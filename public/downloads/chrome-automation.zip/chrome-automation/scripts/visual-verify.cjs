#!/usr/bin/env node
/**
 * Visual verify helper — headless Chromium screenshot with error capture.
 *
 * 사용법:
 *   node visual-verify.cjs <url> [waitMs] [outPath]
 *
 * 예시:
 *   node visual-verify.cjs https://wind-tunnel-cfd.vercel.app/ 4500 /tmp/wt.png
 *
 * 의존성: /Users/mac/node_modules/playwright (글로벌 npm install)
 *
 * Python venv가 비어있고 글로벌 Node playwright가 있을 때 사용.
 * python `from playwright...` → ESM `import 'playwright'` 둘 다 실패하므로
 * CJS `require('/abs/path')` 절대경로로 우회.
 */

const path = require('path');
const GLOBAL_PW = '/Users/mac/node_modules/playwright';
let chromium;
try {
  ({ chromium } = require(GLOBAL_PW));
} catch (e) {
  console.error('❌ 글로벌 playwright 부재:', GLOBAL_PW);
  console.error('   설치: cd /Users/mac && npm i playwright && npx playwright install chromium');
  process.exit(2);
}

const [,, url, waitMsRaw, outPath] = process.argv;
if (!url) {
  console.error('사용법: node visual-verify.cjs <url> [waitMs=3000] [outPath=/tmp/snap.png]');
  process.exit(1);
}
const waitMs = Number(waitMsRaw) || 3000;
const out = outPath || '/tmp/snap.png';

(async () => {
  const browser = await chromium.launch();
  try {
    const ctx = await browser.newContext({
      viewport: { width: 1280, height: 800 },
      deviceScaleFactor: 2,
    });
    const page = await ctx.newPage();
    const errs = [];
    page.on('pageerror', e => errs.push('pageerror: ' + e.message));
    page.on('console', m => {
      if (m.type() === 'error') errs.push('console: ' + m.text());
    });
    const res = await page.goto(url, { waitUntil: 'networkidle', timeout: 30000 });
    console.log('STATUS', res.status());
    await page.waitForTimeout(waitMs);
    await page.screenshot({ path: out, fullPage: false });
    const title = await page.title();
    const canvas = await page.locator('canvas').count();
    console.log('TITLE', title);
    console.log('CANVAS', canvas);
    console.log('ERRORS', errs.length);
    if (errs.length) console.log(errs.slice(0, 5).join('\n'));
    console.log('SAVED', out);
  } finally {
    await browser.close();
  }
})();
