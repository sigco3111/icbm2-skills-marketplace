#!/usr/bin/env python3
"""범용 웹 스크래핑 스크립트 - Playwright 기반"""

import argparse
import json
import sys
from playwright.sync_api import sync_playwright


def scrape(url: str, selector: str = 'body', wait_for: str = None,
           wait_timeout: int = 30000, cookies_file: str = None,
           full_page: bool = False, screenshot: str = None) -> dict:
    """
    웹 페이지에서 데이터를 추출합니다.

    Args:
        url: 대상 URL
        selector: 추출할 CSS 선택자 (기본: body)
        wait_for: 대기할 선택자 (선택사항)
        wait_timeout: 대기 시간 (ms, 기본: 30000)
        cookies_file: 쿠키 JSON 파일 경로 (선택사항)
        full_page: 전체 페이지 렌더링 여부
        screenshot: 스크린샷 저장 경로 (선택사항)

    Returns:
        dict: {title, content, url, screenshot}
    """
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        context = browser.new_context(
            viewport={'width': 1920, 'height': 1080},
            user_agent='Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36'
        )

        # 쿠키 로드
        if cookies_file:
            try:
                with open(cookies_file) as f:
                    context.add_cookies(json.load(f))
            except (FileNotFoundError, json.JSONDecodeError):
                pass

        page = context.new_page()

        try:
            page.goto(url, wait_until='domcontentloaded', timeout=wait_timeout)

            if wait_for:
                page.wait_for_selector(wait_for, timeout=wait_timeout)

            if full_page:
                # 무한 스크롤 (최대 10회)
                for _ in range(10):
                    prev_height = page.evaluate('document.body.scrollHeight')
                    page.evaluate('window.scrollTo(0, document.body.scrollHeight)')
                    page.wait_for_timeout(1000)
                    new_height = page.evaluate('document.body.scrollHeight')
                    if new_height == prev_height:
                        break

            # 스크린샷
            shot_path = None
            if screenshot:
                page.screenshot(path=screenshot, full_page=True)
                shot_path = screenshot

            # 데이터 추출
            element = page.query_selector(selector)
            content = element.inner_text() if element else page.inner_text('body')
            title = page.title()

            # HTML 추출 (선택자 지정 시)
            html = None
            if selector != 'body' and element:
                html = element.inner_html()

            return {
                'title': title,
                'content': content.strip(),
                'html': html,
                'url': url,
                'screenshot': shot_path,
                'status': 'ok'
            }

        except Exception as e:
            return {
                'url': url,
                'status': 'error',
                'error': str(e)
            }
        finally:
            browser.close()


def main():
    parser = argparse.ArgumentParser(description='웹 스크래핑')
    parser.add_argument('url', help='대상 URL')
    parser.add_argument('--selector', '-s', default='body', help='CSS 선택자')
    parser.add_argument('--wait-for', '-w', help='대기할 선택자')
    parser.add_argument('--timeout', '-t', type=int, default=30000, help='타임아웃 (ms)')
    parser.add_argument('--cookies', '-c', help='쿠키 JSON 파일')
    parser.add_argument('--scroll', action='store_true', help='전체 페이지 스크롤')
    parser.add_argument('--screenshot', help='스크린샷 경로')
    parser.add_argument('--json', action='store_true', help='JSON 출력')

    args = parser.parse_args()

    result = scrape(
        url=args.url,
        selector=args.selector,
        wait_for=args.wait_for,
        wait_timeout=args.timeout,
        cookies_file=args.cookies,
        full_page=args.scroll,
        screenshot=args.screenshot
    )

    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        if result['status'] == 'ok':
            print(f"제목: {result['title']}")
            print(f"URL: {result['url']}")
            if result.get('screenshot'):
                print(f"스크린샷: {result['screenshot']}")
            print(f"\n---\n{result['content']}")
        else:
            print(f"에러: {result['error']}", file=sys.stderr)
            sys.exit(1)


if __name__ == '__main__':
    main()
