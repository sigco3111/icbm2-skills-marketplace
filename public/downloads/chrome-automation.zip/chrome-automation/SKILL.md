---
name: chrome-automation
description: Playwright 기반 웹 브라우저 자동화 — 로그인, 스크래핑, 폼 제출, 스크린샷, PDF 생성 등 브라우저 작업 자동화
tags: [playwright, browser, automation, scraping, web]
dependencies:
  - playwright >= 1.58.0
  - python >= 3.9
---

# Chrome Automation (Playwright)

Playwright를 사용한 웹 브라우저 자동화 스킬. 로그인, 데이터 수집, 폼 제출, 스크린샷 등을 자동으로 수행.

## 환경 확인

```bash
# Playwright 설치 확인
python3 -c "from playwright.sync_api import sync_playwright; print('OK')"
# 브라우저 설치 (최초 1회)
playwright install chromium
```

## 기본 패턴

### 1. 빠른 스크래핑 (헤드리스)

```python
from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    page = browser.new_page()
    page.goto('https://example.com')
    title = page.title()
    content = page.inner_text('body')
    browser.close()
```

### 2. 로그인 + 세션 유지

```python
from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    context = browser.new_context()
    page = context.new_page()

    # 로그인
    page.goto('https://example.com/login')
    page.fill('#email', 'user@example.com')
    page.fill('#password', 'password')
    page.click('button[type="submit"]')
    page.wait_for_load_state('networkidle')

    # 로그인 후 페이지 접근
    page.goto('https://example.com/dashboard')
    data = page.inner_text('.dashboard-content')

    # 쿠키 저장 (재사용 가능)
    cookies = context.cookies()
    browser.close()
    return cookies
```

### 3. 저장된 쿠키로 세션 복원

```python
from playwright.sync_api import sync_playwright
import json

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    context = browser.new_context()
    page = context.new_page()

    # 이전 쿠키 로드
    with open('cookies.json') as f:
        cookies = json.load(f)
    context.add_cookies(cookies)

    page.goto('https://example.com/dashboard')  # 이미 로그인된 상태
    browser.close()
```

### 4. 스크린샷 & PDF

```python
from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    page = browser.new_page(viewport={'width': 1920, 'height': 1080})
    page.goto('https://example.com')

    # 전체 페이지 스크린샷
    page.screenshot(path='screenshot.png', full_page=True)

    # PDF 생성
    page.pdf(path='page.pdf', format='A4')
    browser.close()
```

### 5. 동적 콘텐츠 스크래핑 (무한 스크롤, SPA)

```python
from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    page = browser.new_page()
    page.goto('https://example.com/feed')

    # 무한 스크롤
    for _ in range(5):
        page.evaluate('window.scrollTo(0, document.body.scrollHeight)')
        page.wait_for_timeout(1000)

    # SPA에서 특정 요소 대기
    items = page.wait_for_selector('.item-list').inner_text()
    browser.close()
```

### 6. 폼 자동 제출

```python
from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    page = browser.new_page()
    page.goto('https://example.com/form')

    page.fill('#name', '홍길동')
    page.select_option('#category', 'tech')
    page.check('#agree')
    page.set_input_files('#file-upload', '/path/to/file.pdf')
    page.click('#submit')
    page.wait_for_selector('.success-message')
    browser.close()
```

## 실전 시나리오

### Notion 웹 스크래핑

```python
from playwright.sync_api import sync_playwright

def scrape_notion_page(url: str) -> str:
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page()
        page.goto(url)
        page.wait_for_selector('.notion-page-content')
        content = page.inner_text('.notion-page-content')
        browser.close()
        return content
```

### GitHub 트렌딩 수집

```python
from playwright.sync_api import sync_playwright

def scrape_github_trending(language: str = '') -> list:
    url = f'https://github.com/trending/{language}' if language else 'https://github.com/trending'
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page()
        page.goto(url)
        repos = page.query_selector_all('article.Box-row')
        results = []
        for repo in repos:
            name = repo.query_selector('h2 a').inner_text().strip().replace('\n', '/')
            desc = repo.query_selector('p').inner_text().strip() if repo.query_selector('p') else ''
            stars = repo.query_selector('.Link--muted.d-inline-block.mr-3').inner_text().strip()
            results.append({'name': name, 'desc': desc, 'stars': stars})
        browser.close()
        return results
```

## 터미널에서 빠르게 사용

```bash
# 단순 페이지 텍스트 추출
python3 -c "
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b = p.chromium.launch(headless=True)
    pg = b.new_page()
    pg.goto('https://example.com')
    print(pg.inner_text('body'))
    b.close()
"

# 스크린샷
python3 -c "
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b = p.chromium.launch(headless=True)
    pg = b.new_page(viewport={'width': 1920, 'height': 1080})
    pg.goto('https://example.com')
    pg.screenshot(path='output.png', full_page=True)
    b.close()
"
```

## 주의사항

- 항상 `headless=True`로 실행 (에이전트 환경)
- `page.wait_for_load_state('networkidle')`로 AJAX 로딩 대기
- 선택자가 불안정하면 `page.wait_for_selector()` 사용
- 대량 스크래핑 시 `page.wait_for_timeout(1000~2000)`으로 폴리트하게
- 쿠키/세션 정보는 `~/.hermes/secrets/`에 저장, 메모리에 절대 노출 금지
- JavaScript 실행은 `page.evaluate()` 사용

## 파일 구조

```
~/.hermes/skills/automation/chrome-automation/
├── SKILL.md                    # 이 파일
├── scripts/
│   ├── scrape.py               # 범용 스크래핑 스크립트
│   ├── screenshot.py           # 스크린샷/PDF 생성
│   └── form_submit.py          # 폼 자동 제출
└── templates/
    └── selectors.json          # 자주 쓰는 CSS 선택자 템플릿
```
