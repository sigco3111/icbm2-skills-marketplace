---
name: chrome-automation
description: Playwright 기반 웹 브라우저 자동화 — 로그인, 스크래핑, 폼 제출, 스크린샷, PDF 생성 등 브라우저 작업 자동화
tags: [playwright, browser, automation, scraping, web]
dependencies:
  - playwright >= 1.58.0
  - python >= 3.9
---

# Chrome Automation (Playwright)

Playwright를 사용한 웹 브라우저 자동화 스킬. 로그인, 데이터 수집, 폼 제출, 스크린샷 등을 자동으로 수행.

## 환경 확인

```bash
# Playwright 설치 확인
python3 -c "from playwright.sync_api import sync_playwright; print('OK')"
# 브라우저 설치 (최초 1회)
playwright install chromium
```

## 기본 패턴

### 1. 빠른 스크래핑 (헤드리스)

```python
from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    page = browser.new_page()
    page.goto('https://example.com')
    title = page.title()
    content = page.inner_text('body')
    browser.close()
```

### 2. 로그인 + 세션 유지

```python
from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    context = browser.new_context()
    page = context.new_page()

    # 로그인
    page.goto('https://example.com/login')
    page.fill('#email', 'user@example.com')
    page.fill('#password', 'password')
    page.click('button[type="submit"]')
    page.wait_for_load_state('networkidle')

    # 로그인 후 페이지 접근
    page.goto('https://example.com/dashboard')
    data = page.inner_text('.dashboard-content')

    # 쿠키 저장 (재사용 가능)
    cookies = context.cookies()
    browser.close()
    return cookies
```

### 3. 저장된 쿠키로 세션 복원

```python
from playwright.sync_api import sync_playwright
import json

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    context = browser.new_context()
    page = context.new_page()

    # 이전 쿠키 로드
    with open('cookies.json') as f:
        cookies = json.load(f)
    context.add_cookies(cookies)

    page.goto('https://example.com/dashboard')  # 이미 로그인된 상태
    browser.close()
```

### 4. 스크린샷 & PDF

```python
from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    page = browser.new_page(viewport={'width': 1920, 'height': 1080})
    page.goto('https://example.com')

    # 전체 페이지 스크린샷
    page.screenshot(path='screenshot.png', full_page=True)

    # PDF 생성
    page.pdf(path='page.pdf', format='A4')
    browser.close()
```

### 5. 동적 콘텐츠 스크래핑 (무한 스크롤, SPA)

```python
from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    page = browser.new_page()
    page.goto('https://example.com/feed')

    # 무한 스크롤
    for _ in range(5):
        page.evaluate('window.scrollTo(0, document.body.scrollHeight)')
        page.wait_for_timeout(1000)

    # SPA에서 특정 요소 대기
    items = page.wait_for_selector('.item-list').inner_text()
    browser.close()
```

### 6. 폼 자동 제출

```python
from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    page = browser.new_page()
    page.goto('https://example.com/form')

    page.fill('#name', '홍길동')
    page.select_option('#category', 'tech')
    page.check('#agree')
    page.set_input_files('#file-upload', '/path/to/file.pdf')
    page.click('#submit')
    page.wait_for_selector('.success-message')
    browser.close()
```

## 실전 시나리오

### Notion 웹 스크래핑

```python
from playwright.sync_api import sync_playwright

def scrape_notion_page(url: str) -> str:
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page()
        page.goto(url)
        page.wait_for_selector('.notion-page-content')
        content = page.inner_text('.notion-page-content')
        browser.close()
        return content
```

### GitHub 트렌딩 수집

```python
from playwright.sync_api import sync_playwright

def scrape_github_trending(language: str = '') -> list:
    url = f'https://github.com/trending/{language}' if language else 'https://github.com/trending'
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page()
        page.goto(url)
        repos = page.query_selector_all('article.Box-row')
        results = []
        for repo in repos:
            name = repo.query_selector('h2 a').inner_text().strip().replace('\n', '/')
            desc = repo.query_selector('p').inner_text().strip() if repo.query_selector('p') else ''
            stars = repo.query_selector('.Link--muted.d-inline-block.mr-3').inner_text().strip()
            results.append({'name': name, 'desc': desc, 'stars': stars})
        browser.close()
        return results
```

## 터미널에서 빠르게 사용

```bash
# 단순 페이지 텍스트 추출
python3 -c "
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b = p.chromium.launch(headless=True)
    pg = b.new_page()
    pg.goto('https://example.com')
    print(pg.inner_text('body'))
    b.close()
"

# 스크린샷
python3 -c "
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b = p.chromium.launch(headless=True)
    pg = b.new_page(viewport={'width': 1920, 'height': 1080})
    pg.goto('https://example.com')
    pg.screenshot(path='output.png', full_page=True)
    b.close()
"
```

## 주의사항

- 항상 `headless=True`로 실행 (에이전트 환경)
- `page.wait_for_load_state('networkidle')`로 AJAX 로딩 대기
- 선택자가 불안정하면 `page.wait_for_selector()` 사용
- 대량 스크래핑 시 `page.wait_for_timeout(1000~2000)`으로 폴리트하게
- 쿠키/세션 정보는 `~/.hermes/secrets/`에 저장, 메모리에 절대 노출 금지
- JavaScript 실행은 `page.evaluate()` 사용

## ⚠️ Node.js 글로벌 Playwright — ESM/CJS Import 함정 (2026-07-06 wind-tunnel-cfd 실측)

Python venv 비어있고 글로벌 `/Users/mac/node_modules/playwright`만 있을 때 — Node.js로 우회. **세 가지 함정 동시 발생**:

### 함정 ①: ESM `import 'playwright'` (NODE_PATH 무시)

```bash
# ❌ ERR_MODULE_NOT_FOUND — Node ESM은 NODE_PATH 완전 무시
NODE_PATH=/Users/mac/node_modules node -e "import { chromium } from 'playwright'"
```

### 함정 ②: ESM `import 'playwright/index.js'` 도 거부

```bash
# ❌ 동일 — ESM resolver가 절대 경로 절대경로 import도 거부
node -e "import { chromium } from 'playwright/index.js'"
# → Did you mean to import "playwright/index.js"?
```

### ✅ 해결: CJS `require('/abs/path')` 절대경로

```bash
cat > /tmp/visual-verify.cjs <<'EOF'
const { chromium } = require('/Users/mac/node_modules/playwright');
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 800 }, deviceScaleFactor: 2 });
  const page = await ctx.newPage();
  const errs = [];
  page.on('pageerror', e => errs.push(String(e)));
  page.on('console', m => { if (m.type() === 'error') errs.push('CONSOLE: ' + m.text()); });
  const url = process.argv[2] || 'https://example.vercel.app/';
  const waitMs = Number(process.argv[3]) || 4500;
  const res = await page.goto(url, { waitUntil: 'networkidle', timeout: 30000 });
  console.log('STATUS', res.status());
  await page.waitForTimeout(waitMs);
  await page.screenshot({ path: process.argv[4] || '/tmp/snap.png', fullPage: false });
  console.log('TITLE', await page.title(), 'CANVAS', await page.locator('canvas').count());
  console.log('ERRORS', errs.length);
  await browser.close();
})();
EOF
node /tmp/visual-verify.cjs "https://wind-tunnel-cfd.vercel.app/" 4500 /tmp/wt.png
```

### Python vs Node 선택 가이드

| 환경 | 접근 |
|---|---|
| 글로벌 Python venv에 `playwright` 설치 | SKILL.md 본체 패턴 (`from playwright.sync_api import sync_playwright`) |
| 글로벌 `/Users/mac/node_modules/playwright`만 존재 | 위 CJS 패턴 (`require('/Users/mac/node_modules/playwright')`) |
| 둘 다 부재 | 1회성 설치: `pip install playwright && playwright install chromium` |

### 결정성 팁 (canvas-based 정적 사이트 검증용)

- `deviceScaleFactor: 2` — 레티나급 선명한 스크린샷
- `waitUntil: 'networkidle'` + 명시적 `waitForTimeout(N초)` — 솔버/애니메이션 warm-up
- `pageerror` + `console error` 둘 다 capture → 빈 화면·런타임 에러 검출
- 스크린샷 후 → `vision_analyze` 로 "기능이 의도대로 동작하는지" 2차 검증 (정량적 증거로 가장 강함)

### 재사용 가능 스크립트

`scripts/visual-verify.cjs` — URL + 대기시간 + 저장경로 인자 받는 일반화 스크립트. Python venv 없는 환경 즉시 사용.

세션 후 정리:
```bash
rm -f /tmp/visual-verify.cjs /tmp/wt.png /tmp/snap.png
```

## 🎭 E2E 테스트 (@playwright/test, TypeScript) — 2026-07-10 v1.2 실측

Python Playwright (스크래핑) 외에 **TypeScript Playwright e2e** (테스트 자동화) 패턴. CI/Vercel preview URL 자동 검증에 특화.

### 설치 (Next.js 15+ 기준)

```bash
npm install --save-dev @playwright/test
npx playwright install chromium webkit   # macOS 캐시: ~/Library/Caches/ms-playwright/chromium-1228/
```

### playwright.config.ts 패턴 (Vercel preview URL 자동 검증)

```typescript
import { defineConfig, devices } from "@playwright/test";

const PORT = process.env.PORT ?? "3000";
const BASE_URL = process.env.PLAYWRIGHT_BASE_URL ?? `http://localhost:${PORT}`;

export default defineConfig({
  testDir: "./test/e2e",
  fullyParallel: true,
  forbidOnly: !!process.env.CI, // CI에서 .only() 사용 시 fail
  retries: process.env.CI ? 2 : 0, // CI에서만 재시도
  workers: process.env.CI ? 1 : undefined,
  reporter: process.env.CI ? "github" : "list",
  use: { baseURL: BASE_URL, trace: "on-first-retry", screenshot: "only-on-failure" },
  projects: [
    { name: "chromium", use: { ...devices["Desktop Chrome"] } },
    { name: "webkit", use: { ...devices["Desktop Safari"] } },
  ],
  webServer: process.env.CI
    ? undefined // CI: Vercel preview URL
    : { command: "npm run dev", url: BASE_URL, reuseExistingServer: !process.env.CI, timeout: 60_000 },
});
```

### API Mock 패턴 (실계좌 영향 zero)

```typescript
// test/e2e/helpers/api-mock.ts
import type { Page, Route } from "@playwright/test";

export async function setupApiMocks(page: Page): Promise<void> {
  // holdings mock: 삼성전자 10주 + SK하이닉스 5주
  await page.route("**/api/toss/api/v1/holdings", async (route: Route) => {
    await route.fulfill({
      status: 200,
      contentType: "application/json",
      body: JSON.stringify({
        data: { result: { items: [
          { symbol: "005930", symbolName: "삼성전자", quantity: 10, avgPrice: 70000 },
          { symbol: "000660", symbolName: "SK하이닉스", quantity: 5, avgPrice: 130000 },
        ]}},
      }),
    });
  });

  // 모드별 응답 분기
  await page.route("**/api/telegram/send", async (route: Route) => {
    const body = JSON.parse(route.request().postData() ?? "{}");
    const ok = body.confirmMode === "auto";
    await route.fulfill({ status: 200, contentType: "application/json", body: JSON.stringify({ ok, ... }) });
  });
}
```

### E2E Test Spec 패턴

```typescript
import { test, expect } from "@playwright/test";
import { setupApiMocks } from "./helpers/api-mock";

test.describe("Dashboard", () => {
  test.beforeEach(async ({ page }) => { await setupApiMocks(page); });

  test("매수 진행 → confirm 모달 → 발송 → 결과 표시 (auto 모드)", async ({ page }) => {
    await page.addInitScript(() => {
      window.localStorage.setItem("toss-trader:confirm-mode", "auto");
    });
    await page.goto("/");
    await page.getByRole("button", { name: "매수 진행" }).click();
    await expect(page.getByRole("heading", { name: "주문 confirm" })).toBeVisible();
    await page.getByRole("button", { name: "발송" }).click();
    await expect(page.getByText(/주문 성공/)).toBeVisible({ timeout: 10_000 });
  });
});
```

### ⚠️ Playwright strict mode `.or()` 함정 (v1.2 실측)

```typescript
// ❌ strict mode violation: .or()가 2 elements 매치 시 fail
await expect(page.getByText(/A/).or(page.getByText(/B/))).toBeVisible();

// ✅ 각 element 별도 검증 (1 element 보장)
await expect(page.getByText("A")).toBeVisible();
await expect(page.getByText("B")).toBeVisible();

// ✅ 또는 getByRole('heading', ...) 명시 (unique selector)
await expect(page.getByRole("heading", { name: "주문 confirm" })).toBeVisible();
```

### 모달 내부 검증 패턴

```typescript
// 모달 스코프 격리
const modal = page.getByRole("heading", { name: "주문 confirm" }).locator("..");
await expect(modal.getByText(/005930/)).toBeVisible();
await expect(modal.getByText(/매수/)).toBeVisible();
```

### localStorage 사전 설정 (addInitScript)

```typescript
// page.goto() 전에 localStorage 설정
await page.addInitScript(() => {
  window.localStorage.setItem("toss-trader:confirm-mode", "auto");
});
```

### GitHub Actions (.github/workflows/e2e.yml)

```yaml
name: E2E Tests
on: [pull_request, push]
jobs:
  e2e:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: "20", cache: "npm" }
      - run: npm ci
      - run: npx playwright install --with-deps chromium webkit
      - run: npm run build
      - run: npm test  # vitest unit 먼저
      - env:
          PLAYWRIGHT_BASE_URL: ${{ secrets.VERCEL_PREVIEW_URL || 'http://localhost:3000' }}
          CI: "true"
        run: npx playwright test
      - uses: actions/upload-artifact@v4
        if: always()
        with:
          name: playwright-report
          path: playwright-report/
          retention-days: 7
```

### package.json 스크립트

```json
{
  "scripts": {
    "test": "vitest run",
    "test:e2e": "playwright test",
    "test:e2e:ui": "playwright test --ui"
  }
}
```

### .gitignore 추가

```
/test-results/
/playwright-report/
/playwright/.cache/
```

### Vercel preview URL 통합

- **Vercel GitHub App** 연동 → PR마다 preview URL 자동 생성
- `VERCEL_PREVIEW_URL` GitHub Secret 또는 Vercel Actions 자동 주입
- e2e가 실제 배포 환경에서 실행 (mock + 실서버 검증)

### Python vs Node.js vs TypeScript Playwright 비교

| 영역 | 도구 | 언어 | 사용 |
|---|---|---|---|
| 스크래핑 | `playwright` | Python/Node.js | 빠른 일회성 |
| e2e 테스트 | `@playwright/test` | **TypeScript** | **CI + Vercel preview** |
| 비주얼 검증 | `playwright` + `vision_analyze` | Python/Node.js | 디자인 회귀 |
| 캐노니컬 비교 | `chrome-automation` SKILL.md | Python venv | v0 (스크립팅) |

## 파일 구조

```
~/.hermes/skills/automation/chrome-automation/
├── SKILL.md                    # 이 파일
├── scripts/
│   ├── scrape.py               # 범용 스크래핑 스크립트
│   ├── screenshot.py           # 스크린샷/PDF 생성
│   └── form_submit.py          # 폼 자동 제출
└── templates/
    └── selectors.json          # 자주 쓰는 CSS 선택자 템플릿
```
