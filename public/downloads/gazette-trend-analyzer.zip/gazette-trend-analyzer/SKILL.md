---
name: gazette-trend-analyzer
description: 대한민국 관보 트렌드 분석기 — ai-readable-gazette-kr 데이터 기반 정책 흐름 분석 대시보드
---

# 관보 트렌드 분석기

## 프로젝트 정보

- **GitHub:** https://github.com/sigco3111/gazette-trend-analyzer
- **배포:** https://gazette-trend-analyzer.vercel.app
- **데이터소스:** https://hosungseo.github.io/ai-readable-gazette-kr/

## 데이터 소스 구조

### meta.json
- `heatmap`: `[{ym, count}]` 배열 (월별 공시 수)
- `institutions`: `[{name, count, cat}]` 배열 (기관별 공시 수)
- `dates`: 날짜 문자열 배열

### 날짜별 JSON (dates/{YYYY-MM-DD}.json)
- `{date, docs: [{n, inst, title, file, raw, blob}]}`

## 기술 스택

- Next.js (App Router)
- Tailwind CSS v4
- Vercel 배포

## 주의사항

- Tailwind v4에서 `mx-auto`가 컴파일에서 누락될 수 있음 → CSS에서 직접 `margin: auto`로 해결
- AI 느낌 배제, 에디토리얼/저널 스타일 디자인 유지
