---
name: ace-step-music
description: "Kaggle T4 GPU에서 ACE-Step 1.5 터보로 가사 없는 인스트루멘탈 음악 생성 — 30초~60초 곡, 프롬프트 기반"
tags: [music-generation, ace-step, kaggle, t4, gpu, instrumental]
---

# ACE-Step 1.5 Instrumental Music Generation

Kaggle 무료 T4 GPU에서 ACE-Step 1.5 터보 모델로 인스트루멘탈 음악을 생성합니다. 프롬프트만으로 장르/무드/악기를 지정할 수 있으며, 가사 없이 음악만 생성합니다.

## ⚠️ 제한사항

- **가사(lyrics) 입력 불가**: T4 GPU에서 `ACESTEP_DTYPE=float32` + 가사 조합 시 OOM/에러 발생
- **보컬 불가**: `lyrics=None`으로만 동작
- 음성(TTS)이 필요한 경우 → `qwen3-tts` 스킬 사용

## 모델 정보

| 항목 | 값 |
|---|---|
| 모델 | ACE-Step 1.5 Turbo |
| 형식 | wav → ffmpeg로 mp3 변환 |
| 기본 길이 | 30초 |
| 최대 길이 | ~60초 (T4 메모리 제한) |
| GPU 요구 | T4 16GB 이상 |

## 전제 조건

- Kaggle 계정
- Kaggle 노트북 설정: Settings → **Internet: On** → **Accelerator: GPU T4 x2**

## Kaggle 노트북

스크립트: `~/.hermes/scripts/kaggle/ace-step-music.ipynb`

### 사용법

1. Kaggle에 새 노트북 생성
2. Settings → Internet: On, Accelerator: GPU T4 x2
3. 아래 셀들을 순서대로 실행

### 셀 1 — FFmpeg + 저장소 클론 + 의존성 설치

```python
!apt-get install -y ffmpeg

# ACE-Step 저장소 클론
!git clone https://github.com/ACE-Step/ACE-Step-1.5.git
%cd ACE-Step-1.5

# 패키지 설치
!pip install uv
!uv sync

# 가상환경 PATH 추가
import os
os.environ["PATH"] = os.getcwd() + "/.venv/bin:" + os.environ["PATH"]
```

### 셀 2 — 음악 생성 함수 정의

```python
import os, sys, subprocess, torch, gc

os.environ.pop("MPLBACKEND", None)
venv_site = "/kaggle/working/ACE-Step-1.5/.venv/lib/python3.12/site-packages"
sys.path.insert(0, venv_site)

def generate_music(prompt, duration=30, output_path="/kaggle/working/output/music.mp3"):
    """가사 없는 인스트루멘탈 음악 생성 (T4 최적화)

    Args:
        prompt: 음악 설명 프롬프트 (예: "emotional K-pop ballad with piano and strings")
        duration: 생성 길이 (초). 기본 30, 최대 ~60
        output_path: 출력 mp3 경로
    """
    gc.collect()
    torch.cuda.empty_cache()

    os.environ["ACESTEP_DTYPE"] = "float32"

    from acestep.handler import AceStepHandler
    from acestep.inference import GenerationParams, GenerationConfig, generate_music as gm

    dit = AceStepHandler()
    dit.initialize_service(
        project_root="/kaggle/working/ACE-Step-1.5",
        config_path="acestep-v15-turbo",
        device="cuda"
    )

    # 가사 없이 프롬프트로만 생성
    params = GenerationParams(
        caption=prompt,
        duration=duration,
        lyrics=None,          # ← 반드시 None
        vocal_language="en",
    )
    config = GenerationConfig(audio_format="wav")
    result = gm(dit, None, params, config, save_dir="/kaggle/working/output")

    if result.success:
        for audio in result.audios:
            fixed_wav = "/kaggle/working/output/music.wav"
            os.rename(audio['path'], fixed_wav)
            os.makedirs(os.path.dirname(output_path), exist_ok=True)
            subprocess.run(["ffmpeg", "-y", "-i", fixed_wav,
                          "-codec:a", "libmp3lame", "-q:a", "2", output_path])
            print(f"✅ 음악 생성 완료: {output_path}")
    else:
        print(f"❌ 실패: {result.error}")

    del dit
    gc.collect()
    torch.cuda.empty_cache()
```

### 셀 3 — 음악 생성 실행

```python
generate_music(
    prompt="emotional K-pop ballad with piano and strings",
    duration=30
)
```

## 프롬프트 예시

```
"upbeat electronic dance music with synth pads and heavy bass"
"calm lo-fi hip hop with jazz piano and vinyl crackle"
"epic orchestral cinematic score with brass and timpani"
"acoustic guitar fingerpicking folk melody"
"dark ambient synthwave with retro pads"
"energetic rock with distorted guitar riffs and drums"
"smooth jazz with saxophone and upright bass"
"minimal techno with deep bass and atmospheric pads"
```

## 주의사항

- **가사 넣으면 에러남**: 반드시 `lyrics=None` 사용
- **OOM 시**: `duration`을 15~20초로 줄이거나, 세션을 재시작
- **초기 실행**: 모델 다운로드로 ~1분 소요 (이후 캐시됨)
- **cuFFT/cuDNN 경고**: 무시해도 정상 동작
