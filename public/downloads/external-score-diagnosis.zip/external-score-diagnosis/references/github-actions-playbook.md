# GitHub Actions Playbook — 외부 OSS 점수 개선 실행용

> 2026-07-31 sigco3111 gitfut 세션에서 추출한 패턴 모음.
> Step 6/7 ("대신 해줘" follow-up + repeatable execution) 구현 시 참조.
> 이건 **gitfut-class** 점수 (GitHub 활동 데이터 기반, z-score 또는 가산 모델) 에 한정.

## 1. Watch 풀 표준 5-레포

대상은 *사용자가 실제로 사용 중인 도구* — 별도 표시한(starred) 레포나 fork 부모가 좋은 후보.

**sigco3111 instance (2026-07-31 검증)**:

```bash
for repo in \
  anomalyco/opencode \
  code-yeongyu/oh-my-openagent \
  NousResearch/hermes-agent \
  anomalyco/models.dev \
  junhoyeo/tokscale; do
  gh watch "$repo"
done
```

⚠️ `gh watch` 출력은 단일 라인 `workflow` — **에러 아님**. 절대 출력 길이로 실패 판정 금지.

**풀 선정 기준**:
1. 사용자가 starred한 repo (GitHub API: `user/starred`)
2. 사용자가 fork한 repo의 부모 (PASS 위주)
3. 사용자의 README/포트폴리오에 언급된 도구

## 2. Weekly Cron 큐 표준

```bash
# cronjob create
{
  "name": "gitfut-weekly-queue",
  "schedule": "0 9 * * 1",   # 월요일 09:00 KST
  "skills": ["gitfut-growth"],
  "deliver": "telegram"        # 또는 "all"
}
```

⚠️ `deliver='local'`이면 CLI/TUI 세션은 결과를 다음 세션에서만 볼 수 있음. 텔레그램/슬랙/디스코드 연결 시 `deliver='telegram'` 명시.

## 3. PR 큐 검색 쿼리 (검증된 형태)

```bash
# ✅ 동작하는 형태
gh api 'search/issues?q=is:open+is:pr+repo:anomalyco/opencode+comments:0..3+created:>2026-07-25&per_page=10'

# ❌ 동작 안 함 (출력이 항상 비어있음)
gh search prs 'is:open is:pr repo:anomalyco/opencode'
```

⚠️ search API는 **secondary rate limit** 빡셈 — 분당 1-2회. 5개 레포를 매주 cron 한 번 호출하는 게 안전.

## 4. 한국어 코멘트 템플릿 (3가지)

자연스러운 한국어 첫 인사 + 짧은 본문 + 마무리 질문 구조:

```
Hi! 👋 작은 기여 제안입니다.

[구체적 제안 1-2줄]

혹시 이 방향으로 PR을 보내도 될까요? 더 구체적인 코드 변경 전에 컨벤션 먼저 확인하고 싶어요.

감사합니다! 🙏
```

### 4a. 🟢 질문형 (가장 안전, PR 없어도 카운트)
```
Hi! 👋 [repo] 보면서 발견했는데, [X 기능] 부분 — 왜 이런 방식을 선택하셨나요?
저도 비슷한 문제 겪었는데, [Y 대안]도 고려해보셨는지 궁금해서요.
```

### 4b. 🟡 docs 제안형
```
Hi! 👋 README의 [X 섹션] — 한국어 번역 PR을 보내도 될까요?
[korean OSS community] 도움 받고 있어서, 작은 기여부터 시작하고 싶어요.
CONTRIBUTING 가이드 먼저 읽어보고 진행하겠습니다.
```

### 4c. 🟠 i18n 큐 등록 제안형
```
Hi! 👋 [repo] 한국어 사용자로 매일 사용 중입니다.
i18n 기여를 별도 큐로 받는 게 있는지 궁금해서요 — 있다면 등록 부탁드립니다!
```

## 5. 절대 하지 말 것 (Anti-pattern)

| 패턴 | 이유 |
|---|---|
| `gh star <random-repo>` 인위적 별 모으기 | GitFut anti-gaming heuristic → 점수 패널티 |
| 같은 레포에 1주일에 5개 PR | 협업 가이드 위반 + maintainer annoyance |
| 인위적 follow | 신뢰도 무너뜨림 |
| OAuth 토큰으로 외부 PR 자동 push | rate limit + bot detection + merge 거부 (§Pitfalls #9 in main SKILL) |
| 같은 PR에 여러 watch 풀에서 동시 알림 | 노이즈 폭탄 |

## 6. 검증 체크리스트 (월 1회)

- [ ] `gh api user/sigco3111` → public_repos, followers 증가 추이
- [ ] gitfut.dev 본인 카드 캡처 → OVR 변화
- [ ] `gh api 'search/issues?q=author:sigco3111+is:pr+created:>YYYY-MM-DD'` → PAS 측정
- [ ] tension 완화 확인: SHO/PAS 점수 +1-2pt 동반 상승 여부 (z-score 엔진 한정)

## 7. 시그코 fork 9개 → upstream 동기화 패턴

sigco3111 fork 9개의 parent가 명확하지 않을 때 (`gh repo list --json parent`가 null):

```bash
# per-fork parent 확인
for fork in sigco3111/gitfut sigco3111/end_of_eden sigco3111/triplea-kr sigco3111/neko-master sigco3111/i-have-adhd sigco3111/OpenMinis sigco3111/oh-my-agent sigco3111/open-design sigco3111/tokenmon; do
  echo "── $fork ──"
  gh repo view "$fork" --json parent,nameWithOwner 2>/dev/null | python3 -c "
import sys, json
try:
    d = json.loads(sys.stdin.read())
    p = d.get('parent') or {}
    print('   upstream:', p.get('nameWithOwner', '(없음)'))
except: print('   parse err')
"
done
```

parent를 알면:
1. upstream의 새 PR 후보 리스트에서 sigco3111 fork 작업과 동기화 가능한 PR 추출
2. 영어 commit message + `Co-authored-by: sigco3111 <email>` trailer
3. CHANGELOG/PR template 자동 매칭 → PR 본문 초안 작성

## 8. 환경 노트

- macOS 시스템 Python 3.9 (`/Applications/Xcode.app/...`) — `json.loads`가 strict 모드. multi-page JSON array 파싱 시 "Extra data" 에러 가능. 해결: `jq` 사용 또는 단일 Python 호출로 묶기.
- Xcode 기본 Python 외에 `python3` (Homebrew/pyenv 등) 가 따로 있을 수 있음 — 터미널 기본 `which python3` 확인.
