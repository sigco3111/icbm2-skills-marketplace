/* score-replay.js — generic Node.js harness for replaying a third-party
 * scoring platform's formula against a user's real signals.
 *
 * Usage:
 *   1. Clone the platform's repo:   git clone --depth 1 <repo-url> /tmp/<platform>
 *   2. Read the scoring engine + constants.
 *   3. Port the math from the platform's language (TypeScript / Python / Go)
 *      to the sections marked <<PLATFORM-SPECIFIC>> below.
 *   4. Provide a `signals` object with the platform's input fields.
 *   5. Run:   node /path/to/score-replay.js
 *   6. Confirm `buildCard(signals)` matches the platform's displayed stat values.
 *   7. Iterate the counterfactual block at the bottom to find highest-leverage
 *      improvements.
 *
 * Verified against gitfut (younesfdj/gitfut) — see references/gitfut-formula-replay.md
 * for the full worked example.
 */

// ============================================================================
// <<PLATFORM-SPECIFIC>> — Port these functions from the platform's source code
// ============================================================================

// 1. The scoring engine functions. The names and shape below are from
//    lib/scoring/engine.ts of gitfut; rename + retype as needed.

const Lg = (x) => Math.log10(Math.max(0, x) + 1);
const sigmoid = (z) => 1 / (1 + Math.exp(-z));
const lerp = (a, b, t) => a + (b - a) * t;
const clamp = (x, lo, hi) => Math.max(lo, Math.min(hi, x));
const mean = (a) => a.reduce((s, x) => s + x, 0) / a.length;

const STATS = ["pac", "sho", "pas", "dri", "def", "phy"]; // platform's stat axis names
const ATTACK_STATS = ["pac", "sho", "pas", "dri"];        // or whatever the platform defines

const K = {
  // platform-specific constants — copy from constants.ts / k.ts / weights.json
  magnitude: { w1: 0.5, w2: 0.4, w3: 0.5, w4: 0.08, b: -2.8, lo: 48, hi: 82 },
  tension:   { alpha: 0.7, pairs: [["sho","def"],["dri","phy"],["pac","def"]] },
  spike:     { base: 8, cohesion: 0.6 },
  legacy:    { a: 1.0, b: 0.7, c: 0.3, d: 0.3, e: 0.3, f: 6.0, activeCap: 15, bonusMax: 11 },
  ovrCap:    88,
};
const WEIGHTS = {
  Forward:   { pac: 0.2,  sho: 0.3,  pas: 0.1,  dri: 0.2,  def: 0.05, phy: 0.15 },
  Playmaker: { pac: 0.1,  sho: 0.15, pas: 0.3,  dri: 0.25, def: 0.1,  phy: 0.1  },
  Anchor:    { pac: 0.1,  sho: 0.05, pas: 0.15, dri: 0.1,  def: 0.4,  phy: 0.2  },
};

function rawStats(s) {
  // platform-specific — copy verbatim from the source
  const o = {
    pac: 36 + 12 * Lg(s.recent_contributions),
    sho: 36 + 13 * Lg(s.total_stars_owned) + 5 * Lg(s.max_repo_stars),
    pas: 40 + 12 * Lg(s.prs_to_others) + 9 * Lg(s.followers),
    dri: 58 + 7 * Math.sqrt(s.languages),
    def: 40 + 14 * Lg(s.reviews + s.issues_closed),
    phy: 40 + 9 * Lg(s.total_contributions_lifetime) + 2.2 * Math.min(s.active_years, 12),
  };
  for (const k of STATS) o[k] = clamp(Math.round(o[k]), 1, 99);
  return o;
}
function center(s) {
  const { w1, w2, w3, w4, b, lo, hi } = K.magnitude;
  const M = sigmoid(w1*Lg(s.total_stars_owned) + w2*Lg(s.followers) + w3*Lg(s.total_contributions_lifetime) + w4*s.account_age_years + b);
  return lerp(lo, hi, M);
}
function zscore(raw) {
  const v = STATS.map((k) => raw[k]);
  const m = mean(v);
  const sd = Math.sqrt(mean(v.map((x) => (x - m) ** 2))) || 1;
  const p = {}; STATS.forEach((k, i) => (p[k] = (v[i] - m) / sd));
  return p;
}
function applyTension(p) {
  const out = { ...p };
  for (const [a, b] of K.tension.pairs) {
    const overlap = Math.max(0, Math.min(out[a], out[b]));
    const weaker = out[a] <= out[b] ? a : b;
    out[weaker] -= K.tension.alpha * overlap;
  }
  return out;
}
function spike(p, c) {
  const v = STATS.map((k) => p[k]);
  const lop = clamp((Math.max(...v) - Math.min(...v)) / 4, 0, 1);
  const spread = K.spike.base * (1 + lop);
  const m = mean(v);
  const raw = {}; STATS.forEach((k) => (raw[k] = c + spread * (p[k] - m)));
  const am = mean(ATTACK_STATS.map((k) => raw[k]));
  ATTACK_STATS.forEach((k) => (raw[k] = am + K.spike.cohesion * (raw[k] - am)));
  const st = {}; STATS.forEach((k) => (st[k] = clamp(Math.round(raw[k]), 1, 99)));
  return st;
}
function positionFromShape(st) {
  const fam = { Forward: st.sho + st.pac, Playmaker: st.pas + st.dri, Anchor: st.def + st.phy };
  const family = Object.keys(fam).sort((a, b) => fam[b] - fam[a])[0];
  const position =
    family === "Forward" ? (st.pac > st.sho ? "RW" : "ST")
    : family === "Playmaker" ? (st.pas > st.dri ? "CM" : "CAM")
    : (st.def > st.phy ? "CB" : "CDM");
  return { position, family };
}
function weightedOVR(stats, family) {
  const w = WEIGHTS[family];
  return Math.min(Math.round(STATS.reduce((s, k) => s + stats[k] * w[k], 0)), K.ovrCap);
}
function legacyScore(s) {
  const { a, b, c, d, e, f, activeCap } = K.legacy;
  const z = a*Math.log(s.account_age_years+1) + b*Math.min(s.active_years, activeCap) + c*Lg(s.followers) + d*Lg(s.total_stars_owned) + e*Lg(s.max_repo_stars) - f;
  return sigmoid(z);
}
function buildCard(s) {
  const stats = spike(applyTension(zscore(rawStats(s))), center(s));
  const { position, family } = positionFromShape(stats);
  const baseOVR = weightedOVR(stats, family);
  const L = legacyScore(s);
  const overall = clamp(baseOVR + Math.round(K.legacy.bonusMax * L), 1, 99);
  return { stats, position, family, baseOVR, overall, L };
}

// ============================================================================
// <<USER-SPECIFIC>> — Provide the user's real signals here
// ============================================================================
//
// Get these from the canonical source (GitHub API, Wakatime API, etc.) using
// the SAME fields the platform's own client uses. Don't take them from the
// platform's score endpoint — that gives you only the result, not the inputs.
//
// For GitHub: use `gh api graphql` with `-f query=@file.gql` (avoid the
// `gh api graphql` integer-literal bug by reading the query from a file).
// See references/gitfut-formula-replay.md §5 for the full extraction.

const signals = {
  // baseline values
  followers: 18,
  total_stars_owned: 25,
  max_repo_stars: 2,
  languages: 9,
  recent_contributions: 1174,
  total_contributions_lifetime: 1232,
  active_years: 2,
  account_age_years: 4.35,
  prs_to_others: 0,
  reviews: 1,
  issues_closed: 2,
};

// ============================================================================
// Verification — must match the platform's displayed stat values exactly
// ============================================================================

console.log("\n=== TODAY's CARD (replay) ===");
console.log(buildCard(signals));
console.log("\nIf this does not match the platform's displayed stats, you missed a field.");
console.log("Check: active_years formula, lifetime window slicing, recent_contributions sum.");

// ============================================================================
// Counterfactuals — rank by ΔOVR / effort
// ============================================================================

function mutate(fn, label) {
  const s2 = { ...signals };
  fn(s2);
  const { overall } = buildCard(s2);
  console.log(`${label.padEnd(60)} -> OVR ${overall}`);
}

console.log("\n=== COUNTERFACTUALS (ranked by ΔOVR) ===");
mutate((s) => (s.total_stars_owned = 2000),        "total_stars_owned 25 -> 2,000  (+1975)  [자력: 시간 누적]");
mutate((s) => (s.active_years = 5),                "active_years 2 -> 5            [봉쇄: pushedAt 서버측 검증]");
mutate((s) => (s.max_repo_stars = 200),            "max_repo_stars 2 -> 200        [자력: 콘텐츠/노출]");
mutate((s) => (s.followers = 50),                  "followers 18 -> 50             [자력: 콘텐츠 발행 자동화]");
mutate((s) => (s.recent_contributions = 1500),     "recent_contributions 1,174 -> 1,500  [자력: 자연 누적]");
mutate((s) => (s.total_contributions_lifetime = 5000), "lifetime_contribs 1,232 -> 5,000  [자력: 장기 누적]");
mutate((s) => (s.prs_to_others = 80),              "prs_to_others 0 -> 80          [봉쇄: 시스템 토큰 자동 푸시 불가]");
mutate((s) => (s.reviews = 60),                    "reviews 1 -> 60                [자력: 본인 OSS 인입 PR 응답]");
mutate((s) => (s.languages = 12),                  "languages 9 -> 12              [자력, sqrt saturates]");
mutate((s) => (s.account_age_years = 5),           "account_age_years 4.35 -> 5    [자력, 시간 경과]");

console.log("\n=== INSIGHT ===");
console.log("Log/sqrt curves saturate fast: one viral repo > 100 small ones.");
console.log("Stat saturations to watch: languages (sqrt), reviews (log).");
console.log("Linear levers: active_years, account_age_years, max_repo_stars.");
console.log("");
console.log("=== 봉쇄 시그널 표시 ===");
console.log("각 시그널 옆 [자력 / 봉쇄] 라벨을 보고 사용자에게 정직하게 보고:");
console.log("- [자력]: 사용자가 실제 행동으로 만들 수 있음 (시간 누적, 콘텐츠 발행 등)");
console.log("- [봉쇄]: 공식에는 있지만 자력으로는 만들 수 없음. 사용자가 '진행해줘' 요청 시");
console.log("  정직하게 봉쇄 이유 (Pitfalls #8, #9)를 알리고 대안을 함께 제시할 것.");
