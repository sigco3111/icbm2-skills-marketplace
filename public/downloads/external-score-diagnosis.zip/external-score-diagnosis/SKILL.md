---
name: external-score-diagnosis
description: Diagnose why a user's score / rating / tier dropped or stalled on a third-party scoring platform (gitfut, wakatime, codewars, githut, repography, etc.). Reverse-engineers the platform's scoring formula, replays it locally with the user's real signals, runs counterfactual simulations to propose the highest-leverage improvements. Use when a user asks "why did my X score go down" or "how do I raise my X rating".
version: 1.0.1
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [scoring, reverse-engineering, github-signals, counterfactual, diagnostics]
    last_updated: "2026-07-30"
---

# External Score Diagnosis

Class-level workflow for "why did my X score change, and how do I raise it?" tasks. The platform can be **any** service that scores a user from public signals (GitHub data, coding activity, language breadth, etc.) — gitfut, Wakatime, Codewars tier, repography, githut rankings, etc. The methodology is the same: clone source → extract formula → fetch real signals → replay → counterfactual.

## When to use

| User says | Trigger |
|---|---|
| "내 gitfut 점수가 71에서 69로 떨어졌어" | Yes |
| "Why did my Codewars kyu go from 4kyu to 5kyu?" | Yes |
| "How do I raise my Wakatime leaderboard rank?" | Yes |
| "What's my signal pattern on platform X?" | Yes |
| "Tell me my score on platform X" (no change) | Partial — fetch + report only, skip diagnosis |
| "Review the code of this scoring platform" | Adjacent — use `github-code-review` instead |

## The 5-step method

### 1. Identify the platform and the score's surface

Before touching code, locate the public formula. Search in this order:

1. **Source repo on GitHub** — almost every scoring platform is OSS. Check the site's footer, README, or About page for a repo link.
2. **Page source** — curl the user page, look for SSR'd numbers in the HTML body, or a `__NEXT_DATA__` / RSC payload.
3. **Public API** — `/api/u/<user>.json` or GraphQL endpoints; if they 404, the score is server-computed and the formula is in the source.
4. **Hover text / "How it works" modal** — sometimes the platform itself explains the weighting.

**Diagnostic tell**: if the SSR HTML shows the score, the formula is in the source. If the page renders empty until JS runs, the formula still lives in the source — it just hydrates client-side. Either way, **clone the repo**.

### 2. Clone the scoring repo and read the formula

```bash
git clone --depth 1 https://github.com/<owner>/<scoring-platform>.git /tmp/<platform>
ls /tmp/<platform>/lib   # or src/
```

Look for files named `engine`, `scoring`, `score`, `formula`, `weight`. Scoring engines typically have:
- A `rawStats(signal) → 6 stats` mapping (log/sqrt scaled)
- A `center(signal) → gravity` (sigmoid around magnitude)
- A `zscore(stats) → profile` (per-stat deviation from own mean)
- A `tension(profile) → profile` (penalise antagonist pairs)
- A `spike(profile, center) → stats` (final card stats)
- A `weightedOVR(stats, family) → number` (position-weighted overall)
- A `legacyScore(signal) → 0..1` (years + sustained influence)
- A `clamp(baseOVR + round(bonusMax · L), 1, 99)` final step

**Read the constants file too** — usually named `constants.ts`, `weights.ts`, or `k.ts`. The numeric weights, caps, and finish thresholds are the levers.

### 3. Fetch the user's real signals

Identify what input fields the formula reads. For gitfut, the inputs were:
- `followers`, `public_repos`, `total_stars_owned`, `max_repo_stars`
- `recent_contributions` (last 365d commits+PRs+reviews+issues+private)
- `total_contributions_lifetime`, `active_years`, `account_age_years`
- `languages` (deduped set of repo primary languages)
- `reviews`, `issues_closed`, `prs_to_others`

**Get them from the canonical source, not the platform's API.** The platform's own score is one snapshot; the underlying signal is the ground truth and is what the formula reads. For GitHub: use `gh api graphql` (or `gh api` REST) to pull the same fields the platform's GitHub client pulls.

**⚠️ Pitfall — `gh api graphql` integer-literal bug (2026-07-24)**: `gh api graphql` parses `-F key=value` pairs as headers. A GraphQL argument that is an **integer literal** (e.g. `maxRepositories: 100`, `first: 100`) gets misread as a header `100: <next token>` and GraphQL returns `Expected NAME, actual: INT`. Workarounds:

- ✅ Pass the query through a file: `-f query=@/tmp/query.gql` or `-f query="$(cat /tmp/query.gql)"` (the entire query as one string, then `-F` for variables)
- ✅ Replace integer literals with variables: `maxRepositories: $maxRepos` and pass `-F maxRepos=100` (numeric vars parse correctly)
- ❌ Do not inline `maxRepositories: 100` directly in a `-f query="..."` argument

**Pitfall — JSON escaping on the command line**: prefer writing the GraphQL to a file and `cat`ing it, or use Python's `urllib`/`requests` with a real JSON body. Building GraphQL queries through shell `""` quoting is a recursive quoting trap.

### 4. Replay the formula locally

Port the scoring engine to a standalone script. The point is to **make it parameterizable** so you can mutate one signal at a time. For gitfut:

```js
// mirrors lib/scoring/engine.ts exactly
const Lg = x => Math.log10(Math.max(0, x) + 1);
const sigmoid = z => 1 / (1 + Math.exp(-z));
// ... copy rawStats, center, zscore, applyTension, spike, weightedOVR, legacyScore
```

Sanity-check by replaying the user's **current** signals: you must reproduce the **exact** stat values and overall that the platform shows (e.g. PAC 76, DRI 80, SHO 65, DEF 51, PAS 62, PHY 72, OVR 69). If your replay produces a different number, you missed a field or applied a different formula version.

**Common drift sources**:
- Lifetime contribution windows sliced differently (the platform may use `<=` not `<`)
- `active_years` formula may include createdAt year vs pushedAt year vs both
- `recent_contributions` may exclude one of {commits, PRs, reviews, issues, restricted}
- `Math.round()` vs `Math.floor()` on `bonusMax·L` causes ±1 swings — this is often the entire "score dropped by 1" mystery

### 5. Run counterfactuals

For each top signal, mutate it to a plausible higher value and record the new OVR. **Rank by ΔOVR / effort**:

| Perturbation | Effort | Typical ΔOVR (gitfut-class) |
|---|---|---|
| `total_stars_owned` × 10 | medium (자력, 시간 누적) | +5 to +12 (log curve) |
| `max_repo_stars` 2 → 200 (1 viral repo) | high (자력, 콘텐츠/노출) | +3 to +7 |
| `active_years` +1 | **봉쇄** — `pushedAt`은 서버측 검증, commit date 위조 불가 | +3 to +7 (이론치) |
| `followers` × 3 | low (자력, 콘텐츠 발행 자동화 가능) | +1 to +3 |
| `recent_contributions` +30% | medium (자력, 자동 누적) | +1 to +2 |
| `recent_spike` true로 토글 | high (1주 burst 활동) | 0~+1 (in-form 등급 보너스) |
| `lifetime_contributions` × 4 | high (자력, 장기 누적) | +1 to +2 |
| `prs_to_others` 0 → 50 | **봉쇄** — 시스템 토큰 자동 푸시 불가, 메인테이너 merge 거부 패턴 | +1 to +2 (이론치) |
| `reviews` × 60 | low (자력, 본인 OSS 인입 PR 응답) | 0 to +1 (log saturates if already >10) |
| `languages` +1 to +3 | low (자력, 새 언어 repo) | 0 to +1 (sqrt saturates) |

**`Effort` 컬럼은 사용자에게 정직하게 보고하기 위한 라벨입니다**:
- `low / medium / high (자력)` — 사용자가 실제 행동으로 만들 수 있는 변화
- `medium (자력, 자동화 가능)` — cron / Kanban 카드 / 콘텐츠 자동화로 외부 작업 없이 누적
- `high (자력, 콘텐츠/노출)` — 사용자가 의도적으로 만들어야 함 (별 받는 메가-히트 repo 등)
- **`봉쇄`** — 공식에는 있지만 자력으로는 만들 수 없는 변화. 사용자가 "진행해줘" 요청할 때 실행 가능하다는 듯이 답하지 말 것. (자세한 봉쇄 이유: §Pitfalls #8, #9)

**Always print the saturating-curve insight**: log and sqrt curves mean **one viral repo is worth more than 100 small ones**. Tell the user this, don't just print numbers.

## Output format

The user wants an answer, not a 4-page report. Use this shape:

1. **하락 원인 (1-3문장 + 불릿)** — root cause + supporting signals
2. **공식 검증** — "당신 카드 stat은 현재 PAC 76 / DRI 80 / SHO 65 / DEF 51 / PAS 62 / PHY 72 / OVR 69 (CAM, SILVER, Fantasista)" — proof the replay matches
3. **상승책 표** — effort × impact ranking. 봉쇄된 시그널은 명시적으로 봉쇄 라벨을 달아라 (§Pitfalls #8, #9, #10 참고)
4. **최우선 1-2개 액션** — "별을 받는 메가-히트 레포 1개 만들기가 +5~+7 OVR의 가장 직접적 경로"
5. **(선택) 후속 자동화 제안** — only if natural (e.g. "원하시면 auto-researcher로 popular repo 자랑 thread 자동 생성해드릴까요?")

**언어 기본값**: 사용자가 한국어 사용자 (sigco 멤버)이면 모든 출력은 한국어로. `OCRs/Korean 조사 분리 proximity` 등 한국어 처리 함정은 `ad-hoc-verification-bash-heredoc-pitfall` 스킬 D18 참고.

## 영향 가능/불가능 매트릭스 + z-score tension 진단 (sigco3111 gitfut, 2026-07-30 실전 검증) ⭐

**Step 5 counterfactual 표를 보강하기 전, 반드시 두 가지 추가 분석을 한다.** 둘 다 z-score 기반 scoring engine에서 거의 항상 등장하는 패턴이지만, counterfactual 표만으로는 사용자에게 안 보이는 insight다.

### A. 영향 가능/불가능 매트릭스 (12개 시그널 × 3 카테고리)

counterfactual을 돌리기 **전에** 12개 입력 시그널을 3분류로 라벨링한다. **외생 시그널**(외부 사용자/시스템이 결정) vs **내생 시그널**(사용자가 자력으로 만들 수 있음) vs **봉쇄**(公式에는 있지만 자력 변경 불가).

| 시그널 | 영향 분류 | 이유 | counterfactual ΔOVR |
|---|:-:|---|---|
| `stars earned` (lifetime) | ⚠️ 외생 | 다른 사람이 별을 줘야 함 | — |
| `top repo reach` | ❌ 외생 | 단일 레포 별 수 = 다른 사람의 결정 | — |
| `account age` | ❌ 외생 | 시간 | — |
| `active years` | ❌ 외생/봉쇄 | 서버측 `pushedAt` 검증 (§Pitfall #8) | — |
| `followers` | ⚠️ 외생/혼합 | 본인 발행 콘텐츠 + 타인 호감 = 부분 통제 | +1~+3 |
| `commits` | ✅ 내생 | 본인 활동 | +1~+2 |
| `pull requests` (to others) | ✅ 내생 (봉쇄) | §Pitfall #9 — 자동 푸시 봉쇄, 손으로만 가능 | +1~+2 |
| `code reviews` | ✅ 내생 | 본인 OSS 인입 PR 응답 | 0~+1 |
| `issues` | ✅ 내생 | 다른 프로젝트에 issue 제기/관리 | +0~+1 |
| `contributions` | ✅ 내생 | 위 4종 합 — 자연 누적 | +1~+2 |
| `languages` | ✅ 내생 (포화) | 새 언어 repo — sqrt 포화 주의 | 0~+1 |
| `active days` | ✅ 내생 | 올해 며칠이나 활동했나 | +0~+1 |

**판별 신호 (z-score 엔진 한정)**:
- ✅ 4~6개 (commits / PRs / reviews / contributions / active days / languages) → 내생
- ⚠️ 2개 (stars earned / followers) → 외생/혼합
- ❌ 4개 (top repo reach / account age / active years / 봉쇄 시그널) → 외생 또는 봉쇄

**사용자 보고 형식**: 매트릭스 표 + "이 중 영향 가능한 6개로만 로드맵을 그립니다" 명시. 외생/봉쇄를 모호하게 묶어 "노력하면 됩니다"라고 하면 사용자 시간 낭비.

### B. z-score tension 페널티 = "약한 스탯 하나가 모든 것을 깎는다"

z-score 기반 엔진(공식이 **자기 자신의 stat들 사이의 편차**로 점수 매기는 경우)은 거의 항상 tension 페널티를 가진다:

- z-score: 각 stat을 자기 자신의 평균에서 얼마나 떨어져 있는지로 정규화
- tension 페널티: 강한 stat 옆 약한 stat이 균형을 깎아 **"모두 강함"**이 보장되지 않으면 OVR이 깎임
- 결과: **가장 약한 stat이 OVR 상한을 잠근다**. 1개 stat을 올리면 4-5개 stat이 동시 부양 (tension 완화)

**진단 절차 (Step 4 replay 직후, Step 5 counterfactual 전에 수행)**:

1. **z-score 함수 위치 확인** — `lib/scoring/engine.ts`에 `applyTension()` 또는 `tension(profile)` 함수. sigmoid/penalty 형태.
2. **사용자 6개 stat의 평균 계산** — `mean = (76+64+67+81+47+71)/6 = 67.7`
3. **가장 약한 stat 식별** — 평균 대비 가장 큰 음수 편차인 stat
4. **공식 검증 — 약한 stat만 +10 올린 카운터펙추얼**: 다른 stat 동시 +5~10 부양 (tension 해소 효과)
5. **사용자에게 보고**: *"약한 stat X가 OVR 상한을 잠그고 있어요. +15 올리면 OVR +8~12 효과"*

**sigco3111 gitfut 실전 검증 (2026-07-30)**:
- 카드 stat: PAC 76 / SHO 64 / PAS 67 / DRI 81 / **DEF 47** / PHY 71 → OVR 70
- DEF가 평균 -20.7pt로 최대 음수 편차 → SHO 64 / PAS 67을 tension 페널티로 끌어내림
- 시뮬레이션: DEF 47 → 70 (+23)으로 올리면 SHO/PAS 5~10pt 부양 + DEF 단독 +25 → **OVR +8~12**
- 결론: **"리뷰 1주일에 한 번만 보내도 6개월 후 Gold 진입"** (정확한 진단)

**z-score tension이 없는 엔진 (예: 단순 가산/평균 모델)에서는 B 절차를 skip** — Codewars/워카타임의 단순 합산 모델은 해당 없음. Step 1에서 엔진 종류 먼저 확인.

### C. 두 분석을 합친 보고 순서

Step 5 counterfactual 표를 보고하기 **전에** A → B 순서로 한 단락씩 먼저:

```
[영향 가능/불가능 매트릭스]
- ✅ 내생 6개: commits, PRs (to others), reviews, issues, contributions, active days
- ⚠️ 외생/혼합 2개: stars earned, followers
- ❌ 봉쇄/외생 4개: top repo reach, account age, active years, 자동 PR

[z-score tension 진단]
- 가장 약한 stat: DEF 47 (평균 -20.7pt 편차, OVR 상한 잠금)
- DEF 47 → 70 시뮬레이션: SHO/PAS +5~10pt 부양 + DEF 단독 +25 → OVR +8~12
- 결론: 리뷰 활동 1주일에 1회만 늘려도 6개월 내 Gold 진입 (75+)
```

이 두 단락을 **먼저** 보여주면, 뒤따르는 counterfactual 표의 effort 라벨 사용자가 안 읽고도 직관적으로 받아들임.

### Anti-patterns (이 분석의 함정)

- **외생/내생 구분 누락**: 모든 시그널을 "노력하면 됩니다"로 뭉뚱그리면 사용자가 봉쇄 시그널에 시간 낭비 (§Pitfall #10과 같은 함정).
- **z-score tension 무시**: stat별 단순 평균만 보고 "DEF를 올리세요" → DEF만 올려도 SHO/PAS가 따라오지 않으면 사용자 "왜 안 올라가지?" 반복.
- **A → B 순서 역전**: counterfactual 표 먼저 보여주면 사용자가 effort 라벨에 매몰되어 z-score tension 통찰을 못 봄.
- **tension 페널티 없는 엔진에 적용**: 단순 합산 모델 (예: Codewars kyu)에서 "약한 stat이 모두 깎는다"고 하면 거짓말.

**Anti-patterns**:
- Do not give a 4-table, 30-line report for what is fundamentally a "ΔOVR per signal" question
- Do not invent numbers — if you can't reach the platform, say so
- Do not promise exact "you'll get +5 if you do X" — log/sigmoid means ranges, not points
- Do not say "the formula weights this signal heavily" without showing the actual weight from the constants file
- **Do not pretend 봉쇄된 시그널을 만들 수 있는 것처럼 다음 단계를 제시** — `active_years` 분포 / `prs_to_others` 자동 푸시 같은 봉쇄 시그널은 사용자가 "진행해줘"라고 해도 정직하게 봉쇄를 알리고 대안 (외부 PR 본문 초안, 활동 분포 자동화 가능한 시그널 등) 을 함께 제시할 것

## Pitfalls (consolidated)

1. **`gh api graphql` integer-literal bug** — see §3. Use `-f query=@file` or variables.
2. **Replay drift** — if your local replay doesn't match the platform's displayed stat, you missed a field. Check `active_years` (Set of years from createdAt+pushedAt) and the lifetime contribution window slicing.
3. **Math.round vs Math.floor** on the legacy bonus — accounts for ±1 OVR swings that look like "the platform changed the algorithm" but is just boundary noise.
4. **recent_spike toggle** — many platforms have a "in-form" or "trending" tier that flips on/off around a threshold. False↔True transitions can drop a tier or finish level even when the OVR is unchanged. Check the finish/tier derivation logic explicitly.
5. **SSR HTML vs hydration** — many SPA-style scoring pages show empty divs in the initial HTML and hydrate client-side. Don't conclude "no score in the source" — clone the JS bundle or the source repo.
6. **Languages saturation** — `sqrt(languages)` and `Lg(languages)` saturate fast. Adding a 12th language gives ~0 OVR. Do not recommend "add more languages" without checking the curve.
7. **Counterfactual honesty** — the perturbation is a thought experiment. If the user can't realistically get 2,000 stars in a week, say "+12 OVR is theoretical ceiling; in practice +3–5 in a month is realistic if you ship a viral repo."
8. **`active_years` cannot be self-distributed via commit-date spoofing (2026-07-24, sigco3111 gitfut case)** — A counterfactual showing "push any repo in year X for +7 OVR" looks like a free lever, but the platform reads `repo.pushedAt` as the **server-attributed push time**, not the commit author date. `GIT_AUTHOR_DATE=2023-01-01 git commit` followed by a normal push is **rejected or rewritten by GitHub on push** — the server cross-checks commit hash against the author date and either rejects hard or silently coerces the timestamp to push time. There is no stable path to forge a backdated `pushedAt`. Practical consequence: if the user's `active_years` distribution comes from new repos only (years = createdAt years), the gap between account age and active years is **structural** and cannot be closed by self-action. State this honestly in the report — do not propose a "+7 OVR with one push" plan without flagging that it doesn't actually work.
9. **External `prs_to_others` cannot be automated from a system OAuth token (2026-07-24, sigco3111 gitfut case)** — A user will sometimes ask "if I widen the GitHub token scope, can you auto-PR to other repos?" The answer is no, and not because of token scope. The block is layered:
   - **Bot detection**: GitHub's user-OAuth token pushing to >1 unrelated external org within a short window triggers rate limit + captcha + account verification. The Hermes/ICBM2 system token's owner is the system account, not the user — `git config` author mismatch is visible in the commit.
   - **Merge rejection**: even if the PR opens, automated no-content PRs ("add a docstring", "fix a typo") are typically closed by maintainers. The signal `prs_to_others` only counts **merged** PRs in some platforms; read the platform's source for the exact field. Merge rate for bot PRs is near zero, so the signal doesn't move.
   - **Rate limit**: 60/h on unauthenticated, 5000/h on authenticated, but a "fast PR across many orgs" pattern triggers secondary limits.
   - **Ethics**: even when technically possible, automated OSS PR sending on the user's behalf without per-PR human review damages the user's OSS reputation.
   Honest answer: external PRs are a **human-driven lever**. The agent can draft PR bodies, identify good-first-issue candidates, and run the formula replay to show the +1~+2 OVR ceiling, but cannot send the PRs.
10. **Distinguish "automatable" from "blocked" signals in the recommendation table** — the counterfactual table shows ΔOVR per perturbation, but every perturbation falls into one of three categories the table must label:
    - **Auto-bumps** (e.g. recent_contributions, lifetime_contributions, languages) — produced by normal activity; no specific action, just keep working.
    - **Self-targeted actions** (e.g. max_repo_stars via shipping one viral repo, recent_spike via a burst week, followers via content) — require user work but no external dependency.
    - **External / blocked** (e.g. active_years distribution, prs_to_others, reviews on third-party repos) — the lever exists in the formula but cannot be self-driven; mark as 봉쇄 in the table so the user doesn't waste effort.

## Related skills

- `github-cli` — for `gh api graphql`, `gh repo clone`, etc. The integer-literal pitfall lives there too.
- `auto-researcher` — if the user wants a broader multi-source research report rather than a single-platform diagnosis, this is the right call.
- `stock-market-pro` — same methodology (signals → formula → replay → counterfactual) for market data instead of reputation.

## Reference files

- `references/gitfut-formula-replay.md` — concrete worked example: signals extraction, formula port, replay match, counterfactual table for the sigco3111 case. Use as a template when you hit a new platform — the steps transfer, the field names don't.
- `templates/score-replay.js` — Node.js skeleton that ports a generic `engine.ts` to a parameterizable replay script. Drop in a platform's `rawStats`, `center`, `weightedOVR`, `legacyScore` and you have a counterfactual harness in 5 minutes.
