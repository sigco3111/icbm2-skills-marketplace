# fireToken TUI — 기존 도구에 TUI 추가 사례

> 2026-06-20 fireToken v0.2.0 (TUI) 부트스트랩 세션에서 검증된 사례.
> PowerShell only OSS에 Python Textual TUI를 추가하는 패턴.

## 🎯 핵심 아이디어

**기존 PowerShell 자산을 0% 삭제하지 않고 Python TUI를 덧 붙인다.**

PowerShell은 백그라운드 워커로 강등 — 토큰 소진 로직 유지.
TUI는 컨트롤러 — 실시간 모니터링 + 명령 전송.

**파일 시스템 IPC**로 두 언어를 잇는다 (HTTP IPC 대비 크로스플랫폼, 디버깅 쉬움, 표준 라이브러리만).

---

## 📂 PowerShell IPC 모듈 (7KB 추가)

`scripts/firetoken-ipc.ps1` 한 파일. 기존 `burn.ps1` / `burn-session.ps1`에서 dot-source로 로드.

**공개 API 4개 + 헬퍼 1개**:
- `Initialize-IpcDir` — 디렉토리 생성
- `Write-Event -Type -SessionId -Data` — JSONL append
- `Write-StateSnapshot -State` — 원자적 JSON 쓰기
- `Read-Command` — cmd.json 읽고 처리 후 ACK
- `New-SessionState` — 표준 세션 객체 생성 헬퍼

**IPC 디렉토리 우선순위**:
1. `$env:fireToken_IpcDir` (TUI가 명시)
2. `$LogDir/fireToken-ipc` (기본)

**TUI 없을 때 fallback** — `if (Test-Path $ipcModule) { . $ipcModule } else { /* silent */ }`. 기존 PowerShell은 100% 정상 동작 유지.

---

## 🔄 PowerShell ↔ Python IPC 프로토콜

```
<ipc_dir>/
├── state-s1.json         # 세션 1 스냅샷 (TUI가 1초마다 폴링)
├── state-s2.json         # 세션 2 스냅샷
├── state-s3.json         # 세션 3 스냅샷
├── state-s4.json         # 세션 4 스냅샷
├── state-s5.json         # 세션 5 스냅샷
├── events.jsonl          # append-only 이벤트 로그 (TUI가 tail)
├── cmd.json              # TUI → PowerShell 명령 (원자적 쓰기)
└── cmd.ack.json          # PowerShell → TUI ACK (처리 확인)
```

### state-s{ID}.json (스냅샷)

세션 메인 루프에서 매 round마다 덮어쓰기. JSON 한 줄.

```json
{
  "session_id": 1,
  "pid": 12345,
  "status": "running",
  "round": 42,
  "total_tokens": 3847291,
  "last_round_tokens": 12847,
  "input_tokens": 2103,
  "output_tokens": 6820,
  "reasoning_tokens": 3924,
  "context_tokens": 64235,
  "error_count": 0,
  "reasoning_effort": "high",
  "context_policy": "slide",
  "messages_count": 9,
  "updated_at": "2026-06-20T14:23:45.123Z"
}
```

**원자적 쓰기 (Windows)**:
```powershell
$tmpFile = "$($script:StateFile).tmp"
Set-Content -Path $tmpFile -Value $json -Encoding UTF8 -NoNewline
Move-Item -Path $tmpFile -Destination $script:StateFile -Force
```

### events.jsonl (append-only)

각 이벤트 = JSON 한 줄 + newline. TUI는 byte offset 추적.

```json
{"ts":"2026-06-20T14:23:45.123Z","type":"round","sid":"s1","data":{"round":42,"tokens":12847,...}}
{"ts":"2026-06-20T14:23:50.456Z","type":"error","sid":"s2","data":{"code":429,"msg":"rate limit"}}
{"ts":"2026-06-20T14:24:01.789Z","type":"context_action","sid":"s1","data":{"action":"slide","tokens":102000}}
```

이벤트 타입 8종: `orchestrator_start`, `orchestrator_stop`, `session_start`, `session_stop`, `round`, `error`, `strategy_switch`, `context_action`.

### cmd.json (TUI → PowerShell)

TUI가 원자적으로 쓰고, PowerShell이 1초마다 폴링 + 처리 후 파일 삭제.

```json
{
  "id": "tui-3-a1b2c3d4",
  "action": "stop",
  "value": null,
  "ts": 1740000000.0
}
```

**액션 4종**: `stop`, `switch_reasoning`, `switch_policy`, `add_session`.

### cmd.ack.json (PowerShell → TUI)

PowerShell이 cmd 처리 후 작성. TUI가 최대 3초 폴링.

```json
{
  "id": "tui-3-a1b2c3d4",
  "ts": "2026-06-20T14:25:00.000Z",
  "ok": true,
  "action": "stop"
}
```

---

## 🐍 Python TUI 패키지 (8개 파일, ~30KB)

```
tui/firetoken_tui/
├── __init__.py
├── app.py               # main() + FireTokenApp (Textual)
├── ipc/
│   ├── __init__.py
│   ├── backend.py       # Backend Protocol + SessionState + Event + CommandResult
│   ├── fs_backend.py    # FileSystemBackend (실제 PowerShell)
│   └── mock_backend.py  # MockBackend (macOS/Linux 개발용)
└── widgets/
    ├── __init__.py
    ├── summary_panel.py
    ├── session_table.py
    └── event_log.py
```

### Backend Protocol (핵심 추상화)

```python
class Backend(abc.ABC):
    @abc.abstractmethod
    def get_session(self, session_id: int) -> SessionState | None: ...
    @abc.abstractmethod
    def list_sessions(self) -> dict[int, SessionState]: ...
    @abc.abstractmethod
    def tail_events(self, since_byte: int = 0) -> tuple[list[Event], int]: ...
    @abc.abstractmethod
    def send_command(self, action: str, value: str | None = None) -> CommandResult: ...
    @abc.abstractmethod
    def is_connected(self) -> bool: ...
    @abc.abstractmethod
    def ipc_dir(self) -> str: ...
```

**TUI는 Backend만 의존**. FileSystemBackend ↔ MockBackend 전환 자유.

### MockBackend (개발용)

macOS/Linux에서 Windows + PowerShell 없이 TUI를 개발/테스트할 수 있는 인메모리 백엔드:

- 5세션 기본 시작
- 매 초마다 토큰 증가 (3K~8K 베이스 + reasoning_effort 곱)
- 5% 확률로 에러 발생 (모의)
- 8라운드마다 context_action 이벤트
- `stop` / `switch_reasoning` / `switch_policy` / `add_session` 명령 처리
- 백그라운드 `threading.Thread`로 시뮬레이션

**사용법**:
```bash
ftui --mock
# 또는
python -m firetoken_tui --mock
```

### Textual App

```python
class FireTokenApp(App):
    CSS_PATH = "app.tcss"
    BINDINGS = [
        Binding("q", "quit", "Quit"),
        Binding("s", "stop_all", "Stop all"),
        Binding("a", "add_session", "Add session"),
        Binding("r", "cycle_reasoning", "Switch reasoning"),
        Binding("p", "cycle_policy", "Switch policy"),
        Binding("c", "clear_log", "Clear log"),
    ]

    def compose(self) -> ComposeResult:
        yield Header()
        with Vertical():
            yield SummaryPanel()
            with Horizontal():
                yield SessionTable()
                yield EventLog()
        yield Footer()

    async def on_mount(self) -> None:
        self._events_offset = 0
        self._started_at = datetime.now()
        self.summary_panel.started_at = self._started_at
        self.summary_panel.ipc_dir = self.backend.ipc_dir()
        self.summary_panel.is_connected = self.backend.is_connected()
        # 1초마다 refresh
        self.set_interval(1.0, self._refresh_from_backend)
```

**레이아웃 결정**:
- Header (고정) → Vertical { SummaryPanel (3줄) / Horizontal { SessionTable (좌, 70%) / EventLog (우, 30%) } } → Footer (키바인딩)
- SessionTable: DataTable with zebra stripes + cursor_type="row"
- EventLog: RichLog with max_lines=2000

---

## ⚠️ 함정 5가지 (TUI 추가 신규)

### 1. 원자적 쓰기 안 하면 파일 race

PowerShell이 state.json 쓰는 중 (1ms 소요) TUI가 읽으면 **JSON 파싱 실패** → SessionState None 반환.

**해결 — PowerShell**:
```powershell
$tmpFile = "$($script:StateFile).tmp"
Set-Content -Path $tmpFile -Value $json -Encoding UTF8 -NoNewline
Move-Item -Path $tmpFile -Destination $script:StateFile -Force
```

**해결 — Python**:
```python
with tempfile.NamedTemporaryFile(mode="w", delete=False, dir=ipc_dir, suffix=".tmp") as tmp:
    json.dump(cmd, tmp)
    tmp_path = tmp.name
os.replace(tmp_path, cmd_path)
```

### 2. 이벤트 tail offset

`events.jsonl`이 rotated/truncated되면 `stat().st_size < since_byte`. **자동 reset to 0** 필수.

```python
def tail_events(self, since_byte: int = 0) -> tuple[list[Event], int]:
    size = path.stat().st_size
    if size < since_byte:
        since_byte = 0  # rotated, reset
    ...
```

**주의**: 예외 무시 X. 명시적 reset이 디버깅 쉬움. `tail -F` (GNU coreutils)의 기본 동작과 동일.

### 3. ACK 폴링 timeout

PowerShell이 응답 안 해도 TUI가 무한 대기하면 안 됨. **3초 timeout + pending=True** 반환.

```python
deadline = time.time() + 3.0
while time.time() < deadline:
    if ack_path.exists():
        # process ACK
        return CommandResult(ok=True, action=action, ack=ack)
    time.sleep(0.1)
return CommandResult(ok=True, action=action, ack={"pending": True, ...})
```

TUI는 "명령 큐에 들어감 (ACK 미수신)" 메시지 표시.

### 4. PowerShell `Get-Command` 가드

IPC 모듈이 로드 안 된 환경(예: .env 잘못 설정, ipc 모듈 파일 누락)에서도 기존 PowerShell은 동작해야 함.

**해결**:
```powershell
if (Get-Command Write-Event -ErrorAction SilentlyContinue) {
    Write-Event -Type "round" -SessionId "s$SessionId" -Data @{...}
}
```

`Get-Command` 자체가 실패하면 silent continue, 그 다음 조건문은 false → TUI IPC 없이 기존 로직 정상.

### 5. Textual reactive + render() vs watch_

Textual은 2가지 패턴:
- **A. `reactive` 속성 + `render()`** — 단순 polling, 디버깅 쉬움. **처음에는 A 추천**.
- **B. `@on(Event)` 핸들러 + `watch_<속성>` 메서드** — 비동기 이벤트 기반, 더 우아하나 학습 곡선 있음.

```python
class SummaryPanel(Widget):
    total_tokens: reactive[int] = reactive(0)
    tokens_per_sec: reactive[float] = reactive(0.0)

    def render(self) -> Text:
        # reactive 속성으로 Text 빌드
        return Text(...)
```

**A의 함정**: `time.sleep()` 사용은 Textual 이벤트 루프 블로킹. **`asyncio.sleep` 또는 `set_interval` Worker** 사용. Worker는 별도 스레드/태스크에서 실행되므로 메인 루프 영향 X.

```python
async def _refresh_from_backend(self) -> None:
    sessions = self.backend.list_sessions()
    events, new_offset = self.backend.tail_events(self._events_offset)
    self._events_offset = new_offset
    # 위젯 업데이트 (UI 스레드)
    self.session_table.refresh_sessions(sessions)
    for ev in events:
        self.event_log.append_event(ev)
```

### 6. **`threading.Lock()` vs `RLock()` — 워커 + emit 재진입 데드락** (2026-06-20)

백그라운드 워커 스레드가 `with self._lock:` 안에서 같은 lock을 다시 획득하는 메서드(예: `_emit_event`)를 호출하면 **데드락 + pytest hang**. **증상**: `python -m pytest tests/test_backend.py`가 traceback 없이 hang. 메인 스레드(`send_command`)가 `with self._lock` 대기, 워커는 같은 락에서 재진입 대기.

**해결**:
```python
# ❌ 일반 Lock — 데드락
self._lock = threading.Lock()

# ✅ RLock — 재진입 가능
self._lock = threading.RLock()
```

**진단**:
```python
import faulthandler
faulthandler.dump_traceback_later(timeout=5, repeat=False)
# + 단계별 print(..., flush=True)로 멈춘 위치 특정
```

**재사용**: 백그라운드 워커 + 중간 emit 메서드, Producer/Consumer + 재귀 lock, mock 워커 thread 기반 백엔드.

### 7. **Textual DataTable DuplicateKey race** (2026-06-20)

Textual `DataTable`에 동적 row를 추가/갱신할 때 흔한 try/except 패턴이 만드는 함정:

```python
# ❌ 위험한 패턴
def refresh_sessions(self, sessions):
    for sid, s in sessions.items():
        row_key = f"s{sid}"
        try:
            self.update_cell(row_key, "Status", ...)  # row 없으면 KeyError
        except Exception:
            self.add_row(*cells, key=row_key)  # 첫 refresh는 OK
```

**증상**:
- 첫 refresh: row 추가 성공
- 두 번째 refresh: update_cell 성공
- 그러나 어떤 시점에 update_cell이 **silent fail** (columns 안정화 전, key 오타)
- 그 다음 refresh에서 add_row가 **DuplicateKey** → TUI 죽음

**원인**: Textual `DataTable`은 row 존재 여부 직접 확인 메서드 없음. `try/except` 패턴이 silent fail을 가려서 진단 어렵게 만듦.

**해결 패턴 — 외부 dict로 row 추적**:
```python
class SessionTable(DataTable):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._last_states: dict[int, SessionState] = {}

    def refresh_sessions(self, sessions: dict[int, SessionState]) -> None:
        for sid in set(self._last_states.keys()) - set(sessions.keys()):
            try:
                self.remove_row(f"s{sid}")
            except Exception:
                pass

        for sid, s in sorted(sessions.items()):
            row_key = f"s{sid}"
            cells = (Text(...), ...)
            if row_key not in self._last_states:
                try:
                    self.add_row(*cells, key=row_key)
                except Exception:
                    pass  # race: 다른 tick이 이미 추가함
            else:
                col_keys = list(self.columns.keys())
                for col_key, cell in zip(col_keys, cells):
                    try:
                        self.update_cell(row_key, col_key, cell)
                    except Exception:
                        pass

        self._last_states = dict(sessions)
```

**원칙**:
- row/key 존재 여부 추적은 **위젯 외부 dict**에서 (DataTable 내장 의존 X)
- add_row의 DuplicateKey는 try/except로 안전 catch
- update_cell의 모든 예외는 try/except로 catch
- silent fail 절대 금지: try/except 후 logging 또는 counter

**재사용**: Textual `DataTable`로 동적 row를 polling으로 갱신하는 모든 TUI.

---

## 🔄 워크플로 — macOS에서 TUI 개발 → Windows에서 실행

1. **macOS (집)**: `python -m firetoken_tui --mock` → 5세션 시뮬레이션으로 레이아웃/위젯/키바인딩 검증
2. **Windows (회사/Windows PC)**: PowerShell로 `burn.ps1` 시작 → 별도 터미널에서 `ftui --ipc <dir>` → 실시간 모니터링 + 제어
3. **macOS에서 Windows PC의 burn 프로세스를 SSH + TUI로 모니터링**: SSH로 Windows PC 접속 → `pwsh -File burn.ps1` 시작 (백그라운드) → 동일한 macOS 세션에서 `ftui --ipc <remote_ipc_dir>` (NFS/SMB 공유 시)

---

## 📊 변경 요약 (fireToken v0.1.0 → v0.2.0)

| 영역 | 변경 |
|---|---|
| 신규 Python 파일 | 8개 (~30KB) |
| 신규 PowerShell 파일 | 1개 (7KB, firetoken-ipc.ps1) |
| 기존 PowerShell 변경 | burn.ps1 (32줄 추가) / burn-session.ps1 (50줄 추가) |
| 기존 PowerShell 삭제 | 0줄 |
| 의존성 | `textual>=0.80`, `rich>=13.0` 2개 |
| Python 표준 의존 | argparse, dataclass, json, pathlib, threading, time, uuid |
| pyproject.toml | 신규 (hatchling 백엔드) |
| CLI 엔트리포인트 | `ftui = "firetoken_tui.app:main"` |
| 소요 시간 | ~20분 (기존 OSS 확장이라 신규 부트스트랩보다 빠름) |

---

## 🚀 즉시 사용법

```bash
# 1. 설치
cd ~/workspace/fireToken
python3 -m venv tui/venv
source tui/venv/bin/activate
pip install -e "./tui[dev]"

# 2. macOS/Linux에서 TUI 개발 모드 (PowerShell 불필요)
ftui --mock
# 또는
python -m firetoken_tui --mock

# 3. Windows에서 실전 모드
# PowerShell 한 터미널에서:
pwsh -ExecutionPolicy Bypass -File scripts/burn.ps1 -Sessions 5

# 다른 터미널에서:
ftui --ipc $env:TEMP/fireToken-ipc
# 또는
python -m firetoken_tui --ipc "$env:TEMP/fireToken-ipc"
```

**키바인딩**:
- `q` — 종료
- `s` — 모든 세션 stop
- `a` — 세션 추가
- `r` — reasoning effort 순환 (low → medium → high)
- `p` — context policy 순환 (slide → reset → warn → hard)
- `c` — 이벤트 로그 클리어

---

## 📜 검증된 사례

- **fireToken v0.2.0 (TUI)** (2026-06-20, sigco3111/fireToken 비공개)
  - 8개 Python 파일 + 1개 PowerShell IPC 모듈
  - macOS에서 MockBackend로 5세션 시뮬레이션 검증
  - PowerShell IPC 프로토콜 4종 (state, events, cmd, ack)
  - 사용자 "그대로 진행해" + 브레인스토밍 4개 결정 포인트 확정 후 즉시 실행

**재사용**:
- 다음 "기존 도구에 TUI 추가" 요청 시 이 문서 + SKILL.md의 "기존 도구에 TUI 추가 변형" 섹션 차용.
- "CLI가 잘 돌아가는데 모니터링 대시보드가 없어서 불편" 류 요청의 표준 응답.
