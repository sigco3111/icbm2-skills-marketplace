# Read-Only TUI Monitor Case Study (xmrig-dashboard v0.1.0)

> xmrig-dashboard v0.1.0 (2026-06-24, sigco3111/xmrig-dashboard) — Python 489 lines + 1 launcher script + 4 docs (`README`/`LICENSE`/`.gitignore`/`.plist.example`).
> **11번째 Phase 1 변형 사례** — 처음부터 TUI로 시작하는 "읽기 전용 + pause/resume" 대시보드 + **OSS 부트스트랩 전 보안 점검 워크플로** 4대 영역.
> 본 문서는 "외부 도구 로그를 읽어 TUI로 보여주기" 류 OSS (모니터링, 대시보드, 시각화) 부트스트랩 시 표준 참조.

## 1. 트리거 조건

다음 중 하나라도 해당되면 본 변형 + references 적용:

- "TUI 대시보드 만들어줘" + "기존 도구 있음" 명시
- "외부 도구 (XMRig, kmsg, AWS CLI, kakao-mcp, Docker 등) 로그/상태를 실시간으로 보고 싶음"
- "모니터링", "대시보드", "시각화" 류 요청
- 부트스트랩 시점에 **개인 식별 정보 (지갑, API 키, 사용자 경로, 거래소) 하드코딩 위험** 존재

## 2. fireToken-TUI 변형과의 차이

| 항목 | fireToken-TUI (v0.2.0) | xmrig-dashboard (v0.1.0) |
|---|---|---|
| **시작점** | 기존 OSS (PowerShell fireToken) + TUI 추가 | 처음부터 TUI로 부트스트랩 |
| **통신 방향** | 양방향 (PowerShell ↔ Python IPC) | 단방향 (외부 로그 읽기 + `pkill` 명령만) |
| **런타임 의존성** | `textual + rich` (2개) | `textual + psutil` (2개) |
| **IPC** | PowerShell IPC 모듈 (state.json + events.jsonl + cmd.json) | 없음 (외부 도구 로그 파일 직접 tail) |
| **명령 송신** | cmd.json + ACK 폴링 | `pkill -STOP/-CONT` (SIGSTOP/SIGCONT, no IPC) |
| **백엔드 추상화** | Backend Protocol + FileSystem/Mock 듀얼 | 없음 (외부 도구 1개) |
| **보안 점검** | PowerShell PS1 파일에 secret 없음 확인 | **4대 영역 (PII/지갑/절대경로/거래소) grep 필수** |

→ 둘 다 "기존 도구 + TUI" 카테고리. **fireToken-TUI가 v0.1 → v0.2 업그레이드**라면, **xmrig-dashboard가 처음부터 TUI로 부트스트랩**. 워크플로 자체는 동일 (브레인스토밍 → 환경 → 코드 → 비대화형 디버깅 → README → push) 이지만 **부트스트랩 전 보안 점검 단계**가 xmrig-dashboard만의 차별점.

## 3. 9단계 레시피

### 1단계: 브레인스토밍 (결정 포인트 3개 + 추천)

| 결정 포인트 | 옵션 A | 옵션 B | 옵션 C | 추천 |
|---|---|---|---|---|
| **TUI 범위** | 시뮬/대시보드만 (돈 안 됨) | **실제 데이터 + 대시보드** | 둘 다 | B (재미 + 실용성) |
| **TUI 라이브러리** | Rich + prompt_toolkit (수제) | **Textual (>= 6.2.1)** | curses | B (비동기 + 위젯 + DataTable) |
| **PII 처리** | 하드코딩 (사용자 본인만) | **config 동적 로드** | 환경변수 | B (config + env var fallback) |

xmrig-dashboard 사례: 채굴 의도(돈은 안 됨) + Textual 모던 + config 동적 로드 (xmrig-config.json에서 wallet/worker 자동 추출) 채택.

### 2단계: 환경 + 의존성 확인

```bash
# TTY 환경 확인 (TUI는 비대화형에서 hang)
# Python 3.8+ 필요
python3 --version

# 런타임 의존성 설치
python3 -m pip install --user textual psutil

# brew로 외부 도구 설치 (xmrig 예시)
brew install xmrig
which xmrig  # /usr/local/bin/xmrig 또는 /opt/homebrew/bin/xmrig

# xmrig config 사전 작성
cat > ~/xmrig-config.json <<'EOF'
{
  "autosave": true,
  "cpu": true,
  "pools": [
    {
      "url": "pool.supportxmr.com:5555",
      "user": "<your_monero_wallet_address_here>",
      "pass": "<your_worker_name>",
      "keepalive": true,
      "tls": false
    }
  ]
}
EOF
```

### 3단계: OSS 부트스트랩 전 보안 점검 (4대 영역) — **신규 단계**

이게 Phase 1의 **xmrig-dashboard 고유 단계**. 사용자 본인 PII/지갑/절대경로/거래소명 검색:

```bash
# 작업 디렉토리에서
cd ~/xmrig-dashboard

# 1) 지갑/주소 패턴 — 코인별 패턴 다름
# Monero: 95자, 4 또는 8 시작
# Ethereum: 0x + 40 hex chars
# Bitcoin: 1/3/bc1 시작
grep -rE "875D2GJL|4[A-Za-z0-9]{94}|0x[a-fA-F0-9]{40}|bc1[a-zA-HJ-NP-Z0-9]{25,39}" . --include="*.py" --include="*.md" --include="*.json"

# 2) 거래소명
grep -riE "kucoin|binance|bybit|upbit|bithumb|kraken|coinbase" . --include="*.py" --include="*.md"

# 3) 워커명/사용자명
grep -rE "heejeong_|shin_|hjshin" . --include="*.py" --include="*.md"

# 4) 절대경로
grep -rE "/Users/[a-z]+|/home/[a-z]+" . --include="*.py" --include="*.md"
```

**0건 확인 후 진행**. 발견 시:
- **지갑/워커**: config 동적 로드 (`load_xmrig_config(path)` 함수로 런타임 추출)
- **거래소명**: "your exchange subaddress" / "your exchange wallet" 일반화
- **절대경로**: `Path.home() / ".config/app-name"` 표준 + `os.environ.get("APP_CONFIG", ...)` env var
- **.gitignore**: `*.log`, `<app>-config.json` (외부 도구 설정), `.env` 등 PII 가능 파일 제외

### 4단계: 메인 코드 작성 (~500 lines)

**5개 표준 레이어**:

```python
# 1) Config 로딩 — PII는 런타임 추출
def load_xmrig_config(path: Path) -> dict:
    global WALLET, WORKER
    try:
        if not path.exists():
            return {}
        with path.open("r", encoding="utf-8") as f:
            data = json.load(f)
        pools = data.get("pools", [])
        if pools and isinstance(pools, list):
            first_pool = pools[0]
            if isinstance(first_pool, dict):
                user = first_pool.get("user", "").strip()
                worker_name = first_pool.get("pass", "").strip()
                if user: WALLET = user
                if worker_name: WORKER = worker_name
        return data
    except Exception:
        return {}

# 2) 외부 도구 로그 파서 (XMRig log regex)
def parse_xmrig_log(path: Path) -> dict:
    state = {k: (v.copy() if isinstance(v, deque) else v) for k, v in _DEFAULT_STATE.items()}
    if not path.exists():
        return state
    try:
        with path.open("rb") as f:
            f.seek(0, 2)
            size = f.tell()
            f.seek(max(0, size - 50_000))  # 마지막 50KB
            tail = f.read().decode("utf-8", errors="ignore")
        for line in tail.splitlines():
            state["recent_log"].append(line)
            # Hashrate, accepted, pool URL, threads regex
            ...
    except Exception as e:
        state["recent_log"].append(f"(parse error) {e}")
    return state

# 3) 시스템 메트릭 (psutil)
def get_system_metrics() -> dict:
    return {
        "cpu_pct": psutil.cpu_percent(interval=0.1),
        "mem_used_gb": psutil.virtual_memory().used / 1024**3,
        ...
    }

# 4) TUI 위젯 — 5~7개 패널
class HashratePanel(Static): ...  # hashrate 막대
class SystemPanel(Static): ...    # CPU/RAM/전력/업타임
class PoolPanel(Static): ...      # 풀 연결/블록/쓰레드
class EarningsPanel(Static): ...  # accepted/rejected/USD 환산
class LogPanel(Static): ...      # 최근 8줄 로그
class StatusBar(Static): ...     # 상단 한 줄 요약

# 5) App class + main()
class MinerDashboard(App):
    CSS = """..."""
    state = reactive({})
    
    def __init__(self):
        super().__init__()
        # 첫 render 안전: _DEFAULT_STATE로 pre-populate
        self.state = {
            "xmrig": {k: (v.copy() if isinstance(v, deque) else v) for k, v in _DEFAULT_STATE.items()},
            "system": {"cpu_pct": 0.0, ...},
        }
        self._last_price_fetch = 0
    
    def compose(self) -> ComposeResult:
        yield StatusBar()
        with Container(id="main"):
            yield HashratePanel()
            yield SystemPanel()
            # ... 5개 패널
            yield Static("Press q to quit | p pause | r resume", id="hint")
        # Footer/Header 빼기 (함정 34)
    
    def on_mount(self) -> None:
        self.set_interval(1.0 / REFRESH_HZ, self.refresh_metrics)
        self.set_interval(300.0, self.fetch_price)  # 5분마다 가격
    
    def refresh_metrics(self) -> None:
        self.state["xmrig"] = parse_xmrig_log(XMRIG_LOG)
        self.state["system"] = get_system_metrics()
        for w in self.query(Static):
            if w.id not in ("hint",):
                w.refresh()
        self.query_one(StatusBar).refresh()
    
    def action_pause(self) -> None:
        import subprocess
        subprocess.run(["pkill", "-STOP", "-f", "xmrig --config"], check=False)
        self.notify("Mining paused")
    
    BINDINGS = [
        ("p", "pause", "Pause"),
        ("r", "resume", "Resume"),
        ("q", "quit", "Quit"),
    ]

def main() -> None:
    load_xmrig_config(XMRIG_CONFIG)
    if not XMRIG_LOG.exists():
        print(f"WARNING: XMRig log not found at {XMRIG_LOG}")
    if not XMRIG_CONFIG.exists():
        print(f"WARNING: XMRig config not found at {XMRIG_CONFIG}")
    app = MinerDashboard()
    app.run()

if __name__ == "__main__":
    main()
```

### 5단계: TUI 비대화형 디버깅 (함정 35)

TUI는 TTY 필수. **background + stdout/stderr redirect + 수동 kill**:

```bash
# 5-1) 짧게 background로 띄워서 5~10초 후 캡처
/usr/local/bin/python3 /path/to/dashboard.py > /tmp/dash_test.log 2>&1 &
DASH_PID=$!
sleep 10
kill -9 $DASH_PID 2>/dev/null

# 5-2) 캡처된 출력에서 Traceback/Error/MarkupError grep
grep -iE "error|traceback|markup" /tmp/dash_test.log | head -5

# 5-3) 정상 종료 + 에러 0이면 TUI 컴포넌트는 OK
# 진짜 화면 확인은 실제 TTY (iTerm2, Terminal.app, Ghostty, Alacritty) 에서
```

### 6단계: .gitignore 작성

```gitignore
# Logs and runtime artifacts
*.log
*.pid
*.swp

# Python
__pycache__/
*.py[cod]
*.egg-info/
.eggs/
.pytest_cache/
.mypy_cache/
.ruff_cache/
build/
dist/
*.egg

# Virtual environments
venv/
.venv/
env/

# OS
.DS_Store
Thumbs.db

# Editor
.idea/
.vscode/
*.iml

# Secrets — never commit your actual app config
<app>-config.json  # ← 외부 도구 설정 (PII 포함 가능)
.env
.env.local
```

### 7단계: README (한/영 병기 + 다층 옵션)

fireToken-TUI/README 패턴 + 표준 경로/환경변수 가이드 추가:

```markdown
## Quick start

### 1. Install dependencies
python3 -m pip install --user textual psutil

### 2. Run
python3 miner-dashboard.py

기본 경로:
- 외부 도구 로그: ~/.xmrig/xmrig.log
- 외부 도구 설정: ~/.xmrig/xmrig-config.json

다른 경로에 있다면:
XMRIG_LOG=/path/to/xmrig.log XMRIG_CONFIG=/path/to/config.json python3 miner-dashboard.py

## Privacy
이 대시보드는 지갑 주소, 워커명, 기타 개인 데이터를 어디에도 전송하지 않습니다.
외부로 나가는 네트워크 호출은 오직 XMR/USD 가격을 위한 api.coingecko.com (5분 캐시)뿐.
지갑/워커는 런타임에 config에서 읽지, 코드에 하드코딩되지 않습니다.

## Limitations
이건 재미용이지 돈 버는 도구 아님. Intel Mac i5-8500B 6코어 hashrate ~1.2 KH/s,
예상 일일 채굴량 ~$0.04, 월 ~$1~$1.5, 전기세 ~$1~$2/월. **거의 본전도 안 나와요**.
```

### 8단계: .plist.example 작성 (선택, macOS LaunchAgent)

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!-- Example macOS LaunchAgent for running xmrig in the background. -->
<plist version="1.0">
<dict>
    <key>Label</key><string>com.local.xmrig</string>
    <key>ProgramArguments</key>
    <array>
        <string>/usr/local/bin/xmrig</string>
        <string>--config=/path/to/xmrig-config.json</string>
    </array>
    <key>RunAtLoad</key><true/>
    <key>KeepAlive</key><true/>
    <key>StandardOutPath</key><string>/path/to/xmrig.log</string>
    <key>StandardErrorPath</key><string>/path/to/xmrig.log</string>
    <key>ProcessType</key><string>Background</string>
</dict>
</plist>
```

→ **실제 plist는 `~/Library/LaunchAgents/com.local.xmrig.plist`에 두고 (절대경로 포함), git에는 안 올림**.

### 9단계: GitHub repo 생성 + 푸시

```bash
# 9-1) 보안 점검 grep 재실행 (3단계와 동일, 최종 확인)
grep -rE "<PII>" . --include="*.py" --include="*.md" --include="*.json"  # 0건

# 9-2) gh repo create
gh repo create sigco3111/xmrig-dashboard --public \
  --description "Real-time TUI dashboard for XMRig (Monero CPU miner) — live hashrate, system metrics, pool status" \
  --license MIT

# 9-3) 클론 + 파일 복사 + 커밋 + 푸시
cd ~ && rm -rf xmrig-dashboard
gh repo clone sigco3111/xmrig-dashboard
cp /path/to/miner-dashboard.py ~/xmrig-dashboard/
cp /path/to/README.md ~/xmrig-dashboard/
# ... LICENSE, .gitignore, .plist.example

cd ~/xmrig-dashboard
git add .
git commit -m "Initial release: XMRig TUI dashboard

- Real-time hashrate, system metrics, pool status
- Reads wallet/worker from xmrig-config.json (no hardcoded PII)
- CoinGecko XMR/USD price (5-min cache)
- Pause/resume XMRig with p/r keys
- Standard paths (~/.xmrig/) with env var override
- Bilingual README (EN/KR)
- MIT license"
git push -u origin main
```

## 4. ⚠️ 함정 7가지 상세

### 31. OSS 부트스트랩 전 PII/하드코딩 4대 영역 보안 점검 필수

`git push` 전 반드시 grep으로 검증. **잠재 PII 카테고리 4개**:

1. **지갑/주소** — Monero 95자 `4/8` 시작, Ethereum `0x` + 40 hex, Bitcoin `1/3/bc1` 시작 등
2. **거래소명** — KuCoin, Binance, Bybit, Upbit, Bithumb, Kraken, Coinbase
3. **워커명/사용자명** — 개인 식별 가능한 string (이름+용도+장소 등)
4. **절대경로** — `/Users/<name>/`, `/home/<name>/` 같은 OS-specific 사용자 경로

**해결 다층 방어**:
- **코드**: 하드코딩 → config 동적 로드 (`load_xmrig_config(path)` 함수로 런타임 추출)
- **경로**: 절대 → 표준 경로 `Path.home() / ".config/app-name"` + `os.environ.get("APP_CONFIG", ...)` env var
- **거래소명**: "your exchange subaddress" / "your exchange wallet" 일반화
- **.gitignore**: `*.log`, `<app>-config.json` (외부 도구 설정), `.env` 등 PII 가능 파일 제외

**검증 명령 (푸시 직전)**:
```bash
grep -rE "<PII-pattern>" . --include="*.py" --include="*.md" --include="*.json"
# 0건 확인 후 push
```

**재사용**: 모든 OSS 부트스트랩 시 자동 적용. **특히 외부 도구 (XMRig, kmsg, AWS CLI, kakao-mcp) 와 강하게 결합된 OSS**는 사용자별 설정이 코드에 새 들어갈 위험 100%. **kakao-summary 사례 (2026-06-16)** 에서도 동일 점검 필요했음 — 후회 패턴.

### 32. Textual TUI 첫 render에서 빈 dict → KeyError

`self.app.state["xmrig"]["hashrate_10s"]` 같은 깊이 2단계 dict 접근 시, `__init__`에서 `state = {}`로 시작 + `refresh_metrics`가 비동기로 도는 구조라면 **첫 render는 빈 dict에 접근** → `KeyError: 'hashrate_10s'`. **증상**: TUI 시작 시 traceback, 위젯 일부 안 보임.

**해결**: `_DEFAULT_STATE` 모듈 상수 + `__init__`에서 pre-populate:

```python
_DEFAULT_STATE = {
    "hashrate_10s": 0.0, "hashrate_60s": 0.0, "hashrate_15m": 0.0, "hashrate_max": 0.0,
    "accepted": 0, "rejected": 0, "block_height": 0,
    "pool_connected": False, "pool_url": "pool.supportxmr.com:5555",
    "pool_latency_ms": 0, "threads_ready": 0, "threads_total": 0,
    "last_share_time": None, "recent_log": deque(maxlen=8),
}

def __init__(self):
    super().__init__()
    # pre-populate with defaults
    self.state = {
        "xmrig": {k: (v.copy() if isinstance(v, deque) else v) for k, v in _DEFAULT_STATE.items()},
        "system": {"cpu_pct": 0.0, "mem_used_gb": 0.0, "mem_total_gb": 0.0, "mem_pct": 0.0,
                   "cpu_temp_c": None, "uptime_s": 0.0},
        "earnings": {"xmr_price": XMR_USD_PRICE},
    }
```

**추가**: 모든 render 메서드에서 `.get("key", default)` 안전 접근:

```python
def render(self) -> str:
    s = self.app.state.get("xmrig", _DEFAULT_STATE)
    hr_10 = s.get("hashrate_10s", 0.0)  # ← 없으면 0.0
    hr_60 = s.get("hashrate_60s", 0.0)
    ...
```

**재사용**: Textual/React/Vue/Svelte 등 reactive TUI의 첫 render. **state-driven UI의 보편 패턴**.

### 33. Textual 짝 안 맞는 Rich markup → MarkupError

f-string 안에 `[bold]...[/bold]`, `[dim]...[/dim]` 같은 Rich markup 쓰면 짝이 맞아야 하는데, **TUI가 `self.refresh()`로 위젯을 여러 번 재render하면서 캐시와 충돌**하면 `MarkupError: closing tag '[/dim]' does not match any open tag`. **진단**: traceback에 `[/dim]` 또는 `[/bold]`가 보이면 무조건 짝 검사.

**해결 3가지** (선호 순):
1. **짝 다시 확인** — `[bold]X[/bold]`, `[dim]X[/dim]` 한 쌍씩 명시
2. **markup 자체 제거** — 단순 텍스트로 (xmrig-dashboard는 EarningsPanel의 `[dim]Power cost[/dim]` → `Power cost:` 일반 텍스트로)
3. **위젯별 markup=False** — 가능하면 Static 위젯 단위로 markup 비활성화

**재사용**: Rich/Textual TUI에서 f-string 안에 bracket 패턴 쓰기. **첫 render OK + 두 번째 render부터 깨지면 90% 이 함정**.

**디버깅 단계** (xmrig-dashboard 실제):
```
1) EarningsPanel에서 [dim]Power cost: ... - net: ...[/dim] 발견
   → f-string 안에 [dim]...[/dim] 한 쌍. 코드 보면 짝 맞음.
2) 그래도 MarkupError 발생
   → Textual이 render() 캐시 + self.refresh() 호출 시 캐시 무효화 과정에서 짝이 어긋남
3) 단순 텍스트로 변경
   → f"  Power cost: ~$1.50/mo - net: -$0.30/mo\n"  # [dim] 제거
4) MarkupError 사라짐
```

### 34. Textual 6.x `Footer(markup=False)` 인자 없음

Footer/Header가 자체적으로 markup 처리하면서 `[/dim]` 같은 잔여 markup을 만들 수 있어 비활성화하려고 `Footer(markup=False)` 호출 → `TypeError: __init__() got an unexpected keyword argument 'markup'`. **Footer 6.x signature**: `(self, *children, name=None, id=None, classes=None, disabled=False, show_command_palette=True, compact=False)` — `markup` 인자 자체가 없음.

**해결**: Footer/Header 자체를 빼고 직접 만든 Static 위젯으로 대체:

```python
def compose(self) -> ComposeResult:
    yield StatusBar()  # 직접 만든 status bar
    with Container(id="main"):
        yield HashratePanel()
        yield SystemPanel()
        yield PoolPanel()
        yield EarningsPanel()
        yield LogPanel()
        yield Static("Press q to quit  |  p pause  |  r resume", id="hint")
    # No Header, No Footer (both have markup conflicts in textual 6.2.1)
```

**재사용**: Textual 6.x TUI에서 `MarkupError: closing tag '[/dim]'`이 Footer 활성화 시 발생하면 즉시 Footer 제거.

**진단 체크** (xmrig-dashboard 실제):
```
1) 첫 TUI 실행 → [bold green]...[/bold green] 짝 OK, [dim]...[/dim] 짝 OK
   → 그래도 MarkupError
2) Header/Footer 의심 → Header 제거 → 여전히 MarkupError
3) Footer 제거 → MarkupError 사라짐
   → Footer가 자체 markup 처리하면서 잔여 [/dim] 만들어냄
4) 직접 만든 StatusBar + hint Static으로 Footer 대체
```

### 35. TUI는 비대화형 환경에서 자동으로 screen refresh 루프에 빠져 timeout

`python3 dashboard.py`를 TTY 없는 환경 (subprocess, background, `nohup` 등) 에서 실행하면 TUI가 화면을 계속 그리려고 시도하면서 **출력 버퍼에 ANSI escape가 누적** + process가 종료 안 됨. **증상**: `[Command timed out after 90s]` 등 timeout, 비대화형이라 사용자 키 입력 못 받음.

**해결**: TUI 디버깅은 **반드시 background + stdout/stderr redirect로 캡처 + 수동 kill**:

```bash
# 5-1) 짧게 background로 띄워서 5~10초 후 캡처
/usr/local/bin/python3 /path/to/dashboard.py > /tmp/dash_test.log 2>&1 &
DASH_PID=$!
sleep 10
kill -9 $DASH_PID 2>/dev/null

# 5-2) 캡처된 출력에서 Traceback/Error/MarkupError grep
grep -iE "error|traceback|markup" /tmp/dash_test.log | head -5

# 5-3) 정상 종료 + 에러 0이면 TUI 컴포넌트는 OK
# 진짜 화면 확인은 실제 TTY (iTerm2, Terminal.app, Ghostty, Alacritty) 에서
```

**재사용**: TUI/REPL/curses 도구의 모든 비대화형 디버깅. **실제 TTY (iTerm2, Terminal.app, Ghostty, Alacritty) 에서 실행해야 진짜 화면 확인 가능**. 비대화형은 "TUI 컴포넌트 + markup + 위젯이 import + render 가능한가?"만 검증.

**주의**: 이 환경 (Hermes 대화형 셸) 에서 `terminal(background=true)` + `notify_on_complete=true` 사용 시 background process가 종료될 때마다 알림 옴. **xmrig-dashboard 5회 디버깅** 동안 5개 background process 종료 알림 받음. 무시 OK.

### 36. parse_xmrig_log() 같은 regex 파서는 log line을 누적해서 recent_log deque에 push할 때 줄바꿈 + ANSI escape + 길이 모두 처리

TUI의 `LogPanel`이 `recent_log` 마지막 8줄을 표시하는데, XMRig 로그가 **70~200자 길이 + ANSI escape (`\x1b[...m`) + 줄바꿈** 포함. 그대로 TUI에 넣으면 (a) 줄이 화면 넘침, (b) markup `[` `]` 충돌 (함정 33과 연관), (c) ANSI escape 그대로 출력되어 화면 깨짐.

**해결 3단계**:

```python
for ln in lines:
    # 1) markup 문자 escape — [ → ( , ] → )
    ln = ln.replace("[", "(").replace("]", ")")
    # 2) 길이 제한 (90자)
    if len(ln) > 90:
        ln = ln[-90:]  # 끝 90자 (timestamp 보존)
    formatted.append(ln[:90])
```

**추가 안전 장치**: 빈 deque 처리:

```python
if not formatted:
    formatted = ["(waiting for log data...)"]
```

**재사용**: 어떤 외부 도구 로그를 TUI로 표시할 때 (XMRig, Docker, k8s, AWS CloudWatch, nginx 등) — ANSI escape는 `re.sub(r'\x1b\[[0-9;]*m', '', ln)`로 제거하고, markup conflict는 `[/` → `)/`로 치환.

### 37. GitHub repo description은 한글 1줄이 가장 효과적 (한국 개발자 검색)

Public repo의 description은 GitHub search + About 섹션에 노출. 영문보다 **한글 한 줄 + 핵심 키워드 (영문 약어 포함)** 이 한국 개발자 검색에서 유리.

**예시 (xmrig-dashboard)**:
- 영문: `Real-time TUI dashboard for XMRig (Monero CPU miner) — live hashrate, system metrics, pool status` ✅
- 한글 한 줄: `XMRig(Monero CPU 채굴기) 실시간 TUI 대시보드 — hashrate, 시스템 메트릭, 풀 상태 라이브 모니터링`
- **선택**: 영문 + 핵심 키워드 (XMRig, Monero, TUI, dashboard, hashrate) — 이 키워드들이 sigco3111 OSS 검색에서 매칭됨

**재사용**: 모든 `gh repo create` 호출에서 description 1줄은 신중히. **이름 + description 조합이 GitHub search ranking의 70%**.

## 5. 검증 워크플로 (보고 전 필수)

xmrig-dashboard 사례 기반:

```bash
# 1) 보안 점검 (함정 31)
grep -rE "875D2GJL|4[A-Za-z0-9]{94}" . --include="*.py" --include="*.md"
grep -riE "kucoin|binance|bybit" . --include="*.py" --include="*.md"
grep -rE "heejeong_|/Users/hjshin" . --include="*.py" --include="*.md"
# → 모두 0건 확인

# 2) Python 문법
python3 -c "import ast; ast.parse(open('miner-dashboard.py').read())"  # → OK

# 3) import 검증
python3 -c "import importlib.util; spec = importlib.util.spec_from_file_location('md', 'miner-dashboard.py'); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); print('OK')"
# → "OK"

# 4) 데이터 파서 단독 테스트 (TUI 없이)
python3 -c "
import importlib.util
spec = importlib.util.spec_from_file_location('md', 'miner-dashboard.py')
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
s = mod.parse_xmrig_log('/Users/hjshin/xmrig.log')
print(f'10s: {s[\"hashrate_10s\"]:.1f} H/s, accepted: {s[\"accepted\"]}')
"
# → "10s: 1189.4 H/s, accepted: 4"

# 5) TUI 5~10초 background 실행 + 에러 캡처 (함정 35)
/usr/local/bin/python3 /path/to/miner-dashboard.py > /tmp/dash_test.log 2>&1 &
sleep 8
kill -9 $(pgrep -f miner-dashboard) 2>/dev/null
grep -iE "error|traceback|markup" /tmp/dash_test.log
# → "✅ 에러 없음" 또는 빈 줄

# 6) GitHub repo 검증
gh repo view sigco3111/xmrig-dashboard --json name,description,isPrivate,licenseInfo
gh api repos/sigco3111/xmrig-dashboard/contents/ --jq '.[] | .name'
# → 5개 파일 (.gitignore, LICENSE, README.md, miner-dashboard.py, xmrig.plist.example)
```

## 6. 검증된 사례

**xmrig-dashboard v0.1.0 (2026-06-24, sigco3111/xmrig-dashboard)**:

- **소요 시간**: ~45분 (TUI 디버깅 5회 + MarkupError 격리 + Footer 제거 + 비대화형 캡처 패턴 적용)
- **파일**: 5개 (Python 489 lines + README 289 lines + LICENSE 21 lines + .gitignore 35 lines + .plist.example 21 lines)
- **런타임 의존성**: `textual>=6.2.1` + `psutil>=7.0` (2개)
- **데이터 소스**: XMRig 로그 파일 (regex 파싱) + psutil + CoinGecko API
- **키 바인딩**: `p` (pause) / `r` (resume) / `q` (quit)
- **보안 점검 통과**: 4대 영역 grep 모두 0건 (지갑/KuCoin/사용자명/절대경로)
- **공개**: Public, MIT
- **URL**: https://github.com/sigco3111/xmrig-dashboard

**디버깅 트랜스크립트** (실제 5회 background 실행):

| 차수 | 증상 | 원인 | 해결 |
|---|---|---|---|
| 1 | `KeyError: 'hashrate_10s'` | 첫 render 시 빈 dict | `_DEFAULT_STATE` pre-populate + `.get()` 안전 접근 |
| 2 | `MarkupError '[/dim]'` (EarningsPanel) | `[dim]...[/dim]` 짝 어긋남 (실제로는 cache 충돌) | `[dim]` 제거 → 일반 텍스트 |
| 3 | `TypeError: Footer.__init__() got 'markup'` | `Footer(markup=False)` 인자 없음 | Footer 자체를 빼고 StatusBar + hint Static으로 대체 |
| 4 | `MarkupError '[/dim]'` (Footer 자체) | Footer가 자체 markup 처리하면서 `[/dim]` 잔여 | Header/Footer 모두 제거, 직접 만든 위젯만 |
| 5 | ✅ 정상 | 12초째 실행 중, traceback 0개 | 완료 |

**소요 시간 누적**:
- 1~4차: 각 5~10분 (background 캡처 + traceback 분석 + 패치)
- 5차: 정상 확인 (1분)
- → 총 ~30분이 TUI 디버깅에 소요. **TUI 비대화형 디버깅 패턴 (함정 35) 없었으면 5배 더 걸렸을 것**.

## 7. 재사용 가이드

다음 "외부 도구 + TUI 모니터링" 류 요청 시:

1. **본 references 먼저 로드** (SKILL.md의 "기존 도구에 TUI 추가 변형" + 본 문서)
2. **부트스트랩 전 보안 점검 4대 영역** (함정 31) 자동 적용
3. **9단계 레시피** 따라 코드 작성
4. **TUI 디버깅 5대 함정** (32~36) 회피
5. **README + LICENSE + .gitignore + .plist.example** 4개 파일 템플릿 적용
6. **검증 워크플로** 6단계 통과 후 push

**예상 소요 시간**: 30~45분 (xmrig-dashboard 기준)

**다음 적용 시나리오** (예측):
- **AWS CLI 로그 TUI** — CloudTrail log 파싱 + IAM 메트릭 + cost dashboard
- **Docker 컨테이너 TUI** — `docker ps`/`docker logs` 파싱 + 리소스 메트릭
- **kmsg-mcp TUI** — kakao-mcp 메시지 검색 + 30일 단위 cron + 통계
- **GitHub Actions 워크플로 TUI** — `gh run list` + workflow 상태 + 로그 tail

→ 위 시나리오 중 하나라도 요청 시 **본 references + 9단계 레시피 그대로 적용** 가능.

---

# v0.2.0 — Vivid Visuals (2026-06-24, sigco3111/xmrig-dashboard)

> **v0.1.0에서 v0.2.0으로의 업그레이드 사례** — 핵심 widget 5개는 그대로 두고 **시각화 helper 5개 + 새 패널 1개 + 단축키 1개 + pytest 20개**를 추가. **100% backward compatible**.

## 1. 트리거 조건

다음 중 하나라도 해당되면 v0.2.0 단계로 분기:

- "그래프/애니메이션/시각효과 추가해줘"
- "TUI를 더 화려하게" 류 요청
- "단위 테스트 추가해줘" (v0.1.0에 테스트 0개였음)
- v0.1.0이 동작하지만 사용자가 시각적 피드백 부족을 느낌

## 2. v0.1.0 → v0.2.0 작업 단계

| 단계 | 내용 | 산출물 |
|---|---|---|
| **브레인스토밍** | 결정 포인트 6~7개 + 2~3 옵션 + 추천 | 6 카테고리 옵션 표 |
| **방식 결정** | Phase 0 (다른 PC) vs 풀세션 (이 PC) | 사용자 선택 |
| **기존 코드 정독** | `_DEFAULT_STATE`, `__init__` pre-populate, helper 없는 widget 직접 render 확인 | 회귀 위험 지점 |
| **helper 5개 추가** | 순수 함수 (Rich 마크업 반환) | `render_donut`, `render_core_bars`, `render_forecast_bars`, `render_core_heatmap`, `render_header_logo` |
| **기존 widget 확장** | SystemPanel에 코어 바, EarningsPanel에 도넛+막대, StatusBar에 로고 | widget `render()` 메서드 수정 |
| **새 panel 1개** | `CoreHeatmapPanel` 추가 | compose()에 yield |
| **단축키 1개** | `g` 토글 (그래프 on/off) | BINDINGS + action_toggle_graphs |
| **앱 상태 확장** | `_core_history`, `_daily_earnings`, `_show_graphs` | `__init__`에 pre-populate |
| **pytest 20개** | helper 5개 × 4 케이스 + 경계조건 | `tests/test_visual.py` |
| **README 업데이트** | Controls 표 + "What's new in v0.2.0" 섹션 | +37 lines |
| **commit + push + tag** | 단일 commit + v0.2.0 태그 | `384137a` |

**소요 시간**: ~30분 (브레인스토밍 5분 + 코드 15분 + 테스트 5분 + push 5분)

## 3. 핵심 아키텍처 결정: "helper 함수 분리" 패턴

v0.2.0의 가장 중요한 결정. **widget 코드와 시각화 helper를 분리**.

### 3-1. v0.1.0 패턴 (위험)

```python
class HashratePanel(Static):
    def render(self) -> str:
        # ... 100 lines of markup construction inline
        bar_full = chr(0x2588)
        bar_empty = chr(0x2591)
        # ... 50 lines
```

**문제**:
- 단위 테스트 불가 (Textual `App` 컨텍스트 필요)
- 새 시각 효과 추가할 때마다 widget 코드 100+ lines 수정
- 회귀 위험 (한 widget 수정 → 다른 widget 영향)

### 3-2. v0.2.0 패턴 (안전) ⭐

```python
# ---------- Visualization helpers (v0.2.0) ----------
# All helpers are pure functions: they take primitive inputs and return
# Rich-markup strings. This keeps them unit-testable without spinning up
# the Textual app.

def render_donut(accepted: int, rejected: int, size: int = 4) -> str:
    """..."""
    if accepted + rejected == 0:
        return f"[{PALETTE['fg_dim']}](no shares yet)[/{PALETTE['fg_dim']}]"
    # ... 30 lines, no self, no state

# ---------- TUI Widgets ----------
class EarningsPanel(Static):
    def render(self) -> str:
        # ... 기존 코드 ...
        h += f"\n  [#1f8033]donut[/#1f8033]  {render_donut(accepted, rejected)}\n"
        return h
```

**이점**:
- helper는 `psutil`/`Textual` import 없이 호출 가능 → **pytest 100% 단위 테스트**
- 새 시각 효과 = 새 helper 1개 + widget 1~2줄 추가
- widget 코드는 5~10줄 증가로 끝남

### 3-3. helper 작성 규칙 (v0.2.0 검증)

1. **순수 함수**: `self` 금지, 모듈 글로벌 읽기 금지, 외부 IO 금지
2. **Rich 마크업 문자열 반환**: widget과 동일한 출력 포맷
3. **`PALETTE` 상수만 사용**: 색상은 모듈 상수로 통일
4. **빈 데이터 placeholder 필수**: 차트가 비어 보이지 않게 명시적 메시지
5. **width/height 인자**: terminal 크기 적응 가능

## 4. ⚠️ v0.2.0 신규 함정 3가지

### 38. Hyphen 들어간 single-file Python은 `import` 불가 → pytest에서 `importlib` 우회

xmrig-dashboard v0.1.0의 메인 파일은 `miner-dashboard.py` (하이픈 포함). Python 식별자 규칙상 하이픈은 import 불가:

```python
# ❌ 안 됨
import miner-dashboard  # SyntaxError
from miner-dashboard import render_donut  # SyntaxError
```

**해결** (`tests/test_visual.py` 전체에 적용):

```python
import importlib.util
import pathlib

ROOT = pathlib.Path(__file__).resolve().parent.parent
SCRIPT = ROOT / "miner-dashboard.py"
spec = importlib.util.spec_from_file_location("miner_dashboard", SCRIPT)
assert spec is not None and spec.loader is not None  # type guard for mypy/pyright
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

# 이제 mod.render_donut(...) 호출 가능
```

**Pyright false-positive**:
```python
spec = importlib.util.spec_from_file_location(...)
mod = importlib.util.module_from_spec(spec)  # ERROR: spec is "ModuleSpec | None"
spec.loader.exec_module(mod)  # ERROR: loader is "None"
```

→ `assert spec is not None and spec.loader is not None` 한 줄로 가드.

**재사용**: TUI/CLI OSS에서 단일 파일 + hyphen 컨벤션 채택 시 (Python에서는 흔함 — `aws-cli`, `ssh-keygen`, `kmsg-mcp` 류). **테스트 0개 → 20개로 확장 시 필수 패턴**.

### 39. `Textual.Static.app`은 read-only property → render() 단위 테스트 시 subclass로 우회

Textual의 `Widget.app`은 내부 메시지 라우팅용으로 `MutableTypes` 기반이지만, **외부에서 `widget.app = mock_app` 할당 불가**:

```python
sb = m.StatusBar()
sb.app = app  # AttributeError: property 'app' of 'StatusBar' object has no setter
```

**해결** (`tests/test_visual.py` 외부 smoke test):

```python
class MockSB(m.StatusBar):
    @property
    def app(self):
        return app  # closure-captured fake app

sb = MockSB()
out = sb.render()  # widget의 .app 호출이 mock으로 라우팅
```

**대안 (덜 깔끔)**: `monkeypatch`로 `Widget._app` private 속성에 직접 할당. Textual 6.x에서는 `_app`이 `reactive`로 선언되어 있어 `app._app = mock_app`은 가능하지만 brittle.

**재사용**: Textual widget의 `render()`를 TTY/앱 없이 검증할 때. **TUI의 단위 테스트 가능 영역 = helper 100% + widget render 50%** (위 패턴으로 50% 회복).

### 40. v0.x → v0.y 기능 추가 시 `_DEFAULT_STATE` + `__init__` pre-populate 패턴이 회귀 안전망

v0.2.0에서 새 상태 3개 (`_core_history`, `_daily_earnings`, `_show_graphs`)를 App에 추가했는데, **pre-populate 안 하면 widget 첫 render에서 `AttributeError`**:

```python
class CoreHeatmapPanel(Static):
    def render(self) -> str:
        history = list(getattr(self.app, "_core_history", []))  # getattr으로 우회
        # ...
```

**원칙**:
1. App의 새 상태는 `__init__`에서 **반드시 기본값으로 초기화** (deque, list, bool 등)
2. widget은 `getattr(self.app, "key", default)` 안전 접근 (혹은 `hasattr` 가드)
3. v0.1.0 패턴(`_DEFAULT_STATE` 모듈 상수 + widget의 `.get("key", default)`)을 그대로 모방

**검증 워크플로**:
```bash
# 새 widget/상태 추가 후 5초 background 실행 → AttributeError grep
python3 dashboard.py > /tmp/test.log 2>&1 &
sleep 5
kill -9 $! 2>/dev/null
grep -iE "attribute|keyerror|nameerror" /tmp/test.log
# → 0줄이어야 OK
```

**재사용**: TUI/REPL/GUI에서 reactive state 추가 시. **`App.__init__`이 모든 state의 source of truth** 원칙 유지.

## 5. pytest 통합 (v0.1.0에 없던 신규 계층)

### 5-1. 디렉토리 구조

```
xmrig-dashboard/
├── miner-dashboard.py        # 메인 (1292 lines)
├── tests/
│   └── test_visual.py        # pytest 20개
├── README.md
├── LICENSE
├── .gitignore                # .pytest_cache/ 이미 포함
└── xmrig.plist.example
```

### 5-2. 테스트 4 원칙

1. **TTY 의존 0개**: Textual app 안 띄움
2. **psutil 의존 최소화**: `psutil.cpu_percent(percpu=True)`는 테스트에서 호출 안 함 (CI에서 환경 의존)
3. **Rich 마크업 substring 검증**: `assert "▄" in out` 같은 단순 체크 (정확한 ANSI 비교 X)
4. **경계조건 명시**: 빈 입력, 0%, 100%, 코어 수 32개 초과 등

### 5-3. 실행

```bash
python3 -m pip install pytest textual psutil
python3 -m pytest tests/ -v
# → 20 passed in 0.44s
```

**CI 통합 (선택)**: `.github/workflows/test.yml` 추가하면 좋지만, v0.2.0에서는 **로컬 테스트로만** 운영. CI는 v0.3.0에서.

## 6. Density-adaptive UI (v0.1.0 호환 + v0.2.0 시각화)

v0.2.0의 모든 새 시각화는 **작은 터미널(< 36 lines)에서 자동 축소**:

| 화면 높이 | 풀 모드 | 컴팩트 모드 |
|---|---|---|
| **HashratePanel** | 5개 라인 + 트렌드 스파크라인 | 5개 라인 + 짧은 트렌드 |
| **SystemPanel** (v0.2.0+) | 코어 바 (4×N cells) | 1줄 요약 |
| **CoreHeatmapPanel** (신규) | 12 컬럼 히트맵 | 1줄 avg/min/max |
| **EarningsPanel** | 도넛 + 7일 막대 | 6줄 요약 |

**원칙**: 모든 새 위젯은 `screen_h < 36` 분기에서 **데이터 손실 없이 1줄 요약**으로 축소. 비어 보이는 UI 절대 안 만듦.

## 7. v0.2.0 검증 워크플로 (5단계)

```bash
# 1) 단위 테스트
python3 -m pytest tests/ -v
# → 20 passed

# 2) Import + App 인스턴스화
python3 -c "
import importlib.util
spec = importlib.util.spec_from_file_location('md', 'miner-dashboard.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
app = m.MinerDashboard()
print('BINDINGS:', [b[0] for b in m.MinerDashboard.BINDINGS])
"
# → BINDINGS: ['p', 'r', 'q', '?', 'c', 's', 'g']  # g 신규

# 3) Helper dryrun
python3 -c "
import importlib.util
spec = importlib.util.spec_from_file_location('md', 'miner-dashboard.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
print(m.render_donut(100, 5))  # 도넛 렌더 확인
"
# → ASCII 도넛 4행 + '95.2% acc' 라벨

# 4) 5초 background + AttributeError/KeyError grep
python3 miner-dashboard.py > /tmp/test.log 2>&1 &
sleep 5
kill -9 $! 2>/dev/null
grep -iE 'attribute|keyerror|nameerror|traceback' /tmp/test.log
# → 0줄 (성공)

# 5) StatusBar render 검증 (subclass 패턴, 함정 39)
python3 -c "
import importlib.util, re
spec = importlib.util.spec_from_file_location('md', 'miner-dashboard.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
app = m.MinerDashboard()
app.state['xmrig'] = {'pool_connected': True, 'hashrate_10s': 1234.0,
                     'accepted': 142, 'rejected': 3}
app.state['system'] = {'cpu_pct': 87.5}
class MockSB(m.StatusBar):
    @property
    def app(self): return app
sb = MockSB()
out = re.sub(r'\[/?[^]]+\]', '', sb.render())  # markup 제거
print('MINING' in out, 'IDLE' in out)  # True, False
"
# → True False (로고 + 상태 dot 정확히 작동)
```

## 8. v0.1.0 → v0.2.0 호환성 보장 체크리스트

v0.2.0 푸시 전 확인:

- [ ] 기존 BINDINGS (`p/r/q/?/c/s`) 그대로 작동
- [ ] 기존 widget (`Hashrate/System/Pool/Earnings/Log`) 모두 렌더링
- [ ] v0.1.0 펄스 효과 (`-pulse-bright` 클래스) 보존
- [ ] density-adaptive 분기 (`screen_h < 36`) 모든 widget에 적용
- [ ] Python 3.8+ 호환 (no walrus, no match statements)
- [ ] PII grep 4대 영역 0건 (보안 점검 동일)
- [ ] 단위 테스트 100% 통과

## 9. v0.2.0 디버깅 트랜스크립트 (실제 5회)

| 차수 | 증상 | 원인 | 해결 | 함정 |
|---|---|---|---|---|
| 1 | lint: 중복 주석 `# ---------- TUI Widgets ----------` 2개 | patch 도구가 컨텍스트 매칭 시점에 부분만 잡힘 | patch 한 번 더 | (도구 사용) |
| 2 | lint: 중복 `power = estimate_power(cpu_pct)` | patch old_string이 일부만 매칭 | patch 한 번 더 | (도구 사용) |
| 3 | pytest: `test_total_lines_is_consistent` 실패 | 도넛은 4행 구조인데 테스트가 5줄 기대 | 테스트 정정 | — |
| 4 | pytest: `test_uses_block_chars` 실패 | 100% 부하 + width=3 → 빈 행 없음 | 테스트 50%로 변경 | — |
| 5 | smoke: `widget.app = app` → AttributeError | Textual property read-only | subclass `@property app` | 39 |

**소요 시간 누적**: 30분 (브레인스토밍 5 + 코드 10 + 테스트 5 + 디버깅 5 + push 5)

## 10. v0.2.0 → v0.3.0 로드맵 (예측)

| 단계 | 작업 | 비고 |
|---|---|---|
| v0.2.1 | 사용자가 직접 1주일 사용 후 발견한 UX 이슈 픽스 | 버그 리포트 기반 |
| v0.3.0 | 코어 히트맵 애니메이션 (rich Live + render=auto) | v0.2.0의 helper 5개로 충분 |
| v0.4.0 | 멀티 풀 지원 (config pools[0/1/2] 사이클) | 6단축키 추가 |
| v0.5.0 | GitHub Actions CI (.github/workflows/test.yml) | pytest 자동화 |
| v1.0.0 | pyproject.toml 패키징 + PyPI 배포 | pip install 가능 |

**v0.3.0 핵심**: v0.2.0의 helper 패턴 덕분에 **widget 코드는 거의 안 건드리고 helper만 확장** 가능. **이게 helper 분리의 진짜 가치**.

## 11. 재사용 가이드

다음 "기존 TUI에 시각화/테스트 추가" 요청 시:

1. **본 v0.2.0 섹션 + SKILL.md 메인 + `references/visual-helpers-pattern.md` 로드**
2. **브레인스토밍 6~7 카테고리** (그래프/펄스/팔레트/단축키/로고/시각화/방식) — 결정 포인트별 2~3 옵션
3. **방식 결정**: Phase 0 (다른 PC) vs 풀세션 (이 PC) — 5개 미만 변경이면 풀세션 OK
4. **helper 3~5개 먼저 추가** (순수 함수, Rich 마크업 반환)
5. **widget 확장** (helper 호출 1~2줄)
6. **pytest 추가** (helper당 3~5 케이스, 총 15~25개 목표)
7. **density-adaptive 분기** (모든 widget에 `screen_h < 36` 분기)
8. **검증 워크플로 5단계** 통과 후 push

**예상 소요 시간**: 30분 (v0.2.0 사례 기준) — helper 분리가 잘 되어 있으면 widget 추가 1개당 5~10분.

**다음 적용 시나리오** (예측):
- **AWS CLI 로그 TUI v0.2.0** — CloudWatch 비용 시각화 + region별 히트맵
- **Docker 컨테이너 TUI v0.2.0** — `docker stats` 파싱 + 컨테이너별 메트릭 막대
- **gh-actions TUI v0.2.0** — workflow run 히스토리 + status dot + 실패율 도넛
- **kmsg-mcp TUI v0.2.0** — 메시지 버스트 히트맵 (30분 갭 토픽 그룹핑) + 30일 통계 막대

→ 위 시나리오 중 하나라도 "그래프/시각화 추가" 요청 시 **본 섹션 + 9단계 + helper 분리 패턴** 그대로 적용.
