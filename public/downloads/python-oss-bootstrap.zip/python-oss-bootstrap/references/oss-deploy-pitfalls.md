# OSS Deploy Pitfalls (xmrig-dashboard v0.2.0, 2026-06-24)

> **코드 push != production deploy**. v0.2.0 push 직후 사용자가 "UI가 전혀 변하지 않았음"으로 직접 피드백. 진단 결과 — **launcher/의존성/PID 3중 갭**이 동시 발생.
> 본 문서는 다음 OSS 부트스트랩/v0.x→v0.y 업그레이드 시 자동 적용할 **deploy 4단계 + 회피 자가 점검**.

## 1. 트리거 조건

다음 중 하나라도 해당되면 본 deploy 단계 자동 적용:

- "UI가 안 바뀌어요", "신버전인데 동작 안 해요", "옛 버전이 보임" 류 사용자 피드백
- v0.x → v0.y 업그레이드 직후
- 시스템 Python (`/Library/Frameworks/Python.framework/...`)에 신버전 의존성 미설치
- OSS launcher가 `~/bin/run-<oss>.sh` 같은 wrapper 스크립트로 운영될 때

## 2. 증상 (3중 갭)

v0.2.0 사례에서 동시 발생:

| # | 증상 | 원인 |
|---|---|---|
| 1 | UI가 v0.1.0 그대로 | launcher `exec` 경로가 옛 v0.1.0 단일 파일 가리킴 |
| 2 | 신버전 import 실패 | launcher가 system Python 3.8 사용 (textual 6.2.1만 있음), v0.2.0은 textual 8.2.7 필요 |
| 3 | 신버전 PID는 떴지만 화면은 옛것 | 옛 v0.1.0 background process가 안 죽어서 충돌 없이 신버전 추가 실행, 사용자 화면은 옛것 |

**하나만 발생해도 사용자 입장에선 "신버전 안 됨"으로 보임. 3개 다 점검 필수.**

## 3. Deploy 4단계 (push 직후 자동 실행)

```bash
# Step 1: launcher exec 경로 갱신
# ~/bin/run-<oss>.sh 의 exec 경로를 v0.y.0 repo 파일로
sed -i '' 's|/Users/.*/old-file.py|/Users/<user>/git/sigco3111/<repo>/main-file.py|' ~/bin/run-<oss>.sh

# Step 2: launcher Python 인터프리터 갱신 (의존성 버전 충족 확인)
# system Python에 신버전 의존성 없으면 conda env 경로로
sed -i '' 's|/Library/Frameworks/Python.framework.*|/Users/<user>/opt/anaconda3/envs/<env>/bin/python|' ~/bin/run-<oss>.sh

# Step 3: 이전 process 정리 (deploy 필수 — push만 하면 옛 PID 살아있음)
pgrep -fl <oss-name>  # 옛 PID 확인
kill -9 <old-pid>     # 명시적 종료 (background가 끝나기 기다리지 말 것)

# Step 4: 신버전 health check (background 5~10초 + 에러 grep)
<launcher> > /tmp/<oss>_deploy_check.log 2>&1 &
sleep 6
grep -iE "error|traceback|markup|attribute|keyerror" /tmp/<oss>_deploy_check.log
# → 0줄이어야 OK. 비어있지 않으면 즉시 traceback 확인 후 launcher/의존성 재점검
```

**예상 소요 시간**: 5~10분 (launcher 1~2줄 + PID 1개 + 6초 health check)

## 4. 회피 자가 점검 (deploy 직전 4개 질문)

| # | 질문 | 명령 |
|---|---|---|
| 1 | launcher exec 경로가 신 repo 가리키는가? | `cat ~/bin/run-<oss>.sh` |
| 2 | 옛 PID 안 떠 있는가? | `pgrep -fl <oss>` → 0줄 |
| 3 | launcher Python에 신버전 의존성 있는가? | `<launcher-python> -c "import <dep>; print(<dep>.__version__)"` |
| 4 | background 5초 + 에러 grep에서 traceback 0줄인가? | 위 Step 4 |

→ 4개 다 OK여야 "deploy 완료". 하나라도 어긋나면 launcher 1~2줄 + PID 1개로 5분 안에 수정 가능.

## 5. 실제 사례 (xmrig-dashboard v0.2.0)

### 5-1. 발견

- **사용자**: "UI가 전혀 변하지 않았음. `~/bin/run-miner-dashboard.sh`로 실행하는 것이 맞나?"
- **진단 1**: `cat ~/bin/run-miner-dashboard.sh` → `exec /Library/Frameworks/Python.framework/Versions/3.8/bin/python3 /Users/hjshin/miner-dashboard.py` (옛 v0.1.0 단일 파일)
- **진단 2**: `pgrep -fl miner-dashboard` → PID 75352 살아있음 (옛 v0.1.0)
- **진단 3**: system Python 3.8 → `textual 6.2.1` (v0.1.0 시절), v0.2.0은 `textual 8.2.7` 필요

### 5-2. 수정

```bash
# Step 1: launcher path
sed -i '' 's|/Users/hjshin/miner-dashboard.py|/Users/hjshin/git/sigco3111/xmrig-dashboard/miner-dashboard.py|' ~/bin/run-miner-dashboard.sh

# Step 2: launcher Python interpreter
sed -i '' 's|/Library/Frameworks/Python.framework/Versions/3.8/bin/python3|/Users/hjshin/opt/anaconda3/envs/xmrig-dash/bin/python|' ~/bin/run-miner-dashboard.sh

# Step 3: 옛 PID kill
kill -9 75352

# Step 4: health check
~/bin/run-miner-dashboard.sh > /tmp/dash_v020.log 2>&1 &
sleep 6
grep -iE "error|traceback|markup" /tmp/dash_v020.log
# → 0줄
```

### 5-3. 검증

```
XMRig log:        /Users/hjshin/xmrig.log  [OK]
XMRig config:     /Users/hjshin/xmrig-config.json  [OK]

     █▀█ █▀▀ █▀█ █▀▀ █▀▀ ● IDLE | heejeong_kucoin_macmini | CPU   0.0% | 0...
```

→ 새 ASCII 로고 `█▀█ █▀▀ █▀█ █▀▀ █▀▀` + 상태 dot `● IDLE` 정확히 출력. v0.2.0 동작 확인.

## 6. 재사용 가이드

다음 OSS 부트스트랩/v0.x→v0.y 업그레이드 시:

1. **본 references 자동 로드** (SKILL.md의 references 목록에 이미 추가됨)
2. **push 직후 deploy 4단계 자동 실행** (위 3번)
3. **자가 점검 4개 질문** (위 4번) 모두 OK
4. **사용자에게 "다시 실행해보세요" 알림** + health check 로그 일부 보여주기

**다음 적용 시나리오**:
- 다른 시그니처 OSS (md-doctor, cron-doctor, chat-doctor, gh-traffic-monitor 등) v0.x→v0.y 업그레이드 시
- 새 OSS 부트스트랩 시 launcher 작성 단계에서 deploy 4단계 미리 적용
- "UI가 안 바뀌어요" 류 사용자 피드백 시 진단 첫 단계로

## 7. 본 deploy 단계와 기존 함정의 관계

- **함정 35 (TUI 비대화형 디버깅)**: background + stdout/stderr redirect + 수동 kill 패턴 재사용 (Step 3~4)
- **v0.1.0 6단계 검증 워크플로** (case study 5번): 6번 단계 (TUI 5~10초 background 실행 + 에러 캡처)가 deploy 4단계의 Step 4와 동일

→ 본 deploy 단계는 기존 검증 워크플로의 **"production 환경" 특화 변형**. 5~10초 캡처 → 6초 캡처로 단축, launcher 경로/PID 정리 추가.

## 8. 안티패턴 (하지 말 것)

### 8-1. ❌ push만 하고 "배포 끝"으로 간주

```bash
git push  # "배포 완료!"
```

→ 사용자는 launcher가 옛 경로 가리키는 줄 모름. **3중 갭 자동 발생**.

### 8-2. ❌ launcher 수정 없이 신버전 파일만 교체

```bash
cp /path/to/new/miner-dashboard.py ~/miner-dashboard.py
# launcher는 ~/miner-dashboard.py 가리키니까 OK?
```

→ launcher가 repo 파일 (`~/git/.../`)을 가리키게 **되어 있다면** 옛 단일 파일 가리키는 launcher는 무시됨. launcher 우선 갱신.

### 8-3. ❌ 옛 PID 정리 안 함

```bash
~/bin/run-miner-dashboard.sh &  # 신버전 실행
# 옛 PID는 안 죽임
```

→ 신/구 2개 process 동시 실행, 사용자는 옛것 봄. `pgrep -fl` + `kill -9` 명시 필수.

### 8-4. ❌ system Python에 신버전 의존성 강제 설치

```bash
# v0.2.0은 textual 8.2.7인데 system Python 3.8에 강제 설치
python3 -m pip install --user --upgrade textual
```

→ `pip install --user`로 system Python 의존성 업그레이드 시 다른 도구와 충돌 위험. **conda env 격리 패턴 권장** (`conda create -n <env> python=3.11 && <env-pip-install>`).
