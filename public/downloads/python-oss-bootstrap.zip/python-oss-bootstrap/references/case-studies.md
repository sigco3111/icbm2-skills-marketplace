last_updated: 2026-06-17

# 실전 사례 — hwp2md, md-doctor, cron-doctor, kakao-summary (kmsg-doctor), opencode-trading, opencode-harness-bridge, gh-traffic-monitor, Repolis

> **시계순 읽기 권장**: 사례 1 → 2 → 3 → 4 → 5 → 6 → 7 → 8. 각 사례가 이전 사례의 학습을 어떻게 활용하는지 보임.

---

## 사례 1: hwp2md (2026-06-08, v1.0.0)

**트리거**: "오랜만에 가벼운 서브프로젝트" + "hwp2md 만들어줘"
**소요**: 단일 세션 ~30분
**결과**: 8/8 테스트 통과, v1.0.0 (1.0 정식 출시)

### 시퀀스
1. gh repo create → clone
2. pyproject.toml + LICENSE + .gitignore
3. 소스: `__init__` (convert/batch_convert), core (dispatcher), cli, exceptions
4. 백엔드: hwpx (0.2.0 예정 스텁), hwp5 (0.2.0 스텁)
5. 스모크 테스트 6개
6. README (한글 + 영문) + CHANGELOG
7. CI + action.yml
8. v0.1.0 태그 → 푸시
9. About 한글화 (1차 영문 → 2차 한글)

### 배운 점
- **백엔드 디스패처 패턴**: `core.py`가 `hwp/hwpx` 확장자 보고 분기. 새 포맷 추가 = 새 파일 + dispatcher 1줄.
- **GitHub About 영문 → 한글**: 사용자 요청으로 2차 한글화. 처음부터 한글로 가는 게 더 빠름.

---

## 사례 2: md-doctor (2026-06-09, v0.1.0)

**트리거**: "hwp2md 완료했음. 다음 서브프로젝트?" → 추천 3개 거절 → "md-doctor 진행하자"
**소요**: 단일 세션 ~25분
**결과**: 16/16 테스트 통과, v0.1.0

### 시퀀스 (hwp2md와 거의 동일, 그래서 자동화 가치가 입증됨)
1. gh repo create → clone
2. pyproject.toml (실패 1회: 이메일 형식) + .gitignore + pytest.ini
3. `models.py` 분리 (이게 새로운 학습!)
4. 소스: __init__, __main__, cli, core, models, exceptions, checks/{token_stats, heading_consistency, dead_links 스텁, broken_images 스텁}
5. 스모크 테스트 16개
6. README (한글 + 영문 부록) + CHANGELOG + CONTRIBUTING (BaseCheck 상속 튜토리얼)
7. CI (Python 3.9-3.12 매트릭스) + action.yml (composite)
8. v0.1.0 태그 → 푸시
9. About 한글화 (처음부터 한글)

### 새 학습 (hwp2md와 차이)
- **순환 import**: core ↔ checks 구조에서 발생 → `models.py` 분리 + lazy import로 해결. **다음 프로젝트부터는 처음부터 적용**.
- **`pyproject.toml` authors.email 함정**: PEP 621 위반으로 `pip install -e .` 깨짐 → 이메일 빼고 `name`만.
- **argparse `nargs="?"`**: `--list-checks` 같은 부속 명령과 동시 사용 가능하게.
- **체크 모듈 패턴**: `BaseCheck` 상속 → `default_checks()` 레지스트리 → 0.1.0엔 2개 활성, 2개는 스텁. hwp2md의 백엔드 스텁 패턴과 동일.

---

## 사례 3: cron-doctor (2026-06-16, v0.1.0 — Phase 0)

**트리거**: "새 프로젝트를 시작하고 싶네? 뭐가 좋을까?" → 추천 4개 중 "Cron YAML 검증기로 하자" 선택 → "리드미와 About은 한글로, 다른 PC에서 작업"
**소요**: 단일 세션 ~20분
**결과**: Phase 0 스켈레톤 (README/CHANGELOG/CONTRIBUTING/LICENSE + 5개 검사 모듈 stub + 2개 파서 stub) + v0.1.0 태그

### Phase 0 변형의 핵심 차이 (사례 1·2와 다른 점)
- **소스 코드는 다른 PC에서 작업** → 이 PC는 README/About + 스켈레톤(빈 함수 + docstring 가이드)만
- **브레인스토밍 단계 추가**: 결정 포인트(이름/범위/CLI/테스트/README)별 옵션 2~3개 + 추천 → "그대로 진행해" 받음 → 즉시 실행. 음악/디자인 워크플로와 동일 패턴.
- **README 다층 옵션 구조**: 1-옵션 단순 거부, **결정 사항 4가지 + 샘플 옵션 + 직접 작성(고급) + 4단계 로드맵** 등 단계적 깊이 선호
- **각 스텁 파일에 docstring 가이드**: 다른 PC 작업자가 빈 파일 보고 헤매지 않게. 예: `Y001_yaml.py`엔 "PyYAML 의존성 vs 자체 구현 trade-off" 결정 가이드, `cli.py`엔 "`nargs='?'` 잊지 말 것" 함정 알림, `models.py`엔 "core와 checks 모두 models만 직접 import" 패턴

### 시퀀스
1. `mkdir -p ~/.openclaw/workspace/cron-doctor` (워크스페이스에 격리)
2. `write_file` 4종: README.md (다층 옵션, 9.5KB) / CHANGELOG.md / CONTRIBUTING.md / LICENSE / .gitignore
3. `mkdir -p src/cron_doctor/checks src/cron_doctor/parsers tests/fixtures .github/workflows` (⚠️ 한 줄 mkdir가 가끔 race condition)
4. `touch` 23개 파일 (스켈레톤 + .gitkeep)
5. `write_file`로 각 스텁에 docstring 가이드 작성 (12개 파일)
6. `git init -b main && git add -A && git commit`
7. `gh repo create sigco3111/cron-doctor --public --description "<한글>" --source=. --remote=origin --push` (--license 빼고 — 일부 gh 버전에서 help만 출력되는 현상 회피)
8. `git tag -a v0.1.0 -m "..." && git push origin v0.1.0`
9. `gh repo view`로 description + license + visibility 확인

### 새 학습 (사례 1·2에 없는 것)
- **Phase 0 변형 = 부트스트랩의 정당한 부분**: 코드 작업은 다른 곳에서, README/스켈레톤/문서만이라도 가치 있음. **사용자가 명시적으로 "다른 PC에서" 요청**할 때만 사용.
- **스텁 docstring 가이드 = 핸드오프 도구**: 다른 PC 작업자(또는 미래의 나)에게 "이 파일은 이런 책임, 이런 trade-off, 이런 패턴" 알려주기. ai-gm 시리즈의 README가 했던 역할과 같음.
- **`mkdir -p` race condition**: `mkdir -p A B/C` 직후 `touch B/C/x.py`가 같은 한 줄 안에 있을 때, 가끔 B/C가 아직 안 만들어진 상태로 touch가 실행됨. **안전한 패턴**: `mkdir -p`를 한 번 더 실행하거나 dir을 한 줄씩 만들기.
- **`gh repo create --license MIT` 옵션 문제**: 일부 gh 버전에서 `--license` 플래그 위치가 잘못 인식돼 도움말만 출력됨. **안전한 패턴**: `--license` 빼고 repo 생성, MIT 라이선스는 `LICENSE` 파일 푸시로 처리.
- **브레인스토밍 2-3 옵션 + 추천 → 선택**: 음악 창작 / 프로젝트 디자인 / OSS 부트스트랩 모두 공통 패턴. **사용자 "그대로 진행해"가 가장 흔한 답** — 옵션 4~5개 넘지 않게, 추천은 명확히.

---

## 사례 4: kmsg-doctor → kakao-summary (2026-06-16, v0.1.0 — Phase 1 + 이름 변경)

**트리거**: cron-doctor (Phase 0) 완료 직후 사용자가 첨부 카톡 카드뉴스 이미지 + `kmsg-mcp` GitHub URL 공유 → "이걸로 단톡방 카드뉴스 요약할 수 있나?" → 브레인스토밍 4개 옵션 → "에르메스 PC에서 직접 작업" 선택 → **v0.1.0 완성 후 사용자가 "kmsg-doctor는 적합하지 않은것 같아"로 rename 요청** → kakao-summary로 변경

**소요**: 단일 세션 ~40분 (35분 부트스트랩 + 5분 이름 변경)
**결과**: 9개 모듈 + 32/32 테스트 통과 (0.14초) + v0.1.0 태그 + GitHub public

### Phase 1 변형의 핵심 차이 (사례 1·2·3과 다른 점)
- **이 PC에서 직접 작업** → 소스 코드를 직접 작성, 스텁 아님. 핵심 4개 모듈(`kmsg_client`, `prefilter`, `cache`, `summarizer`)은 실제 동작
- **외부 도구 wrapping** — kmsg-mcp라는 별도 MCP 서버를 stdio subprocess + JSON-RPC 2.0으로 통합. pip 의존성 0개 유지하면서 외부 도구 기능 흡수
- **SQLite 캐시** — kmsg-mcp의 `limit=100` 한계를 로컬 DB로 우회. 1000개+ 영구 보관 + 증분 sync + 시간 윈도우 쿼리
- **결정론적 v0.1.0** — LLM 호출 0회. 시간 갭 30분 기준 토픽 그룹핑. 비용 $0, 즉시 응답. v0.2.0+ 에서 LLM 추가 예정
- **다중 출력 포맷** — 터미널 컬러 / Telegram Markdown / JSON. CLI `--format` 옵션으로 선택
- **사용자 첨부 이미지 → 형식 결정** — "이 카톡 카드뉴스처럼 만들어줘" 식 요청이 들어오면 첨부 이미지 분석 + JSON fixture로 시뮬레이션 후 같은 형식 생성
- **이름 변경 워크플로** (Phase 1.5) — 1세션 만에 kmsg-doctor → kakao-summary로 rename (사용자 "프로젝트명으로 적합하지 않음" 신호)

### 시퀀스
1. **브레인스토밍** (5 결정 포인트) — 이름(kmsg-doctor 시리지 일관성) / 범위(카드뉴스+캐시) / 통합 방식(stdio subprocess) / 출력(text+telegram+json) / 저장소(SQLite). 옵션 A/B/C + 추천 → "진행해"
2. `mkdir -p ~/.openclaw/workspace/kmsg-doctor` + `python-oss-bootstrap` 스킬 로드
3. `pyproject.toml` (zero-deps, scripts=kmsg-doctor) + `.gitignore` (+ `*.sqlite` 추가)
4. **소스 9개 모듈 직접 작성** (Phase 0의 stub과 다름):
   - `models.py` — RawMessage, Card, CardNews (frozen dataclass + Literal type)
   - `exceptions.py` — KmsgDoctorError + 5 서브클래스
   - `kmsg_client.py` — **외부 도구 stdio 클라이언트** (subprocess + JSON-RPC, ⚠️ 4개 함정 주의)
   - `prefilter.py` — _SIMPLE_REACTIONS frozenset + _SYSTEM_PATTERNS tuple (substring 매칭)
   - `cache.py` — SQLite + ID-based upsert + 시간 윈도우 쿼리
   - `summarizer.py` — group_by_topic(30분 갭) + extract_speakers/request + generate_card_title
   - `formatter.py` — format_text(컬러) + format_telegram(Markdown) + format_json
   - `core.py` — sync_chat / summarize_chat 오케스트레이션
   - `cli.py` — argparse 4 서브 명령 (sync/summarize/status/chats) + 단축 사용
5. **CLI entry point** — `pyproject.toml` `[project.scripts] kmsg-doctor = "kmsg_doctor.cli:main"`
6. **venv + 설치** — `rm -rf venv && /usr/bin/python3 -m venv venv && pip install -e ".[dev]"` (⚠️ system python 3.8.8 함정)
7. **fixture 작성** — `tests/fixtures/sample_messages.json` (첨부 이미지의 실제 카드뉴스 3장과 매칭되는 시나리오)
8. **단위 테스트 32개** — conftest.py + test_prefilter(8) + test_cache(6) + test_summarizer(8) + test_formatter(4) + test_cli(6)
9. **pytest 1차** — 31/32 통과, 1개 실패 (system message "홍길동님이 입장하셨습니다" 가 substring 패턴으로 안 잡힘) → _SYSTEM_PREFIXES → _SYSTEM_PATTERNS (substring) 변경
10. **pytest 2차** — 32/32 통과 (0.14초)
11. **CLI 동작 검증** — `kmsg-doctor --version` + `kmsg-doctor --help` + `/Users/.../venv/bin/python3 -c "..."`로 실제 카드뉴스 3장 생성 확인
12. **README (다층 옵션 + 아키텍처 + 토큰 비용)** — 12KB 한/영 병기, 11개 섹션 (동기/설치/CLI/시나리오/아키텍처/토큰/디렉토리/로드맵/주의/감사)
13. **CHANGELOG** (Keep a Changelog 1.1.0) + **CONTRIBUTING** (4단계 튜토리얼: 새 필터/새 포맷터/디버깅/아키텍처)
14. **git init -b main** + commit + `gh repo create sigco3111/kmsg-doctor --public --description "<한글>" --source=. --remote=origin --push` (--license 빼고)
15. **v0.1.0 태그** 푸시 + `mcp_ddg_search_fetch_content`로 GitHub 페이지 렌더링 확인

### Phase 1.5 — 이름 변경 (kmsg-doctor → kakao-summary)

**사용자 트리거**: "kmsg-doctor는 프로젝트명으로 적합하지 않은것 같아. 다른 이름을 제안해봐"

**사용자 두 번째 트리거**: "kakao 단톡방 내용 요약을 직관적으로 알수 있는 제목이면 좋겠는데..."

**네이밍 의사결정** (사용자 선호 + 옵션 제시):
- A. `chat-doctor` (md-doctor/cron-doctor 시리즈 통일)
- B. `kakao-doctor` (kmsg-mcp 의존 명시)
- C. `cardnews` (직관적, 기능 중심)
- D. `kakao-digest` (digest = 요약의 IT/영어 컨벤션)
- E. `kakao-summary` (직관적, 한국어 "요약" 영어 컨벤션)
- F. `kakao-cardnews` (카드뉴스 명시)
- → 사용자 선택: **E. kakao-summary** ("직관적 + kakao + 기능명시" 모두 만족)

**이름 변경 6단계 시퀀스** (5분):
1. **브레인스토밍** (8개 옵션 → 4개 압축 → 추천 → 사용자 결정)
2. **`gh repo rename kakao-summary --yes`** (owner prefix 없이! `/` 때문에 거부됨)
3. **모든 파일의 옛 이름 일괄 변경** (sed):
   ```bash
   # Python 소스: import + module references
   find src tests -name "*.py" -exec sed -i '' 's/kmsg_doctor/kakao_summary/g' {} +
   # README/CHANGELOG/CONTRIBUTING: 하이픈 표기 + 언더스코어 표기 모두
   sed -i '' 's/kmsg-doctor/kakao-summary/g' README.md CHANGELOG.md CONTRIBUTING.md
   sed -i '' 's/kmsg_doctor/kakao_summary/g' README.md CHANGELOG.md CONTRIBUTING.md
   # 도큐먼트 내부에 남은 하이픈 표기 한 번 더
   find src tests -name "*.py" -exec sed -i '' 's/kmsg-doctor/kakao-summary/g' {} +
   ```
4. **디렉토리 rename** — `git mv src/kmsg_doctor src/kakao_summary` (git이 자동 감지, history 보존)
5. **venv 재생성 + pytest 재검증** — 32/32 통과 확인
6. **별도 커밋 + v0.1.0 태그 force-update**:
   ```bash
   git add -A
   git commit -m "refactor: rename kmsg-doctor → kakao-summary
   - <변경 이유>
   - <검증 결과>"
   git tag -d v0.1.0 && git push origin :refs/tags/v0.1.0
   git tag -a v0.1.0 -m "v0.1.0 - ... (프로젝트명: kakao-summary, 2026-06-16 rename)"
   git push origin v0.1.0
   ```

### 새 학습 (사례 1·2·3에 없는 것)
- **Phase 1 변형 = 풀 부트스트랩을 한 세션에**: 사용자가 "이번 PC에서 작업" / "에르메스 PC에서" 식으로 명시하면 Phase 0가 아닌 정식 10단계를 한 번에. 핵심 모듈 3~4개는 실제 동작, 30~50개 테스트 통과. **소요 35~45분**.
- **외부 도구 wrapping = 새로운 OSS 클래스**: kakao-summary는 자체 로직뿐 아니라 **다른 도구의 Python wrapper**. 이런 OSS는 (a) `*_client.py` 모듈이 외부 도구 stdio/subprocess 통합, (b) 나머지 로직은 우리 로직. README에 "전제 조건: X 설치 + 권한 필요" 명시 필수 (사용자 06-11 "데이터 ≠ 표시" 원칙).
- **사용자 첨부 이미지 → 형식 결정**: "이 카톡 카드뉴스처럼 만들어줘" → 첨부 이미지 분석 → JSON fixture로 시뮬레이션 → 같은 형식 생성. **fixture-first 개발**: 실제 외부 도구 없이도 형식 검증 가능. 단, **실제 외부 도구 호출은 사용자 PC에서** (이 PC에는 카톡 없음).
- **사용자 컨펌 기반 동적 길이 README**: README 12KB (cron-doctor의 9.5KB보다 김). 이유는 외부 의존성/kmsg-mcp 통합이라는 새 클래스라 **아키텍처 다이어그램 + 토큰 비용 분석 + 외부 의존 명시**가 필요. 짧은 README는 충분한 정보를 못 줌.
- **stdout 컬러 = formattable**: `format_text(use_color=False)` 옵션으로 CI에서도 깨지지 않게. Telegram Markdown는 `*` `_` `` ` `` escape 필수 (`text.replace("*", "\\*")`).
- **system message prefix → substring 패턴**: "님이 입장하셨습니다" prefix로 매칭하면 "홍길동님이 입장하셨습니다"가 안 잡힘. **substring 매칭**으로 변경 ("입장하셨습니다" 같은 핵심 동사만).
- **fixture-first 테스트가 진짜 회귀 방지**: sample_messages.json이 첨부 이미지의 카드뉴스 3장과 정확히 매칭 → `test_summarizer.py::test_summarize_creates_cardnews`로 fixture → 카드뉴스 형식 검증. **이게 다층 README + 32 테스트의 가치**.
- **이름 변경 워크플로 (Phase 1.5)**: 1세션 만에 부트스트랩 완료 + 이름 변경 모두 가능. **사용자 후회 신호는 1세션 내 발생** — 사용자가 "kmsg-doctor는 적합하지 않은것 같아"라고 했을 때 즉시 옵션 3~5개 + 추천을 다시 제시. **사용자 "kakao-summary로 하자" 같은 답을 받으면 5분 만에 6단계 rename 워크플로 실행**.
- **이름 결정 후회 패턴 = 두 번째 교훈**: 1차 결정 (kmsg-doctor) 시 "md-doctor / cron-doctor / **kmsg-doctor**" 시리즈 일관성 추천을 받아 진행했지만, 사용자는 "직관성"을 더 중시. **다음부터는 브레인스토밍 단계에서 "기능 명시 + 도메인 직관성" 모두 만족하는 옵션을 추천**해야 함. 시리즈 일관성만으로 추천하면 사용자가 1세션 만에 rename 요청.
- **`gh repo rename` owner prefix 함정**: `gh repo rename sigco3111/kakao-summary`는 `/` 때문에 "New repository name cannot contain '/' character" 에러. `gh repo rename <new-name> --yes` 형식만. ⚠️ `gh repo rename --help` 출력에는 명시 안 됨 — 도움말이 거짓말.
- **GitHub redirect는 자동**: repo rename 후 옛 URL `https://github.com/sigco3111/kmsg-doctor`는 그대로 살아있고 `kakao-summary`로 자동 리다이렉트. **사용자가 기존 URL로 클론해도 안전**. 단, 로컬 `git remote` URL은 수동 업데이트 필요.
- **v0.1.0 태그 force-update 패턴**: 같은 SHA에 같은 태그를 다시 발행하려면 로컬/원격 모두 삭제 후 재생성. 또는 v0.1.1 새 태그 발행 (이게 git 모범 사례). kakao-summary는 v0.1.0 그대로 force-update (이름만 바뀌었지 의미는 같음).

### 외부 도구 wrapping 의사결정 트리 (2026-06-16 정리)

새 OSS가 다른 도구의 wrapper일 때 다음을 결정:

| 결정 포인트 | 옵션 | 추천 | 이유 |
|---|---|---|---|
| 통합 방식 | pip 의존성 / subprocess / fork | **subprocess (stdio JSON-RPC)** | zero-deps 유지 + 버전 분리 + 격리 |
| 응답 파싱 | 라이브러리 / 직접 JSON | 직접 JSON (try/except 견고) | 의존성 0 + 포맷 변경 시 한 곳만 수정 |
| 캐시 | SQLite / JSON 파일 / 없음 | SQLite (ID-based upsert) | 시간 윈도우 쿼리 + 증분 sync에 최적 |
| LLM 통합 시점 | v0.1.0부터 / v0.2.0+로 연기 | **v0.2.0+로 연기** | 결정론적 v0.1.0 = 비용 0 + 즉시 응답, 사용자가 가치 검증 후 LLM 추가 |
| 출력 포맷 | 1개 / 2개 / 3개+ | 3개 (text/telegram/json) | 사용자 패턴 (텔레그램 DM) + CI/훅 통합 |

→ 이 의사결정 트리는 kakao-summary가 처음 작성한 것이며, 다음 외부 도구 wrapping OSS (예: `notion-doctor`, `github-doctor` 등) 부트스트랩 시 그대로 재사용.

### 네이밍 의사결정 트리 (2026-06-16 kakao-summary 후회 패턴)

| 결정 포인트 | 옵션 | 추천 (2026-06-16 이전) | **수정된 추천 (2026-06-16 이후)** | 이유 변경 |
|---|---|---|---|---|
| 이름 | 시리즈 통일 vs 직관성 | 시리즈 통일 (md-doctor, cron-doctor) | **직관성 (기능 + 도메인)** | 사용자가 1세션 만에 rename 요청했음 |
| 신조어 사용 | OK / 회피 | OK (kmsg-doctor) | **회피 (kakao-summary)** | 신조어는 다른 사람이 검색/기억 어려움 |
| 도메인 prefix | 있음 / 없음 | 있음 (kmsg-) | **있되 명확한 브랜드 (kakao-) 또는 범용 (chat-)** | "kmsg"는 kmsg-mcp 종속처럼 보임 |

→ **다음 OSS 부트스트랩 시**: 브레인스토밍 단계에서 "기능 명시 + 도메인 직관성" 모두 만족하는 옵션을 추천. 시리즈 일관성은 부수적 고려사항 (만드는 게 우선, 통일은 나중에 `chat-doctor` 시리즈로 묶어도 됨).

---

## 사례 5: kakao-summary decommission (2026-06-16, 같은 세션, 사용자 명시 요청)

**트리거**: v0.1.0 완성 + 실제 카톡 연동 27개 성공 후 사용자가 "어제 내용 정리" 요청 → kmsg의 "최근 N개" 한계로 어제 데이터 fetch 불가 → 사용자 "해당 프로젝트를 제거하자. 저장소도 제거해줘."

**소요**: ~10분 (5단계 절차)
**결과**: GitHub repo 삭제 + 모든 로컬/시스템 잔재 100% 정리

### 5단계 시퀀스 (decommission)
1. **GitHub repo 삭제**: `gh repo delete sigco3111/kakao-summary --yes` + 404 확인
2. **로컬 워크스페이스 정리**: `trash ~/.openclaw/workspace/kakao-summary` + `trash ~/kmsg-mcp/`
3. **외부 의존성 uninstall**: `brew uninstall channprj/tap/kmsg` (⚠️ transitive deps python@3.13, ripgrep, fzf 자동 제거됨) + `trash ~/.local/share/kmsg-mcp/` + `trash ~/.cache/kakao-summary/` + `trash ~/Library/{Logs,Caches}/Homebrew/kmsg*`
4. **셸 환경변수 정리**: `sed -i '' '/^# kakao-summary:/d; /^export KMSG_BIN=/d' ~/.zshrc`
5. **메모리 업데이트** (선택): memory tool drift 가능성 → 다음 세션에 안전 정리

### 새 학습 (사례 1·2·3·4에 없는 것)
- **decommission = 작업의 정당한 부분**: 사용자가 명시적으로 "제거" 요청 시 5단계 절차는 정상 작업. **trash > rm 원칙** (사용자 06-11 선호, 복구 가능).
- **brew uninstall transitive deps 부작용**: kmsg uninstall 시 **python@3.13 (74MB), ripgrep, fzf** 자동 제거. **다른 용도로 쓰고 있었다면 `brew install` 재설치 필요**. 예방: `brew deps <formula> --installed`로 미리 확인.
- **GitHub redirect는 보존**: `kakao-summary` 삭제 전 `kmsg-doctor`로 rename했었던 history는 그대로 살아있음 (GitHub redirect chain). 최종적으로 repo 삭제되면 redirect chain도 사라짐.
- **memory tool drift**: `MEMORY.md`에 같은 날 추가된 다른 entry가 있어서 round-trip 거부됨. 백업은 자동 생성 (`.bak.<timestamp>`). **다음 세션에 한 번에 정리하는 게 안전**.
- **사용자 06-11 "데이터 ≠ 표시" 원칙의 OSS 적용**: kakao-summary는 "어제 데이터"라는 사용자 요구를 충족 못 시키는 도구. **사용자가 원하는 것을 못 주는 도구는 빠르게 decommission** (1세션 만에 결정). **decommission도 작업의 일부** — 굳이 더 붙잡고 fix하지 않음.

### 검증된 절차
```bash
# 1. GitHub
gh repo delete sigco3111/<name> --yes
gh repo view sigco3111/<name>  # 404 확인

# 2. 로컬 (trash 우선)
trash ~/.openclaw/workspace/<name> ~/.<name>-mcp/

# 3. 외부 의존성 + 잔재
brew uninstall <tap>/<formula>  # ⚠️ transitive deps 점검
trash ~/.local/share/<name>-mcp/ ~/.cache/<name>/ ~/Library/{Logs,Caches}/Homebrew/<formula>*
find ~ -maxdepth 5 -iname "*<name>*"  # 출력 없으면 깨끗

# 4. 환경변수
if grep -q "<NAME>" ~/.zshrc 2>/dev/null; then
  sed -i '' '/^# <package>:/d; /^export <NAME>=/d' ~/.zshrc
fi

# 5. 메모리 (선택, drift 가능)
# memory tool이 거부하면 다음 세션에 정리
```

---

## 시퀀스 요약 (재현 가능한 10단계)

```bash
gh repo create sigco3111/<name> --public --description "<한글>" --license MIT
git clone https://github.com/sigco3111/<name>.git ~/Documents/<name>/
cd ~/Documents/<name>
# 1. .gitignore (Python std)
# 2. pyproject.toml (setuptools>=68, name만, zero-deps, scripts)
# 3. pytest.ini
# 4. src/<pkg>/{__init__, __main__, cli, core, models, exceptions}
# 5. src/<pkg>/<sub>/{__init__, <impl1>, <impl2> 스텁}
# 6. tests/test_cli.py (6~16개)
python3 -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"
pytest  # 6+ 통과 확인
md-doctor <(echo "# test")  # CLI 스모크

# 7. README.md (한글 + 영문 부록, 다층 옵션)
# 8. CHANGELOG.md
# 9. CONTRIBUTING.md
# 10. .github/workflows/ci.yml + action.yml
git add -A
git commit -m "feat: initial project skeleton (v0.1.0) ..."
git push -u origin main
git tag -a v0.1.0 -m "..."
git push origin v0.1.0
gh repo edit sigco3111/<name> --description "<한글>"
```

## Phase 0 변형 시퀀스 (다른 PC에서 작업 케이스)

```bash
# 1. 워크스페이스에 디렉토리
mkdir -p ~/.openclaw/workspace/<name>
cd ~/.openclaw/workspace/<name>

# 2. 파일 4종 작성 (write_file)
README.md (다층 옵션 구조, "Phase 1+ 작업은 다른 PC에서" 명시)
CHANGELOG.md (0.1.0 Added/Notes만)
CONTRIBUTING.md (4단계 튜토리얼)
LICENSE (MIT)
.gitignore (Python std)

# 3. 소스 스켈레톤
mkdir -p src/<pkg>/<sub1> src/<pkg>/<sub2> tests/fixtures .github/workflows
touch src/<pkg>/__init__.py src/<pkg>/__main__.py ... (모든 .py + .gitkeep)
# 각 스텁에 docstring 가이드 작성 (write_file) — 책임/trade-off/패턴/코드 골격

# 4. git init + 커밋
git init -b main
git add -A
git commit -m "docs: initial project skeleton (v0.1.0) - Phase 0"

# 5. gh repo create (--license 빼고 안전하게)
gh repo create sigco3111/<name> --public \
  --description "<한글 한 줄>" \
  --source=. --remote=origin --push

# 6. 태그 푸시
git tag -a v0.1.0 -m "v0.1.0 - Phase 0: 스켈레톤 + 문서"
git push origin v0.1.0
```

## Phase 1 변형 시퀀스 (이 PC에서 직접 풀 부트스트랩)

```bash
# 1. 브레인스토밍 (5 결정 포인트, 옵션 A/B/C + 추천)
#    ⚠️ 이름은 "기능 + 도메인 직관성" 모두 만족하는 옵션 추천
# 2. 워크스페이스 + pyproject.toml + .gitignore (Phase 0와 동일)
# 3. 소스 9개 모듈 직접 작성 (스텁 아님, 핵심 3~4개는 실제 동작)
# 4. CLI entry point 등록
# 5. venv + pip install -e ".[dev]" (system python 버전 확인!)
# 6. fixture + 단위 테스트 6~32개
# 7. pytest + 실패 디버그 (1~2회 반복)
# 8. README (다층 옵션 + 아키텍처 + 토큰 비용) + CHANGELOG + CONTRIBUTING
# 9. git init + commit + gh repo create + push + v0.1.0 태그
# 10. GitHub 페이지 렌더링 확인
```

## Phase 1.5 변형 시퀀스 (이름 변경 워크플로, 5분)

```bash
# 1. 브레인스토밍 (옵션 3~5개 + 추천)
# 2. gh repo rename
gh repo rename <new-name> --yes  # owner prefix 없이!

# 3. git remote URL 업데이트
git remote set-url origin https://github.com/sigco3111/<new-name>.git

# 4. 모든 파일의 옛 이름 일괄 변경
find src tests -name "*.py" -exec sed -i '' 's/<old_module>/<new_module>/g' {} +
sed -i '' 's/<old-name>/<new-name>/g' README.md CHANGELOG.md CONTRIBUTING.md
sed -i '' 's/<old_module>/<new_module>/g' README.md CHANGELOG.md CONTRIBUTING.md
find src tests -name "*.py" -exec sed -i '' 's/<old-name>/<new-name>/g' {} +

# 5. 디렉토리 rename (git mv)
git mv src/<old_module> src/<new_module>

# 6. venv 재생성 + pytest 재검증
rm -rf venv && /usr/bin/python3 -m venv venv
source venv/bin/activate
pip install -e ".[dev]"
pytest  # 32/32 통과 확인

# 7. 별도 커밋 + v0.1.0 태그 force-update
git add -A
git commit -m "refactor: rename <old> → <new> ..."
git tag -d v0.1.0 && git push origin :refs/tags/v0.1.0
git tag -a v0.1.0 -m "v0.1.0 - ... (rename)" && git push origin v0.1.0
```

## Phase 2 — Decommission 시퀀스 (제거, ~10분)

```bash
# 1. GitHub repo 삭제
gh repo delete sigco3111/<name> --yes
gh repo view sigco3111/<name>  # 404 확인

# 2. 로컬 (trash 우선)
trash ~/.openclaw/workspace/<name> ~/.<name>-mcp/

# 3. 외부 의존성 + 잔재
brew uninstall <tap>/<formula>  # ⚠️ transitive deps 점검
trash ~/.local/share/<name>-mcp/ ~/.cache/<name>/ ~/Library/{Logs,Caches}/Homebrew/<formula>*
find ~ -maxdepth 5 -iname "*<name>*"  # 출력 없으면 깨끗

# 4. 환경변수
if grep -q "<NAME>" ~/.zshrc 2>/dev/null; then
  sed -i '' '/^# <package>:/d; /^export <NAME>=/d' ~/.zshrc
fi

# 5. 메모리 (선택, drift 가능)
# memory tool이 거부하면 다음 세션에 정리
```

## 다른 PC에서 작업 시작 (Phase 0 결과물 받기)

```bash
git clone https://github.com/sigco3111/<name>.git
cd <name>
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"
pytest
```

**예상 시간: 3분** (clone + 설치 + 테스트). 이게 무사히 통과하면 환경 검증 끝.

---

## 사례 7: gh-traffic-monitor (2026-06-23, v0.1.0 → v0.1.1 — Phase 1, 데이터 시각화 백엔드)

**트리거**: 사용자가 hyeonsangjeon/Repolis를 sigco3111에 맞게 fork하고 싶다고 요청 → 분석: 원본 빌더는 3-layer CSV 입력 기대. **sigco3111 계정에는 그 데이터를 수집하는 OSS가 없음** → "gh-traffic-monitor 신규 제작 → 우리 fork Repolis의 빌더가 직접 읽을 수 있는 단일 레이어 CSV 출력" 결정. 사용자 "권장하는 방법은?" → 옵션 비교 후 추천한 **"별도 데이터 백엔드 + 빌더 단순화"** 채택.

**소요**: 단일 세션 ~25분 (v0.1.0) + ~5분 (v0.1.1 PEP 604 호환성 픽스)
**결과**: 9개 모듈 + 23/23 테스트 통과 (0.64s) + v0.1.0 → v0.1.1 태그 + GitHub public + **154개 sigco3111 repo 실제 트래픽 수집 검증** (3분 13초, 0 실패) + CI `conclusion: success`

### Phase 1 변형의 핵심 차이 (이전 사례들과 다른 점)
- **"데이터 시각화 백엔드" = 9번째 OSS 클래스** — 변환(transcoding) / 진단(diagnosis) / wrapping / adaptor에 이어. **자체 로직 + 외부 데이터 소스 + 시각화 도구의 중간 계층**.
- **외부 도구 wrapping이 아닌 외부 API 직접 호출** — kakao-summary가 kmsg-mcp(stdio)를 wrapping했다면, gh-traffic-monitor는 **GitHub REST API를 직접 호출** (stdlib urllib). **pip 의존성 0** 유지.
- **macOS keyring 토큰 자동 추출** — `gh auth token` subprocess 호출로 환경 변수 (`GH_TOKEN`/`GITHUB_TOKEN`) fallback + keyring 자동 사용. **cron 잡에서 토큰 안전 사용 + 환경 변수 노출 없음**.
- **append/overwrite 누적 패턴** — 일별 CSV는 같은 날 재실행 시 overwrite (14-day rolling 갱신 반영), 평생 누적은 `_cumulative.csv`에 별도 저장. **CSV DictReader 이중 가드** (함정 25) — `row.get("date")` 후 `if not date: continue` 필수.

### 시퀀스
1. **브레인스토밍** (5 결정 포인트) — 이름(gh-traffic-monitor vs github-traffic-collector vs repo-traffic-csv) / 데이터 소스(GitHub REST + urllib) / 저장 포맷(단일 레이어 CSV) / 의존성(stdlib only) / CLI 패턴(argparse subparsers). 옵션 A/B/C + 추천 → "권장하는 방법으로" 받음 → 즉시 실행.
2. `gh repo create sigco3111/gh-traffic-monitor --public --description "<한글>" --license MIT`
3. `git clone` + `mkdir -p src/gh_traffic_monitor/{__init__,__main__} tests .github/workflows`
4. **소스 9개 모듈 직접 작성**:
   - `models.py` — TrafficRecord, CumulativeTotals, CollectionResult (frozen dataclass + Literal)
   - `exceptions.py` — GTMError + 5 서브클래스 (GitHubAPIError, RateLimitError, AuthError, StorageError, ConfigError)
   - `github_api.py` — stdlib urllib + gh CLI subprocess (auth token 추출) + rate limit 자동 감지
   - `storage.py` — CSV append/overwrite + 일별 → 누적 집계 + 14-day rolling overwrite 처리
   - `core.py` — 4단계 오케스트레이터 (조회 → 수집 → 저장 → 집계)
   - `cli.py` — argparse subparsers (collect/status/repos)
   - `__main__.py` — `from .cli import main; sys.exit(main())` (함정 9a 적용 — 처음부터 채움)
5. **CLI entry point** — `pyproject.toml`의 `[project.scripts]`에 `gh-traffic-monitor = "gh_traffic_monitor.cli:main"` 등록
6. **venv + pip install -e ".[dev]"** + `pip install ruff pytest` (dev deps)
7. **단위 테스트 23개** — conftest.py + test_cli(5) + test_exceptions(4) + test_models(6) + test_storage(7) — **5개 실패 → 23/23 통과** (첫 시도 22/23, 한 가지 추가 후 23/23)
8. **실제 트래픽 수집 검증** — `python -m gh_traffic_monitor --owner sigco3111 collect` → 154개 repo 데이터 수집 (3분 13초, 0 실패), `_cumulative.csv` 생성
9. **status 명령 검증** — 154개 repo 누적 통계 요약 출력
10. **README (다층 옵션 + GitHub Traffic API 24~48h 지연 명시)** — 9KB 한/영 병기 + 옵션 5종 + 사용 시나리오 4개 + GitHub Actions 예시 + 로드맵 4단계
11. **CHANGELOG + CONTRIBUTING** — 0.1.0 Added/Notes, CONTRIBUTING는 5단계 튜토리얼
12. **GitHub Actions CI** — Python 3.9/3.10/3.11/3.12 매트릭스 + ruff + pytest + CLI smoke
13. **`.github/workflows/daily-collect.yml` 예시** — 매일 cron 패턴
14. `git init -b main && add -A && commit -m "feat: initial project skeleton (v0.1.0) ..."`
15. `git push -u origin main` + `git tag -a v0.1.0 -m "..."` + `git push origin v0.1.0`
16. `gh repo edit sigco3111/gh-traffic-monitor --description "<한글>"` (About 한글화)

### v0.1.1 — PEP 604 union type 호환성 픽스 (같은 세션)

**트리거**: v0.1.0 push 직후 CI 첫 실행 결과 `conclusion: failure`. **TypeError: unsupported operand type(s) for |: 'type' and 'NoneType`**.

**진단** (GitHub Actions URL 직접 fetch):
```
tests/test_exceptions.py:4: in <module>
    from gh_traffic_monitor.exceptions import (...)
src/gh_traffic_monitor/exceptions.py:16: in <module>
    class RateLimitError(GitHubAPIError):
src/gh_traffic_monitor/exceptions.py:19: in RateLimitError
    def __init__(self, reset_at: str | None = None):
E   TypeError: unsupported operand type(s) for |: 'type' and 'NoneType'
=========================== 2 errors in 0.14s =============================
```

**원인**: 로컬 Python 3.12에서 `str | None` (PEP 604) 신택스 사용 → **CI는 Python 3.9 매트릭스에서 `TypeError`로 import 실패**. `requires-python = ">=3.9"`인데도 로컬 검증이 3.12라서 못 잡음.

**수정 패턴 (SKILL.md 함정 30번으로 정식 기록)**:
- `from __future__ import annotations`는 이미 모든 파일에 있었음 (확인됨)
- `str | None` → `Optional[str]` / `dict | None` → `Optional[dict]` (typing import 추가)
- 3곳 수정 (exceptions.py, github_api.py, core.py) — `from typing import Optional` 추가
- patch가 두 곳에서 `from __future__ import annotations` 중복 추가하는 부작용 → sed 정리

**검증**:
- `/usr/bin/python3` (3.8 시스템) 으로 import 단계 검증 → 5개 예외 클래스 + github_api 함수 3개 + core 함수 import OK
- 로컬 venv 23/23 테스트 통과
- CI 재실행 → `conclusion: success`

**소요**: ~5분 (grep + 6 patch + 검증 + commit + tag v0.1.1)
**교훈**: **로컬 Python 버전 ≠ CI 매트릭스 최소 버전**. 부트스트랩 첫 단계에서 `from __future__ import annotations` 박아두거나 `Optional[X]` 명시 사용.

### 새 학습 (이전 6개 사례에 없는 것)
- **"데이터 시각화 백엔드" OSS 클래스 = 9번째** — 변환 / 진단 / wrapping / adaptor에 이어. 사용자가 "X 저장소처럼 우리도 할 수 있을까?" 류 요청 시 **백엔드 OSS가 없으면 같이 만드는 게 정석**.
- **`gh auth token` subprocess = macOS keyring 토큰 안전 추출** — `os.environ["GH_TOKEN"]` fallback + keyring. cron 잡 / GitHub Actions 모두에서 안전. **pip 의존성 0 유지하면서 GH 인증**.
- **CSV append vs overwrite 정책** — 일별 CSV는 같은 날 재실행 시 **overwrite** (GitHub Traffic API 14-day rolling 갱신 반영), 누적 CSV는 **append 기반 diff**. 이게 없으면 첫 실행에서 같은 데이터가 2번 들어가서 uniqueness 깨짐.
- **GitHub Traffic API 24~48h 지연 명시** (함정 28) — README 첫 줄에 박아두지 않으면 사용자가 "왜 uniques가 0이야?" 11번 질문. **proactive documentation 패턴**.
- **CLI smoke 테스트** (함정 9a) — `python -m gh_traffic_monitor --version` + `--help` 둘 다 정상 출력 검증. **`__main__.py`가 cli.main 호출하도록** 처음부터 작성.
- **PEP 604 호환성 함정 30번** — `str | None`은 Python 3.10+, CI 3.9 매트릭스에서 깨짐. **`from __future__ import annotations`는 모든 파일에 박아두기** + 첫 단계에서 적용.

---

## 사례 8: Repolis (2026-06-23, v0.1.0 → v0.2.0 → v0.2.1 — 다른 사람 스타 OSS fork)

**트리거**: 사용자가 hyeonsangjeon/Repolis URL 공유 + "우리 저장소도 이렇게 할 수 있을까?" → 분석: 196개 파일 (Three.js 단일 HTML 185KB + Python 빌더 + PartyKit 멀티플레이어) / 60~80개 repo 도시. **sigco3111에 적용하려면 3가지 함정** — (1) 빌더가 3-layer CSV 입력 기대 (우리엔 없음) → 어댑터 vs 빌더 단순화 결정, (2) 156개 repo 다 그리면 도시 균일함 → 트래픽 그라데이션 필수, (3) GH_PAT 별도 발급 필요한지 점검. **사용자 결정**: "모두 추천한 것으로 진행할께" → 모든 추천 옵션 채택 (Phase 1 풀세션, 빌더 단순화, Ghibli 톤, GitHub Pages).

**소요**: ~1시간 (Phase 0~6 한 세션) + v0.2.0 ~30분 + v0.2.1 README 최종 갱신 ~10분
**결과**: sigco3111/Repolis v0.1.0 라이브 (155개 repo, 14 다운타운 + 141 동네) → v0.2.0 (LLM 택시 3모드 + Contribution Library 큐레이션 + 이중 cron) → v0.2.1 (README 최종 갱신, 라이브 데모 임베드)

### 이 사례의 차별점 — 다른 사람 스타 OSS fork + 빌더 단순화
- **원본 hyeonsangjeon/Repolis의 빌더는 3-layer CSV 입력** — `data/logs/<name>.csv` + `data/logs/clones/<name>.csv` + `data/logs/metadata/<name>.csv`. 우리 신규 gh-traffic-monitor는 **단일 레이어 출력** (`logs/YYYY-MM-DD.csv` + `_cumulative.csv`). **어댑터 계층 추가하지 않고 빌더를 단순화** — "데이터 ≠ 표시" 원칙 (사용자 06-11 학습). 우리가 필요한 건 cumulative uniques/clones/forks/views 4개 metric. stars/language/description은 `gh api /repos` 한 번 더 호출로 충분.
- **v0.1.0 → v0.2.0 한 세션 업그레이드** — 사용자가 "v0.2.0 진행" 한마디로 묵묵히 + 최종 보고 워크플로 그대로 적용. 변경 6개 파일 / 한 세션. **소요 시간 ~30분** (원래 예상 1~2시간 → 학습된 워크플로 덕에 단축).
- **v0.2.0이 기능 추가 마지막 버전** — 사용자 신호: "이후 로드맵은 기능적인 추가는 없이 성능개선만 되는거지?" → **v0.2.0 = feature freeze, v0.3.0+ = 성능/안정성/관측성/자동화만**. **이 신호는 다음 OSS 작업 워크플로에 그대로 적용** — 사용자 승인 없이 새 기능 추가 안 함.
- **v0.2.1 = README 최종 갱신** — 라이브 데모 임베드 + 배지 8개 + 목차 + 다층 옵션 + 로드맵 명시. **코드/워크플로/도시 데이터 동일 변경 없음** (문서만). 사용자: "여기에서 프로젝트를 마무리하고, 리드미파일을 더욱 화려하고 보기 좋게 갱신해줘. (라이브데목는 꼭 포함해줘.)"

### 시퀀스 (Phase 1 fork 변형)
1. **브레인스토밍** (5 결정 포인트) — 스코프(C: 도시 + Local 택시만) / repo 필터(전체 156개 공개) / traffic-monitor(신규) / 톤(Ghibli) / 호스팅(GitHub Pages) / 작업 위치(이 PC 풀세션). "권장하는 방법은?" 받음 → 즉시 실행.
2. **환경 스캔** — sigco3111 = 170 repo (공개 156, 비공개 14, fork 3), gh CLI 이미 `repo` scope 인증 → **GH_PAT 별도 발급 불필요**.
3. **gh-traffic-monitor 신규 제작** (사례 7) → 빌더가 `_cumulative.csv` 직접 read.
4. `gh repo create sigco3111/Repolis --public --description "<한글>" --license MIT`
5. `git clone` + index.html (185KB 단일 파일) + 정적 자산 가져오기 (`party/`, `api/`, `cloudflare/`, `.nojekyll`, `partykit.json`, `.github/workflows/refresh.yml`). `.dotfile`은 f-string syntax error 회피 위해 `curl -sL` 직접 다운로드 (함정 9c).
6. **빌더 단순화** (3-layer → 1-layer) — `scripts/build_repos.py` 8.6KB로 직접 작성, gh CLI API + `_cumulative.csv` 통합.
7. **빌더 실행 검증** — `python3 scripts/build_repos.py` → 155개 repo 빌드 성공 (14 다운타운 + 141 동네).
8. **index.html 미세 조정** — `const OWNER = 'sigco3111'` + meta tag canonical URL + `LIBREPO=null` (Library 비어있음).
9. **GitHub Actions refresh.yml** — 6시간 cron + workflow_dispatch + push paths. `actions/checkout@v4` + `actions/setup-python@v5` + `gh-traffic-monitor` 설치 + collect + build + commit + push.
10. **GitHub Pages 자동 활성화** (함정 9b) — `gh api repos/sigco3111/Repolis/pages -X POST -f build_type=legacy -F 'source[branch]=main' -F 'source[path]=/'` → 1~2분 후 `HTTP/2 200`.
11. **README 다층 옵션** — 한/영 병기 + gh-traffic-monitor 데이터 흐름 다이어그램 + 3가지 옵션 (우리 도시 / 본인 도시 / Library 큐레이션) + 사용 시나리오.
12. **CHANGELOG + About 한글화** — `gh repo edit --description "<한글>"`.

### v0.2.0 업그레이드 시퀀스 (사용자 "v0.2.0 진행" 한마디로 묵묵히 + 최종 보고)
1. **브레인스토밍** (4 결정 포인트) — 택시 업그레이드 + Library + Social preview 옵션 a 추천. "권장하는 방법은?" 받음 → 즉시 실행.
2. **택시 아키텍처 분석** — hyeonsangjeon이 **이미 3모드 다 구현** (Local + WebLLM + AI proxy) — 코드 그대로 활용. 옵션 그대로 두고 default만 Local 유지 (zero-deps 철학).
3. **Contribution Library 큐레이션** — 6 카테고리 × 23 작품 (🛠️ 시그니처 OSS / 🎮 게임 / 🤖 AI 자동화 / 🏘️ 커뮤니티 / 🎨 3D / 📚 학습). **데이터 ≠ 표시** — sigco3111 OSS/코드 위주, 학술 카테고리 제거.
4. **이중 cron 자동화** — traffic-refresh.yml (4시간마다, gh-traffic-monitor만) + refresh.yml (매일 1회, 전체 빌드). **월 ~210회** (180 + 30) — 한도 2,000분의 10%.
5. **Social preview PNG** — `sips -s format png -z 640 1280 assets/banner.svg --out assets/social-preview.png` (macOS native, 1280×640 PNG 342KB).
6. **commit + tag v0.2.0**.

### v0.2.1 README 최종 갱신 시퀀스
1. **README 211줄 → 350줄** — 라이브 데모 메인 진입점 + 배지 8개 + 목차 + 우리 도시 한눈에 (점수 상위 5 + 언어 분포 표) + 작동 원리 다이어그램 + 3가지 옵션 안내 + 택시 3모드 비교표 + 로드맵 명시 + 기술 스택 + 감사의 말.
2. **CHANGELOG v0.2.1** — "이 버전은 문서만 변경. 코드/워크플로/도시 데이터 동일".
3. **commit + tag v0.2.1** → GitHub Pages 자동 갱신.

### 새 학습 (이전 7개 사례에 없는 것)
- **"다른 사람 스타 OSS fork + 빌더 단순화" 변형 = 11번째 OSS 클래스** — 변환 / 진단 / wrapping / adaptor / 데이터 시각화 백엔드에 이어. **원본 스타 OSS + 우리 신규 백엔드 OSS의 통합 사례**. SKILL.md의 "다른 사람 OSS fork + 빌더 통합 변형" 섹션 참조.
- **"v0.2.0 = feature freeze" 사용자 신호** — "이후 로드맵은 기능적인 추가는 없이 성능개선만 되는거지?" → 사용자는 **프로젝트 마무리 선언** + **자동화/성능/관측성 중심의 점진적 개선** 선호. 다음 Repolis 작업 시 자동화 + 안정성 + 성능만 다룸 (사용자 승인 없이 새 기능 추가 안 함).
- **사용자 "권장하는 방법은?" 신호 = 브레인스토밍 옵션 + 추천을 받겠다는 의도** — 옵션 3개 + 추천 제시 → 사용자 "권장하는 방법" → 즉시 실행. **`"그대로 진행해"` 와 `"권장하는 방법은?"`은 동의어** (둘 다 옵션 + 추천 받겠다는 의미).
- **README 라이브 데모 임베드 = v0.2.1 종료 신호** — 사용자가 "라이브 데모는 꼭 포함해줘" 명시 → README 첫 줄 + 배너 SVG + 라이브 URL을 메인 진입점으로 부각. **사용자 피드백: 프로젝트 마무리 = 문서 마무리** (코드 변경 없는 최종 정리).
- **macOS `sips` SVG→PNG 변환** (함정 29b) — `pip install` 없이 macOS 기본 도구로 SVG→PNG 변환. 1280×640 정확히 맞추려면 `-z 640 1280` 명시.
- **GitHub Pages 활성화 두 번 째 검증** (함정 9b 재확인) — `gh api ... -X POST -f build_type=legacy -F 'source[branch]=main' -F 'source[path]=/'` 패턴. gh CLI `--enable-pages` 옵션은 도움말만 출력.

---

## 📊 8개 사례 메타 비교 (2026-06-23 업데이트)

| | hwp2md | md-doctor | cron-doctor | kakao-summary | opencode-trading | opencode-harness-bridge | **gh-traffic-monitor** | **Repolis** |
|---|---|---|---|---|---|---|---|---|
| **날짜** | 2026-06-08 | 2026-06-09 | 2026-06-16 | 2026-06-16 | 2026-06-17 | 2026-06-17 | **2026-06-23** | **2026-06-23** |
| **소요** | ~30분 | ~25분 | ~20분 | ~40분 | ~25분 | ~30분 | **~25분 (+ 5분 v0.1.1 픽스)** | **~1시간 + 30분(v0.2.0) + 10분(v0.2.1)** |
| **버전** | v1.0.0 | v0.1.0 | v0.1.0 (Phase 0) | v0.1.0 (decomm) | v0.1.0 (Phase 0) | v0.1.0 (Phase 1) | **v0.1.0 → v0.1.1** | **v0.1.0 → v0.2.0 → v0.2.1** |
| **테스트** | 8 | 16 | 0 (다른 PC) | 32 | 18 | 9 | **23** | **0 (빌더는 155개 repo 빌드 검증)** |
| **변형** | 정식 10단계 | 정식 10단계 | Phase 0 | Phase 1 + rename + decomm | Phase 0 (adaptor) | Phase 1 (메타 adaptor) | **Phase 1 (데이터 시각화 백엔드)** | **다른 사람 OSS fork + 빌더 단순화** |
| **핵심 학습** | 백엔드 디스패처 | models.py + nargs="?" | 스텁 docstring + mkdir race | stdio JSON-RPC + SQLite | zero-deps adaptor + sys.exit() | N:M + 4-tier + secret | **stdlib urllib + gh auth token + PEP 604 호환** | **3-layer→1-layer 빌더 + GitHub Pages 자동 활성화 + v0.2.0 feature freeze 신호** |
| **클래스** | 변환 | 진단 | 진단 | wrapping (decomm) | adaptor (1:1) | adaptor (N:M) | **데이터 시각화 백엔드** | **다른 사람 OSS fork** |
| **외부 의존** | hwp5/olefile | stdlib only | stdlib only | kmsg-mcp (subprocess) | TradingCodex (zero-deps) | Claude Code/Codex 하니스 | **GitHub REST API (stdlib urllib)** | **Three.js (단일 HTML 185KB) + gh CLI + gh-traffic-monitor** |
| **이름 변경 횟수** | 0 | 0 | 0 | 1 | 0 | 0 | **0** | **0 (fork만, OWNER 교체)** |
| **decommission** | 아니오 | 아니오 | 아니오 | 예 | 아니오 | 아니오 | **아니오** | **아니오 (v0.2.0 = feature freeze, 성능만)** |
| **CI 매트릭스** | 3.9~3.12 | 3.9~3.12 | 3.9~3.12 | 3.9~3.12 | 3.11~3.13 | 3.9~3.12 | **3.9~3.12 (v0.1.1에서 PEP 604 픽스)** | **GitHub Actions schedule (cron)** |

→ **총 8개 사례 / 11번째 OSS 클래스 (다른 사람 OSS fork)**. 사례 7 (gh-traffic-monitor)와 사례 8 (Repolis)는 **같은 세션에서 연쇄 생성** — 데이터 백엔드 OSS + 시각화 OSS가 한 세션에서 다 만들어짐. **소요 시간 단축 추세**: kakao-summary 40분 → gh-traffic-monitor 25분 (v0.1.0) / 5분 (v0.1.1 픽스) → Repolis v0.2.0 30분 (사용자가 옵션 + 추천을 빠르게 결정하는 워크플로의 효율).

**시간이 줄어드는 이유 (또는 늘나는 이유)**: 매번 같은 함정을 학습해서 사전에 회피. `authors` 이메일, `nargs="?"`, `mkdir` race, `gh --license` 모두 1~3번째 만에 마스터. kakao-summary (kmsg-doctor)는 시간이 더 든 이유가 **외부 도구 wrapping**이라는 새 클래스라 stdio/subprocess 4개 함정을 새로 학습 + 32개 테스트로 검증. **이름 변경 워크플로 (Phase 1.5)는 5분** — `gh repo rename`, sed 일괄 변경, `git mv`, venv 재생성, 태그 force-update만 알면 됨.

**kakao-summary가 1세션 만에 이름이 바뀐 이유**: 
- kmsg-doctor 결정 시 추천을 "md-doctor / cron-doctor / **kmsg-doctor**" 시리즈 통일로 제시
- 사용자는 "직관성"을 더 중시 → 1세션 만에 "kmsg-doctor는 적합하지 않음"
- 두 번째 브레인스토밍에서 "kakao 단톡방 내용 요약을 직관적으로 알수 있는 제목" 명시 → kakao-summary 선택
- **교훈**: 다음 OSS 부트스트랩 시 브레인스토밍에서 "기능 명시 + 도메인 직관성" 모두 만족하는 옵션을 추천. 시리즈 통일만으로 추천하면 1세션 rename 비용 발생.

**kakao-summary가 같은 세션에 decommission된 이유**:
- v0.1.0 완성 + 실제 카톡 연동(27개) 성공 후 사용자가 "어제 내용 정리" 요청
- kmsg의 "최근 N개" 한계로 **어제 데이터 fetch 불가** (AX 트리 스크롤 한계)
- 사용자 요구(과거 시점 데이터) 충족 불가 → "해당 프로젝트를 제거하자" 결정
- 5단계 절차로 ~10분 만에 100% 정리
- **교훈**: 사용자가 원하는 것을 못 주는 도구는 빠르게 decommission. 외부 도구 wrapping OSS는 **wrapping 대상 도구의 한계가 곧 우리 OSS의 한계**. 첫 부트스트랩 전에 "wrapping 대상 도구가 우리 요구사항 충족하는지" 먼저 검증 필요 (특히 macOS 비공식 API 도구류).

---

## 사례 6: opencode-trading (2026-06-17, v0.1.0 — Phase 0, **adaptor 클래스**)

**트리거**: 사용자가 monarchjuno/tradingcodex URL 공유 + "이걸 OpenCode에서 사용할 수 있나?" → 분석: Codex 전용 (`.codex/agents/*.toml`, `.codex/prompts/*`, `.codex/hooks/*`) + oh-my-openagent와 충돌 안 함 (에이전트 네임스페이스 다름) → "A) OpenCode용 어댑터 포크" 결정 → "다른 PC에서 작업" 명시

**소요**: 단일 세션 ~25분
**결과**: 5종 변환기 스텁 + 도메인 모델 5개 + CLI + 18 테스트 통과 (0.24s) + v0.1.0 태그 + GitHub public

### 이 사례가 새 클래스 — **adaptor (포맷 변환)**

hwp2md(포맷 변환), md-doctor/cron-doctor(진단), kakao-summary(wrapping)와 다른 클래스:
- **목적**: 외부 도구(A) → 외부 도구(B) 포맷 변환 (TradingCodex Codex → OpenCode)
- **zero-deps 어댑터 전략**: TradingCodex 본체를 import하지 않고 stdlib `tomllib`로 `.codex/agents/*.toml`만 읽어서 OpenCode JSON 생성. **adaptee 의존 X, 결과물 의존 O**.
- **MCP 실행 경계 = 그대로 재사용**: TradingCodex MCP 서버 + Django 서비스 + SQLite ledger는 범용이라 변환 불필요.
- **oh-my-openagent 스쿼드와 직교**: 에이전트 이름 1개도 겹치지 않음 (sisyphus/oracle/librarian vs head-manager/fundamental-analyst/technical-analyst). 1+9 specialist 토폴로지는 보존.

### 5개 결정 포인트 (브레인스토밍)

| 결정 | 옵션 | 추천 | 채택 |
|---|---|---|---|
| 이름 | `tcx-opencode` / `opencode-trading` / `trading-opencode-bridge` | **B (opencode-trading)** | ✅ |
| 저장소 owner | sigco3111 조직 / 본인 계정 | sigco3111 (시리즈 일관성) | ✅ |
| 구조 | 모노레포 (워크스페이스 템플릿 + 어댑터) / 어댑터 only | 모노레포 | ✅ |
| 라이선스 | MIT (시그니처) / Apache-2.0 (TradingCodex 본체와 통일) | MIT | ✅ |
| README 톤 | 한/영 병기 다층 / 영문 only / 한글 only | 한/영 병기 다층 | ✅ |

→ "그대로 진행해" 받음 → 즉시 실행 (cron-doctor 06-16 패턴 동일).

### 시퀀스 (cron-doctor Phase 0와 거의 동일, ~25분)
1. `gh repo create sigco3111/opencode-trading --public --description "<한글>"` (--license 빼고, 사례 3 학습)
2. `mkdir -p ~/.openclaw/workspace/opencode-trading && mkdir -p src/opencode_trading/{agents,converters} tests/fixtures .github/workflows` (race condition 회피, 사례 3 학습)
3. **도메인 모델 5개** (frozen dataclass + Literal type): `OpenCodeAgent`, `OpenCodeSkill`, `OpenCodeHook`, `OpenCodeMCP`, `OpenCodeWorkspace` (models.py 분리, 사례 2 학습)
4. **5종 변환기 스텁** (각 docstring에 "다른 PC 작업자용 가이드" 포함): codex_to_opencode / hooks / commands / mcp / workflows
5. **CLI** (`opencode-trading convert --workspace <path> [--dry-run]`): argparse subcommand handler
6. **테스트 18개** (4 파일): test_models(5) + test_codex_to_opencode(5) + test_converters(4) + test_cli(4)
7. **CI** (`.github/workflows/ci.yml`): Python 3.11/3.12/3.13 + ruff + mypy || true + pytest + smoke CLI
8. **README (10.4KB)** — 한/영 병기 + 결정 매트릭스 6개 + 사용 시나리오 4개 + Phase 0 다른 PC 작업 흐름 + 로드맵 4단계 + 디렉토리 구조 + 의존성 명시
9. `git init -b main && git add -A && git commit` (한 번에)
10. `git push -u origin main` + `git tag -a v0.1.0 -m "..."` + `git push origin v0.1.0`
11. `gh repo edit sigco3111/opencode-trading --description "<한글>"` (About 한글화)

### 새 학습 (사례 1~5에 없는 것)

- **adaptor OSS 클래스 = 네 번째 OSS 클래스**: 변환(transcoding) / 진단(diagnosis) / wrapping(wrapping)에 이어 adaptor. **zero-deps 어댑터 전략**이 핵심: adaptee를 import하지 않고 결과물(파일)만 읽어서 변환. 의존성 0, adaptee 버전 변경에 영향 없음, pip install 시간 <1초.
- **TomlLib = stdlib 어댑터의 핵심 도구**: Python 3.11+ `tomllib` (read-only) + `tomli_w` (optional, write). tomli를 의존성에 추가하지 말 것. v0.2.0+ 구현 시 핵심 import.
- **oh-my-openagent와 직교 가능 검증**: 에이전트 이름 1개도 겹치지 않음 + MCP 클라이언트는 둘 다 지원 + oh-my-openagent의 sisyphus가 TradingCodex MCP 도구 호출 가능 → **스쿼드 시스템과 어댑터가 충돌 안 함**. 이게 "그냥 MCP로 가볍게 붙일까, 어댑터 만들까" 결정의 기술적 근거.
- **CLI subcommand handler 함정 21번 — 직접 발생**: `_cmd_convert`에서 `if not workspace.exists(): print(...); return 2` → 정상 경로 테스트 17개 통과, 에러 경로 테스트 1개 실패 (`assert result.returncode == 2` → 실제 0). 17/18 → 18/18 디버깅. **처음부터 `sys.exit(N)` 또는 main() dispatcher 통일**. **Phase 0 스텁이라도 CLI는 정상 + 에러 경로 둘 다 테스트**. 이 함정은 SKILL.md 함정 21번에 영구 기록.
- **mypy || true in CI = 점진적 타이핑**: 0.1.0은 mypy strict 모드 적용 X, 0.3.0+에서 strict. cron-doctor도 동일 패턴.
- **About 한글 description + 영문 README 한/영 병기 = 일관성**: About은 짧은 한 줄, README는 두 언어 섹션. GitHub 검색은 description 매칭하므로 한글 한 줄이 한국어 검색에 유리.
- **README "다른 PC에서 작업" 섹션의 작업 순서 권장**: Phase 0 README에는 **순서가 있는 9단계** 제시 (models → converter → hook → command → mcp → workflow → cli → tests → CI → tag). 다른 PC 작업자가 "어디서부터 시작?" 안 헤매게.
- **memory tool drift = 4번째 세션째 발생**: opencode-trading 부트스트랩 직후 memory 추가 시도했으나 drift guard 거부. 사례 4 (kakao-summary)에서도 발생했음. **패턴**: 06-16 학습 노트대로 "다음 세션에 한 번에 정리"가 안전. **drift 자체를 MEMORY.md에 노트로 남기는 게 더 나을 수도** (다음 drift 발생 시 비교 데이터).

### 네이밍 의사결정 트리 업데이트 (2026-06-17)

| 결정 포인트 | 옵션 | 추천 (2026-06-16 이전) | **수정된 추천 (2026-06-16)** | opencode-trading 검증 (2026-06-17) |
|---|---|---|---|---|
| 이름 | 시리즈 통일 vs 직관성 | 시리즈 통일 (md-doctor, cron-doctor) | **직관성 (기능 + 도메인)** | ✅ **opencode-trading**: OpenCode 메인 플랫폼 + trading 도메인. 시리즈 통일 (md-doctor/cron-doctor) 아님. 미래 `opencode-research`, `opencode-deploy` 확장 가능. |
| 신조어 사용 | OK / 회피 | 회피 (kakao-summary) | 회피 | ✅ 회피 유지 |
| 도메인 prefix | 있음 / 없음 | brand (kakao-) or 범용 (chat-) | brand (kakao-) or 범용 (chat-) | ✅ **범용 (opencode-)**: 미래 도메인 확장 시 시리즈 일관성 자동 확보. opencode는 단일 OSS가 아니라 OpenCode 통합 OSS **컬렉션**의 prefix 역할. |

→ **핵심 원칙 (2026-06-17 확정)**: "기능 명시 + 도메인 직관성" **+** "미래 확장 prefix 통일성" 모두 만족하는 옵션 추천. opencode-trading는 (1) 기능(OpenCode 변환), (2) 도메인(trading), (3) 미래 확장(`opencode-*` 시리즈) 셋 다 만족.

### 메타 비교표 (6개)

| | hwp2md | md-doctor | cron-doctor | kakao-summary | **opencode-trading** |
|---|---|---|---|---|---|
| **날짜** | 2026-06-08 | 2026-06-09 | 2026-06-16 | 2026-06-16 | **2026-06-17** |
| **소요** | ~30분 | ~25분 | ~20분 | ~40분 | **~25분** |
| **버전** | v1.0.0 | v0.1.0 | v0.1.0 (Phase 0) | v0.1.0 (decomm) | **v0.1.0 (Phase 0)** |
| **테스트** | 8 | 16 | 0 (다른 PC) | 32 | **18** |
| **변형** | 정식 10단계 | 정식 10단계 | Phase 0 | Phase 1 + rename + decomm | **Phase 0 (adaptor)** |
| **핵심 학습** | 백엔드 디스패처 | models.py + nargs="?" | 스텁 docstring + mkdir race | stdio JSON-RPC + SQLite | **zero-deps adaptor + sys.exit() 함정** |
| **클래스** | 변환 | 진단 | 진단 | wrapping (decomm) | **adaptor** |
| **이름 변경** | 0 | 0 | 0 | 1 | 0 |
| **decommission** | 아니오 | 아니오 | 아니오 | 예 | 아니오 |

→ opencode-trading는 **이름 결정이 한 번에 성공** (브레인스토밍 단계에서 "기능 + 도메인 + 미래 확장" 3축 추천). 사례 4 (kakao-summary) 교훈이 적용된 첫 사례.

### xmrig-dashboard v0.1.0 → v0.2.0 (2026-06-24) — 시각화 + pytest 확장

| 항목 | v0.1.0 | **v0.2.0** |
|---|---|---|
| **날짜** | 2026-06-24 | **2026-06-24** |
| **소요** | ~45분 (TUI 디버깅 5회) | **~30분** (helper 5 + pytest 20) |
| **버전** | v0.1.0 | **v0.2.0** |
| **테스트** | 0 | **20** |
| **시각 효과** | 0 (정적 박스) | **5 helper + 1 panel + 1 key** |
| **핵심 학습** | TUI 6.x 함정 7개 (MarkupError, Footer, 비대화형) | **helper 분리 패턴 + hyphen importlib + Static.app read-only** |
| **변형** | Phase 1 (정식 10단계) | **Phase 1 v0.2.0 (helper 5 + pytest 20 + backward compat)** |
| **클래스** | Read-Only TUI Monitor | **Read-Only TUI Monitor + 시각화** |
| **함정 추가** | 31~37 | **38 (hyphen), 39 (Static.app), 40 (state pre-populate)** |

→ **helper 분리 패턴** (xmrig-dashboard v0.2.0의 핵심): widget `render()` 안에 박혀있던 시각 효과 코드를 **순수 함수 5개**로 분리 → pytest 100% 가능 + 새 시각 효과 추가 시 widget 1~2줄. 자세한 적용은 `references/visual-helpers-pattern.md` 참조.

→ **재사용 시나리오** (예측):
- **gh-traffic-monitor v0.2.0**: GitHub Traffic 데이터 시각화 (방문자 도넛 + 일별 막대 + 트래픽 히트맵) — 4 helper + 1 panel + pytest 16
- **kakao-summary v0.2.0** (만약 decom 하지 않았다면): 30분 갭 토픽 히트맵 + 메시지 버스트 막대 — 3 helper + pytest 12
- **md-doctor v0.2.0**: 진단 결과를 도넛/막대로 시각화 — 3 helper + pytest 12
- **cron-doctor v0.2.0** (Phase 1 직접 부트스트랩 시): cron 상태 도넛 + 실행 히트맵 — 3 helper + pytest 12

→ 위 시나리오 중 하나라도 "시각화/그래프/pytest 추가" 요청 시 **helper 분리 패턴 + hyphen importlib 우회 + 5규칙** 그대로 적용.
