# 실전 사례 — hwp2md & md-doctor

## 사례 1: hwp2md (2026-06-08, v1.0.0)

**트리거**: "오랜만에 가벼운 서브프로젝트" + "hwp2md 만들어줘"
**소요**: 단일 세션 ~30분
**결과**: 8/8 테스트 통과, v1.0.0 (1.0 정식 출시)

### 시퀀스
1. gh repo create → clone
2. pyproject.toml + LICENSE + .gitignore
3. 소스: `__init__` (convert/batch_convert), core (dispatcher), cli, exceptions
4. 백엔드: hwpx (0.2.0 예정 스텁), hwp5 (0.2.0 스텁)
5. 스모크 테스트 6개
6. README (한글 + 영문) + CHANGELOG
7. CI + action.yml
8. v0.1.0 태그 → 푸시
9. About 한글화 (1차 영문 → 2차 한글)

### 배운 점
- **백엔드 디스패처 패턴**: `core.py`가 `hwp/hwpx` 확장자 보고 분기. 새 포맷 추가 = 새 파일 + dispatcher 1줄.
- **GitHub About 영문 → 한글**: 사용자 요청으로 2차 한글화. 처음부터 한글로 가는 게 더 빠름.

## 사례 2: md-doctor (2026-06-09, v0.1.0)

**트리거**: "hwp2md 완료했음. 다음 서브프로젝트?" → 추천 3개 거절 → "md-doctor 진행하자"
**소요**: 단일 세션 ~25분
**결과**: 16/16 테스트 통과, v0.1.0

### 시퀀스 (hwp2md와 거의 동일, 그래서 자동화 가치가 입증됨)
1. gh repo create → clone
2. pyproject.toml (실패 1회: 이메일 형식) + .gitignore + pytest.ini
3. `models.py` 분리 (이게 새로운 학습!)
4. 소스: __init__, __main__, cli, core, models, exceptions, checks/{token_stats, heading_consistency, dead_links 스텁, broken_images 스텁}
5. 스모크 테스트 16개
6. README (한글 + 영문 부록) + CHANGELOG + CONTRIBUTING (BaseCheck 상속 튜토리얼)
7. CI (Python 3.9-3.12 매트릭스) + action.yml (composite)
8. v0.1.0 태그 → 푸시
9. About 한글화 (처음부터 한글)

### 새 학습 (hwp2md와 차이)
- **순환 import**: core ↔ checks 구조에서 발생 → `models.py` 분리 + lazy import로 해결. **다음 프로젝트부터는 처음부터 적용**.
- **`pyproject.toml` authors.email 함정**: PEP 621 위반으로 `pip install -e .` 깨짐 → 이메일 빼고 `name`만.
- **argparse `nargs="?"`**: `--list-checks` 같은 부속 명령과 동시 사용 가능하게.
- **체크 모듈 패턴**: `BaseCheck` 상속 → `default_checks()` 레지스트리 → 0.1.0엔 2개 활성, 2개는 스텁. hwp2md의 백엔드 스텁 패턴과 동일.

## 시퀀스 요약 (재현 가능한 10단계)

```
gh repo create sigco3111/<name> --public --description "<한글>" --license MIT
git clone https://github.com/sigco3111/<name>.git ~/Documents/<name>/
cd ~/Documents/<name>
# 1. .gitignore (Python std)
# 2. pyproject.toml (setuptools>=68, name만, zero-deps, scripts)
# 3. pytest.ini
# 4. src/<pkg>/{__init__, __main__, cli, core, models, exceptions}
# 5. src/<pkg>/<sub>/{__init__, <impl1>, <impl2> 스텁}
# 6. tests/test_cli.py (6~16개)
python3 -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"
pytest  # 6+ 통과 확인
md-doctor <(echo "# test")  # CLI 스모크

# 7. README.md (한글 + 영문 부록)
# 8. CHANGELOG.md
# 9. CONTRIBUTING.md
# 10. .github/workflows/ci.yml + action.yml
git add -A
git commit -m "feat: initial project skeleton (v0.1.0) ..."
git push -u origin main
git tag -a v0.1.0 -m "..."
git push origin v0.1.0
gh repo edit sigco3111/<name> --description "<한글>"
```

## 다른 PC에서 작업 시작

```bash
git clone https://github.com/sigco3111/<name>.git
cd <name>
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"
pytest
```

**예상 시간: 3분** (clone + 설치 + 테스트). 이게 무사히 통과하면 환경 검증 끝.
