last_updated: 2026-06-17

# Adaptor OSS 클래스 — zero-deps 어댑터 전략

> **이 문서가 필요한 시점**: 새 OSS가 "도구 A의 출력 → 도구 B의 입력" 변환에 해당할 때. 변환(transcoding), 진단(diagnosis), wrapping의 네 번째 클래스.

## 정의

| 클래스 | 목적 | 의존성 패턴 |
|---|---|---|
| 변환 (transcoding) | 파일 포맷 A → 파일 포맷 B (e.g. hwp → md) | 입력 파일만 의존 |
| 진단 (diagnosis) | 파일/구조 분석 + 리포트 | 분석 대상만 의존 |
| wrapping | 외부 도구 호출 + 우리 로직 추가 | adaptee 호출 필요 (의존성 또는 subprocess) |
| **adaptor (포맷 변환)** | **외부 도구 A의 워크스페이스 → 외부 도구 B의 워크스페이스** | **adaptee import X, 결과물 파일만 읽음** |

## Zero-deps 어댑터 전략

**핵심 원칙**: `pip install` 시 adaptee를 설치하지 않는다. 어댑터는 adaptee의 **출력 파일**(TOML, JSON, YAML, Markdown)만 읽어서 **입력 파일**(JSON, Markdown)을 생성한다.

```toml
# pyproject.toml
dependencies = []  # ← zero-deps
[project.optional-dependencies]
adaptee = ["monarchjuno-tradingcodex>=0.2.1"]  # ← optional, import는 안 함
```

**이점**:
1. `pip install` 시간 <1초
2. adaptee 버전 변경에 영향 없음 (출력 포맷이 안정적이라면)
3. adaptee 제거/교체되어도 어댑터는 동작
4. 어댑터 사용자가 adaptee를 별도 설치할 필요 없음 (선택)

**단점**:
1. adaptee 출력 스키마 변경 시 어댑터 깨짐 → **adaptee 버전 핀** 또는 **출력 검증**
2. adaptee 기능 일부가 adaptee 내부 API에만 노출되고 출력에 안 나오면 활용 불가

## 검증된 사례 1: opencode-trading (2026-06-17) — 1:1 도메인 어댑터

- **adaptee**: monarchjuno/tradingcodex v0.2.1
- **adaptee 출력 파일**: `.codex/agents/*.toml`, `.codex/prompts/*.md`, `.codex/hooks/*.py`, `.tradingcodex/workflows/*.yaml`, `.tradingcodex/policies/*.yaml`
- **adaptee 입력 파일** (생성할 것): `opencode.json` `agent` 객체, `mcp` 블록, `hooks` 배열, `~/.config/opencode/command/*.md`
- **사용한 stdlib 모듈**:
  - `tomllib` (Python 3.11+, read-only TOML 파싱) — **핵심 도구**
  - `tomli_w` (optional extra, write)
  - `json` (OpenCode JSON 출력)
  - `pathlib` (파일 디스토링)
  - `dataclasses` (frozen domain models)

**adaptee import 안 함 검증**:
```python
# src/opencode_trading/__init__.py
def __getattr__(name: str):
    # models와 converters는 lazy import
    # tradingcodex는 절대 import 안 함
    ...
```

## 검증된 사례 2: opencode-harness-bridge (2026-06-17) — 메타 어댑터 (N:M 변환 + 안전 정책)

`opencode-harness-bridge`는 단순한 1:1 어댑터가 아님. **3-tier 안전 정책** (auto-apply / model-assisted / user-owned) + 1개 신규 tier (opencode-incompatible) 로 **여러 source → 여러 target** 마이그레이션을 다룬다.

| 일반 adaptor (opencode-trading) | 메타 adaptor (opencode-harness-bridge) |
|---|---|
| 1 source, 1 target | N sources, M targets (N ≥ 2, M ≥ 1) |
| 1-way 변환 | 양방향 가능 (`--source A --target B` ↔ `--source B --target A`) |
| 변환 성공/실패만 분류 | 변환 **외**에 "적용 안전도" 분류 |
| dry-run으로 충분 | dry-run + `--apply-safe` (사용자 확인 후) 필수 |

**메타 adaptor의 4-tier 안전 정책 패턴** (reusable):

```python
from enum import Enum

class SafetyTier(str, Enum):
    AUTO_APPLY = "auto-apply-after-confirmation"   # 안전, 사용자 확인 후 자동
    MODEL_ASSISTED = "model-assisted-manual"        # 의미 변환, 모델이 설명 + 승인
    USER_OWNED = "user-owned-secret-step"           # secret, 사용자 직접
    # ↓ 메타 adaptor에서만 추가되는 tier:
    INCOMPATIBLE = "opencode-incompatible"          # 자동 변환 불가, 수동
```

**핵심**:
1. **기존 tier 시스템 차용**: `danyuchn/claude-codex-harness-sync`의 3-tier를 그대로 가져오고, 새로운 타겟 호환성 tier 1개 추가
2. **secret 탐지는 모든 tier에 적용**: tier-1 (auto-apply) 자산이 secret을 포함하면 자동으로 critical error
3. **default = fail-safe**: 분류 안 된 asset kind는 가장 보수적인 tier (`INCOMPATIBLE`)로 기본값
4. **StrEnum 사용**: `json.dumps(plan)` 시 tier가 자동으로 string 직렬화

**검증 사례** — `opencode-harness-bridge` v0.1.0 (2026-06-17):
- 9개 secret 패턴 (OpenAI, Anthropic, GitHub, AWS, Google, PEM)
- 24개 tier 분류 (Claude 8 + Codex 6 + 호환 10)
- 32 테스트 통과 (0.37s)
- `MigrationPlan.summary()` 가 tier별 카운트 + total 반환
- 향후 source 추가 시 (Aider, Continue) 같은 패턴 그대로 적용

→ "메타"란: 단순 변환을 넘어서 **정책 (안전 tier) + 인벤토리 + 검증** 의 3단 워크플로우. SKILL.md "외부 도구 wrapping" 섹션과 시너지.

## 다른 도메인 확장 가능성

같은 패턴이 적용 가능한 다른 시나리오:

| 어댑터 | adaptee | adaptee 출력 | 어댑터 출력 |
|---|---|---|---|
| `opencode-trading` (✅) | TradingCodex | `.codex/*`, `.tradingcodex/*` | `opencode.json` 블록 + skills |
| `opencode-harness-bridge` (✅) | Claude Code + Codex | `.claude/*`, `.codex/*` | `opencode.json` (4-tier 안전) |
| `opencode-research` (가능) | 노션 DB / Obsidian vault | `.md` 파일 | OpenCode skills + agents |
| `opencode-deploy` (가능) | Vercel/Netlify 설정 | `vercel.json` / `netlify.toml` | OpenCode hooks (deploy trigger) |
| `codex-opencode` (역방향) | OpenCode 워크스페이스 | `opencode.json` + `.opencode/*` | `.codex/agents/*.toml` |
| `obsidian-cursor` (가능) | Obsidian vault | `.md` + YAML frontmatter | `.cursor/rules/*` |
| `claude-codex-bridge` (가능) | Claude Code | `.claude/*` | Codex AGENTS.md + `.codex/*` (메타 adaptor) |

→ "opencode-*" prefix는 **OpenCode 통합 OSS 컬렉션**의 네임스페이스. 시리즈 일관성 자동 확보.

## 스킬 적용 체크리스트

새 OSS가 adaptor 클래스에 해당하는지 확인:

- [ ] 외부 도구 A의 워크스페이스/파일을 입력으로 받는다
- [ ] 외부 도구 B의 워크스페이스/파일을 출력으로 생성한다
- [ ] adaptee를 import/subprocess 호출할 필요 없다 (출력 파일만 읽으면 충분)
- [ ] adaptee의 핵심 가치는 **재사용** (MCP 서버, SQLite DB, 대시보드 등) → 어댑터는 그걸 건드리지 않는다
- [ ] zero-deps 유지가 가치 있다 (adaptee 진영과 분리)

→ 5개 모두 체크 → 1:1 adaptor 클래스. 추가로 6번째 충족 → **메타 adaptor** (N:M 변환 + 안전 정책):
- [ ] 2개 이상의 source format (Claude Code + Codex) 또는 2개 이상의 target format을 다룬다
- [ ] 변환 결과에 "적용 안전도" 가 있다 (auto-apply / model-assisted / user-owned 등)
- [ ] dry-run 외에 `--apply-safe` 같은 사용자 확인 후 적용 모드가 필요하다

→ `python-oss-bootstrap` Phase 0 변형 + zero-deps 어댑터 전략 + `opencode-` prefix 적용.

## oh-my-openagent 스쿼드와 직교 가능 검증 (opencode-trading)

`oh-my-openagent.json`의 에이전트와 TradingCodex의 에이전트는 **이름이 1개도 겹치지 않음**:

| oh-my-openagent | TradingCodex |
|---|---|
| sisyphus, oracle, librarian, explore, multimodal-looker, prometheus, metis, momus, atlas, sisyphus-junior | head-manager, fundamental-analyst, technical-analyst, news-analyst, macro-analyst, instrument-analyst, valuation-analyst, portfolio-manager, risk-manager, execution-operator |

→ **두 스쿼드 시스템이 같은 OpenCode 세션에서 충돌 없이 공존 가능**.

**MCP 클라이언트도 둘 다 지원**: OpenCode는 n개의 MCP 서버를 동시에 spawn 가능. `oh-my-openagent`의 내장 MCP (búsqueda, github 등) + `tradingcodex` MCP (Django) 동시 사용 가능.

**호출 흐름**:
```
사용자 프롬프트
  ↓
OpenCode primary agent (sisyphus) ← oh-my-openagent
  ↓
MCP 도구 호출: mcp__tradingcodex__create_research_artifact
  ↓
TradingCodex MCP 서버 (subprocess)
  ↓
Django service layer
  ↓
SQLite ledger + 대시보드
```

→ sisyphus가 TradingCodex MCP를 호출하면 TradingCodex의 1+9 specialist는 **Django 서비스 레이어**에서 동작. **oh-my-openagent는 위임자, TradingCodex는 실행자**. 직교.

## 어댑터 개발 시 트레이드오프 결정 트리

| 결정 포인트 | 옵션 | 추천 | 이유 |
|---|---|---|---|
| 어댑터 범위 | 1:1 변환 (A→B) / 양방향 (A↔B) / N:M 변환 | **1:1로 시작** | 1:1이 가장 단순, 양방향은 v0.3.0+ |
| adaptee import | yes / no | **no (zero-deps)** | 의존성 분리, pip install <1초 |
| TOML 파싱 | stdlib tomllib / tomli / PyYAML | **stdlib tomllib (3.11+)** | tomli 의존성 0개 |
| 출력 포맷 | opencode.json 블록 / 별도 파일 / 둘 다 | **블록 + 별도 파일 둘 다** | 블록은 merge-in, 별도 파일은 git diff 가능 |
| 검증 | pytest + integration test / pytest only | **pytest + dry-run mode** | dry-run은 다른 PC 작업자가 손수 검증 가능 |
| Phase | Phase 0 (stub) / Phase 1 (full) | **Phase 0부터 시작** | 다른 PC 작업자에게 docstring 가이드 가능 |
| 이름 prefix | `<adaptee>-<host>` / `<host>-<adaptee>` / `<class>` | **`<host>-<domain>`** (opencode-trading, opencode-harness-bridge) | 미래 도메인 확장 시 prefix 통일성 |
| 안전 정책 (메타 adaptor만) | 차용 (3-tier) / 자체 설계 / 둘 다 | **차용 + 1 tier 추가** | 검증된 시스템 재사용 + 새 요구사항 1개 |

## 다음 adaptor OSS 부트스트랩 시 적용할 것

1. **브레인스토밍** (5~7 결정 포인트): 이름 / 범위 (1:1 vs 양방향 vs N:M) / adaptee 의존성 / 출력 포맷 / Phase 0 vs 1 / 안전 정책 (메타만) / 시리즈 포지셔닝
2. **zero-deps 유지** — adaptee import 안 함
3. **5~6개 도메인 모델** (frozen dataclass + Literal type) — 어댑터 출력물 구조 정의
4. **N개 변환기 스텁** — 각 docstring에 "다른 PC 작업자용 가이드" + stdlib 사용 가이드
5. **CLI dry-run 필수** — 정상 + 에러 경로 둘 다 exit code 검증 (함정 21번)
6. **README 다층 옵션** — 한/영 병기 + "다른 PC에서 작업" 9단계 순서 권장
7. **CI** — Python 3.11/3.12/3.13 + ruff + mypy || true + pytest
8. **v0.1.0 태그** — 어댑터는 stub이라 Phase 0가 자연스러움
9. **About 한글** — 한글 description + 영문 README 두 언어 섹션
10. **시그니처 시리즈 추가** — 사례 7로 case-studies.md 업데이트
11. **(메타 adaptor만) ADR 작성** — `docs/decisions/0001-<rationale>.md` 형식으로 핵심 결정 1~2개 문서화
12. **(메타 adaptor만) 4-tier 안전 정책 명시** — README에 "3-tier 차용 + 1 tier 추가" 사실 + 출처 명시

## 검증된 함정 3개 (opencode-trading + opencode-harness-bridge, 2026-06-17)

1. **`sys.exit(N)` vs `return N` for argparse subcommand handler** (opencode-trading) — SKILL.md 함정 21번 참고. **adaptor OSS의 CLI도 Phase 0 스텁이라도 정상 + 에러 경로 둘 다 테스트** 필수.

2. **`write_file` 멀티라인 escape** (opencode-harness-bridge) — 비정상 데이터 (시크릿 같은 더미 문자열, ASCII art, 바이너리 비슷한 hex dump) 를 `write_file` 본문에 넣으면 멀티라인 escape가 깨져서 **다음 줄이 한 줄로 합쳐지는** 현상 발생. **증상**: `text = "sk-abc..."\n    assert looks_like_secret(text) is True` 같은 코드가 한 줄로 깨짐. **해결**: 의심스런 데이터는 `write_file` 대신 `patch(mode='replace')` 사용. patch는 멀티라인 escape를 정확히 처리. **재사용**: 시크릿 키, ASCII art, base64 데이터, 한국어 조사 포함 prefix, 매우 긴 라인 (1KB+) 등 `write_file` 본문에 들어갈 때. **테스트 데이터는 항상 1KB 미만 + 멀티라인 가능 + escape 안전한 형태로** (일반 ASCII + 단순 알파벳).

3. **시크릿 regex 테스트 데이터 길이** (opencode-harness-bridge) — `looks_like_secret()` 같은 정규식 기반 secret detector는 보통 `r"sk-[A-Za-z0-9]{20,}"` 같은 길이 최소값 패턴. 테스트 데이터를 `text = "sk-abc...wxyz"` 같이 짧게 쓰면 패턴 최소값 미만으로 **매칭 실패**. **증상**: regex는 정확하지만 테스트만 fail. **해결**: 테스트용 fake secret은 **실제 키 길이 ≥ 패턴 최소값** 으로 작성 (예: `text = "sk-abc...wxyz"` = 30자, `text = "ghp_ab...6789"` = 40자). **재사용**: 모든 정규식 기반 탐지/필터 (시크릿, 욕설, 스팸, PII, 전화번호) 테스트 작성 시. **원칙**: "regex 패턴이 요구하는 길이보다 테스트 데이터가 길거나 같아야 한다".
