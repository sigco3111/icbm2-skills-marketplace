# Visualization Helpers Pattern (xmrig-dashboard v0.2.0+)

> TUI/Terminal 대시보드에서 **시각 효과(그래프/도넛/히트맵/펄스)를 widget 코드와 분리**해서 **TTY 안 잡고도 단위 테스트 가능**하게 만드는 패턴. xmrig-dashboard v0.2.0에서 실전 검증.

## 1. 왜 helper를 분리하나

**TUI widget의 `render()` 메서드 안에 시각 효과 코드를 다 박으면**:

1. **단위 테스트 불가** — Textual `App` 컨텍스트 필요, TTY 필요
2. **회귀 위험** — 한 widget 수정 시 다른 widget 영향
3. **확장성 0** — 새 시각 효과 추가할 때마다 widget 100+ lines 수정
4. **검증 어려움** — Textual이 reactive로 `render()`를 여러 번 부르며 cache와 충돌 → 간헐적 MarkupError

**v0.2.0 패턴**: 시각 효과를 **순수 함수**로 분리. widget은 helper 호출 한 줄.

## 2. helper 작성 5규칙

| # | 규칙 | 이유 |
|---|---|---|
| 1 | **순수 함수** (`self` 금지) | 테스트 가능 + 부작용 0 |
| 2 | **Rich 마크업 문자열 반환** | widget과 출력 포맷 통일 |
| 3 | **모듈 글로벌 `PALETTE` 상수만 사용** | 색상 일관성 |
| 4 | **빈 데이터 placeholder 필수** | "차트가 비어 보임" 사고 방지 |
| 5 | **`width`/`height` 인자** | terminal 크기 적응 |

## 3. helper 시그니처 표준

```python
def render_xxx(primitives, *, width=None, height=None) -> str:
    """One-line summary.

    Detailed docstring. Return Rich-markup string.
    Empty input → returns placeholder (never raises, never returns empty).
    """
    if not primitives:
        return f"[{PALETTE['fg_dim']}](no data yet)[/{PALETTE['fg_dim']}]"
    # ... 20~50 lines of pure computation
    return "█ █ █"  # Rich markup
```

**실제 xmrig-dashboard v0.2.0 5개 helper 시그니처**:

```python
def render_donut(accepted: int, rejected: int, size: int = 4) -> str
def render_core_bars(per_core: list, width: int = 6) -> str
def render_forecast_bars(daily_usd: list, max_height: int = 5) -> str
def render_core_heatmap(per_core_now: list, history: list, width: int = 12) -> str
def render_header_logo(width: int = 60) -> str
```

## 4. widget에서 helper 호출 패턴

```python
# ---------- TUI Widgets ----------
class EarningsPanel(Static):
    """v0.2.0+ — extends v0.1.0 with donut + forecast."""
    def render(self) -> str:
        # 기존 v0.1.0 코드 ...
        accepted = s.get("accepted", 0)
        rejected = s.get("rejected", 0)
        # ...
        # v0.2.0 시각화 추가 (위 2줄)
        h += f"\n  [#1f8033]donut[/#1f8033]  {render_donut(accepted, rejected)}\n"
        h += f"\n  [#1f8033]7-day[/#1f8033]  {render_forecast_bars(getattr(self.app, '_daily_earnings', []))}\n"
        return h
```

**핵심**: widget 코드는 5~10줄 증가로 끝. 시각 효과 95%는 helper 안에.

## 5. pytest 템플릿 (단일 파일 + hyphen OSS)

### 5-1. 디렉토리 구조

```
my-tui-tool/
├── my-tui.py                 # 메인 (hyphen 들어간 단일 파일)
├── tests/
│   ├── __init__.py           # (선택, pytest discovery용)
│   └── test_visual.py        # pytest
├── README.md
└── ...
```

### 5-2. test_visual.py 표준 템플릿

```python
"""Unit tests for v0.2.0+ visualization helpers.

Helper functions are pure (no self, no Textual state), so we can test
them without spinning up a Textual app or a TTY. The main file uses
a hyphen in its name (my-tui.py) which Python can't import directly;
we use importlib.util to load it as a module.

Run: python3 -m pytest tests/ -v
"""

import importlib.util
import pathlib

import pytest

# Load my-tui.py as a module (filename has a hyphen, so we
# can't just `import my_tui`).
ROOT = pathlib.Path(__file__).resolve().parent.parent
SCRIPT = ROOT / "my-tui.py"
spec = importlib.util.spec_from_file_location("my_tui", SCRIPT)
assert spec is not None and spec.loader is not None  # type guard
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)


# ---------- Test class per helper ----------

class TestDonut:
    """Example: a 4-line ASCII donut with a label."""

    def test_zero_shares_returns_placeholder(self):
        out = mod.render_donut(0, 0)
        assert "no shares yet" in out
        # No donut cells in placeholder
        assert "▄" not in out

    def test_nonzero_renders_donut(self):
        out = mod.render_donut(100, 5)
        # Donut cells present
        assert "▄" in out
        assert "█" in out
        # Label format
        assert "acc" in out
        # 95% (100/(100+5)) visible
        assert "95" in out

    def test_low_acceptance_uses_warning_color(self):
        out = mod.render_donut(50, 50)
        assert "#ffaa00" in out  # PALETTE['warning']

    def test_high_acceptance_uses_default(self):
        out = mod.render_donut(99, 1)
        assert "#33ff66" in out  # PALETTE['fg']
        assert "99" in out


class TestCoreBars:
    """Example: per-core load as vertical mini-bars."""

    def test_empty_returns_placeholder(self):
        out = mod.render_core_bars([])
        assert "no core data" in out

    def test_eight_cores_render_with_caption(self):
        per_core = [10, 25, 50, 75, 90, 100, 5, 30]
        out = mod.render_core_bars(per_core, width=4)
        lines = out.split("\n")
        # width=4 bars + 1 caption = 5 lines
        assert len(lines) == 5
        # Caption has average
        assert "avg" in lines[-1]
        assert "48" in lines[-1]  # average of test data

    def test_caps_at_32_visible_cores(self):
        per_core = [50.0] * 40
        out = mod.render_core_bars(per_core, width=2)
        assert "+8 more" in out

    def test_uses_block_chars(self):
        # 50% on 3-cell bar: 1 empty (▁) + 2 full (█)
        per_core = [50.0] * 4
        out = mod.render_core_bars(per_core, width=3)
        assert chr(0x2588) in out  # █
        assert chr(0x2581) in out  # ▁
```

### 5-3. 테스트 4 원칙

1. **TTY 의존 0개** — `textual.app.App.run()` 호출 안 함
2. **외부 IO 최소화** — 파일 읽기/psutil 호출은 mock 또는 `interval=None` (no-op)
3. **Rich 마크업 substring 검증** — `assert "▄" in out` (정확한 ANSI escape 비교 X)
4. **경계조건 명시** — 빈 입력, 0%, 100%, N개 초과, 음수 등

### 5-4. pytest 실행

```bash
python3 -m pip install pytest textual psutil
python3 -m pytest tests/ -v
# → 20 passed in 0.44s (xmrig-dashboard v0.2.0 기준)
```

## 6. widget render() 단위 테스트 (subclass 패턴)

helper는 100% 테스트 가능. **widget의 `render()`도 50%는 테스트 가능** — `Textual.Static.app` read-only property 우회:

```python
import re
from my_tui import StatusBar

# Smoke test (outside test_visual.py)
def test_status_bar_renders_logo():
    spec = importlib.util.spec_from_file_location("my_tui", "my-tui.py")
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    app = m.MyApp()  # Your app class
    app.state["x"] = {"connected": True, ...}

    # Subclass to override read-only `app` property
    class MockSB(m.StatusBar):
        @property
        def app(self):
            return app  # closure-captured fake app

    sb = MockSB()
    out = sb.render()
    # Strip Rich markup for substring check
    plain = re.sub(r"\[/?[^]]+\]", "", out)
    assert "MINING" in plain
    assert "IDLE" not in plain
```

**왜 subclass?** — `widget.app = mock_app` 직접 할당 불가 (read-only property). `@property` 오버라이드만 가능.

**대안 (덜 안정)**: `app._app = mock_app` (private reactive). Textual 6.x에서 동작하지만 버전 업 시 깨질 수 있음.

## 7. 회귀 방지 워크플로 (TUI 변경 후)

```bash
# 1) pytest
python3 -m pytest tests/ -v
# → 20 passed

# 2) 5초 background + 에러 grep
python3 my-tui.py > /tmp/test.log 2>&1 &
PID=$!
sleep 5
kill -9 $PID 2>/dev/null
grep -iE "attribute|keyerror|nameerror|markup|traceback" /tmp/test.log
# → 0줄이어야 OK

# 3) App 인스턴스화 검증
python3 -c "
import importlib.util
spec = importlib.util.spec_from_file_location('my_tui', 'my-tui.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
app = m.MyApp()
print('BINDINGS:', [b[0] for b in m.MyApp.BINDINGS])
"
# → 모든 신규 단축키 확인

# 4) Helper dryrun
python3 -c "
import importlib.util
spec = importlib.util.spec_from_file_location('my_tui', 'my-tui.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
print(m.render_donut(100, 5))  # 시각화 작동 확인
"
```

## 8. helper 추가 시 체크리스트

새 helper 1개 추가할 때마다:

- [ ] 순수 함수 (no `self`, no 모듈 글로벌 읽기, no IO)
- [ ] Rich 마크업 반환
- [ ] `PALETTE` 상수만 사용
- [ ] 빈 입력 placeholder (`(no data yet)`, `(...waiting)`, etc.)
- [ ] `width`/`height` 인자 (또는 합리적 default)
- [ ] pytest 3~5 케이스 추가 (빈 입력, 정상, 경계, 색상, 형상)
- [ ] widget에서 1~2줄로 호출
- [ ] widget density-adaptive 분기 (`screen_h < 36`)에서 helper 1줄 요약

**총 소요 시간**: helper 1개당 ~5분 (작성 2분 + 테스트 2분 + widget 통합 1분)

## 9. 안티패턴 (하지 말 것)

### 9-1. ❌ helper에서 `self` 사용

```python
class DonutWidget(Static):
    def render_donut(self, accepted, rejected):  # ❌ class method가 아니라 helper여야
        return self.app.state.get("x", 0)  # ❌ 부작용
```

→ 테스트 불가. widget은 helper 호출만, helper는 순수 함수로.

### 9-2. ❌ widget render() 100+ lines

```python
class HashratePanel(Static):
    def render(self):
        # ... 100 lines of inline bar/heatmap/markup construction
        # ❌ 회귀 시 어디가 문제인지 찾기 어려움
        # ❌ 테스트 불가
```

→ 30줄 넘으면 helper로 분리.

### 9-3. ❌ helper에서 외부 IO

```python
def render_donut():
    data = open("/tmp/foo").read()  # ❌ 부작용
    return ...
```

→ IO는 widget 또는 별도 collector 함수에서.

### 9-4. ❌ 빈 데이터 placeholder 생략

```python
def render_forecast_bars(daily_usd):
    if not daily_usd: return ""  # ❌ 차트가 비어 보임 → "버그?" 오해
```

→ 명시적 placeholder:
```python
def render_forecast_bars(daily_usd):
    if not daily_usd or all(v <= 0 for v in daily_usd):
        return f"[{PALETTE['fg_dim']}]no data yet — chart fills in as the dashboard runs each day[/{PALETTE['fg_dim']}]"
```

## 10. 실전 사례

| OSS | helper 개수 | pytest 개수 | widget 추가 |
|---|---|---|---|
| **xmrig-dashboard v0.2.0** | 5 (donut, core_bars, forecast, heatmap, logo) | 20 | 1 (CoreHeatmapPanel) |
| (예측) gh-actions TUI v0.2.0 | 4~5 (run list, success donut, fail heatmap, status dot) | 15~20 | 1~2 |
| (예측) kmsg-mcp TUI v0.2.0 | 3~4 (message burst, topic donut, 30일 통계) | 12~16 | 1 |

→ **공통점**: helper는 항상 3~5개, pytest는 15~25개, widget 추가는 1~2개로 끝. **이 비율이 helper 분리 패턴의 표준**.

## 11. 다른 OSS 적용 예시

### 11-1. gh-actions TUI v0.2.0

```python
# render_xxx 4개
def render_run_status_dot(status: str) -> str: ...  # success/fail/cancelled
def render_failure_donut(successes: int, failures: int) -> str: ...
def render_workflow_heatmap(runs: list, width: int = 14) -> str: ...
def render_header_logo() -> str: ...

# widget에서 호출
class WorkflowsPanel(Static):
    def render(self):
        h = "[bold]WORKFLOWS[/bold]\n"
        h += f"  {render_failure_donut(successes, failures)}\n"
        h += f"  {render_workflow_heatmap(runs)}\n"
        return h
```

### 11-2. kmsg-mcp TUI v0.2.0

```python
# render_xxx 3개
def render_topic_donut(topics: dict) -> str: ...  # 30분 갭 토픽 그룹핑
def render_burst_heatmap(messages: list, width: int = 24) -> str: ...
def render_header_logo() -> str: ...
```

## 12. 재사용 가이드 요약

**다음 TUI/Terminal 시각화 추가 요청 시**:

1. **결정**: helper 분리 패턴 적용 (시각 효과 3개+ 추가 시 거의 필수)
2. **helper 시그니처 표준** (위 3번) 따라서 작성
3. **pytest 템플릿** (위 5-2) 복사 → helper당 3~5 케이스
4. **widget 호출** (위 4번) 1~2줄로
5. **회귀 워크플로** (위 7번) 4단계 통과

**예상 소요 시간**: 5~10분/helper, 20분/widget 추가 (helper 5개 + pytest 20개 + widget 1개 = 30~50분 풀세트)

**함정 3개 자동 회피**:
- hyphen 파일 → importlib (함정 38)
- `Static.app` read-only → subclass `@property` (함정 39)
- 새 state → `__init__` pre-populate (함정 40)

→ 본 references와 함께 `references/tui-monitor-readonly-case-study.md` v0.2.0 섹션, `references/external-tool-wrapping.md` 동시 로드 권장.
