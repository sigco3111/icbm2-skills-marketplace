# Deploy 단계 (코드 push != production deploy)

> xmrig-dashboard v0.2.0 → v0.2.1 (2026-06-24)에서 발견된 4가지 deploy 함정. **OSS 코드를 git에 push한 뒤, 사용자가 production 환경에서 실행할 수 있도록 만드는 단계**를 따로 다룸. python-oss-bootstrap 9단계 레시피의 10번째 단계.

## 트리거 조건

다음 중 하나라도 해당되면 v0.x 푸시 직후 deploy 4단계 자동 진행:

- 사용자가 **launcher 스크립트**(`~/bin/run-*`, `~/.local/bin/*`, `PATH` 안 실행 파일)로 실행한다고 명시/암시
- **systemd/LaunchAgent/Homebrew formula** 같은 운영 레이어가 있음
- **이전 v0.x의 background process**가 살아있을 가능성
- v0.y가 **새 의존성 버전** 요구 (Python 3.x, textual 8.x 등 메이저)

## 4단계 절차

### 1단계: launcher 경로 갱신

```bash
cat ~/bin/run-myapp.sh
# → exec /old/path/python3 /old/v0.x/myapp.py

# 1-a) 직접 경로
exec /path/to/new/repo/myapp.py

# 1-b) venv/conda env (Python 의존성 변경 시)
exec /Users/me/.venvs/myapp/bin/python /path/to/new/repo/myapp.py
```

**확인**:
```bash
diff <(md5 /old/v0.x/myapp.py 2>/dev/null) <(md5 /path/to/new/repo/myapp.py) || echo "✓ 다른 파일"
```

### 2단계: 의존성 버전 확인

```bash
PYBIN=/Users/me/.venvs/myapp/bin/python
$PYBIN -c "import my_dep; print(my_dep.__version__)"
# v0.y 요구 버전과 비교
```

**불일치 시**: venv/conda env 새로 만들어 launcher 갱신.

xmrig-dashboard v0.2.0 사례:
- system Python 3.8: textual 6.2.1 ❌
- conda env `xmrig-dash`: textual 8.2.7 ✅
- → launcher가 conda env 가리키게

### 3단계: 이전 background process 정리

```bash
pgrep -fl myapp
# → PID 12345 /Library/.../Python /old/v0.x/myapp.py  (살아있을 수 있음)
kill -9 12345
sleep 1
pgrep -fl myapp  # → 비어있어야 OK
```

**왜**: launcher 갱신 + 신버전 띄워도 옛 PID 살아있으면 TTY에서 옛 화면 → "UI 안 바뀜" → deploy 실패처럼 보임.

### 4단계: 사용자 검증

TTY에서 직접 띄워서:
- 핵심 visual 요소 작동
- 단축키 작동 (`g` 토글 등)
- 새 패널 border 정확히 표시 (함정 41)
- 에러/traceback 없음

**검증 실패 시**: 캡처 → hotfix 사이클 (v0.2.0 → v0.2.1 처럼 핫픽스 commit + 마이너 태그).

## 흔한 deploy 함정 4가지

| # | 함정 | 증상 | 해결 |
|---|---|---|---|
| A | launcher가 옛 v0.x 파일 가리킴 | 신버전 코드 안 실행 | launcher exec 라인 갱신 |
| B | Python 인터프리터 의존성 불일치 | ImportError / 구버전 API | venv/conda env + launcher 갱신 |
| C | 이전 background process 살아있음 | TTY에 옛 화면 | `pkill -9 -f <app>` |
| D | CSS border 셀렉터 누락 (TUI 한정, 함정 41) | 박스 없이 헤더만 떠 보임 | commit 직전 `git grep "Panel {"` |

## deploy-check.sh 자동화 (선택)

```bash
#!/bin/bash
set -e
APP="myapp"
REPO="/Users/me/repos/$APP"
LAUNCHER="$HOME/bin/run-$APP.sh"

echo "1. Launcher 경로 검증..."
grep -q "$REPO" "$LAUNCHER" || { echo "❌ launcher가 repo 경로 가리키지 않음"; exit 1; }

echo "2. 의존성 검증..."
PYBIN=$(head -1 "$LAUNCHER" | awk '{print $2}')
$PYBIN -c "import my_dep" || { echo "❌ 의존성 미설치"; exit 1; }

echo "3. 이전 process 정리..."
pkill -9 -f "$APP" 2>/dev/null || true
sleep 1
pgrep -fl "$APP" && { echo "❌ process 살아있음"; exit 1; }

echo "4. 5초 background health check..."
$LAUNCHER > /tmp/deploy.log 2>&1 &
PID=$!
sleep 5
kill -9 $PID 2>/dev/null
grep -iE "error|traceback" /tmp/deploy.log && { echo "❌ traceback"; exit 1; }

echo "✅ deploy 4단계 통과"
```

## 실전 사례 (xmrig-dashboard v0.1.0 → v0.2.0 → v0.2.1)

| 단계 | v0.1.0 → v0.2.0 | v0.2.0 → v0.2.1 |
|---|---|---|
| 1. launcher | ❌ 옛 v0.1.0 | ✅ v0.2.0 repo |
| 2. 의존성 | ❌ system 3.8 = textual 6.2.1 | ✅ conda env = 8.2.7 |
| 3. process | ❌ 옛 PID 75352 | ✅ 자연 정리 |
| 4. 검증 | ❌ "UI 안 바뀜" | ✅ 사용자 캡처 → 함정 41 (CSS) 발견 |
| 핫픽스 | (deploy 자체 누락) | v0.2.1 commit + tag (7 lines) |

**교훈**: v0.1.0 → v0.2.0은 **deploy 단계 자체를 누락**. v0.2.0 → v0.2.1은 deploy 1~3 통과 후 4단계(검증)에서 **함정 41** 발견. **deploy는 10번째 독립 단계이지, 9단계의 일부가 아님**.

## 재사용

다음 "OSS v0.x 푸시 + production 반영" 시나리오:
1. 사용자 launch 경로 먼저 파악
2. deploy 4단계 자동 적용 (5~10분)
3. 사용자 검증 결과에 따라 핫픽스

**예상 시간**: 5~10분 (deploy 1~3) + 사용자 검증.
