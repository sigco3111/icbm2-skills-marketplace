# v0.2.0 → v0.2.1 신규 학습: 함정 41 + deploy 단계

> 2026-06-24 xmrig-dashboard v0.2.0 푸시 후 v0.2.1 핫픽스 과정에서 발견. **`tui-monitor-readonly-case-study.md` v0.2.0 섹션에 함정 41 추가 + `references/deploy-after-push.md` 신규**.

## 함정 41: 새 위젯 추가 시 CSS border 셀렉터 누락 → 박스 없이 헤더만 떠 보임

xmrig-dashboard v0.2.0에서 `CoreHeatmapPanel` 추가했는데 **CSS의 panel border 룰에서 빠뜨림**. 결과: HEATMAP 헤더만 박스 없이 떠 있고, 옆 panel과 시각적으로 어긋남. 6개 panel이 grid에 들어가는데 border가 1개 빠지면 그 패널만 boxless.

**증상 (사용자가 TTY에서 발견)**:
```
 HEATMAP                          ← 박스 밖
┌───────────────────────────────┐
│   LAST LOG LINES              │
cores 6  avg 100.0%  min 100  max  ← 옆 panel과 정렬 어긋남
100
└───────────────────────────────┘
```

**근본 원인** (v0.2.0 코드 966, 972-976 라인):
```python
CSS = f"""
    HashratePanel, SystemPanel, PoolPanel, EarningsPanel, LogPanel {{  # ← CoreHeatmapPanel 빠짐
        border: solid {PALETTE['fg_dim']};
        padding: 0 2;
        background: {PALETTE['bg']};
    }}
    HashratePanel    {{ border: solid {PALETTE['accent']}; }}   # ← 여기에도 빠짐
    SystemPanel      {{ border: solid {PALETTE['fg']}; }}
    ...
"""
```

**해결 (v0.2.1, 7 lines diff)**:
```python
HashratePanel, SystemPanel, PoolPanel, EarningsPanel, LogPanel, CoreHeatmapPanel {{
    border: solid {PALETTE['fg_dim']};
    padding: 0 2;
    background: {PALETTE['bg']};
}}
HashratePanel    {{ border: solid {PALETTE['accent']}; }}
SystemPanel      {{ border: solid {PALETTE['fg']}; }}
PoolPanel        {{ border: solid {PALETTE['fg_dim']}; }}
EarningsPanel    {{ border: solid {PALETTE['fg']}; }}
LogPanel         {{ border: solid {PALETTE['fg_faint']}; }}
CoreHeatmapPanel {{ border: solid {PALETTE['accent']}; }}  # 추가
```

**체크리스트 — 새 위젯 추가 시 CSS 4곳 업데이트**:
1. **공통 셀렉터** (`Widget1, Widget2, ... { border: ... }`) — 모든 위젯 공유 룰
2. **개별 border 색상 매핑** — 패널별 고유 색상
3. **Pulse 클래스** (`-mining-active`, `-pulse-bright` 등) — 애니메이션 있으면
4. **Reactive 클래스** (`-hidden` 등) — 토글이 있으면

**검증 방법**:
```bash
python3 dashboard.py > /tmp/test.log 2>&1 &
sleep 5
kill -9 $! 2>/dev/null
grep -A1 "HEATMAP" /tmp/test.log | grep -E "┌|│" || echo "❌ border missing"
```

**재사용**: Textual/Rich/CSS-grid 기반 모든 TUI 새 위젯 추가 시. **render() 코드만 보고 commit하지 말고 CSS도 grep으로 검증**.

**함정 38/39/40과의 관계**: 38(hyphen importlib)/39(Static.app)/40(state pre-populate) 모두 **Python 로직** 함정. 41은 **CSS 룰** 함정 — 같은 widget 추가 작업에서도 빠질 수 있는 4번째 카테고리.

## deploy 단계 (코드 push != production deploy)

v0.2.0 푸시 후 사용자가 "UI가 전혀 변하지 않음" 리포트 → 원인 3가지 동시 노출:

1. **launcher가 옛 v0.1.0 파일 가리킴** (`~/bin/run-miner-dashboard.sh`)
2. **system Python 3.8에 textual 6.2.1** (v0.2.0은 textual 8.2.7 요구)
3. **이전 background process PID 75352 살아있음**

이 3가지가 한꺼번에 겹쳐서 "코드는 push했는데 UI가 그대로" 증상 발생. v0.2.1에서는 deploy 4단계 (launcher 갱신 + conda env `xmrig-dash` + pkill + 사용자 검증) 모두 통과.

자세한 절차는 `references/deploy-after-push.md` 참조.

## python-oss-bootstrap 스킬 변경 사항

- **9단계 → 10단계로 갱신** (deploy 4단계 추가)
- SKILL.md description + 본문에 v0.2.1 함정 41 + deploy 4단계 명시
- x-v020-additions + x-v021-additions 메타필드 추가

## 다음 OSS 부트스트랩 시 자동 적용

- 새 OSS v0.1.0: 사용자에게 launch 경로 먼저 확인 → 9단계 + deploy 4단계 한 세트
- 기존 OSS v0.x → v0.y: 10단계 풀세트
- TUI/CSS 위젯 추가: 함정 41 자동 체크 (`git grep "Panel {"`)
