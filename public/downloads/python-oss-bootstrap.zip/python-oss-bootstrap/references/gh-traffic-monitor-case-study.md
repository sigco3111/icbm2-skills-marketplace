# gh-traffic-monitor 케이스 스터디 (2026-06-23)

sigco3111 GitHub 조직에 만든 **9번째 Phase 1 변형 풀세션 부트스트랩 사례**. 외부 도구 wrapping이 아닌 **GitHub REST API를 직접 호출**하는 도구. Repolis 같은 3D 도시 시각화의 데이터 백엔드 역할.

## 의사결정 트리 (브레인스토밍 단계)

사용자 요청: "Notion 장애 뉴스 확인" → Notion 실시간 장애 확인 → "Repolis 따라 우리도 할 수 있을까?" → "모두 추천한 것으로 진행" → Phase 0 시작.

| 결정 포인트 | 옵션 | 선택 | 이유 |
|---|---|---|---|
| 작업 위치 | A 풀세션 / B 다른 PC / C Phase 0만 | **A 풀세션** | 사용자가 명시 선택 |
| 스코프 | A 풀 / B 도시만 / **C 도시+로컬택시** / D MVP | **C** | 균형 (WebGPU/proxy 제외) |
| repo 필터 | 156개 전부 / 내가 만든 것만 / 커밋한 것만 | **전부 156개** | 사용자 결정 |
| 도시 배치 | 균등 / 그라데이션 / 둘 다 | **트래픽 그라데이션** | 사용자 결정 |
| 트래픽 데이터 소스 | 새 monitor / 기존 cron / API만 | **새 monitor** | 없음 |
| 도시 미학 | Ghibli / 사이버펑크 / 사용자 | **Ghibli 그대로** | 검증됨 |
| 호스팅 | GitHub Pages / Vercel / Cloudflare | **GitHub Pages** | 무료 + 충분 |
| PAT | 신규 발급 / 기존 gh CLI | **기존 gh CLI 활용** | `repo` scope 보유 |
| 동기화 주기 | daily / 6h / 4h / 1h | **6h Actions schedule + workflow_dispatch** | 무료 한도 + 즉시성 균형 |
| OSS 이름 | `github-traffic-collector` / `gh-traffic-monitor` / `repo-traffic-csv` | **gh-traffic-monitor** | Repolis 원작자 의도 차용, 짧고 호환성 높음 |

## 모듈 구조 (9개 모듈, ~25KB)

```
src/gh_traffic_monitor/
├── __init__.py         # 빈 파일 (re-export 불필요, 단순 패키지)
├── __main__.py         # python -m 진입점 (cli.main 호출)
├── cli.py              # argparse subparser (collect/status/repos)
├── core.py             # 4단계 오케스트레이터
├── github_api.py       # stdlib urllib + gh auth token subprocess
├── storage.py          # CSV append/overwrite + 누적 집계
├── models.py           # TrafficRecord, CumulativeTotals (frozen dataclass)
└── exceptions.py       # GTMError 계층 (5개 서브클래스)
```

## 23개 테스트 (0.64초 통과)

| 카테고리 | 개수 | 커버리지 |
|---|---|---|
| models | 6 | frozen dataclass, CSV 헤더, ISO 포맷 |
| exceptions | 4 | 계층, 메시지 |
| storage | 7 | append/overwrite/누적/멀티 repo/빈 dir |
| cli | 6 | version, help, status 빈 dir, status after collect, owner 누락, unknown command |

## 검증된 함정 (4개 + 기존 재발견 1개)

1. **함정 24**: `__main__.py` 빈 파일 → `python -m pkg` 호출 시 silent (exit 0, stdout 비음). `touch`만 한 후 cli 연결 안 하면 모든 CLI 테스트가 fail.
2. **함정 25**: CSV DictReader 헤더 행에서 `row["date"]` 직접 접근 → KeyError. 이중 가드 `if not repo or not date: continue` 필수.
3. **함정 26**: argparse subparser `required=True`인데도 명령 없을 때 silent fail. 명시적 `if args.command is None: parser.print_help(); return 0` 처리.
4. **함정 27**: macOS keyring 토큰을 `gh auth token` subprocess로 추출 → 환경 변수 노출 없이 cron에서 안전 사용.
5. **함정 28**: GitHub Traffic API 24~48h 지연. README 첫 줄에 명시 필수 ("왜 uniques 0이야?" 11번 질문 회피).

## 핵심 디버깅 트랜스크립트 — `__main__.py` silent fail

```bash
$ python3 -m gh_traffic_monitor --version
# exit_code: 0, stdout: '', stderr: ''
# 사용자: "왜 출력이 안 나오지?"
```

**원인**: `touch src/<pkg>/__main__.py`로 0바이트 파일만 만들고 `cli.py`의 `main()`을 호출 안 함. `python -m <pkg>`은 `__main__.py`를 실행하는데 빈 파일이니까 그냥 종료.

**해결**:
```python
# src/gh_traffic_monitor/__main__.py
"""`python -m gh_traffic_monitor` 진입점."""
import sys
from .cli import main
if __name__ == "__main__":
    sys.exit(main())
```

**교훈**: 4단계 디렉토리 생성 후 `__init__.py`는 비어도 OK (패키지 인식용)지만, **`__main__.py`는 절대 비우지 말 것** — 빈 0바이트 파일은 silent fail 원인.

## 검증된 워크플로 패턴 (재사용 가능)

1. **브레인스토밍 단계 (5~10분)** — 결정 포인트 옵션 2~3 + 추천. 사용자가 빠르게 결정.
2. **GitHub repo 생성 + clone** — `gh repo create --license MIT` (라이선스 함정 9번 대비).
3. **소스 9개 모듈 한 번에 작성** — `models → exceptions → github_api → storage → core → cli → __main__`.
4. **pyproject.toml + .gitignore + 테스트 4종** — 동시에.
5. **테스트 1차 실행 → fail → `__main__.py` 패치 → 통과** — 5개 fail → 0 fail (17 → 23개 통과).
6. **실제 데이터 1회 collect** — 154개 repo 3분 13초, 0 실패, CSV 정상 생성.
7. **README 다층 옵션 작성** — 9KB 한/영 병기 (설치/옵션/시나리오 4개/로드맵/주의사항).
8. **git commit + push + tag + About 한글화** — `gh repo edit --description`.
9. **GitHub tree 검증** — `gh api ...git/trees/main?recursive=1` → 29개 파일 모두 존재 확인.

**소요 시간**: ~25분 (kakao-summary 35분 대비 빠름 — 외부 도구 wrapping 없음 + stdlib only).

## 사용 패턴 (실제 워크플로)

```bash
# 사용자 cron / Actions에서
gh-traffic-monitor --owner sigco3111 --log-dir ./data/logs collect
gh-traffic-monitor --owner sigco3111 --log-dir ./data/logs status
```

JSON 결과는 stdout, 진행 로그는 stderr → cron에서 `2>/dev/null`로 stderr 무시하고 JSON 파싱 가능.

## GitHub Actions 패턴 (예시)

```yaml
on:
  schedule:
    - cron: "0 */6 * * *"  # 6시간마다
  workflow_dispatch:        # 수동 트리거
```

→ **즉시성 6h + Actions 무료 한도 안전**. 매시간/매일은 rate limit 위험.

## Repolis와의 연결 (다음 단계)

이 도구가 만들어야 할 `data/logs/_cumulative.csv`가 Repolis 빌더의 입력. Phase 2에서 sigco3111/Repolis fork 시 `scripts/build_repos.py`가 `_cumulative.csv`를 읽도록 조정. **데이터 백엔드와 시각화 프런트가 분리**되어 있어 둘 다 독립적으로 발전 가능.

## 시사점 — "데이터 ≠ 표시" 원칙 재확인 (2026-06-11 학습)

사용자 06-11 Sun 함정: "데이터셋에 있으니 보여주자" 함정. **gh-traffic-monitor는 데이터 수집 도구**이고, Repolis는 시각화 프런트. 이 분리 덕분에:
- 데이터 도구 자체는 단순 (4단계 오케스트레이터)
- 시각화 도구는 데이터 모양에 종속되지 않음
- 다른 시각화 도구 (예: Next.js 대시보드, Notion 임베드) 도 같은 CSV 재사용 가능

**수집 단계에서 metric 4개로 한정한 것**도 이 원칙의 적용 — uniques/clones/forks/views/stars/commits 6개를 다 수집하면 데이터는 풍부하지만 다운스트림 시각화에서 5차원 그래프가 돼버림. **4개면 다운타운/동네/크기/장식 4가지 도시 속성과 1:1 매핑**.