# GitHub Pages Failed-Deploy 진단 (2026-07-07 Repolis 실측)

> Repolis GitHub Pages 자동 배포(`pages-build-deployment`)가 **deploy_pages job에서 5초 polling 직후 `Deployment failed, try again later`** 응답하는 패턴 진단. 코드 회귀가 아니라 Pages 백엔드 일시 장애일 가능성이 가장 높다는 결론 + 그 결론에 도달하기까지의 3단계 recipe.

## 트리거 조건

다음 중 하나라도 해당되면 본 recipe 자동 적용:

- 사용자가 GitHub Pages **deployments 탭에 빨간 X** 스크린샷/이미지를 보냄
- `vercel ls` 또는 GitHub UI에서 "Failed to deploy to github-pages via pages-build-deployment" 메시지 확인됨
- 자동화 cron (예: `chore: refresh Repolis data`)이 푸시됐는데 사이트가 이전 버전 그대로
- "최근 N건 중 일부 fail, 일부는 success" — 인프라 일시 장애 패턴 의심

## 3단계 진단 recipe

### 1단계: deployments API로 최근 N건 패턴 조회

```bash
gh api "repos/<owner>/<repo>/deployments?per_page=10" \
  | python3 -c "
import sys, json
data = json.loads(sys.stdin.read())
for d in data:
    print(f\"  {d['created_at']}  sha={d['sha'][:8]}  id={d['id']}\")
"
```

**시그널 1**: 모든 failed 건이 **같은 workflow run** (예: `actions/deploy-pages@v5` 동일 SHA)에서 발생 → 코드 회귀 ❌, **Pages 백엔드 측 일시 장애 가능성 ⬆**

**시그널 2**: success와 failed 건이 **같은 workflow 동일 버전**에서 교차 발생 → 코드 회귀 ❌❌, Pages 백엔드 일시 장애 가능성 ⬆⬆⬆

### 2단계: 가장 최근 failed 건의 workflow run 로그 직접 fetch

```bash
# deployment_id로 status URL에서 target_url의 run_id 추출
DEPLOY_ID=<failed-deploy-id>
RUN_ID=$(gh api "repos/<owner>/<repo>/deployments/$DEPLOY_ID/statuses" \
  | python3 -c "import sys,json,re
data=json.loads(sys.stdin.read())
for s in data:
    if s['state'] in ('failure','success'):
        m=re.search(r'/actions/runs/(\d+)/', s.get('target_url',''))
        if m: print(m.group(1)); break")
echo "run_id=$RUN_ID"

# 로그 zip fetch + unzip
mkdir -p /tmp/<repo>-logs/run_$RUN_ID
TOKEN=$(gh auth token)
curl -s -L -H "Authorization: token $TOKEN" \
  "https://api.github.com/repos/<owner>/<repo>/actions/runs/$RUN_ID/logs" \
  -o /tmp/<repo>-logs/run_$RUN_ID/log.zip
unzip -o -q /tmp/<repo>-logs/run_$RUN_ID/log.zip -d /tmp/<repo>-logs/run_$RUN_ID/
```

### 3단계: `0_deploy.txt` 본문에서 에러 메시지 + timing 패턴 추출

```bash
cd /tmp/<repo>-logs/run_$RUN_ID
echo "=== Failed step ==="
grep -E '##\[error\]|Deployment failed' 0_deploy.txt | head -3
echo
echo "=== Timing (POST → poll → fail) ==="
grep -E 'Created deployment for|Getting Pages deployment status' 0_deploy.txt | head -2
```

**시그널 3 (결정적)**: 다음 패턴이 모두 맞으면 **Pages 인프라 측 일시 장애 확정**:
- build 단계 ✅ + report-build-status ✅ + deploy 단계 ❌ (deploy 단계의 마지막 step이 fail)
- POST `Created deployment for {sha}` → **정확히 5초 후** → `Getting Pages deployment status` (5초는 `actions/deploy-pages@v5` 기본 polling)
- `##[error]Deployment failed, try again later.` 메시지 — "try again later"은 **재시도 권고** = 인프라 일시 장애의 강한 시그널
- GITHUB_TOKEN Permissions 정상 (Contents: read, Metadata: read, Pages: write)
- artifact 정상 생성 + OIDC token masked된 채 POST 성공

**시그널 4 (코드 회귀 가능성 재확인)**: 위 1~3단계에서 다음이 모두 정상 → **100% 인프라 이슈**:
- 다른 failed 건도 같은 워크플로우 같은 액션 SHA
- 코드 변경 없이 같은 패턴 반복 (Repolis 사례: 4건의 다른 SHA 모두 동일 메시지)
- 빌드 + report-build-status 성공 (= 코드 빌드 자체는 OK)

### 4단계 (선택): 사이트 현재 상태 cross-check

```bash
# Pages 사이트 자체는 정상 동작 확인
curl -sI -L "https://<owner>.github.io/<repo>/" | head -3
curl -s "https://<owner>.github.io/<repo>/" | grep -oE '<title>[^<]+</title>'
```

→ 만약 site가 200이고 `<title>`이 정상인데 **deployments 탭은 failed** 표시 = **이전 성공 deploy가 그대로 serving 중** + 새 commit only failed. 인프라 장애 결론 보강.

## 진단 결론 분류

| 분류 | 시그널 | 권장 다음 행동 |
|---|---|---|
| **인프라 일시 장애** | 시그널 1+2+3+4 (위 패턴) | **그냥 두기** (다음 자동 push 시 self-heal) 또는 **빈 commit 강제 push** (페이지 rebuild 트리거) |
| **코드 회귀 (빌드 실패)** | build 단계 ❌ | 빌드 로그에서 에러 분석, 사용자 코드 검토 |
| **권한 문제** | GITHUB_TOKEN 누락/만료, Pages: write 부재 | Vercel/GitHub 설정에서 Pages 권한 재설정 |
| **LFS/대용량 파일** | artifact > 1GB 또는 checkout 단계 fail | LFS 추적 + git-lfs 설치 |
| **Python action 호환성** | `actions/deploy-pages@v5` 액션 호환성 문제 | 워크플로우 액션 버전 업그레이드 |

## Repolis 4건 cross-check 실측 (2026-07-07)

| # | 시간 (UTC) | commit | run_id | step 실패 | 메시지 |
|---|---|---|---|---|---|
| #27 | 2026-07-06 12:13 | `cc8e583a` | 28790664990 | Deploy to GitHub Pages | `Deployment failed, try again later.` |
| #25 | 2026-07-05 02:58 | `99844d8f` | 28727571090 | 동일 | 동일 |
| #23 | 2026-07-03 10:46 | `fc440a69` | 28655554070 | 동일 | 동일 |
| #22 | 2026-07-03 07:33 | `1faa7190` | 28645683694 | 동일 | 동일 |
| #26 (✅) | 2026-07-06 03:26 | `6b1cfa50` | 28765765009 | (성공) | (없음) |

**모든 fail 건의 공통점**:
- 같은 workflow `pages-build-deployment` + 같은 action `actions/deploy-pages@v5` (SHA cd2ce8fc...)
- 정확히 5초 polling 후 fail
- build + report-build-status 모두 ✅
- 다른 commit (코드 회귀 ❌)
- 사이트 자체는 200 OK, `<title>Repolis · 레포들의 도시 · sigco3111</title>` 정상

→ **인프라 일시 장애 결론**. 다음 자동 cron push가 self-heal 후보.

## 4옵션 제시 패턴 (사용자 권장 진단 보고 형식)

사용자가 "에러 발생" 이미지를 보냈을 때 진단 완료 후 **4옵션 + 추천** 형식으로 응답 (희정님 선호 06-29):

| 옵션 | 설명 | 추천? |
|---|---|---|
| **A. 그냥 두기 (대기)** | 다음 자동 push 시 self-heal, 사이트는 이미 200 정상 | ⭐ **추천** |
| B. 강제 workflow 재실행 | 가장 최근 failed run을 UI에서 Re-run | ⭐ 부추천 (안전 시도) |
| C. 멱등 수동 sync | 빈 commit (`git commit --allow-empty`) + push → 새 deploy 트리거 | ⭐ 부추천 (B보다 확실) |
| D. GH Status 페이지 점검 | `https://www.githubstatus.com` 에서 Pages incident + 환경 inspection | 진단 명확화 필요 시 |

추천을 표시하되 **즉시 행동하지 않고 사용자 응답 대기** (희정님 패턴: "원인만 알고 싶었어" 발견 후 "그냥 둘게" 시 액션 묻기).

## 재현 가능한 helper 스크립트

`scripts/diagnose-github-pages-failed-deploy.sh` (별도 파일) — 본 recipe 1~4단계를 정적 셸 스크립트로 묶음. 사용법:

```bash
bash ~/.hermes/skills/python-oss-bootstrap/scripts/diagnose-github-pages-failed-deploy.sh \
  sigco3111 Repolis
```

출력 예:
```
========================================
GitHub Pages Failed Deploy Diagnosis
========================================
repo: sigco3111/Repolis
recent deployments (5):
  2026-07-06T12:13:41Z  cc8e583a  5329007413
  2026-07-06T03:26:18Z  6b1cfa50  5323970474 ← success pattern control
  ...
========================================
most-recent failed deploy: 5329007413
workflow run: 28790664990
fetching logs... done
========================================
FAILED STEP:
  Deploy to GitHub Pages → ##[error]Deployment failed, try again later.
TIMING:
  Created deployment for cc8e583a (T+0s)
  Getting Pages deployment status... (T+5s)
========================================
SITE CHECK:
  https://sigco3111.github.io/Repolis/ → HTTP 200
  title: Repolis · 레포들의 도시 · sigco3111
========================================
DIAGNOSIS: GitHub Pages BACKEND TRANSIENT FAILURE
- Same workflow / action across all failed runs ✓
- Different commit SHA per failure (code regression ruled out) ✓
- 5-second polling = actions/deploy-pages@v5 default ✓
- Build + report-build-status steps SUCCEED ✓
- Error message contains "try again later" (retry-encouraging) ✓
- Site currently serving 200 OK from previous successful deploy ✓
========================================
recommendation: A (대기 + 다음 자동 push로 self-heal)
```

## 자기 교정 노트 (vercel/SKILL.md 본문 Team-scope SSO 302 와 차이)

이 reference는 **GitHub Pages** 한정. **Vercel deploy race 404** 또는 **team-scope SSO 302**는 다른 메커니즘 → vercel/SKILL.md 본문 함정 참조. 본 reference는 명시적으로 `pages-build-deployment` 워크플로우 한정 (Vercel ❌).

## 다음 진단에 적용

같은 패턴이 또 발생할 때 자동 적용:
1. 사용자가 GitHub Pages deployments 페이지 스크린샷을 보내면
2. 1~3단계 recipe 자동 실행 (deployments API → run_id → 로그 fetch)
3. 시그널 1+2+3+4 매칭 시 4단계 사이트 cross-check
4. 진단 결론 분류표 + 4옵션 보고

**자동화 후보**: `chore:` cron이 push할 때마다 자동으로 배포 상태를 체크해서 실패 패턴 감지 → cron-stale-triage 스킬과 통합 가능 (다음 세션에서 검토).
