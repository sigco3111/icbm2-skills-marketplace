# Vite+React+TS SPA → Vercel Auto-Deploy (sigco-fruitbox 사례, 2026-08-07)

## 배경

fruitboxgame.com/ko 사과게임을 Vite+React+TS+Tailwind 풀 SPA로 구현 + sigco-fruitbox OSS 공개. python-oss-bootstrap의 "단일 HTML 변형"과 다른 **풀 빌드 SPA 변형**이므로 별도 패턴.

**차이점 (python-oss-bootstrap 기준)**:
- 단일 HTML: `index.html` 1개 + JS 인라인, Vercel은 그냥 정적 서빙
- **Vite+React SPA**: tsc + vite 빌드 후 `dist/` 출력, `tsc 0 + build 0`로 만족 ❌ (Playwright/curl alias 검증 필수)

## 결정 4-단계 (sigco-fruitbox 실전)

1. **로컬 폴더**: `~/work/sigco-fruitbox` (이미 만들어진 상태)
2. **HANDOFF_BUGFIX.md**: 새 게임 후 보드 빈 문제 + status 초기화 명시 (`useGame` 훅에서 `createBoard()` + `setStatus('idle')` 명시적 호출)
3. **GitHub repo**: `gh repo create sigco3111/fruitbox --public --source=. --push` (한 번에)
4. **Vercel**: `vercel link` + `vercel deploy --prod` → 자동 배포 trigger (`https://api.vercel.com/v6/deployments?projectId=...&limit=3`)

## Vercel 자동 배포 검증 (3분, 17초 READY)

```bash
# 1) 최신 3개 deployment 확인 — source=git vs source=cli 구분
TOKEN=$(python3 -c "import json; print(json.load(open('/Users/mac/Library/Application Support/com.vercel.cli/auth.json'))['token'])")
curl -sS -H "Authorization: Bearer $TOKEN" \
  "https://api.vercel.com/v6/deployments?projectId=prj_XXX&limit=3" \
  | python3 -c "
import sys, json
from datetime import datetime, timezone
d = json.load(sys.stdin)
for dep in d.get('deployments', []):
    ts = datetime.fromtimestamp(dep['createdAt']/1000, timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
    print(f'{ts}  source={dep.get(\"source\",\"?\")}  trigger={dep.get(\"deployTrigger\",\"?\")}  state={dep.get(\"readyState\")}')
    if dep.get('gitMetadata'):
        print(f'  git commit={dep[\"gitMetadata\"][\"commitSha\"][:10]}  msg={dep[\"gitMetadata\"][\"commitMessage\"][:50]}')
"

# 2) production alias 검증 — 가장 최근 ready production
curl -sI https://sigco-fruitbox.vercel.app | head -3

# 3) asset hash 검증 — 우리 build 로그와 일치하는지
curl -s https://sigco-fruitbox.vercel.app | grep -oE 'index-[A-Za-z0-9_-]+\.(js|css)'
```

**판별 신호**:
- `source=git` + `trigger=git` = GitHub main push로 자동 트리거 (17초 READY)
- `source=cli` = 우리가 `vercel deploy --prod` 직접 실행
- 둘 다 ready면 production alias는 자동 승격 (Vercel 기본 정책)

## ⚠️ 함정 47: HANDOFF_BUGFIX.md 누락

새 게임 후 보드 빈 문제 같은 **post-launch 발견 버그**는 코드 코멘트 + commit 메시지에만 남기면 3개월 후 추적 불가. **반드시 `HANDOFF_BUGFIX.md` 파일에 별도 기록**:
- 무엇이 문제였는지 (사용자 보고 시각)
- 어디서 수정했는지 (파일:라인)
- 왜 발생했는지 (root cause)

sigco-fruitbox v0.1.0 → v0.1.1 사이클:
- v0.1.0: 초기 푸시 + Vercel 자동 배포
- 사용자 피드백: "게임 완료 후 새 게임 하면 빈 보드"
- v0.1.1: `useGame` 훅에 `status` 초기화 + `createBoard()` 명시적 호출 + HANDOFF_BUGFIX.md 추가

## ⚠️ 함정 48: GitHub Actions 메일 지연 (5시간+)

`gh run` 표준 응답은 즉시지만, GitHub Actions의 **이메일 알림**은 별도 워커 큐에서 비동기 발송. 5시간+ 늦게 도착 가능.

**판별**: 사용자가 "방금 실패 메일 받았다"고 하면 → **메일 본문의 headSha/run_id**를 `gh run view <id>`로 바로 검증. 실제 run은 5시간 전 실패였고 현재는 수정 후 success인 케이스 빈번.

sigco3111/batgrl-gallery 사례 (08-07):
- 메일: `Run failed: Sphinx Documentation - main (028aabd)` ← 8시간 전 실패
- `gh run view 028aabd` → 5:06Z fail (첫 시도), 5:08Z success (8e4957d, 권한 fix)
- 메일 = 옛 run, 현재 = 양호

**자동 응답**: `gh run list -L 5 --json createdAt,conclusion,headSha,event`로 실제 타임라인 CSV 추출 → 메일 vs reality gap 명시.

## tsc 0 + build 0 ≠ OK (사용자 정책 엄격)

`tsc 0 + build 0`로 만족 ❌ — **production alias curl + asset hash 검증 필수** (USER.md 정책). sigco-fruitbox 사례:
- `tsc 0` ✅
- `vite build 0, 11초, 41 modules, index-snSJS2x9.js (164.89kB)` ✅
- Vercel 자동 배포 READY (17s) ✅
- production alias curl HEAD 200 OK ✅
- asset hash `index-snSJS2x9.js` 일치 ✅

**5단계 검증 모두 PASS해야 public release 가능**. 다음 세션 이 패턴 자동 적용.

## Vercel 자동 배포 트리거 결정 트리

```
GitHub main push
   ↓
Vercel webhook (vercel.json + .vercel 디렉터리에 link 저장)
   ↓
17초 READY → source=git deployment 생성
   ↓
production alias 자동 승격 (Vercel 기본)
```

**link 안 됐는데 push한 경우**: 새 repo 만들면 자동으로 link 안 됨. **반드시 `vercel link` 후 push** (`.vercel/project.json` gitignored).

## 다음 Vite+React SPA 부트스트랩 시 체크리스트

- [ ] `vercel link` 사전 실행 (`.vercel/project.json` 생성)
- [ ] `.gitignore`에 `.vercel/` 명시
- [ ] `gh repo create --source=. --push` (한 번에)
- [ ] push 후 30초 대기 → Vercel API로 `source=git` deployment 생성 확인
- [ ] production alias HEAD 200 + asset hash 일치 확인
- [ ] HANDOFF_BUGFIX.md 초기 비우기 (release 후 버그 발견 시 추가)
- [ ] GitHub Actions 메일 늦게 와도 `gh run view`로 reality 확인 가능 명시

## 재사용

- 다른 SPA 부트스트랩 (Vue, Svelte, Solid 등)에도 동일 패턴
- `gh repo create --source=. --push` 한 줄이 핵심 — 두 명령 분리보다 안전
- Vercel team-scope prod URL은 anon 302라 README에 alias URL만 (`*.vercel.app`) 박기
