# Bilingual OSS Documentation Pattern (English + Korean `.ko.md`)

> Why, when, and how to ship Korean-translated docs alongside English
> originals. Proven in production with `sigco3111/xmrig-dashboard`
> (2026-06-24, 12 doc files / 3,423 lines / all bilingual).

## Why

sigco3111 (owner) writes English-only by default but consumes Korean. For
**crypto / privacy / finance** OSS, the difference matters because:

- Korean readers will skim the README once and decide whether to trust the
  author. If it's English-only, they'll often bounce.
- Crypto OSS has many gotchas (address formats, fake tokens, exchange KYC
  walls) that read better in the owner's native language.
- A bilingual doc set signals: "this is for Koreans + international" without
  having to maintain two GitHub repos.

**Trigger when**:
- Owner is Korean and writes English as a second language.
- OSS touches Korean-specific friction (Korean exchanges, KYC, Korean
  regulators, Korean user habits).
- The subject (cryptocurrency, fintech, K-content tools, etc.) has a
  significant Korean user base.

**Don't trigger when**:
- OSS is a developer-tool/CLI with a global audience — English-only is fine
  (md-doctor, cron-doctor, kakao-summary all stayed English-only).
- The translations would just be literal; if there's no Korean-specific
  *content* to add, translation adds zero value.

## Pattern: 1 English + 1 Korean per doc, same content

For each `.md` doc, also write `<name>.ko.md` with the **same content in
Korean**. No machine translation, no summary — full mirror. The English
file is the source of truth; the Korean file is for direct reading.

**File structure** (xmrig-dashboard validated):
```
README.md                    # bilingual: EN section + KR section in one file
docs/xmr-overview.md         # English only
docs/xmr-overview.ko.md      # Korean full mirror
docs/getting-started.md      # English only
docs/getting-started.ko.md   # Korean full mirror
... (12 total files: 6 EN + 6 KO for 6 distinct topics)
```

The README itself is bilingual in-place (one section EN, one section KR)
because it's the entry point. Deeper docs are full mirrors.

## Decision points (brainstorm with user first)

| Decision | A (lean) | B (full) | C (skip) | Pick |
|---|---|---|---|---|
| Translation scope | README only | README + all docs | No translation | B if Korean user base |
| README format | bilingual in-place | EN with link to KO | KO only | A — both audiences see content immediately |
| Mirror file naming | `<name>.ko.md` sibling | `ko/<name>.md` subfolder | inline `<details>` blocks | A — GitHub renders both, no folder navigation overhead |
| Sync process | manual on edits | GitHub Action auto-translate | no sync, accept drift | A — translation drift is acceptable; technical accuracy matters more than sentence-level consistency |

## Sync process (manual, accept drift)

**Do NOT auto-translate.** Machine translation produces obvious engrish that
damages the OSS's credibility. Manual translation is one PR per file,
triggered when the EN file changes substantially.

Practical workflow:
1. Update `docs/<name>.md` first (English is source of truth).
2. Open follow-up PR for `docs/<name>.ko.md` with translated content.
3. If only minor changes (typo, link fix), do Korean PR in same commit.
4. If major rewrite, accept temporary drift; KO PR follows within 1-2 days.

**Why accept drift?**:
- English doc updates happen during development (frequent).
- Korean translation is a "polish" step that should follow, not block, releases.
- Tag-based sync (e.g. translate before tagging v0.2.0) keeps major releases coherent.

## README bilingual in-place template

```markdown
# English title

> 1-line tagline

## Quick Start (60 seconds)
[EN content]

## Documentation
[Doc table in English]

## License
[EN license text]

---

# 한국어 제목

> 1줄 슬로건

## 빠른 시작 (60초)
[KO content]

## 문서
[Doc table in Korean]

## 라이선스
[KO license text]
```

Two `---` separator, two `#` H1s (English first, Korean second). GitHub
renders both with anchor links; mobile users see one big page.

## Pitfalls

### 1. Translation file name conflicts with `go.sum`/other ecosystems

- `<name>.ko.md` is fine for GitHub rendering. Won't conflict with anything.
- Avoid `<name>_ko.md` (underscore) — some blog parsers treat it as a separate
  file with the same base. Hyphen is safer.
- Avoid `ko/<name>.md` subfolder — breaks the "every doc file is its own
  link target" assumption; GitHub's permalink + cross-doc references
  need relative paths that go up a level.

### 2. Auto-translation that produces obvious engrish

GPT-style auto-translation of long technical docs produces:
- "체크포인트" for "checkpoint" (sometimes wrong — e.g. Git's "checkpoint"
  should stay English in some contexts)
- Wrong honorifics / politeness levels (Korean tech writing style is
  casual-form)
- Literal translations of idioms that don't exist in Korean

**Rule**: If you can't write the Korean by hand, don't ship it. Bad Korean
is worse than no Korean. A user who reads engrish once never trusts
the rest of the doc.

### 3. Date/time formats differ

- EN: "2026-06-24" (ISO 8601, fine for both)
- KO: "2026년 6월 24일" or "2026-06-24" (use ISO 8601 — it's universal)
- KO readers prefer ISO 8601 for technical content. Don't convert.

### 4. Examples: USD vs KRW

- For crypto OSS, USD is the international standard. Keep USD.
- Add KRW in parentheses only for *retail* price displays (e.g. "1 XMR ≈
  $318 ≈ ₩430,000"). For developer docs (config values, API responses),
  USD is fine.

### 5. Link to Korean-only resources

- If you reference "한국 5대 거래소", add a note: "한국 외 독자는 KuCoin /
  Kraken 같은 국제 거래소 사용 권장".
- Conversely, if you reference international exchanges, add a note for
  Korean readers: "한국 사용자는 KuCoin / MEXC 사용 권장 (Binance는
  한국에서 XMR 미상장)".

This dual-tagging is what makes bilingual docs *useful* instead of just
*translated*.

## When the user requests it

User prompts that trigger this pattern:
- "한글문서도 추가해줘"
- "한국어 버전도 만들어줘"
- "이거 한국 개발자한테도 보여주고 싶어"
- "README 영어인데 한국어로도 보고 싶음"

The decision is always: **bilingual in-place for the README, sibling
`.ko.md` files for deeper docs**. Don't ask the user, just do it — the
trade-off is obvious.

## Effort estimate

- EN README (bilingual in-place): +20% (Korean section is a translation
  of the English section, but you only write one of them and translate
  the other).
- Each `.ko.md` doc: ~30 min for a 300-line doc. ~5 min if it's mostly
  a translation of an already-finalized EN doc.
- Maintenance: 1 PR per substantial EN change. Not free, but
  proportional to doc size.

## Validated case study

`sigco3111/xmrig-dashboard` (2026-06-24):
- 6 distinct doc topics → 12 files (6 EN + 6 KO)
- 3,423 total lines
- Bilingual README in-place (EN section + KO section, single file)
- All Korean translations done in 4 separate PRs over 2 days
- Korean user (sigco3111 / 6ih) reads KO docs, English-speaking users read
  EN docs. Both audiences served without maintaining two repos.

**Anti-pattern (what I almost did)**: only translating the README and
leaving deeper docs English-only. Korean user would read the EN docs via
Google Translate, miss nuances (e.g. "Stealth Address" doesn't translate
well, "subaddress" is a Monero-specific Korean term). Full mirror
solves this.

## Related

- `cryptocurrency-address-verification` skill — the validation step that
  ensures NO PII in either EN or KO docs.
- `python-oss-bootstrap` P31 — OSS 부트스트랩 전 보안 점검 4대 영역.
  Apply same checks to Korean content.
