#!/usr/bin/env bash
# verify-single-html.sh — 단일 HTML 프로젝트 배포 직전 검증
# Usage: bash verify-single-html.sh <path-to-index.html>
#
# 검증 4단계:
#  1) JS 신택스 (script 태그 추출 → new Function)
#  2) IndexedDB 스키마 일관성 (DB_NAME/VERSION/STORE_*)
#  3) 필수 함수 존재 (add/delete/getAll + 이벤트 핸들러)
#  4) 이벤트 리스너 등록 수 (click 핸들러 카운트)
#
# 4단계 모두 PASS 아니면 exit 1 (deploy 금지)

set -o pipefail
PASS=0; FAIL=0

ok() { echo "  ✅ $1"; PASS=$((PASS+1)); }
fail() { echo "  ❌ $1"; FAIL=$((FAIL+1)); }

HTML="${1:-index.html}"

if [ ! -s "$HTML" ]; then
  fail "$HTML 파일 없음 또는 비어있음"
  exit 1
fi

# ─── 1) JS 신택스 ───
echo "[1/4] JS 신택스 검증"
node -e "
const fs = require('fs');
const html = fs.readFileSync('$HTML', 'utf-8');
const m = html.match(/<script>([\s\S]*?)<\/script>/);
if (!m) { console.error('  ❌ no script tag'); process.exit(1); }
try { new Function(m[1]); console.log('  ✅ JS syntax OK (', m[1].length, 'bytes)'); }
catch (e) { console.error('  ❌', e.message); process.exit(1); }
" || { fail "JS 신택스 에러"; exit 1; }

# ─── 2) IndexedDB 스키마 일관성 ───
echo "[2/4] IndexedDB 스키마 일관성"
DB_NAME=$(grep -oE "DB_NAME\s*=\s*['\"][^'\"]+['\"]" "$HTML" | head -1)
VERSION=$(grep -oE "VERSION\s*=\s*\d+" "$HTML" | head -1)
STORES=$(grep -oE "STORE_[A-Z]+\s*=\s*['\"][^'\"]+['\"]" "$HTML" | wc -l | tr -d ' ')
INDEXES=$(grep -cE "createIndex\s*\(\s*['\"]" "$HTML")

if [ -n "$DB_NAME" ]; then ok "DB_NAME 정의됨: $DB_NAME"; else fail "DB_NAME 없음"; fi
if [ -n "$VERSION" ]; then ok "VERSION: $VERSION"; else fail "VERSION 없음"; fi
if [ "$STORES" -ge 1 ]; then ok "STORE 정의: $STORES개"; else fail "STORE 정의 없음"; fi
if [ "$INDEXES" -ge 1 ]; then ok "createIndex: $INDEXES개"; else fail "createIndex 없음 — 마이그레이션 위험"; fi

# ─── 3) 필수 함수 존재 ───
echo "[3/4] 필수 함수/핸들러"
HAS_OPENDB=$(grep -cE "function\s+openDB" "$HTML")
HAS_ADD=$(grep -cE "\.add\s*\(" "$HTML")
HAS_GETALL=$(grep -cE "\.getAll\s*\(" "$HTML")
HAS_DELETE=$(grep -cE "\.delete\s*\(" "$HTML")
HAS_UPDATE_TS=$(grep -cE "updateTimestamp|put\s*\(" "$HTML")

[ "$HAS_OPENDB" -ge 1 ] && ok "openDB 함수 존재" || fail "openDB 없음"
[ "$HAS_ADD" -ge 1 ] && ok "add 호출 존재" || fail "add 호출 없음"
[ "$HAS_GETALL" -ge 1 ] && ok "getAll 호출 존재" || fail "getAll 호출 없음"
[ "$HAS_DELETE" -ge 1 ] && ok "delete 호출 존재" || fail "delete 호출 없음"

# ─── 4) 이벤트 리스너 등록 ───
echo "[4/4] 이벤트 리스너"
CLICK_HANDLERS=$(grep -cE "addEventListener\s*\(\s*['\"]click['\"]" "$HTML")
CHANGE_HANDLERS=$(grep -cE "addEventListener\s*\(\s*['\"](input|change)['\"]" "$HTML")
PASTE_HANDLERS=$(grep -cE "addEventListener\s*\(\s*['\"]paste['\"]" "$HTML")

[ "$CLICK_HANDLERS" -ge 1 ] && ok "click 핸들러: $CLICK_HANDLERS개" || fail "click 핸들러 0개 — UI 동작 안 됨"
[ "$CHANGE_HANDLERS" -ge 1 ] && ok "input/change 핸들러: $CHANGE_HANDLERS개" || echo "  ℹ️ input/change 핸들러 없음 (검색/설정 UI 없는 경우 정상)"

echo ""
echo "총 $((PASS+FAIL))개 검증 / PASS=$PASS / FAIL=$FAIL"
[ "$FAIL" -eq 0 ] && echo "✅ deploy 가능" || echo "❌ deploy 금지 — FAIL 항목 수정 후 재실행"
exit $FAIL
