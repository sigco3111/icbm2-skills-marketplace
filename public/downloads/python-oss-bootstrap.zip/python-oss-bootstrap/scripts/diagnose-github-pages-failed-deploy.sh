#!/usr/bin/env bash
# scripts/diagnose-github-pages-failed-deploy.sh
#
# GitHub Pages failed deploy 1~4단계 진단 recipe (정적 helper).
# python-oss-bootstrap/references/diagnose-github-pages-failed-deploy.md 의 자동화 버전.
#
# Usage:
#   bash diagnose-github-pages-failed-deploy.sh <owner> <repo>
#   bash diagnose-github-pages-failed-deploy.sh sigco3111 Repolis
#
# Output:
#   - 최근 10건 deployments 패턴
#   - 가장 최근 failed 건의 workflow run + step 실패 메시지 + timing
#   - 사이트 현재 상태 (HTTP 200 + <title>)
#   - 인프라 일시 장애 / 코드 회귀 / 권한 등 결론 + 추천 옵션
#
# Exit codes:
#   0 = 인프라 일시 장애 결론 (그냥 두기)
#   1 = 진단 실패 또는 다른 결론 (manual 검토 필요)
#
# Requires: gh CLI (authenticated), curl, python3, unzip.
# Discovered 2026-07-07 in Repolis GitHub Pages diagnosis.

set -eo pipefail

OWNER="${1:?Usage: $0 <owner> <repo>}"
REPO="${2:?Usage: $0 <owner> <repo>}"
TMPDIR=$(mktemp -d -t ghpages-diag-XXXXXX)
trap "rm -rf $TMPDIR" EXIT

bar() { printf '\n========================================\n%s\n========================================\n' "$1"; }

bar "GitHub Pages Failed Deploy Diagnosis"
echo "repo: $OWNER/$REPO"
echo "tmpdir: $TMPDIR"

bar "Step 1: Recent deployments (latest 10)"
gh api "repos/$OWNER/$REPO/deployments?per_page=10" \
  | python3 -c "
import sys, json
data = json.loads(sys.stdin.read())
for d in data:
    print(f\"  {d['created_at']}  sha={d['sha'][:8]}  id={d['id']}\")
"

# 가장 최근 deploy id
LATEST_DEPLOY=$(gh api "repos/$OWNER/$REPO/deployments?per_page=10" \
  | python3 -c "import sys,json; print(json.loads(sys.stdin.read())[0]['id'])")
echo "latest deployment id: $LATEST_DEPLOY"

# 해당 deploy의 status 중 failure를 가진 run_id 추출
RUN_ID=$(gh api "repos/$OWNER/$REPO/deployments/$LATEST_DEPLOY/statuses" \
  | python3 -c "
import sys, json, re
data = json.loads(sys.stdin.read())
for s in data:
    if s['state'] in ('failure','success'):
        m = re.search(r'/actions/runs/(\d+)/', s.get('target_url',''))
        if m:
            print(m.group(1))
            break
")

if [ -z "$RUN_ID" ]; then
  echo "❌ no completed workflow run found for deployment $LATEST_DEPLOY"
  exit 1
fi
echo "workflow run_id: $RUN_ID"

bar "Step 2: Fetching logs for run $RUN_ID"
mkdir -p "$TMPDIR/run_$RUN_ID"
TOKEN=$(gh auth token)
HTTP_CODE=$(curl -s -o "$TMPDIR/run_$RUN_ID/log.zip" \
  -w "%{http_code}" \
  -L -H "Authorization: token $TOKEN" \
  "https://api.github.com/repos/$OWNER/$REPO/actions/runs/$RUN_ID/logs")
echo "log download HTTP: $HTTP_CODE"
unzip -o -q "$TMPDIR/run_$RUN_ID/log.zip" -d "$TMPDIR/run_$RUN_ID/"

bar "Step 3: Extract failed step + timing"
cd "$TMPDIR/run_$RUN_ID"
if [ -f 0_deploy.txt ]; then
  echo "--- FAILED STEP ---"
  grep -E '##\[error\]|Deployment failed' 0_deploy.txt | head -3 | sed 's/^/  /'
  echo
  echo "--- TIMING (POST → poll → fail) ---"
  grep -E 'Created deployment for|Getting Pages deployment status' 0_deploy.txt \
    | head -2 | sed 's/^/  /'
else
  echo "❌ 0_deploy.txt not in log archive"
  exit 1
fi

bar "Step 4: Site sanity cross-check"
echo "checking https://$OWNER.github.io/$REPO/"
SITE_HTTP=$(curl -s -o /dev/null -w "%{http_code}" -L "https://$OWNER.github.io/$REPO/")
echo "  HTTP: $SITE_HTTP"
if [ "$SITE_HTTP" = "200" ]; then
  TITLE=$(curl -s -L "https://$OWNER.github.io/$REPO/" | grep -oE '<title>[^<]+</title>' | head -1)
  echo "  $TITLE"
fi

bar "CONCLUSION"
# 시그널 1+2+3+4 매칭 체크 (간단 휴리스틱)
HAS_TRY_AGAIN=$(grep -c 'try again later' "$TMPDIR/run_$RUN_ID/0_deploy.txt" 2>/dev/null || echo 0)
SITE_OK=0
[ "$SITE_HTTP" = "200" ] && SITE_OK=1

if [ "$HAS_TRY_AGAIN" -gt 0 ] && [ "$SITE_OK" -eq 1 ]; then
  cat <<EOF
DIAGNOSIS: GitHub Pages BACKEND TRANSIENT FAILURE
- build + report-build-status steps SUCCEED ✓
- "try again later" message present (retry-encouraging) ✓
- Site currently serving 200 OK from previous successful deploy ✓
- Same workflow/action across multiple failures = infra not code ✓
EOF
  echo
  echo "recommendation: A (대기 + 다음 자동 push로 self-heal)"
  echo "  - 빈 commit push (B/C 옵션) 도 가능하지만 시도 비용 0이 아님"
  exit 0
else
  cat <<EOF
DIAGNOSIS: UNCLEAR — manual review recommended
- "try again later" message: ${HAS_TRY_AGAIN}
- Site HTTP: ${SITE_HTTP}
- 다른 진단 경로 검토 (코드 회귀, 권한, LFS 등)
EOF
  exit 1
fi
