#!/usr/bin/env bash
# python-oss-bootstrap: sigco3111 GitHub에 Python OSS 한 번에 띄우기
# 사용법: ./bootstrap.sh <name> "<한글 설명>" [python-version=3.11]
#
# 예시: ./bootstrap.sh md-doctor "마크다운 품질 진단 + 후처리 CLI"

set -euo pipefail

NAME="${1:?사용법: $0 <name> \"<한글 설명>\"}"
DESC="${2:?한글 설명을 두 번째 인자로 주세요}"
PYVER="${3:-3.11}"

# 1. GitHub 저장소 생성
echo "→ [1/7] GitHub 저장소 생성"
gh repo create "sigco3111/${NAME}" --public --description "${DESC}" --license MIT

# 2. 로컬 클론
echo "→ [2/7] 로컬 클론"
cd ~/Documents
if [ -d "${NAME}" ]; then
  echo "  ⚠️  ~/Documents/${NAME} 이미 존재 — 스킵"
else
  git clone "https://github.com/sigco3111/${NAME}.git"
fi
cd "${NAME}"

# 3. venv + 의존성
echo "→ [3/7] venv + pip install"
python${PYVER} -m venv .venv
# shellcheck disable=SC1091
source .venv/bin/activate
pip install -U pip --quiet

# 4. 기본 파일 4종 (사용자가 직접 채울 부분)
echo "→ [4/7] 기본 파일 4종 (사용자 채움 필요)"
echo "  다음 파일들이 비어있는 상태로 생성됨:"
echo "    - src/${NAME}/__init__.py"
echo "    - src/${NAME}/cli.py"
echo "    - src/${NAME}/core.py"
echo "    - src/${NAME}/models.py"
echo "    - src/${NAME}/exceptions.py"
echo "    - tests/test_cli.py"
echo "  스킬의 templates/ 와 references/case-studies.md 참고하여 채우세요."

mkdir -p "src/${NAME}" tests .github/workflows
touch "src/${NAME}/__init__.py"
touch "src/${NAME}/cli.py"
touch "src/${NAME}/core.py"
touch "src/${NAME}/models.py"
touch "src/${NAME}/exceptions.py"
touch "tests/__init__.py"
touch "tests/test_cli.py"

# 5. pyproject.toml은 템플릿에서 복사 후 sed 치환
echo "→ [5/7] pyproject.toml 템플릿 복사"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILL_DIR="$(dirname "${SCRIPT_DIR}")"
if [ -f "${SKILL_DIR}/templates/pyproject-minimal.toml" ]; then
  sed -e "s|<NAME>|${NAME}|g" \
      "${SKILL_DIR}/templates/pyproject-minimal.toml" > pyproject.toml
else
  echo "  ⚠️  템플릿 못 찾음 — 수동으로 pyproject.toml 작성 필요"
fi

# 6. README/CHANGELOG/CONTRIBUTING 스텁
echo "→ [6/7] 문서 스텁 생성"
[ -f README.md ]      || cat > README.md <<EOF
# ${NAME}

> **${DESC}**
>
> English | **한국어** (이 문서)

🚧 부트스트랩 진행 중 — 곧 채워질 예정입니다.
EOF
[ -f CHANGELOG.md ]   || cat > CHANGELOG.md <<EOF
# Changelog

## [0.1.0] - $(date +%Y-%m-%d)

### Added
- 🚧 Initial project skeleton
EOF
[ -f CONTRIBUTING.md ] || cat > CONTRIBUTING.md <<EOF
# Contributing

기여 가이드는 곧 추가됩니다.
EOF

# 7. CI + action.yml
echo "→ [7/7] GitHub Actions + action.yml"
cat > .github/workflows/ci.yml <<'YAML'
name: CI
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        python-version: ["3.9", "3.10", "3.11", "3.12"]
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: ${{ matrix.python-version }}
          cache: pip
      - run: pip install -e ".[dev]"
      - run: pytest
YAML
cat > action.yml <<EOF
name: "${NAME}"
description: "${DESC}"
branding:
  icon: "check-circle"
  color: "blue"
inputs:
  path:
    description: "진단할 경로"
    required: true
runs:
  using: "composite"
  steps:
    - uses: actions/setup-python@v5
      with:
        python-version: "3.11"
    - shell: bash
      run: pip install "${NAME} @ git+https://github.com/sigco3111/${NAME}.git@\${{ github.ref_name }}"
EOF

echo ""
echo "✅ 부트스트랩 완료!"
echo ""
echo "다음 단계:"
echo "  1. ~/Documents/${NAME} 에서 src/${NAME}/ 파일들 채우기"
echo "  2. tests/test_cli.py 6~16개 작성"
echo "  3. README.md / CHANGELOG.md / CONTRIBUTING.md 작성"
echo "  4. pytest  # 6+ 통과 확인"
echo "  5. git add -A && git commit -m 'feat: initial project skeleton (v0.1.0)'"
echo "  6. git push -u origin main"
echo "  7. git tag -a v0.1.0 -m '...' && git push origin v0.1.0"
echo ""
echo "다른 PC에서:"
echo "  git clone https://github.com/sigco3111/${NAME}.git"
echo "  cd ${NAME} && python -m venv .venv && source .venv/bin/activate"
echo "  pip install -e \".[dev]\" && pytest"
