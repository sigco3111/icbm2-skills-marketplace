---
name: python-oss-bootstrap
description: "sigco3111 GitHub에 작은 Python OSS 라이브러리/CLI를 부트스트랩하는 전체 워크플로 — 저장소 생성 → pyproject.toml 골격 → 소스 스텁 → pytest → README/CHANGELOG/CONTRIBUTING → GitHub Actions CI + action.yml → v태그 푸시 → About 한글화. hwp2md, md-doctor, cron-doctor, kakao-summary, opencode-trading, opencode-harness-bridge로 실전 검증. Phase 0 (다른 PC 변형 — **다른 스택에서도 docs-only + 다른 PC 핸드오프 패턴 적용 가능**), Phase 1 (이 PC 직접 풀 부트스트랩), 외부 도구 wrapping (MCP/CLI 통합) 변형, 메타 어댑터 (N:M 변환 + 4-tier 안전 정책) 변형, 이름 변경 워크플로 + 네이밍 후회 패턴 포함."
trigger: "Python 라이브러리/CLI 신규 프로젝트를 sigco3111 GitHub에 처음 만들 때, 또는 다른 사람의 '새 Python OSS 시작' 요청을 처리할 때. '서브프로젝트 만들어줘', 'OSS 부트스트랩', 'pyproject.toml 골격 만들어줘', '새 프로젝트 시작하고 싶어' 같은 요청에 활성화. 음악/디자인처럼 '방향 정해지면 시작' 류 요청에도 동일하게 적용 가능. **Adaptor 클래스 (외부 도구 A → 외부 도구 B 포맷 변환) OSS 부트스트랩 시** `references/adaptor-oss-class.md` 로드. **다른 스택(TS/React Native 등) 'docs-only Phase 0 + 다른 PC 핸드오프'만 필요하면** 본 skill의 Phase 0 절차 + `devops/canvas-static-site-pipeline`의 '플랫폼 SDK 미니앱 변형' 차용 (2026-06-18 dongne-today 앱인토스 챌린지 검증)."
last_updated: 2026-06-18
status: battle-tested
---

# Python OSS 부트스트랩 워크플로

sigco3111 GitHub 조직에 **작고 마른 Python OSS**를 한 세션에 띄우는 검증된 10단계 레시피. `hwp2md`(v1.0.0), `md-doctor`(v0.1.0), `cron-doctor`(Phase 0 v0.1.0), `kakao-summary`(Phase 1 v0.1.0, 원래 이름 kmsg-doctor), `opencode-trading`(Phase 0 v0.1.0, adaptor 클래스)에서 실전 검증.

## 트리거 조건

다음 중 하나라도 해당되면 이 스킬을 로드:
- "Python 라이브러리/CLI 새 프로젝트 만들어줘"
- "sigco3111/[name] 저장소 만들어줘"
- "hwp2md처럼 [name] 만들어줘"
- "서브프로젝트 부트스트랩"
- "pyproject.toml 골격 + CLI 엔트리포인트 + GitHub Action 한 번에"

## 10단계 레시피

### 1단계: GitHub 저장소 생성

```bash
gh repo create sigco3111/<name> --public \
  --description "<한글 한 줄 설명 — 영문은 나중에>" \
  --license MIT
cd ~/Documents
git clone https://github.com/sigco3111/<name>.git
```

> ⚠️ **이름 선택은 신중히** — 사용자가 "kmsg-doctor → kakao-summary"로 이름 변경을 요청한 사례가 있음 (2026-06-16, 1세션 만에). 처음부터 **기능 + 도메인 직관성**을 모두 담은 이름을 추천. 자세한 네이밍 의사결정은 `references/case-studies.md`의 "kakao-summary 사례" + 본 문서 "8단계 시작 전 — 브레인스토밍" 섹션 참고. **이름이 애매하면 사용자에게 옵션 3개 + 추천 제시하고 확인** (사용자 "그대로 진행해" 패턴이지만 이름은 예외 — 잘못 고르면 10분 손해).

### Phase 0 변형: "코드는 다른 PC에서, 이 PC에선 README + 라이선스만"

다음 경우 1~7단계를 생략하고 Phase 0만 실행:
- "계획만 세우고", "방향 정해지면 저장소/README만 만들어줘", "다른 PC에서 작업" 식 명시 요청
- 1개가 아니라 **여러 repo**를 한 번에 (예: 코어 + 장르 플러그인 N개)
- 코드 작성은 사용자 본인이 다른 PC에서 직접

**Phase 0 변형 레시피**:

1. **워크스페이스에 디렉토리 만들기** (이 PC)
   - 경로: `~/.openclaw/workspace/<name>/` (기존 작업물과 격리)
2. **파일 3종**:
   - `README.md` (이 스킬 8단계의 README 가이드 적용, 단 "Quick Start"는 "Phase 1+ 작업은 다른 PC에서"로 안내)
   - `LICENSE` (Apache 2.0 또는 MIT)
   - `.gitignore` (장르별 차이 — 게임 데이터는 `games/*/` gitignore)
3. **소스 스켈레톤** (다른 PC 작업자용 docstring 가이드 포함) — `mkdir -p` 한 번 더, 그 다음 `touch`:
   ```bash
   # ⚠️ 함정: `mkdir -p A B` 한 줄로 여러 dir을 만들고 바로 그 안 파일을 touch하면
   # 두 번째 dir의 parent가 아직 안 만들어져서 실패할 수 있음. 안전하게 두 단계로:
   mkdir -p src/cron_doctor/checks src/cron_doctor/parsers tests/fixtures .github/workflows
   touch src/cron_doctor/__init__.py src/cron_doctor/__main__.py ... \
         src/cron_doctor/parsers/__init__.py src/cron_doctor/parsers/cron_expr.py
   ```
   **각 스텁 파일에 다른 PC 작업자용 docstring을 넣는다** — 모듈 책임, 구현 가이드, trade-off 결정 포인트, 코드 예시 골격. cron-doctor의 경우 (2026-06-16) `models.py`에는 "순환 import 방지 패턴: core와 checks 모두 models만 직접 import" 같은 가이드, `Y001_yaml.py`에는 "PyYAML 의존성 vs 자체 구현 trade-off" 결정 가이드, `cli.py`에는 "`nargs='?'` 잊지 말 것" 함정 알림을 넣었음. **이게 다른 PC 작업자가 빈 파일 보고 헤매지 않게 하는 핵심**.
4. **`git init -b main` + 커밋** (한 번에)
5. **`gh repo create --public --source=<dir> --remote=origin --push`** (한 번에 repo 생성 + 푸시)
6. (선택) 아키텍처 결정 문서는 `~/.openclaw/workspace/` 에 별도 `.md` 로 저장 (repo에 안 들어감)

**검증된 사례**:
- `ai-gm-core` + `ai-gm-strategy-war` 2개 repo를 한 세션에서 5분 안에 GitHub public 생성 완료 (2026-06-12)
- `cron-doctor` 1개 repo를 README/About + 5개 검사 모듈 + 2개 파서 스켈레톤(각각 docstring 가이드) + v0.1.0 태그까지 완성 (2026-06-16). 다른 PC 작업자가 모델 → 파서 → 검사 → CLI → 테스트 순서로 진행 가능.

**장르별 repo 구조 (AI 게임/멀티 플러그인 시)**: 코어 1개 + 플러그인 N개 → 각각 독립 repo, 공통 로직은 코어에. 플레이스홀더 디렉토리는 `.gitkeep` 사용.

### Phase 1 변형: "이 PC에서 직접 풀 부트스트랩" (2026-06-16 kakao-summary)

Phase 0의 반대 — 사용자가 명시적으로 "이번 PC에서 직접 작업" 또는 "에르메스 PC에서 작업" 같은 요청을 하면 Phase 0가 아닌 **풀 10단계 부트스트랩**을 한 세션에 끝낸다. 외부 도구 wrapping (MCP/CLI 통합) OSS에 특히 적합.

**Phase 1의 차이점**:
1. **소스 코드를 직접 작성** (스텁 아님) — 핵심 모듈 3~4개는 실제로 동작
2. **테스트도 직접 작성** — 6~32개 단위 테스트, 모두 통과
3. **CLI 동작 검증** — `kakao-summary --version` + `kakao-summary --help` + 실제 demo 출력 1번
4. **외부 의존성은 subprocess로** — kmsg-mcp를 pip 패키지가 아닌 stdio JSON-RPC 클라이언트로 통합 (zero-deps 유지). **단, kmsg 같은 macOS GUI 도구는 PTY 할당 필수** (subprocess.run no-TTY는 hang) — 자세한 함정은 `references/external-tool-wrapping.md` 참고.

**Phase 1 레시피 (kakao-summary 사례 기반, 9단계)**:
1. **브레인스토밍** — 5개 결정 포인트 (이름/범위/통합 방식/출력/저장소) 옵션 A/B/C + 추천 제시
2. **워크스페이스 디렉토리** + **소스 9개 모듈 스켈레톤 + 핵심 4개 실제 구현**:
   - `models.py` (도메인 타입, frozen dataclass + Literal)
   - `exceptions.py` (베이스 + N개 서브클래스)
   - `kmsg_client.py` (외부 도구 stdio 클라이언트 — 아래 "외부 도구 wrapping" 섹션 참고)
   - `prefilter.py` (의미 있는 메시지만 필터링, 1000→300 압축)
   - `cache.py` (SQLite, ID 기반 upsert, 시간 윈도우 쿼리 — 아래 "SQLite 캐시 패턴" 참고)
   - `summarizer.py` (결정론적 그룹핑, 시간 갭 기준)
   - `formatter.py` (text/telegram/json 다중 출력)
   - `core.py` (오케스트레이션)
   - `cli.py` (argparse 4~5개 서브 명령 + 단축 사용)
3. **CLI entry point** — `pyproject.toml`의 `[project.scripts]`에 등록
4. **venv + pip install -e ".[dev]"** — `python3 -m venv venv && pip install -e ".[dev]"`
5. **fixture + 단위 테스트 6~32개** — `tests/fixtures/sample.json` + `tests/conftest.py` + 모듈별 `test_*.py`
6. **pytest 실행 + 디버그** — 1~2개 실패는 정상, lsp/pyright 에러는 어노테이션 추가로 해결
7. **README (다층 옵션)** — "Phase 0 다른 PC 작업" 대신 "다른 PC 작업 흐름" 섹션 생략, **실제 출력 예시** + **아키텍처 다이어그램** + **토큰 비용 분석** 추가
8. **git init + commit + gh repo create + push + tag** (Phase 0와 동일)
9. **GitHub 페이지에서 렌더링 확인** — `mcp_ddg_search_fetch_content`로 fetch_content로 README 표시 검증

**검증된 사례**:
- `kakao-summary` v0.1.0 (2026-06-16, 원래 이름 kmsg-doctor) — 9개 모듈 + 32/32 테스트 통과 (0.14s) + README 12KB 한/영 병기 + v0.1.0 태그 + GitHub public + 실제 카드뉴스 출력 검증. **소요 시간 ~35분** (cron-doctor Phase 0의 23분보다 약간 더, 외부 도구 통합이 까다로움). **이름 변경 1회 추가 작업** 후 v0.1.0 재태그 푸시.

### Phase 1.5 변형: "이름 변경 워크플로" (2026-06-16 kakao-summary)

사용자가 1~10단계 완료 후 "이름은 다시 정하자" 또는 "프로젝트명이 적합하지 않은것 같아" 같은 요청을 보내면 다음을 **한 세션 안에** 끝낸다. 사용자는 이미 기능에 만족하고 이름만 바꾸는 거라 **소요 시간 5~10분**.

**이름 변경 워크플로 6단계**:
1. **`gh repo rename <new-name> --yes`** (⚠️ owner prefix 없이 이름만! `sigco3111/...` 형식 ❌)
   ```bash
   # ❌ 잘못된 사용
   gh repo rename sigco3111/kakao-summary --confirm
   # → "New repository name cannot contain '/' character" 에러
   # ✅ 올바른 사용
   gh repo rename kakao-summary --yes
   ```
2. **`git remote set-url origin https://github.com/sigco3111/<new-name>.git`** (로컬 remote URL 동기화)
3. **모든 파일의 옛 이름 일괄 변경** (sed):
   ```bash
   # Python 소스: import + module references
   find src tests -name "*.py" -exec sed -i '' 's/<old_module>/<new_module>/g' {} +
   # README/CHANGELOG/CONTRIBUTING: 하이픈 표기 + 언더스코어 표기 모두
   sed -i '' 's/<old-name>/<new-name>/g' README.md CHANGELOG.md CONTRIBUTING.md
   sed -i '' 's/<old_module>/<new_module>/g' README.md CHANGELOG.md CONTRIBUTING.md
   # 도큐먼트 내부에 남은 하이픈 표기 한 번 더
   find src tests -name "*.py" -exec sed -i '' 's/<old-name>/<new-name>/g' {} +
   ```
4. **디렉토리 rename** — `git mv`로 history 보존:
   ```bash
   git mv src/<old_module> src/<new_module>
   # git이 나머지 파일 import 변경을 자동 감지 → R (rename) 상태
   ```
5. **venv 재생성 + pytest 재검증** — 32/32 통과 확인 (이름 변경이 로직에 영향 주면 안 됨)
6. **v0.1.0 태그 force-update**:
   ```bash
   git tag -d v0.1.0 && git push origin :refs/tags/v0.1.0
   git tag -a v0.1.0 -m "v0.1.0 - ... (프로젝트명: <new-name>, <date> rename)"
   git push origin v0.1.0
   ```
7. **별도 커밋 메시지** — `refactor: rename <old> → <new>` (변경 이유 + 검증 결과 명시)

**검증된 사례**: kakao-summary (2026-06-16) — kmsg-doctor v0.1.0 완성 직후 5분 만에 rename 완료. 32/32 테스트 그대로 통과, CLI 데모 정상, GitHub redirect 자동 (`sigco3111/kmsg-doctor` URL은 그대로 살아있고 `kakao-summary`로 리다이렉트).

**⚠️ 함정 2가지**:
1. **`gh repo rename`에 owner prefix 붙이지 말 것** — `/`가 들어가서 거부됨. `gh repo rename <new-name> --yes` 형식.
2. **이름 변경 후에는 GitHub URL이 redirect되지만 로컬에서 `git clone https://github.com/sigco3111/<old>.git`은 깨짐** — 사용자에게 새 URL 안내 + README/INSTALL에도 새 URL로 업데이트.

### 네이밍 의사결정 — 후회 패턴 (2026-06-16 학습)

OSS 부트스트랩 시 **이름은 가장 먼저 결정하지만, 가장 후회하기 쉬운 결정**. 사용자가 1세션 만에 `kmsg-doctor → kakao-summary`로 바꾼 사례에서 추출한 원칙:

| 원칙 | 설명 | 예시 |
|---|---|---|
| **기능 명시** | 이름만 봐도 무엇을 하는지 알 수 있어야 함 | `kakao-summary` ✅ / `kmsg-doctor` 🟡 (doctor 컨셉 모호) |
| **도메인 직관성** | 타겟 사용자가 검색할 만한 키워드 포함 | `kakao` > `chat` > `thread` (한국 사용자 대상 시) |
| **시리즈 일관성** | md-doctor / cron-doctor / chat-doctor 처럼 통일 | 통일성 챙기면 chat-doctor, 직관성 챙기면 kakao-digest |
| **확장성** | 미래 어댑터 추가 시 이름이 안 깨지는지 | `kakao-summary` (✅ 다른 메신저 추가 시 `slack-summary` 가능) |
| **브랜드 검토** | trademark 정책 (kakao는 합법적 사용 가능) | "kakao"는 kmsg-mcp도 사용 중이라 OK |

**실전 체크리스트** (이름 결정 전):
- [ ] 1년 후 검색했을 때 내 OSS가 상단에 노출되는 이름인가?
- [ ] README 첫 줄 읽기 전에 무엇을 하는 도구인지 알 수 있는가?
- [ ] 다른 메신저/도구로 확장 시 이름이 부끄럽지 않은가?
- [ ] trademark 정책에 걸리지 않는가?

**사용자 "그대로 진행해" 패턴**에서도 이름은 옵션 3개 + 추천을 명확히 제시하고 확인. 5분 더 일찍 옵션 3개를 보여줬다면 kmsg-doctor → kakao-summary rename 5분을 절약할 수 있었음.

### 외부 도구 wrapping 패턴 — MCP/CLI stdio 통합 (2026-06-16 kakao-summary)

OSS가 다른 도구의 Python wrapper일 때 (예: kmsg-mcp를 stdio JSON-RPC으로 호출), 이 패턴 적용:

**1. `<tool>_client.py` — stdio JSON-RPC 클라이언트**:
```python
import subprocess, json, sys
from .exceptions import ToolUnavailableError, NotFoundError
from .models import RawData

DEFAULT_SERVER_PATH = "~/.local/share/<tool>-mcp/<tool>-mcp.py"

class ToolClient:
    def __init__(self, server_path: str = DEFAULT_SERVER_PATH, python_bin: str = sys.executable):
        self.server_path = os.path.expanduser(server_path)
        self._proc: subprocess.Popen | None = None
        self._request_id = 0

    def __enter__(self): self.start(); return self
    def __exit__(self, *exc): self.close()

    def start(self):
        try:
            self._proc = subprocess.Popen(
                [self.python_bin, "-u", self.server_path],
                stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                text=True, bufsize=1,
            )
        except FileNotFoundError as e:
            raise ToolUnavailableError(f"서버를 찾을 수 없음: {self.server_path}") from e

    def close(self):
        if self._proc:
            self._proc.stdin.close()
            self._proc.terminate()
            self._proc.wait(timeout=5)
            self._proc = None

    def _send_request(self, method: str, params: dict) -> dict:
        if self._proc is None: raise ToolUnavailableError("start() 먼저")
        request = {"jsonrpc": "2.0", "id": self._next_id(), "method": method, "params": params}
        self._proc.stdin.write(json.dumps(request) + "\n")
        self._proc.stdin.flush()
        return json.loads(self._proc.stdout.readline())
```

**⚠️ 함정 4가지**:
1. **text=True + bufsize=1** — JSON 한 줄 단위 통신, 안 그러면 응답이 안 옴
2. **`-u` 플래그** — Python 출력 버퍼링 비활성화, 안 그러면 stdin flush 안 됨
3. **subprocess.PIPE × 3개** — stdin/stdout/stderr 모두 PIPE, 그래야 동기 통신 가능
4. **에러 시 stderr 읽기** — `tool_unavailable` 시 `self._proc.stderr.read()`로 디버깅 정보 노출

**2. 외부 도구 응답 파싱 — 견고하게**:
```python
# 좋은 패턴: 응답 포맷이 배열/객체/문자열 어디든 처리
content = response.get("result", {}).get("content", [])
messages_data = []
for item in content:
    if item.get("type") == "text":
        try:
            parsed = json.loads(item["text"])
            if isinstance(parsed, list):
                messages_data.extend(parsed)
            elif isinstance(parsed, dict) and "messages" in parsed:
                messages_data.extend(parsed["messages"])
        except (json.JSONDecodeError, KeyError):
            continue
```

**3. README에 의존성 명시**: "kakao-summary는 단독으로 동작 안 함. 먼저 kmsg-mcp 설치 + Accessibility 권한 필요" — 이게 **솔직한 전제 조건** (사용자 06-11 "데이터 ≠ 표시" 원칙과 정합).

### SQLite 캐시 패턴 (kakao-summary 2026-06-16, 재사용 가능)

외부 API의 `limit=100` 같은 한계를 **로컬 SQLite로 우회**하는 패턴. 1000개 단톡방, 30일 단위 cron 등 어떤 도구든 적용 가능.

**스키마 — ID 기반 upsert + 시간 인덱스**:
```sql
CREATE TABLE IF NOT EXISTS messages (
    id TEXT PRIMARY KEY,
    chat TEXT NOT NULL,
    sender TEXT NOT NULL,
    text TEXT NOT NULL,
    timestamp INTEGER NOT NULL,  -- epoch 초
    type TEXT NOT NULL DEFAULT 'text'
);
CREATE INDEX IF NOT EXISTS idx_chat_ts ON messages (chat, timestamp);
```

**upsert 패턴** (중복 ID는 갱신):
```python
def upsert(self, messages: list[RawMessage]) -> int:
    if not messages: return 0
    with self._conn() as conn:
        rows = [(m.id, m.chat, m.sender, m.text, int(m.timestamp.timestamp()), m.type) for m in messages]
        conn.executemany(
            """
            INSERT INTO messages (...) VALUES (?, ?, ?, ?, ?, ?)
            ON CONFLICT(id) DO UPDATE SET
                sender=excluded.sender, text=excluded.text,
                timestamp=excluded.timestamp, type=excluded.type
            """, rows,
        )
    return len(messages)
```

**시간 윈도우 쿼리** (since/until은 tz-aware datetime):
```python
def get_by_chat(self, chat, since=None, until=None) -> list[RawMessage]:
    query = "SELECT ... WHERE chat = ?"
    params = [chat]
    if since:
        ts = int(since.replace(tzinfo=timezone.utc).timestamp()) if since.tzinfo is None else int(since.timestamp())
        query += " AND timestamp >= ?"; params.append(ts)
    # until도 동일
    query += " ORDER BY timestamp ASC"
    ...
```

**⚠️ 함정**: SQLite는 **naive datetime을 epoch으로 변환할 때 시스템 로컬 타임존 사용**. **명시적으로 UTC 변환**하거나 어플리케이션 레벨에서 tz-aware datetime을 유지해야 함. kakao-summary는 `int(m.timestamp.replace(tzinfo=timezone.utc).timestamp())`로 tz-naive 입력도 안전하게 UTC epoch으로 변환.

### 2단계: 부트스트랩 파일 3종 (`.gitignore`, `pyproject.toml`, `pytest.ini`)

**`.gitignore`**: Python 표준 (캐시, venv, .egg-info, .pytest_cache, .mypy_cache, .ruff_cache, .idea, .vscode, .DS_Store)

**`pyproject.toml`**: setuptools 백엔드. **⚠️ 함정: `authors`에 `email` 넣으면 PEP 621 위반으로 `pip install -e .` 깨짐**. 이메일은 `name`만 또는 `idn-email` 형식(예: `[email protected]`은 OK, `[email protected]` 같은 일반 형식도 OK). 안전하게 가려면:
```toml
authors = [{ name = "sigco3111" }]
```
이메일은 GitHub 프로필에서 가져오므로 README/CONTRIBUTING에만 적기.

**`pytest.ini`**: `testpaths = tests` + `addopts = "-v --tb=short"`

### 3단계: 도메인 모델 분리 (순환 import 방지)

**⚠️ 함정: `core.py` ↔ `checks/` (또는 `parsers/`, `backends/`) 간 순환 import**.

해결 정석: `models.py` (또는 `types.py`)에 **모든 모듈이 의존하는 핵심 타입**을 모아두고, `core`와 `checks` 모두 `models`만 직접 import. `core`가 `default_checks()` 같은 함수를 호출해야 할 때는 **함수 내부 lazy import**.

```python
# models.py — 순환 import 방지의 핵심
@dataclass(frozen=True)
class Diagnosis: ...
class Severity(str, Enum): ...

# core.py
from models import Diagnosis  # 직접 의존 OK
def _default_registry():  # lazy import
    from checks import default_checks
    return default_checks()
```

`core` ↔ `checks` ↔ `plugins` 같은 다방향 의존이 예상될 때 이 패턴을 **처음부터 적용** (나중에 분리하려면 모듈 다 뒤져야 함).

### 4단계: 소스 스텁 (`src/<pkg>/`)

표준 4계층:
```
src/<pkg>/
├── __init__.py        ← 공개 API re-export
├── __main__.py        ← `python -m <pkg>` 진입점
├── cli.py             ← argparse 기반 커맨드
├── core.py            ← 메인 로직 + I/O
├── models.py          ← 도메인 타입
├── exceptions.py      ← 예외 계층 (BaseError → 구체 에러)
└── <sub>/             ← 플러그인 영역 (체크, 파서, 백엔드 등)
    ├── __init__.py    ← BaseInterface + Registry + default_set()
    └── <impl1>.py     ← 스텁(0.1.0) 또는 활성(0.2.0+)
```

`src/` 레이아웃 권장 (테스트가 import 경로 = 사용자가 쓸 경로).

### 5단계: 예외 계층 (처음부터 만들기)

```python
class <Pkg>Error(Exception): ...
class ParseError(<Pkg>Error): ...
class UnreadableFileError(<Pkg>Error): ...
class CheckConfigError(<Pkg>Error): ...
```

모든 라이브러리 예외는 `<Pkg>Error` 서브클래스로 → 사용자가 `except <Pkg>Error` 한 줄로 잡을 수 있음.

### 6단계: CLI (`cli.py`)

표준 옵션 5종 + 부속 명령 1종:
- `-o/--output` (파일/stdout)
- `--format` (text/json/github — GitHub Actions 워크플로용)
- `--min-severity` (info/warning/error)
- `--fail-on` (위와 동일 + `never`)
- `--checks` / `--list` (플러그인 선택)
- `--version`

**⚠️ 함정: `argparse` 위치 인자(예: `path`)를 `nargs="?"` 로 만들지 않으면 `--list-checks` 같은 부속 명령을 쓸 수 없음**. 부속 명령이 있을 거 같으면 처음부터:
```python
parser.add_argument("path", type=Path, nargs="?", default=None)
# main()에서 path is None 체크
```

**GitHub Actions 워크플로 출력 포맷**: `::warning file=F,line=L::msg%0A` — `f"{msg.replace(chr(10), '%0A')}"` 잊지 말 것.

### 7단계: pytest 스모크 테스트 (6~16개)

**Fixture 우선**: `tmp_path`에 마크다운/HWP/CSV 등 픽스처 inline 작성. 외부 파일 의존 최소화.

**카테고리 4종 균형**:
1. 도메인 모델 (불변성, enum 순서)
2. 코어 함수 (성공 + 실패 케이스)
3. CLI (text/json/github 출력, 부속 명령)
4. 예외 (UnreadableFileError, ParseError)

**데모 출력 확인**: `tests/` 외에도 실제 CLI로 한 번 돌려보고 exit code 확인:
```bash
md-doctor /tmp/sample.md  # exit 0 또는 1
md-doctor /no/path        # exit 2 (사용자 오류는 2, 발견 이슈는 1)
```

### 8단계: README/CHANGELOG/CONTRIBUTING

**README.md (다층 옵션 구조 — 사용자 선호 2026-06-12, 06-16 재확인)**:

> ⚠️ **사용자님은 "1-옵션 단순형" README를 거부함**. "기본 시드: 알도리아" 같은 단일 예시보다 **여러 선택지를 제시하는 구조**를 선호. 같은 흐름으로 한 README 안에 "한 톤"보다 **한/영 병기 + 결정 사항 4가지 + 샘플 옵션 + 직접 작성 (고급)** 등 **단계적 깊이**를 원함. cron-doctor README가 본 패턴으로 작성돼 좋은 반응 받음 (2026-06-16).

**다층 README 구조** (각 README는 이 모든 섹션 포함):
1. `<1-2줄 한글 슬로건>` + 영문 부록 (`<a id="english"></a>` 앵커)
2. **"왜 이게 필요한가?"** — 기존 도구의 갭 4가지 (한 + 영 양쪽)
3. **설치** (zero-deps 강조 or extras 표시)
4. **빠른 시작** — CLI 4~6 예시 + Python API 1 블록
5. **검사/모듈 표** (0.1.0 활성 / 0.2.0+ 예정 분리)
6. **사용 시나리오 4~6개** — "이럴 때 쓰세요" 톤 (CI 통합, 로컬 검증, 회귀 테스트 등)
7. **다른 PC에서 작업** (Phase 0 변형 시) — 3분 셋업 + 작업 순서 제안
8. **로드맵** (v0.1.0 ✅ → v1.0.0, 4단계)
9. **디렉토리 구조** (트리 시각화)
10. **감사의 말** + 라이선스

**8단계 시작 전 — 브레인스토밍 단계 (선택이지만 권장)**:

사용자님 OSS 프로젝트 시작 시 **결정 포인트별 옵션 2~3개 + 추천**을 먼저 제시하고 선택을 받는다. 예시 (cron-doctor 2026-06-16):

| 결정 포인트 | 옵션 A | 옵션 B | 옵션 C | 추천 |
|---|---|---|---|---|
| 이름 | cronlint (lint 컨벤션) | cron-doctor (md-doctor 시리즈) | crontab-lint (직관적) | B (시리즈 일관성) |
| 검증 범위 | 문법만 | + 의미 | + 의존성 + 스키마 | 풀스택 |
| CLI | check만 | + fix --dry-run | + watch | B+D |
| 테스트 | 단위만 | + 골든 파일 | + 스냅샷 | 골든 파일 (실제 fixture) |
| README | 1-옵션 단순 | 다층 옵션 | — | **다층 (사용자 선호)** |

**⚠️ 이름 결정은 신중히 (2026-06-16 kakao-summary 사례)** — 옵션 3개 + 추천 제시할 때 "기능 명시 + 도메인 직관성"을 모두 만족하는 옵션을 추천. 시리즈 일관성보다 직관성을 우선 (사용자 "kmsg-doctor는 적합하지 않은것 같아" 후 rename 결정).

→ "그대로 진행해" 같은 답을 받으면 그 즉시 실행. 이 단계는 **사용자가 "방향 정해지면" / "그냥 해줘"** 라고 하면 생략 가능 (단, 이름은 생략 비권장).

**CHANGELOG.md**: [Keep a Changelog](https://keepachangelog.com) 형식. 0.1.0 섹션에 Added/Notes만 있어도 충분.

**CONTRIBUTING.md**: "새 검사 모듈 추가" 튜토리얼 (BaseCheck 상속 4단계) — 다른 사람도 PR 보내기 쉽게.

### 9단계: GitHub Actions + action.yml

**`.github/workflows/ci.yml`**: 매트릭스 `python-version: ["3.9", "3.10", "3.11", "3.12"]` + 단계:
1. `actions/checkout@v4`
2. `actions/setup-python@v5` (cache: pip, cache-dependency-path: pyproject.toml)
3. `pip install -e ".[dev]"`
4. `ruff check src tests`
5. `mypy src || true` (0.1.0은 점진적 타이핑)
6. `pytest -v --tb=short`
7. `md-doctor --version` (스모크 CLI)

**`action.yml`**: composite action. 다른 사람이 `uses: sigco3111/<name>@v1` 으로 쓸 수 있게. inputs 4~5개, `runs.using: composite`, Python setup + pip install + 실행.

### 10단계: 커밋/푸시/태그/About 한글화

```bash
git add -A
git commit -m "feat: initial project skeleton (v0.1.0)

- <공개 API 요약>
- <CLI 요약>
- <예외 계층>
- <활성 모듈>
- <스텁 모듈>
- <테스트 N개 통과>
- <CI/Action>"
git push -u origin main

git tag -a v0.1.0 -m "v0.1.0 - ..."
git push origin v0.1.0

# GitHub About 한글화 (저장소 description)
gh repo edit sigco3111/<name> --description "<한글 한 줄>"
```

## ⚠️ 검증된 함정 (Pitfalls)

1. **`authors` 이메일** — PEP 621 위반. `name`만 쓰기.
2. **순환 import** — `models.py` 분리 + lazy import. **처음부터** 적용.
3. **argparse 위치 인자** — 부속 명령과 동시 사용하려면 `nargs="?"`.
4. **GitHub Actions 워크플로 출력** — `\n` → `%0A` 치환.
5. **테스트 conftest 충돌** — `pyproject.toml`에 `[tool.pytest.ini_options]` + 별도 `pytest.ini` 둘 다 있으면 "ignoring pytest config in pyproject.toml!" 경고. **하나만** 사용 (보통 `pyproject.toml` 안에).
6. **PEP 621 호환 setuptools** — setuptools ≥ 68 필요. 0.1.0에서는 `requires = ["setuptools>=68", "wheel"]` 명시.
7. **stdlib only 첫 릴리즈** — `dependencies = []` 로 시작. 0.2.0+에서 옵션 의존성 추가. 이게 "zero-deps" 마케팅 포인트.
8. **`mkdir -p` + `touch` 한 줄** — `mkdir -p a b/c` 직후 `touch b/c/x.py`가 같은 줄 안에 있으면 shell이 순차 실행하지만, **touch할 파일의 부모 dir이 아직 실제로 안 만들어진 race condition**이 가끔 발생. (2026-06-16 cron-doctor 부트스트랩 중 발생: `touch: src/cron_doctor/parsers/__init__.py: No such file or directory`.) 안전하게 **mkdir를 한 번 더** 실행하거나 dir을 한 줄씩 만든다.
9. **gh repo create 옵션 순서** — `gh` 도움말에 보이는 옵션 순서가 CLI 파서 순서와 다를 수 있음. `--license`는 long form인데 일부 버전에서 다른 위치의 옵션으로 인식해 도움말만 출력되는 현상. **문제 생기면 `--license` 플래그를 빼고** `--source=... --remote=origin --push`만 사용하면 repo 생성은 정상 동작.
10. **venv의 system Python 버전** (kakao-summary 2026-06-16) — macOS 기본 `python3`는 3.8.8인데 `pyproject.toml`에 `requires-python = ">=3.9"`로 잡아두면 venv 생성 후 `pip install -e ".[dev]"`가 `ERROR: Package 'X' requires a different Python: 3.8.8 not in '>=3.9'`로 실패. **해결**: `which python3` 확인 후 3.9+ 경로 명시. 사용자 시스템에는 `/usr/bin/python3` (3.9.6) 있으니 `rm -rf venv && /usr/bin/python3 -m venv venv && source venv/bin/activate && pip install -e ".[dev]"`로 재생성.
11. **pyright/lsp 타입 좁히기 한계** (kakao-summary 2026-06-16) — `if X: return a, b`로 type guard를 해도 pyright가 **같은 이름 변수를 같은 함수 스코프에서 재선언**하면 "Declaration obscured" 에러. **해결**: `if X: a = ...` 안에서 변수 어노테이션을 다시 적지 않거나, 다른 이름으로 분리. 또는 `from __future__ import annotations` + `if TYPE_CHECKING` 패턴으로 우회. **lsp 에러는 warning 수준**일 뿐 실제 pytest는 통과 — 무시하고 진행 가능.
12. **subprocess 매개변수 정확히** (외부 도구 wrapping 시) — `text=True` (문자열 모드), `bufsize=1` (라인 버퍼), `subprocess.PIPE` × 3개 (stdin/stdout/stderr 모두), Python 실행 시 `-u` 플래그 (버퍼링 비활성화). 이 4개 중 하나라도 빠지면 JSON-RPC 응답이 안 옴 또는 flush 안 됨.
13. **`gh repo rename`에 owner prefix** (kakao-summary 2026-06-16) — `gh repo rename sigco3111/kakao-summary`는 `/` 때문에 거부됨. **`gh repo rename <new-name> --yes`** 형식만 허용. 도움말은 `gh repo rename [<new-name>]`이라고 하지만 실제로는 컨텍스트에 따라 동작이 다름.
14. **이름 변경 후 v0.1.0 태그 force-update** (kakao-summary 2026-06-16) — `git tag -a v0.1.0 -m "..."`을 다시 하면 "tag already exists" 에러. **로컬 + 원격 모두 삭제 후 재생성**:
    ```bash
    git tag -d v0.1.0 && git push origin :refs/tags/v0.1.0
    git tag -a v0.1.0 -m "..." && git push origin v0.1.0
    ```
    또는 새 태그 (v0.1.1) 발행. **같은 SHA에 같은 태그가 다른 의미**가 되는 건 git 모범 사례 위반이라 v0.1.1 추천.
15. **sed 일괄 변경 시 하이픈/언더스코어 동시 처리** (kakao-summary 2026-06-16) — `kmsg-doctor` (하이픈, CLI/문서) + `kmsg_doctor` (언더스코어, 모듈/import) 두 표기 모두 sed로 바꿔야 함. **2단계 sed**: (1) 하이픈 → 새 하이픈, (2) 언더스코어 → 새 언더스코어. 한 번에 `(kmsg-doctor|kmsg_doctor)` 정규식 매칭은 sed BRE 호환성 문제 있을 수 있어 단순 두 번 sed가 안전.
16. **한국어 prefix 매칭 시 조사 처리** (kakao-summary `prefilter.py` 2026-06-16) — 시스템 메시지 prefix로 `"님이 입장하셨습니다"` (공백 없음)을 쓰면 `"홍길동님이 입장하셨습니다"`처럼 **이름 + 조사 + 공백 없이** 붙는 실제 카톡 메시지에서 **매칭 실패**. 한글 텍스트는 공백 기준이 약해서 `text.startswith(prefix)`는 **조사/어미 변형에 매우脆弱**. **해결**: 조사/어미가 들어가지 않은 **고유 부분 substring** (예: `"입장하셨습니다"`, `"나갔습니다"`)을 패턴으로 쓰고 `if pattern in text:` (substring) 사용. **재사용 가능**: 한국어 텍스트 분류/필터링하는 모든 도구 (스팸 필터, 욕설 필터, 광고 메시지 필터) 에 동일 패턴 적용. **테스트 케이스도 반드시 조사 변형 포함** (`"홍길동님이"`, `"김철수님이"`, `"운영자님이"` 모두 매칭되는지).
17. **macOS 시스템 설정 deep link로 권한 페이지 열기** (kakao-summary Accessibility 권한 안내 2026-06-16) — `open "x-apple.systempreferences:com.apple.preference.security?Privacy_Accessibility"` 로 **개인정보 보호 및 보안 → 손쉬운 사용** 페인을 한 번에 열 수 있음. macOS 13+ Ventura에서 동작. **fallback**: `open "/System/Library/PreferencePanes/UniversalAccessPref.prefPane"`. kmsg-mcp가 "시스템 설정 열어줘" 안내할 때 이 한 줄로 사용자가 5번 클릭 절약. **재사용**: 손쉬운 사용, 전체 디스크 접근, 화면 기록, 카메라, 마이크 등 모든 macOS 권한 안내에 동일 패턴.
20. **argparse subparser + positional `nargs="?"` 충돌** (kakao-summary 2026-06-16) — `parser.add_argument("chat", nargs="?")` + `add_subparsers`가 공존할 때, **chat 이름에 특수문자(`[`, `]`, `x` 등) 또는 공백이 있으면** argparse가 subparser 이름(`sync`, `summarize` 등)을 무시하고 chat을 COMMAND로 잘못 매칭 → `argument COMMAND: invalid choice` 에러. **진단**: `kakao-summary sync "[코드팩토리] x 클로드 코드" --target 100` → `kakao-summary: error: argument COMMAND: invalid choice: '[코드팩토리] x 클로드 코드'`. **해결**: positional `chat` 제거, 모든 서브 명령에 `--chat` 필수 옵션 + `required=True` 명시. 단축 사용 (`kakao-summary <chat>`) 도 포기. 사용자는 subparser에 5개 옵션 깔끔하게 들어가는 UX 선호. **재사용**: 외부 입력 (단톡방 이름, URL, 파일 경로) 에 사용자 자유 텍스트가 들어가는 모든 argparse CLI에 적용. **예방**: 처음부터 `nargs="?"` 회피, 모든 인자 `--옵션`으로.
21. **argparse subcommand handler에서 `return N` vs `sys.exit(N)` (opencode-trading 2026-06-17)** — `_cmd_convert(args)` 같은 subcommand handler에서 `if error: return 2` 형태로 exit code 반환하면 **테스트가 통과하다가 실패하는 함정**. `main()`이 handler의 int를 받아 `sys.exit(N)`로 종료해야 정상인데, `return N`은 `main()`의 return 값으로 흘러가 Python이 마지막 함수의 return value를 사용하지 않으므로 exit code가 0이 됨. **증상**: 정상 경로 테스트만 통과 (17/18), 에러 경로 테스트 1개만 실패 (`assert result.returncode == 2` → 실제로 0). **해결**: 두 가지 패턴 중 하나.
    - **패턴 A (권장)**: handler 내부에서 직접 `sys.exit(N)`. CLI 디스패처 코드 단순. 단점: handler 단위 테스트 어려워짐.
    - **패턴 B**: main()에서 handler의 return value를 받아 `sys.exit(handler(args))`. 단점: handler가 다른 함수 호출 안에서 호출되면 return value 무시됨. **이게 opencode-trading에서 발생한 정확한 버그**. handler 안에서 `if not workspace.exists(): print(...); return 2` → 정상 경로(0)만 테스트해서 통과, 에러 경로(2) 테스트에서 exit 0. **처음부터 패턴 A 또는 B 하나만 골라 통일**. 패턴 A가 디버깅 쉬움 (handler에 breakpoint 찍으면 즉시 exit). **재사용**: 모든 argparse subcommand handler CLI. **테스트할 때 정상 경로 + 에러 경로 둘 다 명시적으로**.
19. **brew uninstall 부작용** (kakao-summary decommission 2026-06-16) — `brew uninstall <formula>`는 **의존성을 자동 제거**하지 않는 게 일반적이지만, 어떤 formula는 transitive dependency를 정리하면서 같이 uninstall함. kakao-summary 사례에서 `brew uninstall channprj/tap/kmsg`가 **python@3.13 (74MB), ripgrep, fzf**를 같이 제거함. **영향**: 이 도구들을 다른 용도로 쓰고 있었다면 `pip install` / `rg` / `<C-r>` (fzf) 가 깨짐. **예방**: uninstall 전에 `brew deps <formula> --installed`로 의존성 미리 확인, 필요시 `brew install`로 재설치. **재사용**: macOS에서 어떤 formula든 uninstall할 때 동일 점검.
20. **MCP `initialize` 핸드셈 필수** (kakao-summary 2026-06-16) — kmsg-mcp처럼 **MCP (Model Context Protocol) 서버**를 stdio JSON-RPC으로 호출할 때, `tools/call`을 바로 보내면 `Server not initialized` 에러. **정확한 순서**: (1) `initialize` 요청 (`{"protocolVersion": "2024-11-05", "clientInfo": ...}`), (2) `notifications/initialized` (응답 없는 notification), (3) 그 다음 `tools/call`. MCP 프로토콜 2024-11-05 명세. **재사용**: kmsg-mcp뿐 아니라 다른 MCP 서버 (filesystem-mcp, github-mcp, postgres-mcp 등) wrapping 시 동일 순서 필수.
22. **`write_file` 멀티라인 escape (opencode-harness-bridge 2026-06-17)** — 비정상 데이터 (시크릿 같은 더미 문자열, ASCII art, 바이너리 비슷한 hex dump) 를 `write_file` 본문에 넣으면 멀티라인 escape가 깨져서 **다음 줄이 한 줄로 합쳐지는** 현상 발생. **증상**: `text = "sk-abc..."\n    assert looks_like_secret(text) is True` 같은 코드가 한 줄로 깨짐 (`text = "sk-abc..."    assert looks_like_secret(text) is True`). **해결**: 의심스런 데이터는 `write_file` 대신 `patch(mode='replace')` 사용. patch는 멀티라인 escape를 정확히 처리. **재사용**: 시크릿 키, ASCII art, base64 데이터, 한국어 조사 포함 prefix, 매우 긴 라인 (1KB+) 등 `write_file` 본문에 들어갈 때. **테스트 데이터는 항상 1KB 미만 + 멀티라인 가능 + escape 안전한 형태로** (일반 ASCII + 단순 알파벳, 예: `text = "***...hhiijj"`).
23. **시크릿 regex 테스트 데이터 길이 (opencode-harness-bridge 2026-06-17)** — `looks_like_secret()` 같은 정규식 기반 secret detector는 보통 `r"sk-[A-Za-z0-9]{20,}"` 같은 길이 최소값 패턴. 테스트 데이터를 `text = "sk-abc...wxyz"` 같이 짧게 쓰면 패턴 최소값 미만으로 **매칭 실패**. **증상**: regex는 정확하지만 테스트만 fail. **해결**: 테스트용 fake secret은 **실제 키 길이 ≥ 패턴 최소값** 으로 작성 (예: `text = "sk-abcdefghijklmnopqrstuvwxyz"` = 30자, `text = "ghp_abcdefghijklmnopqrstuvwxyz0123456789"` = 40자). **재사용**: 모든 정규식 기반 탐지/필터 (시크릿, 욕설, 스팸, PII, 전화번호) 테스트 작성 시. **원칙**: "regex 패턴이 요구하는 길이보다 테스트 데이터가 길거나 같아야 한다".

## Decommission 워크플로 (2026-06-16 kakao-summary 사례, 재사용 가능)

사용자가 **"프로젝트 제거하자"** 또는 **"decompose"**를 명시적으로 요청할 때 5단계 절차. **trash > rm** 원칙 (사용자 06-11 선호 — `~/.trash`로 복구 가능).

**1단계: GitHub repo 삭제**
```bash
gh repo delete sigco3111/<name> --yes
# 404 확인: gh repo view sigco3111/<name>  # "Could not resolve to a Repository"
```

**2단계: 로컬 워크스페이스 정리**
```bash
# 1순위: trash (복구 가능)
trash ~/.openclaw/workspace/<name>
trash ~/.<name>-mcp/  # 클론 디렉토리 (예: kmsg-mcp)
# 2순위: rm -rf (복구 불가, 신중히)
rm -rf ~/.openclaw/workspace/<name>  # trash 실패 시 fallback
```
- 디렉토리가 이미 **사전 삭제**된 경우도 정상 (trash가 "file doesn't exist" 에러 내며 종료, 무시)

**3단계: 외부 의존성 uninstall + 잔재 정리**
```bash
# brew uninstall
brew uninstall <tap>/<formula>
# ⚠️ 함정: transitive dependency가 같이 제거될 수 있음. 미리 `brew deps <formula> --installed` 확인.
# uninstall 후 잔재 청소
trash ~/Library/Logs/Homebrew/<formula>
trash ~/Library/Caches/Homebrew/<formula>--<version>

# 도구가 설치한 파일 (예: kmsg-mcp → ~/.local/share/)
trash ~/.local/share/<name>-mcp/

# 앱 캐시 (예: ~/.cache/<package-name>/)
trash ~/.cache/<package-name>/
```
**잔여 확인**:
```bash
find ~ -maxdepth 5 -iname "*<name>*" 2>/dev/null
# 출력 없으면 깨끗
```

**4단계: 셸 환경변수 정리**
```bash
# zshrc에서 export 라인 + 직전 주석 한 줄 제거
if grep -q "<NAME>" ~/.zshrc 2>/dev/null; then
  sed -i '' '/^# <package>: .*경로/d; /^export <NAME>=/d' ~/.zshrc
fi
grep -n "<NAME>\|<name>" ~/.zshrc  # 출력 없으면 깨끗
```

**5단계: 메모리 업데이트 (선택)**
- 새 사실 추가 시 **memory tool drift 가능** — 기존 MEMORY.md에 "round-trip 안 되는 변경"이 있을 때 거부됨. 백업은 자동 생성됨 (`.bak.<timestamp>`).
- 안전한 방법: **다음 세션에 한 번에 정리** (drift 해결할 시간이 있는 컨텍스트에서).
- 즉시 추가가 필요하면: read_file로 현재 상태 확인 → drift 백업 내용 머지 → 메모리 tool로 1개씩 추가. **3개 이상 추가는 권장하지 않음** (drift 위험).

**Decommission 후 검증 체크리스트**:
- [ ] `gh repo view sigco3111/<name>` → 404
- [ ] `which <bin-name>` → 없음
- [ ] `find ~ -iname "*<name>*"` → 출력 없음 (또는 의도적으로 보존한 파일만)
- [ ] `~/.zshrc`에 export 없음
- [ ] 새 세션에서 `<cli-name> --version` 시도 → command not found (정확히 제거됨)

**검증된 사례**: kakao-summary v0.1.0 (2026-06-16) — 한 세션 만에 v0.1.0 완성 + 실제 카톡 연동 성공(27개 메시지) + 사용자 요구(어제 데이터) 충족 불가 + decommission 결정. 5단계 절차 ~10분, 100% 깨끗하게 정리.

**⚠️ 사용자 06-11 선호 원칙과 정합**: "이게 정말 보여야 할 정보?" (Sun 함정) — **OSS도 마찬가지**. kakao-summary는 "어제 데이터"라는 사용자 요구를 충족 못 시키는 도구였고, 1세션 만에 제거 결정. **데이터 ≠ 표시 원칙을 OSS 자체에도 적용**: 사용자가 원하는 것을 못 주는 도구는 빠르게 decommission. **decommission도 작업의 일부**.

## ✅ 완료 체크리스트

세션 종료 전 확인:
- [ ] `pytest` → 6개+ 모두 통과 (정상 경로 + 에러 경로 둘 다)
- [ ] `<cli-name> --version` (또는 해당 CLI) → 정상 출력
- [ ] **CLI exit code 검증** — `command not found` 같은 사용자 오류는 exit 2, 발견 이슈는 1, 정상은 0. **반드시 에러 경로도 exit code 검증** (함정 21번 참고).
- [ ] `gh repo view sigco3111/<name>` → description 한글 + license MIT
- [ ] 저장소 페이지에 README/CHANGELOG/CONTRIBUTING/license 뱃지 렌더링
- [ ] v0.1.0 태그 푸시됨
- [ ] 다른 PC에서 `git clone && pip install -e ".[dev]" && pytest` 한 번에 동작
- [ ] **이름이 기능 + 도메인 직관성 모두 만족** (네이밍 후회 패턴 회피)

## 시그니처 OSS 시리즈 (7번째 추가: fireToken 2026-06-19)

사용자님이 정착한 "잘 진단해주는" 톤 + zero-deps + 한/영 병기 README 다층 옵션 + 30+ 테스트 시리즈:

| 순서 | 프로젝트 | 생성일 | 의존 도구 | 핵심 클래스 |
|---|---|---|---|---|
| 1 | `hwp2md` | 2026-06-08 | hwp5/olefile (백엔드 디스패처) | 변환 |
| 2 | `md-doctor` | 2026-06-09 | stdlib only | 진단 (마크다운) |
| 3 | `cron-doctor` | 2026-06-16 | stdlib only | 진단 (cron YAML) |
| 4 | `kakao-summary` | 2026-06-16 | kmsg-mcp (subprocess wrapping) | wrapping (decommissioned) |
| 5 | `opencode-trading` | 2026-06-17 | TradingCodex (zero-deps, stdlib tomllib) | adaptor (포맷 변환, 1:1) |
| 6 | `opencode-harness-bridge` | 2026-06-17 | Claude Code/Codex 하니스 (zero-deps, stdlib) | **메타 adaptor (N:M 변환 + 4-tier 안전 정책)** |
| 7 | `fireToken` | 2026-06-19 | NIM `openai/gpt-oss-120b` (무료, 40 rpm) | **Windows native PowerShell/배치 자동화 (리더보드 부스터)** |

→ 다음 새 프로젝트도 동일 패턴. **사용자 "그대로 진행해"는 이 시리즈가 검증된 워크플로라는 신호**.

**6번째의 차별점 (메타 adaptor)**:
- 일반 adaptor와 달리 **N source → M target** 마이그레이션 다룸
- **4-tier 안전 정책** (auto-apply / model-assisted / user-owned / opencode-incompatible) — `danyuchn/claude-codex-harness-sync` 3-tier 차용 + 1 tier 추가
- **9개 secret 패턴** regex (OpenAI/Anthropic/GitHub/AWS/Google/PEM) — tier-1 (auto-apply) 자산에 secret 발견 시 critical error
- **StrEnum** (Python 3.11+) + `json.dumps(plan)` 자동 직렬화
- **dry-run + --apply-safe** 양 옵션 필수
- → 다음 메타 adaptor 부트스트랩 시 `references/adaptor-oss-class.md` 의 "메타 어댑터 하위 클래스" 섹션 참고.

**7번째의 차별점 (Windows native + 비-Python 스택)**:
- **Python이 아님** — PowerShell 5.1+ + Batch (.bat). 사용자 OS가 Windows native여서 .ps1 + .bat 듀얼 스택. **cron → Task Scheduler** 등록 패턴 (cron 미사용 환경 대응).
- **외부 도구 wrapping 변형의 확장** — kakao-summary가 kmsg-mcp (stdio JSON-RPC)을 wrapping했다면, fireToken은 **NVIDIA NIM REST API**를 wrapping. **무료 tier + rpm 한도 (40 rpm)** 라는 새로운 제약이 추가됨. 동일 패턴으로 향후 "HuggingFace Inference API 무료 모델", "OpenRouter 무료 tier" 등 wrapping 시 활용.
- **Reasoning 모델 활용** — `gpt-oss-120b`의 `reasoning_effort=high` 모드로 thinking 토큰을 output에 누적시키는 패턴. 다른 reasoning 모델 (DeepSeek R1, Qwen QwQ, OpenAI o1/o3)에도 동일 적용 가능. **`reasoning_content` 응답 필드 안전 접근** (`getattr(choice.message, "reasoning_content", None)` 패턴).
- **컨텍스트 한도 자동 관리** — 120K 한도에서 80K/100K/120K 임계치별 slide/reset/hard 정책. **어떤 LLM 기반 자동화든 동일한 임계치 운영** 필요 (특히 컨텍스트 누적형 에이전트). 본 스킬의 `references/firetoken-context-management.md` 참조.
- **비공개 + 윤리적 제약 없음 명시** — README와 LICENSE에 "무의미하더라도 토큰 사용량을 어떻게든 늘려서 순위를 올리는 것" 정체성 + 면책 조항 명시. **KARDASHEV Scale for AI Devs 리더보드 점수 게임**이라는 명확한 목적성. README 첫 줄에 진짜 목적을 숨기지 않고 적는 톤.
- → 다음 Windows native / NIM 무료 모델 / 컨텍스트 누적형 자동화 부트스트랩 시 본 사례 + `references/firetoken-nim-pattern.md` 참조.

### Windows native 변형 (.ps1 + .bat 듀얼 스택)

**Python이 아닌 환경 (Windows native PowerShell/배치)**에서 OSS를 부트스트랩할 때 적용하는 변형. 2026-06-19 fireToken 사례 기반.

**트리거**:
- "Windows native", "PowerShell", ".bat", "Task Scheduler" 명시
- Python 설치가 부담스러운 환경
- 시스템 자동화/모니터링 류 도구 (LLM API 호출, HTTP 폴링, 파일 동기화 등)

**차이점 5가지** (vs Python Phase 1):

1. **소스 레이아웃** — `src/` 대신 `scripts/` (Windows 컨벤션)
2. **듀얼 진입점** — `.bat` (더블클릭/Task Scheduler) + `.ps1` (메인 로직). `<name>.bat`은 단순히 `powershell -ExecutionPolicy Bypass -File <name>.ps1 ...` 호출만.
3. **모듈 분리** — Python 패키지 대신 `.ps1` 파일 단위 (import는 `Import-Module` 또는 dot-sourcing). 컨텍스트 관리 / 입력 주입 / 메인 오케스트레이터 별도 파일.
4. **테스트** — pytest 없음. `powershell -ExecutionPolicy Bypass -File <module>.ps1 -Test` 패턴으로 자체 테스트 모드 내장.
5. **cron → Task Scheduler** — `schtasks /create /tn <name> /tr "<bat path>" /sc daily /st 09:00 /rl highest /f` 패턴. crontab 없는 환경 대응.

**8단계 레시피 (Windows native 변형)**:

1. **브레인스토밍** — 이름 / 타겟 OS / LLM API / 토큰 부풀리기 전략 등 결정 포인트 옵션 A/B/C + 추천 (본 skill의 8단계 시작 전 패턴 그대로)
2. **워크스페이스 디렉토리** + **파일 작성** (한 세션에 모두):
   - `README.md` (한/영 병기 + 다층 옵션 + 시스템 요구사항 + 옵션 + 안전장치 + 면책)
   - `AGENTS.md` (다른 PC 작업자용 — 환경 체크 + 함정 + Git 워크플로)
   - `LICENSE` (MIT + disclaimer)
   - `.gitignore` (Windows + PowerShell + secret 보호)
   - `scripts/<name>.bat` (더블클릭 진입점)
   - `scripts/<name>.ps1` (메인 오케스트레이터 + 파라미터 + 환경 체크)
   - `scripts/<sub>.ps1` (모듈별 분리)
   - `docs/STRATEGY.md` (핵심 알고리즘 상세)
   - `docs/CONTEXT_MANAGEMENT.md` (한도 운영)
   - `docs/ARCHITECTURE.md` (시스템 구조 + 데이터 흐름)
3. **git init + commit** (한 줄 메시지 + 변경 사항 요약)
4. **gh repo create + push** (private 가능) — `gh repo create sigco3111/<name> --private --source=. --description "한글 한 줄" --push`
5. **GitHub API로 검증** — `gh api repos/sigco3111/<name>/git/trees/main?recursive=1` 로 모든 파일 존재 확인
6. **raw URL 검증 (private repo 함정)** — `curl https://raw.githubusercontent.com/.../main/README.md` 는 **404** (raw는 public 전용). **인증 토큰 필요**: `-H "Authorization: token $TOKEN"`. 비공개 repo 검증 시 필수 패턴.
7. **GitHub tree + size 확인** — 모든 파일 blob SHA + size
8. **사용자 가이드 안내** — Windows에서의 즉시 사용법 + macOS에서의 모니터링법 + 다음 단계

**fireToken 검증 사례 (2026-06-19)**:
- 12개 파일 (md 6 + .ps1 3 + .bat 2 + .gitignore + LICENSE), ~57KB
- `gh repo create sigco3111/fireToken --private --source=. --description "..." --push` 한 줄로 repo 생성 + 푸시 동시
- push 직후 `gh api ...git/trees/main?recursive=1`로 12개 파일 모두 존재 확인
- raw URL은 비공개라 404 → 인증 토큰으로 재시도 → HTTP 200 + size 일치

**⚠️ 함정 2가지 (Windows native 신규)**:
1. **`raw.githubusercontent.com` 비공개 repo 404 함정** — 비공개 repo는 raw URL이 인증 없이 404. 검증 시 `gh api` 트리 + 인증 토큰 + `Authorization: token $TOKEN` 헤더 필수.
2. **`--license MIT` 옵션 일부 gh 버전 버그** — 기존 함정 9번 (cron-doctor 06-16) 그대로. LICENSE는 파일로 직접 push.

### "묵묵히 + 최종 보고" 워크플로 선호 (2026-06-19 fireToken 사례, 강한 신호)

**사용자가 "B" 옵션을 명시적으로 선택** — "중간 보고 없이 묵묵히 작업 후 최종 검증 보고". 4번째 확인된 선호 신호.

**적용 기준**:
- 부트스트랩 5단계 이상 (file 5+ / script 3+ / 문서 3+)
- 사용자가 브레인스토밍에서 옵션을 사전 결정
- 검증 가능한 명확한 최종 산출물

**워크플로**:
1. todo 리스트 생성 (전체 단계 한 번에)
2. 작업 중간에는 **상태 변경 + 결과만 짧게 표시** (예: "📄 README.md 작성 중...")
3. 모든 작업 완료 후 **한 번에 최종 보고** (검증 결과 + 산출물 요약 + 사용법 안내)
4. 보고 포맷: ✅ 결과 요약 표 + 📦 산출물 트리 + 🚀 즉시 사용법 + 🔄 다음 단계

**반대로 "단계별 보고"가 필요한 경우**:
- 디버깅/트러블슈팅 (사용자가 중간 결정介入해야 할 때)
- 다중 PC 협업 (사용자가 다음 단계 지시해야 할 때)
- 위험한 작업 (rm, 외부 API POST 등 사용자 승인 필요할 때)

### NVIDIA NIM 무료 모델 wrapping 패턴 (2026-06-19 fireToken, 재사용 가능)

**NIM 무료 tier (40 rpm) + reasoning 모델 + 컨텍스트 자동 관리** = 비용 0으로 토큰 폭발 가능. **NIM REST API는 OpenAI 호환**이라 `openai` Python SDK 또는 `curl`로 호출 가능.

**핵심 파라미터**:
```bash
curl -X POST "https://integrate.api.nvidia.com/v1/chat/completions" \
  -H "Authorization: Bearer *** \
  -H "Content-Type: application/json" \
  -d '{
    "model": "openai/gpt-oss-120b",
    "messages": [...],
    "max_tokens": 65536,
    "temperature": 1.0,
    "reasoning_effort": "high"   # ← reasoning 모델의 핵심
  }'
```

**응답 구조 (실측 검증, 2026-06-19)**:
```json
{
  "id": "resp_xyz",
  "model": "openai/gpt-oss-120b",
  "output": [{"type": "message", "content": [{"type": "output_text", "text": "..."}]}],
  "reasoning": {"effort": "high", "summary": "..."},
  "usage": {
    "input_tokens": 100023,
    "output_tokens": 23,
    "reasoning_tokens": 47,    // ← output에 합산되어 Tokscale 카운트
    "total_tokens": 100093
  }
}
```

**응답 모델**:
- `gpt-oss-120b`: **MoE 36 layers, 120K 컨텍스트, reasoning 지원** (HF config 검증). 무료 NIM에서 가장 큰 모델.
- 40 rpm = 분당 40 요청 = 시간당 2,400 요청 = 일 57,600 요청
- reasoning_effort=high + max_tokens=65536 → 1회 평균 30K~80K output tokens
- → **이론 최대 throughput: 일 ~3B output tokens** (현실 throttle 감안 ~1~2B)

**컨텍스트 자동 관리 (120K 한도, `references/firetoken-context-management.md` 참조)**:
- 80K → slide (70% keep)
- 100K → reset (system prompt만)
- 120K → hard reset (새 세션 ID)

**PowerShell 패턴 (Invoke-RestMethod)**:
```powershell
$body = @{
    model = "openai/gpt-oss-120b"
    messages = $messages
    max_tokens = 65536
    reasoning = @{ effort = "high" }
    stream = $false
} | ConvertTo-Json -Depth 20

$headers = @{
    "Authorization" = "Bearer $ApiKey"
    "Content-Type" = "application/json"
}

$response = Invoke-RestMethod `
    -Uri "https://integrate.api.nvidia.com/v1/chat/completions" `
    -Method Post `
    -Headers $headers `
    -Body $body `
    -TimeoutSec 120
```

**⚠️ 함정**:
1. **`reasoning_effort` 응답에서 `reasoning_content` 필드 없을 수 있음** — `getattr(choice.message, "reasoning_content", None)` 안전 접근 필수
2. **NIM 40 rpm은 key당** — 여러 key 발급해도 IP/계정 단위로 throttle 가능
3. **컨텍스트 120K 정확히 120,000** — 100K 이상이면 슬라이딩/초기화 필수
4. **Bearer 토큰 마스킹** — `$apiKey.Substring(0, 7) + "***" + $apiKey.Substring($apiKey.Length - 4)` 패턴으로 로그 노출 방지

**재사용 가능한 변형**:
- **HuggingFace Inference API 무료 모델** — `https://api-inference.huggingface.co/models/<model>`, 별도 토큰
- **OpenRouter 무료 tier** — `https://openrouter.ai/api/v1/chat/completions`, 모델 prefix 다름
- **GitHub Models** — `https://models.inference.ai.azure.com`, GitHub PAT 인증
- **Google AI Studio 무료 tier** — Gemini Flash 등, rpm 다름

## 📁 첨부 파일

이 스킬에는 다음 지원 파일이 함께 들어 있음:
- `references/case-studies.md` — hwp2md, md-doctor, cron-doctor, kakao-summary **decommission** 5개 + opencode-trading 1개 = 6개 실전 사례 + Phase 0/1/1.5/2 (decommission) 시퀀스 + 의사결정 트리 + 6개 메타 비교표
- `references/external-tool-wrapping.md` — **PTY 할당 필수, MCP initialize 핸드셰이크, kmsg-mcp 우회, argparse subparser + nargs='?' 충돌** 등 macOS GUI 도구 subprocess wrapping의 비-자명한 함정 4가지 (2026-06-16 kakao-summary 실전 추출). macOS GUI 자동화 도구 (kmsg, Karabiner, skhd, hammerspoon) wrapping하는 모든 Python OSS에 적용.
- `references/macos-unofficial-cli.md` — **kmsg / kmsg-mcp / MCP 서버 / AX 트리 접근** 도구 wrapping의 종합 가이드. PTY 패턴 코드 + MCP initialize 3단계 + 시스템 설정 deep link 권한 안내 + transitive deps uninstall 절차 + AX 트리 한계 (과거 시점 데이터 fetch 불가). kakao-summary decommission 후, 다음 macOS 비공식 도구 wrapping OSS 부트스트랩 시 이 문서부터 읽기.
- `references/adaptor-oss-class.md` — **adaptor OSS 클래스 (4번째, 2026-06-17 opencode-trading 검증)** — zero-deps 어댑터 전략 (adaptee import X, 결과물 파일만 읽음), 적용 체크리스트, oh-my-openagent 스쿼드와 직교 가능성, 미래 도메인 확장 prefix 통일성. 새 OSS가 "외부 도구 A → 외부 도구 B" 변환이면 이 문서부터.
- `templates/pyproject-minimal.toml` — 안전한 시작점 (이메일 함정 회피)
- `templates/pytest-minimal.ini` — 표준 pytest 설정
- `references/firetoken-context-management.md` — **Windows native + 컨텍스트 자동 관리 + "묵묵히 + 최종 보고" 워크플로** (2026-06-19 fireToken v0.1.0 검증). 컨텍스트 누적형 LLM 자동화 부트스트랩 시 본 문서부터.
