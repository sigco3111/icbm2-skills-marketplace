---
name: python-oss-bootstrap
description: "sigco3111 GitHub에 작은 Python OSS 라이브러리/CLI를 부트스트랩하는 9단계 + deploy 4단계 = 10단계 레시피. hwp2md, md-doctor, cron-doctor, kakao-summary, gh-traffic-monitor, Repolis, **xmrig-dashboard v0.1.0 → v0.2.0 → v0.2.1 (시각화 5종 + CSS 핫픽스 + 20개 pytest, hyphen 파일 importlib + Textual Static.app + helper 분리 + CSS border 셀렉터 누락 함정 41)** 검증. Phase 0 (다른 PC) / Phase 1 (이 PC) / 외부 도구 wrapping / 메타 adaptor / 이름 변경 변형. **코드 push != production deploy**: launcher 경로 갱신 + 의존성 버전 확인 + 이전 process 정리 + 사용자 검증 = 4단계. 시각화 helper 분리는 `references/visual-helpers-pattern.md`, deploy 절차는 `references/deploy-after-push.md` 참조."
trigger: "Python 라이브러리/CLI 신규 프로젝트 sigco3111 GitHub 부트스트랩 또는 v0.x → v0.y 업그레이드 시. '서브프로젝트 만들어줘', 'OSS 부트스트랩', 'pyproject 골격', 'TUI에 그래프 추가' 같은 요청. **deploy 단계 누락 방지** (xmrig-dashboard v0.2.0 사례 — 코드 push만 하고 production launcher 안 갱신하면 'UI가 안 바뀜' 리포트 옴). **GitHub Pages failed deploy 진단 시**에도 자동 발동 — references/diagnose-github-pages-failed-deploy.md + scripts/diagnose-github-pages-failed-deploy.sh 정적 helper."
last_updated: 2026-07-07
status: battle-tested
x-v020-additions: "xmrig-dashboard v0.2.0 — 5 helper, 20 tests, 3 pitfalls (38/39/40), visual-helpers-pattern.md"
x-v021-additions: "xmrig-dashboard v0.2.1 — pitfall 41 (CSS border selector 누락) + deploy 단계 (코드 push != production deploy). 9단계 → 10단계. deploy-after-push.md 신규."
x-v0707-additions: "Repolis GitHub Pages failed deploy 진단 (2026-07-07). 4단계 recipe: ①deployments API ②run_id + logs zip fetch ③0_deploy.txt의 'Deployment failed, try again later' + 5초 polling 패턴 ④사이트 200 cross-check → 인프라 일시 장애 결론 + 4옵션 보고. diagnose-github-pages-failed-deploy.{md,sh} 신규."
---

# Python OSS 부트스트랩 워크플로 (9단계 + deploy 4단계 = 10단계)

sigco3111 GitHub 조직에 **작고 마른 Python OSS**를 한 세션에 띄우는 레시피. 검증 사례: `hwp2md` v1.0.0, `md-doctor` v0.1.0, `cron-doctor` Phase 0 v0.1.0, `kakao-summary` Phase 1 v0.1.0, `opencode-trading` Phase 0 v0.1.0, `opencode-harness-bridge` Phase 1 v0.1.0, `gh-traffic-monitor` v0.1.0 → v0.1.1 (PEP 604), `Repolis` fork v0.1.0 → v0.2.0 → v0.2.1, `xmrig-dashboard` v0.1.0 → v0.2.0 → v0.2.1 (이게 핵심 사례).

## ⚠️ v0.2.1 핵심 교훈: 9단계 + deploy 4단계 = 10단계

**9단계 끝에서 commit + push 했다고 끝이 아님**. production launcher(`~/bin/run-*`, systemd unit, LaunchAgent 등)로 실행하는 환경이면 **deploy 4단계**가 별도:

1. **launcher 경로 갱신** — 옛 v0.x → 신 v0.y repo 경로
2. **의존성 버전 확인** — launcher의 Python이 v0.y 메이저 요구 충족하는지 (textual 6.x vs 8.x)
3. **이전 background process 정리** — `pgrep -fl <app>` + `kill -9`
4. **사용자 검증** — TTY에서 직접 띄워서 확인

xmrig-dashboard v0.2.0 사례: 코드 push 후 사용자가 "UI가 전혀 변하지 않음" → 3가지 deploy 함정 동시 노출 (옛 launcher, 구버전 textual, 살아있는 PID). v0.2.1에서 deploy까지 완료. 자세한 절차: `references/deploy-after-push.md` (반드시 같이 로드).

## ⚠️ v0.2.1 함정 41: 새 위젯 추가 시 CSS border 셀렉터 누락

v0.2.0에서 `CoreHeatmapPanel` 추가했는데 CSS의 panel border 룰(`Widget1, Widget2, ... { border: ... }`)과 개별 색상 매핑에서 빠뜨림. 결과: HEATMAP 헤더만 박스 없이 떠 있고 옆 panel과 어긋남.

**체크리스트** (새 위젯 추가 시 CSS 4곳 업데이트):
1. 공통 셀렉터 (모든 위젯 공유)
2. 개별 border 색상 매핑
3. Pulse 클래스 (애니메이션 있으면)
4. Reactive 클래스 (토글이 있으면)

**검증**: commit 직전 `git grep "Panel {"`로 모든 위젯이 셀렉터에 들어있는지 확인. v0.2.0 → v0.2.1 핫픽스 사이클 7 lines.

## 다음 OSS 부트스트랩 시 자동 적용

- 새 OSS v0.1.0: 사용자에게 launch 경로 먼저 확인 → 9단계 + deploy 4단계 한 세트
- 기존 OSS v0.x → v0.y: 10단계 풀세트 (코드 push만 하고 끝 ❌)
- TUI/CSS 위젯 추가: 함정 41 자동 체크 (`git grep "Panel {"`)
- 시각화/대시보드 OSS: helper 분리 패턴 (3~5 helper + 15~25 pytest) → `references/visual-helpers-pattern.md`

## 🌐 비-Python 변형 (2026-06-29 추가 — nbody-simulation 사례)

부트스트랩 9단계의 핵심 골격(폴더 → README 다층 → .gitignore → commit → gh repo create → push → ad-hoc 검증)은 **언어/스택과 무관하게 동일**하게 적용 가능. Python CLI/TUI가 아닌 **HTML5 Canvas 단일 파일 게임/시각화**도 같은 패턴.

| 단계 | Python OSS 변형 | HTML/Canvas 단일파일 변형 (nbody-simulation 사례) |
|---|---|---|
| 1. 폴더 | `mkdir ~/work/<name>` | 동일 |
| 2. README | 한/영 병기 다층, 결정 4-6가지 표, CONFIG 섹션 | 동일 (CONFIG 객체는 코드의 CONFIG 객체를 가리키는 설명) |
| 3. .gitignore | pyc/venv/.env | `.DS_Store`, `*.log`, `.vscode/` (스택에 따라) |
| 4. 라이선스 | MIT | 동일 |
| 5-7. 코드 | pyproject.toml + src/<name>/ | **`index.html` 1개에 모든 의존성 인라인** |
| 8. commit | root commit 1개 | 동일 |
| 9. push | `gh repo create --source . --push` | 동일 |
3. 검증은 `ad-hoc 검증 스크립트` (`/var/folders/.../T/hermes-verify-*.sh` — 31 체크 31 PASS 패턴)
4. **반드시 푸시 후 ad-hoc 검증으로 GitHub에 실제 박혔는지 확인 필요** (푸시 사실관계 검증 + raw fetch)

### 🔼 fractal-tree 변형 (2026-07-02 추가)

nbody-simulation과 거의 동일하지만 **2가지 추가**:
- **"원본 미션 프롬프트" 섹션** — 사용자가 알려준 미션 프롬프트 한국어 원문을 인용 블록으로 그대로 README에 포함
- **"요구사항 체크리스트"** — 미션 만족도를 자기 검증할 수 있는 체크박스 리스트 (수학적 재귀 / L-System / 황금색 / 꽃잎 / 단일 HTML 등)

| 항목 | nbody-simulation (06-29) | fractal-tree (07-02) |
|---|---|---|
| 결정사항 표 | 6종 | **5종** (트리+꽃잎 중심) |
| Built With 섹션 | opencode + MiniMax-M3 | 동일 |
| **원본 미션 프롬프트 섹션** | ❌ | ✅ (한국어 5문장 + Implementation Advice 영문) |
| **요구사항 체크리스트** | ❌ | ✅ (6항목) |
| README 크기 | 5764 bytes | **3428 bytes** (이전 2216 → +54.7%) |
| 검증 | 31/31 PASS | **24/24 PASS** (오탐 1회 → `check_any` 패턴 도입) |
| **검증 함정** | write_file /var/folders 거부 | 동일 + **한국어/영문 키워드 어순 오탐** (ad-hoc-verification 함정 6 신규) |

**자동 적용 결정**:
- "원본 미션 프롬프트" 섹션은 **미션/태스크 기반 부트스트랩에서 항상 추가** — "내가 무슨 미션으로 만들었는지" 흔적이 README에 남아있어야 미래에 추적 가능
- "요구사항 체크리스트"는 **미션의 acceptance criteria**를 그대로 옮겨놓은 것. 사용자 만족도 자기 검증 + GitHub Issue/PR 본문 복붙 가능
- ad-hoc 검증 시 `check_any` 패턴 (영문/한국어 동등어) 첫 turn부터 사용 → 어순 차이 오탐 0회

상세 함정은 `ad-hoc-verification` 스킬의 `references/tempfile-bypass.md`와 `ad-hoc-verification` SKILL.md의 "함정 6: 영문/한국어 키워드 어순 차이 오탐" 참조.

**핵심 차이**: Python 변형은 deploy 4단계(launcher/의존성/PID/사용자 검증)가 필수지만, 단일 HTML 변형은 `index.html`을 사용자가 직접 작성/푸시하므로 9단계까지로 충분. deploy는 Vercel/GitHub Pages는 사용자 요청 시 별도 처리.

**참조**: `references/nbody-html-scaffold-case.md` (2026-06-29 nbody-simulation 사례 — README 5764 bytes, GitHub raw Δ=1 byte).

**deploy 직전 4단계 검증 자동화**: `scripts/verify-single-html.sh <index.html>` — JS 신택스 + IndexedDB 스키마 + 필수 함수 + 이벤트 리스너 4축 체크. FAIL 시 deploy 금지.

## 🔥 단일 HTML 변형: 핫픽스 사이클 함정 (2026-08-03, clipboard-history 사례)

**v0.2.0 → v0.2.6 같은 날 6번 핫픽스 — 단일 HTML 프로젝트의 빈번한 함정**:

clipboard-history (단일 HTML, IndexedDB + Clipboard API + JSZip CDN) 한 세션에서:
- v0.2.0 → v0.2.1: 이미지 중복 캡처 + 자동 정리 (SHA-256 해시 도입)
- v0.2.1 → v0.2.2: **`let lastImageHash = ''` 중복 선언 → SyntaxError → UI 전체 멈춤**
- v0.2.2 → v0.2.3: paste 이벤트 + visibilitychange + webp/gif/bmp + 권한 UX
- v0.2.3 → v0.2.4: phantom denied 상태 (NotAllowedError 잘못 catch)
- v0.2.4 → v0.2.5: 1초 폴링 + 활동 트리거 + 디버그 로그
- v0.2.5 → v0.2.6: **IndexedDB hash 인덱스 누락 마이그레이션 → 기존 사용자 DB에 인덱스 없어서 findByHash 실패**

**6번 핫픽스 중 4번이 "변경 후 JS syntax + DB schema 검증 안 함"에서 옴**.

### ⚠️ 단일 HTML 핫픽스 사이클 회피 — 4단계 강제 체크리스트

**commit + push + deploy 직전 1분 검증** (Node 표준 라이브러리만 사용):

```bash
# 1) JS 신택스 — node 표준 라이브러리로 즉시 검증
node -e "
const fs = require('fs');
const html = fs.readFileSync('index.html', 'utf-8');
const m = html.match(/<script>([\s\S]*?)<\/script>/);
if (!m) { console.error('❌ no script tag'); process.exit(1); }
try { new Function(m[1]); console.log('✅ JS syntax OK'); }
catch (e) { console.error('❌', e.message); process.exit(1); }
"

# 2) DB schema 일관성 — store 이름 + version 일치 확인
grep -E "DB_NAME|VERSION = |STORE_(TEXT|IMG)" index.html | head

# 3) 필수 함수 존재 — onupgradeneeded + add/getAll/delete + 모든 이벤트 핸들러
grep -cE "function (openDB|openDb|add|delete|getAll|clear|put)" index.html

# 4) 이벤트 리스너 등록 — 탭/버튼/인풋 매칭
grep -E "addEventListener\('click'" index.html | wc -l
```

**deploy 직전 4단계 PASS 아니면 push 금지**.

### 📌 클립보드 히스토리에서 추출한 핵심 함정 (함정 42\~45)

| # | 함정 | 증상 | 수정 |
|---|------|------|------|
| **42** | **변수 중복 선언 (let 중복)** | SyntaxError → script 전체 실행 안 됨 → 모든 UI 멈춤 | `git grep "let <name>"` 동일 변수 2개 이상 발견 시 |
| **43** | **IndexedDB 마이그레이션 누락** | 기존 사용자 DB에 새 인덱스 부재 → `findByHash()` 쿼리 실패 → silent skip | `onupgradeneeded`에서 기존 store도 다시 정의 + `createIndex` 명시 |
| **44** | **NotAllowedError 잘못 catch** | 자동 폴링 silent 실패 → "⏸️ 대기 중" 표시만 → 사용자가 조치 못함 | 빨간 상태 + "🔓 권한 허용" 버튼 + 명시적 `requestPermission()` 핸들러 |
| **45** | **paste 이벤트 미지원** | Cmd+V 이미지가 폴링 주기(1\~2초)만큼 늦게 저장 | `document.addEventListener('paste')` + `clipboardData.files[0]` 처리 |

### 📌 README 버전 히스토리 표 형식 (함정 46)

단일 HTML 프로젝트는 **하루에 5\~6번 핫픽스**가 흔하므로 README 업데이트가 누락되기 쉬움. commit 메시지에는 `v0.2.3` 같은 버전을 항상 명시 + README "버전 히스토리" 섹션은 **표 형식**:

```markdown
## 📜 버전 히스토리

| 버전 | 변경 |
|------|------|
| **v0.2.6** | IndexedDB hash 인덱스 누락 마이그레이션 버그 수정 |
| **v0.2.5** | 자동 캡처 1초 폴링 + 활동 트리거 + 디버그 로그 |
| **v0.2.4** | phantom denied 상태 수정 |
| ... |
```

**commit 메시지 패턴**: `fix: v0.2.X — <한 줄 요약>` (버전 번호 명시 필수)

### 🔍 clipboard-history v0.2.6 마이그레이션 함정 상세 (함정 43)

**증상**: v0.2.0에서 만든 `images` 스토어가 있고 v0.2.1에서 hash 인덱스 추가하려고 `VERSION = 2`로 올림. 그러나 **이미 v0.2.0을 사용한 사용자**의 IndexedDB는 VERSION=1 상태 → VERSION=2로 자동 업그레이드 시 `onupgradeneeded` 발동 → `images` 스토어가 이미 있으니 `if (!d.objectStoreNames.contains(STORE_IMG))` 분기로 들어가지 않음 → **`createIndex('hash', ...)` 안 불림** → `findByHash()` 쿼리 실패 → silent skip → 중복 방지 동작 안 함.

**수정 패턴**:
```javascript
req.onupgradeneeded = (e) => {
  const d = req.result;
  if (!d.objectStoreNames.contains(STORE_TEXT)) {
    // 새 스토어 생성
  }
  if (!d.objectStoreNames.contains(STORE_IMG)) {
    // 새 스토어 생성 + 인덱스
  } else {
    // ⚠️ 기존 스토어에 인덱스 추가 (마이그레이션 핵심)
    const tx = e.target.transaction;
    const store = tx.objectStore(STORE_IMG);
    if (!store.indexNames.contains('hash')) {
      store.createIndex('hash', 'hash', { unique: false });
    }
  }
};
```

**결론**: IndexedDB 마이그레이션 코드는 **`createStore`만 신경 쓰지 말고 `createIndex`도 명시적으로 처리** — 새 사용자가든 기존 사용자든 동일 코드.

## 기존 변형 (그대로 유효)

- Phase 0 (다른 PC 변형) — docs-only + 다른 PC 핸드오프
- Phase 1 (이 PC 직접 풀 부트스트랩)
- 외부 도구 wrapping (MCP/CLI 통합)
- 메타 어댑터 (N:M 변환 + 4-tier 안전 정책)
- 이름 변경 워크플로 + 네이밍 후회 패턴

자세한 단계별 절차, 함수 정의, 검증 워크플로는 각 case-study reference 참조. 핵심 references:
- `references/visual-helpers-pattern.md` (시각화 helper 분리 + pytest)
- `references/deploy-after-push.md` (deploy 4단계, v0.x 푸시 후 production 반영)
- **`references/diagnose-github-pages-failed-deploy.md`** (★ 2026-07-07 Repolis — GitHub Pages `pages-build-deployment` deploy 실패 4단계 진단 recipe: ①deployments API ②run_id + 로그 zip fetch ③`0_deploy.txt`의 `##[error]Deployment failed, try again later` + 5초 polling timing 추출 ④사이트 200 cross-check → 인프라 일시 장애 결론 + 4옵션. `scripts/diagnose-github-pages-failed-deploy.sh` 정적 helper)
- `references/_v020_pitfalls_update.md` (함정 41 + deploy 단계, v0.2.0 → v0.2.1 학습)
- `references/tui-monitor-readonly-case-study.md` (xmrig-dashboard 풀 사례 + 함정 31~41)
- `references/case-studies.md` (전체 비교표)
- `references/adaptor-oss-class.md` (외부 도구 wrapping 변형)
