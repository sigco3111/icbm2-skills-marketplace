---
name: python-oss-bootstrap
description: "sigco3111 GitHub에 작은 Python OSS 라이브러리/CLI를 부트스트랩하는 9단계 + deploy 4단계 = 10단계 레시피. hwp2md, md-doctor, cron-doctor, kakao-summary, gh-traffic-monitor, Repolis, **xmrig-dashboard v0.1.0 → v0.2.0 → v0.2.1 (시각화 5종 + CSS 핫픽스 + 20개 pytest, hyphen 파일 importlib + Textual Static.app + helper 분리 + CSS border 셀렉터 누락 함정 41)** 검증. Phase 0 (다른 PC) / Phase 1 (이 PC) / 외부 도구 wrapping / 메타 adaptor / 이름 변경 변형. **코드 push != production deploy**: launcher 경로 갱신 + 의존성 버전 확인 + 이전 process 정리 + 사용자 검증 = 4단계. 시각화 helper 분리는 `references/visual-helpers-pattern.md`, deploy 절차는 `references/deploy-after-push.md` 참조."
trigger: "Python 라이브러리/CLI 신규 프로젝트 sigco3111 GitHub 부트스트랩 또는 v0.x → v0.y 업그레이드 시. '서브프로젝트 만들어줘', 'OSS 부트스트랩', 'pyproject 골격', 'TUI에 그래프 추가' 같은 요청. **deploy 단계 누락 방지** (xmrig-dashboard v0.2.0 사례 — 코드 push만 하고 production launcher 안 갱신하면 'UI가 안 바뀜' 리포트 옴)."
last_updated: 2026-06-24
status: battle-tested
x-v020-additions: "xmrig-dashboard v0.2.0 — 5 helper, 20 tests, 3 pitfalls (38/39/40), visual-helpers-pattern.md"
x-v021-additions: "xmrig-dashboard v0.2.1 — pitfall 41 (CSS border selector 누락) + deploy 단계 (코드 push != production deploy). 9단계 → 10단계. deploy-after-push.md 신규."
---

# Python OSS 부트스트랩 워크플로 (9단계 + deploy 4단계 = 10단계)

sigco3111 GitHub 조직에 **작고 마른 Python OSS**를 한 세션에 띄우는 레시피. 검증 사례: `hwp2md` v1.0.0, `md-doctor` v0.1.0, `cron-doctor` Phase 0 v0.1.0, `kakao-summary` Phase 1 v0.1.0, `opencode-trading` Phase 0 v0.1.0, `opencode-harness-bridge` Phase 1 v0.1.0, `gh-traffic-monitor` v0.1.0 → v0.1.1 (PEP 604), `Repolis` fork v0.1.0 → v0.2.0 → v0.2.1, `xmrig-dashboard` v0.1.0 → v0.2.0 → v0.2.1 (이게 핵심 사례).

## ⚠️ v0.2.1 핵심 교훈: 9단계 + deploy 4단계 = 10단계

**9단계 끝에서 commit + push 했다고 끝이 아님**. production launcher(`~/bin/run-*`, systemd unit, LaunchAgent 등)로 실행하는 환경이면 **deploy 4단계**가 별도:

1. **launcher 경로 갱신** — 옛 v0.x → 신 v0.y repo 경로
2. **의존성 버전 확인** — launcher의 Python이 v0.y 메이저 요구 충족하는지 (textual 6.x vs 8.x)
3. **이전 background process 정리** — `pgrep -fl <app>` + `kill -9`
4. **사용자 검증** — TTY에서 직접 띄워서 확인

xmrig-dashboard v0.2.0 사례: 코드 push 후 사용자가 "UI가 전혀 변하지 않음" → 3가지 deploy 함정 동시 노출 (옛 launcher, 구버전 textual, 살아있는 PID). v0.2.1에서 deploy까지 완료. 자세한 절차: `references/deploy-after-push.md` (반드시 같이 로드).

## ⚠️ v0.2.1 함정 41: 새 위젯 추가 시 CSS border 셀렉터 누락

v0.2.0에서 `CoreHeatmapPanel` 추가했는데 CSS의 panel border 룰(`Widget1, Widget2, ... { border: ... }`)과 개별 색상 매핑에서 빠뜨림. 결과: HEATMAP 헤더만 박스 없이 떠 있고 옆 panel과 어긋남.

**체크리스트** (새 위젯 추가 시 CSS 4곳 업데이트):
1. 공통 셀렉터 (모든 위젯 공유)
2. 개별 border 색상 매핑
3. Pulse 클래스 (애니메이션 있으면)
4. Reactive 클래스 (토글이 있으면)

**검증**: commit 직전 `git grep "Panel {"`로 모든 위젯이 셀렉터에 들어있는지 확인. v0.2.0 → v0.2.1 핫픽스 사이클 7 lines.

## 다음 OSS 부트스트랩 시 자동 적용

- 새 OSS v0.1.0: 사용자에게 launch 경로 먼저 확인 → 9단계 + deploy 4단계 한 세트
- 기존 OSS v0.x → v0.y: 10단계 풀세트 (코드 push만 하고 끝 ❌)
- TUI/CSS 위젯 추가: 함정 41 자동 체크 (`git grep "Panel {"`)
- 시각화/대시보드 OSS: helper 분리 패턴 (3~5 helper + 15~25 pytest) → `references/visual-helpers-pattern.md`

## 기존 변형 (그대로 유효)

- Phase 0 (다른 PC 변형) — docs-only + 다른 PC 핸드오프
- Phase 1 (이 PC 직접 풀 부트스트랩)
- 외부 도구 wrapping (MCP/CLI 통합)
- 메타 어댑터 (N:M 변환 + 4-tier 안전 정책)
- 이름 변경 워크플로 + 네이밍 후회 패턴

자세한 단계별 절차, 함수 정의, 검증 워크플로는 각 case-study reference 참조. 핵심 references:
- `references/visual-helpers-pattern.md` (시각화 helper 분리 + pytest)
- `references/deploy-after-push.md` (deploy 4단계, v0.x 푸시 후 production 반영)
- `references/_v020_pitfalls_update.md` (함정 41 + deploy 단계, v0.2.0 → v0.2.1 학습)
- `references/tui-monitor-readonly-case-study.md` (xmrig-dashboard 풀 사례 + 함정 31~41)
- `references/case-studies.md` (전체 비교표)
- `references/adaptor-oss-class.md` (외부 도구 wrapping 변형)
