#!/usr/bin/env python3
"""
sigco3111 README 자동 생성기 (per-repo, multi-repo batch).

각 프로젝트의 작업 사본 코드를 분석해서 README를 자동 생성합니다.
- 플랫폼별 (Mobile/NDS/Bada/iOS/Android) 섹션 구성
- 언어별 (J2ME/C++/Objective-C/Java) 기술 스택 표
- 참고 repo 매핑 (v2 strict)
- 시그너처 푸터 (README v2)

검증 사례 (2026-07-31): 41개 sigco3111 비공개 repo (`private-proj-*`) README 자동 생성
+ 푸시 + 체크리스트 갱신까지 일괄. 평균 4.9 KB / 푸시 성공 41/41.

Usage:
  이 파일을 직접 실행하지 말고, sigco_main.py 와 함께 사용:
  - sigco_readme_gen.py: 메타, 분석 함수, 매핑 함수 (import 가능 모듈)
  - sigco_main.py: 분석 → 생성 → 커밋 → 푸시 → 검증 → 체크리스트 갱신 통합 파이프라인

각 함수의 의도:
- REPOS: 41개 프로젝트 메타 (num, slug, 영문명, 한국어명, 플랫폼, 장르, 시대, inner_dir)
- analyze_assets(): res/ 폴더의 스프라이트/사운드/폰트 분류
- analyze_source(): .java/.c/.cpp/.m/.h 등 소스 라인 수, import, 클래스 추출
- analyze_meta(): JAD/AndroidManifest/Info.plist 메타 추출
- find_refs(): 41개 프로젝트 → sigco3111 public/private repo 매핑 (strict v2)
- render_tree(): emoji 풀 디렉토리 트리 출력
- PLATFORM_NOTES / GENRE_EMOJI / PLATFORM_BADGES: README 배지/이모지 룩업
"""
import os, json, re, sys
from pathlib import Path

WORK = Path("/Users/mac/work/github-private")
GH_USER = "sigco3111"
BUILD_DATE = "2026-07-31"

# 캐시 (sigco_main.py 와 공유)
public = json.load(open("/tmp/sigco_public.json"))
private = json.load(open("/tmp/sigco_private.json"))
all_repos = public + private

# === 헬퍼: 안전한 문자열 출력 ===
def esc(s): return str(s).replace('`', '\\`').replace('|', '\\|')

# === 헬퍼: 트리 출력 ===
def render_tree(p: Path, slug: str, max_lines=80):
    """디렉토리 트리 (emoji 포함) — README '## 📂 디렉토리 구조' 섹션용"""
    lines = []
    for root, dirs, fs in os.walk(p):
        if '.git' in root or '.large_files_excluded' in root:
            continue
        dirs[:] = sorted([d for d in dirs if d not in ('.git', '.large_files_excluded')])
        depth = root.replace(str(p), '').count(os.sep)
        if depth > 3:
            continue
        rel = os.path.basename(root) if root != str(p) else slug
        indent = "│   " * depth
        if depth == 0:
            lines.append(f"```")
            lines.append(f"{slug}/")
        elif rel:
            lines.append(f"{indent}├── 📁 {rel}/")
        for f in sorted(fs)[:30]:
            ind = "│   " * (depth + 1)
            ext = Path(f).suffix.lower()
            emoji = {
                '.java': '☕', '.c': '🔧', '.cpp': '🔧', '.h': '📋',
                '.m': '🍎', '.mm': '🍎', '.swift': '🍎',
                '.png': '🖼️', '.jpg': '🖼️', '.bmp': '🖼️',
                '.mmf': '🎵', '.wav': '🎵', '.mp3': '🎵', '.mid': '🎵',
                '.jad': '📄', '.jar': '📦', '.class': '⚙️',
                '.apk': '📦', '.app': '📦', '.xml': '📄', '.plist': '📄',
                '.psd': '🎨', '.ai': '🎨', '.bdt': '💾', '.db': '💾',
                '.dat': '💾', '.ncg': '🎨', '.ncl': '🎨', '.nce': '🎨',
                '.xib': '📐', '.sln': '🔧', '.vcproj': '🔧', '.mak': '🔧',
                '.Makefile': '🔧', '.md': '📝', '.txt': '📝',
            }.get(ext, '📄')
            lines.append(f"{ind}├── {emoji} {f}")
        if len(fs) > 30:
            lines.append(f"{ind}└── ... ({len(fs)-30} more)")
    lines.append(f"```")
    return "\n".join(lines[:max_lines])

# === 헬퍼: 스프라이트/사운드/소스 분석 ===
def analyze_assets(p: Path):
    """res/ 폴더 분석 (스프라이트/사운드/폰트) — 첫 번째 res 또는 Image_Work/Sound_Work"""
    res_dirs = [d for d in p.rglob('res') if d.is_dir() and '.git' not in str(d) and '.large_files_excluded' not in str(d)]
    res = None
    if res_dirs:
        res = max(res_dirs, key=lambda d: sum(f.stat().st_size for f in d.rglob('*') if f.is_file()))
    if not res:
        for cand in ['Image_Work', 'Sound_Work', 'Resource', 'Res', 'Image', 'Sound', 'BackUp']:
            c = list(p.rglob(cand))
            if c:
                res = c[0] if c[0].is_dir() else c[0].parent
                break
    info = {'sprites': [], 'sounds': [], 'fonts': [], 'other': []}
    if not res: return info
    for f in res.rglob('*'):
        if not f.is_file(): continue
        ext = f.suffix.lower()
        name = f.name
        if ext in ('.png', '.jpg', '.bmp', '.gif', '.pcx', '.psd'):
            if re.match(r'^\d+\.png$', name):
                info['fonts'].append(name)
            elif re.match(r'^(e|p|mb|enemy|player|ship|power|life|cursor|logo)', name, re.I):
                info['sprites'].append(name)
            else:
                info['other'].append(name)
        elif ext in ('.mmf', '.wav', '.mp3', '.mid', '.swav', '.swls'):
            info['sounds'].append(name)
    return info

def analyze_source(p: Path):
    """소스 코드 분석 (.java, .c, .cpp, .m 등)"""
    source_exts = {'.java': 'java', '.c': 'c', '.cpp': 'cpp', '.h': 'h',
                   '.m': 'objc', '.mm': 'objcpp', '.swift': 'swift',
                   '.kt': 'kotlin', '.cs': 'csharp'}
    files = []
    for ext, lang in source_exts.items():
        for f in p.rglob(f'*{ext}'):
            if '.git' in str(f) or '.large_files_excluded' in str(f):
                continue
            try:
                with open(f, 'r', encoding='utf-8', errors='replace') as fp:
                    content = fp.read()
                files.append({
                    'path': str(f.relative_to(p)),
                    'lang': lang,
                    'lines': content.count('\n') + 1,
                    'bytes': f.stat().st_size,
                    'imports': re.findall(r'^import\s+([\w.]+)', content, re.MULTILINE)[:20],
                    'classes': re.findall(r'(?:class|interface)\s+(\w+)', content)[:10],
                })
            except: pass
    return files

def analyze_meta(p: Path):
    """JAD, AndroidManifest, Info.plist 메타 분석"""
    info = {}
    for f in p.rglob('*.jad'):
        try:
            text = f.read_text(encoding='utf-8', errors='replace')
            for line in text.splitlines():
                if '=' in line:
                    k, v = line.split('=', 1)
                    info[k.strip()] = v.strip()
        except: pass
        break
    for f in p.rglob('AndroidManifest.xml'):
        try:
            text = f.read_text(encoding='utf-8', errors='replace')
            info['package'] = re.search(r'package="([^"]+)"', text)
            if info['package']: info['package'] = info['package'].group(1)
            info['version'] = re.search(r'versionName="([^"]+)"', text)
            if info['version']: info['version'] = info['version'].group(1)
        except: pass
        break
    for f in p.rglob('Info.plist'):
        if '.git' in str(f) or '.large_files_excluded' in str(f): continue
        try:
            text = f.read_text(encoding='utf-8', errors='replace')
            info['bundle'] = re.search(r'CFBundleIdentifier[^>]*>([^<]+)', text)
            if info['bundle']: info['bundle'] = info['bundle'].group(1)
        except: pass
        break
    return info

# === 참고 repo 매핑 (v2 strict) ===
CATEGORY_ALIASES = {
    "matgo":          ["matgo"],
    "gostop":         ["gostop", "dsgostop"],
    "magicstore":     ["magicstore", "magicshop", "nds-magicstore"],
    "tycoon":         ["tycoon"],
    "rpg-gunblade":   ["rpg-gunblade"],
    "nds-sound":      ["nds-dsgostop-sound", "gostop-sound", "magicstore-sound"],
    "nds-artwork":    ["dsgostop-artwork", "dsgostop-manga", "dsgostop-planning", "magicstore-planning", "magicstore-screenshots"],
    "nds-sdk":        ["nds-sdk", "nds-education"],
    "billiards":      ["billiards", "billiard"],
    "beauty":         ["tycoon-beauty"],
    "poker":          ["poker"],
    "gunblade":       ["gunblade"],
}

def word_match(keyword, name):
    """단어 경계 매칭 — 'a'가 'art'에 잘못 매칭되지 않음"""
    if len(keyword) < 4: return False
    return bool(re.search(rf'(^|[-_]){re.escape(keyword)}(-|_|$)', name))

ALIASES = {
    1: ["1942", "1942_java", "1942-java"],
    2: ["alpha-version"],
    3: ["ar-billiards", "arbilliards"],
    4: ["armor-bleach", "armored-bleach"],
    5: ["atom"],
    6: ["beautyshop", "beauty-shop", "beautyshop-tycoon"],
    7: ["bmp-compress", "bmpcompress"],
    8: ["curling"],
    9: ["dino-catch", "dinocatch"],
    10: ["drivers-license", "driver-license"],
    11: ["ds-gostop", "dsgostop"],
    12: ["fire-alert", "firealert"],
    13: ["firefire", "fire-fire"],
    14: ["flame-requiem", "flamerequiem"],
    15: ["gameneo", "game-neo"],
    16: ["heavy-arms", "heavyarms"],
    17: ["hospital-pharmacy", "hospital"],
    18: ["hwarang", "hwarang-taekwon", "taekwon"],
    19: ["k-fighter", "kfighter"],
    20: ["limario"],
    21: ["magicshop", "magic-shop", "magicstore", "magic-store"],
    22: ["magicshop-ds", "magicstore-ds", "magicds"],
    23: ["mashimaro"],
    24: ["metalgear", "metal-gear"],
    25: ["mister-ddong", "misterddong", "ddong"],
    26: ["neo-sdk", "neosdk"],
    27: ["neo-space", "neospace", "space-warrior"],
    28: ["newpoker", "new-poker"],
    29: ["poker-gnex", "pokergnex"],
    30: ["powercrystal", "power-crystal"],
    31: ["powerful-pro", "powerfulpro", "powerful-pro-baseball"],
    32: ["res-file", "resfile", "res-file-gen"],
    33: ["rose-war", "rosewar"],
    34: ["shin-matgo", "shinmatgo"],
    35: ["shio", "shio-adventure"],
    36: ["showdown"],
    37: ["ssagaji", "ssagaji-matgo"],
    38: ["subway-matgo", "subwaymatgo"],
    39: ["tget", "t-get"],
    40: ["tadpole", "tadpole-frog"],
    41: ["today-fortune", "todayfortune"],
}

def find_refs(num, slug, ko, platform):
    """41개 프로젝트 → sigco3111 repo 매핑 (strict v2).
    매칭 규칙:
    1. 이름 직접 매칭 (word-boundary, 4자 이상)
    2. 카테고리 매칭 (장르/플랫폼 키워드)
    3. archive 자료 (사운드 + 게임문서)
    """
    matches = []
    seen = set()
    def add(name, why):
        if name in seen: return
        seen.add(name)
        matches.append((name, why))
    target_lower = slug.lower()
    # 1) 직접 alias
    for r in all_repos:
        n = r['name'].lower()
        if n == target_lower or n.startswith("private-proj-"): continue
        for a in ALIASES.get(num, []):
            if word_match(a, n):
                add(r['name'], 'name')
                break
    # 2) 카테고리
    cat_matchers = []
    if "맞고" in ko or "Matgo" in ko: cat_matchers.append("matgo")
    if "고스톱" in ko or "DS Go-Stop" in ko or "화투" in ko: cat_matchers.append("gostop")
    if "마법상점" in ko or "Magic" in ko: cat_matchers.append("magicstore")
    if "타이쿤" in ko or "Tycoon" in ko or "시뮬" in ko: cat_matchers.append("tycoon")
    if "RPG" in ko or "액션 RPG" in ko or "전략 RPG" in ko or "RPG 외주" in ko: cat_matchers.append("rpg-gunblade")
    if "당구" in ko or "Billiards" in ko: cat_matchers.append("billiards")
    if "뷰티" in ko or "Beauty" in ko: cat_matchers.append("beauty")
    if "포커" in ko or "Poker" in ko: cat_matchers.append("poker")
    if "건블" in ko: cat_matchers.append("gunblade")
    if platform == "NDS":
        cat_matchers.extend(["nds-sound", "nds-artwork", "nds-sdk"])
    for cat in set(cat_matchers):
        for r in all_repos:
            n = r['name'].lower()
            if n == target_lower or n.startswith("private-proj-"): continue
            for kw in CATEGORY_ALIASES.get(cat, []):
                if word_match(kw, n):
                    add(r['name'], f'cat:{cat}')
                    break
    # 3) archive
    is_dev_tool = "Tool" in ko or "tool" in ko or "개발 도구" in ko
    if platform in ["Mobile", "NDS", "Bada", "Android"] and not is_dev_tool and "유틸리티" not in ko:
        add("private-archive-sound-assets", 'archive')
    if not is_dev_tool and platform in ["Mobile", "NDS", "Bada", "Android", "iOS"]:
        add("private-archive-game-docs", 'archive')
    return matches

# === 메타 ===
REPOS = [
    (1,  "private-proj-mobile-1942-java",         "1942 Java",        "1942_JAVA",                  "Mobile", "비행 슈팅 (Java)",       "2004-2006", "1942_JAVA"),
    (2,  "private-proj-nds-alpha-version",         "Alpha Version (NDS)",   "알파버전",                    "NDS",    "프로토타입",              "2006-2007", "알파버전"),
    (3,  "private-proj-bada-ar-billiards",         "AR Billiards (Bada)",   "AR당구",                      "Bada",   "AR 스포츠",              "2010-2012", "AR당구"),
    (4,  "private-proj-mobile-armor-bleach",       "Armored Bleach",        "아머드블리치",                  "Mobile", "메카 액션",              "2005-2006", "아머드블리치"),
    (5,  "private-proj-mobile-atom",               "ATOM",                  "아톰",                        "Mobile", "액션",                  "2005-2006", "아톰"),
    (6,  "private-proj-mobile-beautyshop-tycoon",  "Beauty Shop Tycoon",    "뷰티샵 타이쿤",                 "Mobile", "시뮬레이션",              "2005-2007", "뷰티샵 타이쿤"),
    (7,  "private-proj-mobile-bmp-compress-tool",  "BMP Compress Tool",     "BMP압축툴",                    "Mobile", "개발 도구",              "2003-2005", "BMP압축툴"),
    (8,  "private-proj-mobile-curling-gnex",        "Curling (GNEX)",        "컬링_GNEX",                   "Mobile", "스포츠",                "2007-2008", "컬링_GNEX"),
    (9,  "private-proj-mobile-dino-catch",         "Dino Catch Operation",  "공룡잡기 대작전",               "Mobile", "캐주얼 액션",            "2004-2006", "공룡잡기 대작전"),
    (10, "private-proj-bada-drivers-license",      "Driver License Mastery","운전면허 완전정복",             "Bada",   "교육/자격증",            "2011-2013", "운전면허 완전정복"),
    (11, "private-proj-nds-ds-gostop",              "DS Go-Stop (Hwatu)",    "DS 고스톱",                   "NDS",    "보드/카드",              "2006-2008", "DS 고스톱"),
    (12, "private-proj-mobile-fire-alert",         "Fire Alert!",           "앗!불이야",                    "Mobile", "캐주얼",                "2004-2005", "앗!불이야"),
    (13, "private-proj-mobile-firefire-gvm",       "FireFire (GVM)",        "FireFire_GVM",                "Mobile", "캐주얼 액션",            "2006-2007", "FireFire_GVM"),
    (14, "private-proj-mobile-flame-requiem-gvm",  "Flame Requiem (GVM)",   "화염의 진혼곡_GVM",             "Mobile", "액션 RPG",              "2006-2007", "화염의 진혼곡_GVM"),
    (15, "private-proj-mobile-gameneo-matgo",      "GameNeo Matgo",         "게임네오 맞고",                 "Mobile", "보드/카드",              "2007-2010", "게임네오 맞고"),
    (16, "private-proj-mobile-heavy-arms",         "Heavy Arms",            "헤비암즈",                     "Mobile", "메카 액션",              "2005-2007", "헤비암즈"),
    (17, "private-proj-bada-hospital-pharmacy",    "Hospital Pharmacy Finder","병원약국찾기",                "Bada",   "위치 기반 유틸리티",       "2011-2012", "병원약국찾기"),
    (18, "private-proj-mobile-hwarang-taekwon",    "Hwarang Taekwon",       "화랑태권",                     "Mobile", "격투 스포츠",            "2005-2007", "화랑태권"),
    (19, "private-proj-mobile-k-fighter-gvm",      "K Fighter (GVM)",       "K_Fighter_GVM",               "Mobile", "격투 액션",              "2006-2007", "K_Fighter_GVM"),
    (20, "private-proj-mobile-limario-matgo",      "Limario Matgo",         "리마리오 맞고",                 "Mobile", "보드/카드",              "2005-2007", "리마리오 맞고"),
    (21, "private-proj-mobile-magicshop-tycoon",   "Magic Shop Tycoon (Mobile)","마법상점 타이쿤",            "Mobile", "시뮬레이션",              "2004-2005", "마법상점 타이쿤"),
    (22, "private-proj-nds-magicshop-tycoon-ds",   "Magic Shop Tycoon DS",  "마법상점타이쿤DS",               "NDS",    "시뮬레이션",              "2006-2008", "마법상점타이쿤DS"),
    (23, "private-proj-mobile-mashimaro-java",     "Mashimaro (Java)",      "마시마로_Java",                 "Mobile", "플랫포머 (Java)",         "2004-2005", "마시마로_Java"),
    (24, "private-proj-mobile-metalgear-java",     "Metal Gear Java",       "메탈기어 자바",                 "Mobile", "액션 (Java)",            "2004-2005", "메탈기어 자바"),
    (25, "private-proj-mobile-mister-ddong",       "Mister Ddong",          "미스터똥",                     "Mobile", "캐주얼",                "2004-2006", "미스터똥"),
    (26, "private-proj-nds-neo-sdk",               "NEO SDK v0.0.6",        "NEO SDK 0.0.6",                "NDS",    "SDK/엔진",              "2006-2007", "neo_sdk_ver0.0.6"),
    (27, "private-proj-mobile-neo-space-warrior",  "Neo Space Warrior",     "네오 스페이스 워리어",           "Mobile", "SF 슈팅",                "2006-2008", "NeoSpaceWarrior"),
    (28, "private-proj-mobile-newpoker-gnex",      "New Poker (GNEX)",      "뉴 포커 (GNEX)",               "Mobile", "포커",                  "2007-2008", "newPocker_GNEX"),
    (29, "private-proj-mobile-poker-gnex",         "Poker (GNEX)",          "포커_GNEX",                    "Mobile", "포커",                  "2006-2008", "포커_GNEX"),
    (30, "private-proj-mobile-powercrystal-gnex",  "Power Crystal (GNEX)",  "파워 크리스탈 (GNEX)",           "Mobile", "액션 RPG",              "2007-2008", "파워크리스탈_GNEX"),
    (31, "private-proj-mobile-powerful-pro-baseball","Powerful Pro Baseball","파워풀 프로 야구",               "Mobile", "스포츠",                "2006-2008", "파워풀 프로 야구"),
    (32, "private-proj-mobile-res-file-gen",       "RES File Generator",    "RES 파일 생성 프로그램",          "Mobile", "개발 도구",              "2004-2006", "RES_FILE생성프로그램"),
    (33, "private-proj-android-rose-war",          "Rose War (Android)",    "장미의 전쟁",                   "Android","전략 RPG",              "2011-2013", "장미의 전쟁"),
    (34, "private-proj-mobile-shin-matgo",         "Shin Matgo",            "신맞고",                       "Mobile", "보드/카드",              "2007-2008", "신맞고"),
    (35, "private-proj-mobile-shio-nokia",         "Shio Adventure (Nokia)","시오의 모험 노키아 외주",        "Mobile", "RPG 외주",              "2006-2007", "시오의 모험"),
    (36, "private-proj-mobile-showdown-gvm",       "ShowDown (GVM)",        "쇼다운 (GVM)",                 "Mobile", "대전 격투",              "2006-2007", "ShowDown_GVM"),
    (37, "private-proj-mobile-ssagaji-matgo",      "Ssagaji Matgo",         "싸가지맞고",                   "Mobile", "보드/카드",              "2006-2007", "싸가지맞고"),
    (38, "private-proj-mobile-subway-matgo-2010",  "Subway Matgo 2010",     "지하철맞고 2010",               "Mobile", "보드/카드",              "2008-2010", "지하철맞고"),
    (39, "private-proj-ios-tget",                  "T-Get (iOS)",           "T-Get",                        "iOS",    "유틸리티",                "2010-2012", "T-Get"),
    (40, "private-proj-mobile-tadpole-frog-gvm",   "Tadpole & Frog (GVM)",  "올챙이와 개구리_GVM",             "Mobile", "캐주얼",                "2007-2008", "올챙이와 개구리_GVM"),
    (41, "private-proj-bada-today-fortune",        "Today Fortune (Bada)",  "적중 오늘의 운세",               "Bada",   "엔터테인먼트",            "2011-2012", "적중 오늘의 운세"),
]

# === 플랫폼별 특화 콘텐츠 ===
PLATFORM_BADGES = {
    "Mobile":  ("J2ME%20%2F%20BREW%20%2F%20GNEX%20%2F%20GVM", "J2ME/BREW/GNEX/GVM"),
    "NDS":     ("Nintendo%20DS%20%2F%20NitroSDK", "Nintendo DS / NitroSDK"),
    "Bada":    ("Samsung%20Bada%20%2F%20Native%20App", "Samsung Bada / Native App"),
    "Android": ("Android%20%2F%20Java%2BXML", "Android (Java)"),
    "iOS":     ("iOS%20%2F%20Objective--C", "iOS / Objective-C"),
}

GENRE_EMOJI = {
    "비행 슈팅 (Java)": "✈️", "비행 슈팅": "✈️",
    "프로토타입": "🧪", "액션": "⚔️", "액션 RPG": "⚔️", "액션 (Java)": "⚔️",
    "메카 액션": "🤖", "시뮬레이션": "🏪", "스포츠": "⚾", "캐주얼": "🎮",
    "캐주얼 액션": "🎮", "보드/카드": "🀄", "포커": "🃏", "SF 슈팅": "🚀",
    "플랫포머 (Java)": "🏃", "대전 격투": "🥋", "격투 액션": "🥋",
    "격투 스포츠": "🥋", "RPG 외주": "🗡️", "SDK/엔진": "🛠️",
    "개발 도구": "🔧", "AR 스포츠": "🎱", "교육/자격증": "📚",
    "위치 기반 유틸리티": "📍", "엔터테인먼트": "🔮", "전략 RPG": "♟️",
    "유틸리티": "🔧",
}

PLATFORM_NOTES = {
    "Mobile": "Mobile (피처폰 J2ME/BREW/GNEX/GVM, 2003-2010 시대)",
    "NDS":    "Nintendo DS (NitroSDK / ARM9+ARM7, 2005-2010 시대)",
    "Bada":   "Samsung bada (Native C++ App, 2010-2012 시대, Tizen 이전)",
    "Android":"Android (Java + XML 리소스, 2010+ 시대)",
    "iOS":    "iOS (Objective-C + UIKit, 2010+ 시대)",
}

if __name__ == "__main__":
    print(f"README 자동 생성기 (v2) — {len(REPOS)}개 프로젝트 메타 로드됨")
    print(f"  public repos: {len(public)}")
    print(f"  private repos: {len(private)}")
    print(f"  total: {len(all_repos)}")
