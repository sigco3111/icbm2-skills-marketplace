# README Enhancement Pipeline — sigco3111 41-repo Walkthrough

Date: 2026-07-31. Source conversation: 2026-07-31 README enhancement session.

## What was built

41 private GitHub repos (`private-proj-*`) under `sigco3111` were enhanced over three push rounds, then one round was rolled back. Final state: §13 (README rewrite) + §14 (image embedding) remain; §15 (auto web search) was rolled back per user request "링크가 모두 상관 없는 것들임. 일단 모두 롤백해".

## File layout

- `/Users/mac/work/github-private/private-proj-*/` — 41 working copies (one per repo)
- `/tmp/sigco_thumbnails/` — 110 extracted images, pushed to `sigco3111/private-archive-thumbnails` (public)
- `/tmp/sigco_search_v2.json` — 123 web-search URLs (rolled back, still on disk)
- `/Users/mac/work/sigco3111-readme-edit/README-checklist-2026-07-31.md` — master checklist (~16KB after rollback)
- `~/Downloads/README-checklist-2026-07-31.md` — user-facing copy (always write here too)
- `/tmp/sigco_*.py` — pipeline scripts

## Pipeline scripts (in execution order)

| # | Script | Purpose | When to re-run |
|---|---|---|---|
| 1 | `sigco_readme_gen.py` | Per-repo README generator (fancy template, 9KB output) | Imported as a library by 2 |
| 2 | `sigco_main.py --all` | Generate + commit + push 41 READMEs (~5 min) | If §13 not yet run |
| 3 | `sigco_thumbnails.py --extract` | Pull 2-3 representative images from each repo's `res/` | If §14 not yet run |
| 4 | `sigco_thumbnails.py --upload` | Create `private-archive-thumbnails` public repo, push images | If §14 not yet run |
| 5 | `sigco_embed_push.py` | Add image + external-resource sections to 41 READMEs, push | After 3-4 |
| 6 | `sigco_checklist_v3.py` | Rebuild checklist with PUSH table + stats | After every push round |
| 7 | `sigco_search_v2.py --all` | Naver/Google/NamuWiki search, save to JSON | **Don't run unless user explicitly OKs §15 again** |
| 8 | `sigco_search_push.py` | Add search URLs to 41 READMEs, push | **Only after 7 succeeds with user-confirmed relevant URLs** |
| 9 | `sigco_rollback.py` | Strip the `### 🔍 검색 결과` section from 41 READMEs and push revert | If §15 results turn out to be irrelevant |

All scripts use `subprocess.run([...], cwd=WORK / slug, ...)` per-repo — no shared state, safe to interrupt.

## Key decisions and why

### Why 3 push rounds, not 1

User asked incrementally: "리드미 갱신" → "이미지도" → "기사는?" → "롤백해". Each push is a discrete commit on each repo, easy to revert individually. Don't try to do everything in one shot.

### Why a separate `private-archive-thumbnails` PUBLIC repo

GitHub raw URLs to PRIVATE repos require auth — they won't render for unauthenticated users reading the README. Solution: a public mirror that only contains thumbnails, while the full source stays private. Tradeoff: thumbnails are now publicly visible (3 PNGs per repo × 41 = 110 files, ~10MB total). This is acceptable because they're screenshots, not source code.

### Why `cp -a` over `cp -r`

`-a` = archive mode: preserves permissions, timestamps, symlinks. Original `/Users/mac/work/backup/02-private/` stays untouched; working copies at `/Users/mac/work/github-private/` are the only mutable artifacts. If anything breaks, original is safe.

### Why `terminal(background=true, notify_on_complete=true)` not foreground

41 repos × 3 seconds per push = 2-5 minutes per round. Foreground timeout is 600s max; the 5-min round is borderline. Background + polling is safer. Tested in 2026-07-31: all three rounds completed within 5 minutes via background.

### Why `sleep 2` between pushes

GitHub's secondary rate limit kicks in around push #9 without a gap. 2 seconds per push keeps us at ~30/min, well under the limit.

### Why `gh search` was abandoned for web search

`gh search repos` only searches GitHub. For external articles (Naver, Google, NamuWiki), `curl` + `curl -A "<UA>"` was the only reliable path. DDG Lite and Brave both blocked the bot.

## User corrections captured

1. **"기사 더 깊이 검색해서 찾아줘"** → I added §15 (auto web search). User came back with **"링크가 모두 상관 없는 것들임. 일단 모두 롤백해"** → I ran `sigco_rollback.py` to strip the search section from all 41 READMEs. **The lesson**: auto-search URLs (search result pages from Naver/Google/NamuWiki) are not what users want. They want specific wiki pages or news articles about the actual project, which requires manual curation. Captured as §16 in the skill.

2. **"푸시 후 체크리스트 갱신하도록"** → The pipeline now always updates the checklist at the end of every push round (built into each script as the last step). Captured as Pitfall §13 #8 in the skill.

3. **"다운로드 폴더"** → The user's `~/Downloads/` is the destination for user-facing artifacts (checklist copy). Captured as Pitfall §13 #1.

## Re-run checklist (if user asks "다시 해줘")

```bash
# Verify current state
cd /Users/mac/work/github-private && for d in private-proj-*/; do
  cd "$d" && echo "$(basename $d): $(git log -1 --oneline)"
  cd ..
done

# If user wants §13 fresh (overwrites existing):
python3 /tmp/sigco_main.py --all

# If §14 fresh:
python3 /tmp/sigco_thumbnails.py --extract --upload
python3 /tmp/sigco_embed_push.py

# If §16 (manual):
# Edit each README.md to replace auto-search section with curated list
git add README.md && git commit -m "docs: §16 수동 외부 자료 추가"
git push origin main

# Always end with:
python3 /tmp/sigco_checklist_v3.py
```

## Known weak spots

1. **Auto search produces irrelevant URLs** (already addressed via §16 fallback)
2. **f-string + tuple indexing confusion** — `f"{p[1]:,}B"` where `p[1]` is a slug string fails with TypeError on `+`. Always use `str(p[N]) + "B"` or verify `p[N]` is int before comma-format. Hit twice in `sigco_checklist_v4.py` during this session.
3. **In-place regex postprocess can silently truncate** — `sigco_postprocess.py` once truncated checklist from 36KB to 9KB by being too aggressive with regex. Always rebuild from scratch instead of patching in place. Captured as §13 Pitfall #10.
4. **Naver mobile news HTML structure changes** — different from Google. Naver uses `n.news.naver.com/article/...`, Google uses `/url?q=...`. Need separate regex per source.
