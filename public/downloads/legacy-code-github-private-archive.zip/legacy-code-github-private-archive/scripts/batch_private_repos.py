#!/usr/bin/env python3
"""대용량 백업 폴더 → 다중 비공개 GitHub 저장소 배치 푸시 스크립트.

전제:
  - gh CLI 인증 완료 (`gh auth status`)
  - Python 3.9+ (pathlib, subprocess)
  - 작업 사본은 /Users/mac/work/github-private/<repo-name>/ 에 생성

사용법:
  1) 아래 REPOS 리스트를 본인의 (저장소명, 출처 상대경로, 풀네임, 카테고리, 용도) 로 채움
  2) python3 batch_private_repos.py 2>&1 | tee _create_private_repos.log
  3) 끝나면 Phase 5 검증 (배치 README/gh API 일괄 확인)

검증 사례 (2026-07-31):
  원본: ~/work/backup/02-private/01-회사-외주-자료/  (17GB)
  → 17개 비공개 repo로 분할 푸시 (평균 1GB, 최대 3GB)
"""
import os, subprocess, sys
from pathlib import Path

# === 사용자 설정 ===
SRC = Path('/Users/mac/work/backup/02-private/<원본-폴더>')
DST = Path('/Users/mac/work/github-private')

# (저장소명, [출처 상대경로들], 풀네임, 카테고리, 용도)
REPOS = [
    # 예시:
    # ('private-company-arcade', ['기획/1. 아케이드'],
    #  '아케이드 게임 기획/외주 자료', '기획',
    #  '아케이드 장르 게임 기획 자료. 회사 외주 작업 시 사용한 기획 문서/그래픽/원화/설계도 등.'),
]

# === 빌드 산출물 제외 패턴 (통합 .gitignore) ===
EXCLUDE_PATTERNS = (
    '.DS_Store',
    # VC++ 6
    '*.opt', '*.plg', '*.ncb', '*.positions', '*.aps', '*.suo',
    '*.user', '*.userosscache', '*.sdf', '*.opensdf',
    # Build output
    '*.obj', '*.sbr', '*.exe', '*.pdb', '*.idb', '*.pch',
    '*.ilk', '*.bsc', '*.res', '*.tlog', 'BuildLog.htm',
    '*.lastbuildstate', '*.exp', '*.lib',
    # MFC temp
    'MFC*.TMP', 'MFC*.tmp', '~VC*.TMP', '~VC*.tmp',
    # VC60/70 PDB
    'vc60.idb', 'vc60.pdb', 'vc70.idb', 'vc70.pdb',
    # IDE
    '.vs/', '.vscode/',
    # Android
    '*.apk', '*.ap_', '*.dex', '*.class',
    'target/', 'build/',
    # Backup / temp
    '*.bak', '*.tmp', 'ALZ*.TMP', 'ALZ*.tmp',
)

GITIGNORE_TEMPLATE = """# macOS
.DS_Store

# Visual C++ 6 / Visual Studio
*.opt
*.plg
*.ncb
*.positions
*.aps
*.suo
*.user
*.userosscache
*.sdf
*.opensdf
Debug/
Release/
Release_IME/

# Build output
*.obj
*.sbr
*.exe
*.pdb
*.idb
*.pch
*.ilk
*.bsc
*.res
*.tlog
BuildLog.htm
*.lastbuildstate
*.exp
*.lib

# MFC temp
MFC*.TMP
MFC*.tmp
~VC*.TMP
~VC*.tmp

# VC60/70 PDB
vc60.idb
vc60.pdb
vc70.idb
vc70.pdb

# IDE
.vs/
.vscode/
*.swp

# Android build
*.apk
*.ap_
*.dex
*.class
target/
build/

# Backup / temp
*.bak
*.tmp
ALZ*.TMP
ALZ*.tmp

# Logs
*.log
"""

LICENSE_MIT = """MIT License

Copyright (c) sigco3111

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

NOTE: This license covers the work product in this repository. All rights to the
underlying game intellectual property, characters, brand names, and any
third-party content remain with their respective owners.
"""


def fmt_size(n: int) -> str:
    if n < 1024: return f'{n}B'
    if n < 1024**2: return f'{n/1024:.1f}KB'
    if n < 1024**3: return f'{n/1024**2:.1f}MB'
    return f'{n/1024**3:.2f}GB'


def count_files(root: Path) -> dict:
    n_files = n_dirs = total_size = 0
    file_ext = {}
    for f in root.rglob('*'):
        if f.is_file():
            n_files += 1
            total_size += f.stat().st_size
            ext = f.suffix.lower() or '(no ext)'
            file_ext[ext] = file_ext.get(ext, 0) + 1
        elif f.is_dir():
            n_dirs += 1
    return {
        'n_files': n_files, 'n_dirs': n_dirs,
        'total_size': total_size,
        'top_exts': sorted(file_ext.items(), key=lambda x: -x[1])[:10],
    }


def list_top_dirs(root: Path, limit: int = 20) -> list:
    items = []
    for d in sorted(root.iterdir()):
        if d.name.startswith('.'):
            continue
        if d.is_dir():
            sz = sum(f.stat().st_size for f in d.rglob('*') if f.is_file())
            items.append((d.name, sz))
        elif d.is_file():
            items.append((d.name + ' (file)', d.stat().st_size))
    items.sort(key=lambda x: -x[1])
    return items[:limit]


def make_readme(repo_name, full_name, category, source, purpose, root: Path) -> str:
    """화려하고 자세한 비공개 README 자동 생성 (사용자 선호 스타일)."""
    stats = count_files(root)
    top_dirs = list_top_dirs(root)

    ext_table = '\n'.join(f"| `{ext or '(no ext)'}` | {n:,} |" for ext, n in stats['top_exts'])
    tree_lines = [
        f'└── 📁 {name}/ ({fmt_size(sz)})' if not name.endswith(' (file)')
        else f'└── 📄 {name} ({fmt_size(sz)})'
        for name, sz in top_dirs
    ]
    tree_block = '\n'.join(tree_lines) if tree_lines else '(빈 디렉터리)'

    return f"""# 🔒 {full_name}

> ⚠️ **이 저장소는 비공개입니다.** 회사와 관련된 외주 작업 / 기획 / 계약 / 비공개 자료를 보관합니다. 본인만 접근 가능합니다.
> 본 자료는 동일인이 회사 외주 작업 시 사용한 자료이며, 비영리 개인 백업/아카이브 목적입니다.

![visibility](https://img.shields.io/badge/visibility-PRIVATE-red?style=flat-square) ![category](https://img.shields.io/badge/category-{category.replace(' ', '%20')}-orange?style=flat-square) ![files](https://img.shields.io/badge/files-{stats['n_files']:,}-blue?style=flat-square) ![license](https://img.shields.io/badge/license-MIT-blue?style=flat-square)

---

## 📋 개요

| 항목 | 값 |
|---|---|
| **저장소명** | `{repo_name}` |
| **풀네임** | {full_name} |
| **카테고리** | {category} |
| **용도** | {purpose} |
| **원본 위치** | `~/work/backup/02-private/{source}` |
| **가시성** | 🔒 **PRIVATE** (비공개) |
| **파일 수** | {stats['n_files']:,}개 |
| **폴더 수** | {stats['n_dirs']:,}개 |
| **총 용량** | {fmt_size(stats['total_size'])} |
| **라이선스** | MIT (저장소 자체), 콘텐츠는 원저작자 소유 |

---

## 📜 목차

- [📋 개요](#-개요)
- [🎯 용도](#-용도)
- [📂 폴더 구성](#-폴더-구성)
- [📊 파일 분포](#-파일-분포)
- [🔒 비공개 정책](#-비공개-정책)
- [⚙️ 빌드 산출물 정리 안내](#-빌드-산출물-정리-안내)
- [🐛 알려진 한계](#-알려진-한계)
- [📜 라이선스](#-라이선스)
- [📁 원본 출처](#-원본-출처)

---

## 🎯 용도

> {purpose}

본 자료는 동일인이 회사 외주/내부 작업 시 사용한 자료이며, 다음 중 하나에 해당합니다.

- 📋 **기획 문서** — 게임 기획서, 시스템 설계, 원화, 시나리오
- 🎨 **그래픽 원본** — 캐릭터/배경 PSD/AI 파일, 원화 스캔
- 📊 **업무 자료** — 제안서, 계약서, 회의록, 일정표
- 🔒 **비공개 문서** — 회사 내부 비공개 자료
- 📱 **모바일 게임 소스** — WIPI/J2ME/BREW 등 플랫폼별 게임 소스 코드

---

## 📂 폴더 구성

원본 폴더 구조를 그대로 보존했습니다. 최상위 폴더별 크기:

```text
{repo_name}/
{tree_block}
```

각 폴더의 자세한 내용은 해당 폴더 안의 문서/이미지를 참고하세요.

---

## 📊 파일 분포

| 확장자 | 파일 수 |
|---|---:|
{ext_table}

전체 파일 수: **{stats['n_files']:,}개**, 총 용량: **{fmt_size(stats['total_size'])}**

---

## 🔒 비공개 정책

이 저장소는 다음 정책으로 운영됩니다.

- ✅ **본인만 접근** — GitHub 비공개(Private) 설정
- ✅ **로컬 백업 동기화** — 원본 폴더와 동기화
- ⚠️ **외부 공유 금지** — 회사/클라이언트 자료이므로 외부 공유 금지
- ⚠️ **계약/법적 책임** — 일부 자료는 NDA/계약에 의해 공개가 금지될 수 있음
- ⚠️ **저작권** — 게임/캐릭터/브랜드의 저작권은 각 권리자에게 있음

---

## ⚙️ 빌드 산출물 정리 안내

공개 시 다음 항목은 제외했습니다.

```text
✅ 제외된 항목
├── macOS: .DS_Store
├── VC++ 6 환경: *.opt / *.plg / *.ncb / *.positions / *.aps / *.suo
├── 빌드 산출물: *.obj / *.exe / *.pdb / *.idb / *.ilk / *.bsc / *.res / *.tlog
├── MFC 임시: MFC*.TMP / ~VC*.TMP
├── VC PDB: vc60.idb / vc60.pdb / vc70.idb / vc70.pdb
├── Android: *.apk / *.dex / *.class / target/ / build/
└── 임시/백업: *.bak / *.tmp / ALZ*.TMP
```

---

## 🐛 알려진 한계

이 저장소는 회사 외주 작업 자료의 **아카이브 사본**이며, 다음 한계가 있습니다.

1. **빌드 시스템 부재** — 외부 SDK/IDE 의존성이 포함되지 않아 빌드 불가
2. **NDA/계약서** — 일부 자료는 NDA 또는 계약 조건에 의해 공개가 금지될 수 있음
3. **외부 SDK 미포함** — 닌텐도 DS SDK, 모바일 플랫폼 SDK, MFC 등은 포함되지 않음
4. **저작권** — 게임 IP/캐릭터/브랜드는 각 권리자에게 있으며, 본 자료는 단순 보관 목적
5. **빌드 환경 의존** — 한글이 들어간 파일명(EUC-KR) 때문에 일부 OS에서는 인코딩 경고 가능
6. **날짜 정확도** — 일부 자료의 작성일은 정확하지 않을 수 있음 (외주 작업 특성)
7. **중복/유사 자료** — 같은 자료의 여러 버전이 들어 있을 수 있음
8. **참고용** — 실제 회사/클라이언트 작업 시 사용한 자료이지만, 본 저장소는 단순 백업 목적
9. **.gitignore 적용** — 빌드 산출물 / 임시 파일 / 환경 파일은 자동으로 제외됨
10. **README는 메타데이터만** — 각 자료의 자세한 내용은 폴더 안의 문서 참고

---

## 📜 라이선스

- 본 저장소의 **소스 코드/문서**는 MIT 라이선스로 공개합니다. (`LICENSE` 참고)
- 단, **외주 작업의 결과물(게임 IP, 캐릭터, 브랜드, 디자인)**은 각 권리자에게 있으며, 본인은 단순 보관 권한만 가집니다.
- **NDA/계약서**가 적용되는 자료는 해당 계약 조건을 따릅니다.
- 다음은 본 저장소에 포함되어 있지 않습니다:
  - 닌텐도 DS SDK (Nintendo 소유, NDA 필요)
  - J2ME / WIPI / BREW SDK (각 플랫폼 소유)
  - Visual C++ / MFC / DirectX SDK (Microsoft 소유)

---

## 📁 원본 출처

이 저장소는 다음 경로의 사본입니다.

```text
~/work/backup/02-private/{source}
```

원본은 본인 외부 HDD의 회사 외주 자료 백업이며, 본 저장소는 GitHub 비공개(PRIVATE)로 동기화한 것입니다.

---

> 🔒 **Tip**: 이 저장소는 비공개이므로 `gh repo view {repo_name} --json visibility`로 가시성을 확인할 수 있습니다. 본인 외에는 어떤 사용자도 접근할 수 없습니다.
"""


def run(cmd, cwd=None, check=True):
    result = subprocess.run(cmd, cwd=str(cwd) if cwd else None,
                            capture_output=True, text=True)
    if check and result.returncode != 0:
        print(f'  ❌ 실패: {" ".join(cmd[:3])}...')
        print(f'  stderr: {result.stderr[:500]}')
    return result


def main():
    total_pushed = 0
    for repo_name, srcs, full_name, category, purpose in REPOS:
        target = DST / repo_name
        if not target.exists():
            # Phase 1: 작업 사본 생성
            target.mkdir(parents=True, exist_ok=True)
            for s in srcs:
                src = SRC / s
                if not src.exists():
                    print(f'  ⚠️  없음: {s}')
                    continue
                if src.is_dir():
                    dst_sub = target / src.name
                    if dst_sub.exists():
                        import shutil
                        shutil.rmtree(dst_sub)
                    import shutil
                    shutil.copytree(src, dst_sub,
                                    ignore=shutil.ignore_patterns(*EXCLUDE_PATTERNS))
                else:
                    import shutil
                    shutil.copy2(src, target / src.name)

        print(f'\n=== [{repo_name}] {full_name} ===')

        # Phase 2: README + .gitignore + LICENSE
        (target / '.gitignore').write_text(GITIGNORE_TEMPLATE, encoding='utf-8')
        (target / 'LICENSE').write_text(LICENSE_MIT, encoding='utf-8')
        source_str = ', '.join(srcs)
        readme = make_readme(repo_name, full_name, category, source_str, purpose, target)
        (target / 'README.md').write_text(readme, encoding='utf-8')

        # Phase 3: git init + add + commit + push
        run(['git', 'init', '-q', '-b', 'main'], cwd=target)
        run(['git', 'config', 'user.email', '[email protected]'], cwd=target)
        run(['git', 'config', 'user.name', 'sigco3111'], cwd=target)
        run(['git', 'add', '.'], cwd=target, check=False)

        result = run(['git', 'status', '--short'], cwd=target, check=False)
        n_staged = len(result.stdout.strip().split('\n')) if result.stdout.strip() else 0
        print(f'  📦 스테이지된 파일 수: {n_staged:,}')

        commit_msg = f"""{full_name} 비공개 저장소 푸시

- 카테고리: {category}
- 원본: {source_str}
- 용도: {purpose}
- 파일 수: {n_staged:,}개
- 공개: PRIVATE (비공개)
- .gitignore + LICENSE + README.md 추가"""
        run(['git', 'commit', '-q', '-m', commit_msg], cwd=target, check=False)

        result = run(['gh', 'repo', 'create', repo_name,
                      '--private',
                      '--description', f'{full_name} (회사 외주 자료, 비공개)',
                      '--source', '.', '--push'], cwd=target, check=False)
        if result.returncode != 0:
            print(f'  ❌ gh repo create 실패: {result.stderr[:500]}')
            continue

        print(f'  ✅ 푸시 성공: {repo_name}')
        total_pushed += 1

    print(f'\n=== 완료: {total_pushed}/{len(REPOS)} 저장소 푸시 성공 ===')


if __name__ == '__main__':
    main()
