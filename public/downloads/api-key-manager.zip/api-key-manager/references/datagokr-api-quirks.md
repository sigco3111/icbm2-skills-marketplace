# data.go.kr API Quirks & Limitations

## 한국천문研究院_특일 정보 API (ID: 15012690)

### 동작하는 엔드포인트

| 서비스명 | URL suffix | 상태 |
|----------|-----------|------|
| 기념일 조회 | `/getAnniversaryInfo` | ✅ 동작 |
| 공휴일 조회 | `/getHolidayInfoService` | ❌ API not found |
| 국경일 조회 | `/getRestDeInfoService` | ❌ API not found |
| 24절기 조회 | `/get24DivisionsInfoService` | ❌ API not found |
| 잡절 조회 | `/getSundryDayInfoService` | ❌ API not found |

**현재 동작:** `getAnniversaryInfo` (기념일)만 사용 가능.
다른 서비스는 API URL 자체가 존재하지 않음 — 문서에는 나와있지만 실제 서비스는 미구현.

### Request 형식

```
https://apis.data.go.kr/B090041/openapi/service/SpcdeInfoService/getAnniversaryInfo
?ServiceKey=URL-encoded-KEY
&solYear=2026
&solMonth=05
&numOfRows=50
&pageNo=1
```

**필수 파라미터:**
- `ServiceKey` — URL 인코딩 필수 (spaces, special chars)
- `solYear` — 연도 4자리
- `numOfRows` — 기본값 10, 50 이상 권장
- `pageNo` — 페이지 번호

**선택 파라미터:**
- `solMonth` — 월 2자리 (01~12), 없으면 전체 연도 조회

### Response 형식

XML로만 반환 (JSON 불가).
최소 요청: 10,000회/일 (개발계정).

### 응답 필드 (item 기준)

```
locdate    — 날짜 (YYYYMMDD, 8자리)
dateName   — 명칭
dateKind   — 종류 (02=기념일)
isHoliday  — 공공기관 휴일 여부 (Y/N)
seq        — 순번
```

### 주의사항

1. **HTTPS 필수** — http://는 타임아웃 (10초)
2. **URL 인코딩** — ServiceKey에 `%`之类的 문자 있으면不正确揣测
3. **날짜 기준** — 양력(solYear/solMonth), 음력은 없음
4. **공휴일/국경일** — `getAnniversaryInfo`의 `isHoliday=Y` 필드로 간접 확인
   (현재 `isHoliday=N`만 반환됨 — 공휴일 API가故障 중)
5. **연휴 감지 로직** — 토요일/일요일이 공휴일 목록에 있으면 연휴 가능성 판단

### 테스트 명령어

```bash
# 2026년 5월 기념일 조회
curl -s "https://apis.data.go.kr/B090041/openapi/service/SpcdeInfoService/getAnniversaryInfo?ServiceKey=$(cat ~/.hermes/secrets/datagokr_key.txt)&solYear=2026&solMonth=05&numOfRows=50&pageNo=1"

# Key 만료 확인
python3 ~/.hermes/scripts/apikey_holiday_monitor.py --check-expiry
```