---
name: api-key-manager
description: API Key的生命주기 관리 — 발급, 파일 저장, 만료 감시, Telegram 알림까지 Entire 파이프라인. 공공데이터포털(data.go.kr) 키 관리에 특화.
version: 1.1.0
author: ICBM2
metadata:
  hermes:
    tags: [Automation, API, Secret, Expiry, Monitoring]
  created: 2026-05-14
---

# API Key Manager 스킬

## 개요

외부 API Key를 체계적으로 관리하고, 만료일을 추적하며 자동 알림을 주는 파이프라인.

**주 사용처:**
- 공공데이터포털 (data.go.kr) API 키
- 다른 외부 API 키들도 동일한 패턴 적용 가능

## 파일 명명 규약 (Naming Convention)

```
~/.hermes/secrets/
  {platform}_expiry_YYYYMMDD.txt    ← 만료일 관리 대상 키 (7일 전 알림)
  {platform}_key.txt               ← 만료일 없는 일반 키 (감시 안 함)
  {platform}_token.txt             ← 통합 토큰 (Notion, Slack, GitHub 등) — liveness probe 필요
```

**`{platform}_expiry_YYYYMMDD.txt` 파일 규칙:**
- 파일명: `{플랫폼명}_expiry_{만료일(YYYYMMDD)}.txt`
- 내용: API Key 원본 (첫 줄만 또는 `KEY=값` 형태)
- 예: `datagokr_expiry_20280514.txt` → 만료일 2028-05-14

**`{platform}_key.txt` 파일 규칙:**
- 만료일 없는 일반 키 파일
- 스크립트가 자동 감지하지만 만료 알림은 보내지 않음

**`{platform}_token.txt` 파일 규칙 (통합 토큰):**
- Notion Integration, Slack Bot, GitHub PAT, OpenAI/Anthropic API key 등
- **발급 시점에 만료일을 알 수 없는 토큰** — workspace 측에서 silent revoke 가능
- 만료일 추적 대신 **liveness probe** (e.g. `/v1/users/me` for Notion)로 방어
- probe 실패 시 status file fallback + Telegram 알림 패턴: `weekly-automation-report/templates/notion_preflight.py` 참조

## 모니터링 스크립트

**스크립트:** `~/.hermes/scripts/apikey_holiday_monitor.py`

```bash
# Key 만료 체크 (7일 전부터 매일 알림)
python3 ~/.hermes/scripts/apikey_holiday_monitor.py --check-expiry

# 공휴일/연휴 조회 (14일 내)
python3 ~/.hermes/scripts/apikey_holiday_monitor.py --holidays current
python3 ~/.hermes/scripts/apikey_holiday_monitor.py --holidays 2026 12
```

**liveness probe는 별도 패턴** — 위 스크립트는 날짜 기반 만료 감시만 수행. 통합 토큰
(특히 Notion)의 silent revoke는 probe-based 모니터링이 필수. 예시: 매주 weekly
report cron이 `weekly-automation-report/templates/notion_preflight.py`로 검증.

## 크론 잡 설정

| 시간 | 작업 | 설명 |
|------|------|------|
| 09:00 | `--check-expiry` | Key 만료 7일 전부터 매일 알림 |
| 10:00 | `--holidays current` | 14일 내 공휴일/연휴 알림 |
| 매주 일요일 | weekly cron → `notion_preflight.py` | Notion 통합 토큰 liveness probe (weekly-automation-report 연동) |

## 새 키 추가 절차

1. **발급 받기** → 공공데이터포털에서 API Key 발급
2. **파일 저장** → 만료일 포함 파일명 사용
   ```bash
   echo "API_KEY_값" > ~/.hermes/secrets/{platform}_expiry_YYYYMMDD.txt
   ```
3. **즉시 검증** → 만료일 포함되었는지 확인
   ```bash
   python3 ~/.hermes/scripts/apikey_holiday_monitor.py --check-expiry
   ```

## 통합 토큰 추가 절차 (만료일 미고지, e.g. Notion)

1. **발급 받기** → Notion workspace Settings → Connections → Create integration
2. **파일 저장** → `_token.txt` 접미사
   ```bash
   echo "ntn_..." > ~/.hermes/secrets/notion_token.txt
   ```
3. **즉시 liveness probe** → 인증 거부되면 의미 없는 키
   ```bash
   TK=$(cat ~/.hermes/secrets/notion_token.txt)
   curl -s https://api.notion.com/v1/users/me -H "Authorization: Bearer *** -H "Notion-Version: 2022-06-28" | grep -q '"object": "user"'
   ```
4. **probe 결과 false → 즉시 rotation** (workspace 측 revoke 가능성)
5. **liveness probe 스케줄 등록** — `weekly-automation-report` 같은 정기 워크플로우에 probe 단계 추가

## ⚠️ data.go.kr API Quirks

[data.go.kr API 특징과 한계](references/datagokr-api-quirks.md)를 반드시 참조할 것.

## Telegram 알림 설정

환경 변수 `TELEGRAM_BOT_TOKEN` + `TELEGRAM_CHAT_ID` 설정 시 텔레그램으로 직접 전송.
미설정 시 stdout만 출력 (크론 로그에서 확인).

```bash
# Telegram 설정 확인
echo "TOKEN: ${TELEGRAM_BOT_TOKEN:-(not set)}"
echo "CHAT: ${TELEGRAM_CHAT_ID:-(not set)}"
```

## NVIDIA NIM API 키 발급/검증 (2026-07-07 학습)

**NVIDIA NIM (`integrate.api.nvidia.com`) 무료 티어** — BYOK 패턴이 필요한 모든 프로젝트(1인용 AI 통합 게임 류)의 핵심 의존성.

### 발급 단계 (5단계, 3분)

1. **직행 URL 접속** — `https://build.nvidia.com/settings/api-keys` 로 **모델 카탈로그 없이 직접** 진입. ❌ `build.nvidia.com/models` → 모델 검색 → "Get API Key" 패턴은 **불필요한 단계**. (2026-07-07 BYOK 게임 README 세션에서 사용자가 정정함)
2. **회원가입 / 로그인** — GitHub·Google·이메일 중 선택. **⚠️ 핸드폰 인증 필수** — 미인증 시 "Generate Key" 버튼이 비활성화됨. 인증 코드는 SMS로 발송, 5분 내 입력.
3. **키 생성** — "Generate Key" → 이름 입력 (예: `nim-game-demo`) → **키는 한 번만 표시** → 즉시 복사.
4. **키 형식 확인** — `nvapi-XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX` (60~70자). 접두사 `nvapi-` 또는 `nvapi-prod-` 둘 다 작동.
5. **즉시 검증 (선택이지만 권장)** — 30초 컷 체크:

```bash
KEY=$(security find-generic-password -s "NVIDIA_API_KEY_1" -w 2>/dev/null || echo "${NVIDIA_API_KEY_1:-}")
curl https://integrate.api.nvidia.com/v1/chat/completions \
  -H "Authorization: Bearer $KEY" \
  -H "Content-Type: application/json" \
  -d '{"model":"openai/gpt-oss-120b","messages":[{"role":"user","content":"hi"}],"max_tokens":1}'
```

✅ `200 OK` → 키 정상.
❌ `401 Unauthorized` → 오타 / 핸드폰 인증 미완료 / 키 만료.

### 무료 한도 (2026-07-07 사용자 교정으로 정정)

| 항목 | 정정된 값 |
|---|---|
| **월 한도** | **없음** |
| **분당 한도** | **40 RPM** (모든 모델 공통, 무료 티어) |
| 본 게임 1턴 = 1~3 요청 | **분당 13턴 플레이 가능** |
| 429 응답 시 | 60초 대기 후 자동 재개 |

⚠️ **잘못 알려진 정보 (이전 README/문서)**: "월 1,000 요청". 공식 docs에 명시 없음, NVIDIA 빌드 사이트 모델 페이지에도 자동 노출 안 됨. **실측 사용자 경험이 가장 신뢰할 만함**.

### Pitfalls (NVIDIA NIM 특화)

- **핸드폰 인증 만료 (90일)** — 재인증 안 하면 키 작동 안 함. 키는 살아있지만 401. → 사용자 안내: "NIM 콘솔 로그인 → 핸드폰 재인증" 후 재발급 불필요.
- **모델 ID 형식 정확히 `openai/gpt-oss-120b`** (소문자, 슬래시) — 오타 시 404. zai/GLM 같은 다른 NIM 카탈로그 ID는 **다른 모델**이므로 절대 혼용 금지.
- **reasoning 모델의 `max_tokens` 함정** (함정 5 cross-ref): `openai/gpt-oss-120b` 같은 reasoning 모델은 `reasoning_content` 필드에 추론을 먼저 쓰고 `max_tokens`를 다 소진 → `finish_reason: "length"` + 본 답변 `content: null` 가능. BYOK 게임에서 NPC 두뇌로 쓸 때는 **`max_tokens: 4096` 이상** 권장. 작은 값으로 테스트하면 "AI가 답을 안 한다" 오해.
- **OpenAI 호환이지만 rate-limit 헤더 미노출** — `x-ratelimit-*` 같은 표준 헤더 없음. 429 응답 본문에 retry-after 안 적힘. → 클라이언트에서 자체적으로 60초 backoff 구현 필요.
- **Bearer 토큰 노출 위험** — `~/.hermes/secrets/nvidia_key.txt`에 저장하고 `.env*.local`은 `.gitignore` 등록. Vercel 배포 시 Environment Variables에 등록 (Production/Preview/Development 모두). **GitHub 커밋 절대 금지**.
- **BYOK 사용자에게 키 발급 가이드 제공 시** — "모델 카탈로그 탐색" 단계 끼워넣지 말 것. **직행 URL + 핸드폰 인증** 만으로 충분.

### 파일 저장 (ICBM2 패턴)

```bash
# macOS 키체인 우선 (보안)
security add-generic-password -s "NVIDIA_API_KEY_1" -a "nvidia" -w "nvapi-..."

# 폴백: 일반 파일
mkdir -p ~/.hermes/secrets
echo "nvapi-..." > ~/.hermes/secrets/nvidia_key.txt
```

**`{platform}_expiry_*.txt` 패턴은 사용 안 함** — NIM 키는 만료일 없음 (핸드폰 인증만 갱신), `*_key.txt` 일반 키 규칙 따름.

## Pitfalls

- **Python global 변수 문제:** `DATAGOKR_KEY` 같은 모듈 전역 변수는 함수 안에서 `global` 선언 필수. 안 하면 `UnboundLocalError` 발생 (2026-05-14 버그 history)
- **http vs https:** 공공데이터포털 API는 `https://` 필수. `http://`는 타임아웃
- **만료일 형식:** YYYYMMDD 8자리. YYYY-MM-DD 형식 불가
- **파일 존재 ≠ 토큰 유효:** Notion Integration Token이 silent revoke되면 파일은 존재하지만 401 반환. 매 probe 필수. 2026-06-07 incident: weekly cron이 6주 연속 silent failure했다가 우연히 발견됨.
- **integration revoke는 user에게 통보되지 않음** — Notion은 workspace owner가 integration을 삭제해도 consumer에게는 알림 없음. liveness probe가 유일한 defense.
- **weekly-automation-report 스킬과 강하게 결합** — probe 패턴이 그쪽에 있음 (`templates/notion_preflight.py`). 이 스킬은 메타데이터/추적만, 실제 probe 구현은 weekly-automation-report 참조.
- **NIM BYOK 가이드에서 "모델 카탈로그 탐색 단계" 절대 끼워넣지 말 것** — 사용자가 직접 정정함 (2026-07-07). 직행 URL `build.nvidia.com/settings/api-keys`가 정답.
