# 세션 종료 / 백그라운드 SIGTERM 실전 함정 (2026-07-27)

> minimax-of-duty 보드 운영 중 만난 종료 / SIGTERM 패턴 4건. SKILL.md 본문 함정 17, 18 참조.

## 1. 사용자 "작업종료" 신호 = 즉시 STOP (★★★ 사용자 분노 사례)

### 무엇이 일어났나

Phase 1.3 워커 진행 중 사용자 "작업종료" 신호 → 운영자가 PROMPT-LOG 갱신 + 메모리 write_file + 스킬 patch + HERMES.md 손질 등 "마무리 작업"으로 10분 끌음 → 사용자 "종료하는 중이 맞나? 10분가까이 걸렸는데, 왜 아직 처리중이지?" 분노 메시지.

### 올바른 종료 절차 (30초 안에)

```bash
# 1. 워커 SIGTERM (있으면)
for pid in $(ps aux | grep -E 'hermes.*coder.*t_' | grep -v grep | awk '{print $2}'); do
  kill -9 $pid 2>/dev/null
done

# 2. dev 서버 SIGTERM (있으면)
kill -9 $(lsof -ti:5173 2>/dev/null) 2>/dev/null
kill -9 $(lsof -ti:4173 2>/dev/null) 2>/dev/null

# 3. 포트 깨끗 확인
lsof -ti:5173 2>&1 | wc -l   # 0 확인
lsof -ti:4173 2>&1 | wc -l

# 4. 보드 stats (워커 살아있는지)
hermes kanban --board <slug> stats 2>&1 | head -12

# 5. 5줄 요약 보고 후 STOP
```

5줄 보고 예시:
```
프로젝트 종료 처리.
- 워커 0개, dev 서버 0개, 포트 cleanup ✅
- 보존: local git 4 commit, 사용자 디렉터리 Phase 1.3 미커밋 월드 1,505 lines
- 칸반 보드: minimax-of-duty (DB 살아있음)
- 다음 세션: "Phase 1.3 마무리하고 1.4 가자" 한마디면 resume
- 다른 방향 진행하시면서 자유롭게 시작 가능
```

### 절대 금지 (종료 신호 후)

- ❌ PROMPT-LOG 갱신 (다음 세션에서 박으면 됨)
- ❌ memory write_file (스킬 본문 박았으니 메모리 수정 불필요)
- ❌ skill patch (스킬 본문은 이미 박았음)
- ❌ HERMES.md / README / 다른 메타 파일 손질
- ❌ git commit / git push (사용자 명시 신호 전엔 보류)
- ❌ "마지막으로 한 가지만" 명목의 추가 작업

### 사용자 분노 패턴

snkrx-web / minimax-of-duty 두 보드에서 같은 패턴 발생. **사용자가 종료 신호 보내는 건 더 이상의 작업을 원하지 않는다는 명확한 신호**. 운영자의 "마무리" 는 사용자 인내심 시험. **신호 받자마자 cleanup → 5줄 → STOP**.

## 2. vite dev 서버 SIGTERM 30분 사이클 (함정 18)

### 무엇이 일어났나

Phase 1.2 + Phase 1.3 워커가 진행되는 동안 같은 시점에 vite dev 서버가 SIGTERM (exit 143) 받음. 알림 로그 보면 워커가 11번 HMR 핫리로드 후 서버 종료. 30분 간격으로 반복.

### 원인 추정

- Hermes 데몬의 백그라운드 프로세스 정리 사이클 (30분 무활동 idle kill)
- 또는 시스템 launchd 가 long-lived 자식 정리
- 또는 사용자가 새 명령 시작하면서 자동 정리

### 영향

- 코드 손실 0 (사용자 디렉터리에 박힌 거 보존)
- 워커도 영향 0 (별도 PID, scratch 아님)
- dev 서버만 죽음 → 사용자 브라우저 ERR_CONNECTION_REFUSED

### 대응

```bash
# 죽은 dev 서버 깨끗이 청소
kill -9 $(lsof -ti:5173 2>/dev/null) 2>/dev/null

# dev 서버 재시작 (워커 살아있는 상태)
lsof -ti:5173 2>&1 | head -3  # 깨끗한지 확인
# → background=true 로 vite 띄움
```

### 예방

- 매 워커 spawn 마다 dev 서버 PID 기록해두고, 알림 오면 즉시 재시작
- 또는 **dev 서버를 띄우지 않고 워커 작업 결과만 git commit 으로 받고, 브라우저 검증은 사용자 측에서 필요할 때만** 띄움 (운영 노이즈 최소화)
- 30분 안에 dev 서버 죽어도 사용자가 한 번도 안 보면 그냥 두는 게 효율적

## 3. 워커 SIGTERM 직전 commit (함정 17) — 종료 시와 별개

Phase 1.2 워커 SIGTERM 30초 직전에 자기 commit 완료했음. 종료 처리 시 워커 SIGTERM 보내는 시점은:

- ✅ 사용자가 명시적으로 "워커 정지" 신호 보낸 경우 OK
- ⚠️ 종료 신호 후 추가 cleanup 명목으로 보내는 건 안 됨 (사용자 분노 패턴)

종료 신호 후 워커를 죽일 때는 **현재 작업물 손실 감수** OK (워커가 commit 안 했으면 사용자 디렉터리에 박힌 거만 보존, scratch 면 손실). 사용자가 "Phase 1.3 마무리" 같은 신호를 다음 세션에 보낼 거임.

## 4. 프로젝트 종료 vs 단순 세션 종료 구분

| 사용자 신호 | 의미 | 운영자 행동 |
|---|---|---|
| "그만" / "STOP" / "종료" / "마무리" | 이 세션 끝 | 즉시 cleanup + 5줄 보고 |
| "프로젝트 종료" / "다른 방향" | 프로젝트 자체 끝 | cleanup + 프로젝트 산출물 보존 + 다음 프로젝트 시작 대기 |
| "워커 정지" | 워커만 멈춤 | SIGTERM + 처리 안 한 카드 archive / 운영자 직접 commit |
| "Phase X 종료" | 특정 단계 끝 | 다음 단계 dispatch 대기 |

**사용자가 어느 신호를 보냈는지 정확히 식별** — 잘못 매칭하면 "종료"인데 추가 작업하거나, "워커 정지"인데 워커만 죽이고 끝내면 사용자 의도와 어긋남.