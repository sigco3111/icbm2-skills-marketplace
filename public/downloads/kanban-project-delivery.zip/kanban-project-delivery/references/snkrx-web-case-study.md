# snkrx-web 픽스처 케이스 스터디 (2026-07-22~23)

이 문서는 `kanban-project-delivery` SKILL.md의 모든 패턴이 실제로 어떻게 작동했는지를 보여주는 실측 사례 모음. SKILL.md 본문이 "이런 패턴을 써라"라면, 이 문서는 "이 상황에서 정확히 이렇게 됐다"의 컨크리트 레코드.

## 보드 구성

- Board slug: `snkrx-web`
- Profile: `default` (단일 프로필)
- 작업 경로: `/Users/mac/work/snkrx-web`
- GitHub: `sigco3111/snkrx-web`

8장의 초기 카드 (의존성 체인):

```text
원본 실행 기준선 확보 → PixiJS 스캐폴딩 → DPR 처리 → 폰트 로딩 → 이미지 로딩
→ 정지 전투 장면 재현 → 첫 렌더링 Playtest → 첫 전투 프로토타입 계획
```

## 실제 진행 타임라인

| 카드 | 시작 → 끝 | 결과 |
|---|---|---|
| 원본 실행 기준선 확보 | 09:25 → 09:32 | done (자체) |
| PixiJS 웹 스캐폴딩 | 09:38 → 09:58 (21분) | review-required (스스로) |
| 논리 해상도와 DPR | 09:42 → 09:44 (2분) | review-required (스스로) |
| 원본 폰트 로딩 | 09:47 → 09:54 (7분) | review-required (스스로) |
| 원본 이미지 로딩 | 09:29 (timed_out 15분) → 09:44 (재시도 4분) | review-required → 완료 |
| 정지 전투 장면 재현 | 09:49 → 1시간+ | **stuck (worker hang)** |
| 첫 렌더링 Playtest | 11:21 → review-required | 사용자 시각 검증 단계 |

## 1번 사례 — 정지 전투 장면 1시간+ hang

### 무엇이 잘못됐나

작업자가 단일 카드로 "배경 + 별 + 뱀 + 영웅 배치 + 적 4종 + HP바 + 파티클 + UI + 원본 비교"를 한 번에 구현하려 했다. 작업자 로그에서 본 패턴:

```text
patch src/assets.ts × 5회 (같은 파일을 5번 고침)
npx tsc --noEmit × 5회 (tsc 통과/실패 반복)
patch src/screens/staticBattle.ts × 4회
npm run build → 통과
npm run dev | tee /tmp/snkrx-dev.log &  ← 여기서 hang
```

마지막 단계의 background shell wrapper (`npm run dev | tee ... &`)가 종료하지 않아 worker가 forever running 상태. 작업자 process는 살아 있지만 (`PID 34853`, %CPU 1.0), 진척 0.

### 47분 시점에 무엇을 했나

SKILL.md의 "Stuck-worker recovery" 절차 적용:

1. `hermes kanban show t_7c252d77 --json` — `status: running`, `outcome: null`, elapsed 47분, last heartbeat 21분 전 → 확인
2. `git status --short` — 작업자의 변경이 디스크에는 있으나 commit 없음
3. `tail -60 /Users/mac/.hermes/kanban/boards/snkrx-web/logs/t_7c252d77.log` — `npm run dev | tee /tmp/snkrx-dev.log & sleep 4 ...` 명령이 hang
4. `hermes kanban reclaim t_7c252d77` → "not running or unknown id" (reclaim 실패, worker는 PID는 있지만 dispatcher 입장에서 reclaim 대상이 아닌 상태였음)
5. 보드 상태를 `archive`로 닫고 의존성 그래프 정리

### 5장 분할 (Decomposition-time classification 적용)

```text
v1 정지 전투 화면: 좌표·코어 데이터 (P: 원본 이미지 로딩 완료 후)
v2 정지 전투 화면: 빌드 가능한 화면 골격
v3 정지 전투 화면: 뱀(snake) 본체와 영웅 위치
v4 정지 전투 화면: 적·투사체·HP바·파티클
v5 정지 전투 화면: UI 골격과 비교 스크린샷
```

v1 카드 본문에 명시적으로 적어둔 완료 규칙:

> "완성 시 TDD로 단위 테스트 통과 및 docs/STATIC_BATTLE_COORDS.md 작성." (auto-verifiable)

> "auto-verifiable 카드. unit test + build 통과 후 kanban_complete 직접 호출. review-required로 block 금지."

이건 SKILL.md의 "Decomposition-time classification" 섹션의 약속을 카드 body에 박은 형태.

## 2번 사례 — 시각 검증에서 placeholder만 보임

### 사용자 시각 검증 결과

사용자가 http://127.0.0.1:5173/ (이후 5175로 자동 fallback) 브라우저 캡처:

```text
좌상단 텍스트: "PixiJS 초기화 중..."
나머지: 흰 배경
캔버스: 보이지 않음
게임 요소: 0개
```

### 의미

이건 단순한 "빌드 실패"가 아니라 **placeholder 코드**가 출력되고 있다는 신호. 작업자가 `mountStaticBattleScene()`을 호출하기 전에 텍스트만 띄우는 early return 경로가 화면에 잡혔던 것. 이 시각 검증이 SKILL.md의 "Playtest 게이트"가 작동한 사례 — npm run build 성공과 실제 게임 화면은 별개라는 원칙을 사용자가 직접 확인한 순간.

### 대응

```text
A. 현재 상태 정리 (변경 폐기, 가장 단순한 화면부터 다시)
B. 현재 변경 유지, 캔버스에 텍스처 보이는 다음 카드로
C. 처음부터 다른 방식 (배경 + 정사각형 + 영웅 한 명 + 적 한 명만 표시)
```

사용자가 C 선택. 이때 분할한 4장 카드를 새로 등록했는데, 그 과정에서 **두 가지 CLI 함정**을 만남:

### 함정 A — `kanban link` 인자 순서

내가 처음에 호출한 형태:

```bash
hermes kanban link --parent t_580aa3df --child t_50df70b6  # ❌ --parent/--child 플래그 없음
hermes kanban link t_50df70b6 t_580aa3df  # ❌ 거꾸로 (parent 먼저, child 다음)
```

올바른 형태:

```bash
hermes kanban link t_580aa3df t_50df70b6  # parent 먼저, child 다음
```

거꾸로 등록한 결과 4장의 카드가 dispatcher에 의해 동시에 Running 됨. `reclaim` + `archive`로 정리하고 다시 link.

### 함정 B — 잘못된 그래프에서 동시에 Running 됨

```text
t_580aa3df (v1) 의 parents에 t_50df70b6 (v2), t_1cd01c4b (v3) 이 들어가버림
→ dispatcher가 v2/v3을 parent로 해석
→ v2/v3/v4 모두 ready로 인식되어 동시에 spawn
```

복구:

```bash
# 잘못된 링크 제거
hermes kanban unlink t_50df70b6 t_580aa3df
hermes kanban unlink t_1cd01c4b t_580aa3df
# 올바른 링크
hermes kanban link t_580aa3df t_50df70b6
hermes kanban link t_580aa3df t_1cd01c4b
hermes kanban link t_50df70b6 t_7da70bb5
hermes kanban link t_1cd01c4b t_7da70bb5
# 잘못 동시에 Running 된 v2/v3/v4 중단
hermes kanban reclaim t_50df70b6 --reason '의존성 역행으로 잘못 동시 실행'
hermes kanban reclaim t_1cd01c4b --reason '의존성 역행으로 잘못 동시 실행'
hermes kanban reclaim t_7da70bb5 --reason '의존성 역행으로 잘못 동시 실행'
```

이 두 함정은 SKILL.md의 `references/kanban-cli-gotchas.md`에 함정 5로 추가됨.

## 3번 사례 — 알림 정책: "진척이 없는 것 같은데?" 사용자 질문

### 무엇이 일어났나

```text
t_574f769c (PixiJS 스캐폴딩): review-required
→ 운영자가 검증 후 complete
→ t_6cac860a 자동 실행 → review-required
→ 운영자가 검증 후 complete
→ t_8cd5743e 자동 실행 → review-required
→ 운영자가 검증 후 complete
→ t_42da79f4 자동 실행 → review-required
→ 운영자가 검증 후 complete
```

매 카드마다 Telegram 알림이 와서 "작업 끝났습니다, 다음 진행합니다" 메시지를 사용자에게 보냈고, 사용자는 "진척이 없는 것 같은데? 무슨 문제 있나?" 라고 묻게 됨. 자동 검증 카드의 완료는 사용자 입장에선 알릴 일이 아니었음.

### 학습

SKILL.md 본문과 `references/review-required-and-notifications.md`에 이미 selective notification 패턴이 문서화되어 있었지만, 이 세션에서 처음 카드 8장에 일괄 구독을 걸었던 게 실수. 시각 검증 카드 (정지 전투 장면, Playtest, 첫 전투 계획) 3장만 구독했어야 했다.

```text
A. 추천 방식: 시각 검증 3장만 알림  ← 선택해야 하는 것
B. 매 작업마다 알림
C. 알림 끄기, 대시보드만 확인
```

## SKILL.md 패턴별 실제 작동 검증 매트릭스

| SKILL.md 섹션 | snkrx-web에서의 작동 여부 |
|---|---|
| 기본 원칙 1: `done`은 검증된 결과 | ✅ 작동 — 작업자 보고만으로 Done 처리 안 함 |
| 기본 원칙 2: 의존성은 카드 생성 시 부모로 선언 | ⚠️ 부분 — 분할 카드에서 부모 미선언 후 link 시도, 거꾸로 등록 → 함수 교훈 |
| 기본 원칙 3: 자동 진행과 사람 검토를 분리 | ✅ 작동 — visual 검증 카드만 멈춤 |
| 기본 원칙 4: 오케스트레이터가 최종 소유자 | ✅ 작동 — 운영자가 reclaim+complete |
| 기본 원칙 5: 알림은 terminal event 중심 | ⚠️ 부분 — 초기 8장 일괄 구독으로 알림 폭주 |
| Decomposition-time classification | ✅ 작동 — v1~v5 카드 body에 명시 |
| Stuck-worker recovery | ✅ 작동 — 1시간+ hang 카드 archive + 분할 |
| Playtest 게이트 (사용자 검증) | ✅ 작동 — placeholder 화면 발견 → 분할 결정 |
| Selective notification | ⚠️ 보완 — 첫 시도 실패 후 사용자가 명시적으로 "시각 검증 카드만" 요청 |

## 보완 제안 (다음 프로젝트에서)

1. **분할 카드 등록은 한 번에 끝내지 말고 부모 → ready → 작업 시작을 한 카드씩 검증하면서 진행.** 처음에 4장 동시 등록 + link 시도하다가 그래프 오류 + 동시 실행 함정에 빠짐.
2. **시각 검증 카드 수동 dispatch 패턴**: `kanban create --initial-status blocked`로 처음부터 blocked 등록 → 운영자가 unblock 후 진행. 이렇게 하면 dispatcher가 작업자 실행시키는 일을 막을 수 있어 더 안전.
3. **background shell wrapper 사용 금지** (snkrx-clone의 build_all.sh와 같은 패턴). worker 카드 body에 "foreground-only, 백그라운드 래퍼 금지"를 명시적으로 적을 것.

## 관련 파일/로그

- 보드 DB: `/Users/mac/.hermes/kanban/boards/snkrx-web/kanban.db`
- 작업자 로그: `/Users/mac/.hermes/kanban/boards/snkrx-web/logs/`
- GitHub: https://github.com/sigco3111/snkrx-web
- 작업 경로: `/Users/mac/work/snkrx-web`