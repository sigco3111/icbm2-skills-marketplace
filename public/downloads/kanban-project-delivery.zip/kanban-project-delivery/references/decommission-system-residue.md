# 카드 폐기 (decommission) 시 시스템 잔여물 정리

카드 1장을 archive하는 것과 **시스템 상태를 카드 생성 이전으로 되돌리는 것**은 다른 작업이다. 사용자가 "폐기" / "취소" / "버려" 라고 말할 때는 후자를 기대한다. `archive` 한 줄로 끝냈다는 보고는 부실하다.

## 폐기 시 점검할 5개 영역

| 영역 | 점검 | 정리 |
|---|---|---|
| cron 잡 | `jq '.jobs[] \| select(.id == "<id-from-body>")' ~/.hermes/cron/jobs.json` | `hermes cron remove <id>` |
| 스킬/SKILL.md 섹션 | `grep -n "<고유키워드>" ~/.hermes/skills/.../SKILL.md` | 정확한 anchor로 `patch` (skill_manage action=patch) |
| /tmp 산출물 | `ls /tmp/<prefix>-*` | `rm /tmp/<prefix>-*` |
| 워크스페이스 디렉토리 | `ls ~/.hermes/kanban/boards/<slug>/workspaces/<task_id>/` | 자동 정리되지만 잔여 확인 |
| 등록된 토큰/credentials | `grep -r "<scope-keyword>" ~/.hermes/secrets/` | 사용자 판단 (자동 삭제 ❌) |

## 실측 사례 (2026-07-24 sigco3111 gitfut-scout)

### 시나리오

- 보드: `gitfut-scout`
- 폐기 대상 카드: `t_e1cf4a7f` (Card 4: Tistory 큐레이터 / weekly-tech-digest sigco 채널로 확장)
- 사용자 메시지: "콘텐츠 발행 자동화 폐기"
- 운영자 첫 행동: `hermes kanban archive t_e1cf4a7f` → "archive 했어요" 한 줄 보고
- 사용자 추적: "정말 폐기 처리됐나?"

### 점검 결과 — 두 군데 잔여

1. **cron 잡** `7995f1387b79` ("📰 sigco 주간 기술 큐레이션") — `~/.hermes/cron/jobs.json`에 여전히 active
   - 다음 자동 실행: 2026-07-26 16:00 KST (폐기 의도와 정면 충돌)
2. **SKILL.md 섹션** — `~/.hermes/skills/automation/weekly-tech-digest/SKILL.md` 라인 17~40
   - 헤더: `## sigco 개인 채널 톤`
   - 내용: 제목 기본형, 첫 문장 기본형, 1인칭 톤 규칙, 발행 승인 게이트 등 24줄
   - 시스템 잔여 0 검증: `grep -c "sigco 개인" SKILL.md` → 0이 되어야 정답

### 정리 절차

```bash
# 1. cron 잡 제거
hermes cron remove 7995f1387b79
# → Removed job: 📰 sigco 주간 기술 큐레이션 (7995f1387b79)

# 2. SKILL.md 섹션 patch (skill_manage action=patch 사용)
# - old_string: "## sigco 개인 채널 톤\n\n[24줄 본문]\n\n## 파이프라인"
# - new_string: "## 파이프라인"

# 3. 잔여 검증
grep -c "sigco 개인" ~/.hermes/skills/automation/weekly-tech-digest/SKILL.md
# 기대값: 0
jq '.jobs | map(select(.id == "7995f1387b79")) | length' ~/.hermes/cron/jobs.json
# 기대값: 0
```

### 최종 보고 (정직한 3축)

```
✅ Card 4 폐기 완료
- (a) 보드: t_e1cf4a7f archived
- (b) cron: 7995f1387b79 removed
- (c) SKILL.md: 라인 17~40 (24줄) reverted, 잔여 grep 0건
- 다른 카드/산출물 영향 없음
```

## 폐기 자동 점검 스크립트

카드 body에 cron id / 파일 경로 / 외부 리소스 id가 있을 때, archive 전에 한 번에 점검:

```bash
# 1. body 추출
CARD_BODY=$(hermes kanban --board <slug> show <id> --json | jq -r '.body')

# 2. cron id 추출 (12자 hex)
CRON_IDS=$(echo "$CARD_BODY" | grep -oE '[a-f0-9]{12}' | sort -u)

# 3. 파일 경로 추출
FILES=$(echo "$CARD_BODY" | grep -oE '~/.hermes/[^ ]+' | sort -u)

echo "===== 점검할 cron 잡 ====="
for cid in $CRON_IDS; do
  echo "  - $cid: $(jq -r ".jobs[] | select(.id == \"$cid\") | .name" ~/.hermes/cron/jobs.json 2>/dev/null || echo 'NOT FOUND')"
done

echo "===== 점검할 파일 ====="
for f in $FILES; do
  if [ -f "$f" ]; then
    HITS=$(grep -c "<card-specific-keyword>" "$f" 2>/dev/null || echo 0)
    echo "  - $f: $HITS hit(s)"
  fi
done
```

`hits != 0` 인 파일이 있으면 archive 전에 patch로 정리. archive는 **모든 잔여 정리가 끝난 후 마지막에**.

## 흔한 부실 보고 패턴 (★ 안티패턴)

| 안티패턴 | 부실 이유 |
|---|---|
| "Card N이 archived 됐어요" | 시스템 잔여 0 보장 안 됨 |
| "폐기 처리 완료" | 무엇이 어디까지 됐는지 불분명 |
| "더 이상 실행 안 됨" (cron 안 지운 상태) | 다음 시각 cron 자동 재발 |
| "원래대로 됐어요" (SKILL.md 안 지운 상태) | 다음 스킬 로드 시 죽은 섹션 노출 |

**정답**: 산출물 3축 (보드 + cron + 문서) 명시 + 잔여 grep 결과 0.

## 관련

- SKILL.md 본문 "사용자 카드 상한 (★ 2026-07-24 신규 — 카드 등록 over-step 사고)" — 위임 시 5장 일괄 등록 over-step도 같은 사고 패턴
- `kanban-cli-gotchas.md` 함정 4 (unblock ≠ 승인), 함정 6 (archive 후 block 거부)
