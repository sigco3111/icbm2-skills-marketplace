# `hermes kanban` CLI 추가 함정 (2026-07-24 이후)

`references/kanban-cli-gotchas.md`에 미처 못 담은 v0.19.0 이후 발견된 함정. 본 파일이 더 정제되면 본문으로 통합 예정.

## 함정 10 — `--initial-status`는 `blocked`/`running`만, `todo` 없음 (2026-07-24 실측)

`hermes kanban create ... --initial-status todo`를 기대하는 사람이 많지만 실제 옵션은 두 개뿐:

```bash
$ hermes kanban create --help | grep -A2 initial-status
  --initial-status {blocked,running}   # ← todo 없음
```

`todo` 상태로 시작하는 방법은 **부모 카드가 이미 존재하고 그게 done 이어야** 자동 생성됨. 또는 `--initial-status`를 빼면 default = `ready` (dispatcher가 곧바로 잡아감).

**실측 (snkrx-web Phase 5-9 카드 등록)**:
```bash
# ❌ todo 직접 시작 — 에러
hermes kanban create "Phase 5-9: ..." --initial-status todo --body "..." --parent t_63cf5ab9
# → hermes kanban create: error: argument --initial-status: invalid choice: 'todo'

# ✅ default (ready) + parent link → 부모 done 시 자동 ready
hermes kanban create "Phase 5-9: ..." --parent t_63cf5ab9 --body "..." --json
# → status: ready (dispatcher가 곧바로 spawn)
```

**회피 패턴 3가지**:
1. **부모 카드(done/archived) → 자식 카드(ready 자동)** — `--initial-status` 빼고 `--parent`만.
2. **수동 blocked 시작** — `--initial-status blocked`로 등록, 운영자가 `unblock`으로 풀어야 dispatcher가 잡음. 시각 검증 카드나 보류 카드를 명시적으로 멈춰둘 때 유용.
3. **수동 running 시작** — `--initial-status running`은 dispatcher 우회. 권장 안 함 (claim/heartbeat 흐름 깨짐).

**운영상 함정**: 부모 done 카드 → 자식 ready 카드는 **dispatcher가 자동 spawn**한다. 사용자에게 "5장 다 자동으로 시작했어요" 알림 폭주 방지를 위해 `selective notification` (시각 검증 카드만 구독) + 카드 body의 `[DECOMPOSITION-TIME: auto-verifiable]` 표시가 중요.

## 함정 11 — 사용자 "OK" 한 단어 신호 = 일괄 후속 작업 (2026-07-24 실측)

`kanban-project-delivery` SKILL.md 본문의 "위임 1장, 일괄 dispatch X" 정책과 별개로, **사용자 검증 완료 신호 한 번**에 묶음으로 후속 작업 진행이 효율적인 케이스가 있다.

**시나리오 (snkrx-web Phase 5-8)**:
1. 사용자가 브라우저로 시각 검증
2. "ok" 한 단어 회신
3. 운영자가 묶음 실행: `git add/commit/push` + `kanban complete` + `kanban create (후속)` + `dispatch`
4. **이 묶음을 사용자에게 미리 announce 해둠**: 이전 턴에 "확인 후 OK 신호 주면 (a) commit + main push (b) t_63cf5ab9 complete (c) 후속 카드 1장 등록 + dispatch" 라고 4옵션 + 추천으로 제시
5. 사용자 OK → 묶음 실행 → **결과만 짧게 보고** (5장 다 자동 시작했어요 같은 안내 금지)

**핵심**:
- 묶음 실행 **전에** 무엇을 묶을지 명확히 enumerate
- 4옵션 + 추천 1개로 사용자 의사결정 시간 최소화
- 실행 후에는 stats/commit hash/다음 ready 카드 ID 같은 **machine-verified facts**만 보고
- "진행 중" 같은 추측성 표현 금지 (memory "솔직한 보고 패턴"과 일치)

## 함정 12 — 비대화 환경에서 73줄+ multi-line body는 heredoc 필수 (2026-07-24 실측)

`--body` 플래그에 multi-line 텍스트를 shell-quote로 넘기면 작은따옴표 escape 함정에 빠짐. 큰따옴표 안에 backtick / `$` 가 들어가면 명령 치환됨.

**올바른 패턴**:
```bash
# 패턴 A — heredoc → cat → $(...)
cat > /tmp/card_body.txt << 'EOF'
[DO NOT SPECIFY/DECOMPOSE] ...
...
EOF
hermes kanban create "..." --body "$(cat /tmp/card_body.txt)" --json

# 패턴 B — python3 -c 로 안전하게
python3 -c "
import subprocess, json
body = '''[DO NOT SPECIFY/DECOMPOSE]
... 멀티라인 ...
'''
result = subprocess.run(['hermes', 'kanban', 'create', 'Phase 5-9', '--body', body, '--json'], capture_output=True, text=True)
print(result.stdout)
"
```

`'EOF'` (single-quoted heredoc) 가 핵심 — 안에 `$VAR`나 `` `cmd` `` 있어도 확장 안 됨. plain `EOF` 는 shell expansion 함정.
