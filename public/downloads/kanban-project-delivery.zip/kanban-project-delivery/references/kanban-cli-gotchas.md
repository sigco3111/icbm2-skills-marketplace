# `hermes kanban` CLI 운영 시 만나는 함정

Hermes Kanban 보드 작업을 자동화할 때 자주 만나는 CLI 함정 모음. 본문 SKILL.md의 운영 흐름을 따라가다 보면 결국 한두 번은 만나는 것들이므로 처음부터 회피 패턴을 박아두는 게 효율적.

## 함정 1 — `create --json` 응답 키는 `task_id`가 아니라 `id`

`hermes kanban create <title> ... --json`의 출력:

```json
{
  "id": "t_xxxxxxxx",
  "title": "...",
  "body": "...",
  "assignee": "default",
  "status": "todo",
  ...
}
```

`task_id` 필드 없음. 코드에서 `data['task_id']`로 받으면 `KeyError`. **반드시 `data['id']`로 받을 것.**

잘못된 예:

```python
ids = []
for title, body in cards:
    p = subprocess.run(
        ['hermes', 'kanban', 'create', title, '--body', body, '--json'],
        capture_output=True, text=True)
    ids.append(json.loads(p.stdout)['task_id'])   # KeyError: 'task_id'
```

올바른 예:

```python
ids.append(json.loads(p.stdout)['id'])
```

## 함정 2 — `block`은 `--reason` 플래그가 없음, reason은 positional

`hermes kanban block <task_id> --reason "..."` 형태로 쓰면 `unrecognized arguments` 에러가 난다. 정해진 시그니처는:

```bash
hermes kanban block <task_id> [reason ...]
hermes kanban block <task_id> --kind {capability,dependency,needs_input,transient} [reason ...]
```

잘못된 예:

```bash
hermes kanban block t_123 --reason "stuck 47 min, splitting into smaller cards"
# → usage: hermes [...]; error: unrecognized arguments: --reason
```

올바른 예:

```bash
hermes kanban block t_123 --kind dependency 'stuck 47 min, splitting into smaller cards'
hermes kanban block t_123 'stuck 47 min, splitting into smaller cards'
```

`--kind`를 생략하면 generic `blocked`가 된다. 시각 검증 대기는 `needs_input`, 작업자 의존성은 `dependency`, 일시적 실패는 `transient`.

## 함정 3 — Python `subprocess`로 띄울 때 글로벌 argv prefix가 끼어들 수 있음

`hermes` 글로벌 CLI는 환경에 따라 `--yolo`, `--accept-hooks`, `--ignore-rules` 같은 prefix 인자를 argv 앞에 자동 추가하는 경우가 있다. 이 상태에서 Python `subprocess.run(['hermes', 'kanban', 'block', id, '--reason', '...'])`로 띄우면, `hermes` 메인이 prefix를 먼저 소비하고 `--reason`이 남은 위치 인자 처리 단계에서 깨질 수 있다.

증상:

```text
usage: hermes [-h] [--version] [-z PROMPT] [--usage-file PATH] ...
              [--yolo] [--pass-session-id]
              [--ignore-user-config] [--ignore-rules] [--safe-mode] [--tui]
              [--cli] [--dev]
              {chat,model,moa,fallback,...}
              ...
hermes: error: unrecognized arguments: --reason <text>
```

회피:

1. **가능하면 `terminal()` 도구나 dispatch 경로(`hermes kanban --board <slug> dispatch --max 1 --json`)로 우회.** 이 경로들은 prefix argv를 알고 있다.
2. 또는 `hermes` 인자 직전에 `--` separator를 넣어 prefix 흡수를 끊기.
3. 또는 셸에서 `hermes`가 prefix argv를 추가하지 않는 상태(예: 일반 `hermes` CLI 비대화형 호출)를 확인하고 그때만 `subprocess` 사용.

## 함정 4 — `unblock`은 worker를 재실행시키는 거지, 승인이 아님

`unblock`은 `blocked` 카드를 `ready`로 되돌린다. **그러면 dispatcher가 곧장 worker를 새로 띄운다.** 작업자가 또 같은 `review-required`를 반복하면 무한 루프.

승인 완료 절차는:

```bash
# 1. 산출물 확인 (git, build, log)
hermes kanban --board <slug> show <id> --json
hermes kanban --board <slug> log <id> --tail 2000

# 2. (선택) reclaim — worker가 떠있으면 중단, 떠있지 않으면 no-op
hermes kanban --board <slug> reclaim <id> --reason "operator confirming review-required handoff"

# 3. 운영자가 직접 complete — metadata.reviewed_by 마커
hermes kanban --board <slug> complete <id> \
  --summary "<one-line>" \
  --metadata '{"changed_files":[...], "tests_run":N, "reviewed_by":"operator"}'

# 4. 다음 카드 자동 안 되면 수동 dispatch
hermes kanban --board <slug> dispatch --max 1 --json
```

`unblock`을 "내가 봤으니 OK"의 의미로 쓰지 말 것.

## 함정 5 — `kanban link` 인자 순서는 positional `parent_id child_id` (--parent / --child 플래그 없음)

`hermes kanban link <parent_id> <child_id>`만 지원. `--parent <p> --child <c>` 형태는 없음. 거꾸로 넘기면 dependency graph가 뒤집힌 채 저장된다.

실측 사례 (2026-07-23 snkrx-web v1 분할):

```bash
# 잘못된 예 — v1의 자식이 v2/v3인데 v2/v3의 자식으로 등록됨
hermes kanban link t_50df70b6 t_580aa3df  # → "Linked t_50df70b6 -> t_580aa3df"
hermes kanban link t_1cd01c4b t_580aa3df
# 결과: t_580aa3df의 parents가 [t_50df70b6, t_1cd01c4b]가 되어버림
# 즉 "v2, v3이 끝나야 v1 실행" 이라는 역행 그래프
```

회피:

1. `hermes kanban link --help`로 시그니처를 먼저 확인.
2. 다중 카드 link는 항상 부모를 먼저 적은 후 자식 — 코멘트로 의도 적어두기.
3. 그래프 검증: 링크 직후 `hermes kanban show <child-id> --json`에서 `parents` 필드를 한 번 확인.

실수했을 때 정리:

```bash
# 잘못된 링크 제거 후 정정
hermes kanban unlink <wrong-parent> <child>
hermes kanban link <correct-parent> <child>
```

추가 함정: 링크 작업 **이후에** dispatcher가 이미 잘못된 그래프를 보고 child 카드들을 동시에 Running으로 띄울 수 있다 (snkrx-web 실측 — 4장이 동시에 Running 됨). 그 경우 잘못 Running된 child를 `reclaim` + `archive` (또는 명시적 unblock 후 dependency 다시 선언)로 정리한다.

## 함정 6 — `hermes kanban archive` 후 `block`은 거부

이미 `archive`된 카드는 더 이상 `block` / `complete` / `unblock` 불가. 부모 카드를 `archive`한 뒤 자식 카드를 새로 등록할 때, 자식 카드의 `--parent`는 부모 archived 카드 id를 그대로 써도 동작한다 (archive가 dependency graph를 보존). 즉:

```bash
hermes kanban --board <slug> archive <parent-id>  # 부모 카드 닫기
# 자식 카드는 새 parent를 archive된 부모 id로
hermes kanban create <child-title> --parent <archived-parent-id> ...
```

이렇게 하면 자식 카드는 부모 done 상태의 자리에 archive 완료가 dependency로 들어가서 정상 진행된다.

## 함정 6 — 카드 알림은 소급되지 않는다

`hermes kanban notify-subscribe`는 미래 terminal event만 받는다. 카드가 이미 `done`이 된 뒤에 구독을 걸어도 그 카드의 완료 알림은 오지 않는다.

장기 프로젝트에서는 분해 직후 + 카드 등록 직후에 바로 구독을 거는 게 좋다. 또는 운영자가 직접 `notify-list`로 어떤 카드가 구독돼 있는지 확인한다.

## 함수 한 줄 — 자주 같이 쓰이는 조합

```bash
# 작업자가 review-required로 멈췄을 때 운영자가 검증 후 승인
hermes kanban --board <slug> show <id> --json | jq '.task, .latest_summary, .runs[-1].summary'
git -C <workdir> status --short --branch
git -C <workdir> log -3 --oneline
npm run build
npm run dev -- --host 127.0.0.1   # 또는 백그라운드+curl
hermes kanban --board <slug> reclaim <id> --reason "operator confirming review-required handoff" || true
hermes kanban --board <slug> complete <id> --summary "..." --metadata '{"changed_files":[...], "reviewed_by":"operator"}'
hermes kanban --board <slug> dispatch --max 1 --json
```

`reclaim`이 실패해도 (worker가 이미 종료된 경우 no-op) 다음 단계는 정상 동작해야 한다.