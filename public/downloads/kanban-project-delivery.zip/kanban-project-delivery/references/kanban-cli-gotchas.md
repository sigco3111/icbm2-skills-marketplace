# `hermes kanban` CLI 운영 시 만나는 함정

Hermes Kanban 보드 작업을 자동화할 때 자주 만나는 CLI 함정 모음. 본문 SKILL.md의 운영 흐름을 따라가다 보면 결국 한두 번은 만나는 것들이므로 처음부터 회피 패턴을 박아두는 게 효율적.

## 함정 1 — `create --json` 응답 키는 `task_id`가 아니라 `id`

`hermes kanban create <title> ... --json`의 출력:

```json
{
  "id": "t_xxxxxxxx",
  "title": "...",
  "body": "...",
  "assignee": "default",
  "status": "todo",
  ...
}
```

`task_id` 필드 없음. 코드에서 `data['task_id']`로 받으면 `KeyError`. **반드시 `data['id']`로 받을 것.**

잘못된 예:

```python
ids = []
for title, body in cards:
    p = subprocess.run(
        ['hermes', 'kanban', 'create', title, '--body', body, '--json'],
        capture_output=True, text=True)
    ids.append(json.loads(p.stdout)['task_id'])   # KeyError: 'task_id'
```

올바른 예:

```python
ids.append(json.loads(p.stdout)['id'])
```

## 함정 2 — `block`은 `--reason` 플래그가 없음, reason은 positional

`hermes kanban block <task_id> --reason "..."` 형태로 쓰면 `unrecognized arguments` 에러가 난다. 정해진 시그니처는:

```bash
hermes kanban block <task_id> [reason ...]
hermes kanban block <task_id> --kind {capability,dependency,needs_input,transient} [reason ...]
```

잘못된 예:

```bash
hermes kanban block t_123 --reason "stuck 47 min, splitting into smaller cards"
# → usage: hermes [...]; error: unrecognized arguments: --reason
```

올바른 예:

```bash
hermes kanban block t_123 --kind dependency 'stuck 47 min, splitting into smaller cards'
hermes kanban block t_123 'stuck 47 min, splitting into smaller cards'
```

`--kind`를 생략하면 generic `blocked`가 된다. 시각 검증 대기는 `needs_input`, 작업자 의존성은 `dependency`, 일시적 실패는 `transient`.

## 함정 3 — Python `subprocess`로 띄울 때 글로벌 argv prefix가 끼어들 수 있음

`hermes` 글로벌 CLI는 환경에 따라 `--yolo`, `--accept-hooks`, `--ignore-rules` 같은 prefix 인자를 argv 앞에 자동 추가하는 경우가 있다. 이 상태에서 Python `subprocess.run(['hermes', 'kanban', 'block', id, '--reason', '...'])`로 띄우면, `hermes` 메인이 prefix를 먼저 소비하고 `--reason`이 남은 위치 인자 처리 단계에서 깨질 수 있다.

증상:

```text
usage: hermes [-h] [--version] [-z PROMPT] [--usage-file PATH] ...
              [--yolo] [--pass-session-id]
              [--ignore-user-config] [--ignore-rules] [--safe-mode] [--tui]
              [--cli] [--dev]
              {chat,model,moa,fallback,...}
              ...
hermes: error: unrecognized arguments: --reason <text>
```

회피:

1. **가능하면 `terminal()` 도구나 dispatch 경로(`hermes kanban --board <slug> dispatch --max 1 --json`)로 우회.** 이 경로들은 prefix argv를 알고 있다.
2. 또는 `hermes` 인자 직전에 `--` separator를 넣어 prefix 흡수를 끊기.
3. 또는 셸에서 `hermes`가 prefix argv를 추가하지 않는 상태(예: 일반 `hermes` CLI 비대화형 호출)를 확인하고 그때만 `subprocess` 사용.

## 함정 4 — `unblock`은 worker를 재실행시키는 거지, 승인이 아님

`unblock`은 `blocked` 카드를 `ready`로 되돌린다. **그러면 dispatcher가 곧장 worker를 새로 띄운다.** 작업자가 또 같은 `review-required`를 반복하면 무한 루프.

승인 완료 절차는:

```bash
# 1. 산출물 확인 (git, build, log)
hermes kanban --board <slug> show <id> --json
hermes kanban --board <slug> log <id> --tail 2000

# 2. (선택) reclaim — worker가 떠있으면 중단, 떠있지 않으면 no-op
hermes kanban --board <slug> reclaim <id> --reason "operator confirming review-required handoff"

# 3. 운영자가 직접 complete — metadata.reviewed_by 마커
hermes kanban --board <slug> complete <id> \
  --summary "<one-line>" \
  --metadata '{"changed_files":[...], "tests_run":N, "reviewed_by":"operator"}'

# 4. 다음 카드 자동 안 되면 수동 dispatch
hermes kanban --board <slug> dispatch --max 1 --json
```

`unblock`을 "내가 봤으니 OK"의 의미로 쓰지 말 것.

## 함정 5 — `kanban link` 인자 순서는 positional `parent_id child_id` (--parent / --child 플래그 없음)

`hermes kanban link <parent_id> <child_id>`만 지원. `--parent <p> --child <c>` 형태는 없음. 거꾸로 넘기면 dependency graph가 뒤집힌 채 저장된다.

실측 사례 (2026-07-23 snkrx-web v1 분할):

```bash
# 잘못된 예 — v1의 자식이 v2/v3인데 v2/v3의 자식으로 등록됨
hermes kanban link t_50df70b6 t_580aa3df  # → "Linked t_50df70b6 -> t_580aa3df"
hermes kanban link t_1cd01c4b t_580aa3df
# 결과: t_580aa3df의 parents가 [t_50df70b6, t_1cd01c4b]가 되어버림
# 즉 "v2, v3이 끝나야 v1 실행" 이라는 역행 그래프
```

회피:

1. `hermes kanban link --help`로 시그니처를 먼저 확인.
2. 다중 카드 link는 항상 부모를 먼저 적은 후 자식 — 코멘트로 의도 적어두기.
3. 그래프 검증: 링크 직후 `hermes kanban show <child-id> --json`에서 `parents` 필드를 한 번 확인.

실수했을 때 정리:

```bash
# 잘못된 링크 제거 후 정정
hermes kanban unlink <wrong-parent> <child>
hermes kanban link <correct-parent> <child>
```

추가 함정: 링크 작업 **이후에** dispatcher가 이미 잘못된 그래프를 보고 child 카드들을 동시에 Running으로 띄울 수 있다 (snkrx-web 실측 — 4장이 동시에 Running 됨). 그 경우 잘못 Running된 child를 `reclaim` + `archive` (또는 명시적 unblock 후 dependency 다시 선언)로 정리한다.

## 함정 6 — `hermes kanban archive` 후 `block`은 거부

이미 `archive`된 카드는 더 이상 `block` / `complete` / `unblock` 불가. 부모 카드를 `archive`한 뒤 자식 카드를 새로 등록할 때, 자식 카드의 `--parent`는 부모 archived 카드 id를 그대로 써도 동작한다 (archive가 dependency graph를 보존). 즉:

```bash
hermes kanban --board <slug> archive <parent-id>  # 부모 카드 닫기
# 자식 카드는 새 parent를 archive된 부모 id로
hermes kanban create <child-title> --parent <archived-parent-id> ...
```

이렇게 하면 자식 카드는 부모 done 상태의 자리에 archive 완료가 dependency로 들어가서 정상 진행된다.

## 함정 6 — 카드 알림은 소급되지 않는다

`hermes kanban notify-subscribe`는 미래 terminal event만 받는다. 카드가 이미 `done`이 된 뒤에 구독을 걸어도 그 카드의 완료 알림은 오지 않는다.

장기 프로젝트에서는 분해 직후 + 카드 등록 직후에 바로 구독을 거는 게 좋다. 또는 운영자가 직접 `notify-list`로 어떤 카드가 구독돼 있는지 확인한다.

## 함정 7 — `hermes profile create`에서 `--binary` 옵션은 Hermes 0.19+에서 제거됨 (2026-07-24 snkrx-web 실측)

스크립트 `setup-omp-kanban.sh` 6단계가 옛 시그니처로 작성돼 있어 0.19.0에서 즉시 실패한다:

```bash
# ❌ 옛 시그니처 (Hermes 0.18 이하) — 0.19+에서 unrecognized arguments
hermes profile create "coder" \
  --binary /opt/homebrew/bin/omp \
  --description "..."

# 증상:
#   usage: hermes [-h] ... {chat,model,...,profile,...}
#   hermes: error: unrecognized arguments: --binary /opt/homebrew/bin/omp
#   ✗ 프로필 등록 실패
```

`omp` 바이너리는 프로필 안에서 PATH로 자동 발견된다. 0.19+ 정답 시그니처는 **clone 기반** + description:

```bash
# ✅ Hermes 0.19+ 정답
hermes profile create coder --clone \
  --description "oh-my-pi (omp) for kanban coding tasks. 2-tier routing: ..."
# → Wrapper created: /Users/mac/.local/bin/coder
#   coder setup / coder chat / coder gateway start
```

`hermes profile create --help`로 확인되는 플래그는 `--clone` / `--clone-all` / `--clone-from SOURCE` / `--no-alias` / `--no-skills` / `--description DESCRIPTION` 6개뿐. `omp` 바이너리 경로를 강제하는 옵션 자체가 없음.

회피 패턴:
1. 스크립트 사용 전 `hermes profile create --help`로 현재 시그니처 1번 확인.
2. `--clone`은 default 프로필에서 skills/config/.env를 복사하므로, 기존 default 프로필에 omp 자격증명이 없으면 빈 프로필이 됨 → `coder setup` 별도 실행 필요.
3. 스크립트 자체를 패치할 거면 `ai-agent-setup/hermes` 저장소에서 `hermes profile create "$PROFILE_NAME" --clone --description "..."` 형태로 수정.

## 함정 8 — 비대화 환경(agent terminal)에서 `&` background wrapper는 거부됨 (2026-07-24 실측)

스크립트 6.5단계(omp 모델 확인)처럼 셸 레벨 backgrounding을 쓰는 경우 agent `terminal()`에서 다음 에러로 차단된다:

```text
Foreground command uses '&' backgrounding.
Use terminal(background=true) for long-lived processes,
then run health checks and tests in follow-up terminal calls.
```

`&` + `wait` 같은 inline background도 거부된다. macOS에는 `timeout` 명령이 없으므로 셸 레벨에서 시간을 강제하는 패턴(`timeout 10 cmd &`)도 단순 `cmd &`로 인식되어 같은 차단 대상이 된다.

해결 패턴 3가지:

```bash
# 패턴 A — foreground + --max-time (가장 안전, 1~30초 작업)
omp -p "say only: OK" --print --no-tools --no-lsp --max-time 8 > /tmp/omp_test.log 2>&1
tail -5 /tmp/omp_test.log

# 패턴 B — agent tool 사용 시 terminal(background=true) + process(action='poll')

# 패턴 C — `gtimeout` (brew install coreutils) — 비대화 셸 직접 실행 시
```

스크립트 6.5단계처럼 4모델 × background loop + inline kill 패턴은 비대화 환경에서 영영 안 돌아간다. **foreground + `--max-time N`으로 재작성**하거나, agent가 돌리는 환경이라면 `terminal(background=true)`로 명시 분리.

## 함정 9 — 기존 dev 서버 감지 없이 새로 띄우면 포트 충돌 (2026-07-24 snkrx-web 실측)

브라우저 검증 카드 진입 전, 같은 workdir에서 이미 `npm run dev`가 떠 있는 경우 (이전 세션 잔여) 새 dev 서버가 EADDRINUSE로 죽거나, 포트가 겹쳐서 잘못된 서버에 붙을 수 있다.

체크 패턴:

```bash
# 1. 포트 점유 PID 확인
lsof -ti:5173 | head -3
# 2. 기존 서버 응답 확인
curl -s -o /dev/null -w "HTTP %{http_code} / time=%{time_total}s\n" \
  "http://127.0.0.1:5173/?test=1" --max-time 5
# 3. 기존 서버 살아있으면 → 재사용 (방금 띄운 거는 kill)
```

검증 단계:
- HTTP 200 + size > 0 + time < 1s → 살아있음, 재사용
- connection refused → 새로 띄워야 함
- 5xx / 빈 응답 → 죽은 서버. PID 죽이고 재시작

`kill <pid>` 직후 바로 `lsof -ti:5173` 재실행해서 정말 free 됐는지 확인 (TIME_WAIT 잔여). 0~1초 sleep 권장.

`npm run dev`를 background로 띄우기 전에는 항상 이 1줄을 먼저:

```bash
[ -z "$(lsof -ti:5173 2>/dev/null)" ] && npm run dev -- --host 127.0.0.1 --port 5173 > /tmp/dev.log 2>&1 &
# 점유 중이면 위 한 줄은 실행 안 되고, 다음 줄에서 curl로 기존 서버 확인
curl -s -o /dev/null -w "HTTP %{http_code}\n" "http://127.0.0.1:5173/" --max-time 5
```

## 함수 한 줄 — 자주 같이 쓰이는 조합

```bash
# 작업자가 review-required로 멈췄을 때 운영자가 검증 후 승인
hermes kanban --board <slug> show <id> --json | jq '.task, .latest_summary, .runs[-1].summary'
git -C <workdir> status --short --branch
git -C <workdir> log -3 --oneline
npm run build
npm run dev -- --host 127.0.0.1   # 또는 백그라운드+curl
hermes kanban --board <slug> reclaim <id> --reason "operator confirming review-required handoff" || true
hermes kanban --board <slug> complete <id> --summary "..." --metadata '{"changed_files":[...], "reviewed_by":"operator"}'
hermes kanban --board <slug> dispatch --max 1 --json
```

`reclaim`이 실패해도 (worker가 이미 종료된 경우 no-op) 다음 단계는 정상 동작해야 한다.