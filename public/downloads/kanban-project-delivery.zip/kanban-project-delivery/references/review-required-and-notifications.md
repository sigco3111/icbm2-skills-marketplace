content
# Review-required와 Telegram 알림 실전 기록

## 관찰된 흐름

1. 선행 카드가 `done`이면 의존 카드가 `ready`로 승격된다.
2. `dispatch --max 1`이 ready 카드를 worker에 할당해 `running`으로 만든다.
3. worker가 구현·자체 검증 후 `review-required`를 남기며 `blocked`가 될 수 있다.
4. 운영자가 저장소, 빌드, 개발 서버, 브라우저 프리뷰를 독립 검증한다.
5. 검증된 산출물에 단순 `unblock`만 하면 worker가 다시 실행되어 같은 `review-required`를 반복할 수 있다.
6. 이 경우 중복 실행을 정리한 뒤 운영자가 `complete`하고, 다음 카드를 직접 dispatch하거나 정상 dispatcher에 맡긴다.

## 검증 명령 예시

```bash
hermes kanban --board snkrx-web show <task_id> --json
hermes kanban --board snkrx-web stats
hermes kanban --board snkrx-web dispatch --dry-run --json
git -C /Users/mac/work/snkrx-web status --short --branch
git -C /Users/mac/work/snkrx-web log -3 --oneline
npm run build
npm run dev -- --host 127.0.0.1
```

웹 게임 스캐폴딩은 빌드만 보지 말고 브라우저 프리뷰에서 캔버스와 반응형 표시를 확인한다.

## Operator pass-through after review-required

When the worker blocks with `review-required` and the operator has independently verified the artifact (build, tests, dev server, browser preview), use this exact sequence — the `reclaim` is a no-op when the worker process has already exited, which is the normal case, and that is fine:

```bash
hermes kanban --board <slug> show <id> --json
# optional: tail the worker log for context
hermes kanban --board <slug> log <id> --tail 2000
# reclaim is a no-op if the worker isn't running — that is expected
hermes kanban --board <slug> reclaim <id> --reason "operator confirming review-required handoff"
hermes kanban --board <slug> complete <id> \
  --summary "<one-line: what shipped + how verified>" \
  --metadata '{"changed_files":[...], "tests_run":N, "reviewed_by":"operator"}'
```

**Why not just `unblock`?** `unblock` re-spawns the worker on the same card. If the worker's completion rule says "block with review-required on every card", it will block again immediately. Use `complete` with `metadata.reviewed_by` to mark operator-pass-throughs; audits can later sort which `blocked` cards were operator-approved vs human-reviewed.

If after completing, the dispatcher doesn't pick up the next child automatically, run one explicit pass:

```bash
hermes kanban --board <slug> dispatch --max 1 --json
```

## 알림 구독

Telegram chat id가 이미 알려진 경우 카드별로 구독한다.

```bash
hermes kanban notify-subscribe <task_id> \
  --platform telegram \
  --chat-id <chat_id> \
  --notifier-profile default
hermes kanban notify-list
```

구독은 이전 terminal event를 소급하지 않는다. 카드 완료 전에 구독해야 완료 알림을 받을 수 있으며, 신규 카드에 자동 상속된다고 가정하지 말고 `notify-list`로 확인한다.

## Selective notification — only the user's visual-verification gates

Subscribing every card produces notification fatigue: with N cards on a linear chain, the user gets pinged on every `done`/`blocked` even though they only care about gates where they personally need to verify (visual fidelity, gameplay, design). For long-running projects with one operator + one user, **subscribe only the human-verifiable cards** (the cards classified as "needs operator eyes" at decomposition time — see SKILL.md "Decomposition-time classification").

Concrete recipe for a fresh board:

1. After decomposition, list the human-verifiable card ids (e.g. "static first-frame render", "first render Playtest", "design review pass").
2. Subscribe only those:

```bash
for tid in <human-verifiable-id-1> <human-verifiable-id-2> <human-verifiable-id-3>; do
  hermes kanban notify-subscribe "$tid" \
    --platform telegram \
    --chat-id <chat_id> \
    --notifier-profile default
done
```

3. Auto-verifiable cards stay unsubscribed — the orchestrator handles their verification silently and dispatches the next card.
4. Confirm with `hermes kanban notify-list` — subscriptions are not inherited by sibling cards created later; re-subscribe new human-verifiable cards as you add them.

Effect: a Telegram ping means "stop scrolling, your eyes are needed here". Auto-verifiable progress stays out of chat entirely unless something fails.