---
name: kanban-project-delivery
description: Hermes Kanban 기반 장기 코딩 프로젝트 운영 — 보드·의존성·디스패처·알림·review-required 검증·Playtest 게이트까지 실제 산출물 중심으로 관리
version: 1.0.0
author: HyeRin
license: MIT
metadata:
  hermes:
    tags: [kanban, project-delivery, review-gate, playtest, notifications, dispatch]
    related_skills: [kanban-orchestrator, kanban-worker, project-delegation]
---

# Hermes Kanban 장기 코딩 프로젝트 운영

## 사용 시기

- 여러 단계의 웹/게임/애플리케이션 구현을 Kanban으로 운영할 때
- 선행 카드가 끝나면 후속 카드가 자동 실행되어야 할 때
- 코딩 작업자의 산출물을 실제로 검증한 뒤 다음 카드를 진행해야 할 때
- Telegram/Discord로 완료·실패·차단 알림을 받고 싶을 때

## 기본 원칙

1. 카드 상태와 실제 산출물을 구분한다. `done`은 작업자의 자기 보고가 아니라 검증된 결과를 뜻하게 운영한다.
2. 의존성은 카드 생성 시 부모로 선언한다.
3. 자동 진행과 사람 검토를 분리한다. 분석·스캐폴딩은 자동 진행하되, 시각 비교·Playtest·통합은 검토 게이트를 둔다.
4. 오케스트레이터가 최종 소유자다. 작업자는 구현·보고를 하고, 오케스트레이터는 diff·빌드·실행·브라우저 검증 후 완료를 승인한다.
5. 알림은 중요한 terminal event 중심으로 설정한다. heartbeat를 매번 전달하지 않아 알림 폭주를 막는다.

## 표준 흐름

```text
Todo (부모 대기) → Ready (실행 가능) → Running → review-required/Blocked → Done → 다음 부모 의존 카드
```

`Done → 다음 카드`는 디스패처가 정상 실행 중일 때 자동이다. 후속 카드가 실행되지 않으면 `stats`, `list --json`, `dispatch --dry-run`으로 보드와 디스패처를 확인한다.

## review-required 카드 처리

작업자가 구현·검증을 마치고 `review-required`로 Blocked할 수 있다. 이것은 실패가 아니다.

1. `kanban show <id> --json`에서 comments, events, runs를 확인한다.
2. 실제 저장소에서 `git status`, `git log`, `git show <commit>`을 확인한다.
3. canonical build/test를 오케스트레이터가 직접 다시 실행한다.
4. 웹 작업이면 개발 서버와 브라우저 프리뷰를 확인한다.
5. 검증이 통과하면 운영자 검토 결과를 기록한다.
6. 이미 산출물이 완성됐는데 단순 `unblock` 후 worker가 같은 review-required를 반복하면, 중복 실행을 정리하고 운영자가 카드를 최종 완료한다.
7. 검증이 부족하면 Blocked를 유지하고 사용자에게 확인을 요청한다.

`unblock`은 후속 실행을 유발할 수 있으므로, 단순 해제가 승인 완료를 뜻하지 않는다.

### Decomposition-time classification (prevent the "review-required stutter")

A single `review-required` block is fine. A linear chain of them is a stall — the dispatcher auto-promotes the next card only when the previous is `done`, but if every worker blocks at "review-required: I can't pixel-check headlessly", the chain never advances and the operator ends up unblocking each card by hand.

**At decomposition time, classify each card into one of two groups and write the rule into the card body so the worker reads it before it decides to block.** This is cheaper than fixing it after the chain stalls.

| Group | Worker completion rule | Examples |
|---|---|---|
| **Auto-verifiable** | `kanban_complete(...)` after tests + build + smoke all pass. **Do not** `kanban_block(review-required:)` for this card. | scaffolding, deps install, DPR/viewport module, font loading, asset loader wiring, store state machine, save/load helpers |
| **Human-verifiable** | After smoke checks pass, `kanban_block(reason="review-required: ...")` and stop. Operator/Playtest reviews and unblocks. | static first-frame render, gameplay first wave, design review, balance pass, store layout, audio mix |

Most "wire / load / scaffold / unit-test" cards in a game/web port project fall in the auto-verifiable group. Only cards that gate *playtest* or *visual fidelity* belong in the human-verifiable group.

Auto-verifiable card body example:

```text
Wire src/viewport.ts. Acceptance: `npm test` passes for the new tests,
`npm run build` succeeds, `npm run dev` serves the page. After all three pass,
call kanban_complete directly. Do NOT block with review-required for this card.
```

Human-verifiable card body example:

```text
Render the static first-frame of the arena. Acceptance: Vite dev server
serves at http://127.0.0.1:5173/ with the canvas visible, and the page
matches the reference screenshot shape. After smoke passes, block with
review-required: so the operator can confirm visually before the next card.
```

When you (orchestrator/operator) have to unblock by hand anyway:

```bash
hermes kanban show <id> --json          # confirm work is genuinely complete
hermes kanban log <id> --tail 2000      # optional: pull worker log
hermes kanban reclaim <id> --reason "operator confirming review-required handoff"
# reclaim is a no-op if the worker is no longer running — that's normal
hermes kanban complete <id> --summary "<one-line>" --metadata '{"changed_files":[...], "tests_run":N, "reviewed_by":"operator"}'
```

`metadata.reviewed_by: "operator"` is a useful breadcrumb — later audits can sort which `blocked` cards were operator-pass-throughs vs which were human-reviewed.

## 웹 게임 Playtest 게이트

`npm run build` 성공만으로 게임 품질을 승인하지 않는다. 개발 서버, 브라우저 캔버스, 논리 해상도·DPR, 리사이즈, 콘솔 오류, 원본 대비 위치·크기·색상·폰트·레이어 순서를 확인한다. 사용자 확인이 필요한 카드는 자동 Done 처리하지 않는다.

## Telegram 알림

```bash
hermes kanban notify-subscribe <task_id> --platform telegram --chat-id <chat_id> --notifier-profile default
hermes kanban notify-list
```

카드별 구독을 설정하고 완료·차단·실패·시간 초과 중심으로 운영한다.

## 상태 점검 명령

```bash
hermes kanban --board <slug> stats
hermes kanban --board <slug> list --json
hermes kanban --board <slug> show <task_id> --json
hermes kanban --board <slug> dispatch --dry-run --json
hermes gateway status
```

- `blocked=1`: 검토 대기인지 오류인지 comments/events/runs 판별
- `ready=1`: 디스패처가 가져갈 수 있는 상태
- `todo=1`: 부모 작업 대기

## 참고 자료

- `references/review-required-and-notifications.md`
- `references/kanban-cli-gotchas.md` — `hermes kanban` CLI 운영 시 만나는 함정 (create 응답 키, block positional reason, subprocess prefix argv, unblock≠승인, **link positional parent_id→child_id**, **잘못된 링크 후 dispatcher 동시 Running 함정** 등)
- `references/snkrx-web-case-study.md` — 2026-07-22~23 snkrx-web 게임 포팅 보드의 실측 타임라인. 카드 hang → 5장 분할 → 시각 검증에서 placeholder 발견 → 알림 폭주 → selective notification 전환까지 SKILL.md 패턴이 실제로 어떻게 작동/실패했는지의 사례 모음.

## 금지 사항

- worker 자기 보고만으로 Done 처리하지 않는다.
- 존재하지 않는 프로필을 assignee로 만들지 않는다.
- 부모 의존성이 있는 카드를 독립 Ready로 만들지 않는다.
- Playtest 전에 웹 게임의 시각 동일성을 확정하지 않는다.
- 알림 설정 후 `notify-list` 재확인을 생략하지 않는다.
- 분해 시점에 auto-verifiable vs human-verifiable 카드를 분류해 카드 본문에 완료 규칙으로 적어두지 않으면, 작업자가 일괄 `review-required:`로 멈추며 운영자가 매번 수동 unblock하게 된다. "Decomposition-time classification" 섹션 참고.

## 카드 크기 제한 — worker stop sign

**A single card should finish within roughly 10–15 minutes of worker time, not multiple hours.** A card that bundles "build the static first-frame of the entire arena with all sprites and UI" is too big, even if its final shape is auto-verifiable. The worker has no stop sign until it hits a `review-required` block or runs out of iterations, and a too-large card produces three failure modes that the operator only notices after the fact:

1. **Patch churn** — 15+ patches to the same file in one worker session, often fixing earlier mistakes. Symptom in the log: alternating `npx tsc --noEmit` and `patch <same-file>` lines.
2. **Background-shell trap** — the worker's final smoke step (e.g. `npm run dev | tee /tmp/log &`) gets captured by a foreground wrapper and the worker hangs waiting for the process to exit. The card stays `running` indefinitely with a live PID but no progress.
3. **Self-verification loop** — the worker keeps re-running its own checks (tsc, build, asset URLs) and never decides "done". No error, no crash, just endless heartbeat.

Decomposition rule:

- If a card needs >2 unrelated subsystems (e.g. "snake head + body history + hero positions + enemy spawn + projectile + UI bar + particle system + BASELINE comparison"), split it. Natural split points for game ports:
  - **Data / coords module** (constants only, unit-tested) → 5 min
  - **Render skeleton** (PixiJS scene with placeholder objects, builds and renders) → 10 min
  - **First subsystem** (e.g. snake body + hero positions only) → 10 min
  - **Second subsystem** (e.g. enemy + projectile + HP bar) → 10 min
  - **UI + comparison note** (gold/round/pause placeholder + visual diff doc) → 10 min

When a worker is already stuck mid-card (1h+ elapsed, no commit, heartbeat but no diff), do not wait for it to finish. Use the **stuck-worker recovery** sequence below.

### Stuck-worker recovery (operator procedure)

When `runs` shows `outcome: null`, `status: running`, elapsed >> 30 min, and no commit has landed:

1. **Verify the worker is actually alive but stuck** — `ps -p <worker_pid> -o pid,etime,%cpu,%mem,stat` (low %CPU + no recent heartbeat payload = stuck).
2. **Confirm there is no salvageable artifact** — `git status --short` and `git log -3 --oneline`. If no commit and no useful diff, treat as a lost cause.
3. **Reclaim and archive the parent card** so the worker claim is released:
   ```bash
   hermes kanban --board <slug> reclaim <id> --reason "stuck X min, splitting into smaller cards"
   # reclaim is a no-op if the worker is no longer running — that's fine
   hermes kanban --board <slug> archive <id>
   ```
4. **Create the split children** with the same `--parent <original-id>` chain (each new card lists the previous one as parent; the original archived card acts as the dependency root) and **decomposition-time classification** baked into each body.
5. **Dispatch the first child** explicitly with `hermes kanban --board <slug> dispatch --max 1 --json` if the dispatcher hasn't picked it up yet.

Do not call `kanban_complete` on the original card — it was never finished. `archive` keeps the audit trail while removing it from the active chain.

## 자동 진행에 대한 사용자 알림 정책

**자동 검증 카드는 운영자도 사용자도 알리지 않고 묵묵히 통과시킨다.** Telegram 알림은 시각 검증 카드에만 구독한다. 이건 단순한 알림 노이즈 필터링이 아니라 사용자 선호 시그널이다:

- 자동 검증 카드마다 "멈춤 → 제가 검토해서 다시 진행" 같은 메시지를 사용자에게 보내면, **사용자는 "진척이 없는 것 같은데?" 라고 다시 묻게 되고**, 매번 "아니야 사실 5장 끝났어" 같은 해명을 반복해야 한다.
- 작업자가 `review-required`로 멈춘 사실 자체는 운영자에게 가는 정상 신호이지 사용자에게 가는 "이게 뭔가요?" 신호가 아니다. 운영자가 검증해서 `complete`하면 그 자체로 다음 카드가 자동 실행된다.
- 시각 검증 카드의 `review-required`만 사용자 알림 대상. 이건 진짜 "지금 화면 확인해주세요" 라는 신호.

기본 동작:

| 카드 종류 | Telegram 알림 | 메시지 내용 |
|---|---|---|
| 자동 검증 (단위 테스트·빌드·로직) | ❌ 미구독 | (없음) |
| 시각 검증 (Playtest·시각 비교) | ✅ 구독 | 작업 요약 + 확인 방법 + 다음 단계 |
| 실패/타임아웃 | ✅ 자동 (구독 여부 무관) | 에러 요약 |

사용자가 명시적으로 "매 작업마다 알려줘"로 바꾸면 그때 모든 카드에 구독. 기본값은 selective.

## 운영자 응답 스타일 (stalled 카드 처리 시, ★ 2026-07-23 사용자 시그널)

**카드가 막혔을 때 운영자는 설명형 보고 → 행동형 보고로 전환한다.** 사용자가 "별다른 진전이 없어보이는데, 콜솔에서 더 많은 정보를 수집할 수 있도록 로그를 추가해보는게 어때?" 같은 시그널을 보냈을 때, 운영자는 다음을 따른다:

- ❌ "지금 카드가 review-required로 멈춰있고, 작업자가 47분째 패치를 반복하고 있어서..." 같은 **진행 상황 나열 금지**. 사용자는 이미 앎.
- ❌ "가능한 원인 A, B, C가 있고..." 같은 **이론 나열 금지**. 작업자는 멈췄고 사용자는 답이 듣고 싶음.
- ✅ **로그를 추가하고 결과를 본다 → 무엇이 문제인지 좁혀서 다음 행동 1개를 제시**.
- ✅ 사용자가 "ok" 만 응답할 때: **바로 행동으로 옮긴다** (카드 생성, dispatch, log 추가 등). 추가 확인 질문 금지.
- ✅ 작업자 보고 / 빌드 결과 / git log 같은 **machine-verified facts만 보고**. "X가 진전 없는 것 같다" 같은 추측성 표현 금지.

**카드 분할 / 작업자 회복 시 커뮤니케이션**: "1장 → 5장으로 분할" 같은 결정은 **사용자 선택지 4개 + 추천 1개** 형태로 제시하고, 사용자 응답을 받자마자 실행. 결정형 답변을 기다리지 말고, 추천 옵션이 명확할 때는 그 옵션으로 바로 진행한다고 안내.

**핵심**: 사용자가 "잘 진행 중이야?" 같은 추적성 질문을 했을 때 답은 **짧고 사실 기반**이어야 한다. 카운트(stats), 마지막 작업 시간, 다음 행동.

## 작업자 자동 분해(specify/decompose) 충돌 처리 (★ 2026-07-23 SNKRX 실측)

작업자가 큰 카드를 받으면 내부적으로 `kanban_specify` 또는 `kanban_decompose`를 호출해 **자동으로 5-7장의 세분화 카드를 생성**할 수 있다. 이때:

- **원본 카드는 `todo`로 돌아감** (분해되어 더 이상 직접 처리 안 됨)
- 분해된 카드들은 **자동으로 추가되어 dispatcher가 즉시 디스패치 가능**
- **원본 spec과 분해된 카드의 body가 충돌**하는 경우 많음 (예: 작업자가 chain-follower로 구현했는데 분해 카드는 "90° 회전 + accumulator" 같은 다른 spec으로 작성)

**즉시 인식 신호**:
- 카드가 갑자기 5-7장 늘었음
- 새 카드의 title이 비슷한 단어 반복 (예: "Create Snake module skeleton", "Implement snake rendering in PIXI.Graphics", "Wire ArrowLeft / ArrowRight keyboard input", "Write Snake unit tests (Vitest)", "Final integration check in main.ts and README touch-up")
- 새 카드들의 spec body가 원본 카드의 의도와 다름

**처리 절차**:

```bash
# 1. 작업자 프로세스 즉시 중단 (작업자가 이미 시작했을 가능성)
ps aux | grep -E 'hermes.*t_<new-id>' | grep -v grep | awk '{print $2}' | head -1 | xargs -r kill -TERM

# 2. 자동 분해된 카드 전부 archive
for tid in t_<auto-id-1> t_<auto-id-2> ...; do
  hermes kanban archive $tid
done

# 3. 원본 카드는 필요 시 직접 done 처리하거나, 운영자 설계의 새 카드로 대체
```

**원인 (★ 디버깅 메모)**: 작업자의 `kanban_specify` / `kanban_decompose`는 카드의 짧은 title + body를 보고 "어떤 단계로 나눌까"를 결정함. 작업자가 자체적인 구현 방향(예: chain-follower)을 명시하지 않으면, LLM의 일반적인 게임 프로그래밍 지식을 기반으로 분해 (보통 "skeleton + rendering + input + tests + integration" 같은 표준 패턴). **운영자가 이미 구현 방향을 정한 경우엔 항상 자동 분해된 카드는 무시**하고 운영자 카드를 쓰는 게 안전.

**카드 body에 "분해 금지" 표시**:
```text
[DO NOT SPECIFY/DECOMPOSE] 이 카드는 운영자가 직접 작성한 단일 범위.
worker는 kanban_complete 또는 kanban_block만 호출.
kanban_specify / kanban_decompose 호출 금지.
```

이 한 줄이 자동 분해 충돌을 거의 막아준다.

## 운영자의 작업자 파일 충돌 방지 패턴 (★ 2026-07-23 SNKRX 실측)

상황: 운영자가 직접 `src/snake.ts`를 chain-follower 모델로 수정하고 commit함. 그런데 **이미 dispatch되어 실행 중이던 작업자가 같은 `src/snake.ts`를 건드리는 중**이면, 작업자의 patch가 운영자의 chain-follower를 덮어쓸 수 있음.

**신호 감지**:
```bash
# 작업자 로그에서 같은 파일을 만지는지 확인
hermes kanban --board <slug> log <task_id> --tail 100 | grep -E 'patch.*<filename>'
```

**즉시 대응**:
```bash
# 1. 작업자 프로세스 중단 (PID는 ps aux | grep 'hermes.*t_<id>' | awk '{print $2}')
PID=$(ps aux | grep -E 'hermes.*t_<id>' | grep -v grep | awk '{print $2}' | head -1)
[ -n "$PID" ] && kill -TERM $PID
sleep 2
# 2. 작업자 reclaim + 카드는 그대로 (운영자가 직접 처리)
hermes kanban --board <slug> reclaim <id> --reason 'operator overriding worker to prevent file conflict'
```

**원칙**: 운영자가 작업자 결과를 신뢰할 수 없는 상황(같은 파일에 동시 변경)은 **작업자를 즉시 중단**. 작업자가 자기 commit을 push하기 전에 차단. 운영자가 작업자의 미완성 변경은 `git checkout <file>` 또는 `git stash -u`로 정리.

## 사용자 선호 — 설명형 보고보다 행동 (★ 2026-07-23 SNKRX 실측)

**시그널**: 사용자가 "별다른 진전이 없어보이는데, 콜솔에서 더 많은 정보를 수집할 수 있도록 로그를 추가해보는게 어때?" 같이 **원인 추측/이론 나열 대신 구체적 다음 행동**을 요구.

**규칙**:
- ❌ "지금 카드가 review-required로 멈춰있고, 작업자가 47분째 패치를 반복하고 있어서..." 같은 **진행 상황 나열 금지** — 사용자는 이미 앎
- ❌ "가능한 원인 A, B, C가 있고..." 같은 **이론 나열 금지** — 작업자는 멈췄고 사용자는 답이 듣고 싶음
- ✅ **로그를 추가하고 결과를 본다 → 무엇이 문제인지 좁혀서 다음 행동 1개를 제시**
- ✅ 사용자가 "ok" 만 응답할 때: **바로 행동으로 옮긴다** (카드 생성, dispatch, log 추가 등). 추가 확인 질문 금지
- ✅ 작업자 보고 / 빌드 결과 / git log 같은 **machine-verified facts만 보고**. "X가 진전 없는 것 같다" 같은 추측성 표현 금지

**왜 이게 중요한가**: 운영자가 "이론 A, B, C"로 답하면 사용자는 그 중 하나를 골라야 하고, 운영자가 "로그 추가 + 다음 행동"으로 답하면 사용자는 그 행동을 승인/거절만 하면 됨. **사용자의 인지 부하를 최소화**하는 것이 장기 프로젝트의 핵심.

**반대 상황**: 사용자가 명시적으로 "왜 안 되는지 설명해줘" 같은 요청을 보낸 경우는 오히려 **완전한 이론 나열 + 각각의 가능성**이 정답. 두 패턴을 구분하는 핵심은 **사용자 메시지에 "왜" / "설명" 단어가 있느냐** + **사용자가 막힘을 직접 알렸느냐** + **이전 응답에 행동이 포함됐었느냐**. 이 중 하나라도 없으면 행동형으로 응답.

### 무엇이 일어났나

사용자가 "시각 검증할 시점에 다시 알려줘"라고 명시 요청. 즉, **자동 진행 도중 시각 검증을 사람이 직접 해야 하는 카드**만 알림. 그 외 자동 검증 카드는 알림 없음. 이건 SKILL.md 본문의 "선택적 알림 정책"과 일치.

### 학습

Telegram 알림은 카드 단위로 구독. board 단위 구독은 알림 폭주를 만든다. **시각 검증 카드**만 구독. 그 외 자동 검증 카드는 **운영자가 직접 검증 후 done 처리** (사용자에게 안 보냄).

다만 이게 한 사이클이 잘 끝났을 때의 이야기이고, **여러 사이클 동안 사용자가 "X가 끝났습니다, 다음 진행합니다" 메시지를 보고 싶을 때**는 board 단위 또는 모든 카드 알림으로 전환 가능. 운영자가 매번 결정.

## 9번 사례 — 점진적 분할 + 검증 사이클 (snkrx-web v0.1.0+ 성공 패턴)

### 무엇이 일어났나

snkrx-web은 1시간+ 정지 카드를 분할해 5장 → B+D 운영자 직접 수정 → 누적 거리 카드 추가 → 보정 카드 분할 → Phase 4 5장 분할 → 보정 카드 추가의 흐름으로 진행. 이 모든 흐름이 **사용자 "OK" 또는 "A/B/C/D 선택"**로 단계를 진행.

### 학습

성공한 사이클은 항상 **사용자 한 번 확인 → 운영자 행동** 패턴. 사용자가 모든 단계를 자동으로 신뢰하고 결과를 보는 게 아니라, **핵심 결정 지점에서 한 번 확인**:
- 작업자 1시간+ 정지 → "B+D"
- 누적 거리 보정 → "A"
- 자동 조준 + 투사체 → "A"
- 화면 경계 튕김 + 화면 정렬 → "A"
- 뱀 곡선 추적 → "A"
- 발사 위치 버그 → 자동으로 bugfix 카드
- Wave 표시 버그 → 자동으로 bugfix 카드

이 패턴이 "8단계 풀 게임 포팅 = 실패 패턴"이었던 v0.1.12 (Canvas 2D)와 가장 큰 차이. v0.1.0+ PixiJS는 **사용자 확인 + 분할 + 보정 카드 + 운영자 직접 수정**의 조합으로 진행되어 v0.1.0+ Phase 4까지 안정적으로 도달.

## 10번 사례 — 사용자가 카드 진행 상태를 추적하는 패턴 ("지금 진행중인게 맞나?")

### 무엇이 일어났나

Phase 3 끝나고 Phase 4 카드 자동 진행 후, 사용자가 "지금 진행중인게 맞나?"로 작업자 상태를 물었음. 운영자는 stats + show + log + ps로 즉시 확인 후 보고. **사용자 추적성 질문은 정상이며, 운영자는 빠르게 machine-verified facts로 답해야 함.**

### 학습

- stats: by status + oldest ready task age
- show: latest_summary, runs, events
- log: 작업자 활동
- ps: 프로세스 alive 확인

4개 조합으로 5초 이내에 "진행 중 / 멈춤 / 실패" 구분 가능. 답은 짧고 사실 기반이어야 함 ("5/8 done, phase 4 running, commit 271f0e3"). "진행이 느린 것 같다" 같은 추측성 표현 금지.
