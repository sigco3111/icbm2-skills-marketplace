---
name: kanban-project-delivery
description: Hermes Kanban 기반 장기 코딩 프로젝트 운영 — 보드·의존성·디스패처·알림·review-required 검증·Playtest 게이트까지 실제 산출물 중심으로 관리
version: 1.0.0
author: HyeRin
license: MIT
metadata:
  hermes:
    tags: [kanban, project-delivery, review-gate, playtest, notifications, dispatch]
    related_skills: [kanban-orchestrator, kanban-worker, project-delegation]
---

# Hermes Kanban 장기 코딩 프로젝트 운영

## 사용 시기

- 여러 단계의 웹/게임/애플리케이션 구현을 Kanban으로 운영할 때
- 선행 카드가 끝나면 후속 카드가 자동 실행되어야 할 때
- 코딩 작업자의 산출물을 실제로 검증한 뒤 다음 카드를 진행해야 할 때
- Telegram/Discord로 완료·실패·차단 알림을 받고 싶을 때
- **Three.js + Vite + Vitest 같은 브라우저 ESM 게임 부트스트랩 프로젝트일 때** → `vite-threejs-game-bootstrap` 스킬 참조

## 기본 원칙

1. 카드 상태와 실제 산출물을 구분한다. `done`은 작업자의 자기 보고가 아니라 **machine-verified 된 결과** (사용자 디렉터리에 실제 파일 + git commit + 빌드 결과) 를 뜻한다.
2. 의존성은 카드 생성 시 부모로 선언한다.
3. 자동 진행과 사람 검토를 분리한다. 분석·스캐폴딩은 자동 진행하되, 시각 비교·Playtest·통합은 검토 게이트를 둔다.
4. 오케스트레이터가 최종 소유자다. 작업자는 구현·보고를 하고, 오케스트레이터는 **5분 안에 사용자 디렉터리의 실제 파일 + git log + build 결과** 3종 세트로 검증한 뒤 완료로 승인한다.
5. 알림은 중요한 terminal event 중심으로 설정한다. heartbeat를 매번 전달하지 알림 폭주를 막는다.

## ★★★ Done ≠ Verified — 워커 완료 후 사용자 디렉터리 검증 게이트 (★ 2026-07-27 minimax-of-duty 실측) ★★★

**원칙**: `kanban_complete` 호출 ≠ 사용자 손에 코드 도착. 워커는 scratch workspace 에 코드를 박고 dispatcher 가 그 workspace 를 정리하면 사용자 디렉터리는 비어있는 상태로 끝남. **"done=1" 만 보고 끝내면 0 파일이 사용자 손에 남음** — 2026-07-27 minimax-of-duty 의 Phase 1.0 + 1.1 이 정확히 이 함정에 빠진 뒤 운영자가 6 모듈 + main + test 를 1시간 걸려 재구현했음 (함정 14 본문 참조).

**즉시 검증 (워커 done 5분 이내, 매번)**:

```bash
# 1. 사용자 디렉터리에 새 파일 + 새 commit
ls -la /Users/mac/work/<project>/
git -C /Users/mac/work/<project>/ log --oneline | head -3
git -C /Users/mac/work/<project>/ status --short

# 2. scratch workspace 살아있는지
find /Users/mac/.hermes/kanban/boards -type d -name 't_<id>*' 2>/dev/null
ls -la /Users/mac/.hermes/kanban/boards/<board>/workspaces/t_<id>/

# 3. 워커 latest_summary (commit hash + 핵심 파일 목록)
hermes kanban --board <board> show t_<id> | grep -A 5 "Latest summary"
```

**3가지 회복 워크플로**:

| 상황 | 회복 |
|---|---|
| A. 워커가 `--workspace dir:<user_dir>` 사용 | 사용자 디렉터리에 직접 박힘. `git add + commit` 만 |
| B. scratch workspace 살아있음 | `cp -r workspace/* <user_dir>/ && git add . && git commit` |
| C. 둘 다 없음 | 운영자가 ARCHITECTURE.md + latest_summary 로 직접 재구현 (5~30분) |

**예방 (★ 모든 새 카드 의무)**: 처음부터 `--workspace dir:<user_dir>` 로 생성. `scratch` 모드 절대 안 씀. 단 `worktree:<path>` 모드는 git worktree 메커니즘 — 사용자 디렉터리 내 다른 브랜치에 박힘. Phase 별 브랜치 분리 시 적합.

**보고 의무**: 워커 done 보고 시 `git log --oneline | head -3` + `git status --short` 결과를 **반드시 machine-verified facts 로 같이 보고**. "다 됐어요" 같은 추측성 / 자랑 표현 금지. 사용자가 "별다른 진전이 없어보이는데..." 시그널 보내면 즉시 git log + workspace ls + 워커 ps 3종 세트로 machine-verified 보고 (snkrx-web 9번 / 10번 사례).

## 프로젝트 이름 중간 변경 — slug immutable + 일괄 치환 워크플로 (★ 2026-07-27 신규, minimax-of-duty 실측)

칸반 보드 slug 는 immutable (`boards rename` 은 display name 만). 프로젝트 이름을 잘못 정하거나 사용자가 변경 원할 때:

1. **사용자 디렉터리 이동**: `mv /Users/mac/work/<old> /Users/mac/work/<new>`
2. **본문 일괄 치환**: `sed -i '' 's/<old-slug>/<new-slug>/g' /Users/mac/work/<new>/prompts/*.md` (heredoc 비대화 가드 회피)
3. **칸반 보드 정리**: 옛 보드 `hermes kanban boards rm <old>` (archive) + 새 보드 `create <new>`
   - **★ 워커 running 중에 rm 하면 scratch + 사용자 디렉터리 데이터 손실**. `running=0` 확인 후에만.
   - 또는 옛 보드 그대로 두고 display name 만 바꾸는 것도 가능 (slug 비일관성 감수)
4. **사용자 디렉터리에 직접 작업한 워커 코드는 자동으로 새 이름 따라감** (`--workspace dir:<path>` 의 장점)

**자주 하는 실수**: 새 보드만 `create new` 하고 옛 보드를 `archive` 안 해서 두 보드가 공존 → 다음 세션에서 어느 보드가 활성인지 헷갈림. 보드는 항상 1:1 매핑 유지.

## 표준 흐름

```text
Todo (부모 대기) → Ready (실행 가능) → Running → review-required/Blocked → Done → 다음 부모 의존 카드
```

`Done → 다음 카드`는 디스패처가 정상 실행 중일 때 자동이다. 후속 카드가 실행되지 않으면 `stats`, `list --json`, `dispatch --dry-run`으로 보드와 디스패처를 확인한다.

## review-required 카드 처리

작업자가 구현·검증을 마치고 `review-required`로 Blocked할 수 있다. 이것은 실패가 아니다.

1. `kanban show <id> --json`에서 comments, events, runs를 확인한다.
2. 실제 저장소에서 `git status`, `git log`, `git show <commit>`을 확인한다.
3. canonical build/test를 오케스트레이터가 직접 다시 실행한다.
4. 웹 작업이면 개발 서버와 브라우저 프리뷰를 확인한다.
5. 검증이 통과하면 운영자 검토 결과를 기록한다.
6. 이미 산출물이 완성됐는데 단순 `unblock` 후 worker가 같은 review-required를 반복하면, 중복 실행을 정리하고 운영자가 카드를 최종 완료한다.
7. 검증이 부족하면 Blocked를 유지하고 사용자에게 확인을 요청한다.

`unblock`은 후속 실행을 유발할 수 있으므로, 단순 해제가 승인 완료를 뜻하지 않는다.

### Decomposition-time classification (prevent the "review-required stutter")

A single `review-required` block is fine. A linear chain of them is a stall — the dispatcher auto-promotes the next card only when the previous is `done`, but if every worker blocks at "review-required: I can't pixel-check headlessly", the chain never advances and the operator ends up unblocking each card by hand.

**At decomposition time, classify each card into one of two groups and write the rule into the card body so the worker reads it before it decides to block.** This is cheaper than fixing it after the chain stalls.

| Group | Worker completion rule | Examples |
|---|---|---|
| **Auto-verifiable** | `kanban_complete(...)` after tests + build + smoke all pass. **Do not** `kanban_block(review-required:)` for this card. | scaffolding, deps install, DPR/viewport module, font loading, asset loader wiring, store state machine, save/load helpers |
| **Human-verifiable** | After smoke checks pass, `kanban_block(reason="review-required: ...")` and stop. Operator/Playtest reviews and unblocks. | static first-frame render, gameplay first wave, design review, balance pass, store layout, audio mix |

Most "wire / load / scaffold / unit-test" cards in a game/web port project fall in the auto-verifiable group. Only cards that gate *playtest* or *visual fidelity* belong in the human-verifiable group.

Auto-verifiable card body example:

```text
Wire src/viewport.ts. Acceptance: `npm test` passes for the new tests,
`npm run build` succeeds, `npm run dev` serves the page. After all three pass,
call kanban_complete directly. Do NOT block with review-required for this card.
```

**시각 명세 acceptance criteria 가 있는 카드는 auto-verifiable 이 아니다** (★ 2026-07-24 snkrx-web Phase 5-8 교훈). "shop card slide-in spring bounce", "0~0.6초 호버 글로우", "클릭 시 sx/sy sin 펄스" 같은 시각 명시가 body 에 있으면 그 카드는 **human-verifiable**. 작업자가 "20/20 pass, build clean" 만 보고하지, "사용자가 ?test=1 로 시각 확인했습니다" 를 명시해야 함. 자세한 사례는 `references/snkrx-web-case-study.md` 11번 사례 참고.

**이전 task 부터 있던 fail 테스트는 운영자 결정 대상** (★ 2026-07-24). 작업자가 "fail N개는 이전 task 부터 존재, 본 task 와 무관" 으로 묵묵히 통과 보고하면 — 그 fail 자체가 **시각 검증의 신호**일 수 있음. 운영자가 fix 할지 archive 후 별도 bugfix 카드로 뺄지 결정.

Human-verifiable card body example:

```text
Render the static first-frame of the arena. Acceptance: Vite dev server
serves at http://127.0.0.1:5173/ with the canvas visible, and the page
matches the reference screenshot shape. After smoke passes, block with
review-required: so the operator can confirm visually before the next card.
```

When you (orchestrator/operator) have to unblock by hand anyway:

```bash
hermes kanban show <id> --json          # confirm work is genuinely complete
hermes kanban log <id> --tail 2000      # optional: pull worker log
hermes kanban reclaim <id> --reason "operator confirming review-required handoff"
# reclaim is a no-op if the worker is no longer running — that's normal
hermes kanban complete <id> --summary "<one-line>" --metadata '{"changed_files":[...], "tests_run":N, "reviewed_by":"operator"}'
```

`metadata.reviewed_by: "operator"` is a useful breadcrumb — later audits can sort which `blocked` cards were operator-pass-throughs vs which were human-reviewed.

## 웹 게임 Playtest 게이트

`npm run build` 성공만으로 게임 품질을 승인하지 않는다. 개발 서버, 브라우저 캔버스, 논리 해상도·DPR, 리사이즈, 콘솔 오류, 원본 대비 위치·크기·색상·폰트·레이어 순서를 확인한다. 사용자 확인이 필요한 카드는 자동 Done 처리하지 않는다.

## Telegram 알림

```bash
hermes kanban notify-subscribe <task_id> --platform telegram --chat-id <chat_id> --notifier-profile default
hermes kanban notify-list
```

카드별 구독을 설정하고 완료·차단·실패·시간 초과 중심으로 운영한다.

## 상태 점검 명령

```bash
hermes kanban --board <slug> stats
hermes kanban --board <slug> list --json
hermes kanban --board <slug> show <task_id> --json
hermes kanban --board <slug> dispatch --dry-run --json
hermes gateway status
```

- `blocked=1`: 검토 대기인지 오류인지 comments/events/runs 판별
- `ready=1`: 디스패처가 가져갈 수 있는 상태
- `todo=1`: 부모 작업 대기

## 비대화 환경 가드 (2026-07-24 신규)

agent `terminal()`은 비대화 환경에서 다음 패턴을 거부한다. setup-omp-kanban.sh 같은 스크립트를 agent가 실행할 때 특히 주의:

- **셸 background wrapper (`&`, `&` + `wait`)**: `Foreground command uses '&' backgrounding` 에러. macOS `timeout` 명령 없음. 우회: `terminal(background=true)`로 명시 분리, 또는 `--max-time` 플래그로 foreground 실행.
- **`cat` 헤드리스 출력 일부 케이스**: `BLOCKED (hardline)` — `read_file`로 우회.
- **셸 background + long-lived watcher**: `terminal(background=true, notify_on_complete=true)`로 감시.

또한 dev 서버 띄우기 전에는 `lsof -ti:<port>`로 기존 인스턴스를 먼저 점검. EADDRINUSE + 잘못된 서버 매칭 회피. 상세 패턴은 `references/kanban-cli-gotchas.md` 함정 7~9 참조.

## 참고 자료

- `references/review-required-and-notifications.md`
- `references/kanban-cli-gotchas.md` — `hermes kanban` CLI 운영 시 만나는 함정 (create 응답 키, block positional reason, subprocess prefix argv, unblock≠승인, **link positional parent_id→child_id**, **잘못된 링크 후 dispatcher 동시 Running 함정**, **archive는 보드만 정리, 시스템 산출물 별도 정리 필요**, **위임 5장 일괄 dispatch + 옵션 안보임 멈춤 신호** 등)
- `references/kanban-cli-gotchas-addendum-2026-07-24.md` — 2026-07-24 v0.19+ 발견: **`--initial-status`는 `blocked`/`running`만 (todo 없음)**, 사용자 "OK" 한 단어 신호 = 묶음 후속 작업 진행 패턴, multi-line body는 heredoc 필수.
- `references/session-terminate-gotcha-2026-07-27.md` — 사용자 종료 신호 = 즉시 STOP 패턴 + vite dev 서버 SIGTERM 30분 사이클 + 워커 SIGTERM 직전 commit 시나리오 + 종료 신호 4종 분류.
- `references/snkrx-web-case-study.md` — 2026-07-22~23 snkrx-web 게임 포팅 보드의 실측 타임라인. 카드 hang → 5장 분할 → 시각 검증에서 placeholder 발견 → 알림 폭주 → selective notification 전환까지 SKILL.md 패턴이 실제로 어떻게 작동/실패했는지의 사례 모음.
- `references/decommission-system-residue.md` — 2026-07-24 sigco3111 gitfut-scout 보드 폐기 사고. archive 한 줄로 끝내지 않고 cron + SKILL.md + /tmp 잔여까지 점검하는 5영역 체크리스트 + 폐기 자동 점검 스크립트 + 안티패턴 보고 모음.

## 금지 사항

- worker 자기 보고만으로 Done 처리하지 않는다.
- 존재하지 않는 프로필을 assignee로 만들지 않는다.
- 부모 의존성이 있는 카드를 독립 Ready로 만들지 않는다.
- Playtest 전에 웹 게임의 시각 동일성을 확정하지 않는다.
- 알림 설정 후 `notify-list` 재확인을 생략하지 않는다.
- 분해 시점에 auto-verifiable vs human-verifiable 카드를 분류해 카드 본문에 완료 규칙으로 적어두지 않으면, 작업자가 일괄 `review-required:`로 멈추며 운영자가 매번 수동 unblock하게 된다. "Decomposition-time classification" 섹션 참고.

## 사용자 카드 상한 (★ 2026-07-24 신규 — 카드 등록 over-step 사고)

**사용자가 카드 개수를 명시한 경우, 그 숫자를 절대 넘기지 않는다.** "1~2장 더", "한두 개", "1장 추가" 같은 신호는 **상한**이지 시작점이 아니다.

과거 사고 (2026-07-24, sigco3111 gitfut 보드):

- 사용자: "지금 작업 중인 칸반이 있는데, 새로운 칸반을 하나 또는 두 개 더 생성해서 진행하게 되지?"
- 운영자: 보드 1개 신규 생성 + 카드 5장 일괄 등록 + 모두 `--priority 50` + 자동 dispatch까지 흘림.
- 사용자가 "1~2장 더"라고 한 의도는 **현재 작업 흐름을 가볍게 보강**이었지 "새 보드 + 5장 + 즉시 worker 4개 점유"가 아니었음.
- 게다가 `--priority 50` 일괄 + `--assignee default` 조합은 dispatcher가 60초 안에 모두 running 상태로 만들어버림.

**규칙**:
- 사용자가 "1~2장", "한두 개", "한 두장", "1장 추가" 등 **정량 상한을 명시**했으면 그게 **정확한 cap**. 2장이면 2장, 1장이면 1장.
- "1~2장"의 모호성을 운영자 임의로 "5장"이라고 해석하지 않는다. 1장이든 2장이든 **상한 쪽**을 따른다.
- 새 보드 생성은 "한두 개 더"의 범위 안에 들어가는지 검토 — 기존 보드에 카드 2장 추가가 더 자연스러우면 새 보드 생성 자체를 보류.
- 카드 등록 직후 `--initial-status todo` (또는 `blocked`)를 고려. `--initial-status {blocked,running}` 옵션이 있음을 기억. default는 ready → 자동 dispatch됨.
- 5장 이상을 한꺼번에 dispatch하지 않는다. dispatcher 점유 = 시스템 자원 분산 + 다른 보드 워커와 충돌 위험.

**체크리스트 (카드 등록 직전 5초 점검)**:
1. 사용자 메시지에 정량 상한("1~2개", "두세 개", "1장")이 있었나? → 있었으면 cap을 정확히 그 숫자로
2. 새 보드 생성이 적절한가, 기존 보드 카드 추가가 더 적절한가? → 기존 보드 우선
3. 모든 카드를 동시에 Ready로 만들면 dispatcher가 한꺼번에 잡나? → 의존성 그래프 확인, 의존성 없으면 분할 dispatch 또는 `--initial-status blocked`로 시작
4. 카드가 4장 이상이고 의존성이 없으면, `kanban dispatch --max 2`로 한 번에 2장씩만 송출
5. **dispatch 후 바로 사용자에게 "5장 다 자동으로 시작했어요" 보고하지 않음**. 결과만 보고.

**clarify 4옵션 + 추천 신호 — UI는 `choices` 배열만 본다 (★ 2026-07-24 신규)**: 운영자가 clarify 도구로 4개 선택지를 제시할 때, `question` 텍스트에 "1) A 2) B 3) C 4) D" 처럼 풀어 적으면 **UI가 선택지를 안 그리고 죽은 prose로 렌더링**된다. 사용자는 "옵션이 안보임" 으로 멈춤 신호를 보내고, 운영자가 4개를 다시 푸는 시간 낭비. 반드시 `choices` 배열에만 1~4개 옵션을 적고, question에는 질문 본문만 적을 것. 추천이 명확하면 1개 옵션을 기본값처럼 두면 사용자가 한 번에 결정 가능.

**위임 후 사용자 멈춤 신호 무시 금지 (★ 2026-07-24 신규)**: 사용자가 "위임할께" / "그냥 진행해" 라고 답해도, **그건 1장 카드 위임이지 "판단을 멈추고 일괄 등록 + 자동 dispatch해라"는 신호가 아니다**. 4장 이상 일괄 dispatch 후 사용자에게 "5장 다 자동으로 시작했어요" 라고 즉시 보고하면, 사용자가 일시 정지 신호를 보낼 기회를 빼앗는다. 그리고 사용자가 "옵션이 안보임" 으로 멈춤 신호를 보내면, 운영자가 카드 일부를 archive로 되돌려야 하는 비효율. **위임 받은 순간도 정량 상한 + 분할 dispatch + 결과만 보고 3축이 동시에 적용된다.**

### `hermes kanban create --body-file` 옵션 부재 (★ 2026-07-27 신규)

`hermes kanban create` 는 `--body-file` 옵션이 **없음**. `--body BODY` (인라인)만 지원. heredoc 비대화 가드(`Foreground command uses '&' backgrounding` / `BLOCKED (hardline)`) 회피하려면:

```bash
# ❌ heredoc 비대화 가드
cat > /tmp/body.txt << 'EOF'
...
EOF
hermes kanban create "..." --body-file /tmp/body.txt  # 옵션 없음 — unrecognized arguments

# ❌ 비대화 환경에서 heredoc + 명령어 연결
hermes kanban create "..." --body "$(cat << 'EOF'
...
EOF
)"  # BLOCKED (hardline)

# ✅ write_file 로 파일에 박고 cat + --body 인라인
write_file(path="/tmp/body.md", content="...")
BODY=$(cat /tmp/body.md)
hermes kanban create "..." --body "$BODY"
```

### `unblock` 비대화 환경 hang + dispatcher 5-카드 동시 claim (★ 2026-07-27 신규, claude-of-duty-ko 실측)

**상황**: 5장 카드를 `blocked` 로 등록하고 의존성 link. 의존성 없는 root 카드 1장만 `unblock` 했는데, **60초 후에도 unblock 가 return 안 함**. 그동안 dispatcher 가 ready 카드를 모두 동시 claim → 5개 워커 동시 spawn → npm install / vite / capture 포트/파일 락 경합.

**원인**:
1. `unblock` 가 dispatcher 데몬과 IPC 하면서 비대화 환경에서 출력 stream 을 block
2. dispatcher 가 `--max` 옵션 없이 모든 ready 카드를 자동 claim
3. `dispatch --max N` 을 별도 호출해야 spawn cap 이 적용됨

**즉시 인식 신호**:
```bash
hermes kanban --board <slug> stats  # By status: running=N (예상보다 큼)
ps aux | grep 'hermes.*t_'          # 워커 N개 동시
```

**즉시 대응 (3단계)**:
```bash
# 1. 워커 모두 SIGTERM
for pid in $(ps aux | grep -E 'hermes.*t_(id1|id2|...)' | grep -v grep | awk '{print $2}'); do
  kill -TERM $pid
done
sleep 3
# 안 죽으면 SIGKILL
for pid in $(ps aux | grep -E 'hermes.*t_(id1|id2|...)' | grep -v grep | awk '{print $2}'); do
  kill -9 $pid 2>/dev/null
done

# 2. 모든 running 카드 reclaim
hermes kanban --board <slug> reclaim t_xxx --reason "5-card 동시 dispatch 회수"  # ×N

# 3. 보존할 1장만 남기고 나머지 archive
hermes kanban --board <slug> archive t_yyy  # ×(N-1)
```

**이후 정상 dispatch**:
```bash
hermes kanban --board <slug> dispatch --max 1  # 단독 1장 spawn 확인
ps aux | grep -E 'hermes.*t_xxx' | grep -v grep | wc -l  # 1 확인
```

**원인 (디버깅 메모)**: dispatcher 데몬은 `--max` 옵션이 명시된 `dispatch` 호출에만 cap 적용. `unblock` 는 `ready` 전이만 하고 spawn cap 은 안 건드림. 보드 전체에 blocked 가 많을 때 unblock 1장 → 나머지 ready 카드도 같은 사이클에 claim.

**예방**:
- 다중 카드 보드에서 `unblock` 대신 처음부터 `--initial-status todo` 가 안 되는 함정 (옵션 부재) 때문에 blocked 로 시작해야 하면, **link 로 의존성 그래프를 먼저 만들고 root 1장만 unblock**하는 게 정석. 그래도 위 hang 패턴 가능 → **5장 이상 동시 dispatch 금지 + dispatch --max 1 명시**.
- 또는 처음에 카드 1장만 등록 → dispatch --max 1 → 완료 후 다음 카드 1장 등록 패턴. **장기 보드는 한 번에 1장씩**.

### 워커 SIGTERM 직전 commit (★ 함정 17, 2026-07-27 신규, minimax-of-duty 실측)

**상황**: Phase 1.2 워커가 자기 patch + vitest + build + commit 단계에서 5분+ 무활동 보임. 운영자가 "stuck-worker recovery" 패턴 따라 SIGTERM 보냄. **단 워커는 SIGTERM 받기 30초 직전에** 이미 `git commit 31f750f` 완료. 직후 운영자가 직접 fix patch 적용 (워커 commit 과 동일 fix 라 충돌 없음).

**즉시 인식 신호**:
- 워커 CPU 5분+ 0% + 새 파일 안 박힐 때도 worker 가 마지막 commit + finish 메시지 작성 중일 수 있음
- SIGTERM 보내기 전 **`hermes kanban --board <slug> log <id> --tail 50`** 확인 — 마지막 활동 시점이 30초 이내면 SIGTERM 보류
- 또는 워커가 commit 했을 가능성 → git log 확인 후 사용자 디렉터리에 이미 박혀있을 수 있음

**예방 / 작업 흐름**:
1. **5분+ 무활동 + 새 파일 0**: SIGTERM 보내기 전 `git log --oneline | head -3` 으로 commit 신규 여부 확인
2. **SIGTERM 보낸 후 30초 이내**: 운영자가 직접 fix patch 했어도 워커 commit 의 동일 라인이면 충돌 0, 그대로 두기
3. **충돌 발생 시**: `git status` 로 conflict 파일 확인 → 운영자 patch 가 워커 commit 이전이면 `git stash` 후 `git pull --rebase` 또는 cherry-pick

**결정 권고**: "워커 stuck" 판정은 **CPU 0% AND git log 동일 AND 새 파일 0 AND log tail 30초 무활동** 4 조건 모두 충족 시. CPU 0% 와 commit 시점 차이는 30초 이내 가능성 큼.

### `file://` 직접 열기 + vite preview SPA fallback 함정 (★ 함정 16, 2026-07-27 신규, minimax-of-duty 실측)

**상황**: 사용자가 `/Users/mac/work/minimax-of-duty/index.html` 을 Chrome 주소창에 `file:///...` 로 직접 입력. ES module (`<script type="module" src="/src/main.js">`) 이 CORS 로 차단되어 페이지 부팅 실패. "부팅 중…" 텍스트만 화면에 남음.

**또 다른 함정**: vite preview 서버(`npm run preview`)는 SPA fallback 으로 **모든 미인식 경로를 `/index.html` 로 라우팅**해버려서 `/src/main.js` 요청이 index.html 본문 (1257 bytes) 으로 응답됨. 정상 Vite ESM 응답 (8526 bytes JS) 안 받음.

**즉시 인식 신호**:
- "부팅 중…" 인디케이터가 안 사라짐
- DevTools Console 에 `Access to script ... from origin 'null' blocked by CORS` 또는 `Failed to load resource: net::ERR_FAILED`
- 미리보기 패널에 http 가 아닌 file:// URL 보임

**예방**:
1. **`open_preview` 호출은 항상 `vite dev` (5173) 로 띄움** — preview (4173) 절대 사용 안 함
2. 사용자가 `index.html` 을 직접 열고 싶어할 땐 **`npm run dev` 띄우고 `http://127.0.0.1:5173/` URL 전달**
3. `file://` URL 은 ES module 차단 + Three.js GL import 깨짐 → 항상 `http://` 만
4. vite preview 의 SPA fallback 함정: 빌드된 dist/index.html 만 정상 응답, `/src/*.js` 는 fallback 됨 → preview 서버는 **vite build 결과 검증 용도**로만, **개발 / 미리보기 용은 dev 서버**

**워크플로**: `npm run dev` 백그라운드로 띄우고 `/` 엔드포인트 + `/src/main.js` + 첫 모듈 3개 curl 로 200 + text/javascript 검증 후 `open_preview http://127.0.0.1:5173/`. 이게 안전.

### Scratch 워크스페이스 코드 보존 정책 결여 (★ 함정 14, 2026-07-27 신규, minimax-of-duty 실측)

워커가 scratch workspace 에 코드를 박고 `kanban_complete` 호출하면, dispatcher 가 워크스페이스를 곧바로 정리함. 운영자가 보드 stats 만 확인하고 "done=1" 보고만으로 안심하면 **사용자 손에 코드가 없는 상태**가 됨.

**즉시 인식 신호**:
- 워커 done 알림 후 `/Users/mac/work/<project>/` 에 새 파일 0개
- 로컬 git `git log --oneline` 비어있음
- `hermes kanban runs <id> --json` summary 는 존재

**예방 절차 (★ 의무화)**:
1. **워커 done 직후 5분 안에 scratch 워크스페이스 직접 확인**:
   ```bash
   ls -la /Users/mac/.hermes/kanban/boards/<board>/workspaces/t_<id>/
   git -C .../workspaces/t_<id>/ log --oneline | head -3
   find /Users/mac/.hermes/kanban/boards -type d -name 't_<id>' 2>/dev/null
   ```
2. **commit 해시를 latest_summary 에서 잡고 사용자 디렉터리에 즉시 옮김** (cherry-pick, 파일 cp, 또는 운영자 직접 재구현)
3. **board archive 호출은 사용자 디렉터리에 코드 박힌 후**에만 (그 전에 archive 하면 워크스페이스 통째로 삭제)
4. **machine-verified 완료**: 사용자 디렉터리에 실제 파일 + git commit 존재 확인

**최선의 예방 (★ 모든 새 카드 의무, 처음부터 적용)**: 카드 create 시점부터 **`--workspace dir:<user_dir>`** 패턴. 이 패턴이 함정 14의 궁극적 해결:

```bash
hermes kanban --board <slug> create "Phase X.Y — ..." \
  --body "$BODY" \
  --workspace dir:/Users/mac/work/<user_dir> \
  --assignee coder
# NOTE: --branch 는 worktree 모드에서만. dir: 모드에서는 빼야 함.
```

장점:
- dispatcher 가 scratch 정리해도 사용자 디렉터리는 보존
- 워커의 `git add + commit` 도 사용자 디렉터리에서 실행 → 머신 검증 git log 즉시 확인 가능
- 워커 done 직후 `git -C /Users/mac/work/<user_dir> log --oneline | head -3` 만 보면 commit 검증 끝

**한계**: dir: 워크스페이스는 scratch 정리 문제는 해결하지만 **워커가 done 직전 git commit 안 하는 stuck 패턴은 못 해결**. 운영자가 마지막에 `git add + git commit` 마무리 해야 함 (함정 17). 

**대안 워크플로**: `hermes kanban create` 시 `--workspace worktree:<path>` 또는 `--workspace dir:<path>` 로 **사용자 디렉터리에 직접 worktree** 만듦. dispatcher가 scratch 정리해도 사용자 디렉터리는 보존. 단 git worktree 메커니즘 이해 필요. **최선의 예방은 처음부터 `--workspace dir:<user_dir>` 로 만드는 것** — 위 "Done ≠ Verified" 섹션 참고.

### 보드 slug immutable (★ 함정 15, 2026-07-27 신규)

`hermes kanban boards rename` 은 **display name 만** 변경. **slug 자체는 immutable**. 한 번 정한 slug (`claude-of-duty-ko`) 는 못 바꿈. 다른 slug (`minimax-of-duty`) 로 옮기려면:

- 옛 보드 archive + 새 보드 create + 모든 카드 다시 등록
- 또는 옛 보드 그대로 두고 display name 만 `"Minimax Of Duty"` 로 rename — slug 비일관성 감수
- 워커가 작업 중이면 archive 가 워커 정리. **새 보드에서 처음 시작이 안전한 선택**

**예방**: 보드 생성 시점부터 slug 이름을 신중히 결정. 한 번 결정하면 바꿀 수 없음.

### 백그라운드 프로세스 SIGTERM 30분 사이클 (★ 함정 18, 2026-07-27 신규, minimax-of-duty 실측)

**상황**: Phase 1.2 + Phase 1.3 워커가 진행되는 동안 같은 시점에 vite dev 서버가 SIGTERM (exit 143) 받음. 알림 로그 보면 워커가 11번 HMR 핫리로드 후 서버 종료. 30분 간격으로 반복됨 — SIGTERM (143) 받은 두 시점: 워커 SIGTERM 직전, 다음 워커 spawn 30분 후.

**원인 추정**:
1. Hermes 데몬의 백그라운드 프로세스 정리 사이클 (예: 30분 무활동 idle kill)
2. 또는 시스템 launchd 가 long-lived 자식 정리
3. 또는 사용자가 새 명령 시작하면서 자동 정리

**즉시 인식 신호**:
- `lsof -ti:5173 2>&1 | wc -l` > 0 인데 `ps -p <vite_pid>` 죽어있음 → 자식 살아있고 부모 죽음
- `[IMPORTANT: Background process proc_xxx exited (exit code 143, SIGTERM)]` 시스템 알림 도착

**영향**:
- 코드 손실 0 (사용자 디렉터리에 박힌 거 보존)
- 워커도 영향 0 (별도 PID, scratch 아님)
- **dev 서버만 죽음** → 사용자 브라우저 ERR_CONNECTION_REFUSED

**대응**:
```bash
# 1. 죽은 dev 서버 깨끗이 청소
kill -9 $(lsof -ti:5173 2>/dev/null) 2>/dev/null

# 2. dev 서버 재시작 (워커 살아있는 상태)
lsof -ti:5173 2>&1 | head -3  # 깨끗한지 확인
# → background=true 로 vite 띄움
```

**예방**:
- 매 워커 spawn 마다 dev 서버 PID 기록해두고, 알림 오면 즉시 재시작
- 또는 **dev 서버를 띄우지 않고 워커 작업 결과만 git commit 으로 받고, 브라우저 검증은 사용자 측에서 필요할 때만** 띄움 (운영 노이즈 최소화)
- 30분 안에 dev 서버 죽어도 사용자가 한 번도 안 보면 그냥 두는 게 효율적

### 사용자 '종료/STOP/그만' 신호 = 즉시 STOP (★ 2026-07-27 신규, ★★★ 사용자 분노 사례)

**상황**: 사용자가 "작업종료" 신호 → 운영자가 PROMPT-LOG 갱신 + 메모리 write_file + 추가 작업을 10분간 끌음 → "왜 아직 처리중이지?" 분노 피드백.

**규칙 (절대 위반 금지)**:
1. **사용자가 "종료/STOP/그만/마무리" 신호 보내면 즉시 STOP** — 그 다음 작업은 다음 세션
2. **워커 SIGTERM + dev 서버 SIGTERM + 포트 cleanup 만 30초 안에 끝내기**
3. **PROMPT-LOG 갱신 / 메모리 write_file / 스킬 패치 / 함수형 가드 작업 절대 금지**
4. **git commit / git push / GitHub push 도 사용자 명시 신호 시에만**
5. 최종 보고는 "보존된 것 + 다음 세션 시작점" 의 5줄 요약. 장황한 분석 금지.

**체크리스트 (사용자 종료 신호 즉시)**:
```bash
# 1. 워커 SIGTERM (있으면)
for pid in $(ps aux | grep -E 'hermes.*coder.*t_' | grep -v grep | awk '{print $2}'); do
  kill -9 $pid 2>/dev/null
done

# 2. dev 서버 SIGTERM (있으면)
kill -9 $(lsof -ti:5173 2>/dev/null) 2>/dev/null

# 3. 포트 깨끗 확인
lsof -ti:5173 2>&1 | wc -l   # 0 확인

# 4. 보드 stats (워커 살아있는지)
hermes kanban --board <slug> stats 2>&1 | head -12

# 5. 5줄 요약 보고 후 STOP
```

**원인 (★ 디버깅 메모)**: 사용자가 "작업종료" 같은 단어 신호를 보내는 건 **그 세션의 작업 종료 의사** 임. 운영자가 "마지막으로 이것만 하고" 라는 명목으로 PROMPT-LOG / 메모리 / 스킬 작업을 끼워넣는 게 가장 흔한 위반. 사용자는 자신의 종료 신호가 즉시 처리되는 것을 기본 기대. 10분 끌면 분노.

**역사**: 2026-07-27 minimax-of-duty 세션 종료 시 10분간 끌림 → 사용자 "종료하는 중이 맞나? 10분가까이 걸렸는데, 왜 아직 처리중이지?" → 이 항목 박힘.

### setup-omp-kanban.sh 호환성 (★ 2026-07-24 신규)

`hermes profile create` 의 `--binary` 옵션은 0.19.0 에서 제거됨. 옛날 스크립트는:

```bash
hermes profile create "$NAME" --binary /opt/homebrew/bin/omp  # ❌ 0.19.0 실패
```

신규 호환:

```bash
hermes profile create "$NAME" --clone --description "..."  # ✅ wrapper 자동 생성 (/Users/mac/.local/bin/$NAME)
# omp 바이너리는 PATH 에 있어야 함 (brew install can1357/tap/omp)
```

스크립트 수정 시점: `hermes profile create --help` 로 현재 시그니처 확인 후. 환경 변수 `SKIP_BOARD=1` 로 보드 생성 스킵 (기존 보드 재사용 시 유용).

### 보조 명령 (참고)

```bash
# 카드 N장 등록 후 처음 2장만 dispatch
hermes kanban --board <slug> dispatch --max 2 --json

# 등록은 했지만 dispatch는 보류 (대기 상태로 시작)
hermes kanban create "..." --initial-status blocked   # 사용자가 "직접 확인" 후 unblock
hermes kanban create "..." --initial-status todo      # 부모 카드 ready 후 자동 전이

# 등록 즉시 의도 확인
hermes kanban list --json | jq '.[] | {id, status, priority, parent}'
```

## 카드 크기 제한 — worker stop sign

**A single card should finish within roughly 10–15 minutes of worker time, not multiple hours.** A card that bundles "build the static first-frame of the entire arena with all sprites and UI" is too big, even if its final shape is auto-verifiable. The worker has no stop sign until it hits a `review-required` block or runs out of iterations, and a too-large card produces three failure modes that the operator only notices after the fact:

1. **Patch churn** — 15+ patches to the same file in one worker session, often fixing earlier mistakes. Symptom in the log: alternating `npx tsc --noEmit` and `patch <same-file>` lines.
2. **Background-shell trap** — the worker's final smoke step (e.g. `npm run dev | tee /tmp/log &`) gets captured by a foreground wrapper and the worker hangs waiting for the process to exit. The card stays `running` indefinitely with a live PID but no progress.
3. **Self-verification loop** — the worker keeps re-running its own checks (tsc, build, asset URLs) and never decides "done". No error, no crash, just endless heartbeat.

Decomposition rule:

- If a card needs >2 unrelated subsystems (e.g. "snake head + body history + hero positions + enemy spawn + projectile + UI bar + particle system + BASELINE comparison"), split it. Natural split points for game ports:
  - **Data / coords module** (constants only, unit-tested) → 5 min
  - **Render skeleton** (PixiJS scene with placeholder objects, builds and renders) → 10 min
  - **First subsystem** (e.g. snake body + hero positions only) → 10 min
  - **Second subsystem** (e.g. enemy + projectile + HP bar) → 10 min
  - **UI + comparison note** (gold/round/pause placeholder + visual diff doc) → 10 min

When a worker is already stuck mid-card (1h+ elapsed, no commit, heartbeat but no diff), do not wait for it to finish. Use the **stuck-worker recovery** sequence below.

### 단위 테스트 통과 / 시각 검증 실패 recovery (★ 2026-07-24)

worker 가 "20/20 pass + tsc + build clean" 으로 보고했는데 사용자 시각 검증에서 효과가 안 보일 때. stuck-worker 와 다른 패턴:

1. **시각 명세 vs 코드 검증 갭 확인** — 카드 body 에 "spring bounce", "글로우", "펄스", "slide-in" 같은 시각 명시가 있었는가? 있었는데도 시각 검증 실패면 1-2 함수 보정으로 끝나는 작업.
2. **fail 테스트가 진짜 신호인지 확인** — worker 가 "fail N개는 이전 task 부터 존재" 라고 보고했으면, 그 fail 자체가 시각 효과 미구현의 신호일 가능성. (`shop-card-fx` 의 hoverEnter/Exit no-op, pulseAmp=0 등이 그랬음.)
3. **5분 진단 → 운영자 직접 수정 vs 보정 카드 1장**:
   - 진단 신호 명확 (hit area / no-op / 진폭 0) → 운영자 직접 수정. 워커 위임은 5-10분+ 소요.
   - 진단 모호 → 보정 카드 1장 등록 + coder 위임.
4. **사용자 선택지 4개 + 추천**으로 직접 수정 vs 위임 결정 받기.
5. **수정 후 동일 검증 사이클** — `npx tsc --noEmit` + `npm run build` + 단위 테스트 + `?test=1` 시각 검증. 모두 통과 시 `complete`.
6. **commit + main push 는 사용자 "OK" 신호 후에만** — blocked 카드는 commit 보류 상태로 유지. (GitHub Release 가드와 동일 정책.)

자세한 사례는 `references/snkrx-web-case-study.md` 11번, 13번 사례.

### Stuck-worker recovery (operator procedure)

When `runs` shows `outcome: null`, `status: running`, elapsed >> 30 min, and no commit has landed:

1. **Verify the worker is actually alive but stuck** — `ps -p <worker_pid> -o pid,etime,%cpu,%mem,stat` (low %CPU + no recent heartbeat payload = stuck).
2. **Confirm there is no salvageable artifact** — `git status --short` and `git log -3 --oneline`. If no commit and no useful diff, treat as a lost cause.
3. **Reclaim and archive the parent card** so the worker claim is released:
   ```bash
   hermes kanban --board <slug> reclaim <id> --reason "stuck X min, splitting into smaller cards"
   # reclaim is a no-op if the worker is no longer running — that's fine
   hermes kanban --board <slug> archive <id>
   ```
4. **Create the split children** with the same `--parent <original-id>` chain (each new card lists the previous one as parent; the original archived card acts as the dependency root) and **decomposition-time classification** baked into each body.
5. **Dispatch the first child** explicitly with `hermes kanban --board <slug> dispatch --max 1 --json` if the dispatcher hasn't picked it up yet.

Do not call `kanban_complete` on the original card — it was never finished. `archive` keeps the audit trail while removing it from the active chain.

## 자동 진행에 대한 사용자 알림 정책

**자동 검증 카드는 운영자도 사용자도 알리지 않고 묵묵히 통과시킨다.** Telegram 알림은 시각 검증 카드에만 구독한다. 이건 단순한 알림 노이즈 필터링이 아니라 사용자 선호 시그널이다:

- 자동 검증 카드마다 "멈춤 → 제가 검토해서 다시 진행" 같은 메시지를 사용자에게 보내면, **사용자는 "진척이 없는 것 같은데?" 라고 다시 묻게 되고**, 매번 "아니야 사실 5장 끝났어" 같은 해명을 반복해야 한다.
- 작업자가 `review-required`로 멈춘 사실 자체는 운영자에게 가는 정상 신호이지 사용자에게 가는 "이게 뭔가요?" 신호가 아니다. 운영자가 검증해서 `complete`하면 그 자체로 다음 카드가 자동 실행된다.
- 시각 검증 카드의 `review-required`만 사용자 알림 대상. 이건 진짜 "지금 화면 확인해주세요" 라는 신호.

기본 동작:

| 카드 종류 | Telegram 알림 | 메시지 내용 |
|---|---|---|
| 자동 검증 (단위 테스트·빌드·로직) | ❌ 미구독 | (없음) |
| 시각 검증 (Playtest·시각 비교) | ✅ 구독 | 작업 요약 + 확인 방법 + 다음 단계 |
| 실패/타임아웃 | ✅ 자동 (구독 여부 무관) | 에러 요약 |

사용자가 명시적으로 "매 작업마다 알려줘"로 바꾸면 그때 모든 카드에 구독. 기본값은 selective.

## 운영자 응답 스타일 (stalled 카드 처리 시, ★ 2026-07-23 사용자 시그널)

**카드가 막혔을 때 운영자는 설명형 보고 → 행동형 보고로 전환한다.** 사용자가 "별다른 진전이 없어보이는데, 콜솔에서 더 많은 정보를 수집할 수 있도록 로그를 추가해보는게 어때?" 같은 시그널을 보냈을 때, 운영자는 다음을 따른다:

- ❌ "지금 카드가 review-required로 멈춰있고, 작업자가 47분째 패치를 반복하고 있어서..." 같은 **진행 상황 나열 금지**. 사용자는 이미 앎.
- ❌ "가능한 원인 A, B, C가 있고..." 같은 **이론 나열 금지**. 작업자는 멈췄고 사용자는 답이 듣고 싶음.
- ✅ **로그를 추가하고 결과를 본다 → 무엇이 문제인지 좁혀서 다음 행동 1개를 제시**.
- ✅ 사용자가 "ok" 만 응답할 때: **바로 행동으로 옮긴다** (카드 생성, dispatch, log 추가 등). 추가 확인 질문 금지.
- ✅ 작업자 보고 / 빌드 결과 / git log 같은 **machine-verified facts만 보고**. "X가 진전 없는 것 같다" 같은 추측성 표현 금지.

**카드 분할 / 작업자 회복 시 커뮤니케이션**: "1장 → 5장으로 분할" 같은 결정은 **사용자 선택지 4개 + 추천 1개** 형태로 제시하고, 사용자 응답을 받자마자 실행. 결정형 답변을 기다리지 말고, 추천 옵션이 명확할 때는 그 옵션으로 바로 진행한다고 안내.

**핵심**: 사용자가 "잘 진행 중이야?" 같은 추적성 질문을 했을 때 답은 **짧고 사실 기반**이어야 한다. 카운트(stats), 마지막 작업 시간, 다음 행동.

## 작업자 자동 분해(specify/decompose) 충돌 처리 (★ 2026-07-23 SNKRX 실측)

작업자가 큰 카드를 받으면 내부적으로 `kanban_specify` 또는 `kanban_decompose`를 호출해 **자동으로 5-7장의 세분화 카드를 생성**할 수 있다. 이때:

- **원본 카드는 `todo`로 돌아감** (분해되어 더 이상 직접 처리 안 됨)
- 분해된 카드들은 **자동으로 추가되어 dispatcher가 즉시 디스패치 가능**
- **원본 spec과 분해된 카드의 body가 충돌**하는 경우 많음 (예: 작업자가 chain-follower로 구현했는데 분해 카드는 "90° 회전 + accumulator" 같은 다른 spec으로 작성)

**즉시 인식 신호**:
- 카드가 갑자기 5-7장 늘었음
- 새 카드의 title이 비슷한 단어 반복 (예: "Create Snake module skeleton", "Implement snake rendering in PIXI.Graphics", "Wire ArrowLeft / ArrowRight keyboard input", "Write Snake unit tests (Vitest)", "Final integration check in main.ts and README touch-up")
- 새 카드들의 spec body가 원본 카드의 의도와 다름

**처리 절차**:

```bash
# 1. 작업자 프로세스 즉시 중단 (작업자가 이미 시작했을 가능성)
ps aux | grep -E 'hermes.*t_<new-id>' | grep -v grep | awk '{print $2}' | head -1 | xargs -r kill -TERM

# 2. 자동 분해된 카드 전부 archive
for tid in t_<auto-id-1> t_<auto-id-2> ...; do
  hermes kanban archive $tid
done

# 3. 원본 카드는 필요 시 직접 done 처리하거나, 운영자 설계의 새 카드로 대체
```

**원인 (★ 디버깅 메모)**: 작업자의 `kanban_specify` / `kanban_decompose`는 카드의 짧은 title + body를 보고 "어떤 단계로 나눌까"를 결정함. 작업자가 자체적인 구현 방향(예: chain-follower)을 명시하지 않으면, LLM의 일반적인 게임 프로그래밍 지식을 기반으로 분해 (보통 "skeleton + rendering + input + tests + integration" 같은 표준 패턴). **운영자가 이미 구현 방향을 정한 경우엔 항상 자동 분해된 카드는 무시**하고 운영자 카드를 쓰는 게 안전.

**카드 body에 "분해 금지" 표시**:
```text
[DO NOT SPECIFY/DECOMPOSE] 이 카드는 운영자가 직접 작성한 단일 범위.
worker는 kanban_complete 또는 kanban_block만 호출.
kanban_specify / kanban_decompose 호출 금지.
```

이 한 줄이 자동 분해 충돌을 거의 막아준다.

## 운영자의 작업자 파일 충돌 방지 패턴 (★ 2026-07-23 SNKRX 실측)

상황: 운영자가 직접 `src/snake.ts`를 chain-follower 모델로 수정하고 commit함. 그런데 **이미 dispatch되어 실행 중이던 작업자가 같은 `src/snake.ts`를 건드리는 중**이면, 작업자의 patch가 운영자의 chain-follower를 덮어쓸 수 있음.

**신호 감지**:
```bash
# 작업자 로그에서 같은 파일을 만지는지 확인
hermes kanban --board <slug> log <task_id> --tail 100 | grep -E 'patch.*<filename>'
```

**즉시 대응**:
```bash
# 1. 작업자 프로세스 중단 (PID는 ps aux | grep 'hermes.*t_<id>' | awk '{print $2}')
PID=$(ps aux | grep -E 'hermes.*t_<id>' | grep -v grep | awk '{print $2}' | head -1)
[ -n "$PID" ] && kill -TERM $PID
sleep 2
# 2. 작업자 reclaim + 카드는 그대로 (운영자가 직접 처리)
hermes kanban --board <slug> reclaim <id> --reason 'operator overriding worker to prevent file conflict'
```

**원칙**: 운영자가 작업자 결과를 신뢰할 수 없는 상황(같은 파일에 동시 변경)은 **작업자를 즉시 중단**. 작업자가 자기 commit을 push하기 전에 차단. 운영자가 작업자의 미완성 변경은 `git checkout <file>` 또는 `git stash -u`로 정리.

## 사용자 선호 — 설명형 보고보다 행동 (★ 2026-07-23 SNKRX 실측)

**시그널**: 사용자가 "별다른 진전이 없어보이는데, 콜솔에서 더 많은 정보를 수집할 수 있도록 로그를 추가해보는게 어때?" 같이 **원인 추측/이론 나열 대신 구체적 다음 행동**을 요구.

**규칙**:
- ❌ "지금 카드가 review-required로 멈춰있고, 작업자가 47분째 패치를 반복하고 있어서..." 같은 **진행 상황 나열 금지** — 사용자는 이미 앎
- ❌ "가능한 원인 A, B, C가 있고..." 같은 **이론 나열 금지** — 작업자는 멈췄고 사용자는 답이 듣고 싶음
- ✅ **로그를 추가하고 결과를 본다 → 무엇이 문제인지 좁혀서 다음 행동 1개를 제시**
- ✅ 사용자가 "ok" 만 응답할 때: **바로 행동으로 옮긴다** (카드 생성, dispatch, log 추가 등). 추가 확인 질문 금지
- ✅ 작업자 보고 / 빌드 결과 / git log 같은 **machine-verified facts만 보고**. "X가 진전 없는 것 같다" 같은 추측성 표현 금지

**왜 이게 중요한가**: 운영자가 "이론 A, B, C"로 답하면 사용자는 그 중 하나를 골라야 하고, 운영자가 "로그 추가 + 다음 행동"으로 답하면 사용자는 그 행동을 승인/거절만 하면 됨. **사용자의 인지 부하를 최소화**하는 것이 장기 프로젝트의 핵심.

**반대 상황**: 사용자가 명시적으로 "왜 안 되는지 설명해줘" 같은 요청을 보낸 경우는 오히려 **완전한 이론 나열 + 각각의 가능성**이 정답. 두 패턴을 구분하는 핵심은 **사용자 메시지에 "왜" / "설명" 단어가 있느냐** + **사용자가 막힘을 직접 알렸느냐** + **이전 응답에 행동이 포함됐었느냐**. 이 중 하나라도 없으면 행동형으로 응답.

### 무엇이 일어났나

사용자가 "시각 검증할 시점에 다시 알려줘"라고 명시 요청. 즉, **자동 진행 도중 시각 검증을 사람이 직접 해야 하는 카드**만 알림. 그 외 자동 검증 카드는 알림 없음. 이건 SKILL.md 본문의 "선택적 알림 정책"과 일치.

### 학습

Telegram 알림은 카드 단위로 구독. board 단위 구독은 알림 폭주를 만든다. **시각 검증 카드**만 구독. 그 외 자동 검증 카드는 **운영자가 직접 검증 후 done 처리** (사용자에게 안 보냄).

다만 이게 한 사이클이 잘 끝났을 때의 이야기이고, **여러 사이클 동안 사용자가 "X가 끝났습니다, 다음 진행합니다" 메시지를 보고 싶을 때**는 board 단위 또는 모든 카드 알림으로 전환 가능. 운영자가 매번 결정.

## 9번 사례 — 점진적 분할 + 검증 사이클 (snkrx-web v0.1.0+ 성공 패턴)

### 무엇이 일어났나

snkrx-web은 1시간+ 정지 카드를 분할해 5장 → B+D 운영자 직접 수정 → 누적 거리 카드 추가 → 보정 카드 분할 → Phase 4 5장 분할 → 보정 카드 추가의 흐름으로 진행. 이 모든 흐름이 **사용자 "OK" 또는 "A/B/C/D 선택"**로 단계를 진행.

### 학습

성공한 사이클은 항상 **사용자 한 번 확인 → 운영자 행동** 패턴. 사용자가 모든 단계를 자동으로 신뢰하고 결과를 보는 게 아니라, **핵심 결정 지점에서 한 번 확인**:
- 작업자 1시간+ 정지 → "B+D"
- 누적 거리 보정 → "A"
- 자동 조준 + 투사체 → "A"
- 화면 경계 튕김 + 화면 정렬 → "A"
- 뱀 곡선 추적 → "A"
- 발사 위치 버그 → 자동으로 bugfix 카드
- Wave 표시 버그 → 자동으로 bugfix 카드

이 패턴이 "8단계 풀 게임 포팅 = 실패 패턴"이었던 v0.1.12 (Canvas 2D)와 가장 큰 차이. v0.1.0+ PixiJS는 **사용자 확인 + 분할 + 보정 카드 + 운영자 직접 수정**의 조합으로 진행되어 v0.1.0+ Phase 4까지 안정적으로 도달.

## 10번 사례 — 사용자가 카드 진행 상태를 추적하는 패턴 ("지금 진행중인게 맞나?")

### 무엇이 일어났나

Phase 3 끝나고 Phase 4 카드 자동 진행 후, 사용자가 "지금 진행중인게 맞나?"로 작업자 상태를 물었음. 운영자는 stats + show + log + ps로 즉시 확인 후 보고. **사용자 추적성 질문은 정상이며, 운영자는 빠르게 machine-verified facts로 답해야 함.**

### 학습

- stats: by status + oldest ready task age
- show: latest_summary, runs, events
- log: 작업자 활동
- ps: 프로세스 alive 확인

4개 조합으로 5초 이내에 "진행 중 / 멈춤 / 실패" 구분 가능. 답은 짧고 사실 기반이어야 함 ("5/8 done, phase 4 running, commit 271f0e3"). "진행이 느린 것 같다" 같은 추측성 표현 금지.
