---
name: gjc-cli-setup
description: gjc (gajae-code) 터미널 코딩 에이전트 셋업 + provider 등록 + 모델 영구화 워크플로우. PATH 문제, 프리셋 등록, kilo 라우터 함정, 환경변수명 불일치 해결까지. "gjc 설치", "gjc provider 등록", "gjc 모델 변경", "gajae-code 셋업", "gjc 기본 모델" 같은 요청에 발동. (2026-07-13 라이브 검증.)
trigger: "gjc setup gajae-code provider registration model default"
---

# gjc (gajae-code) 셋업 워크플로우

> **호칭:** "희정님" 한글 통일. 한자/한문 금지.
>
> **바이너리 위치 (2026-07-13 확인):** `~/.bun/bin/gjc` → `~/.bun/install/global/node_modules/gajae-code/bin/gjc.js`

---

## 1단계: 설치 + PATH 등록

`gajae-code`는 bun global로 설치됨. **bin 디렉토리 PATH 누락 함정:**

```bash
which bun                                  # bun 자체는 /opt/homebrew/bin/bun
bun pm ls -g                               # → gajae-code@0.10.1 확인
ls -la ~/.bun/bin/                         # → gjc 심볼릭 링크 있음
echo $PATH | tr ':' '\n' | grep bun        # → 비어있으면 PATH 미등록!
```

**PATH 영구 등록:**
```bash
echo 'export PATH="$HOME/.bun/bin:$PATH"' >> ~/.zshrc
source ~/.zshrc
gjc --version                              # v0.10.1 확인
```

---

## 2단계: Provider 등록 (프리셋 사용)

내장 프리셋 3종:
- `minimax` (aliases: `minimax-code`) — MiniMax Coding Plan (글로벌)
- `minimax-cn` (aliases: `minimax-code-cn`, `minimax`) — MiniMax China
- `glm` (aliases: `zai`, `z-ai`, `bigmodel`) — GLM

**프리셋 자동 기대 env 변수명 함정:**
- `minimax` 프리셋 → `MINIMAX_CODE_API_KEY` 환경변수명 강제
- `minimax-cn` → 다른 env 변수명 (프리셋별로 다름)

**사용자 키가 다른 이름일 때 (예: `MINIMAX_API_KEY`만 있을 때):**

```bash
source ~/.hermes/secrets/minimax.env        # MINIMAX_API_KEY=sk-cp-...
export MINIMAX_CODE_API_KEY="$MINIMAX_API_KEY"
gjc setup provider --preset minimax -y --force
```

성공 시 출력:
```
✔ Provider configured
Provider 'minimax-code' configured as openai-compatible.
Preset: MiniMax Coding Plan
Models: minimax-m3
Base URL: https://api.minimax.io/v1
API key: MINI…_KEY (environment variable)
Config: /Users/mac/.gjc/agent/models.yml
```

**⚠️ 이미 등록된 provider 재설정 시 `--force` 필수** (생략 시 "already exists" 에러).

**⚠️ 직접 키 입력 (env에 키 없을 때) 비대화형은 안 됨:**
```bash
# ❌ 에러: Provider preset 'minimax' uses MINIMAX_CODE_API_KEY; omit --api-key-env or use --compat openai
gjc setup provider --preset minimax --api-key-env MINIMAX_API_KEY -y
```

→ 반드시 env 변수명 맞춰서 export 후 실행.

---

## 3단계: 모델 호출 (kilo 라우터 함정 주의)

**❌ 짧은 모델명 → kilo 라우터로 잘못 감:**
```bash
gjc --model minimax-m3 "프롬프트"
# Error: No API key for kilo/minimax/minimax-m3
```

**✅ 풀 provider ID 명시:**
```bash
gjc --model "minimax-code/minimax-m3" "프롬프트"
```

**원인:** gjc는 동일 모델명에 대해 여러 provider를 추론 시도. `minimax-m3` 단독은 kilo라는 내장 라우터로 매핑됨. kilo는 별도 OAuth/API 키가 필요하므로 인증 실패.

**함정 회피:** 항상 `provider/model` 풀 ID 사용.

---

## 4단계: 기본 모델 영구화

```bash
gjc --mpreset minimax --default
```

이후 그냥 `gjc`만 실행해도 minimax-m3가 DEFAULT로 잡힘.

**⚠️ mpreset 프로필 ID 함정 (2026-07-13 실측):**

`--mpreset`이 받는 값은 **provider ID가 아니라 모델 등급 프로필 ID**. 사용 가능한 프로필:
- `minimax-pro` → m3 (HIGH)
- `minimax-medium` → m2 (MID)
- `minimax-eco` → m1 (LOW)

```bash
# ❌ Unknown model profile "minimax-code"
gjc --mpreset minimax-code --default

# ✅ minimax-m3 영구화 성공
gjc --mpreset minimax-pro --default

# 사용 가능한 전체 프로필 목록 (다음 셸에서 시도)
gjc --mpreset <TAB>
# 또는 set mpreset 시도 후 출력에 나열되는 목록 사용
# 실제 발견된 목록: claude-fable, claude-opus, codex-eco/medium/pro,
# cursor-eco/medium/pro, fable-opus-codex, glm-eco/medium/pro,
# grok-build-pro, grok-eco/medium/pro, kimi-coding-plan-eco/medium/pro,
# mimo-eco/medium/pro, minimax-eco/medium/pro, opencodego, opus-codex
```

**alias도 같이 수정:**
```bash
alias gjcmp='gjc --mpreset minimax-pro --default'
```

## 4.5단계: `/model` UI 함정 (NEW, 2026-07-13)

`/model` 명령은 **OAuth credential 기반 provider만** 메뉴에 표시. `auth: apiKey`로 등록한 `minimax-code`는 메뉴에 안 뜸 → "로그인하세요" 안내만 나옴. **`/model` UI에서 M2로만 보이는 이유가 이것**.

**3가지 우회** (상황별 추천):

| 방법 | 상황 | 비고 |
|---|---|---|
| 1. **`gjcm` alias 사용** | API 키만 있을 때 | 가장 간단. provider/model 풀 ID로 즉시 호출 |
| 2. **OAuth credential 등록** | Coding Plan 구독자 | `gjc login minimax-code` → 브라우저 인증 → 이후 `/model`에서 잡힘 |
| 3. **`gjc --mpreset minimax-pro --default`** | 기본 모델 영구화 | 채팅 시작 시 자동으로 m3 — UI 거치지 않음 |

**OAuth 비대화형 함정**: `gjc login minimax-code`는 PTY + 브라우저 인증 필수. 비대화형 호출 시 60초 후 timeout → 무한 대기. 사용자에게 안내:
```
OAuth 로그인은 새 터미널 탭(TTY 환경)에서 직접 실행해주세요.
브라우저가 열리거나 URL이 표시되며, MiniMax 계정 로그인 후 인증 완료.
```

**📌 권장 흐름**:
- API 키만 있는 사용자 → **alias (`gjcm`)** + `--mpreset minimax-pro --default`
- Coding Plan 구독자 → 위 + OAuth 등록 (`/model` UI 가능해짐)

**alias 등록 (선택, zshrc):**

zsh에서 `export ... $(cat ...)` 같은 복합 명령은 파싱 에러 → 별도 스크립트 파일로 분리:

```bash
cat > ~/.hermes/secrets/gjc_minimax_alias.sh <<'EOF'
#!/bin/zsh
# gjc + MiniMax alias
if [[ -z "$MINIMAX_CODE_API_KEY" && -n "$MINIMAX_API_KEY" ]]; then
    export MINIMAX_CODE_API_KEY="$MINIMAX_API_KEY"
fi
[[ -d "$HOME/.bun/bin" ]] && export PATH="$HOME/.bun/bin:$PATH"
alias gjcm='gjc --model minimax-code/minimax-m3'
alias gjcmp='gjc --mpreset minimax-pro --default'
EOF

grep -q gjc_minimax_alias.sh ~/.zshrc || echo 'source ~/.hermes/secrets/gjc_minimax_alias.sh' >> ~/.zshrc
```

**⚠️ alias 비대화형 검증 함정:** `zsh -c 'alias gjcm'`처럼 비대화형 호출로는 alias 안 잡힘. 인터랙티브 셸(`zsh -ic`) 또는 새 터미널 탭에서만 작동. 검증은 `zsh -ic 'alias gjcm'`로.

---

## 5단계: 검증

```bash
gjc --model "minimax-code/minimax-m3" "ping 한 단어만 답해" -p
# → ping
```

`-p` (print) 플래그는 비대화형 모드 — 스크립트/검증용. 결과가 stdout으로 한 번에 나옴.

---

## 흔한 에러 → 해결 매트릭스

| 에러 | 원인 | 해결 |
|------|------|------|
| `gjc: 명령을 찾을 수 없음` | PATH 미등록 | `export PATH="$HOME/.bun/bin:$PATH"` |
| `No models available` | API 키 env 미설정 | env 변수 export |
| `Provider already exists` | 재등록 | `--force` 추가 |
| `uses MINIMAX_CODE_API_KEY` | env 이름 불일치 | 프리셋이 기대하는 env 이름으로 export |
| `No API key for kilo/minimax/...` | 짧은 모델명 사용 | `provider/model` 풀 ID로 변경 |
| `invalid api key (401)` | 키 자체 문제 | 키 재발급 / endpoint 확인 |
| `gjc login` 비대화형 무한 대기 | OAuth 플로우 = 브라우저 인증 필수 | PTY 환경(새 터미널)에서 사용자 직접 실행 |
| `/model` UI에서 M3 안 보임 | `/model`은 OAuth credential provider만 메뉴 표시 | alias(`gjcm`) 사용 또는 `gjc login minimax-code`로 OAuth 인증 |

---

## 한 줄 진단 명령

```bash
source ~/.hermes/secrets/minimax.env && export MINIMAX_CODE_API_KEY="$MINIMAX_API_KEY" && \
gjc --model "minimax-code/minimax-m3" "테스트" -p
```

이게 실패하면 단계별로 (PATH → provider → env → 모델 ID) 분해 진단.

---

## 모델 역할 시스템 (참고)

gjc는 4개 role에 모델 할당 가능:
- DEFAULT (기본 채팅)
- EXECUTOR (실행)
- ARCHITECT (아키텍처)
- PLANNER (계획)
- CRITIC (비평)

`/model` 명령으로 각 role에 다른 모델 매핑 가능. 예: DEFAULT=minimax-m3, ARCHITECT=claude-opus 등.

---

## zshrc 파싱 에러 함정 (2026-07-13 실측)

`export A=B $(cat file | cut ...)` 같은 복합 명령은 zsh가 파싱 에러:
```bash
export MINIMAX_CODE_API_KEY=*** MINIMAX_API_KEY=~/.her....env | cut -d= -f2- | sed 's/^export //')"
# zsh: parse error near `)'
```

**해결: 변수를 한 줄씩 분리:**
```bash
KEY=$(grep '^export MINIMAX_API_KEY=' ~/.hermes/secrets/minimax.env | cut -d= -f2-)
export MINIMAX_CODE_API_KEY="$KEY"
```

## 참고 자료

- [`templates/gjc_minimax_alias.sh`](templates/gjc_minimax_alias.sh) — zshrc에 source로 추가하는 alias 셋업 스크립트 (한 줄 source로 끝)
