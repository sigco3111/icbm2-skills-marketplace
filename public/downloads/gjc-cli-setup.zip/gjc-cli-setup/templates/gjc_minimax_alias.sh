#!/bin/zsh
# gjc + MiniMax Coding Plan alias 셋업 스크립트
# zshrc에 source 한 줄만 추가하면 됨. (alias는 인터랙티브 셸에서만 동작)
#
# 사용법:
#   1) 이 파일을 ~/.hermes/secrets/gjc_minimax_alias.sh 로 저장
#   2) ~/.zshrc 끝에 'source ~/.hermes/secrets/gjc_minimax_alias.sh' 추가
#   3) 새 터미널 열기

# 키 환경변수 매핑 (MINIMAX_API_KEY → MINIMAX_CODE_API_KEY)
# Hermes secrets/minimax.env가 MINIMAX_API_KEY로 저장되어 있는 경우 자동 변환
if [[ -z "$MINIMAX_CODE_API_KEY" && -n "$MINIMAX_API_KEY" ]]; then
    export MINIMAX_CODE_API_KEY="$MINIMAX_API_KEY"
fi

# bun global bin 경로 추가 (gjc 바이너리 위치)
[[ -d "$HOME/.bun/bin" ]] && export PATH="$HOME/.bun/bin:$PATH"

# 단축 alias
alias gjcm='gjc --model minimax-code/minimax-m3'
alias gjcmp='gjc --mpreset minimax-code --default'
alias gjcl='gjc --list-models minimax'

# 비대화형 검증용 export 함수 (alias 대신 full path 호출)
gjcm-p() { gjc --model minimax-code/minimax-m3 "$@" -p }
