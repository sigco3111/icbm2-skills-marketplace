# Quests - Templates, Plot Hooks & Storylines

## Quest Structure

### Quest Template
```
Title: [Quest Name]
Type: [Main Story | Side Quest | Faction Quest | Personal Quest]
Difficulty: [Easy | Medium | Hard | Extreme]
Location: [Where it takes place]
Quest Giver: [NPC who provides quest]
Objectives: [Clear goals, 3-5 steps]
Rewards: [XP, gold, items, reputation]
Risks: [Potential dangers, failure consequences]
Prerequisites: [Level, items, completed quests]
```

### Quest Types

**Fetch Quests:** Retrieve item/object for NPC
- Example: "Retrieve the Ancient Scroll from the Crypt"
- Variation: Retrieve from dangerous location, guarded area, hidden cache

**Kill Quests:** Defeat specific enemies
- Example: "Slay the Bandit Leader threatening the village"
- Variation: Clear entire area, boss fight, multiple targets

**Escort Quests:** Protect NPC while traveling
- Example: "Escort the merchant safely to Crossroads"
- Variation: Multiple escorts, timed, through dangerous territory

**Investigation Quests:** Gather clues, solve mystery
- Example: "Investigate the murders in Stormhaven's slums"
- Variation: Missing person, stolen item, conspiracy unraveling

**Diplomatic Quests:** Negotiate, persuade, mediate
- Example: "Mediate peace between the elves and dwarves"
- Variation: Trade agreement, alliance, faction politics

**Crafting Quests:** Create specific items
- Example: "Forge a sword worthy of a king"
- Variation: Brew potion, enchant item, construct weapon

**Exploration Quests:** Discover new areas
- Example: "Map the uncharted caves in the mountains"
- Variation: Find lost city, explore ruins, discover resource

## Fantasy Quest Hooks

### Main Story Hooks

**The Ancient Prophecy**
- Hook: Player discovers an ancient prophecy about their destiny
- Progression: Unravel prophecy, gather allies, confront threat
- Climax: Fulfill destiny (or choose own path)
- Variants: Chosen hero, accidental hero, reluctant hero

**The Dark Lord's Rise**
- Hook: Villain begins conquest, spreads darkness
- Progression: Defeat minions, gather allies, reach enemy stronghold
- Climax: Final battle against Dark Lord
- Variants: Redemption arc, sacrifice ending, secret alliance

**The Lost Artifact**
- Hook: Powerful artifact scattered across world, must collect
- Progression: Find pieces, solve puzzles, defeat guardians
- Climax: Reassemble artifact, make choice on its use
- Variants: Destroy artifact, use artifact, hide artifact forever

### Side Quest Hooks

**Village Troubles**
- "The crops are withering—evil magic?"
- "Werewolves hunting at night"
- "Mysterious illness spreading"

**Personal Requests**
- "Find my missing daughter"
- "Recover family heirloom"
- "Avenger my father's murder"

**Merchant Tasks**
- "Escort my caravan to trade fair"
- "Stop bandits on the road"
- "Deliver urgent message to lord"

**Mystery Investigations**
- "Strange lights at the old ruins"
- "People disappearing from tavern"
- "Corruption in the city guard"

**Crafting Requests**
- "Forge me a sword of dragon bone"
- "Brew a potion that cures poison"
- "Craft an amulet of protection"

### Faction Quest Hooks

**Silver Council**
- "Investigate reports of dark magic in the forest"
- "Destroy the necromancer's lair"
- "Recruit new mages to the council"

**Merchant League**
- "Disrupt competitor's supply line"
- "Negotiate better trade terms with dwarves"
- "Smuggle goods past blockade"

**Rangers of the Wild**
- "Track the beast killing livestock"
- "Protect the forest from loggers"
- "Rescue captured ranger"

**Shadow Syndicate**
- "Assassinate the merchant who won't pay"
- "Steal the royal jewels"
- "Corrupt the town guard"

## Sci-Fi Quest Hooks

### Main Story Hooks

**The First Contact**
- Hook: Aliens arrive at colony—is it peace or war?
- Progression: Communicate, understand motives, defend or cooperate
- Climax: Diplomatic resolution or space battle
- Variants: Peaceful aliens, deceptive aliens, misunderstanding

**The Corporate Conspiracy**
- Hook: Discover evidence of corporate crimes
- Progression: Gather proof, expose publicly, survive retaliation
- Climax: Confront CEO, reveal truth to all colonies
- Variants: Cover-up succeeds, partial revelation, justice served

**The Ancient Ruins**
- Hook: Alien technology discovered in ruins
- Progression: Explore ruins, reverse-engineer tech, unlock secrets
- Climax: Activate ancient machine, make choice about its power
- Variants: Terraforming device, weapon, stasis chamber

### Side Quest Hooks

**Colony Problems**
- "Life support failing in Sector 7"
- "Marauders attacking mining outpost"
- "Rebels sabotaging terraforming"

**Personal Requests**
- "Help my android achieve sentience"
- "Find my brother's last transmission"
- "Smuggle illegal memories off-planet"

**Corporate Jobs**
- "Retrieve stolen prototype"
- "Sabotage competitor's research"
- "Negotiate mining rights with rebels"

**Mystery Investigations**
- "Strange signal coming from asteroid field"
- "Crew members going insane on space station"
- "Alien artifacts affecting colonists"

**Tech Research**
- "Reverse-engineer alien weapon"
- "Develop terraforming bacteria"
- "Create FTL drive prototype"

## Modern Quest Hooks

### Main Story Hooks

**The Serial Killer**
- Hook: Bodies piling up, pattern emerges
- Progression: Investigate crime scenes, profile killer, narrow suspects
- Climax: Confront killer, rescue final victim
- Variants: Killer is supernatural, killer is copycat, killer is accomplice

**The Conspiracy**
- Hook: Discover evidence of city-wide conspiracy
- Progression: Follow clues, avoid assassination, expose truth
- Climax: Confront mastermind, public revelation
- Variants: Cover-up succeeds, partial exposure, full revelation

**The Supernatural Awakening**
- Hook: Player gains supernatural powers or witnesses supernatural event
- Progression: Learn powers, uncover origin, fight related threats
- Climax: Battle supernatural mastermind
- Variants: Vampire awakening, werewolf curse, ghost possession

### Side Quest Hooks

**Neighborhood Problems**
- "Gang members harassing elderly"
- "Missing children from park"
- "Stray dogs attacking mailman"

**Personal Requests**
- "Find my missing spouse"
- "Clear my friend's name"
- "Retrieve stolen family heirloom"

**Police Work**
- "Patrol high-crime district"
- "Investigate warehouse break-in"
- "Testify in court case"

**Mysteries**
- "Lights in abandoned factory"
- "Strange symbols appearing in the city"
- "People claiming to see monsters"

**Supernatural Cases**
- "Vampire preying on nightclubs"
- "Werewolf transforming in full moon"
- "Ghost haunting historic mansion"

## Quest Complications

**Unexpected Twists:**
- Quest giver is actually the villain
- Item you're retrieving is cursed
- "Victims" are actually villains
- Multiple parties want the same thing
- Time pressure added mid-quest

**Moral Dilemmas:**
- Save one person or save many?
- Kill villain or imprison for trial?
- Use evil artifact to defeat greater evil?
- Betray ally to achieve goal?
- Reveal truth that hurts innocent?

**Environmental Challenges:**
- Weather storm complicates travel
- Natural disaster during quest
- Terrain collapse blocks path
- Disease outbreak in area
- Resource scarcity

**Social Complications:**
- NPC companion has secret agenda
- Faction relationships change mid-quest
- Rumors affect NPC trust
- Bounty hunters pursue player
- Family member involved

## Quest Rewards

**XP Rewards:**
- Easy: 50-100 XP
- Medium: 100-250 XP
- Hard: 250-500 XP
- Extreme: 500-1000+ XP

**Gold Rewards:**
- Easy: 10-50 gold
- Medium: 50-150 gold
- Hard: 150-400 gold
- Extreme: 400-1000+ gold

**Item Rewards:**
- Unique weapons/armor
- Magical artifacts
- Consumables (potions, scrolls)
- Crafting materials
- Keys/passwords/access

**Reputation Rewards:**
- Faction standing increase
- Discounts from merchants
- Access to new areas
- NPC relationships
- Quest opportunities unlock

**Ability Rewards:**
- New skill or technique
- Attribute boost
- Special ability
- Companion ally
- Secret knowledge

## Multi-Part Questlines

### Example: The Bandit King

**Part 1: The First Strike**
- Quest: Defeat bandit raiders on the road
- Reward: 50 XP, 20 gold
- Unlock: Part 2

**Part 2: Tracking the Hideout**
- Quest: Follow tracks to bandit camp
- Reward: 100 XP, map of camp
- Unlock: Part 3

**Part 3: The Scout**
- Quest: Infiltrate camp, gather intel
- Reward: 150 XP, guard schedule
- Unlock: Part 4

**Part 4: The Rescue**
- Quest: Free prisoners before attack
- Reward: 200 XP, prisoner allies
- Unlock: Part 5

**Part 5: The Bandit King**
- Quest: Defeat Bandit King in his fortress
- Reward: 500 XP, 300 gold, Bandit King's Sword (+8 damage)
- Completion: Unlocks new reputation with Merchant League

### Example: The Conspiracy

**Part 1: Suspicious Activity**
- Quest: Investigate strange warehouse activity
- Reward: 75 XP, document fragment
- Unlock: Part 2

**Part 2: The Whistleblower**
- Quest: Meet informant who knows more
- Reward: 125 XP, list of names
- Unlock: Part 3

**Part 3: Corporate Espionage**
- Quest: Infiltrate corporation, steal evidence
- Reward: 200 XP, incriminating files
- Unlock: Part 4

**Part 4: The Setup**
- Quest: Player framed for crimes, must clear name
- Reward: 250 XP, allies' help
- Unlock: Part 5

**Part 5: The Revelation**
- Quest: Publicly expose conspiracy to news media
- Reward: 500 XP, corporate downfall
- Completion: Unlocks new main story arc

## Dynamic Quest Generation

When player creates unexpected actions:
- Generate new quest based on their choice
- Adapt existing quest to incorporate new path
- Create consequences for unexpected decisions
- Reward creative problem-solving

Example: Player decides to negotiate with bandit instead of fighting:
- New quest: "Diplomatic Resolution"
- Objectives: Persuade bandit leader, find peaceful solution
- Reward: 300 XP, reputation boost, possible ally
- Risk: Bandit might betray, reputation with others affected
