# Mechanics - Game Rules, Formulas & Systems

## Core Game Rules

### Dice System

**Standard Dice Notation:**
- d4 = 4-sided die (1-4)
- d6 = 6-sided die (1-6)
- d8 = 8-sided die (1-8)
- d10 = 10-sided die (1-10)
- d12 = 12-sided die (1-12)
- d20 = 20-sided die (1-20)

**Rolling Rules:**
- Natural 20 (d20): Critical success (double effect)
- Natural 1 (d20): Critical failure (backfires)
- Advantage: Roll twice, take higher result
- Disadvantage: Roll twice, take lower result

**Damage Formulas:**
```
Melee Damage = Weapon Dice + STR modifier
Ranged Damage = Weapon Dice + DEX modifier
Magic Damage = Spell Dice + INT/WIS modifier
```

## Combat System

### Turn Order

**Initiative:**
```
Initiative Roll = d20 + DEX modifier + (INT ÷ 4)
Highest roll goes first, descending order
```

**Turn Structure:**
1. **Movement:** Up to 30 feet (or action-specific)
2. **Action:** Attack, cast spell, use ability, item
3. **Bonus Action:** Minor action (if available)
4. **Reaction:** Opportunity attacks, spells (if available)

**Action Types:**
- **Attack:** Make weapon or spell attack
- **Cast Spell:** Use magic (requires concentration for duration spells)
- **Dash:** Double movement speed
- **Disengage:** Move without provoking opportunity attacks
- **Dodge:** +2 to all defense rolls until next turn
- **Help:** Give ally advantage on next roll
- **Hide:** Make Stealth check to become unseen
- **Ready:** Prepare action to trigger on condition
- **Search:** Make Perception check to find hidden items
- **Use Object:** Interact with item (door, lever, potion)

### Attack Resolution

**Standard Attack:**
```
Attack Roll = d20 + Stat + Proficiency + Weapon Bonus
Defense = Enemy AC (Armor Class)
Hit if Attack Roll ≥ Defense
Damage if Hit = Weapon Dice + Stat Modifier
```

**Example Attack:**
```
Player (STR 16, +6 Melee Weapons) attacks goblin (AC 13)
Attack Roll = d20 + 3 (STR) + 2 (Proficiency) = d20 + 5
Result: Attack Roll = 18 (hit)
Damage = 1d8 (sword) + 3 (STR) = 1d8 + 3
Damage Roll: 6 + 3 = 9 damage
```

**Critical Hit (Natural 20):**
```
Damage = (Weapon Dice × 2) + Stat Modifier
Attack automatically hits
```

**Miss:**
- No damage dealt
- Some abilities trigger on miss (special effects)

### Defense

**Armor Class (AC):**
```
Base AC = 10 + DEX modifier
+ Armor Bonus (Light: +2, Medium: +4, Heavy: +5)
+ Shield Bonus (+2 or +4)
```

**Dodge Action:**
```
AC Bonus = +2 for 1 turn
```

**Cover:**
- Half cover: +2 AC
- Three-quarters cover: +3 AC
- Full cover: +5 AC, cannot be targeted directly

### Status Effects

**Common Status Effects:**

**Poisoned:**
- Disadvantage on attack rolls and ability checks
- Duration: 1-10 turns (varies by source)
- Cure: Poison antidote, magical healing

**Burning:**
- 1d4 damage at start of each turn
- Duration: 3-6 turns
- Cure: Water, healing magic, end turn in water

**Stunned:**
- Cannot move, act, or react
- Disadvantage on saving throws
- Duration: 1-2 turns
- Cure: Make CON save (DC varies)

**Prone:**
- Movement reduced to 5 feet
- Disadvantage on attack rolls
- Advantage against melee attacks from standing enemies
- Cure: Stand up (half movement)

**Paralyzed:**
- Incapable of movement or action
- Automatically fails STR and DEX saves
- Advantage on melee attack rolls against paralyzed
- Duration: 1-4 turns
- Cure: Make CON save (DC varies)

**Invisible:**
- Cannot be seen by normal vision
- Disadvantage on attack rolls
- Advantage on attack rolls against visible enemies
- Duration: Until attack or end of spell
- Cure: Dispel magic, reveal by dust, see invisibility

**Bleeding:**
- 1d6 damage at start of each turn
- Duration: Until treated or death
- Cure: Medicine check (DC 15), magical healing

**Fear:**
- Disadvantage on attack rolls and ability checks
- Must move away from fear source
- Duration: 1-6 turns
- Cure: Make WIS save (DC varies), end of effect source

## Skill System

### Skill Checks

**Standard Skill Check:**
```
Skill Check = d20 + Stat Modifier + Proficiency Bonus
Difficulty Class (DC) determines success/failure
```

**Difficulty Classes:**
- Very Easy: DC 5
- Easy: DC 10
- Medium: DC 15
- Hard: DC 20
- Very Hard: DC 25
- Nearly Impossible: DC 30

**Proficiency Bonus:**
- Level 1-4: +2
- Level 5-8: +3
- Level 9-12: +4
- Level 13-16: +5
- Level 17-20: +6

**Example Skill Checks:**
```
Perception (WIS 14, Trained +2) to spot hidden door
Skill Check = d20 + 2 (WIS) + 2 (Proficiency) = d20 + 4
DC = 15 (Medium)
Player rolls 12 + 4 = 16 (success!)

Deception (CHA 12, Untrained) to lie to guard
Skill Check = d20 + 1 (CHA) = d20 + 1
DC = 13 (Hard, guard is alert)
Player rolls 7 + 1 = 8 (failure!)
```

### Specialized Skills

**Stealth:**
```
Stealth Check = d20 + DEX + Proficiency
vs Enemy Perception
Success = Unseen, advantage on next attack
```

**Persuasion:**
```
Persuasion Check = d20 + CHA + Proficiency
vs Target's WIS + Relationship Modifier
Success = Target agrees or provides help
```

**Lockpicking:**
```
Lockpicking Check = d20 + DEX + Proficiency
vs Lock DC (10-30)
Critical failure = Lockpick breaks
```

**Tracking:**
```
Tracking Check = d20 + WIS + Proficiency
vs Trail DC (varies by age, terrain)
Success = Follow trail, identify what passed
```

## Magic System

### Spell Slots

**Spell Slots per Level (Cleric/Wizard):**
- Level 1: 4 slots
- Level 2: 3 slots
- Level 3: 3 slots
- Level 4: 2 slots
- Level 5: 2 slots

**Cantrips:** Unlimited casts (level 0 spells)

### Casting Spells

**Spell Attack:**
```
Spell Attack Roll = d20 + Casting Stat + Proficiency
vs Target's Saving Throw DC or AC
```

**Saving Throws:**
```
Save DC = 8 + Spell Level + Casting Stat + Proficiency
Target rolls saving throw vs DC
Success = Half damage or no effect
```

**Spell Duration:**
- Instant: Immediate effect, no duration
- Concentration: Requires concentration check when damaged (DC 10 or half damage)
- Timed: Lasts for specified time

**Example Spell Casting:**
```
Mage (INT 18, Level 5) casts Fireball (Level 3)
Spell Attack Roll = d20 + 4 (INT) + 3 (Proficiency) = d20 + 7
Damage = 8d6 (Fireball)
Target makes DEX save vs DC = 8 + 3 (Level) + 4 (INT) + 3 (Proficiency) = 18
Target rolls 14 (failure) → Full damage: 8d6 = 28 damage
```

## Strategy Game Mechanics

### Resource Production

**Base Production Formula:**
```
Production Per Turn = Base × Building Multiplier × Technology Multiplier
```

**Building Multipliers:**
- Farm: ×2 food production
- Mine: ×2 mineral production
- Lumber Mill: ×2 wood production
- Market: ×1.5 gold income
- Barracks: ×1.5 unit production

**Technology Multipliers:**
- Agriculture Tech: +10-50% food
- Mining Tech: +10-50% minerals
- Lumber Tech: +10-50% wood
- Trade Tech: +10-50% gold
- Military Tech: +10-50% unit strength

### Population Growth

**Growth Formula:**
```
Population Growth = Current Population × Growth Rate × Happiness × Stability
Growth Rate = Base 2% + Bonuses
Happiness = 0.5-1.5 multiplier (Stability affects this)
Stability = 0.5-1.5 multiplier (War, crime, corruption reduce this)
```

**Example:**
```
Population: 10,000
Growth Rate: 3% (with Agriculture Tech)
Happiness: 1.2 (with festivals)
Stability: 0.8 (minor war)
Growth = 10,000 × 0.03 × 1.2 × 0.8 = 288 new people
```

### Research System

**Research Points Formula:**
```
Research Per Turn = (Labs × 10) + (Scholars × 5) × Technology Bonus
```

**Research Costs:**
- Basic Tech: 100-500 points
- Intermediate Tech: 500-2000 points
- Advanced Tech: 2000-10000 points
- Revolutionary Tech: 10000+ points

**Technology Trees:**
```
Agriculture → Irrigation → Crop Rotation → Genetically Modified Crops
Military → Bronze Age → Iron Age → Steel Age → Gunpowder → Modern Warfare
```

### Combat (Strategy)

**Army Strength:**
```
Army Power = Σ(Unit Count × Unit Strength × Tech Bonus)
Unit Strength: Infantry (1), Cavalry (1.5), Archers (1.2), Siege (2)
Tech Bonus: Military Tech level × 0.1
```

**Battle Resolution:**
```
Attack Power = Army Power × (1 + General Skill × 0.1)
Defense Power = Army Power × (1 + Terrain Bonus)
Defender Bonus: Walls (+20%), Hills (+15%), Forest (+10%)
Damage Dealt = Attack Power × (1 - Defense Factor / 2)
```

**Example Battle:**
```
Attacker: 1000 Infantry (Strength 1) + 100 Cavalry (Strength 1.5) + Tech Level 2
Attack Power = (1000×1 + 100×1.5) × (1 + 2×0.1) = 1150 × 1.2 = 1380

Defender: 800 Infantry + 100 Archers + Tech Level 1 + Hill Terrain
Defense Power = (800×1 + 100×1.2) × (1 + 1×0.1 + 0.15) = 920 × 1.25 = 1150

Damage = 1380 × (1 - 1150/(1380+1150)) = 1380 × 0.46 = 635 casualties
```

## Survival Mechanics

### Hunger & Thirst

**Hunger:**
```
Time Without Food = Constitution × 8 hours
After starvation: 1 CON damage per hour
Death when CON = 0
```

**Thirst:**
```
Time Without Water = Constitution × 4 hours
After dehydration: 1 CON damage per 4 hours
Death when CON = 0
```

### Environmental Hazards

**Extreme Heat:**
```
Check: CON save (DC varies by temperature)
Failure: 1 level exhaustion
Exhaustion levels: Disadvantage on checks, speed halved, HP max halved, death
```

**Extreme Cold:**
```
Check: CON save (DC varies by temperature)
Failure: 1 level exhaustion
Protection needed: Cold weather gear, magical protection
```

**Altitude:**
```
Above 10,000 feet: One level exhaustion every hour
Acclimatization needed: 1 week per 10,000 feet
```

**Drowning:**
```
Hold breath: Constitution × 1 minute
After that: 1 CON damage per round
Death when CON = 0
```

## Social Mechanics

### Reputation System

**Reputation Scale:**
- -100: Hated (NPCs attack on sight, no services)
- -50: Hostile (High prices, limited services)
- 0: Neutral (Standard prices, standard services)
- 50: Friendly (Discounts, special quests)
- 100: Hero (Free services, fan following, leadership offers)

**Reputation Changes:**
- Help village: +10 reputation
- Complete major quest: +20 reputation
- Defeat villain: +30 reputation
- Betray ally: -30 reputation
- Murder innocent: -50 reputation
- Slay dragon: +50 reputation

### Relationship System

**NPC Attitude:**
- Hostile: Will attack, refuses help
- Unfriendly: Reluctant to help, high prices
- Neutral: Standard interaction
- Friendly: Helpful, discounts
- Devoted: Will risk life for player

**Improving Relationships:**
```
Persuasion check (DC varies): Success = +1 relationship
Gift giving (value × 0.1): +1 relationship per 10 gold worth
Quest completion: +5 relationship
Shared experiences: +2 relationship
```

**Deteriorating Relationships:**
- Failed persuasion: -1 relationship
- Betrayal: -10 relationship
- Refuse request: -2 relationship
- Offend: -3 relationship

## Travel Mechanics

### Movement Speeds

**Travel Speeds:**
```
Walk: 3 miles per hour (30 feet per round)
Hustle: 6 miles per hour (fatigue check every hour)
Run: 12 miles per hour (exhaustion every 10 minutes)
Mount: 6 miles per hour (30 feet per round)
```

**Travel Time Calculation:**
```
Travel Time = Distance ÷ Speed
Add terrain modifier: Plains ×1, Forest ×1.5, Mountains ×2, Swamp ×2.5
```

**Example:**
```
Distance: 30 miles, Forest terrain
Walking Time = 30 ÷ 3 × 1.5 = 15 hours
```

### Encounters

**Encounter Check:**
```
Check per travel day: d100
Encounter if roll ≤ Danger Level
Danger Levels: Safe (10), Moderate (25), Dangerous (40), Lethal (60)
```

**Encounter Types:**
- Combat: Hostile creatures
- Social: Friendly or neutral NPCs
- Environmental: Weather, terrain hazards
- Discovery: Hidden locations, treasure
- Mystery: Strange occurrences

### Camp Mechanics

**Setting Camp:**
```
Time Required: 1 hour to set up camp
Benefits: Recover HP, prepare meals, rest for travel
Risks: Possible night encounter if in dangerous area
```

**Watch System:**
```
Watch Duration: 4 hours per watch
Party Size: Minimum 2 people for rotation
Perception Check: d20 + WIS + Proficiency during watch
Success = Detect approaching danger early
```

## Economy Mechanics

### Equipment Prices

**Weapons:**
- Dagger: 5 gold
- Sword: 25 gold
- Greatsword: 50 gold
- Bow: 40 gold
- Crossbow: 50 gold

**Armor:**
- Leather: 10 gold
- Chainmail: 40 gold
- Plate: 150 gold
- Shield: 10 gold

**Magic Items:**
- +1 Weapon: 200 gold
- +2 Weapon: 800 gold
- Potion of Healing: 50 gold
- Scroll of Magic Missile: 75 gold

### Crafting

**Crafting Time:**
```
Time Required = (Item Value ÷ 50) × Difficulty Modifier
Difficulty: Simple ×1, Medium ×2, Complex ×4
```

**Crafting Success:**
```
Crafting Check = d20 + Stat + Proficiency
vs Item DC (15-30)
Success = Item created
Critical Success = Masterwork item (+1 bonus)
Failure = Materials wasted, half value lost
Critical Failure = Explosion, fire, materials destroyed
```

### Trading

**Buying Prices:**
```
Price = Base Price × (1 + Merchant Markup)
Markup: 10-50% (varies by relationship)
Discount applies with high reputation
```

**Selling Prices:**
```
Price = Base Price × (1 - Merchant Take)
Merchant Take: 30-60% (varies by relationship, item type)
```

**Haggling:**
```
Haggle Check = d20 + CHA + Proficiency
vs Merchant DC (varies)
Success = Reduce price/markup by 10% per 5 over DC
```

## Game Balance Guidelines

### Difficulty Scaling

**Scaling Encounters:**
```
Player Level × 2 = Appropriate challenge level
Level 1 Party (4 players) vs 4 Level 2 enemies = Medium difficulty
Level 5 Party vs 8 Level 5 enemies = Hard difficulty
```

**Reward Scaling:**
```
XP Reward = Challenge Level × 10
Gold Reward = Challenge Level × 2
Item Quality = Match to level (magical items at level 3+)
```

### Pacing

**Game Session Structure:**
```
Warm-up (10-15 min): Recap, check status, minor interactions
Main Activity (60-90 min): Quest progress, combat, exploration
Wind-down (10-15 min): Rest, level up, plan next session
```

**Pacing Principles:**
- Mix combat, exploration, and roleplay
- Vary intensity between scenes
- Include meaningful choices
- Allow for player improvisation
- Keep sessions moving forward

### Fun vs. Simulation

**Prioritize Fun When:**
- Simulation would punish player creativity
- Rules unclear or missing
- Cool moment at stake
- Player enjoyment at risk

**Prioritize Simulation When:**
- Consequences are important for future
- Player expects realism
- Consistency matters
- Challenge is key

**Always:**
- Be fair and consistent
- Communicate expectations
- Allow player agency
- Maintain game flow
