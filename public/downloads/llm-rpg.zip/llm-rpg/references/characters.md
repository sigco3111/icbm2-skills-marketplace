# Characters - Character Creation & Archetypes

## Character Stats System

### Core Attributes (1-20 scale)
- **Strength (STR)** - Physical power, melee damage, carrying capacity
- **Dexterity (DEX)** - Agility, reflexes, ranged accuracy, stealth
- **Constitution (CON)** - Health, stamina, poison resistance
- **Intelligence (INT)** - Learning, memory, logic, magical aptitude
- **Wisdom (WIS)** - Perception, insight, willpower
- **Charisma (CHA)** - Leadership, persuasion, deception, appearance

### Derived Stats
```
HP = CON × 10 + STR × 2
MP = INT × 8 + WIS × 2
Carry Capacity = STR × 15 lbs
Initiative = DEX + (INT ÷ 4)
```

### Skills
Each skill has proficiency level: Untrained (0), Trained (+2), Expert (+4), Master (+6)

**Combat Skills:**
- Melee Weapons (STR)
- Ranged Weapons (DEX)
- Unarmed Combat (STR)
- Defense (DEX)

**Magic Skills:**
- Elemental Magic (INT)
- Healing Magic (WIS)
- Dark Magic (INT)
- Light Magic (WIS)

**Social Skills:**
- Persuasion (CHA)
- Deception (CHA)
- Intimidation (CHA)
- Insight (WIS)

**Exploration Skills:**
- Stealth (DEX)
- Perception (WIS)
- Survival (WIS)
- Knowledge (INT)

## Character Archetypes

### Fighter
**Focus:** Combat excellence, durability, leadership
**Primary Stats:** STR, CON, DEX
**Starting Equipment:** Sword, shield, chainmail, 50 gold
**Abilities:**
- Power Strike: Deal double damage, cooldown 3 turns
- Shield Wall: +5 defense for 2 turns
- Battle Cry: Allies get +2 attack for 3 turns

**Example Build:**
```
Name: Kaelen Ironheart
STR 16 | DEX 12 | CON 15 | INT 10 | WIS 11 | CHA 13
Skills: Melee Weapons (+6), Defense (+4), Intimidation (+4)
Equipment: Steel longsword (+5 damage), Tower Shield (+4 defense), Chainmail (+3 AC)
```

### Mage
**Focus:** Spellcasting, knowledge, utility
**Primary Stats:** INT, WIS, DEX
**Starting Equipment:** Staff, robes, spellbook, 30 gold
**Abilities:**
- Fireball: 4d6 fire damage, area effect
- Ice Shard: 2d8 ice damage, slow target
- Shield Barrier: +8 temporary HP
- Teleport: Move up to 30 ft instantly

**Example Build:**
```
Name: Elara Stormwind
STR 8 | DEX 14 | CON 10 | INT 18 | WIS 16 | CHA 12
Skills: Elemental Magic (+6), Knowledge (+4), Perception (+2)
Equipment: Oak staff (+2 magic), Robes of Arcane Wisdom (+1 INT), Spellbook
Spells: Fireball, Ice Shard, Shield Barrier, Teleport, Light, Detect Magic
```

### Rogue
**Focus:** Stealth, precision, thievery
**Primary Stats:** DEX, INT, CHA
**Starting Equipment:** Dagger, leather armor, lockpick set, 40 gold
**Abilities:**
- Backstab: +4 damage when attacking from behind
- Shadow Step: Teleport to shadows, gain invisibility for 1 turn
- Pickpocket: Steal item without detection (DC 15)
- Evasion: Dodge area attacks with DEX check

**Example Build:**
```
Name: Thorne Blackwood
STR 10 | DEX 18 | CON 12 | INT 14 | WIS 12 | CHA 15
Skills: Stealth (+6), Ranged Weapons (+4), Deception (+4), Perception (+4)
Equipment: Enchanted dagger (+4 damage), Leather armor (+2 AC), Lockpicks
```

### Paladin
**Focus:** Holy magic, tanking, healing
**Primary Stats:** STR, CON, WIS, CHA
**Starting Equipment:** Holy sword, heavy armor, holy symbol, 60 gold
**Abilities:**
- Smite Evil: +10 damage vs. evil enemies
- Lay on Hands: Heal ally for 1d10 + CHA
- Divine Shield: +10 AC, immune to fear for 2 turns
- Turn Undead: 2d10 damage to undead, DC 15 + CHA

**Example Build:**
```
Name: Seraphina Dawnbringer
STR 15 | DEX 10 | CON 16 | INT 12 | WIS 14 | CHA 15
Skills: Melee Weapons (+4), Defense (+4), Healing Magic (+4)
Equipment: Holy avenger sword (+6 damage), Plate armor (+5 AC), Holy Symbol
Spells: Lay on Hands, Turn Undead, Bless, Cure Wounds
```

### Ranger
**Focus:** Tracking, ranged combat, survival
**Primary Stats:** DEX, WIS, CON
**Starting Equipment:** Longbow, light armor, survival gear, 45 gold
**Abilities:**
- Precise Shot: +4 ranged damage, ignores cover
- Track: Follow tracks (DC 12 + WIS)
- Animal Companion: Wolf companion (HP 20, damage 1d6+3)
- Hunter's Mark: Mark target, deal +1d6 damage per hit

**Example Build:**
```
Name: Kaelen Wildrunner
STR 12 | DEX 17 | CON 14 | INT 10 | WIS 16 | CHA 11
Skills: Ranged Weapons (+6), Survival (+6), Perception (+4), Stealth (+2)
Equipment: Masterwork longbow (+5 damage), Leather armor, Survival kit
Companion: Shadow (Wolf) - HP 20, AC 14, Damage 1d6+3, Special: Pack Tactics
```

## Strategy Mode - Faction Leaders

### Empire
**Focus:** Military might, expansion, taxation
**Resources:** Gold, Food, Production, Happiness
**Unique Units:** Legionnaires, Ballistae, Catapults
**Buildings:**
- Barracks: +2 unit production, unlock Legionnaires
- Palace: +5 gold/turn, unlock Ballistae
- Market: +10% trade income

### Kingdom
**Focus:** Diplomacy, trade, culture
**Resources:** Gold, Culture, Influence, Food
**Unique Units:** Knights, Diplomats, Merchants
**Buildings:**
- Castle: +3 defense, +1 unit production
- University: +2 culture/turn, unlock Diplomats
- Harbor: +20% naval trade

### Republic
**Focus:** Innovation, research, commerce
**Resources:** Gold, Science, Influence, Production
**Unique Units:** Scholars, Engineers, Merchants
**Buildings:**
- Laboratory: +3 science/turn, unlock Engineers
- Bank: +15% gold income
- Factory: +2 production, +10% resource output

## NPC Templates

### Town Guard
```
STR 12 | DEX 10 | CON 12 | INT 10 | WIS 10 | CHA 10
HP: 40 | AC: 14 | Damage: 1d6+3 (sword)
Attitude: Helpful to law-abiding, suspicious to strangers
```

### Merchant
```
STR 8 | DEX 10 | CON 10 | INT 14 | WIS 12 | CHA 16
HP: 20 | AC: 10 | Damage: 1d4 (dagger)
Attitude: Friendly to customers, greedy with discounts
Special: 20% markup on items, can identify magical items
```

### Bandit Leader
```
STR 14 | DEX 14 | CON 14 | INT 12 | WIS 10 | CHA 12
HP: 50 | AC: 13 | Damage: 1d8+4 (scimitar)
Attitude: Hostile, demands tribute
Special: Bandit followers (2-4, HP 15 each, damage 1d6+2)
```

### Innkeeper
```
STR 10 | DEX 10 | CON 12 | INT 12 | WIS 14 | CHA 15
HP: 30 | AC: 10 | Damage: 1d6 (club)
Attitude: Welcoming, gossip-monger
Special: Knows local rumors, provides room and board (10 gold/night)
```

## Character Progression

### Level Up
Every level (requires XP = Level × 100):
- +2 to one stat (max 20)
- +1 proficiency bonus to two skills
- Learn new ability (class-specific)
- HP increase: +d8 + CON modifier

### Reputation System
- **Feared:** NPCs react with fear or hostility
- **Neutral:** NPCs treat you with caution
- **Friendly:** NPCs offer help and discounts
- **Legendary:** NPCs seek you out for quests and rewards

### Alignment
- **Lawful Good:** Honorable, principled, compassionate
- **Neutral Good:** Benevolent, flexible, kind
- **Chaotic Good:** Freedom-loving, unpredictable, moral
- **Lawful Neutral:** Orderly, disciplined, impartial
- **True Neutral:** Balanced, moderate, adaptable
- **Chaotic Neutral:** Unpredictable, free-spirited, self-interested
- **Lawful Evil:** Tyrannical, organized, ruthless
- **Neutral Evil:** Self-serving, pragmatic, cruel
- **Chaotic Evil:** Destructive, sadistic, unpredictable

Alignment affects NPC reactions and available quest options.
