# Worlds - Settings, Locations & Lore

## Fantasy World: Eldoria

### Overview
A medieval fantasy realm of magic, adventure, and ancient mysteries. Humans, elves, dwarves, and other races coexist in uneasy peace, while dark forces stir in the shadows.

### Geography

**Major Regions:**

**Kingdom of Stormhaven**
- Capital: Stormhaven City
- Ruler: King Alaric III
- Population: 500,000 (mostly human)
- Notable: Storm Citadel, Grand Academy of Magic
- Atmosphere: Prosperous, bustling, seat of power

**Elven Forest of Sylvanas**
- Capital: Silverleaf
- Ruler: High Priestess Elara Moonwhisper
- Population: 200,000 (95% elf, 5% others)
- Notable: Moon Temple, World Tree, Enchanted Glades
- Atmosphere: Ancient, mystical, guarded

**Dwarven Mountains of Ironhold**
- Capital: Deepstone
- Ruler: King Thorgar Ironfist
- Population: 150,000 (dwarves)
- Notable: Great Forge, Deep Mines, Dragon's Lair
- Atmosphere: Industrious, underground, stoic

**Shadowfell**
- Ruler: Unknown (presumed lich or demon lord)
- Population: Varies (undead, dark creatures)
- Notable: Spire of Despair, Necropolis, Dark Temple
- Atmosphere: Corrupted, dangerous, evil

**Trade Route: The Amber Road**
- Connects all major kingdoms
- Controlled by merchant guilds
- Hotbed of banditry and intrigue
- Key towns: Crossroads, Rivergate, Stonebridge

### Factions

**The Silver Council**
- Alignment: Lawful Good
- Goals: Maintain peace, regulate magic, combat evil
- Leader: Archmage Valerius Stormwind
- Headquarters: Grand Academy of Magic
- Resources: Magical artifacts, political influence
- Quests: Investigate magical disturbances, defeat dark mages

**The Shadow Syndicate**
- Alignment: Chaotic Evil
- Goals: Accumulate power, corrupt kingdoms, summon demons
- Leader: Unknown (revealed late in campaign)
- Headquarters: Hidden (assumed Shadowfell)
- Resources: Assassins, dark magic, spies
- Quests: Stop assassinations, uncover plots

**The Merchant League**
- Alignment: Neutral
- Goals: Profit, trade dominance, economic influence
- Leader: Guildmaster Marcus Aurelius
- Headquarters: Trade Hall, Stormhaven
- Resources: Wealth, trade routes, mercenaries
- Quests: Escort caravans, disrupt competitors, negotiate deals

**The Rangers of the Wild**
- Alignment: Chaotic Good
- Goals: Protect nature, hunt monsters, maintain balance
- Leader: Ranger Captain Thorn Blackwood
- Headquarters: Hidden camps in Sylvanas Forest
- Resources: Survival skills, beast companions, knowledge
- Quests: Track monsters, protect villages, investigate corruption

### Notable Locations

**Stormhaven City**
- Population: 100,000
- Features: Royal Palace, Market District, Thieves' Den, Temple District
- NPCs: King Alaric III, Captain of Guard (Borin), Thieves' Guildmaster (Unknown)
- Quests: Court intrigue, city mysteries, urban adventures

**Silverleaf (Elven Capital)**
- Population: 80,000
- Features: Moon Temple, World Tree, Enchanted Library, Glades
- NPCs: High Priestess Elara, Librarian Aramil, Elder Council
- Quests: Ancient mysteries, forest protection, elven lore

**Deepstone (Dwarven Capital)**
- Population: 100,000 (underground)
- Features: Great Forge, Deep Mines, Dragon's Lair, Brewery
- NPCs: King Thorgar, Master Smith Durin, Dragon Advisor (if alive)
- Quests: Underground exploration, crafting, dragon politics

**Crossroads (Trade Town)**
- Population: 5,000
- Features: Inns, taverns, blacksmiths, market
- NPCs: Innkeeper (Greta), Blacksmith (Brom), Merchant (Viktor)
- Quests: Starting adventures, bandit hunting, escort missions

**Ruins of Old Stormhaven**
- Ancient city destroyed 500 years ago
- Features: Crumbling walls, undead, treasure, magical artifacts
- Quests: Exploration, treasure hunting, uncovering history

### Magic System

**Types of Magic:**
- **Arcane Magic:** Elemental spells, teleportation, illusions (INT-based)
- **Divine Magic:** Healing, protection, holy power (WIS-based)
- **Dark Magic:** Necromancy, curses, demon summoning (INT-based, corrupts user)
- **Nature Magic:** Animal communication, plant control, shapeshifting (WIS-based)

**Magical Artifacts:**
- Sword of Stormhaven: +10 damage, lightning strikes (royal heirloom)
- Crown of Elara: +4 INT, +4 WIS, detects evil (elven relic)
- Hammer of Thorgar: +8 damage, earthquake on critical hit (dwarven relic)
- Staff of the Lich: +15 dark magic, resurrects undead once (cursed item)

## Sci-Fi World: Nova Terra

### Overview
A future human colony on planet Nova Terra, 200 years after first settlement. Corporate colonies, rebellion, alien ruins, and survival in a hostile environment.

### Geography

**Major Colonies:**

**New Geneva (Corporate Hub)**
- Ruler: Corporate Council
- Population: 2,000,000
- Notable: Orbital elevator, corporate towers, research labs
- Atmosphere: High-tech, wealthy, stratified

**Frontier Outposts (Rebel Territory)**
- Ruler: Local councils (semi-autonomous)
- Population: 500,000 spread across 12 outposts
- Notable: Mining operations, terraforming efforts, alien ruins
- Atmosphere: Rough, dangerous, independent

**Space Stations (Orbital)**
- Ruler: Space Command
- Population: 300,000
- Notable: Shipyards, defensive platforms, zero-G manufacturing
- Atmosphere: Isolated, disciplined, strategic

### Factions

**Nova Corp (Ruling Corporation)**
- Alignment: Lawful Neutral
- Goals: Profit, control, resource extraction
- Leader: CEO Elena Vance
- Resources: Military, wealth, technology
- Quests: Corporate missions, sabotage competitors

**Frontier Rebellion**
- Alignment: Chaotic Good
- Goals: Independence from corporate control, fair treatment
- Leader: General Marcus Chen (ex-Corporate military)
- Resources: Guerrilla tactics, popular support, local resources
- Quests: Supply runs, raids, sabotage, diplomacy

**Alien Remnant Study Group**
- Alignment: True Neutral
- Goals: Study alien technology, understand extinct civilization
- Leader: Dr. Aris Thorne
- Resources: Alien artifacts, scientific knowledge
- Quests: Explore ruins, translate alien texts, reverse-engineer tech

### Technology Level

**Weapons:**
- Laser rifles (2d6 damage, range 100m)
- Plasma cannons (3d8 damage, limited ammo)
- Magnetic railguns (4d10 damage, slow fire rate)
- Sonic disruptors (1d4 damage, stuns targets)

**Vehicles:**
- Hover cars (personal transport)
- Mechs (military, 2-4 person crew)
- Dropships (rapid deployment)
- Orbital shuttles (space travel)

**AI:**
- Basic AI assistants (common)
- Advanced AI personalities (rare, expensive)
- Autonomous military units (controversial, limited deployment)

## Modern World: Shadows of Metro

### Overview
A contemporary noir city setting with criminal underworld, corrupt politics, supernatural elements, and conspiracy.

### Districts

**Uptown**
- Wealthy neighborhoods, corporate HQs, luxury shopping
- NPCs: CEOs, politicians, celebrities
- Quests: Corporate espionage, political scandals

**Midtown**
- Commercial district, offices, restaurants
- NPCs: Businesspeople, shopkeepers, workers
- Quests: Everyday mysteries, community problems

**Downtown**
- Entertainment district, nightclubs, theaters
- NPCs: Artists, musicians, tourists, criminals
- Quests: Nightlife mysteries, hunting criminals

**The Docks**
- Industrial shipping, warehouses, crime
- NPCs: Dockworkers, smugglers, gang members
- Quests: Smuggling busts, gang conflicts

**Slums**
- Impoverished neighborhoods, abandoned buildings
- NPCs: Homeless, gang members, desperate people
- Quests: Helping the poor, uncovering corruption

### Factions

**Metro PD**
- Alignment: Lawful Neutral
- Goals: Enforce law, protect citizens
- Quests: Investigations, patrols, manhunts

**The Syndicate (Crime Organization)**
- Alignment: Lawful Evil
- Goals: Profit, control territory
- Leader: Don Vincenzo Moretti
- Quests: Undercover operations, dismantling operations

**Vigilante (Batman-style Hero)**
- Alignment: Chaotic Good
- Goals: Justice outside the law, protect innocents
- Quests: Night patrols, rescuing hostages

**Supernatural Creatures (Secret)**
- Alignment: Varies
- Goals: Survival, feeding, ancient agendas
- Quests: Vampire hunting, werewolf investigation, ghost mysteries

### Supernatural Elements

**Vampires:**
- Weaknesses: Sunlight, garlic, wooden stakes
- Powers: Super speed, strength, mind control
- Hierarchy: Elder vampires, sires, fledglings

**Werewolves:**
- Weaknesses: Silver, full moon transformation
- Powers: Super strength, enhanced senses, regeneration
- Packs: Alpha wolf, pack members, omegas

**Ghosts:**
- Weaknesses: Exorcism, sunlight, blessed items
- Powers: Possession, poltergeist activity, invisibility
- Types: Bound to locations, objects, or people

## Historical World: Roman Empire

### Overview
Ancient Rome during the reign of Emperor Nero. Politics, military conquests, gladiatorial combat, and daily life in the empire.

### Locations

**Rome (Capital)**
- Colosseum, Forum, Senate, Palatine Hill
- Population: 1,000,000
- Quests: Political intrigue, Senate debates, gladiator fights

**Provinces**
- Britain: Military campaigns against Celtic tribes
- Egypt: Grain supply, ancient mysteries
- Judea: Religious tensions, rebellion brewing
- Gaul: Trade, Celtic tribes, Romanization

### Factions

**Imperial Court**
- Emperor Nero, Senators, Praetorian Guard
- Quests: Court intrigue, assassination plots

**Military**
- Legions, Centurions, Auxiliary troops
- Quests: Military campaigns, defending borders

**Christians (Persecuted Minority)**
- Secret meetings, spreading faith, avoiding persecution
- Quests: Protecting believers, hiding scriptures

**Cults & Mystery Religions**
- Mithraism, Isis worship, Dionysian rites
- Quests: Initiations, secret ceremonies

### Daily Life

**Gladiators:**
- Training, fighting for freedom or death
- Quests: Arena battles, earning freedom

**Merchants:**
- Trade, travel, wealth accumulation
- Quests: Supply routes, exotic goods

**Common People (Plebeians):**
- Work, entertainment, grain dole
- Quests: Everyday problems, mob politics

## World Creation Template

When creating a custom world, include:

**Basic Info:**
- Name and theme
- Technology/magic level
- Primary conflict
- Tone and atmosphere

**Geography:**
- Major regions/locations
- Transportation methods
- Climate and terrain

**Factions:**
- 3-5 major groups
- Their goals and relationships
- Leaders and resources

**Key NPCs:**
- Quest givers
- Villains
- Information sources
- Recurring characters

**Unique Elements:**
- Custom mechanics
- Special abilities
- World-specific rules
- Plot hooks and mysteries
