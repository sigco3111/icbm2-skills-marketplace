---
name: notebooklm-video-overview
category: automation
description: Generate Video Overview in NotebookLM UI before upload.
trigger: When running NotebookLM YouTube automation and a video overview is required.
---

# NotebookLM Video Overview Manual Step

The NotebookLM CLI cannot generate the Video Overview; you must do it in the web UI.

## Procedure
1. Open the NotebookLM web UI (e.g., https://notebooklm.google.com/).
2. Locate the notebook (title prefixed with `ICBM |`).
3. Click **Generate Video Overview** and wait until the thumbnail appears and the status shows **Ready**.
4. Return to the automation pipeline and run the upload command (`notebooklm upload …`).

## Pitfalls
- Skipping this step causes `video_overview_generation_failed` in the upload pipeline.
- The UI may take several minutes; do not restart the pipeline until the status is Ready.
- Ensure you are logged in with the same account used by the CLI.

## References
- `references/manual-video-overview.md` – quick cheat‑sheet.
