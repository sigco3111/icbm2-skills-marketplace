# Manual Video Overview Generation for NotebookLM

NotebookLM CLI **does not** generate the Video Overview. The required step is to open each notebook in the web UI and click **"Generate Video Overview"**.

## Procedure
1. Open the NotebookLM web UI (e.g., https://notebooklm.google.com/).
2. Find the notebook (title prefixed with `ICBM |`).
3. Click **Generate Video Overview** and wait until a thumbnail appears and the status changes to **Ready**.
4. Once ready, return to the automation pipeline and trigger the upload step (`notebooklm upload …`).

## Pitfalls
- Skipping this step causes the upload pipeline to fail with `video_overview_generation_failed`.
- The UI may take several minutes; do not restart the pipeline until the status is Ready.
- Ensure you are logged in with the same account used by the CLI.

> This manual step is a prerequisite for the automated upload flow.
