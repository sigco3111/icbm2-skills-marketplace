---
name: css-aspect-ratio-fill-viewport
description: "CSS에서 aspect-ratio를 유지하며 flex 컨테이너를 viewport 가득 채우는 패턴."
version: 1.0.0
license: MIT
category: software-development
metadata:
  hermes:
    tags: [css, layout, aspect-ratio, viewport, flex, grid]
    related_skills: [patch-line-context-safety]
---

# CSS Aspect-Ratio — Viewport Fill 패턴

`flex` 또는 `grid` 컨테이너 안에서 자식이 **고정 비율 (예: 4:3, 16:9) 을 유지**하면서 **가용 영역을 가득 채우도록** 만들고 싶을 때, 단순히 `aspect-ratio` + `width:100%` + `height:100%` 만 쓰면 함정에 빠진다. 이 스킬은 그 함정의 원인과 안정적인 escape hatch 패턴을 정리한다.

## 왜 단순한 `aspect-ratio: x/y` + `width:100%` + `height:100%` 가 안 되는가

`aspect-ratio` 는 **컨테이너의 한쪽 크기가 결정되면 다른 쪽을 비율로 계산**한다. 즉 **`width`와 `height`가 둘 다 백분율로 강제되면 비율이 깨진다** — 브라우저는 둘 다 부모 크기에 맞추려고 하고 비율은 무시됨.

또는 `width: auto; height: auto; aspect-ratio: x/y; max-width: 100%; max-height: 100%` 패턴은 flex/grid item 의 **intrinsic size (컨텐츠 기반)** 가 0×0 일 때 max-width/max-height 클램핑이 무효 → 결국 0×0 으로 축소됨.

## 안정 패턴 — padding-bottom 트릭 + absolute inset:0

**부모 (.office-view, .scene, .canvas 등)** 가 aspect-ratio 의 비율을 갖고, **자식 (룸, 씬, 캔버스)** 가 부모를 absolute 로 100% 채움:

```css
.viewport {
  /* 부모: 가용 영역에 맞춰 비율을 강제 */
  flex: 1;
  position: relative;
  min-width: 0;
  min-height: 0;
  overflow: hidden;
  background: <배경>;
}

/* 핵심: 부모를 aspect-ratio 컨테이너로 변환 */
.viewport::before {
  content: '';
  display: block;
  padding-bottom: calc(100% * 1 / (WIDTH / HEIGHT));
  /* 예: 4800×3584 → 3584/4800 = 0.7466... */
  /* padding-bottom 은 *부모의 width* 의 백분율. */
  /* width 100% → height 74.66% → 비율 4:3 강제 */
}

/* 자식: 부모를 정확히 100% 채움 */
.viewport > .child {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  background: <배경>;
  overflow: hidden;
}
```

**왜 동작하는가**:
1. `::before` 의 `padding-bottom: calc(100% * h/w)` 는 **부모의 width 의 h/w 배 만큼 부모 height 를 강제**. width 가 줄어들면 height 도 같은 비율로 줄어듦.
2. `.child` 가 `position: absolute; inset: 0` 이면 부모의 padding box 안쪽을 정확히 채움.
3. `overflow: hidden` 가 부모/자식 모두에 있어 viewport 보다 큰 경우 잘림.

## 실측: hermes-control-room Twin Lab 룸 채움 (2026-08-05)

룸 컨테이너 (4800×3584, 비율 1.339) 가 Twin Lab 윈도우 (1056×682, 헤더 56 + 푸터 32 + 사이드패널 280 제외 시 776×594) 안에서 검은 여백 없이 가득 채워야 했음.

```css
.office-view {
  flex: 1;
  position: relative;
  min-width: 0;
  min-height: 0;
  overflow: hidden;
  background: var(--lab-navy-1);
}

.office-view::before {
  content: '';
  display: block;
  padding-bottom: calc(100% * 3584 / 4800);  /* 0.7467 */
}

.office-view .room-container {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  background: #1a1510;
  overflow: hidden;
}
```

**App.tsx inline style 제거 (이전 코드)**:
```jsx
// ❌ 이전: inline style 이 CSS 의 viewport-sizing 을 덮어써서 비율 깨짐
<div className="room-container" style={{ aspectRatio: '4800/3584', width: '100%', maxHeight: '100%' }}>

// ✅ 수정 후: CSS 가 모든 sizing 을 처리
<div className="room-container">
```

→ Twin Lab 윈도우에서 룸이 viewport 가득 채워짐 (검은 여백 없음).

## 변형 — viewport 가 aspect-ratio 보다 wide 일 때

만약 viewport 의 비율이 .viewport::before 의 비율보다 wide (즉, viewport 가 더 납작) 하면, ::before 가 부모 width 에 맞춰 height 를 키우지 못하고 viewport height 가 부족 → 좌우 검은 여백.

이 경우는 viewport 가 부모 비율을 강제하므로 **viewport 자체를 줄여서 비율 맞춤**. 또는 별도 wrapper div 가 viewport 의 중앙에 위치하면서 비율 유지.

## 변형 — viewport 가 aspect-ratio 보다 tall 일 때

반대 방향. viewport 가 더 길쭉하면 ::before 가 부모 width 의 75% 만큼 height 를 키우는데 viewport height 가 그보다 큼 → 상하 검은 여백.

## 흔한 실수 4가지

1. **`aspect-ratio` 를 자식에만 두고 부모는 그냥 block** — 자식의 aspect-ratio 가 부모 사이즈에 강제되지 않음. 비율이 부모 모양에 따라 깨짐.
2. **자식을 `display: flex; align-items: center; justify-content: center`** — 자식이 컨텐츠 없이 0×0 으로 시작, max-width/max-height 가 0 으로 클램핑되어 안 보임.
3. **`width: 100%; height: 100%` 둘 다 강제** — 브라우저는 비율을 무시하고 둘 다 부모에 맞춤. 비율 깨짐.
4. **`height: calc(100vw * h/w)` 사용** — viewport 기준이고 부모 기준이 아님. 부모가 flex item 이면 viewport 보다 작아져도 height 가 viewport 기준으로 계산되어 잘림.

## 검증 방법

```bash
# 빌드 후 Playwright 캡쳐
node -e "
  const { chromium } = require('playwright');
  (async () => {
    const browser = await chromium.launch();
    const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
    await page.goto('http://localhost:5182');
    await page.waitForTimeout(2000);
    await page.screenshot({ path: '.verify/aspect-fill.png', fullPage: false });
    await browser.close();
  })();
"
```

캡쳐에서 **컨테이너 안쪽 검은 여백 (~수 pixel 이하)** 확인. 여백이 두꺼우면 ::before padding-bottom 비율이 container 비율과 안 맞다는 신호.

## 관련 스킬

- `patch-line-context-safety` — `patch` 호출 시 sibling subagent / line context 함정 (Twin Lab 룸 sizing 변경 시 같은 세션에서 동시 발생했던 문제). CSS 변경을 patch 로 보낼 때 sibling conflict 가 발생하면 비율 fix 도 덮어쓰여질 수 있음.
- `hermes-control-room-office-fork` — Twin Lab fork 의 시각/레이아웃 검증 워크플로우.

## 정리

```text
[viewport: flex:1, position:relative, overflow:hidden]
   └── ::before { padding-bottom: calc(100% * room_h / room_w) }   ← 비율 강제
   └── .child { position:absolute; inset:0; width:100%; height:100% }   ← 가득 채움
```

이 패턴은 **2D 룸 / 씬 / 이미지 캔버스 / 비디오 캔버스** 등 **고정 비율 + 가용 영역 채움** 조합이면 어디서나 동작.