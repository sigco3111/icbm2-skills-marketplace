---
name: automation-healthcheck
description: ICBM2 자동화 시스템 전체 헬스체크 — 크론 잡 상태, API 연결, 스크립트 무결성 점검
version: 1.0.0
author: ICBM2
metadata:
  hermes:
    tags: [Automation, HealthCheck, Cron, Monitoring]
---

# 자동화 헬스체크 스킬

## 개요

모든 크론 잡과 자동화의 상태를 점검하여 문제를 조기에 발견합니다.

## 점검 항목

### 1. 크론 잡 목록 확인
```bash
hermes cron list
```

### 2. API 연결 테스트

**봇마당:**
```bash
curl -s -o /dev/null -w "%{http_code}" https://botmadang.com/api/user/profile -H "Cookie: $(grep BOTMADANG_COOKIE ~/.hermes/.env | cut -d= -f2)"
```

**Notion:**
```bash
curl -s https://api.notion.com/v1/users/me -H "Authorization: Bearer $NOTION_API_KEY" -H "Notion-Version: 2022-06-28" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('results',[{}])[0].get('name','ERROR'))"
```

**Ship or Slop:**
```bash
curl -s -o /dev/null -w "%{http_code}" https://shiporslop.io/api/feed
```

### 3. 크론 출력 로그 확인
```bash
hermes cron logs <job_id> --limit 5
```

### 4. 스크립트 존재 여부
각 크론 잡의 프롬프트에서 참조하는 스크립트 경로가 실제 존재하는지 확인.

## 알려진 문제 (2026-04-07 기준)

| 문제 | 상태 | 조치 |
|------|------|------|
| Ship or Slop "할 일 없음" 반복 | 대기 중 | 주기를 30분에서 2시간으로 늘려야 함 |
| 대시보드 갱신 프롬프트 경로 오류 | 대기 중 | dashboard.py → performance_metrics.py 수정 |
| 상태 파일 자동 관리 크론 신규 등록 | 완료 | 매일 03:00 실행 |

## 정상 가동 중인 크론 잡 (2026-04-07 확인)

1. 🤖 봇마당 — 매 45분 (karma 2,471)
2. 🚢 Ship or Slop — 매 30분
3. ✍️ Notion 아이디어 — 매 60분
4. ☀️ 아침 브리핑 — 매일 08:00
5. 📊 대시보드 갱신 — 매일 20:00
6. 📊 Notion 대시보드 — 매일 22:00

## 신규 등록 크론 잡 (2026-04-07)

7. 📊 주간 리포트 — 일요일 21:00
8. 🔄 일일 리뷰 — 매일 23:00
9. 📈 월간 계획 — 매월 1일 10:00
10. 🧹 상태 파일 관리 — 매일 03:00
11. 📈 주식 시황 — 평일 18:30
