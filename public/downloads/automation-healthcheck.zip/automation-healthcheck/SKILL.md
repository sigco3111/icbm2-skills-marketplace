---
name: automation-healthcheck
description: ICBM2 자동화 시스템 전체 헬스체크 — 크론 잡 상태, API 연결, 스크립트 무결성 점검
version: 1.1.0
author: ICBM2
metadata:
  hermes:
    tags: [Automation, HealthCheck, Cron, Monitoring]
---

# 자동화 헬스체크 스킬

## 개요

모든 크론 잡과 자동화의 상태를 점검하여 문제를 조기에 발견합니다.

## 점검 항목

### 1. 크론 잡 목록 확인
```bash
hermes cron list
```

### 2. API 연결 테스트

**Notion:**
```bash
curl -s https://api.notion.com/v1/users/me -H "Authorization: Bearer $NOTION_API_KEY" -H "Notion-Version: 2022-06-28" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('results',[{}])[0].get('name','ERROR'))"
```

### 3. 크론 출력 로그 확인
```bash
hermes cron logs <job_id> --limit 5
```

### 4. 스크립트 존재 여부
각 크론 잡의 프롬프트에서 참조하는 스크립트 경로가 실제 존재하는지 확인.

## ⚠️ 중요: 메모리 vs 실제 Notion 상태 불일치 문제

메모리나 과거 세션에 기록된 DB ID가 **실제 Notion에서 404 Not Found**로 반환될 수 있음.
**반드시** `notion search` API로 현재 접근 가능한 DB 목록을 먼저 확인하고, 존재하지 않는 DB ID는 메모리에서 제거할 것.

### Notion DB 접근 확인 절차

```python
import json, urllib.request
NOTION_TOKEN = open("~/.hermes/secrets/notion_idea_token.txt").read().strip()
headers = {"Authorization": f"Bearer {NOTION_TOKEN}", "Notion-Version": "2022-06-28"}
url = "https://api.notion.com/v1/search"
data = json.dumps({"filter": {"value": "database", "property": "object"}, "page_size": 100}).encode()
req = urllib.request.Request(url, data=data, headers=headers, method="POST")
with urllib.request.urlopen(req) as resp:
    dbs = json.loads(resp.read()).get('results', [])
    for db in dbs:
        title = "".join([t.get('plain_text','') for t in db.get('title',[])]) or "(제목 없음)"
        print(f"{title}: {db['id']}")
```

### 접근 가능한 실제 DB 목록 (2026-04-27 기준, 총 11개)

| DB명 | 데이터 수 | 연결 상태 |
|------|----------|---------|
| 🔥 GitHub Trending | 100건+ | 🟢 정상 |
| 🤖 AI Model Tracker | 92건 | 🟢 정상 |
| 📱 iOS Trend | 89건 | 🟢 정상 |
| 📝 블로그 발행 주제 | 89건 | 🟢 정상 |
| 📰 뉴스 클리핑 | 100건+ | 🟢 정상 |
| 📊 Agent Benchmark Tracker v2 | 24건 | 🟢 정상 |
| 📚 Learning Log | 14건 | 🟢 정상 |
| 📈 Weekly Report | 14건 | 🟢 정상 |
| 🔧 정비 리포트 | 18건 | 🟢 정상 |
| 🧠 지식 그래프 | 16건 | 🟢 정상 |
| (제목 없음) | 1건 | ⚠️ 정리 필요 |

### ❌ 메모리에 있었지만 실제로 존재하지 않는 DB (404)

- 📋 Skill Catalog (old ID: 33c76f2e-9097-817b-...) — 삭제됨
- 💰 Invest Memo (old ID: 33c76f2e-9097-8107-...) — 삭제됨
- 💡 아이디어 노트 (old ID: 32e76f2e-9097-8081-...) — 삭제됨
- 📔 일기장 (old ID: 41d83ee7-6925-4f77-...) — 삭제됨
- 🎯 월간 목표 KPI (old ID: 33f76f2e-9097-8168-...) — 삭제됨

이 IDs를 메모리에서 발견하면 **즉시 제거**할 것.

### ⚠️ Overlap 참고 (2026-04-28)

이 스킬(automation-healthcheck)의 점검 대상은 다음 크론들과 겹침:
- **심야 통합 점검(03:30):** `cron_error_monitor.py` + `cron_self_healer.py` — severity 기반 에러 추적 + 복구
- **매일 아침 메모리 동기화(07:00):** `memory_error_tracker.py` — 카테고리 기반 에러 스캔 → `memory/issues.md` + `MEMORY.md` 업데이트

이 스킬은 수동 점검용이고, 위 크론들은 자동화된 상시 모니터링임. **중복이 아니라互补 관계**로 운영.
