---
name: automation-healthcheck
description: ICBM2 자동화 시스템 전체 헬스체크 — 크론 잡 상태, API 연결, 스크립트 무결성 점검
version: 1.5.0
author: ICBM2
metadata:
  hermes:
    tags: [Automation, HealthCheck, Cron, Monitoring]
---

# 자동화 헬스체크 스킬

## 개요

모든 크론 잡과 자동화의 상태를 점검하여 문제를 조기에 발견합니다.

## 점검 항목

### 1. 크론 잡 목록 확인
```bash
hermes cron list
```

### 2. API 연결 테스트

**Notion (정상 응답 빠른 확인):**
```bash
curl -s -o /dev/null -w "Notion API: %{http_code} (%{time_total}s)\n" -H "Authorization: Bearer *** -H "Notion-Version: 2022-06-28" https://api.notion.com/v1/users/me
```

**Telegram (토큰 파일 placeholder 여부 우선 확인):**
```bash
# 1) 토큰 파일이 placeholder인지 먼저 확인 (ICBM2 디폴트 함정)
head -1 ~/.hermes/secrets/telegram_bot_token.txt   # "# ⚠️ ICBM2..." 주석이면 placeholder

# 2) 실제 토큰이면 짧은 timeout으로 getMe
TOKEN=*** ~/.hermes/secrets/telegram_bot_token.txt)
curl -s -m 8 -o /dev/null -w "Telegram: %{http_code} (%{time_total}s)\n" "https://api.telegram.org/bot${TOKEN}/getMe"
```

**🔴 외부 API 응답 분류 — http_code 빠른 해석표**

| http_code | exit | 의미 | 다음 액션 |
|-----------|------|------|----------|
| 200/2xx | 0 | 정상 | 그대로 진행 |
| 401/403 | 0 | 인증 실패 | 토큰 파일 확인, rotation |
| 404 | 0 | 엔드포인트/리소스 없음 | DB ID/URL 검증 |
| 429 | 0 | rate limit | 백오프 후 재시도 |
| 302/301 | 0 | 리다이렉트 | -L 옵션 또는 정상 |
| **000** | **3** | **curl 자체 실패** | **네트워크/DNS/SSL 문제** — 아래 6단계 진단 |
| (없음) | 28 | **timeout** | 방화벽 차단 / IP 자체 차단 — 핫스팟 or VPN |

**🌐 "000" 또는 timeout일 때 6단계 네트워크 진단**

API 호출이 `000`이나 timeout으로 실패하면, 그게 **토큰 문제인지 네트워크 문제인지** 구분해야 함. 다음 6단계를 순서대로:

```bash
# 1) DNS — 이름 해석은 되는지
nslookup api.telegram.org   # Name: 응답이 있으면 DNS 정상

# 2) IPv4 / IPv6 — 둘 다 시도 (한쪽만 막힌 경우 있음)
curl -s -m 8 -4 -o /dev/null -w "IPv4: %{http_code} (%{time_total}s)\n" https://api.telegram.org/
curl -s -m 8 -6 -o /dev/null -w "IPv6: %{http_code} (%{time_total}s)\n" https://api.telegram.org/

# 3) IP 직접 핑 — IP 자체가 라우팅되는지
TELE_IP=$(nslookup api.telegram.org | grep -A1 "Name:" | tail -1 | awk '{print $2}')
ping -c 2 -W 3 $TELE_IP   # 100% loss = IP 자체 차단

# 4) 환경변수 프록시
env | grep -iE "proxy|PROXY" | grep -v "_="   # 비어있으면 OS-level 프록시 아님

# 5) 시스템 프록시 (macOS)
scutil --proxy   # ExceptionsList만 있으면 자동 프록시 강제 아님

# 6) hosts 파일 변조 (DNS 스푸핑 체크)
grep -i telegram /etc/hosts   # 비어있으면 정상
```

**진단 결과별 처방:**

| 진단 결과 | 원인 | 처방 |
|----------|------|------|
| DNS 실패 | DNS 서버 / 도메인 차단 | `8.8.8.8` 임시 사용, ISP 문의 |
| IPv4만 timeout | IPv4 라우트 차단 | IPv6 only 환경일 수 있음 — `-6` 우선 |
| IP 핑 100% loss | **방화벽이 IP 대역 전체 차단** | **회사/학교망 거의 확정** — 우회 필요 |
| 프록시 강제 설정 | OS-level intercept | 환경변수로 `HTTPS_PROXY` 우회 또는 시스템 설정 확인 |
| hosts 변조 | DNS 스푸핑 | hosts에서 해당 라인 제거 |

**📡 우회 옵션 (외부 API 차단 시)**

| 옵션 | 소요 시간 | 비용 | 회사 정책 위험 |
|------|----------|------|---------------|
| 폰 핫스팟 (LTE/5G) | 30초 | 데이터 | 없음 ⭐ 추천 |
| VPN (Cloudflare WARP 무료) | 2분 | 무료 | 회사 정책 확인 필요 |
| SOCKS5 프록시 (집 VPS 터널) | 10분+ | VPS 비용 | **위반 가능성 매우 높음** — 비추 |
| 작업 보류 (집/카페로 이동) | — | — | 없음 |

**핵심 원칙:** 회사망에서 외부 터널(SOCKS5/VPS) 뚫는 건 거의 항상 보안 정책 위반. 핫스팟이나 회사 승인 VPN만 권장.

### ⚠️ 우회 시도 시 흔한 함정 3개

**함정 1 — macOS WiFi/Ethernet 우선순위 함정 (가장 자주 빠짐)**
- 증상: WiFi를 다른 SSID로 바꿔도 여전히 같은 IP/게이트웨이가 잡혀 트래픽이 안 풀림
- 원인: macOS에서 `en0`(유선 LAN)이 `en1`(WiFi)보다 라우트 우선순위 높음. WiFi SSID만 바꾸면 en0이 살아있어 default route가 en0 유지
- 진단:
  ```bash
  networksetup -getairportnetwork en1   # "associated with" → SSID 확인
  ifconfig en0 | grep "status:"         # "active"면 살아있음
  route -n get api.telegram.org | grep interface   # en0 vs en1 어느 쪽으로 가나
  ```
- 처방: **이더넷 케이블 물리적으로 뽑기** (또는 시스템 설정 → 네트워크 → 이더넷 → "이 인터페이스 비활성"). 케이블 뽑으면 en0 down → en1(WiFi)이 default route로 자동 승격
- ⚠️ 케이블 뽑고 나서도 `ifconfig`에서 en0가 `UP`으로 보일 수 있음 — NIC 자체는 down 안 되지만 라우트 테이블에서 빠지면 OK. `route -n get`로 확인이 진짜 기준
- ⚠️ en0가 down된 직후 macOS가 자동으로 WiFi 재연결 시도 → SSID가 회사 WiFi면 다시 같은 망. **케이블 뽑기 전 새 SSID(핫스팟/외부 WiFi) 먼저 연결**하거나, 케이블 뽑은 후 즉시 SSID 전환 필요

**함정 2 — cloudflared DNS 프록시 모드 종료 (2026.2.0+)**
- 증상: `brew install cloudflare-warp`로 cloudflared 설치 후 `cloudflared proxy-dns` 실행 → "DNS Proxy is no longer supported since version 2026.2.0" 에러
- 원인: 2026-11 changelog에서 proxy-dns 모드 지원 종료
- 처방: cloudflared 2026.x는 SOCKS5 forward 용도로만 사용 가능 (`cloudflared access tcp --hostname ... --listener localhost:PORT`). DNS 우회 목적으론 부적합
- **DNS 우회 대안:** `curl --dns-servers 127.0.0.1:5454`는 libcurl이 `--dns-servers` 옵션을 지원 안 함. 다음 우회:
  - 시스템 DNS를 일시적으로 `1.1.1.1`로 변경 (`networksetup -setdnsservers Wi-Fi 1.1.1.1`) → 이게 더 단순
  - 또는 `dig @1.1.1.1 api.telegram.org`로 도메인 IP만 얻고 `curl --resolve api.telegram.org:443:<IP> https://api.telegram.org/`로 직접 IP 핑
  - **주의:** DNS는 풀려도 IP 자체가 ISP 단에서 막혀있으면 무의미. 위 함정 1의 WiFi/Ethernet 우회가 선행 필요

**함정 3 — 비대화형 환경에서 brew cask sudo 함정**
- 증상: `brew install --cask cloudflare-warp` → "sudo: a terminal is required to read the password" 에러로 설치 실패
- 원인: brew cask는 시스템 `/Applications`에 .pkg를 설치하려고 `sudo /usr/sbin/installer` 호출. 비대화형(PTY 없음) 환경에서 sudo가 password 못 받음
- 처방: brew formula는 대부분 sudo 불필요하지만, 시스템 통합 GUI 앱은 어쩔 수 없음 → **사용자님이 macOS GUI에서 직접 다운로드/설치** 안내
- 비대화형 환경 진단 워크플로: brew 시도 → sudo 막히면 → DMG 직접 다운로드 (`curl -L -o /tmp/app.dmg https://...`) → 비대화형으로 풀 수 있으면 OK, .pkg라 어쩔 수 없으면 사용자 안내

**함정 4 — WARP GUI는 curl로 못 받고 Safari로 받는다 (v1.4.0 추가)**
- 증상: `curl -L https://install.appcenter.cloudflare.com/...` → `http_code: 000` (timeout), `curl https://1.1.1.1/` → 0KB
- 원인: 회사 방화벽이 curl 시그니처(헤더/시퀀스)만 차단하고 Safari TLS 핑거프린트는 통과시키는 경우
- 처방: **curl 다운로드 시도만 보고 "WARP 설치 불가"로 단정하지 말 것** → 사용자에게 Safari로 `https://1.1.1.1/` 받게 안내 (보통 1분)
- 설치 검증: `ps aux | grep -iE "WARP|CloudflareWARP"` → `Cloudflare WARP` 프로세스 떠있으면 OK
- 비대화형 상태 진단: `/Applications/Cloudflare WARP.app/Contents/Resources/warp-cli status` → "Connected" + "Network: healthy" 확인

**함정 5 — WARP 첫 실행 Registration Missing + 토큰 마스킹 함정 (v1.4.0 추가)**
- WARP 설치 직후 자동 연결 안 됨. 메뉴바에서 사용자 직접 "Connect" 클릭 → macOS VPN 구성 추가 승인 알림 → Allow 필수
- 비대화형 진단:
  ```bash
  /Applications/Cloudflare\ WARP.app/Contents/Resources/warp-cli status
  # "Status update: Unable / Reason: Registration Missing due to: Daemon Startup"
  # → 메뉴바 Connect 클릭 안 한 상태
  ```
- **토큰 마스킹 함정 (자주 빠짐):** 40자+ 시크릿이 `$(cat ...)` 또는 `write_file` heredoc에 들어가면 마스킹 정책이 토큰을 `***`로 잘라 명령 자체를 깨뜨림
  ```bash
  # ❌ 깨지는 패턴
  TOKEN=*** ~/.hermes/secrets/telegram_bot_token.txt)  # syntax error
  # ✅ 안전한 패턴
  read -r TOKEN < /Users/hjshin/.hermes/secrets/telegram_bot_token.txt
  echo "len=${#TOKEN}"  # 46 정상
  ```
- **Python urllib SSL 인증서 함정:** 회사 MITM CA가 시스템 키체인에 없으면 `ssl.SSLCertVerificationError: self signed certificate in certificate chain` 발생. `curl`은 별도 CA store라 OK인 경우 많음 → 진단 스크립트는 `curl` 우선 권장

**WARP 외부 IP 검증 + Telegram 봇 통신 비대칭 (v1.4.0 추가):**
- WARP Connected 후 검증:
  ```bash
  curl -s https://api.ipify.org   # → 104.28.x.x 또는 162.158.x.x (Cloudflare)
  curl -s -m 10 -o /dev/null -w "%{http_code} (%{time_total}s)\n" https://api.telegram.org/   # → 302 + 1.3s 정상
  curl -s "https://api.telegram.org/bot${TOKEN}/getMe"  # → {"ok":true,"result":{"first_name":"..."}}
  ```
- **sendMessage는 OK인데 getUpdates는 빈 응답 (회사 환경 빈번):**
  - 가장 흔한 원인: 사용자가 보낸 줄 알지만 다른 채팅/봇에 보냄, 새 봇 DM은 사용자가 먼저 `/start` 해야 봇이 발신 가능 (Telegram 정책), 회사망 outbound만 뚫리고 inbound(SNI 필터)가 차단
  - 진단: 사용자에게 **핑 메시지(message_id)에 Reply로 답장** 보내달라고 안내 → 8초 내 getUpdates에 안 잡히면 회사망 inbound 차단 확정
  - 처방: `webhook` 모드 전환 (Telegram → 외부 public URL POST) 또는 집/카페에서 작업

#### 🔴 `getUpdates 409 Conflict` — launchd 데몬 충돌 (v1.5.0 추가)

**증상**: 텔레그램 메시지는 정상 도착(sendMessage OK), 봇 getMe OK, **그런데 봇이 답장 안 함**. `getUpdates` 호출 시 `409 Conflict: terminated by other getUpdates request; make sure that only one bot instance is running`.

**원인**: Telegram Bot API는 봇당 1개의 long-polling 세션만 허용. macOS launchd의 `~/Library/LaunchAgents/`에 같은 봇을 잡는 Hermes 게이트웨이 plist가 2개 등록되면, 둘이 같은 봇의 getUpdates를 동시에 잡으려다 한쪽이 거절당함. 둘 다 결국 SIGTERM(-9)으로 비정상 종료된 채 좀비 슬롯에 박혀 있음.

**진단 5단계**:

```bash
# 1) getUpdates로 409 확정
TOKEN=$(grep TELEGRAM_BOT_TOKEN ~/.hermes/.env | cut -d= -f2)
curl -sS --max-time 5 "https://api.telegram.org/bot${TOKEN}/getUpdates?timeout=0&limit=1"
# → {"ok":false,"error_code":409,"description":"Conflict: terminated by other getUpdates request; ..."}

# 2) launchd 좀비 데몬 찾기
launchctl list 2>/dev/null | grep -iE "hermes|icbm"
# → PID -9 (-9 = SIGKILL로 죽은 좀비), 두 줄 이상이면 충돌

# 3) 좀비 PID 강제 종료 (반복)
for pid in $(launchctl list 2>/dev/null | awk '$3 ~ /hermes|icbm/ && $1 ~ /^[0-9]+$/ {print $1}'); do
  kill -9 $pid 2>/dev/null
done
pkill -9 -f "hermes_cli.main" 2>/dev/null
pkill -9 -f "hermes gateway" 2>/dev/null

# 4) plist 비활성화 (다음 부팅부터 자동 시작 차단)
for label in ai.hermes.gateway com.icbm2.hermes-gateway; do
  for dir in ~/Library/LaunchAgents /Library/LaunchAgents /Library/LaunchDaemons; do
    f="$dir/$label.plist"
    if [ -f "$f" ]; then
      cp "$f" "${f}.bak.$(date +%s)"
      mv "$f" "${f}.disabled"
    fi
  done
done

# 5) sendMessage self-test (봇 API 살아있는지)
curl -sS -X POST "https://api.telegram.org/bot${TOKEN}/sendMessage" \
  -d chat_id="$(grep TELEGRAM_ALLOWED_USERS ~/.hermes/.env | cut -d= -f2 | cut -d, -f1)" \
  -d text="🩺 진단 테스트"
# → message_id 응답 = 봇 API 정상, 워커만 띄우면 됨
```

**plist 두 개의 진짜 정체 — 어떤 게 살아남아야 하나**:

| plist 라벨 | 진입점 | WorkingDirectory | KeepAlive | 환경변수 | 정식 여부 |
|------------|--------|------------------|-----------|----------|-----------|
| `ai.hermes.gateway` | `python -m hermes_cli.main gateway run --replace` | `~/.hermes/hermes-agent` | SuccessfulExit=false (정상 종료 시 안 띄움) | VIRTUAL_ENV, HERMES_HOME, PATH 풀세트 | ✅ **정식** |
| `com.icbm2.hermes-gateway` | `hermes gateway run --replace` (직접 바이너리) | `~/.openclaw/workspace` | true (무조건 재시작) | PATH만 (VIRTUAL_ENV 없음) | ❌ **중복** — 메인 워커 디렉토리 아님, 토큰 못 읽고 좀화 |

`com.icbm2.hermes-gateway`가 4월 6일 같은 날 1시간 16분 뒤에 추가된 중복. 환경변수 없어서 `~/.hermes/.env` 못 읽고 토큰 없이 죽으면서 KeepAlive=true로 무한 재시작하는 좀비. **영구 비활성화 권장** (`*.disabled` 유지).

**워크커 재기동 명령** (워커 0개 상태일 때):
```bash
cd ~/.hermes/hermes-agent && \
  /Users/hjshin/.hermes/hermes-agent/venv/bin/hermes gateway run --replace
```

**함정 — `launchctl bootout` 실패 (TMI 회피)**:
- `launchctl bootout gui/$UID/<label>` → "Operation not permitted" 또는 "Boot-out failed: I/O error". macOS launchd는 사용자 도메인에서 SIGKILL로 죽은 좀비의 bootout을 거부함.
- `kill -9 <pid>` + `pkill -9 -f "hermes"` 직접 종료가 더 효과적. plist 비활성화는 `.disabled`로 rename이 정답.

**회귀 방지**: 이 케이스 발생 시 본 세션의 ps + launchctl 결과 패턴을 같이 캡처:
```bash
# 진단을 한 줄로:
launchctl list 2>/dev/null | grep -iE "hermes|icbm" | grep -- "-9"
# 두 줄 이상 = 충돌 좀비 존재
```

### 3. 크론 출력 로그 확인
```bash
hermes cron logs <job_id> --limit 5
```

### 4. 크론 잡 프롬프트 vs 스킬 정의 간 DB ID 불일치 검출

Cron 잡이 스킬을 참조할 때, 잡의 prompt에 하드코딩된 DB ID가 스킬 정의와 다를 수 있음.
이 경우 cron은 "ok"로 표시되지만 실제 API 호출은 404 에러 → 데이터가 안 씌워짐.

**검증 절차:**

```
1. hermes cron list로 모든 크론 잡의 prompt에서 Notion DB ID 패턴 추출
   grep -oE '[0-9a-f]{32}' <<< prompt

2. 각 스킬 파일(~/.hermes/skills/*/SKILL.md)에서 DB_ID 변수 grep
   grep "DB_ID\|\"id\":" << SKILL.md

3. 불일치 발견 시:
   - cron jobs.json에서 해당 job_id의 prompt 확인
   - jobs.json 내 prompt의 wrong DB ID → 올바른 DB ID로 교체
   - cron update 실행
```

**흔한 실패 패턴:**
- 크론 잡 생성 시 prompt에 임시/올드 DB ID를 넣고, 스킬만 수정 → 스킬 ID로 동기화 안 됨
- 크론이 skill을 로드하지만 prompt의 hardcoded ID가 스킬의 DB_ID보다 우선함

### 5. 스크립트 존재 여부 — False Positive 주의
각 크론 잡의 프롬프트에서 참조하는 스크립트 경로가 실제 존재하는지 확인.

**⚠️ `cd` 이후 상대경로 false positive 패턴:**

`cron_self_healer.py`의 스크립트 존재检查는 `python3 scripts/notebooklm_selection.py` 같은
상대경로를 **작업 디렉터리(HERMES_DIR=~/.hermes) 기준**으로 해석합니다.
하지만 크론 프롬프트에 `cd ~/.hermes && python3 scripts/notebooklm_selection.py`가 있으면,
`scripts/`는 HERMES_DIR 기준 상대경로이므로 **실제론 정상이 false positive**로 오검출됩니다.

**판별 기준:**
- 크론 프롬프트에 `cd <dir> && python3 <script.py>` 패턴이 있으면 → 상대경로는 `cd`의 디렉터리 기준
- 이런 경우 `missing_script` 오류는 **false positive**일 가능성이 높음
- 실제 스크립트 존재 여부는 `~/.hermes/<상대경로>`로 확인

**자동 수정:**
`cron_self_healer.py`가 이 패턴을 감지하면 해당 오류를 건너뛰도록 개선됨 (2026-05-04).
수동 점검 시: jobs.json의 크론 프롬프트에서 `python3 scripts/` 형태의 상대경로를 절대경로로 교체
(`~/.hermes/scripts/...`)하면 false positive가从根本上消除됩니다.

## ⚠️ 중요: 메모리 vs 실제 Notion 상태 불일치 문제

메모리나 과거 세션에 기록된 DB ID가 **실제 Notion에서 404 Not Found**로 반환될 수 있음.
**반드시** `notion search` API로 현재 접근 가능한 DB 목록을 먼저 확인하고, 존재하지 않는 DB ID는 메모리에서 제거할 것.

### Notion DB 접근 확인 절차

```python
import json, urllib.request
NOTION_TOKEN = open("~/.hermes/secrets/notion_token.txt").read().strip()
headers = {"Authorization": f"Bearer {NOTION_TOKEN}", "Notion-Version": "2022-06-28"}
url = "https://api.notion.com/v1/search"
data = json.dumps({"filter": {"value": "database", "property": "object"}, "page_size": 100}).encode()
req = urllib.request.Request(url, data=data, headers=headers, method="POST")
with urllib.request.urlopen(req) as resp:
    dbs = json.loads(resp.read()).get('results', [])
    for db in dbs:
        title = "".join([t.get('plain_text','') for t in db.get('title',[])]) or "(제목 없음)"
        print(f"{title}: {db['id']}")
```

### 접근 가능한 실제 DB 목록 (2026-04-27 기준, 총 11개)

| DB명 | 데이터 수 | 연결 상태 |
|------|----------|---------|
| 🔥 GitHub Trending | 100건+ | 🟢 정상 |
| 🤖 AI Model Tracker | 92건 | 🟢 정상 |
| 📱 iOS Trend | 89건 | 🟢 정상 |
| 📝 블로그 발행 주제 | 89건 | 🟢 정상 |
| 📰 뉴스 클리핑 | 100건+ | 🟢 정상 |
| 📊 Agent Benchmark Tracker v2 | 24건 | 🟢 정상 |
| 📚 Learning Log | 14건 | 🟢 정상 |
| 📈 Weekly Report | 14건 | 🟢 정상 |
| 🔧 정비 리포트 | 18건 | 🟢 정상 |
| 🧠 지식 그래프 | 16건 | 🟢 정상 |
| (제목 없음) | 1건 | ⚠️ 정리 필요 |

### ❌ 메모리에 있었지만 실제로 존재하지 않는 DB (404)

- 📋 Skill Catalog (old ID: 33c76f2e-9097-817b-...) — 삭제됨
- 💰 Invest Memo (old ID: 33c76f2e-9097-8107-...) — 삭제됨
- 💡 아이디어 노트 (old ID: 32e76f2e-9097-8081-...) — 삭제됨
- 📔 일기장 (old ID: 41d83ee7-6925-4f77-...) — 삭제됨
- 🎯 월간 목표 KPI (old ID: 33f76f2e-9097-8168-...) — 삭제됨

이 IDs를 메모리에서 발견하면 **즉시 제거**할 것.

### 🔔 자동 스케줄링 권장

이 스킬의 "DB ID 불일치 검출" 절차는 **정기적으로 실행**해야 가치를 발휘합니다. 다음 크론 잡 중 해당 시간에 맞춰 실행하세요:

- **매일 09:00 이전**: `agent-benchmark-tracker` 실행 → 직후 이 스킬로 검증
- 또는 독립 크론으로 `automation-healthcheck` 스킬을 매일 아침(08:00 등)에 실행하여 전夜的 자동화 건강 상태 확인

핵심: 크론 잡이 "ok"로 표시되어도 **목적지 DB에 실제로 데이터가 쓰여졌는지** 반드시 확인해야 합니다.

## 🔄 3단계: 통합 정비 — 알려진 문제와 수정 패턴

### 자주 발생하는 출력 에러 패턴 (자가치유 대상)

**TimeoutError — 스크립트 분할 필요:**
- 증상: 출력 파일에서 `TimeoutError`, `timed out`, `deadline exceeded` 패턴 매치
- 발생 크론: `일일 자기 개선 리뷰`, `심야 통합 점검`, `주간 학습 로그`
- 근본 원인: 1800s threshold 초과 — 스크립트가 단일 단계로 너무 김
- 수정 방향: Phase1(데이터 수집) / Phase2(보고서 작성)로 분리

**APIError — 인증/rate limit:**
- 증상: 출력 파일에서 `api.*error`, `401`, `403`, `429`, `500`, `unauthorized` 패턴 매치
- 발생 크론: `오전 정보 수집 (iOS+AI모델)`, `지식 그래프 자동 구축`
- 주의: APIError不等于 API 장애 — rate limit 또는 입력质量问题일 수 있음

**출력 파일 Bloat:**
- 증상: Tistory 출력 디렉토리에 100개+ 파일 축적
- 자가치유: `cron_self_healer.py`가 한 번에 6개씩 삭제 (증분 정리)
- 완전 정리를 원하면: `find ~/.hermes/cron/output/<job_id>/ -name "*.md" -mtime +30 -delete`

### 72시간 에러 카테고리 트렌드 (2026-05 기준)

| 카테고리 | 일반적 원인 | 심각도 |
|---------|-----------|--------|
| Other | 미분류 에러 | 🟡 확인 필요 |
| YouTube | 업로드 타임아웃, 플레이스홀더 미출력 | 🟡 반복 발생 시 주의 |
| NotebookLM | Video Overview 폴링 타임아웃 | 🟡 반복 발생 |
| RSS Feeds | 피드 fetch 실패 | 🟡 신규 카테고리 |

RSS Feeds가 신규로 감지되면 (`memory_error_tracker.py`가 `🆕 RSS Feeds` 출력) → `issues.md`에 ISS-NNN으로 즉시 기록.

## 🔐 API Key 만료 모니터링

**참조:** `api-key-manager` 스킬 — API Key의 발급, 저장, 만료 감시, Telegram 알림까지 전체 파이프라인.

`~/.hermes/scripts/apikey_holiday_monitor.py`를 매일 09:00 크론으로 실행하여:
- Key 만료 7일 전부터 매일 알림
- 14일 내 공휴일/연휴 조회 알림

## 📚 지원 파일

- `references/api-network-diagnosis.md` — 외부 API 점검/차단 시 6단계 진단 + 우회 옵션 상세 (핫스팟/VPN/SOCKS5 트레이드오프, 회사 정책 가이드)
- `scripts/diagnose_api.py <host> [host2 ...]` — 6단계 진단을 자동 실행 + 종합 판정 출력 (DNS→HTTPS→IP핑→프록시→hosts). `python3 diagnose_api.py api.telegram.org`

## ⚠️ Overlap 참고 (2026-04-28)

이 스킬(automation-healthcheck)의 점검 대상은 다음 크론들과 겹침:
- **심야 통합 점검(03:30):** `cron_error_monitor.py` + `cron_self_healer.py` — severity 기반 에러 추적 + 복구
- **매일 아침 메모리 동기화(07:00):** `memory_error_tracker.py` — 카테고리 기반 에러 스캔 → `memory/issues.md` + `MEMORY.md` 업데이트

이 스킬은 수동 점검용이고, 위 크론들은 자동화된 상시 모니터링임. **중복이 아니라互补 관계**로 운영.

## 🆕 v1.3.0 추가 (2026-06-16)

- **외부 API 응답 분류표** (http_code → 원인/액션 빠른 매핑) 추가
- **6단계 네트워크 진단 절차** 신설 — "000" 또는 timeout 시 토큰 문제 vs 네트워크 문제 구분
- **우회 옵션 비교표** (핫스팟/VPN/SOCKS5/보류) — 회사 정책 위험도 명시
- **Telegram 토큰 placeholder 함정** 명시 (`# ⚠️ ICBM2...` 주석 = 미발급)
- **우회 시도 함정 5개** (v1.4.0 추가):
  - **macOS WiFi/Ethernet 우선순위 함정** — WiFi SSID 바꿔도 en0(유선) 라우트 살아있어 무의미, 케이블 물리적 분리가 가장 확실
  - **cloudflared proxy-dns 종료 (2026.2.0+)** — DNS 우회 목적으론 부적합, WARP GUI 앱 필요
  - **brew --cask 비대화형 sudo 함정** — PTY 없는 환경에서 시스템 앱 설치 불가, 사용자 GUI 안내
  - **WARP GUI는 curl timeout, Safari로 받는다 (v1.4.0)** — 회사 방화벽이 curl 시그니처만 차단. `warp-cli status` 비대화형 진단 + `ps aux` 프로세스 확인
  - **WARP Registration Missing + 토큰 마스킹 (v1.4.0)** — 첫 Connect 사용자 승인 필요, `read -r TOKEN < file`이 가장 안정
- 출처: 2026-06-16 Telegram 헬스체크 세션 (회사망 → IP 대역 차단 → WiFi/Ethernet 우선순위 → 케이블 분리 → WARP 우회 → Safari 설치) + sendMessage OK / getUpdates 빈 응답 비대칭 패턴에서 검증됨

## 🆕 v1.5.0 추가 (2026-06-22)

- **`getUpdates 409 Conflict` 케이스 신설** — "메시지 텔레 도착 O, 봇 답장 X" 진단
- **launchd 좀비 데몬 5단계 정리**: getUpdates 409 → `launchctl list | grep hermes` → `kill -9` 반복 → `*.plist → *.disabled` + `.bak.<ts>` → sendMessage self-test
- **plist 2개 정체 비교표** (`ai.hermes.gateway` 정식 vs `com.icbm2.hermes-gateway` 중복) — 환경변수/PATH/KeepAlive 차이로 중복 데몬 식별 가능
- **부팅 명령 표준화**: `cd ~/.hermes/hermes-agent && hermes gateway run --replace`
- **회귀 방지 한 줄 진단**: `launchctl list | grep hermes | grep -- "-9"` 두 줄 이상 = 충돌 좀비
- 출처: 2026-06-22 회사 PC 텔레그램 봇 "반응 없음" 점검 세션 — `~/Library/LaunchAgents/ai.hermes.gateway.plist` (정식, 4/6 11:53 등록) + `com.icbm2.hermes-gateway.plist` (중복, 4/6 13:09 추가) 동시 등록으로 409 충돌, plist 비활성화 + 좀비 PID 정리 + sendMessage self-test(message_id:18522) 정상화 검증
