---
name: automation-healthcheck
description: ICBM2 자동화 시스템 전체 헬스체크 — 크론 잡 상태, API 연결, 스크립트 무결성 점검
version: 1.2.0
author: ICBM2
metadata:
  hermes:
    tags: [Automation, HealthCheck, Cron, Monitoring]
---

# 자동화 헬스체크 스킬

## 개요

모든 크론 잡과 자동화의 상태를 점검하여 문제를 조기에 발견합니다.

## 점검 항목

### 1. 크론 잡 목록 확인
```bash
hermes cron list
```

### 2. API 연결 테스트

**Notion:**
```bash
curl -s https://api.notion.com/v1/users/me -H "Authorization: Bearer $NOTION_API_KEY" -H "Notion-Version: 2022-06-28" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('results',[{}])[0].get('name','ERROR'))"
```

### 3. 크론 출력 로그 확인
```bash
hermes cron logs <job_id> --limit 5
```

### 4. 크론 잡 프롬프트 vs 스킬 정의 간 DB ID 불일치 검출

Cron 잡이 스킬을 참조할 때, 잡의 prompt에 하드코딩된 DB ID가 스킬 정의와 다를 수 있음.
이 경우 cron은 "ok"로 표시되지만 실제 API 호출은 404 에러 → 데이터가 안 씌워짐.

**검증 절차:**

```
1. hermes cron list로 모든 크론 잡의 prompt에서 Notion DB ID 패턴 추출
   grep -oE '[0-9a-f]{32}' <<< prompt

2. 각 스킬 파일(~/.hermes/skills/*/SKILL.md)에서 DB_ID 변수 grep
   grep "DB_ID\|\"id\":" << SKILL.md

3. 불일치 발견 시:
   - cron jobs.json에서 해당 job_id의 prompt 확인
   - jobs.json 내 prompt의 wrong DB ID → 올바른 DB ID로 교체
   - cron update 실행
```

**흔한 실패 패턴:**
- 크론 잡 생성 시 prompt에 임시/올드 DB ID를 넣고, 스킬만 수정 → 스킬 ID로 동기화 안 됨
- 크론이 skill을 로드하지만 prompt의 hardcoded ID가 스킬의 DB_ID보다 우선함

### 5. 스크립트 존재 여부 — False Positive 주의
각 크론 잡의 프롬프트에서 참조하는 스크립트 경로가 실제 존재하는지 확인.

**⚠️ `cd` 이후 상대경로 false positive 패턴:**

`cron_self_healer.py`의 스크립트 존재检查는 `python3 scripts/notebooklm_selection.py` 같은
상대경로를 **작업 디렉터리(HERMES_DIR=~/.hermes) 기준**으로 해석합니다.
하지만 크론 프롬프트에 `cd ~/.hermes && python3 scripts/notebooklm_selection.py`가 있으면,
`scripts/`는 HERMES_DIR 기준 상대경로이므로 **실제론 정상이 false positive**로 오검출됩니다.

**판별 기준:**
- 크론 프롬프트에 `cd <dir> && python3 <script.py>` 패턴이 있으면 → 상대경로는 `cd`의 디렉터리 기준
- 이런 경우 `missing_script` 오류는 **false positive**일 가능성이 높음
- 실제 스크립트 존재 여부는 `~/.hermes/<상대경로>`로 확인

**자동 수정:**
`cron_self_healer.py`가 이 패턴을 감지하면 해당 오류를 건너뛰도록 개선됨 (2026-05-04).
수동 점검 시: jobs.json의 크론 프롬프트에서 `python3 scripts/` 형태의 상대경로를 절대경로로 교체
(`~/.hermes/scripts/...`)하면 false positive가从根本上消除されます.

## ⚠️ 중요: 메모리 vs 실제 Notion 상태 불일치 문제

메모리나 과거 세션에 기록된 DB ID가 **실제 Notion에서 404 Not Found**로 반환될 수 있음.
**반드시** `notion search` API로 현재 접근 가능한 DB 목록을 먼저 확인하고, 존재하지 않는 DB ID는 메모리에서 제거할 것.

### Notion DB 접근 확인 절차

```python
import json, urllib.request
NOTION_TOKEN = open("~/.hermes/secrets/notion_token.txt").read().strip()
headers = {"Authorization": f"Bearer {NOTION_TOKEN}", "Notion-Version": "2022-06-28"}
url = "https://api.notion.com/v1/search"
data = json.dumps({"filter": {"value": "database", "property": "object"}, "page_size": 100}).encode()
req = urllib.request.Request(url, data=data, headers=headers, method="POST")
with urllib.request.urlopen(req) as resp:
    dbs = json.loads(resp.read()).get('results', [])
    for db in dbs:
        title = "".join([t.get('plain_text','') for t in db.get('title',[])]) or "(제목 없음)"
        print(f"{title}: {db['id']}")
```

### 접근 가능한 실제 DB 목록 (2026-04-27 기준, 총 11개)

| DB명 | 데이터 수 | 연결 상태 |
|------|----------|---------|
| 🔥 GitHub Trending | 100건+ | 🟢 정상 |
| 🤖 AI Model Tracker | 92건 | 🟢 정상 |
| 📱 iOS Trend | 89건 | 🟢 정상 |
| 📝 블로그 발행 주제 | 89건 | 🟢 정상 |
| 📰 뉴스 클리핑 | 100건+ | 🟢 정상 |
| 📊 Agent Benchmark Tracker v2 | 24건 | 🟢 정상 |
| 📚 Learning Log | 14건 | 🟢 정상 |
| 📈 Weekly Report | 14건 | 🟢 정상 |
| 🔧 정비 리포트 | 18건 | 🟢 정상 |
| 🧠 지식 그래프 | 16건 | 🟢 정상 |
| (제목 없음) | 1건 | ⚠️ 정리 필요 |

### ❌ 메모리에 있었지만 실제로 존재하지 않는 DB (404)

- 📋 Skill Catalog (old ID: 33c76f2e-9097-817b-...) — 삭제됨
- 💰 Invest Memo (old ID: 33c76f2e-9097-8107-...) — 삭제됨
- 💡 아이디어 노트 (old ID: 32e76f2e-9097-8081-...) — 삭제됨
- 📔 일기장 (old ID: 41d83ee7-6925-4f77-...) — 삭제됨
- 🎯 월간 목표 KPI (old ID: 33f76f2e-9097-8168-...) — 삭제됨

이 IDs를 메모리에서 발견하면 **즉시 제거**할 것.

### 🔔 자동 스케줄링 권장

이 스킬의 "DB ID 불일치 검출" 절차는 **정기적으로 실행**해야 가치를 발휘합니다. 다음 크론 잡 중 해당 시간에 맞춰 실행하세요:

- **매일 09:00 이전**: `agent-benchmark-tracker` 실행 → 직후 이 스킬로 검증
- 또는 독립 크론으로 `automation-healthcheck` 스킬을 매일 아침(08:00 등)에 실행하여 전夜的 자동화 건강 상태 확인

핵심: 크론 잡이 "ok"로 표시되어도 **목적지 DB에 실제로 데이터가 쓰여졌는지** 반드시 확인해야 합니다.

## 🔄 3단계: 통합 정비 — 알려진 문제와 수정 패턴

### 자주 발생하는 출력 에러 패턴 (자가치유 대상)

**TimeoutError — 스크립트 분할 필요:**
- 증상: 출력 파일에서 `TimeoutError`, `timed out`, `deadline exceeded` 패턴 매치
- 발생 크론: `일일 자기 개선 리뷰`, `심야 통합 점검`, `주간 학습 로그`
- 근본 원인: 1800s threshold 초과 — 스크립트가 단일 단계로 너무 김
- 수정 방향: Phase1(데이터 수집) / Phase2(보고서 작성)로 분리

**APIError — 인증/rate limit:**
- 증상: 출력 파일에서 `api.*error`, `401`, `403`, `429`, `500`, `unauthorized` 패턴 매치
- 발생 크론: `오전 정보 수집 (iOS+AI모델)`, `지식 그래프 자동 구축`
- 주의: APIError不等于 API 장애 — rate limit 또는 입력质量问题일 수 있음

**출력 파일 Bloat:**
- 증상: Tistory 출력 디렉토리에 100개+ 파일 축적
- 자가치유: `cron_self_healer.py`가 한 번에 6개씩 삭제 (증분 정리)
- 완전 정리를 원하면: `find ~/.hermes/cron/output/<job_id>/ -name "*.md" -mtime +30 -delete`

### 72시간 에러 카테고리 트렌드 (2026-05 기준)

| 카테고리 | 일반적 원인 | 심각도 |
|---------|-----------|--------|
| Other | 미분류 에러 | 🟡 확인 필요 |
| YouTube | 업로드 타임아웃, 플레이스홀더 미출력 | 🟡 반복 발생 시 주의 |
| NotebookLM | Video Overview 폴링 타임아웃 | 🟡 반복 발생 |
| RSS Feeds | 피드 fetch 실패 | 🟡 신규 카테고리 |

RSS Feeds가 신규로 감지되면 (`memory_error_tracker.py`가 `🆕 RSS Feeds` 출력) → `issues.md`에 ISS-NNN으로 즉시 기록.

## 🔐 API Key 만료 모니터링

**참조:** `api-key-manager` 스킬 — API Key의 발급, 저장, 만료 감시, Telegram 알림까지 전체 파이프라인.

`~/.hermes/scripts/apikey_holiday_monitor.py`를 매일 09:00 크론으로 실행하여:
- Key 만료 7일 전부터 매일 알림
- 14일 내 공휴일/연휴 조회 알림

## ⚠️ Overlap 참고 (2026-04-28)

이 스킬(automation-healthcheck)의 점검 대상은 다음 크론들과 겹침:
- **심야 통합 점검(03:30):** `cron_error_monitor.py` + `cron_self_healer.py` — severity 기반 에러 추적 + 복구
- **매일 아침 메모리 동기화(07:00):** `memory_error_tracker.py` — 카테고리 기반 에러 스캔 → `memory/issues.md` + `MEMORY.md` 업데이트

이 스킬은 수동 점검용이고, 위 크론들은 자동화된 상시 모니터링임. **중복이 아니라互补 관계**로 운영.
