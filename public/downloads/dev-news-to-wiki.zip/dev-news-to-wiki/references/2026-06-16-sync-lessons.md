# 2026-06-16 Sync Session Lessons

Session-specific detail captured for the dev-news-to-wiki skill. See SKILL.md for active rules.

## What Got Processed

| Notion Item | Category | Decision | Page Action |
|-------------|----------|----------|-------------|
| hera-agent-unity (CLI로 Unity 제어하는 MCP 대안) | TIP | CREATE | `entities/hera-agent-unity.md` |
| AI/ML 주간 논문 모음 (2026-06-08~14, PyTorchKR 10편) | 뉴스 | CREATE | `concepts/ai-ml-papers-weekly.md` |
| AI 기반 애니메이션 스프라이트 생성 스튜디오 (PerfectPixel) | 오픈소스 | CREATE | `entities/perfectpixel-studio.md` |
| Kimi K2.7-Code (사고 토큰 30% 절감) | 뉴스 | **REGISTER (Case D)** | `entities/kimi-k2-6.md` already existed (K2.7 merged into K2.6 page) |
| GLM 5.2 출시 (744B-A40B MoE, 1M 컨텍스트) | 뉴스 | **REGISTER (Case D)** | `entities/glm-5-2.md` already existed |
| NotebookLM MCP 서버 (RAG-as-MCP) | TIP | **REGISTER (Case D)** | `entities/notebooklm-mcp-server.md` existed, index 미등록 |
| 에이전트 코딩에 로컬 LLM 활용하기 (결정론적 하니스 6배) | TIP | **REGISTER (Case D)** | `concepts/local-llm-agentic-coding.md` existed, index 미등록 |
| (axon — 2026-05-12 raw+page already existed, also Case D) | — | **REGISTER (Case D)** | `entities/axon.md` index 미등록 보강 |

3 신규 + 5 정식 등재 = index 8개 항목 추가 (Total 123 → 126).

## Case D (partial-sync) Detection — First Real Encounter

This was the first session where the **4-case table** was needed. The 4-case table now in SKILL.md 5단계 was added as a result of this session.

**Root cause**: Previous sync (2026-06-15) created raw + entity/concept files for 5+ items (Kimi K2.7, GLM 5.2, NotebookLM MCP, local-llm-agentic-coding, axon) but the script did not complete the index.md / log.md update step. The items then re-appeared in the 2026-06-16 digest as "신규 7건" (because the Notion DB has no "Wiki-synced" marker).

**Detection pattern that worked**:
```bash
WIKI=~/wiki
for slug in <digest-slugs>; do
  page_existing=$(ls "$WIKI/entities/$slug.md" "$WIKI/concepts/$slug.md" 2>/dev/null | head -1)
  in_index=$(grep -c "\[\[$slug\]\]" "$WIKI/index.md" 2>/dev/null)
  if [[ -n "$page_existing" && "$in_index" -eq 0 ]]; then
    echo "CASE_D: $slug"
  fi
done
```

**Without this detection**, the agent would have either:
- Skipped the 5 items as "already done" → navigation permanently broken
- Recreated duplicate pages → wiki bloat and wikilink graph corruption

Both are worse than the formal-re-registration path.

## Cross-Section Backlink Pattern (Step 9)

Each new page got 1 patch-per-page to the closest related page:

| New page | Backlink target | What was added |
|----------|-----------------|----------------|
| `hera-agent-unity.md` | `entities/acp-ui.md` | "관련 엔티티/컨셉" 섹션에 1줄 (MCP vs 도메인 한정 우회 대조) |
| `ai-ml-papers-weekly.md` | `concepts/ai-agents-trends-2026.md` | "섹션 21" 추가 (3대 트렌드) |
| `perfectpixel-studio.md` | `concepts/mcp-vs-skills.md` | "AI + 결정론적 후처리" 섹션 + 결정론적 보강 메타 패턴 |

This kept orphan count = 0 for the new pages and reinforced cross-graph density. Verified post-write:
- hera-agent-unity: 6 inbound links
- perfectpixel-studio: 5 inbound links
- ai-ml-papers-weekly: 3 inbound links

## Domain Pattern Recognition — What This Session Surfaced

### Pattern 4: AI + 도메인 특화 런타임 (Triple)
- `acp-ui` (범용 통합) / `hera-agent-unity` (Unity 도메인) / `perfectpixel-studio` (스프라이트 도메인)
- 같은 "AI + 런타임"이라도 scope 축이 다름 — 범용 vs 도메인
- `mcp-vs-skills` 의 3번째 축 후보: "도메인 한정 도구" (hera-agent-unity 가 대표 사례)

### Pattern 5: 결정론적 보강 (Deterministic Augmentation) 메타 패턴
- `local-llm-agentic-coding` (약한 LLM + 결정론적 하니스) = 6배 품질
- `perfectpixel-studio` (약한 LMM + 결정론적 후처리 4축) = 엔진 임포트 가능
- → "모델 약점을 시스템이 보완" 패턴이 LLM/LMM 양쪽으로 확산
- `mcp-vs-skills` 의 4번째 카테고리 후보 (MCP / Skills / 도메인 한정 / 결정론적 보강)

### Pattern 6: 자기 수정 루프 (Self-Harness)
- `ai-ml-papers-weekly` 10편 중 하나: 에이전트가 자기 하니스를 자동 진화
- `loop-engineering` 의 6가지 구성요소 + 자기 수정 = 7번째 요소

### Pattern 7: Hayekian Incentive-based 오케스트레이션
- `ai-ml-papers-weekly` 의 Economy of Minds (Hayekian 경매 기반)
- `multi-model-orchestration` 의 4번째 패턴 (Advisor/Router/Cascade + Incentive-based)

## External Fetch Pattern (Cron-Safe)

The cron context blocks `curl | python3 -c` (pipe-to-interpreter security rule). Workaround pattern that worked:

```bash
# 1. Save HTML to /tmp
curl -sL "URL" -A "Mozilla/5.0" -o /tmp/page.html

# 2. Find topic body via search_files
search_files pattern="<keyword>" path="/tmp/page.html" context=3

# 3. For GitHub README, direct raw fetch works:
curl -sL "https://raw.githubusercontent.com/<owner>/<repo>/main/README.md" \
  -A "Mozilla/5.0" -o /tmp/readme.md
```

This avoids the blocked `curl | python` pattern and is also easier to inspect mid-task.

## Decision Tree Update (5단계 → 4-case)

Before this session, the skill had 3 cases (A/B/C) in 5단계. The 4th case (D: partial-sync orphan) was discovered today. The table was updated to 4 cases in SKILL.md 5단계 with explicit detection recipe. Future sync sessions should run the detection loop on the digest slugs BEFORE deciding Skip/Update/Create/Register.
