# 2026-07-09 Sync Lessons — 13건 중 3 신규 + cron 패턴 정교화

## 핵심 학습 3가지

### 1. cron 환경 일괄 fetch 패턴 (정교화)

이전 lessons (2026-06-19) 가 `curl -o file` + `read_file` + `search_files` 4단계로 갈라놓았지만,
2026-07-09 sync 에선 **4개 fetch를 1 terminal call 에 batch** + Python 파싱은 heredoc으로
1-shot 으로 해결. 시간/콜 예산 절약.

**검증된 패턴 (2026-07-09, Grok 4.5 + kakao-wiki + katok + GLM 5.2 추론 마진 = 4 fetch):**

```bash
UA='Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15'
TMP=/tmp/wiki_fetch_$$.mkdir  # $$ = PID for unique tmpdir
mkdir -p "$TMP"

# (a) 4개 fetch 병렬 (1 terminal call)
curl -sL -A "$UA" "URL1" -o "$TMP/slug1.html" -w "slug1: %{http_code} %{size_download}b\n"
curl -sL -A "$UA" "URL2" -o "$TMP/slug2.html" -w "slug2: %{http_code} %{size_download}b\n"
curl -sL -A "$UA" "URL3" -o "$TMP/slug3.html" -w "slug3: %{http_code} %{size_download}b\n"
curl -sL -A "$UA" "URL4" -o "$TMP/slug4.html" -w "slug4: %{http_code} %{size_download}b\n"

# (b) Python 파싱 1-shot (heredoc으로 quoting 문제 회피)
python3 << PYEOF
import re
from html.parser import HTMLParser
class T(HTMLParser):
    # ... (HTMLParser class with skip-tag handling)
for f, name in [("\$TMP/foo.html", "Foo"), ("\$TMP/bar.html", "Bar")]:
    html = open(f).read()
    p = T(); p.feed(html)
    text = re.sub(r'\n\s*\n+', '\n\n', ''.join(p.t)).strip()
    text = re.sub(r'[ \t]+', ' ', text)
    print("===", name, "===")
    print(text[:5500])
PYEOF
```

이 한 패턴이 **6 call 절약** (4 curl + 1 read + 4 grep = 9 → 4 curl + 1 python = 5).
13건 중 4개만 fetch 필요했던 본 sync에서 fetch 단계가 단 2~3 terminal call로 종료.

**GitHub raw URL도 동일 패턴:**
```bash
curl -sL -A "$UA" "https://raw.githubusercontent.com/<owner>/<repo>/<branch>/README.md" -o "$TMP/readme.md" -w "%{http_code}\n"
# GitHub raw는 HTML 파싱 불필요 → read_file 1회로 raw 본문 직접 사용
```

**fallback for older `curl | python3` 패턴 거부**: `curl | python3 -c` 같은 pipe to interpreter는
cron 모드에서 자동 거부됨 (Pitfalls 섹션 참조). 본 heredoc 패턴은 (a) 파일로 저장 → (b) 명시적
`python3 <file-or-heredoc>` 으로 분리하기 때문에 안전.

### 2. index.md 헤더 patch의 빈 줄 손실 함정 (NEW)

**증상**: `patch` 로 index.md 의 `> Last updated A | Total pages B` 줄을 새 `> Last updated ... | Total pages N`
으로 교체할 때, 두 줄만 매칭시키면 **헤더 끝의 빈 줄이 사라지고** `## Entities` 직전에 quote-block
스타일이 잘못 형성됨:

```
# Wiki Index
>                          # ← ❌ 빈 줄 손실 (원래는 빈 줄이어야 함)
> Content catalog...
> Read this first...
> Last updated 2026-07-09 | Total pages 159
## Entities                  # ← 앞 빈 줄이 사라짐
```

**원인**: `old_string = "# Wiki Index\n> Content catalog..."` 와 같이 H1 + 첫 blockquote 줄만
anchor 하면, patch tool이 H1 다음의 **빈 줄을 제거**해버림 (또는 첫 줄 직전이 blockquote로
변환되면서 quote-block 으로 잘못 묶임).

**Safe pattern (검증 2026-07-09)**:
1. `old_string`에 `## Entities` 직전까지 **3줄 정도의 구조적 context** 포함:
   ```python
   old_string = """# Wiki Index
   >
   > Content catalog. Every wiki page listed under its type with a one-line summary.
   > Read this first to find relevant pages for any query.
   > Last updated 2026-07-08 | Total pages 156
   ## Entities"""
   ```
2. patch 후 **`read_file` 로 첫 8줄 verify**:
   ```
   1: # Wiki Index
   2: (빈 줄)
   3: > Content catalog...
   4: > Read this first...
   5: > Last updated ... | Total pages ...
   6: (빈 줄)
   7: ## Entities
   ```
3. 회귀 발견 시 (`>\n>` 처럼 quote-block 잘못 형성) **두 번째 patch로 빈 줄 복구**:
   ```python
   patch(path="index.md",
         old_string="# Wiki Index\n>\n> Content catalog",
         new_string="# Wiki Index\n\n> Content catalog")
   ```
   검증됨: 2 patches (insert + repair) 가 1개 botched write 보다 빠름.

### 3. multi-day deep-dive 패턴 — "같은 출처, 누적 분석" (NEW, GLM 5.2 추론 마진)

**상황**: 이전 sync (2026-07-08) 에서 GeekNews 31209 (GLM 5.2 + AI 추론 마진 붕괴) 본문을 추출하여
`raw/articles/glm-5-2-inference-margin-2026-07-08.md` 를 만들고, `entities/glm-5-2.md` 에 "추론
마진 붕괴 — 오픈 가중치의 산업적 함의" 섹션 등록. 2026-07-09 sync 에서 동일 GeekNews URL 이 다시
digest 에 등장 (Notion Marking 미구현 + 같은 주 7/8, 7/9 발행 → 부분 중복).

**처리 결정**:
- ❌ (a) 어제 raw 파일 overwrite → raw 불변성 위반
- ❌ (b) 본 새 분석을 어제 raw에 추가 → raw 불변성 위반
- ✅ (c) **새 raw 파일 `raw/articles/glm-5-2-inference-margin-deepdive-2026-07-09.md` 생성** + entity sources에 동시 등록

**검증된 패턴 (2026-07-09)**:

```yaml
# glm-5-2.md frontmatter
sources:
  - raw/articles/glm-5-2-2026-06-15.md
  - raw/articles/glm-5-2-misos-bugmageddon-2026-06-30.md
  - raw/articles/glm-5-2-inference-margin-2026-07-08.md     # 1차 pass (yesterday)
  - raw/articles/glm-5-2-inference-margin-deepdive-2026-07-09.md  # 2차 pass (today, deeper)
```

Entity 본문에 새 섹션 추가 시 **두 raw의 날짜를 명시**:
```markdown
## 추론 마진 붕괴 2차 분석 — Z.ai/Fireworks 엔드포인트 + AMD Wafer (2026-07-09)

GeekNews 31209 본문 + Hacker News 댓글 종합 (raw/articles/glm-5-2-inference-margin-deepdive-2026-07-09.md).
```

**log entry 에도 명시**: "본 동기화에서는 같은 출처의 2차 분석으로 갱신 (어제 raw + 오늘 deep-dive raw 양쪽 sources에 포함)"

→ 이 패턴의 장점: (1) raw 불변성 유지, (2) 두 시점의 분석이 sources에서 비교 가능, (3)
사용자/다음 agent가 raw 파일만 봐도 "같은 주에 두 번 분석했구나" 인식.

## 다른 7건의 처리 결과 (참고)

- 5건 → 어제(2026-07-08) 동기화에서 이미 처리됨 (hwpxskill, ternlight, job-searcher, meta Pocket, glm-5-2 1차 raw). 5축 detection recipe 로 즉시 ✅신규 0건 + ⏭️처리 5건 분류.
- 5건 → 🚫 skip raw 파일 기록: 단일 YouTube 3건 (grok-4-5 무료 / GPT-5.6+Grok-4.5 동시공개 / 루프 엔지니어링 가이드) + gitconnected Medium proxy 1건 (VS Code 2026) + 상업 listicle 1건 (AI 3D 생성기). 단일 YouTube skip 의 경우 raw/articles/<slug>-skip-YYYY-MM-DD.md 패턴 으로 URL/사유 영구 기록 → 다음 sync 에서 중복 추적.

## raw 파일 8건 작성 분포 (참고)

- 본문 추출 성공 4건: grok-4-5, kakao-wiki, katok, glm-5-2-deepdive
- skip raw (메타만) 5건: 위 5건 (3 YouTube + Medium + listicle)

## 메가 트렌드 (3가지)

1. **"양쪽 동시 가격 압박"** — 폐쇄형(xAI 1/4 가격) + 오픈 가중치(GLM $4.40/MTok) 양쪽 동시 인하 → `[[ai-subscription-timebomb]]` 해결 가속
2. **"한국어 결정론 도구 3종 삼각"** — hwpxskill + kakao-wiki + katok = 한글 HWPX + 카카오톡 + Apple Silicon (모두 7/8~7/9 1주 내 등장) → `[[verification-tax]]` 도메인 확장 5번째
3. **"로컬 임베딩 일체형"** — katok (앱 프로세스 안 EmbeddingGemma) + ternlight (브라우저 7MB WASM) → `[[edge-ai]]` 의 결정 트렌드. 외부 endpoint 의존 제로.

## 권고

- 다음 lint에서 `opensource-llm-platforms-2026` 에 "Grok 4.5 가격 인하 + GLM 5.2 마진 붕괴" 케이스 본문 통합 (현재는 backlink만 추가됨)
- `ai-agents-trends-2026` 섹션 32 후보 = "양쪽 동시 가격 압박" 메가 트렌드
- `kakao-wiki` 의 GREEN/spike-pending/experimental 패턴 = `[[hero]]`/멀티에이전트 가이드라인에 "명시적 미검증 표시" 원칙 추가 가치
- multi-day deep-dive 패턴 (이번 lessons 3번) 은 다른 토픽 (예: GPT-5.6, ternlight) 에도 적용 가능 → 다음 sync 에서 사례 발견 시 확장
