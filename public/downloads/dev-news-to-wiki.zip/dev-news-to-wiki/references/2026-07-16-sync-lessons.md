# 2026-07-16 동기화 교훈

## 1. Wiki 경로 oscillation — SKILL.md의 stale assertion 함정

SKILL.md의 "Wiki Location" 섹션이 `/Users/mac/Documents/ObsidianVault/wiki` (Obsidian vault)
를 강하게 권장하고 있었지만, 이번 세션의 실제 경로는 `/Users/mac/wiki` (plain). 세션 시작
시 `stat`/검증 단계로 발견했고 동기화는 정상 진행되었지만, **prose를 ground truth로 신뢰했다면
놓쳤을 뻔**. SKILL.md에 검증 recipe (4단계 fallback) + "prose는 hint, ground truth는 매번 검증"
강조를 patch로 추가.

**일반화된 규칙:** 멀티-host 워크플로우에서 prose가 단일 경로를 단정하면 의심하라. 호스트 이름,
iCloud 설정, 사용자 계정 이름 중 하나만 바뀌어도 stale이 된다. "Verify, don't assume" 패턴.

## 2. GeekNews selector drift — `<div class=topic_contents>` 더 이상 안정적이지 않음

옛 워크플로우 가이드는 GeekNews 본문을 `<div class=topic_contents>` 셀렉터로 grep했다. 이번
세션에서 `search_files`로 시도했을 때 해당 클래스 매치가 0건. GeekNews가 UI를 리팩토링했거나
클래스명이 변경된 것으로 보임. fallback으로 첫 한국어 키워드(예: "수사본부가", "유출된")로 anchor
찾고, 그 주변 `<p>` 블록을 통째 grep하여 본문 추출. 31444 (PAT 사건) 으로 검증 완료.

**일반화된 규칙:** 사이트 본문 셀렉터는 6개월~1년 주기로 drift한다. 정규식 + selector 기반
추출은 한 번 검증된 셀렉터라도 매 sync 시점에 sanity check 1번 하거나, content-anchor
fallback 패턴을 병행.

## 3. 한국 AI Times — `article_body` (underscore) 첫 시도 성공

llm-wiki skill의 `patch-disaster-case-studies.md` Case "AI Times extraction pattern"에 이미
문서화된 pitfall이 이번에 정확히 들어맞았다: `<div class="...article_body...">` (underscore)
이 실제 본문 컨테이너. 한 번에 추출 성공 (~2500자). 이 패턴은 한국 뉴스 사이트 CMS가 비슷하므로
다른 Korean news 도메인 (전자신문, 디지털타임스, ZDNet Korea 등) 에도 적용 가능할 듯. 현재
SKILL.md에는 AI Times 추출 가이드가 명시적으로 없으므로, 다음 sync lessons.md에 추가 가치.

## 4. Multi-company news → 1 concept page 통합 (AI OS / Agent Phone)

이번 입력 중 **[[ai-os-agent-phone-2026]]** 한 페이지로 통합한 케이스가 기존 SKILL.md의
"엔티티 vs 개념 흡수 판정" pitfall과 정확히 일치했다:
- StepFun (스텝X Neo + Step AOS)
- Honor (화웨이 분사, 알리바바 협업 Agent OS)
- ZTE (Doubao 탑재 폰)
- OpenAI (자체 하드웨어)

→ 4개 entity 페이지가 아니라 **1 concept 페이지로 흡수 + 본문 내 4-row 표 + 각 회사별 섹션**.

판정 기준이 작동했다는 실전 사례. SKILL.md의 해당 pitfall 섹션을 강화할 가치 있음:
- "여러 회사가 등장하는 산업 트렌드 뉴스" → 거의 항상 concept 1페이지로 통합
- 단, "특정 회사의 신제품 출시"가 dominant하면 그 회사만 entity 페이지 + 나머지는 본문 표

## 5. log.md patch glued-line 함정 — atomic header patch의 검증된 사례

이번 세션에서 `## [2026-07-16] ingest | Notion Dev News → LLM Wiki 동기화` 헤더 + 본문 5줄을
한 patch로 삽입하려고 했는데, `old_string`이 어제 entry의 마지막 줄 `- index.md 갱신: 3개
페이지 추가 (Entities 2, Concepts 1)` 까지 포함하면서, `new_string` 끝의 동일 줄이
중복 매치되어 glued line `- index.md 갱신: ... +- index.md 갱신: ...` 발생. 두 patch로
복구 (glued line 제거 + 헤더 복원).

**llm-wiki `patch-disaster-case-studies.md` Case 9** 가 같은 함정을 다룬다. 본 SKILL.md에도
"log.md에 새 entry를 append할 때 `old_string`이 직전 entry의 마지막 줄까지 침범하지 않도록
anchor를 좁게 잡아야 한다" 는 명시적 pitfall 추가 가치 있음. (현재는 index.md patch 함정만
강조되어 있음.)

## 6. "Notion Marking TODO" 의 cron cost 누적

이번 세션도 어제 (7/15) 처리한 2건 (Orca Mode Studio 북마크 + Orca IDE YouTube) 이 신규로
다시 등장했다. 5축 Quick Re-Verification Recipe (5단계의 recipe) 가 작동해서 30초 이내로
no-op 처리. 하지만 이 패턴이 매주 2~3회 반복되면 **연간 ~100회의 중복 fetch + write 작업**
누적. SKILL.md의 "Notion Marking TODO" 섹션은 이미 잘 강조되어 있지만, **"매주 2~3회 → 연간
~100회 중복 작업"** 이라는 정량 비용을 명시하면 upstream script patch 우선순위가 올라갈 듯.

## 7. ⏭️ 이미 처리된 항목의 명시적 표시 — silent skip 회피

이번 세션의 log entry는 ✅/⏭️/🚫 3-way split으로 어제 처리된 2건의 raw 파일 경로까지 명시.
llm-wiki skill의 "Partial-overlap (mixed) batch handling" pitfall이 잘 작동했다. 추가로
이번 cron 보고서에도 동일한 split을 user-facing 형식으로 노출 — owner가 다음 sync에서 같은
URL이 또 등장했을 때 "이건 7/15에 처리했었지" 즉시 식별 가능.

## 8. Backlink 즉시 patch 패턴 재확인

신규 concept 2개 생성 직후, 가장 가까운 기존 entity ([[orca-mode-studio]]) 와 concept
([[double-loop-ai-research]]) 에 outbound backlink 2개씩 patch. 이 패턴은 SKILL.md 9단계에
이미 문서화되어 있고, 이번에도 정확히 그대로 적용됨 — 새로운 학습은 없지만 실전 검증 1회 추가.

## 종합

이번 세션에서 발견된 신규 학습:
- (1) Wiki 경로 oscillation → SKILL.md patch 완료
- (2) GeekNews selector drift → SKILL.md patch 완료
- (3)~(8)은 기존 pitfall의 실전 검증 / 정량화 강화

다음 sync에서 GeekNews 다른 ID로 재검증하여 selector fallback 패턴을 확신할 것.