---
name: dev-news-to-wiki
description: Notion Dev News Archive 뉴스 클리핑을 분석하여 LLM Wiki에 자동 등록
---

# Dev News → Wiki Sync

## Overview
Notion Dev News Archive의 뉴스 클리핑 DB를 매일 분석하여 LLM Wiki에 등록하는 자동화.

## Notion Page
- URL: https://www.notion.so/Dev-24976f2e9097809caecdebede4ee8e2c
- Integration: ICBM2 Notion Integration (연결 완료)
- DB 이름: 뉴스 클리핑
- DB 속성: 이름, 분류(뉴스/인사이트/TIP/오픈소스/iOS), 발견일, 부연설명, 원문 URL, 즐겨찾기

## Schedule
- 크론: 평일(월~금) 20:00
- 스크립트: scripts/dev_news_to_wiki.py

## Workflow
1. Notion API로 당일 추가된 뉴스 클리핑 조회
2. 각 뉴스 분석 → 주인님 취향 기반 필터링
3. 관련 엔티티/컨셉 추출
4. LLM Wiki (~/wiki)에 wikilinks 포함 페이지 생성
5. 결과를 Telegram으로 알림

## 주인님 관심사 프로필
- 분류 비중: 뉴스(35) > 인사이트(25) > TIP(24) > 오픈소스(12) > iOS(4)
- iOS 개발자, AI, 투자 관심
