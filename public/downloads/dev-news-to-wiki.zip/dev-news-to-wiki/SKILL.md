---
name: dev-news-to-wiki
description: Notion Dev News Archive 뉴스 클리핑을 분석하여 LLM Wiki에 자동 등록
---

# Dev News → Wiki Sync

## Overview
Notion Dev News Archive의 뉴스 클리핑 DB를 매일 분석하여 LLM Wiki에 등록하는 자동화.
> Support files: `references/category-registration-guide.md` (category→type mapping + skip patterns), `references/2026-06-04-sync-lessons.md` (earlier session decisions + backlink gaps), `references/2026-06-16-sync-lessons.md` (partial-sync detection / 4-case table / "AI + 도메인 런타임" triple), `references/2026-06-23-sync-lessons.md` (mixed-batch 6+1 처리 / "표준화 3단계" 패턴 / 결정론적 보강 4·5번째 사례 / frontmatter atomic 갱신 7페이지), `references/2026-07-06-sync-lessons.md` (budget-cap partial failure / MK Cloudflare bypass / "write skeleton log.md EARLY" + "write PARTIAL marker EARLIER" recipes), `references/2026-07-09-sync-lessons.md` (4-fetch 1-shot batch pattern / index.md header patch 빈 줄 손실 함정 / multi-day deep-dive "같은 출처 누적 분석" 패턴 / Grok 4.5+kakao-wiki+katok+GLM-5.2-deepdive 사례), `references/2026-07-16-sync-lessons.md` (wiki path oscillation fix / GeekNews selector drift / Agent Phone → concept 통합 / log.md patch glued-line atomicity)

## Notion Page
- URL: `https://www.notion.so/Dev-<DB_ID>` (본인 DB URL로 설정)
- Integration: ICBM2 Notion Integration (연결 완료)
- DB 이름: 뉴스 클리핑
- DB 속성: 이름, 분류(뉴스/인사이트/TIP/오픈소스/iOS), 발견일, 부연설명, 원문 URL, 즐겨찾기

## Schedule
- 크론: 평일(월~금) 20:00
- 스크립트: `~/.hermes/scripts/notion_news_to_wiki.py`

## Wiki Location
**Host-dependent — do NOT assume `~/wiki`.** The path has oscillated across hosts and iCloud
configurations over the project's lifetime (`/Users/hjshin/wiki` → `/Users/mac/Documents/ObsidianVault/wiki`
→ `/Users/mac/wiki`). The current state MUST be verified at the start of every sync rather than
trusted from this skill's prose.

**Verification recipe (do this before any other orientation step):**
```bash
# 1. Try the default
ls ~/wiki/SCHEMA.md 2>/dev/null && echo "FOUND: ~/wiki"

# 2. If missing, try the Obsidian vault
ls ~/Documents/ObsidianVault/wiki/SCHEMA.md 2>/dev/null && echo "FOUND: ~/Documents/ObsidianVault/wiki"

# 3. If still missing, try the legacy /Users/hjshin path (rare)
ls /Users/hjshin/wiki/SCHEMA.md 2>/dev/null && echo "FOUND: /Users/hjshin/wiki"

# 4. NEVER use `find ~ -name wiki` on the Obsidian vault — it hangs.
```

Whichever path's `SCHEMA.md` resolves first is the wiki for this session. Set
`WIKI=<resolved_path>` and use `$WIKI/...` for all subsequent file references. **Do not
hardcode a path from this skill — the prose above is a hint, not ground truth.**

### ⚠️ iCloud-logout stall (2026-07-10)
If the resolved wiki is the iCloud-synced Obsidian vault AND **iCloud Drive is logged out**,
the wiki's files become dataless placeholders: `stat` returns metadata instantly, but any
`read`/`cat`/`ls`/enumeration **blocks forever** (and `read_file` reports false "not found"/
"dedup"). Diagnosis: `brctl download <file>` → `"Logged out - iCloud Drive is not configured"`.
In that state the sync **cannot proceed** (existing pages unreadable → orientation impossible
→ high duplication risk). Abort and report the blocker; do NOT create pages blind. Note:
writes to new files still succeed, but you must be able to READ index.md/log.md/existing
entities first. Wait until iCloud is signed back in and files re-materialize.

If the resolved wiki is at `~/wiki` (plain non-iCloud path, as on some hosts), this stall
does not apply — proceed normally.

### 1단계: 스크립트 실행
```bash
python3 ~/.hermes/scripts/notion_news_to_wiki.py
```
출력의 지시사항을 읽고 Autonomous하게 실행합니다. 크론 컨텍스트에서 실행되므로 Clarify 요청이 불가능합니다.

### 2단계: Wiki 방향 확인 (Orientation)
Wiki 조작 전 반드시 실행 (매번):
1. `~/wiki/SCHEMA.md` 읽기 — conventions, tag taxonomy, page thresholds 파악
2. `~/wiki/index.md` 읽기 — 현재 페이지 목록과 중복 체크
3. `~/wiki/log.md` 마지막 20~30줄 — 최근 활동 확인

### 3단계: Content Fetch (병렬)
여러 항목을 동시에 fetch하면 속도가大幅 향상됩니다. **2~3개씩 병렬 호출**합니다.
- GeekNews (hada.io): 본문 영역 selector는 시간에 따라 변하므로 `curl -o /tmp/<id>.html` 후 `search_files`로 본문 anchor(첫 한국어 키워드, 예: "수사본부가" / "유출된")를 grep하여 추출. 옛 가이드의 `<div class=topic_contents>` 셀렉터는 더 이상 안정적으로 매치하지 않음 (2026-07-16 확인). `mcp_ddg_search_fetch_content`는 Medium 게이트에서 막힘
- 기술 기사 (AI Times 등): `mcp_ddg_search_fetch_content`로 본문 fetch 후 핵심 정리
- 유튜브만 제공: `mcp_ddg_search_search`로 GitHub/프로젝트 페이지를 먼저 검색
- GitHub README: `curl https://raw.githubusercontent.com/<owner>/<repo>/<branch>/README.md`로 직접 fetch 가능
- 각 호출은 `max_length=6000` 설정

### 4단계: Raw Source 파일 작성
각 뉴스 항목의 핵심 내용을 요약하여 `raw/articles/`에 저장.
파일명: `{주제-YYYY-MM-DD}.md`, 형식: 타이틀, URL, Date, Category, 요약

**Content fetch 전략:**
- **hada.io/GeekNews TIP급**: 제목+URL로 핵심 파악 가능 → fetch 불필요, 제목+카테고리+간단 요약만 raw source로 저장
- **AI Times 기술 기사** (깊은 분석, 벤치마크 수치 포함): `mcp_ddg_search_fetch_content`로 본문 fetch 후 핵심 정리
- **유튜브 인사이트**: 제목+카테고리로 판단 → 로컬 GPU 비교, 페르소나 등 기술적 깊이 있는 것은 fetch, 단순 TIP은 skip
- 판단 기준: 항목명에 벤치마크/비교/프레임워크/아키텍처 관련어가 있으면 → fetch

**병렬 fetch 패턴 (중요):** 여러 항목을 동시에 fetch할 때는 2~3개씩 **동시에** 호출한다. `mcp_ddg_search_fetch_content`를 한 번에 여러 개 호출하면 병렬 처리되어 속도가大幅 향상된다. 8개 항목이면 3+3+2 또는 3+3+2로 분할해서 호출. 각 호출은 `max_length=6000`으로 설정 (긴 기술 기사는 6000, GeekNews 급은 4000).

**Content Fetch Fallback Strategy (YouTube / Minimal Content):**
- 유튜브만 제공되는 경우: `mcp_ddg_search_search`로 실제 GitHub 또는 프로젝트 페이지를 먼저 검색. 본문 fetch는 GitHub/프로젝트 페이지에서 수행
  - 예: "OpenSwarm" YouTube → DuckDuckG 검색 → `github.com/openswarm-ai/openswarm` repo 요약으로 Wiki 정보 충당
- GeekNews (hada.io) 요약만 있는 경우: curl로 HTML 본문 직접 추출 → `<div class=topic_contents>...</div>` 영역을 grep
- 403 Forbidden 우회: `mcp_ddg_search_search`로 동일 기사를 dev.to, medium, pasqualepillitteri.it 등 대체 출처에서 검색

**YouTube 영상 처리 강화 (2026-06-04 학습):**
- 제목만 보고 "흥미로워 보이는" YouTube 영상(예: "클로드 코드 Dynamic Workflow 기능 비교", "랄프모드 딥인터뷰")은 **무조건 skip하지 말 것**
- 먼저 `mcp_ddg_search_search`로 영상/채널/주제를 검색해서 본문 텍스트/스크립트/transcript 추출 시도
  - 예: "ralph mode deep interview" → 관련 GitHub repo나 블로그 글 발견되면 fetch
- 추출 불가능하면 skip하되 log에 **"콘텐츠 미확보"** 사유 명시
- 키워드/도구 이름(Ralph mode, Dynamic Workflow)이 주제 자체로 가치가 있으면 **개념 페이지 1개 생성도 고려** — 향후 동기화에서 확장 가능한 시드 페이지
- 이 패턴이 누적되면 `references/workflow-pattern-tracker.md` 같은 **워크플로우 패턴 진화 추적 파일**로 활용 가능

**이미지 기반 콘텐츠 (유머/게임 등):**
- 루리웹 게임 매출 순위, 밈/유머 게시글 등 → **즉시 skip** (주인님 핵심 관심사 AI/ML/iOS/개발자 도구 범위 밖)
- 판단이困难的 경우: "이것이 에이전트, 코딩, iOS, AI 모델, 개발 도구와 직접 관련 있는가?"로 테스트

### 4단계: 분류
Notion DB에 이미 주인님 관심사만 스크랩되어 있으므로, **모든 항목을 Wiki에 등록**합니다.

**분류 규칙:**
- products, models, frameworks, companies, tools → **entities/**
- techniques, formats, theories, paradigms → **concepts/**

### 5단계: 기존 페이지 처리 — "이미 등록" 판단 기준 (2026-06-16 4-case 업데이트, 2026-06-19 5축 레시피 추가)

**4가지 경우가 있음. 각각 다르게 처리해야 함:**

| 상황 | 판단 기준 | 처리 |
|------|-----------|------|
| A. Wiki page 존재 + index 등록 + log 등록 + 내용 충실 | page 있고, index.md/log.md 양쪽에 흔적 있고 updated recent | **Skip** (완전한 previous sync) |
| B. Wiki page 존재 + 내용 陳旧 | page는 있으나 최신 뉴스의 세부사항이 빠져있음 | **Update** — read_file 후 patch로 내용 보강 |
| C. index.md에 wikilink만 있음 + page 없음 | 이전 sync에서 index에만 추가되고 page 파일이 생성 안 됨 | **Create** — page 파일 생성 |
| **D. Wiki page + raw source 존재 + index/log 미등록** | `entities/<slug>.md` 또는 `concepts/<slug>.md`가 있고 `raw/articles/<slug>-*.md`도 있는데 index.md와 log.md에는 흔적 없음 | **Formally register** — page 자체는 만들지 말고, index.md에 wikilink 추가 + log.md에 sync entry 추가. **Skip 금지** (navigation에서 영원히 누락) |

**5축 Quick Re-Verification Recipe (2026-06-19 학습, 다회차 재등장 대응)**:

같은 항목이 3회차 이상 등장하는 경우(예: GLM-5.2 — 06-15 raw+entity → 06-16 정식 등재 → 06-18 no-op → 06-19 재등장) **5축을 모두 한 번에 확인**하여 Case A인지 빠르게 판정:

```bash
SLUG="<item-slug>"  # 예: glm-5-2
WIKI=~/wiki

# 1) entity/concept/comparison page 존재 여부
page_existing=$(ls "$WIKI/entities/$SLUG.md" "$WIKI/concepts/$SLUG.md" "$WIKI/comparisons/$SLUG.md" 2>/dev/null | head -1)

# 2) raw source 파일 존재 여부 + 가장 최근 파일명
raw_files=$(ls "$WIKI/raw/articles/"*$SLUG* 2>/dev/null)
raw_count=$(echo -n "$raw_files" | grep -c .)

# 3) index.md 등록 여부
in_index=$(grep -c "\[\[$SLUG\]\]" "$WIKI/index.md" 2>/dev/null)

# 4) log.md 등록 여부 + 가장 최근 등재 일자
in_log=$(grep -c "\[\[$SLUG\]\]" "$WIKI/log.md" 2>/dev/null)

# 5) entity 페이지 updated 날짜 (최근 7일 이내 = fresh)
updated_recent=$(grep -A1 "^title:" "$WIKI/entities/$SLUG.md" 2>/dev/null | grep "updated:" | awk -F: '{print $2"/"$3}' | tr -d ' ')

echo "page=$page_existing | raw=$raw_count files | index=$in_index | log=$in_log | updated=$updated_recent"
# 5축 모두 hit → Case A (Skip, no-op 처리)
```

**판정 매트릭스:**
- 5축 모두 hit (page + raw + index + log + updated recent) → **Case A → Skip (no-op 처리)**
- page + raw만 있고 index/log 누락 → **Case D → 정식 등재**
- page는 있으나 raw 없음 → **Case B → Update (신규 raw 추가 후)**
- page 없음 → **Create**

> 이 레시피를 매 sync 5단계 시작 시 1번 실행하면, no-op 항목 1~2건에 대해 fetch/raw/page 생성 작업을 생략하고 30초 이내로 처리 가능.

**Case D (orphan-from-partial-sync) — 2026-06-16 학습:**
이전 sync 사이클에서 raw + page 파일은 만들었지만 index.md/log.md 갱신을 빠뜨린 상태에서 cron이 다시 도는 경우 발생. 실전 사례 (2026-06-16):
- `entities/notebooklm-mcp-server.md`, `concepts/local-llm-agentic-coding.md`, `entities/axon.md` 가 모두 raw + page는 존재하지만 index.md에 등재 안 됨
- 직전 lint (2026-06-14) 가 "Index 미등록 페이지 10건" 으로 이미 경고했지만 자동 복구 안 됨
- 단순 "Skip" 으로 처리하면 영원히 navigation에서 누락 → **반드시 정식 등재 (Case D)**

**Detection recipe (Case D 자동 감지):**
```bash
WIKI=~/wiki
for slug in <item-slug-1> <item-slug-2> ...; do
  page_existing=$(ls "$WIKI/entities/$slug.md" "$WIKI/concepts/$slug.md" "$WIKI/comparisons/$slug.md" 2>/dev/null | head -1)
  raw_existing=$(ls "$WIKI/raw/articles/"*$slug* 2>/dev/null | head -1)
  in_index=$(grep -c "\[\[$slug\]\]" "$WIKI/index.md" 2>/dev/null)
  in_log=$(grep -c "\[\[$slug\]\]" "$WIKI/log.md" 2>/dev/null)
  if [[ -n "$page_existing" && "$in_index" -eq 0 ]]; then
    echo "CASE_D: $slug — page=$page_existing, raw=$raw_existing, in_index=$in_index"
    # → formally register, do NOT recreate
  fi
done
```

**실전 판단 (2026-06-16 업데이트):**
- `ruflo.md`: 기존 page가 v3 Claude Flow 수준 → 오늘 v3 (Rust 엔진, 32개 플러그인) 새로운 정보 없음 → **Skip (Case A)**
- `ssh-tunnel-services.md`: 기존 page에 NatNest 상세 내용 포함 → **Update (Case B)**
- `siri-ai-agent.md`: 기존 page는 개요 수준 → 오늘 iOS 27 Siri 상세 디자인 추가 → **Update (Case B)**
- `notebooklm-mcp-server.md` (2026-06-16): page + raw 둘 다 존재, index 미등록 → **Formally register (Case D)**, 절대 Skip 금지

> **핵심 기준:** "이미 등록"은 **4가지 상태 모두를 확인**해야 결정 가능. 단순히 index.md에 있并不能不代表 Skip (Case A만 Skip), page 파일이 있다고 자동으로 Skip도 아님 (Case B는 Update, Case D는 Register). 반드시 page 파일 + raw + index + log 4축을 모두 체크.

### 6단계: Wiki 페이지 작성
Batch로 처리하면 효율적. **모든 write_file을 한 번에 호출한 뒤 한 번에 patch하는 순서**가 context 절약에 유리.

> ⚠️ **index.md patch 주의사항 (중요)**: `patch`의 `old_string`이 파일에서 **2곳 이상** 매치되면 모든 지점이 한 번에 수정됩니다. 이 session에서 중복이 2배로 늘어난 사례가 있습니다. 방지 방법:
> 1. **미리 `read_file`으로 전체 파일을 읽고** 매치 범위 확인
> 2. **unique한 context** (예: surrounding 3줄 이상)를 포함시켜서 매치를 제한
> 3. 2곳 이상 매치되면 `write_file`로 통째 재작성
> 4. **수정 후 `read_file`으로 중복이 사라졌는지 반드시 확인**
> 5. **llm-wiki skill 의 `references/patch-disaster-case-studies.md`** 참고 — alphabetization footgun / frontmatter atomicity 등 디테일 거기 있음

**index.md 정렬 표준:**
- 모든 항목은 `- ` 접두어 (빼기/공백) 사용 — `|- ` 절대 사용하지 말 것
- 중복 항목이 생기기 쉬운 위치: tokenmon, voxcpm2, whichllm 등 기존 항목 근처에 새 항목을 insert할 때
- **반드시 read_file으로 삽입 위치 전후 3줄을 확인**한 뒤 unique context로 patch

**"이미 등록" 판단 기준 — script 출력과 Wiki 현황의 괴리:**
스크립트 출력의 "신규 항목: N건"은 **Notion DB에 새로 추가된 항목**이지, Wiki에まだ登録されていない 항목을 의미하지 않습니다. 동일 항목이昨天 Wiki에 등록된 경우도 "신규"로 표기됩니다.

**따라서 모든 항목에 대해 Wiki existing page check가 필수입니다:**
1. 스크립트 출력의 각 항목을 `search_files`로 Wiki에서 검색
2. page가 이미 존재하면 → **5단계 4-case 표**에 따라 A/B/C/D 판단
3. page가 없으면 → **Create**

실전 판단 (2026-05-19 기준):
- `apple-on-device-openai`, `whichllm`, `sherlock-ai-notes`, `google-skills`, `ai-subscription-timebomb` → 모두昨天的 동기화에서 이미 Wiki 등록됨 → **Skip (Case A)**
- `Emergence World`, `Datatype`, `Tokenova` → Wiki에 없음 → **Create**

### 7단계: Raw Source 파일 작성

각 뉴스 항목의 핵심 내용을 요약하여 `raw/articles/`에 저장.
파일명: `{주제-YYYY-MM-DD}.md`, 형식: 타이틀, URL, Date, Category, 요약

> Note: Raw source 저장은 Wiki page 생성 후에 해도 무방. `/tmp/notion_news_digest.json`에 원본 데이터가 이미 존재하므로 raw source는 "참조용"이며 Wiki page가 주요 산출물이다.

### 8단계: Orphan 검증 (생성 직후 필수)

Orphan = 다른 페이지에서 `[[wikilink]]`로 한 번도 참조되지 않는 페이지. 모든 새 페이지는 반드시 2개 이상의 아웃바운드 wikilink를 포함해야 합니다.

```bash
# 아웃바운드 wikilink가 없는 페이지 찾기
grep -r "\[\[" ~/wiki/entities/ ~/wiki/concepts/ ~/wiki/comparisons/ 2>/dev/null \
  | grep -oE '\[\[[^]]+\]\]' | sort | uniq -c | sort -rn \
  | awk '$1==1 {print $2}' | sed 's/\[\[//g; s/\]\]//g'
```

Orphan이 발견되면 해당 페이지에 [[hermes-agent]], [[ai-agents-trends-2026]] 등 범용 백링크라도 추가합니다.

### 9단계: Cross-Section Backlink (2026-06-16 학습)

신규 entity/concept를 만든 후, 단순 outbound만 채우는 게 아니라 **closest related 페이지에 inbound 백링크를 patch로 즉시 추가**해야 다음 lint가 깨끗하다. 실전 패턴 (2026-06-16):
- `entities/hera-agent-unity.md` 생성 → `entities/acp-ui.md` 의 "관련 엔티티/컨셉" 섹션에 `[[hera-agent-unity]]` 패치 (MCP vs 도메인 한정 우회 대조)
- `concepts/ai-ml-papers-weekly.md` 생성 → `concepts/ai-agents-trends-2026.md` 에 섹션 21 추가 + 3대 트렌드 cross-link
- `entities/perfectpixel-studio.md` 생성 → `concepts/mcp-vs-skills.md` 에 "AI + 결정론적 후처리" 카테고리 추가

이 1-patch-per-page effort 가 graph density 를 유지하고 다음 lint cycle 의 orphan/broken-link 카운트를 0에 가깝게 유지한다. 자세한 pitfall 패턴은 `llm-wiki` skill 의 `references/patch-disaster-case-studies.md` Case 4/9 참고.

## 10단계: 도메인 패턴 인식 (2026-06-04 학습, 2026-06-16 업데이트)

새로운 entity/concept가 등장할 때 **단일 페이지 등록을 넘어 도메인 차원의 패턴으로 승격**할지 검토:

- **"프로덕션 하네스 정렬 학습" 패턴** (MAI-Code-1-Flash): 벤치마크 최적화가 아닌 실제 워크플로 하네스에서 직접 학습하는 새 학습 패러다임 → `concepts/coding-agent-benchmark.md`에 "벤치마크 한계 + harness-aligned training" 섹션 추가
- **"코딩 도구 → 범용 업무 플랫폼" 카테고리 이동** (Codex Plugins/Sites): AI 코딩 에이전트가 비개발자 영역으로 확장하는 트렌드 → `concepts/ai-agents-trends-2026.md`에 "에이전트형 업무 자동화 메인스트림 진입" 섹션 추가
- **"주주 플랫폼 전쟁"** (Anthropic Skills/Cowork vs OpenAI Plugins/Sites vs Microsoft MAI): 3사가 같은 도메인(팀 업무 에이전트)에 진입 → 별도 `concepts/agent-platform-war-2026.md` 페이지 검토 (현재는 트렌드 페이지에 섹션으로 흡수)
- **"AI + 도메인 특화 런타임" 트리플** (2026-06-16): `acp-ui` (범용 통합) / `hera-agent-unity` (Unity 도메인) / `perfectpixel-studio` (스프라이트 도메인) — 같은 "AI + 런타임"이라도 scope 가 다름. `mcp-vs-skills` 또는 `ai-agents-trends-2026` 에 "에이전트 스택 레이어화" 섹션으로 흡수
- **"결정론적 보강" 메타 패턴** (2026-06-16): `local-llm-agentic-coding` (약한 LLM + 결정론적 하니스) + `perfectpixel-studio` (약한 LMM + 결정론적 후처리) — 같은 "모델 약점 → 시스템이 보완" 패턴이 LLM/LMM 양쪽으로 확산. `mcp-vs-skills` 의 4번째 카테고리 후보
- **"자기 수정 루프" 7번째 요소** (2026-06-16): `loop-engineering` 의 6가지 구성요소 (Automations/Worktrees/Skills/Plugins/Sub-agents/Memory) 에 Self-Harness (자기 실패 분석 → 정책 자동 수정) 추가 = 7번째 요소로 승격
- **"Hayekian Incentive-based 오케스트레이션"** (2026-06-16): `multi-model-orchestration` 의 3가지 패턴 (Advisor/Router/Cascade) 에 Economy of Minds (경매 기반 인센티브) 가 4번째 패턴 후보
- **"인식된 도메인 패턴이 3건 이상 누적되면 별도 concept 페이지 분리** — 그렇지 않으면 ai-agents-trends-2026 같은 트렌드 페이지가 비대해짐 (200줄 임계점 주의)
- **"에이전트 표준화 3단계" 패턴** (2026-06-23 학습): 표준화는 한 단계로 끝나지 않는다 — 통신([[agent-client-protocol]] / [[mcp-vs-skills]]) + 배포([[agent-connector]]) + UI([[acp-ui]]) 가 함께 가야 생태계가 완성됨. 한 단계만 있는 표준은 종속을 만든다. 향후 OpenAPI/LSP 같은 다른 표준 생태계에도 적용 가능한 메타-패턴
- **"한국 AI 도구의 실무화" 패턴** (2026-06-23, mydoo): Anthropic의 [[claude-cowork]] 같은 도메인 자율 에이전트 비전을 한국 SMB/SOHO 시장 로컬라이제이션으로 풀어내는 흐름. 모바일 승인 / 팀 기억 공유 / 프리랜서 과정 기억 등 한국 사용자 워크플로우 친화 기능이 글로벌 도구와 차별화되는 지점
- **"자연어 → 데이터셋 자급자족 파이프라인" 패턴** (2026-06-23, bigset): AI가 자체 데이터를 만들고([[bigset]]) / 저장하고([[gitdb]]) / 소비하는([[hermes-agent]]) 파이프라인. [[ai-readable-gazette-kr]] 같은 정적 코퍼스와 대비되는 **동적 라이브 데이터셋** 영역의 출현

이런 패턴 인식은 **다음 동기화에서 cross-reference 작업 부하를 大幅 줄임** + 사용자(희정님)에게 "기술 트렌드의 큰 그림" 인사이트 제공.

## Pitfalls

### frontmatter 필수: title, created, updated, type, tags (taxonomy만), sources
- 최소 2개 이상의 outbound `[[wikilinks]]` 포함
- 기존 페이지 있으면 새 정보만 추가, updated 날짜 갱신
- 같은 entity/concept에 여러 뉴스가 있으면 **한 페이지에 병합** (중복 방지)

### Skip decision trees (주인님 관심사 프로필)
> See `references/category-registration-guide.md` for detailed category→type mapping and correct skip patterns.
- **Tutorials/How-to**: 단일 튜토리얼은 항상 skip (Git 커밋 로그 자동화 등)
- **인사이트 (insight)**: 새 엔티티/개념 있으면 등록, 없으면 skip
- **TIP (tool)**: 도구/플랫폼이면 entities/, 개념적 추상화면 concepts/
- **오픈소스**: entities/에 등록하는 것이 기본

### index.md patch 주의사항 (중요)
> ⚠️ `patch`의 `old_string`이 파일에서 **2곳 이상** 매치되면 모든 지점이 한 번에 수정됩니다.
> 1. `read_file`으로 전체 파일 읽고 매치 범위 확인
> 2. unique context 3줄 이상 포함시켜서 매치 제한
> 3. 2곳 이상 매치되면 `write_file`으로 통째 재작성
> 4. 수정 후 `read_file`으로 중복 확인

### Case D (partial-sync) 안티패턴 (2026-06-16)
- "스크립트가 신규 7건 줬네, 그 중 일부는 Wiki 에 이미 있나? 없으면 만들면 되지" 라는 단순 사고방식이 **Case D 를 놓침**
- raw + page 가 만들어져 있는데 index/log 만 누락된 상태는 "이미 처리됨" 으로 보이지만 **navigation 에서는 영원히 invisible**
- 직전 lint 가 "Index 미등록 페이지 10건" 경고를 했는데 cron sync 가 자동 복구하지 않는 한, **다음 sync 의 5단계에서 반드시 formal re-registration**
- detection recipe (위 5단계 코드) 를 매 sync 시작 시 실행해서 case D 후보를 명시적으로 식별

### 외부 fetch 보안 (cron 컨텍스트)
- `curl | python3 -c` 같은 **pipe to interpreter 패턴은 보안을 위해 자동 거부됨** (cron 모드)
- 우회: `curl -o /tmp/file.html` 으로 파일 저장 후 `read_file` / `search_files` 로 내용 추출
- GeekNews 본문 추출 시: HTML 의 `<div class=topic_contents>...</div>` 영역을 search_files 로 grep
- Medium / Notion JS-only 페이지는 본문 fetch 불가 → `fetch_status: partial` 명시 + 메타데이터만으로 concept 페이지 작성 (llm-wiki skill `references/patch-disaster-case-studies.md` Case 5 참고)

### Notion Marking TODO (Recurring Pain)
`notion_news_to_wiki.py` does NOT mark processed items in Notion. 2026-06-02 → 2026-06-03 sync no-op 사례 + 2026-06-15 partial-sync 사례 + 2026-06-18 GLM-5.2 no-op 사례 — 같은 root cause. 동일 항목이 3회차 연속 재등장하는 패턴이 상례화됨 → **5단계의 5축 Quick Re-Verification Recipe**로 매 sync 시작 시 1번 실행하여 fetch/save 작업 생략.
- Add a `Wiki-synced` date property to the Notion DB schema
- Modify the script to set `Wiki-synced = True` and `Wiki-synced-at = YYYY-MM-DD` after processing
- This would let the collector skip already-processed items at the source
- Filed for upstream script patch. This is a script issue, not a workflow issue, but the **5-axis detection recipe** in 5단계 is the partial mitigation until the upstream patch lands.

### Budget Cap is Environment-Imposed, NOT the 50-call execute_code limit (2026-07-06)

Hermes' "**maximum number of tool-calling iterations allowed**" message
can fire well before any single tool hits its own limit — Hermes stops
the *whole turn* when cumulative call count exceeds the runtime ceiling
for that profile. The `llm-wiki` skill's 35-call "stop and write log.md"
hard rule is still correct but may be too late on tighter profiles.

Tightened rules for cron-driven Notion syncs (see `references/2026-07-06-sync-lessons.md` for full breakdown):

1. **Write skeleton `log.md` entry BEFORE Phase 4 (raw writes)** — append
   `## [YYYY-MM-DD] ingest | Notion Dev News → LLM Wiki 동기화 (in progress)`
   right after Phase 2 triage completes, then update incrementally as each
   phase lands. Recovery from "log entry exists but incomplete" is trivial;
   recovery from "no log entry at all" requires re-orienting and
   reverse-engineering what got done.
2. **Batch all `write_file` calls per phase into ONE parallel block** —
   never write one raw file at a time. 2026-07-06 collapse (8 raws in
   one parallel batch) saved ~7 calls vs serial.
3. **Write `<!-- PARTIAL SYNC — index/log NOT updated -->` marker EARLIER** —
   if Phase 4 finishes but Phase 5 is taking more than 3 entity pages,
   write the marker to `index.md` BEFORE creating more entities. The
   marker is recoverable; missing index entries are not.
4. **Symptom of imminent cap**: tool returns start denying
   non-whitelisted tools with "Background review denied" /
   "Other tools will be denied at runtime" — STOP creating content,
   switch to writing `log.md` and `index.md` immediately. This is the
   final warning signal before the turn ends.
5. **Surface PARTIAL SYNC prominently in the cron report** — ⚠️ marker
   in the FIRST paragraph, not buried in a bullet list. 2026-07-06 had
   this right; preserve that pattern.

### execute_code 차단 시 본문 추출 워크플로우 (2026-06-19 학습)

Cron 모드에서는 `execute_code`가 자동 거부됨 (`BLOCKED: execute_code runs arbitrary local Python...cron jobs run without a user present to approve it`). 본문 fetch/HTML 파싱이 필요할 때 대안 패턴:

1. **원격 페이지를 curl로 디스크에 저장**
   ```bash
   curl -sL "https://news.hada.io/topic?id=30608" -o /tmp/gitdb.html
   curl -sL "https://www.aitimes.com/news/articleView.html?idxno=211877" -o /tmp/china-mem.html
   ```

2. **`search_files`로 본문 영역 grep** (target=content, path=/tmp/<file>.html)
   - GeekNews (hada.io): `<div class=topic_contents>...</div>` 영역 (정규식 `topic_contents`)
   - AI Times: `<article id="article-view-content-div"...>` 영역 (정규식 `article-view-content-div`)
   - 라인 번호와 매치 1건 정도가 나오면 본문 영역의 시작점 확보

3. **`read_file`로 offset/limit 지정하여 본문 읽기**
   ```python
   read_file(path="/tmp/gitdb.html", offset=115, limit=100)
   ```
   → HTML markup이 섞여 있지만 핵심 본문 추출 가능

4. **본문 정제는 raw/articles/<slug>-YYYY-MM-DD.md 작성 시 수행**
   - URL, Date, Category, 핵심 문단 5~10개로 요약
   - HTML tag는 write_file 시 자연스럽게 정리됨

이 패턴은 4개 항목을 1분 이내 fetch 가능 (병렬 curl + 순차 read_file로). Notion JS-only 페이지는 본 단계에서 fetch 실패 → raw에 `fetch_status: not_extracted` 명시 후 개념 페이지로 흡수 (Case 5 패턴).

### 엔티티 vs 개념 흡수 판정 (2026-06-19 학습)

시장/산업 뉴스(예: "중국 메모리 글로벌 PC 공급망 침투")처럼 **명확한 신생 엔티티가 아니라 산업 트렌드/시장 이슈**인 경우, 신규 엔티티 페이지를 만들지 않고 **기존 concept 페이지에 섹션으로 흡수**하는 것이 위키 건강도에 유리:

**판정 기준:**
- 1개 회사/제품/모델이 명확 → entity 페이지 생성
- 산업 트렌드/시장 이슈 + 여러 회사 등장 → concept 페이지 섹션 추가 (예: [[hbm-ai-chip-costs]] + [[china-ai-lab-culture]] 에 분산 흡수)
- 단순 분석/코멘터리 → raw source만 저장 + 개념 페이지 본문 업데이트에 활용
- 위키에 이미 비슷한 concept 페이지가 있으면 신규 entity 생성을 자제하고 cross-link 위주로

이 패턴은 페이지 수 비대화를 방지하고 graph density를 유지. 신규 entity를 만들었다면 최소 2개 이상의 outbound `[[wikilinks]]` 필수 + 가장 가까운 concept 페이지에 inbound backlink 1개 추가.

### index.md 헤더 patch가 빈 줄을 삼키는 함정 (2026-07-09)

`Last updated | Total pages` 한 줄만 매칭하도록 `old_string`을 좁게 잡으면 `## Entities` 직전의
빈 줄이 사라지면서 quote-block 스타일이 깨짐. 검증된 8줄 structural verify 와 recovery patch 패턴은
`references/2026-07-09-sync-lessons.md` "index.md 헤더 patch의 빈 줄 손실 함정" 섹션 참조. 요약:
- `old_string`에 최소 `## Entities` 까지 포함한 structural anchor 사용
- patch 직후 **항상** `read_file` 로 첫 8줄 verify
- 회귀 발견 시 → 1줄 recovery patch로 빈 줄 1개 복구 (2 patches 가 1 botched write보다 빠름)

### multi-day deep-dive 패턴 — "같은 출처, 누적 분석" (2026-07-09)

이전 sync (예: 7/8) 에서 동일 URL 의 raw 가 이미 존재하고, 새 sync (7/9) 에서 같은 URL 의 더 깊은
분석이 가능해진 경우. 처리 결정:
- ❌ 어제 raw 를 overwrite / 어제 raw 에 추가 (raw 불변성 위반)
- ✅ **새 raw 파일** `raw/articles/<slug>-deepdive-YYYY-MM-DD.md` 생성 + entity `sources:` 에
  양쪽 동시 등록 + 본문 새 섹션에 "1차 pass (yesterday) / 2차 pass (today)" 명시
- log entry 에도 "동일 출처의 누적 분석" 명시

GLM 5.2 추론 마진 분석 사례 (7/8 1차 pass + 7/9 2차 pass = 3차원으로 확장: $4.40/MTok + 90% 마진
가설 + AMD Wafer 2.75배 등). raw 불변성 + 누적 분석 시점 비교 + 다음 sync 가 같은 소스 재방문
시 즉시 식별 가능. 전체 패턴 디테일은 `references/2026-07-09-sync-lessons.md` 참조.

> Note: Raw source 저장은 Wiki page 생성 후에 해도 무방. `/tmp/notion_news_digest.json`에 원본 데이터가 이미 존재하므로 raw source는 "참조용"이며 Wiki page가 주요 산출물이다.
