---
name: dev-news-to-wiki
description: Notion Dev News Archive 뉴스 클리핑을 분석하여 LLM Wiki에 자동 등록
---

# Dev News → Wiki Sync

## Overview
Notion Dev News Archive의 뉴스 클리핑 DB를 매일 분석하여 LLM Wiki에 등록하는 자동화.

## Notion Page
- URL: `https://www.notion.so/Dev-<DB_ID>` (본인 DB URL로 설정)
- Integration: ICBM2 Notion Integration (연결 완료)
- DB 이름: 뉴스 클리핑
- DB 속성: 이름, 분류(뉴스/인사이트/TIP/오픈소스/iOS), 발견일, 부연설명, 원문 URL, 즐겨찾기

## Schedule
- 크론: 평일(월~금) 20:00
- 스크립트: `~/.hermes/scripts/notion_news_to_wiki.py`

## Workflow (정확한 절차)

### 1단계: 스크립트 실행
```bash
python3 ~/.hermes/scripts/notion_news_to_wiki.py
```
출력의 지시사항을 반드시 읽고 따를 것.

### 2단계: Wiki 방향 확인 ( Orientation)
Wiki 조작 전 반드시 실행:
1. `SCHEMA.md` 읽기 — conventions, tag taxonomy, page thresholds 파악
2. `index.md` 읽기 — 현재 페이지 목록과 중복 체크
3. `log.md` 마지막 20~30줄 — 최근 활동 확인

### 3단계: 소스 콘텐츠 수집
각 뉴스 항목의 URL에서 `mcp_ddg_search_fetch_content`로 본문 가져오기.
원문은 `raw/articles/`에 저장 (sources frontmatter용).

### 4단계: 분류
Notion DB에 이미 주인님 관심사만 스크랩되어 있으므로, **모든 항목을 Wiki에 등록**합니다.

**분류 규칙:**
- products, models, frameworks, companies, tools → **entities/**
- techniques, formats, theories, paradigms → **concepts/**

### 5단계: Wiki 페이지 작성
- frontmatter 필수: title, created, updated, type, tags (taxonomy만), sources
- 최소 2개 이상의 outbound `[[wikilinks]]` 포함
- 기존 페이지 있으면 새 정보만 추가, updated 날짜 갱신

### 6단계: Navigation 갱신
- `index.md`: 새 페이지 추가 ( alphabetical ), Total pages + 헤더 갱신
- `log.md`: `## [YYYY-MM-DD] ingest | Notion Dev News → LLM Wiki 동기화` 형식으로Append

## 주인님 관심사 프로필
Notion DB에 이미 관심사만 스크랩되어 있으므로, 모든 항목을 Wiki에 등록합니다.
