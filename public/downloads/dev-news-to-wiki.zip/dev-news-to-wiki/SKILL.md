---
name: dev-news-to-wiki
description: Notion Dev News Archive 뉴스 클리핑을 분석하여 LLM Wiki에 자동 등록
---

# Dev News → Wiki Sync

## Overview
Notion Dev News Archive의 뉴스 클리핑 DB를 매일 분석하여 LLM Wiki에 등록하는 자동화.

## Notion Page
- URL: `https://www.notion.so/Dev-<DB_ID>` (본인 DB URL로 설정)
- Integration: ICBM2 Notion Integration (연결 완료)
- DB 이름: 뉴스 클리핑
- DB 속성: 이름, 분류(뉴스/인사이트/TIP/오픈소스/iOS), 발견일, 부연설명, 원문 URL, 즐겨찾기

## Schedule
- 크론: 평일(월~금) 20:00
- 스크립트: `~/.hermes/scripts/notion_news_to_wiki.py`

## Workflow (정확한 절차)

### 1단계: 스크립트 실행
```bash
python3 ~/.hermes/scripts/notion_news_to_wiki.py
```
출력의 지시사항을 반드시 읽고 따를 것.

### 2단계: Wiki 방향 확인 ( Orientation)
Wiki 조작 전 반드시 실행:
1. `SCHEMA.md` 읽기 — conventions, tag taxonomy, page thresholds 파악
2. `index.md` 읽기 — 현재 페이지 목록과 중복 체크
3. `log.md` 마지막 20~30줄 — 최근 활동 확인

### 3단계: Raw Source 파일 작성
각 뉴스 항목의 핵심 내용을 요약하여 `raw/articles/`에 저장.
파일명: `{주제-2026}.md`, 형식: 타이틀, URL, Date, Category, 요약

**Content fetch 전략:**
- 짧거나 자체 설명적인 항목 (hada.io 토픽, 간단한 뉴스): 최소 요약만으로 충분
- 복잡하거나 기술적으로 깊은 항목 (AI Times 기사, 유튜브 인사이트): `mcp_ddg_search_fetch_content`로 본문 fetch
- 판단 기준: 항목 당 2분 안에 핵심을 파악할 수 있으면 → 직접 요약, 아니면 → fetch

### 4단계: 분류
Notion DB에 이미 주인님 관심사만 스크랩되어 있으므로, **모든 항목을 Wiki에 등록**합니다.

**분류 규칙:**
- products, models, frameworks, companies, tools → **entities/**
- techniques, formats, theories, paradigms → **concepts/**

### 5단계: Wiki 페이지 작성
Batch로 처리하면 효율적:
1. 먼저 모든 raw source 파일을 한꺼번에 write_file
2. 그 다음 모든 Wiki page 파일을 한꺼번에 write_file
3. 기존 페이지 업데이트는 patch로 한꺼번에 처리

**주의:** Wiki page를 먼저 다 쓰고, 그다음 index.md/log.md를 마지막에 한꺼번에 갱신. 순서 바뀌면 index가 불일치.

- frontmatter 필수: title, created, updated, type, tags (taxonomy만), sources
- 최소 2개 이상의 outbound `[[wikilinks]]` 포함
- 기존 페이지 있으면 새 정보만 추가, updated 날짜 갱신
- 같은 entity/concept에 여러 뉴스가 있으면 **한 페이지에 병합** (중복 방지)

### 6단계: Navigation 갱신
- `index.md`: 새 페이지 추가 ( alphabetical ), Total pages + 헤더 갱신
- `log.md`: `## [YYYY-MM-DD] ingest | Notion Dev News → LLM Wiki 동기화` 형식으로Append

## 주인님 관심사 프로필
Notion DB에 이미 관심사만 스크랩되어 있으므로, 모든 항목을 Wiki에 등록합니다.

**실제 적용된 건너뜀 기준 (2026-04-29 확인):**
- 하드웨어 프로젝트 (가정용 DRAM 등) — 관심사 범위 밖
- 단순 산업 뉴스 (시장 확장, 단순 파트너십) — 새로운 개념/엔티티 없음
- 단일 TIP 급 item — 핵심 관심사에 부합하지 않으면 skip
- 접근 불가 URL (403 등) — skip 후 보고
