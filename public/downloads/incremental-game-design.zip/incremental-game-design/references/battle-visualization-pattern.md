# Battle Visualization Pattern (Last Banner 7단계, 2026-07-16)

> 결정 다이얼로그의 텍스트 결과를 **CK3 양식 3단계 시각화**로 전환. 주사위 애니메이션 + 그리드 + 손실 카드.

---

## 문제 → 해결

**문제**: `BANDIT_RAID` 결정 다이얼로그에서 출격/숨기/뇌물 선택 → 결과는 텍스트 한 줄 출력만. 사용자가 "전투가 일어났다"는 시각적 임팩트를 못 느낌.

**해결**: `BattleScene`이 별도 화면으로 띄워 **3단계 상태머신** (Decision → Simulating → Result)으로 전투 진행을 시각화.

---

## 3단계 상태머신

```
DecisionDialog 출격/숨기/뇌물 클릭
    ↓
BattleScene.show_battle(enemy_count, my_power, enemy_power)
    ├─ DECISION — 출격/숨기/뇌물 버튼 (전투 시작 전)
    ├─ SIMULATING — 주사위 3번 굴림 애니메이션 → 최종 주사위
    └─ RESULT — 승/패 + 손실 카드 → 5초 후 자동 종료
```

---

## 씬 구조 (`scenes/battle_scene.tscn`)

```
BattleScene (Control, anchor_full)
├── DimBG (ColorRect, Color(0.05, 0.04, 0.03, 0.97), mouse_filter=0)
└── MainVBox (VBoxContainer)
    ├── TopMargin (MarginContainer) — 24px
    │   └── Header (HBoxContainer)
    │       ├── TitleLabel "⚔️ 전투"
    │       └── PhaseLabel "결정 단계" (색상 modulate로 단계 표시)
    ├── ContentMargin (size_flags_vertical=3)
    │   └── ContentVBox (VBoxContainer, separation=16)
    │       ├── TroopRow (HBoxContainer, separation=24, vertical=3)
    │       │   ├── AlliesCard (PanelContainer, size=expand) — 🛡️ 아군
    │       │   │   └── AlliesMargin (16/12/16/12)
    │       │   │       └── AlliesVBox (separation=6)
    │       │   │           ├── AlliesTitle "🛡️ 아군" (font 16)
    │       │   │           ├── AlliesStats "전투력: N"
    │       │   │           └── AlliesGrid (GridContainer, columns=5, vertical=3)
    │       │   ├── VSLabel "⚔️\nVS" (custom_min_width=60, center)
    │       │   └── EnemiesCard (PanelContainer, size=expand) — 💀 적군
    │       │       └── EnemiesMargin / EnemiesVBox (대칭 구조)
    │       └── BottomCard (PanelContainer, min_height=160)
    │           └── BottomMargin (20/16/20/16)
    │               └── BottomVBox (separation=8)
    │                   ├── StatusLabel "전투 준비 중..." (font 16)
    │                   ├── DiceLabel "" (center, font 28, modulate gold)
    │                   └── ChoicesRow (HBox, separation=8)
    └── BottomMargin2 (24/0/24/12)
        └── BottomHBox (separation=12)
            ├── Spacer (expand)
            └── CloseButton "닫기 (B)" (180x44)
```

**핵심**:
- `AlliesGrid`/`EnemiesGrid`는 **런타임 동적 채우기** (씬에 박지 X). `show_battle()` 호출 시 `_allies`/`_enemies` 리스트로 채움.
- `ChoicesRow`도 동적 — 결정 단계에서는 선택지 버튼, 결과 단계에서는 "전투 종료" 버튼 1개.
- VSLabel은 단순 텍스트 (UI 안 어수선하지 않게).

---

## 상태머신 구현 (`scripts/battle.gd`)

```gdscript
enum Phase { DECISION, SIMULATING, RESULT }

var _phase: Phase = Phase.DECISION
var _enemy_count: int = 0
var _my_power: int = 0
var _enemy_power: int = 0
var _allies: Array = []          # GameWorld.alive_mercenaries().duplicate(true)
var _enemies: Array = []         # {"id", "name", "alive"} dict 리스트
var _allied_losses: int = 0
var _enemy_losses: int = 0
var _outcome: String = ""

func show_battle(enemy_count: int, my_power: int, enemy_power: int) -> void:
    _enemy_count = enemy_count
    _my_power = my_power
    _enemy_power = enemy_power
    _allied_losses = 0
    _enemy_losses = 0
    _outcome = ""

    # 아군 = 살아있는 용병
    _allies = GameWorld.alive_mercenaries().duplicate(true)
    # 적군 = bandit 무작위 생성
    _enemies.clear()
    for i in range(enemy_count):
        _enemies.append({
            "id": i,
            "name": "약탈자 %d" % (i + 1),
            "alive": true
        })

    _phase = Phase.DECISION
    visible = true
    _render_decision_phase()


func _render_decision_phase() -> void:
    phase_label.text = "결정 단계"
    phase_label.modulate = Color(1.0, 0.85, 0.4)
    status_label.text = "약탈자 %d명이 출몰! 출격하시겠습니까?" % _enemy_count
    dice_label.text = ""
    allies_stats.text = "전투력: %d (%d명)" % [_my_power, _allies.size()]
    enemies_stats.text = "전투력: %d (%d명)" % [_enemy_power, _enemy_count]

    _populate_grid(allies_grid, _allies, "ally")
    _populate_grid(enemies_grid, _enemies, "enemy")

    # 선택지 버튼 동적 생성
    for child in choices_row.get_children():
        child.queue_free()
    var choices := [
        { "id": "fight", "label": "⚔️ 출격", "color": Color(0.9, 0.4, 0.4) },
        { "id": "hide",  "label": "🏰 영지에 숨기", "color": Color(0.6, 0.6, 0.9) },
        { "id": "bribe", "label": "💰 뇌물 (%d골드)" % (10 + _enemy_count * 2), "color": Color(0.9, 0.8, 0.4) },
    ]
    for c in choices:
        var btn := Button.new()
        btn.text = c.label
        btn.custom_minimum_size = Vector2(0, 48)
        btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        btn.modulate = c.color
        btn.pressed.connect(_on_choice_pressed.bind(c.id))
        choices_row.add_child(btn)


func _on_choice_pressed(choice_id: String) -> void:
    _choice_made = choice_id
    for child in choices_row.get_children():
        child.queue_free()
    match choice_id:
        "fight":
            _phase = Phase.SIMULATING
            phase_label.text = "전투 중..."
            phase_label.modulate = Color(1.0, 0.4, 0.4)
            await _run_simulation()
        "hide":
            _outcome = "retreat"
            _render_result_phase("🏰 영지에 숨었습니다", "안전하지만 약탈자에게 약탈당했습니다 (식량/명성 손실).")
        "bribe":
            _outcome = "bribe"
            _render_result_phase("💰 뇌물 지급", "약탈자가 떠나갔습니다. %d골드를 잃었습니다." % (10 + _enemy_count * 2))


func _run_simulation() -> void:
    status_label.text = "⚔️ 전투 진행 중..."
    dice_label.text = "🎲 주사위 굴리는 중..."

    # 주사위 3번 굴림 애니메이션
    for i in range(3):
        dice_label.text = "🎲 %d" % (randi() % 20 + 1)
        await get_tree().create_timer(0.2).timeout

    # 최종 주사위
    var dice_roll: int = (randi() % 20) + 1
    dice_label.text = "🎲 %d" % dice_roll
    status_label.text = "전투력 %d vs %d, 주사위 %d" % [_my_power, _enemy_power, dice_roll]

    # 결과 판정 — CK3 양식: 전투력 + 주사위 비교
    var my_score: int = _my_power + dice_roll
    var enemy_score: int = _enemy_power + (randi() % 20) + 1
    var victory: bool = my_score > enemy_score

    if victory:
        _outcome = "victory"
        _allied_losses = int(_enemy_count * 0.15 * randf())      # 0~15%
        _enemy_losses = int(_enemy_count * 0.3 * randf())        # 0~30%
    else:
        _outcome = "defeat"
        _allied_losses = int(_enemy_count * 0.25 * randf()) + 1  # +1
        _enemy_losses = int(_enemy_count * 0.1 * randf())

    _apply_losses(_allies, _allied_losses, "ally")
    _apply_losses(_enemies, _enemy_losses, "enemy")

    # 그리드 갱신 (사망자 어두워짐)
    _populate_grid(allies_grid, _allies, "ally")
    _populate_grid(enemies_grid, _enemies, "enemy")

    await get_tree().create_timer(1.5).timeout

    var outcome_text: String
    var outcome_detail: String
    match _outcome:
        "victory":
            outcome_text = "🎉 승리!"
            outcome_detail = "아군 손실: %d명 사망, 적 손실: %d명 처치" % [_allied_losses, _enemy_losses]
        "defeat":
            outcome_text = "💀 패배..."
            outcome_detail = "아군 손실: %d명 사망, 적 손실: %d명 처치" % [_allied_losses, _enemy_losses]
    _render_result_phase(outcome_text, outcome_detail)


func _apply_losses(units: Array, losses: int, side: String) -> void:
    var actual: int = min(losses, units.size())
    var rng := RandomNumberGenerator.new()
    rng.randomize()
    for i in range(actual):
        var idx: int = rng.randi() % units.size()
        units[idx].alive = false
    # 아군 사망자는 GameWorld에서도 처리
    if side == "ally":
        var alive_in_gw: Array = GameWorld.alive_mercenaries()
        for i in range(min(losses, alive_in_gw.size())):
            var victim: Dictionary = alive_in_gw[0]
            victim.alive = false
            GameWorld.dismiss_mercenary(victim, "전투 사망")


func _render_result_phase(title: String, detail: String) -> void:
    _phase = Phase.RESULT
    phase_label.text = "결과"
    phase_label.modulate = Color(0.7, 1.0, 0.7) if _outcome == "victory" else Color(1.0, 0.6, 0.6)
    status_label.text = "%s\n\n%s" % [title, detail]
    dice_label.text = ""

    # 닫기 버튼만 표시
    for child in choices_row.get_children():
        child.queue_free()
    var btn := Button.new()
    btn.text = "전투 종료 (닫기)"
    btn.custom_minimum_size = Vector2(0, 48)
    btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    btn.pressed.connect(_finish_battle)
    choices_row.add_child(btn)

    # GameWorld.apply_result 호출 (이미 다이얼로그에서 처리됐으면 스킵)
    GameWorld.resolve_battle(_outcome, _allied_losses, _allied_losses / 2)
    battle_finished.emit(_outcome, _allied_losses, _enemy_losses)

    # 5초 후 자동 종료
    await get_tree().create_timer(5.0).timeout
    if visible and _phase == Phase.RESULT:
        _finish_battle()


func _populate_grid(grid: GridContainer, units: Array, side: String) -> void:
    for child in grid.get_children():
        child.queue_free()
    for u in units:
        grid.add_child(_create_unit_card(u, side))


func _create_unit_card(u: Dictionary, side: String) -> PanelContainer:
    var card := PanelContainer.new()
    card.custom_minimum_size = Vector2(80, 80)
    # ... 마진 + vbox + 아이콘(⚔️/💀/🗡️/☠️) + 이름 라벨 ...
    if not u.alive:
        card.modulate = Color(0.4, 0.4, 0.4, 0.6)  # 사망자 어둡게
    elif side == "ally":
        card.modulate = Color(0.6, 0.85, 1.0)
    else:
        card.modulate = Color(1.0, 0.5, 0.5)
    return card
```

---

## 결정 다이얼로그 ↔ 전투 자동 연동

현재 Last Banner는 메뉴의 "전투 시뮬레이션 (B)" 버튼으로 수동 트리거. 실제 게임에선 BANDIT_RAID 결정 후 자동 호출이 정석:

```gdscript
# scripts/decision_dialog.gd 안에서
func _on_choice_pressed(choice: Dictionary) -> void:
    var decision_id: int = _current_decision.id
    var result_code: String = choice.get("result", "")
    var payload: Dictionary = _current_decision.payload

    if not result_code.is_empty():
        GameWorld.apply_result(result_code, payload)

    # BATTLE_BANDITS_FIGHT 선택 시 BattleScene 자동 표시
    if result_code == "BATTLE_BANDITS_FIGHT" and battle_scene and battle_scene.has_method("show_battle"):
        var enemy_count: int = payload.get("enemy_count", 5)
        var my_power: int = GameWorld.alive_mercenaries().size() * GameWorld.fortification_level
        var enemy_power: int = enemy_count * 2
        battle_scene.show_battle(enemy_count, my_power, enemy_power)
        # 결정 큐 resolve는 BattleScene 완료 후로 미룸 (await battle_scene.battle_finished)

    DecisionQueue.resolve(decision_id, choice)
```

**왜 결정 후 BattleScene을 띄우는가**: `apply_result`가 확률 기반으로 즉시 처리하므로 시각화 효과는 약함. `apply_result` 호출을 **BattleScene 결과 단계에서**로 미루고, 대신 `show_battle`만 호출. BattleScene이 시뮬레이션 끝에 `GameWorld.apply_result(BATTLE_BANDITS_FIGHT, payload)` + `resolve_battle()` 호출.

**단점**: 결정 다이얼로그의 `_on_choice_pressed` 흐름이 복잡해짐. **해결**: `battle_scene.battle_finished` 시그널 await → resolve. 또는 단순화해서 결정 후 즉시 자원 변동 + 전투 화면은 별도 시뮬레이션(Last Banner 현재 상태).

---

## GDScript 실전 함정 3가지 (Last Banner 7단계 검증 발견)

### 1. `var: Dictionary = Array()` 타입 미스매치

```gdscript
# ❌ 파스 에러: Cannot assign a value of type Array to variable "m" with specified type Dictionary
var m: Dictionary = GameWorld.alive_mercenaries()

# ✓ Array로 선언
var m: Array = GameWorld.alive_mercenaries()
if m.size() > 0:
    var victim: Dictionary = m[0]
```

**진단**: `Compile Error: Cannot assign ... of type Array to variable with specified type Dictionary` → 변수 타입 어노테이션이 Array 반환 함수와 미스매치. grep으로 반환 타입 확인.

### 2. tscn Label에 `modulate = Color(...)` 직접 작성 → 파스 에러

```ini
# ❌ Parse error: res://scenes/battle_scene.tscn:77
[node name="AlliesTitle" type="Label" parent="..."]
text = "🛡️ 아군"
modulate = Color(0.6, 0.85, 1.0)   # ← Label은 tscn에서 modulate 직렬화 안 됨
```

**해결 3가지**:
```ini
# (1) theme_override_colors
text = "🛡️ 아군"
theme_override_colors/font_color = Color(0.6, 0.85, 1.0)

# (2) 단순화 — modulate 제거 (기본 흰색)
text = "🛡️ 아군"

# (3) .gd 코드에서 런타임 적용
# label.modulate = Color(0.6, 0.85, 1.0)   # .gd 안에서 OK
```

**진단**: `ERROR: Failed loading resource: res://scenes/battle_scene.tscn` → 해당 .tscn에서 `modulate` 라인 grep → Label인지 확인.

### 3. `@onready var x = $SceneInstance` 인스턴스화 순서

```gdscript
# ❌ ERROR: Node not found: "BattleScene" (relative to "/root/Main").
# WARNING: Node './BattleScene' was modified from inside an instance, but it has vanished.
@onready var battle_scene: Control = $BattleScene
```

**원인**: main.tscn에서 여러 PackedScene 인스턴스를 `[node name="X" parent="." instance=ExtResource(...)]`로 로드할 때, `@onready` 평가 시점에 인스턴스가 트리에 없을 수 있음. 부팅 순서/익스턴스화 타이밍 race.

**해결 — 동적 검색 패턴**:
```gdscript
# var + call_deferred
var battle_scene: Control = null

func _ready() -> void:
    # ... 다른 초기화 ...
    call_deferred("_find_battle_scene")

func _find_battle_scene() -> void:
    battle_scene = get_node_or_null("BattleScene")

func _on_battle_test_pressed() -> void:
    if battle_scene == null:
        _find_battle_scene()
    if battle_scene != null and battle_scene.has_method("show_battle"):
        battle_scene.show_battle(5, 3, 10)
```

**대안 — 인스턴스 순서 변경**: main.tscn에서 BattleScene 인스턴스를 가장 먼저 정의 (다른 인스턴스보다 위). 단 동적 검색이 더 안정적.

---

## LB_VERIFY 검증 절차

```gdscript
# 4.9) 전투 시각화 검증
print("[4.9] 전투 시각화 검증")
var battle: Node = get_tree().current_scene.find_child("BattleScene", true, false)
if battle == null:
    battle = get_node_or_null("/root/Main/BattleScene")
if battle == null:
    print("  ✗ FAIL — BattleScene 노드 미발견")
else:
    print("  - BattleScene 발견, visible=%s" % str(battle.visible))
    if battle.has_method("show_battle"):
        var enemy_count: int = 5
        var my_power: int = GameWorld.alive_mercenaries().size() * GameWorld.fortification_level
        var enemy_power: int = 10
        battle.show_battle(enemy_count, my_power, enemy_power)
        assert(battle.visible, "show_battle 후 visible=true 아님")
        print("  - show_battle OK — 적 %d명 vs 아군 전투력 %d" % [enemy_count, my_power])

        # 그리드 채워졌는지 확인
        var allies_grid: GridContainer = battle.get_node_or_null(
            "MainVBox/ContentMargin/ContentVBox/TroopRow/AlliesCard/AlliesMargin/AlliesVBox/AlliesGrid")
        var enemies_grid: GridContainer = battle.get_node_or_null(
            "MainVBox/ContentMargin/ContentVBox/TroopRow/EnemiesCard/EnemiesMargin/EnemiesVBox/EnemiesGrid")
        if allies_grid and enemies_grid:
            print("  - 아군 그리드: %d명, 적군 그리드: %d명" % [
                allies_grid.get_child_count(), enemies_grid.get_child_count()])
            assert(allies_grid.get_child_count() == 3, "아군 3명이어야 함")
            assert(enemies_grid.get_child_count() == 5, "적군 5명이어야 함")

        # 시뮬레이션 시작 (출격) — await 없이
        if battle.has_method("_on_choice_pressed"):
            battle._on_choice_pressed("fight")
            # 결과 단계까지는 await가 필요하지만 헤드리스 검증에서는 skip
```

**헤드리스 검증 제약**: `await get_tree().create_timer(...)`는 헤드리스에서 신호 지연 가능. 검증은 **상태 천이 확인**까지만 — `show_battle` 호출 → 그리드 채움 확인 → `_on_choice_pressed("fight")`로 시뮬레이션 진입까지만. 실제 시각 효과(애니메이션)는 라이브에서 수동 확인.

---

## main.tscn 통합

```ini
[gd_scene load_steps=N format=3 uid="uid://b1lastbanner"]

[ext_resource ... "res://scenes/decision_dialog.tscn" id="2_dialog"]
[ext_resource ... "res://scenes/battle_scene.tscn" id="7_battle"]

[node name="BattleScene" parent="." instance=ExtResource("7_battle")]
visible = false
```

**메뉴 버튼**: `BattleTestButton` "전투 시뮬레이션 (B)" — 검증/데모 용. 라이브에서는 결정 다이얼로그 → 자동 호출로 대체 가능.

```gdscript
# main.gd
func _on_battle_test_pressed() -> void:
    if battle_scene == null:
        _find_battle_scene()
    if battle_scene != null and battle_scene.has_method("show_battle"):
        var enemy_count: int = 5 + randi() % 6
        var my_power: int = GameWorld.alive_mercenaries().size() * GameWorld.fortification_level
        var enemy_power: int = enemy_count * 2
        battle_scene.show_battle(enemy_count, my_power, enemy_power)
```

---

## 단축키

- `B` — 전투 시뮬레이션 화면 표시 (수동 트리거)
- `ESC` — 화면 닫기