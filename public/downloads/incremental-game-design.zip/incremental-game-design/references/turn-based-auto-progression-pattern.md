# Turn-Based Auto-Progression + Re-entry Architecture

"위임 진행 + 재진입" 게임의 시간 단계/결정 큐/체크포인트 아키텍처. Last Banner, Six Crowns, Iron Heralds 등 게임 무관 공통.

## 한 줄 요약

게임 시뮬레이션은 30초~5분 tick 단위로 자동 진행. 매 tick 후 결정 큐 + 스냅샷 DB 저장. 사용자가 진입하면 그간 누적된 결정 큐를 일괄 처리하고, 떠날 땐 자동 진행 재개.

## 4계층 모델

```
┌──────────────────────────────────────────────────────────────┐
│  Layer 4: User UI Layer                                       │
│  └─ Dashboard / Map / Camp / Dialogue (대시보드가 진입점)    │
├──────────────────────────────────────────────────────────────┤
│  Layer 3: Auto-Progression Loop                               │
│  └─ tick_scheduler.gd / setInterval (30s = 4 game hours)     │
├──────────────────────────────────────────────────────────────┤
│  Layer 2: State + Decision Queue                              │
│  ├─ game_state DB (영지/용병/자원/관계)                       │
│  └─ decision_queue (Milestone/Crisis/Opportunity/Discovery)   │
├──────────────────────────────────────────────────────────────┤
│  Layer 1: Tick Engine — pure logic, no UI dep                │
│  └─ economy.gd / contract.gd / event.gd / combat.gd          │
└──────────────────────────────────────────────────────────────┘
```

**Layer 1 = 순수 함수**. UI 없음. `advance_tick(state) → (new_state, events)`.
테스트 가능, 디버그 가능, 다른 엔진으로 이식 가능.

## 4가지 이벤트 enum

| Enum | 예 | 자동 처리 가능? | 우선순위 |
|------|---|----|------|
| **Milestone** | 영지 풍작 / 용병 졸업 / 동맹 | ✅ (수락/축제/투자 옵션) | 3 |
| **Crisis** | 적 약탈 / 용병 부상 / 침공 | ❌ (사용자 결정 필수) | 1 |
| **Opportunity** | 용병 지원 / 교역 제안 | ✅ (자동 거절 가능) | 2 |
| **Discovery** | 숨겨진 동굴 발견 | ✅ (자동 무시 가능) | 4 |

→ Crisis만 무조건 사용자 결정. 나머지는 사용자가 옵션별 자동 처리 정책 설정 가능.

## Godot 4 구현 골격

```gdscript
# autoload/tick_scheduler.gd (Autoload 등록)
extends Node

const TICK_INTERVAL = 30.0  # 30초 = 게임 4시간

var auto_running: bool = true
var last_tick_at: int = -1  # ms epoch
var tick_count: int = 0

func _ready() -> void:
    var timer := Timer.new()
    timer.wait_time = TICK_INTERVAL
    timer.autostart = auto_running
    timer.timeout.connect(_on_tick)
    add_child(timer)

func _on_tick() -> void:
    if not auto_running: return
    if game_state.has_active_dialogue(): return  # 다이얼로그 중 일시정지
    tick_count += 1
    var events := tick_engine.advance_tick(game_state.snapshot())
    game_state.apply_events(events)
    decision_queue.push_many(events.filter_user_required())
    snapshot_system.save()
```

```gdscript
# autoload/decision_queue.gd
extends Resource

class Decision:
    var id: StringName
    var type: String  # "milestone" | "crisis" | "opportunity" | "discovery"
    var payload: Dictionary
    var created_at_tick: int
    var auto_policy: String  # "auto_accept" | "auto_reject" | "auto_ignore" | "manual"

var queue: Array[Decision] = []

func push_many(events: Array) -> void:
    for e in events:
        queue.append(Decision.new(e))
    queue.sort_custom(_priority_sort)

func take_next() -> Decision:
    if queue.is_empty(): return null
    var d = queue[0]; queue.pop_at(0); return d

func _priority_sort(a, b):
    return priority(a.type) < priority(b.type)
```

## 순수 Web 구현 골격 (React + TS, 동일 패턴)

```typescript
// lib/tick-engine.ts
export interface GameState { /* ... */ }
export type Event =
  | { type: 'milestone'; payload: {...} }
  | { type: 'crisis'; payload: {...} }
  | { type: 'opportunity'; payload: {...} }
  | { type: 'discovery'; payload: {...} }

export function advanceTick(state: GameState): { state: GameState; events: Event[] } {
  // pure function, no UI, no DB
}

export function isUserRequired(e: Event): boolean {
  return e.type === 'crisis'
}
```

```typescript
// hooks/useAutoProgression.ts
import { useEffect, useRef } from 'react'
import { advanceTick, isUserRequired } from '@/lib/tick-engine'

export function useAutoProgression(stateRef: MutableRefObject<GameState>) {
  const ref = useRef(stateRef.current)
  useEffect(() => {
    const id = setInterval(() => {
      const next = advanceTick(ref.current)
      ref.current = next.state
      db.save(next.state)
      const userReq = next.events.filter(isUserRequired)
      if (userReq.length) decisionQueue.pushMany(userReq)
    }, 30_000)
    return () => clearInterval(id)
  }, [])
}
```

→ Layer 1 (advanceTick) = 두 스택에서 동일 코드 가능 (Godot GDScript ↔ TypeScript).

## 체크포인트 DB — 5가지 스키마 기초

```sql
-- 모든 게임 공통
CREATE TABLE snapshots (
    game_id        TEXT PRIMARY KEY,
    schema_version INT NOT NULL,
    last_tick_at   INT NOT NULL,  -- ms epoch
    state_json     TEXT NOT NULL,
    last_saved_at  INT NOT NULL
);

CREATE TABLE decision_queue (
    id             TEXT PRIMARY KEY,
    game_id        TEXT NOT NULL,
    type           TEXT NOT NULL,  -- milestone/crisis/opportunity/discovery
    payload_json   TEXT NOT NULL,
    created_at_tick INT NOT NULL,
    auto_policy    TEXT NOT NULL,
    resolved_at    INT,
    FOREIGN KEY (game_id) REFERENCES snapshots(game_id)
);

CREATE TABLE event_log (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    game_id        TEXT NOT NULL,
    tick           INT NOT NULL,
    type           TEXT NOT NULL,
    payload_json   TEXT NOT NULL,
    occurred_at    INT NOT NULL
);

CREATE TABLE meta (
    key            TEXT PRIMARY KEY,
    value          TEXT
);

-- 게임별 추가 테이블 (예: Last Banner)
-- CREATE TABLE mercenaries (id, name, level, hp, ...);
-- CREATE TABLE contracts (id, giver, task, reward, deadline_tick, ...);
```

**`schema_version` 컬럼은 무조건 박아둘 것** — 한 번 출시하고 나면 마이그레이션 코드가 필수. v1에서 심어두면 v2 때 큰 비용 안 듬.

## 24 게임 시간 = 1 real-life day 호흡

이게 핵심 디자인 상수. 검증된 보정:

| 설정 | 30분 게임 | 1시간 게임 | 1일 게임 |
|------|---------|---------|---------|
| Tick (real) | 30초 | 1분 | 5분 |
| Tick (game) | 4시간 | 2시간 | 12시간 |
| Real day = game | 12일 | 48일 | 288일 |

→ Last Banner는 30분 게임 카테고리 (정착 + 모험 + 다음 계절 사이클). Six Crowns는 1시간 게임 (정치 + 외교가 더 깊음).

## 검증된 함정

1. **체크포인트 DB schema 버전 박지 않음** — 출시 후 마이그레이션 코드 없는 게임 → 업데이트 불가능.
2. **결정 큐 우선순위 없이 push** — 사용자가 1주 미진입 시 Crisis 수십 개 섞여 나옴. 우선순위 sort 필수.
3. **자동 진행 + 다이얼로그 동시** — 다이얼로그 중 tick 발생 → 텍스트가 사라짐. 일시정지 필수.
4. **체크포인트 I/O 동기 작업** — SQLite write를 메인 스레드에서 → tick stutter. 비동기 또는 batch write.
5. **시간 비율 잘못 설정** — 너무 빠르면 사용자가 결정할 틈이 없음 (스트레스). 너무 느리면 "1주 = 12시간 게임" 밖에 안 진행. 24일 게임 = 1 real-life day 균형점.

## 빠른 참조

- **Godot 자동 진행**: `autoload/tick_scheduler.gd` + `Timer` node
- **Web 자동 진행**: `setInterval(30_000)` + `useRef` state
- **결정 큐 우선순위**: Crisis → Opportunity → Milestone → Discovery
- **체크포인트 마이그레이션**: `schema_version` row + 별도 마이그레이션 함수
- **다이얼로그 일시정지**: `tick_scheduler.gd`가 `game_state.has_active_dialogue()` 체크

## 차용 출처

- **Kittens Game / Universal Paperclips** — idle/incremental 디자인 패턴
- **CK3 succession screen** — 결정 큐 + 다이얼로그 패턴
- **Universal Paperclips 자동 진행** — 사용자가 떠나면 시간 폭주 → 종료 시 summary
- **A Dark Room / A Train Loop** — 자동 진행 + 가끔 결정 UI
