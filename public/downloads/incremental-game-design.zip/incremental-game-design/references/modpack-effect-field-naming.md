# Modpack Effect Field Naming — NaN Propagation Pitfall

> 모드팩(JSON/PO) 시스템에서 effect/handler가 받는 필드명이 base와 다르면 **silent NaN corruption** 발생. 한 번 발생하면 회복 안 되며, load 시 sanitize 코드 필요.

sango-rising-dragons-kr (Phaser 3 / TypeScript, 2026-07-20)에서 실전 검증. 황건의 잔당 토벌 모달 → "병력 +1500" 선택 → 도시 troops가 영구 NaN → 이후 모든 recruit이 NaN+1500=NaN.

---

## 버그 패턴

```typescript
// base/events.json (원본)
{ "op": "troopsHome", "v": 1500 }

// ko/events.json (한국어 모드팩 — 한국어화 시점에 실수로 amount로 변경)
{ "op": "troopsHome", "amount": 1500 }

// state.ts applyEffects (handler)
case 'troopsHome': {
  const home = citiesOf(G.playerFaction)[0];
  if (home) home.troops = Math.max(200, home.troops + e.v);  // ← e.v는 undefined!
}
```

**결과**: `home.troops + undefined = NaN`. 이후 모든 mutation silent fail:
- `home.troops += 1500` (recruit) → NaN
- `home.troops -= 2000` (event) → NaN  
- `home.troops * 0.93` (식량고갈) → NaN

---

## 진단 시그널

| 증상 | 가능성 |
|---|---|
| 로그에 "✓ +1500" 표시되지만 UI는 `-` 또는 변하지 않음 | **NaN 직렬화 가능** — `JSON.stringify(NaN) === "null"` |
| 다음 모달/액션에서 "병력"이 `-`로 표시 | troops NaN 확정 |
| 콘솔에서 `G.cities[id].troops` → `NaN` | root cause |
| `Object.values(G.cities).filter(c => !Number.isFinite(c.troops))` | corrupted 도시 수 |

---

## 3단계 방어 (필수 — 1개만으론 부족)

### 1. 데이터 정규화 (가장 먼저)

```diff
{
  "op": "troopsHome",
- "amount": 1500
+ "v": 1500
}
```

**원칙**: 모드팩은 base의 **정확한 필드명**을 따라야 함. 새 필드 추가보다 기존 필드 재사용이 안전.

### 2. Handler 다중 필드 수용 (미래 안전성)

```typescript
case 'troopsHome': {
  const home = citiesOf(G.playerFaction)[0];
  // ★ base convention (`v`) + 한국어 convention (`amount`) + numeric fallback 모두 수용
  const delta = Number((e as any).v ?? (e as any).amount ?? 0);
  if (home && Number.isFinite(delta) && delta !== 0) {
    home.troops = Math.max(200, home.troops + delta);
  }
  break;
}
```

`Number.isFinite` 가드: NaN/Infinity면 mutation skip — silent fail 방지.

### 3. Load-time sanitize (이미 corrupted 세이브 복구)

```typescript
function sanitizeGameState(g: any): void {
  if (!g) return;
  const safe = (v: any, fallback = 0) => 
    Number.isFinite(Number(v)) ? Number(v) : fallback;
  
  g.gold = safe(g.gold, 0);
  g.food = safe(g.food, 0);
  g.cp = safe(g.cp, 0);
  g.turn = safe(g.turn, 1);
  
  if (g.aiGold) for (const k of Object.keys(g.aiGold)) 
    g.aiGold[k] = safe(g.aiGold[k], 800);
  
  if (g.cities) {
    for (const id of Object.keys(g.cities)) {
      const c = g.cities[id];
      c.troops = safe(c.troops, 1000);  // ← NaN troops → 1000 default
      c.farm = safe(c.farm, 0);
      c.market = safe(c.market, 0);
      c.walls = safe(c.walls, 0);
    }
  }
  
  if (g.officers) {
    for (const id of Object.keys(g.officers)) {
      const o = g.officers[id];
      if (!Number.isFinite(o.level)) o.level = 1;
      if (!Number.isFinite(o.exp)) o.exp = 0;
    }
  }
}

export function loadGame(): boolean {
  const raw = localStorage.getItem(SAVE_KEY);
  if (!raw) return false;
  try {
    G = JSON.parse(raw);
    sanitizeGameState(G);
    return true;
  } catch { return false; }
}
```

**debug hook** (선택):
```typescript
const corrupted = Object.values(G.cities).filter(c => !Number.isFinite(c?.troops)).length;
if (corrupted > 0) (window as any).__sangoSaveHeal = { fixedCities: corrupted };
```

사용자가 콘솔에서 `__sangoSaveHeal` 확인 → 자동 복구된 도시 수 검증.

---

## 적용 범위 (체크리스트)

모든 numeric effect handler에 동일한 패턴 적용:

| handler | 데이터 필드 | NaN 위험 |
|---|---|---|
| `gold` | `e.v` (effect 객체 v 필드) | gold += undefined → NaN |
| `food` | `e.v` | 동일 |
| `troopsHome` | `e.v ?? e.amount` (양쪽 컨벤션) | NaN |
| `expAll` | `e.v` | 장수 exp NaN |
| `recruit` (장수) | `e.v` | target.city 잘못 → runtime error |
| `weakenFaction` | `e.v ?? e.amount` | 적 진영 troops NaN |

**권장**: 모든 handler에 `Number.isFinite(Number(...))` 가드 추가. 데이터 정규화와 load-time sanitize는 handler 가드와 별개로 항상 둘 다 적용.

---

## JSON.stringify(NaN) = null 함정

`JSON.stringify({troops: NaN})` 결과: `'{"troops":null}'` — **NaN이 그대로 저장되지 않고 null로 직렬화됨**.

```typescript
const obj = { troops: NaN };
JSON.stringify(obj);  // → '{"troops":null}'
JSON.parse('{"troops":null}').troops;  // → null (not NaN)
obj.troops = null + 1500;  // → 1500 (silent recovery!)
```

**중요 함정**: 만약 handler가 `home.troops += e.v`이고 `e.v`가 null이면 `home.troops + null = home.troops` (no-op). **NaN이 아니라 null로 직렬화됐으면 게임은 계속 작동하지만 사용자가 보기엔 변화 없음**. 

→ 진단 시 `JSON.stringify(G.cities[id])` 후 NaN/null/undefined 모두 grep.

---

## 모드팩 품질 검증 워크플로

번역자가 모드팩 작성할 때 다음 검사:

```bash
# 1. 모든 effect의 필드명이 base와 일치하는지
for op in gold food troopsHome expAll recruit weakenFaction; do
  for f in public/data/base public/data/ko public/data/ja; do
    grep -l "\"op\": \"$op\"" "$f/events.json" 2>/dev/null
  done
done

# 2. 각 effect의 필드 키 목록 출력 (base vs ko)
python3 -c "
import json
for pack in ['base', 'ko']:
    with open(f'public/data/{pack}/events.json') as f:
        events = json.load(f)
    for ev in events:
        for ch in ev.get('choices', []):
            for eff in ch.get('effects', []):
                print(f'{pack} {ev[\"id\"]}: {list(eff.keys())}')
" | sort | uniq -c | sort -rn
```

**필드명 일치하지 않는 effect 발견 시**: 해당 위치 수정 + handler 다중 필드 가드 추가.

---

## 일반화 — JSON/PO 모드팩 시스템 공통

| 시스템 | 위험 | 완화 |
|---|---|---|
| **JSON modpack** (sango-rising-dragons, OpenRA, ...) | effect 필드명 불일치 → NaN | handler 다중 수용 + sanitize |
| **PO gettext** (Wesnoth, Civilization) | msgid 오타 → 빈 번역 fallback | msgid hash 검증 + fallback chain |
| **YAML i18n** | 누락 키 → undefined value | strict mode + schema 검증 |
| **Lua mod** (Factorio, RimWorld) | API 변경 → silent fail | version check + assert |

**공통 원칙**: **데이터 모드팩 시스템에서는 (1) 데이터 정규화 + (2) handler 다중 가드 + (3) load-time sanitize 3중 방어가 안전**. 1개만으론 부족.