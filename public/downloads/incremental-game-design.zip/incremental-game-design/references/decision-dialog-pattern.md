# Decision Dialog Pattern (위임 진행 게임의 결정 UX)

incremental / auto-progression 게임에서 **결정 큐를 어떻게 사용자에게 보여줄지**에 대한 class-level 패턴. Last Banner에서 검증 (2026-07-15).

## 핵심 문제

게임 세계는 알아서 돌아가지만, 결정이 필요한 사건이 생긴다. 그 결정을 어떻게:

1. **사용자에게 알릴 것인지** (modal vs notification vs silent)
2. **자동 진행을 멈출 것인지** (게임 정지 vs 계속)
3. **선택지를 어떻게 표현할 것인지** (버튼 vs 액션 큐)

→ **단일 정답 없음**, 우선순위 기반 분기가 정답.

## 우선순위 기반 UI 분기 (검증된 표준)

| 우선순위 | UI 표시 | 자동 진행 | 트리거 예 |
|---|---|---|---|
| **LOW** | 알림만 (큐 알림, 토스트) | 유지 | 용병 자원 도착, 농민 호소 |
| **MEDIUM** | 알림만 (배너) | 유지 | 외교 제안, 식량 경고 |
| **HIGH** | **모달 다이얼로그** | 일시정지 (pause_for_decision) | 약탈자 출몰 |
| **CRITICAL** | **모달 다이얼로그** + 즉시 표시 | 즉시 정지 | 식량 위기, 전투 결과, 후계 위기 |

**원칙**: 자동 진행을 막을 가치가 있는 사건만 모달로 띄운다. 매 4시간 용병 자원 같은 것은 알림만 — 안 보면 자동 처리(또는 무시).

## 다이얼로그 씬 구조 (Godot 4 예)

```
DecisionDialog (CanvasLayer, layer=10) — 최전면
├── DimBG (ColorRect)         — 반투명 검정 (alpha 0.75)
└── Card (PanelContainer)     — 중앙, anchor 0.5 + offset ±W×H
    └── Margin (24/20/24/20)
        └── VBox
            ├── TitleLabel    — 결정 제목
            ├── PriorityBadge — "[CRITICAL]" 등 (색 modulate)
            ├── HSep1
            ├── DescriptionLabel — 본문 (autowrap, 최소 높이)
            ├── HSep2
            ├── ChoicesList   — VBoxContainer (선택지 버튼 동적 생성)
            ├── HSep3
            ├── StatusLabel   — "결정 처리 중..." 일시
            └── PendingLabel  — "대기 결정: N건"
```

**Web/모바일**: anchor 기반 레이아웃 필수 (anchor_left=right=0.5 + offset = 중앙). 절대 좌표는 viewport 의존성 함정.

## 핵심 로직 — 큐 길이 추적 debouncing

**함정**: 매 `_process` (또는 매 frame) 호출 시 LOW 결정 알림이 push될 때마다 `_show_next` → 알림 30+번 spam.

**해결**: 큐 길이 변동 추적.

```gdscript
var _last_notified_queue_size: int = 0

func _process(_delta: float) -> void:
    if not visible:
        if DecisionQueue.has_any_pending():
            var current_size: int = DecisionQueue.get_all_pending().size()
            if current_size > _last_notified_queue_size:  # ← 증가 감지
                _show_next()
                _last_notified_queue_size = current_size
        else:
            _last_notified_queue_size = 0
```

→ 길이 1→2→3으로 갈 때만 알림. resolve로 큐 줄어들면 reset.

## 결과 처리 — Resource vs GameWorld vs EventEngine

다이얼로그가 선택지를 받아도 그게 **어디에 적용되느냐**가 아키텍처 결정:

| 책임 | 위치 | 이유 |
|---|---|---|
| **결과 코드 → 자원 변동** | `GameWorld.apply_result(result_code, payload)` | 게임 월드 SSOT |
| **결과 코드 → 이벤트 효과** (예: 외교 동맹) | EventEngine의 별도 핸들러 | 게임 외부 효과 |
| **결과 코드 → 큐/UI 갱신** | DecisionQueue.resolve() | 큐 관리 |

**GameWorld.apply_result 패턴** (match statement):
```gdscript
func apply_result(result_code: String, payload: Dictionary) -> void:
    match result_code:
        "ACCEPT_MERCENARY":
            var m: Dictionary = payload.get("mercenary", {})
            if not m.is_empty() and gold >= payload.get("cost", 0):
                modify_resource("gold", -payload["cost"])
                roster.append(m)
                mercenary_joined.emit(m)
        "BATTLE_BANDITS_FIGHT":
            var enemy_count: int = payload.get("enemy_count", 5)
            var est_victory: float = payload.get("estimated_victory", 0.5)
            if randf() <= est_victory:
                resolve_battle("victory", int(enemy_count * 0.1 * randf()), ...)
            else:
                resolve_battle("defeat", int(enemy_count * 0.3 * randf()) + 1, ...)
        # ... 14개 결과 코드
```

**CRITICAL 결정은 자동 호출**: `DecisionQueue.push()` 내부에서 `if priority == CRITICAL: GameManager.pause_for_decision()`. 별도 트리거 코드 필요 없음.

## 핵심 Pitfalls

### 1. Dictionary inline format 안 됨
```gdscript
# ❌ Parse error
{ "label": "뇌물 (%d골드)". % cost }

# ✓ 변수에 format 적용 후
var label: String = "뇌물 (%d골드)" % cost
{ "label": label }
```

### 2. 모달을 매번 새로 만들지 말 것
씬에 `[node name="DecisionDialog"]` 1개 박고 `_show_next()`로 내용물만 갈아끼움. 매 결정마다 인스턴스화하면 GC 압박 + 트랜지션 끊김.

### 3. 모달 사라질 때 효과음/transition
`_hide()` 호출 시 `await get_tree().create_timer(0.3).timeout`로 0.3초 정지 → 다음 결정 표시 또는 해제. 즉시 해제하면 사용자가 결과를 못 봄.

### 4. 결정 큐가 비어있는데 모달 떠있을 때
`_hide()` 호출 — `DecisionQueue._queue.is_empty()` 체크 후. CRITICAL 결정 resolve 후 GameManager 상태가 PLAYING으로 돌아가는데 모달이 남아있으면 입력 차단됨.

### 5. 결정 큐 우선순위 정렬은 push 시점에
resolve 후 재정렬하지 말 것. push 시점에 insert_idx 계산해서 정렬. 매 resolve마다 정렬은 O(N log N) 부담.

### 6. payload에 choices 동봉
```gdscript
DecisionQueue.push("EVENT_TYPE", {
    "title": "...",
    "description": "...",
    "choices": [
        { "id": "accept", "label": "수용", "result": "ACCEPT_X" },
        { "id": "reject", "label": "거절", "result": "REJECT_X" }
    ]
}, Priority.LOW)
```
UI는 `payload.choices`만 읽어서 버튼 생성. 결정 로직과 UI 분리.

## 검증 패턴 — LB_VERIFY=1 환경변수

main.gd에 검증 모드 내장. 결정 다이얼로그 표시까지 자동 검증:

```gdscript
func _run_verify() -> void:
    # ... 새 게임 + 24시간 시간 진행 ...

    # HIGH/CRITICAL 강제 push
    EventEngine._maybe_bandit_raid(Time.get_ticks_msec())
    GameWorld.food = 5
    EventEngine._maybe_food_crisis(Time.get_ticks_msec())

    await get_tree().process_frame
    var dialog: Node = get_tree().current_scene.find_child("DecisionDialog", true, false)
    if dialog and dialog.visible:
        print("[PASS] CRITICAL 결정 시 다이얼로그 자동 표시")

        # 첫 결정 자동 처리
        var first: Dictionary = DecisionQueue._queue[0]
        var first_choice: Dictionary = first.payload.choices[0]
        GameWorld.apply_result(first_choice.result, first.payload)
        DecisionQueue.resolve(first.id, first_choice)
        await get_tree().process_frame
        print("[PASS] 결정 처리 후 자원 변동 정확")
```

**실행**: `LB_VERIFY=1 godot --headless` → 24시간 시뮬 + 다이얼로그 표시/처리 자동 검증.

## 다른 엔진 차용 (React 예)

```tsx
function DecisionDialog({ decision, onResolve }) {
  if (!decision) return null
  const choices = decision.payload.choices || []
  return (
    <div className="modal-backdrop">
      <div className="modal-card">
        <h2>{decision.payload.title}</h2>
        <span className={`badge badge-${decision.priority}`}>
          {decision.priority}
        </span>
        <p>{decision.payload.description}</p>
        <div className="choices">
          {choices.map(c => (
            <button key={c.id} onClick={() => onResolve(decision.id, c)}>
              {c.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}
```

- LOW/MEDIUM: 토스트 알림으로 라우팅 (별도 컴포넌트)
- HIGH/CRITICAL: 이 모달 컴포넌트로 라우팅
- `onResolve` → `gameStore.applyResult(c.result, decision.payload)` + `decisionQueue.resolve(decision.id, c)`

→ 게임 월드 SSOT는 동일 (`gameStore.apply_result`), UI는 엔진별 다르게.

## 관련

- **Last Banner 실전 검증**: `incremental-game-design-last-banner-event-engine` — 이 패턴을 실제로 구현한 사례
- **시간 단계 + 결정 큐 아키텍처**: `references/turn-based-auto-progression-pattern.md`
- **Godot 결정 다이얼로그 구현**: `godot-game-bootstrap` SKILL.md의 autoload 골격 + `decision_dialog.gd` 템플릿