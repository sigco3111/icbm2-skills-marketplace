# Headless 검증 통합 스크립트 (Last Banner 12단계, 2026-07-16)

`LB_VERIFY=1 godot --headless` 패턴을 여러 게임에 재사용 가능한 bash 래퍼.

## 사용

```bash
cd ~/work/<your-game>
bash ~/.hermes/skills/creative/incremental-game-design/scripts/verify-headless.sh

# 옵션
GAME_ROOT=~/work/last-banner bash ~/.hermes/.../verify-headless.sh
VERCEL_URL=https://last-banner.vercel.app bash ~/.hermes/.../verify-headless.sh
LB_TIMEOUT=120 bash ~/.hermes/.../verify-headless.sh
```

## 스크립트가 하는 일 (3단계)

1. **부팅 체크** — `godot --headless --quit-after 15`로 main scene 부팅 확인 (autoload 등록 + 파스 에러 catch)
2. **LB_VERIFY 시뮬** — `timeout 60 godot --headless`로 main.gd의 `_run_verify()` 실행 (60초 타임아웃 → hang 시 simplify 가이드)
3. **마커 grep** — `[PASS]`, `✓ 저장/로드`, `✓ 다이얼로그` 등 핵심 마커 + (선택적) 누적 마커

## 종료 코드

- `0` = 모든 검증 통과
- `1` = 부팅 실패 또는 LB_VERIFY 실패 (마커 없음)
- `2` = LB_VERIFY hang (60초 타임아웃) → main.gd의 verify 코드에서 await 루프 단순화 필요

## LB_VERIFY 패턴 (재사용)

```gdscript
# main.gd
const LB_VERIFY := "LB_VERIFY"

func _ready() -> void:
    _verify_mode = OS.has_environment(LB_VERIFY)
    if _verify_mode:
        _run_verify()
        return
    # ... 일반 부팅

func _run_verify() -> void:
    print("=== 자동 진행 검증 ===")
    await get_tree().process_frame
    await get_tree().process_frame

    # 1) 새 게임
    GameManager.start_new_game("default")
    # 2) 시간 진행 (await 없이 동기로 — 헤드리스 hang 회피)
    for step in range(144):
        TimeManager.advance_minutes(10)
    await get_tree().process_frame
    # 3) 결정 큐 push 확인
    assert(DecisionQueue.get_all_pending().size() > 0)
    # 4) HIGH/CRITICAL 결정 처리
    # ...
    # 5) 저장/로드 round-trip
    # 6) 화면 인스턴스 검증
    # ...
    print("=== 모든 검증 통과 — 종료 ===")
    get_tree().quit()
```

**핵심**: `await get_tree().process_frame` 누적 금지. 동기 + 단일 await.

## 7~12차 누적 마커 (참고)

스크립트가 자동으로 grep하는 마커들:

- `[PASS]` — 결정 큐 증가 확인
- `✓ 저장/로드` — round-trip OK
- `✓ 다이얼로그` — HIGH/CRITICAL 모달 자동 표시
- `✓ 자동 진행` — enable_auto_progress() 기본값
- `왕조` — court 시스템
- `전투 시각화` — BattleScene
- `오디오` — AudioManager
- `마을 건설` — buildings[]

각 마커는 선택적 — 게임에 해당 시스템이 없으면 grep 실패해도 종료 코드에 영향 없음.

## Pitfalls (실전 검증)

1. **`timeout` 명령 없음 환경** — macOS 기본 없음 (`brew install coreutils` 필요). 또는 `gtimeout`. 또는 `&` + `kill` 대안.
2. **`/tmp/lb_verify.log` 권한** — 자동 생성되지만 시스템 권한에 따라 fail할 수 있음. `mktemp` 패턴 권장.
3. **누적 마커 매칭이 너무 엄격** — 게임마다 다른 마커 출력 → "없음" 메시지가 많아도 정상. exit 1이 아님.
4. **Vercel URL 옵션 사용 시 SSL 핸드셰이크** — 사내 망에서 SSL 검증 실패 가능. `curl -sI`가 즉시 hang. `curl --max-time 5` 추가 고려.

## LB_VERIFY 단계 명명 규칙 (Last Banner 패턴)

스크립트가 grep하는 마커와 매핑되는 검증 단계 번호:

| 마커 | 단계 번호 | 설명 |
|---|---|---|
| `[1]` 초기 상태 | 1 | 새 게임 후 자원/용병 확인 |
| `[1.5]` 자동 진행 ON | 1.5 | enable_auto_progress() 확인 |
| `[1.6]` 자동 진행 시뮬 | 1.6 | _process 틱 시뮬레이션 |
| `[1.7]` 튜토리얼 | 1.7 | 4단계 순회 |
| `[2]` 24시간 시뮬 | 2 | 시간 진행 + 결정 큐 push |
| `[4.5]` 다이얼로그 | 4.5 | HIGH/CRITICAL 모달 표시 |
| `[4.6]` 명단 화면 | 4.6 | 3-pane 동적 갱신 |
| `[4.7]` 대시보드 | 4.7 | 라인 차트 + ProgressBar |
| `[4.8]` 왕조 | 4.8 | court + 후계자 |
| `[4.9]` 전투 시각화 | 4.9 | show_battle + 그리드 |
| `[4.10]` 오디오 | 4.10 | AudioManager + TRACKS |
| `[4.11]` 마을 건설 | 4.11 | buildings + 일간 효과 |
| `[5]` 자원 변동 | 5 | 24시간 후 자원 요약 |
| `[6]` 저장/로드 | 6 | round-trip 정합성 |

→ 새 기능 추가 시 `[N.M] <시스템명> 검증` 형식으로 print → 스크립트가 자동 grep.