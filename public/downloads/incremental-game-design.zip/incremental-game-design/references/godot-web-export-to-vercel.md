# Godot 4 → Vercel Web Export — 전체 절차

Last Banner 프로젝트용으로 2026-07-15에 검증된 워크플로. 다른 Godot 게임에도 그대로 차용.

## 한 줄 요약

Godot 4로 게임 빌드 → `Web` 프리셋 export → `export/web/`을 Vercel에 정적 호스팅 + COOP/COEP 헤더 1줄. 끝.

## Step 0: Godot 4 설치 (macOS)

```bash
brew install --cask godot
godot --version  # 4.6+ 권장
```

## Step 1: Godot 프로젝트 — Web Export 프리셋

1. Godot 에디터에서 Project → Export
2. Web → Add (preset)
3. **Options 탭**:
   - **Thread support**: "Enabled" (SharedArrayBuffer) — 권장. 헤더 덕에 작동
   - **Extensions**: WebAssembly + GDExtension 필요한 경우
   - **GitHub Pipelines HTML**: 켜기 (GitHub Actions로 자동 빌드 시)
   - **Vr Mode**: 끄기
4. **Export Path**: `./export/web/index.html`
5. **Resources → Add Folder**: 프로젝트에서 import 한 모든 자산

## Step 2: 첫 빌드 (로컬 테스트)

```bash
cd ~/work/<project>
godot --headless --export-release "Web" export/web/index.html
```

생성 파일:
```
export/web/
├── index.html           (~20 KB)
├── index.js             (~1 MB)
├── index.wasm           (~25 MB)
├── index.audio.positioning.wasm  (옵션)
├── index.audio.worklet.js        (옵션)
├── index.audio.worklet.wasm      (옵션)
├── index.pck            (모든 게임 자산, 50~200 MB 가능)
└── (그 외 오디오/SVG 폰트 등)
```

## Step 3: 로컬 서버에서 검증

```bash
cd export/web
python3 -m http.server 8080
# 브라우저에서 http://localhost:8080
```

**첫 로딩이 느린 게 정상** (50~200 MB). "Loading..." 스플래시가 10~30초 보임.

## Step 4: Vercel 배포

### Option A: Vercel CLI (1회성, 빠른 검증)

```bash
cd export/web
vercel --prod \
  --token "$(cat ~/.hermes/secrets/vercel_token.txt)"
```

→ URL 출력. 그게 게임 라이브 URL.

### Option B: GitHub Actions + Vercel 자동 배포

```yaml
# .github/workflows/build-web.yml
name: build-web
on:
  push:
    branches: [main]
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
        with:
          lfs: true
          submodules: recursive   # game-assets-pool submodule 자산
      - uses: godotengine/godot-ci@main
        with:
          version: 4.6
          export: Web
          exportPath: export/web
      - uses: actions/upload-artifact@v4
        with:
          name: web-build
          path: export/web/
  deploy:
    needs: build
    runs-on: ubuntu-latest
    steps:
      - uses: actions/download-artifact@v4
        with:
          name: web-build
          path: web
      - uses: amondnet/vercel-action@v25
        with:
          vercel-token: ${{ secrets.VERCEL_TOKEN }}
          vercel-args: '--prod'
          working-directory: web
```

Vercel token: `https://vercel.com/account/tokens` → 토큰 생성 → GitHub repo Settings → Secrets.

## Step 5: ⚠️ COOP/COEP 헤더 (가장 자주 빠지는 함정)

Web Export한 결과만 배포하면 SharedArrayBuffer 기반 멀티스레딩 + GDExtension이 작동 안 함. **반드시** `vercel.json` 작성:

`export/web/vercel.json` (또는 프로젝트 루트에 두고 build 후 export/web로 복사):

```json
{
  "$schema": "https://openapi.vercel.sh/vercel.json",
  "headers": [
    {
      "source": "/(.*)",
      "headers": [
        { "key": "Cross-Origin-Opener-Policy",   "value": "same-origin" },
        { "key": "Cross-Origin-Embedder-Policy", "value": "require-corp" },
        { "key": "Cross-Origin-Resource-Policy", "value": "cross-origin" }
      ]
    }
  ]
}
```

**이 파일 1개가 빠지면 모든 WASM Thread가 죽음**. deploy 후 헤더 검증:

```bash
curl -I https://<vercel-app>.vercel.app/ | grep -i cross-origin
# 3개 헤더 모두 보여야 함
```

## Step 6: 모바일 검증 (필수)

iPhone Safari에서:
1. 게임 URL 진입 → 첫 로딩 30초 기다림
2. 진입 후 게임 작동 확인
3. 화면 회전/전체화면 모드 전환 검증

문제 발생 시 모바일 브라우저 별도 처리 필요:
- iOS Safari: 사운드 자동재생 막힘 (첫 사용자 인터랙션 후 재생)
- Android Chrome: 백그라운드 tab throttle

## Step 7: Web 자동 진행 + 백그라운드 tab

**한계 인정**: 백그라운드 tab에서 `setInterval`는 1초 throttle. Service Worker의 periodic sync는:
- 5분 단위
- 권한 요청 필요
- 배터리 절약 모드에선 더 길어짐 (1시간 단위까지)

→ **Web은 foreground-only 자동 진행**, 백그라운드는 desktop 빌드만. README/UI에 정직히 명시.

IndexedDB로 결정 큐 영구화:
- 진입 시 IndexedDB → Godot FileAccess bridge
- 게임은 SQLite (or JSON file) 사용 — Godot 한 줄로 IndexedDB 호환 가능

## ⚠️ 검증된 함정

1. **COOP/COEP 헤더 빠뜨림**: 1순위 함정. 위에서 강조.
2. **첫 로딩 30~60MB**: 모바일 진입 즉시 한 번 보고 떠지는 비율 높음. 해결책 없음. **허용하고 스플래시 예쁘게**.
3. **iOS Safari 사운드 자동재생 차단**: 게임 시작 시 사용자 인터랙션 (예: 스플래시 화면 "터치하여 시작") 필수.
4. **Godot 버전 비호환**: 4.5 → 4.6 사이 wasm 형식 변경 있음. CI/CD에 버전 pin.
5. **대형 .pck 파일**: 200MB 넘으면 Vercel deploy 100초 초과 가능. LFS 권장.
6. **vercel --prod 비대화형 토큰**: `~/.hermes/secrets/vercel_token.txt`는 `-rw-r--r--`이면 GitHub Actions에서 못 읽음. `chmod 600` 먼저.

## 빠른 참조 한 줄

```bash
cd ~/work/<project> && \
  godot --headless --export-release "Web" export/web/index.html && \
  cp ~/work/incremental-game-design/templates/vercel.json export/web/vercel.json && \
  vercel --prod
```

(템플릿은 skill templates/ 에 있음)
