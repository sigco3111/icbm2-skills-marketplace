# NIM 5-세션 AI-NPC Orchestration 상세 패턴 (2026-07-30 라이브 검증)

fireToken 인프라를 재활용한 **AI-NPC multi-agent simulation** 패턴. 5개 OpenCode 세션이 NIM gpt-oss-20b/120b로 동시 운용되어 토큰을 폭발시키면서 **하나의 가상 세계를 함께 발전**시킴. 단순 토큰 태우기와 결정적 차이는 **각 세션의 출력이 게임의 영속 state DB에 쓰이고 다음 턴의 context에 들어옴**.

## 1. 40 rpm — 게임 호흡 디자인

NVIDIA NIM 무료 tier는 **분당 40회** (냉혹한 제약). 40 rps 아님. 이게 게임 1일의 길이를 결정.

| 컨셉 | 5NPC 1인당 분당 행동 | 게임 1일 길이 (real time) |
|---|---|---|
| 페이스 (warm-up) | 2-3회 | 30분 |
| 표준 (default) | 4-5회 | 15-20분 |
| 고강도 (crisis) | 6-8회 | 10분 |

**`5 × 12초 = 60초 = 1분 = 5사이클 = 40 호출`** = 안전 마진. NPC 1인당 분당 4-5번 행동 → 게임 1일 = 15-20분이 자연스러운 호흡.

## 2. 컨텍스트 120k — 5 NPC의 규모 한계

```
gpt-oss-20b / gpt-oss-120b
  context: 131,072 tokens
  output:  32,768 tokens

5 NPC 동시 운용 시 1인당 컨텍스트:
  - world_state.md        4,000 토큰 (공유)
  - events.jsonl (last 24h) 8,000 토큰
  - relations.json         2,000 토큰
  - npc_history (자기)    16,000 토큰
  - inbox / outbox         4,000 토큰
  ─────────────────────────────
  합계                   ~34,000 토큰 (전체의 26%)
  여유                  ~97,000 토큰 (응답 + Reasoning)
```

**100k 초과시 슬라이딩/요약 권장** — fireToken `context_manager.ps1` 패턴 차용. 자동 요약: 1일 전 events → 1문단, 7일 전 → "1주 요약" 한 줄.

## 3. fireToken-style storming-herd 회피

```bash
# ❌ thundering herd — 5 worker 동시 spawn → 2-3개 429 자살
for i in 1 2 3 4 5; do
  opencode run --format json --session "ses_$i" "..." &
done
wait
```

```bash
# ✅ 3-8초 stagger + 5초 round throttle
for i in 1 2 3 4 5; do
  opencode run --format json \
    --session "ses_$(uuidgen | tr -d - | head -c 12)" \
    "..." &
  sleep $((3 + RANDOM % 6))   # 3-8초 jitter
done
wait
```

**검증된 결과 (fireToken 2026-07-30)**: stagger 적용시 20개 worker 0건 thundering herd. stagger 없으면 5개 중 2-3개 자살 (429 → 3-strike retry → fail).

## 4. 토큰 추출 — NIM 응답이 SOT

```bash
opencode run --format json ... -p "..." | \
  jq -c 'select(.type=="step_finish") | {
    session: .sessionID,
    in: .part.tokens.input,
    out: .part.tokens.output,
    cumulative: .part.tokens.cumulative
  }'
```

**tiktoken은 gpt-oss vocab과 다르므로** 절대 클라이언트 카운터 안 짜기. NIM 응답의 `usage.total_tokens` (= `step_finish.part.tokens`)가 single source of truth.

## 5. 4종 검증 command (source-of-truth disambiguation)

```bash
# 1. ps -eo pid,etime,command — NIM call signature 살아있나
ps -eo pid,etime,command | grep -iE 'gpt-oss|integrate.api.nvidia' | grep -v grep

# 2. opencode.db 사이즈 — 실제 누적 (45+ GB = active)
ls -la ~/.local/share/opencode/opencode.db

# 3. 글로벌 config — nvidia provider 정의
grep -E 'nvidia|gpt-oss' ~/.config/opencode/opencode.json | head -5

# 4. opencode stats — 토큰 사용 통계
opencode stats --days 1 --models 5
```

**`opencode providers list`는 authorized credentials만** — 위 4종이 source of truth. 2026-07-30 사용자 코렉션 = "fireToken은 NIM GPT-OSS-120B로 정상구동중이야. 다시 확인해봐" (제가 처음에 providers list만 보고 "미등록" 잘못 진단).

## 6. 5 NPC 세션 라이프사이클

```
┌─────────────────────────────────────────────────────────┐
│                    Game Tick (15분)                     │
│                                                         │
│  1. world_state.md snapshot                             │
│  2. last 24h events.jsonl 5개 NPC별 prompts 구성         │
│  3. 5세션 spawn (3-8초 stagger)                         │
│  4. NDJSON stream → step_finish.part.tokens 누적          │
│  5. NPC 행동 JSON → world_state.json에 patch             │
│  6. 충돌 감지 (예: 전쟁 / 정치 위기) → 결정 큐 push     │
│  7. 5 NPC 행동 로그 → events.jsonl append                │
│  8. user dashboard 갱신 (TUI)                           │
│  9. 다음 tick scheduler 예약 (15분 후)                   │
└─────────────────────────────────────────────────────────┘
```

각 NPC 세션은 **영속** — `opencode session list`로 ses_... ID 추적, `opencode session delete`로 명시적 종료. 5개 고정 유지 = `MAX_SESSIONS=5` 정책 + 가장 오래된 idle 세션 교체.

## 7. NPC 행동을 JSON 스키마로 강제

```json
{
  "npc_id": "finance",
  "action": "propose_budget",
  "target": "school_funding",
  "amount": 50000,
  "reasoning_summary": "교육 투자가 장기 GDP 성장에 필수...",
  "confidence": 0.78,
  "side_effects": [
    {"kind": "resource_change", "resource": "budget", "delta": -50000},
    {"kind": "approval_required", "decision_id": "DEC_2026-07-30_001"}
  ],
  "tokens_used": {"input": 8420, "output": 1240}
}
```

**이유**: 토큰 폭발 ≠ 게임 발전. **토큰 × 의미** = KPI. JSON 스키마로 강제해야 world state에 반영 가능.

## 8. 06-26 격리 default OFF — Tokscale 호환

```bash
# ❌ 격리 강제 (Tokscale이 못 봄)
export HERMES_ISOLATE=1
export OPENCODE_DB_ISOLATE=1

# ✅ default (격리 OFF) — Tokscale 리더보드 자동 반영
unset HERMES_ISOLATE
unset OPENCODE_DB_ISOLATE
```

격리의 원래 의도 (= SQLite WAL contention 회피) 는 5-8초 spawn stagger + 5초 round throttle로 이미 흡수. 5동시 worker 0건 WAL contention 실측.

## 9. `--variant` 선택 — 비용 vs 깊이

| 모델 | variant | 1 응답 시간 | 1 응답 토큰 | 의미 깊이 |
|---|---|---|---|---|
| `gpt-oss-20b` | low | 5-10초 | 1-3k | 중간 |
| `gpt-oss-20b` | medium | 15-30초 | 3-8k | 높음 |
| `gpt-oss-20b` | high | 30-90초 | 8-15k | 매우 높음 |
| `gpt-oss-120b` | low | 15-30초 | 2-5k | 높음 |
| `gpt-oss-120b` | medium | 45-90초 | 5-12k | 매우 높음 |
| `gpt-oss-120b` | high | 90-180초 | 10-25k | 극도로 높음 |

**권장**: 메인 loop = `gpt-oss-20b --variant high` (현재 fireToken 라이브). 위기는 `gpt-oss-120b --variant high` 1회 풀 호출 = 6배 시간 = 1 game month 처리.

## 10. 모니터링 — TUI / 토큰 누적 / export

기존 fireToken `tui/` 디렉토리 (Textual TUI) 가 **그대로 사용 가능**:
- SessionTable — 5세션 라이브 status
- SummaryPanel — 토큰 누적 / round 수
- EventLog — NPC 행동 로그
- ModelPickerScreen — 20b ↔ 120b 토글
- DutyCycleModal — utilization 추적

**export**: `opencode export <sessionID> --sanitize` 또는 `opencode stats --days 1 --models 5` JSON. 5개 세션 각각 export → 통합 JSON = NPC별 history.

## 11. cross-platform note

| 플랫폼 | 5세션 spawn | web dashboard | 모바일 export |
|---|---|---|---|
| macOS (현재) | ✅ ts-bash 직접 | ✅ TUI (`ftui`) | ✅ JSON export |
| Windows (fireToken 원래) | ✅ pwsh 7+ | ✅ TUI (`ftui`) | ✅ JSON export |
| Linux | ✅ bash | ✅ TUI | ✅ JSON export |
| Web (browser) | ❌ OPENCODE_CONFIG env 필요 | ✅ TUI + web dashboard | ✅ JSON export |

**Web에서 직접 spawn은 Vercel serverless에서 어려움** — `OUT-OF-BAND` fireToken의 Web 패턴은 **OpenCode serve mode** (`opencode serve --port 4096`) 노출 후 게임 front-end가 fetch. `/mcp` endpoint로 ACP 통합 가능.

## 12. Known pitfalls (요약)

1. **40 rpm 글로벌 rate limit** — 5+ 세션 동시 spawn시 stagger 필수. 6+ NPC는 spawn stagger 시간 늘려야.
2. **tiktoken client-side 카운터 금물** — gpt-oss vocab과 다름. NIM 응답 `usage.total_tokens` SOT.
3. **`opencode providers list` = metadata view** — 실제 운영 상태는 `ps aux` or `~/.local/share/opencode/opencode.db`.
4. **격리 default OFF 필수** — Tokscale 호환. 격리는 5-8초 stagger로 대체.
5. **모달 결정 큐 = 사용자가 개입할 때** — 자동 진행은 분 단위, 결정 큐 push는 HIGH/CRITICAL만.
6. **각 NPC의 컨텍스트 100k+ 자동 슬라이딩** — fireToken `context_manager.ps1` 패턴 차용.

## 13. 실제 적용 사례 (2026-07-30 컨셉)

**국가 시뮬 "Aetheria"** — 5 NPC × 131k context × 40 rpm = 분당 5 게임 행동 = 1일 15-20분. 사용자 옵션:
- 1일 = 15분 (표준)
- 1일 = 30분 (여유)
- 1일 = 1시간 (탐닉)

**MVP 5 NPC**:
1. 재무장관 — 예산·세금·적자
2. 국방장관 — 군사·외적·동맹
3. 과학기술장관 — 연구·규제·혁신
4. 언론·내무장관 — 정보·치안·검열
5. 야당 대표 — 권력 견제

**결정 큐 트리거**: 전쟁 선포 / 부패 폭로 / 자연재해 / 외교 위기 / 예산 결산 (HIGH/CRITICAL). 자동 처리: 일일 보고 (LOW/MEDIUM).

이 패턴은 "토큰 폭발 + 의미 있는 게임" 의 핵심 정답. 단순 태우기 → 5 NPC가 의미 있는 세력으로 진화.
