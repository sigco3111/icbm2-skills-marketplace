# Auto-Progress Onboarding Pattern (신규 진입자 마찰 최소화)

incremental 게임의 핵심은 "사용자가 가끔 들어와 결정한다"인데, 매번 자동 진행을 켜는 것 자체가 마찰. **새 게임 시작 = 자동 진행 ON 기본값**으로 진입 비용 0에 가깝게. Last Banner 4단계 (2026-07-16) 검증.

## 핵심 원칙

1. **새 게임 → 자동 진행 자동 ON** — GameManager.start_new_game()이 TimeManager.enable_auto_progress() 호출
2. **로드 → 사용자 마지막 상태 유지** — TimeManager.save_state() / load_state()에 auto_progress_enabled 저장
3. **첫 진입 알림 → 토스트 페이드** — 화면 하단에 5초 토스트로 "자동 진행 중" 안내
4. **P 키로 일시정지 / 재개** — 토글 가능 (TimeManager.toggle_auto_progress() 이미 있음)

## Godot 4 구현

### GameManager (autoload)

```gdscript
func start_new_game(slot: String = "default") -> void:
    save_slot = slot
    SaveManager.new_game(slot)
    # 새 게임 시작 = 자동 진행 기본 활성화 (진입 마찰 0)
    TimeManager.enable_auto_progress()
    _transition(State.PLAYING)
    game_started.emit()
```

### TimeManager (autoload)

```gdscript
func toggle_auto_progress() -> void:
    auto_progress_enabled = not auto_progress_enabled
    print("[TimeManager] 자동 진행: %s" % ("켜짐" if auto_progress_enabled else "꺼짐"))

func enable_auto_progress() -> void:
    if not auto_progress_enabled:
        auto_progress_enabled = true
        print("[TimeManager] 자동 진행 켜짐 (기본값)")

func disable_auto_progress() -> void:
    if auto_progress_enabled:
        auto_progress_enabled = false
        print("[TimeManager] 자동 진행 꺼짐")

# 이미 save_state / load_state에 auto_progress_enabled 저장/로드됨
func save_state() -> Dictionary:
    return {
        "minutes_elapsed": minutes_elapsed,
        "day": day,
        "season": season,
        "auto_progress_enabled": auto_progress_enabled  # ← 이게 핵심
    }

func load_state(data: Dictionary) -> void:
    # ...
    auto_progress_enabled = data.get("auto_progress_enabled", false)  # ← 로드 시 복원
```

### main.gd — 토스트 + 시작 시 호출

```gdscript
@onready var toast_label: Label = $UI/Toast
var _toast_tween: Tween = null

func _on_start_pressed() -> void:
    GameManager.start_new_game("default")
    # ... 기존 초기화 ...
    _show_toast("🤖 자동 진행 시작 — 결정이 필요하면 모달이 뜹니다 (P: 일시정지)")

func _on_load_pressed() -> void:
    if GameManager.load_game(saves[0]):
        # ... 기존 로드 처리 ...
        var auto_state: String = "켜짐" if TimeManager.auto_progress_enabled else "꺼짐"
        _show_toast("📂 로드 완료 — 자동 진행: %s" % auto_state)

func _show_toast(message: String, duration: float = 5.0) -> void:
    if toast_label == null: return
    toast_label.text = message
    # 기존 트윈 취소 (중복 호출 대비)
    if _toast_tween != null and _toast_tween.is_valid():
        _toast_tween.kill()
    # 페이드 인 → 유지 → 페이드 아웃
    _toast_tween = create_tween()
    _toast_tween.tween_property(toast_label, "modulate:a", 1.0, 0.3)
    _toast_tween.tween_interval(duration)
    _toast_tween.tween_property(toast_label, "modulate:a", 0.0, 0.5)
```

### main.tscn — Toast Label

```ini
[node name="Toast" type="Label" parent="UI"]
anchor_left = 0.5
anchor_top = 0.92
anchor_right = 0.5
anchor_bottom = 0.92
offset_left = -300.0
offset_top = -40.0
offset_right = 300.0
offset_bottom = 0.0
text = ""
horizontal_alignment = 1
vertical_alignment = 1
modulate = Color(1, 1, 1, 0)  # 처음엔 투명
mouse_filter = 2  # 클릭 통과
theme_override_font_sizes/font_size = 16
```

**위치 선택 이유**: 화면 하단 92% — 자동 진행 상태바(상단) / 게임 콘텐츠(중앙) / 토스트(하단) 분리로 시각적 혼잡 방지.

## 검증 (LB_VERIFY 확장)

```gdscript
# main.gd _run_verify()에 추가
print("[1.5] 자동 진행 기본값 검증")
assert(TimeManager.auto_progress_enabled, "새 게임 후 자동 진행이 ON이어야 함")
print("  ✓ 자동 진행 ON 확인 — 위임 시 즉시 흐름 시작")
```

`enable_auto_progress()`는 idempotent (이미 ON이면 no-op) — 중복 호출 안전.

## 다른 엔진 차용

### React + Zustand

```tsx
function NewGameButton() {
  const { startNewGame } = useGameStore()

  const handleClick = () => {
    startNewGame()
    // 자동 진행은 startNewGame 액션 내부에서 기본 ON
    showToast("🤖 자동 진행 시작 — 결정이 필요하면 모달이 뜹니다 (P: 일시정지)")
  }

  return <button onClick={handleClick}>새 게임</button>
}

// store
startNewGame: () => set(state => {
  state.world = initialWorld()
  state.autoProgress = true  // ← 기본값
  state.time = 0
  // ...
})
```

```tsx
function Toast({ message, duration = 5000 }) {
  const [visible, setVisible] = useState(false)
  useEffect(() => {
    if (!message) return
    setVisible(true)
    const timer = setTimeout(() => setVisible(false), duration)
    return () => clearTimeout(timer)
  }, [message, duration])

  return (
    <div className={`toast ${visible ? 'visible' : ''}`}>{message}</div>
  )
}
```

## 핵심 Pitfalls

### 1. 토스트 트윈 중복 호출 시 메모리 누수
`_show_toast`가 연속 호출되면 `_toast_tween`이 새로 시작 → 이전 트윈은 진행 중인 채로 abandon. **반드시 `if _toast_tween != null and _toast_tween.is_valid(): _toast_tween.kill()` 호출 후 새로 시작.**

### 2. 토스트 위치 — 메뉴 화면 가림 주의
화면 하단 92%는 게임 화면에선 OK지만 메뉴 화면에서 토스트가 버튼을 가릴 수 있음. **GameManager 상태에 따라 위치 조정** 또는 메뉴 화면에선 토스트 비활성.

### 3. 자동 진행 OFF 로드 시 혼란
사용자가 명시적으로 자동 진행 OFF → 저장 → 다음 진입에도 OFF. 토스트에 "자동 진행: 꺼짐" 표시해 혼란 방지. 토글 누르면 즉시 토스트로 "켜짐/꺼짐" 알림.

### 4. 첫 진입 토스트 길이
너무 길면 (10초+) 사용자 짜증. **5초가 적정**. 결정 다이얼로그 모달이 더 중요하니 토스트는 짧게.

### 5. 토스트가 결정 다이얼로그와 겹치지 않게
토스트 위치 (하단 92%) vs 다이얼로그 위치 (중앙) → 겹칠 일 없음. 하지만 만약 토스트를 상단으로 옮기면 다이얼로그 우선순위 배지와 겹칠 수 있음.

## Last Banner 검증 결과

- 새 게임 → 자동 진행 즉시 ON
- 토스트 5초 후 페이드아웃
- 결정 다이얼로그 자동 트리거 정상 (CRITICAL → 모달, LOW/MEDIUM → 큐 알림만)
- 24시간 시뮬: 사건 3건 자동 생성, 1건 자동 결정 처리
- 로드 시 자동 진행 상태 보존 확인

→ 진입 마찰 0으로 사용자가 한 번의 클릭으로 게임 시작 → 결정 처리 → 종료 패턴이 자연스러워짐.