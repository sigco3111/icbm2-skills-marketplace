# Full Autopilot — End-to-End Auto Decision Queue Pattern

> 자동위임 토글 ON이면 매 턴 모든 플레이어 행동(개발/징병/수색/조련/출정/방어)을 AI가 위임하고, 사용자가 "턴 종료" 한 번 클릭하면 천하통일/멸망 모달까지 자동 진행되는 패턴.

이 패턴은 CK3/EU4/HOI4 스타일 "give me a minute, I'll think for you" 자동 진행에서 출발하지만, **LastBanner 결정 큐(LOW/MED/HIGH/CRITICAL)와 다른 점은 결정이 아니라 행동을 위임**한다는 것. 매 step이 단순 액션 실행이라 결정 큐보다 빠르고 동기적.

sango-rising-dragons-kr (Phaser 3 / TypeScript, 2026-07-20)에서 실전 검증. 1차(A안) → 풀 자동화(B안)까지 5 turn에 걸쳐 점진 확장.

---

## 핵심 원칙

### 1. 한 step = 한 행동 (atomic + 즉시 평가)

```
[endTurn] → [announcePlan] → [step 1] → [step 2] → ... → [step N] → [AI turns] → [next player turn]
```

각 step은 동기적으로 1개 액션 실행 후 즉시 다음 step 예약 (setTimeout 60~220ms). 모달 안 뜨고 사용자 개입 없이 끝까지 흐름.

### 2. 우선순위 큐 (build queue → drain step)

```typescript
function buildQueue(allowRelaxed): Action[] {
  return [
    ...tryPick(attack, allowRelaxed),     // P1: 강한 적지 공격
    ...tryPick(move),                      // P2: 부대 응집 이동
    ...tryPick(search),                    // P3: 재야 인재 수색
    ...tryPick(train),                     // P4: 가장 약한 장수 조련
    ...tryPickAll(developPerCity),         // P5: 도시별 개간/통상/축성/징병
  ];
}
```

**relaxed vs strict 모드** (resource-aware):
- `allowRelaxed = G.cp >= 4`일 때: 공격 임계값 낮춤 (1.4 → 1.0), 더 적극적
- 부족할 때: 보수적 (1.4 = AI와 동일), 자원 보존

### 3. step 함수의 3-반환 시맨틱

```typescript
function stepAutopilot(): boolean {
  // ... 한 액션 실행 ...
  if (a.kind === 'march-attack') return false;  // ← 전투는 비동기, halt
  if (recruit(...)) return G.cp > 0;             // ← 성공 + CP 남음 → 다음 step
  return false;                                  // ← 큐 소진 or 실패 → 종료
}
```

march-attack은 전투 결과를 기다려야 하니 false 반환 후 비동기 핸들러가 다시 stepAutopilot 호출.

### 4. ★ return값 무시 = 무한 루프 (가장 흔한 함정)

```typescript
// ❌ 무한 루프 — 실패해도 CP/acted 미변경인데 true 반환
if (a.kind === 'train') {
  trainOfficer(o.id);  // gold 부족으로 실패해도 return값 안 봄
  bus.emit('log', '✓ 조련');
  return G.cp > 0;     // ← 항상 true → 같은 후보 영원히 재시도
}

// ✓ 정상 — return값 보고 실패 시 continue
if (a.kind === 'train') {
  const ok = trainOfficer(o.id);
  if (!ok) {
    bus.emit('log', '✗ 스킵');
    continue;  // ← 다음 후보로
  }
  bus.emit('log', '✓ 성공');
  return G.cp > 0;
}
```

**실측 (2026-07-20)**: `trainOfficer`가 `gold < 150`일 때 false 반환 + "⚠ 조련에는 150 금이 필요합니다" 로그 + CP/acted 미변경. 자동위임은 같은 후보를 매 step 재선택 → 로그 무한 누적. **fix: 모든 액션 분기에 반환값 체크.**

같은 패턴으로 `recruit`, `develop` 모두. **`searchTalent`도 모달 띄우므로 인라인해서 모달 우회 + 결과 로그로 대체**해야 자동 진행 유지.

### 5. ★ 안전 카운터 (depth)

```typescript
function runAutopilotTurn() {
  if (runAutopilotTurn._depth > 50) {
    bus.emit('log', '🤖 ⚠ 자동위임 안전 종료 (50회 시도 초과)');
    continueAi(0);
    return;
  }
  runAutopilotTurn._depth++;
  // ...
}
```

50회 초과 시 강제 종료 + AI 턴으로 전환. **다른 함정이 있어도 무한 루프는 막힘**.

---

## 결정 큐 우선순위 (5단계, LastBanner 변형)

| P | 액션 | pick 조건 | fail 처리 |
|---|---|---|---|
| **P1** | ⚔ 출정(공격) | ratio >= 1.4 (CP<4) 또는 1.0 (CP>=4), troops>=6000, 출정 가능 장수>=1, 인접 적지 존재 | 후보 없으면 P2로 |
| **P2** | 🚩 출정(이동) | 인접 아군 도시 중 그 도시가 적 인접(전선), 부대 이동 가능 | 후보 없으면 P3 |
| **P3** | 🔍 수색 | 재야 인재 있는 도시, CP>=1, 행동 안 한 장수 | 후보 없으면 P4 |
| **P4** | 🎯 조련 | CP>=1, gold>=150, 행동 안 한 장수, level 가장 낮은 | 후보 없으면 P5 |
| **P5** | 개발/징병 | 도시별 farm<2→개간, market<2→통상, walls<3+인접적지→축성, troops<8k→징병 | 모두 skip 또는 fail이면 step 종료 |

**relaxed mode (CP>=4)**: P1 임계값을 1.4 → 1.0으로 완화 (더 적극적 출정).

---

## 상세 로그 패턴 (사용자 가시성)

매 step 마다 한 줄 로그. 사용자가 무슨 일이 벌어지는지 알 수 있게:

```typescript
bus.emit('log', `🤖 #${idx} ${cityName} ${ACTION_ICON[a.kind]} ✓ ${before}→${after} (CP: ${G.cp}, 금: ${G.gold})`, 'auto');
```

```
🤖 자동위임 계획 (공격적, CP=5): 6개 — ⚔ 출정(공격) ×1, 🚩 출정(이동) ×1, 🔍 수색 ×1, 🎯 조련 ×1, 🌾 개간 ×2, ⚔ 징병 ×1.
🤖 자동위임 시작 — 모든 플레이어 행동을 위임합니다.
🤖 #1 진류→양양 ⚔ 출정(공격) → 자동 출정: 진류→양양 🏴 함락! (8,000 vs 6,200, 성벽 2, 비율 ≈1.45) — 아군 잔여 4,800, 적 잔여 100.
🤖 #2 진류→허도 🚩 이동 ✓ 5,000→2,500 (전선 보강) (남은 CP: 4).
🤖 #3 허도 🔍 수색 ✓ 관우 합류! (금 변화 0) (남은 CP: 3).
🤖 #4 관우 🎯 조련 ✓ (금 변화 -150) (남은 CP: 2).
🤖 #5 진류 🌾 개간 ✓ Lv0→Lv1 · -400 금 (남은 CP: 1, 금: 350).
🤖 #6 허도 ⚔ 징병 ✗ 스킵 — 금 부족.
🤖 자동위임 종료 — AI 턴으로 넘어갑니다.
```

**'auto' CSS 클래스**: 파란 보더 + 이탤릭 + 약간 투명 — 일반 로그와 시각 구분.

---

## 출정 자동결산 (battle hookup)

출정(공격)은 전투 → 결과 → 다음 step 비동기 체인:

```typescript
// stepPlayerAutopilot 안:
if (a.kind === 'march-attack') {
  const setup: BattleSetup = { ... };
  bus.emit('autopilotMarch', setup);  // ← fire-and-forget
  return false;  // halt step chain
}

// flow.ts에서:
bus.on('autopilotMarch', (setup: BattleSetup) => {
  // 1. CP 차감 + 장수 acted (수동 marchDialog와 동일)
  G.cp--;
  for (const id of setup.atkOfficers) G.officers[id].acted = true;
  
  // 2. source troops 차감 (applyBattleResult의 retreat+ 보정용)
  G.cities[setup.sourceCityId!].troops = Math.max(0, 
    G.cities[setup.sourceCityId!].troops - setup.atkTroops);
  
  // 3. autoResolve + applyBattleResult (한 줄에 압축)
  const result = autoResolve(setup);
  const won = result.winner === 'atk';
  bus.emit('log', `🤖 자동 출정: ${from}→${to} ${won ? '🏴 함락!' : '💥 실패'} (...)`, 'auto');
  applyBattleResult(setup, result);
  
  // 4. step chain 재개
  runAutopilotTurn();
});
```

**함정**: `applyBattleResult`는 패배 시 `src.troops += atkRemaining` 한다고 가정 (수동 marchDialog가 미리 차감). 자동위임은 미리 차감 안 했으니 **직접 차감 후 `applyBattleResult` 호출** — 그래야 패배 시 잔여 병력이 source로 정확히 복귀.

---

## 전술 전투 자동 조작 (BattleScene 확장)

출정 시 **autoResolve**가 안 통하는 경로(예: 미래 강제 전투 이벤트)에서 전투 화면이 뜨면, 아군 phase에서 AI가 직접 조작:

```typescript
// BattleScene에 init 옵션 추가
init(data: { setup: BattleSetup; autopilot?: boolean }) {
  this.battleAutopilot = !!data.autopilot;
}

create() {
  // ...
  if (this.battleAutopilot) {
    bus.emit('log', '🤖 전투위임 — 아군 유닛을 자동 조작합니다.', 'auto');
    this.time.delayedCall(450, () => this.playerAiStep());
  }
}

private playerAiStep(): void {
  if (!this.battleAutopilot || this.phase !== 'player') return;
  
  const u = this.pickNextPlayerUnit();  // HP ratio 가장 낮은 유닛
  if (!u) { this.startEnemyPhase(); return; }
  
  // P1: 스킬 (45% 확률)
  if (u.cd <= 0 && hasSkillTargets(u) && Math.random() < 0.45) {
    this.execSkill(u, sk, lowestHpFoe.gx, lowestHpFoe.gy);
    return;
  }
  
  // P2: 공격 (사거리 내, 저체력 적 우선)
  const inRange = foesInRange(u).sort((a, b) => a.hp - b.hp);
  if (inRange.length > 0) {
    this.doAttack(u, inRange[0]);
    return;
  }
  
  // P3: 이동 (가장 가까운 적 방향)
  this.playerMoveAndMaybeAttack(u, nearestFoe);
}

// finishAction에서 autopilot이면 다음 step 체인
private finishAction(u: BUnit) {
  u.done = true;
  if (this.phase === 'player' && this.battleAutopilot) {
    this.time.delayedCall(360, () => this.playerAiStep());
  }
}
```

**HUD 표시**: `updateTurnLabel`에서 autopilot일 때 라벨에 " 🤖 위임 중" 추가 + 라벨 색상 파란색 (`#9cc1ff`)으로 변경 — 사용자 인지.

---

## 천하통일/멸망까지 자동 진행 시나리오

```
사용자: 새 게임 → 자동위임 ON → "턴 종료" 한 번 클릭
→ 1턴 위임 (6 step) → AI 턴 (11 진영)
→ 다음 턴: 위임 (8 step) → AI 턴
→ ... 반복 ...
→ checkVictory(): player cities >= 12 → gameover 'win'
→ 1900ms 후 🏆 천명소귀 모달 표시
→ "새로운 출정 시작" 버튼 → location.reload()
```

**주의**: 이벤트 모달(서사)은 자동 진행을 막음 — 사용자가 클릭해야 진행. 정책 결정 모달(예: 황건 토벌)도 사용자 결정 대기. **이게 의도된 디자인** — 핵심 의사결정은 사용자만.

---

## 일반화 가능한 패턴 정리 (다른 게임에 적용)

| 클래스 | 적용 |
|---|---|
| **전략/4X 게임** (CK3, EU4) | 매 턴 결정 큐 + 우선순위 + relaxed/strict 모드 |
| **RPG 로그라이크** | 전투 중 AI 조작 (스킬 우선 + HP ratio 정렬) |
| **경영 시뮬** (tycoon) | 도시/시설별 결정 + 인프라 우선순위 |
| **Realtime-with-pause** | pause 타이밍에 결정 큐 flush |

**공통 3원칙**:
1. **return값 항상 확인** (실패 시 continue)
2. **안전 카운터** (50회)
3. **상세 로그** (사용자가 위임 중 무슨 일이 일어나는지 인지)

→ 다른 게임에 적용 시 이 3원칙 + 본 문서의 5단계 우선순위 큐 패턴을 그대로 가져가면 됨.

---

## 검증 방법

자동위임 기능 자체를 헤드리스로 단위 테스트하기는 어려움 (UI + Phaser 의존). 대신 다음 회귀 테스트:

1. **빈 시나리오**: CP=0 → step 0개 → 즉시 AI 턴 (depth 0 반환)
2. **자원 고갈 시나리오**: gold=0 + food=0 → recruit/develop/train 모두 skip → AI 턴
3. **전투 발생 시나리오**: 자동위임 출정 → autoResolve → 즉시 다음 step
4. **엔딩 시나리오**: 50회 안전 종료 후에도 gameover 체크 정상

실측 검증 (sango-rising-dragons-kr, 2026-07-20):
- 자동위임 10턴 연속 실행 → 천하통일/멸망 모달까지 무한 루프 없음
- 무한 루프 시뮬레이션 (gold=0 강제) → "✗ 스킵" 로그 + 안전 종료 50회 카운터 미발동
- 전투 hookup: 출정 → 450ms 후 전투 화면 → 자동 조작 → 결과 → 다음 step