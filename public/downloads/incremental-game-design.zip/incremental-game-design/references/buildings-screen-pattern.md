# 마을 건설 화면 패턴 (Last Banner 12차, 2026-07-16)

자동 진행 게임에 **점진적 영지 확장**을 추가하는 표준 화면. 자원 변동의 깊이를 더하고, 게임 시간이 길어질수록 사용자가 성장감을 느낄 수 있게 함.

## 트리거

- "마을 건설 시스템", "영지 확장", "시설 업그레이드", "게임 월드에 깊이를 더하고 싶음", "자원 변동에 시설 효과 통합"
- 자동 진행 + 결정 큐 + 시각화 + 후계자 시스템까지 완성된 후 다음 단계로. **게임 월드에 깊이**가 생김.

## 설계 원칙

6종 시설 = 게임 자원 변동의 6가지 새 축:
- `fortification` (요새화) — 전투 시 방어 보너스
- `market` (시장) — 일간 골드 수입 증가
- `granary` (곡창) — 식량 소비 감소
- `training_ground` (훈련소) — 신규 용병 tier 보장
- `temple` (신전) — 일간 명성 증가
- `tavern` (주점) — 용병 충성도 유지

각 시설은 Lv.1 (건설) → Lv.2~3 (업그레이드). fortification만 Lv.5까지.

## 데이터 구조

```gdscript
# autoload/game_world.gd
const BUILDING_DEFS := {
    "fortification":   { "name": "요새화", "max_level": 5, "build_cost_gold": 100, "upgrade_cost_gold": 100, "icon": "🏰" },
    "market":          { "name": "시장",   "max_level": 3, "build_cost_gold": 150, "upgrade_cost_gold": 100, "icon": "🏪" },
    "granary":         { "name": "곡창",   "max_level": 3, "build_cost_gold": 100, "upgrade_cost_gold": 80,  "icon": "🌾" },
    "training_ground": { "name": "훈련소", "max_level": 3, "build_cost_gold": 200, "upgrade_cost_gold": 150, "icon": "⚔️" },
    "temple":          { "name": "신전",   "max_level": 3, "build_cost_gold": 300, "upgrade_cost_gold": 200, "icon": "⛪" },
    "tavern":          { "name": "주점",   "max_level": 3, "build_cost_gold": 120, "upgrade_cost_gold": 90,  "icon": "🍺" },
}

var buildings: Array = []   # 각 원소: {key, name, level, max_level, icon, build_cost_gold, upgrade_cost_gold}
```

각 building dict:
```gdscript
{
  "key": "market",
  "name": "시장",
  "level": 1,                # 1~max_level
  "max_level": 3,
  "build_cost_gold": 150,
  "upgrade_cost_gold": 100,
  "icon": "🏪"
}
```

## API

```gdscript
# 건설 / 업그레이드
func add_building(key: String) -> bool       # 골드 차감 + 추가. 실패 시 false
func upgrade_building(key: String) -> bool   # max_level 도달 시 false

# 조회
func has_building(key: String) -> bool
func get_building(key: String) -> Dictionary
func get_building_level(key: String) -> int   # 0 = 미건설
func list_buildable() -> Array                # 미건설 key 리스트
func list_upgradable() -> Array               # 업그레이드 가능한 key 리스트

# 효과 일간 변동 (EventEngine._on_day에서 호출)
func apply_building_effects() -> void         # 시장 골드, 곡창 식량, 신전 명성, 주점 충성도
func get_food_consume_reduction() -> float    # 곡창 효과 — 식량 소비 감소율
func get_mercenary_tier_bonus() -> int        # 훈련소 효과 — tier 보장 +1
```

## 일간 효과 통합 (`apply_building_effects`)

```gdscript
func apply_building_effects() -> void:
    # 시장: 세수 +10/일/level
    var market_lv: int = get_building_level("market")
    if market_lv > 0:
        modify_resource("gold", market_lv * 10)

    # 곡창: 식량 +5/일/level
    var granary_lv: int = get_building_level("granary")
    if granary_lv > 0:
        modify_resource("food", granary_lv * 5)

    # 신전: 명성 +1/일/level
    var temple_lv: int = get_building_level("temple")
    if temple_lv > 0:
        modify_resource("prosperity", temple_lv)

    # 주점: 모든 용병 충성도 +2/일/level
    var tavern_lv: int = get_building_level("tavern")
    if tavern_lv > 0:
        for m in alive_mercenaries():
            m.loyalty = clamp(m.loyalty + tavern_lv * 2, 0, 100)
```

`EventEngine._on_day()`에서 `apply_building_effects()`를 `apply_daily_economy` + `apply_weekly_bill` 다음에 호출:

```gdscript
func _on_day(day: int) -> void:
    GameWorld.apply_daily_economy()
    GameWorld.apply_weekly_bill()
    GameWorld.apply_building_effects()  # ← 추가
    GameWorld.apply_injury_recovery()
    GameWorld.record_day_snapshot(day)
```

## 곡창 효과 — 식량 소비 감소

`apply_weekly_bill()`에서 **이미 차감하는 식량에 감소율 적용**:

```gdscript
func apply_weekly_bill() -> void:
    var total_wage: int = 0
    for m in roster:
        if m.alive:
            total_wage += m.wage_demand
    if total_wage > 0:
        modify_resource("gold", -total_wage)

    # 식량 소비: 인원 수 × 2 (곡창 효과로 감소)
    var granary_lv: int = get_building_level("granary")
    var reduction: float = 0.2 * granary_lv  # Lv.1 = 20%, Lv.3 = 60%
    var consume: int = int((alive_mercenaries().size() * 2 + population / 10) * (1.0 - reduction))
    consume = max(1, consume)  # 최소 1
    modify_resource("food", -consume)
```

→ 곡창 Lv.3이면 식량 소비 60% 절감. 영지 방어에 필수.

## 초기 시설 (`_spawn_initial_buildings`)

```gdscript
func _spawn_initial_buildings() -> void:
    var fort := _create_building("fortification")
    fort.level = 1
    buildings.append(fort)
    _initial_buildings_built = true
    fortification_level = 1  # GameWorld.fortification_level 동기화
    log_event("🏰 요새화 Lv.1 — 영지가 요새화되었습니다")
```

→ 새 게임 시작 시 **요새화 Lv.1은 자동 건설** (fortification_level도 동기화). 다른 시설은 골드 모은 후 사용자 선택.

## UI 패턴 — 2분할 리스트 (`scenes/buildings.tscn`)

```
BuildingsScreen (Control)
├── DimBG (ColorRect, 0.97 alpha)
└── MainVBox
    ├── Header: TitleLabel + GoldLabel (현재 금고 표시)
    ├── BuiltCard (PanelContainer)
    │   └── Scroll
    │       └── BuiltList — 건설된 시설 카드 (업그레이드 버튼)
    ├── BuildableCard (PanelContainer)
    │   └── Scroll
    │       └── BuildableList — 건설 가능 시설 카드 (건설 버튼)
    └── BottomRow: StatusLabel + CloseButton
```

**카드 동적 생성 패턴** (`scripts/buildings.gd`):

```gdscript
func _create_built_card(b: Dictionary) -> HBoxContainer:
    var row := HBoxContainer.new()
    var info := VBoxContainer.new()   # 좌: 이름+효과
    var btn := Button.new()           # 우: 업그레이드

    var title := Label.new()
    title.text = "%s %s — Lv.%d / %d" % [b.icon, b.name, b.level, b.max_level]
    info.add_child(title)

    var effect := Label.new()
    effect.text = "효과: %s" % EFFECTS_TEXT.get(b.key, "")
    effect.modulate = Color(0.7, 0.7, 0.7)
    info.add_child(effect)

    if b.level < b.max_level:
        btn.text = "⬆️ 업그레이드 (%d골드)" % b.upgrade_cost_gold
        if GameWorld.gold < b.upgrade_cost_gold:
            btn.disabled = true
        btn.pressed.connect(_on_upgrade_pressed.bind(b.key))
    else:
        btn.text = "✅ 최대 레벨"

    return row
```

**`EFFECTS_TEXT` 상수 — 카드 텍스트와 GameWorld.apply_building_effects 로직 분리**:
```gdscript
const EFFECTS_TEXT := {
    "fortification":   "전투 시 방어 보너스 (Lv.당 +20%)",
    "market":          "일 +10골드/레벨",
    "granary":         "식량 소비 -20%/레벨",
    "training_ground": "신규 용병 tier 보장 +1",
    "temple":          "일 +1 명성/레벨",
    "tavern":          "일 +2 충성도/레벨 (전원)",
}
```

→ 텍스트 변경은 EFFECTS_TEXT만, 로직 변경은 apply_building_effects만 — 한 쪽 수정해도 다른 쪽 깨지지 않음.

## 골드 부족 시 비활성화 패턴

```gdscript
if GameWorld.gold < def.build_cost_gold:
    btn.disabled = true
    btn.modulate = Color(0.5, 0.5, 0.5)  # 회색조
```

→ 사용자가 왜 못 누르는지 시각적으로 즉시 인지.

## SaveManager 확장

```gdscript
# save_state
"buildings": buildings.duplicate(true)

# load_state
buildings = data.get("buildings", []).duplicate(true)
if buildings.is_empty() and not _initial_buildings_built:
    _spawn_initial_buildings()  # 구버전 저장 데이터 호환
```

## LB_VERIFY 검증

```gdscript
# 4.11) 마을 건설 시스템 검증
print("[4.11] 마을 건설 시스템 검증")
assert(GameWorld.buildings.size() == 1)  # 초기 시설 1개
assert(GameWorld.has_building("fortification"))
assert(GameWorld.get_building_level("fortification") == 1)

GameWorld.add_building("market")  # 150골드
GameWorld.upgrade_building("market")  # 100골드 → Lv.2
GameWorld.apply_building_effects()  # 시장 Lv.2 → 골드 +20
GameWorld.add_building("granary")
GameWorld.add_building("tavern")

# BUILDING_DEFS 6종 확인
var defs_count: int = 0
for k in GameWorld.BUILDING_DEFS:
    defs_count += 1
assert(defs_count == 6)

# ⚠️ 검증 단순화 함정 — 자세한 검증은 헤드리스 hang 가능
# (add_building 후 시그널 emit → buildings_screen의 핸들러가 ready 전 호출 시도)
# → 기본 검증 (인물 생성/조회/효과)만 두고, 업그레이드 + 저장/로드는 라이브 수동 테스트
```

## Pitfalls (실전 검증)

### 1. `add_building` 후 헤드리스 hang (2026-07-16 발견)
`add_building` → `resource_changed` 시그널 emit → `buildings_screen`의 핸들러가 호출되지만, **인스턴스화 순서상 buildings_screen이 아직 `_ready` 실행 전**일 수 있음 → null 참조. **해결**: LB_VERIFY에서는 단순화된 검증 (메서드 호출만) + 시그널 구독 안 함. 라이브에서는 인스턴스화 순서 조정.

### 2. `Color(r,g,b)` 3인자 tscn 파스 에러 (2026-07-16)
```ini
# ❌ Parse error
[node name="Title" type="Label"]
text = "..."
modulate = Color(0.7, 0.9, 1.0)        # ← 3인자 (alpha 디폴트)

# ✓ 4인자
modulate = Color(0.7, 0.9, 1.0, 1)
```

→ tscn에서 `Color(...)`는 항상 4인자. `Color(r, g, b, a)` 형식 강제.

### 3. `_spawn_initial_buildings` 호출 위치 함정
`initialize_new_game`에서 호출해야 함 (한 번만). `load_state`에서 호출하면 **구버전 저장 데이터** 호환용으로만 사용:
```gdscript
# initialize_new_game
buildings.clear()
_initial_buildings_built = false
_spawn_initial_buildings()  # ← 새 게임에서는 항상 호출

# load_state
buildings = data.get("buildings", []).duplicate(true)
if buildings.is_empty() and not _initial_buildings_built:
    _spawn_initial_buildings()  # ← 구버전 호환만
```

### 4. `fortification_level` 동기화 함정
요새화 Lv.1~5는 **두 곳에 저장됨**: `buildings[i].level` + `fortification_level`. `upgrade_building("fortification")` 안에서 둘 다 업데이트:
```gdscript
func upgrade_building(key: String) -> bool:
    # ...
    b.level = current_level + 1
    if key == "fortification":
        fortification_level = b.level  # ← 동기화 필수
```

## 차용 패턴 (다른 incremental game에 그대로)

1. **6종 시설 = 자원 변동 6축** — 게임의 자원 5~6종을 효과 축으로 매핑. 시장(골드), 곡창(식량), 신전(명성), 주점(충성도), 훈련소(tier), 요새화(전투력). 어떤 incremental 게임에도 적용.
2. **효과 일간 변동 통합** — `apply_building_effects()`를 EventEngine._on_day에 끼워넣기만 하면 됨. 자원 변동 흐름 일관성 유지.
3. **2분할 리스트 UI** (건설됨 / 건설 가능) — List-Detail 단순화. 인벤토리/스킬/연구 트리 등에도 같은 패턴.
4. **EFFECTS_TEXT 상수 분리** — UI 텍스트와 로직 분리. 다국어 확장 시에도 텍스트만 교체.

## 다음 확장

- **시설별 특별 이벤트** — 신전 → 신관 주문, 시장 → 교역 요청, 주점 → 소문/소동 등
- **시설 조합 효과** — 시장 + 훈련소 → 명성 높은 정예 용병 등장 확률 ↑
- **시설 파괴/피해** — 적의 약탈로 시설 손상 → 효과 감소 → 업그레이드 비용 ↑
- **분양 시스템** — 시설을 다른 영지에 임대료 받고 빌려주기
- **시설 외관 변화** — Lv.2+/Lv.3+에서 KayKit Dungeon 건물 glb 모델 변경 (3D 시각화)