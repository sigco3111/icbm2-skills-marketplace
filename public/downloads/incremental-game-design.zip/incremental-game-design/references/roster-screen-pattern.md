# Roster / List-Detail Screen Pattern (위임 진행 게임의 컬렉션 UI)

incremental / auto-progression 게임에서 **용병 명단, 인벤토리, 인적 자원, 관계도** 같은 컬렉션을 표시하는 화면의 표준 패턴. Last Banner `scenes/roster.tscn` + `scripts/roster.gd`에서 검증 (2026-07-16).

## 핵심 문제

자동 진행으로 자원/유닛이 계속 변동한다. 그걸 어떻게:

1. **사용자에게 한눈에 보여줄 것인지** (전체 리스트 vs 요약 카드)
2. **상세 정보를 어디에** (같은 화면 vs 모달)
3. **자동 갱신** (시그널 구독 vs _process 폴링)

→ **3-pane List-Detail 레이아웃 + 시그널 구독**이 정답.

## 3-pane 레이아웃 (Godot 4)

```
┌──────────────┬───────────────────────┬──────────────┐
│  Left Panel  │  Center Panel         │  Right Panel │
│  (List)      │  (Detail)             │  (Stats)     │
│  280~320px   │  size_flags=3 (확장)  │  260~300px   │
│              │                       │              │
│  ▸ 이름/직업  │  [선택된 항목 상세]    │  통계        │
│  ▸ 상태 아이콘 │  스탯 그리드          │  분포        │
│  ▸ 티어 색상  │  액션 버튼            │  합계        │
└──────────────┴───────────────────────┴──────────────┘
        HBoxContainer (separation=0, fullscreen anchor)
        각 Panel: custom_minimum_size x 또는 size_flags_horizontal=3
```

**왜 3-pane?**
- **Left (List)**: 스캔 — "누가 있지?" 한 번에 보기. ScrollContainer + 동적 행.
- **Center (Detail)**: 정독 — 선택한 항목의 모든 정보. GridContainer로 라벨/값 페어링.
- **Right (Stats)**: 집계 — 전체 분포/합계. "총 얼마?" 빠른 답.

## 동적 행 생성 (런타임 instantiate)

씬에 행을 박지 말 것. **`_add_mercenary_row()` 함수에서 `Button.new()` → 리스트에 add_child()**:

```gdscript
func _add_mercenary_row(m: Dictionary) -> void:
    var btn := Button.new()
    btn.custom_minimum_size = Vector2(0, 56)
    btn.toggle_mode = true
    btn.text = "%s%s\n%s · T%d · 충성도 %d" % [status_icon, m.name, m.class_label, m.tier, m.loyalty]
    btn.alignment = HORIZONTAL_ALIGNMENT_LEFT
    btn.pressed.connect(_on_row_pressed.bind(m.id))
    list_vbox.add_child(btn)
    _row_buttons.append(btn)
```

**이점**:
- 컬렉션 크기가 변동 (용병 사망, 합류)해도 씬 파일 수정 불필요
- `refresh()` 시 기존 행 `queue_free()` 후 재생성 = 깔끔
- 메모리 부담: 12명 이하 권장 (그 이상은 가상화 필요)

## 시그널 구독으로 자동 갱신

**핵심**: GameWorld의 변동 시그널을 구독해서 화면이 알아서 갱신되게.

```gdscript
func _ready() -> void:
    GameWorld.mercenary_joined.connect(_on_mercenary_changed)
    GameWorld.mercenary_left.connect(_on_mercenary_changed)
    GameWorld.mercenary_injured.connect(_on_mercenary_changed)

func _on_mercenary_changed(_m = null, _reason: String = "") -> void:
    if visible:
        refresh()
```

**`visible` 체크**: 화면 떠있을 때만 갱신 (백그라운드에서 매번 재구성하면 CPU 낭비).

## ⚠️ 시그널 핸들러 인자 미스매치 함정 (가장 흔한 버그)

**증상**:
```
ERROR: Error calling from signal 'mercenary_left' to callable: 'Control(roster.gd)::_on_mercenary_changed':
       Method expected 1 argument(s), but called with 2.
```

**원인**: `mercenary_left`는 `(mercenary, reason)` 2개 인자를 emit하지만, 핸들러는 1개만 받음. Godot이 런타임에서 잡아주지만 게임 진행은 계속됨 (silent crash).

**해결**: 핸들러를 가변 인자로:

```gdscript
# ❌ 안 됨 — 호출 인자 수 고정
func _on_mercenary_changed(_m: Dictionary) -> void: ...

# ✓ 됨 — 디폴트 인자로 시그널 변화에 강건
func _on_mercenary_changed(_m = null, _reason: String = "") -> void: ...
```

**원칙**: 같은 핸들러가 여러 시그널의 콜백이면, 가장 많은 인자를 가진 시그널 기준으로 디폴트 인자. 또는 각 시그널마다 별도 핸들러.

## 시각화 디테일 (티어/상태)

| 요소 | 표현 |
|---|---|
| Tier 1 (신참) | `Color(0.9, 0.9, 0.9)` 회색 |
| Tier 2 (숙련) | `Color(0.6, 0.8, 1.0)` 파랑 |
| Tier 3 (정예) | `Color(1.0, 0.85, 0.4)` 금색 |
| 사망자 💀 | modulate 회색 + `disabled = true` (클릭 불가) |
| 부상자 🩹 | modulate 황색 |
| 충성도 < 30 ⚠️ | modulate 빨강 |
| 충성도 30~50 | modulate 주황 |
| 충성도 50+ | modulate 초록 |

**색상 의미 일관성 유지**: 같은 상태(부상/사망/위험)가 다른 화면에서도 같은 색이면 사용자 학습 비용 ↓.

## _process 폴링 (보조)

시그널이 안 통하는 상태 변화도 있음 — 예: `TimeManager.apply_injury_recovery()`는 부상일을 매일 감소시키지만 별도 시그널 emit 안 함.

```gdscript
func _process(_delta: float) -> void:
    if visible:
        _refresh_stats()                          # 가벼움
        if _selected_mercenary_id >= 0:
            _refresh_detail()                     # 선택된 1명만 갱신
```

**원칙**: 시그널이 없는 변동은 `_process`로 보충. 하지만 **항상 visible 체크** (백그라운드 갱신 X).

## main.tscn 통합 — 토글 버튼 + 인스턴스

```ini
[ext_resource type="PackedScene" uid="uid://b1roster" path="res://scenes/roster.tscn" id="3_roster"]

[node name="Main" type="Node2D"]
[node name="UI" type="CanvasLayer" parent="."]
[node name="RosterButton" type="Button" parent="UI/ButtonRow"]   # 토글
text = "용병 명단 (R)"
[node name="RosterScreen" parent="." instance=ExtResource("3_roster")]
visible = false
```

**게임 시작 전 비활성**:
```gdscript
@onready var roster_button: Button = $UI/ButtonRow/RosterButton

func _ready() -> void:
    roster_button.disabled = true
    # ...

func _on_start_pressed() -> void:
    GameManager.start_new_game("default")
    roster_button.disabled = false  # 시작 후 활성화

func _on_roster_pressed() -> void:
    if roster_screen.has_method("show_screen"):
        roster_screen.show_screen()
```

**`show_screen()` 메서드**: visible=true + refresh() 한 번에 호출. 단순 visible 토글보다 명시적 진입점.

## 검증 패턴 (LB_VERIFY 검증 단계)

main.gd의 `_run_verify()`에 roster 화면 검증 추가:

```gdscript
# 용병 명단 화면 검증
var roster_screen: Node = get_tree().current_scene.find_child("RosterScreen", true, false)
if roster_screen:
    roster_screen.show_screen()
    await get_tree().process_frame

    var list_node: Node = roster_screen.get_node_or_null("MainHBox/LeftPanel/.../ListVBox")
    var initial_count: int = list_node.get_child_count()
    assert(initial_count == GameWorld.alive_mercenaries().size())

    # 새 용병 추가 → 시그널 자동 갱신 확인
    var new_m: Dictionary = GameWorld.offer_mercenary(Time.get_ticks_msec())
    GameWorld.accept_mercenary(new_m)
    await get_tree().process_frame
    assert(list_node.get_child_count() == GameWorld.alive_mercenaries().size())

    # 전투 사망 → 사망자 표시 (시그널 미스매치 검증)
    GameWorld.resolve_battle("defeat", 1, 0)
    await get_tree().process_frame
```

→ 시그널 핸들러 인자 미스매치는 이 검증에서 잡힘. **자동 갱신 + 사망자 표시까지 통과하면 핸들러 시그니처 OK**.

## UI/씬 빌더 결정 트리

| 컬렉션 종류 | 권장 레이아웃 |
|---|---|
| 1~20개 단순 리스트 (용병, 인벤토리) | 3-pane (Left list + Center detail + Right stats) |
| 20~100개 (세력, 영지, 마을) | 2-pane (Left list + Center detail만) |
| 100개 이상 (로그, 이벤트) | 1-pane (스크롤 리스트만) |
| 관계/그래프 (인물 관계도) | 노드 그래프 (별도 패턴) |

## 다른 엔진 차용 (React 예)

```tsx
function RosterScreen({ visible, onClose }) {
  const roster = useGameStore(s => s.world.roster)
  const [selectedId, setSelectedId] = useState<number | null>(null)

  // 시그널 = store action 자동 trigger
  // GameWorld.mercenary_joined → store 업데이트 → useGameStore 구독 자동 재렌더
  // visible 체크는 useMemo나 early return
  if (!visible) return null

  const alive = roster.filter(m => m.alive)
  const selected = roster.find(m => m.id === selectedId)
  const totalWage = alive.reduce((sum, m) => sum + m.wage_demand, 0)

  return (
    <div className="roster-3pane">
      <LeftPanel roster={alive} selectedId={selectedId} onSelect={setSelectedId} />
      <CenterPanel mercenary={selected} />
      <RightPanel alive={alive.length} totalWage={totalWage} gold={gold} />
    </div>
  )
}
```

→ 게임 월드 SSOT는 동일, UI는 엔진별 다르게. 시그널 핸들러 인자 미스매치는 Godot 전용 함정 (React는 props 타입 시스템이 잡아줌).

## 핵심 Pitfalls

### 1. UID 경고는 무시해도 OK
처음 tscn에 `uid://b1decisiondialog` 같은 UID 텍스트 박으면 Godot이 "invalid UID, using text path" 경고. 빌드 1회 후 자동 정규화. 차단 요소 아님.

### 2. show_screen() 후 process_frame 1번 대기
시그널이 같은 프레임에서 emit되면 `_process`가 갱신 전에 끝남. `await get_tree().process_frame` 1회 후 refresh() 호출.

### 3. 컬렉션 0개일 때 빈 상태 표시
용병 0명 = 빈 리스트 + "용병 없음" 라벨. 아니면 화면 자체가 깨진 것처럼 보임.

### 4. 사망자도 roster에 남김
사망 시 `m.alive = false`만 set, 리스트에서 제거하지 않음. 사후 통계/이벤트 트리거에 필요. UI에서 `if m.alive`로 분기.

### 5. 통계 갱신은 가볍게, 행 재생성은 무거움
stats는 텍스트만 update하므로 매 frame OK. 리스트 행은 add_child/queue_free 반복하면 GC 압박. **시그널 변경 시에만 재생성**.

## 관련

- **`incremental-game-design-last-banner-event-engine`** — 이 패턴을 실제로 구현한 사례 (`scenes/roster.tscn` + `scripts/roster.gd`)
- **결정 다이얼로그 패턴** — `references/decision-dialog-pattern.md` (모달 UI)
- **Godot 부트스트랩** — `godot-game-bootstrap` SKILL.md의 autoload 골격
- **Vercel Web Export + lazy fetch** — 이 화면도 Vercel 100MB 한계 회피 패턴 따름 (씬 + 스크립트만 pck에, 자산은 CDN)