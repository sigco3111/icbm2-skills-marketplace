# Modal Screen X Button + Z-Order Pattern (Last Banner, 2026-07-16)

> 모든 모달 화면(roster/dashboard/decision_dialog/tutorial/succession/battle/buildings)에 시각적 X 닫기 버튼 + Z-order 안전성. **사용자 피드백 "닫기 버튼 없음"이 4번 반복**되어 표준화.

---

## 표준 모달 화면 패턴 (4가지 통합)

| 요소 | 필수 여부 | 구현 |
|------|----------|------|
| **X 닫기 버튼** (우상단) | ✅ 필수 | `parent="."` 자식 Button, anchor_top=0, anchor_right=1, offset_left=-60, offset_top=8, 60×48, 텍스트 "✕", font 28pt, white 85% opacity |
| **ESC 단축키** | ✅ 필수 | `_input()` 안에서 `if event.keycode == KEY_ESCAPE` → `_on_close_pressed()` |
| **`closed` 시그널** | ✅ 필수 | 화면 닫힐 때 emit → main.gd가 받음 |
| **Z-order 보장** | ✅ 필수 | `z_index = 100` + `z_as_relative = false` 또는 `layer = 20` |
| **CloseButton (하단)** | 선택 | "닫기" 라벨 버튼, 화면 큰 경우 함께 |

---

## 1. tscn XButton 노드 표준

모든 모달 tscn의 `script = ExtResource(...)` 직후 + `[node name="DimBG" ...]` 전에 추가:

```ini
[node name="BattleScene" type="Control"]
anchor_right = 1.0
anchor_bottom = 1.0
offset_right = 0.0
offset_bottom = 0.0
mouse_filter = 0
script = ExtResource("1_battle")

[node name="XButton" type="Button" parent="."]
anchor_left = 1.0
anchor_top = 0.0
anchor_right = 1.0
anchor_bottom = 0.0
offset_left = -60.0
offset_top = 8.0
offset_right = -8.0
offset_bottom = 56.0
text = "✕"
modulate = Color(1, 1, 1, 0.85)
mouse_default_cursor_shape = 2
theme_override_font_sizes/font_size = 28

[node name="DimBG" type="ColorRect" parent="."]
# ...
```

**CanvasLayer 기반 (decision_dialog, tutorial)** — 동일 패턴, `parent="."`가 CanvasLayer root:

```ini
[node name="DecisionDialog" type="CanvasLayer"]
layer = 10
script = ExtResource("1_dialog")

[node name="XButton" type="Button" parent="."]
# 동일한 anchor/offset
```

---

## 2. 스크립트 핸들러 연결 패턴

**Case A: 기존 `_on_close_pressed`가 있는 모달 (roster/dashboard/succession/buildings/battle)** — XButton도 같은 핸들러에 연결:

```gdscript
@onready var close_button: Button = $MainHBox/RightPanel/RightMargin/RightVBox/CloseButton
@onready var x_button: Button = $XButton  # 추가

func _ready() -> void:
    # ... 다른 초기화 ...
    close_button.pressed.connect(_on_close_pressed)
    if x_button:
        x_button.pressed.connect(_on_close_pressed)  # 같은 핸들러
```

**Case B: close_button이 없는 모달 (decision_dialog)** — `_on_x_pressed` 신규 메서드:

```gdscript
@onready var x_button: Button = $XButton

func _ready() -> void:
    # ... 다른 초기화 ...
    if x_button:
        x_button.pressed.connect(_on_x_pressed)

func _on_x_pressed() -> void:
    # 현재 결정 닫고 큐에 다음 거 표시
    _clear_choices()
    _hide()
    if DecisionQueue.has_any_pending():
        call_deferred("_show_next")
```

**Case C: skip이 이미 있는 모달 (tutorial)** — XButton도 `_on_skip_pressed`에 연결 (skip = 닫기와 동치):

```gdscript
@onready var skip_button: Button = $Card/Margin/VBox/Header/SkipButton
@onready var x_button: Button = $XButton

func _ready() -> void:
    skip_button.pressed.connect(_on_skip_pressed)
    if x_button:
        x_button.pressed.connect(_on_skip_pressed)
```

---

## 3. Z-order 함정 + 해결

**문제**: `MenuToggleButton`이 TutorialOverlay(layer=15)에 가려져 안 보임. 또는 모달이 다른 모달에 가려짐.

**진단법**: 사용자가 "여전히 안 보임"이 2번 이상 반복 → z-order 의심.

**해결 우선순위**:

### 3-1. `z_index = 100` + `z_as_relative = false` (가장 안정적)

```ini
[node name="MenuToggleButton" type="Button" parent="UI"]
# ... anchor ...
z_index = 100
z_as_relative = false
```

`z_as_relative = false`가 핵심 — `true`면 부모 기준 z 순서, `false`면 절대 z 순서. 100이면 모든 CanvasLayer 위에 그림.

### 3-2. 별도 CanvasLayer with `layer = 20`

```ini
[node name="UI" type="CanvasLayer"]
layer = 1
script = ExtResource("1_main")

[node name="MenuToggleButton" type="Button" parent="UI"]
# 일반 z 순서 — layer 1이라 다른 layer에 가려질 수 있음
```

**3-1이 단순하고 안전**. 3-2는 모달 시스템 자체가 복잡해질 때 사용.

### 3-3. tscn 순서 변경 (비추천)

Godot은 `[node ... parent="..."]` 순서대로 그리지만, CanvasLayer의 `layer` 값이 우선이라 순서만으로 z-order 보장 안 됨.

---

## 4. main.tscn 통합 — MenuToggleButton

게임/메뉴 모드 토글용. 우상단 절대 좌표:

```ini
[node name="MenuToggleButton" type="Button" parent="UI"]
anchor_left = 1.0
anchor_top = 0.0
anchor_right = 1.0
anchor_bottom = 0.0
offset_left = -200.0
offset_top = 8.0
offset_right = -8.0
offset_bottom = 56.0
text = "📋 메뉴 (ESC)"
visible = false
modulate = Color(1, 1, 1, 1)
mouse_default_cursor_shape = 2
theme_override_font_sizes/font_size = 16
z_index = 100
z_as_relative = false
```

**너비 200px** — 작은 화면에서 텍스트 잘림 방지. `📋 메뉴 (ESC)` (한글 + 이모지) 위해 충분.

---

## 5. main.gd 토글 로직

```gdscript
@onready var menu_toggle_button: Button = $UI/MenuToggleButton
@onready var button_row: VBoxContainer = $UI/ButtonRow

func _enter_game_mode() -> void:
    if button_row:
        button_row.visible = false
    if menu_toggle_button:
        menu_toggle_button.visible = true
    status_label.text = "Day %d %s ..." % [...]

func _exit_game_mode() -> void:
    if button_row:
        button_row.visible = true
    if menu_toggle_button:
        menu_toggle_button.visible = false
    status_label.text = "Last Banner\n리소스 매니페스트 OK ..."

func _on_menu_toggle_pressed() -> void:
    # button_row.visible == true (메뉴) → 게임으로 / false (게임) → 메뉴로
    if button_row and button_row.visible:
        _enter_game_mode()
    else:
        _exit_game_mode()

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventKey and event.pressed and not event.echo:
        if event.keycode == KEY_M:
            _on_music_toggle_pressed()
            get_viewport().set_input_as_handled()
        if event.keycode == KEY_ESCAPE:
            if GameManager.current_state == GameManager.State.PLAYING or GameManager.current_state == GameManager.State.DECISION_PENDING:
                _on_menu_toggle_pressed()
                get_viewport().set_input_as_handled()
```

**흔한 실수**: `_on_menu_toggle_pressed`의 if/else가 **반대로** 적힘 — `button_row.visible`일 때 `_exit_game_mode` 호출 (메뉴인데 또 메뉴로). 반드시 `button_row.visible → _enter_game_mode` (메뉴 → 게임) / `else → _exit_game_mode` (게임 → 메뉴).

---

## 6. 사용자 반복 피드백 패턴 → 표준화 트리거

**"여전히 X 안 보임" / "여전히 Y 안 됨"** 같은 표현이 **2번 이상** 나오면:
1. **콘솔에 print 진단 추가** (해당 시점에 어디까지 실행됐는지)
2. **동적 검색 폴백** (`get_node_or_null` + 재할당)
3. **Z-order 검토** (CanvasLayer layer, z_index, z_as_relative)
4. **anchor/offset 좌표 검토** (width가 너무 좁지 않은지, 화면 안에 있는지)
5. **@onready 평가 순서 검토** (인스턴스화 순서 race)

이 5단계를 자동화한 헬퍼는 없음 — 매번 손으로 진단. **대신 매번 동일한 진단 print 패턴**을 사용해서 후속 세션이 빠르게 디버깅:

```gdscript
# 표준 진단 print 5종
print("[Main] _on_X_pressed: y=%s" % str(y))                    # 시그널/콜백 도달
print("[Main] 노드 발견: y=%s" % str(get_node_or_null("Y")))    # 노드 존재
print("[Main] y.visible=%s" % str(y.visible))                    # visible 상태
print("[Main] y.size=%s" % str(y.size))                          # 렌더 크기
print("[Main] y.global_position=%s" % str(y.global_position))    # 화면상 위치
```

**4번 진단 후 fix 시도 → 실패 → 한 번 더 fix는 거의 항상 다른 원인** (z-order, parent path, layer). 사용자가 "또 안 됨"이면 z-order 다음 의심.

---

## 7. Last Banner에서 XButton이 추가된 화면 7종

| 화면 | tscn | 스크립트 | XButton 핸들러 |
|------|------|----------|---------------|
| **roster** (용병 명단) | `scenes/roster.tscn` | `scripts/roster.gd` | `_on_close_pressed` |
| **dashboard** (영지 대시보드) | `scenes/manor_dashboard.tscn` | `scripts/dashboard.gd` | `_on_close_pressed` |
| **succession** (왕조/후계자) | `scenes/succession.tscn` | `scripts/succession.gd` | `_on_close_pressed` |
| **buildings** (마을 시설) | `scenes/buildings.tscn` | `scripts/buildings.gd` | `_on_close_pressed` |
| **battle** (전투) | `scenes/battle_scene.tscn` | `scripts/battle.gd` | `_on_close_pressed` |
| **decision_dialog** (결정) | `scenes/decision_dialog.tscn` | `scripts/decision_dialog.gd` | `_on_x_pressed` (close_button 없음) |
| **tutorial** (튜토리얼) | `scenes/tutorial_overlay.tscn` | `scripts/tutorial.gd` | `_on_skip_pressed` |

**7개 모두 동일 tscn 패턴**, 5개는 기존 close_button에 연결, 2개는 별도 메서드 (decision_dialog는 `_on_x_pressed`, tutorial은 `_on_skip_pressed`).
