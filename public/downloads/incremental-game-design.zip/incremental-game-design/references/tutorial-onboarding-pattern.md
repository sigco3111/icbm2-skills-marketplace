# Tutorial Overlay Pattern (첫 진입 4단계 가이드)

증분 게임 / 신규 진입자가 모든 핵심 기능을 자연스럽게 발견하도록 강제하는 오버레이 튜토리얼. 토스트는 "짧은 알림"이지만, 튜토리얼은 "구조화된 단계별 가이드" — 자동 진행 + 결정 큐 + 명단 + 대시보드 같은 4~5개 핵심 기능을 한 번에 노출. Last Banner 5단계 (2026-07-16) 검증.

## 트리거

- "튜토리얼 만들어줘", "첫 진입 가이드", "신규 사용자 안내", "기능 발견을 유도하고 싶어"
- 핵심 기능이 4개 이상인데 사용자가 헤맬 가능성 있음 (대시보드 / 명단 / 결정 큐 / 자동 진행 / 저장)
- 토스트만으로는 한계 — 한 번에 1줄만 보여줌

## 핵심 설계 원칙

1. **자동 진행 ON 기본값 직후에 발동** — 사용자가 자동 진행을 인지한 직후 핵심 기능 4개를 알려야 "자동 진행 중 무슨 일이 일어나는지" 이해 가능.
2. **tutorial_seen 플래그 영속화** — `GameManager`에 `tutorial_seen: bool` 박고 save_state/load_state에 포함. 두 번째 진입부터 안 뜸.
3. **재시청 버튼 제공** — 메뉴 화면에 "튜토리얼 (T)" 버튼. 누르면 `tutorial_seen` 잠시 무효화 + 시작 + 완료 후 복원.
4. **각 단계 7초 자동 진행** — 사용자가 안 읽어도 다음으로 넘어감 (성가시게 안 함).
5. **Space/Enter 다음, ESC 건너뛰기** — 키보드 친화적.

## Godot 4 구현

### GameManager — tutorial_seen 플래그

```gdscript
var tutorial_seen: bool = false  # 저장됨

func save_state() -> Dictionary:
    return {
        "current_state": State.keys()[current_state],
        "save_slot": save_slot,
        "tutorial_seen": tutorial_seen  # ← 추가
    }

func load_state(data: Dictionary) -> void:
    save_slot = data.get("save_slot", "default")
    tutorial_seen = data.get("tutorial_seen", false)  # ← 추가
    # ... 기존 로드 ...
```

### TutorialOverlay 씬 구조

```
TutorialOverlay (CanvasLayer, layer=15) — 최상위 (다른 UI 위)
├── DimBG (ColorRect, alpha 0.5, mouse_filter=0)
└── Card (PanelContainer, anchor 0.5 + offset ±320×±120)
    └── Margin (24/20/24/20)
        └── VBox (separation 12)
            ├── Header (HBox)
            │   ├── IconLabel (font 24)
            │   ├── TitleLabel (size_flags 3, font 22)
            │   └── SkipButton (커스텀 80×32, "건너뛰기")
            ├── HSep
            ├── MessageLabel (autowrap, custom_minimum_size y=80, font 18)
            ├── ProgressHint (modulate 회색, font 13)
            └── ButtonRow (HBox)
                ├── Spacer (size_flags 3)
                └── NextButton (custom 120×40, "다음 →")
```

**layer=15** — 다른 모든 UI (Toast layer=1, DecisionDialog layer=10, Roster/Dashboard 전체화면)보다 위. 튜토리얼 도중 다른 결정 다이얼로그 뜨는 일 없도록.

### tutorial.gd — 4단계 정의 + 상태머신

```gdscript
const STEPS := [
    {
        "icon": "🤖",
        "title": "자동 진행",
        "message": "자동 진행이 켜졌습니다.\n게임이 알아서 시간이 흐르고 자원이 변합니다.\n\n당신이 결정할 일만 모달로 알려드립니다.",
        "hint": "(P 키로 자동 진행 일시정지/재개)"
    },
    {
        "icon": "❓",
        "title": "결정 큐",
        "message": "약탈자 출몰, 식량 위기, 외교 요청 등\n중요한 결정을 내려야 할 때 모달이 자동으로 뜹니다.\n\n선택지에 따라 자원/인구/명성이 변합니다.",
        "hint": "(HIGH/CRITICAL 결정은 게임이 멈춥니다)"
    },
    {
        "icon": "📊",
        "title": "영지 대시보드",
        "message": "D 키를 눌러 영지 대시보드를 열어보세요.\n\n금/식량/인구 변동, 7일 차트, 최근 사건,\n업적을 한눈에 확인할 수 있습니다.",
        "hint": "(D 키)"
    },
    {
        "icon": "⚔️",
        "title": "용병 명단",
        "message": "R 키로 용병 명단을 확인하세요.\n\n이름, 직업, 티어, 충성도, 부상 회복 상태를\n확인하고 전략적으로 관리할 수 있습니다.",
        "hint": "(R 키)"
    }
]

var _current_step: int = 0
var _active: bool = false
var _auto_advance_timer: SceneTreeTimer = null

func start_tutorial() -> void:
    if _active: return
    if GameManager.tutorial_seen: return  # 이미 봤으면 무시
    _current_step = 0
    _active = true
    visible = true
    _show_step(_current_step)
    _schedule_auto_advance(7.0)

func finish_tutorial() -> void:
    _active = false
    visible = false
    GameManager.tutorial_seen = true
    tutorial_finished.emit()

func _on_next_pressed() -> void:
    _current_step += 1
    if _current_step >= STEPS.size():
        finish_tutorial()
        return
    _show_step(_current_step)
    _schedule_auto_advance(7.0)

func _schedule_auto_advance(seconds: float) -> void:
    if _auto_advance_timer != null and _auto_advance_timer.timeout.is_connected(_on_auto_advance):
        _auto_advance_timer.timeout.disconnect(_on_auto_advance)
    _auto_advance_timer = get_tree().create_timer(seconds)
    _auto_advance_timer.timeout.connect(_on_auto_advance)

func _on_auto_advance() -> void:
    if _active:
        _on_next_pressed()

func _input(event: InputEvent) -> void:
    if not _active: return
    if event is InputEventKey and event.pressed and not event.echo:
        if event.keycode == KEY_SPACE or event.keycode == KEY_ENTER:
            _on_next_pressed()
            get_viewport().set_input_as_handled()
        elif event.keycode == KEY_ESCAPE:
            _on_skip_pressed()
            get_viewport().set_input_as_handled()
```

**자동 진행 타이머 분리**: 매 단계마다 새 `create_timer(7)` → 이전 타이머 disconnect. 누적 방지.

### main.gd — 새 게임 직후 + 재시청 버튼

```gdscript
@onready var tutorial_screen: CanvasLayer = $TutorialOverlay

func _on_start_pressed() -> void:
    GameManager.start_new_game("default")
    # ... 기존 초기화 ...
    # 새 게임 + tutorial_seen=False이면 튜토리얼 자동 시작
    if not GameManager.tutorial_seen and tutorial_screen.has_method("start_tutorial"):
        await get_tree().create_timer(0.8).timeout  # 토스트 + UI 안정화 후
        tutorial_screen.start_tutorial()

# 재시청 버튼
func _on_tutorial_pressed() -> void:
    if tutorial_screen.has_method("start_tutorial"):
        # tutorial_seen 잠시 무효화 → 다시 시작 → 완료 후 복원
        var prev_seen: bool = GameManager.tutorial_seen
        GameManager.tutorial_seen = false
        tutorial_screen.start_tutorial()
        await tutorial_screen.tutorial_finished  # finish_tutorial emit 대기
        GameManager.tutorial_seen = prev_seen  # 원래 상태로 복원
```

**0.8초 딜레이 이유**: 토스트 페이드인 + 버튼 활성화 + 씬 정착 시간. 즉시 띄우면 토스트와 튜토리얼 카드가 겹쳐 보임.

**재시청 후 복원**: 강제로 `tutorial_seen = false` 한 다음 다시 `true`로 만들어야 두 번째 진입 시 또 안 뜸. `prev_seen` 변수로 원래 값 기억.

## LB_VERIFY 검증

```gdscript
print("[1.7] 튜토리얼 화면 검증")
var tutorial: Node = get_tree().current_scene.find_child("TutorialOverlay", true, false)
if tutorial == null:
    print("  ✗ FAIL — TutorialOverlay 노드 미발견")
else:
    assert(not GameManager.tutorial_seen, "첫 신규게임 후 tutorial_seen=False여야 함")
    if tutorial.has_method("start_tutorial"):
        tutorial.start_tutorial()
        await get_tree().process_frame
        assert(tutorial.visible)
        # 4단계 전이
        for i in range(4):
            tutorial._on_next_pressed()
            await get_tree().process_frame
        assert(not tutorial.visible, "4단계 후 visible=false")
        assert(GameManager.tutorial_seen, "tutorial_seen=True")
        # 두 번째 호출 시 무시
        tutorial.start_tutorial()
        await get_tree().process_frame
        assert(not tutorial.visible, "두 번째 호출 무시")
        print("  ✓ 튜토리얼 검증 통과")
```

## 다른 엔진 차용

### React + TypeScript

```tsx
const STEPS = [
  { icon: "🤖", title: "자동 진행", message: "...", hint: "(P 키)" },
  // ...
]

function TutorialOverlay() {
  const [step, setStep] = useState(0)
  const [visible, setVisible] = useState(false)
  const gameStore = useGameStore()

  useEffect(() => {
    if (!gameStore.tutorial_seen && gameStore.world_initialized) {
      setStep(0)
      setVisible(true)
    }
  }, [gameStore.world_initialized])

  const next = () => {
    if (step + 1 >= STEPS.length) {
      setVisible(false)
      gameStore.mark_tutorial_seen()
    } else {
      setStep(step + 1)
    }
  }

  if (!visible) return null
  return (
    <div className="tutorial-overlay">
      <h2>{STEPS[step].icon} {STEPS[step].title} ({step + 1}/{STEPS.length})</h2>
      <p>{STEPS[step].message}</p>
      <small>{STEPS[step].hint}</small>
      <button onClick={next}>{step === STEPS.length - 1 ? "시작!" : "다음 →"}</button>
      <button onClick={() => { setVisible(false); gameStore.mark_tutorial_seen() }}>
        건너뛰기
      </button>
    </div>
  )
}
```

## 핵심 Pitfalls

### 1. tutorial_seen 저장 누락
`GameManager.save_state()`에 박지 않으면 매번 진입 시 튜토리얼 다시 뜸. **검증**: LB_VERIFY에 두 번째 `start_tutorial()` 호출 → `not visible` 확인.

### 2. 재시청 후 tutorial_seen 복원 안 함
강제 `false`로 시작 → `finish_tutorial()`에서 `true`로 변경됨 → 다음 진입에도 `true` 유지되니 OK지만, 만약 재시청 시점이 첫 진입이면? `prev_seen = false`였고 복원 시 `false`로 다시 설정 → 다음 진입에 또 튜토리얼. **확인**: `prev_seen` 패턴 정확히 사용.

### 3. 자동 진행 타이머 누적
`_schedule_auto_advance(7)`이 disconnect 없이 매번 호출되면 `_auto_advance_timer` 변수가 새 타이머 참조로 갱신되지만 **이전 타이머는 그대로 살아있음** (Godot SceneTreeTimer). 누적 → 7초 후 여러 번 `_on_auto_advance` 호출 → 단계 건너뜀.
**해결**: 호출 직전 `if _auto_advance_timer != null and _auto_advance_timer.timeout.is_connected(_on_auto_advance): _auto_advance_timer.timeout.disconnect(_on_auto_advance)`.

### 4. 토스트와 튜토리얼 동시 표시
새 게임 시작 시 토스트("🤖 자동 진행 시작") + 튜토리얼 둘 다 띄우면 시각 혼잡. **해결**: 튜토리얼을 0.8초 딜레이 후 시작 → 토스트가 거의 사라질 때쯤 튜토리얼 등장.

### 5. 결정 다이얼로그와 튜토리얼 충돌
튜토리얼 진행 중에 결정 큐에 HIGH/CRITICAL 사건이 push되면 다이얼로그가 튜토리얼 위에 뜸 (둘 다 CanvasLayer). **확인**: `DecisionDialog.layer=10` vs `TutorialOverlay.layer=15` → 튜토리얼이 위. **문제**: 튜토리얼 메시지가 결정 다이얼로그에 가려짐.
**해결**: 튜토리얼 활성 중 `_process`에서 DecisionQueue 큐 확인 → CRITICAL 있으면 튜토리얼 일시정지 (`_active = false`) 후 결정 처리 → 결정 후 `_active = true; visible = true` 복귀. (현재 Last Banner는 미구현 — 일반적으로 튜토리얼 4단계 도는데 30초 미만이라 충돌 거의 안 일어남.)

### 6. TutorialOverlay 노드가 autoload 아닌 인스턴스인 이유
TutorialOverlay는 SceneTree 직접 인스턴스 (main.tscn에 박음). autoload로 만들면 `tutorial_seen` 영속화 전에도 매 세션마다 튜토리얼 시작 → 사용자가 짜증. **인스턴스 + GameManager 플래그** 조합이 정답.

### 7. layer 숫자 충돌
Godot CanvasLayer.layer: 1 (UI) / 10 (DecisionDialog) / 15 (TutorialOverlay). 숫자 클수록 위. Toast는 UI 내부 라벨이라 layer 안 씀. 새로운 전경 화면 추가 시 12~14 권장 (10 < x < 15 사이).

## Last Banner 검증 결과

- 새 게임 → tutorial_seen=False → 0.8초 딜레이 → 4단계 자동 진행 (각 7초)
- Space/Enter로 다음, ESC로 건너뛰기, "건너뛰기" 버튼도 OK
- 완료 후 tutorial_seen=True → 다음 진입에 안 뜸
- "튜토리얼 (T)" 버튼으로 재시청 가능
- 4단계 메시지: 자동 진행 → 결정 큐 → 대시보드 → 명단 (각 단계마다 키 힌트)

→ 사용자가 첫 진입 시 4개 핵심 기능을 자동 인지. 명단/대시보드를 헤매지 않음.

## 다음 확장

- **인터랙티브 튜토리얼** — "이 버튼을 눌러보세요" 단계별 가이드 (실제 클릭 검증)
- **튜토리얼 스킵 후에도 도움말** — 명단 화면 헤더에 "?" 아이콘 → 단축키 안내 팝업
- **다국어 튜토리얼** — STEPS 배열을 JSON으로 분리 + locale별 .json
- **진행률 저장** — 사용자가 3단계에서 끄면 다음 진입 시 3단계부터 시작 (`tutorial_step` 저장)
- **튜토리얼 이벤트 연동** — 특정 액션(예: 첫 용병 합류) 시 해당 단계로 점프