---
name: incremental-game-design
description: Build incremental / 4X / strategy / management games where the world runs on its own and the player re-enters to make decisions ("위임 진행 + 재진입" pattern). Covers time-step simulation, decision queue + check-point DB, optional background progression, plus the Godot-4 + Vercel Web Export deployment pattern that Last Banner uses. Triggers on "incremental game / 로그라이크 / 4X / tycoon / kingdom management / 용병단 운영 / 위임 진행 / idle progression / Godot + web 자동 게임".
version: 0.1.0
author: icbm2
metadata:
  hermes:
    tags: [Game, Godot, Incremental, Idle, Auto-progress, Re-entry, Web-Export, Vercel]
trigger: "수동/능동 진행이 아니라 위임 진행 — 자동 진행 + 재진입 — 을 핵심 패턴으로 가진 게임을 만들 때. Last Banner (용병단 로그라이크), Six Crowns (6각 hex 왕국 경영), Iron Heralds (대규모 hex RTS), Forge & Crown, Tavern Tales 같은 컨셉 그리고 'Godot 게임을 Vercel에 자동 web 배포', 'god WASM 30MB 자동진행 백그라운드' 같은 요청에 활성화."
last_updated: 2026-07-15
status: born-from-last-banner-planning
---

# Incremental / Auto-Progress Game Design (위임 진행 + 재진입 클래스)

**세계는 알아서 돌아가고, 플레이어는 가끔 들어와 결정한다.** 이 클래스의 디자인 워크플로.

---

## 핵심 디자인 원칙 (sigco3111님 1순위, 2026-07-15)

> *"내가 중요하게 생각하는 것은 게임의 자동진행이야. 사용자가 위임하면 자동으로 진행되고, 언제든지 사용자가 게임에 다시 진입할 수 있도록 해야함."*

이 한 문장은 **모든 incremental / strategy / management 게임 설계의 1순위 제약**으로 작동. 어떤 컨셉이든 이 원칙을 깨면 안 됨.

### 5가지 비협상 요구사항

1. **시간 단계 모델** — 게임 시간이 사용자 입력과 분리됨. 1 step = 게임 내 일정 시간 (예: 30초 = 게임 1일).
2. **백그라운드 자동 진행** — 사용자가 보고 있지 않아도 세계는 돌아감. 자원 누적, NPC 행동, 사건 발생.
3. **결정 큐 (pending decisions)** — 사용자 결정이 필요한 사건은 큐에 쌓임. 진입 시 일괄 처리.
4. **체크포인트 자동 저장** — 매 step 후 게임 상태 스냅샷. 새 세션도 같은 체크포인트에서 재개.
5. **세션 무관 진입** — "어디서든" — PC, 모바일, 재시작 후에도 진행 이어짐. DB or IndexedDB만으로 충분.

---

## 기본 아키텍처 (엔진 무관)

```
┌─────────────────────────────────────────────────┐
│  Game World Simulation                           │
│                                                  │
│   Tick (30s) ──► Tick (60s) ──► Tick (90s) ──►  │
│      │              │              │              │
│   advance state,  check decisions,  emit events  │
│                                                  │
│   ┌──────────┐   ┌────────────┐   ┌─────────┐   │
│   │ Time-step │   │ Decision   │   │ Event   │   │
│   │ loop      │   │ Queue      │   │ log     │   │
│   └──────────┘   └────────────┘   └─────────┘   │
│        │                │               │         │
│        ▼                ▼               ▼         │
│   ┌──────────────────────────────────────────┐    │
│   │  Checkpoint DB (SQLite / JSON snapshot)  │    │
│   │  게임 상태, 결정 큐, 이벤트 로그        │    │
│   └──────────────────────────────────────────┘    │
└─────────────────────────────────────────────────┘
```

### 4가지 핵심 모듈

| 모듈 | 책임 | 구현 포인트 |
|------|------|------------|
| **Time-step loop** | 게임 시간 진행 | `while(auto_running): advance_step()` (Godot: `Timer`/`_process`, Web: `setInterval`) |
| **State store** | 모든 게임 상태 (영지, 용병, 자원, 관계) | SQLite or JSON; 모든 변경은 트랜잭션 |
| **Decision queue** | 사용자 결정 필요 사건 버퍼 | `events` 테이블: `[id, type, payload, created_at, resolved_at]` |
| **Snapshot system** | 매 tick 후 자동 저장 | DB row ID + last_saved_at; 새 세션 = 마지막 체크포인트 로드 |

### 4가지 핵심 이벤트 (모든 incremental 게임 공통)

| 이벤트 | 사용자 결정 | 자동 처리 가능 |
|--------|------------|---------------|
| **Milestone** (한 영지 풍작) | 수용/축제/투자 | ✅ 수락 가능 |
| **Crisis** (적 약탈 보고) | 즉시 출전 / 방어 / 배상 | ❌ 사용자만 |
| **Opportunity** (용병 지원 요청) | 모집 / 거절 | ✅ 자동 거절 가능 |
| **Discovery** (숨겨진 장소 발견) | 탐사 / 무시 | ✅ 자동 무시 가능 |

→ 4가지 enum = UI 4개 화면 (결정 큐 진입 시 자동 분류 표시).

---

## Godot 4 + Vercel Web Export — 표준 스택

Godot이 1순위 결정되면 (2026-07-15), 거의 모든 컨셉을 이렇게 함:

### 왜 Godot + Web Export인가

- **사용자 접근성** — 모바일/외부에서도 진입 (Vercel URL)
- **단일 코드베이스** — Mac/Windows/Linux/Web export 모두
- **자동 진행 백그라운드** — 브라우저 탭이 살아있을 때 (Service Worker로 백그라운드 tab도 부분 작동)
- **저장 모델 통일** — Web은 IndexedDB, Desktop은 user:// 폴더 → 같은 JSON 스키마로 export/import

### ⚠️ Vercel Web Export — 두 가지 함정 (반드시 회피)

1. **WASM SharedArrayBuffer 헤더**: Godot 4는 멀티스레딩 위해 SharedArrayBuffer 사용. Vercel은 기본 정적 호스팅 = COOP/COEP 헤더 없음 → WASM 로드 실패. **해결**: `vercel.json`에 COOP/COEP 헤더 1줄 추가 (templates/vercel.json 참조).
2. **첫 로드 30~60MB**: 모바일 4G에서 10~30초 로딩. 해결책 없음. **허용**: 진입 화면에 "로딩" 인디케이터 + 스플래시.

### COOP/COEP 헤더 (vercel.json) — 일종의 행운상수 같은 것, 신봉하지 말 것

- 헤더를 안 넣어도 Godot Web export 일부 기능은 작동 (단일 스레드 모드). 다만 멀티스레딩 + SIMD + SharedArrayBuffer 기반 기능 (예: Godot Physics 3D 멀티스레드 모드) 사용 불가.
- 4.x 본빌드에서는 헤더 필수. 현재 표준에서는 권장 — 게임이 단순할수록 헤더 없이도 OK일 수 있지만, 헤더 있는 게 정답.

자세한 빌드/배포 절차는 `references/godot-web-export-to-vercel.md` 참조.

---

## 워크플로 (4단계)

### 1단계: 컨셉 브레인스토밍 (필수)

먼저 컨셉을 좁힘. **8개 컨셉 후보**가 2026-07-15에 한 번에 생성됨 — 대부분 game-assets-pool 자산을 보고 자연스럽게 떠오른 것들:

| 코드 | 컨셉 | 핵심 자산 | 엔진 적합도 |
|------|------|----------|------------|
| **Last Banner** | 용병단 로그라이크 전략 | KayKit Adventurers + Wesnoth units | Godot 4 |
| **Six Crowns** | 6각 hex 왕국 경영 | KayKit Hexagon + Wesnoth units | Godot 4 (hexgrid 플러그인) |
| **Iron Heralds** | hex 대규모 RTS | Wesnoth units + FreeCiv flags | Godot 4 / Bevy |
| **Forge & Crown** | 대장간 운영 + 인물 성장 | KayKit Adventurers/Skeletons | Godot 4 |
| **Tavern Tales** | 식당 경영 cozy | KayKit Restaurant | Godot 4 |
| **Coastal Republic** | 도시국가 4X | FreeCiv tiles + KayKit City | Godot 4 |
| **Caravans of Veloren** | 보크셀 caravan 호위 | Veloren voxels | Godot 4 |
| **Bell, Book, Crown** | 픽션 정치 비주얼노벨 | Wesnoth portraits | Ren'Py / Godot 4 |

### 2단계: 엔진 결정 (Godot vs Web-native)

- **3D KayKit 캐릭터 살림 + PC/Mac/Web 모두 원함** → Godot 4 + Web Export
- **모바일 진입 최우선 + 2D만으로 충분** → 순수 Web (React + TS)
- **엔진 결정 보류, 코어부터** → Godot 4 (자동 진행 + 체크포인트 모두 동일)

### 3단계: 풀 매니페스트 + 프로젝트 부트스트랩

기존 `game-assets-pool` 저장소를 submodule 또는 직접 readlink로 게임 프로젝트에 매핑:

```bash
~/work/<game-name>/
├── assets/
│   ├── units/human-loyalists/     (symlink → ~/work/game-assets-pool/extracted/wesnoth/units/human-loyalists/)
│   ├── portraits/humans/          (symlink → ...portraits/humans/)
│   ├── heroes/                    (KayKit Adventurers)
│   ├── tiles/                     (KayKit Hexagon)
│   ├── icons/                     (Nieobie)
│   ├── music/                     (Wesnoth music)
│   └── sounds/                    (Wesnoth sounds)
├── src/
│   ├── autoload/
│   │   ├── game_state.gd          (체크포인트 DB)
│   │   ├── tick_scheduler.gd      (자동 진행)
│   │   └── decision_queue.gd      (결정 큐)
│   ├── systems/
│   │   ├── time.gd
│   │   ├── mercenary.gd
│   │   ├── contract.gd
│   │   ├── economy.gd
│   │   └── event.gd
│   ├── scenes/
│   │   ├── main.tscn
│   │   ├── dashboard.tscn         (진입 화면 — 결정 큐 + 요약)
│   │   ├── map.tscn               (전장)
│   │   ├── camp.tscn              (영지)
│   │   └── dialogue.tscn          (이벤트 다이얼로그)
│   └── ui/
│       └── (Wesnoth 픽토그램 + Nieobie icons)
└── export/
    ├── web/                       (Vercel 배포용)
    └── desktop/                   (Mac/Windows 빌드)
```

### 4단계: 빌드 + Vercel 배포

- `godot --headless --export-release "Web" export/web/index.html`
- `vercel --prod` (프로젝트 루트 = `export/web/`)
- 1차 빌드 후 mobile Safari/Chrome에서 즉시 검증

---

## 검증된 함정 (Pitfalls)

1. **자동 진행 = 사용자에게 "느린" 게임으로 느껴질 수 있음** — 진입 화면에서 "지난 N일 동안 일어난 일" 요약을 보여줘야 시간 점프의 부재를 보완.
2. **체크포인트 DB schema 변경 시 마이그레이션** — 한 번 출시 후 스키마 바꿀 때마다 마이그레이션 코드 작성. v0에서는 schema versioning (`schema_version` row) 미리 박아둘 것.
3. **Web 자동 진행 + 백그라운드 tab** — 브라우저는 백그라운드 tab에서 `setInterval`를 1초 throttle 함. Service Worker의 periodic sync는 5분 단위 + 권한 요청 필요. **해결**: Web에서는 자동 진행은 foreground only, 백그라운드는 desktop 빌드만.
4. **Godot WASM SharedArrayBuffer + Vercel** — 위에서 다룸. 헤더 없이 배포하면 런타임 에러 → "vercel.json 파일 빠뜨림"이 1순위 디버깅 포인트.
5. **체크포인트 DB 충돌** — 두 탭에서 동시에 같은 game에 진입하면? 해결: game_id 별로 한 탭이 lock을 들고, 나머지는 "다른 세션 진행 중" 메시지. (Figma식 optimistic lock)
6. **결정 큐 무한 누적** — 사용자가 한 달 미진입 시 결정 큐 1000+ 사건. 해결: 우선순위 정렬 + 자동 처리되는 enum (위 4가지 enum 표 참조).
7. **시간 단계 = 게임 일수 <-> 실시간 동기화** — 단순한 변환 ("1초 = 1일")만 하면 호흡이 깨짐. 실 게임 시간 (예: 24 게임일 = 1 real-life day) 권장.

---

## 📁 첨부 파일

- `references/godot-web-export-to-vercel.md` — Godot 4 Web Export → Vercel 배포 전체 워크플로 + COOP/COEP 함정 + 모바일 테스트 절차
- `references/turn-based-auto-progression-pattern.md` — 시간 단계 + 결정 큐 + 자동 저장 architecture (Godot/Web 공통)
- `templates/vercel.json` — Godot Web Export용 COOP/COEP 헤더 박은 vercel.json (그대로 `export/web/`에 복사)

---

## 🔗 관련 스킬

- `toss-trader-dev` — 토스증권 Open API 기반 Next.js 투자 어시스턴트 (자동 진행 DB 패턴 차용)
- `text-game-builder` — LLM이 GM인 텍스트 게임 (다른 클래스 — 본 스킬은 "세계가 알아서 진행, 사용자는 결정만")
- `python-oss-bootstrap` — repo 부트스트랩 패턴
- `vercel` — Vercel CLI 일반 사용법
- `game-assets-pool` — 본 스킬로 만들 게임들이 모두 끌어다 쓸 풀
