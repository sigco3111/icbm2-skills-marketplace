---
name: incremental-game-design
description: Build incremental / 4X / strategy / management games where the world runs on its own and the player re-enters to make decisions ("위임 진행 + 재진입" pattern). Covers time-step simulation, decision queue + check-point DB, optional background progression, plus the Godot-4 + Vercel Web Export deployment pattern that Last Banner uses. Triggers on "incremental game / 로그라이크 / 4X / tycoon / kingdom management / 용병단 운영 / 위임 진행 / idle progression / Godot + web 자동 게임".
version: 0.4.0
author: icbm2
metadata:
  hermes:
    tags: [Game, Godot, Incremental, Idle, Auto-progress, Re-entry, Web-Export, Vercel]
trigger: "수동/능동 진행이 아니라 위임 진행 — 자동 진행 + 재진입 — 을 핵심 패턴으로 가진 게임을 만들 때. Last Banner (용병단 로그라이크), Six Crowns (6각 hex 왕국 경영), Iron Heralds (대규모 hex RTS), Forge & Crown, Tavern Tales 같은 컨셉 그리고 'Godot 게임을 Vercel에 자동 web 배포', 'god WASM 30MB 자동진행 백그라운드' 같은 요청에 활성화."
last_updated: 2026-07-16
status: born-from-last-banner-planning
---

# Incremental / Auto-Progress Game Design (위임 진행 + 재진입 클래스)

**세계는 알아서 돌아가고, 플레이어는 가끔 들어와 결정한다.** 이 클래스의 디자인 워크플로.

---

## 핵심 디자인 원칙 (sigco3111님 1순위, 2026-07-15)

> *"내가 중요하게 생각하는 것은 게임의 자동진행이야. 사용자가 위임하면 자동으로 진행되고, 언제든지 사용자가 게임에 다시 진입할 수 있도록 해야함."*

이 한 문장은 **모든 incremental / strategy / management 게임 설계의 1순위 제약**으로 작동. 어떤 컨셉이든 이 원칙을 깨면 안 됨.

### 5가지 비협상 요구사항

1. **시간 단계 모델** — 게임 시간이 사용자 입력과 분리됨. 1 step = 게임 내 일정 시간 (예: 30초 = 게임 1일).
2. **백그라운드 자동 진행** — 사용자가 보고 있지 않아도 세계는 돌아감. 자원 누적, NPC 행동, 사건 발생.
3. **결정 큐 (pending decisions)** — 사용자 결정이 필요한 사건은 큐에 쌓임. 진입 시 일괄 처리.
4. **체크포인트 자동 저장** — 매 step 후 게임 상태 스냅샷. 새 세션도 같은 체크포인트에서 재개.
5. **세션 무관 진입** — "어디서든" — PC, 모바일, 재시작 후에도 진행 이어짐. DB or IndexedDB만으로 충분.

### 6번째 원칙: 자동 진행은 기본 ON (2026-07-16, Last Banner 4단계 검증)

사용자가 매번 자동 진행을 켤 필요 없게 — **새 게임 시작 = 자동 진행 ON 기본값**. 진입 마찰을 0에 가깝게.

**구현 (Godot 4)**:
```gdscript
# GameManager (autoload)
func start_new_game(slot: String = "default") -> void:
    save_slot = slot
    SaveManager.new_game(slot)
    TimeManager.enable_auto_progress()  # ← 새 게임 = 자동 진행 켜짐
    _transition(State.PLAYING)
    game_started.emit()
```

```gdscript
# TimeManager (autoload)
func enable_auto_progress() -> void:
    if not auto_progress_enabled:
        auto_progress_enabled = true
        print("[TimeManager] 자동 진행 켜짐 (기본값)")
```

**토스트로 알리기**: 화면 하단에 "🤖 자동 진행 시작 — 결정이 필요하면 모달이 뜹니다 (P: 일시정지)" 페이드 인/아웃. 사용자가 자동 진행이 ON인 걸 인지.

```gdscript
# main.gd
func _show_toast(message: String, duration: float = 5.0) -> void:
    if toast_label == null: return
    toast_label.text = message
    if _toast_tween != null and _toast_tween.is_valid():
        _toast_tween.kill()
    _toast_tween = create_tween()
    _toast_tween.tween_property(toast_label, "modulate:a", 1.0, 0.3)   # 페이드 인
    _toast_tween.tween_interval(duration)                              # 5초 유지
    _toast_tween.tween_property(toast_label, "modulate:a", 0.0, 0.5)   # 페이드 아웃
```

```ini
# main.tscn
[node name="Toast" type="Label" parent="UI"]
anchor_left = 0.5
anchor_top = 0.92
anchor_right = 0.5
anchor_bottom = 0.92
offset_left = -300.0
offset_top = -40.0
offset_right = 300.0
offset_bottom = 0.0
modulate = Color(1, 1, 1, 0)  # 처음엔 투명
mouse_filter = 2
```

**로드 시 자동 진행 상태 기억**: `TimeManager.save_state()` / `load_state()`에 `auto_progress_enabled` 박혀 있어야. 사용자가 명시적으로 끈 상태로 저장 → 다음 진입에도 그대로 OFF.

**Why**: 진입 마찰이 0이면 사용자가 "그냥 보는" 모드로도 즐김. 매번 토글 누를 필요 없음. 1차 진입 → 자동 흐름 → 결정 처리 → 종료 패턴이 자연스러워짐. Last Banner에서 검증됨.

### 7번째 원칙: 첫 진입 4단계 튜토리얼 (2026-07-16, Last Banner 5단계 검증)

토스트는 1줄 알림이지만 핵심 기능 4개 (자동 진행 / 결정 큐 / 대시보드 / 명단)를 한 번에 노출하기엔 부족. **새 게임 직후 4단계 튜토리얼 오버레이** 자동 실행 + `tutorial_seen` 플래그로 재실행 방지 + 메뉴에서 "튜토리얼 (T)" 버튼으로 재시청.

**튜토리얼과 토스트의 관계**: 토스트 = 즉시 알림 (5초, 단발성) / 튜토리얼 = 구조화된 가이드 (4단계, 사용자 주도 진행). 둘 다 필요. 토스트로 자동 진행 인지 → 튜토리얼로 4개 핵심 기능 안내.

자세한 구현 + layer 충돌 회피 + LB_VERIFY 절차: `references/tutorial-onboarding-pattern.md`.

자세한 토스트 패턴 + GameManager 연동: `references/auto-progress-onboarding-pattern.md`.

---

## 기본 아키텍처 (엔진 무관)

```
┌─────────────────────────────────────────────────┐
│  Game World Simulation                           │
│                                                  │
│   Tick (30s) ──► Tick (60s) ──► Tick (90s) ──►  │
│      │              │              │              │
│   advance state,  check decisions,  emit events  │
│                                                  │
│   ┌──────────┐   ┌────────────┐   ┌─────────┐   │
│   │ Time-step │   │ Decision   │   │ Event   │   │
│   │ loop      │   │ Queue      │   │ log     │   │
│   └──────────┘   └────────────┘   └─────────┘   │
│        │                │               │         │
│        ▼                ▼               ▼         │
│   ┌──────────────────────────────────────────┐    │
│   │  Checkpoint DB (SQLite / JSON snapshot)  │    │
│   │  게임 상태, 결정 큐, 이벤트 로그        │    │
│   └──────────────────────────────────────────┘    │
└─────────────────────────────────────────────────┘
```

### 4가지 핵심 모듈

| 모듈 | 책임 | 구현 포인트 |
|------|------|------------|
| **Time-step loop** | 게임 시간 진행 | `while(auto_running): advance_step()` (Godot: `Timer`/`_process`, Web: `setInterval`) |
| **State store** | 모든 게임 상태 (영지, 용병, 자원, 관계) | SQLite or JSON; 모든 변경은 트랜잭션 |
| **Decision queue** | 사용자 결정 필요 사건 버퍼 | `events` 테이블: `[id, type, payload, created_at, resolved_at]` |
| **Snapshot system** | 매 tick 후 자동 저장 | DB row ID + last_saved_at; 새 세션 = 마지막 체크포인트 로드 |

### 4가지 핵심 이벤트 (모든 incremental 게임 공통)

| 이벤트 | 사용자 결정 | 자동 처리 가능 |
|--------|------------|---------------|
| **Milestone** (한 영지 풍작) | 수용/축제/투자 | ✅ 수락 가능 |
| **Crisis** (적 약탈 보고) | 즉시 출전 / 방어 / 배상 | ❌ 사용자만 |
| **Opportunity** (용병 지원 요청) | 모집 / 거절 | ✅ 자동 거절 가능 |
| **Discovery** (숨겨진 장소 발견) | 탐사 / 무시 | ✅ 자동 무시 가능 |

→ 4가지 enum = UI 4개 화면 (결정 큐 진입 시 자동 분류 표시).

---

## Godot 4 + Vercel Web Export — 표준 스택

Godot이 1순위 결정되면 (2026-07-15), 거의 모든 컨셉을 이렇게 함:

### 왜 Godot + Web Export인가

- **사용자 접근성** — 모바일/외부에서도 진입 (Vercel URL)
- **단일 코드베이스** — Mac/Windows/Linux/Web export 모두
- **자동 진행 백그라운드** — 브라우저 탭이 살아있을 때 (Service Worker로 백그라운드 tab도 부분 작동)
- **저장 모델 통일** — Web은 IndexedDB, Desktop은 user:// 폴더 → 같은 JSON 스키마로 export/import

### ⚠️ Vercel Web Export — 두 가지 함정 (반드시 회피)

1. **WASM SharedArrayBuffer 헤더**: Godot 4는 멀티스레딩 위해 SharedArrayBuffer 사용. Vercel은 기본 정적 호스팅 = COOP/COEP 헤더 없음 → WASM 로드 실패. **해결**: `vercel.json`에 COOP/COEP 헤더 1줄 추가 (templates/vercel.json 참조).
2. **첫 로드 30~60MB**: 모바일 4G에서 10~30초 로딩. 해결책 없음. **허용**: 진입 화면에 "로딩" 인디케이터 + 스플래시.

### COOP/COEP 헤더 (vercel.json) — 일종의 행운상수 같은 것, 신봉하지 말 것

- 헤더를 안 넣어도 Godot Web export 일부 기능은 작동 (단일 스레드 모드). 다만 멀티스레딩 + SIMD + SharedArrayBuffer 기반 기능 (예: Godot Physics 3D 멀티스레드 모드) 사용 불가.
- 4.x 본빌드에서는 헤더 필수. 현재 표준에서는 권장 — 게임이 단순할수록 헤더 없이도 OK일 수 있지만, 헤더 있는 게 정답.

자세한 빌드/배포 절차는 `references/godot-web-export-to-vercel.md` 참조.

---

## 워크플로 (4단계)

### 1단계: 컨셉 브레인스토밍 (필수)

먼저 컨셉을 좁힘. **8개 컨셉 후보**가 2026-07-15에 한 번에 생성됨 — 대부분 game-assets-pool 자산을 보고 자연스럽게 떠오른 것들:

| 코드 | 컨셉 | 핵심 자산 | 엔진 적합도 |
|------|------|----------|------------|
| **Last Banner** | 용병단 로그라이크 전략 | KayKit Adventurers + Wesnoth units | Godot 4 |
| **Six Crowns** | 6각 hex 왕국 경영 | KayKit Hexagon + Wesnoth units | Godot 4 (hexgrid 플러그인) |
| **Iron Heralds** | hex 대규모 RTS | Wesnoth units + FreeCiv flags | Godot 4 / Bevy |
| **Forge & Crown** | 대장간 운영 + 인물 성장 | KayKit Adventurers/Skeletons | Godot 4 |
| **Tavern Tales** | 식당 경영 cozy | KayKit Restaurant | Godot 4 |
| **Coastal Republic** | 도시국가 4X | FreeCiv tiles + KayKit City | Godot 4 |
| **Caravans of Veloren** | 보크셀 caravan 호위 | Veloren voxels | Godot 4 |
| **Bell, Book, Crown** | 픽션 정치 비주얼노벨 | Wesnoth portraits | Ren'Py / Godot 4 |

### 2단계: 엔진 결정 (Godot vs Web-native)

- **3D KayKit 캐릭터 살림 + PC/Mac/Web 모두 원함** → Godot 4 + Web Export
- **모바일 진입 최우선 + 2D만으로 충분** → 순수 Web (React + TS)
- **엔진 결정 보류, 코어부터** → Godot 4 (자동 진행 + 체크포인트 모두 동일)

### 3단계: 풀 매니페스트 + 프로젝트 부트스트랩

기존 `game-assets-pool` 저장소를 submodule 또는 직접 readlink로 게임 프로젝트에 매핑:

```bash
~/work/<game-name>/
├── assets/
│   ├── units/human-loyalists/     (symlink → ~/work/game-assets-pool/extracted/wesnoth/units/human-loyalists/)
│   ├── portraits/humans/          (symlink → ...portraits/humans/)
│   ├── heroes/                    (KayKit Adventurers)
│   ├── tiles/                     (KayKit Hexagon)
│   ├── icons/                     (Nieobie)
│   ├── music/                     (Wesnoth music)
│   └── sounds/                    (Wesnoth sounds)
├── src/
│   ├── autoload/
│   │   ├── game_state.gd          (체크포인트 DB)
│   │   ├── tick_scheduler.gd      (자동 진행)
│   │   └── decision_queue.gd      (결정 큐)
│   ├── systems/
│   │   ├── time.gd
│   │   ├── mercenary.gd
│   │   ├── contract.gd
│   │   ├── economy.gd
│   │   └── event.gd
│   ├── scenes/
│   │   ├── main.tscn
│   │   ├── dashboard.tscn         (진입 화면 — 결정 큐 + 요약)
│   │   ├── map.tscn               (전장)
│   │   ├── camp.tscn              (영지)
│   │   ├── dialogue.tscn          (이벤트 다이얼로그)
│   │   └── roster.tscn            (용병 명단, Last Banner 2026-07-16)
│   └── ui/
│       └── (Wesnoth 픽토그램 + Nieobie icons)
└── export/
    ├── web/                       (Vercel 배포용)
    └── desktop/                   (Mac/Windows 빌드)
```

### 4단계: 빌드 + Vercel 배포

- `godot --headless --export-release "Web" export/web/index.html`
- `vercel --prod` (프로젝트 루트 = `export/web/`)
- 1차 빌드 후 mobile Safari/Chrome에서 즉시 검증

**Vercel CLI 토큰 만료 시 fallback**: GitHub push → Vercel GitHub 통합 자동 배포 (2026-07-15 검증). `vercel.json`의 buildCommand는 project settings에 영구 저장 → CLI 토큰 없이도 push 트리거 작동. 즉시 롤백 필요하면 `git revert && git push`로 우회.

---

## 화면 패턴 4종 (Last Banner 1~7단계 검증)

### 결정 다이얼로그 (모달)

HIGH/CRITICAL 결정을 모달로 띄워 자동 진행 일시정지 → 사용자가 선택지 클릭 → 자원 변동 → 다음 결정 또는 진행 재개. 우선순위 기반 UI 분기 (LOW/MEDIUM은 알림만). 자세한 구현: `references/decision-dialog-pattern.md`.

### 컬렉션/명단 화면 (3-pane)

용병/인벤토리/관계도 같은 컬렉션 화면의 표준. **3-pane List-Detail 레이아웃 + 시그널 구독 자동 갱신**. Last Banner `scenes/roster.tscn` + `scripts/roster.gd`에서 검증.

**핵심 함정 — 시그널 핸들러 인자 미스매치**:
```gdscript
# ❌ 안 됨 — 호출 인자 수 고정, 런타임 silent crash
func _on_mercenary_changed(_m: Dictionary) -> void: ...

# ✓ 됨 — 디폴트 인자로 시그널 변화에 강건
func _on_mercenary_changed(_m = null, _reason: String = "") -> void: ...
```
여러 시그널이 같은 핸들러를 호출하면 **가장 많은 인자 시그널 기준으로 디폴트 인자** 원칙. 자세한 구현 + 티어/상태 색상 표준 + 검증 절차: `references/roster-screen-pattern.md`.

### 영지 대시보드 (시계열 시각화)

자동 진행의 효과를 시각화하는 핵심 화면. **메트릭 카드 + ProgressBar + 라인 차트 + 사건 로그 + 업적 시스템** 통합. Last Banner `scenes/manor_dashboard.tscn` + `scripts/dashboard.gd`에서 검증.

**핵심 패턴 4가지**:
1. **GameWorld.history ring buffer (7일)** — `record_day_snapshot(day)` + `pop_front()` 무한 증가 방지
2. **Control._draw() + queue_redraw()** — `draw.connect(_draw_chart)` + `chart_canvas.queue_redraw()` 패턴. `draw_line`/`draw_circle`/`draw_string` 직접 호출.
3. **`max(max_val, 1)` normalize** — 자원별 다른 스케일을 같은 차트에 그릴 때 0 나눗셈 방지
4. **시그널 핸들러 인자 통일** — `_x = null, _y = null` 모든 시그널 디폴트

**GDScript 함정 — theme_override_* 인덱스 할당 불가**:
```gdscript
# ❌ 파스 에러 — Only identifier, attribute access, and subscription access can be used as assignment target
label.theme_override_font_sizes/font_size = 12

# ✓ 메서드 호출
label.add_theme_font_size_override("font_size", 12)
```

**tscn의 Label/modulate 직접 할당 함정** (2026-07-16, Last Banner 전투 화면 검증 발견): `.tscn` 파일에서 `Label`에 `modulate = Color(...)` 직접 작성하면 Godot 4가 파스 에러를 냄 (`Error parsing: Parse error`). Label 노드는 런타임 modulate 속성이 없음. `theme_override_colors/font_color = Color(...)` 또는 코드에서 `label.modulate = ...` (런타임) 둘 다 OK. 또는 아예 modulate 빼고 디자인 단순화.

자세한 패턴 + 색상 표준 + LB_VERIFY 검증 절차: `references/dashboard-screen-pattern.md`.

### 전투 시각화 화면 (Last Banner 7단계, 2026-07-16)

**문제**: 결정 다이얼로그에서 출격/숨기/뇌물 선택만 함 → 텍스트 한 줄로 결과 표시. 시각적 임팩트 0. CK3 양식 주사위 + 그리드 + 손실 카드 시각화 필요.

**해결 패턴 — 3단계 상태머신 (Decision → Simulating → Result)**:

```
DecisionDialog 출격/숨기/뇌물 선택 → BattleScene.show_battle(enemy_count, my_power, enemy_power)
   ├─ DECISION (결정) — 출격/숨기/뇌물 버튼
   ├─ SIMULATING (시뮬레이션) — 주사위 애니메이션 3회 + 전투력 비교
   └─ RESULT (결과) — 승/패 + 손실 카드 → 5초 후 자동 종료
```

**씬 구조** (`scenes/battle_scene.tscn`):
```
BattleScene (Control)
├── DimBG (ColorRect, 0.97 alpha)
└── MainVBox
    ├── Header: TitleLabel + PhaseLabel (현재 단계 색상)
    ├── TroopRow (HBox)
    │   ├── AlliesCard (PanelContainer) — 아군 카드 GridContainer (5열)
    │   ├── VSLabel (단순 텍스트 "⚔️\nVS")
    │   └── EnemiesCard (PanelContainer) — 적군 카드 GridContainer
    └── BottomCard
        ├── StatusLabel (현재 상태)
        ├── DiceLabel (🎲 주사위 큰 텍스트 28pt)
        └── ChoicesRow (선택지 동적 버튼)
```

**상태머신 구현** (`scripts/battle.gd`):
```gdscript
enum Phase { DECISION, SIMULATING, RESULT }

func show_battle(enemy_count, my_power, enemy_power) -> void:
    _enemy_count = enemy_count
    _allies = GameWorld.alive_mercenaries().duplicate(true)
    # 적군 무작위 생성
    for i in range(enemy_count):
        _enemies.append({"id": i, "name": "약탈자 %d" % (i+1), "alive": true})
    _phase = Phase.DECISION
    visible = true
    _render_decision_phase()  # 아군/적군 그리드 채우기 + 선택지 버튼

func _on_choice_pressed(choice_id: String) -> void:
    _choice_made = choice_id
    match choice_id:
        "fight":
            _phase = Phase.SIMULATING
            await _run_simulation()  # 주사위 애니메이션 + 손실 처리
        "hide": _render_result_phase("🏰 영지에 숨었습니다", ...)
        "bribe": _render_result_phase("💰 뇌물 지급", ...)

func _run_simulation() -> void:
    for i in range(3):  # 주사위 3번 굴림
        dice_label.text = "🎲 %d" % (randi() % 20 + 1)
        await get_tree().create_timer(0.2).timeout
    var dice_roll: int = (randi() % 20) + 1
    var my_score: int = _my_power + dice_roll
    var enemy_score: int = _enemy_power + (randi() % 20) + 1
    var victory: bool = my_score > enemy_score
    # ... 손실 처리 + GameWorld.resolve_battle() 호출 ...
```

**전투 결과 처리 (`GameWorld.apply_result("BATTLE_BANDITS_FIGHT")`)** — CK3 양식 확률:
```gdscript
"BATTLE_BANDITS_FIGHT":
    var enemy_count: int = payload.get("enemy_count", 5)
    var est_victory: float = payload.get("estimated_victory", 0.5)
    var roll: float = randf()
    if roll <= est_victory:
        # 승리 — 적 0~30% 사망, 아군 0~15% 사망
        var casualties: int = int(enemy_count * 0.3 * randf())
        var injured: int = int(enemy_count * 0.2 * randf())
        resolve_battle("victory", casualties, injured)
    else:
        # 패배 — 아군 1~25%, 적 0~10%
        var casualties: int = int(enemy_count * 0.25 * randf()) + 1
        var injured: int = int(enemy_count * 0.4 * randf()) + 1
        resolve_battle("defeat", casualties, injured)
        modify_resource("population", -int(enemy_count * 0.2))
```

**결정 다이얼로그 ↔ 전투 자동 연동** — `dialog_scene._on_choice_pressed` 안에서 `BattleScene.show_battle()` 직접 호출 가능 (현재는 메뉴의 "전투 시뮬레이션 (B)" 버튼으로 수동 트리거, LB_VERIFY 검증 용).

**단축키**: B/ESC로 화면 토글.

**LB_VERIFY 검증 절차**:
```gdscript
# 4.9) 전투 시각화 검증
var battle = get_tree().current_scene.find_child("BattleScene", true, false)
battle.show_battle(5, my_power, 10)
assert(battle.visible)
# 그리드 채워졌는지 확인
var allies_grid: GridContainer = battle.get_node_or_null("MainVBox/.../AlliesGrid")
var enemies_grid: GridContainer = battle.get_node_or_null("MainVBox/.../EnemiesGrid")
assert(allies_grid.get_child_count() == 3)  # 아군 3명
assert(enemies_grid.get_child_count() == 5)  # 적군 5명
# 출격 선택 → 시뮬레이션 진입 확인
battle._on_choice_pressed("fight")
```

자세한 코드 + 다이얼로그 → 전투 자동 연동 패턴 + LB_VERIFY 검증 절차: `references/battle-visualization-pattern.md`.

---

## 검증된 함정 (Pitfalls)

1. **자동 진행 = 사용자에게 "느린" 게임으로 느껴질 수 있음** — 진입 화면에서 "지난 N일 동안 일어난 일" 요약을 보여줘야 시간 점프의 부재를 보완. **해결책**: 자동 진행 ON 기본값 + 토스트 알림 (위 "6번째 원칙" 참조).
2. **체크포인트 DB schema 변경 시 마이그레이션** — 한 번 출시 후 스키마 바꿀 때마다 마이그레이션 코드 작성. v0에서는 schema versioning (`schema_version` row) 미리 박아둘 것.
3. **Web 자동 진행 + 백그라운드 tab** — 브라우저는 백그라운드 tab에서 `setInterval`를 1초 throttle 함. Service Worker의 periodic sync는 5분 단위 + 권한 요청 필요. **해결**: Web에서는 자동 진행은 foreground only, 백그라운드는 desktop 빌드만.
4. **Godot WASM SharedArrayBuffer + Vercel** — 위에서 다룸. 헤더 없이 배포하면 런타임 에러 → "vercel.json 파일 빠뜨림"이 1순위 디버깅 포인트.
5. **체크포인트 DB 충돌** — 두 탭에서 동시에 같은 game에 진입하면? 해결: game_id 별로 한 탭이 lock을 들고, 나머지는 "다른 세션 진행 중" 메시지. (Figma식 optimistic lock)
6. **결정 큐 무한 누적** — 사용자가 한 달 미진입 시 결정 큐 1000+ 사건. 해결: 우선순위 정렬 + 자동 처리되는 enum (위 4가지 enum 표 참조).
7. **시간 단계 = 게임 일수 <-> 실시간 동기화** — 단순한 변환 ("1초 = 1일")만 하면 호흡이 깨짐. 실 게임 시간 (예: 24 게임일 = 1 real-life day) 권장.
8. **시그널 핸들러 인자 미스매치 (Godot)** — 한 핸들러가 여러 시그널 콜백이면 가장 많은 인자 시그널 기준 디폴트 인자. 검증: `_run_verify()`에 사망자 시그널 (`mercenary_left` = 2 args) 트리거 + 행 갱신 확인.
9. **Godot 헤드리스 `process_frame` 무한 대기 (2026-07-16, Last Banner 검증 발견)** — `for i in range(60): await get_tree().process_frame` 같은 패턴이 헤드리스 모드에서 hang (Godot이 process_frame 신호를 안 보내거나 지연). **증상**: `LB_VERIFY=1 godot --headless` 가 timeout으로 죽음. **해결**: await 루프 대신 `advance_minutes()` 직접 호출 후 단일 `process_frame`.
   ```gdscript
   # ❌ 안 됨 — 헤드리스에서 hang 가능
   for i in range(60):
       TimeManager.advance_minutes(10)
       await get_tree().process_frame  # ← 헤드리스에서 progress 신호 안 옴
   
   # ✓ 됨 — 시뮬 효과 동일, await 없음
   for i in range(60):
       TimeManager.advance_minutes(10)
   await get_tree().process_frame  # 한 번만
   ```
   **진단**: hang 시 `print` 로그로 어디까지 실행됐는지 확인 → `await get_tree().process_frame` 줄 찾기.
10. **`_` prefix 변수 외부 할당 시 변수 위치 확인 (2026-07-16 발견)** — GDScript `_` prefix는 컨벤션일 뿐 (강제 private 아님). 외부에서 `TimeManager._last_tick_minutes = 0` 호출 시 컴파일은 통과해도 **변수가 다른 autoload에 있을 수 있음** (예: 진짜는 `GameWorld._last_tick_minutes`). **증상**: 런타임 ERROR `Invalid assignment of property '_last_tick_minutes' with value of type 'int' on a base object of type 'Node'`. **해결**: 외부에서 `_` 변수 만지기 전에 `grep -rn "var _last_" autoload/`로 위치 확인. 또는 public API (`set_xxx()` / `reset()`) 추가.
11. **`@onready $SceneInstance` 인스턴스화 순서 함정 (2026-07-16, Last Banner 전투 화면 검증 발견)** — main.tscn이 여러 PackedScene 인스턴스를 `[node name="X" parent="." instance=ExtResource(...)]`로 로드할 때, **`@onready var x = $SceneInstance`가 `@onready` 평가 시점에 인스턴스가 아직 트리에 없으면 null 반환**. 증상: `ERROR: Node not found: "BattleScene" (relative to "/root/Main").` + 부팅 시 WARNING `Node './BattleScene' was modified from inside an instance, but it has vanished.`. **해결**:
    ```gdscript
    # ❌ 안 됨 — 평가 시점에 노드 미존재
    @onready var battle_scene: Control = $BattleScene

    # ✓ 됨 — var + call_deferred로 _ready 끝에 동적 검색
    var battle_scene: Control = null

    func _ready() -> void:
        call_deferred("_find_battle_scene")

    func _find_battle_scene() -> void:
        battle_scene = get_node_or_null("BattleScene")

    func _on_battle_test_pressed() -> void:
        if battle_scene == null:
            _find_battle_scene()
        # ... 사용
    ```
    또는 인스턴스화 순서를 main.tscn에서 명시적으로 재배열 (이전 인스턴스보다 먼저 정의). 동적 검색이 더 안정적.
12. **tscn의 `Label.modulate = Color(...)` 파스 에러 (2026-07-16, 전투 화면 검증 발견)** — `.tscn`에서 Label 노드에 `modulate = Color(...)` 직접 작성 → Godot 4에서 `Parse Error: Parse error` (Label은 런타임 modulate 속성이 있지만 tscn 직렬화 형식에 안 맞음). **해결**:
    ```ini
    # ❌ Parse error
    [node name="AlliesTitle" type="Label" parent="..."]
    text = "🛡️ 아군"
    modulate = Color(0.6, 0.85, 1.0)        # ← 파스 에러

    # ✓ (1) theme_override_colors 사용
    text = "🛡️ 아군"
    theme_override_colors/font_color = Color(0.6, 0.85, 1.0)

    # ✓ (2) 아예 빼고 디자인 단순화 (Label 색은 기본 흰색)
    text = "🛡️ 아군"

    # ✓ (3) 코드에서 런타임 modulate 적용
    label.modulate = Color(0.6, 0.85, 1.0)   # .gd 안에서 OK
    ```
    **진단**: 빌드는 통과하지만 `Failed loading resource: res://scenes/X.tscn` 같은 에러 → 해당 .tscn에서 `modulate` 라인 grep.
13. **Autoload 시그널 race condition — emit이 connect보다 빠름 (2026-07-16, Last Banner 자산 가져오기 버튼 디버깅에서 발견)** — 사용자가 "자산 가져오기 (CDN) 버튼이 비활성화"라고 보고. Godot autoload는 main scene보다 먼저 `_ready()` 호출. AssetRegistry가 `_load_manifest()` 안에서 `manifest_loaded.emit()` 호출 → main scene은 아직 인스턴스화 안 됐거나 `_ready` 진입 전 → `connect`는 한참 뒤에 호출 → 시그널은 emit됐는데 아무도 안 받음 → 핸들러 미호출 → 버튼 영영 비활성.

    **증상은 "버튼 안 눌림"처럼 보이지만 진짜 원인은 시그널 미수신**. 같은 패턴이 두 번 더 등장: `fetch_progress` 시그널이 콜백으로만 emit되어 ProgressBar 0%에서 멈춤, `all_assets_ready` 시그널이 `_loaded_bytes >= total` 절대 만족 안 되는 조건 때문에 미발생. **시그널은 두 곳에서 emit해야 함 — (1) 명시적 핸들러/콜백, (2) 직접 시그널 emit**. 둘 중 하나만 쓰면 한쪽 경로가 silent하게 끊김.

    **진단법**: main.gd `_ready()`에 진단용 print:
    ```gdscript
    print("[Main] autoload 상태: %s" % str(AssetRegistry.get_base_url() != ""))
    AssetRegistry.manifest_loaded.connect(_on_manifest_loaded)
    print("[Main] 시그널 연결 후 connections: %d" % AssetRegistry.manifest_loaded.get_connections().size())
    ```
    매니페스트가 이미 로드됐는데 connections=0이면 race condition 확정.
    
    **해결 — 2중 안전망**:
    ```gdscript
    # autoload/asset_registry.gd — emit 지연
    func _load_manifest() -> void:
        # ... 파싱 ...
        _manifest_ready = true
        call_deferred("_emit_manifest_loaded")   # ← 다음 프레임에 emit

    func _emit_manifest_loaded() -> void:
        manifest_loaded.emit()
    ```
    ```gdscript
    # scripts/main.gd — 안전망
    func _ready() -> void:
        AssetRegistry.manifest_loaded.connect(_on_manifest_loaded)
        if AssetRegistry.get_base_url() != "":
            _on_manifest_loaded()  # ← 이미 로드됐으면 직접 호출
    ```
    
    **왜 둘 다?**
    - `call_deferred`만: autoload 시점 OK, 하지만 autoload 도중 재호출 시 미보호.
    - 안전망만: 매번 main scene 진입 시 체크 → 미세 overhead.
    - 둘 다: 어떤 호출 경로에서도 핸들러 1회 호출 보장.
    
    **LB_VERIFY 주의**: 검증 모드 분기(`if _verify_mode: _run_verify(); return`)에서 early return → 안전망 미호출 → `get_connections().size() == 0`이 정상. `if not _verify_mode: assert(...)`로 약화.

14. **모달 화면의 X 버튼 + Z-order 표준 패턴 (2026-07-16, Last Banner 다중 화면 작업에서 검증)** — 모든 모달 화면(roster/dashboard/decision_dialog/tutorial/succession/battle/buildings)에 시각적 X 닫기 버튼이 필요. ESC 단축키만 있으면 사용자가 "못 닫는다"고 느낌 (Last Banner에서 4번 반복된 사용자 피드백). **표준 패턴**:
    - 모든 모달 tscn에 `XButton` 노드 추가 (parent=".", 우상단 anchor, 60×48 크기, 텍스트 "✕", font 28pt, white 85% opacity, mouse cursor=2)
    - 각 모달 스크립트에 `@onready var x_button: Button = $XButton` + `_on_close_pressed`에 연결
    - `decision_dialog`처럼 close_button이 없는 모달은 `_on_x_pressed` 신규 메서드 (현재 결정 닫고 큐에 다음 거 표시)
    - main.tscn에 MenuToggleButton (게임/메뉴 모드 토글) 추가

    **Z-order 함정 — CanvasLayer의 layer 값으로 z 순서 제어**:
    - `TutorialOverlay layer=15` > `DecisionDialog layer=10` > `UI layer=1` (기본). 토글 버튼이나 X 버튼이 TutorialOverlay에 가려질 수 있음.
    - **해결 1**: `z_index = 100` + `z_as_relative = false` (절대 z, 모든 layer 위). 이게 가장 안정적.
    - **해결 2**: `layer = 20` 같은 더 높은 CanvasLayer로 MenuToggleButton 배치.
    - **해결 3 (피해야)**: tscn 순서 변경만 (Godot은 tree 순서대로 그리지만 CanvasLayer layer가 우선).

    **사용자 보고 패턴**: "여전히 안 보임"이 2번 이상 반복되면 — 콘솔 메시지(`print`) + 동적 검색(`get_node_or_null`) 폴백으로 진단 후 수정. 단순 시각적 누락은 z-order 의심.

15. **LB_VERIFY 헤드리스 hang — await 루프 + 실제 HTTP fetch (2026-07-16, AssetRegistry.fetch_all 디버깅에서 검증)** — `for i in range(60): TimeManager.advance_minutes(10); await get_tree().process_frame` 같은 패턴은 헤드리스에서 hang 가능 (이미 함정 9에 기록). **더 미묘한 hang**: `AssetRegistry.fetch_file(url, callback)`이 헤드리스 환경에서 실제 HTTP 요청 → 404 (CDN 헤더 누락 등) → 콜백 안 호출 또는 빈 body → Ogg 디코딩 실패 → 무한 재시도. **증상**: `LB_VERIFY=1 godot --headless` 타임아웃. **진단법**: 타임아웃 시 `/tmp/lbout.txt`로 출력 캡처 → 마지막 print 로그 확인 → `await get_tree().create_timer(...)` 또는 HTTP 요청 의심.
    - `DisplayServer.get_name() == "headless"` 체크로 가드 (AudioManager의 `_is_running_locally()` 패턴이 대표)
    - `pending.is_empty()` early return 추가 — 동시 다운로드 흐름에서 큐 비었을 때 무한 대기 방지
    - `if not _verify_mode` 가드로 검증 모드에서 HTTP fetch 자체 호출 안 함 (AssetRegistry.fetch_file 같은 경우)

    **LB_VERIFY 시 발견되는 hang 패턴**:
    - `await` 루프 (함정 9)
    - HTTP fetch (위)
    - 무한 큐 처리 (예: `while queue: process_one()` — 큐가 줄지 않으면 hang)
    - Audio 디코딩 (위)
    - **진단**: hang이면 `print` 로그 위치를 보고 hang 지점 찾기 → 그 줄 await/fetch/loop 의심.
    
    **AudioManager 헤드리스 가드 (보너스 발견)**: `play_bgm("menu")` → `fetch_file()` → HTTP 다운로드 → 404 (헤드리스에선 CDN 실패) → 빈 파일 → Ogg 디코딩 실패 → 무한 재시도 hang. **해결**:
    ```gdscript
    func _is_running_locally() -> bool:
        return DisplayServer.get_name() != "headless"

    func _load_and_play_bgm(file_path, track_info, fade_duration) -> void:
        if _cache.has(file_path):
            _start_bgm_with_stream(_cache[file_path], track_info, fade_duration)
            return
        if not _web_audio_available and not _is_running_locally():
            print("[AudioManager] 헤드리스 모드 — 음악 재생 스킵: %s" % file_path)
            return
        # ... fetch_file ...
    ```
    `DisplayServer.get_name()`은 "headless" 또는 "dummy" 또는 실제 디스플레이 서버 이름.

    **전체 통합 워크플로 + 진단법 + LB_VERIFY 약화 패턴**은 `references/autoload-signal-race-condition.md` (godot-game-bootstrap 스킬) 참조. 시그널 인자 미스매치 + 인스턴스화 순서 + autoload race condition이 한 곳에 모임.

---

## 검증 패턴 — `LB_VERIFY=1` 환경변수 (Godot 한정)

Godot 헤드리스에서 autoload까지 띄우는 표준 검증 방법. `godot --script res://verify.gd`는 autoload 등록 안 됨 → main.gd에 검증 모드 내장.

```gdscript
const LB_VERIFY := "LB_VERIFY"

func _ready() -> void:
    if OS.has_environment(LB_VERIFY):
        _run_verify()
        return
    # ... 일반 부팅

func _run_verify() -> void:
    # 1) 새 게임
    # 2) 24시간 시간 진행 (1440분)
    # 3) 결정 큐 증가 확인
    # 4) HIGH/CRITICAL 강제 push → 다이얼로그 자동 표시 확인
    # 5) 결정 자동 처리 → 자원 변동 정확성
    # 6) 저장/로드 round-trip
    # 7) (선택) 컬렉션 화면 자동 갱신
    # 8) get_tree().quit()
```

**실행**: `cd ~/work/last-banner && LB_VERIFY=1 godot --headless`

상세 패턴 + 출력 예: `incremental-game-design-last-banner-event-engine` SKILL.md 참조.

---

## 📁 첨부 파일

- `references/godot-web-export-to-vercel.md` — Godot 4 Web Export → Vercel 배포 전체 워크플로 + COOP/COEP 함정 + 모바일 테스트 절차 + **GitHub push → Vercel 자동 배포 패턴** (CLI 토큰 만료 시 fallback, 2026-07-15 검증)
- `references/turn-based-auto-progression-pattern.md` — 시간 단계 + 결정 큐 + 자동 저장 architecture (Godot/Web 공통)
- `references/decision-dialog-pattern.md` — 모달 결정 다이얼로그 UI (LOW/MEDIUM 알림 분기, 큐 길이 debouncing, 14개 결과 핸들러)
- `references/roster-screen-pattern.md` — 3-pane List-Detail 컬렉션 UI, 시그널 구독 자동 갱신, **시그널 핸들러 인자 미스매치 함정**, 티어/상태 색상 표준, show_screen() 토글 패턴 (Last Banner 2026-07-16 검증)
- `references/dashboard-screen-pattern.md` — 영지 대시보드 (라인 차트 + ProgressBar + 메트릭 카드 + 업적 + 시그널 자동 갱신), GameWorld.history ring buffer, **Control._draw() + queue_redraw() 패턴**, 토스트 페이드 인/아웃, **GDScript theme_override_* 인덱스 할당 불가 함정** (Last Banner 2026-07-16 검증)
- `references/battle-visualization-pattern.md` — 전투 시각화 화면 (3단계 상태머신 + 주사위 애니메이션 + 손실 카드 + 결정 다이얼로그 → 전투 자동 연동 + LB_VERIFY 검증), **@onready $SceneInstance 인스턴스화 순서 함정**, **tscn Label.modulate 파스 에러 함정** (Last Banner 7단계 2026-07-16 검증)
- `references/auto-progress-onboarding-pattern.md` — 자동 진행 ON 기본값 패턴 (GameManager.start_new_game에서 enable_auto_progress, 토스트 페이드 트윈 알림, 로드 시 상태 보존, Last Banner 4단계 2026-07-16 검증)
- `references/modal-screen-x-button-pattern.md` — 모달 화면 X 닫기 버튼 표준 + Z-order 안전성 (모든 모달 tscn에 XButton + z_index=100 + z_as_relative=false, "여전히 안 보임"이 2번 이상 반복 시 z-order 다음 의심). 7개 화면 적용 예시 (Last Banner 2026-07-16 검증)
- `references/tutorial-onboarding-pattern.md` — 4단계 튜토리얼 오버레이 (`GameManager.tutorial_seen` 영속화 + 재시청 패턴 + 7초 자동 진행 + Space/Enter/ESC 단축키 + DecisionDialog.layer=10과 충돌 방지, Last Banner 5단계 2026-07-16 검증)
- `templates/vercel.json` — Godot Web Export용 COOP/COEP 헤더 박은 vercel.json (그대로 `export/web/`에 복사)

---

## 🔗 관련 스킬

- `toss-trader-dev` — 토스증권 Open API 기반 Next.js 투자 어시스턴트 (자동 진행 DB 패턴 차용)
- `text-game-builder` — LLM이 GM인 텍스트 게임 (다른 클래스 — 본 스킬은 "세계가 알아서 진행, 사용자는 결정만")
- `python-oss-bootstrap` — repo 부트스트랩 패턴
- `vercel` — Vercel CLI 일반 사용법
- `godot-game-bootstrap` — Godot 프로젝트 부트스트랩 (자산 풀 + export presets + autoload 골격)
- `incremental-game-design-last-banner-event-engine` — Last Banner 실전 검증된 GameWorld + EventEngine + DecisionQueue 패턴