#!/usr/bin/env bash
## verify-headless.sh — incremental-game-design 헤드리스 통합 검증.
##
## Last Banner 패턴 (2026-07-16 검증):
##   1. Godot 헤드리스 부팅 가능 확인 (3초)
##   2. LB_VERIFY 모드 전체 시뮬레이션 실행
##   3. 핵심 마커 (PASS/FAIL/✓/✗) grep
##   4. pck에 새 파일 포함 확인 (Vercel 배포 후)
##
## 사용:
##   cd ~/work/<your-game>
##   bash ~/.hermes/skills/creative/incremental-game-design/scripts/verify-headless.sh
##
## 종료 코드:
##   0 = 모든 검증 통과
##   1 = 부팅 실패 또는 LB_VERIFY 실패
##   2 = LB_VERIFY hang (60초 타임아웃) — simplify 필요

set -euo pipefail

GAME_ROOT="${GAME_ROOT:-$PWD}"
GODOT_BIN="${GODOT_BIN:-godot}"
VERCEL_URL="${VERCEL_URL:-}"

LB_TIMEOUT="${LB_TIMEOUT:-60}"
HEADLESS_TIMEOUT="${HEADLESS_TIMEOUT:-15}"

echo "=== 헤드리스 부팅 체크 ==="
if ! "$GODOT_BIN" --headless --quit-after "$HEADLESS_TIMEOUT" 2>&1 | tail -3; then
    echo "❌ 부팅 실패 — main.gd 파스 에러 또는 autoload 문제"
    exit 1
fi

echo
echo "=== LB_VERIFY 통합 시뮬레이션 ==="
if ! timeout "${LB_TIMEOUT}" bash -c "LB_VERIFY=1 $GODOT_BIN --headless 2>&1" | tee /tmp/lb_verify.log | tail -60; then
    echo
    echo "❌ LB_VERIFY hang (${LB_TIMEOUT}초 타임아웃)"
    echo "   → main.gd의 verify 코드에서 await 루프 단순화 필요"
    echo "   → 또는 새 시그널 핸들러 인자 미스매치 가능성"
    exit 2
fi

echo
echo "=== 핵심 마커 확인 ==="
if grep -qE '\[PASS\]|✓ 저장/로드|✓ 다이얼로그|✓ 자동 진행' /tmp/lb_verify.log; then
    echo "✓ 핵심 마커 발견"
else
    echo "⚠ 핵심 마커 없음 — 검증 결과 확인 필요"
    exit 1
fi

# 7~12차 누적 마커 — 새로 추가된 기능 검증용
echo
echo "=== 누적 마커 (선택적) ==="
for marker in "왕조" "전투 시각화" "오디오" "마을 건설"; do
    if grep -q "$marker" /tmp/lb_verify.log; then
        echo "✓ $marker 검증 발견"
    else
        echo "  (선택적) $marker 없음"
    fi
done

# Vercel 배포 후 라이브 확인
if [[ -n "$VERCEL_URL" ]]; then
    echo
    echo "=== Vercel 라이브 확인 ==="
    curl -sI "$VERCEL_URL" | grep -E "age|HTTP" | head -3
fi

echo
echo "=== 검증 완료 ==="