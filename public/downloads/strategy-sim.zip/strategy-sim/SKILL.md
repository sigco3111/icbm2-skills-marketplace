---
name: strategy-sim
description: Military and strategic simulation engine for analyzing scenarios, developing tactics, and optimizing resource allocation. Use when the user needs to: (1) Analyze military scenarios or strategic situations, (2) Develop tactical plans and response strategies, (3) Evaluate enemy capabilities and predict movements, (4) Optimize resource allocation under constraints, (5) Assess risks and develop contingency plans, (6) Run strategic simulations and wargaming exercises.
---

# Strategy Sim - Military & Strategic Simulation

## Core Capabilities

This skill provides frameworks and tools for strategic analysis across military, business, and competitive scenarios.

### When to Load References

Load reference files based on the task type:

- **Classic strategic theory**: `references/classic-theory.md` - Clausewitz, Sun Tzu, modern principles
- **Resource allocation**: `references/resource-models.md` - Force multiplication, logistics, attrition rates
- **Scenario templates**: `references/scenarios.md` - Terrain types, engagement scenarios, force structures
- **Risk assessment**: `references/analysis-frameworks.md` - SWOT, vulnerability analysis, decision trees

## Analysis Workflow

### 1. Define the Scenario

Establish the strategic context:
- **Objective**: What's the end state? (Capture territory, achieve market share, neutralize threat)
- **Participants**: Who are the actors? (Allied forces, competitors, neutrals)
- **Constraints**: Time, resources, geographical limitations
- **Intelligence**: What's known about enemy capabilities?

### 2. Analyze Force Capabilities

Use `references/resource-models.md` to assess:
- Combat power and multipliers (technology, morale, training)
- Logistics and sustainment capacity
- Mobility and maneuver capabilities
- Intelligence and surveillance assets

### 3. Develop Strategic Options

Generate 3-5 distinct approaches based on:
- **Direct approach**: Strength vs strength
- **Indirect approach**: Attack weaknesses, bypass main force
- **Asymmetric approach**: Exploit unique advantages
- **Defensive approach**: Exhaust enemy, counter-attack

For each option, assess:
- Success probability
- Resource requirements
- Time to achieve objective
- Risk exposure

### 4. Evaluate Risks and Contingencies

Use frameworks from `references/analysis-frameworks.md`:
- Identify high-probability, high-impact events
- Develop early warning indicators
- Create fallback positions or alternative plans
- Plan for worst-case scenarios

### 5. Optimize Resource Allocation

Use `scripts/optimize_allocation.py` to:
- Prioritize high-impact units/actions
- Balance offensive vs defensive needs
- Maintain reserve forces (typically 20-30%)
- Sustain logistics chain

## Simulation Scripts

### Run Strategic Simulation

```bash
cd skills/strategy-sim/scripts
python3 simulate_scenario.py --scenario <scenario-file>
```

Outputs:
- Predicted outcomes for each strategic option
- Casualty/loss estimates
- Time-to-objective projections
- Risk heat maps

### Compare Strategies

```bash
python3 compare_strategies.py --options <strategy-list>
```

Provides:
- Side-by-side comparison matrix
- Sensitivity analysis (what if key assumptions change?)
- Break-even analysis points

## Output Formats

### Strategic Brief

Structure your analysis as:

```
# Strategic Analysis: [Scenario Name]

## Executive Summary
[3-4 sentence overview of recommended approach]

## Situation Assessment
[Current state, key factors, enemy disposition]

## Strategic Options

### Option 1: [Name]
**Approach**: [Brief description]
**Strengths**: [Bullet points]
**Weaknesses**: [Bullet points]
**Resource Requirements**: [Units, time, logistics]
**Success Probability**: [%]

### Option 2: [Name]
[Same structure]

## Recommended Course of Action
**Primary Strategy**: Option X
**Rationale**: [Why this option]
**Critical Success Factors**: [What must go right]
**Contingency Plans**: [If A, then B]

## Risk Assessment
[Top 5 risks with mitigation strategies]
```

### Wargame Exercise Format

For interactive simulations:

```
## Wargame: [Scenario]

### Setup
- Map/terrain: [Description]
- Forces: [Blue vs Red composition]
- Starting positions: [Coordinates]
- Turn structure: [Time per turn, phases]

### Turn X Results
[Movement, engagement, outcomes]

### After Action Review
- What worked as planned?
- What surprised us?
- Lessons learned
```

## Key Strategic Principles

Reference these fundamentals when advising:

- **Mass**: Concentrate superior force at decisive point
- **Objective**: Direct every operation toward a clearly defined goal
- **Offense**: Seize, retain, and exploit initiative
- **Economy of Force**: Allocate minimum essential resources to secondary efforts
- **Maneuver**: Place enemy at disadvantage through flexible application
- **Surprise**: Strike enemy at time/place unprepared
- **Security**: Never permit enemy to acquire advantage
- **Simplicity**: Prepare clear, uncomplicated plans

## Advanced Analysis

### When to Use Classic Theory

Load `references/classic-theory.md` when:
- Explaining strategic rationale
- Drawing historical parallels
- Providing fundamental principles
- Contextualizing modern decisions

### When to Run Simulations

Use simulation scripts when:
- Comparing multiple strategic options
- Quantifying risk exposure
- Testing sensitivity to assumptions
- Providing data-driven recommendations

### When to Be Qualitative

Focus on qualitative analysis when:
- Intelligence is uncertain
- Human factors dominate (morale, leadership, political)
- Time is extremely constrained
- Historical patterns are more relevant than calculations

## Common Pitfalls

- **Focusing on tactics, not strategy**: Ensure recommendations align with strategic objectives
- **Ignoring friction**: Account for chaos, uncertainty, and Murphy's Law
- **Over-optimism**: Build in buffers for delays, resistance, setbacks
- **Mirror imaging**: Don't assume enemy thinks like you do
- **Analysis paralysis**: Provide actionable recommendations, not endless scenarios
