# Resource Models

## Force Multipliers

### Technology Multipliers
- **Superior equipment**: 1.5-3x combat effectiveness
- **Intelligence/surveillance**: 1.5-2x situational awareness
- **Communications**: 1.3-1.8x coordination efficiency
- **Precision weapons**: 2-4x target destruction efficiency

### Human Factors
- **Training quality**: 1.5-2x effectiveness per skill level
- **Morale/combat spirit**: 1.2-1.8x willingness to engage
- **Leadership**: 1.3-2x unit cohesion and initiative
- **Experience**: 1.1-1.5x per combat engagement survived

### Environmental Factors
- **Air superiority**: 2-5x ground force effectiveness
- **Defensive terrain**: 1.5-3x defender advantage
- **Night capability**: 2-3x advantage over enemy without night vision
- **Weather advantage**: 1.2-1.5x if better equipped for conditions

## Combat Power Calculations

### Lanchester's Laws

**Linear Law (Ancient combat)**:
```
Effectiveness = Force size × Individual combat power
```
Each soldier can engage one enemy at a time.

**Square Law (Modern ranged combat)**:
```
Effectiveness = Force size² × Individual combat power
```
All units can engage all enemy targets simultaneously.

**Practical application**: In modern combat, superior numbers compound exponentially.

### Relative Combat Power Formula

```
RCP = (N × C × T × M × L) / (n × c × t × m × l)

Where:
N, n = Number of forces (friendly, enemy)
C, c = Combat effectiveness per unit
T, t = Technology multiplier
M, m = Morale multiplier
L, l = Leadership multiplier
```

**Interpretation**:
- RCP > 1.0: Likely victory
- RCP = 1.0: Stalemate
- RCP < 1.0: Likely defeat
- RCP < 0.5: High risk of catastrophic failure

### Attrition Models

**Linear attrition** (steady casualties over time):
```
Casualties = (Attrition rate × Time) × Force size
```

**Exponential attrition** (accelerating as battle progresses):
```
Casualties = Force size × (1 - e^(-attrition rate × Time))
```

**Critical mass point**: Force becomes ineffective when below 30-40% of original strength.

## Logistics Models

### Supply Line Efficiency

**Logistics effectiveness factor (LEF)**:
```
LEF = 1 - (Distance × 0.01 + Hostility × 0.2 + Terrain difficulty × 0.15)
```

**Multipliers**:
- Secured supply routes: +0.3 LEF
- Air transport capability: +0.4 LEF
- Local resource access: +0.2 LEF

**Amphibious operations**: LEF reduced by 0.4-0.6 due to limited capacity

### Fuel and Ammunition Consumption

**Combat operations**: 3-5x peacetime consumption
- Mobile units: Highest consumption (mechanized infantry, armor)
- Static defenses: Lowest consumption
- Artillery: High ammunition consumption, low fuel

**Logistics-to-combat ratio**: Historical average is 3:1
- For every 1 combat unit, 3 logistics support personnel required

### Sustainment Duration

**Maximum combat effectiveness duration**:
```
Days of sustained combat = (Fuel reserves × Ammunition reserves × Food)^(1/3)
```

**Critical thresholds**:
- Fuel < 20%: Mobility severely degraded
- Ammunition < 30%: Defensive posture required
- Food < 7 days: Morale begins degrading

## Force Structure Models

### Optimal Composition

**Combined arms mix** (balanced for offense):
- Armor: 20-25%
- Mechanized infantry: 30-35%
- Artillery: 15-20%
- Air defense: 10-15%
- Combat support: 15-20%
- Combat service support: 25-30%

**Defensive posture**:
- Static infantry: Increase 10-15%
- Engineers/miners: Increase 5-10%
- Artillery: Increase 5-10%
- Armor: Decrease 10-15%

**Mobile/expeditionary**:
- Air/mobile infantry: Increase 15-20%
- Transport/logistics: Increase 10-15%
- Armor: Decrease 5-10%

### Reserve Force Allocation

**Strategic reserves**: 20-30% of total force
- Maintain depth for exploitation or counterattack
- Location: Behind front line, ready to deploy

**Operational reserves**: 10-15% per sector
- Flexible response to local breakthroughs or threats

**Rest and refit rotation**: 10% of frontline units
- Preserve combat effectiveness over extended operations

## Economic/Military Resources

### Defense Spending Impact

**Spending categories**:
- Personnel: 40-50% (training, salaries, benefits)
- Operations & Maintenance: 25-35% (fuel, parts, repairs)
- Procurement: 15-25% (new equipment)
- R&D: 5-10% (future capabilities)

**Diminishing returns**: After 3-4% of GDP, marginal effectiveness decreases

### Industrial Capacity

**Production multipliers**:
- Peacetime baseline: 1.0
- War footing (partial): 1.5-2.0
- Total war mobilization: 3-5.0
- Concentrated economy: +0.3-0.5 multiplier

**Bottlenecks**: Critical minerals, skilled labor, specialized machinery

## Terrain Models

### Terrain Combat Value (TCV)

**Modifiers to combat effectiveness**:
- Open terrain: 0.8 (reduces cover)
- Mixed terrain: 1.0 (neutral)
- Mountainous: 0.6 (reduces mobility, increases cover)
- Urban: 0.5 (reduces mobility, massive cover advantage)
- Swamp/marsh: 0.4 (severe mobility reduction)

### Movement Rates

**Clear terrain**: 30-40 km/day (mechanized)
**Rough terrain**: 15-25 km/day
**Mountainous**: 10-15 km/day
**Urban**: 5-10 km/day

**Force multipliers**:
- Roads/highways: +50-100% movement
- Helicopter transport: 2-3x mobility (fuel intensive)
- Amphibious capability: Cross water obstacles (slow but valuable)

## Modeling Guidelines

### When to Use Simple Models
- Quick estimates and back-of-envelope calculations
- Early planning phases
- Educational purposes
- When data is limited

### When to Use Complex Models
- Final operational planning
- Resource allocation decisions
- Comparative analysis of multiple options
- Sensitivity analysis (what-if scenarios)

### Limitations and Warnings

- **Human factors are difficult to quantify**: Morale, leadership, initiative matter immensely but resist precise measurement
- **Friction is constant**: Models assume optimal conditions; real operations always degrade
- **Enemy adaptation**: Models assume enemy is static; real enemies adjust and adapt
- **Chaos and randomness**: Black swan events can invalidate all calculations
- **Context dependency**: Historical multipliers may not apply to new technology or environments

**Best practice**: Use models as tools for thinking, not oracles for truth. Combine quantitative analysis with qualitative judgment.
