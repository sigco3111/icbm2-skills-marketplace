# Scenario Templates

## Scenario Structure Template

```
# Scenario: [Name]

## Overview
- **Type**: [Offensive/Defensive/Stability/Hybrid]
- **Scale**: [Tactical/Operational/Strategic]
- **Duration**: [Timeframe]
- **Primary Objective**: [Clear statement]

## Environment

### Terrain
- **Type**: [Urban/Mountain/Desert/Coastal/Jungle]
- **Key features**: [Elevations, water obstacles, chokepoints]
- **Weather**: [Current conditions and seasonal patterns]
- **Infrastructure**: [Roads, bridges, airports, ports]

### Population
- **Density**: [Urban/Rural/Mixed]
- **Attitude**: [Hostile/Neutral/Friendly]
- **Key demographics**: [Ethnic groups, tribes, clans]

## Forces

### Friendly (Blue)
- **Composition**: [Units, types, capabilities]
- **Strength**: [Personnel count, equipment]
- **Deployment**: [Initial positions]
- **Capabilities**: [Air, artillery, cyber, intelligence]
- **Limitations**: [Logistics, endurance, vulnerabilities]

### Enemy (Red)
- **Composition**: [Known or estimated]
- **Strength**: [Estimate range]
- **Disposition**: [Known positions and activities]
- **Capabilities**: [Air defense, armor, indirect fire]
- **Intelligence gaps**: [Unknowns and assumptions]

### Third Parties
- **Neutrals**: [Non-combatants, NGOs, media]
- **Potential allies**: [Other forces or factions]
- **Complicating factors**: [Criminals, militias, etc.]

## Constraints

### Time
- **Start time**: [When operations begin]
- **End time**: [Deadline or sunset clause]
- **Key milestones**: [Intermediate objectives]

### Rules of Engagement
- **Positive ID required**: [Yes/No]
- **Collateral damage limits**: [Tolerance levels]
- **Civilian protection**: [Specific protocols]
- **Escalation thresholds**: [What triggers wider conflict]

### Logistics
- **Supply lines**: [Source, distance, security]
- **Sustainment limits**: [How long operations can continue]
- **Airlift/sea lift**: [Capacity, availability]

## Intelligence

### What We Know
- [Confirmed enemy dispositions, capabilities, intentions]

### What We Suspect
- [Likely enemy actions, estimated strength]

### What We Don't Know
- [Critical intelligence gaps]

### Collection Requirements
- [What intel is needed before committing]

## Success Criteria

### Primary
- [Minimum acceptable outcome]

### Desired
- [Ideal outcome if conditions permit]

### Failure Conditions
- [What constitutes strategic failure]
```

## Common Scenario Types

### 1. Amphibious Assault

**Characteristics**:
- Sea-to-land transition
- Limited initial force size
- High vulnerability during landing
- Build-up critical for success

**Key considerations**:
- Beach selection: Wide, accessible, near objectives
- Air/naval supremacy required
- Logistics bottleneck at beachhead
- Enemy advantage in prepared defenses

**Success factors**:
- Surprise at landing site
- Rapid build-up tempo
- Air and naval fire support
- Secured supply corridor

**Failure modes**:
- Failure to establish beachhead
- Enemy counter-attack overwhelms landing
- Logistics failure prevents build-up
- Naval losses reduce support

### 2. Mountain Warfare

**Characteristics**:
- Extremely limited mobility
- Air power limited by terrain
- Extreme weather challenges
- Natural chokepoints and defensible positions

**Key considerations**:
- Infantry is primary combat arm
- Mountain passes are critical objectives
- Weather windows for operations
- Helicopter support is high-risk, high-value

**Success factors**:
- Superior mountaineering skills
- Local knowledge of terrain
- Air superiority
- Logistics prepared for extreme conditions

**Failure modes**:
- Weather traps force in open
- Logistics failure (snow, avalanches)
- Enemy holds higher ground
- Isolation and lack of reinforcement

### 3. Urban Combat

**Characteristics**:
- Three-dimensional battlespace (underground, ground, air)
- Massive civilian presence
- Intelligence and local support critical
- Slow movement, high casualties

**Key considerations**:
- Buildings become fortresses
- Every street intersection is an obstacle
- Underground networks (sewers, tunnels)
- Sniper and IED threat constant

**Success factors**:
- Superior urban training
- Local intelligence networks
- Precision weapons to minimize collateral damage
- Information warfare (hearts and minds)

**Failure modes**:
- Civilian casualties erode support
- High casualties demoralize force
- Becomes protracted siege
- Insurgency emerges from destroyed infrastructure

### 4. Desert Operations

**Characteristics**:
- Long lines of communication
- High mobility but no cover
- Extreme temperatures
- Limited water and vegetation

**Key considerations**:
- Armor becomes decisive (flat terrain)
- Air superiority critical (no terrain masking)
- Water and heat management primary concerns
- Flanking opportunities abundant

**Success factors**:
- Air superiority for reconnaissance
- Armor superiority
- Robust logistics for long supply lines
- Night operations to reduce heat stress

**Failure modes**:
- Air denial leaves ground force exposed
- Logistics failure in open desert
- Heat casualties degrade combat power
- Enemy outflanks through open terrain

### 5. River Crossing

**Characteristics**:
- Water obstacle as major barrier
- Crossing site critical chokepoint
- Enemy can concentrate defense on crossing
- High vulnerability during crossing

**Key considerations**:
- Crossing site selection (narrowest, best approaches)
- Deception operations to hide true crossing point
- Air supremacy for crossing force protection
- Rapid bridge/engineer capability

**Success factors**:
- Surprise at crossing site
- Overwhelming firepower during crossing
- Engineer preparedness (bridges, boats, pontoons)
- Enemy defensive positions suppressed

**Failure modes**:
- Enemy destroys bridging assets
- Crossing force isolated and destroyed
- Delay allows enemy to reinforce
- Multiple crossing attempts failed

### 6. Counterinsurgency (COIN)

**Characteristics**:
- Enemy blends with population
- Political objectives primary
- Military actions have outsized strategic impact
- Intelligence from population critical

**Key considerations**:
- Population is center of gravity
- Legitimacy is strategic objective
- Minimum force doctrine
- Winning "hearts and minds"

**Success factors**:
- Local government legitimacy
- Economic development
- Security for population
- Intelligence from population (requires trust)

**Failure modes**:
- Civilian casualties create insurgents
- Economic failure fuels resentment
- Corrupt local government
- Over-militarization alienates population

### 7. Strategic Encirclement

**Characteristics**:
- Surrounded enemy force
- Logistics cut off
- Time pressure before resupply or breakout
- Urban fortification likely

**Key considerations**:
- Maintain encirclement integrity
- Psychological operations to induce surrender
- Prevent breakout
- Manage civilian population (if in urban area)

**Success factors**:
- Complete containment
- Denial of air resupply
- Psychological pressure
- Gradual reduction of pocket

**Failure modes**:
- Enemy breakout succeeds
- Encirclement breached at weak point
- Enemy receives air resupply
- Prolonged siege drains resources

## Force-on-Force Comparison Matrix

| Scenario | Friendly Advantage | Enemy Advantage | Decisive Factor |
|----------|-------------------|-----------------|-----------------|
| Amphibious | Surprise, naval supremacy | Prepared defenses, terrain | Build-up tempo |
| Mountain | Training, equipment | Higher ground, knowledge | Air support |
| Urban | Technology, training | Familiarity, concealment | Intelligence |
| Desert | Armor, air power | Long supply lines | Logistics |
| River | Engineer capability | Defensive concentration | Fire superiority |
| COIN | Technology, training | Popular support | Legitimacy |
| Encirclement | Surrounding position | Interior lines | Supply denial |

## Scenario Variables

### Adjustable Parameters

**Force ratios**: 1:1, 1.5:1, 2:1, 3:1 (attack advantage required)
**Time pressure**: Urgent (24h), Normal (days), Protracted (weeks+)
**Intelligence quality**: Complete, Partial, Minimal
**Logistics**: Secure, Contested, Disrupted
**Air support**: Full, Limited, None
**Rules of engagement**: Permissive, Restrictive, Hostile

### Scenario Difficulty Levels

**Easy**:
- 3:1 force ratio
- Air superiority
- Good intelligence
- Secure logistics
- Permissive ROE

**Medium**:
- 1.5:1 force ratio
- Air parity or limited superiority
- Partial intelligence
- Contested logistics
- Moderate ROE

**Hard**:
- 1:1 force ratio
- Air parity or disadvantage
- Minimal intelligence
- Disrupted logistics
- Restrictive ROE

**Extreme**:
- 1:2 force ratio (attack against superior force)
- Air denial
- No intelligence
- No logistics
- Hostile environment

## Using Scenarios

1. **Select template** closest to actual situation
2. **Fill in specifics** for forces, terrain, objectives
3. **Identify gaps** in information and intelligence
4. **Run analysis** with multiple strategic options
5. **Sensitivity test** against different assumptions
6. **Validate** against historical parallels if available
