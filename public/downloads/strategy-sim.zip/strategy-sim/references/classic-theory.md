# Classic Strategic Theory

## Carl von Clausewitz - On War (1832)

### Core Concepts

**The Trinity of War**:
- **Violence/Passion**: Primordial forces (enmity, hatred)
- **Chance/Probability**: Uncertainty and chaos
- **Reason/Policy**: Rational calculation of political objectives

**Key Principles**:
- "War is the continuation of politics by other means"
- Center of Gravity: The source of power that provides moral or physical freedom of action
- Friction: The difference between war as planned and war as experienced
- Fog of War: Uncertainty in situational awareness
- Culminating Point: The point at which offensive power peaks and begins to decline

### Strategic Guidelines

1. **Focus on the enemy's center of gravity**: Strike at the source of their power
2. **Economy of force**: Don't attack everywhere - concentrate strength at decisive point
3. **Attack enemy's strategy**: Defeat their plan before their forces
4. **Defense is stronger**: Defense naturally has advantage; offense requires superiority

## Sun Tzu - The Art of War (c. 500 BCE)

### Core Philosophy

**Victory without fighting**: The best general wins without engaging in battle.

### Key Principles

1. **Know yourself and your enemy**: "If you know the enemy and know yourself, you need not fear the result of a hundred battles."
2. **Deception**: "All warfare is based on deception. When able, appear unable. When active, appear inactive."
3. **Attack strategy first**: "The best policy is to attack the enemy's strategy, next their alliances, then their army, and worst of all, their cities."
4. **Avoid strength, attack weakness**: "Water shapes its course according to the nature of the ground over which it flows."

### The Five Factors

1. **Moral Law**: Causes people to be in harmony with their ruler
2. **Heaven**: Weather, seasons, timing
3. **Earth**: Terrain, distances, danger points
4. **Commander**: Wisdom, sincerity, benevolence, courage, strictness
5. **Method and Discipline**: Organization, chain of command, logistics

### Strategic Attacks

**Order of preference**:
1. Attack the enemy's strategy
2. Break their alliances
3. Attack their army
4. Besiege walled cities (last resort, worst option)

## Jomini - The Art of War (1838)

### Core Concepts

**Lines of Operation**: The strategic direction of military forces toward the enemy's decisive point.

**Key Principles**:
- Strategy determines where to act; tactics determine how to act
- Always attack the decisive point
- Maintain interior lines (shorter communication between your own forces)
- Strategic objective: Enemy's army, not territory

## Liddell Hart - Strategy (1954)

### Indirect Approach

**Core thesis**: The most effective strategy attacks the unexpected.

**Key principles**:
- Dislocate enemy's balance before destroying forces
- Psychological and physical effects combined
- Exploit line of least expectation
- Maintain freedom of action

## Modern Strategic Frameworks

### OODA Loop (Boyd, 1975)

**Observe-Orient-Decide-Act cycle**:
1. **Observe**: Gather information
2. **Orient**: Filter through culture, experience, new information
3. **Decide**: Select course of action
4. **Act**: Execute decision

**Strategic implication**: Faster OODA cycles create advantage by confusing and disorienting enemy.

### DIME Framework

**Elements of National Power**:
- **D**iplomatic: Alliances, negotiations, international pressure
- **I**nformation: Propaganda, cyber operations, media
- **M**ilitary: Force projection, deterrence, coercion
- **E**conomic: Sanctions, aid, trade policies

### PMESII (Operational Environment)

**Variables to analyze**:
- **P**olitical: Government stability, power structures
- **M**ilitary: Force capabilities, intentions
- **E**conomic: Economic health, infrastructure
- **S**ocial: Demographics, culture, social tensions
- **I**nformation: Media, information flows, cyber
- **I**nfrastructure: Transportation, communications, utilities

## Applying Classic Theory

### When to Reference Clausewitz
- Analyzing complex political-military conflicts
- Understanding friction and uncertainty
- Identifying centers of gravity
- Planning strategic objectives vs tactical actions

### When to Reference Sun Tzu
- Deception and information warfare
- Psychological operations
- Avoiding direct confrontation
- Exploiting enemy weaknesses

### When to Reference Modern Frameworks
- Contemporary military operations
- Multi-domain operations (cyber, space, information)
- Coalition and alliance operations
- Complex adaptive environments

### Integration Guidelines

Combine multiple theorists based on scenario:
- **Sun Tzu + Liddell Hart**: Indirect approach with deception
- **Clausewitz + OODA**: Managing friction while maintaining tempo
- **DIME + PMESII**: Whole-of-government approach
- **Sun Tzu + Cyber**: Modern information operations

**Warning**: Don't quote classical authors in isolation. Contextualize for modern technology and circumstances. Ancient principles endure, but applications evolve.
