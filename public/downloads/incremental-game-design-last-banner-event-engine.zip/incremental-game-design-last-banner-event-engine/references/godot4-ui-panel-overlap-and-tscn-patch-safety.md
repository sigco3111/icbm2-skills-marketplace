# Godot 4 UI 패널 겹침 + tscn patch 안전 패턴 (Last Banner v3.1, 2026-07-16)

> 사용자가 Godot 4 UI 작업에서 **반복 지적한 2가지 클래스**:
> (1) 패널이 캐릭터/차트/날씨창과 겹침
> (2) tscn `replace_all=true`로 파일 폭파
>
> 이 reference는 두 클래스의 **순차적 디버깅 절차 + 안전 규칙**을 명시한다. 자동 진행 게임의 모든 UI 작업에서 반복 적용 가능.

## 의도

게임 UI는 패널 5~10개 (차트, 모달, 상세, 휘장, Roster, 자원바, 결정 큐, 버튼 행) 가 1280×720 안에 들어야 한다. **겹침은 사용자가 가장 즉각적으로 발견하는 버그**.

## 겹침 원인 3가지

### ① 패널이 부모 Control 4면을 정확히 모름

대부분 패널은 `PanelContainer`나 `Control`이고 다음 4 속성만으로 위치 결정:
- `anchor_left/top/right/bottom` — 0~1 사이 비율 (Control 부모 대비)
- `offset_left/top/right/bottom` — 픽셀 단위 보정

혼동 패턴:
- `anchor_left=0, anchor_top=0, anchor_right=0, anchor_bottom=0` → 좌상단 픽셀 고정 (가장 흔한 실수)
- `anchor_left=0, anchor_top=1, anchor_right=0, anchor_bottom=1` → 좌하단 고정
- 4 anchor 중 하나라도 다르면 anchor가 깨짐

⇒ **모든 패널은 4 anchor + 4 offset을 명시적으로** 작성.

### ② 부모와 자식 사이 z-order + CanvasLayer 레이어링 혼합

Godot 4 z-order 규칙:
- **CanvasLayer.layer** 값 (숫자 클수록 위)
- 같은 CanvasLayer 안 → 트리 순서 (나중에 추가된 게 위)
- `mouse_filter` — 자식 Control 위에 부모 Control이 가려도 mouse_event는 따로 흐름

⇒ **GameView Control은 z=0, 모달은 CanvasLayer z=10, 차트는 별도 layer=z=1, 토스트는 z=20** 식 명시적 분리.

### ③ Text/Label이 같은 Control 안에 chart와 함께 있을 때

풍경도 안에 차트 + 휘장 텍스트를 같은 `Control` 자식으로 두면 둘이 같은 좌표 평면. 휘장이 길면 차트와 겹침.

⇒ **텍스트와 차트는 별도 Panel + 별도 영역**.

## 디버깅 4단계 절차 (v3.1.1 → 3.1.5 적용)

### 1단계: 어떤 패널이 겹치는지 가시화

스크린샷에서 빨간 박스/화살표가 가리킨 두 패널 확인:
- PanelContainer A (tsx 파일 + line)
- PanelContainer B (tsx 파일 + line)

tscn에서 두 패널의 `parent=` 경로 + anchor + offset 모두 작성. 동일 부모에 있는지 다른 부모인지 결정.

### 2단계: 두 패널의 위치를 트리에서 시각화

```
ManorDashboard
├ ManorTitle (PanelContainer, anchor=...)
└ ManorScene (PanelContainer, size_flags_vertical=3)
   └ SceneHost (Control, mouse_filter=2)
      ├ SceneRoot (Node2D, 캐릭터 sprite 5명)
      ├ ChartCard (PanelContainer) ← 사용자 지적
      └ DetailPanel (PanelContainer) ← 사용자 지적
```

### 3단계: 해결 옵션 3가지 중 선택

| 옵션 | 사용 시기 |
|---|---|
| **A. 한 패널 좌표 이동** (anchor 변경) | 두 패널의 부모가 다를 때 (각자 부모 영역이 있음) |
| **B. 두 패널을 같은 부모에서 분리** (HBox/VBox) | 두 패널을 같은 줄 또는 다른 줄에 분리할 때 (v3.1.4에서 채택) |
| **C. 한 패널을 보이지 않게** (visible=false) | 패널 자체가 불필요할 때 |

**불변량**:
- 텍스트 라벨은 chart/card **바깥** (별도 Panel 또는 별도 Label) — chart 안에 텍스트 넣지 않음
- 모든 패널 anchor는 0~1 비율 + offset 명시
- CanvasLayer.layer는 절대 겹치지 않게 (0/1/10/20/100 등 정수 분리)

### 4단계: LB_VERIFY + .app 빌드 + 시각 확인

```gdscript
print("[12.5.5] 차트 검증")
var chart_canvas: Control = get_node_or_null("ManorDashboard/CenterRoot/LeftColumn/ChartRow/ChartCard/ChartCanvas") as Control
if chart_canvas:
    chart_canvas.queue_redraw()
    await get_tree().process_frame
    print("  ✓ ChartCanvas 노드 존재: %s" % str(chart_canvas.size))
```

`.app` 재빌드 후 `open ~/work/<game>/build/<game>.app` — 사용자에게 스크린샷 요청 → 그래도 겹치면 1단계로 회귀.

## tscn patch 안전 규칙 (`replace_all` 사고 방지)

v3.1.4에서 `replace_all=true`로 manor_dashboard.tscn 폭파 — `manor_title`, `DetailPanel`, `VisitorCard`, `QuickStatsCard`, `BottomRowInColumn`, `Roster*` 등 모두 사라짐.

### 규칙 1: `replace_all=true` 사용 X

대부분 tscn 파일들이 같은 패턴 (Panel, Button, Label 등)이라 `replace_all=true`가 **의도치 않게 다른 노드까지 삭제**. **반드시 unique anchor + context 포함**:

```python
# 옛 방식 (unique 매치 가능)
old_string = "script = ExtResource(\"1_roster\")\n\n[node name=\"DimBG\" type=\"ColorRect\" parent=\".\"]"
new_string = "script = ExtResource(\"1_roster\")\n\n[node name=\"XButton\" type=\"Button\" parent=\".\"]\n... ...\n\n[node name=\"DimBG\" type=\"ColorRect\" parent=\".\"]"

# 옛 방식 forbidden — 항상 unique context
old_string = "[node name=\"ChartCard\" type=\"PanelContainer\""   # ← 4~5개 노드 매치 → 폭파
```

### 규칙 2: 패치 후 항상 `git status --short` 확인

```bash
git status --short | wc -l          # 추가/삭제 줄 수 확인
git diff --stat scenes/<file>.tscn  # 큰 diff 면 폭파 의심
```

diff 줄 수가 **의도한 변경의 2배 이상**이면 `git checkout -- scenes/<file>.tscn` 으로 복구 후 `write_file`로 깨끗하게 재작성.

### 규칙 3: 폭파 후 복구 — `write_file` 전체 재작성이 안전

```python
# 잘못된 patch 후 폭파 확인되면:
# 1) patch 전 git 버전으로 checkout
# 2) 동일 내용으로 fresh write_file (전체 재작성)
```

v3.1.4 복구 방법 — `manor_dashboard.tscn`의 모든 노드 (BG, CenterRoot, LeftColumn, ManorTitle+TitleLabel, ManorScene+SceneHost+SceneRoot+DetailPanel+VBox, BottomRowInColumn+VisitorCard+QuickStatsCard, RightColumn+RosterTitle+RosterList+RosterScroll+RosterVBox) 를 통째로 재작성.

### 규칙 4: 같은 노드명 부모가 다른 위치에 있을 때 unique context 사용

예: ChartCard는 같은 tscn 안에서 여러 위치에 있을 수 있음 (Legacy와 새로 추가). patch 시 **anchor/offset 2~3줄까지 unique context 포함**:

```python
old_string = """[node name="ChartCard" type="PanelContainer" parent="CenterRoot/LeftColumn/ManorScene/SceneHost"]
anchor_left = 0.0
anchor_top = 0.0
anchor_right = 0.0
anchor_bottom = 0.0
offset_left = 16.0
offset_top = 12.0
offset_right = 220.0
offset_bottom = 110.0
mouse_filter = 0"""
new_string = """[node name="ChartCard" type="PanelContainer" parent="CenterRoot/LeftColumn/ChartRow"]
custom_minimum_size = Vector2(220, 0)
mouse_filter = 0"""
```

## GDScript 파스 오타 — 5종 디버그 체크리스트

v3.1.5에서 다음 패턴 반복 발생:

### 오타 1: `[...])` — `]` 닫고 `)` 추가

```gdscript
# ❌ 파스 에러
chart_row_label.text = "..." % [int(history[-1].gold), int(history[-1].food)])

# ✓
chart_row_label.text = "..." % [int(history[-1].gold), int(history[-1].food)])
```

### 오타 2: `var ... = history[-1]` + 그 줄에 안 닫음

```gdscript
# ❌ 뒷줄에서 함수 호출 끊김
var last: Dictionary = history[-1]
chart_row_label.text = "..." % [last.gold, last.food]

# ✓
var last_gold: int = int(history[-1].gold)
var last_food: int = int(history[-1].food)
chart_row_label.text = "..." % [last_gold, last_food]
```

### 오타 3: `print(...) % (a, b)` — 다중 인자 미지원

```gdscript
# ❌ 파스 에러
print("... (a=%s, b=%s)" % ("OK" if a else "NULL", "OK" if b else "NULL"))

# ✓ GDScript의 % 는 단일 위치 인자만 받음 — 변수로 분리
var a_state: String = "OK" if a else "NULL"
var b_state: String = "OK" if b else "NULL"
print("... (a=%s, b=%s)" % [a_state, b_state])
```

### 오타 4: `TextureButton.stretch=true` / `expand_icon=true` — Godot 4에 존재 X

```gdscript
# ❌ Invalid assignment of property 'stretch' with value of type 'bool'
btn.stretch = true
btn.expand_icon = true

# ✓ Godot 4의 TextureButton에 그런 속성 없음 — 제거
btn.ignore_texture_size = true
btn.size = ...
btn.custom_minimum_size = btn.size
```

### 오타 5: `theme_override_font_sizes/font_size = 12` — 할당 불가

```gdscript
# ❌ 파스 에러
label.theme_override_font_sizes/font_size = 12

# ✓ 메서드 호출
label.add_theme_font_size_override("font_size", 12)
```

## 표준 UI 안전 패턴 5가지

### 패턴 1: 패널 추가 시 항상 write_file로 직접 (anchors + offsets 명시)

```python
# 안전한 새 패널 정의 (모든 anchor + offset 명시)
content = f"""[node name=\"{name}\" type=\"PanelContainer\" parent=\"{parent}\"]
anchor_left = {anchor_left}
anchor_top = {anchor_top}
anchor_right = {anchor_right}
anchor_bottom = {anchor_bottom}
offset_left = {offset_left}
offset_top = {offset_top}
offset_right = {offset_right}
offset_bottom = {offset_bottom}
mouse_filter = 0
"""
```

### 패턴 2: 동적 노드 검색 시 null 가드

```gdscript
var canvas: Control = get_node_or_null("...") as Control
if canvas:
    canvas.queue_redraw()
    print("  ✓ ChartCanvas 노드 존재: %s" % str(canvas.size))
else:
    print("[WARN] 차트 노드 없음")
```

### 패턴 3: 패딩 + 라인 영역 분리

```python
# ChartCanvas 내부 패딩 — ChartTitle 영역 (0~22) + 라인 영역 (22~끝) 분리
offset_top = 26        # 위쪽 26px = 라벨 영역
offset_bottom = -6    # 아래쪽 6px = 차트 카드 padding
# ChartTitle 영역은 anchor_left=0, anchor_right=1, offset_bottom=22 (라벨 0~22)
# ChartCanvas offset_top=26 → 라벨 22 아래에서 시작 (4px 여유)
```

### 패턴 4: 패딩 줄여서 라인 영역 활용

```gdscript
# 텍스트 없는 차트 (v3.1.5) → padding 줄임 (28,14 → 20,12)
# 텍스트 있는 차트 (v3.1.3) → padding 더 줌 (28,14)
var padding := Vector2(20, 12) if not has_chart_title else Vector2(28, 14)
```

### 패턴 5: HBox로 텍스트 + 차트 분리

```python
# 차트 + 자원추이 텍스트는 별도 자식 (v3.1.5)
[node name="ChartRow" type="HBoxContainer" parent="..."]
custom_minimum_size = Vector2(0, 92)
[node name="ChartTitleLabel" type="Label" parent=".../ChartRow"]
text = "📈 자원 추이"
size_flags_horizontal = 3          # 가변 (남은 공간 차지)
[node name="ChartCard" type="PanelContainer" parent=".../ChartRow"]
custom_minimum_size = Vector2(220, 0)
mouse_filter = 0
```

## 적용 게임 (재사용 시점)

- Godot 4 게임에서 **2개 이상 Control/Panel이 같은 line 영역에 있을 때** (HUD, 상세 화면, 오버레이)
- **tscn 파일에서 여러 노드 추가/이동/이름변경 작업** 시
- **GDScript에 새 함수 또는 새 변수 추가** 시 파스 에러 디버깅
- **새 게임 화면**을 5종 이상 패널로 구성할 때 (타이틀+메인+HUD+모달+토스트)

## 안티패턴

| 안티패턴 | 결과 | 대안 |
|---|---|---|
| `replace_all=true`로 tscn 작업 | 파일 폭파 | unique context (anchor 2~3줄 포함) |
| `print(...) % (a, b)`로 디버그 | 파스 에러 | `var a_str: String = ...; print("%s" % [a_str])` |
| chart 안에 text label 함께 두기 | 그래프/텍스트 겹침 | chart Card + text Label 별도 Panel/HBox |
| `anchor_top=0, anchor_bottom=0` (생략 시 기본값) | 좌상단 박힘 | 항상 4 anchor 명시 |
| 같은 CanvasLayer에 모든 overlay | 뒤에 있는 게 가림 | 모달=layer=10, 토스트=20, 인게임=0, 별도=90 |

## 빠른 체크리스트 (tscn 변경 후)

- [ ] `git status --short` — 추가/삭제 줄이 의도 범위 안인지 확인
- [ ] `git diff --stat` — 큰 diff 면 `git checkout` + `write_file`로 깨끗하게 재작성
- [ ] 모든 새 노드 4 anchor 명시 확인
- [ ] 패딩 + 라벨 영역 분리 (텍스트 차트 안 넣기)
- [ ] LB_VERIFY에 새 검증 단계 추가 + `.app` 빌드 후 사용자 시각 확인

## 다음 확장

- **인터랙션 충돌** (예: 캐릭터 호버 + 차트 클릭) — v3에서 호버만 처리. 향후 click+drag 충돌 시 새 reference 추가
- **반응형 UI** (모바일/태블릿 viewport) — 현재 desktop 1280×720만 가정. anchor 비율 + offset 픽셀 혼합 사용 시 viewport 변경 시 깨짐
- **모달 Z-order 통일 규칙** — 현재 layer=100. 다른 게임에서 layer=50+layer=200 같은 다중 모달 추가 시 표준 필요
