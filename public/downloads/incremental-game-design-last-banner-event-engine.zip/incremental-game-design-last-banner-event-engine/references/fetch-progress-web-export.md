# Godot 4 Web Export + Vercel — Asset Fetch Progress 함정 3가지 (Last Banner 9차, 2026-07-16)

> **증상**: "자산 가져오기 (CDN)" 버튼이 활성화되어 클릭은 되는데, ProgressBar가 0%에서 멈춤. status_label에 "자산 다운로드 시작" 토스트만 뜨고 진행 안 됨. 2510개 파일이 매니페스트에 있는데 0% 그대로.

**근본 원인 3가지가 동시 작용** — 첫 번째만 고치면 두 번째, 세 번째에서 또 멈춤. 모두 처리해야 함.

## 함정 #1 — 시그널이 콜백 안에서만 emit됨

**문제**: `fetch_all(progress_cb)` 시그니처에서 `fetch_progress.emit(...)`이 콜백 분기 안에만 있음.

```gdscript
# ❌ 진행률이 안 보임 — 콜백 없으면 시그널 미발생
func fetch_all(progress_cb: Callable = Callable()) -> void:
    var total := get_total_size()
    for cat_name in list_categories():
        for rel_path in files:
            _download_single(base_url, rel_path, progress_cb, total)
            # fetch_progress.emit은 _download_single의 콜백 호출 안에만 있음

func _download_single(base_url, rel_path, progress_cb, total):
    # ... HTTP 다운로드 ...
    if progress_cb.is_valid():        # ← 분기 안에서만 emit
        progress_cb.call(_loaded_bytes, total)
    _maybe_all_done(progress_cb, total)
```

```gdscript
# ✓ 시그널을 콜백과 분리해서 항상 emit
func fetch_all(progress_cb: Callable = Callable()) -> void:
    for cat_name in list_categories():
        for rel_path in files:
            _download_single(base_url, rel_path, progress_cb, total)

func _download_single(base_url, rel_path, progress_cb, total):
    # ... HTTP 다운로드 ...
    if progress_cb.is_valid():
        progress_cb.call(_loaded_bytes, total)
    fetch_progress.emit(_loaded_bytes, total)  # ← 항상 emit
    _maybe_all_done(progress_cb, total)
```

**교훈**: Godot 4의 `Callable()` (디폴트 인자) 검증은 `is_valid()` false. 호출자가 콜백 안 넘기면 시그널이 emit 안 됨. **시그널은 항상 emit, 콜백은 옵션**.

## 함정 #2 — 진행률 계산이 사이즈 기반인데 estimate가 0 반환

**문제**: `get_file_size_estimate(rel_path)`가 `categories/[cat]/sizes[rel]` dict에서 찾는데, `.import` 메타파일 제외 시 키가 없으면 0 반환 → 누적 사이즈 0 → 진행률 0%.

```gdscript
# ❌ _loaded_bytes 누적 안 됨
func get_file_size_estimate(rel_path: String) -> int:
    for cat_name in cats:
        var sizes: Dictionary = cat.get("sizes", {})
        if sizes.has(rel_path):
            return int(sizes[rel_path])   # ← 키 없으면 0
    return 0
```

**해결 A**: 사이즈 dict가 import 메타도 포함하므로 import 제외한 실제 파일은 키가 없을 수 있음 → **estimate 무시**.

**해결 B (더 좋음)**: 진행률 = `_fetch_done_files / _fetch_total_files` **파일 수 기반**. 사이즈 dict 의존성 제거.

```gdscript
# ✓ 파일 수 기반 진행률
var _fetch_total_files: int = 0
var _fetch_done_files: int = 0

func fetch_all(progress_cb: Callable = Callable()) -> void:
    _fetch_total_files = 0
    _fetch_done_files = 0

    # 큐 수집
    for cat_name in list_categories():
        var cat: Dictionary = get_category(cat_name)
        var files: Array = _filter_real_files(cat.get("files", []))
        for rel_path in files:
            queue.append({...})
    _fetch_total_files = queue.size()

    # 시그널 emit
    fetch_progress.emit(_fetch_done_files, _fetch_total_files, _compute_pct())
    if progress_cb.is_valid():
        progress_cb.call(_fetch_done_files, _fetch_total_files, _compute_pct())

func _compute_pct() -> float:
    return 100.0 * float(_fetch_done_files) / float(max(_fetch_total_files, 1))
```

## 함정 #3 — .import 메타파일이 매니페스트에 포함 → 404 spam

**문제**: Godot 4 export 시 각 자산마다 `.import` 메타파일이 자동 생성되어 매니페스트(`asset_host.json`)에 들어감. CDN에는 원본만 있고 `.import`는 없음 → 404. 매번 HTTP 요청이 낭비되고, **404 응답에서 진행률이 갱신 안 되어 0%에 멈춘 것처럼 보임**.

```bash
# asset_host.json 발췌
"audio": {
  "files": [
    "audio/music/battle-epic.ogg",
    "audio/music/battle-epic.ogg.import",   # ← CDN에 없음 (404)
    "audio/music/battle.ogg",
    "audio/music/battle.ogg.import",        # ← CDN에 없음 (404)
    ...
  ]
}
```

**해결**: fetch 시 `.import`/`.uid` 메타파일 제외.

```gdscript
# ✓ .import / .uid 제외
func _filter_real_files(files: Array) -> Array:
    var result: Array = []
    for f in files:
        if typeof(f) != TYPE_STRING:
            continue
        if f.ends_with(".import") or f.ends_with(".uid"):
            continue
        result.append(f)
    return result

func fetch_all(progress_cb: Callable = Callable()) -> void:
    for cat_name in list_categories():
        var cat: Dictionary = get_category(cat_name)
        var files: Array = _filter_real_files(cat.get("files", []))  # ← 적용
        # ...
```

**추가**: 404도 `_fetch_done_files += 1`로 카운트해서 진행률이 절대 멈추지 않게 (실패도 진행):

```gdscript
func _on_async_done(...):
    if result == HTTPRequest.RESULT_SUCCESS and response_code == 200:
        # 성공 — 파일 저장
        _fetched[rel_path] = local_path
        _fetch_done_files += 1
    else:
        # 실패도 진행률에 포함 (멈춤 방지)
        _fetch_done_files += 1
    fetch_progress.emit(_fetch_done_files, _fetch_total_files, _compute_pct())
```

## 함정 #4 — sequential 다운로드 (2510파일 = 매우 느림)

**문제**: `fetch_all`이 한 번에 1개씩 다운로드. 2510파일 × 평균 0.5초 = 20분 이상 걸림. 사용자는 멈춘 것으로 인식.

**해결**: 동시 다운로드 (concurrency 4).

```gdscript
const FETCH_CONCURRENCY := 4

func fetch_all(progress_cb: Callable = Callable()) -> void:
    # ... 큐 수집 ...
    var pending: Array = []
    for item in queue:
        if _fetched.has(item.rel_path):
            _fetch_done_files += 1
        else:
            pending.append(item)
    fetch_progress.emit(_fetch_done_files, _fetch_total_files, _compute_pct())

    if pending.is_empty():
        all_assets_ready.emit()
        return
    var batch_size: int = min(FETCH_CONCURRENCY, pending.size())
    _fetch_active_count = 0
    for i in range(batch_size):
        if i < pending.size():
            _start_next_fetch(pending, i, progress_cb)

func _on_async_done(...):
    # ... 처리 ...
    _on_one_done(progress_cb, queue, idx)

func _on_one_done(progress_cb, queue, idx):
    _fetch_active_count -= 1
    var next_idx: int = idx + FETCH_CONCURRENCY  # ← 4칸씩 건너뛰기
    if next_idx < queue.size():
        _start_next_fetch(queue, next_idx, progress_cb)
    elif _fetch_active_count <= 0:
        fetch_progress.emit(_fetch_done_files, _fetch_total_files, 100.0)
        all_assets_ready.emit()
```

## UI 패턴 — ProgressBar + status_label

```gdscript
# main.tscn — ProgressBar 추가
[node name="FetchProgress" type="ProgressBar" parent="UI"]
anchor_left = 0.15
anchor_top = 0.45
anchor_right = 0.85
anchor_bottom = 0.48
visible = false
max_value = 100.0
value = 0.0
show_percentage = true

# main.gd
@onready var fetch_progress: ProgressBar = $UI/FetchProgress

func _on_fetch_pressed() -> void:
    fetch_button.disabled = true
    if fetch_progress:
        fetch_progress.visible = true
        fetch_progress.value = 0
    AssetRegistry.fetch_all()  # 콜백 없이 — 시그널로 받음

func _on_fetch_progress(done: int, total: int, pct: float) -> void:
    status_label.text = "자산 다운로드: %d / %d 파일 (%.0f%%)" % [done, total, pct]
    if fetch_progress:
        fetch_progress.value = pct

func _on_assets_ready() -> void:
    fetch_button.disabled = false
    if fetch_progress:
        fetch_progress.value = 100
        fetch_progress.visible = false
```

## 시그널 시그니처 결정 — 함수 호출자 위치에 따라 다르게

| 호출자 | 시그널 emit 위치 | 권장 |
|---|---|---|
| `AssetRegistry.fetch_all()` (시그널 구독) | 콜백 + 시그널 **둘 다** emit | OK |
| `AssetRegistry.fetch_file(path, callback)` (콜백) | 콜백 안에서만 | OK (단일 파일) |
| `AssetRegistry.fetch_category(name)` | 시그널만 | OK |

**판단 기준**: 시그널 구독자가 UI 갱신용 → emit 필수. 단일 파일 fetch_file은 오디오 lazy load처럼 호출자가 콜백으로 처리 → 콜백만 OK.

## LB_VERIFY 검증 절차

```gdscript
# 시그널 연결 확인
var conns: int = AssetRegistry.fetch_progress.get_connections().size()
assert(conns >= 1, "main.gd에서 fetch_progress 시그널 연결 필요")

# fetch_category 호출 가능 (실제 HTTP는 헤드리스에서 안 함)
AssetRegistry.fetch_category("units")  # 2.8MB, 가장 작은 카테고리
assert(AssetRegistry.has_method("fetch_category"))
assert(AssetRegistry.has_method("fetch_file"))

# _filter_real_files 단위 검증
var files: Array = ["a.png", "a.png.import", "b.png", "b.png.uid", "c.png"]
var filtered: Array = AssetRegistry._filter_real_files(files)
assert(filtered.size() == 3)  # a/b/c만
```

**헤드리스에서 `fetch_all` 직접 호출은 hang** (HTTP 요청이 무한 대기). `_filter_real_files`/`fetch_category` 같은 단위 메서드만 검증. 실제 fetch는 라이브에서만.

## 요약 — 4가지 동시 적용

| 함정 | 증상 | 해결 |
|---|---|---|
| #1 시그널이 콜백 안 | 시그널 미발생 → 0% | `fetch_progress.emit(...)`을 콜백 분기 밖으로 |
| #2 사이즈 estimate 0 | 누적 사이즈 0 → 0% | 파일 수 기반 (`done/total`) |
| #3 .import 404 | 50% 시간 낭비 + 진행률 갱신 실패 가능 | `_filter_real_files()` |
| #4 sequential | 20분+ 소요 | `FETCH_CONCURRENCY=4` 동시 |

**4가지 모두 적용해야 ProgressBar가 0% → 100%로 정상 동작**. 하나만 빠지면 0%에 멈춤 또는 hang.

## 흔한 진단 실수

**"asset_host.json이 잘못된 거 아닌가?"** — 가장 먼저 의심하기 쉬우나, **manifest 자체는 정상**. 매니페스트에서 `.import`가 들어있는 게 정상 (Godot export 도구 출력). `.import`를 받는 클라이언트가 처리해야 함.

**"fetch_all에 콜백 안 넘겨서 그런 거 아닌가?"** — 맞을 수 있지만, 진짜 문제는 **시그널이 콜백 안에서만 emit된다는 설계 자체**. emit이 한쪽 분기에만 있으면 양쪽 다 깨짐.

**"ProgressBar가 visible인데 value 업데이트가 안 됨"** — `queue_redraw()` 안 한 거. `ProgressBar`는 자체적으로 invalidate하지만 `_process`에서 매 프레임 갱신 안 하면 끊김. 명시적 set + queue_redraw 필요.

**"Web에서는 fetch가 안 됨"** — Vercel `vercel.json`의 COOP/COEP 헤더 (`Cross-Origin-Opener-Policy: same-origin` + `Cross-Origin-Embedder-Policy: require-corp`) 필요. Godot Web export는 SharedArrayBuffer 쓰는데 이 헤더 없으면 일부 환경에서 hang.

## 적용 확인 (Last Banner 9차, 2026-07-16)

```
[Main] 안전망1(즉시): _on_manifest_loaded 호출
[Main] fetch_button 활성화 완료 (228.4 MB)
→ 사용자가 "자산 가져오기 (CDN)" 클릭
→ ProgressBar 0% → 25% → 50% → 75% → 100% (실제 4개 동시)
→ ✅ 자산 다운로드 완료! (228.4 MB) 토스트
→ fetch_button 다시 활성화
```

전 2510 파일 중 ~1300 (실제 파일)만, 4개 동시, .import 404 0개, ~5분 소요.
