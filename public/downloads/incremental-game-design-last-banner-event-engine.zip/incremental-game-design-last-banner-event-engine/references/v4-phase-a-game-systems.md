># v4.0 Phase A — 게임 시스템 4종 (Last Banner 실전 검증)

> Phase A 4단계: A-4 사건 4종 추가 / A-1 용병 9-class tier / A-2 왕조 court (CK3 양식) / A-3 빌딩 4종. 모두 2026-07-19~20 한 세션에서 구축 + LB_VERIFY 17단계 통과.

## Phase A 전체 그림

| 단계 | 시스템 | 핵심 API | 시그널 | LB_VERIFY 단계 |
|---|---|---|---|---|
| A-4 | 사건 4종 | `EventEngine._maybe_*` | (push → DecisionQueue) | [8.6] |
| A-1 | 용병 Roster | `MercenaryData` + `GameWorld.roster` | 3종 (joined/left/injured) | [8.7] |
| A-2 | 왕조 court | `GameWorld.court` + 4종 스탯 | 3종 (added/removed/succession_changed) | [8.8] |
| A-3 | 빌딩 4종 | `GameWorld.buildings` + 일간 보너스 | (없음 — 일간 변동) | [8.9] |

## A-1. 용병 Roster — 9-class tier 시스템

### autoload/mercenary_data.gd (신규, 9-class 카탈로그)

```gdscript
extends Node
## 용병 데이터 카탈로그 — 9-class tier 시스템 (v1 검증 복원)

const CLASSES := {
    "bowman":    { "tier": 1, "base_wage": 5,  "labels": ["궁수", "궁병"],     "portrait_faction": "humans" },
    "swordsman": { "tier": 1, "base_wage": 4,  "labels": ["검사", "병사"],     "portrait_faction": "humans" },
    "pikeman":   { "tier": 1, "base_wage": 5,  "labels": ["창병", "척후"],     "portrait_faction": "humans" },
    "sergeant":  { "tier": 2, "base_wage": 12, "labels": ["하사관"],           "portrait_faction": "humans" },
    "fencer":    { "tier": 2, "base_wage": 10, "labels": ["페렌스", "결투자"], "portrait_faction": "humans" },
    "crossbow":  { "tier": 2, "base_wage": 11, "labels": ["석궁병"],           "portrait_faction": "humans" },
    "cavalry":   { "tier": 2, "base_wage": 15, "labels": ["기병"],             "portrait_faction": "humans" },
    "captain":   { "tier": 3, "base_wage": 30, "labels": ["선봉장", "대장"],   "portrait_faction": "humans" },
    "paladin":   { "tier": 3, "base_wage": 35, "labels": ["성기사"],           "portrait_faction": "humans" },
}
const FIRST_NAMES := ["에드윈", "린", "그림발트", "엘가르", "토르바르", ...]   # 25개
const TITLES_BY_TIER := { 1: ["신참", "견습", "풋내기"], 2: ["베테랑", "숙련", "경험자"], 3: ["전설", "영웅", "명장"] }
```

### GameWorld.roster 시스템

```gdscript
signal mercenary_joined(mercenary: Dictionary)
signal mercenary_left(mercenary: Dictionary, reason: String)
signal mercenary_injured(mercenary: Dictionary, days: int)

var roster: Array = []   # 모든 용병 (alive/dead)
var _next_mercenary_id: int = 1000

# API
func offer_mercenary(class_id: String) -> Dictionary: ...   # dict 생성 (roster 미포함)
func add_mercenary(m: Dictionary) -> void: ...             # roster.append + 시그널
func dismiss_mercenary(id: int, reason: String) -> bool: ... # alive=false + 시그널
func injure_mercenary(id: int, days: int) -> bool: ...
func alive_mercenaries() -> Array: ...                      # alive=true 필터
func get_mercenary_by_id(id: int) -> Dictionary: ...
func total_wage_burden() -> int: ...                       # sum(wage_demand)
func reset_roster() -> void: ...
```

### EventEngine 통합

```gdscript
# 16시간마다 tier 가중치 결정 (60/30/10)
const MERCENARY_OFFER_INTERVAL_MIN := 960
func _maybe_mercenary_offer(_game_time: int) -> void:
    if _decisions_today >= DECISION_MAX_PER_DAY: return
    if GameWorld.alive_mercenaries().size() >= 12: return  # 만원
    if randf() > 0.6: return
    var tier_roll: float = randf()
    var class_pool: Array
    if tier_roll < 0.6: class_pool = ["bowman", "swordsman", "pikeman"]  # 60%
    elif tier_roll < 0.9: class_pool = ["sergeant", "fencer", "crossbow", "cavalry"]  # 30%
    else: class_pool = ["captain", "paladin"]  # 10%
    var class_id: String = class_pool[randi() % class_pool.size()]
    var m: Dictionary = GameWorld.offer_mercenary(class_id)
    DecisionQueue.push("MERCENARY_OFFER", {
        "title": "⚔️ 용병 자원 도착",
        "description": "%s (%s, Tier %d)가 합류를 제안합니다. 일급 %d골드, 충성도 %d." % [...],
        "choices": [
            { "id": "accept", "label": "✅ 수용 (일급 %d골드)" % m.wage_demand, "result": "ACCEPT_MERCENARY" },
            { "id": "reject", "label": "❌ 거절", "result": "REJECT_MERCENARY" },
        ],
        "mercenary": m,  # main.gd가 _apply_result에서 add_mercenary 호출
    }, DecisionQueue.Priority.LOW)
    _decisions_today += 1

# 8시간마다 충성도 자동 이탈 체크
func _check_mercenary_loyalty() -> void:
    var deserter_ids: Array = []
    for m in GameWorld.roster:
        if m.alive and m.loyalty < 30: deserter_ids.append(m.id)
    for id in deserter_ids:
        GameWorld.dismiss_mercenary(id, "충성도 저하로 이탈")
```

### GameWorld.apply_daily_economy 확장

```gdscript
func apply_daily_economy() -> void:
    # 일급 자동 차감
    var wage: int = total_wage_burden()
    if wage > 0: modify_resource("gold", -wage)
    # 식량 추가 소비 (용병 1명당 2/일)
    var consumed: int = population / 10 + alive_mercenaries().size() * 2
    modify_resource("food", -consumed)
    # 부상 회복 + 경험 누적
    for m in roster:
        if m.alive and m.injured_days > 0: m.injured_days -= 1
        if m.alive: m.experience += get_total_exp_bonus()  # 건물 보너스 연동
```

### 결과 코드 (7종) — GameWorld.RESULT_EFFECTS

```gdscript
"ACCEPT_MERCENARY":      { "log": "용병 수용" },      # main.gd _apply_result에서 payload.mercenary로 add_mercenary
"REJECT_MERCENARY":      { "log": "용병 거절" },
"DISMISS_MERCENARY":     { "log": "용병 해고" },      # payload.mercenary_id로 dismiss_mercenary
"MERCENARY_PAY_BONUS":   { "gold": -30, "prosperity": +5, "log": "..." },  # 전원 loyalty +10
"MERCENARY_TRAINING":    { "gold": -20, "prosperity": +2, "log": "..." },  # 전원 exp +5
"MERCENARY_INJURY_HEAL": { "gold": -15, "log": "..." },                  # 전원 injured_days -3
"MERCENARY_DESERTS":     { "log": "..." },                              # 자동 이탈 (EventEngine)
```

## A-2. 왕조 / 후계자 — CK3 양식

### GameWorld.court 시스템

```gdscript
signal person_added(person: Dictionary)
signal person_removed(person: Dictionary, reason: String)
signal succession_changed(new_heir: Dictionary)

var court: Array = []            # 모든 인물
var _next_person_id: int = 2000
var dynasty_name: String = ""

# 인물 dict 구조
{
    "id": int,
    "name": String,
    "class": String,            # "영주" / "후계자" / "신하" / "원로" / "기사단장" / "원정대장"
    "age": int,
    "stats": { "martial": int, "stewardship": int, "diplomacy": int, "intrigue": int },  # 4~15
    "loyalty": int,             # 0~100, <30 이탈 위험
    "ambition": int,            # 0~100, >65 배신 위험
    "alive": bool,
    "spouse_id": int,           # -1 = 없음
    "parent_id": int,
    "heir_rank": int,           # 0=영주, 1~3=후계자, -1=신하
    "dynasty": String,
    "portrait_index": int,      # 0~7 Wesnoth portrait 매핑
}

# API
func spawn_initial_court() -> void: ...   # 영주 1 + 후보 3 + 신하 1 = 5명
func _create_person(base_class, heir_rank, parent_id, age_base, loyalty_base) -> Dictionary: ...
func get_person_by_id(id: int) -> Dictionary: ...
func get_lord() -> Dictionary: ...                # heir_rank=0 alive
func get_heirs() -> Array: ...                    # alive && heir_rank>0, sort by rank
func get_vassals() -> Array: ...                  # alive && heir_rank<0
func set_heir_rank(person_id, new_rank) -> bool: ...
func kill_person(person_id, reason) -> bool: ...
func reset_court() -> void: ...
```

### EventEngine 통합

```gdscript
const SUCCESSION_AUDIT_INTERVAL_MIN := 4320  # 3일
func _maybe_succession_audit(_game_time: int) -> void:
    if _decisions_today >= DECISION_MAX_PER_DAY: return
    var heirs: Array = GameWorld.get_heirs()
    if heirs.is_empty(): return
    for h in heirs:
        h.loyalty = clamp(h.loyalty + randi() % 11 - 5, 0, 100)      # ±5
        h.ambition = clamp(h.ambition + randi() % 7 - 3, 0, 100)      # ±3
    var top: Dictionary = heirs[0]
    DecisionQueue.push("SUCCESSION_AUDIT", {
        "title": "👑 후계자 감사",
        "description": "1순위 후보 %s (충성도 %d, 야망 %d) — 유지 / 교체 / 양육" % [top.name, top.loyalty, top.ambition],
        "choices": [
            { "id": "keep", "label": "✓ 유지", "result": "SUCCESSION_KEEP" },
            { "id": "swap", "label": "🔄 1↔2 교체", "result": "SUCCESSION_SWAP" },
            { "id": "nurture", "label": "💝 양육 (골드 -30, 충성도 +10)", "result": "SUCCESSION_NURTURE" },
        ],
        "person_id": top.id,
    }, DecisionQueue.Priority.MEDIUM)
    _decisions_today += 1
    # 배신 위험 감지
    for h in heirs:
        if h.loyalty < 25 and h.ambition > 65 and randf() > 0.5:
            _maybe_heir_betrayal(h); return

func _maybe_heir_betrayal(heir: Dictionary) -> void:
    DecisionQueue.push("HEIR_BETRAYAL", {
        "title": "⚠️ 후계자 배신!",
        "description": "%s이(가) 왕조를 위협 (충성도 %d, 야망 %d)" % [heir.name, heir.loyalty, heir.ambition],
        "choices": [
            { "id": "crusher", "label": "⚔️ 처형 (명성 +5)", "result": "BETRAYAL_CRUSHER" },
            { "id": "banish", "label": "🚪 추방 (명성 -3)", "result": "BETRAYAL_BANISH" },
            { "id": "forgive", "label": "🕊️ 용서 (충성도 +20, 명성 -8)", "result": "BETRAYAL_FORGIVE" },
        ],
        "person_id": heir.id,
    }, DecisionQueue.Priority.CRITICAL)
    _decisions_today += 1
```

## A-3. 빌딩 시스템 — 4종 × max Lv 3

```gdscript
const BUILDING_MAX_LEVEL := 3
const BUILDING_DEFS := {
    "market":         { "name": "시장", "description": "세수 +5/level", "gold_cost_base": 50, "food_cost_base": 30, "effect": { "tax_bonus": 5 } },
    "training_ground": { "name": "훈련장", "description": "용병 경험 +2/level", "gold_cost_base": 40, "food_cost_base": 0, "effect": { "exp_bonus": 2 } },
    "granary":        { "name": "창고", "description": "식량 +10/level", "gold_cost_base": 30, "food_cost_base": 20, "effect": { "food_bonus": 10 } },
    "walls":          { "name": "성벽", "description": "약탈/역병 피해 -10%/level", "gold_cost_base": 80, "food_cost_base": 0, "effect": { "defense_bonus": 10 } },
}
var buildings: Dictionary = {}   # { building_id: level } 0=Lv 0

# API
func reset_buildings() -> void: ...
func can_upgrade(building_id: String) -> bool: return get_building_level(building_id) < BUILDING_MAX_LEVEL
func get_upgrade_cost(building_id: String) -> Dictionary:
    var lvl: int = get_building_level(building_id)
    var def: Dictionary = BUILDING_DEFS[building_id]
    return { "gold": def["gold_cost_base"] * (lvl + 1), "food": def["food_cost_base"] * (lvl + 1) }
func upgrade_building(building_id: String) -> bool: ...  # 골드/식량 차감 + level++
func get_total_tax_bonus() -> int: ...   # 합산
func get_total_food_bonus() -> int: ...
func get_total_exp_bonus() -> int: ...
func get_defense_multiplier() -> float: return max(0.5, 1.0 - 0.1 * get_building_level("walls"))
```

### apply_daily_economy 연동

```gdscript
var tax: int = max(5, prosperity + population / 4) + get_total_tax_bonus()
var harvest: int = max(2, population / 4) + get_total_food_bonus()
```

### EventEngine

```gdscript
const BUILD_CONSTRUCTION_INTERVAL_MIN := 720  # 12시간
func _maybe_build_construction(_game_time: int) -> void:
    if randf() > 0.5: return
    var upgradable: Array = []
    for b in GameWorld.BUILDING_DEFS:
        if GameWorld.can_upgrade(b): upgradable.append(b)
    if upgradable.is_empty(): return
    var building_id: String = upgradable[randi() % upgradable.size()]
    var def: Dictionary = GameWorld.BUILDING_DEFS[building_id]
    var cost: Dictionary = GameWorld.get_upgrade_cost(building_id)
    DecisionQueue.push("BUILD_CONSTRUCTION", {
        "title": "🏗️ %s Lv %d → Lv %d" % [def["name"], GameWorld.get_building_level(building_id), GameWorld.get_building_level(building_id) + 1],
        "choices": [
            { "id": "upgrade", "label": "🔨 건설 (골드 -%d, 식량 -%d)" % [cost["gold"], cost["food"]], "result": "BUILD_UPGRADE" },
            { "id": "skip", "label": "⏭️ 보류", "result": "BUILD_SKIP" },
        ],
        "building_id": building_id,
    }, DecisionQueue.Priority.LOW)
```

## A-4. 사건 4종 추가 (PEASANT/WINTER/MERCHANT/PLAGUE)

| 사건 | 우선순위 | 트리거 | default | 결과 |
|---|---|---|---|---|
| PEASANT_PETITION | LOW | 매일 25% | 거절 (명성 -2) | LOWER: 골드 -20, 명성 +3 |
| WINTER_PREPARATION | MEDIUM | season→winter 1회 | 무시 (겨울 식량 2배) | STOCKPILE/MUSTER/IGNORE |
| MERCHANT_CARAVAN | LOW | 30h마다 40% | 돌려보냄 (명성 -1) | BUY: 골드 -40, 식량 +30 |
| PLAGUE | CRITICAL | 50h마다 5%, 인구>100 | (없음 — 사용자만) | MEDICINE/QUARANTINE/NOTHING |

`EventEngine._maybe_*` + `main.gd _apply_result` 분기 추가. PLAGUE는 population<100이면 skip (조건부 발화 패턴).

## GameManager.start_new_game 통합

```gdscript
func start_new_game(slot: String = "default") -> void:
    # ... 자원 init ...
    GameWorld.reset_history()
    GameWorld.reset_roster()
    GameWorld.reset_court()
    GameWorld.spawn_initial_court()    # 영주 1 + 후보 3 + 신하 1
    GameWorld.reset_buildings()
    # 초기 용병 5명
    for c in ["bowman", "bowman", "swordsman", "pikeman", "sergeant"]:
        var m: Dictionary = GameWorld.offer_mercenary(c)
        GameWorld.add_mercenary(m)
    # ...
```

## LB_VERIFY 4단계 추가

- [8.6] A-4 — 4종 사건 push + 분포 검증 `{LOW: 10, MEDIUM: 2, HIGH: 7}`
- [8.7] A-1 — 9-class / 충성도 이탈 / round-trip
- [8.8] A-2 — court 5명 / SWAP / NURTURE / BETRAYAL_CRUSHER
- [8.9] A-3 — 4종 × Lv 1~3 / 비용 곡선 / round-trip

각 단계 7~10개 assert. 모두 통과 = v4.0.0 자동 진행 + 결정 큐 + 자원 + 시그널 + 영속화 통합 안정.

## 진화 의도

v3.1.x: 사건 4종 (VISITOR/BANDIT/DIPLOMACY/FOOD) + 자동 진행 + 결정 큐 → incremental 핵심 검증
v4.0: 사건 4종 추가 + 용병/왕조/빌딩 3개 시스템 → **incremental + 4X + tycoon** 하이브리드, 게임 깊이 3배

## 적용 게임

- incremental 로그라이크 (Last Banner, 슬레이 더 서바이벌) — 4종 시스템 모두 적용
- tycoon 게임 — 용병만 적용
- 4X 전략 — 왕조 + 빌딩만 적용
- RPG — 용병 + 왕조 (전투원 + 정치) 적용

## 안티패턴

1. **9-class tier 가중치 균등 분할** (1/9씩) → tier 1만 누적. **60/30/10 가중치 필수**
2. **왕조 4종 스탯 모두 동시 가중** → 한 명만 all-stat-15 → 게임 trivial. **3종 가중치 + 1종 약점** 패턴 (예: martial 강 + diplomacy 약)
3. **빌딩 4종 동시 max** → 자원 폭증. 일간 보너스 + 비용 곡선으로 자연스러운 선택 강제
4. **왕조 사망 = 게임 즉시 종료** (인구/식량 0과 동급) → CRITICAL 배신 + 후계자 0만 게임 오버
5. **용병 충성도 <30 즉시 kill** (자연사) → 명시적 dismiss + reason 기록으로 player가 추적 가능

## 관련 참조

- `references/decision-queue-on-off-auto-vs-waiting.md` — 자동 진행 ON/OFF + default 결정 패턴
- `references/apply-result-unification.md` — GameWorld.apply_result 단일 dict 통합
- `incremental-game-design-last-banner-event-engine/references/v4-phase-b-ux-polish.md` — 튜토리얼/사운드/모바일 viewport (다음 단계)
