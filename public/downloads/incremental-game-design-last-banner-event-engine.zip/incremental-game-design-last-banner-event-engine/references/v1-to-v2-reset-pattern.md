# 프로젝트 v1 → v2 리셋 — 컨셉 보존 + 스택 폐기 패턴 (Last Banner)

> 동일한 게임 컨셉을 유지하면서 **기술 스택을 완전히 갈아엎을 때**의 패턴. 컨셉 (자동 진행 + 결정 큐 + 영지 운영 로그라이크)은 보존하고 Web/Vercel/3D 자산/web-export pipeline만 폐기. 신규 폴더에서 클린 부트스트랩 후 GitHub remote 갈기.

## 의도

Last Banner v1 (Godot 4 + Vercel Web + KayKit 3D) → v2 (Godot 4 + macOS .app + Wesnoth 2D) 사례에서 검증:

| 보존 | 폐기 |
|---|---|
| 컨셉 / 메카닉 (자동 진행, 결정 큐, 영지 로그라이크) | KayKit GLB 3D 자산 |
| 8-autoload 패턴 (GameWorld/EventEngine/DecisionQueue 등) | Vercel deploy pipeline (`vercel.json`, lazy fetch, asset_host.json, CDN 도구) |
| 결정 큐 4단계 우선순위 | HTML5 Web export (`build/web/`, `index.pck`, `index.html`, `index.js`, `index.wasm`) |
| 한글 폰트 적용 | `_archive` 백업 폴더 (검수 후) |
| Singleton Skeleton EventEngine (8-autoload 중 1개 적용) | — |

⇒ **컨셉 패턴 = 보존, 스택 specific = 폐기**. v3 시작도 같은 패턴.

## 검증된 절차 (Last Banner 2026-07-16)

### 1단계: 신규 디렉터리 + project.godot

```bash
mkdir -p ~/work/last-banner-v2/{autoload,scenes,scripts,tools,docs,assets}
cd ~/work/last-banner-v2
```

### 2단계: 8-autoload 골격 재작성 (v1 패턴 그대로)

```gdscript
# autoload/time_manager.gd (v1 패턴 그대로)
extends Node
signal tick_advanced(game_time_min: int)
signal day_changed(day: int)
signal month_changed(month: int)
signal season_changed(season: String)

const SECONDS_PER_GAME_MINUTE := 1.0 / 60.0  # v2 신규 (60배 빠름)
const MINUTES_PER_HOUR := 60
const MINUTES_PER_DAY := 1440
var minutes_elapsed: int = 0
var day: int = 0
# ... (전체 v1 골격 재사용)
```

⇒ **autoload 인터페이스 + 시그널** = v1 패턴 그대로. **상수 값만 v2에 맞게**.

### 3단계: 자산 풀 셋업 (v1 lazy fetch → v2 res:// 직접)

```bash
# tools/setup-assets.sh (간소화 버전)
# - .gdignore 생성 X (v2는 res:// 직접)
# - 단순 ID PNG만 선택 (attack/defend/melree/ranged/mounted/die/move/stand/horse 제외)
```

### 4단계: v1 백업 후 새 폴더로 rename

```bash
mv ~/work/last-banner ~/work/_archive/last-banner-v1-$(date +%Y%m%d)   # 백업 (검수용)
mv ~/work/last-banner-v2 ~/work/last-banner                                # 새 폴더로
cd ~/work/last-banner
git init -b main
git remote add origin https://github.com/sigco3111/last-banner.git
```

### 5단계: v1 강제 푸시로 갈기

```bash
git add -A
git commit -m "v2.0.0: macOS-native, Wesnoth 2D, 자동 진행 + 결정 큐

[상세 변경 이력]
"
git push --force origin main
```

`--force` 필수 (v1 history 12+ commits을 v2 단일 commit으로 갈기).

### 6단계: GitHub description + .app 빌드

```bash
# GitHub description 수동 (gh 미인증 시)
# repo → Settings → General → About → description 변경
godot --headless --export-release macOS
```

⇒ v1 → v2 리셋 완료. v1 history 12 commits → v2 history 1 commit.

## v2 다음 단계로의 진화 (Last Banner v2.0 → v2.1)

v1→v2 리셋 후 v2 내부 증분 변경:

| 버전 | 변경 | 핵심 학습 |
|---|---|---|
| v2.0.0 | macOS + Wesnoth 2D + 8-autoload | 스택 리셋 |
| v2.1.0 | 매너지 풍경도 + 결정 큐 ON/OFF 분기 | ModalLayer z-order, Control > Node2D |
| v2.1.1 | 60배 빠른 자동 진행 | 자동 진행 속도 튜닝 |

v2.1.0 추가 학습 → `references/decision-queue-on-off-auto-vs-waiting.md`
v2.1.1 추가 학습 → `references/auto-progress-speed-tuning.md` (godot-game-bootstrap)
v2.1 매너지 패턴 → `references/manor-dashboard-screen-with-control-node2d.md` (godot-game-bootstrap)

## 핵심 결정

### 어떤 자산도 v1에서 그대로 가져오지 말 것

특히 빌드 산출물 (`build/web/*`, `*.import`, `*.gdignore` 등)은 가져오면 안 됨. v2 부트스트랩 시 `setup-assets.sh`가 올바른 자산 구조 새로 생성.

### v1 백업 보관 기간

- **14일 안전 폴더** 후 rm (Last Banner 사례: 같은 세션 내 백업 → 리셋 검증 완료 후 즉시 삭제)
- 또는 GitHub history를 통해 v1 SHA 접근 가능하면 백업 폴더 안 만들어도 됨

### 리셋 트리거 신호

다음 중 2개 이상 해당 시 리셋 권장:
- 빌드 성공해도 화면이 텍스트만 표시 (asset 미적용)
- export 실패 3회+ 동일 원인
- 사용자 "다시 처음부터" 명시
- 컨셉은 살아있는데 코드베이스가 컨셉과 안 맞음

## 푸시 안전성 — GitHub protected branches

`--force` 푸시는 v1 → v2 같은 명시적 리셋 시에만 사용. 일반 작업에서는 `--force-with-lease` 사용 (다른 사람 push 안 잃게):

```bash
git push --force-with-lease origin main    # 안전 (동시 작업자 보호)
git push --force origin main                # 위험 (모든 history 갈기)
```

## 적용 패턴

⇒ 컨셉 보존 + 스택 폐기는 **모든 Godot/Unity/Web 프로젝트 전환**에 적용:
- React → Svelte, 컨셉 보존
- Unity → Godot, 컨셉 보존
- Web → 모바일/데스크탑, 컨셉 보존

⇒ 리셋 신호 (자산 안 보임, 빌드 실패 반복) → 새 폴더 + 클린 부트스트랩 + GitHub force push + 패턴 reference 작성.
