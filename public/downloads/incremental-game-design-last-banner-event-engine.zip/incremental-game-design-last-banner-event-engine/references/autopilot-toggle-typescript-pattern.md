# Autopilot Toggle 패턴 — TypeScript/Phaser 정복 (sango-rising-dragons 2026-07-20)

Last Banner의 Godot 기반 풀 자동위임(EventEngine + DecisionQueue + GameManager.pause_for_decision)은
GDScript에 특화돼 있다. **sango-rising-dragons**는 같은 패턴을 TypeScript + Phaser 3 + Vite로
구현하면서 (1) localStorage 영속화, (2) 결정 큐 인라인화, (3) snapshot diff 로그라는 세 가지를 추가했다.

이 reference는 TypeScript 기반 게임(Phaser/Pixi/일반 SPA)에서 풀 자동위임을 구현할 때의 정형 패턴.

---

## 1. 아키텍처 (3-tier)

Last Banner와 1:1 대응이지만 코드 위치가 TypeScript에 맞춰 분산:

| Last Banner (GDScript) | sango-rising-dragons (TypeScript) |
|---|---|
| `GameWorld` autoload | `state.ts` (단일 mutable `G` 객체 + getters) |
| `EventEngine._maybe_*` (주기적 사건 생성) | `buildAutopilotQueue()` (한 step마다 호출) |
| `DecisionQueue.push()` | `stepPlayerAutopilot()` (직접 실행, 큐 자체가 없음) |
| `GameManager.pause_for_decision()` | `bus.emit('autopilotMarch', setup)` (비동기 재진입) |
| `GameManager.GAME_OVER` 시그널 | `G.over = 'win'/'lose'` 체크 + `bus.emit('gameover', kind)` |
| SaveManager 자동 저장 | `localStorage[SAVE_KEY]` + 토글은 별도 키 |

**핵심 차이**: Last Banner는 결정 큐를 별도 데이터 구조로 들고 `apply_*` 핸들러로 비동기 적용하지만,
TypeScript 게임에서는 **bus 이벤트 패턴**으로 결정-실행-재진입을 한 함수에서 처리한다.

---

## 2. 토글 상태 관리 — `getAutopilot/setAutopilot/loadAutopilot`

**게임 세이브와 분리**: 토글은 UI 설정이지 게임 상태가 아니다. 별도 localStorage 키.

```typescript
// state.ts
const AUTOPILOT_KEY = 'sango_autopilot_v1';
let autopilotOn = false;

export function getAutopilot(): boolean { return autopilotOn; }
export function setAutopilot(on: boolean): void {
  autopilotOn = !!on;
  try { localStorage.setItem(AUTOPILOT_KEY, autopilotOn ? '1' : '0'); }
  catch { /* private mode */ }
  bus.emit('autopilotChanged', autopilotOn);
}
export function loadAutopilot(): boolean {
  try {
    const v = localStorage.getItem(AUTOPILOT_KEY);
    autopilotOn = v === '1';
  } catch { autopilotOn = false; }
  return autopilotOn;
}
```

**hud.ts 부팅 시 호출** — contentReady 이후 (DOM 존재):
```typescript
export function initHud() {
  const tog = $('autopilotToggle') as HTMLInputElement;
  loadAutopilot();
  tog.checked = getAutopilot();
  syncAutoToggleVisual();
  tog.addEventListener('change', () => {
    setAutopilot(tog.checked);
    log(tog.checked ? '🤖 자동위임 ON' : '🤖 자동위임 OFF');
  });
  bus.on('autopilotChanged', () => syncAutoToggleVisual());
}
```

**함정 — 부트 순서**: `loadAutopilot`을 `bus.on('contentReady')` 안에서 호출. `initHud`는
`contentReady` 이벤트에서 호출되므로 그 안에서 호출하면 OK. 단 DOM `#autopilotToggle`이
`<head>` `<script>` 실행 시점에 존재해야 함 → `<script type="module">` defer 또는 DOMContentLoaded 이후.

---

## 3. 결정 큐 우선순위 — `buildAutopilotQueue`

**풀 자동위임 정책** (Last Banner의 EventEngine이 매 tick 사건을 만드는 것과 1:1):

```typescript
function buildAutopilotQueue(allowRelaxed: boolean): AutoAction[] {
  const q: AutoAction[] = [];
  // P1 march-attack — 강한 적지 출정
  const atk = pickBestAttack(allowRelaxed);
  if (atk) q.push(atk);
  // P2 march-move — 전선 보강 (비전투 재배치)
  const mv = pickBestMove();
  if (mv) q.push(mv);
  // P3 search — 재야 인재 수색
  const sr = pickBestSearch();
  if (sr) q.push(sr);
  // P4 train — 가장 약한 장수 조련
  const tr = pickBestTrain();
  if (tr) q.push(tr);
  // P5 develop/recruit — 인프라
  const my = citiesOf(G.playerFaction);
  for (const c of my) {
    const cd = cityDef(c.id);
    const adjacentHostile = cd.adj.some((a) => G.cities[a].owner !== G.playerFaction);
    if (c.farm < 2 && G.gold >= DEV_COST) q.push({ kind: 'farm', cityId: c.id });
    if (c.market < 2 && c.farm >= 2 && G.gold >= DEV_COST) q.push({ kind: 'market', cityId: c.id });
    if (adjacentHostile && c.walls < 3 && G.gold >= DEV_COST) q.push({ kind: 'walls', cityId: c.id });
    if (c.troops < 8000 && G.gold >= RECRUIT_COST_GOLD && G.food >= RECRUIT_COST_FOOD) {
      q.push({ kind: 'recruit', cityId: c.id });
    }
  }
  return q;
}
```

**우선순위 정당화**:
- P1 attack이 최우선 — 적을 안 치면 게임이 끝나지 않음 (12개 성도 점령이 승리 조건)
- P2 move가 attack 다음 — 부대 응집이 다음 출정의 전제
- P3/P4는 opportunistic — CP 여유 있을 때만
- P5 develop는 항상 가능 — CP만 남으면 끝까지

---

## 4. 출정 공격 함수 — `pickBestAttack`

**Last Banner의 `_maybe_bandit_raid` 패턴** (강도 비율 + 자원 체크)을 그대로:

```typescript
function pickBestAttack(allowRelaxed: boolean): AutoAction | null {
  if (G.cp <= 0) return null;
  const my = citiesOf(G.playerFaction);
  const threshold = allowRelaxed ? ATTACK_RATIO_RELAXED : ATTACK_RATIO_STRICT;
  let best: { from: string; to: string; ratio: number; picked: string[]; troops: number } | null = null;

  for (const c of my) {
    if (c.troops < 6000) continue;
    const cd = cityDef(c.id);
    const available = officersIn(c.id, G.playerFaction).filter((o) => !o.acted);
    if (available.length === 0) continue;
    for (const adjId of cd.adj) {
      const t = G.cities[adjId];
      if (t.owner === G.playerFaction) continue;
      const maxTroops = Math.max(0, c.troops - 500);
      if (maxTroops < 500) continue;
      const picked = available.slice(0, 3).map((o) => o.id);
      const sendTroops = Math.floor(maxTroops * 0.85);
      const defOff = officersIn(adjId, t.owner).map((o) => o.id);
      const myPow = armyPower(sendTroops, picked);
      const defPow = armyPower(t.troops, defOff, t.walls);
      const ratio = myPow / Math.max(1, defPow);
      if (ratio >= threshold && (!best || ratio > best.ratio)) {
        best = { from: c.id, to: adjId, ratio, picked, troops: sendTroops };
      }
    }
  }
  if (!best) return null;
  return { kind: 'march-attack', cityId: best.from, targetCityId: best.to, picked: best.picked, troops: best.troops };
}
```

**공격 강도 모드 (★ 결정적 패턴)**:
```typescript
const ATTACK_RATIO_STRICT = 1.4;  // AI와 동일 — CP < 4일 때
const ATTACK_RATIO_RELAXED = 1.0;  // 적극 — CP >= 4일 때
```

**왜 1.4/1.0인가** — `ai.ts`의 AI 출정 임계값과 동일. CP가 충분하면 더 공격적으로,
부족하면 보수적으로. AI와 동일한 baseline을 유지하되 위임은 한 단계 더 적극적.

---

## 5. 결정 실행 — `stepPlayerAutopilot` (Last Banner의 `apply_*` 핸들러)

**핵심 차이**: GDScript는 `await apply_result(payload)`로 비동기 결과를 기다리지만,
TypeScript에서는 **bus 이벤트 + setTimeout 체인**으로 끊김 없는 진행:

```typescript
// state.ts
export function stepPlayerAutopilot(silent = false): boolean {
  if (!G || G.over) return false;
  if (G.cp <= 0) return false;
  const allowRelaxed = G.cp >= 4;
  const queue = buildAutopilotQueue(allowRelaxed);
  if (queue.length === 0) return false;

  for (const a of queue) {
    autoStepIdx++;
    // march-attack → 비동기 (flow.ts가 처리 후 재호출)
    if (a.kind === 'march-attack' && a.targetCityId && a.picked && a.troops !== undefined) {
      const setup: BattleSetup = { /* ... */ };
      bus.emit('autopilotMarch', setup);
      return false;  // march 핸들러가 재호출
    }
    // 동기 액션 (개간/통상/축성/징병/수색/조련/이동)
    if (a.kind === 'recruit' && a.cityId) {
      const before = G.cities[a.cityId].troops;
      if (recruit(a.cityId)) {
        bus.emit('log', `🤖 #${autoStepIdx} ${cityName} ⚔ 징병 ✓ ${before.toLocaleString()}→${G.cities[a.cityId].troops.toLocaleString()}`, 'auto');
        return G.cp > 0;
      }
      continue;
    }
    // ... 다른 액션들도 같은 패턴
  }
  return false;
}
```

**flow.ts의 march 핸들러 (★ 핵심 — 비동기 재진입)**:
```typescript
// flow.ts
bus.on('autopilotMarch', (setup: BattleSetup) => {
  if (!getAutopilot()) return;
  pendingMarch = setup;
  const result = autoResolve(setup);
  // src.troops 차감 후 applyBattleResult (패배 시 src로 복귀)
  G.cities[setup.sourceCityId!].troops = Math.max(0, G.cities[setup.sourceCityId!].troops - setup.atkTroops);
  applyBattleResult(setup, result);
  G.cp--;
  for (const id of setup.atkOfficers) G.officers[id].acted = true;
  bus.emit('refresh');
  pendingMarch = null;
  runAutopilotTurn();  // 체인 계속
});

function runAutopilotTurn() {
  if (!G || G.over || G.cp <= 0) { continueAi(0); return; }
  setTimeout(() => {
    const more = stepPlayerAutopilot(true);
    bus.emit('refresh');
    if (more) runAutopilotTurn();
    else if (!pendingMarch) {
      bus.emit('log', '🤖 자동위임 종료 — AI 턴으로 넘어갑니다.', 'auto');
      continueAi(0);
    }
  }, 220);  // ★ 220ms — UI 로그 한 줄씩 보이게
}
```

**220ms 간격 정당화**: 60ms는 로그가 동시에 쌓여서 한 줄씩 안 보임. 220ms가 사용자 가독성 +
자동 진행 속도 균형점. Last Banner는 시뮬이므로 이 딜레이 없지만, 시각적 게임에서는 필수.

---

## 6. 스냅샷 diff 로그 — 시각화 게임만의 차별점

**Last Banner는 `print()` 한 줄 로그이지만**, sango-rising-dragons는 매 step마다
before/after diff를 만들어서 한 줄에 모든 변화 표시:

```typescript
// 각 액션별 before snapshot
const before = { gold: G.gold, food: G.food, troops: c.troops, farm: c.farm, /* ... */ };

// 액션 실행
recruit(a.cityId);  // 또는 develop/move/train/search

// after + diff
const after = { /* ... */ };
const dGold = after.gold - before.gold;
const dFood = after.food - before.food;
bus.emit('log', 
  `🤖 #${autoStepIdx} ${cityName} ⚔ 징병 ✓ ` +
  `병력 ${before.troops.toLocaleString()}→${after.troops.toLocaleString()} ` +
  `(+${(after.troops - before.troops).toLocaleString()}) · ` +
  `-${(-dGold).toLocaleString()} 금 · -${(-dFood).toLocaleString()} 식량 ` +
  `(남은 CP: ${G.cp}, 금: ${after.gold.toLocaleString()})`,
  'auto'  // 시각 구분용 CSS 클래스 (파란 보더, 이탤릭)
);
```

**사용자 경험**:
- 한 줄에 5개 필드 (도시, 액션, 결과, 변화량, 잔여 자원) — 화면 스크롤 없이 파악 가능
- `#${autoStepIdx}` 번호로 실행 순서 추적 — "5번 액션이 뭐였지?" 즉시 확인
- `(남은 CP: N, 금: N)` — 다음 액션 의사결정 컨텍스트 제공

---

## 7. 모달 회피 — searchTalent 인라인화

**핵심 함정**: `searchTalent` 함수가 재야 인재 합류 시 **`bus.emit('modal', ...)`로 모달 띄움**.
위임 중 모달 뜨면 자동 진행이 막힘 → 사용자가 닫아야 진행.

**해결**: 위임 모드에서는 searchTalent을 인라인화:

```typescript
// ❌ searchTalent() 직접 호출 — 모달 띄우면 자동 진행 정지
if (a.kind === 'search' && a.officerId && a.cityId) {
  searchTalent(a.cityId, a.officerId);  // 모달 emit
  return G.cp > 0;
}

// ✓ 인라인화 — 같은 로직이지만 로그로만 출력
if (a.kind === 'search' && a.officerId && a.cityId) {
  const beforeGold = G.gold;
  const searcher = G.officers[a.officerId];
  searcher.acted = true;
  G.cp--;
  const free = freeOfficersIn(a.cityId);
  const pol = effStat(searcher, 'pol');
  if (free.length === 0) {
    G.gold += 100;
    bus.emit('log', `🤖 #${autoStepIdx} ${cityName} 🔍 수색 ✓ 인재 없음, 세금 +100 금`, 'auto');
  } else {
    const target = free[Math.floor(Math.random() * free.length)];
    const chance = 0.35 + pol / 200;
    if (Math.random() < chance) {
      target.faction = G.playerFaction;
      bus.emit('log', `🤖 #${autoStepIdx} ${cityName} 🔍 수색 ✓ ${officerDef(target.id).name} 합류!`, 'auto');
    } else {
      bus.emit('log', `🤖 #${autoStepIdx} ${cityName} 🔍 수색 — ${officerDef(target.id).name} 영입 실패`, 'auto');
    }
  }
  return G.cp > 0;
}
```

**일반화 규칙**: 위임 자동화가 기존 함수를 호출할 때, 그 함수가 모달/alert/confirm 등
사용자 입력 대기 동작을 포함하면 **반드시 인라인화**해서 동기 동작으로 변환.

---

## 8. 사용자 결정 포인트 (★ 3가지 정책 선택)

sango-rising-dragons 세션에서 사용자가 명시적으로 선택한 3가지:

### 8.1 출정 강도
| 옵션 | 기준 | 의미 |
|---|---|---|
| **A (사용자 선택)** | ratio > 1.4 (AI와 동일) | 보수적, CP<4일 때 자동 적용 |
| B | ratio > 1.2 | 약간 적극 |
| C | ratio > 1.0 | 매우 적극 (모든 인접 적지 공격) |

**사용자 선택**: A안 + B안 혼합 — **CP<4일 땐 A (보수적), CP>=4일 땐 ratio>1.0 (적극)**

```typescript
const ATTACK_RATIO_STRICT = 1.4;
const ATTACK_RATIO_RELAXED = 1.0;

const allowRelaxed = G.cp >= 4;
const threshold = allowRelaxed ? ATTACK_RATIO_RELAXED : ATTACK_RATIO_STRICT;
```

### 8.2 조련 사용 여부
- **사용자 선택**: 항상 시도 (CP 여유 있을 때)
- 근거: 조련은 CP 1 + 150 금만 필요, 실패해도 금만 잃음. 게임 진행에 도움

### 8.3 출정 전투 모달
| 옵션 | 의미 |
|---|---|
| A | 항상 자동 결산 (출정 모달 생략) |
| B | 사용자 직접 선택 (직접 지휘 vs 자동 결산) |
| **C (사용자 선택)** | 위임 ON이면 자동 결산, OFF면 사용자 선택 모달 |

**구현**: `flow.ts`의 `promptDefense`에 동일 분기:
```typescript
if (getAutopilot()) {
  bus.emit('log', '🤖 자동 결산', 'auto');
  autoResolve + applyBattleResult + afterBattle (no modal);
  return;
}
// 위임 OFF: 기존 모달 표시
bus.emit('modal', { title, text, choices: [...] });
```

---

## 9. 검증된 출력 패턴

실제 한 턴 출력 예시 (sango-rising-dragons):

```
🤖 자동위임 계획 (공격적, CP=5): 8개 — ⚔ 출정(공격) ×1, 🚩 출정(이동) ×1, 🔍 수색 ×1, 🎯 조련 ×1, 🌾 개간 ×2, 🪙 통상 ×1, ⚔ 징병 ×1.
🤖 자동위임 시작 — 모든 플레이어 행동을 위임합니다.
🤖 #1 진류→양양 ⚔ 출정(공격) → 자동 출정: 진류→양양 🏴 함락! (8,000 vs 6,200, 성벽 2, 비율 ≈1.45) — 아군 잔여 4,800, 적 잔여 100.
🤖 #2 진류→허도 🚩 이동 ✓ 5,000→2,500 (전선 보강) (남은 CP: 4).
🤖 #3 허도 🔍 수색 ✓ 관우 합류! (금 변화 0) (남은 CP: 3).
🤖 #4 관우 🎯 조련 ✓ (금 변화 -150) (남은 CP: 2).
🤖 #5 허도 🌾 개간 ✓ Lv0→Lv1 · -400 금 (남은 CP: 1, 금: 350).
🤖 #6 허도 ⚔ 징병 ✗ 스킵 — 금 부족.
🤖 #7 허도 ⚔ 징병 ✗ 스킵 — 식량 부족.
🤖 자동위임 종료 — AI 턴으로 넘어갑니다.
🤖 자동위임 — 양양 방어 (적 6,000 vs 아군 100, 성벽 0) 자동 결산.
💔 양양之戰落敗……
```

**핵심**: 한 줄에 컨텍스트 (도시, 액션, 변화량, 잔여) 모두 포함 + `✗ 스킵 — 사유` 로 실패 이유 명시.

---

## 10. 정형 checklist (TypeScript 게임에서 풀 자동위임 구현 시)

- [ ] `localStorage` 키 분리 — 토글 상태 vs 게임 세이브
- [ ] 결정 큐 5-tier 우선순위 (출정 → 이동 → 수색 → 조련 → 개발)
- [ ] 출정 강도 모드 2종 (CP<4 strict / CP>=4 relaxed)
- [ ] 각 액션별 `silent` 인라인화 — 모달 띄우는 함수는 직접 호출 금지
- [ ] 출정 비동기 핸들러는 `bus.emit('autopilotMarch')` + `pendingMarch` 가드
- [ ] setTimeout 220ms 간격 (시각적 게임에서 로그 가독성)
- [ ] snapshot diff 로그 — `#N 도시 액션 ✓ 변화량 (잔여 CP/금)`
- [ ] `✗ 스킵 — 사유` 명시 — 금 부족 / 식량 부족 / 이미 최고 레벨
- [ ] `getAutopilot() ? auto : modal` 분기 — 모든 사용자 입력 경로
- [ ] `G.over` 체크 — 게임 종료 시 위임 즉시 중단
- [ ] `runAutopilotTurn` 진입 시 `pendingMarch` 체크 — march 핸들러가 비동기 재진입하므로
- [ ] WT clean 보장 — `.tmp-deploy.sh` 같은 helper는 deploy 후 `git rm` + 별도 commit

---

## 11. 결정 큐 3대 함정 (sango-rising-dragons 실전 검증, 2026-07-20)

풀 자동위임 첫 통합 후 실제 발견된 함정 3가지. 각 함정은 사용자 화면에서 명확한 증상으로 드러남.

### 11.1 함정 A — 함수 반환값 무시 → 무한 루프 (★ 가장 위험)

**증상**: 자동위임 로그에 같은 행동이 #118, #119, #120, #121... 끝없이 반복. CP가 줄지 않는데 액션 번호만 증가.

**원인**: `stepPlayerAutopilot`이 `trainOfficer`/`recruit`/`develop`의 boolean 반환값을 무시하고 항상 `return G.cp > 0`. 실패해도 CP/acted 미변경 → 같은 후보 재선택 → 무한.

**실제 코드 (수정 전)**:
```typescript
// ❌ 버그
if (a.kind === 'train' && a.officerId) {
  trainOfficer(a.officerId);  // 반환값 무시
  bus.emit('log', `🤖 #${autoStepIdx} 🎯 조련 ✓ ...`);
  return G.cp > 0;  // CP 안 줄었으니 계속 true
}
```

**수정 후**:
```typescript
// ✓ FIX — 반환값 체크 + continue
if (a.kind === 'train' && a.officerId) {
  const ok = trainOfficer(a.officerId);
  if (!ok) {
    bus.emit('log', `🤖 #${autoStepIdx} ${name} 🎯 조련 ✗ 스킵.`, 'auto');
    continue;  // 다음 후보 시도 (infinite loop 차단)
  }
  bus.emit('log', `🤖 #${autoStepIdx} ${name} 🎯 조련 ✓ ...`);
  return G.cp > 0;
}
```

**일반화 규칙**: 자동화 코드가 기존 도메인 함수를 호출할 때는 **반드시 boolean 반환값 체크 + 실패 시 continue**. "어차피 성공하겠지"라는 가정은 사치.

**이중 안전망**: 함수 반환값 체크 + 별도 depth 카운터 (50회 시도 초과 시 안전 종료):
```typescript
function runAutopilotTurn() {
  if (!G || G.over || G.cp <= 0) { continueAi(0); return; }
  if ((runAutopilotTurn as any)._depth === undefined) (runAutopilotTurn as any)._depth = 0;
  (runAutopilotTurn as any)._depth++;
  if ((runAutopilotTurn as any)._depth > 50) {
    (runAutopilotTurn as any)._depth = 0;
    bus.emit('log', '🤖 ⚠ 자동위임 안전 종료 (50회 시도 초과).', 'auto');
    continueAi(0);
    return;
  }
  setTimeout(() => {
    if (!busy || G.over) { (runAutopilotTurn as any)._depth = 0; return; }
    const more = stepPlayerAutopilot(true);
    if (more) runAutopilotTurn();
    else if (!pendingMarch) {
      (runAutopilotTurn as any)._depth = 0;
      continueAi(0);
    }
  }, 220);
}

function continueAi(startIndex: number) {
  (runAutopilotTurn as any)._depth = 0;  // 진입 시 depth 리셋
  ...
}
```

**Last Banner 대조**: GDScript의 `apply_result()`는 27+ 결과 코드를 dict로 매핑 — 실패 결과도 모두 정의되어 있으므로 silent fail이 안 생김. TypeScript 게임은 동적 함수 호출이라 silent fail 위험 ↑.

### 11.2 함정 B — `pickBestX` 후보 선택 시 사전 체크 누락 → 같은 후보 무한 재선택

**증상**: 11.1과 같은 무한 루프지만, 이번엔 **`pickBestTrain`이 후보를 매번 같은 officer로 반환**해서 `trainOfficer`가 반복 호출. 함정 A가 픽스된 후에도 발생할 수 있는 잔존 케이스.

**원인**: 후보 선택 함수가 `!o.acted`만 체크. `o.acted = true`가 반영되기 전까지 같은 후보 재선택.

**수정 후**:
```typescript
function pickBestTrain(): AutoAction | null {
  if (G.cp <= 0) return null;
  if (G.gold < 150) return null;  // ★ 사전 체크 — 후보 자체를 안 만듦
  const my = officersOf(G.playerFaction)
    .filter((o) => !o.acted && G.gold >= 150)  // ★ 명시적 후보 사전 체크
    .sort((a, b) => a.level - b.level || a.exp - b.exp);
  if (my.length === 0) return null;
  return { kind: 'train', officerId: my[0].id };
}
```

**일반화 규칙**: 모든 `pickBestX` 함수는 다음 4가지를 반드시 사전 체크:
1. `G.cp > 0` (CP 있어야 행동 가능)
2. 행동별 자원 (gold<150이면 train null, gold<200+food<300이면 recruit null 등)
3. 행동별 max (이미 최고 레벨이면 develop null)
4. 후보 list가 비면 null

**체크리스트**:
```
- [ ] CP 사전 체크
- [ ] 자원 사전 체크 (gold / food / cp)
- [ ] max 사전 체크 (이미 최고 레벨인 경우)
- [ ] 후보 0개면 null 반환
```

### 11.3 함정 C — Mutation은 됐는데 UI 미갱신 디버깅 패턴

**증상 (사용자 보고)**: "로그는 징병된 것으로 나오지만 UI는 항상 -, 전쟁을 하더라도 병력을 설정할 수 없는 것으로 봐서 정말 징병이 안되는듯."

**사용자 진단의 핵심**: **"로그는 정상인데 UI는 안 바뀜"** → mutation은 됐고 UI 미갱신. 이 한 줄로 80% 원인 특정됨.

**진단 3단계 패턴**:
```typescript
// 1단계: 함수 자체에 before/after 명시 로그 박기
export function recruit(cityId: string): boolean {
  if (G.gold < RECRUIT_COST_GOLD || G.food < RECRUIT_COST_FOOD) {
    bus.emit('log', '⚠ 징병에는 200 금과 300 식량이 필요합니다.'); return false;
  }
  if (!spendCp()) return false;
  const beforeTroops = G.cities[cityId]?.troops ?? 0;
  G.gold -= RECRUIT_COST_GOLD; G.food -= RECRUIT_COST_FOOD;
  G.cities[cityId].troops += RECRUIT_AMOUNT;
  const afterTroops = G.cities[cityId].troops;
  // 2단계: window console hook (사용자가 직접 검증 가능)
  try { (window as any).__sangoRecruitLog = { cityId, before: beforeTroops, after: afterTroops, gold: G.gold, food: G.food }; } catch {}
  bus.emit('log', `⚔ ${cityDef(cityId).name}에서 신병 ${RECRUIT_AMOUNT}명 모집. (${beforeTroops.toLocaleString()}→${afterTroops.toLocaleString()})`);
  bus.emit('refresh');
  return true;
}

// 3단계: 자동위임 분기에서 변화량 검증
if (a.kind === 'recruit' && a.cityId) {
  const before = c.troops;
  const ok = recruit(a.cityId);
  const after = c.troops;
  if (!ok || after === before) {
    bus.emit('log', `🤖 #${autoStepIdx} ⚔ 징병 ✗ 실패 (변화 없음).`, 'auto');
    continue;
  }
  bus.emit('log', `🤖 #${autoStepIdx} ⚔ 징병 ✓ ${before.toLocaleString()}→${after.toLocaleString()} (+${(after - before).toLocaleString()})`, 'auto');
}
```

**사용자가 콘솔에서 직접 검증 가능**:
```js
__sango.getG().cities.chenliu.troops   // 현재 troops
__sangoRecruitLog                       // 최근 recruit 결과
```

**3가지 시나리오 진단**:
| 시나리오 | 콘솔 결과 | 원인 | 해결 |
|---|---|---|---|
| A. mutation은 됐고 UI만 안 바뀜 | `__sango.getG().cities.chenliu.troops` = +1500인데 사이드패널은 그대로 | `bus.emit('refresh')` 미동작 또는 HUD 렌더 사이클 문제 | `refresh` emit 후 MapScene까지 도달 확인 |
| B. mutation 자체가 안 됨 | 콘솔 troops도 그대로, 로그에 "✗ 실패 (변화 없음)" 표시 | 도시 ID 불일치 또는 `spendCp` silent fail | 도시 ID 매핑 검증 |
| C. 브라우저 캐시 | 모든 동작 정상인데 옛 빌드 실행 | Vercel alias는 갱신됐지만 브라우저가 옛 JS 캐시 | `Cmd+Shift+R` 강제 새로고침 |

**사용자 진단 협조 패턴** — "UI 안 바뀜" 보고 받으면:
1. **코드 + 미니파이된 JS 양쪽 grep** (mutation 코드 존재 확인)
2. **before/after 명시 로그 박기** (가장 빠른 진단)
3. **window 콘솔 hook 추가** (사용자가 콘솔에서 직접 검증)
4. **3가지 시나리오 진단표** 제시 + 사용자 보고 대기

**강제 새로고침 권장**: 모든 시각 회귀 진단의 첫 단계. vercel.json의 `/index.html` 캐시는 `max-age=0, must-revalidate`라 자동이지만 `/assets/index-*.js`는 `max-age=31536000` → 새 빌드 시 파일명 hash가 바뀌므로 자동으로 새 파일 받음. 단 Vite HMR 모드 + 옛 캐시 동시 존재 시 명시적 새로고침 필요.

### 11.4 일반화된 자동위임 체크리스트 (v2)

11.1~11.3 함정 통합:

```
[사전 — pickBestX]
- [ ] CP 사전 체크 (G.cp <= 0 → null)
- [ ] 자원 사전 체크 (gold/food 임계값)
- [ ] max 사전 체크 (이미 최고 레벨)
- [ ] 후보 0개면 null 반환 (filter 후 .length 체크)

[실행 — stepPlayerAutopilot]
- [ ] trainOfficer/recruit/develop의 boolean 반환값 체크
- [ ] 실패 시 "✗ 스킵" 로그 + continue (다음 후보)
- [ ] 성공 시 before/after 명시 diff 로그
- [ ] 모달 띄우는 함수 (searchTalent 등) 인라인화 — 모달 emit 회피

[비동기 — bus.emit('autopilotMarch')]
- [ ] flow.ts 핸들러가 출정 후 runAutopilotTurn 재호출
- [ ] pendingMarch 가드 — march 핸들러가 비동기 재진입하므로

[안전망 — depth 카운터]
- [ ] 50회 시도 초과 시 안전 종료 로그 + AI 턴
- [ ] continueAi 진입 시 depth 리셋
- [ ] G.over 체크 (게임 종료 시 위임 즉시 중단)

[사용자 진단 협조]
- [ ] "UI 안 바뀜" 보고 → before/after 명시 로그 + window console hook
- [ ] "로그는 정상인데 실제 변화 없음" → silent fail 가설 + 3단계 진단표
- [ ] 첫 액션 권장: Cmd+Shift+R 강제 새로고침
```

## 12. LastBanner ↔ sango-rising-dragons 차이점 총정리

| 항목 | Last Banner (GDScript) | sango-rising-dragons (TS) |
|---|---|---|
| 결정 큐 데이터 구조 | `DecisionQueue.push()` 별도 객체 | `buildAutopilotQueue()` 호출 시점 생성 |
| apply 핸들러 | 27+ 메서드 (GameWorld.apply_*) | 5단계 if-else (stepPlayerAutopilot 내부) |
| 비동기 재진입 | `await apply_result()` | `bus.emit('autopilotMarch')` + setTimeout |
| 진행 속도 조절 | `TimeManager.speed_multiplier` | setTimeout 220ms |
| 모달 회피 | EventEngine이 모달 자체 emit 안 함 | searchTalent 인라인화 |
| 영속화 | SaveManager 자동 저장 | localStorage 토글 키 (별도) |
| 시각 로그 | GDScript `print()` | `bus.emit('log', msg, 'auto')` (CSS 클래스) |
| 게임 종료 | GameManager.GAME_OVER + game_ended 시그널 | `G.over = 'win'/'lose'` + `bus.emit('gameover', kind)` |
| 테스트 | LB_VERIFY 헤드리스 22단계 | (없음 — 시뮬 X, Phaser 렌더링) |

**결론**: 두 시스템은 **같은 패턴의 두 언어 구현**. 풀 자동위임 + 결정 큐 + 게임 종료 모달
까지 자동 진행되는 게임이라면 어느 언어로 구현하든 이 reference의 체크리스트가 적용된다.