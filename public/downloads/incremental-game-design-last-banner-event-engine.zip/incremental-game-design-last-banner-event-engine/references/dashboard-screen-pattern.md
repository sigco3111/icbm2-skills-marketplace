# Dashboard Screen Pattern — 영지/도시/국가 시각화 (Last Banner 5차 검증, 2026-07-16)

자동 진행 게임에서 **자동 진행의 효과를 시각화**하는 표준 화면. 자원 카드 + 진행 바 + 라인 차트 + 사건 로그 + 업적 시스템의 통합 패턴.

## 트리거

- "영지 대시보드 만들어줘", "자원 추이 그래프 보여줘", "도시/국가 현황 화면", "게임 플레이어가 진행 상황을 시각적으로 보고 싶어할 때"
- 자동 진행이 자원을 변동시키지만 **사용자가 그 효과를 보지 못하면 게임이 정체되어 보임** — 이걸 시각화하는 표준

## 5가지 구성 요소

| 요소 | 역할 | Godot 구현 |
|---|---|---|
| **메트릭 카드** | 자원 5종 (gold/food/pop/prosperity/fortification) + 큰 숫자 + 색상별 delta | `PanelContainer` + `Label` (메인 숫자 + delta sub-label) |
| **진행 바** | prosperity 0~100, fortification 1~5 | `ProgressBar` (max_value 다름) |
| **라인 차트** | 7일 ring buffer 기반 자원 추이 | `Control._draw()` + `queue_redraw()` |
| **이벤트 로그** | 최근 20건 사건 (Day X — 메시지) | 동적 `Label` 행 추가 |
| **업적 시스템** | 자동 해금 (10명/명성30/금500 등) + 시그널 emit | `GameWorld.unlock_achievement()` |

## GameWorld 확장 — 일별 History Ring Buffer

자동 진행의 효과를 시계열로 시각화하려면 **매일 자원 스냅샷 기록** 필요. GameWorld에 다음 추가:

```gdscript
const HISTORY_MAX_DAYS := 7
var history: Array = []  # 오래된 → 최신 순, 각 원소: {day, gold, food, population, prosperity}
var _last_history_day: int = 0

const EVENT_LOG_MAX := 20
var event_log: Array = []  # 각 원소: {day, game_time, message}

var achievements: Array = []  # 각 원소: {id, title, description, unlocked_day}

signal achievement_unlocked(achievement: Dictionary)

func record_day_snapshot(day: int) -> void:
    var snap := {
        "day": day,
        "gold": gold,
        "food": food,
        "population": population,
        "prosperity": prosperity
    }
    if _last_history_day == day and not history.is_empty():
        history[-1] = snap  # 같은 날 중복 방지
    else:
        history.append(snap)
        _last_history_day = day
        while history.size() > HISTORY_MAX_DAYS:
            history.pop_front()  # ring buffer

func log_event(message: String) -> void:
    var entry := {"day": TimeManager.day, "game_time": TimeManager.minutes_elapsed, "message": message}
    event_log.append(entry)
    while event_log.size() > EVENT_LOG_MAX:
        event_log.pop_front()

func unlock_achievement(id: String, title: String, description: String = "") -> bool:
    for a in achievements:
        if a.id == id:
            return false  # 중복 방지
    var entry := {"id": id, "title": title, "description": description, "unlocked_day": TimeManager.day}
    achievements.append(entry)
    log_event("🏆 업적 달성: %s" % title)
    achievement_unlocked.emit(entry)
    return true
```

**EventEngine._on_day에서 호출**:
```gdscript
func _on_day(day: int) -> void:
    GameWorld.apply_daily_economy()
    GameWorld.apply_weekly_bill()
    GameWorld.record_day_snapshot(day)  # ← 일별 스냅샷
    GameWorld.log_event("Day %d — 자원 변동" % day)
    # ... 업적 자동 체크
    if GameWorld.alive_mercenaries().size() >= 10:
        GameWorld.unlock_achievement("ten_mercenaries", "용병 10명 보유")
```

**save_state/load_state**: history/event_log/achievements 모두 직렬화 + 복원 (사용자가 한 달 미진입해도 차트 + 로그 + 업적 보존).

## 라인 차트 — `Control._draw()` 직접 그리기

Godot 4에서 차트는 **`Control._draw()` 오버라이드 + `queue_redraw()` 호출**로 그린다. TextureRect나 Sprite2D 안 씀. CanvasItem API 직접.

```gdscript
@onready var chart_canvas: Control = $ChartCanvas  # PanelContainer 안에 Control 노드

func _ready() -> void:
    chart_canvas.draw.connect(_draw_chart)  # _draw 신호 구독

func _refresh_chart() -> void:
    chart_canvas.queue_redraw()  # 다음 프레임에 _draw_chart 호출

func _draw_chart() -> void:
    var history: Array = GameWorld.history
    var size: Vector2 = chart_canvas.size
    var padding := Vector2(40, 16)
    var plot_w: float = size.x - padding.x * 2
    var plot_h: float = size.y - padding.y * 2

    chart_canvas.draw_rect(Rect2(Vector2.ZERO, size), Color(0.08, 0.07, 0.06, 0.5))
    if history.size() < 1:
        chart_canvas.draw_string(KOREAN_FONT, Vector2(size.x/2 - 60, size.y/2),
            "(데이터 부족)", HORIZONTAL_ALIGNMENT_LEFT, -1, 14, COLOR_AXIS)
        return

    # 자원별 max 값
    var max_gold: int = 1; var max_food: int = 1; var max_pop: int = 1
    for h in history:
        if int(h.gold) > max_gold: max_gold = int(h.gold)
        if int(h.food) > max_food: max_food = int(h.food)
        if int(h.population) > max_pop: max_pop = int(h.population)

    # 그리드 (수평선 4개)
    for i in range(5):
        var y: float = padding.y + plot_h * float(i) / 4.0
        chart_canvas.draw_line(Vector2(padding.x, y), Vector2(padding.x + plot_w, y), COLOR_GRID, 1.0)

    # 자원별 라인
    _draw_series(history, "gold", COLOR_GOLD, padding, plot_w, plot_h, max_gold)
    _draw_series(history, "food", COLOR_FOOD, padding, plot_w, plot_h, max_food)
    _draw_series(history, "population", COLOR_POP, padding, plot_w, plot_h, max_pop)

    # 범례
    var legend_x: float = size.x - 180
    chart_canvas.draw_rect(Rect2(Vector2(legend_x - 8, 0), Vector2(180, 56)), Color(0, 0, 0, 0.4))
    chart_canvas.draw_string(KOREAN_FONT, Vector2(legend_x, 14), "💰 금", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, COLOR_GOLD)
    chart_canvas.draw_string(KOREAN_FONT, Vector2(legend_x, 32), "👥 인구", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, COLOR_POP)

func _draw_series(history: Array, key: String, color: Color, padding: Vector2, plot_w: float, plot_h: float, max_val: int) -> void:
    var n: int = history.size()
    if n < 2: return
    var points: Array = []
    for i in range(n):
        var x: float = padding.x + plot_w * float(i) / float(n - 1)
        var v: int = int(history[i][key])
        var y: float = padding.y + plot_h * (1.0 - float(v) / float(max(max_val, 1)))
        points.append(Vector2(x, y))
    for i in range(points.size() - 1):
        chart_canvas.draw_line(points[i], points[i + 1], color, 2.0)
    for p in points:
        chart_canvas.draw_circle(p, 3.0, color)
```

**핵심 6가지**:
1. `chart_canvas.draw.connect(_draw_chart)` — `_draw` 시그널을 스크립트 함수에 연결
2. `chart_canvas.queue_redraw()` — 다음 프레임에 `_draw_chart` 호출 트리거
3. `size: Vector2 = chart_canvas.size` — 차트 영역 크기 자동 반영
4. `draw_line`, `draw_circle`, `draw_string` — CanvasItem API
5. **max_val normalize** — 자원별 다른 스케일을 같은 차트에 그릴 때
6. **points 배열 미리 계산** — 라인/점을 분리 그리기

## 색상 표준 (Gameworld Summary 표기)

| 자원/상태 | 색상 |
|---|---|
| 금 (gold) | `Color(0.95, 0.78, 0.2)` — 금색 |
| 식량 (food) | `Color(0.6, 0.85, 0.4)` — 연두 |
| 인구 (population) | `Color(0.4, 0.7, 1.0)` — 하늘 |
| 그리드 | `Color(0.3, 0.3, 0.3, 0.5)` — 어두운 회색 |
| 축 텍스트 | `Color(0.6, 0.6, 0.6, 0.8)` — 회색 |
| 명성 바 (낮음) | `Color(0.7, 0.7, 0.7)` |
| 명성 바 (중간) | `Color(0.8, 1.0, 0.8)` |
| 명성 바 (높음 ≥70) | `Color(1.0, 0.85, 0.4)` — 금색 |
| 요새화 Lv.1 | `Color(0.7, 0.7, 0.7)` |
| 요새화 Lv.5 | `Color(1.0, 0.85, 0.3)` — 금색 |
| 사망자 💀 | `Color(0.4, 0.4, 0.4)` |
| 부상자 🩹 | `Color(1.0, 0.7, 0.3)` |
| 충성도 위험 (< 30) ⚠️ | `Color(1.0, 0.4, 0.4)` |
| 업적 🏆 | `Color(1.0, 0.95, 0.6)` — 연한 금색 |

## 메트릭 카드 레이아웃 (5개 자원)

3개 한 줄 + 2개 한 줄 패턴:

```
[Gold Card]  [Food Card]  [Pop Card]      # 3-pane HBox, custom_minimum_size=Vector2(220, 130)
[Prosperity ProgressBar]  [Fort ProgressBar]  # 2-pane HBox, size_flags_horizontal=3
```

각 카드는 `PanelContainer` + `MarginContainer(12,8,12,8)` + `VBox` + `Title Label` + `Value Label` (큰 글꼴 32) + `Delta Label` (작은 글꼴 12, modulate 색).

## 동적 List 행 추가 (이벤트 로그 + 업적)

```gdscript
func _refresh_event_log() -> void:
    for child in event_log_list.get_children():
        child.queue_free()
    # 최신 → 오래된 순
    for i in range(GameWorld.event_log.size() - 1, -1, -1):
        var entry: Dictionary = GameWorld.event_log[i]
        var label := Label.new()
        label.text = "Day %d — %s" % [entry.day, entry.message]
        label.add_theme_font_size_override("font_size", 12)  # ← GDScript 함정
        event_log_list.add_child(label)
```

**Pitfall — GDScript theme_override 할당 불가**:
```gdscript
# ❌ 파스 에러: Only identifier, attribute access, and subscription access can be used as assignment target
label.theme_override_font_sizes/font_size = 12

# ✓ 메서드 호출
label.add_theme_font_size_override("font_size", 12)
```

`theme_override_*`는 노드 인덱스 접근이라 직접 할당 불가. `add_theme_*_override(name, value)` 메서드로.

## 시그널 구독 자동 갱신

```gdscript
func _ready() -> void:
    GameWorld.world_initialized.connect(_on_world_changed)
    GameWorld.resource_changed.connect(_on_resource_changed)
    GameWorld.achievement_unlocked.connect(_on_achievement_unlocked)

func _on_resource_changed(_resource: String, _value: int, _delta: int) -> void:
    if visible:
        refresh()

func _on_achievement_unlocked(_a: Dictionary) -> void:
    if visible:
        _refresh_achievements()  # 업적만 갱신 (전체 refresh는 무거움)

func _process(_delta: float) -> void:
    if visible:
        _refresh_metrics()   # 자원 카드 (delta 계산)
        _refresh_bars()      # 진행 바
```

**Pitfall — _process에서 refresh() 전체 호출은 무거움**: 매 프레임 List/Chart 갱신 → row 동적 생성 → List 클래스 인스턴스 폭증. **필드별 분리 refresh** (메트릭/바/로그/업적/차트).

## 시그널 핸들러 인자 미스매치 — 디폴트 인자 패턴

```gdscript
# GameWorld 시그널들
signal resource_changed(resource: String, value: int, delta: int)        # 3 args
signal mercenary_joined(mercenary: Dictionary)                            # 1 arg
signal mercenary_left(mercenary: Dictionary, reason: String)             # 2 args
signal mercenary_injured(mercenary: Dictionary, days: int)                # 2 args
signal achievement_unlocked(achievement: Dictionary)                     # 1 arg
```

**한 핸들러가 여러 시그널의 콜백이면, 가장 많은 인자를 가진 시그널 기준 디폴트 인자**:
```gdscript
# ❌ 런타임 ERROR (silently logged, 게임은 계속됨)
func _on_mercenary_changed(_m: Dictionary) -> void: pass

# ✓ 3개 시그널 모두 OK
func _on_mercenary_changed(_m = null, _reason_or_days = null) -> void: pass
```

검증: `LB_VERIFY`에 `GameWorld.resolve_battle("defeat", 1, 0)` 호출 → `mercenary_left(m, reason)` 시그널 emit → 핸들러에서 ERROR 없음 확인.

## LB_VERIFY 검증 단계 추가 (8~9단계)

`main.gd._run_verify()` 끝에 추가:

```gdscript
# 8) 대시보드 화면 검증
print("[4.7] 영지 대시보드 화면 검증")
var dashboard = get_tree().current_scene.find_child("Dashboard", true, false)
if dashboard and dashboard.has_method("show_screen"):
    dashboard.show_screen()
    await get_tree().process_frame
    assert(dashboard.visible)

    # 자원 카드 값 확인
    var gold_v: Label = dashboard.get_node_or_null(".../GoldValue")
    assert(gold_v.text == str(GameWorld.gold))

    # 차트용 히스토리
    assert(GameWorld.history.size() >= 1, "히스토리 최소 1일")

    # 업적 해금 시뮬
    GameWorld.unlock_achievement("test_achv", "테스트", "검증용")
    await get_tree().process_frame
    var ach_list: VBoxContainer = dashboard.get_node_or_null(".../AchList")
    assert(ach_list.get_child_count() == GameWorld.achievements.size())

    # 차트 redraw
    var chart: Control = dashboard.get_node_or_null(".../ChartCanvas")
    chart.queue_redraw()
    await get_tree().process_frame
    print("  ✓ 대시보드 검증 통과")
```

## 토스트 알림 패턴 (자동 진행 ON 첫 진입 안내)

```gdscript
var _toast_tween: Tween = null

func _show_toast(message: String, duration: float = 5.0) -> void:
    if toast_label == null: return
    toast_label.text = message
    if _toast_tween != null and _toast_tween.is_valid():
        _toast_tween.kill()
    _toast_tween = create_tween()
    _toast_tween.tween_property(toast_label, "modulate:a", 1.0, 0.3)  # 페이드 인
    _toast_tween.tween_interval(duration)                             # 유지
    _toast_tween.tween_property(toast_label, "modulate:a", 0.0, 0.5)  # 페이드 아웃
```

**main.tscn**: `Toast Label` 노드, anchor 0.5/0.92 (화면 하단 중앙), modulate alpha 0 (처음 투명), mouse_filter=2 (클릭 무시).

## main.tscn 통합 패턴

```ini
[gd_scene load_steps=4 format=3 uid="uid://b1lastbanner"]

[ext_resource type="Script" path="res://scripts/main.gd" id="1_main"]
[ext_resource type="PackedScene" uid="uid://b1decisiondialog" path="res://scenes/decision_dialog.tscn" id="2_dialog"]
[ext_resource type="PackedScene" uid="uid://b1roster" path="res://scenes/roster.tscn" id="3_roster"]
[ext_resource type="PackedScene" uid="uid://b1dashboard" path="res://scenes/manor_dashboard.tscn" id="4_dashboard"]

[node name="Main" type="Node2D"]
script = ExtResource("1_main")

[node name="DecisionDialog" parent="." instance=ExtResource("2_dialog")]
[node name="RosterScreen" parent="." instance=ExtResource("3_roster")]
[node name="Dashboard" parent="." instance=ExtResource("4_dashboard")]
```

## Pitfalls 요약

1. **`theme_override_*` 인덱스 할당 불가** → `add_theme_*_override(name, value)` 메서드 사용
2. **`Control._draw()` 직접 호출 X** → `queue_redraw()` + `_draw` 시그널 구독
3. **`Label` 동적 추가 시 `add_theme_font_size_override` 필수** (theme 없으면 기본 16px 작음)
4. **`_process`에서 `refresh()` 전체 호출은 무거움** → 필드별 분리 refresh (metrics/bars/log/achievements/chart)
5. **시그널 핸들러 인자 통일** → 모든 시그널 인자 다 디폴트 (`_x = null, _y = null`)
6. **history ring buffer 7일** → `pop_front()` 호출 잊으면 무한 증가
7. **save_state/load_state에 history 포함** → 사용자 미진입 1달 후 차트/로그/업적 보존
8. **Resource_max normalize** → `max(max_val, 1)` (0 나눗셈 방지)
9. **차트 size 자동 반영** → `chart_canvas.size` 매번 (리사이즈 대응)
10. **`draw_string(KOREAN_FONT, ...)` 한글 폰트 명시** → 안 하면 □ 깨짐 (godot-game-bootstrap의 한글 폰트 패턴 재사용)

## 다음 확장

- **전투 결과 시각화** — BANDIT_RAID 해결 후 생존자/사망자 모달
- **자원 차트 인터랙션** — 호버 시 해당 일수 자원값 툴팁
- **예측 라인** — 현재 추세 기반 7일 후 자원 예측 (점선)
- **업적 토스트** — `unlock_achievement` 시 화면 하단 "🏆 [업적명] 달성" 페이드
- **차트 디스크 저장** — 매 7일마다 history JSON 덤프 (재진입 시 차트 즉시 표시)