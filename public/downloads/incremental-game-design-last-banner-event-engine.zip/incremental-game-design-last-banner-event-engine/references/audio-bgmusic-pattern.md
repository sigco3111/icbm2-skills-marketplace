# BGM/SFX 배경음악 패턴 (Last Banner 9차, 2026-07-16 검증)

자동 진행 게임에 분위기를 더하는 BGM 시스템. Wesnoth 음악 632곡이 asset_host.json에 등록되어 있어 즉시 활용 가능. **사용자 한 명 작업이 천 건 작업** — 매크로 단축키보다 음악 전환이 몰입감을 크게 좌우함.

## 트리거

- "BGM 넣어줘", "배경음악 추가", "Wesnoth 음악 활용", "분위기 개선", "전투 음악 자동 전환", "계절별 음악", "AudioManager 만들어줘"
- 자동 진행 + 결정 큐 + 시각화까지 완성된 후 마무리로. 음악 없으면 데모가 빈약해 보임.

## 아키텍처

```
AudioManager (autoload)
├── BGM AudioStreamPlayer (루프 재생)
├── SFX AudioStreamPlayer (1회 재생)
├── _cache: Dictionary            # path → AudioStream (메모리 캐시)
└── TRACKS / SFX const           # 키 → 파일 경로 매핑

AssetRegistry.fetch_file(path, callback)   # ← lazy fetch + 콜백
└── CDN → user://persistent/assets/ → AudioStreamOggVorbis.load_from_file()
```

**Lazy fetch + 캐시** 전략:
1. 첫 요청 시 CDN (`cdn.jsdelivr.net/gh/...`) 에서 다운로드
2. `user://persistent/assets/...` 에 저장 (Web에서는 IndexedDB)
3. 다음 요청 시 디스크 캐시 hit → 즉시 재생
4. 메모리 캐시 (`_cache[path]`) 로 두 번째 재생은 즉시 시작

Vercel 100MB 파일 제한 우회 + 초기 pck < 1MB 유지 → 음악은 lazy.

## AudioManager 핵심 구현

### 상수 정의

```gdscript
const TRACKS := {
    "menu":       { "file": "audio/music/main_menu.ogg",      "loop": true,  "volume": 0.4 },
    "peace":      { "file": "audio/music/elf-land.ogg",       "loop": true,  "volume": 0.4 },
    "explore":    { "file": "audio/music/northern_mountains.ogg","loop":true, "volume":0.4 },
    "winter":     { "file": "audio/music/northerners.ogg",     "loop": true,  "volume": 0.4 },
    "battle":     { "file": "audio/music/battle.ogg",          "loop": true,  "volume": 0.5 },
    "battle_epic":{ "file": "audio/music/battle-epic.ogg",     "loop": true,  "volume": 0.5 },
    "victory":    { "file": "audio/music/victory.ogg",         "loop": false, "volume": 0.6 },
    "defeat":     { "file": "audio/music/defeat.ogg",          "loop": false, "volume": 0.6 },
    "defeat2":    { "file": "audio/music/defeat2.ogg",         "loop": false, "volume": 0.6 },
    "heroes":     { "file": "audio/music/heroes_rite.ogg",     "loop": false, "volume": 0.6 },
    "legends":    { "file": "audio/music/legends_of_the_north.ogg","loop":false,"volume":0.6 },
    "journey_end":{ "file": "audio/music/journeys_end.ogg",    "loop": false, "volume": 0.6 },
}
```

**`loop: false`** 트랙 (victory/defeat/heroes): 한 번 재생 후 menu/peace BGM으로 자동 복귀 (`_on_bgm_finished`).

### `play_bgm` Lazy Fetch

```gdscript
func play_bgm(track_key: String, fade_duration: float = 0.5) -> bool:
    if not TRACKS.has(track_key): return false
    var track_info: Dictionary = TRACKS[track_key]
    _current_track = track_key
    _load_and_play_bgm(track_info.file, track_info, fade_duration)
    return true

func _load_and_play_bgm(file_path: String, track_info: Dictionary, fade_duration: float) -> void:
    if _cache.has(file_path):
        _start_bgm_with_stream(_cache[file_path], track_info, fade_duration)
        return
    # AssetRegistry.fetch_file은 콜백 호출 (asset_registry.gd에서 추가한 메서드)
    AssetRegistry.fetch_file(file_path, func(local_path: String):
        if local_path.is_empty():
            return  # fetch 실패 → 무음 진행
        var stream := _load_stream_from_path(local_path)
        if stream != null:
            _cache[file_path] = stream
            _start_bgm_with_stream(stream, track_info, fade_duration)
    )

func _load_stream_from_path(local_path: String) -> AudioStream:
    if not FileAccess.file_exists(local_path): return null
    var stream := AudioStreamOggVorbis.load_from_file(local_path)
    return stream

func _start_bgm_with_stream(stream: AudioStream, track_info: Dictionary, fade_duration: float) -> void:
    _bgm_player.stream = stream
    _bgm_player.volume_db = linear_to_db(0.0) if fade_duration > 0 else linear_to_db(_volume * track_info.volume)
    _bgm_player.play()
    if fade_duration > 0:
        var tween := create_tween()
        tween.tween_property(_bgm_player, "volume_db", linear_to_db(_volume * track_info.volume), fade_duration)
    music_started.emit(_current_track)
```

**`linear_to_db`** — Godot의 dB 변환 (`linear_to_db(0.5) ≈ -6 dB`). 0에 가까울수록 조용, 1 = 0dB.

### 볼륨 + 음소거

```gdscript
func set_volume(vol: float) -> void:
    _volume = clamp(vol, 0.0, 1.0)
    if _bgm_player.playing and TRACKS.has(_current_track):
        var info: Dictionary = TRACKS[_current_track]
        _bgm_player.volume_db = linear_to_db(_volume * info.volume)

func toggle_mute() -> bool:
    _muted = not _muted
    AudioServer.set_bus_mute(0, _muted)  # 0 = Master bus
    return _muted
```

**볼륨 × 트랙 볼륨 = 실제 출력**. 트랙마다 다른 볼륨 (전투 0.5, 평화 0.4) → 같은 마스터 볼륨에서 상대적 강도 조절.

### `play_context_bgm` — 상황별 자동 매핑

```gdscript
func play_context_bgm(context: String) -> void:
    var track: String = context
    match context:
        "menu", "boot":       track = "menu"
        "peace", "explore", "play": track = "peace"
        "battle", "combat":    track = "battle"
        "victory":             track = "victory"
        "defeat":              track = "defeat"
        "winter":              track = "winter"
    play_bgm(track)
```

외부에서 `AudioManager.play_context_bgm("battle")` 호출만 하면 자동으로 트랙 매핑 + 재생. **각 호출 측이 트랙 이름을 알 필요 없음**.

## AssetRegistry 확장 — `fetch_file(path, callback)`

기존 `fetch_asset(path)`는 시그널 emit만 함. **단일 파일 + 즉시 콜백**이 필요해 새 메서드 추가:

```gdscript
# asset_registry.gd
var _pending_callbacks: Dictionary = {}

func fetch_file(rel_path: String, callback: Callable) -> void:
    if _fetched.has(rel_path):
        callback.call(_fetched[rel_path])
        return
    if not callback.is_valid():
        fetch_asset(rel_path)
        return
    _pending_callbacks[rel_path] = callback
    fetch_asset(rel_path)

# _on_request_done에서 호출 추가
func _on_request_done(...):
    # ... 기존 로직 ...
    if _pending_callbacks.has(rel_path):
        var cb: Callable = _pending_callbacks[rel_path]
        _pending_callbacks.erase(rel_path)
        if cb.is_valid():
            cb.call(local_path)
    # 실패 시에도 "" 전달
    if result != HTTPRequest.RESULT_SUCCESS or response_code != 200:
        if _pending_callbacks.has(rel_path):
            var cb_fail: Callable = _pending_callbacks[rel_path]
            _pending_callbacks.erase(rel_path)
            if cb_fail.is_valid():
                cb_fail.call("")  # 빈 문자열로 실패 전달
```

**`_pending_callbacks` Dictionary 1개** — path → Callable. fetch_asset 완료 시 콜백 호출 후 제거.

## 자동 BGM 전환 — 시그널/이벤트 훅

자동 진행 게임의 **각 게임 상태 전환 지점에 BGM 훅** 심기:

```gdscript
# game_manager.gd — start_new_game
func start_new_game(slot: String = "default") -> void:
    SaveManager.new_game(slot)
    TimeManager.enable_auto_progress()
    _transition(State.PLAYING)
    game_started.emit()
    if AudioManager and AudioManager.has_method("play_context_bgm"):
        AudioManager.play_context_bgm("peace")  # ← 새 게임은 평화

# event_engine.gd — _on_season
func _on_season(season: String) -> void:
    if season == "겨울":
        DecisionQueue.push("WINTER_PREPARATION", {...}, DecisionQueue.Priority.MEDIUM)
        if AudioManager:
            AudioManager.play_context_bgm("winter")  # ← 계절별
    elif season in ["봄", "여름", "가을"]:
        if AudioManager:
            AudioManager.play_context_bgm("peace")

# battle.gd — show_battle / _finish_battle
func show_battle(enemy_count: int, my_power: int, enemy_power: int) -> void:
    _enemy_count = enemy_count
    # ...
    if AudioManager:
        AudioManager.play_context_bgm("battle")  # ← 전투 시작

func _finish_battle() -> void:
    if AudioManager:
        if _outcome == "victory":
            AudioManager.play_context_bgm("victory")
            get_tree().create_timer(3.0).timeout.connect(func():
                AudioManager.play_context_bgm("peace")  # 3초 후 평화 복귀
            )
        elif _outcome == "defeat":
            AudioManager.play_context_bgm("defeat")
            get_tree().create_timer(3.0).timeout.connect(func():
                AudioManager.play_context_bgm("peace")
            )
        else:
            AudioManager.play_context_bgm("peace")
```

**핵심 패턴**: `if AudioManager and AudioManager.has_method(...)` 가드. AudioManager autoload 등록 전 코드 경로에서도 안전.

## UI 컨트롤 — 토글 + 볼륨 슬라이더

```ini
[node name="MusicToggleButton" type="Button" parent="UI/ButtonRow"]
custom_minimum_size = Vector2(0, 64)
text = "🎵 음악 ON/OFF (M)"

[node name="VolumeSlider" type="HSlider" parent="UI/ButtonRow"]
custom_minimum_size = Vector2(0, 48)
min_value = 0.0
max_value = 1.0
step = 0.05
value = 0.5
```

```gdscript
# main.gd
music_toggle_button.pressed.connect(_on_music_toggle_pressed)
volume_slider.value_changed.connect(_on_volume_changed)

func _on_music_toggle_pressed() -> void:
    AudioManager.toggle_mute()
    _update_music_button_text(AudioManager.is_muted())

func _on_volume_changed(value: float) -> void:
    AudioManager.set_volume(value)

func _update_music_button_text(muted: bool) -> void:
    music_toggle_button.text = "🔇 음악 OFF (M)" if muted else "🎵 음악 ON (M)"

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventKey and event.pressed and not event.echo:
        if event.keycode == KEY_M:
            _on_music_toggle_pressed()
            get_viewport().set_input_as_handled()
```

**M 키 단축키 + 버튼** 둘 다 지원. `_unhandled_input`이 키 입력의 마지막 단계라 UI 처리 후 호출됨.

## Web 환경 함정

**Web export에서는 첫 사용자 인터랙션 전까지 AudioContext 자동 정지**. Godot는 이걸 자동으로 처리하지만, `AudioStreamPlayer.play()` 호출이 사용자 클릭 전이면 silent fail. **해결**: 부팅 시 자동 재생 대신 `main.gd._ready()` 끝에서 `play_context_bgm("menu")` 호출 (사용자가 페이지를 클릭했기 때문에 작동).

```gdscript
func _ready() -> void:
    # ... 기타 초기화 ...
    if AudioManager:
        volume_slider.value = AudioManager.get_volume()
    if AudioManager and AudioManager.has_method("play_context_bgm"):
        AudioManager.play_context_bgm("menu")  # ← 첫 클릭 후이므로 OK
```

**사운드 fetch는 백그라운드** — 사용자 인터랙션 불필요. 하지만 재생은 첫 클릭 이후.

## LB_VERIFY 검증

```gdscript
# 4.10) 오디오 매니저 검증
print("[4.10] 오디오 매니저 검증")
print("  - 상태: %s" % AudioManager.status())
print("  - 트랙: %d BGM, %d SFX" % [AudioManager.TRACKS.size(), AudioManager.SFX.size()])

# 핵심 트랙 정의 확인
for k in ["menu", "peace", "battle", "victory", "defeat", "winter"]:
    assert(AudioManager.TRACKS.has(k))

# 메서드 호출 (헤드리스에선 실제 소리 X)
AudioManager.play_bgm("menu")
AudioManager.play_context_bgm("peace")
AudioManager.play_context_bgm("battle")

# 볼륨/음소거
AudioManager.set_volume(0.3)
assert(AudioManager.get_volume() == 0.3)

AudioManager.toggle_mute()
assert(AudioManager.is_muted())
AudioManager.toggle_mute()  # 해제
assert(not AudioManager.is_muted())
```

검증 출력 예:
```
[4.10] 오디오 매니저 검증
  - AudioManager 상태: track=battle, vol=0.50, muted=false, cache=0
  - 트랙 정의: 15종 BGM, 3종 SFX
  - 핵심 트랙 6종 정의 OK
  - 음소거 토글 OK
```

## Pitfalls 요약

1. **`fetch_asset`는 시그널만 emit, 즉시 콜백 없음** → AudioManager처럼 즉시 처리 필요한 경우 `fetch_file(path, callback)` 사용
2. **음악 파일이 이미 캐시되어 있어도 콜백이 즉시 호출되어야 함** → `_fetched.has(rel_path)` 분기에서 즉시 `callback.call(local_path)` (이미 받은 파일도 콜백으로 흐름 일관성 유지)
3. **볼륨 0과 음소거는 다름** — 볼륨 0은 재생은 됨 (무음), 음소거는 `AudioServer.set_bus_mute(0, true)` (버스 자체 정지)
4. **`linear_to_db(0.0)` = `-inf`** → 절대 0을 직접 넣지 말 것. 페이드 시작은 `linear_to_db(0.001)` 정도로
5. **BGM fade-in 트윈 중 다른 트랙 전환** → 트윈이 진행 중이면 `.kill()` 후 새로 시작 (이전 BGM 페이드 안 끊김)
6. **`AudioStreamOggVorbis.load_from_file()` 실패 시 null** → `load(local_path)` 일반 load 시도 (mp3 등 다른 포맷 대비)
7. **Web의 AudioContext 첫 클릭 전 자동 정지** → `main.gd._ready()` 끝에서 play 호출 (페이지 로드 + 클릭 후)
8. **`play_context_bgm` 가드 `if AudioManager and AudioManager.has_method(...)`** — autoload 등록 순서 의존 코드 회피
9. **`loop: false` 트랙은 `music_finished.emit` 후 menu/peace 자동 복귀** → BGM 무한 반복 방지
10. **JSON 직렬화 시 Callable 못 저장** → `_pending_callbacks` Dictionary는 메모리만, save_state 대상 X

## 핵심 4가지 학습

1. **Lazy fetch + 메모리 캐시** — 첫 재생만 네트워크, 이후 즉시
2. **`play_context_bgm` 추상화** — 외부 호출 측은 트랙 이름 모름
3. **상황별 훅 (시그널/event)** — 게임 상태 변화 지점에 자동 BGM 전환
4. **볼륨 × 트랙 볼륨** — 같은 마스터에서 트랙별 상대 강도 조절

## 다음 확장

- **SFX 확장** — click/fanfare/alarm 외 새 SFX (UI 클릭, 업적 달성, 사망 등)
- **Web Audio 사용자 인터랙션 게이트** — 첫 클릭 후 `_audio_unlock` 플래그 활성화
- **동적 BGM 페이드** — `AudioServer.set_bus_volume_db` 트윈으로 부드러운 전환
- **음악 설정 영속화** — 볼륨/음소거/마지막 트랙 save_state에 저장
- **크로스페이드** — 두 BGM 트랙 동시 재생 + 볼륨 반전 트윈 (CK3 vassal 게임 페이드 패턴)