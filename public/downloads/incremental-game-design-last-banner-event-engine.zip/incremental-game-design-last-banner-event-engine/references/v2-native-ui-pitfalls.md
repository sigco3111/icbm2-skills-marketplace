# Godot 4 네이티브 UI 반문 — Control 부모 + z-order + 가시성 함정 (Last Banner v2.1 ~ v3.1)

> v2 리셋 후 macOS 네이티브 .app 빌드 환경에서 반복적으로 만난 **10가지 UI 반문**.
> web export / 모바일 viewport 와 다른 **데스크탑 Control + SignalHandler 기반** 함정들.
> v3.1에서 3가지 추가 (tscn patch 폭파 + GDScript 파스 오타 5종 + UI 안전 패턴 5종).

## 종합 함정 10가지

### 1. CanvasLayer z-order 충돌 (가장 빈번)

**증상**: 모달이 떠있는데 안 보이거나, 어떤 패널이 다른 패널 뒤에 깔림.

**원인**: Godot 4에서 Control 노드의 z-order는 (a) 부모 CanvasLayer 우선 → (b) 같은 레이어 안에서는 형제 추가 순서. ModalLayer을 GameWorld/UI/TitleScreen과 같은 CanvasLayer 레벨에 두면 z-order가 자식 추가 순서대로 결정 → 모달이 가려짐.

**해결 — 4-tier CanvasLayer 분리 패턴** (`scenes/main.tscn`):

```ini
Main (Node2D)
├─ ManorLayer (CanvasLayer layer=0)        [게임 풍경도]
├─ TitleLayer (CanvasLayer layer=5)        [타이틀 화면]
├─ UI (CanvasLayer layer=10)               [자원바/버튼행 — 게임 모드만 보임]
├─ ModalLayer (CanvasLayer layer=100)      [결정 모달/DimBG — 항상 위]
├─ BattleLayer (CanvasLayer layer=90)      [전투 화면 — Modal 아래]
```

**모달이 갑자기 안 보이는 증상 4번 반복됨** (v2.1 v2.3.4 v3.0 v3.1.3):
- v2.1 ManorDashboard PanelContainer가 ModalLayer 위 CanvasLayer에 추가됨 → 모달 위에 그려짐
- 해결: `scenes/main.tscn` 재작성으로 4-tier 분리 완료

**진단 단계**:
1. 모달 인스턴스 OK, `visible=true` 이지만 안 보임 → z-order 의심
2. `control.show()` → 0.5초 후 `control.top_level = true` 시도 후 ModalLayer에서 별도 Canvas로 분리하는 게 정답
3. `layer` 값을 5, 10, 100으로 점진 분리

### 2. Area2D가 Control 부모 트리에서 마우스 이벤트 미수신 (가장 오래 잡힘)

**증상**: Area2D + CollisionShape2D + Sprite2D 조합을 Control 내부에 배치했을 때, `area.input_event.connect(handler)`가 영원히 호출되지 않음.

**근본 원리**: Godot 4의 Control 부모는 `Viewport.input_event` 파이프라인과 별도의 `_gui_input` 메커니즘 사용. Area2D/Sprite2D는 Viewport 기반이라 Control 부모의 `_gui_input` 라우터를 타지 않음.

**해결**: Sprite/Area2D 대신 **`TextureButton`** (Control 상속) 사용. TextureButton은:
- size/position 모두 Control 좌표계
- `mouse_entered`, `mouse_exited`, `pressed` 시그널이 정상 발화
- `texture_normal`/`hover`/`pressed`/`focused` 모두 동일 텍스처 설정 가능

```gdscript
var btn := TextureButton.new()
btn.texture_normal = tex
btn.texture_pressed = tex
btn.texture_hover = tex
btn.ignore_texture_size = true
btn.position = pos - Vector2(tex.get_width() * scale / 2.0, tex.get_height() * scale / 2.0)
btn.size = Vector2(tex.get_width() * scale, tex.get_height() * scale)
btn.mouse_filter = Control.MOUSE_FILTER_STOP   # 중요 — 자식 클릭 가로채기
scene_root.add_child(btn)

btn.mouse_entered.connect(_on_character_hover.bind(character))
btn.mouse_exited.connect(_on_character_unhover.bind(character))
# 클릭은 의도적으로 연결 안 함 (사용자 결정)
```

**Godot 4 GDScript 함정: TextureButton에 없는 속성**:
```gdscript
# ❌ Invalid assignment of property 'stretch' with value of type 'bool'
btn.stretch = true
btn.expand_icon = true

# ✓ Godot 4의 TextureButton에 그런 속성 없음 — 제거
btn.ignore_texture_size = true
# size + custom_minimum_size만 사용
```

**Mouse_entered가 안 떨어지는 진단**:
- `mouse_filter = MOUSE_FILTER_IGNORE` (기본값) → 마우스 이벤트 통과, 자식에서 안 잡힘
- `mouse_filter = MOUSE_FILTER_STOP` (필요) → 자식이 마우스 이벤트 잡음

### 3. PanelContainer visible 부모-자식 상속 오작 (가장 잘못된 진단)

**증상**: DetailPanel에 자식 VBox 추가했는데 Panel Container만 보이고 자식 안 보임, 또는 Panel이 보이지 않게 했는데 자식만 떠있음.

**진단 — Panel은 자식 visible을 무시하지 않음, 부모가 hidden이면 자식도 hidden**:
- PanelContainer는 자식 Control을 자기 영역에 클립 + 정렬
- 부모 (`DetailPanel.visible = false`) → 자식 (VBox) 안 보임 (Godot 렌더 파이프라인 stop)
- 부모 true + 자식 false → 패널만 보이고 자식 안 보임
- **이중 안전망**: tscn에서 `visible = false` 명시 + `.gd _find_nodes()`에서도 `visible = false` 명시

```ini
# scenes/manor_dashboard.tscn
[node name="DetailPanel" type="PanelContainer" parent="..."]
visible = false   # ← 명시 필수 (true가 기본)
```

```gdscript
# manor_dashboard.gd _find_nodes()에서
if detail_panel:
    detail_panel.visible = false   # 런타임 강제 (이중 안전망)
    detail_vbox.visible = false    # 부모와 자식 둘 다 false
```

**호버 시점에 부모와 자식 모두 `visible = true` 필수** (자식만 true면 부모 hidden에 가려짐):

```gdscript
func _show_character_detail(character: Dictionary) -> void:
    if detail_panel: detail_panel.visible = true    # ← 부모 먼저
    if detail_vbox: detail_vbox.visible = true     # ← 그 다음 자식
```

**증상 3번 반복**: 다른 세션에서 같은 증상 + 같은 해결 적용 — 숙지 필수.

### 4. size 변화 시 position 누적 버그 (반복됨)

**증상**: 캐릭터를 호버할 때마다 sprite가 조금씩 좌측상단으로 이동.

**근본 원리**: `(current_pos - delta/2)` 보정 패턴이 **매번 적용될 때마다 누적**:
- hover 1회: size × 1.08, position -= delta/2 (보정됨)
- hover 끝나고 unhover: size × 1.0, position 그대로 → **다음 hover 시작점**
- hover 2회: size × 1.08, position -= delta/2 (또 적용) → **또 누적**
- N회 후 = 좌측상단으로 가속이동

**해결**: **character dict에 `original_position`을 1회 저장** (생성 시점) → hover/unhover 시점에 그 절대 위치 기준으로 보정:

```gdscript
# _add_unit_sprite()에서 캐릭터 생성 시
var character := {
    "button": btn,
    "original_position": btn.position,    # ← 1회만 저장
    "original_size": btn.size,
    ...
}

# _on_character_hover()
var orig_pos: Vector2 = character["original_position"]
var orig_size: Vector2 = character["original_size"]
var boosted: Vector2 = orig_size * (1.0 + HOVER_SCALE_BOOST)
btn.position = orig_pos - (boosted - orig_size) * 0.5
btn.size = boosted

# _on_character_unhover()
btn.position = orig_pos   # 절대 원위치로 복원
btn.size = orig_size
```

**증상 패턴**: "캐릭터가 호버 후 원위치로 안 돌아옴". 5번 반복되는 패턴.

### 5. GDScript `%(...)` 다중 인수 미지원 — `[]` 배열만 가능

**증상**: `print("... %s %s" % (a, b))` → 파스 에러 `Expected closing ")" after grouping expression`.

**원인**: GDScript는 Python과 다르게 `%` 다음 **배열 `[]`만 허용**. 튜플 `(a, b)`는 파스 에러.

**해결**:

```gdscript
# ❌ 파스 에러
print("[Dashboard] scene_root=%s, detail_panel=%s" % ("OK" if scene_root else "NULL", "OK" if detail_panel else "NULL"))

# ✓ 배열 사용
var scene_state: String = "OK" if scene_root else "NULL"
var detail_state: String = "OK" if detail_panel else "NULL"
print("[Dashboard] scene_root=%s, detail_panel=%s" % [scene_state, detail_state])
```

**탐지 패턴**: `print(... %(...)`, `assert(... %(...)`, f-string처럼 쓰려는 모든 곳.

### 6. LB_VERIFY stage 사이 reset 누락

**증상**: `[11] 자동 ON에서 모달이 떠있어야 함` 같은 assertion이 실패하는데 분명히 push했음에도 안 뜸.

**근본 원리**: 모든 LB_VERIFY 단계가 같은 SceneTree에서 순차 실행 → 전 단계 상태가 다음 단계에 영향:
- `[10] OFF 무한 대기`: 모달 띄움 + `_current_decision_id = 24` 세팅 + 모달 그대로 유지
- `[11] ON 자동 닫힘`: 새 LOW push (id=25) → `_current_decision_id (24) < 25` OK인데... `_last_queue_size = 0`이나 `modal.visible = false` 를 안 명시했으면 잔존하는 모달이 즉각적 자동 skip에 걸려서 새 모달이 안 뜨는 것처럼 보임

**해결**: 각 단계 시작마다 **모든 transient 상태를 명시적으로 reset**:

```gdscript
# [11] 시작 시 전체 reset 패턴
_current_decision_id = -1
_last_queue_size = 0
if decision_modal: decision_modal.visible = false
if modal_dim_bg: modal_dim_bg.visible = false
# 큐도 명시적 비우기
while not DecisionQueue.get_all_pending().is_empty():
    DecisionQueue.resolve(DecisionQueue.get_all_pending()[0].id, {"id": "force", "label": "force"})
# EventEngine의 daily cap도 reset (MAX_PER_DAY 체크 회피용)
EventEngine._decisions_today = 0
```

**다른 흔한 함정**: `randf() > 0.6` 같은 확률 게이트 → 시드에 따라 fail. **강제 push**: `EventEngine._maybe_xxx()` 호출 대신 `DecisionQueue.push("TYPE", payload, Priority.X)` 직접 호출로 우회.

### 7. 빈 상태창이 항상 표시 — Panel 부모 visibility 검출력 부족

**증상**: DetailPanel이 호버하지 않아도 항상 표시됨 (텍스트는 빈 VBox).

**원인**: tscn에서 `visible` 속성을 명시하지 않으면 기본값 `true`로 동작. PanelContainer는 부모 visible이 true이면 자기 영역만 그리고, 자식 VBox의 visible 만 false여도 자기 패널 박스는 보임.

**해결 패턴** (이중 안전망):
1. **tscn**: `[node name="DetailPanel" ...] visible = false` (씬 로드 시점부터 숨김)
2. **`_find_nodes()`**: `if detail_panel: detail_panel.visible = false` (런타임 안전망)
3. **호버 시**: 부모와 자식 모두 `true` (이중 안전망 패턴)

**호버인데 상태창이 안 나오는 변형 증상**:
- `detail_vbox.visible = true` 했는데 `detail_panel.visible` 안 바꿈 → PanelContainer 부모가 hidden이면 자식도 hidden
- 해결: 호버 시 부모와 자식 모두 `true` (이중 안전망 패턴)

### 8. tscn `replace_all=true` 사고 (v3.1.4 폭파, 새 추가)

**증상**: `replace_all=true`로 tscn 노드 일괄 삭제 시도 → 같은 패턴 (PanelContainer, Button, Label 등)이 많으면 의도치 않게 다른 노드까지 삭제.

**v3.1.4 사고**: manor_dashboard.tscn의 ChartCard 패턴 (ChartCard type=PanelContainer)이 같은 파일 안에 Legacy와 새로 추가 두 위치 존재 → `replace_all=true`로 삭제 시도 → `manor_title`, `DetailPanel`, `VisitorCard`, `QuickStatsCard`, `BottomRowInColumn`, `Roster*` 모두 삭제됨.

**해결 규칙 4가지**:

**규칙 1: `replace_all=true` 사용 X** — 항상 unique anchor + context 포함:
```python
# 옛 방식 (unique 매치 가능)
old_string = "script = ExtResource(\"1_roster\")\n\n[node name=\"DimBG\" type=\"ColorRect\" parent=\".\"]"
new_string = "script = ExtResource(\"1_roster\")\n\n[node name=\"XButton\" type=\"Button\" parent=\".\"]\n... ...\n\n[node name=\"DimBG\" type=\"ColorRect\" parent=\".\"]"

# ❌ 위험
old_string = "[node name=\"ChartCard\" type=\"PanelContainer\""   # ← 4~5개 노드 매치 → 폭파
```

**규칙 2: 패치 후 항상 `git status --short` 확인**:
```bash
git status --short | wc -l          # 추가/삭제 줄 수 확인
git diff --stat scenes/<file>.tscn  # 큰 diff 면 폭파 의심
```
diff 줄 수가 **의도한 변경의 2배 이상**이면 `git checkout -- scenes/<file>.tscn` 복구 후 `write_file`로 깨끗하게 재작성.

**규칙 3: 폭파 후 복구 — `write_file` 전체 재작성이 안전**:
```python
# 잘못된 patch 후 폭파 확인되면:
# 1) patch 전 git 버전으로 checkout
# 2) 동일 내용으로 fresh write_file (전체 재작성)
```
v3.1.4 복구 — `manor_dashboard.tscn`의 모든 노드 (BG, CenterRoot, LeftColumn, ManorTitle+TitleLabel, ManorScene+SceneHost+SceneRoot+DetailPanel+VBox, BottomRowInColumn+VisitorCard+QuickStatsCard, RightColumn+RosterTitle+RosterList+RosterScroll+RosterVBox) 를 통째로 재작성.

**규칙 4: 같은 노드명 부모가 다른 위치에 있을 때 unique context 사용**:
```python
old_string = """[node name=\"ChartCard\" type=\"PanelContainer\" parent=\"CenterRoot/LeftColumn/ManorScene/SceneHost\"]
anchor_left = 0.0
anchor_top = 0.0
anchor_right = 0.0
anchor_bottom = 0.0
offset_left = 16.0
offset_top = 12.0
offset_right = 220.0
offset_bottom = 110.0
mouse_filter = 0"""

new_string = """[node name=\"ChartCard\" type=\"PanelContainer\" parent=\"CenterRoot/LeftColumn/ChartRow\"]
custom_minimum_size = Vector2(220, 0)
mouse_filter = 0"""
```

### 9. GDScript 파스 오타 5종 (v3.1.5 디버깅, 새 추가)

오타 1: `[...])` — `]` 닫고 `)` 추가:
```gdscript
# ❌ 파스 에러
chart_row_label.text = "..." % [int(history[-1].gold), int(history[-1].food)])

# ✓
chart_row_label.text = "..." % [int(history[-1].gold), int(history[-1].food)])
```

오타 2: `var ... = history[-1]` + 그 줄에 안 닫음:
```gdscript
# ❌ 뒷줄에서 함수 호출 끊김
var last: Dictionary = history[-1]
chart_row_label.text = "..." % [last.gold, last.food]

# ✓
var last_gold: int = int(history[-1].gold)
var last_food: int = int(history[-1].food)
chart_row_label.text = "..." % [last_gold, last_food]
```

오타 3: `print(...) % (a, b)` 다중 인자 — 위 5번과 동일.

오타 4: `TextureButton.stretch=true` / `expand_icon=true` — Godot 4 존재 X — 위 2번과 동일.

오타 5: `theme_override_font_sizes/font_size = 12` — 할당 불가:
```gdscript
# ❌ 파스 에러: "Only identifier, attribute access, and subscription access can be used as assignment target"
label.theme_override_font_sizes/font_size = 12

# ✓ 메서드 호출
label.add_theme_font_size_override("font_size", 12)
```

### 10. 표준 UI 안전 패턴 5가지 (v3.1 UI 작업에서 모두 사용, 새 추가)

**패턴 1**: 패널 추가 시 항상 write_file로 직접, anchors + offsets 4면 명시
```python
content = f\"\"\"[node name=\"{name}\" type=\"PanelContainer\" parent=\"{parent}\"]
anchor_left = {anchor_left}
anchor_top = {anchor_top}
anchor_right = {anchor_right}
anchor_bottom = {anchor_bottom}
offset_left = {offset_left}
offset_top = {offset_top}
offset_right = {offset_right}
offset_bottom = {offset_bottom}
mouse_filter = 0
\"\"\"
```

**패턴 2**: 동적 노드 검색 시 null 가드
```gdscript
var canvas: Control = get_node_or_null(\"...\") as Control
if canvas:
    canvas.queue_redraw()
    print(\"  ✓ ChartCanvas 노드 존재: %s\" % str(canvas.size))
else:
    print(\"[WARN] 차트 노드 없음\")
```

**패턴 3**: 패딩 + 라인 영역 분리 (차트 안에 텍스트 겹침 방지)
```python
# ChartCanvas 내부 패딩 — ChartTitle 영역 (0~22) + 라인 영역 (22~끝)
offset_top = 26        # 위쪽 26px = 라벨 영역
offset_bottom = -6    # 아래쪽 6px = 차트 카드 padding
```

**패턴 4**: 패딩 줄여서 라인 영역 활용 (텍스트 있는 차트 vs 없는 차트)
```gdscript
# 텍스트 없는 차트 (v3.1.5) → padding 줄임 (28,14 → 20,12)
# 텍스트 있는 차트 (v3.1.3) → padding 더 줌 (28,14)
var padding := Vector2(20, 12) if not has_chart_title else Vector2(28, 14)
```

**패턴 5**: HBox로 텍스트 + 차트 분리 (겹침 회피)
```python
[node name=\"ChartRow\" type=\"HBoxContainer\" parent=\"...\"]\ncustom_minimum_size = Vector2(0, 92)\n[node name=\"ChartTitleLabel\" type=\"Label\" parent=\".../ChartRow\"]\ntext = \"📈 자원 추이\"\nsize_flags_horizontal = 3          # 가변 (남은 공간 차지)\n[node name=\"ChartCard\" type=\"PanelContainer\" parent=\".../ChartRow\"]\ncustom_minimum_size = Vector2(220, 0)\nmouse_filter = 0
```
→ 텍스트와 차트가 **다른 sibling**으로 분리되어 자연스럽게 영역 구분.

## 진단 패턴 치트시트 (Godot 4 Control UI, 10가지)

| 증상 | 진단 | 해결 |
|---|---|---|
| 호버/클릭 안 됨 + Control 부모 | `Area2D.input_event` 미발화 | `TextureButton` 전환 |
| 모달/패널 가려짐 | 형제 CanvasLayer 비교 | 4-tier CanvasLayer 분리 |
| 보이긴 한데 내용 없음 | PanelContainer 부모 visibility | 부모+자식 둘 다 false 명시 |
| 위치가 누적 드리프트 | 매번 `(current - delta/2)` 보정 | `original_position` 1회 저장 |
| 캐릭터 안 숨김 + 호버 시 떠 있음 | `visible` 속성 tscn 미명시 → 기본 true | tscn에 `visible = false` + 코드 reset |
| LB_VERIFY 단계 fail | `_current_decision_id` 잔존 | 단계 시작 시 -1로 reset |
| 시각 OK인데 결과 null | 자동 진행 OFF인 데 _on_auto_skip 발생 | 첫 줄 `if not auto_progress_enabled: return` |
| tscn patch 폭파 | `replace_all=true` + 같은 노드명 다중 | unique context (anchor 2~3줄) 또는 write_file 전체 재작성 |
| **`print(...) % (a, b)` 파스 에러** | 튜플 다중 인자 미지원 | `var a_str: String; print("%s" % [a_str])` |
| **TextureButton.stretch / expand_icon 에러** | Godot 4에 없는 속성 | 제거 (ignore_texture_size만 사용) |

## 시그널 차이 — Mouse 이벤트 라우터

| 노드 | 부모 | 이벤트 라우터 | 마우스 |
|---|---|---|---|
| Control | Control | `_gui_input` | O |
| TextureButton (Control 상속) | Control | `_gui_input` | O |
| Area2D | **Control 비권장** | `Viewport.input_event` | △ (전파 안 됨) |
| Sprite2D | Control | 시각만 | X |

→ **Control 부모 안에서 마우스 인터랙션 필요하면 Control 상속 노드만 쓸 것**. Sprite/Node2D/Area2D는 화면 표시 전용.

## 호버만 인터랙션 패턴 (Last Banner 사용자 직접 지정)

사용자 디렉티브에 따라 정한 명세:
- **호버**: 상태창 자동 표시 + 캐릭터 정보 채우기
- **마우스 떠남**: 상태창 자동 숨김
- **클릭**: 안 함 (단순화)

이 패턴은 **어떤 팝업/오버레이가 있든 상관없이** GDScript 패턴으로 차용 가능. 자식들의 `is_hovered` 플래그 추적 + `any_hovered` 체크로 다른 캐릭터로 옮겨갔을 때만 갱신:

```gdscript
func _on_character_unhover(character: Dictionary) -> void:
    character[\"is_hovered\"] = false
    # ... 캐릭터 원위치로 복구 ...
    # 다른 캐릭터 호버 중이 아니면 상태창 숨김
    var any_hovered := false
    for c in scene_characters:
        if c.get(\"is_hovered\", false):
            any_hovered = true
            break
    if not any_hovered:
        detail_vbox.visible = false
        if detail_panel:
            detail_panel.visible = false
```

## 11. v3.0 전투 화면 — 결정 큐에서 BattleScene로 라우팅

v2 결정 큐의 BANDIT_RAID에서 \"출격\" 선택 시 BattleScene을 독립 화면으로 표시. 단순화하려면 결정 큐의 result_code만으로 분기:

```gdscript
# main.gd _on_choice_pressed()
var result_code: String = choice.get(\"result\", \"\")
var decision_type: String = _current_decision_type()
if decision_type == \"BANDIT_RAID\" and result_code == \"BATTLE_BANDITS_FIGHT\":
    var battle: Control = _get_battle_scene()
    if battle:
        var enemy_count: int = int(_current_decision_payload().get(\"enemy_count\", 4))
        battle.start_battle(enemy_count)
        # 모달 안 닫음 (전투 화면이 독립)
        # 또는 모달 닫고 BattleScene 슬라이드인 (선택)
```

전투 화면 끝나면 BattleScene가 `visible = false`로 자동 종료 + signal emit로 main.gd가 자원 변동 확인.

**v3.0.3 (CanvasLayer 격리)**: BattleScene가 `Main` 직속 자식 (`Control` → Node2D의 부속) → 가시성 토글 비정상. **별도 CanvasLayer (`BattleLayer layer=90`)에 격리** + ModalLayer(100)보다 아래. UTL layer 분리 — ModalDialog(100) > Battle(90) > UI(10) > Manor(0) > Title(5).

## 12. v3.1 풍경도 안 UI 배치 5번 반복 (새 추가, 제일 중요)

v3.1 UI 작업에서 사용자가 5번 반복 지적:
- v3.1.0 (차트 추가, 우상단) → 차트가 호버 DetailPanel과 겹침
- v3.1.1 (DetailPanel 풍경도 하단) → 방문객 카드와 겹침
- v3.1.2 (차트 좌하단 + DetailPanel 우상단 분할) → 휘장 텍스트와 겹침
- v3.1.3 (차트 휘장 옆 + 텍스트 분리) → 텍스트 + 라인 겹침
- v3.1.4 (차트 + 휘장 HBox) → Resource bar 폭파 사고 + 차트 안 텍스트 OK
- v3.1.5 (차트 Row + 텍스트 Label 차트 밖) → 사용자 만족

**4단계 절차**:

1단계: **어떤 패널이 겹치는지 가시화** — 스크린샷 빨간 박스/화살표가 가리킨 두 PanelContainer 확인.

2단계: **두 패널의 부모 + z-order 시각화**:
```
ManorDashboard
├ ManorTitle (PanelContainer, anchor=...)
└ ManorScene (PanelContainer, size_flags_vertical=3)
   └ SceneHost (Control, mouse_filter=2)
      ├ SceneRoot (Node2D, 캐릭터 sprite 5명)
      ├ ChartCard (PanelContainer) ← 사용자 지적
      └ DetailPanel (PanelContainer) ← 사용자 지적
```

3단계: **해결 옵션 3가지 중 선택**:
| 옵션 | 사용 시기 |
|---|---|
| **A. 한 패널 좌표 이동** | 두 패널의 부모가 다를 때 |
| **B. 두 패널을 같은 부모에서 분리** (HBox/VBox) | 두 패널을 같은 줄에 분리할 때 (가장 흔한 해결) |
| **C. 한 패널을 보이지 않게** (visible=false) | 패널 자체가 불필요할 때 |

**불변량**:
- 텍스트 라벨은 chart/card **바깥** (별도 Panel 또는 별도 Label) — chart 안에 텍스트 넣지 않음
- 모든 패널 anchor는 0~1 비율 + offset 명시
- CanvasLayer.layer는 절대 겹치지 않게 (0/1/10/20/100 등 정수 분리)

4단계: **LB_VERIFY + .app 빌드 + 시각 확인**:
```gdscript
print(\"[12.5.5] 차트 검증\")
var chart_canvas: Control = get_node_or_null(\"ManorDashboard/CenterRoot/LeftColumn/ChartRow/ChartCard/ChartCanvas\") as Control
if chart_canvas:
    chart_canvas.queue_redraw()
    await get_tree().process_frame
    print(\"  ✓ ChartCanvas 노드 존재: %s\" % str(chart_canvas.size))
```
사용자에게 스크린샷 요청 → 그래도 겹치면 1단계로 회귀.

## 수정 이력

- v2.1.0 → v2.1.1: CanvasLayer z-order (modal 가려짐 1번)
- v2.3.0 → v2.3.1: Area2D → TextureButton 전환
- v2.3.1 → v2.3.4: DetailPanel 이중 visible 안전망
- v2.3.4: 캐릭터 호버 position 누적 → original_position 저장
- v2.3.5: DetailPanel을 풍경도 상단으로 이동 (플리커 제거)
- v3.0.0: 전투 화면 — 결정 큐 BANDIT_RAID 라우팅
- v3.0.3: BattleScene CanvasLayer 격리 (직속 자식 가려짐 해결)
- **v3.1.0 → v3.1.5**: UI 배치 5번 반복 — DetailPanel/차트/Roster 패턴 (사용자 직접 지적 5번, 제일 중요한 학습 신호)
- **v3.1.4**: tscn `replace_all=true` 사고 (manor_dashboard.tscn 폭파)
- **v3.1.5**: GDScript 파스 오타 5종 디버깅 (다중 인자 %, [...]) 닫기 등)

## 참조

- `references/v1-to-v2-reset-pattern.md` — v1 → v2 전체 리셋 (스택 갈기)
- `references/decision-queue-on-off-auto-vs-waiting.md` — v2.1.0 결정 큐 ON/OFF
- `references/menu-game-mode-toggle.md` — v2.2.0 타이틀/게임 모드 토글
- `godot-game-bootstrap` (umbrella) — 빌드 파이프라인 / 헬드리스 검증
