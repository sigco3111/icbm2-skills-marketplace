# Last Banner 7~8차 — 튜토리얼 + 왕조/후계자 패턴

Last Banner 7차(튜토리얼 4단계), 8차(왕조/후계자 CK3 양식)에서 검증된 두 가지 핵심 패턴. 자동 진행 게임의 **첫 사용자 경험 완성**과 **저판타지 정치 미학 차별화**에 필수.

## 1. 튜토리얼 4단계 오버레이

### 데이터 모델 — STEPS 배열

```gdscript
# scripts/tutorial.gd
const STEPS := [
    {
        "icon": "🤖",
        "title": "자동 진행",
        "message": "자동 진행이 켜졌습니다.\n게임이 알아서 시간이 흐르고 자원이 변합니다.",
        "hint": "(P 키로 자동 진행 일시정지/재개)"
    },
    {
        "icon": "❓",
        "title": "결정 큐",
        "message": "약탈자/식량 위기/외교 요청 등\n중요한 결정 시 모달이 자동으로 뜹니다.",
        "hint": "(HIGH/CRITICAL 결정은 게임이 멈춥니다)"
    },
    {
        "icon": "📊",
        "title": "영지 대시보드",
        "message": "D 키를 눌러 영지 대시보드를 열어보세요.",
        "hint": "(D 키)"
    },
    {
        "icon": "⚔️",
        "title": "용병 명단",
        "message": "R 키로 용병 명단을 확인하세요.",
        "hint": "(R 키)"
    }
]
```

### SceneTreeTimer 기반 자동 진행 (7초)

```gdscript
var _auto_advance_timer: SceneTreeTimer = null

func _schedule_auto_advance(seconds: float) -> void:
    # 기존 타이머 안전 정리
    if _auto_advance_timer != null and _auto_advance_timer.timeout.is_connected(_on_auto_advance):
        _auto_advance_timer.timeout.disconnect(_on_auto_advance)
    _auto_advance_timer = get_tree().create_timer(seconds)
    _auto_advance_timer.timeout.connect(_on_auto_advance)

func _on_auto_advance() -> void:
    if _active:
        _on_next_pressed()
```

- 7초 후 자동 다음 단계
- 사용자가 클릭하면 그 시점부터 7초 리셋
- `is_connected` 체크 후 disconnect → 중복 연결 방지

### `tutorial_seen` 영속화 — 한 번만 자동 실행

```gdscript
# autoload/game_manager.gd
var tutorial_seen: bool = false

func save_state() -> Dictionary:
    return {
        "current_state": State.keys()[current_state],
        "save_slot": save_slot,
        "tutorial_seen": tutorial_seen
    }

# scripts/tutorial.gd
func start_tutorial() -> void:
    if GameManager.tutorial_seen:
        return  # 이미 봤으면 무시
    _current_step = 0
    _active = true
    visible = true
    _show_step(_current_step)
    _schedule_auto_advance(7.0)

func finish_tutorial() -> void:
    _active = false
    visible = false
    GameManager.tutorial_seen = true  # 영구 플래그
    tutorial_finished.emit()
```

### 다시보기 패턴 (main.gd)

```gdscript
func _on_tutorial_pressed() -> void:
    if tutorial_screen.has_method("start_tutorial"):
        var prev_seen: bool = GameManager.tutorial_seen
        GameManager.tutorial_seen = false  # 강제 무시
        tutorial_screen.start_tutorial()
        await tutorial_screen.tutorial_finished
        GameManager.tutorial_seen = prev_seen  # 다시 자동 트리거 OFF
```

→ 버튼은 항상 활성. 첫 자동은 `tutorial_seen == false`일 때만.

### LB_VERIFY 검증 절차

```gdscript
# 1.7) 튜토리얼 검증
var tutorial: Node = get_tree().current_scene.find_child("TutorialOverlay", true, false)
assert(not GameManager.tutorial_seen)

if tutorial.has_method("start_tutorial"):
    tutorial.start_tutorial()
    assert(tutorial.visible)
    for i in range(4):
        tutorial._on_next_pressed()
    assert(not tutorial.visible)
    assert(GameManager.tutorial_seen)

    # 두 번째 호출 시 무시되어야 함
    tutorial.start_tutorial()
    assert(not tutorial.visible)
```

---

## 2. 왕조/후계자 CK3 양식 시스템

### 인물 dict 구조

```gdscript
{
  "id": int,
  "name": String,                         # 자동 생성
  "class": String,                       # lord / heir / vassal / courtier
  "age": int,
  "stats": {
    "martial": int,                       # 4~15
    "stewardship": int,
    "diplomacy": int,
    "intrigue": int
  },
  "loyalty": int,                         # 0~100
  "ambition": int,                        # 0~100
  "alive": bool,
  "spouse_id": int,                       # -1 = 없음
  "parent_id": int,                       # -1 = 영주
  "heir_rank": int,                       # 0=영주, 1=1순위
  "dynasty": String,
  "portrait_index": int                   # Wesnoth portrait 매핑용
}
```

### GameWorld API

```gdscript
var court: Array = []                     # 모든 인물
var dynasty_name: String = ""
var _next_person_id: int = 0

func create_person(seed_val, base_class, heir_rank, parent_id) -> Dictionary
func add_person(person) -> void
func get_person_by_id(id) -> Dictionary
func get_lord() -> Dictionary
func get_heirs() -> Array                  # heir_rank 순 정렬
func set_heir_rank(person_id, new_rank) -> void
func kill_person(person_id, reason) -> bool
func _spawn_initial_court(seed) -> void   # 영주 1 + 후보 3 + 신하 1

# 시그널
signal person_added(person: Dictionary)
signal person_removed(person: Dictionary, reason: String)
signal succession_changed(new_heir: Dictionary)
```

### 초기 court 생성 — `_spawn_initial_court`

```gdscript
func _spawn_initial_court(seed: int) -> void:
    # 영주 (lord)
    var lord := create_person(seed, "lord", 0, -1)
    lord_name = lord.name  # 동기화
    add_person(lord)

    # 후보 3명 (영주의 형제/자녀/친척)
    for i in range(3):
        var heir := create_person(seed + i + 1, "heir", i + 1, lord.id)
        add_person(heir)

    # 신하 1명
    var steward := create_person(seed + 100, "vassal", -1, -1)
    steward.name = "재상 %s" % steward.name
    add_person(steward)
```

### EventEngine 정치 이벤트

```gdscript
# autoload/event_engine.gd
const SUCCESSION_AUDIT_INTERVAL_MIN := 4320  # 3일

func _on_tick(game_time: int) -> void:
    # ... 기존 4h/8h/10h/12h 주기 체크 ...
    if game_time - _last_succession_audit >= SUCCESSION_AUDIT_INTERVAL_MIN:
        _last_succession_audit = game_time
        _maybe_succession_audit(game_time)

func _maybe_succession_audit(_game_time: int) -> void:
    var heirs: Array = GameWorld.get_heirs()
    for h in heirs:
        h.loyalty = clamp(h.loyalty + randi() % 11 - 5, 0, 100)
        h.ambition = clamp(h.ambition + randi() % 7 - 3, 0, 100)
    # 배신 위험 감지
    for h in heirs:
        if h.loyalty < 25 and h.ambition > 65 and randf() > 0.5:
            _maybe_heir_betrayal(h)
            return
    # 일반 감사 알림
    if randf() > 0.6:
        _maybe_succession_alert(heirs)
```

### 3가지 결정 큐 결과 (apply_result)

| 결과 코드 | 효과 |
|---|---|
| `BETRAYAL_CRUSHER` | kill_person(heir_id), 명성 +5, 용병 2명 사망 |
| `BETRAYAL_BANISH` | remove_person(heir_id), 명성 -3 |
| `BETRAYAL_FORGIVE` | heir.loyalty += 20, 명성 -8 |
| `SUCCESSION_KEEP` | (no-op) |
| `SUCCESSION_SWAP` | 1순위 ↔ 2순위 heir_rank 교환 |
| `SUCCESSION_NURTURE` | gold -30, heir.loyalty += 10 |

### 후계자 화면 (succession.gd) — 인물 카드 동적 생성

`Control` 루트에 `VBox` + `VBox/HeirScroll/HeirList` 구조. `_create_heir_card(h)` 메서드로 카드 동적 생성:

```gdscript
func _create_heir_card(h: Dictionary) -> PanelContainer:
    var card := PanelContainer.new()
    # ... layout 셋업 ...

    var name_label := Label.new()
    name_label.text = "%s (%d세)" % [h.name, h.age]
    if h.loyalty < 25 and h.ambition > 65:
        name_label.modulate = Color(1.0, 0.4, 0.4)
        name_label.text += " ⚠️ 배신 위험"
    # ...

    var loy_bar := ProgressBar.new()
    loy_bar.value = h.loyalty
    if h.loyalty < 30:
        loy_bar.modulate = Color(1.0, 0.5, 0.5)
    # ...

    return card
```

**`_process`에서 매 프레임 refresh**: loyalty/ambition은 자주 변하므로 분리 refresh + 가벼운 갱신.

---

## 3. 공통 LB_VERIFY 검증 함정

### 헤드리스 무한 hang — 3가지 원인

1. **`SceneTree` 직접 호출 시 autoload 미등록** — `godot --script res://verify.gd`로 SceneTree 직접 실행하면 main scene 안 거침 → autoload 0개 → 모든 시그널 연결 실패. **해결**: `LB_VERIFY` 환경변수로 main.gd 분기 (위 헤더리스 검증 패턴 참조).
2. **시그널 인자 미스매치 ERROR** — 핸들러가 시그널 인자 수와 다르면 `Method expected N argument(s)` ERROR + 코드 흐름 중단. **해결**: 핸들러는 모든 인자 디폴트 (`_m = null, _reason = null`).
3. **`process_frame` 루프 누적** — `for i in range(60): await get_tree().process_frame`가 헤드리스에서 안 끝남. **해결**: `await` 제거하고 동기 (`for i in range(144): TimeManager.advance_minutes(10)`).

### `@onready` 평가 순서

`@onready var x = $UI/Toast` 같은 변수는 `_ready()` 함수가 **return 하기 전**에 평가됨. 검증 모드 분기로 early return해도 `@onready`는 이미 평가됨. → null 가드 필수 (`if toast_label == null: return`).

### `apply_result("BETRAYAL_CRUSHER")` 가끔 hang

`dismiss_mercenary` → `mercenary_left` 시그널 → 다른 핸들러가 새 큐 push 가능. 라이브는 OK. **LB_VERIFY에는 기본 검증 (인물 생성/조회/순위 교체) 만 두기**. 배신 시뮬은 라이브 수동 테스트.

---

## 4. 차용 패턴 (다른 incremental game에 그대로)

1. **튜토리얼**: 4~6단계 카드 오버레이 + `STEPS` 데이터 + SceneTreeTimer 자동 + `seen` 영속화 + 다시보기 prev_seen 백업. 어떤 incremental game이든 첫 진입 안내에 그대로 적용.
2. **후계자/인물 시스템**: `class` + 4종 스탯 + loyalty/ambition + 분기 감사 + 배신 트리거. CK3 / Crusader Kings 풍 게임에 필수. 다른 게임 (호위 caravan / 탐험 게임)에도 후보/동료 시스템으로 일반화 가능.
3. **공통 LB_VERIFY**: 어떤 incremental game이든 환경변수 기반 헤드리스 검증 모드를 main.gd에 내장. CI에서도 그대로 재사용.