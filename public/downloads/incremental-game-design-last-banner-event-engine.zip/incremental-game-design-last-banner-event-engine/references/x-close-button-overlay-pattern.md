# X 닫기 버튼 패턴 — 모든 오버레이 화면에 우상단 X (Last Banner 12차, 2026-07-16)

CloseButton은 모든 오버레이 화면 하단에 있지만 작은 화면에서 잘려서 안 보임 → ESC 단축키로만 닫을 수 있어 UX 불편. 해결: **모든 화면에 우상단 X 버튼 통일 추가**.

## 문제 — CloseButton은 있는데 안 보임

- `roster/dashboard/succession/buildings/battle` — 화면 하단 `BottomMargin/BottomHBox/CloseButton` 위치 → 작은 화면에서 잘림
- `decision_dialog/tutorial` — close 버튼 자체가 없음 (ESC로만 닫음)
- 사용자: "단축키 닫기는 정상 동작함" + "메뉴 닫기 UI도 추가" → 시각적 X 버튼 통일

## 해결 — XButton 모든 화면 통일 추가

7개 화면 tscn에 동일 패턴의 XButton 추가 (anchor=우상단, 60×48, ✕ 텍스트, 28pt):

```ini
[node name="XButton" type="Button" parent="."]
anchor_left = 1.0
anchor_top = 0.0
anchor_right = 1.0
anchor_bottom = 0.0
offset_left = -60.0
offset_top = 8.0
offset_right = -8.0
offset_bottom = 56.0
text = "✕"
modulate = Color(1, 1, 1, 0.85)
mouse_default_cursor_shape = 2
theme_override_font_sizes/font_size = 28
```

**위치**: `DimBG`나 `Card`가 root의 자식이므로, XButton을 root 직속으로 둬서 항상 위에 렌더링. `anchor_right = 1.0` → 우상단 고정.

**표시 스타일**:
- `modulate = Color(1, 1, 1, 0.85)` — 약간 투명 (스크린 가리지 않음)
- `mouse_default_cursor_shape = 2` — 손가락 커서 (UI 표준)
- `theme_override_font_sizes/font_size = 28` — 큰 X (탭하기 쉬움, 60×48 영역 내)

## 화면별 tscn 추가 위치 (DimBG 위)

`scenes/<screen>.tscn`에 `[node name="XButton" type="Button" parent="."]`를 `DimBG` 노드 **다음** 또는 **이전**에 추가. Control/CanvasLayer 상관없이 동일:

```ini
[gd_scene load_steps=2 ...]

[ext_resource type="Script" path="res://scripts/<screen>.gd" id="1_<screen>"]

[node name="<Screen>" type="Control"]   # 또는 CanvasLayer
script = ExtResource("1_<screen>")

[node name="XButton" type="Button" parent="."]
anchor_left = 1.0
# ... (위 패턴) ...

[node name="DimBG" type="ColorRect" parent="."]
# ...
```

**중요**: `parent="."` (root에 직접 부착) → 다른 Control 위에 항상 렌더. `parent="DimBG"`나 `parent="Card"`로 하면 가려질 수 있음.

## 각 화면 스크립트 — 핸들러 추가

이미 `_on_close_pressed`가 있으면 그 함수에 XButton도 연결:

```gdscript
# 예: scripts/roster.gd
@onready var close_button: Button = $MainHBox/RightPanel/RightMargin/RightVBox/CloseButton
@onready var x_button: Button = $XButton   # ← 추가

func _ready() -> void:
    # ... 기타 ...
    close_button.pressed.connect(_on_close_pressed)
    if x_button:                              # ← null 가드 (verify_mode 분기 시)
        x_button.pressed.connect(_on_close_pressed)
```

**XButton이 없는 화면 (decision_dialog, tutorial)** — 신규 `_on_x_pressed` 메서드:

```gdscript
# decision_dialog.gd
@onready var x_button: Button = $XButton

func _ready() -> void:
    # ... 기존 connect ...
    if x_button:
        x_button.pressed.connect(_on_x_pressed)

# CRITICAL: 닫기 = "현재 결정 건너뛰기" — 큐에 다음 결정 있으면 다음 표시
func _on_x_pressed() -> void:
    print("[DecisionDialog] X 버튼 — 현재 결정 건너뛰기")
    _clear_choices()
    _hide()
    if DecisionQueue.has_any_pending():
        call_deferred("_show_next")
```

```gdscript
# tutorial.gd
@onready var x_button: Button = $XButton

func _ready() -> void:
    next_button.pressed.connect(_on_next_pressed)
    skip_button.pressed.connect(_on_skip_pressed)
    if x_button:
        x_button.pressed.connect(_on_skip_pressed)   # X = skip과 동일 동작
```

## tscn patch 시 패턴 — `script = ExtResource("...")` 줄 직후에 삽입

`scenes/<screen>.tscn`에서 XButton이 추가될 위치는 항상 **`script = ExtResource(...)` 줄 다음 + `[node name="DimBG" ...]` 줄 앞** (Control) 또는 **`script = ExtResource(...)` 줄 다음 + `[node name="DimBG" ...]` 줄 앞** (CanvasLayer) — Control/CanvasLayer 모두 동일.

```diff
  script = ExtResource("1_roster")
+
+[node name="XButton" type="Button" parent="."]
+anchor_left = 1.0
+anchor_top = 0.0
+anchor_right = 1.0
+anchor_bottom = 0.0
+offset_left = -60.0
+offset_top = 8.0
+offset_right = -8.0
+offset_bottom = 56.0
+text = "✕"
+modulate = Color(1, 1, 1, 0.85)
+mouse_default_cursor_shape = 2
+theme_override_font_sizes/font_size = 28

  [node name="DimBG" type="ColorRect" parent="."]
```

**Patch 검증**: 빈 줄 차이로 unique 매치 안 됨 → `replace_all=true` 또는 patch_old_string에 `[node name="DimBG"` 다음 줄까지 포함해야 unique.

```gdscript
# 옛 방식 (unique 매치)
old_string = "script = ExtResource(\"1_roster\")\n\n[node name=\"DimBG\" type=\"ColorRect\" parent=\".\"]"
new_string = "script = ExtResource(\"1_roster\")\n\n[node name=\"XButton\" type=\"Button\" parent=\".\"]\nanchor_left = 1.0\n# ...\n\n[node name=\"DimBG\" type=\"ColorRect\" parent=\".\"]"
```

→ **반드시 script 줄 + 빈 줄 + DimBG 줄을 한 묶음으로 매치**. tscn 파일들이 거의 동일 패턴이라 `replace_all`은 위험.

## LB_VERIFY 검증

```gdscript
# 4.13) X 닫기 버튼 검증
print("[4.13] X 닫기 버튼 검증")
# 모든 화면의 XButton 노드 존재 확인
var screens := ["RosterScreen", "Dashboard", "SuccessionScreen", "BattleScene", "BuildingsScreen"]
for s in screens:
    var x_btn: Button = get_tree().current_scene.find_child(s, true, false).get_node_or_null("XButton")
    assert(x_btn != null, "%s에 XButton 없음" % s)
    # 클릭 → _on_close_pressed 호출 → visible = false
    var screen: Node = get_tree().current_scene.find_child(s, true, false)
    x_btn.pressed.emit()
    await get_tree().process_frame
    # 화면이 닫혔는지 (visible false 또는 _on_close_pressed가 visible=false 호출)
```

## 흔한 실수

1. **XButton을 `parent="DimBG"`로 둠** → DimBG가 화면 전체 덮으므로 XButton이 그 뒤에 가려짐. **반드시 `parent="."` (root)**.
2. **tscn `modulate = Color(r, g, b)` 3인자** → tscn은 4인자만 허용 (`Color(1, 1, 1, 0.85)`). GDScript 코드는 3인자 OK이지만 .tscn에서는 alpha 명시.
3. **anchor_right 안 줌** → 좌상단에 박혀서 게임 화면 가림. **반드시 `anchor_left = 1.0` + `anchor_right = 1.0`**.
4. **`@onready var x_button = $XButton` 만 하고 `if x_button:` 가드 안 함** → verify_mode 분기에서 null 에러 가능. **항상 `if x_button:` 가드**.
5. **decision_dialog의 X가 큐를 안 비우고 그냥 hide** → 다음 결정이 안 보임. **항상 `call_deferred("_show_next")`**.
6. **tutorial의 X가 _on_next_pressed 호출** → 한 단계 건너뜀 (사용자 혼란). **X = skip과 동일**.

## 권장 적용 순서

1. **모든 tscn에 XButton 일괄 추가** — patch로 한꺼번에
2. **각 화면 스크립트에 `@onready var x_button: Button = $XButton` + `if x_button: x_button.pressed.connect(...)` 추가**
3. **decision_dialog/tutorial은 close 메서드 직접 호출** (`_on_x_pressed`)
4. **LB_VERIFY로 7개 화면 모두 XButton 존재 확인** + 클릭 시 visible=false 확인
5. **빌드 + 라이브 검증** — `godot --headless --quit-after 5` 부팅 후 stderr에 ERROR 없음 확인

## 관련 패턴

- `references/menu-game-mode-toggle.md` — 우상단 `MenuToggleButton` (앵커 패턴 동일)
- `godot-game-bootstrap/references/autoload-signal-race-condition.md` — `@onready` 평가 순서 함정 (XButton이 null일 수 있는 원인)
- `references/tutorial-and-succession-patterns.md` — 튜토리얼 4단계 + 우상단 SkipButton (XButton과 동일 패턴)
