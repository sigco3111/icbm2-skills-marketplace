# 결정 큐 ON/OFF 자동 진행 분기 — 무한 대기 패턴 (Last Banner v2.1.1)

> 사용자 위임 시(자동 진행 ON) 모든 결정을 자동으로, 사용자 직접 플레이 시(자동 진행 OFF) 무한 대기. 결정 큐 시스템의 두 가지 동작 모드.

## 의도

v1 패턴: **HIGH/CRITICAL만 모달, LOW/MEDIUM은 알림만** → 사용자 OFF 상태에서 결정 못 받음.
v2.1 패턴: **모든 우선순위 모달** + `TimeManager.auto_progress_enabled`로 분기:
- **ON**: LOW 3초 / 그 외 5초 후 default 결정 자동 resolve
- **OFF**: **무한 대기** — 사용자가 직접 결정할 때까지 모달 유지

⇒ 위임 의도와 직접 플레이 의도를 명확히 구분. **사용자 UX가 우선**.

## 검증된 패턴 (Last Banner v2.1.1)

### main.gd의 모달 트리거

```gdscript
func _show_next_decision() -> void:
    # 모든 우선순위 모달
    # - 자동 진행 ON: 모든 우선순위 자동 처리 (LOW 3초 / 그 외 5초 후 default)
    # - 자동 진행 OFF: 사용자 결정까지 무한 대기
    for d in DecisionQueue.get_all_pending():
        if d.id > _current_decision_id:
            _current_decision_id = d.id
            _populate_modal(d)
            if modal_dim_bg:
                modal_dim_bg.visible = true
            decision_modal.visible = true
            print("[Modal] 표시: id=%d [%s] %s (auto_progress=%s)" % [
                d.id, DecisionQueue.Priority.keys()[d.priority],
                d.payload.get("title", ""),
                "ON" if TimeManager.auto_progress_enabled else "OFF"
            ])
            # 자동 진행 ON일 때만 자동 결정 타이머 설정
            if TimeManager.auto_progress_enabled:
                var delay: float = 3.0 if d.priority == DecisionQueue.Priority.LOW else 5.0
                _auto_skip_timer = get_tree().create_timer(delay)
                _auto_skip_timer.timeout.connect(_on_auto_skip)
            return
```

### _on_auto_skip 가드 패턴

```gdscript
func _on_auto_skip() -> void:
    # 자동 진행 ON 상태에서만 호출됨 (외부 호출 가드)
    if not TimeManager.auto_progress_enabled:
        return   # OFF면 즉시 return (사용자 결정 대기)
    if _current_decision_id < 0 or not decision_modal or not decision_modal.visible:
        return
    var default_choice := _default_low_choice()
    if default_choice != "":
        _apply_result(default_choice)
        print("[Modal] 자동 결정: id=%d → %s (auto_progress=ON)" % [_current_decision_id, default_choice])
    DecisionQueue.resolve(_current_decision_id, {"id": "auto_skip", "label": "(자동 결정)"})
    _current_decision_id = -1
    if decision_modal:
        decision_modal.visible = false
        if modal_dim_bg:
            modal_dim_bg.visible = false
    GameManager.resume_from_decision()
```

### _default_low_choice (default 결정 매핑)

```gdscript
func _default_low_choice() -> String:
    # 자동 진행 ON에서 default 처리할 선택지 코드 반환
    for d in DecisionQueue.get_all_pending():
        if d.id == _current_decision_id:
            match d.type:
                "VISITOR": return "VISITOR_REJECT"     # 명성 -2
                "FOOD_SHORTAGE":
                    if GameWorld.food < 15:
                        return "FOOD_BUY"               # 위기 → 매입
                    return "FOOD_RATION"                # 부족 → 건제
                "DIPLOMACY": return "DIPLOMACY_REFUSE"  # 명성 -5
                _: return ""
    return ""
```

### _apply_result (default 결정 = 자원 변동)

```gdscript
func _apply_result(code: String) -> void:
    match code:
        "VISITOR_REJECT":
            GameWorld.modify_resource("prosperity", -2)
            GameWorld.log_event("방문객 거절: 명성 -2")
        "FOOD_BUY":
            GameWorld.modify_resource("gold", -50)
            GameWorld.modify_resource("food", 30)
            GameWorld.log_event("식량 매입: -50골드, +30 식량")
        "FOOD_RATION":
            GameWorld.modify_resource("prosperity", -5)
            GameWorld.log_event("건제 시행: 명성 -5")
        "DIPLOMACY_REFUSE":
            GameWorld.modify_resource("prosperity", -5)
            GameWorld.log_event("외교 거절: 명성 -5")
        _:
            push_warning("[Main] 알 수 없는 결과 코드: %s" % code)
```

## 핵심 설계 결정

### "대기 결정 N건" 카운터 제거

v1 패턴: 상단 자원바에 `[📜 대기 결정: N건]` 표시. v2.1에서 **제거**:
- 모달이 가장 직관적 알림 채널
- 자동 진행 ON에선 사용자 안 봐도 게임 진행 → 카운터 무의미
- OFF에선 모달이 떠야 의미 → 카운터 중복

```diff
- var pending: int = DecisionQueue.get_all_pending().size()
- if decision_label:
-     decision_label.text = "📜 대기 결정: %d건" % pending
```

⇒ **결정 큐 = 모달이 유일한 알림**. 카운터 패널은 단순화.

### 이벤트 타입별 default 결정 전략

| 우선순위 | 자동 처리 default | 의미 |
|---|---|---|
| LOW (방문객) | 거절 | 보수적 (사용자 거절보다 손해 작음) |
| MEDIUM (외교) | 거절 | 보수적 (관계 손상) |
| HIGH (약탈자) | (없음 — 사용자만 결정) | 자원 손실 큼, default X |
| CRITICAL (식량 위기) | 매입 (food<15) | 사용자 보호 — 게임 망함 방지 |

⇒ **default 선택 = 보수적이되 게임 손실 방지**. HIGH/CRITICAL은 사용자 결정 필수.

## 검증 (LB_VERIFY [10] + [11] 단계)

### [10] 자동 OFF 무한 대기

```gdscript
print("[10] 모달 자동 OFF 무한 대기 검증")
# 큐 전부 클리어 + 모든 상태 리셋
while not DecisionQueue.get_all_pending().is_empty():
    DecisionQueue.resolve(DecisionQueue.get_all_pending()[0].id, {"id": "force", "label": "force"})
_current_decision_id = -1
_last_queue_size = 0
if decision_modal: decision_modal.visible = false
if modal_dim_bg: modal_dim_bg.visible = false
# 강제 push (daily cap 무관)
DecisionQueue.push("TEST_OFF", {"title": "테스트 (자동 OFF)", ...}, DecisionQueue.Priority.MEDIUM)
await get_tree().process_frame
TimeManager.auto_progress_enabled = false
_check_decision_queue()
await get_tree().process_frame
assert(decision_modal.visible, "자동 OFF에서 모달이 떠있어야 함")
# _on_auto_skip 호출 시 OFF라 즉시 return
_current_decision_id = DecisionQueue.get_all_pending()[0].id if not DecisionQueue.get_all_pending().is_empty() else -1
_on_auto_skip()
assert(decision_modal.visible, "자동 OFF에서 _on_auto_skip 호출되어도 모달 유지")
```

### [11] 자동 ON 자동 결정

```gdscript
print("[11] 모달 자동 ON 검증")
# 강제 클리어
_current_decision_id = -1
_last_queue_size = 0
if decision_modal: decision_modal.visible = false
if modal_dim_bg: modal_dim_bg.visible = false
while not DecisionQueue.get_all_pending().is_empty():
    DecisionQueue.resolve(DecisionQueue.get_all_pending()[0].id, {"id": "force", "label": "force"})
EventEngine._decisions_today = 0   # daily cap 무력화
# 새 LOW 1건 push
EventEngine._maybe_visitor(Time.get_ticks_msec() + 20000)
await get_tree().process_frame
TimeManager.auto_progress_enabled = true
_check_decision_queue()
await get_tree().process_frame
assert(decision_modal.visible, "자동 ON에서 모달이 떠있어야 함")
# _on_auto_skip 호출 → ON이면 닫힘
_on_auto_skip()
await get_tree().process_frame
assert(not decision_modal.visible, "자동 ON에서 _on_auto_skip 후 모달은 닫혀야 함")
```

핵심: **`EventEngine._decisions_today = 0` 강제 리셋** — 10단계에서 push 후 daily cap 채워짐 → 11단계에서 새 push 안 됨.

## 적용 게임

- 자동 진행 로그라이크 (Last Banner, 슬레이 더 서바이벌)
- 시뮬레이션 게임 (Anno 류)
- 인큐베이터 게임 (기본 동작은 자동, 가끔 모달로 개입)

⇒ 모든 자동 진행 게임은 **ON/OFF 분기 + default 결정** 2종 패턴.

## 진화 의도

v1: HIGH/CRITICAL만 모달, LOW/MEDIUM 알림 → 사용자 답답. 카운터 패널.
v2.1: 모든 우선순위 모달 + ON/OFF 분기. 카운터 제거. ⇒ **사용자 의도 명시적으로 구분**.

## 안티패턴

1. **모든 결정 무조건 자동**: 사용자 컨트롤 박탈 → 게임 → 시뮬레이터
2. **모든 결정 무조건 모달**: 사용자 미쳐 답답 → 게임 포기
3. **카운터 패널과 모달 중복**: 정보 노이즈
4. **default 결정 = 항상 유리한 선택**: 게임 trivial → 사고 필요 없음
