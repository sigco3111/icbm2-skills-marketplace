# Menu / Game Mode Toggle — 자동 진행 게임의 UI 모드 전환 (Last Banner 10차, 2026-07-16)

자동 진행 + 결정 큐 + 대시보드 + 후계자 시스템이 모두 갖춰졌을 때 **남은 마지막 한 가지**: 게임 시작 후 메뉴/영지 화면이 **동시에 보이는 혼란 상태**. 해결: UI 모드 토글.

## 문제 — 새 게임 시작 후 메뉴가 그대로 보임

**증상**: `새 게임` 버튼 클릭 → GameWorld 초기화, 자동 진행 ON, Day 1 표시... **그런데 우측에 `새 게임` / `로드` / `자동 진행 토글` / `🏗️ 마을 시설` / `📥 리소스 다운로드` 버튼이 그대로**. status_label에 영지 정보 + 메뉴 버튼이 겹쳐서 혼란.

```gdscript
# ❌ 기존 — 새 게임만 호출, UI는 그대로
func _on_start_pressed() -> void:
    GameManager.start_new_game("default")
    # ... roster_button.disabled = false 등 ...
    _refresh_status()
```

→ 메뉴 화면과 게임 화면이 동시에 노출되어 사용자가 "이게 정상?" 의심.

## 해결 — 메뉴/게임 모드 토글 (3가지 핵심)

### 1) `enter_game_mode()` / `exit_game_mode()` — UI 모드 토글 함수

```gdscript
# scripts/main.gd
func _enter_game_mode() -> void:
    # 메뉴 버튼들 숨김, 게임 토글 버튼 표시
    if button_row:
        button_row.visible = false
    if menu_toggle_button:
        menu_toggle_button.visible = true
    # status_label에 영지 정보 표시
    status_label.text = "Day %d %s — 자동진행: %s — 결정 큐: %d건\n%s\n%s\n%s" % [
        TimeManager.day, TimeManager.season,
        "●" if TimeManager.auto_progress_enabled else "○",
        DecisionQueue.get_all_pending().size(),
        GameWorld.summary(),
        _last_event_text,
        _last_decision_text
    ]
    _refresh_status()

func _exit_game_mode() -> void:
    # 게임 모드 → 메뉴 모드 복귀
    if button_row:
        button_row.visible = true
    if menu_toggle_button:
        menu_toggle_button.visible = false
    # status_label에 매니페스트 정보 복원
    status_label.text = "Last Banner\n리소스 매니페스트 OK — 6 카테고리, %.1f MB\n[리소스 다운로드] 클릭 시 CDN에서 다운로드" % (
        AssetRegistry.get_total_size() / 1024.0 / 1024.0
    )
    _show_toast("📋 메뉴로 돌아갑니다 (자동 진행 계속)")
```

### 2) `MenuToggleButton` — main.tscn에 우상단 고정

```ini
[node name="MenuToggleButton" type="Button" parent="UI"]
anchor_left = 1.0
anchor_top = 0.02
anchor_right = 1.0
anchor_bottom = 0.02
offset_left = -180.0
offset_top = 0.0
offset_right = -16.0
offset_bottom = 44.0
text = "📋 메뉴 (ESC)"
visible = false
```

- 우상단 (anchor_right=1.0) — 게임 화면 가리지 않음
- `visible = false` 기본값 — 메뉴 모드에서만 안 보임
- 게임 모드에서 `visible = true`로 토글

### 3) `_on_start_pressed()` / `_on_load_pressed()`에서 `_enter_game_mode()` 호출

```gdscript
func _on_start_pressed() -> void:
    GameManager.start_new_game("default")
    # ... 기타 버튼 활성화 ...
    _refresh_status()
    _show_toast("🤖 자동 진행 시작 — 결정이 필요하면 모달이 뜹니다 (P: 일시정지)")
    _enter_game_mode()  # ← 메뉴 숨기고 게임 모드 진입

func _on_load_pressed() -> void:
    # ... (saves.is_empty 체크 등) ...
    if GameManager.load_game(saves[0]):
        # ... 버튼 활성화 ...
        _show_toast("📂 로드 완료 — 자동 진행: %s" % auto_state)
        _enter_game_mode()  # ← 마찬가지
```

## ESC 키로 양방향 토글

`unhandled_input`에서 `KEY_ESCAPE` 처리. 게임 중(PLAYING/DECISION_PENDING)이면 메뉴로, 메뉴면 게임으로. 자동 진행은 멈추지 않음 (메뉴로 돌아가도 시계는 흐름).

```gdscript
func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventKey and event.pressed and not event.echo:
        if event.keycode == KEY_M:
            _on_music_toggle_pressed()
            get_viewport().set_input_as_handled()
        if event.keycode == KEY_ESCAPE:
            if GameManager.current_state == GameManager.State.PLAYING or GameManager.current_state == GameManager.State.DECISION_PENDING:
                _on_menu_toggle_pressed()
                get_viewport().set_input_as_handled()

func _on_menu_toggle_pressed() -> void:
    if button_row and button_row.visible:
        _exit_game_mode()
    else:
        _enter_game_mode()
```

**Pitfall — 결정 다이얼로그 열려있을 때 ESC**: `DecisionDialog._input`이 `KEY_ESCAPE`를 처리하므로 `unhandled_input`까지 안 옴. **다이얼로그 닫기 우선**, 그 후 메뉴 토글 — Godot의 input 우선순위가 자동 처리.

## "자동 새 게임 시작" 패턴 — fetch 완료 시

리소스 다운로드 100% 완료 시 자동으로 새 게임 시작하려면:

```gdscript
# autoload/asset_registry.gd의 all_assets_ready 시그널은 fetch 완료 시 자동 emit
# main.gd에서 연결
AssetRegistry.all_assets_ready.connect(_on_assets_ready)

func _on_assets_ready() -> void:
    fetch_button.disabled = false
    if fetch_progress:
        fetch_progress.value = 100
        fetch_progress.visible = false
    _last_fetch_pct = 0
    var total_mb: float = AssetRegistry.get_total_size() / 1024.0 / 1024.0
    _show_toast("✅ 리소스 다운로드 완료! (%.1f MB)" % total_mb)

    # MENU/BOOT 상태면 자동 새 게임 시작
    if GameManager.current_state == GameManager.State.MENU or GameManager.current_state == GameManager.State.BOOT:
        _show_toast("🎮 새 게임을 자동 시작합니다...")
        await get_tree().create_timer(0.5).timeout
        _on_start_pressed()  # ← 이게 _enter_game_mode()도 자동 호출
```

→ 사용자가 "리소스 다운로드" 한 번만 클릭 → 매니페스트 로드 → 다운로드 → 자동 게임 시작. **마찰 0**.

## status_label 분리 — 메뉴 vs 게임 모드 내용

| 모드 | status_label 내용 |
|------|-------------------|
| **메뉴** | "Last Banner\n리소스 매니페스트 OK — 6 카테고리, %.1f MB\n[리소스 다운로드] 클릭 시 CDN에서 다운로드" |
| **게임** | "Day %d %s — 자동진행: %s — 결정 큐: %d건\n%s\n%s\n%s" (영지 요약 + 최근 사건 + 결정 큐) |

같은 Label 노드, 모드 전환 시 `text`만 갱신. **별도 노드 불필요** — 메모리/씬 트리 단순.

## main.tscn 통합 패턴

```ini
[node name="UI" type="CanvasLayer" parent="."]
layer = 1

[node name="StatusLabel" type="Label" parent="UI"]
# ... (메뉴/게임 양쪽에서 재사용)

[node name="FetchProgress" type="ProgressBar" parent="UI"]
visible = false

[node name="ButtonRow" type="VBoxContainer" parent="UI"]
# 새 게임/로드/자동 진행/리소스 다운로드/마을 시설/튜토리얼 버튼들

[node name="MenuToggleButton" type="Button" parent="UI"]
anchor_right = 1.0
visible = false

[node name="DecisionDialog" parent="." instance=ExtResource("2_dialog")]
visible = false
```

**레이어 구조**:
- `StatusLabel` (전경, 모드 양쪽 표시)
- `FetchProgress` (전경, fetch 중만)
- `ButtonRow` (메뉴 모드만, 게임 모드 숨김)
- `MenuToggleButton` (게임 모드만, 메뉴 모드 숨김)
- `DecisionDialog` (layer=10, 최상위, 모달)

## 명칭 변경 패턴 (사용자 요청 시)

사용자가 "자산 가져오기" → "리소스 다운로드" 같은 명칭 변경 요청하면:

| 위치 | 변경 |
|------|------|
| main.tscn 버튼 text | `text = "📥 리소스 다운로드"` |
| main.gd status_label 텍스트 | `"리소스 매니페스트 OK — ..."`, `"리소스 다운로드 시작 — ..."` |
| main.gd 토스트 메시지 | `"📥 리소스 다운로드 시작 — ..."`, `"✅ 리소스 다운로드 완료! ..."` |
| main.gd print/log | `"[Main] 리소스 다운로드 완료 — ..."` |
| 검증 모드 라벨 | `"[4.12] 리소스 다운로드 버튼 검증"` |

**한 곳 변경 시 6곳 동기화** — grep 필수:
```bash
grep -rn "자산" scripts/ scenes/ autoload/  # → 0개 확인
```

**근본 원인**: Godot 프로젝트는 매니페스트/UI/status_label/토스트/print/log/검증 6개 레이어에 같은 단어가 흩어져 있어 명칭 변경 시 grep 의존. 1개 SSOT(예: `const RESOURCE_DOWNLOAD = "리소스 다운로드"`) 도입하면 변경 1곳이지만, 3-4개 화면에서 텍스트 동시 갱신 필요. → **현재 구조에선 grep 패턴 권장**.

## LB_VERIFY 검증

```gdscript
# 4.10) 메뉴/게임 모드 토글 검증
print("[4.10] 메뉴/게임 모드 토글 검증")
# 초기 상태 — 메뉴 모드
var menu_btn: Button = get_node_or_null("/root/Main/UI/MenuToggleButton")
assert(menu_btn != null, "MenuToggleButton 미발견")
assert(not menu_btn.visible, "메뉴 모드에선 MenuToggleButton 숨김")

# 새 게임 → 게임 모드 전환
GameManager.start_new_game("default")
# (실제로는 _on_start_pressed 호출해야 _enter_game_mode() 실행)
# 헤드리스에선 _on_start_pressed()를 직접 호출
_on_start_pressed()
assert(not button_row.visible, "게임 모드에서 ButtonRow 숨김")
assert(menu_btn.visible, "게임 모드에서 MenuToggleButton 표시")

# ESC → 메뉴 복귀
_on_menu_toggle_pressed()
assert(button_row.visible, "메뉴 복귀 후 ButtonRow 표시")
assert(not menu_btn.visible, "메뉴 복귀 후 MenuToggleButton 숨김")
```

## 시너지 — fetch-progress + 자동 게임 시작

이 패턴은 **lazy fetch + 자동 진행 게임** 조합에서 핵심:

1. 사용자가 처음 진입 → 메뉴 화면 (자동 진행 OFF)
2. "리소스 다운로드" 클릭 → 매니페스트 로드 → fetch 시작
3. 4개 동시 다운로드 (FETCH_CONCURRENCY=4) → ProgressBar 0~100%
4. **100% 완료 → `all_assets_ready` 시그널 → `_on_assets_ready` → 자동 `_on_start_pressed()` → `_enter_game_mode()`** → 게임 화면으로 자동 전환
5. 사용자는 메뉴 ↔ 게임을 ESC로 자유롭게 토글

→ **결정 다이얼로그 / 튜토리얼 / 대시보드 / 용병 명단 / 마을 시설 / 후계자 / 전투 / 사운드 / BGM 자동 전환** 모든 기능이 메뉴 ↔ 게임 모드에서 정상 작동. 첫 진입 마찰 0.

## 흔한 실수

1. **MenuToggleButton anchor_right=1.0 안 줌** → 좌상단에 박혀서 게임 화면 가림. **우상단 고정** 필수.
2. **button_row.visible 토글만 하고 status_label 그대로** → 메뉴/게임 정보가 같은 곳에 → 사용자 혼란. **두 곳 모두 갱신**.
3. **`_unhandled_input`에서 KEY_ESCAPE 무조건 처리** → 결정 다이얼로그 닫기 우선되어야. `unhandled_input`이라 자동 우선순위 적용되지만, 결정 다이얼로그의 `_input`이 먼저 소비.
4. **`fetch_button.disabled = false` 안 복원** → fetch 완료 후 MenuToggleButton이나 새 게임으로 진입 못 함. `_on_assets_ready`에서 **항상 `disabled = false`로 복원**.
5. **메뉴에서 다시 게임으로 돌아왔는데 영지 정보 갱신 안 됨** → `_enter_game_mode()`가 `_refresh_status()` 호출 → `_process`가 매 프레임 갱신. 두 가지 안전망.

## 관련 패턴

- `references/dashboard-screen-pattern.md` — 게임 모드에서 보여줄 화면 (Dashboard, Roster, Buildings, Succession)
- `references/tutorial-and-succession-patterns.md` — 첫 진입 튜토리얼 4단계 (튜토리얼이 MenuToggleButton 위에 떠야 함)
- `references/fetch-progress-web-export.md` — fetch 진행률 → all_assets_ready → 자동 게임 시작 흐름
- `godot-game-bootstrap/references/three-layer-safety-net.md` — fetch_button 활성화 3중 안전망 (메뉴 모드 진입 전 필수)
- `godot-game-bootstrap/references/lazy-fetch-fetch_all-pitfalls.md` — 6가지 fetch 함정 (이 토글 패턴이 정상 작동하려면 fetch가 먼저 정상 작동해야)

## 권장 적용 순서

1. **먼저 fetch_button 3중 안전망** (godot-game-bootstrap) — fetch가 안정적이어야
2. **그 다음 결정 다이얼로그** (UI 모달) — 게임 모드에서 첫 사용자 마주침
3. **대시보드/용병/마을/후계자** — 게임 모드에서 보여줄 화면들
4. **메뉴/게임 모드 토글** (이 reference) — 마지막. 위 4개가 안정된 후 UI 모드 분리 적용
5. **튜토리얼** — 모든 기능 안정 후 첫 사용자 안내
