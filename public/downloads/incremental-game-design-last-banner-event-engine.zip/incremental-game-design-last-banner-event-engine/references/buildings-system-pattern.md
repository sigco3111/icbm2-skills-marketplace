# 마을 건설 시스템 패턴 (Last Banner 9차, 2026-07-16)

영지 자원의 심화 콘텐츠. 요새화만 있던 `fortification_level`에 시장/곡창/훈련소/신전/주점 5종 추가. 시설 효과는 일간 변동(`apply_building_effects`)에 통합.

## 6종 시설 + 효과

| 키 | 이름 | 효과 (Lv.1) | 비용 (build/upgrade) | Max Lv |
|---|---|---|---|---|
| `fortification` | 요새화 | 전투 시 방어 보너스 | 100 / 100 | 5 |
| `market` | 시장 | 일 +10골드/Lv | 150 / 100 | 3 |
| `granary` | 곡창 | 식량 소비 -20%/Lv | 100 / 80 | 3 |
| `training_ground` | 훈련소 | 신규 용병 tier 보장 +1 | 200 / 150 | 3 |
| `temple` | 신전 | 일 +1 명성/Lv | 300 / 200 | 3 |
| `tavern` | 주점 | 일 +2 충성도/Lv (전원) | 120 / 90 | 3 |

## dict 구조 + BUILDING_DEFS 상수

```gdscript
var buildings: Array = []  # 각 원소: {key, name, level, max_level, icon, build_cost_gold, upgrade_cost_gold}

const BUILDING_DEFS := {
    "fortification": { "name": "요새화", "max_level": 5, "build_cost_gold": 100, "upgrade_cost_gold": 100, "icon": "🏰" },
    "market": { "name": "시장", "max_level": 3, "build_cost_gold": 150, "upgrade_cost_gold": 100, "icon": "🏪" },
    # ... 나머지 4종
}
```

`BUILDING_DEFS`는 정적 (변하지 않음) — 게임 밸런스 조정 시 한 곳에서 변경. `buildings[]`는 동적 (플레이 중 추가/업그레이드).

## API 7종

```gdscript
# 조회
func has_building(key: String) -> bool
func get_building(key: String) -> Dictionary
func get_building_level(key: String) -> int
func list_buildable() -> Array       # 아직 안 지은 키
func list_upgradable() -> Array      # 업그레이드 가능한 키

# 변동
func add_building(key: String) -> bool       # false = 자금 부족/이미 존재
func upgrade_building(key: String) -> bool   # false = 자금 부족/최대
```

`add_building` / `upgrade_building`은 **골드 차감**까지 내부에서 처리. 호출자는 bool만 받음.

## 초기 시설 자동 건설

```gdscript
func _spawn_initial_buildings() -> void:
    var fort := _create_building("fortification")
    fort.level = 1
    buildings.append(fort)
    fortification_level = 1  # ← 기존 필드 동기화
    log_event("🏰 요새화 Lv.1 — 영지가 요새화되었습니다")
```

요새화는 시작 시 자동 (Lv.1). fortification_level은 buildings[0]과 동기화 — 일관성 유지.

## 일간 효과 통합

```gdscript
func apply_building_effects() -> void:
    var market_lv: int = get_building_level("market")
    if market_lv > 0:
        modify_resource("gold", market_lv * 10)  # 시장 Lv.2 = +20골드/일

    var granary_lv: int = get_building_level("granary")
    if granary_lv > 0:
        modify_resource("food", granary_lv * 5)

    var temple_lv: int = get_building_level("temple")
    if temple_lv > 0:
        modify_resource("prosperity", temple_lv)

    var tavern_lv: int = get_building_level("tavern")
    if tavern_lv > 0:
        for m in alive_mercenaries():
            m.loyalty = clamp(m.loyalty + tavern_lv * 2, 0, 100)
```

`EventEngine._on_day()`에서 `apply_daily_economy()` 다음에 호출:

```gdscript
func _on_day(day: int) -> void:
    GameWorld.apply_daily_economy()
    GameWorld.apply_weekly_bill()      # ← 일급 지급
    GameWorld.apply_building_effects() # ← 시설 효과
    GameWorld.apply_injury_recovery()
    # ... record_day_snapshot, log_event
```

## 곡창 효과 = 식량 소비 감소 (다른 함정)

`apply_weekly_bill()`이 식량 소비할 때 곡창 Lv 비례 감소:

```gdscript
func apply_weekly_bill() -> void:
    # ... 월급 ...
    var granary_lv: int = get_building_level("granary")
    var reduction: float = 0.2 * granary_lv  # Lv.3 = 60% 감소
    var consume: int = int((alive_mercenaries().size() * 2 + population / 10) * (1.0 - reduction))
    consume = max(1, consume)
    modify_resource("food", -consume)
```

`get_food_consume_reduction()` API로 다른 시스템도 접근 가능 (수치 확인용).

## 결정 결과 코드

`apply_result()`에 6개 신규 결과 핸들러 — Last Banner 1~8차 누적 30+개 핸들러에 추가:

| 결과 코드 | 효과 | 트리거 |
|---|---|---|
| (요새화는 자동 트리거, 결정 없음) | (없음) | fortification_level 변경 시 자동 |
| (시장/곡창 등은 트리거 결정 없음) | | (시설 건설/업그레이드는 UI에서 직접) |

`BUILD_BUILDING` / `UPGRADE_BUILDING` 같은 결정 큐 코드 없음. **시설은 메뉴에서 직접 건설/업그레이드** (결정 큐가 아님). 결정 큐 = 자동 진행에 의한 사건 (약탈자, 식량 위기, 후계자 배신)만. 사용자가 의도적으로 짓는 건물은 결정 큐가 아니라 메뉴 액션.

## UI 패턴 (buildings.tscn)

- 좌측 패널: **건설된 시설** (업그레이드 버튼 포함)
- 우측 패널: **건설 가능** 시설 (건설 버튼)
- 상단: 현재 금고
- 하단: 상태 메시지 ("✓ 시장 건설 완료!" / "✗ 자금 부족")

건설/업그레이드 버튼은 `disabled = true` if `gold < cost`, modulate 회색조. 클릭 시 `_on_build_pressed(key)` → `GameWorld.add_building(key)` → 결과 토스트.

## save/load_state 확장

```gdscript
func save_state() -> Dictionary:
    return {
        # ... 기존 필드 ...
        "buildings": buildings.duplicate(true)
    }

func load_state(data: Dictionary) -> void:
    # ... 기존 필드 ...
    buildings = data.get("buildings", []).duplicate(true)
    if buildings.is_empty() and not _initial_buildings_built:
        _spawn_initial_buildings()  # ← 저장에 시설이 없으면 초기화
```

**중요**: 로드 시 buildings가 비어있으면 자동으로 초기 시설 생성. **세이브 마이그레이션 처리** (이전 버전 세이브 호환).

## LB_VERIFY 검증

```gdscript
var initial: int = GameWorld.buildings.size()
assert(initial == 1, "초기 시설 1개(요새화)")
assert(GameWorld.has_building("fortification"))
assert(GameWorld.get_building_level("fortification") == 1)

GameWorld.add_building("market")
GameWorld.upgrade_building("market")
GameWorld.apply_building_effects()
var gold_after: int = GameWorld.gold
GameWorld.apply_building_effects()
# 시장 Lv.2 → +20골드 효과 확인

# save/load round-trip
SaveManager.save_game("test_buildings")
GameWorld.add_building("temple")
SaveManager.load_game("test_buildings")
assert(not GameWorld.has_building("temple"))  # 저장 안 된 상태
assert(GameWorld.has_building("market"))     # 저장된 상태
```

## 확장 가능성

- **훈련소 효과** (`get_mercenary_tier_bonus()`): 신규 용병 합류 시 `offer_mercenary`에서 `tier` 최소값 보장에 사용. 1~7차에서는 호출 안 됐지만 API 준비됨.
- **요새화 효과 (전투)**: `fortification_level`이 전투 시 `my_power *= fortification_level`로 반영. 7차 전투 시각화에서 자동 적용.
- **신전 효과 (명성 천천히 회복)**: 배신 후 명성 회복에 사용 가능.

## 안 되는 기능 함정 — 토스트 스팸 (LB_VERIFY hang)

`apply_building_effects`가 `EventEngine._on_day`에서 호출될 때마다 `modify_resource` → `resource_changed` 시그널 → main.gd의 `_on_resource_changed` → `_refresh_status()` 전체 호출 → 매 프레임 갱신.

이게 LB_VERIFY hang의 원인이 될 수 있음. `LB_VERIFY`에서 `apply_building_effects` 호출 직후 `TimeManager.advance_minutes()`로 시간 강제 진행하면, 100+ 프레임에 걸쳐 시그널 폭주. **해결**: 검증 모드에서 일별 효과 시뮬은 1회만 호출 + `TimeManager.advance_minutes`는 검증용 시간 누적용으로만 사용.
