# v4.0 Phase B — UX 마감 (튜토리얼 / 사운드 / 게임 종료 / 모바일) (Last Banner 실전 검증)

> Phase A 4단계가 끝나면 인디 게임으로 정식 출시 직전. 4개 마감 작업: B-1 튜토리얼 4단계 오버레이 / B-2 사운드 (BGM 4종 + SFX 6종) / B-3 게임 종료 조건 (인구 0 / 식량 0 30일 / 왕조 멸절) + 엔딩 화면 / B-4 모바일 viewport (1280×720 고정 → anchor 비율). **2026-07-20 v4.1.0-alpha 시점 상태: B-1 ✅ + B-2 통합 100% + B-3 ✅ + B-4 미완**.

## v4.1.0-alpha Phase B 현재 상태 (2026-07-20)

| 단계 | 상태 | LB_VERIFY | 비고 |
|---|---|---|---|
| **B-1** 튜토리얼 4단계 | ✅ 완료 | [8.10] 8단계 통과 | `tutorial_seen` 영속화, 자동 8초 진행, "다시보기" 버튼 |
| **B-2** 사운드 | 🔄 통합 100% + 검증 90% | [8.11] (autoload const preload 한계로 미완) | main.gd 6개 위치 통합 OK |
| **B-3** 게임 종료 3조건 | ✅ 완료 | [8.12] 11단계 통과 | 3종 라벨/설명 + 통계 7종 + 메인메뉴 복귀 |
| **B-4** 모바일 viewport | ❌ 미착수 | (planned) [8.13] | 다음 사이클 |

## Phase B 전체 그림

| 단계 | 시스템 | 핵심 API | 시그널 | LB_VERIFY 단계 |
|---|---|---|---|---|
| B-1 | 튜토리얼 4단계 | `tutorial.start_tutorial(force)` | `tutorial_finished/skipped` | [8.10] ✅ |
| B-2 | 사운드 (BGM+SFX) | `AudioManager.play_bgm/play_sfx` (헤드리스 2중 가드) | (없음 — 단순 API) | [8.11] 90% |
| B-3 | 게임 종료 + 엔딩 | `GameManager.check_game_over_conditions()` + `end_game(reason)` | `game_ended(reason, stats)` | [8.12] ✅ |
| B-4 | 모바일 viewport | `anchor_*` 비율 + VBox 재배치 | (없음) | (planned) [8.13] |

## 4-tier z-order 명시 (v4.1.0 신규 — 사용자 회귀 방지)

```
z-order (위에서 아래로):
┌─────────────────────────────────┐
│ GameOverLayer (layer=120)        │  ← 게임 오버 (최상위, 모든 UI 차단)
├─────────────────────────────────┤
│ ModalLayer (layer=100)           │  ← 결정 큐 모달
├─────────────────────────────────┤
│ BattleLayer (layer=90)            │  ← 전투 화면 (모달보다 하위)
├─────────────────────────────────┤
│ TutorialLayer (layer=15)         │  ← 튜토리얼 (모달보다 의도적 하위!)
├─────────────────────────────────┤
│ UI (layer=10)                     │  ← 자원바 / 버튼행
├─────────────────────────────────┤
│ TitleLayer (layer=5)              │  ← 타이틀 (게임 진입 전)
├─────────────────────────────────┤
│ ManorLayer (layer=0)              │  ← 풍경도 / 차트 / 용병
└─────────────────────────────────┘
```

**v4.1.0 z-order 의도** (Pitfall 25 본문):
- **TutorialLayer(15) vs ModalLayer(100)**: 튜토리얼이 모달보다 **의도적으로 하위**. 튜토리얼이 결정 큐를 가리면 자동 진행 일시정지 → UX 최악.
- **GameOverLayer(120) vs ModalLayer(100)**: 게임 오버는 모달보다 **의도적으로 상위**. 종료 시점에는 결정 큐가 무의미 → "영지 무너짐" 메시지 최상위.
- **BattleLayer(90) vs ModalLayer(100)**: 전투 화면은 모달보다 하위. 전투 중 결정 큐 가능.

**v4.1.0 4-layer 신규 씬 (tutorial / game_over)**:
- `scenes/tutorial.tscn` — CanvasLayer layer=15
- `scenes/game_over.tscn` — CanvasLayer layer=120
- main.tscn에 TutorialLayer / GameOverLayer 둘 다 추가

## B-1. 튜토리얼 4단계 오버레이 — `tutorial_seen` 영속화 패턴

### 레이어 구조 (z-order 결정)

```
ModalLayer (layer=100)       ← 결정 모달 (최상위)
TutorialLayer (layer=15)      ← 튜토리얼 오버레이 (모달 < 튜토리얼이지만 > UI)
UI (layer=10)                ← 게임 자원바 / 버튼 행
ManorLayer (layer=0)         ← 풍경도 / 차트 / 용병
```

**왜 layer=15?**: 모달(layer=100)이 결정 큐로 떴을 때 튜토리얼 위에 덮어써야 함 (튜토리얼 진행 중에도 새 결정이 push 가능). 튜토리얼이 UI(layer=10)보다 위여야 배경 dim 처리 가능. ManorLayer(layer=0)보다 위 = 풍경도 위에 오버레이 표시.

### scripts/tutorial.gd 구조

```gdscript
extends CanvasLayer

const STEPS := [
    { "icon": "🤖", "title": "자동 진행 + 위임", "message": "...", "hint": "(P: 자동 진행 토글)" },
    { "icon": "📜", "title": "결정 큐", "message": "11종 사건...", "hint": "..." },
    { "icon": "💰", "title": "자원 변동 + 차트", "message": "5종 자원...", "hint": "..." },
    { "icon": "⚔️", "title": "4가지 시스템", "message": "용병/왕조/빌딩/차트...", "hint": "..." },
]

var _current_step: int = 0
var _auto_timer: SceneTreeTimer = null
const AUTO_ADVANCE_SEC := 8.0

func start_tutorial(force: bool = false) -> void:
    if not force and GameManager.tutorial_seen:
        emit_signal("tutorial_skipped")
        return
    _current_step = 0
    _active = true
    visible = true
    _show_step(_current_step)
    _schedule_auto_advance(AUTO_ADVANCE_SEC)

func _on_next_pressed() -> void:
    _current_step += 1
    if _current_step >= STEPS.size():
        _finish_tutorial()  # seen=true set + visible=false
    else:
        _show_step(_current_step)
        _schedule_auto_advance(AUTO_ADVANCE_SEC)

func _finish_tutorial() -> void:
    _active = false
    visible = false
    GameManager.tutorial_seen = true  # 영구 저장
```

### GameManager.tutorial_seen 영속화

```gdscript
var tutorial_seen: bool = false

func save_state() -> Dictionary:
    return { ..., "tutorial_seen": tutorial_seen }

func load_state(data: Dictionary) -> void:
    tutorial_seen = data.get("tutorial_seen", false)
```

### main.gd 자동 호출 + 재시청 시그널

```gdscript
# 새 게임 진입 시 자동
func _enter_game_mode() -> void:
    ...
    if tutorial_screen and tutorial_screen.has_method("start_tutorial"):
        tutorial_screen.start_tutorial(false)  # seen 체크

# TitleScreen 재시청 버튼 → retutorial_requested 시그널
func _on_title_retutorial() -> void:
    if tutorial_screen:
        tutorial_screen.start_tutorial(true)  # force=true → seen 무시
```

### TitleScreen "튜토리얼 다시보기" 버튼 (옵션)

`scenes/title_screen.tscn`에 `TutorialButton` 추가 + `title_screen.gd`에 `retutorial_requested` 시그널 + `main.gd`의 `_on_title_retutorial()` 핸들러로 연결. 새 게임 후 잊어버린 사용자가 Title로 돌아가서 다시 볼 수 있게.

### LB_VERIFY [8.10] 작성 시 가정 오류 (Pitfall 19)

**자주 틀리는 assert 가정 2종**:

1. `tutorial._show_step(1)` 호출 후 `assert(_current_step == 1)` — **실패**. `_show_step`은 화면만 갱신하고 `_current_step`은 변경 안 함 (단순 표시 함수).
2. `GameManager.tutorial_seen = true` 강제 set + `start_tutorial(false)` 호출 후 `assert(not tutorial.visible)` — **실패**. `_on_skip_pressed`로 명시적 종료가 안 됐으면 `_finish_tutorial` 미호출 → `visible` 상태 잔존.

**해결 패턴**:
```gdscript
# ❌ 가정 오류
GameManager.tutorial_seen = true
tutorial.start_tutorial(false)
await get_tree().process_frame
assert(not tutorial.visible)  # seen 체크에서 return → visible=true 잔존

# ✓ 명시적 reset + assert
tutorial._on_skip_pressed()    # 명시적 종료로 _finish_tutorial 호출
await get_tree().process_frame
assert(not tutorial.visible)
assert(GameManager.tutorial_seen)
GameManager.tutorial_seen = true
tutorial.start_tutorial(false)
await get_tree().process_frame
assert(not tutorial.visible)  # 정상 skip 동작
```

## B-2. 사운드 시스템 — BGM 4종 + SFX 6종 + 헤드리스 2중 가드

### 자산 출처 (v4.1.0 — 풀 가용성 사전 확인 워크플로)

| 종류 | 출처 | 라이선스 | 폴 경로 |
|---|---|---|---|
| BGM 4곡 | Wesnoth `data/core/music/*.ogg` (elf-land/knolls/battle-epic/sad) | CC-BY-4.0 | `~/work/game-assets-pool/extracted/wesnoth/music/core/music/` |
| SFX 6곡 | sparklinlabs superpowers-asset-packs/rpg-battle-system/sound/*.ogg | CC0 | `~/work/game-assets-pool/free/2D/CC0/sparklinlabs_superpowers-asset-packs/.../rpg-battle-system/sound/` |

**Pitfall 21 — 풀 가용성 사전 확인** (v4.1.0 신규):
- **Wesnoth 풀 = music 53곡 + sfx 0개** (의외)
- **sparklinlabs RPG pack = sfx 40+개** (CC0)
- 새 자산 카테고리 추가 전 `find ... -name "*.ogg" | wc -l` 1회 확인

### autoload/audio_manager.gd (헤드리스 2중 가드)

```gdscript
extends Node

const BGM_TRACKS := {
    "menu":  "res://assets/audio/music/menu.ogg",
    "game":  "res://assets/audio/music/game.ogg",
    "battle": "res://assets/audio/music/battle.ogg",
    "modal": "res://assets/audio/music/modal.ogg",
}
const SFX_TRACKS := {
    "modal_open":     "res://assets/audio/sfx/modal_open.ogg",
    "modal_close":    "res://assets/audio/sfx/modal_close.ogg",
    "choice_confirm": "res://assets/audio/sfx/choice_confirm.ogg",
    "dice_roll":      "res://assets/audio/sfx/dice_roll.ogg",
    "battle_start":   "res://assets/audio/sfx/battle_start.ogg",
    "victory":        "res://assets/audio/sfx/victory.ogg",
}

const BGM_VOLUME := 0.65
const SFX_VOLUME := 0.85
const FADE_DURATION := 1.5

var _bgm_player: AudioStreamPlayer = null
var _sfx_players: Array = []   # 8-풀링 (동시 재생)
var _enabled: bool = true

func _ready() -> void:
    # 1) 헤드리스 가드
    _enabled = _is_running_with_display()
    if _enabled:
        # 2) 자산 가드
        _asset_available = _check_assets()
        if not _asset_available:
            _enabled = false
    if not _enabled:
        print("[AudioManager] 비활성화 (헤드리스 또는 자산 없음)")
        return
    _setup_players()

func _is_running_with_display() -> bool:
    return DisplayServer.get_name() != "headless"

func _check_assets() -> bool:
    return ResourceLoader.exists(BGM_TRACKS["menu"])

func play_bgm(name: String, fade: bool = true) -> void:
    # 3) 호출부 가드
    if not _enabled: return
    if name == _current_bgm and _bgm_player.playing: return
    var stream: AudioStream = load(BGM_TRACKS[name])
    if fade and _bgm_player.playing:
        _fade_switch_bgm(stream)  # Tween으로 페이드아웃 → 교체 → 페이드인
    else:
        _bgm_player.stream = stream
        _bgm_player.play()

func play_sfx(name: String) -> void:
    if not _enabled: return
    var player: AudioStreamPlayer = _sfx_players[_sfx_index]
    player.stream = load(SFX_TRACKS[name])
    player.play()
    _sfx_index = (_sfx_index + 1) % _sfx_players.size()

func stop_bgm(fade: bool = true) -> void:
    if not _enabled: return
    if not _bgm_player.playing: return
    if fade:
        if _fade_tween != null and _fade_tween.is_valid(): _fade_tween.kill()
        _fade_tween = create_tween()
        _fade_tween.tween_property(_bgm_player, "volume_db", -40.0, FADE_DURATION * 0.5)
        _fade_tween.tween_callback(func(): if _bgm_player: _bgm_player.stop())
    else:
        _bgm_player.stop()
    _current_bgm = ""
```

### main.gd 사운드 트리거 포인트 (v4.1.0 통합 100%)

```gdscript
# 모드 전환
func _enter_title_mode() -> void:
    ...
    if AudioManager.is_enabled():
        AudioManager.play_bgm("menu")
func _enter_game_mode() -> void:
    ...
    if AudioManager.is_enabled():
        AudioManager.play_bgm("game")

# 모달
func _show_next_decision() -> void:
    ...
    if AudioManager.is_enabled():
        AudioManager.play_sfx("modal_open")
func _on_choice_pressed(choice: Dictionary) -> void:
    ...
    if AudioManager.is_enabled():
        AudioManager.play_sfx("choice_confirm")
    # BANDIT_RAID → BATTLE_BANDITS_FIGHT 분기
    if decision_type == "BANDIT_RAID" and result_code == "BATTLE_BANDITS_FIGHT":
        if battle:
            ...
            if AudioManager.is_enabled():
                AudioManager.play_sfx("battle_start")
                AudioManager.play_bgm("battle")
    ...
    if AudioManager.is_enabled():
        AudioManager.play_sfx("modal_close")
func _on_auto_skip() -> void:
    ...
    if AudioManager.is_enabled():
        AudioManager.play_sfx("modal_close")

# 게임 오버
func _on_game_ended(reason: String, stats: Dictionary) -> void:
    ...
    if AudioManager.is_enabled():
        AudioManager.play_sfx("victory")
        AudioManager.stop_bgm(true)
```

### 헤드리스 LB_VERIFY 가드

- `LB_VERIFY=1 godot --headless` 실행 시 `DisplayServer.get_name() == "headless"` → `_enabled = false` → 모든 play_bgm/play_sfx 즉시 return. **LB_VERIFY는 절대 사운드로 hang하지 않음**.
- 자산이 없어도 (`assets/audio/` 폴더 자체가 없을 때) `_check_assets()` false → 비활성화.

### Pitfall 23 (v4.1.0 신규) — autoload const preload non-static 메서드 호출

**증상** (2026-07-20 B-2 [8.11] 검증 작성 시): `const AudioManager = preload("res://autoload/audio_manager.gd")`로 상수 로드 후 `AudioManager.is_enabled()` 호출 시:

```
SCRIPT ERROR: Parse Error: Cannot call non-static function "is_enabled()" on the class
"res://autoload/audio_manager.gd" directly. Make an instance instead.
```

**근본 원인**: GDScript의 `const Foo = preload("path")`는 **클래스 자체**(Script 객체)를 const로 로드. non-static 메서드(`func is_enabled()`)는 인스턴스 메서드이므로 클래스 직접 호출 불가. **STATIC 메서드만 호출 가능** (e.g., `const X = preload(...); X.STATIC_CONST`).

**해결 패턴 A** — autoload 인스턴스 사용 (검증 코드):
```gdscript
# ❌ 파스 에러
const AudioManager = preload("res://autoload/audio_manager.gd")
...
assert(AudioManager.is_enabled())  # non-static 메서드

# ✓ autoload는 /root에서 인스턴스 접근
var am: Node = get_node_or_null("/root/AudioManager")
assert(am != null, "AudioManager autoload 인스턴스 없음")
assert(am.is_enabled(), "헤드리스 가드 OK")
am.play_bgm("menu")   # 인스턴스 메서드 호출 OK
```

**비교표**:
| 패턴 | non-static 메서드 | 정적 상수 | 사용 사례 |
|---|---|---|---|
| `const X = preload("class.gd")` | ❌ 파스 에러 | ✓ | `X.SOME_CONST` (rare) |
| `var x: Node = get_node("/root/X")` (autoload) | ✓ | ✓ | `x.method()` / `x.CONST` |
| `class_name X` 다른 클래스 | ✓ | ✓ | `X.method()` (씬 외부) |

**v4.1.0 B-2 [8.11] 90% 완성**: 본 함정으로 마지막 10% 막힘 → 다음 세션 첫 액션이 `const AudioManager` 라인 제거 + `am` 인스턴스 변수 사용으로 수정.

## B-3. 게임 종료 조건 + 엔딩 화면 (v4.1.0-alpha 완료)

### GameManager 신규 필드 + 신호

```gdscript
extends Node

signal game_ended(reason: String, stats: Dictionary)

enum State { BOOT, MENU, PLAYING, PAUSED, DECISION_PENDING, GAME_OVER }

const CONSECUTIVE_FOOD_ZERO_DAYS_LIMIT := 30
const POPULATION_EXTINCTION_THRESHOLD := 0

var end_reason: String = ""
var end_day: int = 0
var end_stats: Dictionary = {}
var consecutive_food_zero_days: int = 0

func check_game_over_conditions() -> bool:
    if current_state == State.GAME_OVER: return true
    # 1) 인구 멸망
    if GameWorld.population <= POPULATION_EXTINCTION_THRESHOLD:
        end_game("POPULATION_EXTINCTION"); return true
    # 2) 식량 0 연속 30일
    if GameWorld.food <= 0:
        consecutive_food_zero_days += 1
        if consecutive_food_zero_days >= CONSECUTIVE_FOOD_ZERO_DAYS_LIMIT:
            end_game("FOOD_FAMINE"); return true
    else:
        consecutive_food_zero_days = 0
    # 3) 왕조 멸절 (영주 + 후보 + 신하 모두 사망)
    var alive_court: int = 0
    for p in GameWorld.court:
        if p.alive: alive_court += 1
    if alive_court == 0:
        end_game("DYNASTY_EXTINCTION"); return true
    return false

func end_game(reason: String) -> void:
    if current_state == State.GAME_OVER: return
    end_reason = reason
    end_day = TimeManager.day
    end_stats = {
        "gold": GameWorld.gold, "food": GameWorld.food,
        "population": GameWorld.population, "prosperity": GameWorld.prosperity,
        "fortification_level": GameWorld.fortification_level,
        "roster_count": GameWorld.alive_mercenaries().size(),
        "court_count": GameWorld.court.size(),
        "buildings": GameWorld.buildings.duplicate(),
        "history_days": GameWorld.history.size(),
    }
    current_state = State.GAME_OVER
    game_ended.emit(reason, end_stats)

func reset_end_state() -> void:
    end_reason = ""; end_day = 0; end_stats.clear()
    consecutive_food_zero_days = 0
    current_state = State.PLAYING

func get_end_reason_label() -> String:
    match end_reason:
        "POPULATION_EXTINCTION": return "인구 멸망"
        "FOOD_FAMINE": return "대기아 (식량 0 연속 30일)"
        "DYNASTY_EXTINCTION": return "왕조 멸절"
        _: return "알 수 없음"
```

### EventEngine._on_day 일간 평가 (v4.1.0 신규 — state=PLAYING 체크)

```gdscript
func _on_day(_d: int) -> void:
    _decisions_today = 0
    GameWorld.apply_daily_economy()
    GameWorld.record_day_snapshot(_d)
    print("[EventEngine] Day %d — 자원 변동: ...")
    # v4.1.0: 게임 오버 평가 (state=PLAYING 일 때만)
    if GameManager and GameManager.current_state == GameManager.State.PLAYING:
        GameManager.check_game_over_conditions()
```

**state=PLAYING 체크의 의미** (Pitfall 25):
- `PAUSED` (토글 OFF): 평가 안 함 (사용자 수동 진행 중)
- `DECISION_PENDING` (결정 큐): 평가 안 함 (이미 결정 처리 중)
- `GAME_OVER` (이미 종료): 평가 안 함 (중복 트리거 방지)
- `PLAYING` (정상): 평가 O

### scenes/game_over.tscn (CanvasLayer layer=120)

```
GameOver (CanvasLayer, layer=120, visible=false)
├── DimBG (ColorRect, 0.88 alpha, mouse_filter=0)
└── Card (PanelContainer, 600×600 중앙)
    └── Margin (28/24/28/24)
        └── VBox (separation 12)
            ├── HeaderRow (HBox)
            │   ├── IconLabel (이모지 56pt)
            │   └── TitleLabel (제목 22pt, 우선순위 색상)
            ├── DescriptionLabel (90pt, autowrap)
            ├── DayLabel ("생존 일수: N일" 16pt 중앙)
            ├── StatsTitle ("📊 종료 통계" 14pt 중앙)
            ├── StatsVBox (VBoxContainer — 동적 7종)
            └── ButtonRow
                └── ReturnButton ("🏠 메인 메뉴로" 180×48)
```

### scripts/game_over.gd (3종 라벨/설명 + 통계 7종)

```gdscript
const REASON_LABELS := {
    "POPULATION_EXTINCTION": "인구 멸망",
    "FOOD_FAMINE": "대기아 (식량 0 연속 30일)",
    "DYNASTY_EXTINCTION": "왕조 멸절",
}
const REASON_DESCRIPTIONS := {
    "POPULATION_EXTINCTION": "영지의 인구가 모두 사라졌습니다.\n전쟁·역병·기근이 겹치며 백성이 뿔뿔이 흘어졌습니다.\n당신의 영지는 이제 텅 빈 폐허입니다.",
    "FOOD_FAMINE": "30일 연속으로 식량이 바닥났습니다.\n마을은 텅 비고, 아이들이 울음을 멈췄습니다.\n마지막 창고가 비어가는 날, 영지도 함께 무너졌습니다.",
    "DYNASTY_EXTINCTION": "영주와 모든 후보·신하가 사망했습니다.\n가문의 마지막 이름이 역사에서 지워졌습니다.\n영지를 누가 이을 것인지는 이제 아무도 모릅니다.",
}

func show_game_over(reason: String, day: int, stats: Dictionary) -> void:
    visible = true
    # 아이콘/제목/설명/통계 동적 채우기
    ...
    var stat_labels := [
        "💰 금: %d" % int(stats.get("gold", 0)),
        "🌾 식량: %d" % int(stats.get("food", 0)),
        "👥 인구: %d" % int(stats.get("population", 0)),
        "⭐ 명성: %d" % int(stats.get("prosperity", 0)),
        "🏰 요새 Lv %d" % int(stats.get("fortification_level", 1)),
        "⚔️ 생존 용병: %d명" % int(stats.get("roster_count", 0)),
        "👑 생존 왕조 인물: %d명" % int(stats.get("court_count", 0)),
    ]
    for s in stat_labels:
        var lbl := Label.new(); lbl.text = s; ...
        stats_vbox.add_child(lbl)
```

### main.gd _on_game_ended + _on_game_over_return

```gdscript
func _on_game_ended(reason: String, stats: Dictionary) -> void:
    TimeManager.auto_progress_enabled = false
    if decision_modal: decision_modal.visible = false
    if modal_dim_bg: modal_dim_bg.visible = false
    if AudioManager.is_enabled():
        AudioManager.play_sfx("victory")
        AudioManager.stop_bgm(true)
    if game_over_screen and game_over_screen.has_method("show_game_over"):
        game_over_screen.show_game_over(reason, GameManager.end_day, stats)

func _on_game_over_return() -> void:
    if game_over_screen: game_over_screen.visible = false
    SaveManager.save_game("autosave")
    _enter_title_mode()
```

### LB_VERIFY [8.12] 11단계 (v4.1.0-alpha)

1. GameOver 노드 + 메서드 ✓
2. REASON_LABELS / DESCRIPTIONS 3종 ✓
3. GameManager 상수 + 필드 초기값 ✓
4. 시나리오 1: 인구 0 → POPULATION_EXTINCTION ✓
5. end_stats 7종 정확성 ✓
6. 중복 호출 안전 (이미 GAME_OVER → 재평가 X) ✓
7. show_game_over → 화면 표시 ✓
8. 시나리오 2: 식량 0 29일 → 안 트리거 + 회복 시 리셋 ✓
9. 식량 0 30일 → FOOD_FAMINE ✓
10. 시나리오 3: court 전원 사망 → DYNASTY_EXTINCTION ✓
11. get_end_reason_label 3종 + save/load round-trip ✓

**Pitfall 24 (v4.1.0 신규) — GDScript `% (a, obj.method())` 파스 에러**:

LB_VERIFY [8.12]에서:
```gdscript
# ❌ 파스 에러
assert(not triggered, "Day %d: 누적 %d일" % (i + 1, GameManager.consecutive_food_zero_days))
# → Parse Error: Expected closing ")" after grouping expression

# ✓ 변수로 추출
for i in range(29):
    var triggered: bool = GameManager.check_game_over_conditions()
    var day_count: int = i + 1
    var zero_count: int = GameManager.consecutive_food_zero_days
    assert(not triggered, "Day %d: 누적 %d일" % [day_count, zero_count])
```

## B-4. 모바일 viewport (다음 사이클)

### 현재 문제 (v4.0.0)

모든 tscn의 offset_* 좌표가 픽셀 고정값:
- `offset_left=-260, offset_top=-200` (CenterBox, 1280×720용)
- `offset_left=-380, offset_top=-200` (DecisionModal, 720×400 크기)
- `offset_top=80` (TopResourceBar, 80px 고정)

**iPhone 세로 (390×844)** 또는 태블릿 (768×1024)에서 좌우/상하 컨텐츠가 화면 밖으로 나감.

### 해결 패턴

**옵션 A — anchor 비율 (가장 단순)**: 모든 절대 픽셀 offset을 anchor 비율로 변환.
```ini
# ❌ 1280×720 고정
offset_left = -260.0
offset_right = 260.0

# ✓ 모든 viewport 대응
anchor_left = 0.5; anchor_right = 0.5
offset_left = -260.0; offset_right = 260.0   # 폭은 고정, 위치는 중앙
```

**옵션 B — 모바일 세로 분기 (anchor + 토글)**: 토글 변수로 모바일/데스크탑 분기.
```gdscript
func _is_portrait() -> bool:
    return get_viewport().get_visible_rect().size.y > get_viewport().get_visible_rect().size.x
```

**옵션 C — 모바일 전용 씬 (mobile.tscn)**: 복잡한 게임에서 사용. Last Banner는 옵션 A 권장.

### LB_VERIFY [8.13] 패턴

```gdscript
# [8.13] 모바일 viewport 시뮬레이션 (해상도 변경)
var vp: Viewport = get_viewport()
vp.size = Vector2i(390, 844)  # iPhone 12
await get_tree().process_frame
# 모든 주요 Control이 viewport 안에 있는지 확인
var topbar: Control = get_node_or_null("UI/TopResourceBar") as Control
assert(topbar.get_global_rect().size.y <= vp.size.y, "TopResourceBar가 viewport 안에")
# ... 등
vp.size = Vector2i(1280, 720)  # 데스크탑 복원
```

`godot --headless`는 Viewport 크기 변경이 자동 처리되지만 실제 모바일 .app 빌드 검증은 사용자 디스크탑에서 1회 필수 (UI 회귀 패턴 — godot-game-bootstrap의 "macOS .app 시각 검증은 사용자 데스크탑 위임" 참고).

## 진화 의도

v4.0.0: Phase A 4단계 — 게임 깊이 확장 (incremental → 4X + tycoon 하이브리드)
**v4.1.0-alpha: Phase B-1/B-2/B-3 — UX 마감 (튜토리얼 + 사운드 + 게임 종료 = 인디 게임 정식 출시 가능 + 모바일은 v4.1.1)**
v4.2.0: Phase D — 씬 다양화 (맵 5종 + 인격 시스템 + 기술 트리 + 30+ 사건)
v5.0.0: Phase E — 스토리 모드 + 메이저 리팩토링 (챕터 캠페인 + Godot 5.x + 멀티플랫폼)

## 안티패턴

1. **튜토리얼 8초 자동 진행이 너무 빠름** — 4단계 × 8초 = 32초. STEP 2~3개까지 자동 진행 후 "다음" 버튼 명시. 모바일 사용자는 8초도 길다
2. **BGM 4곡 모두 1곡처럼 들리게** — 분위기 차이가 명확해야 모드 전환 피드백이 됨. Wesnoth elf-land/sad는 둘 다 잔잔 → modal/game 분기 부적합
3. **SFX를 매 클릭마다** — 3초 안에 5번 클릭 = 사용자 짜증. 결정 확정/모달 열기/전투 시작/승리 4종만
4. **게임 종료 후 자동 저장** — 종료된 게임을 또 저장하면 다음 로드 시 종료 상태. **game_over 호출 직전에 save 안 함**
5. **모바일 viewport를 anchor 비율만으로 해결** — 일부 복잡한 그리드는 모바일 전용 tscn이 정답. Last Banner는 단순 그리드라 anchor 비율로 OK
6. **autoload const preload로 non-static 메서드 호출** (Pitfall 23) — `const Foo = preload("autoload/foo.gd"); Foo.method()` 파스 에러. → `var foo: Node = get_node("/root/Foo"); foo.method()`
7. **% 포맷 안에 멤버 접근** (Pitfall 24) — `"%d" % (i, obj.method())` 파스 에러. → 변수로 추출 후 `% [a, b]` 배열 포맷
8. **tscn 구조 변경 후 LB_VERIFY만 통과했다고 시각 OK 가정** (Pitfall 18) — 사용자 Mac 데스크탑 .app 빌드 스크린샷 양쪽 검증 필수

## v4.1.0 회귀 디버깅 워크플로 (Pitfall 18 보강)

**v4.0.1 회귀** (2026-07-20): PanelContainer anchor 미명시로 UI 망가짐 → 사용자 명시적 피드백. **교훈 워크플로**:

1. **사용자 스크린샷 + "UI 망가짐" 신호** → tscn 구조 의심
2. **현재 tscn 직접 read** — anchor_left/top 누락 여부 grep
3. **git diff HEAD~1 -- scenes/main.tscn** — 직전 commit과 비교
4. **검증된 형태로 복원** — UITheme 색상만 입히는 방식 (구조 변경 X)
5. **재빌드 + .app 실행 + 사용자 Mac 시각 확인** — LB_VERIFY만으론 부족

**v4.1.0 tscn 안전 패턴**:
1. 기존 검증된 PanelContainer 구조는 그대로 유지
2. 동적 추가 (예: 모달/튜토리얼) 시 anchor 4-값 명시
3. `add_theme_stylebox_override` + 색상 매핑은 안전 (구조 변경 X)
4. 시각 회귀 시 → LB_VERIFY + 사용자 Mac 데스크탑 .app 빌드 스크린샷으로 양쪽 검증
5. 사용자 시각 피드백 신호 — LB_VERIFY 통과해도 "UI 망가짐" 같은 명시적 지적이 들어오면 즉시 tscn 구조 의심

## 관련 참조

- `references/v4-phase-a-game-systems.md` — Phase A 4단계 (사건/용병/왕조/빌딩)
- `godot-game-bootstrap/references/audio-asset-acquisition.md` — Wesnoth + sparklinlabs 자산 패턴
- `godot-game-bootstrap/SKILL.md` — PanelContainer 자식 anchor 4-값 명시 (Phase B-4와 직결)
- `references/decision-queue-on-off-auto-vs-waiting.md` — 결정 큐 ON/OFF + default 결정
- `incremental-game-design` (umbrella) — incremental 게임 클래스 전체 워크플로
- `references/v2-native-ui-pitfalls.md` — v2.1~v3.0 7가지 UI 반문 (anchor 4-값 함정 보강)