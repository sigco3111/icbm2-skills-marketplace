---
name: incremental-game-design-last-banner-event-engine
description: Last Banner 실전에서 검증된 GameWorld + EventEngine + DecisionQueue 자동 진행 패턴 — TimeManager의 tick_advanced/day_changed 시그널 → EventEngine의 매 N시간 사건 생성기 → DecisionQueue.push (LOW/MEDIUM/HIGH/CRITICAL) → GameManager.pause_for_decision() 연결. 영지 자원 (gold/food/population/prosperity/fortification), 용병 roster (Tier 1~3, 9개 클래스), 일간 변동 (세금/수확/월급/식량소비), 자동 저장 (60분 주기), **v3.0 결정 큐 → 별도 씬 라우팅 (type+result code 조합, GameWorld.apply_result 단일 dict 통합, race-free await)**, 전투 화면 (3상태 머신), 시간대 그라디언트, 라운드트립. **모든 v2/v3 실전 패턴 + 헤드리스 검증 + UI 가시성 함정**.
version: 0.5.0
author: icbm2
metadata:
  hermes:
    tags: [Game, Godot, EventEngine, DecisionQueue, Auto-progression, BattleScene, ApplyResult]
trigger: "Last Banner처럼 GameWorld (영지/용병/자원 데이터) + EventEngine (매 N시간 사건 생성기) + DecisionQueue (우선순위 큐) + GameManager (상태머신) 구조로 자동 진행 게임을 만들 때. 트리거: 'incremental game with EventEngine', 'last banner event engine', 'tick-driven event generator', 'priority decision queue pattern', 'Godot auto progress game', 'battle scene Godot', 'Wesnoth 2D idle PNG'. **v3.0 신규**: 결정 큐 → 별도 씬 라우팅 + GameWorld.apply_result 통합 + CanvasLayer 4-tier z-order invariant + race-free await. **v3.1 보강**: 7일 ring buffer `history` (Control._draw 라인 차트) + HUD 패널 z-order 충돌 회피 (HBox 분리, 차트 안에 텍스트 X, tscn `replace_all=true` 금지 + anchor 4개 명시). Godot 4 Control/UI/Tween에 막힐 때 `godot-control-input-quirks` + `godot4-ui-panel-overlap-and-tscn-patch-safety.md` 참조."
last_updated: 2026-07-16 (v0.5.0 — v3.0 결정 큐→Scene 라우팅 + GameWorld.apply_result 단일 dict 통합 + CanvasLayer 4-tier 패턴 추가; references/v2-native-ui-pitfalls.md 통합으로 v3 BattleScene/ModalLayer/BottomRow 패턴 참조)
status: live-verified
---

# Last Banner Event Engine Pattern (실전 검증)

> **Last Banner**는 2026-07-15 1차 빌드에서 헤드리스 검증까지 통과한 패턴. 자동 진행이 실제로 자원 변동 + 사건 생성 + 결정 큐 push + 저장/로드 round-trip을 모두 수행하는 걸 확인. 7차까지 검증.

## 핵심 연결 고리

```
TimeManager (autoload, _process)
   │
   ├─ tick_advanced.emit(game_time)
   │     ├─► SaveManager._on_tick   → maybe_auto_save (60분)
   │     └─► EventEngine._on_tick    → 4h/8h/10h/12h 주기 사건
   │
   └─ day_changed.emit(day)
         └─► EventEngine._on_day     → 일간 자원 변동 (apply_daily_economy + apply_weekly_bill)
                                      → apply_injury_recovery
                                      → 농민 호소
```

**3가지 핵심 시그널을 모두 활용** — `tick_advanced`(자원/사건), `day_changed`(일간 변동), `season_changed`(계절별 특별 이벤트).

## GameWorld — 데이터 모델 (영지/용병/자원)

### 자원 5필드

```gdscript
var gold: int = 200                # 금고
var food: int = 100                # 식량
var population: int = 50           # 인구
var prosperity: int = 10           # 명성 0~100
var fortification_level: int = 1   # 요새 Lv 1~5
var lord_name: String = ""         # 자동 생성 (영주 이름)
```

### 용병 Roster — Tier + Class 시스템

```gdscript
const MERCENARY_CLASSES := {
    "bowman":    { "tier": 1, "base_wage": 5,  "labels": ["궁수", "궁병"] },
    "swordsman": { "tier": 1, "base_wage": 4,  "labels": ["검사", "병사"] },
    "pikeman":   { "tier": 1, "base_wage": 5,  "labels": ["창병", "척후"] },
    "sergeant":  { "tier": 2, "base_wage": 12, "labels": ["하사관"] },
    "fencer":    { "tier": 2, "base_wage": 10, "labels": ["페렌스", "결투자"] },
    "crossbow":  { "tier": 2, "base_wage": 11, "labels":["석궁병"] },
    "cavalry":   { "tier": 2, "base_wage": 15, "labels": ["기병"] },
    "captain":   { "tier": 3, "base_wage": 30, "labels": ["선봉장", "대장"] },
    "paladin":   { "tier": 3, "base_wage": 35, "labels": ["성기사"] },
}
```

각 용병은 dict로 저장:
```gdscript
{
  "id": int,
  "name": String (자동 생성),
  "class": String,
  "class_label": String,
  "tier": int,
  "experience": int,
  "loyalty": int (0~100, 30 미만 이탈 위험),
  "wage_demand": int,
  "injured_days": int,
  "alive": bool
}
```

### 일간 변동 패턴

```gdscript
func apply_daily_economy() -> void:
    # 세수: 명성 + 인구 비례
    var tax: int = max(5, prosperity + population / 4)
    modify_resource("gold", tax)
    # 식량 회복: 인구 1/4
    var harvest: int = max(2, population / 4)
    modify_resource("food", harvest)

func apply_weekly_bill() -> void:
    # 매일 적용 (월급 = 일급 합산)
    var total_wage: int = 0
    for m in roster:
        if m.alive: total_wage += m.wage_demand
    if total_wage > 0:
        modify_resource("gold", -total_wage)
    # 식량 소비
    var consumed: int = alive_mercenaries().size() * 2 + population / 10
    modify_resource("food", -consumed)
```

**함정**: 메서드 이름이 `apply_weekly_bill`이지만 실제로는 매일 호출. 이름보다 호출 빈도가 중요. 이름 변경 시 grep + 모든 caller 업데이트.

## EventEngine — 매 tick 사건 생성기

### 주기 정의 (분 단위)

```gdscript
const RECRUIT_OFFER_INTERVAL_MIN := 240      # 4시간마다 용병 자원
const FOOD_CRISIS_CHECK_INTERVAL_MIN := 720  # 12시간마다 식량 체크
const BANDIT_RAID_INTERVAL_MIN := 480        # 8시간마다 약탈자
const DIPLOMACY_INTERVAL_MIN := 600          # 10시간마다 외교
const SUCCESSION_AUDIT_INTERVAL_MIN := 4320  # 3일마다 후계자 감사 (CK3 양식)
const DECISION_MAX_PER_DAY := 3              # 하루 최대 3건 (사용자 부담 줄임)
```

### 시그널 연결

```gdscript
func _ready() -> void:
    TimeManager.tick_advanced.connect(_on_tick)
    TimeManager.day_changed.connect(_on_day)
    TimeManager.season_changed.connect(_on_season)
```

### 사건 생성 패턴 (각각 독립 함수)

```gdscript
func _maybe_offer_mercenary(_game_time: int) -> void:
    if _decisions_today >= DECISION_MAX_PER_DAY: return
    if GameWorld.alive_mercenaries().size() >= 12: return  # 만원
    if randf() > 0.6: return  # 60% 확률
    var m: Dictionary = GameWorld.offer_mercenary(Time.get_ticks_msec())
    DecisionQueue.push("MERCENARY_OFFER", {
        "title": "용병 자원 도착",
        "description": "...",
        "mercenary": m,
        "choices": [
            { "id": "accept", "label": "수용", "result": "ACCEPT_MERCENARY" },
            { "id": "reject", "label": "거절", "result": "REJECT_MERCENARY" }
        ]
    }, DecisionQueue.Priority.LOW)
    _decisions_today += 1
```

**핵심 패턴 5가지**:
1. **daily cap 체크** (`_decisions_today < MAX`) — 하루에 너무 많은 결정 안 받게
2. **확률 게이트** (`randf() > X`) — 모든 사건이 매번 발화하지 않게
3. **사건별 precondition** (만원/식량 충분/명성 높음 등) — 게임 상태에 따라 발화 여부
4. **payload에 choices 동봉** — UI가 어떤 선택지를 줄지 결정
5. **priority 큐 push** — LOW/MEDIUM/HIGH/CRITICAL

### 사건 타입 (Last Banner 1~8차 누적)

| 타입 | 우선순위 | 트리거 |
|---|---|---|
| `MERCENARY_OFFER` | LOW | 4h마다 60%, 만원 시 skip |
| `BANDIT_RAID` | HIGH | 8h마다 40%, 명성 >70이면 skip |
| `DIPLOMACY_REQUEST` | MEDIUM | 10h마다 30% |
| `FOOD_LOW` | MEDIUM | 12h마다 food < 30 |
| `FOOD_CRISIS` | CRITICAL | 12h마다 food < 10 → 자동 정지 |
| `PEASANT_PETITION` | LOW | 매일 25% |
| `WINTER_PREPARATION` | MEDIUM | 계절 → 겨울 진입 시 |
| `SUCCESSION_AUDIT` | MEDIUM | 3일마다, 분기 후계자 점검 |
| `HEIR_BETRAYAL` | CRITICAL | loyalty<25 && ambition>65 → 자동 정지 |

**CRITICAL 발화 시 자동 정지**: `DecisionQueue.push()` 내부에서 `if priority == Priority.CRITICAL: GameManager.pause_for_decision()`. 사용자가 결정할 때까지 자동 진행 멈춤.

## SaveManager — 자동 저장 + Round-trip

### tick_advanced 구독으로 자동 저장

```gdscript
func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    TimeManager.tick_advanced.connect(_on_tick)

func _on_tick(_game_time: int) -> void:
    maybe_auto_save()

func maybe_auto_save() -> void:
    if not auto_save_enabled: return
    var now := TimeManager.minutes_elapsed
    if now - _last_auto_save_min >= AUTO_SAVE_INTERVAL_MIN:  # 60분
        if save_game("autosave"):
            _last_auto_save_min = now
```

### Round-trip 직렬화 (GameManager + TimeManager + GameWorld + DecisionQueue)

```gdscript
func _capture_state() -> Dictionary:
    return {
        "version": SAVE_VERSION,
        "created_at": Time.get_unix_time_from_system(),
        "game": GameManager.save_state(),
        "time": TimeManager.save_state(),
        "world": GameWorld.save_state(),    # ← GameWorld 추가
        "decisions": DecisionQueue.save_state()
    }

func _apply_state(data: Dictionary) -> void:
    if data.has("game"): GameManager.load_state(data["game"])
    if data.has("time"): TimeManager.load_state(data["time"])
    if data.has("world"): GameWorld.load_state(data["world"])
    if data.has("decisions"): DecisionQueue.load_state(data["decisions"])
    _last_auto_save_min = TimeManager.minutes_elapsed  # 중복 저장 방지
```

**각 autoload마다 `save_state() -> Dictionary` + `load_state(data: Dictionary)` 메서드 1쌍 추가가 표준**.

## 헤드리스 검증 패턴 — `LB_VERIFY=1` 환경변수

**함정**: Godot에서 `godot --headless --script res://verify.gd`로 SceneTree를 직접 실행하면 **autoload가 등록되지 않음** (메인 씬을 거치지 않기 때문).

**해결**: main.gd에 검증 모드 내장.

```gdscript
const LB_VERIFY := "LB_VERIFY"  # 환경변수명

func _ready() -> void:
    _verify_mode = OS.has_environment(LB_VERIFY)
    if _verify_mode:
        _run_verify()
        return
    # ... 일반 부팅 로직

func _run_verify() -> void:
    print("=== Last Banner 자동 진행 검증 시작 ===")
    await get_tree().process_frame
    await get_tree().process_frame

    # 1) 새 게임
    GameManager.start_new_game("default")
    await get_tree().process_frame
    print("[1] 새 게임: %s" % GameWorld.summary())
    assert(GameWorld.gold == 200)
    assert(GameWorld.food == 100)
    assert(GameWorld.roster.size() == 3)
    print("  ✓ 초기 상태 OK")

    # 2) 시간 강제 진행 — 24시간 (1440분)
    print("[2] 시간 진행 시작 (24시간 = 1440분)")
    var initial_decisions: int = DecisionQueue.get_all_pending().size()
    var gold_start: int = GameWorld.gold
    var food_start: int = GameWorld.food
    for step in range(144):
        TimeManager.advance_minutes(10)
        await get_tree().process_frame

    var final_decisions: int = DecisionQueue.get_all_pending().size()
    print("[3] 진행 후: %s" % GameWorld.summary())
    print("[4] 결정 큐: %d → %d" % [initial_decisions, final_decisions])
    if final_decisions > initial_decisions:
        print("[PASS] 자동 진행 중 사건 생성 확인 ✓")
        for d in DecisionQueue.get_all_pending():
            var pname: String = DecisionQueue.Priority.keys()[d.priority]
            print("  - [%s] %s — %s" % [pname, d.type, d.payload.get("title", "")])
    else:
        # 디버그: 수동 호출
        print("[FAIL] 결정 큐에 사건 push 안 됨 → 수동 호출")
        EventEngine._maybe_offer_mercenary(Time.get_ticks_msec())
        EventEngine._maybe_bandit_raid(Time.get_ticks_msec() + 1)
        EventEngine._maybe_diplomacy_request(Time.get_ticks_msec() + 2)
        await get_tree().process_frame

    # 3) 자원 변동 확인
    print("[5] 자원 변동 (24시간): 금 %d→%d, 식량 %d→%d" % [gold_start, GameWorld.gold, food_start, GameWorld.food])

    # 4) 저장/로드 round-trip
    print("[6] 저장/로드 round-trip")
    var gold_before: int = GameWorld.gold
    var roster_size_before: int = GameWorld.roster.size()
    assert(SaveManager.save_game("test"))
    GameWorld.gold = 0
    GameWorld.population = 0
    GameWorld.roster.clear()
    assert(SaveManager.load_game("test"))
    assert(GameWorld.gold == gold_before)
    assert(GameWorld.roster.size() == roster_size_before)
    print("  ✓ Round-trip 정합성 OK")

    print("=== 모든 검증 통과 — 종료 ===")
    get_tree().quit()
```

**검증 실행**: `cd ~/work/last-banner && LB_VERIFY=1 godot --headless`

**검증 출력 예**:
```
[GameWorld] 새 게임 초기화: 영주=토르바르 오크슬레이어, 금=200, 식량=100, 용병=3명
[EventEngine] Day 2 — 자원 변동: 금 209, 식량 101, 인구 50
[4] 결정 큐: 0 → 3건
  - [MEDIUM] DIPLOMACY_REQUEST — 이웃 영주의 제안
  - [LOW] MERCENARY_OFFER — 용병 자원 도착
  - [LOW] MERCENARY_OFFER — 용병 자원 도착
[5] 자원 변동 (24시간): 금 200→209, 식량 100→101
[6] 저장/로드 round-trip
  ✓ Round-trip 정합성 OK
```

### LB_VERIFY 단계 7종 (종합, 2026-07-16)

| 단계 | 검증 항목 | 핵심 assert |
|------|----------|------------|
| 1 | 새 게임 | gold=200, food=100, roster=3 |
| 1.5 | 자동 진행 ON | `TimeManager.auto_progress_enabled == true` |
| 1.6 | 자동 진행 시뮬 | `advance_minutes(N)` 후 `sim_min > 0` |
| 1.7 | 튜토리얼 | 4단계 순회 후 `tutorial_seen=true`, 두 번째 호출 시 안 뜸 |
| 2 | 24시간 시뮬 | 결정 큐 0→N (LOW 자동 push) |
| 4.5 | 다이얼로그 | HIGH/CRITICAL push → visible=true |
| 4.6 | 명단 화면 | 동적 행 갱신 (용병 추가/사망) |
| 4.7 | 대시보드 | history ≥ 1, unlock_achievement, 차트 queue_redraw |
| 4.8 | 왕조 | 인물 5명, 후계자 3명 |
| 4.9 | 전투 시각화 | show_battle → 그리드 채움, 출격 → 시뮬레이션 |
| 6 | round-trip | save → 망가뜨리기 → load → 정합성 |
| 7 | 화면 인스턴스 자식 검증 | ManorDashboard 자식 Sprite ≥ 4, Roster row ≥ 4 (Last Banner v2 2026-07-16) — 헤드리스에서 부착/생성 확인. 시각 검증은 사용자 데스크탑 의존. |
| 8.5 | 외교 시나리오 push (DIPLOMACY) | `_maybe_diplomacy()` 강제 호출 → DIPLOMACY ≥ 1건 큐에 들어감 |
| 8.6 | 결정 큐 우선순위 분포 | 7일 시뮬 후 `{LOW: N, MEDIUM: M, HIGH: K}` 다양성 확인 (한 종류만 30+건 쌓이면 UX 답변 부족) |

### 결정 큐 자동 진행 ON/OFF 분기 — 핵심 UX 패턴 (Last Banner v2.1.0, 2026-07-16, 헤르린님 직접 선택)

**v2.0.0의 한계**: v2.0.0는 "모든 우선순위 모달 + LOW 3초 자동 skip"이었음. → 모달은 뜨지만 자동 진행 OFF에서도 3초 후 자동 닫힘 → **사용자가 모르는 사이 결정이 계속 진행됨**. 위임과 대기가 혼재해서 답답.

**v2.1.0 (v2 패턴 확정)**: **사용자의 자동 진행 토글이 모달 동작을 완전히 결정**.
- **자동 진행 ON**: ① 모든 우선순위 모달 ② LOW 3초 / 그 외 5초 후 default 결정 자동 resolve
- **자동 진행 OFF**: ① 모든 우선순위 모달 ② **타이머 설정 안 함 → 사용자 결정까지 무한 대기**

**핵심 코드 패턴** (`main.gd._show_next_decision`):
```gdscript
func _show_next_decision() -> void:
    for d in DecisionQueue.get_all_pending():
        if d.id > _current_decision_id:
            _current_decision_id = d.id
            _populate_modal(d)
            if modal_dim_bg: modal_dim_bg.visible = true
            decision_modal.visible = true
            # v2.1.0 핵심: 타이머는 자동 진행 ON일 때만 걸기
            if TimeManager.auto_progress_enabled:
                var delay := 3.0 if d.priority == DecisionQueue.Priority.LOW else 5.0
                _auto_skip_timer = get_tree().create_timer(delay)
                _auto_skip_timer.timeout.connect(_on_auto_skip)
            return
```

**`_on_auto_skip`의 1차 가드** — 외부 호출 또는 race condition 안전:
```gdscript
func _on_auto_skip() -> void:
    if not TimeManager.auto_progress_enabled:
        return  # OFF면 즉시 종료 — 타이머 콜백이 아니다 수동 호출이어도 안전
    if _current_decision_id < 0 or not decision_modal or not decision_modal.visible:
        return
    var default_choice := _default_low_choice()
    if default_choice != "":
        _apply_result(default_choice)
    DecisionQueue.resolve(_current_decision_id, {"id": "auto_skip", "label": "(자동 결정)"})
    _current_decision_id = -1
    if decision_modal: decision_modal.visible = false
    if modal_dim_bg: modal_dim_bg.visible = false
    GameManager.resume_from_decision()
```

**default 결정 코드** (자동 ON일 때 자동 처리):
| type | condition | default | effect |
|---|---|---|---|
| `VISITOR` | always | `VISITOR_REJECT` | 명성 -2 |
| `FOOD_SHORTAGE` | food < 15 | `FOOD_BUY` | 골드 -50, 식량 +30 |
| `FOOD_SHORTAGE` | food ≥ 15 | `FOOD_RATION` | 명성 -5 |
| `DIPLOMACY` | always | `DIPLOMACY_REFUSE` | 명성 -5 |
| (other) | - | "" (빈 문자열) | 자동 거절 안 함 → 무한 대기 (안전 가드) |

**사용자 클릭 시** (`_on_choice_pressed`): 자동 진행 상태 무관 — 항상 즉시 모달 닫힘 + 결과 적용. 3초 타이머 콜백이 그 사이에 호출되어도 `_current_decision_id < 0` 가드로 자동 결정 안 함.

**주된 해석 — "Godot 자동 진행 게임의 3모드 UX"**:
| 상태 | 자동 진행 | 모달 동작 | default 결정 |
|---|---|---|---|
| **위임 (ON)** | 시계 자동 진행 | 모든 모달 + 자동 결정 (LOW 3초 / 그 외 5초) | 자동 ON |
| **대기 (OFF)** | 사용자가 +1일 진행 또는 결정 | 모든 모달 + **무한 대기** | 사용자가 직접 |

→ 자동 진행 = **상호 배타적 (XOR) 모드**로 작동. 같은 결정 큐 자원이 두 모드에서 다른 동작. 자동 진행 OFF는 의도적으로 게임을 정지시켜 사용자의 개입을 요구하는 모드.

**LB_VERIFY 검증 단계 [10] [11]** (반드시 둘 다 검증):
```gdscript
# [10] OFF 무한 대기
TimeManager.auto_progress_enabled = false
EventEngine._maybe_visitor(...)   # 새 결정 push
await get_tree().process_frame
_check_decision_queue()
assert(decision_modal.visible, "OFF에서 모달 떠있어야")
_on_auto_skip()                  # OFF 가드 — 모달 그대로 유지
assert(decision_modal.visible, "OFF에서 _on_auto_skip 호출되어도 모달 유지")

# [11] ON 자동 닫힘
TimeManager.auto_progress_enabled = true
EventEngine._decisions_today = 0  # daily cap reset
EventEngine._maybe_visitor(...)
await get_tree().process_frame
_check_decision_queue()
assert(decision_modal.visible, "ON에서 모달 떠있어야")
_on_auto_skip()                   # default 결정 + 모달 닫기
assert(not decision_modal.visible, "ON에서 _on_auto_skip 호출 후 모달 닫혀야")
```

**부수 효과**: 상단 자원바의 "📜 대기 결정: N건" 라벨을 **삭제**하는 게 정답. 결정 큐 N건이 누적되는 건 위임 모드에선 정보 가치가 없고 (자동 처리됨), 대기 모드에선 모달만 떠서 카운트 불필요. **모달 = 유일한 알림 채널**. 사용자가 "대기 결정 알림" 따로 보는 UX는 이 패턴과 충돌.

**핵심 UX 철학 — "위임이거나 결정"**:
- 위임(ON) = 사용자가 게임에서 손을 떼고, default 결정이 처리해줌. 모달 스팸 안 받게 LOW만 빠르게 통과.
- 결정(OFF) = 사용자가 모든 결정을 보고 함. 게임 진행은 사용자의 결정 또는 +1일 버튼에만 반응.
- 이 분리는 **사용자가 명시적으로 토글**해야만 바뀜 (`P` 키 → `TimeManager.toggle_auto_progress()`). 게임 임의로 변경 X.

### 타이틀 화면 ↔ 게임 모드 토글 (Last Banner v2.2.0, 2026-07-16) — 재진입 UX

게임 코어가 안정화되면 다음 단계 = **재진입 UX**. 사용자가 "어디서부터 시작?"라고 묻지 않게.

**핵심 디자인 결정**:
- 게임 시작 = **항상 타이틀 화면** (`SceneTreeTree`의 `_ready()`에서 `_enter_title_mode()` 호출)
- 타이틀 → 게임: `start_new_game` or `continue_game` 시그널
- 게임 → 타이틀: 우하단 `🏠 타이틀로` 버튼, autosave 후 복귀
- 종료: 타이틀의 `✕ 게임 종료` 버튼 → `get_tree().quit()`

**씬 구조 — 4 CanvasLayer 분기**:
```
Main (Node2D)
├─ ManorLayer (CanvasLayer layer=0)        [게임 모드 전용, initially visible=false]
│  └─ ManorDashboard (Control)
├─ TitleLayer (CanvasLayer layer=5)        [타이틀 모드 전용, initially visible=true]
│  └─ TitleScreen (Control — 로고/버튼들)
├─ UI (CanvasLayer layer=10)               [게임 자원/버튼 행, visible=false]
│  ├─ TopResourceBar
│  └─ BottomButtonRow
└─ ModalLayer (CanvasLayer layer=100)      [결정 모달, 보임/숨김 토글]
```

z-order 분리 + modal 가려짐 함수 해소. 자세한 z-order 함정 → `godot-game-bootstrap/references/canvaslayer-z-order-overlay-pitfall.md`.

**scenes/title_screen.tscn** (핵심 위주):
```
TitleScreen (Control, anchor 전체)
├─ BG (ColorRect anchor 전체, color=(0.08, 0.06, 0.05))
└─ CenterBox (VBoxContainer, anchor 0.5 + ±260×±200)
   ├─ Logo (Label "🏰 LAST BANNER", font_size=48, center)
   ├─ Tagline (Label "변방 영지 운영 로그라이크", font_size=18)
   ├─ StartButton (Button "▶ 새로 시작")
   ├─ ContinueButton (Button "⏵ 이어하기 (N개 저장)", disabled=true)
   ├─ StatusLabel (Label "마지막 저장: <slot>")
   └─ QuitButton (Button "✕ 게임 종료")
```

**scripts/title_screen.gd** 시그널:
```gdscript
signal start_new_game
signal continue_game
signal quit_game_requested

func _ready() -> void:
    _find_nodes()
    _connect_signals()
    _refresh_continue_button()   # SaveManager.list_saves() 기반

func _refresh_continue_button() -> void:
    var saves: Array = SaveManager.list_saves()
    var continue_button: Button = get_node_or_null("CenterBox/ContinueButton")
    if saves.is_empty():
        continue_button.disabled = true
        continue_button.text = "⏵ 이어하기 (저장 없음)"
    else:
        continue_button.disabled = false
        continue_button.text = "⏵ 이어하기 (%d개 저장)" % saves.size()
        var status_label: Label = get_node_or_null("CenterBox/StatusLabel")
        if status_label: status_label.text = "마지막 저장: %s" % saves[0]

func refresh() -> void:
    _refresh_continue_button()  # 외부에서 강제 갱신 ('💾 저장' 직후)
```

**scripts/main.gd** 모드 토글:
```gdscript
var _in_game_mode: bool = false

func _ready() -> void:
    _find_nodes()
    _connect_signals()
    _enter_title_mode()   # 시작은 타이틀 화면

func _enter_title_mode() -> void:
    _in_game_mode = false
    if title_layer: title_layer.visible = true
    if ui_layer: ui_layer.visible = false
    if manor_layer: manor_layer.visible = false
    if decision_modal: decision_modal.visible = false
    if modal_dim_bg: modal_dim_bg.visible = false
    GameManager.current_state = GameManager.State.MENU
    if title_screen and title_screen.has_method("refresh"):
        title_screen.refresh()   # '이어하기' 활성화 등

func _enter_game_mode() -> void:
    _in_game_mode = true
    if title_layer: title_layer.visible = false
    if ui_layer: ui_layer.visible = true
    if manor_layer: manor_layer.visible = true
    GameManager.current_state = GameManager.State.PLAYING
    _refresh_all()      # 자원 카드 새로 그리기

func _on_title_start_new() -> void:
    GameManager.start_new_game("default")
    _enter_game_mode()

func _on_title_continue() -> void:
    var saves: Array = SaveManager.list_saves()
    if not saves.is_empty():
        SaveManager.load_game(saves[0])     # 최신 저장 로드
        GameManager.start_new_game(saves[0])
        _enter_game_mode()
    else:
        _on_title_start_new()   # 저장 없으면 새 게임

func _on_title_menu_pressed() -> void:   # 게임 중 [🏠 타이틀로] 클릭
    SaveManager.save_game("autosave")     # 재진입 보장 — 저장 후 복귀
    _enter_title_mode()
```

**`_process` 분기** — 게임 모드에서만 자동 진행/결정 큐 체크:
```gdscript
func _process(_delta: float) -> void:
    if _verify_mode or not _in_game_mode:
        return   # 타이틀 모드에선 아무것도 안 함
    _refresh_time_label()
    _check_decision_queue()
```

**LB_VERIFY 타이틀 라운드트립 검증 [12]**:
```gdscript
# [12] 타이틀 화면 라운드트립
var saves: Array = SaveManager.list_saves()
assert(not saves.is_empty(), "저장 파일이 있어야 이어하기 검증 가능")
if saves.is_empty():
    SaveManager.save_game("verify_title")
var ts: Control = get_node_or_null("TitleLayer/TitleScreen") as Control
if ts and ts.has_method("refresh"):
    ts.refresh()
    var continue_btn: Button = ts.get_node_or_null("CenterBox/ContinueButton") as Button
    assert(not continue_btn.disabled, "저장 있는데 이어하기 버튼 비활성")

# 진입/퇴장 라운드트립
_enter_title_mode()
assert(not _in_game_mode)
_on_title_start_new()
assert(_in_game_mode)
_on_title_menu_pressed()
assert(not _in_game_mode)
```

**'💾 저장' 버튼 누를 때 강제 refresh** — '이어하기' 버튼 즉시 활성화:
```gdscript
func _on_save_pressed() -> void:
    SaveManager.save_game("manual")
    if title_screen and title_screen.has_method("refresh"):
        title_screen.refresh()  # ← 핵심
```

**결정적 패턴**: 
1. **타이틀을 메인 진입점으로 강제** — UI 첫 노드 = TitleLayer + `visible=true`. 게임 모드 UI는 `visible=false`. 사용자가 의도치 않게 게임 모드로 시작하는 것 방지.
2. **autosave = 재진입 보장** — `🏠 타이틀로` 버튼 누를 때 자동 저장. 다음 세션에서 '이어하기'가 즉시 작동.
3. **`_in_game_mode` 분기로 `_process` 가드** — 타이틀에서 시계/결정 큐 자동 진행 안 됨. `auto_progress_enabled` 상태와 별개로 main.gd 자체가 게이트.

**사용자 선호 (희정님 2026-07-16 직접 요청)**: "이 프로젝트를 진행중인데, 전혀 내가 원하던 방향이 아님" → v2 리셋부터 "오토 진행이 아니면 팝업에서 멈추고, 오토 진행이면 알아서 결정" + "그리고 대기결정은 제거해도 될 것 같은데"까지 사용자가 직접 UX 결정. 이후 v2.2.0에서 "다음 권장 작업은?"에 **"홈 화면 + 시작 메뉴 + 게임 종료 (재진입 UX)"를 직접 선택**. 이 사용자 선호 패턴을 본 스킬이 진단하기 위해 "_test_mode_" 함수 또는 `_on_title_start_new` 같은 명시적 진입점이 아닌 곳에서 게임이 시작되면 안 됨.

### 결정 큐 우선순위 분포 검증 (LB_VERIFY step 8.6, 2026-07-16 last-banner-v2)

자동 진행 게임은 **결정 큐의 다양성**이 핵심. 한 우선순위(예: LOW만)만 30+건 쌓이면 사용자가 답답해하기 전에 게임 이탈. LB_VERIFY에 7일 시뮬 후 분포 assert 추가:

```gdscript
# main.gd _run_verify()
print("[8.6] 결정 큐 우선순위 분포 검증")
var pending: Array = DecisionQueue.get_all_pending()
var priorities := {}
for d in pending:
    var pname: String = DecisionQueue.Priority.keys()[d.priority]
    priorities[pname] = priorities.get(pname, 0) + 1
print("  ✓ 우선순위 분포: %s" % str(priorities))
# 한 종류만 80% 이상이면 UX 답변 부족
if pending.size() >= 10:
    var max_prio_count: int = 0
    for v in priorities.values():
        if v > max_prio_count: max_prio_count = v
    assert(max_prio_count <= pending.size() * 0.8, "한 우선순위 80% 초과 — EventEngine 다양화 필요")
```

이게 통과해도 사용자 데스크탑에서 직접 보면 다른 결함이 보일 수 있음 — 모달 우선순위 라벨 색상, 결정 후 자원 변동 시각화 등. **헤드리스는 다양성만 보장**. 시각 마이크로 조정 = 사용자 의존.

## 화면 인스턴스 자식 검증 (LB_VERIFY step 7, 2026-07-16 Last Banner v2)

자동 진행 게임에 매니저/대시보드 화면을 붙인 직후, 헤드리스 검증이 sprite 부착 + roster 행 생성을 같이 확인하면 **사용자 데스크탑 시각 검증 전에 회귀 잡기** 가능.

```gdscript
# main.gd _run_verify() 끝에 추가
print("[7] ManorDashboard 화면 검증")
var dashboard: Control = get_node_or_null("ManorDashboard") as Control
assert(dashboard != null)
var scene_root_node: Node = dashboard.get_node_or_null(".../SceneRoot")
assert(scene_root_node != null)
var sprite_count: int = 0
for child in scene_root_node.get_children():
    if child is Sprite2D:
        sprite_count += 1
print("  ✓ Manor Scene sprites: %d" % sprite_count)
assert(sprite_count >= 4, "최소 4개 sprite 필요")
var roster_node: Node = dashboard.get_node_or_null(".../RosterVBox")
var roster_count: int = roster_node.get_child_count()
print("  ✓ Roster rows: %d" % roster_count)
assert(roster_count >= 4)
```

**한계**: 헤드리스에선 윈도우 안 그려져서 sprite 이미지 실제 픽셀은 검증 불가. 부착/자식 카운트만 가능. 색상/UI 미세조정 확인은 **사용자 Mac 데스크탑 더블클릭 후 스크린샷 회신**이 정답. 상세 매니저 패러다임: `godot-game-bootstrap/references/manor-dashboard-screen-pattern.md`.

## 📁 첨부 파일

- `references/dashboard-screen-pattern.md` — 영지 대시보드 (라인 차트 + ProgressBar + 메트릭 카드 + 업적 + 시그널 구독 자동 갱신), Control._draw() 직접 그리기 패턴, 토스트 페이드 인/아웃, 5단계 검증 절차 (Last Banner 5차 2026-07-16)
- `references/menu-game-mode-toggle.md` — 메뉴 ↔ 게임 모드 토글 패턴 (`_enter_game_mode()`/`_exit_game_mode()` + 우상단 `MenuToggleButton` + ESC 키). 자동 진행 + 결정 큐 + 대시보드 모두 갖춰진 후 마지막에 적용. `all_assets_ready` 시그널 → 자동 `_on_start_pressed()` → 게임 모드 전환. status_label 분리, 명칭 변경 grep 패턴, LB_VERIFY 검증. (Last Banner 10차 2026-07-16)
- `references/x-close-button-overlay-pattern.md` — 모든 오버레이 화면에 우상단 XButton 통일 (roster/dashboard/succession/buildings/battle/decision_dialog/tutorial 7개). `parent="."`로 root에 부착, anchor_right=1.0, ESC 단축키 외 시각적 X. decision_dialog는 "현재 결정 건너뛰기 + 큐 다음 표시", tutorial은 "skip과 동일". (Last Banner 12차 2026-07-16)
- `references/tutorial-and-succession-patterns.md` — 튜토리얼 4단계 오버레이 (`STEPS` 데이터 + SceneTreeTimer 7초 자동 + `tutorial_seen` 영속화 + 다시보기 prev_seen 백업) + 왕조/후계자 CK3 양식 시스템 (court dict + 4종 스탯 + loyalty/ambition + SUCCESSION_AUDIT/HEIR_BETRAYAL) + LB_VERIFY 헤드리스 hang 3원인 (`@onready` 평가 순서, 시그널 인자 미스매치, `await process_frame` 누적). Last Banner 7~8차 2026-07-16.
- `references/battle-visualization-pattern.md` — 전투 시각화 화면 (3단계 상태머신 + 주사위 애니메이션 + 손실 카드 + 결정 다이얼로그 → 전투 자동 연동 + LB_VERIFY 검증), **`var: Dictionary = Array()` 타입 미스매치 함정**, **tscn Label.modulate 파스 에러 함정**, **`@onready $SceneInstance` 인스턴스화 순서 함정** (Last Banner 7단계 2026-07-16 검증)
- `references/fetch-progress-web-export.md` — Godot 4 Web export + Vercel에서 asset fetch 진행률 0% 멈춤 함정 3가지 + 해결 (시그널은 콜백 안에서만 emit, fetch progress는 파일 수 기반이어야, .import 메타파일 제외) (Last Banner 9차 2026-07-16)

## 핵심 Pitfalls (실전 검증)

### 0. Autoload 멤버 cross-reference는 항상 글로벌 이름 명시 (2026-07-16 last-banner-v2)

같은 이름 변수가 여러 autoload에 있을 때 (TimeManager에 `var day: int`, GameWorld에 없을 때) `day`라고 그냥 쓰면 `Identifier "day" not declared in the current scope` 파스 에러 → GameWorld autoload 로드 실패 → GameManager 등 의존성 연쇄 실패 → 부팅 hang.

**반드시** `TimeManager.day`처럼 명시:
```gdscript
# ❌ game_world.gd 안에서
print("[GameWorld] Day %d — gold %+d" % [day, day_gold_change])

# ✓
print("[GameWorld] Day %d — gold %+d" % [TimeManager.day, day_gold_change])
var entry := {"day": TimeManager.day, "message": message}
```

GDScript는 Python처럼 from-import 없음. 다른 autoload 멤버는 자동 임포트 안 됨. 진단은 `grep -rn "var X:" autoload/`로 즉시 식별 가능. `godot --headless --import` 1회면 4~5개 autoload 동시 파스 에러를 한 번에 잡힘. 자세한 함정 → `godot-game-bootstrap` 스킬.

> 본 스킬의 모든 GDScript 예제 코드는 이미 글로벌 이름 명시 패턴 사용 (EventEngine → TimeManager, GameWorld 등). 새 GameWorld/EventEngine 메서드 작성 시 이 규칙 유지.

### 1. `apply_weekly_bill` 이름 함정
이름만 보면 주 1회 같지만 실제로는 매일 호출. 메서드 이름보다 호출 빈도가 진짜 의미. **이름 변경 시 grep 필수**: `grep -rn "apply_weekly_bill" autoload/ scripts/`.

### 2. GDScript format() 안 되는 케이스
```gdscript
# ❌ Dictionary value 안에서 inline format 안 됨
{ "label": "뇌물 (%d골드)". % cost }

# ✓ 미리 변수에 format 적용 후 삽입
var label: String = "뇌물 (%d골드)" % cost
{ "label": label }
```

### 3. TimeManager.advance_minutes() vs day_changed 시그널
- `advance_minutes()`는 `day_changed`를 day가 바뀔 때만 emit
- 같은 day 안에서 여러 번 호출해도 day_changed는 1번
- 일간 변동 (apply_daily_economy 등)은 day_changed 리스너에 두는 게 정답

### 4. EventEngine이 emit하는 event_fired vs GameManager 일시정지
- `event_fired`는 알림용 (UI 표시)
- `pause_for_decision()`은 CRITICAL 결정 큐 push 시 자동 호출
- 둘은 별개 — event_fired는 결정 큐에 들어가지 않은 사건도 표시 가능

### 5. 자동 진행 끊김 진단
TimeManager가 멈추는 3가지 원인:
1. `auto_progress_enabled = false`
2. `GameManager.is_playing() == false` (PAUSED/DECISION_PENDING)
3. `DecisionQueue.has_pending_critical() == true`

각각 다른 처리가 필요. `print("[TimeManager] tick skipped")` 같은 로그로 추적.

### 6. 자동 저장 충돌
60분마다 자동 저장 + 명시적 load_game 사이에 race condition 가능. `load_state` 마지막에 `_last_auto_save_min = TimeManager.minutes_elapsed` 리셋 필수 (중복 저장 방지).

### 7. 시그널 핸들러 인자 미스매치 (Godot, 2026-07-16 발견)
한 핸들러가 여러 시그널의 콜백이면, **가장 많은 인자를 가진 시그널 기준**으로 디폴트 인자. `mercenary_left(m, reason)` 2개 인자 시그널 + `mercenary_joined(m)` 1개 인자 시그널이 같은 `_on_mercenary_changed`를 호출하면, 핸들러는 `(_m = null, _reason: String = "")` 형태로 디폴트 인자. 런타임 ERROR는 발생하지만 게임 진행은 계속됨 (silent crash) — `LB_VERIFY` 검증에서 `resolve_battle` 호출 → 핸들러 갱신 확인으로 잡힘.

### 8. `var: Dictionary = Array()` 타입 미스매치 (2026-07-16, 전투 화면 검증 발견)
```gdscript
# ❌ Compile Error: Cannot assign a value of type Array to variable "m" with specified type Dictionary
var m: Dictionary = GameWorld.alive_mercenaries()

# ✓ Array로 선언
var m: Array = GameWorld.alive_mercenaries()
if m.size() > 0:
    var victim: Dictionary = m[0]
```

### 9. `await get_tree().process_frame` 누적 (헤드리스 hang, 2026-07-16)
```gdscript
# ❌ 헤드리스에서 hang 가능 (process_frame 신호 지연)
for i in range(60):
    TimeManager.advance_minutes(10)
    await get_tree().process_frame

# ✓ await 없이 동기로 처리
for i in range(60):
    TimeManager.advance_minutes(10)
await get_tree().process_frame  # 한 번만
```

### 10. `@onready $SceneInstance` 인스턴스화 순서 (2026-07-16, 전투 화면 검증 발견)
main.tscn이 여러 PackedScene 인스턴스를 로드할 때 `@onready` 평가 시점에 인스턴스가 트리에 없을 수 있음 → `ERROR: Node not found`. 해결: `var + call_deferred("_find_X")`로 동적 검색.

### 11. tscn Label에 `modulate = Color(...)` 직접 작성 (2026-07-16, 전투 화면 검증 발견)
Label 노드의 tscn 직렬화 형식에서 modulate는 파스 에러. `theme_override_colors/font_color` 또는 .gd 코드에서 런타임 적용으로 회피.

### 12. Autoload 시그널 race condition — emit이 connect보다 빠름 (2026-07-16, 자산 가져오기 버튼 디버깅)
Godot autoload는 main scene보다 먼저 `_ready()` 호출. AssetRegistry가 `_load_manifest()` 안에서 `manifest_loaded.emit()` 호출 → main scene은 아직 인스턴스화 안 됐거나 `_ready` 진입 전 → `connect`는 한참 뒤에 호출 → 시그널은 emit됐는데 아무도 안 받음 → 핸들러 미호출 → UI 상태 영속.

**해결 — 2중 안전망**:
```gdscript
# autoload 측 — emit 지연
func _load_manifest() -> void:
    # ... 파싱 ...
    call_deferred("_emit_manifest_loaded")  # ← 다음 프레임에 emit

# main scene 측 — 안전망
func _ready() -> void:
    AssetRegistry.manifest_loaded.connect(_on_manifest_loaded)
    if AssetRegistry.get_base_url() != "":  # ← 이미 로드됐다면 직접 호출
        _on_manifest_loaded()
```

**LB_VERIFY 주의**: `if _verify_mode: _run_verify(); return`로 early return하면 안전망 미호출 → `get_connections().size() == 0`이 정상. `if not _verify_mode: assert(...)`로 약화.

자세한 진단 + 통합 워크플로 + 3가지 race condition 통합: `references/autoload-signal-race-condition.md` (godot-game-bootstrap 스킬).

## 결정 다이얼로그 UI (Last Banner 2차 검증 완료, 2026-07-15)

자동 진행이 사건을 만들어내도 사용자가 결정을 못 받으면 게임 진행 불가. **결정 다이얼로그 UI**가 핵심.

### 우선순위 기반 UI 분기 (class-level pattern) — 2026-07-16 v2 뒤집기

결정 4개 우선순위 (LOW/MEDIUM/HIGH/CRITICAL)의 **UI 표시 방식**:

| 우선순위 | UI | 자동 skip | 효과 | 이유 |
|---|---|---|---|---|
| LOW | **모달 다이얼로그** | **3초 후 자동 "거절"** | 자동 진행 유지 | 정보성. 사용자가 안 보면 빠르게 통과 |
| MEDIUM | **모달 다이얼로그** | 사용자 결정까지 대기 | 자동 진행 유지 | 결정 가치 있음 |
| HIGH | **모달 다이얼로그** | 사용자 결정까지 대기 | 자동 진행 일시정지 | 무시하면 큰 손실 |
| CRITICAL | **모달 다이얼로그** + 즉시 | 사용자 결정까지 대기 | 자동 진행 즉시 정지 | 안 보면 게임 망함 |

**v1 패턴**: HIGH/CRITICAL만 모달 띄움, LOW/MEDIUM은 알림만 → 큐 30+건 쌓여 답답함.
**v2 패턴** (사용자 직접 선택한 UX, 2026-07-16 last-banner-v2): **모든 우선순위 모달** + **LOW만 3초 후 자동 "거절"로 skip** → spam 방지 + 사용자가 매 결정 인지.

→ 클래스의 다른 게임에도 그대로 차용 가능. 코드 예제는 아래 "v2 LOW 3초 자동 skip 패턴" 섹션.

### 다이얼로그 씬 구조 (decision_dialog.tscn)

```
DecisionDialog (CanvasLayer, layer=10) — 전경
├── DimBG (ColorRect)         — 반투명 검정 (alpha 0.75), mouse_filter=0
└── Card (PanelContainer)     — anchor 0.5 + offset ±360×±260
    └── Margin (24/20/24/20)
        └── VBox
            ├── TitleLabel    (font 26, autowrap)
            ├── PriorityBadge (색 modulate — RED for CRITICAL)
            ├── HSep1
            ├── DescriptionLabel (custom_minimum_size y=80, autowrap)
            ├── HSep2
            ├── ChoicesList   — VBoxContainer (선택지 버튼 동적 생성)
            ├── HSep3
            ├── StatusLabel   — "결정 처리 중..." 일시 메시지
            └── PendingLabel  — "대기 중인 결정: N건"
```

**핵심**: `ChoicesList`의 선택지 버튼은 **런타임 동적 생성** (씬에 박지 X). `payload.choices` 배열 길이만큼 `Button.new()` + `pressed.connect(_on_choice_pressed.bind(choice))`.

### 다이얼로그 표시 로직 (decision_dialog.gd 핵심) — 2026-07-16 v2 패턴

**v2 핵심**: LOW까지 모달 띄우되 `_auto_skip_timer`로 3초 후 자동 skip.

```gdscript
var _auto_skip_timer: SceneTreeTimer = null

func _process(_delta: float) -> void:
    if not visible:
        if DecisionQueue.has_any_pending():
            var current_size: int = DecisionQueue.get_all_pending().size()
            # 큐 길이 증가 시에만 알림/표시 (LOW spam 방지)
            if current_size > _last_notified_queue_size:
                _show_next()
                _last_notified_queue_size = current_size
        else:
            _last_notified_queue_size = 0

func _show_next() -> void:
    if DecisionQueue._queue.is_empty():
        _hide()
        return
    var next: Dictionary = DecisionQueue._queue[0]
    _current_decision = next
    # ... title/description/badge/choices 동적 채우기 (모든 우선순위 모달) ...
    visible = true
    # LOW만 3초 자동 skip
    if next.priority == DecisionQueue.Priority.LOW:
        _auto_skip_timer = get_tree().create_timer(3.0)
        _auto_skip_timer.timeout.connect(_on_low_auto_skip)

func _on_choice_pressed(choice: Dictionary) -> void:
    var result_code: String = choice.get("result", "")
    if not result_code.is_empty():
        GameWorld.apply_result(result_code, _current_decision.payload)
    DecisionQueue.resolve(_current_decision.id, choice)
    _last_notified_queue_size = DecisionQueue.get_all_pending().size()  # reset
    await get_tree().create_timer(0.3).timeout
    if DecisionQueue.has_any_pending() and GameManager.current_state == GameManager.State.DECISION_PENDING:
        _show_next()
    else:
        _hide()

func _on_low_auto_skip() -> void:
    # 사용자가 3초 전에 골랐다면 이미 _current_decision_id 변경 → 가드로 no-op
    if _current_decision.id < 0 or _current_decision == null:
        return
    var default_choice := _default_low_choice(_current_decision)
    if default_choice != "":
        GameWorld.apply_result(default_choice, _current_decision.payload)
    DecisionQueue.resolve(_current_decision.id, {"id": "auto_skip", "label": "(자동 건너뛰기)"})
    _last_notified_queue_size = DecisionQueue.get_all_pending().size()
    await get_tree().create_timer(0.3).timeout
    if DecisionQueue.has_any_pending() and GameManager.current_state == GameManager.State.DECISION_PENDING:
        _show_next()
    else:
        _hide()

# type별 기본 거절 결과 코드
func _default_low_choice(d: Dictionary) -> String:
    match d.type:
        "VISITOR": return "VISITOR_REJECT"
        "FOOD_SHORTAGE": return "FOOD_RATION"
        "DIPLOMACY": return "DIPLOMACY_REFUSE"
        _: return ""  # 매핑 없으면 auto-skip 안 함 → 무한 대기 (안전)
```

**가드 3종이 필수**:
1. `_on_low_auto_skip` 시작에서 `if _current_decision.id < 0` — 사용자가 3초 전에 골랐으면 자동 콜백 no-op
2. `_default_low_choice`에서 매핑 없는 type은 빈 문자열 → 자동 거절 안 함 (사용자가 직접 결정)
3. `_last_notified_queue_size` reset — `_on_choice_pressed`와 `_on_low_auto_skip` 양쪽 모두에서 큐 길이 동기화

### 큐 길이 추적 debouncing — LOW spam 방지 함정

**문제**: 매 `_process` (1초) 호출 → LOW 결정이 큐에 push될 때마다 `_show_next` 호출 → 모달 30+번 spam.

**해결**: `_last_notified_queue_size` 변수로 **큐 길이가 증가할 때만** 알림. resolve로 큐가 줄면 reset.

```gdscript
var _last_notified_queue_size: int = 0

func _process(_delta: float) -> void:
    if not visible:
        if DecisionQueue.has_any_pending():
            var current_size: int = DecisionQueue.get_all_pending().size()
            if current_size > _last_notified_queue_size:
                _show_next()
                _last_notified_queue_size = current_size
        else:
            _last_notified_queue_size = 0
```

**LOW 3초 자동 skip과 동시 사용 시**: `_on_choice_pressed`가 resolve 후 `_last_notified_queue_size` 재계산 필수 — 안 하면 다음 LOW에서 "이미 큐에 있는데 길이 안 늘었다"고 무한 대기.

### GameWorld.apply_result() — 17+개 결과 핸들러 (1~8차 누적)

결정 다이얼로그의 `choice.result` 코드를 자원 변동으로 매핑:

| 결과 코드 | 효과 | 트리거 이벤트 |
|---|---|---|
| `ACCEPT_MERCENARY` | gold -cost, roster.append | MERCENARY_OFFER |
| `REJECT_MERCENARY` | (none) | MERCENARY_OFFER |
| `BATTLE_BANDITS_FIGHT` | 확률 기반 승패 + 사상자 | BANDIT_RAID |
| `BATTLE_BANDITS_HIDE` | food -enemy×2, prosperity -5 | BANDIT_RAID |
| `BATTLE_BANDITS_BRIBE` | gold -cost, prosperity -2 | BANDIT_RAID |
| `DIPLOMACY_ALLIANCE_ACCEPT` | prosperity +8, gold +50 | DIPLOMACY_REQUEST |
| `DIPLOMACY_TRADE` | food +30, prosperity +3 | DIPLOMACY_REQUEST |
| `DIPLOMACY_REFUSE` | prosperity -5 | DIPLOMACY_REQUEST |
| `FOOD_BUY` | gold -50~-80, food +30 | FOOD_LOW/CRISIS |
| `FOOD_RATION` | prosperity -5 | FOOD_LOW/CRISIS |
| `TAX_LOWER` | prosperity +3 | PEASANT_PETITION |
| `TAX_REJECT` | prosperity -2 | PEASANT_PETITION |
| `BETRAYAL_CRUSHER` | heir 처형, 명성 +5, 용병 -2 | HEIR_BETRAYAL |
| `BETRAYAL_BANISH` | heir 추방, 명성 -3 | HEIR_BETRAYAL |
| `BETRAYAL_FORGIVE` | loyalty +20, 명성 -8 | HEIR_BETRAYAL |
| `SUCCESSION_KEEP` | (no-op) | SUCCESSION_AUDIT |
| `SUCCESSION_SWAP` | 1순위 ↔ 2순위 교체 | SUCCESSION_AUDIT |
| `SUCCESSION_NURTURE` | gold -30, loyalty +10 | SUCCESSION_AUDIT |

**전투 확률 처리**: `payload.estimated_victory` (EventEngine이 미리 계산한 승률)를 `randf()`와 비교 → 승/패 분기. 사망자 = `enemy_count × 0.1~0.3 × randf()` + (패배 시 +1).

### main.tscn 통합 패턴

```ini
[gd_scene load_steps=N format=3 uid="uid://b1lastbanner"]

[ext_resource ... "res://scripts/main.gd" id="1_main"]
[ext_resource ... "res://scenes/decision_dialog.tscn" id="2_dialog"]

[node name="Main" type="Node2D"]
script = ExtResource("1_main")

[node name="UI" type="CanvasLayer" parent="."]
# ... 기존 버튼/레이블 ...

[node name="DecisionDialog" parent="." instance=ExtResource("2_dialog")]
visible = false
```

**UID 주의**: 처음 작성 시 UID (`uid://b1decisiondialog`) 텍스트로 박아도 Godot이 "invalid UID" 경고 + 텍스트 경로로 폴백. 빌드 1회 후 자동 정규화. 무시해도 OK.

## 배포 — GitHub Push → Vercel 자동 배포 (2026-07-15 검증)

**Vercel CLI 토큰 만료 시**: `vercel --prod` → `Error: The specified token is not valid`. 하지만 **GitHub push → Vercel GitHub 통합** 자동 배포는 작동.

### Vercel 프로젝트 설정 확인

```bash
cat ~/work/last-banner/.vercel/project.json
# "buildCommand": "bash tools/build.sh web" → Vercel이 빌드 명령으로 사용
# "outputDirectory": "build/web" → 배포 결과 위치
```

### 배포 절차

```bash
cd ~/work/last-banner
git add -A
git commit -m "결정 다이얼로그 UI 추가 + 자동 진행 루프 완성"
git push origin main
# → Vercel GitHub 통합이 자동 빌드+배포 시작 (30~60초)
```

### 라이브 검증 (헤드리스에서 동일 패턴)

```bash
sleep 30
curl -sI https://last-banner.vercel.app/ | head -10
# age: 0 → 방금 배포, COOP/COEP 헤더 정상

# pck에 새 파일 포함 확인
curl -s https://last-banner.vercel.app/index.pck -o /tmp/lb.pck
strings /tmp/lb.pck | grep "decision_dialog"
# → res://scenes/decision_dialog.tscn, res://scripts/decision_dialog.gd 보이면 OK
```

**왜 작동하는가**: `vercel.json`의 `buildCommand`/`outputDirectory`는 Vercel project settings에 영구 저장 → CLI 토큰 없어도 GitHub push가 트리거. **단점**: 토큰 없이 배포 취소/롤백 불가. 즉시 롤백 필요하면 `git revert && git push`로 우회.

## 검증된 세션 누적 (1~7차)

| 차수 | 검증 항목 | 핵심 발견 |
|------|-----------|----------|
| 1 | 자동 진행 + GameWorld + EventEngine + DecisionQueue | 핵심 연결 고리 작동, 결정 큐 0→N |
| 2 | 결정 다이얼로그 UI | HIGH/CRITICAL 자동 표시, 자원 변동 정확 |
| 3 | 용병 명단 화면 | 3-pane List-Detail, 시그널 자동 갱신 |
| 4 | 자동 진행 ON 기본값 + 토스트 | `enable_auto_progress()` + 5초 페이드 트윈 |
| 5 | 영지 대시보드 | 라인 차트 + 메트릭 카드 + 업적, ring buffer |
| 6 | 후계자/정치 시스템 | CK3 양식 4종 스탯, 분기 감사 |
| 7 | 전투 시각화 | 3단계 상태머신 + 주사위 애니메이션 |
| 8 | (planned) 사운드/배경음악 | Wesnoth music lazy fetch |

## 📁 첨부 파일

- `references/dashboard-screen-pattern.md` — 영지 대시보드 (라인 차트 + ProgressBar + 메트릭 카드 + 업적 + 시그널 구독 자동 갱신), Control._draw() 직접 그리기 패턴, 토스트 페이드 인/아웃, 5단계 검증 절차 (Last Banner 5차 2026-07-16)
- `references/menu-game-mode-toggle.md` — 메뉴 ↔ 게임 모드 토글 패턴 (`_enter_game_mode()`/`_exit_game_mode()` + 우상단 `MenuToggleButton` + ESC 키). 자동 진행 + 결정 큐 + 대시보드 모두 갖춰진 후 마지막에 적용. `all_assets_ready` 시그널 → 자동 `_on_start_pressed()` → 게임 모드 전환. status_label 분리, 명칭 변경 grep 패턴, LB_VERIFY 검증. (Last Banner 10차 2026-07-16)
- `references/x-close-button-overlay-pattern.md` — 모든 오버레이 화면에 우상단 XButton 통일 (roster/dashboard/succession/buildings/battle/decision_dialog/tutorial 7개). `parent="."`로 root에 부착, anchor_right=1.0, ESC 단축키 외 시각적 X. decision_dialog는 "현재 결정 건너뛰기 + 큐 다음 표시", tutorial은 "skip과 동일". (Last Banner 12차 2026-07-16)
- `references/tutorial-and-succession-patterns.md` — 튜토리얼 4단계 오버레이 (`STEPS` 데이터 + SceneTreeTimer 7초 자동 + `tutorial_seen` 영속화 + 다시보기 prev_seen 백업) + 왕조/후계자 CK3 양식 시스템 (court dict + 4종 스탯 + loyalty/ambition + SUCCESSION_AUDIT/HEIR_BETRAYAL) + LB_VERIFY 헤드리스 hang 3원인 (`@onready` 평가 순서, 시그널 인자 미스매치, `await process_frame` 누적). Last Banner 7~8차 2026-07-16.
- `references/battle-visualization-pattern.md` — 전투 시각화 화면 (3단계 상태머신 + 주사위 애니메이션 + 손실 카드 + 결정 다이얼로그 → 전투 자동 연동 + LB_VERIFY 검증), **`var: Dictionary = Array()` 타입 미스매치 함정**, **tscn Label.modulate 파스 에러 함정**, **`@onready $SceneInstance` 인스턴스화 순서 함정** (Last Banner 7단계 2026-07-16 검증)
- `references/v2-native-ui-pitfalls.md` — v2.1~v3.0 반복 만난 7가지 UI 반문: CanvasLayer z-order 충돌 (modal 가려짐 4번 반복), Area2D가 Control 부모에서 마우스 이벤트 미수신 → TextureButton 전환, PanelContainer visibility 이중 안전망 (tscn+코드), size 변화 시 position 누적 버그 (original_position 1회 저장), GDScript %(...) 다중 인수 미지원 ([] 배열만), LB_VERIFY stage 사이 _current_decision_id reset 누락, 빈 상태창이 항상 표시되는 Panel 부모 visibility 검출력 부족, v3.0 결정 큐 → BattleScene 라우팅 패턴. (Last Banner v2.1~v3.0 2026-07-16)

---

## Native UI 반문 — Control 부모 + z-order + 가시성 함정 (Last Banner v2.1 ~ v3.0)

## 튜토리얼 4단계 오버레이 패턴 (Last Banner 7차, 2026-07-16)

자동 진행 + 결정 큐 + 명단 + 대시보드 화면이 갖춰졌을 때, **첫 사용자**는 화면이 많고 어디부터 봐야 할지 모름. 4단계 카드 오버레이로 자동 안내.

### 데이터 모델

```gdscript
const STEPS := [
    {
        "icon": "🤖",
        "title": "자동 진행",
        "message": "자동 진행이 켜졌습니다.\n게임이 알아서 시간이 흐르고 자원이 변합니다.\n\n당신이 결정할 일만 모달로 알려드립니다.",
        "hint": "(P 키로 자동 진행 일시정지/재개)"
    },
    {
        "icon": "❓",
        "title": "결정 큐",
        "message": "약탈자 출몰, 식량 위기, 외교 요청 등\n중요한 결정을 내려야 할 때 모달이 자동으로 뜹니다.",
        "hint": "(HIGH/CRITICAL 결정은 게임이 멈춥니다)"
    },
    {
        "icon": "📊",
        "title": "영지 대시보드",
        "message": "D 키를 눌러 영지 대시보드를 열어보세요.",
        "hint": "(D 키)"
    },
    {
        "icon": "⚔️",
        "title": "용병 명단",
        "message": "R 키로 용병 명단을 확인하세요.",
        "hint": "(R 키)"
    }
]
```

### SceneTreeTimer 기반 자동 진행

```gdscript
var _auto_advance_timer: SceneTreeTimer = null

func _schedule_auto_advance(seconds: float) -> void:
    # 기존 타이머 안전 정리
    if _auto_advance_timer != null and _auto_advance_timer.timeout.is_connected(_on_auto_advance):
        _auto_advance_timer.timeout.disconnect(_on_auto_advance)
    _auto_advance_timer = get_tree().create_timer(seconds)
    _auto_advance_timer.timeout.connect(_on_auto_advance)

func _on_auto_advance() -> void:
    if _active:
        _on_next_pressed()
```

7초 후 자동 다음 단계. 사용자가 클릭하면 그 시점부터 7초 리셋.

### `tutorial_seen` 영속화 — 한 번만 보이기

```gdscript
# GameManager
var tutorial_seen: bool = false

func save_state() -> Dictionary:
    return {
        "current_state": State.keys()[current_state],
        "save_slot": save_slot,
        "tutorial_seen": tutorial_seen
    }

func load_state(data: Dictionary) -> void:
    tutorial_seen = data.get("tutorial_seen", false)
    # ...

# tutorial.gd
func start_tutorial() -> void:
    if GameManager.tutorial_seen:
        return  # 이미 봤으면 안 띄움
    _current_step = 0
    _active = true
    visible = true
    _show_step(_current_step)
    _schedule_auto_advance(7.0)

func finish_tutorial() -> void:
    _active = false
    visible = false
    GameManager.tutorial_seen = true  # 영구 저장 플래그
    tutorial_finished.emit()
```

### 다시보기 패턴 — `prev_seen` 백업/복원

main.gd의 "튜토리얼" 버튼은 `tutorial_seen`을 무시하고 강제로 띄움. 완료 후 원래 값 복원:

```gdscript
func _on_tutorial_pressed() -> void:
    if tutorial_screen.has_method("start_tutorial"):
        var prev_seen: bool = GameManager.tutorial_seen
        GameWorld.tutorial_seen = false  # 강제
        tutorial_screen.start_tutorial()
        await tutorial_screen.tutorial_finished
        GameManager.tutorial_seen = prev_seen  # 다시 안 뜨게 복원
```

→ **버튼은 항상 활성**, 첫 자동 실행은 `tutorial_seen == false`일 때만.

### LB_VERIFY 검증

```gdscript
# 1.7) 튜토리얼 검증
tutorial.start_tutorial()
assert(tutorial.visible)
for i in range(4):
    tutorial._on_next_pressed()
assert(not tutorial.visible)
assert(GameManager.tutorial_seen)
tutorial.start_tutorial()  # 두 번째
assert(not tutorial.visible)  # 안 뜸
```

---

## 왕조/후계자 시스템 (CK3 양식, Last Banner 8차, 2026-07-16)

저판타지 정치 미학의 핵심 차별화 요소. 영주 + 후보 3명 + 신하 1명, 4종 스탯(무력/행정/외교/암약), 충성도/야망 동적 변동, 분기마다 후계자 감사, **배신 이벤트**.

### 인물 dict 구조

```gdscript
{
  "id": int,
  "name": String,                       # 자동 생성
  "class": String,                     # lord / heir / vassal / courtier
  "age": int,
  "stats": {                            # CK3 양식 4종
    "martial": int (4~15),
    "stewardship": int,
    "diplomacy": int,
    "intrigue": int
  },
  "loyalty": int (0~100, 30 미만 이탈 위험),
  "ambition": int (0~100, 70 초과 배신 가능),
  "alive": bool,
  "spouse_id": int,                     # -1 = 없음
  "parent_id": int,                     # -1 = 영주
  "heir_rank": int (0=영주, 1=1순위),
  "dynasty": String,
  "portrait_index": int                 # Wesnoth portrait 매핑용
}
```

### GameWorld API

```gdscript
var court: Array = []              # 모든 인물
var dynasty_name: String = ""

func create_person(seed, base_class, heir_rank, parent_id) -> Dictionary
func add_person(person) -> void
func get_person_by_id(id) -> Dictionary
func get_lord() -> Dictionary
func get_heirs() -> Array              # heir_rank 순 정렬
func set_heir_rank(person_id, new_rank) -> void
func kill_person(person_id, reason) -> bool
func _spawn_initial_court(seed) -> void  # 영주 1 + 후보 3 + 신하 1

# 시그널
signal person_added(person: Dictionary)
signal person_removed(person: Dictionary, reason: String)
signal succession_changed(new_heir: Dictionary)
```

### EventEngine 정치 이벤트

```gdscript
const SUCCESSION_AUDIT_INTERVAL_MIN := 4320  # 3일마다

func _maybe_succession_audit(_game_time: int) -> void:
    var heirs: Array = GameWorld.get_heirs()
    # 매 감사마다 loyalty ±5, ambition ±3 변동
    for h in heirs:
        h.loyalty = clamp(h.loyalty + randi() % 11 - 5, 0, 100)
        h.ambition = clamp(h.ambition + randi() % 7 - 3, 0, 100)
    # 배신 위험 감지 → CRITICAL 결정 큐 push
    for h in heirs:
        if h.loyalty < 25 and h.ambition > 65 and randf() > 0.5:
            _maybe_heir_betrayal(h)
            return
```

**3가지 결정 큐 타입**:

| 이벤트 | 우선순위 | 결과 코드 | 효과 |
|---|---|---|---|
| `HEIR_BETRAYAL` | CRITICAL | `BETRAYAL_CRUSHER` | 후계자 처형, 명성 +5, 용병 -2 |
| | | `BETRAYAL_BANISH` | 추방, 명성 -3 |
| | | `BETRAYAL_FORGIVE` | 충성도 +20, 명성 -8 |
| `SUCCESSION_AUDIT` | MEDIUM | `SUCCESSION_KEEP` | 유지 |
| | | `SUCCESSION_SWAP` | 1순위 ↔ 2순위 교체 |
| | | `SUCCESSION_NURTURE` | 골드 -30, 충성도 +10 |

### 성공 화면 패턴 — 인물 카드 동적 생성

`scripts/succession.gd`:
- 좌상단: 현재 영주 (이름, 나이, 4종 스탯, 충성도/야망)
- 본문: 후계자 후보 카드 리스트 (1순위 강조 색상, 충성도/야망 ProgressBar, ⚠️ 배신 위험 라벨)
- `_process`에서 매 프레임 갱신 (loyalty/ambition 자주 변하므로)

### LB_VERIFY 검증 함정 (2026-07-16 발견)

**`apply_result("BETRAYAL_CRUSHER")`가 가끔 헤드리스에서 hang**. `dismiss_mercenary` → `mercenary_left` 시그널 emit → 다른 핸들러가 새 큐 push → 무한 루프 가능성. 라이브에서는 정상 작동. **기본 검증 (인물 생성/조회/순위 교체)** 까지만 LB_VERIFY에 두고, 배신 시뮬레이션은 라이브 수동 테스트.

---

## 신호/핸들러 인자 통일 패턴 (Godot 4, 2026-07-16 종합)

여러 시그널이 같은 핸들러를 호출할 때 인자 수 통일이 필수. **가장 많은 인자를 가진 시그널 기준**으로 디폴트 인자:

```gdscript
# 시그널 3종
signal mercenary_joined(m: Dictionary)           # 1개
signal mercenary_left(m: Dictionary, reason: String)   # 2개
signal mercenary_injured(m: Dictionary, days: int)    # 2개

# 핸들러 — 가장 많은 인자(2개) 기준 디폴트
func _on_mercenary_changed(_m = null, _reason_or_days = null) -> void:
    if visible:
        refresh()
```

**런타임에 명시적 ERROR가 나지만 게임 진행은 계속됨** (silent crash) → LB_VERIFY 검증 단계의 `resolve_battle("defeat", 1, 0)` 호출로 잡힘. 시그니처 불일치 시 ERROR 줄에 `"Method expected N argument(s), but called with M."` 출력.

---

## `@onready` 평가 순서 함정 (Godot 4, 2026-07-16 발견)

`@onready var x: Label = $UI/Toast` 같은 변수는 `_ready()` 함수가 **return 하기 전**에 평가됨. 즉:

```gdscript
func _ready() -> void:
    _verify_mode = OS.has_environment("LB_VERIFY")
    if _verify_mode:
        _run_verify()
        return                       # ← 여기서 return해도 @onready는 이미 평가됨
    # 일반 모드 코드...
```

→ `@onready`로 선언된 `toast_label` 등이 검증 모드 분기 후 null 가능성 있음. 검증 코드는 **null 체크** 필수:
```gdscript
func _show_toast(message: String, duration: float = 5.0) -> void:
    if toast_label == null:
        return
```

분기를 return으로 끊어도 `@onready`는 이미 끝났으므로 안전. 단, `_show_toast` 같은 헬퍼가 검증 모드에서 호출되면 null 가드 필수.

---

## 헤드리스 검증 무한 hang 함정 (2026-07-16 종합)

`await get_tree().process_frame`이 헤드리스에서 무한 hang 가능. 다음 3가지 원인이 확인됨:

1. **`SceneTree` 직접 호출 시 autoload 미등록** — `godot --script`로 SceneTree 서브클래스 직접 실행하면 main scene을 거치지 않아 autoload가 등록되지 않음. → `LB_VERIFY` 환경변수로 main.gd 분기하는 우회 패턴이 정답 (위 "헤드리스 검증 패턴" 섹션).
2. **시그널 인자 미스매치 ERROR로 hang** — `connect()`로 연결된 핸들러가 시그널 인자와 다르면 ERROR + 코드 흐름 중단. LB_VERIFY는 검증 도중 ERROR 발견 시 hang.
3. **`process_frame` 루프 누적** — `for i in range(60): await get_tree().process_frame` 같은 패턴이 헤드리스에서 빠르게 안 끝남. → `await` 없이 동기로 처리 (`for i in range(144): TimeManager.advance_minutes(10)`).

**진단**: 60초 타임아웃 시 hang 위치는 stderr 마지막 줄에서 grep. 대부분 ERROR: Method expected N argument(s)가 catch 포인트.

## 용병 명단 화면 (Last Banner 3차, 2026-07-16 검증 완료)

3-pane List-Detail 레이아웃 (Left list + Center detail + Right stats) + GameWorld 시그널 구독 자동 갱신. 자세한 패턴 + 시그널 핸들러 인자 미스매치 함정 + 색상 표준 → 상위 umbrella `incremental-game-design`의 `references/roster-screen-pattern.md` 참조.

**핵심 발견 (Godot 전용)**: 같은 핸들러가 여러 시그널의 콜백이면, **가장 많은 인자를 가진 시그널 기준**으로 디폴트 인자.

```gdscript
# mercenary_joined(m), mercenary_left(m, reason), mercenary_injured(m, days)
# 3개 시그널 모두 같은 핸들러 호출 → reason/days 둘 다 디폴트
func _on_mercenary_changed(_m = null, _reason_or_days: String = "") -> void:
    if visible:
        refresh()
```

**검증**: `_run_verify()`에 `GameWorld.resolve_battle("defeat", 1, 0)` 추가 → `mercenary_left` 시그널 emit → 핸들러에서 ERROR 없이 갱신 OK면 시그니처 정상.

## 영지 대시보드 화면 (Last Banner 5차, 2026-07-16 검증 완료)

자동 진행의 효과를 시각화하는 표준 화면. 자원 5종 메트릭 + ProgressBar + 라인 차트 + 사건 로그 + 업적 시스템 통합.

**핵심 트리거**: 자동 진행이 자원을 변동시키지만 사용자가 그 효과를 보지 못하면 게임이 정체되어 보임. → 일별 history ring buffer + 차트로 시계열 표시.

**GameWorld 확장**:
- `history: Array` (7일 ring buffer) — `record_day_snapshot(day)`
- `event_log: Array` (20건 ring buffer) — `log_event(message)`
- `achievements: Array` — `unlock_achievement(id, title, description)` + `achievement_unlocked` 시그널

**EventEngine._on_day()**에서 호출:
```gdscript
GameWorld.record_day_snapshot(day)
GameWorld.log_event("Day %d — 자원 변동" % day)
if GameWorld.alive_mercenaries().size() >= 10:
    GameWorld.unlock_achievement("ten_mercenaries", "용병 10명 보유")
```

**라인 차트 — Control._draw() 패턴**:
```gdscript
@onready var chart_canvas: Control = $ChartCanvas

func _ready() -> void:
    chart_canvas.draw.connect(_draw_chart)

func _refresh() -> void:
    chart_canvas.queue_redraw()  # 다음 프레임에 _draw_chart 호출

func _draw_chart() -> void:
    var history: Array = GameWorld.history
    var size: Vector2 = chart_canvas.size
    # ... draw_rect 배경 + draw_line 그리드 + 자원별 draw_line/draw_circle/draw_string
```

**save_state/load_state 확장**: history/event_log/achievements 모두 직렬화 → 사용자 미진입 1달 후 차트/로그/업적 보존.

**Pitfalls** (자세한 패턴은 `references/dashboard-screen-pattern.md`):
1. `theme_override_*` 인덱스 할당 불가 → `add_theme_*_override(name, value)` 메서드
2. `Control._draw()` 직접 호출 X → `queue_redraw()` + `_draw` 시그널 구독
3. `Label` 동적 추가 시 `add_theme_font_size_override` 필수 (theme 없으면 기본 16px 작음)
4. `_process`에서 `refresh()` 전체 호출은 무거움 → 필드별 분리 refresh
5. 시그널 핸들러 인자 통일 → 모든 시그널 인자 다 디폴트 (`_x = null, _y = null`)
6. `draw_string(KOREAN_FONT, ...)` 한글 폰트 명시 → 안 하면 □ 깨짐

**LB_VERIFY 검증 단계 8**: dashboard.show_screen() → 자원 카드 값 확인 → history ≥ 1 → unlock_achievement → 차트 queue_redraw.

**main.tscn 통합** (4종 화면):
```ini
[ext_resource ... "res://scenes/decision_dialog.tscn" id="2_dialog"]
[ext_resource ... "res://scenes/roster.tscn" id="3_roster"]
[ext_resource ... "res://scenes/manor_dashboard.tscn" id="4_dashboard"]

[node name="DecisionDialog" parent="." instance=ExtResource("2_dialog")]
[node name="RosterScreen" parent="." instance=ExtResource("3_roster")]
[node name="Dashboard" parent="." instance=ExtResource("4_dashboard")]
```

## 전투 시각화 화면 (Last Banner 7차, 2026-07-16)

결정 다이얼로그의 텍스트 결과를 **CK3 양식 3단계 시각화**로 전환. 주사위 애니메이션 + 그리드 + 손실 카드.

**3단계 상태머신** (Decision → Simulating → Result):
- **DECISION** — 출격/숨기/뇌물 버튼 (전투 시작 전)
- **SIMULATING** — 주사위 3번 굴림 애니메이션 + 전투력 비교
- **RESULT** — 승/패 + 손실 카드 → 5초 후 자동 종료

**씬 구조**: AlliesCard(좌, GridContainer 5열) + VSLabel(중앙) + EnemiesCard(우, GridContainer) + BottomCard(StatusLabel + DiceLabel + ChoicesRow 동적).

**전투 결과 처리 (`GameWorld.apply_result("BATTLE_BANDITS_FIGHT")`)** — CK3 양식 확률:
```gdscript
var est_victory: float = payload.get("estimated_victory", 0.5)
var roll: float = randf()
if roll <= est_victory:
    # 승리 — 적 0~30%, 아군 0~15% 사망
    resolve_battle("victory", casualties, injured)
else:
    # 패배 — 아군 1~25%, 적 0~10%
    resolve_battle("defeat", casualties, injured)
```

**GDScript 실전 함정 3가지** (전투 화면 검증 발견):
1. `var: Dictionary = Array()` 타입 미스매치 → `var: Array`로 선언
2. tscn Label에 `modulate = Color(...)` 직접 작성 → 파스 에러 → `theme_override_colors/font_color` 또는 .gd 코드 적용
3. `@onready $SceneInstance` 인스턴스화 순서 → `var + call_deferred` 동적 검색 패턴

자세한 패턴 + 결정 다이얼로그 ↔ 전투 자동 연동 + LB_VERIFY 검증 절차: `references/battle-visualization-pattern.md`.