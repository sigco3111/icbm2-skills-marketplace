---
name: incremental-game-design-last-banner-event-engine
description: "Last Banner 실전 검증 GameWorld+EventEngine+DecisionQueue 자동 진행 패턴 — TimeManager tick_advanced/day_changed 시그널 → EventEngine 사건 생성기 → DecisionQueue.push (LOW/MED/HIGH/CRITICAL) → GameManager.pause_for_decision. 자원 5종/용병 9-class/왕조 court/빌딩 4종/자동 저장 60분. **v4.0.0 Phase A 완료** (사건 11종 + 핸들러 27+) / **v4.1.0-alpha Phase B 5단계 완료 (2026-07-20)** (튜토리얼 ✅ + 사운드 ✅ + 게임 종료 ✅ + 모바일 viewport ✅ + 단일 슬롯 ✅). LB_VERIFY 22단계 ([8.10]~[8.14] 포함). 전투 3상태/시간대 그라디언트/라운드트립. **v2/v3/v4 실전 패턴 + 헤드리스 2중 가드 + UI 함정 (PanelContainer anchor 4-값 + tscn 변경 시 사용자 Mac 시각 검증) + GDScript 파스 17종 (int2/% 단일/if-else 한 줄/닫는 괄호/autoload const preload non-static/%() 멤버 접근/%() 단일 인자) + state-dependent assert 전제조건 + 풀 가용성 사전 확인 + B-5 단일 슬롯 정책 (UI 없는 다중 슬롯 = 사고) + assert 전제조건 명시화 (_on_*_pressed 명시적 호출, 함수 분기 다 검증, [DEBUG] state dump 1회 허용) + 사용자 신호 (단순/직접 지시/헤더 1줄 선호)**."
tags: [Game, Godot, EventEngine, DecisionQueue, Auto-progression, BattleScene, ApplyResult, Mercenary, Court, Buildings]
trigger: "Last Banner처럼 GameWorld (영지/용병/왕조/빌딩 데이터) + EventEngine (매 N시간 사건 생성기) + DecisionQueue (우선순위 큐) + GameManager (상태머신) 구조로 자동 진행 게임을 만들 때. 트리거: 'incremental game with EventEngine', 'last banner event engine', 'tick-driven event generator', 'priority decision queue pattern', 'Godot auto progress game', 'battle scene Godot', 'Wesnoth 2D idle PNG', 'building system incremental', 'CK3 dynasty mechanic', 'mercenary roster tier'. **v4.0.0**: 4종 빌딩 시스템 (시장/훈련장/창고/성벽, max Lv 3, base × (lvl+1) 비용 곡선) + LB_VERIFY 골드 보충 패턴. **v3.0**: 결정 큐 → 별도 씬 라우팅 + GameWorld.apply_result 통합 + CanvasLayer 4-tier z-order. **v3.1**: 7일 ring buffer `history` (Control._draw 라인 차트). **v4.1.0-alpha 완료 (2026-07-20)**: Phase B 5단계 모두 완료 — 튜토리얼 4단계 (CanvasLayer layer=15, seen 플래그) + 사운드 (AudioManager 헤드리스 2중 가드 + BGM 4종 페이드 트윈 + SFX 6종 8-풀링 + main.gd 9개 마커 통합) + 게임 종료 3조건 (인구 0 / 식량 0 30일 / 왕조 전원 사망 → GameManager.GAME_OVER + scenes/game_over.tscn layer=120) + 모바일 viewport (`MOBILE_VIEWPORT_THRESHOLD = 800` + `_adjust_modal_for_viewport(modal: Node, viewport_size: Vector2)` + CanvasLayer 내부 Card 자동 탐색 + 9단계 LB_VERIFY [8.13]) + **단일 슬롯 정책 (B-5, 사용자 명시 선호)** — `SaveManager.SAVE_SLOT = \"autosave\"` (다중 슬롯 폐기) + `has_save / delete_save / list_saves(0~1)` + `_cleanup_legacy_slots()` 1회 자동 정리 (verify_* 8개). **v4.0.1 회귀 교훈**: tscn 구조 변경 시 헤드리스 LB_VERIFY + 사용자 Mac 데스크탑 .app 빌드 스크린샷 양쪽 검증 필수. **v4.1.0 신규 함정 (LB_VERIFY 작성)**: autoload는 `const Foo = preload(\"res://autoload/foo.gd\")`로 상수 로드 가능하지만 non-static 메서드 호출 시 `Cannot call non-static function on the class directly` 파스 에러 → `get_node_or_null(\"/root/Foo\")` 인스턴스 사용. **v4.1.0 신규 함정 (GDScript)**: `if expr else 변수` 한 줄 if-else는 GDScript 미지원 (함수 인자 위치만 작동) + `% 포맷 (i + 1, GameManager.foo)` 안에 멤버 접근이 들어가면 파스 에러 → 변수로 미리 추출 + **assert 전제조건 명시화** (함수 호출 = 상태 변경 가정 X, `_on_*_pressed` 명시적 호출, 함수 분기 다 검증). Godot 4 Control/UI/Tween에 막힐 때 `godot-control-input-quirks` + `godot4-ui-panel-overlap-and-tscn-patch-safety.md` 참조. **사용자 신호 (v4.1.0)**: 단순/직접 지시 선호 — 권장 묻기 ('권장하는 것응ㄴ?')에는 **명확한 권장 + 이유 + 선택지** 1회 응답, 이후 바로 진행. 헤더 1줄 응답 선호."
last_updated: 2026-07-20 - v0.9.0 - v4.1.0-alpha Phase B 5단계 모두 완료 (튜토리얼/사운드/게임 종료/모바일/단일 슬롯) + LB_VERIFY 22단계 ([8.10]~[8.14] 포함) + v0.8.0 패턴 + **B-5 단일 슬롯 정책 신규 (Pitfall 28)** — UI 없는 다중 슬롯 = 사고, _cleanup_legacy_slots 1회 자동 정리 + **v4.0.1 UI 회귀 교훈 재확인** (PanelContainer anchor 4-값 명시, tscn 변경 시 사용자 Mac 시각 검증 필수) + **사용자 신호 임베드** (단순/직접 지시/헤더 1줄 선호, "권장 묻기"에 권장 + 이유 + 선택지 1회 응답). GDScript 파스 함정 강화 (autoload const preload non-static / % 포맷 멤버 접근 / if-else 한 줄), assert 전제조건 명시화 (_on_*_pressed 명시 호출), 풀 가용성 사전 확인 워크플로 추가. LB_VERIFY assert 전제조건 명시화 4번째 케이스 (autoload const preload 한계) → 해결 패턴 B (autoload는 get_node_or_null("/root/X")로 인스턴스 접근).
status: live-verified (v4.1.0-alpha Phase B 5단계 완료)
---

# Last Banner Event Engine Pattern (실전 검증)

> **Last Banner**는 2026-07-15 1차 빌드에서 헤드리스 검증까지 통과한 패턴. 자동 진행이 실제로 자원 변동 + 사건 생성 + 결정 큐 push + 저장/로드 round-trip을 모두 수행하는 걸 확인. **v3.3.0 (2026-07-20)**: 9-class 용병 Roster + 4종 신규 사건 + 왕조/후계자 court 시스템 추가. **v4.0.0 (2026-07-20)**: 4종 빌딩 시스템 + LB_VERIFY 17단계. **v4.1.0-alpha (2026-07-20)**: Phase B 5단계 모두 완료 — 튜토리얼 ✅ + 사운드 ✅ + 게임 종료 ✅ + 모바일 viewport ✅ + 단일 슬롯 (B-5) ✅. LB_VERIFY 22단계 ([8.10]~[8.14] 포함). **v4.0.1 UI 회귀**: tscn 구조 변경 시 사용자 Mac 시각 검증 필수. **v4.1.0 사용자 신호**: 단순/직접 지시/헤더 1줄 선호 — "권장 묻기"에는 권장 + 이유 + 선택지 1회 응답, 이후 바로 진행.

## v4.0/v4.1 신규 시스템 (Phase A & B)

| Phase | 시스템 | 신규 API | 신규 시그널 | LB_VERIFY 단계 | 레퍼런스 |
|---|---|---|---|---|---|
| **A-1** | 용병 Roster 9-class tier | `MercenaryData` + `GameWorld.roster` (add/dismiss/injure/...) | 3종 (joined/left/injured) | [8.7] | `references/v4-phase-a-game-systems.md` |
| **A-2** | 왕조 court (CK3 양식) | `GameWorld.court` + 4종 스탯 + get_lord/heirs/vassals | 3종 (added/removed/succession_changed) | [8.8] | `references/v4-phase-a-game-systems.md` |
| **A-3** | 빌딩 시스템 4종 × max Lv 3 | `GameWorld.buildings` + upgrade/get_total_*_bonus | (없음 — 일간 변동) | [8.9] | `references/v4-phase-a-game-systems.md` |
| **A-4** | 사건 4종 추가 (PEASANT/WINTER/MERCHANT/PLAGUE) | `EventEngine._maybe_peasant_petition/_winter_preparation/_merchant_caravan/_plague` | (push → DecisionQueue) | [8.6] | `references/v4-phase-a-game-systems.md` |
| **B-1** | 튜토리얼 4단계 오버레이 | `tutorial.start_tutorial(force)` | `tutorial_finished/skipped` | [8.10] (8단계) | `references/v4-phase-b-ux-polish.md` |
| **B-2** | 사운드 (BGM 4 + SFX 6) | `AudioManager.play_bgm/play_sfx` (헤드리스 자동 가드) | (없음 — 단순 API) | [8.11] (6단계 + 9개 마커) | `references/v4-phase-b-ux-polish.md` |
| **B-3** | 게임 종료 3조건 + 엔딩 | `GameManager.check_game_over_conditions()` + `end_game(reason)` | `game_ended(reason, stats)` | [8.12] (11단계) | `references/v4-phase-b-ux-polish.md` |
| **B-4** | 모바일/태블릿 viewport | `_adjust_modal_for_viewport(modal: Node, viewport_size: Vector2)` | (없음) | [8.13] (9단계) | `references/v4-phase-b-ux-polish.md` |
| **B-5** | **단일 슬롯 정책** | `SaveManager.SAVE_SLOT = "autosave"` + `has_save/delete_save/list_saves(0~1)` + `_cleanup_legacy_slots()` | (없음) | [8.14] (8단계) | `references/v4-phase-b-ux-polish.md` |

### B-4. 모바일 viewport — `_adjust_modal_for_viewport` 패턴 (v4.1.0 신규)

**문제**: 모든 tscn의 offset_* 좌표가 픽셀 고정값 → iPhone 세로 (390×844) / 태블릿 (768×1024)에서 컨텐츠가 화면 밖으로 나감.

**해결 — `MOBILE_VIEWPORT_THRESHOLD = 800` + 동적 offset**:
```gdscript
const MOBILE_VIEWPORT_THRESHOLD := 800   # 너비 < 800px → 모바일 모드

func _is_mobile_viewport() -> bool:
    var size: Vector2 = get_viewport().get_visible_rect().size
    return size.x < MOBILE_VIEWPORT_THRESHOLD

func _adjust_modal_for_viewport(modal: Node, viewport_size: Vector2) -> void:
    if modal == null: return
    if viewport_size.x < MOBILE_VIEWPORT_THRESHOLD:
        # 모바일: viewport 90% 너비, 70% 높이
        var w: float = viewport_size.x * 0.90
        var h: float = viewport_size.y * 0.70
        modal.offset_left = -w * 0.5; modal.offset_right = w * 0.5
        modal.offset_top = -h * 0.5; modal.offset_bottom = h * 0.5
    else:
        # 데스크탑: 원래 사이즈 (±360×±180)
        modal.offset_left = -360.0; modal.offset_right = 360.0
        modal.offset_top = -180.0; modal.offset_bottom = 180.0
```

**시그니처 함정** (Pitfall 26): `modal: Control` 시그니처는 CanvasLayer에서 파스 에러. → **`modal: Node`** 로 확장. `Node`이면 `offset_*` 4-속성 있는 모든 노드 (PanelContainer + CanvasLayer)에서 fail-soft.

**CanvasLayer 내부 Card 자동 탐색** (Tutorial/GameOver는 CanvasLayer라 직접 Control 자식 탐색):
```gdscript
var go_card: Control = null
for child in game_over_screen.get_children():
    if child is Control: go_card = child; break
_adjust_modal_for_viewport(go_card if go_card else game_over_screen, ...)
```

**TopResourceBar 자식 Label** — 모바일에서 overflow 방지 (FILL + clip_text):
```ini
size_flags_horizontal = 3      # FILL — 가변 너비
clip_text = true                # overflow 시 자르기
custom_minimum_size = Vector2(110, 0)
```

**main.gd 통합 3개 위치**: `_enter_game_mode` (Tutorial) / `_show_next_decision` (DecisionModal) / `_on_game_ended` (GameOver) + `_on_title_retutorial` (Tutorial 재시청).

**LB_VERIFY [8.13] 9단계 검증 (v4.1.0-alpha 통과)**:
- MOBILE_VIEWPORT_THRESHOLD == 800
- `_is_mobile_viewport()` + `_adjust_modal_for_viewport()` 메서드 존재
- 현재 viewport (1280×1280 헤드리스) → is_mobile=false
- 1280×720 (데스크탑) → 모달 offset ±360×±180
- 414×896 (모바일) → 모달 viewport 90%×70% (offset 373×627)
- 768×1024 (태블릿) → 모달 90%×70% (offset 691×717) — **1024×768은 800 임계값 초과라 데스크탑 모드 → 태블릿은 768×1024 (iPad mini 세로)로 검증**

**시각 회귀 워크플로**: LB_VERIFY [8.13] 통과해도 **사용자 Mac 데스크탑 .app 빌드 스크린샷으로 1회 확인 필수** (Pitfall 18 보강). 모바일 .app 빌드는 별도 export preset 필요 (현재는 macOS 단일).

### Phase A 한 줄 요약
- **A-1**: `MercenaryData.CLASSES` 9-class + `GameWorld.roster` API 8종 + `EventEngine._maybe_mercenary_offer` 16h 주기 + 충성도 자동 이탈
- **A-2**: `GameWorld.court` 5명 + `EventEngine._maybe_succession_audit` 3일 주기 + HEIR_BETRAYAL CRITICAL
- **A-3**: `BUILDING_DEFS` 4종 + 비용 곡선 `base × (lvl+1)` + 일간 보너스 (tax/food/exp/defense)
- **A-4**: 4종 사건 신규 (LOW ×2 / MEDIUM ×1 / CRITICAL ×1)

### Phase B 한 줄 요약 (v4.1.0-alpha 5단계 완료)
- **B-1**: `tutorial_seen` 영속화 + `tutorial.start_tutorial(force)` + TutorialLayer (layer=15, 모달보다 의도적 하위) + 4단계 STEPS (자동진행/결정큐/자원+차트/4시스템) + 자동 8초 진행 + "튜토리얼 다시보기" 버튼 + `retutorial_requested` 시그널
- **B-2**: `AudioManager` 헤드리스 2중 가드 (`DisplayServer.get_name() != "headless"` + `_check_assets()`) + BGM 4곡 페이드 트윈 (메뉴/게임/전투/모달) + SFX 8-풀링 (modal_open/close/choice_confirm/dice_roll/battle_start/victory) + main.gd **9개 마커 통합** (메뉴 진입/게임 진입/모달 열기/선택 확정/배틀 시작/모달 닫기/오토스킵/배틀 BGM/게임오버)
- **B-3**: `check_game_over_conditions()` 3종 트리거 (인구 0 → POPULATION_EXTINCTION / 식량 0 30일 연속 → FOOD_FAMINE / court 전원 사망 → DYNASTY_EXTINCTION) + `game_ended` 시그널 + `scenes/game_over.tscn` (CanvasLayer layer=120, 3종 라벨/설명 + 통계 7종 + 메인메뉴 복귀) + 11단계 LB_VERIFY [8.12]
- **B-4**: `MOBILE_VIEWPORT_THRESHOLD = 800` + `_adjust_modal_for_viewport(modal: Node, viewport_size: Vector2)` + CanvasLayer 내부 Card 자동 탐색 (Tutorial/GameOver) + TopResourceBar 자식 Label `size_flags_horizontal=3` (FILL) + `clip_text=true` (overflow 방지) + 9단계 LB_VERIFY [8.13] (1280×720 데스크탑 / 414×896 모바일 90%×70% / 768×1024 태블릿 90%×70%)
- **B-5 (사용자 명시 선호)**: **단일 슬롯 정책** — `SaveManager.SAVE_SLOT = "autosave"` (이전 다중 슬롯 폐기) + `save_game(slot)/load_game(slot)` — slot 인자 무시 (호환성 위해 시그니처만 보존) + `has_save()/delete_save()` 신규 API + `list_saves()` — 0 또는 `[autosave]` 1개만 (호환성) + `_cleanup_legacy_slots()` — `_ready`에서 verify_* 등 8개 자동 정리 (1회) + title_screen "이어하기 (N개 저장)" → "이어하기" 또는 "저장 없음" + main.gd `_on_title_continue` — `list_saves[0]` → `has_save() + load_game()` 단일 로드 + 8단계 LB_VERIFY [8.14]

### Phase B 핵심 학습 (v0.8.0 신규)
- **CanvasLayer 4-tier z-order (v4.1.0)**: 모달(100) < 게임오버(120) < 튜토리얼(15, 모달보다 의도적 하위). **튜토리얼이 모달 위에 뜨면 결정 큐를 가림** — 의도된 동작.
- **EventEngine._on_day game_over 평가 순서**: `apply_daily_economy()` 호출 후 `if GameManager.current_state == PLAYING: GameManager.check_game_over_conditions()` — **PAUSED/DECISION_PENDING/GAME_OVER 상태에서는 평가 안 함** (중복 트리거 방지)
- **GameManager.reset_end_state()** 시 `consecutive_food_zero_days = 0` 명시적 리셋 (안 하면 다음 게임 카운터 누적)
- **사운드 자산 풀 가용성** (v4.1.0 신규): Wesnoth 풀은 music 53곡 + sfx 0개. SFX는 sparklinlabs RPG pack (CC0)에서 빌림 — **풀 가용성 사전 확인** 워크플로 필수
- **header 끝 부분** (v4.1.0 신규): "v4.1.0-alpha Phase B 거의 완료" 명시 — 실전 검증 상태 추적

### LB_VERIFY 17 → 22단계 확장 (v4.1.0-alpha 완료)
```
[8.6]   A-4 신규 사건 4종 push 검증
[8.6.5] A-4 결과 핸들러 검증 (10종)
[8.7]   A-1 용병 시스템 (9-class / 5명 / 충성도 이탈 / round-trip)
[8.8]   A-2 왕조/후계자 (court 5명 / SWAP / NURTURE / BETRAYAL_CRUSHER)
[8.9]   A-3 빌딩 (4종 × Lv 1~3 / 비용 곡선 / round-trip)
[8.10]  B-1 튜토리얼 4단계 (8단계 검증) ← v4.1.0 신규
[8.11]  B-2 사운드 (6단계 + main.gd 9개 통합 마커) ← v4.1.0 신규
[8.12]  B-3 게임 종료 (3조건 + 11단계 검증) ← v4.1.0 신규
[8.13]  B-4 모바일 viewport (9단계 — 1280/414/768 viewport 시뮬레이션) ← v4.1.0 신규
[8.14]  B-5 단일 슬롯 정책 (8단계 — SAVE_SLOT/has_save/delete_save + main.gd/title_screen 단일화) ← v4.1.0 신규
```

**상세 — Phase A 4단계 전체 코드 (MercenaryData / GameWorld.court / BUILDING_DEFS / EventEngine._maybe_*)**: `references/v4-phase-a-game-systems.md`
**상세 — Phase B 4단계 (튜토리얼 / 사운드 / 게임 종료 / 모바일)**: `references/v4-phase-b-ux-polish.md`

### v4.0.0 핵심 신규 시스템 (상세 → `references/v4.0-buildings-and-verify-pitfalls.md`)**
- **빌딩 4종** (시장/훈련장/창고/성벽) × max Lv 3, 비용 곡선 `base × (lvl+1)` (Lv 0→1 = base, Lv 2→3 = base×3)
- **`effect_per_level` nested dict** 패턴 → 새 효과 추가 시 한 곳만 수정
- **일간 경제 보너스 합산** (tax_bonus / food_bonus / exp_bonus / defense_bonus)
- **LB_VERIFY 골드 보충 패턴** — 단계별 격리 검증 (직전 단계 자원 변동 무시)
- **GDScript 파스 에러 3종 추가** — `int2` 오타 / `dict.key]` 닫는 괄호 오타 / `% 포맷` 단일 인자

**v3.3.0 핵심 신규 시스템 (상세 → `references/v3.3-mercenary-and-court-pattern.md`)**:
- **용병 9-class tier** (bowman~paladin, T1 60% / T2 30% / T3 10% 가중치) + 시그널 3종 + 자동 이탈 (loyalty<30)
- **왕조 court** (영주 + 후보 3 + 신하 1) + 4종 스탯 (martial/stewardship/diplomacy/intrigue, 4~15) + SUCCESSION_AUDIT (3일 MEDIUM) + HEIR_BETRAYAL (CRITICAL)
- **4종 신규 사건**: PEASANT_PETITION (LOW 매일), WINTER_PREPARATION (MEDIUM season→winter 1회), MERCHANT_CARAVAN (LOW 30h), PLAGUE (CRITICAL 50h, pop>100)
- **GDScript 파스 에러 7가지** (모두 실전 검증): `% 포맷 / class_info.tier] 오타 / 검증 함수 내 변수 중복 / in 키워드(Object 미지원) / macOS timeout 부재 / payload ID 중복 / season_changed 초기 시점

## 핵심 연결 고리

```
TimeManager (autoload, _process)
   │
   ├─ tick_advanced.emit(game_time)
   │     ├─► SaveManager._on_tick   → maybe_auto_save (60분)
   │     └─► EventEngine._on_tick    → 4h/8h/10h/12h 주기 사건
   │
   └─ day_changed.emit(day)
         └─► EventEngine._on_day     → 일간 자원 변동 (apply_daily_economy + apply_weekly_bill)
                                      → apply_injury_recovery
                                      → 농민 호소
```

**3가지 핵심 시그널을 모두 활용** — `tick_advanced`(자원/사건), `day_changed`(일간 변동), `season_changed`(계절별 특별 이벤트).

## GameWorld — 데이터 모델 (영지/용병/왕조/빌딩)

### 자원 5필드

```gdscript
var gold: int = 200                # 금고
var food: int = 100                # 식량
var population: int = 50           # 인구
var prosperity: int = 10           # 명성 0~100
var fortification_level: int = 1   # 요새 Lv 1~5
var lord_name: String = ""         # 자동 생성 (영주 이름)
```

### 용병 Roster — Tier + Class 시스템 (v3.3.0 신규)

```gdscript
const MERCENARY_CLASSES := {
    "bowman":    { "tier": 1, "base_wage": 5,  "labels": ["궁수", "궁병"] },
    "swordsman": { "tier": 1, "base_wage": 4,  "labels": ["검사", "병사"] },
    "pikeman":   { "tier": 1, "base_wage": 5,  "labels": ["창병", "척후"] },
    "sergeant":  { "tier": 2, "base_wage": 12, "labels": ["하사관"] },
    "fencer":    { "tier": 2, "base_wage": 10, "labels": ["페렌스", "결투자"] },
    "crossbow":  { "tier": 2, "base_wage": 11, "labels":["석궁병"] },
    "cavalry":   { "tier": 2, "base_wage": 15, "labels": ["기병"] },
    "captain":   { "tier": 3, "base_wage": 30, "labels": ["선봉장", "대장"] },
    "paladin":   { "tier": 3, "base_wage": 35, "labels": ["성기사"] },
}
```

각 용병은 dict로 저장:
```gdscript
{
  "id": int,
  "name": String (자동 생성),
  "class": String,
  "class_label": String,
  "tier": int,
  "experience": int,
  "loyalty": int (0~100, 30 미만 이탈 위험),
  "wage_demand": int,
  "injured_days": int,
  "alive": bool
}
```

### 왕조 court (v3.3.0 신규)

```gdscript
var court: Array = []              # 모든 인물 (영주 + 후보 + 신하)
var dynasty_name: String = ""

# 인물 dict 구조
{
  "id": int,
  "name": String,
  "class": String,                  # lord / heir / vassal
  "age": int,
  "stats": {                        # CK3 양식 4종 (4~15)
    "martial": int,
    "stewardship": int,
    "diplomacy": int,
    "intrigue": int,
  },
  "loyalty": int (0~100, 30 미만 이탈 위험),
  "ambition": int (0~100, 70 초과 배신 가능),
  "alive": bool,
  "heir_rank": int (0=영주, 1=1순위, -1=신하),
  "dynasty": String,
}
```

### 빌딩 시스템 (v4.0.0 신규)

```gdscript
const BUILDING_MAX_LEVEL := 3
const BUILDING_DEFS := {
    "market":         { "name": "시장", "gold_cost_base": 50, "food_cost_base": 30, "effect_per_level": { "tax_bonus": 5 } },
    "training_ground": { "name": "훈련장", "gold_cost_base": 40, "food_cost_base": 0, "effect_per_level": { "exp_bonus": 2 } },
    "granary":        { "name": "창고", "gold_cost_base": 30, "food_cost_base": 20, "effect_per_level": { "food_bonus": 10 } },
    "walls":          { "name": "성벽", "gold_cost_base": 80, "food_cost_base": 0, "effect_per_level": { "defense_bonus": 10 } },
}
var buildings: Dictionary = {}   # { building_id: level } — 0 = 미건설
```

**비용 곡선** — `get_upgrade_cost(building_id)`:
```gdscript
return {
    "gold": int(def["gold_cost_base"]) * (lvl + 1),
    "food": int(def["food_cost_base"]) * (lvl + 1),
}
```

**상세 패턴 + 일간 보너스 합산 + BUILD_CONSTRUCTION 결정 큐 + 비용 곡선 assert 함정** → `references/v4.0-buildings-and-verify-pitfalls.md`

### 일간 변동 패턴 (v4.0.0 — 건물 보너스 합산)

```gdscript
func apply_daily_economy() -> void:
    var tax: int = max(5, prosperity + population / 4) + get_total_tax_bonus()
    modify_resource("gold", tax)
    var harvest: int = max(2, population / 4) + get_total_food_bonus()
    modify_resource("food", harvest)
    var consumed: int = population / 10 + alive_mercenaries().size() * 2
    modify_resource("food", -consumed)
    var wage: int = total_wage_burden()
    if wage > 0:
        modify_resource("gold", -wage)
    for m in roster:
        if m.alive and m.injured_days > 0:
            m.injured_days -= 1
        if m.alive:
            m.experience += get_total_exp_bonus()  # 훈련장 보너스
```

**함정**: 메서드 이름이 `apply_weekly_bill`이지만 실제로는 매일 호출. 이름보다 호출 빈도가 중요. 이름 변경 시 grep + 모든 caller 업데이트.

## EventEngine — 매 tick 사건 생성기

### 주기 정의 (분 단위, v4.0.0)

```gdscript
const RECRUIT_VISITOR_INTERVAL_MIN := 1200  # 20시간마다 방문객
const FOOD_CHECK_INTERVAL_MIN := 2400        # 40시간마다 식량 체크
const DIPLOMACY_INTERVAL_MIN := 2400         # 40시간마다 외교 요청
const BANDIT_RAID_INTERVAL_MIN := 720        # 12시간마다 약탈자 습격 (HIGH)
const MERCHANT_CARAVAN_INTERVAL_MIN := 1800  # 30시간마다 상인 caravan (LOW)
const PLAGUE_CHECK_INTERVAL_MIN := 3000      # 50시간마다 역병 (CRITICAL, 인구>100)
const PEASANT_PETITION_INTERVAL_MIN := 1440  # 매일 농민 호소 (LOW)
const MERCENARY_OFFER_INTERVAL_MIN := 960    # 16시간마다 용병 자원 제안 (LOW)
const MERCENARY_INJURY_INTERVAL_MIN := 480   # 8시간마다 부상 회복 + 충성도 체크
const SUCCESSION_AUDIT_INTERVAL_MIN := 4320  # 3일마다 후계자 감사 (MEDIUM)
const BUILD_CONSTRUCTION_INTERVAL_MIN := 720 # 12시간마다 건물 건설 제안 (LOW)
const DECISION_MAX_PER_DAY := 8              # 하루 최대 8건
```

### 시그널 연결

```gdscript
func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    TimeManager.tick_advanced.connect(_on_tick)
    TimeManager.day_changed.connect(_on_day)
    TimeManager.season_changed.connect(_on_season)
```

### 사건 타입 (Last Banner v4.0.0, 11종)

| 타입 | 우선순위 | 트리거 |
|---|---|---|
| `VISITOR` | LOW | 20h마다 70% |
| `BANDIT_RAID` | HIGH | 12h마다 40% |
| `DIPLOMACY` | MEDIUM | 40h마다 30% |
| `FOOD_SHORTAGE` | CRITICAL/MEDIUM | 40h마다 food<50 (food<15 → CRITICAL) |
| `PEASANT_PETITION` | LOW | 매일 25% |
| `WINTER_PREPARATION` | MEDIUM | season→winter 1회 |
| `MERCHANT_CARAVAN` | LOW | 30h마다 40% |
| `PLAGUE` | CRITICAL | 50h마다 5% (인구>100) |
| `MERCENARY_OFFER` | LOW | 16h마다 60% (T1 60% / T2 30% / T3 10%) |
| `SUCCESSION_AUDIT` | MEDIUM | 3일마다 |
| `HEIR_BETRAYAL` | CRITICAL | loyalty<25 && ambition>65 |
| `BUILD_CONSTRUCTION` | LOW | 12h마다 50% |

**CRITICAL 발화 시 자동 정지**: `DecisionQueue.push()` 내부에서 `if priority == Priority.CRITICAL: GameManager.pause_for_decision()`.

## SaveManager — 자동 저장 + Round-trip

### tick_advanced 구독으로 자동 저장

```gdscript
func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    TimeManager.tick_advanced.connect(_on_tick)

func _on_tick(_game_time: int) -> void:
    maybe_auto_save()

func maybe_auto_save() -> void:
    if not auto_save_enabled: return
    var now := TimeManager.minutes_elapsed
    if now - _last_auto_save_min >= AUTO_SAVE_INTERVAL_MIN:  # 60분
        if save_game("autosave"):
            _last_auto_save_min = now
```

### Round-trip 직렬화 (v4.0.0 — 4 객체)

```gdscript
func _capture_state() -> Dictionary:
    return {
        "version": SAVE_VERSION,
        "game": GameManager.save_state(),
        "time": TimeManager.save_state(),
        "world": GameWorld.save_state(),         # roster + court + buildings 모두 포함
        "decisions": DecisionQueue.save_state()
    }

func _apply_state(data: Dictionary) -> void:
    if data.has("game"): GameManager.load_state(data["game"])
    if data.has("time"): TimeManager.load_state(data["time"])
    if data.has("world"): GameWorld.load_state(data["world"])
    if data.has("decisions"): DecisionQueue.load_state(data["decisions"])
    _last_auto_save_min = TimeManager.minutes_elapsed
```

**각 autoload마다 `save_state() -> Dictionary` + `load_state(data: Dictionary)` 메서드 1쌍 추가가 표준**. **v4.0.0**: GameWorld.save_state는 `roster + court + buildings + event_log + history + dynasty_name` 모두 직렬화.

## 헤드리스 검증 패턴 — `LB_VERIFY=1` 환경변수

**17단계 누적 (v4.0.0)**:
```
[1]     새 게임 초기 상태 OK
[2]     1일 시뮬
[2.5]   속도 검증 1초 real = 60분 game
[3]     자원 변동
[4]     6일 추가 + 사건 자동 push
[5]     PASS — 자동 진행 ✓
[6]     7일 후 자원
[7]     save/load round-trip
[8]     결과 적용 (VISITOR_WELCOME)
[8.5]   외교 push + 분포 {LOW:10, MEDIUM:2, HIGH:7}
[8.6]   신규 사건 4종 push 검증 (A-4)
[8.6.5] 신규 결과 코드 핸들러 검증 (A-4 — 10종)
[8.7]   용병 시스템 검증 (A-1) — 9-class / 5명 / 충성도 이탈 / round-trip
[8.8]   왕조/후계자 검증 (A-2) — court 5명 / SWAP / NURTURE / BETRAYAL_CRUSHER
[8.9]   빌딩 시스템 검증 (A-3) — 4종 × Lv 1~3 / 비용 곡선 / round-trip
[9~13]  화면 / 호버 / 시간대 / 모달 / 전투 / 차트 / 타이틀 ✓
```

### **NEW: LB_VERIFY 단계별 골드 보충 패턴 (v4.0.0 A-3 검증)**

```gdscript
# 8.9) 빌딩 시스템 검증 (A-3)
print("[8.9] 빌딩 시스템 검증 (A-3)")
# 검증용 골드/식량 보충 (이전 단계 변동 무시)
GameWorld.gold = 1500
GameWorld.food = 1000
# ... 검증 본문 ...
```

**왜 보충이 정답**: LB_VERIFY는 한 메서드 안에서 누적 → 직전 단계 자원 변동이 다음 단계에 영향. **현재 단계 로직 자체를 검증**하는 게 목적 → `GameWorld.gold = 1500` 한 줄로 격리. **잘못된 대안**: 매번 직전 단계 추적 → 직전 단계 변경 시 깨짐.

### **NEW: 변수명 중복 회피 (LB_VERIFY 누적 시)**

```gdscript
# ❌ Parse Error: There is already a variable named "roster_count" declared in this scope.
# step [8.7]와 step [9]에서 같은 이름 두 번 선언

# ✓ 단계별 prefix 또는 의미 변경
# 8.7
var saved_count: int = GameWorld.alive_mercenaries().size()
# 9
var roster_count: int = roster_node.get_child_count()
```

## 핵심 Pitfalls (실전 검증)

### 0. Autoload 멤버 cross-reference는 항상 글로벌 이름 명시 (2026-07-16)

같은 이름 변수가 여러 autoload에 있을 때 `day`라고 그냥 쓰면 `Identifier "day" not declared in the current scope` 파스 에러 → GameWorld autoload 로드 실패 → GameManager 등 의존성 연쇄 실패 → 부팅 hang. **반드시** `TimeManager.day`처럼 명시.

### 1. `apply_weekly_bill` 이름 함정
이름만 보면 주 1회 같지만 실제로는 매일 호출. 메서드 이름보다 호출 빈도가 진짜 의미.

### 2. GDScript format() 안 되는 케이스
```gdscript
# ❌ Dictionary value 안에서 inline format 안 됨
{ "label": "뇌물 (%d골드)". % cost }
# ✓ 미리 변수에 format 적용 후 삽입
var label: String = "뇌물 (%d골드)" % cost
{ "label": label }
```

### 3. TimeManager.advance_minutes() vs day_changed 시그널
`advance_minutes()`는 `day_changed`를 day가 바뀔 때만 emit. 일간 변동은 day_changed 리스너에 두는 게 정답.

### 4. EventEngine이 emit하는 event_fired vs GameManager 일시정지
- `event_fired`는 알림용 (UI 표시)
- `pause_for_decision()`은 CRITICAL 결정 큐 push 시 자동 호출

### 5. 자동 진행 끊김 진단
TimeManager가 멈추는 3가지 원인: `auto_progress_enabled = false` / `GameManager.is_playing() == false` / `DecisionQueue.has_pending_critical() == true`.

### 6. 자동 저장 충돌
`load_state` 마지막에 `_last_auto_save_min = TimeManager.minutes_elapsed` 리셋 필수.

### 7. 시그널 핸들러 인자 미스매치
한 핸들러가 여러 시그널의 콜백이면, **가장 많은 인자를 가진 시그널 기준**으로 디폴트 인자.

### 8. `var: Dictionary = Array()` 타입 미스매치
```gdscript
# ❌ Compile Error
var m: Dictionary = GameWorld.alive_mercenaries()
# ✓ Array로 선언
var m: Array = GameWorld.alive_mercenaries()
if m.size() > 0:
    var victim: Dictionary = m[0]
```

### 9. `await get_tree().process_frame` 누적 (헤드리스 hang)
`for i in range(60): await get_tree().process_frame` 패턴이 헤드리스에서 빠르게 안 끝남 → await 없이 동기 처리.

### 10. `@onready $SceneInstance` 인스턴스화 순서
main.tscn이 여러 PackedScene 인스턴스를 로드할 때 `@onready` 평가 시점에 인스턴스가 트리에 없을 수 있음. `var + call_deferred("_find_X")`로 동적 검색.

### 11. tscn Label에 `modulate = Color(...)` 직접 작성
Label 노드의 tscn 직렬화 형식에서 modulate는 파스 에러. `theme_override_colors/font_color` 또는 .gd 코드에서 런타임 적용으로 회피.

### 12. Autoload 시그널 race condition — emit이 connect보다 빠름
해결 — 2중 안전망: autoload 측 `call_deferred("_emit_manifest_loaded")` + main scene 측 `if ... != "": _on_manifest_loaded()`.

### **NEW (v4.0.0)**: 13. `var X: int2` — 존재하지 않는 타입 오타
GDScript 정수는 `int` 단일. `int2`/`int4` 없음 (vec2i는 있음). 헤더 즉시 확인 → sed 치환.

### **NEW (v4.0.0)**: 14. 닫는 괄호 오타 — `var foo.bar]`
GDScript는 `dict["key"]` 형식만 지원. `dict.key]` 같은 표기 불가. dict[key]는 `dict.key` 단축 표현 가능하지만 닫는 괄호는 `[`만.

### **NEW (v4.0.0)**: 15. `% 포맷 — 단일 인자만 (printf 스타일 미지원)
```gdscript
# ❌ Parse Error: unsupported format character in operator '%'
dynasty_name = "%가 가문" % lord.name   # 's' 누락

# ✓
dynasty_name = "%s 가문" % lord.name
# 다중 인자도 [] 배열 필요
var msg := "%s 가문 (%d 세)" % [lord.name, lord.age]
```

### **NEW (v4.0.0)**: 16. 변수명 중복 (한 함수 안 두 번 선언)
LB_VERIFY `_run_verify()`처럼 거대한 함수에서 단계별 임시 변수가 충돌. step 번호 prefix 또는 의미별 unique name (`gold_before_nurture` / `food_pre_build` / `saved_count`) 권장.

### **NEW (v4.0.0)**: 17. 비용 곡선 assert 함정
`get_upgrade_cost`의 `(lvl+1)` 곱을 빠뜨리면 assert가 항상 false. 수동 계산기로 검증 후 assert에 박을 것 (시장 Lv 0→1: 50, Lv 1→2: 100, Lv 2→3: 150).

### **NEW (v4.1.0)**: 18. PanelContainer 동적 추가 시 anchor 4-값 명시 필수 (사용자 회귀 신호)

**증상** (2026-07-20 사용자 명시 피드백: "UI가 완전히 망가졌음" + 스크린샷): Card 안에 Label이 좌상단 (0,0)에 뭉침. 모달 안의 DimBG만 보이고 내용은 안 보임. **사용자가 즉시 스크린샷으로 시각 회귀 인식** → LB_VERIFY 회귀에도 불구하고 시각 검증 단계 빠뜨린 결과.

**근본 원인**: `PanelContainer` 안에 `VBoxContainer` 자식을 둘 때, 자식의 `anchor_right/bottom`만 명시하고 `anchor_left/top`을 기본값(0)으로 두면 부모 안에서 사이즈가 0이 됨.

```gdscript
# ❌ 망가짐 — anchor_left/top = 0 (기본값), right/bottom = 1.0 → 사이즈 0
[node name="CenterCard" type="PanelContainer" parent="."]
anchor_left = 0.5; anchor_top = 0.5; anchor_right = 0.5; anchor_bottom = 0.5
offset_left = -290; offset_top = -240; offset_right = 290; offset_bottom = 240

[node name="CenterBox" type="VBoxContainer" parent="CenterCard"]
anchor_right = 1.0; anchor_bottom = 1.0
# anchor_left/top 누락 → (0, 0) 위치에 0 사이즈

# ✓ 안전 — anchor 4-값 모두 명시
[node name="CenterBox" type="VBoxContainer" parent="CenterCard"]
anchor_left = 0.0; anchor_top = 0.0
anchor_right = 1.0; anchor_bottom = 1.0
```

**교훈 (v4.0.1 회귀 후)**: 기존에 검증된 tscn 구조 (anchor 4-값 명시)를 함부로 변경하지 말 것. 동적 스타일링은 `add_theme_stylebox_override`로 색상만 입히고, 구조 변경은 신중하게.

**v4.1.0 tscn 안전 패턴**:
1. 기존 검증된 PanelContainer 구조는 그대로 유지
2. 동적 추가 (예: 모달/튜토리얼) 시 anchor 4-값 명시
3. `add_theme_stylebox_override` + 색상 매핑은 안전 (구조 변경 X)
4. **시각 회귀 시 → LB_VERIFY + 사용자 Mac 데스크탑 .app 빌드 스크린샷으로 양쪽 검증**
5. **사용자 시각 피드백 신호** — LB_VERIFY 통과해도 "UI 망가짐" 같은 명시적 지적이 들어오면 즉시 tscn 구조 의심

**v4.0.1 회귀 디버깅 워크플로** (실전 5단계):
1. **사용자 스크린샷 + "UI 망가짐" 신호** → tscn 구조 의심
2. **현재 tscn 직접 read** — anchor_left/top 누락 여부 grep
3. **git diff HEAD~1 -- scenes/main.tscn** — 직전 commit과 비교
4. **검증된 형태로 복원** — UITheme 색상만 입히는 방식 (구조 변경 X)
5. **재빌드 + .app 실행 + 사용자 Mac 시각 확인** — LB_VERIFY만으론 부족

### **NEW (v4.1.0)**: 19. LB_VERIFY assert 전제조건 명시화 (가정 오류 2종)

**증상 1**: `tutorial._show_step(1)` 호출 후 `assert(_current_step == 1)` 실패. 실제 `_show_step`은 화면만 갱신하고 `_current_step`은 변경하지 않음 (단순 표시 함수).

**증상 2**: `GameManager.tutorial_seen = true` 강제 set + `start_tutorial(false)` 호출 후 `assert(not tutorial.visible)` 실패. `_on_skip_pressed`로 명시적 종료가 안 됐으면 `_finish_tutorial` 미호출 → `visible` 상태 잔존.

**근본 원인**: assert는 **모든 전제 조건이 충족된 상태**에서만 통과. `start_tutorial(force=false)` → seen=true이면 skip, `_show_step`은 표시만, `_on_skip_pressed`는 `_finish_tutorial` 호출 — 각 함수의 사이드 이펙트를 모두 이해해야 함.

**해결 패턴**:
```gdscript
# ❌ 가정 오류: start_tutorial만 호출하면 seen 무시하고 보일 것
GameManager.tutorial_seen = true
tutorial.start_tutorial(false)
await get_tree().process_frame
assert(not tutorial.visible)   # ← seen 체크에서 return했으니 visible=true 잔존

# ✓ 명시적 reset + assert
tutorial._on_skip_pressed()     # ← 명시적 종료로 _finish_tutorial 호출
await get_tree().process_frame
assert(not tutorial.visible)
assert(GameManager.tutorial_seen)
GameManager.tutorial_seen = true   # ← 그 다음 seen 강제 set
tutorial.start_tutorial(false)
await get_tree().process_frame
assert(not tutorial.visible)   # ← 정상 skip 동작
```

**LB_VERIFY assert 작성 규칙 (v4.1.0 신규)**:
1. **함수 호출 = 상태 변경 가정 X** — 함수의 사이드 이펙트를 명시적으로 호출
2. **`_on_*_pressed` → 명시적 호출** — 자동 진행 OFF 시 _on_auto_skip가 가드하지만, 검증에서는 직접 호출
3. **assert 전에 명시적 reset 단계** — `_current_decision_id = -1`, `visible = false`, 큐 비우기
4. **함수 분기 다 검증** — seen=true / seen=false / force=true 3가지 경우 모두
5. **디버그 print 1회 허용** — `[DEBUG] visible=%s _active=%s` 같은 state dump로 가설 확인

### **NEW (v4.1.0)**: 26. 게임 종료 시스템 (B-3) — 3종 트리거 + `_on_day` 평가 순서

**3종 패배 조건** (`GameManager.check_game_over_conditions()`):
```gdscript
const CONSECUTIVE_FOOD_ZERO_DAYS_LIMIT := 30
const POPULATION_EXTINCTION_THRESHOLD := 0

func check_game_over_conditions() -> bool:
    if current_state == State.GAME_OVER: return true  # 중복 방지
    if GameWorld.population <= POPULATION_EXTINCTION_THRESHOLD:
        end_game("POPULATION_EXTINCTION"); return true
    if GameWorld.food <= 0:
        consecutive_food_zero_days += 1
        if consecutive_food_zero_days >= CONSECUTIVE_FOOD_ZERO_DAYS_LIMIT:
            end_game("FOOD_FAMINE"); return true
    else:
        consecutive_food_zero_days = 0  # 회복 시 리셋
    var alive_court: int = 0
    for p in GameWorld.court:
        if p.alive: alive_court += 1
    if alive_court == 0:
        end_game("DYNASTY_EXTINCTION"); return true
    return false
```

**`_on_day` 평가 순서** (EventEngine 안):
```gdscript
func _on_day(_d: int) -> void:
    _decisions_today = 0
    GameWorld.apply_daily_economy()
    GameWorld.record_day_snapshot(_d)
    print("[EventEngine] Day %d — 자원 변동: ...", _d)
    # v4.1.0: 게임 오버 평가 (state=PLAYING 일 때만)
    if GameManager and GameManager.current_state == GameManager.State.PLAYING:
        GameManager.check_game_over_conditions()
```

**`state=PLAYING` 체크의 의미**:
- `PAUSED` (토글 OFF): 평가 X (사용자 수동 진행 중)
- `DECISION_PENDING` (결정 큐): 평가 X (이미 결정 처리 중)
- `GAME_OVER` (이미 종료): 평가 X (중복 트리거 방지)
- `PLAYING` (정상): 평가 O

**end_game 패턴** — 통계 + 시그널 emit:
```gdscript
func end_game(reason: String) -> void:
    if current_state == State.GAME_OVER: return
    end_reason = reason
    end_day = TimeManager.day
    end_stats = {
        "gold": GameWorld.gold, "food": GameWorld.food,
        "population": GameWorld.population, "prosperity": GameWorld.prosperity,
        "fortification_level": GameWorld.fortification_level,
        "roster_count": GameWorld.alive_mercenaries().size(),
        "court_count": GameWorld.court.size(),
    }
    current_state = State.GAME_OVER
    game_ended.emit(reason, end_stats)  # main.gd가 받아서 GameOver 화면 표시
```

**`reset_end_state()` 명시 호출** (start_new_game / save load 시):
```gdscript
func reset_end_state() -> void:
    end_reason = ""
    end_day = 0
    end_stats.clear()
    consecutive_food_zero_days = 0  # ⚠️ 명시적 리셋 — 안 하면 다음 게임 카운터 누적
    current_state = State.PLAYING
```

**GameOver.tscn layer=120 (모달보다 위)**:
- `ModalLayer (100) < GameOverLayer (120)` — 게임 오버가 모달 위에 표시되어 결정 큐 가림 (의도)
- `scenes/game_over.tscn`: CanvasLayer layer=120 + DimBG (alpha 0.88) + Card (HeaderRow + DescriptionLabel + DayLabel + StatsTitle + StatsVBox + ButtonRow[Return])
- main.gd `_on_game_ended`에서 `decision_modal.visible=false` → `AudioManager.play_sfx("victory")` + `stop_bgm(true)` → `game_over_screen.show_game_over(...)`
- `_on_game_over_return`에서 `SaveManager.save_game("autosave")` + `_enter_title_mode()`

**엔딩 화면 텍스트 3종 (REASON_LABELS / REASON_DESCRIPTIONS)**:
```gdscript
const REASON_LABELS := {
    "POPULATION_EXTINCTION": "인구 멸망",
    "FOOD_FAMINE": "대기아 (식량 0 연속 30일)",
    "DYNASTY_EXTINCTION": "왕조 멸절",
}
```

### **NEW (v4.1.0)**: 27. 모바일 viewport — 임계값 + `_adjust_modal_for_viewport` 패턴 (B-4)

**문제**: 모든 tscn의 offset_* 좌표가 픽셀 고정값 → iPhone 세로 (390×844) / 태블릿 (768×1024)에서 컨텐츠가 화면 밖으로 나감.

**해결 — `MOBILE_VIEWPORT_THRESHOLD = 800` + 동적 offset**:
```gdscript
const MOBILE_VIEWPORT_THRESHOLD := 800

func _is_mobile_viewport() -> bool:
    var size: Vector2 = get_viewport().get_visible_rect().size
    return size.x < MOBILE_VIEWPORT_THRESHOLD

func _adjust_modal_for_viewport(modal: Node, viewport_size: Vector2) -> void:
    if modal == null: return
    if viewport_size.x < MOBILE_VIEWPORT_THRESHOLD:
        # 모바일: viewport 90% 너비, 70% 높이
        var w: float = viewport_size.x * 0.90
        var h: float = viewport_size.y * 0.70
        modal.offset_left = -w * 0.5; modal.offset_right = w * 0.5
        modal.offset_top = -h * 0.5; modal.offset_bottom = h * 0.5
    else:
        # 데스크탑: 원래 사이즈 (±360×±180)
        modal.offset_left = -360.0; modal.offset_right = 360.0
        modal.offset_top = -180.0; modal.offset_bottom = 180.0
```

**시그니처 함정** (Pitfall 8 보강): `modal: Control` 시그니처는 CanvasLayer에서 파스 에러. → **`modal: Node`** 로 확장. `Node`이면 `offset_*` 4-속성 있는 모든 노드 (PanelContainer + CanvasLayer)에서 fail-soft.

**CanvasLayer 내부 Card 자동 탐색** (Tutorial/GameOver는 CanvasLayer라 직접 Control 자식 탐색):
```gdscript
var go_card: Control = null
for child in game_over_screen.get_children():
    if child is Control: go_card = child; break
_adjust_modal_for_viewport(go_card if go_card else game_over_screen, ...)
```

**TopResourceBar 자식 Label** — 모바일에서 overflow 방지 (FILL + clip_text):
```ini
size_flags_horizontal = 3      # FILL — 가변 너비
clip_text = true                # overflow 시 자르기
custom_minimum_size = Vector2(110, 0)
```

**임계값 함정 (Pitfall 11 보강)**: `MOBILE_VIEWPORT_THRESHOLD = 800`이면 **iPad 가로 (1024×768)도 데스크탑 모드**. 태블릿 검증은 `Vector2(768, 1024)` (iPad mini 세로)로 — 임계값 안의 디바이스 사이즈 선택. **선택 기준**: 800 = 폰 + 작은 태블릿, 1100 = 큰 태블릿 포함, 1280+ = 데스크탑만.

**main.gd 통합 4개 위치**: `_enter_game_mode` (Tutorial) / `_show_next_decision` (DecisionModal) / `_on_game_ended` (GameOver) / `_on_title_retutorial` (Tutorial 재시청).

### **NEW (v4.1.0)**: 28. 단일 슬롯 정책 — 다중 슬롯 UI 없는 시스템 = 사고 (B-5)

**증상**: `SaveManager.save_game(slot: String)`이 String 인자라 사실상 무제한 슬롯 생성 가능. LB_VERIFY가 7개 verify_* 슬롯을 만들면 title_screen에 "이어하기 (9개 저장)" 표시 → 사용자 혼란 ("저장슬롯이 몇개까지 있지? 선택 UI 없는데 그냥 슬롯 하나만 가는 것은 어때?" → 사용자 명시 피드백).

**원인**: 시스템이 다중 슬롯을 허용하면서 UI는 슬롯 선택 안 함 = 1슬롯으로 사용하지만 화면에는 9개 노출.

**해결 — 단일 슬롯 정책**:
```gdscript
const SAVE_SLOT := "autosave"  # v4.1.0: 단일 슬롯 (이전 다중 슬롯 정책 폐기)

func save_game(_slot: String = SAVE_SLOT) -> bool:
    # v4.1.0: slot 인자는 호환성 위해 유지하지만 무시 (항상 SAVE_SLOT로 저장)
    var path := "user://save_%s.json" % SAVE_SLOT
    var file := FileAccess.open(path, FileAccess.WRITE)
    if file == null: return false
    file.store_string(JSON.stringify(_capture_state(), "  "))
    file.close()
    return true

func load_game(_slot: String = SAVE_SLOT) -> bool:
    # v4.1.0: slot 인자 무시 (항상 SAVE_SLOT에서 로드)
    ...

func has_save() -> bool:
    return FileAccess.file_exists("user://save_%s.json" % SAVE_SLOT)

func list_saves() -> Array:
    # v4.1.0: 단일 슬롯 — 0 또는 [autosave] 반환 (호환성 보존)
    if has_save(): return [SAVE_SLOT]
    return []

func delete_save() -> bool:
    # v4.1.0: 단일 슬롯 삭제 (새 게임 시작 시)
    var path := "user://save_%s.json" % SAVE_SLOT
    if not FileAccess.file_exists(path): return false
    return DirAccess.remove_absolute(ProjectSettings.globalize_path(path)) == OK
```

**자동 정리 (1회)**: 첫 실행 시 `_cleanup_legacy_slots()`가 verify_* 등 다중 슬롯 자동 삭제:
```gdscript
func _cleanup_legacy_slots() -> void:
    var dir := DirAccess.open("user://")
    if dir == null: return
    dir.list_dir_begin()
    var name := dir.get_next()
    while name != "":
        if name.begins_with("save_") and name.ends_with(".json"):
            var slot_name: String = name.trim_prefix("save_").trim_suffix(".json")
            if slot_name != SAVE_SLOT:
                DirAccess.remove_absolute(ProjectSettings.globalize_path("user://" + name))
        name = dir.get_next()
    dir.list_dir_end()
```

**UI 단순화**:
```gdscript
# title_screen.gd _refresh_continue_button
func _refresh_continue_button() -> void:
    var has_save: bool = SaveManager.has_save()
    if continue_button:
        if has_save:
            continue_button.disabled = false
            continue_button.text = "⏵ 이어하기"
            if status_label:
                status_label.text = "마지막 자동 저장: %s · Day %d" % [
                    Time.get_datetime_string_from_system().substr(0, 16), TimeManager.day
                ]
        else:
            continue_button.disabled = true
            continue_button.text = "⏵ 이어하기 (저장 없음)"
            if status_label:
                status_label.text = "새 게임을 시작하세요"
```

**판단 기준**: 슬롯 선택 UI가 없으면 단일 슬롯이 정답. 다중 슬롯이 필요하면 **반드시 슬롯 선택 UI** (ListBox/OptionButton 등) 제공. UI 없는 다중 슬롯 = 사고.

### **NEW (v4.1.0)**: 29. 사운드 시스템 (B-2) — 헤드리스 2중 가드 + 9개 통합 마커

**헤드리스 2중 가드** (AudioManager `_ready()`):
```gdscript
func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    _enabled = _is_running_with_display()  # 1) 헤드리스 가드
    if _enabled:
        _asset_available = _check_assets()  # 2) 자산 가드
        if not _asset_available: _enabled = false
    if not _enabled:
        print("[AudioManager] 헤드리스 — 사운드 비활성화")
        return
    _setup_players()
```

**main.gd 통합 9개 마커** (B-2 완료):
- `_enter_title_mode` → `play_bgm("menu")`
- `_enter_game_mode` → `play_bgm("game")`
- `_show_next_decision` → `play_sfx("modal_open")`
- `_on_choice_pressed` → `play_sfx("choice_confirm")` + battle 분기 시 `play_sfx("battle_start")` + `play_bgm("battle")`
- `_on_choice_pressed` 종료부 → `play_sfx("modal_close")`
- `_on_auto_skip` → `play_sfx("modal_close")`
- `_on_game_ended` → `play_sfx("victory")` + `stop_bgm(true)`

**LB_VERIFY [8.11] grep 패턴** (FileAccess로 main.gd 읽고 마커 카운트):
```gdscript
var main_src: String = FileAccess.get_file_as_string("res://scripts/main.gd")
var integration_count: int = 0
for marker in ["_enter_title_mode()", "play_bgm(\"menu\")", "play_bgm(\"game\")", "play_sfx(\"modal_open\")", "play_sfx(\"modal_close\")", "play_sfx(\"choice_confirm\")", "play_sfx(\"battle_start\")", "play_bgm(\"battle\")", "play_sfx(\"victory\")"]:
    if main_src.find(marker) != -1: integration_count += 1
assert(integration_count >= 7, "최소 7개 마커 필요")
```

### **NEW (v4.1.0)**: 30. autoload const preload — non-static 메서드 호출 시 파스 에러 (LB_VERIFY [8.11] 작성 시 흔한 함정)

**증상** (2026-07-20 B-2 [8.11] 검증 작성 시): `const AudioManager = preload("res://autoload/audio_manager.gd")`로 상수 로드 후 `AudioManager.is_enabled()` 호출 시:
```
SCRIPT ERROR: Parse Error: Cannot call non-static function "is_enabled()" on the class
"res://autoload/audio_manager.gd" directly. Make an instance instead.
```

**근본 원인**: GDScript의 `const Foo = preload("path")`는 **클래스 자체**(Script 객체)를 const로 로드. non-static 메서드(`func is_enabled()`)는 인스턴스 메서드이므로 클래스 직접 호출 불가.

**해결 패턴** — autoload 인스턴스 사용 (검증 코드):
```gdscript
# ❌ 파스 에러
const AudioManager = preload("res://autoload/audio_manager.gd")
assert(AudioManager.is_enabled())  # non-static 메서드

# ✓ autoload는 /root에서 인스턴스 접근
var am: Node = get_node_or_null("/root/AudioManager")
assert(am != null, "AudioManager autoload 인스턴스 없음")
assert(am.is_enabled(), "헤드리스 가드 OK")
am.play_bgm("menu")   # 인스턴스 메서드 호출 OK
```

**const preload 비교**:
| 패턴 | non-static 메서드 | 정적 상수 | 사용 사례 |
|---|---|---|---|
| `const X = preload("class.gd")` | ❌ 파스 에러 | ✓ | `X.SOME_CONST` (rare) |
| `var x: Node = get_node("/root/X")` (autoload) | ✓ | ✓ | `x.method()` / `x.CONST` |
| `class_name X` 다른 클래스 | ✓ | ✓ | `X.method()` (씬 외부) |

**LB_VERIFY에서 autoload 검증 작성 4단계 패턴**:
1. `var am: Node = get_node_or_null("/root/AudioManager")` — 인스턴스 확보
2. `am.has_method("is_enabled")` — 메서드 존재 확인 (정적 검사 + 다이나믹 호출 안전)
3. `am.is_enabled()` / `am.play_bgm("menu")` — 인스턴스 메서드 호출
4. `FileAccess.get_file_as_string("res://scripts/main.gd").find(marker)` — 정적 분석 (const/매크로 사용 검증)

### **NEW (v4.1.0)**: 31. CanvasLayer 4-tier z-order (의도적 분리)

**v4.1.0-alpha 4-tier z-order (의도적)**:
- **TutorialLayer (layer=15)**: 튜토리얼 오버레이. 모달보다 **의도적으로 하위** — 튜토리얼이 결정 큐를 가리면 안 됨
- **UI (layer=10)**: 기본 게임 UI
- **TitleLayer (layer=5)**: 타이틀 화면
- **ModalLayer (layer=100)**: 결정 큐 모달. 튜토리얼보다 위
- **GameOverLayer (layer=120)**: 게임 오버 화면. 모달보다 위. 모든 UI 차단

**왜 튜토리얼은 모달 아래?** 튜토리얼은 새 게임 첫 진입 시 자동 표시. 사용자가 튜토리얼을 보는 동안 결정 큐 모달이 떠야 정상 게임 진행 가능. 튜토리얼이 모달 위에 있으면 결정 큐를 못 봄 → 자동 진행 일시정지 → 튜토리얼 닫을 때까지 게임 정지 (UX 최악).

**왜 게임 오버는 모달 위?** 게임 오버 시점에는 결정 큐가 의미 없음. 사용자에게 "당신의 영지는 무너졌습니다" 메시지를 최상위에 표시.

**전체 layer 표**:
| CanvasLayer | layer | z-order 의도 |
|---|---|---|
| TitleLayer | 5 | 타이틀 (게임 진입 전) |
| UI | 10 | 자원바 + 버튼행 (게임 중) |
| TutorialLayer | 15 | 튜토리얼 (모달보다 의도적 하위) |
| BattleLayer | 90 | 전투 화면 (모달보다 하위) |
| ModalLayer | 100 | 결정 큐 (게임 중) |
| GameOverLayer | 120 | 게임 오버 (최상위) |

### **NEW (v4.1.0)**: 32. `.vercelignore`가 빌드 입력을 차단 — TS 컴파일 실패 (sango-rising-dragons 2026-07-20)

**증상**: Vercel 첫 deploy에서 빌드는 통과했으나 TypeScript 컴파일 단계에서 실패:
```
TS18003: No inputs were found in config file '/vercel/path0/tsconfig.json'.
Specified 'include' paths were '["src"]' and 'exclude' paths were '[]'.
```

**근본 원인**: `.vercelignore`가 `src/`를 차단. `vercel deploy`가 첫 배포에서 `.vercelignore`에 따라 **src/ 디렉토리를 업로드에서 제외** → 빌드 컨텍스트에 src/ 없음 → TypeScript 컴파일러가 입력 파일을 찾지 못함. `tsconfig.json`의 `"include": ["src"]`는 빈 디렉토리가 돼서 `TS18003`.

**잘못된 .vercelignore 예시 (sango-rising-dragons 발견)**:
```gitignore
src/              # ❌ 빌드 입력 — 차단하면 TS 컴파일 실패
public/           # ❌ 런타임 데이터/에셋 — 차단하면 화면 깜빡
*.ts              # ❌ 빌드 입력 — 차단하면 TS 없음
```

**올바른 .vercelignore (3가지만 차단)**:
```gitignore
node_modules/
.git/
.gitignore
screenshots/
*.log
.DS_Store
*.md
!README.md
```

**규칙**: src/, public/, *.ts, *.tsx — **절대 차단 금지**. 빌드 입력 또는 런타임 데이터.

**진단**: deploy 후 빌드 로그에 `TS2304: Cannot find name 'X'` 또는 `TS18003: No inputs` 나오면 100% `.vercelignore` 또는 `.vercel/build-output` 누락. **해결 패턴**: 의심스면 일단 모두 allow → 빌드 통과 확인 → 점진적 차단.

**LastBanner 대조**: Godot 프로젝트는 Vercel보다 Itch.io/Steam 배포 위주이므로 이 함정 없음. **Web (Vite/Next/CRA) + Vercel 환경 전용**.

### **NEW (v4.1.0)**: 33. 결정 큐 정책 매트릭스 — 사용자가 4가지 결정 포인트를 선택하는 워크플로 (sango-rising-dragons 2026-07-20)

풀 자동위임 단계에서 사용자가 결정해야 할 4가지:

| # | 결정 | 옵션 | 사용자 선택 (이번 세션) |
|---|---|---|---|
| 1 | 출정 강도 | A. 1.4 (AI 동일) / B. 1.2 / C. 1.0 | **A + B 혼합** (CP<4 보수적, CP>=4 적극) |
| 2 | 조련 사용 | A. 항상 / B. 안 함 | **상황 따라 (CP 충분할 때)** |
| 3 | 출정 전투 모달 | A. 항상 자동 / B. 항상 수동 / C. 혼합 | **C (위임 ON이면 자동, OFF면 선택)** |
| 4 | 풀 자동화 수준 | A. 개간/축성/징병만 / B. 위 + 출정/수색/조련 | **B (전부)** |

**워크플로**:
1. `clarify` 도구로 3-4개 옵션 + 추천 1개 제시
2. 각 옵션의 트레이드오프 명시 (밸런스 영향, 구현 복잡도, 게임 길이)
3. 사용자 선택 후 해당 옵션 구현 + 후속 옵션 자동 결정 근거
4. 전체 구현 후 사용자가 결과 보면서 추가 조정

**함정 — "엔딩까지 자동" 옵션**: 한 단계만 ON으로 끝나지 않음. 출정/전투/이벤트 모두 자동이어야 함. 각 단계마다 결정 큐 깊이가 깊어짐 → 코드 복잡도 ↑. **사용자 시연**: "Cmd+Shift+R 한 번 + 자동위임 ON + 턴 종료 한 번"으로 천하 통일 모달까지 도달.

**LastBanner 대조**: Last Banner는 자동 진행 기본값 (LOW 3초 자동 skip / MEDIUM 사용자 결정 / HIGH 사용자 결정). sango-rising-dragons는 기본값이 수동이고 토글로 전환. **두 게임의 자동 진행 철학이 다름** — Last Banner는 "백그라운드 시뮬", sango는 "위임 가능한 전략 게임".

### **NEW (v4.1.0)**: 34. 전투 AI autopilot 확장 — BattleScene init 옵션 + playerAiStep (sango-rising-dragons 2026-07-20)

**핵심**: 출정이 autoResolve로 자동 결산되면 사용자가 전투 화면을 못 봄. **전투가 게임의 가장 흥미로운 순간**. 위임 ON일 때 출정이 강한 적을 만나면 전투 화면을 띄우고 아군 유닛을 AI가 자동 조작.

**Phaser Scene init에 autopilot 옵션**:
```typescript
init(data: { setup: BattleSetup; autopilot?: boolean }) {
  this.battleAutopilot = !!data.autopilot;  // ★
  ...
}
create() {
  ...
  if (this.battleAutopilot) {
    bus.emit('log', '🤖 전투위임 — 아군 유닛을 자동 조작합니다.', 'auto');
    this.time.delayedCall(450, () => this.playerAiStep());
  }
}
```

**playerAiStep 우선순위** (저체력 유닛 우선):
1. **스킬** (쿨타임 끝 + 45% 확률 + 범위 내 적 → 저체력 우선)
2. **공격** (사거리 내 → 저체력 우선)
3. **이동** (가장 가까운 적 방향 + 공격 가능하면 공격)
4. **대기** (위 셋 불가 시 done)

**finishAction 체인**: 한 행동 끝나면 `setTimeout(360, () => playerAiStep())`으로 다음 행동 자동.

**HUD 배지**: `제 N 라운드 — 아군 행동 🤖 위임 중` + 파란색 (#9cc1ff) 라벨.

**일반화 규칙**: 어떤 Phase든 (전략 맵 / 전투 / 내정) autopilot은:
1. init 옵션으로 진입
2. 체인은 finishAction/tick advance에서 setTimeout으로 다음
3. HUD에 상태 표시 ("🤖 위임 중" 배지)
4. 한 줄 로그 (각 행동마다 bus.emit('log', ..., 'auto'))
5. G.over 체크 (게임 종료 시 모든 autopilot 중단)

### **NEW (v4.1.0)**: 35. 풀 자동위임 검증 시나리오 — "Cmd+Shift+R + 자동위임 ON + 턴 종료 한 번"

목표: 사용자가 한 번의 클릭 시퀀스로 게임이 천하 통일 또는 멸망 모달까지 자동 진행되는 것을 검증.

**검증 단계**:
```
1. 브라우저 cache bust: Cmd+Shift+R
2. 자동위임 토글 ON (파란 글로우 켜짐)
3. 게임 시작 (진영 선택 → 새 캠페인)
4. 도시 클릭 안 함
5. "턴 종료" 버튼 한 번 클릭 (또는 Enter)
6. 로그 시퀀스 관찰:
   - "🤖 자동위임 계획 (공격적, CP=N): X개 — ..."
   - "🤖 #N ... ⚔ 출정(공격) ..."
   - "🤖 자동 출정: ... 🏴 함락!"
   - ... (위임 액션 5-10개)
   - "🤖 자동위임 종료 — AI 턴으로 넘어갑니다."
   - "🤖 자동위임 — 양양 방어 (...) 자동 결산."
7. 다음 플레이어 턴 자동 진입 → 5-7 반복
8. 30-60턴 후:
   - "🏆 천명소귀" 모달 (12개 성도 점령) OR
   - "💀 대세막아" 모달 (성도 0개)
```

**사용자 검증 신호**:
- 모든 로그가 파란 보더('auto' 클래스)로 표시
- 사이드패널 자원 숫자 매 행동마다 갱신
- 미니맵 깃발 색이 매 턴마다 변함
- 모달 안 뜸 (이벤트 모달 제외)

**LastBanner 대조**: Last Banner는 헤드리스 LB_VERIFY로 자동 진행 검증. sango-rising-dragons는 **시각적 게임**이라 헤드리스 검증이 어렵고, **사용자가 직접 게임 플레이하면서 검증**. 둘 다 결국 "자동 진행이 멈추지 않고 끝까지 가는가"가 핵심.

### **NEW (v4.1.0)**: 36. 키보드 단축키 추가 패턴 — 입력 필드 가드 5종 (sango-rising-dragons 2026-07-20)

**상황**: "턴 종료" 버튼을 매번 마우스로 누르기 번거로움 → Enter 키 단축키 추가.

**안전 가드 5종 (★ 모두 필수)**:
```typescript
window.addEventListener('keydown', (e: KeyboardEvent) => {
  if (e.key !== 'Enter') return;  // 1) Enter만
  if (e.shiftKey || e.ctrlKey || e.metaKey || e.altKey) return;  // 2) 조합키 무시
  const tag = (e.target as HTMLElement | null)?.tagName?.toLowerCase();
  if (tag === 'input' || tag === 'textarea' || (e.target as HTMLElement | null)?.isContentEditable) return;  // 3) 입력 필드 가드
  e.preventDefault();  // 4) 기본 동작 차단
  if (G?.over) return;  // 5) 게임 종료 시 무시
  if (!isBusy()) { sfx('click'); endTurn(); }
});
```

**가드 5종 각각의 함정**:
1. **Enter만** — Space/Arrow 등은 미처리 (다른 단축키와 충돌 방지)
2. **조합키 무시** — Shift+Enter (줄바꿈), Cmd+Enter (브라우저) 보존
3. **입력 필드 가드** — input/textarea/contenteditable에서 Enter는 폼 기본 동작
4. **preventDefault** — 입력 필드 밖에서 Enter가 form submit 트리거 차단
5. **G.over 체크** — 게임 종료 모달 중 Enter 추가 트리거 방지

**LastBanner 대조**: Last Banner는 결정 큐 모달이 떠있을 때 Enter가 default 결정 자동 trigger. **Enter = "위임/스킵" 의미**. sango-rising-dragons는 Enter = "다음 턴". **같은 키, 다른 의미** — 두 게임의 단축키 의도가 다름.

---

# v3 패치 (2026-07-20 sango-rising-dragons 추가 학습)

## 11.10 결정 큐 우선순위 진화 — A안 → B안 → C안 → D안

사용자 정책 결정 흐름이 시간순으로 발전한 패턴. 각 옵션이 다음 단계의 전제가 됨:

```
[Phase 1] A안 (사용자 선택: "개간/축성/징병만 자동")
  └─ buildAutopilotQueue: P5 develop/recruit만
  └─ 출정/수색/조련: 수동

[Phase 2] B안 (사용자 선택: "출정 강도는 AI와 동일, CP 충분하면 ratio>1.0")
  └─ pickBestAttack: CP<4 strict (1.4) / CP>=4 relaxed (1.0)
  └─ 출정 모달 우회: bus.emit('autopilotMarch', setup) → 자동결산

[Phase 3] C안 (사용자 선택: "전투 모달 양쪽 다")
  └─ 위임 ON이면 autoResolve 자동
  └─ 위임 OFF이면 사용자 선택 모달

[Phase 4] D안 (사용자 선택: "전투도 자동")
  └─ BattleScene.init에 autopilot 옵션
  └─ playerAiStep: 저체력 유닛 우선 → 스킬/공격/이동
```

**교훈 — 한 번에 모든 결정 안 함**:
- A안 먼저 구현 → 사용자 검증 → 다음 옵션 결정
- 한 번에 4개 옵션 모두 결정하면 사용자 부담 ↑ + 잘못된 가정 시 rollback 어려움
- 각 단계 끝마다 **사용자 시연** (Cmd+Shift+R + 자동위임 ON + 턴 종료 한 번) → 결과 보고 → 다음 결정

## 11.11 결정 큐 5-tier 우선순위 (최종)

| Tier | 액션 | 비용 | 비고 |
|---|---|---|---|
| **P1** | ⚔ 출정(공격) | 1⚡ + 병력 | AI와 동일 ratio>1.4 (CP<4), ratio>1.0 (CP>=4) |
| **P2** | 🚩 출정(이동) | 1⚡ + 병력 | 전선 보강 (인접 아군 도시) |
| **P3** | 🔍 수색 | 1⚡ + 0~100 금 | CP>=2 + 재야 인재 있는 도시 |
| **P4** | 🎯 조련 | 1⚡ + 150 금 | CP>=2 + 가장 약한 장수 |
| **P5** | 🌾🪙🧱⚔ 개발/징병 | 1⚡ + 200~400 금 | A안 + recruit |

**P1이 최우선**인 이유: 적을 안 치면 게임 안 끝남 (12개 성도 점령 = 승리).
**P2가 attack 다음**인 이유: 부대 응집이 다음 출정의 전제.
**P3/P4는 opportunistic** — CP 여유 있을 때만.
**P5 develop는 항상 가능** — CP만 남으면 끝까지.

## 11.12 사용자 시그널 패턴 (4회 결정 워크플로)

세션 중 사용자가 4번 결정한 패턴 — 각 결정의 신호와 응답:

| # | 사용자 신호 | 응답 | 자동 진행 |
|---|---|---|---|
| 1 | "구체적으로 표시되도록 개선해줘" | 로그 + snapshot diff | 다음 |
| 2 | "수색/조련/출정 등 모든 행동을 위임" | 옵션 3개 + 추천 B안 | B안 구현 |
| 3 | "B 전술 전투에 전투위임 토글 추가" | 즉시 구현 | Phaser BattleScene 확장 |
| 4 | "엔터 단축키" | 즉시 구현 | 5종 가드 |

**신호 → 응답 매핑 규칙**:
- "구체적/상세히/뭐가 있지?" → 옵션 + 추천 + trade-off 명시 → 사용자 결정 대기
- "위임할께/해줘/추가해줘" → 추천 옵션 + 근거 + 결정 묻기 → A안 기본 진행
- "X / Y / Z" (선택지 안 보일 때) → 옵션 재제시 + why
- "단축키/추가/개선" → 안전 가드 체크 → 즉시 구현

## 11.13 결정 큐 자동화 일반화 패턴 (Cross-language)

풀 자동화 게임을 구현할 때 결정해야 할 5가지 공통 결정:

| 결정 | Last Banner (GDScript) | sango-rising-dragons (TS) | Last Banner RPG (Godot 향후) |
|---|---|---|---|
| 자동 진행 ON/OFF | 기본값 ON (사용자 설정 가능) | 기본값 OFF + 토글 | (TBD) |
| 결정 큐 깊이 | 별도 데이터 구조 (DecisionQueue) | 함수 호출 시점 생성 | (TBD) |
| 모달 회피 | EventEngine이 모달 자체 emit 안 함 | searchTalent 인라인화 | (TBD) |
| 비동기 핸들링 | `await apply_result()` | bus.emit + setTimeout | (TBD) |
| 진행 속도 | `TimeManager.speed_multiplier` | 220ms setTimeout | (TBD) |

**공통 체크리스트**:
- [ ] 자동 진행 ON/OFF 토글 또는 설정
- [ ] 결정 큐 우선순위 명시
- [ ] 모달 회피 (사이드 이펙트 방지)
- [ ] 비동기 핸들러 + 체인
- [ ] 진행 속도 조절 (너무 빠르면 안 읽힘, 너무 느리면 답답)
- [ ] G.over / 게임 종료 체크 (모든 autopilot 중단)
- [ ] 사용자 진단 협조 (로그 + console hook)
- [ ] 안전 카운터 (무한 루프 차단)
- [ ] 풀 자동화 검증 시나리오 (엔딩까지 도달)

### **NEW (v4.1.0)**: 20. GDScript `if 표현식 else 변수` — GDScript 미지원 문법

**증상**: `var x: Type = ... if condition else null` 같은 한 줄 if-else가 파스 에러 또는 의도와 다른 결과.

**원인**: GDScript는 Python-style ternary expression을 지원하지 않음. `value if condition else other`는 함수 인자 위치에서만 작동.

```gdscript
# ❌ 파스 에러
var tutorial: CanvasLayer = tutorial_layer.get_node_or_null("Tutorial") as CanvasLayer if tutorial_layer else null
# → GDScript가 `if tutorial_layer else null`을 함수 인자 식으로 파싱 시도, 실패

# ✓ 명시적 if-else
var tutorial: CanvasLayer = null
if tutorial_layer:
    tutorial = tutorial_layer.get_node_or_null("Tutorial") as CanvasLayer
```

**해결**: 변수를 먼저 선언 → if-else 블록에서 할당. 또는 `null` 초기값을 명시적으로 줌.

### **NEW (v4.1.0)**: 21. 사운드 자산 풀 가용성 사전 확인 워크플로 (B-2 학습)

**상황**: Phase B-2 사운드 시스템 구축 시 Wesnoth 풀(`~/work/game-assets-pool/extracted/wesnoth/`)에 music 53곡만 있고 sfx는 0개. 다른 풀(sparklinlabs RPG CC0)에서 sfx를 가져와야 했음.

**교훈**: 새 자산 카테고리 추가 전 **반드시 풀 가용성 사전 확인**:

```bash
# 1. 풀 디렉터리 확인
ls ~/work/game-assets-pool/extracted/wesnoth/  # → music, portraits, sounds, units

# 2. 카테고리별 파일 카운트
find ~/work/game-assets-pool/extracted/wesnoth/music -name "*.ogg" | wc -l   # 53
find ~/work/game-assets-pool/extracted/wesnoth/sounds -name "*.ogg" 2>/dev/null | wc -l  # 0

# 3. 다른 풀 백업 검색
find ~/work -name "*.ogg" -path "*sparklinlabs*" | head -5
```

**v4.1.0 사운드 풀 구성 (실전 결정)**:
- BGM: `~/work/game-assets-pool/extracted/wesnoth/music/core/music/` (4곡 — elf-land/knolls/battle-epic/sad)
- SFX: `~/work/game-assets-pool/free/2D/CC0/sparklinlabs_superpowers-asset-packs/superpowers-asset-packs-master/rpg-battle-system/sound/` (6곡)

**Best Practice**: 풀 검색을 **메인 자산 작업 직전** (1~2시간 전)에 1회. setup-assets.sh로 자동화 안 된 카테고리는 수동으로 fetch.

### **NEW (v4.1.0)**: 22. 게임 시스템 사망 (Death) — 헤드리스 가드 + 사용자 알림 패턴

**상황**: 사용자 .app 빌드 후 macOS 데스크탑에서 실행했을 때, 헤드리스 LB_VERIFY는 통과했지만 시각 회귀 발생. 또는 사운드 자산 없으면 play_bgm() 호출 시 hang.

**해결 패턴 — 헤드리스 / 자산 / 사용 환경 모두 가드**:
```gdscript
# AudioManager (B-2)
func _ready() -> void:
    _enabled = _is_running_with_display()  # 1) 헤드리스 가드
    if _enabled:
        _asset_available = _check_assets()  # 2) 자산 가드
        if not _asset_available:
            _enabled = false
    if not _enabled:
        print("[AudioManager] 비활성화 (헤드리스 또는 자산 없음)")
        return
    _setup_players()

func play_bgm(name: String, fade: bool = true) -> void:
    if not _enabled: return   # 3) 호출부 가드
    if not BGM_TRACKS.has(name): return
    if not ResourceLoader.exists(BGM_TRACKS[name]): return   # 4) 자산 존재 가드
    ...
```

**3중 가드 원칙**: (1) autoload `_ready`에서 환경 체크 (2) `is_enabled()` API 제공 (3) 호출부에서 `if not _enabled: return` 명시. 사용자에게 노출되는 API는 항상 안전.

### **NEW (v4.1.0)**: 23. autoload `const Foo = preload("res://autoload/foo.gd")` — non-static 메서드 호출 시 파스 에러 (LB_VERIFY 작성 시 흔한 함정)

**증상** (2026-07-20 B-2 [8.11] 검증 작성 시): `const AudioManager = preload("res://autoload/audio_manager.gd")`로 상수 로드 후 `AudioManager.is_enabled()` 호출 시:

```
SCRIPT ERROR: Parse Error: Cannot call non-static function "is_enabled()" on the class
"res://autoload/audio_manager.gd" directly. Make an instance instead.
```

**근본 원인**: GDScript의 `const Foo = preload("path")`는 **클래스 자체**(Script 객체)를 const로 로드. non-static 메서드(`func is_enabled()`)는 인스턴스 메서드이므로 클래스 직접 호출 불가. **STATIC 메서드만 호출 가능** (e.g., `const X = preload(...); X.STATIC_CONST`).

**해결 패턴 A** — autoload 인스턴스 사용 (검증 코드):
```gdscript
# ❌ 파스 에러
const AudioManager = preload("res://autoload/audio_manager.gd")
...
assert(AudioManager.is_enabled())  # non-static 메서드

# ✓ autoload는 /root에서 인스턴스 접근
var am: Node = get_node_or_null("/root/AudioManager")
assert(am != null, "AudioManager autoload 인스턴스 없음")
assert(am.is_enabled(), "헤드리스 가드 OK")
am.play_bgm("menu")   # 인스턴스 메서드 호출 OK
```

**해결 패턴 B** — autoload가 `class_name` 선언 시 (씬 script가 아닌 진짜 클래스):
```gdscript
# autoload/foo.gd
class_name Foo
# → 다른 파일에서 그냥 Foo.method() 호출 가능 (이 경우는 autoload와 무관)

# 단, autoload는 보통 `class_name` 없이 *_autoload 형식 → preload const로 인스턴스 메서드 호출 불가
```

**LB_VERIFY에서 autoload 검증 작성 시 4단계 패턴**:
1. `var am: Node = get_node_or_null("/root/AudioManager")` — 인스턴스 확보
2. `am.has_method("is_enabled")` — 메서드 존재 확인 (정적 검사 + 다이나믹 호출 안전)
3. `am.is_enabled()` / `am.play_bgm("menu")` — 인스턴스 메서드 호출
4. `FileAccess.get_file_as_string("res://scripts/main.gd").find(marker)` — 정적 분석 (const/매크로 사용 검증)

**`: 비-const preload 비교**:
| 패턴 | non-static 메서드 | 정적 상수 | 사용 사례 |
|---|---|---|---|
| `const X = preload("class.gd")` | ❌ 파스 에러 | ✓ | `X.SOME_CONST` (rare) |
| `var x: Node = get_node("/root/X")` (autoload) | ✓ | ✓ | `x.method()` / `x.CONST` |
| `class_name X` 다른 클래스 | ✓ | ✓ | `X.method()` (씬 외부) |

**v4.1.0 B-2 [8.11] 90% 완성**: 본 함정으로 마지막 10% 막힘 → 다음 세션 첫 액션이 `const AudioManager` 라인 제거 + `am` 인스턴스 변수 사용으로 수정.

### **NEW (v4.1.0)**: 24. GDScript `% (expr_a, expr_b.method())` — 포맷 안에 멤버 접근 시 파스 에러

**증상** (2026-07-20 B-3 [8.12] 검증 작성 시):
```gdscript
assert(not triggered, "Day %d: 아직 30일 미만 (food=0 누적 %d일)" % (i + 1, GameManager.consecutive_food_zero_days))
# → SCRIPT ERROR: Parse Error: Expected closing ")" after grouping expression.
```

**근본 원인**: GDScript의 `%` 포맷 연산자는 `()` 그룹 안의 표현식을 평가한 후 포맷. 그룹 안에 **멤버 접근** `GameManager.consecutive_food_zero_days`이 있으면 파서가 그룹의 끝을 찾지 못함. `(i + 1, GameManager.foo)`에서 `GameManager.foo`의 `.`가 메서드 호출이 아니라 속성 접근으로 인식되지 않음.

**해결 패턴** — 값을 변수로 미리 추출:
```gdscript
# ❌ 파스 에러
assert(not triggered, "Day %d: 누적 %d일" % (i + 1, GameManager.consecutive_food_zero_days))

# ✓ 변수로 미리 추출
for i in range(29):
    var triggered: bool = GameManager.check_game_over_conditions()
    var day_count: int = i + 1
    var zero_count: int = GameManager.consecutive_food_zero_days
    assert(not triggered, "Day %d: 누적 %d일" % [day_count, zero_count])
```

**GDScript `%` 포맷 규칙** (Pitfall 15 보강):
- 단일 인자: `"%d" % 42` (괄호 불필요)
- 다중 인자: **`[] 배열 필수`** — `"%s 가문 (%d 세)" % [name, age]`
- 그룹 `(a, b)` 자체는 GDScript 미지원 — 반드시 `[]` 사용
- `% (a, obj.method())` 같이 그룹 안에 멤버 접근 → 파스 에러 → 변수로 추출

**v4.1.0 LB_VERIFY 작성 규칙 (v0.8.0 신규)**: assert 메시지에 **2개 이상 값** 넣을 땐 `[] 배열` + **모든 값을 변수에 미리 추출** (멤버 접근 금지).

### **NEW (v4.1.0)**: 25. Phase B z-order 의도적 분리 — TutorialLayer(15) vs ModalLayer(100) vs GameOverLayer(120)

**v4.1.0-alpha 4-tier z-order (의도적)**:
- **TutorialLayer (layer=15)**: 튜토리얼 오버레이. 모달보다 **의도적으로 하위** — 튜토리얼이 결정 큐를 가리면 안 됨.
- **UI (layer=10)**: 기본 게임 UI (자원바 / 버튼행)
- **TitleLayer (layer=5)**: 타이틀 화면
- **ModalLayer (layer=100)**: 결정 큐 모달. 튜토리얼보다 위.
- **GameOverLayer (layer=120)**: 게임 오버 화면. 모달보다 위. 모든 UI 차단.

**왜 튜토리얼은 모달 아래?** 튜토리얼은 새 게임 첫 진입 시 자동으로 뜨는데, 사용자가 튜토리얼을 보는 동안 결정 큐 모달이 떠야 정상 게임 진행 가능. 튜토리얼이 모달 위에 있으면 결정 큐를 못 봄 → 자동 진행 일시정지 → 튜토리얼 닫을 때까지 게임 정지 (UX 최악).

**왜 게임 오버는 모달 위?** 게임 오버 시점에는 결정 큐가 의미 없음 (이미 종료). 사용자에게 "당신의 영지는 무너졌습니다" 메시지를 최상위에 표시.

**v4.1.0 신규 시스템 z-order 표**:
| CanvasLayer | layer | z-order 의도 |
|---|---|---|
| TitleLayer | 5 | 타이틀 (게임 진입 전) |
| UI | 10 | 자원바 + 버튼행 (게임 중) |
| TutorialLayer | 15 | 튜토리얼 (모달보다 의도적 하위) |
| BattleLayer | 90 | 전투 화면 (모달보다 하위) |
| ModalLayer | 100 | 결정 큐 (게임 중) |
| GameOverLayer | 120 | 게임 오버 (최상위) |

**v4.1.0 GameOver.tscn layer=120 추가** (v4.0.0에서 미사용이던 State.GAME_OVER 활용): 사용자가 명시적으로 게임 종료 시 최상위 표시. main.gd `_on_game_ended`에서 `decision_modal.visible=false` → `game_over_screen.show_game_over(...)` 순서.

**v4.1.0 EventEngine 일간 game_over 평가 순서**:
```gdscript
# EventEngine._on_day 안
GameWorld.apply_daily_economy()
GameWorld.record_day_snapshot(_d)
print("[EventEngine] Day %d — 자원 변동: ...")
# v4.1.0: 게임 오버 평가 (state=PLAYING 일 때만)
if GameManager and GameManager.current_state == GameManager.State.PLAYING:
    GameManager.check_game_over_conditions()
```

**`state=PLAYING` 체크의 의미**: 
- `PAUSED` (토글 OFF): 평가 안 함 (사용자 수동 진행 중)
- `DECISION_PENDING` (결정 큐): 평가 안 함 (이미 결정 처리 중)
- `GAME_OVER` (이미 종료): 평가 안 함 (중복 트리거 방지)
- `PLAYING` (정상): 평가 O

## 결정 다이얼로그 UI (Last Banner 2차 검증 완료, 2026-07-15)

**v4.1.0 게임 종료 패턴 (B-3) — `GameWorld.check_game_over()` + `GameManager.game_over(reason)`**:
```gdscript
# GameWorld.apply_daily_economy() 끝부분
if population <= 0:
    GameManager.game_over("EXTINCTION")
    return
if food < 1:
    _starvation_days += 1
    if _starvation_days >= 30:
        GameManager.game_over("STARVATION")
        return
else:
    _starvation_days = 0
# 왕조 전원 사망
var alive_lord_or_heirs := 0
for p in court:
    if p.alive and p.heir_rank >= 0: alive_lord_or_heirs += 1
if alive_lord_or_heirs == 0:
    GameManager.game_over("DYNASTY_END")
```

**엔딩 화면 (scenes/game_over.tscn)**: 사망 원인 표시 + 누적 통계 (총 결정 / 평균 충성도 / 최대 명성) + "메인 메뉴로" 버튼. GameManager.GAME_OVER 상태 전환 → main.gd `_process`에서 `_in_game_mode=false`로 전환.

## 결정 다이얼로그 UI (Last Banner 2차 검증 완료, 2026-07-15)

자동 진행이 사건을 만들어내도 사용자가 결정을 못 받으면 게임 진행 불가. **결정 다이얼로그 UI**가 핵심.

### 우선순위 기반 UI 분기 (class-level pattern) — 2026-07-16 v2 뒤집기

| 우선순위 | UI | 자동 skip | 효과 | 이유 |
|---|---|---|---|---|
| LOW | **모달 다이얼로그** | **3초 후 자동 "거절"** | 자동 진행 유지 | 정보성 |
| MEDIUM | **모달 다이얼로그** | 사용자 결정까지 대기 | 자동 진행 유지 | 결정 가치 있음 |
| HIGH | **모달 다이얼로그** | 사용자 결정까지 대기 | 자동 진행 일시정지 | 무시하면 큰 손실 |
| CRITICAL | **모달 다이얼로그** + 즉시 | 사용자 결정까지 대기 | 자동 진행 즉시 정지 | 안 보면 게임 망함 |

### GameWorld.apply_result() — 27+개 결과 핸들러 (v4.0.0)

v4.0.0 기준 **GameWorld.RESULT_EFFECTS dict 27종**:

| 카테고리 | 결과 코드 | 개수 |
|---|---|---|
| 방문객 | VISITOR_WELCOME / REJECT | 2 |
| 식량 | FOOD_BUY / RATION | 2 |
| 외교 | DIPLOMACY_ALLIANCE_ACCEPT / TRADE / REFUSE | 3 |
| 전투 | BATTLE_BANDITS_HIDE / BRIBE | 2 |
| 농민 | PETITION_LOWER / REJECT | 2 |
| 겨울 | WINTER_STOCKPILE / MUSTER / IGNORE | 3 |
| 상인 | MERCHANT_BUY / SEND_AWAY | 2 |
| 역병 | PLAGUE_MEDICINE / QUARANTINE / NOTHING | 3 |
| 용병 (A-1) | ACCEPT/REJECT/DISMISS_MERCENARY, PAY_BONUS, TRAINING, INJURY_HEAL, DESERTS | 7 |
| 왕조 (A-2) | BETRAYAL_CRUSHER/BANISH/FORGIVE, SUCCESSION_KEEP/SWAP/NURTURE | 6 |
| 빌딩 (A-3) | BUILD_UPGRADE / SKIP | 2 |

**전투 확률 처리**: `payload.estimated_victory` (EventEngine이 미리 계산한 승률)를 `randf()`와 비교 → 승/패 분기.

### main.tscn 통합 패턴

```ini
[node name="Main" type="Node2D"]
script = ExtResource("1_main")

[node name="UI" type="CanvasLayer" parent="."]
[node name="DecisionDialog" parent="." instance=ExtResource("2_dialog")]
visible = false
```

## 📁 첨부 파일

- `references/v4.0-buildings-and-verify-pitfalls.md` — **v4.0.0 신규**: 빌딩 시스템 (4종 × max Lv 3, base × (lvl+1) 비용 곡선) + `effect_per_level` nested dict + 일간 보너스 합산 + BUILD_CONSTRUCTION 결정 큐 + LB_VERIFY 단계별 골드 보충 패턴 + 변수명 중복 회피 + 비용 곡선 assert 함정 + GDScript 파스 에러 3종 (int2 / 닫는 괄호 / `% 포맷`) + 사용자 진행 선호 신호. (Last Banner v4.0.0 2026-07-20)
- `references/v3.3-mercenary-and-court-pattern.md` — **v3.3.0**: 9-class tier 용병 Roster (MercenaryData + GameWorld.roster + 시그널 3종 + MERCENARY_OFFER/Injury + 충성도 자동 이탈) + 4종 신규 사건 (PEASANT_PETITION/WINTER_PREPARATION/MERCHANT_CARAVAN/PLAGUE) + 왕조 court (4종 스탯 + SUCCESSION_AUDIT + HEIR_BETRAYAL) + 7가지 GDScript 파스 에러 함정. (Last Banner v3.3.0 2026-07-20)
- `references/dashboard-screen-pattern.md` — 영지 대시보드 (라인 차트 + ProgressBar + 메트릭 카드 + 업적 + 시그널 구독 자동 갱신), Control._draw() 직접 그리기 패턴, 토스트 페이드 인/아웃, 5단계 검증 절차 (Last Banner 5차 2026-07-16)
- `references/menu-game-mode-toggle.md` — 메뉴 ↔ 게임 모드 토글 패턴 (Last Banner 10차 2026-07-16)
- `references/x-close-button-overlay-pattern.md` — 모든 오버레이 화면 우상단 XButton 통일 (Last Banner 12차 2026-07-16)
- `references/tutorial-and-succession-patterns.md` — 튜토리얼 4단계 + 왕조/후계자 CK3 양식 + LB_VERIFY 헤드리스 hang 3원인 (Last Banner 7~8차 2026-07-16)
- `references/battle-visualization-pattern.md` — 전투 시각화 화면 (3단계 상태머신 + 주사위 애니메이션 + 손실 카드) + GDScript 실전 함정 3가지 (Last Banner 7단계 2026-07-16)
- `references/fetch-progress-web-export.md` — Godot 4 Web export + Vercel asset fetch 진행률 0% 멈춤 함정 3가지 (Last Banner 9차 2026-07-16)
- `references/v2-native-ui-pitfalls.md` — v2.1~v3.0 7가지 UI 반문: CanvasLayer z-order, Area2D→TextureButton, PanelContainer visibility 이중 안전망, size 변화 시 position 누적 버그, GDScript %(...) 다중 인수 미지원 ([] 배열만), LB_VERIFY stage 사이 _current_decision_id reset 누락, 빈 상태창 가시성 검출력 부족. (Last Banner v2.1~v3.0 2026-07-16)

## 검증된 세션 누적 (1~12차)

| 차수 | 검증 항목 | 핵심 발견 |
|------|-----------|----------|
| 1 | 자동 진행 + GameWorld + EventEngine + DecisionQueue | 핵심 연결 고리 작동 |
| 2 | 결정 다이얼로그 UI | HIGH/CRITICAL 자동 표시, 자원 변동 정확 |
| 3 | 용병 명단 화면 | 3-pane List-Detail, 시그널 자동 갱신 |
| 4 | 자동 진행 ON 기본값 + 토스트 | `enable_auto_progress()` + 5초 페이드 트윈 |
| 5 | 영지 대시보드 | 라인 차트 + 메트릭 카드 + 업적, ring buffer |
| 6 | 후계자/정치 시스템 | CK3 양식 4종 스탯, 분기 감사 |
| 7 | 전투 시각화 | 3단계 상태머신 + 주사위 애니메이션 |
| 8 | 사운드/배경음악 | (planned) Wesnoth music lazy fetch |
| 9 | Web export 진행률 | (planned) jsDelivr lazy fetch |
| 10 | 메뉴 ↔ 게임 모드 토글 | `MenuToggleButton` + ESC |
| 11 | 결정 큐 ON/OFF 분기 | 자동 진행 토글이 모달 동작 결정 |
| 12 | 타이틀 화면 + 재진입 | SaveManager.list_saves() + '이어하기' |

## 결정 큐 모달 — 자동 진행 ON/OFF 분기

**v2.1.0 패턴** (사용자 직접 선택, 2026-07-16):
- **자동 진행 ON**: 모든 우선순위 모달 + LOW 3초 / 그 외 5초 후 default 결정 자동 resolve
- **자동 진행 OFF**: 모든 우선순위 모달 + **무한 대기** (사용자 결정까지)

default 결정 코드 (자동 ON):
| type | condition | default | effect |
|---|---|---|---|
| `VISITOR` | always | `VISITOR_REJECT` | 명성 -2 |
| `PEASANT_PETITION` | always | `PETITION_REJECT` | 명성 -2 |
| `MERCHANT_CARAVAN` | always | `MERCHANT_SEND_AWAY` | 명성 -1 |
| `MERCENARY_OFFER` | always | `REJECT_MERCENARY` | — |
| `BUILD_CONSTRUCTION` | always | `BUILD_SKIP` | — |
| `FOOD_SHORTAGE` | food < 15 | `FOOD_BUY` | 골드 -50, 식량 +30 |
| `FOOD_SHORTAGE` | food ≥ 15 | `FOOD_RATION` | 명성 -5 |
| `DIPLOMACY` | always | `DIPLOMACY_REFUSE` | 명성 -5 |
| (other) | - | "" (빈 문자열) | 자동 거절 안 함 → 무한 대기 (안전 가드) |

## 왕조/후계자 시스템 (CK3 양식, Last Banner v3.3.0)

저판타지 정치 미학의 핵심 차별화 요소. 영주 + 후보 3명 + 신하 1명, 4종 스탯(무력/행정/외교/암약), 충성도/야망 동적 변동, 분기마다 후계자 감사, **배신 이벤트**.

### EventEngine 정치 이벤트

```gdscript
const SUCCESSION_AUDIT_INTERVAL_MIN := 4320  # 3일마다

func _maybe_succession_audit(_game_time: int) -> void:
    var heirs: Array = GameWorld.get_heirs()
    for h in heirs:
        h.loyalty = clamp(h.loyalty + randi() % 11 - 5, 0, 100)
        h.ambition = clamp(h.ambition + randi() % 7 - 3, 0, 100)
    for h in heirs:
        if h.loyalty < 25 and h.ambition > 65 and randf() > 0.5:
            _maybe_heir_betrayal(h)
            return
```

## `@onready` 평가 순서 함정 (Godot 4, 2026-07-16 발견)

`@onready var x: Label = $UI/Toast` 같은 변수는 `_ready()` 함수가 **return 하기 전**에 평가됨. 즉:

```gdscript
func _ready() -> void:
    _verify_mode = OS.has_environment("LB_VERIFY")
    if _verify_mode:
        _run_verify()
        return                       # ← 여기서 return해도 @onready는 이미 평가됨
    # 일반 모드 코드...
```

→ `@onready`로 선언된 `toast_label` 등이 검증 모드 분기 후 null 가능성 있음. 검증 코드는 **null 체크** 필수.

## 헤드리스 검증 무한 hang 함정 (2026-07-16 종합)

`await get_tree().process_frame`이 헤드리스에서 무한 hang 가능. 다음 3가지 원인이 확인됨:

1. **`SceneTree` 직접 호출 시 autoload 미등록** — `godot --script`로 SceneTree 서브클래스 직접 실행하면 main scene을 거치지 않아 autoload가 등록되지 않음. → `LB_VERIFY` 환경변수로 main.gd 분기하는 우회 패턴이 정답.
2. **시그널 인자 미스매치 ERROR로 hang** — `connect()`로 연결된 핸들러가 시그널 인자와 다르면 ERROR + 코드 흐름 중단.
3. **`process_frame` 루프 누적** — `for i in range(60): await get_tree().process_frame` 같은 패턴이 헤드리스에서 빠르게 안 끝남. → `await` 없이 동기로 처리.

**진단**: 60초 타임아웃 시 hang 위치는 stderr 마지막 줄에서 grep. 대부분 ERROR: Method expected N argument(s)가 catch 포인트.

## 📁 첨부 파일 (재정리)

- `references/v4.0-buildings-and-verify-pitfalls.md` — **v4.0.0 신규**: 빌딩 시스템 + LB_VERIFY 17단계 + GDScript 파스 에러 3종 + 사용자 진행 선호.
- `references/v3.3-mercenary-and-court-pattern.md` — **v3.3.0**: 9-class tier 용병 + 왕조 court + 4종 신규 사건 + 7가지 GDScript 파스 에러.
- `references/dashboard-screen-pattern.md` — 영지 대시보드 (5차)
- `references/menu-game-mode-toggle.md` — 메뉴 ↔ 게임 모드 토글 (10차)
- `references/x-close-button-overlay-pattern.md` — 모달 XButton 통일 (12차)
- `references/tutorial-and-succession-patterns.md` — 튜토리얼 + 왕조 (7~8차)
- `references/battle-visualization-pattern.md` — 전투 시각화 (7차)
- `references/fetch-progress-web-export.md` — Web export 진행률 (9차)
- `references/v2-native-ui-pitfalls.md` — v2.1~v3.0 7가지 UI 반문
- `references/decision-queue-on-off-auto-vs-waiting.md` — v2.1.0 자동 진행 ON/OFF 분기 UX (Last Banner 11차 2026-07-16)
- `references/buildings-system-pattern.md` — 빌딩 시스템 패턴 (Last Banner v4.0.0 2026-07-20, 본 reference의 1절과 중복 — 추후 consolidation)
- `references/audio-bgmusic-pattern.md` — 사운드/배경음악 패턴 (planned)
- **`references/godot4-ui-panel-overlap-and-tscn-patch-safety.md`** — tscn 패치 폭파 회피
- **`references/autopilot-toggle-typescript-pattern.md`** — ★ 2026-07-20 sango-rising-dragons (TypeScript/Phaser 풀 자동위임 — 5-tier 결정 큐 + localStorage 토글 + snapshot diff 로그 + 비동기 march 핸들러 + searchTalent 인라인화 + 220ms setTimeout + 사용자 결정 3가지 정책 선택). **v2 패치 (2026-07-20)**: Pitfall 32-36 추가 — `.vercelignore` 빌드 입력 차단 / 결정 큐 정책 매트릭스 (사용자 4가지 결정) / 전투 AI autopilot 확장 (BattleScene.playerAiStep) / 풀 자동위임 검증 시나리오 ("Cmd+Shift+R + 자동위임 ON + 턴 종료 한 번" → 천하 통일) / 키보드 단축키 5종 가드 패턴.