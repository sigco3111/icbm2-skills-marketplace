---
name: gh-pages-spa-deploy
description: gh-pages Vite/React SPA. vite base + sprite + cache-bust.
version: 1.0.0
author: HyeRin
license: MIT
metadata:
  hermes:
    tags: [gh-pages, vite, react, spa, deploy, sprite, static-hosting, fork]
    related_skills: [canvas-static-site-pipeline, pixijs-v8-pitfalls, github-cli]
when_to_use: >
  Vite/React SPA를 GitHub Pages 서브경로에 호스팅. sprite 다수, Twin Lab 류 fork. vite base 있음에도 sprite 404, "unpack failed", cache-bust 안 됨, 옛 sprite 봄.
category: devops
---

# GitHub Pages SPA Deploy — 4대 함정 + 검증 3-tier

Vite + React + 정적 자산(특히 sprite/PNG 다수) SPA를 **`{user}.github.io/{repo}/`** 서브경로에 호스팅. 2026-08-04 hermes-control-room Twin Lab 룩 이식 실측 기반. Vercel과 다른 gh-pages만의 함정 4가지.

**Vercel과의 차이**: Vercel = alias URL root, gh-pages = 서브경로 prefix. 단일 HTML 미션엔 gh-pages가 가장 단순.

## 1. vite `base: '/{repo}/'` 설정이 JS 내부 절대경로에 적용 안 됨 (★★★ 가장 빈번)

Vite `base`는 HTML asset 참조에만 prepend. JS 내부 절대경로 문자열 리터럴 (`"/sprites/..."`, `"/rooms/..."`)은 변환 없이 박힘.

```ts
// vite.config.ts
export default defineConfig({
  base: '/hermes-control-room/',  // ← HTML에만 적용
})

// src/theme.ts — OK
export function getSpriteDir() {
  return `${BASE_URL}sprites/office/characters`  // 런타임 동적
}

// src/assets.ts — ❌ 변환 안 됨
'char-debugger': { path: '/sprites/debugger.png' },
```

**실측 (hermes-control-room)**: 빌드 후 `/sprites/...` 84개 + `/rooms/...` 6개 박혀있음. HTML은 정상이지만 sprite 404.

**해결 — 빌드 후 sed (post-build.sh)**:

```bash
#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
JS_FILE=$(ls dist/assets/index-*.js | head -1)
[ -z "$JS_FILE" ] && { echo "no index-*.js"; exit 1; }
sed -i.bak 's|"/sprites/|"/hermes-control-room/sprites/|g' "$JS_FILE"
sed -i.bak 's|"/rooms/|"/hermes-control-room/rooms/|g' "$JS_FILE"
rm -f "$JS_FILE.bak"
```

**근본 원인**: vite는 webpack의 `publicPath`처럼 string literal을 강제 변환하지 않음. `${BASE_URL}` 템플릿은 작동하지만 정적 path 객체 안 string은 안 됨. **Webpack → vite 이전 프로젝트는 빌드 후 sed가 정석**.

**기준으로 박기**:
- 모든 sprite/room path를 한 곳에 모으고 `BASE_URL` 박기 → sed 1차만 필요
- `assets.ts`에 100+ sprite 있으면 일괄 변환 + sed fallback

## 2. cache-bust meta + 강력 새로고침 (★ 사용자 UX)

gh-pages CDN이 옛 HTML 캐시. `Cmd+R`로는 새 빌드 안 보임. **1~2분 전파 + Cmd+Shift+R 강력 새로고침** 필요.

**해결 — index.html**:

```html
<title>Hermes Control Room</title>
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
<meta http-equiv="Pragma" content="no-cache" />
<meta http-equiv="Expires" content="0" />
```

이 meta + 푸시 + 1분 전파 + 사용자 Cmd+Shift+R = 새 빌드.

**3-tier 검증 (캐시 디버깅)**:
1. `curl -sI https://{user}.github.io/{repo}/index.html` → Cache-Control 헤더
2. `curl -s https://{user}.github.io/{repo}/assets/index-*.js | md5` vs `md5 dist/assets/index-*.js` → 다르면 gh-pages 푸시 미완료
3. 사용자 "404 + 옛 sprite" → 먼저 `Cmd+Shift+R` 1회 요청

**판단 기준**: `md5 동일` + 200 + meta 있음에도 옛 path → **사용자 브라우저 캐시**. 푸시 OK, 안내만.

## 3. force push 시 `unpack failed: did not receive expected object` (★★★)

`git push ... --force` 시 `unpack failed: did not receive expected object b0bb8de7...` 보고. remote의 refs가 **로컬에 없는 객체를 가리킴**. 보통 `gh-pages-new` 임시 브랜치에서 `git rm -rf .` + force push로 발생.

**해결 — fresh-clone 패턴**:

```bash
rm -rf /tmp/fresh-clone
git clone --depth 1 https://github.com/sigco3111/{repo}.git /tmp/fresh-clone
cd /tmp/fresh-clone
git checkout main
cp -R {우리 repo}/src/* .
cp {우리 repo}/package.json {vite.config.ts} .
git add -A && git commit -m "feat: ..."
git push -u origin main --force

git checkout gh-pages
git rm -rf .
cp -r {우리 repo}/dist/. .
touch .nojekyll
git add -A && git commit -m "deploy: ..."
git push -u origin gh-pages --force
```

**왜 fresh-clone**: force push는 로컬 refs를 remote에 강제 덮어쓰기. corrupt 객체 가리키기 시 unpack failed. fresh-clone은 remote 현재 상태 그대로 → corrupt 객체 가리키기 현상 없음. 단, unstaged 변경 안 가져옴 → `cp -R` 명시적 복사.

**흔한 시나리오** (hermes-control-room 실측):
1. 위임 `git remote set-url` 안 함 → W17ant/Claude-Office로 push → 403
2. remote set-url로 sigco3111 교정 → `b0bb8de7` 부재 → unpack failed
3. fresh-clone 패턴으로 우회

**판단 기준**:
- `unpack failed` / `did not receive expected object` → **fresh-clone 패턴**
- `403 Permission denied` → remote URL 확인 + `git remote set-url`
- `non-fast-forward` → fetch + rebase, 또는 `force-with-lease`

## 4. gh-pages workflow 자동화 (Actions workflow)

```yaml
# .github/workflows/deploy.yml
name: Deploy {Repo}
on:
  push:
    branches: [main]
  workflow_dispatch:

permissions:
  contents: write

jobs:
  build-and-deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: 20, cache: npm }
      - run: npm ci
      - run: npm run build
      - run: bash post-build.sh
      - name: Copy state.json into dist
        run: |
          [ -f public/state.json ] && cp public/state.json dist/state.json
      - name: Deploy to GitHub Pages
        uses: peaceiris/actions-gh-pages@v4
        with:
          github_token: ${{ secrets.GITHUB_TOKEN }}
          publish_dir: ./dist
          force_orphan: true
          keep_files: false
```

**핵심**: `bash post-build.sh`가 `npm run build` 직후 실행 → sed 자동화. 다음 푸시부터 수동 sed 불필요.

## 5. cold-start 5단계 (gh-pages 단일 HTML 미션 권장)

```bash
PROJECT="{project-name}"

mkdir -p /Users/mac/work/$PROJECT && cd /Users/mac/work/$PROJECT
git init -b main
git remote add origin "https://github.com/sigco3111/$PROJECT.git"

gh repo create "sigco3111/$PROJECT" --public --description "{한 줄}"

# 자산 + post-build.sh + workflow + cache-bust meta작성

git add -A
git commit -m "feat: ${PROJECT} bootstrap"
git push -u origin main

sleep 30
curl -sS -o /dev/null -w "HTTP %{http_code} | %{size_download}B\n" \
  "https://sigco3111.github.io/$PROJECT/"
```

## Vercel vs gh-pages

| | Vercel | gh-pages |
|---|---|---|
| URL | alias (root) | 서브경로 |
| cron | 6시간 | Actions only |
| 무료 | ✓ | ✓ |
| 단일 HTML | alias 점유 패턴 추적 | **가장 단순** |
| Sprite 100+ | 빌드 후 sed 필요 | 빌드 후 sed 필요 |

**판단 기준**:
- 단일 HTML + sprite 다수 + 간단한 SPA → **gh-pages** (이 스킬)
- OAuth/external API + 안전 가드 + TDD → Vercel + Next.js (`canvas-static-site-pipeline` 변형 4)
- 둘 다 → Vercel alias + Pages 백업

## 체크리스트 (deploy 전)

- [ ] `vite.config.ts`에 `base: '/{repo}/'` 박힘
- [ ] 모든 sprite/room path에 `${BASE_URL}` 또는 명시적 prefix
- [ ] `post-build.sh` 빌드 후 sed (또는 Actions workflow)
- [ ] `index.html` `Cache-Control: no-cache` 메타
- [ ] `.nojekyll` dist/ 루트
- [ ] GitHub Pages REST API 활성화
- [ ] 첫 빌드 30~60초 대기 후 `curl` 검증
- [ ] 사용자 강력 새로고침 안내 (Cmd+Shift+R)
- [ ] `md5` 비교 (로컬 vs 라이브) — 푸시 직후 1회

## 금지 사항

- 절대경로 sprite URL 박고 `post-build.sh` sed 안 돌리기 — vite base 안 잡음
- `git push` 시 remote URL 미확인 — 403 / unpack failed
- cache-bust meta 없이 푸시 — 사용자 옛 버전 봄
- 일반 새로고침만 권장 — 강력 새로고침 (Cmd+Shift+R) 안내
- `force push` 일반 repo에 사용 — fresh-clone 패턴 우선

## 6. PIT: `${BASE_URL}` template literal을 import 없이 사용 → 런타임 `ReferenceError: BASE_URL is not defined` (★★★)

빌드는 통과 (esbuild는 `import.meta.env.BASE_URL`을 tree-shake로 정규화), **런타임에 ReferenceError**로 화면이 검정 + console에 `BASE_URL is not defined at line:XXXXX`. CSS는 정상 로드되지만 JS 실행이 멈춰서 sprite/캐릭터/사이드 패널 안 보임.

**증상 패턴** (hermes-control-room 실측):
- 콘솔: `Uncaught ReferenceError: BASE_URL is not defined at index-XXX.js:73343`
- 화면: 검은 배경 + 헤더는 안 보일 수 있음 (React 마운트 실패)
- HTTP 상태: sprite 다 200 (캐시/CDN 아님)
- `BASE_URL 식별자`가 빌드된 JS에 박혀 있으나 `import.meta.env.BASE_URL`로 변환 안 됨

**체크 (수동 5초)**:
```bash
# BASE_URL을 사용하지만 import 안 한 .ts 파일 찾기
for f in $(grep -l '${BASE_URL}' src/**/*.ts src/**/*.tsx 2>/dev/null); do
  if ! grep -q "from '.*baseUrl'" "$f"; then
    echo "MISSING IMPORT: $f"
  fi
done
```

**자동 검사** (SKILL 트리거 시 권장):
```bash
for f in $(find src -name '*.ts' -o -name '*.tsx' | xargs grep -l 'BASE_URL' 2>/dev/null); do
  if ! grep -q "from '.*baseUrl'" "$f"; then
    echo "❌ $f uses BASE_URL but doesn't import it"
  fi
done
```

**해결**: theme.ts 같은 누락 파일에 `import { BASE_URL } from './baseUrl'` 한 줄 추가. **빌드는 통과해도 런타임에 깨지므로** CI 단계에 `tsc --noEmit`만으론 잡히지 않음 — 반드시 **dev server 브라우저 콘솔 + Playwright** 로 런타임 검증.

**왜 `tsc`가 못 잡나**: `BASE_URL`은 template literal 안 식별자 → TypeScript는 dynamic value로 추론 → import 없어도 any로 통과. esbuild tree-shake 후 runtime에 ReferenceError 던짐.

## 7. cache-bust `?v=` 박을 때 CSS hash mismatch 함정

JS만 `?v=20260804` 박고 CSS는 안 박으면, 빌드마다 CSS hash가 바뀌므로 옛 hash가 박힌 index.html이 가리키는 CSS가 404.

**해결**: cache-bust 추가할 때 JS + CSS 둘 다 동시에:
```bash
JS_HASH=$(ls dist/assets/index-*.js | grep -oP 'index-\K[A-Za-z0-9_-+]+')
CSS_HASH=$(ls dist/assets/index-*.css | grep -oP 'index-\K[A-Za-z0-9_-+]+')
sed -i "s|index-[A-Za-z0-9_-+]\.js?v=.*|index-${JS_HASH}.js?v=$(date +%Y%m%d)|" dist/index.html
sed -i "s|index-[A-Za-z0-9_-+]\.css?v=.*|index-${CSS_HASH}.css?v=$(date +%Y%m%d)|" dist/index.html
```

**또는 더 단순** — 매번 cache-bust 버전을 `date +%s` (Unix epoch)로 → 캐시 항상 무효. 단 사용자 URL에 timestamp 박히니 비추천. **하루 단위**가 합리적.

**판단 기준**:
- Playwright fresh context에서 1개 404 → CSS hash mismatch 가능성
- `md5 dist/assets/index-*.css` vs 라이브 md5 → 다르면 옛 CSS

## 강화된 deploy 전 체크리스트 (이 skill의 5/6/7절 반영)

- [ ] `vite.config.ts`에 `base: '/{repo}/'` 박힘
- [ ] **`grep "from '.*baseUrl'" src/**/*.ts | xargs grep -L '${BASE_URL}'` → BASE_URL 사용 + import 누락 파일 0개**
- [ ] 모든 sprite/room path에 `${BASE_URL}` 또는 명시적 prefix
- [ ] `post-build.sh` 빌드 후 sed (또는 Actions workflow)
- [ ] **JS + CSS hash 둘 다** index.html에 동기화 (cache-bust)
- [ ] `index.html` `Cache-Control: no-cache` 메타
- [ ] `.nojekyll` dist/ 루트
- [ ] GitHub Pages REST API 활성화
- [ ] 첫 빌드 30~60초 대기 후 `curl` 검증
- [ ] Playwright fresh context 404 count 확인 (0 또는 5 미만)
- [ ] **dev server 브라우저 콘솔 + Playwright** 런타임 검증 (BASE_URL ReferenceError 확인)
- [ ] 사용자 강력 새로고침 안내 (Cmd+Shift+R)
- [ ] `md5` 비교 (로컬 vs 라이브) — 푸시 직후 1회

## 통합 디버깅 사이클 (5+회 반복 실측 패턴)

이번 hermes-control-room 세션에서 5+회 같은 디버깅 사이클 반복됨:

```
[검은화면 / sprite 깨짐 보고]
       ↓
Playwright fresh context로 404 카운트
       ↓
원인 분류:
  (a) 절대경로 sprite URL → sed 해결
  (b) BASE_URL import 누락 → import 한 줄 추가
  (c) CSS hash mismatch → sed로 JS+CSS 둘 다
  (d) gh-pages 푸시 미완 → fresh-clone + force push
  (e) 사용자 브라우저 캐시 → Cmd+Shift+R 안내
       ↓
해결 + 빌드 + main push + gh-pages push + 1~2분 전파 + 검증
```

**자동 진단 명령 (5초)**:
```bash
# 1. 라이브에서 sprite 200 OK 확인
curl -s -o /dev/null -w "%{http_code}" "https://{user}.github.io/{repo}/sprites/{sample}.png"
# 2. 라이브 JS md5 vs 로컬 dist
curl -s "https://{user}.github.io/{repo}/assets/$(ls dist/assets/index-*.js | xargs basename)" | md5
md5 dist/assets/index-*.js
# 3. JS에 BASE_URL ReferenceError 가능성 (NODE_ENV=production 빌드만)
curl -s "https://{user}.github.io/{repo}/assets/index-*.js" | grep -c "BASE_URL" 
# 4. CSS hash 동기화
grep "index-.*\.css" dist/index.html | head -1
ls dist/assets/index-*.css
```

세 가지 (1)/(2)/(3)/(4) 모두 통과해야 사용자 Cmd+Shift+R 한 번에 해결.
