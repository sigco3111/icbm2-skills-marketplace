# Hermes Control Room — Twin Lab 톤 디자인 + 1개 룸 + 8개 부서 패턴

> 2026-08-04 hermes-control-room Twin Lab 룩 이식 5+ 세션 실측. W17ant/Claude-Office fork + Hermes 8부서 매핑. **1개 큰 룸 (Dunder Mifflin) 유지 + 8개 부서 chip 헤더 + 사이드 패널 + 하단 티커**가 사용자 결정 디자인.

## 1. 사용자 확정 결정 (히스토리)

| 라운드 | 사용자 결정 | 결과 |
|---|---|---|
| 1 | Twin Lab 룩 이식 (다크 네이비 헤더 + 부서 chip + 사이드 패널 + 하단 티커) | LabHeader/LabSidePanel/LabTicker 컴포넌트 + office.css Twin Lab 톤 |
| 2 | "방이 하나만 나오고 비율도 이상함" → 8개 부서 룸 분리 시도 | 위임이 RoomView/RoomSidebar 만들었지만 사용자 후속 결정으로 무효 |
| 3 | **"룸을 분리하지말고 룸은 하나에 부서만 8개로 해줘"** | RoomSidebar/RoomView 삭제, 1개 큰 룸 + 부서 chip 8개로 충분 |
| 4 | 검은 룸 비율 문제 → CSS 비례 해결 (`.app-body` 중복 정의) | 정상 |
| 5 | **"룸 분리하기 전 소스로 돌려놓으라고 했는데, 여전히 룸은 8개고, 한글화된 상태야"** | Twin Lab *전* 시점으로 reset (`a08abdd`) — 영문 디자인, 부서 chip 없음 |

**결론**: 1개 큰 룸 + 한글화/8부서 chip/Twin Lab 톤은 사용자가 만족한 디자인이지만 **빌드 + 푸시 과정에서 사이드이펙트 (CSS 비례 깨짐, 캐시, gh-pages 강제 푸시 손실) 발생**. **이 패턴이 안전하게 작동하려면 §2-5의 함정 모두 회피 필수**.

## 2. CSS cascade conflict (★★★ 가장 빈번한 "검은 룸" 원인)

### 증상

- 룸이 화면 가운데에 **검은 정사각형**으로 작게 표시
- 헤더/사이드/티커는 정상
- sprite 다 200 OK
- `BASE_URL is not defined` 같은 JS 에러 없음
- 사용자가 강력 새로고침해도 변화 없음 (이건 보통 캐시)

### 원인

CSS에 **`.app-body` 정의가 2개** (line 169 + 454) — Twin Lab 톤 추가 시 옛 Claude-Office `.app-body` 정의를 안 지웠을 때 발생.

```css
/* line 169 — Twin Lab 톤 (정상) */
.app-body {
  flex: 1;
  display: flex;
  flex-direction: row;
  min-height: 0;
  position: relative;  /* ★ 이게 있어야 자식 absolute가 부모 인식 */
}

/* line 454 — 옛 Claude-Office (Twin Lab 추가 전 잔재) */
.app-body {
  flex: 1;
  display: flex;
  flex-direction: row;
  min-height: 0;
  /* position: relative 없음 ❌ */
}
```

CSS cascade 우선순위: **두 정의 모두 specificity 동일 → 뒤에 박힌 line 454가 이김**. `position: relative` 사라짐 → 자식 `.room-container`의 `position: absolute`가 부모 인식 못 함 → 룸 콘텐츠가 viewport에 안 보임.

### 진단 (3초)

```bash
# .app-body 정의 카운트
grep -c "^\.app-body {" src/styles/office.css
# → 2 이상이면 ❌
```

### 해결

**옛 Claude-Office CSS 제거 (line 454 이후) — Twin Lab 톤만 유지**:

```bash
# 우리 프로젝트 hermes-control-room 기준
sed -n '1,453p' src/styles/office.css > /tmp/office.css.clean
mv /tmp/office.css.clean src/styles/office.css
wc -l src/styles/office.css  # 1642 → 453 lines
```

### Twin Lab 톤 `.app-body` 정형 (★ 향후 모든 fork에 적용)

```css
.app-body {
  flex: 1;
  display: flex;
  flex-direction: row;
  min-height: 0;
  position: relative;  /* ★ 필수 */
}

.office-view {
  flex: 1;
  position: relative;
  min-width: auto;  /* ★ 0 안 되게 */
  min-height: 0;
  overflow: hidden;
}

.room-container {
  position: absolute;
  inset: 0;  /* top/right/bottom/left: 0 */
  width: 100%;
  height: 100%;
}
```

## 3. Twin Lab 톤 디자인 토큰 (★ 디자인 시스템)

이 패턴은 W17ant/Twin Lab (`twin.quantlabnote.com/guest`) 의 룩에서 차용. 다크 네이비 + glassmorphism + 60s linear ticker.

### 3-1. CSS 변수 (office.css 상단)

```css
:root {
  /* Twin Lab 다크 네이비 팔레트 */
  --lab-navy-0: #0d0d12;
  --lab-navy-1: #15121d;
  --lab-navy-2: #1a1f2e;
  --lab-navy-3: #252a3a;
  --lab-accent: #00d4ff;     /* 시안 액센트 */
  --lab-cyan: #4dd0e1;
  --lab-cream: #f5f9f7;      /* 사이드 패널 glassmorphism */
  --lab-border-soft: rgba(245, 249, 247, 0.16);
  --lab-amber: #ffb84a;
  --lab-rose: #ff6b8a;
  --lab-green: #5dd39e;
}
```

### 3-2. 헤더 (LabHeader)

```css
.lab-header {
  height: 64px;
  background: linear-gradient(180deg, var(--lab-navy-0), var(--lab-navy-2));
  border-bottom: 1px solid var(--lab-border-soft);
  display: flex;
  align-items: center;
  padding: 0 16px;
  gap: 16px;
  flex-shrink: 0;
}

.lab-header-title {
  font-family: 'JetBrains Mono', monospace;
  font-size: 13px;
  color: var(--lab-accent);
  letter-spacing: 1.5px;
}

.lab-header-clock {
  font-family: 'JetBrains Mono', monospace;
  font-size: 14px;
  color: var(--lab-cream);
  margin-left: auto;
}

.lab-metrics {
  display: flex;
  gap: 16px;
  font-family: 'JetBrains Mono', monospace;
  font-size: 11px;
}

.lab-metric {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  color: var(--lab-cream);
}

.lab-metric-label {
  color: rgba(255, 255, 255, 0.5);
  font-size: 9px;
  letter-spacing: 1px;
  text-transform: uppercase;
}

.lab-metric-value {
  color: var(--lab-accent);
  font-weight: 600;
}

.lab-room-chip {
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 4px 10px;
  border-radius: 4px;
  background: var(--lab-navy-3);
  border: 1px solid var(--lab-border-soft);
  font-size: 11px;
  color: var(--lab-cream);
  cursor: pointer;
  transition: all 0.15s ease;
}

.lab-room-chip:hover {
  border-color: var(--lab-accent);
  background: rgba(0, 212, 255, 0.08);
}

.lab-room-chip.active {
  background: rgba(0, 212, 255, 0.16);
  border-color: var(--lab-accent);
  color: var(--lab-accent);
}
```

### 3-3. 사이드 패널 (LabSidePanel) — glassmorphism

```css
.lab-side-panel {
  width: 280px;
  background: var(--lab-cream);
  backdrop-filter: blur(14px) saturate(160%);
  -webkit-backdrop-filter: blur(14px) saturate(160%);
  border-left: 1px solid var(--lab-border-soft);
  display: flex;
  flex-direction: column;
  flex-shrink: 0;
  z-index: 20;
  box-shadow: -4px 0 18px rgba(13, 13, 18, 0.18);
  color: var(--lab-navy-2);
  font-family: 'JetBrains Mono', monospace;
}

.lab-side-panel-header {
  padding: 12px 14px 10px;
  border-bottom: 1px solid rgba(26, 31, 46, 0.08);
  background: rgba(255, 255, 255, 0.5);
}

.lab-side-panel-title {
  font-size: 11px;
  letter-spacing: 1.5px;
  text-transform: uppercase;
  color: var(--lab-navy-2);
  font-weight: 600;
}

.lab-side-panel-content {
  padding: 12px 14px;
  flex: 1;
  overflow-y: auto;
}

.lab-side-panel-row {
  display: flex;
  justify-content: space-between;
  padding: 6px 0;
  font-size: 11px;
  border-bottom: 1px solid rgba(26, 31, 46, 0.06);
}

.lab-side-panel-label {
  color: rgba(26, 31, 46, 0.5);
}

.lab-side-panel-value {
  color: var(--lab-navy-2);
  font-weight: 500;
}
```

### 3-4. 하단 티커 (LabTicker) — 60s linear 흐름

```css
.lab-ticker {
  height: 32px;
  background: var(--lab-navy-0);
  border-top: 1px solid var(--lab-border-soft);
  display: flex;
  align-items: center;
  overflow: hidden;
  position: relative;
  flex-shrink: 0;
}

.lab-ticker-content {
  display: flex;
  gap: 32px;
  white-space: nowrap;
  animation: lab-ticker-scroll 60s linear infinite;
  padding-left: 100%;
  font-family: 'JetBrains Mono', monospace;
  font-size: 11px;
  color: var(--lab-cream);
}

.lab-ticker-item {
  display: flex;
  align-items: center;
  gap: 6px;
}

.lab-ticker-item .emoji {
  font-size: 12px;
}

@keyframes lab-ticker-scroll {
  0% { transform: translateX(0); }
  100% { transform: translateX(-100%); }
}

.lab-ticker:hover .lab-ticker-content {
  animation-play-state: paused;
}
```

### 3-5. JSX 구조 (App.tsx)

```tsx
<div className="app-wrapper">
  <LabHeader
    metrics={metrics}                              // { activeCrons, memoryUsed, memoryCap, tistoryToday, sessionCount }
    selectedRoomId={selectedRoomId}
    onSelectRoom={(id) => setSelectedRoomId(id === selectedRoomId ? null : id)}
  />

  <div className="app-body">
    <div className="office-view">
      {/* 1개 큰 룸 (MAIN_ROOM = ROOMS['main-office']) */}
      <div className="room-container">
        <div className="room-background" style={{ backgroundImage: `url(${getRoomImage('day')})` }} />
        <div className="room-background room-background-night" style={{ backgroundImage: `url(${getRoomImage('night')})` }} />
        <FurnitureRenderer items={MAIN_ROOM.furniture} onItemClick={handleFurnitureClick} />
        {agents.map(agent => <Character key={agent.id} {...agent} />)}
      </div>
    </div>
  </div>

  <LabTicker />

  <LabSidePanel
    selectedRoomId={selectedRoomId as HermesRoomId}
    onClose={() => setSelectedRoomId(null)}
  />

  <SlackChat {...chatProps} />
</div>
```

## 4. Hermes 8부서 매핑 (★ 컨텐츠 패턴)

| 부서 | emoji | 영문 ID | 룸 ID (rooms.ts) | 설명 |
|------|-------|---------|---------|------|
| Tistory 발행 | 📝 | `tistory` | `main-office` | 자동 발행 파이프라인 |
| 모닝 브리핑 | 🌅 | `briefing` | `meeting-room` | 매일 아침 통합 인사이트 |
| 자동화 정비 | ⚙️ | `automation` | `server-room` | nightly maintenance |
| 리서치/트렌드 | 🔍 | `research` | `ceo-office` | 기술 트렌드 수집 |
| Notion 동기화 | 📓 | `notion` | `manager-office` | Notion DB 자동 sync |
| 투자/트레이딩 | 📈 | `trading` | `lobby` | Yahoo Finance 추적 |
| 미디어/영상 | 🎬 | `media` | `kitchen` | Manim/뮤직비디오 |
| DevOps | 🔧 | `devops` | `nap-room` | cron 헬스체크 |

**중요**: 이 매핑은 **헤더 chip → 사이드 패널 트리거** 용도. 부서 chip 클릭 시 룸 안 바뀌고 사이드 패널만 열림. **`1개 큰 룸 (main-office) 유지`가 사용자 결정** — 룸 분리 안 함.

### hermesRooms.ts (★ 부서 정의 정형)

```ts
// src/hermesRooms.ts
export type HermesRoomId = 'tistory' | 'briefing' | 'automation' | 'research' | 'notion' | 'trading' | 'media' | 'devops'

export interface HermesRoom {
  id: HermesRoomId
  emoji: string
  name: string  // 한글 부서명
  status: 'active' | 'idle' | 'waiting' | 'inactive' | 'error'
  lastRun: string  // ISO 8601
  nextRun: string  // 표시용 (예: "5분 이내", "내일 08:30")
  scripts: string[]  // cron skill IDs
}

export const HERMES_ROOMS: Record<HermesRoomId, HermesRoom> = {
  tistory: {
    id: 'tistory', emoji: '📝', name: 'Tistory 발행',
    status: 'active', lastRun: '2026-08-04T17:25:00.000Z', nextRun: '5분 이내',
    scripts: ['b1bca63a117a', '0b0e9f44e10a', 'b21d94a14860']
  },
  briefing: {
    id: 'briefing', emoji: '🌅', name: '모닝 브리핑',
    status: 'idle', lastRun: '2026-08-04T08:30:00.000Z', nextRun: '내일 08:30',
    scripts: ['075bec58df7b', '582ecc59aaee']
  },
  // ... 6개 더
}

export function formatTimeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime()
  const min = Math.floor(diff / 60000)
  if (min < 1) return '방금'
  if (min < 60) return `${min}분 전`
  const hour = Math.floor(min / 60)
  if (hour < 24) return `${hour}시간 전`
  return `${Math.floor(hour / 24)}일 전`
}

export function formatTimeUntil(nextRun: string): string {
  if (nextRun.includes('이내') || nextRun.includes('내일') || nextRun.startsWith('내일')) {
    return nextRun  // 미리 포맷된 표현 그대로 반환
  }
  return nextRun
}
```

## 5. main.tsx — fork에서 React 18 진입점 누락 함정 (★★★)

W17ant/Claude-Office fork + 본인 커스터마이즈에서 **dd5e521 이전 커밋엔 `src/main.tsx`가 없음**. 빌드 시 "no entry point" 에러:

```
error during build: rollup-plugin-... could not resolve "./main"
```

### 해결 (★ 향후 모든 fork에 적용)

```tsx
// src/main.tsx
import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import App from './App'

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
)
```

**진단 (3초)**:
```bash
ls src/main.tsx 2>/dev/null || echo "❌ main.tsx missing"
```

**vite.config.ts 검증**:
```ts
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'  // ★ import 확인

export default defineConfig({
  plugins: [react()],
  base: '/hermes-control-room/',
})
```

**index.html `<div id="root">` 확인**:
```html
<body>
  <div id="root"></div>
  <script type="module" src="/src/main.tsx"></script>
</body>
```

## 6. "룸 분리 전" 롤백 시 정확히 어느 커밋으로 (★ workflow lesson)

사용자가 **"룸 분리하기 전 소스로"** 같은 롤백을 요청할 때, **Twin Lab 도입 전 정확한 커밋** 식별이 핵심. **추측으로 "옛 거 같다" 커밋 reset하면 사용자 만족도 못 맞춤**.

### 진단 절차 (5분)

```bash
# 1) 우리 repo의 reflog + 모든 브랜치의 커밋 timeline
git -C /Users/mac/work/hermes-control-room log --all --oneline --reflog

# 2) "Twin Lab 도입" 커밋 식별 — 보통 메시지에 "Twin Lab" 포함
git -C /Users/mac/work/hermes-control-room log --all --oneline | grep -i "twin"

# 3) "Twin Lab 도입" 직전 커밋 = "Twin Lab 전"
# hermes-control-room 실측:
#   dd5e521 feat: Twin Lab tone header/side/ticker + Actions sed + data fetch  ← 도입
#   72d8c7c fix: theme.ts cat sprite BASE_URL + state.json                       ← 직전
#   a08abdd fix: BASE_URL sprite path 일관성                                       ← 안정 base
# → reset target: a08abdd (Twin Lab 도입 전 + 한글 헤더 추가 전 + 부서 chip 없음)
```

### 안전 reset 패턴

```bash
# 우리 repo의 모든 변경 stash (안전)
git -C /Users/mac/work/hermes-control-room stash push -m "pre-rollback state" -u

# 특정 커밋으로 reset
git -C /Users/mac/work/hermes-control-room reset --hard a08abdd

# main push (force — diverged 가능)
git -C /Users/mac/work/hermes-control-room push -u origin main --force
# → ⚠️ unpack failed: did not receive expected object b0bb8de7 발생 시
# → fresh-clone 패턴 (§gh-pages-spa-deploy §3 참조)

# gh-pages 푸시
# gh-pages 푸시는 dist 빌드 후 /tmp/fresh-clone에 복사 + force push
```

### fresh-clone으로 unpack failed 우회

```bash
rm -rf /tmp/fresh-clone-rollback
git clone https://github.com/sigco3111/hermes-control-room.git /tmp/fresh-clone-rollback
cd /tmp/fresh-clone-rollback
git checkout --orphan gh-pages
git rm -rf .
cp -r /Users/mac/work/hermes-control-room/dist/. .
touch .nojekyll
git add -A
git commit -m "deploy: a08abdd (Twin Lab 전 — Claude-Office 원본)"
git push -u origin gh-pages --force
```

## 7. 옛 커밋의 source 추출 패턴 (★ recovery technique)

`a08abdd`처럼 옛 커밋에서 source를 가져와 **새 작업물에 재사용**해야 할 때 (HANDOFF.md 작성, 다른 fork와 비교 등).

### git show로 한 파일씩

```bash
git -C /Users/mac/work/hermes-control-room show a08abdd:src/App.tsx
```

### 디렉토리 트리 전체 추출

```bash
# 1) 디렉토리 트리만
git -C /Users/mac/work/hermes-control-room ls-tree -r --name-only a08abdd:src

# 2) public/ 같은 폴더 전체 tar
git -C /Users/mac/work/hermes-control-room show a08abdd:public | tar -x

# 3) 각 파일을 /tmp/{commit}_src/ 에 복사
mkdir -p /tmp/dd5e521_src
for f in $(git -C /Users/mac/work/hermes-control-room ls-tree -r --name-only dd5e521:src); do
  mkdir -p "/tmp/dd5e521_src/$(dirname $f)"
  git -C /Users/mac/work/hermes-control-room show "dd5e521:$f" > "/tmp/dd5e521_src/$f"
done

# 4) 우리 repo에 적용
cp -r /tmp/dd5e521_src/src /Users/mac/work/hermes-control-room/
```

**자주 빠지는 함정**:
- `tsconfig.app.json`, `tsconfig.node.json` 등이 옛 커밋엔 없음 (단일 tsconfig.json) → 빌드 시 분할 설정 누락 에러
- `src/main.tsx` 누락 (★ §5 참조)
- `vite.config.ts`에 `@vitejs/plugin-react` import 누락 → esbuild 오류

## 8. HANDOFF.md 7섹션 정형 (★ 다른 에이전트 인계)

세션이 끝나고 다른 PC/다른 에이전트가 이어받을 때, **`HANDOFF.md` 또는 `AGENTS.md` 1개 파일**로 압축. 30~50KB 적정.

### 7섹션 표준 구조

```markdown
# {프로젝트명} — 핸드오프 문서

> 새 세션 / 다른 에이전트 인계용. **다음 작업: {한 줄}**.

## 1. 한 줄 요약
{무엇을 만들었고, 다음 작업이 무엇인지}

## 2. 저장소 상태
| 항목 | 값 |
|------|-----|
| 위치 | `/Users/mac/work/{name}/` |
| 현재 main HEAD | {commit} |
| origin main | {commit} ({설명}) |
| gh-pages HEAD (라이브) | {commit} |
| 라이브 URL | {url} |
| dev 서버 | {port} |
| 빌드 | {size} |
| Playwright | {200 N + 404 N} |

### Git reflog (시간순)
```
{주요 커밋 timeline}
```

## 3. 완료된 작업 (현재 시점)
- ✅ {done 1}
- ✅ {done 2}

## 4. 다음 작업 — {제목}

### 4-1. 핵심 결정 (사용자 확정)
- {decision 1}
- {decision 2}

### 4-2. 작업 단계
1. **{step title}**:
   - 위치: `{path}`
   - {details}
2. {next step}

### 4-3. 빌드 + 푸시 패턴
```bash
{복붙 가능 명령어}
```

## 5. 알려진 함정 (회피 패턴)
| 함정 | 회피 |
|------|------|
| {trap 1} | {fix} |

## 6. 핵심 결정 (다음 세션 참고)
1. {decision 1}
2. {decision 2}

## 7. 성공 지표
- ✅ {success 1}
- ✅ {success 2}
```

### 안티패턴
- ❌ 링크만 박기 (다른 에이전트가 클릭해서 읽기 부담)
- ❌ 결정 근거 누락 ("왜 Twin Lab 톤?" 같은 why)
- ❌ 너무 광범위 (수 MB 로그 / 200 파일 diff)
- ❌ 너무 짧음 (다음 작업 1줄만)

## 9. dev 서버 + Playwright 검증 (★ hand-off 직전 확인)

```bash
# dev 서버 살아있는지
curl -s -o /dev/null -w "HTTP %{http_code}\n" http://localhost:5182/

# Playwright fresh context
const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({ args: ['--no-cache', '--disable-cache'] });
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 } });
  const page = await ctx.newPage();
  const fails = [];
  const statuses = {};
  page.on('response', r => {
    statuses[r.status()] = (statuses[r.status()] || 0) + 1;
    if (r.status() >= 400) fails.push(r.status() + ' ' + r.url());
  });
  await page.goto('https://sigco3111.github.io/hermes-control-room/', { waitUntil: 'load', timeout: 30000 });
  await page.waitForTimeout(8000);
  console.log('STATUS counts:', JSON.stringify(statuses));
  console.log('FAIL count:', fails.length);
  fails.slice(0, 10).forEach(f => console.log('  ', f));
  await page.screenshot({ path: '/Users/mac/work/hermes-control-room/.verify/phase3/live.png' });
  await browser.close();
})();
```

**PASS 기준**:
- STATUS counts 200 ≥ 60
- FAIL count 0~5 (cat sprite 1~2개는 영향 미미)
- screenshot 100KB+ (검은 화면이면 50KB 이하로 작음)

## 10. 결함 추적 + HANDOFF.md 작성 워크플로우 (5단계)

세션이 마무리 단계일 때 (사용자가 "다른 세션에서 다른 에이전트에게 작업 진행시키겠어. 리드미 갱신하고 핸드오프문서를 만들어줘"):

```bash
# 1) 우리 repo 상태 확인
git -C /Users/mac/work/hermes-control-room log --oneline -5
git -C /Users/mac/work/hermes-control-room status --short

# 2) README.md 갱신
# - 트러블슈팅 / 함정 섹션 (env 검증, anchor 깨짐, .app-body 중복, main.tsx 누락)
# - 빌드 / 배포 패턴
# - 라이브 URL 명시

# 3) HANDOFF.md 작성 (§8 7섹션)
# - 한 줄 요약 + 저장소 상태 + 완료 작업 + 다음 작업 + 함정 + 결정 + 성공 지표
# - 한국어로 작성 (사용자 한국어 소통 시)

# 4) main push
# ⚠️ 우리 repo에 main push가 unpack failed로 실패할 수 있음 (diverged origin main)
# → fresh-clone 패턴 (§6) 사용
rm -rf /tmp/fresh-clone-handoff
git clone https://github.com/sigco3111/hermes-control-room.git /tmp/fresh-clone-handoff
cd /tmp/fresh-clone-handoff
git checkout main
# src/ + public/ + config + README.md + HANDOFF.md 강제 복사
rm -rf src public
cp -r /Users/mac/work/hermes-control-room/{src,public,post-build.sh,package.json,package-lock.json,tsconfig.json,tsconfig.app.json,tsconfig.node.json,vite.config.ts,index.html,README.md,HANDOFF.md} .
git add -A
git commit -m "docs: README 갱신 (Hermes Control Room) + HANDOFF.md (8부서 작업 지시)"
git push -u origin main --force  # force — origin이 dbc0cd5 Initial commit인 경우

# 5) 검증
gh api repos/sigco3111/hermes-control-room/commits?sha=main --jq '.[0:2] | .[] | "\(.sha[0:7]) \(.commit.message)"'
gh api repos/sigco3111/hermes-control-room/commits?sha=gh-pages --jq '.[0:2] | .[] | "\(.sha[0:7]) \(.commit.message)"'
```

## 11. 헷갈리기 쉬운 함정 6종 (★ 본 세션 실측)

| 함정 | 증상 | 해결 |
|------|------|------|
| CSS `.app-body` 중복 정의 (line 169 + 454) | 룸이 검은 정사각형으로 작게 표시 | 옛 Claude-Office CSS 제거 (line 454 이후) |
| `src/main.tsx` 누락 (fork) | "could not resolve ./main" 빌드 에러 | React 18 + createRoot + <App /> 별도 추가 |
| `getAngelaCat` / `getRoomImage`가 `${BASE_URL}` 사용하지만 import 누락 | `BASE_URL is not defined` ReferenceError (런타임) | `theme.ts`에 `import { BASE_URL } from './baseUrl'` 추가 |
| `git push main --force` → `unpack failed: did not receive expected object` | 우리 repo에 main push 안 됨 | fresh-clone + force push 패턴 |
| `gh-pages --force`로 옛 dist 사라짐 | "어제 시점 라이브 복원" 요청 시 git history에 없음 | `git show <옛 커밋>:path` + 우리 repo에 source 추출 → 새 빌드 + 푸시 |
| 사용자가 "옛 거로" / "롤백" 요청 시 **어느 시점**인지 추측 | 사용자 만족 못 맞춤 | `git reflog` + `git log --all` + `grep -i "twin"`로 정확한 커밋 식별 |
