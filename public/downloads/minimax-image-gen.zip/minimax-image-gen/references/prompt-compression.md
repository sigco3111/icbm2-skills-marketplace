# 미니맥스 image-01 프롬프트 1500자 압축 레시피

## 한도 (2026-07-05 실측)
- **정확한 한도:** `prompt length must be less than 1500` → **1490자 이내 권장**
- 1500자 정확히도 거부됨. 안전 마진 10자.

## 압축 전략 (핵심 보존 우선순위)

### 1순위 — 절대 유지
- 인물의 외형 핵심 (성별, 나이대, 머리/눈 색, 의상, 포즈)
- 스타일 키워드 (anime illustration, photorealistic, painterly, oil painting 등)
- 핵심 분위기/조명 키워드 3~5개
- 배경 핵심 묘사 (색 팔레트, 텍스처 종류)

### 2순위 — 압축 가능
- 형용사 중복 (e.g., "elegant, refined, sophisticated" → "elegant" 1개로)
- 부사 (`gradually`, `subtly`, `naturally` 같은 connective adverb 다수 제거)
- 연결 문장 (`while`, `where`, `with` 도입 절 단순화)

### 3순위 — 완전 제거 가능
- 중복 정보 (같은 색을 다른 표현으로 2번 이상 언급)
- 모호한 강조 (`breathtaking`, `stunning` 같은 마케팅 부사)
- 영어 외곽 표현 (`the lower part of` → `lower`, `in order to` → `to`)

## 실전 예시 (2026-07-05 케이스)

**원본 (2114자 — 거부됨):**
```
masterpiece, best quality, newest, ultra detailed, anime illustration, premium artbook illustration, highly aesthetic, elegant contemporary art, gallery-quality character portrait, expressive painterly composition, 9:16 vertical composition, a beautiful young woman, looking back over her shoulder toward the viewer, soft golden eyes, gentle and mysterious smile, graceful neck line, delicate facial features, long layered black hair, flowing hair gradually dissolving into painterly brushstrokes and abstract pigments, subtle gold paint splashes woven through her hair, wearing a luxurious black velvet off-shoulder dress, matte fabric, elegant folds, high-fashion editorial styling, the lower part of the dress gradually transforming into abstract oil painting textures, fabric blending seamlessly into thick palette-knife strokes, standing calmly with refined posture, shoulders slightly turned away, head gently turned back toward the camera, elegant and confident, cinematic fashion magazine atmosphere, background completely composed of contemporary abstract oil painting, textured canvas, thick impasto, palette knife painting, heavy brush strokes, scraped paint, layered pigments, rough canvas grain, distressed painted wall, expressive acrylic texture, rich tactile surface, dominant colors of deep teal, emerald green, muted olive, warm ivory, antique gold, subtle burgundy accents, harmonious muted palette, sophisticated color blocking
the abstract painting naturally invades the character, hair partially dissolving into brushstrokes, dress melting into layered pigments, subtle paint textures appearing around shoulders and silhouette while the face remains beautifully clean and sharply rendered, soft museum lighting, diffused natural light, fine rim light, cinematic shadows, elegant contrast, painterly atmosphere, luxurious editorial photography composition, modern art exhibition mood, emotional fine art aesthetic, perfect anatomy, highly detailed eyes, intricate fabric folds, breathtaking texture
```
→ 길이 2114, status_code 2013 거부

**압축본 (1482자 — 통과):**
```
masterpiece, best quality, ultra detailed, anime illustration, premium artbook style, gallery character portrait, 9:16 vertical, beautiful young woman looking back over her shoulder, soft golden eyes, gentle mysterious smile, graceful neck, delicate features, long layered black hair dissolving into painterly brushstrokes and abstract pigments, subtle gold paint splashes in her hair, wearing luxurious black velvet off-shoulder dress, matte fabric, elegant folds, high-fashion editorial styling, lower dress transforming into abstract oil painting textures, fabric blending into thick palette-knife strokes, refined posture, shoulders slightly turned away, head gently turned back, elegant and confident, cinematic fashion magazine atmosphere, background of contemporary abstract oil painting, textured canvas, thick impasto, palette knife, heavy brush strokes, scraped paint, layered pigments, rough canvas grain, distressed painted wall, dominant colors deep teal, emerald green, muted olive, warm ivory, antique gold, subtle burgundy, harmonious muted palette, abstract painting invading the character, hair dissolving into brushstrokes, dress melting into layered pigments, paint textures around shoulders while face remains clean and sharp, soft museum lighting, diffused natural light, fine rim light, cinematic shadows, elegant contrast, painterly atmosphere, modern art exhibition mood, emotional fine art aesthetic, perfect anatomy, detailed eyes, intricate fabric folds
```
→ 길이 1482, status_code 0 success

**압축률:** 2114 → 1482 (30% 감소). 시각적 결과는 동일하게 의도 보존.

## 압축 시 절대 잃으면 안 되는 것

⚠️ **눈 색상은 매우 약한 시그널**: `soft golden eyes` → `golden eyes`로 줄여도 모델이 어두운 갈색으로 내는 경향. 진짜 강조하려면:
```
vivid amber golden eyes, glowing golden irises, bright golden eye color
```
처럼 **2~3번 반복 + vivid/glowing 강조어** 붙여야 적용됨 (2026-07-05 실측).

⚠️ **9:16 비율**: image-01 모델은 9:16을 요청해도 실제 출력은 3:4에 가까운 세로형. 비율을 진짜 세로로 강제하려면 다른 백엔드(FAL 등) 고려.