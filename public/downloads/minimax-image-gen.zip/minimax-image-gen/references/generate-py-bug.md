# `scripts/generate.py` 파싱 버그 (2026-07-05 실측)

## 증상

```
Attempt 1 error: 'NoneType' object has no attribute 'get'
Attempt 2 error: 'NoneType' object has no attribute 'get'
Failed to generate image
```

## 원인

`scripts/generate.py`의 응답 파싱:

```python
result = json.loads(resp.read())
urls = result.get("data", {}).get("image_urls", [])   # ← 여기서 죽음
```

API는 정상 응답을 주지만 `data` 키가 **None**이 아닌 정상 dict이고, `.get("image_urls", [])`는 정상 동작해야 하는데도 죽음. 실제 원인은 더 위 라인:

```python
status = result.get("base_resp", {}).get("status_code")
if status == 0 and urls:
    return urls
elif status == 1033 and attempt < retry - 1:
    ...
```

→ API는 status_code 0을 정상 반환하지만, 그 다음 `urls` 평가 시점이 **아직 `urls` 빈 리스트**라 `if status == 0 and urls:`가 False. 그러면 두 번째 `elif`로 가서 `status != 1033`이라 else 분기:

```python
else:
    return []    # ← urls = [] 반환
```

즉, **실제 응답은 200 OK + 정상 URL인데 스크립트가 항상 빈 리스트로 반환**. 그럼 호출자(`if __name__`)가 "Failed to generate image" 출력.

## 진단법

직접 curl로 같은 payload 보내서 status_code=0 + image_urls 채워지는지 확인:

```bash
source ~/.hermes/secrets/minimax.env
curl -s -X POST "https://api.minimax.io/v1/image_generation" \
  -H "Authorization: Bearer $MINIM...EY" \
  -H "Content-Type: application/json" \
  -d @payload.json | python3 -m json.tool
```

`base_resp.status_code == 0` + `data.image_urls`가 채워지면 스크립트 버그 확정.

## 우회 호출 스니펫 (즉시 사용 가능)

`scripts/generate.py` 우회 — Python urllib 직접 호출:

```python
import json, urllib.request, urllib.error, pathlib

env_path = pathlib.Path.home() / ".hermes" / "secrets" / "minimax.env"
key = ""
for line in env_path.read_text().splitlines():
    if line.startswith("export "):
        k, _, v = line[len("export "):].partition("=")
        if k.strip() == "MINIM...EY":
            key = v.strip().strip('"').strip("'")
            break

prompt = "<your prompt, ≤1490 chars>"
payload = json.dumps({
    "model": "image-01",
    "prompt": prompt,
    "aspect_ratio": "9:16",   # 또는 "16:9", "1:1", "4:3", "3:4"
    "response_format": "url",
    "n": 1,
}, ensure_ascii=False).encode("utf-8")

req = urllib.request.Request(
    "https://api.minimax.io/v1/image_generation",
    data=payload, method="POST",
    headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
)

try:
    with urllib.request.urlopen(req, timeout=120) as resp:
        r = json.loads(resp.read().decode("utf-8"))
        urls = (r.get("data") or {}).get("image_urls", [])
        if urls:
            # 다운로드 + /tmp 저장
            out = pathlib.Path("/tmp/minimax_output.jpg")
            with urllib.request.urlopen(urls[0], timeout=60) as ir:
                out.write_bytes(ir.read())
            print(f"OK: {out} ({out.stat().st_size} bytes) — {urls[0]}")
except urllib.error.HTTPError as e:
    print(f"HTTP {e.code}: {e.read().decode('utf-8', errors='replace')[:400]}")
```

## 영구 픽스 (scripts/generate.py)

다음 PR에서 `scripts/generate.py`를 다음으로 교체 권장:

```python
result = json.loads(resp.read())
status = result.get("base_resp", {}).get("status_code")
urls = (result.get("data") or {}).get("image_urls", [])  # ← 방어적

if status == 0 and urls:
    return urls
elif status == 1033 and attempt < retry - 1:
    continue
else:
    # 디버깅을 위해 실제 응답 stderr에 dump
    print(f"DEBUG: status={status} body={json.dumps(result)[:200]}", file=sys.stderr)
    return []
```

핵심 변경:
1. `(result.get("data") or {})` — `data`가 `None`일 때 방어
2. else 분기에 디버그 dump — 왜 빈 리스트인지 즉시 알 수 있게

## 현재 상태

- **2026-07-05**: 버그 인지, 우회 스니펫으로 작업 가능
- **scripts/generate.py 자체는 미수정** (영구 픽스는 다음 maintenance 윈도우에서)
- 우회 스니펫으로 호출 → 정상 동작 확인 (painterly portrait 381KB 생성 성공)