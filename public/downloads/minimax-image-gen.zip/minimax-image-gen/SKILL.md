---
name: minimax-image-gen
description: MiniMax image-01 텍스트→이미지 생성. 프롬프트만 주면 기본 16:9 비율로 생성. 가로세로 비율/개수 지정 가능.
triggers:
  - "이미지 생성해줘"
  - "이미지 만들어줘"
  - "image generation"
  - "그림 그려줘"
default_options:
  aspect_ratio: "16:9"
  n: 1
  response_format: "url"
---

# MiniMax Image Generation (image-01)

## ⚠️ 밝은 이미지 생성 규칙 (유머/위트 테마 필수)

**주인님 선호:** 포토리얼리즘이면서 **밝고 활기찬** 이미지. 어두운 이미지를 절대 원하지 않음.

**✅ 항상 포함:** `bright daylight, vivid colors, high-key lighting, cheerful atmosphere`
**❌ 절대 사용 금지:** `cinematic photography, natural lighting, low-key lighting, moody atmosphere, dark, night scene` — 어두운 이미지 유발

**유머/위트 테마 추가 키워드:** `comedic contrast, playful light, saturated tones, warm golden hour`

**예시 (옳음):**
```
Photorealistic, bright daylight, sunny street market, colorful awnings, saturated tones, high-key lighting, comedic contrast, cheerful atmosphere
```

**예시 (❌):**
```
Photorealistic, cinematic photography, moody atmosphere, natural lighting, dark tones
```

**⚠️ 예외 (2026-07-05 업데이트):** 사용자가 직접 보낸 painterly / moody / museum-style 프롬프트처럼 **에디토리얼 / 회화풍 일러스트**를 명시한 경우 위 밝은 이미지 규칙은 적용하지 **않음**. 사용자 의도 최우선 — 단 본인 피드백 루프로 "이건 밝게 가자" 코렉션 오면 그때 follow.

MiniMax `image-01` 모델로 텍스트 프롬프트에서 이미지를 생성합니다.

## API 정보

- **Endpoint:** `POST https://api.minimax.io/v1/image_generation`
- **모델:** `image-01`
- **URL 만료:** 24시간

## 파라미터

| 파라미터 | 기본값 | 설명 |
|----------|--------|------|
| `prompt` | (필수) | 이미지 설명 (**≤ 1500자, 정확히는 1490자 안전 마진**) |
| `aspect_ratio` | `16:9` | 비율: 1:1, 16:9, 4:3, 3:2, 2:3, 3:4, 9:16, 21:9 (**⚠️ 9:16 요청해도 실제 출력은 ~3:4 세로형으로 나옴 — 모델 특성**) |
| `n` | `1` | 생성 개수 (1~9) |
| `response_format` | `url` | `url` 또는 `base64` |
| `prompt_optimizer` | `false` | 프롬프트 자동 최적화 |

**⚠️ 프롬프트 길이 함정 (2026-07-05 실측):**
- 한도 = **1500자 미만** (`less than 1500`)
- `2013 invalid params, prompt length must be less than 1500`로 거부됨
- 보통 영어 기준 약 220~250 단어 정도. 안전 마진으로 **1490자 이내** 권장
- 초과 시 자동 압축 팁 → `references/prompt-compression.md`

**⚠️ 키 마스킹 함정 (2026-07-05 실측):**
- 터미널에서 `Bearer *** `처럼 인라인으로 키를 쓰면 `***`로 마스킹되어 `1004 login fail`
- `export MINIM...EY=*** | tee > curl`처럼 환경변수 경유가 안전
- 가장 안전한 길: Python urllib로 키를 직접 `~/.hermes/secrets/minimax.env`에서 읽어 호출

## 사용 예시

### simplest call (디폴트 16:9)
```
흰 배경을 앞에 두고 귀여운 robot이 달리는 샛빛 레트로 스타일
```

### 9:16 세로형 (Shorts용)
```
aspect_ratio=9:16
비오는 도시 야경, 네온 불빛이 물에 반사, cinematic mood
```

### 1:1 정사각형
```
aspect_ratio=1:1
minimalist workspace, macbook, coffee, plants, soft lighting
```

## curl 명령어

```bash
curl -s -X POST "https://api.minimax.io/v1/image_generation" \
  -H "Authorization: Bearer $MINIMAX_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "image-01",
    "prompt": "yscene description",
    "aspect_ratio": "16:9",
    "response_format": "url",
    "n": 1
  }'
```

**⚠️ 터미널에서 키 마스킹 회피:** 인라인 `Bearer *** ` 대신 `source ~/.hermes/secrets/minimax.env` 후 `$MINIM...EY` 환경변수로 참조.

## 에러 처리

| status_code | 의미 | 대응 |
|---|---|---|
| **0** | success | `data.image_urls` 배열에서 URL 추출 |
| **1004** | `login fail: Please carry the API secret key` | 키 누락/잘못됨 → 키 로딩 다시 확인 |
| **2013** | `prompt length must be less than 1500` | 프롬프트 압축 (참조: `references/prompt-compression.md`) |
| **1033** | 일시적 서버 에러 | 3회 재시도 |

## 백엔드 선택 가이드 (2026-07-05)

이미지 생성 요청이 들어왔을 때 두 가지 경로가 있음:

| 경로 | 트리거 | 키 필요 | 비고 |
|---|---|---|---|
| **`image_generate` 툴 (Hermes 내장)** | 모델이 자동으로 사용 | `FAL_KEY` 환경변수 | 현재 기본 백엔드 FAL (FLUX 2 Klein 9B). 키 없으면 ValueError |
| **`minimax-image-gen` 스킬 (직접 호출)** | `python3 scripts/generate.py` 또는 curl | `~/.hermes/secrets/minimax.env`의 `MINIM...EY` | 키 살아있고 별도 비용 체계 (Interval/Weekly 한도) |

**판단 규칙:**
1. 사용자가 명시적으로 "미니맥스/MiniMax" 언급 → 스킬 사용
2. 사용자가 "이미지 생성해줘" 일반 호출 → `image_generate` 툴 시도 → `FAL_KEY` 없으면 fallback으로 스킬
3. 에디토리얼 / painterly / anime 풍 → 미니맥스 image-01이 더 잘 뽑음 (FLUX는 포토리얼 강함)
4. FAL 키 세팅은 옵션 → 평소엔 미니맥스 경로가 1순위

## 저장소

- 스크립트: `scripts/generate.py` (⚠️ 2026-07-05 파싱 버그 발견 — `references/generate-py-bug.md`)
- 시크릿: `~/.hermes/secrets/minimax.env` (MINIMAX_API_KEY)

## 지원 파일

- `references/prompt-compression.md` — 1500자 초과 시 핵심 보존 압축 레시피
- `references/generate-py-bug.md` — `scripts/generate.py` 응답 파싱 버그 + 우회 우회 호출 스니펫