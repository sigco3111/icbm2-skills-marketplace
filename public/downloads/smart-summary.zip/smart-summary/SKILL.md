---
name: smart-summary
description: 다중 소스 지능 요약 — URL, PDF, 유튜브, 긴 텍스트를 핵심만 추려서 요약
version: 1.0.0
author: icbm2
metadata:
  hermes:
    tags: [Summary, YouTube, PDF, URL, Productivity]
---

# smart-summary

## 개요

URL, PDF, 유튜브 링크, 긴 텍스트 등 어떤 형태의 콘텐츠든 입력하면 핵심만 추려서 요약해주는 통합 스킬.

## 입력 형식 지원

1. **URL (웹페이지)** — terminal로 curl + web_extract 사용
2. **PDF 파일** — ocr-and-documents 스킬 활용
3. **유튜브 링크** — youtube-content 스킬의 fetch_transcript.py 활용 (`SKILL_DIR/scripts/fetch_transcript.py`)
4. **긴 텍스트** — 직접 LLM 처리

## 요약 옵션

- 3줄 요약 (ultra-short)
- 1단락 요약 (short)
- 상세 요약 (detailed, 섹션별)
- 키워드 5개 자동 추출
- 관련 링크/추천 자료 제안 (선택)

## 실행 워크플로우

### 1. 입력 타입 감지

입력값의 형태를 자동 감지:

- `youtube.com` / `youtu.be` 링크 → 유튜브 처리
- `.pdf`로 끝나는 URL 또는 로컬 파일 경로 → PDF 처리
- `http://` 또는 `https://`로 시작하는 URL → 웹페이지 처리
- 그 외 → 긴 텍스트로 처리

### 2. 콘텐츠 수집

- **유튜브**: `python3 SKILL_DIR/scripts/fetch_transcript.py "URL" --text-only --timestamps` 사용
- **PDF**: `ocr-and-documents` 스킬 참고 (web_ext 활용)
- **URL**: `curl -sL "URL" | head -c 50000` 또는 web_extract 사용
- **텍스트**: 그대로 사용

### 3. 청킹 (50K 문자 초과 시)

- 40K 문자 단위로 분할 (2K 오버랩)
- 각 청크를 개별 요약 후 병합

### 4. 요약 생성

요약 옵션에 따라 LLM으로 요약 생성. 한국어로 작성.

### 5. 출력 형식

```
📋 요약: [제목]

🔑 핵심 요약
(3줄 또는 1단락)

📌 주요 포인트
• 포인트 1
• 포인트 2
• 포인트 3

🏷️ 키워드
#키워드1 #키워드2 #키워드3 #키워드4 #키워드5

📎 원문: [URL]
```

### 6. Notion 저장 (선택)

주인님이 요청하면 Notion 아이디어 노트 DB에 저장:

- DB ID: `32e76f2e-9097-8081-98d0-f54524fe4c47`
- notion 스킬의 API 패턴 사용

## 사용 예시

### 텔레그램에서

- `"이 링크 요약해줘 https://..."` → 3줄 요약
- `"상세 요약해줘 https://youtube.com/..."` → 상세 요약 + 키워드
- `"이 PDF 요약해줘 /path/to/file.pdf"` → PDF 요약

### 크론에서

- 뉴스 모니터링과 연동하여 자동 요약

## Notion API 패턴

다른 스킬들과 동일하게 curl 기반:

```python
import os, json, subprocess
TK_PATH = os.environ.get("NOTION_TOKEN_PATH", os.path.expanduser("~/.hermes/secrets/notion_token.txt"))
with open(TK_PATH) as f:
    tk = f.read().strip()
# curl 기반 API 호출 패턴
```

## 관련 스킬

- **youtube-content** (유튜브 전문)
- **ocr-and-documents** (PDF 전문)
- **tech-doc-translator** (번역 전문)
- **notion-idea-note** (Notion 저장)

## 주의사항

- 유튜브 자막이 없는 영상은 요약 불가 → 에러 메시지 안내
- 50K+ 문자는 청킹 필수
- 한국어로 요약 (원문이 영문이어도)
- 출처 URL은 항상 표시
- 투자 조언 등은 요약에서 배제
