---
name: smart-summary
description: 다중 소스 지능 요약 — URL, PDF, 유튜브, 긴 텍스트를 핵심만 추려서 요약
version: 1.0.0
author: icbm2
metadata:
  hermes:
    tags: [Summary, YouTube, PDF, URL, Productivity]
---

# smart-summary

## 개요

URL, PDF, 유튜브 링크, 긴 텍스트 등 어떤 형태의 콘텐츠든 입력하면 핵심만 추려서 요약해주는 통합 스킬.

## 입력 형식 지원

1. **URL (웹페이지)** — terminal로 curl + web_extract 사용
2. **PDF 파일** — ocr-and-documents 스킬 활용
3. **유튜브 링크** — youtube-content 스킬의 fetch_transcript.py 활용 (`SKILL_DIR/scripts/fetch_transcript.py`)
4. **긴 텍스트** — 직접 LLM 처리

## 요약 옵션

- 3줄 요약 (ultra-short)
- 1단락 요약 (short)
- 상세 요약 (detailed, 섹션별)
- 키워드 5개 자동 추출
- 관련 링크/추천 자료 제안 (선택)

## 실행 워크플로우

### 1. 입력 타입 감지

입력값의 형태를 자동 감지:

- `youtube.com` / `youtu.be` 링크 → 유튜브 처리
- `.pdf`로 끝나는 URL 또는 로컬 파일 경로 → PDF 처리
- `http://` 또는 `https://`로 시작하는 URL → 웹페이지 처리
- 그 외 → 긴 텍스트로 처리

### ⚠️ 한국 뉴스 사이트 케이스 — AI타임스 / 미디어잇 / ZDNet Korea (2026-07-02 추가)

한국어 IT 뉴스 사이트는 **단계 A(LLM 미러)가 거의 없음** (`/llms.txt` → 404). 단계 B(SSR streamed JSON)도 아님. **단계 C(HTML 파싱)만 작동.**

**실전 사례 (2026-07-02 aitimes.com)**:

```bash
# 단계 A: 즉시 SKIP (404 페이지 반환)
curl -sL --max-time 8 -A "$UA" "https://www.aitimes.com/llms.txt" -o /tmp/x.txt
# → "요청하신 페이지를 찾을 수 없습니다" HTML 1355 bytes (404)

# 단계 C: HTML 파싱
curl -sL --max-time 12 -A "$UA" "URL" -o /tmp/article.html
```

**3가지 한국 뉴스 사이트 함정**:

1. **`<title>` 태그가 비어있는 사이트 많음** (aitimes 케이스)
   - `grep -oE '<title[^>]*>[^<]*</title>'` → 매치 없음
   - **대안**: `og:description` 또는 `meta name="description"`이 안정적으로 채워져 있음
2. **HTML entity `&#039;` (작은따옴표) 한국어 본문에 섞임**
   - `html.unescape(plain)` 필수
   - 안 하면 검색 키워드 매치 깨짐 (e.g. `'롱캣(LongCat)-2.0'` → `'롱캣(LongCat)-2.0'`)
3. **본문이 `<div class="article-body">` 또는 `<div id="article-view-content">` 안에 있는 줄 알았는데, 사실 페이지 전체가 한 div로 평탄하게 들어있는 경우 多**
   - "롱캣" 매치 위치를 찾고 ±200~1500자 윈도우로 핵심 문장 추출
   - Python `re.finditer` + `plain[max(0, m.start()-200):m.end()+1500]` 패턴이 가장 안정적

**검증된 사이트**: aitimes.com (박찬 기자 2026-07-01 롱캣-2.0 기사) — `og:description` + 본문 추출로 답변 생성 완료.

**범용 패턴**:

```python
import re, html
with open('/tmp/article.html', encoding='utf-8') as f:
    raw = f.read()

# 1) 메타데이터
title = re.search(r'<meta[^>]*property="og:title"[^>]*content="([^"]+)"', raw)
desc = re.search(r'<meta[^>]*property="og:description"[^>]*content="([^"]+)"', raw)
# (title 태그가 빈 사이트는 og:title이 본문 결정의 1차 소스)

# 2) 본문 평탄화
text = re.sub(r'<script[^>]*>.*?</script>', '', raw, flags=re.S)
text = re.sub(r'<style[^>]*>.*?</style>', '', text, flags=re.S)
plain = re.sub(r'<[^>]+>', ' ', text)
plain = html.unescape(re.sub(r'\s+', ' ', plain)).strip()

# 3) 키워드 매치 주변 추출
for m in re.finditer(r'KEYWORD', plain):
    s = max(0, m.start() - 200)
    e = min(len(plain), m.end() + 1500)
    print(plain[s:e])
    break  # 첫 매치만
```

**결론**: 한국 뉴스 사이트는 **"og description 먼저 + 본문 키워드 매치 윈도우"** 패턴이 가장 안정적. LLM 미러 단계는 시간 낭비 → 즉시 단계 C로 직행.

### 2. 콘텐츠 수집 — URL은 4단계 우선순위

**최신 사이트는 처음부터 chrome-automation 쓰지 말 것.** 비용↑ 속도↓ 로그인 필요 없는 public 페이지는 거의 다 curl로 충분. 단계별로 시도:

#### 단계 A. LLM-first 사이트 미러 (가장 빠름)

2025+ LLM 친화 사이트는 대부분 `/llms.txt` + `/md/*` 마크다운 미러를 제공. 이걸 먼저 확인.

```bash
# 1) LLM 가이드 존재 여부
curl -sL --max-time 8 -A "Mozilla/5.0" "https://SITE/llms.txt" -o /tmp/llms.txt
head -50 /tmp/llms.txt  # 있으면 마크다운 엔드포인트 목록이 있음

# 2) llms.txt에 나온 /md/* 경로를 그대로 fetch (HTML 파싱보다 10배 빠름)
curl -sL --max-time 10 "https://SITE/md/posts" -o /tmp/posts.md
curl -sL --max-time 10 "https://SITE/md/users/HANDLE" -o /tmp/user.md
curl -sL --max-time 10 "https://SITE/md/posts/POSTID" -o /tmp/post.md

# 3) robots.txt + sitemap.xml — 사이트 구조 파악
curl -sL "https://SITE/robots.txt"
curl -sL "https://SITE/sitemap.xml"        # sitemapindex일 수 있음
curl -sL "https://SITE/sitemaps/posts-1.xml"  # 직접 fetch
```

**대표 사이트 패턴**:
- Boutlet: `/llms.txt`, `/md/{channels,posts,users/HANDLE,posts/POSTID}`
- Cloudflare 문서, Stripe 일부 페이지, Vercel docs: `/llms.txt` 또는 `/llms-full.txt`
- 일반 SaaS는 sitemap만 있는 경우 多

#### 단계 B. SSR streamed JSON 디코딩 (React Router v7 / Remix)

SPA로 보이지만 SSR이 있는 사이트(예: Boutlet의 `/data-hub/erc8004`)는 `curl -sL`로 받은 HTML 안에 **`window.__reactRouterContext.streamController.enqueue("...")`** 형식의 청크된 JSON이 inline으로 들어있음. 최대 2MB+ 까지 가능.

```python
import re, json

with open('/tmp/page.html', encoding='utf-8') as f:
    raw = f.read()

# 1) 모든 enqueue("...") 청크 추출
pattern = r'window\.__reactRouterContext\.streamController\.enqueue\("((?:[^"\\]|\\.)*)"\)'
chunks = []
for m in re.finditer(pattern, raw, re.S):
    try: chunks.append(json.loads(f'"{m.group(1)}"'))  # JSON-safe unescape
    except: pass

# 2) "P<id>:[...]" 형식의 본문 파싱 → 큰 배열 평탄화
merged = []
for c in chunks:
    idx = c.find(':')
    if idx > 0 and c[0] == 'P':
        try:
            arr = json.loads(c[idx+1:])
            if isinstance(arr, list):
                merged.extend(arr)
        except: pass

# 3) 키워드 가이드 추출
for i, v in enumerate(merged):
    if isinstance(v, str) and len(v) > 50 and v[0].isupper() \
       and any(k in v.lower() for k in ['agent', 'protocol', 'integration']):
        # 후속 카테고리/점수 후보도 함께 보고 싶으면 i+1..i+8 스캔
        ...
```

**함정**: ① 헤더가 2.9MB HTML이라 hydration 전 SSR 텍스트는 매우 짧음 (대부분 <3000자). ② 큰 script 블록은 React 자체 (Meta scheduler 라이센스 보이면 무시). ③ chunk의 body가 JSON parse 실패하면 quote escape 실수 — `json.loads(f'"{s}"')`로 한번 더 감싸면 안전.

**대상 사이트 신호**: ① `<title>`에 의미있는 이름, ② meta description이 채워져 있음, ③ `<html>` SSR 텍스트가 짧음, ④ script 블록이 1MB+ — 이 조합이면 99% React Router v7 SSR streamed JSON.

#### 단계 C. 일반 HTML 파싱

마크다운 미러 없고 SSR streamed도 없을 때.

```bash
curl -sL --max-time 12 -A "Mozilla/5.0" "URL" -o /tmp/page.html
```

```python
import re, html
with open('/tmp/page.html', encoding='utf-8') as f:
    raw = f.read()

# script/style 제거 후 텍스트만
text = re.sub(r'<script[^>]*>.*?</script>', '', raw, flags=re.S)
text = re.sub(r'<style[^>]*>.*?</style>', '', text, flags=re.S)
text = re.sub(r'<!--.*?-->', '', text, flags=re.S)
plain = re.sub(r'<[^>]+>', ' ', text)
plain = html.unescape(re.sub(r'\s+', ' ', plain)).strip()

# 메타데이터
title = re.search(r'<title[^>]*>([^<]+)</title>', raw)
desc = re.search(r'<meta[^>]*name="description"[^>]*content="([^"]+)"', raw)
og = re.findall(r'<meta[^>]*property="og:([^"]+)"[^>]*content="([^"]+)"', raw)
```

#### 단계 D. chrome-automation fallback

위 3단계 다 안 되거나 JS 렌더링 필수 (검색 결과 동적 로딩, 무한 스크롤, 인터랙티브 폼 등)일 때만. 비용 큼.

- **유튜브**: `python3 SKILL_DIR/scripts/fetch_transcript.py "URL" --text-only --timestamps` 사용
- **PDF**: `ocr-and-documents` 스킬 참고 (web_ext 활용)
- **텍스트**: 그대로 사용

### 3. 청킹 (50K 문자 초과 시)

- 40K 문자 단위로 분할 (2K 오버랩)
- 각 청크를 개별 요약 후 병합

### 4. 요약 생성

요약 옵션에 따라 LLM으로 요약 생성. 한국어로 작성.

### 5. 출력 형식

```
📋 요약: [제목]

🔑 핵심 요약
(3줄 또는 1단락)

📌 주요 포인트
• 포인트 1
• 포인트 2
• 포인트 3

🏷️ 키워드
#키워드1 #키워드2 #키워드3 #키워드4 #키워드5

📎 원문: [URL]
```

### 6. Notion 저장 (선택)

주인님이 요청하면 Notion 아이디어 노트 DB에 저장:

- DB ID: `32e76f2e-9097-8081-98d0-f54524fe4c47`
- notion 스킬의 API 패턴 사용

## 사용 예시

### 텔레그램에서

- `"이 링크 요약해줘 https://..."` → 3줄 요약
- `"상세 요약해줘 https://youtube.com/..."` → 상세 요약 + 키워드
- `"이 PDF 요약해줘 /path/to/file.pdf"` → PDF 요약

### 크론에서

- 뉴스 모니터링과 연동하여 자동 요약

## Notion API 패턴

다른 스킬들과 동일하게 curl 기반:

```python
import os, json, subprocess
TK_PATH = os.environ.get("NOTION_TOKEN_PATH", os.path.expanduser("~/.hermes/secrets/notion_token.txt"))
with open(TK_PATH) as f:
    tk = f.read().strip()
# curl 기반 API 호출 패턴
```

## 관련 스킬

- **youtube-content** (유튜브 전문)
- **ocr-and-documents** (PDF 전문)
- **tech-doc-translator** (번역 전문)
- **notion-idea-note** (Notion 저장)

## 주의사항

- 유튜브 자막이 없는 영상은 요약 불가 → 에러 메시지 안내
- 50K+ 문자는 청킹 필수
- 한국어로 요약 (원문이 영문이어도)
- 출처 URL은 항상 표시
- 투자 조언 등은 요약에서 배제
- **`execute_code`는 일반 세션에선 OK, cron 잡 컨텍스트에서는 BLOCKED** — cron에서 데이터 분석이 필요하면 `terminal` + python heredoc 또는 `scripts/` 정적 스크립트화
- **4단계 우선순위 (A→D)**: A(llms.txt/md) → B(SSR streamed JSON) → C(HTML 파싱) → D(chrome). A에서 끝나는 경우가 절반.
