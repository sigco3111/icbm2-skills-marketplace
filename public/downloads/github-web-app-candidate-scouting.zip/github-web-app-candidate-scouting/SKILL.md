---
name: github-web-app-candidate-scouting
description: Scout GitHub OSS web apps for improvement candidates.
---

# GitHub web app candidate scouting

The **web-app/productivity** sibling of `github-game-candidate-scouting` — same investigation shape, but domain signals differ (i18n libs, framework choice, PR backlog health instead of engines/Steam shim).

Use when the user asks for:
- 웹앱/생산성 도구 한글화 후보
- OSS productivity tools to contribute to
- Self-hostable alternatives with growth opportunity
- Best targets for a specific improvement (a11y, i18n, perf, feature gap)

## Workflow

### 1. Broad survey

Run 3-5 `gh search repos` queries covering the user's implied domain. Use the JSON shape gh CLI actually accepts:

```bash
gh search repos "productivity" --language=typescript --stars=">500" --limit 20 \
  --json fullName,description,stargazersCount,language,license,pushedAt,url
```

Seed queries for productivity/web apps:
- `"productivity"` — broad
- `"note-taking"` — note apps
- `"task management"` — task/project tools
- `"kanban"` — board apps
- `"bookmark manager"` — bookmark tools
- `"todo web app"` — todo apps

> ⚠️ `gh search repos` JSON field for license is `license` (an object with `key`/`name`), NOT `licenseInfo`. Confirmed by gh 2.95.0: `Unknown JSON field: "licenseInfo"`.

### 2. First-pass filter

For each candidate:

```bash
gh repo view <repo> --json stargazerCount,forkCount,languages,pushedAt,license,url
```

Drop rules (initial):
- `pushedAt` > 1 year ago (dead)
- `license.key` = `agpl-3.0` (if user wants to fork; keep if contribution-only)
- `isArchived` = true
- few stars (< 500)

> 💡 `gh repo view` does NOT accept `openIssuesCount` — that field is only on the raw `gh api repos/<repo>` endpoint. Don't add it; you'll get a list of valid fields.

### 3. i18n structure probe

For each survivor, list root contents and look for:

```bash
gh api repos/<repo>/contents | python3 -c "import sys,json; [print(d['name'], d['type']) for d in json.loads(sys.stdin.read())]"
```

Indicators of i18n readiness:
- `i18n/`, `locales/`, `public/locales/`, `l10n/`, `translations/` folder
- `crowdin.yml` at root (Crowdin-managed)
- `package.json` deps: `i18next`, `react-i18next`, `next-intl`, `next-i18next`, `@formatjs`, `lingui`, `vue-i18n`

### 4. Coverage comparison (the coverage trick)

For projects where the target locale already exists, compute leaf-key coverage against the source-of-truth file — use the `flatten` helper in `references/korean-localization-gates.md`.

**Interpretation zones:**
- **0-50%** → 0-to-N work, often rejected as too large
- **50-85%** → mid-fidelity; expect more review
- **85-95%** → sweet spot for natural-language follow-up PR
- **> 95%** → quality-only work; typo/PR-friendly

### 5. PR + activity probe

```bash
gh search prs "korean OR i18n OR locale OR translation" \
  --repo <repo> --state closed --limit 15 \
  --json number,title,state,author,createdAt
```

Signals:
- ✅ Merged in last 30 days → healthy
- ⚠️ Merged > 90 days ago → slowing
- ❌ Many OPEN > 1 month → maintainer backlog
- ❌ Most closed unmerged → contribution culture cold

Sample 1-2 merged PRs to learn the project's contribution style (commit message convention, PR template, diff stats expected).

### 6. Output report (top 3 ranked)

For each pick, include:
- License / stars / last push
- Why i18n-friendly (existing ko, schema, automation)
- First PR scope (e.g., "complete Korean: 142 missing keys")
- Effort estimate

Then a single top recommendation with `→ Adopt this first` reasoning.

## Pitfalls

- **gh CLI JSON field names**: `license` (not `licenseInfo`), `openIssuesCount` only on raw `gh api repos/<repo>`.
- **Stars ≠ quality**: 50k-star project with i18n PR backlog = bad target. 3k stars + weekly commits is often better.
- **Activity floor**: `pushedAt` < 90 days for non-trivial PR. > 1 year = dead.
- **AGPL-3.0 trade-off**: fine for contribution, restrictive for self-hosting in production. Note in report.
- **i18n "exists" ≠ complete**: 91% Korean file is a great target; 0% project is bigger lift.
- **No `i18n/` folder ≠ no i18n**: check `package.json` deps + `crowdin.yml` + `public/locales/`.
- **Crowdin-only projects**: locales live on Crowdin, not in repo. Different contribution model.
- **Korean tone consistency**: prefer `-습니다`/`-어요` consistency; check existing keys for tone before adding.
- **Don't auto-translate**: existing translation strings may have intentional terminology; only fill missing keys, lightly polish. Bulk machine translation often gets rejected.

## Output format

Top-tier recommendation should always include:
- A single top pick with `→ Adopt this first` reasoning
- 2 alternative picks with `When to choose this instead`
- A "first PR" section: file list, key counts, expected diff size, validation command

Always include a "what first PR looks like" section so the user can pick up the work immediately.

## See also

- `github-game-candidate-scouting` — sibling for games/addons
- `oss-fork-localization` — downstream workflow (after picking a candidate)
- `references/korean-localization-gates.md` — i18n health-check playbook with concrete gh commands
