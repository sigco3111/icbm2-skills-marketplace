# Korean localization gates — concrete playbook

Condensed knowledge bank for the i18n investigation phase. Use this when you've narrowed to a candidate and need to validate Korean localization readiness before recommending it.

## The 6 health gates

Each gate is a pass/fail signal. List pass/fail for each candidate in the report.

### Gate 1 — License compatibility

| License | Fork + self-host | Contribution | Notes |
|---|---|---|---|
| MIT, BSD, Apache | ✅ | ✅ | green-light |
| AGPL-3.0 | ⚠️ self-host restriction | ✅ | OK if contribution-only |
| GPL-3.0 | ⚠️ copyleft | ✅ | depends on use case |
| `other` / undetected | ❌ | ❌ | drop |

```bash
gh repo view <repo> --json license | jq -r '.license.key'
```

### Gate 2 — Active maintenance

```bash
gh repo view <repo> --json pushedAt | jq -r '.pushedAt'
```
- ✅ < 30 days = very active
- ✅ 30-90 days = healthy
- ⚠️ 90-180 days = slowing
- ❌ > 180 days = dead

### Gate 3 — i18n infrastructure present

Indicators (any one is enough):
- `i18n/`, `locales/`, `public/locales/`, `l10n/`, `translations/` folder
- `crowdin.yml` at root
- `package.json` has `i18next`, `react-i18next`, `next-intl`, `next-i18next`, `@formatjs`, `lingui`, `vue-i18n`

```bash
gh api repos/<repo>/contents | python3 -c "import sys,json; [print(d['name']) for d in json.loads(sys.stdin.read())]"
gh search code "i18next|react-i18next|next-intl|next-i18next|crowdin" --repo <repo> --limit 5
```

### Gate 4 — Korean locale exists (or not)

Two scenarios:
- **A: Korean locale exists** → check coverage (Gate 5). Best case for incremental PR.
- **B: Korean locale absent** → bigger lift (0→100%), but viable if i18n infrastructure is mature.

```bash
gh api repos/<repo>/contents/i18n  # or appropriate locale folder
```

### Gate 5 — Coverage gap (preferred targets)

Use the `flatten` helper below to compute leaf-key coverage. Target zones:
- **85-95%**: natural-language follow-up PR. Sweet spot.
- **> 95%**: quality-only work.
- **50-85%**: still viable, but expect more review.
- **< 50%**: probably too big for a first PR.

Helper — flatten + coverage:

```python
import json, base64, urllib.request

def get_content(owner, repo, path):
    with urllib.request.urlopen(f"https://api.github.com/repos/{owner}/{repo}/contents/{path}") as r:
        return json.loads(base64.b64decode(json.loads(r.read())['content']).decode())

def flatten(obj, prefix=''):
    out = {}
    if isinstance(obj, dict):
        for k, v in obj.items():
            full = f'{prefix}.{k}' if prefix else k
            if isinstance(v, dict):
                out.update(flatten(v, full))
            else:
                out[full] = v
    return out

EN = flatten(get_content(OWNER, repo, 'i18n/en-US.json'))
KO = flatten(get_content(OWNER, repo, 'i18n/ko-KR.json'))
missing = [k for k in EN if k not in KO]
print(f'EN: {len(EN)} | KO: {len(KO)} | Missing: {len(missing)}')
print(f'Coverage: {100*len(KO)/len(EN):.1f}%')
print('Missing examples:', missing[:30])
```

### Gate 6 — PR merge velocity

```bash
gh search prs "i18n OR locale OR translation OR korean" \
  --repo <repo> --state closed --limit 15 \
  --json number,title,state,createdAt
```

Then check each PR:
- ✅ Merged in last 30 days → healthy
- ⚠️ Merged > 90 days ago → slowing
- ❌ Many OPEN > 1 month → maintainer backlog
- ❌ Most closed unmerged → contribution culture is cold

Sample 1-2 merged PRs to learn:
- Commit message style (`feat(i18n):` vs `i18n:` vs `translate:`)
- PR template sections expected
- Whether diff stats are reported

## Concrete commands for quick reuse

```bash
# Candidate deep-dive in one go (assumes $REPO = "owner/repo")
gh repo view "$REPO" --json stargazerCount,forkCount,languages,pushedAt,license,url
gh api "repos/$REPO/contents" | python3 -c "import sys,json; [print(d['name'], d['type']) for d in json.loads(sys.stdin.read())]"
gh search code "i18next|react-i18next|next-intl|next-i18next|crowdin" --repo "$REPO" --limit 5
gh search prs "korean OR i18n OR locale" --repo "$REPO" --state closed --limit 15 --json number,title,state,author,createdAt
```

## What to deliver in the report

For each candidate, present a one-line verdict per gate:

```
## usekaneo/kaneo
G1 license ✅ MIT  G2 active ✅ 2026-07-27  G3 i18n ✅ i18n/ + react-i18next
G4 ko exists ✅ 91.1% coverage  G5 sweet-spot ✅ 142 missing keys
G6 PR velocity ✅ 4 i18n PRs merged in last 7 days

→ Top pick: complete Korean (ko-KR) translation, ≤ half-day
```

Then for the top pick, include:

- **File list**: e.g., `i18n/ko-KR.json`
- **Key counts**: leaf 1,455 / 1,597 (91.1%); missing 142
- **Expected diff**: ~150-300 lines
- **Validation command**: `pnpm i18n:check ko-KR` (project-specific; check package.json for the actual script)
- **Reference PR**: reference the latest schema-sync PR (e.g., `fix(i18n): align locale files with translation schema`) so reviewers understand the context

## Why this matters

The "coverage gap" signal is the single most useful heuristic. A 91% Korean file is a guarantee of:
1. The project has accepted Korean as a locale.
2. The maintainer has done schema work recently.
3. The natural-language PR is welcome, not structural.

This is the difference between a PR that merges in 1 day and one that rots for months.
