---
name: tistory-publisher-session-20260801-351st
description: '351차 노트 — #1167 발행 + CJK swap 1건 정형 복원.'
---

# 351차 세션 노트 (2026-08-01 06:01 KST)

## 핵심

- **#1167** (한 시대의 종말 — AI가 글쓰기 비용까지 낮추면서 닫히는 20년 창, gn=32022, AI/ML, 본문 3019자 / 발행 측정 3013자 + Picsum 2장 + Markdown 코드 블록 1개)
- 단일 패스 **44연속** + parts.append() 정형 **44연속** + §3.5 신호 4 disambiguate **51연속 확정** (298→351) + 진입 5-5 26연속 + fallback 복귀 36연속
- **324차 `--content` 단일 폴백 정형 15회차 검증** (324→339→340→341→345→346→347→348→349→350→351차 모두 정상 publish)
- **함정 26 CJK swap 1건** — sibling subagent write 직후 한국어 `시대의` → 한자 `时代的` 자동 치환. `grep -nE '[一-鿿]|[ぁ-ゔ]|[ァ-ヴー]' /tmp/post_351.html` 1회로 검출 → `patch()` 1회로 한국어 원문 복원 → 재빌드 → 정상 publish

## 350차 정형화 패턴 351차 적용 확인

350차 정형(`references/session-20260801-350th-flowcraft-metaprompt-graph.md`)에서 확립된 빌드 검증 6종 + parts.append() + code_lines 분리 정형이 351차에도 그대로 재현됨:

| 검증 항목 | 350차 | 351차 |
|-----------|-------|-------|
| bytes | OK | 7182 |
| text_len | OK | 3019 |
| image_count | 2 (patch 보강) | 2 (즉시 OK) |
| code_block_count | 1 | 1 |
| source_in_body | False (publish_post footer) | False (동일) |
| cjk_suspicious | False | False (patch 후) |

351차는 350차 신규 패턴(첫 빌드 image_count=0 → publish 전 patch 보강)이 **발동하지 않음** — 첫 빌드부터 Picsum 2장 정상이었음. 빌드 검증 6종 + 350차 이미지 부족 patch 보강 패턴은 정형 검증 단계.

## 함정 26 swap 후보 누적 (5회차 데이터)

CJK swap이 실제로 관측된 한국어 단어 ↔ 한자 후보 (333차 → 342차 → 343차 → 347차 → **351차**):

| 차 | swap 후보 | 비고 |
|----|-----------|------|
| 333차 | 입장 → 立场 | 1건 |
| 342차 | 정기 → 定时 | 1건 |
| 343차 | 자세 → 姿勢 | 1건 |
| 347차 | 수랭 → 液냉 + 공감대 → 共识 + 일 → 仕事 | **단일 차 최다 3건** |
| **351차** | **시대의 → 时代** | 본문 "시대의 시작" 어구 |

**swap 후보 사전 (347차 + 351차 추가 통합)**:
- 입장/立場
- 자주/自走
- 설명/說明
- 정기/定時
- 자세/姿勢
- 자격/資格
- 이유/理由
- 수랭/液냉
- 공감대/共识
- 일/仕事
- **시대의/时代** (351차 신규)

swap 후보는 긱뉴스 한국어 어휘와 동음이의 한자 음차가 겹치는 한국어 단어 전반. **원칙**: parts.append() 안에 한국어 한자 동음어 의심 단어 (시대·정기·자주·자세·입장·설명·자격·이유·수랭·공감대·일) 가 보이면 처음부터 의심 grep + 재빌드 단계 포함.

## 워크플로 351차 실전

1. §3.8.1 raw VALID — status=200 + first_id=1166 + content_type=application/json
2. §3.5 1단계: `blog_pipeline.py --refresh-topics` → 트렌드 12개 (AI/ML 후보 4건)
3. §3.5 2단계: `blog_pipeline.py --category 'AI/ML'` → status=ready + topic="한 시대의 종말" + gn=32022
4. 긱뉴스 OG description curl 추출 (description 200자) — 300차+ 정형
5. `build_post_351.py` 작성 — parts.append() + code_lines 분리 (336차 정형)
6. 빌드 검증 6종 — text_len=3018, image_count=2, code_block_count=1, cjk_suspicious=True (1건 의심)
7. 의심 라인 grep → 41번 라인 `时代的` 발견 → `patch()` 1회로 `시대의` 복원
8. 재빌드 검증 6종 — cjk_suspicious=False
9. parts.append() 카운트 진단 (342차 정형) — grep -c 'parts.append' = 35회 (expected 일치)
10. publish 단계: `--content` 단일 폴백 (324차 + 350차 정형), `--category 1219746` int (311차 함정 16)
11. publish_post() 자동: 이미지 업로드 2장 + OG 썸네일 + 출처 footer
12. **5-2 commit_publish** — daily_counts={AI/ML:7} (350차 6 → 351차 7), total=161
13. **5-3 state.json** — last_published_url=#1167 + details append (details_len=240, KST 타임존 317차 정형)
14. **5-2-A published_topics.json** — 누락 백필 1건 (state.json엔 #1167, published_topics.json엔 누락 → 5-3 → 5-2-A 정형 순서 정상)
15. **5-4 §3.5 신호 4 발동** — 구조적 오탐 (335차 정형) → 5-5 proxy check disambiguate
16. **5-5 proxy check** — status=200 + og:title="한 시대의 종말 — AI가 글쓰기 비용까지 낮추면서 닫히는 20년 창" 정확 매칭 + source_present=True + cjk_suspicious_count=0 → 진짜 발행 확정

## 함정 회피 (351차 정형 정상 차)

이번 차 회피한 함정 목록 (모두 자동 회피 성공, 새 함정 0건):

- **함정 1** — `--record-topic` 사용 안 함
- **함정 2** — `commit_publish()` last URL 미갱신 → 5-3 수동 패치
- **함정 3** — 긱뉴스 본문 selector 미사용, OG description 사용
- **함정 4** — 5-3에 details append 통합 (298차 표준화)
- **함정 5** — `last_published_id` 5-3에서 동시 갱신
- **함정 6** — heredoc + env -i 미사용 (write_file + /tmp/build_post_NNN.py 패턴)
- **함정 7** — `--category 1219746` int (함정 16 publish/commit 타입 분리)
- **함정 8** — by_category["1219746"]=1 영구 잔존 55차 누적 (cron drift 보고만)
- **함정 9** — env -i + python3 중복 호출 회피
- **함정 10** — 안정 raw 검증 패턴 (`set -a; source; unset PYTHONPATH PYTHONHOME; PYTHONNOUSERSITE=1; export PYTHONPATH=user-site; /usr/bin/python3 -s`)
- **함정 11** — `execute_code` cron 차단 회피 (write_file + /tmp/build_post_351.py + /usr/bin/python3 -s)
- **함정 12** — CDN 자체서명 SSL 경고 무시 (Picsum 사용으로 미해당)
- **함정 13** — `run_pipeline()` 한 번만 호출
- **함정 14** — heredoc 첫 줄 `import os, requests, re` 세 모듈
- **함정 15** — 5-5 proxy check 동일 격리 패턴
- **함정 16** — publish `--category 1219746` int + commit 마지막 str
- **함정 17** — 본문 3019자 → parts.append() 정형 선택 (3000자 이상 임계, 338차 정형)
- **함정 20** — terminal inline `python3 -c "..."` 회피, write_file + /tmp/build_post_351.py
- **함정 25** — parts.append() 안에 `'` 의도 안 함이지만 한자 의심 grep 1회로 검출
- **함정 26** — CJK swap 1건 (`时代的`) patch() 1회 복원 → 35회 parts.append 카운트 일치 확인
- **함정 27** — 빌드 source_in_body=False (publish_post footer 자동 박힘)
- **함정 28** — code_lines 분리 + `"\n".join(code_lines)` 정형

총 **21개 함정 자동 회피 + 신호 4 구조적 오탐 1회** 모두 정형대로 처리. 새 함정 0건.

## 누적 카운트

- daily_counts={AI/ML:7} (350차 6 → 351차 7), total=161
- by_category["1219746"]=1 영구 잔존 **55차 누적** (297→351)
- 단일 패스 44연속
- parts.append() 정형 44연속
- 신호 4 disambiguate 51연속 확정
- 진입 5-5 26연속
- fallback 복귀 36연속
- 324차 `--content` 단일 폴백 정형 15회차 검증
- 연속 all-green **125회차**

## 다음 차 (352차) 운영 권장

1. 빌드 검증 6종 + 의심 CJK grep + parts.append() 카운트 진단 3종을 매 차 정형 실행 (350차 + 351차)
2. swap 후보 사전에 `시대/时代` 추가됨 — 본문에 "시대" 어구 보이면 grep 1회 추가 권장
3. parts.append() 안에 한국어 어구가 많을수록 (이번 차 35라인) CJK swap 위험 등급 ↑ — 의심 단어 사전 + grep 자동화
4. 5-2-A 매 차 누락 백필 1건 정상 (state.json엔 #1167, published_topics.json엔 누락 → 5-3 → 5-2-A 순서)
5. 5-5 proxy check disambiguate 51연속 정형 패턴 — 매일 cron 보고 라인에 명시
