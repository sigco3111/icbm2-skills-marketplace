# Sticky Fallback IP 단일 IP 환경 트랩 — 2026-07-12 실측 레퍼런스

## 핵심 발견

`discover_fallback_ips()` 결과가 **`['149.154.166.110']` 처럼 단일 IP로 수렴**하는 환경에서는 Step 6의 (좀비 정리 + 90s 대기 + 깨끗 부팅)을 **여러 번 반복**해도 즉시 `Primary api.telegram.org path unreachable; using sticky fallback IP ...` 로그가 재발. 외부 `curl getMe` 0.8초 정상이어도 **워커만 박힘**.

## 실측 데이터 (2026-07-12 mac 시드 PC)

### 외부 통신은 모두 정상

```bash
# 1) 시스템 DNS (KT) 질의
$ dig +short api.telegram.org @168.126.63.1
149.154.166.110

# 2) Google DoH 질의
$ curl -sS "https://dns.google/resolve?name=api.telegram.org&type=A" | python3 -c "import json,sys; print(json.load(sys.stdin)['Answer'])"
[{"data": "149.154.166.110", ...}]

# 3) 외부 curl getMe
$ time curl -sS --max-time 8 -o /dev/null -w "HTTP %{http_code} time=%{time_total}s ip=%{remote_ip}\n" \
    "https://api.telegram.org/bot${TOKEN}/getMe"
HTTP 200 time=0.804751s ip=149.154.166.110

# 4) SSL 인증서 chain 검증
$ echo | openssl s_client -servername api.telegram.org -connect 149.154.166.110:443 \
    | grep -E "subject=|verify return:"
subject=/CN=api.telegram.org
verify return:1  # 3회 반복 → 모두 OK
```

### 워커는 동일 IP에서 즉시 fail

```bash
# in-process: 워커가 발견한 IP 직접 검증
$ cd ~/.hermes/hermes-agent && ./venv/bin/python3 -c "
import asyncio
from plugins.platforms.telegram.telegram_network import discover_fallback_ips
print(asyncio.run(discover_fallback_ips()))
"
['149.154.166.110']

# err.log 반복 패턴
WARNING plugins.platforms.telegram.telegram_network: [Telegram] Primary api.telegram.org connection failed (); trying fallback IPs 149.154.166.110
WARNING plugins.platforms.telegram.telegram_network: [Telegram] Primary api.telegram.org path unreachable; using sticky fallback IP 149.154.166.110
WARNING plugins.platforms.telegram.telegram_network: [Telegram] Fallback IP 149.154.166.110 failed:
WARNING hermes_plugins.telegram_platform.adapter: [Telegram] Telegram network error (attempt 1/10), reconnecting in 5s. Error: httpx.ReadError:
```

→ 인증서는 멀쩡한데 워커 httpx만 즉시 fail. **`Primary ... connection failed ();` 의 `();` 은 `str(exc)` 가 빈 문자열**이 된 케이스. 진단 정보 부족.

## 워커 소스 동작 의도 vs 실제

`~/.hermes/hermes-agent/plugins/platforms/telegram/telegram_network.py` L74 의 if 분기:

```python
if request.url.host != _TELEGRAM_API_HOST or not self._fallback_ips:
    return await self._primary.handle_async_request(request)
```

→ 의도는 "fallback IP가 0개일 때만 primary path". 즉 IP 1개라도 발견되면 **무조건 IP-rewrite path** (`_rewrite_request_for_ip`) 로 가버림. 도메인 직접 연결을 안 합니다. 이 환경에서 fallback이 단일 IP만 발견되는 게 본질.

## 사용자 옵션 분기

| 옵션 | 명령 | 효과 |
|---|---|---|
| **A. WARP 가동 (정공법)** | 메뉴바 Cloudflare WARP 앱 → WARP ON 토글. 또는 `brew install --cask cloudflare-warp` 후 `warp-cli connect` (PTY 모드 필요) | 회사망이 텔레그램 차단일 때 primary DNS 우회 |
| **B. `hermes gateway start` (stale plist 교체)** | plist가 현 Hermes 설치보다 옛 버전일 때 자동 재작성 | launchd 등록 정합성 회복 |
| **C. 포그라운드 한 번 띄우기** | `cd ~/.hermes/hermes-agent && ./venv/bin/hermes gateway run --replace`. Ctrl+C 종료 | launchd SIGTERM 루프 없이 깨끗한 환경에서 부팅 검증 |
| **D. 사용자 텔레 메시지 재전송** | 옵션 A~C 적용 후 텔레에서 봇에 "테스트" 발사 | 부팅 직후 1~2분 워밍업 시간에 잡힐 수 있음 |

## 검증 가드레일

- `getMe` 외부 curl 정상 + 워커 polling fail + 단일 IP → **이 레퍼런스의 트랩**
- `getMe` 외부 curl도 fail → 외부망 차단 (WARP 활성화 필요)
- `getMe` 외부 curl 정상 + 워커 polling 정상 (sticky 카운트 0) → 다른 원인 (MCP, 화이트리스트, 토큰)

## sendMessage self-test 주의

워커가 살아있어 `sendMessage` self-test는 **false positive 가능**:
- 워커가 살아있으면 send가 정상 응답할 수 있음 (보내는 방향은 외부 통신 OK이므로)
- 사용자 메시지는 봇이 polling으로 받아야 응답 가능
- 사용자 텔레 메시지로만 봇 응답 검증

## 근본 patch (워크어라운드)

워커의 sticky fallback을 환경변수/옵션으로 끄기:
1. `_TELEGRAM_TRANSPORT_DISABLE_FALLBACK=true` 같은 환경변수 추가 (Hermes 버전 미지원 가능성 큼)
2. `_DOH_TIMEOUT=0.001` 으로 DoH 즉시 timeout → seed list 로 폴백 시도도 무력화
3. `discover_fallback_ips()` 가 빈 리스트를 반환하도록 강제 → primary만 시도

가장 깔끔한 옵션은 환경변수로 끄는 것인데, 현 Hermes 1.x 코드는 sticky fallback을 옵션화하지 않음. 패치는 워커 코드 수정이 필요 — 이 스킬 밖.

## 진단 스크립트 함정

`scripts/sticky-fallback-diagnose.sh` 가 obfuscated 가드 패턴 (`TOKEN=*** TELEGRAM_BOT_TOKEN ...` 의 `***` placeholder 박힘)에 걸려 `bash: syntax error near unexpected token ')'` 즉시 실패. 스크립트 직접 실행 금지. `references/sticky-fallback-diagnosis.md` 의 inline 5단계 명령어를 `terminal`에 직접 붙여 실행할 것.
