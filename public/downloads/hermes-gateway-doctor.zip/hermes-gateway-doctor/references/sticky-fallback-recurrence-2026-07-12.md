# Sticky Fallback 재발 케이스 — 2026-07-12 세션 메모

## 핵심 발견

원래 `references/sticky-fallback-diagnosis.md` 의 해결 절차(좀비 정리 + 60s 대기 + 깨끗한 부팅)만으로 **모든 케이스가 풀리는 게 아님**을 확인. 환경 자체에 1차 DNS 차단이 박혀있으면 Step 6 절차 반복해도 같은 sticky fallback 루프로 회귀.

## 2026-07-12 세션에서 본 실측 패턴

### 환경
- 사용자: `/Users/mac`
- `/Users/hjshin` 시드 PC가 아님 — 다른 환경
- WARP 가동 상태 미확인 (이게 결정적일 가능성)

### 진단 타임라인

| 단계 | 명령 | 결과 | 판정 |
|---|---|---|---|
| 1차 | `hermes gateway status` | PID 59169, exit -15, stale plist 경고 | 좀비 슬롯 |
| 2차 | `getUpdates` | `{"ok":true,"result":[]}` | 워커 부재 (409 아님) |
| 3차 | 외부 `getMe` ×3 | 200 OK, 0.8s | 워커 외부 통신 정상 |
| 4차 | sticky fallback 흔적 grep | `Primary path unreachable; using sticky fallback IP 149.154.166.110` × N | Step 6 함정 확정 |
| 5차 | fallback IP SSL curl | `SSL: no alternative certificate subject name matches target ipv4 address '149.154.166.110'` | SSL mismatch 확정 |

### 1차 복구 시도
- 좀비 정리 (`kill -9 59169`, pkill -9)
- `launchctl unload` + 60s 대기 + `launchctl load -w` → 새 PID 3650, exit 0
- 30s 안정화 후 `getUpdates` 여전히 빈 배열
- sticky fallback 로그 재발

### 2차 복구 시도
- 1차 unload + 좀비 3회 반복 + 90s 대기 + 깨끗 부팅 → 새 PID 5290, exit 0
- 60s 안정화 후 `getUpdates` 여전히 빈 배열
- sticky fallback 로그 176라인 누적 (계속 늘어남)
- **`Primary api.telegram.org path unreachable` 즉시 재발** → Step 6 절차 한계 확정

### sendMessage false positive 검증
- 워커가 살아있어 `sendMessage` 응답 와도 봇이 polling 못 잡으면 사용자 메시지 응답은 못 받음
- self-test 메시지 발송 (`message_id: 29003`) → 봇 응답 안 옴
- **결론**: 워커 httpx의 polling channel과 send channel이 다른 경로일 수 있어 send로 polling 정상화 판별 불가

## 사용자 옵션 4종 제시 (SKILL.md Pitfall 13)

| 옵션 | 명령/방법 | 시나리오 |
|---|---|---|
| A. WARP 가동 | Cloudflare WARP CLI 가동 → primary DNS 우회 | 회사망/ISP가 텔레그램 차단 |
| B. `force_primary` config 옵션 | `~/.hermes/config.yaml` telegram 섹션 검토 + sticky 회피 옵션 | WARP 없이 워커 동작만 변경 |
| C. 포그라운드 워밍업 | `cd ~/.hermes/hermes-agent && ./venv/bin/hermes gateway run --replace` | launchd SIGTERM 루프 회피 검증 |
| D. 사용자 텔레 메시지 재전송 | "테스트" 메시지 봇에 발사 후 응답 확인 | 옵션 A~C 효과 즉시 검증 |

## 진단 스크립트 함정

`scripts/sticky-fallback-diagnose.sh` 가 obfuscated 텍스트 가드 패턴 때문에 `bash: syntax error near unexpected token ')'` 로 즉시 실패. 이 파일은 현 시점 사용 불가 — `references/sticky-fallback-diagnosis.md` 의 inline 명령어를 `terminal`에 직접 붙여 실행.

## stale plist 트리거

`hermes gateway status` 의 `⚠ Service definition is stale relative to the current Hermes install` 경고는 plist 자체가 현 Hermes 설치보다 옛 버전이라는 신호. 데몬이 살아있어도 다음 재시작 시점에 launchd 등록 불일치 야기 가능. 권장: `hermes gateway start` 로 stale plist 교체.

## Related

- `references/sticky-fallback-diagnosis.md` — Step 6의 발생 조건, 핵심 증상, 외부 vs 워커 통신 분리, 해결 절차 순서
- SKILL.md Pitfall 13, 14, 15 — 본 세션에서 추가된 함정/경고
- `~/.hermes/logs/gateway.err.log` — sticky fallback 흔적 + ReadError 영구 로그가 본 세션 기준 진단 근거
