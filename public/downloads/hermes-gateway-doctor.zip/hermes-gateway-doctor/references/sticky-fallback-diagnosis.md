# Sticky Fallback IP 함정 — 진단 레퍼런스

2026-06-30 시드 PC에서 처음 발견 + 검증. 워커 httpx 클라이언스가 텔레그램 fallback IP에 sticky 박혀서 SSL mismatch → polling 영구 실패하는 케이스.

## 발생 조건

- 텔레그램 primary 도메인(`api.telegram.org`) 첫 연결 실패 또는 매우 느림 (4초 이상)
- 워커 플러그인이 자동 fallback IP(예: `149.154.166.110`)로 전환
- fallback IP의 SSL 인증서가 텔레그램 공식이 아니라 httpx가 `SSL: no alternative certificate subject name matches target ipv4 address '149.154.166.110'` 에러
- 워커가 이 fallback IP를 sticky로 박아두고 매번 polling 시도 → 매번 ReadError

## 핵심 증상 (이 셋이 동시에 보이면 100% 진단 확정)

1. `launchctl list | grep ai.hermes.gateway` → PID + exit code **0** (데몬 정상)
2. `getUpdates` → `{"ok":true,"result":[]}` (워커가 polling 못 잡음, **409 아님**)
3. `~/.hermes/logs/gateway.err.log`에 다음이 반복:
   - `WARNING plugins.platforms.telegram.telegram_network: [Telegram] Primary api.telegram.org connection failed (); trying fallback IPs 149.154.166.110`
   - `WARNING plugins.platforms.telegram.telegram_network: [Telegram] Primary api.telegram.org path unreachable; using sticky fallback IP 149.154.166.110`
   - `WARNING hermes_plugins.telegram_platform.adapter: [Telegram] Network error on send (attempt 1/3), retrying in 1s: httpx.ReadError`
   - `WARNING hermes_plugins.telegram_platform.adapter: [Telegram] Telegram polling conflict (4/5) — previous session still held open on Telegram's servers. Waiting 50s for it to expire.`

## 외부 통신 vs 워커 내부 통신 분리 진단

| 진단 | 명령 | 기대 결과 |
|---|---|---|
| 외부 DC 직접 통신 | `curl -sS --max-time 10 -o /dev/null -w "HTTP %{http_code} time=%{time_total}s\n" "https://api.telegram.org/bot${TOKEN}/getMe"` 3회 | 첫 요청 4~8초 가능, 이후 0.7~1초, 모두 HTTP 200 |
| fallback IP SSL mismatch | `curl -sS --max-time 6 -o /dev/null -w "HTTP %{http_code}\n" "https://149.154.166.110/"` | `SSL: no alternative certificate subject name matches target ipv4 address '149.154.166.110'` 에러 |

외부 DC 통신이 정상인데 워커만 polling 실패 = **워커 httpx 클라이언트만 망가진 상태**. 네트워크 / DNS / 봇 토큰은 정상.

## 해결 절차 (순서 엄수)

```
1. launchctl unload plist
2. 좀비 PID 3회 반복 kill -9 (PID가 launchd 캐시 때문에 자꾸 바뀜: 45490 → 46907 → 47493 → ...)
3. pkill -9 -f "hermes gateway" / pkill -9 -f "hermes_cli.main"
4. ps 확인: hermes 프로세스 0개
5. **텔레그램 서버측 좀비 세션 만료 50~60s 대기 (필수)**
6. launchctl load -w plist
7. 15초 대기 후 launchctl list | grep ai.hermes → 새 PID + exit 0
8. 30초 더 대기 (텔레 서버측에서 새 polling 연결 시도)
9. launchctl list 재확인 → PID 2분 이상 exit 0 유지
10. 사용자가 텔레그램에서 봇에게 메시지 전송 → 응답 검증
```

## 흔한 실수

- **워커만 재시작 (load → unload → load)** → 같은 sticky fallback 루프 반복
- **좀비 정리 안 하고 unload** → launchd가 옛 PID로 자동 재시작 → 같은 루프
- **텔레 서버측 좀비 세션 만료 대기 생략** → 새 부팅도 polling conflict 4/5로 즉시 막힘
- **sendMessage self-test로 검증 시도** → 워커가 살아있어 getUpdates를 잡고 있어서 sendMessage가 timeout됨. 사용자 메시지로만 검증 가능
- **외부 SIGTERM의 원인을 찾으려고 log show 추적** → 게이트웨이 `gateway.run` 로직 자체 버그 (under_systemd=yes 부모 인식). 추적 시간 낭비, Step 6 절차만 따라가면 됨

## 부가 관찰: under_systemd=yes SIGTERM 패턴

macOS launchd 환경인데 게이트웨이가 `under_systemd=yes parent_pid=1 parent_cmdline='(unknown)'` 로그를 남김. macOS에선 부자연스러운 표시. launchd가 충돌 감지 후 보내는 SIGTERM일 가능성이 큼 (KeepAlive.Crashed=true 동작). 이 자체는 별도 진단 항목이 아님 — Step 6 절차로 자동 해결.

## 진단 흐름 요약 (한 페이지)

```
증상: 봇 무반응
  ↓
launchctl list | grep ai.hermes
  ↓
[데몬 0개] → Step 0
[PID + -9] → Step 4 좀비 정리
[PID + 0 + ReadError 로그] → ★ Step 6 sticky fallback ★
[PID + 0 + 깨끗] → 다른 진단 (MCP / 화이트리스트 등)
```

## 관련 메모리 항목

- `**Telegram 워커 sticky fallback IP 함정 (06-30):**` 메모리 entry — 진단 시 자동 로드

## 검증 스크립트

```bash
#!/bin/bash
# sticky-fallback 진단 — 5초 안에 종합 판정
TOKEN=*** TELEGRAM_BOT_TOKEN ~/.hermes/.env | cut -d= -f2)

echo "=== [1] 데몬 상태 ==="
launchctl list 2>/dev/null | grep -iE "ai\.hermes" || echo "(데몬 없음)"

echo ""
echo "=== [2] getUpdates ==="
curl -sS --max-time 5 "https://api.telegram.org/bot${TOKEN}/getUpdates?timeout=0&limit=1"

echo ""
echo ""
echo "=== [3] sticky fallback 흔적 ==="
grep -E "sticky fallback|httpx\.ReadError|polling conflict" ~/.hermes/logs/gateway.err.log 2>/dev/null | tail -5

echo ""
echo "=== [4] 외부 DC 통신 (워커 httpx 분리 진단) ==="
for i in 1 2 3; do
  curl -sS --max-time 10 -o /dev/null -w "getMe $i: HTTP %{http_code} time=%{time_total}s\n" \
    "https://api.telegram.org/bot${TOKEN}/getMe"
  sleep 1
done

echo ""
echo "=== 판정 ==="
if grep -qE "sticky fallback" ~/.hermes/logs/gateway.err.log 2>/dev/null; then
  echo "★ Step 6 sticky fallback 함정 진단 확정 ★"
  echo "  → 좀비 정리 + 텔레 서버측 좀비 세션 50~60s 대기 + 깨끗한 부팅"
else
  echo "Step 6 함정 아님 — 다른 원인 (화이트리스트 / MCP / 토큰 등) 점검"
fi
```