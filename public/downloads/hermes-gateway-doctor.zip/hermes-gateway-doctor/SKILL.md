---
name: hermes-gateway-doctor
description: Use when Hermes Gateway 또는 텔레그램/디스코드/슬랙 봇이 메시지에 답장하지 않거나, 409 Conflict 에러가 나오거나, launchd 데몬이 좀비처럼 살아있거나, PC 교체 직후 텔레그램 봇이 무반응이거나, 워커는 살아있는데 `httpx.ReadError` polling 실패로 봇 무반응일 때. macOS에서 `~/Library/LaunchAgents/*.plist` 게이트웨이 등록/중복/부재 + 워커 충돌 + `.env` deprecated 경고 + 옛 사용자명 잔재 + 워커 sticky fallback IP SSL mismatch로 인한 polling 실패 + **단일 IP 환경 트랩 (`discover_fallback_ips()` 가 단일 IP 반환)** 까지 진단/조치. 7단계 진단 + 단일 IP 트랩 분기.
version: 1.3.0
author: Hermes Agent
license: MIT
platforms: [macos]
metadata:
  hermes:
    tags: [hermes, telegram, launchd, macos, doctor, gateway, post-migration, env-cleanup, sticky-fallback, single-ip-trap, warp-fallback]
    related_skills: [hermes-agent, "simplify-and-harden", "device-environment-migration"]
---

# Hermes Gateway Doctor

## Overview

Hermes Gateway(macOS launchd 데몬)가 텔레그램/디스코드 등 메시징 채널에서 답장을 안 하는 증상의 **근본 원인을 7단계로 진단하고 조치**합니다. 가장 흔한 원인은 `~/Library/LaunchAgents/`에 게이트웨이 plist가 **두 개 이상 동시 등록**되어 워커끼리 텔레그램 봇을 잡으려다 둘 다 SIGTERM으로 비정상 종료되는 것입니다. sendMessage는 정상(메시지 텔레 도착)인데 봇이 무반응이고 getUpdates가 `409 Conflict`로 떨어지면 이 워크플로우로 진단합니다.

**2026-06-26 추가**: PC 교체 / 사용자명 변경 후 **게이트웨이 부팅 자체가 실패**하는 케이스. plist 부재 또는 `.env` deprecated + 옛 사용자명 잔재가 원인. Step 0 (부팅 사전 점검) 신규.

**2026-06-30 추가**: 워커 httpx 클라이언트가 텔레그램 fallback IP(예: `149.154.166.110`)에 **sticky** 박혀서 SSL 인증서 mismatch로 `httpx.ReadError` 영구 루프. 데몬은 살아있고 exit 0인데 봇은 무반응. Step 6 신규.

**2026-07-12 추가**: Step 6 (좀비 정리 + 60~90s 대기 + 깨끗한 부팅)만으로 **환경 자체의 1차 DNS 차단이 박힌 케이스**에선 반복해도 본 문제 해결 불가. **WARP 가동 / `config.yaml`의 `force_primary` 또는 DNS-over-HTTPS 옵션 조정 / 포그라운드 워밍업** 등 사용자 옵션 제시로 분기 필수. `scripts/sticky-fallback-diagnose.sh` 가 obfuscated 텍스트 가드 패턴에 걸려 `syntax error near unexpected token ')'` 로 즉시 실패 — **레퍼런스 / SKILL.md에 inline으로 박힌 명령어 5개를 직접 `terminal`에 붙여 실행** 해야 함. `hermes gateway status` 의 `⚠ Service definition is stale relative to the current Hermes install` 경고도 plist 재작성 트리거로 해석해야 함 (그냥 죽은 게 아니라 게이트웨이는 살아있지만 plist가 옛 버전).

## When to Use

다음 증상 중 하나라도 보이면 즉시 트리거:

- 텔레그램에 보낸 메시지는 도착했지만 봇이 답장 안 함
- `getUpdates` 호출 시 `409 Conflict: terminated by other getUpdates request` 응답
- `launchctl list | grep hermes` 결과에 죽은 데몬(`-9` 종료 코드)이 PID와 함께 잔존
- `hermes gateway run`을 띄워도 곧바로 SIGTERM 받고 종료 (`parent_pid=(unknown)` 로그)
- `.env`에 `MESSAGING_CWD=~/.openclaw/workspace` 또는 `TERMINAL_CWD=...` deprecated 경고가 뜨면서 게이트웨이가 죽음
- **PC 교체 후 텔레그램 봇 무반응** (2026-06-26 추가) — `launchctl list | grep hermes` 결과 0개 = LaunchAgents plist 부재. `device-environment-migration` Phase 5.5와 함께 트리거
- **마이그레이션 후 `409 안 뜸 + .env에 옛 사용자명 잔재** (2026-06-26 추가) — 게이트웨이 부팅 자체 실패. .env 정리 우선 후 게이트웨이 재시작
- **워커는 살아있는데 봇 무반응 + `httpx.ReadError`** (2026-06-30 추가) — sticky fallback IP 함정. 데몬 PID + exit 0인데 `getUpdates`가 빈 배열, polling conflict 4/5 로그 반복, send도 ReadError. Step 6 진단.
- **`hermes gateway status` "Service definition is stale" 경고 + 봇 무반응** (2026-07-12 추가) — 게이트웨이 데몬은 PID + 정상 exit code로 살아있는데 `hermes gateway status`가 `⚠ Service definition is stale relative to the current Hermes install`를 띄움. plist가 현 Hermes 설치보다 옛 버전이라는 신호. 게이트웨이 본체는 작동 가능하지만 stale plist 자체가 다음 재시작 시점의 launchd 등록 불일치를 야기함. **즉시 `hermes gateway start`로 stale plist 교체 권장** (또는 수동으로 `~/Library/LaunchAgents/ai.hermes.gateway.plist` 백업 + 현 `config.yaml` 기준으로 재작성).
- **Step 6 절차 + 옵션 A/B를 여러 번 반복해도 `Primary path unreachable` 로그가 재발** (2026-07-12 추가) — 환경 자체에 1차 DNS 차단이 박혀있어 게이트웨이 절차로 해결 불가. WARP 가동 또는 회사망/ISP 정책 변경으로 차단 해소 필수. 사용자에게 옵션 4종 (WARP / force_primary / 포그라운드 워밍업 / 사용자 텔레 메시지 재시도) 제시.

Don't use for:

- 봇 토큰 자체가 잘못된 경우 (`getMe`가 실패) → `.env`의 `TELEGRAM_BOT_TOKEN` 점검
- 회사망이 텔레그램을 차단하는 경우 → WARP 또는 외부 WiFi 필요
- 단순히 cron이 안 도는 경우 → `cron-doctor` 스킬 사용
- 디스코드/슬랙 등 다른 채널 고장 → 일단 텔레그램으로 좁힌 다음 적용

## The 6-Step Diagnostic

### Step 0: 부팅 사전 점검 (2026-06-26 신규, 게이트웨이 부팅 자체 실패 케이스)

증상: `launchctl list | grep hermes` → 0개. 텔레그램 봇 무반응. sendMessage만 성공.

**0-1) LaunchAgents plist 부재 확인**:
```bash
ls -la ~/Library/LaunchAgents/ | grep -iE "hermes|gateway"
# 결과 없으면 → plist 신규 작성 필요 (아래 "plist 신규 생성" 참조)
```

**0-2) 게이트웨이 로그에 부팅 에러 확인**:
```bash
ls -la ~/.hermes/logs/gateway.{out,err}.log 2>&1
tail -20 ~/.hermes/logs/gateway.err.log 2>&1
# "Deprecated .env settings detected" → .env 정리 필요
# "MESSAGING_CWD=" 또는 "TERMINAL_CWD=" 또는 옛 사용자명(/Users/hjshin 등) → 후속 정리 필수
```

**0-3) .env에 옛 사용자명 / deprecated 키 잔재 확인** (P16 + P8 결합 함정):
```bash
echo "=== .env 옛 사용자명 잔재 ==="
grep -nE "/Users/<OLD>|/home/<OLD>" ~/.hermes/.env 2>/dev/null || echo "(없음)"
echo "=== .env deprecated 키 ==="
grep -nE "^MESSAGING_CWD=|^TERMINAL_CWD=" ~/.hermes/.env 2>/dev/null || echo "(없음)"
```

**0-4) .env 일괄 정리** (둘 다 있으면 fatal exit):
```bash
# 백업
cp ~/.hermes/.env ~/.hermes/.env.bak.$(date +%Y%m%d_%H%M%S)

# deprecated 키 제거
sed -i '' '/^MESSAGING_CWD=/d;/^TERMINAL_CWD=/d' ~/.hermes/.env

# 옛 사용자명 잔재는 device-environment-migration Phase 5.5-3의 Python walk_replace 패턴 사용
# (BSD sed 함정 회피)
```

**0-5) plist 신규 작성** (부재 시):
plist 경로: `~/Library/LaunchAgents/ai.hermes.gateway.plist`. 핵심 키:
- `Label`: `ai.hermes.gateway`
- `ProgramArguments`: `["/Users/<NEW>/.hermes/hermes-agent/venv/bin/python3", "/Users/<NEW>/.hermes/hermes-agent/venv/bin/hermes", "gateway", "run"]`
- `WorkingDirectory`: `/Users/<NEW>/.hermes/hermes-agent`
- `EnvironmentVariables`: `HERMES_HOME`, `VIRTUAL_ENV`, `PATH` (venv bin 우선)
- `RunAtLoad`: true
- `KeepAlive.Crashed`: true (재시작 자동)
- `StandardOutPath/StandardErrorPath`: `~/.hermes/logs/gateway.{out,err}.log`
- `ThrottleInterval`: 10

**0-6) load + 좀비 정리**:
```bash
plutil -lint ~/Library/LaunchAgents/ai.hermes.gateway.plist  # XML 검증
launchctl unload ~/Library/LaunchAgents/ai.hermes.gateway.plist 2>&1 || true
launchctl load -w ~/Library/LaunchAgents/ai.hermes.gateway.plist
sleep 8
launchctl list 2>/dev/null | grep -iE "ai\\.hermes"  # PID 살아있어야 정상
```

**완료 기준**: launchctl에 PID + 정상 exit code(0). 0 없거나 `-9` exit → 좀비 슬롯. Step 4로 진행.

### Step 1: 409 Conflict 재현

봇이 답장 안 하면 먼저 `getUpdates`로 충돌이 있는지 확인:

```bash
TOKEN=$(grep TELEGRAM_BOT_TOKEN ~/.hermes/.env | cut -d= -f2)
curl -sS --max-time 6 "https://api.telegram.org/bot${TOKEN}/getUpdates?timeout=0&limit=1"
```

**기대 결과 해석**:

- `{"ok":true,"result":[]}` → 워커 부재 상태로 정상. 봇이 답장 안 하는 다른 원인.
  - **단, `err.log`에 `httpx.ReadError` 또는 `polling conflict`가 반복 보이면 → 단순 부재가 아니라 Step 6 sticky fallback IP 함정 가능성 큼.** 외부에서 `getMe`를 3회 워밍업 후에도 빈 배열 유지 + send가 ReadError면 Step 6으로 즉시 분기.
- `{"ok":false,"error_code":409,"error":"Conflict: terminated by other getUpdates request; make sure that only one bot instance is running"}` → **이 스킬의 핵심 진단 대상**.

**완료 기준**: `error_code: 409`가 응답에 포함되면 Step 2로 진행. 409가 안 뜨고 err.log에 ReadError/polling conflict가 있으면 Step 6으로 분기.

### Step 2: launchd 좀비 슬롯 찾기

데몬이 살아있지만 죽어있는 상태를 찾습니다:

```bash
launchctl list 2>/dev/null | grep -iE "hermes|icbm"
```

**기대 출력 예시**:

```
18942   -9   ai.hermes.gateway
18880   -9   com.icbm2.hermes-gateway
```

**판독 규칙**:

- 두 번째 컬럼이 `-9` (SIGKILL 종료) 또는 `-15` (SIGTERM)면 좀비 슬롯
- **Label이 2개 이상이면 100% 충돌 원인**. 이 스킬의 정확한 적.
- Label이 `com.icbm2.hermes-gateway`처럼 메인 워커 디렉토리(`~/.hermes/hermes-agent`)가 아닌 다른 곳에서 띄우는 게이트웨이면 거의 확실히 중복 데몬

**Label 구분법**:

| Label | 정식/중복 | 근거 |
|---|---|---|
| `ai.hermes.gateway` | ✅ 정식 | `/Users/hjshin/.hermes/hermes-agent` 워킹디렉토리, VIRTUAL_ENV/HERMES_HOME 설정 |
| `com.icbm2.hermes-gateway` | ❌ 중복 가능성 큼 | `~/.openclaw/workspace` 워킹디렉토리, KeepAlive=true, 환경변수 누락 |

**완료 기준**: 좀비 슬롯의 Label과 PID가 명확히 식별됨.

### Step 3: plist 백업 + 비활성화

두 plist 모두 백업 후 `.disabled`로 이름 변경:

```bash
cd ~/Library/LaunchAgents
TS=$(date +%s)
for label in ai.hermes.gateway com.icbm2.hermes-gateway; do
  f="$label.plist"
  [ -f "$f" ] && cp "$f" "${f}.bak.${TS}" && mv "$f" "${f}.disabled"
done
ls -la *.bak.* *.disabled 2>&1
```

**완료 기준**: 두 plist 모두 `.disabled`로 이름 변경되고 `.bak.<ts>` 백업본이 같은 디렉토리에 존재.

### Step 4: 좀비 PID 강제 종료

launchd 캐시가 옛 슬롯을 기억하고 있어 `.disabled` 이름 변경만으로는 부족할 수 있음. 3회 반복 종료:

```bash
for attempt in 1 2 3; do
  pids=$(launchctl list 2>/dev/null | awk '$3 ~ /hermes|icbm/ && $1 ~ /^[0-9]+$/ {print $1}')
  [ -z "$pids" ] && echo "시도 $attempt: 좀비 없음" && break
  echo "$pids" | while read pid; do kill -9 "$pid" 2>/dev/null; done
  pkill -9 -f "hermes_cli.main" 2>/dev/null
  pkill -9 -f "hermes gateway" 2>/dev/null
  sleep 1
done
launchctl list 2>/dev/null | grep -iE "hermes|icbm" || echo "(데몬 모두 정리됨)"
```

**완료 기준**: `launchctl list | grep hermes` 출력 없음 (또는 `-` PID, `-9` exit code만 남음).

### Step 5: Self-Test 메시지 발송

봇 API 자체가 살아있는지 확인:

```bash
TOKEN=$(grep TELEGRAM_BOT_TOKEN ~/.hermes/.env | cut -d= -f2)
ALLOWED=$(grep TELEGRAM_ALLOWED_USERS ~/.hermes/.env | cut -d= -f2 | tr -d ' "')
MY_ID=$(echo "$ALLOWED" | cut -d, -f1)
curl -sS --max-time 8 -X POST "https://api.telegram.org/bot${TOKEN}/sendMessage" \
  -d chat_id="$MY_ID" \
  -d text="🩺 Hermes Gateway Doctor self-test"
```

**응답 예시**:

```json
{"ok":true,"result":{"message_id":18522,"chat":{"id":8359527845,...}}}
```

**완료 기준**: `ok:true` + `message_id` 응답. 사용자 텔레그램에서 메시지 도착 확인.

### Step 6: Sticky Fallback IP 함정 (2026-06-30 신규)

워커 httpx 클라이언트가 텔레그램 fallback IP에 박혀서 SSL 인증서 mismatch로 polling이 영구 실패하는 케이스. 데몬은 살아있고 exit 0인데 봇 무반응.

**6-1) 증상 확인**:
```bash
# 데몬 살아있는지
launchctl list 2>/dev/null | grep -iE "ai\.hermes"
# exit code 0 + 살아있는 PID → 정상 부팅

# getUpdates 빈 배열 확인
TOKEN=$(grep TELEGRAM_BOT_TOKEN ~/.hermes/.env | cut -d= -f2)
curl -sS --max-time 5 "https://api.telegram.org/bot${TOKEN}/getUpdates?timeout=0&limit=1"
# {"ok":true,"result":[]} → 워커가 polling 못 잡음

# err.log에 sticky fallback 흔적
grep -E "sticky fallback|httpx\.ReadError|polling conflict" ~/.hermes/logs/gateway.err.log | tail -10
# "Primary api.telegram.org path unreachable; using sticky fallback IP 149.154.166.110" + ReadError + polling conflict 4/5
```

**6-2) 외부 DC 직접 통신 검증** (워커 httpx 문제 분리):
```bash
# 외부에서 getMe 3회 연속 — 첫 1회는 4~8초 느릴 수 있음, 이후 0.7~1초 정상
for i in 1 2 3; do
  curl -sS --max-time 10 -o /dev/null -w "getMe $i: HTTP %{http_code} time=%{time_total}s\n" \
    "https://api.telegram.org/bot${TOKEN}/getMe"
  sleep 1
done
# 전부 200 + 1초 미만 → 워커 외부 통신 정상 = 워커 내부 httpx만 망가짐
```

**6-3) fallback IP SSL mismatch 직접 검증**:
```bash
# fallback IP의 SSL 인증서가 텔레그램 공식이 아님을 확인
curl -sS --max-time 6 -o /dev/null -w "fallback IP: HTTP %{http_code}\n" "https://149.154.166.110/"
# SSL: no alternative certificate subject name matches target ipv4 address '149.154.166.110'
# → sticky fallback IP는 SSL mismatch로 httpx가 ReadError로 실패
```

**6-3.5) 단일 IP 환경 트랩 확인** (2026-07-12 추가, 거의 항상 같이 발현):
```bash
# 워커가 발견한 IP 직접 검증 (in-process 실행)
cd ~/.hermes/hermes-agent && ./venv/bin/python3 -c "
import asyncio
from plugins.platforms.telegram.telegram_network import discover_fallback_ips
async def main():
    ips = await discover_fallback_ips()
    print('discover_fallback_ips() ->', ips)
asyncio.run(main())
" 2>&1 | tail -3
# 출력: ['149.154.166.110'] (단일 IP) → STEP 6 사일런트 함정

# Google DoH 응답도 단일 IP만 반환하는지 확인
curl -sS --max-time 8 "https://dns.google/resolve?name=api.telegram.org&type=A" \
  | python3 -c "import json,sys; d=json.load(sys.stdin); print([a['data'] for a in d.get('Answer',[])])"
# ["149.154.166.110"] → 이 망의 A 레코드가 진짜로 단일 IP로 수렴

# SSL 인증서 chain은 정상인지 (SNI 보존 verify)
echo | openssl s_client -servername api.telegram.org -connect 149.154.166.110:443 2>&1 \
  | grep -E "subject=|verify return:|no alternative" | head -5
# subject=/CN=api.telegram.org + verify return:1 → 인증서는 OK. IP 직결 시 httpx 내부 검증 디테일 차이.
```

**판정**: 단일 IP + 외부 `curl`/`openssl s_client` 정상 + 워커만 fail → **환경 함정이 본질**. 워커는 `if request.url.host != _TELEGRAM_API_HOST or not self._fallback_ips: return await self._primary.handle_async_request(request)` 의도였는데, fallback IP가 1개라도 있으면 primary 대신 무조건 IP-rewrite path (`_rewrite_request_for_ip`) 로 가버림. 도메인 직접 연결을 안 합니다. 따라서:
- 외부 curl 0.8초 정상이어도 워커는 박힘
- 6-7 (Step 6 절차 반복) 만으로는 못 풀음 — 환경의 단일 IP 매핑이 원인

**판별**: `discover_fallback_ips() -> ['단일 IP']` AND 외부 `curl getMe` 정상 → 즉시 6-7 (사용자 옵션 분기) 점프.

**6-4) 워커 재시작 (단, 좀비 정리 먼저)**:
```bash
launchctl unload ~/Library/LaunchAgents/ai.hermes.gateway.plist 2>&1
sleep 3

# 좀비 3회 반복 종료 (Step 4와 동일)
for attempt in 1 2 3; do
  pids=$(launchctl list 2>/dev/null | awk '$3 ~ /hermes/ && $1 ~ /^[0-9]+$/ {print $1}')
  [ -z "$pids" ] && echo "좀비 정리 완료" && break
  echo "좀비 PID = $pids 정리"
  echo "$pids" | while read pid; do kill -9 "$pid" 2>/dev/null; done
  pkill -9 -f "hermes gateway" 2>/dev/null
  sleep 1
done
ps aux | grep -E "hermes gateway" | grep -v grep || echo "(프로세스 0개)"
```

**6-5) 텔레그램 서버측 좀비 세션 만료 대기 (50~60s)**:
```bash
# 새 부팅 전 필수: 텔레 서버측에서 옛 세션 만료 + sticky IP 캐시 무효화 대기
echo "텔레그램 서버측 좀비 세션 만료 대기 (60s)..."
sleep 60
```

**6-6) 깨끗한 부팅**:
```bash
launchctl load -w ~/Library/LaunchAgents/ai.hermes.gateway.plist
sleep 15
launchctl list 2>/dev/null | grep -iE "ai\.hermes"
# 새 PID + exit 0 + 2분 이상 살아있으면 정상 복구
```

**6-7) 사용자 메시지 검증 + 환경 적중 진단** (2026-07-12 보강):
텔레그램에서 봇에게 "테스트" 메시지 전송 → 봇 응답 와야 정상. 안 오면 환경 적중 진단 후 사용자 옵션 분기.

6-7.1) 환경 적중 진단 (WARP 가동 + 외부 IP 확인):
```bash
# WARP 설치 여부
ls /Applications/Cloudflare\ WARP.app 2>&1 | head -2
ps aux | grep -iE "Cloudflare.WARP" | grep -v grep | head -2
# → 설치 안 되어 있으면 옵션 A (WARP 설치) 가 1순위

# WARP 가동 후 외부 IP 변화 (WARP off면 한국 ISP IP, on이면 colo=ICN 등)
curl -sS --max-time 8 "https://api.cloudflare.com/cdn-cgi/trace" 2>&1 \
  | grep -E "^(ip=|colo=|loc=)"
# ip=KT 한국 IP (WARP off) vs colo=SEA/LAX (WARP on)
```

6-7.2) **사용자 옵션 분기** (`discover_fallback_ips()` 가 단일 IP를 반환하는 환경에서만 효과):

| 옵션 | 명령 | 트레이드오프 |
|---|---|---|
| **A. WARP 가동 (가장 정공법)** | 메뉴바 아이콘에서 WARP ON 토글. 또는 `brew install --cask cloudflare-warp` 후 `warp-cli connect`. sudo 없이 메뉴바 토글로 충분 | 설치는 영구, 토글은 즉시. 회사망이 텔레그램 차단일 때 1순위. |
| **B. `hermes gateway start` (stale plist 자동 교체)** | 게이트웨이 데몬이 살아있어도 stale plist 자체가 다음 재시작 시점의 launchd 등록 불일치를 야기함. 즉시 권장. | 데몬은 작동 가능하지만 plist 재작성으로 launchd 등록 정합성 회복 |
| **C. 포그라운드로 한 번 띄우기 (검증용)** | `cd ~/.hermes/hermes-agent && ./venv/bin/hermes gateway run --replace`. Ctrl+C 종료. launchd SIGTERM 루프 없이 깨끗한 환경. | 검증용 1회성. 다음 로그인 시 자동 시작 안 됨 |
| **D. 사용자 텔레 메시지 재전송** | 옵션 A~C 적용 후 텔레에서 봇에 "테스트" 발사. 부팅 직후 1~2분 워밍업 시간에 메시지 도달 시 봇 응답 가능 | sendMessage self-test는 false positive 가능 (워커가 살아있어 send가 timeout되거나 응답 와도 봇 polling과 무관). 사용자 메시지로만 검증 |

**판별 가드레일**:
- `discover_fallback_ips()` 가 단일 IP AND 옵션 A (WARP) 미설치 → 옵션 A 설치 + 토글 안내
- `discover_fallback_ips()` 가 단일 IP AND WARP ON인데도 박힘 → 회사망이 `149.154.0.0/16` 자체를 차단. 옵션 B/C/D만 시도
- `hermes gateway status` 에서 `⚠ Service definition is stale` → 옵션 B 즉시 권장 (게이트웨이 본체는 멀쩡해도 plist 재작성 권장)

**완료 기준**: 옵션 D 로 검증 후 봇 응답. 응답 옴 = 정상. 여전히 무반응 = 워커 패치 (`force_primary` 또는 sticky disable 코드 변경) — 이건 스킬 밖의 워커 변경 사항.

## 정식 게이트웨이 재시작 (사용자 직접)

좀비 정리 후 워커를 새로 띄워야 봇이 답장합니다. **포그라운드로 띄우면 터미널 종료 시 같이 죽으므로** launchd 데몬 복구 권장:

### 옵션 A: 단일 데몬 영구 복구 (권장)

```bash
# 중복 plist 영구 보관, 정식 plist만 복구
cd ~/Library/LaunchAgents
mv ai.hermes.gateway.plist.disabled ai.hermes.gateway.plist
launchctl load -w ~/Library/LaunchAgents/ai.hermes.gateway.plist
# com.icbm2.hermes-gateway.plist.disabled 는 그대로 두기 (영구 비활성)
```

### 옵션 B: 수동 포그라운드 (일회성 검증)

```bash
cd ~/.hermes/hermes-agent
/Users/hjshin/.hermes/hermes-agent/venv/bin/hermes gateway run --replace
# Ctrl+C 로 종료됨 — 다음 로그인 시 자동 시작 안 됨
```

**완료 기준**: 새 메시지 전송 시 봇이 답장함.

## Common Pitfalls

1. **`launchctl bootout` "Operation not permitted"** — 사용자 권한으로는 unload 못 할 수 있음. `kill -9 <pid>` 직접 종료로 우회. `.disabled`로 launchd 인식 못 하게 하는 게 본질적 해결.

2. **좀비 재탄생** — launchd가 옛 슬롯을 캐시에서 안 잊어서 PID가 자꾸 바뀜 (예: 19248 → 19289). 3회 반복 kill + `.disabled` 이름 변경으로 영구 차단.

3. **`parent_pid=(unknown) parent_cmdline='(unknown)'`** — 게이트웨이가 정상 부팅 후 누군가 SIGTERM 보냄. 보통 launchd의 다른 데몬이 충돌 감지하고 죽인 것. `log show --last 5m --predicate 'eventMessage contains "hermes"'`로 누가 보냈는지 추적 가능.

4. **`.env` deprecated 경고 무시하면 죽음** — `MESSAGING_CWD`, `TERMINAL_CWD` 키는 deprecated. 게이트웨이가 부팅 후 죽을 수 있음. config.yaml로 옮겨야 함:
   ```yaml
   # ~/.hermes/config.yaml
   terminal:
     cwd: /Users/hjshin/Desktop/project/work/ai
   ```

5. **두 plist가 동시에 살아있으면 영원히 충돌** — 하나만 살리고 나머지는 `.disabled` 영구 보관 또는 삭제. 둘 다 살리는 건 구조적 결함.

6. **macOS에 `timeout` 명령 없음** — `ping -W 2000` 또는 `gtimeout` 사용 (없으면 `curl --max-time`로 우회).

7. **WARP가 살아있어도 회사망 차단 정책 확인** — `149.154.166.0/24` (Telegram DC) 차단이 회사 방화벽에 있으면 WARP 우회 안 될 수 있음. `1.1.1.1` 차단도 마찬가지.

8. **`.env`에 옛 사용자명 잔재 + deprecated 키 결합** (2026-06-26 발견) — 마이그레이션 후속 정리에서 가장 위험한 패턴. `MESSAGING_CWD=/Users/hjshin/.openclaw/workspace` 같이 **옛 사용자명 + deprecated 경고가 동시에** 있으면 게이트웨이 부팅 → deprecated 감지 → 즉시 죽음. 단순 경고지만 fatal exit. .env의 deprecated 키 제거 + 사용자명 일치 확인이 **둘 다** 필요. `device-environment-migration` 스킬의 Phase 5.5와 함께 사용.

9. **마이그라운데이션 후 LaunchAgents plist 부재** (2026-06-26 발견) — PC 교체 시 `~/Library/LaunchAgents/`는 자동 백업 안 됨 (사용자 레벨 디렉토리라 Hermes 백업 범위 밖). 새 PC에서 게이트웨이 데몬 자동 시작 X → 텔레그램 봇 무반응의 **두 번째로 흔한 원인**. 증상은 "409 안 뜸" + `launchctl list | grep hermes` 0개. 해결은 `~/Library/LaunchAgents/ai.hermes.gateway.plist` 신규 작성 + `launchctl load -w`.

10. **409 Conflict가 워커 정상 신호일 수 있음** (확인됨, 2026-06-26 검증) — 게이트웨이가 정상 가동 중이면 `getUpdates`가 `409 Conflict: terminated by other getUpdates request` 응답. **에러처럼 보이지만 워커가 polling 잡고 있다는 뜻**. 단, 사용자 메시지에 봇이 답장하지 않으면 진짜 워커 결함. self-test sendMessage 후 응답 와서 사용자 텔레에 도착했는지로 판별.

11. **Sticky Fallback IP 함정** (2026-06-30 발견) — 워커 httpx가 텔레그램 fallback IP(예: `149.154.166.110`)에 sticky 박힘. SSL 인증서가 텔레그램 공식이 아니라 `httpx.ReadError` 영구 루프. 증상: 데몬 PID + exit 0 정상, `getUpdates` 빈 배열, send도 ReadError, `polling conflict 4/5` 로그 반복. **반드시 재시작 전 좀비 정리 + 텔레 서버측 좀비 세션 만료 50~60s 대기 후 부팅**. 워커 재시작만 하면 같은 루프 반복. 외부 `getMe`가 0.7~1초로 정상 = 워커 외부 통신 정상, 워커 httpx만 망가진 상태이므로 위 진단 흐름이 정확.

12. **`under_systemd=yes parent_pid=1 parent_cmdline='(unknown)'` SIGTERM** (2026-06-30 관찰) — macOS에서 게이트웨이가 `under_systemd=yes`로 표시되며 PID 1 부모로 SIGTERM 받는 패턴. launchd 환경에서 부모를 systemd로 잘못 인식하는 게이트웨이 `gateway.run` 로직의 버그 가능성. SIGTERM이 들어오면 KeepAlive.Crashed=true가 자동 재시작시키지만, sticky fallback 상태면 같은 에러로 반복. **근본 해결은 Step 6의 좀비 정리 + 세션 만료 대기로만**. 이 자체는 별도 진단 항목이 아님.

13. **단일 IP 환경 트랩 + Step 6 절차 한계** (2026-07-12 실측 확정) — `discover_fallback_ips()` 결과가 `['149.154.166.110']` 처럼 **단일 IP로 수렴**하는 환경에서는 Step 6의 (좀비 정리 + 90s 대기 + 깨끗 부팅)을 **여러 번 반복**해도 즉시 `Primary api.telegram.org path unreachable; using sticky fallback IP` 로그가 재발. 워커 소스 (`telegram_network.py`)의 의도는 `if request.url.host != _TELEGRAM_API_HOST or not self._fallback_ips: return await self._primary.handle_async_request(request)` — 즉 fallback이 0개일 때만 primary로 가도록 의도했는데, fallback 1개라도 있으면 무조건 IP-rewrite path (`_rewrite_request_for_ip`) 로 가버림. 도메인 직접 연결을 **안 합니다**. 외부 `curl getMe` 0.8초 정상이어도 워커는 박힘.

    **판별 실측치 (2026-07-12 mac 시드 PC)**:
    - 외부 `curl https://api.telegram.org/bot${TOKEN}/getMe` → 200 OK, 0.79~0.84초 (curl + 시스템 DNS + 시스템 trust store)
    - `dig api.telegram.org @168.126.63.1` → `149.154.166.110` (KT DNS도 단일 IP)
    - `curl https://dns.google/resolve?name=api.telegram.org&type=A` → `Answer: ["149.154.166.110"]` (Google DoH도 단일 IP)
    - 워커 `discover_fallback_ips() -> ['149.154.166.110']`
    - `openssl s_client -servername api.telegram.org -connect 149.154.166.110:443` → `verify return:1` + `subject=/CN=api.telegram.org` (인증서 chain 정상)

    → **인증서는 정상인데 워커 httpx만 IP 직결에서 즉시 fail**. `Primary ... connection failed ();` 의 `();` 은 `str(exc)` 가 빈 문자열이 된 케이스. 진단 정보 부족. 환경 적중 후 사용자 옵션 분기 (Step 6 6-7.2 표 참조).

    **sendMessage self-test는 false positive 가능** — 워커가 살아있어 send가 timeout되거나 응답 와도 봇의 polling과 무관. 검증은 사용자 텔레 메시지로만.

14. **진단 스크립트 `syntax error near unexpected token ')'` 함정** (2026-07-12 신규) — `scripts/sticky-fallback-diagnose.sh` 가 obfuscated 텍스트 가드 패턴 (`TOKEN=*** TELEGRAM_BOT_TOKEN ...` 에서 `***` 같은 placeholder가 그대로 박혀있어 bash가 인식 실패)에 걸려 `bash: syntax error near unexpected token ')'` 즉시 실패. **절차: 스크립트 직접 실행 금지. SKILL.md / `references/sticky-fallback-diagnosis.md`에 inline으로 박힌 5단계 명령어 (`launchctl list` → `getUpdates` → sticky fallback grep → `getMe` ×3 → fallback IP SSL curl) 를 `terminal`에 직접 붙여 실행** — 더 빠르고 안정적. 스크립트는 현 상태에선 사용 불가.

15. **`hermes gateway status`의 "Service definition is stale" 경고** (2026-07-12 신규) — 게이트웨이 데몬은 PID + 정상 exit code로 살아있는데 `hermes gateway status`가 `⚠ Service definition is stale relative to the current Hermes install` + `Run: hermes gateway start` 힌트를 띄움. **해석**: plist 자체가 현 Hermes 설치보다 옛 버전. 데몬이 작동 중일 땐 현 상태 유지하되, 다음 재시작 시점의 launchd 등록 불일치를 막으려면 `hermes gateway start` 로 stale plist 교체 권장 (Step 6 6-7.2 옵션 B). 증상 자체는 봇 무반응이 아니더라도, "재시작 후에도 다시 stale" 루프가 보이면 즉시 처리.

16. **sudo 없이 DNS resolver 우회 불가 (2026-07-12 관찰)** — `sudo networksetup -setdnsservers Wi-Fi 1.1.1.1` 같은 시스템 레벨 DNS 변경은 사용자 PTY 컨텍스트에서 sudo 비밀번호 입력 필수. PTY 모드로 우회 가능하지만 **자동 진단에서 시도 비권장**. 대신 단계별 우회 우선: (1) WARP 가동 (sudo 불필요) → (2) `~/.hermes/config.yaml` 의 telegram 섹션 옵션 → (3) 워커 patch. sudo 의존성 우회하려다 시간 낭비 금지.

17. **같은 `v0.19.0`이어도 소스·launchd 환경이 다를 수 있음 (2026-07-22 실측)** — 버전 문자열, Python, macOS, WARP가 같아도 `git status --short`, `git rev-parse HEAD`, Telegram 파일 SHA-256, 실행 프로세스 `ps eww`를 반드시 비교한다. 정상 M4에서 실제 결정적 차이는 `plugins/platforms/telegram/telegram_network.py`의 미커밋 패치와 launchd `HERMES_TELEGRAM_DISABLE_FALLBACK=1`이었다. 이 **단수형** 변수는 해당 커스텀 패치가 있을 때만 discovery를 건너뛴다. stock adapter가 이미 인식하는 별도 변수는 **복수형** `HERMES_TELEGRAM_DISABLE_FALLBACK_IPS=1`이며, fallback transport 선택만 끈다. 둘을 같은 변수로 혼동하지 말 것. 비교 명령:
   ```bash
   git -C ~/.hermes/hermes-agent status --short
   git -C ~/.hermes/hermes-agent rev-parse HEAD
   shasum -a 256 ~/.hermes/hermes-agent/plugins/platforms/telegram/{telegram_network.py,adapter.py}
   PID=$(pgrep -f 'hermes gateway run' | head -1)
   ps eww -p "$PID" | tr ' ' '\n' | grep -E '^(HERMES_TELEGRAM_|DYLD|LD_|HTTPS?_PROXY|ALL_PROXY|NO_PROXY)='
   ```

18. **`_queue_SimpleQueue_get_impl`은 보통 hang 원인이 아니라 idle ThreadPoolExecutor (2026-07-22 실측)** — 정상 gateway의 native `sample`에서도 여러 worker가 `_PyEval_EvalFrameDefault → method_vectorcall_FASTCALL_KEYWORDS_METHOD → _queue_SimpleQueue_get_impl → __psynch_cvwait`에 있다. 이는 `concurrent.futures.thread._worker()`의 `work_queue.get(block=True)`에서 다음 작업을 기다리는 정상 idle 상태다. 이 스택만 보고 `Application.initialize()` Future가 막혔다고 결론내리지 않는다. 정상 M4의 **main thread**는 `select_kqueue_control_impl → kevent`; M1의 main thread 자체가 SimpleQueue라면 (a) 잘못된 PID를 sample했거나 (b) asyncio loop가 다른 스레드에서 돌고 있는지 먼저 확인하고, `kevent`, `socket_getaddrinfo`, SSL/httpcore 프레임이 있는 실제 loop/network thread를 찾는다. native `sample`의 `_PyEval_EvalFrameDefault` 주소만으로 Python await 함수명을 확정할 수 없으므로, stdlib stack shape·source 또는 `py-spy`/faulthandler를 함께 써야 한다.

19. **bare PTB `Application.initialize()`로 launchd/Hermes 경계를 먼저 자르기 (2026-07-22 실측)** — 정상 M4에서 launchd와 무관한 대화형 셸의 같은 venv로 `Application.builder().token(token).build(); await app.initialize()`가 1.408초에 성공했다. 따라서 launchd 등록 자체는 PTB `getMe` 초기화의 필수 조건이 아니다. M1에서 같은 최소 테스트가 hang하면 원인은 Hermes adapter 위가 아니라 **PTB/httpx/SSL/DNS/WARP/토큰 경로**다. 최소 테스트가 성공하지만 gateway만 hang하면 **Hermes의 커스텀 request/transport, 중복 gateway, lifecycle**로 범위를 좁힌다. 토큰은 출력하지 말고 `.env`에서 로컬로 읽는다.

20. **WARP 연결 직후 시작 race는 시작 시각으로 검증 (2026-07-22 실측)** — 정상 M4의 WARP 프로세스는 07:38:34, launchd gateway는 07:46:06에 시작되어 약 7분 32초의 선행 워밍업이 있었다. WARP `Connected/healthy` 표시 직후에도 DNS·route·NetworkExtension 전파가 덜 끝났을 가능성을 배제할 수 없다. 재현 불규칙 시 `warp-cli disconnect/connect` 직후 gateway를 띄우지 말고, (1) `warp-cli status`, (2) `route -n get 149.154.166.110`이 `utun0`, (3) venv `httpx GET https://api.telegram.org` 10초 이내 성공, (4) bare PTB initialize 성공을 확인한 뒤 launchd gateway를 시작한다. 단, 이 시간 순서는 상관관계이며 단독으로 인과를 확정하지 않는다.

## Verification Checklist

진단 완료 후 다음을 모두 확인:

- [ ] `launchctl list | grep -E "hermes|icbm"` 출력에 PID + 정상 exit code(0)
- [ ] `~/Library/LaunchAgents/ai.hermes.gateway.plist` 존재 + `plutil -lint` OK
- [ ] `~/.hermes/.env`에 `MESSAGING_CWD=`, `TERMINAL_CWD=` deprecated 키 없음
- [ ] `~/.hermes/.env`에 옛 사용자명(`/Users/<OLD>`) 잔재 없음
- [ ] `~/.hermes/logs/gateway.err.log`에 "Deprecated .env settings detected" 없음
- [ ] `~/.hermes/logs/gateway.err.log`에 MCP 서버 initial connection failed가 1분 이상 지속 안 됨 (3회 후 포기 OK)
- [ ] `getUpdates` 호출 시 `409 Conflict` 응답 (워커 정상 신호)
- [ ] **Step 6 함정 아닌지**: err.log에 `httpx.ReadError` 또는 `polling conflict` 반복 + `sticky fallback IP 149.154.166.110` 흔적 없는지
- [ ] **Step 6 진단 시**: 좀비 정리 + 텔레 서버측 좀비 세션 60s 대기 + 깨끗한 부팅 후 새 PID 2분 이상 exit 0 유지
- [ ] `sendMessage` self-test 성공 (`ok:true`, `message_id` 응답) — Step 6에서 워커가 살아있어 sendMessage가 timeout될 수 있음, 이 경우 워커 응답 검증은 사용자 메시지로만
- [ ] 사용자 텔레그램에 self-test 메시지 도착 확인
- [ ] 게이트웨이 재시작 후 새 메시지 → 봇 답장 확인

## Quick-Reference: 한 줄 진단

```bash
TOKEN=$(grep TELEGRAM_BOT_TOKEN ~/.hermes/.env | cut -d= -f2) && \
curl -sS --max-time 5 "https://api.telegram.org/bot${TOKEN}/getUpdates?timeout=0&limit=1" && \
echo "" && launchctl list 2>/dev/null | grep -iE "hermes|icbm" || echo "(데몬 없음)"
```

출력에 `error_code: 409` + `launchctl`에 `-9` 좀비 → 이 스킬의 정확한 타겟. 위 5단계 즉시 진행.

**(데몬 자체가 0개면 — `launchctl list | grep hermes` 결과 없음)** → Step 0으로 분기. plist 신규 작성 + .env 정리 먼저.

**(데몬 PID + exit 0인데 `getUpdates` 빈 배열 + err.log에 `httpx.ReadError`/`polling conflict`/`sticky fallback IP` 흔적)** → Step 6으로 분기.

**6-3.5 단일 IP 환경 트랩 감지**:
```bash
cd ~/.hermes/hermes-agent && ./venv/bin/python3 -c "
import asyncio
from plugins.platforms.telegram.telegram_network import discover_fallback_ips
print(asyncio.run(discover_fallback_ips()))
"
```
출력 = `['149.154.166.110']` (단일 IP) → 6-7 사용자 옵션 분기로 즉시 점프. Step 6 본 절차 (6-4 ~ 6-6) 반복은 시간 낭비.

**판정 매트릭스** (2026-07-12 확정):

| 데몬 상태 | getUpdates | sticky fallback 로그 | 외부 curl | discover_fallback_ips() | 진단 |
|---|---|---|---|---|---|
| 0개 | ok:result[] | 없음 | 정상 | - | Step 0 |
| -9 좀비 | ok:result[] | 없음 | 정상 | - | Step 4 (좀비 정리) |
| exit 0 + PID | **빈 배열** | **있음** | 정상 | 단일 IP | **Step 6 → 6-7 (단일 IP 트랩)** |
| exit 0 + PID | 409 Conflict | 없음 | 정상 | - | 워커 정상 (False 진단) |
| exit 0 + PID | ok:result[] | 없음 | **timeout** | - | 외부망 차단 → WARP |

**`hermes gateway status`** 가 `⚠ Service definition is stale` 띄우면 → 데몬이 살아있어도 `hermes gateway start` 로 plist 재작성 권장 (다음 재시작 시점 대비).

## Related Reference

증상이 메시지 텔레 도착 X (전송 자체 실패)면 → 네트워크 차단. WARP 활성 여부 + `1.1.1.1` ping + `getMe` 호출로 분리 진단.
증상이 cron 자동 발송은 정상인데 사용자 메시지에만 반응 없음 → `TELEGRAM_ALLOWED_USERS` 화이트리스트 확인.
증상이 PC 교체 직후 발생 → `device-environment-migration` Phase 5.5 (.env + LaunchAgents 후속 정리)와 동시 트리거.
증상이 `~/.hermes/logs/gateway.err.log`에 `minimax` 또는 `ddg-search` MCP connection failed → 해당 MCP 서버 비활성화 (`config.yaml` mcp_servers 블록 제거). 단, `hermes-cli` toolsets에 web_search 포함되어 있어 MCP ddg-search 부재해도 웹 검색은 정상.

**증상이 데몬 PID + exit 0인데 봇 무반응 + `httpx.ReadError`/`polling conflict`/`sticky fallback IP`** → `references/sticky-fallback-diagnosis.md` 참조. Step 6의 재현 레시피 + err.log 패턴 + 텔레 서버측 좀비 세션 만료 흐름이 정리되어 있음. **빠른 진단은 `references/sticky-fallback-diagnosis.md` 의 5단계 inline 명령어를 `terminal`에 직접 붙여 실행** (`scripts/sticky-fallback-diagnose.sh` 는 2026-07-12 현 시점 obfuscated 가드 패턴 때문에 syntax error로 실패 — 스크립트 사용 금지).

## Support Files

- `references/sticky-fallback-diagnosis.md` — Step 6의 발생 조건, 핵심 증상, 외부 vs 워커 통신 분리, 해결 절차 순서, 흔한 실수, 한 페이지 진단 흐름
- `references/sticky-fallback-recurrence-2026-07-12.md` — Step 6 절차가 한계인 케이스 실측 (WARP / force_primary / 포그라운드 / 사용자 메시지 재전송 4종 옵션, stale plist 경고 트리거, 진단 스크립트 syntax error 함정). SKILL.md Pitfall 13/14/15 원자료.
- `references/sticky-fallback-single-ip-trap-2026-07-12.md` — `discover_fallback_ips() -> ['149.154.166.110']` 단일 IP 환경 트랩 실측. 워커 소스 의도 vs 실제 동작 차이, getMe/dig/openssl s_client 전수 데이터, sendMessage self-test false positive 가드레일, 워커 patch 3안 (`disable_fallback` / `_DOH_TIMEOUT=0.001` / 빈 리스트 강제). SKILL.md Step 6 6-3.5 + Pitfall 13 원자료.
- `scripts/sticky-fallback-diagnose.sh` — 2026-07-12 현 시점 obfuscated 가드 패턴 때문에 `syntax error`로 실패 — **사용 금지**. `references/sticky-fallback-diagnosis.md`의 inline 5단계 명령어를 `terminal`에 직접 붙여 실행할 것.
