---
name: hermes-gateway-doctor
description: Use when Hermes Gateway 또는 텔레그램/디스코드/슬랙 봇이 메시지에 답장하지 않거나, 409 Conflict 에러가 나오거나, launchd 데몬이 좀비처럼 살아있을 때. macOS에서 `~/Library/LaunchAgents/*.plist` 게이트웨이 중복 등록 → 워커 충돌 진단/조치. getUpdates → 409 / sendMessage 성공 but 봇 무반응 / launchctl list에 죽은 게이트웨이 슬롯 잔존 / .env deprecated 경고 등의 신호로 발동.
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [macos]
metadata:
  hermes:
    tags: [hermes, telegram, launchd, macos, doctor, gateway]
    related_skills: [hermes-agent, simplify-and-harden]
---

# Hermes Gateway Doctor

## Overview

Hermes Gateway(macOS launchd 데몬)가 텔레그램/디스코드 등 메시징 채널에서 답장을 안 하는 증상의 **근본 원인을 5단계로 진단하고 조치**합니다. 가장 흔한 원인은 `~/Library/LaunchAgents/`에 게이트웨이 plist가 **두 개 이상 동시 등록**되어 워커끼리 텔레그램 봇을 잡으려다 둘 다 SIGTERM으로 비정상 종료되는 것입니다. sendMessage는 정상(메시지 텔레 도착)인데 봇이 무반응이고 getUpdates가 `409 Conflict`로 떨어지면 이 워크플로우로 진단합니다.

## When to Use

다음 증상 중 하나라도 보이면 즉시 트리거:

- 텔레그램에 보낸 메시지는 도착했지만 봇이 답장 안 함
- `getUpdates` 호출 시 `409 Conflict: terminated by other getUpdates request` 응답
- `launchctl list | grep hermes` 결과에 죽은 데몬(`-9` 종료 코드)이 PID와 함께 잔존
- `hermes gateway run`을 띄워도 곧바로 SIGTERM 받고 종료 (`parent_pid=(unknown)` 로그)
- `.env`에 `MESSAGING_CWD=~/.openclaw/workspace` 또는 `TERMINAL_CWD=...` deprecated 경고가 뜨면서 게이트웨이가 죽음

Don't use for:

- 봇 토큰 자체가 잘못된 경우 (`getMe`가 실패) → `.env`의 `TELEGRAM_BOT_TOKEN` 점검
- 회사망이 텔레그램을 차단하는 경우 → WARP 또는 외부 WiFi 필요
- 단순히 cron이 안 도는 경우 → `cron-doctor` 스킬 사용
- 디스코드/슬랙 등 다른 채널 고장 → 일단 텔레그램으로 좁힌 다음 적용

## The 5-Step Diagnostic

### Step 1: 409 Conflict 재현

봇이 답장 안 하면 먼저 `getUpdates`로 충돌이 있는지 확인:

```bash
TOKEN=$(grep TELEGRAM_BOT_TOKEN ~/.hermes/.env | cut -d= -f2)
curl -sS --max-time 6 "https://api.telegram.org/bot${TOKEN}/getUpdates?timeout=0&limit=1"
```

**기대 결과 해석**:

- `{"ok":true,"result":[]}` → 워커 부재 상태로 정상. 봇이 답장 안 하는 다른 원인.
- `{"ok":false,"error_code":409,"error":"Conflict: terminated by other getUpdates request; make sure that only one bot instance is running"}` → **이 스킬의 핵심 진단 대상**.

**완료 기준**: `error_code: 409`가 응답에 포함되면 Step 2로 진행. 아니면 다른 진단 분기.

### Step 2: launchd 좀비 슬롯 찾기

데몬이 살아있지만 죽어있는 상태를 찾습니다:

```bash
launchctl list 2>/dev/null | grep -iE "hermes|icbm"
```

**기대 출력 예시**:

```
18942   -9   ai.hermes.gateway
18880   -9   com.icbm2.hermes-gateway
```

**판독 규칙**:

- 두 번째 컬럼이 `-9` (SIGKILL 종료) 또는 `-15` (SIGTERM)면 좀비 슬롯
- **Label이 2개 이상이면 100% 충돌 원인**. 이 스킬의 정확한 적.
- Label이 `com.icbm2.hermes-gateway`처럼 메인 워커 디렉토리(`~/.hermes/hermes-agent`)가 아닌 다른 곳에서 띄우는 게이트웨이면 거의 확실히 중복 데몬

**Label 구분법**:

| Label | 정식/중복 | 근거 |
|---|---|---|
| `ai.hermes.gateway` | ✅ 정식 | `/Users/hjshin/.hermes/hermes-agent` 워킹디렉토리, VIRTUAL_ENV/HERMES_HOME 설정 |
| `com.icbm2.hermes-gateway` | ❌ 중복 가능성 큼 | `~/.openclaw/workspace` 워킹디렉토리, KeepAlive=true, 환경변수 누락 |

**완료 기준**: 좀비 슬롯의 Label과 PID가 명확히 식별됨.

### Step 3: plist 백업 + 비활성화

두 plist 모두 백업 후 `.disabled`로 이름 변경:

```bash
cd ~/Library/LaunchAgents
TS=$(date +%s)
for label in ai.hermes.gateway com.icbm2.hermes-gateway; do
  f="$label.plist"
  [ -f "$f" ] && cp "$f" "${f}.bak.${TS}" && mv "$f" "${f}.disabled"
done
ls -la *.bak.* *.disabled 2>&1
```

**완료 기준**: 두 plist 모두 `.disabled`로 이름 변경되고 `.bak.<ts>` 백업본이 같은 디렉토리에 존재.

### Step 4: 좀비 PID 강제 종료

launchd 캐시가 옛 슬롯을 기억하고 있어 `.disabled` 이름 변경만으로는 부족할 수 있음. 3회 반복 종료:

```bash
for attempt in 1 2 3; do
  pids=$(launchctl list 2>/dev/null | awk '$3 ~ /hermes|icbm/ && $1 ~ /^[0-9]+$/ {print $1}')
  [ -z "$pids" ] && echo "시도 $attempt: 좀비 없음" && break
  echo "$pids" | while read pid; do kill -9 "$pid" 2>/dev/null; done
  pkill -9 -f "hermes_cli.main" 2>/dev/null
  pkill -9 -f "hermes gateway" 2>/dev/null
  sleep 1
done
launchctl list 2>/dev/null | grep -iE "hermes|icbm" || echo "(데몬 모두 정리됨)"
```

**완료 기준**: `launchctl list | grep hermes` 출력 없음 (또는 `-` PID, `-9` exit code만 남음).

### Step 5: Self-Test 메시지 발송

봇 API 자체가 살아있는지 확인:

```bash
TOKEN=$(grep TELEGRAM_BOT_TOKEN ~/.hermes/.env | cut -d= -f2)
ALLOWED=$(grep TELEGRAM_ALLOWED_USERS ~/.hermes/.env | cut -d= -f2 | tr -d ' "')
MY_ID=$(echo "$ALLOWED" | cut -d, -f1)
curl -sS --max-time 8 -X POST "https://api.telegram.org/bot${TOKEN}/sendMessage" \
  -d chat_id="$MY_ID" \
  -d text="🩺 Hermes Gateway Doctor self-test"
```

**응답 예시**:

```json
{"ok":true,"result":{"message_id":18522,"chat":{"id":8359527845,...}}}
```

**완료 기준**: `ok:true` + `message_id` 응답. 사용자 텔레그램에서 메시지 도착 확인.

## 정식 게이트웨이 재시작 (사용자 직접)

좀비 정리 후 워커를 새로 띄워야 봇이 답장합니다. **포그라운드로 띄우면 터미널 종료 시 같이 죽으므로** launchd 데몬 복구 권장:

### 옵션 A: 단일 데몬 영구 복구 (권장)

```bash
# 중복 plist 영구 보관, 정식 plist만 복구
cd ~/Library/LaunchAgents
mv ai.hermes.gateway.plist.disabled ai.hermes.gateway.plist
launchctl load -w ~/Library/LaunchAgents/ai.hermes.gateway.plist
# com.icbm2.hermes-gateway.plist.disabled 는 그대로 두기 (영구 비활성)
```

### 옵션 B: 수동 포그라운드 (일회성 검증)

```bash
cd ~/.hermes/hermes-agent
/Users/hjshin/.hermes/hermes-agent/venv/bin/hermes gateway run --replace
# Ctrl+C 로 종료됨 — 다음 로그인 시 자동 시작 안 됨
```

**완료 기준**: 새 메시지 전송 시 봇이 답장함.

## Common Pitfalls

1. **`launchctl bootout` "Operation not permitted"** — 사용자 권한으로는 unload 못 할 수 있음. `kill -9 <pid>` 직접 종료로 우회. `.disabled`로 launchd 인식 못 하게 하는 게 본질적 해결.

2. **좀비 재탄생** — launchd가 옛 슬롯을 캐시에서 안 잊어서 PID가 자꾸 바뀜 (예: 19248 → 19289). 3회 반복 kill + `.disabled` 이름 변경으로 영구 차단.

3. **`parent_pid=(unknown) parent_cmdline='(unknown)'`** — 게이트웨이가 정상 부팅 후 누군가 SIGTERM 보냄. 보통 launchd의 다른 데몬이 충돌 감지하고 죽인 것. `log show --last 5m --predicate 'eventMessage contains "hermes"'`로 누가 보냈는지 추적 가능.

4. **`.env` deprecated 경고 무시하면 죽음** — `MESSAGING_CWD`, `TERMINAL_CWD` 키는 deprecated. 게이트웨이가 부팅 후 죽을 수 있음. config.yaml로 옮겨야 함:
   ```yaml
   # ~/.hermes/config.yaml
   terminal:
     cwd: /Users/hjshin/Desktop/project/work/ai
   ```

5. **두 plist가 동시에 살아있으면 영원히 충돌** — 하나만 살리고 나머지는 `.disabled` 영구 보관 또는 삭제. 둘 다 살리는 건 구조적 결함.

6. **macOS에 `timeout` 명령 없음** — `ping -W 2000` 또는 `gtimeout` 사용 (없으면 `curl --max-time`로 우회).

7. **WARP가 살아있어도 회사망 차단 정책 확인** — `149.154.166.0/24` (Telegram DC) 차단이 회사 방화벽에 있으면 WARP 우회 안 될 수 있음. `1.1.1.1` 차단도 마찬가지.

## Verification Checklist

진단 완료 후 다음을 모두 확인:

- [ ] `launchctl list | grep -E "hermes|icbm"` 출력 없거나 PID `-`만 표시
- [ ] `~/Library/LaunchAgents/*.plist.disabled` 두 개 존재 (또는 영구 보관된 백업)
- [ ] `~/Library/LaunchAgents/*.bak.<ts>` 백업 두 개 존재
- [ ] `getUpdates` 호출 시 `ok:true, result:[]` (워커 부재 상태 정상)
- [ ] `sendMessage` self-test 성공 (`ok:true`, `message_id` 응답)
- [ ] 사용자 텔레그램에 self-test 메시지 도착 확인
- [ ] 게이트웨이 재시작 후 새 메시지 → 봇 답장 확인

## Quick-Reference: 한 줄 진단

```bash
TOKEN=$(grep TELEGRAM_BOT_TOKEN ~/.hermes/.env | cut -d= -f2) && \
curl -sS --max-time 5 "https://api.telegram.org/bot${TOKEN}/getUpdates?timeout=0&limit=1" && \
echo "" && launchctl list 2>/dev/null | grep -iE "hermes|icbm" || echo "(데몬 없음)"
```

출력에 `error_code: 409` + `launchctl`에 `-9` 좀비 → 이 스킬의 정확한 타겟. 위 5단계 즉시 진행.

## Related Reference

증상이 메시지 텔레 도착 X (전송 자체 실패)면 → 네트워크 차단. WARP 활성 여부 + `1.1.1.1` ping + `getMe` 호출로 분리 진단.
증상이 cron 자동 발송은 정상인데 사용자 메시지에만 반응 없음 → `TELEGRAM_ALLOWED_USERS` 화이트리스트 확인.
