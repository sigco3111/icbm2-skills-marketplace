#!/bin/bash
# sticky-fallback-diagnose.sh
# Hermes Gateway Doctor — Sticky Fallback IP 함정 진단 스크립트
# 2026-06-30 시드에서 검증된 절차.
#
# 사용법:
#   bash scripts/sticky-fallback-diagnose.sh
#
# 판정:
#   - 데몬 0개 → Step 0 분기
#   - 데몬 PID + exit 0 + sticky fallback 흔적 → ★ Step 6 진단 확정 ★
#   - 데몬 PID + exit -9 → Step 4 좀비 정리 분기
#   - 그 외 → 다른 원인 (화이트리스트, MCP, 토큰)

set -e

TOKEN=*** TELEGRAM_BOT_TOKEN ~/.hermes/.env | cut -d= -f2)
ERR_LOG=~/.hermes/logs/gateway.err.log

echo "============================================"
echo " Hermes Gateway Doctor — Sticky Fallback 진단"
echo "============================================"
echo ""

echo "[1] 데몬 상태:"
DAEMON_LINE=$(launchctl list 2>/dev/null | grep -iE "ai\.hermes" || echo "")
if [ -z "$DAEMON_LINE" ]; then
  echo "  (데몬 없음)"
  echo ""
  echo "★ 판정: Step 0 분기 — plist 신규 작성 또는 load 필요"
  exit 0
fi
echo "$DAEMON_LINE"

EXIT_CODE=$(echo "$DAEMON_LINE" | awk '{print $2}')
if [ "$EXIT_CODE" = "-9" ] || [ "$EXIT_CODE" = "-15" ]; then
  echo ""
  echo "★ 판정: 좀비 슬롯 — Step 4 좀비 정리 후 Step 6 점검"
fi

echo ""
echo "[2] getUpdates 응답 (워커 polling 상태):"
GU=$(curl -sS --max-time 5 "https://api.telegram.org/bot${TOKEN}/getUpdates?timeout=0&limit=1" 2>&1)
echo "  $GU"

if echo "$GU" | grep -q "409"; then
  echo ""
  echo "★ 판정: 409 Conflict = 워커 정상 polling. 사용자 메시지에 봇 응답 와야 함."
  echo "  무반응이면 Step 2 (중복 plist) / 화이트리스트 점검."
  exit 0
fi

echo ""
echo "[3] sticky fallback / ReadError / polling conflict 흔적:"
if [ -f "$ERR_LOG" ]; then
  HITS=$(grep -E "sticky fallback|httpx\.ReadError|polling conflict|polling retry" "$ERR_LOG" 2>/dev/null | tail -5)
  if [ -n "$HITS" ]; then
    echo "$HITS"
  else
    echo "  (없음)"
  fi
else
  echo "  ($ERR_LOG 없음)"
fi

echo ""
echo "[4] 외부 DC 통신 (워커 httpx 분리 진단):"
for i in 1 2 3; do
  RESULT=$(curl -sS --max-time 10 -o /dev/null -w "HTTP %{http_code} time=%{time_total}s" \
    "https://api.telegram.org/bot${TOKEN}/getMe" 2>&1)
  echo "  getMe $i: $RESULT"
  sleep 1
done

echo ""
echo "[5] fallback IP SSL mismatch 검증:"
curl -sS --max-time 6 "https://149.154.166.110/" 2>&1 | head -3 | sed 's/^/  /'

echo ""
echo "============================================"
echo " 최종 판정"
echo "============================================"
if grep -qE "sticky fallback|polling conflict" "$ERR_LOG" 2>/dev/null && [ "$EXIT_CODE" = "0" ]; then
  echo "★ Step 6 sticky fallback 함정 진단 확정 ★"
  echo ""
  echo "해결 절차:"
  echo "  1. launchctl unload ~/Library/LaunchAgents/ai.hermes.gateway.plist"
  echo "  2. 좀비 3회 반복 kill -9 (Step 4)"
  echo "  3. 텔레 서버측 좀비 세션 만료 50~60s 대기"
  echo "  4. launchctl load -w plist"
  echo "  5. 15초 대기 후 새 PID + exit 0 확인"
  echo "  6. 사용자가 텔레그램에서 봇에게 메시지 전송 → 응답 검증"
  exit 1
elif [ "$EXIT_CODE" = "-9" ] || [ "$EXIT_CODE" = "-15" ]; then
  echo "★ 좀비 슬롯 — Step 4 좀비 정리 후 재진단"
  exit 1
else
  echo "sticky fallback 함정 아님 — 다른 원인 점검 필요"
  echo "  - TELEGRAM_ALLOWED_USERS 화이트리스트"
  echo "  - MCP 서버 (config.yaml mcp_servers 블록)"
  echo "  - 토큰 / .env 변수"
  exit 0
fi