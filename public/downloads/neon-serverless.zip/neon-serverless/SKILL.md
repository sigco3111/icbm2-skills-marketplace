---
name: neon-serverless
description: Configures Neon Serverless Driver for Next.js, Vercel Edge Functions, AWS Lambda, and other serverless environments. Use when connecting applications to Neon, querying data, or setting up database access in edge/serverless environments.
allowed-tools: ["bash"]
---

# Neon Serverless Skill

Configures the Neon Serverless Driver for optimal performance in serverless and edge computing environments.

## When to Use

- Setting up connections for edge functions (Vercel Edge, Cloudflare Workers)
- Configuring serverless APIs (AWS Lambda, Google Cloud Functions)
- Optimizing for low-latency database access
- Implementing connection pooling for high-throughput apps

**Not recommended for:** Complex multi-statement transactions (use WebSocket Pool), persistent servers (use native PostgreSQL drivers), or offline-first applications.

## Code Generation Rules

When generating TypeScript/JavaScript code:
- BEFORE generating import statements, check tsconfig.json for path aliases (compilerOptions.paths)
- If path aliases exist (e.g., "@/*": ["./src/*"]), use them (e.g., import { x } from '@/lib/utils')
- If NO path aliases exist or unsure, ALWAYS use relative imports (e.g., import { x } from '../../../lib/utils')
- Default to relative imports - they always work regardless of configuration

## Quick Setup

### Installation

```bash
npm install @neondatabase/serverless
```

### Connection Patterns

**HTTP Client** (recommended for edge/serverless):
```typescript
import { neon } from '@neondatabase/serverless';
const sql = neon(process.env.DATABASE_URL!);
const rows = await sql`SELECT * FROM users WHERE id = ${userId}`;
```

**WebSocket Pool** (for Node.js long-lived connections):
```typescript
import { Pool } from '@neondatabase/serverless';
const pool = new Pool({ connectionString: process.env.DATABASE_URL! });
const result = await pool.query('SELECT * FROM users WHERE id = $1', [userId]);
```

### Python Connection (psycopg2)
```python
import psycopg2
conn = psycopg2.connect(os.environ["DATABASE_URL"])
```

### Python Connection (asyncpg)
```python
import asyncpg
conn = await asyncpg.connect(os.environ["DATABASE_URL"])
```

## Connection String Format

```
postgresql://user:password@ep-xxx.region.aws.neon.tech/dbname?sslmode=require
```

## Best Practices

- Always use `sslmode=require`
- Store connection strings in environment variables
- Use HTTP adapter for serverless/edge (cold start friendly)
- Use WebSocket pool for long-running Node.js servers
- Set connection pool size appropriately for your workload

## Related Skills

- **neon-drizzle** - For ORM with serverless connections

## Source

- 출처: https://github.com/neondatabase/ai-rules (Neon 공식)
- 라이선스: MIT
