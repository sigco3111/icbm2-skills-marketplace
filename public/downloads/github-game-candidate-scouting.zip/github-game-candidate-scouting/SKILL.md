---
name: github-game-candidate-scouting
description: Scout GitHub for OSS games worth forking + localizing.
tags: [github, game, scouting, localization, fork, candidate-evaluation, korean]
---

# GitHub Game Candidate Scouting

Class-level workflow for the **pre-fork phase**: scanning GitHub to find open-source game candidates that are well-suited to localization + feature improvement forks (especially Korean).

## Reference docs

- `references/2026-07-27-validated-candidates.md` — 검증된 TOP 5 + 회피 6개 + 빌드 비용 (재실행 불필요)
- `references/genre-query-bank.md` — 30+ query templates organized by genre + scope filters + anti-patterns
- `scripts/scout-games.sh` — re-runnable batched search script (token-aware, customizable genre list)

## When to use

- User: "GitHub에서 오픈소스 게임 추천해줘 (한국어화 + 기능 개선용)"
- User: "Find OSS game candidates for [language] localization"
- User: "게임 fork 후보 N개 골라줘"
- User: "어떤 OSS 게임을 fork하면 좋을까?"

This skill **ends** when you have a ranked list of 3-5 candidates with a TOP recommendation. The existing fork/localization skills (`oss-fork-localization`, `cpp-game-koreanization`, `github-cli`) take over from there.

## Phase 1 — Multi-Query Batched Search (5 min)

**Never** use a single genre query — search noise drowns real games in engines/tutorials. Batch 8-12 genre queries with `sort=stars&order=desc`, dedupe across results.

**Query bank must use game-content signals (verified 07-27)**: broad `open source game`/`rpg game`/`platformer` queries match vuejs/tensorflow/opencode/electron + engines (godot/bevy/pixijs). Always combine `genre + "game"` or use language filter:

```bash
# ❌ broad → engines/frameworks contaminate results
"open source game" "rpg game" "platformer"

# ✅ narrower → game content only
"roguelike+game+language:Java"
"tower+defense+game"
"auto+battler" "autobattler"
"pixel+platformer+game"
"incremental+game" "idle+game"
"turn-based+strategy+game"
"love2d+game" "godot+game" "pygame+game"
"city+builder+game" "puzzle+game+2d"
"visual+novel+engine" "shooter+game+language:Lua"
"browser+game+free"
```

**Master vs main branch 404 함정 (07-27 verified)**: `repos/OWNER/REPO/contents/` API는 `default_branch`를 알려주지만, `raw.githubusercontent.com/...` 직접은 브랜치 명시 필요. older repos = `master`, newer = `main`. preflight은 **양쪽 모두 시도**:

```bash
for branch in main master; do
    status=$(curl -s -o /dev/null -w "%{http_code}" "https://raw.githubusercontent.com/OWNER/REPO/$branch/path/to/file")
    echo "$branch: $status"
done
```

실 사례: `pmotschmann/Evolve/strings/strings.ko-KR.json` → main 404, master 200. 함정 14번 polish 측정 자체가 master 때만 가능했음.

```bash
for q in "tower defense game" "roguelike deckbuilder" "auto battler" "incremental game" \
         "turn-based strategy game" "love2d game" "godot game" "visual novel engine"; do
  echo "=== $q ==="
  curl -s -H "Authorization: token $(cat ~/.hermes/secrets/github_token.txt)" \
    "https://api.github.com/search/repositories?q=${q// /+}&sort=stars&order=desc&per_page=4" \
    | python3 -c "
import json, sys
data = json.load(sys.stdin)
for r in data.get('items', [])[:4]:
    license = (r.get('license') or {}).get('spdx_id', 'NOASSERTION')
    pushed = r.get('pushed_at','')[:10]
    print(f\"  {r['stargazers_count']:>7} | {(r.get('language') or 'None'):<12} | {r['full_name']:<45} | {license:<10} | pushed={pushed} | {(r.get('description') or '')[:60]}\")
"
done
```

**Full genre query bank (30+)**: see `references/genre-query-bank.md`.
**Reusable script**: `scripts/scout-games.sh` (default 12-genre batch + custom override). 

> **07-27 노트**: scripts/scout-games.sh의 기본 `DEFAULT_QUERIES`도 broad query 사용 → 엔진 매칭 위험. 커스텀 `-q "tower+defense+game auto+battler ..."` 또는 `QUERIES=...` env override 필요.

## Phase 2 — Initial Triage (2 min)

Dedupe by `full_name`. Discard:

- Archived repos
- Pure engines (Godot/Unity/cocos2d) without a sample game
- 0 stars / 0 forks
- Tutorials (Unity FPS-Sample, Brackeys series, etc.)
- No activity in 6+ months (unless legendary)

Keep top 10-15.

## Phase 3 — 5-Dimension Evaluation Matrix

Score each candidate 1-10 on each dimension. Final score = weighted sum.

| Dimension | Weight | What to check |
|---|---|---|
| **Differentiability** | 25% | Can fork add value beyond translation? Korean-specific content room (historical scenarios, K-pop theming, localized items)? |
| **macOS Build Ease** | 20% | Repo files: `package.json` (npm/pnpm), `Cargo.toml`, `Makefile` + simple deps. **🟢 npm/yarn/pnpm**, **🟡 Java/Gradle**, **🟠 Rust/cargo**, **🔴 C++ with Boost/SDL** (90-min trap) |
| **Korean Gap** | 20% | `api.github.com/search/issues?q=repo:OWNER/REPO+korean+OR+한국어` — 0-2 PR = greenfield, 5+ = crowded |
| **i18n Readiness** | 15% | `i18n/` `locales/` `lang/` `*.po` `translations/` dirs present? Existing i18n lib (i18next, gettext, JS string module)? |
| **Playability** | 20% | README screenshots/GIFs, demo link, status (WIP/Alpha/Release), community (Discord/forums), is the game actually playable end-to-end or just a tech demo? |

**Formula**: `0.25*diff + 0.20*build + 0.20*ko_gap + 0.15*i18n + 0.20*play`

**Top 3-5 → final report.**

## Phase 4 — First-Improvement Ideation (per candidate)

For each ranked candidate, articulate the **specific concrete improvement** beyond translation. This is what makes a fork valuable vs. just a translation patch.

Common patterns:

| Pattern | Example |
|---|---|
| **Cultural content add** | Korean historical scenarios (이순신/강감찬 units), K-pop theming, local holiday events |
| **Platform distribution** | macOS .app build, Vercel deploy, GitHub Releases with .love/.exe/.dmg |
| **Quality-of-life feature** | Save state persistence, difficulty settings, accessibility options (colorblind, text size) |
| **New game mode** | Daily challenge, multiplayer, time attack, endless mode |
| **Performance** | Mobile optimization, asset pipeline, lazy loading |

The **first PR** should be small and obviously valuable — not "translate everything" but "translate the main menu + add a quality-of-life feature". That builds trust with upstream.

## Phase 5 — Final Report

Output format (concise, table-driven — user explicitly asked for 3-5 + final pick):

```markdown
## 🏆 TOP N 후보 비교 매트릭스

| 순위 | 저장소 | ⭐ | 언어 | 라이선스 | 차별화 | 빌드 | 한글 | 플레이 |
|---|---|---|---|---|---|---|---|---|
| 🥇 | owner/repo | stars | Lang | MIT | 9/10 | 10/10 | 10/10 | 9/10 |

## 📋 후보별 상세 평가
- (URL + 기술 스택 + 활동성 + i18n 현황 + 첫 개선 작업)

## 🎯 최종 추천
- (이유 + 첫 개선 작업 구체화 + 1단계 행동)

## ⚠️ 회피 후보
- (고려했으나 제외한 후보 + 제외 이유 — IP 충돌 / 라이선스 / 이미 한국어 활발 등)
```

**Format rationale**: User asked for "3~5개 + 최종 추천" — table for at-a-glance comparison, sections for depth, final pick with concrete next step, plus explicit "rejected" section so user understands the screening.

## Pitfalls (encountered in real sessions)

1. **Single-query search misses diversity** — searching only "open source game" returns mostly engines/tutorials. Always batch 8-12 genres.

2. **`NOASSERTION` license ≠ unrestricted** — many game repos never set a LICENSE file. Check `LICENSES/`, `LICENSE.md`, `REUSE.toml`, `package.json#license`. If unclear, treat as "all rights reserved" → flag in report. Cannot fork legally without explicit license.

3. **`licenseInfo.key: "other"` = 커스텀 라이선스 함정** — `gh repo view --json licenseInfo`에서 `key`가 `"other"`로 나오면 SPDX 표준 외 자체 라이선스. raw 본문 다운로드 후 차단 키워드 검사 필수:
   - `"commercial purposes"` 금지 → fork 가치 의문
   - `"reserve the right to request"` (삭제 요구권) → PR 머지해도 권리 불안정
   - `"All Rights Reserved"` → 사실상 사용 불가

   실 사례: `R74n/sandboxels`는 439⭐이지만 R74n Content License v1.1이 셋 다 포함 → 1순위 후보에서 제외됨. 라이선스 본문 5분 안 보면 절대 발견 못 함.

4. **`pushed_at` 6+ months ago = likely abandoned** — even with high stars. Filter: pushed within 90 days for green light, 6 months for caution, older = deprioritize unless legendary (Cave Story remake, etc.).

5. **Korean GitHub Issue/PR search misses external translation services** — many repos track translations in Crowdin/Weblate/POEditor, not GitHub Issues. Check `locales/` directory directly for the real status.

6. **macOS C++ builds are a 90-min trap** — same lesson as `cpp-game-koreanization` Phase 0. Before recommending a C++ game, verify it has a working build path or a CI artifact. Otherwise the candidate is "show but don't fork".

7. **IP-conflicting games** — Pokemon fan-games (PokeRogue), Disney/Studio-IP remakes, MUGEN-with-stolen-assets. The fork itself is fine on GitHub but **limits distribution** (no Steam, no App Store, no commercial release).

8. **`pushed_at` is commit, not release** — a repo with daily commits but no release in 2 years = developer-only mode. Verify the game is actually playable by users (downloadable artifact, web demo, Steam page), not just maintainers.

9. **Don't confuse "active i18n" with "active Korean i18n"** — repos with 200+ localization PRs (e.g. PokéRogue, Mindustry) often have a mature translation team already. Check if Korean-specific PRs are recent or stale.

10. **Game frameworks ≠ games** — KoBeWi/Metroidvania-System is a Godot framework, not a game. Forks here mean "demo game + framework update" — different work type than forking a complete game.

11. **PR workflow > email contributor** — for small localization fixes, open PR directly. Don't ask "want to translate?" — say "here's the PR, ping me if changes needed".

12. **`gh search repos -L <N>` (대시 L, 카운트)** — `--limit` 아님. `--limit` 쓰면 "unknown flag" 에러. 동일하게 `gh search repos --json fields` 사용 가능 필드 확인 가능.

13. **`gh repo view --json` vs `gh search repos --json` 필드명 다름**:
    - `gh repo view`: `primaryLanguage`, `stargazerCount`, `licenseInfo`, `pushedAt`, `updatedAt`, `description`, `url`
    - `gh search repos`: `language`, `stargazersCount`, `license`, `pushedAt`, `updatedAt`, `description`, `url`
    - 잘못된 필드명 쓰면 "Unknown JSON field" 에러. 양쪽 다 사용 직전 `gh ... --help`로 확인 권장.
    - **실수 패턴**: `gh search repos --json licenseInfo` (X) → `license`만 사용 가능. `gh search repos --json primaryLanguage` (X) → `language`만 사용 가능. 단, `primaryLanguage`는 nested object `{"name":"..."}` 반환, `language`는 string 반환.

14. **한국어 strings 파일이 "존재"한다고 완성된 건 아님** — `strings.ko-KR.json`이 있어도 5-15%는 영문 잔존 (토큰·기술용어·수치 제외). 실측 필수:

    ```bash
    curl -fsSL <url> | python3 -c "
    import json,sys
    d=json.loads(sys.stdin.read())
    not_ko = [k for k,v in d.items() if v and not any(0xAC00 <= ord(c) <= 0xD7A3 for c in v) and len(v) > 5]
    print(f'non-korean (longer values): {len(not_ko)}/{len(d)}')
    "
    ```

    polish 임팩트가 큰 케이스 = 한국어 키 1000+ 보유 + 영문 잔존 5%+ (예: `pmotschmann/Evolve` 10,164 키 중 **1,213개 영문 잔존** → polish 가치 큼). 반대로 `R74n/sandboxels`처럼 잔존 1-2%면 신규 번역보다 다른 후보로 이동.

    **07-27 실측**: Evolve 22.5% residue (2,291/10,164). 함수 14의 5-15% 추정보다 훨씬 높음. **5%+ 일반화 OK, 22.5%도 케이스별로 충분히 발생**.

15. **메타데이터 `language: ""` (빈 문자열) ≠ 라이브러리** — `break_infinity.js`, `discord.py` 류는 `language: ""` 인데 description에 "game" 들어가도 라이브러리. description과 repo topic 둘 다 확인 필수.

16. **`gh search issues "repo:OWNER/REPO keyword"` 쿼리 파싱 실패 함정** — `gh search issues` CLI는 `repo:` 한정자 + 추가 키워드를 같은 인자에 공백 한 칸으로 넘기면 "Invalid search query" 에러를 뱉음:
    - ❌ `gh search issues "repo:oskarrough/slaytheweb korean"` → 파싱 실패
    - ✅ 우회 1: `gh api "search/issues?q=repo:oskarrough/slaytheweb+korean+OR+한국어&per_page=1"` + `total_count` JSON 파싱
    - ✅ 우회 2: GitHub web UI 직접 확인 (`https://github.com/OWNER/REPO/issues?q=korean+OR+한국어`)
    - 카운트만 필요하면 `gh api search/issues` JSON의 `total_count`가 정답 (CLI보다 안정적).

17. **`stargazersCount: null` (혹은 `pushedAt: null`) format string 에러** — 일부 신규/저활동 저장소는 `stargazersCount`나 `pushedAt`가 `null`로 옴. Python f-string에서 `{r['stargazersCount']:>5}`로 직접 쓰면 `TypeError: unsupported format string passed to NoneType`:
    - ❌ `print(f\"  {r['stargazers_count']:>7} | {r['full_name']}\")` → None이면 죽음
    - ✅ `print(f\"  {(r.get('stargazersCount') or 0):>5} | {(r.get('pushedAt') or '')[:10]}\")` 방어
    - preflight 스크립트 작성 시 모든 숫자/날짜 필드에 `or 0` / `or ''` 필수.

18. **Query bank 노이즈 — broad game term 매칭 (07-27 verified)** — `open source game`/`rpg game`/`platformer` 같은 broad 쿼리는 vuejs/tensorflow/opencode/electron + 엔진 (godot/bevy/pixijs) 매칭. 항상 `genre + "game"` 또는 `language:XXX`로 좁히기. Phase 1 코드 블록 참고.

19. **Master vs main branch 404 (07-27 verified)** — `repos/OWNER/REPO/contents/` API의 `default_branch` 와 `raw.githubusercontent.com/...` 의 브랜치 명시는 다름. older repos는 `master`, newer는 `main`. 폴리시 측정/실측 시 **양쪽 모두 시도**. 실 사례: `pmotschmann/Evolve/strings/strings.ko-KR.json` → main 404, master 200.

## Reference

- `references/2026-07-27-validated-candidates.md` — 검증된 TOP 5 + 회피 6개 + 빌드 비용 (재실행 불필요)
- `references/genre-query-bank.md` — 30+ query templates organized by genre + scope filters + anti-patterns
- `scripts/scout-games.sh` — re-runnable batched search script (token-aware, customizable genre list)

## Next steps after scouting

Once a candidate is selected, existing skills take over:

- **`oss-fork-localization`** — full fork workflow (LICENSE/MODIFIED, preflight check, distribution)
- **`cpp-game-koreanization`** — game-specific (PO files, JSON modpacks, browser ESM, LÖVE)
- **`github-cli`** — repo setup, PR workflow, releases
- **`build-environment-preflight-check`** (under oss-fork-localization references) — 5-min build verification BEFORE any translation work
