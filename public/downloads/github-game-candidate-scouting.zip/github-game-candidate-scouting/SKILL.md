---
name: github-game-candidate-scouting
description: Scout GitHub for OSS games/addons worth forking + localizing.
tags: [github, game, scouting, localization, fork, candidate-evaluation, korean]
---

# GitHub Game Candidate Scouting

Class-level workflow for the **pre-fork phase**: scanning GitHub to find open-source game (or addon) candidates that are well-suited to localization + feature improvement forks (especially Korean).

## Reference docs

- `references/2026-07-27-validated-candidates.md` — 검증된 TOP 5 + 회피 6개 + 빌드 비용 (재실행 불필요)
- `references/2026-07-28-newly-validated-candidates.md` — `nathanhoad/godot_dialogue_manager` 외 3 검증 (gettext 패턴 + addon 분류 + exclude SSoT 학습)
- `references/genre-query-bank.md` — 30+ query templates organized by genre + scope filters + anti-patterns
- `scripts/scout-games.sh` — re-runnable batched search script (token-aware, customizable genre list)
- `scripts/i18n-loader-probe.sh` — headless i18n loader verification (Pitfall 29b). Go 게임의 i18n 패키지만 import하는 probe main.go 자동 생성 + `go run` 결과 출력. Nerd Font 게임(Pitfall 29c)에서 단위 검증의 SSOT.

## When to use

- User: "GitHub에서 오픈소스 게임 추천해줘 (한국어화 + 기능 개선용)"
- User: "Find OSS game candidates for [language] localization"
- User: "게임 fork 후보 N개 골라줘"
- User: "어떤 OSS 게임을 fork하면 좋을까?"
- User: "GitHub에서 최근 활동 중인 저장소 3~5개 추천해줘" (게임/개발 도구 모두 포함)

This skill **ends** when you have a ranked list of 3-5 candidates with a TOP recommendation. The existing fork/localization skills (`oss-fork-localization`, `cpp-game-koreanization`, `github-cli`) take over from there.

## Phase 0 — Exclude Cross-Check (30 sec, BEFORE search)

사용자가 **이미 작업한 fork = 추천 금지**. 매 세션 첫 30초에 1회 실행:

```bash
# 1) 작업 디렉토리 fork = 사용자가 한국어화한/작업 중인 것
ls /Users/mac/work 2>/dev/null | while read dir; do
  remote=$(git -C "/Users/mac/work/$dir" remote get-url origin 2>/dev/null)
  [[ "$remote" =~ sigco3111/ ]] && echo "$dir ← $remote"
done

# 2) 홈 디렉토리 전체 검색 (작업/설치 흔적)
find /Users/mac -maxdepth 3 -type d \( -iname "*triplea*" -o -iname "*snkrx*" \) 2>/dev/null

# 3) Library/Application Support (Steam 클라우드 동기화 등)
ls "/Users/mac/Library/Application Support/" 2>/dev/null | grep -iE "snkrx|triplea"
```

**07-28 실증**: TripleA + Evolve + OpenMinis + minimax-of-duty 4개 모두 작업 완료/진행 중이었음 — SEARCH 결과에 안 나와도 작업 흔적으로 발견. **이 단계 안 거치면 사용자가 "어 그거 이미 했잖아요" 시그널 → 신뢰 하락.**

## Phase 1 — Multi-Query Batched Search (5 min)

**Never** use a single genre query — search noise drowns real games in engines/tutorials. Batch 8-12 genre queries with `sort=stars&order=desc`, dedupe across results.

**Query bank must use game-content signals (verified 07-27)**: broad `open source game`/`rpg game`/`platformer` queries match vuejs/tensorflow/opencode/electron + engines (godot/bevy/pixijs). Always combine `genre + "game"` or use language filter:

```bash
# ❌ broad → engines/frameworks contaminate results
"open source game" "rpg game" "platformer"

# ✅ narrower → game content only
"roguelike+game+language:Java"
"tower+defense+game"
"auto+battler" "autobattler"
"pixel+platformer+game"
"incremental+game" "idle+game"
"turn-based+strategy+game"
"love2d+game" "godot+game" "pygame+game"
"city+builder+game" "puzzle+game+2d"
"visual+novel+engine" "shooter+game+language:Lua"
"browser+game+free"
```

**Master vs main branch 404 함정 (07-27 verified)**: `repos/OWNER/REPO/contents/` API는 `default_branch`를 알려주지만, `raw.githubusercontent.com/...` 직접은 브랜치 명시 필요. older repos = `master`, newer = `main`. preflight은 **양쪽 모두 시도**:

```bash
for branch in main master; do
    status=$(curl -s -o /dev/null -w "%{http_code}" "https://raw.githubusercontent.com/OWNER/REPO/$branch/path/to/file")
    echo "$branch: $status"
done
```

실 사례: `pmotschmann/Evolve/strings/strings.ko-KR.json` → main 404, master 200. 함정 15번 polish 측정 자체가 master 때만 가능했음.

```bash
for q in "tower defense game" "roguelike deckbuilder" "auto battler" "incremental game" \
         "turn-based strategy game" "love2d game" "godot game" "visual novel engine"; do
  echo "=== $q ==="
  curl -s -H "Authorization: token $(cat ~/.hermes/secrets/github_token.txt)" \
    "https://api.github.com/search/repositories?q=${q// /+}&sort=stars&order=desc&per_page=4" \
    | python3 -c "
import json, sys
data = json.load(sys.stdin)
for r in data.get('items', [])[:4]:
    license = (r.get('license') or {}).get('spdx_id', 'NOASSERTION')
    pushed = r.get('pushed_at','')[:10]
    print(f\"  {r['stargazers_count']:>7} | {(r.get('language') or 'None'):<12} | {r['full_name']:<45} | {license:<10} | pushed={pushed} | {(r.get('description') or '')[:60]}\")
"
done
```

### 🔴 gh search 쿼리 단순화 함정 (07-28 verified)

`gh search` CLI는 **AND/OR/NOT이 5번 이상** 들어가거나 따옴표 중첩 시 422 Validation Failed:

```bash
# ❌ 422 (operator > 5)
gh search repos "snkrx OR evolve OR triplea OR openminis OR \"claude-of-duty\" OR ..."
gh search repos "topic:godot stars:200..5000 pushed:>2026-05-01"

# ✅ 단순화
gh search repos "snkrx" --limit 5
gh search repos "athena-crisis" --limit 5
gh search repos "youtd2" --limit 5
```

`gh api search/repositories` REST endpoint는 검색력이 더 강하지만, **rate limit 60회/시간 (unauth) / 5000회/시간 (auth)** — 큰 배치 한 번에 403 가능. **방어책**:

```bash
# 인증된 사용자도 30회 이상 연속 호출 시 403 가능 — sleep 또는 batch 분할
for repo in "$@" ; do
  gh api "repos/$repo" --jq '.stargazers_count,.pushed_at,(.license.spdx_id // "NO"),.topics' 2>/dev/null
  sleep 1   # rate limit 회피
done
```

**최안정 fallback**: `gh api repos/OWNER/REPO --jq '...'` 1개씩 + 짧은 `sleep`. 트리키한 multi-keyword 검색은 **GitHub web UI URL 직접 + 수동 copy**.

**Full genre query bank (30+)**: see `references/genre-query-bank.md`.

> **07-27 노트**: scripts/scout-games.sh의 기본 `DEFAULT_QUERIES`도 broad query 사용 → 엔진 매칭 위험. 커스텀 `-q "tower+defense+game auto+battler ..."` 또는 `QUERIES=...` env override 필요.

**Reusable script**: `scripts/scout-games.sh` (default 12-genre batch + custom override).

## Phase 2 — Initial Triage (2 min)

Dedupe by `full_name`. Discard:

- Archived repos
- Pure engines (Godot/Unity/cocos2d) without a sample game
- 0 stars / 0 forks
- Tutorials (Unity FPS-Sample, Brackeys series, etc.)
- No activity in 6+ months (unless legendary)
- **Phase 0 exclude 리스트에 매치되는 후보** (재추천 금지)

Keep top 10-15.

## Phase 3 — 5-Dimension Evaluation Matrix

Score each candidate 1-10 on each dimension. Final score = weighted sum.

| Dimension | Weight | What to check |
|---|---|---|
| **Differentiability** | 25% | Can fork add value beyond translation? Korean-specific content room (historical scenarios, K-pop theming, localized items)? |
| **macOS Build Ease** | 20% | Repo files: `package.json` (npm/pnpm), `Cargo.toml`, `Makefile` + simple deps. **🟢 npm/yarn/pnpm**, **🟡 Java/Gradle**, **🟠 Rust/cargo**, **🔴 C++ with Boost/SDL** (90-min trap). **NEW 07-27**: If `CONTRIBUTING.md` mentions Google Drive/Dropbox/Mega asset download, **build requires 2-step process** (clone + external download) — demote to 🟠 even if engine is 🟢. |
| **Korean Gap** | 20% | `api.github.com/search/issues?q=repo:OWNER/REPO+korean+OR+한국어` — 0-2 PR = greenfield, 5+ = crowded |
| **i18n Readiness** | 15% | Tree probe for `i18n/` `locales/` `lang/` `*.po` `translations/` directories. **Gettext 표준 (.pot + .po)** 점수 최고 — ko.po 한 파일 추가가 곧 PR 작업. JSON dicts (Evolve/SNKRX 스타일) 다음 순위. 기존 ko 디렉토리/파일 부재 확인이 greenfield 신호. |
| **Playability** | 20% | README screenshots/GIFs, demo link, status (WIP/Alpha/Release), community (Discord/forums), is the game actually playable end-to-end or just a tech demo? |

**Formula**: `0.25*diff + 0.20*build + 0.20*ko_gap + 0.15*i18n + 0.20*play`

**Top 3-5 → final report.**

## Phase 4 — First-Improvement Ideation (per candidate)

For each ranked candidate, articulate the **specific concrete improvement** beyond translation. This is what makes a fork valuable vs. just a translation patch.

Common patterns:

| Pattern | Example |
|---|---|
| **Cultural content add** | Korean historical scenarios (이순신/강감찬 units), K-pop theming, local holiday events |
| **Platform distribution** | macOS .app build, Vercel deploy, GitHub Releases with .love/.exe/.dmg |
| **Quality-of-life feature** | Save state persistence, difficulty settings, accessibility options (colorblind, text size) |
| **New game mode** | Daily challenge, multiplayer, time attack, endless mode |
| **Performance** | Mobile optimization, asset pipeline, lazy loading |

The **first PR** should be small and obviously valuable — not "translate everything" but "translate the main menu + add a quality-of-life feature". That builds trust with upstream.

## Phase 5 — Final Report

Output format (concise, table-driven — user explicitly asked for 3-5 + final pick):

```markdown
## 🏆 TOP N 후보 비교 매트릭스

| 순위 | 저장소 | ⭐ | 언어 | 라이선스 | 차별화 | 빌드 | 한글 | 플레이 |
|---|---|---|---|---|---|---|---|---|
| 🥇 | owner/repo | stars | Lang | MIT | 9/10 | 10/10 | 10/10 | 9/10 |

## 📋 후보별 상세 평가
- (URL + 기술 스택 + 활동성 + i18n 현황 + 첫 개선 작업)

## 🎯 최종 추천
- (이유 + 첫 개선 작업 구체화 + 1단계 행동)

## ⚠️ 회피 후보
- (고려했으나 제외한 후보 + 제외 이유 — IP 충돌 / 라이선스 / 이미 한국어 활발 등)
```

**Format rationale**: User asked for "3~5개 + 최종 추천" — table for at-a-glance comparison, sections for depth, final pick with concrete next step, plus explicit "rejected" section so user understands the screening.

## Pitfalls (encountered in real sessions)

1. **Single-query search misses diversity** — searching only "open source game" returns mostly engines/tutorials. Always batch 8-12 genres.

2. **`NOASSERTION` license ≠ unrestricted** — many game repos never set a LICENSE file. Check `LICENSES/`, `LICENSE.md`, `REUSE.toml`, `package.json#license`. If unclear, treat as "all rights reserved" → flag in report. Cannot fork legally without explicit license.

2b. **🔴 듀얼 라이선스 분리 함정 (youtd2 2026-07-27 verified)** — root `LICENSE`는 MIT지만 `assets/LICENSE.md`는 **CC-BY-NC 4.0**인 경우 多. "라이선스 OK" → fork → 상업 빌드 시도 시 NC 위반. **preflight에서 반드시 두 가지 모두 확인**:
   - root `LICENSE` / `LICENSE.md` (코드)
   - `assets/` `content/` `textures/` `images/` `audio/` `sounds/` `sfx/` `music/` 하위 별도 `LICENSE.md`
   - 두 라이선스 다 OK일 때만 상업 배포 가능으로 표시. NC 포함 시 "비상업 fork만 OK" 명시.

3. **🔴 External asset hosting (Google Drive / Dropbox / Mega) — Silent build-fail (youtd2 2026-07-27 verified)** — 인디 Godot/JS 게임은 `.png`/`.ogg`/`.mp3` 같은 무거운 에셋을 git LFS 회피하려고 Google Drive에 분리 호스팅. `CONTRIBUTING.md`에 "Download from this Drive" 단계가 있으면:
   - fork 받으면 78MB 중 22MB (코드만) — **즉시 플레이 불가**
   - 에셋은 별도 다운로드 (gdown 30분+ vs curl 병렬 49초, see `oss-fork-localization` references)
   - preflight에서 무조건 확인:
     ```bash
     grep -E "drive\.google\.com|dropbox\.com|mega\.nz" README.md CONTRIBUTING.md
     # → 매치 있으면 외부 에셋 = 빌드 불가 (에셋 없으면)
     ```
   - top 5 후보에서 외부 에셋 후보 발견 시 사용자에게 **5단계 preflight 모두 통과 전까지 "final recommendation" 금지**.

4. **🔴 CLA + 외부 에셋 = "독립 fork only" 신호 (youtd2 2026-07-27 verified)** — `CONTRIBUTING.md`/`docs/CLA.md`에 다음 키워드 발견 시 PR로 가면 안 됨:
   - "you assign copyright" / "transfer all rights" / "grant all transferrable rights" / "copyright assignment"
   - "re-licensing the code" by maintainer
   - "do not modify any copyright statements"
   - **판별**: PR 보내면 코드 저작권 양도 → fork 가치 의문. **독립 fork (sigco3111/<name>-kr)로 가야 함**. scoring matrix의 "PR 머지 가능성"을 0으로 두고, 차별화 가치는 10/10 유지.

4b. **🔴🔴 "Red flag bundle" — 3개 시그널 동시 발견 시 즉시 STOP (youtd2 2026-07-27 lesson)** — 아래 3개 중 **2개 이상** 매칭되면 final recommendation 금지, 사용자에게 clarify 필수:
   1. **외부 에셋 호스팅** (Google Drive / Dropbox / Mega) — `CONTRIBUTING.md` grep
   2. **CLA 저작권 양도** — `CONTRIBUTING.md` grep
   3. **듀얼 라이선스 분리** (코드 MIT + 에셋 CC-BY-NC) — `assets/LICENSE.md` grep

   **근거**: youtd2가 이 3개를 다 갖고 있었는데 스카우팅이 미처 잡지 못함. 사용자가 "에셋 받아서 풀빌드" 선택 → 78MB 다운로드 + 폰트 fallback 작업 + 빌드 에러 → 결국 종료. **3개 중 1개만 있어도 비용 큼, 2개 이상이면 PR 가치 의심**.

   **preflight grep 한 줄**:
   ```bash
   curl -fsSL "https://raw.githubusercontent.com/OWNER/REPO/$(gh repo view OWNER/REPO --json defaultBranchRef -q .defaultBranchRef.name)/CONTRIBUTING.md" 2>/dev/null \
     | grep -E "drive\.google|dropbox|mega\.nz|assign copyright|transfer all rights|re-licensing" \
     || echo "no red flags in CONTRIBUTING.md"
   # assets/LICENSE.md 별도 확인
   curl -fsSL "https://raw.githubusercontent.com/OWNER/REPO/.../assets/LICENSE.md" 2>/dev/null \
     | grep -E "BY-NC|non.?commercial" && echo "NC license detected"
   ```

   **작업 순서**: red flag 1개 → Phase 5에서 명시 후 추천 OK / 2개+ → clarify로 사용자 결정 받기 전까지 "final recommendation" 표시 금지.

4c. **⚠️ 한국어 polish 측정 — upstream 비교 필수 (Evolve 2026-07-27 verified)** — `strings.ko-KR.json`이 있고 영문 잔존이 적어 보여도, **upstream master와 비교**해야 진짜 polish 가치를 알 수 있음:
   - Evolve: `strings.ko-KR.json` 10,166 lines (upstream master) vs 11,672 lines (내 fork) = **1,506 lines 순수 polish** = 1,506 신규 key 추가
   - 즉 Evolve의 한/영 잔존 22.5%는 polish 가치 있지만, **upstream master 자체가 이미 10,164 key 한국어**라 fork 가치 = 추가 1,506 key
   - **PR diff 통계상 0 commits between** 함정: GitHub가 fork branch HEAD의 parent = upstream master HEAD면 "0 commits" 판단. **JSON 신규 key 추가는 line diff로 보이지만 GraphQL의 "commits"는 git commit count 기반** — git commit은 1개라도 통계상 OK
   - **해결**: `gh pr create`가 cross-fork에서 "0 commits" 에러 시 `--base master`를 명시하고, **GraphQL 캐시 5-10분 후 재시도** 또는 **GitHub UI 직접** (https://github.com/UPSTREAM_OWNER/UPSTREAM_REPO/compare/UPSTREAM_DEFAULT_BRANCH...FORK_OWNER:BRANCH).

5. **`licenseInfo.key: "other"` = 커스텀 라이선스 함정** — `gh repo view --json licenseInfo`에서 `key`가 `"other"`로 나오면 SPDX 표준 외 자체 라이선스. raw 본문 다운로드 후 차단 키워드 검사 필수:
   - `"commercial purposes"` 금지 → fork 가치 의문
   - `"reserve the right to request"` (삭제 요구권) → PR 머지해도 권리 불안정
   - `"All Rights Reserved"` → 사실상 사용 불가

   실 사례: `R74n/sandboxels`는 439⭐이지만 R74n Content License v1.1이 셋 다 포함 → 1순위 후보에서 제외됨. 라이선스 본문 5분 안 보면 절대 발견 못 함.

6. **`pushed_at` 6+ months ago = likely abandoned** — even with high stars. Filter: pushed within 90 days for green light, 6 months for caution, older = deprioritize unless legendary (Cave Story remake, etc.).

7. **Korean GitHub Issue/PR search misses external translation services** — many repos track translations in Crowdin/Weblate/POEditor, not GitHub Issues. Check `locales/` directory directly for the real status.

8. **macOS C++ builds are a 90-min trap** — same lesson as `cpp-game-koreanization` Phase 0. Before recommending a C++ game, verify it has a working build path or a CI artifact. Otherwise the candidate is "show but don't fork".

9. **IP-conflicting games** — Pokemon fan-games (PokeRogue), Disney/Studio-IP remakes, MUGEN-with-stolen-assets. The fork itself is fine on GitHub but **limits distribution** (no Steam, no App Store, no commercial release).

10. **`pushed_at` is commit, not release** — a repo with daily commits but no release in 2 years = developer-only mode. Verify the game is actually playable by users (downloadable artifact, web demo, Steam page), not just maintainers.

11. **Don't confuse "active i18n" with "active Korean i18n"** — repos with 200+ localization PRs (e.g. PokéRogue, Mindustry) often have a mature translation team already. Check if Korean-specific PRs are recent or stale.

12. **Game frameworks ≠ games** — KoBeWi/Metroidvania-System is a Godot framework, not a game. Forks here mean "demo game + framework update" — different work type than forking a complete game.

13. **PR workflow > email contributor** — for small localization fixes, open PR directly. Don't ask "want to translate?" — say "here's the PR, ping me if changes needed".

14. **`gh search repos -L <N>` (대시 L, 카운트)** — `--limit` 아님. `--limit` 쓰면 "unknown flag" 에러. 동일하게 `gh search repos --json fields` 사용 가능 필드 확인 가능.

15. **`gh repo view --json` vs `gh search repos --json` 필드명 다름**:
    - `gh repo view`: `primaryLanguage`, `stargazerCount`, `licenseInfo`, `pushedAt`, `updatedAt`, `description`, `url`
    - `gh search repos`: `language`, `stargazersCount`, `license`, `pushedAt`, `updatedAt`, `description`, `url`
    - 잘못된 필드명 쓰면 "Unknown JSON field" 에러. 양쪽 다 사용 직전 `gh ... --help`로 확인 권장.
    - **실수 패턴**: `gh search repos --json licenseInfo` (X) → `license`만 사용 가능. `gh search repos --json primaryLanguage` (X) → `language`만 사용 가능. 단, `primaryLanguage`는 nested object `{"name":"..."}` 반환, `language`는 string 반환.

16. **한국어 strings 파일이 "존재"한다고 완성된 건 아님** — `strings.ko-KR.json`이 있어도 5-15%는 영문 잔존 (토큰·기술용어·수치 제외). 실측 필수:

    ```bash
    curl -fsSL <url> | python3 -c "
    import json,sys
    d=json.loads(sys.stdin.read())
    not_ko = [k for k,v in d.items() if v and not any(0xAC00 <= ord(c) <= 0xD7A3 for c in v) and len(v) > 5]
    print(f'non-korean (longer values): {len(not_ko)}/{len(d)}')
    "
    ```

    polish 임팩트가 큰 케이스 = 한국어 키 1000+ 보유 + 영문 잔존 5%+ (예: `pmotschmann/Evolve` 10,164 키 중 **1,213개 영문 잔존** → polish 가치 큼). 반대로 `R74n/sandboxels`처럼 잔존 1-2%면 신규 번역보다 다른 후보로 이동.

    **07-27 실측**: Evolve 22.5% residue (2,291/10,164). 위 추정보다 훨씬 높음. **5%+ 일반화 OK, 22.5%도 케이스별로 충분히 발생**.

17. **메타데이터 `language: ""` (빈 문자열) ≠ 라이브러리** — `break_infinity.js`, `discord.py` 류는 `language: ""` 인데 description에 "game" 들어가도 라이브러리. description과 repo topic 둘 다 확인 필수.

18. **`gh search issues "repo:OWNER/REPO keyword"` 쿼리 파싱 실패 함정** — `gh search issues` CLI는 `repo:` 한정자 + 추가 키워드를 같은 인자에 공백 한 칸으로 넘기면 "Invalid search query" 에러를 뱉음:
    - ❌ `gh search issues "repo:oskarrough/slaytheweb korean"` → 파싱 실패
    - ✅ 우회 1: `gh api "search/issues?q=repo:oskarrough/slaytheweb+korean+OR+한국어&per_page=1"` + `total_count` JSON 파싱
    - ✅ 우회 2: GitHub web UI 직접 확인 (`https://github.com/OWNER/REPO/issues?q=korean+OR+한국어`)
    - 카운트만 필요하면 `gh api search/issues` JSON의 `total_count`가 정답 (CLI보다 안정적).

19. **`stargazersCount: null` (혹은 `pushedAt: null`) format string 에러** — 일부 신규/저활동 저장소는 `stargazersCount`나 `pushedAt`가 `null`로 옴. Python f-string에서 `{r['stargazersCount']:>5}`로 직접 쓰면 `TypeError: unsupported format string passed to NoneType`:
    - ❌ `print(f\"  {r['stargazers_count']:>7} | {r['full_name']}\")` → None이면 죽음
    - ✅ `print(f\"  {(r.get('stargazersCount') or 0):>5} | {(r.get('pushedAt') or '')[:10]}\")` 방어
    - preflight 스크립트 작성 시 모든 숫자/날짜 필드에 `or 0` / `or ''` 필수.

20. **Query bank 노이즈 — broad game term 매칭 (07-27 verified)** — `open source game`/`rpg game`/`platformer` 같은 broad 쿼리는 vuejs/tensorflow/opencode/electron + 엔진 (godot/bevy/pixijs) 매칭. 항상 `genre + "game"` 또는 `language:XXX`로 좁히기. Phase 1 코드 블록 참고.

21. **🔴 `gh pr create` cross-fork GraphQL "0 commits" 버그 (Evolve 2026-07-27 verified)** — fork 브랜치 → upstream PR 만들 때 gh CLI가 "Head sha can't be blank, No commits between ... and ..., Head ref must be a branch" 에러:
   - **원인**: gh가 fork의 `pr/<name>` 브랜치 HEAD가 upstream master의 HEAD와 같은 ancestor chain을 갖고 있어 0 commit으로 인식
   - **force-push / 브랜치 삭제 후 재생성 / 새 브랜치명 / `--web` / `--fill`** 다 안 됨 (07-27 4회 시도 실패)
   - **유일한 해결**: GitHub UI 직접. URL 형식:
     ```
     https://github.com/UPSTREAM_OWNER/UPSTREAM_REPO/compare/UPSTREAM_DEFAULT_BRANCH...FORK_OWNER:BRANCH?expand=1
     ```
   - 브라우저에서 base/compare 수동 선택 → "Create pull request"
   - **대안 (curl)**: GraphQL mutation으로 cross-fork PR 생성 가능. 단 첫 시도가 GraphQL 캐시 영향으로 실패할 수 있어 2-3회 재시도.
   - **방어**: PR 생성 전 `gh api repos/FORK_OWNER/REPO/branches/BRANCH` 로 브랜치 존재 + SHA 확인 (0이면 푸시 안 된 것). GitHub UI에서 "Compare changes" 페이지에 1 commit / 1500+ lines 보이면 PR 자체는 문제없음, gh CLI만 문제.

22. **🔴 CLA + PR-permission check 단계 빠뜨림 (OpenFrontIO 07-28 verified)** — `CONTRIBUTING.md` 1개만 보면 라이선스·PR 정책 다 OK라 착각하지만, 실제로는:
    - **CLA (Contributor License Agreement) 존재** — `CLA.md`, `cla-assistant.io/readme/badge/...`, 또는 "I agree to CLA" PR template 체크박스. CLA가 있으면 본인이 본인 코드의 권리를 어도 보증 → PR 보내도 본인에게 권한 없는 상태 발생
    - **첫 contributor는 UI만 가능** — "New Contributors: Limited to UI improvements and small bug fixes only" 같은 점진적 권한 시스템. 한국어 번역 PR (=코드 변경)은 **거절 확률 매우 높음**
    - **Crowdin/Weblate 외부 트랜슬레이션 플랫폼** — README/CONTRIBUTING에서 `[Crowdin](https://badges.crowdin.net/...)` 같은 배지 발견 시, GitHub PR이 아니라 Crowdin에서 번역 작업. 한국어가 이미 있으면 첫 PR 가치 0
    - **preflight grep**:
      ```bash
      curl -fsSL .../CONTRIBUTING.md | grep -iE "cla-assistant|crowdin|weblate|poeditor|first contributor|trainwreck.+contributor|approved.+label|assigned.+before" \
        && echo "🔴 PR restrictive policy detected"
      ```

23. **`gh repo view` default 출력은 README markdown (07-28 verified)** — `gh repo view OWNER/REPO` 기본은 markdown 형식의 README 본문. JSON으로 받으려면 반드시 `--json` 플래그 + `--jq`. **권장**: `gh repo view --json` 보다는 **`gh api repos/OWNER/REPO --jq`** 가 (1) 더 적은 필드, (2) CLI 호환성 보장, (3) rate 1회로 압축 가능:
    ```bash
    # ❌ stdout = README markdown, json 안 옴
    gh repo view "owner/repo"
    # ✅ 안정 (jq로 필요한 필드만)
    gh api repos/owner/repo --jq '.stargazers_count, .pushed_at, .license.spdx_id, .topics | join("|")'
    ```

24. **Godot addon ≠ 게임 fork (07-28 verified)** — Godot 어드온 (beehave, godot_dialogue_manager 등)은 1차 가치가 "fork 자체"가 아니라 "한국어 어드온 그대로 받음". PR 가치 = **`l10n/<lang>.po` 1파일 추가** 수준. CONTRIBUTING이 짧고 ("fork and raise PR") 라이선스 MIT면 첫 PR 30분~1시간이면 끝. **게임 후보 풀에 addon도 포함해서 비교**할 것. 예: `nathanhoad/godot_dialogue_manager` (3,733★, MIT, addons/dialogue_manager/l10n/translations.pot 167 msgid, en/es/uk/zh/zh_TW만 존재 — ko greenfield).

25. **`/Users/mac/work/` 가 단일 진실 소스(SSoT) — git remote로 자동 exclude (07-28 verified)** — 사용자 fork 디렉토리만으로 "작업 중/완료" 후보 5~10개 자동 발굴. 이 디렉토리 안 보면 검색 결과로 다시 추천하는 사고 발생. 매 스카우팅 세션 첫 30초에 1번 실행. (Phase 0의 "Exclude Cross-Check" 참조.)

26. **🔴 `gh api repos/OWNER/REPO/git/trees/<branch>?recursive=1` → 빈 응답 함정 (07-28 verified)** — 대용량 repo (300+ 파일)나 일부 sparse repo에서 `recursive=1` 호출이 `[0m[0m` 같이 빈 결과 반환. `0` (count) 때문에 모든 후보가 "no i18n files"로 오판됨:
   - **원인**: GitHub tree API는 결과가 6MB 초과 또는 100k+ 파일이면 truncate. sub-tree만 보고싶어도 recursive=1이 전체를 직렬화
   - **해결 1**: `gh api repos/OWNER/REPO/contents/<path>` 로 **경로 지정** (root 또는 `assets/` 등) 후 recursively depth-2
   - **해결 2**: i18n 후보 디렉토리 (`i18n/` `locales/` `lang/` `translations/`)만 **경로 지정 contents API**로 직접 ls:
     ```bash
     # 후보 root 디렉토리 한 번에
     gh api repos/OWNER/REPO/contents --jq '[.[] | .name] | join(",")'
     # 디렉토리 안 파일
     gh api repos/OWNER/REPO/contents/assets/locals --jq '[.[] | .name] | join(",")'
     ```
   - **느린 해결**: `gh api "repos/OWNER/REPO/contents/<dir>"` 단건 + sleep 1.2초로 매 디렉토리 직접 ls (Phase 3 단계 권장 패턴)
   - **함정 패턴**: `gh api .../git/trees/main?recursive=1` 결과가 0줄 → 절대 "i18n 없음" 결론 내리지 말 것. 반드시 contents API로 재확인.

27. **🔴 GitHub search API secondary rate limit 403 (07-28 verified)** — 인증된 사용자도 짧은 시간에 `api.github.com/search/repositories` 12회+ 연속 호출 시 `403 API rate limit exceeded` 반환. 그런데 `/rate_limit` 엔드포인트는 정상 (`4990/5000`) — search endpoint만의 **secondary limit**:
   - **증상**: `search/repositories?q=...` → 403 / `repos/OWNER/REPO` → 정상
   - **해결 1**: `gh search repos "keyword" --limit 5` (CLI) 사용 — secondary limit 별도 풀
   - **해결 2**: `gh api repos/OWNER/REPO --jq '...'` 로 **미리 발굴된 full_name 1건씩** 단건 조회 + `sleep 1.2`
   - **해결 3 (최후)**: 1-2분 대기 후 재시도. secondary limit은 보통 1-2분 cooldown
   - **방어 패턴**: 12 query batch 실행 후 0 결과가 나오면 99% secondary limit → batch 분할 또는 단건 fallback

28. **🔴 `translations/` 디렉토리 내 한글 filename — koIssues=0인데 한국어 이미 진행 중 (Monogatari 07-28 verified)** — `search/issues?q=repo:OWNER/REPO+korean+OR+한국어` 0건 = greenfield 신호로 오판하기 쉬움. 그러나 `src/translations/` 같은 디렉토리 안에 이미 `한국어.ts`, `日本語.ts`, `العربية.ts` 같은 **localized filename**이 존재할 수 있음:
   - 실 사례: Monogatari의 ko 이슈 0건이지만 `src/translations/한국어.ts` (2,798 bytes) 이미 존재 → 추천 가치 0
   - **검증 단계 (Phase 3 필수)**:
     ```bash
     # translations/ 디렉토리 ls에서 영문 아닌 (CJK, Arabic, Cyrillic 등) 파일명 검사
     gh api repos/OWNER/REPO/contents/src/translations --jq '[.[] | .name] | join("\n")' \
       | grep -E '[^\x00-\x7F]' && echo "🔴 localized filenames exist — 차별화 가치 없음"
     ```
   - **greenfield 진짜 정의**: translations 디렉토리에 `ko.*`/`한국어.*`/`Korean.*` **부재** AND ko 이슈/PR **부재** + 둘 다 확인해야 함
   - **빠뜨림 패턴**: koIssues만 보고 디렉토리 미확인 → "Monogatari가 1순위 후보" 같은 사고 발생 (다국어 엔진이라 21개 언어 이미 진행 중이었음)

29. **🔴 i18n 인프라 착시 — "있어 보이지만 실측 분량 적음" 함정 (BigJk/end_of_eden 07-28 verified)** — `assets/locals/` 같은 폴더 + `de/` 같은 기존 번역 디렉토리가 있으면 "i18n 인프라 갖춤 → greenfield 가치 없음"으로 오판하기 쉬움. 그러나 다음을 실측해야 함:
   - **실제 번역 분량**: 기존 locale 파일의 line 수 + top-level 키 수. `wc -l assets/locals/de/*.yml` + `yq` 또는 Python yaml로 키 카운트
   - **번역이 적용되는 범위 vs 코드에 하드코딩된 범위**: 코드 검색으로 `register_card("X", { name = "...", description = "..." })` 같이 Lua/JS에 박힌 영문 텍스트가 얼마나 있는지 확인. **end_of_eden 사례**: 23개 카드 중 `de/cards.yml`에는 단 **1개** 카드만 번역 (`MELEE_HIT`). 나머지 22개는 Lua에 영문 박혀있어서 fallback 동작. 즉 인프라 0.001%만 활용 중
   - **진짜 greenfield 신호**: (a) `assets/locals/ko/` 디렉토리 자체 부재 + (b) `register_card` 등 코드 내 하드코딩 발견 + (c) 기존 다른 locale 분량 적음 → 3개 동시 매치 시 신규 locale 추가가 high-value
   - **빠뜨림 패턴**: Phase 3 i18n Readiness 점수를 "10/10 (greenfield)"로 단정 → 실제 작업 들어갔을 때 "UI 텍스트는 코드에 박혀있어서 번역 안 됨" 발견 → 1차 PR 범위 80% 축소
   - **preflight 측정** (5분):
     ```bash
     # 1) 기존 locale 분량
     for f in assets/locals/*/*.yml; do wc -l "$f"; done
     # 2) 코드 내 영문 하드코딩 카운트
     grep -rE 'register_(card|enemy)\("' assets/scripts/ | wc -l
     # 3) Lua에서 l("key", default) fallback 패턴 검색 (번역 hook 흔적)
     grep -rE 'l\("cards?\.assets/scripts/ | head -5
     ```
   - Phase 3 점수에 "i18n 인프라 있음(0.1) + 실제 작업 분량(0.9)" 가중치 분리해서 보고

29b. **TUI/헤드리스 게임 i18n 검증 — 별도 main.go 스캐폴드 (end_of_eden 07-28 verified)** — ebitengine/raylib/cocos2d-x 등 GUI 게임은 헤드리스 실행 + 스크린샷 자동화가 까다로움 (Xvfb, OpenGL 컨텍스트 필요). i18n 패키지만 import하는 새 main.go를 `/tmp/...`에 두고 `go run`으로 검증하는 패턴이 안전. **재사용 스크립트**: `scripts/i18n-loader-probe.sh` (Go 게임용) — repo 경로 + i18n 패키지 import path + 테스트 키 배열 인자 → scaffold + `go run` + 결과 출력 자동. Pitfall 29c와 세트로 사용.
   ```go
   package main
   import (
       "fmt"; "os"
       "github.com/OWNER/REPO/system/localization"
   )
   func main() {
       if err := localization.Global.AddFolder("./assets/locals"); err != nil {
           fmt.Println("AddFolder error:", err); os.Exit(1)
       }
       fmt.Println("Loaded locales:", localization.Global.GetLocales())
       for _, l := range localization.Global.GetLocales() {
           for _, k := range []string{"settings.audio.title", "basics.on", "cards.ADRENALINE_SHOT.name"} {
               fmt.Printf("  %s/%s = %q\n", l, k, localization.Global.Get(l, k))
           }
       }
   }
   ```
   - **장점**: (a) TUI 실행 불필요, (b) 모든 locale 등록 확인, (c) fallback 동작 확인, (d) PR 본문에 "verified via headless loader: Loaded locales [de ko en]" 문구 가능 → 메인테이너 수용률 ↑
   29c. **🔴 Nerd Font 전용 게임 — 한글 시각 검증 불가능 함정 (end_of_eden 07-28 verified)** — 게임이 **Nerd Font만 사용**할 때 (예: `assets/fonts/IosevkaTermNerdFontMono-Regular.ttf`, `BigBlueTermPlusNerdFont-Regular.ttf`) 한국어 PR의 시각 검증을 PTY/script로 캡처할 수 없음. 두 가지 함정:
   - **Nerd Font = 한글 glyph 없음**: 화면에 한글 텍스트가 있어도 tofu(▯)로 렌더링. PR에 첨부 가능한 스크린샷 확보 불가
   - **ebitengine 픽셀 렌더링**: `script -q ./game` 으로 캡처해도 셀(cell) 단위 그래픽이라 멀티바이트 한글 추출 불가. `cat -v` 해보면 `M-^V` 같은 raw byte만 보임
   - **스크린샷 확보 경로 3가지** (모두 비용 큼):
     1. **`assets/fonts/`에 한글 폰트 추가** (예: NotoSansKR-Regular.ttf) — 별도 PR. **라이선스 검증 필요** (OFL/Apache만 OK), 파일 크기 (5~10MB)
     2. **macOS native 스크린샷** (TUI는 alt-screen이라 `screencapture`가 빈 화면만 캡처). 게임 자체를 데스크탑 윈도우로 띄우는 ebitengine 설정 필요
     3. **PR에 스크린샷 생략** — 단위 테스트 (Pitfall 29b) + 코드 diff가 증거. 메인테이너가 로컬 검증
   - **preflight grep (Phase 6 추가)**:
     ```bash
     grep -rE 'NerdFont|Meslo|Consolas|JetBrainsMono' assets/fonts/ README.md cmd/ --include="*.ttf" --include="*.md" --include="*.go"
     ```
     Nerd Font 감지 → "스크린샷 확보 별도 작업 필요" 메모리에 기록 + PR 본문에 `Nerd Font only — visual verification deferred to upstream maintainer (or font-PR follows)` 명시
   - **빠뜨림 패턴**: PR 본문에 "screenshots attached" 약속 → 캡처 시도가 깨져서 약속 불이행 → 메인테이너 의심. **한국어 시각 검증 = 항상 tofu. 코드 diff + 단위 테스트만 신뢰**
   - **end_of_eden 실측 결과** (PR 본문 인용 가능):
     ```
     Loaded locales: [de ko en]
     ko/settings.audio.title = "오디오"
     ko/basics.on = "켜기"
     ko/cards.ADRENALINE_SHOT.name = "아드레날린 주사"
     de/basics.on = "An"
     en/basics.on = "basics.on"  # fallback: 키 그대로 반환
     ```

## Phase 6 — Post-Selection i18n Architecture Reconnaissance (5 min)

**final pick 확정 후, fork 전에** i18n이 실제로 어떻게 동작하는지 5단계로 정찰. 이 단계 빠뜨리면 Phase 5 추정의 50% 이상이 틀어짐:

1. **Locale 코드 형식**: 2글자 (`ko`)? BCP-47 (`ko-KR`)? 둘 다? — 코드 grep으로 확인
   ```bash
   grep -rE 'SetCurrent|locale|"en"|locales\[' system/ internal/ --include="*.go" --include="*.ts" --include="*.lua"
   ```
2. **자동 스캔 vs 수동 등록**: 폴더 기반 (`AddFolder("assets/locals")`) vs 명시적 import vs locale별 config 파일
3. **Fallback 체인**: 누락 키 → 영어 → key 그대로 반환? Lua `l("key", default)` 같은 inline default가 있는지?
   ```bash
   grep -rE 'l\(.*default\)|t\(.*default\)|_(".*",.*")' assets/scripts/ --include="*.lua" --include="*.ts"
   ```
4. **기존 번역 분량 실측**: 다른 locale 파일들의 line/키 수 → 신규 locale PR이 어느 정도 규모인지 가늠
   ```bash
   find assets/locals -name "*.yml" -exec wc -l {} \;
   find assets/locals -name "*.yml" -exec yq '.. | select(tag == "!!str") | path | join(".")' {} \; 2>/dev/null | wc -l
   ```
5. **빌드 툴체인 확인**: Go/Rust/Node/Cargo 중 무엇? 설치되어 있는지? **미설치 시 PR에 "tested locally: N/A (build chain unavailable)" 명시 필요** — 메인테이너 수용률 하락

**end_of_eden 사례 (07-28 verified)**:
1. ✅ 2글자 강제 (`localization.go:94: if len(local) != 2 { return error }`) → `ko` OK, `ko-KR` NG
2. ✅ `AddFolder("./assets/locals")` 자동 스캔 — 폴더만 만들면 끝
3. ✅ Lua `l("cards.<id>.name", weapon.name)` inline fallback — 부분 번역 안전
4. ⚠️ `de/cards.yml`은 5줄 (1개 카드만). 즉 인프라만 있고 실제 작업 분량 매우 적음 → 신규 locale 가치 ↑ (Pitfall 29 참조)
5. ❌ Go 미설치 → 빌드 검증 불가 → PR 본문에 명시 필요

**산출물**: Phase 5가 추천한 "첫 개선 작업" 범위를 이 단계 결과로 **재조정**:
- i18n 인프라 없을 때 → PR 1 = "i18n 인프라 도입" (큰 작업)
- i18n 인프라 + 기존 번역 풍부 → PR 1 = "ko 전체 번역" (큰 작업)
- i18n 인프라 + 기존 번역 빈약 (end_of_eden) → PR 1 = "신규 locale 폴더 + 베이스 + 카드 1~3개" (작은 작업, PR 가치 큼)

상세 체크리스트 + 코드 스니펫은 `references/i18n-architecture-recon.md`.

## Reference

- `references/2026-07-27-validated-candidates.md` — 검증된 TOP 5 + 회피 6개 + 빌드 비용 (재실행 불필요)
- `references/2026-07-28-newly-validated-candidates.md` — `nathanhoad/godot_dialogue_manager` 외 3 검증 (gettext 패턴 + addon 분류 + exclude SSoT 학습)
- `references/genre-query-bank.md` — 30+ query templates organized by genre + scope filters + anti-patterns
- `references/i18n-architecture-recon.md` — **post-scout i18n 정찰 체크리스트** (locale 코드 형식, 로딩 메커니즘, fallback 체인, 기존 번역 분량, 빌드 툴체인). `end_of_eden` (Go, 2글자 locale, Lua 폴백) 케이스 스터디 포함.
- `references/i18n-pre-pr-verification.md` — locale 파일 작성 후 PR 직전 검증 (standalone `verify_ko.sh` 패턴, TUI 스크린샷 불가능 함정, 폰트 추가 무용 함정, pre-PR checklist)
- `scripts/scout-games.sh` — re-runnable batched search script (token-aware, customizable genre list)
- `scripts/i18n-loader-probe.sh` — headless i18n loader verification (Pitfall 29b). Go 게임의 i18n 패키지만 import하는 probe main.go 자동 생성 + `go run` 결과 출력. Nerd Font 게임(Pitfall 29c)에서 단위 검증의 SSOT.

## Next steps after scouting

Once a candidate is selected, existing skills take over:

- **`oss-fork-localization`** — full fork workflow (LICENSE/MODIFIED, preflight check, distribution)
- **`cpp-game-koreanization`** — game-specific (PO files, JSON modpacks, browser ESM, LÖVE)
- **`github-cli`** — repo setup, PR workflow, releases
- **`build-environment-preflight-check`** (under oss-fork-localization references) — 5-min build verification BEFORE any translation work
