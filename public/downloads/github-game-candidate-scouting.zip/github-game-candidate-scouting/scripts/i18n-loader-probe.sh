#!/bin/bash
# i18n-loader-probe.sh — Headless i18n loader verification for Go games
#
# Usage:
#   i18n-loader-probe.sh <REPO_PATH> <IMPORT_PATH> <LOCALE> [LOCALE_DIR] [KEY1,KEY2,...]
#
# Example (end_of_eden):
#   ./i18n-loader-probe.sh \
#     /Users/mac/work/end_of_eden \
#     "github.com/BigJk/end_of_eden/system/localization" \
#     ko \
#     ./assets/locals \
#     "basics.on,settings.audio.title,cards.ADRENALINE_SHOT.name"
#
# What it does:
#   1. Creates a /tmp probe dir with a small main.go that calls the i18n loader
#   2. Runs `go run` from the repo path (so go.mod resolution works)
#   3. Prints loaded locales + sample key values for visual verification
#
# Why this exists (end_of_eden 07-28 lesson):
#   - ebitengine/raylib games are hard to run headlessly
#   - But the i18n package alone has no audio/X11 deps — perfect for unit-style probe
#   - Saves 5+ min of hand-writing the probe main.go each time
#
# Pitfall: this only verifies YAML loading + key lookup. Visual rendering (Korean glyph
# coverage in the game's font) is a separate concern — see SKILL.md pitfall 29c.

set -e

REPO_PATH="${1:?REPO_PATH required}"
IMPORT_PATH="${2:?IMPORT_PATH required (e.g. github.com/OWNER/REPO/system/localization)}"
LOCALE="${3:-ko}"
LOCALE_DIR="${4:-./assets/locals}"
KEYS="${5:-basics.on,settings.audio.title,cards.ADRENALINE_SHOT.name}"

if [ ! -d "$REPO_PATH" ]; then
    echo "❌ REPO_PATH not found: $REPO_PATH"
    exit 1
fi

PROBE_DIR=$(mktemp -d)
trap 'rm -rf "$PROBE_DIR"' EXIT

# Build the key array literal for Go
KEY_ARR=""
IFS=',' read -ra KEY_ARRAY <<< "$KEYS"
for k in "${KEY_ARRAY[@]}"; do
    KEY_ARR+="\"$k\","
done
KEY_ARR="${KEY_ARR%,}"

cat > "$PROBE_DIR/main.go" <<EOF
package main

import (
	"fmt"
	"os"
	"strings"
	"$IMPORT_PATH"
)

func main() {
	if err := localization.Global.AddFolder("$LOCALE_DIR"); err != nil {
		fmt.Println("AddFolder error:", err)
		os.Exit(1)
	}
	locales := localization.Global.GetLocales()
	fmt.Println("Loaded locales:", locales)

	testKeys := []string{$KEY_ARR}
	fmt.Println("\\n--- [$LOCALE] verification ---")
	pass, fail := 0, 0
	for _, k := range testKeys {
		v := localization.Global.Get("$LOCALE", k)
		ok := "OK"
		if v == k || strings.HasPrefix(v, k) {
			ok = "MISS"
			fail++
		} else {
			pass++
		}
		fmt.Printf("  [%s] %s = %q\\n", ok, k, v)
	}
	fmt.Printf("\\n========== RESULT ==========\\nPASS: %d\\nFAIL: %d\\nTOTAL: %d\\n",
		pass, fail, len(testKeys))
	if fail > 0 {
		os.Exit(1)
	}
}
EOF

cd "$PROBE_DIR"
go mod init probe >/dev/null 2>&1 || true
go run "$PROBE_DIR/main.go"