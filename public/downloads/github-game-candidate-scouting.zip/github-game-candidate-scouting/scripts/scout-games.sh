#!/bin/bash
# scout-games.sh — Multi-query GitHub game candidate scouting
#
# Usage:
#   ./scout-games.sh                    # default 12-genre batch
#   ./scout-games.sh -q "rpg game roguelike"   # custom (space-separated)
#   QUERIES="rpg tower defense" ./scout-games.sh
#   MIN_STARS=200 ./scout-games.sh      # filter low-signal results
#
# Output: tab-separated rows → easy to grep/sort.
# Requires: GitHub token at ~/.hermes/secrets/github_token.txt (chmod 600).

set -euo pipefail

TOKEN_FILE="${HOME}/.hermes/secrets/github_token.txt"
if [ ! -f "$TOKEN_FILE" ]; then
  echo "ERROR: $TOKEN_FILE not found" >&2
  echo "Create one: openssl rand -hex 32 or 'gh auth token' value" >&2
  exit 1
fi

TOKEN="$(cat "$TOKEN_FILE")"

DEFAULT_QUERIES="open source game rpg game roguelike tower defense incremental game puzzle game visual novel engine platformer game card game simulation game action rpg deckbuilder"

QUERIES="${QUERIES:-$DEFAULT_QUERIES}"
MIN_STARS="${MIN_STARS:-0}"

# CLI: -q "queries" overrides QUERIES env
while getopts "q:" opt; do
  case "$opt" in
    q) QUERIES="$OPTARG" ;;
    *) echo "Usage: $0 [-q 'query1 query2 ...']"; exit 1 ;;
  esac
done

PER_PAGE="${PER_PAGE:-4}"

for q in $QUERIES; do
  echo "=== $q ==="
  curl -s -H "Authorization: token $TOKEN" \
    "https://api.github.com/search/repositories?q=${q// /+}&sort=stars&order=desc&per_page=${PER_PAGE}" \
    | python3 -c "
import json, sys, os
min_stars = int(os.environ.get('MIN_STARS', '0'))
data = json.load(sys.stdin)
for r in data.get('items', []):
    stars = r['stargazers_count']
    if stars < min_stars: continue
    license = (r.get('license') or {}).get('spdx_id', 'NOASSERTION')
    pushed = r.get('pushed_at','')[:10]
    print(f\"  {stars:>7} | {(r.get('language') or 'None'):<12} | {r['full_name']:<45} | {license:<10} | pushed={pushed} | {(r.get('description') or '')[:60]}\")
" 2>/dev/null
done

echo ""
echo "(tip: MIN_STARS=200 ./scout-games.sh  to filter low-signal)"
echo "(tip: -q 'rpg deckbuilder' for a single-genre targeted scan)"