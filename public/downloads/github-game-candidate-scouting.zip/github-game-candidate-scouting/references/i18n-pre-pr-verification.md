# i18n Pre-PR Verification for OSS Game Forks

Reusable patterns and pitfalls for verifying a Korean (or other) localization PR **before** pushing to upstream. Captured from a real session working on `BigJk/end_of_eden` (Go + bubble tea + ebitengine TUI game, 2026-07-28).

This document assumes you have already done scouting + fork + locale file creation following the parent skill's Phase 0-5. It covers the gap between "files written" and "PR opened": proving the translation loads correctly.

---

## Standalone Verification Script Pattern

**When to use**: the upstream project has **no Go test files** (`*_test.go`) but the i18n system is testable through Go code.

**Why this shape, not a `*_test.go`**: adding the project's first test file in an i18n PR is a stylistic departure the maintainer may not want to review. A standalone shell script keeps the verification self-contained and runnable with the project's existing `go` toolchain.

**Pattern** (`verify_ko.sh`):

```bash
#!/bin/bash
# 1. Locate the repo (current dir or first arg)
REPO_ROOT="${1:-$(pwd)}"

# 2. Sanity check
if [ ! -d "$REPO_ROOT/assets/locals/ko" ]; then
    echo "ERROR: $REPO_ROOT/assets/locals/ko not found."
    exit 1
fi

# 3. Build a temp Go program that exercises the real i18n code path
WORK=$(mktemp -d)
trap "rm -rf $WORK" EXIT
cat > "$WORK/main.go" <<EOF
package main

import (
    "fmt"
    "os"
    "strings"
    "github.com/<owner>/<repo>/system/localization"
)

func main() {
    if err := localization.Global.AddFolder("$REPO_ROOT/assets/locals"); err != nil {
        fmt.Println("AddFolder error:", err); os.Exit(1)
    }
    expected := []string{ /* hard-coded list of keys */ }
    pass, fail := 0, 0
    var missing []string
    for _, k := range expected {
        v := localization.Global.Get("ko", k)
        // missing → Get returns either the key string or the en fallback
        if v == k || strings.HasPrefix(v, k) {
            fail++; missing = append(missing, k)
        } else {
            pass++
        }
    }
    fmt.Printf("PASS: %d / FAIL: %d / TOTAL: %d\n", pass, fail, len(expected))
    if fail > 0 {
        for _, k := range missing { fmt.Println("  -", k) }
        os.Exit(1)
    }
}
EOF

# 4. Run from the repo root so go.mod resolves module imports
cd "$REPO_ROOT"
go run "$WORK/main.go"
```

**Why `go run` from the repo root**: it picks up `go.mod` and resolves the project's internal imports (`<owner>/<repo>/system/...`) without needing a separate `go.mod` in the temp dir.

**What to assert** (the critical part):
- `Get(locale, key)` returns the **key itself** when the locale is unknown or the key is missing from the locale AND from the `en` fallback.
- So `if v == k { missing }` correctly identifies both "no ko file" and "ko file present but key absent."

**Reference size for a mid-sized game**: ~118 representative keys (cards, status effects, artifacts, enemies, settings) catches the bulk of typos and missing entries without bloating the script.

**Surface the result in the PR body**: copy the script's `PASS: 118 / FAIL: 0 / TOTAL: 118` line verbatim — it gives the reviewer a one-line proof.

---

## TUI Game Screenshot Impossibility (Bubble Tea / Ebitengine)

**Pitfall — read this before promising screenshots**: For Go games using **bubble tea + ebitengine** in TUI mode (`cmd/game/main.go` style, NOT the `cmd/game_wasm/` browser build), you **cannot** capture screenshots via `script`:

```bash
# ❌ This does NOT give you a screenshot
script -q /tmp/log.bin ./game < /dev/null
cat /tmp/log.bin  # → raw ANSI escape sequences, not rendered pixels
```

**Why**:
- bubble tea renders via ANSI escape sequences written to a PTY
- `script -q` captures the raw escape bytes flowing into the PTY master
- The log fills with `38;2;R;G;Bm` true-color codes and pixel-block characters BEFORE menu text appears
- The log buffer hits its 64KB cap mid-render, so even ANSI is truncated
- TUI text characters ARE in the log, but they're interleaved with pixel-render escapes that make manual extraction impractical

**Implication for the PR**:
- Cannot attach a "screenshot of Korean UI" proof to the PR
- Cannot visually verify "한글" actually displays as expected
- The reviewer's machine + terminal font is what determines whether Korean glyphs render

**Verification strategy**:
1. The standalone verification script above is your **only** automated proof
2. In the PR body, explicitly write: "Korean display requires a terminal font with CJK glyphs; verified via `verify_ko.sh` (118/118 keys load), visual confirmation requires running locally."
3. Do **not** claim "tested and working" without qualifying the limit.

**Cross-check pattern** (when you really want to peek):
```bash
# Game prints init logs to stdout BEFORE the TUI takes over.
# Capture those to confirm Settings → Localization init succeeds.
script -q /tmp/init.log ./game < /dev/null &
PID=$!
sleep 1  # capture init phase only
kill -INT $PID
grep -E "Initializing|Done!" /tmp/init.log
# Expect:
#   Initializing Settings. Please wait...   Done!
#   Initializing Localization. Please wait...   Done!
```

---

## Font Addition Is Irrelevant for TUI Builds

**Pitfall — don't waste time adding Korean fonts**: Adding `assets/fonts/NotoSansKR*.ttf` to a Go TUI game does **NOT** help Korean display in the `cmd/game/` (macOS/Linux terminal) build.

**Why**:
- `cmd/game/main.go` does **not** call `crt.LoadFaces` or any font loader
- Only `cmd/game_win/main.go` (Windows GUI) and `cmd/game_wasm/` (browser) load fonts from `assets/fonts/`
- TUI mode prints text to a PTY; the **host terminal's font** (iTerm2, Terminal.app, Windows Terminal, gnome-terminal, ...) does the rendering
- Whether Korean glyphs appear as glyphs or as `▯▯` tofu is determined by the user's terminal font, not by anything in the repo

**What to do instead**:
- **Don't** add Korean fonts in an i18n PR — it adds repo size, no runtime benefit, and dilutes the PR's purpose
- In the PR body, mention the terminal-font requirement as a note (not a blocker)
- If a separate "fallback font" feature is wanted, file it as a follow-up issue rather than bundling it into the i18n PR

**How to confirm** (when in doubt):
```bash
# Search for font loader calls in each cmd/ build target
grep -rn "LoadFaces\|font_dpi\|LoadFont" cmd/
# If only cmd/game_win/ and cmd/game_wasm/ appear → TUI build doesn't load fonts
```

---

## Pre-PR Verification Checklist

```
[ ] Standalone verify script written
[ ] Script exits 0 with "PASS: N / FAIL: 0" on this branch
[ ] Script output captured for PR body
[ ] YAML files validated with `python3 -c "import yaml; yaml.safe_load(open(...))"`
[ ] Game builds without errors (`go build ./cmd/game`)
[ ] Game init log shows "Initializing Localization... Done!"
[ ] settings_term.json (or equivalent) tested with `language: "ko"` to confirm runtime loading
[ ] No screenshots promised — only key-load verification
[ ] No font files added
[ ] PR body explains: scope (cards/status_effects/artifacts/enemies), what's NOT translated (Lua hardcoded event text), and how to verify (`./verify_ko.sh`)
```