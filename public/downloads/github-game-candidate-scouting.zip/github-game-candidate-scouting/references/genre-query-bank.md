# Genre Query Bank (30+ queries for GitHub game scouting)

Used in Phase 1 (multi-query batched search). Add/modify as new genres emerge.

## Action / Adventure

| Query | Notes |
|---|---|
| `rpg game` | Classic RPG, JRPG |
| `action rpg` | Diablo-like, hack-and-slash |
| `metroidvania` | Cave Story, Hollow Knight clones |
| `roguelike` | Traditional turn-based (NetHack lineage) |
| `roguelite` | Modern action-roguelike (Slay the Spire, Risk of Rain) |
| `dungeon crawler` | First-person dungeon games |
| `platformer game` | Side-scrollers (rare OSS, mostly engines) |

## Strategy / Simulation

| Query | Notes |
|---|---|
| `tower defense` | Bloons, Mindustry lineage |
| `turn-based strategy` | Wesnoth, Advance Wars clones |
| `hex strategy` | Niche — verify before recommending |
| `simulation game` | OpenTTD, SimCity lineage (often huge projects) |
| `sandbox game` | Voxel sandboxes (Minetest, Terasology) |
| `incremental game` | Cookie Clicker, idle games |
| `voxel game` | Minetest, Veloren lineage |
| `minecraft clone` | Usually Minecraft demo or tutorial |

## TCG / Card / Deckbuilder

| Query | Notes |
|---|---|
| `card game` | Hearthstone-like (Duelyst, Hearthstone clones) |
| `deckbuilder` | Slay the Spire-likes (rare OSS) |

## Casual / Puzzle

| Query | Notes |
|---|---|
| `puzzle game` | Tetris-likes, match-3 |
| `sokoban` | Box-pushing puzzlers |
| `snake game` | Snake clones (often demos) |

## Shooting / Action

| Query | Notes |
|---|---|
| `shooter` | FPS, third-person (often IP-restricted) |
| `shoot em up` | Bullet hell, vertical scrollers |
| `bullet hell` | Danmaku (Touhou-likes) |
| `fighting game` | MUGEN clones, IKEMEN, Brawlhalla-likes |
| `shoot them up` | Same as `shoot em up` |

## Narrative / Visual

| Query | Notes |
|---|---|
| `visual novel engine` | Ren'Py, WebGAL, Monogatari |
| `rpg maker` | Often RPG Maker MV/MZ games (not engines — usually .zip) |

## Engine-specific (use carefully)

| Query | Notes |
|---|---|
| `godot game` | Many GDScript games — narrow to `language:GDScript` |
| `phaser game` | JavaScript framework — many tutorials, narrow by stars |
| `unity game` | Most require Unity Hub — verify free/open license |
| `love2d game` | LÖVE Lua games — usually `.love` only |
| `threejs game` | Browser WebGL — verify `dependencies: { three }` only |

## Anti-pattern queries (DO NOT USE as primary)

- `open source game` alone — mostly engines + tutorials. Use as first batch item but not sole query.
- `game engine` — returns Godot/Unity/cocos, not games
- `game framework` — same as above
- `tutorial game` — student projects, low signal

**07-27 노이즈 실측** (broad 단일 단어 매칭 위험):
- `rpg game` → vuejs/core, opencode, electron 매칭 (게임 아님)
- `simulation game` → Genesis-Embodied-AI, ml-agents (라이브러리)
- `platformer game` → n8n, langchain, electron (워크플로우/에이전트)
- `open source game` → linux, tensorflow, pixijs, bevy (OS/엔진)

**해결**: 항상 `genre + "game"` 2단어 또는 `language:XXX` 필터 추가:
```bash
# ❌ broad → 엔진/라이브러리 매칭
"rpg game" "simulation game" "platformer game"

# ✅ 좁혀짐
"roguelike+game+language:Java"
"tower+defense+game"
"pixel+platformer+game"
"turn-based+strategy+game"
"visual+novel+engine"   # engine 디렉토리 매칭 OK
"shooter+game+language:Lua"
"browser+game+free"
```

## Filters to add per query

| Filter | Syntax | Why |
|---|---|---|
| Stars floor | `stars:>500` | Removes demo/tutorial spam |
| Pushed within N days | `pushed:>2026-01-01` | Removes dead repos |
| License | `license:mit` or `license:apache-2.0` | Avoids NOASSERTION noise |
| Language | `language:typescript` | Narrows framework noise |

**Default per-query filter**: `sort=stars&order=desc&per_page=5` (caller script uses `per_page=4` to keep output readable).

## 검증된 TOP 5 (07-27 real run — 재실행 불필요)

| 순위 | 저장소 | 게임 | 점수 | 비고 |
|---|---|---|---|---|
| 🥇 | Praytic/youtd2 | TD+RPG | 9.1 | Godot 4.6, greenfield i18n |
| 🥈 | pmotschmann/Evolve | incremental | 8.7 | 10,164 keys, **22.5% 영문 잔존** |
| 🥉 | AshVXmc/ReonixeDungeons | hack-and-slash RPG | 8.6 | 단일 저작자 → 독립 fork |
| 4 | triplea-game/triplea | Axis & Allies | 7.6 | Java/Gradle → 빌드 15분 |
| 5 | 00-Evan/shattered-pixel-dungeon | roguelike | 6.5 | 한국어 7 PR 이미 활발 |

**회피 검증됨**: Athena Crisis (Open Core), debris/autobattler (라이선스 NONE), Cataclysm-BN (한글 124 PR), WebGAL (中文 중심), Pokéclicker (IP), Wesnoth/Mindustry/DDA (C++ + 한글 활발).

전체 빌드 비용 + 한국어 진행도 표는 `references/2026-07-27-validated-candidates.md` 참조.

## When to expand the bank

- A new trending genre emerges (e.g. auto-chess, survival craft)
- Existing queries return too many engines/tutorials (add `language:X` filter)
- User asks for a niche (e.g. "find a Korean-language-OSS game" → add `korean` query to filter FOR not against)

## 검증된 게임 스택 (07-27 실측 — preflight 시간 절약)

| 스택 | 검색 키워드 | 검증된 양질 후보 |
|---|---|---|
| Godot 4 (GDScript) | `godot+game`, `autobattler`, `tower+defense+game`, `pixel+platformer+game` | youtd2, ReonixeDungeons, debris/autobattler |
| LÖVE (Lua) | `love2d+game`, `shooter+game+language:Lua` | SNKRX (이미 fork), BYTEPATH, void-protocol-p8 |
| Java (libGDX) | `roguelike+game+language:Java` | Shattered Pixel Dungeon |
| Plain JS | `incremental+game`, `idle+game`, `browser+game` | pmotschmann/Evolve, pokeclicker |
| Java/Gradle | `turn-based+strategy+game` | TripleA, AncientBeast |
| Python (pygame) | `pygame+game` | CharlesPikachu/Games, youre-the-os |
| C# | `game+in:CSharp` (broad → narrower 필요) | TripleA, IKEMEN |
| C++ | `roguelike+game` (드물게 OSS) | OpenMW, Veloren, NetHack (90-min 빌드 함정) |
