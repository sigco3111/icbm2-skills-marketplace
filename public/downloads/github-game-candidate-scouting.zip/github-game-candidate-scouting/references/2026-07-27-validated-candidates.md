# 2026-07-27 검증된 게임 후보 풀 (TOP 5 + 회피)

> 스카우팅 실전 검증 (12-genre batch + 5-axis matrix) 결과. 다음 세션에서 가중치/장르 다시 짤 필요 없이 바로 검증 완료된 후보부터 시작 가능.

## TOP 5 (검증 완료)

| # | 저장소 | ⭐ | 언어 | 라이선스 | 점수 | 비고 |
|---|---|---|---|---|---|---|
| 🥇 | **Praytic/youtd2** | 217 | GDScript | MIT | 9.1 | Godot 4.6, TD+RPG, 101MB, greenfield i18n |
| 🥈 | **pmotschmann/Evolve** | 1185 | JS | MPL-2.0 | 8.7 | incremental, 10,164 keys, **22.5% 영문 잔존** (polish 가치 큼) |
| 🥉 | **AshVXmc/ReonixeDungeons** | 26 | GDScript | MIT | 8.6 | Godot 4 hack-and-slash RPG, 단일 저작자 → PR 머지 어려움 |
| 4 | **triplea-game/triplea** | 1543 | Java/Gradle | GPL-3.0 | 7.6 | Axis & Allies 엔진, properties i18n, 한국어 0 |
| 5 | **00-Evan/shattered-pixel-dungeon** | 6359 | Java | GPL-3.0 | 6.5 | libGDX, 220개 lang 파일, 한국어 번역 이미 활발 |

## 회피 후보 (패턴 + 이유)

| 저장소 | 회피 이유 | 함정 매핑 |
|---|---|---|
| **nkzw-tech/athena-crisis** | Open Core 비공개 (art/Variants.nkzw.tsx + codegen) | 함정 3 (Open Core 7시그널) |
| **debris/autobattler** | 라이선스 NONE → NOASSERTION | 함정 2 (라이선스 본문 5분 안 보면 발견 못함) |
| **cataclysmbn/Cataclysm-BN** | 한국어 124 PR + `lang/` + `readme.ko.md` | 이미 활발 → 차별화 ↓ |
| **WebGAL/...** | 中文 중심, 한국어 i18n 0 | greenfield지만 컨텐츠 의존성 = 번역 비용 큼 |
| **pokeclicker/pokeclicker** | Pokemon IP 충돌 | 함정 7 (상용 배포 제한) |
| **Wesnoth/Mindustry/Cataclysm-DDA** | 한국어 번역 활발 + C++ 빌드 함정 | 함정 6 (90분 C++ trap) |

## 검증된 한국어 진행도 (TOP 5 한정)

| 후보 | ko 검색 | lang 디렉토리 | i18n 폴더 | 첫 작업 추정량 |
|---|---|---|---|---|
| youtd2 | 0 | none | none | 150~200 strings (greenfield) |
| Evolve | 17 | `strings/strings.ko-KR.json` | 있음 | 2,291 polish (함정 14 정확 매칭) |
| ReonixeDungeons | 0 | none | none | greenfield (단일 저작자) |
| TripleA | 0 | `i18n/games/strategy/...` | properties | 3,000~5,000 keys |
| Shattered PD | 7 | `actors_ko.properties` 등 | .properties | polish만 (차별화 ↓) |

## 게임 빌드 비용 (실제 검증)

| 후보 | 빌드 도구 | 1회 빌드 시간 (macOS) | 배포 산출물 |
|---|---|---|---|
| youtd2 | Godot 4.6 | ~3분 | .dmg, .apk, .exe, .love 포맷 |
| Evolve | none (정적 JS) | 0분 | 정적 호스팅 |
| ReonixeDungeons | Godot 4 | ~3분 | .dmg, .apk, .exe |
| TripleA | Gradle 8 + Kotlin DSL | ~15분 (첫 빌드) | .jar, .exe, .dmg |
| Shattered PD | Gradle + libGDX | ~10분 | .jar, .apk, .exe |

## SKILL.md Phase 1 함정 보강: 쿼리 노이즈

기본 12-genre query bank (`open source game`) 가 bash split되어 "open/source/game" → 3개 별도 쿼리. 결과:
- vuejs/core, opencode, tensorflow, electron이 계속 매칭됨
- 엔진 (godot, bevy, pixijs) 도 매칭되지만 게임 아님

**수정 패턴**: game-content 시그널 포함 (장르 + "game" 또는 "language:XXX"):
```bash
# ❌ 잘못된 (broad, 엔진 튜토리얼 매칭)
"open source game" "rpg game" "platformer"

# ✅ 좀 더 정확
"roguelike+game+language:Java"
"tower+defense+game"
"auto+battler" "autobattler"
"pixel+platformer+game"
"incremental+game"
"turn-based+strategy+game"
"love2d+game" "godot+game"
```

```bash
# Verification (curl + python3 in one shot)
TOKEN=$(cat ~/.hermes/secrets/github_token.txt)
curl -s -H "Authorization: token $TOKEN" \
    "https://api.github.com/search/repositories?q=tower+defense+game&sort=stars&order=desc&per_page=8" \
    | python3 -c "
import json,sys
for r in json.loads(sys.stdin.read()).get('items',[]):
    print(f\"  {r['stargazers_count']:>7} | {(r.get('language') or 'None'):<12} | {r['full_name']:<45} | {(r.get('description') or '')[:80]}\")
"
```

## Master vs main branch 함정

`pmotschmann/Evolve` 의 `strings/strings.ko-KR.json` 은 **master 브랜치에만** 있음 (main 404). 라이브러리/서비스 시대는 master가 흔하지만 GitHub Pages/Netlify 새 프로젝트는 main. preflight 시 **양쪽 다 시도**:

```bash
for branch in main master; do
    url="https://raw.githubusercontent.com/OWNER/REPO/$branch/path/to/file"
    status=$(curl -s -o /dev/null -w "%{http_code}" "$url")
    echo "$branch: $status"
done
```
