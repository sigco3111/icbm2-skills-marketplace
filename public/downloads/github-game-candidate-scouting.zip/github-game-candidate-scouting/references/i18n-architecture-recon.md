# i18n Architecture Reconnaissance — Post-Selection Checklist

`end_of_eden` (BigJk) 작업 중 발견한 패턴들. **final pick 확정 후, fork 직전에** 5단계 정찰을 돌려야 Phase 5의 "첫 개선 작업" 범위가 실제와 맞아떨어짐.

## 5단계 정찰 체크리스트

### 1. Locale 코드 형식 (30초)

**질문**: 한국어 코드는 `ko`? `ko-KR`? 둘 다? 그 외?

```bash
# Go 예시
grep -rE 'SetCurrent|locale|"en"' system/ internal/ --include="*.go"

# TypeScript / JS
grep -rE 'i18n|locale|language' src/ --include="*.ts" --include="*.tsx" | head -10

# Lua (Godot / LÖVE)
grep -rE 'locale|LANGUAGE' assets/ --include="*.lua"
```

**판정**:
- 2글자 강제 → `ko`만 가능
- BCP-47 → `ko-KR` 권장 (지역별 변형 가능)
- 둘 다 → 둘 중 메인테이너 선호 패턴 따라가기

**end_of_eden 사례**: `localization.go:94`에 `if len(local) != 2 { return error }` 명시 → **`ko-KR`는 로드 자체가 실패**. `ko`만 가능.

### 2. 자동 스캔 vs 수동 등록 (30초)

**질문**: 폴더 만들면 끝? 아니면 코드에 명시적으로 등록해야 함?

```bash
# 자동 스캔 흔적
grep -rE 'AddFolder|Walk\(|filepath\.Walk|fs\.Walk' system/ internal/ --include="*.go" --include="*.ts"

# 수동 등록 흔적
grep -rE 'RegisterTranslation|registerLocale|i18n\.addResourceBundle' src/ --include="*.ts" --include="*.go"
```

**판정**:
- 자동 스캔 → `assets/locals/ko/` (또는 해당 경로)에 디렉터리 + yml/json 추가만으로 끝
- 수동 등록 → main config 파일이나 registry 코드 수정 필요 (작업량 2배)

**end_of_eden 사례**: `AddFolder("./assets/locals")` 자동 스캔 → **폴더 만들기만 하면 끝**. 단점은 어떤 locale이 사용 가능한지 코드 grep으로만 확인 가능.

### 3. Fallback 체인 (1분)

**질문**: 키가 한국어 YAML에 없으면 어떻게 동작? 빈 문자열? 영어 fallback? 키 그대로 노출?

```bash
# Go / TS
grep -rE 'fallback|default.*locale|FALLBACK_LOCALE' system/ internal/ src/ --include="*.go" --include="*.ts"

# Lua inline default 흔적 (가장 흔한 패턴)
grep -rE 'l\(".*",.*"\)' assets/scripts/ --include="*.lua"
grep -rE '_\(".*",.*"\)' assets/ --include="*.lua"
```

**판정**:
- inline default (`l("key", "default english")`) → **부분 번역 안전**. 빠진 키는 자동으로 영문 표시. PR 범위 점진 확장 가능
- 영어 fallback만 → 누락 시 키 그대로 노출 (사용자 경험 ↓)
- 빈 문자열 → 절대 안 됨 (메인테이너에게 사전 수정 요청)

**end_of_eden 사례**: `basic_hand_weapons.lua:56`에 `name = l("cards." .. weapon.id .. ".name", weapon.name)` → **인라인 폴백**. 한국어 YAML에 키 없으면 자동으로 `weapon.name` (영문) 사용. 부분 번역 PR 안전.

### 4. 기존 번역 분량 실측 (2분)

**질문**: 다른 locale 파일들이 실제로 어느 정도 채워져 있는가? "greenfield"가 진짜 greenfield인가?

```bash
# 분량
for f in assets/locals/*/*.yml assets/locales/**/*.json i18n/**/*.json; do
  if [ -f "$f" ]; then
    wc -l "$f"
  fi
done

# 키 카운트 (YAML)
for f in assets/locals/*/*.yml; do
  python3 -c "
import yaml
with open('$f') as fh:
    d = yaml.safe_load(fh)
def count(o):
    if isinstance(o, dict):
        return sum(count(v) for v in o.values()) + len(o)
    return 0
print(f'$f: {count(d)} keys')"
done
```

**판정 매트릭스**:

| 다른 locale 분량 | 신규 locale 가치 | 권장 PR 범위 |
|---|---|---|
| 0줄 / 빈 파일 | 🟢 high | "신규 locale + 30~50 키" (작지만 임팩트 큼) |
| 1~10줄 (end_of_eden `de/cards.yml`) | 🟢🟢 very high | "신규 locale + 베이스 + 카드 1~3개" |
| 100~500줄 | 🟡 medium | "신규 locale + 베이스 + 카드 5~10개" |
| 1000줄+ | 🟠 low | 폴리시 (다른 후보 검색) |

**end_of_eden 사례**: `de/cards.yml`은 단 **5줄** (1개 카드만). 즉 "기존 locale 인프라 0.001% 활용 중" → 신규 locale 추가가 **very high value**.

### 5. 빌드 툴체인 확인 (1분)

**질문**: Go / Rust / Node / Java / C++ 중 무엇? 로컬에 설치되어 있는가?

```bash
# 매니페스트
cat go.mod package.json Cargo.toml pyproject.toml 2>/dev/null | head -20

# 로컬 설치 확인
which go node cargo python3 java 2>/dev/null
```

**판정**:
- 모두 설치 + 프로젝트 빌드 성공 → PR 본문에 "✅ tested locally on macOS"
- 메인언어만 설치 (예: Node 있음, Go 없음) → PR 본문에 "tested: 빌드 체인 미설치로 시각 검증 보류. YAML 문법 검증만 수행"
- 빌드 체인 복잡 (CMake + 의존성 5+) → 빌드 보류하고 YAML만 검증

**end_of_eden 사례**: Go 미설치 → 빌드 검증 불가 → PR 본문에 명시 필요.

## 통합 출력 템플릿

5단계 완료 후 사용자 보고 형식:

```markdown
## i18n 정찰 결과: OWNER/REPO

| 항목 | 결과 | 영향 |
|---|---|---|
| 1. Locale 코드 | 2글자 강제 | `ko` OK, `ko-KR` NG |
| 2. 자동 스캔 | AddFolder 자동 | 폴더만 만들면 끝 |
| 3. Fallback | inline default | 부분 번역 안전 |
| 4. 기존 분량 | de/cards.yml 5줄 | very high value |
| 5. 빌드 | Go 미설치 | YAML 검증만 가능 |

→ 첫 PR 범위: "assets/locals/ko/{base,cards}.yml 추가 (UI 45키 + 카드 6개)"
→ PR 본문 포함: "Build chain (Go 1.23) unavailable locally — YAML syntax verified"
```

## 케이스 스터디: BigJk/end_of_eden (2026-07-28)

전체 정찰 결과는 위 5단계 표 참조.

**교훈**:
1. **i18n 인프라 ≠ i18n 활용도**: 폴더 구조는 있으나 실제 활용 0.001% → 신규 locale 가치 큼
2. **빌드 체인 부재는 PR 사망 사유 아님**: YAML 문법 검증 + "build chain unavailable" 명시로 메인테이너가 자체 검증 가능. 단, "tested locally on macOS"는 못 적음
3. **2글자 locale 강제**: 메인테이너 선호 패턴이 있을 수 있음. CONTRIBUTING.md나 기존 locale 코드 (`de`, `en`) 보면 패턴 보임
4. **Lua inline fallback**: 가장 안전한 패턴. 빠진 키는 자동 영문 표시 → 첫 PR을 좁게 시작 가능

**다른 후보 풀기 전 반드시 정찰 5단계 완료**. Phase 5 추정의 50% 이상이 여기서 조정됨.