# 2026-07-28 검증된 게임/어드온 후보 풀 (Round 1-2)

> 07-28 두 라운드 검증 결과. Round 1 = broad 12-genre batch, Round 2 = exclude-list 검증 + i18n 구조 실측.

## Round 1 — Broad 12-genre batch 결과

24+ 후보 발굴, exclude + 라이선스 + i18n 구조로 5개로 압축.

### 검증된 TOP 후보 (Round 1)

| # | 저장소 | ⭐ | 언어 | 라이선스 | 점수 | 비고 |
|---|---|---|---|---|---|---|
| 🥇 | **BigJk/end_of_eden** | 202 | Go | MIT | **8.5** | Spire-like roguelite (콘솔), `assets/locals/de/`만 존재 → **완전 greenfield YAML i18n** |
| 🥈 | **Kirilllive/tuesday-js** | 672 | JS (HTML) | Apache-2.0 | **8.5** | Web VN 엔진/에디터, `translate/{en,es,ja,ru,zh}_tuesday_visual.html` 5개만 → 한국어 1파일 PR |
| 🥉 | **db0/hypnagonia** | 107 | GDScript | AGPL-3.0 | **6.8** | Spire-like 카드 게임, i18n 디렉토리 없음 + .gd 하드코딩 |
| 4 | **Null-Signal-Games/netrunnerdb** | 166 | PHP | MIT | **6.5** | Netrunner 카드 DB, ko 이슈 1건 (closed, 다른 로케일 버그) |
| 5 | **acoto87/war1** | 149 | C/SDL3 | Zlib | **6.6** | Warcraft 리메이크, **Blizzard IP 충돌 우려** + C 빌드 어려움 |

### Round 1에서 검토 후 제외

| 후보 | 제외 이유 | 검출 단계 |
|---|---|---|
| **Monogatari/Monogatari** | `src/translations/`에 `한국어.ts` (2,798B) 이미 존재 | Phase 3 i18n probe |
| **eduard-permyakov/permafrost-engine** | RTS **engine** (not game) | Phase 2 triage |
| **VoidmatrixHeathcliff/VoidNovelEngine** | 1,652⭐지만 root에 README+LICENSE+doc만, 349 파일 = doc/만 보임 → 빈 셸 | Phase 2 |
| **a327ex/SNKRX** | `/Users/mac/Library/Application Support/SNKRX` 작업 흔적 | Phase 0 |
| **a327ex/BYTEPATH** | pushed 2020-10 (3년 전) | Phase 2 |
| **Ren'Py/renpy** | 엔진 (visual novel engine) | Phase 2 |

## 한국어 진행도 실측 (TOP 5 한정)

| 후보 | ko 이슈 | lang 디렉토리 | i18n 구조 | 첫 작업 추정 |
|---|---|---|---|---|
| **end_of_eden** | 0 | `assets/locals/de/` (base.yml + cards.yml) | YAML 2계층 | ko/base.yml + ko/cards.yml 추가 |
| **tuesday-js** | 0 | `translate/` (en/es/ja/ru/zh HTML) | HTML 1파일 | `ko_tuesday_visual.html` 추가 |
| **hypnagonia** | 0 | **(없음)** | GDScript 하드코딩 | dreamscape/내 .gd 직접 번역 (大 작업) |
| **netrunnerdb** | 1 closed | **(없음)** | i18n 구조 미확인 | PHP LAMP 환경 + i18n 구조 파악 |
| **war1** | 0 | **(미확인)** | C/SDL3 + libc 직접 | SDL 문자열 위치 추적 |

## 빌드 비용

| 후보 | 빌드 도구 | 추정 시간 (macOS) | 배포 산출물 |
|---|---|---|---|
| end_of_eden | `go build` (go.mod) | ~1분 | 단일 바이너리 (콘솔) |
| tuesday-js | **빌드 불요** (HTML 정적) | 0 | 브라우저/Vercel |
| hypnagonia | Godot 4 | ~3분 | .dmg, .apk, .exe |
| netrunnerdb | PHP + LAMP | ~5분 | 정적 호스팅 or LAMP |
| war1 | SDL3 + nob.c (build tool) | ~10분+ (SDL3 의존성) | .app (제한적) |

## 차별화 노트

- **end_of_eden**: YAML 2계층 = `base.yml` (UI) + `cards.yml` (컨텐츠). 한국 시나리오(이순신/강감찬 카드팩) 추가 시 차별화 큼
- **tuesday-js**: README에 5개 언어 credit 명시 (`[Japanes translation by Onigi]` 등). 한국어 credit 추가 = 즉각 가시화 + low-PR이지만 upstream 머지 가치 명확
- **hypnagonia**: AGPL-3.0 = 모든 derivative work도 AGPL → **상업 fork 불가**, 비상업 fork 한정
- **war1**: Warcraft fan-remake 정책 미공개 = **Blizzard의 C&D 위험**. fan-game 정책이 그동안 엄격했음 → 추천 가치 의문

## KO 검색 vs 실제 한국어 파일 — Mismatch 함정

ko 이슈/PR 검색이 0건이어도, **translations/ 디렉토리 안에 `한국어.ts`, `ko.json` 같은 filename이 이미 존재할 수 있음**. 실 사례:

| 후보 | ko 이슈 카운트 | 디렉토리 직접 ls 결과 |
|---|---|---|
| Monogatari/Monogatari | 0 | `src/translations/한국어.ts` (2,798B) **존재** |
| 위 5개 TOP 후보 | 모두 0 | **모두 부재** (greenfield 확인) |

→ **검증 단계에 `translations/` 디렉토리 직접 ls 필수** (Pitfalls #28 참조).

## Round 2 — 추가 query + exclude 검증 결과

12 query 재실행 → 모두 0 결과로 귀결 (secondary rate limit 403에 걸림). 403 자체가 진짜 함정 — `/rate_limit` API는 4990/5000 정상 반환하지만 search API만 차단됨.

→ 이후 `gh api repos/OWNER/REPO --jq` 단건 + sleep 1.2초로 안전하게 후보 검증.

## 적용 가능한 skill 패턴

- YAML 2계층 (`base.yml` + `cards.yml`) — `cpp-game-koreanization`에 신규 패턴 추가 가능
- HTML 1파일 추가 (tuesday-js) — Godot addon의 gettext 패턴과 동일 level "단일 파일 PR"
- Hypnagonia의 GDScript 하드코딩 — Godot 외부 string 추출 자동화 후보 (미구현, 별도 class)
