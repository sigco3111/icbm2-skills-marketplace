---
name: skill-security-audit
description: "스킬 파일 보안 감사 — 공개 전 민감 정보(DB ID, 절대경로, 시크릿 경로, 계정명 등) 검출 및 환경변수 대체"
tags: [security, audit, skills, marketplace]
---

# 스킬 보안 감사

공개용 스킬 파일에서 민감 정보를 검출하고 수정하는 워크플로우.

## 검출 대상

| 카테고리 | 패턴 | 조치 |
|----------|-------|------|
| Notion DB ID | 32자 hex (UUID 형식) | `$NOTION_XXX_DB_ID` 환경변수로 대체 |
| Agent ID | API URL에 포함된 ID | `$BOTMADANG_AGENT_ID` 등으로 대체 |
| 절대경로 | `/Users/...` | 상대경로로 변경 |
| 시크릿 경로 | `~/.hermes/secrets/` | `$NOTION_TOKEN_PATH` 등 환경변수로 대체 |
| 내부 구조 | `~/.hermes/` 하위 경로 | `scripts/`, `memory/` 등 상대경로로 변경 |
| 계정명 | GitHub 계정명 등 | 제거 또는 일반화 |
| API 키 | 실제 키/토큰 | 마스킹 확인 |
| .env 참조 | `~/.hermes/.env` | `$ENV_FILE`로 대체 |

## 감사 절차

1. **grep으로 광범위 검출**
   ```bash
   cd ~/.hermes/skills/
   grep -rn "secrets/" --include="*.md" .
   grep -rn "/Users/" --include="*.md" .
   grep -rn "~/.hermes/" --include="*.md" .
   grep -rPn "[0-9a-f]{32}" --include="*.md" .
   ```

2. **각 파일 수정** — skill_manage patch로 환경변수 대체

3. **scripts/*.py 점검** — `os.getenv()`, `os.path.expanduser()` 동적 경로 사용 확인 (이미 안전한 경우가 많음)

4. **최종 검증** — 동일 grep으로 0건 확인

## 주의사항

- DB ID는 `grep -rPn "[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"`로 UUID 패턴 검출 가능
- 수정 시 기능 설명은 유지하되, 예제의 실제 값만 환경변수로 치환
- 환경변수명은 용도를 명확히: `$NOTION_TOKEN_PATH`, `$SHIPORSLOP_AUTH_PATH`, `$CONFIG_FILE` 등
