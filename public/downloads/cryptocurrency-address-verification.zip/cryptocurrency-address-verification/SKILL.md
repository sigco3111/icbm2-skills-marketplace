---
name: cryptocurrency-address-verification
description: "암호화폐 지갑 주소를 받기 전/후에 검증하는 클래스. (1) 거래소 검색 결과에서 가짜 토큰(memecoin scam)과 진짜 자산을 구분하는 법, (2) 코인별 진짜 주소 형식 검증 (Monero 95자 4/8 시작, Bitcoin 1/3/bc1 시작, Ethereum 0x+40hex, Solana 32~44자 Base58), (3) 거래소 입금 흐름 vs 검색의 차이, (4) KYC 제한/지역 차단 우회 가이드 (KuCoin/Bybit/MEXC fallback), (5) '너무 짧은 주소' / 'Base58 아닌 글자 포함' / '네트워크 불일치' 같은 스캠 패턴 식별. \"XMR 주소 줘\", \"입금 주소 받았는데 맞아?\", \"이게 진짜 XMR이야?\", \"거래소 지갑 어떻게 받아?\" 같은 요청에 발동."
version: 0.1.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [cryptocurrency, monero, xmr, kucoin, binance, address-verification, scam-detection, deposit]
    related_skills: [invest-memo, stock-market-trader]
---

# Cryptocurrency Address Verification

암호화폐 입금 주소를 사용자에게 받기 전/후에 검증하고, 가짜 토큰 scam을 식별하며, 거래소 KYC 벽을 우회하는 클래스.

## 트리거 시그널

- "XMR / BTC / ETH / SOL 주소 줘" (사용자 본인이 만든 주소)
- "이게 진짜야?" / "이 주소 맞는지 확인해줘"
- "Binance/KuCoin에서 지갑 어떻게 받아?"
- "주소 받았는데 진짜 XMR이야?" / "주소가 44자인데 맞나?"

## 절대 트리거 X

- 거래 시그널 (→ `trading-strategy` 스킬)
- 단순 가격 조회 (→ `stock-market-pro` 스킬)
- 지갑 만들기 (이 스킬은 검증만, 생성은 getmonero.org 등 가이드)

---

## 코인별 진짜 주소 형식 (Reference)

| 코인 | 시작 | 길이 | 알파벳 | 네트워크 | 비고 |
|---|---|---|---|---|---|
| **Bitcoin (BTC)** | `1` / `3` / `bc1` | 26~62자 | Base58/Bech32 | Bitcoin mainnet | `bc1...`는 SegWit |
| **Monero (XMR)** | `4` / `8` | **정확히 95자** | Base58 | Monero mainnet | `8...`은 subaddress |
| **Ethereum (ETH)** | `0x` | 42자 (`0x` + 40 hex) | hex (0-9, a-f, A-F) | ERC-20 | 대소문자 무관 |
| **Solana (SOL)** | 무관 (숫자/대문자) | 32~44자 | Base58 | Solana mainnet | **XMR 아님** |
| **Litecoin (LTC)** | `L` / `M` / `ltc1` | 26~43자 | Base58/Bech32 | Litecoin | |

> **Mnemonic 문구 ≠ 주소**: 25단어 / 12단어 시드 문구 절대 공유 금지. 공유하면 자금 즉시 탈취당함.

---

## 검증 단계 (반드시 순서대로)

### Step 1: 길이 + 시작 글자 체크

사용자가 보낸 주소를 보면 무의식적으로 다음 3가지를 본다:

```
1. 길이 (Monero면 정확히 95자, ETH면 42자)
2. 시작 (XMR: 4/8, ETH: 0x, BTC: 1/3/bc1)
3. 알파벳 (XMR/ETH/SOL: hex 또는 Base58, 공백/특수문자 없어야)
```

**예외**: 일부 거래소는 subaddress 또는 memo/destination tag 추가 요구 — 사용자가 "memo"도 같이 보냈는지 확인.

### Step 2: 거래소 검색 vs 입금 흐름 구분

이게 이번 세션의 핵심 교훈:

| | 검색 화면 (위험) | 입금 흐름 (안전) |
|---|---|---|
| **진입점** | "Markets" → "Search" 또는 "Discover" 검색창 | "Wallet" → "Deposit" 또는 "Receive" |
| **결과** | 이름이 비슷한 가짜 토큰 다수 (특히 `X (Solana)`, `Wrapped X`, `Wormhole X`) | 진짜 코인 한 줄만 표시 |
| **가격** | $0.0001 ~ $0.5 (memecoin 가격대) | 진짜 시세 (XMR ~$300, BTC ~$60K) |
| **유동성** | $0 ~ $100K (ILL) | 시가총액 수십억 |
| **네트워크** | "Solana", "Ethereum", "BSC" | 코인 자체 (Monero, Bitcoin, ...) |

**흔한 가짜 패턴**:
- `XMR (Solana)` → 진짜 XMR 아님, Solana 위 memecoin
- `WXMR (Ethereum)` → Wrapped XMR, 진짜 XMR 아님
- `MONERO` (네트워크 Solana) → 이름 도용 토큰
- `Wrapped X` → 원래 코인의 ERC-20/SPL wrapping

### Step 3: 사용자 화면 분석 (필수)

사용자가 보내는 이미지는 **반드시** `vision_analyze`로 본다. `mcp_minimax_understand_image`로도 가능.

분석해서 확인:
- 어떤 화면인지 (검색? 입금? 차트?)
- 어떤 코인/네트워크가 표시되는지
- 검색이면 가짜 토큰 vs 진짜 토큰 비율
- 입금이면 진짜 자산만 표시되는지

### Step 4: 의심 신호 체크리스트

다음 중 하나라도 해당하면 **거부하고 우회 옵션 제시**:

- [ ] 길이 표준과 다름 (Monero 44자, ETH 40자 등)
- [ ] 시작 글자가 표준과 다름 (XMR이 `6...` 시작 등)
- [ ] 네트워크가 "Solana" / "Ethereum" / "BSC"인데 사용자가 "진짜 XMR이다" 라고 주장
- [ ] 시가총액 / 유동성 비정상적으로 작음
- [ ] 이름에 "(Solana)" / "(Ethereum)" / "Wrapped" 같은 한정어 붙어있음
- [ ] 계약 주소가 0x... 또는 Base58이지만 ERC-20/BEP-20 컨트랙트

### Step 5: 우회 옵션 제시

검증이 실패하면:

1. **다른 거래소 시도** (한국 사용자한테 XMR 차단일 확률 높음)
2. **공식 지갑 직접 생성** (거래소 의존 X)

---

## 거래소별 한국 사용자 XMR 지원 상태 (2026-06 기준)

| 거래소 | 한국 지원 | XMR 입금 | 추천도 |
|---|---|---|---|
| **Binance** | ✅ | ⚠️ 차단 사례 다수 | KYC OK이지만 입금 검색 안 됨 |
| **KuCoin** | ✅ | ✅ 정상 | ⭐️ 추천 |
| **Bybit** | ✅ | ✅ 정상 | OK |
| **MEXC** | ✅ | ✅ 정상, No KYC 옵션 | OK |
| **OKX** | ✅ | ⚠️ 국가별 제한 | 위치 확인 필요 |
| **Binance.US** | ❌ (미국 전용) | ✅ | 한국 IP 차단 |
| **Kraken** | ⚠️ KYC 까다로움 | ✅ | 어려운 편 |
| **공식 Monero GUI** | ✅ | ✅ | ⭐️ 가장 안전 |

> **거래소명 노출 트레이드오프 (2026-06-24 OSS 부트스트랩 결정)**: 사용자가 "KuCoin 가입법 + SupportXMR 사용법 + XMR 채굴법"을 README에 추가 요청하는 경우, PII 보안 원칙("코드/문서에 거래소명/지갑명 노출 X")과 사용자 가이드 충족("실제 가입 흐름 알려줘")이 충돌. **해결 패턴 (xmrig-dashboard 06-24 검증)**:
>
> 1. **코드/환경변수**: 거래소명·지갑명·사용자명·절대경로 **완전 제거** (0건 grep 확인 후 푸시)
> 2. **README/docs**: **거래소 중립 + 모든 거래소 동일 평면 노출** — Binance/Bybit/Kraken/KuCoin/MEXC/OKX를 **알파벳 순**으로 나열, 어느 거래소도 추천 톤 아님
> 3. **KuCoin이 사용자 요청에 명시되면**: 별도 "예시: KuCoin 가입" 섹션이 아니라 비교표의 한 행으로 자연스럽게 포함. **"추천" 워딩 금지** — 사용자가 자기 책임으로 선택하게 둠
> 4. **거래소명 변경 가능성 명시**: "이 목록은 작성 시점 기준. 거래소가 XMR 지원을 중단할 수 있으니 deposit 페이지에서 확인" — 미래 stale 방지
> 5. **검증 명령**: 푸시 전 `grep -riE "kucoin|binance|bybit|kraken" .`로 의도된 문서 외 노출 0건 확인
>
> **재사용**: 모든 OSS 부트스트랩 + 사용자 가이드 충돌 시. "PII 제거 + 모든 옵션 평면 노출 + 추천 금지"가 안전 패턴. 사용자 "추천" 시그널은 **트레이드오프 해결 후 만족**하지만, **공개 OSS는 추천 워딩이 책임 문제를 일으킬 수 있음** (거래소가 해킹당하면 추천자 책임 추궁).

---

## KuCoin 입금 흐름 (가장 빠른 우회, 5분)

```
1. https://www.kucoin.com/ko 접속
2. 이메일/휴대폰 가입 → KYC (신분증 + 셀카)
3. 상단 "Assets" → "Main Account" (또는 "Funding")
4. "Deposit" 클릭
5. 코인 검색: "XMR" 또는 "Monero"
6. "Monero (XMR)" 한 줄만 표시됨 → 클릭
7. 네트워크: "XMR" 또는 "Monero" 선택 (다른 거 선택하면 자산 손실)
8. 주소 복사 (4... 또는 8... 시작, 95자)
```

---

## 공식 Monero 지갑 (가장 안전, 10분)

```
1. https://www.getmonero.org/downloads/
2. Mac용 "Monero GUI" 다운로드 → 설치
3. "Create a new wallet"
4. 25단어 시드 문구 → **오프라인 종이에 적기** ⚠️
5. 주소 생성 → "4..." 시작, 95자
6. 4...가 메인 주소, 8...가 subaddress (둘 다 입금 받기 OK)
```

> **경고**: 25단어 시드를 디지털 저장(클립보드/사진/문자) 절대 X. 종이 2장 이상 백업 권장. 분실 시 복구 불가.

---

## 에이전트 주소 생성 절대 금지

> ❌ "제가 랜덤 지갑 만들어드릴게요" 같은 말 절대 금지.

**이유**:
- 생성한 지갑의 **실제 소유자가 누구인지 알 수 없음** (에이전트가 시드를 기억 못 함)
- 자금을 잃어버리면 복구 방법 없음
- 법적/보안 책임 소재 모호

**대신**:
- 사용자가 직접 거래소 가입 or 공식 지갑 다운받기
- 그 결과를 받아서 검증만 해주기
- 의심 신호 발견 시 명확하게 거부

---

## 자주 하는 실수 5가지

1. **검색 결과 화면을 "입금 성공"으로 오해** — 검색에 뜬 토큰 ≠ 실제 입금 가능 자산.
2. **이름만 같다고 "진짜" 라고 확인** — XMR / WXMR / MONERO (Solana) 셋 다 "이름은 비슷한데 진짜 XMR은 XMR 하나뿐".
3. **길이/시작 글자 검증 안 함** — Monero 44자 = 100% 가짜. BTC 25자 = 가짜. ETH 38자 = 가짜.
4. **거래소 KYC 벽을 "XMR 자체 문제" 로 오인** — KuCoin/Bybit/MEXC는 거의 다 됨. Binance만 차단.
5. **에이전트가 랜덤 주소 생성** — 절대 금지. 사용자가 직접 받아야 함.

## 변경 이력

| 날짜 | 버전 | 내용 |
|---|---|---|
| 2026-06-24 | v0.1.0 | 초기 작성. 코인별 주소 형식 reference + 검증 5단계 + 거래소 XMR 지원 표 + KuCoin/공식 지갑 우회 흐름 + 5대 실수. xmrig-dashboard 부트스트랩 중 KuCoin 가이드 요청 → 거래소 중립 + 추천 금지 + 평면 노출 트레이드오프 결정 추가. |

---

## 실전 체크리스트 (사용자에게 받은 주소 검증할 때)

```text
[ ] 길이: 95자? (XMR) / 42자? (ETH) / 26~62자? (BTC)
[ ] 시작: 4 또는 8? (XMR) / 0x? (ETH) / 1/3/bc1? (BTC)
[ ] 알파벳: Base58? (XMR/BTC/SOL) / hex 0-9a-f? (ETH)
[ ] 출처: 거래소 입금 흐름에서 직접 복사? (검색 X)
[ ] 네트워크: XMR 자체 (Solana/Ethereum/BSC 아니어야)
[ ] 의심 신호: 시가총액, 유동성, 가격대가 정상 코인 범위?
```

전부 ✅ 이면 정식 config에 사용. 하나라도 ❌ 이면 우회 옵션 제시.
