# SVG Connector Lines Between Columns — Visual Chain Pattern

When a component has two columns / two lists / two structures where items in the left
column *cause* or *feed* items in the right column, drawing explicit lines between them
makes the chain readable at a glance. This is the pattern Google Search's bracket card
added in v3 of `bracket-view`, and it generalizes to:

- Tournament brackets (R32 → R16 → R8 → ...)
- Decision trees / org charts / family trees
- Network topology diagrams
- Directed acyclic graphs of any depth where the user needs to see "this one flows
  into that one"

This reference captures the CSS + math tricks that make those lines *stay aligned*
with the cards even when the page is scrolled or the data changes.

## The core constraint — CSS units and connector math must LOCK together

The moment you decide to draw connector lines between two columns, you make CSS layout
deterministic a requirement, not an option. The connector paths are generated at
render time as **pixel coordinates** in an SVG, but the cards they connect are
**flex/grid children** with computed sizes.

If the CSS uses `height: auto` on the cards, the connector lines will draw at the
*intended* coordinates but the cards will sit somewhere else — silently misaligned,
no error message.

**Lock the dimensions.** Pick concrete numbers and never vary them:

```css
.bv-card { height: 84px; }       /* lock card vertical metric */
.bv-col  { gap: 10px; }          /* lock card-to-card gap      */
```

Then mirror those constants into the JS that generates the SVG:

```js
const CARD_H = 84;
const GAP = 10;
const UNIT = CARD_H + GAP;       // 94
```

**Document the lock explicitly in the README so a future maintainer doesn't
"improve" one and silently break the other.**

## The grid trick — leave a 12px trench between the two columns

The SVG with connector lines needs to sit **between** the two columns, in the gap
between them. Two ways to do this:

| Approach | Pros | Cons |
|---|---|---|
| Absolute positioning (calc left = 50% of container) | Simple CSS | Fragile — breaks if columns resize asymmetrically |
| **Grid `1fr 12px 1fr` with `template-areas: 'from sv to'`** | Robust, columns always honor the trench | Adds a grid layer |

The grid approach is more robust because the trench width is *defined by the grid*,
not by fragile percentage math. The SVG becomes a first-class grid item:

```css
.bv-columns {
  display: grid;
  grid-template-columns: 1fr 12px 1fr;
  grid-template-areas: 'from sv to';
  align-items: start;
}
.bv-col-from { grid-area: from; }
.bv-col-to   { grid-area: to;   }
.bv-connectors {
  grid-area: sv;
  width: 12px;
  height: auto;
  pointer-events: none;
  overflow: visible;
}
```

Then in your markup:

```html
<div class="bv-columns">
  <div class="bv-col-from">…left column cards…</div>
  <div class="bv-col-to">…right column cards…</div>
  <svg class="bv-connectors" width="12" height="…" viewBox="0 0 12 …">…paths…</svg>
</div>
```

The SVG fits in the 12px trench exactly. Each path enters at x=0 (left edge of
trench = right edge of left column) and exits at x=12 (right edge of trench = left
edge of right column). No math against container width needed.

## The connector path — one M-curve per source item

For each card `i` in the from-column, draw a rectangular M-curve to its target card
`j = Math.floor(i / 2)` in the to-column:

```
   card 0 ───────╮
                  │
   card 1 ───────┤
                  ├───── target card j (to-column)
   card 2 ───────╯
```

The SVG path uses two horizontal segments (at the from card's y and at the target's
y) and one vertical segment connecting them:

```js
const d = `M 0 ${y1} L ${midX} ${y1} L ${midX} ${y2} L ${W} ${y2}`;
//         ↑      ↑         ↑       ↑         ↑      ↑         ↑      ↑
//         enter  from-y    midX    from-y    midX   target-y  exit   target-y
//         (x=0)           (x=W/2)         (x=W/2)         (x=W)
```

`y1` and `y2` are pixel offsets measured from the **top of the SVG** (which is
also the top of the trench = top of the columns, since both share `align-items:
start`).

```js
const fromY = (i) => Math.round(i * UNIT + UNIT / 2);                 // centerline of card i
const toY   = (j) => Math.round((j + 0.5) * UNIT * (fromCount / toCount)); // centerline of card j, scaled
```

The `* (fromCount / toCount)` is what makes lines from two source cards *converge*
to the same target card. If from has 16 cards and to has 8, `fromCount / toCount = 2`
— the to-card centerlines are spaced 2x further apart than the from-card
centerlines, so two from-cards' lines meet at the same to-card's center.

The SVG declares its height as `fromCount * UNIT` (the full height of the
from-column) so the line endpoints sit at exact card-center offsets inside the
viewBox.

```js
const totalH = fromCount * UNIT;
return `<svg class="bv-connectors" width="12" height="${totalH}"
             viewBox="0 0 12 ${totalH}" preserveAspectRatio="none">${paths}</svg>`;
```

`preserveAspectRatio="none"` lets the SVG stretch exactly into the 12px-wide
trench cell. `width="12"` is redundant with the grid CSS but explicit > implicit.

## Coloring the connector — winner highlighting

Three states, three classes:

| Class                  | When                           | CSS                                             |
|------------------------|--------------------------------|-------------------------------------------------|
| (default)              | Match not yet decided          | `stroke: var(--line)`                           |
| `.active`              | Match decided                  | `stroke: var(--accent)`                         |
| `.active.inactive-side`| Match decided, this is the LOSER side | `stroke-dasharray: 3 3; opacity: 0.4` |

The "active side vs inactive side" split is the killer detail — when a match is
decided, the winner's line lights up in the accent color, and the *loser's* line
goes dashed/faded. This is exactly Google's pattern and it's what makes the cascade
read as "this one won, this one lost" rather than just "this is decided".

```js
let activeCls = '';
if (decided) {
  activeCls = ' active';
  if (i % 2 === 0 && winnerB) activeCls += ' inactive-side';
  else if (i % 2 === 1 && winnerA) activeCls += ' inactive-side';
}
```

The logic: pair index `2i` and `2i+1` both feed target `i`. If `2i` is the winner,
`2i+1`'s line goes inactive-side. If `2i+1` is the winner, `2i`'s line does.

## Verification — measure that the lines actually meet the cards

Don't trust visual inspection alone. The line might be 5 pixels off and you'd miss
it. Use Playwright to read both the line endpoint and the card edge from the DOM:

```js
const cardRect = await page.evaluate(`document.querySelector('bracket-view').shadowRoot
  .querySelector('.bv-col-from .bv-card[data-match="0"]').getBoundingClientRect()`);
// cardRect.y = top, cardRect.height = 84
// card center y = cardRect.top + cardRect.height / 2

// Then read the path d attribute and check its y1 is within ±2px of the card center.
```

For the target card (right column), the line should arrive at the *center* of the
target card. The convergence check: line for source 2i and line for source 2i+1
should both have the same `y2` value.

## Pitfall — re-renders lose the connectors if you forget to re-render

`_render()` rewrites `shadowRoot.innerHTML` every time data changes. That destroys
the SVG. So `_renderConnectors()` must be called inside `_render()`, every time,
with the current data. If you forget, the connectors will appear on first paint and
disappear the moment the user clicks anything.

## Anti-pattern — building connectors as separate DOM elements per line

Resist the temptation to draw lines with `<div>`s absolutely positioned. Each line
becomes 4 divs (3 segments + 1 corner), the math for each depends on parent width
+ sibling position + scroll, and it all goes wrong the moment the window resizes.
One SVG with N paths is dramatically simpler to reason about, easy to recolor, and
easy to extend (e.g. to dashes for inactive-side).

## When you DON'T want connectors

If the chain is implicit (e.g. the user's only signal of "this fed this" is the
*position* of cards, not a separate first-class edge), don't draw connectors.
Adding lines that don't carry information adds visual noise. Use them when the
*relationship* between cards is itself a piece of information the user needs.
