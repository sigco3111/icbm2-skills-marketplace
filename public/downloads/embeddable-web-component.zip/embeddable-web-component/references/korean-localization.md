# Korean UI Localization for Embedded Components

When the user wants the component's labels in Korean (round names, status badges, button text, dynamic sub-headers with particle variation), this is the verified recipe. Built and tested against `sigco3111/bracket-view` v17 (2026-07-17) — tabs `16강/8강/4강/결승`, sub-header `승자는 8강으로 진출`, status `풀타임/진행 중/예정`.

## The one-piece-of-data design

A **single label array, indexed by depth-from-final** is enough for any power-of-two round count from 2 to 64:

```js
// Final at index 0, rounds grow backward.
// Verbs (advance / on-knock-out etc.) live elsewhere; these are noun labels.
const KO_LABELS = ['결승', '4강', '8강', '16강', '32강', '64강'];
```

For totalRounds `N`, the **first round (roundIdx 0)** is `KO_LABELS[N - 2]`. Round `i` is `KO_LABELS[N - 2 - i]`. Last round (final) is always `KO_LABELS[0] = '결승'`.

```js
function roundLabel(roundIdx, totalRounds) {
  const start = KO_LABELS.length - (totalRounds - 1); // first round's index
  const idx = start - roundIdx;
  return KO_LABELS[idx] || `Round ${roundIdx + 1}`;
}
```

Verified mapping table:

| totalRounds | roundIdx=0 | roundIdx=1 | roundIdx=2 | roundIdx=3 | roundIdx=4 |
|---|---|---|---|---|---|
| 5 (16 teams) | 16강 | 8강 | 4강 | 결승 | — |
| 4 (8 teams) | 8강 | 4강 | 결승 | — | — |
| 3 (4 teams) | 4강 | 결승 | — | — | — |
| 2 (2 teams) | 결승 | — | — | — | — |

## Sub-header with Korean josa (을/를)

A common sub-header pattern is `"승자는 {nextRoundLabel}으로 진출"` or `"승자는 {nextRoundLabel}로 진출"`. The particle changes based on the last character's **종성 (jongseong / final consonant)**.

```js
function josa(label, particleForJongSung, particleForNoJongSung) {
  // Hangul Syllables block: U+AC00..U+D7A3
  // (codepoint - 0xAC00) % 28 gives the jongseong index; 0 means no jongseong.
  const lastChar = label.charCodeAt(label.length - 1);
  const hasJongSung = lastChar >= 0xAC00 && lastChar <= 0xD7A3
    && (lastChar - 0xAC00) % 28 > 0;
  return label + (hasJongSung ? particleForJongSung : particleForNoJongSung);
}

// Usage:
josa('결승', '으로', '로');  // → '결승으로' (받침 'ㅇ' → 으로)
josa('8강', '으로', '로');   // → '8강으로' (받침 'ㅇ' → 으로)
josa('4강', '으로', '로');   // → '4강으로'
josa('16강', '으로', '로');  // → '16강으로'
```

Non-Hangul last characters (digits, English letters) skip the calculation and just fall back to the no-jongseong particle. Good enough for UI labels — full `받침 확인` for digits like `1등/2등` would need an extension table.

## Status badges — single mapping table

Three states, each gets a label + color cue:

```js
const STATUS = {
  scheduled: { label: match.kickoff || '예정', tone: 'dim' },     // 회색
  live:      { label: '진행 중',            tone: 'danger' },  // 빨강
  fulltime:  { label: '풀타임',            tone: 'winner' },  // 청록
  // Some upstream libs use 'completed' — map it the same as 'fulltime':
  completed: { label: '풀타임',            tone: 'winner' },
  // 'postponed' occasionally shows up:
  postponed: { label: '연기',              tone: 'dim' },
};
```

Defaulting rule: `if (decided) STATUS.fulltime else STATUS.scheduled`. `live` requires an explicit `match.status === 'live'` from the source.

## Button labels

Default English → Korean:

| English | Korean |
|---|---|
| Reset | 초기화 |
| Random | 랜덤 |
| Clear focus | 포커스 해제 |
| Toggle layout (paper-fold ↔ flat) | 펼치기 / 접기 |
| Empty state ("No teams loaded") | 팀이 없습니다 |

The layout toggle is two states — use `this._layout === 'paper-fold' ? '⤢ 펼치기' : '⤡ 접기'` and `title="레이아웃 전환"`.

## HTML title bar (document.title)

`<title>` and `<h1>` headers need Korean too. Just write them in Korean directly; no special handling.

## When to fall back to English

If `totalRounds > 6` (64 teams is the largest KNOWN standard), the array doesn't cover it. Fall back to a separate English array with the same depth-from-final structure:

```js
const ENGLISH_LABELS = ['Final', 'Semifinals', 'Quarterfinals', 'Round of 16', 'Round of 32', 'Round of 64'];
// Same start = length - (totalRounds - 1), same idx = start - roundIdx
```

Use English when the user later asks for an English variant. Don't mix languages in a single component.

## Diagnostic

Open the live page and confirm:
- All visible labels are in the requested language (no English fallback sneaking in)
- `page.evaluate(() => [...shadow.querySelectorAll('.label')].map(e => e.textContent))` returns only Korean strings
- The josa-rendered sub-header reads naturally when spoken aloud: "승자는 8강으로 진출" sounds correct; "승자는 8강로 진출" sounds wrong
- No empty `<span>` slots (a missing `label` returns `undefined` which renders as the literal text "undefined" — easy to spot in screenshots)
