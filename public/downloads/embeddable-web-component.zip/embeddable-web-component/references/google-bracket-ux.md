# Google Search Bracket Card — UX Reverse-Engineering Notes

When the user pastes Google Search's tournament-card screenshot and says "I want this",
these are the structural patterns to look for. The session that produced this reference
(`/Users/mac/work/bracket-view/` v2) decomposed 4 screenshots from a 2026 FIFA World
Cup search result.

## The single most important structural insight

**The bracket is a *paper-fold* of round-pairs, not a horizontal list of all rounds.**

A flat horizontal-scroll bracket (v1 default) shows *everything at once* — the user
must scroll the entire viewport to traverse rounds. Google shows *one round-pair at a
time*, paginated:

```
┌────── round-pair 0 ──────┐ ┌────── round-pair 1 ──────┐ ┌── final+3rd ──┐
│  Round 32   │  Round 16  │ │  Round 16   │  Round 8    │ │  Final │ 🏆    │
│  16 matches │  8 matches │ │  8 matches  │  4 matches │ │ 1 match│ 🏆    │
└─────────────┴────────────┘ └─────────────┴────────────┘ └────────┴───────┘
     swiped out                   swiped in                 swiped in
```

A swipe / tab click advances by exactly one round. There's no "long scroll" between
rounds — the track is paginated with `scroll-snap`.

**Consequence for the component:** there are **N pages** in the track, where
`N = rounds.length` (each page shows current + next, with the last page being final +
trophy). NOT `N - 1` pairs plus a separate final.

## Card v2 — what each card must carry

The v1 "two text rows in a small SVG rect" loses information Google considers
first-class. Each card needs:

| Slot        | Example                              | Source                          |
|-------------|--------------------------------------|---------------------------------|
| Date        | `7.11 (목) 오전 4:00`                | `match.date`                    |
| Status badge| `풀타임` / `진행 중` / `예정`         | `match.status` ('fulltime' / 'live' / 'scheduled') |
| Team A row  | `🇦🇷 아르헨티나    2 ◀`              | `match.a.flag`, `match.a.displayName`, `match.scores.a` |
| Team B row  | `🇧🇪 벨기에        1`                | `match.b.flag`, `match.b.displayName`, `match.scores.b` |
| ◀ arrow     | Only on the side fed by a previous match | `match.prev.a` / `match.prev.b` (ID) |

The ◀ arrow is the visual trace of the propagation chain — when you click a winner on
a Round-of-32 card, the ◀ arrow appears on the corresponding row of the Round-of-16
card. That's what makes the cascade feel physical.

## Navigation layer — tabs that own scroll

Tabs sit **above** the track as a sticky horizontal strip:

```
[32강 → 16강]  [16강 → 8강]  [8강 → 준결승]  [준결승 → 결승]  [결승]
       ● (active underline)
```

Two-way sync is required:

- **Tab clicked → scroll the horizontal track only**: `track.scrollTo({ left: page.offsetLeft, top: 0, behavior: 'smooth' })`. Add `preventDefault()` to the tab click. Do not use `page.scrollIntoView()` because it may also move the document viewport vertically.
- **User scrolls/swipes → IntersectionObserver on each `.bv-page` picks the
  dominant intersection ratio → updates `.active` class on the matching tab.** The IO callback must only toggle classes; never call `tab.scrollIntoView()` from it.

Skip the IO half and the tab gets stuck on the initial selection after a swipe.

Use `scroll-snap-type: x proximity` + `scroll-snap-align: start` + `overscroll-behavior-y: none` + equal-height pages. In live mobile verification, `mandatory` cross-axis snapping plus `scrollIntoView` produced document-level vertical jumps; explicit `track.scrollTo(..., top: 0)` kept `window.scrollY` and the component's viewport top unchanged across every tab.

## Boundaries — final page + 3rd place playoff

The last page is a special case:

- **No "next round" column** — only the final match + a trophy block
- The trophy block is its own column to the right of the final match card. When
  `final.winner` is set, it shows the champion name. When null, it shows `🏆 + "결승 대기"`.

3rd-place playoff renders **outside the main track**, as a single dashed-border card
below the track. It is not part of the round-pair pagination — it's a separate slot.

```js
// pages.length = rounds.length (not rounds.length - 1)
// last page: from = rounds.length - 1, to = same, isFinal = true
// thirdPlace card: rendered below the track, separate from pagination
```

## Status state machine — three states

```js
status: 'scheduled' | 'live' | 'fulltime'
```

- `scheduled` → 회색 "예정" badge; no score shown
- `live` → 빨간색 "진행 중" badge; score shown even if tied
- `fulltime` → 청록색 "풀타임" badge; score shown

The `winner` field is independent: it's set by the user (or by `randomFill()`), not
derived from score. A match can have a `winner` set without `status: 'fulltime'`
(you decided the bracket before the simulated match ran), or vice versa.

## Data shape — `prev` trace

The `prev` object on each match records which previous match fed which side. Without
this, the ◀ arrow can't be rendered:

```js
{
  id: 'M17',
  a: { name: 'Argentina', flag: '🇦🇷' },   // winner of M1 was promoted here
  b: { name: 'Brazil', flag: '🇧🇷' },       // winner of M2 was promoted here
  prev: { a: 'M1', b: 'M2' },              // ← drives the ◀ render
}
```

`_propagateWinner(round, idx)` mutates `nextMatch.prev.a` or `prev.b` at the same time
it sets `nextMatch.a`/`b`. If you skip the `prev` update, the ◀ will be missing on the
next round even though the winner is correctly promoted.

## What the user actually means when they say "이게 내가 원하는 거야"

When the user shows a Google-bracket screenshot, they are looking at a **navigation
and information-density pattern**, not a color palette or font choice. If you copy
Google's aesthetics (rounded corners, dark theme, blue accents) but build a flat
horizontal list, the user will respond with the structural-mismatch sentence:

> 예쁘기는 한데 내가 원하는 건 아냐
> (Pretty, but not what I wanted)

The match is in the **navigation structure** (paginated round-pairs + tabs + swipe)
and **card information density** (date + status + flag + name + score + ◀), NOT in
the visual styling.

**Always decompose before coding.** Fill out this table per screenshot before
writing any code:

| Question                                            | Answer for Google bracket                      |
|-----------------------------------------------------|-----------------------------------------------|
| How many columns shown simultaneously?              | 2 (current round + next round)                |
| Is there a navigation layer?                        | Yes — tab strip + swipe both control same track|
| What info per card?                                 | date + status + (flag + name + score + ◀) × 2 |
| Are there visual links?                             | No drawn lines — the ◀ arrow carries the chain|
| What's at the boundary?                             | Final page + trophy column + 3rd-place card below |
| What's first-class state?                           | status (3 values) + winner (independent from score) |

If any of those answers is different from what you'd build, **stop and surface the
difference to the user** before writing code. The fastest way to recover from a
structural mismatch is to never build the wrong structure in the first place.
