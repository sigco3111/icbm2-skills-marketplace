# Evaluating Third-Party Widget Libraries for No-Build Single-File Embeds

When the page is single-file / no-build (`<script type="module">` or `<script src=...>` only — no webpack, no Vite, no bundler) and the user wants to *import* an existing widget rather than build one, this is the playbook. The "is this library importable from a CDN?" question has six concrete failure modes; check each in order before recommending a library.

This file was born from evaluating single-elimination bracket libraries for `sigco3111/bracket-view` (live: https://sigco3111.github.io/bracket-view/). The exact same matrix generalizes to any "drop-in chart / calendar / picker / viewer" search.

---

## The 6-axis verification matrix

Run these in order. Stop at the first axis that fails — that library is dead for no-build use.

| # | Axis | How to verify | What kills it |
|---|---|---|---|
| 1 | **npm name exists** | `curl -s https://registry.npmjs.org/<pkg> \| jq .` | Typo, never published, or scoped under private org |
| 2 | **jsDelivr resolves it** | `curl -sI https://cdn.jsdelivr.net/npm/<pkg>@<ver>` → 200 | npm name correct but no tarball published to jsDelivr's index |
| 3 | **Dist files exist** | `curl -s https://data.jsdelivr.com/v1/package/npm/<pkg>@<ver> \| jq` | npm has metadata but `dist/` was gitignored — `main`/`module` are null |
| 4 | **UMD/script-tag OR ESM build** | Inspect `package.json` `main` + `module` + `unpkg` + `exports` fields; check file listing for `.min.js` or `.esm.js` | Only ships `dist/cjs/index.js` (CommonJS only — unusable in browser) |
| 5 | **Import via esm.sh works** | `curl -sI https://esm.sh/<pkg>@<ver>` → 200; for React deps add `?deps=react@18,react-dom@18` | esm.sh can't transform due to non-portable deps (e.g. native Node modules) |
| 6 | **License + activity + stars** | `(license || {}).spdx_id`, `pushed_at`, `stargazers_count` | AGPL-3.0 (no-go for most projects), unpushed since 2017, <5 stars |

If all 6 pass → ready to recommend. Track results in a small table with the URL, license, last-push, import shape, data model.

---

## Four import shapes that work in a single HTML page

Pick one based on what the library ships.

### Shape A: Plain `<script>` + global namespace (simplest)
```html
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/<pkg>@<ver>/dist/x.min.css">
<script src="https://cdn.jsdelivr.net/npm/<pkg>@<ver>/dist/x.min.js"></script>
<script>/* X.someApi(...) is on window */</script>
```
Examples: `teijo/jquery-bracket`, `@amirhossein-shk/tournament-bracket-js`.

### Shape B: WebComponent (Custom Element) auto-registers
```html
<script type="module" src="https://cdn.jsdelivr.net/npm/<pkg>@<ver>/dist/adapters/webcomponent.js"></script>
<my-widget data='{"...":"..."}'></my-widget>
```
Examples: `gracket` with `adapters/webcomponent.js`. **Best UX** — host page needs zero JS.

### Shape C: ES module import
```html
<script type="module">
  import { Foo } from "https://esm.sh/<pkg>@<ver>";
</script>
```
Examples: `vue-tournament-bracket`, `gracket` core, `tournament-bracket-tree`.

### Shape D: ESM with peer-dep pinning
```html
<script type="module">
  import React from "https://esm.sh/react@18";
  import { Bracket } from "https://esm.sh/<react-pkg>@<ver>?deps=react@18,react-dom@18";
</script>
```
Always pin React + react-dom to the same major version via `?deps=`. For Preact (smaller): `?deps=preact@10&alias=react:preact/compat,react-dom:preact/compat`.

---

## Decision tree: when to import vs when to build

```
User wants "drop-in <widget>" in a single-file page
  │
  ├─ Does an existing library pass all 6 axes? ──── no ──▶ Build it (use skill)
  │                                          │
  │                                          yes
  │                                          ▼
  ├─ Library ships Shape B (WebComponent)? ──── yes ──▶ Use Shape B (zero host JS)
  │                                          │
  │                                          no
  │                                          ▼
  ├─ Library is jQuery/vanilla, ≤ 30KB minified? ── yes ──▶ Use Shape A
  │                                          │
  │                                          no
  │                                          ▼
  ├─ Library is React-only? ── Use Shape D with Preact alias to save ~40KB
  │                                          │
  │                                          ▼
  └─ Library is Vue/Svelte? ── Use Shape C with `?deps=vue@3`
```

---

## Pitfalls specific to CDN-imported widgets

### P1: `package.json` has `main`/`module` but no `dist/` was actually uploaded
Several libraries ship a `package.json` that references `dist/index.js`, but the `.npmignore` accidentally excludes `dist/`. jsDelivr will then list the package but `curl -sI https://cdn.jsdelivr.net/npm/<pkg>@<ver>/dist/index.js` returns 404.

**Detection**: always check the file tree at `https://data.jsdelivr.com/v1/package/npm/<pkg>@<ver>` and confirm the path you intend to import actually exists with a non-zero `size`.

### P2: ESM-only libraries that ship CJS under `main`
esm.sh can often transform CJS → ESM on the fly, but if a library uses dynamic `require()` at the top level, the transform fails silently and you get an empty module.

**Detection**: after import, `await import('https://esm.sh/<pkg>')` and log what you actually got. If `Object.keys(mod).length === 0`, switch to Shape A or pick a different library.

### P3: React libraries with stale `peerDependencies`
A React component lib published in 2022 might still declare `peerDependencies: { react: "^16" }`. esm.sh will respect that and refuse to install react 18, breaking the page.

**Fix**: always pin peer deps explicitly: `?deps=react@18,react-dom@18,styled-components@5`. Don't trust the lib's own peer-dep declaration.

### P4: Library uses `styled-components` v4 (legacy, ESM-broken)
Some popular React bracket libs (`@g-loot/react-tournament-brackets`) hard-depend on `styled-components@^4`, which only ships CommonJS. esm.sh can wrap it, but the wrapped bundle is ~120 KB and has known issues with React 18 concurrent mode.

**Workaround**: prefer libraries with CSS-only theming (CSS custom properties). If the lib insists on `styled-components`, the build is fragile — flag it as a risk to the user.

### P5: Web Component adapters that try to register the same tag twice
If the host page already has `<gracket-bracket>` and the imported adapter also registers it, you get `NotSupportedError: This name has already been used`. Check the adapter's source for `customElements.define(...)` — most do it on import, no opt-out.

**Fix**: only import the adapter once. Don't include both the core bundle and the adapter in the same page.

### P6: jsDelivr `data.jsdelivr.com/v1/package/npm/<pkg>` may rate-limit
After ~30 lookups in a minute the API starts returning 429. The CDN itself (`cdn.jsdelivr.net/npm/...`) is not rate-limited the same way. If you hit 429, fall back to `https://unpkg.com/<pkg>@<ver>/` for verification (unpkg is a bit slower but never rate-limited in practice).

### P7: Star count ≠ library quality
`evroon/bracket` (1699 stars, AGPL-3.0) is a *full-stack tournament system* (backend + DB + frontend), not a reusable widget. `sbachinin/bracketry` (42 stars) is a single-file vanilla JS widget that ships in 8 KB and just works. Read the description + first 50 lines of `README.md` before trusting the star count.

---

## Validated candidate list — single-elimination bracket libraries

Snapshot from 2026-07-17. Treat as a starting point, not gospel — re-run the 6-axis matrix before each new project because npm publishing is fast and casual.

| Rank | npm package | Stars | Last push | License | Import shape | Why pick it |
|---|---|---|---|---|---|---|
| 1 | `@amirhossein-shk/tournament-bracket-js` | new | 2024–2025 | MIT | A (script tag) **or** C (ESM) | Only library that ships **both** UMD and ESM builds natively — exactly matches "no build" use case |
| 2 | `gracket` (Zettersten/jquery.gracket.js) | 103 | 2025-11 | MIT | B (WebComponent adapter) **or** C (ESM) | Zero deps, built-in stats/export/bye handling, WebComponent adapter drops in as one `<script>` |
| 3 | `teijo/jquery-bracket` | 500 | 2023-07 | MIT | A (jQuery + script) | Battle-tested, interactive editing, but jQuery adds ~30KB |
| 4 | `vue-tournament-bracket` | 21 | 2024 | MIT | C (ESM + Vue3) | Clean Vue3 API, UMD bundle also available |
| 5 | `react-tournament-bracket` (moodysalem) | 285 | 2022-12 | ISC | D (ESM + React) | Mature but uses `styled-components@^4` — risk for React 18 |
| — | `bracket-data` | n/a | n/a | MIT | C (ESM, data-only) | No rendering, just bracket-state math — useful as the data layer under a custom renderer |
| — | `tournament-bracket-tree` | n/a | n/a | MIT | C (ESM) | Tiny data-structure library (classnames dep), not a renderer |

**Excluded on purpose**:
- `sbachinin/bracketry` — confirmed to ship but user already rejected.
- `g-loot/react-tournament-brackets` — needs `react-svg-pan-zoom` + `styled-components@4`; fragile under esm.sh.
- `Drarig29/brackets-viewer.js` — user already rejected.
- `evroon/bracket` — AGPL-3.0 license + full-stack architecture, not a reusable widget.

---

## Verified ESM/script URLs (live HTTP 200 at time of writing)

```
# Shape A (script tag)
https://cdn.jsdelivr.net/npm/@amirhossein-shk/tournament-bracket-js@1.0.7/dist/tournament-bracket.min.js
https://cdn.jsdelivr.net/npm/jquery-bracket@0.11.1/dist/jquery.bracket.min.js

# Shape B (WebComponent adapter)
https://cdn.jsdelivr.net/npm/gracket@2.1.1/dist/adapters/webcomponent.js

# Shape C (ESM)
https://esm.sh/gracket@2.1.1
https://esm.sh/vue-tournament-bracket@3.0.0?deps=vue@3
https://esm.sh/tournament-bracket-tree@1.0.1

# Shape D (React + esm.sh)
https://esm.sh/react-tournament-bracket@1.0.41?deps=react@18,react-dom@18
https://esm.sh/preact@10.22.0
```

All 200 OK on 2026-07-17. Re-verify before each use — these URLs can rot fast.