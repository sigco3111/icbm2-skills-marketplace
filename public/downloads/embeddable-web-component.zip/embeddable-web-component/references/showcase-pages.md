# Multi-Library Showcase Pages on GitHub Pages

When the user has a `bracket-view`-style component and says "show me how it compares to the others, on one page" — or wants to publish a single GitHub Pages URL that demos *multiple* libraries in one place (their own build + 3rd-party imports + self-impl references) — this is the pattern. Built for `sigco3111/bracket-view` v22 (2026-07-17): https://sigco3111.github.io/bracket-view/.

## What "showcase" means here

A single GitHub Pages URL that hosts 6–8 cards on one screen, each card showing the *same sample data* rendered by a different approach:

- Card 1: your own component (imported via `<script type="module">` from the same repo)
- Cards 2–5: 3rd-party libraries imported as `<script>` or `<script type="module">` from CDN
- Cards 6–8: plain JavaScript self-implementations that copy the visual pattern from each library's docs

The page is **not** an iframe gallery (those get blocked by upstream X-Frame-Options, see `references/cdn-third-party-widget-evaluation.md`). It's a single index.html that runs everything inline.

## Card taxonomy — pick all three flavors

| Card type | When to use | How it loads |
|---|---|---|
| **Self-import** | You built it and want it on the showcase | `<script type="module" src="./my-comp.js">` then `<my-comp></my-comp>` |
| **Live CDN import** | Library has a working UMD script tag or ESM build | `<script src="https://cdn.jsdelivr.net/npm/...">` then call the global |
| **Self-implementation** | Library exists but isn't CDN-friendly, or you want to show the visual pattern without dependency | Write ~30–80 lines of vanilla JS in a sibling `bracket-samples.js` and dispatch on `data-sample="lib-name"` |

Mix all three on one page. The contrast IS the point: readers see "here's what a 3KB self-impl looks like vs. a 280KB CDN library renders for the same data" without leaving the page.

## Data sharing — write JSON once, render 6 ways

Put a single JSON blob in a `<script id="sample-data" type="application/json">` tag at the top of the page. Parse it once and pass to every renderer:

```html
<script id="sample-data" type="application/json">
{
  "participants": [
    { "id": "p1", "name": "Brazil" },
    ...
  ],
  "rounds": [[...], [...], [...]]
}
</script>
<script>window.SAMPLE_DATA = JSON.parse(document.getElementById('sample-data').textContent);</script>
```

Each card mounts into a `[data-sample="libname"]` div; the renderer dispatcher in `bracket-samples.js` picks the right one:

```js
document.querySelectorAll('[data-sample]').forEach(el => {
  const which = el.getAttribute('data-sample');
  ({ bv: renderBracketsViewer, vue: renderVue, ... })[which]?.(el);
});
```

This pattern means **one source of truth** for the bracket state. When a card decides its own winner via UI, the others don't auto-update — that's fine, the showcase is a *visual* comparison, not a live data sync.

## Mount your own component (card #1)

The your-own card needs special handling because it's a Web Component loaded as an ES module — `customElements.define()` runs when the module imports, and the element is then droppable into HTML:

```html
<!-- In <head> or just before <body> close -->
<script type="module">
  await import('./my-component.js');  // registers <my-component>

  const mount = document.getElementById('my-mount');
  const root = document.createElement('my-component');
  root.setAttribute('layout', 'paper-fold');
  root.style.width = '100%';
  mount.appendChild(root);

  // Feed sample data
  const data = { rounds: [...], participants: [...] };
  root.setData ? root.setData(data) : setTimeout(() => root.setData?.(data), 300);
</script>
```

Wait until the page DOM is parsed before `document.createElement` / `appendChild`. Module scripts are deferred by default so they're fine to put anywhere — but the mount div must already exist when the script runs.

## Live CDN imports — three failure modes, three fixes

When the page imports multiple CDN libraries, expect at least one to fail. Each failure mode has a known recovery:

| Failure | Symptom | Fix |
|---|---|---|
| **Iframe X-Frame-Options** | `<iframe src="...">` shows blank | Don't iframe. Just `<script src>` and call the global in a `<div data-sample>` mount point. |
| **Library tries to write to `shadowRoot` directly** | `Cannot set property shadowRoot of #<Element> which has only a getter` | Detect on first load — show a "library self-fail" status card with the error message. Don't try to monkey-patch the library. |
| **ESM peer-dep version mismatch** | React 18 vs 17 errors | Add `?deps=react@18,react-dom@18` to esm.sh URLs. |
| **Library needs DOM ready** | Calling too early throws "Cannot read property 'appendChild' of null" | Wrap in `document.addEventListener('DOMContentLoaded', ...)` or check the mount exists first. |

The "library self-fail" card pattern is honest and useful — readers see *why* the import didn't work (the actual error message) instead of an empty white box. Make it look intentional:

```html
<div id="livesample-shk" class="lib-status">
  <div class="lib-status-msg">
    <p class="lib-status-tag">library self-fail</p>
    <p>Imported successfully from jsDelivr, then called
       <code>window.tournamentBracket(...)</code>. Internally, the library
       tries to write to a <code>shadowRoot</code> property that is read-only
       in modern browsers...</p>
    <p><a href="...">Source on GitHub ↗</a></p>
  </div>
</div>
```

## Self-implementations — copy the visual, not the code

For libraries that don't ship a CDN build, or to show readers "what would it look like to write this pattern by hand", write a ~50-line vanilla JS renderer per library. Each lives in `bracket-samples.js` as a named function:

```js
function renderBracketsViewer(el) {
  // Plain flex column with rounded boxes. Matches the DOM look of
  // Drarig29/brackets-viewer.js without depending on the library.
  el.innerHTML = `<div class="bv-round">
    ${SAMPLE_DATA.rounds[0].map(m => `
      <div class="bv-card">
        <div class="bv-team ${m.winner === 'a' ? 'winner' : ''}">${m.a.name}</div>
        <div class="bv-team ${m.winner === 'b' ? 'winner' : ''}">${m.b.name}</div>
      </div>`).join('')}
  </div>`;
}
```

The dispatcher routes by attribute. Add a new card by writing one function and one CSS block — no build step.

## Layout — `auto-fit` grid for responsive cards

The card grid adapts to any viewport without breakpoints:

```css
.lib-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(360px, 1fr));
  gap: 20px;
}

@media (max-width: 700px) {
  .lib-grid { grid-template-columns: 1fr; }   /* force 1 column on phones */
}
```

On a 1280px desktop, ~3 cards per row. On a phone, 1 per row. No manual breakpoints between.

## i18n for the showcase page itself

If the user wants the *page chrome* (titles, descriptions, button labels) in their language but the rendered libraries can stay in whatever language the libraries ship in:

- Wrap every translatable string in parallel spans: `<span class="ko" data-i18n-show="ko">한국어</span><span class="en" data-i18n-show="en">English</span>`
- Single CSS rule: `[data-i18n-show] { display: none; }`
- Toggle button calls `applyLocale(loc)` which sets `body[data-locale]` AND inline `display: block/inline` on matching spans
- **Do NOT use `el.style.display = ''`** — it doesn't beat the CSS rule. See Pitfall #14 in SKILL.md.

The library cards themselves can stay in their own language (e.g. our bracket-view renders Korean tabs/badges; the self-implementations render English labels). The user can see both side-by-side. The page chrome is the only thing the toggle affects.

## Order the cards: own first

Put your own component as card #1. The page is a showcase of what *you built*, with the others as comparisons. Not "card 5 of 8" — card #1 with `↻ OUR BUILD` badge in the title.

## Card title pattern

```html
<article class="lib-card">
  <div class="lib-meta">
    <h3>
      1. Ours (sigco3111/bracket-view)
      <span class="status-badge ours">↻ OUR BUILD</span>
    </h3>
    <p>One-line description of the pattern this card demos.</p>
    <div class="stats">
      <span><b>↻ OUR BUILD</b></span>
      <span>MIT</span>
      <span>v22 card alignment</span>
    </div>
  </div>
  <div class="lib-frame tall">
    <h4>Single-elimination 8 teams (paper-fold)</h4>
    <div id="my-mount"></div>
  </div>
  <div class="actions">
    <a href="https://github.com/sigco3111/my-component" target="_blank" rel="noopener">
      Source on GitHub ↗
    </a>
  </div>
</article>
```

The `OUR BUILD` badge is a different color than `LIVE IMPORT` so readers can tell at a glance which cards are *yours* vs. third-party live imports vs. self-implementations.

## Verification — capture one screenshot per state

For a multi-card showcase:

```js
// 1. Page loads, all cards present
await page.screenshot({ path: 'showcase-full.png', fullPage: true });

// 2. Locale toggled to English
await page.click('button[data-locale-target="en"]');
await page.waitForTimeout(500);
await page.screenshot({ path: 'showcase-en.png', fullPage: true });

// 3. Each card's first child element actually rendered (not just an empty div)
const cards = await page.$$eval('article.lib-card', cs =>
  cs.map(c => c.querySelector('.lib-frame > *:not(h4)')?.children.length || 0)
);
// Expect at least one child per card; the live-import-fail card counts the
// status message as a child.
```

Three states to capture: ko, en, mobile (390×2400).

## Pitfalls specific to showcase pages

### S1: Cards not on the same data shape

Different libraries expect different shapes:
- `brackets-viewer.js`: `{ stages: [{ matches: [...] }] }`
- `react-tournament-bracket`: `{ matches: [...] }` flat list
- `bracketry`: `{ rounds: [...], teams: [...] }`

The data-sharing JSON tag is one shape (whichever your own component uses). Self-implementation renderers translate. Live CDN imports translate in the `<script>` block. Don't try to be canonical — translate at the boundary.

### S2: Card frame must have a real min-height

If a card's render output is empty (e.g. before the library script loads), the layout collapses. Set `.lib-frame { min-height: 360px; }` (or `460px` for `tall` cards with extra space). The card is at least a placeholder-shaped box before its contents render.

### S3: Loader order matters

Mount divs are in the DOM at parse time. Scripts that mount into them can run in any order BUT a `<script type="module">` is deferred by default, so it runs after `DOMContentLoaded`. A plain `<script>` (UMD library) runs as soon as the parser hits it — if you put the script *before* the mount div, the mount doesn't exist yet. Put all scripts (or at least all `DOMContentLoaded`-dependent ones) at the end of `<body>`.

### S4: `<script type="module">` inside an inline `<script>` parent

If you have `<script>...</script>` (non-module) that tries to `<script type="module">...</script>` again, the inner module will run but the outer script's variable assignments don't wait for it. Use:

```js
// Outer (non-module): schedule the module work
setTimeout(async () => {
  await import('./my-comp.js');   // waits for module
  // ... mount it
}, 0);
```

Or just keep everything in one `<script type="module">` block at the bottom of `<body>`.

## Reference implementation

`/Users/mac/work/bracket-view/index.html` — 8 cards (1 own build, 2 live imports, 5 self-impls) with ko/en toggle, full verification screenshots at `/tmp/v22-*.png`.

Live: https://sigco3111.github.io/bracket-view/

The pattern generalizes to any "show me how X compares to Y, on one page" request: same data shape, N cards, N renderers, single GitHub Pages URL.
