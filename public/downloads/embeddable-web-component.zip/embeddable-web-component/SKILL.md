---
name: embeddable-web-component
description: Build reusable, themeable, zero-dependency interactive UI building blocks as Web Components (Custom Elements + Shadow DOM). Triggered when creating components intended to be embedded in multiple projects — bracket viewers, visualizers, form widgets, charts, pickers, animated SVG components, etc. Covers inline SVG rendering, pointer-events hierarchy pitfalls, the focus/dim UX pattern, declarative + programmatic API design, event conventions, themability via CSS custom properties, Playwright shadow-DOM verification patterns, GitHub Pages nobuild deploy, and how to reverse-engineer screenshot references structurally instead of aesthetically. Skip for one-off HTML pages (use creative/claude-design instead).
---

# Embeddable Interactive Web Components

When the deliverable is a single-file, zero-build, zero-dep interactive UI building block that drops into any web page (or framework) with one script tag, this is the pattern. The session that produced this skill — `/Users/mac/work/bracket-view/` — is the canonical worked example.

## When to use this skill

Trigger when the user wants:
- A reusable widget / visualization / form / picker / viewer to embed
- A component that works in vanilla HTML + React + Vue + Next.js with zero config
- A visual reference (Google bracket card, Figma mock, screenshot) to reverse-engineer into a reusable thing
- Mobile-friendly interactivity (touch, swipe, scroll-snap)

**Do NOT use for** one-off HTML pages, throwaway demos, or server-coupled features. For those: `creative/claude-design` (one-off artifacts), `software-development/spike` (validate-before-build), or proper framework component libs (heavy reuse across one app).

## Core architecture — four layers

Every component in this pattern has exactly four layers. Don't skip any.

| Layer | Role | Implementation |
|---|---|---|
| **Custom Element** | Public tag name, public API | `class Foo extends HTMLElement` + `customElements.define('foo', Foo)` |
| **Shadow DOM** | Style isolation from host page | `this.attachShadow({ mode: 'open' })` |
| **Inline SVG** | All graphics | SVG string returned from a render function |
| **CSS custom properties** | Themability without poking inside shadow | `:host { --foo-* }` + `var(--foo-*)` in shadow CSS |

Bonus surface: a small **public API** (`setData`, `reset`, `randomFill`, `getState`) PLUS a **declarative attribute layer** (`<foo-comp attr="...">`) so the component is useful with zero JS.

## File layout

```
my-component/
├── my-component.js     # 300–700 lines, single ES module, ≤ 30KB
├── index.html          # demo with 2–3 usage scenarios
├── README.md           # usage, API, events, theming, embed instructions
└── .gitignore
```

No build step. No `package.json` needed. Single import: `<script type="module" src="./my-component.js"></script>`.

## Authoring checklist (run before committing)

- [ ] Component is a single `.js` file ≤ ~30KB
- [ ] All styles are inside Shadow DOM (no host-page leakage, no `:root` selectors)
- [ ] `:host` exposes ≥ 6 CSS custom properties for theming
- [ ] Has both declarative (`<comp attr="...">`) and programmatic (`comp.setData(...)`) APIs
- [ ] Emits ≥ 1 event with `{ bubbles: true, composed: true }` for parent integration
- [ ] Touch-friendly: tap targets ≥ 36px, no hover-only state
- [ ] Mobile: horizontal scroll OR vertical scroll-snap when content overflows
- [ ] Respects `@media (prefers-reduced-motion: reduce)`
- [ ] Sanitizes any user-provided string via HTML escape before injecting into SVG/HTML
- [ ] `_render()` re-attaches all event listeners (idempotent — don't `addEventListener` once in `connectedCallback` if you ever re-render)

---

## Visual reference reverse-engineering — when the user says "like this"

When the user shows a screenshot of another product and says "I want this", the difference between delivering something *inspired by* vs something that *matches* the structure is whether you actually decompose what they're seeing.

**Common user reaction when this goes wrong**: "예쁘기는 한데 내가 원하는 건 아냐" / "It looks pretty but it's not what I want". That sentence means you copied the **aesthetic** (colors, smoothness, roundness) but missed the **structural pattern** (how data flows, how the user navigates, what slots are first-class).

**Concrete decomposition checklist** — for any screenshot the user gives you, produce a table with these rows before writing any code:

| Question to answer from the image | Why it matters |
|---|---|
| How many **columns** are shown simultaneously? | Determines horizontal-scroll vs tabbed-zoom layout |
| Is there a **navigation layer** (tabs, chips, scroller)? | Determines whether the component owns nav or the host page does |
| What **information per card**? (date, status, score, team, score-arrows) | Determines the slot model — names are not enough |
| Are there **visual links** (lines, arrows, connectors)? | Determines whether the component has 2D structure or just a list |
| What happens at **boundaries** (last round, playoff)? | Determines whether you need a separate "playoff" / "third-place" rendering path |
| What's **first-class state** (live/scheduled/completed, winner/loser/tbd)? | Determines the data model — `winner: 'a'` is not the same as `score: { a: 2, b: 0, state: 'completed' }` |

For the Google Search bracket pattern specifically, see `references/google-bracket-ux.md`.

---

## Critical pitfalls — in priority order

### 1. SVG pointer-events hierarchy (the #1 trap)

This will bite you. By default, every `<g>` with `pointer-events: visiblePainted` (the SVG default) intercepts clicks on its rendered children. So:

```svg
<g class="match">
  <rect class="match-card"/>          <!-- intercepts -->
  <line class="separator"/>            <!-- also intercepts -->
  <g class="team"><rect/></g>          <!-- blocked above -->
</g>
```

A click on a `.team` `<rect>` is intercepted by the `.match-card` rect drawn on top. Result: nothing clicks correctly, no error, silent failure. Playwright reports it as `<line> intercepts pointer events` on every retry.

**Fix pattern** — three rules:

```css
/* 1. SVG root container does NOT receive pointer events */
.bracket-svg { pointer-events: none; }

/* 2. Only the interactive <g> groups (matches wrapper) opt back in */
.bracket-svg .matches,
.bracket-svg .matches > * { pointer-events: all; }

/* 3. Decorative chrome inside a match does NOT receive pointer events */
.match > rect,
.match > line,
.match > text.match-id { pointer-events: none; }

/* 4. Team <g> groups inside a match opt back in */
.team { pointer-events: visiblePainted; }
.team > text { pointer-events: none; }
```

The principle: **the SVG root container and decorative chrome should NOT receive pointer events**. Only the interactive groups should. Apply this hierarchy whenever you have nested clickable groups in SVG.

### 2. setData / mutate-before-render order

When wiring data updates + state propagation, call `setData(data)` BEFORE calling any propagation method that reads `this._data`:

```js
// WRONG — throws on first call
const data = this._generateFromTeams(teams, 'Title');
this._propagateWinner(0, 0);   // reads this._data.rounds[1] → null!
this.setData(data);

// RIGHT
const data = this._generateFromTeams(teams, 'Title');
this.setData(data);              // this._data = data
this._propagateWinner(0, 0);     // now this._data.rounds[1] exists
this._render();
```

### 3. setData must reset focus/selection state

When the user resets or swaps data, clear any focus/selection/highlight state — otherwise the focused match from the previous dataset "leaks" into the new one:

```js
setData(data) {
  this._data = data;
  this._focusedMatch = null;   // ← reset
  this._render();
}
```

### 4. CustomEvents from inside Shadow DOM need `composed: true`

Without it, the event won't cross the shadow boundary and host-page listeners will never hear it:

```js
this.dispatchEvent(new CustomEvent('match-decided', {
  detail: { round, match, winner },
  bubbles: true,
  composed: true,   // ← required, not optional
}));
```

### 5. HTML-escape every string before injecting into SVG

`shadowRoot.innerHTML = ... ${userInput} ...` will break the SVG (and XSS) if the input contains `<`, `>`, `&`, `"`, `'`. Always:

```js
_esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}
```

Apply to: team names, match IDs, titles, anything from outside the component.

### 6. Custom Element must be defined before the tag is parsed

If your HTML has `<my-comp>` before the `<script type="module">` that defines it, the browser silently treats the tag as `HTMLUnknownElement` — the constructor never runs.

**Fix:** put the import in `<head>`, or load it before any usage. Module scripts default to deferred execution so a `<script type="module" src="./my-comp.js">` in `<head>` works.

### 7. Round-label mapping for varying sizes

When labeling tournament rounds (or any positionally-varying context), use a single array + offset — no per-size branching:

```js
const labels = ['Round of 32', 'Round of 16', 'Quarterfinals', 'Semifinals', 'Final'];
const offset = Math.max(0, labels.length - numRounds);
const label = labels[offset + r];
```

Handles any power-of-two size (4/8/16/32/64) without conditionals.

### 8. Never attach event listeners in `connectedCallback` if `_render()` rewrites the DOM

If your `_render()` does `this.shadowRoot.innerHTML = '...'`, every `addEventListener` you added in `connectedCallback` is on nodes that no longer exist. Either:
- (a) Attach listeners inside `_render()` after `innerHTML =`, or
- (b) Use event delegation on `this.shadowRoot` (one listener, handles everything)

(a) is simpler for small components. (b) scales better.

---

## Theming via CSS custom properties

Expose design tokens on `:host` so the host page can re-theme without touching inside:

```css
:host {
  --bv-bg: #0f1115;
  --bv-card: #1a1d24;
  --bv-card-hover: #252932;
  --bv-text: #e5e7eb;
  --bv-text-dim: #9ca3af;
  --bv-accent: #4f9eff;
  --bv-winner: #22c55e;
  --bv-line: #2a2f3a;
}
.card { fill: var(--bv-card); }
```

Host page override — wrap in a class:

```css
.light my-component {
  --bv-bg: #fff;
  --bv-card: #f8fafc;
  --bv-text: #111;
}
```

Always name them `--{component-prefix}-*` (e.g. `--bv-*` for bracket-view) so they don't collide with host variables.

---

## Interaction patterns worth borrowing

### Focus + dim (Google bracket UX)

When the user selects an item, dim everything else so the focus is unmissable. The composition that nails it:

```css
.root.has-focus .item:not(.focus) { opacity: 0.28; }
.item.focus {
  transform: scale(1.04);
  filter: drop-shadow(0 0 10px var(--accent-glow));
}
.item {
  transition: transform .45s cubic-bezier(.4, 0, .2, 1),
              opacity .35s ease,
              filter .35s ease;
}
```

Behavior: click empty area of an item to focus; click focused item again to unfocus. Subtle but powerful.

### Connectors light up as decisions propagate

If the component has edges/lines between items, light up the relevant edge when a decision is made. The chain effect (one card → line → next card lighting up) is what makes Google's bracket feel alive.

```js
// In render:
const isActive = !!match.winner;
svg += `<path class="connector ${isActive ? 'active' : ''}" d="..." />`;
```

```css
.connector { stroke: var(--bv-line); transition: stroke .5s ease; }
.connector.active { stroke: var(--bv-accent); }
```

### Smooth transforms

`cubic-bezier(.4, 0, .2, 1)` (Material standard) on transforms/opacity gives the right "responsive but not bouncy" feel. Avoid `ease-in-out` for hover transitions (too slow) and `ease-out` (too sharp).

---

## Verification with Playwright (the shadow-DOM gotcha)

`page.locator(...).click()` on elements inside Shadow DOM often fails because:
- SVG hit-testing races (decorative chrome intercepts — see Pitfall #1)
- Shadow boundary confuses Playwright's element-resolution algorithm

The Playwright error is verbose and looks scary: `<line x1="0" y1="28" x2="28" class="separator"> intercepts pointer events`. It's almost always Pitfall #1, not a real layout bug.

**Bypass pattern — dispatch the click directly from inside the page:**

```js
await page.evaluate(`
  (el) => {
    const target = el.shadowRoot.querySelector('g.team[data-team="a"]');
    target.dispatchEvent(new MouseEvent('click', { bubbles: true, composed: true }));
  }
`, elementHandle);
```

This skips pixel hit-testing entirely and verifies the *handler logic* — which is usually what you actually want to test.

**Verification matrix to run before declaring done:**

| Surface | Viewport | What to check |
|---|---|---|
| Desktop, initial render | 1280×900 | All scenarios render, no layout overflow |
| Desktop, after interaction | 1280×900 | Click → winner set, propagation correct |
| Desktop, focus state | 1280×900 | Focused item highlighted, others dimmed |
| Mobile | 390×844 | Horizontal scroll works, touch targets ≥ 36px |

Capture one screenshot per state (`full_page=True` for the whole demo). After `page.wait_for_timeout(500)` to let CSS transitions settle.

---

## Deploy — GitHub Pages, zero-build

For a single-file static component like this, GitHub Pages is the obvious host. No build step, no framework, just point Pages at the repo root.

```bash
# 1. Create repo (if not exists) + push
gh repo create sigco3111/my-component --public --source=. --remote=origin --push

# 2. Enable Pages on main branch, root path
gh api -X POST repos/sigco3111/my-component/pages \
  -f source[branch]=main -f source[path]=/

# 3. Wait for build (1-3 min, polling required — no notification)
sleep 30 && gh api repos/sigco3111/my-component/pages/builds/latest --jq '.status'

# 4. Verify
curl -sI https://sigco3111.github.io/my-component/ | head -1      # expect HTTP/2 200
curl -sI https://sigco3111.github.io/my-component/my-component.js | head -1   # expect content-type: application/javascript
```

**Critical: ES modules require correct MIME type.** GitHub Pages serves `.js` as `application/javascript` automatically — verified. (Some misconfigured hosts serve `text/plain`, and the browser refuses to execute ES module imports.)

**Don't add a `vercel.json`, `netlify.toml`, or GitHub Actions workflow** for a no-build static component. It just adds moving parts.

---

## Step-by-step workflow

1. **If the user gave a screenshot, decompose it FIRST** using the table above. If the structural pattern doesn't match what you'd otherwise build, surface that BEFORE coding (see "Visual reference reverse-engineering" section).
2. **Sketch the visual on paper or in a comment block** before coding — get the layout math (column widths, gaps, card dimensions) into one place as constants
3. **Author the component class** — constructor + `connectedCallback` + `attributeChangedCallback` (declare `observedAttributes`)
4. **Author `_css()`** returning a single `<style>` string (no `document.createElement('style')` — just a template literal)
5. **Author the SVG generator** — pure functions taking data + layout constants, returning SVG strings
6. **Wire events inside `_attachEvents()`** — call from `_render()` so listeners survive re-renders
7. **Build the demo HTML** with 2–3 scenarios: small (4), medium (16), large (32+). Add `controls-row` with `Random`/`Reset` buttons that call public API methods — instant UX validation
8. **Write the README** with: usage, public API table, events table, theming via CSS variables, embed snippet for React/Vue
9. **Verify with Playwright** — use the harness at `scripts/verify_component.py`. Captures 4 screenshots + reports any page errors
10. **Fix bugs found** — Pitfall #1 (pointer-events) is the #1 fix you'll make; Pitfall #2 (setData order) is #2
11. **Deploy** via the GitHub Pages recipe above
12. **Re-verify the live URL** with the same Playwright harness (just point at the production URL) — first deploy often surfaces ES-module MIME or path issues that local doesn't

---

## Reference example

`/Users/mac/work/bracket-view/` — single-elimination tournament bracket (~530 lines, 20KB):
- Click team to advance; click match body to focus
- Connectors light up as winners propagate
- Trophy marker appears beside final winner
- Programmatic + declarative API, 3 events, 8 CSS variables
- Full Playwright verification including the shadow-DOM dispatch bypass pattern
- Live: https://sigco3111.github.io/bracket-view/

**Use it as a template** — the architecture is general; only the SVG generator and CSS are domain-specific. See `templates/bracket-view.js` for the canonical version, and `references/google-bracket-ux.md` for the v2 structural breakdown if you're rebuilding it as a tabbed origami view (always-2-columns + tab nav).

---

## Support files

- `templates/bracket-view.js` — Canonical worked example (the full component, ~530 lines). Copy and modify the SVG generator + CSS for new components in this class.
- `scripts/verify_component.py` — Re-runnable Playwright verification harness. Captures 4 screenshots + reports any page errors. Run with `python3 scripts/verify_component.py <url> <selector>` instead of hand-typing Playwright each session. Use this to verify the **deployed** URL as well — same script, swap the URL.
- `references/google-bracket-ux.md` — Structural breakdown of Google Search's bracket card UX (origami always-2-columns + tab nav + match-card v2 with score/status/date). Read this if you're rebuilding bracket-view as v2, or any similar "current N → next N/2" visualization.
