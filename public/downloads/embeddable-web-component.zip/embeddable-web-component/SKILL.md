---
name: embeddable-web-component
description: Build reusable, themeable, zero-dependency interactive UI building blocks as Web Components (Custom Elements + Shadow DOM). Triggered when creating components intended to be embedded in multiple projects — bracket viewers, visualizers, form widgets, charts, pickers, animated SVG components, etc. Covers inline SVG rendering, pointer-events hierarchy pitfalls, the focus/dim UX pattern, declarative + programmatic API design, event conventions, themability via CSS custom properties, Playwright shadow-DOM verification patterns, GitHub Pages nobuild deploy, and how to reverse-engineer screenshot references structurally instead of aesthetically. Also covers multi-library showcase pages that put your build next to third-party imports and self-implementations on one GitHub Pages URL. Skip for one-off HTML pages (use creative/claude-design instead).
---

# Embeddable Interactive Web Components

When the deliverable is a single-file, zero-build, zero-dep interactive UI building block that drops into any web page (or framework) with one script tag, this is the pattern. The session that produced this skill — `/Users/mac/work/bracket-view/` — is the canonical worked example.

## When to use this skill

Trigger when the user wants:
- A reusable widget / visualization / form / picker / viewer to embed
- A component that works in vanilla HTML + React + Vue + Next.js with zero config
- A visual reference (Google bracket card, Figma mock, screenshot) to reverse-engineer into a reusable thing
- Mobile-friendly interactivity (touch, swipe, scroll-snap)
- **Evaluating whether to import a third-party widget vs build one** — see `references/cdn-third-party-widget-evaluation.md` for the 6-axis CDN-availability verification matrix and the four import shapes that work in single-file pages

**Do NOT use for** one-off HTML pages, throwaway demos, or server-coupled features. For those: `creative/claude-design` (one-off artifacts), `software-development/spike` (validate-before-build), or proper framework component libs (heavy reuse across one app).

## Core architecture — four layers

Every component in this pattern has exactly four layers. Don't skip any.

| Layer | Role | Implementation |
|---|---|---|
| **Custom Element** | Public tag name, public API | `class Foo extends HTMLElement` + `customElements.define('foo', Foo)` |
| **Shadow DOM** | Style isolation from host page | `this.attachShadow({ mode: 'open' })` |
| **Inline SVG** | All graphics | SVG string returned from a render function |
| **CSS custom properties** | Themability without poking inside shadow | `:host { --foo-* }` + `var(--foo-*)` in shadow CSS |

Bonus surface: a small **public API** (`setData`, `reset`, `randomFill`, `getState`) PLUS a **declarative attribute layer** (`<foo-comp attr="...">`) so the component is useful with zero JS.

## File layout

```
my-component/
├── my-component.js     # 300–700 lines, single ES module, ≤ 30KB
├── index.html          # demo with 2–3 usage scenarios
├── README.md           # usage, API, events, theming, embed instructions
└── .gitignore
```

No build step. No `package.json` needed. Single import: `<script type="module" src="./my-component.js"></script>`.

## Authoring checklist (run before committing)

- [ ] Component is a single `.js` file ≤ ~30KB
- [ ] All styles are inside Shadow DOM (no host-page leakage, no `:root` selectors)
- [ ] `:host` exposes ≥ 6 CSS custom properties for theming
- [ ] Has both declarative (`<comp attr="...">`) and programmatic (`comp.setData(...)`) APIs
- [ ] Emits ≥ 1 event with `{ bubbles: true, composed: true }` for parent integration
- [ ] Touch-friendly: tap targets ≥ 36px, no hover-only state
- [ ] Mobile: horizontal scroll OR vertical scroll-snap when content overflows
- [ ] Respects `@media (prefers-reduced-motion: reduce)`
- [ ] Sanitizes any user-provided string via HTML escape before injecting into SVG/HTML
- [ ] `_render()` re-attaches all event listeners (idempotent — don't `addEventListener` once in `connectedCallback` if you ever re-render)

---

## Visual reference reverse-engineering — when the user says "like this"

When the user shows a screenshot of another product and says "I want this", the difference between delivering something *inspired by* vs something that *matches* the structure is whether you actually decompose what they're seeing.

**Common user reaction when this goes wrong**: "예쁘기는 한데 내가 원하는 건 아냐" / "It looks pretty but it's not what I want". That sentence means you copied the **aesthetic** (colors, smoothness, roundness) but missed the **structural pattern** (how data flows, how the user navigates, what slots are first-class).

**Concrete decomposition checklist** — for any screenshot the user gives you, produce a table with these rows before writing any code:

| Question to answer from the image | Why it matters |
|---|---|
| How many **columns** are shown simultaneously? | Determines horizontal-scroll vs tabbed-zoom layout |
| Is there a **navigation layer** (tabs, chips, scroller)? | Determines whether the component owns nav or the host page does |
| What **information per card**? (date, status, score, team, score-arrows) | Determines the slot model — names are not enough |
| Are there **visual links** (lines, arrows, connectors)? | Determines whether the component has 2D structure or just a list |
| What happens at **boundaries** (last round, playoff)? | Determines whether you need a separate "playoff" / "third-place" rendering path |
| What's **first-class state** (live/scheduled/completed, winner/loser/tbd)? | Determines the data model — `winner: 'a'` is not the same as `score: { a: 2, b: 0, state: 'completed' }` |

For the Google Search bracket pattern specifically, see `references/google-bracket-ux.md`.

---

## Critical pitfalls — in priority order

### 1. SVG pointer-events hierarchy (the #1 trap)

This will bite you. By default, every `<g>` with `pointer-events: visiblePainted` (the SVG default) intercepts clicks on its rendered children. So:

```svg
<g class="match">
  <rect class="match-card"/>          <!-- intercepts -->
  <line class="separator"/>            <!-- also intercepts -->
  <g class="team"><rect/></g>          <!-- blocked above -->
</g>
```

A click on a `.team` `<rect>` is intercepted by the `.match-card` rect drawn on top. Result: nothing clicks correctly, no error, silent failure. Playwright reports it as `<line> intercepts pointer events` on every retry.

**Fix pattern** — three rules:

```css
/* 1. SVG root container does NOT receive pointer events */
.bracket-svg { pointer-events: none; }

/* 2. Only the interactive <g> groups (matches wrapper) opt back in */
.bracket-svg .matches,
.bracket-svg .matches > * { pointer-events: all; }

/* 3. Decorative chrome inside a match does NOT receive pointer events */
.match > rect,
.match > line,
.match > text.match-id { pointer-events: none; }

/* 4. Team <g> groups inside a match opt back in */
.team { pointer-events: visiblePainted; }
.team > text { pointer-events: none; }
```

The principle: **the SVG root container and decorative chrome should NOT receive pointer events**. Only the interactive groups should. Apply this hierarchy whenever you have nested clickable groups in SVG.

### 2. setData / mutate-before-render order

When wiring data updates + state propagation, call `setData(data)` BEFORE calling any propagation method that reads `this._data`:

```js
// WRONG — throws on first call
const data = this._generateFromTeams(teams, 'Title');
this._propagateWinner(0, 0);   // reads this._data.rounds[1] → null!
this.setData(data);

// RIGHT
const data = this._generateFromTeams(teams, 'Title');
this.setData(data);              // this._data = data
this._propagateWinner(0, 0);     // now this._data.rounds[1] exists
this._render();
```

### 3. setData must reset focus/selection state

When the user resets or swaps data, clear any focus/selection/highlight state — otherwise the focused match from the previous dataset "leaks" into the new one:

```js
setData(data) {
  this._data = data;
  this._focusedMatch = null;   // ← reset
  this._render();
}
```

### 4. CustomEvents from inside Shadow DOM need `composed: true`

Without it, the event won't cross the shadow boundary and host-page listeners will never hear it:

```js
this.dispatchEvent(new CustomEvent('match-decided', {
  detail: { round, match, winner },
  bubbles: true,
  composed: true,   // ← required, not optional
}));
```

### 5. HTML-escape every string before injecting into SVG

`shadowRoot.innerHTML = ... ${userInput} ...` will break the SVG (and XSS) if the input contains `<`, `>`, `&`, `"`, `'`. Always:

```js
_esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}
```

Apply to: team names, match IDs, titles, anything from outside the component.

### 6. Custom Element must be defined before the tag is parsed

If your HTML has `<my-comp>` before the `<script type="module">` that defines it, the browser silently treats the tag as `HTMLUnknownElement` — the constructor never runs.

**Fix:** put the import in `<head>`, or load it before any usage. Module scripts default to deferred execution so a `<script type="module" src="./my-comp.js">` in `<head>` works.

### 7. Round-label mapping for varying sizes

When labeling tournament rounds (or any positionally-varying context), use a single array + offset — no per-size branching:

```js
const labels = ['Round of 32', 'Round of 16', 'Quarterfinals', 'Semifinals', 'Final'];
const offset = Math.max(0, labels.length - numRounds);
const label = labels[offset + r];
```

Handles any power-of-two size (4/8/16/32/64) without conditionals.
### 8. Never attach event listeners in `connectedCallback` if `_render()` rewrites the DOM

If your `_render()` does `this.shadowRoot.innerHTML = '...'`, every `addEventListener` you added in `connectedCallback` is on nodes that no longer exist. Either:

- (a) Attach listeners inside `_render()` after `innerHTML =`, or
- (b) Use event delegation on `this.shadowRoot` (one listener, handles everything)

(a) is simpler for small components. (b) scales better.

### 9. Duplicate CSS rules for the same selector cause cascade confusion

If the same selector (e.g. `.bv-card`) appears twice in your shadow CSS with different `height` / `padding` values, only the **last** rule wins — but the first rule still parses and creates a property on `getMatchedCSSRules`-like debug views. When the rendered result doesn't match what you "just edited", check `document.styleSheets[shadowIdx].cssRules` for your selector — you may have an orphan duplicate from an earlier commit.

**Fix pattern**: when refactoring a card style, **delete the old rule entirely** in the same patch that adds the new one. Don't append-and-pray. A clean way to do this: search for the selector's closing `}` and replace through the next rule, not just the property values.

### 10. Mobile does NOT mean "hide content to fit it" — shrink the layout

**Repeated user pushback** (this exact mistake has been reverted at least 3 times across sessions): "오른쪽 카드를 완전히 없애 버렸네? 이건 내가 원하는게 아니야" / "I asked you to fix mobile, not remove the right column." / "구성 변경하지 말고, 세로 정렬만 낮춰서 정렬해줘."

When content overflows on a narrow viewport, the temptation is `display: none !important` for the secondary column. **Don't.** That throws away information density the user explicitly wants, and the next user message will be a complaint followed by reverting the hide. The user *will* catch it and the next round of corrections costs you.

The right pattern at `@media (max-width: 640px)`:
- Tighten font sizes (`12px` → `11px`, `13px` → `12px`)
- Shrink fixed columns (`28px` → `22px`, `16px` → `14px`)
- Reduce gaps (`gap: 6px` → `gap: 4px`)
- Keep ALL columns visible; just compact them
- If a single card slot still overflows, the user will tell you — that's their call to hide, not yours

**Diagnostic**: if a mobile session report says "왼쪽/오른쪽 같은 크기" or "왼쪽 카드만 보여" and the user replies negatively, your previous turn probably hid content. Walk the media-query history before shipping a "fix".

**Hard rules** (from repeated user pushback — treat these as non-negotiable):

1. When a column already exists in the desktop layout and the user has not explicitly asked to remove it, **never** add `display: none !important` to the `@media (max-width: 640px)` block to "make it fit". If the layout genuinely cannot be shrunk to fit, surface that to the user and let them decide. Do not silently delete visual structure.

2. When the user says "오른쪽 카드 정렬을 낮춰서 대진표선에 맞춰줘" or "align the right card to the bracket line", they mean **change the y-position of the right column to match the bracket's geometry**, NOT remove the right column. The right column is first-class — it stays, just shifted.

3. When the user says "구성은 이전과 같이" / "keep the same layout", **do not change the layout structure**. Only adjust the positioning or styling within the existing structure.

4. When the user says "내용을 좀더 풍부하게" / "make the content richer", they mean add detail to existing items, not restructure. (See Pitfall #11 for the score data shape that supports this.)

### 11. Score belongs in `match.scores[side]`, not `match[side].score`

The natural data shape when designing the model: `{ a: { name, score: 2 }, b: { name, score: 1 } }`. The shape the component actually needs: `{ a: { name }, b: { name }, scores: { a: 2, b: 1 } }`.

The reason: scores are **state**, not **identity**. A team object should be reusable across matches (winner of M1 = participant of M2). If `score` lives on the team, you can't reuse the same team object in two matches (or you have to reset it on every render). Keeping scores as a sibling of `a` / `b` makes the data model invariant under winner propagation.

**Symptom**: preview column shows `·` placeholder for already-decided matches. Cause: `match.scores` is empty but `match.a.score` has a value, and the render reads `match.scores[side]` not `match[side].score`. Fix the data shape at the source.

### 12. CSS Grid rows are 1-indexed — staggered alignment off-by-one is the most common bug

When using `grid-template-rows` for staggered layouts (e.g. a preview column where card i starts halfway between from card 2i and 2i+1), each card needs `grid-row` = its 1-indexed row position in the template, **not** a 0-indexed offset.

The classic mistake:

```js
// grid-template-rows: 53px 96px 116px 96px 53px;  // 5 rows: spacer|card|spacer|card|spacer
// I want card 0 to land on the first 96px track, card 1 on the second.

// WRONG (treats row 1 as the first card track)
card.style.gridRow = j * 2 + 1;   // j=0 → row 1 (which is the 53px spacer!) → top collapses to 0

// RIGHT (CSS Grid is 1-indexed; row 1 = first template row = the 53px spacer)
card.style.gridRow = j * 2 + 2;   // j=0 → row 2 (the first 96px track)
```

**Symptom that should make you suspicious**: card 0 sits at the column top (offsetTop=0) even though you set `grid-row: 1`. Card 1 happens to be at the right offset because its row number coincides with the right template track by accident (row 3 = second 96px track).

**Verify with `offsetTop` after `gridRowStart`**: the formula `expected_top = sum(gridTemplateRows[0..gridRowStart-2])` should hold. If it doesn't, you have an off-by-one in your row formula.

**The minimum recipe for a staggered preview column**:

```html
<!-- column = grid container with interleaved spacer / card rows -->
<div class="bv-col-next-preview"
     style="display: grid; grid-template-rows: 53px 96px 116px 96px 53px;">
  <article style="grid-row: 2; grid-column: 1;" ...>preview 0</article>
  <article style="grid-row: 4; grid-column: 1;" ...>preview 1</article>
</div>
```

```css
.bv-card-preview { align-self: start; justify-self: stretch; }
```

Without `align-self: start`, the card might stretch to fill the row's full height AND its parent's content area; without `grid-column: 1`, an auto-flow grid with one column is fine, but pinning is cheap insurance.

Each preview card gets `grid-row: i * 2 + 2` (1-indexed — see Pitfall #12 in SKILL.md), and the from column's plain flex `gap: GAP` arrangement provides the symmetric spacing. Don't try to fake this with absolute positioning or negative margins — connector lines need pixel-exact alignment and the math guarantees it.

### 14. `el.style.display = ''` does NOT beat a CSS rule — i18n page toggle pitfall

When the demo page (or any page surrounding the component) has a ko/en locale switch that toggles every text span via inline style, you'll be tempted to write:

```js
// WRONG
el.style.display = (matchesLocale) ? '' : 'none';
```

That fails silently. `el.style.display = ''` is equivalent to "no inline override" — the CSS rule `[data-i18n-show] { display: none }` still wins, and **every span on the page becomes invisible**. The page goes blank.

The reason: empty string assignment doesn't *unset* the inline style in a way that "resets to default"; it just sets the inline style's display property to empty. CSS specificity wins on the cascade step, and `[data-i18n-show]` is a real selector with non-zero specificity that still matches.

**Correct pattern** — set the explicit display value the element should have:

```js
// RIGHT
el.style.display = hit
  ? (tagIsBlock ? 'block' : 'inline')
  : 'none';
```

Better still: combine with a CSS rule that uses an attribute selector only as the *initial* fallback (hidden), and the JS sets the *positive* display value when toggling on:

```css
[data-i18n-show] { display: none; }   /* initial fallback for first paint */
```

```js
function applyLocale(loc) {
  document.body.setAttribute('data-locale', loc);
  document.querySelectorAll('[data-i18n-show]').forEach(el => {
    const hit = el.getAttribute('data-i18n-show') === loc;
    if (hit) {
      const tag = el.tagName.toLowerCase();
      const blockLike = ['div','p','li','h1','h2','h3','h4','h5','h6','section'].includes(tag);
      el.style.display = blockLike ? 'block' : 'inline';
      if (el.classList.contains('badge')) el.style.display = 'inline-block';
    } else {
      el.style.display = 'none';
    }
  });
}
```

**Symptom**: page renders correctly on first load, but after clicking the toggle button, *every* span becomes invisible. The `getComputedStyle(el).display` returns `'none'` even though your JS just set the inline style. Check `el.style.cssText` — if it's empty, you hit this pitfall.

### 15. Page-level i18n should be inline-style based, not CSS-attribute-selector based

Related to #14. The temptation when adding a ko/en toggle is:

```css
body[data-locale="ko"] .en-only { display: none; }
body[data-locale="en"] .ko-only { display: none; }
```

This works for **two-language elements** but breaks when:
- The same element has both `.ko` and `.en` classes for fallback / searchability
- You want CSS-only first-paint hiding for the non-default locale (avoiding flash of mixed text)
- You want the JS toggle to work even if the CSS hasn't loaded yet

The pattern that survives all three: every translatable string lives inside **two parallel spans** (`<span class="ko" data-i18n-show="ko">한국어</span><span class="en" data-i18n-show="en">English</span>`), all hidden by default via CSS, then the JS sets the inline display value of the matching span to `block`/`inline` based on the current locale.

This decouples translation from the parent layout. A page can have 50 translatable strings and only need one CSS rule (`[data-i18n-show] { display: none }`) plus one JS function (`applyLocale(loc)`).

Don't try to do it with `:not()` selectors — they always include the "default" locale incorrectly. Just hide everything explicitly and re-show what matches.

## Staggered preview / next-round column (without a separate SVG)

Sometimes the "preview" column isn't drawn as connector lines — it's a real column of cards that sit on the *midpoint between two from cards*. The pixel-exact alignment still matters because the connector paths from the from-column converge on the preview cards' top and bottom centerlines.

The recipe:

```html
<div class="bv-col-next-preview"
     style="display: grid;
            grid-template-rows: 53px 96px 116px 96px 53px;">
  <article style="grid-row: 2; grid-column: 1;" ...>preview 0</article>
  <article style="grid-row: 4; grid-column: 1;" ...>preview 1</article>
</div>
```

```css
.bv-col-next-preview .bv-card-preview {
  align-self: start;
  justify-self: stretch;
}
```

The math (where `UNIT = CARD_H + GAP`, `OFFSET = UNIT / 2`, `STRIDE = 2 * UNIT`):

- row 0: `OFFSET` — initial spacer so preview 0's centerline lands between from[0] and from[1]
- row 1: `CARD_H` — preview 0
- row 2: `STRIDE - CARD_H` — gap between preview 0 and preview 1
- row 3: `CARD_H` — preview 1
- row 4: `UNIT - OFFSET` — final trailer so the preview column's total height equals the from-column's

Card `i` lives at `grid-row: i * 2 + 2` (1-indexed — see Pitfall #12 in SKILL.md).

**Verification**: measure `offsetTop` of every preview card and check it satisfies
`sum(gridTemplateRows[0..gridRowStart-2])`. If preview 0 has `offsetTop: 0` even
though you set `grid-row: 1` or `2`, you have the 1-indexed off-by-one.

## Theming via CSS custom properties

Expose design tokens on `:host` so the host page can re-theme without touching inside:

```css
:host {
  --bv-bg: #0f1115;
  --bv-card: #1a1d24;
  --bv-card-hover: #252932;
  --bv-text: #e5e7eb;
  --bv-text-dim: #9ca3af;
  --bv-accent: #4f9eff;
  --bv-winner: #22c55e;
  --bv-line: #2a2f3a;
}
.card { fill: var(--bv-card); }
```

Host page override — wrap in a class:

```css
.light my-component {
  --bv-bg: #fff;
  --bv-card: #f8fafc;
  --bv-text: #111;
}
```

Always name them `--{component-prefix}-*` (e.g. `--bv-*` for bracket-view) so they don't collide with host variables.

---

## Interaction patterns worth borrowing

### Focus + dim (Google bracket UX)

When the user selects an item, dim everything else so the focus is unmissable. The composition that nails it:

```css
.root.has-focus .item:not(.focus) { opacity: 0.28; }
.item.focus {
  transform: scale(1.04);
  filter: drop-shadow(0 0 10px var(--accent-glow));
}
.item {
  transition: transform .45s cubic-bezier(.4, 0, .2, 1),
              opacity .35s ease,
              filter .35s ease;
}
```

Behavior: click empty area of an item to focus; click focused item again to unfocus. Subtle but powerful.

### Connectors light up as decisions propagate

If the component has edges/lines between items, light up the relevant edge when a decision is made. The chain effect (one card → line → next card lighting up) is what makes Google's bracket feel alive.

```js
// In render:
const isActive = !!match.winner;
svg += `<path class="connector ${isActive ? 'active' : ''}" d="..." />`;
```

```css
.connector { stroke: var(--bv-line); transition: stroke .5s ease; }
.connector.active { stroke: var(--bv-accent); }
```

### Smooth transforms

`cubic-bezier(.4, 0, .2, 1)` (Material standard) on transforms/opacity gives the right "responsive but not bouncy" feel. Avoid `ease-in-out` for hover transitions (too slow) and `ease-out` (too sharp).

---

## Verification with Playwright (the shadow-DOM gotcha)

`page.locator(...).click()` on elements inside Shadow DOM often fails because:
- SVG hit-testing races (decorative chrome intercepts — see Pitfall #1)
- Shadow boundary confuses Playwright's element-resolution algorithm

The Playwright error is verbose and looks scary: `<line x1="0" y1="28" x2="28" class="separator"> intercepts pointer events`. It's almost always Pitfall #1, not a real layout bug.

**Bypass pattern — dispatch the click directly from inside the page:**

```js
await page.evaluate(`
  (el) => {
    const target = el.shadowRoot.querySelector('g.team[data-team="a"]');
    target.dispatchEvent(new MouseEvent('click', { bubbles: true, composed: true }));
  }
`, elementHandle);
```

This skips pixel hit-testing entirely and verifies the *handler logic* — which is usually what you actually want to test.

**Verification matrix to run before declaring done:**

| Surface | Viewport | What to check |
|---|---|---|
| Desktop, initial render | 1280×900 | All scenarios render, no layout overflow |
| Desktop, after interaction | 1280×900 | Click → winner set, propagation correct |
| Desktop, focus state | 1280×900 | Focused item highlighted, others dimmed |
| Mobile | 390×844 | Horizontal scroll works, touch targets ≥ 36px |

Capture one screenshot per state (`full_page=True` for the whole demo). After `page.wait_for_timeout(500)` to let CSS transitions settle.

---

## Deploy — GitHub Pages, zero-build

For a single-file static component like this, GitHub Pages is the obvious host. No build step, no framework, just point Pages at the repo root.

```bash
# 1. Create repo (if not exists) + push
gh repo create sigco3111/my-component --public --source=. --remote=origin --push

# 2. Enable Pages on main branch, root path
gh api -X POST repos/sigco3111/my-component/pages \
  -f source[branch]=main -f source[path]=/

# 3. Wait for build (1-3 min, polling required — no notification)
sleep 30 && gh api repos/sigco3111/my-component/pages/builds/latest --jq '.status'

# 4. Verify
curl -sI https://sigco3111.github.io/my-component/ | head -1      # expect HTTP/2 200
curl -sI https://sigco3111.github.io/my-component/my-component.js | head -1   # expect content-type: application/javascript
```

**Critical: ES modules require correct MIME type.** GitHub Pages serves `.js` as `application/javascript` automatically — verified. (Some misconfigured hosts serve `text/plain`, and the browser refuses to execute ES module imports.)

**Don't add a `vercel.json`, `netlify.toml`, or GitHub Actions workflow** for a no-build static component. It just adds moving parts.

---

## Step-by-step workflow

1. **If the user gave a screenshot, decompose it FIRST** using the table above. If the structural pattern doesn't match what you'd otherwise build, surface that BEFORE coding (see "Visual reference reverse-engineering" section).
2. **Sketch the visual on paper or in a comment block** before coding — get the layout math (column widths, gaps, card dimensions) into one place as constants
3. **Author the component class** — constructor + `connectedCallback` + `attributeChangedCallback` (declare `observedAttributes`)
4. **Author `_css()`** returning a single `<style>` string (no `document.createElement('style')` — just a template literal)
5. **Author the SVG generator** — pure functions taking data + layout constants, returning SVG strings
6. **Wire events inside `_attachEvents()`** — call from `_render()` so listeners survive re-renders
7. **Build the demo HTML** with 2–3 scenarios: small (4), medium (16), large (32+). Add `controls-row` with `Random`/`Reset` buttons that call public API methods — instant UX validation
8. **Write the README** with: usage, public API table, events table, theming via CSS variables, embed snippet for React/Vue
9. **Verify with Playwright** — use the harness at `scripts/verify_component.py`. Captures 4 screenshots + reports any page errors
10. **Fix bugs found** — Pitfall #1 (pointer-events) is the #1 fix you'll make; Pitfall #2 (setData order) is #2
11. **Deploy** via the GitHub Pages recipe above
12. **Re-verify the live URL** with the same Playwright harness (just point at the production URL) — first deploy often surfaces ES-module MIME or path issues that local doesn't

- `references/google-bracket-ux.md` — Structural breakdown of Google Search's bracket card UX (origami always-2-columns + tab nav + match-card v2 with score/status/date). Read this if you're rebuilding bracket-view as v2, or any similar "current N → next N/2" visualization.
13. **Re-verify the live URL** with the same Playwright harness (just point at the production URL) — first deploy often surfaces ES-module MIME or path issues that local doesn't

## Importing third-party widgets instead of building (no-build)

When the user already has a `<bracket-view>`-style page and asks "is there an off-the-shelf library I can just `<script>` in?", this skill already covers the *building* path — but the *evaluation* side is its own recipe. Load `references/cdn-third-party-widget-evaluation.md` for:

- A **6-axis verification matrix** (npm exists → jsDelivr resolves → dist files present → UMD/ESM build exists → esm.sh transform works → license/stars/activity OK)
- The **four import shapes** that work in a single-file page: plain `<script>` + global namespace, WebComponent auto-registered tag, ES module `import`, ESM with peer-dep pinning
- Seven pitfalls specific to CDN-imported widgets (empty dist, CJS-only, stale peer-deps, styled-components v4, double-register, jsDelivr rate-limit, star-count ≠ quality)
- A snapshot-validated table of single-elimination bracket libraries (eight candidates with stars/license/import shape/reason) plus live HTTP-200 ESM/script URLs

Use the matrix as the first-pass filter before recommending anything. A library with 1699 stars (e.g. `evroon/bracket`) may be AGPL-licensed full-stack infra and not a reusable widget — the matrix catches that in axis 6.

## Reference example

`/Users/mac/work/bracket-view/` — single-elimination tournament bracket
- Click team to advance; click match body to focus
- Connectors light up as winners propagate
- Trophy marker appears beside final winner
- Programmatic + declarative API, 3 events, 8 CSS variables
- Full Playwright verification including the shadow-DOM dispatch bypass pattern
- Live: https://sigco3111.github.io/bracket-view/

**Use it as a template** — the architecture is general; only the SVG generator and CSS are domain-specific. See `templates/bracket-view.js` for the canonical version, and `references/google-bracket-ux.md` for the v2 structural breakdown if you're rebuilding it as a tabbed origami view (always-2-columns + tab nav).

## When the user wants a "library showcase" — actual imports, not GitHub redirects

A common request pattern: "make a page that demos multiple libraries side by side". The user does NOT want a card grid where each card just links to the library's GitHub repo — that defeats the point. **They want each library actually running on the page.**

```js
// WRONG — each card just has a "Source on GitHub" link, the library never runs
<a href="https://github.com/X/library">Source on GitHub ↗</a>

// RIGHT — library is imported as a script or ESM and renders inside the card
<script src="https://cdn.jsdelivr.net/npm/<lib>@<ver>/dist/x.min.js"></script>
<script>window.X.someApi('#card-mount', data);</script>
```

If the user says something like "각각의 라이브러리가 직접 동작했으면 좋겠다 / 내가 원하는 건 라이브러리로 직접 동작하는 것 / not just a link to GitHub" — they're telling you the import is the point. See `references/showcase-pages.md` for the full pattern (data sharing, mount points, the "library self-fail" status card when an import breaks, etc.).

If a library can't be imported via CDN (no UMD, no ESM, only source on GitHub), write a self-implementation in `bracket-samples.js` — see Pitfall S1 in `references/showcase-pages.md`. The user prefers a ~50-line vanilla JS approximation over an empty card with a GitHub link.

---

## Support files

- `templates/bracket-view.js` — Canonical worked example (the full component, ~530 lines). Copy and modify the SVG generator + CSS for new components in this class.
- `scripts/verify_component.py` — Re-runnable Playwright verification harness. Captures 4 screenshots + reports any page errors. Run with `python3 scripts/verify_component.py <url> <selector>` instead of hand-typing Playwright each session. Use this to verify the **deployed** URL as well — same script, swap the URL.
- `references/google-bracket-ux.md` — Structural breakdown of Google Search's bracket card UX (origami always-2-columns + tab nav + match-card v2 with score/status/date). Read this if you're rebuilding bracket-view as v2, or any similar "current N → next N/2" visualization.
- `references/svg-connector-lines.md` — M-curve / L-shape connector math (viewBox, `preserveAspectRatio="none"` pitfalls, `UNIT = CARD_H + GAP` constants, why y-coordinates come from math not DOM measurements).
- `references/cdn-third-party-widget-evaluation.md` — The 6-axis CDN-availability verification matrix, the four import shapes, snapshot-validated library list with live HTTP-200 URLs.
- `references/korean-localization.md` — KO_LABELS table + josa (을/를) Unicode-math recipe + status/button label tables. Load when the user wants the component's UI in Korean.
- `references/showcase-pages.md` — Multi-library showcase page pattern (own build + CDN imports + self-implementations on one GitHub Pages URL with shared sample data and ko/en toggle). Load when the user wants to compare their component to third-party libraries on a single page.
