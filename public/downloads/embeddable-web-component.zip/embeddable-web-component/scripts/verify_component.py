#!/usr/bin/env python3
"""
Verification harness for embeddable Web Components.

Usage:
    # 1. Start your component dev server (e.g. python3 -m http.server 8765)
    # 2. python3 verify_component.py <url> <component-selector>

Defaults: http://127.0.0.1:8765/ <bracket-view>

Captures 4 screenshots:
    /tmp/component-desktop-full.png   (initial render)
    /tmp/component-interact.png       (after dispatchEvent on first interactive item)
    /tmp/component-focus.png          (after dispatchEvent on first card body)
    /tmp/component-mobile.png         (390x844 viewport)

Pixel-level clicks inside Shadow DOM often fail (decorative chrome intercepts).
We bypass hit-testing via dispatchEvent so we test the *handler logic*.
"""
import sys
from playwright.sync_api import sync_playwright

URL = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8765/"
SELECTOR = sys.argv[2] if len(sys.argv) > 2 else "bracket-view"

def run():
    with sync_playwright() as p:
        browser = p.chromium.launch()

        # ── Desktop ──
        ctx = browser.new_context(viewport={"width": 1280, "height": 900})
        page = ctx.new_page()
        errors = []
        page.on("pageerror", lambda e: errors.append(str(e)))
        page.on("console", lambda m: errors.append(f"[{m.type}] {m.text}") if m.type == "error" else None)

        resp = page.goto(URL, wait_until="networkidle")
        print(f"HTTP {resp.status}")

        page.wait_for_function(f"document.querySelectorAll('{SELECTOR}').length >= 1", timeout=5000)
        page.wait_for_timeout(500)

        page.screenshot(path="/tmp/component-desktop-full.png", full_page=True)
        print("✓ /tmp/component-desktop-full.png (initial)")

        # Interaction test — click first team-row of first match
        first = page.locator(SELECTOR).first
        first.evaluate("""
          (el) => {
            const match = el.shadowRoot.querySelector('[data-round="0"][data-match="0"], .match:first-child, .item:first-child');
            if (!match) return;
            const team = match.querySelector('[data-team], .interactive, .row');
            if (team) {
              team.dispatchEvent(new MouseEvent('click', { bubbles: true, composed: true }));
            } else {
              match.dispatchEvent(new MouseEvent('click', { bubbles: true, composed: true }));
            }
          }
        """)
        page.wait_for_timeout(500)
        first.screenshot(path="/tmp/component-interact.png")
        print("✓ /tmp/component-interact.png (after first interaction)")

        # Focus test — dispatch click on card surface (not on a row)
        first.evaluate("""
          (el) => {
            const match = el.shadowRoot.querySelector('[data-round="0"][data-match="0"], .match:first-child, .item:first-child');
            if (!match) return;
            const card = match.querySelector('.match-card, .card, rect:first-child') || match;
            card.dispatchEvent(new MouseEvent('click', { bubbles: true, composed: true }));
          }
        """)
        page.wait_for_timeout(900)
        first.screenshot(path="/tmp/component-focus.png")
        print("✓ /tmp/component-focus.png (focus state)")

        ctx.close()

        # ── Mobile ──
        ctx_m = browser.new_context(viewport={"width": 390, "height": 844}, device_scale_factor=2)
        m = ctx_m.new_page()
        m.goto(URL, wait_until="networkidle")
        m.wait_for_timeout(700)
        m.screenshot(path="/tmp/component-mobile.png", full_page=True)
        print("✓ /tmp/component-mobile.png (mobile 390x844)")
        ctx_m.close()

        browser.close()

    if errors:
        print(f"\n⚠ {len(errors)} error(s) detected:")
        for e in errors:
            print(f"  • {e}")
        return 1
    print("\n✓ All screenshots captured, no errors")
    return 0

if __name__ == "__main__":
    sys.exit(run())
