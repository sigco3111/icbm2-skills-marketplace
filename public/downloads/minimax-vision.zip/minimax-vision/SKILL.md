---
name: minimax-vision
description: "MiniMax Coding Plan MCP의 understand_image로 이미지 분석 — OpenRouter 402 에러 시 기본으로 사용"
tags: [vision, minimax, mcp, image-analysis, coding-plan]
---

# 이미지 분석 (MiniMax MCP)

> OpenRouter 기반 `vision_analyze`가 402 에러(크레딧 부족)를返す場合, 본 스킬의 `mcp_minimax_understand_image`를 사용.

## 현재 방식

**MiniMax Coding Plan MCP** 서버가 이미 Hermes에 등록되어 있음.

```
mcp_minimax_understand_image(image_source="...", prompt="...")
```

- **크레딧:** Coding Plan 구독자 무료 (402 에러 없음)
- **모델:** MiniMax-VL (내장)
- **설정:** `~/.hermes/scripts/minimax-mcp-wrapper.sh` 참고

## 사용 방법

### 기본 호출

```
mcp_minimax_understand_image(
  image_source="/path/to/image.jpg",  # 로컬 파일 또는 HTTP URL
  prompt="이 이미지를 한국어로 분석해줘"
)
```

### 파라미터

| 파라미터 | 타입 | 필수 | 설명 |
|----------|------|------|------|
| `image_source` | string | ✅ | 이미지 경로 또는 URL |
| `prompt` | string | ✅ | 분석용 프롬프트 |

### 지원 포맷

- **로컬 파일:** 절대경로, 상대경로 모두 가능
- **HTTP/HTTPS URL:** 원격 이미지 URL
- **지원:** JPEG, PNG, WebP
- **不支持:** PDF, GIF, PSD, SVG

### 사용 예시

#### 1. 텔레그램/메시징

```
mcp_minimax_understand_image를 이용해서 이 이미지를 분석해줘
```

#### 2. 로컬 파일

```
mcp_minimax_understand_image(image_source="/Users/hjshin/photo.png", prompt="이미지 설명해줘")
```

#### 3. URL 이미지

```
mcp_minimax_understand_image(image_source="https://example.com/image.jpg", prompt="이 이미지의 주요 내용을 요약해줘")
```

## vision_analyzeとの比較

| 항목 | `vision_analyze` | `mcp_minimax_understand_image` |
|------|-----------------|-------------------------------|
| **provider** | OpenRouter | MiniMax MCP |
| **크레딧** | 유료 (402 에러 가능) | 무료 (Coding Plan) |
| **파라미터** | `image_url`, `question` | `image_source`, `prompt` |
| **속도** | 보통 | 보통 |
| **품질** | 좋음 | 좋음 |

## 설정 확인

```bash
# MCP 서버 등록 상태 확인
cat ~/.hermes/config.yaml | grep -A5 "mcp_servers:"

# 미니맥스 API 키 확인
cat ~/.hermes/secrets/minimax.env
```

## 에러 상황

| 에러 | 원인 | 해결 |
|------|------|------|
| `MINIMAX_API_KEY environment variable is required` | API 키 미설정 | `~/.hermes/secrets/minimax.env` 확인 |
| `mcp_minimax_understand_image not found` | MCP 서버未起動 | Hermes gateway 재시작 |
| 402/크레딧 에러 | OpenRouter 문제 | 본 스킬의 MCP 도구 사용 |

## 호출 로그 확인

```bash
tail -20 ~/.hermes/logs/agent.log | grep -i "mcp_minimax\|minimax.*understand"
```
