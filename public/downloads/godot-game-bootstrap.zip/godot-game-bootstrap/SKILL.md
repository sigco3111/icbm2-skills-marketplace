---
name: godot-game-bootstrap
description: Godot 4로 새 게임 프로젝트를 부트스트랩할 때 사용 — 자산 풀(특히 game-assets-pool) 심볼릭 링크 연결 + 멀티플랫폼 export presets (Web/macOS/Windows/Linux) + Web 배포 (Vercel/Cloudflare 둘 다) + 자동 진행·결정 큐 autoload 골격 + lazy fetch (Vercel 100MB 한계 우회)까지 한 번에. "Godot 게임 만들어줘", "Godot으로 X 만들기", "이 자산으로 게임 부트스트랩", "Vercel로 게임 배포", "Godot Web export", "lazy fetch 게임", "Cloudflare Pages 게임", "Godot 검은 화면 부팅 실패" 같은 요청에 발동.
category: devops
---

# Godot 4 Game Bootstrap

풀에서 자산을 끌어와 Godot 4 게임 프로젝트를 만든다. **풀은 submodule로 흡수하지 않고 `tools/setup-assets.sh`로 카테고리별 필터링 후 심볼릭 링크**만 만들어 디스크/중복 없이 사용. 자동 진행 + 결정 큐는 autoload 골격으로 제공하므로 즉시 게임 메카닉 코드에 집중 가능.

## 호스팅 결정 (lazy fetch 채택으로 Vercel 무료 + 200~500MB 자산 우회)

이전에는 Godot 4 Web export 시 `index.pck`가 200MB 넘어서 Vercel 무료 한계(파일당 100MB)에 막혔음. **2026-07 검증 결과**: `assets/*/.gdignore` + jsDelivr lazy fetch 패턴으로 **Vercel 무료 유지 + 228MB 자산 그대로 호스팅** 가능. 4가지 옵션 비교는 아래 "🔄 호스팅 결정" 섹션 참고.

## 언제 쓰나

- game-assets-pool 같은 자산 풀에서 **특정 게임용 라인업**만 골라 게임 프로젝트에 연결할 때
- Godot 4 데스크탑 + **Web Export를 Vercel/Cloudflare에 배포**할 때 (lazy fetch로 Vercel 무료 가능)
- **자동 진행(위임 모드) + 결정 큐(critical 사건 정지) + 영속 저장(JSON/IndexedDB)** 게임 메카닉을 처음부터 짤 때
- 멀티플랫폼 export preset을 한 번에 셋업할 때
- 자산 라이선스 표기 (CC0/CC-BY-4.0) 구조를 처음부터 정리할 때
- **Web 빌드 결과가 브라우저에서 검은 화면으로 부팅 안 될 때** — SW 비활성화 / 디버그 pane 진단 (2026-07-15 last-banner 실전)

## 핵심 디자인 원칙

| 원칙 | 이유 |
|---|---|
| **풀을 submodule로 흡수 X, 심볼릭 링크로만** | 풀은 큐레이터 저장소 안에서 자체 진화. 게임 프로젝트는 카테고리 필터링만 필요한데 submodule로 받으면 쓸데없는 데이터까지 다 옴. |
| **autoload 5종 표준 골격** | GameManager(상태) · TimeManager(자동 진행 시계) · DecisionQueue(임시정지 결정) · SaveManager(JSON/IndexedDB 영속화) · AssetRegistry(카테고리 매니페스트 + lazy fetch) |
| **Web export = PWA + COOP/COEP 헤더 필수** | Godot 4의 SharedArrayBuffer/Threading 활성화 요구사항 → Vercel `headers`에 3개 헤더 세팅 |
| **lazy fetch 패턴으로 Vercel 무료 사용** | `assets/*/.gdignore` (import 차단, git 추적 유지) + jsDelivr CDN 런타임 fetch + user://persistent/assets/ 캐시. pck은 ~수백 KB로 줄어듦. |
| **자산 라이선스는 코드(코드 영역)와 분리** | GPL 게임(Wesnoth)의 에셋은 별도 CC-BY-4.0. 게임 본 프로젝트는 에셋만 사용하므로 GPL 소스 공개 의무 없음. |
| **P 키로 자동 진행 토글 (CRITICAL 결정 시 자동 정지)** | "사용자가 위임하면 자동으로 진행되고, 언제든지 다시 진입" 선호 — 사용자 진입 시 결정 큐 모달 노출. |
| **결정 큐는 우선순위 정렬 + CRITICAL 임시정지 신호** | MEDIUM 결정은 큐에 쌓이기만, CRITICAL이면 GameManager가 즉시 DECISION_PENDING으로 전이 |
| **저장은 `user://` (데스크탑) / IndexedDB (Web) 양쪽 호환** | Godot Web export는 `user://`를 IndexedDB에 자동 매핑 → 데스크탑/Web 동일 코드 |
| **build/web/ 만 .gitignore 예외** | lazy fetch 채택 시 build/web/도 git 추적 (Vercel outputDirectory와 직접 연결). 나머지 build/*는 ignore. |

## 표준 디렉터리 레이아웃

```
game-name/
├── project.godot                # Godot 4 프로젝트 정의 + 5개 autoload 등록
├── export_presets.cfg           # Web/macOS/Windows/Linux 4종 preset (루트 위치 필수)
├── vercel.json                  # COOP/COEP/SW 헤더 (Vercel 배포 시)
├── wrangler.toml                # Cloudflare Pages 빌드 설정 (선택)
├── _headers                     # Cloudflare Pages Cross-Origin 헤더 (선택)
├── asset_host.json              # lazy fetch용 매니페스트 (CDN URL + 카테고리별 사이즈)
├── .gitignore                   # .godot/ + build/* (단, build/web/ 예외)
├── README.md                    # 컨셉/자산/빠른시작/라이선스
├── docs/CREDITS.md              # 라이선스별 표기 (CC0/CC-BY-4.0)
├── autoload/                    # *res://autoload/*.gd 싱글턴
│   ├── game_manager.gd          # 상태머신 (BOOT/MENU/PLAYING/PAUSED/DECISION_PENDING/COMBAT/GAME_OVER)
│   ├── time_manager.gd          # 1초 = 게임 내 X시간 자동 진행
│   ├── decision_queue.gd        # 우선순위별 큐 + CRITICAL → 일시정지
│   ├── save_manager.gd          # user://save_*.json + 자동 저장 (IndexedDB 호환)
│   └── asset_registry.gd        # 매니페스트 로드 + lazy fetch (CDN → user://persistent/assets/)
├── scripts/                     # .gd 게임 스크립트
├── scenes/                      # .tscn 메인/서브 씬
├── assets/                      # 심볼릭 링크로 연결된 풀 + .gdignore (lazy fetch용)
│   ├── .gdignore                # Godot import 차단, git 추적은 유지
│   ├── heroes/                  # KayKit Adventurers glb
│   ├── enemies/                 # KayKit Skeletons glb
│   ├── props/                   # KayKit Dungeon glb
│   ├── units/{faction}/         # Wesnoth PNG base 포즈
│   ├── portraits/{faction}/     # Wesnoth webp
│   └── audio/{music,sfx}/       # Wesnoth ogg
├── tools/
│   ├── setup-assets.sh          # 풀 → 게임 심볼릭 링크 멱등 스크립트
│   ├── build.sh                 # 멀티플랫폼 빌드 (web/mac/windows/linux/all)
│   ├── gen-asset-manifest.sh    # 풀 → asset_host.json 자동 생성 (lazy fetch 매니페스트)
│   ├── disable-service-worker.sh  # Godot 4 Web export PWA SW 비활성화 (post-build, 검은 화면 함정 회피)
│   └── inject-debug-pane.sh     # index.html에 런타임 진단 pane 자동 주입 (원격 사용자 디버깅)
└── build/                       # .gitignore (단, build/web/은 추적 — Vercel이 직접 사용)
```

## 빠른 시작 절차

1. **디렉터리 + 5종 autoload 골격** — `project.godot` + `autoload/*.gd` 작성. 헤드리스 부팅으로 검증.
2. **자산 풀 스크립트 작성** — `tools/setup-assets.sh`가 idempotent. 카테고리별 find + 필터링 + 링크.
3. **Godot import** — `godot --headless --import` 1회 (1,000+ 자산도 1~2분).
4. **export presets** — `export_presets.cfg` (Web + macOS + Windows + Linux). **루트 디렉터리에 둘 것** (서브폴더 X).
5. **vercel.json + vercel CLI** — `vercel.json` 헤더 + `vercel --prod --archive=tgz` (5000 requests 한도 우회).
6. **Web 빌드 후 SW 비활성화 + 디버그 pane 자동 주입** — `bash tools/build.sh web` 한 번이면 내부에서 둘 다 자동 실행.
7. **lazy fetch 채택 시** — `assets/*/.gdignore` 생성 + `gen-asset-manifest.sh` 실행 + AssetRegistry lazy fetch 함수.
8. **README + CREDITS.md** — 자동 생성 가능.

## 함정 (반드시 숙지)

### Web export 전용
- **COOP/COEP 헤더 누락 = 첫 로드 멈춤**. `Cross-Origin-Opener-Policy: same-origin` + `Cross-Origin-Embedder-Policy: require-corp` + `Cross-Origin-Resource-Policy: same-origin`. Vercel `vercel.json` `headers` 배열로.
- **SharedArrayBuffer를 사용하려면 wasm threading 활성화**. export preset에서 `variant/thread_support=true` + `variant/wasm_threads=true`. 단, threading 끄면 COEP 의존성이 떨어져 헤더 단순화 + 환경 호환성 ↑.
- **`.wasm`/`.pck`/`.js` 캐시 헤더는 1년 immutable**. Service Worker는 `no-cache`.
- **PWA 활성화 시 `progressive_web_app/enabled=true` + icon 144/180/512 PNG 필요**. 없으면 기본 아이콘.
- **`.import` 파일(자동 생성)을 다른 폴더로 옮기지 말 것** — Godot이 import 단계마다 경로 추적함. 옮기면 깨짐.
- **headless launch 전 GDScript parse 검증**: `godot --headless --quit-after 200` 1회 실행 후 Error 줄 없으면 빌드 진행.
- **vercel.json은 vercel 스키마 필드 외 추가 속성 (`_comment`) 거부** → plain JSON으로만.

### Web export — PWA Service Worker 비활성화 함정 (2026-07-15 last-banner 실전)

**증상**: 사용자 브라우저에서 검은 화면 + Godot 로고만. 콘솔에 `Service worker already exists` 또는 `Unexpected token 'else'`. 새로고침해도 회복 안 됨.

**원인**: `progressive_web_app/enabled=false`로 설정해도 **Godot 4.7 Web export는 여전히** `index.service.worker.js` 파일 + `index.html`의 SW 등록 if-else 블록을 생성. 첫 build 후 reload 시 `Service worker already exists` 에러로 무한 reload에 빠지거나, `crossOriginIsolated=false` 환경에서 missing features 분기 진입 시 **else가 단독 구문이 되어 `SyntaxError: Unexpected token 'else'`**.

`vercel.json` 헤더 / `progressive_web_app.enabled` 어디서도 못 막음. **빌드 후 HTML post-processing으로 SW 자체를 no-op 처리**하는 것이 유일한 해결.

**Fix 패턴 — `templates/disable-service-worker.sh.tpl`**:
1. `index.service.worker.js` 파일 삭제
2. `index.offline.html` 삭제 (SW 의존)
3. `GODOT_CONFIG.serviceWorker = ""` 로 패치
4. **핵심**: SW if-else 블록을 `if (false) { /* SW DISABLED */ } else { ... }` 로 교체. **단순 주석(//) 절대 불가** — else가 매칭할 if 잃어 SyntaxError.

```python
# 핵심 regex — else를 보존해야 if-else 문법 유지
pattern = re.compile(
    r"if \(GODOT_CONFIG\['serviceWorker'\] && GODOT_CONFIG\['ensureCrossOriginIsolationHeaders'\] && 'serviceWorker' in navigator\) \{[\s\S]*?\}\s+else\s*\{",
    re.MULTILINE
)
m = pattern.search(html)
new_html = (
    html[:m.start()]
    + "if (false) { /* SW DISABLED */ } else {"
    + html[m.end():]
)
```

`bash tools/disable-service-worker.sh build/web` 한 줄로 처리. 빌드 파이프라인(`tools/build.sh web`)에 포함 권장.

### Web export — 검은 화면 진단 워크플로 (2026-07-15)

원격 사용자 브라우저에서 **검은 화면만 보이는 상태**를 진단할 때 **puppeteer 헤드리스는 한계**가 있음 (`--use-gl=swiftshader`도 WebGL2 software rendering 미지원 → 게임 자체 부팅 안 됨). 헤드리스에서 게임 부팅 안 된다고 사용자 환경도 동일하지 **않음**.

**정석 워크플로**:
1. **로컬 헤드리스 부팅** — `godot --headless --quit-after 200` (autoload parse 에러 잡기)
2. **`build/web/` curl 헤더 검증** — COOP/COEP/CORP + asset_host.json + pck/wasm Content-Length (4축)
3. **`templates/inject-debug-pane.sh.tpl` 자동 주입 + Vercel deploy**
4. **사용자 새로고침 (Cmd+Shift+R)** → 우상단 빨간 박스에 진단 결과 표시
5. **사용자가 박스 텍스트 회신** → `Engine.getMissingFeatures` 출력 + 헤더 검증으로 원인 특정

**주입되는 진단 pane 내용 예** (`templates/inject-debug-pane.sh.tpl` 참고):
```
=== 상태 ===
canvas: 1280x720         # Godot이 캔버스 잡았는지 (300x150 = 부팅 안 됨)
status visible: visible  # status-notice 표시 중인지
progress: ""
notice: "Error\nThe following features required to run Godot projects on the Web are missing:\nWebGL2 - ..."
Missing features (threads=false): []
Missing features (threads=true): ["WebGL2..."]   # threads 강제 시 추가 필요
crossOriginIsolated: false                        # Vercel COEP 헤더 정상이어도 false 가능
SharedArrayBuffer: OK
WebGL2: 실패
WebGL1 fallback: 실패
```

→ 원인 즉시 식별 (헤더 미스매치 / WebGL2 미지원 / threads 강제 미만의 진짜 원인).

### Vercel 배포 전용 (2026-07 실전 검증)
- **단일 파일 100MB 한계** → lazy fetch 또는 Cloudflare Pages.
- **첫 `vercel --prod` 시 buildCommand가 project settings에 영구 저장**. 나중에 vercel.json에서 빼도 자동 실행됨. **`PATCH /v9/projects/{id}?teamId=...`로 직접 null 설정** 필요 (vercel CLI로는 변경 불가).
- **무료 플랜 일일 5,000 requests 한도** — `vercel --archive=tgz`로 묶어서 보내면 1 request. 한도 초과 시 24시간 블로킹.
- **`vercel.json` regex에 `$` 앵커 필수** (`"/(.+\\.(wasm|pck|js))"` ❌, `"/(.+)\\.(wasm|pck|js)$"` ✅).
- **Vercel 빌드 머신에 Godot CLI 없음** → `bash tools/build.sh web` exit 127. 해결: `buildCommand`를 Vercel project settings에서 null로, build/web/을 git에 직접 커밋, GitHub Actions에서 godot 빌드 후 푸시.

### Godot 4 import / autoload
- **빈 폴더에 `godot` 실행해도 project.godot 안 만들어줌**. `write_file`로 명시 생성.
- **autoload 스크립트에 `type inference` 에러** (예: `var x := func().field` 같은 콜백 결과 추론 실패) → autoload 로드 실패 → main.tscn에서 `Nil` 에러. `var x: Dict = obj["key"]` 처럼 명시.
- **모든 autoload에 `process_mode = Node.PROCESS_MODE_ALWAYS`** → 메인 씬 정지해도 시계/큐는 계속 동작.
- **헤드리스 부팅 검증 필수**: `godot --headless --quit-after <frame> 2>&1 | tail`. 스크립트 파스 에러는 출력에 남음.
- **함수 이름과 멤버 변수 이름 충돌 시 parse 에러** — `_ready()` 함수와 `var _ready: bool` 멤버가 동시에 있으면 멤버 변수가 `_ready` 플래그로 인식되어 충돌. → `var _manifest_ready: bool` 같이 함수 이름 피해서 명명.
- **Dictionary `:=` 추론 실패** — `var m := MANIFEST[cat]` 처럼 Dictionary 추론 안 됨. `var m: Dictionary = MANIFEST[cat]` 같이 명시.

### 모바일 / 모바일 세로 viewport anchor 레이아웃 함정 (2026-07-15)
**증상**: 데스크탑(1280x720)에서는 정상 UI, 모바일 세로(예: iPhone 1290x2325)에서는 **컨텐츠가 화면 밖으로 나가서 검은 화면처럼 보임**. 디버그 pane의 canvas rect는 정상 큰데 픽셀이 검은색.

**원인**: `offset_left=24, offset_top=600` 같은 절대 좌표는 viewport_width/height에 종속. 모바일 세로에서는 컨트롤이 viewport 아래/우측 밖에 위치.

**Fix**: 모든 Control의 위치는 **anchor 비율 (0~1)** 사용. Control은 Anchor가 기본값 (0,0,0,0)인데 모바일에서는 다음 패턴이 안전:
```
[node name="ButtonRow" type="VBoxContainer" parent="UI"]
anchor_left = 0.5; anchor_top = 0.55
anchor_right = 0.5; anchor_bottom = 0.95
offset_left = -200; offset_right = 200    # 폭만 픽셀 지정
offset_top = 0; offset_bottom = 0
```
- `BG ColorRect`: `anchor_right = 1.0; anchor_bottom = 1.0` → 화면 전체 cover
- `Label/Button`: `anchor_left = right = 0.5` + `offset_left = -width/2` → 가로 중앙 정렬
- `VBoxContainer`로 버튼 묶기 → 모바일 세로에서 버튼들이 세로 스택
- `custom_minimum_size = Vector2(0, 64)` → 버튼 최소 높이 보장 (모바일 탭 영역)

`project.godot`의 `window/stretch/mode="canvas_items"` + `aspect="expand"`는 유지 (Control 비율 stretch는 별개로 anchor로 처리).

### status div 부팅 후 덮음 함정 (2026-07-15)
**증상**: `Engine.getMissingFeatures()`가 비어 있고 모든 시스템 OK인데 화면이 검은색. `#status` div가 부팅 후에도 `visibility:visible` 상태로 남아 캔버스 위에 검은 div를 덮음.

**원인**: Godot 4 Web export의 `index.html`에 `#status` div가 부팅 진행률 표시용으로 있는데, 모바일 환경에서 `Engine.start()`가 정상 완료해도 status div의 visible 토글이 안 풀리는 경우가 있음 (특히 lazy fetch 매니페스트 로드 후 추가로 동기 작업 발생 시).

**Fix — `inject-debug-pane.sh`에 CSS 강제 추가**:
```css
#status { display: none !important; visibility: hidden !important; pointer-events: none !important; }
#status-notice, #status-progress { display: none !important; visibility: hidden !important; }
```
사용자가 진단 pane의 텍스트를 회신할 때 status div가 진짜 원인 가리개를 안 하고 있도록. 진단 끝난 후에도 CSS는 그대로 두면 OK (status div는 부팅 후 사실상 미사용).

### 한글 폰트 미적용 함정 (2026-07-15)
**증상**: 게임 UI는 정상 렌더링되고 메뉴/버튼이 보이는데 **모든 한글이 □ 깨짐**. 영문/숫자는 정상.

**원인**: Godot 4 기본 폰트(NotoSans fallback)는 한국어 글리프 미포함. 모바일 Web export에서 `renderer/rendering_method.mobile="gl_compatibility"` fallback 시 더 두드러짐. `project.godot`의 `[gui] theme/custom_font=...`는 4.7에서 일관성 없게 작동.

**Fix — main.gd의 `_ready()`에서 모든 Control에 재귀 적용** (가장 확실):
```gdscript
const KOREAN_FONT := preload("res://assets/fonts/UnDotum.ttf")

func _ready() -> void:
    var theme := Theme.new()
    theme.default_font = KOREAN_FONT
    theme.default_font_size = 24
    _apply_theme_recursive(self, theme)

func _apply_theme_recursive(node: Node, theme: Theme) -> void:
    if node is Control:
        (node as Control).theme = theme
    for child in node.get_children():
        _apply_theme_recursive(child, theme)
```
- 폰트 추천: `UnDotum.ttf` (FreeCiv 2.1MB, 한글+라틴) — 게임 풀에 흔히 있음
- `preload()`는 빌드 시 pck에 폰트 포함 (런타임 fetch 불필요)
- `default_font_size = 24` 권장 (모바일 가독성, PC에서는 약간 큼)
- `Label.autowrap_mode=2` (off)면 멀티라인 안 보임 → `3` (arbitrary) 또는 영역 충분히 키우기

**pck 크기 영향**: UnDotum.ttf 2.1MB 추가 → pck 1.9MB. Vercel 100MB 한도 안전.

### 캔버스 픽셀 검증 패턴 (원격 진단)
원격 사용자 디버깅 시 `canvas.getImageData`로 **실제 게임 씬이 그려졌는지** 검증:
```js
var probe = document.createElement('canvas');
probe.width = 32; probe.height = 32;
var pctx = probe.getContext('2d');
pctx.drawImage(document.getElementById('canvas'), 0, 0, 32, 32);
var data = pctx.getImageData(0, 0, 32, 32).data;
var nonBlack = 0;
for (var i = 0; i < data.length; i += 4) {
    if (data[i] > 10 || data[i+1] > 10 || data[i+2] > 10) nonBlack++;
}
// nonBlack=0/1024 = 모든 픽셀 검정 = 게임 씬 안 그려짐 (status div 덮음 등)
```
`inject-debug-pane.sh`의 `dumpState()`에 위 코드 추가 → 사용자 디버그 pane에 `canvas non-black pixels: 0/1024` 같은 한 줄 출력.

### 자산 / 풀 연결
- **`/Applications/Godot.app`이 homebrew cask로 깔리면 `godot` 심볼릭 링크가 `/opt/homebrew/bin/`에 생김**. CLI 사용 시 `godot --path ~/work/foo`.
- **풀에서 `.git` 폴더는 절대 게임 프로젝트로 링크하지 말 것**. `.gitignore`로 한 줄 차단.
- **Wesnoth units는 공격/방어 프레임 PNG가 많다**. base idle 포즈만 쓰려면 `-attack-/-defend-/-melee-/-ranged-/-mounted-/-die-` 패턴 grep 제외.
- **Wesnoth portraits는 `.webp` 형식 (png 아님)**. Godot 4는 webp 임포트 가능 (확인됨).
- **KayKit GLB는 `addons/<pack>/<Category>/gltf/*.glb` 구조**. top-level은 git subtree.
- **Doficia cord-sprites / gmgeo-osmic 등은 풀에서 fetch (curl/wget) → ZIP 풀기**. `tools/fetch-cc0-assets.sh` 패턴 참고.
- **`.gdignore`는 Godot import만 차단, git 추적은 유지** → lazy fetch용으로 자산은 그대로 git에 push하되 pck에서만 빠짐.

### export templates
- **빈 폴더에 export templates unpkg 후 `templates/` 서브폴더에 들어가 있으면 Godot이 못 찾음**. zip을 직접 부모 디렉터리로 옮길 것:
  ```bash
  cd "$HOME/Library/Application Support/Godot/export_templates/<버전>.stable/"
  mv templates/web_*.zip .   # templates/ 없이 직접
  ```
- **`export_presets.cfg`의 bool 값은 소문자** (`false`, `true`만). Python 자동 생성 시 `False` 들어가면 `Unexpected identifier 'False'` 에러.

### 결정 큐 / 자동 진행
- **CRITICAL이 아니면 자동 진행 멈추지 않음**. `DecisionQueue.has_pending_critical()` 체크는 `TimeManager._process` 안에서.
- **`process_mode = Node.PROCESS_MODE_ALWAYS`** 잊으면 GameManager.PAUSED에서 시계도 정지함.
- **`advanced_options=true` + `script_export_mode=2` (binary)** — 텍스트 export 시 PCK 누락.

## 핵심 명령어

```bash
# 1. Godot 4 설치
brew install godot   # 4.7+ stable

# 2. 프로젝트 부트스트랩 (write_file로 직접)
mkdir -p ~/work/<game>/{autoload,scenes,scripts,assets,docs,export,tools}
# project.godot, autoload/*.gd 작성

# 3. 자산 풀 연결
bash tools/setup-assets.sh   # idempotent 재실행 가능

# 4. lazy fetch (Vercel 무료용) — 선택
for d in assets/*/; do touch "$d/.gdignore"; done
bash tools/gen-asset-manifest.sh   # asset_host.json 생성
# build/web/을 git에 추적 (vercel.json outputDirectory와 직접 연결)

# 5. Godot import (1회, 1~2분)
cd ~/work/<game>
godot --headless --import

# 6. 헤드리스 검증 (빌드 전 필수)
godot --headless --quit-after 200   # autoload/init 에러 확인

# 7. 멀티플랫폼 빌드
bash tools/build.sh web     # Web → build/web/index.html
#   내부 호출: disable-service-worker.sh → inject-debug-pane.sh
bash tools/build.sh mac     # macOS → build/macos/
bash tools/build.sh all     # 전부

# 8. 검은 화면 시 진단 (사용자 PC 접근 불가일 때)
# inject-debug-pane.sh 자동 주입됨 → 사용자에게 새로고침 요청
# 우상단 박스 텍스트 회신 받으면 Engine.getMissingFeatures + 헤더로 원인 특정

# 9. Vercel 배포 (lazy fetch 채택 시)
export VERCEL_TOKEN=$(cat ~/.hermes/secrets/vercel_token.txt | tr -d '\n')
vercel --yes --prod --archive=tgz   # tgz 묶음으로 5,000 reqs 한도 회피

# 9b. Cloudflare 배포 (lazy fetch 없이)
# https://dash.cloudflare.com → Pages → Connect to Git → repo 선택
# Framework preset: None
# Build command: bash tools/build.sh web
# Build output: build/web
```

## 자산 라인업 (game-assets-pool에서 검증)

`tools/setup-assets.sh`가 다음 라인을 자동 구성:

| 카테고리 | 출처 | 라이선스 | 연결 수 |
|---|---|---|---|
| heroes | KayKit Adventurers 1.0 | CC0 | 5 glb |
| skeletons | KayKit Skeletons 1.0 | CC0 | 4 glb |
| dungeon_props | KayKit Dungeon Remastered 1.0 | CC0 | ~50 glb 선택 |
| units (human) | Wesnoth human-loyalists/outlaws | CC-BY-4.0 | ~180 base PNG |
| units (orc/goblin) | Wesnoth orcs/goblins | CC-BY-4.0 | ~210 PNG |
| units (undead/monster) | Wesnoth undead-skeletal/monsters | CC-BY-4.0 | ~225 PNG |
| units (allies) | Wesnoth elves-wood/dwarves | CC-BY-4.0 | ~580 PNG |
| portraits | Wesnoth portraits/{humans,dunefolk,elves,dwarves} | CC-BY-4.0 | ~96 webp |
| music | Wesnoth data/core/music | CC-BY-4.0 | ~44 ogg |
| sfx | Wesnoth data/core/sounds | CC-BY-4.0 | ~272 ogg |

총 **~1,700+ 자산**. Wesnoth 에셋은 GPL 코드와 분리되어 **CC-BY-4.0**만 따르므로 게임 본 프로젝트는 GPL 소스 공개 의무 없음.

## 자산 라이선스 표기 규칙

`docs/CREDITS.md`에 모든 저작자 + 라이선스 + 출처 표기:

```
- KayKit (CC0-1.0): 표기 의무 없음, 그래도 출처 표기
- Battle for Wesnoth (CC-BY-4.0): "© 2003-2026 The Battle for Wesnoth contributors / https://www.wesnoth.org/" + 라이선스 명시
- Nieobie game-icon-pack (CC0): 표기 의무 없음
```

## 지원 파일

- `templates/project.godot.tpl` — 5 autoload 표준 등록된 Godot 프로젝트 파일
- `templates/vercel.json.tpl` — Godot Web Export용 COOP/COEP 헤더
- `templates/export_presets.cfg.tpl` — Web/macOS/Windows/Linux 4종 preset
- `templates/autoload-{game,time,decision,save}_manager.gd.tpl` — 5종 autoload 골격
- `templates/autoload-asset-registry-lazy.gd.tpl` — lazy fetch AssetRegistry 골격
- `templates/setup-assets.sh.tpl` — 풀 → 심볼릭 링크 멱등 스크립트
- `templates/build.sh.tpl` — 멀티플랫폼 빌드
- `templates/gen-asset-manifest.sh.tpl` — 풀 → asset_host.json 생성
- `templates/asset_host.schema.json.tpl` — asset_host.json 스키마 예시
- `templates/disable-service-worker.sh.tpl` — Godot 4 Web export PWA SW 비활성화 (검은 화면 함정 회피, 2026-07-15)
- `templates/inject-debug-pane.sh.tpl` — index.html에 런타임 진단 pane 자동 주입 (원격 사용자 디버깅, 2026-07-15)
- `references/vercel-godot-web-export.md` — Vercel + Godot 4 웹 배포 함정 + 헤더 패턴
- `references/lazy-fetch-via-cdn.md` — Vercel 100MB 한계 lazy fetch 우회 구현 4단계 + jsDelivr/CDN 선택 + 캐시 무효화
- `references/cloudflare-pages-vs-vercel.md` — 두 호스팅 비교
- `references/godot-4-headless-bootstrap.md` — autoload 골격 + 헤드리스 부팅 검증 단계
- `references/wesnoth-asset-selection.md` — Wesnoth 풀에서 게임용 자산만 골라내는 grep + base 포즈 선택 기준
- `references/godot4-web-export-pitfalls.md` — 8가지 Web export 함정
- `references/godot-web-black-screen-diagnosis.md` — 검은 화면 진단 워크플로 + SW 비활성화 + 진단 pane (2026-07-15 last-banner 실전)
- `references/godot-web-mobile-ui-and-fonts.md` — 모바일 viewport anchor + status div 덮음 + 한글 폰트 미적용 함정 3종 (2026-07-15 last-banner 실전)

## 권장 워크플로

1. **풀 결정** — `game-assets-pool` 커밋 SHA pin 후 submodule이 아니라 `curl`로 풀 데이터 받기 (이미 둘 다 있음).
2. **`setup-assets.sh` 작성** — 풀 디렉터리 + 게임 프로젝트 디렉터리 둘 다 받기, 카테고리 필터링 후 심볼릭 링크.
3. **`project.godot` + autoload 골격** — 5종 표준, 게임 코어는 안 건드림.
4. **헤드리스 부팅 1회 검증** — autoload 로드 에러 잡기 (`--quit-after 200`).
5. **main.tscn** — 첫 화면 (부트 메뉴 + Save/Load/Toggle/Fetch).
6. **씬 본격 추가** — 영지 화면 → 전투 화면 → 결정 다이얼로그 모달.
7. **Web 빌드 후 SW 비활성화 + 디버그 pane 자동 주입** (빌드 파이프라인에 포함). 검은 화면 시 진단 pane이 자동 진단 결과 화면에 표시.
8. **Web 배포 결정** — `references/cloudflare-pages-vs-vercel.md` 보고 Vercel(lazy fetch) vs Cloudflare(대용량 그대로) 선택.
9. **자산 라이선스 README 업데이트** — 사용한 라인업 기반으로 CREDITS.md 재생성.

## 🔄 호스팅 결정 — 4가지 옵션 + 비교

Godot 4 Web export 산출물은 `index.pck` 1개 파일에 200~500MB 압축됨. 호스팅 결정은 **lazy fetch 채택 여부**로 갈림.

| 옵션 | 단일 파일 한계 | lazy fetch 불필요? | 결론 |
|---|---|---|---|
| Vercel (무료) | 100MB ❌ | ✅ (lazy fetch 채택 시) | 무료 + 자동화 |
| Vercel (Pro $20/월) | 무제한 | ✅ | 비용 발생 |
| Cloudflare Pages | 25MB | ✅ (대용량 자산 그대로 빌드) | 무료 + 가장 단순 |
| GitHub Pages | 100MB | ✅ | assets도 100MB OK지만 LFS 필요 |

**결론**:
- **lazy fetch 안 쓰겠다** → Cloudflare Pages (가장 단순, 무료)
- **Vercel 유지 + 무료** → `.gdignore` + jsDelivr lazy fetch (이 스킬 권장)
- **Pro 플랜 OK** → Vercel 무제한 (그냥 `vercel --prod`)

### lazy fetch 패턴 (Vercel 무료 + 200~500MB 자산 우회)

핵심 아이디어: `pck`에는 **스크립트/씬만** (~수백 KB) → 자산은 **런타임에 jsDelivr CDN에서 fetch** → `user://persistent/assets/`에 IndexedDB 캐시.

```
pck 501KB  →  게임 즉시 부팅
            ↓ 사용자가 [자산 가져오기 (CDN)] 클릭
jsDelivr   →  자산 228MB 백그라운드 다운로드
            ↓ 완료
user://    →  IndexedDB 캐시 (재방문 시 즉시)
```

**구현 4단계** (자세한 코드/함정은 `references/lazy-fetch-via-cdn.md`):

1. `assets/*/.gdignore` 파일 생성 → Godot export 시 해당 폴더 제외 (그러나 git 추적은 유지 → CDN이 받음)
2. `asset_host.json` 생성 (CDN URL + 카테고리별 파일 목록 + 사이즈) — `gen-asset-manifest.sh`로 자동 생성
3. `AssetRegistry.gd` lazy fetch 함수 (`_http_download` + `user://persistent/assets/` 캐시)
4. main.tscn에 `[자산 가져오기 (CDN)]` 버튼 + 진행률 표시

**장점**: Vercel 무료로 200~500MB 자산 호스팅 가능 + 첫 로드 빠름 (스크립트만 <1MB)  
**단점**: 첫 진입 후 자산 다운로드 30~60초 추가 (백그라운드 가능), CDN 장애 시 게임 불가

자세한 패턴은 `references/lazy-fetch-via-cdn.md`, Web export 8가지 함정은 `references/godot4-web-export-pitfalls.md`, Vercel/Cloudflare 비교는 `references/cloudflare-pages-vs-vercel.md`, 검은 화면 진단은 `references/godot-web-black-screen-diagnosis.md`.

## ⌨️ 단축키 권장 (자동 진행 게임)

자동 진행이 핵심 메카닉이라면 **`P` 키 = 자동 진행 토글**을 project.godot의 input action으로 등록:

```ini
[input]
toggle_auto_progress={
"deadzone": 0.5,
"events": [Object(InputEventKey,"resource_local_to_scene":false,"resource_name":"","device":-1,"window_id":0,"alt_pressed":false,"shift_pressed":false,"ctrl_pressed":false,"meta_pressed":false,"pressed":false,"keycode":80,"physical_keycode":0,"key_label":0,"unicode":112,"location":0,"echo":false,"script":null)
]
}
```

`TimeManager.toggle_auto_progress()`가 받아서 `auto_progress_enabled = not auto_progress_enabled`. UI에도 동일 단축키 버튼 노출. 결정 큐 모달은 자동 표시 (사용자 진입 시점).
