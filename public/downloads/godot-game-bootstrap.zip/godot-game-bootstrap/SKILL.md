---
name: godot-game-bootstrap
description: Godot 4로 새 게임 프로젝트를 부트스트랩할 때 사용 — 자산 풀 심볼릭 링크 + 멀티플랫폼 export (Web/macOS/Windows/Linux) + Vercel/Cloudflare + 헤드리스 부팅 검증 + macOS .app cascade 4단계 + 한글 폰트 (NanumGothic.ttf) + Wesnoth 2D idle PNG 셋업 + **macOS .app 시각 검증은 사용자 데스크탑 위임** (헤드리스 한계) + **Godot MCP 서버 통합 (hi-godot/godot-ai 권장, Hermes Agent 공식 지원)** + **전투/오버레이 씬 (GameWorld.apply_result 단일 dict)** + **race-free await 패턴 (한 함수 한 await)** + **CanvasLayer-for-Control 가시성 invariant** + **Godot 4 native 2D UI pitfalls (replace_all=true 폭파 방지, PanelContainer mouse_filter, HBox title/canvas 분리, PanelContainer 자식 anchor 4개 명시 — anchor_left/top 기본값 0이면 사이즈 0, 시각 개선은 GDScript 색상 오버라이드만, tscn 구조 변경은 사용자 .app 빌드 검증 필수)**. "Godot 게임 만들어줘", "Godot macOS 빌드", "Godot export 템플릿", "macOS .app cascade", "Wesnoth 2D 셋업", "한국어 폰트 깨짐", "헤드리스 .app 시각 검증", "Godot MCP", "godot-ai", "Hermes에서 Godot 자율 코딩", "전투 씬", "별도 씬 자원 처리", "비동기 race condition", "서브오버레이 가려짐", "Godot UI 겹침", "tscn 패치 폭파", "3패널 분할" 같은 요청에 발동.
last_updated: '2026-07-20 (v2.6.0 — references/godot4-native-2d-ui-pitfalls.md #12 추가: PanelContainer/VBoxContainer 자식 anchor 4개 명시 안 하면 사이즈 0 — v4.0.1 UI 회귀 직접 원인. 헤드리스 LB_VERIFY 통과해도 사용자 .app에서 시각 깨질 수 있음. tscn 구조 변경은 색상 오버라이드만, 시각 확인 가능한 환경에서만.)'
last_updated: 2026-07-16 (v2.3.0 — hi-godot/godot-ai + Gut + mcpollinations 통합 설치 recipe 추가; references/godot-mcp-gut-integration-setup.md + templates/gut-test-template.gd 신규; Last Banner 실전 검증)
last_updated: 2026-07-16 (v2.2.0 — Godot MCP 통합 섹션 + references/godot-mcp-ecosystem-2026-07.md 추가)
last_updated: 2026-07-16 (v2.1.0 결정 큐 자동 진행 ON/OFF 분기 + 상단 카운터 제거 추가)
last_updated: 2026-07-16
---

# Godot 4 Game Bootstrap

풀에서 자산을 끌어와 Godot 4 게임 프로젝트를 만든다. **풀은 submodule로 흡수하지 않고 `tools/setup-assets.sh`로 카테고리별 필터링 후 심볼릭 링크**만 만들어 디스크/중복 없이 사용. 자동 진행 + 결정 큐는 autoload 골격으로 제공하므로 즉시 게임 메카닉 코드에 집중 가능.

## 호스팅 결정 (lazy fetch 채택으로 Vercel 무료 + 200~500MB 자산 우회)

이전에는 Godot 4 Web export 시 `index.pck`가 200MB 넘어서 Vercel 무료 한계(파일당 100MB)에 막혔음. **2026-07 검증 결과**: `assets/*/.gdignore` + jsDelivr lazy fetch 패턴으로 **Vercel 무료 유지 + 228MB 자산 그대로 호스팅** 가능. 4가지 옵션 비교는 아래 "🔄 호스팅 결정" 섹션 참고.

## 언제 쓰나

- game-assets-pool 같은 자산 풀에서 **특정 게임용 라인업**만 골라 게임 프로젝트에 연결할 때
- Godot 4 데스크탑 + **Web Export를 Vercel/Cloudflare에 배포**할 때 (lazy fetch로 Vercel 무료 가능)
- **자동 진행(위임 모드) + 결정 큐(critical 사건 정지) + 영속 저장(JSON/IndexedDB)** 게임 메카닉을 처음부터 짤 때
- 멀티플랫폼 export preset을 한 번에 셋업할 때
- 자산 라이선스 표기 (CC0/CC-BY-4.0) 구조를 처음부터 정리할 때
- **Web 빌드 결과가 브라우저에서 검은 화면으로 부팅 안 될 때** — SW 비활성화 / 디버그 pane 진단 (2026-07-15 last-banner 실전)

## 핵심 디자인 원칙

| 원칙 | 이유 |
|---|---|
| **풀을 submodule로 흡수 X, 심볼릭 링크로만** | 풀은 큐레이터 저장소 안에서 자체 진화. 게임 프로젝트는 카테고리 필터링만 필요한데 submodule로 받으면 쓸데없는 데이터까지 다 옴. |
| **autoload 7종 표준 골격** (Last Banner 실전 검증) | GameManager(상태) · TimeManager(자동 진행 시계) · DecisionQueue(임시정지 결정) · SaveManager(JSON/IndexedDB 영속화) · AssetRegistry(카테고리 매니페스트 + lazy fetch) · **GameWorld(영지/용병/자원 데이터 모델)** · **EventEngine(매 tick 사건 생성기)** |
| **Web export = PWA + COOP/COEP 헤더 필수** | Godot 4의 SharedArrayBuffer/Threading 활성화 요구사항 → Vercel `headers`에 3개 헤더 세팅 |
| **lazy fetch 패턴으로 Vercel 무료 사용** | `assets/*/.gdignore` (import 차단, git 추적 유지) + jsDelivr CDN 런타임 fetch + user://persistent/assets/ 캐시. pck은 ~수백 KB로 줄어듦. |
| **자산 라이선스는 코드(코드 영역)와 분리** | GPL 게임(Wesnoth)의 에셋은 별도 CC-BY-4.0. 게임 본 프로젝트는 에셋만 사용하므로 GPL 소스 공개 의무 없음. |
| **P 키로 자동 진행 토글 (CRITICAL 결정 시 자동 정지)** | "사용자가 위임하면 자동으로 진행되고, 언제든지 다시 진입" 선호 — 사용자 진입 시 결정 큐 모달 노출. |
| **결정 큐는 우선순위 정렬 + CRITICAL 임시정지 신호** | MEDIUM 결정은 큐에 쌓이기만, CRITICAL이면 GameManager가 즉시 DECISION_PENDING으로 전이 |
| **저장은 `user://` (데스크탑) / IndexedDB (Web) 양쪽 호환** | Godot Web export는 `user://`를 IndexedDB에 자동 매핑 → 데스크탑/Web 동일 코드 |
| **build/web/ 만 .gitignore 예외** | lazy fetch 채택 시 build/web/도 git 추적 (Vercel outputDirectory와 직접 연결). 나머지 build/*는 ignore. |

## 표준 디렉터리 레이아웃

```
game-name/
├── project.godot                # Godot 4 프로젝트 정의 + 5개 autoload 등록
├── export_presets.cfg           # Web/macOS/Windows/Linux 4종 preset (루트 위치 필수)
├── vercel.json                  # COOP/COEP/SW 헤더 (Vercel 배포 시)
├── wrangler.toml                # Cloudflare Pages 빌드 설정 (선택)
├── _headers                     # Cloudflare Pages Cross-Origin 헤더 (선택)
├── asset_host.json              # lazy fetch용 매니페스트 (CDN URL + 카테고리별 사이즈)
├── .gitignore                   # .godot/ + build/* (단, build/web/ 예외)
├── README.md                    # 컨셉/자산/빠른시작/라이선스
├── docs/CREDITS.md              # 라이선스별 표기 (CC0/CC-BY-4.0)
├── autoload/                    # *res://autoload/*.gd 싱글턴
│   ├── game_manager.gd          # 상태머신 (BOOT/MENU/PLAYING/PAUSED/DECISION_PENDING/COMBAT/GAME_OVER)
│   ├── time_manager.gd          # 1초 = 게임 내 X시간 자동 진행, tick_advanced/day_changed/season_changed 시그널
│   ├── decision_queue.gd        # 우선순위별 큐 + CRITICAL → 일시정지
│   ├── save_manager.gd          # user://save_*.json + tick_advanced 구독 자동 저장 (IndexedDB 호환)
│   ├── asset_registry.gd        # 매니페스트 로드 + lazy fetch (CDN → user://persistent/assets/)
│   ├── game_world.gd            # 영지(gold/food/population/prosperity/fortification) + 용병 roster 데이터 모델
│   └── event_engine.gd          # 매 tick 사건 생성기 (4h/8h/10h/12h 주기 + 확률 게이트 + 결정 큐 push)
├── scripts/                     # .gd 게임 스크립트
├── scenes/                      # .tscn 메인/서브 씬
├── assets/                      # 심볼릭 링크로 연결된 풀 + .gdignore (lazy fetch용)
│   ├── .gdignore                # Godot import 차단, git 추적은 유지
│   ├── heroes/                  # KayKit Adventurers glb
│   ├── enemies/                 # KayKit Skeletons glb
│   ├── props/                   # KayKit Dungeon glb
│   ├── units/{faction}/         # Wesnoth PNG base 포즈
│   ├── portraits/{faction}/     # Wesnoth webp
│   └── audio/{music,sfx}/       # Wesnoth ogg
├── tools/
│   ├── setup-assets.sh          # 풀 → 게임 심볼릭 링크 멱등 스크립트
│   ├── build.sh                 # 멀티플랫폼 빌드 (web/mac/windows/linux/all)
│   ├── gen-asset-manifest.sh    # 풀 → asset_host.json 자동 생성 (lazy fetch 매니페스트)
│   ├── disable-service-worker.sh  # Godot 4 Web export PWA SW 비활성화 (post-build, 검은 화면 함정 회피)
│   └── inject-debug-pane.sh     # index.html에 런타임 진단 pane 자동 주입 (원격 사용자 디버깅)
└── build/                       # .gitignore (단, build/web/은 추적 — Vercel이 직접 사용)
```

## 빠른 시작 절차

1. **디렉터리 + 5종 autoload 골격** — `project.godot` + `autoload/*.gd` 작성. 헤드리스 부팅으로 검증.
2. **자산 풀 스크립트 작성** — `tools/setup-assets.sh`가 idempotent. 카테고리별 find + 필터링 + 링크.
3. **Godot import** — `godot --headless --import` 1회 (1,000+ 자산도 1~2분).
4. **export presets** — `export_presets.cfg` (Web + macOS + Windows + Linux). **루트 디렉터리에 둘 것** (서브폴더 X).
5. **vercel.json + vercel CLI** — `vercel.json` 헤더 + `vercel --prod --archive=tgz` (5000 requests 한도 우회).
6. **Web 빌드 후 SW 비활성화 + 디버그 pane 자동 주입** — `bash tools/build.sh web` 한 번이면 내부에서 둘 다 자동 실행.
7. **lazy fetch 채택 시** — `assets/*/.gdignore` 생성 + `gen-asset-manifest.sh` 실행 + AssetRegistry lazy fetch 함수.
8. **README + CREDITS.md** — 자동 생성 가능.

## 함정 (반드시 숙지)

### Web export 전용
- **COOP/COEP 헤더 누락 = 첫 로드 멈춤**. `Cross-Origin-Opener-Policy: same-origin` + `Cross-Origin-Embedder-Policy: require-corp` + `Cross-Origin-Resource-Policy: same-origin`. Vercel `vercel.json` `headers` 배열로.
- **SharedArrayBuffer를 사용하려면 wasm threading 활성화**. export preset에서 `variant/thread_support=true` + `variant/wasm_threads=true`. 단, threading 끄면 COEP 의존성이 떨어져 헤더 단순화 + 환경 호환성 ↑.
- **`.wasm`/`.pck`/`.js` 캐시 헤더는 1년 immutable**. Service Worker는 `no-cache`.
- **PWA 활성화 시 `progressive_web_app/enabled=true` + icon 144/180/512 PNG 필요**. 없으면 기본 아이콘.
- **`.import` 파일(자동 생성)을 다른 폴더로 옮기지 말 것** — Godot이 import 단계마다 경로 추적함. 옮기면 깨짐.
- **headless launch 전 GDScript parse 검증**: `godot --headless --quit-after 200` 1회 실행 후 Error 줄 없으면 빌드 진행.
- **vercel.json은 vercel 스키마 필드 외 추가 속성 (`_comment`) 거부** → plain JSON으로만.

### Web export — PWA Service Worker 비활성화 함정 (2026-07-15 last-banner 실전)

**증상**: 사용자 브라우저에서 검은 화면 + Godot 로고만. 콘솔에 `Service worker already exists` 또는 `Unexpected token 'else'`. 새로고침해도 회복 안 됨.

**원인**: `progressive_web_app/enabled=false`로 설정해도 **Godot 4.7 Web export는 여전히** `index.service.worker.js` 파일 + `index.html`의 SW 등록 if-else 블록을 생성. 첫 build 후 reload 시 `Service worker already exists` 에러로 무한 reload에 빠지거나, `crossOriginIsolated=false` 환경에서 missing features 분기 진입 시 **else가 단독 구문이 되어 `SyntaxError: Unexpected token 'else'`**.

`vercel.json` 헤더 / `progressive_web_app.enabled` 어디서도 못 막음. **빌드 후 HTML post-processing으로 SW 자체를 no-op 처리**하는 것이 유일한 해결.

**Fix 패턴 — `templates/disable-service-worker.sh.tpl`**:
1. `index.service.worker.js` 파일 삭제
2. `index.offline.html` 삭제 (SW 의존)
3. `GODOT_CONFIG.serviceWorker = ""` 로 패치
4. **핵심**: SW if-else 블록을 `if (false) { /* SW DISABLED */ } else { ... }` 로 교체. **단순 주석(//) 절대 불가** — else가 매칭할 if 잃어 SyntaxError.

```python
# 핵심 regex — else를 보존해야 if-else 문법 유지
pattern = re.compile(
    r"if \(GODOT_CONFIG\['serviceWorker'\] && GODOT_CONFIG\['ensureCrossOriginIsolationHeaders'\] && 'serviceWorker' in navigator\) \{[\s\S]*?\}\s+else\s*\{",
    re.MULTILINE
)
m = pattern.search(html)
new_html = (
    html[:m.start()]
    + "if (false) { /* SW DISABLED */ } else {"
    + html[m.end():]
)
```

`bash tools/disable-service-worker.sh build/web` 한 줄로 처리. 빌드 파이프라인(`tools/build.sh web`)에 포함 권장.

### Web export — 검은 화면 진단 워크플로 (2026-07-15)

원격 사용자 브라우저에서 **검은 화면만 보이는 상태**를 진단할 때 **puppeteer 헤드리스는 한계**가 있음 (`--use-gl=swiftshader`도 WebGL2 software rendering 미지원 → 게임 자체 부팅 안 됨). 헤드리스에서 게임 부팅 안 된다고 사용자 환경도 동일하지 **않음**.

**정석 워크플로**:
1. **로컬 헤드리스 부팅** — `godot --headless --quit-after 200` (autoload parse 에러 잡기)
2. **`build/web/` curl 헤더 검증** — COOP/COEP/CORP + asset_host.json + pck/wasm Content-Length (4축)
3. **`templates/inject-debug-pane.sh.tpl` 자동 주입 + Vercel deploy**
4. **사용자 새로고침 (Cmd+Shift+R)** → 우상단 빨간 박스에 진단 결과 표시
5. **사용자가 박스 텍스트 회신** → `Engine.getMissingFeatures` 출력 + 헤더 검증으로 원인 특정

**주입되는 진단 pane 내용 예** (`templates/inject-debug-pane.sh.tpl` 참고):
```
=== 상태 ===
canvas: 1280x720         # Godot이 캔버스 잡았는지 (300x150 = 부팅 안 됨)
status visible: visible  # status-notice 표시 중인지
progress: ""
notice: "Error\nThe following features required to run Godot projects on the Web are missing:\nWebGL2 - ..."
Missing features (threads=false): []
Missing features (threads=true): ["WebGL2..."]   # threads 강제 시 추가 필요
crossOriginIsolated: false                        # Vercel COEP 헤더 정상이어도 false 가능
SharedArrayBuffer: OK
WebGL2: 실패
WebGL1 fallback: 실패
```

→ 원인 즉시 식별 (헤더 미스매치 / WebGL2 미지원 / threads 강제 미만의 진짜 원인).

### Vercel 배포 전용 (2026-07 실전 검증)
- **단일 파일 100MB 한계** → lazy fetch 또는 Cloudflare Pages.
- **첫 `vercel --prod` 시 buildCommand가 project settings에 영구 저장**. 나중에 vercel.json에서 빼도 자동 실행됨. **`PATCH /v9/projects/{id}?teamId=...`로 직접 null 설정** 필요 (vercel CLI로는 변경 불가).
- **무료 플랜 일일 5,000 requests 한도** — `vercel --archive=tgz`로 묶어서 보내면 1 request. 한도 초과 시 24시간 블로킹.
- **`vercel.json` regex에 `$` 앵커 필수** (`"/(.+\\.(wasm|pck|js))"` ❌, `"/(.+)\\.(wasm|pck|js)$"` ✅).
- **Vercel 빌드 머신에 Godot CLI 없음** → `bash tools/build.sh web` exit 127. 해결: `buildCommand`를 Vercel project settings에서 null로, build/web/을 git에 직접 커밋, GitHub Actions에서 godot 빌드 후 푸시.

### Godot 4 import / autoload
- **빈 폴더에 `godot` 실행해도 project.godot 안 만들어줌**. `write_file`로 명시 생성.
- **autoload 스크립트에 `type inference` 에러** (예: `var x := func().field` 같은 콜백 결과 추론 실패) → autoload 로드 실패 → main.tscn에서 `Nil` 에러. `var x: Dict = obj["key"]` 처럼 명시.
- **모든 autoload에 `process_mode = Node.PROCESS_MODE_ALWAYS`** → 메인 씬 정지해도 시계/큐는 계속 동작.
### **`var X: int2` 오타 — 존재하지 않는 정수형 (2026-07-20 last-banner-v4.0.0 실전)**

**증상**: GDScript 파스 에러 `Identifier "int2" not declared in the current scope`. LB_VERIFY 검증에서 즉시 hang.

**원인**: GDScript 정수 타입은 **`int` 단일**. `int2` / `int4` 같은 GPU 프로그래밍 스타일 타입 없음 (`Vector2i`는 별도). 신나서 검증용 임시 변수 만들다가 오타 발생.

```gdscript
# ❌ Parse Error
var gold_before: int2 = GameWorld.gold

# ✓
var gold_before: int = GameWorld.gold
```

**진단법**: `godot --headless --import` 출력에 `Identifier "intN" not declared` → 즉시 grep + sed 치환. **1초 fix**.

### **macOS 헤드리스 timeout 부재 — `&` + sleep + kill 패턴 (2026-07-20 last-banner-v4.0.0 실전)**

**증상**: `timeout 30 bash -c "godot --headless ..."` 실행 시 `bash: line 1: timeout: command not found` 에러. macOS는 `timeout` 명령어가 GNU coreutils에 있지만 기본 설치되지 않음.

**해결 — 백그라운드 + sleep + kill 패턴**:
```bash
# ❌ macOS에서 실패
timeout 30 godot --headless --script verify.gd

# ✓ Hermes terminal 도구 + macOS 호환
(godot --headless > /tmp/lb.log 2>&1 &) && sleep 18 && cat /tmp/lb.log | tail -50
```

**확장 패턴 — LB_VERIFY 같은 장시간 헤드리스 검증**:
```bash
cd /Users/mac/work/<game>
(LB_VERIFY=1 godot --headless > /tmp/lb.log 2>&1 &) 
sleep 18  # LB_VERIFY는 보통 5~15초 걸림
grep -E "(SCRIPT ERROR|Parse Error|Assertion failed)" /tmp/lb.log | head -10
echo "--- tail ---" && tail -10 /tmp/lb.log
```

**왜 `&` 후 괄호**: `( ... &)` 서브쉘에서 띄우면 현재 쉘이 즉시 리턴 → sleep + grep 동시 진행 가능.

### **PanelContainer 자식 anchor 4-값 명시 필수 — anchor_left/top 기본값 0이면 사이즈 0 (2026-07-20 last-banner-v4.0.1 UI 회귀 실전)**

**증상**: 헤드리스 LB_VERIFY 17단계 모두 통과 + `godot --headless --export-release macOS` 빌드 성공 → 사용자가 .app 실행 → **빈 화면 + 상단 좌측에 텍스트만 뭉침** + 카드만 어긋남. 스크린샷 보면 PanelContainer만 보임.

**원인**: PanelContainer를 동적으로 추가하거나 자식 VBoxContainer를 둘 때, 자식의 `anchor_right=1.0, anchor_bottom=1.0`만 명시하고 `anchor_left/top`은 기본값 0으로 두면 → 자식이 부모 안에서 **0,0 위치에 0 사이즈**로 그려짐. PanelContainer는 자식의 min_size를 따라 사이즈를 잡기 때문에 자식이 0이면 카드만 보이고 내용은 좌상단 모서리에 뭉침.

**가장 흔한 트리거**: tscn에 `PanelContainer` + 자식 `VBoxContainer`를 새로 추가할 때 — `anchor_left/top`을 빠뜨림. 특히 "tscn 구조 변경 → UI 개선" 의도였을 때 빈도가 높음 (v4.0.1 회귀의 직접 원인).

**진단 4단계** (헤드리스는 통과해도 사용자 데스크탑에서만 보임):
```bash
# 1) LB_VERIFY는 통과 — autoload/시그널은 OK
LB_VERIFY=1 godot --headless

# 2) 빌드 성공
godot --headless --export-release macOS

# 3) .app 사이즈 정상
du -sh "build/macos/Last Banner.app"   # 170 MB OK

# 4) 사용자 .app 실행 → 빈 화면
# → 헤드리스로는 절대 못 잡음. 사용자 Mac 데스크탑 빌드 + 스크린샷 필수
```

**해결 — anchor 4개 모두 명시**:
```ini
# ❌ anchor_left/top 누락 → 사이즈 0
[node name="CenterBox" type="VBoxContainer" parent="CenterCard"]
anchor_right = 1.0
anchor_bottom = 1.0

# ✓ anchor 4개 명시
[node name="CenterBox" type="VBoxContainer" parent="CenterCard"]
anchor_left = 0.0
anchor_top = 0.0
anchor_right = 1.0
anchor_bottom = 1.0

# 또는 offset_left/top으로 명시적 픽셀 위치
[node name="CenterBox" type="VBoxContainer" parent="."]
anchor_left = 0.5; anchor_top = 0.5
anchor_right = 0.5; anchor_bottom = 0.5
offset_left = -260.0; offset_top = -200.0
offset_right = 260.0; offset_bottom = 200.0
```

**더 안전한 패턴 — 동적으로 PanelContainer를 추가하는 GDScript 코드**:
```gdscript
# ❌ anchor_left/top 미설정 + position만 — 자식 사이즈 0
var card := PanelContainer.new()
add_child(card)
var vbox := VBoxContainer.new()
card.add_child(vbox)

# ✓ anchor 4개 명시
var card := PanelContainer.new()
card.anchor_left = 0.5; card.anchor_top = 0.5
card.anchor_right = 0.5; card.anchor_bottom = 0.5
card.offset_left = -290.0; card.offset_top = -240.0
card.offset_right = 290.0; card.offset_bottom = 240.0
add_child(card)
```

**핵심 교훈 — "구조 변경은 사용자 검증 후에만"**:
- 시각 개선 (= 색상/스타일/UITheme 적용) = **GDScript `.gd` 코드에서 동적 적용** — tscn 구조는 절대 안 건드림
- 새 카드 추가 (= PanelContainer 추가) = **사용자에게 .app 빌드 + 스크린샷 회신 요청** 후 commit
- LB_VERIFY 통과 ≠ 시각 정상 — 헤드리스는 layout 검증 안 함 (ResourceLoader.get_size만, get_position/get_anchor 안 함)
- v4.0.1 회귀는 **17단계 LB_VERIFY 모두 PASS**였지만 사용자 .app에서 깨짐 → LB_VERIFY는 통합/기능 검증만, **시각 검증은 사용자 디스크탑 위임** (이미 스킬 상단의 "macOS .app 시각 검증은 사용자 데스크탑 위임"에 명시)

**가시 안전성 invariant (수정 권장)**: PanelContainer + 자식 VBoxContainer/HBoxContainer 구조를 동적/정적으로 추가할 때, **자식의 anchor 4개 명시 + .app 사용자 빌드 검증** 두 가지를 동시에. v4.0.1 회귀 후 v4.0.2에서 tscn은 v3.1.6 검증된 형태로 100% 복원, 색상만 동적 적용.

**관련 함정**: `godot4-native-2d-ui-pitfalls.md`의 "PanelContainer mouse_filter" 섹션 + "HBox 안 title/canvas 분리" 섹션과 함께 읽기.

### **UITheme 표준화 패턴 — 색상/스타일 중앙 관리 (2026-07-20 last-banner-v4.0.1 실전)**

**증상**: tscn과 .gd 파일 곳곳에 `Color(0.95, 0.78, 0.2)` 같은 색상 리터럴이 흩어져 있어 색 일관성 깨짐 + 다크/라이트 톤 조정 시 모든 파일 grep + 치환 필요.

**해결 — `autoload/ui_theme.gd` 신규 + 색상 상수 + 헬퍼 함수**:
```gdscript
extends Node
## UITheme — 색상 팔레트 + 스타일 헬퍼 중앙 관리

const BG_BASE := Color(0.10, 0.07, 0.05, 1.0)
const BG_PANEL := Color(0.16, 0.12, 0.09, 0.95)
const TEXT_PRIMARY := Color(0.95, 0.92, 0.85, 1.0)
const TEXT_TITLE := Color(0.98, 0.92, 0.70, 1.0)
const COLOR_GOLD := Color(1.00, 0.85, 0.30, 1.0)
const PRIORITY_CRITICAL := Color(1.00, 0.40, 0.40, 1.0)

func resource_color(resource: String) -> Color: ...
func priority_color(priority: int) -> Color: ...
func make_panel_style(bg: Color, border: Color, border_w: int = 1, radius: int = 4) -> StyleBoxFlat:
    var style := StyleBoxFlat.new()
    style.bg_color = bg
    style.border_color = border
    style.set_border_width_all(border_w)
    style.set_corner_radius_all(radius)
    return style

func apply_style(control: Control, style: StyleBoxFlat) -> void:
    if control and style:
        control.add_theme_stylebox_override("panel", style)

func apply_button_styles(button: Button, base: Color) -> void:
    var normal_style := make_button_style(base)
    var hover_style := make_button_style(base.lerp(Color.WHITE, 0.15))
    var pressed_style := make_button_style(base.lerp(Color.BLACK, 0.2))
    button.add_theme_stylebox_override("normal", normal_style)
    button.add_theme_stylebox_override("hover", hover_style)
    button.add_theme_stylebox_override("pressed", pressed_style)
```

**사용 패턴 (main.gd `_apply_styles()` 1회 호출로 전체 적용)**:
```gdscript
func _apply_styles() -> void:
    var topbar: PanelContainer = ui_layer.get_node_or_null("TopResourceBar") as PanelContainer
    if topbar:
        UITheme.apply_style(topbar, UITheme.make_panel_style(UITheme.BG_PANEL_DARK))
    UITheme.apply_button_styles(save_button, UITheme.BG_BUTTON)
```

**핵심 디자인 원칙**:
1. **모든 색상 리터럴은 UITheme 상수 참조** — tscn에 `Color(...)` 박지 말 것
2. **tscn은 구조만, 색은 .gd 코드에서 일괄 적용** — 색 변경 시 한 곳만 수정
3. **StyleBoxFlat `apply_style()` 헬퍼** — PanelContainer의 `add_theme_stylebox_override("panel", style)` 통일
4. **Button hover/pressed/disabled 4종 모두 override** — Godot 기본 스타일 회피

### **`% 포맷 — 단일 인자만 (printf 스타일 미지원) (2026-07-20 last-banner-v4.0.0 실전)**

**증상**: `dynasty_name = "%가 가문" % lord.name` 호출 시 `SCRIPT ERROR: unsupported format character in operator '%'` + 즉시 파스 에러.

**원인**: GDScript의 `%` 연산자는 **항상 단일 인자 또는 어레이 1개**만 받음. printf 스타일의 `%s %d` 가변 인자 미지원. `'s'` 같은 포맷 지정자 누락 시 파스 에러.

```gdscript
# ❌ Parse Error: unsupported format character in operator '%'
dynasty_name = "%가 가문" % lord.name      # 's' 누락
msg = "이름: %s 나이: %d" % (name, age)    # 튜플 미지원

# ✓ 단일 인자
dynasty_name = "%s 가문" % lord.name

# ✓ 다중 인자 — 어레이로
msg = "이름: %s 나이: %d" % [name, age]
```

**진단법**: `Parse Error: unsupported format character` → 해당 줄의 `%` 호출에서 포맷 문자 누락 또는 튜플 사용. 즉시 fix 가능.

### **함수 내 변수명 중복 회피 (LB_VERIFY 누적 시) (2026-07-20 last-banner-v4.0.0 실전)**

**증상**: `SCRIPT ERROR: Parse Error: There is already a variable named "roster_count" declared in this scope`. LB_VERIFY `_run_verify()`처럼 거대한 함수에서 단계별 임시 변수가 충돌.

**원인**: step [8.7]에서 `var roster_count: int = ...` 선언 + step [9]에서 같은 이름 재선언. 직전 단계와 같은 변수명을 의식 없이 재사용.

**해결 — 단계 prefix 또는 의미 변경**:
```gdscript
# ❌
# step 8.7
var roster_count: int = GameWorld.alive_mercenaries().size()
# step 9
var roster_count: int = roster_node.get_child_count()   # Parse Error!

# ✓ 의미 변경
# step 8.7
var saved_count: int = GameWorld.alive_mercenaries().size()
# step 9
var roster_count: int = roster_node.get_child_count()
```

**LB_VERIFY 작성 시 권장 컨벤션**: `var <prefix>_<descriptor>` — `gold_before_nurture` / `food_pre_build` / `saved_count` / `build_id` / `target_id` 등.

### 헤드리스 부팅 검증 필수
- **빈 폴더에 `godot` 실행해도 project.godot 안 만들어줌**. `write_file`로 명시 생성.
- **autoload 스크립트에 `type inference` 에러** (예: `var x := func().field` 같은 콜백 결과 추론 실패) → autoload 로드 실패 → main.tscn에서 `Nil` 에러. `var x: Dict = obj["key"]` 처럼 명시.
- **모든 autoload에 `process_mode = Node.PROCESS_MODE_ALWAYS`** → 메인 씬 정지해도 시계/큐는 계속 동작.
- **헤드리스 부팅 검증 필수**: `godot --headless --quit-after <frame> 2>&1 | tail`. 스크립트 파스 에러는 출력에 남음.
- **함수 이름과 멤버 변수 이름 충돌 시 parse 에러** — `_ready()` 함수와 `var _ready: bool` 멤버가 동시에 있으면 멤버 변수가 `_ready` 플래그로 인식되어 충돌. → `var _manifest_ready: bool` 같이 함수 이름 피해서 명명.
- **Dictionary `:=` 추론 실패** — `var m := MANIFEST[cat]` 처럼 Dictionary 추론 안 됨. `var m: Dictionary = MANIFEST[cat]` 같이 명시.

### **LB_VERIFY state-dependent 테스트 순서 함정 — assert 가정은 "이전 단계의 close 호출 완료" 전제 (2026-07-20 last-banner-v4.1.0 B-1 튜토리얼 실전)**

**증상**: LB_VERIFY에서 같은 시스템을 두 번 호출하며 상태 변화를 검증할 때, "이미 한 번 close 됐다"는 가정 하에 두 번째 호출의 skip 분기를 검증 → assert fail. 예: 튜토리얼 `start_tutorial(false)`를 두 번 호출하며 seen=true 시 skip 분기 검증 시, 첫 번째 호출의 `_on_next_pressed`가 마지막 step까지 진행해 `_finish_tutorial`을 호출하지 않은 상태(즉 사용자가 step 1~3에서 멈춘 상태)에서는 visible=true가 유지됨 → 두 번째 skip 분기 assert 실패.

**원인**: LB_VERIFY 코드는 `for i in range(STEPS.size()): tutorial._on_next_pressed()`로 마지막 step까지 가지 않을 수도 있음 (디버그 중 멈춤, branch 검증 중 일찍 중단). assert는 "이전 close가 완료됐다"는 전제인데, 그 전제가 거짓일 수 있음.

**수정 패턴 — 명시적 close 후 분기 검증**:
```gdscript
# ❌ 가정 오류 — 첫 호출의 close가 완료됐다고 가정
GameManager.tutorial_seen = true   # 두 번째 호출에서 skip 분기 타기 위해
tutorial.start_tutorial(false)
await get_tree().process_frame
assert(not tutorial.visible)        # FAIL — 실제 visible=true

# ✓ 명시적으로 close 보장
tutorial._on_skip_pressed()         # _finish_tutorial 강제 트리거
await get_tree().process_frame
assert(not tutorial.visible)
assert(GameManager.tutorial_seen)
GameManager.tutorial_seen = true     # 안전 재설정
tutorial.start_tutorial(false)       # seen=true → skip 분기 검증
await get_tree().process_frame
assert(not tutorial.visible)        # OK
```

**일반화 — "LB_VERIFY 검증 시 가시 상태는 명시적 close 보장 후 검증"**:
- 모달/오버레이: `_on_close_pressed()` / `_hide()` / `_finish_x()` 명시 호출 후 검증
- 로직 분기가 자동 호출에 의존하지 않음
- 분기 검증 = "조건만 인위적으로 set → 분기 결과만 확인" (이전 상태 무관)

**함께 적용**: 자동 skip 타이머 / 트랜지션 / 애니메이션이 끼면 `_process_frame` await을 명시적으로 1번 + close + 재검증 패턴. LB_VERIFY가 hang할 위험 0.

**관련**: `references/headless-verify-pitfall.md`의 "await get_tree().process_frame 누적 hang" + "시그널 인자 미스매치 ERROR" 3가지 hang 원인 패턴과 함께 적용.

### Autoload cross-reference 이름 명시 (2026-07-16 last-banner-v2 실전)

**증상**: `autoload/game_world.gd`에서 print 문에 `day` 변수를 그냥 썼는데 `Identifier "day" not declared in the current scope` 파스 에러 → GameWorld autoload 로드 실패 → GameManager도 의존성 때문에 컴파일 실패 연쇄 → 부팅 hang.

**원인**: 같은 이름 변수가 여러 autoload에 있을 때 (TimeManager에 `var day: int`, GameWorld에는 없음) `self` 멤버가 우선이지만 **다른 autoload 멤버는 자동 임포트 안 됨**. GDScript는 Python처럼 from-import 없음.

**해결 — autoload 멤버 접근할 땐 항상 글로벌 이름 명시**:
```gdscript
# ❌ game_world.gd 안에서 그냥 day — parse error
print("[GameWorld] Day %d — gold %+d" % [day, day_gold_change])

# ✓ TimeManager.day로 명시
print("[GameWorld] Day %d — gold %+d" % [TimeManager.day, day_gold_change])

# dict 키도 마찬가지
var entry := {"day": TimeManager.day, "message": message}
```

**진단법**: `godot --headless --import` 출력에 `SCRIPT ERROR: Parse Error: Identifier "X" not declared` → 해당 줄의 멤버가 다른 autoload에 있는지 grep. `grep -rn "var X:" autoload/`로 즉시 식별. 부팅 hang은 보통 이 단계에서 동시다발로 잡힘.

### `.gdignore` 자산 import 차단 함정 (2026-07-16 last-banner-v2 실전)

**증상**: `assets/.gdignore` 또는 `assets/*/.gdignore` 생성 후 폰트 같은 비-이미지 자산이 Godot import 단계에서 누락 → `ERROR: No loader found for resource: res://assets/fonts/Foo.ttf` → `[gui] theme/custom_font`가 무시되고 한글이 □ 깨짐.

**원인**: lazy fetch 패턴에서 `assets/*/.gdignore`로 자산을 막으면 **폰트/사운드 같은 비-이미지 자산도 다 차단됨**. `.gdignore`는 폴더 단위 비활성화라 파일 종류 무관.

**해결 — lazy fetch 대상과 통합 자산 분리**:
```
assets/
├── units/        ← .gdignore OK (lazy fetch)
├── portraits/    ← .gdignore OK (lazy fetch)
├── audio/        ← .gdignore OK (lazy fetch)
├── fonts/        ← .gdignore 절대 X (빌드 포함 필수)
└── icon.svg      ← .gdignore X
```

**확실한 검증**: `ls .godot/imported/fonts/` → 빈 디렉터리면 차단된 것. `.fontdata`나 `.sample` 파일이 보여야 정상. setup-assets.sh 작성 시 .gdignore 루프를 카테고리 한정으로 (`for d in "$ASSETS_DIR"/units/*/ "$ASSETS_DIR"/portraits/*/ "$ASSETS_DIR"/audio/*/; do touch "$d/.gdignore"; done`). `assets/` 자체엔 절대 안 둠.

**진단법**: `godot --headless --import 2>&1 | grep -E "ERROR|loader"` → `No loader found for resource: res://assets/fonts/*` 등장 시 .gdignore 재확인.

### macOS export 템플릿 다운로드 (2026-07-16 검증 — Godot 4.7+)

Web는 보통 자동 받지만 **macOS/Linux/Windows용 템플릿은 명시 다운로드 필요**. 가장 흔한 신규 함정 3종:

**1. URL은 `godot` 리포 — `godot-builds` 아님**

```bash
TPL_DIR="$HOME/Library/Application Support/Godot/export_templates/4.7.1.stable/"
mkdir -p "$TPL_DIR"
cd "$TPL_DIR"

# 통합 export 템플릿 한 파일에 macOS/Linux/Windows/Android/iOS 모두 포함
curl -L -fsSL -o templates.tpz \
  "https://github.com/godotengine/godot/releases/download/4.7.1-stable/Godot_v4.7.1-stable_export_templates.tpz"

# 플랫폼 zip만 추출 (templates/ 서브폴더 없이 부모로 직접)
unzip -j templates.tpz "templates/macos.zip" -d .
```

- **`-L` (follow redirect) 필수** — 안 붙이면 HTTP 302 → 빈 페이지
- **버전 표기 차이**: URL `4.7.1-stable` (하이픈) vs 디렉터리 `4.7.1.stable` (점) — 다름
- **`unzip -j` 로 `templates/*.zip`을 부모 디렉터리에 직접** (templates/ 서브폴더 있으면 Godot이 못 찾음)

**확인**: `ls "$TPL_DIR"/macos.zip` 123MB 있어야 OK.

**2. ETC2 ASTC 텍스처 압축 비활성화 → macOS export 실패**

Godot 4.7+에서 macOS desktop(.app) export는 ETC2 ASTC 압축 활성 필수:
```
ERROR: ETC2 ASTC 텍스처 형식이 비활성화된 경우 universal 또는 arm64용으로 내보낼 수 없습니다.
프로젝트 설정(렌더링 > 텍스처 > VRAM 압축 > ETC2 ASTC 가져오기)에서 이를 활성화하세요.
```

**해결 — project.godot에 추가**:
```ini
[rendering]

renderer/rendering_method="forward_plus"
textures/vram_compression/import_etc2_astc=true
```

`project.godot` 직접 작성 시 위 줄 추가. 누락 시 어떤 빌드 도움말도 안 나오고 한 줄짜리 메시지만 → 자주 막힘.

**3. bundle_identifier 누락 → "잘못된 번들 식별자" 에러**

`godot --export-release macOS` 시 preset에 `application/bundle_identifier` 안 박으면:
```
ERROR: Cannot export project with preset "macOS" due to configuration errors:
잘못된 번들 식별자: 식별자가 누락되어 있습니다.
```

**해결 — export_presets.cfg에 bundle_identifier + unique_name 둘 다**:
```ini
application/unique_name="org.godotengine.lastbanner"
application/bundle_identifier="org.godotengine.lastbanner"
```

한쪽만 있어도 다른 에러. unique_name과 bundle_identifier는 같은 값으로.

**4. Gatekeeper 차단 경고는 무시 OK**

```bash
ad-hoc 서명을 사용 중입니다. 내보낸 프로젝트는 Gatekeeper에 의해 차단됩니다
공증이 비활성화되어 있습니다.
```

이건 **경고(info)지 에러 아님**. 로컬 개발용이면 무시. Mac App Store 배포 시만 코드 서명 identity 채우면 됨 (별도 `codesign/` 작업).

**5. macOS .app 실행 → 헤드리스 환경에서 5초 내 죽음**

빌드 성공 후 `open "build/macos/Last Banner.app"` 또는 `./Contents/MacOS/Last\ Banner` 직접 실행 → GUI 세션 없는 헤드리스 환경에서는 window 1개도 못 만들어 즉시 quit. stderr/stdout 둘 다 비어있음. **시각 확인은 사용자 Mac 데스크탑 필요**:
- 헤드리스 환경: `LB_VERIFY=1 godot --headless`로 8단계 검증 통과 확인으로 대체
- 사용자 데스크탑: 더블클릭 또는 `open "Last Banner.app"` 후 Cmd+Q로 종료 전 스크린샷 확보

### 한글 폰트 — NanumGothic.ttf (2026-07-16 last-banner-v2 검증)

v1의 `UnDotum.ttf` (FreeCiv)는 game-assets-pool에 **더 이상 안정적 출처 없음**. 다운로드 URL 자주 깨짐.

**확인된 안정 출처**:
```bash
curl -fsSL -o assets/fonts/NanumGothic.ttf \
  "https://github.com/google/fonts/raw/main/ofl/nanumgothic/NanumGothic-Regular.ttf"
# 2MB, TTF, 한국어 + 라틴, SIL OFL 1.1
```

**형식 함정 — 모두 실패 확인 (2026-07-16 last-banner-v2 실전)**:
- **TTC** (Apple SD Gothic Neo 등 macOS 시스템 폰트): Godot 4 직접 로더 없음 → `No loader found for resource` → `theme/custom_font` 무시 → 한글 □ 깨짐
- **OTF** (NotoSansCJKkr-Regular.otf 16MB): 마찬가지 → `No loader found for resource` → 폰트 안 로드
- **TTF but 한글 글리프 없음**: 로딩은 되지만 한글이 □ 깨짐 (v1 함정)

→ **반드시 TTF + 한글 + 라틴 둘 다 포함된 폰트** 사용. NanumGothic.ttf (SIL OFL 1.1, 2MB) 1순위. macOS 시스템 폰트 TTC는 심볼릭 링크로 우회 불가 — 반드시 외부 TTF 파일 다운로드.

**디버그 로직**: `godot --headless --import 2>&1 | grep -iE "(loader|font)"` → `No loader found for resource: res://assets/fonts/*.ttf` 나오면 Godot이 import 단계를 완전히 건너뛴 것. 가능한 원인: ① TTC/OTF 형식 ② `assets/.gdignore` 차단 ③ 파일 자체 깨짐.

`UnDotum.ttf`는 더 이상 1순위 추천 아님.

### Autoload 시그널 race condition — connect 전에 emit (2026-07-16 last-banner 실전)

**증상**: 사용자 화면에서 버튼이 영영 비활성 상태. `AssetRegistry.manifest_loaded` 시그널이 `_on_manifest_loaded`에서 받아야 fetch_button 활성화인데, 자동 진행/사건/결정 큐처럼 **다른 코드 path는 정상 작동**. 시그널 자체는 emit되지만 핸들러가 호출되지 않는 상황.

**원인**: Godot autoload는 main scene보다 먼저 `_ready()`가 호출됨. 다음 순서로 진행:
1. AssetRegistry `_ready()` → `_load_manifest()` → `manifest_loaded.emit()` (즉시)
2. main.tscn의 main.gd `_ready()` → `AssetRegistry.manifest_loaded.connect(...)` (**이미 늦음**)

결과: 시그널은 emit됐는데 아무도 듣지 못함 → 핸들러 미호출 → 버튼 비활성 상태 영속.

**해결 — 2중 안전망**:

```gdscript
# autoload/asset_registry.gd
func _load_manifest() -> void:
    # ... 매니페스트 파싱 ...
    _manifest_ready = true
    # 핵심: call_deferred → 다음 프레임에 emit → main scene이 _ready 끝낼 시간
    call_deferred("_emit_manifest_loaded")

func _emit_manifest_loaded() -> void:
    manifest_loaded.emit()
```

```gdscript
# scripts/main.gd
func _ready() -> void:
    AssetRegistry.manifest_loaded.connect(_on_manifest_loaded)
    # 핵심: 안전망 — 이미 로드됐다면 직접 핸들러 호출
    if AssetRegistry.get_base_url() != "":
        _on_manifest_loaded()
```

**진단법**: main.gd의 `_ready()`에 진단용 print 추가:
```gdscript
print("[Main] autoload manifest_loaded 상태: %s" % str(AssetRegistry.get_base_url() != ""))
```
출력에 매니페스트가 이미 로드됐는데 시그널이 emit됐다고 나오면 race condition 확정.

**자동 검증 모드(LB_VERIFY) 주의**: main.gd의 `_ready()`가 `if _verify_mode: _run_verify(); return`로 early return하면 `@onready` 변수는 평가되지만 `_on_manifest_loaded` 안전망은 호출 안 됨 → 검증에서 시그널 연결 assert 시 `get_connections().size() == 0` 가능. **verify_mode 분기에서는 assert 약화 필요** (`if not _verify_mode: assert(...)`).

상세 디버깅 워크플로우는 `references/autoload-signal-race-condition.md`.

**3중 안전망 (Web 환경에서 2중이 부족할 때)**: `references/three-layer-safety-net.md` — 2026-07-16 last-banner 자산 가져오기 버튼 3회 시도 끝에 안정화. 즉시/call_deferred/타이머 3중 + 핵심 노드 동적 재검색.

### GDScript 시그널 핸들러 인자 미스매치 ERROR (2026-07-15 last-banner 실전)

**증상**: 동일한 핸들러를 여러 시그널에 connect하는데, 시그널마다 인자 개수가 다르면 런타임 ERROR → 흐름 중단 → 헤드리스에서 hang.

**원인 예시**:
```gdscript
# roster.gd
func _on_mercenary_changed(_m = null) -> void:
    if visible: refresh()

GameWorld.mercenary_joined.connect(_on_mercenary_changed)   # 1개 인자
GameWorld.mercenary_left.connect(_on_mercenary_changed)     # 2개 인자 (m, reason)
GameWorld.mercenary_injured.connect(_on_mercenary_changed)  # 1개 인자
```

`mercenary_left.emit(m, reason)` 호출 시 핸들러는 `_m = null` 디폴트가 있어 호출되긴 하지만, 인자 2개를 1개짜리 함수로 보내면 `Method expected N argument(s)` ERROR. ERROR 후 시그널 emit 체인 중단.

**해결 — 모든 핸들러는 모든 인자 디폴트**:
```gdscript
func _on_mercenary_changed(_m = null, _reason: String = "") -> void:
    if visible:
        refresh()
```

`m`만 쓸 거면 `_m`, 안 쓸 거면 `_reason` 처럼 underscore prefix로 명시적 "안 씀" 표시.

**진단법**: stderr에 `ERROR: Method expected N argument(s)`가 catch 포인트. 시그널 connect한 모든 핸들러 grep → 시그널 emit 시그니처와 비교.

### `@onready` 인스턴스화 순서 함정 (2026-07-15 last-banner 실전)

**증상**: `@onready var battle_scene: Control = $BattleScene` 같은 참조가 `Nil`이 됨. `ERROR: Node not found: "BattleScene"`. 검증 모드나 빠른 부팅에서 발생.

**원인**: `@onready` 변수는 `_ready()` 함수가 return하기 전에 평가됨. 인스턴스화 순서에 따라 main scene이 먼저 로드되며, **자기 자신의 자식 노드(@onready로 직접 참조)** 는 평가 시점에 존재하지만 **다른 instanced scene의 루트는 아직 준비 안 됨**.

예: main.tscn에서 `instance=ExtResource("7_battle")` 로 BattleScene을 인스턴스화 → main scene _ready가 BattleScene의 _ready보다 먼저 끝나야 `@onready $BattleScene` 평가 가능. 시점에 따라 실패.

**해결 패턴 — 동적 검색**:
```gdscript
# 잘못된 패턴
@onready var battle_scene: Control = $BattleScene

# 올바른 패턴
var battle_scene: Control = null   # 일반 변수

func _ready() -> void:
    # ... 기타 연결 ...
    call_deferred("_find_battle_scene")   # 다음 프레임에 검색

func _find_battle_scene() -> void:
    battle_scene = get_node_or_null("BattleScene")
```

**장점**:
- 시점 무관 — 다음 프레임엔 무조건 인스턴스화 완료
- 동적 부재 시 null 반환 (기존 `@onready`는 ERROR 후 null)
- 검증 모드에서 호출 안 돼도 안전

**트레이드오프**: 매번 함수 호출 → 코드량 약간 증가. 단, main.gd 같은 단일 호출자에서만 필요.

### Godot tscn 파스 함정 2종 (2026-07-15~16 last-banner 실전)

1. **`Color(r, g, b)` 3인자 거부** — tscn에서 `Color(0.7, 0.9, 1.0)`는 파스 에러. 항상 4인자 `Color(r, g, b, a)`. GDScript 코드에서는 3인자 OK (alpha default 1.0), tscn에서만 다름.

2. **`Label.modulate = Color(...)` 직접 할당 시 파스 에러** — Label은 modulate 자체가 OK인데 다른 컨테이너와 충돌. 차라리 Label은 `theme_override_colors/font_color = Color(...)` 사용. 또는 `modulate` 대신 코드에서 `.add_theme_color_override("font_color", color)` 호출.

3. **잘못된 부모 경로** — L77 파스 에러가 실제로는 L85 잘못된 parent path일 수 있음. `.tscn` 파일 작성 후 `godot --headless --quit-after 3`으로 1차 검증 필수.

4. **PanelContainer 동적 추가 + anchor 미명시 → layout 깨짐 (2026-07-20 last-banner v4.0.1 회귀)**:
   - 증상: Card 안의 자식 VBox가 좌상단 (0,0)에 뭉침, 부모는 full screen인데 자식 사이즈 0
   - 원인: `CenterCard PanelContainer`의 자식 `CenterBox VBoxContainer`의 `anchor_right/bottom`만 명시되고 `anchor_left/top` 기본값 0 → 부모 안에서 사이즈 0
   - 해결: **anchor 4개 모두 명시**하거나, **tscn은 검증된 형태 유지 + UITheme 색상만 동적 적용**
   - **교훈**: PanelContainer 동적 추가/수정 시 anchor 4개 모두 명시. 기존 검증된 tscn 구조 변경 회피
   - **디버깅 패턴**: 헤드리스에서 LB_VERIFY 회귀 후 사용자 데스크탑에서 카드 안에 라벨 안 보임 → z-order 의심 전에 anchor 4개 먼저 검증

5. **GDScript format() 안 되는 케이스**:
   ```gdscript
   # ❌ Dictionary value 안에서 inline format 안 됨
   { "label": "뇌물 (%d골드)". % cost }

   # ✓ 미리 변수에 format 적용 후 삽입
   var label: String = "뇌물 (%d골드)" % cost
   { "label": label }
   ```

6. **GDScript printf 다중 인자 미지원 (2026-07-20 last-banner 발견)**:
   ```gdscript
   # ❌ Parse Error: Expected closing ")" after grouping expression
   print("[X] %s %s" % (a, b))

   # ✓ 어레이 1개로
   print("[X] %s %s" % [a, b])
   ```
   또는 변수로 빼서 `print("[X] %s %s" % [var1, var2])`. 어레이 안 `Variant`는 알아서 String 변환.

7. **GDScript 비공개 파라미터 디폴트 (2026-07-20 last-banner 발견)**:
   ```gdscript
   # ❌ 함수 인자에 `if X else Y` 인라인 — 파서 오류
   foo(value if X else Y, other)

   # ✓ 변수로 빼기
   var v = value if X else Y
   foo(v, other)
   ```
   또는 어레이로 `print("[X] %s %s" % [v1, v2])`. **특히 LB_VERIFY에서 인라인 식 + 함수 호출이 섞이면 무조건 변수 분리**.

8. **GDScript 함수 시그니처 타입 — Control vs CanvasLayer (2026-07-20 last-banner v4.1 모바일 viewport 발견)**:
   ```gdscript
   # ❌ CanvasLayer를 Control 인자로 전달 시 파스 에러
   func adjust_modal(modal: Control, ...): pass
   adjust_modal(my_canvas_layer, ...)  # "argument 1 should be 'Control' but is 'CanvasLayer'"

   # ✓ Node 타입으로 받기
   func adjust_modal(modal: Node, ...): pass
   # CanvasLayer는 Control 상속 X — viewport 자식만 Control
   # 동적 offset 조작은 양쪽 다 .offset_left = X 지원하므로 Node로 충분
   ```

9. **GDScript 파일 읽기 + 부분 매칭 (2026-07-20 last-banner B-5 발견)**:
   ```gdscript
   # ❌ 전체 파일에서 "list_saves" 패턴 검색 → 의도치 않게 매치
   assert(FileAccess.get_file_as_string("res://main.gd").find("list_saves") == -1)

   # ✓ 함수 본문만 추출해서 검색
   var src = FileAccess.get_file_as_string("res://main.gd")
   var idx = src.find("func _on_title_continue")
   var idx_end = src.find("\nfunc ", idx + 1)
   var body = src.substr(idx, idx_end - idx)
   assert(body.find("list_saves") == -1)  # 이제 함수 내부만 검사
   ```
   **특히 LB_VERIFY가 같은 함수를 여러 번 호출할 때, 다른 곳에서 같은 이름이 나타나면 false positive**. 항상 함수/섹션 경계로 추출.

10. **GDScript 변수명 중복 (2026-07-20 last-banner LB_VERIFY 다단계 누적 발견)**:
    - `_run_verify` 한 함수 안에서 LB_VERIFY 단계를 [8.1] → [8.2] → ... [8.14]까지 누적하면 변수명 충돌 발생
    - **규칙**: 각 단계별 prefix 사용 (예: `saves1`, `saves2`, `saves_after2`) 또는 함수 분리
    - 처음부터 [8.14]까지 작성 시 변수명 namespace 분리: `phase1_*`, `phase2_*` 또는 section별 고유 prefix
    - **자주 쓰는 prefix 패턴**: `saves1/2/3` (저장 슬롯 단계), `gold_pre_* / food_pre_*` (자원 변동), `*_before/*_after` (before/after 비교)

11. **viewport 검증 임계값 함정 — 표준 디바이스 사이즈와 임계값 미스매치 (2026-07-20 last-banner v4.1 B-4 발견)**:
    - LB_VERIFY에서 `MOBILE_VIEWPORT_THRESHOLD = 800`인데 **iPad 가로 (1024×768)도 데스크탑 모드로 분류** → 모바일 offset 적용 안 됨
    - 검증 의도 = "태블릿 1024×768도 모바일 offset으로 가야 한다"였다면 임계값을 1100+으로 올려야 함
    - **해결 패턴 2가지**:
      1. **임계값을 의도한 모든 디바이스 포함**: `const MOBILE_VIEWPORT_THRESHOLD := 1100` → 1024도 모바일
      2. **검증 사이즈를 임계값 안에 있는 디바이스로 선택**: 태블릿 검증은 `Vector2(768, 1024)` (iPad mini 세로) — 임계값 800 미만
    - **선택 기준**: 프로젝트가 어떤 디바이스를 "모바일/태블릿"으로 분류하느냐. 800 = 폰 + 작은 태블릿, 1100 = 큰 태블릿 포함, 1280+ = 데스크탑만. 게임의 UI 복잡도에 따라 조정.

12. **단일 슬롯 정책 — 다중 슬롯 UI 없는 시스템 = 사고 (2026-07-20 last-banner v4.1.0 발견)**:
    - **증상**: `SaveManager.save_game(slot: String)`이 String 인자라 사실상 무제한 슬롯 생성 가능. LB_VERIFY가 7개 verify_* 슬롯을 만들면 title_screen에 "이어하기 (9개 저장)" 표시 → 사용자 혼란
    - **원인**: 시스템이 다중 슬롯을 허용하면서 UI는 슬롯 선택 안 함 = 1슬롯으로 사용하지만 화면에는 9개 노출
    - **해결 — 단일 슬롯 정책**:
      ```gdscript
      const SAVE_SLOT := "autosave"  # 단일 슬롯
      func save_game(_slot: String = SAVE_SLOT) -> bool:  # 인자 무시
          var path := "user://save_%s.json" % SAVE_SLOT
          # ... 항상 autosave로 저장
      func has_save() -> bool:  # autosave 존재 여부
          return FileAccess.file_exists("user://save_%s.json" % SAVE_SLOT)
      func delete_save() -> bool:  # 새 게임 시작 시
          # ...
      func list_saves() -> Array:  # 0 또는 [autosave] (호환성)
          if has_save(): return [SAVE_SLOT]
          return []
      ```
    - **자동 정리 (1회)**: 첫 실행 시 `_cleanup_legacy_slots()`가 verify_* 등 자동 삭제
    - **UI 단순화**: "이어하기" 또는 "저장 없음" 단일 표현
    - **판단 기준**: 슬롯 선택 UI가 없으면 단일 슬롯이 정답. 다중 슬롯이 필요하면 **반드시 슬롯 선택 UI** (ListBox/OptionButton 등) 제공

13. **`# 8.10` 튜토리얼 검증 — `seen` 분기 검증의 hidden state 함정 (2026-07-20 last-banner v4.1.0 B-1 발견)**:
    - "seen=true 시 skip" 분기를 검증하려고 `GameManager.tutorial_seen = true`로 set 후 `start_tutorial(false)` 호출 → `if not force and seen` → return → visible 그대로
    - **문제**: 직전 단계의 `start_tutorial(false)` (seen=false → 진입 → visible=true)에서 끝나고, `_on_next_pressed()`로 step 진행 중 (current_step=1~3) → seen 분기 호출 시 visible은 여전히 true
    - **원인**: 분기 호출 전 `_finish_tutorial`이 호출된 적이 없다. 사용자가 step을 끝까지 진행한 게 아님
    - **해결 — 명시적 close**:
      ```gdscript
      # ❌ 가정 오류
      GameManager.tutorial_seen = true
      tutorial.start_tutorial(false)
      assert(not tutorial.visible)  # FAIL — visible=true (직전 단계에서 close 안 됨)

      # ✓ 명시적 close 후 분기 검증
      tutorial._on_skip_pressed()  # _finish_tutorial 강제 트리거
      assert(not tutorial.visible)
      GameManager.tutorial_seen = true
      tutorial.start_tutorial(false)
      assert(not tutorial.visible)  # OK — seen 분기로 skip
      ```
    - **일반화 — LB_VERIFY 분기 검증 시 가시 상태는 명시적 close 보장 후 검증**. 모달/오버레이/사운드 모두 동일 패턴.

14. **AudioManager 헤드리스 가드 — `DisplayServer.get_name()` (2026-07-20 last-banner v4.1.0 B-2 실전)**:
    ```gdscript
    # autoload _ready()에서
    _enabled = DisplayServer.get_name() != "headless"
    if not _enabled:
        return  # play_bgm/play_sfx가 no-op
    # 자산 없으면
    if not ResourceLoader.exists(BGM_TRACKS["menu"]):
        _enabled = false
        return
    # play_xxx() 호출 시
    if not _enabled: return  # 가드
    ```
    - **이중 가드**: 헤드리스 환경 + 자산 미존재. 두 조건 모두 OK일 때만 실제 재생
    - **LB_VERIFY 안전**: 헤드리스에서 play_bgm/play_sfx 호출해도 크래시 없음 (단순 return)
    - **macOS GUI 세션에서**: `DisplayServer.get_name()` = "macos" 등 실제 디스플레이 이름 반환

### 모바일 / 모바일 세로 viewport anchor 레이아웃 함정 (2026-07-15)
**증상**: 데스크탑(1280x720)에서는 정상 UI, 모바일 세로(예: iPhone 1290x2325)에서는 **컨텐츠가 화면 밖으로 나가서 검은 화면처럼 보임**. 디버그 pane의 canvas rect는 정상 큰데 픽셀이 검은색.

**원인**: `offset_left=24, offset_top=600` 같은 절대 좌표는 viewport_width/height에 종속. 모바일 세로에서는 컨트롤이 viewport 아래/우측 밖에 위치.

**Fix**: 모든 Control의 위치는 **anchor 비율 (0~1)** 사용. Control은 Anchor가 기본값 (0,0,0,0)인데 모바일에서는 다음 패턴이 안전:
```
[node name="ButtonRow" type="VBoxContainer" parent="UI"]
anchor_left = 0.5; anchor_top = 0.55
anchor_right = 0.5; anchor_bottom = 0.95
offset_left = -200; offset_right = 200    # 폭만 픽셀 지정
offset_top = 0; offset_bottom = 0
```
- `BG ColorRect`: `anchor_right = 1.0; anchor_bottom = 1.0` → 화면 전체 cover
- `Label/Button`: `anchor_left = right = 0.5` + `offset_left = -width/2` → 가로 중앙 정렬
- `VBoxContainer`로 버튼 묶기 → 모바일 세로에서 버튼들이 세로 스택
- `custom_minimum_size = Vector2(0, 64)` → 버튼 최소 높이 보장 (모바일 탭 영역)

`project.godot`의 `window/stretch/mode="canvas_items"` + `aspect="expand"`는 유지 (Control 비율 stretch는 별개로 anchor로 처리).

### status div 부팅 후 덮음 함정 (2026-07-15)
**증상**: `Engine.getMissingFeatures()`가 비어 있고 모든 시스템 OK인데 화면이 검은색. `#status` div가 부팅 후에도 `visibility:visible` 상태로 남아 캔버스 위에 검은 div를 덮음.

**원인**: Godot 4 Web export의 `index.html`에 `#status` div가 부팅 진행률 표시용으로 있는데, 모바일 환경에서 `Engine.start()`가 정상 완료해도 status div의 visible 토글이 안 풀리는 경우가 있음 (특히 lazy fetch 매니페스트 로드 후 추가로 동기 작업 발생 시).

**Fix — `inject-debug-pane.sh`에 CSS 강제 추가**:
```css
#status { display: none !important; visibility: hidden !important; pointer-events: none !important; }
#status-notice, #status-progress { display: none !important; visibility: hidden !important; }
```
사용자가 진단 pane의 텍스트를 회신할 때 status div가 진짜 원인 가리개를 안 하고 있도록. 진단 끝난 후에도 CSS는 그대로 두면 OK (status div는 부팅 후 사실상 미사용).

### 한글 폰트 미적용 함정 (2026-07-15)
**증상**: 게임 UI는 정상 렌더링되고 메뉴/버튼이 보이는데 **모든 한글이 □ 깨짐**. 영문/숫자는 정상.

**원인**: Godot 4 기본 폰트(NotoSans fallback)는 한국어 글리프 미포함. 모바일 Web export에서 `renderer/rendering_method.mobile="gl_compatibility"` fallback 시 더 두드러짐. `project.godot`의 `[gui] theme/custom_font=...`는 4.7에서 일관성 없게 작동.

**Fix — main.gd의 `_ready()`에서 모든 Control에 재귀 적용** (가장 확실):
```gdscript
const KOREAN_FONT := preload("res://assets/fonts/UnDotum.ttf")

func _ready() -> void:
    var theme := Theme.new()
    theme.default_font = KOREAN_FONT
    theme.default_font_size = 24
    _apply_theme_recursive(self, theme)

func _apply_theme_recursive(node: Node, theme: Theme) -> void:
    if node is Control:
        (node as Control).theme = theme
    for child in node.get_children():
        _apply_theme_recursive(child, theme)
```
- 폰트 추천: `UnDotum.ttf` (FreeCiv 2.1MB, 한글+라틴) — 게임 풀에 흔히 있음
- `preload()`는 빌드 시 pck에 폰트 포함 (런타임 fetch 불필요)
- `default_font_size = 24` 권장 (모바일 가독성, PC에서는 약간 큼)
- `Label.autowrap_mode=2` (off)면 멀티라인 안 보임 → `3` (arbitrary) 또는 영역 충분히 키우기

**pck 크기 영향**: UnDotum.ttf 2.1MB 추가 → pck 1.9MB. Vercel 100MB 한도 안전.

### 캔버스 픽셀 검증 패턴 (원격 진단)
원격 사용자 디버깅 시 `canvas.getImageData`로 **실제 게임 씬이 그려졌는지** 검증:
```js
var probe = document.createElement('canvas');
probe.width = 32; probe.height = 32;
var pctx = probe.getContext('2d');
pctx.drawImage(document.getElementById('canvas'), 0, 0, 32, 32);
var data = pctx.getImageData(0, 0, 32, 32).data;
var nonBlack = 0;
for (var i = 0; i < data.length; i += 4) {
    if (data[i] > 10 || data[i+1] > 10 || data[i+2] > 10) nonBlack++;
}
// nonBlack=0/1024 = 모든 픽셀 검정 = 게임 씬 안 그려짐 (status div 덮음 등)
```
`inject-debug-pane.sh`의 `dumpState()`에 위 코드 추가 → 사용자 디버그 pane에 `canvas non-black pixels: 0/1024` 같은 한 줄 출력.

### 자산 / 풀 연결
- **`/Applications/Godot.app`이 homebrew cask로 깔리면 `godot` 심볼릭 링크가 `/opt/homebrew/bin/`에 생김**. CLI 사용 시 `godot --path ~/work/foo`.
- **풀에서 `.git` 폴더는 절대 게임 프로젝트로 링크하지 말 것**. `.gitignore`로 한 줄 차단.
- **Wesnoth units는 공격/방어 프레임 PNG가 많다**. base idle 포즈만 쓰려면 `-attack-/-defend-/-melee-/-ranged-/-mounted-/-die-` 패턴 grep 제외.
- **Wesnoth portraits는 `.webp` 형식 (png 아님)**. Godot 4는 webp 임포트 가능 (확인됨).
- **KayKit GLB는 `addons/<pack>/<Category>/gltf/*.glb` 구조**. top-level은 git subtree.
- **Doficia cord-sprites / gmgeo-osmic 등은 풀에서 fetch (curl/wget) → ZIP 풀기**. `tools/fetch-cc0-assets.sh` 패턴 참고.
- **`.gdignore`는 Godot import만 차단, git 추적은 유지** → lazy fetch용으로 자산은 그대로 git에 push하되 pck에서만 빠짐.

### export templates
- **빈 폴더에 export templates unpkg 후 `templates/` 서브폴더에 들어가 있으면 Godot이 못 찾음**. zip을 직접 부모 디렉터리로 옮길 것:
  ```bash
  cd "$HOME/Library/Application Support/Godot/export_templates/<버전>.stable/"
  mv templates/web_*.zip .   # templates/ 없이 직접
  ```
- **`export_presets.cfg`의 bool 값은 소문자** (`false`, `true`만). Python 자동 생성 시 `False` 들어가면 `Unexpected identifier 'False'` 에러.

### 결정 큐 / 자동 진행
- **CRITICAL이 아니면 자동 진행 멈추지 않음**. `DecisionQueue.has_pending_critical()` 체크는 `TimeManager._process` 안에서.
- **`process_mode = Node.PROCESS_MODE_ALWAYS`** 잊으면 GameManager.PAUSED에서 시계도 정지함.
- **`advanced_options=true` + `script_export_mode=2` (binary)** — 텍스트 export 시 PCK 누락.

### 자동 진행 속도 + 이벤트 간격 곱 비례 (2026-07-16 last-banner-v2.1.1 실전)

`SECONDS_PER_GAME_MINUTE`를 올려서 게임 진행 속도 빠르게 → **이벤트 간격도 비례 조정 필수**. 안 그러면 real time에서 이벤트 폭주.

```gdscript
# 속도 60배 빠르게 (1초 real = 60분 game, 1일 = 60초) — 이때 이벤트 간격도 5배 늘리기
const SECONDS_PER_GAME_MINUTE := 1.0 / 60.0
const RECRUIT_VISITOR_INTERVAL_MIN := 1200  # 4h → 20h (real 4초 → 20초)
const FOOD_CHECK_INTERVAL_MIN := 2400        # 8h → 40h
const DIPLOMACY_INTERVAL_MIN := 2400         # 8h → 40h
const DECISION_MAX_PER_DAY := 8              # 3 → 8 (빠른 속도에 맞춰 cap 증가)
```

**핵심 통찰**: 게임 시간 의미(4h = 4시간)는 동일, real time 빈도만 적정 수준으로. **속도 ↑ = 인터벌 ↑** 곱 비례. `DECISION_MAX_PER_DAY`가 폭주 안전장치.

**LB_VERIFY [2.5] 헤드리스 속도 검증** — `await get_tree().create_timer(1.0).timeout`은 헤드리스에서 hang 가능 → **직접 시뮬**:
```gdscript
var min_before = TimeManager.minutes_elapsed
TimeManager._process(1.0)   # 1초 시뮬레이션
var advance = TimeManager.minutes_elapsed - min_before
assert(advance >= 55 and advance <= 65, "1초 real = 60±5분 game")
```

자세한 패턴 (권장 속도 매트릭스 / 안티패턴 4종): `references/auto-progress-speed-tuning.md`.

### 캐릭터 마우스 인터랙션 — **Control 부모 = TextureButton** 정답 (2026-07-16 last-banner-v2.3.1 실전)

**v2 교훈 (가장 중요한 발견)**: Area2D + Sprite2D 조합은 **Sprite 부모**에서만 작동. **Control 부모 안에서는 마우스 이벤트가 자식 Area2D로 안 전달**되어 호버/클릭이 작동하지 않음.

**해결 — `TextureButton` (Control 기반)**: Control 부모와 같은 input dispatcher라 Control 호환 보장.

```gdscript
# 각 캐릭터 = TextureButton 1개
var btn := TextureButton.new()
btn.texture_normal = tex
btn.texture_pressed = tex
btn.texture_hover = tex
btn.texture_focused = tex
btn.ignore_texture_size = true
btn.position = pos - Vector2(tex.get_width() * scale / 2.0, tex.get_height() * scale / 2.0)
btn.size = Vector2(tex.get_width() * scale, tex.get_height() * scale)
btn.custom_minimum_size = btn.size
btn.mouse_filter = Control.MOUSE_FILTER_STOP
scene_root.add_child(btn)

btn.mouse_entered.connect(_on_hover.bind(character))
btn.mouse_exited.connect(_on_unhover.bind(character))
# 클릭 안 쓸 거면 pressed 시그널 의도적으로 연결 안 함 (사용자 명세 v2.3.2)
```

**판단 기준**:

| 부모 | 마우스 인터랙션 정답 | 이유 |
|---|---|---|
| **Control 부모** (ex: ManorScene > SceneHost) | **TextureButton** | 같은 Control 트리 — input dispatcher 통합 |
| **Node2D 부모** (ex: 게임 월드 자유 카메라) | Area2D + RectangleShape2D | sprite가 Node2D라 Area2D wrap 필요 |
| **둘 다** (ex: Node2D + Control 자식) | 둘 다 시도 가능하지만 Control 호환 우선 | 사용자 PC 호환성 ↑ |

**TextureButton 미존재 속성 함정 (검증됨)**: 다음 속성은 TextureButton에 존재하지 않아 `Invalid assignment of property` 에러:
- `btn.stretch = true` ❌ (존재하지 않음)
- `btn.expand_icon = true` ❌ (존재하지 않음)
- 해결: 그냥 빼고 `ignore_texture_size` + `size`/`custom_minimum_size` 설정이 충분.

**호버 시 1.08배 확대 — `pivot_offset + scale` 권장 (누적 drift 없음)**:
```gdscript
# 생성 직후 1회
btn.pivot_offset = btn.size * 0.5

func _on_hover(character: Dictionary) -> void:
    var button: TextureButton = character["button"]
    button.pivot_offset = button.size * 0.5
    button.scale = Vector2(1.08, 1.08)

func _on_unhover(character: Dictionary) -> void:
    character["button"].scale = Vector2.ONE
```
`size`/`position`을 건드리지 않으므로 호버 반복에도 좌상단 누적 이동이 없다. 크기 자체를 바꿔야 하는 특수 상황이면 생성 직후 `original_position`과 `original_size`를 절대값으로 1회 저장하고, unhover 때 둘 다 절대 복원한다. `current position - delta/2` 식 누적 보정은 금지.

**호버 + 클릭 안 함 (사용자 명세 v2.3.2 — 2026-07-16)**: 사용자가 "클릭은 빼라니까" 명시 후 다음 패턴:
- `mouse_entered` → 상태창 표시 + sprite 확대
- `mouse_exited` → 상태창 자동 숨김 + sprite 축소
- `pressed` 시그널 의도적으로 연결 안 함

**라벨 처리**: TextureButton의 자식이 아닌 형제 노드로 두면 클릭 이벤트와 무관 (TextureButton만 STOP, 라벨은 IGNORE).

자세한 패턴: `references/character-click-interaction-area2d.md`.

### 풍경도 시간대 그라디언트 — ColorRect + Color.lerp (2026-07-16 last-banner-v2.3)

매 게임 분마다 풀밭 + 흙길 색 보간:

```gdscript
const SCENE_BG_DAY := Color(0.32, 0.36, 0.22, 1)
const SCENE_BG_NIGHT := Color(0.06, 0.07, 0.14, 1)
const SCENE_BG_DAWN := Color(0.32, 0.22, 0.22, 1)
const SCENE_BG_DUSK := Color(0.32, 0.18, 0.12, 1)

func _update_time_of_day_colors() -> void:
    var hour: int = (TimeManager.minutes_elapsed % 1440) / 60
    var bg: Color
    if hour >= 5 and hour < 8:        # 새벽
        var t: float = float(hour - 5) / 3.0
        bg = SCENE_BG_DAY.lerp(SCENE_BG_DAWN, t)
    elif hour >= 8 and hour < 17:    # 낮
        bg = SCENE_BG_DAY
    elif hour >= 17 and hour < 20:    # 노을
        var t2: float = float(hour - 17) / 3.0
        bg = SCENE_BG_DAY.lerp(SCENE_BG_DUSK, t2)
    else:                            # 밤
        bg = SCENE_BG_NIGHT
    bg_color_rect.color = bg
```

**연결**: `TimeManager.tick_advanced.connect(_update_time_of_day_colors)` — 1초 real = 60분 게임 = 1 게임 분마다 색 미세 변화.

**LB_VERIFY 헤드리스 한계**: `_update_time_of_day_colors()`를 직접 호출 + `TimeManager.minutes_elapsed` 직접 set → 색 변화 검증.

자세한 패턴: `references/control-colorrect-time-of-day-gradient.md`.

### 결정 큐 모달 — 자동 진행 ON/OFF 분기 (희정님이 직접 선택한 UX, 2026-07-16 v2.1.0)

**v1 패턴**: HIGH/CRITICAL만 모달 띄움, LOW/MEDIUM은 알림만 → 사용자가 모르는 사이 결정 큐 30+건 쌓여 답답함.

**v2 패턴** (모든 우선순위 모달): 모든 우선순위 모달 띄움 + LOW만 3초 자동 skip.

**v2.1.0 패턴** (자동 진행 ON/OFF 분기): **자동 진행 상태가 모달 동작을 완전히 결정**.

```gdscript
# main.gd _show_next_decision()
func _show_next_decision() -> void:
    for d in DecisionQueue.get_all_pending():
        if d.id > _current_decision_id:
            _current_decision_id = d.id
            _populevate_modal(d)
            decision_modal.visible = true
            # 핵심: 자동 진행 ON일 때만 타이머 걸기
            if TimeManager.auto_progress_enabled:
                var delay: float = 3.0 if d.priority == DecisionQueue.Priority.LOW else 5.0
                _auto_skip_timer = get_tree().create_timer(delay)
                _auto_skip_timer.timeout.connect(_on_auto_skip)
            # OFF면 타이머 미설정 → 무한 대기
            return

# 자동 결정 콜백 — OFF면 첫 줄에서 즉시 return
func _on_auto_skip() -> void:
    if not TimeManager.auto_progress_enabled:
        return  # OFF면 안 닫음 (사용자 결정 대기)
    # ... default 결정 + resolve + 모달 닫기
```

**동작 매트릭스**:

| 자동 진행 | 모든 우선순위 모달 표시 | 타이머 설정 | default 결정 |
|---|---|---|---|
| **ON** | ✅ | LOW 3초 / 그 외 5초 | 자동 (VISITOR_REJECT 등) |
| **OFF** | ✅ | ❌ (설정 안 함) | 사용자 직접 클릭 |

**핵심 디자인 결정**:
- **모든 우선순위 모달** — 답답함 해소. 사용자가 매 결정 인지
- **자동 진행 OFF면 모달 무한 대기** — 사용자가 명시적으로 결정할 때까지 게임 멈춤
- **자동 진행 ON이면 default 결정 자동 적용** — 위임한 사용자는 게임 흐름 방해 X
- **`_on_auto_skip` 첫 줄의 OFF 가드** — 혹시 외부에서 호출되어도 안전 (LB_VERIFY 타이밍 race 포함)
- **상단 자원바의 "대기 결정 N건" 카운터 제거** — 모달이 유일한 알림 채널 (자동 OFF에서 누적 안 보이는 것 OK, 모달 떠있음)

**default 결정** (자동 ON일 때 자동 처리):
- `VISITOR` (LOW) → `VISITOR_REJECT` (명성 -2)
- `FOOD_SHORTAGE` MEDIUM → `FOOD_RATION` (명성 -5)
- `FOOD_SHORTAGE` CRITICAL (food < 15) → `FOOD_BUY` (골드 -50, 식량 +30, 사용자 보호)
- `DIPLOMACY` (MEDIUM) → `DIPLOMACY_REFUSE` (명성 -5)

**사용자가 선택지를 클릭할 때** (`_on_choice_pressed`):
- 자동 진행 상태 무관 — 항상 즉시 모달 닫힘 + 선택 결과 적용
- 3초 타이머 콜백이 그 사이에 호출되어도 `_current_decision_id < 0` 가드로 자동 결정 안 함

**LB_VERIFY 검증 단계 추가**:
```gdscript
# [10] OFF 무한 대기 — auto_progress_enabled = false로 전환 후 모달 띄움 → _on_auto_skip 호출해도 모달 유지
# [11] ON 자동 닫힘 — auto_progress_enabled = true로 전환 → 새 LOW push → _on_auto_skip 호출 후 모달 닫힘
```

**EventEngine 다양화**: 7일 시뮬 후 결정 큐 분포는 자연스럽게 다양해짐. 5개 시나리오 (VISITOR LOW + DIPLOMACY MEDIUM + FOOD_SHORTAGE MEDIUM/CRITICAL + PEASANT_PETITION LOW + BANDIT_RAID HIGH)를 골고루 push하면 분포는 `{LOW: 12, MEDIUM: 5, HIGH: 2}` 같은 모양. LOW만 push하면 답답해지고, HIGH만 push하면 자동 진행이 자꾸 멈춤.

**UI 디자인 한 줄**: 결정 큐 카운터(상태바) 제거 — 모달이 유일한 알림. OFF 상태에서 사용자에게 "결정 안 함 → 게임 진행 X"가 시각적으로 명확. "대기 결정 N건" 같은 텍스트는 **모달이 안 뜨면 안 뜨는 거 자체가 정상**이라 정보 가치가 적음 (특히 자동 ON에서는 어차피 자동 처리됨).

### CanvasLayer z-order — 모달/오버레이 가려짐 함정 (2026-07-16 last-banner-v2)

**증상**: 결정 큐 모달이 push됐는데 화면에 안 보임. 헤드리스 검증은 모두 통과 (`ready`, `push`, `print` 작동) + stderr에 `[Modal] 표시: id=N` 로그까지 나오는데 사용자 스크린샷엔 안 보임.

**원인**: 모달 `CanvasLayer` (또는 Control)가 대시보드 `Control`과 같은 z-level이라 자식 추가 순서/트리 위치로 가려짐. v2 사례로는:
- `ManorDashboard` (Control, Main의 직접 자식 — CanvasLayer 없음)
- `DecisionModal` (Control, UI CanvasLayer의 자식)

두 노드 모두 root 레이어 0에서 그려짐. UI CanvasLayer가 **먼저** 인스턴스화되어 ManorDashboard가 **위**에 그려져 모달을 가림.

**해결 핵심**: 모달은 **별도 `CanvasLayer layer=100`** 으로 분리. 기존 dashboard/hud는 `layer <= 0`. 한 줄 패턴.

```ini
[node name="ManorLayer" type="CanvasLayer" parent="."]   ; layer=0
[node name="ManorDashboard" parent="ManorLayer" instance=ExtResource("2_dash")]

[node name="ModalLayer" type="CanvasLayer" parent="."]    ; layer=100 ← 핵심
[node name="DimBG" type="ColorRect" parent="ModalLayer"]
anchor_right = 1.0; anchor_bottom = 1.0
color = Color(0, 0, 0, 0.7)
visible = false
mouse_filter = 0

[node name="DecisionModal" type="PanelContainer" parent="ModalLayer"]
visible = false
anchor_left = 0.5; anchor_top = 0.5; anchor_right = 0.5; anchor_bottom = 0.5
offset_left = -360.0; offset_top = -180.0; offset_right = 360.0; offset_bottom = 180.0
mouse_filter = 0
```

**GDScript 동적 노드 검색 — 절대 경로** (`UI` CanvasLayer 안에 있지 않음):
```gdscript
modal_dim_bg = get_node_or_null("ModalLayer/DimBG") as ColorRect
decision_modal = get_node_or_null("ModalLayer/DecisionModal") as PanelContainer
```

**모달 열기/닫기 — DimBG 동기 토글** (둘 다 visible=true/false):
```gdscript
func _show_next_decision() -> void:
    if modal_dim_bg: modal_dim_bg.visible = true
    decision_modal.visible = true
    # ...

func _close_modal() -> void:
    if decision_modal: decision_modal.visible = false
    if modal_dim_bg: modal_dim_bg.visible = false
```

**진단 4단계**: ① `decision_modal = get_node_or_null(...)` not null 확인 ② `print("[Modal] 표시")` 로그 확인 ③ LB_VERIFY 헤드리스에서 `assert(decision_modal.visible)` 통과 ④ 사용자 데스크탑 스크린샷에서 안 보임 → z-order 100%.

**권장 패턴**: 모든 오버레이 (모달, 풀스크린 트랜지션, 풀스크린 토스트) → **별도 `CanvasLayer layer >= 100`**. 기존 dashboard/hud는 `layer <= 0`. 이 규칙 한 줄이면 z-order 충돌 0.

자세한 진단 + 4단계: `references/canvaslayer-z-order-overlay-pitfall.md`.

### SubViewport vs 단순 Control > Node2D (2026-07-16 last-banner-v2)

**증상**: 풍경도 Panel 안에 SubViewportContainer + SubViewport + Node2D (SceneRoot) 구성으로 Sprite2D 5개 배치 → LB_VERIFY에서 sprite_count == 5 모두 PASS, .ctex import 모두 정상 → 사용자 화면에 **픽셀 0개 표시**.

**원인 후보**: SubViewportContainer stretch 옵션, render_target_update_mode 값, SubViewport size vs Container size 불일치 등. 디버깅에 시간 쓰지 말고 — **단순 트리로 회귀**.

**해결 — Control > Node2D 단순 트리**:
```ini
[node name="ManorScene" type="PanelContainer" parent="CenterRoot/LeftColumn"]
size_flags_vertical = 3

[node name="SceneHost" type="Control" parent="CenterRoot/LeftColumn/ManorScene"]
anchor_right = 1.0; anchor_bottom = 1.0
mouse_filter = 2                                ; MOUSE_FILTER_IGNORE

[node name="SceneRoot" type="Node2D" parent="CenterRoot/LeftColumn/ManorScene/SceneHost"]
```

스크립트가 `SceneRoot`(Node2D)에 `Sprite2D × N + ColorRect × N + Label × N` 직접 add_child. Control 위의 Node2D는 **position이 Control 좌표 그대로** 동작. 카메라/스크롤 인터랙션 없는 정적 풍경도에선 SubViewport가 오버엔지니어링.

**판단 기준**:

| 인터랙션 | 구조 |
|---|---|
| 캐릭터 클릭만 | **Control > Node2D** (단순) — 권장 |
| 풍경도 드래그 패닝 | SubViewport |
| 줌 + 패닝 + 미니맵 | SubViewport + Camera2D |
| viewport-to-texture 머티리얼 | SubViewport |

### GDScript `printf("%s %s", a, b)` 인자 목록 함수 호출 미지원 (2026-07-16)

**증상**: `print("[X] %s %s" % (a, b))` 사용 시 `Parse Error: Expected closing ")" after grouping expression`.

**원인**: GDScript는 `printf` 스타일의 가변 인자를 지원하지 않음. `%` 연산자는 **항상 어레이 1개**만 받음.

**해결**:
```gdscript
# ❌ Parse error
print("[X] %s %s" % (a, b))

# ✓ 어레이로
var arr := [a, b]
print("[X] %s %s" % arr)
# 또는 인라인 (가장 흔한 패턴)
print("[X] %s %s" % [a, b])
```

**중요**: 어레이 안 `Variant`는 알아서 String으로 변환. 다중 인자가 필요할 땐 미디 변수/딕셔너리로 만들어 1개 객체로 전달.

### Wesnoth PNG 팔레트 인덱스 자동 처리 OK (2026-07-16)

**증상 우려**: Wesnoth 2D PNG는 `8-bit colormap` (=팔레트 인덱스) 형식이라 Godot이 처리 못 할까 봐 우려.

**실제**: Godot 4.7의 PNG 로더가 팔레트 인덱스 PNG를 자동 RGBA 디코딩. `.import` 파일이 정상 생성되고 `load()` → `Texture2D` 그대로 사용 가능. 추가 작업 불필요.

**검증**:
```bash
ls .godot/imported/bowman*   # → bowman.png-XXX.ctex + bowman.png-XXX.md5
file assets/units/human-loyalists/bowman.png
# → PNG image data, 72 x 72, 8-bit colormap, non-interlaced (OK)
```

**다른 Wesnoth 함정 (실전 검증)**:
- 크기 = `72 x 72`, 8-bit colormap — Godot이 자동 처리 OK
- 공격/방어 프레임은 항상 `-attack-N`/`-defend-N` 패턴 — `setup-assets.sh`의 grep `case`로 제외
- 포트레이트는 `.webp` — Godot 4 webp 임포트 OK
- `ColorMap.png`는 단순 테스트 카드 (70×56, 747바이트) — 사용 안 함

상세: `references/wesnoth-2d-idle-png-selection.md`.

### 결정 큐 모달 — 모든 우선순위 모달 표시 + LOW 3초 자동 skip (2026-07-16 last-banner-v2)

**v1 패턴**: HIGH/CRITICAL만 모달 띄움, LOW/MEDIUM은 알림만 → 사용자가 모르는 사이 결정 큐 30+건 쌓여 답답함.

**v2 패턴** (희정님 직접 선택한 UX): **모든 우선순위 모달 표시**, **LOW는 3초 타이머로 자동 skip** ("건너뛰기").

```gdscript
# main.gd _show_next_decision()
func _show_next_decision() -> void:
    for d in DecisionQueue.get_all_pending():
        if d.id > _current_decision_id:
            _current_decision_id = d.id
            _populate_modal(d)
            decision_modal.visible = true
            # LOW만 3초 자동 skip
            if d.priority == DecisionQueue.Priority.LOW:
                _auto_skip_timer = get_tree().create_timer(3.0)
                _auto_skip_timer.timeout.connect(_on_low_auto_skip)
            return

func _on_low_auto_skip() -> void:
    if _current_decision_id < 0 or not decision_modal or not decision_modal.visible:
        return
    var default_choice := _default_low_choice(_current_decision_id)
    if default_choice != "":
        _apply_result(default_choice)
    DecisionQueue.resolve(_current_decision_id, {"id": "auto_skip", "label": "(자동 건너뛰기)"})
    _current_decision_id = -1
    if decision_modal: decision_modal.visible = false
    GameManager.resume_from_decision()

func _default_low_choice(decision_id: int) -> String:
    for d in DecisionQueue.get_all_pending():
        if d.id == decision_id:
            match d.type:
                "VISITOR": return "VISITOR_REJECT"
                "FOOD_SHORTAGE": return "FOOD_RATION"
                "DIPLOMACY": return "DIPLOMACY_REFUSE"
                _: return ""
    return ""
```

**핵심 디자인 결정**:
- **모든 우선순위 모달** — 답답함 해소. 사용자가 매 결정 인지
- **LOW만 3초 자동 skip** — 결정 큐 spam 방지. 사용자가 안 보면 "거절" 기본값으로 빠르게 통과
- **MEDIUM/HIGH/CRITICAL은 무한 대기** — 사용자 결정 필수
- **자동 skip 콜백이 `_current_decision_id >= 0` 가드** — 사용자가 3초 전에 직접 골랐으면 자동 skip 안 함

**EventEngine 다양화**: 7일 시뮬 후 결정 큐 분포는 자연스럽게 다양해짐. 5개 시나리오 (VISITOR LOW + DIPLOMACY MEDIUM + FOOD_SHORTAGE MEDIUM/CRITICAL + PEASANT_PETITION LOW + BANDIT_RAID HIGH)를 골고루 push하면 분포는 `{LOW: 12, MEDIUM: 5, HIGH: 2}` 같은 모양. LOW만 push하면 답답해지고, HIGH만 push하면 자동 진행이 자꾸 멈춤.

### SubViewport vs 단순 Control > Node2D (2026-07-16 last-banner-v2 실전 함정)

**증상**: 풍경도 Panel 안에 SubViewportContainer + SubViewport + Node2D (SceneRoot) 구성으로 Sprite2D 5개 배치 → LB_VERIFY에서 sprite_count == 5 모두 PASS, .ctex import 모두 정상 → 그런데 사용자 화면에 **픽셀 0개 표시**.

**원인 후보**: SubViewportContainer stretch 옵션, render_target_update_mode 값, SubViewport size vs Container size 불일치 등. 디버깅에 시간 쓰지 말고 — **단순 트리로 회귀**.

**해결 — Control > Node2D 단순 트리**:
```ini
[node name="ManorScene" type="PanelContainer" parent="CenterRoot/LeftColumn"]
size_flags_vertical = 3

[node name="SceneHost" type="Control" parent="CenterRoot/LeftColumn/ManorScene"]
anchor_right = 1.0; anchor_bottom = 1.0
mouse_filter = 2                                ; MOUSE_FILTER_IGNORE

[node name="SceneRoot" type="Node2D" parent="CenterRoot/LeftColumn/ManorScene/SceneHost"]
```

스크립트가 `SceneRoot`(Node2D)에 `Sprite2D × N + ColorRect × N + Label × N` 직접 add_child. Control 위의 Node2D는 **position이 Control 좌표 그대로** 동작. 카메라/스크롤 인터랙션 없는 정적 풍경도에선 SubViewport가 오버엔지니어링.

**판단 기준**:
| 인터랙션 | 구조 |
|---|---|
| 캐릭터 클릭만 | **Control > Node2D** (단순) — 권장 |
| 풍경도 드래그 패닝 | SubViewport |
| 줌 + 패닝 + 미니맵 | SubViewport + Camera2D |
| viewport-to-texture 머티리얼 | SubViewport |

자세한 패턴 + 코드: `references/manor-dashboard-screen-pattern.md` (섹션 1).

### LB_VERIFY 헤드리스 무한 hang — 3가지 원인 (2026-07-16 종합)

`LB_VERIFY=1 godot --headless`가 60초 안에 안 끝나면 hang. 다음 3가지 원인 + 해결:

1. **`SceneTree` 직접 호출 시 autoload 미등록** — `godot --script res://verify.gd`로 `SceneTree` 서브클래스 실행하면 main scene 안 거침 → autoload 0개 → 시그널 연결 실패. **해결**: main.gd에 환경변수 기반 분기 (`if OS.has_environment("LB_VERIFY"): _run_verify(); return`). main scene을 거치므로 autoload 정상 등록.
2. **시그널 인자 미스매치 ERROR** — 같은 핸들러가 여러 시그널 콜백이면 ERROR 발생 후 흐름 중단. `mercenary_left(m, reason)` 2개 + `mercenary_joined(m)` 1개 시그널이 같은 핸들러 호출 시 `Method expected N argument(s)` ERROR. **해결**: 핸들러는 모든 인자 디폴트 (`_m = null, _reason = null`).
3. **`await get_tree().process_frame` 누적 hang** — 헤드리스에서 `for i in range(60): await process_frame`가 빨리 안 끝남. **해결**: 검증 루프는 `await` 제거 + 동기 처리 (`for i in range(144): TimeManager.advance_minutes(10)`). 한 프레임 await는 OK, 반복 누적은 위험.

**진단**: stderr 마지막 줄 grep. `ERROR: Method expected N argument(s)` 또는 `ERROR: Parse Error`가 catch 포인트. `Parse Error`는 script 로드 실패 → autoload 등록 실패 → 모든 autoload 사용 라인 ERROR 연쇄 → hang.

### macOS .app 시각 검증 — 헤드리스 환경 한계 (2026-07-16 last-banner-v2 실전)

**헤드리스 환경(SSH/CI/Claude Code)에서는 GUI 세션이 없어 `.app` 윈도우 자체를 띄울 수 없음**. 빌드는 성공해도 `open build/macos/Game.app` 또는 `./Contents/MacOS/Game` 실행 시 5초 내 즉시 quit (stdout/stderr 둘 다 비어있음). `process_mode` 이슈가 아님 — 창 1개 못 만들어서 윈도우 시스템에서 거절.

**해결 패턴 — 헤드리스 자동 검증 + 사용자 시각 위임**:
1. **헤드리스 검증으로 대체** — `LB_VERIFY=1 godot --headless`로 8단계 (새 게임 + 24시간 시뮬 + 결정 큐 push + 저장/로드 라운드트립) 모두 통과 확인. 시각 검증이 아니라 **기능 검증**.
2. **시각 확인은 사용자 Mac 데스크탑에서** — `cd ~/work/<game> && open build/macos/Game.app` 또는 더블클릭. 스크린샷 받으면 시각 디버그.
3. **사용자 시각 의존 시 명시적 위임** — 빌드 완료 메시지에 "사용자 데스크탑에서 더블클릭 후 스크린샷 회신 부탁드립니다" 한 줄 포함. 헤드리스에서 `.app` 직접 띄우려고 시간 낭비 금지.

### macOS build cascade — 4개 에러 순서 (2026-07-16 last-banner-v2 실전)

`godot --headless --export-release macOS` 첫 시도가 통과할 확률은 거의 0%. 다음 4개 cascade가 확정으로 발생:

1. **`Cannot find export template at .../4.7.1.stable/macos.zip`** → `godot` 리포에서 통합 templates.tpz 받아서 macos.zip만 `unzip -j`로 부모 디렉터리에 풀기 (스킬 함정: templates/ 서브폴더에 두면 Godot이 못 찾음)
2. **`ETC2 ASTC 텍스처 형식이 비활성화된 경우... 활성화하세요`** → `project.godot` `[rendering]`에 `textures/vram_compression/import_etc2_astc=true` 추가
3. **`잘못된 번들 식별자: 식별자가 누락되어 있습니다`** → `export_presets.cfg`에 `application/bundle_identifier` + `application/unique_name` 둘 다 명시 (unique_name만으로는 부족)
4. **`공증이 비활성화 / ad-hoc 서명을 사용 중입니다`** → 경고지 에러 아님. 로컬 개발은 무시 OK. Mac App Store 배포 시에만 notarization 활성화

상세 명령어 4개 모음 → `references/macos-build-cascade.md` (예정).

### `@onready` 평가 순서 함정 (2026-07-16 발견)

`@onready var x: Label = $UI/Toast` 같은 변수는 `_ready()` 함수가 **return 하기 전**에 평가됨. 검증 모드 분기로 early return해도 `@onready`는 이미 평가됨 → null 가드 필수:

```gdscript
func _ready() -> void:
    _verify_mode = OS.has_environment("LB_VERIFY")
    if _verify_mode:
        _run_verify()
        return                       # ← early return
    # 일반 모드...

@onready var toast_label: Label = $UI/Toast   # ← 이미 평가됨

func _show_toast(msg):
    if toast_label == null:        # ← 검증 모드에서 호출되면 null 가드 필수
        return
```

## 핵심 명령어

```bash
# 1. Godot 4 설치
brew install godot   # 4.7+ stable

# 2. 프로젝트 부트스트랩 (write_file로 직접)
mkdir -p ~/work/<game>/{autoload,scenes,scripts,assets,docs,export,tools}
# project.godot, autoload/*.gd 작성

# 3. 자산 풀 연결
bash tools/setup-assets.sh   # idempotent 재실행 가능

# 4. lazy fetch (Vercel 무료용) — 선택
for d in assets/*/; do touch "$d/.gdignore"; done
bash tools/gen-asset-manifest.sh   # asset_host.json 생성
# build/web/을 git에 추적 (vercel.json outputDirectory와 직접 연결)

# 5. Godot import (1회, 1~2분)
cd ~/work/<game>
godot --headless --import

# 6. 헤드리스 검증 (빌드 전 필수)
godot --headless --quit-after 200   # autoload/init 에러 확인

# 7. 멀티플랫폼 빌드
bash tools/build.sh web     # Web → build/web/index.html
#   내부 호출: disable-service-worker.sh → inject-debug-pane.sh
bash tools/build.sh mac     # macOS → build/macos/
bash tools/build.sh all     # 전부

# 8. 검은 화면 시 진단 (사용자 PC 접근 불가일 때)
# inject-debug-pane.sh 자동 주입됨 → 사용자에게 새로고침 요청
# 우상단 박스 텍스트 회신 받으면 Engine.getMissingFeatures + 헤더로 원인 특정

# 9. Vercel 배포 (lazy fetch 채택 시)
export VERCEL_TOKEN=$(cat ~/.hermes/secrets/vercel_token.txt | tr -d '\n')
vercel --yes --prod --archive=tgz   # tgz 묶음으로 5,000 reqs 한도 회피

# 9b. Cloudflare 배포 (lazy fetch 없이)
# https://dash.cloudflare.com → Pages → Connect to Git → repo 선택
# Framework preset: None
# Build command: bash tools/build.sh web
# Build output: build/web
```

## 자산 라인업 (game-assets-pool에서 검증)

`tools/setup-assets.sh`가 다음 라인을 자동 구성:

| 카테고리 | 출처 | 라이선스 | 연결 수 |
|---|---|---|---|
| heroes | KayKit Adventurers 1.0 | CC0 | 5 glb |
| skeletons | KayKit Skeletons 1.0 | CC0 | 4 glb |
| dungeon_props | KayKit Dungeon Remastered 1.0 | CC0 | ~50 glb 선택 |
| units (human) | Wesnoth human-loyalists/outlaws | CC-BY-4.0 | ~180 base PNG |
| units (orc/goblin) | Wesnoth orcs/goblins | CC-BY-4.0 | ~210 PNG |
| units (undead/monster) | Wesnoth undead-skeletal/monsters | CC-BY-4.0 | ~225 PNG |
| units (allies) | Wesnoth elves-wood/dwarves | CC-BY-4.0 | ~580 PNG |
| portraits | Wesnoth portraits/{humans,dunefolk,elves,dwarves} | CC-BY-4.0 | ~96 webp |
| music | Wesnoth data/core/music | CC-BY-4.0 | ~44 ogg |
| sfx | Wesnoth data/core/sounds | CC-BY-4.0 | ~272 ogg |

총 **~1,700+ 자산**. Wesnoth 에셋은 GPL 코드와 분리되어 **CC-BY-4.0**만 따르므로 게임 본 프로젝트는 GPL 소스 공개 의무 없음.

## 자산 라이선스 표기 규칙

`docs/CREDITS.md`에 모든 저작자 + 라이선스 + 출처 표기:

```
- KayKit (CC0-1.0): 표기 의무 없음, 그래도 출처 표기
- Battle for Wesnoth (CC-BY-4.0): "© 2003-2026 The Battle for Wesnoth contributors / https://www.wesnoth.org/" + 라이선스 명시
- Nieobie game-icon-pack (CC0): 표기 의무 없음
```

## 지원 파일

- `templates/project.godot.tpl` — 5 autoload 표준 등록된 Godot 프로젝트 파일
- `templates/vercel.json.tpl` — Godot Web Export용 COOP/COEP 헤더
- `templates/export_presets.cfg.tpl` — Web/macOS/Windows/Linux 4종 preset
- `templates/autoload-{game,time,decision,save}_manager.gd.tpl` — 5종 autoload 골격
- `templates/autoload-asset-registry-lazy.gd.tpl` — lazy fetch AssetRegistry 골격
- `templates/setup-assets.sh.tpl` — 풀 → 심볼릭 링크 멱등 스크립트
- `templates/build.sh.tpl` — 멀티플랫폼 빌드
- `templates/gen-asset-manifest.sh.tpl` — 풀 → asset_host.json 생성
- `templates/asset_host.schema.json.tpl` — asset_host.json 스키마 예시
- `templates/disable-service-worker.sh.tpl` — Godot 4 Web export PWA SW 비활성화 (검은 화면 함정 회피, 2026-07-15)
- `templates/inject-debug-pane.sh.tpl` — index.html에 런타임 진단 pane 자동 주입 (원격 사용자 디버깅, 2026-07-15)
- `templates/lb-verify-mode.gd.tpl` — main.gd에 내장되는 `LB_VERIFY=1` 환경변수 헤드리스 검증 모드 (24시간 시뮬레이션 + 자원 변동 + 결정 큐 push + 저장/로드 round-trip 자동 검증)
- `templates/ui-theme.gd.tpl` — **색상 팔레트 + 스타일 헬퍼 중앙 관리** autoload (UITheme 신규, 2026-07-20 last-banner-v4.0.1 실전). `BG_* / TEXT_* / COLOR_* / PRIORITY_* / LOYALTY_*` 상수 + `make_panel_style / make_button_style / make_progress_style` 빌더 + `apply_style / apply_button_styles / apply_progress_styles / apply_label_color / apply_change_color` 헬퍼. 새 Godot 프로젝트에서 `autoload/ui_theme.gd`로 복사 → project.godot에 등록 → 1줄 호출로 전체 스타일 통일.
- `references/godot-event-engine-pattern.md` — GameWorld + EventEngine + DecisionQueue 자동 진행 패턴 (Last Banner 실전 검증, 7종 autoload 신호 연결, CRITICAL 자동 정지, 매일/주기별 변동, 직렬화 round-trip)
- `references/autoload-signal-race-condition.md` — autoload 시그널 race condition 디버깅 + 2중 안전망 패턴 + 시그널 인자 미스매치 + `@onready` 인스턴스화 순서 (2026-07-15~16 last-banner 실전)
- `references/autoload-cross-reference-pitfall.md` — autoload 멤버 cross-reference `Identifier not declared` 파스 에러 진단 + `grep -rn "var X:" autoload/` 패턴 + 이름 충돌 자동 검사 (`awk | sort | uniq -c`) (2026-07-16 last-banner-v2 실전)
- `references/three-layer-safety-net.md` — 3중 안전망 패턴 (즉시/call_deferred/타이머). 2중이 web에서 실패하는 경우의 최후 수단 + 핵심 노드 동적 재검색. 2026-07-16 last-banner 자산 가져오기 3회 시도 후 안정화.
- `references/cdn-asset-placeholder-invalidation.md` — CDN(jsDelivr/GitHub)이 HTTP 200 + Content-Length: 73 bytes 같은 placeholder 본문 반환. fetch "성공"으로 끝났지만 디코딩 실패. **1KB 미만 threshold 가드** (`body.size() < 1024` 무효 처리) + 무효 파일 자동 삭제. 헤드리스는 못 잡고 Web export만 폭발 (2026-07-16 last-banner 실전).
- `references/vercel-godot-web-export.md` — Vercel + Godot 4 웹 배포 함정 + 헤더 패턴 + **pck 캐시 헤더는 `no-cache, must-revalidate` 권장 (2026-07-16 교훈: Godot 4 pck는 콘텐츠 해시 미포함 → immutable이면 새 deploy 영영 미반영)** + 사용자 디버깅 막힘 시 로컬 `godot --path . --quit-after N` 워크플로 전환 트리거 (콘솔 안 열림/고도 페이지/여전히 안됨 2회+)
- `references/godot4-web-export-print-signal-pitfalls.md` — Web export 진단 함정 3종: `print(str(node))` 스택 오버플로우, `@onready` 인스턴스화 순서, `await create_timer().timeout` 시그널 콜백 hang. **로컬 헤드리스가 통과해도 Web export는 다름** — 빌드 후 사용자 1회 테스트 필수
- `references/lazy-fetch-via-cdn.md` — Vercel 100MB 한계 lazy fetch 우회 구현 4단계 + jsDelivr/CDN 선택 + 캐시 무효화
- `references/cloudflare-pages-vs-vercel.md` — 두 호스팅 비교
- `references/godot-4-headless-bootstrap.md` — autoload 골격 + 헤드리스 부팅 검증 단계
- `references/wesnoth-asset-selection.md` — Wesnoth 풀에서 게임용 자산만 골라내는 grep + base 포즈 선택 기준
- `references/wesnoth-2d-idle-png-selection.md` — Wesnoth 2D idle PNG 단일 선택 실전 패턴 (5 factions, 393 PNG 검증, setup-assets.sh 패턴, portraits 구조, grep 정규식, .gdignore 격리) (2026-07-16 last-banner-v2)
- `references/macos-export-pitfalls.md` — Godot 4.7 macOS .app cascade 4단계 (templates.tpz URL/unzip -j, ETC2 ASTC, bundle_identifier, Gatekeeper 경고) + .app 사이즈 분석 + 헤드리스 시각 검증 한계 (2026-07-16 last-banner-v2)
- `references/manor-dashboard-screen-pattern.md` — 4존 레이아웃 매너 대시보드 (TopResourceBar + ManorScene SubViewport + Roster List-Detail + BottomButtonRow) + sprite/colorrect 조합 + autoload cross-reference + LB_VERIFY 화면 검증 단계 (2026-07-16 last-banner-v2)
- `references/godot4-web-export-pitfalls.md` — 8가지 Web export 함정
- `references/godot4-native-2d-ui-pitfalls.md` — Godot 4 macOS-native 2D 게임 UI 함정 모음 (v2.3~v3.1 검증). `replace_all=true` tscn 폭파 사고 (9개 노드 손실 사례 + `write_file` 복구 패턴) + PanelContainer mouse_filter=0/2 선택 기준 + HBox 안 title/canvas 영역 분리 + 3패널 분할 배치 패턴 (풍경도 ⇄ DetailPanel ⇄ ChartPanel) + 동적 노드 경로 일관성 (`get_node_or_null`) + Variant 추론 파스 에러 (`var X := func().field`) + 다중 패널 height 충돌 + 닫는 태그 깨짐 + `await create_timer` 헤드리스 hang 3종 + `_on_tick`마다 `queue_redraw` 안전성 (2026-07-16 last-banner-v2.3~v3.1 실전 9 검증 사례)
- `references/character-click-interaction-area2d.md` — Sprite2D에 마우스 입력 부여하는 Area2D + RectangleShape2D 패턴 + 라벨/Control mouse_filter 가드 + 호버 강조 + LB_VERIFY 우회 검증 (2026-07-16 last-banner-v2)
- `references/auto-progress-speed-tuning.md` — SECONDS_PER_GAME_MINUTE 1/60 + 이벤트 interval 분리 조정(20h/40h) + DECISION_MAX_PER_DAY 3→8 + **속도↑ = interval↑ 곱 비례** 통찰 + LB_VERIFY [2.5] 직접 _process 시뮬 패턴 + 결정 큐와의 상호작용 + 안티패턴 4종 (2026-07-16 last-banner-v2.1.1)
- `references/control-colorrect-time-of-day-gradient.md` — 풍경도 배경이 매 시간대로 색 변화 (Color.lerp + tick_advanced마다 update) + 흙길도 동시 어두워짐 + 새벽/낮/노을/밤 4구간 (2026-07-16 last-banner-v2.3)
- `incremental-game-design-last-banner-event-engine/references/menu-game-mode-toggle.md` — 메뉴 ↔ 게임 모드 토글 (`_enter_game_mode()`/`_exit_game_mode()` + 우상단 `MenuToggleButton` + ESC). 모든 화면/시스템 안정 후 마지막에 적용하는 UI 모드 분리 패턴 (Last Banner 10차 2026-07-16).
- `references/battle-scene-with-apply-result-unification.md` — **GameWorld.apply_result 단일 dict 통합 패턴** (전투/오버레이 씬 자원의 단일 소스 오브 트루쓰) + **race-free await** (한 함수 한 await 또는 for + 단일 await) + LB_VERIFY에서 `DecisionQueue.push()` 직접 호출로 `randf()` 게이트 우회 (2026-07-16 last-banner-v3.0)
- `references/godot-web-black-screen-diagnosis.md` — 검은 화면 진단 워크플로 + SW 비활성화 + 진단 pane (2026-07-15 last-banner 실전)
- `references/godot-web-mobile-ui-and-fonts.md` — 모바일 viewport anchor + status div 덮음 + 한글 폰트 미적용 함정 3종 (2026-07-15 last-banner 실전)
- `references/live-deployment-healthcheck.md` — Vercel 라이브 deploy 후 4축 sanity check (curl 헤더 + WASM/JS 응답 + asset_host.json shape + Godot 헤드리스 부팅)
- `references/audio-asset-acquisition.md` — **CC0/SFX 폴백 전략** (Wesnoth 풀에 SFX 없을 때 sparklinlabs superpowers-asset-packs의 RPG pack에서 빌려오기 — 4종 BGM + 6종 SFX = 9.8 MB, 라이선스 표기 한 줄, 헤드리스 가드 패턴, setup-assets.sh 통합 가이드. 2026-07-20 last-banner-v4.1.0 B-2 실전 검증.)
- `references/godot-mcp-ecosystem-2026-07.md` — **Godot MCP 통합 카탈로그** (26개 도구 + npm/PyPI 패키지 + 비교 표 + 10개 Hermes 인사이트 + 즉시 적용 로드맵). SKILL.md "🤖 Godot MCP 통합" 섹션의 상세판.
- `references/love-to-godot-single-screen-migration.md` — **LÖVE → Godot 단일 화면 마이그레이션 1단계 패턴** (2026-07-21 snkrx-clone → snkrx-godot v0.0.1 실전). 풀 마이그레이션 불가능 + 1개 화면 단위로 좁히는 작업 정의 + ko.lua → Godot Translation 이식 + anchor 회피를 위한 `custom_minimum_size` + `size_flags_horizontal` 단순 그리드 + 헤드리스 2단계 검증 + v0.0.1~v1.0 단계별 매트릭스 (5~10세션).
- `references/godot-mcp-gut-integration-setup.md` — **hi-godot/godot-ai + Gut + mcpollinations 통합 설치 recipe** (2026-07-16 Last Banner 실전 검증). 각 도구의 정확한 설치 URL/명령 + **헤드리스 함정 5가지** (godot-ai는 GUI Configure 사용자 위임, Gut는 git clone만 가능, mcpollinations는 npm 글로벌 prefix 격리) + **Gut ↔ LB_VERIFY 역할 분리 매트릭스** + 단위 테스트 9/9 통과 검증 출력 예.
- `templates/gut-test-template.gd` — **Gut 단위 테스트 골격** (Last Banner v2 GameWorld 예시). `before_each()`로 autoload 상태 격리 + 시그널 캡처 람다 패턴 + assert 헬퍼 카탈로그. 복사 후 함수 본문 작성 → 30분 내 9개 테스트 셋업 가능.

## 권장 워크플로

1. **풀 결정** — `game-assets-pool` 커밋 SHA pin 후 submodule이 아니라 `curl`로 풀 데이터 받기 (이미 둘 다 있음).
2. **`setup-assets.sh` 작성** — 풀 디렉터리 + 게임 프로젝트 디렉터리 둘 다 받기, 카테고리 필터링 후 심볼릭 링크.
3. **`project.godot` + autoload 골격** — 5종 표준, 게임 코어는 안 건드림.
4. **헤드리스 부팅 1회 검증** — autoload 로드 에러 잡기 (`--quit-after 200`).
5. **main.tscn** — 첫 화면 (부트 메뉴 + Save/Load/Toggle/Fetch).
6. **씬 본격 추가** — 영지 화면 → 전투 화면 → 결정 다이얼로그 모달.
7. **Web 빌드 후 SW 비활성화 + 디버그 pane 자동 주입** (빌드 파이프라인에 포함). 검은 화면 시 진단 pane이 자동 진단 결과 화면에 표시.
8. **Web 배포 결정** — `references/cloudflare-pages-vs-vercel.md` 보고 Vercel(lazy fetch) vs Cloudflare(대용량 그대로) 선택.
9. **자산 라이선스 README 업데이트** — 사용한 라인업 기반으로 CREDITS.md 재생성.
10. **자동 진행 헤드리스 검증 (LB_VERIFY 패턴)** — main.gd에 환경변수 기반 검증 모드 내장. `LB_VERIFY=1 godot --headless` 한 줄로 24시간 시뮬레이션 + 자원 변동 + 결정 큐 push + 저장/로드 round-trip 자동 검증. **상세 패턴은 `references/godot-event-engine-pattern.md` + `references/godot-headless-verify-pitfall.md`**. GDScript SceneTree 직접 호출 시 autoload 인식 안 되는 함정 + 환경변수 우회법 포함.

## 7종 표준 autoload 신호 연결 (Last Banner 실전 검증)

```
TimeManager (autoload, _process)
   │
   ├─ tick_advanced.emit(game_time)
   │     ├─► SaveManager._on_tick    → maybe_auto_save (60분 주기)
   │     └─► EventEngine._on_tick    → 4h/8h/10h/12h 주기 사건 (확률 게이트 + 결정 큐 push)
   │
   ├─ day_changed.emit(day)
   │     └─► EventEngine._on_day     → apply_daily_economy + apply_weekly_bill (일간 자원 변동)
   │
   └─ season_changed.emit(season)
         └─► EventEngine._on_season   → 계절별 특별 이벤트 (예: 겨울 준비)
```

**3가지 시그널을 모두 활용** — `tick_advanced`(자원/사건), `day_changed`(일간 변동), `season_changed`(계절별). 각 autoload의 `_ready()`에서 `process_mode = Node.PROCESS_MODE_ALWAYS` 잊지 말 것.

**DecisionQueue.push() 내부**: priority == CRITICAL이면 `GameManager.pause_for_decision()` 자동 호출 → 자동 진행 일시정지 → 사용자 결정 대기.

## 🔄 호스팅 결정 — 4가지 옵션 + 비교

Godot 4 Web export 산출물은 `index.pck` 1개 파일에 200~500MB 압축됨. 호스팅 결정은 **lazy fetch 채택 여부**로 갈림.

| 옵션 | 단일 파일 한계 | lazy fetch 불필요? | 결론 |
|---|---|---|---|
| Vercel (무료) | 100MB ❌ | ✅ (lazy fetch 채택 시) | 무료 + 자동화 |
| Vercel (Pro $20/월) | 무제한 | ✅ | 비용 발생 |
| Cloudflare Pages | 25MB | ✅ (대용량 자산 그대로 빌드) | 무료 + 가장 단순 |
| GitHub Pages | 100MB | ✅ | assets도 100MB OK지만 LFS 필요 |

**결론**:
- **lazy fetch 안 쓰겠다** → Cloudflare Pages (가장 단순, 무료)
- **Vercel 유지 + 무료** → `.gdignore` + jsDelivr lazy fetch (이 스킬 권장)
- **Pro 플랜 OK** → Vercel 무제한 (그냥 `vercel --prod`)

### lazy fetch 패턴 (Vercel 무료 + 200~500MB 자산 우회)

핵심 아이디어: `pck`에는 **스크립트/씬만** (~수백 KB) → 자산은 **런타임에 jsDelivr CDN에서 fetch** → `user://persistent/assets/`에 IndexedDB 캐시.

```
pck 501KB  →  게임 즉시 부팅
            ↓ 사용자가 [자산 가져오기 (CDN)] 클릭
jsDelivr   →  자산 228MB 백그라운드 다운로드
            ↓ 완료
user://    →  IndexedDB 캐시 (재방문 시 즉시)
```

**구현 4단계** (자세한 코드/함정은 `references/lazy-fetch-via-cdn.md`):

1. `assets/*/.gdignore` 파일 생성 → Godot export 시 해당 폴더 제외 (그러나 git 추적은 유지 → CDN이 받음)
2. `asset_host.json` 생성 (CDN URL + 카테고리별 파일 목록 + 사이즈) — `gen-asset-manifest.sh`로 자동 생성
3. `AssetRegistry.gd` lazy fetch 함수 (`_http_download` + `user://persistent/assets/` 캐시)
4. main.tscn에 `[자산 가져오기 (CDN)]` 버튼 + 진행률 표시

**장점**: Vercel 무료로 200~500MB 자산 호스팅 가능 + 첫 로드 빠름 (스크립트만 <1MB)  
**단점**: 첫 진입 후 자산 다운로드 30~60초 추가 (백그라운드 가능), CDN 장애 시 게임 불가

자세한 패턴은 `references/lazy-fetch-via-cdn.md`, Web export 8가지 함정은 `references/godot4-web-export-pitfalls.md`, Vercel/Cloudflare 비교는 `references/cloudflare-pages-vs-vercel.md`, 검은 화면 진단은 `references/godot-web-black-screen-diagnosis.md`.

## ⌨️ 단축키 권장 (자동 진행 게임)

자동 진행이 핵심 메카닉이라면 **`P` 키 = 자동 진행 토글**을 project.godot의 input action으로 등록:

```ini
[input]
toggle_auto_progress={
"deadzone": 0.5,
"events": [Object(InputEventKey,"resource_local_to_scene":false,"resource_name":"","device":-1,"window_id":0,"alt_pressed":false,"shift_pressed":false,"ctrl_pressed":false,"meta_pressed":false,"pressed":false,"keycode":80,"physical_keycode":0,"key_label":0,"unicode":112,"location":0,"echo":false,"script":null)
]
}
```

`TimeManager.toggle_auto_progress()`가 받아서 `auto_progress_enabled = not auto_progress_enabled`. UI에도 동일 단축키 버튼 노출. 결정 큐 모달은 자동 표시 (사용자 진입 시점).

## 🤖 Godot MCP 통합 (Hermes Agent + 2026-07 검증)

Last Banner처럼 **Hermes에서 Godot 작업을 자율화**하려면 MCP 서버 1종 + 클라이언트 등록이 정석. **`hi-godot/godot-ai` 1순위 권장** — README에서 **Hermes Agent를 공식 지원 클라이언트로 명시**.

### 비교 (2026-07-16)

| 서버 | ⭐ | 라이선스 | 툴 수 | Godot 4.7 | Hermes 호환 | 특이사항 |
|---|---|---|---|---|---|---|
| **hi-godot/godot-ai** | 1,010 | MIT | 43 (rollup 120+ ops) | ✅ | ✅ **공식** | **1순위**. AssetLib 등록 |
| Coding-Solo/godot-mcp | 4,733 | MIT | 20 | ⚠️ `--check-only` | 수동 | 별점 1위지만 Last Banner autoload 환경에 false negative |
| tugcantopaloglu/godot-mcp | 340 | MIT | 157 | ✅ SceneTree 검증 | 수동 | Last Banner autoload cross-ref 안전 (v3.1.0+) |
| HaD0Yun/Doyunha-Gopeak | 230 | MIT | 95+ | ✅ DAP+LSP | 수동 | 한국어 README, Bun 1.3.3+ |
| IvanMurzak/Godot-MCP | 174 | Apache-2.0 | 39 + npm `godot-cli` | ✅ | godot-cli 자동 | **클라우드 백엔드(ai-game.dev) 의존** |
| Glade-tool/glade-mcp | 178 | MIT | 235+ (Unity 260+) | ❌ 헤드리스/CI 미지원 | 수동 | editor-only, Mono/C# 미지원 |

### Last Banner 권장 설치 (2026-07)

```bash
# 1) hi-godot/godot-ai 플러그인 — GitHub releases ZIP (v3.0.2 검증)
curl -fsSL -o /tmp/godot-ai.zip "https://github.com/hi-godot/godot-ai/releases/download/v3.0.2/godot-ai-plugin.zip"
unzip -o /tmp/godot-ai.zip          # → addons/godot_ai/ 2.0MB

# 2) bitwes/Gut — git clone만 가능 (ZIP 릴리즈 없음, v9.6.1 검증)
git clone --depth 1 --branch v9.6.1 https://github.com/bitwes/Gut.git /tmp/gut_src
cp -R /tmp/gut_src/addons/gut addons/gut   # → addons/gut/ 3.2MB (addons/만 복사)

# 3) uv (Python MCP 브릿지) — macOS는 brew install uv
brew install uv

# 4) Godot import 1회
cd ~/work/<game>
godot --headless --import

# 5) Hermes 자동 등록: godot-ai dock > Clients 탭 > "Hermes Agent" row > Configure
#    → http://127.0.0.1:<port>/mcp + uvx mcp-proxy 자동 설정. **헤드리스에서 불가능** —
#    사용자 Mac 데스크탑에서 open -a Godot.app 한 번 띄워야 함.
#    또는 ~/.claude.json의 mcpServers에 수동 추가
```

**상세 단계별 + 헤드리스 함정 5가지 + GUI 1회 사용자 위임 패턴**: `references/godot-mcp-gut-integration-setup.md`

### 보조 도구 매트릭스

| 도구 | 용도 | 설치 |
|---|---|---|
| `@pinkpixel/mcpollinations` (npm v1.3.1) | NPC 일러스트 / 풍경 / 음향 즉시 생성 | `npm install -g @pinkpixel/mcpollinations` |
| `bitwes/Gut` (addons, 2,639⭐) | 결정 큐 + 자원 단위 테스트 (LB_VERIFY = 통합 검증, Gut = 함수 단위) | **git clone만 가능** (ZIP 없음) `git clone --depth 1 --branch v9.6.1 https://github.com/bitwes/Gut.git /tmp/gut_src && cp -R /tmp/gut_src/addons/gut addons/gut` |
| `chickensoft-games/setup-godot` (CI) | macOS + Web 4-platform 동시 빌드 | GitHub Actions `uses: chickensoft-games/setup-godot@v4` |
| `godot-cli` npm (v0.17.1) | MCP 서버 health check + AI agent 자동 등록 | `npm install -g godot-cli` |
| `Donchitos/Claude-Code-Game-Studios` (23,040⭐) | 자율 코딩 (49 agents + 72 skills) | **전체 import 금지** — 2~3개만 발췌 |

### Godot MCP 함정 4종 (Last Banner 실전 + 2026-07-16 통합 설치 검증)

1. **100 툴 cap** — Cursor/Cline 일부 클라이언트는 100 툴 cap. `tugcantopaloglu`(157) + `comfyui-mcp`(108) 동시 사용 시 cap 초과. **해결**: hi-godot의 `<domain>_manage` rollup 패턴 — 43 툴로 120+ ops 노출
2. **Autoload cross-reference false negative** — Coding-Solo의 `--check-only` 방식은 `Identifier "X" not declared` 오탐 (이 스킬의 autoload cross-reference 함정과 정확히 매치). **해결**: `tugcantopaloglu` v3.1.0+ `_initialize()` SceneTree 검증 또는 hi-godot Python 검증
3. **Web export 환경은 MCP로 검증 불가** — PWA SW / SharedArrayBuffer / WebGL2 / mobile viewport는 헤드리스 부팅으로 검증 안 됨. `references/godot-web-black-screen-diagnosis.md` + `templates/inject-debug-pane.sh.tpl` 패턴 유지
4. **헤드리스에서 godot-ai 자동 등록 불가 (2026-07-16 발견)** — godot-ai는 Godot GUI 안에서 MCP 서버를 띄우는 구조. 헤드리스 부팅은 충돌 없이 통과하지만 `~/.claude.json`에 자동 등록되지 않음. **사용자가 `open -a Godot.app ~/work/<game>` + 도크 Configure 클릭 한 번 필요**. 시간 낭비 금지 — 30초 + 1클릭.

**상세 카탈로그** (26개 도구 + npm 패키지 + 비교 표 + 10개 Hermes 인사이트): `references/godot-mcp-ecosystem-2026-07.md`
