#!/usr/bin/env bash
# disable-service-worker.sh — Godot 4 Web export의 PWA Service Worker 비활성화 (검은 화면 함정 회피)
# 사용: bash tools/disable-service-worker.sh build/web
#
# 왜 필요한가 (2026-07-15 last-banner 실전):
#   progressive_web_app/enabled=false로 설정해도 Godot 4.7은 여전히
#   index.service.worker.js + index.html의 SW 등록 if-else 블록을 생성.
#   첫 build 후 reload 시 "Service worker already exists" 에러로 무한 reload,
#   또는 crossOriginIsolated=false 환경에서 missing features 분기 진입 시
#   else가 단독 구문이 되어 "SyntaxError: Unexpected token 'else'" → 게임 부팅 실패.
#   vercel.json 헤더 / progressive_web_app.enabled 어디서도 못 막음.
#   **빌드 후 HTML post-processing으로 SW 자체를 no-op 처리**하는 것이 유일한 해결.
#
# 핵심 패턴 (단순 // 주석 절대 불가, else가 매칭할 if 잃음):
#   if (GODOT_CONFIG['serviceWorker'] && ...) { /* SW 등록 */ } else { displayFailureNotice(...) }
#     → if (false) { /* SW DISABLED */ } else { displayFailureNotice(...) }

set -euo pipefail

WEB_DIR="${1:-build/web}"
[[ -d "$WEB_DIR" ]] || { echo "ERR: $WEB_DIR not found"; exit 1; }

# 1. SW 파일 삭제
SW_FILE="$WEB_DIR/index.service.worker.js"
if [ -f "$SW_FILE" ]; then
    rm "$SW_FILE"
    echo "✓ removed $SW_FILE"
fi

# 2. offline.html 삭제 (SW 의존)
OFFLINE="$WEB_DIR/index.offline.html"
if [ -f "$OFFLINE" ]; then
    rm "$OFFLINE"
    echo "✓ removed $OFFLINE"
fi

# 3. index.html의 SW 등록 코드 처리
HTML="$WEB_DIR/index.html"
if [ -f "$HTML" ]; then
python3 <<PYEOF
import re
from pathlib import Path

html_path = Path("$HTML")
html = html_path.read_text()

# GODOT_CONFIG.serviceWorker 값을 ""로 변경
new_html = re.sub(
    r'"serviceWorker":"index\.service\.worker\.js"',
    '"serviceWorker":""',
    html
)

# 원본 구조:
#   if (missing.length !== 0) {
#     if (GODOT_CONFIG['serviceWorker'] && ...) { ... } else { displayFailureNotice(...) }
#   }
#
# 변경 후:
#   if (missing.length !== 0) {
#     if (false) { /* SW DISABLED */ } else { displayFailureNotice(...) }
#   }
# else는 매칭할 if가 사라지면 안 되므로 if(false)로 교체 (단순 주석 X).
pattern = re.compile(
    r"if \(GODOT_CONFIG\['serviceWorker'\] && GODOT_CONFIG\['ensureCrossOriginIsolationHeaders'\] && 'serviceWorker' in navigator\) \{[\s\S]*?\}\s+else\s*\{",
    re.MULTILINE
)
m = pattern.search(new_html)
if m:
    new_html = (
        new_html[:m.start()]
        + "if (false) { /* SW DISABLED by disable-service-worker.sh */ } else {"
        + new_html[m.end():]
    )
    print(f"✓ replaced SW if-else block ({len(m.group(0))} chars)")
else:
    print("✗ no SW if-else pattern matched; manual review needed")

html_path.write_text(new_html)
print(f"✓ patched {html_path}")
PYEOF
fi

echo "✅ Service Worker 비활성화 완료"
