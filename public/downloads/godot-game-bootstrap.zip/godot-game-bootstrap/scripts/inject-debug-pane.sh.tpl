#!/usr/bin/env bash
# inject-debug-pane.sh — Godot Web export 산출물 index.html에 런타임 진단 pane 주입.
# 사용: bash tools/inject-debug-pane.sh build/web/index.html
#
# 목적 (2026-07-15 last-banner 실전):
#   원격 사용자 브라우저에서 검은 화면만 보일 때 — puppeteer 헤드리스는 WebGL2
#   software rendering 미지원으로 게임 자체 부팅 안 됨. 사용자 PC 접근 불가
#   상황에서 화면에 무엇이 빠졌는지 즉시 식별할 도구가 필요.
#
# 주입 결과:
#   - 우상단 빨간 박스 (고정 position) — canvas / WebGL / Cross-Origin /
#     Missing features / 콘솔 에러 자동 표시
#   - 1/5/15초 시점에 상태 덤프 (자동 갱신)
#   - 사용자가 새로고침하면 즉시 진단 결과 화면에 표시 → 텍스트 회신
#     → Engine.getMissingFeatures + 헤더로 원인 특정

set -euo pipefail

HTML="${1:-build/web/index.html}"
[[ -f "$HTML" ]] || { echo "ERR: $HTML not found"; exit 1; }

if grep -q "lb-debug-pane" "$HTML"; then
    echo "✓ 이미 패치됨"
    exit 0
fi

python3 "$HTML" <<'PYEOF'
import sys
from pathlib import Path

html_path = Path(sys.argv[1])
html = html_path.read_text()

inject = """
<!-- Last Banner aggressive debug pane — injected by tools/inject-debug-pane.sh -->
<style>
#lb-debug-pane {
  position: fixed !important;
  top: 8px !important; right: 8px !important;
  width: 600px !important; max-height: 90vh !important;
  background: rgba(0,0,0,0.92) !important;
  color: #ff6b6b !important;
  font-family: ui-monospace, Menlo, monospace !important;
  font-size: 12px !important;
  padding: 12px !important;
  border: 2px solid #ff6b6b !important;
  border-radius: 6px !important;
  white-space: pre-wrap !important;
  word-break: break-word !important;
  z-index: 9999999 !important;
  display: block !important;
  overflow: auto !important;
}
#lb-debug-pane h3 { color: #ffd93d; margin: 4px 0; font-size: 13px; }
</style>
<div id="lb-debug-pane">
<h3>🔍 Last Banner — 디버그 pane</h3>
<div id="lb-debug-log"></div>
</div>
<script>
(function() {
  var log = document.getElementById('lb-debug-log');
  function show(msg) {
    var line = document.createElement('div');
    line.textContent = msg;
    log.appendChild(line);
    console.log('[lb-debug]', msg);
  }
  function dumpState() {
    var c = document.getElementById('canvas');
    var s = document.getElementById('status');
    var p = document.getElementById('status-progress');
    var n = document.getElementById('status-notice');
    show('=== 상태 (' + new Date().toLocaleTimeString() + ') ===');
    show('canvas: ' + (c ? c.width + 'x' + c.height : '없음'));
    show('status visible: ' + (s ? getComputedStyle(s).visibility : '?'));
    show('progress: "' + (p ? p.textContent : '') + '"');
    show('notice: "' + (n ? n.textContent : '') + '"');
    show('Engine: ' + (typeof Engine !== 'undefined' ? 'OK' : '없음'));
    if (typeof Engine !== 'undefined') {
      try {
        var missing = Engine.getMissingFeatures({threads: false});
        show('Missing features (threads=false): ' + JSON.stringify(missing));
        var missingT = Engine.getMissingFeatures({threads: true});
        show('Missing features (threads=true): ' + JSON.stringify(missingT));
      } catch(e) { show('getMissingFeatures err: ' + e.message); }
    }
    show('crossOriginIsolated: ' + (typeof crossOriginIsolated !== 'undefined' ? crossOriginIsolated : '?'));
    show('SharedArrayBuffer: ' + (typeof SharedArrayBuffer !== 'undefined' ? 'OK' : '없음'));
    try {
      var probe = new SharedArrayBuffer(8);
      show('SharedArrayBuffer 인스턴스 생성: OK');
    } catch(e) {
      show('SharedArrayBuffer 인스턴스 생성 실패: ' + e.message);
    }
    try {
      var c2 = document.createElement('canvas');
      var gl = c2.getContext('webgl2');
      show('WebGL2: ' + (gl ? 'OK ' + gl.getParameter(gl.VERSION) : '실패'));
      if (!gl) {
        var gl1 = c2.getContext('webgl');
        show('WebGL1 fallback: ' + (gl1 ? 'OK' : '실패'));
      }
    } catch(e) { show('WebGL check err: ' + e.message); }
  }
  window.addEventListener('error', function(e) {
    show('[ERROR] ' + e.message + ' @ ' + (e.filename || '?') + ':' + (e.lineno || '?'));
  });
  window.addEventListener('unhandledrejection', function(e) {
    show('[PROMISE] ' + (e.reason && e.reason.message || e.reason || 'unknown'));
  });
  if (typeof Engine !== 'undefined') {
    var orig = Engine.onError;
    Engine.onError = function(msg, type) {
      show('[GODOT] ' + type + ' ' + msg);
      if (orig) orig.apply(this, arguments);
    };
  }
  show('Pane 초기화 완료. 1초 후 상태 덤프...');
  setTimeout(dumpState, 1000);
  setTimeout(dumpState, 5000);
  setTimeout(dumpState, 15000);
})();
</script>
"""

if "</body>" in html:
    html = html.replace("</body>", inject + "\n</body>")
else:
    html = html + inject

html_path.write_text(html)
print(f"✓ debug pane injected into {html_path}")
PYEOF
