extends Node
## TimeManager — 자동 진행 시계.
## 1초 = 게임 내 X시간 (기본 2초 = 1시간). P 키 토글.
## CRITICAL 결정 큐가 있으면 자동 진행 중단.

signal tick_advanced(game_time: int)
signal day_changed(day: int)
signal season_changed(season: String)

const SECONDS_PER_GAME_HOUR := 2.0
const MINUTES_PER_HOUR := 60

var minutes_elapsed: int = 0
var day: int = 1
var season: String = "봄"
var auto_progress_enabled: bool = false
var _accumulator: float = 0.0

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    set_process(true)

func _process(delta: float) -> void:
    if not auto_progress_enabled:
        return
    if not GameManager.is_playing():
        return
    if DecisionQueue.has_pending_critical():
        GameManager.pause_for_decision()
        return

    _accumulator += delta
    var minutes_per_real_second := MINUTES_PER_HOUR / SECONDS_PER_GAME_HOUR
    var minutes_to_advance := int(_accumulator * minutes_per_real_second)
    if minutes_to_advance <= 0:
        return
    _accumulator -= float(minutes_to_advance) / minutes_per_real_second
    advance_minutes(minutes_to_advance)

func advance_minutes(minutes: int) -> void:
    var old_day := day
    minutes_elapsed += minutes
    day = 1 + (minutes_elapsed / (24 * MINUTES_PER_HOUR))
    tick_advanced.emit(minutes_elapsed)
    if day != old_day:
        day_changed.emit(day)
        _update_season()

func _update_season() -> void:
    var day_of_year := (day - 1) % 90  # 4계절 90일 사이클
    var old_season := season
    if day_of_year < 23:
        season = "봄"
    elif day_of_year < 46:
        season = "여름"
    elif day_of_year < 69:
        season = "가을"
    else:
        season = "겨울"
    if season != old_season:
        season_changed.emit(season)

func toggle_auto_progress() -> void:
    auto_progress_enabled = not auto_progress_enabled
    print("[TimeManager] 자동 진행: %s" % ("켜짐" if auto_progress_enabled else "꺼짐"))

func save_state() -> Dictionary:
    return {
        "minutes_elapsed": minutes_elapsed,
        "day": day,
        "season": season,
        "auto_progress_enabled": auto_progress_enabled
    }

func load_state(data: Dictionary) -> void:
    minutes_elapsed = data.get("minutes_elapsed", 0)
    day = data.get("day", 1)
    season = data.get("season", "봄")
    auto_progress_enabled = data.get("auto_progress_enabled", false)
