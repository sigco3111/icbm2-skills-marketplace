extends Node
## GameManager — 게임 상태머신 + 글로벌 이벤트 버스.
## 표준 autoload. 씬 전환·일시정지·로드를 단일 진실로 처리.

signal game_started
signal game_paused
signal game_resumed
signal game_state_changed(new_state: String)

enum State {
    BOOT,
    MENU,
    PLAYING,
    PAUSED,
    DECISION_PENDING,
    COMBAT,
    GAME_OVER
}

var current_state: State = State.BOOT
var save_slot: String = "default"

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    print("[GameManager] 부팅 완료")

func start_new_game(slot: String = "default") -> void:
    save_slot = slot
    SaveManager.new_game(slot)
    _transition(State.PLAYING)
    game_started.emit()

func load_game(slot: String) -> bool:
    if not SaveManager.load_game(slot):
        return false
    save_slot = slot
    _transition(State.PLAYING)
    game_started.emit()
    return true

func pause_for_decision() -> void:
    if current_state == State.PLAYING:
        _transition(State.DECISION_PENDING)

func resume_after_decision() -> void:
    if current_state == State.DECISION_PENDING:
        _transition(State.PLAYING)

func _transition(new_state: State) -> void:
    if current_state == new_state:
        return
    print("[GameManager] %s → %s" % [State.keys()[current_state], State.keys()[new_state]])
    current_state = new_state
    game_state_changed.emit(State.keys()[new_state])

func is_playing() -> bool:
    return current_state == State.PLAYING

func can_accept_user_input() -> bool:
    return current_state in [State.PLAYING, State.DECISION_PENDING]
