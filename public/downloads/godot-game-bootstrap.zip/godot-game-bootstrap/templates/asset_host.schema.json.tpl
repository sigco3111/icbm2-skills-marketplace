{
  "$schema": "asset_host.schema.json",
  "version": 1,
  "generated_at": "2026-07-15T09:00:00Z",
  "base_url": "https://cdn.jsdelivr.net/gh/<user>/<repo>@main/assets",
  "total_size_bytes": 239463132,
  "category_count": 6,
  "categories": {
    "audio": {
      "kind": "audio",
      "file_count": 632,
      "size_bytes": 187309337,
      "base_url": "https://cdn.jsdelivr.net/gh/<user>/<repo>@main/assets",
      "files": [
        "audio/music/battle-epic.ogg",
        "audio/music/battle.ogg"
      ],
      "sizes": {
        "audio/music/battle-epic.ogg": 4123456,
        "audio/music/battle.ogg": 1234567
      }
    },
    "heroes": {
      "kind": "3d_character",
      "file_count": 5,
      "size_bytes": 5120000,
      "base_url": "https://cdn.jsdelivr.net/gh/<user>/<repo>@main/assets",
      "files": [
        "heroes/kaykit/Knight.glb",
        "heroes/kaykit/Barbarian.glb"
      ],
      "sizes": {
        "heroes/kaykit/Knight.glb": 1024000,
        "heroes/kaykit/Barbarian.glb": 1024000
      }
    }
  }
}
