extends Node
## AssetRegistry (lazy fetch) — 빌드 시 자산 미포함.
## 런타임에 base_url의 CDN에서 자산 다운로드 → user://persistent/assets/{category}/{file}
## 매니페스트: res://asset_host.json (CDN URL + 카테고리 매핑)

const MANIFEST_LOCAL_PATH := "res://asset_host.json"

var _manifest: Dictionary = {}
var _fetched: Dictionary = {}     ## {relative_path: local_path} 메모리 캐시
var _in_progress: Dictionary = {} ## 같은 자산 중복 fetch 방지
var _loaded_bytes: int = 0
var _manifest_ready: bool = false

signal manifest_loaded
signal asset_fetched(rel_path: String, local_path: String)
signal fetch_progress(loaded: int, total: int)
signal all_assets_ready

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    _load_manifest()

func _load_manifest() -> void:
    if not FileAccess.file_exists(MANIFEST_LOCAL_PATH):
        push_warning("[AssetRegistry] %s 없음 — fetch 비활성" % MANIFEST_LOCAL_PATH)
        return
    var f := FileAccess.open(MANIFEST_LOCAL_PATH, FileAccess.READ)
    if f == null:
        push_warning("[AssetRegistry] 매니페스트 읽기 실패")
        return
    var json := JSON.new()
    if json.parse(f.get_as_text()) != OK:
        push_warning("[AssetRegistry] 매니페스트 JSON 파싱 실패")
        f.close()
        return
    f.close()
    _manifest = json.data
    _manifest_ready = true
    manifest_loaded.emit()
    print("[AssetRegistry] 매니페스트 로드: base_url=%s, %d 카테고리" % [
        _manifest.get("base_url", "?"),
        (_manifest.get("categories", {}) as Dictionary).size()
    ])

func get_base_url() -> String:
    return _manifest.get("base_url", "")

func list_categories() -> Array:
    if not _manifest_ready:
        return []
    var cats: Dictionary = _manifest.get("categories", {})
    return cats.keys()

func get_category(name: String) -> Dictionary:
    if not _manifest_ready:
        return {}
    var cats: Dictionary = _manifest.get("categories", {})
    return cats.get(name, {})

func get_total_size() -> int:
    var total := 0
    var cats: Dictionary = _manifest.get("categories", {})
    for cat_name in cats:
        var cat: Dictionary = cats[cat_name]
        total += int(cat.get("size_bytes", 0))
    return total

## 매니페스트에 있는 모든 카테고리 fetch + 진행률 콜백
func fetch_all(progress_cb: Callable = Callable()) -> void:
    var total: int = get_total_size()
    _loaded_bytes = 0
    var cats: Dictionary = _manifest.get("categories", {})
    for cat_name in cats:
        var cat: Dictionary = cats[cat_name]
        var files: Array = cat.get("files", [])
        var base_url: String = cat.get("base_url", get_base_url())
        for rel_path in files:
            _download_single(base_url, rel_path, progress_cb, total)

func _download_single(base_url: String, rel_path: String, progress_cb: Callable, total: int) -> void:
    if _fetched.has(rel_path) or _in_progress.has(rel_path):
        return
    var url := "%s/%s" % [base_url, rel_path]
    var local_path := "user://persistent/assets/%s" % rel_path
    # 디스크 캐시 hit (재진입 시 즉시)
    if FileAccess.file_exists(local_path):
        var sz: int = FileAccess.get_file_as_bytes(local_path).size()
        _fetched[rel_path] = local_path
        _loaded_bytes += sz
        asset_fetched.emit(rel_path, local_path)
        if progress_cb.is_valid():
            progress_cb.call(_loaded_bytes, total)
        return
    # HTTP fetch 시작
    _in_progress[rel_path] = true
    var req := HTTPRequest.new()
    add_child(req)
    req.request_completed.connect(_on_request_done.bind(req, local_path, rel_path, progress_cb, total))
    req.request(url)

func _on_request_done(result: int, response_code: int, _h: PackedStringArray,
                     body: PackedByteArray, req: HTTPRequest, local_path: String,
                     rel_path: String, progress_cb: Callable, total: int) -> void:
    req.queue_free()
    _in_progress.erase(rel_path)
    if result != HTTPRequest.RESULT_SUCCESS or response_code != 200:
        push_warning("[AssetRegistry] fetch 실패: %s (code=%d)" % [rel_path, response_code])
        return
    # 디스크 캐시 저장
    var dir_path := local_path.get_base_dir()
    DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(dir_path))
    var f := FileAccess.open(local_path, FileAccess.WRITE)
    if f == null:
        push_warning("[AssetRegistry] 쓰기 실패: %s" % local_path)
        return
    f.store_buffer(body)
    f.close()
    _fetched[rel_path] = local_path
    _loaded_bytes += body.size()
    asset_fetched.emit(rel_path, local_path)
    if progress_cb.is_valid():
        progress_cb.call(_loaded_bytes, total)
    if _loaded_bytes >= total and _in_progress.is_empty():
        all_assets_ready.emit()
        print("[AssetRegistry] 모든 자산 fetch 완료 (%d bytes)" % _loaded_bytes)

## 로컬 파일 경로 조회
func resolve_local(rel_path: String) -> String:
    if _fetched.has(rel_path):
        return _fetched[rel_path]
    var local_path := "user://persistent/assets/%s" % rel_path
    if FileAccess.file_exists(local_path):
        _fetched[rel_path] = local_path
        return local_path
    return ""

func is_ready() -> bool:
    return _manifest_ready
