extends GutTest
## 단위 테스트 골격 — Last Banner v2 (2026-07-16 검증)
## 사용법: 이 파일을 tests/unit/test_<autoload>.gd로 복사 → 함수 본문 작성
## 실행: godot --headless -s addons/gut/gut_cmdln.gd \
##            -gdir=res://tests/unit -gprefix=test_ -gsuffix=.gd -gexit

# ─────────────────────────────────────────────────────────────
# autoload 인스턴스 (Godot 4.7 autoload는 자동으로 글로벌 노출)
# ─────────────────────────────────────────────────────────────

# ─────────────────────────────────────────────────────────────
# before_each / after_each — autoload 싱글턴이라 명시 격리 필수
# ─────────────────────────────────────────────────────────────

func before_each() -> void:
	# autoload 상태 리셋 (이전 테스트 영향 제거)
	# GameWorld.gold = 200
	# GameWorld.food = 100
	# GameWorld.population = 50
	# GameWorld.prosperity = 10
	# GameWorld.fortification_level = 1
	# GameWorld.event_log.clear()
	# GameWorld.day_gold_change = 0
	# GameWorld.day_food_change = 0
	# TimeManager.minutes_elapsed = 0
	# TimeManager.day = 1
	pass

func after_each() -> void:
	# 테스트 후 정리 (필요 시)
	pass

# ─────────────────────────────────────────────────────────────
# assert 헬퍼 함수 (Gut 내장)
# ─────────────────────────────────────────────────────────────
# assert_true(expr, msg)
# assert_false(expr, msg)
# assert_eq(actual, expected, msg)
# assert_ne(actual, expected, msg)
# assert_lt(actual, threshold, msg)
# assert_le(actual, threshold, msg)
# assert_gt(actual, threshold, msg)
# assert_ge(actual, threshold, msg)
# assert_null(thing, msg)
# assert_not_null(thing, msg)
# assert_string_contains(text, substring, msg)
# assert_almost_eq(actual, expected, msg, tolerance)
# wait_frames(N), wait_seconds(T), wait_until_signal(...)

# ─────────────────────────────────────────────────────────────
# 테스트 케이스 예시 (Last Banner v2 GameWorld)
# ─────────────────────────────────────────────────────────────

func test_modify_resource_gold_increments_and_emits() -> void:
	# 시그널 캡처 (lambda connect 패턴)
	# var captured: Array = []
	# GameWorld.resource_changed.connect(func(r, v): captured.append({"r": r, "v": v}))
	# GameWorld.modify_resource("gold", 50)
	#
	# assert_eq(GameWorld.gold, 250, "gold +50 → 250")
	# assert_eq(captured.size(), 1, "시그널 1회 emit")
	# assert_eq(captured[0]["r"], "gold")
	# assert_eq(captured[0]["v"], 250)
	pass

func test_modify_resource_prosperity_clamped_0_to_100() -> void:
	# GameWorld.prosperity = 95
	# GameWorld.modify_resource("prosperity", 50)
	# assert_eq(GameWorld.prosperity, 100, "prosperity 100 cap")
	# GameWorld.modify_resource("prosperity", -150)
	# assert_eq(GameWorld.prosperity, 0, "prosperity 0 floor")
	pass

func test_modify_resource_fortification_clamped_1_to_5() -> void:
	# GameWorld.modify_resource("fortification_level", 10)
	# assert_eq(GameWorld.fortification_level, 5, "fortification 5 cap")
	# GameWorld.modify_resource("fortification_level", -100)
	# assert_eq(GameWorld.fortification_level, 1, "fortification 1 floor")
	pass

func test_modify_resource_unknown_pushes_warning() -> void:
	# unknown resource는 silent drop (no-op)
	# var before_gold: int = GameWorld.gold
	# GameWorld.modify_resource("coffee", 100)
	# assert_eq(GameWorld.gold, before_gold, "unknown resource는 gold에 영향 X")
	pass

func test_apply_daily_economy_basic_population_50() -> void:
	# population=50, prosperity=10
	#   tax     = max(5, 10 + 50/4) = 22
	#   harvest = max(2, 50/4) = 12
	#   consumed = 50/10 = 5
	# var gold_before: int = GameWorld.gold
	# GameWorld.apply_daily_economy()
	# assert_eq(GameWorld.gold - gold_before, 22, "일일 +22 gold")
	# assert_eq(GameWorld.food, 100 + 12 - 5, "일일 +7 food")
	pass

func test_apply_daily_economy_low_population_min_taxes() -> void:
	# population=0, prosperity=0 → min 세수 5, min 수확 2
	# GameWorld.population = 0
	# GameWorld.prosperity = 0
	# GameWorld.apply_daily_economy()
	# assert_eq(GameWorld.day_gold_change, 5, "min 세수 5")
	# assert_eq(GameWorld.day_food_change, 2, "min 수확 2")
	pass

func test_log_event_appends_and_caps_at_50() -> void:
	# ring buffer 50 한도
	# GameWorld.event_log.clear()
	# for i in range(60):
	#     GameWorld.log_event("evt-%d" % i)
	# assert_eq(GameWorld.event_log.size(), 50, "ring buffer 50 한도")
	# assert_eq(GameWorld.event_log[0]["message"], "evt-10", "오래된 10개 evict")
	pass

func test_save_state_round_trip() -> void:
	# save → 망가뜨리기 → load → 정합성
	# GameWorld.gold = 1234
	# GameWorld.food = 567
	# GameWorld.event_log.append({"day": 5, "message": "test"})
	# var state: Dictionary = GameWorld.save_state()
	#
	# GameWorld.gold = 0
	# GameWorld.food = 0
	# GameWorld.event_log.clear()
	#
	# GameWorld.load_state(state)
	# assert_eq(GameWorld.gold, 1234, "load 후 gold 복원")
	# assert_eq(GameWorld.food, 567, "load 후 food 복원")
	# assert_eq(GameWorld.event_log.size(), 1)
	pass

func test_summary_format_includes_lord_name() -> void:
	# GameWorld.lord_name = "테스트 영주"
	# var s: String = GameWorld.summary()
	# assert_true(s.contains("테스트 영주"), "영주 이름 포함")
	# assert_true(s.contains("gold=200"), "자원 gold 포함")
	pass

# ─────────────────────────────────────────────────────────────
# 비동기 테스트 패턴 (필요 시)
# ─────────────────────────────────────────────────────────────

# func test_async_decision_queue_push() -> void:
#     # await 패턴 — 헤드리스에서 hang 가능성 있으므로 sync 선호
#     DecisionQueue.push("TEST_EVENT", {"title": "test"}, DecisionQueue.Priority.LOW)
#     var pending: Array = DecisionQueue.get_all_pending()
#     assert_gt(pending.size(), 0, "큐에 push됨")
#     for d in pending:
#         if d.type == "TEST_EVENT":
#             DecisionQueue.resolve(d.id, {"id": "test", "label": "OK"})
#             return
#     fail_test("TEST_EVENT not found in queue")
