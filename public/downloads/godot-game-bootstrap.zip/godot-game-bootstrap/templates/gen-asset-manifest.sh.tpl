#!/usr/bin/env bash
# gen-asset-manifest.sh — 풀 자산을 카테고리별 파일 목록 + 사이즈 JSON으로 변환.
# 출력: asset_host.json
# 사용: bash tools/gen-asset-manifest.sh <base_url>
#   base_url: 자산이 호스팅될 CDN URL (예: https://cdn.jsdelivr.net/gh/<user>/<repo>@main/assets)

set -euo pipefail

LB_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ASSETS_DIR="$LB_ROOT/assets"
OUT="$LB_ROOT/asset_host.json"
BASE_URL="${1:-https://cdn.jsdelivr.net/gh/<user>/<repo>@main/assets}"

python3 - "$BASE_URL" "$ASSETS_DIR" "$OUT" <<'PYEOF'
import sys, os, json
from pathlib import Path
from datetime import datetime, timezone

base_url = sys.argv[1]
assets_dir = Path(sys.argv[2])
out_path = Path(sys.argv[3])

categories = {}
total = 0

for cat_dir in sorted(assets_dir.iterdir()):
    if not cat_dir.is_dir():
        continue
    if cat_dir.name.startswith("."):
        continue
    files = []
    sizes = {}
    cat_size = 0
    # 서브폴더 재귀
    for f in sorted(cat_dir.rglob("*")):
        if f.is_file() and not f.name.startswith("."):
            rel = f.relative_to(assets_dir).as_posix()
            sz = f.stat().st_size
            files.append(rel)
            sizes[rel] = sz
            cat_size += sz
    if not files:
        continue
    categories[cat_dir.name] = {
        "kind": cat_dir.name,
        "file_count": len(files),
        "size_bytes": cat_size,
        "base_url": base_url,
        "files": files,
        "sizes": sizes
    }
    total += cat_size

manifest = {
    "version": 1,
    "generated_at": datetime.now(timezone.utc).isoformat(),
    "base_url": base_url,
    "total_size_bytes": total,
    "category_count": len(categories),
    "categories": categories
}

out_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False))
print(f"✓ {out_path} ({len(categories)} categories, {total/1024/1024:.1f} MB)")
PYEOF
