extends Node
## DecisionQueue — 우선순위별 결정 큐.
## CRITICAL이면 즉시 GameManager.pause_for_decision() 호출.

signal decision_added(decision)
signal decision_resolved(decision_id)

enum Priority { LOW, MEDIUM, HIGH, CRITICAL }

var _queue: Array = []
var _next_id: int = 0

func push(decision_type: String, payload: Dictionary, priority: Priority = Priority.MEDIUM) -> int:
    var id := _next_id
    _next_id += 1
    var entry := {
        "id": id,
        "type": decision_type,
        "payload": payload,
        "priority": priority,
        "created_at_game_time": TimeManager.minutes_elapsed,
        "resolved": false
    }
    var insert_idx := _queue.size()
    for i in range(_queue.size()):
        if _queue[i].priority < priority:
            insert_idx = i
            break
    _queue.insert(insert_idx, entry)
    decision_added.emit(entry)
    if priority == Priority.CRITICAL:
        GameManager.pause_for_decision()
    return id

func resolve(decision_id: int, choice: Dictionary) -> bool:
    for entry in _queue:
        if entry.id == decision_id and not entry.resolved:
            entry.resolved = true
            entry.resolution = choice
            _queue.erase(entry)
            decision_resolved.emit(decision_id)
            if not has_pending_critical() and GameManager.current_state == GameManager.State.DECISION_PENDING:
                GameManager.resume_after_decision()
            return true
    return false

func peek_next() -> Dictionary:
    if _queue.is_empty():
        return {}
    return _queue[0]

func get_all_pending() -> Array:
    return _queue.duplicate()

func has_pending_critical() -> bool:
    for entry in _queue:
        if entry.priority == Priority.CRITICAL and not entry.resolved:
            return true
    return false

func has_any_pending() -> bool:
    return not _queue.is_empty()

func save_state() -> Dictionary:
    return {"queue": _queue.duplicate(), "next_id": _next_id}

func load_state(data: Dictionary) -> void:
    _queue = data.get("queue", []).duplicate()
    _next_id = data.get("next_id", 0)
