extends Node
## AssetRegistry — 게임이 사용하는 자산 카테고리 매니페스트.
## 실제 파일은 심볼릭 링크 또는 풀에서 직접. 이 스크립트는 카탈로그 역할.

const MANIFEST := {
    # 예시 — 카테고리별로 채워넣기
    # "heroes": {
    #     "kind": "3d_character",
    #     "format": "glb",
    #     "license": "CC0",
    #     "source": "KayKit Character Pack: Adventurers 1.0",
    #     "path": "res://assets/heroes/",
    #     "usage": "주인공/용병 영웅"
    # },
}

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    print("[AssetRegistry] 매니페스트 로드 — %d 카테고리" % MANIFEST.size())

func get_category(name: String) -> Dictionary:
    return MANIFEST.get(name, {})

func list_categories() -> Array:
    return MANIFEST.keys()

func summary() -> String:
    var lines: PackedStringArray = ["AssetRegistry — %d 카테고리:" % MANIFEST.size()]
    for cat in MANIFEST:
        var m: Dictionary = MANIFEST[cat]
        lines.append("  • %s — %s [%s]" % [cat, m.get("license", "?"), m.get("format", "?")])
    return "\n".join(lines)
