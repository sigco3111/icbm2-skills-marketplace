extends Node
## SaveManager — 게임 상태 영속화.
## user:// 가 데스크탑에서는 OS 표준 위치, Web에서는 IndexedDB에 자동 매핑.

const SAVE_VERSION := 1
const AUTO_SAVE_INTERVAL_MIN := 60

var auto_save_enabled: bool = true
var _last_auto_save_min: int = 0

func new_game(slot: String) -> void:
    var state := _initial_state()
    _write(slot, state)

func load_game(slot: String) -> bool:
    var path := _slot_path(slot)
    if not FileAccess.file_exists(path):
        return false
    var f := FileAccess.open(path, FileAccess.READ)
    if f == null:
        return false
    var json := JSON.new()
    if json.parse(f.get_as_text()) != OK:
        f.close()
        return false
    f.close()
    var data: Dictionary = json.data
    _apply_state(data)
    return true

func save_game(slot: String) -> bool:
    var state := _capture_state()
    return _write(slot, state)

func maybe_auto_save() -> void:
    if not auto_save_enabled:
        return
    var now := TimeManager.minutes_elapsed
    if now - _last_auto_save_min >= AUTO_SAVE_INTERVAL_MIN:
        if save_game("autosave"):
            _last_auto_save_min = now

func list_saves() -> Array:
    var dir := DirAccess.open("user://")
    if dir == null:
        return []
    var files: Array = []
    dir.list_dir_begin()
    var fname := dir.get_next()
    while fname != "":
        if fname.ends_with(".json"):
            files.append(fname.get_basename())
        fname = dir.get_next()
    dir.list_dir_end()
    return files

func _initial_state() -> Dictionary:
    return {
        "version": SAVE_VERSION,
        "created_at": Time.get_unix_time_from_system(),
        "time": TimeManager.save_state(),
        "decisions": DecisionQueue.save_state()
    }

func _capture_state() -> Dictionary:
    return {
        "version": SAVE_VERSION,
        "created_at": Time.get_unix_time_from_system(),
        "time": TimeManager.save_state(),
        "decisions": DecisionQueue.save_state()
    }

func _apply_state(data: Dictionary) -> void:
    if data.has("time"):
        TimeManager.load_state(data["time"])
    if data.has("decisions"):
        DecisionQueue.load_state(data["decisions"])

func _write(slot: String, state: Dictionary) -> bool:
    var path := _slot_path(slot)
    var f := FileAccess.open(path, FileAccess.WRITE)
    if f == null:
        return false
    f.store_string(JSON.stringify(state, "  "))
    f.close()
    return true

func _slot_path(slot: String) -> String:
    return "user://save_%s.json" % slot
