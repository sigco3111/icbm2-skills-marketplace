#!/usr/bin/env bash
# setup-assets.sh — 풀에서 게임용 자산만 골라 심볼릭 링크로 연결.
# 변수는 환경변수로 override 가능. 멱등 (idempotent).

set -euo pipefail

LB_ROOT="${LB_ROOT:-$HOME/work/<game-name>}"
POOL_ROOT="${POOL_ROOT:-$HOME/work/game-assets-pool}"
WES_SRC="${WES_SRC:-$HOME/work/game-assets/sources/wesnoth/data/core/images}"

ASSETS_DIR="$LB_ROOT/assets"
mkdir -p "$ASSETS_DIR"/{heroes,enemies,props,units/wesnoth,portraits/wesnoth,tiles/hex,ui/{icons,map_icons},audio/{music,sfx}}

echo "🎯 자산 풀 매니페스트 구성"
echo "  LB_ROOT=$LB_ROOT"
echo "  POOL_ROOT=$POOL_ROOT"

link() {
    local target="$1"
    local link_path="$2"
    if [ -e "$link_path" ] || [ -L "$link_path" ]; then
        echo "  ✓ 기존: $link_path"
    else
        mkdir -p "$(dirname "$link_path")"
        ln -s "$target" "$link_path"
        echo "  + 링크: $link_path → $target"
    fi
}

# === KayKit Heroes (예시: KayKit Adventurers) ===
KAYKIT_ADV="$POOL_ROOT/free/3D/CC0/KayKit_Character_Pack_Adventurers_1.0/KayKit-Character-Pack-Adventures-1.0-main/addons/kaykit_character_pack_adventures/Characters/gltf"
for hero in Knight Barbarian Mage Rogue Rogue_Hooded; do
    link "$KAYKIT_ADV/$hero.glb" "$ASSETS_DIR/heroes/kaykit/$hero.glb"
done

# === KayKit Dungeon Remastered (예시) ===
KAYKIT_DUN="$POOL_ROOT/free/3D/CC0/KayKit_Dungeon_Remastered_1.0/KayKit-Dungeon-Remastered-1.0-main/addons/kaykit_dungeon_remastered/Assets/gltf"
for f in banner_thin_red banner_patternA_yellow barrel_small_stack candle_thin candle_triple wall_arched wall_doorway_Tsplit wall_open_scaffold trunk_large_B bed_floor; do
    found=$(find "$KAYKIT_DUN" -maxdepth 1 -name "${f}*.glb" 2>/dev/null | head -1)
    if [ -n "$found" ]; then
        link "$found" "$ASSETS_DIR/props/kaykit_dungeon/$f.glb"
    fi
done

# === Wesnoth units (base idle PNG만) ===
echo "── Wesnoth 유닛 base 포즈만 ──"
for faction in human-loyalists human-outlaws dunefolk dwarves elves-wood monsters undead-skeletal orcs goblins; do
    src_dir="$WES_SRC/units/$faction"
    dst_dir="$ASSETS_DIR/units/wesnoth/$faction"
    [ ! -d "$src_dir" ] && continue
    mkdir -p "$dst_dir"
    count=0
    while IFS= read -r png; do
        base=$(basename "$png")
        # 공격/방어/라이딩/죽음 프레임 제외 — base 포즈만
        if echo "$base" | grep -qE "\-(attack|defend|melee|ranged|mounted|die|crossbow|bow|sword|spear|axe|gun|throw|wand|magic|range)\-"; then
            continue
        fi
        if [ ! -e "$dst_dir/$base" ]; then
            ln -s "$png" "$dst_dir/$base"
            count=$((count+1))
        fi
    done < <(find "$src_dir" -maxdepth 1 -type f -name "*.png" 2>/dev/null)
    echo "  ✓ $faction: $count base PNG"
done

# === Wesnoth portraits (.webp) ===
for faction in humans dunefolk elves dwarves; do
    src_dir="$WES_SRC/portraits/$faction"
    dst_dir="$ASSETS_DIR/portraits/wesnoth/$faction"
    [ ! -d "$src_dir" ] && continue
    mkdir -p "$dst_dir"
    count=0
    while IFS= read -r img; do
        [ ! -e "$dst_dir/$(basename "$img")" ] && ln -s "$img" "$dst_dir/$(basename "$img")" && count=$((count+1))
    done < <(find "$src_dir" -maxdepth 1 -type f \( -name "*.webp" -o -name "*.png" \) 2>/dev/null)
    echo "  ✓ portraits $faction: $count"
done

# === Wesnoth music (core) ===
WES_MUSIC="$HOME/work/game-assets/sources/wesnoth/data/core/music"
[ -d "$WES_MUSIC" ] && {
    count=0
    while IFS= read -r ogg; do
        [ ! -e "$ASSETS_DIR/audio/music/$(basename "$ogg")" ] && ln -s "$ogg" "$ASSETS_DIR/audio/music/$(basename "$ogg")" && count=$((count+1))
    done < <(find "$WES_MUSIC" -maxdepth 2 -type f -name "*.ogg" -size +10k 2>/dev/null)
    echo "  ✓ music: $count"
}

# === Wesnoth sounds ===
WES_SFX="$HOME/work/game-assets/sources/wesnoth/data/core/sounds"
[ -d "$WES_SFX" ] && {
    count=0
    while IFS= read -r ogg; do
        [ ! -e "$ASSETS_DIR/audio/sfx/$(basename "$ogg")" ] && ln -s "$ogg" "$ASSETS_DIR/audio/sfx/$(basename "$ogg")" && count=$((count+1))
    done < <(find "$WES_SFX" -maxdepth 3 -type f \( -name "*.ogg" -o -name "*.wav" \) -size +1k 2>/dev/null)
    echo "  ✓ sfx: $count"
}

echo
echo "✅ 자산 매니페스트 구성 완료"
echo "총 심볼릭 링크: $(find "$ASSETS_DIR" -type l 2>/dev/null | wc -l)"
