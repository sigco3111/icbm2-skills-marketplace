#!/usr/bin/env bash
# build.sh — 멀티플랫폼 export.
# 사용: bash tools/build.sh [web|mac|windows|linux|all]

set -euo pipefail

LB_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD_DIR="$LB_ROOT/build"
mkdir -p "$BUILD_DIR"

echo "→ Godot import..."
cd "$LB_ROOT"
godot --headless --import 2>&1 | tail -5

if [ ! -d "$HOME/Library/Application Support/Godot/export_templates" ]; then
    echo "⚠ Godot export templates 미설치. https://godotengine.org/download 에서 다운로드 후"
    echo "  ~/Library/Application Support/Godot/export_templates/<버전>/ 로 이동"
fi

target="${1:-web}"

case "$target" in
    web)        mkdir -p "$BUILD_DIR/web"; godot --headless --export-release "Web" "$BUILD_DIR/web/index.html" 2>&1 | tail -10 ;;
    mac|macos)  mkdir -p "$BUILD_DIR/macos"; godot --headless --export-release "macOS" "$BUILD_DIR/macos/Last Banner.app" 2>&1 | tail -10 ;;
    windows|win) mkdir -p "$BUILD_DIR/windows"; godot --headless --export-release "Windows" "$BUILD_DIR/windows/Game.exe" 2>&1 | tail -10 ;;
    linux)      mkdir -p "$BUILD_DIR/linux"; godot --headless --export-release "Linux" "$BUILD_DIR/linux/Game.x86_64" 2>&1 | tail -10 ;;
    all)        for t in web mac windows linux; do bash "$0" "$t" || echo "  ✗ $t 실패"; done ;;
    *) echo "사용: bash tools/build.sh [web|mac|windows|linux|all]"; exit 1 ;;
esac

echo "✅ $target build 완료"
