extends Node
## UITheme — 색상 팔레트 + 스타일 헬퍼 중앙 관리
## Last Banner v4.0.0+ 실전 검증 (2026-07-20)
##
## 사용법:
##   1) 본 파일을 `res://autoload/ui_theme.gd`로 복사
##   2) project.godot autoload 섹션에 등록: `UITheme="*res://autoload/ui_theme.gd"`
##   3) main.gd `_ready()`에서 `UITheme.apply_*` 일괄 호출
##
## 핵심 원칙:
##   - 모든 색상 리터럴은 UITheme 상수 참조 (tscn에 Color(...) 박지 말 것)
##   - tscn은 구조만, 색은 .gd 코드에서 일괄 적용
##   - 새 우선순위/자원 추가 시 이 파일 한 곳만 수정

# ─── 배경 ─────────────────────────────────────────
const BG_BASE := Color(0.10, 0.07, 0.05, 1.0)            # 베이지-다크 (만국 공통)
const BG_PANEL := Color(0.16, 0.12, 0.09, 0.95)          # PanelContainer 배경
const BG_PANEL_LIGHT := Color(0.22, 0.17, 0.13, 0.92)    # 강조 Panel
const BG_PANEL_DARK := Color(0.08, 0.06, 0.04, 0.95)     # 깊은 패널
const BG_MODAL := Color(0.12, 0.08, 0.06, 0.97)          # 모달 카드
const BG_RESOURCE_CARD := Color(0.20, 0.15, 0.10, 0.85)  # 자원 카드
const BG_BUTTON := Color(0.30, 0.24, 0.18, 0.95)         # 일반 버튼
const BG_BUTTON_HOVER := Color(0.42, 0.34, 0.26, 0.95)
const BG_BUTTON_PRESS := Color(0.20, 0.16, 0.12, 0.95)

# ─── 텍스트 ───────────────────────────────────────
const TEXT_PRIMARY := Color(0.95, 0.92, 0.85, 1.0)       # 본문
const TEXT_SECONDARY := Color(0.78, 0.72, 0.60, 1.0)     # 보조
const TEXT_DIM := Color(0.55, 0.50, 0.42, 1.0)           # 흐림
const TEXT_TITLE := Color(0.98, 0.92, 0.70, 1.0)         # 제목 (금빛)
const TEXT_DANGER := Color(1.00, 0.55, 0.45, 1.0)
const TEXT_SUCCESS := Color(0.55, 0.85, 0.55, 1.0)
const TEXT_NEGATIVE := Color(1.00, 0.65, 0.50, 1.0)
const TEXT_POSITIVE := Color(0.65, 0.90, 0.65, 1.0)

# ─── 자원 색상 ────────────────────────────────────
const COLOR_GOLD := Color(1.00, 0.85, 0.30, 1.0)
const COLOR_FOOD := Color(0.65, 0.85, 0.40, 1.0)
const COLOR_POPULATION := Color(0.50, 0.75, 0.95, 1.0)
const COLOR_PROSPERITY := Color(0.95, 0.80, 0.50, 1.0)

# ─── 우선순위 색상 ─────────────────────────────────
const PRIORITY_LOW := Color(0.65, 0.65, 0.70, 1.0)
const PRIORITY_MEDIUM := Color(0.50, 0.75, 0.95, 1.0)
const PRIORITY_HIGH := Color(1.00, 0.75, 0.30, 1.0)
const PRIORITY_CRITICAL := Color(1.00, 0.40, 0.40, 1.0)
const PRIORITY_LOW_BG := Color(0.25, 0.25, 0.28, 0.95)
const PRIORITY_MEDIUM_BG := Color(0.18, 0.25, 0.35, 0.95)
const PRIORITY_HIGH_BG := Color(0.35, 0.25, 0.12, 0.95)
const PRIORITY_CRITICAL_BG := Color(0.40, 0.15, 0.15, 0.95)

# ─── 충성도 색상 ───────────────────────────────────
const LOYALTY_HIGH := Color(0.55, 0.85, 0.55, 1.0)       # ≥70
const LOYALTY_MID := Color(0.95, 0.85, 0.45, 1.0)        # 40~69
const LOYALTY_LOW := Color(0.95, 0.55, 0.45, 1.0)        # <40

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS

## ─── 색상 매핑 헬퍼 ─────────────────────────────
func resource_color(resource: String) -> Color:
	match resource:
		"gold": return COLOR_GOLD
		"food": return COLOR_FOOD
		"population": return COLOR_POPULATION
		"prosperity": return COLOR_PROSPERITY
		_: return TEXT_PRIMARY

func priority_color(priority: int) -> Color:
	match priority:
		0: return PRIORITY_LOW
		1: return PRIORITY_MEDIUM
		2: return PRIORITY_HIGH
		3: return PRIORITY_CRITICAL
		_: return PRIORITY_LOW

func priority_bg(priority: int) -> Color:
	match priority:
		0: return PRIORITY_LOW_BG
		1: return PRIORITY_MEDIUM_BG
		2: return PRIORITY_HIGH_BG
		3: return PRIORITY_CRITICAL_BG
		_: return PRIORITY_LOW_BG

func loyalty_color(loyalty: int) -> Color:
	if loyalty >= 70: return LOYALTY_HIGH
	elif loyalty >= 40: return LOYALTY_MID
	else: return LOYALTY_LOW

## ─── 포맷 헬퍼 ──────────────────────────────────
func format_change(delta: int) -> String:
	if delta > 0: return "+%d" % delta
	elif delta < 0: return "%d" % delta
	else: return "0"

func change_color(delta: int) -> Color:
	if delta > 0: return TEXT_POSITIVE
	elif delta < 0: return TEXT_NEGATIVE
	return TEXT_DIM

## ─── StyleBoxFlat 빌더 ───────────────────────────
func make_panel_style(bg: Color = BG_PANEL, border: Color = Color(0.40, 0.32, 0.22, 0.6), border_w: int = 1, radius: int = 4) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = bg
	style.border_color = border
	style.set_border_width_all(border_w)
	style.set_corner_radius_all(radius)
	style.content_margin_left = 12
	style.content_margin_right = 12
	style.content_margin_top = 8
	style.content_margin_bottom = 8
	return style

func make_button_style(bg: Color = BG_BUTTON, border: Color = Color(0.70, 0.55, 0.30, 0.8), radius: int = 6) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = bg
	style.border_color = border
	style.set_border_width_all(1)
	style.set_corner_radius_all(radius)
	style.content_margin_left = 14
	style.content_margin_right = 14
	style.content_margin_top = 8
	style.content_margin_bottom = 8
	return style

func make_priority_badge_style(bg: Color, fg: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = bg
	style.border_color = fg
	style.set_border_width_all(1)
	style.set_corner_radius_all(3)
	style.content_margin_left = 8
	style.content_margin_right = 8
	style.content_margin_top = 2
	style.content_margin_bottom = 2
	return style

func make_progress_style(fg: Color, bg: Color = Color(0.10, 0.08, 0.06, 1.0)) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = fg
	style.set_corner_radius_all(2)
	return style

func make_progress_bg_style(bg: Color = Color(0.10, 0.08, 0.06, 1.0)) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = bg
	style.set_corner_radius_all(2)
	return style

## ─── 노드 적용 헬퍼 ──────────────────────────────
func apply_style(control: Control, style: StyleBoxFlat) -> void:
	if control and style:
		control.add_theme_stylebox_override("panel", style)

func apply_button_styles(button: Button, base: Color = BG_BUTTON) -> void:
	if button == null: return
	var normal_style := make_button_style(base)
	var hover_style := make_button_style(base.lerp(Color.WHITE, 0.15))
	var pressed_style := make_button_style(base.lerp(Color.BLACK, 0.2))
	var disabled_style := make_button_style(base.lerp(Color.BLACK, 0.5))
	button.add_theme_stylebox_override("normal", normal_style)
	button.add_theme_stylebox_override("hover", hover_style)
	button.add_theme_stylebox_override("pressed", pressed_style)
	button.add_theme_stylebox_override("disabled", disabled_style)
	button.add_theme_color_override("font_color", TEXT_PRIMARY)
	button.add_theme_color_override("font_hover_color", TEXT_TITLE)
	button.add_theme_color_override("font_pressed_color", TEXT_TITLE)
	button.add_theme_color_override("font_disabled_color", TEXT_DIM)

func apply_progress_styles(pb: ProgressBar, fg: Color) -> void:
	if pb == null: return
	pb.add_theme_stylebox_override("fill", make_progress_style(fg))
	pb.add_theme_stylebox_override("background", make_progress_bg_style())
	pb.add_theme_color_override("font_color", TEXT_PRIMARY)

func apply_label_color(label: Label, color: Color) -> void:
	if label: label.add_theme_color_override("font_color", color)

func apply_change_color(label: Label, delta: int) -> void:
	apply_label_color(label, change_color(delta))