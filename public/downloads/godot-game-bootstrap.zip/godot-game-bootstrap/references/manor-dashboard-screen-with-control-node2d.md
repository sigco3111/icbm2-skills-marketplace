# Manor Dashboard — Control > Node2D 직접 그림 패턴 (Last Banner v2 검증)

> 게임 내 풍경도(영지, 전투, 마을) 화면을 만들 때 **Control 위 Node2D**에 직접 Sprite2D/ColorRect/Label을 add_child하는 패턴. SubViewport 회귀 없이 v1 SubViewport 패턴보다 단순.

## 의도

Wesnoth 2D 픽토그램을 화면에 띄울 때 가장 흔한 함정:
- **SubViewport + Node2D** → 검은 화면 / 사이즈 0 / 위치 어긋남 (v1 Last Banner 회귀)
- **단순 Control > Sprite2D** → Sprite2D가 Control의 자식일 때 position 좌표계가 다름

**해결**: `Control` 안에 `Node2D` (`SceneHost`) 두고, 그 `Node2D`에 `Sprite2D`/`ColorRect`/`Label` 직접 add. position은 컨트롤 좌표 그대로 (320, 240 = 화면 중앙).

## 검증된 패턴 (Last Banner 2026-07-16 v2.1.x)

### 씬 구조 (manor_dashboard.tscn)

```
ManorDashboard (Control)
├── BG (ColorRect, anchor 0/0/1/1)
└── CenterRoot (HBoxContainer, anchor 0/0/1/1)
    ├── LeftColumn (VBoxContainer)
    │   ├── ManorTitle (PanelContainer) → TitleLabel
    │   ├── ManorScene (PanelContainer, size_flags_vertical=3)
    │   │   └── SceneHost (Control, mouse_filter=2)
    │   │       └── SceneRoot (Node2D)   ← Sprite 부모
    │   └── BottomRowInColumn (HBoxContainer)
    │       ├── VisitorCard (PanelContainer)
    │       └── QuickStatsCard (PanelContainer)
    └── RightColumn (VBoxContainer)
        ├── RosterTitle (PanelContainer)
        └── RosterList (PanelContainer, size_flags_vertical=3)
            └── RosterScroll (ScrollContainer)
                └── RosterVBox (VBoxContainer)   ← 동적 행 add_child
```

### 핵심: SceneHost Control 안에 Node2D (= SceneRoot)

```gdscript
# scenes/manor_dashboard.tscn
[node name="ManorScene" type="PanelContainer" parent="CenterRoot/LeftColumn"]
size_flags_vertical = 3

[node name="SceneHost" type="Control" parent="CenterRoot/LeftColumn/ManorScene"]
anchor_right = 1.0
anchor_bottom = 1.0
mouse_filter = 2

[node name="SceneRoot" type="Node2D" parent="CenterRoot/LeftColumn/ManorScene/SceneHost"]
```

### 동적 그림 (manor_dashboard.gd)

```gdscript
extends Control

var scene_root: Node2D = null

func _ready():
    scene_root = get_node_or_null("CenterRoot/LeftColumn/ManorScene/SceneHost/SceneRoot") as Node2D
    if scene_root == null:
        push_error("[Dashboard] scene_root 없음 — 씬 구조 확인")
        return
    _draw_manor_scene()

func _draw_manor_scene():
    # 풀밭 (배경 ColorRect)
    var bg := ColorRect.new()
    bg.color = Color(0.32, 0.36, 0.22, 1)
    bg.size = Vector2(720, 460)
    bg.position = Vector2.ZERO
    bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
    scene_root.add_child(bg)

    # 흙길
    var ground := ColorRect.new()
    ground.color = Color(0.48, 0.42, 0.28, 1)
    ground.size = Vector2(720, 140)
    ground.position = Vector2(0, 280)
    ground.mouse_filter = Control.MOUSE_FILTER_IGNORE
    scene_root.add_child(ground)

    # 캐릭터 5명 (Sprite2D)
    for unit in SCENE_UNITS:
        _add_unit_sprite(unit)

func _add_unit_sprite(unit: Dictionary) -> bool:
    var path: String = unit.get("path", "")
    if not ResourceLoader.exists(path):
        push_warning("[Dashboard] 자산 없음: %s" % path)
        return false
    var tex: Texture2D = load(path)
    if tex == null or tex.get_width() == 0:
        return false
    var sprite := Sprite2D.new()
    sprite.texture = tex
    sprite.centered = true
    sprite.position = unit.get("pos", Vector2.ZERO)
    sprite.scale = Vector2(unit.get("scale", 1.0), unit.get("scale", 1.0))
    scene_root.add_child(sprite)

    var lbl := Label.new()
    lbl.text = unit.get("label", "")
    lbl.position = unit.get("pos", Vector2.ZERO) + Vector2(-32, 70)
    lbl.add_theme_font_size_override("font_size", 14)
    scene_root.add_child(lbl)
    return true
```

## 검증된 함정 7가지

### 1. SubViewport가 검은 화면
- `SubViewport`에 `Node2D` 직접 add하면 표시 안 됨 (size=0, depth mismatch)
- **v1 last-banner에서 텍스트만 보인 원인**
- **해결**: Control 안 Node2D 직접 사용 (= 위 패턴)

### 2. Sprite가 안 보임
- `Sprite2D.texture`가 null (load 실패) → 검은 1px 정사각형 표시
- `tex.get_width() == 0` 가드 추가
- 동적 인스턴스화 후 한 프레임 대기 (queue_redraw)

### 3. 팔레트 인덱스 PNG 안 보임
- Wesnoth PNG는 `8-bit colormap` 헤더 — 1KB 미만 PLTE 섹션에 색 등록
- Godot 4.7은 자동 처리 → 통상 ctex로 import됨
- 만약 검은 화면이면 `.import` 파일 미생성. **원인 90%**: 디렉터리에 `.gdignore` 존재. res:// 직접 사용 시 `.gdignore` 삭제 필수.

### 4. .gdignore가 자산 import 차단
- v1 lazy fetch 패턴에서 "pck에서 빼기"용으로 만든 `.gdignore`
- v2 (res:// 직접 사용)에서는 **위험** — 자산 폴더 전체 import 차단 → Sprite2D 텍스처 = 빈 검은 정사각형
- **해결**: `setup-assets.sh`에서 `.gdignore` 생성 라인을 제거. `find assets -name ".gdignore" -delete` 일괄 정리.

### 5. 진입 시 Anchor 위치 어긋남
- `Control.anchor_left/right`가 기본 0.0/0.0이면 좌상단 기준
- `size_flags_horizontal=3` (fill+expand) 안 줘서 부모가 줄어들면 안 늘어남
- **해결**: `anchor_right=1.0` + `size_flags_horizontal=3` 조합 또는 명시 `custom_minimum_size`

### 6. `ManorDashboard`가 `ManorScene` 자식 Sprite를 가림
- z-order는 자식 추가 순서. **뒤에 추가된 게 위에 그려짐**
- ManorDashboard 인스턴스가 ModalLayer보다 먼저 root에 추가됨 → 모달 가려짐
- **해결**: 모달을 별도 `ModalLayer` (CanvasLayer, `layer=100`) 으로 분리 (아래 reference 참조)

### 7. TextureRect avatar가 안 보임
- `TextureRect.expand_mode` 기본 0 (KEEP) → 작은 크기에서 라벨만 보임
- `expand_mode=1` (IGNORE_SIZE) + `stretch_mode=5` (KEEP_ASPECT_CENTERED) 설정
- 텍스처 = null이면 placeholder ColorRect 반환 (LB_VERIFY assert로 검증)

## 핵심 검증 (LB_VERIFY 단계)

```gdscript
# 화면 그리기 검증 — sprite 5개 + avatar 5개 모두 정상 로드
print("[9] ManorDashboard 화면 검증")
var dashboard: Control = get_node_or_null("ManorDashboard") as Control
if dashboard:
    var scene_root_node: Node = dashboard.get_node_or_null("CenterRoot/LeftColumn/ManorScene/SceneHost/SceneRoot")
    assert(scene_root_node != null, "scene_root 없음 — SceneHost/SceneRoot 경로")
    var sprite_count: int = 0
    var tex_rect_count: int = 0
    for child in scene_root_node.get_children():
        if child is Sprite2D:
            sprite_count += 1
    print("  ✓ Manor Scene sprites: %d" % sprite_count)
    assert(sprite_count == 5, "5명 sprite 모두 필요 (현재 %d)" % sprite_count)
    var roster_node: Node = dashboard.get_node_or_null("CenterRoot/RightColumn/RosterList/RosterScroll/RosterVBox")
    for child in roster_node.get_children():
        for sub in child.get_children():
            if sub is TextureRect:
                tex_rect_count += 1
                break
    var roster_count: int = roster_node.get_child_count()
    print("  ✓ Roster rows: %d (avatar TextureRect: %d)" % [roster_count, tex_rect_count])
    assert(roster_count == 5)
    assert(tex_rect_count == 5)
```

## 동적 노드 참조 (instantiation 순서 함정 회피)

```gdscript
# ❌ @onready var dashboard: Control = $ManorDashboard — null 가능
# ✓ manual search in _ready()
func _ready() -> void:
    scene_root = get_node_or_null("CenterRoot/LeftColumn/ManorScene/SceneHost/SceneRoot") as Node2D
    if scene_root == null:
        return
    _draw_manor_scene()
```

검증: LB_VERIFY에서 "scene_root=NULL" 경고 나오면 tscn에서 노드 이름이 정확한지 grep.

## 헤드리스 한계

`_ready()`에서 동적 노드 add는 헤드리스에서도 작동하지만 **실제 시각 검증은 안 됨**. **사용자 Mac 데스크탑 더블클릭 필요**. 헤드리스에서 sprite가 정상 추가됐는지 (= LB_VERIFY step 9 PASS) 확인 후 사용자 시각 검수로 마무리.

## 적용 가능 게임

- 매너지 풍경도 (v2 Last Banner)
- 전투 화면 그리드 + 캐릭터 배치
- 마을 지도 (마을 건물 sprite + 농지 ColorRect)
- 로비 화면 (배경 + 캐릭터 콜렉션)

⇒ "Control > Node2D 직접 그림"은 **SubViewport 회귀를 피하는 가장 단순한 패턴**.
