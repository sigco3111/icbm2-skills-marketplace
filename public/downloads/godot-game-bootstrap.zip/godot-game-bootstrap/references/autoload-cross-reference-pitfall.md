# Autoload Cross-Reference Pitfall (2026-07-16 last-banner-v2 실전)

## 증상

`godot --headless --import` 출력:
```
SCRIPT ERROR: Parse Error: Identifier "X" not declared in the current scope.
   at: GDScript::reload (res://autoload/Y.gd:N)
SCRIPT ERROR: Compile Error: Failed to compile depended scripts.
   at: GDScript::reload (res://autoload/Z.gd:0)
ERROR: Failed to create an autoload, script 'res://autoload/Y.gd' is not compiling.
```

## 원인

같은 이름 변수가 여러 autoload에 있을 때, GDScript는 `self` 멤버만 자동 인식. **다른 autoload 멤버는 자동 임포트 안 됨** (Python의 from-import 없음). 같은 파일에 멤버가 없으면 `Identifier not declared` 파스 에러.

예: `TimeManager`에 `var day: int`, `GameWorld`에 같은 멤버 없을 때, `GameWorld.gd` 안에서:
```gdscript
# ❌ Identifier "day" not declared
print("[GameWorld] Day %d — gold %+d" % [day, day_gold_change])
```

→ GameWorld autoload 로드 실패 → GameManager 등 의존 파일 컴파일 실패 연쇄 → 부팅 hang.

## 해결

autoload 멤버 접근할 땐 **항상 글로벌 이름 명시**:
```gdscript
print("[GameWorld] Day %d — gold %+d" % [TimeManager.day, day_gold_change])
var entry := {"day": TimeManager.day, "message": message}
```

## 진단법

`godot --headless --import` 1회면 4~5개 autoload 동시 파스 에러를 한 번에 잡힘.

파스 에러가 떴을 때 grep으로 멤버 정의를 찾는다:
```bash
grep -rn "var X:" autoload/
```

## 미연에 방지하는 패턴

autoload 새 멤버 추가할 때 다른 autoload와 이름 충돌을 자동 검사:
```bash
grep -hn "^var " autoload/*.gd | awk -F'[ :]' '{print $3}' | sort | uniq -c | sort -rn
# count > 1인 줄이 충돌 후보
```

## 본 함정이 잡힌 실전 케이스

`last-banner-v2/autoload/game_world.gd:53,56`:
```gdscript
func apply_daily_economy() -> void:
    # ...
    day_gold_change = tax
    day_food_change = harvest - consumed
    print("[GameWorld] Day %d — gold %+d, food %+d" % [day, day_gold_change, day_food_change])  # ← 파스 에러

func log_event(message: String) -> void:
    var entry := {"day": day, "message": message}  # ← 같은 파스 에러
```

`time_manager.gd`에 `var day: int` 있었고 `game_world.gd`엔 없었음. → `TimeManager.day`로 명시하여 해결.

## Pinned SKILL.md 안에 합치거나 별도 파일 보존 여부

이 함정은 godot-game-bootstrap 스킬 본문의 "Autoload cross-reference 이름 명시 (2026-07-16 last-banner-v2 실전)" 섹션에도 짧게 있음. 이 reference는 **grep 진단 명령** + **이름 충돌 자동 검사 패턴**을 보존.
