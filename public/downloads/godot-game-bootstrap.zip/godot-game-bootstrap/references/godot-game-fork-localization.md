# Godot 4 Game Fork Localization — 실전 패턴 모음

> 2026-07-27 youtd2-kr (Praytic/youtd2) fork 실전 검증.
> Godot 4 + GitHub 게임 fork + 한국어화 + 외부 에셋 + CLA 회피의 전체 워크플로.

## 1. Google Drive 외부 에셋 — curl 병렬 다운로드 (78MB / 345파일 / 49초)

**시나리오**: Godot 4 게임이 345개 에셋 (PNG/OGG/CSV)을 Google Drive에 호스팅. `gdown --folder` 30분+ 회피.

**1단계 — gdown --json으로 URL 목록 추출** (1회, 5초):
```bash
~/.local/bin/gdown --folder "https://drive.google.com/drive/folders/1U4wTjBu2qo1cInH3IAowsFC5yq56V5uQ?usp=sharing" --json > /tmp/filelist.json
# warning: `--json` is in beta
```

**출력 형식**:
```json
[
  {"url": "https://drive.google.com/uc?id=1_cgMvaeodvRNR1S2S97wwK8haecp8qCk", "path": "creeps/orc/air/fly_E.png"},
  {"url": "https://drive.google.com/uc?id=13x6hhgRxd7Rx-BinrMP_aZTaXiPWiNjU", "path": "creeps/orc/air/fly_N.png"},
  ...
]
```

**2단계 — Python ThreadPoolExecutor + curl 직접 (16 workers, 49초)**:
```python
#!/usr/bin/env python3
import json, subprocess, os, time
from concurrent.futures import ThreadPoolExecutor, as_completed

data = json.load(open('/tmp/filelist.json'))
os.makedirs('/tmp/assets', exist_ok=True)

def download(entry):
    url, path = entry['url'], entry['path']
    outpath = f'/tmp/assets/{path}'
    if os.path.exists(outpath) and os.path.getsize(outpath) > 0:
        return path, 'skip'
    os.makedirs(os.path.dirname(outpath), exist_ok=True)
    try:
        result = subprocess.run(
            ['curl', '-sSLo', outpath, url],
            capture_output=True, timeout=15
        )
        # HTML redirect 응답 가드 (Google Drive 인증 실패)
        if os.path.exists(outpath):
            with open(outpath, 'rb') as f:
                head = f.read(100)
            if b'<html' in head.lower() or b'<' in head[:10]:
                os.remove(outpath)
                return path, 'html-err'
        return path, 'ok' if result.returncode == 0 else 'fail'
    except Exception:
        return path, 'err'

# Clean partial
subprocess.run(['find', '/tmp/assets', '-size', '0', '-delete'], capture_output=True)

start = time.time()
done = 0
with ThreadPoolExecutor(max_workers=16) as ex:
    futures = [ex.submit(download, e) for e in data]
    for f in as_completed(futures):
        path, status = f.result()
        done += 1
        if done % 50 == 0:
            elapsed = time.time() - start
            rate = done / elapsed
            eta = (len(data) - done) / rate if rate > 0 else 0
            print(f'  [{done}/{len(data)}] {elapsed:.0f}s elapsed, {rate:.1f} f/s, ETA {eta:.0f}s', flush=True)

total_size = sum(
    os.path.getsize(f'/tmp/assets/{d["path"]}')
    for d in data
    if os.path.exists(f'/tmp/assets/{d["path"]}')
)
print(f'\nTotal: {done} files, {total_size/1024/1024:.1f} MB, {time.time()-start:.1f}s')
```

**실측 결과 (youtd2-kr 2026-07-27)**:
- 345 파일, 76.3 MB, **48.8초**
- gdown --folder 동일 작업 30분+ vs 49초 = **37배 빠름**

**gdown --folder vs curl 직접 차이**:
- gdown: Python startup + 매 파일마다 Google Drive API 호출 (5초+/파일)
- curl: 바이너리 직접 (1.9초/파일)
- 16 workers 병렬 = throughput 16배

**실패 가드 3개**:
1. `os.path.exists && size > 0` → 재시작 시 skip
2. HTML 응답 가드 (`<html in head`) → Google Drive redirect 캡처
3. `timeout=15` → 한 파일 hang 방지

## 2. csv_translation importer — 4개 언어에서 5번째 추가

**시나리오**: `assets/texts/texts.csv`가 `keys, en, zh, it` 4컬럼. 한국어 ko 컬럼 추가.

**texts.csv 변환 (Python csv writer, quote 처리 안전)**:
```python
import csv
with open('assets/texts/texts.csv', encoding='utf-8', newline='') as f:
    reader = csv.reader(f)
    header = next(reader)
    rows = list(reader)

new_header = header + ['ko']
with open('assets/texts/texts.csv', 'w', encoding='utf-8', newline='') as f:
    writer = csv.writer(f, quoting=csv.QUOTE_ALL)
    writer.writerow(new_header)
    writer.writerows([r + [''] for r in rows])
```

**주의 — multiline cell**: csv.reader는 quote된 cell 안의 newline을 자동 처리. wc -l로 row 수 ≠ reader row 수가 정상 (5,916 row vs 15,174 줄 = 멀티라인 cell 존재).

**texts.csv.import 업데이트 (dest_files에 ko 추가)**:
```ini
[remap]
importer="csv_translation"
type="Translation"
uid="uid://b4mco2dr478ww"

[deps]
files=["res://assets/texts/texts.en.translation", "res://assets/texts/texts.zh.translation",
       "res://assets/texts/texts.it.translation", "res://assets/texts/texts.ko.translation"]
source_file="res://assets/texts/texts.csv"
dest_files=["res://assets/texts/texts.en.translation", "res://assets/texts/texts.zh.translation",
            "res://assets/texts/texts.it.translation", "res://assets/texts/texts.ko.translation"]

[params]
compress=true
delimiter=0
```

**project.godot에 ko translation 추가**:
```ini
[internationalization]
locale/translations=PackedStringArray(
    "res://assets/texts/texts.zh.translation",
    "res://assets/texts/texts.en.translation",
    "res://assets/texts/texts.it.translation",
    "res://assets/texts/texts.ko.translation"
)
```

**Godot 자동 동작**:
- `godot --headless --import` 한 번 → `csv_translation` importer가 `texts.csv` 5번째 컬럼 읽어서 `texts.ko.translation` 자동 생성
- `tr("KEY")` 호출 시 가장 먼저 일치하는 translation → ko → en → en fallback 순
- **영문 fallback 자동** = 한국어 미번역 키는 영어 그대로 노출 (별도 작업 불필요)

## 3. Language enum + UI 콤보박스 확장 (5곳 동시 수정)

**5곳 동시 수정 안 하면 인덱스 에러**:
1. `src/enums/language.gd` — `enum enm`에 KOREAN 추가
2. `language_map: Dictionary` — ko 매핑
3. `language_option_map: Dictionary` — KOREAN → 3
4. `language_option_locale_map: Dictionary` — 3 → "ko"
5. 콤보박스 .tscn — `popup/item_3/text = "한국어"`, `popup/item_3/id = 3`

**language.gd 패치** (youtd2 실전):
```gdscript
class_name Language extends Node

enum enm {
	ENGLISH,
	CHINESE,
	ITALIAN,
	KOREAN,
}

static var language_map: Dictionary = {
	Language.enm.ENGLISH: "en",
	Language.enm.CHINESE: "zh",
	Language.enm.ITALIAN: "it",
	Language.enm.KOREAN: "ko",
}

static var language_option_map: Dictionary = {
	Language.enm.ENGLISH: 0,
	Language.enm.CHINESE: 1,
	Language.enm.ITALIAN: 2,
	Language.enm.KOREAN: 3,
}

static var language_option_locale_map: Dictionary = {
	0:"en",
	1:"zh",
	2:"it",
	3:"ko",
}
```

**.tscn 콤보박스 item 추가** (patch):
```ini
popup/item_0/text = "English"
popup/item_1/text = "中文"
popup/item_1/id = 1
popup/item_2/text = "Italiana"
popup/item_2/id = 2
+popup/item_3/text = "한국어"
+popup/item_3/id = 3
```

## 4. 한글 폰트 — theme.tres fallbacks vs .gd 동적 적용

**5가지 폰트 함정 (2026-07-27 youtd2-kr 실전)**:
1. **NotoSansCJKkr-Regular.otf = OTF** → Godot 4 `font_data_dynamic` 직접 로더 미지원 → `No loader found` → 폰트 안 로드 → 한글 □
2. **Apple SD Gothic Neo (TTC) = TTC** → 마찬가지 미지원. macOS 시스템 폰트 심볼릭 링크 우회 불가
3. **theme.tres가 단일 폰트만 ext_resource** → `fallbacks` 필드 없음 → 한글 fallback 어디로도 안 감
4. **NotoSansSC-Medium.ttf = 중국어** → 한글 글리프 없음 → 한자만 렌더링되고 한글은 □
5. **theme_override_fonts/font 동적 적용** (v2.3+ last-banner 검증) = 가장 확실

**해결 1 — NanumGothic.ttf (TTF + 한글 + 라틴, 2MB, SIL OFL 1.1)**:
```bash
curl -fsSL -o assets/fonts/NanumGothic.ttf \
  "https://github.com/google/fonts/raw/main/ofl/nanumgothic/NanumGothic-Regular.ttf"
# 2MB, TTF, 한국어 + 라틴 글리프
```

**해결 2 — .gd 동적 적용 (가장 확실, last-banner 검증 패턴)**:
```gdscript
# main.gd
const KOREAN_FONT := preload("res://assets/fonts/NanumGothic.ttf")

func _ready() -> void:
    var theme := Theme.new()
    theme.default_font = KOREAN_FONT
    theme.default_font_size = 24
    _apply_theme_recursive(self, theme)

func _apply_theme_recursive(node: Node, theme: Theme) -> void:
    if node is Control:
        (node as Control).theme = theme
    for child in node.get_children():
        _apply_theme_recursive(child, theme)
```

**해결 3 — theme.tres에 fallbacks 필드 추가** (1순위는 해결 2):
```ini
; resources/theme/wc3_theme.tres
[gd_resource type="Theme" load_steps=2 format=3]
[ext_resource type="FontFile" uid="uid://d1pnwehsosppo" path="res://assets/fonts/Friz Quadrata Std Medium.otf" id="1"]
[ext_resource type="FontFile" uid="uid://bkoreanfallback0001" path="res://assets/fonts/NotoSansCJKkr-Regular.otf" id="2"]

[sub_resource type="FontFile" id="FontFile_ko"]
fallbacks = Array[Resource]([ExtResource("2")])
```

단, OTF → Godot이 자체 .fontdata로 변환 후에는 정상 작동. `godot --headless --import` 실행 후 `.godot/imported/NotoSansCJKkr-Regular.otf-*.fontdata` 생성 확인.

## 5. LICENSE.MODIFIED 패턴 — CLA + CC-BY-NC 동시 발견 시

**상황**: root `LICENSE` = MIT (코드 자유), `assets/LICENSE.md` = CC-BY-NC 4.0 (에셋 비상업), `CONTRIBUTING.md` = CLA (PR 시 저작권 양도).

**LICENSE.MODIFIED 템플릿**:
```
<repo>-kr (한국어화 fork) — License Notice
================================================

This repository is a Korean localization + improvement fork of:
  <owner>/<upstream> (https://github.com/<owner>/<upstream>)
  Copyright (c) <year> <original author>
  Licensed under the MIT License (see LICENSE file in this repository).

This fork (sigco3111/<repo>-kr) is independently maintained by sigco3111.
Original code copyright and MIT license terms remain in effect for the
upstream code. Any new code contributed by the fork author (sigco3111)
is released under the same MIT License for compatibility with upstream.

What this fork adds:
  - Korean (ko-KR) localization: tower/builder/ability/item names,
    UI strings, tooltips, descriptions.
  - README in Korean.
  - Convenience scripts (e.g. for building the Korean edition).

What this fork does NOT change:
  - Core game logic, gameplay, balance.
  - Asset files under assets/ (these remain CC-BY-NC 4.0 — see
    assets/LICENSE.md; NON-COMMERCIAL distribution only).
  - Upstream's CLA policy (any future PR to upstream is governed
    by upstream CONTRIBUTING.md; this fork is independent).

Distribution notes:
  - Source code: MIT, free to use, modify, redistribute with attribution.
  - Assets: CC-BY-NC 4.0 (NonCommercial). Commercial use (paid Steam,
    paid itch.io, paid bundles, etc.) of THIS FORKBUILD is NOT permitted
    under the asset license, even with code changes.
  - Free distribution (itch.io tip-jar, GitHub Releases, free Steam)
    is permitted.

For the full upstream license, see:
  - LICENSE (MIT, this directory)
  - assets/LICENSE.md (CC-BY-NC 4.0 for assets)

Last updated: <date>
```

**판단 기준**:
- 라이선스 MIT only → LICENSE.MODIFIED 불필요
- 라이선스 MIT + assets CC-BY-NC → LICENSE.MODIFIED 필수 (상업 배포 명시)
- CLA 발견 + MIT + assets OK → LICENSE.MODIFIED 권장 (fork가 upstream CLA 무관 명시)

**CLA 발견 시 fork vs PR 결정 트리 (2026-07-27 youtd2-kr 실전)**:
- **PR 보내는 경우**: 기여자 코드 저작권을 메인테이너에게 양도 → 본인 코드 권리 잃음. 한국어 번역처럼 "내가 기여한 코드"가 많아질수록 권리 박탈 큼
- **독립 fork 유지하는 경우 (권장)**: sigco3111/<repo>-kr 생성 → LICENSE.MODIFIED로 "fork는 upstream CLA 무관" 명시 → PR 안 보내고 자체 유지보수
- **판단**: 한국어 i18n 기여 = 누가 봐도 가치 있는 큰 작업 → PR로 돌려주면 한국어 번역 권리가 upstream으로. fork 유지가 본작 보호 + 더 많은 작업 가능
- **비용**: PR 머지 시 upstream 빠른 버그픽스 받기 가능 / fork는 직접 머지해야 함
- **LICENSE.MODIFIED에 한 줄 명시**: `Any future PR to upstream is governed by upstream CONTRIBUTING.md; this fork is independent.`

**`item_count = N` 명시 함정 (2026-07-27 youtd2-kr 실전 결정적 발견)**: `popup/item_3/text = "한국어"` + `popup/item_3/id = 3`만 추가해도 콤보박스에 안 보임. **부모 OptionButton 노드에 `item_count = 3`이 명시**되어 있으면 Godot이 그 값만큼만 렌더링 → item_3은 무시됨.

**.tscn 수정 패턴 (필수: item_count 갱신)**:
```ini
[node name="Language" type="OptionButton" parent="..."]
selected = 0
item_count = 3                              ; ← 기존 값 (popup/item_3 추가해도 무시)
popup/item_0/text = "English"
popup/item_1/text = "中文"
popup/item_1/id = 1
popup/item_2/text = "Italiana"
popup/item_2/id = 2
popup/item_3/text = "한국어"                ; ← 추가
popup/item_3/id = 3
item_count = 4                              ; ← 변경 (또는 위의 item_count = 3 줄 삭제)
```

**진단 — 게임 실행 시 `--check-only` 에러**:
```
ERROR: Index p_which = 3 is out of bounds (popup->get_item_count() = 3).
   at: _select (scene/gui/option_button.cpp:386)
```
→ `Language.get_option_from_locale()`가 KOREAN = 3 반환 → `_language_combo.select(3)` 호출 → 콤보박스엔 3개뿐 → 인덱스 3 out of bounds

**Fix — 3가지 패턴 (택 1)**:
1. **`item_count` 줄 자체 삭제** (Godot이 popup/item_N 자동 카운트) — 가장 안전
2. **`item_count = N` 값만 증가** (예: 3 → 4) — 직접 수정
3. **GDScript에서 동적 add_item** — `_load_current_settings()`에서 `_language_combo.clear()` + `for lang in [...]: _language_combo.add_item(lang.name, lang.id)` → .tscn은 4개 그대로 두고 코드만 동적. **가장 안전 + tscn 직접 수정 안 해도 됨**

**선택 기준**:
- tscn을 git에서 직접 보고 관리하고 싶으면 패턴 1/2
- 코드만으로 옵션 관리하고 싶으면 패턴 3 (multilang 지원에 더 유연)

**함정** — Godot 4 에디터는 `item_count`를 .tscn 저장 시 자동 재계산해서 보통 잘 맞음. **하지만 외부에서 tscn 직접 패치하면 명시 값을 수동으로 갱신해야 함**. `--check-only`로 1차 검증 필수.

## 6. 5축 preflight 1분 스니펫

```bash
# 1) 외부 에셋 호스팅 (Google Drive / Dropbox / Mega)
grep -E "drive\.google\.com|dropbox\.com|mega\.nz" README.md CONTRIBUTING.md .github/CONTRIBUTING.md 2>/dev/null

# 2) 듀얼 라이선스 (root + assets)
curl -s "https://raw.githubusercontent.com/OWNER/REPO/main/LICENSE" | head -3
curl -s "https://raw.githubusercontent.com/OWNER/REPO/main/assets/LICENSE.md" 2>/dev/null | head -3

# 3) CLA (PR 시 저작권 양도)
curl -s "https://raw.githubusercontent.com/OWNER/REPO/main/.github/CONTRIBUTING.md" | \
  grep -iE "assign copyright|transfer all rights|grant all transferrable"

# 4) 한국어 갭
curl -s -H "Authorization: token $(cat ~/.hermes/secrets/github_token.txt)" \
  "https://api.github.com/search/issues?q=repo:OWNER/REPO+korean+OR+%ED%95%9C%EA%B5%AD%EC%96%B4&per_page=1" \
  | python3 -c "import json,sys; d=json.loads(sys.stdin.read()); print('Korean issues:', d.get('total_count', 0))"

# 5) 빌드 환경 정확 버전
curl -s "https://raw.githubusercontent.com/OWNER/REPO/main/project.godot" | \
  grep "config/features"
# → PackedStringArray("4.3") → brew godot 4.7.1과 미스매치 → 정확 버전 직접 다운로드
```

**3개 모두 OK + 한국어 0건 + 정확 버전 받음 = "🟢 즉시 진행"**:
- 외부 에셋 + 라이선스 OK + CLA 없음
- 한국어 0건 + lang dir 없음 → greenfield 가치 큼
- brew godot 4.7.1 + 프로젝트 4.3 → `Godot_v4.3-stable_macos.universal.zip` 직접 받기

**1개라도 🟠/🔴 = "사용자 결정 게이트"**:
- 외부 에셋만 → fork 후 curl 병렬 (49초) + LICENSE.MODIFIED
- CLA만 → 독립 fork + LICENSE.MODIFIED (CLA 무관 명시)
- 정확 버전만 → brew 4.7.1로 4.3 프로젝트 열기 시도 (보통 OK) + 안 되면 4.3 직접 다운로드

## 7. 헤드리스 preflight 4축

**1단계 — import 단계 (에셋 + translation 동시 검증)**:
```bash
godot --headless --quit --import 2>&1 | grep -E "(Importing|Saving to|import took|ERROR|loader)"
# 기대: "Importing file: res://assets/texts/texts.csv" + "import took 95 ms"
# 기대: "Importing dynamic font from: res://assets/fonts/NotoSansCJKkr-Regular.otf" + "Done saving"
# 위험: "No loader found for resource: res://assets/fonts/*.otf" → OTF/TTC 함정
```

**2단계 — autoload parse (language.gd 등)**:
```bash
godot --headless --quit --check-only 2>&1 | grep -E "(SCRIPT ERROR|Parse Error)"
# 기대: exit 0, SCRIPT ERROR 없음
# 위험: "Identifier \"day\" not declared" → autoload cross-reference (별도 스킬 함정)
```

**3단계 — enum 인덱스 (콤보박스 vs enum)**:
```bash
godot --headless --quit --check-only 2>&1 | grep "out of bounds"
# 위험: "Index p_which = 3 is out of bounds (popup->get_item_count() = 3)" → .tscn 캐시 vs 코드 미스매치
# 해결: .tscn import 1회 더 또는 _load_current_settings()에서 clear() + add_item 동적
```

**4단계 — tr() 키 검증 (translation 누락)**:
```bash
godot --headless --quit --check-only 2>&1 | grep -E "(Missing translation|tr_)"
# 위험: "Missing translation for KEY" → texts.csv에 키는 있는데 ko 비어있음 (en fallback)
# 해결: 정상 동작, 별도 작업 불필요 (영문 fallback이 자동)
```

**5축 모두 exit 0 = 빌드 가능**. 사용자에게 .app 빌드 + 스크린샷 위임.

## 8. 전체 워크플로 9단계 요약

1. **5축 preflight (1분)** — 외부 에셋 / 듀얼 라이선스 / CLA / 한국어 갭 / 빌드 버전
2. **Fork 생성 + clone + 에셋 받기 (5분)** — gh repo fork + curl 병렬 49초
3. **Godot 4.3 정확 버전 받기 (10초)** — GitHub releases 직접 다운로드
4. **5곳 동시 수정 (5분)** — texts.csv + texts.csv.import + project.godot + language.gd + .tscn 콤보박스
5. **한글 폰트 (2분)** — NanumGothic.ttf 다운로드 + .gd 동적 적용
6. **LICENSE.MODIFIED (1분)** — MIT + CC-BY-NC + CLA 무관 명시
7. **헤드리스 preflight 4축 (3분)** — import + parse + enum + tr
8. **사용자 .app 빌드 위임 (5분+)** — 시각 검증은 사용자 Mac 데스크탑
9. **첫 commit + push (1분)** — `git add . && git commit -m "feat: ko-KR localization (169/5916 keys)" && git push`

**총 소요 시간 30분** (사용자 .app 빌드 위임 제외).

## 9. 참고 자료

- `references/godot-web-mobile-ui-and-fonts.md` — 한글 폰트 미적용 함정 3종 (last-banner 검증)
- `references/godot4-web-export-pitfalls.md` — Web export 8가지 함정
- `references/autoload-cross-reference-pitfall.md` — autoload 멤버 cross-reference 파스 에러
- `references/macos-export-pitfalls.md` — Godot 4.7 macOS .app cascade 4단계
- `references/cdn-asset-placeholder-invalidation.md` — CDN placeholder 본문 가드
- `oss-fork-localization` SKILL — fork 워크플로 + LICENSE/MODIFIED + distribution
- `github-game-candidate-scouting` SKILL — 5축 매트릭스 + 19개 함정 (이번 패치로 external asset hosting + dual license + CLA 추가됨)
