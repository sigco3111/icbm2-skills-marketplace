# Wesnoth 2D Idle PNG 선택 가이드 (last-banner-v2 실전 검증, 2026-07-16)

Wesnoth 풀(`game-assets-pool/extracted/wesnoth/units/<faction>/`)에는 **각 유닛당 10~20장 PNG**가 들어있음 — idle 외에 attack/defend/melee/ranged/mounted/die/move/stand 등 전투 프레임이 대부분. 게임에 단일 idle PNG만 필요한 경우(2D 픽토그램) **90%는 버려야 함**.

## 실전 검증 라인업 (5 factions, 393 idle PNG)

| Faction | 풀 경로 | idle PNG 수 | 캐릭터 톤 |
|---|---|---|---|
| `human-loyalists` | `units/human-loyalists/` | 129 | 플레이어 진영. 정규 기사/궁수/창병 |
| `human-outlaws` | `units/human-outlaws/` | 63 | 모병/유격대. 강해 보이는 잡다한 외형 |
| `dunefolk` | `units/dunefolk/` | 1 (현재 풀에 1장뿐) | 이국 용병. 확장 시 `units/dunefolk/*.png` 풀 더 큰 풀에서 가져오기 |
| `undead-skeletal` | `units/undead-skeletal/` | 86 | 적 기본. 보스형 포함, 사악하지만 subtle |
| `orcs` | `units/orcs/` | 114 | 적 엘리트 |

선택 결과 확인: `find ~/work/last-banner-v2/assets/units -maxdepth 2 -type l | wc -l` = 393

## base idle PNG 찾기 — grep 패턴

Wesnoth 파일명 컨벤션:
- `<unit-id>.png` — base idle (정확히 단어 + `.png`)
- `<unit-id>-attack-N.png` — 공격 1/2/3/4 프레임
- `<unit-id>-defend.png` — 방어
- `<unit-id>-melee-attack-N.png` / `<unit-id>-ranged-attack-N.png` — 전투 1~4 프레임
- `<unit-id>-mounted.png` / `<unit-id>-mounted-horse.png` — 기마 변형
- `<unit-id>-die.png` — 사망
- `<unit-id>-stand-<frame>.png` — stand 변형 프레임

**포함 패턴** (단순 ID):
```
^[a-z0-9_-]+$
```

**제외 패턴**:
- `*-attack-*`
- `*-defend-*`
- `*-melee-*`
- `*-ranged-*`
- `*-mounted-*`
- `*-die-*`
- `*-move-*`
- `*-stand-*`
- `*-horse*`
- `*-idle*` (별도 idle 변형이 있는 경우, base를 우선)
- `*-frame_*` / `*-frame-*`

## setup-assets.sh 패턴 (실전 검증)

```bash
#!/usr/bin/env bash
set -e
PROJECT_DIR="$(dirname "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)")"
POOL_DIR="$HOME/work/game-assets-pool"
WESNOTH="$POOL_DIR/extracted/wesnoth"

link_unit_faction() {
  local faction="$1"
  local src="$WESNOTH/units/$faction"
  local dst="$PROJECT_DIR/assets/units/$faction"
  [ ! -d "$src" ] && { echo "    [SKIP] $faction"; return; }

  mkdir -p "$dst"
  cd "$src"
  for f in *.png; do
    [ -f "$f" ] || continue
    base="${f%.png}"
    case "$base" in
      *-attack-*|*-defend-*|*-melee-*|*-ranged-*|*-mounted-*|*-die-*|*-move-*|*-stand-*|*-horse*|*-idle*|*-frame_*|*-frame-*)
        continue ;;
    esac
    [ -f "$f" ] || continue
    if [[ "$base" =~ ^[a-z0-9_-]+$ ]] && [ ! -e "$dst/$f" ]; then
      ln -s "$src/$f" "$dst/$f"
    fi
  done
}

link_unit_faction "human-loyalists"
link_unit_faction "human-outlaws"
link_unit_faction "dunefolk"
link_unit_faction "undead-skeletal"
link_unit_faction "orcs"
```

## 던전 골격 ~700개 PNG 풀 → 실전 라인업

전체 풀을 긁으면 Wesnoth 본편은 **18 factions 합쳐서 ~1,800 PNG**. 그중 base idle은 약 400. 비율 ~22%.

**확장 가이드**: 신규 faction 추가 시 위 grep 패턴 동일 적용:
- `elves-wood` (~140 idle) — 동맹 군주/용병
- `dwarves` (~90 idle) — 산맥 동맹
- `monsters` (~100 idle) — 오크 외 적 추가
- `goblins` (~80 idle) — 약탈자 부류
- `nagas` (~50 idle) — 수상 적
- `trolls` (~30 idle) — 단일 거대 적

추가 시마다 `link_unit_faction "새faction"` 한 줄. `tools/setup-assets.sh` 재실행 idempotent (심볼릭 링크 존재하면 skip).

## portraits (서브폴더로 정확하게)

Wesnoth portraits는 `<faction>.png` 단일이 아닌 **`<faction>/<NPC_name>.webp`** 구조:
```
extracted/wesnoth/portraits/
├── humans/      (영주 후보)
├── dunefolk/    (이국 인물)
├── elves/       (엘프 NPC)
├── dwarves/
├── undead/      (적 보스)
├── orcs/        (오크 전사)
└── ... (12 factions)
```

**선별 패턴**: 단순 `ln -s`로 race 디렉터리 전체를 가리키면 끝 (Wesnoth = 게임 양식이므로 portrait는 그대로 OK). 다만 게임 컨셉이 CK3/EU4 정치 미학이면 인물 강조가 필요하므로 **12개씩만 선택** (영주 4명 + 후보 8명).

```bash
for race in humans dunefolk undead orcs; do
  src="$WESNOTH/portraits/$race"
  dst="$ASSETS_DIR/portraits/$race"
  [ -d "$src" ] || continue
  mkdir -p "$dst"
  count=0
  for f in "$src"/*.webp "$src"/*.png; do
    [ -f "$f" ] || continue
    base="$(basename "$f")"
    [ ! -e "$dst/$base" ] && ln -s "$f" "$dst/$base"
    count=$((count + 1))
    [ $count -ge 12 ] && break
  done
done
```

## .gdignore는 faction에만 — assets/ 자체엔 두지 말 것

```bash
# OK
for d in "$ASSETS_DIR"/units/*/ "$ASSETS_DIR"/portraits/*/; do
  [ -d "$d" ] && touch "$d/.gdignore"
done

# 절대 X
touch "$ASSETS_DIR/.gdignore"   # ← 폰트/사운드까지 다 차단
```

(자세한 .gdignore 함정은 본 SKILL.md의 `### \`.gdignore\` 자산 import 차단 함정` 섹션.)

## 진단 — 잘못된 풀에서 끌고 올 때 흔한 증상

| 증상 | 원인 |
|---|---|
| idle PNG 0개 | grep 패턴이 너무 엄격 → `-attack-` 외 다른 제외 패턴 추가 누락 |
| idle PNG 800개 이상 | 제외 패턴 누락 → attack 프레임까지 다 끌려옴 |
| portrait 0개 | 풀 경로에 포털이 `portraits/`가 아니라 `data/core/images/portraits/`인 경우 → 풀 README에서 정확한 경로 확인 |
| `.colorMap.png` 같이 이상한 PNG 등장 | 단순 ID가 아닌 대문자/특수문자 포함 → `^[a-z0-9_-]+$` 정규식이 자동 제외, 그러나 검증 필요 |
| `*.yaml` 파일이 폴더 안에 있음 | 풀에서 같이 옴. 게임에서는 `*.import` 옆에 `*.yaml` 있어도 무해 (Godot은 무시), 단 `find` 카운트에서 제외 필요 |

## 칼 결과 분석

last-banner-v2 셋업 결과:
```
[LINK] human-loyalists     → 129 idle PNG
[LINK] human-outlaws       → 63 idle PNG
[LINK] dunefolk            → 1 idle PNG   (이 풀에선 1장뿐)
[LINK] undead-skeletal     → 86 idle PNG
[LINK] orcs                → 114 idle PNG
[LINK] portraits/humans    → 12 portraits
[LINK] portraits/dunefolk  → 3 portraits
[LINK] portraits/undead    → 12 portraits
[LINK] portraits/orcs      → 12 portraits
총 393 idle PNG + 39 portraits
```

dunefolk가 1장뿐인 건 이 풀의 한계. Wesnoth 공식 1.18 trunk에서 가져오면 ~50 idle 확보 가능. 단 dunefolk는 컨셉 적합도 낮으니 다른 faction(elves/dwarves) 우선 고려.
