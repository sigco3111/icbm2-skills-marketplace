# Godot 4 Web Export — 인쇄·시그널·String 진단 함정 3종

Web export 환경에서 **헤드리스 검증으로는 발견 불가능하고, 브라우저에서만 폭발**하는 함정 3종. 시그널 emit은 정상이지만 콜백이 죽거나, 의도하지 않은 print가 heap을 잡아먹거나, 시그널 콜백이 emit 스레드에서만 동기 실행돼 의도와 다르게 흘러가는 패턴들.

## 1. `print("...%s" % str(node))` 스택 오버플로우 (2026-07-16 last-banner 실전)

**증상**: 헤드리스는 정상, **Web 빌드에서만 특정 시점 이후 흐름이 죽음**. 브라우저 콘솔에 `(NNN) Uncaught RangeError: Maximum call stack size exceeded`. 사용자는 "여전히 안됨" / 검은 화면.

**원인**: Godot Web export의 `print`는 `console.log`로 변환. `str(Godot Node)` 호출 시 Godot 런타임이 노드의 `__str__`을 호출하고, 그 안에서 `print` 로직이 다시 호출되며 **재귀** — 큰 노드 트리 (인스턴스화된 scene 7개) 에서 호출 깊이 폭발.

**증거 (last-banner)**:
```gdscript
# 추가한 진단 print (main.gd)
func _enter_game_mode() -> void:
    print("[Main] _enter_game_mode: menu_toggle_button=%s" % str(menu_toggle_button))
    # ...
```
이 한 줄 때문에 **X 버튼 클릭 → 스택 오버플로우 → 그 뒤 코드 미실행 → 메뉴 그대로 보임**.

**로컬 헤드리스는 왜 못 잡나**: Godot 헤드리스 `print`는 C++ `stdout`이라 재귀가 자연 종료. **Web export의 JS print만 무한 재귀**.

**해결 — 단일 규칙**:
> **Godot Node를 `print("...%s" % str(node))` 패턴으로 출력하지 말 것.**

대안:
- **Node 이름만** (재귀 안전): `print("[Debug] node: %s" % node.name)`
- **명시적 필드**: `print("[Debug] %s" % node.get_path())` 또는 `print("[Debug] enabled=%s" % node.visible)`
- **`label` 식별**: `print("label text: %s" % label.text)` (Node가 아니라 String)
- **on-screen debug**: `status_label.text = "디버그: %s" % str(value)` — Canvas에 직접 출력, 사용자가 즉시 확인

**로컬 헤드리스 검증이 통과해도 Web export는 다름** — 빌드 후 Web 환경에서 한 번은 실행 필수.

## 2. `@onready` 평가 순서와 인스턴스화 시점 (이미 SKILL.md에 있음 — 강화)

`@onready var x: Control = $SomeNode`는 `_ready()` 함수가 return하기 **전**에 평가. main scene의 자식 노드 (instanced scene 루트) 는 **자기 자신의 `_ready`가 끝나기 전**엔 인스턴스화 완료로 안 침 → `Nil` 반환.

**Web export에서 더 자주 폭발** — 초기화가 main scene 안의 자식 instanced scene들의 `_ready` 체인 끝나기 전에 evaluate.

**해결 패턴 — 동적 검색 + call_deferred**: SKILL.md에 있음. 핵심은 `@onready` 대신 일반 변수 + `call_deferred("_find_xxx")` + `get_node_or_null("Xxx")`.

## 3. `await get_tree().create_timer().timeout` 시그널 콜백 함정

자세한 함정 + 해결 + 대체 패턴은 `references/vercel-godot-web-export.md` 하단 "Godot 4 Web export — await get_tree().create_timer().timeout 시그널 콜백 함정" 섹션에 통합. **핵심**: Web export의 시그널 콜백에서 `await create_timer().timeout`는 hang — `call_deferred` 사용.

## 4. 시그널 핸들러 내 `print` 추가 시 `stale node` 폭주 함정 (확인됨)

Web export에서 **시그널이 emit되는 시점에 autoload는 살아있지만**, **시그널을 emit한 노드가 free되었다면** (예: 씬 전환, autoload unload) — `print`의 `str(node)` 가뭄. 다른 신호 연결로 **delete** 후 `print`가 호출되면 use-after-free.

**대응**: 시그널 콜백에서 `print(node)` 직전 `if not is_instance_valid(node): return` 가드. Godot 4에 `is_instance_valid()` 내장.

## 5. 다중 시그널 콜백 인자 미스매치 (이미 SKILL.md에 있음)

같은 함수가 여러 시그널에 connect될 때, 시그널마다 인자 개수가 다르면 ERROR. 핸들러는 **모든 인자를 디폴트로**:

```gdscript
func _on_mercenary_changed(_m = null, _reason: String = "") -> void:
    if visible: refresh()
```

ERROR가 나면 시그널 emit 체인이 중단 → 연쇄 hang 가능. **Web export에서 ERROR는 콘솔에만 출력**, 헤드리스에서도 stderr로 보이지만 **stale**가 되는 경우 많음. 시그널 connect grep으로 인자 일치 확인.

## 진단 워크플로 (Web export 디버깅 우선순위)

**증상 → 진단 순서**:

1. **Web export에서만 특정 시점 후 흐름이 죽음** → `print(...str(node))` 스택 오버플로우 의심 (1번)
2. **시그널 콜백에서 await 후 다음 라인 실행 안 됨** → `await create_timer().timeout` hang 의심 (3번)
3. **`Nil` 에러로 autoload·scene 인스턴스 호출** → `@onready` 평가 순서 의심 (2번)
4. **여러 시그널의 같은 핸들러 호출 시 부분 작동 안 함** → 인자 미스매치 ERROR 의심 (5번)
5. **인스턴스화된 노드가 사라진 후 시그널 emit** → stale node 의심 (4번)

**공통 — 로컬 헤드리스가 통과해도 Web export는 다름**. 빌드 후 5분 안에 사용자에게 Web URL로 한 번은 테스트 시키고, 사용자 디버깅이 막히면 로컬 `godot --path . --quit-after 30`로 전환.

## 시그널 핸들러 작성 안전 패턴 (요약)

```gdscript
# 안전 패턴
func _on_some_signal(arg1, arg2) -> void:
    # 1. Null 가드
    if arg1 == null:
        return
    # 2. await 금지 — call_deferred 사용
    call_deferred("_deferred_handler", arg1, arg2)

func _deferred_handler(arg1, arg2) -> void:
    # 3. is_instance_valid 가드
    if not is_instance_valid(some_node):
        return
    # 4. 정상 처리
    ...
```

**5개 규칙 요약**:
1. `print(str(node))` 금지
2. `@onready` 의존 줄이기 (동적 검색)
3. `await create_timer()` 시그널 콜백에서 금지 (`call_deferred`)
4. 핸들러에서 free된 노드 가드 (`is_instance_valid`)
5. 다중 시그널 핸들러는 모든 인자 디폴트

## 헤드리스 vs Web export 동작 차이 요약표

| 항목 | 헤드리스 (godot --path) | Web export (브라우저) |
|---|---|---|
| `print(str(node))` | 정상 (C++ stdout) | ❌ 스택 오버플로우 (JS console.log) |
| `await create_timer().timeout` | ✅ 정상 | ❌ hang (JS 비동기 컨텍스트) |
| `@onready $instancedScene` | 보통 정상 | ❌ Nil 가능 (자식 인스턴스화 순서) |
| 시그널 emit → free된 emitter | 보통 OK | ❌ use-after-free, ERROR 폭주 |
| `is_instance_valid(node)` | 정상 | 정상 (반드시 사용) |
| `var x: Dict = obj["key"]` 명시 타입 | 정상 | 정상 (반드시 사용, `:=` 추론 위험) |

→ **Web export 동작은 헤드리스로 100% 시뮬레이션 불가능**. 빌드 후 사용자에게 최소 1회 테스트 URL 제공 필수.
