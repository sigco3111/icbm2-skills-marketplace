# CDN Asset Placeholder Invalidation — fetch 성공처럼 보이지만 빈 파일 함정

**핵심 lesson (2026-07-16 last-banner 실전)**: jsDelivr에 업로드된 일부 자원이 **HTTP 200 + Content-Length: 73** 같은 placeholder 본문을 반환. fetch는 "성공"으로 끝났지만 디코딩 실패. 게임 흐름이 매달려 보임. **Ogg Vorbis 디코딩 에러 + 무한 로깅**이 백그라운드에서 계속됨.

## 증상 (last-banner 실전 출력)

```
[Main] 리소스 다운로드 완료 — fetch_button 다시 활성화
[AssetRegistry] 모든 자산 fetch 완료 (73 bytes)
ERROR: Ogg Vorbis decoding failed. Check that your data is a valid Ogg Vorbis audio stream.
   at: load_from_buffer (modules/vorbis/audio_stream_ogg_vorbis.cpp:693)
ERROR: Resource file not found: user://persistent/assets/audio/music/main_menu.ogg (expected type: unknown)
```

**`Content-Length: 73` 응답이 진짜 문제** — jsDelivr에 73 bytes짜리 placeholder Ogg가 실제로 존재 (`curl -I`로 확인 가능):

```bash
$ curl -sI "https://cdn.jsdelivr.net/gh/sigco3111/last-banner@main/assets/audio/music/main_menu.ogg"
HTTP/2 200
content-type: audio/ogg
content-length: 73       # ← 진짜 73 bytes 짜리 placeholder
```

## 왜 발생하나

jsDelivr/GitHub는 저장소에 실제로 파일이 있어도 **LFS 미연결 + submodule pointer 누락** 시 placeholder만 보여줌. 또는 **git subtree의 빈 blob**이 placeholder로 표시됨. Content-Length는 작은 정수(73, 145, 200 bytes 등)로 옴. HTTP 200이라 fetch 성공으로 처리되지만 `AudioStreamOggVorbis.load_from_file`은 디코딩 실패.

## 해결 — 1KB 미만은 무효 처리

**AudioManager.fetch_file 콜백** 또는 **AssetRegistry._on_async_done** 양쪽 어디서든 1KB threshold로 가드. 권장 위치: **AssetRegistry에서 무효 파일 자체를 저장 안 함 + AudioManager에서도 한 번 더 가드 (defense in depth)**.

```gdscript
# autoload/audio_manager.gd
func _load_stream_from_path(local_path: String) -> AudioStream:
    if not FileAccess.file_exists(local_path):
        return null
    # 1KB 미만 파일은 CDN placeholder (헤더만 있는 빈 Ogg 등) — 무효 처리
    var file_size: int = FileAccess.get_file_as_bytes(local_path).size()
    if file_size < 1024:
        print("[AudioManager] 무효 파일 (크기 %d bytes): %s" % [file_size, local_path])
        DirAccess.remove_absolute(ProjectSettings.globalize_path(local_path))
        return null
    var stream := AudioStreamOggVorbis.load_from_file(local_path)
    if stream == null:
        stream = load(local_path)
    return stream
```

**AssetRegistry에서 무효 파일도 무시 (선제적)** — fetch는 받지만 _fetched dict에 등록 안 함 + 진행률은 증가:

```gdscript
# autoload/asset_registry.gd (동기 다운로드 경로)
func _on_async_done(result, response_code, _headers, body, req, local_path, rel_path, progress_cb, queue, idx):
    req.queue_free()
    _in_progress.erase(rel_path)
    if result == HTTPRequest.RESULT_SUCCESS and response_code == 200:
        # 무효 파일 (CDN placeholder) — 저장 안 함
        if body.size() < 1024:
            push_warning("[AssetRegistry] 무효 파일 (%d bytes): %s" % [body.size(), rel_path])
            _fetch_done_files += 1
            if progress_cb.is_valid():
                progress_cb.call(_fetch_done_files, _fetch_total_files, _compute_pct())
            fetch_progress.emit(_fetch_done_files, _fetch_total_files, _compute_pct())
            _on_one_done(progress_cb, queue, idx)
            return
        # 정상 파일 — 저장
        var dir_path := local_path.get_base_dir()
        DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(dir_path))
        var f := FileAccess.open(local_path, FileAccess.WRITE)
        if f != null:
            f.store_buffer(body)
            f.close()
            _fetched[rel_path] = local_path
            _fetch_done_files += 1
            asset_fetched.emit(rel_path, local_path)
    # 콜백 + 시그널 둘 다
    if progress_cb.is_valid():
        progress_cb.call(_fetch_done_files, _fetch_total_files, _compute_pct())
    fetch_progress.emit(_fetch_done_files, _fetch_total_files, _compute_pct())
    _on_one_done(progress_cb, queue, idx)
```

## 진단법

```bash
# 무효 파일인지 확인 — Content-Length 확인
curl -sI "https://cdn.jsdelivr.net/gh/<user>/<repo>@<branch>/assets/<path>" | grep -i content-length

# body가 진짜 파일인지 확인 (헤더만 있고 본문 작은지)
curl -s "https://cdn.jsdelivr.net/..." | wc -c   # 73, 145 같은 작은 정수
```

**last-banner에서 무효로 판명된 카테고리**:
- `audio/music/main_menu.ogg` (73 bytes)
- `audio/music/elf-land.ogg` (72 bytes)
- `audio/music/*.ogg` 다수 (Wesnoth 음악 일부가 jsDelivr에서 placeholder만 노출)
- Wesnoth units/portraits 등 이미지 자산은 정상 (수 KB~수백 KB)

**실제 자산을 받으려면**: GitHub LFS 사용 또는 jsDelivr 대신 **ghcr.io / raw.githubusercontent.com 직접 사용** (raw는 placeholder 미반환). 또는 **CDN 우회 + 게임 프로젝트 pck에 직접 포함** (Vercel 100MB 한계 주의).

## 적용 기준

- **fetch 응답이 항상 신뢰할 수 있는 건 아님** — Content-Length 체크는 항상 첫 줄 방어선
- **100KB 미만 모든 바이너리** (오디오, 이미지, 폰트) → threshold 가드 필수
- **텍스트** (.json, .xml, .tres) → 100KB 미만도 정상일 수 있음 (manifest 파일 등) — 카테고리별 분기 권장

## 헤드리스가 잡지 못한 이유

`godot --headless`에서 `AudioStreamOggVorbis.load_from_buffer` 호출 시 **C++ 직접 처리**라 placeholder도 파싱 시도하다가 무음 또는 0 byte로 처리. **에러 메시지 출력 안 됨**. Web export의 JS 환경만 정직한 ERROR를 뱉음.

→ **CDN placeholder 같은 미묘한 무효 자원은 Web 빌드 후 사용자 환경에서만 보임**. 헤드리스로 "전부 OK" 나오면 안심하면 안 됨.

## 참고: last-banner 5차 시도 타임라인 (2026-07-16)

| 시도 | 변경 | 결과 |
|---|---|---|
| 1차 | fetch_all 시그널 미발생 | ProgressBar 0% 멈춤 |
| 2차 | 동시 다운로드 + 1KB 미만 무효 | 무효 파일 자동 삭제, 진행률 100% 도달, **게임 모드 진입** |

**세션의 다른 교훈과의 조합**:
- `references/three-layer-safety-net.md` — 3중 안전망으로 버튼 활성화 보장
- `references/godot4-web-export-print-signal-pitfalls.md` — `print(str(node))` 스택 오버플로우
- `references/godot4-web-export-pitfalls.md` — Web export 검은 화면 진단

세 가지가 합쳐져서 "lib.png가 73 bytes면 게임이 멈춤" 같은 함정을 종합 방어.
