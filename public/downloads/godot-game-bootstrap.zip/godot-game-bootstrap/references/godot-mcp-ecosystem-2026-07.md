# Godot MCP Ecosystem — 2026-07-16 Survey

> **Snapshot date**: 2026-07-16. 도구 생태계는 빠르게 변하므로 6개월 이내 재검증 권장.
> **대상**: Last Banner 프로젝트 (Godot 4.7.1 / macOS / Wesnoth 자산 풀 / Vercel Web 배포 / 자동 진행 로그라이크)
> **핵심 발견**: `hi-godot/godot-ai`가 README에서 **Hermes Agent를 공식 지원 클라이언트로 명시** — Last Banner에 가장 직접 적합.

## 1. Godot MCP Servers (씬 트리 / GDScript / 빌드)

### ⭐ 1순위: hi-godot/godot-ai (1,010⭐, MIT, v3.0.2)
- **한 줄**: Godot Asset Library에도 정식 등록된 MCP 서버. **Hermes Agent 공식 지원**. Python(uvx) + Godot 에디터 플러그인 + WebSocket 아키텍처.
- **왜 Last Banner에 적합**: 120+ ops / 43 MCP 툴로 결정 큐 모달, 자원바, 풍경도 같은 Control 트리 노드 직접 조작 + GDScript 패치 + 씬 검증 + 게임 실행 + 스크린샷까지 한 번에. 기존 `tools/build.sh` 흐름을 LLM이 그대로 따라할 수 있게 됨.
- **설치**:
  ```bash
  git clone https://github.com/hi-godot/godot-ai.git
  cp -r godot-ai/plugin/addons/godot_ai ~/work/<game>/addons/
  brew install uv   # 이미 설치됨 (uv 0.11.25)
  # Godot 에디터에서 Project > Project Settings > Plugins > Godot AI 활성화
  # Hermes 자동 등록: dock > Clients 탭 > "Hermes Agent" Configure
  # 또는 ~/.hermes/config.yaml mcp.servers에 수동 추가:
  #   command: uvx mcp-proxy==0.11.0 --transport streamablehttp http://127.0.0.1:8000/mcp
  ```
- **핵심 함정**:
  - AssetLib 버전은 GitHub 대비 지연 → 가능하면 **소스 클론**
  - **서버 URL은 항상 `http://127.0.0.1:8000/mcp`** (네트워크 노출 X)
  - macOS `uvx` 첫 실행 시 shared C extension lock → `UV_LINK_MODE=copy` env 자동 추가 (dock Configure가 처리)
  - 43 툴은 100 툴 cap 안에 들어가지만 `<domain>_manage` rollup 패턴이라 명시적 툴 호출 우선

### 2순위: Coding-Solo/godot-mcp (4,733⭐, MIT, JS)
- **한 줄**: 가장 인기 있는 베이스 MCP 서버. TypeScript, 헤드리스 GDScript 실행 + 씬 트리 조작 20 툴.
- **설치**:
  ```bash
  git clone https://github.com/Coding-Solo/godot-mcp.git
  cd godot-mcp && npm install && npm run build
  # ~/.hermes/config.yaml mcp.servers.godot-mcp:
  #   command: node
  #   args: ["/path/godot-mcp/dist/index.js", "--godot-path", "/opt/homebrew/bin/godot"]
  ```
- **핵심 함정**:
  - JS/Node 의존성 → 헤드리스 빌드 도구들과 별개 런타임
  - `godot --headless --check-only`를 `_init()`에서 호출 → **autoload cross-reference에서 false negative** ("Identifier not declared" 오류가 진짜 에러가 아닌데 에러로 잡힘) → Last Banner의 7종 autoload 환경에서 디버깅 혼란

### 3순위: tugcantopaloglu/godot-mcp (340⭐, MIT, TS, v3.1.0)
- **한 줄**: Coding-Solo fork로 **157 툴**까지 확장 + **autoload 검증이 `_initialize()`에서 SceneTree로 실제 컴파일** (Last Banner의 `autoload-cross-reference-pitfall`이 정확히 잡던 함정을 해결).
- **설치**:
  ```bash
  git clone https://github.com/tugcantopaloglu/godot-mcp.git
  cd tugcantopaloglu/godot-mcp && npm install && npm run build
  ```
- **핵심 함정**:
  - Godot 4.4+ 필수 → Last Banner 4.7.1 OK
  - 157 툴은 일부 MCP 클라이언트의 100 툴 cap 초과 → Hermes는 OK이지만 Cursor 등 일부 클라는 개별 enable 필요

### 4순위: HaD0Yun/Doyunha-Gopeak (230⭐, MIT, Bun, v2.3.9)
- **한 줄**: 한국어 README + Bun 런타임 + DAP 디버거 + GDScript LSP 통합. 95+ 툴.
- **설치**:
  ```bash
  bun add -g https://github.com/HaD0Yun/Doyunha-Gopeak/releases/download/v2.3.9/gopeak-2.3.9.tgz
  ```
- **핵심 함정**:
  - Bun 1.3.3+ 필수 — 절대 경로 설치 버그 (`$PWD/gopeak-2.3.9.tgz`로 명시)
  - 한국어 README가 메인보다 약간 lag — 영문 canonical
  - DAP 디버거는 헤드리스 환경에서 hang 가능

### 5순위: IvanMurzak/Godot-MCP (174⭐, Apache-2.0, C#, v0.17.1)
- **한 줄**: C# 에디터 애드온 + 자체 클라우드 백엔드(ai-game.dev) + Unity-MCP와 공유 스택 + npm 패키지 `godot-cli` 제공.
- **설치**:
  ```bash
  npm install -g godot-cli   # v0.17.1, Apache-2.0
  # Godot Editor > AssetLib > AI Game Developer 검색 > 설치
  godot-cli --health
  ```
- **핵심 함정**:
  - **클라우드 백엔드 의존** (ai-game.dev) — 셀프호스팅 가능하지만 기본은 외부
  - C# 프로젝트 우선 — GDScript는 동작하지만 도구 깊이가 얕음
  - Apache-2.0이지만 클라우드 컴포넌트 약관 별도

### 6순위 (Unity/Godot 통합): Glade-tool/glade-mcp (178⭐, MIT, C#, v0.7.14)
- **한 줄**: Unity/Godot 자동 감지 + 235+ 툴. Godot bridge는 `localhost:8766` WebSocket.
- **설치**:
  ```bash
  # 1) https://github.com/Glade-tool/glade-mcp/releases 에서 com.gladekit.mcp-bridge.zip
  # 2) addons/에 풀기 → plugin.cfg 위치 확인
  # 3) Project Settings > Plugins > GladeKit MCP Bridge 활성화
  ```
- **핵심 함정**:
  - **헤드리스/CI/웹 export 미지원** — 브리지 editor-only
  - **Godot Mono / C# 프로젝트 미지원** — GDScript OK이지만 .NET 모드 차단

## 2. Asset Generation MCPs (스프라이트 / 타일셋 / 음향)

### ⭐ 1순위: @pinkpixel/mcpollinations (41⭐, MIT, npm v1.3.1)
- **한 줄**: Pollinations.ai API 이미지/텍스트/오디오 생성 MCP. 무료 + BYOP(Bring Your Own Pollen).
- **Last Banner 사용**: Wesnoth PNG 기본 + 신규 NPC 일러스트 / 임시 풍경 / 분위기 음악
- **설치**: `npm install -g @pinkpixel/mcpollinations`
- **함정**: 무료 티어 rate limit (burst 시 429). 50+ 모델이지만 Wesnoth 같은 hand-drawn 스타일은 생성 어려움 → CC-BY 자산과 조합

### 2순위: artokun/comfyui-mcp (387⭐, MIT)
- **한 줄**: ComfyUI 로컬 백엔드 + 108 툴 + 29 AI 스킬 + Claude Code 플러그인. Flux/WAN/LT2.3/Qwen 모델.
- **함정**: GPU 필수 (Apple Silicon은 MPS fallback 느림) → Last Banner는 CC-BY 자산 우선이라 1순위 아님. 108+29 툴로 100 cap 주의

### 3순위: diivi/aseprite-mcp (307⭐)
- **한 줄**: Aseprite API 직접 제어 MCP. 스프라이트/레이어/프레임/팔레트/익스포트. Godot 지원 명시.
- **함정**: Aseprite 상용 라이선스 (Steam $20). Wesnoth PNG는 hand-drawn이라 편집 필요성 낮음

### 4순위: SamurAIGPT/Generative-Media-Skills (3,814⭐)
- **한 줄**: 멀티모달 스킬 묶음 (이미지/비디오/오디오). 범용 — Godot 특화 X

### 5순위: SunoMCP / ElevenLabs CLI MCP
- **Last Banner 사용**: 자동 진행 중 분위기 변화 / 분기 음악. Wesnoth ogg 음원이 메인이라 즉시 필요성 낮음

## 3. Game-specific LLMs / Agent Tools

### ⭐ 1순위: Donchitos/Claude-Code-Game-Studios (23,040⭐)
- **한 줄**: Claude Code를 풀 게임 스튜디오로 — 49 AI agents + 72 workflow skills + 스튜디오 계층 미러링
- **Last Banner 사용**: 자동 진행 + 결정 큐 + 자원/시간 시스템 게임 메카닉 코어를 전담 agent가 만들고, 다른 agent가 GDScript 검증 + 자산 매니페스트 + 빌드 검증
- **설치**:
  ```bash
  git clone https://github.com/Donchitos/Claude-Code-Game-Studios.git
  ln -s /path/Claude-Code-Game-Studios/.claude/agents ~/work/<game>/.claude/agents
  ln -s /path/Claude-Code-Game-Studios/.claude/skills ~/work/<game>/.claude/skills
  ```
- **함정**:
  - **49 agents + 72 skills 모두 import하면 Hermes 컨텍스트 폭발** — `~/.claude/CLAUDE.md`에 트리거 키워드 기반 lazy load 설정 필수
  - Mac 전용 함정: 일부 agent가 Linux 전용 경로 가정 (`/usr/bin/...`) → macOS 가드 필요

### 2순위: jame581/GodotPrompter (424⭐)
- **한 줄**: Godot 4 전용 agent skills framework. 씬/GDScript/UI/물리 도메인별 skills
- **함정**: 4.7+ 일부 신규 API는 수동 patch 필요

### 3순위: gamedev-skills/awesome-gamedev-agent-skills (281⭐)
- **한 줄**: 66개 게임 개발 skills + master router

### 4순위: striderZA/OpenCodeGameStudios (57⭐)
- **한 줄**: Claude-Code-Game-Studios의 OpenCode 포팅. Hermes `opencode` 스킬과 결합 시 무료 모델로 동작

### Last Banner 권장 조합
- **풀 게임 스튜디오 전체 import는 과함** (Last Banner는 Web export + Vercel 자동 배포 + Wesnoth CC-BY 자산)
- **추천 subset**:
  - `hi-godot/godot-ai` (MCP) — 씬/스크립트 직접 조작
  - `godot-game-bootstrap` (기존 스킬) — 자산/빌드/배포 워크플로
  - Claude-Code-Game-Studios의 **2~3개 핵심 agent만** import (예: `level-designer`, `qa-tester`, `narrative-writer`)

## 4. CLI 검증 / 디버깅 툴

### ⭐ 1순위: chickensoft-games/setup-godot (176⭐, MIT)
- **한 줄**: macOS/Windows/Linux CI 러너용 Godot 헤드리스 셋업 액션. GitHub Actions에서 export 템플릿 자동 설치 + 헤드리스 부팅 검증.
- **설치**:
  ```yaml
  - uses: chickensoft-games/setup-godot@v4
    with:
      version: 4.7.1
      include-templates: true
      cache: true
  ```
- **함정**: Godot 4.7.1 export 템플릿은 `templates.tpz` URL 정확히. macOS export는 ETC2 ASTC 압축 필수

### 2순위: godot-cli (npm v0.17.1, Apache-2.0)
- **한 줄**: IvanMurzak의 공식 Godot CLI + MCP 헬퍼. AI agent 자동 설정 + 헬스 체크
- **설치**: `npm install -g godot-cli` → `godot-cli --health`

### 3순위: bitwes/Gut (2,639⭐, MIT)
- **한 줄**: Godot 가장 인기 있는 단위 테스트 프레임워크. GDScript + C# + 헤드리스 CLI 러너.
- **설치**:
  ```bash
  # 1) https://github.com/bitwes/Gut/releases ZIP 다운로드
  # 2) addons/gut/에 풀기
  # 3) Project Settings > Plugins > Gut 활성화
  godot --headless -s addons/gut/gut_cmdln.gd -gdir=res://test -gexit
  ```
- **Last Banner 사용**: EventEngine 5개 시나리오 + SaveManager round-trip + DecisionQueue 우선순위 + GameWorld 자원 변동 모두 단위 테스트로 검증
- **함정**: Last Banner autoload는 `process_mode = Node.PROCESS_MODE_ALWAYS` — Gut 테스트는 main scene 거치지 않으면 autoload 0개

### 4순위: godot-gdunit-labs/gdUnit4 (1,147⭐)
- **한 줄**: GUT의 C# 대안. Last Banner는 GDScript라 GUT 추천

### 5순위: AndreaCatania/godot_tracy (128⭐, MIT)
- **한 줄**: Tracy Profiler C++/GDScript 통합. 프레임 단위 성능 + 메모리 + GPU 시간 시각화
- **함정**: C++ 빌드 도구 필요 (scons). 헤드리스에서 native binary 빌드 복잡

### 6순위: youichi-uda/godot-qa (2⭐, 신규)
- **한 줄**: 헤드리스 CI 테스트 러너 + 입력 리플레이 + 노드/텍스트 assert + 스크린샷 diff
- **함정**: 신규 프로젝트 — 안정성 검증 부족

## 5. Hermes-specific 인사이트 (Last Banner 실전)

### 🎯 Insight #1: hi-godot/godot-ai가 Hermes를 공식 지원
- README에서 **Hermes Agent**를 명시적 지원 클라이언트로 나열
- dock "Clients" 탭 → "Hermes Agent" Configure 한 번이면 자동 등록
- Server URL `http://127.0.0.1:8000/mcp` 고정 → Hermes의 `mcp.servers`에 바로 추가 가능

### 🎯 Insight #2: Godot MCP의 autoload cross-reference 함정이 결정적
- Last Banner의 `autoload-cross-reference-pitfall` 스킬에 이미 명시된 `Identifier "X" not declared in the current scope` 파스 에러
- **Coding-Solo/godot-mcp는 `--check-only`로 false negative** → Last Banner의 7종 autoload 환경에서 디버깅 시간 낭비
- **tugcantopaloglu/godot-mcp (v3.1.0+)는 `_initialize()`에서 SceneTree로 실제 컴파일** → Last Banner 권장
- hi-godot/godot-ai는 Python 검증으로 우회

### 🎯 Insight #3: Godot Web export의 MCP 검증 한계
- `godot --headless`는 **PWA Service Worker / SharedArrayBuffer / WebGL2 환경 검증 불가**
- Last Banner의 "검은 화면 + Godot 로고" 함정은 MCP 도구로 자동 진단 어려움
- **대안 패턴**: `templates/inject-debug-pane.sh.tpl`로 사용자 브라우저에서 `Engine.getMissingFeatures()` + crossOriginIsolated 자동 출력
- MCP 도구는 **빌드 후 배포 + 진단 pane 결과 회신 후** 원격 분석에 진가

### 🎯 Insight #4: 100 툴 cap 함정
- Cursor/Cline/Windsurf 일부 MCP 클라이언트는 100 툴 cap
- `tugcantopaloglu/godot-mcp` (157 툴) + `comfyui-mcp` (108 툴) 동시 사용 시 cap 초과
- **해결**: hi-godot/godot-ai의 `<domain>_manage` rollup 패턴 — 43 툴로 120+ ops 노출

### 🎯 Insight #5: GDScript `:=" 추론 함정 + MCP의 시그널 핸들러 자동 검증
- Last Banner의 `autoload-signal-race-condition.md`에 명시 — 시그널 인자 미스매치 (`mercenary_left(m, reason)` 2개 + `_on_mercenary_changed(_m=null)` 1개 시그널 충돌)
- `godot --headless --quit-after 200`로만 잡힘 → MCP의 `validate_script` (tugcantopaloglu) 또는 `validate_gdscript` (hi-godot) 자동 검증 권장

### 🎯 Insight #6: Hermes + godot-ai 조합 패턴
```
[사용자] → Hermes (MCP client)
        ↓ http://127.0.0.1:8000/mcp
[godot-ai Python bridge (uvx mcp-proxy)]
        ↓ WebSocket ws://127.0.0.1:7777
[Godot Editor + godot_ai 플러그인]
        ↓
[Last Banner 프로젝트 (7종 autoload + 씬/스크립트)]
```
- **3-tuple 검증**: godot-ai dock의 "Clients" 탭에서 Hermes row에 status dot이 **green**이어야 정상
- **auto-configure**가 `UV_LINK_MODE=copy` + 정확한 args 자동 작성 → 수동보다 안전

### 🎯 Insight #7: 자주 빠지는 함정 Top 5 (Last Banner 실전)
1. **macOS .app 시각 검증은 헤드리스에서 불가** — Godot이 window 1개 못 만들어 즉시 quit → 사용자 데스크탑 위임
2. **ETC2 ASTC 압축 누락 시 macOS export cascade 실패** — `textures/vram_compression/import_etc2_astc=true` 추가 필수
3. **Web export Service Worker if-else 블록 → `else` 단독 구문 SyntaxError** — `if (false) { /* SW DISABLED */ } else { ... }` 패턴
4. **PWA `progressive_web_app/enabled=false`여도 SW 파일 + 등록 코드는 생성됨** — 후처리 필수
5. **CDN 자산 placeholder (HTTP 200 + 73 bytes)** — lazy fetch 시 `body.size() < 1024` 가드 필수

### 🎯 Insight #8: Last Banner 실전 추천 조합 (2026-07)
- **필수**:
  - `godot --headless --quit-after 200` (모든 autoload parse 에러 검증) — 1분
  - `godot --headless --import` (자산 임포트 검증) — 1~2분
  - `LB_VERIFY=1 godot --headless` (24h 시뮬 + 결정 큐 + save round-trip) — 5초
  - `bitwes/Gut` 결정 큐 우선순위 + GameWorld 자원 단위 테스트 — 30초
- **선택** (Last Banner 규모에서 가성비):
  - `hi-godot/godot-ai` MCP — 씬/스크립트 자율 조작 필요할 때
  - `pinkpixel/mcpollinations` — NPC 일러스트 / 임시 풍경도
  - `chickensoft-games/setup-godot` GitHub Action — 멀티 플랫폼 CI
  - `andrea-catania/godot_tracy` — 성능 트러블슈팅 시만
- **불필요** (Last Banner에 과한 도구):
  - ComfyUI MCP (GPU + 시간)
  - `Glade-tool/glade-mcp` (헤드리스 미지원 + C# 미지원)
  - 풀 Claude-Code-Game-Studios 49 agents (컨텍스트 폭발)

### 🎯 Insight #9: Pollinations 무료 vs 자체 FLUX 판단 기준
- **무료 Pollinations OK**: 1회성 NPC 일러스트 / 임시 풍경 / 분위기 음악 (지속성 무관)
- **자체 FLUX/SDXL 권장**: 게임 출시 자산 / 일관된 캐릭터 시트 / 대량 생성 (>50개)
- Last Banner는 **Wesnoth CC-BY 자산이 메인**이라 Pollinations는 **신규 NPC 추가 시에만** 필요

### 🎯 Insight #10: MCP와 Hermes의 협업 패턴
- **MCP는 도구 노출**, **Hermes는 워크플로 자동화**
- godot-ai의 43 툴을 Hermes가 호출 → 결정 큐 모달 검증 → Vercel 배포 → 사용자 회신 → 진단 pane 분석
- **Godot-MCP 단독으로는 부족** — Hermes의 `godot-game-bootstrap` 스킬이 함정/패턴/자동화를 제공 → 둘이 결합 시 진가

## 📋 Last Banner 즉시 적용 로드맵 (우선순위)

| 단계 | 도구 | 기대 효과 | 예상 시간 |
|---|---|---|---|
| 1 | `bitwes/Gut` addons 추가 + `LB_VERIFY` 자동화 | 결정 큐 우선순위 + 자원 변동 단위 테스트 | 30분 |
| 2 | `hi-godot/godot-ai` 플러그인 + Hermes 자동 등록 | LLM 자율 씬/스크립트 조작 가능 | 1시간 |
| 3 | `@pinkpixel/mcpollinations` (이미 Hermes 사용 가능) | 신규 NPC 일러스트 즉시 생성 | 15분 |
| 4 | `chickensoft-games/setup-godot` GitHub Action | macOS + Web 동시 CI | 1시간 |
| 5 | `godot-cli` (IvanMurzak) 헬스 체크 자동화 | MCP 서버 응답 모니터링 | 30분 |
| 6 | `andrea-catania/godot_tracy` | 성능 트러블슈팅 (필요 시) | 2시간 |

**총 ~5.5시간**으로 Last Banner의 도구 인프라를 2026년 검증된 표준으로 업그레이드 가능.

## 재검증 트리거

이 스냅샷을 다시 조사해야 하는 시점:
- **6개월 경과** (2027-01-16)
- **Godot 4.8 stable 릴리즈** 시 (autoload 검증 API 변경 가능)
- **Last Banner 8종 autoload → 다른 게임 프로젝트로 이전 시** (Last Banner 전용 함정 재평가)
- **MCP 100 툴 cap 정책 변경** (Claude/Cursor 등 클라이언트 업데이트 시)
