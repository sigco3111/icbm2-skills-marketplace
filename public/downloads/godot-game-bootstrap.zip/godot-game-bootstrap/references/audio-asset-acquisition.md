# Audio Asset Acquisition — CC0/SFX 폴백 전략 (2026-07-20 last-banner 실전)

> Wesnoth 풀에 music만 있고 SFX가 없을 때, sparklinlabs superpowers-asset-packs의 RPG pack에서 6곡을 빌려오면 Wesnoth music + CC0 SFX 조합으로 인디 게임 오디오를 완성할 수 있다. 라이선스 표기는 CREDITS.md에 한 줄.

## 의도

Last Banner 같은 incremental 로그라이크가 사운드 자산을 필요로 할 때, Wesnoth 풀의 music은 풍부하지만 sounds/ 디렉터리가 비어있는 경우가 있다 (sources/wesnoth에서 sfx를 별도 추출하지 않은 경우). **무료 CC0 팩에서 SFX를 빌려오면 라이선스 표기 한 줄 + 디스크 사용량 +10MB로 6개 효과음을 확보**.

## 풀 경로 (2026-07 검증)

| 출처 | 경로 | 라이선스 | 수 |
|---|---|---|---|
| Wesnoth music | `~/work/game-assets-pool/extracted/wesnoth/music/core/music/*.ogg` | CC-BY-4.0 | 53곡 |
| sparklinlabs RPG SFX | `~/work/game-assets-pool/free/2D/CC0/sparklinlabs_superpowers-asset-packs/superpowers-asset-packs-master/rpg-battle-system/sound/*.ogg` | CC0 | 40+곡 |

Wesnoth 풀의 sfx는 별도 추출 스크립트가 없으면 비어있음. 2026-07 현재 game-assets-pool에 sfx는 Veloren/warzone 등 다른 게임 소스에 흩어져 있지만 인디 게임용 RPG SFX로는 sparklinlabs가 가장 정돈됨.

## 자산 선택 (4종 BGM + 6종 SFX)

**BGM 4곡 — Wesnoth에서 분위기별 1곡씩**:
| 트랙 | 출처 | 분위기 |
|---|---|---|
| `menu.ogg` | elf-land.ogg | 잔잔/명상 (메뉴/타이틀) |
| `game.ogg` | knolls.ogg | 따뜻한 중후 (게임 중) |
| `battle.ogg` | battle-epic.ogg | 긴장/격정 (전투) |
| `modal.ogg` | sad.ogg | 침착/중후 (결정 모달) |

**SFX 6곡 — sparklinlabs RPG pack에서 번호순 매핑**:
| 트랙 | 출처 번호 | 용도 |
|---|---|---|
| `modal_open.ogg` | 10 | 모달 열림 (작은 차임) |
| `modal_close.ogg` | 11 | 모달 닫힘 |
| `choice_confirm.ogg` | 12 | 결정 확정 |
| `dice_roll.ogg` | 13 | 주사위 굴림 (전투) |
| `battle_start.ogg` | 14 | 전투 시작 |
| `victory.ogg` | 15 | 승리 |

## 복사 명령어 (Wesnoth 심볼릭 링크 + sparklinlabs 직접 파일)

```bash
# BGM — Wesnoth 심볼릭 링크는 .yaml 파일 동반, 직접 복사
DST=/Users/mac/work/last-banner/assets/audio/music
SRC=~/work/game-assets-pool/extracted/wesnoth/music/core/music
cp "$SRC/elf-land.ogg"   "$DST/menu.ogg"
cp "$SRC/knolls.ogg"     "$DST/game.ogg"
cp "$SRC/battle-epic.ogg" "$DST/battle.ogg"
cp "$SRC/sad.ogg"        "$DST/modal.ogg"

# SFX — sparklinlabs는 진짜 파일
DST=/Users/mac/work/last-banner/assets/audio/sfx
SRC=~/work/game-assets-pool/free/2D/CC0/sparklinlabs_superpowers-asset-packs/superpowers-asset-packs-master/rpg-battle-system/sound
cp "$SRC/10.ogg" "$DST/modal_open.ogg"
cp "$SRC/11.ogg" "$DST/modal_close.ogg"
cp "$SRC/12.ogg" "$DST/choice_confirm.ogg"
cp "$SRC/13.ogg" "$DST/dice_roll.ogg"
cp "$SRC/14.ogg" "$DST/battle_start.ogg"
cp "$SRC/15.ogg" "$DST/victory.ogg"
```

**결과**: 9.8 MB (BGM 9.7 MB + SFX 70 KB). pck 사이즈에 영향 거의 없음.

## 라이선스 표기 (CREDITS.md)

```markdown
## 오디오 자산

- **BGM (4곡)** — Battle for Wesnoth (CC-BY-4.0)
  - "elf-land.ogg" / "knolls.ogg" / "battle-epic.ogg" / "sad.ogg"
  - © 2003-2026 The Battle for Wesnoth contributors
  - https://www.wesnoth.org/
- **SFX (6곡)** — sparklinlabs Superpowers Asset Packs (CC0)
  - RPG Battle System Sound Pack (10~15.ogg)
  - https://itch.io/profile/sparklinlabs
```

**CC0 = 표기 의무 없음**이지만 출처는 한 줄 추가. CC-BY-4.0 = 저작자 + 라이선스 + URL 필수.

## 헤드리스 가드 패턴 (autoload/audio_manager.gd)

```gdscript
func _is_running_with_display() -> bool:
    return DisplayServer.get_name() != "headless"
```

**CI/검증 환경** (`godot --headless`): `DisplayServer.get_name()` → `"headless"` → 오디오 자동 비활성화. **CDN 자산 부재** 시에도 자동 비활성화 (다중 가드).

**macOS .app**: `DisplayServer.get_name()` → `"macos"` → 오디오 정상. **Web export**: `"web"` → Web Audio API로 정상.

## Godot import

```bash
cd /Users/mac/work/last-banner
godot --headless --import    # .ogg 자동 인식 + .import 파일 생성
```

`.gdignore` 생성하지 말 것 — 폰트/사운드는 빌드 포함 필수 (폰트와 동일 정책). setup-assets.sh는 `audio/` 폴더를 건드리지 않음.

## 안티패턴

1. **Wesnoth 풀에서 sfx 추출 시도** — 디렉터리가 비어있음. 별도 추출 스크립트 필요 (2026-07 시점 미존재)
2. **Otto/soundbible 같은 상용 SFX 사이트** — 라이선스 문제, 인디 게임은 CC0 우선
3. **Wesnoth music을 BGM으로 5곡 이상 사용** — 디스크 사용량 폭증. 분위기별 1곡씩이 인디 게임 적정
4. **랜덤 BGM 순환** — incremental 게임은 BGM이 일관되게 유지되어야 함. 모드별 1곡 고정

## 적용 게임

- 인디 incremental 로그라이크 (Last Banner)
- 시뮬레이션 게임 (Anno 류) — BGM 4곡으로 메뉴/게임/전투/모달 구분
- RPG (전투 시작/승리/패배 SFX 필요)
- 시뮬레이션 (결정 확정 SFX로 피드백)

## 진화 의도

v0: 사운드 없음 → 조용한 게임
v1 (2026-07-20): BGM 4곡 + SFX 6곡 = 분위기 + 결정 피드백 + 전투 박자감. 9.8 MB.
