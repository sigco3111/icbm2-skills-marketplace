# Lazy Fetch via CDN — Vercel 100MB 한계 우회 패턴

`assets/*/.gdignore` + jsDelivr 런타임 fetch + `user://persistent/assets/` 캐시. Godot 4 Web export의 `index.pck`를 ~수백 KB로 줄여서 Vercel 무료(파일당 100MB) 안에서 200~500MB 자산 호스팅.

## 왜 필요한가

| 문제 | 값 |
|---|---|
| `index.pck` (lazy fetch 미채택) | 207~500MB |
| Vercel 무료 단일 파일 한계 | **100MB** |
| 결과 | `Error: File size limit exceeded (100 MB)` |
| Pro 플랜 | $20/월 (Vercel) 또는 Cloudflare 0원 |

lazy fetch 채택 시 pck은 ~수백 KB. 자산은 CDN에서 런타임 fetch.

## 핵심 메커니즘

```
[빌드 시점]
Godot export → res://assets/* 제외 (.gdignore 덕분)
         ↘
        pck ~500KB (스크립트/씬만)
         ↘
       Vercel outputDirectory로 직접 푸시 (단일 파일 < 1MB OK)

[런타임]
사용자가 [자산 가져오기] 클릭
        ↓
asset_host.json 로드 (base_url=jsDelivr)
        ↓
HTTPRequest로 자산 fetch
        ↓
user://persistent/assets/<category>/<file> 디스크 캐시 (Web: IndexedDB)
        ↓
다음 진입부터는 디스크 캐시 즉시 사용
```

### 왜 jsDelivr인가

- GitHub repo의 특정 브랜치/태그를 CDN으로 자동 변환
- `https://cdn.jsdelivr.net/gh/<user>/<repo>@<ref>/<path>` 패턴
- 무료, 무제한, README/license 자동 노출 안 됨 (CDN만)
- Last Banner 실전 검증 (228MB 자산 안정 서빙)

대안:
- GitHub Releases (zip으로 묶어야 함, 파일별 URL)
- GitHub raw.githubusercontent.com (헤더 없음, 느림)
- Cloudflare R2 (무료 10GB, wrangler 설정 필요)
- jsDelivr + GitHub = 가장 단순

## 구현 4단계

### 1단계: `.gdignore`로 자산 import 차단 (git 추적 유지)

```bash
# 각 자산 폴더에 빈 파일 생성
for d in ~/work/<game>/assets/*/; do touch "$d/.gdignore"; done
```

**`ls -la`로 확인**:
```
assets/heroes/.gdignore   # 0 bytes 빈 파일
assets/heroes/Knight.glb  # ← 심볼릭 링크 (실제 파일 추적됨)
```

핵심: `.gdignore`는 **Godot import 단계에서만** 무시. `git add`는 정상 추적 → `git push` → CDN이 받음.

`.gitignore`에서 `build/*` + `!build/web/` 예외 추가:
```gitignore
build/*
!build/web/
!build/web/**
```

→ Vercel이 build/web/을 outputDirectory로 직접 사용. 빌드 명령 불필요.

### 2단계: `asset_host.json` 자동 생성

```bash
bash tools/gen-asset-manifest.sh https://cdn.jsdelivr.net/gh/<user>/<repo>@main/assets
```

생성 결과 (실제 Last Banner 사례):
```json
{
  "version": 1,
  "base_url": "https://cdn.jsdelivr.net/gh/sigco3111/last-banner@main/assets",
  "total_size_bytes": 239463132,
  "category_count": 6,
  "categories": {
    "audio": {
      "file_count": 632,
      "size_bytes": 187309337,
      "base_url": "https://cdn.jsdelivr.net/gh/sigco3111/last-banner@main/assets",
      "files": ["audio/music/battle-epic.ogg", ...],
      "sizes": {"audio/music/battle-epic.ogg": 4123456, ...}
    },
    "heroes": { ... }
  }
}
```

**`build.sh`가 자동으로 `asset_host.json`을 `build/web/`로 복사**해야 함 (Vercel outputDirectory와 일치):
```bash
echo "→ Web export..."
mkdir -p "$BUILD_DIR/web"
godot --headless --export-release "Web" "$BUILD_DIR/web/index.html" 2>&1 | tail -10
# asset_host.json 복사
if [ -f "$LB_ROOT/asset_host.json" ]; then
    cp "$LB_ROOT/asset_host.json" "$BUILD_DIR/web/asset_host.json"
fi
```

### 3단계: AssetRegistry lazy fetch

핵심 골격 (`autoload/asset_registry.gd`):

```gdscript
extends Node

const MANIFEST_LOCAL_PATH := "res://asset_host.json"

var _manifest: Dictionary = {}
var _fetched: Dictionary = {}     # {relative_path: local_path}
var _in_progress: Dictionary = {} # 중복 fetch 방지
var _loaded_bytes: int = 0
var _manifest_ready: bool = false

signal manifest_loaded
signal asset_fetched(rel_path: String, local_path: String)
signal all_assets_ready

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    _load_manifest()

func _load_manifest() -> void:
    if not FileAccess.file_exists(MANIFEST_LOCAL_PATH):
        push_warning("[AssetRegistry] %s 없음 — fetch 비활성" % MANIFEST_LOCAL_PATH)
        return
    var f := FileAccess.open(MANIFEST_LOCAL_PATH, FileAccess.READ)
    if f == null:
        return
    var json := JSON.new()
    if json.parse(f.get_as_text()) != OK:
        f.close()
        return
    f.close()
    _manifest = json.data
    _manifest_ready = true
    manifest_loaded.emit()

func get_total_size() -> int:
    var total := 0
    var cats: Dictionary = _manifest.get("categories", {})
    for cat_name in cats:
        var cat: Dictionary = cats[cat_name]
        total += int(cat.get("size_bytes", 0))
    return total

## 모든 자산 fetch + 진행률 콜백
func fetch_all(progress_cb: Callable = Callable()) -> void:
    var total := get_total_size()
    _loaded_bytes = 0
    var cats: Dictionary = _manifest.get("categories", {})
    for cat_name in cats:
        var cat: Dictionary = cats[cat_name]
        var files: Array = cat.get("files", [])
        var base_url: String = cat.get("base_url", _manifest.get("base_url", ""))
        for rel_path in files:
            _download_single(base_url, rel_path, progress_cb, total)

func _download_single(base_url: String, rel_path: String, progress_cb: Callable, total: int) -> void:
    if _fetched.has(rel_path) or _in_progress.has(rel_path):
        return
    var url := "%s/%s" % [base_url, rel_path]
    var local_path := "user://persistent/assets/%s" % rel_path
    # 디스크 캐시 hit
    if FileAccess.file_exists(local_path):
        _fetched[rel_path] = local_path
        _loaded_bytes += FileAccess.get_file_as_bytes(local_path).size()
        asset_fetched.emit(rel_path, local_path)
        if progress_cb.is_valid(): progress_cb.call(_loaded_bytes, total)
        return
    # HTTP fetch
    _in_progress[rel_path] = true
    var req := HTTPRequest.new()
    add_child(req)
    req.request_completed.connect(_on_request_done.bind(req, local_path, rel_path, progress_cb, total))
    req.request(url)

func _on_request_done(result: int, response_code: int, _h: PackedStringArray,
                     body: PackedByteArray, req: HTTPRequest, local_path: String,
                     rel_path: String, progress_cb: Callable, total: int) -> void:
    req.queue_free()
    _in_progress.erase(rel_path)
    if result != HTTPRequest.RESULT_SUCCESS or response_code != 200:
        push_warning("fetch 실패: %s" % rel_path)
        return
    DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(local_path.get_base_dir()))
    var f := FileAccess.open(local_path, FileAccess.WRITE)
    if f == null: return
    f.store_buffer(body)
    f.close()
    _fetched[rel_path] = local_path
    _loaded_bytes += body.size()
    asset_fetched.emit(rel_path, local_path)
    if progress_cb.is_valid(): progress_cb.call(_loaded_bytes, total)
    if _loaded_bytes >= total and _in_progress.is_empty():
        all_assets_ready.emit()
```

### 4단계: main.tscn에 진행률 버튼

```gdscript
# scripts/main.gd 발췌
@onready var fetch_button: Button = $UI/FetchButton

func _ready() -> void:
    AssetRegistry.manifest_loaded.connect(_on_manifest_loaded)

func _on_manifest_loaded() -> void:
    var total_mb: float = AssetRegistry.get_total_size() / 1024.0 / 1024.0
    status_label.text = "Last Banner\n자산 매니페스트 OK — %.1f MB\n[자산 가져오기] 클릭 시 다운로드" % total_mb
    fetch_button.disabled = false

func _on_fetch_pressed() -> void:
    fetch_button.disabled = true
    AssetRegistry.fetch_all(_on_fetch_progress)

func _on_fetch_progress(loaded: int, total: int) -> void:
    var pct: float = 100.0 * float(loaded) / float(max(total, 1))
    status_label.text = "자산 다운로드: %.1f / %.1f MB (%.0f%%)" % [
        loaded / 1024.0 / 1024.0, total / 1024.0 / 1024.0, pct
    ]
```

## 검증 절차 (Last Banner 실전)

```bash
# 1. .gdignore 적용
for d in assets/*/; do touch "$d/.gdignore"; done

# 2. 매니페스트 생성
bash tools/gen-asset-manifest.sh "https://cdn.jsdelivr.net/gh/sigco3111/last-banner@main/assets"

# 3. 헤드리스 부팅 검증 (parse 에러 잡기)
godot --headless --quit-after 200 2>&1 | grep -E "AssetRegistry|GameManager"

# 4. 빌드 — pck이 ~500KB로 줄어드는지
rm -rf build/web .godot/imported .godot/exported
godot --headless --import
godot --headless --export-release "Web" "$PWD/build/web/index.html"
ls -lh build/web/index.pck   # ~500KB ✓

# 5. Vercel deploy (build/web/을 git에 직접 커밋 후)
cd ~/work/last-banner
git add -A
git commit -m "build/web/ git 추적 + lazy fetch"
git push origin main

export VERCEL_TOKEN=$(cat ~/.hermes/secrets/vercel_token.txt | tr -d '\n')
vercel --yes --prod --archive=tgz

# 6. 라이브 URL에서 검증
curl -sI https://<alias>.vercel.app/asset_host.json | grep -E "HTTP|content-type"
curl -s https://<alias>.vercel.app/asset_host.json | python3 -c "import json,sys; print(json.load(sys.stdin)['total_size_bytes'])"
```

## 캐시 무효화

CDN URL이 같으면 캐시가 stale 됨 → 새 자산 추가 시 base_url에 버전 bump:

```bash
# 예: assets-v1 → assets-v2
bash tools/gen-asset-manifest.sh "https://cdn.jsdelivr.net/gh/<user>/<repo>@assets-v2/assets"
git add asset_host.json && git commit -m "assets-v2 bump" && git push
```

브랜치/태그로 bump 하면 jsDelivr가 새 URL 제공 → 기존 사용자도 새 매니페스트 받으면 새 자산을 fetch.

## 함정 / 디버깅

| 증상 | 원인 | Fix |
|---|---|---|
| pck이 여전히 200MB | `.gdignore` 누락 또는 폴더 구조 잘못 | `find . -name .gdignore`로 확인, `rm -rf .godot/imported` 후 재import |
| fetch 404 에러 | base_url 경로 오타, `cdn.jsdelivr.net` 캐시 지연 (1~5분) | URL 직접 `curl -I`로 검증, jsDelivr purge API 또는 5분 대기 |
| fetch CORS 에러 | CDN이 CORS 헤더 미지원 | jsDelivr/GitHub Releases는 CORS 자동 허용, R2/S3는 수동 설정 |
| `user://persistent/assets/` 에러 | 디렉터리 미생성 | `DirAccess.make_dir_recursive_absolute` 호출 |
| 자산 캐싱 너무 오래됨 | base_url stale | 태그 bump |
| WebP/MKV 비디오 lazy fetch는 미검증 | 텍스처/오디오 외 | WebGL/Vorbis만 검증됨. 다른 형식은 추가 테스트 필요 |
| `progress_cb.call()` 직렬화 에러 | Callable capture 문제 | 명시적 `.bind()` 사용 또는 `_on_request_done`에 콜백 파라미터로 전달 |

## 보안 / 라이선스 주의

- **CC-BY 자산의 경우 출처 표기 자동화 권장** (`docs/CREDITS.md` 재사용)
- jsDelivr는 GitHub repo 변경 즉시 반영 (1~5분 지연) — 라이선스 파일은 CDN으로 노출 안 해도 됨
- 악의적 PR이 합쳐지면 jsDelivr가 그대로 CDN → **GitHub branch protection rules** 필수

## 관련

- `references/cloudflare-pages-vs-vercel.md` — 호스팅 비교
- `references/godot4-web-export-pitfalls.md` — 8가지 Web export 함정
- `templates/gen-asset-manifest.sh.tpl` — 매니페스트 생성 스크립트
- `templates/asset_host.schema.json.tpl` — 매니페스트 스키마
- `templates/autoload-asset-registry-lazy.gd.tpl` — 전체 lazy fetch 골격
