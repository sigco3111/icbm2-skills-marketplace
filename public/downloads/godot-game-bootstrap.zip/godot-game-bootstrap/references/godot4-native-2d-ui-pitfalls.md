# Godot 4 Native 2D UI Pitfalls (Last Banner v2.3+, 2026-07-16)

v2.3.0~v3.1.4에서 검증한 **macOS 네이티브 2D 게임 UI 함정 모음**. 이 스킬의 다른 레퍼런스(`manor-dashboard-screen-pattern.md`, `character-click-interaction-area2d.md` 등)에 흩어져 있던 것을 v2.3~v3.1 실무 사례와 묶어서 추가 보강.

## 1. `replace_all=true` tscn patch 폭파 사고 (2026-07-16 발견)

**증상**: `patch(mode='patch-replace_all=true')`로 여러 위치에 같은 노드 정의가 있을 때, 처음 한 위치만 매치하려고 했는데 `old_string`가 다른 위치에서도 발견되어 **9개 sibling 노드가 의도치 않게 삭제됨**. ManorTitle, DetailPanel, VisitorCard, QuickStatsCard, BottomRowInColumn, RosterTitle, RosterScroll, RosterVBox 등 한꺼번에 사라짐.

**원인**: `replace_all`은 `old_string` 매치를 **파일 내 모든 위치**에서 수행. tscn은 같은 노드 정의라도 부모 경로가 다르면 살려둬야 함. 그래서 `old_string`에 부모 정보 없이 노드 정의 일부만 넣으면 다른 위치의 같은 정의까지 잡힘.

**해결 패턴 — `write_file`로 깨끗하게 재작성**:

```
# 절대 금지
patch(replace_all=true) with old_string = "[node name=\"X\"]\n..."

# 노드 손실 후: .tscn 파일 전체를 다시 write_file로 작성
# 헤더 구조 (load_steps, ext_resource, root) + 모든 노드 정의 그대로 재현
```

**검증 패턴 — 패치 후 즉시 노드 카운트 비교**:
```
# tscn 패치 후 또는 재빌드 후
godot --headless --quit-after 5 2>&1 | grep -i "error\|parse" | head -10
# 또는 노드 수 직접 확인
grep -c "^\\[node name=" scenes/main.tscn   # 이전 12 → 이번 7 (5개 사라짐)
```

**Best practice (2026-07-16 정립)**:
- tscn 패치 시 한 번에 하나씩 변경 — `replace_all=false` 기본값 유지
- 노드 추가/이동/삭제 시 항상 **3단계 검증**: ① 패치 ② 헤드리스 import ③ LB_VERIFY
- 3개 이상 노드 변경 필요 시 → tscn 영역의 `write_file`이 패치보다 빠르고 안전

## 2. PanelContainer `mouse_filter`와 내부 호버 인터랙션 공존

**증상**: `PanelContainer`를 상세 정보 영역으로 사용하는데 `mouse_filter = 0 (STOP)`으로 두면 외부 클릭이 패널에 막힘. 호버 인터랙션은 TextureButton이 자체적으로 받지만 사용자가 호버 영역을 벗어나면서 일관성 깨질 가능성.

**해결**: 패널 안 자식이 클릭 받으면 `mouse_filter = 2 (IGNORE)`.

```tscn
[node name="DetailPanel" type="PanelContainer" parent="..."]
mouse_filter = 0   ← STOP (전체가 클릭 막음) — 모달처럼 사용 시 OK
; 또는
mouse_filter = 2   ← IGNORE (관통) — 내부 자식이 클릭 처리 시 필요
```

**판단 기준**:
| 용도 | mouse_filter 값 |
|---|---|
| 결정 모달 (DimBG + Panel) | `0` (STOP) — 사용자가 모달 외부 클릭 안 함 |
| DetailPanel (호버 시만 표시, 내부 콘텐츠는 Label) | `0` (STOP) — 콘텐츠 자체가 클릭 안 받음 |
| 풍경도 배경 (배경 클릭 = 패닝) | `0` (STOP) |
| 호스트 컨테이너 (자식이 클릭 받아야 함) | `2` (IGNORE) |
| 캐릭터 표시 Area2D/TextureButton 부모 | `2` (IGNORE) |

**확인**: LB_VERIFY [12.5] 차트 검증 시 `chart_canvas.queue_redraw()` 호출 후에도 차트 클릭이 매너지 클릭을 막는지 — LB_VERIFY에서는 헤드리스라 의미 없음. 사용자 .app에서 마우스 hover 시 차트가 사라지면 문제.

## 3. HBox 안 PanelContainer ↔ 자식 노드 — 라벨/캔버스 완전 분리

**증상**: `ManorTitle`(PanelContainer) 안에 HBox를 두고 [Label, ChartPanelContainer]를 수평 배치. ChartCard 안에 `ChartTitle`(Label) + `ChartCanvas`(Control)를 둘 때 — ChartTitle이 ChartCard 안 **전체 영역** 사용 (anchor 없이 부모 따라가기)하면 ChartCanvas와 영역 겹침.

**해결 패턴**:
```tscn
[node name="ChartCard" type="PanelContainer"]
custom_minimum_size = Vector2(220, 100)   ; 차트 영역 정함

[node name="ChartTitle" type="Label" parent="ChartCard"]
anchor_left = 0.0
anchor_right = 1.0
offset_top = 4
offset_bottom = 22          ; **22px 분리 영역 확보** (title만)
text = "📈 자원 추이 (7일)"

[node name="ChartCanvas" type="Control" parent="ChartCard"]
anchor_left = 0.0; anchor_top = 0.0
anchor_right = 1.0; anchor_bottom = 1.0
offset_top = 26               ; **title 아래서만 시작**
offset_left = 6; offset_right = -6
offset_bottom = -6
mouse_filter = 2               ; IGNORE (라벨처럼 클릭 무관)
```

**핵심**: `title 영역 (top 0~22px)` / `line 영역 (top 26~끝)` 완전 분리. 캔버스 내부 padding.y=14 추가 → 라인 시작 위치 = 차트 카드 위 26+14=40px (title 영역과 안 겹침).

**최적의 폰트 + 색 표준**:
```gdscript
# PNG/WESNOTH 색 강조
const COLOR_GOLD := Color(0.95, 0.78, 0.2)
const COLOR_FOOD := Color(0.6, 0.85, 0.4)
const COLOR_GRID := Color(0.3, 0.3, 0.3, 0.5)

# draw_string에 한글 폰트 명시
var default_font: Font = ThemeDB.fallback_font
chart_canvas.draw_string(default_font, ...)
```

## 4. 풍경도 ⇄ DetailPanel ⇄ ChartPanel — 3패널 분할 배치 패턴

**증상**: 풍경도 한 화면 안에 차트 + DetailPanel + 캐릭터 sprite까지 모두 들어가야 하는데 각자 같은 줄이나 영역에 떠서 가림.

**해결 패턴 — 풍경도 내부 좌우 분할**:
```
┌────────────────────────────────────────────────────────────────┐
│ [🏰 휘장 텍스트]  │  [📈 자원 추이 (7일)]   ← HBox 가로 배치  │
├────────────────────────────────────────────────────────────────┤
│ 풀밭 + 흙길 + 캐릭터 5명                                          │
│                                                  (호버 시 우상단   │
│                                                  DetailPanel)     │
├────────────────────────────────────────────────────────────────┤
│ [📜 방문객]  │  [📊 일간 변동]                                │
└────────────────────────────────────────────────────────────────┘
```

**구현 — VBox > Item 트리**:
```tscn
[node name="LeftColumn" type="VBoxContainer"]
custom_minimum_size = Vector2(760, 0)
theme_override_constants/separation = 12

[node name="ManorTitle" type="PanelContainer"]                    ; VBox item 1
custom_minimum_size = Vector2(0, 100)
[node name="TitleHBox" type="HBoxContainer" parent="ManorTitle"]
  [TitleLabel] [ChartCard → ChartTitle + ChartCanvas]            ; HBox 자식

[node name="ManorScene" type="PanelContainer"]                     ; VBox item 2
size_flags_vertical = 3
[node name="SceneHost" type="Control" parent="ManorScene"]
anchor_right = 1.0; anchor_bottom = 1.0; mouse_filter = 2
  [SceneRoot: Node2D + Sprite2D × N]                          ; 풍경도
  [DetailPanel: 호버 시 표시]                                  ; 풍경도 내부 우상단

[node name="BottomRowInColumn" type="HBoxContainer"]              ; VBox item 3
custom_minimum_size = Vector2(0, 96)
  [VisitorCard] [QuickStatsCard]                               ; HBox 자식
```

**결정**: 사용자가 "겹치지 않게 해주세요"라고 하면 위 3구역 + HBox가 가장 안정적.

**헤드리스 검증은 구조/상태용이지 시각 증거가 아니다.** `node.visible`, 자식 수, 시그널 연결만으로 실제 레이아웃을 통과시켰다고 간주하지 말 것. 레이아웃 변경마다 실행 가능한 GUI 캡처(로컬 데스크탑 또는 macOS computer-use)로 최소한 다음을 확인한다: 패널끼리 안 겹침, chart/text가 별도 영역, Roster와 형제 column, 핵심 PNG 픽셀이 실제 보임. 사용자가 스크린샷을 제공하면 그 화면이 최종 시각 SSOT다.

**판단 기준**:
- 2개 패널 (차트 + DetailPanel): **풍경도 안에서 좌우 분할** — Best
- 3개 이상: **VBox + HBox 계층 구조** — 트리 깊이 1 단계로 끝남

## 5. 동적 노드 검색 — `get_node_or_null`과 일관성

**증상**: `scenes/main.tscn`에서 `ManorTitle`이 PanelContainer → 그 안 HBox → 자식 ChartCard → ChartCanvas. manor_dashboard.gd에서 `get_node_or_null(".../ManorScene/SceneHost/ChartCard/ChartCanvas")` (옛 위치) 호출 시 null 반환 — 차트가 안 그려짐.

**해결 패턴 — 절대 경로 일관성 유지**:

```gdscript
# 짧은 경로 (ManualScene > SceneHost > ChartCard 안에 있을 때)
chart_canvas = get_node_or_null("CenterRoot/LeftColumn/ManorScene/SceneHost/ChartCard/ChartCanvas")

# HBox 안으로 옮긴 후: full path 변경
chart_canvas = get_node_or_null("CenterRoot/LeftColumn/ManorTitle/TitleHBox/ChartCardInline/ChartCanvas")

# → 항상 첫 줄 (anchor_left=0.0, anchor_right=1.0)에 라인 → 정렬되었는지 grep으로 검증:
# scenes/*.tscn에서 parent="CenterRoot/LeftColumn/ManorTitle/TitleHBox" 검색
# scripts/*.gd에서 get_node_or_null("CenterRoot/LeftColumn/ManorTitle") 검색
```

**자동 검증으로 잡는 법**: LB_VERIFY에 `[12.5.5] 차트 검증` 단계 추가 — chart_canvas 인스턴스 존재 → `assert(not chart_canvas == null, "차트 노드 경로 확인")`.

## 6. GDScript Variant 추론 에러 — `var X := func().field`

**증상**: `var x := GameWorld.get("_pending") if false else 4` 같이 삼항 + Variant → 파스 에러 `The variable type is being inferred from a Variant value, so it will be typed as Variant. (Warning treated as error.)`

**해결**: 인라인 삼항 + Variant는 항상 명시 타입으로:
```gdscript
# Variant 추론 경고 (에러 처리됨)
var x := GameWorld.get("foo") if something else 4

# 명시 타입
var x: int = 4
if something:
    x = GameWorld.get("foo")
```

**GDScript 패턴 (Godot 4.6+ strict)**:
```ini
; project.godot 또는 그 외 .cfg 파일에
[debug]

gdscript/warnings/untyped_declaration=warn
gdscript/warnings/untyped_assignment=error    ; 라이브 코드에서 Variant 추론 차단
gdscript/warnings/integer_division=warn
```

기본값은 strict하지 않지만 Godot 4.7+ 에디터 기본은 strict. 헤드리스 부팅 시 `Parse Error: The variable type is being inferred from a Variant value` → autoload 로드 실패 → 연쇄 ERROR로 hang.

## 7. 다중 패널 height 충돌 — 화면 크기별 검증

**증상**: tscn에서 `custom_minimum_size = Vector2(0, 100)` (ManorTitle이 차트 카드 들어가도록 100px). 다른 패널 (ManorScene)이 `size_flags_vertical=3` (남는 공간 채움). 화면 높이가 변하면 차트 영역이 짤리거나 ManorScene이 너무 작아짐.

**해결 패턴 — 화면 크기 가정 명시**:

```ini
; project.godot
[display]

window/size/viewport_width=1280
window/size/viewport_height=720
window/stretch/mode="canvas_items"   ; 4:3, 16:9 등 비율 유지하면서 확대
window/stretch/aspect="expand"        ; 검은 띠 없이 화면 채움
```

**계산 검증**: 1280×720에서 모든 패널 height 합산 < 720.
- ManorTitle: 100 (custom_minimum)
- ManorScene: 가용 = 720 - 100 - 96 - 상단 96 - 하단 90 - VBox spacing 36 = ~310
- BottomRowInColumn: 96
- ⇒ ManorScene ~310px, 432×460 풍경도에 충분

**확인**: LB_VERIFY 안에서 `print(node.size)` 또는 `print(get_viewport().get_visible_rect().size)` 모니터링 → 1280×720 외 다른 사이즈에서 안 깨지는지 검증.

## 8. Godot 4.7 tscn 패치 시 닫는 태그 깨짐 주의

**증상**: `patch`의 `new_string`에서 실수로 `</ratio>` `</prohibited>` 같은 잘못된 닫는 태그를 포함 → tscn 파일 자체가 깨짐.

**해결 패턴**:
1. 패치 후 **항상** `godot --headless --import 2>&1 | grep -iE "error|parse"` 실행
2. tscn 파일 끝의 `</ratio>` `</prohibited>` 같은 패턴 grep:
   ```bash
   grep -E "</(ratio|prohibited|node)" scenes/main.tscn
   ```
3. 깨진 태그 발견 시 `sed -i '' 's|</ratio>||g' scenes/main.tscn` 또는 `write_file`로 깨끗하게 재작성

**Last Banner에서 발생한 사례**: 
- v2.3.1 patch → `</ratio>` 3번 등장 (첫 자리만 정상 + 2번째/3번째 깨짐)
- v3.1.4 patch → `replace_all=true` 사고 → 9개 노드 손실

**권장**: `replace_all=true` 또는 `replace_all=false` 패치 후 **반드시** `godot --headless --import` 1회 실행 + stderr Error/Parse 확인.

## 9. LB_VERIFY 헤드리스 비동기 hang 3종 (재강조)

다른 레퍼런스에 이미 있지만 가장 빈번하게 함정에 빠지는 부분이라 재강조:

```gdscript
# 위험: 헤드리스에서 빨리 안 끝남
await get_tree().create_timer(4.0).timeout
for i in range(60):
    await get_tree().process_frame

# 안전: 동기 처리
for i in range(144):
    TimeManager.advance_minutes(10)

# 안전: 한 프레임 await만
await get_tree().create_timer(0.1).timeout   # 0.1초는 OK
```

**create_timer 헤드리스 안전 패턴**:
```gdscript
# 테스트 모드 진입한 직후 동기 시간 진행
var min_before: int = TimeManager.minutes_elapsed
TimeManager._process(1.0)   # delta 직접 주입
var advance: int = TimeManager.minutes_elapsed - min_before
assert(advance >= 55 and advance <= 65, "1초 real = 60±5분 game")
```

**진단법**: stderr 마지막 줄 grep. `ERROR: Method expected N argument(s)` (시그널 인자 미스매치) / `Parse Error: Identifier "X"` (autoload cross-ref) / `Parse Error: The variable type is being inferred from a Variant value` (variant 추론) → hang 진단.

## 10. `_on_tick`마다 `queue_redraw` 안전성

**v3.1 라인 차트의 경우 `_refresh_chart`가 `_on_tick`마다 호출**:

```gdscript
func _on_tick(_game_time: int) -> void:
    _update_time_of_day_colors()   # 매 tick마다 색 보간 (60초 = 1일, 색 변화 자연스러움)
    _refresh_chart()               # 자원 변동 시 차트 갱신
```

**주의**: `_on_tick`이 초당 여러 번 호출될 가능성 (Godot의 _process 주기 = vsync 60fps라면 60번/초). `queue_redraw`는 다음 프레임에 redraw 1회만 실행되니 다중 queue 안전. 단 다른 함수에서 `_refresh_chart()` 직접 호출하면 + 매 프레임 draw → 성능 저하.

**핵심**: `queue_redraw()`는 idempotent. 여러 번 호출해도 redraw 1회. 직접 `draw_*()` 메서드 호출 금지.

## 11. v2.x~v3.x에서 작업한 패턴 요약 표

| 기능 | 위치 | 핵심 노드/시그널/메서드 |
|---|---|---|
| 자동 진행 (ON/OFF) | TimeManager.auto_progress_enabled | toggle_auto_progress() |
| 결정 큐 (모달) | main.gd `_show_next_decision` | DecisionQueue.get_all_pending() |
| 결정 큐 ON/OFF 분기 | main.gd `_on_auto_skip` | `if not TimeManager.auto_progress_enabled: return` |
| 전투 화면 | BattleScene (별도 SceneTreeLayer) | CanvasLayer + State enum |
| GameWorld.apply_result (단일 dict) | game_world.gd RESULT_EFFECTS | 전투/모달 양쪽에서 호출 |
| 매너지 풍경도 | manor_dashboard.gd | TextureButton (Control 부모 호환) |
| 호버 인터랙션 | `_on_character_hover/unhover` | mouse_entered/exited + original_position 누적 방지 |
| DetailPanel (호버 시) | tscn anchor + Control canvas 내부 분리 | mouse_filter=0 (STOP) |
| ChartPanel (v3.1) | `Control._draw()` + queue_redraw | GameWorld.history ring buffer |
| 시간대 그라디언트 | `_update_time_of_day_colors` | Color.lerp + tick_advanced |
| 자동 저장 (Save/Load) | SaveManager.save_game/load_game | user:// + IndexedDB |
| 타이틀 화면 | TitleScene -> → Game 또는 Q | '이어하기' 버튼 (SaveManager.list_saves) |
| BGM/효과음 | (미구현 v2.3) | `audio/stream/` + WESNOTH or CC0 ogg |

## 부록 — Best Practices (안티패턴)

1. **`replace_all=true` 금지** — tscn 폭파 위험. 단일 매치만 사용. 다중 변경 필요 시 `write_file` 또는 loop.

2. **모든 신규 scroll/canvas/textbox/range 추가 시 LB_VERIFY 단계 1개씩** — [10], [11], [12] 등 단계 번호 매겨서 main.gd `_run_verify()`에 추가. 시점 다르면 assert 약화.

3. **`process_mode = Node.PROCESS_MODE_ALWAYS` 모든 autoload 잊지 않기** — main scene 정지해도 시계/큐는 계속.

4. **모든 autoload에 `_save_state / _load_state` 메서드** — save_manager.gd의 `_capture_state()`에서 호출.

5. **`@onready` 사용 최소화** — main scene 즉시 부팅되지 않는 환경 (LB_VERIFY 헤드리스)에서 null 가드 필요. 동적 `get_node_or_null`이 안전.

6. **tscn 작성 후 `godot --headless --import` 1회 검증** — parse error 즉시 발견.

7. **모든 Scene 호출 (외부 씬) → 별도 `CanvasLayer`로** — z-order 가려짐 회피. ModalLayer=100, BattleLayer=90, TitleLayer=5, ManorLayer=0.

8. **수치/자원 코드 → autoload에 `const`로 정의** — 매직넘버 회피. `GameWorld.BASE_FOOD_HARVEST = 2` 등.

## 참조 — 함께 봐야 할 레퍼런스

- `references/manor-dashboard-screen-pattern.md` — 메인 허브 4존 레이아웃 골격
- `references/panel-container-visibility-invariant-and-patch-tscn-pitfalls.md` — PanelContainer mouse_filter 가이드
- `references/modal-layer-popup-z-order-separation.md` — CanvasLayer z-order 분할 패턴
- `references/manor-dashboard-screen-with-control-node2d.md` — SubViewport vs Control>Node2D 가이드
- `references/battle-scene-with-apply-result-unification.md` — GameWorld.apply_result 단일 dict 통합
- `references/character-click-interaction-area2d.md` — TextureButton 마우스 인터랙션
- `references/auto-progress-speed-tuning.md` — 속도/간격 곱 비례 + LB_VERIFY [2.5] 패턴
