# Autoload 시그널 Race Condition — 진단과 2중 안전망 패턴

Godot 4에서 autoload와 main scene 사이의 **시그널 emit/connect 타이밍 충돌**은 가장 찾기 어려운 버그 클래스 중 하나. 사용자에게 보이는 증상은 "버튼이 영영 비활성" 같은 미묘한 한 줄 메시지인데, 실제 원인은 autoload 로드 순서와 깊이 연관. 이 문서는 last-banner (2026-07-15~16) 실전에서 만난 패턴 3종 + 검증 워크플로.

---

## 패턴 1: Connect 전에 Emit (가장 빈번)

### 증상
- UI 버튼이 영영 비활성 상태 (예: "자산 가져오기 (CDN)")
- 시그널을 받는 다른 핸들러는 정상 작동
- `print()` 로그는 emit은 정상 발생
- 코드 경로상 핸들러는 호출돼야 하는데 호출 안 됨

### 진단법
main.gd `_ready()`에 진단용 print 추가:
```gdscript
func _ready() -> void:
    print("[Main] autoload 상태: %s" % str(AssetRegistry.get_base_url() != ""))
    AssetRegistry.manifest_loaded.connect(_on_manifest_loaded)
    print("[Main] 시그널 연결 후 connections: %d" % AssetRegistry.manifest_loaded.get_connections().size())
    # ...
```

출력에 `autoload 상태: True` + `connections: 0` → 시그널이 connect 전에 emit된 것 확정.

### 원인
Godot autoload는 main scene보다 먼저 `_ready()` 호출. 다음 순서:
1. `AssetRegistry._ready()` → `_load_manifest()` → **`manifest_loaded.emit()` (즉시)**
2. `main.tscn` 인스턴스화 → `main.gd._ready()` → `AssetRegistry.manifest_loaded.connect(...)` **이미 늦음**

결과: 시그널은 emit됐는데 아무도 듣지 못함 → 핸들러 미호출 → UI 상태 영속.

### 해결 — 2중 안전망

**1단계: emit을 `call_deferred`로 지연** — autoload 측
```gdscript
# autoload/asset_registry.gd
func _load_manifest() -> void:
    # ... 매니페스트 파싱 ...
    _manifest_ready = true
    # 핵심: 다음 프레임에 emit → main scene _ready 끝날 시간 확보
    call_deferred("_emit_manifest_loaded")

func _emit_manifest_loaded() -> void:
    manifest_loaded.emit()
    print("[AssetRegistry] 매니페스트 로드 완료")
```

**2단계: main scene에 안전망** — connect 직후 이미 로드됐는지 확인
```gdscript
# scripts/main.gd
func _ready() -> void:
    AssetRegistry.manifest_loaded.connect(_on_manifest_loaded)
    # 핵심: autoload 시그널이 이미 emit된 경우를 위한 안전망
    if AssetRegistry.get_base_url() != "":
        _on_manifest_loaded()
```

**왜 둘 다 필요한가?**
- `call_deferred`만: autoload 시점에서는 OK, 하지만 다른 코드 path에서 autoload 등록 전에 emit하는 경우 (예: 게임 도중 `_load_manifest` 재호출) 미보호.
- 안전망만: 매번 main scene 진입 시 체크 필요 → 미세 overhead, 그러나 의도 명확.

둘 다 적용하면 어떤 호출 경로에서도 핸들러가 1회는 호출됨 보장.

---

## 패턴 2: 시그널 핸들러 인자 불일치 ERROR

### 증상
- 헤드리스에서 `LB_VERIFY=1 godot --headless`가 60초 안에 안 끝남 (hang)
- stderr에 `ERROR: Method expected N argument(s)`
- 같은 핸들러를 여러 시그널에 connect한 경우

### 진단법
```bash
LB_VERIFY=1 godot --headless 2>&1 | grep "Method expected"
```

### 원인 예시
```gdscript
# 잘못된 패턴
func _on_mercenary_changed(_m = null) -> void:
    if visible: refresh()

GameWorld.mercenary_joined.connect(_on_mercenary_changed)   # 1개 인자
GameWorld.mercenary_left.connect(_on_mercenary_changed)     # 2개 인자 (m, reason)
```

`mercenary_left.emit(m, reason)` 호출 시 Godot이 인자 개수 검증 → `Method expected 1 argument(s), but called with 2` ERROR → 시그널 emit 체인 중단 → 다음 코드 hang.

### 해결 — 모든 핸들러는 모든 인자 디폴트
```gdscript
func _on_mercenary_changed(_m = null, _reason: String = "") -> void:
    if visible: refresh()
```

**규칙**:
- 모든 인자에 디폴트 값 (`= null`, `= ""`, `= 0`)
- 안 쓰는 인자는 underscore prefix (`_m`, `_reason`)
- 시그널 emit 시그니처와 정확히 매치하지 않아도 OK (디폴트 채워짐)
- 4개 이상 인자도 동일 패턴

### 예방
- 같은 핸들러를 여러 시그널에 connect할 때, **모든 시그널의 emit 시그니처 grep** 후 가장 긴 시그니처로 핸들러 작성
- 또는 핸들러를 시그널마다 분리 (`_on_mercenary_joined`, `_on_mercenary_left`, ...)

---

## 패턴 3: `@onready` 인스턴스화 순서

### 증상
- `@onready var battle_scene: Control = $BattleScene` 인데 `Nil`
- stderr에 `ERROR: Node not found: "BattleScene"`
- 빠른 부팅 (헤드리스/모바일)에서만 발생

### 원인
`@onready` 변수는 `_ready()` 함수가 return하기 전에 평가됨. main.tscn에서 다른 PackedScene을 `instance=ExtResource(...)`로 인스턴스화할 때, **자기 자신의 자식**은 평가 시점에 존재하지만 **다른 instanced scene의 루트는 시점에 따라 미준비**일 수 있음.

특히 main.gd에서 `DecisionDialog`, `RosterScreen`, `BattleScene`, `Dashboard`, `TutorialOverlay`, `SuccessionScreen`, `BuildingsScreen` 같은 6~7개 instanced scene을 한 main.tscn에 넣으면 트리거 빈도 ↑.

### 해결 — 동적 검색 패턴
```gdscript
# 잘못된 패턴 — 인스턴스화 순서에 의존
@onready var battle_scene: Control = $BattleScene

# 올바른 패턴 — 시점 무관
var battle_scene: Control = null

func _ready() -> void:
    # ... 기타 연결 ...
    # 핵심: 다음 프레임에 검색 (모든 instanced scene 준비 완료)
    call_deferred("_find_battle_scene")

func _find_battle_scene() -> void:
    battle_scene = get_node_or_null("BattleScene")

func _on_use_battle_scene() -> void:
    if battle_scene == null:
        _find_battle_scene()  # 재시도
    if battle_scene != null and battle_scene.has_method("show_battle"):
        battle_scene.show_battle(...)
```

### 장점
- **시점 무관** — `call_deferred` 다음 프레임엔 무조건 인스턴스화 완료
- **동적 부재 시 null** (기존 `@onready`는 ERROR 후 null, 하지만 디버깅 어려움)
- **검증 모드 안전** — main scene이 LB_VERIFY 분기에서 early return해도 OK

### 트레이드오프
- 매 호출 시 null 체크 필요 → 코드량 약간 증가
- 단, main.gd 같은 단일 호출자에서만 발생

### 적용 기준
- main scene에서 직접 참조하는 instanced scene (예: 6개 화면 인스턴스)
- 다른 화면에서 호출하는 빈도가 낮을 때 (null 체크 1번이면 충분)
- 검증/디버깅 시 안전망 필요할 때

---

## 통합 진단 워크플로

`LB_VERIFY=1 godot --headless`가 60초 안에 안 끝나거나, UI 버튼이 영영 비활성 상태일 때:

```bash
# 1단계: stderr 에러 grep
LB_VERIFY=1 godot --headless 2>&1 > /tmp/out.txt
grep -E "ERROR|Parse Error|Method expected|Node not found|Invalid access" /tmp/out.txt

# 2단계: hang 시 진단 print 추가
# main.gd _ready()에 print 추가해서 어느 단계까지 도달했는지 확인
```

흔한 매핑:
- `Method expected N argument(s)` → 패턴 2 (핸들러 인자)
- `Node not found: "X"` + `@onready $X` → 패턴 3 (인스턴스화 순서)
- `시그널 emit 로그는 있는데 핸들러 미호출` → 패턴 1 (autoload race)

## 자동 검증 모드 (LB_VERIFY) 시 주의

main.gd의 `_ready()`가 `if _verify_mode: _run_verify(); return`로 early return하면 `@onready` 변수는 평가되지만 `_on_manifest_loaded` 안전망은 호출되지 않음. 검증에서 `get_connections().size() == 0`이 정상 (main scene이 시그널 connect 전에 분기해서 빠짐).

**해결**: 검증 모드 분기에서 시그널 assert 약화:
```gdscript
# 잘못된 패턴 (verify_mode에서 fail)
assert(AssetRegistry.manifest_loaded.get_connections().size() >= 1)

# 올바른 패턴
if not _verify_mode:
    assert(AssetRegistry.manifest_loaded.get_connections().size() >= 1)
```

---

## 참고: last-banner 사례 타임라인 (2026-07-15~16)

- **7/15 오전**: 대시보드/명단/결정 다이얼로그 추가 — 자동 진행 + 결정 큐 + 저장은 정상 작동
- **7/15 오후**: 사용자가 "자산 가져오기 버튼이 비활성화"라고 보고
- **7/16 오전**: 진단 — autoload 시그널 race condition 확정 → call_deferred + 안전망 적용 → 버튼 활성화 확인
- **7/16**: AudioManager가 `play_bgm("menu")` 호출 시 fetch_file → 헤드리스에서 Ogg 디코딩 실패 → 검증 hang → `DisplayServer.get_name() == "headless"` 체크 가드 추가

이 패턴들은 Godot 4 + 자동 진행 게임 + Web export 조합에서 **거의 모든 프로젝트가 만남**. 다음 게임 빌드 시 `LB_VERIFY` 패턴 + 2중 안전망 + 동적 검색을 **첫 1시간에 모두 셋업**하면 디버깅 시간을 90% 절약.