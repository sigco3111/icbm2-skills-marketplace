# Godot 4 Web — 검은 화면 진단 워크플로 (2026-07-15 last-banner 실전)

원격 사용자 PC 접근 불가 상황에서 Godot Web 빌드가 브라우저에서 검은 화면으로 부팅 안 될 때 진단 절차.

## 핵심 사실

**puppeteer 헤드리스는 WebGL2 software rendering 미지원**. `--use-gl=swiftshader` 옵션 줘도 게임 자체 부팅 안 됨. → puppeteer 결과로 사용자 환경 추론 **불가**. 헤드리스에서 게임 부팅 안 된다고 사용자 환경도 동일하지 **않음**.

진단 정석은 **사용자 브라우저에 진단 결과를 화면에 띄우는 것**. 그러면 사용자가 텍스트 회신 → 원격으로 원인 특정 가능.

## 4단계 진단 워크플로

### 1단계: 로컬 헤드리스 부팅 검증 (사용자 환경 X)

```bash
godot --headless --quit-after 200 2>&1 | tail
```

→ autoload parse 에러 잡기. `Error: Parse Error` 같은 게 보이면 빌드 전에 autoload 스크립트 수정. 통과 시 다음 단계.

### 2단계: build/web/ 4축 헤더 검증 (curl 한 줄로)

```bash
curl -sI https://<alias>.vercel.app/ | grep -iE "cross-origin|coop|coep|corp"
# 4 헤더 다 보여야 함:
# cross-origin-embedder-policy: require-corp
# cross-origin-opener-policy: same-origin
# cross-origin-resource-policy: same-origin
# (Vercel 기본은 위 3개. 4번째는 vercel.json의 COEP/COOP/SW 추가 헤더)

curl -s https://<alias>.vercel.app/asset_host.json | python3 -c "import json,sys; d=json.load(sys.stdin); print('OK', d['total_size_bytes'])"
# asset_host.json → total_size_bytes 정상 (lazy fetch 매니페스트)

curl -sI https://<alias>.vercel.app/index.pck | grep -i content-length
curl -sI https://<alias>.vercel.app/index.wasm | grep -i content-length
# pck/wasm Content-Length (lazy fetch 채택 시 pck ~수백 KB)

curl -sI https://<alias>.vercel.app/index.service.worker.js
# SW 비활성화 시 404 (정상). SW 활성이면 200.
```

4개 다 정상이면 빌드 자체는 정상. 사용자 환경 이슈.

### 3단계: 진단 pane 자동 주입 + 사용자 새로고침

`tools/inject-debug-pane.sh`가 build/web/index.html에 공격적 디버그 pane 자동 주입 (build.sh web 내부에서 실행). Vercel deploy 후 사용자에게:

> 새로고침 (Cmd+Shift+R) → 우상단 빨간 박스에 표시되는 텍스트 그대로 보내주세요.

사용자는 페이지 우상단 박스에서 다음 정보를 즉시 확인 가능:
- canvas 크기 (300x150 = 부팅 안 됨, 1280x720 = 정상)
- status visible (visible/hidden)
- progress 텍스트
- notice 텍스트 (displayFailureNotice 호출 시 missing features 메시지)
- Missing features (threads=false/true) 두 가지 비교
- Engine / SharedArrayBuffer / crossOriginIsolated / WebGL2 / WebGL1 fallback

### 4단계: 결과 해석

#### 케이스 A: notice = "Error\nThe following features required to run Godot projects on the Web are missing:\nWebGL2..."

→ **WebGL2 미지원 브라우저**. 모바일 Safari 구버전 / IE / 일부 임베디드 브라우저. 사용자에게 Chrome/Safari 최신 권고.

#### 케이스 B: Missing features (threads=true) = ["WebGL2...", "Cross-Origin Isolation..."]

→ **Cross-Origin Isolation 헤더 누락**. `Missing features (threads=false) = []` 인데 threads=true에 COEP 빠짐 → 우리 variant/thread_support=false 빌드인데 export가 GODOT_THREADS_ENABLED=true로 고정 → var이ant 옵션 먹통. 해결: 빌드 옵션 `variant/wasm_threads=false` 명시 + 빌드 캐시 클리어.

#### 케이스 C: crossOriginIsolated: false (정상 헤더인데도 false)

→ Vercel CDN 캐시가 옛 응답일 수 있음. 빌드 후 즉시 `--archive=tgz` 새로 업로드 + 사용자에게 강력 새로고침 요청.

#### 케이스 D: canvas 300x150 + Missing features [] + progress 비어있음

→ **WASM 자체 실행 안 됨**. SharedArrayBuffer 헤더 의존성 또는 Godot Engine 초기화 실패. `Engine.onError` hook이 [GODOT] 로그에 표시. 그 텍스트 받으면 Godot 소스 분석 필요.

#### 케이스 E: notice 비어있음 + status hidden + 페이지 에러 있음

→ **JS 문법 깨짐**. 우리 SW 비활성화 패치에서 else 처리 잘못한 경우. `console.error: Unexpected token 'else'` 같은 메시지가 pane에 표시됨. 패치 재검토.

## puppeteer 디버그 모드 (사용자 환경 모방용)

```bash
npm install puppeteer-core    # /tmp/chrome-test/
```

```javascript
// test.mjs
import puppeteer from 'puppeteer-core';
const browser = await puppeteer.launch({
  executablePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  headless: 'new',
  args: ['--no-sandbox', '--enable-features=SharedArrayBuffer',
         '--use-gl=swiftshader', '--ignore-gpu-blocklist']
});
const page = await browser.newPage();
page.on('console', msg => console.log(`[${msg.type()}] ${msg.text()}`));
page.on('pageerror', err => console.log('[pageerror]', err.message));
await page.goto('https://last-banner.vercel.app/', {waitUntil: 'load'});
await new Promise(r => setTimeout(r, 30000));   // 30초 부팅 대기
const debug = await page.evaluate(() => document.getElementById('lb-debug-pane').textContent);
console.log(debug);
await browser.close();
```

→ 헤드리스에선 WebGL2 실패로 puppeteer 검증을 사용자 환경 검증으로 못 씀. **사용자 진단 pane 회신이 최선**.

## 빌드 파이프라인 권장 통합

`tools/build.sh`에 두 스크립트 자동 호출:

```bash
case "$target" in
  web)
    godot --headless --export-release "Web" "$BUILD_DIR/web/index.html"
    # PWA Service Worker 비활성화 (검은 화면 함정 회피)
    [ -f "$LB_ROOT/tools/disable-service-worker.sh" ] && \
      bash "$LB_ROOT/tools/disable-service-worker.sh" "$BUILD_DIR/web"
    # 디버그 pane 주입 (런타임 진단)
    [ -f "$LB_ROOT/tools/inject-debug-pane.sh" ] && \
      bash "$LB_ROOT/tools/inject-debug-pane.sh" "$BUILD_DIR/web/index.html"
    ;;
esac
```

→ 매 빌드마다 SW 자동 비활성화 + 디버그 pane 자동 주입. 사용자 새로고침만으로 진단 가능.

## 절대 하지 말 것

- **`progressive_web_app/enabled=false`만 믿지 말 것** — Godot 4.7은 SW 파일/코드를 여전히 생성함. 빌드 후 post-processing 필수.
- **단순 주석 처리 (`//`)로 SW 비활성화하지 말 것** — else가 매칭할 if 잃어 `SyntaxError: Unexpected token 'else'` (실제 last-banner 1차 패치 함정). `if (false) { /* DISABLED */ } else { ... }` 패턴만 안전.
- **puppeteer 검증을 사용자 환경 검증으로 착각하지 말 것** — swiftshader는 WebGL2 실패 → 게임 부팅 안 됨 → 사용자 환경과 무관.
- **헤더만 확인하고 게임 코드를 의심하지 말 것** — 정상 헤더 + 정상 빌드 + 게임 안 부팅 = autoload/씬 asset path 오류. pane 회신 받으면 `Missing features []` + `progress ""` 케이스로 진단.

## 자동화로 만든 검증 흐름 (last-banner 1차 검증 사례)

```
1. bash tools/disable-service-worker.sh build/web         → SW 파일 삭제 + HTML if(false) 패치
2. bash tools/inject-debug-pane.sh build/web/index.html    → pane 주입
3. curl -sI https://last-banner.vercel.app/ | grep cross  → 3개 헤더 OK
4. curl -s https://.../asset_host.json | jq                → manifest OK
5. puppeteer test.mjs https://...  (WebGL2 실패 → 헤드리스 한계 확인)
6. 사용자에게 새로고침 요청 → 우상단 박스 텍스트 회신 → 4단계로 원인 특정
```
