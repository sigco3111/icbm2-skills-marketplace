# 모달/팝업을 별도 CanvasLayer로 분리 — ModalLayer(layer=100) 패턴

> 모달(결정 큐, 설정, 알림)을 띄울 때 **메인 화면(ManorDashboard, WorldMap 등)에 가려지는 함정** 해결. 별도 CanvasLayer에 layer=100 설정하면 모든 Control 위에 항상 표시.

## 의도

Godot 4에서 CanvasLayer는 z-order를 결정한다. 기본 `layer=0` 1개만 쓰면 자식 추가 순서로 그려져서 **나중에 추가된 게 위에** 표시됨. 매니 대시보드를 메인에 추가한 직후 모달을 같은 CanvasLayer에 추가하면 모달이 보이지만, 모달을 `Main` 직속 자식으로 추가하고 매니를 그 뒤에 추가하면 매니가 모달을 가림.

**해결**: 모달 전용 CanvasLayer (`ModalLayer`) 분리, `layer=100` 명시. z-order 100은 기본 0보다 항상 위.

## 검증된 패턴 (Last Banner v2.1.1)

### 씬 구조 (main.tscn 핵심 부분)

```
Main (Node2D)
├── UI (CanvasLayer, 기본 layer=0)
│   ├── TopResourceBar       ← 자원 카드
│   ├── BottomButtonRow      ← P/+1일/저장/불러오기
│   └── ModalLayer NO!       ← 여기에 두면 안 됨 (layer 동일)
├── ManorLayer (CanvasLayer, layer=0)
│   └── ManorDashboard        ← 매너지 풍경도 (전체 화면)
└── ModalLayer (CanvasLayer, layer=100)   ← 항상 위에 표시
    ├── DimBG (ColorRect alpha=0.7, mouse_filter=0)   ← 반투명 배경
    └── DecisionModal (PanelContainer, mouse_filter=0)   ← 모달 패널
        └── ModalVBox (VBoxContainer)
            ├── ModalTitle (Label, 22pt)
            ├── ModalDesc (Label, autowrap)
            ├── ModalPriority (Label, 14pt)
            └── ModalChoices (VBoxContainer)   ← 동적 버튼 add_child
```

### 의도된 레이어 분리 vs 권장

| 노드 | layer | 의도 |
|---|---|---|
| `UI` (자원/버튼) | 0 | 가장 아래 (배경처럼 항상 보임) |
| `ManorLayer` | 0 | 매너지 풍경도 (게임 화면) |
| `ModalLayer` | 100 | 모달/팝업 (모든 레이어 위) |

### tscn 패턴

```ini
[node name="ModalLayer" type="CanvasLayer" parent="."]
layer = 100

[node name="DimBG" type="ColorRect" parent="ModalLayer"]
anchor_right = 1.0
anchor_bottom = 1.0
color = Color(0, 0, 0, 0.7)
visible = false
mouse_filter = 0

[node name="DecisionModal" type="PanelContainer" parent="ModalLayer"]
visible = false
anchor_left = 0.5
anchor_top = 0.5
anchor_right = 0.5
anchor_bottom = 0.5
offset_left = -360.0
offset_top = -180.0
offset_right = 360.0
offset_bottom = 180.0
mouse_filter = 0

[node name="ModalVBox" type="VBoxContainer" parent="ModalLayer/DecisionModal"]
```

핵심 속성 2개:
1. `ModalLayer layer=100` — 모든 layer 0 위에 표시
2. `mouse_filter=0` (`MOUSE_FILTER_STOP`) — 모달 위 마우스 클릭이 뒤로 통과 X

### GDScript 동적 노드 + 토글

```gdscript
# ModalLayer는 Main 직속 자식 → get_node_or_null("ModalLayer/DecisionModal")
var decision_modal: PanelContainer = null
var modal_dim_bg: ColorRect = null

func _find_nodes() -> void:
    modal_dim_bg = get_node_or_null("ModalLayer/DimBG") as ColorRect
    decision_modal = get_node_or_null("ModalLayer/DecisionModal") as PanelContainer

func _show_next_decision() -> void:
    # 결정 모달 띄움
    if modal_dim_bg:
        modal_dim_bg.visible = true
    decision_modal.visible = true

func _close_modal() -> void:
    if decision_modal:
        decision_modal.visible = false
    if modal_dim_bg:
        modal_dim_bg.visible = false
```

## 핵심 함정 4가지

### 1. 같은 CanvasLayer에 두면 자식 추가 순서로 결정

처음 `UI` 안에 모달 넣고 `ManorDashboard`를 `Main` 직속 자식으로 추가했다면, ManorDashboard가 UI 자식(모달)보다 인덱스가 늦어 **위에 그려져서 모달 가림**. **반드시 별도 CanvasLayer 분리**.

### 2. layer=10만 줘도 안 됨 (모든 게임 UI와 충돌)

`layer=10`은 일반 게임 UI와 겹쳐 의도와 다를 수 있음. 명시적으로 `100` (충분히 큰 값) 사용.

### 3. mouse_filter 안 주면 클릭이 뒤로 통과

`ColorRect`/`PanelContainer` 기본 mouse_filter=1 (PASS) 또는 2 (IGNORE). 모달은 **STOP**(=0)으로 명시. 자식 Button이 정상 동작.

### 4. DimBG alpha 0.5 이하면 효과 없음, 0.9 이상은 너무 어두움

검은색 0.7 alpha가 표준. 이벤트 모달 강조 시 0.85까지.

## 검증

### 헤드리스 (LB_VERIFY)

모달 표시/숨김 검증:

```gdscript
# 가짜 결정 push 후 모달 표시 확인
DecisionQueue.push("TEST", {"title": "테스트", ...}, DecisionQueue.Priority.MEDIUM)
_check_decision_queue()
await get_tree().process_frame
assert(decision_modal.visible, "모달 안 뜸 — ModalLayer z-order 확인")
assert(modal_dim_bg.visible, "DimBG 안 보임")
```

### 시각 확인 (사용자 데스크탑)

모달 클릭 가능 + 회전 시 DimBG 가시성 확인. 안 보이면 tscn에서 `parent="."` (Main 직속) 확인.

## 적용 가능

- 결정 큐 모달 (게임 진행 결정)
- 설정 화면 (옵션 변경)
- 알림 토스트 (이벤트 로그 상세)
- 저장/불러오기 다이얼로그
- 게임 종료 확인

⇒ 모달 띄울 일이 있으면 **항상 `ModalLayer`로 분리**.
