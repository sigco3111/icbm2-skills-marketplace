---
name: godot-mcp-gut-integration-setup
description: hi-godot/godot-ai + bitwes/Gut + @pinkpixel/mcpollinations 통합 설치 recipe — 2026-07-16 Last Banner 실전 검증. 헤드리스 환경에서 3개 셋업 후 godot-ai는 사용자 GUI에서 한 번 Configure 클릭 필요 (자동 등록 불가). "godot-ai 설치", "Gut 단위 테스트", "mcpollinations 등록", "Hermes에서 Godot 자율 코딩", "Godot 4 autoload 단위 테스트" 같은 요청에 발동.
---

# Godot MCP + Gut + mcpollinations 통합 설치 (2026-07-16 실전 검증)

## 1. hi-godot/godot-ai 플러그인 (Godot 4 에디터 MCP 서버)

**용도**: Godot 에디터를 MCP(Model Context Protocol)로 노출 → Claude/Hermes에서 자연어로 씬/노드/GDScript 조작.

### 설치 (3단계, 헤드리스에서 가능)

```bash
# 1) 최신 릴리즈 ZIP 다운로드 (v3.0.2 검증됨)
cd ~/work/<game>
mkdir -p addons
curl -fsSL -o /tmp/godot-ai.zip \
  "https://github.com/hi-godot/godot-ai/releases/download/v3.0.2/godot-ai-plugin.zip"

# 2) 압축 해제 (ZIP 안에 addons/godot_ai/ 구조가 들어있음)
unzip -o /tmp/godot-ai.zip                 # 현재 디렉터리에 addons/godot_ai/ 풀림
ls addons/godot_ai | head -5               # client_configurator.gd + tool_catalog.gd + clients/ + ...
du -sh addons/godot_ai                    # 약 2.0MB

# 3) project.godot에 [editor_plugins] 등록
# project.godot:
#   [editor_plugins]
#   enabled=PackedStringArray("res://addons/godot_ai/plugin.cfg", "res://addons/gut/plugin.cfg")
```

### 등록 — **GUI 단계 필수** (가장 흔한 함정)

**헤드리스 환경에서는 자동 MCP 등록이 안 됨.** 사용자가 한 번 Godot GUI를 띄워야 다음 단계 가능:

```bash
open -a Godot.app ~/work/<game>   # 사용자 데스크탑에서 직접
# 또는 godot --editor ~/work/<game>
```

GUI 안에서:
1. **Godot AI 도크** 활성화 (Project > Plugins > Godot AI 체크)
2. **Clients 탭** → "Hermes Agent" 또는 "Claude Code" row 선택
3. **"Configure"** 버튼 클릭 → 자동으로 `claude mcp add --scope user --transport http godot-ai http://127.0.0.1:<port>/mcp` 실행됨
4. (선택) uv 설치: `brew install uv` — Python MCP 브릿지

### 검증

```bash
# 헤드리스에서 충돌 안 나는지만 확인
cd ~/work/<game>
LB_VERIFY=1 godot --headless --quit-after 100 2>&1 | grep -iE "(godot_ai|ERROR)" | head
# → 아무 출력 없으면 OK. godot-ai는 _process/idle 상태로 대기만 함.
```

### Client 등록 자동화 코드 (godot-ai 내부)

`addons/godot_ai/clients/claude_code.gd`가 자동으로 `claude mcp add --scope user --transport http {name} {url}` 실행. JSON fallback은 `~/.claude.json` 직접 편집 (type=url 키). 자세한 패턴은 `references/godot-mcp-ecosystem-2026-07.md` 참고.

### 함정

1. **헤드리스에서 자동 등록 불가** — GUI 한 번 띄우는 사용자 위임 필요. 시도 시간 낭비 금지.
2. **`--transport http`** — godot-ai 서버는 HTTP 기반 (stdio X). 일부 클라이언트는 stdio만 지원 → 호환 확인.
3. **`uv` PATH** — godot-ai가 `uv`로 mcp-proxy 설치 시도. `brew install uv` 후 `~/.local/bin` 또는 `which uv`로 PATH 확인.

## 2. bitwes/Gut 단위 테스트 (2,639⭐, Godot 4.7+ 호환 v9.6.1)

**용도**: GameWorld.apply_result / EventEngine / DecisionQueue 등 autoload 함수를 단위 레벨에서 검증. LB_VERIFY = 통합 (24시간 시뮬 + round-trip), Gut = 함수 단위 (개별 결정 핸들러/자원 변동).

### 설치 — **git clone만 가능** (가장 흔한 함정)

```bash
cd ~/work/<game>
git clone --depth 1 --branch v9.6.1 https://github.com/bitwes/Gut.git /tmp/gut_src
cp -R /tmp/gut_src/addons/gut addons/gut    # addons/ 만 복사 (나머지는 docs/ + CI 설정)
du -sh addons/gut                          # 3.2MB
cat addons/gut/plugin.cfg | head -3        # [plugin] version="9.6.1" 확인
```

**왜 ZIP이 아닌가**: Gut은 GitHub releases 페이지에 ZIP이 **없음**. ZIP 검색은 404 반환. git clone이 유일한 통로.

### project.godot 등록

```ini
[editor_plugins]
enabled=PackedStringArray("res://addons/gut/plugin.cfg", "res://addons/godot_ai/plugin.cfg")
```

### 테스트 실행 (헤드리스)

```bash
cd ~/work/<game>
godot --headless -s addons/gut/gut_cmdln.gd \
  -gdir=res://tests/unit \
  -gprefix=test_ \
  -gsuffix=.gd \
  -gexit 2>&1 | tail -30
# → "9/9 passed" + Totals 요약
```

| 플래그 | 의미 |
|---|---|
| `-gdir` | 테스트 디렉터리 (res:// 기준) |
| `-gprefix` | 파일명 prefix (`test_*.gd`) |
| `-gsuffix` | 파일명 suffix |
| `-gexit` | Godot 자동 종료 |

### 테스트 골격 — Last Banner v2 (2026-07-16 검증)

```bash
mkdir -p tests/unit
```

골격은 `templates/gut-test-template.gd` 참고. 핵심 패턴:

```gdscript
extends GutTest
const TEST_SLOT := "gut_test_slot"

func before_each() -> void:
    # autoload는 영속 상태이므로 테스트 간 상태 격리 필수
    GameWorld.gold = 200
    GameWorld.food = 100
    GameWorld.population = 50
    GameWorld.prosperity = 10
    GameWorld.event_log.clear()

func test_apply_daily_economy_basic_population_50() -> void:
    var gold_before: int = GameWorld.gold
    GameWorld.apply_daily_economy()
    assert_eq(GameWorld.gold - gold_before, 22, "population=50, prosperity=10 → +22 gold")

func test_modify_resource_emits_signal() -> void:
    var captured: Array = []
    GameWorld.resource_changed.connect(func(r, v): captured.append({"r": r, "v": v}))
    GameWorld.modify_resource("gold", 50)
    assert_eq(captured.size(), 1, "시그널 1회 emit")

func test_save_load_round_trip() -> void:
    GameWorld.gold = 1234
    var state: Dictionary = GameWorld.save_state()
    GameWorld.gold = 0
    GameWorld.load_state(state)
    assert_eq(GameWorld.gold, 1234, "round-trip 보존")
```

### 검증 출력 예 (Last Banner v2 실전)

```
9/9 passed.
Totals
------
Scripts               1
Tests                 9
Passing Tests         9
Asserts              22
Time              0.466s

---- All tests passed! ----
```

### Gut ↔ LB_VERIFY 역할 분리

| 계층 | 도구 | 검증 대상 |
|---|---|---|
| **단위 (함수)** | **Gut** | autoload 함수 (`apply_result`, `apply_daily_economy`, `save_state`/`load_state` round-trip, 시그널 emit 횟수) |
| **통합 (씬)** | **LB_VERIFY=1 godot --headless** | main scene 부팅 + autoload 8개 정상 등록 + 24시간 시뮬 + 결정 큐 push + 화면 자식 인스턴스 + 자동 진행 ON/OFF 분기 |

**둘 다 필요**: Gut이 통과해도 LB_VERIFY가 실패할 수 있고 (씬 부팅 hang), 그 반대도 가능. CI에선 둘 다 1줄 실행 + PASS 여부 확인.

### 함정

1. **autoload 상태 격리 누락** — before_each 없이 테스트 작성하면 이전 테스트 데이터 영향. autoload는 매 테스트 new_game() 호출 안 함 (싱글턴). → `before_each()`에서 모든 필드 명시 리셋.
2. **tscn에서 addons 안 보임** — Project Settings > Plugins에서 수동 활성화해야 가끔. 헤드리스에선 `editor_plugins` 섹션만으로 충분.
3. **`@onready` 변수는 autoload에서도 평가됨** — `_ready()`에 검증 모드 분기 있어도 @onready 평가 시점엔 nil 가능. → null 가드 필수.
4. **Unknown resource → push_warning 출력** — GDScript WARNING stderr에 출력되며 테스트는 통과. 노이즈 줄이려면 `--no-warnings` 또는 `disable_warnings=true`.
5. **GUT v9.7.1 최신** — 2026-07-16 기준 v9.6.1이 Last Banner와 충돌 없음. v9.7.1로 올리면 호환성 테스트 권장.

## 3. @pinkpixel/mcpollinations (npm v1.3.1, MCP stdio 서버)

**용도**: Pollinations.ai 무료 이미지/오디오 생성 (1024+ 모델). NPC 초상화/배경 즉시 채우기. **Godot 외부 자산을 autonomous하게 생성**할 때 핵심.

### 설치 (2단계, 헤드리스에서 100% 작동)

```bash
# 1) npm 글로벌 설치 (Hermes prefix 또는 user-global)
mkdir -p ~/.npm-global
npm install -g @pinkpixel/mcpollinations --prefix ~/.npm-global

# 2) ~/.claude.json에 MCP 서버 등록 (python one-liner)
python3 -c "
import json
with open('/Users/mac/.claude.json') as f: d = json.load(f)
d['mcpServers'] = {
    'mcpollinations': {
        'command': 'npx',
        'args': ['-y', '@pinkpixel/mcpollinations'],
        'disabled': False
    }
}
with open('/Users/mac/.claude.json', 'w') as f: json.dump(d, f, indent=2, ensure_ascii=False)
print('updated ~/.claude.json')
"
```

검증:
```bash
python3 -c "import json; print(json.dumps(json.load(open('/Users/mac/.claude.json'))['mcpServers'], indent=2, ensure_ascii=False))"
```

**다음 Claude Code 세션부터 즉시 사용 가능** — `mcp` 도구로 자동 노출됨.

### 함정

1. **npm 글로벌 prefix 충돌** — Hermes이 이미 다른 글로벌 패키지를 쓰면 `--prefix ~/.npm-global`로 격리. `npm root -g`로 확인.
2. **Pollinations 무료 모델 다운타임** — 특정 모델 24h 사용 한도 있음. 폴백 모델 자동 선택 (패키지가 처리).
3. **결과는 images/ 폴더 또는 base64** — Godot 자산을 위해선 파일 경로 받고 `assets/concept-art/`로 `mv`. 즉시는 저장 안 됨.
4. **stdout/stderr 둘 다 사용** — MCP stdio 프로토콜이라 logger가 stdout 잡으면 메시지 손실. 가능하면 stderr로.

## 4. 통합 워크플로 (Last Banner 권장)

### 즉시 시작 (3분 셋업)

```bash
# 1) Gut + godot-ai (둘 다 git/curl로 가능)
cd ~/work/<game>
mkdir -p addons tests/unit

curl -fsSL -o /tmp/godot-ai.zip \
  "https://github.com/hi-godot/godot-ai/releases/download/v3.0.2/godot-ai-plugin.zip"
unzip -o /tmp/godot-ai.zip

git clone --depth 1 --branch v9.6.1 https://github.com/bitwes/Gut.git /tmp/gut_src
cp -R /tmp/gut_src/addons/gut addons/gut

# 2) project.godot에 editor_plugins 등록 (patch 또는 write_file)

# 3) Godot import (한 번)
godot --headless --import

# 4) 헤드리스 부팅 검증 (autoload 충돌 확인)
LB_VERIFY=1 godot --headless --quit-after 100 2>&1 | grep -iE "ERROR" | head
```

### 사용자 GUI 단계 (1분, 사용자 의존)

```bash
open -a Godot.app ~/work/<game>
# → Plugins > Godot AI 활성화 → 도크 Configure → "Claude Code" → Configure 버튼 클릭
```

### 단위 테스트 작성 (30분, 9개 테스트)

`templates/gut-test-template.gd`를 `tests/unit/test_<autoload>.gd`로 복사 → 함수 본문 작성 → 실행.

### Godot MCP 자연어 조작 (Configure 후)

```
User: "DecisionQueue에 MERCENARY_OFFER push해서 모달 뜨는지 보여줘"
  → godot-ai mcp_godot_run_code → EventEngine._maybe_mercenary() 호출 → 모달 표시
```

## 5. 검증된 신호 5가지

1. **헤드리스 부팅 통과** — `LB_VERIFY=1 godot --headless --quit-after 100`로 8개 autoload + 9개 화면 부팅 확인.
2. **Gut 9/9 + LB_VERIFY 둘 다 PASS** — 단위 + 통합 양쪽 OK여야 머지 안전.
3. **`~/.claude.json`의 `mcpServers` dict 검증** — 다음 세션 시작 시 mcp 도구 노출 확인.
4. **Godot GUI Configure 1회 후 godot-ai 도구 노출** — 세션 시작 후 `claude mcp list`로 `godot-ai` row 확인.
5. **소스 빌드 비용 확인** — Gut 3.2MB + godot-ai 2.0MB + mcpollinations ~1MB = 총 ~6MB. Vercel 100MB 한계 안전.

## 6. 자주 빠지는 함정 5가지

1. **Gut 릴리즈 페이지에 ZIP 없음** → git clone만 가능.
2. **godot-ai 헤드리스 자동 등록 불가** → GUI 도크 Configure 사용자 위임.
3. **mcpollinations 무료 모델 한도** → 자주 다운타임. 폴백은 패키지가 자동 처리.
4. **autoload 테스트 격리 누락** → before_each()에서 명시 리셋.
5. **`patch` 도구가 `[display]">"` 같은 깨진 라인 생성 가능** → project.godot 수정 후 `head -3` 검증. write_file로 전체 재작성이 가장 안전.
