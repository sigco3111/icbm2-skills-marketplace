# Godot 4 macOS .app Export Pitfalls (2026-07-16 last-banner v2 실전)

> Godot 4.7 macOS `.app` 빌드는 Web export와 함정이 완전히 다릅니다. **Web export는 indexed/ccz 압축 패턴에 매몰**되어 있고, **macOS export는 시스템 통합(번들 ID/서명/ETC2)**에 매몰되어 있음.

## 0. 빠르게 부팅하는 5단계

```bash
# 1) export 템플릿 받기 (1.3GB zip → 풀면 web/macOS/windows/linux 다 들어있음)
curl -fsSL -o /tmp/godot-templates.tpz \
  "https://github.com/godotengine/godot/releases/download/4.7.1-stable/Godot_v4.7.1-stable_export_templates.tpz"
cd /tmp
unzip -j godot-templates.tpz "templates/macos.zip" \
  -d "/Users/mac/Library/Application Support/Godot/export_templates/4.7.1.stable/"

# 2) project.godot에 ETC2 ASTC 활성화
#    [rendering]
#    textures/vram_compression/import_etc2_astc=true

# 3) export_presets.cfg 작성 (텍스트로 — 사용자 편집기 안 거치고 CLI export 가능)

# 4) 빌드
cd /Users/mac/work/<project>
mkdir -p build/macos
godot --headless --export-release macOS
# → build/macos/<AppName>.app

# 5) 실행 (헤드리스에서는 GUI 세션 없으면 즉시 종료 — 사용자 데스크탑에서)
open "build/macos/<AppName>.app"
```

## 1. macOS export templates 받기 (가장 자주 막히는 곳)

### 문제
```
ERROR: Cannot export project with preset "macOS" due to configuration errors:
예상된 경로에서 찾은 내보내기 템플릿이 없습니다:
/Users/mac/Library/Application Support/Godot/export_templates/4.7.1.stable/macos.zip
```

Godot 4 자체에는 macOS export 템플릿이 **포함돼있지 않다**. `<Godot 설치>/share/godot/...`에도 없음. 별도 다운로드.

### 해결

**Godot이 기대하는 위치**:
```
~/Library/Application Support/Godot/export_templates/<version>.stable/
├── macos.zip                        ← 핵심
├── windows.zip
├── linux.zip
├── web_*.zip
└── ...
```

**다운로드 URL (Godot 4.7)**:
```
https://github.com/godotengine/godot/releases/download/4.7.1-stable/Godot_v4.7.1-stable_export_templates.tpz
```

다른 버전은 `4.6.2-stable`, `4.5.3-stable` 등으로 치환. GitHub Releases에 보면 zip 이름이 `Godot_v<버전>-stable_export_templates.tpz` 형식.

### 함정: zip 안의 `templates/` 중첩 폴더

`.tpz` (zip) 압축 시 내부 구조:
```
Godot_v4.7.1-stable_export_templates.tpz
└── templates/                ← 하위 폴더
    ├── macos.zip
    ├── windows.zip
    └── ...
```

`unzip`이 `templates/macos.zip`을 그대로 풀면 `templates/macos.zip` 경로가 생김 — Godot이 못 찾음. **`-j` 옵션으로 경로 박탈** + `templates/` prefix 지정:
```bash
unzip -j godot-templates.tpz "templates/macos.zip" \
  -d "/Users/mac/Library/Application Support/Godot/export_templates/4.7.1.stable/"
```

→ 결과: `~/.../4.7.1.stable/macos.zip` (Godot이 기대하는 정확 위치)

### 자동화 스크립트 (재실행 안전)

```bash
#!/usr/bin/env bash
set -e
TPL_BASE="$HOME/Library/Application Support/Godot/export_templates"
GODOT_VER="4.7.1.stable"
TPL_DIR="$TPL_BASE/$GODOT_VER"
mkdir -p "$TPL_DIR"

if [ ! -f "$TPL_DIR/macos.zip" ]; then
  TMPDIR=$(mktemp -d)
  curl -fsSL -o "$TMPDIR/godot.tpz" \
    "https://github.com/godotengine/godot/releases/download/4.7.1-stable/Godot_v4.7.1-stable_export_templates.tpz"
  unzip -j "$TMPDIR/godot.tpz" "templates/macos.zip" -d "$TPL_DIR/"
  rm -rf "$TMPDIR"
  echo "→ macos.zip 설치 완료"
fi
```

## 2. ETC2 ASTC 미활성화 함정

### 증상
```
ETC2 ASTC 텍스처 형식이 비활성화된 경우 universal 또는 arm64용으로
내보낼 수 없습니다. 프로젝트 설정(렌더링 > 텍스처 > VRAM 압축 >
ETC2 ASTC 가져오기)에서 이를 활성화하세요.
```

### 원인
Godot 4.7의 macOS export는 mobile-class GPU(Apple Silicon 통합 GPU 포함)를 타겟으로 **ETC2 ASTC 압축 텍스처 사용**. 이것이 비활성화돼 있으면 universal/arm64 export 거부.

### 해결 — project.godot에 한 줄
```ini
[rendering]
renderer/rendering_method="forward_plus"
textures/vram_compression/import_etc2_astc=true   # ← 추가
```

**꼭 `[rendering]` 섹션 안**에 두기. 다른 섹션은 무시됨.

## 3. bundle_identifier 누락

### 증상
```
ERROR: Cannot export project with preset "macOS" due to configuration errors:
잘못된 번들 식별자: 식별자가 누락되어 있습니다.
경고: 공증이 비활성화되어 있습니다...
코드 서명: ad-hoc 서명을 사용 중입니다...
```

`export_presets.cfg`에 `bundle_identifier` 없으면 실패. `unique_name`은 있는데 `bundle_identifier` 없으면 export 거부. **두 개는 별개**.

### 해결 — preset에 둘 다

```ini
[preset.0.options]
application/unique_name="org.godotengine.<projectname>"
application/bundle_identifier="org.godotengine.<projectname>"   # ← 필수
application/min_macos_version_arm64="11.0"
application/min_macos_version_x86_64="11.0"
application/min_macos_version="11.0"
application/embedded_bundle_icons=true
codesign/enable=false    # ad-hoc 서명으로도 export는 됨 (Gatekeeper 경고만)
```

⚠️ **Gatekeeper 차단**: ad-hoc 서명된 .app은 다른 사용자가 다운로드해서 열 때 Gatekeeper에 막힘. 로컬 본인 사용은 OK.

## 4. export_presets.cfg 보일러플레이트 (Web 없이 macOS만)

Web export preset을 빼고 macOS 하나만 둘 때:

```ini
[preset.0]

name="macOS"
platform="macOS"
runnable=true
advanced_options=false
dedicated_server=false
custom_features=""
export_filter="all_resources"
include_filter=""
exclude_filter=""
export_path="build/macos/<AppName>.app"
encryption_include_filters=""
encryption_exclude_filters=""
encrypt_pck=false
encrypt_directory=false
script_export_mode=2

[preset.0.options]

custom_template/debug=""
custom_template/release=""
debug/export_console_wrapper=1
binary_format/embed_pck=false                 # pck는 Resources/ 디렉터리에 따로
texture_format/s3tc_bptc=true
texture_format/etc2_astc=true                 # 1번 함정 해결 후 활성화됨
binary_format/architecture="universal"
codesign/enable=false
codesign/identity=""
codesign/certificate_file=""
codesign/certificate_password=""
codesign/notarization/enable=false
codesign/notarization/apple_team_id=""
codesign/notarization/api_key_id=""
codesign/notarization/api_key=""
codesign/notarization/api_key_path=""
codesign/entitlements/enable=false
codesign/entitlements/entitlements_file=""
codesign/custom_options=""
application/min_macos_version_arm64="11.0"
application/min_macos_version_x86_64="11.0"
application/icon=""
application/embedded_bundle_icons=true
application/icon_interpolation=4
application/file_version=""
application/short_version=""
application/unique_name="org.godotengine.<projectname>"
application/bundle_identifier="org.godotengine.<projectname>"
application/profiler/enable=false
application/high_res_icon=""
application/app_store_id=""
application/copyright=""
application/category="Games"
application/min_macos_version="11.0"
```

`bool` 값은 반드시 **소문자** (`true` / `false`). `True` / `False` 들어가면 파스 에러.

## 5. CLI Export + 헤드리스 부팅 검증

```bash
cd /Users/mac/work/<project>
mkdir -p build/macos
godot --headless --export-release macOS
# → "[ DONE ] savepack" → "[ DONE ] export" 나오면 OK
```

`.app` 구조:
```
build/macos/<AppName>.app/
├── Contents/
│   ├── MacOS/<AppName>            ← 네이티브 binary
│   ├── Resources/<AppName>.pck    ← 모든 스크립트 + 임포트 자원
│   ├── Resources/icon.icns
│   ├── Resources/PrivacyInfo.xcprivacy
│   ├── Info.plist                 ← bundle_id 포함
│   ├── PkgInfo
│   └── _CodeSignature/            ← ad-hoc 서명 결과
```

**pck 사이즈 = 임포트된 자원 + .gd/.tscn**. 393 PNG + 8 autoload + 1 main.tscn이면 160~170 MB. 대부분 자산.

## 6. 헤드리스 환경에서 .app 시각 검증 한계

`open "..."` 또는 `./<AppName>` 직접 실행 시 **GUI 세션이 없는 헤드리스 환경**에선 윈도우 생성 실패로 즉시 종료. stderr가 비어있고 exit 0 또는 -1로 짧게 끝남.

**사용자 데스크탑에서 더블클릭 권장**:
- 본 세션처럼 헤드리스 검증은 `LB_VERIFY=1 godot --headless`로 자동 진행/결정 큐/저장 라운드트립으로 대체
- 마지막 시각 확인은 사용자 본인

## 7. .app이 Gatekeeper에 차단될 때

`open "<AppName>.app` 시 macOS가 "확인되지 않은 개발자" 경고.

**해결 A** (1회성):
```
시스템 설정 → 개인 정보 보호 및 보안 → "그래도 열기"
```

**해결 B** (CI/스크립트):
```bash
xattr -cr "/path/to/<AppName>.app"   # quarantine 속성 제거
open "/path/to/<AppName>.app"
```

**해결 C** (codesign + notarization):
Apple Developer Program 가입 후 진짜 인증서로 서명. $99/년.

로컬 개발 단계에서는 A 또는 B로 충분.

## 8. .app 사이즈 분석

```bash
du -sh "build/macos/<AppName>.app/Contents/Resources"   # pck + icon
du -sh "build/macos/<AppName>.app/Contents/MacOS/<AppName>"  # binary (보통 30~50MB)
```

`pck`가 큰 게 정상 (자원이 다 거기 들어감). build/web/inject-debug-pane.sh 같은 Web 도구는 macOS에선 **불필요**.
