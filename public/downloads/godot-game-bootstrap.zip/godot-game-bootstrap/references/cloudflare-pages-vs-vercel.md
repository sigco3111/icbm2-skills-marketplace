# Godot 4 Web 배포 호스팅 결정 — Vercel (lazy fetch) vs Cloudflare Pages

Godot 4 Web export (`index.pck` ~200MB)를 어디에 띄울지. **2026-07 업데이트**: lazy fetch 패턴으로 Vercel 무료도 가능해져서 단순 단정이 아님.

## 결정 표 (2026-07 업데이트)

| 기준 | Vercel (lazy fetch) | Cloudflare Pages (대용량) | GitHub Pages |
|---|---|---|---|
| 단일 파일 한계 | 100MB (pck ~500KB로 우회) | 25MB 단위 / 총량 무제한 | 100MB |
| 총량 한계 | 100GB | **무제한** | 1GB/repo |
| CDN | Edge | 300+ PoP | GitHub Edge |
| 커스텀 헤더 | JSON vercel.json | `_headers` 파일 | HTML meta |
| PWA Service Worker | O | O | O |
| 빌드 시간 | ~30s | ~3min (free) | ~3min |
| 무료 | O | O | O |
| 자동 HTTPS | O | O | O |
| **사용자 진입 첫 로드 시간** | **즉시** (스크립트만 ~500KB) + 자산 백그라운드 30~60초 | 즉시 (전체 받음 10~30초) | 좌동 |
| **모바일 UX** | 좋음 (작은 초기 로드) | 좋음 (PWA 캐시 후 즉시) | 좋음 |
| 구현 복잡도 | **높음** (lazy fetch 코드 + CDN/매니페스트) | **낮음** (대시보드 import만) | 보통 |

## 2026-07 결정 — Last Banner 실전

Last Banner는 **Vercel + lazy fetch** 채택:

- pck 207MB → **501KB** (lazy fetch 덕분)
- 자산 228MB는 jsDelivr CDN (`cdn.jsdelivr.net/gh/sigco3111/last-banner@main/assets`)
- 런타임 fetch + `user://persistent/assets/` IndexedDB 캐시
- 라이브 URL: **https://last-banner.vercel.app**

채택 이유: 사용자(희정님)가 Vercel 선호 + PC 접근 어려움 → 모바일 진입 최적화. lazy fetch로 첫 로드 <1MB라 모바일에서 즉시 보임.

다른 선택:
- **가장 단순**: Cloudflare Pages (대용량 자산 그대로 빌드, wrangler 없이 대시보드 import)
- **가장 무료**: Vercel (lazy fetch만 구현하면)
- **가장 Pro**: Vercel Pro $20/월 (그냥 `vercel --prod`, 끝)

## Cloudflare Pages 셋업 (lazy fetch 없이)

GitHub repo 있으므로 대시보드에서 직접 import:

1. https://dash.cloudflare.com → **Workers & Pages** → Create application → **Pages** → Connect to Git
2. GitHub repo `sigco3111/last-banner` 선택
3. Build settings:
   - Framework preset: **None**
   - Build command: `bash tools/build.sh web`
   - Build output directory: `build/web`
4. **Save and Deploy** → 3~5분 후 `https://<project-name>.pages.dev` 자동 발급

`wrangler` CLI는 로컬 검증용일 뿐 없어도 됨.

## 필수 repo 파일 2개 (Cloudflare)

**1. `wrangler.toml` (Cloudflare 빌드 설정)**:
```toml
[build]
command = "bash tools/build.sh web"
destination = "build/web"

[build.environment]
NODE_VERSION = "22"
```

**2. `_headers` (Cross-Origin Isolation + 캐싱)**:

Cloudflare Pages는 이 파일을 **자동 인식**. repo 루트 또는 output 디렉터리 어디든 OK.

```
/*
  Cross-Origin-Opener-Policy: same-origin
  Cross-Origin-Embedder-Policy: require-corp
  Cross-Origin-Resource-Policy: same-origin

/*.wasm
  Cache-Control: public, max-age=31536000, immutable
  Content-Type: application/wasm

/*.pck
  Cache-Control: public, max-age=31536000, immutable

/*.js
  Cache-Control: public, max-age=31536000, immutable

/service-worker.js
  Service-Worker-Allowed: /
  Cache-Control: no-cache
```

> **3개 Cross-Origin 헤더 모두 필수**: Godot 4의 SharedArrayBuffer/wasm threading 활성화 요구.

**`build.sh`에서 `_headers` 자동 복사**:
```bash
echo "→ Web export..."
mkdir -p "$BUILD_DIR/web"
godot --headless --export-release "Web" "$BUILD_DIR/web/index.html" 2>&1 | tail -10
# Cloudflare Pages용 _headers 복사
[ -f "$LB_ROOT/_headers" ] && cp "$LB_ROOT/_headers" "$BUILD_DIR/web/_headers"
echo "✅ Web build: $BUILD_DIR/web/"
```

## Vercel (lazy fetch) 셋업

```bash
# 1. 자산 폴더에 .gdignore 생성 (Godot import만 차단, git 추적 유지)
for d in assets/*/; do touch "$d/.gdignore"; done

# 2. asset_host.json 자동 생성
bash tools/gen-asset-manifest.sh "https://cdn.jsdelivr.net/gh/<user>/<repo>@main/assets"

# 3. .gitignore에 build/web/ 예외 추가
echo "build/*" >> .gitignore
echo "!build/web/" >> .gitignore
echo "!build/web/**" >> .gitignore

# 4. vercel.json — outputDirectory만 (buildCommand는 PATCH API로 null 처리)
{
  "headers": [...],
  "outputDirectory": "build/web"
}

# 5. Vercel REST API로 첫 deploy 직후 buildCommand 비활성화
TOK=$(cat ~/.hermes/secrets/vercel_token.txt | tr -d '\n')
curl -X PATCH "https://api.vercel.com/v9/projects/<id>?teamId=<teamId>" \
  -H "Authorization: Bearer $TOK" \
  -H "Content-Type: application/json" \
  -d '{"buildCommand": null, "installCommand": null, "devCommand": null}'

# 6. 첫 빌드는 로컬에서 (Godot CLI 필요), build/web/ 푸시
cd ~/work/last-banner && bash tools/build.sh web
git add build/web/   # pck ~500KB는 OK
git commit -m "build/web/ 첫 빌드"
git push

# 7. 이후 푸시 시 Vercel 자동 배포 (build/web/은 변경분만)
export VERCEL_TOKEN=$(cat ~/.hermes/secrets/vercel_token.txt | tr -d '\n')
vercel --yes --prod --archive=tgz   # tgz 묶음으로 5,000 reqs 한도 우회
```

자세한 lazy fetch 구현 4단계 + 함정은 `references/lazy-fetch-via-cdn.md`.

## 모바일 확인 (어느 쪽이든)

둘 다 PWA로 설치 가능 + 모바일 진입 즉시:

- iPhone Safari → URL → 첫 로드 후 "홈 화면에 추가"
- Chrome Android → URL → 설치 배너 자동

자동 진행은 **브라우저 탭이 살아있을 때만**. 결정 큐는 IndexedDB(`user://`)에 영속화되어 다음 진입 시 처리.

## Cloudflare vs Vercel 요약

| 상황 | 추천 |
|---|---|
| 빠르게 1차 배포 (대용량 자산 OK) | Cloudflare Pages |
| Vercel 유지 + 무료 + 200MB+ 자산 | **Vercel + lazy fetch** |
| 모바일 초기 진입 최적화 (작은 첫 로드) | Vercel + lazy fetch |
| 가장 단순 셋업 (wrangler/git push 자동) | Cloudflare Pages |
| Pro 플랜 OK | Vercel |

## 결론

**Cloudflare는 가장 단순 (대량 자산 그대로), Vercel은 가장 무료 (lazy fetch 후)**. 두 옵션 다 같은 게임에 적용 가능. SE 가이드 (= godot-game-bootstrap SKILL)에서는 **lazy fetch를 1순위로 권장** — Vercel 무료 + 모바일 UX 최적 + 자동화 패턴.
