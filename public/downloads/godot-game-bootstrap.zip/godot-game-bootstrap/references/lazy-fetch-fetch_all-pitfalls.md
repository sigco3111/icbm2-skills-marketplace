# Lazy Fetch 함정 6종 — `.import` 404, Sequential Hang, Progress 표시, 시그널 미발생, 완료 조건 불일치, 사이즈 vs 파일 수

**핵심 lesson (2026-07-16 last-banner 실전)**: 자산 2510+ 파일을 lazy fetch로 받으려는데 **6가지 함정이 동시에 작용**해서 다운로드가 0%에 멈춘 것처럼 보임. 처음 3개만 고치면 진짜 0% 멈춤이 별도 3개로 다시 나타남.

---

## 함정 1: `.import`/`.uid` 메타파일이 매니페스트에 포함됨 → 매번 404

### 증상
- fetch_all을 호출했는데 status_label에 "자산 다운로드: 0.0/228.4 MB" 그대로
- 콘솔에 `HTTPRequest RESULT_SUCCESS, response_code=404` 연속 출력
- fetch_progress 시그널이 한 번도 emit 안 됨 (각 파일이 0KB라서)

### 원인
`gen-asset-manifest.sh`가 Godot의 import 시스템이 만든 **`.import` 파일까지 모두 매니페스트에 포함**:
```
files: [
  "audio/music/battle-epic.ogg",
  "audio/music/battle-epic.ogg.import",  # ← Godot이 만든 메타파일
  "audio/music/battle.ogg",
  ...
]
```

`battle-epic.ogg.import`는 Godot의 캐시 메타파일 (해시 + 의존성)이라 CDN에 존재하지 않음 → **매번 404** → 실패 처리. Godot이 fetch하면 안 되는 파일.

### 해결 — `_filter_real_files()`

```gdscript
# autoload/asset_registry.gd
func _filter_real_files(files: Array) -> Array:
    var result: Array = []
    for f in files:
        if typeof(f) != TYPE_STRING:
            continue
        if f.ends_with(".import"):
            continue
        if f.ends_with(".uid"):
            continue
        result.append(f)
    return result
```

`fetch_all`, `fetch_category` 둘 다 `_filter_real_files(cat.get("files", []))`로 필터링된 결과 사용. **manifest 자체를 재생성하지 말고 fetch 단에서 필터링** — manifest는 다른 도구(예: `gen-asset-manifest.sh`)에서도 쓰일 수 있으므로 원본 보존.

### 진단법
```bash
python3 -c "
import json
d = json.load(open('asset_host.json'))
total = 0; import_count = 0
for cat in d['categories'].values():
    for f in cat.get('files', []):
        total += 1
        if f.endswith('.import') or f.endswith('.uid'):
            import_count += 1
print(f'전체 {total}개 중 {import_count}개가 메타파일 → 실제 자산은 {total - import_count}개')
"
```

---

## 함정 2: Sequential fetch = 2510파일 순차 → 영원히 못 끝남

### 증상
- `.import` 필터링 후에도 1300+ 파일
- 한 번에 1개씩 `await` 기반 fetch → **RTT 누적**
- 진행률 거의 0%에서 멈춰 보임 (사용자: "프로그레스바가 있었으면 함")

### 원인
`fetch_all`의 첫 구현:
```gdscript
for rel_path in files:
    if _fetched.has(rel_path):
        continue
    _download_single(base_url, rel_path, progress_cb, total)
    # 다음 파일 시작은 이전 HTTPRequest의 request_completed 시그널에 의존
```

각 HTTPRequest가 직렬로 완료 → 한 사이클 = RTT × 1300. Web 환경 RTT 평균 100~300ms → **130~390초 = 2~6분**.

### 해결 — 동시 다운로드 (concurrency 4)

```gdscript
const FETCH_CONCURRENCY := 4  # 동시 다운로드 수 (너무 크면 CDN rate limit)

func fetch_all(progress_cb: Callable = Callable()) -> void:
    # 1) 큐 수집
    var queue: Array = []
    for cat_name in list_categories():
        var cat: Dictionary = get_category(cat_name)
        var files: Array = _filter_real_files(cat.get("files", []))
        var base_url: String = cat.get("base_url", get_base_url())
        for rel_path in files:
            queue.append({"url": "%s/%s" % [base_url, rel_path], "rel_path": rel_path})

    # 2) 이미 받은 건 카운트만
    var pending: Array = []
    for item in queue:
        if _fetched.has(item.rel_path):
            _loaded_bytes += get_file_size_estimate(item.rel_path)
        else:
            pending.append(item)
    if progress_cb.is_valid():
        progress_cb.call(_loaded_bytes, total)

    # 3) 동시 다운로드 시작 (최대 4개)
    var batch_size: int = min(FETCH_CONCURRENCY, pending.size())
    _fetch_active_count = 0
    for i in range(batch_size):
        if i < pending.size():
            _start_next_fetch(pending, i, progress_cb, total)

func _start_next_fetch(queue: Array, idx: int, progress_cb: Callable, total: int) -> void:
    if idx >= queue.size():
        return
    var item: Dictionary = queue[idx]
    _fetch_active_count += 1
    _download_single_async(item.url, item.rel_path, progress_cb, total, queue, idx)

func _download_single_async(url: String, rel_path: String, progress_cb: Callable, total: int, queue: Array, idx: int) -> void:
    var local_path := "user://persistent/assets/%s" % rel_path
    if FileAccess.file_exists(local_path):
        _fetched[rel_path] = local_path
        _loaded_bytes += get_file_size_estimate(item.rel_path)
        _on_one_done(progress_cb, total, queue, idx)
        return
    _in_progress[rel_path] = true
    var req := HTTPRequest.new()
    add_child(req)
    req.request_completed.connect(_on_async_done.bind(req, local_path, rel_path, progress_cb, total, queue, idx))
    req.request(url)

func _on_async_done(result, response_code, _headers, body, req, local_path, rel_path, progress_cb, total, queue, idx) -> void:
    req.queue_free()
    _in_progress.erase(rel_path)
    if result == HTTPRequest.RESULT_SUCCESS and response_code == 200:
        # ... 저장 ...
        _fetched[rel_path] = local_path
        _loaded_bytes += body.size()
        asset_fetched.emit(rel_path, local_path)
    if progress_cb.is_valid():
        progress_cb.call(_loaded_bytes, total)
    _on_one_done(progress_cb, total, queue, idx)

func _on_one_done(progress_cb: Callable, total: int, queue: Array, idx: int) -> void:
    _fetch_active_count -= 1
    var next_idx: int = idx + FETCH_CONCURRENCY
    if next_idx < queue.size():
        _start_next_fetch(queue, next_idx, progress_cb, total)
    elif _fetch_active_count <= 0:
        _maybe_all_done(progress_cb, total)
        all_assets_ready.emit()
```

**핵심 패턴**:
- 모든 파일을 큐에 수집
- `FETCH_CONCURRENCY`개 병렬 시작
- 각 완료 시 `idx + FETCH_CONCURRENCY`번째로 다음 시작 (rolling window)
- 모두 끝나면 `all_assets_ready.emit()`

**동시성 선택**:
- `FETCH_CONCURRENCY=2` — 안전 (CDN rate limit 회피)
- `FETCH_CONCURRENCY=4` — 일반적 최적 (Last Banner 채택)
- `FETCH_CONCURRENCY=8` — 공격적 (CDN 429 위험)

### 진단법
```bash
# 동시 fetch가 동작하는지 콘솔에 카운트
LB_VERIFY=1 godot --headless 2>&1 | grep -c "_in_progress"
# 4개 정도 떠야 정상 (FETCH_CONCURRENCY)
```

---

## 함정 3: ProgressBar 없음 + status_label만 → 사용자가 "멈춤" 인식

### 증상
- 사용자: "다운로드 프로그레스바가 있었으면 함"
- status_label만 업데이트하는데 라벨이 작거나 위치 안 좋아서 변화 못 느낌
- 토스트는 4번 정도 (25/50/75/100%) — 그 사이 진행 상황을 알 수 없음

### 해결 — ProgressBar + 가시 토스트

#### 1) main.tscn에 ProgressBar 추가
```
[node name="FetchProgress" type="ProgressBar" parent="UI"]
anchor_left = 0.15
anchor_top = 0.45
anchor_right = 0.85
anchor_bottom = 0.48
visible = false
max_value = 100.0
value = 0.0
show_percentage = true
```

#### 2) main.gd — ProgressBar 동적 갱신
```gdscript
@onready var fetch_progress: ProgressBar = $UI/FetchProgress

func _on_fetch_pressed() -> void:
    fetch_button.disabled = true
    if fetch_progress:
        fetch_progress.visible = true
        fetch_progress.value = 0
    AssetRegistry.fetch_all()  # 콜백 없이 — 시그널로

func _on_fetch_progress(loaded: int, total: int) -> void:
    var pct: float = 100.0 * float(loaded) / float(max(total, 1))
    if fetch_progress:
        fetch_progress.value = pct
    # 25/50/75% 마일스톤에서만 토스트 (너무 자주 안 뜨게)
    var cur_pct_int: int = int(pct)
    for milestone in [25, 50, 75, 100]:
        if cur_pct_int >= milestone and _last_fetch_pct < milestone:
            _show_toast("📦 자산 %d%% 다운로드 (%.1f/%.1f MB)" % [milestone, loaded/1024/1024, total/1024/1024])
    _last_fetch_pct = cur_pct_int
    # status_label도 갱신
    status_label.text = "자산 다운로드: %.1f / %.1f MB (%.0f%%)" % [...]

func _on_assets_ready() -> void:
    fetch_button.disabled = false
    if fetch_progress:
        fetch_progress.value = 100
        fetch_progress.visible = false
    _last_fetch_pct = 0  # 다음 fetch를 위해 리셋
```

**`_last_fetch_pct` 변수 선언 필수** (시그널마다 호출되므로 토스트 1회만 뜨게 비교 기준). `hasattr()`는 GDScript에 **없음** — 일반 `if has: ...` 패턴은 불가. 변수를 class member로 명시 선언:
```gdscript
var _last_fetch_pct: int = 0  # 시그널 마일스톤 토스트 중복 방지
```

#### 3) ProgressBar 위치
- `anchor_top=0.45, anchor_bottom=0.48` → status_label 바로 아래 (0.2~0.45 = status_label 영역)
- `show_percentage=true` → 0%~100% 숫자 자동 표시
- fetch 시작 시 `visible=true`, 완료 시 `visible=false`

---

## GDScript의 `hasattr()` 없음 — 변수 명시 선언

### 증상
```gdscript
# 파스 에러: Function "hasattr()" not found in base self.
if hasattr(self, "_last_fetch_pct"):
    last_pct = self._last_fetch_pct
```

### 해결 — 멤버 변수로 명시 선언
```gdscript
var _last_fetch_pct: int = 0  # 클래스 멤버로 선언

func _on_fetch_progress(loaded: int, total: int) -> void:
    var last_pct: int = _last_fetch_pct  # 직접 참조 (hasattr 불필요)
    # ...
    _last_fetch_pct = cur_pct_int
```

`hasattr`는 Python의 관용구. GDScript는 변수가 선언 안 됐으면 직접 에러 — 멤버 변수로 선언하면 항상 존재.

---

## 함정 4: `fetch_progress` 시그널이 콜백 안에서만 emit됨 (2026-07-16 발견)

위 3가지 함정(.import / sequential / ProgressBar 부재) 해결 후에도 **여전히 ProgressBar가 0%에서 멈춤**. 진짜 원인은 별개 3가지.

### 증상
- fetch_all이 0%에 멈춤. status_label 갱신은 되는데 ProgressBar.value 업데이트 안 됨.

### 원인
`fetch_all(progress_cb)` 시그니처에서 `fetch_progress.emit(...)`이 `if progress_cb.is_valid():` 분기 안에만 있음. 호출자가 콜백 안 넘기면 (`AssetRegistry.fetch_all()`) → `progress_cb`는 `Callable()` 디폴트 → `is_valid()` false → 시그널 미발생 → ProgressBar 갱신 0회.

```gdscript
# ❌ 시그널이 콜백 분기 안에만 — 호출자가 콜백 안 넘기면 emit 안 됨
func _on_async_done(..., progress_cb: Callable, total: int, ...):
    # ... fetch ...
    if progress_cb.is_valid():
        progress_cb.call(_loaded_bytes, total)
    # ← fetch_progress.emit 없음!
```

### 해결
**시그널은 항상 emit, 콜백은 옵션**. emit을 if 분기 밖으로:

```gdscript
# ✓ 시그널은 콜백과 독립적으로 emit
func _on_async_done(..., progress_cb: Callable, total: int, ...):
    # ... fetch ...
    if progress_cb.is_valid():
        progress_cb.call(_loaded_bytes, total)
    fetch_progress.emit(_loaded_bytes, total)  # ← 항상 emit
    _on_one_done(progress_cb, total, queue, idx)
```

**판단 기준**: Godot 4의 `Callable()` (디폴트 인자) 검증은 `is_valid()` false. 시그널 구독자가 있으면 emit은 필수, 콜백은 호출자 의도에 따라 옵션. **양쪽 다 emit하는 게 안전**.

---

## 함정 5: `_loaded_bytes >= total` 절대 만족 불가 → `all_assets_ready` emit 안 됨 (2026-07-16 발견)

### 증상
fetch_all은 100% 완료, 모든 파일 캐시되어 있는데 `_on_assets_ready` 핸들러는 안 불림. fetch_button이 disabled 상태로 영구.

### 원인
옛 경로 `_maybe_all_done(progress_cb, total)`이 `_loaded_bytes >= total` 체크. 하지만:
- `total` = `get_total_size()` = categories의 `size_bytes` 합 (import 포함 = 228MB)
- `_loaded_bytes` = 실제 받은 바이트 (import 제외 시 ~50%)

→ `_loaded_bytes >= total` 절대 만족 못 함 → `all_assets_ready.emit()` 미발생 → `_on_assets_ready` 미호출 → `fetch_button` 영영 disabled.

### 해결
`all_assets_ready.emit()`을 `_on_one_done`의 `_fetch_active_count <= 0` 체크에서 직접 호출. 사이즈 비교 회피.

```gdscript
func _on_one_done(progress_cb: Callable, queue: Array, idx: int) -> void:
    _fetch_active_count -= 1
    var next_idx: int = idx + FETCH_CONCURRENCY
    if next_idx < queue.size():
        _start_next_fetch(queue, next_idx, progress_cb, total)
    elif _fetch_active_count <= 0:
        # ← _loaded_bytes >= total 체크 제거, 직접 emit
        fetch_progress.emit(_fetch_done_files, _fetch_total_files, 100.0)
        all_assets_ready.emit()
```

---

## 함정 6: 진행률을 사이즈가 아닌 파일 수 기반으로 (2026-07-16 발견)

### 증상
`fetch_progress.emit(loaded, total)`이 사이즈(byte) 기반이라 `.import` 제외 후 `loaded_bytes`가 작게 잡혀서 진행률이 비정상적으로 낮음. 예: 50% 다운로드해도 ProgressBar는 22%.

### 원인
`get_file_size_estimate()`는 `categories/[cat]/sizes[rel]` dict를 찾는데, `.import` 제외한 키가 없으면 0 반환 → 누적 사이즈 0. 또 estimate가 부정확해도 누적합 부정확.

### 해결
**파일 수 기반 (`done/total` 형식)** — 사이즈 dict 의존성 제거, 단순 카운터.

```gdscript
var _fetch_total_files: int = 0
var _fetch_done_files: int = 0

func fetch_all(progress_cb: Callable = Callable()) -> void:
    _fetch_total_files = 0
    _fetch_done_files = 0
    # ... 큐 수집 ...
    _fetch_total_files = queue.size()
    # 시그널 emit
    fetch_progress.emit(_fetch_done_files, _fetch_total_files, _compute_pct())

func _compute_pct() -> float:
    return 100.0 * float(_fetch_done_files) / float(max(_fetch_total_files, 1))

# 시그널 시그니처: (done: int, total: int, pct: float)
# _on_async_done에서 실패도 _fetch_done_files += 1 (멈춤 방지)
```

**시그널 시그니처 변경 고려**: 기존 `(loaded: int, total: int)` → `(done: int, total: int, pct: float)`. 호출자/구독자 시그니처 일치 필수.

**장점**:
- 사이즈 dict 의존성 0
- `.import` 제외 여부 무관
- 실패도 진행률에 포함 (멈춤 방지)
- 직관적 (`42/1000 파일`)

---

## 6가지 함정 동시 작용 타임라인 (last-banner 2026-07-16)

| 시간 | 이벤트 | 사용자 인지 |
|---|---|---|
| 1차 fix | 2중 안전망 → fetch_button 활성화 | "버튼 눌렀는데 멈춤" |
| 2차 fix | `.import` 필터 + 동시 fetch + ProgressBar | "여전히 멈춤" |
| 3차 fix | 시그널을 콜백 밖으로 emit, 파일 수 기반 진행률, `_on_one_done` 직접 emit | 작동 |

**최종 교훈**: fetch_all을 작성할 때 **6가지 모두 한 번에 적용**:
1. `.import`/`.uid` 메타파일 제외 (`_filter_real_files`)
2. 동시 다운로드 (`FETCH_CONCURRENCY=4`)
3. ProgressBar 동적 갱신 + 가시 토스트
4. 시그널을 콜백과 독립적으로 emit (콜백 분기 밖)
5. 파일 수 기반 진행률 (`done/total`, `pct` 직접 계산)
6. `_on_one_done`의 `_fetch_active_count <= 0`에서 `all_assets_ready.emit()` 직접 호출 (사이즈 비교 회피)

## 권장 fetch_all 작성 순서 (한 번에 6가지 모두 적용)

1. **`_filter_real_files()` 함수 작성** — `.import`/`.uid` 제외
2. **동시 다운로드 (FETCH_CONCURRENCY=4)** — 큐 + rolling window
3. **ProgressBar 동적 갱신** — fetch_progress 시그널 + 25% 마일스톤 토스트
4. **시그널은 콜백과 독립적으로 emit** — `if progress_cb.is_valid():` 분기 밖에서 `fetch_progress.emit()`
5. **`_on_one_done`의 `_fetch_active_count <= 0`에서 직접 emit** — `all_assets_ready.emit()`
6. **파일 수 기반 진행률** — `_fetch_done_files / _fetch_total_files` 카운터
7. **`_last_fetch_pct` 멤버 변수 선언** (GDScript hasattr 없음)
8. **헤더리스 검증**: `LB_VERIFY=1 godot --headless 2>&1 | grep -E "fetch|매니페스트"`

Lazy fetch 패턴 전체 개요는 본 스킬의 `references/lazy-fetch-via-cdn.md` 참조.
