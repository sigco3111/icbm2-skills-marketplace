# 전투/오버레이 씬 패턴 — GameWorld.apply_result 통일 + race-free await (Last Banner v3.0 실전)

> 자동 진행 게임에서 **별도 씬 (전투, 인벤토리, 상점 등)**을 띄울 때 **`DecisionModal` 한 곳에서만 자원 변동 처리하지 말고**, GameWorld 모듈의 단일 dict에서 모든 결과 코드 → 자원 변동을 정의. + **주사위/애니메이션에 await + self-recursion 사용 금지**.

## 의도

자동 진행 게임에서 결정 큐 모달(`DecisionModal`) + 별도 씬(`BattleScene`, `ShopScene`, ...) 양쪽에서 같은 결과를 적용해야 함:
- HIGHLANDER 모달 → "출격" 클릭 → 전투 화면 (`BattleScene`) 진입 → 전투 결과 자원/명성 변동
- 인벤토리 씬 → "아이템 사용" → 효과 적용
- 모든 곳에서 **같은 코드 한 줄**로 자원 변동

**v2.3 이전**: 각 씬에서 `match result_code:` 직접 작성 → 일관성 깨짐 (결정 큐 모달과 전투 씬의 동일 결과 코드 작동 차이).

**v3.0 정답**: `GameWorld.apply_result(code, payload)` 단일 메서드. 데이터 모델에 정의 → 모든 씬에서 호출.

## 검증된 패턴 (Last Banner v3.0)

### GameWorld 모듈에 통합

```gdscript
# autoload/game_world.gd (데이터 모델 안에 적용 효과 dict)

const RESULT_EFFECTS := {
    "VISITOR_WELCOME":            { "gold": +30, "prosperity": +1, "log": "방문객 환영" },
    "VISITOR_REJECT":             { "prosperity": -2, "log": "방문객 거절" },
    "FOOD_BUY":                   { "gold": -50, "food": +30, "log": "식량 매입" },
    "FOOD_RATION":                { "prosperity": -5, "log": "건제 시행" },
    "DIPLOMACY_ALLIANCE_ACCEPT": { "gold": +50, "prosperity": +8, "log": "동맹 수락" },
    "DIPLOMACY_TRADE":            { "food": +30, "prosperity": +3, "log": "교역" },
    "DIPLOMACY_REFUSE":           { "prosperity": -5, "log": "외교 거절" },
    "BATTLE_BANDITS_HIDE":        { "log": "숨기 — 식량 손실" },
    "BATTLE_BANDITS_BRIBE":       { "gold": -30, "prosperity": -2, "log": "뇌물" },
}

func apply_result(result_code: String, _payload: Dictionary = {}) -> void:
    var effects: Dictionary = RESULT_EFFECTS.get(result_code, {})
    for resource_name in effects:
        if resource_name == "log":
            continue
        if effects[resource_name] is int:
            modify_resource(resource_name, int(effects[resource_name]))
    if effects.has("log"):
        log_event(effects["log"])
    print("[GameWorld] apply_result(%s) 적용" % result_code)
```

**key 설계 원칙**:
- dict 키 = 자원 이름 (`gold`, `food`, `prosperity`, ...)
- 값 = 변화량 (양수/음수)
- `"log": "..."` 특수 키 — 자원 변화 없지만 메시지만
- 새 result_code 추가 = `RESULT_EFFECTS` 한 줄만

### 모든 호출처

**결정 큐 모달** (`scripts/main.gd`의 `_apply_result`):
```gdscript
func _on_choice_pressed(choice: Dictionary) -> void:
    var result_code: String = choice.get("result", "")
    var decision_type: String = _current_decision_type()
    # BANDIT_RAID면 BattleScene로 라우팅
    if decision_type == "BANDIT_RAID" and result_code == "BATTLE_BANDITS_FIGHT":
        var battle: Control = _get_battle_scene()
        if battle:
            var enemy_count: int = int(_current_decision_payload().get("enemy_count", 4))
            battle.start_battle(enemy_count)   # 전투 화면 표시
    # 다른 결과는 GameWorld에 위임
    if result_code != "":
        GameWorld.apply_result(result_code)
    DecisionQueue.resolve(_current_decision_id, choice)
    _current_decision_id = -1
    if decision_modal:
        decision_modal.visible = false
```

**별도 씬** (`scripts/battle.gd`의 `_victory_now`):
```gdscript
func _victory_now(bonus: int) -> void:
    if result_label:
        result_label.text = "✅ 승리! ..."
    GameWorld.log_event("전투 승리 — 약탈자 퇴치 ...")  # 추가 컨텍스트
    GameWorld.apply_result("BATTLE_BANDITS_FIGHT", {})   # 자원 변동 위임
    await get_tree().create_timer(5.0).timeout
    _finish("FIGHT_WIN")
```

**어디서 호출해도 같은 결과** = 모달/BattleScene/상점 씬에서 일관성 자동 보장.

### 진짜 효과: 새 결과 코드 추가 시 1줄

새 결정 큐 `QUEST_COMPLETE` 추가 시:
```gdscript
# game_world.gd의 RESULT_EFFECTS dict에 한 줄 추가
"QUEST_COMPLETE": { "gold": +100, "prosperity": +5, "log": "퀘스트 완료" }

# 결정 큐에서 푸시할 때 result_code만 설정하면 끝
DecisionQueue.push("QUEST_COMPLETE", {
    "title": "의뢰 완료",
    "choices": [{ "result": "QUEST_COMPLETE" }]
}, DecisionQueue.Priority.LOW)

# 어느 씬에서 호출해도 자동 적용 — main.gd / battle.gd / shop.gd 수정 불필요
```

### _apply_result 모호성 회피

**main.gd의 기존 `_apply_result()`** (dict-based match)도 있으나 — **GameWorld.apply_result()로 단일화 권장**. 두 곳 모두 두고 **먼저 GameWorld로, 특수 케이스만 main.gd에 추가** 패턴:

```gdscript
# main.gd _on_choice_pressed
GameWorld.apply_result(result_code)  # 1순위: dict 단일 정의

# main.gd는 DecisionModal UI 토글 등 부수효과만 담당
if decision_modal: decision_modal.visible = false
```

새 효과 추가 = `RESULT_EFFECTS` 한 줄. **모든 씬에서 자동으로 작동**.

## race-free await 패턴 (Last Banner v3.0.1 — 주사위 시뮬)

### ❌ 안티패턴: await + self-recursion

```gdscript
# ❌ 버그: race condition, 재진입 호출 문제, hang 위험
func _roll_dice() -> void:
    if roll_count >= 3:
        _resolve_fight()
        return
    roll_count += 1
    var roll: int = randi() % 6 + 1
    rolls.append(roll)
    if dice_label:
        var dice_str := ""
        for r in rolls:
            dice_str += DICE_ICONS[r - 1] + " "
        dice_label.text = "🎲 " + dice_str
    await get_tree().create_timer(0.6).timeout
    _roll_dice()  # ← self-recursion: 타이밍 race risk
```

**문제**:
- await → 코루틴 suspension → 다음 프레임에 resume → _roll_dice() 재진입
- `roll_count`, `rolls` 등의 인스턴스 변수가 재진입 시점에도 정확한 값일지 의존
- 헤드리스 환경에서 `await` 누적은 hang 위험

### ✓ 정답 패턴: 한 함수에 for 루프 + 단일 await

```gdscript
# ✓ 검증된 패턴 — 주사위 굴림 + 결과 계산 동기
func _simulate_dice_sync() -> void:
    for i in range(3):
        var roll: int = randi() % 6 + 1
        rolls.append(roll)
        roll_count += 1
        _update_status("상태: 전투 진행 중 (%d/3)" % roll_count)
        # 중간 진행 표시 (UI 시각 효과)
    # 모든 굴림 완료 후 라벨 갱신
    if dice_label:
        var dice_str := ""
        for r in rolls:
            dice_str += DICE_ICONS[r - 1] + " "
        dice_label.text = "🎲 " + dice_str
    print("[Battle] 주사위 굴림 완료: %s" % str(rolls))
    # 결과 계산은 즉시 (await 없음)
    state = State.RESULT
    var bonus: int = sum_rolls()
    if allies_power + bonus >= enemies_power:
        _victory_now(bonus)   # async (5초 후 자동 종료)
    else:
        _defeat_now(bonus)    # async (5초 후 자동 종료)
```

**원칙**:
- 한 함수 = 한 `await` (또는 0개)
- 여러 단계 필요하면 **for 루프 + 단일 await** (마지막 단계 또는 표시 갱신)
- 재진입 함수 호출로 인한 인스턴스 상태 race 회피

### 검증된 사용 패턴 3종 (Last Banner v3)

**패턴 A — 동기 계산 + 단일 마지막 await**:
```gdscript
func _victory_now(bonus: int) -> void:
    # ... 동기 계산 / UI 갱신 / 자원 변동 ...
    # 5초 후 자동 종료만 await
    await get_tree().create_timer(5.0).timeout
    _finish("FIGHT_WIN")
```

**패턴 B — 단계별 표시 + 중간 await**:
```gdscript
func _simulate_dice_sync() -> void:
    for i in range(3):
        _single_roll_animation(i)
        # i < 2 (마지막 아님)일 때만 await
        if i < 2:
            await get_tree().create_timer(0.6).timeout
    # for 루프 종료 후 즉시 결과 계산
    _resolve_fight()
```

**패턴 C — 결정 후 자동 종료 (이중 safety)**: 
```gdscript
func _finish(outcome: String) -> void:
    state = State.DECISION
    if choices_row: choices_row.visible = true
    emit_signal("battle_finished", outcome)
    await get_tree().create_timer(2.0).timeout
    if visible:
        visible = false  # 이중 safety: 사용자 안 닫았으면 종료
        print("[Battle] 7초 후 자동 종료 (outcome=%s)" % outcome)
```

## 권장 적용 게임

| 게임 | 별도 씬 | 적용 |
|---|---|---|
| 자동 진행 로그라이크 (Last Banner) | `BattleScene`, `ShopScene`, `InventoryScene`, `QuestScene` | 결정 큐 결과 코드 통일 |
| 인큐베이터 (Cookie Clicker 류) | `UpgradeScene`, `PrestigeScene` | 단일 효과 dict |
| 턴제 RPG | `BattleScene`, `DialogScene` | 결정 큐 → 효과 |
| 카드 게임 (Slay the Spire 류) | `DraftScene`, `RewardScene` | 카드 효과 통합 |

**공통**: 모든 결정 → 한 곳에서 처리 = `GameWorld.apply_result(code)` 1줄. 씬/모달/대화창 일관성 자동.

## 권장 워크플로 (새 결과 코드 추가)

```gdscript
# 1. GameWorld.RESULT_EFFECTS dict에 한 줄 추가
# 2. 결정 큐 push — choices 배열의 result 필드에 코드만 매칭
# 3. (선택) 별도 씬이 있으면 그 씬에서 GameWorld.apply_result(code) 호출
# 4. LB_VERIFY에 [N] 검증 추가 — payload 검증
```

새 효과를 모듈 dict 정의로 누락 방지. **각 씬/모달에서 match/match/match로 흩어져 있으면 누락 → 테스트로 잡기 어려움. 단일 dict는 grep으로 1줄 검색으로 누락 즉시 확인 가능**.

## 핵심 함정

| 함정 | 증상 | 해결 |
|---|---|---|
| 각 씬에 `match result_code` 흩어짐 | 새 결과 추가 시 일부 씬에서 작동 안 함 | GameWorld 단일 dict |
| await + self-recursion | 재진입 race, hang 위험 | 한 함수 한 await 또는 단일 timer |
| `await get_tree().create_timer().timeout` 헤드리스 hang | LB_VERIFY hang | 동기 `_process(delta)` 직접 또는 동기 for 루프 |
| `result_code` 모달 vs 씬별 미스매치 | 새 씬에서 추가된 코드 다른 씬 미적용 | GameWorld.call_once 통합 |
| `payload` 안 받음 | payload에 적힌 값(예: enemy_count) 씬에서 못 읽음 | `apply_result(code, payload)` 시그니처 일관 |

## 검증된 LB_VERIFY 패턴

```gdscript
# [12.5] 전투 화면 검증 — GameWorld.apply_result 통합 시
print("[12.5] 전투 화면 검증")
var battle: Control = get_node_or_null("BattleScene") as Control
if battle:
    assert(battle.has_method("start_battle"))
    battle.start_battle(4)
    await get_tree().process_frame
    assert(battle.visible)
    var allies_count = battle.get_node("GridRow/AlliesCard/AlliesVBox/AlliesGrid").get_child_count()
    var enemies_count = battle.get_node("GridRow/EnemiesCard/EnemiesVBox/EnemiesGrid").get_child_count()
    assert(allies_count == 5)
    assert(enemies_count == 4)
    # GameWorld.apply_result 단일 정의 검증
    var gold_before = GameWorld.gold
    GameWorld.apply_result("DIPLOMACY_TRADE")
    assert(GameWorld.gold != gold_before, "단일 dict 효과가 자동 적용")
```

`apply_result` 단일 호출로 자원 변동 + 로그 + 이벤트 모두 발생 확인.

## 관련

- `references/canvaslayer-z-order-overlay-pitfall.md` — BattleScene 같이 별도 씬 띄울 때 CanvasLayer로 가시성 보장
- `references/manor-dashboard-screen-with-control-node2d.md` — Control > Node2D 그림 패턴
- `references/auto-progress-speed-tuning.md` — 자동 진행 속도, 결정 큐 분포
- `incremental-game-design-last-banner-event-engine/SKILL.md` — 8종 autoload 패턴 + 결정 큐 push/modify_resource 메서드
