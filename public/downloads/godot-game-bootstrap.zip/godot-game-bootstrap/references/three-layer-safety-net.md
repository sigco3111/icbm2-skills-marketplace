# 3중 안전망 패턴 — Godot Autoload + Web 환경 Race Condition

**핵심 lesson (2026-07-16)**: 2중 안전망(call_deferred + 즉시 체크)이 헤드리스에서는 작동하지만 **Web export에서는 여전히 실패할 수 있음**. 사용자가 "여전히 비활성"이라고 2회 보고한 후 3중 안전망으로 해결.

---

## 문제: 2중 안전망이 web에서 부족한 이유

**시나리오**: `AssetRegistry.manifest_loaded` 시그널이 main scene에서 `fetch_button`을 활성화해야 하는데, 사용자가 라이브에서 새로고침해도 비활성.

**헤드리스에서**: `print` 로그로 `_on_manifest_loaded`가 호출되는 것 확인 — 안전망 작동.
**Web에서**: 호출 안 됨 — 2중 안전망 실패.

**원인 추정**: `call_deferred`의 시점이 web export와 헤드리스에서 미묘하게 다름. 헤드리스에서는 autoload `_ready` → 즉시 `call_deferred` → main scene `_ready` (다음 프레임) → 안전망 체크 시점. Web에서는 main scene `_ready`가 같은 프레임에 실행되어 `call_deferred`가 main scene `_ready` **이전** 프레임에 emit될 가능성.

---

## 해결: 3중 안전망 패턴

```gdscript
# scripts/main.gd
func _ready() -> void:
    # ... 기타 연결 ...
    AssetRegistry.manifest_loaded.connect(_on_manifest_loaded)
    AssetRegistry.all_assets_ready.connect(_on_assets_ready)
    AssetRegistry.fetch_progress.connect(_on_fetch_progress)

    # 안전망 1: 즉시 체크 (autoload가 이미 emit했을 경우)
    if AssetRegistry.get_base_url() != "":
        _on_manifest_loaded()
    else:
        # 안전망 2: 다음 프레임 체크 (Web 환경에서 필요)
        call_deferred("_check_manifest_ready")
        # 안전망 3: 0.5초 타이머 (최후 수단)
        get_tree().create_timer(0.5).timeout.connect(_force_manifest_check)

func _check_manifest_ready() -> void:
    if AssetRegistry.get_base_url() != "":
        _on_manifest_loaded()

func _force_manifest_check() -> void:
    if AssetRegistry.get_base_url() != "":
        # status_label이 "Last Banner\n자산 매니페스트 OK"로 갱신 안 됐으면 강제
        if "Last Banner\n자산 매니페스트 OK" not in status_label.text:
            _on_manifest_loaded()
```

---

## 핵심 노드 동적 재검색 (안전망 내부)

`@onready var fetch_button: Button = $UI/ButtonRow/FetchButton`로 선언된 변수도, 안전망이 호출되는 시점에 null일 수 있음 (특히 `_ready`가 early return한 후). **모든 안전망 핸들러 내부에서 get_node_or_null로 재검색**:

```gdscript
func _on_manifest_loaded() -> void:
    if fetch_button == null:
        fetch_button = get_node_or_null("UI/ButtonRow/FetchButton")
    if fetch_button:
        fetch_button.disabled = false
    else:
        push_warning("[Main] fetch_button 노드 미발견")
```

`@onready`는 `_ready` return 직전에 평가되지만, 시점에 따라 null 가능. 안전망에서는 항상 재검색.

---

## 진단법 (3중 안전망 적용 후에도 실패할 때)

```bash
# stderr에 모든 메시지 캡처
LB_VERIFY=1 godot --headless 2>&1 > /tmp/out.txt; head -50 /tmp/out.txt

# 사용자 브라우저에서 콘솔(F12) → "[Main] 안전망" 메시지 검색
# 메시지가 없으면 시그널 자체가 emit 안 된 것
# 메시지가 있는데 버튼이 비활성이면 → 노드 동적 재검색 누락
```

`[Main] 안전망1(즉시)` / `[Main] 안전망: _on_manifest_loaded 호출 (버튼 활성화)` / `[Main] 강제: _on_manifest_loaded 호출 (status_label 미갱신 감지)` 중 어느 메시지가 보이는지 보고 어느 안전망이 작동했는지 식별.

---

## 적용 기준

- **2중 안전망으로 충분**: 헤드리스 테스트만 하는 경우, 단일 환경 (PC 또는 Web 한쪽)
- **3중 안전망 권장**: Web + 모바일 + 데스크탑 멀티 플랫폼, 또는 1차 시도 실패 후 사용자 보고 받았을 때

3중은 "과보호"가 아니라 **환경 차이를 흡수하는 보험**. 1줄 타이머 연결의 비용은 0에 가깝고, 사용자 frustration 1회 절약 효과가 큼.

---

## 참고: last-banner 자산 가져오기 버튼 3회 시도 타임라인 (2026-07-16)

| 시도 | 변경 | 결과 |
|---|---|---|
| 1차 | `if get_base_url() != "":` 즉시 안전망만 | 헤드리스 OK, 라이브 실패 |
| 2차 | `call_deferred("_check_manifest_ready")` 추가 (2중) | 헤드리스 OK, 라이브 **여전히 실패** |
| 3차 | `create_timer(0.5).timeout.connect(_force_manifest_check)` 추가 (3중) | 헤드리스 OK, **라이브 성공** |

사용자 1차 보고 → 1차 fix → 사용자 2차 보고 → 2차 fix → 사용자 3차 보고 → 3차 fix 후 성공. **3회 시도 끝에 안정화**는 autoload + web 환경의 일반적 패턴. 1차에서 3중을 적용했다면 사용자 frustration 2회 절약.
