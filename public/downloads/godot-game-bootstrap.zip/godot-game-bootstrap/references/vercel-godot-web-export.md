# Vercel + Godot 4 Web Export — 함정과 패턴

## 왜 필요한가

Godot 4의 Web export는 **WASM + SharedArrayBuffer + Threading**을 쓰는데, 브라우저는 보안상 COOP/COEP 헤더 없이는 `SharedArrayBuffer`를 비활성화한다. 헤더 없으면:

- 첫 로드 시 WASM 초기화 단계에서 멈춤 (콘솔에 `SharedArrayBuffer is not defined`)
- `pthread` 사용 불가 → 멀티스레드 코드 경로 fallback
- 자동 진행 백그라운드 (Service Worker) 작동 안 함

## Vercel 헤더 3종 (필수)

`vercel.json` `headers` 배열에 **3개 모두** 세팅:

```json
{
  "headers": [
    {
      "source": "/(.*)",
      "headers": [
        { "key": "Cross-Origin-Opener-Policy", "value": "same-origin" },
        { "key": "Cross-Origin-Embedder-Policy", "value": "require-corp" },
        { "key": "Cross-Origin-Resource-Policy", "value": "same-origin" }
      ]
    }
  ]
}
```

| 헤더 | 값 | 없으면 |
|---|---|---|
| `Cross-Origin-Opener-Policy` | `same-origin` | SharedArrayBuffer 차단 |
| `Cross-Origin-Embedder-Policy` | `require-corp` | 타 도메인 fetch 차단, 자체 자산만 가능 |
| `Cross-Origin-Resource-Policy` | `same-origin` | cross-origin 이미지/오디오 차단 |

## Godot export preset — 핵심 옵션

`export_presets.cfg` `[preset.N.options]` 안에서:

```
variant/thread_support=true       # 필수
variant/wasm_threads=true         # 필수 (없으면 pthread fallback)
variant/wasm_simd=true            # 권장 (성능)
vram_texture_compression/for_desktop=true
html/canvas_resize_policy=2       # FILL (반응형)

# PWA 활성화 시 — 자동 진행 백그라운드에 도움
progressive_web_app/enabled=true
progressive_web_app/ensure_cross_origin_isolation_headers=true   # vercel.json 헤더와 중복되지만 일관성 위해 true
progressive_web_app/icon_144x144="res://icons/icon-144.png"
progressive_web_app/icon_180x180="res://icons/icon-180.png"
progressive_web_app/icon_512x512="res://icons/icon-512.png"
```

## 캐시 헤더

`.wasm` `.pck` `.js` 파일은 **불변** — `Cache-Control: public, max-age=31536000, immutable`.

```
{
  "source": "/(.+\\.(wasm|pck|js))",
  "headers": [
    { "key": "Cache-Control", "value": "public, max-age=31536000, immutable" }
  ]
}
```

HTML은 짧게 — `no-cache` 또는 짧은 max-age.

## 디버깅 체크리스트

1. **첫 로드 멈춤** → 콘솔에 `SharedArrayBuffer is not defined` → 헤더 3종 확인.
2. **Service Worker 등록 안 됨** → `https://` 아니거나 경로 mismatch → manifest 위치 점검.
3. **WASM은 로드됐는데 검은 화면** → export preset에서 `runnable=true`인데 main scene 미설정 → `run/main_scene` 확인.
4. **결정 큐 저장 안 됨** → IndexedDB quota 초과 → 슬롯 정리 또는 자동 저장 간격 늘리기.
5. **자동 진행 안 됨** → `process_mode = PROCESS_MODE_ALWAYS` 누락.

## Vercel 배포 사이클

```bash
# 1. Web 빌드
bash tools/build.sh web      # build/web/index.html + *.wasm + *.pck + *.js

# 2. Vercel 배포
vercel --prod
# 또는
vercel --prod --token $(cat ~/.hermes/secrets/vercel_token.txt)

# 3. 검증
curl -I $(vercel alias)/index.html | grep -E "Cross-Origin|Cache"
```

## 함정

- **Vercel `outputDirectory`는 빌드 명령 출력이 아니라 디렉터리 경로**. `buildCommand` 먼저 실행 후 `outputDirectory`에서 픽업.
- **`Cache-Control` max-age를 HTML에 1년 걸면 업데이트가 안 보임**. index.html은 1시간, 자산은 1년으로 분리.
- **GitHub Pages로 옮길 때는 vercel.json 헤더 불필요**. GitHub Pages는 자체 COOP/COEP 헤더를 지원하지 않으므로 SharedArrayBuffer 활성화를 원하면 Cloudflare Workers 앞단에 배치 필요.
- **자체 호스팅 시 같은 헤더를 nginx/Caddy에 세팅**. Caddy 예시:
  ```
  header Cross-Origin-Opener-Policy "same-origin"
  header Cross-Origin-Embedder-Policy "require-corp"
  header Cross-Origin-Resource-Policy "same-origin"
  ```

## 다중 플랫폼 export 시 차이

| 플랫폼 | 헤더 필요 | Service Worker | IndexedDB | 장점 |
|---|---|---|---|---|
| **Web (Vercel)** | COOP/COEP 필수 | ✅ | ✅ | 모바일 진입, 자동 배포 |
| **macOS / Windows / Linux** | 불필요 | ❌ | ❌ | 풀 성능, 백그라운드 자동 진행 |

같은 코드 + 같은 `user://` 추상화로 양쪽 동일 코드 동작.
