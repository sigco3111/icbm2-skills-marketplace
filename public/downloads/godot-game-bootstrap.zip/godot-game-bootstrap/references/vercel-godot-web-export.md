# Vercel + Godot 4 Web Export — 함정과 패턴

## 왜 필요한가

Godot 4의 Web export는 **WASM + SharedArrayBuffer + Threading**을 쓰는데, 브라우저는 보안상 COOP/COEP 헤더 없이는 `SharedArrayBuffer`를 비활성화한다. 헤더 없으면:

- 첫 로드 시 WASM 초기화 단계에서 멈춤 (콘솔에 `SharedArrayBuffer is not defined`)
- `pthread` 사용 불가 → 멀티스레드 코드 경로 fallback
- 자동 진행 백그라운드 (Service Worker) 작동 안 함

## Vercel 헤더 3종 (필수)

`vercel.json` `headers` 배열에 **3개 모두** 세팅:

```json
{
  "headers": [
    {
      "source": "/(.*)",
      "headers": [
        { "key": "Cross-Origin-Opener-Policy", "value": "same-origin" },
        { "key": "Cross-Origin-Embedder-Policy", "value": "require-corp" },
        { "key": "Cross-Origin-Resource-Policy", "value": "same-origin" }
      ]
    }
  ]
}
```

| 헤더 | 값 | 없으면 |
|---|---|---|
| `Cross-Origin-Opener-Policy` | `same-origin` | SharedArrayBuffer 차단 |
| `Cross-Origin-Embedder-Policy` | `require-corp` | 타 도메인 fetch 차단, 자체 자산만 가능 |
| `Cross-Origin-Resource-Policy` | `same-origin` | cross-origin 이미지/오디오 차단 |

## Godot export preset — 핵심 옵션

`export_presets.cfg` `[preset.N.options]` 안에서:

```
variant/thread_support=true       # 필수
variant/wasm_threads=true         # 필수 (없으면 pthread fallback)
variant/wasm_simd=true            # 권장 (성능)
vram_texture_compression/for_desktop=true
html/canvas_resize_policy=2       # FILL (반응형)

# PWA 활성화 시 — 자동 진행 백그라운드에 도움
progressive_web_app/enabled=true
progressive_web_app/ensure_cross_origin_isolation_headers=true   # vercel.json 헤더와 중복되지만 일관성 위해 true
progressive_web_app/icon_144x144="res://icons/icon-144.png"
progressive_web_app/icon_180x180="res://icons/icon-180.png"
progressive_web_app/icon_512x512="res://icons/icon-512.png"
```

## 캐시 헤더 — pck/wasm은 **조건부 no-cache**가 안전 (2026-07-16 last-banner 교훈)

Godot 4의 `index.pck`는 **콘텐츠 해시가 파일명에 포함되지 않음** — `index.pck`라는 고정 이름으로 export됨. Vercel이 `immutable` 헤더로 캐시하면 **새 deploy의 pck가 절대 안 받음** — CDN/Vercel 캐시가 stale. 사용자 브라우저는 영원히 옛날 게임을 본다.

**해결 — 두 모드 분리**:

| 모드 | `.pck`/`.wasm`/`.js` 캐시 | 사용 시기 |
|---|---|---|
| **개발 중 (active dev)** | `no-cache, must-revalidate` | 새 deploy 빠르게 반영, 사용자 매번 새로고침 |
| **안정 release** | `immutable` (1년) | CI에서 Vercel 캐시 purge hook 또는 다른 파일명 강제 |

```json
{
  "source": "/(.+)\\.(wasm|pck|js)$",
  "headers": [
    { "key": "Cache-Control", "value": "no-cache, must-revalidate" }
  ]
}
```

**안정 release로 전환 시**: 파일명에 hash 추가 (`index.HASH.pck`) 또는 `vercel deploy --force` + Vercel 캐시 purge webhook. **단순한 회피책은 HTML만 캐시하고 pck는 항상 no-cache** — 첫 로드만 50ms 더 걸리고 사용자는 항상 최신 게임.

**함정**: 위 캐시 헤더를 처음에 `public, max-age=31536000, immutable`로 두면 사용자가 영원히 옛날 게임을 봄. 3회 deploy 후 사용자가 "여전히 안됨" → 결국 no-cache로 강제 변경한 교훈.

## 디버깅 체크리스트

1. **첫 로드 멈춤** → 콘솔에 `SharedArrayBuffer is not defined` → 헤더 3종 확인.
2. **Service Worker 등록 안 됨** → `https://` 아니거나 경로 mismatch → manifest 위치 점검.
3. **WASM은 로드됐는데 검은 화면** → export preset에서 `runnable=true`인데 main scene 미설정 → `run/main_scene` 확인.
4. **결정 큐 저장 안 됨** → IndexedDB quota 초과 → 슬롯 정리 또는 자동 저장 간격 늘리기.
5. **자동 진행 안 됨** → `process_mode = PROCESS_MODE_ALWAYS` 누락.
6. **새 deploy인데 사용자가 옛날 게임을 봄** → pck 캐시 헤더가 immutable인지 확인 (위 섹션).

## Vercel 배포 사이클

```bash
# 1. Web 빌드
bash tools/build.sh web      # build/web/index.html + *.wasm + *.pck + *.js

# 2. Vercel 배포
vercel --prod
# 또는
vercel --prod --token $(cat ~/.hermes/secrets/vercel_token.txt)

# 3. 검증
curl -I $(vercel alias)/index.html | grep -E "Cross-Origin|Cache"
```

## 함정

- **Vercel `outputDirectory`는 빌드 명령 출력이 아니라 디렉터리 경로**. `buildCommand` 먼저 실행 후 `outputDirectory`에서 픽업.
- **Godot의 pck는 콘텐츠 해시 미포함** — 위 캐시 헤더 섹션 참고.
- **GitHub Pages로 옮길 때는 vercel.json 헤더 불필요**. GitHub Pages는 자체 COOP/COEP 헤더를 지원하지 않으므로 SharedArrayBuffer 활성화를 원하면 Cloudflare Workers 앞단에 배치 필요.
- **자체 호스팅 시 같은 헤더를 nginx/Caddy에 세팅**. Caddy 예시:
  ```
  header Cross-Origin-Opener-Policy "same-origin"
  header Cross-Origin-Embedder-Policy "require-corp"
  header Cross-Origin-Resource-Policy "same-origin"
  ```

## 다중 플랫폼 export 시 차이

| 플랫폼 | 헤더 필요 | Service Worker | IndexedDB | 장점 |
|---|---|---|---|---|
| **Web (Vercel)** | COOP/COEP 필수 | ✅ | ✅ | 모바일 진입, 자동 배포 |
| **macOS / Windows / Linux** | 불필요 | ❌ | ❌ | 풀 성능, 백그라운드 자동 진행 |

같은 코드 + 같은 `user://` 추상화로 양쪽 동일 코드 동작.

## 사용자 디버깅 막힘 → 로컬 검증 워크플로 (2026-07-16 last-banner 교훈)

**상황**: 사용자가 "콘솔이 안 열림" 또는 "고도(固定) 페이지에서 F12 안 됨" 같은 말을 하면 **원격 진단은 한계**. Vercel에 `inject-debug-pane.sh`로 자동 진단 pane을 주입해도 사용자가 텍스트를 회신하지 않으면 정보가 안 들어옴.

**대응 — 즉시 로컬 헤드리스 검증으로 전환**:

```bash
# 사용자 PC에서 (사용자가 직접 실행할 수 있도록 안내)
cd ~/work/<game>
godot --path . --quit-after 30   # 30초 후 자동 종료, autoload print 전부 표시
```

`godot` CLI는 `brew install godot`로 설치된 로컬 Godot 4 — 헤드리스로 실행되며 **모든 print()가 stderr/stdout으로 출력**. 사용자가 직접 복사해서 회신 가능.

**헤드리스 출력 패턴**:
```
[GameManager] 부팅 완료
[AssetRegistry] 매니페스트 로드: base_url=...
[Main] 안전망1(즉시): _on_manifest_loaded 호출
[Main] fetch_button 활성화 완료 (228.4 MB)
[Main] 리소스 다운로드 완료 — fetch_button 다시 활성화
ERROR: Ogg Vorbis decoding failed
   at: load_from_buffer (...)
```

**이 패턴의 가치**:
- Vercel 배포 + 사용자 화면 + 콘솔 닫힘 = 3중 불가지 상황
- 로컬 `godot --path .` = 5분 안에 print 전부 확인 가능
- 사용자가 텍스트 복사 + 회신만 하면 → 진단 끝

**적용 트리거**: 사용자가 "콘솔 안 열림", "고도 페이지", "직접 확인", "방법을 바꿔", "여전히 안됨" 같은 표현을 2회 이상 쓰면 즉시 로컬 워크플로 안내. 더 이상 Vercel 진단 pane에만 의존하지 말 것.

## Godot 4 Web export — `await get_tree().create_timer().timeout` 시그널 콜백 함정 (2026-07-16 last-banner 교훈)

**증상**: 시그널 핸들러에서 `await get_tree().create_timer(0.5).timeout` 후 어떤 동작을 하면 **그 동작이 실행되지 않음**. 콘솔에 에러도 없음. 단순히 await 라인에서 흐름이 멈춤.

**원인 추정**: Godot 4의 시그널 emit → 핸들러 호출은 **시그널 emitter의 스레드**에서 실행. Web export에서 fetch_all의 `_on_request_done` 콜백은 **JS 비동기 컨텍스트** 안에서 실행되는데, `create_timer().timeout` 신호가 JS event loop에 제대로 등록 안 됨. 또는 timer가 시작되긴 했지만 그 안의 SceneTree 메인 루프가 시그널을 dispatch 못 함.

**증거 (last-banner)**:
```gdscript
# _on_assets_ready — 시그널 핸들러
func _on_assets_ready() -> void:
    # ... print, status, fetch_button ...
    if GameManager.current_state == GameManager.State.MENU:
        _show_toast("🎮 새 게임을 자동 시작합니다...")
        await get_tree().create_timer(0.5).timeout   # ← 이 라인에서 흐름 멈춤
        _on_start_pressed()                            # ← 실행 안 됨
```

`[Main] 리소스 다운로드 완료 — fetch_button 다시 활성화` print만 출력되고, 그 아래 코드는 실행 안 됨. 자동 새 게임 시작 안 됨 → 메뉴 그대로.

**로컬 헤드리스에서 100% 재현 가능** — `godot --path . --quit-after 30` 출력에서 명확:
```
[Main] 리소스 다운로드 완료 — fetch_button 다시 활성화
(아무것도 안 일어남)
```

**해결 — `call_deferred` 사용**:
```gdscript
func _on_assets_ready() -> void:
    if GameManager.current_state == GameManager.State.MENU:
        _show_toast("🎮 새 게임을 자동 시작합니다...")
        call_deferred("_on_start_pressed")    # ← await 대신
```

`call_deferred`는 Godot이 안정적으로 보장하는 다음 프레임 호출 메커니즘. 시그널 emitter 스레드와 무관. **`await`는 시그널 핸들러에서 거의 항상 위험** — 사용자 입력(`_on_button_pressed` 등)에서는 작동하지만 자동 fetch, 자동 저장, 백그라운드 워커에서는 hang 위험.

**판별법**: 로컬 `godot --path .`에서 **print 다음 라인이 안 나오면** await hang. `print` 진단 문을 await 직전/직후에 넣어 확인.

**대체 패턴 모음**:
- "N초 후 호출" → `get_tree().create_timer(N).timeout` (await) → **`call_deferred(메서드)` 또는 `await get_tree().process_frame` 1회**
- "다음 프레임에 실행" → `call_deferred(메서드)` (이게 표준)
- "시그널 안의 자동 동작" → **`call_deferred` 만 사용**, await 금지

**Web export가 아닌 macOS/Windows/Linux 데스크탑에서는 await이 정상 작동할 수도** — 차이는 Web export의 JS 비동기 환경. Web 빌드 검증 필수.
