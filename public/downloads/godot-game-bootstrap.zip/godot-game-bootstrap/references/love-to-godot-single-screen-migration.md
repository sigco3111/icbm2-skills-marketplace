# LÖVE → Godot 단일 화면 마이그레이션 (1단계 패턴)

2026-07-21 snkrx-clone → snkrx-godot v0.0.1 실전 검증. **LÖVE 게임을 Godot 4로 옮길 때 1개 화면 단위로 진행**하는 패턴.

## 핵심 통찰 — "LÖVE → Godot 풀 마이그레이션은 불가능, 단일 화면은 가능"

LÖVE 게임을 Godot으로 통째로 옮기는 건 비현실적이에요:

| 항목 | LÖVE | Godot 4 | 변환 비용 |
|---|---|---|---|
| API 표면 | `love.graphics.draw`, `love.physics`, `Group:enable_trigger_between` | `_draw()`, `RigidBody2D`, `Area2D + collision_layer/mask` | 1:1 매핑 없음 |
| 셰이더 | GLSL `.frag`/`.vert` 직접 | `ShaderMaterial` + `.gdshader` | 호환성 낮음 |
| 상태머신 | `Object:extend() + State` 직접 구현 | `SceneTree.change_scene_to_file` 또는 `State` 디자인 패턴 (별도 구현) | 직접 다시 짜야 함 |
| 타이머/코루틴 | `t:every(0.375, fn)` | `Timer` 노드 또는 `get_tree().create_timer` | 단순한 1:1 변환 가능 |
| 사운드 | `love.audio.newSource` + `Source:play` | `AudioStreamPlayer` + `.play()` | 1:1 매핑 |
| 입력 | `love.keyboard.isDown`, `love.mouse.isDown` | `Input.is_action_pressed`, `_input(event)` | 1:1 매핑 |

**결론**: 풀 마이그레이션 = **2~3개월 풀타임**. 한 세션에서 끝낼 수 있는 단위는 **단일 화면** (메인 메뉴, 상점, 옵션 등).

## 1단계 작업 정의 템플릿 — "메인 메뉴 1개 화면"

가장 단순한 LÖVE 게임 화면을 Godot으로 옮길 때 다음 순서로 진행하면 한 세션에 끝낼 수 있어요:

### 1. 작업 정의 (사용자 합의)

| 항목 | 정의 |
|---|---|
| 저장소 | 신규 `sigco3111/<game>-godot` |
| 화면 1개 | LÖVE의 `<screen>.lua` 1개 |
| 산출물 | Godot 4.3+ 프로젝트 + 메인 화면 1개 + 한글 + GitHub push |
| 제외 | 풀 게임 로직, 상점 화면, 게임 플레이, 사운드/셰이더, Release 배포 |

### 2. LÖVE 원본 분석

LÖVE 화면 1개를 분석할 때 확인할 5가지:

```lua
-- mainmenu.lua 예시 (snkrx-clone)
function MainMenu:on_enter(from)
  -- 초기화: wall, player, star_group, units 7개
  self.title_text = Text({{text = '[wavy_mid, fg]' .. T('snkrx_title', 'SNKRX'), ...}})
  self.arena_run_button = Button{...}  -- 좌상단 버튼들
  self.options_button = Button{...}
  self.quit_button = Button{...}
  self.soundtrack_button = Button{...}  -- 우하단 버튼들
  self.discord_button = Button{...}
end
```

- **버튼 위치** (LÖVE px 좌표 → Godot 비율 anchor)
- **한국어 키** (ko.lua에서 매핑되는 T() 호출 식별)
- **외부 링크** (`system.open_url` → `OS.shell_open`)
- **상태** (Lua 테이블 멤버)
- **사운드/이펙트** (이 단계에선 스텁으로 두고 print)

### 3. Godot 프로젝트 부트스트랩

`project.godot` 작성 시 결정사항:

| 옵션 | 권장 | 이유 |
|---|---|---|
| renderer | **gl_compatibility** | Vercel Web export 호환 + M4 Mac 안전 |
| viewport | 1280x720 | snkrx-clone 원본 동일 |
| main_scene | `res://scenes/main_menu.tscn` | 단일 화면 |
| features | `["4.3", "GL Compatibility"]` | Godot 4.3+ 검증 |

```ini
; project.godot
[application]
config/name="..."
run/main_scene="res://scenes/main_menu.tscn"
config/features=PackedStringArray("4.3", "GL Compatibility")

[display]
window/size/viewport_width=1280
window/size/viewport_height=720

[rendering]
renderer/rendering_method="gl_compatibility"
renderer/rendering_method.mobile="gl_compatibility"
```

### 4. 한국어 처리 — ko.lua → Godot Translation 이식

#### 옵션 A: `Translation` 리소스 (정석)

`lang/ko.godot_translation`:
```
[gd_resource type="Translation" format=3]
[resource]
locale="ko"
[translations]
arena_run="아레나 런"
options="옵션"
quit="종료"
buy_soundtrack="사운드트랙 구매!"
join_discord="커뮤니티 디스코드 가입!"
snkrx_title="SNKRX"
```

Godot 4.3+에서 `project.godot`에 추가 등록:
```ini
[internationalization]
locale/translations_pak=true
```

#### 옵션 B: 코드 직접 주입 (단순, v0.0.1 권장)

```gdscript
# main_menu.gd _ready()
title_label.text = "SNKRX"  # ← 직접 한글 주입
arena_btn.text = "아레나 런"
```

**옵션 B 권장 이유** (v0.0.1, v0.1):
- Translation 등록 + locale fallback 디버깅 안 해도 됨
- 6개 키면 코드에 박는 게 1줄 더 짧음
- v0.2+ 키가 84개 넘어가면 옵션 A로 마이그레이션

### 5. 씬 구조 — 단순 그리드 (anchor 회귀 회피)

**last-banner v4.0.1 회귀 교훈** (anchor_left/top 미명시 → 자식 사이즈 0)을 피하기 위해, v0.0.1에선 **anchor 사용 최소화 + `custom_minimum_size` + `size_flags_horizontal`** 패턴 사용:

```ini
; scenes/main_menu.tscn
[gd_scene load_steps=2 format=3]

[ext_resource type="Script" path="res://scripts/main_menu.gd" id="1_main_menu"]

[node name="MainMenu" type="Control"]
anchor_right = 1.0; anchor_bottom = 1.0
script = ExtResource("1_main_menu")

[node name="Background" type="ColorRect" parent="."]
anchor_right = 1.0; anchor_bottom = 1.0
color = Color(0.0784, 0.0902, 0.1098, 1)

[node name="VBoxContainer" type="VBoxContainer" parent="."]
anchor_left = 0.0; anchor_top = 0.05
anchor_right = 1.0; anchor_bottom = 0.25

[node name="TitleLabel" type="Label" parent="VBoxContainer"]
layout_mode = 2
text = "SNKRX"
horizontal_alignment = 1

[node name="HBoxContainer" type="HBoxContainer" parent="."]
anchor_left = 0.05; anchor_top = 0.5
anchor_right = 0.95; anchor_bottom = 0.95
alignment = 1

[node name="LeftButtons" type="VBoxContainer" parent="HBoxContainer"]
layout_mode = 2
size_flags_horizontal = 3
size_flags_vertical = 4

[node name="RightButtons" type="VBoxContainer" parent="HBoxContainer"]
layout_mode = 2
size_flags_horizontal = 3
size_flags_vertical = 8
alignment = 2
```

**핵심 회피 사항**:
- `anchor_left/top` 기본값 0에 의존하는 자식 컨테이너 금지 → 명시
- PanelContainer 자식 동적 추가는 v0.2+ 에서 (anchor 4개 명시 후)
- tscn 구조 변경 = 사용자 .app 빌드 검증 필수 (헤드리스는 layout 못 잡음)

### 6. GDScript — 버튼 생성기 + 핸들러 스텁

```gdscript
extends Control

const TITLE_FONT_SIZE := 72
const BUTTON_FONT_SIZE := 24

@onready var title_label: Label = $VBoxContainer/TitleLabel
@onready var left_buttons: VBoxContainer = $HBoxContainer/LeftButtons
@onready var right_buttons: VBoxContainer = $HBoxContainer/RightButtons


func _ready() -> void:
    title_label.text = "SNKRX"
    title_label.add_theme_font_size_override("font_size", TITLE_FONT_SIZE)

    # 좌측 3버튼
    left_buttons.add_child(_make_button("아레나 런", _on_arena_run_pressed))
    left_buttons.add_child(_make_button("옵션", _on_options_pressed))
    left_buttons.add_child(_make_button("종료", _on_quit_pressed))

    # 우측 2버튼
    right_buttons.add_child(_make_button("사운드트랙 구매!", _on_soundtrack_pressed))
    right_buttons.add_child(_make_button("커뮤니티 디스코드 가입!", _on_discord_pressed))


func _make_button(text: String, callback: Callable) -> Button:
    var btn := Button.new()
    btn.text = text
    btn.add_theme_font_size_override("font_size", BUTTON_FONT_SIZE)
    btn.custom_minimum_size = Vector2(320, 56)  # anchor 회피
    btn.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
    btn.pressed.connect(callback)
    return btn


# 핸들러 스텁 (v0.1+에서 실제 화면 연결)
func _on_arena_run_pressed() -> void:
    print("[main_menu] arena_run 클릭됨 — v0.1+ 에서 BuyScreen 연결")
    get_viewport().set_input_as_handled()


func _on_options_pressed() -> void:
    print("[main_menu] options 클릭됨")


func _on_quit_pressed() -> void:
    get_tree().quit()


func _on_soundtrack_pressed() -> void:
    OS.shell_open("https://kubbimusic.com/album/ember")


func _on_discord_pressed() -> void:
    OS.shell_open("https://discord.gg/4d6GWmChKY")
```

### 7. 헤드리스 검증 2단계

```bash
cd ~/work/<game>-godot

# 1단계: 임포트 + autoload/scene 파싱 검증
godot --headless --import 2>&1 | tail -20

# 2단계: 씬 로드 + 스크립트 컴파일 + main scene 진입
godot --headless --quit-after 1 scenes/main_menu.tscn 2>&1
echo "---EXIT $?---"
```

**EXIT 0 + stderr 깨끗** = 통과. 시각 검증은 사용자 .app 빌드 후 (snkrx-clone 메모리 §tscn 동적 변경 교훈).

### 8. GitHub push

```bash
git init
git add -A
git commit -m "v0.0.1: Godot 4 부트스트랩 + <screen> 1개 화면

- Godot 4.3+ 프로젝트 부트스트랩
- <screen> 씬 (<size> Korean buttons)
- 헤드리스 빌드 검증 통과
- 다음 단계 (v0.1+): ..."

gh repo create sigco3111/<game>-godot --public --description "..." --source=. --push
# 또는 수동 push
git push -u origin main
```

**Release 발행은 사용자 명시 요청 시에만** (snkrx-clone 메모리 §빌드→push 자동화 함정).

## 진행 매트릭스 — v0.0.1 ~ v0.5+ 단계

snkrx-clone 10000+ 줄 Lua → Godot 단계별 분할:

| 버전 | 화면 | LÖVE 줄 수 | Godot 작업량 | 외부위임 가능 |
|---|---|---|---|---|
| **v0.0.1** | 메인 메뉴 | 213 | 소 (1~2h) | ✅ 1세션 |
| v0.1 | BuyScreen (상점) | 2115 | 중 | ✅ 1세션 |
| v0.2 | Options (옵션) | ~300 | 소 | ✅ 1세션 |
| v0.3 | Arena (게임 플레이) | 1214 | 대 | ❌ 3~5세션 |
| v0.4 | Player (뱀 조종) | 4001 | **대** | ❌ 5~10세션 |
| v0.5 | Enemies (적 AI) | 1117 | 대 | ❌ 3~5세션 |
| v0.6+ | Objects + Shared + Main (엔진 코어) | ~3000 | 대 | ❌ 5~10세션 |
| v0.7+ | 셰이더 + 사운드 이식 | 다양 | 중 | ✅ 2세션 |
| v0.8+ | ko.lua 키 통합 (84+ keys) | - | 소 | ✅ 1세션 |
| v0.9+ | Vercel Web Export 검증 | - | 중 | ✅ 2세션 |
| v1.0 | 풀 게임 플레이 검증 | - | 대 | ❌ 5~10세션 |

**전체 작업량 추정**: 30~50 세션 = 풀타임 2~3개월. v0.0.1~v0.3까지만 해도 5~7세션 = 1~2주.

## 함정 — LÖVE → Godot 1:1 마이그레이션 시도 회피

### ❌ 자동 변환 툴 시도 금지

GitHub에 "LOVE → Godot converter" 같은 시도가 있지만:
- 완성도 낮음 (단순한 draw만 변환)
- `Group`, `State`, `Timer` 같은 snkrx-clone 코어 패턴 인식 못 함
- 셰이더 호환성 0%

### ❌ 풀 게임을 한 번에 Godot으로 옮기는 작업 지양

- 시간 2~3개월 + 중간 검증 어려움
- 기존 LÖVE 게임이 잘 굴러가면 위험 대비 가치 낮음

### ✅ 단일 화면 단위 + 사용자 검증 루프

- 각 v0.0.x마다 사용자 .app 빌드 + 스크린샷 회신
- LÖVE 원본과 비교하며 점진적 개선

## 다음 단계 권장 — v0.1 BuyScreen 진입 전

1. **v0.0.1 사용자 .app 빌드 검증** — `cd ~/work/snkrx-godot && godot --headless --export-release macOS` 후 사용자 데스크탑에서 실행 + 스크린샷
2. **anchor/size 회귀 확인** — 버튼이 정상 위치에 표시되는지
3. **v0.1 BuyScreen 포팅** — 2115줄 Lua → GDScript. UI 구조 + 유닛 슬롯 + 리롤 + 아이템 탭. 한 세션 작업.
4. **ko.lua → Godot Translation 마이그레이션** — 84+ 키 통합. 옵션 A (Translation 리소스) 적용.

## 관련 함정 (다른 레퍼런스에서)

- **anchor 4개 명시** — `references/godot4-native-2d-ui-pitfalls.md`
- **GL Compatibility 렌더러 + M4 Retina 호환** — `references/godot4-web-export-pitfalls.md`
- **헤드리스 부팅 검증 한계** — SKILL.md "macOS .app 시각 검증 — 헤드리스 환경 한계"
- **번역 리소스 등록** — SKILL.md "🤖 Godot MCP 통합" 섹션 (snkrx-clone v0.1.12 한글화 패턴과 연결)