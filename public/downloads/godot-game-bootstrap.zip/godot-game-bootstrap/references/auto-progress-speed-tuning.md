# 자동 진행 게임 속도 튜닝 — TimeManager SECONDS_PER_GAME_MINUTE 패턴

> 자동 진행 게임에서 사용자 직접 플레이 속도와 시뮬레이션 속도 분리. `real_sec → game_min` 비율 1개만 바꾸면 1분~24시간까지 즉시 전환 가능.

## 의도

`SECONDS_PER_GAME_MINUTE` 상수 하나로 **real time → game time 매핑**을 제어. 비율을 조정하면:

| 비율 | 1일 = ? real time | 의도 |
|---|---|---|
| 0.5초/분 | 12초 | 빠른 진행 (테스트) |
| 1초/30분 | 720초 (12분) | 적당 (v1 default) |
| **1초/60분** | **60초** | **빠른 시뮬레이션 (v2 권장)** |
| 2초/분 | 120초 (2분) | 1달 = 1시간, 적당 |

**게임 시간 의미는 동일** — `event_engine.gd`의 `*_INTERVAL_MIN` 상수는 게임 시간 분 단위. Real time만 빠르면 사용자 피드백 루프 빨라짐.

## 검증된 패턴 (Last Banner v2.1.1)

### TimeManager 단일 상수

```gdscript
# autoload/time_manager.gd
const SECONDS_PER_GAME_MINUTE := 1.0 / 60.0   # 1초 real = 60분 game (= 1시간)
const MINUTES_PER_HOUR := 60
const MINUTES_PER_DAY := 1440            # 24h
const DAYS_PER_MONTH := 30
const MONTHS_PER_YEAR := 12

func _process(delta: float) -> void:
    if not auto_progress_enabled:
        return
    if GameManager and not GameManager.is_playing():
        return
    if DecisionQueue and DecisionQueue.has_pending_critical():
        return
    _accumulator += delta
    while _accumulator >= SECONDS_PER_GAME_MINUTE:
        _accumulator -= SECONDS_PER_GAME_MINUTE
        advance_minutes(1)
```

### EventEngine interval (게임 시간 기준)

```gdscript
# 빠른 real time (1일 = 60초)에 맞춘 조정 (Last Banner v2.1.1)
const RECRUIT_VISITOR_INTERVAL_MIN := 1200  # 20시간마다 (= real 20초)
const FOOD_CHECK_INTERVAL_MIN := 2400        # 40시간마다 (= real 40초)
const DIPLOMACY_INTERVAL_MIN := 2400         # 40시간마다 (= real 40초)
const DECISION_MAX_PER_DAY := 8              # 빠른 진행에서 하루 cap 증가
```

핵심: `RECRUIT_VISITOR_INTERVAL_MIN`을 절대 줄이지 말 것. **1분(=real 1초)마다 방문객** push되면 사용자 미쳐 결정 못 함. 게임 시간 비율은 일정하게, real time 매핑만 빠르게.

### 속도 변경 시 권장 조정 공식

`Real_Per_Day = 86400 / SECONDS_PER_GAME_MINUTE / 60` (초 단위):
- 60초/일 (v2): `INTERVAL_MIN = real_second * 60` (40 real초 = 2400분 = 40시간 게임)
- 120초/일: `INTERVAL_MIN = real_second * 120` (40 real초 = 4800분 = 80시간 게임)

⇒ Real time 기준 동일 분포 = **게임 시간 interval을 real time에 맞춰 60~120배 늘림**.

## 헤드리스 검증 (LB_VERIFY [2.5] 단계)

```gdscript
# 정확한 비율 검증 — _process에 1.0 delta 주입 → 60분 advance 기대
print("[2.5] 속도 검증 — 1초 real = 60분 game (1.0 delta 주입)")
var min_before: int = TimeManager.minutes_elapsed
TimeManager._process(1.0)   # 1초 경과 시뮬
var min_after: int = TimeManager.minutes_elapsed
var advance_60: int = min_after - min_before
print("  1초 시뮬 후 진행 분: %d (기대 60)" % advance_60)
assert(advance_60 >= 55 and advance_60 <= 65, "속도 정확도: %d분 (60±5)" % advance_60)
```

핵심: **`await get_tree().create_timer(1.0).timeout`는 헤드리스에서 hang 위험**. 동기 `_process(delta)` 직접 호출이 헤드리스 안전.

## 권장 비율별 게임 케이스

| 게임 종류 | 비율 | 의도 |
|---|---|---|
| 자동 진행 로그라이크 (CK3/EU4) | 1초/60분 (1일 = 60초) | 빠른 시뮬 + 충분한 결정 큐 |
| 인디 게임 (짧은 세션) | 1초/30분 (1일 = 30초) | 더 빠른 진행 |
| 모바일 캐주얼 | 0.5초/분 (1일 = 12초) | 분 단위 플레이 |
| 시뮬레이션 게임 | 2초/분 (1일 = 2분) | 천천히 즐기기 |

## 결정 큐 cap 연동

빠른 real time → user가 미쳐 결정 → **day cap 증가**:

```
real/day = 60 (v2 default) → DECISION_MAX_PER_DAY = 8
real/day = 30 (빠른) → DECISION_MAX_PER_DAY = 12
real/day = 120 (느린) → DECISION_MAX_PER_DAY = 4
```

## auto_progress_enabled로 일시정지

`TimeManager.auto_progress_enabled = false` 시:
- `_process` 첫 줄 `return` — 시간 멈춤
- 결정 큐 모달이 떠있어도 자동 닫기 안 함 (`_on_auto_skip` 가드)
- **사용자 결정 때까지 무한 대기**

```gdscript
func _on_auto_skip() -> void:
    if not TimeManager.auto_progress_enabled:
        return  # OFF면 안 닫음 (사용자 결정 대기)
    # ON 모드 default 결정 처리...
```

## 적용 게임

- 자동 진행 로그라이크 (Last Banner, 슬레이 더 서바이벌)
- 시뮬레이션 게임 (Cities: Skyline 류)
- 인큐베이터 게임 (Cookie Clicker 류)
- 턴제 전략 (P 秒 단위 조정)

⇒ 모든 자동 진행 게임은 **real time + game time 매핑 상수 + interval 비율 조정 + LB_VERIFY 속도 검증** 4종 세트.

## 핵심 실패 모드

| 증상 | 원인 | 해결 |
|---|---|---|
| 게임 시간 그대로 + 실시간 배로 빠름 (e.g. 0.5초/분) | 사용자 미쳐 결정 못 함 | `INTERVAL_MIN`을 real time 비율에 맞춰 60~120배 확대 |
| AUTO 진행 너무 느려 식상함 | SECONDS_PER_GAME_MINUTE 너무 큼 | 0.5~1/60 권장 |
| 모달 자동 닫힘이 너무 빠름 | `get_tree().create_timer(3.0)` 안에 사용자 못 누름 | 우선순위별 차별화: LOW 3초 / MEDIUM+ 5초 |
| 결정 큐 누적 100건 | 일일 cap 없어 + 빠른 진행 | `DECISION_MAX_PER_DAY` 설정 |

---

## LB_VERIFY 진단 강화 (Last Banner v2.2~v3.0 실전)

`godot --headless --import` 또는 `LB_VERIFY=1 godot --headless`는 stderr에 `print()`를 출력하지만 **성능 진단에 한계**가 있음. 다음 패턴으로 LB_VERIFY 실패를 빠르게 격리.

### 진단 1: 헤드리스 `print`는 보이지만 `.app`이 응답 없을 때 — `godot --path .` 사용

`.app`이나 `open` 명령은 stderr를 **표시하지 않음**. 디버깅이 안 됨.

**대신 — Godot 에디터 셸에서 실행**:
```bash
cd ~/work/<game>
godot --path .
```

이 명령은 Godot 에디터 셸을 띄우면서 같은 main scene을 실행. **하단 출력 패널** (Ctrl+Shift+Y 또는 우하단)에 `print()` 출력 보임. 사용자가 모달 안 닫힘/클릭 안 됨 등 인터랙션 버그 디버깅할 때 **사용자 Mac 데스크탑에서 1회만 띄워달라고 위임**.

**Last Banner v3 사례**: `BattleScene`가 안 뜨는 문제 → `godot --path .` + 콘솔에 `[Main] _on_choice_pressed:` print 추가 → 어느 단계에서 끊겼는지 정확히 식별.

### 진단 2: `randf()` 게이트 때문에 LB_VERIFY가 flaky

`EventEngine._maybe_*()` 함수에는 항상 확률 게이트 존재:
```gdscript
func _maybe_bandit_raid(_game_time: int) -> void:
    if _decisions_today >= DECISION_MAX_PER_DAY: return
    if randf() > 0.4:   # 40% 확률 — LB_VERIFY에서 자주 skip
        return
    DecisionQueue.push("BANDIT_RAID", ...)
```

`randf()`가 시드 없이 호출되면 **런타임마다 70%는 fail**로 빠짐. LB_VERIFY가 1회는 pass하고 다음엔 fail하는 flaky 모드가 됨.

**해결 — LB_VERIFY에서 직접 `DecisionQueue.push()` 호출**:
```gdscript
# ❌ LB_VERIFY flaky: _maybe_*() 호출
EventEngine._maybe_bandit_raid(Time.get_ticks_msec())
# 70% 확률로 push 안 됨 → assert(diplomacy_count >= 1) 간헐적 fail

# ✓ LB_VERIFY 결정적: 직접 push (randf 게이트 우회)
DecisionQueue.push("BANDIT_RAID", {
    "title": "...",
    "description": "...",
    "enemy_count": 4,
    "choices": [...],
}, DecisionQueue.Priority.HIGH)
```

`_decisions_today = 0` (일일 cap 리셋) + randf 게이트 우회 + 결정적 결과.

**이벤트별 테스트 패턴**:
- `[8.5] DIPLOMACY 검증` → `DecisionQueue.push("DIPLOMACY", {...}, MEDIUM)` 직접
- `[10] BANDIT_RAID OFF 검증` → `DecisionQueue.push("TEST_OFF", {...}, MEDIUM)` + `TimeManager.auto_progress_enabled = false`
- `[11] 출격 검증` → `DecisionQueue.push("VISITOR", {...}, LOW)` 직접

### 진단 3: `_process(delta)` 직접 주입 vs `await create_timer().timeout`

`await get_tree().create_timer(N).timeout`는 헤드리스에서 hang 위험 (스킬 함수정 9: 누적 hang). LB_VERIFY에서 시간 검증 시:

```gdscript
# ❌ Hang 위험
print("1초 대기 후 진행 분 측정")
await get_tree().create_timer(1.0).timeout
var advance = TimeManager.minutes_elapsed - min_before

# ✓ 동기 _process 직접 호출
var min_before = TimeManager.minutes_elapsed
TimeManager._process(1.0)   # 1초 시뮬레이션 — 즉시 반환
var min_after = TimeManager.minutes_elapsed
var advance = min_after - min_before   # 60±5분
```

이 `_process(1.0)` 패턴이 [2.5] 속도 검증의 정답.
