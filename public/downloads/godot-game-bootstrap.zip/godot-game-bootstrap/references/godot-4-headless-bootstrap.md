# Godot 4 Headless Bootstrap — autoload + boot 검증

## 의도

Godot 4로 새 게임 프로젝트 부트스트랩 시 **빈 프로젝트 부터 autoload 5종 + 씬 1개까지 5분 안에** 검증된 형태로 만든다.

## 1단계: 디렉터리

```bash
mkdir -p ~/work/<game>/{autoload,scenes,scripts,assets,docs,export,tools}
```

## 2단계: project.godot 직접 작성

`godot` CLI는 빈 폴더에서 `project.godot` 자동으로 만들어주지 않는다. **반드시 `write_file`로 명시 생성**.

필수 필드:
- `config/name`, `config/features=PackedStringArray("4.7", "Forward Plus")`
- `run/main_scene="res://scenes/main.tscn"`
- `[autoload]` 5개 등록:
  ```
  GameManager="*res://autoload/game_manager.gd"
  TimeManager="*res://autoload/time_manager.gd"
  DecisionQueue="*res://autoload/decision_queue.gd"
  SaveManager="*res://autoload/save_manager.gd"
  AssetRegistry="*res://autoload/asset_registry.gd"
  ```
- `[web] threads_support=true`, `experimental_features=true`

## 3단계: autoload 5종 골격 작성

각 스크립트에 `process_mode = Node.PROCESS_MODE_ALWAYS` 잊지 말 것 — 메인 씬이 일시정지돼도 시계/큐는 계속 동작해야 함.

## 4단계: 메인 씬 (main.tscn)

`write_file`로 1KB 분량 .tscn 직접 가능 — UID 수동 생성 (`uid="uid://b<random12>"`).

```
[gd_scene load_steps=2 format=3 uid="uid://b<random>"]
[ext_resource type="Script" path="res://scripts/main.gd" id="1_main"]
[node name="Main" type="Node2D"]
script = ExtResource("1_main")
[node name="UI" type="CanvasLayer" parent="."]
... Label + Button + ColorRect
```

## 5단계: 헤드리스 부팅 검증 (필수)

```bash
godot --headless --import 2>&1 | tail -10        # 1~2분 걸림
godot --headless --quit-after 200 2>&1 | tail -40  # ~2초, autoload 파스 에러 잡기
```

`--quit-after N`은 N 프레임 후 종료 (헤드리스로 무한 루프 방지).

## 흔한 부팅 에러

### 1. `Cannot infer the type of "m" variable`

```gdscript
func summary() -> String:
    var lines: Array = [...]
    for cat in MANIFEST:
        var m := MANIFEST[cat]   # ← Dict 추론 실패 (상수가 Dict임이 추론 안 됨)
```

→ 명시 타입:
```gdscript
var m: Dictionary = MANIFEST[cat]
```

또는 unsafe access:
```gdscript
lines.append("  • %s — %s [%s]" % [cat, m.get("license", "?"), m.get("format", "?")])
```

### 2. `Failed to load script ... does not inherit from 'Node'`

→ 파스 에러로 autoload 등록 실패. 다른 autoload에서 `Nil.has_method(...)` 호출하면 동일 에러. **첫 에러 잡으면 후속 에러도 사라짐**.

### 3. `Failed loading scene: res://scenes/main.tscn`

→ .tscn 작성 시 UID나 ExtResource 경로 오타. 스크립트가 `/Users/mac/work/<game>/scripts/main.gd`에 있어야 함.

### 4. `Cannot open file ... user://save_default.json`

→ 새 게임 후 바로 저장할 때 user:// 디렉토리 자동 생성되지만 디스크 권한 문제 가능. `OS.get_user_data_dir()` 출력으로 확인.

## 6단계: 자산 import

```bash
godot --headless --import 2>&1 | tail -10
```

심볼릭 링크로 연결한 자산을 import. `.godot/imported/` 캐시 빌드. **1,700+ 자산이면 1~2분**.

## 7단계: 검증된 빌드 사이클

```bash
godot --headless --import       # import
godot --headless --quit-after 200  # autoload 검증 (2초)
bash tools/build.sh web         # 빌드 (asset 많으면 5분+)
```

## 함정 요약

| 증상 | 원인 | 해결 |
|---|---|---|
| 빈 폴더에서 `godot`만 실행해도 project.godot 없음 | Godot이 빈 프로젝트 만들어주지 않음 | `write_file`로 명시 생성 |
| autoload 파스 에러 → 모든 autoload Nil | 한 스크립트 오타 | 첫 에러 fix하면 cascade 사라짐 |
| import 단계에서 멈춤 | 손상된 asset (.png 등) | `godot --headless --quit` 후 손상 파일 제거 |
| Web 빌드는 성공했는데 첫 로드 멈춤 | COOP/COEP 헤더 없음 | vercel.json 헤더 추가 |
| `process_mode` 안 바꿈 → 메인 씬 정지 시 시계 멈춤 | — | 모든 autoload에 `PROCESS_MODE_ALWAYS` |
