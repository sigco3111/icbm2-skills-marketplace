# Godot 4 + Vercel Live Deployment Healthcheck

부트스트랩 직후 또는 CI/CD 후 배포된 게임이 정말로 살아있는지 확인하는 4축 검증. 모든 체크는 curl + Godot 헤드리스 부팅만 사용 → 외부 의존 0.

## 트리거 조건

- 부트스트랩 후 첫 deploy가 정상 도달했는지 확인
- "Vercel 200인데 게임이 안 보여요" 디버깅
- README에 라이브 URL 박기 전 sanity check
- 정기 헬스체크 (cron job에서 6시간마다)

## 4축 검증

### 축 1: HTML 응답 + COOP/COEP 헤더

```bash
curl -sI https://<domain>/ | grep -iE 'http|cross-origin|content-type'
```

**기대값**:
- `HTTP/2 200` 또는 `HTTP/1.1 200`
- `cross-origin-opener-policy: same-origin`
- `cross-origin-embedder-policy: require-corp`
- `cross-origin-resource-policy: same-origin`
- `content-type: text/html; charset=utf-8`

**실패 시**:
- 404 → 배포 미완료 또는 도메인 오타
- 200인데 COOP/COEP 없음 → `vercel.json` headers 누락, Vercel 캐시 응답일 수 있으니 `--no-cache`로 재시도
- 5xx → 빌드 실패 (Vercel 대시보드 logs 확인)

### 축 2: WASM/JS 정적 자산 응답

```bash
curl -sI https://<domain>/index.wasm | head -5
curl -sI https://<domain>/index.js | head -5
```

**기대값**: 둘 다 200, Content-Type 정확 (`application/wasm`, `application/javascript`).

**실패 시**:
- 404 → 빌드는 됐는데 export 산출물이 빠짐 (export_presets.cfg의 export_path 확인)
- Content-Type `application/octet-stream` → Vercel이 MIME 추측 실패, `_headers` 또는 `vercel.json` headers에 명시 필요

### 축 3: asset_host.json (lazy fetch용) shape 검증

```bash
curl -s https://<domain>/asset_host.json | python3 -c "
import json, sys
d = json.load(sys.stdin)
assert 'version' in d, 'no version'
assert 'base_url' in d, 'no base_url'
assert d['base_url'].startswith('http'), 'base_url not absolute'
print('OK:', d['base_url'], 'categories:', d.get('category_count'))
"
```

**기대값**: `version`, `base_url` (절대 URL), `category_count` 또는 `assets`/`urls` 키 존재.

**실패 시**:
- 404 → `build/web/asset_host.json`이 export에 포함 안 됨. `tools/build.sh web`가 명시적으로 cp 하는지 확인.
- 200인데 JSON parse 실패 → 손상. 빌드 로그 확인.

### 축 4: Godot 헤드리스 부팅 (autoload parse + 매니페스트 로드)

```bash
cd ~/work/<game>
godot --headless --quit-after 30 2>&1 | tail -5
```

**기대값**:
```
[GameManager] 부팅 완료
[AssetRegistry] 매니페스트 로드: base_url=https://..., N 카테고리
```

**실패 시**:
- GDScript parse 에러 출력 → autoload 스크립트 라인/함정 확인 (godot-game-bootstrap SKILL.md "Godot 4 import / autoload" 섹션)
- `[AssetRegistry]` 라인 없는데 헤더는 OK → 매니페스트 로드 실패. `user://` 권한 또는 `asset_host.json` 경로 확인
- 30초 timeout → 메인 씬에서 hang. `main.tscn`의 첫 노드 확인.

## 원라이너 (전체 4축)

```bash
DOMAIN="https://<your-app>.vercel.app"
ROOT="~/work/<your-game>"

echo "=== 1. HTML + COOP/COEP ==="
curl -sI "$DOMAIN/" | grep -iE 'http/|cross-origin' || echo "FAIL: headers missing"

echo "=== 2. WASM/JS ==="
curl -sI "$DOMAIN/index.wasm" | head -1
curl -sI "$DOMAIN/index.js" | head -1

echo "=== 3. asset_host.json ==="
curl -s "$DOMAIN/asset_host.json" | python3 -c "
import json, sys
try:
    d = json.load(sys.stdin)
    print('OK:', d.get('base_url','?'), 'cats:', d.get('category_count','?'))
except Exception as e:
    print('FAIL:', e)
"

echo "=== 4. Godot headless boot ==="
cd "$ROOT" && godot --headless --quit-after 30 2>&1 | tail -3
```

## 자동화 패턴 (cron job)

6시간마다 자동 헬스체크 → 실패 시 Telegram 알림:

```yaml
# crontab
0 */6 * * * cd ~/work/<game> && bash tools/healthcheck.sh https://<domain> | tee /tmp/lb-health.log
```

`tools/healthcheck.sh`:
```bash
#!/usr/bin/env bash
set -u
DOMAIN="${1:-https://<your-app>.vercel.app}"
fail=0
[ "$(curl -sI "$DOMAIN/" -o /dev/null -w '%{http_code}')" != "200" ] && fail=1
[ "$(curl -sI "$DOMAIN/index.wasm" -o /dev/null -w '%{http_code}')" != "200" ] && fail=1
exit $fail
```

`fail=1`이면 cron은 Telegram 알림으로 → 즉시 인지.

## 검증된 실전 예시 (2026-07-15 last-banner)

```
=== 1. HTML + COOP/COEP ===
HTTP/2 200
cross-origin-embedder-policy: require-corp
cross-origin-opener-policy: same-origin

=== 2. WASM/JS ===
HTTP/2 200  (index.wasm)
HTTP/2 200  (index.js, application/javascript)

=== 3. asset_host.json ===
OK: https://cdn.jsdelivr.net/gh/sigco3111/last-banner@main/assets cats: 6

=== 4. Godot headless boot ===
[GameManager] 부팅 완료
[AssetRegistry] 매니페스트 로드: base_url=https://cdn.jsdelivr.net/..., 6 카테고리
```

→ 4축 모두 OK → README에 라이브 URL 박아도 안전.

## 일반 함정

- **첫 deploy 직후 `age: 0` 응답 = Vercel 캐시 미적중**. 실제 사용자 트래픽은 다른 POP에서 나옴 → 가능하면 1분 대기 후 재시도.
- **`cross-origin-resource-policy: same-origin`** 가 빠지면 SharedArrayBuffer는 살아있지만 외부 embed 시 차단될 수 있음. 3개 헤더 모두 필수.
- **GODOT 버전 mismatch**: 로컬 Godot이 4.7인데 Vercel 빌드가 4.6 export → 헤드리스 부팅은 OK여도 web은 깨질 수 있음. export templates 버전 명시.
- **`asset_host.json` 404 vs 403**: 404면 파일 없음, 403이면 `Cache-Control` 충돌. `curl -v`로 분기.

## 참고

- Vercel 헤더 패턴: `references/vercel-godot-web-export.md`
- lazy fetch 매니페스트: `references/lazy-fetch-via-cdn.md`
- Godot 헤드리스 부팅 함정: `references/godot-4-headless-bootstrap.md`
- 검은 화면 진단: `references/godot-web-black-screen-diagnosis.md`