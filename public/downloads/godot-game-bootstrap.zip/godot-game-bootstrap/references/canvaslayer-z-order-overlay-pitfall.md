# CanvasLayer z-order — 모달/오버레이 가려짐 함정 (Last Banner v2, 2026-07-16 실전)

Godot CanvasLayer 사이에 명시적 z-order 분리가 없으면, 오버레이/모달이 대시보드 Control 아래에 그려져서 **모달이 떠있어도 화면에 안 보임**. 사용자 클릭 → 인터랙션 0 = "모달 안 뜬다"로 보임.

## 증상

- 결정 큐 모달이 push됐는데 화면에 안 보임
- 코드상 `decision_modal.visible = true` 인데 시각적으론 표시 0
- LB_VERIFY 헤드리스 검증은 통과 (`ready`, `push`, `print` 모두 작동)
- 사용자 데스크탑에서 `godot --path .` 또는 정식 .app 실행 시 **모달이 가려짐**
- stderr 로그: `[Modal] 표시: id=N` 출력됨 → 코드는 정상 실행 중

## 원인 (3개 누적)

### 원인 A — CanvasLayer 평면적 그리기 순서

`Main` Node2D에 자식 여러 개:
```
Main (Node2D)
├── UI (CanvasLayer, layer=0)
├── ManorDashboard (Control 직접 — CanvasLayer 없음)
├── ModalLayer (CanvasLayer, layer=100) ← 나중에 추가했어야 함
```

CanvasLayer가 없는 `ManorDashboard`는 root Node2D의 **기본 layer 0**에서 그려짐. 또 다른 CanvasLayer도 기본 layer 0. 이 둘은 **자식 추가 순서**로 z-order 결정:
- 자식 추가 순서: UI → ManorDashboard → ModalLayer
- manor_dashboard가 **modal_layer보다 먼저** 그려짐 (모달이 manor 위에? ❌ 사실 그 반대)

실제 Godot 그리기 순서:
1. Tree에서 자식 인덱스 0번부터
2. **같은 z-level이면 자식 인덱스 = z-order** (위 = 나중에 그려짐 = 위에 표시)

UI (idx 0), ManorDashboard (idx 1), ModalLayer (idx 2) → ModalLayer가 **위**에 그려져야 하는데, **ManorDashboard가 ModalLayer보다 큰 영역을 차지하면 ManorDashboard의 모든 픽셀이 ModalLayer 픽셀보다 뒤에 그려져서 위에 보임**. 단, CanvasLayer는 내부 자식을 그 layer에서 한 번에 묶어서 그리므로 ModalLayer(CanvasLayer)가 z-level에서 ManorDashboard보다 위에 있어야 함.

### 원인 B — Modal의 Background가 검정이라 안 보임
PanelContainer만 있으면 alpha 없는 디폴트 스타일. 비어있는 흰 패널 위에 자식 Label이 그대로 보이긴 하지만, 배경에 **반투명 검정 DimBG** 없으면 "왜 모달이 안 떠?" 헷갈림.

### 원인 C — PanelContainer mouse_filter 기본값
기본 PanelContainer는 mouse_filter=STOP이지만 자식 Button은 별도. 명시 안 하면 OS-level 클릭 이벤트가 패널을 통과 못할 수 있음.

## 해결 — ModalLayer layer=100 분리

```ini
[gd_scene load_steps=N format=3 uid="..."]

[ext_resource type="Script" path="res://scripts/main.gd" id="1_main"]

[node name="Main" type="Node2D"]
script = ExtResource("1_main")

[node name="UI" type="CanvasLayer" parent="."]
layer = 0

# ... 기존 TopResourceBar/BottomButtonRow ...

[node name="ManorLayer" type="CanvasLayer" parent="."]
layer = 0

[node name="ManorDashboard" parent="ManorLayer" instance=ExtResource("2_dash")]

[node name="ModalLayer" type="CanvasLayer" parent="."]
layer = 100   ← 핵심: ManorLayer보다 명확히 큰 layer 번호

[node name="DimBG" type="ColorRect" parent="ModalLayer"]
anchor_right = 1.0
anchor_bottom = 1.0
color = Color(0, 0, 0, 0.7)
visible = false
mouse_filter = 0   ← STOP (모달 영역 외 클릭 시 modal 닫기 등에 쓰임)

[node name="DecisionModal" type="PanelContainer" parent="ModalLayer"]
visible = false
anchor_left = 0.5
anchor_top = 0.5
anchor_right = 0.5
anchor_bottom = 0.5
offset_left = -360.0
offset_top = -180.0
offset_right = 360.0
offset_bottom = 180.0
mouse_filter = 0   ← STOP 명시

[node name="ModalVBox" type="VBoxContainer" parent="ModalLayer/DecisionModal"]
# ... Title/Desc/Priority/Choices 라벨들 ...
```

## GDScript 동적 노드 검색 — 절대 경로로

CanvasLayer 안에 있으니 `ui = get_node_or_null("UI")` 그대로 두고 ModalLayer는 별도:

```gdscript
var modal_dim_bg: ColorRect = null
var decision_modal: PanelContainer = null

func _find_nodes() -> void:
    var ui: CanvasLayer = get_node_or_null("UI")
    # ... UI 자식들은 ui.get_node_or_null("...") ...
    # ModalLayer는 Main의 직접 자식 — 절대 경로
    modal_dim_bg = get_node_or_null("ModalLayer/DimBG") as ColorRect
    decision_modal = get_node_or_null("ModalLayer/DecisionModal") as PanelContainer
    if decision_modal:
        modal_title = decision_modal.get_node_or_null("ModalVBox/ModalTitle") as Label
        # ...
```

## 모달 열기/닫기 — DimBG 동기 토글

```gdscript
func _show_next_decision() -> void:
    for d in DecisionQueue.get_all_pending():
        if d.id > _current_decision_id:
            _current_decision_id = d.id
            _populate_modal(d)
            if modal_dim_bg:
                modal_dim_bg.visible = true   # ← DimBG도 함께
            decision_modal.visible = true
            print("[Modal] 표시: id=%d [%s] %s" % [d.id, ...])
            return

func _close_modal() -> void:
    if decision_modal:
        decision_modal.visible = false
    if modal_dim_bg:
        modal_dim_bg.visible = false
    _current_decision_id = -1
```

## 진단 4단계

| 단계 | 확인 | 결과 |
|---|---|---|
| 1 | `decision_modal = get_node_or_null("ModalLayer/DecisionModal")` 검색 | not null |
| 2 | `decision_modal.visible = true` 직후 `print("[Modal] 표시")` 실행 | 로그 O |
| 3 | 헤드리스 `LB_VERIFY` 에서 `assert(decision_modal.visible)` | pass |
| 4 | 사용자 데스크탑 스크린샷 | 모달이 **안 보임** = z-order 문제 확정 |

→ 1~3이 모두 정상이면 **z-order 100%**.

## 검증 (LB_VERIFY에 추가)

```gdscript
# [10] 모달 z-order 검증
print("[10] 모달 z-order 검증")
var modal_layer: CanvasLayer = get_node_or_null("ModalLayer") as CanvasLayer
assert(modal_layer != null)
assert(modal_layer.layer >= 100, "ModalLayer layer >= 100 필수 (현재 %d)" % modal_layer.layer)
var manor_layer: CanvasLayer = get_node_or_null("ManorLayer") as CanvasLayer
if manor_layer:
    assert(modal_layer.layer > manor_layer.layer, "ModalLayer가 ManorLayer보다 위에 있어야 함")
print("  ✓ ModalLayer.layer=%d, ManorLayer.layer=%d" % [modal_layer.layer, manor_layer.layer])
```

## 흔한 오해

| 오해 | 실제 |
|---|---|
| "anchor_center 0.5 0.5이면 화면 중앙 → 무조건 보임" | 가려지면 안 보임 (z-order 무관하게) |
| "visible = true면 무조건 그려짐" | 다른 노드가 더 뒤에 있고 그 영역을 덮으면 안 보임 |
| "Anchor full screen (=1,1,1,1) 안 먹어서 가려짐" | Anchor 문제 아님 — z-level 문제 |
| "popup 동작이라 CanvasLayer 자동 분리" | Godot는 자동 분리 X — 명시 필요 |

## 권장 패턴

모든 오버레이 (모달, 풀스크린 트랜지션, 풀스크린 토스트) → **별도 `CanvasLayer layer >= 100`**. 기존 dashboard/hud는 `layer <= 0`. 이 규칙 한 줄이면 z-order 충돌 0.

## 관련 스킬/문서

- `godot-game-bootstrap/SKILL.md` 함수정 1: 모바일 viewport anchor — Control anchor는 OK, z-order는 별개
- `incremental-game-design-last-banner-event-engine/references/x-close-button-overlay-pattern.md` — 우상단 XButton (layer 문제와 별개로 항상 root에 parent=".")

---

## Control 자식은 **항상 CanvasLayer에 두기** — 가시성 invariant (2026-07-16 Last Banner v3.0.3 실전)

위 패턴 (modal/dashboard z-order)은 **CanvasLayer로 명시적 분리**가 핵심. v3.0.3에서 발견한 **더 강한 invariant**가 있습니다:

> **`Control` (특히 `visible` 토글이 필요한 노드)을 `CanvasLayer` 아닌 곳에 두지 말 것 — 특히 `Node2D` 직속 자식이면 가시성 토글이 무시될 수 있음.**

### 증상 (Last Banner v3.0.3)

`Main` (Node2D) 직속 자식으로 `BattleScene` (Control)을 인스턴스화했습니다:

```ini
[ext_resource type="PackedScene" path="res://scenes/battle_scene.tscn" id="4_battle"]

[node name="BattleScene" parent="." instance=ExtResource("4_battle")]
```

`scene.start_battle()`에서 `visible = true` 호출하지만 **사용자 화면에 안 떠** (LB_VERIFY `assert(battle.visible)` 통과했음에도). `_process` 매 프레임마다 `visible` 점검해도 무반응.

**확인된 원인**: Godot 4는 `Control` 노드의 가시성 토글 처리가 `CanvasLayer` 내부에 있을 때 안정적. **Node2D 직속 자식**으로 두면 input dispatcher가 다르게 작동하면서 visibility propagation이 비정상 처리될 가능성.

### 해결 — `BattleLayer` CanvasLayer 추가 (layer=90)

```ini
[node name="BattleLayer" type="CanvasLayer" parent="."]
layer = 90

[node name="BattleScene" parent="BattleLayer" instance=ExtResource("4_battle")]
```

**선택 이유**:
- `ManorDashboard`는 `ManorLayer layer=0`에 있고
- `ModalLayer layer=100`이 가장 위
- `BattleLayer layer=90`은 ManorLayer보다 위지만 ModalLayer보다 아래
- 다른 모든 오버레이와 시각적으로 충돌 X

### GDScript 동적 검색 — CanvasLayer 경로

```gdscript
func _get_battle_scene() -> Control:
    var layer: Node = get_node_or_null("BattleLayer") as CanvasLayer
    if layer:
        return layer.get_node_or_null("BattleScene") as Control
    # legacy fallback: Main 직속 자식
    for child in get_children():
        if child.name == "BattleScene" and child is Control:
            return child
    return null
```

### 일반화된 가시성 invariant — "Control은 항상 CanvasLayer에"

| 부모 타입 | Control 가시성 토글 | 권장 |
|---|---|---|
| **`Control` 부모** | 정상 작동 | 그대로 사용 가능 |
| **`Node2D` 부모** (직속) | **고장 — visible 토글 무반응** | **반드시 CanvasLayer로 감싸기** |
| **`CanvasLayer` 부모** | 정상 + z-order 명시 가능 | 권장 (모든 Control 자식) |
| **`SubViewport` 부모** | 정상 — viewport 별도 render target | 카메라/줌 인터랙션 시 |

**판단 기준** (제작 시):

```gdscript
# ❌ 피해야 할 패턴 — Node2D 직속 자식 Control
[node name="SomeControl" parent="." instance=ExtResource("control.tscn")]
# GDScript로 visible 토글 → 가끔 안 보임

# ✅ 권장 패턴 — CanvasLayer에 감싸기
[node name="SomeCanvasLayer" type="CanvasLayer" parent="."]
[node name="SomeControl" parent="SomeCanvasLayer" instance=ExtResource("control.tscn")]
# 가시성 토글 항상 작동
```

**Layer 번호 선택 규칙**:
- `layer <= 0` — 배경/매너지/dashboard
- `layer 1~50` — 메인 오버레이 (HUD 등)
- `layer 51~90` — 화면 전체 전환 (전투 화면 등)
- `layer >= 100` — 모달/디버그 pane (가장 위)

이 규칙 한 줄 + `layer`로 z-order 명시 → visibility + z-order 동시 해결.
