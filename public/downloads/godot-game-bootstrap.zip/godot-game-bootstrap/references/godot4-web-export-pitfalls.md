# Godot 4 Web Export + Vercel — 실전 함정 12가지

Last Banner 부트스트랩 중 **실제로 만난** 함정들. 헤더리스 빌드 → Vercel/Cloudflare 배포까지 통과한 검증된 패턴.

## 함정 1: `config/icon` 경로 부재 시 export 크래시

```ini
[application]
config/icon="res://assets/icons/app_icon.png"   # ⚠ PNG가 없으면 export 시 ERROR: Error opening file
```

`godot --headless --export-release "Web" ...` 출력이 끝까지 안 가고 `error opening file` 메시지에서 멈춤.

**Fix**: 아이콘 PNG 만들기 전엔 `config/icon` 줄 자체를 빼. 빌드 후 추가 가능.

## 함정 2: `export_presets.cfg`는 project **루트**에만

Godot 4는 `res://export_presets.cfg`만 인식. `res://export/export_presets.cfg`는 무시 → `This project doesn't have an export_presets.cfg file at its root` 에러.

**Fix**: project.godot와 같은 디렉터리에 둘. 서브폴더화 안 됨.

## 함정 3: cfg bool은 **소문자** `false`/`true`

export_presets.cfg는 INI 형식이지만 bool 값은 JSON처럼 소문자.

```ini
codesign/replace_sandbox=false   # ✅
codesign/replace_sandbox=False   # ❌ ConfigFile parse error at line N: Unexpected identifier 'False'
```

macOS preset 생성 시 Python 도구로 자동 생성하면 `False` (대문자) 들어가는 경우 있음 — 정규식 sed로 일괄 변환.

## 함정 4: export templates 디렉토리 구조

unzip 직후엔 이렇게 풀림:
```
~/Library/Application Support/Godot/export_templates/4.7.1.stable/
└── templates/
    ├── web_release.zip
    ├── web_debug.zip
    └── linux_release.x86_64 ... (모든 플랫폼)
```

하지만 Godot은 다음 위치에서 찾음:
```
~/Library/Application Support/Godot/export_templates/4.7.1.stable/
└── web_release.zip   # templates/ 없이 직접
```

`templates/` 서브폴더에 두면 `Cannot export project with preset "Web" due to configuration errors: 예상된 경로에서 찾은 내보내기 템플릿이 없습니다`.

**Fix**:
```bash
cd "$HOME/Library/Application Support/Godot/export_templates/<버전>.stable/"
mv templates/web_*.zip .   # 모든 web_* + web_dlink_*.zip을 root로
mv templates/linux_*.xz . 2>/dev/null   # linux도 비슷
```

## 함정 5: Vercel의 **단일 파일 100MB 제한**

Godot Web export 산출물:
- `index.html` — 5KB
- `index.js` — 300KB
- `index.wasm` — **37MB**
- `index.pck` — **207MB**

→ `Error: File size limit exceeded (100 MB)` on upload.

**3가지 우회**:
1. **lazy fetch** (이 스킬 권장) — `assets/*/.gdignore` + jsDelivr CDN → pck ~500KB
2. **Cloudflare Pages** (대용량 그대로 빌드)
3. **Vercel Pro $20/월**

## 함정 6: Vercel JSON regex는 `$` 앵커 필요

```json
{
  "source": "/(.+\\.(wasm|pck|js))"     // ❌ Error: Header at index 1 has invalid `source` pattern
  "source": "/(.+)\\.(wasm|pck|js)$"    // ✅ 끝에 $ 필수
}
```

Vercel regex는 ECMA-262 subset으로 더 엄격. `$` 없으면 invalid pattern.

## 함정 7: GDScript Dictionary 타입 추론 실패

```gdscript
func summary() -> String:
    var lines: Array = [...]   # ✅ Array는 추론 OK
    for cat in MANIFEST:
        var m := MANIFEST[cat]                            # ❌ Parse Error: Cannot infer type
        lines.append("... %s ... " % [m.license])          # 컴파일 실패
```

**Fix**: 명시적 타입 + `.get()` 으로 안전 접근:
```gdscript
var m: Dictionary = MANIFEST[cat]
lines.append("... %s ... " % [m.get("license", "?")])
```

## 함정 8: GDScript **함수 이름과 멤버 변수 이름 충돌**

```gdscript
func _ready() -> void:        # Godot lifecycle
    ...
var _ready: bool = false       # ❌ Parse Error: Function "_ready" has the same name as a previously declared variable.
```

`var _ready`는 `_ready` 함수를 가린다고 GDScript 파서가 판단.

**Fix**: 변수명 변경. `var _manifest_ready: bool` 같이 함수 이름 피해서 명명.

## 함정 9 (Vercel): 첫 deploy 시 buildCommand가 **project settings에 영구 저장**

`vercel.json`에서 `buildCommand` 빼고 푸시해도, 첫 `vercel --prod`가 project settings에 저장. 그 이후 `bash tools/build.sh web` exit 127이 자동 실행됨.

이게 일어나는 이유: Vercel CLI가 buildCommand 없이 deploy할 때 project settings에 있던 명령을 사용.

**Fix**: Vercel REST API로 project settings 직접 변경 (vercel CLI로는 변경 불가):
```bash
TOK=$(cat ~/.hermes/secrets/vercel_token.txt | tr -d '\n')
curl -X PATCH "https://api.vercel.com/v9/projects/<PROJECT_ID>?teamId=<TEAM_ID>" \
  -H "Authorization: Bearer $TOK" \
  -H "Content-Type: application/json" \
  -d '{"buildCommand": null, "installCommand": null, "devCommand": null}'

# 프로젝트 ID는 .vercel/project.json의 projectId 또는 vercel inspect URL
```

또는 `build/web/`을 git에 커밋 + vercel.json `buildCommand` 제거 + vercel.json에 `outputDirectory`만 명시.

## 함정 10 (Vercel): 무료 플랜 일일 **5,000 requests 한도** + 24시간 블로킹

`vercel --prod`가 여러 파일을 개별 request로 업로드하다가 하루 5,000건 초과. 그 이후 24시간 블로킹:
```
Error: Too many requests - try again in 24 hours (more than 5000, code: "api-upload-free").
```

**Fix**: `--archive=tgz` 옵션으로 묶어서 보내면 1 request:
```bash
vercel --yes --prod --archive=tgz   # build/web/ 을 tgz 1개로 묶음
```

## 함정 11 (Vercel): **`vercel.json` 추가 속성 (`_comment`) 거부**

```json
{
  "_comment": "buildCommand는 null",      // ❌ Error: Invalid vercel.json - should NOT have additional property '_comment'
  "outputDirectory": "build/web"
}
```

Vercel은 vercel 스키마의 알려진 필드만 허용. 주석은 별도 `.md` 파일에 적을 것.

## 함정 12 (Vercel): 빌드 머신에 **Godot CLI 없음** → exit 127

```
> Running build in Washington, D.C., USA (East) – iad1
> Build machine configuration: 2 cores, 8 GB
> Retrieving list of deployment files...
> Concatenating deployment archive files...
> Extracting deployment files...
Error: Command "bash tools/build.sh web" exited with 127
```

Vercel 빌드 컨테이너는 깨끗한 Node.js 환경. Godot CLI / templates / 풀 데이터 전부 없음.

**Fix 3가지**:
1. **GitHub Actions에서 빌드 + `build/web/`을 main에 푸시** → Vercel은 outputDirectory만 사용 (vercel project settings `buildCommand: null`)
2. **로컬에서 빌드 후 `build/web/` 직접 푸시** → 빠르지만 수동
3. **`vercel.json`에 buildCommand 안 적고 `outputDirectory: build/web`** + 첫 deploy 시 `--archive=tgz`로 산출물 업로드 (Vercel은 빈 디렉터리만 보고 0ms 빌드로 끝남)

## 부수 함정

- **헤드리스 부팅 검증**: `godot --headless --quit-after 200 2>&1 | grep -E "GameManager|TimeManager"`로 autoload 5종 다 로드되는지 확인. 안 되면 Error 1개로 게임 전체 막힘.
- **`process_mode = Node.PROCESS_MODE_ALWAYS`** 필수 (GameManager PAUSED 상태에서도 시계/큐가 돌려면).
- **Git push 시 `index.pck` 200MB**: GitHub은 100MB/파일 hard limit 걸려서 LFS 안 쓰면 push 실패. 다행히 `build/`는 gitignore라 OK. 단, **lazy fetch 채택 시 `build/web/index.pck`은 ~500KB**이므로 추적 가능.
- **`.import` 파일(자동 생성)을 다른 폴더로 옮기지 말 것** — Godot이 import 단계마다 경로 추적함. 옮기면 깨짐.
- **빈 폴더에 `godot` 실행해도 project.godot 안 만들어줌**. `write_file`로 명시 생성.

## 검증된 풀 파이프라인 (Last Banner 실전)

```bash
# 1. templates 설치
curl -L -o /tmp/godot_templates.tpz \
  "https://github.com/godotengine/godot-builds/releases/download/4.7.1-stable/Godot_v4.7.1-stable_export_templates.tpz"
mkdir -p "$HOME/Library/Application Support/Godot/export_templates/4.7.1.stable/"
cd "$HOME/Library/Application Support/Godot/export_templates/4.7.1.stable/"
unzip -q /tmp/godot_templates.tpz
mv templates/web_*.zip .   # ⚠ 함정 4

# 2. 헤드리스 부팅 검증 (함정 7, 8 잡기)
godot --headless --quit-after 200

# 3. Web 빌드
godot --headless --export-release "Web" "$PWD/build/web/index.html"
ls build/web/ | grep -E "wasm|pck"   # 둘 다 생성 확인

# 4. 로컬 HTTP 서빙 검증
python3 -m http.server 8765 &
sleep 2
curl -sI http://localhost:8765/index.pck | head -3   # 200 OK + Content-Length ~217MB

# 5a. Cloudflare Pages (대용량 그대로) — wrangler 없이 가능
# https://dash.cloudflare.com → Pages → Connect to Git

# 5b. Vercel lazy fetch (pck ~500KB) — vercel.json + build/web/ git 추적
export VERCEL_TOKEN=$(cat ~/.hermes/secrets/vercel_token.txt | tr -d '\n')
vercel --yes --prod --archive=tgz
```

## 자동 진행 + 결정 큐 구조 (확정 패턴)

```
GameManager.current_state  ←→  TimeManager.auto_progress_enabled
            │                           │
            │ _process(delta)           │ CRITICAL 결정 감지
            ▼                           ▼
        minutes_elapsed++         GameManager.pause_for_decision()
            │
            ▼
        SaveManager.maybe_auto_save()  (60분마다)
            │
            ▼
        DecisionQueue.push(priority)
            │
   ────────┴─────────────────────────────────────
   │ MEDIUM → 큐에 push만, 자동 진행 계속     │
   │ HIGH   → 큐에 push만, 자동 진행 계속     │
   │ CRITICAL → 자동 진행 즉시 정지 + 알림    │
```

`TimeManager._process`에서 매 프레임 `if DecisionQueue.has_pending_critical(): GameManager.pause_for_decision()` 호출. **게임 중 사용자 진입 시 진입점에 결정 큐 모달 자동 노출**.

## 단계별 검증 — 빌드 후 라이브 검증

```bash
# 1. HTTP 200 확인
curl -sI https://<alias>.vercel.app/ | head -3

# 2. COOP/COEP 헤더 확인
curl -sI https://<alias>.vercel.app/ | grep -E "Cross-Origin"

# 3. asset_host.json 도달 확인
curl -s https://<alias>.vercel.app/asset_host.json | python3 -c "import json,sys; print(json.load(sys.stdin)['total_size_bytes'])"

# 4. pck / wasm 도달 확인 (Content-Length)
curl -sI https://<alias>.vercel.app/index.pck | grep -i content-length
curl -sI https://<alias>.vercel.app/index.wasm | grep -i content-length

# 5. Service Worker 도달 확인
curl -sI https://<alias>.vercel.app/index.service.worker.js
```

모두 정상이면 라이브 OK. 그 다음 실제 브라우저로 첫 진입 (3rd-party storage 권한 알림 뜨면 허용).
