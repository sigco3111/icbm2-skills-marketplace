# Manor Dashboard 화면 패턴 (Last Banner v2, 2026-07-16 실전)

> 영지 풍경도 + 용병 roster + 일간 변동 카드. Godot 4.7 + macOS .app에서 검증됨.

## 언제 쓰나

`Control` 1개 씬에 **4존 레이아웃**으로 게임 허브를 구성할 때:
- 자동 진행 + 결정 큐 + 시뮬레이션 게임의 메인 화면
- 영지/도시/기지 운영 로그라이크의 허브
- 정치/CK3 양식의 court/재화/인적자원 통합 화면

## 4존 표준 레이아웃 (1280×720)

```
┌─────────────────────────────────────────────────────────────────────┐
│ TopResourceBar (CanvasLayer, full width × 80px)                      │  ← 자원 카드 + 시간
│  [Day X | HH:MM | 자동 ON/OFF]  💰  🌾  👥  ⭐  📜5건  🪵최근 사건   │
├─────────────────────────────────────────────────────────────────────┤
│ ┌────────────────────────────────────┐ ┌─────────────────────────┐   │
│ │ 🏰 영지명 / 휘장 카드               │ │ ⚔️ 용병 (N명) 카드        │   │
│ ├────────────────────────────────────┤ ├─────────────────────────┤   │
│ │ ManorScene (SubViewport)           │ │ RosterList              │   │
│ │ - 풀밭 ColorRect 배경               │ │ ┌────┐ 이름 · 직책       │   │
│ │ - 흙길 ColorRect + ridge            │ │ │ 🐴 │ 💰 X/일 ★ Y/100   │   │
│ │ - Sprite2D × 5 (영주 + 4명)         │ │ └────┘ ...              │   │
│ │ - Label (이름/위치 표시)            │ │                         │   │
│ └────────────────────────────────────┘ └─────────────────────────┘   │
├─────────────────────────────────────────────────────────────────────┤
│ [📜 방문객 카드]     [📊 일간 변동 카드]                              │  ← 결정 큐 알림 + 일일 누적
├─────────────────────────────────────────────────────────────────────┤
│ BottomButtonRow (CanvasLayer, full width × 90px)                     │  ← 액션 버튼
│        [P: 자동 진행]  [+1일 진행]  [💾 저장]  [📂 불러오기]            │
└─────────────────────────────────────────────────────────────────────┘
```

## 핵심 구성 패턴

### 1. 풍경도 그리기 — `Control > Node2D > Sprite2D` 단순 트리 (1순위 권장)

**1순위 권장** (대부분 허브 화면, 카메라/줌 인터랙션 없을 때):
```ini
[node name="ManorScene" type="PanelContainer" parent="CenterRoot/LeftColumn"]
size_flags_vertical = 3

[node name="SceneHost" type="Control" parent="CenterRoot/LeftColumn/ManorScene"]
anchor_right = 1.0
anchor_bottom = 1.0
mouse_filter = 2                                ; MOUSE_FILTER_IGNORE

[node name="SceneRoot" type="Node2D" parent="CenterRoot/LeftColumn/ManorScene/SceneHost"]
```

스크립트가 `SceneRoot`(Node2D)에 `Sprite2D × N + ColorRect × N + Label × N` 직접 `add_child`. Control 위의 Node2D는 position이 Control 좌표 그대로 동작 — 카메라/이벤트 충돌 없음 (메인 윈도우에 직접 그리니까).

**왜 단순 트리?** (2026-07-16 last-banner-v2 실전 검증):
- LB_VERIFY에서 `scene_root.get_children() 중 Sprite2D 개수` assert 단순. 결정적 검증 가능.
- 헤드리스 빌드 시 픽셀 렌더링은 안 되지만 노드 트리 자체는 검증 가능 — sprite가 한 번이라도 정상 추가됐다 보장.
- SubViewport 사용 시 `render_target_update_mode`, `SubViewport.size`, `SubViewportContainer.stretch` 3개 값 미스매치로 화면에 픽셀 0개 되는 함정 빈번 (sprite 추가 카운트는 정상이라 LB_VERIFY 통과하는데 사용자 데스크탑엔 검은 화면).

**SubViewport가 필요한 경우** (1순위가 아닌 예외):
- 풍경도 안에서 카메라 줌인/줌아웃/패닝 (드래그로 시점 이동)
- 풍경도가 별도 미니월드거나 미니맵 (다른 카메라 좌표계)
- viewport-to-texture 패턴 (SubViewport 텍스처를 다른 머티리얼에 입힘)

**판단 기준**:
| 인터랙션 | 권장 구조 |
|---|---|
| 캐릭터 클릭만 | Control > Node2D (이 패턴, 1순위) |
| 풍경도 드래그 패닝 | SubViewport |
| 줌 + 패닝 | SubViewport + Camera2D |
| 머티리얼 텍스처로 사용 | SubViewport |

**잘못된 시도 (2026-07-16 last-banner-v2 1차)** — SubViewport로 갔다가 sprite 안 보이는 함정에 빠짐:
```ini
[node name="SceneViewport" type="SubViewportContainer" parent="CenterRoot/LeftColumn/ManorScene"]
stretch = true

[node name="SceneViewport" type="SubViewport" parent="..."]
handle_input_locally = false
size = Vector2i(696, 500)
render_target_update_mode = 4                    ; WHEN_PARENT_VISIBLE (성능)

[node name="SceneRoot" type="Node2D" parent="...SceneViewport"]
```
LB_VERIFY step sprite_count==5 PASS지만 사용자 화면엔 픽셀 0개. 2차에서 단순 Control > Node2D로 회귀하니 즉시 정상. **단순 구조로 시작하고 인터랙션 필요해지면 SubViewport로 마이그레이션**이 시간 절약.

### 2. 풍경도 그리기 (ColorRect 배경 + Sprite2D 캐릭터)

```gdscript
# 스크립트는 scripts/manor_dashboard.gd
const SCENE_BG_COLOR := Color(0.32, 0.36, 0.22, 1)   # 황야
const GROUND_COLOR := Color(0.48, 0.42, 0.28, 1)    # 흙길

const SCENE_UNITS := [
    { "id": "lord",   "path": "res://assets/units/.../general.png",   "pos": Vector2(360, 360), "scale": 2.0,  "label": "영주" },
    { "id": "sword",  "path": "res://assets/units/.../swordsman.png", "pos": Vector2(200, 380), "scale": 1.6,  "label": "기사" },
    # ...
]

func _draw_manor_scene() -> void:
    # 1. 배경 풀밭
    var bg := ColorRect.new()
    bg.color = SCENE_BG_COLOR
    bg.size = Vector2(696, 500)
    bg.position = Vector2(0, 0)
    scene_root.add_child(bg)

    # 2. 흙길 (중간 가로 띠)
    var ground := ColorRect.new()
    ground.color = GROUND_COLOR
    ground.size = Vector2(696, 120)
    ground.position = Vector2(0, 320)
    scene_root.add_child(ground)

    # 3. 경계선 (길과 풀 사이)
    var ridge := ColorRect.new()
    ridge.color = Color(0.32, 0.28, 0.16, 1)
    ridge.size = Vector2(696, 4)
    ridge.position = Vector2(0, 320)
    scene_root.add_child(ridge)

    # 4. 캐릭터 5명 (영주 + 4명)
    for unit in SCENE_UNITS:
        _add_unit_sprite(unit)

    # 5. 휘장 라벨
    var banner := Label.new()
    banner.text = "토르바르의 영지"
    banner.position = Vector2(20, 20)
    banner.add_theme_font_size_override("font_size", 20)
    banner.add_theme_color_override("font_color", Color(0.94, 0.86, 0.62))
    scene_root.add_child(banner)

func _add_unit_sprite(unit: Dictionary) -> void:
    var path: String = unit.get("path", "")
    if not ResourceLoader.exists(path):
        print("[Dashboard] 자산 없음: %s" % path)   # ★ graceful fallback
        return
    var tex: Texture2D = load(path)
    var sprite := Sprite2D.new()
    sprite.texture = tex
    sprite.centered = true
    sprite.position = unit.get("pos", Vector2.ZERO)
    var sc: float = unit.get("scale", 1.0)
    sprite.scale = Vector2(sc, sc)
    sprite.modulate = Color(1, 1, 1, 1)            # ★ Wesnoth 원본 색 그대로
    scene_root.add_child(sprite)

    # 이름 라벨 (캐릭터 발 아래)
    var lbl := Label.new()
    lbl.text = unit.get("label", "")
    lbl.position = unit.get("pos", Vector2.ZERO) + Vector2(-24, 60)
    lbl.add_theme_font_size_override("font_size", 11)
    lbl.add_theme_color_override("font_color", Color(0.96, 0.88, 0.68))
    scene_root.add_child(lbl)
```

### 3. Roster List-Detail (우측 사이드)

```gdscript
func _refresh_roster() -> void:
    if roster_vbox == null:
        return
    for child in roster_vbox.get_children():
        child.queue_free()                          # 재갱신 패턴 (가벼운 경우 OK)
    for merc in ROSTER:
        var row := HBoxContainer.new()
        row.custom_minimum_size = Vector2(0, 56)    # 행 높이 고정
        row.add_theme_constant_override("separation", 8)
        row.add_child(_make_avatar(merc.get("img", "")))  # 48×48 PNG
        var info := VBoxContainer.new()
        info.size_flags_horizontal = 3              # 남은 폭 차지
        var name_lbl := Label.new()
        name_lbl.text = "%s · %s" % [merc.get("name", ""), merc.get("class", "")]
        name_lbl.add_theme_font_size_override("font_size", 13)
        var wage_lbl := Label.new()
        wage_lbl.text = "💰 %d/일  ★ %d/100" % [merc.get("wage", 0), merc.get("loyalty", 0)]
        wage_lbl.add_theme_font_size_override("font_size", 11)
        info.add_child(name_lbl)
        info.add_child(wage_lbl)
        row.add_child(info)
        roster_vbox.add_child(row)

func _make_avatar(path: String) -> Control:        # ★ Control 반환으로 통합
    if path != "" and ResourceLoader.exists(path):
        var tex_rect := TextureRect.new()
        tex_rect.custom_minimum_size = Vector2(48, 48)
        tex_rect.expand_mode = 1                     # IGNORE_SIZE
        tex_rect.stretch_mode = 5                    # KEEP_ASPECT_CENTERED
        tex_rect.texture = load(path)
        return tex_rect
    var ph := ColorRect.new()                       # placeholder
    ph.size = Vector2(48, 48)
    ph.color = Color(0.3, 0.3, 0.3, 1)
    return ph
```

**함정 회피**: `_make_avatar` 반환 타입을 `Control`로 통합. TextureRect/ColorRect 둘 다 반환 가능. `TextureRect`만 반환 타입 선언하면 `ColorRect` 반환 시 parse 에러.

### 4. 시그널 구독 자동 갱신

```gdscript
func _ready() -> void:
    _find_nodes()
    _draw_manor_scene()
    _refresh_roster()
    _refresh_status()
    GameWorld.resource_changed.connect(_on_resource_changed)
    GameWorld.event_logged.connect(_on_event_logged)

func _refresh_status() -> void:
    if manor_title:
        manor_title.text = "🏰 영지: %s" % GameWorld.lord_name
    if stats_gold_change:
        var g: int = GameWorld.day_gold_change
        stats_gold_change.text = "💰 오늘: %s%d" % ["+" if g > 0 else "", g]
    if stats_food_change:
        var f: int = GameWorld.day_food_change
        stats_food_change.text = "🌾 오늘: %s%d" % ["+" if f > 0 else "", f]
    if stats_days:
        stats_days.text = "📅 경과: %d일" % TimeManager.day
    if visitor_desc:
        var pending: Array = DecisionQueue.get_all_pending()
        if pending.is_empty():
            visitor_desc.text = "대기 중인 방문객 없음"
        else:
            var first: Dictionary = pending[0]
            visitor_desc.text = "[%s] %s" % [
                DecisionQueue.Priority.keys()[first.priority],
                first.payload.get("title", "")
            ]

func _on_resource_changed(_r: String, _v: int) -> void:
    _refresh_status()

func _on_event_logged(_msg: String) -> void:
    _refresh_status()
```

### 5. main.tscn 통합

```ini
[gd_scene load_steps=3 format=3 uid="uid://..."]
[ext_resource type="Script" path="res://scripts/main.gd" id="1_main"]
[ext_resource type="PackedScene" path="res://scenes/manor_dashboard.tscn" id="2_dash"]

[node name="Main" type="Node2D"]
script = ExtResource("1_main")

[node name="UI" type="CanvasLayer" parent="."]

[node name="TopResourceBar" type="PanelContainer" parent="UI"]
anchor_right = 1.0
offset_bottom = 80.0

[node name="ResourceRow" type="HBoxContainer" parent="UI/TopResourceBar"]
; 시간 + 자원 5종 + 결정 큐 + 최근 사건 한 줄에 나열

[node name="ManorDashboard" parent="." instance=ExtResource("2_dash")]

[node name="BottomButtonRow" type="PanelContainer" parent="UI"]
anchor_top = 1.0
anchor_bottom = 1.0
offset_top = -90.0
; 버튼 4개 가로 정렬
```

`ManorDashboard`는 별도 노드 (UI CanvasLayer 밖 — Node2D 자식). Control은 보통 2D 월드와 독립이라 CanvasLayer 둘 다 가능.

## 함정 + 주의사항

### A. `_make_avatar` 반환 타입은 `Control`

```gdscript
# ❌ parse 에러
func _make_avatar(path: String) -> TextureRect:
    if path != "" and ResourceLoader.exists(path):
        var tex_rect := TextureRect.new()
        return tex_rect
    var ph := ColorRect.new()    # ← TextureRect 반환인데 ColorRect 반환
    return ph                    # ← "Cannot return value of type \"ColorRect\" because the function return type is \"TextureRect\""

# ✓
func _make_avatar(path: String) -> Control:    # ★ 통합 타입
    ...
```

### B. tscn 파스: `@onready` 평가 순서

`ManorScene`의 자식 노드들을 `@onready`로 잡으면 main.tscn 인스턴스화 순서에 따라 Nil 가능. **반드시 `var + call_deferred("_find_nodes")` 동적 검색 패턴** 사용.

```gdscript
# ❌
@onready var scene_root: Node2D = $CenterRoot/LeftColumn/ManorScene/SceneViewport/SceneViewport/SceneRoot

# ✓
var scene_root: Node2D = null

func _ready() -> void:
    call_deferred("_find_nodes")              # 다음 프레임에 검색

func _find_nodes() -> void:
    scene_root = get_node_or_null("CenterRoot/LeftColumn/ManorScene/SceneViewport/SceneViewport/SceneRoot") as Node2D
```

### C. autoload 멤버 cross-reference

dashboard.gd에서 `TimeManager.day`처럼 autoload 멤버 접근할 때 **글로벌 이름 명시 필수** (SKILL.md "Autoload cross-reference" 함정 참고).

```gdscript
# ❌ parse: Identifier "TimeManager" not declared
# (autoload 인스턴스 이름이 명시 안 됐을 때)
print("%d일" % day)

# ✓
print("%d일" % TimeManager.day)
```

### D. 미존재 자산 — graceful fallback

Wesnoth PNG 중 일부는 faction 디렉터리에 없을 수 있음 (예: `knight.png` 부재 → `general.png`로 대체). `ResourceLoader.exists()` 가드 필수:

```gdscript
if not ResourceLoader.exists(path):
    print("[Dashboard] 자산 없음: %s" % path)
    return                              # sprite 추가 안 함 (캐릭터가 화면에 안 보일 뿐 crash 없음)
```

### E. 결정 큐 표시 UX — 모든 우선순위 모달 + LOW 3초 자동 skip (2026-07-16 v2)

**v1 패턴**: HIGH/CRITICAL만 모달 띄움, LOW/MEDIUM은 알림만 → 큐 30+건 쌓여 답답함.

**v2 패턴** (희정님 직접 선택한 UX):
- **모든 우선순위 모달 표시** — 사용자가 매 결정 인지
- **LOW만 3초 타이머로 자동 skip** — "건너뛰기" 빠른 통과
- **MEDIUM/HIGH/CRITICAL은 무한 대기** — 사용자 결정 필수

```gdscript
# main.gd _show_next_decision() + _on_low_auto_skip()
func _show_next_decision() -> void:
    for d in DecisionQueue.get_all_pending():
        if d.id > _current_decision_id:
            _current_decision_id = d.id
            _populate_modal(d)
            decision_modal.visible = true
            # LOW만 3초 자동 skip
            if d.priority == DecisionQueue.Priority.LOW:
                _auto_skip_timer = get_tree().create_timer(3.0)
                _auto_skip_timer.timeout.connect(_on_low_auto_skip)
            return

func _on_low_auto_skip() -> void:
    if _current_decision_id < 0 or not decision_modal or not decision_modal.visible:
        return
    var default_choice := _default_low_choice(_current_decision_id)
    if default_choice != "":
        _apply_result(default_choice)
    DecisionQueue.resolve(_current_decision_id, {"id": "auto_skip", "label": "(자동 건너뛰기)"})
    _current_decision_id = -1
    if decision_modal: decision_modal.visible = false
    GameManager.resume_from_decision()

func _default_low_choice(decision_id: int) -> String:
    for d in DecisionQueue.get_all_pending():
        if d.id == decision_id:
            match d.type:
                "VISITOR": return "VISITOR_REJECT"
                "FOOD_SHORTAGE": return "FOOD_RATION"
                "DIPLOMACY": return "DIPLOMACY_REFUSE"
                _: return ""
    return ""
```

**판단 가드**: 사용자가 3초 전에 직접 골랐으면 (`_current_decision_id == -1` 이거나 `decision_modal.visible == false`) 자동 skip 콜백이 no-op. 저절로 처리됨.

### F. LB_VERIFY에 화면 검증 단계 추가

LB_VERIFY=1 헤드리스 검증에 화면 인스턴스 자식 카운트 assert 추가 → 시각 검증 없이도 화면 구조가 정상 부팅됐는지 확인:

```gdscript
# main.gd _run_verify() 끝에 추가
print("[N] ManorDashboard 화면 검증")
var dashboard: Control = get_node_or_null("ManorDashboard") as Control
assert(dashboard != null)
var scene_root_node: Node = dashboard.get_node_or_null("...SceneRoot")
assert(scene_root_node != null)
var sprite_count: int = 0
for child in scene_root_node.get_children():
    if child is Sprite2D:
        sprite_count += 1
print("  ✓ Manor Scene sprites: %d" % sprite_count)
assert(sprite_count >= 4, "최소 4개 sprite 필요")
var roster_node: Node = dashboard.get_node_or_null(".../RosterVBox")
var roster_count: int = roster_node.get_child_count()
print("  ✓ Roster rows: %d" % roster_count)
assert(roster_count >= 4)
```

이게 통과해도 **시각 검증은 사용자 데스크탑 필요** — 헤드리스에선 윈도우 자체 안 그려짐. sprite가 정상 부착됐다 + 에셋이 0개가 아니다만 보장.

## 확장 패턴 (v3+ 권장)

- **풍경도 인터랙션**: Sprite2D 클릭 시 결정 모달 (해당 캐릭터가 관련된 결정 큐 filter)
- **시간대별 배경 색 변동**: ColorRect 배경이 `_process`에서 cycle (낮/밤/새벽 색 cycle)
- **용병 hover 시 툴팁**: 커스텀 `_draw`로 sprite 위에 4종 스탯 ProgressBar
- **분기별 풍경도 진화**: season_changed 시그널 → 풀밭→눈밭 ColorRect 교체, 흙길→얼음길
