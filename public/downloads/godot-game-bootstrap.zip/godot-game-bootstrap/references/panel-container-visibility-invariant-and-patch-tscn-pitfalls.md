# PanelContainer 가시성 Invariant + Patch Tool TSCN 함정 + History Ring Buffer

Last Banner v3.x 실전 검증 — 2026-07-16.

## PanelContainer 부모/자식 visible 동기화 invariant

**증상**: PanelContainer(부모)의 자식 VBox(혹은 자식 PanelContainer)의 `visible = false`만 설정해도 **빈 PanelContainer 자체는 화면에 그려짐**. 사용자에게 "호버 안 해도 상태창이 항상 출력"으로 보임.

**원인**: Godot 4 Control 렌더 트리에서 PanelContainer는 자기 자신의 가시성 + 자식 컨테이너의 가시성 + 자식 노드들의 가시성을 **각각 따로 체크**. 빈 상태로도 draw_rect 호출. 자식만 숨겨도 부모가 visible이면 부모의 패널/배경/테두리가 보임.

**inviolate invariant**: 
```
DetailPanel.visible = true  ⇔  detail_vbox(자식).visible = true  (양쪽 표시)
DetailPanel.visible = false ⇔  detail_vbox(자식).visible = false (양쪽 숨김)
```

**이중 안전망 패턴**: tscn에서 `visible = false` 명시 + 코드에서 `_find_nodes()` 시점에 `parent.visible = false` 강제 설정.

```gdscript
# tscn (PanelContainer)
visible = false

# 코드 (manor_dashboard.gd _find_nodes())
detail_panel = get_node_or_null("CenterRoot/LeftColumn/ManorScene/SceneHost/DetailPanel") as PanelContainer
if detail_panel:
    # 기본 숨김 — 호버할 때만 표시
    detail_panel.visible = false                          # ← 부모 자체 숨김 (필수)
    detail_vbox = detail_panel.get_node_or_null("VBox") as VBoxContainer
    if detail_vbox:
        detail_vbox.visible = false                      # ← 자식도 숨김 (belt-and-suspenders)

# 호버 시 — 둘 다 visible=true 명시
func _show_character_detail(character: Dictionary) -> void:
    if detail_vbox == null:
        return
    for child in detail_vbox.get_children():
        child.queue_free()
    # ... 라벨 추가 ...
    if detail_panel:                                     # ← 부모 가시성 명시
        detail_panel.visible = true
    detail_vbox.visible = true                           # ← 자식 가시성 명시

# 호버 해제 — 둘 다 visible=false
func _on_character_unhover(character: Dictionary) -> void:
    # ... sprite 축소 ...
    if detail_vbox:
        detail_vbox.visible = false                      # ← 자식 숨김
        if detail_panel:
            detail_panel.visible = false                 # ← 부모도 숨김 (둘 다 안 하면 빈 패널 보임)
```

**진단법**:
- LB_VERIFY: `assert(detail_vbox.visible == false, "DetailPanel 기본 숨김이어야 함")` ✓
- 화면: 스크린샷에 "호버 안 한 상태인데 빈 검은 패널이 보인다" → 빈 패널 = 부모만 안 숨긴 경우

**다른 케이스**: Control의 모든 컨테이너 종류 (PanelContainer, MarginContainer, VBoxContainer 등) 동일. **"자식만 숨기고 부모 visible = 빈 컨테이너가 보임"** 이게 Godot 4 Control의 기본 동작. 양쪽 다 명시할 것.

---

## Patch Tool TSCN 클로징 태그 함정

**증상**: `patch` 도구로 `.tscn` 파일을 변경할 때 본문 안에 `</ratio>`, `</prohibited>`, `</something>` 같은 잘못된 클로징 태그가 끼어들어가서 파스 에러 발생. 예:

```
[node name="DetailPanel" type="PanelContainer" parent="..."]</prohibited>
visible = false
```

이러면 Godot이 tscn 로드 시 DetailPanel 노드 정의가 `</prohibited>`로 끝나버림 → `Parse Error` or `Couldn't load resource`.

**함정 패턴 5종 (2026-07-16 실전)**:
1. `</ratio>` (한 글자 뒤섞임)
2. `</prohibited>` (실수로 생성)
3. `</node>` 안에 이상한 인자 (예: ratio 키워드)
4. 패치 매칭 실패 시 fallback으로 잘못된 태그 사용
5. multi-arg `print("%s %s" % (a, b))`를 GDScript가 파스 못함

**해결 — 항상 tscn 검증**:
```bash
# 패치 적용 후
grep -n "^</.*>" /Users/mac/work/<game>/scenes/*.tscn
# 또는 read_file로 tscn 마지막 5~10줄 확인
```

**자동화 — 검증 헬퍼 함수** (LB_VERIFY 시작 부분에):
```gdscript
# 작업 완료 전 tscn 파일 빠른 검증
func _verify_tscn_files() -> void:
    var tscn_files: Array = []
    var dir := DirAccess.open("res://")
    if dir:
        dir.list_dir_begin()
        var name := dir.get_next()
        while name != "":
            if name.ends_with(".tscn") or name.ends_with(".tscn.uid"):
                tscn_files.append("res://" + name)
            name = dir.get_next()
        dir.list_dir_end()
    # 각 파일 로드 시도 — parse 에러나면 즉시 false 반환
    for path in tscn_files:
        var res: Resource = load(path)
        if res == null:
            push_error("[tscn] 로드 실패: %s" % path)
            assert(false, "tscn parse 실패: %s" % path)
    print("[OK] %d개 tscn 파일 모두 로드 성공" % tscn_files.size())
```

`LB_VERIFY=1 godot --headless` 첫 단계에서 호출 → 실패 시 어떤 파일 깨졌는지 즉시 식별.

**multi-arg print 함정**:
```gdscript
# ❌ Parse Error: Expected closing ")" after grouping expression
print("[X] %s %s" % (a, b))

# ✓ 어레이로
print("[X] %s %s" % [a, b])

# ✓ 인라인 미디 변수
var mode_state: String = "OK" if connection else "NULL"
print("[X] mod=%s state=%s" % [mode_state, other_state])
```

**진단법**: `godot --headless --quit-after 5 2>&1 | grep "Parse Error"` 로 즉시 찾기.

---

## GameWorld History Ring Buffer + 라인 차트 패턴 (Last Banner v3.1)

**시나리오**: 자동 진행 게임에서 자원 변동 시각화. 매 day_changed emit에 snap shot 기록 → 7일 ring buffer → Line chart with Control._draw().

### GameWorld 확장 — 일별 history ring buffer

```gdscript
const HISTORY_MAX_DAYS := 7
var history: Array = []   # [{day, gold, food}, ...] 오래된→최신, 최대 7일
var _last_history_day: int = -1

## 일별 스냅샷 — 라인 차트용 history ring buffer
func record_day_snapshot(day: int) -> void:
    var snap := {
        "day": day,
        "gold": gold,
        "food": food,
    }
    if _last_history_day == day and not history.is_empty():
        history[-1] = snap   # 같은 날 중복 방지
    else:
        history.append(snap)
        _last_history_day = day
        while history.size() > HISTORY_MAX_DAYS:
            history.pop_front()   # ring buffer (고장 X)

func reset_history() -> void:
    history.clear()
    _last_history_day = -1
```

**EventEngine._on_day에서 호출**:
```gdscript
func _on_day(day: int) -> void:
    _decisions_today = 0
    GameWorld.apply_daily_economy()
    GameWorld.record_day_snapshot(day)   # ← 일별 history 기록
```

**save_state/load_state에 history 직렬화** — 사용자 미진입 한 달 후에도 차트가 보존:
```gdscript
func save_state() -> Dictionary:
    return {
        # ... 기존 필드 ...
        "history": history.duplicate(),
        "_last_history_day": _last_history_day,
    }

func load_state(data: Dictionary) -> void:
    history.clear()
    for h in data.get("history", []):
        history.append(h)
    _last_history_day = data.get("_last_history_day", -1)

func start_new_game(slot: String = "default") -> void:
    GameWorld.reset_history()   # ← 새 게임은 history 리셋
    # ... 기존 로직 ...
```

### 라인 차트 — Control._draw + draw.connect

```gdscript
# tscn (Control 부모)
ChartCard = PanelContainer
ChartCanvas = Control with mouse_filter=2

# manor_dashboard.gd
chart_canvas = get_node_or_null(".../ChartCanvas") as Control
if chart_canvas:
    chart_canvas.draw.connect(_draw_chart)

func _refresh_chart() -> void:
    if chart_canvas:
        chart_canvas.queue_redraw()   # 다음 프레임에 _draw_chart 호출

func _draw_chart() -> void:
    if not chart_canvas: return
    var history: Array = GameWorld.history
    var size: Vector2 = chart_canvas.size
    var padding := Vector2(28, 14)
    var plot_w: float = max(size.x - padding.x * 2, 0.0)
    var plot_h: float = max(size.y - padding.y * 2, 0.0)

    chart_canvas.draw_rect(Rect2(Vector2.ZERO, size), Color(0.05, 0.04, 0.03, 0.4))
    if history.size() < 1:
        var default_font: Font = ThemeDB.fallback_font
        chart_canvas.draw_string(default_font,
            Vector2(8, size.y / 2),
            "(데이터 누적 중)", HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Color(0.6, 0.6, 0.6, 0.7))
        return

    # max 정규화 (자원이 다른 스케일을 가질 때 한 차트에 같이)
    var max_gold: int = 1
    var max_food: int = 1
    for h in history:
        if int(h.get("gold", 0)) > max_gold: max_gold = int(h.get("gold", 0))
        if int(h.get("food", 0)) > max_food: max_food = int(h.get("food", 0))

    # 그리드 (수평선 3개)
    for i in range(4):
        var y: float = padding.y + plot_h * float(i) / 3.0
        chart_canvas.draw_line(
            Vector2(padding.x, y),
            Vector2(padding.x + plot_w, y),
            Color(0.3, 0.3, 0.3, 0.5), 1.0
        )

    # 자원별 라인
    _draw_series(history, "gold", Color(0.95, 0.78, 0.2), padding, plot_w, plot_h, max_gold)
    _draw_series(history, "food", Color(0.6, 0.85, 0.4), padding, plot_w, plot_h, max_food)

func _draw_series(history: Array, key: String, color: Color,
        padding: Vector2, plot_w: float, plot_h: float, max_val: int) -> void:
    var n: int = history.size()
    if n < 1: return
    var denom: float = float(max(max_val, 1))
    var points: Array = []
    for i in range(n):
        var x: float = padding.x + plot_w * (float(i) / max(float(n - 1), 1.0))
        var v: int = int(history[i].get(key, 0))
        var y: float = padding.y + plot_h * (1.0 - float(v) / denom)
        points.append(Vector2(x, y))
    for i in range(points.size() - 1):
        chart_canvas.draw_line(points[i], points[i + 1], color, 2.0)
    for p in points:
        chart_canvas.draw_circle(p, 2.0, color)
```

**진행 함수 — 자원 변동 시 자동 갱신**:
```gdscript
func _on_tick(_game_time: int) -> void:
    _update_time_of_day_colors()   # 시간대 그라디언트
    _refresh_chart()                # 매 tick마다 갱신
```

### 차트 위치 — 풍경도 안 분리

상세 Layout 함정은 `references/manor-dashboard-screen-with-control-node2d.md`에 위임. 두 패널을 풍경도 안 좌우 분할하여 안 가림:

| 패널 | 위치 | anchor | offset |
|---|---|---|---|
| ChartCard | 풍경도 좌하단 | `top=1, bottom=1` | `left=16, top=-100, right=196, bottom=-20` (180×80) |
| DetailPanel | 풍경도 우상단 | `top=0, bottom=0` | `left=-340, top=20, right=-16, bottom=-100` (324×80) |

다른 곳에 둘 경우 흙길 / 모병(Elgar) 캐릭터 / 방문객 카드 / 일간 변동 카드와 겹침 가능.

### LB_VERIFY [12.5.5] 차트 검증 패턴

```gdscript
print("[12.5.5] 차트 검증")
print("  history 크기: %d" % GameWorld.history.size())
assert(GameWorld.history.size() >= 1, "history ≥1일 필요")
assert(GameWorld.history.size() <= 7, "history ≤7일 ring buffer")

var chart_canvas: Control = get_node_or_null(
    "ManorDashboard/CenterRoot/LeftColumn/ManorScene/SceneHost/ChartCard/ChartCanvas"
) as Control
if chart_canvas:
    chart_canvas.queue_redraw()
    await get_tree().process_frame
    print("  ✓ 차트 queue_redraw 호출 성공")
```

### 확장 (v3.2+ 옵션)

- **호버 툴팁** — 차트 점에 hover하면 `(Day N) gold=X food=Y` 표시
- **예측 라인** — 점선으로 다음 7일 예측 (현재 추세 기반 linear regression)
- **CSV 덤프** — 매 7일마다 history JSON 저장 → 재진입 시 즉시 표시
- **성능 비교** — 같은 시간대 (오전 9시 vs 오후 9시) 자원 변동 패턴 시각화
</content>
</invoke>