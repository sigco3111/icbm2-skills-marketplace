# Godot Web Mobile UI 함정 + 한글 폰트

2026-07-15 last-banner 실전에서 만난 **모바일 viewport + 한글 폰트** 3가지 함정.

## 증상 vs 원인 매트릭스

| 증상 (사용자 보고) | 디버그 pane 단서 | 진짜 원인 |
|---|---|---|
| 모바일에서 검은 화면, 데스크탑에서 정상 | `canvas: 1290x2325` 정상 | anchor 미사용 → 컨트롤이 viewport 밖 |
| 모든 게 OK인데 화면 검은색 | `canvas non-black pixels: 0/1024` | `#status` div가 부팅 후에도 visible → 캔버스 덮음 |
| 메뉴는 보이는데 한글만 □ | 디버그 pane에 한글 정상 | Godot 기본 폰트가 한국어 글리프 미포함 |
| 모바일에서 status-notice 안 사라짐 | 모든 missing features=[] | 모바일 renderer fallback + lazy fetch 후 동기 작업 |

## 함정 1 — 모바일 viewport anchor 미사용

### 증상
- 데스크탑 (1280x720): 메뉴 정상 표시
- 모바일 세로 (예: iPhone Safari 1290x2325): 검은 화면처럼 보임
- 디버그 pane `canvas rect: 0,0,1290,2325` 정상

### 원인
`offset_left=24, offset_top=600, offset_right=884, offset_bottom=660` 같은 **절대 픽셀 좌표**는 viewport_width/height에 종속. 모바일 세로 (1290x2325)에서는 컨트롤이 화면 아래 또는 우측 밖으로 나감. `window/stretch/mode="canvas_items"`는 CanvasItem의 transform만 stretch하고, **Control의 anchor는 별개**.

### Fix
모든 Control에 anchor 비율 (0~1) 사용. main.tscn 예시:

```ini
[node name="BG" type="ColorRect" parent="UI"]
anchor_right = 1.0
anchor_bottom = 1.0
offset_right = 0.0
offset_bottom = 0.0
color = Color(0.08, 0.07, 0.06, 1)

[node name="Title" type="Label" parent="UI"]
anchor_left = 0.5
anchor_right = 0.5
offset_left = -200.0
offset_right = 200.0
text = "Last Banner"
horizontal_alignment = 1

[node name="ButtonRow" type="VBoxContainer" parent="UI"]
anchor_left = 0.5
anchor_top = 0.55
anchor_right = 0.5
anchor_bottom = 0.95
offset_left = -200.0
offset_right = 200.0
theme_override_constants/separation = 16

[node name="StartButton" type="Button" parent="UI/ButtonRow"]
custom_minimum_size = Vector2(0, 64)
text = "새 게임"
```

핵심 패턴:
- BG: `anchor_right = 1.0; anchor_bottom = 1.0` (offset 모두 0) → 화면 전체 cover
- 가로 중앙 정렬: `anchor_left = right = 0.5; offset_left = -width/2`
- 버튼은 `VBoxContainer` 안에 묶고 `custom_minimum_size = Vector2(0, 64)` → 모바일 탭 영역

`project.godot`:
```ini
[display]
window/stretch/mode="canvas_items"
window/stretch/aspect="expand"
```

## 함정 2 — #status div가 캔버스 덮음

### 증상
- 모든 시스템 OK (`Engine.getMissingFeatures: []`)
- 디버그 pane: `canvas: 1290x2325`, `WebGL2: OK`
- `canvas non-black pixels: 0/1024` (canvas는 큰데 픽셀은 모두 검정)
- status div가 `visibility:visible`

### 원인
Godot 4 Web export의 `index.html`이 부팅 진행률 표시용으로 `#status` div를 페이지에 띄움. 정상적으로는 `engine.start()` 완료 후 `setStatusMode('hidden')`이 호출되어 숨겨지는데, 모바일 + lazy fetch 환경에서는 **status 모달이 안 닫히는 케이스** 발생. status div가 `display: flex` + 어두운 배경 + z-index auto로 캔버스 위에 덮음.

### Fix — inject-debug-pane.sh에 CSS 추가
`templates/inject-debug-pane.sh.tpl`의 `<style>` 블록에 다음 추가:

```css
/* status div가 부팅 후에도 visible이면 캔버스를 덮음 → 강제 hide */
#status {
  display: none !important;
  visibility: hidden !important;
  pointer-events: none !important;
}
#status-notice, #status-progress {
  display: none !important;
  visibility: hidden !important;
}
```

`!important` 필수 (Godot 런타임이 직접 style attribute 설정하는 것보다 우선). 빌드 파이프라인에서 자동 주입되므로 사용자 추가 작업 없음.

## 함정 3 — 한글 폰트 미적용

### 증상
- 메뉴 4개 보임 + 디버그 pane 한글 정상 출력
- 게임 내 한글 텍스트만 □ 깨짐

### 원인
Godot 4의 기본 폰트 (NotoSans fallback)는 한국어 글리프 미포함. `project.godot`의 `[gui] theme/custom_font="res://assets/fonts/X.ttf"`는 4.7에서 일관성 없게 작동 — 모바일 Web export + `renderer/rendering_method.mobile="gl_compatibility"` 환경에서 특히 무시되는 듯.

### Fix — main.gd의 _ready에서 재귀 적용

```gdscript
const KOREAN_FONT := preload("res://assets/fonts/UnDotum.ttf")

func _ready() -> void:
    var theme := Theme.new()
    theme.default_font = KOREAN_FONT
    theme.default_font_size = 24
    _apply_theme_recursive(self, theme)
    # ... 이후 status_label.text 설정 등

func _apply_theme_recursive(node: Node, theme: Theme) -> void:
    if node is Control:
        (node as Control).theme = theme
    for child in node.get_children():
        _apply_theme_recursive(child, theme)
```

### 폰트 선택 가이드

| 폰트 | 크기 | 글리프 | 출처 | 권장 |
|---|---|---|---|---|
| UnDotum.ttf | 2.1MB | 한글+라틴 | FreeCiv 풀 | ✅ 게임 UI |
| fireflysung.ttf | 15MB | 한자+한글+라틴 | FreeCiv 풀 | ⛔ 너무 큼 |
| sazanami-gothic.ttf | 7.3MB | 일어+한자 | FreeCiv 풀 | △ 일어 게임만 |
| NotoSansTC-Regular.ttf | ~3MB | 번체+간체 | Veloren | △ 번체 게임만 |
| GoNotoCurrent.ttf | 15MB | 통합 | Veloren | ⛔ 통합 게임 아니면 과함 |

`assets/fonts/UnDotum.ttf`로 심볼릭 링크:
```bash
mkdir -p ~/work/<game>/assets/fonts
ln -sf "/Users/mac/work/game-assets/sources/freeciv/data/themes/gui-sdl2/human/UnDotum.ttf" \
       ~/work/<game>/assets/fonts/UnDotum.ttf
```

fonts 폴더엔 **.gdignore 안 만들기** (폰트는 Godot import되어야 FontFile 리소스로 사용 가능). pck 크기 영향: +2MB 정도, Vercel 한도 무관.

### Label 멀티라인 함정 (보너스)

`Label.autowrap_mode` 값:
- `0` (off) = 한 줄로 자름
- `1` (arbitrary) = 단어 단위 wrap (영문)
- `2` (word) = ⚠ Godot 4에서 off로 작동하는 함정 — 멀티라인 안 보임
- `3` (word_smart) = 단어 단위 wrap

**한국어 텍스트에는 `autowrap_mode=3` (word_smart) 또는 그냥 `\n` 직접 삽입 + 충분한 영역**. `\n`은 항상 작동하지만 영역이 좁으면 잘림.

## 진단 pane에 추가할 항목

`templates/inject-debug-pane.sh.tpl`의 `dumpState()`에 다음 2개 항목 추가:

```js
// canvas 실제 픽셀 데이터
try {
  var probe = document.createElement('canvas');
  probe.width = 32; probe.height = 32;
  var pctx = probe.getContext('2d');
  pctx.drawImage(document.getElementById('canvas'), 0, 0, 32, 32);
  var data = pctx.getImageData(0, 0, 32, 32).data;
  var nonBlack = 0;
  for (var i = 0; i < data.length; i += 4) {
    if (data[i] > 10 || data[i+1] > 10 || data[i+2] > 10) nonBlack++;
  }
  show('canvas non-black pixels (32x32 sample): ' + nonBlack + '/1024');
} catch(e) { show('canvas pixel check err: ' + e.message); }

// canvas rect (anchor 미사용 함정 진단)
show('canvas rect: ' + JSON.stringify(c.getBoundingClientRect()));
```

`non-black pixels: 0/1024` → 함정 2 (status div 덮음)  
`non-black pixels: 1024/1024` 정상 → 게임 씬 렌더링 OK, 다른 문제 (한글 폰트 등)

## 종합 점검 순서 (원격 검은 화면 보고 시)

1. 디버그 pane에서 `canvas: 300x150` → 부팅 안 됨 (WebGL2/COEP 등 환경 문제) → COEP 헤더 확인
2. `canvas: 1290x2325` + `non-black: 0/1024` → 함정 2 (status div) → CSS로 강제 hide
3. `non-black: 1024/1024` + 한글 깨짐 → 함정 3 (폰트) → KOREAN_FONT theme 적용
4. `non-black: 1024/1024` + 데스크탑 OK인데 모바일만 검정 → 함정 1 (anchor) → anchor 비율로 재작성
5. 모든 정상인데 검정 → 다른 원천 (renderer 등) → `renderer/rendering_method.mobile="gl_compatibility"` 명시 확인