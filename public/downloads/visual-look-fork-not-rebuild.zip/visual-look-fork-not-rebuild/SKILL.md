---
name: visual-look-fork-not-rebuild
title: Visual 룩은 OSS fork 후 데이터만 교체
description: Fork MIT/Apache OSS clone and swap data, not pixels.
trigger: User wants a non-trivial visual look or says "껍데기 그대로 가져오고 내용만 교체".
---

# Visual 룩 = Fork, Not Rebuild

## Why this skill exists

Three or more attempts to recreate a recognizable visual look from scratch (Twin Lab isometric control room → PixiJS Graphics primitives → even a Claude-Office-sprite fork) kept failing on proportion, animation, and decoration density. The look the user wants **already exists as open source** in 90% of cases — recreating it pixel-by-pixel is a losing bet because:

- The visual craft (proportions, asset quality, animation easing, decoration density) was tuned by the original author over many iterations
- Our PixiJS/Canvas/Three.js primitives lack the asset library (sprite sheets, room backgrounds, character walk cycles)
- Even with measurement comparisons, the gaps accumulate: pixel-perfect 1:1 in proportions but animation off, or decoration off but proportions off
- **Time and tokens spent on re-implementation exceed the time to clone + customize**

## Decision rule

When the user references a recognizable visual look:

1. **In the first 1–2 turns**, before writing any custom code:
   - Identify the source (Twin Lab, Wordle, HackerNews, ...)
   - Search GitHub for "isometric office", "control room dashboard", "<product> clone", "<product> open source" (see `references/search-queries.md`)
   - Find an MIT/Apache-2.0 fork with the closest visual match (PixiJS/Phaser for 2D, Three.js/Godot for 3D, SVG/CSS for layout)
2. **Present the fork plan as the FIRST option** in the choice matrix, not after "build from scratch"
3. **Treat "just build it" / "처음부터 짜" as a yellow flag** — re-ask once before 1+ hour of custom work

When the user explicitly says **"껍데기 그대로 가져오고 내용만 교체"**, **"fork 해"**, **"그냥 clone 해서 바꿔"** → this is a definitive signal. Stop, fork, customize content.

## Fork-and-customize workflow

```
[user asks for X 룩]
    ↓
[search GitHub for X-clone / X-fork]
    ↓
[present fork option FIRST]
    ↓
[user picks fork]
    ↓
[clone OSS into /tmp/<oss>-cloned (reference)]
    ↓
[strip project-specific layers: auth, persistence, config]
    ↓
[wire user's domain data into same UI shapes]
    ↓
[preserve original README + LICENSE + CREDITS]
    ↓
[build + dev server + verify]
    ↓
[push with fresh-clone fallback if remote corruption]
```

### Stripping layers (in this order)

1. **Auth/identity**: remove GitHub OAuth, server sessions, telemetry. Replace with simulation mode.
2. **Persistence**: replace localStorage/IndexedDB with stateless render or in-memory mock.
3. **Backend bridge**: remove WebSocket/HTTP servers, MCP integrations. Replace with `useEffect` pollers on `public/state.json`.
4. **Config knobs**: replace real-config files with inline defaults (frequent trap: `await import('../config.json')` fails under ESM).
5. **Theming**: keep theme structure but add a domain-name mapping (e.g. `HERMES_DEPARTMENT_DISPLAY` overrides original character display names).
6. **Assets**: keep all decorative sprites (cats, plants, props, furniture) — they're MIT/CC0 licensed and the look IS the assets.

### Pitfalls

- **Don't `git remote set-url` from within a delegate**: delegates that clone OSS often leave `origin` pointing at the original OSS repo. Verify `git remote -v` before every push; if pointing at W17ant/Claude-Office.git or similar, `git remote set-url origin https://github.com/sigco3111/<our-repo>.git` BEFORE push.
- **Don't trust "Initial commit" push failures as remote corruption immediately**: first try `--force-with-lease`. If still failing with `b0bb8de7`-style missing object errors, switch to the fresh-clone pattern (see `references/git-push-fresh-clone.md`).
- **Don't add ESM `await import('../config.json')` patterns**: replace with inline const defaults. Top-level await + missing file + ESM = build break.
- **Don't trust the first 100% visual fidelity comparison**: after fork, the visual will look ~95% there. Show the user; if they ask for adjustments, fix specific issues rather than rebuilding. Iterate on top of the fork.

## References

- `references/search-queries.md` — GitHub search keywords per visual domain (isometric office, dashboard, control room, ...)
- `references/git-push-fresh-clone.md` — fresh clone pattern for unpacking `unpack failed` push errors (the most common fork-push failure mode)
- `references/case-2026-08-04-twin-lab.md` — worked case: Twin Lab → 5 attempts → Claude-Office fork. Time/token ledger.