# GitHub Search Queries by Visual Domain

When the user references a recognizable visual look, search GitHub with these domain-keyword combinations. Prefer MIT/Apache-2.0 licenses. Prefer repos with active commits in last 6 months. Prefer repos that have a live demo (Vercel, Netlify, gh-pages) or `public/`, `dist/` build output ready to fork.

## Isometric office / control room / pixel-art workplace

```
isometric office
isometric control room
pixel office
2.5D office game
isometric dashboard
phaser isometric
pixi.js isometric game
control room dashboard
operation center visualization
isometric building game
mapbox isometric
city builder
office simulator
tower tycoon
claude office (for AI agent visualization variants)
hermes office (Hermes/CronWatch variants)
```

**Top candidates** (from real cases):
- `W17ant/Claude-Office` (56⭐, MIT) — Twin Lab equivalent, AI agent visualization
- `askmojo/moltcraft` (32⭐, MIT) — Vanilla JS isometric, npm-installable
- `honorstudio/claude-ville` (13⭐, MIT) — Multi-CLI agent visualization
- `victorqribeiro/isocity` (3246⭐, MIT) — Base isometric engine
- `elchininet/isometric` (233⭐, Apache-2.0) — SVG isometric path library
- `Gaurav2693/ai-office` (44⭐, MIT) — 3D Three.js isometric, has live Vercel demo

## Dashboard / monitoring / observability

```
observability dashboard
metrics dashboard
grafana clone
datadog clone
monitoring dashboard
uptime dashboard
react dashboard
```

## Game clones (general)

```
<game-name> clone
<game-name> open source
<game-name> typescript
```

Wordle → `lyziwizard/wordle-clone`, HackerNews → various Next.js clones. **Always search** before building from scratch.

## Note on Vercel-deployable forks

If the user wants fast iteration + GitHub Pages deployment, prioritize forks that:
1. Use **Vite** (not Webpack/CRA — Vite is faster, has fewer build pitfalls)
2. Have **shadcn/ui** or similar Tailwind components (modern, accessible, easy to skin)
3. **No backend required** OR have a "demo mode" / static fallback
4. License: MIT or Apache-2.0 (permissive, allows commercial use)

## Quick smoke-test before recommending

```bash
# 1. License check
gh repo view <owner>/<repo> --json licenseInfo,name
# 2. Recent activity
gh repo view <owner>/<repo> --json pushedAt
# 3. Star count + archived
gh repo view <owner>/<repo> --json stargazerCount,isArchived
# 4. Live demo URL in README?
gh repo view <owner>/<repo> --json homepage,url
```