# Case Study — Twin Lab → 5 attempts → Claude-Office fork

## Timeline (2026-08-04)

| # | 시도 | 결과 | 누적 시간 |
|---|------|------|----------|
| 1 | r3f 1단계 풀스택 부트스트랩 | 동작, 캐릭터 박스 위에 떠있음 + 라벨 거꾸로 | ~7분 |
| 2 | PixiJS v8 2.5D 풀 재부트스트랩 | 동작, 비율/애니메이션 부자연스럽 | ~25분 |
| 3 | Twin Lab 정밀 분석 + 비율/애니메이션 1:1 차용 | 동작, 사용자가 여전히 불만족 | ~30분 |
| 4 | W17ant/Claude-Office 캐릭터 PNG 차용 + rooms.ts 패턴 이식 | 동작, 룩이 Twin Lab과 여전히 차이 | ~30분 |
| 5 | **W17ant/Claude-Office 완전 fork + Hermes 데이터만 교체** | **🟢 LIVE** — 만족 | ~25분 |

총 ~2시간, 6번의 위임 + 수동 검증 + push 단계.

## 핵심 깨달음

시도 1~4의 본질적 문제: **Twin Lab의 룩은 자체 자산 + 다듬어진 비율 + 누적된 애니메이션 + 디테일이 결합된 결과**. 우리 PixiJS Graphics primitives로 1:1 시도는 비율은 맞출 수 있어도 디테일/애니메이션에서 항상 어긋남.

시도 5는 **껍데기(Twin Lab 룩 거의 그대로) + 내용(Hermes 부서명)만 교체** — 룩은 원작이 직접 다듬은 그 자체이고 우리는 데이터/이름 매핑만 신경 씀.

## 사용자 결정 흐름 (한국어)

| 시점 | 사용자 발언 |
|------|------------|
| 1단계 후 | "사람이 공중에 떠있고 비주얼도 별로임. 3d말고 2.5d로 다시 해보는 건 어떨까?" |
| PixiJS 2.5D 후 | "디자인이 처참함. 오픈소스중 참고할 만한 것이 없을까?" |
| OSS 발견 + 클론 패턴 후 | "물건의 크기나 사람의 크기등등이 현실적이지 않아. 원본은 괜찮던데....다시 원본을 분석하고 비슷한 비율로 변경해줘" |
| (마침내) | "불만족스러움. 차라리 껍데기는 클로드오피스를 그대로 사용하고 내용만 우리가 원하는데로 변경하는 것은 가능한가?" |

이 시퀀스가 **visual 룩 = fork, not rebuild** skill의 정당성.

## 산출물

- `https://github.com/sigco3111/hermes-control-room` (public, MIT)
- `https://sigco3111.github.io/hermes-control-room/` (live, GitHub Pages)
- 5개 보존 브랜치:
  - `main` (HEAD) — Claude-Office fork + Hermes 매핑
  - `gh-pages` — 배포용 빌드
  - `phase2-pixijs` — 2~3번째 시도 (보존)
  - `phase2-our-attempt` — 2번째 시도 (보존)
  - `phase3-claude-office-fork` — 4번째 시도 (보존)

## 보존 교훈

1. **시각 룩은 처음부터 짜지 말 것** — OSS clone → 도메인 매핑이 거의 항상 정답.
2. **위임 remote 검증 필수** — delegate가 OSS clone하면 `origin`이 OSS repo 그대로 → 매 push 직전 `git remote -v` 확인.
3. **`unpack failed`는 fresh clone으로** — force-with-lease가 안 먹힐 때 30초 우회 패턴.
4. **`config.ts`의 top-level await + JSON import는 ESM에서 깨짐** — inline const로 대체.
5. **`dev server`는 Hermes idle 후 죽음** — 매번 `background=true` + curl 검증 (메모리화됨).
6. **사용자 "처리해줘/해/뭐 권장하지?" 같은 신호** — 자동위임 OK, but 큰 결정 단계마다 게이트.

## 향후 세션용 패턴

새 사용자가 "X 사이트처럼 만들어줘" 같은 요청 시:

1. 첫 2 turn 안에는 fork 옵션 제시 (build-from-scratch 옵션보다 먼저)
2. MIT/Apache OSS 후보 3개 정도 탐색 후 비교
3. fork 옵션 선택되면 → 본 skill (`visual-look-fork-not-rebuild`) 워크플로 따름
4. 진행 중 막히면 → 본 skill의 pitfalls 참조