---
name: one-shot-game-orchestration
description: Use when recreating multi-subsystem games with Kanban.
version: 1.0.0
author: HyeRin
license: MIT
metadata:
  hermes:
    tags: [game-port, multi-model, fps, three.js, phase-gate, opus-5-comparison]
    related_skills: [kanban-project-delivery, github-repo-triage, cpp-game-koreanization, game-autopilot]
---

# One-shot Game Orchestration — 대규모 멀티서브시스템 게임 점진 제작

## 트리거

다음 중 하나라도 매칭되면 발동:

- 사용자가 **원샷 프롬프트**(single prompt)로 FPS / 게임 / 멀티서브시스템 엔진을 칸반으로 만들고 싶다
- **Opus 5 / GPT-5 / GLM-4.6** 등 타 모델의 원샷 산출물을 **reference**로 박고 다른 모델(M3 등)이 따라올 수 있는지 측정
- **mshumer/Claude-of-Duty** 같은 대형 멀티서브시스템(11서브시스템) 게임을 칸반 Phase 게이트 + imagediff 시각 회귀 게이트로 재현
- ARCHITECTURE.md 같은 11서브시스템 계약서가 있고, ARCHITECTURE 그대로 implementation 만들기
- "AAA quality", "utterly perfect" 같은 **정성만 있는 원샷 프롬프트**를 M3/Llama 등 컨텍스트 작은 모델로 분해 실행

트리거 안 됨: 단일 파일 게임 프로토타입 → `cpp-game-koreanization` / `love-lua-game-fork` / `pixijs` 클래스 스킬. 단순 게임 후속 작업 → `kanban-project-delivery` 만으로 충분.

## 핵심 직관 — 왜 이게 별도의 스킬인가

mshumer는 Opus 5 한 세션에 1.5일 + 11서브시스템을 in-context로 동시 구축. M3 / GLM-4.6 / GPT-5 등 컨텍스트/도구 활용이 다른 모델은 **/loop + 멀티에이전트 fan-out 패턴을 단독으로 흉내내지 못한다**. 그래서:

1. **원본 /loop 프롬프트를 그대로 쓰면 무한 자기만족 루프** (외부 critic 없음)
2. **"AAA quality" 같은 정성 지시만으로는** M3가 "어떤 디테일을 잡아야 AAA인지" 모름
3. **컨텍스트가 작아서** ARCHITECTURE.md 11서브 + critic 루프 + 비교 reference 한 번에 못 넣음

진짜 해법: **원본 원샷 프롬프트 + ARCHITECTURE.md + 모델 비교 reference → 5-Phase 게이트로 분해 → 각 Phase 끝 imagediff 게이트로 비교**. 이게 이 스킬의 본질.

## 5-Phase 게이트 (B 패턴, 2026-07-27 claude-of-duty-ko 실측)

| Phase | 카드 | 핵심 시스템 | Auto/Human Verifiable | Opus 5 점수 기여 |
|---|---|---|---|---|
| **Phase 1** | 4~5장 | 엔진 코어 + 렌더 + 월드 + 통합스모크 | Auto (build/test) + Human (씬 시각) | 11서브 중 3 (engine/render/world) |
| **Phase 2** | 5~7장 | 머티리얼 + 스카이 + audio | Auto (material library) + Human (시각) | 11서브 중 3 (materials/sky/audio) |
| **Phase 3** | 5~7장 | player + weapons + AI | Human-verifiable (mshumer 약점) | 11서브 중 3 (player/weapons/ai) |
| **Phase 4** | 3~5장 | fx + ui + integrated polish | Human-verifiable (playtest) | 11서브 중 2 (fx/ui) |

**실측 성공 확률 (B 게이트, claude-of-duty-ko)**:

| 단계 | 조건부 확률 | 누적 |
|---|---|---|
| Phase 1 통과 | 75% | 75% |
| Phase 2 통과 | 55% | 41% |
| Phase 3 통과 | 40% | 16% |
| Phase 4 통과 | 65% | 11% |
| **어딘가 의미 있는 산출물** | — | **89%** |

핵심: **Phase 4까지 (전체 완성) 확률 11%. 의미 있는 산출물 확률 89%**. d 풀버전(한꺼번에 20~30장)보다 B 게이트가 리스크 캡에 훨씬 유리.

## 표준 흐름 (사용자 → 운영자 → 워커)

### 1. 사용자 결정 단계 (4옵션 + 추천)

| 결정 | 선택지 | 추천 |
|---|---|---|
| **Phase 1 카드 수** | A-2 (5장, --max 1) / A-3 (7장, 머티리얼+스카이 포함) / A-4 (5장, --max 2) / B-1 (자동 진행) | **A-2** |
| **각 Phase 끝 결정 패턴** | 진행 / 보류 / 모델 비교 추가 / 종료 | **사용자 4옵션** |
| **golden image 박기** | Phase 1 시작 전 Opus 5 첫 프레임 캡처 / Phase 1 끝에 캡처 / 게이트 없이 진행 | **Phase 1 끝에 캡처** |

### 2. 운영자 setup

```bash
# 1. 보드 + 디렉터리
mkdir -p /Users/mac/work/<project>-ko
cd /Users/mac/work/<project>-ko
mkdir -p prompts logs tools captures
hermes kanban boards create <slug>

# 2. 프롬프트 로그 빈 파일
write_file path="prompts/PROMPT-LOG.md" content="<템플릿 — templates/prompt-log.md 참조>"

# 3. 각 Phase 카드 body 파일 (한글 + 영문 번역 가능)
write_file path="prompts/phase-X.Y-body.md" content="<한글 본문, 영문 번역은 PROMPT-LOG.md에 동시 기록>"

# 4. 카드 등록 (★ 함정 12: --body-file 옵션 부재)
BODY=$(cat prompts/phase-X.Y-body.md)
hermes kanban create "Phase X.Y — ..." --body "$BODY" --assignee coder --initial-status blocked
```

### 3. 디스패치 패턴 — 1장씩 + parent 완료 시 자동 promote

```bash
# ❌ 5장 일괄 dispatch (함정 13 — dispatcher 5-카드 동시 claim)
# ❌ unblock 후 대기 (함정 13 — 비대화 환경 hang + 동일 문제)

# ✅ 1장씩 dispatch 패턴
hermes kanban link t_<new-id> t_<done-id>   # parent done → child 자동 promote
# → parent done 시 dispatcher가 child를 즉시 ready → claim → spawn
```

**핵심**: `dispatch --max 1` 매번 호출 안 해도 됨. parent done 시 dispatcher가 자동 spawn. 단 **이미 ready인 카드가 5장 이상이면** 1장씩 archive + parent link 패턴 반복.

### 4. 카드 body 작성 룰 (★ 결정적)

모든 카드 body에 다음 마커를 첫 줄에 박는다:

```text
[DO NOT SPECIFY/DECOMPOSE] 이 카드는 운영자가 직접 작성한 단일 범위.
worker는 kanban_complete 또는 kanban_block만 호출.
kanban_specify / kanban_decompose 호출 금지.

[분류: auto-verifiable] 또는 [분류: human-verifiable]
```

그리고 acceptance criteria 5개 항목 + "통과 시/실패 시" 절차 + **금지 사항** (e.g., "Math.random() 금지", "외부 CDN fetch 금지", "light.visible=false 금지"). `kanban-project-delivery` 스킬의 "Decomposition-time classification" 그대로.

### 5. 워커 진행 관찰

```bash
# 워커가 살아있는지 + commit 박혔는지 5분마다 체크
ps -p <worker_pid> -o pid,etime,%cpu,%mem,stat
ls -la /Users/mac/.hermes/kanban/boards/<slug>/workspaces/<task_id>/
git -C /Users/mac/.hermes/kanban/boards/<slug>/workspaces/<task_id>/ log --oneline  # commit 확인
```

**auto-verifiable 카드는 worker가 kanban_complete 직접 호출**. 운영자 알림 불필요. **human-verifiable 카드는 worker가 review-required로 block**. 운영자 → 사용자 시각 확인 → complete.

### 6. Phase 끝 결정 — 4옵션 + 추천

각 Phase 끝마다 운영자가 사용자에게 보고:

```markdown
| Phase | 시작 / 완료 | 산출물 | run # | commit |
|---|---|---|---|---|
| Phase 1.0 (보일러) | 05:47 / 06:12 | 8 files, build pass, dev serve 5173 | #13 | 51c914f |
| Phase 1.1 (엔진) | running | ... | ... | ... |

[3-Phase 게이트 진행 상황]
- Phase 1: 1/5 done
- Phase 2: 0/0
- Phase 3: 0/0
[남은 누적 성공 확률: 41%]
```

→ 4옵션 + 추천으로 다음 Phase 진입 결정.

## 모델 비교 시나리오 (★ 이 스킬의 차별점)

원본 Opus 5 결과물을 **golden image로 박고**, M3 / GPT-5 / GLM-4.6 등 다른 모델 결과물과 pixel-level 비교:

```bash
# 1. Opus 5 첫 프레임 캡처 → captures/golden.png
curl -fsSL https://raw.githubusercontent.com/<owner>/<repo>/main/captures/first-frame.png -o captures/golden.png

# 2. Phase 1 끝에 M3 빌드 첫 프레임 캡처
node tools/baseline.mjs --out captures/m3-phase1.png

# 3. imagediff
node tools/imagediff.mjs --a captures/golden.png --b captures/m3-phase1.png
# 출력: total pixels=N, diff pixels=M, diff%=X.XX
```

**해석 가이드**:

| diff % | 의미 |
|---|---|
| 0~1% | bit-identical 에 가까움 (불가능) |
| 1~5% | 같은 카메라/시간, 표현만 다름 (좋은 결과) |
| 5~15% | 구조는 같지만 표면/조명 다름 (보통) |
| 15~30% | 의도는 같지만 디테일 다름 (재현 어려움) |
| 30%+ | 사실상 다른 결과 (모델 한계) |

**mshumer 본인은 이걸 안 했음** (자기 critic loop만 사용). 우리 `golden image` 패턴은 차이점.

## 비교 산출물 형태 (사용자 노출)

각 Phase 끝마다 다음을 사용자에게 노출:

```markdown
## Phase X 완료 보고

| 항목 | 값 |
|---|---|
| Phase | Phase 1.0 — 보일러 |
| 카드 | t_xxx |
| 시작 / 완료 | 05:47 / 06:12 (25분 1초) |
| run | #1 crashed / #13 completed (831초) |
| commit | 51c914f |
| 산출물 | package.json + vite.config.js + index.html + src/main.js + ... |
| 검증 | 헤드리스 Chromium 1280x720, 콘솔 에러 0 |

[워커 latest_summary]
> 보일러플레이트: Vite 8.1.5 + Three.js r180, build 통과, dev 서버 127.0.0.1:5173 부팅 확인. 헤드리스 Chromium에서 콘솔 오류 0개, 1280×720 단색 WebGL 캔버스와 `Three.js r180` 로그를 검증했고 커밋 51c914f로 저장했습니다.

[함정 N 발생 / 회수] — 함정 12, 13 실측 사례
```

## 핵심 함정 (이번 세션 실측)

| # | 함정 | 해결 |
|---|---|---|
| 12 | `hermes kanban create --body-file` 옵션 부재 | write_file + cat + --body 인라인 |
| 13 | `unblock` 비대화 hang + dispatcher 5-카드 동시 claim | 1장씩 dispatch + parent 자동 promote 패턴 |
| 14 | scratch 워크스페이스 = done 직후 dispatcher 정리 → 사용자 손에 코드 0개 | **`--workspace dir:<user_dir>`** 처음부터. 가장 깨끗한 예방. |
| 15 | 보드 slug immutable (display name 만 rename 가능) | 보드 만들 때 신중하게. 변경 시 옛 보드 archive + 새 보드 create |
| 16 | `file://` 직접 열기 + vite preview SPA fallback | `open_preview` 는 항상 `vite dev` (5173) 만 사용, 절대 preview (4173) 안 씀 |

`--workspace dir:<user_dir>` 패턴이 정말 중요. **card 생성 시점부터** 적용:

```bash
hermes kanban --board <slug> create "Phase X.Y — ..." \
  --body "$BODY" \
  --workspace dir:/Users/mac/work/<user_dir> \
  --assignee coder
# NOTE: --branch 는 worktree 모드에서만. dir: 모드에서는 빼야 함.
```

장점:
- dispatcher가 scratch 정리해도 사용자 디렉터리는 보존
- 워커의 `git add + commit` 도 사용자 디렉터리에서 실행 → machine-verified git log 즉시 확인 가능
- 워커 done 직후 `git -C /Users/mac/work/<user_dir> log --oneline | head -3` 만 보면 commit 검증 끝

**한계도 명시**: dir: 워크스페이스는 scratch 정리 문제는 해결하지만 **워커가 done 직전 git commit 안 하는 stuck 패턴은 못 해결**. 운영자가 마지막에 `git add . && git commit` 마무리 해야 함 (minimax-of-duty Phase 1.2 실측).

자세한 재현 절차 + recover sequence: `references/kanban-cli-gotchas-game-orchestration.md`

### ★★★ minimax-of-duty 세션 (2026-07-27) 의 실제 흐름

| 시점 | 이벤트 |
|---|---|
| 디렉터리 시작 | `/Users/mac/work/minimax-of-duty/` (이전 이름 claude-of-duty-ko 였다가 사용자 요청으로 rename) |
| Phase 1.0 | 워커 t_60d85c09, scratch 모드, 25분, commit 51c914f → scratch 정리 → 사용자 손에 코드 0개 |
| Phase 1.1 | 워커 t_266e00c5, scratch 모드, 13분, commit b81d2a0 → scratch 정리 → 사용자 손에 코드 0개 |
| 운영자 재구현 | ARCHITECTURE.md + summary 기반 6 모듈 + main + test 직접 작성, vitest 29/29 + vite build PASS, git commit `54d01dc` |
| Phase 1.2 | 워커 t_3a596bbc, **`--workspace dir:/Users/mac/work/minimax-of-duty`** — 함정 14 해결. 7 파일 + tools/ 4 파일 직접 박힘. 워커 stuck → 운영자 `Color.clone` 1줄 fix |
| 함수정 14 | 워커 scratch 정리 후 사용자 손에 코드 0 — 운영자가 직접 ARCHITECTURE.md + summary 보고 재구현 (25분) |
| 함수정 15 | 보드 slug immutable, 옛 보드 archive + 새 보드 create |
| 함수정 16 | `open_preview` 가 vite preview 띄움 → SPA fallback → `/src/main.js` 가 index.html 응답. vite dev (5173) 만 사용으로 해결 |

**B 게이트 검증**: Phase 1.0 + 1.1 + 1.2 모두 1장씩 dispatch --max 1 패턴. 5장 동시 claim 함정 없었음. 사용자 4옵션 + 추천 결정 매 Phase 끝마다.

## 프롬프트 영문+한글 동기 기록 (★ 사용자 시그널)

이번 세션에서 사용자 시그널: "작업에 사용되는 모든 프롬프트를 기록해서 저정해주고, 가능하면 한글 프롬프트를 사용해줘. 만약 영문 프롬프트를 사용하게 되면 한글로 번역된 프롬프트도 같이 기록해줘."

**워크플로우**:
1. 카드 body는 **한글**로 작성 (워커에게 한국어 그대로 전달)
2. PROMPT-LOG.md에 카드 body 발췌 + 영문 번역 모두 박기
3. 워커 latest_summary (주로 한글)도 EN 번역 동시 기록
4. 운영자의 4옵션 질문 (한글)도 EN 번역 동시 기록

→ `templates/prompt-log.md` 본 스킬이 보일러플레이트 제공. `kanban-project-delivery` 스킬에도 이 워크플로우 박음.

## 금지 사항

- Opus 5 / GPT-5 / GLM-4.6 결과물을 **그대로 복제** 시도 금지 (라이선스 + 의미 없음). **상호 비교 reference**로만 사용.
- 11서브시스템을 단일 카드에 묶지 않는다 (kanban-project-delivery "카드 크기 제한" 그대로).
- Phase 1 한 번에 5장 이상 동시 dispatch 금지.
- 5장 일괄 dispatch 후 "5장 다 자동으로 시작했어요" 식의 사후 보고 금지.
- 사용자 "OK" 신호로 5장 일괄 dispatch 절대 금지.

## 참고 자료

- `references/original-mshumer-prompt.md` — mshumer의 /loop 원샷 프롬프트 전문
- `references/architecture-contract.md` — 11서브시스템 ARCHITECTURE.md (render engine contract)
- `references/kanban-decomposition.md` — 11서브시스템을 5-Phase + 20~25 카드로 분해한 분해안
- `references/kanban-cli-gotchas-game-orchestration.md` — 함정 12, 13, 14, 15 재현/회복
- `references/claude-of-duty-ko-case-study.md` — 2026-07-27 1일차 실측 (Phase 1.0 done, 1.1 running)
- `templates/prompt-log.md` — 프롬프트 로그 빈 템플릿
- `templates/phase-card-body.md` — Phase 카드 body 한/영 템플릿
