# 프롬프트 로그 — <project-name>

> 모든 프롬프트는 여기에 영문 + 한글 둘 다 기록됩니다. 카드별로 worker에게 보낸 프롬프트가 이 파일에 동기화되며, 커밋 시점의 결정 프롬프트도 함께 보관됩니다.
> 형식: `[카드ID] [날짜] [EN 원문] / [한글 번역] / [실제 결과]`

---

## 세션 0: 프로젝트 결정 (<YYYY-MM-DD>)

### 결정 프롬프트 (사용자 → 운영자)

**EN**: <사용자 영어 메시지 원본>

**한글**: <한글 번역 또는 한국어 그대로>

**결과**: <운영자 결정 + 추천>

### 운영자 의사결정 프롬프트 N (사용자 → 운영자 4옵션)

**EN**: <clarify 4옵션 question EN>

**한글**: <clarify 4옵션 question KR>

**결과**: <사용자 선택 옵션>

---

## Phase 1 — 5장 카드 분해

> 참고: ARCHITECTURE.md 11서브시스템 중 Phase 1은 **engine(코어) + render + world** 만 다룸. materials/sky/player/weapons/ai/audio/fx/ui 는 Phase 2~4.
> 참조: `references/kanban-decomposition.md`

| 카드 | 제목 | 핵심 시스템 | Auto/Human Verifiable | 파일 | 상태 |
|---|---|---|---|---|---|
| t_xxx | Phase 1.0 — 보일러플레이트 | npm/vite/three | Auto | `prompts/phase-1.0-body.md` | **DONE ✅** |
| t_xxx | Phase 1.1 — 엔진 코어 | ctx/events/time/rng | Auto | `prompts/phase-1.1-body.md` | RUNNING |
| ... | ... | ... | ... | ... | ... |

---

## Phase 1.0 — 카드 본문 (t_xxx, **완료**)

**운영자 작성 한글 본문 (전체)**: `prompts/phase-1.0-body.md` 참조

**워커에게 전달된 프롬프트 (dispatch 시점)**:
운영자가 카드 body에 작성한 **한글 본문이 그대로 워커 컨텍스트에 주입됨**. hermes kanban 워커는 카드 body를 system prompt 일부로 받음 — 영문 변환 없이 한글 그대로. `DO NOT SPECIFY/DECOMPOSE` + `[분류: auto-verifiable]` 마커는 워커 LLM에게 명확한 행동 지시.

**워커의 행동 지시 (body 발췌, 한글)**:
> <body에서 발췌>

**EN 번역 (영문 프롬프트 기록 룰 충족용)**:
> <전체 한국어 body의 영문 번역>

### Phase 1.0 — 운영자 작업 로그 (시점별)

#### T0: 보드 생성 + N장 카드 등록 + N-1장 archive + 단독 dispatch

- 보드: `<slug>` 생성
- N장 카드 등록: t_xxx (1.0), t_xxx (1.1), ...
- 의존성 link N-1건
- **함정 12 (★ YYYY-MM-DD 신규)**: `hermes kanban create --body-file` 옵션 부재 → write_file + cat + --body 인라인 우회
- **함정 13 (★ YYYY-MM-DD 신규)**: `hermes kanban unblock` 비대화 환경 hang + dispatcher가 모든 blocked→ready 카드 동시 claim. 5장 모두 running 상태.
- 회복: 5개 워커 SIGTERM → 4장 reclaim → 4장 archive → 1장만 keep
- `dispatch --max 1` → t_xxx 단독 running

#### T1: 워커 작업 (HH:MM ~ HH:MM, MM분 SS초 소요)

- HH:MM — <단계 1>
- HH:MM — <단계 2>
- ...
- HH:MM — **run #N completed, kanban_complete 호출**

#### T2: 워커 latest_summary (한글 번역)

**워커 original (EN)**: <워커 latest_summary 한글 원본>

**EN translation**: <EN 번역>

#### T3: 워커가 만든 산출물

| 파일 | 크기 | 비고 |
|---|---|---|
| <파일> | <bytes> | ... |

#### T4: 수용 기준 검증 결과

| 기준 | 결과 |
|---|---|
| (1) <기준> | ✅ / ❌ |
| ... | ... |

#### T5: Phase 의사결정 결과 (★ 함수형 게이트 통과)

- **auto-verifiable 카드**의 자기 검증 워크플로가 정상 작동
- **dispatch --max 1** 단독 dispatch 검증
- **함정 N 회피** — 1장씩 dispatch 패턴 정착

---

## Phase 1.1 — 카드 본문 (t_xxx, RUNNING)

**운영자 작성 한글 본문 (전체)**: `prompts/phase-1.1-body.md` 참조

**워커에게 전달된 프롬프트 (dispatch 시점)**:
body 내용 그대로.

**EN 번역**:
> <한글 body 전체의 EN 번역>

### Phase 1.1 — 운영자 작업 로그 (시점별)

#### T0: 카드 등록 + parent link

- 카드 t_xxx (1.1) 등록: `Created t_xxx (blocked, assignee=coder)`
- 의존성 link: `Link t_xxx -> t_xxx (parent=1.0 done)`
- **함정 14 (★ YYYY-MM-DD 신규)**: 동일 ID로 카드 재생성 불가 → 새 ID 자동 발급, body 파일 재사용
- 자동 promote + spawn (1장 keep 패턴)

#### T1: 워커 작업 (진행 중)

- HH:MM — ...

---
