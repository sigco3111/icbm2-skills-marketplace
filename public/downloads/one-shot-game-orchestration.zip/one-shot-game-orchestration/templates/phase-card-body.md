Phase <X.Y> — <한글 제목> (<시스템 키워드>)

[DO NOT SPECIFY/DECOMPOSE] 이 카드는 운영자가 직접 작성한 단일 범위. worker는 kanban_complete 또는 kanban_block만 호출. kanban_specify / kanban_decompose 호출 금지.

[분류: <auto-verifiable | human-verifiable>] <워커 규정 — auto면 review-required로 막지 말 것, human이면 통과 후 review-required로 block>

목표:
- <목표 1>
- <목표 2>
- <목표 3>
- <목표 4>
- <목표 5>

수용 기준 (acceptance):
1. <기준 1>
2. <기준 2>
3. <기준 3>
4. <기준 4>
5. <기준 5>

통과 시:
  - 모든 5개 기준 충족 확인
  - git add . && git commit -m "phase <X.Y>: <커밋 메시지>"
  - hermes kanban --board <slug> complete t_<id> --summary "<one-line>" --metadata '{"files":[...],"build_pass":true,...}'

실패 / 막힘 시:
  - hermes kanban --board <slug> block t_<id> --reason "review-required: <구체적 막힌 곳>"
  - 운영자가 직접 확인

금지:
- <금지 1>
- <금지 2>
- <금지 3>
- <금지 4>
- <금지 5>

---

## EN 번역 (프롬프트 로그 PROMPT-LOG.md에 동시 기록)

Phase <X.Y> — <English title> (<system keyword>)

[DO NOT SPECIFY/DECOMPOSE] Single-scope card written by operator. Worker calls only kanban_complete or kanban_block. kanban_specify / kanban_decompose forbidden.

[Class: <auto-verifiable | human-verifiable>] <Worker rule — auto means do not block with review-required; human means block with review-required after smoke passes>

Goals:
- <goal 1>
- <goal 2>
- <goal 3>
- <goal 4>
- <goal 5>

Acceptance (5):
1. <criterion 1>
2. <criterion 2>
3. <criterion 3>
4. <criterion 4>
5. <criterion 5>

On pass:
  - Verify all 5 criteria
  - git add . && git commit -m "phase <X.Y>: <commit message>"
  - hermes kanban --board <slug> complete t_<id> --summary "<one-line>" --metadata '{"files":[...],"build_pass":true,...}'

On fail:
  - hermes kanban --board <slug> block t_<id> --reason "review-required: <concrete blocker>"
  - Operator reviews

Prohibited:
- <prohibition 1>
- <prohibition 2>
- <prohibition 3>
- <prohibition 4>
- <prohibition 5>
