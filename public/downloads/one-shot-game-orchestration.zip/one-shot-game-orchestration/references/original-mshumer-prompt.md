# mshumer 원본 /loop 프롬프트 (Claude-of-Duty)

> 출처: https://github.com/mshumer/Claude-of-Duty/blob/main/prompt.md
> 2026-07-27 정독.

## 원본 (영문)

```
I want you to build a first-person shooter at the level of the most recent Call of Duty games. It should be utterly perfect, visually beautiful, with every single thing done at AAA quality—from textures to physics to anything you could think of.

Fan out sub-agents and have sub-agents tackle each one individually so that the game is utterly perfect. You should /loop on each item and have a separate sub-agent check it visually to ensure it looks triple A. That separate sub-agent should be a really harsh critic, and if it doesn't look triple A, it should keep going.

Don't stop until each sub-agent is utterly wowed with the quality when compared with the actual Call of Duty game. It should literally compare them side by side blind and say which one looks better. Do this in ThreeJS. /loop until it's utterly perfect. Fan out sub-agents and ultracode.
```

## 한글 번역

```
나는 너에게 최근 콜 오브 듀티 게임 수준에 맞는 1인칭 슈팅 게임을 만들어달라.
텍스처부터 물리까지, 생각할 수 있는 모든 것이 AAA 품질로 완벽해야 해.

서브 에이전트들을 펼치고(sub-agent fan out), 각자가 개별적으로 하나씩 다뤄서
게임이 완벽하도록 해. 각 항목에 대해 /loop 하고, 별도의 서브 에이전트가
시각적으로 AAA 수준인지 확인하도록 해. 그 별도 서브 에이전트는 정말 깐깐한
비평가여야 하고, AAA가 아니면 계속 진행시켜야 해.

각 서브 에이전트가 실제 콜 오브 듀티 게임과 비교했을 때 품질에 완전히
감동받을 때까지 멈추지 마. 블라인드 사이드 바이 사이드(side-by-side)
비교로 어느 쪽이 더 좋아 보이는지 말해야 해. ThreeJS로 해.
/loop 완벽할 때까지. 서브 에이전트 펼치고 ultracode.
```

## 이 프롬프트의 핵심 패턴 (★ 분석)

1. **"Fan out sub-agents"** — Opus 5는 in-context에서 여러 sub-agent 호출 가능. M3는 불가.
2. **"/loop"** — Opus 5의 슬래시 커맨드. 자기 비평을 무한 반복. M3는 LLM 자체가 /loop 호출 불가.
3. **"separate sub-agent harsh critic"** — 외부 비평가 = 비교 기준. M3는 자기 비평으로 빠짐.
4. **"blind side-by-side"** — 정량 비교. M3는 그 인프라 없이 시작.
5. **"ultracode"** — Opus 5만 이해하는 슬랭. 품질 푸시 신호.

## 평가 대상 vs 우리 B-Phase 게이트 (변환)

| Opus 5 | 우리 (M3 + 칸반) |
|---|---|
| Sub-agent fan-out | 5-Phase 카드 23장 |
| /loop 자기 비평 | worker latest_summary + 운영자 검증 |
| Harsh critic | imagediff 게이트 + golden image |
| Blind side-by-side | pixel-diff % |
| ultracode | Phase 끝 4옵션 + 추천 |

## 동일 프롬프트를 M3에 그대로 쓰면 안 되는 이유 (3가지)

1. `/loop` + fan-out을 M3 단독으로 흉내내지 못함. 컨텍스트 한계 + sub-agent 호출 권한 없음.
2. "AAA quality" 같은 정성 지시만으로 M3가 디테일 카탈로그를 못 만듦. ARCHITECTURE.md가 필요.
3. 외부 비평가 인프라를 못 만듦. `imagediff` 같은 결정론적 게이트로 대체.

## ARCHITECTURE.md (요약)

본 파일 전체는 `references/architecture-contract.md` 참조.
핵심: 11 서브시스템 + `ctx` 라는 공유 객체 + 이벤트 vocabulary + 5개 surface type + render integration 규약.
