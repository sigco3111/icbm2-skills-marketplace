# 11서브시스템 → 5-Phase 20~25 카드 분해안

> 출처: mshumer/Claude-of-Duty ARCHITECTURE.md (https://github.com/mshumer/Claude-of-Duty/blob/main/ARCHITECTURE.md) 기반. 2026-07-27 claude-of-duty-ko 보드에서 실측.

## 11서브시스템 전체

| id | directory | 역할 |
|---|---|---|
| `render` | `src/render/` | WebGLRenderer, HDR pipeline, post-processing |
| `materials` | `src/materials/` | 절차적 PBR 텍스처 |
| `sky` | `src/sky/` | physical sky, IBL, volumetric fog |
| `world` | `src/world/` | level geometry, props |
| `physics` | `src/physics/` | BVH, raycast, controller, rigid bodies |
| `player` | `src/player/` | movement state machine |
| `weapons` | `src/weapons/` | viewmodel, ADS, recoil |
| `fx` | `src/fx/` | GPU particles, decals, tracers |
| `ai` | `src/ai/` | enemy characters, navmesh |
| `ui` | `src/ui/` | DOM/CSS HUD |
| `audio` | `src/audio/` | synthesized weapon/foley, HRTF |

## 5-Phase 분해 (B 게이트, 23 카드)

### Phase 1 — Engine + Render + World (5장, 06:00 ~ 06:30)

| 카드 | 제목 | 시스템 | Auto/Human |
|---|---|---|---|
| 1.0 | 보일러플레이트 (Vite + Three.js r180) | npm/vite | Auto |
| 1.1 | 엔진 코어 (ctx/events/time/rng/config) | engine | Auto |
| 1.2 | 렌더 (HDR + TAA + AgX + prewarm) | render | Human (첫 프레임) |
| 1.3 | 월드 (120x120m market + modular kit) | world | Human (씬 시각) |
| 1.4 | 통합 스모크 + 5 mjs 도구 | tools | Human (게이트 가동) |

### Phase 2 — Materials + Sky + Audio (6장, 추정 06:30 ~ 08:00)

| 카드 | 제목 | 시스템 | Auto/Human |
|---|---|---|---|
| 2.0 | 머티리얼 라이브러리 (19종 procedural) | materials | Auto (unit) |
| 2.1 | 머티리얼 5종 (concrete/brick/plaster/asphalt/sand) | materials | Human (시각) |
| 2.2 | 머티리얼 7종 (rusted/painted/brushed metal, wood, fabric, burlap, glass) | materials | Human (시각) |
| 2.3 | 스카이 (atmospheric scattering + time of day + PMREM) | sky | Human (시각) |
| 2.4 | 오디오 (Web Audio synth + HRTF + reverb) | audio | Auto (smoke) |
| 2.5 | Phase 2 통합: sun + sky + audio 테스트 | render + sky + audio | Human (시각) |

### Phase 3 — Player + Weapons + AI (6장, 추정 08:00 ~ 10:00)

| 카드 | 제목 | 시스템 | Auto/Human |
|---|---|---|---|
| 3.0 | 물리 (BVH + character controller + raycast) | physics | Auto |
| 3.1 | 플레이어 (movement state machine + slide/mantle/lean) | player | Human (playtest) |
| 3.2 | 무기 (procedural geometry + ADS + recoil) | weapons | Human (playtest) |
| 3.3 | AI (navmesh + perception + cover) | ai | Human (playtest) |
| 3.4 | AI squad + squad tactics | ai | Human (playtest) |
| 3.5 | Phase 3 통합: player + weapons + AI 1 라운드 | — | Human (playtest) |

### Phase 4 — FX + UI + Polish (4장, 추정 10:00 ~ 11:30)

| 카드 | 제목 | 시스템 | Auto/Human |
|---|---|---|---|
| 4.0 | FX (GPU particles + decals + tracers + muzzle) | fx | Auto |
| 4.1 | UI (DOM/CSS HUD + crosshair + hitmarker + killfeed) | ui | Human (시각) |
| 4.2 | 통합 빌드 + imagediff 게이트 Phase 4 | all | Human (playtest) |
| 4.3 | 최종 polished build + commit | all | Human (playtest) |

## 의존성 그래프 (Phase 1)

```
1.0 (보일러) ─┬─> 1.1 (엔진) ─┐
              │                ├─> 1.3 (월드) ─┐
              └─> 1.2 (렌더) ─┘                │
                                                └─> 1.4 (통합스모크)
```

## 분해 결정 시 고려사항

1. **Phase 1은 다른 Phase의 기반**. 1.0~1.4 모두 통과해야 Phase 2 진입 가능.
2. **Phase 2 머티리얼은 2.1(5종) + 2.2(7종) 분할** — 한 카드에 19종 다 묶지 않음 (mshumer 자체가 19종을 2개 카테고리로 분리).
3. **Phase 3 AI는 3.3(개별 행동) + 3.4(squad)** — mshumer가 squad.js 별도 파일 만듦.
4. **Phase 4는 4.2 imagediff 게이트** — Phase 1.4의 도구 활용, golden image와 비교.
5. **각 Phase 끝 통합 카드 (1.4, 2.5, 3.5, 4.2)** — Phase 끝났을 때 확인. 사람 시각 확인 필요.

## Owner 헷갈림 방지

- 1.0 worker: src/main.js, vite.config.js, index.html, package.json
- 1.1 worker: src/core/ (5 modules)
- 1.2 worker: src/render/ (6 modules)
- 1.3 worker: src/world/ (5 modules)
- 1.4 worker: tools/ (5 modules)

ARCHITECTURE.md ownership map 그대로. **다른 카드의 디렉터리는 수정 금지** (1.2 worker가 src/world/ 건드리지 않음). 이걸 카드 body에 명시 안 하면 worker가 멋대로 다른 서브시스템 import 함.
