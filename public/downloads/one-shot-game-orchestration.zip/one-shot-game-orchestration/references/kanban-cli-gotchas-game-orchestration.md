# `hermes kanban` CLI 게임 오케스트레이션 함정 (2026-07-27 신규)

> 본 문서는 `kanban-project-delivery`의 `references/kanban-cli-gotchas.md` 보완. 게임 오케스트레이션 워크플로우에서 실측된 4가지 함정.

## 함정 12: `hermes kanban create --body-file` 옵션 부재

**증상**:
```bash
cat > /tmp/body.txt << 'EOF'
...
EOF
hermes kanban create "..." --body-file /tmp/body.txt
# unrecognized arguments: --body-file /tmp/body.txt
```

**원인**: `hermes kanban create`는 `--body BODY` (인라인)만 지원. 외부 파일 참조 옵션 없음.

**회피**:
```bash
# ✅ write_file + cat + --body 인라인
write_file path="/tmp/body.md" content="<한글 본문>"
BODY=$(cat /tmp/body.md)
hermes kanban create "..." --body "$BODY"
```

**왜 heredoc 안 되는가**: 비대화 환경에서 `cat > /tmp/body.txt << 'EOF' ... EOF` 가 BLOCKED (hardline) 처리됨. terminal 가드 9번.

## 함정 13: `unblock` 비대화 hang + dispatcher 5-카드 동시 claim

**증상**:
```bash
# 5장 카드 blocked 상태로 등록, 1장만 unblock
hermes kanban unblock t_xxx --reason "Phase 1.0 시작"
# 60초 timeout — 출력 없음, return 안 함
```

그 사이 dispatcher 데몬이 모든 blocked 카드를 ready로 자동 promote + 5개 워커 동시 spawn.

**원인**:
1. `unblock` CLI가 dispatcher 데몬과 IPC하면서 비대화 환경에서 출력 stream을 block
2. dispatcher가 `--max` 옵션 없이 모든 ready 카드를 자동 claim
3. `dispatch --max N`을 별도 호출해야 spawn cap이 적용됨

**즉시 인식**:
```bash
hermes kanban --board <slug> stats  # By status: running=N (예상 1인데 5)
ps aux | grep 'hermes.*t_' | grep -v grep | wc -l  # 5
```

**즉시 대응 (3단계)**:
```bash
# 1. 워커 모두 SIGTERM (9초 후 SIGKILL)
for pid in $(ps aux | grep -E 'hermes.*t_(id1|id2|...)' | grep -v grep | awk '{print $2}'); do
  kill -TERM $pid
done
sleep 3
for pid in $(ps aux | grep -E 'hermes.*t_(id1|id2|...)' | grep -v grep | awk '{print $2}'); do
  kill -9 $pid 2>/dev/null
done

# 2. 모든 running 카드 reclaim
hermes kanban --board <slug> reclaim t_xxx --reason "5-card 동시 dispatch 회수"

# 3. 보존할 1장만 남기고 나머지 archive
hermes kanban --board <slug> archive t_yyy
```

**이후 dispatch**:
```bash
hermes kanban --board <slug> dispatch --max 1
ps aux | grep -E 'hermes.*t_xxx' | grep -v grep | wc -l  # 1 확인
```

**근본 회피 (1장씩 dispatch 패턴)**:
```bash
# ✅ 1장만 ready 상태로 시작, parent done 시 자동 promote
hermes kanban create "Phase 1.1" --body "..." --initial-status blocked
hermes kanban link t_266e00c5 t_60d85c09  # child가 parent done 대기
# → parent done되면 dispatcher가 child 자동 claim + spawn
```

**핵심**: parent done 시 dispatcher가 자동으로 child를 ready → claim → spawn. 별도 unblock/dispatch 호출 불필요. 단 **이미 ready인 카드가 5장 이상이면** 1장씩 archive + parent link 패턴 반복.

## 함정 14: 동일 ID로 카드 재생성 불가

**증상**: archive 처리된 카드 ID `t_cbab7958` 와 똑같은 ID의 새 카드를 만들 수 없음.

**원인**: SQLite-backed board. archived 상태도 row 존재.

**대응**: 새 ID 자동 발급 (`Created t_xxx new_id`). body 파일 재사용:
```bash
BODY=$(cat prompts/phase-1.1-body.md)
hermes kanban create "Phase 1.1 — 엔진 코어" --body "$BODY" --assignee coder --initial-status blocked
# Created t_266e00c5 (blocked, assignee=coder)
```

## 함정 15: workspace 폴더가 done 후 사라짐

**증상**: 카드 done 후 `/Users/mac/.hermes/kanban/boards/<slug>/workspaces/<task_id>/` 폴더가 사라짐 (또는 안 보임).

**원인**: dispatcher가 cleanup 사이클에서 workspace archive 처리. 일부 환경에서는 폴더가 살짝 남아있다가 다음 사이클에 사라짐.

**대응**: 결과물은 다음 위치에 영구 백업:
1. `prompts/PROMPT-LOG.md` — commit hash, file list, latest_summary 기록
2. `git log` — 커밋 해시 + 메시지
3. `hermes kanban show <id> --json` — latest_summary + metadata

done 후 workspace에 접근해야 할 일은 거의 없음. **done == 작업 종료 + 결과 박힘 == 정리 완료** 패턴.

## 비대화 환경 일반 함정 (참조)

- `sleep 90` + 명령 조합: terminal 가드 60초 timeout. 30초씩 분할.
- `\`cat | head\` + 파이프`: 가끔 BLOCKED (hardline). `read_file` 사용.
- `hermes gateway status`: 비대화 환경에서 가끔 hang. 5분 후 던지기.
- `hermes kanban log --tail N`: 워커가 활발히 출력 중이면 hang. `show` + `runs` 조합이 안전.

## dispatch / unblock 비대화 환경 종합 표

| 작업 | 비대화 hang? | 대안 |
|---|---|---|
| `unblock` | ✅ hang (5-카드 동시 claim) | parent link만 만들고 ready 대기 |
| `dispatch --max 1` | ❌ 즉시 return | 정상 사용 |
| `dispatch --max N` (N>1) | ❌ 즉시 return | OK, 단 N은 2 이하 |
| `reclaim` | ❌ 즉시 return | 정상 사용 |
| `archive` | ❌ 즉시 return | 정상 사용 |
| `link` | ❌ 즉시 return | 정상 사용 |
| `log --tail N` | ⚠️ 워커 출력 중이면 hang | `show` + `runs` |
| `show` | ❌ 즉시 return | 정상 사용 |
| `stats` | ❌ 즉시 return | 정상 사용 |
| `list` | ❌ 즉시 return | 정상 사용 |
| `runs` | ❌ 즉시 return | 정상 사용 |
| `complete` | ❌ 즉시 return | 정상 사용 |
| `gateway status` | ⚠️ 가끔 hang | 5분 후 skip |
