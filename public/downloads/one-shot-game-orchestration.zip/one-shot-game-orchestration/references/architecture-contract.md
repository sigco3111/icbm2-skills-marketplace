# 11서브시스템 ARCHITECTURE.md 발췌

> 출처: https://github.com/mshumer/Claude-of-Duty/blob/main/ARCHITECTURE.md
> 2026-07-27 정독. 본 발췌는 칸반 카드의 ctx 계약으로 활용.

## TL;DR — OVERWATCH 계약

**Every agent must read this before writing code. It is the only coordination mechanism.**

- Target: browser FPS, WebGL2 + Three.js r180, no external art assets
- 모든 텍스처/메시/애니메이션/오디오 절차적 생성
- 실행 의존성: `three` 단일

## Hard Rules (8개)

1. **You own your directory. Never edit files outside it.** 다른 에이전트 디렉터리 수정 금지.
2. **Never import another subsystem's module.** `ctx.get('fx')` 로 runtime에 가져온다.
3. **No new npm dependencies.** three 단일. CDN fetch 금지, 외부 이미지/HDRIs/모델/오디오 금지.
4. **No `Math.random()` in gameplay or visuals.** `ctx.rng` 또는 `ctx.rng.fork()` 사용.
5. **Allocate nothing per-frame.** `new THREE.Vector3()` in update() = bug.
6. **Dispose what you create.** geometries, materials, textures, render targets dispose.
7. `npm run build` must pass and `node tools/capture.mjs` must produce a frame. 다른 에이전트 작업 깨뜨리지 마.
8. *(implicit)* 무결성 — 분석/안전성 자체 룰.

## Subsystem Interface (★ ctx 계약)

```js
export class MySystem {
  static id = 'mysystem';       // unique; how others reach you
  static deps = ['render'];     // ids that must init before you

  async init(ctx) {}            // build resources; may await
  fixedUpdate(h, ctx) {}        // optional, 120 Hz, deterministic gameplay
  update(dt, ctx) {}            // optional, once per frame
  lateUpdate(dt, ctx) {}        // optional, after all update()
  resize(w, h, ctx) {}          // optional
  dispose() {}                  // optional
}
```

## ctx 노출 (★ 모든 카드가 따라야 함)

```js
{
  scene, camera, viewScene, viewCamera, canvas,
  config, events, input, time, rng,
  get(id), peek(id), has(id), register(system)
}
```

- `scene`/`camera` — world
- `viewScene`/`viewCamera` — 1인칭 무기, 별도 그려짐 (월드와 클립 안 함)
- `time` — `{ elapsed, raw, dt, fixed, alpha, scale, frame }`
- `alpha` — 물리 step 사이 보간용
- `config.q` — quality preset (taa, gtao, ssr, volumetrics, shadowMapSize, particleBudget, decalBudget)

## Ownership Map (11서브시스템)

| id | directory | owns |
|---|---|---|
| `render` | `src/render/` | WebGLRenderer, HDR pipeline, post-processing, CSM shadows, final composite |
| `materials` | `src/materials/` | procedural PBR texture generation, material library, triplanar/detail mapping |
| `sky` | `src/sky/` | physical sky, sun/moon, time of day, IBL/env map, volumetric fog |
| `world` | `src/world/` | level geometry, modular building kit, props, set dressing, static collision meshes |
| `physics` | `src/physics/` | broadphase, raycasts, character controller collision, rigid bodies, ragdolls, penetration |
| `player` | `src/player/` | movement state machine, camera feel, sprint/slide/mantle/lean, health |
| `weapons` | `src/weapons/` | weapon meshes, viewmodel rig, ADS, recoil, sway, bob, reload, ballistics |
| `fx` | `src/fx/` | GPU particles, muzzle flash, tracers, impacts, decals, smoke, blood, shells |
| `ai` | `src/ai/` | enemy characters, navigation, perception, cover selection, combat behaviour |
| `ui` | `src/ui/` | HUD, crosshair, hitmarkers, damage indicators, ammo, killfeed, menus |
| `audio` | `src/audio/` | synthesized weapon/foley audio, spatialisation, reverb, occlusion, mix |

**Shared (소유자 = lead, 수정 금지)**: `src/core/`, `src/main.js`, `src/dev/`, `tools/`, `vite.config.js`.

## Cross-subsystem Events (cross-system vocabulary)

| event | payload | emitted by |
|---|---|---|
| `weapon:fire` | `{ weapon, origin: Vector3, dir: Vector3, seed }` | weapons |
| `weapon:reload` | `{ weapon, phase: 'start'\|'magout'\|'magin'\|'end' }` | weapons |
| `weapon:shell` | `{ position, velocity }` | weapons |
| `bullet:impact` | `{ point, normal, surface, incident, damage }` | physics |
| `bullet:tracer` | `{ from, to, speed }` | weapons |
| `damage:dealt` | `{ target, amount, headshot, killed, point }` | ai / physics |
| `damage:taken` | `{ amount, from: Vector3, health }` | player |
| `actor:death` | `{ actor, point, impulse }` | ai |
| `player:land` | `{ velocity, surface }` | player |
| `player:footstep` | `{ position, surface, running }` | player |
| `player:state` | `{ stance, sprinting, sliding, ads }` | player |
| `explosion` | `{ position, radius, damage }` | any |
| `resize` | `{ width, height }` | engine |

새 이벤트 추가 시 같은 commit에 행 추가.

## Surface Types (충돌 + impact)

`concrete`, `metal`, `wood`, `dirt`, `sand`, `glass`, `water`, `foliage`, `fabric`, `flesh`, `rubber`, `plaster`

## Render Integration

```js
const r = ctx.get('render');
r.renderer            // do not change outside a frame
r.registerPass(pass)  // insert custom post pass
r.addLight(light)     // register punctual light for culling/budgets
r.requestEnvMap()     // PMREM env map currently in use
r.screenSize          // internal render target size
r.depthTexture        // linear depth, for soft particles / SSR
r.velocityTexture     // motion vectors, for TAA / motion blur
```

`viewScene`에 그려진 건 world 뒤에 합성되고 depth buffer 클리어됨.

**per-object opt-outs**:
- `mesh.userData.owNoPrepass = true` — prepass에서 제외
- `mesh.userData.owNoShadow = true` — CSM 캐스케이드에서 제외 (★ 유일한 shadow caster 스위치)

## The Point-Light Count is a Shader Permutation Key (★ 핵심 함정)

`r.addLight()` 가 distance culling 받음. **fade 도달 시 light.visible = false 대신 intensity = 0 으로 유지** (visible=true). Three.js는 visible point light 수를 material program cache key에 박음. light 하나가 radius 넘어가서 visible=false 되면 모든 lit material recompile (+33~36 programs, 640-900 ms).

**해결책 2가지**:
- intensity = 0으로 두고 visible = true (fx/lights.js 방식)
- 0-intensity "ballast" lights로 슬롯 채움 (world/_stabiliseLightCount, 17 practicals)

**0-irradiance light = shader.add(float 0.0) = extra slot이 픽셀에 영향 없음**.

## Pre-warm (★ 셰이더 lazy compile 함정)

`src/core/prewarm.js`가 첫 프레임 전에 각 subsystem의 `prewarmMaterials(ctx)` 호출. 두 가지 트랩:

1. **render target 바인딩 필요**: `renderer.compileAsync(scene, camera)`만 호출하면 forward lit variant만 warm. CSM depth pass / MRT prepass / post chain은 **현재 bound된 render target**에서 compile. canvas bound = wrong variant.
2. **fx excluded**: fx 시스템의 light count 의존 key는 첫 frame 후에만 해결. fx는 frame 2에 self-warm.

## Quality Bar (비평가 기준)

- No flat/untextured surfaces
- No uniform lighting
- Physically plausible values (albedo 0.02-0.9, metals 0 or 1)
- Nothing perfectly straight, clean, or repeated
- Every action has weight

## 우리 B-Phase 게이트와의 매핑

| ARCHITECTURE.md 섹션 | Phase | 카드 |
|---|---|---|
| Hard rules (8개) | Phase 1.0 보일러 | 카드 body 금지 사항 |
| Subsystem interface | Phase 1.1 엔진 | ctx.js |
| Ownership map | Phase 1.2+ | 카드 디렉터리 경계 |
| Cross-subsystem events | Phase 1.1 | events.js |
| Surface types | Phase 1.3+ | physics + world |
| Render integration | Phase 1.2 | render.js |
| Point-light count 함정 | Phase 1.2 + 1.3 | light_cull.js + world/lights.js |
| Pre-warm | Phase 1.2 | prewarm.js |
| Quality bar | Phase 2+ | 머티리얼 라이브러리 |
