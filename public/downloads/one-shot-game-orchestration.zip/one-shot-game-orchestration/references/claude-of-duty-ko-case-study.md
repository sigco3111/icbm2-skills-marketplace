# claude-of-duty-ko 1일차 실측 (2026-07-27)

> 본 문서는 본 스킬의 pivo 사례. 향후 동일 시나리오에서 참조.

## 프로젝트 컨텍스트

- **목표**: mshumer/Claude-of-Duty (Opus 5 원샷 /loop 프롬프트, 11서브시스템, 55k lines)를 M3 + 칸반 5-Phase 게이트로 재현
- **사용자 시그널**: "칸반으로 미니맥스m3로 원샷에 만들어보고 싶다. 같은 프롬프트로 opus5와 필적할 수 있을까?"
- **선택된 옵션**: B (3-Phase 게이트) + A-2 (Phase 1 = 5장, --max 1, 워커 1명)
- **사용자 추가 지시**: "모든 프롬프트를 기록해서 저정해주고, 가능하면 한글 프롬프트를 사용해줘. (만약 영문 프롬프트를 사용하게 되면 한글로 번역된 프롬프트도 같이 기록해줘)"

## 타임라인

| 시간 | 이벤트 |
|---|---|
| 05:33 | GitHub repo triage (Claude-of-Duty) |
| 05:36 | 칸반 스킬 로드 |
| 05:38 | ARCHITECTURE.md + prompt.md 정독 |
| 05:42 | A/B/C/D 옵션 + 4옵션 → A-2 (사용자 선택) |
| 05:44 | 디렉터리 + 보드 생성 (`claude-of-duty-ko`) |
| 05:47 | 5장 카드 등록 (t_60d85c09 ~ t_ec8ca6e1) |
| 05:48 | 4장 link + 1장 unblock → **함정 13 발동**, 5-카드 동시 claim |
| 05:49 | 5개 워커 SIGTERM → 4장 archive → 1장 keep |
| 05:53 | `dispatch --max 1` → t_60d85c09 단독 running |
| 06:03 | worker: node_modules/ 박힘 (npm install) |
| 06:05 | worker: dist/ + index.html + .gitignore (vite build) |
| 06:05 | worker: src/main.js + src/core/ (Three.js 부팅) |
| 06:11 | worker: .git/ 박힘 (git init + commit) |
| 06:12 | **t_60d85c09 done, commit 51c914f** — Phase 1.0 완료 |
| 06:16 | Phase 1.1 (t_266e00c5) 등록 → archive 처리된 t_cbab7958 ID 회수 불가 → 새 ID 자동 (함정 14) |
| 06:16 | `link t_266e00c5 t_60d85c09` → dispatcher 자동 promote + spawn |
| 06:16~ | Phase 1.1 running |

## Phase 1.0 산출물 (commit 51c914f)

| 파일 | 크기 | 비고 |
|---|---|---|
| package.json | 287 bytes | three 0.180.0, vite 8.1.5, dev/build/preview scripts |
| package-lock.json | 27.9 KB | npm install lock |
| vite.config.js | 242 bytes | 기본 config |
| index.html | 1230 bytes | 한국어, ARIA, loading indicator, #game-canvas |
| src/main.js | 941 bytes | THREE.Scene + WebGLRenderer + DPR cap 2 + resize + THREE.REVISION 로그 |
| src/core/ | (placeholder) | Phase 1.1에서 채움 |
| .gitignore | 30 bytes | node_modules, dist |
| dist/ | (vite build 결과) | 빌드 통과 |

**워커 latest_summary (한글)**: "보일러플레이트: Vite 8.1.5 + Three.js r180, build 통과, dev 서버 127.0.0.1:5173 부팅 확인. 헤드리스 Chromium에서 콘솔 오류 0개, 1280×720 단색 WebGL 캔버스와 `Three.js r180` 로그를 검증했고 커밋 51c914f로 저장했습니다."

**수용 기준 5개 전부 통과**:
- (1) npm install 무경고 ✅
- (2) npm run build 성공 ✅
- (3) npm run dev 127.0.0.1:5173 콘솔 에러 0 ✅
- (4) 1280×720 단색 WebGL 캔버스 ✅
- (5) Three.js r180 로그 ✅

## 워커 행동 분석 (★ 잘한 점)

1. **body에 명시한 금지 사항 모두 준수**: Math.random() 안 씀, three 외 패키지 안 깔림, 외부 CDN 안 씀
2. **DPR cap 2**: 모바일 Retina 대응, mshumer원본 안 봄
3. **한국어 페이지 (lang="ko") + ARIA 라벨**: 사용자 한글 선호 시그널을 자동 반영
4. **THREE.REVISION 로그**: 카드 body의 "three 버전 출력" 요구사항 정확히 충족
5. **loading indicator 자동 hide**: 부팅 완료 시 `setAttribute('hidden', '')` UX 디테일
6. **headless Chromium 검증**: 자체 검증 5개 다 통과 + run #13 831초 만에 done

## 함정 13의 비용과 회복

**비용**:
- 5개 워커 동시 spawn으로 npm install / vite / capture 잠재 경합 (실제 충돌은 안 일어남 — 워커가 workspace 분리)
- 약 4분 (05:48 ~ 05:53) lost to workaround

**회복**:
- 워커 SIGTERM + archive 4장 + 1장 keep 패턴 → 4분 후 정상 dispatch
- 이후 모든 1장씩 dispatch 패턴 정착

**교훈**: **첫 시도부터 5장 일괄 dispatch 절대 금지**. 1장씩 + parent link 패턴.

## 누적 성공 확률 (B 게이트, 이 프로젝트 기준)

| 단계 | 누적 |
|---|---|
| Phase 1 시작 전 | 100% |
| Phase 1.0 done | 75% |
| Phase 1.1 in progress | — |
| Phase 1 끝 (4장 남음) | 75% |
| Phase 2 끝 | 41% |
| Phase 3 끝 | 16% |
| Phase 4 끝 (전체 완성) | 11% |
| **어딘가 의미 있는 산출물** | **89%** |

## 다음 단계 (현재 상태)

- t_266e00c5 (Phase 1.1 엔진 코어) running
- 예상 20~30분 후 done
- 사용자에게 결과 보고 + 4옵션 + 추천으로 Phase 1.2 결정

## 본 스킬에 반영된 학습

1. **함정 12 + 13**: `references/kanban-cli-gotchas-game-orchestration.md`
2. **5-Phase 분해안**: `references/kanban-decomposition.md`
3. **프롬프트 영문+한글 동기 기록**: 사용자 시그널 → SKILL.md 본문 + templates/prompt-log.md
4. **1장씩 dispatch 패턴**: SKILL.md 본문 "디스패치 패턴" 섹션
5. **워커 행동 분석**: 위 6개 잘한 점 → 카드 body 작성 가이드 (특히 "한국어 페이지 + ARIA" 같은 디테일)
