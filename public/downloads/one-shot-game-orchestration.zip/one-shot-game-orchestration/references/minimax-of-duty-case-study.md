# minimax-of-duty 케이스 스터디 (2026-07-27)

> **mshumer/Claude-of-Duty 를 원샷 프롬프트 + 칸반 + Minimax-M3 로 재현**한 1일차 실측.
> 프로젝트명 변경: `claude-of-duty-ko` → `minimax-of-duty` (사용자 명시 요청, 함정 15).

## 디렉터리

`/Users/mac/work/minimax-of-duty/` (git init + commit 박힘)

## 보드

`hermes kanban boards create minimax-of-duty` (slug immutable, 이후 영구)

## 시간 정리

| 시점 | 이벤트 |
|---|---|
| 05:44 | 디렉터리 `/Users/mac/work/claude-of-duty-ko/` 생성 |
| 05:47 | 보드 claude-of-duty-ko + 첫 카드 t_60d85c09 (Phase 1.0) |
| 05:47→06:12 | Phase 1.0 워커 작업 25분 → commit 51c914f (scratch 정리됨) |
| 06:16 | Phase 1.1 t_266e00c5 spawn (scratch 모드, 부모 link t_60d85c09) |
| 06:16→06:29 | Phase 1.1 워커 13분 → commit b81d2a0 (scratch 정리됨) |
| 06:29 | Phase 1.1 워커 done, scratch 워크스페이스 정리 |
| 06:30~06:55 | 사용자가 "저장소 안 만들었나?" 정정 → 운영자가 ARCHITECTURE.md + summary 기반 재구현, vitest 29/29 + vite build PASS, commit `54d01dc` + `b732ea0` |
| 06:55 | 디렉터리명 claude-of-duty-ko → minimax-of-duty 변경, 보드 archive + 새 보드 생성 |
| 07:13 | Phase 1.2 t_3a596bbc spawn, **`--workspace dir:/Users/mac/work/minimax-of-duty`** (함정 14 해결) |
| 07:13→07:40 | Phase 1.2 워커 27분, 16 파일 +2288 insertions, commit `31f750f` (워커 자체 commit) |
| 07:40:17 | commit 직후 ~30초 후 SIGTERM 받음 (함정 17 — 운영자 stuck 판단, 그러나 워커는 commit 직후) |
| 07:42 | dev 서버 SIGTERM 받음 (함정 18 — 30분 사이클 백그라운드 정리), 운영자 즉시 재시작 |
| ~07:55 | Phase 1.3 t_d33fef44 spawn, dir 워크스페이스 패턴 유지 |

## 함정 실측 매핑

### 함정 12 — `hermes kanban create --body-file` 옵션 부재

**발생**: 첫 카드 등록 시도
```bash
cat > /tmp/t001.txt << 'EOF'
...
EOF
hermes kanban create "..." --body-file /tmp/t001.txt
# → unrecognized arguments: --body-file
```

**회복**: write_file → cat + `--body` 인라인
```bash
write_file path="prompts/phase-X.Y-body.md" content="..."
BODY=$(cat prompts/phase-X.Y-body.md)
hermes kanban create "..." --body "$BODY"
```

### 함정 13 — unblock 비대화 환경 hang + dispatcher 5-카드 동시 claim

**발생**: 5장 일괄 unblock 시도 시
```
[Command timed out after 60s]
```

확인 시점에 `running=5` — dispatcher 가 모든 ready 카드를 동시에 claim. 워커 5개 동시 spawn. npm install / vite / capture 포트 경합.

**회복**:
```bash
# 1. 워커 모두 SIGTERM
for pid in $(ps aux | grep -E 'hermes.*t_(id1|id2|...)' | grep -v grep | awk '{print $2}'); do
  kill -TERM $pid
done

# 2. 모든 running 카드 reclaim
for id in t_xxx; do hermes kanban --board <slug> reclaim $id --reason "5-카드 동시 dispatch 회수"; done

# 3. 1장만 keep + 나머지 archive
hermes kanban --board <slug> archive t_yyy  # ×(N-1)

# 4. 그 1장만 dispatch --max 1
hermes kanban --board <slug> dispatch --max 1
```

### 함정 14 — scratch 워크스페이스 = done 직후 dispatcher 정리

**발생**: Phase 1.0 + 1.1 완료 후 사용자 디렉터리(`/Users/mac/work/minimax-of-duty/`) 가 **빈 상태** — commit 51c914f + b81d2a0 의 실제 코드는 scratch 워크스페이스에 있었고 done 직후 dispatcher 가 정리.

사용자 정정: "ㅓ장소는 안만들었나?" (저장소 안 만들었냐는 의미)

**회복 방법 A (Phase 1.0 + 1.1)**: 운영자가 직접 재구현 (Phase 1.1 25분). ARCHITECTURE.md + 워커 latest_summary 보고 6 모듈 + main + test 직접 작성 + vitest 29/29 + vite build 검증 + commit.

**회복 방법 B (Phase 1.2 부터 권장)**: 처음부터 `--workspace dir:<user_dir>` 사용. dispatcher가 scratch 정리해도 사용자 디렉터리는 보존. commit 도 사용자 디렉터리 git repo 에 직접 박힘.

**즉시 인식 신호**:
- 워커 done 알림 후 `/Users/mac/work/<project>/` 에 새 파일 없음
- `git log --oneline` (로컬) 비어있음

**필수 예방 패턴**: 카드 create 시점부터 dir: 워크스페이스
```bash
hermes kanban --board <slug> create "Phase X.Y — ..." \
  --body "$BODY" \
  --workspace dir:/Users/mac/work/<user_dir> \
  --assignee coder
# NOTE: --branch 는 worktree 모드에서만, dir: 모드에서는 빼야 함
```

### 함정 15 — 보드 slug immutable

**발생**: 프로젝트명 변경 시. `hermes kanban boards rename` 은 **display name 만** 변경. slug 자체 immutable.

**회복**:
- 옛 보드 archive: `hermes kanban boards rm <old-slug>`
- 새 보드 create: `hermes kanban boards create <new-slug>`
- 모든 카드 다시 등록 (이전 보드 → 새 보드 마이그레이션 도구 없음)

**예방**: 보드 생성 시점부터 신중하게. 프로젝트명 확정 후 create.

### 함정 16 — `file://` 직접 열기 + vite preview SPA fallback

**발생**: 사용자가 `index.html` 을 `file:///Users/mac/work/minimax-of-duty/index.html` 로 Chrome 에 직접 입력. ES module 이 CORS 차단 → "부팅 중…" 멈춤.

또 다른 함정: `npm run preview` (port 4173) 가 SPA fallback 으로 모든 모듈 경로를 `/index.html` 로 라우팅 → `/src/main.js` 가 1257 bytes (index.html 사이즈) JS 가 아닌 HTML 응답.

**회복**:
- `open_preview` URL 을 항상 **`vite dev` (port 5173)** 로만 사용, **절대 preview (4173) 안 씀**
- vite HMR + on-the-fly 변환 + 모듈별 ESM 응답
- `curl -fs http://127.0.0.1:5173/src/main.js` 로 실제 JS 응답 200 검증 후 미리보기 띄움

**사용자 안내 문구**: "브라우저 `Cmd+Shift+R` (HMR 캐시 무효화) 새로고침"

### 함정 17 — 워커 SIGTERM 직전 commit 완료 가능성

**발생**: Phase 1.2 워커가 patch + vitest + commit 단계에서 5분+ idle. 운영자가 stuck 판단 후 SIGTERM. **워커는 SIGTERM 직전 ~30초 전에 이미 git commit 완료** → 코드 보존. 운영자가 직접 fix patch 했지만 워커 commit 과 동일 fix 라 충돌 없음.

**즉시 인식 신호**: 워커 CPU 0% + 새 파일 0 → 위험. SIGTERM 보내기 전 `git log --oneline | head -3` 으로 commit 신규 여부 확인.

**올바른 판정**:
- 5분+ 무활동 + CPU 0% + **git log 변동 없음** → SIGTERM OK
- 5분+ 무활동 + CPU 0% + **`git log` 에 새 commit** → SIGTERM 보류 (워커가 commit 직후 done 처리 중)

### 함정 18 — dev 서버 30분 사이클 SIGTERM

**발생**: 백그라운드 dev 서버(`npx vite --port 5173`)가 30분 사이클로 SIGTERM 받음. Phase 1.2 워커가 HMR 핫리로드 11번 중 SIGTERM.

`exit_code=143 (SIGTERM)` 은 시스템 백그라운드 정리 또는 Hermes 가 자동 보내는 신호.

**회복**: dev 서버 재시작. 사용자 디렉터리에 코드 박혀있으니 코드 손실 0.

**예방**:
- 운영자가 commit 한 사이클에서 dev 서버 종료 알림 받으면 **즉시 재시작** (5초면 끝)
- 또는 dev 서버를 안 띄우고 **사용자 측에서 필요할 때만 띄우는** 패턴 (사용자 디렉터리 코드만 박고 dev 검증은 사용자 측)

## 결정 보고 형식 (B-Phase-Gate)

각 Phase 끝마다 4옵션 + 추천:
```
- A-2 추천: ...
- A-3: ...
- A-4: ...
- B-0: ...
```

B 게이트 검증:
- Phase 1.0 + 1.1 = (scratch 정리됨) → 운영자 재구현 = 89% 의미 있는 산출물 중 1
- Phase 1.2 = 워커 자체 commit + dir 워크스페이스 = 89% 의 Phase 1 통과

**함정 14 해결 후 Phase 1.2 + 1.3 모두 워커 단독 commit 패턴**. 운영자 재구현 필요 0건.

## 검증 결과

브라우저 `http://127.0.0.1:5173/` (vite dev):
- Phase 1.0 + 1.1: 짙은 청남색 단색 WebGL + `Three.js r180 | preset=ultra shadow=2048pp | rng[0]=0.0211` 로그
- Phase 1.2: 청남색 그라운드 + 갈색 큐브(임시 빌더) + 청남색 지붕 + 그림자
- Chrome 확장 에러 (`r.closest is not a function` at content.js:4) 는 우리 코드 무관

## 카드 body 마커 패턴 (★ 결정적)

모든 카드 body 첫 줄:
```
[DO NOT SPECIFY/DECOMPOSE] 이 카드는 운영자가 직접 작성한 단일 범위.
worker는 kanban_complete 또는 kanban_block만 호출.
kanban_specify / kanban_decompose 호출 금지.

[분류: auto-verifiable] 또는 [분류: human-verifiable]
```

→ 워커가 자동 분해 충돌 안 함. snkrx-web 23번 자동분해 패턴 회피.

## 한글 프롬프트 + 영문 번역 패턴

1. 카드 body = 한글 (워커에게 그대로 전달)
2. PROMPT-LOG.md에 카드 body 발췌 + 영문 번역 동시 기록
3. 워커 latest_summary 도 EN 번역 동시
4. 운영자의 4옵션 질문 (한글)도 EN 번역 동시

`templates/prompt-log.md` 의 본 스킬이 보일러플레이트.
