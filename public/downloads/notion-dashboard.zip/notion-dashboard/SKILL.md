---
name: notion-dashboard
dashboard_db: "$NOTION_DASHBOARD_DB_ID"
description: Notion DB에 ICBM2 자동화 성과를 일별로 누적 기록
version: 2.0.0
author: ICBM2
metadata:
  hermes:
    tags: [notion, dashboard, visualization, cron, automation]
---

# Notion 성과 대시보드 (v2 — DB 기반)

## 개요

모든 자동화 활동 데이터를 날짜별로 Notion Database에 누적 저장합니다. Notion의 필터/정렬/그룹핑으로 자유롭게 분석 가능.

## API 설정

```bash
NOTION_KEY=$(cat $NOTION_TOKEN_PATH)
NOTION_VERSION="2022-06-28"
DASHBOARD_DB_ID="$NOTION_DASHBOARD_DB_ID"
```

## DB 스키마

| Property | Type | 설명 |
|----------|------|------|
| 날짜 | date | 기록 날짜 |
| 카테고리 | select | 크론잡/Ship or Slop/아이디어 노트/봇마당/Tistory/시스템/자기개선/AI 모델 트래커/투자 메모/iOS 트렌드 |
| 지표명 | title | 지표 이름 |
| 값 | number | 수치 |
| 단위 | select | 개/%/회/건/KB |
| 비고 | rich_text | 추가 정보 |

## 실행 방법

```bash
# 오늘 데이터 수집 후 DB에 삽입 (upsert)
python3 scripts/notion_dashboard.py

# JSON으로 데이터만 확인 (DB 미수정)
python3 scripts/notion_dashboard.py --json

# 히스토리 백필 (기존 상태 파일에서 과거 데이터 복구)
python3 scripts/backfill_dashboard.py
```

### 수집 데이터 상세

1. **크론 잡 상태** — 총 실행 횟수, 정상 작동 수
2. **Ship or Slop KR** — 아이디어 제출, 리서치, 리뷰, 투표(Ship/Slop)
3. **노션 아이디어 노트** — 작성 글 수
4. **봇마당** — 게시글, 댓글, 페르소나 종류
5. **시스템** — 메모리 파일 수, 크기

**DB 컬럼 (Phase 2+):** 날짜, 카테고리, 지표명, 값, 단위, 비고, 상태(정상/주의/에러), 전주 대비

**Notion 뷰**

- **📋 전체 현황** — 기본 테이블 (날짜 내림차순)
- **📂 카테고리별** — 보드 뷰 (카테고리별 그룹)
- **📊 최근 7일** — 필터링 테이블
- **📈 일별 요약** — 날짜+카테고리 정렬

**데이터 소스 (Phase 3):** Ship or Slop, 봇마당, 아이디어 노트, 크론잡, 시스템, Tistory, AI 모델 트래커 DB, 투자 메모 DB, iOS 트렌드 DB, Learning Log DB, 스킬 카탈로그

**인텔리전스 (Phase 4):**
- 자동 인사이트 (주간 추이, 가장 활발한 카테고리, 크론잡 안정도)
- Anomaly Detection (활동량 감소, 크론잡 불안정, 카테고리 활동 없음)
- KPI 목표 추적 DB: `$NOTION_KPI_DB_ID` (월간 목표/현재값/달성률)
  - Ship or Slop 200개, 봇마당 60개, 아이디어 노트 60개, 크론잡 정상률 90%

**브리핑 페이지:** "📊 ICBM2 브리핑" — Progress Bar, 주간 비교, Heatmap, 인사이트, Anomaly, KPI

## 자동 업데이트

- **스케줄:** 6시간마다 (00:30, 06:30, 12:30, 18:30 KST)
- **DB:** 매 실행 시 upsert
- **브리핑:** 06:30~07:00, 18:30~19:00, 또는 Anomaly 감지 시에만 업데이트
- **옵션:** `--force-briefing` 강제 브리핑 업데이트
- **Rate limit:** 요청 간 0.35초

## Phase 7~10 추가 기능 (2026-04-12)

**예측 & 트렌드 (Phase 7):** 7일 이동평균 기반 월간 예상치, MoM 성장률, 요일별 사이클 패턴

**알림 & 자동화 (Phase 8):**
- Telegram 일일 브리핑 푸시 (아침/저녁)
- 임계값 알림 (SoS 3일연속 0건, 크론잡 80% 미만, 봇마당 2일연속 0건)
- 자가치유 트리거 (에러 로그 자동 분석)

**플랫폼별 상세 DB (Phase 9):** scripts/dashboard_platforms.py
- Ship or Slop 상세 DB, 봇마당 상세 DB, Tistory 상세 DB

**웹 대시보드 (Phase 10):** 본인 GitHub Pages URL에 배포
- 5탭 구조: 📊 Dashboard → 📈 자동화 성과 → 🤖 Skills → 🧪 AI Models → 🧠 Knowledge Graph
- 기본 활성 탭: Dashboard
- 다크 모드 ICBM 테마, KPI 카드, 라인/바 차트, Heatmap 포함

**Phase 6 (보류):** API 비용 추적 — 주인님 API 키/대시보드 접근 정보 필요

## 관련 파일

| 파일 | 설명 |
|------|------|
| `scripts/notion_dashboard.py` | 메인 대시보드 스크립트 (Phase 1~5 통합) |
| `scripts/backfill_dashboard.py` | 히스토리 데이터 백필 스크립트 |
| `scripts/dashboard_platforms.py` | 플랫폼별 상세 DB 수집 (Phase 9) |
| `scripts/telegram_dashboard_briefing.py` | Telegram 브리핑 푸시 (Phase 8) |

## Notion 링크

- 성과 DB: `https://www.notion.so/$NOTION_DASHBOARD_DB_ID`
- KPI DB: `https://www.notion.so/$NOTION_KPI_DB_ID`
