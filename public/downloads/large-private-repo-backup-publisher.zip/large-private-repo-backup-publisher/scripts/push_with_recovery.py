#!/usr/bin/env python3
"""Pitfall #11/#12 대응 — gh hang 시 3-step 분리 푸시 패턴.

큰 pack에서 `gh repo create --push`가 hang할 때 (15분+ 0% CPU + :443 ESTABLISHED 0)
또는 hang 후 저장소 자체가 안 만들어진 경우 (Pitfall #12, Repository not found)
→ kill -9 <gh_PID> 후 다음 3-step을 시도:
  1. gh repo view (또는 gh api repos/.../commits)로 저장소 존재 + 푸시 완료 여부 확인
  2. 저장소 없으면 `gh repo create <name> --private --description "..."` 별도 호출 (Pitfall #12 회복)
  3. 저장소 있고 푸시 안 됐으면 remote 추가 + `git push -u origin main` 직접 호출 (subprocess timeout=1800)

사용법:
    python3 push_with_recovery.py <repo_name> <target_dir> [--description "회사 외주 자료, 비공개"]

전제:
    - <target_dir>는 이미 git init + commit 완료 상태
    - gh CLI 인증 완료 (sigco3111)
"""
import subprocess
import sys
import argparse
from pathlib import Path

USER = 'sigco3111'


def kill_hanging_gh(repo_name: str) -> bool:
    """gh repo create가 hang 중이면 강제 종료."""
    result = subprocess.run(
        ['pgrep', '-f', f'gh repo create {repo_name}'],
        capture_output=True, text=True
    )
    if result.returncode != 0 or not result.stdout.strip():
        return False
    killed = False
    for pid in result.stdout.strip().split('\n'):
        try:
            subprocess.run(['kill', '-9', pid], capture_output=True)
            print(f"  ⚠️ hang 중인 gh PID {pid} 강제 종료")
            killed = True
        except Exception as e:
            print(f"  kill 실패 PID {pid}: {e}")
    return killed


def check_repo_state(repo_name: str) -> str:
    """저장소 상태 분류: 'pushed' / 'empty' / 'missing' / 'unknown'.

    - 'pushed':   저장소 존재 + 커밋 있음 (완료)
    - 'empty':    저장소 존재 + 빈 상태 (gh repo create만 성공, push 안 됨)
    - 'missing':  저장소 없음 (404, Pitfall #12 케이스)
    - 'unknown':  API 에러/네트워크 등 분류 불가
    """
    r = subprocess.run(
        ['gh', 'api', f'repos/{USER}/{repo_name}/commits'],
        capture_output=True, text=True, timeout=30
    )
    if r.returncode != 0:
        # 404 = 저장소 없음
        if 'Not Found' in r.stderr or '"status":"404"' in r.stderr:
            return 'missing'
        # 그 외 = unknown
        return 'unknown'
    # 성공 = 커밋 있음
    return 'pushed'


def ensure_repo_exists(repo_name: str, description: str = '') -> bool:
    """저장소가 없으면 gh repo create로 생성. 있으면 그대로 통과."""
    state = check_repo_state(repo_name)
    if state == 'pushed' or state == 'empty':
        return True  # 이미 존재
    if state == 'missing':
        print(f"  📦 저장소 없음 → gh repo create로 생성: {repo_name}")
        desc = description or f'{repo_name} (회사 외주 자료, 비공개)'
        r = subprocess.run(
            ['gh', 'repo', 'create', repo_name, '--private', '--description', desc],
            capture_output=True, text=True, timeout=60
        )
        if r.returncode == 0 or 'already exists' in (r.stderr + r.stdout).lower():
            return True
        print(f"  ❌ 저장소 생성 실패: {r.stderr[:300]}")
        return False
    # unknown은 시도해봄
    return True


def push_direct(repo_name: str, target_dir: str, timeout: int = 1800) -> tuple[bool, str]:
    """remote 추가 후 직접 git push."""
    target = Path(target_dir)
    if not target.exists():
        return False, f"디렉터리 없음: {target}"

    subprocess.run(['git', 'remote', 'remove', 'origin'], cwd=str(target), capture_output=True)
    result = subprocess.run(
        ['git', 'remote', 'add', 'origin', f'https://github.com/{USER}/{repo_name}.git'],
        cwd=str(target), capture_output=True, text=True
    )
    if result.returncode != 0:
        return False, f"remote 추가 실패: {result.stderr[:300]}"

    # 직접 push (stderr로 진행 상황 출력)
    result = subprocess.run(
        ['git', 'push', '-u', 'origin', 'main'],
        cwd=str(target), capture_output=True, text=True, timeout=timeout
    )
    if result.returncode == 0:
        return True, result.stdout[-300:]
    return False, result.stderr[:500]


def main():
    parser = argparse.ArgumentParser(description='Pitfall #11/#12 — gh hang 후 3-step 회복 푸시')
    parser.add_argument('repo_name', help='GitHub 저장소명')
    parser.add_argument('target_dir', help='작업 사본 디렉터리')
    parser.add_argument('--description', default='', help='저장소 설명 (Pitfall #12 회복 시 사용)')
    parser.add_argument('--timeout', type=int, default=1800, help='git push timeout 초')
    args = parser.parse_args()

    repo_name = args.repo_name
    target_dir = args.target_dir

    # Step 1: hang 중인 gh 프로세스 kill
    if kill_hanging_gh(repo_name):
        print(f"  ⚠️ gh hang 감지, kill 완료")
    else:
        print(f"  → hang 중인 gh 없음")

    # Step 2: 저장소 상태 확인
    state = check_repo_state(repo_name)
    print(f"  🔍 저장소 상태: {state}")

    if state == 'pushed':
        print(f"  ✅ 이미 푸시 완료: {repo_name}")
        sys.exit(0)

    if state == 'missing':
        # Pitfall #12 회복: 저장소 생성
        if not ensure_repo_exists(repo_name, args.description):
            print(f"  ❌ 저장소 생성 실패")
            sys.exit(1)

    if state == 'empty':
        # Pitfall #11 회복: 저장소는 있지만 푸시 안 됨
        pass

    # Step 3: 직접 git push
    print(f"  🔄 {repo_name} 직접 push 시작 (timeout={args.timeout}s)...")
    ok, msg = push_direct(repo_name, target_dir, timeout=args.timeout)
    if ok:
        print(f"  ✅ 푸시 성공: {msg[:200]}")
        sys.exit(0)
    else:
        print(f"  ❌ 푸시 실패: {msg}")
        sys.exit(1)


if __name__ == '__main__':
    main()
