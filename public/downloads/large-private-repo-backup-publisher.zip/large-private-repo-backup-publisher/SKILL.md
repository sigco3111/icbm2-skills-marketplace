---
name: large-private-repo-backup-publisher
description: Split 1GB+ backups into sub-700MB GitHub PRIVATE repos.
---

# Large Private Repo Backup Publisher

## 발동 조건
- 사용자가 "회사 자료 / 비공개 자료 / 백업 폴더"를 깃허브 비공개 저장소에 올려달라고 요청할 때
- 원본 폴더가 **1GB+**일 때 (단일 비공개 푸시 못함)
- 여러 개의 작은 비공개 저장소로 분할해야 할 때

## 왜 이게 필요한가
- GitHub 비공개 저장소는 단일 푸시 2GB까지만 안정적
- **1.3GB+ pack 단일 푸시는 HTTP 408 timeout + send-pack 끊김 빈번** (검증됨 — tycoon 1.9GB 첫 시도에서 발생)
- 50MB+ 단일 파일은 GitHub 거부 (.gitignore에 자동 추가 + `.large_files_excluded/`로 원본 보존)

## 5단계 워크플로

### 1단계 — 폴더 구조 분석
- `du -sh /path/to/backup/*` — 큰 폴더 식별
- 큰 폴더별로 내부 서브디렉토리 크기 다시 측정 → 분할 단위 결정
- 1GB+ 큰 폴더는 **서브디렉토리 단위로 분할** 검토 (각 ≤700MB 권장)
- **압축 파일 (*.zip *.7z *.rar *.alz *.egg) 일괄 제외 후 재측정** — `find ... ! \( -name '*.zip' ... \) | du -ch` (Pitfall #13 참조). 분할 결정은 **재측정 값**으로. NDS-SDK 2.0GB → 312MB 케이스처럼 압축이 1.5GB+ 차지하는 경우 분할 단위가 크게 바뀜
- **PPTX/PPT 워드 파일도 pack 비대화 원인**: 50MB 미만이어도 10개+ ppt 폴더는 pack 100MB+ 증가. PPT는 워드 파일이 아니라 바이너리(zip 압축) 형태라 delta가 큼. 분할 단위에 ppt 폴더별 묶음 포함 권장
- **한국어/공백/괄호 폴더명 매칭 주의**: 스크립트에서 추론한 이름이 원본과 다를 수 있음. 검증 사례 (2026-07-31):
  - 스크립트는 `마법상점DS/스크린샷`으로 가정했지만 실제 폴더명은 `마법상점타이쿤DS/스크린샷`
  - `문서관련`이 아니라 `문서관련 (사업계획서, 제안서 관련)` (괄호+공백)
  - 해결: `ls "/원본/폴더"`로 직접 확인 후 분할 스크립트에 정확한 경로 명시
- **상위 1~2개 큰 단일 파일이 분할의 1차 기준**: 큰 폴더에서 `find ... -size +50M`으로 식별 후, 그 파일이 들어있는 폴더는 분할 단위로 분리하거나 `.large_files_excluded/`로 제외
- **분할 단위 후보 확인** — `du -sh` 와 `find ... | du -ch` 결과가 다르면 (Pitfall #13) 분할 단위 재검토. 50MB+ 단일 파일이 압축이 아닌 PDF/EXE면 100MB 미만이라 푸시 가능 (Pitfall #14)

### 2단계 — 작업 사본 생성 + 50MB+ 파일 제외
```python
SRC = Path('/Users/mac/work/backup/.../대상폴더')
DST = Path('/Users/mac/work/github-private')

EXCLUDE = ('*.opt','*.plg','*.ncb','*.exe','*.dll','*.obj','*.lib',
           'Debug','Release','ipch',...)  # VC++6 + Android + MFC + 알집
EXCLUDE_DIRS = ('.git','.vs','bin','obj','node_modules','.large_files_excluded')

def copy_with_excludes(src, dst):
    # copy + 50MB+ 파일은 dst/.large_files_excluded/<구조>로 이동
```

### 3단계 — 각 저장소 README + LICENSE + .gitignore
- README.md: 화려한 템플릿 (11섹션, 500~1000줄, shields.io 배지 + 표)
- LICENSE: MIT 표준
- .gitignore: VC++6 (*.opt *.plg *.ncb) + Android (*.apk *.dex) + MFC (*.tmp) + .large_files_excluded/

### 4단계 — git init + commit + push (순차)
- **각 저장소 ≤700MB 권장** (안정성)
- 작은 것부터 푸시 (성공률 상승 효과)
- `gh repo create <name> --private --source . --push` 한 줄로 처리

### 5단계 — 검증 + 진행 보고
- `gh repo view <name> --json visibility` 로 PRIVATE 확인
- 매 푸시 후 사용자에게 간단 보고 (진행 중 / 성공 / 실패)

## 핵심 함정 (검증됨)

### Pitfall #1 — 1.3GB+ pack HTTP 408 timeout (가장 중요)
- 단일 pack이 1.3GB+이면 `git push`가 HTTP 408으로 끊김
- **해결** — 폴더를 서브디렉토리 단위로 쪼개서 pack 크기 ≤700MB로 유지
- 또는 Git LFS 도입 (`.gitattributes` + `git lfs install` + `lfs track`)

### Pitfall #2 — 50MB+ 단일 파일 거부
- `*.zip` 검수용 APK, `*.psd` 포토샵 원화, `*.mov` 영상 등
- GitHub는 100MB+ 단일 파일 거부
- **해결** — `.large_files_excluded/` 폴더로 이동 + `.gitignore`에 등록

### Pitfall #3 — pack에 큰 객체 누적
- `git rm --cached`만으로는 pack 크기 안 줄어듦
- BFG Repo-Cleaner 미설치 시 manual `git filter-branch --tree-filter` + `git gc --prune=now --aggressive` 필요
- 또는 처음부터 작업 사본에 큰 파일 안 넣기 (가장 안전)

### Pitfall #4 — README에 원본 경로/계정 노출 금지
- README에 회사명/클라이언트명/연락처 절대 노출 X
- 비공개 가시성이라도 향후 권한 변경 가능성 대비

### Pitfall #5 — 원본 폴더 직접 수정 금지
- `cp -r` 또는 `shutil.copytree`로 작업 사본 분리
- 원본 `/Users/mac/work/backup/...` 절대 안 건드림
- 실수 대비 `EXCLUDE_DIRS`에 `.large_files_excluded/` 명시

### Pitfall #6 — gh CLI 출력 끊김 false positive
- 푸시가 진행 중일 때 `process.poll()`이 `running` 보고해도 GitHub에는 이미 푸시 완료된 상태일 수 있음
- 5분+ 막혀있을 때 `netstat -an -p tcp | grep :443.*ESTABLISHED`로 확인
- 또는 `gh repo view <name> --json visibility`로 PRIVATE 여부 확인 후 다음 저장소 진행

### Pitfall #7 — 단계별 푸시 시 443 연결 fallback
- 푸시 후 `gh repo view` 호출 시 443 ESTABLISHED가 0으로 보일 수 있음
- 명령 사이의 transient 상태일 뿐, 실패 아님
- 30초 기다린 후 다시 확인

### Pitfall #8 — 비디오/오디오 확장자 (50MB 미만이어도 pack 비대화)
- `*.ASF`, `*.WMV`, `*.WAV`, `*.MP3`, `*.OGG` 등도 .gitignore에 명시 권장
- 50MB 미만이라도 pack에는 그대로 들어가므로 폴더당 20개+ 영상 파일이면 pack이 수백 MB 증가
- 검증 사례 (2026-07-31): secrets-2-seminar 폴더의 17개 폴더에 영상 파일만 있어서 첫 커밋이 0이 안 됨
  → .gitignore에 `*.ASF *.WAV *.MP3` 추가 후 git add가 즉시 통과
- **해결** — 작업 사본 생성 직후 `.gitignore`에 모든 영상/오디오 확장자 일괄 등록

### Pitfall #9 — 분할 직후 _finalize 스크립트 실행 시 작업 사본 점검
- 분할 직후 일부 작업 사본 디렉터리가 사라지거나 이름 충돌로 미생성될 수 있음
- 검증 사례 (2026-07-31): `private-company-nds-dsgostop-artwork`가 분할 후 디렉터리로 떠있었으나 _finalize 스크립트 실행 시점에 사라짐
- **해결** — _finalize 스크립트 실행 전에 `ls /Users/mac/work/github-private/private-company-*`로 대상 디렉터리 모두 존재 확인
  → 누락 시 원본 백업에서 `shutil.copytree`로 즉시 재복사 + .gitignore/LIC 즉시 적용

### Pitfall #10 — gh repo create --push 출력 캡처 비결정성
- `gh repo create --private --source . --push`의 stdout이 다음 저장소로 진행 시점에 화면에 표시 안 될 수 있음 (Python subprocess 버퍼링 + tee 출력 경합)
- 검증 사례 (2026-07-31): proc_e77c592ae4ae는 10분 걸린 마지막 푸시를 출력에 표시하기 전에 백그라운드 완료 알림으로 합계만 보냄
- **해결** — `process.poll()` 대신 `gh repo view <name> --json visibility` 사용해서 GitHub API 직접 확인 (private = 성공, error = 실패). 1차 검증 후 다음 저장소 진행 패턴이 robust
- 또는 각 푸시 사이에 `time.sleep(5)` 추가해서 stdout 버퍼가 비워질 시간 확보

### Pitfall #11 — gh repo create --push 자체가 hang (가장 위험)
- 큰 저장소에서 `gh repo create --private --source . --push`가 0% CPU로 15분+ 멈춤. gh 프로세스는 살아있지만 진행이 안 되고 `netstat :443 ESTABLISHED` 도 0
- GitHub에 빈 저장소는 생성됐지만(`gh api repos/.../commits` → `Git Repository is empty`), 푸시는 무한 대기
- 검증 사례 (2026-07-31): `private-company-nds-magicstore-screenshots` (506 파일, 1.4GB 스크린샷 원본)에서 gh hang. 15분+ 대기 후 `kill -9 <PID>`로 종료
- **핵심 해결 — 2-step 분리 패턴**:
  1. `gh repo create <name> --private --description "..." --source .` (푸시 없이 저장소만 생성, 또는 `gh repo create <name> --private --push`로 시도 후 hang 시 강제 종료)
  2. `git remote remove origin && git remote add origin https://github.com/<user>/<name>.git`
  3. `git push -u origin main` (subprocess.run timeout=1800)
  - 직접 `git push`는 큰 pack도 stderr로 진행 상황 출력하며 안정적으로 끝남
- **진단 순서**:
  1. `ps aux | grep "gh repo create"` — gh 프로세스 살아있는지
  2. `gh api repos/<user>/<repo>/commits` — 저장소가 비어있는지 (409 empty) vs 푸시 완료 (커밋 있음)
  3. `netstat -an -p tcp | grep ":443.*ESTABLISHED" | wc -l` — 0이면 gh가 실제 작업 안 함
  4. 15분+ hang + 위 3개 조건 충족 시 → `kill -9 <gh_PID>` 후 2-step 분리 패턴으로 전환

### Pitfall #12 — gh hang 후 재시도시 "Repository not found" (gh repo create 자체가 실패한 케이스)
- Pitfall #11 kill -9 후 같은 스크립트로 재시도하면 **`Repository not found`** 로 실패할 수 있음
- 원인: gh가 hang 중에 **저장소 생성 단계에서 멈춘 것**이라 GitHub에 저장소 자체가 없는 상태. 단지 `process`가 살아있어서 다음 스크립트 루프가 "이미 gh가 push 중"이라고 판단할 수 있음
- 검증 사례 (2026-07-31): `private-company-proposal-docs` — 첫 gh repo create가 hang되어 kill, 재시도 시 `Repository not found` 발생
- **수정된 3-step 회복 패턴**:
  1. `kill -9 <gh_PID>` (Pitfall #11 동일)
  2. **`gh repo create <name> --private --description "..."` 별도 실행** — 저장소 생성 보장 (이미 있으면 "already exists" 에러지만 무시)
  3. `git remote remove origin && git remote add origin https://github.com/<user>/<name>.git && git push -u origin main`
- **진단 추가**:
  - `gh api repos/<user>/<repo>` — 404면 저장소 없음 → 2단계 `gh repo create` 필요
  - 200이면 저장소 존재 → 바로 3단계 push
- `push_with_recovery.py`는 `verify_pushed`에서 200+커밋 = 완료 / 409 empty = 푸시 안 됨 / 그 외(404, network err) = 저장소 없음 으로 분기 후 step 2 자동 호출로 보강되어야 함 (아래 스크립트 참조)

### Pitfall #13 — `du -sh`의 .large_files_excluded false positive (재측정 필수)

`du -sh <작업사본>` 은 `.large_files_excluded/` 폴더까지 합산해서 **실제 pack 크기보다 크게** 표시한다. `du -sh`만 보고 분할 결정하면 잘못된 분할 단위가 나온다.

검증 사례 (2026-07-31, NDS-SDK 2.0GB → 1.2GB 케이스):
- `du -sh private-nds-sdk-core/` → **366M** (실제 pack은 180M)
- `du -sh private-nds-sdk-docs/` → **312M** (실제 pack은 302M)
- `du -sh private-nds-education-data/` → **395M** (실제 pack은 290M)
- `du -sh private-nds-education-set/` → **440M** (실제 pack은 440M)
- **모두 700MB 한도 내**지만 `du -sh`만 보면 Education 두 개가 각각 800MB+로 보임

**정확한 재측정 명령** — `find ... ! -path "*/.large_files_excluded/*" | xargs -0 du -ch`:
```bash
# 실제 pack 크기 (제외 폴더 빼고)
find "$d" -type f ! -path "*/.large_files_excluded/*" ! \( \
  -name '*.zip' -o -name '*.7z' -o -name '*.rar' -o -name '*.alz' -o -name '*.egg' \
\) -print0 2>/dev/null | xargs -0 du -ch 2>/dev/null | tail -1

# .large_files_excluded/ 안의 파일 수 / 크기 (참고)
du -sh "$d/.large_files_excluded" 2>/dev/null
```

**워크플로우 적용** — `du -sh`로 1차 측정 후, 분할 직전 `find ... du -ch`로 재측정해서 분할 단위 확정. Pitfall #1의 "≤700MB" 기준은 **재측정 값**으로 적용.

### Pitfall #14a — 1 리포 = 1 프로젝트 분할 + N개 README 일괄 생성 패턴 (2026-07-31, 04-원본-소스-에셋-백업)

원본 폴더 안에 **독립적인 서브 프로젝트 30~50개**가 있을 때 (예: `Mobile_Work/`, `NDS_Work/` 각각 30+개 게임 프로젝트), 사용자가 "프로젝트 단위로 1 리포 = 1 프로젝트"를 명시하면 다음 패턴 적용:

**워크플로우 (자동화 필수 — 수동으로는 41개 푸시 불가능)**:
1. **메타 추출** (1회): `find ... ! -name '*.zip' ... -print0 | xargs -0 stat -f %z` + `find ... | wc -l` → 각 프로젝트 (slug, size_mb, files) 메타 수집
2. **README 자동 생성** (Python 스크립트): 메타 인라인 → `private-proj-{slug}/README.md` 일괄 작성. 템플릿은 shields.io 배지 7~8개 + 프로젝트 정보 박스 + 트리 + 푸시 노트
3. **작업 사본 셋업** (Python 스크립트): 각 슬러그 폴더에 원본 복사 → `*.zip/7z/rar/alz/egg` + `*.srl/nds/apk/dex/app/ipa` + `.svn/` 자동 제외 → git init
4. **푸시 자동화** (Python 스크립트, 2-step recovery 내장): 작은 것 → 큰 것 순, `time.sleep(2)` rate limit 회피, `gh repo create --push` 실패 시 2-step 분리 패턴

**검증 사례 (2026-07-31)**:
- 04-원본-소스-에셋-백업 41개 프로젝트 (1.4GB) → 41개 비공개 리포 푸시, **0건 실패 / 0회 Recovery 발동**
- 가장 큰 화랑태권(166MB) + DS 고스톱(173MB)도 1차 시도 성공
- 총 6분 소요

**슬러그 컨벤션**:
- 형식: `private-proj-{platform}-{english-slug}`
- 예: `private-proj-mobile-dino-catch`, `private-proj-nds-ds-gostop`, `private-proj-bada-ar-billiards`
- 한글 폴더명은 영문 슬러그로 변환 (예: `화랑태권` → `hwarang-taekwon`, `바다/AR당구` → `bada-ar-billiards`)

**장점**:
- 프로젝트별 독립적 백업 → 한 리포가 망가지거나 권한 바뀌어도 다른 리포 안전
- 각 리포의 `gh repo view`에서 README 한 번에 확인 가능
- 41개 푸시도 자동화 스크립트 한 번이면 끝

**단점**:
- 41+개 푸시 시 GitHub rate limit 주의 (각 푸시 사이 `time.sleep(2)` 권장)
- 슬러그 결정은 사람이 해야 함 (스크립트가 추론하면 한글 폴더명 오타 위험)
- 같은 시리즈 프로젝트는 slug prefix 일관성 유지 (`private-proj-mobile-*`, `private-proj-nds-*`)

### Pitfall #14b — `nohup &` 사용 금지 (Hermes 도구 규칙)

푸시 자동화 스크립트를 백그라운드로 돌릴 때:
- `nohup python3 script.py &` 또는 `python3 script.py &` → Hermes가 거부 ("Foreground command uses shell-level background wrappers")
- **해결** — `terminal(command="...", background=True, notify_on_complete=True, timeout=3600)` 사용
- `notify_on_complete=True`는 거의 항상 켜기 (끄면 백그라운드 완료 알림 못 받음)
- 푸시 완료 후 `process(action="log")` 또는 `tail /tmp/_push_log.txt`로 진행 확인

이는 Hermes 환경 규칙 (런타임)이므로 다른 일반 도구 스킬에서 다뤄야 함.

### Pitfall #14c — 한글 폴더명 메타 dict 매칭 실패 (2026-07-31, 41개 프로젝트 자동화)

`find`로 추출한 메타를 Python `dict`에 키로 저장할 때 **한글 폴더명이 들어간 튜플 키는 `dict.get()` 매칭이 실패**해서 0MB로 떨어짐. **재현 가능한 학습**:

**실패 사례**:
```python
meta = {}  # {(parent, name): (size, files)}
for line in meta_file:
    parent, name, b, fc = line.split("|")
    meta[(parent, name)] = (int(b), int(fc))  # ← 한글 키

# 41개 모두 0MB 반환
for p in PROJECTS:
    size, files = meta.get((p[1], p[5]), (0, 0))  # (platform, ko_folder)
    # ↑ 한글이 들어간 키 매칭이 깨짐
```

**근본 원인 (추정)** — `find` 출력 + Python 파일 I/O + `split("|")` 사이에 **인코딩 차이 or bytes/str 혼재** 가능성. 한 줄씩 디버깅하면 정상이었지만, 41개 루프에서 모든 키가 매칭 실패.

**해결** — **메타를 Python 코드에 인라인** (이중 소스 오브 트루스 회피):
```python
PROJECTS = [
    (1, "Mobile_Work", "private-proj-mobile-1942-java", "1942_JAVA", ..., 0.5, 114),
    #  ↑ 모든 메타(슬러그/이름/크기/파일수)를 코드에 직접 박음
]
```
- 장점: dict 매칭 버그 원천 차단 + 코드 자체가 self-documenting
- 단점: 새 프로젝트 추가 시 메타 측정 → 코드에 직접 추가 필요

**대안 — 정규화 키**:
```python
def norm(s):
    return s.encode('utf-8').decode('utf-8').strip()
meta = {(norm(p), norm(n)): (b, fc) for ...}
```
- 효과 미미 (이 문제 자체가 인코딩 문제가 아닐 수 있음)

**일반 원칙** — 30+개 항목의 메타를 자동화 스크립트에 주입할 때는 **dict 매칭 < 인라인 리스트 < JSON 파일 로드** 순으로 단순화. 41개처럼 많으면 JSON이 가장 robust하지만, **수정 빈도가 낮으면 인라인이 가장 안전**.

### Pitfall #14 — 100MB 미만 단일 파일은 사실 푸시 가능 (Pitfall #2 보완)

기존 Pitfall #2는 "100MB+ 단일 파일 거부"로만 적혀 있지만, **50MB~100MB 사이 단일 파일은 사실 푸시 가능** (경고만 출력). 검증 사례 (2026-07-31):
- `NITRO_ProgramingManual_v142_ko.pdf` 75.06MB × 3개 → `remote: warning: ... is 75.06 MB; this is larger than GitHub's recommended maximum file size of 50.00 MB` 경고 후 **푸시 성공**
- 100MB 미만은 모두 통과

**분류 기준 갱신**:
- **100MB+ 단일 파일** → `.large_files_excluded/`로 **반드시 제외** (푸시 거부됨)
- **50MB~100MB 단일 파일** → `.large_files_excluded/`로 이동 **권장** (경고는 나오지만 통과하긴 함. 분할 압박 시 그대로 두고 `git add -A` 통과 여부로 결정)
- **50MB 미만 단일 파일** → 그대로 둠 (문제 없음)
- **파일 수 10+ × 30MB+** → pack 비대화 우려. `*.ASF *.WMV *.WAV *.MP3` 등 일괄 .gitignore 권장 (Pitfall #8)

**검증 절차** — 큰 PDF/EXE가 있으면 푸시 후 `gh api repos/<user>/<repo>/commits`로 커밋 존재 확인. 경고 떠도 커밋 있으면 성공.

## 검증된 분할 전략 (2026-07-31)

대용량 폴더를 서브디렉토리 단위로 분할할 때:

| 원본 | 크기 | 분할 단위 | 분할 후 최대 크기 |
|---|---|---|---|
| tycoon (1.9GB) | 큰 마법상점 폴더 3개 + 작은 것 2개 | 각 마법상점 1개씩 + (견인+뷰티) 묶음 | ms1=894MB, ms2=435MB, ms3=560MB, misc=74MB |
| matgo (1.8GB) | 뉴맞고 850MB + 나머지 | 뉴맞고 단독 + 나머지 묶음 | newmatgo=850MB, misc=1GB+(큰 폴더 미분할) |
| dsgostop-artwork (1.7GB) | 만화 1GB + 아트워크 689MB + 사운드 등 | 만화/아트워크/사운드+기타 | manga=1GB, artwork=689MB, sound-full=700MB |
| secrets-2 (2.7GB) | 세미나 2.2GB + 나머지 557MB | 세미나 단독 + 나머지 | seminar=17파일(=푸시 가능), misc=550MB |
| gunblade-proto (2.4GB) | zip 2.1GB + 나머지 | zip을 큰파일이므로 제외 + 광표작업 등 | extracted=191 파일 |
| **NDS-SDK (2.0GB)** | **zip/7z/rar 23개 1.5GB+ 차지** | **압축 일괄 제외 후 4개 리포** (sdk-core/sdk-docs/edu-data/edu-set) | **각 180~440MB** |
| **04-원본-소스-에셋-백업 (1.4GB)** | **Mobile_Work 31개 + NDS_Work 4개 + 바다 4개 + iOS 1개 + 안드로이드 1개 = 41개 독립 프로젝트** | **사용자 명시적 요청: 1 리포 = 1 프로젝트. README/푸시 모두 Python 자동화. 작은 것→큰 것 순** | **각 0.1~173MB, 총 41 리포** |

핵심: **가장 큰 단일 객체(zip/ppt)가 들어있는 폴더는 자동으로 제외 + 나머지로 분할**. 이렇게 하면 pack 크기 ≤700MB로 유지되어 HTTP 408 회피 가능

## 검증된 사례 (2026-07-31)
- 짧은 명령, 미니멀 응답
- 4옵션 + 추천
- 큰 결정은 단계별 검증 ("A", "B-2" 등)
- 풀 자동위임 OK (private GitHub push는 user-owned 영역)
- 한국어 응답 (한자 최소화)

## 검증된 사례 (2026-07-31)
- 원본 17GB 분할 → 총 30+개 비공개 저장소
- **누적 푸시 성공 35개** (옵션 A 1단계 10 + 옵션 A 2단계 10 + 옵션 B 작은 6 + 옵션 B 큰 6 + tycoon-magicstore1 + screenshots + proposal-docs)
- tycoon 1.9GB 첫 푸시는 HTTP 408 실패 → ms1(894MB)/ms3(560MB)/ms2(435MB)/misc(74MB) 4개로 재분할하여 모두 푸시 성공
- nds-magicstore-screenshots (1.4GB 원본, 506 파일) 분할 후 gh hang → Pitfall #11 2-step 분리 패턴으로 푸시 성공 (마법상점DS 스크린샷 외주 자료 비공개 저장소 푸시 (506 파일) 커밋)
- proposal-docs (1.3GB 원본, 265 파일) gh hang 후 Pitfall #12 (`Repository not found`) → 3-step 패턴 (별도 gh repo create 후 push)으로 회복 성공 (사업계획서/제안서 문서 비공개 저장소 푸시 (265 파일) 커밋)
- 분할 시 폴더명 매칭 함정: `마법상점DS` 추론이 `마법상점타이쿤DS`로 다름, `문서관련`이 `문서관련 (사업계획서, 제안서 관련)`로 다름 → `ls` 직접 확인 필수
- **NDS-SDK (2.0GB → 4개 비공개 리포 푸시 성공, 2026-07-31)** — 압축(*.zip *.7z *.rar *.alz) 일괄 제외로 1.2GB로 축소 → sdk-core(180MB) / sdk-docs(302MB) / edu-data(290MB) / edu-set(440MB) 분할. 75MB ProgrammingManual PDF 3개는 경고만 뜨고 푸시 성공 (Pitfall #14). 클라이언트 SDK 자료 (닌텐도 독점) + 교육 과정 자료 4트랙 (프로그래머/디자이너/그래픽/공통)
- **04-원본-소스-에셋-백업 (1.4GB → 41개 비공개 리포 푸시 성공, 2026-07-31)** — `1 리포 = 1 프로젝트` 정책 (사용자 명시). 41개 프로젝트 (Mobile 31 + NDS 4 + 바다 4 + iOS 1 + 안드로이드 1). Python 자동화 3단계: (1) 메타 추출 → (2) README 일괄 생성 + 작업 사본 셋업 → (3) 푸시 (작은 것 → 큰 것, time.sleep(2) rate limit 회피, 2-step recovery 내장). **41/41 성공, 0회 Recovery 발동, 6분 소요**. 한글 폴더명 메타 dict 매칭 실패 (Pitfall #14c) → 인라인 메타로 우회. 가장 큰 화랑태권(166MB) + DS 고스톱(173MB)도 1차 시도 성공
- **README 통일 템플릿 (NDS-SDK 4리포에 적용, 검증됨)**:
  1. 히어로 섹션 (shields.io 배지 5~6개: status/year/platform/type/license/visibility)
  2. ASCII 박스 다이어그램 (이 리포에 들어있는 것 한눈에)
  3. 디렉토리 트리 (이모지 + 크기 + 파일수)
  4. 핵심 자료 하이라이트 (⭐ 큰 PDF/설치 프로그램)
  5. 카테고리별 표 (SDK 모듈 / 트랙 / 단계)
  6. 파일 통계 / 확장자 분포
  7. 제외된 파일 표 (.large_files_excluded/ 참고용)
  8. 라이선스/법적 고지 (닌텐도 독점 자료 비공개 명시)
  9. Footer에 "Part of NDS SDK Archive (4 repos)" 형식 시리즈 링크
- **프로젝트 단위 README 템플릿 (41개 프로젝트에 적용, 검증됨, 2026-07-31)**:
  1. 히어로: shields.io 배지 7~8개 (status/year/platform/genre/size/files/visibility)
  2. 프로젝트 정보 박스 (한글/영문/장르/시대/플랫폼/크기/파일수)
  3. 디렉토리 트리 (slug 폴더 구조)
  4. 사용 기술 섹션 (언어/엔진/플랫폼)
  5. 제외된 파일 (.large_files_excluded/ 안내)
  6. 법적 고지 (회사 자산/IP 외부 공유 금지)
  7. Footer "Part of N개 프로젝트 Archive — No.X/N — 슬러그: ..."
  - **자동 생성 핵심** — 메타 (slug, 영문명, 한국어명, 장르, 짧은설명, 시대, size_mb, files) 인라인 → Python 스크립트 1개로 41개 README 일괄 생성
  - **장점** — 수동 작성 대비 시간 99% 절약 + 일관성 보장 + 회차당 5KB 이내 동일 포맷

## 다음 세션 재개 방법
```bash
# 작업 사본 위치
ls /Users/mac/work/github-private/

# 큰 저장소 분할 스크립트
cat /Users/mac/work/github-private/_split_large_repos.py

# 푸시 안 된 저장소 찾기
for d in /Users/mac/work/github-private/private-company-*; do
  if [ -d "$d/.git" ] && [ -z "$(gh repo view $(basename $d) 2>&1 | grep PRIVATE)" ]; then
    echo "미푸시: $(basename $d)"
  fi
done
```

## Pitfall #11 회복 스크립트

gh repo create --push가 hang할 때 (Pitfall #11) 다음 스크립트로 자동 회복:

```bash
python3 ~/.hermes/skills/github/large-private-repo-backup-publisher/scripts/push_with_recovery.py \
  <repo_name> /Users/mac/work/github-private/<target_dir>
```

스크립트 동작:
1. `pgrep -f "gh repo create <repo_name>"` 으로 hang 중인 gh 프로세스 찾아서 `kill -9`
2. `gh api repos/.../commits` 으로 푸시 완료 여부 확인 (이미 성공하면 skip)
3. 미완료 시 remote 추가 + `git push -u origin main` 직접 호출 (subprocess timeout=1800)

## N개 프로젝트 자동 푸시 스크립트 (신규, 2026-07-31)

`scripts/push_n_projects.py` (생성 예정) — 30+개 프로젝트를 자동으로 푸시할 때:
- 메타 인라인 (slug, 영문명, 한국어명, 장르, 설명, 시대)
- 작은 것 → 큰 것 정렬 (Pitfall #11 회피 효과)
- 2-step recovery 내장 (gh hang 시 자동 복구)
- 푸시 사이 `time.sleep(2)` rate limit 회피
- 41/41 검증 사례 (2026-07-31, 0회 Recovery 발동, 6분 소요)

다음 세션 재개 시 `scripts/push_n_projects.py`를 확인하고 41개 케이스에서 검증된 템플릿을 그대로 사용 가능.

## 발동 명령
- "회사 자료 비공개로 올려줘"
- "이 폴더 깃허브 비공개로 백업해줘"
- "17GB 분할해서 비공개 저장소 푸시"
- "gh push가 안 끝나", "push 멈춤", "gh hang" → Pitfall #11/#12 진입
