---
name: notion-db-bulk-analysis
description: Notion DB → page-vs-DB → paginate → schema → candidates.
version: 1.0.0
author: community
license: MIT
metadata:
  hermes:
    tags: [Notion, Analysis, Database, Pagination, Trending]
    homepage: https://developers.notion.com
prerequisites:
  env_vars: [NOTION_API_KEY]
---

# Notion DB Bulk Analysis

Class-level workflow for analyzing a Notion database when the user supplies a URL/ID and wants insights (statistics, trends, candidate extraction, content audit). The DB might have 10 rows or 10,000 — the pattern scales.

Companion to the bundled `notion` API skill. That one covers the API surface; this one covers the *analysis pipeline* (URL → page-or-db ID → fetch → schema → quality → insights).

## When to use this skill

- User pastes a Notion URL with a 32-hex ID and asks for trend analysis, recommendations, or summary
- User wants to extract candidates/projects/keywords from a large DB
- User wants to audit a DB's data quality (which fields are empty, which are duplicated)
- A pipeline pushes data into Notion (e.g. `github-trending-monitor`) and you need to mine it

**NOT for**: writing rows back to Notion (use `notion` API), exploring a single page, or one-shot CRUD.

## 5-Phase Pipeline

### Phase 1 — Identify: Page vs Database

The user almost always pastes a URL like:

```
https://www.notion.so/<workspace>/<TITLE>-<32-hex-id>?v=<view-id>
```

The 32-hex-id (`33f76f2e90978176a537d40ebb476ef9`) is **ambiguous** — it could be a page OR a database. Always check, never assume.

```bash
# Try as page first
curl -s "https://api.notion.com/v1/pages/33f76f2e-9097-8176-a537-d40ebb476ef9" \
  -H "Authorization: Bearer $NOTION_API_KEY" \
  -H "Notion-Version: 2025-09-03"
```

If response is `{"object":"error","status":400,"code":"validation_error","message":"Provided ID ... is a database, not a page..."}` → it's a database. Switch to:

```bash
# Now hit the database endpoint
curl -s "https://api.notion.com/v1/databases/33f76f2e-9097-8176-a537-d40ebb476ef9" \
  -H "Authorization: Bearer $NOTION_API_KEY" \
  -H "Notion-Version: 2025-09-03"
```

The DB response contains a `data_sources[]` array — each entry has the **`data_source_id`** you need for querying. **Do NOT use the top-level `id` for page-creation; use the nested `parent.database_id`** (see bundled `notion` skill's "Two IDs" note).

### Phase 2 — Introspect schema

Before parsing anything, list property names and types. This prevents assuming every DB has `Name`/`Title` as English columns. Many ICBM2 DBs use Korean (`이름`, `날짜`, `상태`).

```bash
DATA_SOURCE_ID="33f76f2e-9097-811d-92e9-000b3bbd10de"
curl -s "https://api.notion.com/v1/data_sources/$DATA_SOURCE_ID" \
  -H "Authorization: Bearer $NOTION_API_KEY" \
  -H "Notion-Version: 2025-09-03"
```

Parse out:
- Property names (could be Korean)
- Each property's `type` (`title`, `rich_text`, `select`, `date`, `checkbox`, `number`, `url`)
- For `select` properties: full options list (`select.options[].name`)
- For `date` properties: format (`{"start": "2026-01-15", "end": null}`)

### Phase 3 — Paginate-fetch all rows

Hardcoded `page_size` is 100 max. For DBs > 100 rows, use `start_cursor` + `has_more` loop. **Write the loop in Python (or execute_code)** — bash loops with curl + JSON parsing are brittle.

```python
import subprocess, json
NOTION = open("/Users/mac/.hermes/secrets/notion_token.txt").read().strip()
DS = "33f76f2e-9097-811d-92e9-000b3bbd10de"

all_rows, cursor, page = [], None, 0
while True:
    page += 1
    payload = {"page_size": 100}
    if cursor: payload["start_cursor"] = cursor
    with open("/tmp/q.json", "w") as f: json.dump(payload, f)
    r = subprocess.run(
        ["curl", "-s", "-X", "POST",
         f"https://api.notion.com/v1/data_sources/{DS}/query",
         "-H", f"Authorization: Bearer {NOTION}",
         "-H", "Notion-Version: 2025-09-03",
         "-H", "Content-Type: application/json",
         "-d", "@/tmp/q.json"],
        capture_output=True, text=True)
    data = json.loads(r.stdout)
    all_rows.extend(data.get("results", []))
    print(f"page {page}: +{len(data.get('results', []))} (total={len(all_rows)})")
    if not data.get("has_more"): break
    cursor = data.get("next_cursor")
    if not cursor: break

with open("/tmp/notion_all_rows.json", "w") as f:
    json.dump(all_rows, f, ensure_ascii=False)
print(f"FINAL: {len(all_rows)} rows")
```

**Expected throughput**: ~50 pages in <60s. If `has_more: true` but `next_cursor` is null, you're at the end — break.

### Phase 4 — Normalize accessor functions

Property payloads are deeply nested with type-specific shapes. Write helpers once:

```python
def get_text(rt):
    """rich_text/title arrays → plain string"""
    if not rt: return ""
    return "".join([x.get("plain_text","") for x in rt])

def parse(p):
    return {
        "title": get_text(p.get("Name", {}).get("title") or []),
        "lang": (p.get("Language", {}).get("select") or {}).get("name"),
        "url": p.get("URL", {}).get("url"),
        "stars": p.get("Stars", {}).get("number"),
        "date": (p.get("Date", {}).get("date") or {}).get("start"),
        "description": get_text(p.get("Description", {}).get("rich_text") or []),
        "uploaded": p.get("Uploaded", {}).get("checkbox", False),
    }
```

**Adapt to the actual schema you introspected** — don't copy-paste these field names.

### Phase 5 — Quality inspection + content analysis

Before recommending candidates, run a quality audit. **Empty critical fields are a signal, not a bug**:

```python
from collections import Counter
field_dist = Counter()
for x in parsed:
    field_dist[x["stars"]] += 1   # e.g. {0: 5065, 50000: 1} → 99.98% empty!
```

If a field is 99%+ empty, the upstream bot has a bug — **flag this to the user**, don't pretend it's a ranking signal.

Then run domain-specific analysis. For GitHub-style DBs (URL + description + language), the standard cuts:

```python
# 1. Language/section distribution
langs = Counter(x["lang"] for x in parsed if x["lang"])

# 2. Owner/repo parse from URL
from urllib.parse import urlparse
def owner_repo(url):
    try:
        p = urlparse(url).path.strip("/").split("/")
        if len(p) >= 2: return "/".join(p[:2])
    except: pass
    return None

# 3. Description keyword frequency (with stop words)
import re
desc = " ".join((x["description"] or "") for x in parsed).lower()
words = re.findall(r"[a-z][a-z\-]{3,}", desc)
STOP = set("the a an and or of to in for is on with at by from this that as it be are was were ...".split())
freq = Counter(w for w in words if w not in STOP)

# 4. Date range
dates = [x["date"] for x in parsed if x["date"]]
print("Range:", min(dates), "~", max(dates))
```

For "top N" outputs, **dedupe by repo URL** (the same trending repo can appear 5× over 5 days as re-trending):

```python
seen = set()
unique = []
for x in sorted(items, key=lambda x: -x["score"]):
    if x["repo"] not in seen:
        seen.add(x["repo"])
        unique.append(x)
```

**Always pick the most recent occurrence** per (repo, date) tuple — earlier entries may have stale descriptions.

## Pitfalls

- **Page ID vs Database ID confusion** — always try `/pages/{id}` first; if it 400s with "is a database", switch endpoints.
- **Stars field often 0** — GitHub Trending DBs frequently have a `Stars` number field that's never populated by the monitoring bot. Treat `null`/0 stars as "unknown", not "0 stars".
- **Duplicate rows over time** — same repo can appear 5–10 times as it re-trends. Always dedupe by URL before recommending.
- **Inline JSON in jq filter** — bash heredoc + `key: .value.type // .key` syntax breaks `jq` parsing. Write the filter to `/tmp/*.jq` first, then `jq -f /tmp/file.jq`.
- **Korean property names** — the bundled `notion` skill already flags this. Re-confirm schema before every write.
- **Data source ID vs database ID** — `data_sources[0].id` is for queries; `parent.database_id` is for creating pages. Mixing them returns 404.
- **Empty results misleading** — `data_sources/{id}/query` can return `[]` even when pages exist. Use `/search` for verification (see bundled `notion` skill).

## Verifying the analysis

Before reporting findings to the user:

1. **Sanity check the row count** vs DB size — if you fetched 5,066 and the page count is 5,066, all good.
2. **Spot-check 1–2 rows by URL** — open the page in Notion to confirm the parsed description matches.
3. **Verify date range** covers the expected period (e.g. "2026-04-11 ~ 2026-08-05" = 4 months, plausible).
4. **Compute coverage metrics** — `with_url:` / `total`, `with_description:` / `total`, etc.

## Worked example: `🔥 GitHub Trending` DB

| Field | Value |
|---|---|
| Page-as-DB ID | `33f76f2e-9097-8176-a537-d40ebb476ef9` |
| Data source ID | `33f76f2e-9097-811d-92e9-000b3bbd10de` |
| Parent database ID | (nested — for page creation) |
| Properties | Name (title), Date, UploadDate, Description, Language (select), Uploaded (checkbox), URL (url), Stars (number), TrendingTopic (select), Category (select) |
| Total rows | 5,066 |
| Date range | 2026-04-11 ~ 2026-08-05 |
| Stars populated | 1/5,066 (0.02%) — **bug in upstream bot** |
| Uploaded=true | 0/5,066 (0%) — **clear opportunity** |
| Language dist | Swift 1840, Python 1612, TypeScript 1395, Other 219 |

This pattern is reusable for any user-pasted Notion DB URL.

## Related

- Bundled `notion` skill — API surface (CRUD, page create, query basics)
- `github-trending-monitor` (automation) — writes to this kind of DB
- `periodic-data-pipeline` (automation) — generic "push to Notion DB" pattern
- `knowledge-graph` (automation) — consumes Notion DB rows to build graphs
