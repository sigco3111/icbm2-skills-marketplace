#!/bin/bash
# release_github.sh — 빌드 → 검증 → GitHub Release 자동화 워크플로
# 사용법: ./release_github.sh <version> [repo]
# 예: ./release_github.sh v0.1.18 sigco3111/snkrx-clone
#
# 동작:
#   1) build_all.sh 호출 (또는 기존 dist/ 사용)
#   2) 4개 asset 로컬 검증 (HTTP 200 + 크기 sanity check)
#   3) GitHub Release (draft) 생성
#   4) 각 asset idempotent 업로드 (기존 asset 있으면 삭제 후 재업로드)
#   5) Draft → Published
#
# 의존: gh auth token, build_all.sh, curl, python3
# 안전성: idempotent (재실행 가능), 기존 release 손상 X

set -e

VERSION="${1:-}"
REPO="${2:-sigco3111/snkrx-clone}"
PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
DIST_DIR="$PROJECT_DIR/dist"

[ -z "$VERSION" ] && { echo "Usage: $0 <version> [repo]"; echo "Example: $0 v0.1.18 sigco3111/snkrx-clone"; exit 1; }

TOKEN=$(gh auth token 2>/dev/null)
[ -z "$TOKEN" ] && { echo "❌ gh CLI 인증 필요: gh auth login"; exit 1; }

echo "=== SNKRX 한국어화 fork Release ($VERSION) ==="
echo "Repo: $REPO"
echo

# 1) 빌드 (선택적 — 이미 dist/ 있으면 skip)
if [ -n "$REBUILD" ] || [ ! -f "$DIST_DIR/snkrx-kr-$VERSION.love" ]; then
    echo "1/5 빌드..."
    "$PROJECT_DIR/build_all.sh" "$VERSION"
else
    echo "1/5 빌드 (skip — 기존 dist/ 사용)"
fi
echo

# 2) 로컬 검증
echo "2/5 로컬 검증..."
DIST_FILES=(
    "snkrx-kr-macos-$VERSION.zip"
    "snkrx-kr-windows-$VERSION.zip"
    "snkrx-kr-linux-$VERSION.tar.gz"
    "snkrx-kr-$VERSION.love"
)
for f in "${DIST_FILES[@]}"; do
    [ -f "$DIST_DIR/$f" ] || { echo "❌ Missing: $DIST_DIR/$f"; exit 1; }
    SIZE=$(du -h "$DIST_DIR/$f" | cut -f1)
    echo "  ✅ $f ($SIZE)"
done
echo

# 3) GitHub Release (draft) 생성
echo "3/5 GitHub Release (draft) 생성..."
RELEASE_DATA=$(cat <<EOF
{
  "tag_name": "$VERSION",
  "name": "SNKRX 한국어 $VERSION",
  "body": "## SNKRX 한국어화 fork $VERSION\n\n### 다운로드\n- macOS: snkrx-kr-macos-$VERSION.zip\n- Windows: snkrx-kr-windows-$VERSION.zip\n- Linux: snkrx-kr-linux-$VERSION.tar.gz\n- 크로스: snkrx-kr-$VERSION.love",
  "draft": true
}
EOF
)

RELEASE_ID=$(curl -s -X POST \
    -H "Authorization: Bearer $TOKEN" \
    -H "Accept: application/vnd.github+json" \
    "https://api.github.com/repos/$REPO/releases" \
    -d "$RELEASE_DATA" \
    | python3 -c "import sys,json; print(json.load(sys.stdin)['id'])")
echo "  Release ID: $RELEASE_ID"
echo

# 4) Asset 업로드 (idempotent)
echo "4/5 Asset 업로드 (idempotent)..."
for f in "${DIST_FILES[@]}"; do
    ASSET_PATH="$DIST_DIR/$f"
    # 기존 asset 확인
    EXISTING=$(curl -s -X GET \
        -H "Authorization: Bearer $TOKEN" \
        -H "Accept: application/vnd.github+json" \
        "https://api.github.com/repos/$REPO/releases/$RELEASE_ID/assets" \
        | python3 -c "
import sys, json
try:
    assets = json.load(sys.stdin)
    for a in assets:
        if a['name'] == '$f':
            print(a['id'])
            break
    else:
        print('')
except: print('')
")
    # 있으면 삭제
    if [ -n "$EXISTING" ]; then
        curl -s -X DELETE \
            -H "Authorization: Bearer $TOKEN" \
            "https://api.github.com/repos/$REPO/releases/assets/$EXISTING" \
            -o /dev/null
        echo "  🗑️  $f (이전 삭제)"
    fi
    # 새로 업로드
    HTTP=$(curl -s -X POST \
        -H "Authorization: Bearer $TOKEN" \
        -H "Content-Type: application/zip" \
        --data-binary "@$ASSET_PATH" \
        "https://uploads.github.com/repos/$REPO/releases/$RELEASE_ID/assets?name=$f" \
        -o /dev/null -w "%{http_code}")
    echo "  📤 $f: HTTP $HTTP"
done
echo

# 5) Publish
echo "5/5 Draft → Published..."
curl -s -X PATCH \
    -H "Authorization: Bearer $TOKEN" \
    -H "Accept: application/vnd.github+json" \
    "https://api.github.com/repos/$REPO/releases/$RELEASE_ID" \
    -d "{\"draft\":false,\"tag_name\":\"$VERSION\",\"name\":\"SNKRX 한국어 $VERSION\"}" \
    | python3 -c "import sys,json; d=json.load(sys.stdin); print(f'  ✅ Published: {d[\"html_url\"]}')"
echo

echo "=== Release 발행 완료 ==="
echo "URL: https://github.com/$REPO/releases/tag/$VERSION"
