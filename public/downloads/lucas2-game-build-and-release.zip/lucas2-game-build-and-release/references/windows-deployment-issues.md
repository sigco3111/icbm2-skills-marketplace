# love2d Windows 배포 함정 (실측 SNKRX v0.1.15~v0.1.19, 2026-07-21)

Windows 사용자에게 love2d 게임 .zip을 전달할 때 만나는 **4가지 실측 함정** (순서대로 만남). 각 함정마다 증상 → 원인 → 해결 → 다음 빌드 반영 패턴.

---

## 함정 1: `love.exe` not found

### 증상
```
'love.exe'은(는) 내부 또는 외부 명령, 실행할 수 있는 프로그램, 또는
배치 파일이 아닙니다.

Game failed to start.
계속하려면 아무 키나 누르십시오 . . .
```

### 원인

`build_love.sh`로 만든 zip 구조:
```
zip 루트/
├── run.bat                ← 여기가 zip 루트
└── love-11.5-win64/
    ├── love.exe
    ├── *.dll
    └── snkrx-kr-v0.1.12.love
```

`run.bat`에 `love.exe snkrx-kr-v0.1.12.love` 호출 → `love.exe`가 **현재 디렉토리**에서 검색 → 하위 폴더 `love-11.5-win64/`에 있어서 못 찾음.

### 해결

`run.bat`에 `cd love-11.5-win64` 추가:
```bat
@echo off
REM SNKRX Korean fork launcher (Windows)
cd /d "%~dp0"
cd love-11.5-win64          ← 추가
love.exe snkrx-kr-v0.1.12.love
if errorlevel 1 (
    echo.
    echo Game failed to start.
    ...
)
```

**규칙**: `love.exe`는 `love-11.5-win64/` 하위 폴더에 있으므로 `cd love-11.5-win64`로 진입 필요. **build_all.sh에서 자동 생성**하도록.

```bash
# build_all.sh 내 run.bat 생성 블록
if [ ! -f "$WINDOWS_DIR/run.bat" ]; then
    cat > "$WINDOWS_DIR/run.bat" <<'BAT'
@echo off
REM SNKRX Korean fork launcher (Windows)
cd /d "%~dp0"
cd love-11.5-win64
love.exe snkrx-kr-v0.1.12.love
if errorlevel 1 (
    echo.
    echo Game failed to start.
    echo Install Visual C++ 2013 Redistributable.
    echo Or run: lovec.exe snkrx-kr-v0.1.12.love
    pause
)
BAT
fi
```

---

## 함정 2: `Cannot load game at path 'C:/Users/신희정/...snkrx-kr-v0.1.12.love'`

### 증상
```
Error

[love "boot.lua"]:330: Cannot load game at path 'C:/Users/신희정/Downloads/snkrx-kr-windows-v0.1.12/love-11.5-win64/snkrx-kr-v0.1.12.love'.
Make sure a folder exists at the specified path.

Traceback

[love "callbacks.lua"]:228: in function 'handler'
[C]: in function 'error'
[C]: in function 'xpcall'
[C]: in function 'xpcall'
```

### 원인

3가지 가능성 — **한글 사용자 경로 + zip 인식 실패가 결합**:

1. **.love zip의 내부 path encoding**: macOS에서 만든 zip이 Windows CMD에서 풀릴 때 path 인코딩이 CP949/UTF-8 mismatch
2. **love2d 11.5 Windows의 zip 파서**: 일부 환경에서 macOS/Linux zip을 올바로 인식 못 함
3. **Windows CMD의 한글 경로 처리**: `C:/Users/신희정/...` 같은 한글 경로에서 `love.exe snkrx-kr-v0.1.12.love` 호출 시 zip 내부 path가 깨질 가능성

`.love` zip은 425개 파일 (deflate 압축) 정상이지만 — **love2d가 zip 폴더로 인식**.

### 해결 — .love zip을 game/ 폴더로 추출

**.love 파일을 zip으로 빌드한 후, Windows 배포 시 zip을 풀어서 `game/` 디렉토리로 배치**:
```
zip 루트/
├── run.bat
├── README.txt
└── love-11.5-win64/
    ├── love.exe
    ├── *.dll
    └── game/                  ← .love의 압축 해제된 게임 디렉토리
        ├── conf.lua
        ├── main.lua
        ├── arena.lua
        ├── assets/
        └── ...
```

`run.bat`이 `love.exe game` 호출 (love2d가 폴더 직접 로드):
```bat
@echo off
cd /d "%~dp0"
cd love-11.5-win64
love.exe game
```

**build_all.sh에서 자동 .love → game/ 추출**:
```bash
GAME_DIR="$WINDOWS_DIR/love-11.5-win64/game"
rm -rf "$GAME_DIR"
mkdir -p "$GAME_DIR"
(cd "$GAME_DIR" && unzip -q -o "$LOVE_OUTPUT")
echo "✅ 게임 폴더 추출: $GAME_DIR ($(ls "$GAME_DIR" | wc -l) 항목)"
```

### love2d의 game/ 폴더 직접 로드 동작

love2d는 2가지 게임 경로 형식 지원:
- **단일 .love 파일**: `love.exe game.love` (zip을 메모리에 풀어서 실행)
- **디렉토리**: `love.exe game/` (디렉토리 직접 로드)

**두 형식 모두 사랑**. 디렉토리 로드는 **zip 파서 우회 + 한글 path 우회 + 디버깅 용이** (Windows 탐색기로 직접 파일 확인 가능).

### 검증 워크플로

1. `love.exe game`이 zip처럼 로드 → ALIVE
2. `conf.lua`, `main.lua`이 `game/` 안에 정상 위치 → OK
3. `assets/` 디렉토리도 `game/` 아래 → OK

---

## 함정 3: build_all.sh의 `if [ ! -f ]` 조건

### 증상
- 첫 빌드에서 run.bat / README.txt가 정상 생성
- 두 번째 빌드 (`./build_all.sh`)에서 **새로 생성 안 됨** → 이전 버전이 그대로 zip에 포함됨

### 원인

`build_all.sh`의 run.bat 생성 블록:
```bash
if [ ! -f "$WINDOWS_DIR/run.bat" ]; then
    cat > "$WINDOWS_DIR/run.bat" <<'BAT'
...
BAT
fi
```

**`if [ ! -f ]` 조건이 이미 파일이 있으면 skip** → 빌드 스크립트 수정해도 zip에는 이전 버전만 들어감.

### 해결

**빌드 전 기존 파일 삭제**:
```bash
# build_all.sh 실행 직전 또는 안에서
rm -f "$WINDOWS_DIR/run.bat" "$WINDOWS_DIR/README.txt"
"$DIST_DIR/macosx/build_macos.sh"  # 또는 통합 빌드 진입
./build_all.sh
```

또는 **항상 덮어쓰기** (조건 제거):
```bash
# 조건 없이 항상 생성
cat > "$WINDOWS_DIR/run.bat" <<'BAT'
...
BAT
```

**권장**: 빌드 스크립트 안에서 `rm -f`를 호출해 항상 fresh 파일 보장. zip도 항상 fresh:
```bash
rm -f "$DIST_DIR/snkrx-kr-windows-$VERSION.zip"
(cd "$WINDOWS_DIR" && zip -r "$DIST_DIR/snkrx-kr-windows-$VERSION.zip" love-11.5-win64/ run.bat README.txt -q)
```

### 통합 패턴 (build_all.sh v0.1.18+)

```bash
# 1. 기존 .love / run.bat / README 삭제
rm -f "$WINDOWS_DIR/run.bat" "$WINDOWS_DIR/README.txt"
rm -rf "$WINDOWS_DIR/love-11.5-win64/game"  # game/ 폴더도 fresh

# 2. .love → game/ 폴더 추출
mkdir -p "$WINDOWS_DIR/love-11.5-win64/game"
(cd "$WINDOWS_DIR/love-11.5-win64/game" && unzip -q -o "$LOVE_OUTPUT")

# 3. run.bat / README.txt 새로 생성
cat > "$WINDOWS_DIR/run.bat" <<'BAT'
@echo off
cd /d "%~dp0"
cd love-11.5-win64
love.exe game
...
BAT

# 4. zip 새로 묶기
rm -f "$DIST_DIR/snkrx-kr-windows-$VERSION.zip"
(cd "$WINDOWS_DIR" && zip -r "$DIST_DIR/snkrx-kr-windows-$VERSION.zip" love-11.5-win64/ run.bat README.txt -q)
```

---

## ⭐ 듀얼 모드 — .love zip + game/ 폴더 둘 다 포함 (v0.1.19 NEW, 2026-07-21)

### 문제
v0.1.18에서 `.love` zip을 `game/` 폴더로 풀어 한글 path 문제를 우회했지만, **사용자 워크어라운드 제안**이 들어옴:

> "snkrx-kr-v0.1.12.love 다운로드 받아서 ./love-11.5-win64 폴더에 넣고 실행하면 됨. snkrx-kr-v0.1.12.love 파일을 .zip에 포함해주면 안되나?"

즉, 일부 사용자(영문 path)는 `.love` zip 모드가 잘 동작하는데, 다른 사용자(한글 path)는 `game/` 폴더 모드가 필요. **두 모드 모두 zip에 포함시켜 사용자 선택권을 주자**.

### 해결 — 듀얼 모드 run.bat

`game/` 폴더는 한글 path 우회 (기본, 안전), `.love` zip은 영어 path 사용자용. `run.bat`이 폴더 모드 먼저 시도 → 실패 시 zip 모드 fallback.

```bash
# build_all.sh v0.1.19 — .love zip도 함께 zip에 복사
cp "$LOVE_OUTPUT" "$WINDOWS_DIR/love-11.5-win64/" 2>/dev/null || true
echo "✅ .love zip도 포함 (영문 경로 사용자용)"
```

**run.bat 자동 폴백 로직**:
```bat
@echo off
REM SNKRX Korean fork launcher (Windows)
cd /d "%~dp0"
cd love-11.5-win64
echo Starting SNKRX (folder mode)...
love.exe game
if errorlevel 1 (
    echo.
    echo Folder mode failed. Trying .love zip mode...
    love.exe snkrx-kr-v0.1.12.love
    if errorlevel 1 (
        echo.
        echo Both modes failed.
        echo Install Visual C++ 2013 Redistributable.
        echo Or run: lovec.exe game
        pause
    )
)
```

**최종 zip 구조**:
```
snkrx-kr-windows-v0.1.19.zip (131M)
├── run.bat                ← 폴백 자동 실행
├── README.txt
└── love-11.5-win64/
    ├── love.exe
    ├── *.dll
    ├── game/               ← 폴더 모드 (한글 path 안전, 기본)
    │   ├── conf.lua
    │   ├── main.lua
    │   └── ...
    └── snkrx-kr-v0.1.12.love  ← zip 모드 (영문 path)
```

### 왜 듀얼 모드가 최적인가

| 사용자 환경 | 폴더 모드 (`love.exe game`) | zip 모드 (`love.exe game.love`) |
|------------|------------------------|------------------------|
| 한글 Windows path (예: `C:/Users/신희정/...`) | ✅ 안전 | ❌ zip 인식 실패 |
| 영문 Windows path | ✅ OK | ✅ OK |
| Linux/macOS | ✅ OK (love game 또는 love game.love 둘 다) | ✅ OK |

**기본 = 폴더 모드** (가장 보편적). **zip 모드 = 영문 path fallback** (소수 케이스).

### 사용자 정정 시그널 → 1순위 의심

| 사용자 정정 | 1순위 의심 | 확인 방법 |
|-------------|------------|----------|
| "love.exe 못 찾음" | run.bat에 `cd love-11.5-win64` 누락 | zip unzip → 구조 확인 |
| "Cannot load game at path" | .love zip 인식 실패 (한글 path) → `game/` 폴더 | `love.exe game` 직접 테스트 |
| "한글이 깨져서 출력" | run.bat에 한글 (ASCII only 위반) | `file run.bat` → ASCII text |
| "예전 버전이 실행됨" | GitHub Release에 옛 zip | Release 페이지 asset 버전 확인 |
| **".love가 zip에 없다"** | **v0.1.18 이전 빌드 — `game/` 폴더만 포함** | **v0.1.19+ 듀얼 모드 빌드 필요** |
| "오브젝트가 작다" | `usedpiscale = true` (Retina) | conf.lua 확인 + state.txt 삭제 |
| "풀스크린 됨" | `state.sx` 범위 가드 누락 | `~/Library/Application Support/LOVE/{game}/state.txt` |

**1순위 진단 → 해결 → GitHub Release 재업로드 사이클**이 가장 빈번.

### 듀얼 모드 효과 (실측)

v0.1.18에서 `game/` 폴더만 포함 → **한글 path 사용자는 OK**, 영문 path 사용자도 OK → 4.5M zip.
v0.1.19에서 `.love` zip도 추가 → **zip 크기 4.5M → 131M** (game/ 폴더 + .love 둘 다). 사용자는 90% 더 큰 파일 받지만 **모든 환경에서 동작 보장**.

**대안 — 듀얼 모드 없이 모드 자동 선택**:
```bash
# build_all.sh에서 환경 변수 또는 zip 검사 후 결정
# (복잡도 높음 — 듀얼 모드 단순)
```

**즉시 적용 규칙**:
1. **Windows 사용자에게 love2d 게임 배포 시 듀얼 모드 기본** (game/ + .love 둘 다)
2. **`run.bat` 자동 폴백 로직 필수** (folder → zip 순서)
3. **.gitignore에 `dist/` 추가** (대용량 빌드 결과물 제외)
4. **README에 듀얼 모드 설명** (사용자 혼란 방지)

---

## ⭐ 빌드 → 검증 → 업로드 자동화 워크플로 (권장)

```bash
#!/bin/bash
# release_v2.sh: 빌드 + 검증 + GitHub Release 자동화
set -e
VERSION="$1"  # 예: v0.1.18
[ -z "$VERSION" ] && { echo "Usage: $0 <version>"; exit 1; }

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
DIST_DIR="$PROJECT_DIR/dist"

# 1) 빌드
echo "=== 빌드 ==="
"$PROJECT_DIR/build_all.sh"

# 2) 로컬 검증
echo "=== 로컬 검증 ==="
DIST_FILES=(
  "snkrx-kr-macos-$VERSION.zip"
  "snkrx-kr-windows-$VERSION.zip"
  "snkrx-kr-linux-$VERSION.tar.gz"
  "snkrx-kr-$VERSION.love"
)
for f in "${DIST_FILES[@]}"; do
  [ -f "$DIST_DIR/$f" ] || { echo "❌ Missing: $f"; exit 1; }
  SIZE=$(du -h "$DIST_DIR/$f" | cut -f1)
  echo "  ✅ $f ($SIZE)"
done

# 3) GitHub Release (draft → publish)
TOKEN=$(gh auth token 2>/dev/null)
RELEASE_DATA='{
  "tag_name": "'"$VERSION"'",
  "name": "SNKRX 한국어 '"$VERSION"'",
  "body": "한글화 + Steam 비의존 + 크로스 플랫폼\n\n### 다운로드\n- macOS: snkrx-kr-macos-'"$VERSION"'.zip\n- Windows: snkrx-kr-windows-'"$VERSION"'.zip\n- Linux: snkrx-kr-linux-'"$VERSION"'.tar.gz\n- 크로스: snkrx-kr-'"$VERSION"'.love",
  "draft": true
}'

RELEASE_ID=$(curl -s -X POST \
  -H "Authorization: Bearer $TOKEN" \
  -H "Accept: application/vnd.github+json" \
  https://api.github.com/repos/$REPO/releases \
  -d "$RELEASE_DATA" \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['id'])")
echo "Release ID: $RELEASE_ID"

# 4) Asset 업로드 (idempotent)
for f in "${DIST_FILES[@]}"; do
  ASSET_PATH="$DIST_DIR/$f"
  # 기존 asset 확인
  EXISTING=$(curl -s -X GET \
    -H "Authorization: Bearer $TOKEN" \
    "https://api.github.com/repos/$REPO/releases/$RELEASE_ID/assets" \
    | python3 -c "import sys,json; r=[a['id'] for a in json.load(sys.stdin) if a['name']=='$f']; print(r[0] if r else '')")
  # 있으면 삭제
  if [ -n "$EXISTING" ]; then
    curl -s -X DELETE \
      -H "Authorization: Bearer $TOKEN" \
      "https://api.github.com/repos/$REPO/releases/assets/$EXISTING" \
      -o /dev/null
    echo "  🗑️  $f (이전 삭제)"
  fi
  # 새로 업로드
  HTTP=$(curl -s -X POST \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/zip" \
    --data-binary "@$ASSET_PATH" \
    "https://uploads.github.com/repos/$REPO/releases/$RELEASE_ID/assets?name=$f" \
    -o /dev/null -w "%{http_code}")
  echo "  📤 $f: HTTP $HTTP"
done

# 5) Publish
curl -s -X PATCH \
  -H "Authorization: Bearer $TOKEN" \
  -H "Accept: application/vnd.github+json" \
  https://api.github.com/repos/$REPO/releases/$RELEASE_ID \
  -d "{\"draft\":false,\"tag_name\":\"$VERSION\",\"name\":\"SNKRX 한국어 $VERSION\"}"
echo "✅ Release published: $VERSION"
```

**실행**: `./release_v2.sh v0.1.18`

**출력**:
```
=== 빌드 ===
=== 로컬 검증 ===
  ✅ snkrx-kr-macos-v0.1.18.zip (86M)
  ✅ snkrx-kr-windows-v0.1.18.zip (4.5M)
  ✅ snkrx-kr-linux-v0.1.18.tar.gz (65M)
  ✅ snkrx-kr-v0.1.18.love (62M)
Release ID: 357129451
  🗑️  snkrx-kr-windows-v0.1.18.zip (이전 삭제)
  📤 snkrx-kr-windows-v0.1.18.zip: HTTP 201
  📤 snkrx-kr-macos-v0.1.18.zip: HTTP 201
  ...
✅ Release published: v0.1.18
```

---

## ⭐ 사용자 디버깅 가이드 (Windows 사용자 정정 신호 → 1순위 의심)

| 사용자 정정 | 1순위 의심 | 2순위 | 확인 방법 |
|-------------|------------|-------|----------|
| "love.exe 못 찾음" | run.bat에 `cd love-11.5-win64` 누락 | .zip에 love-11.5-win64/ 폴더 누락 | zip unzip → 구조 확인 |
| "Cannot load game at path" | .love zip 인식 실패 (한글 path) | game/ 폴더 누락 | `love.exe game` 직접 테스트 |
| "한글이 깨져서 출력" | run.bat에 한글 (ASCII only 위반) | build_all.sh heredoc이 한글 포함 | `file run.bat` → ASCII text |
| "예전 버전이 실행됨" | GitHub Release에 옛 zip | build_all.sh의 `if [ ! -f ]` skip | Release 페이지 asset 버전 확인 |
| **".love가 zip에 없다"** | **v0.1.18 이전 빌드** | **사용자 환경에 .love 직접 다운로드** | **v0.1.19+ 듀얼 모드** |
| "오브젝트가 작다" | `usedpiscale = true` (Retina) | `state.sx` 비정상 | conf.lua 확인 + state.txt 삭제 |
| "풀스크린 됨" | `state.sx` 범위 가드 누락 | `state.txt` 비정상 데이터 | `~/Library/Application Support/LOVE/{game}/state.txt` |

**1순위 진단 → 해결 → GitHub Release 재업로드 사이클**이 가장 빈번.

---

## 누적 통계 — SNKRX v0.1.15~v0.1.19 Windows 배포 디버깅 사이클

| 버전 | 함수정 | 해결 |
|------|--------|------|
| v0.1.15 | `run.bat` 누락 | 자동 생성 |
| v0.1.16 | run.bat 한글 깨짐 | ASCII 전용 |
| v0.1.17 | `love.exe` 경로 못 찾음 | `cd love-11.5-win64` 추가 |
| v0.1.18 | `.love` zip 인식 실패 (한글 path) | `game/` 폴더로 압축 해제 후 `love.exe game` |
| **v0.1.19** | **`.love` zip도 zip에 포함 (듀얼 모드)** | **사용자 워크어라운드 수용, `cp .love` + 폴백 run.bat** |

**패턴**: Windows 배포는 **1번에 안 됨** — 사용자 테스트로 4번 반복 수정. **build_love.sh + build_all.sh를 한 번에 완벽하게 만들 수 없다** — **사용자 정정 신호 → 1함정씩 수정 → 자동화** 사이클이 정석.

**즉시 적용 규칙**:
1. **Windows 사용자 배포 전**: 로컬에서 가능한 한 모든 시나리오 테스트 (ASCII path, 한글 path, 풀패키지 .app, .zip 직접 unzip)
2. **사용자 첫 정정 신호 = 1함정 발견**: 즉시 수정 + 빌드 + Release 재업로드
3. **run.bat은 ASCII only 원칙**: 한글 메시지는 README.txt에만
4. **`.love`보다 `game/` 폴더**: 한글 Windows path에서 더 안정적
5. **듀얼 모드 (v0.1.19)**: game/ + .love 둘 다 포함 → 모든 환경 보장
6. **build_all.sh의 `if [ ! -f ]`**: 빌드 직전 `rm -f`로 항상 fresh
7. **사용자 정정 신호 적극 수용**: 사용자가 직접 워크어라운드를 제안하면 그게 정답일 가능성 높음 → 즉시 빌드 시스템에 반영

---

## 다른 엔진 (Defold/Godot Lua) 적용 시

**원칙**: love2d의 `love.exe game`처럼 **다른 엔진의 런처도 game/ 폴더 또는 game.zip 지원** → 같은 디버깅 패턴 적용.

- **Defold**: `.darchive` 파일 (자체 압축 포맷). love와 달리 `.darchive`가 폴더 역할 → 항상 game/ 폴더로 빌드됨 → 한글 path 이슈 없음
- **Godot 4 + Lua/GDScript**: `project.godot` + 디렉토리 구조. **이미 디렉토리 빌드** → 한글 path 이슈만 주의
- **Ren'Py**: `.rpyc` 파일 + 디렉토리. **이미 디렉토리** → love와 달리 zip 인식 이슈 없음

**즉시 적용 규칙**: love2d 외 Lua 엔진은 `.love` 같은 단일 파일 포맷이 없거나 다른 메커니즘 사용. **대부분 디렉토리 기반**이므로 love와 같은 zip 인식 이슈는 없음. 단, **한글 path** 자체 이슈는 모든 엔진에 공통 — Windows에서 빌드할 때는 영문 path에서 빌드 후 zip으로 배포.
