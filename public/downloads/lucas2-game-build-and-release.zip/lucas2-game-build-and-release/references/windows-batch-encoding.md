# Windows .bat 파일 인코딩 함정 (3번째 만남)

SNKRX 한글화 fork v0.1.15 (2026-07-21)에서 **3번째로 만난 인코딩 함정**. 가장 빈번한 빌드 함정 중 하나.

## 증상

Windows에서 `run.bat` 더블클릭 시:
```
'k'은(는) 내부 또는 외부 명령, 실행할 수 있는 프로그램, 또는
배치 파일이 아닙니다.
'0"'은(는) 내부 또는 외부 명령, 실행할 수 있는 프로그램, 또는
배치 파일이 아닙니다.
'krx-kr-v0.1.12.love'은(는) 내부 또는 외부 명령, 실행할 수 있는 프로그램, 또는
배치 파일이 아닙니다.
'el'은(는) 내부 또는 외부 명령, 실행할 수 있는 프로그램, 또는
배치 파일이 아닙니다.
'뚯엫'은(는) 내부 또는 외부 명령, 실행할 수 있는 프로그램, 또는
배치 파일이 아닙니다.
계속하려면 아무 키나 누르십시오 . . .
```

## 원인

1. macOS/리눅스의 텍스트 에디터는 기본 **UTF-8 (no BOM)**으로 저장
2. `run.bat`에 한글 주석/메시지 포함 (예: `REM 게임 실행`)
3. Windows CMD는 기본 코드페이지 **949 (한국어)** 또는 **437 (영문)**
4. UTF-8 → CP949 변환 시도, BOM 없어서 잘못된 위치에서 변환
5. 멀티바이트 깨짐 → `'k'`, `'0"'`, `'el'` 같은 ASCII 단편이 별도 명령으로 실행

## 해결

### ❌ 잘못된 방법 1: `chcp 65001` (UTF-8로 변경)
```bat
@echo off
chcp 65001 > nul
REM 게임 실행
cd /d "%~dp0"
love.exe snkrx-kr-v0.1.12.love
```
**문제**: Windows 10 이전 버전에서 한글 출력 시 깨짐. 일부 시스템에서 `chcp` 명령이 인식 안 됨.

### ❌ 잘못된 방법 2: BOM 추가
```python
# Python
with open('run.bat', 'wb') as f:
    f.write(b'\xef\xbb\xbf')  # UTF-8 BOM
    f.write(content.encode('utf-8'))
```
**문제**: 일부 Windows 버전에서 BOM을 잘못 인식. CMD에서 `?` 같은 문자 보임. 100% 호환성 X.

### ✅ 올바른 방법: **순수 ASCII만 사용**

```bat
@echo off
REM SNKRX Korean fork launcher (Windows)
cd /d "%~dp0"
love.exe snkrx-kr-v0.1.12.love
if errorlevel 1 (
    echo.
    echo Game failed to start.
    echo Install Visual C++ 2013 Redistributable.
    echo Or run: lovec.exe snkrx-kr-v0.1.12.love
    pause
)
```

**규칙**: 
- `REM` (주석) 영어만
- `echo` 메시지 영어만
- `if errorlevel 1` (시스템 명령)
- **사용자-facing 텍스트는 영어**

### 파일 인코딩 가이드 (3종류 파일)

| 파일 | 인코딩 | 한글 가능? | 이유 |
|------|--------|------------|------|
| `run.bat` | **ASCII only** | ❌ | CMD 직접 실행 |
| `README.txt` | UTF-8 OK | ✅ | 메모장에서 열면 자동 디코딩 |
| `Info.plist` (macOS) | UTF-8 OK | ✅ | macOS Finder는 UTF-8 BOM 자동 인식 |
| `AppRun` (Linux AppImage) | ASCII only | ❌ | 일부 환경 locale 없음 |

### Bash heredoc으로 run.bat 생성 (macOS/Linux 빌드 환경)

```bash
# v0.1.15 fix: 순수 ASCII 명령만 사용
cat > "$WINDOWS_DIR/run.bat" <<'BAT'
@echo off
REM SNKRX Korean fork launcher (Windows)
cd /d "%~dp0"
love.exe snkrx-kr-v0.1.12.love
if errorlevel 1 (
    echo.
    echo Game failed to start.
    echo Install Visual C++ 2013 Redistributable.
    echo Or run: lovec.exe snkrx-kr-v0.1.12.love
    pause
)
BAT
```

## 디버그: 인코딩 확인

macOS/Linux에서:
```bash
# 파일 BOM 확인
xxd run.bat | head -1
# 결과: efbbbf... → UTF-8 BOM 있음 (❌ 일부 시스템에서 문제)
# 결과: 40echo ... → BOM 없음, ASCII only (✅)

# 파일 인코딩 추측
file run.bat
# 결과: run.bat: ASCII text (✅)
# 결과: run.bat: UTF-8 Unicode text (⚠️ 한글 있을 때만 OK)
```

Windows CMD에서:
```cmd
chcp  # 현재 코드페이지 확인 (보통 949 또는 437)
type run.bat  # 파일 내용 보기
```

## 3번째 만남 회고

1. **첫 만남 (v0.1.7)**: 클래스 모듈 import 시 한글 깨짐
   - `passive_descriptions_level_ko.lua`의 `local`이 init에서 모듈 require 시점에 평가 안 됨
   - 해결: `local ylb1/2/3` 자체 정의

2. **두 번째 만남 (v0.1.10)**: 패시브 설명 모듈에서 `ts` 함수 nil
   - 같은 패턴, `local ts` 자체 정의

3. **세 번째 만남 (v0.1.15)**: Windows .bat 실행 시 한글 깨짐
   - **가장 빈번한 빌드 함정** 중 하나
   - 해결: .bat은 순수 ASCII, README.txt만 한글

**교훈**: **Windows CMD 환경에서 실행되는 모든 스크립트는 ASCII only 원칙**.

## macOS .app Info.plist는 한글 OK

```xml
<key>CFBundleName</key>
<string>SNKRX 한국어</string>
<key>CFBundleDisplayName</key>
<string>SNKRX 한국어</string>
```

- macOS는 XML parser가 UTF-8 BOM 자동 인식
- Finder 표시명 한글 OK
- 단, `Contents/MacOS/love` 실행 파일명은 영문 유지 (시스템 호출)
