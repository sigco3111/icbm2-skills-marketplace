# Lua/love2d 게임 개발 함정 모음

이 문서는 love2d (LÖVE) 게임 개발 중 자주 만나는 Lua 함정과 해결법을 다룹니다. SNKRX 한국어화 fork v0.1 (2026-07-21) 빌드 과정에서 3번 만남.

## 1. 콜백 함수 인자 안에 `local` 선언 불가

### 증상
```
unexpected symbol near 'local'
```
stack trace가 buy_screen.lua 또는 text.lua에서 `:activate` 또는 `:draw` 콜백을 가리킴.

### 잘못된 코드
```lua
function CharacterIcon:on_mouse_enter()
  self.info_text:activate({
    local char_name = T('char_' .. self.character)  -- ❌ 에러
    {text = char_name, ...},
  })
end
```

### 원인
Lua의 함수 인자는 **expression**만 가능. `local` 선언문은 statement라서 인자 위치에 못 옴.

### 올바른 코드
```lua
function CharacterIcon:on_mouse_enter()
  -- v0.1.7 fix: local은 :activate({ 밖에서 선언
  local char_name = T('char_' .. self.character, self.character)
  if lang.current == 'en' then char_name = self.character:capitalize() end
  local desc_func = (lang.current == 'ko' and lang.character_descriptions_ko and lang.character_descriptions_ko[self.character]) or character_descriptions[self.character]

  self.info_text = InfoText{group = main.current.ui}
  self.info_text:activate({
    {text = char_name, ...},  -- 이제 변수만 사용
  })
end
```

### 영향받는 love2d API
- `InfoText:activate({...})`
- `Button:init({...})`
- `Text({...})`
- 모든 콜백/생성자 인자

### 3번 만남 회고
SNKRX 한글화 중 같은 함정 **3번 반복**:
1. v0.1.4 — `TournamentCharacterPart:on_mouse_enter` (첫 만남)
2. v0.1.7 — `LevelButton:create_info_text` (인식 후 즉시 수정)
3. v0.1.7 — `TutorialClassIcon:on_mouse_enter` (패턴 학습 적용)

**교훈**: ko.lua 모듈 분리할 때 콜백 수정 시 항상 인자 안의 `local` 체크.

## 2. main.lua의 `local` 함수를 다른 모듈에서 사용 시

### 증상
```
attempt to call global 'ylb1' (a nil value)
```
또는
```
attempt to call global 'ts' (a nil value)
```

### 원인
SNKRX의 main.lua 내부에서:
```lua
function init()  -- main.lua 안의 init 함수
  ...
  local ylb1 = function(lvl) ... end
  local ylb2 = function(lvl) ... end
  local ylb3 = function(lvl) ... end
  local ts = function(lvl, a, b, c) return '[' .. ylb1(lvl) .. ']' .. ... end
  ...
  character_descriptions = {  -- 이 테이블이 ylb1/2/3, ts 사용
    ['ranger'] = function(lvl) return ts(lvl, ...) .. ' AoE damage' end,
    ...
  }
end
```
이 `ylb1/2/3`, `ts`는 **local**이라서 `_G`에 노출 안 됨. ko.lua 모듈이 require될 때는 접근 불가.

### 해결
ko.lua 모듈 자체에 정의 복제:
```lua
-- lang/class_descriptions_ko.lua 헤더
local ylb1 = function(lvl)
  if lvl == 3 then return 'light_bg'
  elseif lvl == 2 then return 'light_bg'
  elseif lvl == 1 then return 'yellow'
  else return 'light_bg' end
end
local ylb2 = function(lvl) ... end
local ylb3 = function(lvl) ... end
local ts = function(lvl, a, b, c)
  return '[' .. ylb1(lvl) .. ']' .. tostring(a) .. '[light_bg]/[' .. ylb2(lvl) .. ']' .. tostring(b) .. '[light_bg]/[' .. ylb3(lvl) .. ']' .. tostring(c) .. '[fg]'
end

return {
  ['ranger'] = function(lvl) return ts(lvl, '+3%', '5%', '7%') .. ' AoE damage' end,
  ...
}
```

### 같은 패턴의 다른 모듈
- `lang/passive_descriptions_level_ko.lua` (ts 사용)
- `lang/character_descriptions_ko.lua` (get_character_stat는 글로벌이라 OK)

### 진단 방법
에러 발생 시:
1. `error: attempt to call global '<name>' (a nil value)`
2. main.lua grep `local <name> =` → 함수 정의 위치 확인
3. ko.lua에 같은 정의 복제

## 3. Lua truthy 함정 (0도 truthy)

### 증상
```
attempt to get length of local 'text' (a nil value)
```
또는
```
attempt to get length of local 'text' (a number value)
```

### 잘못된 코드
```lua
function Font:has_cjk(text)
  if not text then return false end  -- ❌ 0도 truthy
  for i = 1, #text do  -- text가 숫자면 #text는 에러
    ...
  end
end
```

### 원인
Lua에서 **`0`은 truthy** (false/nil만 falsy). `if not text then` 가드는 nil만 잡고 0은 통과.

또한 `self.parent.cost` 같은 숫자 전달 시 `text`가 nil이 아니라 number로 들어옴.

### 올바른 코드
```lua
function Font:has_cjk(text)
  if text == nil then return false end
  if type(text) ~= "string" then return false end  -- type 가드
  for i = 1, #text do
    local b = text:byte(i)
    if b >= 0xE0 then return true end
  end
  return false
end
```

### 영향받은 곳
- `Font:has_cjk` (buy_screen.lua:1750의 `self.parent.cost`가 number)
- `Font:get_text_width` (같은 패턴)

## 4. `font.font` 직접 접근 회피

### 증상
CJK 폰트가 적용 안 됨. 한글 깨짐.

### 잘못된 코드
```lua
-- engine/graphics/graphics.lua
function graphics.print(text, font, ...)
  love.graphics.print(text, font.font, ...)  -- ❌ 항상 primary font
end
```

### 원인
`font.font`는 primary font (예: FatPixelFont)인데 한글 glyph가 없음.

### 올바른 코드
```lua
function graphics.print(text, font, ...)
  local _r, g, b, a = love.graphics.getColor()
  if color then love.graphics.setColor(...) end
  local active_font
  if font.get_font_for_text then
    active_font = font:get_font_for_text(text)  -- CJK면 ko_font 반환
  else
    active_font = font.font
  end
  love.graphics.print(text, active_font, ...)
  if color then love.graphics.setColor(_r, g, b, a) end
end
```

## 5. `string.method and x.method() or x.field` 패턴 함정

### 증상
`luac -p` (5.5) 거부. `Lua 5.1` 호환이지만 5.5 문법 검증에서 fail.

### 잘못된 코드
```lua
local cfg = (window_width ~= 'max' and window_width ~= 'half') and window_width or 'fallback'
```

### 올바른 코드
```lua
local cfg
if window_width ~= 'max' and window_width ~= 'half' then
  cfg = window_width
else
  cfg = 'fallback'
end
```

### 영향받은 곳
`engine/init.lua`의 `if [ -n ... and ... ]` 와 비슷한 단락평가 패턴.

## 6. UTF-8 character 단위 반복

### 증상
`getWidth(한글 1글자)` → `UTF-8 decoding error: Not enough space`

### 원인
love2d `Font:getWidth`는 UTF-8로 인코딩된 byte sequence를 받는데, byte 단위 반복 시 한 글자가 3 byte로 쪼개져서 전달됨.

### 해결
text.lua의 `Text:parse` 함수:
```lua
-- v0.1 fix: UTF-8 character 단위 반복 (바이트 단위가 아님)
local i = 1
while i <= #line.text do
  local b = line.text:byte(i)
  local cont = 1
  if b >= 0xF0 then cont = 4      -- 4-byte (emoji, CJK Extension B)
  elseif b >= 0xE0 then cont = 3  -- 3-byte (한글, CJK, 일본어)
  elseif b >= 0xC0 then cont = 2  -- 2-byte (Latin extended)
  end
  local c = line.text:sub(i, i + cont - 1)
  table.insert(line.characters, {character = c, visible = true, ...})
  i = i + cont
end
```

### 진단
- `getWidth(single_byte)` → OK
- `getWidth(korean_char)` → "Not enough space" 에러
- `getWidth(korean_char_3bytes)` → 각 byte마다 호출 시 같은 에러

## 7. love2d의 모듈 순환 import

### 증상
ko.lua에서 main.lua의 table을 참조해야 하는데 import 시점에는 main.lua가 아직 로드 안 됨.

### 해결
ko.lua는 main.lua의 local이 아닌 **global** 함수만 사용. `get_character_stat`은 main.lua에서 `function get_character_stat` (local 없음)으로 정의되어 global → OK.

`ylb1/2/3`, `ts`는 main.lua init() 함수 **내부**에서 local로 정의 → NG. 위 #2 참조.

## 8. CJK 폰트 lazy loading

### 패턴
```lua
function Font:_ensure_ko_font()
  if self.ko_font then return self.ko_font end
  local ko_path = "assets/fonts/NotoSansKR-Regular.ttf"
  if love.filesystem.getInfo(ko_path) then
    self.ko_font = love.graphics.newFont(ko_path, self.size)
  else
    self.ko_font = self.font
  end
  return self.ko_font
end
```

장점: 게임 시작 시 모든 폰트 로드 안 함. 첫 CJK 텍스트 등장 시 lazy 로드.

## 9. 색상 태그 보존하며 번역

love2d 텍스트는 색상 태그(`[yellow]`, `[fg]`)를 사용:
```
'[fg]Classes: ' .. character_class_strings[character]
```

번역 시:
- 색상 태그는 보존
- 영문 단어만 치환
- 정규식으로 `[yellow]...[/yellow]`, `[fg]...[/fg]` 분리 후 텍스트만 번역

```lua
def translate_static(text):
    translations = {
        'movement speed': '이동속도',
        'attack speed': '공격속도',
        'defense': '방어력',
        ...
    }
    # 긴 패턴 우선 매칭 (단어 단위 매칭이 긴 패턴 깨뜨림 방지)
    sorted_keys = sorted(translations.keys(), key=len, reverse=True)
    for en in sorted_keys:
        if en in text:
            text = text.replace(en, translations[en])
    return text
```

### 3단계 매칭 전략 (SNKRX v0.1.12)

1. **풀 문장 매칭** (긴 패턴 우선) — 84개 패시브의 80%+
2. **단어 매핑** (cleanup 사전)
3. **단어 경계 정규식** (`\bhas\b` 등)

길 패턴 먼저 매칭 → 잔여 단어만 단어 매칭. 매칭 안 된 단어의 절반은 오타 (`tkg` = taking, `vlue` = value).
