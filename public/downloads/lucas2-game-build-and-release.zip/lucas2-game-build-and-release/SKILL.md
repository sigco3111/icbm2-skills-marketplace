>---
name: lucas2-game-build-and-release
description: "lucas2 (lucas2, Love2D, GDscript-기반 게임엔진 등 Lua/스크립트 기반) 게임의 크로스 플랫폼 빌드 + GitHub Releases 배포 워크플로우. .love 파일 빌드 → .app/macOS, zip/Windows, AppImage/Linux 패키징 → curl API로 GitHub Release 발행. SNKRX 한국어화 fork v0.1.19 배포 (2026-07-21 실전 검증) — love2d 11.5 + 빌드 스크립트 4개 + 4개 플랫폼 패키지 + 한글 인코딩 함정 + Lua local 함수 함정 + **듀얼 모드 (game/ 폴더 + .love zip 동시 제공, Windows 한글/영문 path 모두 지원) + Release asset idempotent 업로드 (curl GET → DELETE → POST)** + macOS Contents/Frameworks/* 10개 footgun + unzip -o prompt footgun. love2d 외 lucas2 SDK/Defold/Godot Lua 확장으로도 적용 가능."
version: 1.1.0
author: HyeRin (MiniMax)
license: MIT
metadata:
  hermes:
    tags: [lucas2, love2d, game-build, cross-platform, github-release, deployment, lua, indie-game, dual-mode, idempotent-asset-upload]
    related_skills: [godot-game-bootstrap, unity-game-bootstrap, github-portfolio-planner]
---

# LÖVE/love2d 게임 크로스 플랫폼 빌드 + GitHub Releases 배포

> 🎮 love2d (lucas2) 게임을 macOS/Windows/Linux 3개 플랫폼용으로 패키징하고 GitHub Releases로 발행하는 워크플로우. **2026-07-21 SNKRX 한국어화 fork v0.1.19 배포 실전 검증**.

## 언제 사용하나

| 사용자 요청 | 트리거 |
|------------|--------|
| "love2d 게임 빌드해줘" | ✓ |
| "lucas2 게임 크로스 플랫폼 패키징" | ✓ |
| "GitHub Releases로 게임 배포" | ✓ |
| "macOS .app / Windows .exe / Linux AppImage 만들기" | ✓ |
| "게임 .love 파일 빌드" | ✓ |
| "itch.io 대신 GitHub Releases로 배포" | ✓ |
| "Windows .bat 한글 깨짐 해결" | ✓ |
| "사용자 한글 path에서 게임 실행 안 됨" | ✓ (game/ 폴더 모드) |
| "사용자 영문 path에서 게임 실행" | ✓ (.love zip 모드) |
| **"Defold/Lua 게임도 비슷한 방식으로"** | ✓ (lucas2 패턴 → 다른 Lua 엔진 확장) |

## 핵심 워크플로우 (4단계 + 1단계 보너스)

### 1. .love 파일 빌드 (크로스 플랫폼 단일)

`.love`는 love2d가 직접 실행 가능한 zip. 게임 폴더를 zip으로 묶고 확장자만 `.love`로 변경.

```bash
#!/bin/bash
# build_love.sh
set -e
VERSION="${VERSION:-v0.1.19}"
PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
DIST_DIR="$PROJECT_DIR/dist"
OUTPUT="$DIST_DIR/snkrx-kr-$VERSION.love"
mkdir -p "$DIST_DIR"

cd "$PROJECT_DIR"
zip -r "$OUTPUT" . -x "*.git*" -x "*.DS_Store" -x "dist/*" -x "*.love" -q
echo "✅ Built: $OUTPUT ($(du -h "$OUTPUT" | cut -f1))"
```

**함정**: `.git`, `.DS_Store`, `dist/` 반드시 제외. `*.love` (자기 자신) 제외 필수.

### 2. macOS .app 번들 (구조 + Frameworks)

**필수**: `Contents/MacOS/love` + `Contents/Resources/game.love` + **`Contents/Frameworks/*.framework` 10개** + `Info.plist` + 아이콘.

```bash
# build_macos.sh 핵심
cp "/Applications/love.app/Contents/MacOS/love" "$MACOS_DIR/love"
chmod +x "$MACOS_DIR/love"

# ⚠️ 10개 .framework 복사 필수 (없으면 dyld 에러)
FRAMEWORKS_SRC="/Applications/love.app/Contents/Frameworks"
FRAMEWORKS_DST="$CONTENTS/Frameworks"
mkdir -p "$FRAMEWORKS_DST"
cp -R "$FRAMEWORKS_SRC"/* "$FRAMEWORKS_DST/"

cp "$SOURCE_LOVE" "$RESOURCES_DIR/game.love"
cp "/Applications/love.app/Contents/Resources/GameIcon.icns" "$RESOURCES_DIR/GameIcon.icns"
```

**Info.plist** 핵심 필드:
- `CFBundleName`, `CFBundleDisplayName` (한글 가능)
- `CFBundleExecutable`: `love`
- `LSMinimumSystemVersion`: `10.13`
- `NSHighResolutionCapable`: `true`
- `CFBundleDocumentTypes`: `org.love2d.love-game` (love2d game 타입)

**테스트**: `dist/SNKRX-한국어.app/Contents/MacOS/love` 직접 실행. ALIVE면 OK.

### 3. Windows zip (love2d 번들 + run.bat) — v0.1.19 듀얼 모드

```bash
curl -L -o love.zip "https://github.com/love2d/love/releases/download/11.5/love-11.5-win64.zip"
unzip -q -o love.zip
cp snkrx-kr-v0.1.19.love love-11.5-win64/   # ← 듀얼 모드: .love도 zip에 포함
# game/ 폴더 추출
GAME_DIR="$WINDOWS_DIR/love-11.5-win64/game"
mkdir -p "$GAME_DIR"
(cd "$GAME_DIR" && unzip -q -o "$LOVE_OUTPUT")
# run.bat / README.txt는 build_all.sh에서 자동 생성 (v0.1.19 듀얼 모드)
zip -r snkrx-kr-windows-v0.1.19.zip love-11.5-win64/ run.bat README.txt -q
```

**v0.1.19 듀얼 모드** (NEW, 2026-07-21) — game/ 폴더 + .love zip 둘 다 포함:
```
snkrx-kr-windows-v0.1.19.zip (131M)
├── run.bat                ← 폴백 자동 실행 (folder → zip)
├── README.txt
└── love-11.5-win64/
    ├── love.exe
    ├── *.dll
    ├── game/                 ← 폴더 모드 (한글 path 안전, 기본)
    │   ├── conf.lua
    │   ├── main.lua
    │   └── ...
    └── snkrx-kr-v0.1.19.love  ← zip 모드 (영문 path, fallback)
```

**run.bat 자동 폴백 로직** (v0.1.19):
```bat
@echo off
REM SNKRX Korean fork launcher (Windows)
cd /d "%~dp0"
cd love-11.5-win64
echo Starting SNKRX (folder mode)...
love.exe game
if errorlevel 1 (
    echo.
    echo Folder mode failed. Trying .love zip mode...
    love.exe snkrx-kr-v0.1.19.love
    if errorlevel 1 (
        echo.
        echo Both modes failed.
        echo Install Visual C++ 2013 Redistributable.
        echo Or run: lovec.exe game
        pause
    )
)
```

**⚠️ v0.1.16 fix — Windows .bat은 순수 ASCII만** (한글 깨짐 함정, see references/).
**⚠️ v0.1.17 fix — `cd love-11.5-win64` 필수** (.love zip 인식 함정).
**⚠️ v0.1.19 fix — 듀얼 모드**: 사용자 정정 ".love가 zip에 없다" → game/ + .love 둘 다.

### 4. Linux AppImage + tar.gz

```bash
curl -L -o love.AppImage "https://github.com/love2d/love/releases/download/11.5/love-11.5-x86_64.AppImage"
chmod +x love.AppImage
cp snkrx-kr-v0.1.19.love .
tar czf snkrx-kr-linux-v0.1.19.tar.gz love.AppImage snkrx-kr-v0.1.19.love run.sh README.txt
```

**run.sh**:
```bash
#!/bin/bash
set -e
cd "$(dirname "$0")"
./love.AppImage snkrx-kr-v0.1.19.love "$@"
```

**README.txt** (FUSE 미설치 환경 안내):
```
FUSE 오류 시: sudo apt install fuse libfuse2
또는: ./love.AppImage --appimage-extract
       ./squashfs-root/AppRun snkrx-kr-v0.1.19.love
```

### 5. GitHub Release 발행 (curl API, idempotent)

`gh release create`는 **workflow scope** 필요. 부족 시 curl API 우회.

→ **자동화 버전**: `scripts/release_github.sh` 사용 (빌드→검증→Release 발행 idempotent 워크플로). 단일 명령:
```bash
./scripts/release_github.sh v0.1.19
```

수동 버전 (참고):

```bash
TOKEN=$(gh auth token 2>/dev/null)
REPO="user/repo"

# 1) Release 생성 (draft)
RELEASE_JSON=$(curl -s -X POST \
  -H "Authorization: Bearer $TOKEN" \
  -H "Accept: application/vnd.github+json" \
  https://api.github.com/repos/$REPO/releases \
  -d '{"tag_name":"v0.1.19","name":"Release v0.1.19","body":"...","draft":true}')

RELEASE_ID=$(echo "$RELEASE_JSON" | python3 -c "import sys,json; print(json.load(sys.stdin)['id'])")

# 2) Asset 업로드 (idempotent: 기존 asset 있으면 DELETE 후 POST)
#    HTTP 422 = 중복 (이미 같은 이름), HTTP 404 = asset 없음
for file in dist/*.zip dist/*.tar.gz dist/*.love; do
  name=$(basename "$file")
  
  # 기존 asset 확인
  EXISTING=$(curl -s -X GET \
    -H "Authorization: Bearer $TOKEN" \
    "https://api.github.com/repos/$REPO/releases/$RELEASE_ID/assets" \
    | python3 -c "import sys,json; r=[a['id'] for a in json.load(sys.stdin) if a['name']=='$name']; print(r[0] if r else '')")
  
  # 있으면 삭제
  if [ -n "$EXISTING" ]; then
    curl -s -X DELETE \
      -H "Authorization: Bearer $TOKEN" \
      "https://api.github.com/repos/$REPO/releases/assets/$EXISTING" \
      -o /dev/null
  fi
  
  # 새로 업로드
  curl -s -X POST \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/zip" \
    --data-binary "@$file" \
    "https://uploads.github.com/repos/$REPO/releases/$RELEASE_ID/assets?name=$name" \
    -o /dev/null -w "  $name: HTTP %{http_code}\n"
done

# 3) Draft → Published
curl -s -X PATCH \
  -H "Authorization: Bearer $TOKEN" \
  -H "Accept: application/vnd.github+json" \
  https://api.github.com/repos/$REPO/releases/$RELEASE_ID \
  -d '{"draft":false}'
```

**중요**: 422 에러 (같은 이름 중복) 자주 발생 → idempotent 패턴 (GET → DELETE → POST) 필수.

## 통합 빌드 스크립트 (build_all.sh)

```bash
#!/bin/bash
set -e
VERSION="${VERSION:-v0.1.19}"
PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
DIST_DIR="$PROJECT_DIR/dist"
LOVE_OUTPUT="$DIST_DIR/snkrx-kr-$VERSION.love"

# 1) .love 빌드
"$PROJECT_DIR/build_love.sh"

# 2) macOS .app
"$DIST_DIR/macosx/build_macos.sh"
(cd "$DIST_DIR" && zip -r "snkrx-kr-macos-$VERSION.zip" "SNKRX-한국어.app" -q)

# 3) Windows zip (v0.1.19 듀얼 모드)
WINDOWS_DIR="$DIST_DIR/windows"
if [ ! -f "$WINDOWS_DIR/love.exe" ]; then
    echo "  love2d Windows 다운로드..."
    curl -L -o "$WINDOWS_DIR/love.zip" "https://github.com/love2d/love/releases/download/11.5/love-11.5-win64.zip" 2>&1 | tail -1
    (cd "$WINDOWS_DIR" && unzip -q -o love.zip)
    rm "$WINDOWS_DIR/love.zip"
fi
cp "$LOVE_OUTPUT" "$WINDOWS_DIR/"

# v0.1.19: game/ 폴더 + .love 둘 다 추출 (듀얼 모드)
GAME_DIR="$WINDOWS_DIR/love-11.5-win64/game"
rm -rf "$GAME_DIR"
mkdir -p "$GAME_DIR"
(cd "$GAME_DIR" && unzip -q -o "$LOVE_OUTPUT")

# run.bat / README.txt 자동 생성
if [ ! -f "$WINDOWS_DIR/run.bat" ]; then
    cat > "$WINDOWS_DIR/run.bat" <<'BAT'
@echo off
REM SNKRX Korean fork launcher (Windows)
cd /d "%~dp0"
cd love-11.5-win64
echo Starting SNKRX (folder mode)...
love.exe game
if errorlevel 1 (
    echo.
    echo Folder mode failed. Trying .love zip mode...
    love.exe snkrx-kr-v0.1.19.love
    if errorlevel 1 (
        echo.
        echo Both modes failed.
        echo Install Visual C++ 2013 Redistributable.
        echo Or run: lovec.exe game
        pause
    )
)
BAT
fi
# README.txt 동일 ASCII only
rm -f "$DIST_DIR/snkrx-kr-windows-$VERSION.zip"
(cd "$WINDOWS_DIR" && zip -r "$DIST_DIR/snkrx-kr-windows-$VERSION.zip" love-11.5-win64/ run.bat README.txt -q)

# 4) Linux
LINUX_DIR="$DIST_DIR/linux"
if [ ! -f "$LINUX_DIR/love.AppImage" ]; then
    echo "  love2d AppImage 다운로드..."
    curl -L -o "$LINUX_DIR/love.AppImage" "https://github.com/love2d/love/releases/download/11.5/love-11.5-x86_64.AppImage" 2>&1 | tail -1
    chmod +x "$LINUX_DIR/love.AppImage"
fi
cp "$LOVE_OUTPUT" "$LINUX_DIR/"
rm -f "$DIST_DIR/snkrx-kr-linux-$VERSION.tar.gz"
(cd "$LINUX_DIR" && tar czf "$DIST_DIR/snkrx-kr-linux-$VERSION.tar.gz" love.AppImage "snkrx-kr-$VERSION.love" run.sh README.txt)
```

## 빌드 결과물 크기 (참고)

| 플랫폼 | 파일 | 크기 |
|---|---|---|
| macOS | `SNKRX-한국어.app` | 84M |
| Windows (v0.1.19 듀얼) | `snkrx-kr-windows-v0.1.19.zip` | **131M** (game/ + .love 둘 다) |
| Windows (v0.1.18 이전) | `snkrx-kr-windows-v0.1.18.zip` | 4.5M (game/ 만) |
| Linux | `snkrx-kr-linux-v0.1.19.tar.gz` | 65M (AppImage 4.8M + .love) |
| 크로스 | `snkrx-kr-v0.1.19.love` | 62M |

## 7대 함정 (자세한 내용은 references 참조)

| # | 함정 | 해결 |
|---|------|------|
| 1 | macOS .app Frameworks 누락 | `love.framework` 등 10개 `.framework` 복사 |
| 2 | **Windows .bat 한글 깨짐** | `.bat`은 **순수 ASCII**만, `README.txt`만 한글 |
| 3 | `gh release` workflow scope 부족 | `curl /repos/.../releases` API 직접 호출 |
| 4 | `build_all.sh` if `[ ! -f ]` 조건 | 기존 파일 삭제 후 빌드 (변경사항 반영) |
| 5 | `unzip` 인터랙티브 멈춤 | `-o` 플래그 (overwrite) |
| 6 | 빌드 스크립트 path 중복 (`DIST_DIR/DIST_DIR`) | 절대 path + `cd "$DIR" && cmd` 서브셸 |
| 7 | **Release asset 422 중복** | **idempotent 업로드 (GET → DELETE → POST)** |

## 4대 Lua 함정 (자세한 내용은 references 참조)

| # | 함정 | 증상 | 해결 |
|---|------|------|------|
| 1 | `:activate({...})` 안 `local` | `unexpected symbol near 'local'` | local 선언을 `:activate({` **밖**으로 |
| 2 | `local ylb1/2/3`, `local ts` 모듈 접근 | `attempt to call global 'ylb1' (a nil value)` | ko.lua에 자체 정의 |
| 3 | `if not text` 가드 (0 = truthy) | `attempt to get length of local 'text' (a number value)` | `type(text) ~= "string"` 명시 |
| 4 | `print/print_centered`의 `font.font` 직접 접근 | `font:has_cjk` 미적용 | `font:get_font_for_text(text)` 우회 |

## 3대 Bash 빌드 함정

| # | 함정 | 해결 |
|---|------|------|
| 1 | `cd ... && cmd` 부모 셸 영향 | 서브셸 `(cd DIR; cmd)` 사용 |
| 2 | `PROJECT_DIR="$(dirname $0)/.."` 중복 | `SCRIPT_DIR` 명시 후 `cd "$SCRIPT_DIR/.."` |
| 3 | love2d Window zip `unzip` 인터랙티브 | `unzip -q -o` |

## 검증 체크리스트

- [ ] macOS .app: `dist/SNKRX-한국어.app/Contents/MacOS/love` 직접 실행 → ALIVE
- [ ] **Windows zip (v0.1.19 듀얼)**: 한글 path에서 `run.bat` 더블클릭 → `love.exe game` 폴더 모드 ALIVE
- [ ] **Windows zip (v0.1.19 듀얼)**: 영문 path에서 폴더 모드 실패 시 `.love` zip 모드 fallback ALIVE
- [ ] Linux tar.gz: `./run.sh` → ALIVE
- [ ] .love 크로스: `love snkrx-kr-v0.1.19.love` → ALIVE
- [ ] `dist/` 폴더를 `.gitignore`에 추가
- [ ] GitHub Release: 4개 asset HTTP 201 응답 (idempotent 업로드)
- [ ] **사용자 정정 시그널 → 1순위 의심 → 듀얼 모드로 해결** (이전 v0.1.18 단일 모드 한계)

## 템플릿 파일

다음 위치의 템플릿을 복사해서 사용:
- `templates/build_love.sh` — .love 파일 빌드 (단일 플랫폼)
- `templates/build_macos.sh` — macOS .app 번들 (love2d + 10 frameworks + .love)
- `templates/build_all.sh` — 3개 플랫폼 통합 빌드 (**v0.1.19 듀얼 모드**: Windows game/ 폴더 + .love zip 동시, build 직전 fresh 파일, ASCII run.bat)

## 빌드 → Release 자동화 스크립트

- `scripts/release_github.sh` — 빌드 → 검증 → GitHub Release 발행 (**idempotent asset 업로드**: GET → DELETE → POST)

## References (자세한 함정/패턴 문서)

- `references/windows-deployment-issues.md` — **SNKRX v0.1.15~v0.1.19 실측 5함정** (love.exe 경로, .love 한글 path 인식 실패 → game/ 폴더, if [ ! -f ] skip, **v0.1.19 듀얼 모드 (game/ + .love zip)**, 사용자 워크어라운드 수용 패턴, GitHub Release 재업로드 idempotent 패턴, build→검증→업로드 자동화 워크플로)
- `references/lua-pitfalls.md` — love2d/Lua 게임 개발 9대 함정 (콜백 local, main.lua local 함수, truthy, UTF-8, CJK 폰트, 색상 태그 번역)
- `references/windows-batch-encoding.md` — Windows .bat 한글 깨짐 함정 (3번째 만남 회고 + ASCII 전용 규칙 + 디버그 방법)

## 관련 Skill

- **godot-game-bootstrap** — Godot 4 게임의 멀티플랫폼 export 패턴 참고
- **unity-game-bootstrap** — Unity 게임 빌드 패턴
- **mac-bootstrap** — Apple Silicon 환경 셋업
- **github-portfolio-planner** — GitHub Pages 배포

## 실전 검증

- **SNKRX 한국어화 fork v0.1.19** (2026-07-21)
  - 4개 플랫폼 빌드 성공 (Windows 듀얼 모드)
  - GitHub Release 발행: https://github.com/sigco3111/snkrx-clone/releases/tag/v0.1.19
  - 총 226M (4개 asset 합)
  - Windows run.bat 한글 깨짐 → ASCII로 수정 후 해결
  - **v0.1.19 듀얼 모드**: 사용자 정정 ".love가 zip에 없다" → game/ + .love 둘 다 포함으로 해결

## 즉시 적용 규칙 — Windows love2d 게임 배포 (NEW, v0.1.19)

1. **듀얼 모드 기본**: game/ 폴더 (한글 path 안전) + .love zip (영문 path fallback) 둘 다 zip에 포함
2. **run.bat 자동 폴백**: folder mode → zip mode 순서로 시도
3. **.gitignore에 `dist/`**: 대용량 빌드 결과물 제외
4. **README에 듀얼 모드 설명**: 사용자 혼란 방지
5. **사용자 정정 적극 수용**: ".love가 zip에 없다", "한글이 깨져", "love.exe 못 찾음" 같은 정정 → 1함정씩 수정 → 자동화
6. **Release asset idempotent 업로드**: HTTP 422 (중복) → GET → DELETE → POST 패턴
7. **빌드 직전 `rm -f`**: `if [ ! -f ]` skip으로 인한 stale 빌드 결과물 방지

## 클래스 외 인사이트 — love2d는 웹 빌드 안 됨 (2026-07-21, NEW)

**Vercel/Netlify/GitHub Pages에 love2d 게임 직접 배포는 불가능**:
- LÖVE 11.x는 공식 web 빌드 없음 (love-11.5-web.zip 미존재)
- 커뮤니티 love.js/WASM-4 도구도 모두 deprecated/미유지
- 2D Canvas → WASM 컴파일 도구 없음

**해결**: **새 프로젝트**로 처음부터 TypeScript + Canvas 2D로 재작성 → Vercel 배포. SNKRX는 그대로 LÖVE + GitHub Releases 배포 유지.

**즉시 적용 규칙**: 사용자가 "LÖVE 게임을 웹/Vercel로 배포" 요청 시 → **재작업 필요** 안내. 단일 클래스 파일로 끝나는 작업 아님. 새 프로젝트 시작.
