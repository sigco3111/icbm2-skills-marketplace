#!/bin/bash
# build_macos.sh — macOS .app 번들 만들기
# 출력: dist/<APP_NAME>.app
# 사용자가 dist/<APP_NAME>.app를 Applications로 드래그하면 설치 완료

set -e

VERSION="${1:-v0.1.12}"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
DIST_DIR="$PROJECT_DIR"  # build_macos.sh is in dist/macosx/, so PROJECT_DIR is already dist/
SOURCE_LOVE="$DIST_DIR/snkrx-kr-$VERSION.love"
APP_NAME="${APP_NAME:-SNKRX-한국어}"
APP_BUNDLE="$DIST_DIR/$APP_NAME.app"
CONTENTS="$APP_BUNDLE/Contents"
MACOS_DIR="$CONTENTS/MacOS"
RESOURCES_DIR="$CONTENTS/Resources"

# 1. 기존 번들 정리
rm -rf "$APP_BUNDLE"

# 2. .app 구조 생성
mkdir -p "$MACOS_DIR" "$RESOURCES_DIR"

# 3. love2d 실행 파일 복사
cp "/Applications/love.app/Contents/MacOS/love" "$MACOS_DIR/love"
chmod +x "$MACOS_DIR/love"

# 3.5. love2d Frameworks 복사 (의존성, 10개 .framework)
FRAMEWORKS_SRC="/Applications/love.app/Contents/Frameworks"
FRAMEWORKS_DST="$CONTENTS/Frameworks"
if [ -d "$FRAMEWORKS_SRC" ]; then
    mkdir -p "$FRAMEWORKS_DST"
    cp -R "$FRAMEWORKS_SRC"/* "$FRAMEWORKS_DST/"
    echo "✅ Frameworks 복사: $(ls "$FRAMEWORKS_DST" | wc -l)개"
fi

# 4. Info.plist 복사
cp "$SCRIPT_DIR/Info.plist" "$CONTENTS/Info.plist"

# 5. .love 파일 복사
cp "$SOURCE_LOVE" "$RESOURCES_DIR/game.love"

# 6. 아이콘 복사
if [ -f "/Applications/love.app/Contents/Resources/GameIcon.icns" ]; then
    cp "/Applications/love.app/Contents/Resources/GameIcon.icns" "$RESOURCES_DIR/GameIcon.icns"
fi

# 7. PkgInfo
echo -n "APPL????" > "$CONTENTS/PkgInfo"

echo "✅ Built: $APP_BUNDLE"
echo "📦 Size: $(du -sh "$APP_BUNDLE" | cut -f1)"
echo ""
echo "설치 방법:"
echo "  1. Finder에서 $APP_BUNDLE 더블클릭"
echo "  2. Applications로 드래그"
echo "  3. Launchpad에서 'SNKRX 한국어' 실행"
echo ""
echo "테스트: $MACOS_DIR/love 직접 실행 (ALIVE 확인)"
