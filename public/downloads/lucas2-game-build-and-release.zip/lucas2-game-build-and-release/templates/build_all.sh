#!/bin/bash
# build_all.sh — 3개 플랫폼 모두 빌드 (macOS / Windows / Linux)
# 사용법: ./build_all.sh [VERSION]
# 출력: dist/<platform>-v0.1.18.{zip,tar.gz}
#
# ★ v0.1.18+ 패턴:
#   - Windows: .love zip → love-11.5-win64/game/ 폴더로 압축 해제 (한글 path 우회)
#   - run.bat: ASCII only, `cd love-11.5-win64; love.exe game`
#   - build 직전 기존 run.bat/README.txt/game/ 삭제 (if [ ! -f ] skip 방지)
#   - subshell `(cd DIR && cmd)` 패턴 (현재 디렉토리 부작용 방지)

set -e

VERSION="${1:-v0.1.18}"
PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
DIST_DIR="$PROJECT_DIR/dist"
LOVE_OUTPUT="$DIST_DIR/snkrx-kr-$VERSION.love"

echo "=== SNKRX 한국어화 fork 빌드 ($VERSION) ==="
echo

# 1. .love 파일 빌드
if [ ! -f "$LOVE_OUTPUT" ] || [ -n "$REBUILD" ]; then
    echo "1/4 .love 파일 빌드..."
    "$PROJECT_DIR/build_love.sh" "$VERSION"
else
    echo "1/4 .love 파일 (이미 존재): $LOVE_OUTPUT"
fi
echo

# 2. macOS .app 번들
echo "2/4 macOS .app 번들 빌드..."
"$DIST_DIR/macosx/build_macos.sh" "$VERSION"
rm -f "$DIST_DIR/snkrx-kr-macos-$VERSION.zip"
(cd "$DIST_DIR" && zip -r "snkrx-kr-macos-$VERSION.zip" "SNKRX-한국어.app" -q)
echo "✅ macOS: snkrx-kr-macos-$VERSION.zip"
echo

# 3. Windows zip (v0.1.18+ 패턴: .love → game/ 폴더)
echo "3/4 Windows zip 빌드..."
WINDOWS_DIR="$DIST_DIR/windows"
if [ ! -f "$WINDOWS_DIR/love.exe" ]; then
    echo "  love2d Windows 다운로드..."
    curl -L -o "$WINDOWS_DIR/love.zip" "https://github.com/love2d/love/releases/download/11.5/love-11.5-win64.zip" 2>&1 | tail -1
    (cd "$WINDOWS_DIR" && unzip -q -o love.zip)
    rm "$WINDOWS_DIR/love.zip"
fi

# 기존 파일 삭제 (build_all.sh 재실행 시 변경사항 반영)
rm -f "$WINDOWS_DIR/run.bat" "$WINDOWS_DIR/README.txt"
rm -rf "$WINDOWS_DIR/love-11.5-win64/game"

# .love → game/ 폴더 추출 (한글 Windows path에서 zip 인식 실패 우회)
mkdir -p "$WINDOWS_DIR/love-11.5-win64/game"
(cd "$WINDOWS_DIR/love-11.5-win64/game" && unzip -q -o "$LOVE_OUTPUT")
echo "  ✅ 게임 폴더 추출: $WINDOWS_DIR/love-11.5-win64/game ($(ls "$WINDOWS_DIR/love-11.5-win64/game" | wc -l | tr -d ' ') 항목)"

# run.bat (v0.1.17 fix: cd love-11.5-win64 / v0.1.18 fix: love.exe game)
cat > "$WINDOWS_DIR/run.bat" <<'BAT'
@echo off
REM SNKRX Korean fork launcher (Windows)
cd /d "%~dp0"
cd love-11.5-win64
love.exe game
if errorlevel 1 (
    echo.
    echo Game failed to start.
    echo Install Visual C++ 2013 Redistributable.
    echo Or run: cd love-11.5-win64 && lovec.exe game
    pause
)
BAT
echo "  ✅ run.bat 생성 (ASCII only)"

# README.txt (한글 OK, 메모장으로 열면 정상)
cat > "$WINDOWS_DIR/README.txt" <<'TXT'
SNKRX Korean fork v0.1.18 (Windows)

[How to Run]
1. Double-click run.bat
2. Or: cd love-11.5-win64 && love.exe game

[Controls]
- A/D or Arrow keys : Move snake left/right
- Space : Pause
- Mouse : Buy/sell units

[Troubleshooting]
- "Missing DLL": Install Visual C++ 2013 Redistributable
- Run with console: cd love-11.5-win64 && lovec.exe game

[Original] https://github.com/a327ex/SNKRX
[Fork] https://github.com/sigco3111/snkrx-clone
TXT
echo "  ✅ README.txt 생성"

rm -f "$DIST_DIR/snkrx-kr-windows-$VERSION.zip"
(cd "$WINDOWS_DIR" && zip -r "$DIST_DIR/snkrx-kr-windows-$VERSION.zip" love-11.5-win64/ run.bat README.txt -q)
echo "✅ Windows: snkrx-kr-windows-$VERSION.zip"
echo

# 4. Linux tar.gz
echo "4/4 Linux tar.gz 빌드..."
LINUX_DIR="$DIST_DIR/linux"
if [ ! -f "$LINUX_DIR/love.AppImage" ]; then
    echo "  love2d AppImage 다운로드..."
    curl -L -o "$LINUX_DIR/love.AppImage" "https://github.com/love2d/love/releases/download/11.5/love-11.5-x86_64.AppImage" 2>&1 | tail -1
    chmod +x "$LINUX_DIR/love.AppImage"
fi
cp "$LOVE_OUTPUT" "$LINUX_DIR/"
if [ ! -f "$LINUX_DIR/run.sh" ]; then
    cat > "$LINUX_DIR/run.sh" <<'SH'
#!/bin/bash
set -e
cd "$(dirname "$0")"
./love.AppImage snkrx-kr-v0.1.18.love "$@"
SH
    chmod +x "$LINUX_DIR/run.sh"
fi
rm -f "$DIST_DIR/snkrx-kr-linux-$VERSION.tar.gz"
(cd "$LINUX_DIR" && tar czf "$DIST_DIR/snkrx-kr-linux-$VERSION.tar.gz" love.AppImage "snkrx-kr-$VERSION.love" run.sh README.txt)
echo "✅ Linux: snkrx-kr-linux-$VERSION.tar.gz"
echo

echo "=== 모든 빌드 완료 ==="
cd "$DIST_DIR"
ls -lh "snkrx-kr-macos-$VERSION.zip" "snkrx-kr-windows-$VERSION.zip" "snkrx-kr-linux-$VERSION.tar.gz" "snkrx-kr-$VERSION.love" 2>/dev/null
