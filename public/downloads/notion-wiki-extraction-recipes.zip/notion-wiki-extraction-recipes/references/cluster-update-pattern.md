# Cluster update pattern — "N digest items → 1 update section on existing concept" (verified 2026-07-27)

When the Notion digest contains 3+ items that ALL map to the same
existing concept page, the correct pattern is **NOT to create new
wiki pages for each item**. Instead, **add a single `## YYYY-MM-DD
업데이트` section** to the existing concept page that captures all
the new items as a table + subsections.

## Verified case — 2026-07-27 sync

Items mapping to [[chinese-opensource-llm-race-2026-07]]:
- FLUX 3 (Black Forest Labs 통합 멀티모달 — 새로운 미국 프론티어 신호)
- Claude Opus 5 AA Intelligence Index 1위 (170 모델 평가)
- Andrew Ng OpenWorker (모델 독립 오픈소스 AI coworker)
- Claude Media Control (Bangs00 macOS now-playing 통합)

→ Instead of creating 4 new pages or 4 separate update sections,
**add one `## 2026-07-27 업데이트 — 글로벌 멀티모달 라인업 동시 확장`
section** with a 4-row table + 2 short subsections (Opus 5 leaderboard
해석, FLUX 3 변곡점). Total addition: ~25 lines. Concept page now
reflects the *thread* running through 2026-07-27 (에이전트 + 멀티모달
+ 지능 1위 트리플 신호) instead of fragmenting across 4 pages.

## Decision rule

- 3+ items in one digest map to the same concept → reinforce existing
  page with one **dated update section** + cluster analysis at end
- 1–2 items map to the same concept → if first time, create new
  entity; if exists, add a small `## 출처 추가 (date)` note inline
- Items across unrelated concepts → standard create/update per item

## Why this matters

Concept pages in `llm-wiki` are designed to be **navigational hubs**
for a thread of development, not point-in-time snapshots. Obsidian
graph view and Dataview queries can pivot on `updated:` dates or
section headers; clustering multiple items under one dated section
preserves both:

1. **Audit clarity** — `log.md` references one `## 2026-07-27 업데이트`
   section header, not 4 separate page-update entries
2. **Synthesis visibility** — the cluster analysis (why all 4 items
   appeared same day) is captured in 1-2 paragraphs, not 4 separate
   one-liners
3. **Future-readability** — a 2026-08 agent reading the concept page
   sees "2026-07-27: 에이전트+멀티모달+지능 트리플 신호" in the
   timeline at a glance

## Cluster analysis template

When the cluster adds a new dated section, include at the bottom:

```markdown
## 클러스터 분석 (optional synthesis)

7건 중 5건이 "AI 에이전트/오케스트레이션/시스템 통합" 클러스터로 수렴:
- 도구 슬림화: claude-media-control, claude-5-context-engineering
- 멀티에이전트 오케스트레이션: claude-of-duty, openworker
- 통합 멀티모달: flux-3

→ 모두 **로컬 / 오픈소스 / 모델 독립** 흐름으로 수렴.
```

This meta-synthesis is what makes the cluster pattern valuable —
without it, the page just becomes a bulleted list of additions.

## Related-page touch-up rule

When reinforcing the existing concept page, ALSO patch 2-3 related
entity pages to add backlinks to the new cluster. Example from
2026-07-27:

- omp.md → +[[claude-of-duty]], +[[claude-5-context-engineering-2026-07]], +[[openworker]]
- (skip existing concept re-touch — it has the backlinks already)

Avoid over-touched: each backlink should be a 1-line addition, not
a section rewrite.

## Generic — works for any class-level update batch

The pattern doesn't depend on the topic (AI 에이전트, 시장 동향,
벤치마크 비교, etc.). Whenever you see a Notion digest with strong
thematic cohesion, apply this:

1. Identify the most-related existing concept page (or none → create
   one if 4+ items fit cleanly)
2. Add a `## YYYY-MM-DD 업데이트` section with a table of items +
   2-3 short subsections
3. Patch 2-3 related entity pages with `[[cluster-backlink]]` lines
4. In `log.md`, reference ONE section header, not N item entries
