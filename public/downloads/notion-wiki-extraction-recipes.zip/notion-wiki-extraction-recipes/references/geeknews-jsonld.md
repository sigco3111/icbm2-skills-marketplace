# GeekNews JSON-LD `articleBody` extraction (verified 2026-07-27)

The OG `topic-text` / `topic_text` div extraction patterns (referenced
in older `llm-wiki` skill materials) stopped working reliably by
2026-07-27 across all GeekNews topic pages tested (ids 31791, 31807, 31782).
The actual body now lives inside `<script type="application/ld+json">`
blocks as `articleBody`/`description` fields.

## Symptom — old pattern returns empty body

```bash
curl -sL -A "Mozilla/5.0" "https://news.hada.io/topic?id=31791" -o /tmp/x.html
grep -c 'class="topic-text"' /tmp/x.html
# 0 — class no longer present in DOM
grep -A1 '<title>' /tmp/x.html | head -3
# title shows in DOM, but body is JS-rendered / JSON-LD only
```

All three GeekNews items fetched on 2026-07-27 (FLUX 3, Opus 5 AA,
Claude 5 context engineering) returned 39k–44k char HTML with **no
topic-text/topic_text classes**. The DOM contains only navigation,
footer, and schema.org metadata classes. The actual body content is
exclusively in JSON-LD.

## Working pattern — JSON-LD extraction

```bash
mkdir -p /tmp/wiki-fetch && cd /tmp/wiki-fetch
curl -sL -A "Mozilla/5.0" -o article.html "https://news.hada.io/topic?id=31791"

python3 << 'PYEOF'
import re, json
with open("article.html") as f:
    html = f.read()

# Extract ALL JSON-LD script blocks (not just the first)
chunks = re.findall(
    r'<script[^>]*application/ld\+json[^>]*>(.*?)</script>',
    html, re.DOTALL,
)

article_body = ""
description = ""
title = ""
date_published = ""

for c in chunks:
    try:
        d = json.loads(c)
    except json.JSONDecodeError:
        continue
    if not isinstance(d, dict):
        continue
    # NewsArticle schema → articleBody + description + headline + datePublished
    if d.get("@type") == "NewsArticle" or "articleBody" in d:
        article_body = d.get("articleBody", "") or article_body
        description = d.get("description", "") or description
        title = d.get("headline", "") or title
        date_published = d.get("datePublished", "") or date_published

print("TITLE:", title)
print("DATE :", date_published)
print("---DESC---")
print(description[:500])
print("---BODY---")
print(article_body[:3000])
PYEOF
```

## Why multiple JSON-LD chunks, not just one

GeekNews serves at least 2–3 JSON-LD blocks per page:

1. `NewsArticle` schema — the actual article body (`articleBody` + `description`)
2. `BreadcrumbList` or `WebSite` schema — navigation metadata (irrelevant)
3. Sometimes a `Person` block for the author

A single-match regex (`re.search` on first `<script>...ld+json...</script>`)
often hits `BreadcrumbList` first and returns nothing useful. Always
**loop over all chunks**, check `isinstance(d, dict)`, then take the
first non-empty `articleBody` match.

## Robustness notes

- **macOS `grep -P` does NOT work** (no PCRE). Use Python `re` always.
- **`json.loads` strict mode fails on rare trailing commas** — wrap
  in `try/except json.JSONDecodeError`.
- **GeekNews serves ~40k char HTML**, mostly nav/footer — the actual
  body in JSON-LD is 1.5–3k chars. Don't waste cycles parsing the
  full HTML.
- **`description` is shorter than `articleBody`** but always present;
  use as a fallback if `articleBody` is empty on some pages.
- **Headline & datePublished in same JSON-LD** — capture them once,
  frontmatter the raw file directly:
  ```python
  frontmatter = f"""---
  title: "{title}"
  url: https://news.hada.io/topic?id={TOPIC_ID}
  date: {date_published[:10]}
  fetch_status: extracted
  fetched_via: curl + schema.org JSON-LD articleBody
  ---"""
  ```

## Cost reduction

Single curl + Python loop pattern: ~3-4 seconds total per GeekNews
item vs ~8-12 seconds for full HTML parse. For a 5-item GeekNews-heavy
digest, this saves 25-40 seconds and reduces context window bloat.

## Edge case — extract fails → fallback to og:description

If the regex finds no JSON-LD (e.g., a Notion JS-only topic page):

```python
og = re.search(
    r'<meta[^>]*property="og:description"[^>]*content="([^"]+)"',
    html,
)
if og:
    print("OG ONLY:", og.group(1))
```

The og:description is 1-2 sentences (usually enough to qualify for
pre-classification via the `og:description-based pre-classification`
pattern in `llm-wiki`'s references).

## Verified fetch URLs from 2026-07-27

| Topic id | Title | JSON-LD works? |
|---|---|---|
| 31791 | FLUX 3 모델 공개 | ✅ articleBody extracted fully |
| 31807 | Claude Opus 5, Artificial Analysis 지능 리더보드 1위 | ✅ |
| 31782 | Claude 5 모델을 위한 새로운 컨텍스트 엔지니어링 규칙 | ✅ |
| 30979 | (older, 2026-07-02 reference) | ✅ confirmed retroactively |

All 4 confirm JSON-LD is the canonical, stable extraction target.
