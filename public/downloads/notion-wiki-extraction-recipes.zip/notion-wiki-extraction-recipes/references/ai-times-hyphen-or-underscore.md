# AI Times extraction — `class="article-body"` (hyphen OR underscore, verified 2026-07-27)

The older extraction recipe in `llm-wiki` references documented
`article_body` (underscore) as the AI Times body selector. The
2026-07-27 fetch of `articleView.html?idxno=213135` (Andrew Ng
OpenWorker coverage) confirmed the actual class is `article-body`
(**hyphen**) on at least some pages. Both forms co-exist in AI Times'
CMS — different article templates, different content blocks.

## Working pattern — match both with one regex

```bash
curl -sL -A "Mozilla/5.0" \
    "https://www.aitimes.com/news/articleView.html?idxno=213135" \
    -o /tmp/ow.html

python3 << 'PYEOF'
import re
with open("/tmp/ow.html") as f:
    html = f.read()

# ONE regex that matches both hyphen and underscore variants
m = re.search(
    r'class="[^"]*article[-_]body[^"]*"[^>]*>(.{1000,30000})',
    html, re.DOTALL,
)

if not m:
    # Fallback to meta description only (still useful as 1-2 sentence summary)
    meta = re.search(
        r'<meta[^>]*name="description"[^>]*content="([^"]+)"',
        html,
    )
    og_title = re.search(
        r'<meta[^>]*property="og:title"[^>]*content="([^"]+)"',
        html,
    )
    print("META FALLBACK")
    print("title:", og_title.group(1) if og_title else "?")
    print("desc :", meta.group(1) if meta else "?")
    raise SystemExit(0)

chunk = m.group(1)
text = re.sub(r"<script[^>]*>.*?</script>", " ", chunk, flags=re.DOTALL)
text = re.sub(r"<style[^>]*>.*?</style>", " ", text, flags=re.DOTALL)
text = re.sub(r"<[^>]+>", " ", text)
text = re.sub(r"\s+", " ", text).strip()
print("BODY_LEN:", len(text))
print(text[:3000])
PYEOF
```

The `[-_]` character class matches either `-` or `_` — one regex
covers both naming conventions.

## Why both forms exist

AI Times appears to use the same CMS template engine as several
other Korean news portals (ZDNet Korea, 전자신문, etnews). Different
sections on the same site and different sites can produce either
naming variant depending on:

- The article template selected at publish time
- Whether the article is a single-page view or part of a series
- Recent CSS refactors (some old URLs still reference the old naming)

**Always use the `[-_]?` form** in extraction recipes for this family
of Korean news sites.

## Verification step — always check meta description first

If the article-body class match fails, the `meta name="description"`
tag is **almost always present** and gives a 1-2 sentence summary.
Always extract it as a fallback so the raw file is never completely
empty:

```python
meta = re.search(
    r'<meta[^>]*name="description"[^>]*content="([^"]+)"',
    html,
)
og_title = re.search(
    r'<meta[^>]*property="og:title"[^>]*content="([^"]+)"',
    html,
)
```

For the Andrew Ng OpenWorker article (`idxno=213135`), the meta
description was:

> "AI 분야의 권위자인 앤드류 응이 사용자 PC에서 직접 실행되며
> 문서 작성부터 이메일 처리, 일정 관리까지 실제 업무 결과물을
> 완성하는 오픈소스 AI 에이전트를..."

That's a workable 1-sentence summary on its own; combined with the
article-body extract, you get a complete raw source.

## Cross-section false-positive avoidance

The regex `class="[^"]*article[-_]body[^"]*"` will also match
the `article-body-header` or `article-body-bottom` divs (size or
navigation elements around the body). Limit the match group to
**`.{1000,30000}`** (a 1k-char minimum) so accidental matches on
small wrappers are excluded — the real body is multi-kilobyte.

If the class match returns <1000 chars, skip and fall back to meta.

## Related selectors that DO NOT work on AI Times

Just for reference, here are the `id="..."` selectors that DO exist
in AI Times' DOM but do NOT contain the body text:

- `user-wrap`, `user-wrapper`
- `sidenav1`–`sidenav12`
- `layer-popups`
- `floating_banner_left/right`
- `wingBanner`
- `article-view` (the wrapper, not the body)
- `sticky-header`, `fontsize-sticky/dropdown`
- `article-sns`
- `audio-tts-container`
- `myCommnetView`
- `guide-panel`
- `skin-18`, `skin-20`
- `offCanvas`

Don't waste time on these — go directly to `article[-_]body`.

## Forward note

Korean news CMSs (AI Times / ZDNet Korea / 전자신문 등) appear to use
similar template engines with class naming variants. Always try
`article[-_]?body` regex first, then fall back to meta. The same
fallback chain applies to other Korean portals that haven't yet been
mapped in `llm-wiki`'s references.

## Verified fetch URLs from 2026-07-27

| URL | Selector hit | Body extracted? |
|---|---|---|
| `articleView.html?idxno=213135` | `article-body` (hyphen) | ✅ full 25-min Chinese article body |
| `articleView.html?idxno=212918` (older reference, Qwen 3.8) | `article_body` (underscore) | ✅ per `llm-wiki` precedent |
| `articleView.html?idxno=212936` (Moonshot IPO) | `article_body` (underscore) | ✅ |

Both naming conventions are real and active. Pattern: try hyphen first
(since 2026-07 trend), underscore via the `[-_]` character class.
