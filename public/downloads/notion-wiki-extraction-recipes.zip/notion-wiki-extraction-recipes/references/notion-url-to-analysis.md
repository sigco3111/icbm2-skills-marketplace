# Notion URL → Full Database Analysis (page/db-ambiguous)

Use when a user pastes a `notion.so/...` or `app.notion.com/p/...` URL and you need to
extract its contents programmatically (page or database, you don't know which).

**Proven in session 2026-08-06** against a 5,066-row GitHub Trending DB.

## The 5-step recipe

### 1. Parse the URL → dashed UUID

Notion URLs carry a 32-char hex ID that **must** be reformatted as `8-4-4-4-12` UUID.

```bash
# Two URL shapes both work:
# https://www.notion.so/Workspace-1a2b3c4d5e6f7g8h9i0j1k2l3m4n5o6p
# https://app.notion.com/p/33f76f2e90978176a537d40ebb476ef9?v=...
RAW_ID="33f76f2e90978176a537d40ebb476ef9"
UUID=$(python3 -c "s='$RAW_ID'; print(f'{s[:8]}-{s[8:12]}-{s[12:16]}-{s[16:20]}-{s[20:]}')")
# → 33f76f2e-9097-8176-a537-d40ebb476ef9
```

Strip everything after `?` (workspace slug, view params) — keep only the 32-char hex.

### 2. Probe page vs database

A Notion URL works for **both** pages and databases. Cannot tell from URL alone.
Always probe the page endpoint first; if 400 says "is a database, not a page",
recover by hitting the database endpoint.

```bash
NOTION_API_KEY=$(cat ~/.hermes/secrets/notion_token.txt | tr -d '\n\r ')

RAW=$(curl -s -w "\n%{http_code}" "https://api.notion.com/v1/pages/$UUID" \
  -H "Authorization: Bearer $NOTION_API_KEY" \
  -H "Notion-Version: 2025-09-03")
HTTP=$(echo "$RAW" | tail -1)
BODY=$(echo "$RAW" | sed '$d')

if [ "$HTTP" = "200" ]; then
  echo "It's a page — use /pages/$UUID"
elif [ "$HTTP" = "400" ] && echo "$BODY" | grep -q "is a database, not a page"; then
  echo "It's a database — fetch data_source_id"
  curl -s "https://api.notion.com/v1/databases/$UUID" \
    -H "Authorization: Bearer $NOTION_API_KEY" \
    -H "Notion-Version: 2025-09-03" > /tmp/notion_db.json
  DATA_SOURCE_ID=$(jq -r '.data_sources[0].id' /tmp/notion_db.json)
fi
```

**Why this matters:** the bundled `notion` skill shows how to use `/pages/{id}` but
skips the probe step, forcing you to debug the 400 mid-task.

### 3. Introspect schema + select options

```bash
# For databases, hit the data source endpoint for the full schema
curl -s "https://api.notion.com/v1/data_sources/$DATA_SOURCE_ID" \
  -H "Authorization: Bearer $NOTION_API_KEY" \
  -H "Notion-Version: 2025-09-03" > /tmp/notion_ds.json

# Property names + types
jq '.properties | to_entries | map({(.key): .value.type}) | add' /tmp/notion_ds.json

# Select options (for category fields)
jq '.properties | to_entries[] | select(.value.type == "select") |
    {name: .key, options: [.value.select.options[].name]}' /tmp/notion_ds.json

# Title
jq -r '.title[0].plain_text // .title[0].text.content' /tmp/notion_ds.json
```

### 4. Paginate ALL rows (5,000+ rows)

`POST /v1/data_sources/{id}/query` returns max 100 rows/call. For multi-thousand-row
databases, paginate with `has_more` + `next_cursor`:

```python
# /tmp/fetch_all.py
import subprocess, json, sys
NOTION_API_KEY = open("/Users/mac/.hermes/secrets/notion_token.txt").read().strip()
DATA_SOURCE_ID = "<from_step_3>"

all_rows, cursor, page = [], None, 0
while True:
    page += 1
    payload = {"page_size": 100}
    if cursor: payload["start_cursor"] = cursor
    with open("/tmp/q.json", "w") as f: json.dump(payload, f)
    r = subprocess.run([
      "curl", "-s", "-X", "POST",
      f"https://api.notion.com/v1/data_sources/{DATA_SOURCE_ID}/query",
      "-H", f"Authorization: Bearer {NOTION_API_KEY}",
      "-H", "Notion-Version: 2025-09-03",
      "-H", "Content-Type: application/json",
      "-d", "@/tmp/q.json",
    ], capture_output=True, text=True)
    data = json.loads(r.stdout)
    all_rows.extend(data.get("results", []))
    print(f"page {page}: +{len(data.get('results', []))} (total={len(all_rows)})", file=sys.stderr)
    if not data.get("has_more"): break
    cursor = data.get("next_cursor")
    if not cursor: break

with open("/tmp/notion_all_rows.json", "w") as f:
    json.dump(all_rows, f, ensure_ascii=False)
print(f"FINAL: {len(all_rows)} rows")
```

**Real-world timing:** 5,066 rows / 51 pages ≈ 15s. Naturally throttled by subprocess
overhead to stay under the 3 req/s rate limit.

### 5. Analyze (Counter + pandas-style)

```python
import json, re
from collections import Counter, defaultdict

with open("/tmp/notion_all_rows.json") as f:
    rows = json.load(f)

def get_text(rt):
    if not rt: return ""
    return "".join([x.get("plain_text", "") for x in rt])

def parse(p):
    return {
        "title": get_text(p.get("Name", {}).get("title") or []),
        "lang": (p.get("Language", {}).get("select") or {}).get("name"),
        "stars": p.get("Stars", {}).get("number"),
        "url": p.get("URL", {}).get("url"),
        "date": (p.get("Date", {}).get("date") or {}).get("start"),
        "description": get_text(p.get("Description", {}).get("rich_text") or []),
    }

parsed = [parse(r["properties"]) for r in rows if r["properties"]["URL"]["url"]]

# Domain distribution (description keyword clustering)
def desc_cat(d):
    d = (d or "").lower()
    cats = []
    if any(w in d for w in ["agent", "autonomous", "multi-agent"]): cats.append("agent")
    if any(w in d for w in ["claude", "codex", "opencode", "cursor"]): cats.append("ai-coding")
    if any(w in d for w in ["macos", "menu bar"]): cats.append("macos")
    if any(w in d for w in ["tui", "terminal", "cli"]): cats.append("terminal")
    if any(w in d for w in ["voice", "tts", "stt"]): cats.append("voice")
    if any(w in d for w in ["mcp", "model context"]): cats.append("mcp")
    if any(w in d for w in ["memory", "knowledge graph"]): cats.append("memory/kg")
    return cats

cat_counter = Counter()
for x in parsed:
    for c in desc_cat(x["description"]):
        cat_counter[c] += 1

# Title word frequency (owner/repo signal)
titles = [x["title"] for x in parsed if x["title"]]
words = re.findall(r"[a-z][a-z\-]{2,}", " ".join(titles).lower())
for w, c in Counter(words).most_common(30):
    print(f"  {c:>4}  {w}")
```

## Common pitfalls

| Symptom | Cause | Fix |
|---|---|---|
| `400 validation_error: Provided ID ... is a database, not a page` | Hit `/pages/{id}` for a database | Probe first; on 400 retry with `/databases/{id}` then extract `data_sources[0].id` |
| `404 object_not_found` on `POST /v1/pages` | Used `data_source_id` in `parent.database_id` instead of real `database_id` | See the bundled `notion` skill's TWO IDS table |
| `{"results": []}` from `/data_sources/{id}/query` despite pages existing | API v2025-09-03 query date filter bug | Use `/search` with title fragment as fallback for verification |
| `stars` field returns 0 for all rows | Monitor bot may write description only | Don't trust numeric fields — derive popularity from URL/title frequency instead |
| Pagination infinite loop | Forgot to check `has_more` | Always break on `has_more=false` OR `next_cursor=null` |

## Output template

When the user asks "이 URL에서 영감 찾아봐" or similar, send:

1. **TL;DR**: DB name + total rows + date range
2. **분포 표**: 카테고리/언어/owner 카운트
3. **TOP-N**: 스타/언어/owner별
4. **영감 후보 Tier 1-4**: 사용자 취향 매칭 추천
5. **다음 액션 후보**: 1-2개 pick (with 추천)

Round-trip the recommended pick with the user before doing anything else.
