# GitHub raw README fetch (verified 2026-07-27)

The cleanest case for cron sync — `raw.githubusercontent.com` serves
README files as raw text, no HTML parsing needed. Used for both
`Bangs00/claude-media-control` (Korean README.ko.md) and
`mshumer/Claude-of-Duty` (English README.md) in the same sync.

## Working pattern

```bash
# English README
curl -sL -A "Mozilla/5.0" \
    -o claude-of-duty.md \
    "https://raw.githubusercontent.com/mshumer/Claude-of-Duty/main/README.md"

# Korean README if present (site supports multilingual docs)
curl -sL -A "Mozilla/5.0" \
    -o claude-media-control.md \
    "https://raw.githubusercontent.com/Bangs00/claude-media-control/main/README.ko.md"
```

That's it — the response is plain markdown, no parsing required.

## Multi-language README discovery

Many Korean / Japanese / Chinese open-source projects ship localized
READMEs. The common file names to try, in order:

```
README.md         # English (or default)
README.ko.md      # Korean
README.ja.md      # Japanese
README.zh-CN.md   # Simplified Chinese
README.zh-TW.md   # Traditional Chinese
README.es.md      # Spanish
README.de.md      # German
```

Discovery heuristic: if the source URL in Notion points to a
`README.ko.md` or similar language-specific link, fetch that
directly. If the URL is the GitHub repo root page (e.g.
`https://github.com/X/Y`), use the GitHub API redirect:

```bash
# Get the default branch
BRANCH=$(curl -sL "https://api.github.com/repos/X/Y" | \
    python3 -c "import sys, json; print(json.load(sys.stdin).get('default_branch', 'main'))")
# Then fetch README from that branch
curl -sL -o readme.md "https://raw.githubusercontent.com/X/Y/${BRANCH}/README.md"
```

The API call costs ~1s and ~6kB, but the default branch lookup
prevents broken fetches when a repo uses `master` or `develop`.

## When to prefer repo root over raw README

If the source's `url` in the Notion digest points to a specific
file on GitHub (e.g. `/blob/main/README.ko.md`), prefer the
**raw URL** (`raw.githubusercontent.com/...`) over the GitHub HTML
view — the HTML view wraps everything in navigation chrome.

Conversion rule:
```
https://github.com/{owner}/{repo}/blob/{branch}/{path}
                              ↓
https://raw.githubusercontent.com/{owner}/{repo}/{branch}/{path}
```

## Verifying the file exists

```bash
# Check HTTP status
STATUS=$(curl -sL -A "Mozilla/5.0" \
    -o /dev/null -w "%{http_code}" \
    "https://raw.githubusercontent.com/X/Y/main/README.md")
if [ "$STATUS" != "200" ]; then
    echo "README.md not found (HTTP $STATUS)"
fi
```

If 404, try `master` branch or fall back to `git clone` for a full
checkout (rare, only if the user wants the entire repo).

## What you get back (verified, 2026-07-27)

| Repo | URL | Size | Notes |
|---|---|---|---|
| Bangs00/claude-media-control | `README.ko.md` | 9.4 KB / 172 lines | Korean — plugin docs |
| mshumer/Claude-of-Duty | `README.md` | 7.1 KB / 125 lines | English — game+tooling docs |

Both fetches complete in <2 seconds total and require zero HTML parsing.

## Frontmatter the raw file directly from the README

Since the README often has structured sections (`## Foo`, `## Bar`),
you can grep the first heading to use as the page title:

```bash
TITLE=$(grep -m1 "^# " readme.md | sed 's/^# //')
echo "title: $TITLE"
```

For `Bangs00/claude-media-control/README.ko.md`:
```
# claude-media-control   →  title: "claude-media-control — macOS now-playing을 Claude Code statusline + 자연어로"
```

For `mshumer/Claude-of-Duty/README.md`:
```
# Claude of Duty  →  title: "Claude of Duty — mshumer의 멀티에이전트 오케스트레이션 Three.js FPS"
```

(Append Korean context to the title for the owner's wiki.)

## Common gotcha — `main` vs `master` branch

Modern GitHub repos default to `main`, but legacy or self-hosted
forks may still use `master`. The API call pattern above is the
safest single-fetch.

## Common gotcha — LFS files

If the repo uses Git LFS for binary files (`*.psd`, `*.gif`,
large `*.mp4`), the raw URL serves a **pointer file** (1 KB of
text) instead of the actual binary. For README text this is never
an issue (READMEs are plain text), but be aware if you ever fetch
non-README raw files.
