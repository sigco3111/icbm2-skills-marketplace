# Medium 403 → 저자 소유 미러 복구

## 적용 조건

Notion Dev News 원문이 Medium이고 직접 요청이 403·챌린지 페이지를 반환하지만, 제목상 Wiki 등록 가치가 충분할 때 사용한다.

## 검증된 절차

1. canonical Medium URL, 제목, 저자명, 게시일을 먼저 기록한다.
2. 같은 저자의 **소유 채널**만 찾는다: 개인 도메인, Substack, 공식 뉴스레터·블로그.
3. 아래 중 최소 3개가 맞아야 동일 본문으로 인정한다.
   - 저자 신원이 동일함
   - 제목 또는 slug가 동일·근접함
   - 게시일이 동일하거나 매우 가까움
   - 도입부·섹션 제목·코드 블록이 검색 스니펫과 일치함
   - canonical/backlink 또는 저자 프로필 연결이 있음
4. 전체 본문이 확인되면 raw frontmatter에 canonical과 미러를 함께 남긴다.

```yaml
source_url: https://medium.com/@author/...
mirror_url: https://author.substack.com/p/...
fetch_status: extracted-from-author-mirror
medium_status: 403-cloudflare
```

5. Wiki 페이지의 출처에도 canonical과 저자 미러를 모두 기록한다.
6. 신뢰할 저자 소유 미러가 없거나 전문을 확인하지 못하면 기존 `medium-403` skip 파일 규칙으로 돌아간다.

## 금지

- 무작위 재게시·SEO 스크랩 사이트를 원문 대용으로 쓰지 않는다.
- 검색 결과 스니펫만으로 기사 전체의 논지를 복원하지 않는다.
- 제목만 보고 정의·사례·결론을 만들어내지 않는다.

## 검증 사례

2026-08-03 동기화에서 Gao Dalie의 Medium 글 `FORGET Loop Engineering. Graph Engineering is about THIS`는 직접 요청이 403이었다. 동일 저자의 `gaodalie.substack.com` 미러에서 같은 제목·저자·게시일·섹션·LangGraph 코드가 포함된 전문을 확인해 `fetch_status: extracted-from-author-mirror`로 보관했다.
