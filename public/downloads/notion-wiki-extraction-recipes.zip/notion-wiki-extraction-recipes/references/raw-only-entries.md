# Raw-only wiki entry pattern for cluster sub-items (verified 2026-07-27)

When a Notion digest item contains substantial information BUT does
not warrant its own wiki page (because it doesn't match any schema
type cleanly, because it would be a stub of <20 lines, or because
it duplicates an existing concept's coverage), the right move is
**save a `raw/articles/<slug>-YYYY-MM-DD.md` and reference it inline
in the parent concept page** — but NOT create a phantom wikilink to
a non-existent page.

## Verified case — Opus 5 leaderboard (2026-07-27)

The GeekNews item "Claude Opus 5, Artificial Analysis 지능 리더보드
1위" contained rich data (9-benchmark breakdown, top-5 model list,
pricing tiers), but creating an entity page would have been a stub
(single news cycle, model version, no architecture detail). The
[[claude-5-context-engineering-2026-07]] concept page already covers
the Opus 5 era — so:

- ✅ Save `raw/articles/claude-opus-5-aa-intelligence-leaderboard-2026-07-27.md`
  with full extract (3.0 kB)
- ✅ Inline reference in [[chinese-opensource-llm-race-2026-07]] table:
  ```
  Claude Opus 5 / Fable 5 (Intelligence Index v4.1 1위) | Anthropic |
    61점 / 170 모델 평가 — raw: raw/articles/claude-opus-5-aa-intelligence-leaderboard-2026-07-27.md
  ```
- ❌ NO wikilink like `[[claude-opus-5-aa-leaderboard]]` to a
  non-existent page

The raw file is preserved for future reference (when the user asks
"Anthropic Opus 5 AA 점수 알려줘" → grep raw/articles to find it),
and the parent concept page carries the synthesis.

## When to apply this pattern

For each item in the digest, ask in order:

1. **Does the data belong naturally in an existing concept page?**
   → Embed inline + save raw. (Most common path for cluster sub-items.)
2. **Is the data really an entity (product/company/model/person)?**
   → Create entity page.
3. **Is the data just a stats/timing/comparison block about a transient
   news cycle?**
   → Raw-only.
4. **Does it fail schema quality (single YouTube, vague description)?**
   → Skip (per `llm-wiki` Common skipping rules).

## Why wikilinks to non-existent pages are toxic

A wikilink `[[claude-opus-5-aa-leaderboard]]` in a wiki page **promises**
the next agent (and Obsidian graph view) that a page exists at that
slug. The lint catches these and flags them as "broken wikilink". The
cost of cleanup:

- Lint adds an issues line to `log.md` (more noise to triage)
- Obsidian graph view creates a **phantom node** (purple dead-end)
  that breaks visual connectivity analysis
- Future grep-based indexing returns the slug as a valid entity,
  leading to duplicate analysis if the topic recurs

**Always do pre-write `ls` verification** (documented in `llm-wiki`
`SKILL.md` pitfalls section):

```bash
ls ~/wiki/entities/ ~/wiki/concepts/ ~/wiki/comparisons/ ~/wiki/queries/
```

If no slug matches, use plain text or a `raw/articles/<file>.md`
reference in backticks or code spans, NOT a `[[wikilink]]`.

## Raw file frontmatter (verified)

```yaml
---
title: "Claude Opus 5, Artificial Analysis 지능 리더보드 1위 — 170개 모델 평가"
url: https://news.hada.io/topic?id=31807
date: 2026-07-27
source: GeekNews 31807
fetch_status: extracted
fetched_via: curl + schema.org JSON-LD articleBody
extractor: GeekNews (hada.io) JSON-LD pattern
---
```

The `url` + `source` fields give the file a navigable identity even
without a corresponding wiki page. Future lint or query agents can
find it via `search_files("GeekNews 31807" path="~/wiki/raw/articles/")`.

## Comparison table — three dispositions

| Data shape | Action | Wikilink? | Raw saved? |
|---|---|---|---|
| New product/concept with stable identity | New wiki page | ✅ target page | ✅ |
| Update info for existing entity | Patch entity page | ✅ (existing) | ✅ |
| Cluster sub-item, no stable identity, transient | **Raw-only + inline reference in parent concept** | ❌ phantom wikilink to non-existent | ✅ |
| Skip-worthy (YouTube, Medium 403, vague) | Skip file | ❌ | ✅ skip variant |

The 3rd row is the rare-but-important case the pattern covers.
