# 354차 세션 노트 (2026-08-08 07:01 KST) — check-session 3중 신호 검증 + Python 인터프리터 함정

## 증상 1: Python 인터프리터 호환성 에러

`python3 ~/.hermes/scripts/tistory_publisher.py --check-session` (cron이 그대로 호출)을 실행하면:

```
File ".../urllib3/_base_connection.py", line 10, in <module>
    bytes, typing.IO[typing.Any], typing.Iterable[bytes | str], str
TypeError: unsupported operand type(s) for |: 'type' and 'type'
```

- `/usr/bin/python3` = Python 3.9.6
- 시스템 urllib3 = 2.7.0 (Python 3.10+ union syntax `bytes | str` 사용)
- import 단계에서 즉시 실패 → `requests` import 불가 → 어떤 Tistory 호출도 불가

해결: `~/.hermes/hermes-agent/venv/bin/python3` (3.11.15) 직접 호출.

## 증상 2: check_session false-negative

venv로 재시도 시 출력:

```
❌ 연결 오류: Expecting value: line 2 column 2 (char 2)
```

스크립트 소스 (`scripts/tistory_publisher.py:101-118`):

```python
r = requests.get(f"{POSTS_ENDPOINT}?category=-3&page=1", cookies=cookies, ...)
if r.status_code == 200 and r.json().get("totalCount") is not None:
    print("✅ 세션 유효")
else:
    print(f"� 세션 만료 (status: {r.status_code})", file=sys.stderr)
except Exception as e:
    print(f"❌ 연결 오류: {e}", file=sys.stderr)
```

직접 호출로 확인한 진짜 응답:

```
status: 200
url:    https://www.tistory.com/auth/login?redirectUrl=https%3A%2F%2Fsigco.tistory.com%2Fmanage%2Fposts.json
hdrs:   Set-Cookie: TOP-XSRF-TOKEN=...; ...
        TSSESSION=""; Domain=tistory.com; Expires=Thu, 01-Jan-1970 00:00:10 GMT; Path=/
        OLD_TSSESSION=""; Domain=tistory.com; Expires=Thu, 01-Jan-1970 00:00:10 GMT; Path=/
        TSSESSION_KEEP=""; Domain=tistory.com; Expires=Thu, 01-Jan-1970 00:00:10 GMT; Path=/
        Content-Type: text/html;charset=UTF-8
body:   <!doctype html>...<meta property="og:image" content="//t1.daumcdn.net/tistory_admin/static/images/openGraph/tistoryOpengraph.png">
```

→ HTTP 200 + HTML 로그인 페이지. 서버가 **명시적으로 TSSESSION을 1970-01-01로 만료**시키는 Set-Cookie 헤더까지 동봉.

## 3중 검증 패턴 (cron 자동화 적용 권장)

`check_session` 출력이 `"연결 오류"`이면 진짜 네트워크 오류로 오인하지 말고 다음 3가지 동시 확인:

1. **`Set-Cookie`에 `Expires=Thu, 01-Jan-1970`**: 서버가 강제로 무효화한 신호. 이게 있으면 무조건 만료.
2. **최종 URL이 `tistory.com/auth/login?redirectUrl=...`**: 리다이렉트 체인의 종착점.
3. **HTML og:image가 `tistory_admin/static/images/openGraph/tistoryOpengraph.png`**: Tistory 메인 페이지 HTML이 들어온 것.

세 가지 모두 확인되면 = 만료 확정. cron 알림 발송 OK.

## 개선 아이디어 (후속 patch 후보)

`tistory_publisher.py:check_session`을 3가지 분기로 리팩토링:

```python
def check_session(cookies):
    try:
        r = requests.get(...)
        ct = r.headers.get('Content-Type', '')
        if 'application/json' not in ct:
            # 만료 신호: HTML 리다이렉트 응답
            if 'Expires=Thu, 01-Jan-1970' in r.headers.get('Set-Cookie', '') or \
               '/auth/login' in r.url:
                print("❌ 세션 만료 (서버 응답: HTML 로그인 페이지 + TSSESSION 무효화)")
                return False
            print(f"�️ 예상치 못한 Content-Type: {ct}")
            return False
        if r.status_code == 200 and r.json().get("totalCount") is not None:
            print(f"✅ 세션 유효 (총 {r.json()['totalCount']}개 글)")
            return True
        print(f"❌ 세션 만료 (status: {r.status_code})")
        return False
    except requests.exceptions.ConnectionError as e:
        print(f"❌ 네트워크 오류: {e}")
        return False
    except Exception as e:
        print(f"❌ 알 수 없는 오류: {e}")
        return False
```

## 354차 시점 쿠키 상태

- 마지막 갱신: 2026-08-05 07:25 KST (353차)
- 354차 감지: 2026-08-08 07:01 KST
- 만료까지 약 **2일 23시간** — 48시간 가설 일치
- 5개 쿠키 모두 신선값이었으나 TSSESSION만 서버 무효화됨
