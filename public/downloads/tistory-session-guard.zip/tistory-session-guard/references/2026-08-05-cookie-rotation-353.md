# 2026-08-05 — 353차 쿠키 교체 + 48h 만료 사이클 확인

## 트리거 조건
- 세션 리셋 직후(DM 첫 메시지) 사용자가 5개 쿠키를 그대로 보냄. 파일에 즉시 적용하기 전 의심성 검증 → clarification 비용 발생 가능.
- `tistory_publisher.py`의 `COOKIE_NAMES`에 `REACTION_GUEST`가 이미 포함되어 있어 의심 근거 자체가 잘못된 것이 확인됨.

## 학습 1 — `REACTION_GUEST`는 정식 Tistory 쿠키
- `REACTION_GUEST`는 Tistory 측 `반응(좋아요 등)` 게스트 식별자로, manage 세션에서 사용되는 정상 쿠키임. 324차(8/3)에서도 동일 키 사용, `tistory_publisher.py` `COOKIE_NAMES`에 명시.
- 미래 에이전트가 "guestbook 같은 이름이다"는 이유로 의심하지 말 것. 의심이 들면:
  1. `grep REACTION_GUEST ~/.hermes/scripts/tistory_publisher.py` (canonical)
  2. `git -C ~/.hermes log --all -p -- secrets/tistory.env | grep REACTION_GUEST` (역사)
  둘 다 나오면 정식 쿠키 확정.

## 학습 2 — 공개 `/apis/*` 엔드포인트는 cookie-only 검증에 부적합
- 4회 모두 `HTTP 404` + Next.js HTML 응답을 받음 → 표면적으로 "쿠키 깨짐" 처럼 보이지만 실제로는 OAuth `access_token`이 비어 있어서의 404.
- 정답은 `/manage/posts.json` (내부 manage UI JSON API). 검증 신호는 동일하게 `status=200` + `content-type: application/json`.
- 향후 쿠키 검증은 무조건 `/manage/posts.json` 또는 `/manage/category.json`만 찌를 것.

## 학습 3 — `tistory_guard.py`가 정형 검증 도구
- 경로: `/Users/mac/tistory_guard.py`
- 호출: `set -a; source ~/.hermes/secrets/tistory.env; set +a; unset TISTORY_BLOG_NAME TISTORY_BLOG_ID TISTORY_BLOG_URL; python3 /Users/mac/tistory_guard.py`
- 출력 (353차 실측):
  ```
  cookies=5
  status=200
  ct=application/json;charset=UTF-8
  loc=
  first_id=1180
  first_title=Bonsai - Jane Street의 UI 라이브러리...
  GUARD=VALID
  ```
- `TISTORY_BLOG_*` 3개 env를 unset해야 쿠키 5개만 남음 (`os.environ` prefix strip 기준).

## 학습 4 — 48h 만료 사이클 가설 → 사실로 확인
- 322차 회복(7/26) → 324차 교체(8/3, 8일) → **353차 교체(8/5, 48h)**. 48시간 만에 재만료가 두 번째로 관측됨.
- 이전 가설(8/4 353차 "의심")이 8/5 아침 step[5] ❌로 확정. step[7] categories 빈 결과 + `Expecting value` JSON 에러 동반.
- cron `verify-tistory-cookie.sh` 1시간 간격 운영 + 사용자 아침 raw probe 병행이 조기 감지의 핵심.
- 다음 권고: cron 간격 1시간 → 30분 단축 (사용자 미응답으로 보류).

## 새 env 작성 패턴 (정형)
```bash
# 1. 백업 (선택이지만 정책상 자동 수행됨)
# 2. 메타데이터 헤더 갱신 — 교체 시각, 차수, 만료 추이 표
# 3. 5개 쿠키 변수
# 4. BLOG_NAME/ID/URL 보존
# 5. chmod 600 (기존 권한 -rw------- 유지 확인)
```

## 검증 후속 단계
1. `tistory_guard.py` → `GUARD=VALID`
2. `/manage/category.json` → 카테고리 5개 반환 (특히 step[5])
3. `/manage/posts.json?category=-3&page=2` → 최근 15건, 첫 ID = 직전 세션 마지막 ID + 1
4. 모두 200이면 다음 publish 진행 가능.

## 안티패턴 (하지 말 것)
- ❌ `REACTION_GUEST` 보고 phishing 의심 → 사용자 clarification 비용 발생
- ❌ `/apis/category/list?access_token=` 시도 → 404로 잘못된 신호
- ❌ `/tmp/*.py` 절대경로 + 가드 우회 복잡 호출 → escape hatch B/C 먼저 검토
- ❌ 메타데이터 헤더 갱신 누락 → 다음 세션에서 만료 추적 표 단절
