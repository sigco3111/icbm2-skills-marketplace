---
name: icbm2-daily-workspace-cleanup
description: ICBM2 자동화 파이프라인이 남기는 임시 산출물을 매일 청소하는 크론 잡. Manim 임시 디렉토리, 블로그 포스팅 산출물, 팟캐스트 mp3, YouTube/Shorts 빈 디렉토리, 7일 이상 된 크론 출력 로그를 안전하게 정리. "임시 산출물 정리", "tmp 청소", "manim_* 정리", "/tmp blog_post.html 정리", "podcast mp3 24시간 정리" 같은 요청에 발동.
tags: [automation, cron, cleanup, tmp, icbm2, maintenance]
---

# ICBM2 일일 임시 산출물 정리

## 트리거

- **자동:** `hermes cron` (매일 일정 시각)
- **수동:** 사용자가 "임시 산출물 정리" / "tmp 청소" / "manim_* 정리" / "크론 출력 로그 정리" 요청

## ⚠️ 안전 원칙 (전 단계 공통)

1. **`rm -rf` 사용 금지** — `find ... -delete` 또는 개별 `rm`만 허용
2. **삭제 전 `find` dry-run** — 매치 결과를 먼저 보고, 매치 0건이면 no-op
3. **매치 0건이어도 정상 완료** — "정리할 게 없다"는 유효한 결과
4. **`execute_code`는 cron 모드에서 BLOCKED** — 반드시 `terminal` + `find`/`rm` 명령으로 처리
5. **cron 모드에서 macOS `/tmp`은 `/private/tmp`으로 자동 해석됨** — `find /tmp/...` 그대로 사용 가능
6. **대상 경로 매치 시 `find -print`로 먼저 한 번 출력** — 다음 단계에서 `find ... -delete` 또는 `find ... -exec rm {} +`

## 카테고리 (5개 섹션)

### 1️⃣ Manim 임시 파일

```bash
# (a) ~/Desktop/ 하위 manim_* 디렉토리
find ~/Desktop -maxdepth 1 -type d -name 'manim_*' -print

# (b) ~/Desktop/ 하위 media/ 경로 중 manim_* 매치
find ~/Desktop -maxdepth 4 -type d -path '*manim*' -print
```

대상 발견 시 `-delete`로 삭제 (디렉토리이므로 `-prune -exec rm -rf {} +`도 OK, 단 dry-run 후).

### 2️⃣ 블로그 포스팅 산출물

```bash
# glob 매칭 후 개별 확인
for f in /tmp/blog_post.html /tmp/blog_content.txt /tmp/blog_final_*.json /tmp/blog_seo_*.json; do
  [ -f "$f" ] && echo "MATCH: $f"
done
```

매치 시 `rm "$f"` (개별 삭제).

### 3️⃣ Manim/팟캐스트 산출물

```bash
# (a) 디렉토리
find /tmp -maxdepth 1 \( -name 'manim_frames' -o -name 'manim_podcast*' -o -name 'manim_output*' \) -type d -print
[ -e /tmp/podcast_manim_output ] && echo "MATCH: /tmp/podcast_manim_output"

# (b) 로그 파일
[ -e /tmp/podcast_manim_run.log ] && echo "MATCH: /tmp/podcast_manim_run.log"

# (c) 24시간(1440분) 이상 된 podcast_*.mp3
find /tmp -maxdepth 1 -name 'podcast_*.mp3' -mmin +1440 -print
```

매치 시:
- 디렉토리: `find ... -type d ... -prune -exec rm -rf {} +`
- 파일: 개별 `rm`

### 4️⃣ YouTube/Shorts 임시 파일

```bash
# (a) 빈 shorts_* 디렉토리만 (비어있지 않은 건 보존)
find /tmp -maxdepth 1 -type d -name 'shorts_*' -empty -print

# (b) youtube_upload 디렉토리
[ -d /tmp/youtube_upload ] && echo "MATCH: /tmp/youtube_upload"
```

**Pitfall:** `-empty` 플래그 필수. `-type d -name 'shorts_*'`만 쓰면 진행중인 작업 디렉토리까지 날아감.

### 5️⃣ 오래된 크론 출력 로그 (7일+)

```bash
# .log / .txt 확장자 한정. macOS BSD find의 -mtime 반올림 함정 때문에
# "+6"을 사용해야 wall-clock ≥7일 경과 파일을 정확히 매치한다.
find ~/.hermes/cron/output -type f \( -name '*.log' -o -name '*.txt' \) -mtime +6 -print
```

매치 시 `find ... -delete`.

**주의:** `~/.hermes/cron/output/`은 ICBM2 cron job별 출력이 해시 디렉토리 아래 `.md`로 저장되는 것이 **현재 표준**(2026-06-11 확인). `.log`/`.txt` 7일+ 정리 대상이 0건인 날이 정상. 만약 `.md` 7일+ 정리가 필요해지면 별도 정책 결정 후 적용 — 절대 임의로 `.md`까지 확장하지 말 것.

## 보고 형식

각 섹션별로 **매치 0건이라도** 아래 항목을 보고:

```
1️⃣ Manim 임시 파일
   - manim_* 디렉토리: N건
   - media/manim*: N건
2️⃣ 블로그 포스팅 산출물
   - blog_post.html / blog_content.txt / blog_final_*.json / blog_seo_*.json: N건
3️⃣ Manim/팟캐스트 산출물
   - manim_frames, manim_podcast*, manim_output*, podcast_manim_output: N건
   - podcast_manim_run.log: N건
   - podcast_*.mp3 (24h+): N건
4️⃣ YouTube/Shorts 임시 파일
   - shorts_* (빈 디렉토리): N건
   - youtube_upload: N건
5️⃣ 오래된 크론 출력 로그 (7일+ .log/.txt)
   - cron/output: N건

총 삭제: X건 (no-op이 정상일 수 있음)
```

## Pitfall

- **`-mtime +7`은 mtime 기준** — ctime/atime과 다름. 파일 내용 수정 시 mtime 갱신되므로 정확히 7일+ 되는 시점이 매일 달라짐
- **`-mmin +1440`은 분 단위** — 1440분 = 24시간. 시간 단위 `-mtime +1`은 calendar day 경계를 타서 부정확할 수 있음
- **macOS `/tmp` 심볼릭 링크** — `/tmp` → `/private/tmp`. `find /tmp/...` 정상 작동, 출력은 `/private/tmp/...`으로 나올 수 있음
- **`-prune` vs `-delete`** — 디렉토리 통째 삭제 시 `-prune -exec rm -rf {} +` 권장, 단순 파일은 `-delete`로 충분
- **podcast_*.mp3 정책** — 24시간+ 만 삭제. 진행중인 podcast 작업 보호가 핵심
- **cron output 정책 비대칭** — `.log/.txt`는 7일+, `.md`는 보존 (별도 정책 결정 전까지). 매치 0건이어도 정상
- **`find ... -print -delete` 체이닝의 exit code 함정 (2026-07-05 발견)** — `find ~/Desktop/media ...`가 디렉토리 부재로 exit 1을 반환하면 `&&`로 연결된 후속 명령이 모두 스킵됨. **각 카테고리는 독립된 `terminal` 호출로 분리**하거나 `|| true`를 체인 끝에 붙여 exit code를 무력화해야 함. 안전 원칙 #2(매치 0건이어도 정상)와 직접 연결되는 운영 함정.
- **`-mtime +7` macOS BSD 반올림 함정 (2026-07-11 발견)** — BSD `find`는 fractional day를 **올림**한다. 즉 정확히 7.0일~7.99일 경과한 파일은 mtime이 7로 반올림되어 `-mtime +7`에 매치되지 않는다 (≥8.0일 경과해야 매치). "7일 이상" 한국어 표현(≥7.0일 wall-clock)을 충족하는 파일을 놓치게 된다. **실무 권장:** "7일 이상" 매칭이 필요하면 `-mtime +6`을 쓰거나, `find ... -mtime +6 -mtime -8`처럼 mtime 범위를 명시. 검증 사례: `b26b0579a45f_20260704_090335.txt` (7.20일 경과) → `-mtime +7` 0건, `-mtime +6` 1건. **절대 `-mtime +7`만으로 "7일 이상"을 보장하지 말 것.** Cron output 정리는 "≥7일 wall-clock"이 의도이므로 `-mtime +6` 사용을 기본값으로 권장.

## 의존성

- **선행:** 없음 (단독 실행 가능)
- **후행:** `nightly-maintenance-workflow` (심야 03:30), `memory-hygiene` (메모리/리포트)
- **별도:** 본 스킬은 **작업 산출물** 청소, 위 두 스킬은 **자동화 시스템** 청소

## 환경 노트

- 호스트: macOS 26.5.1 (Darwin) — 2026-07-05 확인
- 사용자: hjshin (세션 컨텍스트는 "희정님"으로 표기되나 동일 인물)
- 검증 시각:
  - 2026-06-11 (목) — 첫 실행, 전 카테고리 no-op
  - 2026-06-12 (금) — 두 번째 실행, 전 카테고리 no-op
  - 2026-07-05 (일) — 세 번째 실행, 전 카테고리 no-op
  - 2026-07-11 (토) — 네 번째 실행, **첫 실제 삭제** (cron output .txt 1건)
- **no-op 3회 연속 + 1회 실제 삭제** → 두 패턴 모두 정상. 매니페스트 누락은 드물지만 7일+ .log/.txt는 누적 속도가 느려서 간헐적 발생
- `~/.hermes/cron/output/`의 `.md` 파일은 해시 디렉토리(`075bec58df7b/`, `0f893ba14797/` 등) 내부에 저장. 루트 레벨에 `.txt` 파일이 가끔 flat으로 나타남 (예: `b26b0579a45f_20260704_090335.txt`, `b1bca63a117a_20260709_201625.txt`). **루트 레벨 .txt는 어떤 주기로 1건씩 생성되는 경향** — 다음 정리 시각 예측에 활용 가능

## References

- `references/2026-06-11-first-no-op-run.md` — 첫 실행 결과 (전 카테고리 0건), 환경 점검 기록
- `references/2026-06-12-second-no-op-run.md` — 두 번째 no-op 실행, .md 7일 임계 도달 시점(06-13~14) 예측, `execute_code` cron 차단 재확인
- `references/2026-07-05-third-no-op-run.md` — 세 번째 no-op 실행, macOS 26.5.1 환경 확인, `find ... -print -delete` 체이닝 exit code 주의 패턴 기록
- `references/2026-07-11-fourth-real-delete-run.md` — 네 번째 실행, **첫 실제 삭제** (cron output .txt 1건), `-mtime +7` BSD 반올림 함정 발견 및 `-mtime +6` 권장으로 스킬 본체 패치
