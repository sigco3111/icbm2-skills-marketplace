#!/usr/bin/env python3
"""verify-shadow-component.py — Playwright scaffold for shadow-DOM Web Components.

Usage:
  python3 scripts/verify-shadow-component.py \
    --url http://127.0.0.1:8765/ \
    --selector "bracket-view#worldcup" \
    --out /tmp/screenshots

Or edit the defaults at the top and run with no args. Designed for Web Components
that use shadow DOM + SVG overlays + scroll-snap horizontal pages.

What it asserts (one line each, all-or-nothing at the end):
  - page loaded, no pageerror
  - shadow DOM upgraded (waits for a sentinel selector inside .shadowRoot)
  - all tabs/pages present, expected count matches
  - desktop + mobile viewports both render the same number of cards
  - clicking each tab keeps window.scrollY constant (no vertical jump)
  - clicking each tab advances trackScrollLeft
  - dispatchEvent on SVG <g> works (the pattern that bypasses pointer-events races)

The script exits 0 on PASS, non-zero on FAIL. Designed to be safe to re-run.
"""

import argparse
import sys
import time
from pathlib import Path

from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeoutError

# ── Defaults — edit or pass via flags ──────────────────────────────────────────
DEFAULT_URL      = "http://127.0.0.1:8765/"
DEFAULT_SELECTOR = "bracket-view#worldcup"
DEFAULT_OUT      = "/tmp/screenshots"
DEFAULT_SHADOW_SENTINEL = ".bv-track"   # wait until this exists inside shadowRoot

VIEWPORTS = [
    ("desktop", 1280, 1100, 1.0),
    ("mobile",  390,  844, 2.0),
]


def banner(s: str) -> None:
    print(f"\n=== {s} ===")


def wait_shadow_upgraded(page, host_selector: str, sentinel: str, timeout_ms: int = 8000) -> None:
    """Wait until the Web Component's shadow DOM contains a known element."""
    page.wait_for_function(
        f"document.querySelector({host_selector!r})?.shadowRoot?.querySelector({sentinel!r})",
        timeout=timeout_ms,
    )


def run(url: str, host_selector: str, out_dir: str, shadow_sentinel: str) -> int:
    Path(out_dir).mkdir(parents=True, exist_ok=True)
    failures: list[str] = []
    page_errors: list[str] = []

    with sync_playwright() as p:
        browser = p.chromium.launch()

        for vp_name, vw, vh, dpr in VIEWPORTS:
            banner(f"{vp_name} viewport {vw}x{vh}@{dpr}x")
            ctx = browser.new_context(viewport={"width": vw, "height": vh},
                                       device_scale_factor=dpr)
            page = ctx.new_page()
            page.on("pageerror", lambda e: page_errors.append(f"[{vp_name}] {e}"))

            try:
                page.goto(url, wait_until="networkidle", timeout=15000)
                wait_shadow_upgraded(page, host_selector, shadow_sentinel)
                page.wait_for_timeout(1500)
            except PlaywrightTimeoutError as e:
                failures.append(f"[{vp_name}] page load / shadow upgrade timed out: {e}")
                ctx.close()
                continue

            # ── A. structural read-back ────────────────────────────────────
            banner(f"[{vp_name}] structure")
            info = page.evaluate("""(sel) => {
              const host = document.querySelector(sel);
              if (!host?.shadowRoot) return {ok:false, reason:'no shadowRoot'};
              const root = host.shadowRoot;
              return {
                pages:       root.querySelectorAll('.bv-page').length,
                tabs:        root.querySelectorAll('.bv-tab').length,
                tabLabels:   [...root.querySelectorAll('.bv-tab')].map(t=>t.textContent.trim()),
                cardsPage0:  root.querySelector('.bv-page[data-page="0"] .bv-col-from')
                                 ?.querySelectorAll('.bv-card').length || 0,
                connectors:  root.querySelector('.bv-page[data-page="0"]')
                                 ?.querySelectorAll('.bv-connector').length || 0,
              };
            }""", host_selector)
            print(info)
            if info.get("pages", 0) < 1:
                failures.append(f"[{vp_name}] no .bv-page found in shadow DOM")
            if info.get("tabs", 0) != info.get("pages", 0):
                failures.append(f"[{vp_name}] tab count ({info.get('tabs')}) != page count ({info.get('pages')})")

            page.screenshot(path=f"{out_dir}/{vp_name}-page0.png", full_page=False)

            # ── B. tab clicks: scrollLeft advances, scrollTop stays 0 ─────
            banner(f"[{vp_name}] tab clicks (scroll geometry)")
            for tab_i in range(info.get("pages", 0)):
                before = page.evaluate("""(sel) => {
                  const t = document.querySelector(sel).shadowRoot.querySelector('.bv-track');
                  return {x: t.scrollLeft, y: t.scrollTop};
                }""", host_selector)
                page.evaluate("""(args) => {
                  const root = document.querySelector(args.sel).shadowRoot;
                  root.querySelector(`.bv-tab[data-page="${args.i}"]`).click();
                }""", {"sel": host_selector, "i": tab_i})
                page.wait_for_timeout(800)
                after = page.evaluate("""(sel) => {
                  const t = document.querySelector(sel).shadowRoot.querySelector('.bv-track');
                  return {x: t.scrollLeft, y: t.scrollTop};
                }""", host_selector)

                if after["y"] != before["y"]:
                    failures.append(
                        f"[{vp_name}] tab[{tab_i}] vertical scroll moved: {before['y']} → {after['y']}"
                    )
                if after["x"] == before["x"] and tab_i > 0:
                    failures.append(
                        f"[{vp_name}] tab[{tab_i}] horizontal scroll did not advance (stuck at {before['x']})"
                    )
                else:
                    print(f"  tab[{tab_i}]: scrollLeft {before['x']} → {after['x']} (Δy={after['y']-before['y']})")
                page.screenshot(path=f"{out_dir}/{vp_name}-tab{tab_i}.png", full_page=False)

            # ── C. SVG click via dispatchEvent (bypass pointer-events race) ──
            banner(f"[{vp_name}] SVG click via dispatchEvent")
            try:
                page.evaluate("""(sel) => {
                  const root = document.querySelector(sel).shadowRoot;
                  const card = root.querySelector('.bv-page[data-page="0"] .bv-card');
                  if (!card) return;
                  card.dispatchEvent(new MouseEvent('click', {bubbles: true, composed: true}));
                }""", host_selector)
                page.wait_for_timeout(400)
                print("  dispatchEvent on .bv-card: ok (no exception)")
            except Exception as e:
                failures.append(f"[{vp_name}] dispatchEvent on .bv-card raised: {e}")

            ctx.close()

        browser.close()

    banner("SUMMARY")
    if page_errors:
        print(f"page errors ({len(page_errors)}):")
        for e in page_errors:
            print(f"  - {e}")
    if failures:
        print(f"FAILURES ({len(failures)}):")
        for f in failures:
            print(f"  ✗ {f}")
        return 1
    if page_errors:
        return 2
    print(f"PASS · {len(VIEWPORTS)} viewports · {len(page_errors)} page errors · 0 failures")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--url",      default=DEFAULT_URL)
    ap.add_argument("--selector", default=DEFAULT_SELECTOR)
    ap.add_argument("--out",      default=DEFAULT_OUT)
    ap.add_argument("--sentinel", default=DEFAULT_SHADOW_SENTINEL,
                    help="CSS selector inside the shadow root that signals upgrade")
    args = ap.parse_args()
    return run(args.url, args.selector, args.out, args.sentinel)


if __name__ == "__main__":
    sys.exit(main())
