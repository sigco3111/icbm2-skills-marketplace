# Korean (ko-KR) i18n for Web Components

Web components that localize into Korean need to handle three classes of
text generation rules that don't exist in English:

1. **Josa (조사) auto-selection** — `을/를`, `이/가`, `은/는`, `으로/로`
2. **Date/time formatting** — 오전/오후, 요일 suffixes
3. **Honorific plural markers** — `명/명들/들`

This reference covers the patterns verified inside `<bracket-view>`'s
paper-fold mode. Each pattern is one small JS helper that you keep in
the component (or in a shared i18n module), not in the render path.

## 1. Josa — `으로`/`로`, `을`/`를`, `이`/`가`, `은`/`는`

Korean particles depend on whether the preceding syllable has a 받침
(final consonant). Manual `if (word.endsWith('강')) josa = '으로'` is
fragile. Use the Unicode-level check:

```js
const hasJongSung = (word) => {
  const code = word.charCodeAt(word.length - 1);
  return code >= 0xAC00 && code <= 0xD7A3 && (code - 0xAC00) % 28 > 0;
};

const josa = (word, type) => {
  const jongsong = hasJongSung(word);
  switch (type) {
    case '을를':  return jongsong ? '을' : '를';
    case '이가':   return jongsong ? '이' : '가';
    case '은는':  return jongsong ? '은' : '는';
    case '으로로': return jongsong ? '으로' : '로';
  }
};

// Usage
const label = `승자는 ${nextRound}${josa(nextRound, '으로로')} 진출`;
// 8강 → "승자는 8강으로 진출"
// 결승 → "승자는 결승으로 진출" (끝 '승' 받침 없음)
```

Why `(code - 0xAC00) % 28 > 0` works:
- `0xAC00` is the start of the Hangul syllables block (가)
- `0xD7A3` is the end (힣)
- Every Hangul syllable has `(initial * 588) + (vowel * 28) + jongSung` as its code offset
- `offset % 28 == 0` means no 받침 (e.g. 가=0, 나=4, 다=8… actually each initial maps differently, but the `% 28 > 0` test on the final syllable's offset reliably identifies 받침 presence regardless of vowel)

This works for ALL Hangul blocks including archaic ones (CJK Compatibility block) — same offset math. For Latin/Chinese characters (한자), the function returns false (no 받침 concept), which gives the unmarked particle form. Good enough for the common case where your labels are already in Hangul.

## 2. Round-name mapping

For a tournament bracket:

```
totalRounds=2  → 결승
totalRounds=3  → 4강, 결승
totalRounds=4  → 8강, 4강, 결승
totalRounds=5  → 16강, 8강, 4강, 결승
totalRounds=6  → 32강, 16강, 8강, 4강, 결승
```

Use a depth-from-final formula instead of a fixed-length array indexing:

```js
const KO_LABELS = ['결승', '4강', '8강', '16강', '32강', '64강'];

function roundLabel(roundIdx, totalRounds) {
  if (totalRounds < 2 || totalRounds > KO_LABELS.length) {
    // Fallback to English when the depth is unusual
    const EN = ['Final', 'Semifinals', 'Quarterfinals', 'Round of 16', 'Round of 32', 'Round of 64'];
    const startIdx = EN.length - (totalRounds - 1);
    return EN[startIdx - roundIdx] || `Round ${roundIdx + 1}`;
  }
  const startIdx = KO_LABELS.length - (totalRounds - 1); // first round's label index
  const idx = startIdx - roundIdx;
  return KO_LABELS[idx] || `${roundIdx}`;
}
```

The mistake to avoid: using `labels[offset + roundIdx]` where `offset = MAX - totalRounds`. This puts the LAST round's label at the FIRST round's index, inverting tab order.

## 3. Date + time formatting

```js
function formatKoreanDate(date) {
  const days = ['일', '월', '화', '수', '목', '금', '토'];
  const m = date.getMonth() + 1;
  const d = date.getDate();
  const day = days[date.getDay()];
  const hh = date.getHours();
  const mm = String(date.getMinutes()).padStart(2, '0');
  const ampm = hh < 12 ? '오전' : '오후';
  const h12 = hh % 12 || 12;
  return `${m}.${d} (${day}) ${ampm} ${h12}:${mm}`;
}
// → "7.11 (금) 오전 4:00"
```

## 4. Status badge labels

Match the user's mental model, not the data enum:

```js
const STATUS_LABEL = {
  scheduled:  '예정',
  live:       '진행 중',
  fulltime:   '풀타임',
  completed:  '풀타임',      // ← tolerate both
  postponed:  '연기',
  cancelled:  '취소',
};

function statusLabelOf(match) {
  const status = match.status || (match.winner ? 'fulltime' : 'scheduled');
  return STATUS_LABEL[status] || status;
}
```

## 5. Toolbar/buttons common set

Keep one constant object with all UI verbs:

```js
const KO_BUTTONS = {
  reset:        '초기화',
  random:       '랜덤',
  clearFocus:   '포커스 해제',
  expand:       '펼치기',
  collapse:     '접기',
  empty:        '팀이 없습니다',
  pageSub: (next) => `승자는 ${next}${josa(next, '으로로')} 진출`,
  championSub:  '우승자 결정',
};
```

## 6. Verification

When the component supports ko-KR, the Playwright verification should
also assert that the rendered text matches expectations:

```python
labels = page.evaluate("[...shadow.querySelectorAll('.bv-tab')].map(t=>t.textContent.trim())")
assert labels == ['16강', '8강', '4강', '결승'], f"got {labels}"

subs = page.evaluate("[...shadow.querySelectorAll('.bv-page-sub')].map(s=>s.textContent.trim())")
assert '8강으로 진출' in subs[0]
assert '4강으로 진출' in subs[1]

buttons = page.evaluate("[...shadow.querySelectorAll('.bv-btn')].map(b=>b.textContent.trim())")
assert '초기화' in buttons
assert '랜덤' in buttons
```

If any of these fail, the i18n logic is regressed (the user won't notice
immediately because the missing label falls through to the English
fallback, which is exactly the bug pattern that the previous session
hit).
