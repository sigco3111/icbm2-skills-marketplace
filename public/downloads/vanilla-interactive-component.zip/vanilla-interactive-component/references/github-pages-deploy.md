# GitHub Pages legacy (no-build) deploy

For static Web Components with no build step, the simplest path is **GitHub Pages in legacy mode** (serves the `/` of `main` directly).

## One-shot setup

```bash
gh repo create owner/repo \
  --public \
  --description "..." \
  --source=. \
  --remote=origin \
  --push

gh api -X POST repos/owner/repo/pages \
  -f source[branch]=main \
  -f source[path]=/ \
  -H "Accept: application/vnd.github+json"

# poll the build
sleep 35 && gh api repos/owner/repo/pages/builds/latest --jq '.status'   # → "built"
```

`source[path]=/` means: serve the repo root, not a `docs/` folder.

## Required header

Always pass `-H "Accept: application/vnd.github+json"`. Without it, the API returns 404 ("no permission") even though auth is fine.

## Live URL

```
https://<owner>.github.io/<repo>/
```

GitHub Pages returns `application/javascript` for `.js` files (so ES modules work). 404 path: a typo in the repo name returns a 404 *Page*, not a JSON 404.

## Build polling

Legacy mode "build" is essentially a publish step — Pages compiles the legacy mode manifest. It usually takes 30–60 seconds after a push.

```bash
gh api repos/owner/repo/pages/builds/latest --jq '.status, .committed_at, .duration'
```

Common statuses: `building`, `built`, `errored`.

## Redeploy on push

After `git push origin main`, wait ~35s then re-poll. There's no Vercel-style cache to bust — Pages caches for 10 minutes by default (`cache-control: max-age=600` in `curl -I` output).

## When NOT to use this

- Component has a build step (Vite, TypeScript, anything that needs bundling) → use Vercel/Netlify with a build command
- Repo is private and you want it public → flip visibility first (`gh repo edit --visibility public`)
- You need custom domain → set `custom_404` flag and configure CNAME; not covered here

## Troubleshooting

| Symptom | Likely cause |
|---|---|
| 404 on URL after enable | `source[path]` set wrong, or Pages didn't finish — re-poll build status |
| JS MIME error in console | You probably hit a CDN/proxy cache. Wait or check `Content-Type` directly. |
| Build status `errored` | Check `gh api .../pages/builds/latest \| jq .error.message` — usually a Pages config conflict (e.g. existing CNAME) |
| HTTPS not enforcing | Pass `--https-enforced` or set via repo settings |

## Verified pattern (production usage)

`sigco3111/bracket-view` — live at https://sigco3111.github.io/bracket-view/. Push → 35s → "built" → live. Component is a 49KB vanilla JS Custom Element; embedded via `<script type="module" src="...">` anywhere.
