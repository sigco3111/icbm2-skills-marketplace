---
name: vanilla-interactive-component
description: Build reusable, interactive browser Web Components (Custom Elements) from visual references — vanilla JS, zero deps, zero build. Patterns for shadow DOM, scroll-snap horizontal pages with tab sync, SVG overlays in CSS grid trenches, and pixel-aligned connectors. Includes GitHub Pages legacy (no-build) deploy and Playwright verification scaffolds.
---

# vanilla-interactive-component

When you need to ship a **reusable interactive browser component** that mirrors a modern UX (Google Search cards, design references) and can be embedded anywhere — this skill provides the architecture, patterns, and verification tools.

Use when:
- Building `<some-widget>` Custom Elements with internal state, events, and rich interactive content
- Translating visual references (screenshots, Figma, recorded swipes) into working UI patterns
- Zero-dep, zero-build constraints (CDN-friendly ES modules, embeddable in any framework)
- Publishing as a standalone GitHub Pages project

Don't use when:
- The deliverable is a single one-off page → use `creative/claude-design` or `creative/sketch`
- You need framework integration hooks → emit a vanilla CE and wrap it later
- The component is server-rendered → use a templating skill instead

## Architecture

### File layout (single-file components preferred)
```
component-name/
├── component-name.js   # one Custom Element, with CSS in shadow <style>
├── index.html          # demo + live verification target
├── README.md           # public API + visual reference + examples
└── .gitignore
```

A 500-line single file beats a 5-file split when the goal is "drop in anywhere".

### Custom Element skeleton
```js
class MyWidget extends HTMLElement {
  static get observedAttributes() { return ['teams', 'title']; }
  constructor() { super(); this.attachShadow({mode: 'open'}); this._state = null; }
  connectedCallback() { /* render */ }
  attributeChangedCallback() { /* re-render */ }
}
customElements.define('my-widget', MyWidget);
```

### Shadow DOM pointer-events pitfall
SVG containers in flex/grid layout swallow ALL clicks by default. Fix:
```css
.overlay-svg { pointer-events: none; }                       /* root opts out */
.overlay-svg .interactive,
.overlay-svg .interactive > * { pointer-events: all; }     /* opt back in */
```
Without this, Playwright `click()` will hang on shadow DOM locators and `event.target` chains break.

## Patterns

### Scroll-snap horizontal pages with tab strip (paper-fold UX)
```css
.track {
  display: flex;
  overflow-x: auto;
  overflow-y: hidden;
  scroll-snap-type: x proximity;   /* NOT mandatory — see pitfall below */
  overscroll-behavior-y: none;     /* prevent vertical jump on horizontal swipe */
}
.page {
  flex: 0 0 100%;
  scroll-snap-align: start;
  scroll-snap-stop: normal;
  align-self: stretch;             /* all pages share equal height */
}
```

**Pitfall — vertical auto-align**: `scroll-snap-type: x mandatory` makes browsers snap on the cross-axis too, causing the page to jump vertically on horizontal swipe. The fix is `proximity` + `overscroll-behavior-y: none` + `align-self: stretch`. See `references/scroll-snap-tab-sync.md` for the full diagnosis.

### Tab strip + IntersectionObserver sync
```js
const io = new IntersectionObserver(entries => {
  let best = null;
  for (const e of entries) {
    if (e.isIntersecting && (!best || e.intersectionRatio > best.intersectionRatio)) best = e;
  }
  if (!best) return;
  const pageIdx = +best.target.dataset.page;
  // update tab .active class without full re-render
  root.querySelectorAll('.tab').forEach((t, i) => t.classList.toggle('active', i === pageIdx));
}, { root: track, threshold: [0.4, 0.5, 0.6, 0.8] });
pages.forEach(p => io.observe(p));
```
Tab click must scroll the **track only**. Avoid `pageEl.scrollIntoView(...)`: even with `block:'nearest'`, browsers may move the document viewport and produce a vertical jump. Compute the page's horizontal offset and call:
```js
tab.addEventListener('click', e => {
  e.preventDefault();
  track.scrollTo({ left: pageEl.offsetLeft, top: 0, behavior: 'smooth' });
});
```
The IO callback should only toggle active classes; never call `tab.scrollIntoView()` from it. Single source of truth remains the track's horizontal scroll position.

### SVG overlay in CSS grid trench
When you need a connector line BETWEEN two columns of HTML cards, reserve a grid cell of fixed width:
```css
.columns {
  display: grid;
  grid-template-columns: 1fr 12px 1fr;
  grid-template-areas: 'from sv to';
}
.col-from { grid-area: from; }
.col-to { grid-area: to; }
.connectors-svg { grid-area: sv; width: 12px; height: auto; overflow: visible; }
```
The 12px grid cell sits exactly between the two columns, so the SVG's `x=0` and `x=W` align with column edges. Coordinates are local to the SVG.

### LOCKED CSS dimensions for math-based connectors
If connectors are computed in JS (without `getBoundingClientRect`), CSS card dimensions become a hard contract:
```js
// In JS — MUST mirror CSS
const CARD_H = 84;  // matches .card { height: 84px }
const GAP    = 10;  // matches .col  { gap: 10px }
const UNIT   = CARD_H + GAP;
const y = (i) => i * UNIT + UNIT / 2;  // centerline of card i
```
Add a comment next to those CSS values: `/* DO NOT CHANGE without updating connector math */`. Drift between CSS and JS shows up as off-by-one on every card.

### Active color cascade
Lines that connect a decided source should turn blue; loser side fades to a dashed ghost:
```js
if (match.winner) path.classList.add('active');
if (loserSide) path.classList.add('inactive-side');   // dashed + faded
```

### Tab-per-unit vs tab-per-pair UX decision
For multi-stage views (tournament rounds, wizard steps):
- ✅ **Tab per unit** (R32, R16, R8, …): each tab shows ONE stage — canonical Google pattern
- ❌ **Tab per pair** (R32→R16, R16→R8): each tab shows TWO stages — fights snap, confuses navigation

Always pick per-unit unless there's a strong reason otherwise.

## Verification (Playwright with shadow DOM)

Standard locators fail inside shadow DOM. Three reliable patterns:

### 1. Direct dispatchEvent (bypasses pointer-events races)
```python
page.evaluate("""
  el.shadowRoot.querySelector('.match-card').dispatchEvent(
    new MouseEvent('click', {bubbles: true, composed: true})
  )
""")
```

### 2. evaluate() for read-back assertions
```python
state = page.evaluate("""
  el.shadowRoot.querySelectorAll('.bv-card').length
""")
```

### 3. getBoundingClientRect for geometry checks
```python
y = page.evaluate("""
  el.shadowRoot.querySelector('.bv-page').getBoundingClientRect().top
""")
```

Wait for shadow DOM to upgrade:
```python
page.wait_for_function("document.querySelector('my-widget').shadowRoot.querySelector('.track')")
```

Verify SCROLL behavior, not just static rendering:
```python
before = page.evaluate("track.scrollTop")
page.evaluate("track.scrollBy({left: 600, top: 0, behavior: 'instant'})")
after  = page.evaluate("track.scrollTop")
assert before == after, "Vertical scroll should not move during horizontal swipe"
```

Full scaffold in `scripts/verify-shadow-component.py`.

## Deployment — GitHub Pages (no build)

```bash
gh repo create owner/repo --public --description "..." --source=. --remote=origin --push
gh api -X POST repos/owner/repo/pages \
  -f source[branch]=main -f source[path]=/ \
  -H "Accept: application/vnd.github+json"
sleep 35 && gh api repos/owner/repo/pages/builds/latest --jq '.status'   # → "built"
```

GitHub Pages legacy (`/`) serves the main branch as static files. ES modules work because GitHub returns the correct `application/javascript` MIME. ~30s redeploy on push, no build step, no 100MB cap drama.

See `references/github-pages-deploy.md` for the full workflow including build polling.

## Pitfalls (deduped from session history)

1. **Patch tool duplicates CSS selectors.** Multiple `patch` calls on adjacent rules can leave you with two `.card { ... }` blocks. After any CSS patch, scan the area for dupes (`search_files` on the selector name).
2. **`setData()` ordering for propagation.** If you have `_propagateWinner(r, m)` that reads `this._data`, you MUST call `setData(data)` BEFORE calling propagate — otherwise `this._data` is stale or null and you get `Cannot read properties of null`.
3. **Playwright timeout on SVG click inside shadow DOM.** Pixel-level hit-testing races cause indefinite retry. Use `dispatchEvent` pattern instead of `locator.click()`.
4. **Vertical auto-align on horizontal swipe.** `scroll-snap-type: x mandatory` triggers cross-axis snap. Use `proximity` + `overscroll-behavior-y: none` + `align-self: stretch`.
5. **SVG container pointer-events default.** SVG roots in flex/grid swallow all clicks. Always pair `pointer-events: none` on the SVG root with `pointer-events: all` on the interactive children.
6. **`gh api pages` requires specific accept header.** Always pass `-H "Accept: application/vnd.github+json"`, otherwise it returns 404.
7. **Locked CSS / JS drift.** If you bake card dimensions into JS math, change CSS dimensions in lockstep or the layout visually breaks. Add a `/* LOCKED — see connector math */` comment.
8. **Don't run `python3 -m http.server` with `&` in foreground terminal.** Use `terminal(background=true)` and `process(action='kill')` — the `&` form returns immediately without tracking.
9. **Don't use `scrollIntoView` for tab/page navigation.** It may move the document viewport as well as the horizontal track, causing a vertical jump. Scroll the track explicitly with `track.scrollTo({left: page.offsetLeft, top: 0})`; IO only toggles active classes. Verify `window.scrollY` and component `getBoundingClientRect().top` stay constant across every tab.

## Workflow

1. Read the design reference (screenshots, Figma). Identify the interaction primitives (tap, swipe, focus, propagate).
2. Sketch the data model (`{id, a:{...}, b:{...}, winner, status, ...}`).
3. Pick the file layout (single-file preferred).
4. Implement the **render path first** — get something on screen with the right skeleton.
5. Add **interaction events** with optimistic local state mutation.
6. Verify **rendering** with Playwright (pageerror 0, structure match).
7. Verify **interaction** with `dispatchEvent` patterns.
8. Verify **scroll geometry** with `getBoundingClientRect`.
9. Deploy via GitHub Pages (no build), wait for `built` status, re-verify on the live URL.
10. Commit + push after each green-light step. Version numbers in commit messages help audit (v1, v2, …).

## References

- `references/github-pages-deploy.md` — full gh CLI workflow + build polling
- `references/scroll-snap-tab-sync.md` — CSS scroll-snap + IntersectionObserver patterns
- `templates/demo.html` — boilerplate demo page with seed data
- `scripts/verify-shadow-component.py` — Playwright scaffold with shadow DOM access

## Related skills

- `creative/claude-design` — one-off HTML artifacts (different class; use for landing pages)
- `creative/sketch` — throwaway mockups for design compare (different class)
- `canvas-static-site-pipeline` — end-to-end mini app pipeline (similar but bigger scope)
