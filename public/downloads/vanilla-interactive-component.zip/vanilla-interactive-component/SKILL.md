---
name: vanilla-interactive-component
description: Build reusable, interactive browser Web Components (Custom Elements) from visual references — vanilla JS, zero deps, zero build. Patterns for shadow DOM, scroll-snap horizontal pages with tab sync, SVG overlays in CSS grid trenches, and pixel-aligned connectors. Includes GitHub Pages legacy (no-build) deploy and Playwright verification scaffolds.
---

# vanilla-interactive-component

When you need to ship a **reusable interactive browser component** that mirrors a modern UX (Google Search cards, design references) and can be embedded anywhere — this skill provides the architecture, patterns, and verification tools.

Use when:
- Building `<some-widget>` Custom Elements with internal state, events, and rich interactive content
- Translating visual references (screenshots, Figma, recorded swipes) into working UI patterns
- Zero-dep, zero-build constraints (CDN-friendly ES modules, embeddable in any framework)
- Publishing as a standalone GitHub Pages project

Don't use when:
- The deliverable is a single one-off page → use `creative/claude-design` or `creative/sketch`
- You need framework integration hooks → emit a vanilla CE and wrap it later
- The component is server-rendered → use a templating skill instead

## Architecture

### File layout (single-file components preferred)
```
component-name/
├── component-name.js   # one Custom Element, with CSS in shadow <style>
├── index.html          # demo + live verification target
├── README.md           # public API + visual reference + examples
└── .gitignore
```

A 500-line single file beats a 5-file split when the goal is "drop in anywhere".

### Custom Element skeleton
```js
class MyWidget extends HTMLElement {
  static get observedAttributes() { return ['teams', 'title']; }
  constructor() { super(); this.attachShadow({mode: 'open'}); this._state = null; }
  connectedCallback() { /* render */ }
  attributeChangedCallback() { /* re-render */ }
}
customElements.define('my-widget', MyWidget);
```

### Shadow DOM pointer-events pitfall
SVG containers in flex/grid layout swallow ALL clicks by default. Fix:
```css
.overlay-svg { pointer-events: none; }                       /* root opts out */
.overlay-svg .interactive,
.overlay-svg .interactive > * { pointer-events: all; }     /* opt back in */
```
Without this, Playwright `click()` will hang on shadow DOM locators and `event.target` chains break.

## Patterns

### Scroll-snap horizontal pages with tab strip (paper-fold UX)
```css
.track {
  display: flex;
  overflow-x: auto;
  overflow-y: hidden;
  scroll-snap-type: x proximity;   /* NOT mandatory — see pitfall below */
  overscroll-behavior-y: none;     /* prevent vertical jump on horizontal swipe */
}
.page {
  flex: 0 0 100%;
  scroll-snap-align: start;
  scroll-snap-stop: normal;
  align-self: stretch;             /* all pages share equal height */
}
```

**Pitfall — vertical auto-align**: `scroll-snap-type: x mandatory` makes browsers snap on the cross-axis too, causing the page to jump vertically on horizontal swipe. The fix is `proximity` + `overscroll-behavior-y: none` + `align-self: stretch`. See `references/scroll-snap-tab-sync.md` for the full diagnosis.

### Tab strip + IntersectionObserver sync
```js
const io = new IntersectionObserver(entries => {
  let best = null;
  for (const e of entries) {
    if (e.isIntersecting && (!best || e.intersectionRatio > best.intersectionRatio)) best = e;
  }
  if (!best) return;
  const pageIdx = +best.target.dataset.page;
  // update tab .active class without full re-render — NEVER call scrollIntoView here
  root.querySelectorAll('.tab').forEach((t, i) => t.classList.toggle('active', i === pageIdx));
}, { root: track, threshold: [0.4, 0.5, 0.6, 0.8] });
pages.forEach(p => io.observe(p));
```
Tab click must scroll the **track only**. Avoid `pageEl.scrollIntoView(...)`: even with `block:'nearest'`, browsers may move the document viewport and produce a vertical jump. Compute the page's horizontal offset and call:
```js
tab.addEventListener('click', e => {
  e.preventDefault();           // also blocks button's implicit focus-into-view
  track.scrollTo({ left: pageEl.offsetLeft, top: 0, behavior: 'smooth' });
});
```
The IO callback should only toggle active classes; never call `tab.scrollIntoView()` from it. Single source of truth remains the track's horizontal scroll position.

**Verify across every tab** that `window.scrollY` and the component's `getBoundingClientRect().top` stay constant. If they move on first click, `scrollIntoView` is leaking — replace it with `track.scrollTo`.

### Equal-width columns: `minmax(0, 1fr)` not `1fr`
CSS Grid's default `min-width: auto` makes a `1fr` column expand to its intrinsic min-content when content overflows. Two columns each declared `1fr` will NOT be equal if one column's children have a larger intrinsic minimum.

```css
/* WRONG — visually uneven when one column has wider content */
.columns { grid-template-columns: 1fr 12px 1fr; }

/* RIGHT — both columns locked to half of (track − 12px), regardless of content */
.columns { grid-template-columns: minmax(0, 1fr) 12px minmax(0, 1fr); }
```

`minmax(0, 1fr)` sets the column's min-width to 0, so it cannot exceed the algorithm's fr distribution. This pattern is borrowed from `sbachinin/bracketry`:

```css
.equal-width-columns-grid {
  display: grid;
  grid-auto-flow: column;
  grid-auto-columns: minmax(0, 1fr);
}
```

**Verify**: after layout, both columns must report the same `offsetWidth`. Use `getBoundingClientRect()` in Playwright to confirm.

### SVG overlay in CSS grid trench
When you need a connector line BETWEEN two columns of HTML cards, reserve a grid cell of fixed width:
```css
.columns {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 12px minmax(0, 1fr);  /* see pitfall above */
  grid-template-areas: 'from sv to';
}
.col-from     { grid-area: from; }
.col-to       { grid-area: to; }
.col-preview  { grid-area: to; }   /* EVERY column child needs explicit grid-area */
.connectors-svg { grid-area: sv; width: 12px; height: auto; overflow: visible; }
```
The 12px grid cell sits exactly between the two columns, so the SVG's `x=0` and `x=W` align with column edges. Coordinates are local to the SVG.

**Pitfall — implicit grid placement eats width**: if a child of `.columns` does NOT have a `grid-area` set, the auto-placement algorithm puts it in an *implicit* column, silently bypassing `grid-template-areas`. The trench and connector align by 1–4px, looking broken. Every child that should land in 'from', 'sv', or 'to' MUST declare its area, even when it visually replaces another child (e.g. preview column replacing to-column on a different page).

### LOCKED CSS dimensions for math-based connectors
If connectors are computed in JS (without `getBoundingClientRect`), CSS card dimensions become a hard contract:
```js
// In JS — MUST mirror CSS
const CARD_H = 84;  // matches .card { height: 84px }
const GAP    = 10;  // matches .col  { gap: 10px }
const UNIT   = CARD_H + GAP;
const y = (i) => i * UNIT + UNIT / 2;  // centerline of card i
```
Add a comment next to those CSS values: `/* DO NOT CHANGE without updating connector math */`. Drift between CSS and JS shows up as off-by-one on every card.

### Active color cascade
Lines that connect a decided source should turn blue; loser side fades to a dashed ghost:
```js
if (match.winner) path.classList.add('active');
if (loserSide) path.classList.add('inactive-side');   // dashed + faded
```

### Tab-per-unit vs tab-per-pair UX decision
For multi-stage views (tournament rounds, wizard steps):
- ✅ **Tab per unit** (R32, R16, R8, …): each tab shows ONE stage — canonical Google pattern
- ❌ **Tab per pair** (R32→R16, R16→R8): each tab shows TWO stages — fights snap, confuses navigation

Always pick per-unit unless there's a strong reason otherwise.

## Verification (Playwright with shadow DOM)

Standard locators fail inside shadow DOM. Three reliable patterns:

### 1. Direct dispatchEvent (bypasses pointer-events races)
```python
page.evaluate("""
  el.shadowRoot.querySelector('.match-card').dispatchEvent(
    new MouseEvent('click', {bubbles: true, composed: true})
  )
""")
```

### 2. evaluate() for read-back assertions
```python
state = page.evaluate("""
  el.shadowRoot.querySelectorAll('.bv-card').length
""")
```

### 3. getBoundingClientRect for geometry checks
```python
y = page.evaluate("""
  el.shadowRoot.querySelector('.bv-page').getBoundingClientRect().top
""")
```

Wait for shadow DOM to upgrade:
```python
page.wait_for_function("document.querySelector('my-widget').shadowRoot.querySelector('.track')")
```

Verify SCROLL behavior, not just static rendering:
```python
before = page.evaluate("track.scrollTop")
page.evaluate("track.scrollBy({left: 600, top: 0, behavior: 'instant'})")
after  = page.evaluate("track.scrollTop")
assert before == after, "Vertical scroll should not move during horizontal swipe"
```

Full scaffold in `scripts/verify-shadow-component.py`.

## Deployment — GitHub Pages (no build)

```bash
gh repo create owner/repo --public --description "..." --source=. --remote=origin --push
gh api -X POST repos/owner/repo/pages \
  -f source[branch]=main -f source[path]=/ \
  -H "Accept: application/vnd.github+json"
sleep 35 && gh api repos/owner/repo/pages/builds/latest --jq '.status'   # → "built"
```

GitHub Pages legacy (`/`) serves the main branch as static files. ES modules work because GitHub returns the correct `application/javascript` MIME. ~30s redeploy on push, no build step, no 100MB cap drama.

See `references/github-pages-deploy.md` for the full workflow including build polling.

## Pitfalls (deduped from session history)

1. **Patch tool duplicates CSS selectors.** Multiple `patch` calls on adjacent rules can leave you with two `.card { ... }` blocks. After any CSS patch, scan the area for dupes (`search_files` on the selector name).
2. **`setData()` ordering for propagation.** If you have `_propagateWinner(r, m)` that reads `this._data`, you MUST call `setData(data)` BEFORE calling propagate — otherwise `this._data` is stale or null and you get `Cannot read properties of null`.
3. **Playwright timeout on SVG click inside shadow DOM.** Pixel-level hit-testing races cause indefinite retry. Use `dispatchEvent` pattern instead of `locator.click()`. See `scripts/verify-shadow-component.py` for the working pattern.
4. **Vertical auto-align on horizontal swipe.** `scroll-snap-type: x mandatory` triggers cross-axis snap. Use `proximity` + `overscroll-behavior-y: none` + `align-self: stretch`.
5. **SVG container pointer-events default.** SVG roots in flex/grid swallow all clicks. Always pair `pointer-events: none` on the SVG root with `pointer-events: all` on the interactive children.
6. **`gh api pages` requires specific accept header.** Always pass `-H "Accept: application/vnd.github+json"`, otherwise it returns 404.
7. **Locked CSS / JS drift.** If you bake card dimensions into JS math, change CSS dimensions in lockstep or the layout visually breaks. Add a `/* LOCKED — see connector math */` comment.
8. **Don't run `python3 -m http.server` with `&` in foreground terminal.** Use `terminal(background=true)` and `process(action='kill')` — the `&` form returns immediately without tracking.
9. **Don't use `scrollIntoView` for tab/page navigation.** It may move the document viewport as well as the horizontal track, causing a vertical jump. Scroll the track explicitly with `track.scrollTo({left: page.offsetLeft, top: 0})`; IO only toggles active classes. Verify `window.scrollY` and component `getBoundingClientRect().top` stay constant across every tab.
10. **CSS Grid column widths silently uneven.** `grid-template-columns: 1fr 12px 1fr` is NOT equal-width when one column's content has a wider intrinsic minimum. Use `minmax(0, 1fr) 12px minmax(0, 1fr)`. Same applies to `grid-auto-columns: minmax(0, 1fr)` when using `grid-auto-flow: column`. Always verify with `getBoundingClientRect()` on both columns in Playwright.
11. **Children without explicit `grid-area` get auto-placed.** If `.columns { grid-template-areas: 'from sv to' }` is set but a child has no `grid-area`, it lands in an implicit column outside the named areas. Width and trench alignment drift by 1–4px. Always declare `grid-area` on every child of a grid with named areas — even when swapping which child fills which area.
12. **Browser cache + Pages cache = "no visible change".** After pushing a fix, the user may still see the old version for two reasons: (a) their browser caches `.js` files aggressively (Cache-Control default ~10 min on GitHub Pages; longer on the user's browser cache), and (b) GitHub Pages itself caches static files with `cache-control: max-age=600`. Symptoms: code is correct, `git push` reports success, Pages build returns `built`, Playwright on the live URL shows the fix — but the user's browser shows the old version. Always try, in order: (1) suggest hard refresh (⌘⇧R / Ctrl+F5), (2) append `?v=N` to the URL to force a cache miss for that one resource, (3) verify via `curl -I <live-url>/<file>.js` that the served bytes match the latest commit, (4) ask the user to test in an incognito window. Don't keep iterating on the fix when the code is correct — it's cache, not logic.

13. **Card UI: lock content height with `min-height` + flex gap, not `height`.** When a card contains (a) a meta row (date + status badge), (b) two team rows, (c) a status indicator, the natural content height almost always exceeds the visual height you want. If you set `.card { height: 78px }`, the last row spills outside the card box. Instead set `.card { min-height: 92px; padding: 8px 10px; gap: 4px; display: flex; flex-direction: column; }` and let each inner row take its natural height, with a fixed gap. Verify in Playwright with `getBoundingClientRect()` on the card vs its last child — child's bottom must be ≤ card's bottom.

14. **ES module `<script type="module">` + `DOMContentLoaded` race.** A `<script type="module">` executes deferred relative to the parser — meaning when its body runs, the document may have already fired `DOMContentLoaded` if your module loaded slowly (typical for `import('./component.js')`). Adding `document.addEventListener('DOMContentLoaded', () => { ... })` inside a deferred module body often does nothing because the event has already passed. The fix: skip the listener and run the mount code directly inside the module body, after the `await import(...)` resolves. Verify in Playwright by checking that the component's shadow DOM has children, not that some `loaded` flag flipped.

15. **CDN library imports fail in three predictable ways.** When bringing a third-party bracket/widget library into a no-build page via `<script>` or `import('https://esm.sh/...')`, expect (in order of frequency):
    1. **ESM 404 / wrong alias** — `kamilwylegala/vue-tournament-bracket` 404s on esm.sh, but `vue-tournament-bracket` works (esm.sh auto-aliases npm scope). Always `curl -sI <url>` BEFORE patching your code.
    2. **Library internal bug** — `@amirhossein-shk/tournament-bracket-js` v1.0.7 tries to write `mountEl.shadowRoot = ...`, which throws `Cannot set property shadowRoot of #<Element> which has only a getter`. The library's published build is older than the DOM spec. Treat as: capture the error, render a `library self-fail` fallback card with a link to the upstream repo, and let the rest of the page succeed.
    3. **Data-shape mismatch** — `brackets-viewer.js` wants integer `participant.id` (not your `"p1"` strings); `moodysalem/react-tournament-bracket` wants `{ matches: [{ next: "m9", players: [...], result: 0 }] }` not flat rounds. Always pre-process your shared sample data into the library's expected shape, ideally in one transform function per library.
    Pattern: `try { libraryRender(data) } catch (e) { card.fallback(e.message) }` per card so one library failure doesn't break the others.

### Concrete card-height LOCK recipe (when 96px is mandatory)

When the design requires an **exact** card height (for connector math, for `from === preview` visual alignment, or for "two cards in adjacent columns must look identical"), the safe pattern is:

```css
.bv-card {
  width: 100%;
  height: 96px;              /* LOCKED — connector math depends on this */
  box-sizing: border-box;
  padding: 0 10px;            /* zero vertical padding */
  display: grid;
  grid-template-rows: 18px 1fr;
  gap: 0;
}
.bv-card-meta  { line-height: 18px; height: 18px; }
.bv-card-teams {
  display: grid;
  grid-template-rows: 1fr 1fr; /* exact 1fr/1fr split — equal team rows */
  gap: 2px;
  min-height: 0;
  overflow: hidden;
}
.bv-team { height: 100%; min-height: 0; max-height: 100%; overflow: hidden; }
.bv-team-flag    { line-height: 1; height: 16px; }   /* emoji stops pushing row height */
.bv-team-name    { line-height: 1.2; }
.bv-team-score   { line-height: 1; }
```

The recipe above makes the contents sum to **exactly 96px**:

```
 0 padding + 18 meta (1fr-exact) + 0 gap + ((38 + 2 + 38) = 78 teams, 1fr/1fr) = 96
```

Every sub-element that contributes height to the chain must have `line-height` set explicitly. Otherwise `line-height: 1.5` (browser default) inflates a 13px `font-size` to ~20px and pushes the row past its 38px allotment, even when the parent is locked. Use Playwright to verify the chain:

```python
card  = page.evaluate("card.getBoundingClientRect()")
last  = page.evaluate("card.querySelector('.bv-team:nth-child(2)').getBoundingClientRect()")
assert abs(card.bottom - last.bottom) < 1, "content bleeds past card box"
```

**Locked `height` vs `min-height` tradeoff**: pick **ONE** of these two strategies and stay consistent.

1. **Locked `height`** — content exactly fills the box. The math must hit, every `line-height` is pinned, every child has `max-height: 100%`. Connector math reads the value as a CSS constant.
2. **`min-height`** — content takes its natural size. Connectors must read `getBoundingClientRect().height` per card and re-derive per round. More robust to content variations (different team-name lengths, future redesign with extra rows), more code in the connector.

**What never to do**: set `height: 92px` (or any value) on the card and hope the contents fit. They won't, and the last 4–8px will bleed past the box edge and look like a rendering bug to the user. Always verify with `getBoundingClientRect()` on card AND last child.

If the user's complaint is "left/right cards are different sizes" AND your Playwright measurement says they're equal, the cards are likely **equal in dimensions but visually different** because of a 4px content bleed. The fix is the LOCK recipe above.

If the user explicitly says "높이" (height) and not "너비/폭" (width), they may mean the **inner content height visible inside the box**, not the outer card height. Confirm by reading the symptom back: "카드 height는 정확히 같은데, 안의 텍스트가 한 글자만 보여요" → height is locked correctly, but the row's contents are clipping.

16. **`<script type="application/json">` body must be valid JSON, not JavaScript.** It is easy to slip JS expressions into a shared-data block — e.g. `"players": ["A","B"].map((name,i) => ({id:i+1, name}))` — because the block sits inside `<script>`. The browser parses the body as JSON and fails immediately with `Expecting ',' delimiter` at the position of the `(` in `.map(...)`. JS-only syntax (arrow functions, `.map`, `.filter`, template literals, comments) will all break parsing. Build the data shape manually with literal arrays/objects, OR keep one `.js` file that runs first and assigns to `window.SAMPLE_DATA`. Don't mix.

17. **"User repeats the same complaint N times" — re-diagnose or ask, do not re-attempt.** When the user files the same visual complaint a second, third, or fourth time ("여전히 안 됨", "변화 없음", "왼쪽과 오른쪽 카드 크기가 다름" repeated), the previous fix either (a) didn't ship, (b) didn't fix what the user actually meant, or (c) was correct but invisible due to cache. Distinguish:
   - **Diagnosis wrong** — the user's words mapped to a different concept than you assumed. "카드 크기" could mean width, height, both, or the visible padding/inner content size. After 1 retry with the same diagnosis, **ask the user which dimension they mean** before fixing again.
   - **Fix correct but invisible** — Playwright on the live URL shows the fix is live. Then it's cache (pitfall #12). Don't keep patching CSS; propose hard refresh / `?v=N` / incognito.
   - **Fix correct in Playwright but user device renders differently** — likely Safari vs Chrome divergence. Test with a Safari-emulating viewport (`device_scale_factor`, `is_mobile`) before claiming the fix is live.

   The diagnostic order is: (1) read user words for the dimension/target ("높이", "width", "inner padding", "visible height"), (2) measure on live URL with Playwright, (3) if Playwright agrees with user, fix; (4) if Playwright disagrees with user, suspect cache first and propose cache-busting moves.

18. **Grid template columns must sum to ≤ the locked card width.** When you design a `.bv-team` with `grid-template-columns: 24px 1fr 28px 16px` (a flag + name + score + ◀ arrow column), the fixed pieces already sum to 68px. On a 84px card with padding, the `1fr` column gets a NEGATIVE or zero-width share → `minmax(0, 1fr)` collapses and the name column gets cut to ~10–20px. Symptom: only the first character of the team name shows, e.g. `"B..."`. Fix: drop the optional ◀ column entirely (`grid-template-columns: 22px minmax(0, 1fr) 28px`) — winner indication can be done with text weight + accent color, the literal ◀ glyph is rarely worth a 16px column on small cards. Verify on a real device viewport: `team.children[0].getBoundingClientRect().width` should be ≥ the flag (≥ 22px), `team.children[1]` (name) ≥ 24px, and `team.children[2]` (score) ≥ 22px. If any is smaller than expected, the row's content is being clipped — the layout is fine, the column budget is wrong.

19. **`height: 100%` on a grid row child only works when the parent row is `1fr`.** When `.bv-team` is a child of a `grid-template-rows: 1fr 1fr` parent, `height: 100%` resolves to `(1fr × available) = 100% of the row's allocation`. But if the parent row is `min-height: auto` (default), `1fr` can grow beyond the literal `1fr` if a child's min-content is larger. The fix: always pair `height: 100%` with `min-height: 0` on the child AND `min-height: 0; overflow: hidden` on the parent grid. Without those, the row's actual height becomes `max(min-content, 1fr allocation)`, which can make the card overflow the locked card height by 4–12px.

20. **`status` enum mismatch between sample data and renderer.** A common pattern: sample data uses `status: 'completed'` while the renderer's `if/else` chain checks `'scheduled' | 'live' | 'fulltime'`. The unhandled case falls through to `statusLabel = ''` — the meta badge becomes empty, even though the match IS completed. Fix: normalize enums at the boundary (accept both `'completed'` and `'fulltime'`, both `'scheduled'` and `'kickoff'`, both `'live'` and `'in-progress'`). When defining the sample, pick **one** naming convention and stick to it. When defining the renderer, treat the API as forgiving: `if (status === 'foo' || status === 'bar') ...`. Verify in Playwright: every card's status badge has non-empty `textContent`.

21. **`_roundLabel` formula must use depth-from-final, not offset from start.** A common mistake when round counts vary (4 rounds for 8-team, 5 rounds for 16-team, etc.): `labels[offset + roundIdx]` where `offset = MAX - N`. That puts the **last** round label at the **first** round's index and labels go reverse. Correct: `startIdx = labels.length - (totalRounds - 1); labels[startIdx - roundIdx]`. For totalRounds=4 with labels `['Final','Semifinals','Quarterfinals','Round of 16','Round of 32']`: roundIdx 0 → labels[2] = Quarterfinals ✓ (8-team QF is the first round). roundIdx 1 → labels[1] = Semifinals. roundIdx 2 → labels[0] = Final. Verify in Playwright: `tabs.map(t => t.textContent)` should be in **forward order** (largest bracket size first). If you see "Semifinals, Quarterfinals, Final" instead of "Quarterfinals, Semifinals, Final", the offset is wrong.

22. **Korean particle selection (`을/를`, `이/가`, `으로/로`) on dynamic strings.** When you generate strings like `"승자는 8강으로 진출"` or `"결승이 마무리됐습니다"`, the particle must agree with the final character's 받침 (final consonant). Manual `if (nextLabel.endsWith('강')) josa = '으로'` is fragile — some labels end in '시' or '결승'. The Unicode-level check that works for any Hangul syllable:

```js
const lastChar = label.charCodeAt(label.length - 1);
const hasJongSung = lastChar >= 0xAC00 && lastChar <= 0xD7A3 && (lastChar - 0xAC00) % 28 > 0;
const josa = hasJongSung ? '으로' : '로';
```

`(codepoint - 0xAC00) % 28 > 0` is true when the syllable has a 받침 (e.g. 강 → 28, 각 → 0). This handles every Hangul block without an exceptions table. Verify in Playwright on a few different round names (`8강`, `결승`, `16강`, `준결승`) that the rendered sentence reads naturally.

23. **`from` and `preview` columns must declare explicit `grid-area` even when they "obviously" map to a named area.** When `grid-template-areas: 'from sv to'` is set, children without explicit `grid-area` are auto-placed by the grid algorithm, not snapped to the named areas. Symptom: the preview column lands in an *implicit* column to the right of `to`, the trench between `from` and `to` is wider than 12px, and connectors lose their alignment. Fix: declare `grid-area` on every child that should land in any of the named areas — `.col-from`, `.col-to`, `.col-preview`, `.col-trophy`, even when the visual is identical between two of them. The auto-placement algorithm is silent: it doesn't error, it just puts the column where it has space. Verify with `getBoundingClientRect()` on both columns: `from.right === trench.left` and `trench.right === to.left`.

24. **Staggered preview column: each preview card centerline must land on the midpoint between its two contributing `from` matches.** When the paper-fold page shows N `from` cards on the left and N/2 preview cards on the right, the preview column should be **vertically staggered** so each preview sits halfway between the pair of from-matches it consumes. The math, given `CARD_H = 96px`, `GAP = 10px`, `UNIT = CARD_H + GAP = 106`:

   ```
   from[2k]   top = k * UNIT            mid = k * UNIT + CARD_H/2
   from[2k+1] top = k * UNIT + UNIT     mid = k * UNIT + UNIT + CARD_H/2
   midpoint between them = (2k + 1) * UNIT / 2 + CARD_H / 2
   preview_top(k)        = (2k + 1) * UNIT / 2   =  k * 2 * UNIT + UNIT / 2
   ```

   Implement via an inline-styled grid where `grid-template-rows` alternates spacer → preview card → spacer → preview card → ... → trailing spacer. The example below is for 4 `from` cards feeding 2 preview cards:

   ```js
   const OFFSET  = UNIT / 2;          // 53px — leading offset to first preview's top
   const STRIDE  = 2 * UNIT;          // 212px — gap between consecutive preview starts
   const TRAILING = UNIT - OFFSET;    // 53px — trailing spacer at column end

   const rowSizes = [];
   rowSizes.push(`${OFFSET}px`);
   toMatches.forEach((_, i) => {
     rowSizes.push(`${CARD_H}px`);
     if (i < toMatches.length - 1) rowSizes.push(`${STRIDE - CARD_H}px`); // 116
   });
   rowSizes.push(`${TRAILING}px`);

   html += `<div class="bv-col bv-col-next-preview" style="display: grid; grid-template-rows: ${rowSizes.join(' ')};">`;
   ```

   **Verify** in Playwright: `from[0].mid` and `from[1].mid` should average to `preview[0].mid` exactly. Earlier draft used `OFFSET = (UNIT - GAP) / 2 = 48px` (off-by-half-of-GAP), which placed the preview centerline 5px too high. The trick is that `OFFSET` is measured from the top of the column to the top of the first preview card, and that distance must equal `UNIT/2 - CARD_H/2 + CARD_H/2 = UNIT/2`.

25. **Inline `style="display: grid"` is silently overridden by a CSS class that sets `display: flex` on the same element.** When the parent's component CSS locks `.bv-col { display: flex; flex-direction: column; ... }` for normal card-column flow, and you try to use `grid-template-rows` on a specific column via inline style, you set the inline `style="grid-template-rows: 53px 96px 116px 96px 53px;"` but the computed style still reports `display: flex` and the row template is **silently ignored**. The fix: also set `display: grid` in the inline style: `style="display: grid; grid-template-rows: 53px 96px 116px 96px 53px;"`. Browser inline-style specificity only beats CSS-class declarations on properties that the class actually sets; if the class sets `display: flex`, an inline `grid-template-rows` is meaningless because flex doesn't read it. Verify with `getComputedStyle(col).display === 'grid'` before trusting the row layout.

## Showcase pages: reimplement, don't iframe-embed

When the GitHub Pages demo turns into a **comparison page** ("look at how 5 different libraries solve the same problem"), the user will reject iframe-embedding external demos in favor of **reimplementing each library's design pattern in your own DOM/JS/CSS**.

Concrete signals they want this:
- "라이브에서 깃허브로 이동시키는 것이 아닌 네가 해당 소스를 이용해 만든 샘플" → reimplementation, not link-out
- "각 라이브러리 디자인 패턴이 한눈에" → side-by-side visual contrast
- "CDN으로 직접 import 해봐" → they tried that first, it broke on ESM/resolver quirks, then landed on reimplementation

The recipe that worked for `sigco3111/bracket-view`'s library showcase page:

```
index.html        — 5 cards, shared SAMPLE_DATA, [data-sample="..."] mountpoints
bracket-samples.js — N render functions, one per library, each writes into a target
shared styles     — one CSS block per library, prefixed (bv-, vue-, jq-, react-, css-)
```

```js
// bracket-samples.js
function renderBracketsViewer(target) { /* boxed-teams, minimal */ }
function renderVue                (target) { /* column + divider */ }
function renderJqBracket          (target) { /* stage-label + dashed seed grid */ }
function renderReact              (target) { /* SVG rect + L-connector */ }
function renderCssOnly            (target) { /* flex column with margin-top trick */ }

document.querySelectorAll('[data-sample]').forEach(el => {
  const w = el.dataset.sample;
  ({ bv: renderBracketsViewer, vue: renderVue, jq: renderJqBracket,
     react: renderReact, css: renderCssOnly })[w]?.(el);
});
```

Each card links to the upstream repo as `Source on GitHub ↗` so the comparison still works side-by-side, but the rendered page doesn't depend on the upstream being online or allowing X-Frame.

**Why this beats iframes:** iframe demos routinely X-Frame-block upstream (you can't tell until it loads blank), each iframe's CSS leaks into the parent page, and the user can't tell which library's design choices are doing the work. Reimplementing puts the design signature of each library on your own DOM where you can compare them pixel-by-pixel.

**Why this beats CDN imports:** esm.sh / jsdelivr imports of competing libraries fail in different ways (`?external=react,react-dom` resolves differently across versions, UMD globals collide, React hook requirements drift between libraries). A self-contained render function per library is deterministic, debuggable, and version-stable.

## Workflow

1. Read the design reference (screenshots, Figma). Identify the interaction primitives (tap, swipe, focus, propagate).
2. Sketch the data model (`{id, a:{...}, b:{...}, winner, status, ...}`).
3. Pick the file layout (single-file preferred).
4. Implement the **render path first** — get something on screen with the right skeleton.
5. Add **interaction events** with optimistic local state mutation.
6. Verify **rendering** with Playwright (pageerror 0, structure match).
7. Verify **interaction** with `dispatchEvent` patterns.
8. Verify **scroll geometry** with `getBoundingClientRect`.
9. Deploy via GitHub Pages (no build), wait for `built` status, re-verify on the live URL.
10. Commit + push after each green-light step. Version numbers in commit messages help audit (v1, v2, …).

## References

- `references/github-pages-deploy.md` — full gh CLI workflow + build polling
- `references/korean-i18n.md` — josa (을/를, 이/가, 으로/로) Unicode math, depth-from-final round label formula, status badge mapping, button labels. One small helper per pattern; verified inside `<bracket-view>` paper-fold.
- `scripts/verify-shadow-component.py` — Playwright scaffold with shadow-DOM access (dispatchEvent for SVG, scroll-geometry assertions, pageerror capture, viewport capture, mobile + desktop passes)
- `scripts/verify-card-content-fit.py` — verifies the locked-height recipe (pitfall #13 + #19): card content sum equals card height, last child bottom == card bottom, no bleed past box edge
- `templates/iframe-embed-fallback.html` — embed external demo iframes with auto-fallback button (X-Frame-Options)

## Related skills

- `devops/interactive-widget-pages-deploy` — sister skill for the GitHub Pages no-build deploy workflow (gh repo create → gh api pages → 30s poll → live URL). Use that one for the deploy mechanics; this one for the component mechanics.
- `creative/claude-design` — one-off HTML artifacts (different class; use for landing pages)
- `creative/sketch` — throwaway mockups for design compare (different class)
- `canvas-static-site-pipeline` — end-to-end mini app pipeline (similar but bigger scope)
