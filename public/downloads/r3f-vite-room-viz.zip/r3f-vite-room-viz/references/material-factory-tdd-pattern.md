# 3D 자재 factory 모듈의 TDD 패턴 (cloth / foil / paper / wood)

**출처**: 2026-08-04 hermes-knowledge-shelf (sigco3111) Phase B 실측
**적합 대상**: r3f three.js 프로젝트에서 `MeshStandardMaterial` 의 roughness/metalness 밴드를 테스트로 강제하고, foil 같은 별도 surface 의 specular 반응을 cover 와 격리해야 할 때.

## 핵심 의도

3D 객체가 한 종류의 material 로 다 그려지면 (예: cover/spine/foil/page/wood 모두 같은 roughness/metalness) 빛에 어떻게 반응하는지가 통째로 무너진다 — foil 만 specular highlight 가 잡혀야 하는 데 cover 도 같이 반짝인다. **자재 종류별로 factory 모듈을 분리**하고 **밴드(band) 단정**으로 TDD 하면 시각 회귀를 잡을 수 있다.

## 1단계 — 자재별 밴드 정의

자재마다 허용되는 roughness/metalness 범위를 주석으로 박는다. 이 범위를 벗어나면 시각적으로 잘못 읽힌다.

```ts
/**
 * Material bands follow the brief:
 *   - cover:    roughness 0.65–0.80, metalness ≈ 0 (matte cloth)
 *   - foil:     metalness 0.8–1.0,  roughness ≤ 0.25 (only this picks up specular)
 *   - page:     roughness ≥ 0.9 (matte paper)
 *   - wood:     roughness 0.4–0.85, metalness ≈ 0 (matte walnut)
 *   - headband: roughness < cover.roughness (subtle highlight)
 */
```

## 2단계 — factory 모듈 (side-effect free, no global cache)

각 호출이 **별도 인스턴스**를 반환해야 한다. singleton cache 는 HMR / React StrictMode / 동시 다른 책 인스턴스에서 색상/옵션이 섞인다.

```ts
// src/three/materials.ts
import * as THREE from 'three'

const clamp = (v: number, min: number, max: number) => Math.max(min, Math.min(max, v))

export function buildCoverMaterial(accent: string, clothTexture: THREE.Texture | null): THREE.Material {
  return new THREE.MeshStandardMaterial({
    color: '#ffffff',
    map: clothTexture ?? undefined,
    bumpMap: clothTexture ?? undefined,
    bumpScale: 0.012,
    roughness: clamp(0.74, 0.65, 0.8),  // cloth band
    metalness: 0.02,
  })
}

export function buildFoilMaterial(color: string): THREE.Material {
  return new THREE.MeshStandardMaterial({
    color,
    roughness: clamp(0.2, 0.05, 0.25),
    metalness: clamp(0.92, 0.8, 1.0),
    emissive: new THREE.Color(color).multiplyScalar(0.06),
  })
}

export function buildPageMaterial(color: string): THREE.Material {
  return new THREE.MeshStandardMaterial({ color, roughness: 0.94, metalness: 0.0 })
}

export function buildWoodMaterial(color: string): THREE.Material {
  return new THREE.MeshStandardMaterial({ color, roughness: 0.66, metalness: 0.0 })
}

export function buildHeadbandMaterial(color: string): THREE.Material {
  return new THREE.MeshStandardMaterial({ color, roughness: 0.62, metalness: 0.04 })
}

// foil mesh 의 z-offset 상수 — cover 앞 0.003
export const FOIL_FORWARD_OFFSET = 0.003
```

**★ 함정**: `clamp` 가 빠지면 band 가 깨져도 silent pass 한다. clamp 호출 + 테스트는 항상 짝이다.

## 3단계 — RED→GREEN 테스트 (band + singleton-leak)

`MeshStandardMaterial` 의 roughness/metalness 는 `Material.parameters` 또는 instance property 로 접근 가능. vitest 에서 `(mat as any).roughness` 캐스트가 가장 안정적이다.

```ts
// tests/materials.test.ts
import { describe, expect, it } from 'vitest'
import {
  buildCoverMaterial, buildFoilMaterial, buildPageMaterial,
  buildWoodMaterial, buildHeadbandMaterial,
  clothNormalWeights, normalMapCellCount,
} from '../src/three/materials'

describe('cover material (cloth)', () => {
  it('uses the cloth-roughness band 0.65–0.80', () => {
    const mat = buildCoverMaterial('#354767', null)
    const r = (mat as any).roughness as number
    expect(r).toBeGreaterThanOrEqual(0.65)
    expect(r).toBeLessThanOrEqual(0.8)
  })
  it('is non-metallic (metalness <= 0.05) so only foil picks up specular', () => {
    const mat = buildCoverMaterial('#354767', null)
    expect((mat as any).metalness as number).toBeLessThanOrEqual(0.05)
  })
})

describe('foil material', () => {
  it('uses the metallic band 0.8–1.0 with low roughness 0.2', () => {
    const mat = buildFoilMaterial('#e8c783')
    expect((mat as any).metalness).toBeGreaterThanOrEqual(0.8)
    expect((mat as any).metalness).toBeLessThanOrEqual(1.0)
    expect((mat as any).roughness).toBeLessThanOrEqual(0.25)
  })

  // ★ singleton-leak 회귀 테스트 — 같은 인자라도 별도 인스턴스 보장
  it('emits a separate material instance per call (no global cache leak)', () => {
    const a = buildFoilMaterial('#e8c783')
    const b = buildFoilMaterial('#e8c783')
    expect(a).not.toBe(b)
  })
})

describe('page material', () => {
  it('is matte with high roughness to read as paper, not glossy board', () => {
    const mat = buildPageMaterial('#ddd4c3')
    expect((mat as any).roughness).toBeGreaterThanOrEqual(0.9)
  })
})

describe('wood material', () => {
  it('is mid-roughness, non-metallic', () => {
    const mat = buildWoodMaterial('#3b2118')
    expect((mat as any).metalness).toBeLessThanOrEqual(0.05)
    expect((mat as any).roughness).toBeGreaterThanOrEqual(0.4)
    expect((mat as any).roughness).toBeLessThanOrEqual(0.85)
  })
})

describe('headband material', () => {
  it('has lower roughness than the cover so the band stays distinct', () => {
    const cover = buildCoverMaterial('#354767', null)
    const band = buildHeadbandMaterial('#765f8e')
    expect((band as any).roughness).toBeLessThan((cover as any).roughness)
  })
})

// (선택) procedural normal map 의 weight 밴드 — broad weave 보다는 fiber/speckle 비중 ↑
// describe('cloth normal map builder') { ... }
```

**★ 함정 — vitest 가 three.js 의 `MeshStandardMaterial` 생성 시 stderr 에 "parameter 'map' has value of undefined" 같은 경고**:
테스트는 통과하지만 stderr 가 시끄럽다. factory 자체에서 `?? undefined` 로 안전하게 처리하면 사라진다.

**★ 함정 — `(mat as any).roughness` 캐스트가 안 먹힐 때**:
three.js 버전이 바뀌면 property 이름이 바뀔 수 있다. 그땐 `(mat as any).parameters.roughness` 또는 `console.log(Object.keys(mat))` 로 진단. 캐스트는 three.js 가 typescript strict mode 와 살짝 어긋나기 때문에 any cast 가 관용.

## 4단계 — foil mesh 별도 plane 분리 (★ 시각 격리의 핵심)

foil 을 cover 텍스처에 그리지 말고 **별도 mesh + 별도 material + cover 앞 0.003 offset** 으로 둔다.

```ts
// src/three/bookModel.ts
import { buildFoilMaterial, FOIL_FORWARD_OFFSET } from './materials'

const FOIL_GEOMETRY = new THREE.PlaneGeometry(1.0, 1.0, 1, 1)
const COVER_FRONT_Z = 0.24  // cover BoxGeometry depth/2

function foilBoard(index: number): BookPartMesh {
  // 책마다 다른 색 (어두운 foil vs 밝은 foil)
  const color = index === 3 || index === 4 ? '#191715' : '#e8c783'
  return {
    geometry: FOIL_GEOMETRY,
    material: buildFoilMaterial(color),
    position: [0, 0, COVER_FRONT_Z + FOIL_FORWARD_OFFSET],  // 0.243
    castShadow: false,
    receiveShadow: false,
    slot: 'foil',
  }
}
```

`FOIL_FORWARD_OFFSET = 0.003` 같은 상수는 export 해서 다른 mesh 의 z 좌표 계산에 재사용 (예: title plane 도 같은 z plane).

## 5단계 — Scene 에서 legacy foil motif (lineLoop + ring + box) 제거

자재 factory 로 분리하기 전에는 foil 을 JSX 의 `<lineLoop>` / `<ringGeometry>` / `<boxGeometry>` 조합으로 그렸을 수 있다. **새 foil plane 으로 갈아치울 때 이 motif 컴포넌트를 반드시 같이 지운다** — 두 foil 이 겹쳐서 더 부자연스러워진다.

```diff
- function FoilMotif({ index }) {
-   // ...lineLoop + ring + box 5개 mesh
- }
-
  return (
    <group>
      {parts.map(...)}
-     <FoilMotif index={index} />
      {/* + title plane + index text 만 유지 */}
    </group>
  )
```

## 6단계 — Scene 에서 factory 함수 호출 (legacy defaultCoverMaterial 제거)

```diff
- import { defaultCoverMaterial, defaultSpineMaterial } from '../three/bookModel'
+ import { defaultSpineMaterial } from '../three/bookModel'
+ import { buildCoverMaterial, buildWoodMaterial } from '../three/materials'

  const materials = useMemo(() => ({
-   coverMaterial: defaultCoverMaterial(book.accent, clothTexture),
+   coverMaterial: buildCoverMaterial(book.accent, clothTexture),
    spineMaterial: defaultSpineMaterial(clothTexture),
  }), [book.accent, clothTexture])
```

Wooden shelf 같이 인라인 `<meshStandardMaterial color roughness />` 가 많으면 그것도 factory 로 묶는다:

```tsx
function WalnutShelf() {
  const wood = useMemo(() => buildWoodMaterial('#3b2118'), [])
  const woodAccent = useMemo(() => buildWoodMaterial('#5a3324'), [])
  // ... 톤별
  return (
    <group>
      <mesh material={wood}><boxGeometry args={[32, 0.2, 2.34]} /></mesh>
      <mesh material={woodAccent}><boxGeometry args={[32, 0.11, 0.16]} /></mesh>
      {/* ... */}
    </group>
  )
}
```

## 7단계 — bare `npx vitest run` 함정

`npx vitest run` 을 그냥 실행하면 `tests/visual.spec.ts` (Playwright spec) 까지 vitest 가 잡아서 `test.use()` 호출 불가로 실패한다.

```
Error: Playwright Test did not expect test.use() to be called here.
```

**해결**: 항상 `--exclude tests/visual.spec.ts` 플래그를 박는다. 또는 `package.json` 의 `test` 스크립트처럼 exclude 옵션 자체를 박는다.

```json
"scripts": {
  "test": "vitest run --exclude tests/visual.spec.ts"
}
```

CI / shell 에서 ad-hoc 으로 `npx vitest run` 만 치면 같은 함정에 빠진다 — alias / 스크립트로 고정.

## 8단계 — 검증 절차

```bash
# 1. 새 자재 factory 테스트 — RED 확인 (factory 모듈 없을 때 import error 또는 band 단정 실패)
npx vitest run tests/materials.test.ts

# 2. factory 구현 — GREEN
# (위 materials.ts 코드)

# 3. legacy defaultCoverMaterial / FoilMotif 제거
# 4. Scene 에서 factory 호출로 교체

# 5. quality gate (모든 phase 와 동일)
npx vitest run --exclude tests/visual.spec.ts
npm run privacy-check
npx tsc -b
npm run build
```

## 학습 시그널

1. **band 단정**: 자재 종류별로 roughness/metalness 밴드를 박고 `toBeGreaterThanOrEqual / toBeLessThanOrEqual` 로 양쪽 단정 — 한쪽만 단정하면 band 위로 새어나가도 silent pass
2. **singleton-leak 회귀 테스트**: factory 가 매번 별도 인스턴스 반환하는지 `expect(a).not.toBe(b)` — HMR / StrictMode 에서 색상 섞이는 버그를 사전 차단
3. **별도 mesh + 별도 material**: foil 을 cover 텍스처의 일부로 두면 안 됨. 격리된 plane + 별도 material 이 빛 반응을 cover 와 분리
4. **legacy 컴포넌트 동시 제거**: 새 foil plane 을 추가할 때 기존 `<FoilMotif>` 같은 legacy motif 컴포넌트는 반드시 같이 삭제 — 두 foil 이 겹쳐서 더 부자연스러워짐
5. **`npx vitest run` 함정**: bare 명령은 Playwright spec 까지 잡아서 실패 — 항상 `--exclude` 또는 스크립트로 고정

## 다음 단계로 Phase C (인터랙션)

자재 분리가 끝나면 동일 quality gate 로:
- state machine 모듈 (`shelf` / `opening` / `open` / `turning` / `closing` + invalid transition reject + page clamp/wrap)
- 3D open-book 구현 (cover hinge 회전 + back cover + paper block + ≥3 spreads + curved page mesh)
- 페이지 넘김 애니메이션 + 44px 모바일 타겟 + reduced-motion 즉시 전환
- Playwright OPEN/prev/Escape 시나리오 + desktop+mobile 스크린샷
