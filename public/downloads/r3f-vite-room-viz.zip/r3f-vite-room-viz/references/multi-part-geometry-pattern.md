# R3F 다중 부품(multi-part) 지오메트리 + 순수함수 placement 패턴

**출처**: 2026-08-04 hermes-knowledge-shelf (sigco3111) Phase A 실측
**적합 대상**: 책 / 카드 / 패널 / 오브젝트 한 개를 여러 부품으로 나눠서 dense scene 에서 silhouette 을 살리고, useFrame 안의 transform 계산을 vitest 로 검증해야 하는 R3F 프로젝트.

## 핵심 의도

R3F 에서 `<boxGeometry args={[w,h,d]}>` 한 개로 객체를 만들면 평면 카드처럼 보이고, dense scene (예: 7권 row, 60+ 엔티티 룸) 에서 이웃 객체가 각 객체의 "두께"를 읽지 못한다. **객체 1개 = 부품 7~10개** 로 분리하면 silhouette 이 살아나고 raking light 아래서 raised band / 페이지 가장자리 / 머리끝 띠 가 시각적으로 읽힌다.

## 부품 분해 (책 1권 예시)

```
1. 전면 cover 보드  — 가장 큰 단일 부품 (silhouette 결정)
2. 후면 back board  — 살짝 더 크고 어두운 톤 (binding lip 노출)
3. 분절 spine      — 3개의 좁은 panel + 2개의 hinge groove
4. inset paper block — cover 보다 살짝 좁고 두꺼운 슬랩
5. page-edge layers — 3개 얇은 슬랩 (page stack 으로 읽힘)
6. headbands        — 머리/꼬리 부분의 좁은 컬러 띠
7. optional bookmark ribbon — 머리에서 늘어진 thin strip (절반의 책만)
```

각 부품은 별도 `<mesh>` 이지만 같은 parent `<group>` 아래에 위치 → 부모 transform 변경 시 모두 함께 이동/회전.

## 데이터로 노출 (★ 핵심 패턴)

부품을 코드 안에 흩어두지 말고 **데이터 배열** 로 노출한다. 그러면 `<mesh>` 를 map 으로 그릴 수 있고, 부품을 추가/제거/위치조정할 때 다른 코드 수정 없이 데이터만 바꿀 수 있다.

```ts
// src/three/bookModel.ts
import * as THREE from 'three'

export type BookPartMesh = {
  geometry: THREE.BufferGeometry
  material: THREE.Material
  position: [number, number, number]
  castShadow: boolean
  receiveShadow: boolean
  slot: 'cover' | 'spine' | 'paper' | 'edge' | 'headband' | 'hinge' | 'ribbon' | 'foil' | 'wood'
}
export type BookPartSpec = BookPartMesh[]

// ★ placeholder 아님 — 실제 BOOK_WIDTH × BOOK_HEIGHT × BOOK_DEPTH
const COVER_GEOMETRY = new THREE.BoxGeometry(1.72, 2.62, 0.48)
const FOIL_GEOMETRY = new THREE.PlaneGeometry(1.0, 1.0, 1, 1)
const COVER_FRONT_Z = 0.24

function frontBoard(_accent, coverMaterial) {
  return {
    geometry: COVER_GEOMETRY,
    material: coverMaterial,
    position: [0, 0, 0],
    castShadow: true,
    receiveShadow: true,
    slot: 'cover',
  }
}

export function buildBookParts(input, materials) {
  const parts = [
    backBoard(),
    ...spinePanels(input.accent, materials.spineMaterial),
    ...paperBlock(),
    ...pageEdgeLayers(),
    ...headbands(input.accent),
  ]
  if (input.bookmark) parts.push(bookmarkRibbon(input.accent))
  parts.push(frontBoard(input.accent, materials.coverMaterial))
  parts.push(foilBoard(input.index))  // foil 은 별도 plane, cover 앞 0.003
  return parts
}
```

```tsx
// ShelfScene.tsx
import { buildAllParts, defaultBookmarkFor, defaultCoverMaterial, defaultSpineMaterial } from '../three/bookModel'
import { getClothTexture } from './clothTexture'

function Volume({ index }: { index: number }) {
  const book = BOOKS[index]
  const clothTexture = useMemo(() => getClothTexture(book.accent), [book.accent])
  const materials = useMemo(() => ({
    coverMaterial: defaultCoverMaterial(book.accent, clothTexture),
    spineMaterial: defaultSpineMaterial(clothTexture),
  }), [book.accent, clothTexture])
  const parts = useMemo(() => buildAllParts(() => materials, defaultBookmarkFor)[index], [index, materials])

  return (
    <group ref={ref} position={...}>
      {parts.map((part, i) => (
        <mesh key={`${index}-${part.slot}-${i}`}
              position={part.position}
              geometry={part.geometry}
              material={part.material}
              castShadow={part.castShadow}
              receiveShadow={part.receiveShadow} />
      ))}
      {/* + foil motif + title plane + index text */}
    </group>
  )
}
```

## 순수함수 placement 분리 (★ useFrame body 단축)

`useFrame` 안에 직접 박은 transform 계산을 **순수함수 모듈로 분리**하면 vitest 로 RED→GREEN 검증 가능. three.js 의존 없는 함수가 best (node 환경 vitest 에서 path error 회피).

```ts
// src/three/bookPlacement.ts
export const SLOT_GAP = 2.02
export const SHELF_SCALE = 1.14
export const MOBILE_SCALE = 1.18
export const INSPECTION_SCALE = 1.38
export const SHELF_FORWARD_Z = 0.72
export const INSPECTION_FORWARD_Z = 2.45
export const SHELF_LIFT_Y = -0.02
export const SHELF_REST_Y = -0.17

export type ShelfMode = 'shelf' | 'inspection'

export function carouselDistance(index: number, selected: number, total = 7): number {
  const raw = index - selected
  const half = Math.floor(total / 2)
  if (raw > half) return raw - total
  if (raw < -half) return raw + total
  return raw
}

export function activeScale(mode: ShelfMode, viewportWidth: number): number {
  if (mode === 'inspection') return INSPECTION_SCALE
  return viewportWidth <= 700 ? MOBILE_SCALE : SHELF_SCALE
}

export function activeForwardZ(mode: ShelfMode): number {
  return mode === 'inspection' ? INSPECTION_FORWARD_Z : SHELF_FORWARD_Z
}

export function computeBookPlacement(input: { index: number; selected: number; mode: ShelfMode; viewportWidth: number }) {
  const { index, selected, mode, viewportWidth } = input
  const distance = carouselDistance(index, selected)
  const capped = Math.min(Math.abs(distance), 3)
  const position = {
    x: distance * SLOT_GAP,
    y: distance === 0 ? SHELF_LIFT_Y : SHELF_REST_Y - capped * 0.026,
    z: distance === 0 ? activeForwardZ(mode) : -capped * 0.1,
  }
  const rotationY = distance === 0 ? 0
    : -Math.sign(distance) * (Math.min(10, 3 + Math.abs(distance) * 2.5) * Math.PI) / 180
  const scale = distance === 0 ? activeScale(mode, viewportWidth)
    : Math.abs(distance) === 1 ? 0.99
    : Math.abs(distance) === 2 ? 0.92 : 0.86
  return { position, rotationY, scale, liftY: position.y, distance }
}
```

```tsx
// ShelfScene.tsx — useFrame 안에서 호출
useFrame((state, delta) => {
  if (!ref.current) return
  const placement = resolvePlacement(index, selected, mode, state.size.width)
  const ease = 1 - Math.exp(-delta * (placement.distance === 0 ? 8 : 6))
  ref.current.position.x = THREE.MathUtils.lerp(ref.current.position.x, placement.position.x, ease)
  ref.current.position.y = THREE.MathUtils.lerp(ref.current.position.y, placement.position.y, ease)
  ref.current.position.z = THREE.MathUtils.lerp(ref.current.position.z, placement.position.z, ease)
  ref.current.rotation.y = THREE.MathUtils.lerp(ref.current.rotation.y, placement.rotationY, ease)
  const nextScale = THREE.MathUtils.lerp(ref.current.scale.x, placement.scale, ease)
  ref.current.scale.setScalar(nextScale)
})
```

## TDD 테스트 케이스 (RED→GREEN)

```ts
// tests/bookPlacement.test.ts
import { describe, expect, it } from 'vitest'
import { carouselDistance, computeBookPlacement } from '../src/three/bookPlacement'

describe('carouselDistance', () => {
  it('returns 0 for the selected index', () => {
    expect(carouselDistance(2, 2)).toBe(0)
  })
  it('wraps around for distant indices', () => {
    expect(carouselDistance(0, 2)).toBe(-2)
    expect(carouselDistance(5, 2)).toBe(3)  // 5-2=3, within band [-3,3]
    expect(carouselDistance(5, 2, 5)).toBe(-2)  // smaller total = tighter wrap band
  })
})

describe('computeBookPlacement', () => {
  it('centers selected book in shelf mode with forward z 0.72 and scale 1.14', () => {
    const p = computeBookPlacement({ index: 3, selected: 3, mode: 'shelf', viewportWidth: 1440 })
    expect(p.position.x).toBeCloseTo(0, 5)
    expect(p.position.z).toBeCloseTo(0.72, 5)
    expect(p.scale).toBeCloseTo(1.14, 5)
  })
  it('scales active to 1.38 in inspection mode', () => {
    const p = computeBookPlacement({ index: 4, selected: 4, mode: 'inspection', viewportWidth: 1440 })
    expect(p.scale).toBeCloseTo(1.38, 5)
  })
  it('moves immediate neighbors back, rotates, shrinks', () => {
    const left = computeBookPlacement({ index: 2, selected: 3, mode: 'shelf', viewportWidth: 1440 })
    const right = computeBookPlacement({ index: 4, selected: 3, mode: 'shelf', viewportWidth: 1440 })
    expect(left.position.x).toBeCloseTo(-2.02, 5)
    expect(right.position.x).toBeCloseTo(2.02, 5)
    expect(left.position.z).toBeLessThan(0)
    expect(left.rotationY).toBeGreaterThan(0)
    expect(left.scale).toBeCloseTo(0.99, 5)
  })
  it('mobile uses slightly larger scale than desktop', () => {
    const desktop = computeBookPlacement({ index: 0, selected: 0, mode: 'shelf', viewportWidth: 1440 })
    const mobile = computeBookPlacement({ index: 0, selected: 0, mode: 'shelf', viewportWidth: 390 })
    expect(mobile.scale).toBeCloseTo(1.18, 5)
    expect(desktop.scale).toBeCloseTo(1.14, 5)
  })
  it('produces finite numbers for every carousel slot', () => {
    for (let i = 0; i < 7; i++) {
      const p = computeBookPlacement({ index: i, selected: 3, mode: 'shelf', viewportWidth: 1440 })
      expect(Number.isFinite(p.position.x)).toBe(true)
      expect(Number.isFinite(p.position.y)).toBe(true)
      expect(Number.isFinite(p.position.z)).toBe(true)
      expect(Number.isFinite(p.rotationY)).toBe(true)
      expect(Number.isFinite(p.scale)).toBe(true)
    }
  })
})
```

## ★ 함정 — placeholder 박스 지오메트리

코드 작성 중 `new THREE.BoxGeometry(1, 1, 1)` 같은 placeholder 박스를 cover 부품에 박고 deploy + screenshot 을 했는데 라이브에서 cover 가 1×1×1 정사각형으로 보였다. placeholder → 실제 dimension 교체 잊음.

**예방 4단계**:
1. 첫 번째 local render 또는 첫 deploy 직후 screenshot 에서 silhouette 검증
2. `vitest` 단위 테스트는 순수 함수만 검증하고 three.js geometry 의 실제 크기는 검증 안 함 → **시각 QA 단계 필수**
3. `bookPlacement.test.ts` 같은 함수 테스트가 다 통과해도 3D 가 깨질 수 있다는 것을 명심
4. deploy 후 `vision_analyze` 로 cover geometry sanity check

## Vercel deploy + screenshot 워크플로

```bash
# quality gate
cd /Users/mac/work/<project>
npx vitest run --exclude tests/visual.spec.ts      # 모든 unit PASS
npm run privacy-check                                # 0 findings
npx tsc -b                                           # 0 errors
npm run build                                        # exit 0

# prod deploy
TOK=$(cat ~/.hermes/secrets/vercel_token.txt)
vercel deploy --yes --prod --token "$TOK" 2>&1 | tail -10
# → "▲ Aliased  https://<project>.vercel.app" 캡처

# live screenshot
sleep 8
node scripts/verify-ui.mjs https://<project>.vercel.app phase-a-live 2>&1 | grep -E "PASS|FAIL"
# → consoleErrors 0 + pageErrors 0 + requestFailures 0 확인
ls -la .verify/phase-a-live-*.png

# vision QA
# (vision_analyze 로 .verify/phase-a-live-desktop.png 확인)
```

## 다음 단계로 Phase B (재질) 또는 Phase C (인터랙션)

Phase A 가 끝나면 동일 패턴으로:
- **Phase B**: material factory 분리 (`buildCoverMaterial`, `buildFoilMaterial`, etc.) + foil plane 별도 분리 + TDD material 테스트
- **Phase C**: state machine (`shelf` → `opening` → `open` → `turning` → `closing` → `shelf` with invalid transition 차단) + 페이지 turn 애니메이션 + Playwright OPEN/prev/Escape 검증

각 phase 끝마다 즉시 commit + `.verify/phase-<name>-live.png` 캡처.

## 학습 시그널

이 레퍼런스의 모든 함정/패턴은 2026-08-04 hermes-knowledge-shelf Phase A 한 세션에서 실측된 것. 다음 R3F 책/오브젝트 dense scene 작업에서 같은 패턴으로 재사용 가능.

핵심 4가지 학습:
1. **데이터 노출 패턴**: 부품을 데이터 배열로 노출 → `<mesh>` map 렌더 → 추가/제거/위치조정 자유
2. **순수함수 분리**: `useFrame` transform 계산을 vitest 가능 모듈로 분리
3. **placeholder 함정**: `BoxGeometry(1,1,1)` 같은 placeholder 는 첫 deploy 후 무조건 silhouette 검증
4. **phase 별 commit**: A→B→C 가 한 commit 에 섞이지 않게 phase 끝마다 즉시 commit