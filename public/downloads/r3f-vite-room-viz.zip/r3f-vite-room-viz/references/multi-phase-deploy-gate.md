# 다중 phase 순차 deploy gate (A→B→C 패턴)

**출처**: 2026-08-04 hermes-knowledge-shelf (sigco3111) 실측
**적합 대상**: 한 세션 안에서 다중 phase (예: A=구조 / B=재질 / C=인터랙션) 작업을 순차적으로 완성·배포해야 하는 R3F 시각 프로젝트.

## 핵심 의도

한 phase 가 너무 크면 (예: "책 입체감 + 재질 + 책 열기 인터랙션 전부") tool budget / 시간 안에 안 끝나고 중간 보고가 없어진다. **phase 별 deploy gate** 로 나누면:

- 각 phase 끝마다 실제 라이브 검증
- phase C 가 중간에 잘려도 phase A+B 는 이미 커밋/배포되어 있음
- 다음 세션이 그대로 이어받을 수 있게 todo list 에 phase 상태 유지

## Phase 순차 workflow

```
Phase A                          Phase B                          Phase C
──────                          ──────                          ──────
기능 N개 완성                    추가 기능                        인터랙션
  ↓                               ↓                               ↓
test + privacy + build           동일 gate                        동일 gate
  ↓                               ↓                               ↓
Vercel prod deploy               prod deploy                      prod deploy
  ↓                               ↓                               ↓
.verify/phase-a-live.png         .verify/phase-b-live.png         .verify/phase-c-live-desktop.png
                                                                  .verify/phase-c-live-mobile.png
  ↓                               ↓                               ↓
commit "feat: phase A — ..."     commit "feat: phase B — ..."     commit "feat: phase C — ..."
  ↓                               ↓                               ↓
다음 phase 진입                  다음 phase 진입                  완료
```

## Quality gate 매트릭스 (모든 phase 동일)

| 축 | 명령 | 합격 |
|---|---|---|
| Unit tests | `npx vitest run --exclude tests/visual.spec.ts` | 모두 PASS |
| Privacy | `npm run privacy-check` | 0 findings |
| TypeScript | `npx tsc -b` | 0 errors |
| Build | `npm run build` | exit 0 |
| Prod deploy | `vercel deploy --yes --prod --token $TOK` | ✓ Ready + ▲ Aliased |
| Live screenshot | `node scripts/verify-ui.mjs https://<alias>.vercel.app <phase>-live` | consoleErrors 0 + pageErrors 0 |
| Vision QA | `vision_analyze` screenshot | 디자인 기준 충족 |

## 한 phase 의 표준 8-step

```bash
# 1. 코드 작성 (TDD: 테스트 먼저, RED→GREEN)
write tests/<feature>.test.ts
npx vitest run tests/<feature>.test.ts  # RED
write src/three/<feature>.ts
npx vitest run tests/<feature>.test.ts  # GREEN

# 2. wire to scene
patch src/components/Scene.tsx

# 3. quality gate
cd /Users/mac/work/<project>
npx vitest run --exclude tests/visual.spec.ts
npm run privacy-check
npx tsc -b
npm run build

# 4. prod deploy
TOK=$(cat ~/.hermes/secrets/vercel_token.txt)
vercel deploy --yes --prod --token "$TOK" 2>&1 | tail -10

# 5. live screenshot
sleep 8
node scripts/verify-ui.mjs https://<project>.vercel.app <phase-name>-live
ls -la .verify/<phase-name>-live-*.png

# 6. vision QA (실제 silhouette/색상/구도 확인)
# (vision_analyze 호출)

# 7. commit
git add <changed files>
git -c user.name="Hermes Agent" -c user.email="agent@hermes.local" \
  commit -m "feat: phase <X> — <한 줄 설명>

<상세 bullet list>

🤖 Generated with MiniMax-M3"

# 8. 다음 phase 진입 또는 완료 보고
```

## ★ 함정 — placeholder 코드 조기 deploy 후 catch (2026-08-04 실측)

Phase A 도중 cover geometry 가 `BoxGeometry(1, 1, 1)` placeholder 인 상태로 deploy 했는데 라이브 screenshot 에서 cover 가 정사각형으로 보였다. 라이브 screenshot 까지 가서야 발견.

**해결**: 첫 deploy 후 무조건 `vision_analyze` 로 silhouette 검증 → placeholder 흔적 있으면 즉시 fix → redeploy. **vitest 가 통과해도 3D 시각은 검증 안 됨**.

## ★ 함정 — phase 끝나기 전 commit 안 하면 다음 phase 의 변경과 섞임

Phase A 변경 + Phase B 변경을 한꺼번에 commit 하면 나중에 "Phase B 가 정확히 무엇을 추가했는지" 보이지 않는다. **매 phase 끝에 즉시 commit + 로그 기록**:

```
feat: phase A — 입체감 강화 (multi-part book geometry + cinematic camera + 3-point lighting)
feat: phase B — 고급 재질 (procedural cloth + separate foil plane + factory pattern)
feat: phase C — 책 열기 (state machine + page turn + reduced-motion 대응)
```

`.verify/deployment-log.md` 에 deployment ID 기록 보존:

```markdown
## Phase A — 입체감
- Date: 2026-08-04
- Commit: a3deb4f
- Deployment: hermes-knowledge-shelf-p6951mask-sigco3111s-projects.vercel.app
- Alias: https://hermes-knowledge-shelf.vercel.app
- Screenshots: .verify/phase-a-live-{desktop,mobile}.png
- Tests: 26/26 PASS
- Bundle: index-*.js 1.24MB / 356KB gzip
```

## ★ 함정 — tool budget exhaustion mid-phase

A→B→C 가 한 세션 안에 다 안 끝날 수 있다 (특히 phase C 가 인터랙션이면 큼). **세션 시작 시 todo list 에 phase 별 id 박고 매 phase 끝마다 status 갱신** — 끝나지 못한 phase 는 명시적으로 "in_progress" 로 남겨서 다음 세션이 그대로 이어받을 수 있게 한다.

```
Phase A: completed
Phase B: in_progress  ← 중간에 잘리면 이 상태로 남김
Phase C: pending
```

절대 "구현 중" 보고로 끝내지 말 것. 다음 세션이 알아볼 수 있도록 명시.

## Vercel + screenshot 도구 표준

```bash
# 토큰 후보 위치 검증
TOK=$(cat ~/.hermes/secrets/vercel_token.txt)
vercel whoami --token "$TOK"  # → sigco3111 OK

# 4축 자기검증 (vercel skill §"deploy 직전 4축")
vercel_cmd="vercel deploy --prod --yes --non-interactive --token \"$TOK\""
grep -q -- '--name' <<<"$vercel_cmd" && echo "❌ --name deprecated 포함" || echo "✓"
grep -q -- '--token' <<<"$vercel_cmd" || echo "❌ --token 없음"

# 배포
vercel deploy --prod --yes --non-interactive --token "$TOK" 2>&1 | tail -10
# → "▲ Aliased  https://<project>.vercel.app" 캡처

# free alias 200 확인 (team-scope SSO 302 회피)
curl -sI https://<project>.vercel.app | head -1  # HTTP/2 200

# live screenshot (Playwright)
sleep 8  # Vercel alias race 404 회피
node scripts/verify-ui.mjs https://<project>.vercel.app <phase>-live
# → consoleErrors 0 + pageErrors 0 + requestFailures 0
ls -la .verify/<phase>-live-*.png
```

## 다음 단계 가이드

- **Phase B (재질)** 가 끝나면 `references/multi-part-geometry-pattern.md` 의 material factory 패턴 참고
- **Phase C (인터랙션)** 가 시작되면:
  - state machine 모듈을 `src/store/` 또는 `src/three/` 에 추가
  - `tests/<stateMachine>.test.ts` 로 invalid transition RED→GREEN
  - Playwright OPEN/prev/Escape 시나리오 검증
  - desktop + mobile screenshot 둘 다
- **README 다층 갱신** (Phase C 끝): A/B/C 구현 요약 + clean-room note + 데모 URL + 디자인 결정

## 학습 시그널

- A→B→C 의 phase 분할은 사용자가 명시적으로 요구했기 때문에 자연스러웠다. 다음에 "책장 미니앱 만들고 OPEN 인터랙션도" 같은 모호한 요청이 와도 phase A/B/C 로 자동 분할 추천.
- Tool budget 200 호출 중 Phase A+B 통합 + Phase C 시작 못 함 → 다음 세션은 todo list 의 "in_progress: Phase B" + "pending: Phase C" 그대로 이어받으면 됨.
- 매 phase 끝마다 즉시 commit + screenshot 보존은 git history 와 evidence 둘 다 살리는 정석 패턴.