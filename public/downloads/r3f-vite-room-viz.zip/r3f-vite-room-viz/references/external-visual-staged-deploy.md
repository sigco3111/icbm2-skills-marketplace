# 외부 사용자용 단계별 3D 시각 개선·배포

사용자가 로컬 네트워크 밖에 있어 `localhost`를 볼 수 없는 경우의 표준 루프다.

## 핵심 원칙

- 로컬 캡처는 에이전트 내부 QA 증거일 뿐, 사용자 확인 경로가 아니다.
- 사용자가 외부에 있다고 밝히면 로컬 URL을 안내하지 않는다.
- 장기 시각 개선(A→B→C)은 마지막에 한 번 배포하지 말고 **각 단계가 품질 게이트를 통과할 때마다 같은 공개 alias에 배포**한다.
- Preview deployment가 팀 보호로 302/SSO를 반환하면 사용자 확인용 링크로 전달하지 않는다. 공개 production alias의 HTTP 200을 확인한 뒤 전달한다.

## 단계별 루프

각 단계마다 반복한다.

1. 구현 전 시각 수용 기준과 인터랙션 회귀 테스트를 RED로 만든다.
2. 구현 후 단위 테스트, 개인정보 검사, 타입 검사, 프로덕션 빌드를 실행한다.
3. Playwright로 데스크톱·모바일 실제 화면과 콘솔 오류 0건을 확인한다.
4. 원본 레퍼런스와 나란히 캡처하여 구도→깊이→재질→인터랙션 순으로 검사한다.
5. Vercel production에 배포한다.
6. 공개 alias가 HTTP 200인지 확인한다.
7. 라이브 alias에서 같은 Playwright 사용자 흐름을 재실행한다.
8. 사용자에게는 공개 alias 하나만 전달하고, 이번 단계에서 바뀐 시각 요소를 짧게 적는다.

## A→B→C 권장 분리

### A — 기하·입체감

- 표지판, 책등, 종이 블록, 헤드밴드, 홈을 별도 부품으로 구성
- 선택 책 전진·상승·확대
- 이웃 책은 거리별 후퇴·회전·축소
- 카메라에서 윗면·책등·종이 단면이 동시에 보이도록 조정
- 접촉 그림자와 선반 깊이 우선

### B — 재질·조명

- 천 표지는 절제된 미세 normal/bump
- 금박은 별도 geometry와 금속 재질
- 종이 단면, 나뭇결, 헤드밴드 재질 분리
- 색 변경보다 빛에 따른 재질 반응을 검증

### C — 책 열기·페이지 넘김

- 명시적 상태 머신: shelf → opening → open → turning → open → closing → shelf
- 앞표지 hinge, 펼친 종이 블록, 곡면 페이지
- 이전·다음·드래그/클릭, Escape/BACK, 모바일 hit target
- `prefers-reduced-motion` 대응

## Vercel 외부 확인 함정

비대화형 실행에서 팀 범위 요구가 나오면 `--scope <team>`을 명시한다. 단, 팀 scope의 preview URL은 공개 접근 시 302 SSO일 수 있다.

```text
Preview team URL → curl -I → 302 SSO
공개 production alias → curl -I → 200
```

사용자에게 “배포 완료”라고 말하는 기준은 다음 모두 충족할 때다.

- deployment READY
- 공개 alias HTTP 200
- 최신 asset hash 또는 build identity 확인
- 라이브 Playwright 인터랙션 통과

## 동시 작업과 단계 완료 정의

같은 worktree에서 여러 에이전트가 순차·동시에 작업할 수 있으면 각 단계 시작과 커밋 직전에 `git status` 및 staged/unstaged diff를 다시 확인한다. 다른 작업자의 미커밋 변경을 발견하면 `reset`/`checkout`으로 지우지 말고 파일을 다시 읽어 현재 변경 위에 통합한다.

단계 완료는 “코드 작성”이나 “로컬 테스트 통과”가 아니다. 아래가 모두 끝나야 완료다.

1. 전체 test/privacy/typecheck/build 재실행
2. 단계별 commit + push
3. production deploy READY
4. 공개 alias HTTP 200
5. 라이브 Playwright와 화면 캡처
6. 최종 `HEAD == origin/main`, clean working tree

에이전트의 도구 호출 한도 때문에 단계가 중단되면 완료라고 요약하지 말고, **완료된 마지막 게이트와 정확한 미완료 게이트**를 구분한다. 다음 작업자는 미커밋 파일을 먼저 통합하고 이어간다.

## 보고 규칙

외부 사용자에게는:

- ❌ `http://127.0.0.1:...` / `localhost` 안내
- ❌ 302 SSO preview URL 전달
- ✅ 공개 production alias
- ✅ 현재 단계(A/B/C), 확인할 변화 2~4개
- ✅ 아직 남은 단계와 한계
