# Phase C: R3F open-book 3D scene (★ 2026-08-04 hermes-knowledge-shelf 실측)

Phase A/B 가 정적 row + 다중 부품 책 모델이라면, Phase C 는 **인터랙티브 펼친 책 (open-book) 3D scene**. 이 reference 는 실전 패턴 4종 + 함정 5종을 정리한다.

## 1. State machine → R3F scene → DOM overlay 단방향 흐름

```
keyboard/swipe/click → zustand action
                        ↓
              reduceBookState (pure reducer)
                        ↓
            { mode, spreadIndex, transition }
              ↓                  ↓                  ↓
         <OpenBook/> 3D    <ReaderPanel>    App keyboard handler
         (useFrame+useEffect)  (DOM overlay)  (route Arrow/Esc)
```

**단방향 + single source of truth** 가 핵심. OpenBook 와 ReaderPanel 둘 다 같은 zustand store 를 구독. 양쪽이 따로 노는 일 없음.

## 2. OpenBook 컴포넌트 4 부품

### 2.1 Hinged cover
- 앞/뒤 표지를 별도 `<group ref={coverRef}>` 로 분리
- 회전축: 스파인 위치 (페이지 블록 중앙) → `<group position={[±PAGE_WIDTH + GUTTER/2, 0, -COVER_THICKNESS/2]}>`
- 회전: `useFrame` 에서 `lerp(currentAngle, target, ease)`. `OPEN_ANGLE_RAD = 145 * π / 180`
- 앞은 `+currentAngle`, 뒤는 `-currentAngle` (반대 방향)

### 2.2 Gutter
- 정중앙에 `planeGeometry args={[GUTTER, PAGE_HEIGHT]}` + `meshBasicMaterial transparent opacity=0.42 color="#2a1f15"`
- 양쪽 page stack 의 안쪽 모서리 시각적 만남 지점. 페이지가 평면이 아니라 약간 곡선이라 가운데 음영이 더 진해보임

### 2.3 Segmented pages (왜 PlaneGeometry 가 아닌가)
- PlaneGeometry 는 완전히 평면이라 bound page 의 "오른쪽 모서리가 위로 부풀어 보이는" 효과가 안 남
- `BufferGeometry` 를 7 columns × 2 vertices (top+bottom) 로 직접 build + sin curve 적용:
  ```ts
  function pageCurveAt(t: number): number {
    return Math.sin(t * Math.PI) * 0.04  // outer edge 부풀음
  }
  ```
- 좌/우 각 4장 stack (`PAGES_PER_SIDE = 4`), `stackOffset = (PAGES_PER_SIDE - index) * 0.004` 로 z-offset
- normal 도 컬럼별로 계산해 빛 반사 자연스럽게

### 2.4 drei `<Text>` on pages
- 좌/우 페이지에 heading + body + meta 3단
- `maxWidth={PAGE_WIDTH * 0.82}` + `lineHeight={1.45}` 로 페이지 폭 안에 wrap
- **`Html` 가 아닌 `Text` 인 이유**: 페이지 표면 위에 텍스처처럼 박혀야 3D 깊이감 유지 (Html overlay 는 항상 카메라 향해서 평면적)
- 단점: 카메라 각도가 비스듬하면 글자가 약간 일그러져 보임. **트레이드오프 수용**

## 3. State machine → 3D animation 자동 dispatch 패턴

zustand store 가 `bookMode` / `spreadIndex` / `pageDirection` 보유. OpenBook 가 두 곳에서 store 를 사용:

### 3.1 useFrame — 매 프레임 lerp
```tsx
const currentAngle = useRef(0)
useFrame((_, delta) => {
  let target = 0
  if (bookMode === 'opening' || bookMode === 'open' || bookMode === 'turning') target = OPEN_ANGLE_RAD
  if (bookMode === 'closing') target = OPEN_ANGLE_RAD * 0.55
  if (bookMode === 'shelf') target = 0
  const ease = 1 - Math.exp(-delta * (bookMode === 'opening' || bookMode === 'closing' ? 4 : 8))
  currentAngle.current = THREE.MathUtils.lerp(currentAngle.current, target, ease)
  if (frontCoverRef.current) frontCoverRef.current.rotation.z = -currentAngle.current
  if (backCoverRef.current) backCoverRef.current.rotation.z = currentAngle.current
})
```

### 3.2 useEffect — animation 끝나면 reducer 에 _finished dispatch
```tsx
useEffect(() => {
  if (bookMode !== 'opening' && bookMode !== 'turning' && bookMode !== 'closing') return
  const duration = bookMode === 'turning' ? 420 : bookMode === 'closing' ? 380 : 520
  const id = window.setTimeout(() => {
    if (bookMode === 'opening') bookAction('open_finished')
    else if (bookMode === 'turning') bookAction('turn_finished')
    else bookAction('close_finished')
  }, duration)
  return () => window.clearTimeout(id)  // ★ cleanup 필수 (함정 4 참조)
}, [bookMode, bookAction])
```

### 3.3 Reduced-motion 자동 처리
- store 의 `isReducedMotion()` 이 `prefers-reduced-motion: reduce` 감지
- reducer 가 자동으로 `opening → open` 직행 → duration = 0 → animation 즉시 완료
- 별도 코드 없이 `prefers-reduced-motion` 미디어 쿼리로 CSS 애니메이션도 비활성화

## 4. ReaderPanel DOM overlay 패턴

3D scene 가 페이지 텍스트를 보여주지만, **스크린리더 + 검색엔진 + 시각장애 사용자를 위해 DOM 미러** 필수. data-testid 도 여기 박는다.

```tsx
<article data-testid="open-book-spread">
  <span data-testid="spread-indicator">{safeSpreadIndex + 1} / {totalSpreads}</span>
  <h2 data-testid="spread-title">{spread.left.heading}</h2>
  <p data-testid="spread-body">{spread.left.body}</p>
  <h3 data-testid="spread-left-heading">{spread.left.heading}</h3>
  <p data-testid="spread-left-body">{spread.left.body}</p>
  <p data-testid="spread-right-heading">{spread.right.heading}</p>
  <p data-testid="spread-right-body">{spread.right.body}</p>
</article>

<nav className="inspection__page-nav" data-testid="page-nav">
  <button data-testid="prev-page" disabled={!canGoPrev || bookMode === 'turning'}>‹ PREV</button>
  <span data-testid="page-indicator">{safeSpreadIndex + 1} / {totalSpreads}</span>
  <button data-testid="next-page" disabled={!canGoNext || bookMode === 'turning'}>NEXT ›</button>
</nav>
```

**왜 `disabled={bookMode === 'turning'}` 인가**: turn 애니메이션 중 추가 클릭 방지. reducer 의 `page-boundary` 에러가 발생해도 시각적으로 disabled 라서 안전.

## 5. Keyboard + Swipe + Button 3-path 인터랙션

### 5.1 Keyboard (App.tsx)
```tsx
const onKey = (event: KeyboardEvent) => {
  if (event.key === 'Escape') { event.preventDefault(); close(); return }
  if (event.key === 'ArrowRight') {
    event.preventDefault()
    if (mode === 'inspection') nextPage() else next()
  }
  if (event.key === 'ArrowLeft') {
    event.preventDefault()
    if (mode === 'inspection') previousPage() else previous()
  }
}
```

### 5.2 Swipe (pointerdown/up, 60px 임계값)
```tsx
let swipeStartX: number | null = null, swipeStartY: number | null = null
window.addEventListener('pointerdown', (e) => {
  swipeStartX = e.clientX; swipeStartY = e.clientY
})
window.addEventListener('pointerup', (e) => {
  if (swipeStartX === null || swipeStartY === null) return
  const dx = e.clientX - swipeStartX, dy = e.clientY - swipeStartY
  swipeStartX = swipeStartY = null
  if (Math.abs(dx) < 60 || Math.abs(dx) < Math.abs(dy)) return  // vertical scroll 우선
  if (mode === 'inspection') { dx < 0 ? nextPage() : previousPage() }
})
```

### 5.3 Button (ReaderPanel)
- PREV/NEXT 두 버튼 + BACK 버튼
- 모두 WCAG 44px 최소 hit target

## 6. Playwright 검증 시나리오 (★ 2026-08-04 실측)

### 6.1 Desktop
```ts
test('desktop: OPEN → next → prev → ESC swaps spread text and index', async ({ page }) => {
  await page.setViewportSize({ width: 1440, height: 900 })
  const { consoleErrors, pageErrors, requestFailures } = await instrumentPage(page)
  await page.goto('/')

  await page.getByRole('button', { name: 'OPEN' }).click()
  await expect(page.getByTestId('inspection-mode')).toBeVisible()
  const before = await readSpread(page)
  expect(before.indicator).toMatch(/^01 \//)

  await page.getByTestId('next-page').click()
  await page.waitForTimeout(700)
  const afterNext = await readSpread(page)
  expect(afterNext.indicator).toMatch(/^02 \//)
  expect(afterNext.title).not.toBe(before.title)

  await page.keyboard.press('ArrowLeft')
  await page.waitForTimeout(700)
  const afterPrev = await readSpread(page)
  expect(afterPrev.indicator).toMatch(/^01 \//)
  expect(afterPrev.title).toBe(before.title)

  await page.keyboard.press('ArrowRight')
  await page.waitForTimeout(700)
  await page.keyboard.press('Escape')
  await page.waitForTimeout(700)
  await expect(page.getByTestId('inspection-mode')).toHaveCount(0)

  expect(consoleErrors).toEqual([])
  expect(pageErrors).toEqual([])
  expect(requestFailures).toEqual([])
})
```

### 6.2 Mobile (WCAG 44px 강제)
```ts
test('mobile: OPEN → next → prev → BACK closes with 44px targets', async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 })
  // ... instrument

  await page.getByRole('button', { name: 'OPEN' }).click()
  await expect(page.getByTestId('inspection-mode')).toBeVisible()

  const nextBox = await page.getByTestId('next-page').boundingBox()
  const prevBox = await page.getByTestId('prev-page').boundingBox()
  const backBox = await page.getByTestId('inspection-back').boundingBox()
  expect(nextBox?.height).toBeGreaterThanOrEqual(44)
  expect(prevBox?.height).toBeGreaterThanOrEqual(44)
  expect(backBox?.height).toBeGreaterThanOrEqual(44)
  // ... flow assertions
})
```

## 7. Phase C 함정 (5종)

### 함정 1 — Playwright 포트 충돌 ★ 실측
`Error: http://127.0.0.1:4173 is already used`. playwright.config.ts 가 `reuseExistingServer: false` 일 때, 이전 세션의 `npm run preview` 가 port 4173 점유 중이면 발생.
- **진단**: `lsof -i :4173` → PID 확인
- **해결**: `kill <PID>` 후 `npx playwright test` 재실행
- **더 안전한 옵션**: `webServer.reuseExistingServer: true` + 명시적 stop 명령 (테스트 끝나면 자동 종료)

### 함정 2 — placeholder 1×1×1 box deploy 함정 (Phase A 와 동일)
- Phase C 에서도 같은 함정 — `new THREE.BufferGeometry()` 초기 placeholder 평면이 라이브에서 직사각형으로 보임
- **예방**: 첫 deploy 직후 `vision_analyze` 로 page 곡면 + 표지 두께 검증 → placeholder 흔적 있으면 즉시 fix → redeploy

### 함정 3 — write_file CSS 큰 파일 lint 타임아웃
- 14KB+ CSS 갱신 시 lint service 가 30s timeout warning
- **write 자체는 성공** (`verified: true` 확인). 무시하고 진행

### 함정 4 — state machine useEffect cleanup 누락
- `useEffect(() => { setTimeout(...); /* cleanup 빠뜨림 */ }, [bookMode])`
- unmount 또는 mode 전환 시 stale callback 발화 → reducer 가 잘못된 action
- **해결**: 무조건 `return () => window.clearTimeout(id)` 명시

### 함정 5 — inspection mode 에서도 Volume 과 동시 렌더 → z-fighting
- `ShelfScene.tsx` 에서 `bookMode !== 'shelf'` 일 때 `<OpenBook />` 만 렌더하고 `<Volume />` row 는 unmount
- 두 컴포넌트 동시 마운트 시 같은 좌표계에 mesh 겹침 → 카메라 zoom-in 해도 옆 책 silhouette 끼어 보임

## 8. 인터럽트 후 재개 패턴 (★ 2026-08-04 실측)

자주 발생하는 시나리오: child subagent 가 uncommitted 변경 + 새 파일을 남긴 채 종료. 다음 세션이 이를 이어받을 때 절대 reset/stash 하면 안 �.

```bash
# 1. 현재 uncommitted + untracked 상태 확인
git status
# modified: src/store/shelfStore.ts
# modified: tests/shelf.test.ts
# untracked: src/data/spreads.ts
# untracked: src/three/bookStateMachine.ts
# untracked: tests/bookStateMachine.test.ts
# untracked: tests/spreads.test.ts

# 2. 모든 변경 read_file 로 정독 — 인터럽트 child 의 design intent 가 살아있을 가능성 ↑
#    → reducer + store 인터페이스 그대로 사용 (재설계 X)
#    → 명백한 버그(type error, dead code)만 patch

# 3. 베이스라인: 53/53 PASS 확인 (인터럽트 child 가 추가한 테스트 포함)
npx vitest run --exclude tests/visual.spec.ts

# 4. 인터럽트 child 가 못 끝낸 UI 부분 이어서 구현
#    → OpenBook 3D scene + ReaderPanel DOM overlay + App.tsx keyboard/swipe

# 5. quality gate → commit → deploy
```

## 9. 최종 commit 메시지 형식 (★ 2026-08-04)

```
feat(phase-c): add R3F open-book with hinged cover and page navigation

- src/three/OpenBook.tsx: hinged front/back cover (145°), gutter,
  segmented curved pages (BufferGeometry + sin curve), drei Text on
  pages, headbands, state-machine-driven animation via useFrame +
  useEffect setTimeout dispatching open_finished/turn_finished/close_finished
- src/components/ReaderPanel.tsx: spread mirror (heading/body left+right),
  page indicator, prev/next nav buttons (44px min), BACK
- src/components/ShelfScene.tsx: swap Volume → OpenBook when bookMode !== shelf
- src/App.tsx: ArrowLeft/Right → page nav in inspection, Escape → close,
  pointerdown/up 60px swipe, contextmenu block
- src/store/shelfStore.ts: bookMode/spreadIndex/pageDirection per-book state,
  reduced-motion auto-detect
- src/data/spreads.ts: buildSpreadsForBook with cover + sections + cover
- src/three/bookStateMachine.ts: pure reducer (shelf/opening/open/turning/closing)
- tests/: bookStateMachine 12 + spreads 5 + shelf 6 (regression-safe)
- tests/visual.spec.ts: phase-C describe block (desktop OPEN→next→prev→ESC,
  mobile 44px boundingBox, consoleErrors 0)
- src/App.css: page-button 44px WCAG, mobile sticky bottom nav, reduced-motion

🤖 Generated with MiniMax-M3
```

## 10. vision_analyze 체크리스트 (Phase C)

live screenshot 에서 다음 6가지를 명시적으로 확인:

1. **3D 깊이감** — curved pages 가 평면 직사각형이 아니라 가운데 음영 + 외곽 부풀음으로 보임
2. **Cover 회전** — OPEN 시 앞/뒤 표지가 145° 벌어져서 안쪽 페이지가 노출됨
3. **Readable text** — 3D 페이지 위 한국어 heading + body + meta 가 읽을 수 있는 크기/대비
4. **Page indicator** — 우상단 "01 / 04" 같은 indicator 가 명확
5. **Nav button 가독성** — PREV/NEXT 버튼이 모바일에서 44px 이상으로 잘 안 보임
6. **Gutter 가시성** — 가운데 어두운 줄이 페이지 양쪽을 시각적으로 분리함

## 11. 다음 단계 후보 (Phase C 직후)

- **스와이프 더듬이 표시** — 모바일 swipe 시 살짝 transform feedback
- **키보드 화살표 키 힌트** — 화면에 "← →" 힌트 표시 (현재는 hidden)
- **페이지 flip 3D 모션** — 단순 텍스트 swap 이 아닌 실제 페이지가 회전하는 애니메이션 (성능 트레이드오프 큼)
- **사이드 패널 → 풀스크린 reader** — 모바일에서 page nav 가 sticky bottom 인데 풀스크린 reader 가 자연스러운지 검토
- **Vercel Speed Insights** — Phase C 인터랙션 latency 측정 (`useFrame` cost 분석)
