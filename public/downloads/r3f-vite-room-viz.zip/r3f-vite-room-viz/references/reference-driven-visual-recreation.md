# Reference-driven 3D visual recreation

Use this when a user provides a visual reference and asks to apply or recreate its look in a new r3f/Vite project.

## Core rule

A functionally correct 3D scene is not a successful recreation if its **composition, camera, material language, typography, and interaction chrome** differ from the reference. Build against a visual acceptance contract, not a feature checklist alone.

## Before implementation

1. Capture or fetch the authoritative reference image.
2. Write `.verify/reference-criteria.md` with measurable targets:
   - camera projection and fixed/free movement
   - object count, row/grid structure, selected-object scale
   - viewport occupancy and edge cropping
   - spacing, perspective, rotation, and depth visibility
   - background, lighting, contact shadows, surface material
   - top/bottom UI zones, typography, controls, and whitespace
3. Save a baseline screenshot of the current implementation.
4. Name the primary surface archetype (`Explore`, `Inspect`, etc.).
5. If source licensing is absent or restrictive, use clean-room implementation: reproduce visual principles from screenshots but do not copy source code, shaders, textures, atlases, geometry, or artwork.

## Tight visual feedback loop

Create a Playwright check before redesigning. It should be red-capable for the user's complaint and assert structural signals such as:

- expected object count
- reference-specific masthead/footer zones
- selection markers and primary action
- initial absence of unrelated card/dashboard UI
- desktop and mobile overflow
- console/page/request errors

After each meaningful visual pass:

1. Build and run the actual page.
2. Capture desktop and mobile screenshots under `.verify/`.
3. Compare screenshot and reference side by side with vision.
4. List the largest remaining differences in priority order.
5. Do **not** deploy while major compositional differences remain.

At least two visual QA passes are expected for high-fidelity requests.

## Fidelity priority

Fix in this order:

1. composition and camera
2. object scale, spacing, cropping, perspective
3. lighting, depth, contact shadows
4. materials and texture frequency
5. typography and interface chrome
6. decorative detail

Do not polish textures while the camera and composition are still wrong.

## 3D shelf/carousel pattern

For a cinematic row of objects:

- use a fixed or tightly constrained camera rather than free OrbitControls
- move the selected object forward and scale it 10–20%
- progressively reduce scale by distance from selection
- apply small signed Y rotation to neighboring objects so spine/page depth is visible
- tune spacing so edge objects intentionally crop when the reference does
- model shelf depth with top slab, fascia, and lower molding rather than one flat strip
- use broad key/fill/rim lighting and contact shadow to separate objects from the shelf
- keep procedural cloth/noise subtle; a visible square grid reads as pixel art, not fabric

## Reporting

Report fidelity honestly:

- what now matches
- screenshot paths
- test/build/browser evidence
- what still differs and why

Never describe a first functional approximation as visually complete when the reference comparison shows major differences.
