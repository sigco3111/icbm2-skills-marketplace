# 공개 3D 앱: privacy gate + Playwright 3환경 검증

공개 샘플 데이터를 사용하는 Vite+r3f 앱에서 검증된 클래스 패턴이다.

## 1. strict TDD vertical slices

수평으로 테스트를 한꺼번에 쌓지 않는다.

1. 공개 schema/allowlist 테스트 작성 → 모듈 부재 또는 기능 부재로 RED 확인.
2. 최소 schema 구현 → 해당 테스트 GREEN.
3. scanner 패턴 테스트 작성 → RED 확인.
4. 최소 scanner 구현 → GREEN.
5. 정확한 엔티티 순서/개수 테스트 → RED.
6. 공개 JSON + 변환 모듈 구현 → GREEN.
7. Zustand 선택/닫기/순환 탐색 테스트 → RED→GREEN.

최종 보고에는 RED 명령과 기대한 실패 이유를 짧게 남긴다.

## 2. allowlist 공개 schema

- 허용 필드를 선언하고 미허용 필드는 strip한다.
- JSON을 직접 export하지 말고 `raw.map(toPublicRecord)`처럼 런타임 schema 변환을 거친다.
- 공개 문장에도 실제 내부 데이터 대신 명시적인 데모/익명 샘플임을 적는다.

## 3. privacy scanner

재귀 대상 예시: `src`, `public`, `sample-data`.

탐지 클래스:
- 이메일, 전화번호
- `/Users/...`, `/home/...`, `~/.hermes`
- `token|secret|password|api_key` 뒤의 `:`/`=` 패턴
- Telegram/Discord 숫자 ID
- Notion/localhost/internal host 등 비공개 URL

scanner 구현 파일에는 위 문자열과 정규식이 있으므로 자체 스캔 시 오탐한다. 구현 파일은 입력 목록에서 제외하되 다음 두 검증으로 공백을 메운다.

1. 각 패턴에 대한 unit parameterized test.
2. 검사 대상 폴더에 임시 악성 JSON을 생성하고 `npm run privacy-check`가 exit 1인지 확인한 뒤 fixture를 삭제. 이후 정상 검사 0건을 다시 확인.

`package.json`의 build는 `privacy-check && tsc -b && vite build` 순서로 둔다.

## 4. Canvas 접근성 겸 자동화 surface

WebGL mesh는 DOM locator로 직접 세기 어렵다. 각 3D 엔티티에 대응하는 DOM 버튼을 제공한다.

- `aria-label="<이름> 열기"`
- `aria-pressed`로 선택 상태
- `data-testid`는 E2E count에만 사용
- DOM 버튼과 mesh 클릭이 같은 Zustand action을 호출

이 구조는 키보드 접근성, 모바일 대체 UI, Playwright 결정성을 동시에 해결한다.

## 5. 재사용 가능한 E2E 흐름

동일 스크립트에 URL과 label만 인자로 준다.

- dev: `http://127.0.0.1:<dev-port>`
- preview: `http://127.0.0.1:<preview-port>`
- live: production alias

각각 데스크톱 1440x900, 모바일 390x844에서:

1. HTTP 200
2. canvas visible 및 client size 기록
3. 접근성 엔티티 7개와 정확한 이름/순서
4. 첫 항목 클릭 → reader visible
5. ArrowRight → 다음 제목
6. ArrowLeft → 원래 제목
7. screenshot 저장
8. Escape → reader 부재
9. console error 0, pageerror 0

`networkidle` 대신 `domcontentloaded` 후 canvas/DOM selector를 기다린다. 외부 웹폰트가 있거나 지속 요청이 있으면 `networkidle`이 60초 timeout을 만들 수 있다.

## 6. 시각 검증

DOM PASS만으로 3D 구도를 입증하지 못한다. 저장된 데스크톱/모바일 캡처를 vision으로 확인한다.

- 책/룸이 실제 입체로 보이는가
- 선택 항목이 중앙/전면으로 이동했는가
- HTML reader가 3D 씬과 분리되어 읽히는가
- close/previous/next가 잘리지 않는가
- 모바일에서 본문과 고정 하단 탐색이 겹치지 않는가

## 7. production 동일성

Vite 빌드 후 로컬 HTML에서 JS 파일명을 얻거나 `dist/assets/index-*.js`를 선택한다. production alias HTML에서 라이브 JS 경로를 추출하고 SHA-256을 파일 대 파일로 비교한다. 동일하면 소스 배포 정합성에 대한 결정적 증거다.

배포 종료 시:
- `.vercel/` 제거 또는 의도한 정책대로 처리
- Vercel이 `.gitignore`에 중복 `.vercel` 줄을 추가했는지 확인
- `HEAD == origin/main == git ls-remote origin main`
- `git status --porcelain` 비어 있음
- alias HTTP 200
