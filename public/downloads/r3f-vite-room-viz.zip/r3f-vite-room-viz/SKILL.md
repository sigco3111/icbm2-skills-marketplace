---
name: r3f-vite-room-viz
description: "r3f + Vite 풀 3D 룸/오피스 부서 시각화 부트스트랩."
tags: [r3f, react-three-fiber, drei, three.js, vite, react-19, typescript, zustand, gh-pages, isometric, room-viz, office-3d, hud-overlay, glassmorphism, orbitcontrols]
related_skills: [canvas-static-site-pipeline, interactive-globe-viz, globe-gl-pitfalls, pixijs-v8-pitfalls]
metadata:
  hermes:
    tags: [r3f, react-three-fiber, drei, three.js, vite, react-19, typescript, zustand, gh-pages, isometric, room-viz, office-3d, hud-overlay, glassmorphism, orbitcontrols]
    related_skills: [canvas-static-site-pipeline, interactive-globe-viz, globe-gl-pitfalls, pixijs-v8-pitfalls]
---
# r3f + Vite 풀 3D 룸/오피스 시각화 (Class-Level)

**Globe.gl 글로브가 아닌** `@react-three/fiber` 풀 3D 박스룸 + 캐릭터 + HUD 오버레이 시각화 부트스트랩.
검증 사례: **에르메스 3D 관제실** (2026-08-04) — 운용 중인 19개 Hermes cron + 60+ scripts를 8개 부서 룸 + 16명 캐릭터로 시각화 + 상단/우측/하단/좌하단 glassmorphism HUD + OrbitControls 회전/줌.  **+ hermes-knowledge-shelf (2026-08-04)** — 7권 row + 다중 부품 책 모델 + cinematic camera + 고급 재질 + 책 열기 인터랙션.

## ⚠️ Globe.gl / PixiJS와 다른 클래스

| 차원 | Globe.gl | r3f 풀 3D 룸 (본 스킬) | PixiJS v8 |
|------|----------|------------------------|-----------|
| 대상 | 3D 글로브 위 점/호/폴리곤 | 3D 박스 + 캐릭터 + 룸 | 2D 게임/시각화 |
| 카메라 | globe POV (lat/lng/altitude) | PerspectiveCamera + OrbitControls | 2D orthographic/perspective |
| DOM 핀 | `htmlElementsData` (절대 금지) | drei `Html` (허용, hitArea 명시) | Container (허용) |
| 최적화 함정 | viewport culling grid | RoomBox group onClick + raycast | hitArea 명시 |
| HUD | DOM overlay 동일 | DOM overlay 동일 (glassmorphism 동일) | DOM overlay 동일 |

**본 스킬은 Globe.gl/PixiJS와 다른 패턴이라** `globe-gl-pitfalls` / `pixijs-v8-pitfalls` 적용 안 됨.
다만 **CSS overflow guard 패턴** (`#root { position: fixed; overflow: hidden }`)은 차용 가능.

## 1단계 — Vite 스캐폴드 + 의존성

```bash
mkdir -p /Users/mac/work/<project-name>
cd /Users/mac/work/<project-name>
npm create vite@latest . -- --template react-ts -y

npm install three @react-three/fiber @react-three/drei @types/three zustand
npm install -D gh-pages
```

**React 19 + TS 6.x + Vite 8.x가 자동 적용됨** (2026-08-04 Vite 8.2.0 검증).

**주의**: `verbatimModuleSyntax: true` + `erasableSyntaxOnly: true`가 기본 활성. enum/namespace 사용 불가, `import type { ... }` 명시.

## 2단계 — vite.config.ts (gh-pages용 base path)

```ts
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  base: './', // gh-pages는 상대경로가 가장 호환성 좋음 (서브 path 변경에 강함)
  server: { host: '0.0.0.0', port: 5180 },
})
```

**`base: './'` 권장 이유** — GitHub Pages username/저장소 변경에 강함. 절대경로 `/<repo>/` 로 박으면 rename 시 깨짐.

## 3단계 — 컴포넌트 구조 (단일 책임)

```
src/
  types.ts                  # Room / CharacterStatus + 8개 룸 메타데이터 + 그리드 상수
  store.ts                  # Zustand 스토어 (selectedRoom, currentTime, CHARACTER_STATUS mock)
  components/
    Scene.tsx               # 3D 씬 (그리드 + 8개 룸 + OrbitControls + 조명)
    Room.tsx                # 단일 방 (박스 + 라벨 + 캐릭터 2명 + onClick)
    Character.tsx           # 캡슐 + 머리 + 상태 색상 + idle 호흡 애니메이션
    HUD.tsx                 # 헤더 / 사이드 패널 / 티커 / 범례 (DOM overlay)
  App.tsx                   # <Canvas> + <HUD />
  App.css                   # glassmorphism + 4-zone HUD 레이아웃
  index.css                 # 미니멀 리셋
  main.tsx                  # createRoot
  three/                    # ★ 순수함수 placement/geometry/material 모듈 (vitest 대상)
    bookPlacement.ts        # carouselDistance, computeBookPlacement
    bookModel.ts            # buildBookParts (다중 부품 assembly)
    materials.ts            # buildCoverMaterial / buildFoilMaterial / buildPageMaterial
```

**단일 책임 분리 원칙** — Scene은 3D, HUD는 DOM. Zustand 스토어로만 통신. props drilling 금지.
**`three/` 디렉토리 분리 패턴 (★ 2026-08-04 hermes-knowledge-shelf)** — three.js 의존 코드를 `src/three/` 디렉토리에 격리. `useFrame` 안의 transform / geometry / material 로직을 순수함수로 추출하면 vitest 가 three.js 없이 단위 테스트 가능 (vitest node 환경 + `instanceof HTMLCanvasElement` 회피).

## 4단계 — CSS overflow guard (★★★ 필수)

```css
html, body, #root {
  margin: 0; padding: 0;
  width: 100vw; height: 100vh;
  background: #0f172a;
}

body {
  overflow: hidden;
  overscroll-behavior: none;  /* macOS rubber-band scroll 차단 */
  touch-action: none;         /* 모바일 핀치 차단 */
}

#root {
  position: fixed;            /* ← Canvas viewport 초과 방지 */
  overflow: hidden;
  inset: 0;
}

.app-root > canvas {
  display: block;
  width: 100% !important;     /* ← r3f Canvas 내부 width prop 무시 */
  height: 100% !important;
}
```

**차용 출처**: `globe-gl-pitfalls` 함정 3 (body overflow + position 미고정). Globe.gl뿐 아니라 r3f Canvas도 동일한 viewport 초과 → 가로 스크롤 증상 발생. **모든 3D 풀스크린 프로젝트에 동일 패턴 적용**.

## 5단계 — OrbitControls + maxPolarAngle

```tsx
import { OrbitControls } from '@react-three/drei'

<OrbitControls
  enableDamping
  dampingFactor={0.08}
  minDistance={5}
  maxDistance={40}
  maxPolarAngle={Math.PI / 2 - 0.1}  /* ← 지면 아래로 회전 방지 */
  target={[0, 0, 0]}
/>
```

**함정 — `maxPolarAngle` 미지정 시 카메라가 지면 아래로 회전해서 그리드 바닥이 위에 보이는 모드 발생** (isometric 룸 다 뒤집힘). 반드시 `Math.PI/2 - 0.1` (~89.4°) 또는 그 이하로 제한.

**함정 — OrbitControls 가 cinematic camera 와 충돌 (★ 2026-08-04 hermes-knowledge-shelf)**:
책장 같은 미니앱은 OrbitControls 없이 고정 cinematic camera 가 더 자연스럽다. 사용자가 카메라를 조작하지 않아도 모드 전환 (shelf ↔ inspection) 만으로 카메라가 자동으로 위치/FOV 보간되도록 `useFrame` 안에서 lerp. OrbitControls 의 dampingFactor 가 자동 lerp 와 충돌해서 떨림 발생 가능.

## 6단계 — 3D 씬 구조 (Scene.tsx)

```tsx
<>
  {/* 조명 — ambient + directional + hemisphere */}
  <ambientLight intensity={0.55} />
  <directionalLight position={[10, 20, 10]} intensity={1.0} castShadow shadow-mapSize-width={[1024, 1024]} />
  <hemisphereLight args={['#bcd4ff', '#3a2e1f', 0.3]} />

  {/* 그리드 바닥 + 가이드 라인 */}
  <mesh receiveShadow rotation={[-Math.PI / 2, 0, 0]} onClick={handleMissed}>
    <planeGeometry args={[30, 30]} />
    <meshStandardMaterial color="#374151" />
  </mesh>
  <gridHelper args={[30, 30, '#6b7280', '#4b5563']} position={[0, 0.005, 0]} />

  {/* 룸들 */}
  {ROOMS.map((room) => <RoomBox key={room.id} room={room} statuses={...} onSelect={setSelectedRoom} />)}

  {/* OrbitControls */}
  <OrbitControls ... />
</>
```

**그리드 바닥 onClick = 빈 공간 클릭 시 selectedRoom 해제** (사이드 패널 placeholder 복귀).

**3-point lighting rig (★ 2026-08-04 hermes-knowledge-shelf)**:
실제 책장처럼 보이려면 ambient + key + fill + rim 의 3-4 광원 구성이 효과적:
```tsx
<hemisphereLight color="#f3e4cf" groundColor="#0a090b" intensity={0.66} />
<directionalLight position={[2.6, 6.8, 7.4]} intensity={3.1} color="#fff0d5" castShadow shadow-mapSize={[2048, 2048]} shadow-bias={-0.00035} />  // warm key
<directionalLight position={[-6.4, 2.6, 4.4]} intensity={1.2} color="#9eb4d3" />  // cool fill
<directionalLight position={[-1.2, 1.4, -5.2]} intensity={1.6} color="#f6cda2" />  // warm rim
<pointLight position={[0, 1.6, 5.6]} intensity={9.5} color="#f1d99a" distance={10} />  // foil pop
```

## 7단계 — 룸 박스 (Room.tsx)

```tsx
// 4×2 그리드 좌표 계산
// col 0..3 → x: (col - 1.5) * GRID_SPACING
// row 0..1 → z: (row - 0.5) * GRID_SPACING
const x = (room.col - 1.5) * GRID_SPACING;
const z = (room.row - 0.5) * GRID_SPACING;
const [w, h, d] = ROOM_SIZE; // [4, 2.5, 4] 권장

return (
  <group position={[x, 0, z]} onClick={(e) => { e.stopPropagation(); onSelect(room); }}>
    {/* 4면 외벽 + 지붕 (각각 boxGeometry) */}
    {/* 캐릭터 2명 (박스 안쪽 앞쪽) */}
    {/* 라벨 — drei Text 또는 Html */}
  </group>
);
```

**박스 구성 함정 — BoxGeometry 한 번에 쓰지 말고 4면 + 지붕 분리**:
- 4면 + 지붕 분리 → 각 면에 색/그림자 독립 적용 가능
- BoxGeometry 한 번에 → 안쪽이 비어있어도 캐릭터가 박스 안에 들어감 (실제로는 안 보임)
- 분리하면 카메라 각도에 따라 일부 면이 가려져도 OK

## 8단계 — 라벨: drei `Text` vs `Html` (★★★ 함정)

```tsx
// ❌ drei Text — 카메라 각도에 따라 거꾸로 보일 수 있음
<Text position={[0, h + 0.6, 0]} fontSize={0.5} color="#1f2937">
  {`${room.emoji} ${room.name}`}
</Text>

// ✅ drei Html — 항상 카메라 향함, 거꾸로 안 됨 (대신 깊이감 ↓)
<Html position={[0, h + 0.6, 0]} center distanceFactor={10}>
  <div style={{ fontSize: 11, color: '#1f2937', background: 'rgba(255,255,255,0.7)', padding: '2px 6px', borderRadius: 4 }}>
    {label}
  </div>
</Html>
```

**2026-08-04 hermes-control-room 실측**: drei `Text` 라벨이 카메라 정면이 아닌 각도에서 **글자가 거꾸로 보임** (방향벡터가 항상 카메라를 향하지 않음). 트렌드 모니터실 라벨이 명백히 회전된 방향으로 표시됨.

**판단 기준**:
- 게임성/3D 깊이감 우선 → drei `Text` + `Billboard` (drei) 래핑
- 가독성 + 거꾸로 안 됨 우선 → drei `Html` + `distanceFactor`로 크기 자동 축소
- **운영 환경 첫 릴리즈는 Html 권장** (사용자 신뢰도 ↑)

## 9단계 — 캐릭터 (Character.tsx)

```tsx
import { useFrame } from '@react-three/fiber'
import { Html } from '@react-three/drei'

useFrame(({ clock }) => {
  if (status === 'idle') {
    mesh.position.y = position[1] + Math.sin(clock.getElapsedTime() * 1.5 + position[0]) * 0.08;
  }
});

return (
  <group position={position}>
    <mesh ref={meshRef} castShadow>
      <capsuleGeometry args={[CHARACTER_RADIUS, CHARACTER_HEIGHT * 0.6, 4, 12]} />
      <meshStandardMaterial color={STATUS_COLOR[status]} />
    </mesh>
    {/* 머리 (작은 sphere) */}
    <mesh position={[0, CHARACTER_HEIGHT * 0.55, 0]} castShadow>
      <sphereGeometry args={[CHARACTER_RADIUS * 0.55, 16, 16]} />
      <meshStandardMaterial color="#fde68a" />
    </mesh>
    {/* 라벨 */}
    <Html position={[0, CHARACTER_HEIGHT * 1.1, 0]} center distanceFactor={10}>
      <div style={{ fontSize: 10, padding: '1px 4px', background: 'rgba(255,255,255,0.7)', borderRadius: 4 }}>{label}</div>
    </Html>
  </group>
);
```

**idle 호흡 애니메이션 패턴**: `clock.getElapsedTime() * 1.5 + position[0]` — 캐릭터마다 phase offset을 두면 동시 호흡 안 함 (더 자연스러움).

## 10단계 — HUD 4-zone glassmorphism (★★★ 시그니처 패턴)

| Zone | 위치 | 사이즈 | 내용 |
|------|------|--------|------|
| 상단 헤더 | `top: 0` `height: 64px` | 100% width | 좌: 🏛️ 로고 + 시계 (HH:MM) / 우: KPI chips |
| 우측 사이드 패널 | `right: 12px` | `width: 320px` | 방 선택 placeholder 또는 상세 |
| 하단 티커 | `bottom: 0` `height: 48px` | 100% width | 이벤트 스트림 (1단계는 정적) |
| 좌하단 범례 | `bottom: 64px` `left: 12px` | `width: 132px` | 상태 색상 안내 |

**glassmorphism CSS 패턴**:
```css
.glass {
  background: rgba(15, 23, 42, 0.55);
  backdrop-filter: blur(12px) saturate(140%);
  -webkit-backdrop-filter: blur(12px) saturate(140%);
  border: 1px solid rgba(148, 163, 184, 0.18);
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.35);
}
```

**참고**: `twin.quantlabnote.com/guest` 에서 영감받은 구조. isometric 3D + 상단 시세 헤더 + 우측 부서현황 + 하단 뉴스 티커 4-zone 동일 레이아웃.

## 11단계 — Zustand 스토어 패턴

```ts
import { create } from 'zustand'

interface ControlRoomState {
  // KPI mock
  activeCrons: number;
  memoryUsed: number;
  // ...
  selectedRoom: Room | null;
  currentTime: string;

  setSelectedRoom: (room: Room | null) => void;
  tickClock: () => void;
}

export const useControlRoom = create<ControlRoomState>((set) => ({
  activeCrons: 19,
  memoryUsed: 2189,
  // ...
  selectedRoom: null,
  currentTime: formatHHMM(new Date()),
  setSelectedRoom: (room) => set({ selectedRoom: room }),
  tickClock: () => set({ currentTime: formatHHMM(new Date()) }),
}));
```

**1단계 mock → 2단계 라이브 fetch 패턴**:
- 1단계: 스토어에 정적 시드 박음 (`CHARACTER_STATUS: Record<roomId, [CharacterStatus, CharacterStatus]>`)
- 2단계: `useEffect`에서 `fetch('/state.json')` → setState. GitHub Actions 5분 cron이 `public/state.json` 갱신.

## 12단계 — 검증 절차 (4축 + 5단계)

```bash
# 1) TypeScript 컴파일 — 0 에러 필수
npx tsc --noEmit -p tsconfig.app.json

# 2) esbuild 번들 — 0 에러
npx esbuild src/App.tsx --bundle --format=esm --outfile=/tmp/check.js --log-level=warning

# 3) 프로덕션 빌드 — dist/ 생성
npm run build

# 4) dev 서버 health check — background + curl + grep root div
npm run dev -- --host 0.0.0.0 --port 5180 &
sleep 4
curl -s -o /dev/null -w "HTTP %{http_code}\n" http://localhost:5180
curl -s http://localhost:5180 | grep -q '<div id="root"' && echo "ROOT_OK"

# 5) Playwright 스크린샷 + vision_analyze 검증
mkdir -p .verify
# → 프로젝트 scripts/verify-ui.mjs 작성
# → dev / preview / production alias에서 동일 시나리오 실행
# → 1440x900 + 390x844 viewport
# → canvas + 실제 접근성 DOM selector + 인터랙션 검증
```

**검증 폴더 위치 규약**:
- 사용자 또는 과업이 증거 보존을 요구하면 프로젝트의 `.verify/`에 스크린샷을 저장하고 `.gitignore` 처리한다. 최종 보고에 절대경로를 제시한다.
- 일회성 내부 진단만 필요하면 `/tmp/<project>-verify/`를 사용하고 종료 시 정리한다.

**Playwright 검증 표준**:
- viewport 1440x900와 390x844, dpr 1
- `waitUntil: 'domcontentloaded'` + 핵심 selector 대기 + 명시적 warm-up. 외부 폰트나 장기 연결이 있으면 `networkidle`은 불필요하게 timeout될 수 있으므로 완료 조건으로 쓰지 않는다.
- 3D mesh 자체는 DOM에서 셀 수 없으므로 각 엔티티에 대응하는 접근성 버튼/목록을 DOM overlay로 제공하고 개수·이름·선택 상태를 검증한다.
- 클릭 → 상세 패널 표시 → ArrowLeft/ArrowRight → Escape/닫기까지 실제 사용자 흐름을 실행한다.
- `pageerror`와 `console` error를 모두 수집해 0건을 강제한다.
- `canvas.clientWidth/clientHeight`와 실제 viewport를 기록한다.
- dev뿐 아니라 `vite preview`와 production alias에서도 같은 스크립트를 재사용한다.
- 캡처 후 `vision_analyze`로 3D 깊이, 중앙 포커스, 패널 잘림, 모바일 가독성을 확인한다.

### 공개 샘플 데이터 앱의 privacy build gate

공개 배포용 3D 대시보드/서재는 데이터 변환과 개인정보 검사를 빌드 앞단에 둔다.

1. Zod 등으로 공개 필드 allowlist schema를 만들고 `.strip()`/명시적 재구성으로 미허용 필드를 제거한다.
2. `src/`, `public/`, `sample-data/` 등 실제 번들 입력을 재귀 검사한다.
3. 이메일, 전화, 사용자 홈 경로, 비공개 도구 경로, 자격증명 키워드, 메신저 ID, 비공개 URL 발견 시 exit 1.
4. scanner 구현 파일은 탐지 정규식 문자열 자체를 포함하므로 자기 자신을 스캔하지 않는다. 대신 scanner unit test와 임시 악성 fixture로 탐지 및 exit 1을 별도로 입증한다.
5. `build` 스크립트의 첫 단계에 privacy-check를 연결해 로컬과 Vercel 모두 동일하게 차단한다.

상세 재현 레시피는 `references/public-3d-app-privacy-and-e2e.md` 참조.

## 13단계 — 다중 부품(multi-part) 지오메트리 패턴 (★ 2026-08-04 hermes-knowledge-shelf Phase A 실측)

**상황**: 책/오브젝트 한 개를 단일 `<boxGeometry>` 로 만들면 평면 카드처럼 보이고 silhouette 가 부족하다. dense scene (예: 7권 row) 에서 이웃 객체가 각 객체의 "두께"를 읽을 수 있어야 한다.

**해결 — 부품별 분리 (book 7-part 예시)**:
1. **전면 cover 보드**: 가장 큰 단일 부품 (silhouette 결정). 정확한 BOOK_WIDTH × BOOK_HEIGHT × BOOK_DEPTH 사용.
2. **후면 back board**: 살짝 더 크고 어두운 톤 (binding lip 노출)
3. **분절 spine**: 3개의 좁은 panel + 2개의 hinge groove (raking light 아래서 raised band 로 읽힘)
4. **inset paper block**: cover 보다 살짝 좁고 두꺼운 슬랩 (옆에서 봤을 때 page edge 노출)
5. **page-edge layers**: 3개 얇은 슬랩 (page stack 으로 읽힘)
6. **headbands**: 머리/꼬리 부분의 좁은 컬러 띠
7. **optional bookmark ribbon**: 머리에서 늘어진 thin strip (절반의 책만)

**부품을 데이터로 노출하면 `<mesh>` map 으로 그릴 수 있다**:
```ts
// src/three/bookModel.ts
export type BookPartMesh = {
  geometry: THREE.BufferGeometry
  material: THREE.Material
  position: [number, number, number]
  castShadow: boolean
  receiveShadow: boolean
  slot: 'cover' | 'spine' | 'paper' | 'edge' | 'headband' | 'hinge' | 'ribbon' | 'foil' | 'wood'
}
export type BookPartSpec = BookPartMesh[]
export function buildBookParts(input, materials): BookPartSpec { /* ... */ }
```

```tsx
// ShelfScene.tsx
const parts = useMemo(() => buildAllParts(materialsFactory, defaultBookmarkFor)[index], [index, materialsFactory])
return (
  <group ref={ref} position={...}>
    {parts.map((part, i) => (
      <mesh key={`${index}-${part.slot}-${i}`} position={part.position}
            geometry={part.geometry} material={part.material}
            castShadow={part.castShadow} receiveShadow={part.receiveShadow} />
    ))}
    {/* + foil motif + title plane + index text */}
  </group>
)
```

**★ 함정 — placeholder 박스 지오메트리 (2026-08-04 실측)**:
코드 작성 중 `new THREE.BoxGeometry(1, 1, 1)` 같은 placeholder 박스를 cover 부품에 박고 deploy + screenshot 을 했는데 라이브에서 cover 가 1×1×1 정사각형으로 보였다. placeholder → 실제 dimension 교체 잊음. **예방**: 첫 번째 local render 또는 첫 deploy 직후 screenshot 에서 silhouette 검증 필수. `vitest` 단위 테스트는 순수 함수(`computeBookPlacement`)만 검증하고 three.js geometry 의 실제 크기는 검증하지 않는다 — **시각 QA 단계 필수**.

## 14단계 — 순수함수 placement 헬퍼 + TDD (★ 2026-08-04 hermes-knowledge-shelf Phase A)

**패턴**: R3F 의 `useFrame` 안에 직접 박은 transform 계산을 **순수함수 모듈로 분리**해서 vitest 로 RED→GREEN 검증한 뒤 `useFrame` 에서 호출.

```ts
// src/three/bookPlacement.ts — 순수함수 (three.js 의존 없음)
export function carouselDistance(index: number, selected: number, total = 7): number {
  const raw = index - selected
  const half = Math.floor(total / 2)
  if (raw > half) return raw - total
  if (raw < -half) return raw + total
  return raw
}

export function computeBookPlacement(input: BookPlacementInput): BookPlacement {
  const { index, selected, mode, viewportWidth } = input
  const distance = carouselDistance(index, selected)
  const capped = Math.min(Math.abs(distance), 3)
  const position = {
    x: distance * SLOT_GAP,
    y: distance === 0 ? SHELF_LIFT_Y : SHELF_REST_Y - capped * 0.026,
    z: distance === 0 ? activeForwardZ(mode) : -capped * 0.1,
  }
  const rotationY = distance === 0 ? 0
    : -Math.sign(distance) * (Math.min(10, 3 + Math.abs(distance) * 2.5) * Math.PI) / 180
  const scale = distance === 0 ? activeScale(mode, viewportWidth)
    : Math.abs(distance) === 1 ? 0.99
    : Math.abs(distance) === 2 ? 0.92 : 0.86
  return { position, rotationY, scale, liftY: position.y, distance }
}
```

```tsx
// ShelfScene.tsx — useFrame 안에서 호출
useFrame((state, delta) => {
  if (!ref.current) return
  const placement = resolvePlacement(index, selected, mode, state.size.width)
  const ease = 1 - Math.exp(-delta * (placement.distance === 0 ? 8 : 6))
  ref.current.position.x = THREE.MathUtils.lerp(ref.current.position.x, placement.position.x, ease)
  // ...
})
```

**이점**:
- 3D 변환 계산을 unit test 로 검증 가능 (RED→GREEN TDD)
- `useFrame` body 가 짧아져서 가독성 ↑
- `viewportWidth`, `mode`, `selected` 가 같은 입력이면 동일한 placement 보장 (결정론)
- multi-book scene 의 모든 책 transform 이 동일한 함수로 계산되니 일관성 보장

**테스트 케이스 (RED→GREEN)**:
- distance 0 (선택책): position center + forward z + scale 1.14 (shelf) / 1.38 (inspection)
- distance 1: x offset 1 slot, z back, rotation, scale 0.99
- distance 3: 더 큰 z back + 더 큰 rotation + 더 작은 scale
- mobile viewport 가 살짝 큰 scale (1.18 vs 1.14)
- 모든 슬롯에 대해 유한한 수치 반환
- `carouselDistance` 의 wraparound 동작

## 15단계 — `useThree().size.width` in `useFrame` + SSR/CSR FOV init (★ 2026-08-04 hermes-knowledge-shelf Phase A 실측)

**상황**: viewport-aware camera (mobile vs desktop) 가 필요한데 매 프레임 `state.size.width` 를 읽으면 SSR/CSR mismatch 가 발생할 수 있다 (서버는 viewport width 모름).

**해결**:
```tsx
function CinematicCamera() {
  const mode = useShelfStore((state) => state.mode)
  const { camera, size } = useThree()
  const target = useMemo(() => new THREE.Vector3(), [])
  const lookTarget = useMemo(() => new THREE.Vector3(), [])

  // FOV 초기값을 useEffect 에서 한 번 명시적으로 설정 — SSR/CSR mismatch 방지
  useEffect(() => {
    if ('fov' in camera) {
      const initial = cameraKeyframeFor(mode, size.width)
      ;(camera as THREE.PerspectiveCamera).fov = initial.fov
      ;(camera as THREE.PerspectiveCamera).updateProjectionMatrix()
    }
  }, [camera, mode, size.width])

  useFrame((_, delta) => {
    const ease = 1 - Math.exp(-delta * 5)
    const keyframe = cameraKeyframeFor(mode, size.width)
    if ('fov' in camera) {
      const persp = camera as THREE.PerspectiveCamera
      persp.fov = THREE.MathUtils.lerp(persp.fov, keyframe.fov, ease)
      persp.updateProjectionMatrix()
    }
    camera.position.x = THREE.MathUtils.lerp(camera.position.x, keyframe.position[0], ease)
    // ...
  })
  return null
}
```

**★ 함정**: `useFrame` 만 쓰고 `useEffect` 초기화 빠뜨리면 첫 프레임에 camera FOV 가 50° (기본값) 으로 잠깐 보였다가 lerp 로 target 으로 이동 → hydration 직후 짧은 flicker. **useEffect 가 SSR 안전 가드 역할**.

**FOV + position keyframe 패턴**:
```ts
export function cameraKeyframeFor(mode: ShelfMode, viewportWidth: number): CameraKeyframe {
  const mobile = viewportWidth <= 700
  if (mode === 'inspection') return { position: [0, 0.22, 7.4], fov: 38, lookY: 0.05 }
  return {
    position: [0, mobile ? 0.16 : 0.34, mobile ? 14.4 : 11.6],
    fov: mobile ? 28 : 32,
    lookY: mobile ? -0.12 : -0.18,
  }
}
```

## 16단계 — 고급 재질 분리 (Phase B 패턴) — ★ 2026-08-04 hermes-knowledge-shelf

**상황**: 책 한 권의 cover/spine/foil/page/headband 가 모두 같은 roughness/material 라 cloth/foil/paper 가 구분 안 됨. **foil 만 빛에 반응해야** 하는데 cover 도 같이 specular highlight 가 나옴.

**해결 — material factory 모듈로 분리**:
```ts
// src/three/materials.ts
export function buildCoverMaterial(accent, clothTexture) {
  return new THREE.MeshStandardMaterial({
    color: '#ffffff',
    map: clothTexture,
    bumpMap: clothTexture,
    bumpScale: 0.012,
    roughness: 0.74,  // cloth band 0.65–0.80
    metalness: 0.02,  // non-metallic
  })
}
export function buildFoilMaterial(color) {
  return new THREE.MeshStandardMaterial({
    color,
    roughness: 0.2,   // low roughness
    metalness: 0.92,  // metallic band 0.8–1.0
    emissive: new THREE.Color(color).multiplyScalar(0.06),
  })
}
export function buildPageMaterial(color) {
  return new THREE.MeshStandardMaterial({ color, roughness: 0.94, metalness: 0.0 })
}
export function buildWoodMaterial(color) {
  return new THREE.MeshStandardMaterial({ color, roughness: 0.66, metalness: 0.0 })
}
export function buildHeadbandMaterial(color) {
  return new THREE.MeshStandardMaterial({ color, roughness: 0.62, metalness: 0.04 })
}
```

**★ 함정 — foil mesh 를 별도 plane 으로 분리 (2026-08-04 실측)**:
foil 을 cover 의 일부로 텍스처로 그리는 게 아니라 **별도 mesh + 별도 material + cover 앞 0.003 offset** 으로 둬야 한다. 그래야 foil material 의 metalness 0.92 가 cover 의 metalness 0.02 와 격리되어 빛에 반응한다. foil offset `FOIL_FORWARD_OFFSET = 0.003` 상수로 export 해서 다른 mesh (예: title plane) 의 z 좌표 계산에 재사용.

**TDD 패턴 — material factory 도 단위 테스트 가능**:
```ts
// tests/materials.test.ts
it('uses the metallic band 0.8–1.0 with low roughness 0.2', () => {
  const mat = buildFoilMaterial('#e8c783')
  expect((mat as any).metalness).toBeGreaterThanOrEqual(0.8)
  expect((mat as any).roughness).toBeLessThanOrEqual(0.25)
})
```

이 패턴은 vitest 가 three.js import 에서 path error 를 낼 수 있으므로 **factory 모듈이 three.js 에 의존하지 않게 디자인** 하거나, three import 후 throw 하지 않도록 side-effect free 코드 유지. **singleton-leak 회귀 테스트** 도 박는다: `it('emits a separate material instance per call (no global cache leak)')`.

## 17단계 — 다중 phase 순차 deploy gate (A→B→C 패턴) — ★ 2026-08-04 hermes-knowledge-shelf

**상황**: 한 phase 가 너무 크면 (예: "책 입체감 + 재질 + 책 열기 인터랙션 전부") tool budget / 시간 안에 안 끝나고 중간 보고가 없어진다.

**해결 — phase 별 deploy gate**:
1. **Phase A**: 기능 N개 완성 → test + privacy + build → Vercel prod deploy → `.verify/phase-a-live.png` 캡처 → **commit 후 다음 phase 진입**
2. **Phase B**: 추가 기능 → 동일 quality gate → prod deploy → screenshot → **commit**
3. **Phase C**: 인터랙션 → 동일 gate → desktop + mobile screenshot → commit

**quality gate 매트릭스 (모든 phase 동일)**:
| 축 | 명령 | 합격 |
|---|---|---|
| Unit tests | `npx vitest run --exclude tests/visual.spec.ts` | 모두 PASS |
| Privacy | `npm run privacy-check` | 0 findings |
| TypeScript | `npx tsc -b` | 0 errors |
| Build | `npm run build` | exit 0 |
| Prod deploy | `vercel deploy --yes --prod --token $TOK` | ✓ Ready + ▲ Aliased |
| Live screenshot | `node scripts/verify-ui.mjs https://<alias>.vercel.app <phase>-live` | consoleErrors 0 + pageErrors 0 |
| Vision QA | `vision_analyze` screenshot | 디자인 기준 충족 |

**★ 함정 — phase 끝나기 전 commit 안 하면 다음 phase 의 변경과 섞여 history 추적 어려움 (2026-08-04 실측)**:
Phase A 변경 + Phase B 변경을 한꺼번에 commit 하면 나중에 "Phase B 가 정확히 무엇을 추가했는지" 보이지 않는다. **매 phase 끝에 즉시 commit + 로그 기록**:
```
feat: phase A — 입체감 강화 (multi-part book geometry + cinematic camera + 3-point lighting)
feat: phase B — 고급 재질 (procedural cloth + separate foil plane + factory pattern)
feat: phase C — 책 열기 (state machine + page turn + reduced-motion 대응)
```

**함정 — placeholder 코드 조기 deploy 후 catch (2026-08-04 실측)**:
Phase A 도중 cover geometry 가 `BoxGeometry(1, 1, 1)` placeholder 인 상태로 deploy 했는데 라이브 screenshot 에서 cover 가 정사각형으로 보였다. 라이브 screenshot 까지 가서야 발견. **해결**: 첫 deploy 후 무조건 `vision_analyze` 로 silhouette 검증 → placeholder 흔적 있으면 즉시 fix → redeploy. **vitest 가 통과해도 3D 시각은 검증 안 됨**.

**함정 — tool budget exhaustion mid-phase**:
A→B→C 가 한 세션 안에 다 안 끝날 수 있다 (특히 phase C 가 인터랙션이면 큼). **세션 시작 시 todo list 에 phase 별 id 박고 매 phase 끝마다 status 갱신** — 끝나지 못한 phase 는 명시적으로 "in_progress" 로 남겨서 다음 세션이 그대로 이어받을 수 있게 한다. 절대 "구현 중" 보고로 끝내지 말 것.

**함정 — Phase B 구현 시 legacy foil motif 동시 제거 누락**:
자재 factory 로 분리하면서 새 foil plane 을 추가해도, 기존 Scene 에 박혀있던 `<FoilMotif>` 같은 legacy `<lineLoop>` / `<ringGeometry>` / `<boxGeometry>` 조합이 그대로면 두 foil 이 겹쳐서 더 부자연스러워진다. **legacy motif 컴포넌트는 새 foil plane 과 동시에 삭제** (호출 사이트 + 정의 둘 다). band 검증 + singleton-leak 회귀 테스트 + legacy 컴포넌트 grep(`FoilMotif|motifShape`) 으로 zero hit 확인.

**상세 band 검증 코드, singleton-leak 회귀 테스트, `FOIL_FORWARD_OFFSET` 상수 export 패턴, vitest 함정 (`tests/visual.spec.ts` 가 bare `npx vitest run` 으로 잡혀서 실패 → `--exclude` 필수)**: `references/material-factory-tdd-pattern.md` 참조.

## 18단계 — Phase C: R3F open-book 3D scene + state-machine-driven animation (★ 2026-08-04 hermes-knowledge-shelf 실측)

Phase C는 **state machine + 3D scene + DOM overlay (page indicator + nav buttons) + WCAG 44px + reduced-motion + Escape/Arrow/Swipe** 5가지 레이어를 한 phase 안에 묶어야 하는 가장 큰 phase. A/B 와 다른 핵심 결정:

### 18.1 — OpenBook 3D scene 의 핵심 부품 (4개)

R3F `<Canvas>` 안에서 inspection mode 일 때만 마운트하는 `<OpenBook />` 컴포넌트:

1. **Hinged cover (앞 + 뒤)** — `<group ref={coverRef}>` 를 Z축 회전 (0° → 145° = `OPEN_ANGLE_RAD`). `useFrame` 에서 `THREE.MathUtils.lerp(currentAngle, target, ease)`. 앞 표지는 `+OPEN_ANGLE_RAD`, 뒤 표지는 `-OPEN_ANGLE_RAD` 로 반대 방향 (양쪽 다 가운데 spine 에서 hinging).
2. **Gutter (게터)** — 페이지 블록 정중앙의 �은 planeGeometry (GUTTER ≈ 0.04 너비) + dark `meshBasicMaterial` (opacity 0.42). 양쪽 page stack 의 안쪽 모서리가 만나는 지점.
3. **Segmented pages (양쪽 4장씩 stack)** — `BufferGeometry` 를 7 columns + sin curve `pageCurveAt(t) = Math.sin(t * π) * 0.04` 로 직접 build. PAGES_PER_SIDE = 4 매 stack. **왜 PlaneGeometry 가 아닌 BufferGeometry 인가**: PlaneGeometry 는 평면이라 "오른쪽 모서리가 위로 부풀어 보이는" bound page 효과가 안 남. 컬럼별로 Z 곡면을 줘야 실제 종이처럼 보임.
4. **drei `<Text>` on pages** — 좌/우 페이지에 heading + body + meta (한국어) 3단. `maxWidth`, `lineHeight` 명시로 페이지 폭 안에 wrap. **`<Html>` 가 아닌 `<Text>` 인 이유**: 페이지 표면 위에 텍스처처럼 박혀야 3D 깊이감 유지 (HTML overlay 는 항상 카메라 향해서 평면적).

### 18.2 — State machine → 3D scene �이어업 (★ 2026-08-04 실측 핵심 패턴)

**zustand store 가 `bookMode` / `spreadIndex` / `pageDirection` 을 보유** → `<OpenBook />` 가 `useShelfStore` 로 구독 → `useFrame` 에서 `bookMode` 별로 target angle 결정 + `useEffect` setTimeout 으로 `open_finished` / `turn_finished` / `close_finished` 자동 dispatch.

```tsx
// store
applyBookAction('next')  // → reduceBookState returns { mode: 'turning', spreadIndex: 1, transition: 'next' }
// OpenBook useFrame
const target = bookMode === 'opening' || bookMode === 'open' ? OPEN_ANGLE_RAD
             : bookMode === 'closing' ? OPEN_ANGLE_RAD * 0.55 : 0
currentAngle.current = lerp(currentAngle.current, target, ease)
coverRef.current.rotation.z = currentAngle.current

// OpenBook useEffect
useEffect(() => {
  if (bookMode !== 'opening' && bookMode !== 'turning' && bookMode !== 'closing') return
  const duration = bookMode === 'turning' ? 420 : bookMode === 'closing' ? 380 : 520
  const id = window.setTimeout(() => {
    if (bookMode === 'opening') bookAction('open_finished')
    else if (bookMode === 'turning') bookAction('turn_finished')
    else bookAction('close_finished')
  }, duration)
  return () => window.clearTimeout(id)
}, [bookMode, bookAction])
```

**이점**:
- state machine 이 single source of truth → 3D scene 와 DOM overlay 가 같은 state 구독
- vitest 가 reducer 만 검증 → 3D 렌더 검증 없이도 신뢰성 확보
- reduced-motion: store 의 `isReducedMotion()` 이 자동 감지 → reducer 가 `opening → open` 직행 처리 → animation duration = 0

### 18.3 — WCAG 44px + mobile sticky + reduced-motion CSS 패턴

```css
.page-button {
  min-width: 120px; min-height: 44px;  /* WCAG 2.5.5 AAA */
  padding: 0 22px;
  border: 1px solid rgba(232,218,196,.32) !important;
  border-radius: 999px !important;
}
.page-button:disabled { opacity: .35; cursor: not-allowed; }

@media (max-width: 700px) {
  .inspection__page-nav {
    position: sticky; bottom: 12px;
    padding: 10px 12px; background: rgba(23,21,23,.92);
    border-radius: 12px; border: 1px solid rgba(232,218,196,.12);
  }
  .page-button { min-width: 96px; min-height: 44px; }
}

@media (prefers-reduced-motion: reduce) {
  .inspection { animation: none; }  /* CSS 애니메이션도 즉시 종료 */
}
```

**Playwright 44px 검증**:
```ts
const nextBox = await page.getByTestId('next-page').boundingBox()
expect(nextBox?.height ?? 0).toBeGreaterThanOrEqual(44)
```

### 18.4 — Swipe (모바일) + keyboard (데스크톱) + button (둘 다) 3-path

```tsx
// pointerdown/up 으로 60px 임계값 swipe
let swipeStartX: number | null = null
window.addEventListener('pointerdown', (e) => { swipeStartX = e.clientX })
window.addEventListener('pointerup', (e) => {
  if (swipeStartX === null) return
  const dx = e.clientX - swipeStartX
  swipeStartX = null
  if (Math.abs(dx) < 60 || Math.abs(dx) < Math.abs(e.clientY - swipeStartY)) return
  if (mode === 'inspection') { dx < 0 ? nextPage() : previousPage() }
})
```

### 18.5 — Phase C quality gate 추가 사항

| 축 | Phase A/B | Phase C 추가 |
|---|---|---|
| Unit tests | 53/53 PASS | reducer 12 + spreads 5 + shelf 6 = **53/53 PASS 유지** (regression guard) |
| Playwright e2e | desktop/mobile visual | **`phase-C open-book inspection` describe 블록 추가** — desktop: OPEN→next→prev→ESC + page text/index change 어서션 / mobile: 44px boundingBox + prev→BACK. `consoleErrors/pageErrors/requestFailures` 모두 0건 |
| Live screenshot | desktop + mobile | **desktop + mobile 둘 다** (page nav 의 sticky bottom 모바일 검증) |
| vision_analyze | silhouette | **3D 깊이감 (curved pages) + readable text + 페이지 번호 indicator + nav button 가독성** |

### 18.6 — Phase C 함정 (★ 2026-08-04 실측 5종)

1. **placeholder 1×1×1 box deploy 함정 (Phase A 와 동일)** — Phase C 에서도 같은 함정. 첫 page geometry `new THREE.BufferGeometry()` 직전에 placeholder plane 쓰면 라이브에서 평면 직사각형 보임 → vision_analyze 로 즉시 검출.

2. **Playwright 포트 충돌 (4173 already in use, ★ 2026-08-04 실측)** — `playwright.config.ts` 에 `reuseExistingServer: false` 인데 이전 세션의 `npm run preview` 가 port 4173 점유 중이면 `Error: http://127.0.0.1:4173 is already used` 에러. **해결**: `lsof -i :4173` 로 PID 확인 → `kill <PID>` 후 `npx playwright test` 재실행. 더 안전한 옵션은 `webServer.reuseExistingServer: true` + 명시적 stop 명령.

3. **write_file CSS 큰 파일 lint 타임아웃 (cosmetic warning)** — `write_file` 로 14KB+ CSS 갱신 시 lint service 가 30s timeout warning 띄우지만 **write 자체는 성공** (`verified: true` 확인). 무시하고 진행.

4. **state machine `useEffect` cleanup 누락** — `useEffect(() => { const id = window.setTimeout(...); return () => window.clearTimeout(id) }, [bookMode, bookAction])` 의 cleanup function 빠뜨리면 unmount 또는 mode 전환 시 stale callback 이 다음 timeout 발화 → state machine 이 잘못된 action 받음. **무조건 cleanup 함수 명시**.

5. **inspection mode 일 때도 Volume 이 함께 렌더되면 z-fighting** — `ShelfScene.tsx` 에서 `bookMode !== 'shelf'` 일 때 `<OpenBook />` 만 렌더하고 `<Volume />` 7권 row 는 unmount. 두 컴포넌트가 동시에 마운트되면 같은 좌표계에 다른 mesh 가 겹쳐서 카메라가 z=7.4 로 줌인해도 옆쪽 책 silhouette 이 끼어 보임.

### 18.7 — Phase C 인터럽트 후 재개 패턴 (★ 2026-08-04 실측 — 가장 중요한 학습)

**인터럽트된 child 가 uncommitted 변경 + 새 파일을 남긴 채 종료**하는 패턴이 자주 발생. 다음 세션이 이를 이어받을 때 절대 `git reset --hard` 또는 `git stash` 하면 안 됨.

**재개 워크플로**:
```bash
# 1. uncommitted 변경 + untracked 파일 확인
git status
# modified: src/store/shelfStore.ts
# modified: tests/shelf.test.ts
# untracked: src/data/spreads.ts
# untracked: src/three/bookStateMachine.ts
# untracked: tests/bookStateMachine.test.ts
# untracked: tests/spreads.test.ts

# 2. 모든 변경을 read_file 로 정독 (특히 reducer 와 store)
# → 인터럽트 child 의 design intent 가 들어있을 가능성 ↑

# 3. 베이스라인: 기존 테스트 그대로 PASS 하는지 (인터럽트 child 가 추가한 테스트 포함)
npx vitest run --exclude tests/visual.spec.ts  # 53/53 PASS 기대

# 4. 인터럽트 child 가 못 끝낸 UI 부분을 이어서 구현
#    → OpenBook 3D scene + ReaderPanel DOM overlay + App.tsx keyboard/swipe
#    → 기존 store / reducer / spreads 의 인터페이스 그대로 사용

# 5. quality gate → commit → deploy
```

**인터럽트 child 가 잘못 짠 reducer / store 는 reset 하면 안 �** — 인터럽트 child 의 design intent 가 들어있을 가능성이 매우 높다. 다만 명백한 버그 (예: type error, dead code, 잘못된 lifecycle) 는 patch 로 정정. **전체 reset 은 마지막 수단**.

### 18.8 — 최종 보고에 포함할 5가지 (★ 2026-08-04 Phase C 종료 시)

```markdown
## Phase C — 책 열기 인터랙션
- Date: 2026-08-04
- Commit: <sha>
- Deployment ID: hermes-knowledge-shelf-<hash>-sigco3111s-projects.vercel.app
- Free alias: https://hermes-knowledge-shelf.vercel.app (HTTP 200)
- Tests: 53/53 PASS (bookStateMachine 12 + spreads 5 + shelf 6 + materials 9 + privacy 12 + bookPlacement 9)
- Bundle: dist/assets/index-<hash>.js <bytes>B / <bytes>B gzip
- Screenshots: .verify/phase-c-live-{desktop,mobile}.png
- Vision QA: <vision_analyze 결과 — 3D 깊이감 OK, readable text OK, page nav 가독성 OK>
- Notes: <구현 결정 한 줄 — 예: "page navigation state machine driven by zustand; 3D scene subscribes via useFrame + useEffect setTimeout for lifecycle dispatches">
```

## 19단계 — 2단계 진입 준비