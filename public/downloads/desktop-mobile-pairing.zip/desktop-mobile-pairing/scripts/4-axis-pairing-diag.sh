#!/usr/bin/env bash
# 4-axis pairing diagnostics for desktop ↔ mobile apps
# 사용법: bash 4-axis-pairing-diag.sh <app-name> <port> [lan-ip]
# 예시:   bash 4-axis-pairing-diag.sh orca 6768 192.168.10.71

set -uo pipefail

APP="${1:-orca}"
PORT="${2:-6768}"
LAN_IP="${3:-}"
PASS=0; FAIL=0
pass() { echo "  [PASS] $1"; PASS=$((PASS+1)); }
fail() { echo "  [FAIL] $1"; FAIL=$((FAIL+1)); }

echo "=== AXIS 1: $APP 프로세스 상태 ==="
PROC=$(pgrep -fl "$APP" | grep -v "pgrep\|agent-hooks\|ShipIt" | wc -l | tr -d ' ')
[ "$PROC" -gt 0 ] && pass "$APP 프로세스 $PROC 개 살아있음" || fail "$APP 프로세스 없음"
pgrep -fl "$APP" | grep -v "pgrep\|agent-hooks\|ShipIt" | head -3 | sed 's/^/    /'

echo ""
echo "=== AXIS 2: 포트 $PORT listen + 바인딩 주소 ==="
LISTEN=$(lsof -nP -iTCP:"$PORT" -sTCP:LISTEN 2>/dev/null | tail -n +2)
if [ -n "$LISTEN" ]; then
  pass "포트 $PORT LISTEN 중"
  echo "$LISTEN" | head -2 | sed 's/^/    /'
else
  fail "포트 $PORT LISTEN 없음"
fi

echo ""
echo "=== AXIS 3: macOS Application Firewall (ALF) ==="
if [ "$(uname)" = "Darwin" ]; then
  STATE=$(/usr/libexec/ApplicationFirewall/socketfilterfw --getglobalstate 2>&1)
  STEALTH=$(/usr/libexec/ApplicationFirewall/socketfilterfw --getstealthmode 2>&1)
  echo "  global: $STATE"
  echo "  stealth: $STEALTH"
  echo "$STATE" | grep -q "disabled" && pass "방화벽 disabled" || fail "방화벽 enabled (모바일 연결 차단 가능)"
else
  echo "  [SKIP] macOS 외 환경"
fi

echo ""
echo "=== AXIS 4: LAN 자기 도달성 ==="
# loopback
if nc -z -G 3 127.0.0.1 "$PORT" 2>/dev/null; then
  pass "127.0.0.1:$PORT OPEN (loopback)"
else
  fail "127.0.0.1:$PORT CLOSED"
fi

# LAN IP (auto-detect if not provided)
if [ -z "$LAN_IP" ]; then
  LAN_IP=$(ifconfig 2>/dev/null | grep -E "inet " | grep -vE "127\.0\.0\.1" | awk '{print $2}' | head -1)
  echo "  auto-detected LAN IP: $LAN_IP"
fi

if [ -n "$LAN_IP" ]; then
  if nc -z -G 3 "$LAN_IP" "$PORT" 2>/dev/null; then
    pass "$LAN_IP:$PORT OPEN (LAN 자기 도달)"
  else
    fail "$LAN_IP:$PORT CLOSED (인터페이스 미스매치 의심)"
  fi
fi

echo ""
echo "=== AXIS 5: 활성 네트워크 인터페이스 ==="
if [ "$(uname)" = "Darwin" ]; then
  ifconfig 2>/dev/null | grep -B1 "inet " | grep -vE "127\.0\.0\.1|::1" | head -10 | sed 's/^/    /'
  INACTIVE=$(ifconfig 2>/dev/null | grep -B1 "status: inactive" | grep "^[a-z]" | head -3)
  if [ -n "$INACTIVE" ]; then
    echo ""
    echo "  ⚠️ inactive 인터페이스 발견:"
    echo "$INACTIVE" | sed 's/^/    /'
  fi
fi

echo ""
echo "=== AXIS 6: 라우터 도달성 ==="
ROUTER=$(echo "$LAN_IP" | awk -F. '{print $1"."$2"."$3".1"}')
if [ -n "$ROUTER" ]; then
  if ping -c 1 -W 2 "$ROUTER" 2>&1 | grep -q "1 received"; then
    pass "라우터 $ROUTER ping OK"
  else
    fail "라우터 $ROUTER ping fail"
  fi
fi

echo ""
echo "=== AXIS 7: 같은 서브넷 Apple OUI (iPhone/iPad 후보) ==="
SUBNET=$(echo "$LAN_IP" | awk -F. '{print $1"."$2"."$3}')
if [ -n "$SUBNET" ]; then
  APPLE_DEVICES=$(arp -an 2>/dev/null | grep "$SUBNET" | awk '{print $2, $4}' | while read ip mac; do
    case "${mac:1:8}" in
      "8c:1d:"*|"f0:18:"*|"f8:fe:"*|"ac:19:"*|"04:db:"*|"70:cd:"*|"60:33:"*|"78:7e:"*|"a4:5e:"*|"dc:a9:"*|"98:01:"*|"b8:78:"*) echo "$ip $mac" ;;
    esac
  done)
  if [ -n "$APPLE_DEVICES" ]; then
    pass "Apple OUI 디바이스 발견 (iPhone/iPad 후보)"
    echo "$APPLE_DEVICES" | sed 's/^/    /'
  else
    fail "Apple OUI 매치 0건 (iPhone이 다른 서브넷에 있을 가능성)"
  fi
fi

echo ""
echo "==============================="
echo "총 $((PASS+FAIL)) | PASS=$PASS | FAIL=$FAIL"
echo "==============================="

exit $FAIL