---
name: desktop-mobile-pairing
description: "데스크탑 앱(iPhone/iPad/Android 모바일 디바이스 페어링) 트러블슈팅. WebSocket timeout, QR 코드 페어링 실패, LAN 미스매치, '같은 네트워크인데도 안 됨' 증상. Orca / Cursor / VS Code Live Share / Expo Dev Client / Tailscale SSH / Pangaea 같은 데스크탑 ↔ 모바일 페어링 패턴 전반. 4축 진단(데몬/포트/방화벽/LAN 도달성) → LAN 미스매치 격리 → Tailscale 우회 워크플로."
version: 0.1.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [pairing, websocket, lan, tailscale, mobile, orca, device-control]
    related_skills: [direct-device-execution]
---

# Desktop ↔ Mobile Pairing Troubleshooting

데스크탑 앱(Orca, Cursor, VS Code Live Share, Expo Dev Client, Pangaea, Tailscale SSH 등)이 **모바일 디바이스와 페어링하지 못할 때** 체계적으로 진단하고 우회하는 클래스.

## 트리거 시그널

- "Orca 모바일 페어링 안 됨" / "Couldn't connect within 25s"
- "iPhone에서 QR 스캔했는데 timeout"
- "같은 Wi-Fi인데도 데스크탑 앱이 폰에서 안 보임"
- "WebSocket timeout — endpoint unreachable"
- "데스크탑 앱 모바일 페어링 — 다른 폰은 되는데 이 폰만 안 됨"
- 스크린샷에 빨간 timeout 에러 + "Try Again" / "Paste code instead" 버튼

## 절대 트리거 X

- 모바일 앱 자체 버그 리포트 (앱스토어 쪽)
- 데스크탑 앱 클라우드 계정 인증 문제 (페어링과 무관)
- USB 테더링/외부 디스플레이 등 물리 연결 이슈

## 핵심 워크플로 (5단계)

### 1단계: 4축 동시 진단 (1분)

데스크탑 측에서 **데몬 / 포트 / 방화벽 / LAN 도달성** 4축을 한 번에 측정:

```bash
# === AXIS 1: 데몬 프로세스 살아있나 ===
pgrep -fl <app> | head -10

# === AXIS 2: 페어링 포트 listen + 정확한 바인딩 주소 ===
lsof -nP -iTCP:<port> -sTCP:LISTEN
# 또는 BSD netstat (root 불필요)
netstat -an -p tcp | grep "\.<port>" | grep "LISTEN"

# === AXIS 3: macOS Application Firewall (ALF) ===
/usr/libexec/ApplicationFirewall/socketfilterfw --getglobalstate
/usr/libexec/ApplicationFirewall/socketfilterfw --getstealthmode
/usr/libexec/ApplicationFirewall/socketfilterfw --getblockall

# === AXIS 4: LAN 자기 도달성 (loopback + 실제 LAN IP 둘 다) ===
nc -z -G 3 127.0.0.1 <port>     # loopback (로컬 자체 테스트)
nc -z -G 3 <lan-ip> <port>      # LAN IP (iPhone 시점 시뮬레이션)

# === AXIS 5 (보너스): 활성 인터페이스 + IP ===
ifconfig | grep -B1 "inet " | grep -vE "(127\.0\.0\.1|::1)"
```

**판정 기준**:

| 결과 | 의미 |
|---|---|
| 데몬 + 포트 + LAN 자기 도달 모두 OK | 데스크탑 측 정상 → 2단계로 |
| 포트 listen인데 LAN IP 도달 CLOSED | 인터페이스 미스매치 (en0 inactive + en1 active 등) → 인터페이스 진단 |
| ALF ON + 비번 입력 막힘 | macOS 방화벽이 모바일 연결 차단 → 방화벽 룰 추가 또는 비번 입력 |
| 데몬 자체 죽어있음 | 1단계 트리거보다 데몬 기동부터 |

### 2단계: LAN 미스매치 격리 (iPhone이 정말 같은 LAN?)

4축 모두 OK인데도 iPhone이 못 붙으면 **LAN 미스매치** 가능성 90%.

```bash
# === 라우터 도달성 (LAN 연결 자체 확인) ===
ping -c 1 -W 2 <router-ip>     # 보통 .1 게이트웨이

# === en0 vs en1 인터페이스 상태 ===
ifconfig en0 | grep -E "(status|inet)"
ifconfig en1 | grep -E "(status|inet)"
# "status: inactive" → 그 인터페이스는 LAN에 안 붙어있음

# === 저장된 Wi-Fi SSID (어느 AP에 붙었었나) ===
networksetup -listpreferredwirelessnetworks en1

# === 같은 서브넷 살아있는 디바이스 ===
arp -an | grep "<subnet>" | head -10

# === iPhone MAC vendor 패턴 (Apple OUI prefix) ===
# Apple OUI: 8c:1d:96, f0:18:98, f8:fe:5e, ac:19:8e, 04:db:56, 70:cd:60, 60:33:4b, 78:7e:61
arp -an | awk '{print $2, $4}' | while read ip mac; do
  case "${mac:1:8}" in
    "8c:1d:"*|"f0:18:"*|"f8:fe:"*|"ac:19:"*|"04:db:"*|"70:cd:"*) echo "Apple: $ip $mac" ;;
  esac
done
```

**핵심 진단 시그널**:

| 증상 | 진단 |
|---|---|
| en0 inactive + en1 active인데 LAN ping fail | Wi-Fi 연결 끊겼음 (single-instance lock 패턴 — 앱이 죽은 IP에 매달림) |
| 라우터 ping OK + en0/en1 둘 다 active | 같은 LAN인데 iPhone이 다른 Wi-Fi / 셀룰러에 있을 가능성 |
| Apple OUI 매치 0건 | iPhone이 ARP 캐시에 없음 → 다른 서브넷에 있음 |
| `lastSeenAt: 0` (Orca의 devices.json 등) | 페어링 토큰은 발급됐는데 실제 WebSocket handshake 실패 → LAN 도달 불가 |

### 3단계: 데스크탑 앱 페어링 모드 진입

데스크탑 앱마다 모바일 페어링 모드 진입 방법이 다름. **CLI 옵션이 있으면 헤드리스 모드 우선** (background, 로그 캡처 용이):

| 앱 | CLI 페어링 모드 |
|---|---|
| **Orca** | `orca serve --mobile-pairing --pairing-address <lan-or-ts-ip>` |
| **Cursor** | GUI: Settings → Mobile → QR (CLI 옵션 없음) |
| **VS Code Live Share** | GUI 시작, 모바일 앱에서 invite code 입력 |
| **Expo Dev Client** | `expo start --tunnel` (LAN 우회 모드) |
| **Tailscale SSH** | `tailscale up` + iPhone Tailscale 앱 설치 |

**Orca 같은 Electron 앱** 종료/기동 패턴:
```bash
# 1) 데스크탑 앱 종료 (osascript → killall TERM → KILL fallback)
osascript -e 'tell application "<App>" to quit'
sleep 2
killall -TERM <App>
sleep 2
killall -KILL <App>  # 사용자가 prompt 응답 안 할 때만

# 2) 페어링 모드로 백그라운드 기동
/opt/homebrew/bin/orca serve --mobile-pairing --pairing-address <ip>

# 3) 5~10초 후 검증
lsof -nP -iTCP:<port> -sTCP:LISTEN
/opt/homebrew/bin/orca status --json  # runtime.ready 확인
```

### 4단계: LAN 미스매치 해결 — Tailscale 우회

LAN 미스매치 확정 시 **Tailscale이 가장 빠른 근본 해결** (LAN/Wi-Fi/AP격리/이더넷 케이블 모두 무관).

**Tailscale 비대화 패턴** (상세: `direct-device-execution` P18):

```bash
# 1) CLI 설치 (formula, 비대화 OK)
brew install tailscale

# 2) userspace 데몬 기동 (root 불필요)
mkdir -p "/Users/mac/Library/Application Support/Tailscale"
/opt/homebrew/bin/tailscaled \
    --tun=userspace-networking \
    --statedir="/Users/mac/Library/Application Support/Tailscale" \
    --socket="/Users/mac/Library/Application Support/Tailscale/tailscaled.sock"

# 3) 사용자가 브라우저로 auth key 발급 (https://login.tailscale.com/admin/settings/keys)
#    → 생성된 tskey-auth-XXXX 받음

# 4) 비대화 인증
/opt/homebrew/bin/tailscale --socket="..." up --authkey=<key>

# 5) Tailscale IP 추출
/opt/homebrew/bin/tailscale --socket="..." ip -4
# → 100.x.x.x

# 6) 데스크탑 앱 페어링 모드로 재기동 (Tailscale IP 전달)
orca serve --mobile-pairing --pairing-address 100.x.x.x

# 7) iPhone Tailscale 앱 설치 + 같은 계정 로그인 → 즉시 같은 100.x 사설망 진입
```

**Tailscale 한계**:
- userspace-networking 모드 = 성능 ~30% 느림 (페어링/제어용은 OK, P2P 게임/스트리밍엔 부족)
- 양쪽 디바이스 모두 Tailscale 앱/계정 필요

### 5단계: 페어링 검증 + 사용자 보고

```bash
# === 데스크탑 측: 새 페어링 device 등록 확인 ===
# (Orca 예시)
cat "/Users/mac/Library/Application Support/orca/orca-devices.json" | python3 -m json.tool
# → 새 deviceId + pairedAt (최근 시각)
# → lastSeenAt > 0 이면 연결 성공!

# === iPhone 측 (사용자 액션) ===
# - Orca 앱: QR 스캔 OR "Paste code instead" → orca://pair?... URL 붙여넣기
# - Tailscale 켜고 Orca 앱 재시도

# === 실패 시 추가 진단 ===
# iPhone에서 같은 서브넷/Ping으로 이 PC 도달 가능한지
# Orca 데몬 로그: tail -f "/Users/mac/Library/Application Support/orca/logs/..."
```

## 자주 하는 실수 4가지

1. **데스크탑 측 데몬/포트만 확인하고 끝** — 4축 중 LAN 자기 도달성 (`nc -z 192.168.x.x port`)을 빠뜨리면 인터페이스 미스매치를 놓침.
2. **iPhone 측 Wi-Fi 상태 미확인** — 같은 Wi-Fi라고 사용자 말만 믿지 말고 ARP/OUI로 직접 확인.
3. **Tailscale 비대화 로그인을 `tailscale up` 한 줄로 시도** — 브라우저 OAuth 띄우려다 hang. auth key 발급 + `up --authkey=` 가 유일한 비대화 루트.
4. **사용자 보고 시 "포트 listen OK"만 적음** — `lastSeenAt` 갱신이 진짜 성공 지표. 포트 + 토큰 발급 ≠ 실제 연결.

## Pitfalls

### P1. Orca 페어링 시도 흔적 — `lastSeenAt: 0` 의 의미

- `orca-devices.json`에 새 device가 등록되어도 `lastSeenAt: 0` 이면 **WebSocket handshake 실패**.
- 토큰만 발급되고 실제 통신 1회도 성공 못 함 → LAN 도달 불가 의미.
- `pairedAt` 시간만 보고 "방금 페어링 시도했다"는 사실 확인 가능하지만 **성공 ≠ 토큰 발급**.

### P2. 성공한 PC의 인터페이스 ≠ 이 PC의 인터페이스 함정

- "다른 PC는 되는데 이 PC만 안 됨" → 그 PC가 어떤 인터페이스(en0/en1)로 LAN 붙었는지 확인 필요.
- 이 PC가 **Wi-Fi 끊겼는데 데몬은 죽은 IP에 매달린 채 listen**하면 외부에선 살아있는 것처럼 보이지만 실제 패킷 도달 불가.
- 해결: `ifconfig` 으로 모든 인터페이스 상태 점검 → active한 인터페이스 IP가 데몬 listen IP와 일치하는지.

### P3. Electron 단일 인스턴스 lock — `Another Orca instance is already running`

- `orca serve --mobile-pairing` 실행 시 "Another Orca instance is already running for this userData profile" 에러 → 기존 데스크탑 앱이 살아있어서 fail.
- 해결: `osascript -e 'tell application "Orca" to quit'` → killall TERM → KILL fallback 순서로 깔끔히 종료 후 serve 모드 기동.
- 검증: `pgrep -fl "/Applications/Orca.app/Contents/MacOS/Orca$|daemon-entry"` (정확한 PID 매칭)

### P4. `experimentalMobile` 같은 GUI 토글은 CLI 모드와 무관

- Orca의 `experimentalMobile: false` 설정은 데스크탑 앱 Mobile UI 토글. `orca serve --mobile-pairing` 헤드리스 모드에선 무관하게 페어링 가능.
- **흔한 오해**: settings 파일에서 토글해야 페어링 활성화된다고 믿음 → 실제론 CLI 플래그가 우선.

## 시나리오 3가지

### A. Orca iPhone 페어링 (이번 세션 검증)

```bash
# 1) 4축 진단 → en0 inactive + en1 active, 포트 listen 정상, 데몬 OK
# 2) iPhone이 같은 LAN인지 사용자 확인 → 다른 Wi-Fi일 가능성
# 3) 데스크탑 앱 종료 → orca serve --mobile-pairing --pairing-address 192.168.10.71
# 4) iPhone에서 Orca 앱 → Settings → Mobile → Scan QR (or Paste code)
# 5) 또는: Tailscale 설치 → auth key 발급 → 양쪽 Tailscale → 100.x.x.x 로 재페어링
```

### B. Cursor Mobile (실제 페어링 옵션 없음)

- Cursor는 mobile pairing 공식 옵션 없음 → **사용자한테 "데스크탑 GUI에서 직접" 안내**
- 비대화 환경에서 우회 불가 → 사용자가 Cursor 앱 열고 Settings 진입해야 함

### C. Expo Dev Client (Tunnel 모드)

```bash
# Tunnel 모드는 LAN 자체를 우회 (ngrok 같은 외부 터널)
npx expo start --tunnel
# → 출력된 URL을 iPhone Expo Go 앱에서 입력
# LAN 미스매치 무관, 단 인터넷 연결 필수
```

## 사용자 보고 템플릿

```markdown
## 페어링 진단 결과

### 1단계: 4축 진단 결과
| 축 | 결과 |
|---|---|
| 데몬 프로세스 | ✅ PID 10254 / ❌ 죽어있음 |
| 포트 6768 listen | ✅ tcp *:6768 |
| macOS 방화벽 | ✅ Disabled |
| LAN 자기 도달 | ✅ 192.168.10.71:6768 OPEN |

### 2단계: LAN 미스매치 격리
- en0(이더넷): status inactive
- en1(Wi-Fi): status active, inet 192.168.10.71
- 라우터(192.168.10.1) ping: ✅
- 같은 서브넷 Apple OUI: 0건 ← iPhone이 다른 LAN에 있음

### 3단계: 권장 해결
- **A. Tailscale 설치 (근본 해결, 5분)**: 양쪽 사설망 100.x.x.x → LAN 무관
- **B. iPhone을 같은 Wi-Fi로 이동 (즉시, 사용자 액션)**: UBOB/hjshin_5G/HiDaroo/FFi15Pro 중 하나로
- **C. 이 PC 이더넷 케이블 연결**: 성공한 PC와 동일 환경 재현
```

## 관련 스킬

- `direct-device-execution` P7/P8/P8a/P12/P13/P18 — brew 비대화 sudo, Tailscale 비대화 패턴, PTY + OAuth fallback
- `hermes-gateway-doctor` — Telegram 워커 sticky IP / 큐 막힘 (페어링 후 모바일 알림이 안 올 때 참고)

## 📚 References & Scripts

- `scripts/4-axis-pairing-diag.sh` — 4축 + 인터페이스 + 라우터 + Apple OUI ARP 진단을 1회 실행으로. 사용법 `bash 4-axis-pairing-diag.sh <app> <port> [lan-ip]`. 예시 `bash 4-axis-pairing-diag.sh orca 6768 192.168.10.71`.

## 변경 이력

| 날짜 | 버전 | 내용 |
|---|---|---|
| 2026-07-08 | v0.1.0 | 초기 작성. Orca iPhone 페어링 트러블슈팅 세션 검증. 5단계 워크플로 (4축 진단 → LAN 미스매치 격리 → 페어링 모드 진입 → Tailscale 우회 → 검증) + 4가지 함정 (lastSeenAt 의미, 인터페이스 미스매치, Electron single-instance lock, experimentalMobile GUI 토글 함정). |