---
name: skill-lifecycle
description: 스킬 라이프러리 사용 패턴 진단 + 분류표 제시 + 비활성 후보 선별 워크플로우. skills_list가 비대해진 상황에서 "어떤 스킬이 진짜 죽었나?" 분류가 필요할 때 진입. .archive 폴더의 정체(버저닝 vs 폐기 혼재) 해명, L0/L1 메모리 인덱스 매칭으로 진짜 활성 vs 휴면 vs 폐기 3분류.
version: 1.0.0
author: ICBM2
metadata:
  hermes:
    tags: [skills, lifecycle, audit, inventory, cleanup]
---

# 스킬 라이프사이클 관리 (Skill Lifecycle)

## 트리거 조건

다음 중 **하나라도** 해당하면 진입:

- `~/.hermes/skills/` 에 SKILL.md가 **100개 이상** 누적
- 사용자가 "스킬이 너무 많다 / 정리하자 / 비활성" 명시 요청
- `skills_list` 컨텍스트 부하가 매 세션 의미 있게 발생 (수 KB+)
- `.archive/` 폴더에 20개+ 스킬 누적 (정체 불명)
- 메모리 한도 압박 → L0/L1에 14개+ 스킬 인덱싱 → 그 외 패턴 파악 필요
- **🆕 2026-07-13 신규**: 사용 패턴 데이터 없이 추측으로 비활성 처리하는 함정 회피

## 핵심 원칙: 추측 금지, 데이터 우선

**❌ 절대 하지 말 것**:
- 이름/카테고리만 보고 "안 쓸 것 같다" 추측 → 폐기
- mtime만 보고 "오래됐다" 판단 → sync 타임스탬프일 수 있음 (실측 결과)
- description 없는 스킬 = 죽었다 → 누락일 수 있음

**✅ 반드시 데이터로 판단**:
- L0/L1 메모리 인덱스에 매칭되는가? (필수 활성 신호)
- 다른 active 스킬과 중복되는가? (중복 가능성)
- `.archive/`에 동일 이름이 있는가? (버저닝 가능성)
- 카테고리/명명에 의심 패턴이 있는가? (휴리스틱)

## 4단계 절차

### 1단계: 전수 카운트 + 카테고리 분포

```bash
# 전체 SKILL.md
find ~/.hermes/skills -name 'SKILL.md' | wc -l

# 카테고리별
find ~/.hermes/skills -name 'SKILL.md' | sed 's|.*/skills/||' | awk -F/ '{print $1}' | sort | uniq -c | sort -rn

# .archive 별도 카운트
find ~/.hermes/skills/.archive -name 'SKILL.md' | wc -l
```

### 2단계: 4가지 데이터 소스 교차 검증

| 데이터 소스 | 위치 | 신호 | 한계 |
|---|---|---|---|
| **메모리 인덱스** | `~/.hermes/memories/MEMORY.md` + `topics/*.md` | 필수 활성 (확정 신호) | 인덱싱 안 된다고 죽은 건 아님 |
| **크론 잡 참조** | `~/.hermes/cron/*.yaml` + jobs.json | 활성 (강한 신호) | cron 없는 스킬은 미감지 |
| **다른 active 스킬 중복** | `~/.hermes/skills/` (active 내) | 중복/대체 가능성 | 의도적 다중 버전일 수도 |
| **`.archive` 중복** | `~/.hermes/skills/.archive/` | **버저닝 vs 폐기 혼재** | 메타데이터 없음 |

**핵심 발견 (2026-07-13)**: `.archive/`는 **두 가지 의미**가 혼재:
- **버저닝 백업** (active에 신버전, archive에 옛버전) → 유지
- **진짜 폐기** (archive에만 존재) → 후보

**구분법**: `comm -12 active_names archived_names` → 이름 중복 = 버저닝. `comm -13 active_names archived_names` → archive 전용 = 폐기 후보.

### 3단계: 4가지 카테고리 분류표 제시

| 카테고리 | 정의 | 개수 (2026-07-13 실측) | 조치 |
|---|---|---|---|
| 🟢 **필수 활성** | L0/L1 인덱스 매칭 | 14개 | 절대 유지 |
| 🟡 **휴면 후보** | active + 미인덱싱 + 의심 카테고리 | 174개 | 사용자 판단 필요 |
| 🟠 **버저닝** | .archive + active 중복 | 20개 | 그대로 유지 |
| 🔴 **폐기 후보** | .archive 전용 | 33개 | `_decommission_<date>/` 이동 (rm ❌) |

**사용자에게 분류표 제시** 후 결정 받기. 위임 시 4번째 옵션.

### 4단계: 폐기 실행 (저위험 경로)

**🆕 2026-07-13 신규 원칙**: 폐기 후보는 **즉시 rm ❌**, 안전 폴더로 이동.

```bash
# 1) 안전 폴더 생성 (날짜 스탬프)
mkdir -p ~/.hermes/skills/_decommission_$(date +%Y-%m-%d)

# 2) 폐기 후보만 이동 (.archive 전용 33개)
mv ~/.hermes/skills/.archive/<name>/ ~/.hermes/skills/_decommission_<date>/

# 3) 14일 후 문제 없으면 rm
# (memory-hygiene 또는 nightly-maintenance-workflow가 다시 정찰)
```

## 진단 스크립트 (재사용 가능)

전수 진단 1회 = 약 5분. 다음 세션에서 재사용:

```bash
# 진단만 (read-only, 안전)
python3 << 'PYEOF'
import os, subprocess
from pathlib import Path

def sh(cmd): return subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=15).stdout.strip()

active = sh("find ~/.hermes/skills -maxdepth 3 -name SKILL.md | grep -v '/.archive/'").splitlines()
archived = sh("find ~/.hermes/skills/.archive -maxdepth 2 -name SKILL.md").splitlines()
active_names = {os.path.basename(os.path.dirname(p)): p for p in active}
archived_names = {os.path.basename(os.path.dirname(p)): p for p in archived}

overlap = set(active_names.keys()) & set(archived_names.keys())
only_archived = set(archived_names.keys()) - set(active_names.keys())

print(f"Active: {len(active_names)}, Archived: {len(archived_names)}")
print(f"이름 중복 (버저닝): {len(overlap)}")
print(f"archive 전용 (폐기 후보): {len(only_archived)}")
PYEOF
```

## Pitfall (실측 기반)

### 1. mtime = 사용 패턴 ❌ (2026-07-13 실측)

188개 active 모두 30일 이내 수정됨. **sync 타임스탬프**이지 실제 사용이 아님.

### 2. description 없는 스킬 = 죽음 ❌

이번 실측에서 active 188개 모두 description 있음. 누락은 있을 수 있으나 신호 약함.

### 3. 카테고리 적음 = 미사용 ❌

`leisure (1개)`, `mcp (2개)` 처럼 작은 카테고리도 정당한 니치.

### 4. `.archive` = 모두 폐기 ❌

20개는 active와 중복 = **버저닝 백업** (옛 버전 보존 가치). 즉시 삭제하면 사고.

### 5. 외부 플러그인 의심 (미해결)

`impeccable-*` 14개는 디자인 보조 라이브러리 — npm 의존성 체크 안 됨. **삭제 전 의존성 확인 권장**.

### 6. 즉시 rm 사고 위험

`automation-decommission` 원칙: 시크릿은 trash, 코드는 rm. **스킬은 14일 안전 폴더 후 rm** (이 스킬의 새 원칙).

### 7. L0/L1 인덱스 14개 절대 보호

`vercel`, `toss-trader-dev`, `coding-mission-fullcycle` 등 14개는 **메모리에서 명시 참조** → 삭제 시 다음 세션 L1 fetch 실패 → 워크플로우 함정 못 만남.

## 4가지 데이터 소스 외 보조 신호 (선택적)

| 신호 | 사용법 | 위험도 |
|---|---|---|
| **명명 휴리스틱** (`wip`, `draft`, `old` 등) | 의심 패턴 → 후보 | 낮음 (오탐 가능) |
| **30줄 이하 SKILL.md** (스텁) | 부실 = 워크플로우 없음 | 중간 (단순 의도 가능) |
| **description 없음** | 메타 누락 | 낮음 |
| **세션 DB skill_view 호출 빈도** | 진짜 사용 패턴 | **DB 부재 시 사용 불가** |

## 한도 초과 시 우선순위

`skills_list` 컨텍스트 부하가 매 세션 ~수 KB:
- 100개+: 진단 권장
- 150개+: 비활성 처리 권장
- 200개+: 강제 진단 (사용자 알림)

## 관련 스킬

- **`automation-decommission`**: 사용자 결정 기반 컴포넌트 폐기 (시크릿/크론/스크립트/메모리 4곳 동시 정리). skill-lifecycle 결과가 "폐기 후보"로 나오면 연결.
- **`automation-audit-ops`**: audit 결과가 "cut"이면 → decommission. skill-lifecycle은 그 앞 단계 (사용 패턴 진단 + 분류표).
- **`automation-healthcheck`**: health monitoring 중심. skill-lifecycle은 lifecycle 관리.
- **`memory-hygiene`**: L0/L1 인덱스 매칭 데이터 소스 제공.

## 실행 기록 (references/)

- `references/2026-07-13-skill-audit-262.md` — 262개 스킬 전수 진단 (14 필수 + 174 휴면 + 20 버저닝 + 33 폐기 후보 4분류).