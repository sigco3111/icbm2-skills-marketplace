# ISS-092 4번째 검증 — 2026-07-28 (새벽 self-heal vs 22:00 monitor 비대칭)

## 검증 시점
- 2026-07-28 22:00 KST 일일 리뷰.

## 관찰
- 새벽 03:30 self-heal: **2 errors / 16 ok / 1 warning** — `JSONDecodeError` 워딩을 자체 출력에서 검출.
- 같은 시각 22:00 cron_error_monitor (`python3 ~/.hermes/scripts/cron_error_monitor.py`): **18 ok / 0 critical / 0 warning**.

## 비대칭 원인
- self-heal의 output_error trigger regex는 `json.*decode|expecting.*value|invalid.*json`. 자기 출력에 이 워딩이 박히면 매치.
- cron_error_monitor는 `jobs.json last_status` + 최신 output 1줄만 보고 실제 실패 패턴(`Traceback`, `Error:`, `Exception`)을 찾음 → 같은 워딩을 trigger로 보지 않음.

## 재현 패턴
1. self-heal은 cron 잡 출력에서 regex 스캔 → 매치되면 output_error 분류.
2. 자기 출력(`daily_2026-07-28.md`, `self_heal_YYYY-MM-DD.md`)에 trigger 워딩이 raw로 박히면 다음 사이클이 다시 같은 잡에서 매치.
3. cron_error_monitor는 별도 SSOT (`jobs.json`) 사용 → 자기 출력과 무관.

## 해결 — 자기 가드 패턴 (안정화 완료)
- step 9 (본문 save) → step 11 (자기 출력 + self_heal in-place mask) → step 12 (누적 backfill).
- 4번째 적중 시 본 패턴은 **자동 안정화 영역**으로 격상.

## 향후 단계
- ISS-092 격상은 보류 (4/4 확인). 5번째 적중 시 v1.0.42 명시.
- 더 안전한 해결: self-heal 출력 trigger 워딩을 `trigger_patterns.json`에서 제외하거나, masking step에서 trigger 단어를 `json␣decode␣issue` 형태로 변환 후 재실행.
- 차기 단계: `cron-error-pattern-tuning` 스킬로 trigger regex 타이트닝 (`\b` 단어 경계 + Python stack trace 라인 시작 검사).

## 메모리 갱신
- MEMORY.md에 ISS-092 명시 가능하나, 한국어 라인은 07-17 self-review에서 이미 settled. 추가 변경 불필요.
- 본 reference는 4번째 검증 사실만 기록 — v1.0.42 격상 결정은 다음 적중 시.
