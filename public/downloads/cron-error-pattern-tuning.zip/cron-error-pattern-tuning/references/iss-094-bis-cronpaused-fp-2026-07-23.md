# ISS-094-bis 실전 사례 (2026-07-23)

## 증상

```text
22:00 self-heal dry-run: 1 error / 1 warning
- ERROR: 출력에서 CronPaused state issue 감지 — 패턴 매치: r"(?:...)"
  job: "🛡️ 심야 통합 점검 (정비+에러)"
- WARNING: notion-outage-watch-3h 의도된 disabled (정상)

monitor 22:00: 19 ok / 0 critical / 0 warning
self-heal 03:30: 0 errors / 1 warning (비대칭)
```

## Root Cause

`cron_self_healer.py:191` — 단어 경계 없는 substring regex:

```python
("CronPaused", r"(?:paused|disabled|stopped)", "CronPaused"),
```

자기 보고서 L55의 정상 한국어 텍스트 `의도된 disabled` (의도된 + disabled) 가 trigger.

## 비대칭 root cause 분석

```text
03:30 self-heal:
  - job_id="81f1c81f8664" 의 가장 최근 output = "2026-07-22_03-38-13.md"
  - 03:30 시점에 자기 자신의 03:31 보고서 아직 작성 전
  - 어제 보고서만 스캔 → 0 errors

22:00 self-heal:
  - job_id="81f1c81f8664" 의 가장 최근 output = "2026-07-23_03-32-41.md"
  - 자기 보고서(03:31) 가 누적된 상태
  - L55 disabled 가 trigger → 1 error FP
```

## 변경된 trigger regex (A안)

```python
# 변경 후
("CronPaused",
 r"""(?:
     jobs\.json.*state.*paused
   | state\s*=\s*['\"]?paused
   | state\s*=\s*['\"]?disabled
   | state\s*=\s*['\"]?stopped
   | status:\s*paused
   | status:\s*disabled
   | status:\s*stopped
   | cron\s*job\s*paused
   | job\s*is\s*paused
   | job\s*is\s*disabled
   )""",
 "CronPaused"),
```

## 검증 (패치 시)

```bash
python3 -m py_compile ~/.hermes/scripts/cron_self_healer.py
python3 ~/.hermes/scripts/cron_self_healer.py --dry-run
# 기대: errors 0 / warnings 1 (의도된 notion-outage) / fixes 0
# 81f1c81f8664 의 03:32 output도 trigger 안됨

python3 ~/.hermes/skills/automation/nightly-maintenance-workflow/scripts/verify_self_healer_patch.py --status
# 기대: 4/4 jobs clean
```

## 다음 일정

- 7/24 step 6: 동일 FP 재현 → RFC 유지
- 7/25 step 6: 동일 FP 재현 → references에 2번째 적중 명시
- 7/26 step 6: 동일 FP 3번째 적중 → A안 패치 + verify
- 7/27 step 6: 패치 후 0 errors 유지 확인
- 7/28: ISS-094-bis closed, references/historical/ 이동

## 일일 리뷰 로그

| 날짜 | step 6 self-heal errors | 비고 |
|------|------------------------|------|
| 7/23 03:30 | 0 | 03:31 자기 보고서 작성 전 |
| 7/23 22:00 | 1 (FP) | 03:31 L55 disabled → trigger |
| 7/24 ? | ? | 일일 리뷰 step 6 추적 |
