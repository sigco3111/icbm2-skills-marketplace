---
name: cron-error-pattern-tuning
description: ICBM2 cron_self_healer.py trigger regex 튜닝 — CronPaused/ContextOverflow/PermissionError FP 적중 시 안전한 tightening. 출력 SSOT가 아닌 1차 raw trigger의 단어 경계 (\\b) 명시 + 정황 패턴 요구 형태로 진화. ISS-089 masking / ISS-094 FP / ISS-094-bis 후속.
version: 0.1.0
author: ICBM2
metadata:
  hermes:
    tags: [cron, self-healer, regex, fp-tuning, automation]
    last_updated: "2026-07-23"
---

# Cron Error Pattern Tuning

## 개요

`cron_self_healer.py` 의 trigger regex 가 self-heal 단계에서 1차 raw trigger 의 substring 검출을 하다 보니 자기 보고서 안의 정상 단어까지 잡음. 이 스킬은 **`trigger regex 의 단어 경계 추가 + 정황 패턴 요구`** 형태로 FP를 줄이는 패턴 진화 가이드.

## 사용 시점

1. self-heal/dry-run 에서 동일 FP가 3번째 적중 (예: ISS-094-bis CronPaused)
2. trigger 가 정상 리포트 단어를 substring 매치로 검출
3. mask 동작은 정상 (ISS-089) 이지만 raw 검출 단계에서 FP 발생

## 3단계 검증 절차

### Step 1: FP root cause 확인

```bash
# self-heal dry-run + 출력 grep
python3 ~/.hermes/scripts/cron_self_healer.py --dry-run 2>&1 | grep -E 'pattern|error'
# 어떤 line의 어떤 trigger가 잡혔는지 확인
grep -nE 'paused|disabled|stopped' ~/.hermes/cron/output/<job_id>/<latest>.md | head -3
```

### Step 2: 단어 경계 + 정황 패턴 요구 형태로 tightening

```python
# 변경 전 (FP-prone)
("CronPaused", r"(?:paused|disabled|stopped)", "CronPaused"),

# 변경 후 (명시적 정황 패턴)
("CronPaused",
 r"""(?:
     jobs\.json.*state.*paused
   | state\s*=\s*['\"]?paused
   | state\s*=\s*['\"]?disabled
   | status:\s*paused
   | status:\s*disabled
   | cron\s*job\s*paused
   | job\s*is\s*paused
   | job\s*is\s*disabled
   )""",
 "CronPaused"),
```

### Step 3: verify_self_healer_patch 4/4 PASS

```bash
python3 -m py_compile ~/.hermes/scripts/cron_self_healer.py
python3 ~/.hermes/scripts/cron_self_healer.py --dry-run
python3 ~/.hermes/skills/automation/nightly-maintenance-workflow/scripts/verify_self_healer_patch.py --status
```

## regex self-reference 주의

치환 문자열 자체가 다시 패턴에 걸리면 무한매치 위험: `cron␣paused␣issue` 가 `paused` 를 포함해 재매칭되면 `cron␣state␣issue` 로 교체. (ISS-089 패턴)

## 보류/패치 결정 가이드

| 조건 | 결정 |
|------|------|
| 1번째 적중 | 🟡 RFC만, 즉시 패치 보류 |
| 2번째 적중 (7/24~7/25) | 🟡 RFC 유지, references 갱신 |
| 3번째 적중 (≥7/26) | 🔴 패치 + verify + ISS-closed |

## 보류 사유

1. `enabled=False` disabling 검사가 §4 에서 이미 의도된 disabled 잡 검출 (§3 trigger regex 제거 시 회귀 우려)
2. self-heal의 `0 errors / 1 warning`가 보수적 잡음 포함. 0 errors 달성에 의존하면 실제 사고 누락
3. 1 error FP/일은 사람이 검증 (일일 리뷰가 매번 잡음)

## 검증 시 self-heal 0 errors 의 비대칭 기억

- 03:30 self-heal: 자기 보고서(03:31) 작성 전 → 0 errors (partial measurement)
- 22:00 self-heal: 자기 보고서 누적 → 1 error FP

일일 리뷰 step 6의 errors count diff 가 항상 비대칭을 보일 수 있음. ISS-092 3번째 적중 패턴.

## ISS-094-bis 사례 (2026-07-23)

| 항목 | 내용 |
|------|------|
| Trigger | `CronPaused` |
| Raw regex | `r"(?:paused\|disabled\|stopped)"` |
| FP 원인 | 자기 보고서 L55의 `의도된 disabled` 한글 조사 + disabled |
| 03:30 vs 22:00 | 0 errors vs 1 error (비대칭) |
| Mask 동작 | ISS-089 `\b(?:paused\|disabled\|stopped)\b` → `cron␣state␣issue` 정상 |
| 워크어라운드 | RFC: ≥07-26 3번째 적중 시 위 A안 패치 |

## 다른 trigger 의 동일 패턴 위험

| Trigger | Raw regex | FP 위험 |
|---------|-----------|---------|
| `FileNotFoundError` | `r"(?:file\|path\|directory).*(?:not found\|does not exist\|no such file)"` | 정상 리포트의 "no such file: <path>" 인용 시 FP |
| `PermissionError` | `r"(?:permission denied\|cannot open\|access denied)"` | 정상 리포트의 "permission denied" 단어 인용 시 FP |
| `TimeoutError` | runtime subject + timeout (ISS-094 수정됨) | 역사 요약 단어 제외 OK |
| `MemoryError` | word boundary + 명시 (ISS-058 수정됨) | 안전 |
| `ContextOverflow` | `r"(?:context.*overflow\|context.*exceeded\|token.*limit\|too long)"` | "context exceeded the limit" 정상 사용 시 FP |
| `CronPaused` | `r"(?:paused\|disabled\|stopped)"` | **FP 확인 (ISS-094-bis)** |

## 영향 평가 템플릿

- 사용자 영향: 0-저 (1 error FP/일, 사람의 일일 리뷰가 검증)
- 시스템 영향: 낮음 (동일 알림 가치)
- 알림 가치: 0-저 (ISS-086-ext 같은 진짜 활성 이슈를 drown하지 않는지 확인)

## 일일 리뷰 작업과의 결합

1. 일일 리뷰가 FP 1건 발견 → references/iss-094-bis-* 작성 (이 스킬 패턴)
2. 다음 일일 리뷰 step 6에서 동일 FP 적중 → RFC 단계 유지
3. 3번째 적중 → 이 스킬 step 2-3 따라서 패치
4. 패치 후 verify_self_healer_patch 4/4 PASS 확인
5. ISS-closed → references/historical/ 로 이동

## 검증

- 패치 후 즉시 dry-run: errors 0 / warnings 1 (의도된 notion-outage) / fixes 0
- 24시간 후 새벽 self-heal 0 errors 유지
- 1주일 후 일일 리뷰 7건에서 동일 FP 0건 확인

---

## ISS-095 "업로드" 신호 = readiness probe 게이트 (2026-07-24, NotebookLM 파이프라인)

**증상**: NotebookLM 후보 cron이 16:00 → 사용자가 5개 선택 신호 → "업로드" 단발 신호. 내 자동 패턴이 `notebooklm_upload.py`를 즉시 실행했으나, 그 전에 **비디오 오버뷰 generate + 완료 대기**가 빠져 있었음. `download video --latest` 호출 → completed video artifact 0개 (전부 pending) → 빈 디렉토리 → upload.py fail. 사용자가 "**항상 하던 일인데, 오늘 왜 그럼?**" 반응.

**근본 원인**:
- `notebooklm generate video`는 fire-and-forget. Started ID만 반환하고 즉시 종료.
- 5개를 연속으로 generate하면 모두 **pending** 상태.
- upload.py가 `download video --latest`로 받는데 **latest = pending**이면 fail.

**학습 - 5단계 readiness probe (사용자 단발 신호 처리 표준)**:
1. 사용자 신호가 가리키는 최종 단계까지의 중간 단계 나열
2. 각 단계의 실제 실행 로그/결과 확인 (`artifact list --json`)
3. 빠진 단계 발견 시 정직 보고 (fabricate 금지)
4. 진행 결정은 사용자 선택 (A: 기존 completed video 사용 / B: 신규 pending 완료 대기)
5. 결정 후 실행

**핵심 명령**:
```bash
# 1) generate는 fire-and-forget
notebooklm generate video    # Started: <uuid> 즉시 반환

# 2) 완료 대기 (반드시)
notebooklm artifact wait <artifact_id> -n <notebook_id> --timeout 900

# 3) 또는 기존 completed video 사용
notebooklm artifact list -n <nb_id> --json   # status='completed'인 최신 비디오
```

**Polkit 신호 매핑**:
- "업로드" 단발 = readiness probe 먼저 → 비디오 ready 확인 후 upload.py
- "A로 진행" = 기존 completed video 사용 (대기 없음)
- "B로 진행" = 신규 비디오 wait 후 upload.py
- "왜 그럼?" / "항상 하던 일인데" = 즉시 중단 + 시간순 검증 (이번 세션 트리거)

**적용**: 메모리 §솔직한 보고 패턴 "업로드 1단어 신호 = readiness probe" 와 동기. 신호가 단발이면 그게 "마지막 단계"라는 보장이 없음.

**저장 위치**: 이 스킬은 trigger regex 튜닝이 주 목적이지만, "사용자 단발 신호 처리 표준" 은 cron잡 워커가 자기 보고서를 신뢰하기 전에 점검하는 패턴과 동일 → 여기에 cross-reference.
