---
name: local-dashboard
description: Hermes Agent 로컬 웹 대시보드 실행 — FastAPI 서버를 띄워 브라우저로 관리 UI 제공
trigger: 주인님이 "대시보드 열어", "로컬 대시보드", "hermes dashboard" 등을 요청할 때
---

# Hermes Agent 로컬 대시보드

## 개요

Hermes Agent의 웹 UI 대시보드를 로컬에서 실행합니다. 설정, API 키, 세션 등을 웹으로 관리할 수 있습니다.

## 실행 환경

- **Python**: `~/.hermes/hermes-agent/venv/bin/python` (Python 3.11+)
- **이유**: base conda(Python 3.9)에서는 `str | None` 문법 미지원으로 실행 불가
- **주소**: http://127.0.0.1:9119
- **포트**: 9119 (기본값)

## 실행 절차

### 1. 웹 UI 빌드 확인

```bash
ls ~/.hermes/hermes-agent/hermes_cli/web_dist/index.html 2>/dev/null
```

파일이 없으면 빌드 필요:

```bash
cd ~/.hermes/hermes-agent/web && npm install && npm run build
```

### 2. fastapi/uvicorn 의존성 확인

```bash
~/.hermes/hermes-agent/venv/bin/python -c "import fastapi; import uvicorn; print('OK')"
```

없으면 설치:

```bash
~/.hermes/hermes-agent/venv/bin/python -m pip install fastapi uvicorn[standard]
```

pip 모듈 자체가 없으면:

```bash
~/.hermes/hermes-agent/venv/bin/python -m ensurepip
~/.hermes/hermes-agent/venv/bin/python -m pip install fastapi uvicorn[standard]
```

### 3. 서버 실행 (백그라운드)

```bash
cd ~/.hermes/hermes-agent && ~/.hermes/hermes-agent/venv/bin/python -c "
from hermes_cli.web_server import start_server
start_server(host='127.0.0.1', port=9119, open_browser=False, allow_public=False)
" 2>&1
```

**반드시 `background=true`로 실행할 것** (서버는 foreground에서 블록됨).

### 4. 서버 상태 확인

서버 시작 후 3초 정도 대기한 후:

```bash
curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:9119/
```

200이 반환되면 정상.

### 5. 브라우저 열기

```bash
open http://127.0.0.1:9119
```

## 이미 실행 중인 경우

포트 9119가 이미 사용 중이면 curl로 확인:

```bash
curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:9119/
```

200이면 이미 실행 중이므로 브라우저만 `open`으로 열어주면 됨.

## 주의사항

- **보안**: 대시보드는 API 키와 설정을 노출하므로 `127.0.0.1`에서만 실행
- **Python 버전**: 절대 base conda python3.9로 실행하지 말 것 (TypeError 발생)
- **venv**: 반드시 `~/.hermes/hermes-agent/venv/bin/python` 사용

## Pitfall (2026-07-13 실측)

- **`hermes dashboard --status`는 좀비 PID도 카운트** (실측). 죽은 PID 35142 + 다른 명령 프로세스 PID 1297 (`hermes_cli.main serve --port 0`)도 "2 hermes dashboard process(es) running"으로 표시. **신뢰 ❌**. 직접 `lsof -nP -i :9119`으로 실제 LISTEN 확인이 정답.
- **`hermes dashboard` ≠ `hermes serve`** — `serve`는 헤드리스 백엔드 서버(API 서버), `dashboard`는 웹 UI 서버. `--status`가 둘 다 카운트해서 헷갈림. PID의 command 컬럼으로 구분 (`hermes_cli.main serve` vs `hermes_cli.main dashboard`).
- **`--port 0`은 OS 자동 할당** — `serve --port 0`로 띄운 백엔드는 알려지지 않은 포트(예: 49312)에서 LISTEN. dashboard 기본 9119와 무관.
- **`GET /` 외 메서드는 405** — 정상. POST/PUT 등 시도 시 "Method Not Allowed" 응답. 헬스체크는 `curl -s -o /dev/null -w "%{http_code}"` GET만 사용.
- **`open http://127.0.0.1:9119` 후 대시보드가 안 뜨면** — Safari/Chrome이 다른 인스턴스 점유. `curl -I`로 200 확인 후에도 페이지가 안 뜨면 `--no-open`로 재실행 후 수동 `open`.

## 종료

```bash
hermes dashboard --stop
```

또는 직접 PID 종료:
```bash
lsof -nP -i :9119 | grep LISTEN | awk '{print $2}' | xargs kill
```

## 관련

- `references/2026-07-13-zombie-status-pitfall.md` — 좀비 --status 실측 진단 (PID 1297/35142/35322 타임라인)
- `references/hermes-cli-catalog.md` — `hermes --help` 전체 명령 카탈로그 (SKILL.md에 없는 명령 40+개 포함: kanban, swarm, project, hooks 등)
