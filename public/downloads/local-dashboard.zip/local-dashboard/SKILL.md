---
name: local-dashboard
description: Hermes Agent 로컬 웹 대시보드 실행 — FastAPI 서버를 띄워 브라우저로 관리 UI 제공
trigger: 주인님이 "대시보드 열어", "로컬 대시보드", "hermes dashboard" 등을 요청할 때
---

# Hermes Agent 로컬 대시보드

## 개요

Hermes Agent의 웹 UI 대시보드를 로컬에서 실행합니다. 설정, API 키, 세션 등을 웹으로 관리할 수 있습니다.

## 실행 환경

- **Python**: `~/.hermes/hermes-agent/venv/bin/python` (Python 3.11+)
- **이유**: base conda(Python 3.9)에서는 `str | None` 문법 미지원으로 실행 불가
- **주소**: http://127.0.0.1:9119
- **포트**: 9119 (기본값)

## 실행 절차

### 1. 웹 UI 빌드 확인

```bash
ls ~/.hermes/hermes-agent/hermes_cli/web_dist/index.html 2>/dev/null
```

파일이 없으면 빌드 필요:

```bash
cd ~/.hermes/hermes-agent/web && npm install && npm run build
```

### 2. fastapi/uvicorn 의존성 확인

```bash
~/.hermes/hermes-agent/venv/bin/python -c "import fastapi; import uvicorn; print('OK')"
```

없으면 설치:

```bash
~/.hermes/hermes-agent/venv/bin/python -m pip install fastapi uvicorn[standard]
```

pip 모듈 자체가 없으면:

```bash
~/.hermes/hermes-agent/venv/bin/python -m ensurepip
~/.hermes/hermes-agent/venv/bin/python -m pip install fastapi uvicorn[standard]
```

### 3. 서버 실행 (백그라운드)

```bash
cd ~/.hermes/hermes-agent && ~/.hermes/hermes-agent/venv/bin/python -c "
from hermes_cli.web_server import start_server
start_server(host='127.0.0.1', port=9119, open_browser=False, allow_public=False)
" 2>&1
```

**반드시 `background=true`로 실행할 것** (서버는 foreground에서 블록됨).

### 4. 서버 상태 확인

서버 시작 후 3초 정도 대기한 후:

```bash
curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:9119/
```

200이 반환되면 정상.

### 5. 브라우저 열기

```bash
open http://127.0.0.1:9119
```

## 이미 실행 중인 경우

포트 9119가 이미 사용 중이면 curl로 확인:

```bash
curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:9119/
```

200이면 이미 실행 중이므로 브라우저만 `open`으로 열어주면 됨.

## 주의사항

- **보안**: 대시보드는 API 키와 설정을 노출하므로 `127.0.0.1`에서만 실행
- **Python 버전**: 절대 base conda python3.9로 실행하지 말 것 (TypeError 발생)
- **venv**: 반드시 `~/.hermes/hermes-agent/venv/bin/python` 사용
