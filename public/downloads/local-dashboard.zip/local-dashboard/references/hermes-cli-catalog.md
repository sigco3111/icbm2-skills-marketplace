# hermes CLI 카탈로그 (2026-07-13 실측)

## ⚠️ 왜 이 파일이 필요한가

`hermes-agent` 스킬(SKILL.md v2.0.0)은 자주 갱신되지 않는 문서. `hermes --help`를 직접 실행하면 SKILL.md에 없는 명령이 다수 존재. **실측 우선, SKILL.md는 참고용**.

## 전체 명령 (실측)

```bash
$ hermes --help 2>&1 | grep -oE '\{[^}]+\}' | tr ',' '\n' | sort -u
```

### 채팅 / 인터랙션
- `chat` — 기본 대화 (hermes 단독 = chat)

### 모델 / 설정
- `model` — 모델/프로바이더 선택
- `setup` — 환경 설정 위저드
- `config` — config 관리 (edit/set/path/check/migrate)
- `doctor` — 환경 진단
- `status` — 컴포넌트 상태

### 인증 / 자격증명
- `auth` — 자격증명 풀 관리
- `login` / `logout` — OAuth 로그인
- `secrets` — 시크릿 관리

### 자동화
- `cron` — 크론 잡 관리
- `webhook` — 동적 webhook 구독
- `hooks` — 훅 관리 (SKILL.md에 없음)

### 플랫폼 / 게이트웨이
- `gateway` — 메시징 게이트웨이 (Telegram/Discord 등)
- `proxy` / `portal` — 프록시/포털
- `pairing` — DM 인증
- `whatsapp` / `whatsapp-cloud` / `slack` — 플랫폼별 명령

### 멀티 에이전트
- **`kanban`** — SQLite 기반 작업 보드 (boards/tasks/claim/swarm)
- **`project`** — 프로젝트 관리 (SKILL.md에 없음)
- **`swarm`** — Kanban Swarm v1 그래프 (병렬 워커 → verifier → synthesizer)
- `moa` — Mixture of Agents
- `fallback` — 폴백 프로바이더

### 메모리 / 세션
- `memory` / `memory-graph` — 메모리 관리
- `sessions` — 세션 관리
- `learning` — 학습 (SKILL.md에 없음)
- `journey` — 여정 추적 (SKILL.md에 없음)

### 스킬 / 플러그인 / 도구
- `skills` — 스킬 카탈로그/설치
- `bundles` — 스킬 번들 (SKILL.md에 없음)
- `plugins` — 플러그인 관리
- `curator` — 스킬 큐레이션 (SKILL.md에 없음)
- `tools` — 도구 활성화/비활성화
- `mcp` — MCP 서버 관리

### UI / 디스플레이
- **`dashboard`** — 로컬 웹 UI (FastAPI, 9119)
- **`serve`** — 헤드리스 백엔드 서버
- `desktop` / `gui` — 데스크탑/그래픽 UI
- `tui` — 터미널 UI
- `logs` — 로그 조회
- `prompt-size` — 프롬프트 크기 확인
- `console` — 콘솔 (SKILL.md에 없음)

### 데스크탑 / 디바이스
- `computer-use` — 컴퓨터 사용
- `pets` — 펫 (SKILL.md에 없음)
- `acp` — ACP 서버 (IDE 통합)
- `lsp` — Language Server Protocol

### 메타 / 유틸
- `version` / `update` / `uninstall`
- `completion` — 셸 자동완성
- `import` / `backup` / `dump` / `debug`
- `migrate` — 마이그레이션
- `security` — 보안 진단
- `checkpoints` — 체크포인트
- `postinstall` — 설치 후 스크립트
- `insights` — 사용 분석
- `claw` — OpenClaw 마이그레이션
- `profile` — 프로필 관리
- `send` — 메시지 전송

## 주요 명령 빠른 참조

### Kanban (CLI 태스크 관리)

```bash
hermes kanban init                                    # DB 생성
hermes kanban boards                                  # 보드 목록
hermes kanban create --title "..." --board <slug>     # 태스크 생성
hermes kanban list                                    # 태스크 목록
hermes kanban show <id>                               # 상세
hermes kanban claim <id>                              # 원자적 claim
hermes kanban complete <id>                           # 완료
hermes kanban swarm --goal "..."                      # Swarm 그래프
hermes kanban dispatch                                # 디스패치 데몬
hermes kanban watch                                   # 라이브 워처
hermes kanban stats                                   # 통계
hermes kanban notify-subscribe                        # 알림 구독
hermes kanban heartbeat                               # 하트비트
```

자세한 옵션: `hermes kanban --help` (35+ subcommand)
공식 문서: https://hermes-agent.nousresearch.com/docs/user-guide/features/kanban

### Dashboard (웹 UI)

```bash
hermes dashboard              # 기본 127.0.0.1:9119
hermes dashboard --port 8080  # 다른 포트
hermes dashboard --status     # ⚠️ 좀비 카운트 가능성, 신뢰 ❌
hermes dashboard --stop       # 종료
hermes dashboard --no-open    # 브라우저 안 열기
hermes dashboard register     # Nous Portal 등록
```

상세 pitfall: `references/2026-07-13-zombie-status-pitfall.md`

## SKILL.md에 없는 핵심 명령 (사용자 코렉션 받았음)

| 명령 | 사용자 코렉션 |
|---|---|
| `hermes kanban` | "에르메스 칸반" 질문 시 SKILL.md만 보고 "없음" 답함 ❌. 실제론 35+ subcommand 가진 정식 기능. **다음 세션부터 `hermes --help` 먼저 확인 권장** |

## 진단 우선순위 가이드

```bash
# 1) 명령 존재 확인
hermes --help 2>&1 | grep -iE "X|Y"

# 2) 명령 도움말
hermes X --help

# 3) SKILL.md cross-check (참고만)
cat ~/.hermes/skills/autonomous-ai-agents/hermes-agent/SKILL.md | grep -i X

# 4) SKILL.md에 없어도 help에 있으면 실제 존재 — 신뢰 우선순위: help > SKILL.md
```

## 메모리/스킬 업데이트 가이드

SKILL.md 업데이트 안 되는 상황에서 **새 명령 발견 시**:
1. `references/hermes-cli-catalog.md`에 추가 (이 파일)
2. SKILL.md outdated 마커 추가
3. 별도 class-level 스킬 생성 (해당 명령 카테고리별)

## 관련

- SKILL.md §Pitfall — dashboard --status 좀비 카운트
- `references/2026-07-13-zombie-status-pitfall.md`
- `hermes-agent` (protected 스킬, 패치 불가)