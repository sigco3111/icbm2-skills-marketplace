# hermes dashboard --status 좀비 카운트 함정 (2026-07-13)

## 트리거

`hermes dashboard --status` 실행 시 출력:
```
2 hermes dashboard process(es) running:
    PID 1297
    PID 35142
```
→ 2개 떠있다고 보고함. 하지만 `lsof -nP -i :9119` 결과 **0 LISTEN** = 실제론 아무것도 안 떠있음.

## 진단 타임라인

| 시각 | 이벤트 |
|---|---|
| 06:48 | PID 1297 시작: `hermes_cli.main serve --host 127.0.0.1 --port 0` (헤드리스 백엔드) |
| (이후) | PID 35142 시작 → 죽음 (좀비) |
| 06:30:22 | `hermes dashboard --status` 실행 → "2 processes" |
| 06:30:25 | `curl http://127.0.0.1:9119/` → HTTP 000 (exit 7) |
| 06:30:30 | `lsof -nP -p 1297` → 127.0.0.1:**49312** LISTEN (다른 포트!) |
| 06:30:35 | `ps -p 35142` → 죽음 (empty STAT) |
| 06:30:50 | `hermes dashboard --no-open` 백그라운드 실행 → PID 35335 |
| 06:30:54 | `curl http://127.0.0.1:9119/` → **HTTP 200** ✅ |

## 핵심 발견

### 1) `hermes dashboard` ≠ `hermes serve`

- **`dashboard`**: 웹 UI 서버 (FastAPI), 기본 포트 9119
- **`serve`**: 헤드리스 백엔드 서버 (API), `--port 0` 가능

`--status`가 둘 다 카운트해서 같은 dashboard로 오인.

### 2) `--port 0` = OS 자동 할당

`hermes_cli.main serve --host 127.0.0.1 --port 0`은 OS가 임의 포트 할당 (실측: 49312). 알려지지 않은 포트에서 LISTEN 중이라 dashboard 헬스체크(`curl 9119`)와 무관.

### 3) `--status`는 신뢰 ❌

죽은 PID 35142 + 다른 명령 PID 1297도 카운트. **dashboard 실행 여부 확인은 직접 포트 체크**:

```bash
# ✅ 정답
lsof -nP -i :9119 | grep LISTEN

# ❌ 부정확
hermes dashboard --status
```

## 정답 진단 패턴

```bash
# 1단계: 실제 LISTEN 확인
lsof -nP -i :9119

# 2단계: 떠있으면 헬스체크
curl -s -o /dev/null -w "%{http_code}\n" http://127.0.0.1:9119/
# 200 → 이미 실행 중, 브라우저만 open
# 000/000 → 안 떠있음, 새로 띄우기

# 3단계: 안 떠있으면 실행
hermes dashboard --no-open &  # 백그라운드
sleep 4
curl -s -o /dev/null -w "%{http_code}\n" http://127.0.0.1:9119/

# 4단계: 브라우저 열기
open http://127.0.0.1:9119
```

## 정리

- **dashboard --status는 advisory** — 참고만, 의사결정 근거 ❌
- **포트 + 프로세스 command 동시 확인** — `lsof -nP -p PID | grep LISTEN`로 command 패턴 구분
- **다른 `hermes serve` 프로세스가 살아있어도 dashboard 자체는 별개** — 9119 포트만 비어있으면 새로 띄우기 가능

## 관련

- SKILL.md §Pitfall (2026-07-13 추가)
- `references/hermes-cli-catalog.md` — serve vs dashboard 명령 구분 포함