---
name: legacy-codebase-archeology
description: Doc-only pass on frozen legacy code. README + deep-dives.
category: software-development
---

# Legacy Codebase Archaeology — Documentation-Only Preservation Pass

When the goal is **"preserve knowledge"** rather than **"fix / migrate / refactor"**, most existing skills give the wrong shape. `cpp-game-koreanization` adds features; `legacy-repo-modernization` migrates; `re0` resets and rebuilds. This skill is for the case where the user says: *"write it down well enough that a future session (or a future me) can pick it up cold"*.

Two hard constraints shape every choice below:

1. **Read-only on the code.** Never refactor, never "fix small bugs while you're there", never rename to modern style. If you find a bug, file it as a documented gotcha, do not edit the source.
2. **SSOT-first documentation.** When the same fact lives in N places (const enums, file-format schemas, build flag tables), name the SSOT file/path and explicitly call out the duplicate copies — future archeologists cannot tell which copy is canonical otherwise.

## When to use this skill

Activate when **all** of these hold:

- User hands over an existing project and says "**백업 / 보존 / 더 안 건드림**" intent
- The code is one of: Visual C++ ≤ 2005, classic MFC/WTL, late-90s DirectX (DDraw / DX7), J2ME/WIPI BREW/MIDP mobile era, abandoned closed-source engines, or pre-2010 C/C++ with no tests
- Goal is a written handoff, not a feature or migration
- Korean README is implicit (user context) but docs are otherwise unilingual

Do **not** use this skill if:

- The user wants to fork/modernize (use `cpp-game-koreanization`, `legacy-repo-modernization`, or `oss-fork-localization`)
- Project is current and ongoing (use `coding-mission-fullcycle`, `flywheel`)
- Goal is a quick verdict on an unfamiliar repo (use `github-repo-triage`)

## Phase 1 — Surface scan (10-15 min, mandatory before writing anything)

Run these in parallel, do not deep-dive yet:

1. **Top-level shape** — `tree -L 2 -d` or `find . -maxdepth 2 -type d`. Map the project into 3-7 zones.
2. **Solution/project entry points** — `.sln`, `.vcproj`, `.dsp/.dsw`, `Makefile`, `m.bat`. Pick the canonical build entry.
3. **Header-of-headers** — for Visual C++: `Resource.h`, `stdafx.h`, `targetver.h`. For others: the top-of-include-graph header.
4. **Existing docs** — `ReadMe.txt`, `README.md`, any `.doc` / `.txt`. **Read encoding-charset.** euc-kr/cp949 Korean in old Microsoft-era ReadMe will display as mojibake in any modern editor. Always re-author the visible README in UTF-8.
5. **.user / .suo files** — `*.vcproj.<username>.user` reveals who collaborated. Mention this in the README; do not assume one canonical user.

Then ask the user a single clarifier before writing — three short options, name your recommendation:

> A) "한글 README + 영어 원문 ReadMe.txt 그대로 두기 (추천)"
> B) "한글 README만 두고 ReadMe.txt 삭제"
> C) "양국어 README 탭 구조"

Memory says the user prefers terse + recommendation, so default to A unless they push back.

## Phase 2 — Architecture documentation (the structural doc)

Goal: a reader with the README open can find their way to any file in 30 seconds.

Sections, in this order:

1. **개요** (one paragraph — what the project is, not what it does)
2. **부속 문서 인덱스** (link to each per-topic doc under `docs/`)
3. **역사 노트** (e.g. "2026-07-30 스냅샷, 더 이상 적극 개발 안 함")
4. **디렉토리 트리** (annotated ASCII; mark "✨ 2D 엔진", "🎮 런타임 샘플", "📦 빌드 환경" if it helps)
5. **빌드 진입점** (one canonical command + alt commands for alt targets)
6. **함정** (3-7 explicit gotchas — encoding, dual-build entries, omitted dependencies, etc.)

The README itself stays at ~150-300 lines. Detail belongs in `docs/*.md`.

## Phase 3 — Per-topic deep dives (one `docs/<topic>.md` per non-trivial subsystem)

A "non-trivial subsystem" is one that:

- Has its own enum/constants/format that could change independently
- Hides a non-obvious pitfall (duplicate definitions, hidden SSOT, dead branches)
- A future reader could realistically modify without seeing the code

Common deep-dive topics in legacy VC++ projects:

| Topic | SSOT heuristic |
|-------|---------------|
| `blend-modes.md` | `switch(blendType)` in the rendering file, not the enum header |
| `file-format.md` | the writer-side function, never the reader-side parser |
| `build-variants.md` | the `.bat`/`.mak` files, not the `.vcproj` (vcproj lies about per-target defines) |
| `coordinate-conventions.md` | code that produces an output, not code that consumes it |
| `3rd-party-sdk.md` | the `#include` lines + the `.lib` version, not the wrapper class |

**The deep-dive template** (one structure across all docs):

```
## 1. 코드 위치 (Single Source of Truth)  ← table: definition / switch / algo / UI
## 2. 빠른 참조 표                        ← one row per enum / constant
## 3. 그룹별 설명                          ← conceptual categorization, not duplicate of the table
## 4. 알고리즘 / 함수 인덱스              ← pointer to where each row lives in code
## 5. 변경 시 주의                         ← pitfalls if anyone ever touches this
```

Sections 2+3 are where readers actually scan; section 1 is the load-bearing one. **If you skip the SSOT table, future archeologists will not know which copy of the enum is true.**

## Phase 4 — SSOT audit (separate pass, before declaring done)

This is where `ssotchk` operates in read-only mode. For each non-trivial fact in the docs:

1. Search the repo for declarations (`grep -nE "BLAND_|DIT_|FORMAT_V"`)
2. Tabulate: location · role (definition / duplicate / consumer)
3. Pick canonical home — **the most-maintained location, closest to where the fact actually changes** (the `switch`, the writer function, the build script).
4. Flag any detail that lives ONLY in a non-canonical copy — fold it back to canonical before the doc is reliable.

Common SSOT traps in legacy VC++:

- **Triple-copied enums** (`MainFrm.h` / `ImgDrawView.h` / `<runtime>.h` all redefine the same `DIT_*`). Pick the runtime-file enum as canonical (closest to the consumer).
- **vcproj says one thing, .bat sets another.** The .bat is canonical; the vcproj's preprocessor defines drift.
- **Sample-game uses a different copy of constants than the editor.** When the sample game's enum disagrees with the editor's switch-case, the editor is canonical (it's the producer).

Document all three classes of trap under section 5 ("변경 시 주의") of the relevant `docs/*.md`.

## Phase 5 — Handoff seal

Before declaring the doc pass done:

1. Re-read the README cold (timed — 30 second skim test). If a reader can't answer "where do I look for X?" in three seconds, restructure.
2. Verify no fabricated counts. If code has 23 enum cases, the doc says 23. (One session failure: SSOT line in the file numbered 23, not the 20 the user remembered in chat. Always grep the code, not the memory of it.)
3. Verify links. Every `docs/*.md` link in README resolves to an existing file. Internal anchor links (`#section-1`) work.
4. Confirm the user is OK declaring legacy-backup status (한 줄 노트 README 상단). Don't assume.
5. Do NOT save to user memory unless the user said "이렇게 매번 해" / "레거시 백업 패턴 기억해줘". A single project is not a durable rule.

## Pitfalls (encountered in real failures)

1. **Memory of chat ≠ memory of code.** A user says "20 blend modes" in chat; the file has 23 enum cases. Always re-grep the canonical file before writing the deep-dive.
2. **Triple-copied enum drift.** When the same enum lives in editor header + UI header + runtime header, they WILL drift if anyone touches one but not the others. Pick canonical by *production location* (the switch-case), not by alphabetical first occurrence.
3. **euc-kr ReadMe displays as mojibake.** Always re-author in UTF-8 and note the encoding switch in pitfalls section.
4. **vcproj .user files leak collaborators.** Mention who touched it in the README history note, but don't try to canonicalize.
5. **Number inflation in defs/tables.** If you write "20+ enum cases" when there are 23, fix it. The doc must match `wc -l` or `grep -c "case "`, not vague memory.
6. **Skipping the SSOT callout to be concise.** The single most useful sentence in any legacy doc is "the switch in Foo.cpp is the only place that changes; the three header copies are decoys". Skipping it is the most common retro note.
7. **Refactoring "just a tiny bit" while documenting.** Out of scope. If you can't resist, open a separate task and stop.
8. **Inferring file format without running the parser.** If the project has `.sab`/`.xrf`/`.dat` outputs, only describe the format up to what you can read from the writer code; mark "필드 매핑 미검증" honestly.
9. **Linking to docs that don't exist yet.** Phase 3 must complete before README's "부속 문서" index goes live. Add files in this order: README stub → deep-dives → expand README links → seal README.
10. **Treating one legacy project as a durable preference.** Don't add to user memory or root MEMORY unless the user explicitly says "앞으로도 이렇게". One project ≠ pattern.

## Reference files

- `references/ssot-callout-table.md` — exact template for "1. 코드 위치 (Single Source of Truth)" section, with worked example from a real legacy MFC project.
- `references/deep-dive-template.md` — 5-section template for `docs/<topic>.md` files.
- `references/handoff-seal-checklist.md` — pre-declaration cold-read + verification steps.

## Scripts

- `scripts/ssot_audit.py` — quick SSOT scanner: input list of (symbol, search-pattern, expected-roles) tuples, output table of files where each appears. Read-only report. Useful in Phase 4.

## Memory interactions

- DO add to memory if user explicitly says this pattern is recurring across projects (e.g. "앞으로 모든 레거시 백업은 이렇게").
- DO NOT add on the strength of one project. One session of legacy-pass ≠ durable preference.
- If the deep-dive counts (e.g. "23 blend modes") need to be re-verified next session, store the canonical grep command rather than the count.
