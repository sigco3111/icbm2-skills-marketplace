#!/usr/bin/env python3
"""ssot_audit.py — quick SSOT scanner for legacy codebases.

Read-only. Reads symbol-spec tuples from CLI or stdin and emits a table of
where each symbol appears, classified as definition / duplicate / consumer.

Usage:
    python3 ssot_audit.py --root . --symbols BLAND_,DIT_,DRT_ --include "*.h,*.cpp"
    # or via stdin (one SYMBOL,PATTERN,EXPECTED_ROLE per line)
    python3 ssot_audit.py --root /Users/mac/work/spriteatelier
"""
import argparse
import os
import re
import sys
from collections import defaultdict


def find_files(root, includes):
    """Yield absolute paths whose extension matches any in `includes`."""
    include_set = {ext.strip() for ext in includes if ext.strip()}
    for base, _dirs, files in os.walk(root):
        # Skip obvious noise dirs in legacy repos.
        for skip in (".git", ".vs", "Release", "Debug", "obj", "bin", "Res"):
            if skip in base.split(os.sep):
                break
        else:
            for fn in files:
                if any(fn.endswith(ext) for ext in include_set):
                    yield os.path.join(base, fn)
            continue
        # If 'break' ran above, this is skipped for that base; but we need
        # the for-else pattern properly. Re-implement more simply:
    # Re-walk the skipped logic above (the for-else inside os.walk doesn't
    # iterate per entry — that's a Python idiom bug). Let me redo clean:
    for base, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if d not in {".git", ".vs", "Release", "Debug", "obj", "bin", "Res"}]
        for fn in files:
            if any(fn.endswith(ext) for ext in include_set):
                yield os.path.join(base, fn)


def classify(path, pattern):
    """Heuristic: is this a definition, duplicate, or consumer?

    - "definition"   — file declares the symbol (enum { ... } block or case match)
    - "duplicate"    — file has the same enum but as a re-declaration
    - "consumer"     — file uses the symbol (switch case or call site) but does not declare
    - "unknown"      — fallback; manual check needed
    """
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            content = f.read()
    except (OSError, UnicodeDecodeError):
        return "unknown"
    # Crude but effective — works for VC++ style enums.
    has_enum = bool(re.search(r"\benum\s*[\(\s]?\s*\{[^}]*" + re.escape(pattern), content))
    has_case = bool(re.search(r"\bcase\s+" + re.escape(pattern) + r"\s*:", content))
    if has_enum:
        # If also has case, it's the canonical switch + enum together
        return "definition"
    if has_case:
        return "consumer"
    return "duplicate-or-unknown"  # could be #include re-export; treat as duplicate


def main():
    ap = argparse.ArgumentParser(description="Read-only SSOT scanner for legacy codebases.")
    ap.add_argument("--root", default=".", help="Project root to scan")
    ap.add_argument(
        "--symbols",
        default="BLAND_",
        help="Comma-separated symbol prefixes (default: BLAND_)",
    )
    ap.add_argument(
        "--include",
        default="*.h,*.cpp,*.c,*.hh,*.hpp",
        help="Comma-separated file extensions (default: C/C++ headers and sources)",
    )
    args = ap.parse_args()

    symbol_prefixes = [s.strip() for s in args.symbols.split(",") if s.strip()]
    includes = [s.strip() for s in args.include.split(",") if s.strip()]

    locations = defaultdict(list)
    for path in find_files(args.root, includes):
        rel = os.path.relpath(path, args.root)
        for prefix in symbol_prefixes:
            try:
                with open(path, "r", encoding="utf-8", errors="replace") as f:
                    content = f.read()
            except (OSError, UnicodeDecodeError):
                continue
            if prefix in content:
                role = classify(path, prefix)
                locations[prefix].append((rel, role))
                break  # file counted once per prefix

    # Emit table
    print(f"{'Symbol':<16}{'File (rel)':<60}{'Role'}")
    print("-" * 100)
    for prefix, entries in sorted(locations.items()):
        for rel, role in entries:
            print(f"{prefix:<16}{rel:<60}{role}")
        print()


if __name__ == "__main__":
    main()
