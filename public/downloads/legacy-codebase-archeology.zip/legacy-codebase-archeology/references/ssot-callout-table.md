# SSOT Callout Table — Template for Legacy Code Deep-Dives

Every `docs/<topic>.md` for a frozen legacy project should open with this table. The trick is that the *defining header* is rarely the canonical source — the **switch / writer / parser that actually changes** is.

## Worked example — `CDraw2D.cpp` blend modes (2026-07-30)

```markdown
## 1. 코드 위치 (Single Source of Truth)

| 항목 | 경로 | 비고 |
|------|------|------|
| enum 정의 | `Package/CDraw2D.h` | `enum { BLAND_COLORDODGE=0, ... BLAND_PHOENIX=22 }` |
| enum 재선언 ⚠️ | `MainFrm.h`, `ImgDrawView.h`, `spritest/Sprite.h` | 3곳 동기화 필수 |
| 분기 (switch) | `Package/CDraw2D.cpp` 라인 2487 부근 | **진짜 SSOT** — 인덱스 = 직렬화 정수값 |
| 알고리즘 함수 | 같은 파일 안 `ColorBlend_<Name>(RGB3, RGB1, RGB2)` | 전부 같은 시그니처 |
| UI 콤보박스 ID | `IDC_COMBO_BLEND` | 값 보존 = enum index |
```

The single most useful sentence in the whole deep-dive sits in the row marked ⚠️:

> "The switch in `CDraw2D.cpp` is the only place that changes; the three header copies are decoys."

## Why this table matters more than the rest of the doc

Readers (including future you, after 6 months away) skim docs top-down. They will land on this table first. If it doesn't say where the truth actually lives, they'll fixate on the wrong copy and break the build.

## Three traps to surface in the table

1. **Triple-copied enum** — pick canonical by *production location* (the switch), not by alphabetical first occurrence. Sample-game runtime is the consumer if you want least risk.
2. **vcproj says one thing, .bat sets another** — the .bat is canonical; the vcproj preprocessor defines drift over time. Tabulate both rows.
3. **Commented-out code as false SSOT** — old `#ifdef 0` blocks look like candidates but they don't compile. Use `git blame` to verify the comment predates any later change.

## Filling the table from grep

Two-pass approach (1 minute):

```bash
# Pass 1 — find every place this enum/symbol appears
grep -nE "BLAND_|DIT_|FORMAT_V" . -r --include="*.h" --include="*.cpp"

# Pass 2 — find the switch / writer / parser
grep -nE "switch *\(.*\)|WriteToFile|Fread|Fwrite" . -r --include="*.cpp"
```

The first list is "declarations" (potential SSOT candidates). The second is "the place that actually changes" (always canonical).
