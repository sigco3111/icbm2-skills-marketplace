# Handoff Seal Checklist — Before Declaring the Doc Pass Done

Run each item in order. Skip nothing. A 30-second cold-read is the load-bearing test.

## 1. Cold-read smoke test

Print (or skim) only the rendered README. Set a 30-second timer.

- [ ] Within 30 seconds, can you answer: "where is X?" for any 3 random subsystems you can name?
- [ ] Does the README lead with a one-line legacy-backup note (e.g. "🗄️ 2026-07-30 스냅샷")?
- [ ] Is the directory tree legible without expanding anything?

If any answer is "no", restructure before continuing.

## 2. Count fidelity — never trust chat memory

```bash
# Counts in doc must match counts in code. If not, the doc is lying.
grep -c "case BLAND_"  Package/CDraw2D.cpp     # → §2 row count
grep -c "case BLAND_COLORDODGE\|...BLAND_PHOENIX" Package/CDraw2D.cpp
wc -l README.md                                # ~150-300 lines
wc -l docs/blend-modes.md                      # detail size ok
```

Common errors:
- "20 blend modes" in chat, 23 in the file. Always re-grep.
- DIT + DRT counted together then summed wrong.
- vcproj says one enum count, .h says another.

## 3. Link validity

```bash
# Every docs/*.md link from README must resolve.
grep -oE '\[[^]]*\]\([^)]*docs/[^)]*\)' README.md | sed 's/.*(\(.*\))/\1/'
# Click through each. If a 404, either write the file or remove the link.
```

Internal anchor links (`#section-1`) — verify the heading exists by exact text match.

## 4. Unicode / encoding sanity

```bash
file README.md docs/*.md                 # → should all say "UTF-8"
git diff --stat                          # → no encoding-only diffs
```

If the file output says ISO-8859 or euc-kr, fix it. Old ReadMe.txt can stay in its native encoding only if it's the *original*; the new doc must be UTF-8.

## 5. SSOT audit passed

Confirm Phase 4 ran (use `ssotchk` if available, else hand-tabulate). For each nontrivial constant / format / build flag in `docs/`:

- [ ] At least 2 places known
- [ ] Canonical chosen
- [ ] Duplicates documented with sync requirement (or "static, no live sync needed")

## 6. User confirmation

Read this checklist with the user. Ask one question:

> "이대로 마무리할까요, 아니면 섹션 추가/수정할까요?"

Wait for explicit OK before stopping. Don't assume.

## 7. Handoff summary message

Output to the user:
1. What was created (paths)
2. Where the SSOT lives (the one sentence)
3. What is NOT covered (open questions or risks)
4. The exact recommended next step (or "no further action")

## 8. Do NOT auto-promote to memory

A single project is not a durable preference. Save to memory only if the user says "앞으로도 이렇게" — explicit pattern statement, not implicit.
