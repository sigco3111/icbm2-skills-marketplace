# Multi-Repo Batch Documentation Checklist

Validated 2026-07-31 on **41 sigco3111 private projects** (mobile Java/BREW, NDS, Bada, Android, iOS from 2002-2013). Same template has been used on smaller batches (3-10 repos). Use this when the user asks to bulk-update or bulk-create READMEs across multiple sibling repos of the same era/owner.

## Why a separate checklist

When N ≥ 5 repos share owner/era/audience, the per-repo work is repetitive enough that **doing them in any order without a master plan** leads to: inconsistent badge sets, missing cross-references in some but not all, missed push order causing rate limits, and no way to spot the one repo where the work silently failed.

The checklist has **3 sections** that all batch jobs need: a P1 inventory (what we have), a reference mapping (what else exists we should link to), and an 8-stage tracker (where each repo is in the pipeline).

---

## Section A — Header (always first)

```markdown
# sigco3111 <batch-name> README 보강 체크리스트

**생성일**: <YYYY-MM-DD>
**대상**: <N>개 <repo-prefix> (<repo-type>)
**목표**: 현재 부실한 자동 생성 README (3~4KB, 추정 기반)를
        코드 분석 + 맥락 보강으로 화려하고 자세하게 재작성
**방식**: 작업 사본 코드 분석 → README 작성 → 로컬 커밋 → git push → GitHub API 검증
```

The user reads this once to confirm scope, then scrolls down for the data.

---

## Section B — P1 Inventory (41-row table)

One row per repo. This is the "is the work even possible?" check — spot missing working copies, dirty state, huge size mismatches.

```markdown
| # | Repo 슬러그 | 영문명 | 한국어명 | 플랫폼 | 장르 | 시대 | 문서 size | 실측 size | 파일 수 | 상위 디렉터리 | 상위 확장자 | git | HEAD |
| :-: | :--- | :--- | :--- | :---: | :--- | :--- | ---: | ---: | ---: | :--- | :--- | :--- | :--- |
```

Column meanings:

- **문서 size**: from the source index markdown (often inflated because `.large_files_excluded/` is excluded from git but counted in the original archive)
- **실측 size**: actual working-copy bytes excluding `.git/` and `.large_files_excluded/`
- **상위 디렉터리**: `|`-separated, 3 largest subdirs by bytes — tells you the structure at a glance
- **상위 확장자**: comma-separated `ext(count)` for top 5 — the **strongest signal** for platform identification (see Extension SSOT table below)
- **git**: `clean` or `dirty(N)` where N = uncommitted file count
- **HEAD**: short SHA, so you can verify the push actually advanced HEAD

### Extension SSOT — mobile/J2ME/NDS platform identification

This is worth memorizing because it saves you opening every project:

| Platform | Top extensions | Other tells |
|---|---|---|
| J2ME (Java ME) | `class`, `jar`, `jad`, `java` | `mmf` (SMAF sound), `META-INF/MANIFEST.MF` |
| BREW | `bar`, `bid`, `c`, `h`, `mod`, `mif` | `sig` (signature), `bmd` |
| WIPI | `wpx`, `c`, `h`, `class` | `*.kdef` |
| NDS | `ncg`, `ncl`, `nce`, `nsc`, `NCER`, `NANR`, `NCBR`, `NCLR`, `NCGR` | `Makefile`, `spec`, `Makefile.gba` |
| Bada (C++) | `h`, `cpp`, `xml` | `application.xml`, `manifest.xml`, `signature.xml`, `480x800/IDF_*.xml` |
| Android | `java`, `xml`, `class`, `png` | `AndroidManifest.xml`, `res/layout/*.xml`, `res/values/strings.xml` |
| iOS | `m`, `h`, `xib`, `plist` | `Info.plist`, `*AppDelegate.m`, `*ViewController.xib` |
| GVM/GNEX (feature phone) | `sgs`, `sbm`, `sal`, `ssd`, `smc`, `idf` | Korean carrier-era formats |
| Tools/utilities | `bat`, `c`, `h`, `res`, `wti`, `wbd`, `wbi` | cross-platform file converters |

---

## Section C — Reference Mapping (Phase 1.5, the 4-column matrix)

**This is the load-bearing section** — it determines what every per-repo README will list under "📚 관련 자료 (sigco3111 GitHub)".

### C.1 — Owner inventory

```bash
gh repo list <owner> --visibility public  --limit 200 --json name,description > /tmp/owner_public.json
gh repo list <owner> --visibility private --limit 200 --json name,description > /tmp/owner_private.json
```

### C.2 — STRICT alias matching (Pitfall #11)

The naive version (`if alias in repo_name:`) is **broken** — `"a"` matches `"arcade"`, `"android"`, `"magicshop"`, and 50 other repos. Every project ends up with 20-30 false matches.

**Use this Python pattern** (one-liner mental model):

```python
import re
def word_match(alias: str, name: str) -> bool:
    if len(alias) < 4:                         # Pitfall #11: noise floor
        return False
    return bool(re.search(
        rf'(^|[-_]){re.escape(alias)}(-|_|$)',  # word boundary on - and _
        name
    ))
```

With that, **aliases need to be 4+ chars AND hit a word boundary** in the repo slug. The 41-project batch went from "all match 25 (broken)" → "13/41 match" → "41/41 match with avg 4.4 meaningful refs" in three iterations.

### C.3 — Per-target alias list (≥3 aliases per project)

For a mobile-game batch, build the alias list as: romanized name + Korean keyword + genre/category keyword.

```python
ALIASES = {
    "private-proj-mobile-1942-java":         ["1942", "1942_java", "1942-java"],
    "private-proj-mobile-gameneo-matgo":     ["gameneo", "game-neo"],     # also Korean "게임네오"
    "private-proj-nds-ds-gostop":             ["ds-gostop", "dsgostop"],
    ...
}
```

Korean aliases are also useful but harder to match (no word boundary) — convert them to romanized form for the word_match function and keep Korean as a comment.

### C.4 — Category alias table

Once direct aliases are exhausted, layer in **category** aliases (genre/era/platform):

```python
CATEGORY_ALIASES = {
    "matgo":          ["matgo"],
    "gostop":         ["gostop", "dsgostop"],
    "magicstore":     ["magicstore", "magicshop", "nds-magicstore"],
    "tycoon":         ["tycoon"],
    "rpg-gunblade":   ["rpg-gunblade"],
    "nds-sound":      ["nds-dsgostop-sound"],
    "nds-artwork":    ["dsgostop-artwork", "dsgostop-manga", "dsgostop-planning"],
    "nds-sdk":        ["nds-sdk", "nds-education"],
    ...
}
```

Then map each target project's genre/era to one or more categories. NDS projects → `nds-sound` + `nds-artwork` + `nds-sdk` automatically. Matgo variants → `matgo`.

### C.5 — What to exclude

- **`misc*` is always noise**. `matgo-misc`, `tycoon-misc`, `rpg-misc` etc. are catch-all buckets. Don't auto-link them unless the target project *itself* is in a misc bucket.
- **`private-proj-*` siblings are not references**. The 41 projects ARE the targets, not references to each other.
- **Self-match**: skip if `target == candidate`.

### C.6 — The 4-column matrix output

```markdown
| # | 프로젝트 (한글) | 플랫폼 | Public | 회사 외주 | 게임 문서 | NDS SDK/교육 | 합계 |
| :-: | :--- | :---: | :--- | :--- | :--- | :--- | ---: |
```

Per-row cell content: `[`repo-name`](URL), ...` comma-separated. The "—" placeholder for empty cells keeps the table scannable.

---

## Section D — 8-Stage Tracker (per-repo status)

```markdown
- [x] **P1.** 작업 사본 실측 + 메타데이터 수집 (코드 분석, 확장자, 디렉터리)
- [ ] **P2.** 41개 repo 메타데이터 통합 표 작성          ← P1 result
- [ ] **P3.** 공통 README 템플릿 (비공개 화려 버전) 작성 ← Phase 2.1 in main skill
- [ ] **P4.** 41개 README 자동 생성 (P2+P3 → per-repo 스크립트)
- [ ] **P5.** 41개 작업 사본 로컬 커밋 (소스 변경 없음, README only)
- [ ] **P6.** 41개 `git push origin main` (sequential, 2초 간격)
- [ ] **P7.** GitHub API로 41개 README/visibility/size 검증
- [ ] **P8.** 인덱스 페이지 README size 컬럼 갱신
```

Why this exact split:

- **P1/P2**: data only, no output to git. Easy to redo if extraction script has bugs.
- **P3**: one template, 41 applications. Best return on time invested.
- **P4**: per-repo application of P3. Mistakes here are visible in P7.
- **P5**: separate commit per repo (so P7 can detect "which push failed" via commit SHA).
- **P6**: sequential + 2s sleep — `gh` secondary rate limit hits around the 8th-9th push otherwise.
- **P7**: verifies `visibility=PRIVATE` + `size > 15KB` (the auto-template threshold).
- **P8**: optional master-index update if the user wants a separate index page.

---

## Section E — Per-Project README Approval Pattern (Pitfall #15)

For N > 5 repos, **do not auto-generate all N at once** without a checkpoint. The user explicitly said:

> "확인 후 괜찮으면 나머지도 순차적으로 진행할 예정임"

Recommended flow:

1. Generate #1 (or first 1-2) README fully
2. `cp` to `~/Downloads/<repo-slug>-README-v2.md` (Pitfall #12)
3. Report: size in KB, git diff stat, sections present
4. **Wait for OK** before continuing

If the user wants "auto, no checkpoint", they will say so explicitly. Default to the sample-and-confirm loop.

---

## Section F — Push Order & Rate Limits

The user observed `gh` secondary rate limits hitting around the 8th-9th sequential push on 2026-07-31. Mitigations:

```bash
for slug in $(cat slug_list.txt); do
    (
        cd /Users/mac/work/github-private/$slug
        git add README.md
        git commit -m "docs: 상세 README로 교체 (코드 분석 + 참고 repo 매핑)"
        git push origin main
    )
    sleep 2  # Pitfall: 0s sleep triggers 429 on the 9th push
done
```

For larger batches (N > 30), consider spacing with `sleep 5` between every 5th push. The cost is a few minutes; the benefit is not having to retry failures.

---

## Section G — Verification one-liner (P7)

```bash
gh api repos/<owner>/<repo>/readme \
  | python3 -c "import sys,json,base64; d=json.load(sys.stdin); print(d['name'], 'size:', d['size'])"
```

Expect `size > 15000` for the "fancy" template. The old 3-4 KB auto-templates will all fail this check.

For batch verification, loop over the slug list and report a 41-row table:

```python
results = []
for slug in slug_list:
    r = gh_api(f"repos/{owner}/{slug}/readme")
    results.append((slug, r.get('size', 0), 'OK' if r.get('size', 0) > 15000 else 'TOO_SMALL'))
```

---

## Section H — File Mirroring (Pitfall #12)

The user wants the checklist + sample READMEs in **`~/Downloads/`** (macOS Downloads folder), not buried in `~/work/`. Always `cp` (not symlink) so the user finds an independent, viewable file:

```bash
WORK=/Users/mac/work/<project>
DL=~/Downloads
cp -p "$WORK/checklist.md" "$DL/"
cp -p "$WORK/<repo-slug>/README.md" "$DL/<repo-slug>-README-v2.md"
```

`-p` preserves mtime so the user can tell which is newest.

---

## Section I — Anti-patterns (what NOT to do)

1. **One single monolithic README covering all 41** — the user explicitly wants **per-repo** READMEs. A mega-README is not what they asked for.
2. **Skipping the cross-reference matrix** — leaves every README in isolation, no path to the bigger story.
3. **Saving checklist to `~/work/` only** — user will look in Downloads and find nothing.
4. **Auto-pipelining 41 repos end-to-end without sample-and-confirm** — wastes the review window if the format needs adjustment (Pitfall #15).
5. **Loose substring alias matching** — every project maps to 25 repos, all noise (Pitfall #11).
6. **Treating `misc*` as legitimate references** — they are catch-all buckets, almost never the right link target.
7. **Forgetting `git add README.md` before push** — the push silently succeeds but the README never goes up.
8. **Pushing in parallel** — `gh` rate limits compound; sequential + 2s sleep is the right rhythm.
