# Deep-Dive Doc Template — 5-Section Standard

This is the single structure every `docs/<topic>.md` for a frozen legacy project should follow. Using one template across all deep-dives means readers (and future archeologists) can navigate by section number, not by re-learning each doc.

## The 5 sections

### §1. 코드 위치 (Single Source of Truth) — REQUIRED, TABLE FORM
Always a table with these rows:
- enum / constant / format definition
- enum / constant duplicate copies (mark ⚠️)
- the switch / writer / parser that actually changes (mark **canonical**)
- helper or algorithm functions (named location only)
- UI / serialization layer (id or wire format)

Worked example in `references/ssot-callout-table.md`. The load-bearing sentence of the whole doc lives in this section.

### §2. 빠른 참조 표 — OPTIONAL BUT RECOMMENDED
One row per enum value or constant:
- index / id
- name
- group / category
- algorithm / line in canonical file
- one-line description (Korean, plain language)

This is what readers actually scan. Don't bury it under prose.

### §3. 그룹별 설명 — REQUIRED IF THERE ARE GROUPS
If the enum naturally clusters (Dodge vs Burn vs Multiply vs Comparative), give each cluster a sub-heading with:
- 1-2 sentence pattern description
- when to reach for it (use cases)
- what's in the cluster

For non-enum topics (file formats), this section becomes "field-by-field walkthrough with byte offsets".

### §4. 알고리즘 / 함수 인덱스 — REQUIRED
A pointer for every row in §2 back to its code location:
```cpp
case BLAND_COLORDODGE:  ColorBlend_ColorDodge(RGB3, RGB1, RGB2); break;
```
Three lines per row is enough. Don't paste the function body.

### §5. 변경 시 주의 — REQUIRED
Pitfalls if anyone ever touches this code:
- compat invariants (e.g. "SAB 직렬화 정수값이 어긋나므로 enum 끝에만 추가")
- 3-place sync traps (e.g. "MainFrm.h / ImgDrawView.h / Sprite.h 동시 수정 필수")
- ID-rebinding order (e.g. "IDC_COMBO_BLEND 콤보박스 인덱스 = enum 인덱스")

If this section is empty, the reader has no signal about how dangerous a change is. Don't skip it.

## Anti-pattern: don't bloat with algorithm details

The algorithm body (`ColorBlend_Screen`'s actual pixel math) does NOT belong in the deep-dive. It's in the `.cpp`. The deep-dive's job is *navigation*, not *reproduction*. Readers who want the math grep the code; readers who want orientation read the table.

## Anti-pattern: don't fold historical commentary into §1

History belongs in §0 (one-time 역사 노트 in the README), not in the SSOT table. The SSOT table needs to be cold and unambiguous; history erodes that signal.
