# 듀얼 카드 임베드 케이스 스터디 (sigco3111, 2026-07-13)

## 컨텍스트

sigco3111 GitHub 프로필 README의 기존 히어로 영역은 Tokscale 토큰 그래프 1개 단독.
사용자가 "GitFut 카드 추가하자, 듀얼 카드로 진행" 결정 → 1개 임베드를 **GitFut (PNG) + Tokscale (SVG)** 듀얼로 확장.

## 작업 타임라인

| # | 단계 | 산출물 | 검증 |
|---|------|--------|------|
| 1 | GitFut 카드 컨셉 + URL 패턴 확인 | `gitfut.com/<user>.png?country=KR` | `curl -sI` 200 OK |
| 2 | Tokscale SVG URL 형식 확인 | `tokscale.ai/api/embed/<user>/svg?...` | 200 OK |
| 3 | 듀얼 배치 옵션 A~D 사용자 제시 | B 듀얼 채택 | — |
| 4 | README.md patch (`## 🏆 토큰 사용량` → `## ⚽🃏 듀얼 스카우트`) | +19 / -4 라인 | patch unique match 확인 |
| 5 | 로컬 git init → remote 추가 → fetch → commit | `910778f feat: 듀얼 스카우트 카드` | `git log` 확인 |
| 6 | push 보류 — 사용자가 결정 | 현재 미푸시 상태 | — |

## 발견한 함정 / 패턴

### 1. patch 도구 헤더 anchor — `## 🏆` vs `## ⚽🃏` 호환성

`<sub>` 태그 안에서 `&nbsp;` 구분자 3개를 쓰면 데스크탑 폭(>800px)에서 좌우 정렬되지만 모바일(<800px)에서 자동 wrap → 의도된 동작. 검증 시 `&nbsp;` 보존 확인:

```python
chk("듀얼 카드 구분자 보존", "&nbsp;&nbsp;&nbsp;&nbsp;" in readme)
chk("GitFut 임베드 보존", "gitfut.com/sigco3111.png?country=KR" in readme)
chk("Tokscale 임베드 보존", "tokscale.ai/api/embed/sigco3111/svg" in readme)
```

### 2. country 쿼리스트링 → 서비스 응답 헤더 변화 없음

```bash
# ❌ country=KR 안 붙임 (사용자가 한국 사용자지만 카드에 미국 국기 표시됨)
https://gitfut.com/sigco3111.png

# ✅ country=KR (사용자 정체성 일치, 시각적 임팩트 ↑)
https://gitfut.com/sigco3111.png?country=KR
```

GitFut는 `?country=ISO2` 쿼리를 받아 카드 내 국기 이모지를 오버라이드함. KR/JP/CN/US 등 2자리 ISO 코드.

### 3. 듀얼 카드 attribution 압축 — 3개 링크를 `<sub>` 한 줄에

기존 패턴 (Featured Project):

```markdown
<sub>🎨 원작자 [@hyeonsangjeon](https://github.com/hyeonsangjeon) · MIT fork</sub>
```

듀얼 카드에 적용한 패턴 (3-링크 압축):

```markdown
<sub>
  ⚽ [GitFut] · 📊 [Tokscale] · 🤖 5개 클라이언트 통합
</sub>
```

**교훈**: Featured Project attribution은 1개 링크 + 라이선스, 듀얼 카드는 2개 서비스 링크 + 1개 컨텍스트. 길어지면 sub 캡션 영역만 길어져 시각 임팩트는 비슷.

### 4. 푸시 전 push 가능 상태 — push 보류 트레이드오프

특수 repo (`{user}/{user}`) 에서 `git push --force` 는 특별히 신중해야:

| 옵션 | 단점 |
|---|---|
| `git push origin main` | force 없으면 기존 origin과 unrelated histories 충돌 |
| `git push --force` | 다른 파일이 origin에 있으면 그것도 덮어씀 |
| `git push origin main --force-with-lease` | 안전 옵션 (origin보다 빠를 때만 force) |

**권장**: 듀얼 카드는 README.md만 건드리는 작업이므로 `--force-with-lease`가 정답.
다른 파일 (이미지, workflows) 영향은 pre-push에 `git ls-files` 로 확인.

### 5. 기존 헤더 변환 — 단순 치환 vs 전체 재작성

기존 단일 임베드 헤더:

```markdown
## 🏆 토큰 사용량 — 82일 5개 클라이언트 · 21개 모델

[![Tokscale Stats](URL)](URL)
```

변경 후 (헤더 + 임베드 + 캡션 모두 교체):

```markdown
## ⚽🃏 GitFut Card · 82일 5개 클라이언트 듀얼 스카우트 리포트

<p align="center">
  <a href="..."><img ...></a>
  &nbsp;&nbsp;&nbsp;&nbsp;
  <a href="..."><img ...></a>
</p>

<p align="center">
  <sub>...</sub>
</p>
```

→ patch old_string에 헤더 1줄 + 임베드 1줄 + 캡션 1줄 + `---` 구분자까지 5줄 묶음으로 unique match 확보.

## 푸시 후 검증 체크리스트

```python
# 변경 의도 보존
for needle in [
    "## ⚽🃏 GitFut Card",            # 새 헤더
    "gitfut.com/sigco3111.png?country=KR",  # 좌측 카드
    "tokscale.ai/api/embed/sigco3111/svg",  # 우측 카드
    "&nbsp;&nbsp;&nbsp;&nbsp;",        # 듀얼 구분자
    "5개 클라이언트",                  # 한국어 클라이언트 카운트
]:
    chk(f"'{needle}' 보존", needle in readme)

# 의도된 제거
for needle in [
    "## 🏆 토큰 사용량 — 82일",         # 옛 헤더
    "[![Tokscale Stats](",              # 옛 단일 임베드
]:
    chk(f"'{needle}' 제거", needle not in readme)

# 응답 헤더
# GitFut: HTTP/2 200, content-type: image/png, max-age=3600
# Tokscale: HTTP/2 200, content-type: image/svg+xml, max-age=0
```

## 권장 패턴 요약

- **B 듀얼 카드** 채택 — 좌 GitFut + 우 Tokscale
- **`<sub>` 한 줄 압축 attribution** (3개 링크)
- **`?country=KR`** 쿼리로 사용자 정체성 일치
- **`width="280"` + `width="360"`** 고정 + 모바일 wrap 의도
- **push 전 200 OK 사전 확인** (GitFut PNG + Tokscale SVG)
