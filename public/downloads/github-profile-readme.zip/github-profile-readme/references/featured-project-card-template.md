---
name: featured-project-card-template
description: |
  GitHub Profile README의 Featured Project 섹션용 2-col 테이블 카드 템플릿.
  카테고리에 안 잡히는 시그니처 단일 프로젝트 (예: 134개 repo 중 MIT fork한
  인터랙티브 시각화) 를 노출할 때 사용. MIT/BSD/Apache 등 permissive 라이선스의
  fork 프로젝트인 경우 원작자 attribution 의무 충족. 2026-07-09 sigco3111 Repolis
  추가 세션에서 검증.
---

# Featured Project 카드 템플릿

## ⚠️ 2026-07-09 정정 — HTML `<table>` 사용 금지

**GitHub Profile README는 HTML `<table>`을 지원하지 않음** (함정 7 참조). raw HTML 태그가 텍스트로 노출됨. **반드시 표준 Markdown**으로 작성.

이 템플릿의 v1(HTML 테이블)은 더 이상 권장 안 함. v2(단순 카드) 또는 v3(MD 표준 테이블) 중 선택.

---

## v2: 단순 카드 (★ 권장, 2026-07-09 검증)

```markdown
## 🌐 Featured Project

### 🏙️ {프로젝트명} — {한 줄 한국어 디스크립션}

**{핵심 기술 1줄 설명}** — {차별점 + 임팩트 한 줄}

🌐 [**{사용자 도메인}/{repo-name}**](https://{user}.github.io/{repo}/) · 📦 [GitHub repo](https://github.com/{user}/{repo}) · 🚕 {핵심 기능} · 🎨 {톤} · 🛠 {tech1} · {tech2} · {tech3}

<sub>🎨 원작자 [@{원작자_핸들}](https://github.com/{원작자_핸들}) · {LICENSE} fork</sub>
```

**장점**:
- ✅ GitHub Markdown 100% 호환 — HTML 태그 노출 0건
- ✅ 단일 라인 메타로 4~5개 정보 압축 (badge 효과)
- ✅ attribution 짧게 — 1줄 sub
- ✅ 모바일/데스크탑 모두 깨짐 없음

**단점**:
- ❌ 2-col 시각 분할 없음 (좌측/우측 명확 분리 안 됨)

### 검증된 인스턴스 (sigco3111 Repolis v2, 2026-07-09)

```markdown
## 🌐 Featured Project

### 🏙️ Repolis — 레포들의 도시

**Three.js로 구현한 walkable 3D city** — 134개 GitHub repo가 건물로 살아 숨 쉬고, LLM 택시가 어느 repo든 안내해줍니다.

🌐 **[sigco3111.github.io/Repolis](https://sigco3111.github.io/Repolis/)** · 📦 [GitHub repo](https://github.com/sigco3111/Repolis) · 🚕 LLM 택시 · 🎨 Ghibli 톤 · 🛠 Three.js · WebGL · GitHub Actions

<sub>🎨 원작자 [@hyeonsangjeon](https://github.com/hyeonsangjeon) · MIT fork</sub>
```

---

## v1 (구버전, HTML 테이블 — ❌ 비권장)

GitHub Profile README에서 **렌더 안 되는** HTML. 역사적 참고용으로만 보존.

```markdown
## 🌐 Featured Project

<table>
  <tr>
    <td width="62%" valign="top">

### 🏙️ {프로젝트명} — {한 줄 한국어 디스크립션}

**{핵심 기술 1줄 설명}** — {차별점 + 임팩트 한 줄}

🌐 [**{사용자 도메인}/{repo-name}**](https://{user}.github.io/{repo}/) · 📦 [GitHub repo](https://github.com/{user}/{repo})

<sub>🎨 원작자 [**@{원작자_핸들}**](https://github.com/{원작자_핸들}) 님의 [{원작자_repo}](https://github.com/{원작자_핸들}/{원작자_repo}) ({N}⭐, {LICENSE}) 를 fork하여 {변형 내용}했습니다.</sub>

    </td>
    <td width="38%" valign="top">

**🛠 Tech**  
`{tech1}` · `{tech2}` · `{tech3}` · `{tech4}`

**🎨 Style**  
{스타일 1줄}

**🚕 Feature**  
{핵심 기능 1줄}

**📐 Scale**  
{스케일/숫자}

    </td>
  </tr>
</table>
```

**v1 → v2 전환 이유 (2026-07-09 실측)**:
- 푸시 후 Profile 스크린샷에서 `</td>`, `<td width="38%" valign="top">` 가 텍스트 그대로 노출됨
- 사용자 "위치 + 디자인 다 잘못됨" → 재수정 1회 추가 발생
- **교훈**: 표준 MD이 가장 안전. 2-col 시각 구도가 정말 필요하면 v3(MD 테이블) 검토

---

## v3: MD 표준 테이블 (OK, 2-col 시각 구도가 진짜 필요할 때)

```markdown
## 🌐 Featured Project

| 영역 | 내용 |
|---|---|
| 🏙️ **프로젝트명** | **핵심 기술 1줄 설명** — 차별점 한 줄 |
| 🌐 **데모** | [sigco3111.github.io/Repolis](https://sigco3111.github.io/Repolis/) |
| 📦 **소스** | [github.com/user/repo](https://github.com/user/repo) |
| 🛠 **Tech** | `Three.js` · `WebGL` · `Three-Bvh-Csg` · `GitHub Actions` |
| 🚕 **Feature** | LLM 택시 — "어느 레포 가줘" |
| 📐 **Scale** | 134 buildings |
| 🎨 **원작자** | [@hyeonsangjeon](https://github.com/hyeonsangjeon) · MIT fork |
```

**장점**:
- ✅ HTML 없음 — GitHub Markdown 100% 호환
- ✅ 2-col 시각 구도 유지
- ✅ 모바일에서 자동 stack

**단점**:
- ❌ Featured Project 같은 "카드형 강조"보다 표에 가까움 — 시각 임팩트 ↓
- ❌ attribution이 표 안 한 줄 (sub 톤 약함)

**사용 시점**: 여러 Featured Project를 한 섹션에 모아 비교할 때 유용 (예: 3개 featured 카드).

---

## 슬롯 변수 치트시트 (v2 기준)

| 변수 | 의미 | 예시 |
|---|---|---|
| `{프로젝트명}` | 메인 이름 | Repolis |
| `{한 줄 한국어 디스크립션}` | 부제목 | 레포들의 도시 |
| `{핵심 기술 1줄 설명}` | 핵심 스택 한 줄 | Three.js로 구현한 walkable 3D city |
| `{차별점 + 임팩트 한 줄}` | 134개 repo 적용 등 | 134개 GitHub repo가 건물로 살아 숨 쉬고 |
| `{사용자 도메인}` | GitHub Pages URL | sigco3111.github.io |
| `{repo-name}` | repo 슬러그 | Repolis |
| `{user}` | GitHub 핸들 | sigco3111 |
| `{원작자_핸들}` | 원작자 (fork인 경우만) | hyeonsangjeon |
| `{LICENSE}` | 라이선스 약어 (fork인 경우만) | MIT |
| `{핵심 기능}` | 가장 차별적인 기능 한 단어 | LLM 택시 |
| `{톤}` | 시각/UX 톤 한 단어 | Ghibli 톤 |
| `{tech1..3}` | 우측 칸 기술 스택 | Three.js · WebGL · GitHub Actions |

## Attribution 의무 정리

라이선스별 의무:

| 라이선스 | Attribution 의무 |
|---|---|
| **MIT** | 원작자 + 라이선스 문구 보존. README/CD/UI 어느 곳에든 OK. |
| **BSD-2/3-Clause** | 원작자 + 라이선스 + 면책 문구 보존. |
| **Apache-2.0** | 원작자 + 라이선스 + NOTICE 파일 보존 (별도 파일 가능). |
| **GPL-2.0/3.0** | 원작자 + 라이선스 + 소스 공개 의무 (⚠️ 보통 fork 자체엔 영향 없음, 재배포 시에만). |
| **All Rights Reserved** | ⚠️ fork/재배포 자체가 금지될 수 있음. 사전 허가 필수. |

**이 템플릿의 attribution 패턴 (MIT 검증)**:
```markdown
🎨 원작자 [@{핸들}]({프로필_URL}) 님의 [{repo}]({repo_URL}) ({N}⭐, {LICENSE}) 를 fork하여 {변형}했습니다.
```

**충족 요소**:
- ✅ 원작자 GitHub 핸들 + 프로필 링크
- ✅ 원본 repo + repo 링크
- ✅ 라이선스 약어 (MIT)
- ✅ 변경 내용 1줄
- ✅ `<sub>` 톤 — 시각 임팩트 ↓, 감사 표시는 분명히

## 검증 워크플로 (5-step)

Featured Project 섹션을 README에 patch한 후:

1. **로컬 pre-check** — `grep -c "## 🌐 Featured Project" README.md` → 1
2. **Patch 후 어서션** — section header, 라이브 URL, fork repo URL, 원작자 핸들, MIT 표기, Three.js 언급 모두 README에 있는지
3. **Patch 전 unique match** — `grep -c "## 🧰 Tech Stack" README.md` → 1 (anchor 헤더가 한 번만 등장하는지; 함수정 3 회피)
4. **Push 후 3-way SHA256** — LOCAL == RAW == API 모두 일치 (함정 1)
5. **Profile HTML 렌더** — Repolis, hyeonsangjeon, Featured Project, 레포들의 도시 모두 렌더링 확인 (함정 5 — 작은따옴표 둘 다 허용)

## 흔한 실수 5가지

| 실수 | 해결 |
|---|---|
| 1. 원작자 링크 1개만 (핸들만 또는 repo만) | 둘 다 명시 — GitHub 표준 표기 |
| 2. 라이선스 약어 누락 | (MIT), (Apache-2.0) 형태로 명시 |
| 3. 변경 내용 누락 | "{변형}했습니다" 1줄 필수 |
| 4. `<sub>` 대신 `**bold**` 사용 | 너무 눈에 띔. `<sub>` 작게 |
| 5. anchor 헤더가 2번 등장 (What I Build 패턴 잔재) | patch 전 unique match 확인 (함정 3) |

## 배치 비교

| 배치 | 장점 | 단점 | 추천? |
|---|---|---|---|
| **A. Stats ↔ 카테고리 사이** | 시각 임팩트 + attribution 자연스러움 + 확장성 | 섹션 1개 추가 | ✅ |
| **B. Let's Connect 안 한 줄** | 변경 최소 | 시선 분산, attribution 어색 | ❌ |
| **C. Tech Stack 표 인라인** | 가장 minimal | 묻힘 | ❌ |

---

## 실전 검증 노트 (2026-07-09 sigco3111 Repolis)

- **로컬 사전 검증**: 20/20 어서션 통과
- **Push**: `e4c667e..6b7b752` force push 성공
- **3-way SHA256**: LOCAL == RAW == API 모두 `2da8187d...3fff5` 완전 일치
- **Profile HTML 렌더**: Repolis · hyeonsangjeon · Featured Project · 레포들의 도시 · 라이브 URL 모두 ✅
- **.git fsck**: 무에러, working tree clean
- **README.md +35 lines** (2,668 → 3,763 bytes)

## 다음 확장 아이디어

이 템플릿은 Featured Project **1개**용. 향후:
- 2~3개 featured 추가 시 — 같은 카드 반복 (위양/아래양으로)
- 카테고리 변경 (Featured → 🚀 Side Projects 등)
- 라이브 데모 비디오/스크린샷 박기 (정적 자산이 있는 경우)

---

**Author**: HyeRin (MiniMax)
**Verified**: 2026-07-09 in sigco3111 Profile Repolis addition