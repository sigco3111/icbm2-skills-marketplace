# 듀얼 카드 "제거" 케이스 스터디 (sigco3111, 2026-07-24)

## 컨텍스트

sigco3111 GitHub 프로필 README에 `## ⚽🃏 듀얼 스카우트 카드 — GitHub Stats` 섹션이
있었음 (af0214d에서 듀얼 카드로 단순화). 사용자가 "튜얼 스카우트 카드를 제거하자"
요청 → 단순 patch로 끝날 줄 알았으나, **듀얼 카드가 GitHub Stats 3종 카드를 흡수한
상태**였기 때문에 stats 카드의 귀착을 먼저 결정해야 했음.

## 작업 타임라인

| # | 단계 | 산출물 | 검증 |
|---|------|--------|------|
| 1 | 사용자 요청: "듀얼 스카우트 카드를 제거하자" | — | — |
| 2 | skill_view로 `github-profile-readme` 로드 + 현재 README 가져오기 | 듀얼 카드 L50~L72 식별 | gh API 95라인 |
| 3 | 1차 patch: 듀얼 카드 영역만 제거 | `--- ## 🧰 Tech Stack` 직접 연결 | 로컬 grep |
| 4 | **사용자 OOB 정정**: "GitHub Stats는 남겨야지, 듀얼 스카우트 카드 부분만 제거" | — | — |
| 5 | 롤백: 듀얼 카드 영역 복원 | 원상복구 | git diff 확인 |
| 6 | git log 분석: af0214d에서 듀얼 카드로 단순화, ac9c9a1 이전엔 stats 3종 별도 | — | git show |
| 7 | 2차 patch (2-step): 듀얼 카드 → `## 📊 GitHub Stats` 섹션 + sigma-kohl stats/langs + herokuapp streak | -20/+5 라인 | 0 pattern 잔존 + 1×3 stats URL |
| 8 | 푸시 + 3-way SHA256 검증 | c7e734e4... | 로컬 == raw == API |

총 4 patch 발생 (1차 잘못된 patch 1 + 롤백 1 + 2차 patch 2). **0 patch + clarify 1회**로 줄일 수 있었음.

## 발견한 핵심 함정

### 1. "듀얼 카드 제거"는 단순 삭제가 아님 — stats 카드 흡수 여부 확인 필수

af0214d (`fix: 듀얼 카드를 GitFut + streak으로 단순화, table로 정렬 고정`) 시점에
GitHub Stats 3종이 듀얼 카드 안으로 흡수됨. 이 상태에서 듀얼 카드만 제거하면:

- ❌ stats 카드 3종 전체가 README에서 사라짐
- ❌ "Stats가 통째로 빠졌네?" → 사용자 발견 (또는 후속 작업에서 문제 노출)
- ❌ visual 임팩트 ↓ (GitHub 활동성 시각화 0)

**진단 명령 (push 전 필수)**:
```bash
# 1) 현재 README에서 stats URL 흔적
grep -c "github-readme-stats" README.md
grep -c "herokuapp" README.md
# 0건이면 듀얼 카드가 흡수한 상태

# 2) git log에서 흡수 시점 식별
git log --all --oneline | grep -i "듀얼\|dual" | head -5
# → "fix: 듀얼 카드를 GitFut + streak으로 단순화" 같은 커밋

# 3) 직전 정상 커밋 확인 (stats 3종이 별도 섹션으로 있던 시절)
git show <직전_정상_커밋>:README.md | grep -B2 -A5 "github-readme-stats"
```

### 2. 사용자 OOB 정정 패턴 — 짧은 단어 신호 = 강한 의도

사용자 메시지:
> "GitHub Stats는 남겨야지, 듀얼 스카우트 카드 부분만 제거해달라는 요청임"

해석: 본문 "제거" 표현만 보고 단순 제거한 게 사용자 의도와 다름. **OOB 정정 = 본 요청의
수정으로 즉시 반영** 원칙에 따라 rollback + 재patch 진행.

**교훈**: "제거/삭제" 같은 강한 동사 + 정정 OOB가 늦게 도착하는 패턴 → patch 전
**clarify 도구로 의도 확인**이 시간 절약.

### 3. 2-step patch 안전판 패턴

B안(듀얼 카드 → Stats 3종) 채택 시 다음 순서가 안전:

```python
# 1단계: 듀얼 카드를 다시 원복 (rollback 안전판)
patch(old="---\n\n## 🧰 Tech Stack",
      new="---\n\n## ⚽🃏 듀얼 스카우트 카드 — GitHub Stats\n\n<table>...\n\n---\n\n## 🧰 Tech Stack")

# 2단계: 듀얼 카드를 Stats 3종으로 교체
patch(old="---\n\n## ⚽🃏 듀얼 스카우트 카드 — GitHub Stats\n\n<table>...\n\n---\n\n## 🧰 Tech Stack",
      new="---\n\n## 📊 GitHub Stats\n\n<p align=\"left\">\n  <img src=\"...stats sigma-kohl...\" height=\"165\" />\n  <img src=\"...top-langs sigma-kohl...\" height=\"165\" />\n  <img src=\"...herokuapp streak...\" height=\"165\" />\n</p>\n\n---\n\n## 🧰 Tech Stack")
```

왜 1+2 단계로 나누나:
- 1단계 후 `git diff`로 듀얼 카드 정상 복원 확인 → 다음 patch의 old_string이 README에 존재함이 보장됨
- 만약 1단계 없이 바로 2단계 시도 → old_string 매칭 실패 (이미 1차 patch에서 듀얼 카드가 사라졌으므로)

## 최종 B안 결과 (이 세션에서 채택)

**before** (95 라인):
```markdown
---

## ⚽🃏 듀얼 스카우트 카드 — GitHub Stats

<table align="center">
  <tr>
    <td align="left" width="300">
      <a href="https://gitfut.com/sigco3111">
        <img src="https://gitfut.com/sigco3111.png?country=KR" width="280" alt="..."/>
      </a>
    </td>
    <td align="right" width="540">
      <img src="https://github-readme-streak-stats.herokuapp.com/?user=sigco3111&..."/>
    </td>
  </tr>
</table>

<p align="center">
  <sub>⚽ GitFut — FIFA-style player card · 🔥 Streak — 1,215 total</sub>
</p>

---

## 🧰 Tech Stack
```

**after** (81 라인):
```markdown
---

## 📊 GitHub Stats

<p align="left">
  <img src="https://github-readme-stats-sigma-kohl.vercel.app/api?username=sigco3111&show_icons=true&theme=tokyonight&hide_border=true&count_private=false" height="165" alt="stats — public stats, commits, PRs, stars"/>
  <img src="https://github-readme-stats-sigma-kohl.vercel.app/api/top-langs/?username=sigco3111&layout=compact&theme=tokyonight&hide_border=true&count_private=false" height="165" alt="languages — public repos only"/>
  <img src="https://github-readme-streak-stats.herokuapp.com/?user=sigco3111&theme=tokyonight&hide_border=true" height="165" alt="streak — current/longest contributions"/>
</p>

---

## 🧰 Tech Stack
```

## 3-way SHA256 검증 코드 (푸시 후 60초 이내)

```python
import hashlib, json, urllib.request, base64
from pathlib import Path

REPO = Path("/Users/mac/work/sigco3111-readme-edit/sigco3111")
USER = "sigco3111"
UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) hermes-verify"

def fetch(url, timeout=20):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()

# 3-way: 로컬 + raw + API
local_sha = hashlib.sha256((REPO / "README.md").read_bytes()).hexdigest()
import time
raw = fetch(f"https://raw.githubusercontent.com/{USER}/{USER}/main/README.md?nocache={int(time.time())}")
raw_sha = hashlib.sha256(raw).hexdigest()
api = json.loads(fetch(f"https://api.github.com/repos/{USER}/{USER}/contents/README.md"))
api_content = base64.b64decode(api["content"]).decode()
api_sha = hashlib.sha256(api_content.encode()).hexdigest()

assert local_sha == raw_sha == api_sha, f"SHA mismatch: local={local_sha[:8]} raw={raw_sha[:8]} api={api_sha[:8]}"
print(f"✅ 3-way SHA256 일치: {local_sha[:16]}...")

# 변경 의도 검증 (컨텍스트 단위)
removed = ["gitfut.com", "GitFut", "FIFA-style", "듀얼 스카우트", "1,215"]
for pat in removed:
    assert pat not in api_content, f"❌ '{pat}' still present"

stats = [
    "https://github-readme-stats-sigma-kohl.vercel.app/api?username=sigco3111",
    "https://github-readme-stats-sigma-kohl.vercel.app/api/top-langs/?username=sigco3111",
    "https://github-readme-streak-stats.herokuapp.com/?user=sigco3111",
]
for url in stats:
    assert url in api_content, f"❌ '{url}' missing"
print(f"✅ Stats 3종 + 의도된 제거 모두 OK")
```

## 3-옵션 결정 매트릭스 (clarify 도구용)

| 옵션 | 동작 | 듀얼 카드 | stats 3종 | 적합 상황 |
|------|------|----------|----------|----------|
| **A** | 듀얼 카드만 제거 | ❌ 제거 | ❌ 같이 제거 (흡수된 상태면 통째 소실) | 듀얼 카드 도입 전 stats 3종이 별도였던 시절 (이번 sigco3111 케이스 아님) |
| **B** ★ | 듀얼 카드 제거 + stats 3종 복원 | ❌ 제거 | ✅ `## 📊 GitHub Stats`로 복원 | 이번 세션 채택. ac9c9a1 패턴 |
| **C** | 듀얼 카드 제거 + stats 3종도 의도적 제거 | ❌ 제거 | ❌ 제거 | 의도적 미니멀화. 사용자 명시 OK 필요 |

## push 전 가용성 검증 (B안 채택 시 필수)

```bash
curl -sI "https://github-readme-stats-sigma-kohl.vercel.app/api?username=sigco3111&show_icons=true&theme=tokyonight&hide_border=true&count_private=false" | head -1
# HTTP/2 200

curl -sI "https://github-readme-stats-sigma-kohl.vercel.app/api/top-langs/?username=sigco3111&layout=compact&theme=tokyonight&hide_border=true&count_private=false" | head -1
# HTTP/2 200

curl -sI "https://github-readme-streak-stats.herokuapp.com/?user=sigco3111&theme=tokyonight&hide_border=true" | head -1
# HTTP/1.1 200 OK
```

3개 URL 모두 200 OK 확인 후 푸시. 깬 카드 1개라도 발견되면 stats 3종이 모두 깨질 위험
(시각 임팩트 0) → sigma-kohl 미러 fallback (함정 10).

## 권장 워크플로우 (다음에 같은 요청이 올 때)

1. 사용자 "X 카드 제거" 요청 받음
2. `git log` + `grep`로 X 카드가 다른 카드를 흡수했는지 확인
3. **clarify 도구로 3-옵션 제시** (A/B/C) + 추천
4. 사용자 응답 후 1회 patch 진행 (2-step 안전판)
5. 푸시 + 3-way SHA256 검증 + 의도된 패턴 grep

**소요 시간**: 1~3분 (0 patch + clarify 1회) vs 이번 세션 4 patch + 5분 (clarify 없이 진행)
