# GitFut 단독 섹션 제거 — sigco3111 2026-08-03 케이스 스터디

> **상황**: README 오버뷰의 `## ⚽ GitFut` 단독 섹션만 제거. stats 카드 흡수 상태가 아닌 (stats 3종이 별도 `## 📊 GitHub Stats` 로 분리된) 일반 케이스. 80점 도달 후 다시 노출 예정.

## 📌 핵심 결과 요약

| 항목 | 값 |
|---|---|
| 커밋 SHA | `9dae9ca → b254919` |
| 변경 라인 | 25줄 삭제 |
| patch 횟수 | 1회 (단독 patch로 끝) |
| clarify | 1회 (3-옵션 매트릭스) |
| 푸시 | `--force` (safety net, 실제론 fast-forward 가능) |
| 검증 | 3-way SHA256 일치 (로컬=raw=API=1c8589a3aa82) |
| 헤더 변화 | 6 → 5 (정확히 -1) |

## 🔍 사전 진단: 듀얼 카드 워크플로우와 분기

이번 케이스가 **2026-07-24 듀얼 카드 워크플로우**가 아닌 이유:

```bash
# 2026-08-03 시점 README 진단
gh api repos/sigco3111/sigco3111/contents/README.md --jq '.content' | tr -d ' ' | base64 -d \
  | grep -nE "## 📊 GitHub Stats|## ⚽ GitFut|github-readme-stats|gitfut.com"
# 출력:
#   25:## ⚽ GitFut — sigco3111 카드 (71 SILVER · CAM · Fantasista)
#   50:## 📊 GitHub Stats
```

**판정 기준**:
- `## 📊 GitHub Stats` 섹션 **존재** (streak 1종) → stats 카드는 흡수된 상태 아님
- `## ⚽ GitFut` 단독으로 존재 → **GitFut 단독 섹션 제거 워크플로우** (이번 케이스)
- 만약 `## 📊 GitHub Stats` 가 없고 `gitfut.com` 만 stats 시그널을 포함 → **듀얼 카드 워크플로우** (2026-07-24)

## 🎯 clarify 3-옵션 매트릭스

```
Q: GitFut 섹션만 깔끔히 제거할까요? (현재 README에는 stats 3종이 이미 없으니 stats 보존 고민은 없음)
A. GitFut 섹션만 제거 (단순)                  ← 사용자 선택 ★
B. GitFut + 배너+카드 1줄 압축 보존
C. GitFut + Tokscale 통합 단축
```

**선택 사유**: 80점 도달 시 다시 노출 예정 → 통째 제거 후 복원 시점에 카드/배지/시그널 모두 새 점수로 재편집하는 게 더 자연스러움. 한 줄 압축 보존은 정보 손실 vs 복원 시 중복 편집 비용 trade-off.

## 📝 patch 1회 흐름

### old_string (25줄)

```markdown
---

## ⚽ GitFut — sigco3111 카드 (71 SILVER · CAM · Fantasista)

<p align="center">
  <a href="https://gitfut.com/sigco3111">
    <img src="https://gitfut.com/sigco3111.png"
         alt="GitFut card — sigco3111: 71 SILVER CAM Fantasista (PAC 76 · SHO 64 · PAS 67 · DRI 82 · DEF 47 · PHY 71)"
         width="320"/>
  </a>
</p>

<p align="center">
  <a href="https://gitfut.com/sigco3111">
    <img src="https://img.shields.io/badge/GitFut-71%20SILVER-39d353?style=for-the-badge&logo=github&logoColor=white" alt="GitFut 71 SILVER"/>
  </a>
  <a href="https://gitfut.com/sigco3111">
    <img src="https://img.shields.io/badge/CAM-Fantasista-c0c0c0?style=for-the-badge&logo=football&logoColor=white" alt="CAM Fantasista"/>
  </a>
</p>

<p align="center">
  <sub>🏗️ <b>GitFut이 측정하는 시그널</b>: PAC(올해 활동량) · SHO(별 받은 양) · PAS(외부 PR/팔로워) · DRI(언어 다양성) · DEF(리뷰/이슈) · PHY(lifetime 기여)</sub>
</p>

---

## 🏙️ 레포들의 도시 (sigco3111)
```

### new_string (1줄)

```markdown
---

## 🏙️ 레포들의 도시 (sigco3111)
```

### unique match 보장

- 직전 `---\n\n` 컨텍스트 포함 → README 내 `## ⚽ GitFut` 헤더는 1개뿐이라 unique 보장
- 직후 `## 🏙️ 레포들의 도시` 컨텍스트 포함 → 제거 후 다음 헤더가 정확히 매칭
- 4 블록 (`<p>` 3개 + 헤더) 모두 old/new 양쪽에서 unique 위치

## ✅ 검증 5-step

### 1. grep 잔존 검사 (anchor 단위)

```bash
cd ~/work/sigco3111-readme-edit/sigco3111
echo "=== 잔존 확인 ==="
grep -cE "GitFut|gitfut|시그널|CAM|Fantasista|⚽" README.md
# 기대: 0
```

### 2. 헤더 개수 카운트 (NEW, 2026-08-03)

```bash
grep -n "^## " README.md
# 기대: 5개
# 16:## 🏆 토큰 사용량 — 82일 5개 클라이언트 · 21개 모델
# 25:## 🏙️ 레포들의 도시 (sigco3111)
# 50:## 📊 GitHub Stats
# 58:## 🧰 Tech Stack
# 69:## 🤝 Let’s Connect
```

**6개면?** → 의도치 않은 헤더 추가됨 (예: 빈 헤더나 헤더 라인 누락)
**4개면?** → 의도치 않은 헤더 손실됨 (예: 인접 헤더까지 patch 가 잘못 잡음)

### 3. SHA256 3-way cross-check

```python
import hashlib, json, urllib.request, base64, time
from datetime import datetime, timezone

LOCAL = "/Users/mac/work/sigco3111-readme-edit/sigco3111/README.md"
USER = "sigco3111"
UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) hermes-verify"

time.sleep(30)  # raw CDN 캐시 안정화

local_bytes = open(LOCAL, "rb").read()
local_sha = hashlib.sha256(local_bytes).hexdigest()

_, raw_bytes = urllib.request.urlopen(urllib.request.Request(
    f"https://raw.githubusercontent.com/{USER}/{USER}/main/README.md?nocache={local_sha}",
    headers={"User-Agent": UA})).read(), None
raw_sha = hashlib.sha256(raw_bytes).hexdigest()

api_bytes = urllib.request.urlopen(urllib.request.Request(
    f"https://api.github.com/repos/{USER}/{USER}/contents/README.md",
    headers={"User-Agent": UA})).read()
api_content = base64.b64decode(json.loads(api_bytes)["content"])
api_sha = hashlib.sha256(api_content).hexdigest()

assert local_sha == raw_sha == api_sha
```

### 4. 의도 보존 검사 (anchor 컨텍스트 단위)

```python
readme = local_bytes.decode("utf-8")
preserve_anchors = [
    ("## 🏆 토큰 사용량", "Tokscale 섹션 보존"),
    ("## 🏙️ 레포들의 도시", "Featured Project 보존"),
    ("## 📊 GitHub Stats", "Stats (streak) 보존"),
    ("## 🧰 Tech Stack", "Tech Stack 보존"),
    ("## 🤝 Let’s Connect", "Let's Connect 보존"),
    ("134 public repos", "footer 보존"),
]
for anchor, label in preserve_anchors:
    assert anchor in readme, f"❌ 손상: {label}"
```

### 5. .git fsck

```bash
git -C ~/work/sigco3111-readme-edit/sigco3111 fsck --no-progress
# 기대: no output, exit 0
```

## 🔄 80점 도달 시 복원 워크플로

### 옵션 A: GitFut 블록 재삽입 (커밋 이력 활용)

```bash
cd ~/work/sigco3111-readme-edit/sigco3111

# 제거된 GitFut 블록 (b254919 직전 = 9dae9ca) 에서 발췌
git show 9dae9ca:README.md | sed -n '/^## ⚽ GitFut/,/^---$/p' > /tmp/gitfut_block.md

# 새 README에서 L{L16} (`## 🏆 토큰 사용량` 헤더 다음) 와 L{L25} (`## 🏙️ 레포들의 도시` 헤더 직전) 사이에 삽입
# → patch로 정확히 끼워 넣고, 카드 점수/시그널은 80점 기준으로 새 값 편집

# 새 카드 예시 (골드/아이콘 등급 도달 시)
# <img src="https://gitfut.com/sigco3111.png?country=KR"
#      alt="GitFut card — sigco3111: 80 GOLD CAM Fantasista (PAC X · SHO X · PAS X · DRI X · DEF X · PHY X)"
#      width="320"/>
```

### 옵션 B: revert + 재편집 (안전판)

```bash
git revert b254919 --no-commit
# 80점 시점의 점수/시그널로 README 편집
# git add README.md && git commit -m "docs(profile): GitFut 80 GOLD 재노출"
```

### 복원 시 주의

1. **카드 이미지 URL의 `?country=KR` 쿼리스트링**: 듀얼 카드 패턴 권장 (시각 임팩트 ↑)
2. **등급 색상 매칭**: 골드 `#E6B422`, SILVER `#AAB2BD`, BRONZE `#CD7F32`, TOTY `#3B7AFF`, Icon `#F3D688`
3. **shields.io 배지의 등급 텍스트 갱신**: `GitFut-71%20SILVER` → `GitFut-80%20GOLD` 같이 URL 인코딩된 라벨 동기화
4. **시그널 설명 (PAC/SHO/PAS/DRI/DEF/PHY)**: 새 점수에 맞춰 각 항목 한 줄 재편집

## 💡 핵심 교훈 (재발 방지)

### 1. "단독 제거" vs "듀얼 카드 제거" 분기 기준

| README 상태 | 워크플로우 |
|---|---|
| `## ⚽ GitFut` 단독 + `## 📊 GitHub Stats` 별도 | **단독 제거** (이번 케이스) |
| `## ⚽ GitFut` 만 있고 stats 흔적 0개 (듀얼 카드가 stats 흡수) | **듀얼 카드 제거** (2026-07-24) |

**예외**: `## ⚽ GitFut` 가 사라진 상태에서 `gitfut.com` URL이 다른 섹션 (예: Let's Connect 한 줄 링크) 에 남아있는 경우 → 단독 제거 후 잔존 grep으로 잡아야 함.

### 2. 헤더 개수 카운트 검증의 가치

이번에 의도치 않은 헤더 추가/손실은 없었지만, **헤더 개수 카운트** (의도 6→5, 결과 5) 가 단순 anchor grep 보다 강력한 이유:
- anchor grep 으로는 잡을 수 없는 케이스: patch 가 인접 헤더를 같이 제거/추가 (함정 3번)
- header count 가 정확히 의도된 만큼 변해야 "patch 매칭 위치 정확" 검증 가능
- 단순 anchor grep = 0 만으로는 "다른 헤더가 잘못 추가됨" 같은 케이스 못 잡음

### 3. clarify 의 가치

사용자가 "GitFut 섹션만 제거해줘"라고 분명히 말했지만, **clarify 1회 (3-옵션)** 로 A/B/C 의 명확화 → 후행 patch 1회 만에 통과. 추정으로 진행했다면 "한 줄 보존" 같은 의도와 어긋난 patch → 2 patch + rollback 가능성. 이번 케이스는 사용자 본문 의도가 분명했지만 그래도 옵션 1회 제시가 **정답**.

### 4. 푸시 --force 의 safety net 가치

이번엔 실제로 fast-forward 가능했지만 `--force` 사용. 향후 force 가 위험해지는 케이스:
- 다른 파일이 origin에 있을 때 (예: snake.svg 추가 후 다른 변경을 force push 하면 snake 도 같이 덮어씀)
- 단, 이번엔 README 단독 작업이라 다른 파일 없음 → 안전판으로 --force OK

## 📂 커밋 이력

```bash
git log --oneline | head -5
# b254919 docs(profile): GitFut 카드 섹션 제거 (80점 도달 전 임시)  ← 이번 커밋
# 9dae9ca docs(profile): GitHub Stats 섹션 streak 카드 가운데 정렬
# ec2c036 docs(profile): GitHub Stats 카드에서 stats + top-langs 제거, streak만 유지
# a5fa67b docs(profile): 듀얼 스카우트 카드 제거, GitHub Stats 3종 섹션 복원
# e6aa3f7 docs: remove Gemini CLI from AI 코딩 어시스턴트, Tistory API from 자동화 in Tech Stack
# af0214d fix: 듀얼 카드를 GitFut + streak으로 단순화, table로 정렬 고정
```

af0214d → ec2c036 → a5fa67b → e6aa3f7 → 9dae9ca → b254919 흐름에서 **GitFut 카드의 위치가 변천**:
- af0214d: 듀얼 카드 (GitFut + streak)
- ec2c036: stats 3종 복원 (stats + langs + streak), GitFut 카드 위치 변경 없음
- a5fa67b: 듀얼 스카우트 카드 제거 (stats 3종 + GitFut 단독으로 분기)
- 9dae9ca: streak 가운데 정렬
- b254919: **GitFut 단독 제거** (이번)

## 🔗 관련 references

- `references/dual-card-removal-2026-07-24.md` — 듀얼 카드 제거 워크플로우 (분기 기준 비교용)
- `references/dual-card-embed.md` — GitFut 카드 임베드 패턴 (복원 시 참조)
- `templates/profile-readme-template.md` — sigco3111 검증 프로필 README 골격