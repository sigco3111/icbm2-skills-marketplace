# Featured Project 카드 — 실제 케이스 스터디

2026-07-09 sigco3111 Featured Project 작업의 전체 진화 과정 + 실측 데이터.
다음에 비슷한 작업할 때 복사-붙여넣기 + 회피 패턴 참고.

## 케이스: sigco3111/Repolis (Three.js walkable 3D city)

### 의도

- **프로젝트**: sigco3111이 fork한 인터랙티브 3D 시각화 (134개 GitHub repo가 3D 도시로 사는 walkable city)
- **원작자**: `@hyeonsangjeon` ([hyeonsangjeon/Repolis](https://github.com/hyeonsangjeon/Repolis), 14⭐, MIT)
- **목표**: GitHub Profile README에 Featured Project 섹션으로 노출 (시각 임팩트 ↑ + attribution 분명)
- **최종 위치**: 토큰 사용량 ↔ GitHub Stats 사이 (L16 ↔ L25)

### 단계별 진화 (실제 git 커밋 기록)

| # | 커밋 SHA | 시도 | 결과 |
|---|---|---|---|
| 1 | `6b7b752` | v1 — 2-col HTML `<table>` 카드, 위치 = Stats ↔ Tech Stack 사이 | ❌ `</td>` `<td width="38%">` raw 노출 |
| 2 | `f72cfa5` | v2 — 단순 markdown 카드 + 짧은 attribution, 위치 = Tokscale ↔ Stats 사이로 이동 | ✅ 통과 (HTML 태그 0건) |
| 3 | `975d192` | E안 — v2 + 배너 SVG + 2개 CTA shields 배지 | ✅ 통과 |
| 4 | `af13727` | 헤더 한글화 — `🌐 Featured Project` → `🏙️ 레포들의 도시 (sigco3111)` | ✅ 통과 |

총 4회 푸시. v1은 백지화 + 재작업.

### v1 — HTML 테이블 (실패 사례)

```markdown
## 🌐 Featured Project

<table>
  <tr>
    <td width="62%" valign="top">

### 🏙️ Repolis — 레포들의 도시

**Three.js로 구현한 walkable 3D city** — 134개 GitHub repo가 건물로 살아 숨 쉬고, LLM 택시가 어느 repo든 안내해줍니다.

🌐 [**sigco3111.github.io/Repolis**](https://sigco3111.github.io/Repolis/) · 📦 [GitHub repo](https://github.com/sigco3111/Repolis)

<sub>🎨 원작자 [**@hyeonsangjeon**](https://github.com/hyeonsangjeon) 님의 [Repolis](https://github.com/hyeonsangjeon/Repolis) (14⭐, MIT) 를 fork하여 한국어 디스크립션 + sigco3111 데이터로 재구성했습니다. 컨셉과 엔진은 원작의 훌륭한 설계 덕분입니다.</sub>

    </td>
    <td width="38%" valign="top">

**🛠 Tech**  
`Three.js` · `WebGL` · `Three-Bvh-Csg` · `GitHub Actions`

**🎨 Style**  
Studio Ghibli 톤 · 낮/밤 사이클

**🚕 Feature**  
LLM 택시 — "어느 레포 가줘" 한마디로 navigate

**📐 Scale**  
134 buildings (모든 public repo)

    </td>
  </tr>
</table>
```

**푸시 후 렌더 (스크린샷 확인됨)**:
```
🌐 sigco3111.github.io/Repolis · 📦 GitHub repo · ...

</td>
    <td width="38%" valign="top">
**🛠 Tech**
`Three.js` · `WebGL` ...
```

→ HTML 태그가 텍스트 그대로 노출됨. GitHub Profile README는 GFM만 지원, HTML `<table>` 미지원.

### v2 — 단순 markdown 카드 (통과)

```markdown
## 🌐 Featured Project

### 🏙️ Repolis — 레포들의 도시

**Three.js로 구현한 walkable 3D city** — 134개 GitHub repo가 건물로 살아 숨 쉬고, LLM 택시가 어느 repo든 안내해줍니다.

🌐 **[sigco3111.github.io/Repolis](https://sigco3111.github.io/Repolis/)** · 📦 [GitHub repo](https://github.com/sigco3111/Repolis) · 🚕 LLM 택시 · 🎨 Ghibli 톤 · 🛠 Three.js · WebGL · GitHub Actions

<sub>🎨 원작자 [@hyeonsangjeon](https://github.com/hyeonsangjeon) · MIT fork</sub>
```

**위치 변경**: 처음 Stats 아래 (잘못) → Tokscale ↔ Stats 사이 (옳음). plan 단계 cross-check 부족으로 1회 재수정 발생.

### v3 — E안 시각 부각 (최종)

```markdown
## 🌐 Featured Project

<p align="center">
  <a href="https://sigco3111.github.io/Repolis/">
    <img src="https://sigco3111.github.io/Repolis/assets/banner.svg"
         alt="Repolis — the City of Repos · Walkable 3D city of 134 GitHub repos with an LLM taxi driver"
         width="720"/>
  </a>
</p>

<p align="center">
  <a href="https://sigco3111.github.io/Repolis/">
    <img src="https://img.shields.io/badge/Live_Demo-sigco3111.github.io%2FRepolis-2bb8a3?style=for-the-badge&logo=github-pages&logoColor=white" alt="Live Demo"/>
  </a>
  <a href="https://github.com/sigco3111/Repolis">
    <img src="https://img.shields.io/badge/Source-Repository-1d3b3f?style=for-the-badge&logo=github&logoColor=white" alt="Source"/>
  </a>
</p>

<p align="center">
  <sub>🎨 원작자 <a href="https://github.com/hyeonsangjeon"><b>@hyeonsangjeon</b></a> · MIT fork · Three.js · WebGL · LLM taxi</sub>
</p>
```

**v2 → v3 진화 의도**: "sigco3111.github.io/Repolis 를 좀 부각시킬 방법이 없을까?" (사용자 요청) → 5개 옵션 brainstorm → E안 선택.

**E안 구성 요소**:
- 배너 SVG (`sigco3111.github.io/Repolis/assets/banner.svg`, 1200x340, 7.3KB)
- Live Demo shields 배지 (`#2bb8a3`, 배너 청록 매칭)
- Source shields 배지 (`#1d3b3f`, 배너 타이틀 매칭)
- 짧은 attribution (v2와 동일)

### v3+ — 한글 헤더

```markdown
## 🏙️ 레포들의 도시 (sigco3111)
```

**v3 → v3+ 진화 의도**: "섹션 제목만 한국어로 변경했으면 좋겠는데, 뭐가 좋을까?" → 사용자 직접 선택 ("레포들의 도시 (sigco3111)").

## 발견한 함정 + 우회 (실전 검증)

### 1. shields.io URL에 이모지 (👀📦)

**실패**:
```
https://img.shields.io/badge/👀_Live_Demo-...-2bb8a3
```
→ Python urllib `'ascii' codec can't encode character '\U0001f440'`

**성공**:
```
https://img.shields.io/badge/Live_Demo-...-2bb8a3
```
→ 200 OK, 시각 임팩트 동일 (for-the-badge + 색상이 임팩트 담당)

### 2. raw CDN 5분 캐시

푸시 직후 `raw.githubusercontent.com`는 `cache-control: max-age=300` 캐시. SHA256 false negative.

**해결**:
```bash
curl -s "https://raw.githubusercontent.com/.../README.md?nocache=$(date +%s)"
```

### 3. anon GitHub API rate limit

Vercel/공유 IP에서 anon curl이 IP당 60/h 초과 빈번. `{"message":"API rate limit exceeded..."}` 응답.

**해결**:
```bash
# gh api는 OAuth 인증 — rate limit 5000/h
gh api repos/X/X/contents/README.md --jq '.content' | base64 -d
```

### 4. 검증 시 `<table>` false-positive

`<table>` 노출을 잡으려다 **Tech Stack 정상 MD 테이블**이 만든 `<table>`까지 false-positive.

**해결**: Featured Project 카드 영역만 잘라서(`re.search(r"Featured Project.*?Stats", html, re.S)`) 그 안에서만 검사.

### 5. 사용자 위치 의도 cross-check 부족

사용자가 "토큰 사용량과 GitHub Stats 중간" 의도였는데 agent가 "Stats ↔ Tech Stack 사이"로 plan. 푸시 후 재수정.

**해결 패턴 (다음에 적용)**:
- 사용자 본문에 "X와 Y 중간" 표현 → 정확한 헤더 매칭 후 plan에 L번호 명시
- plan에 `배치 후보 A/B/C` 표 + L번호 + 사용자 cross-check 질문
- 사용자 승인 시 위치도 같이 확인 받기

## 색상 카탈로그 (v3 매칭 패턴)

**Repolis 배너 SVG 색상 추출 결과** (스크립트):
```python
import re
svg = open("banner.svg").read()
colors = sorted(set(re.findall(r"#[0-9a-fA-F]{6}", svg)))
```

주요 색상:
- 청록 primary: `#2bb8a3` (집 지붕)
- 깊은 청록: `#1d3b3f` (배너 타이틀)
- 따뜻한 베이지: `#fbe8c8` (배경 그라데이션)

**shields 매칭 적용**:
- Live Demo: `#2bb8a3` (primary)
- Source: `#1d3b3f` (배너 타이틀)

→ 배너 자체와 shields가 시각적 색상 가족(family) 형성.

## 위치 카탈로그 (L번호 — 2026-07-09 sigco3111 README 기준)

```
L16: ## 🏆 토큰 사용량 — 82일 5개 클라이언트 · 21개 모델
L25: ## 🌐 Featured Project  ← 또는 L25: ## 🏙️ 레포들의 도시 (v3+)
L37: ## 📊 GitHub Stats
L47: ## 🧰 Tech Stack
L58: ## 🤝 Let's Connect
```

→ Featured Project는 **L25 (Tokscale 직후, Stats 직전)** 위치가 사용자 의도.

## 사전 검증 체크리스트 (이 케이스에서 사용한 것)

```python
# 1. 배너 SVG 가용성
import urllib.request
UA = "Mozilla/5.0 hermes-verify"
req = urllib.request.Request("https://sigco3111.github.io/Repolis/assets/banner.svg", headers={"User-Agent": UA})
with urllib.request.urlopen(req, timeout=15) as r:
    assert r.status == 200
    assert len(r.read()) > 1000  # SVG 본문 있음

# 2. shields URL 가용성 (이모지 없는 버전)
for url in [
    "https://img.shields.io/badge/Live_Demo-X-2bb8a3?style=for-the-badge",
    "https://img.shields.io/badge/Source-Y-1d3b3f?style=for-the-badge",
]:
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=15) as r:
        assert r.status == 200

# 3. README에 Featured Project 위치 anchor unique한지
import subprocess
r = subprocess.run(
    ["curl", "-s", "https://raw.githubusercontent.com/sigco3111/sigco3111/main/README.md"],
    capture_output=True, text=True
)
readme = r.stdout
assert readme.count("## 🧰 Tech Stack") == 1  # patch anchor 고유성
```

## 푸시 후 검증 패턴 (3-way + Profile HTML)

```python
import hashlib, urllib.request, base64, json, subprocess
from pathlib import Path

LOCAL = Path("/Users/mac/work/sigco3111-profile/README.md")
UA = "Mozilla/5.0 hermes-verify"

# 1-way LOCAL
local_sha = hashlib.sha256(LOCAL.read_bytes()).hexdigest()

# 2-way RAW (nocache)
req = urllib.request.Request(
    f"https://raw.githubusercontent.com/sigco3111/sigco3111/main/README.md?nocache={hash(local_sha) & 0xffffffff}",
    headers={"User-Agent": UA}
)
raw_body = urllib.request.urlopen(req, timeout=20).read()
raw_sha = hashlib.sha256(raw_body).hexdigest()

# 3-way API (gh OAuth)
r = subprocess.run(["gh", "api", "repos/sigco3111/sigco3111/contents/README.md"],
                   capture_output=True, text=True, timeout=20)
api_content = base64.b64decode(json.loads(r.stdout)["content"]).decode()
api_sha = hashlib.sha256(api_content.encode()).hexdigest()

assert local_sha == raw_sha == api_sha, "3-way SHA mismatch"

# Profile HTML 렌더 — Featured 영역만 추출
req = urllib.request.Request("https://github.com/sigco3111", headers={"User-Agent": UA})
html = urllib.request.urlopen(req, timeout=20).read().decode()

import re
fp_start = html.find("Featured Project")  # 또는 한글 헤더
gs_start = html.find("GitHub Stats")
featured = html[fp_start:gs_start]

# Featured 영역 안에서만 HTML 태그 0건 확인
for needle in ["<table>", "<tr>", "</td>", "<td ", 'valign=', 'width=']:
    assert needle not in featured, f"Featured 카드에 HTML 노출: {needle}"

# 핵심 의도 렌더 확인
for needle in ["Repolis", "hyeonsangjeon", "sigco3111.github.io/Repolis"]:
    assert needle in featured, f"의도 미렌더: {needle}"
```

## 보너스 — 배너 SVG 직접 다운로드

```bash
curl -sL "https://sigco3111.github.io/Repolis/assets/banner.svg" -o /tmp/repolis_banner.svg
file /tmp/repolis_banner.svg  # SVG Scalable Vector Graphics image
wc -c /tmp/repolis_banner.svg  # ~7.3KB
```

→ 1200x340, 7.3KB, "Repolis — the City of Repos" alt 텍스트. GitHub Markdown에서 SVG 직접 렌더 OK.