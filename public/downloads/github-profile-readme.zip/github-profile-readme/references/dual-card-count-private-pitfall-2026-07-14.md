# 듀얼 카드 / 카운트 프라이빗 함정 — 2026-07-14 sigco3111 사례

> **어디서 발견**: sigco3111/sigco3111 README 듀얼 카드 + GitHub Stats 카드 배치 시
> **실측 일자**: 2026-07-14

## 두 가지 핵심 발견

### 발견 1: `count_private=false`로 PAT_1 에러 우회 (가장 빠름)

sigma-kohl 미러(`github-readme-stats-sigma-kohl.vercel.app`)는 owner의 GitHub PAT를 `PAT_1` 환경변수로 등록해야 `count_private=true`가 작동함. owner가 미등록한 미러에서 `count_private=true`로 호출하면:

```
Maximum retries exceeded
Please add an env variable called PAT_1 with your github token in vercel
```

이라는 빨간 에러 박스로 렌더됨. **3번째 옵션(그냥 두기)** 대신 **4번째 옵션** 발견:

```diff
- <img src="https://github-readme-stats-sigma-kohl.vercel.app/api?username=X&show_icons=true&theme=tokyonight&hide_border=true&count_private=true" />
+ <img src="https://github-readme-stats-sigma-kohl.vercel.app/api?username=X&show_icons=true&theme=tokyonight&hide_border=true&count_private=false" />
```

`count_private=false`는 public 통계만 받으므로 PAT 불필요 → 200 OK 정상 작동.

**검증 명령** (push 전):
```bash
# ❌ PAT_1 에러 (owner가 PAT 미등록한 미러)
curl -sI "https://github-readme-stats-sigma-kohl.vercel.app/api?username=sigco3111&count_private=true" | head -1
# HTTP/2 200 (이미지 자체는 응답하지만 렌더링 시 에러 박스)

# ✅ 정상 (public only)
curl -sI "https://github-readme-stats-sigma-kohl.vercel.app/api?username=sigco3111&count_private=false" | head -1
# HTTP/2 200 + 정상 이미지
```

**trade-off**: private 커밋 카운트 빠짐. public 위주 README면 무관. (sigco3111는 100% public이라 손해 0.)

### 발견 2: 듀얼 카드의 "양쪽 정렬" 의도는 듀얼로 못 풀음

사용자 의도: "GitFut 좌측 + GitHub Stats 우측"

문제: 듀얼 카드 자체는 `<p align="center">` 안에서 좌우로 나란히 배치됨. 좌측 카드는 center 정렬의 절반 영역, 우측 카드도 마찬가지. **사용자가 원하는 "둘 다 다른 align"은 듀얼 구조에서 불가능.**

**해결 패턴 (검증됨)**:

**Option A: 듀얼 유지 + 같은 align** — `<p align="center">` 그대로 + 좌 GitFut + 우 stats. stats는 center 정렬 영역의 우측 절반.

**Option B: 단일 + 우측 분리 (사용자 선호)** — GitFut 카드만 `<p align="center">` 단독 배치. stats/stats langs/streak은 `<p align="right">`로 별도 묶음.

```markdown
<!-- GitFut 카드 (중앙 단독) -->
<p align="center">
  <a href="https://gitfut.com/sigco3111">
    <img src="https://gitfut.com/sigco3111.png?country=KR" width="280" alt="..."/>
  </a>
</p>

<p align="center">
  <sub>⚽ GitFut — FIFA-style player card ...</sub>
</p>

<!-- Stats 묶음 (우측 정렬) -->
<p align="right">
  <a href="...?count_private=false"><img src="...?count_private=false" height="180" alt="languages"/></a>
  &nbsp;&nbsp;
  <img src="https://github-readme-streak-stats.herokuapp.com/?user=sigco3111&..." height="180" alt="streak"/>
</p>
```

**근본 원인**: GitHub Markdown의 HTML `align` 속성은 부모 `<p>` 단위로만 적용. 한 줄에 `<p align="center">` + `<p align="right">`을 섞을 수 없음. 카드를 별도 단락으로 분리하는 것이 유일한 깔끔한 해법.

## 작업 위치/환경

- 작업 디렉토리: `/Users/mac/work/sigco3111-readme-edit/sigco3111/`
- 백업 자동 생성: `notebooklm_selection.json`처럼 `.bak_pre_*` prefix는 안 만들었음 (gh repo clone에서 시작)
- 검증 명령: `curl -sI <card url> | head -1`로 200 OK 사전 확인

## 커밋 이력

1. `910778f feat: 듀얼 스카우트 카드 — GitFut + Tokscale` (초기 듀얼, Tokscale 포함)
2. `2c9e6de refactor: 듀얼 카드를 GitHub Stats 섹션으로 이동` (위치 이동)
3. `e37bc24 refactor: 듀얼 카드를 GitFut + GitHub Stats로 재구성` (Tokscale 제거, stats 추가)
4. `ac9c9a1 fix: count_private=false로 PAT_1 에러 우회, stats 카드 우측 정렬` (발견 1+2 적용)

## 후세션 체크리스트

- [ ] 새 GitHub README 디자인 시 stats 카드 4종 모두 `count_private=false` 확인
- [ ] "양쪽 정렬" 사용자 요청 시 듀얼 → 단일+우측 분리 패턴 안내
- [ ] `gjc-cli-setup` SKILL.md alias 예시는 이미 `minimax-pro`로 수정됨 (다음 세션 검증 시점만 다름)
