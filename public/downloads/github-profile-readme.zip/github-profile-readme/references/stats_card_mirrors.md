#!/usr/bin/env bash
# stats_card_mirrors.md
# 2026-07-07 실전 검증. vercel.app 503 DEPLOYMENT_PAUSED 사건 이후 카탈로그 작성.
#
# 시나리오: github-readme-stats.vercel.app가 Vercel 정책상 일시 정지되면
# stats + top-langs 카드 2개가 "Error Fetching Resource"로 깨짐.
# streak 카드(herokuapp.com)는 영향 없음.
#
# 검증 방법:
#   for url in "${MIRRORS[@]}"; do
#     curl -sI "$url" | head -1
#   done
#
# 결과 (2026-07-07 21:50 UTC 기준):

| 미러 | stats endpoint | top-langs endpoint | 비고 |
|---|---|---|---|
| `github-readme-stats.vercel.app` | 503 DEPLOYMENT_PAUSED | 503 | **공식, 그러나 일시 정지됨** |
| `github-readme-stats-sigma-kohl.vercel.app` | 200 ✓ | 200 ✓ | **권장 fallback**, 쿼리 파라미터 100% 호환 |
| `github-readme-stats-git-main-sigco3111.vercel.app` | 404 | 404 | 안 됨 |
| `github-readme-stats-xi-two-26.vercel.app` | 404 | 404 | 안 됨 |
| `github-readme-streak-stats.herokuapp.com` | 200 ✓ | — | streak 카드만 별도 도메인 |

## 적용 패턴 (README patch)

```markdown
<!-- ❌ 깨진 패턴 -->
<img src="https://github-readme-stats.vercel.app/api?username=X&show_icons=true&theme=tokyonight&hide_border=true&count_private=true" />

<!-- ✅ sigma-kohl fallback -->
<img src="https://github-readme-stats-sigma-kohl.vercel.app/api?username=X&show_icons=true&theme=tokyonight&hide_border=true&count_private=true" />
```

## 재발 시 3단계 대응

1. **즉시 확인**: `bash scripts/check_stats_mirror.sh <username>` → exit code 2면 fallback
2. **README 수정**: stats/langs의 `src=` 2줄 patch (alt 명시 unique 매칭)
3. **5분 후 검증**: `bash scripts/verify_profile_push.sh <username> <path>` → exit 0 확인

## raw CDN 5분 캐시 함정 (반드시 결합)

푸시 직후 raw는 max-age=300 캐시 → SHA mismatch false negative.
sleep 5m 또는 쿼리스트링 `?bust=$(date +%s%N)` 강제 우회.

## anon IP GitHub API rate limit 함정

Vercel 공유 IP에서 anon curl 사용 시 60/h 초과 빈번.
→ 항상 `gh api` (OAuth 인증) 폴백. anon 403이면 graceful-degrade.