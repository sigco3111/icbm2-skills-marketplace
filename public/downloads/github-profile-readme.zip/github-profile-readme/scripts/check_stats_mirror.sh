#!/usr/bin/env bash
# check_stats_mirror.sh
# github-readme-stats.vercel.app 503 DEPLOYMENT_PAUSED 감지 + 미러 fallback 결정.
# Usage: bash check_stats_mirror.sh <username>
# Exit codes:
#   0 — vercel.app 정상 (또는 미러 정상, push 진행 가능)
#   1 — vercel.app 503 (DEPLOYMENT_PAUSED) + 미러도 불가
#   2 — vercel.app 503 + 미러 정상 (fallback URL 출력)
#   3 — anon IP rate limit (gh auth 필요)

set -u

USER="${1:-}"
if [[ -z "$USER" ]]; then
  echo "Usage: $0 <github-username>" >&2
  exit 1
fi

UA="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) hermes-verify"
URL_VERCEL="https://github-readme-stats.vercel.app/api?username=${USER}&show_icons=true&theme=tokyonight&hide_border=true&count_private=true"
URL_MIRROR="https://github-readme-stats-sigma-kohl.vercel.app/api?username=${USER}&show_icons=true&theme=tokyonight&hide_border=true&count_private=true"

check_status() {
  local url="$1"
  curl -sI -H "User-Agent: ${UA}" "$url" 2>&1 | head -1 | awk '{print $2}'
}

VERCEL_STATUS=$(check_status "$URL_VERCEL")

if [[ "$VERCEL_STATUS" == "200" ]]; then
  echo "✅ vercel.app 정상 (200 OK) — 현재 URL 유지"
  echo "URL: $URL_VERCEL"
  exit 0
fi

if [[ "$VERCEL_STATUS" != "503" ]]; then
  echo "⚠️  vercel.app 비정상 (HTTP $VERCEL_STATUS) — 함수정, 별도 조사 필요"
  exit 1
fi

# 503 — DEPLOYMENT_PAUSED
echo "❌ vercel.app 503 DEPLOYMENT_PAUSED 감지"
echo "=== 미러 확인 중 ==="
MIRROR_STATUS=$(check_status "$URL_MIRROR")

if [[ "$MIRROR_STATUS" == "200" ]]; then
  echo "✅ sigma-kohl 미러 200 OK — fallback 적용 권장"
  echo ""
  echo "교체 패턴:"
  echo "  sed -i '' 's|github-readme-stats.vercel.app|github-readme-stats-sigma-kohl.vercel.app|g' README.md"
  echo ""
  echo "또는 patch (함정 3: alt 명시 unique 매칭):"
  cat <<'PATCH_EOF'
  <img src="https://github-readme-stats-sigma-kohl.vercel.app/api?username=USERNAME&show_icons=true&theme=tokyonight&hide_border=true&count_private=true" height="165" alt="stats"/>
  <img src="https://github-readme-stats-sigma-kohl.vercel.app/api/top-langs/?username=USERNAME&layout=compact&theme=tokyonight&hide_border=true" height="165" alt="langs"/>
PATCH_EOF
  exit 2
else
  echo "❌ sigma-kohl 미저도 비정상 (HTTP $MIRROR_STATUS) — 24h 대기 후 재시도 권장"
  echo "또는 stats+langs 카드 주석 처리:"
  echo "  <!-- stats 카드 일시 비활성화 (DEPLOYMENT_PAUSED, 2026-07-07) -->"
  exit 1
fi