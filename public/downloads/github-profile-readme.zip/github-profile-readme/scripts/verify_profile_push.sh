#!/usr/bin/env bash
# verify_profile_push.sh
# Push 후 5-way 검증 (로컬 SHA, raw 캐시 우회, GitHub API, gh auth API, profile HTML).
# 함정 1(raw 5분 캐시) + 함정 4(sigma-kohl 카운트) + 함정 7(stats 미러) 자동화.
# Usage: bash verify_profile_push.sh <username> <local_readme_path> [<expected_minute_wait>]
# Exit codes: 0 — 통과, 1 — 검증 실패 (raw SHA mismatch), 2 — anon rate limit (gh 폴백)

set -u

USER="${1:-}"
LOCAL="${2:-}"
WAIT_MIN="${3:-5}"

if [[ -z "$USER" || -z "$LOCAL" ]]; then
  echo "Usage: $0 <github-username> <local_readme_path> [<expected_minute_wait>]" >&2
  exit 1
fi

if [[ ! -f "$LOCAL" ]]; then
  echo "❌ 로컬 파일 없음: $LOCAL" >&2
  exit 1
fi

UA="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) hermes-verify"

echo "=== 1. 푸시 후 ${WAIT_MIN}분 대기 (raw max-age=300) ==="
if [[ "$WAIT_MIN" != "0" ]]; then
  sleep "${WAIT_MIN}m"
fi

echo "=== 2. 로컬 SHA256 ==="
LOCAL_SHA=$(shasum -a 256 "$LOCAL" | awk '{print $1}')
echo "local: $LOCAL_SHA"

echo "=== 3. raw 캐시 우회 SHA256 ==="
RAW_BODY=$(curl -s -H "User-Agent: $UA" "https://raw.githubusercontent.com/${USER}/${USER}/main/README.md?nocache=$(date +%s%N)")
RAW_SHA=$(echo -n "$RAW_BODY" | shasum -a 256 | awk '{print $1}')
echo "raw:   $RAW_SHA"

if [[ "$LOCAL_SHA" != "$RAW_SHA" ]]; then
  echo "❌ raw SHA mismatch — raw CDN 캐시 아직 만료 안 됨. 추가 ${WAIT_MIN}분 대기 후 재시도."
  exit 1
fi

echo "=== 4. anon API SHA 시도 ==="
API_BODY=$(curl -s -H "User-Agent: $UA" "https://api.github.com/repos/${USER}/${USER}/contents/README.md")
if echo "$API_BODY" | grep -q "API rate limit exceeded"; then
  echo "⚠️  anon rate limit exceeded — gh auth 폴백"
  API_CONTENT=$(gh api "repos/${USER}/${USER}/contents/README.md" --jq '.content' | tr -d ' ' | base64 -d)
  API_SHA=$(echo -n "$API_CONTENT" | shasum -a 256 | awk '{print $1}')
  echo "api (gh): $API_SHA"
  if [[ "$LOCAL_SHA" != "$API_SHA" ]]; then
    echo "❌ gh auth API SHA mismatch"
    exit 1
  fi
  echo "✅ 3-way 일치 (gh auth API 폴백)"
else
  API_CONTENT=$(echo "$API_BODY" | python3 -c "import sys,json,base64; print(base64.b64decode(json.load(sys.stdin)['content']).decode())")
  API_SHA=$(echo -n "$API_CONTENT" | shasum -a 256 | awk '{print $1}')
  echo "api:   $API_SHA"
  if [[ "$LOCAL_SHA" != "$API_SHA" ]]; then
    echo "❌ anon API SHA mismatch"
    exit 1
  fi
  echo "✅ 3-way 일치"
fi

echo "=== 5. 변경 의도 (함정 4 + 7: 카운트 단위 검증) ==="
if echo "$RAW_BODY" | grep -q "sigma-kohl"; then
  SIGMA_CNT=$(echo "$RAW_BODY" | grep -c "sigma-kohl")
  echo "sigma-kohl 카운트: $SIGMA_CNT (기대: 2 = stats+langs)"
fi
VERCEL_CNT=$(echo "$RAW_BODY" | grep -c "github-readme-stats.vercel.app")
echo "vercel.app 잔존: $VERCEL_CNT (기대: 0)"
HEROKU_CNT=$(echo "$RAW_BODY" | grep -c "herokuapp.com")
echo "herokuapp streak 보존: $HEROKU_CNT (기대: 1)"

if [[ "$VERCEL_CNT" -ne 0 ]]; then
  echo "❌ vercel.app 잔존 — patch 실패 가능성"
  exit 1
fi
if [[ "$HEROKU_CNT" -lt 1 ]]; then
  echo "⚠️  streak 카드 사라짐 — 의도 보존 확인 필요"
fi

echo "=== 6. GitHub profile HTML 렌더 확인 ==="
HTML=$(curl -s -H "User-Agent: $UA" "https://github.com/${USER}")
if echo "$HTML" | grep -q "sigma-kohl"; then
  echo "✅ profile HTML에 sigma-kohl 카드 렌더됨"
else
  echo "⚠️  profile HTML에 sigma URL 미렌더 — raw 캐시와 별개로 profile 페이지 별도 캐시일 수 있음"
fi

echo "=== 7. .git fsck (해당 시) ==="
REPO_DIR=$(dirname "$LOCAL")
if [[ -d "$REPO_DIR/.git" ]]; then
  (cd "$REPO_DIR" && git fsck --no-progress 2>&1 | head -3)
  echo "fsck exit: $?"
fi

echo ""
echo "✅ 모든 검증 통과"