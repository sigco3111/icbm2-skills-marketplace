---
name: github-profile-readme
description: "GitHub 프로필 README ({username}/{username} special repo) 를 근사하게 꾸미는 클래스. GitHub Stats/Top Langs/Streak 카드 + shields.io 배지 + contribution snake 애니메이션 + N개 repo를 강점 카테고리로 묶는 다층 하이라이트. GitHub 프로필/README 다시 만들어줘/내 소개 페이지 같은 요청에 발동. python-oss-bootstrap이 단일 OSS 부트스트랩이라면 이 스킬은 프로필 페이지에서 본인의 다양한 작업을 보여주는 데 특화."
version: 1.0.0
author: HyeRin (MiniMax)
license: MIT
metadata:
  hermes:
    tags: [github, profile, readme, badges, shields, stats-cards]
    related_skills: [github-cli, python-oss-bootstrap, github-portfolio-planner]
---

# GitHub 프로필 README 꾸미기 — sigco3111 패턴

> 134개 repo 처럼 다수의 작업물을 가진 빌더가 자신의 GitHub 얼굴을 가장 근사하게
> 표현하는 패턴. python-oss-bootstrap과 github-portfolio-planner는 별도 도메인
> (단일 OSS / Next.js 포트폴리오 사이트) 이지만, 이 스킬은 `{user}/{user}` special
> repo 안의 README.md 만을 다룬다.

## 한 줄 정의

GitHub 프로필은 **첫인상이 곧 평판**. 다수 repo를 가진 빌더는 모든 repo를 나열하는
것보다 **4~6개 강점 카테고리** 로 묶어 보여줄 때 훨씬 강렬하다. 시각 자산
(banners, stats cards, snake, badges) 은 텍스트 대비 10배 빠르게 시선을 잡는다.

## 핵심 원칙 (sigco3111 스타일)

### 1. 카테고리 우선, repo 나열 X

❌ **나쁜 예**: 134개 repo를 bullet 134개로 나열
✅ **좋은 예**: 4~6개 카테고리로 묶고, 카테고리당 4~8개 repo만 하이라이트

자주 쓰는 카테고리 (134개 repo 환경에서 검증):

| # | 카테고리 | 포함 repo 예 |
|---|---|---|
| 1 | 🛠 CLI/OSS 도구 (시그니처 시리즈) | md-doctor, cron-doctor, hwp2md, opencode-harness-bridge |
| 2 | 🤖 AI 에이전트/오케스트레이션 | ai-gm 코어 + 4개 장르 플러그인 |
| 3 | 📊 데이터 시각화/대시보드 | knowledge-graph, ai-agent-radar, cable-globe |
| 4 | 🎮 시뮬레이션 게임 | 30+ 종을 경영/전략/캐주얼/시똤 4개 sub-category |
| 5 | 🌐 웹앱/유틸리티 | 블로그, Tistory 발행, 이미지 변환 |
| 6 | 📚 학습/노트 | LLM Wiki, dev-trend-oracle |

### 2. 시각 자산 3종 필수

| 자산 | 용도 | 사용 예 |
|---|---|---|
| **상단 배너** (shields.io) | 챌린지/외부 인증 어필 | "Apps in Toss — Granite Hackathon Participant" |
| **Stats 카드** (github-readme-stats) | 객관적 지표 | Stars, Top Langs, Streak (3장 나란히) |
| **Snake 애니메이션** (github-contribution-grid-snake) | 활동성 시각화 | GitHub Actions로 자동 생성 |

### 3. 테마 통일

- 다크 테마 일관성 (tokyonight / dracula / radical)
- 텍스트 색상은 명시 (white 안 됨, #C9D1D9 권장)
- shields.io `style=flat-square` 통일 (3D/pill 혼용 X)

### 4. 자기 검증 (Forbidden X)

| ❌ 금지 | 이유 |
|---|---|
| 모든 repo 나열 | 스크롤 지옥, 시선 분산 |
| 단순 "Hi, I'm X 👋" | 차별화 X |
| 흰 배경 + 검은 텍스트 | 시각 임팩트 0 |
| shields.io 배지 10개+ | 노이즈 |
| "Last updated: YYYY-MM-DD" | 직접 박으면 stale, 자동화 없으면 거짓말 |

## 작업 워크플로 (6단계)

### Step 0: 브레인스토밍 (필수)

사용자에게 결정 포인트 3~5개 제시 + 추천. 옵션 (A/B/C):

1. **분위기**: 미니멀 / 프로페셔널 / 창의적 / 게이머
2. **테마**: tokyonight (다크) / dracula / radical / default
3. **강조 카테고리 수**: 3 / 4 / 6
4. **시각 자산 강도**: 텍스트 위주 / 배너+stats / 풀 (snake+stats+banner)
5. **배지 강조**: 챌린지 / OSS 시리즈 / 외부 인증 / 통합

이 5개 결정 후 진행.

### Step 1: 현재 상태 점검

```bash
# 1. 현재 README 가져오기
gh api repos/{user}/{user}/contents/README.md \
  | python3 -c "import sys, json, base64; \
    d=json.load(sys.stdin); \
    print(base64.b64decode(d['content']).decode())"

# 2. repo 목록 + 메타 (강점 카테고리 선정용)
gh api user/repos --paginate -q \
  '.[] | "\(.stargazers_count)|\(.forks_count)|\(.name)|\(.description // "")"' \
  | awk -F'|' '{ if ($1 > 0 || $2 > 0) print $0 }' \
  | sort -t'|' -k1,1nr -k2,2nr | head -30

# 3. 최근 활동 repo (업데이트 빈도)
gh api user/repos --paginate -q \
  '.[] | select(.fork==false and .archived==false) | \
   "\(.updated_at)|\(.name)"' \
  | sort -t'|' -k1,1r | head -20
```

→ 강점 카테고리 4~6개 도출 + 각 카테고리별 4~8개 repo 선정

### Step 2: README 초안 작성

상단부터 7개 섹션 순서 (검증된 패턴):

```
1. 인사 + 한 줄 정의
2. 상단 배너 (챌린지/Tokscale 등 외부 인증)
3. 토큰 사용량 / 활동성 임베드
4. GitHub Stats 3종 (Stats/Langs/Streak)
5. 강점 카테고리 4~6개 (테이블 또는 카드 그리드)
6. Tech Stack (간단한 bullet)
7. Let's Connect (3개 정도)
8. Snake 애니메이션 (선택)
```

### Step 3: GitHub special repo ( {user}/{user} ) 작업

**함정**: 이 repo는 GitHub에서 자동 생성되며 평소 clone URL이 보이지 않음.
`gh repo create`로 새로 만들거나, 로컬에서 force push 필요.

**신규 생성 (처음 만들 때)**:

```bash
mkdir -p ~/workspace/{user} && cd ~/workspace/{user}
echo "# {user}" > README.md
gh repo create {user}/{user} --public \
  --description="{GitHub 한 줄 소개}" \
  --source=. --push
```

**이미 존재할 때 (이번 세션 케이스)**:

```bash
cd ~/workspace/{user}
# 로컬 git이 없을 수 있음 (special repo 특성)
git init -q
git remote add origin https://github.com/{user}/{user}.git
git fetch origin --quiet

# 충돌 시 — README.md만 force push
# 주의: 다른 파일이 origin에 있을 수 있으므로 --force는 README만
git checkout -B main
git add README.md
git commit -m "docs(profile): ..."
# 단순 push가 실패하면 (non-fast-forward)
git push -u origin main --force
```

**함정 (2026-06-19 검증)**:
- `git pull --rebase` 는 unrelated histories에서 conflict 발생 → `--abort` 후 `--force`
- `--allow-unrelated-histories` 사용 가능하나 force가 더 단순
- README 외 파일 (이미지 등) 도 같이 push할 땐 force 대신 `git pull --rebase=false` 검토

### Step 4: shields.io 배지 패턴

```markdown
<!-- 챌린지/외부 인증 (상단, for-the-badge + 로고) -->
[![Apps in Toss](https://img.shields.io/badge/Apps%20in%20Toss-Granite%20Hackathon%20Participant-3182F6?style=for-the-badge&logo=toss&logoColor=white)](url)
[![Tokscale](https://img.shields.io/badge/Tokscale-29.8B%20tokens%20%2F%20%24567-FF6B35?style=for-the-badge&logo=openai&logoColor=white)](url)

<!-- 기술/스펙 (중단, flat-square) -->
[![License](https://img.shields.io/badge/license-MIT-blue.svg?style=flat-square)](./LICENSE)
[![TypeScript](https://img.shields.io/badge/TypeScript-100%25-3178C6?style=flat-square&logo=typescript&logoColor=white)](url)
```

**배지 6종을 넘기지 말 것** — 그 이상은 노이즈.

### Step 5: Stats 카드 임베드

```markdown
<p align="left">
  <img src="https://github-readme-stats.vercel.app/api?username={user}&show_icons=true&theme=tokyonight&hide_border=true&count_private=true" height="165" alt="stats"/>
  <img src="https://github-readme-stats.vercel.app/api/top-langs/?username={user}&layout=compact&theme=tokyonight&hide_border=true" height="165" alt="langs"/>
  <img src="https://github-readme-streak-stats.herokuapp.com/?user={user}&theme=tokyonight&hide_border=true" height="165" alt="streak"/>
</p>
```

**3종 나란히**가 시각 임팩트 최고. 1~2종만 쓰면 약해 보임.

### Step 6: Snake 애니메이션 (선택)

GitHub Actions로 자동 생성. `github-contribution-grid-snake` 사용:

```yaml
# .github/workflows/snake.yml
name: Generate snake
on:
  schedule:
    - cron: "0 0 * * *"  # 매일 자정
  workflow_dispatch:
jobs:
  generate:
    runs-on: ubuntu-latest
    steps:
      - uses: Platane/snk@v3
        with:
          github_user_name: {user}
          outputs: |
            dist/github-contribution-grid-snake.svg
            dist/github-contribution-grid-snake-dark.svg
      - uses: actions/checkout@v4
      - uses: git-auto-commit-action@v5
        with:
          commit_message: "chore: regenerate snake"
          file_pattern: dist/*.svg
```

→ README에 임베드:

```markdown
<picture>
  <source media="(prefers-color-scheme: dark)" srcset="https://raw.githubusercontent.com/{user}/{user}/output/github-contribution-grid-snake-dark.svg" />
  <source media="(prefers-color-scheme: light)" srcset="https://raw.githubusercontent.com/{user}/{user}/output/github-contribution-grid-snake.svg" />
  <img alt="snake animation" src="https://raw.githubusercontent.com/{user}/{user}/output/github-contribution-grid-snake.svg" />
</picture>
```

## 🪤 함정 & 함정 회피

### "Last updated" 직접 표기

`Last updated: 2026-06-19` 같은 직접 표기는 **stale 위험** + 자동화 없으면 거짓말.
- 차라리 표기 안 함 (Tokscale SVG가 라이브 데이터라서 자연 갱신)
- 자동화 의도가 있으면 `last-commit` 액션으로 동적 삽입

### 흰 배경에 검은 텍스트

GitHub 다크 모드 사용자에게 거의 안 보임. **테마 통일 필수** (다크 권장).

### shields.io 배지 10개+

6종 이내 권장. 그 이상은 노이즈가 되어 시선 분산.

### 모든 repo 나열

134개 다 적으면 스크롤 지옥. 카테고리화 후 각 카테고리당 4~8개만.

### `git pull --rebase` 충돌 (special repo)

`{user}/{user}` repo에서 rebase는 unrelated histories 충돌 빈번.
**`--force` push가 가장 단순**. 단, 다른 파일이 origin에 있을 수 있으니 사전 확인.

### 카탈로그: 카테고리는 진짜 강점 repo만

`stargazers_count > 0` OR `forks_count > 1` 인 repo 위주로 카테고리화.
fork-only repo, 빈 repo는 제외.

## 검증 체크리스트

푸시 후:

- [ ] GitHub 프로필 페이지 열어서 즉시 렌더 확인
- [ ] Stats 카드 3종 모두 정상 로드 (cached 이미지 깨짐 없는지)
- [ ] shields.io 배지 6종 이내
- [ ] 카테고리 4~6개, 각 카테고리 4~8개 repo
- [ ] Snake 애니메이션 (선택) 워크플로 1회 트리거 확인
- [ ] 모바일 폭에서 레이아웃 깨짐 없는지 (테이블 → 카드)

## 보조 파일

- `references/category-templates.md` — 6개 카테고리별 repo 목록 템플릿
- `references/shields-badge-patterns.md` — 챌린지/OSS/스펙 배지 패턴 카탈로그
- `templates/profile-readme-template.md` — sigco3111 검증 프로필 README 골격 (복사-수정용)