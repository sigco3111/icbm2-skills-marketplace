---
name: github-profile-readme
description: "GitHub 프로필 README ({username}/{username} special repo) 를 근사하게 꾸미는 클래스. GitHub Stats/Top Langs/Streak 카드 + shields.io 배지 + contribution snake 애니메이션 + N개 repo를 강점 카테고리로 묶는 다층 하이라이트. GitHub 프로필/README 다시 만들어줘/내 소개 페이지 같은 요청에 발동. python-oss-bootstrap이 단일 OSS 부트스트랩이라면 이 스킬은 프로필 페이지에서 본인의 다양한 작업을 보여주는 데 특화. vercel.app 503 DEPLOYMENT_PAUSED / stats 카드 깨짐 / 미러 fallback 워크플로도 여기서 처리."
version: 1.4.0
author: HyeRin (MiniMax)
license: MIT
metadata:
  hermes:
    tags: [github, profile, readme, badges, shields, stats-cards]
    related_skills: [github-cli, python-oss-bootstrap, github-portfolio-planner]
---

# GitHub 프로필 README 꾸미기 — sigco3111 패턴

> 134개 repo 처럼 다수의 작업물을 가진 빌더가 자신의 GitHub 얼굴을 가장 근사하게
> 표현하는 패턴. python-oss-bootstrap과 github-portfolio-planner는 별도 도메인
> (단일 OSS / Next.js 포트폴리오 사이트) 이지만, 이 스킬은 `{user}/{user}` special
> repo 안의 README.md 만을 다룬다.

## 한 줄 정의

GitHub 프로필은 **첫인상이 곧 평판**. 다수 repo를 가진 빌더는 모든 repo를 나열하는
것보다 **4~6개 강점 카테고리** 로 묶어 보여줄 때 훨씬 강렬하다. 시각 자산
(banners, stats cards, snake, badges) 은 텍스트 대비 10배 빠르게 시선을 잡는다.

## 핵심 원칙 (sigco3111 스타일)

### 1. 카테고리 우선, repo 나열 X

❌ **나쁜 예**: 134개 repo를 bullet 134개로 나열
✅ **좋은 예**: 4~6개 카테고리로 묶고, 카테고리당 4~8개 repo만 하이라이트

자주 쓰는 카테고리 (134개 repo 환경에서 검증):

| # | 카테고리 | 포함 repo 예 |
|---|---|---|
| 1 | 🛠 CLI/OSS 도구 (시그니처 시리즈) | md-doctor, cron-doctor, hwp2md, opencode-harness-bridge |
| 2 | 🤖 AI 에이전트/오케스트레이션 | ai-gm 코어 + 4개 장르 플러그인 |
| 3 | 📊 데이터 시각화/대시보드 | knowledge-graph, ai-agent-radar, cable-globe |
| 4 | 🎮 시뮬레이션 게임 | 30+ 종을 경영/전략/캐주얼/시똤 4개 sub-category |
| 5 | 🌐 웹앱/유틸리티 | 블로그, Tistory 발행, 이미지 변환 |
| 6 | 📚 학습/노트 | LLM Wiki, dev-trend-oracle |

### 2. 시각 자산 3종 필수

| 자산 | 용도 | 사용 예 |
|---|---|---|
| **상단 배너** (shields.io) | 챌린지/외부 인증 어필 | "Apps in Toss — Granite Hackathon Participant" |
| **Stats 카드** (github-readme-stats) | 객관적 지표 | Stars, Top Langs, Streak (3장 나란히) |
| **Snake 애니메이션** (github-contribution-grid-snake) | 활동성 시각화 | GitHub Actions로 자동 생성 |

### 3. 테마 통일

- 다크 테마 일관성 (tokyonight / dracula / radical)
- 텍스트 색상은 명시 (white 안 됨, #C9D1D9 권장)
- shields.io `style=flat-square` 통일 (3D/pill 혼용 X)

### 4. 자기 검증 (Forbidden X)

| ❌ 금지 | 이유 |
|---|---|
| 모든 repo 나열 | 스크롤 지옥, 시선 분산 |
| 단순 "Hi, I'm X 👋" | 차별화 X |
| 흰 배경 + 검은 텍스트 | 시각 임팩트 0 |
| shields.io 배지 10개+ | 노이즈 |
| "Last updated: YYYY-MM-DD" | 직접 박으면 stale, 자동화 없으면 거짓말 |

## ⚽🃏 듀얼 카드 임베드 패턴 (NEW, 2026-07-13)

사용자가 "GitFut 카드", "FIFA 카드", "듀얼 카드", "GitHub 카드 임베드" 등을 요청하거나 기존 단일 임베드를 듀얼로 확장하고 싶을 때 사용.

### 검증된 듀얼 카드 템플릿 (sigco3111 2026-07-13)

```markdown
## ⚽🃏 GitFut Card · {N일 N개 클라이언트} 듀얼 스카우트 리포트

<p align="center">
  <a href="https://gitfut.com/{user}">
    <img src="https://gitfut.com/{user}.png?country={ISO2}" width="280" alt="{user}'s GitFut card — PAC/SHO/PAS/DRI/DEF/PHY"/>
  </a>
  &nbsp;&nbsp;&nbsp;&nbsp;
  <a href="https://tokscale.ai/u/{user}">
    <img src="https://tokscale.ai/api/embed/{user}/svg?template=graph&tokens=compact&cost=compact" width="360" alt="Tokscale token usage — {N}B tokens / ${N}"/>
  </a>
</p>

<p align="center">
  <sub>
    ⚽ <a href="https://gitfut.com/{user}"><b>GitFut</b></a> — FIFA-style player card scored live from commits, stars & PRs
    &nbsp;·&nbsp;
    📊 <a href="https://tokscale.ai/u/{user}"><b>Tokscale</b></a> — "The Kardashev Scale for AI Devs"
    &nbsp;·&nbsp;
    🤖 {client1} · {client2} · {client3} · {client4} · {client5} 통합
  </sub>
</p>
```

### 핵심 디자인 결정
- 한 줄 좌우 (`&nbsp;&nbsp;&nbsp;&nbsp;` 구분자)로 데스크탑 폭에서 자연스러운 듀얼 배치
- 카드는 280/360 width — 모바일에서 자동 wrap
- `<sub>` 한 줄에 출처 3개 압축 attribution (사용자 "짧게" 선호 패턴 일치)
- KR 국가 코드 쿼리스트링 (`?country=KR`) — 한국 사용자일 때 시각적 임팩트

### 푸시 전 가용성 검증 (필수)
```bash
# 1. GitFut 카드 200 OK
curl -sI "https://gitfut.com/<user>.png" | head -1
# HTTP/2 200, content-type: image/png, cache-control: public, max-age=3600
# x-matched-path: /api/card-image/[username]

# 2. Tokscale SVG 200 OK
curl -sI "https://tokscale.ai/api/embed/<user>/svg?template=graph" | head -1
# HTTP/2 200, content-type: image/svg+xml; charset=utf-8, max-age=0 (라이브)
```

→ 두 URL 모두 200 OK 확인 후 푸시. 서비스 죽으면 이미지가 깨진 박스로 렌더됨.

### 카드 임베드 옵션 비교

| 옵션 | 위치 | 적합한 상황 |
|---|---|---|
| **A. 단독** | "## 🏆 토큰 사용량" 섹션 | 1개 임베드만 쓸 때 |
| **B. 듀얼 카드** ★ | 좌 GitFut + 우 Tokscale | 2개 시그널을 시각적으로 묶고 싶을 때 (sigco3111 채택) |
| **C. 3-카드 그리드** | 좌 GitFut + 중단 Tokscale + 우 github-readme-stats | 활동성/지표/게임성 모두 (모바일 wrap 필수) |
| **D. 텍스트 + 1개 임베드** | "{N일 5개 클라이언트 · {M}개 모델" 헤딩 + 1개 그래프 | 미니멀, 모바일 우선 |

### 제공 카드 서비스 카탈로그 (2026-07-13 검증)

| 서비스 | 응답 | 캐시 | URL 패턴 | 비고 |
|---|---|---|---|---|
| **GitFut** | 200 OK | 3600s | `https://gitfut.com/<user>.png?country=<ISO2>` | FIFA 스타일, KR/JP/US 등 쿼리로 국기 |
| **Tokscale** | 200 OK | 0s | `https://tokscale.ai/api/embed/<user>/svg?template=<tpl>` | SVG 라이브 토큰 통계 |
| github-readme-stats | 503 위험 | — | `https://github-readme-stats-*.vercel.app/api?username=<user>` | 함정 10 — sigma-kohl 미러 |

### GitFut 카드 등급 색상 (디자인 참고용)
Bronze `#CD7F32`, Silver `#AAB2BD`, Gold `#E6B422`, In-Form `#E03E52`, TOTY `#3B7AFF`, Icon `#F3D688`. 둘 다 라이브 데이터 + 시각 카드라 **stale 위험 0**.

### 듀얼 카드 "제거" 요청 시 워크플로우 (NEW, 2026-07-24 sigco3111)

사용자가 "듀얼 카드를 제거하자"고 하면 단순 patch로 끝나지 않음. **듀얼 카드가 흡수한 stats 카드의 귀착**을 먼저 결정해야 함. af0214d 커밋에서 듀얼 카드로 단순화하면서 GitHub Stats 3종이 듀얼 카드 안으로 흡수된 상태에서는, 그대로 듀얼 카드만 제거하면 **README에서 stats 카드가 통째로 사라지는 함정**이 있음.

**3-step 사전 진단 (patch 0회 + clarify 1회로 끝내기)**:
1. `git log`로 듀얼 카드가 stats를 흡수한 시점 식별
   ```bash
   git log --oneline --all | head -10
   # "fix: 듀얼 카드를 GitFut + streak으로 단순화" 같은 커밋 찾기
   git show <직전_정상_커밋>:README.md | grep -n "github-readme-stats"
   ```
2. 현재 README에서 stats URL 흔적 검색
   ```bash
   grep -c "github-readme-stats" README.md  # 0건이면 듀얼 카드가 흡수한 상태
   grep -c "herokuapp" README.md             # streak 카드 흔적
   ```
3. **3-옵션 결정 매트릭스로 사용자 확인** (clarify 도구 사용):
   - **A. 듀얼 카드만 제거** — stats 3종이 별도 섹션으로 있던 시절이 아니라면 stats 통째 소실 위험 → 비권장
   - **B. 듀얼 카드 제거 + `## 📊 GitHub Stats` 섹션으로 stats/langs/streak 3종 복원** ★ (sigco3111 2026-07-24 채택) — ac9c9a1 커밋 패턴
   - **C. 듀얼 카드 제거 + stats 3종도 제거** (의도적 미니멀화)

**2-step patch 패턴 (B안, 안전판)**:
- 1단계: 듀얼 카드를 다시 원복 (rollback 안전판) → 2단계: 듀얼 카드를 Stats 3종으로 교체
- 1단계만 거치고 명확화할 수도 있고 (사용자 결정 후 2단계 진행), 1+2 한 번에 진행할 수도 있음

**교훈 (2026-07-24 sigco3111 OOB 정정)**: 사용자 본문에 "제거" 표현만 있고 stats 카드 처리에 대한 단서가 없으면, **0 patch + clarify 1회**가 정답. 추정으로 진행했다가 사용자 정정 → rollback 1회 + 2 patch = **총 4 patch 낭비**. 이 워크플로우가 정착되면 같은 실수 재발 방지.

**상세 케이스 스터디**: [`references/dual-card-removal-2026-07-24.md`](references/dual-card-removal-2026-07-24.md) — 4 patch 흐름 시간순, SHA 검증 코드, 최종 결과 비교표.

---

## ⭐ README 8개 섹션 순서 + Step 2

```
1. 인사 + 한 줄 정의
2. 상단 배너 (챌린지/Tokscale 등 외부 인증)
3. 토큰 사용량 / 활동성 임베드 (or 듀얼 카드)
4. 🌐 Featured Project (선택 — 시그니처 단일 프로젝트 카드, **2026-07-09 sigco3111**)
5. GitHub Stats 3종 (Stats/Langs/Streak)
6. 강점 카테고리 4~6개 (테이블 또는 카드 그리드)
7. Tech Stack (간단한 bullet)
8. Let's Connect (3개 정도)
9. Snake 애니메이션 (선택)
```

### Step 0: 브레인스토밍 (필수)

사용자에게 결정 포인트 3~5개 제시 + 추천. 옵션 (A/B/C):

1. **분위기**: 미니멀 / 프로페셔널 / 창의적 / 게이머
2. **테마**: tokyonight (다크) / dracula / radical / default
3. **강조 카테고리 수**: 3 / 4 / 6
4. **시각 자산 강도**: 텍스트 위주 / 배너+stats / 풀 (snake+stats+banner)
5. **배지 강조**: 챌린지 / OSS 시리즈 / 외부 인증 / 통합
6. **Featured Project 섹션 추가 여부 (NEW, 2026-07-09)**: 카테고리에 안 잡히는 시그니처 단일 프로젝트가 있을 때 (예: 134개 repo 중 MIT fork한 인터랙티브 시각화) — 별도 섹션으로 노출할지, Let's Connect 한 줄로만 처리할지. **추천: 별도 섹션** (시각 임팩트 + attribution 자연스러움 + 향후 확장성 ↑)

이 5~6개 결정 후 진행.

### Step 1: 현재 상태 점검

```bash
# 1. 현재 README 가져오기
gh api repos/{user}/{user}/contents/README.md \
  | python3 -c "import sys, json, base64; \
    d=json.load(sys.stdin); \
    print(base64.b64decode(d['content']).decode())"

# 2. repo 목록 + 메타 (강점 카테고리 선정용)
gh api user/repos --paginate -q \
  '.[] | "\(.stargazers_count)|\(.forks_count)|\(.name)|\(.description // "")"' \
  | awk -F'|' '{ if ($1 > 0 || $2 > 0) print $0 }' \
  | sort -t'|' -k1,1nr -k2,2nr | head -30

# 3. 최근 활동 repo (업데이트 빈도)
gh api user/repos --paginate -q \
  '.[] | select(.fork==false and .archived==false) | \
   "\(.updated_at)|\(.name)"' \
  | sort -t'|' -k1,1r | head -20
```

→ 강점 카테고리 4~6개 도출 + 각 카테고리별 4~8개 repo 선정

**Step 1-추가: Patch 전 unique match 사전 검증 (NEW, 2026-07-09)**
README는 **반복되는 패턴** (뱃지 표 행, 같은 카테고리 헤더)이 많아서 patch 매칭 위치가 잘못 잡힐 위험 ↑. patch 호출 직전에 **anchor 헤더의 고유성**을 grep으로 확인:

```bash
# patch로 삽입/교체할 anchor 헤더가 README에 정확히 몇 번 등장하는지 확인
curl -s "https://raw.githubusercontent.com/{user}/{user}/main/README.md" \
  | grep -c "## 🧰 Tech Stack"   # 결과: 1 이어야 안전

# 여러 섹션 헤더 동시 확인 (모든 ## 헤더 한 번에)
curl -s "https://raw.githubusercontent.com/{user}/{user}/main/README.md" \
  | grep -n "^## "
```

`count == 1` 이 아니면 patch가 의도와 다른 위치에 적용됨. **반드시 1이어야 진행**. 2+면 anchor 패턴을 더 길게 (직전/직후 3~5줄) 만들어 unique하게 만들 것 (함정 3 참조).

### Step 2: README 초안 작성

상단부터 8개 섹션 순서 (검증된 패턴, NEW 2026-07-09):

```
1. 인사 + 한 줄 정의
2. 상단 배너 (챌린지/Tokscale 등 외부 인증)
3. 토큰 사용량 / 활동성 임베드
4. 🌐 Featured Project (선택 — 시그니처 단일 프로젝트 카드, **2026-07-09 sigco3111**)
5. GitHub Stats 3종 (Stats/Langs/Streak)
6. 강점 카테고리 4~6개 (테이블 또는 카드 그리드)
7. Tech Stack (간단한 bullet)
8. Let's Connect (3개 정도)
9. Snake 애니메이션 (선택)
```

**Featured Project 위치 결정 (2026-07-09 sigco3111 검증, 함정 9)**:
- **사용자 본문 의도**: "토큰 사용량과 GitHub Stats 중간" → **배치 A: Tokscale(L16) ↔ Stats(L25) 사이**
- 처음 plan을 "Stats ↔ Tech 사이"로 잘못 적어서 1회 재수정 발생
- **교훈**: plan 단계에서 "중간" 표현이 모호하면 L번호까지 명시하고 사용자에게 확인

**Featured Project 섹션 템플릿 (v2, 2026-07-09 검증)** — 카테고리에 안 잡히는 시그니처 단일 프로젝트용. 단순 카드 + 짧은 attribution. v1(HTML 테이블)은 GitHub Profile README에서 렌더 안 되므로 비권장 (함정 7).

```markdown
## 🌐 Featured Project

### 🏙️ {프로젝트명} — {한 줄 한국어 디스크립션}

**{핵심 기술 1줄 설명}** — {차별점 + 임팩트 한 줄}

🌐 [**{사용자 도메인}/{repo-name}**](https://{user}.github.io/{repo}/) · 📦 [GitHub repo](https://github.com/{user}/{repo}) · 🚕 {핵심 기능} · 🎨 {톤} · 🛠 {tech1} · {tech2} · {tech3}

<sub>🎨 원작자 [@{원작자_핸들}](https://github.com/{원작자_핸들}) · {LICENSE} fork</sub>
```

**위치 결정 가이드 (L번호 명시 필수, 함정 9)**:
- **L번호 표기** — README의 실제 헤더 L번호를 plan에 명시 (예: "L16 Tokscale ↔ L25 Stats 사이")
- 후보 비교표 (사용자 승인 전):

| 옵션 | 위치 | L번호 (현 README 기준) |
|---|---|---|
| A (★ 사용자 의도) | 토큰 사용량 ↔ GitHub Stats 사이 | L23~L25 |
| B (현재 plan) | GitHub Stats ↔ Tech Stack 사이 | L33~L35 |
| C (minimal) | Let's Connect 한 줄 | L48 |

- **위치는 사용자 본문 의도 vs plan이 일치하는지 명시적으로 확인** 후 진행

**Attribution 짧게 패턴 (2026-07-09 사용자 선호)**:
- ✅ 짧게: `<sub>🎨 원작자 [@{핸들}]({URL}) · {LICENSE} fork</sub>`
- ❌ 길게: 님의 감사 + 변경 내용 + 설계 덕분 등 (사용자 "더 짧게" 피드백)

**Attribution 의무 (MIT/BSD/Apache 등 permissive 라이선스)**:
- 원작자 **GitHub 핸들 + repo 링크** 둘 다 명시 (GitHub 표준 표기)
- 라이선스 이름 명시 (예: "MIT")
- 변경 내용 1줄 명시 (예: "한국어 디스크립션 + sigco3111 데이터로 재구성")
- `<sub>` 톤으로 작게 — 시선 잡지 않게, 감사 표시는 분명히

### Step 3: GitHub special repo ( {user}/{user} ) 작업

**함정**: 이 repo는 GitHub에서 자동 생성되며 평소 clone URL이 보이지 않음.
`gh repo create`로 새로 만들거나, 로컬에서 force push 필요.

**신규 생성 (처음 만들 때)**:

```bash
mkdir -p ~/workspace/{user} && cd ~/workspace/{user}
echo "# {user}" > README.md
gh repo create {user}/{user} --public \
  --description="{GitHub 한 줄 소개}" \
  --source=. --push
```

**이미 존재할 때 (이번 세션 케이스)**:

```bash
cd ~/workspace/{user}
# 로컬 git이 없을 수 있음 (special repo 특성)
git init -q
git remote add origin https://github.com/{user}/{user}.git
git fetch origin --quiet

# 충돌 시 — README.md만 force push
# 주의: 다른 파일이 origin에 있을 수 있으므로 --force는 README만
git checkout -B main
git add README.md
git commit -m "docs(profile): ..."
# 단순 push가 실패하면 (non-fast-forward)
git push -u origin main --force
```

**함정 (2026-06-19 검증)**:
- `git pull --rebase` 는 unrelated histories에서 conflict 발생 → `--abort` 후 `--force`
- `--allow-unrelated-histories` 사용 가능하나 force가 더 단순
- README 외 파일 (이미지 등) 도 같이 push할 땐 force 대신 `git pull --rebase=false` 검토

### Step 4: shields.io 배지 패턴

```markdown
<!-- 챌린지/외부 인증 (상단, for-the-badge + 로고) -->
[![Apps in Toss](https://img.shields.io/badge/Apps%20in%20Toss-Granite%20Hackathon%20Participant-3182F6?style=for-the-badge&logo=toss&logoColor=white)](url)
[![Tokscale](https://img.shields.io/badge/Tokscale-29.8B%20tokens%20%2F%20%24567-FF6B35?style=for-the-badge&logo=openai&logoColor=white)](url)

<!-- 기술/스펙 (중단, flat-square) -->
[![License](https://img.shields.io/badge/license-MIT-blue.svg?style=flat-square)](./LICENSE)
[![TypeScript](https://img.shields.io/badge/TypeScript-100%25-3178C6?style=flat-square&logo=typescript&logoColor=white)](url)
```

**배지 6종을 넘기지 말 것** — 그 이상은 노이즈.

### Step 5: Stats 카드 임베드

```markdown
<p align="left">
  <img src="https://github-readme-stats-sigma-kohl.vercel.app/api?username={user}&show_icons=true&theme=tokyonight&hide_border=true&count_private=false" height="165" alt="stats"/>
  <img src="https://github-readme-stats-sigma-kohl.vercel.app/api/top-langs/?username={user}&layout=compact&theme=tokyonight&hide_border=true&count_private=false" height="165" alt="langs"/>
  <img src="https://github-readme-streak-stats.herokuapp.com/?user={user}&theme=tokyonight&hide_border=true" height="165" alt="streak"/>
</p>
```

**3종 나란히**가 시각 임팩트 최고. 1~2종만 쓰면 약해 보임.

> **⚠️ `count_private=false` 필수 (NEW, 2026-07-14 sigco3111 사례)**: sigma-kohl 미러는 owner의 `PAT_1` GitHub 토큰을 환경변수로 등록해야 `count_private=true`가 작동합니다. owner가 미등록한 미러에서는 `"Maximum retries exceeded — PAT_1"` 빨간 에러 박스로 렌더됩니다. **`count_private=false` 사용 시 PAT 없이도 200 OK 정상 작동** (trade-off: private 커밋 카운트 빠짐, public 위주 README면 손해 0). 상세 사례: [`references/dual-card-count-private-pitfall-2026-07-14.md`](references/dual-card-count-private-pitfall-2026-07-14.md)

> **💡 "양쪽 정렬" 사용자 의도 (NEW, 2026-07-14)**: 듀얼 카드는 양쪽을 다른 `align`으로 정렬할 수 없습니다. 사용자가 "GitFut 좌 + Stats 우" 같은 의도를 표현할 때는 듀얼이 아니라 **단일 + 우측 분리** 패턴 (`<p align="center">` GitFut 단독 + `<p align="right">` Stats 묶음)을 사용하세요. 상세: 같은 references 파일.

### Step 6: Snake 애니메이션 (선택)

GitHub Actions로 자동 생성. `github-contribution-grid-snake` 사용:

```yaml
# .github/workflows/snake.yml
name: Generate snake
on:
  schedule:
    - cron: "0 0 * * *"  # 매일 자정
  workflow_dispatch:
jobs:
  generate:
    runs-on: ubuntu-latest
    steps:
      - uses: Platane/snk@v3
        with:
          github_user_name: {user}
          outputs: |
            dist/github-contribution-grid-snake.svg
            dist/github-contribution-grid-snake-dark.svg
      - uses: actions/checkout@v4
      - uses: git-auto-commit-action@v5
        with:
          commit_message: "chore: regenerate snake"
          file_pattern: dist/*.svg
```

→ README에 임베드:

```markdown
<picture>
  <source media="(prefers-color-scheme: dark)" srcset="https://raw.githubusercontent.com/{user}/{user}/output/github-contribution-grid-snake-dark.svg" />
  <source media="(prefers-color-scheme: light)" srcset="https://raw.githubusercontent.com/{user}/{user}/output/github-contribution-grid-snake.svg" />
  <img alt="snake animation" src="https://raw.githubusercontent.com/{user}/{user}/output/github-contribution-grid-snake.svg" />
</picture>
```

## 🪤 함정 & 함정 회피

### "Last updated" 직접 표기

`Last updated: 2026-06-19` 같은 직접 표기는 **stale 위험** + 자동화 없으면 거짓말.
- 차라리 표기 안 함 (Tokscale SVG가 라이브 데이터라서 자연 갱신)
- 자동화 의도가 있으면 `last-commit` 액션으로 동적 삽입

### 흰 배경에 검은 텍스트

GitHub 다크 모드 사용자에게 거의 안 보임. **테마 통일 필수** (다크 권장).

### shields.io 배지 10개+

6종 이내 권장. 그 이상은 노이즈가 되어 시선 분산.

### 모든 repo 나열

134개 다 적으면 스크롤 지옥. 카테고리화 후 각 카테고리당 4~8개만.

### `git pull --rebase` 충돌 (special repo)

`{user}/{user}` repo에서 rebase는 unrelated histories 충돌 빈번.
**`--force` push가 가장 단순**. 단, 다른 파일이 origin에 있을 수 있으니 사전 확인.

### 카탈로그: 카테고리는 진짜 강점 repo만

`stargazers_count > 0` OR `forks_count > 1` 인 repo 위주로 카테고리화.
fork-only repo, 빈 repo는 제외.

## 🪤 검증 & 푸시 시 흔한 함정 (2026-06-29 실전 검증)

Profile README는 푸시 후 검증을 어떻게 하느냐가 핵심. 다음 6개 함정이 실전에서 반복적으로 등장했음. **fresh verification evidence를 매 턴 요구하는 시스템 메시지와 함께 사용 시 특히 중요**.

### 함정 1: GitHub raw CDN 5분 캐시

푸시 직후 `https://raw.githubusercontent.com/{user}/{user}/main/README.md`는 **5분간 옛 버전 캐싱** (`cache-control: max-age=300`). SHA256 비교 시 false negative.

**3가지 우회 방법**:
```bash
# A. 쿼리스트링 nocache (가장 간단)
curl -s "https://raw.githubusercontent.com/{user}/{user}/main/README.md?nocache=$(date +%s)"

# B. Cache-Control 헤더 명시
curl -s -H "Cache-Control: no-cache" "https://raw.githubusercontent.com/..."

# C. GitHub contents API (캐시 영향 0, base64 응답, 정확)
curl -s -H "Accept: application/vnd.github+json" \
  "https://api.github.com/repos/{user}/{user}/contents/README.md" \
  | python3 -c "
import json, sys, base64
d = json.load(sys.stdin)
print(base64.b64decode(d['content']).decode('utf-8'))"
```

**함정 1-보강: anon IP rate limit (2026-07-07)**
방법 C에서 anon curl은 **IP당 60/h** rate limit. Vercel/공유 IP에서 0 한도 자주 발생 → `{"message":"API rate limit exceeded for 222.108.43.129..."}`. 이때는 `gh api` (OAuth 인증) 폴백:
```bash
# anon curl이 403이면 즉시 gh auth로 graceful-degrade
curl -s "https://api.github.com/repos/X/X/contents/README.md" | grep -q "rate limit" && \
  gh api repos/X/X/contents/README.md --jq '.content' | tr -d ' ' | base64 -d
```
3-way 검증 (로컬/raw/api) 중 anon API가 죽어도 raw + gh auth로 2-way 일치 검증 가능.

### 함정 2: shields.io User-Agent rate-limit (HTTP 403)

Python `urllib.request`는 기본 `User-Agent: Python-urllib/3.x`를 보냄. **shields.io가 이걸 rate-limit으로 403 거부**. `curl`은 정상 200.

```python
# 올바른 패턴 — User-Agent 명시
import urllib.request
req = urllib.request.Request(
    "https://img.shields.io/badge/...",
    headers={"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) hermes-verify"}
)
```

### 함정 3: patch 도구 old_string 모호성

`patch` 도구가 old/new 양쪽에 **동일한 줄이 여러 번 등장**하면, 가장 마지막 매칭 위치를 처리함. 의도와 다른 위치에서 처리될 수 있음.

**실전 사례 1 (sigco3111 프로필 What I Build 제거 시)**:
- old_string에 `\n| ![Tokscale]... | ![License]... |\n\n---\n\n## 🧰 Tech Stack` 가 들어있었고 new_string에 같은 줄 + `\n## 🧰 Tech Stack` 추가
- **결과**: 첫 번째 매칭 위치(What I Build 섹션 내 마지막 위치)에서만 적용 → 헤더(`## 🛠️ What I Build`)는 남고 그 아래 뱃지 표 한 줄만 제거됨

**실전 사례 2 (2026-06-29 What I Build + Snake 제거 시)**:
- 첫 번째 patch에서 old/new 양쪽 모두에 `| ![Tokscale]... | ![License]... |\n\n---\n\n` (뱃지 표 줄) 이 포함됨
- 첫 번째 patch는 What I Build 섹션 내의 표를 새 표 형식으로 교체하지만, **헤더(`## 🛠️ What I Build`)는 그대로 남음**
- 두 번째 patch에서 `## 🛠️ What I Build\n\n| ![Tokscale]...` 패턴만 매칭해서 헤더만 제거

**더 일반적인 함정**: README처럼 **반복되는 패턴** (뱃지 표 행, 같은 카테고리 헤더)이 있을 때 patch가 매칭 위치를 잘못 잡을 가능성 ↑.

**회피**:
- old_string을 **고유한 컨텍스트**로 좁힘 (예: 직전/직후 3~5줄 포함)
- 매칭 후 `grep`으로 잔존 확인
- 의심되면 `read_file`로 결과 직접 확인
- **신뢰 패턴**: patch 후 `git diff` 또는 `git show HEAD:README.md | grep -c <패턴>` 으로 의도된 라인 수 변화 확인

### 함정 4: 단어 기반 검증 — 의도된 보존까지 잡힘

검증 시 단순 단어 검색은 **다른 컨텍스트의 같은 단어**까지 false negative로 잡음.

**실전 사례 (2026-06-29 sigco3111 프로필)**:
- What I Build의 `### 4️⃣ 시뮬레이션 게임 — 30+ 종` 카테고리 헤더 제거 검증
- 단순 `"시뮬레이션 게임" not in readme` 검사 → FAIL
- **실제 원인**: line 3 헤더 설명에 `시뮬레이션 게임` 단어가 의도된 보존으로 들어있음 (`**AI 코딩 어시스턴트 자동화 · 데이터 시각화 · 시뮬레이션 게임 · 오픈소스 CLI**`)

**올바른 패턴**:
```python
# ❌ 단순 단어 검색 — 다른 컨텍스트 같은 단어까지 잡음
chk("'시뮬레이션 게임' 제거", "시뮬레이션 게임" not in readme)

# ✅ 컨텍스트 단위 (헤더 prefix + 전체 텍스트)
removed_categories = [
    "### 1️⃣ CLI / OSS 도구",
    "### 2️⃣ AI 에이전트 / 오케스트레이션",
    "### 3️⃣ 데이터 시각화 · 인터랙티브 대시보드",
    "### 4️⃣ 시뮬레이션 게임",
]
for cat in removed_categories:
    chk(f"카테고리 헤더 '{cat}' 제거", cat not in readme)

# 의도된 보존은 별도 확인
chk("line 3 '4개 영역' 보존 (사용자 정체성)", "4개 영역을 가로지르는 빌더" in readme)
```

### 함정 5: GitHub Profile HTML의 작은따옴표 인코딩

GitHub Profile HTML은 일부 텍스트를 **그대로 렌더** (`Hi, I'm HJ`), 일부는 **HTML 엔티티로 변환** (`Let&#39;s Connect`). **둘 다 가능성 있음** → 검증 시 둘 다 허용.

```python
# ❌ HTML 엔티티만 검사 — 직접 렌더 시 false negative
chk("Profile에 'Hi, I&#39;m HJ'", "Hi, I&#39;m HJ" in html)

# ✅ 둘 다 허용 (직접 문자열 + HTML 엔티티 + U+2019)
chk("Profile에 'Hi, I'm HJ' (직접)", "Hi, I'm HJ" in html)
chk("Profile에 'Let’s Connect' (U+2019)", "Let’s Connect" in html)
chk("Profile에 'Let&#39;s Connect' (엔티티)", "Let&#39;s Connect" in html)
```

### 함정 6: 자동화 파이프라인 모니터링에 PushEvent 수 부적합

GitHub Events API의 PushEvent 수는 **자신의 푸시 + 과거 푸시까지 모두** 잡힘. 푸시 후 활동 모니터링의 1차 지표로는 부적합.

```python
# ❌ PushEvent 수 검사 — 자동화 파이프라인 유추용 (false negative 빈번)
push_events = [e for e in events if e["type"] == "PushEvent"]
chk("자동화 파이프라인 동작 없음", len(push_events) == 0)

# ✅ GitHub commit status API 사용 (푸시한 정확한 커밋의 배포 결과)
import urllib.request, json
with urllib.request.urlopen(
    f"https://api.github.com/repos/{owner}/{repo}/commits/{sha}/status", timeout=15
) as r:
    st = json.loads(r.read())
    chk("state = success", st.get("state") == "success")
    chk("Vercel context 존재",
        any("Vercel" in s.get("context","") for s in st.get("statuses", [])))
    chk("Vercel = Deployment has completed",
        any("Deployment has completed" in s.get("description","") for s in st.get("statuses", [])))
```

### 함정 7: Featured Project에 HTML `<table>` 사용 시 raw 노출 (NEW, 2026-07-09 실전)

GitHub Profile README는 **표준 GitHub Markdown만 지원** — HTML `<table>`, `<tr>`, `<td>`, `valign="top"`, `width="62%"` 같은 raw HTML이 **렌더 안 되고 텍스트로 노출됨**.

**증상 (2026-07-09 sigco3111 Featured Project 첫 시도)**:
```markdown
<!-- ❌ 작성한 코드 -->
<table>
  <tr>
    <td width="62%" valign="top">
### 🏙️ Repolis — 레포들의 도시
...
```

**렌더 결과 (스크린샷 확인됨)**:
```
🌐 sigco3111.github.io/Repolis · 📦 GitHub repo · ...

</td>
    <td width="38%" valign="top">
**🛠 Tech**  
`Three.js` · `WebGL` ...
```

→ `</td>`, `<td width="38%" valign="top">` 같은 태그가 텍스트 그대로 노출됨.

**원인**: GitHub Profile README는 GFM만 지원. HTML 테이블은 GitHub Issues/PR 코멘트, gist, repo README의 일부 컨텍스트에서만 작동. Profile README는 sandbox 처리.

**해결**:
- **단순 카드** (가장 안전) — `### 헤더` + 본문 + 링크 한 줄 + sub attribution. HTML 없음, 100% 호환
- **MD 표준 테이블** (OK) — `| col | col |` 형식은 GitHub이 자동 변환 (단, Featured Project 단일 카드에는 과한 구도)
- **HTML align="right" + img float** (X) — GitHub Markdown은 HTML `align` 속성 무시, float 안 됨

**검증 패턴**: Featured Project 카드 영역을 잘라서(`re.search(r"Featured Project.*?Stats", html, re.S)`) 그 안에서만 HTML 태그 검사.

### 함정 8: 검증 시 `<table>` false-positive (NEW, 2026-07-09 실전)

함정 7과 정반대 함정. Featured Project의 `<table>` 노출을 잡으려다 **Tech Stack의 정상 MD 테이블**이 만든 `<table>`, `<tr>`, `</td>`까지 false-positive로 잡힘.

**증상 (2026-07-09 검증 1차 시도)**:
```python
# ❌ Profile HTML 전체에서 <table> 검사
for needle in ["<table>", "<tr>", "</td>", "<td ", 'valign="top"', 'width="62%"']:
    found = needle in html
    print(f"  {'❌ 노출됨' if found else '✅ 없음'}: '{needle}'")
```

**출력 (혼란스러움)**:
```
❌ 노출됨: '<table>'      ← Tech Stack MD 테이블이 만든 것
❌ 노출됨: '<tr>'         ← Tech Stack MD 테이블이 만든 것
❌ 노출됨: '</td>'        ← Tech Stack MD 테이블이 만든 것
```

**원인**: GitHub이 표준 MD 테이블(`| col | col |`)을 렌더링할 때 자동으로 `<markdown-accessiblity-table><table>...<tr>...<td>...</td>...</tr>...</table></markdown-accessiblity-table>` HTML로 변환함. **이건 정상 동작**.

**올바른 패턴 — 검증 영역 한정**:
```python
# ✅ Featured Project 카드 영역만 추출해서 검사
import re
m = re.search(r"Featured Project.*?(?=GitHub Stats)", html, re.S)
if m:
    section = m.group(0)
    for needle in ["<table>", "<tr>", "</td>", "<td ", 'valign=', 'width=']:
        found = needle in section  # ← section 안에서만
        print(f"  {'❌ 발견' if found else '✅ 없음'}: '{needle}'")
```

→ Featured Project 카드 영역에는 0건, 나머지 정상 HTML은 무시.

**교훈**: Profile HTML 같은 거대한 페이지에서 변경 의도 영역을 검증할 땐 반드시 **정규식으로 섹션을 추출**해서 그 안에서만 검사. 페이지 전체 grep은 정상 렌더링까지 false-positive로 잡음.

### 함정 11: shields.io URL에 이모지 라벨 사용 시 ASCII 인코딩 실패 (NEW, 2026-07-09 sigco3111 E안)

shields.io label에 이모지(👀📦🎨 등)를 직접 넣으면 **Python `urllib`이 `'ascii' codec can't encode character '\U0001f440'`** 에러로 검증 단계에서 즉시 실패.

**원인**: shields.io는 label을 URL-safe하게 기대. 이모지는 ASCII 범위 밖.

**3가지 우회법 비교**:

| 방법 | 예시 | 단점 |
|---|---|---|
| 1. plain text (가장 안전) | `Live_Demo-...` | 이모지 임팩트 손실 |
| 2. URL 인코딩 (`%F0%9F%91%80`) | `Live_Demo_%F0%9F%91%80-...` | shields가 디코딩 안 함 → 깨진 라벨 |
| 3. HTML entity (`&#x1F440;`) | `Live_Demo_&#x1F440;-...` | 라벨에 entity 그대로 노출 |

**권장**: **plain text**. 시선 집중은 **이모지가 아니라 `style=for-the-badge` + 색상 매칭**으로 확보.

**2026-07-09 sigco3111 E안 사건**:
- 1차 시도: `https://img.shields.io/badge/👀_Live_Demo-...-2bb8a3` → Python urllib 즉시 실패
- 2차 수정: `Live_Demo` (plain) + `for-the-badge` + 배너 색상 매칭 (`#2bb8a3`, `#1d3b3f`) → 시각 임팩트 동일하면서 통과

**사전 검증 패턴 (push 전 가용성 확인)**:
```python
import urllib.request
UA = "Mozilla/5.0 hermes-verify"
def check(url, label):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            return r.status, len(r.read())
    except Exception as e:
        return -1, str(e)[:60]

# shields URL push 전에 미리 200 OK 확인
for url, label in [
    ("https://img.shields.io/badge/Live_Demo-X-2bb8a3?style=for-the-badge", "Live Demo plain"),
    ("https://img.shields.io/badge/Source-Y-1d3b3f?style=for-the-badge", "Source plain"),
]:
    status, info = check(url, label)
    print(f"  {'✅' if status == 200 else '❌'} {label}: {info}")
```

### Featured Project 카드 v1 → v3 진화 과정 (NEW, 2026-07-09 sigco3111)

이번 세션에서 실제로 거친 3단계 진화. **다음에 Featured Project 만들 때 v3부터 시작** (시간 절약):

| v | 구조 | 시점 | 문제/개선 |
|---|---|---|---|
| **v1** | 2-col HTML `<table>` + 메타 칸 + 긴 attribution | 1차 patch | 푸시 후 `</td>` `<td width="38%">` raw 노출 → **전면 재작성** |
| **v2** | 단순 markdown 카드 (헤더 + 본문 + 메타 한 줄 + 짧은 attribution) | 2차 patch | 렌더 OK, 보존 OK. 하지만 **위치가 Stats 아래로 잘못 배치** → 사용자 불만 |
| **v3** | v2 + **위치 재배치** (Tokscale ↔ Stats 사이) + **E안 시각 부각** (배너 SVG + 2개 CTA 배지 + 짧은 attribution) + **한글 헤더** | 3~5차 patch | 최종 통과 |

**교훈**:
- **HTML 테이블 시도 → 시간 낭비**. 바로 v2 (단순 markdown) 또는 v3 (시각 부각)부터 시작
- **위치는 plan 단계에 L번호 명시 + 사용자 cross-check**. "중간" 모호 표현 시 무조건 다이어그램
- **시각 부각은 옵션** — Featured Project 1개가 메인 신호일 때만 E안 (배너 + CTA). 일반 카테고리엔 불필요

**v3 최종 템플릿 (재사용 권장)**:
```markdown
## 🏙️ {프로젝트명} ({사용자_핸들})     ← 한글 헤더 (사용자 선호)

<p align="center">
  <a href="https://{user}.github.io/{repo}/">
    <img src="https://{user}.github.io/{repo}/assets/banner.svg"
         alt="{프로젝트 디스크립션}"
         width="720"/>
  </a>
</p>

<p align="center">
  <a href="https://{user}.github.io/{repo}/">
    <img src="https://img.shields.io/badge/Live_Demo-{user}.github.io%2F{repo}-{primary_color}?style=for-the-badge&logo=github-pages&logoColor=white" alt="Live Demo"/>
  </a>
  <a href="https://github.com/{user}/{repo}">
    <img src="https://img.shields.io/badge/Source-Repository-{secondary_color}?style=for-the-badge&logo=github&logoColor=white" alt="Source"/>
  </a>
</p>

<p align="center">
  <sub>🎨 원작자 [@{원작자_핸들}](https://github.com/{원작자_핸들}) · {LICENSE} fork · {tech1} · {tech2}</sub>
</p>
```

**색상 매칭 패턴** — 배너 SVG에서 추출한 청록/딥블루를 shields에 매칭하면 시각적 연결 형성:
- 배너 primary 색상 (예: `#2bb8a3`) → Live Demo 배지
- 배너 타이틀 색상 (예: `#1d3b3f`) → Source 배지

### 사용자 선호 — attribution 짧게 (명시, 2026-07-09)

Featured Project의 `<sub>` attribution 톤은 **짧게** 선호. 사용자가 v2 → v3 과정에서 명시적으로 "더 짧게" 지시함.

**✅ 짧은 패턴 (권장)**:
```markdown
<sub>🎨 원작자 [@hyeonsangjeon](https://github.com/hyeonsangjeon) · MIT fork</sub>
```

**❌ 긴 패턴 (비권장)**:
```markdown
<sub>🎨 원작자 [**@hyeonsangjeon**](https://github.com/hyeonsangjeon) 님의 [Repolis](https://github.com/hyeonsangjeon/Repolis) (14⭐, MIT) 를 fork하여 한국어 디스크립션 + sigco3111 데이터로 재구성했습니다. 컨셉과 엔진은 원작의 훌륭한 설계 덕분입니다.</sub>
```

**포함 필수 요소**: 원작자 핸들 링크 + 라이선스명. (변경 내용은 옵션, 너무 길면 빼도 OK)

### 사용자 선호 — 섹션 헤더 한글화 (명시, 2026-07-09)

사용자가 명시적으로 "섹션 제목만 한국어로 변경" 요청. 영문 헤더(`Featured Project`)보다 한글 헤더(`레포들의 도시 (sigco3111)`) 선호. **다음에 Featured Project 만들 때 처음부터 한글 헤더**.

**패턴**: `## 🏙️ {한국어_프로젝트_별명} ({사용자_핸들})` — 이모지 + 한글 + 본인 핸들로 시그니처 강조.

### 함정 9: 사용자 의도 위치 해석 실수 — plan 단계 위치 결정은 사용자 확인 필수 (NEW, 2026-07-09)

**증상 (2026-07-09 sigco3111)**:
- 사용자 요청: "토큰 사용량과 GitHub Stats 중간에 위치" (희정님이 본문에서 말한 의도)
- agent plan: "Stats ↔ Tech Stack 사이" (Stats 아래로 잘못 명시)
- 사용자 승인: A안 (plan대로) — 푸시 후 스크린샷 보고 "Stats 아래로 나옴" 불만

**원인**: 사용자 본문 의도 + plan 텍스트가 어긋났는데 agent가 plan을 명시하지 않고 진행.

**해결 패턴 — plan 단계 위치 결정 5가지 검증**:
1. 사용자 본문에서 "X와 Y 중간" 표현이 있으면 정확히 어떤 헤더 사이인지 식별
2. plan 텍스트에 **L번호 + 헤더** 둘 다 명시 (예: "L25 Stats ↔ L35 Tech 사이" 또는 "L16 Tokscale ↔ L25 Stats 사이")
3. plan 표에 `배치 옵션 A/B/C` 형태로 위치 후보 + 추천 나열
4. **위치는 approve 전에 사용자에게 "L번호"까지 확인** (특히 "중간" 모호 표현 시)
5. 잘못된 위치로 푸시 후 재수정 → 사용자가 한 번 더 작업 필요 → 비효율

**체크리스트 — plan 명세 시 위치 표기**:
```markdown
## 📍 위치 후보 (희정님이 본문에서 "Tokscale ↔ Stats 중간" 의도)

| 옵션 | 위치 | L번호 (현 README 기준) |
|---|---|---|
| A | 토큰 사용량 ↔ GitHub Stats 사이 (★ 추천, 사용자 의도) | L23~L25 |
| B | GitHub Stats ↔ Tech Stack 사이 (현재 plan) | L33~L35 |
| C | Let's Connect 한 줄로 추가 | L48 |
```

### 사용자 선호 — attribution 짧게 (NEW, 2026-07-09)

Featured Project의 `<sub>` attribution 톤은 **짧게** 선호. 길고 정중한 감사 문구보다 한 줄 압축이 자연스러움.

**✅ 짧은 패턴 (권장)**:
```markdown
<sub>🎨 원작자 [@hyeonsangjeon](https://github.com/hyeonsangjeon) · MIT fork</sub>
```

**❌ 긴 패턴 (비권장)**:
```markdown
<sub>🎨 원작자 [**@hyeonsangjeon**](https://github.com/hyeonsangjeon) 님의 [Repolis](https://github.com/hyeonsangjeon/Repolis) (14⭐, MIT) 를 fork하여 한국어 디스크립션 + sigco3111 데이터로 재구성했습니다. 컨셉과 엔진은 원작의 훌륭한 설계 덕분입니다.</sub>
```

**포함 필수 요소**: 원작자 핸들 링크 + 라이선스명. (변경 내용은 옵션, 너무 길면 빼도 OK)

### 함정 10: github-readme-stats.vercel.app DEPLOYMENT_PAUSED (2026-07-07 실전)

`https://github-readme-stats.vercel.app`은 anuraghazra의 공식 인스턴스지만 **Vercel이 503 `DEPLOYMENT_PAUSED`로 일시 정지**되는 사건이 발생함. 2026-07-07 sigco3111 프로필에서 stats + langs 카드 2개가 "Error Fetching Resource"로 깨짐. streak 카드(herokuapp.com)는 영향 없음.

**증상**:
```bash
$ curl -sI "https://github-readme-stats.vercel.app/api?username=X&show_icons=true&theme=tokyonight"
HTTP/2 503
x-vercel-error: DEPLOYMENT_PAUSED
content-length: 99

# 응답 본문
The deployment is currently unavailable
DEPLOYMENT_PAUSED
```

**3가지 해결책 (우선순위순)**:

| # | 방법 | 단점 |
|---|---|---|
| 1 | **sigma-kohl 미러로 URL 교체** | 공식 인스턴스 아님 (커뮤니티 호스팅) |
| 2 | stats + langs 카드 주석 처리 / 제거 | 프로필 시각 임팩트 ↓ |
| 3 | 24h 대기 후 원복 시도 | Vercel이 다시 안 살릴 수도 |

**방법 1 (추천) — sigma-kohl 미러**:
```markdown
<!-- ❌ 기존 (DEPLOYMENT_PAUSED 위험) -->
<img src="https://github-readme-stats.vercel.app/api?username=X&show_icons=true&theme=tokyonight&hide_border=true&count_private=true" />

<!-- ✅ 교체 (sigma-kohl 미러, 200 OK 검증 완료) -->
<img src="https://github-readme-stats-sigma-kohl.vercel.app/api?username=X&show_icons=true&theme=tokyonight&hide_border=true&count_private=true" />
```

**미러 URL 카탈로그 (2026-07-07 검증)**:

| 미러 | stats | top-langs | 비고 |
|---|---|---|---|
| `github-readme-stats-sigma-kohl.vercel.app` | 200 ✓ | 200 ✓ | **권장**, 쿼리 파라미터 그대로 호환 |
| `github-readme-stats-git-main-sigco3111.vercel.app` | 404 | — | 안 됨 |
| `github-readme-stats-xi-two-26.vercel.app` | 404 | — | 안 됨 |

**patch 시 주의 (함정 3과 연계)**: stats/langs의 `src=` 2줄은 alt 속성이 다르므로 (`alt="stats"` vs `alt="langs"`) 둘을 한 번에 patch하려면 old_string에 alt를 명시해서 unique하게 만들 것. streak은 URL 도메인이 다르므로 자동 보존.

**검증 패턴 (raw CDN 5분 캐시 함정 1과 결합)**:
```bash
# 1. 미러 200 OK 사전 확인
curl -sI "https://github-readme-stats-sigma-kohl.vercel.app/api?username=X&show_icons=true&theme=tokyonight" | head -1

# 2. push 후 5분 대기 (raw max-age=300)
sleep 300

# 3. raw SHA256 3-way 일치 (로컬 == raw 캐시 우회 == API)
# 4. 변경 의도: 'sigma-kohl' 카운트 2개, 'github-readme-stats.vercel.app' 카운트 0개, 'herokuapp.com' 카운트 1개 (streak 보존)
```

### 검증 워크플로 권장 (5-step)

```python
VERIFY_DIR = $(python3 -c "import tempfile; print(tempfile.mkdtemp(prefix='hermes-verify-profile-'))")
cat > "$VERIFY_DIR/verify.py" <<'EOF'
import hashlib, json, urllib.request, base64, subprocess
from datetime import datetime, timezone
from pathlib import Path

REPO = Path("/path/to/local/{user}")
UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) hermes-verify"

def fetch(url, timeout=20):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, r.read()
    except Exception:
        return -1, b""

# 1. 푸시 후 시간 경과 (≥ 60초)
push_dt = ...  # GitHub API HEAD에서
elapsed = (datetime.now(timezone.utc) - push_dt).total_seconds()
assert elapsed >= 60

# 2. SHA256 cross-check (3-way: 로컬 + raw 캐시 우회 + API)
local_sha = hashlib.sha256((REPO / "README.md").read_bytes()).hexdigest()
_, raw_body = fetch(f"https://raw.githubusercontent.com/{user}/{user}/main/README.md?nocache={hash(local_sha)}")
assert hashlib.sha256(raw_body).hexdigest() == local_sha

_, api_body = fetch(f"https://api.github.com/repos/{user}/{user}/contents/README.md")
api_content = base64.b64decode(json.loads(api_body)["content"]).decode()
assert hashlib.sha256(api_content.encode()).hexdigest() == local_sha

# 3. 변경 의도 정확성 (컨텍스트 단위)
# 4. GitHub Profile HTML 렌더 (작은따옴표 둘 다 허용)
# 5. .git 무결성 (git fsck 성공, HEAD 동기화, working tree clean)
EOF
python3 "$VERIFY_DIR/verify.py"
rm -rf "$VERIFY_DIR"
```

## 검증 체크리스트

푸시 후:

- [ ] GitHub 프로필 페이지 열어서 즉시 렌더 확인
- [ ] Stats 카드 3종 모두 정상 로드 (cached 이미지 깨짐 없는지)
- [ ] `github-readme-stats.vercel.app` 503 확인 (DEPLOYMENT_PAUSED 미감시 시 미러 URL 사용)
- [ ] **듀얼 카드 임베드 사용 시** GitFut PNG + Tokscale SVG 모두 200 OK
- [ ] shields.io 배지 6종 이내
- [ ] 카테고리 4~6개, 각 카테고리 4~8개 repo
- [ ] Snake 애니메이션 (선택) 워크플로 1회 트리거 확인
- [ ] 모바일 폭에서 레이아웃 깨짐 없는지 (`&nbsp;` 구분자 사용 시 800px 미만에서 wrap 발생 — 의도된 동작)
- [ ] SHA256 3-way 일치 (로컬 == raw 캐시 우회 == GitHub API)
- [ ] .git fsck 무에러, working tree clean

## 보조 파일

- `references/category-templates.md` — 6개 카테고리별 repo 목록 템플릿
- `references/shields-badge-patterns.md` — 챌린지/OSS/스펙 배지 패턴 카탈로그
- `references/stats_card_mirrors.md` — vercel.app DEPLOYMENT_PAUSED 사건의 미러 카탈로그 (sigma-kohl 권장, 2026-07-07)
- `references/featured-project-card-template.md` (NEW, 2026-07-09) — Featured Project 2-col 테이블 카드 + MIT/Apache/BSD attribution 템플릿 + 슬롯 변수 치트시트 + 5-step 검증 워크플로. 시그니처 단일 프로젝트를 README에 노출할 때 복사-붙여넣기.
- `references/featured-project-cases.md` (NEW, 2026-07-09 sigco3111) — **실제 케이스 스터디**. Repolis Featured Project의 4단계 진화(v1 HTML 테이블 실패 → v2 단순 카드 → v3 E안 시각 부각 → 한글 헤더), 발견한 5가지 함정 실전 데이터, 색상 카탈로그, 사전 검증 체크리스트, 푸시 후 3-way 검증 코드. 다음 Featured Project 만들 때 시간 절약.
- `references/dual-card-embed.md` (NEW, 2026-07-13) — GitFut + Tokscale 듀얼 카드 임베드 케이스 스터디. `?country=KR` 쿼리스트링, `<sub>` 압축 attribution, push 전 200 OK 검증 명령, 옵션 A~D 비교표, 카드 서비스 응답 카탈로그.
- `references/dual-card-removal-2026-07-24.md` (NEW, 2026-07-24 sigco3111) — **듀얼 카드 "제거" 요청 워크플로우**. 듀얼 카드가 stats 카드를 흡수한 상태에서 단순 제거 시 stats 카드 통째 소실 위험 → git log + grep 진단 + clarify 3-옵션 매트릭스. 2-step patch 안전판 패턴. 4 patch 시간순 사례.
- `references/dual-card-count-private-pitfall-2026-07-14.md` (NEW, 2026-07-14 sigco3111) — `count_private=false`로 PAT_1 에러 우회 + 듀얼 카드의 "양쪽 정렬" 의도는 단일+우측 분리 패턴으로 풀기. 실측 사례 4단계 커밋 이력.
- `templates/profile-readme-template.md` — sigco3111 검증 프로필 README 골격 (복사-수정용)
- `scripts/check_stats_mirror.sh` — vercel.app 503 감지 + 미러 fallback 결정 스크립트 (exit 0/1/2/3)
- `scripts/verify_profile_push.sh` — Push 후 5-way SHA 검증 (로컬/raw/gh API/profile HTML/fsck) 자동화