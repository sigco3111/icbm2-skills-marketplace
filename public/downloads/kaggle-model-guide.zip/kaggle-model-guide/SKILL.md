---
name: kaggle-model-guide
description: "초보자를 위한 Kaggle 노트북 AI 모델 실행 가이드 — 설정부터 실행까지 단계별 안내"
tags: [kaggle, gpu, tutorial, beginner, huggingface, ai-model]
---

# Kaggle에서 AI 모델 실행하기

Kaggle 노트북의 무료 GPU를 사용해 HuggingFace의 다양한 AI 모델을 실행하는 초보자 가이드입니다.

## 📌 Kaggle이란?

Google이 운영하는 데이터 사이언스 플랫폼으로, **무료 GPU 노트북**을 제공합니다.
- 주 30시간 GPU 무료 사용 가능
- T4 GPU (16GB VRAM) 제공
- https://www.kaggle.com 에서 가입 (Google 계정으로 간편 가입)

---

## 1단계: 기본 설정 (매번 필수)

### 1-1. 노트북 만들기
1. Kaggle 로그인 → 상단 메뉴 **Code** 클릭
2. **New Notebook** 클릭
3. 노트북이 생성됨

### 1-2. 인터넷 켜기 (중요! 기본 OFF)
- 우측 **Settings** 클릭
- **Internet** → **On** 으로 변경
- 화면에 `Turn Off Internet` 이 보이면 켜진 상태 (이름이 반대임)

### 1-3. GPU 활성화
- Settings → **Accelerator**
- **GPU T4 x2** 선택
- 세션이 재시작될 수 있음

### 1-4. HuggingFace 토큰 준비
- https://huggingface.co/settings/tokens 접속
- **New token** → **Read** 권한으로 생성
- 토큰 복사해두기

> 💡 왜 필요? 일부 모델은 다운로드 시 HuggingFace 로그인을 요구합니다.

---

## 2단계: 모델 실행하기

### 기본 템플릿

아래 코드를 첫 번째 셀에 붙여넣고 실행하세요:

```python
# 의존성 설치 (필요한 것만 선택)
!pip install -q transformers torch accelerate

# HuggingFace 로그인
from huggingface_hub import login
login("HF_TOKEN_여기에_입력")  # ← 본인 토큰으로 교체

import torch
print(f"GPU: {torch.cuda.get_device_name(0)}")
print(f"VRAM: {torch.cuda.get_device_properties(0).total_memory / 1e9:.1f} GB")
```

---

## 3단계: 원하는 모델 실행

### 🖼️ 이미지 생성 (SDXL)
```python
!pip install -q diffusers transformers accelerate
from diffusers import StableDiffusionXLPipeline
import torch

pipe = StableDiffusionXLPipeline.from_pretrained(
    "stabilityai/stable-diffusion-xl-base-1.0",
    torch_dtype=torch.float16,
    variant="fp16"
).to("cuda")

image = pipe("A cute cat sitting on a sofa, anime style").images[0]
image.save("output.png")
image  # 노트북에 이미지 표시
```

### 💬 텍스트 생성 (LLM)
```python
!pip install -q transformers torch accelerate
from transformers import AutoModelForCausalLM, AutoTokenizer
import torch

model_name = "meta-llama/Meta-Llama-3-8B"  # HuggingFace에서 액세스 승인 필요
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForCausalLM.from_pretrained(
    model_name,
    torch_dtype=torch.float16,
    device_map="auto"
)

inputs = tokenizer("Hello, how are you?", return_tensors="pt").to("cuda")
outputs = model.generate(**inputs, max_new_tokens=100)
print(tokenizer.decode(outputs[0], skip_special_tokens=True))
```

### 🎤 음성 인식 (Whisper)
```python
!pip install -q transformers torch accelerate
import torch
from transformers import pipeline

# 오디오 파일 업로드 후
whisper = pipeline(
    "automatic-speech-recognition",
    "openai/whisper-large-v3",
    device="cuda",
    torch_dtype=torch.float16
)
result = whisper("audio.mp3")
print(result["text"])
```

### 🖼️ 이미지 분류
```python
!pip install -q transformers torch torchvision
from transformers import ViTForImageClassification, ViTImageProcessor
from PIL import Image
import torch

processor = ViTImageProcessor.from_pretrained("google/vit-base-patch16-224")
model = ViTForImageClassification.from_pretrained("google/vit-base-patch16-224").to("cuda")

# 이미지 업로드 후
image = Image.open("photo.jpg")
inputs = processor(images=image, return_tensors="pt").to("cuda")
outputs = model(**inputs)
print(model.config.id2label[outputs.logits.argmax(-1).item()])
```

---

## 4단계: 결과 다운로드

### 이미지 다운로드
```python
from IPython.display import FileLink
FileLink("output.png")
```
→ 출력된 링크를 클릭하면 다운로드됩니다.

### 파일 다운로드 (일반)
```python
import pandas as pd
pd.DataFrame({"result": ["값1", "값2"]}).to_csv("result.csv", index=False)
from IPython.display import FileLink
FileLink("result.csv")
```

---

## 🚨 자주 발생하는 문제와 해결

### 문제 1: 다운로드가 멈춤 (0%)
**원인**: 인터넷이 꺼져 있음
**해결**: Settings → Internet → On 확인

### 문제 2: 403 Forbidden 에러
**원인**: Gated Model (승인 필요)
**해결**: HuggingFace 모델 페이지 접속 → "Access repository" 클릭 → 라이선스 동의

### 문제 3: CUDA out of memory
**원인**: 모델이 GPU 메모리(16GB)보다 큼
**해결**:
- 더 가벼운 모델 사용 (예: SDXL 대신 SD 1.5)
- `variant="fp16"` 옵션 사용
- `device_map="auto"` 사용 (CPU+GPU 분산)

### 문제 4: Flax deprecated 경고
**해결**: 무시해도 됨. PyTorch 사용 중이면 동작에 영향 없음

### 문제 5: 세션이 끊김
**원인**: 일정 시간 활동 없으면 자동 종료
**해결**: 커널 재시작 후 셀을 다시 실행. 모델 재로드 필요

### 문제 6: 모델을 찾을 수 없음
**해결**: https://huggingface.co/models 에서 정확한 모델 이름 확인

---

## 📊 T4 GPU에서 실행 가능한 모델 크기 가이드

| 모델 크기 | T4에서 가능? | 예시 |
|-----------|-------------|------|
| 1~4 GB | ✅ 여유 | SD 1.5, ViT, Whisper small |
| 4~8 GB | ✅ 가능 | SDXL (fp16), Llama 3 8B |
| 8~14 GB | ⚠️ 빡빡 | Llama 3 70B (4bit) |
| 14GB+ | ❌ OOM | FLUX.1-schnell (24GB) |

> 💡 모델 페이지에서 "Model size"를 확인하세요.

---

## 🔄 작업 저장하기

노트북 자동 저장: 상단 **Save** 버튼 클릭 또는 `Ctrl+S`
Kaggle은 노트북을 계정에 저장해두므로 다음에도 바로 이어서 작업 가능합니다.
