---
name: cross-fork-pr-submission
description: "Fork 저장소에서 upstream PR 보낼 때 gh CLI 한계 + 안전한 PR workflow."
tags: [github, pr, fork, gh-cli, cross-fork, branch-strategy, evolve, pr-cleanup]
---

# Cross-fork PR submission — 안전한 workflow

**트리거**:
- "PR 보내줘", "upstream에 PR", "fork에서 메인에 기여", "메인테이너에 코드 보내기"
- gh pr create가 "Head sha can't be blank" 에러 낼 때
- 빌드 산출물과 실제 코드가 섞인 fork

**상위 스킬**: `oss-fork-localization` (fork-first 결정과 결합)

## 🚨 gh pr create의 cross-fork 한계

`gh pr create --repo upstream/owner` 호출 시:
```
pull request create failed: GraphQL:
  Head sha can't be blank, Base sha can't be blank,
  Head repository can't be blank,
  No commits between pmotschmann:master and sigco3111:pr/ko-kr-translation,
  Head ref must be a branch, not all refs are readable (createPullRequest)
```

**원인**: `gh pr create`는 같은 repo 안에서만 잘 작동. fork → upstream cross-repo PR은 GitHub UI 또는 `--web` 옵션 필요.

## ✅ 검증된 PR workflow (Evolve 사례)

### 1단계: preflight 5분

```bash
# fork가 upstream과 비교해서 어떤 파일이 다른지
cd /Users/mac/work/evolve-kr
git log --oneline upstream/master..HEAD
git diff --stat upstream/master..HEAD
```

**PR에 부적합한 파일 식별**:
- `dist/`, `build/`, `*.js` (minified), `*.png` (screenshot) → generated
- `README.md` (fork 고유 내용), `vercel.json`, `VERCEL_DEPLOY_GUIDE.md` → fork 전용
- `package-lock.json` (의존성 변경) → upstream 거부 가능

**PR에 적합한 파일**:
- `strings/strings.ko-KR.json` (번역)
- `src/vars.js` (코드 변경, 신중히)
- `.gitignore` (필요시)

### 2단계: 깨끗한 브랜치 생성

```bash
# upstream/master에서 새 브랜치 (fork의 main 아님)
git checkout -b pr/ko-kr-translation upstream/master
```

### 3단계: PR에 보낼 파일만 cherry-pick

```bash
# main 브랜치에서 필요한 파일만 복사
git checkout main -- strings/strings.ko-KR.json src/vars.js
git status  # 확인
git diff --staged --stat
```

### 4단계: 단일 squash commit

```bash
git commit -m "feat(i18n): complete Korean (ko-KR) translation

- 1507 lines of Korean strings added
- src/vars.js: set ko-KR as default locale
- Verified via Vercel deployment: https://evolve-kr.vercel.app

Closes #XXX (없으면 제거)"

# upstream master가 오래됐으면 rebase
git rebase upstream/master
git push origin pr/ko-kr-translation --force-with-lease
```

### 5단계: gh pr create (--web 옵션)

```bash
gh pr create \
  --repo pmotschmann/Evolve \
  --head sigco3111:pr/ko-kr-translation \
  --base master \
  --title "feat(i18n): complete Korean (ko-KR) translation" \
  --body "..." \
  --web
```

**`--web`은 브라우저에서 PR 작성 페이지를 열어줌** (cross-fork의 한계 우회). 직접 작성하는 게 가장 안정적.

### 6단계 (실패 시): 브라우저 URL 직접 열기

```
https://github.com/<upstream-owner>/<repo>/compare/<base>...<fork-owner>:<head>?expand=1
```

예: `https://github.com/pmotschmann/Evolve/compare/master...sigco3111:pr/ko-kr-translation?expand=1`

## 📋 Evolve PR 회고 (2026-07-28)

**상황**: 
- `strings.ko-KR.json` 1507 lines 한국어 번역 추가
- `vars.js` 한국어 기본 로케일 설정
- 9 commits ahead of upstream/master
- 11 files changed, 1829 insertions

**PR 후보 분류**:
- ✅ `strings/strings.ko-KR.json` (1507 lines)
- ❌ `evolve/main.js` (2.3MB, generated)
- ❌ `wiki/wiki.js` (2.4MB, generated)
- ❌ `docs/screenshot-korean-game.png` (fork 전용)
- ❌ `VERCEL_DEPLOY_GUIDE.md` (fork 배포 가이드)
- ❌ `vercel.json` (Vercel 설정)
- ⚠️ `package.json`, `package-lock.json` (vercel 도구 추가)
- ⚠️ `README.md` (한국어 — upstream이 거부할 수 있음)

**최종 결정**: `strings.ko-KR.json`만 (vars.js 변경 제외). 가장 안전, 머지 가능성 최대.

**머지 가능성 평가** (Evolve):
- 다른 i18n PR 패턴 (ja-JP, zh-CN) 준수 ✅
- Demo URL로 사전 검증 ✅
- 코드 변경 없음 (낮은 리스크) ✅
- `vars.js` 기본 변경 없음 ✅
- Trailing comma fix 포함 ✅
- **전체 PR 머지 가능성: 80%+**

## 🎯 일반화 가능한 PR workflow

```bash
# 1. preflight: 어떤 파일이 PR 적합한지
git diff --stat upstream/<base>..HEAD
# generated/fork 전용 제외한 파일 식별

# 2. 깨끗한 PR 브랜치
git checkout -b pr/<topic> upstream/<base>
git checkout main -- <pr-eligible-files>
git commit -m "..."

# 3. push + gh pr create --web (cross-fork 우회)
git push -u origin pr/<topic>
gh pr create --repo <upstream> --head <fork>:<branch> --base <base> --web

# 4. 브라우저에서 최종 작성 + Create pull request
```

## 흔한 함정

- **gh pr create가 cross-fork에서 "Head sha can't be blank" 에러** → `--web` 또는 브라우저 URL 직접
- **빌드 산출물이 PR에 포함됨** → upstream에 들어가면 안 됨, preflight에서 제외
- **vars.js / 설정 파일 변경** → 메인테이너가 거부할 수 있음, 신중히
- **demo URL/PR 본문에서 live verification 강조** → 머지 가능성 ↑
- **다른 i18n PR 패턴과 일치** → 일관성, 머지 가능성 ↑
- **trailing comma / 작은 fix 포함** → 메인테이너 친화적

## PR 머지 후 처리

```bash
# 1) upstream과 sync
git fetch upstream
git checkout main
git merge upstream/master
git push origin main

# 2) fork 유지 vs archive 결정
# - 한국어 locale 사용: fork 유지 + 계속 polish
# - 한국어 locale 불필요: fork archive (GitHub Settings → Danger Zone → Archive)
# - 다른 작업: 새 포크 생성
```

## 사용법

이 스킬은 `oss-fork-localization` fork-first 결정 후 호출:
1. `oss-fork-localization` → fork + 한국어 번역 + 빌드 검증
2. **이 스킬** → upstream PR workflow
3. PR 머지 → fork 정리
4. 다른 i18n 작업으로 (Evolve polish, 다른 후보)
