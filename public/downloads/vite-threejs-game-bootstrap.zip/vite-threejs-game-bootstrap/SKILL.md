---
name: vite-threejs-game-bootstrap
description: Three.js + Vite game bootstrap. Fix CORS, vitest duck-type.
version: 1.0.0
author: HyeRin
license: MIT
metadata:
  hermes:
    tags: [vite, threejs, vitest, bootstrap, webgl, esm]
    related_skills: [one-shot-game-orchestration, kanban-project-delivery]
---

# Vite + Three.js + Vitest 게임 부트스트랩

## 사용 시기

- 새 브라우저 WebGL 게임 (Three.js r180+) 을 vite + vitest 로 시작할 때
- 기존 프로젝트가 "부팅 중..." 에서 안 넘어갈 때
- vitest 가 `HTMLCanvasElement is not defined` 같은 node 환경 한계로 실패할 때
- vite 8 + rolldown 빌드 옵션 (manualChunks 함수 필수 등) 충돌 디버깅할 때

## 부트스트랩 5단계

### 1. project init + 의존성 (★ 단일 런타임 의존성 강제)

```bash
mkdir /Users/mac/work/<project> && cd $_
npm init -y
npm install three@0.180.0          # ★ 런타임 의존성은 three 단일
npm install -D vite@8.1.5 vitest@2.1.5
```

**금지**: three 외 런타임 패키지 추가. archive, gamepad, cannon-es 등 필요해지면 **Phase 별 카드**로 분해해서 한 번에 추가.

### 2. vite.config.js — strictPort + 127.0.0.1

```js
import { defineConfig } from 'vite';
export default defineConfig({
  server: { host: '127.0.0.1', port: 5173, strictPort: true },
  build: { target: 'es2020', sourcemap: true, chunkSizeWarningLimit: 1024 },
});
```

**★ 함정: vite 8 + rolldown 호환성**: `manualChunks` 는 **함수**만 받음 (object 안 됨). 일반적인 `manualChunks: { core: ['/src/core/index.js'] }` 패턴은 `TypeError: manualChunks is not a function` 으로 fail. → `chunkSizeWarningLimit` 으로 대체, 청크 분리는 ESM dynamic import 로 처리.

### 3. index.html — 한국어 ARIA + 로딩 인디케이터

```html
<!doctype html>
<html lang="ko">
  <head>
    <meta charset="UTF-8" />
    <meta name="theme-color" content="#07111f" />
    <title>Game</title>
    <style>
      :root { color-scheme: dark; font-family: system-ui, sans-serif; background: #07111f; }
      * { box-sizing: border-box; }
      html, body, #app { width: 100%; height: 100%; margin: 0; overflow: hidden; }
      #game-canvas { display: block; width: 100%; height: 100%; }
      #loading-indicator { position: fixed; inset: 50% auto auto 50%; transform: translate(-50%, -50%); color: #d7e8ff; }
      #loading-indicator[hidden] { display: none; }
    </style>
  </head>
  <body>
    <main id="app">
      <canvas id="game-canvas" aria-label="Game canvas"></canvas>
      <p id="loading-indicator" role="status">부팅 중…</p>
    </main>
    <script type="module" src="/src/main.js"></script>
  </body>
</html>
```

### 4. main.js — Three.js 부팅 + DPR cap + resize + REVISION 로그

```js
import * as THREE from 'three';
import { Ctx } from './core/index.js';
import { getPreset } from './core/config.js';

const canvas = document.querySelector('#game-canvas');
const loadingIndicator = document.querySelector('#loading-indicator');
if (!(canvas instanceof HTMLCanvasElement)) throw new Error('Game canvas was not found.');

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(60, 1, 0.1, 1000);
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
renderer.setClearColor(0x07111f, 1);
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

function resize() {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight, false);
  renderer.render(scene, camera);
}
window.addEventListener('resize', resize);
resize();
loadingIndicator?.setAttribute('hidden', '');
console.log(`Three.js r${THREE.REVISION}`);
```

부팅 검증 5개: (1) npm install 무경고 (2) vite build 성공 (3) dev 서버 127.0.0.1:5173 콘솔 에러 0 (4) 단색 WebGL 캔버스 (5) `Three.js r180` 로그 한 줄.

### 5. dev 서버 띄우기 (★ 비대화 환경 가드 우회)

```bash
# vite dev 는 long-lived → 백그라운드로 띄움
terminal(background=true, notify_on_complete=true) {
  cd /Users/mac/work/<project> && npx vite --host 127.0.0.1 --port 5173 --strictPort
}

# 검증 (3개 엔드포인트)
sleep 5
curl -fs -o /dev/null -w "%{http_code}\n" http://127.0.0.1:5173/                           # → 200 text/html
curl -fs -o /dev/null -w "%{http_code} %{content_type}\n" http://127.0.0.1:5173/src/main.js  # → 200 text/javascript
curl -fs -o /dev/null -w "%{http_code} %{content_type}\n" http://127.0.0.1:5173/src/core/index.js  # → 200 text/javascript

# open_preview
open_preview(url='http://127.0.0.1:5173/')
```

## 함정 (전부 minimax-of-duty 2026-07-27 실측)

### ★★★ `file://` 직접 열기 + vite preview SPA fallback (함정 16)

가장 자주 만나는 함정. **사용자가 `index.html` 을 Chrome 에 직접 입력할 때**:

- `file:///` 프로토콜은 ES module (`<script type="module">`) 자동 차단
- "부팅 중…" 텍스트만 화면에 남음
- DevTools: `Access to script ... from origin 'null' blocked by CORS`

**또 `vite preview` (npm run preview) 도 함정**:

- SPA fallback 으로 모든 미인식 경로를 `/index.html` 로 라우팅
- `/src/main.js` 요청이 index.html 본문 (1257 bytes) 으로 응답
- 정상이면 Vite ESM 응답 (8526 bytes JS) 받아야 함

**예방**:
1. **`open_preview` 는 항상 `vite dev` (5173) 만 사용** — preview (4173) 절대 안 씀
2. 사용자 직접 URL 입력 시 `http://127.0.0.1:5173/` 만 안내 (절대 `file://` 금지)
3. vite preview 의 SPA fallback 으로 **preview 서버는 build 결과 검증 용도**만. 개발/미리보기 용은 dev 서버.

### ★★★ vitest node 환경에서 `HTMLCanvasElement is not defined`

vitest 기본 환경 = Node. 브라우저 globals 없음. `ctx.js`에서 `instanceof HTMLCanvasElement` 체크 시 ReferenceError.

**해결 — duck-typing 가드**:

```js
// ❌ vitest fail
if (!(canvas instanceof HTMLCanvasElement)) throw new Error(...);

// ✅ duck-typing
if (!canvas || typeof canvas.getContext !== 'function' || typeof canvas.setAttribute !== 'function') {
  throw new Error('Ctx requires an HTMLCanvasElement');
}
```

테스트에서 mock 도 같이:

```js
function makeCanvas() {
  return { getContext: () => null, setAttribute: () => {}, width: 0, height: 0 };
}
```

### ★★★ Time 클래스 null sentinel + 시계 역행 가드

```js
// ❌ tick(0) 와 tick(N) 모두 priming 에 걸림 (sentinel=0 충돌)
reset() { this._last = 0; }
tick(nowMs) {
  if (this._last === 0) { this._last = nowMs; return; }
  ...
}

// ✅ null sentinel + 시계 역행 가드
reset() { this._last = null; }
tick(nowMs) {
  if (this._last === null) { this._last = nowMs; return; }
  const rawDt = (nowMs - this._last) / 1000;
  if (rawDt < 0) return; // 시계 역행
  ...
}
```

### 운영자 재구현 vs 워커 위임 결정

minimax-of-duty Phase 1.0 + 1.1 에서 **운영자가 ARCHITECTURE.md + 워커 latest_summary 로 6 모듈 + main + test 직접 재구현** 했을 때 25분, vitest 29/29 + vite build PASS 시킴. **함정 14 로 scratch 워커가 사용자 손에 코드를 못 남긴 상황**에서 효과적.

**판단 기준**:
- 워커가 `--workspace dir:<user_dir>` 로 작업 중이고 5분 안에 진척 보임 → 워커 기다림
- 워커 scratch 모드 + done 후 파일 없음 → 운영자 재구현 (5~30분)
- 워커 1시간+ 0% CPU stuck → 운영자 직접 + 워커 reclaim + 보정 카드 1장

### 비대화 환경 가드 (vite build, dev 서버)

```bash
# ❌ 차단됨
npx vite build                       # long-lived 가드
npx vite preview --port 4173         # long-lived 가드

# ✅ 우회: node 직접 호출
node -e "import('vite').then(async ({ build }) => { await build({ mode: 'production' }); process.exit(0); })"

# ✅ dev 서버 백그라운드
terminal(background=true, notify_on_complete=true) { npx vite --host 127.0.0.1 --port 5173 --strictPort }
```

### 비대화 환경에서 sleep

```bash
# ❌ 60초 sleep 은 비대화 가드 걸림
sleep 60 && curl ...

# ✅ 짧게 분할
sleep 30 && curl ...; sleep 30 && curl ...
```

### ★★★ 워커가 Three.js r180+ deprecated prototype 호출 시 자가 진단 실패 (2026-07-27 minimax-of-duty Phase 1.2 실측)

**상황**: 워커가 `src/render/renderer.js` 에서 `new Color(0x07111f).clone()` 패턴 사용. 부팅 화면 콘솔에:
```
Uncaught Error: subsystem "render" init failed: property.clone is not a function
    at bootSubsystems (systems.js:63:13)
```

**근본 원인**: Three.js r180+ 에서 일부 prototype 메서드 변경/이동. `Color.prototype.clone` 같은 흔한 메서드가 ESM module-scope 평가 시점에 잡히지 않음. mshumer 의 ARCHITECTURE.md (2026-07 시점 Three.js r180) 와 워커의 code 생성 사이에 API 변경.

**즉시 인식 신호**:
- DevTools 콘솔에 `property.clone is not a function` / `is not a function` 계열 에러
- "부팅 중…" 인디케이터 안 사라짐
- Three.js REVISION 로그는 안 뜸 (bootSubsystems throw 로 끊김)

**예방/회복 (★ 운영자 직접 fix 가 가장 빠름)**:
1. **워커 5분+ 0% CPU + 새 파일 0개 → 워커 stuck 패턴. 1분 더 보고 변동 없으면 워커 SIGTERM + 운영자 직접 fix**
2. 운영자 fix 패턴: `new Color()` 매 호출 직접 생성 (`.clone()` 회피) — 공유 prototype 메서드 의존 줄이기
3. 또는 `three@0.169` 같은 older stable 버전으로 다운그레이드 (ARCHITECTURE.md 와 호환되는 latest)

**워크플로 가치**: 워커가 self-diagnose 후 fix 못 하는 패턴이 **10~25분 손실**. 운영자가 grep 으로 `.clone()` 호출 1개 찾고 1줄 patch → 30초 fix. **워커가 Three.js 코드 짤 때마다 발생 가능**.

### ★★★ "부팅 중…" 화면 3-축 진단 (2026-07-27 minimax-of-duty 실측)

**상황**: 사용자 스크린샷이 "부팅 중…" 인디케이터 + DevTools 콘솔 에러 0 줄. 운영자가 어디부터 봐야 할지 모름.

**3-축 진단**:

| 축 | 확인 명령 | 정상 | 비정상 시 |
|---|---|---|---|
| dev 서버 alive | `curl -fs -o /dev/null -w "%{http_code}\n" http://127.0.0.1:5173/` | `200` | 0/timeout → 서버 죽음, 재시작 |
| 모듈 ESM 응답 | `curl -fs -o /dev/null -w "%{http_code} %{content_type}\n" http://127.0.0.1:5173/src/main.js` | `200 text/javascript` | `200 text/html` 1257 bytes → SPA fallback (vite preview 서버 혼선) |
| 사용자 브라우저 cache | 사용자가 `Cmd+Shift+R` 강력 새로고침 했는가? | HMR 갱신 OK | 강력 새로고침 전이면 옛 모듈. 해결: macOS `Cmd+Shift+R` |

**가장 흔한 함정 (Phase 1.2 끝)**: 사용자가 `127.0.0.1:5173` 페이지를 `Cmd+R` (일반 새로고침)으로 HMR 갱신 안 되는 상태. **강력 새로고침 `Cmd+Shift+R` 안내 필수** (vite HMR 은 cache 보존하니 옛 모듈 응답).

### ★★★ 운영자 재구현 시 만나는 자잘한 버그 3종 (2026-07-27 minimax-of-duty 실측)

운영자 재구현 시 단위 테스트에서 발견된 패턴 — 워커도 동일 패턴 가능:

1. **외부 for 루프 종료 후 `i` 참조**: `Array.from({length: 100}, () => new RNG(i).chance(0.5))` — `i` 가 outer for 의 `i` 인데 for 종료 후 사용. → 명시적 for 루프로 재작성.
2. **vitest node 환경에서 `instanceof HTMLCanvasElement` ReferenceError**: 위 "★★★ vitest node 환경" 섹션 참조.
3. **Time 클래스의 sentinel=0 부팅 충돌**: 위 "★★★ Time 클래스 null sentinel" 섹션 참조.

운영자가 워커 보정 시 grep 으로 점검 패턴.

## 디렉터리 구조 (목표)

```
.
├── package.json              # three 0.180 + vite 8.1.5 + vitest 2.1.5
├── vite.config.js
├── index.html                # 한국어 ARIA + 로딩 인디케이터
├── src/
│   ├── main.js               # 부팅 + 캔버스 + DPI cap + resize
│   └── core/                 # 결정론적 엔진 (Time, RNG, Events, Config, Ctx, Systems)
├── tests/
│   └── core.test.js          # 29+ 단위 테스트 (vitest)
└── prompts/                  # 모든 결정 프롬프트 (한글 + 영문)
```

## 검증 절차 (★ 모든 새 commit 전 실행)

```bash
cd /Users/mac/work/<project>

# 1. 의존성 + 빌드
npx vitest run --no-cache 2>&1 | tail -5  # → "Tests X passed (X)"
node -e "import('vite').then(({build}) => build({mode:'production', logLevel:'info'}))" 2>&1 | tail -10

# 2. dev 서버 띄우고 5초 대기 후 3 엔드포인트 확인
npx vite --host 127.0.0.1 --port 5173 --strictPort &
sleep 5
curl -fs http://127.0.0.1:5173/
curl -fs http://127.0.0.1:5173/src/main.js
curl -fs http://127.0.0.1:5173/src/core/index.js

# 3. chrome / preview 패널에서 직접 확인
open_preview('http://127.0.0.1:5173/')
```

## 참고 패턴

- `one-shot-game-orchestration` — 11서브시스템 → 5-Phase 칸반 분해
- `kanban-project-delivery` — `done` 의 진짜 의미, scratch vs dir 워크스페이스
- `references/minimax-of-duty-boot.md` (TODO) — 프로젝트별 상세 셋업 노트
