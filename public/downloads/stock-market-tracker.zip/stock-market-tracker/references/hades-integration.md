# hades 통합 실측 기록 (2026-06-23)

## 개요

junhoyeo/hades (https://github.com/junhoyeo/hades) — 한국 주식(KOSPI/KOSDAQ) 데이터 +
백테스트 Rust CLI. AI 친화적(JSON 기본). MIT, 7스타, 107커밋, 1000+ 테스트.

pykrx 단독으론 부족한 **백테스트 / 외국인 수급 메트릭 / 5종 전략 × 4종 필터 프리셋 /
cross-sectional 모멘텀** 등을 hades로 보강.

## 1회 셋업 (실측 소요시간)

| 단계 | 소요 | 비고 |
|---|---|---|
| rustup 설치 (curl \| sh) | ~1분 | `~/.cargo` ~500MB 영구 |
| `git clone --depth 1` hades | <1초 | |
| `cargo build --release -p hades-cli` | **4분 4초** | 첫 빌드만, 의존성 캐시됨 |
| conda env `hades` 생성 | 30초 | USER.md 정책대로 |
| pip install pykrx+pandas+pyarrow+tqdm | ~1분 | matplotlib 폰트 캐시 주의(timeout만 발생) |
| `sync_krx_data.py --init 1` (전체 동기화) | ~5분 | 41MB parquet × 2,600+ 종목 |
| **합계** | **~10분** | 1회만 |

## 실측 호출 결과 (2026-06-23 14:50 KST, /tmp/hades-test/hades)

### hades ticker 005930 — 46ms

```json
{
  "symbol": "005930",
  "market": "KOSPI",
  "data_available": true,
  "first_date": 20241230,
  "last_date": 20260622,
  "total_bars": 357,
  "last_close": 353500
}
```

### hades ohlcv 005930 --limit 3 — 45ms

```json
{
  "symbol": "005930",
  "bars": [
    {"date":"2026-06-18","open":345000,"high":363000,"low":344500,"close":362500,
     "volume":32764450,"amount":0},
    {"date":"2026-06-19","open":372500,"high":374500,"low":346250,"close":354000,
     "volume":43284898,"amount":0},
    {"date":"2026-06-22","open":343000,"high":363000,"low":342000,"close":353500,
     "volume":24330451,"amount":0}
  ]
}
```

⚠️ `amount` 필드 = 0. pykrx 스크래핑 한계로 거래대금 컬럼이 비어있음. OHLCV는 정상.

### hades backtest (1년 weekly top-30) — <5s, 실제 계산됨

```json
{
  "config": {
    "market": "kospi", "strategy": "momentum", "top_k": 30,
    "rotation": "weekly", "filter_preset": "moderate", "entry": "day1",
    "start_date": "2025-07-01", "end_date": "2026-06-22"
  },
  "results": {
    "total_return_pct": -1.9203190000000037,
    "final_value": 98079681,
    "initial_capital": 100000000,
    "num_trades": 540,
    "avg_stocks_passed": 314.3888888888889
  }
}
```

→ 540 trades 정상, -1.92% (1년 모멘텀 약세장 검증).

### hades foreign-flow 005930 — 메트릭 null

```json
{"symbol": "005930", "period_days": 30, "metrics": null}
```

→ `data/foreign_flow/` 미동기화. KRX 로그인 env 필요.

## 발견한 함정 (실측 기반, 검증 완료)

### 함정 1: 외국인 수급 parquet 미동기화

**증상**: `hades foreign-flow 005930 --days 30` → `{"metrics": null}`

**원인**: `data/foreign_flow/` 디렉토리는 git에 커밋되지 않음. OHLCV는 `--init 1`로 한 번에
받아지지만 foreign flow는 `sync_foreign_flow.py`로 별도 + KRX 회원 로그인 필요.

**해결**:
```bash
# KRX_ID/KRX_PW 환경변수 필요 (KRX 홈페이지 회원가입)
export KRX_ID="your_id"
export KRX_PW="your_pw"
~/opt/anaconda3/envs/hades/bin/python ~/hades/scripts/sync_foreign_flow.py --month 202606
```

**판단**: KRX 비회원이면 **외국인 수급 자동화 보류**. OHLCV + 백테스트만 우선 활용.

### 함정 2: 백테스트 윈도우 짧으면 trade=0

**증상**: 6개월 윈도우 + top-10 모멘텀 → `num_trades: 0, total_return_pct: 0.0`

**원인**: 데이터 시작일(2024-12-30) + 룩백 윈도우(예: 60일) + 보유기간 = 첫 시그널 발생이
중반 이후로 밀림. 짧은 윈도우에서는 시그널이 채워지지 않음.

**해결 (권장 파라미터)**:
- 모멘텀: 1년+ 윈도우, top-30+, weekly rotation → trade 정상
- mean_reversion / low_volatility: 6개월 윈도우도 OK (시그널 빈도 더 높음)

### 함정 3: 첫 빌드 4분 + 데이터 5분

**증상**: 매번 빌드하면 cron 실행이 느려짐

**해결**: 한 번 빌드한 바이너리(`target/release/hades`) + parquet(`data/ohlcv/`)는 그대로 유지.
cron은 `hades <command> --format json` 호출만. **CI/CD에선 캐시 마운트 필수**.

## 우리 cron에 끼우는 법 (검증된 패턴)

### 패턴 1: 단순 시세 조회 (삼성전자 일일)

```python
import subprocess, json

def hades(cmd, timeout=60):
    r = subprocess.run(
        ['~/hades/target/release/hades'] + cmd,
        capture_output=True, text=True, timeout=timeout, shell=False
    )
    if r.returncode != 0:
        return {'error': r.stderr, 'rc': r.returncode}
    return json.loads(r.stdout)

# 일일 시황에 삼성전자 종가 추가
data = hades(['ticker', '005930'])
print(f"삼성전자({data['last_date']}) 종가 {data['last_close']:,}원")
# 삼성전자(20260622) 종가 353,500원
```

### 패턴 2: 관심 종목 일괄 스냅샷 (N개)

```python
tickers = ['005930', '000660', '373220', '035420', '005380']
results = []
for t in tickers:
    d = hades(['ticker', t])
    results.append({
        'symbol': t,
        'name': ticker_name_map.get(t, t),  # 별도 매핑 필요
        'last_close': d['last_close'],
        'last_date': d['last_date'],
    })
# → Notion/텔레그램에 표 형태로 전송
```

### 패턴 3: 백테스트 결과 주간 리포트

```python
# 매주 토요일 cron: 모멘텀 top-30 weekly 1년 백테스트
bt = hades(['backtest', '--market', 'kospi', '--strategy', 'momentum',
            '--top-k', '30', '--rotation', 'weekly',
            '--from', monday_minus_365, '--to', sunday, '--filter', 'moderate'],
           timeout=120)

# Notion에 기록
notion_page = {
    'title': f'KOSPI 모멘텀 주간 리포트 ({today})',
    'config': bt['config'],
    'results': bt['results'],
}
```

## 다음 단계 옵션 (A/B/C)

### A. 그대로 끼우기 (10분)
- stock-market-tracker의 일일 시황 cron에 `hades ticker <portfolios>` 한 줄 subprocess 추가
- 출력 JSON 파싱해서 텔레그램 메시지에 종가/등락률 삽입
- 위험 없음, 즉시 가치

### B. MCP 래퍼 (30분)
- hades CLI → MCP tool로 감싸기 (hermes-agent의 `mcp-builder` 스킬 활용)
- 노출 툴: `hades_ticker`, `hades_ohlcv`, `hades_backtest`, `hades_foreign_flow`
- junhoyeo 님께 컨트리뷰트(PR) vs 독립 래퍼 결정 필요
- A의 상위호환, 학습 가치 ↑

### C. 둘 다 (A → B 순차)
- A로 데이터 흐름 먼저 입증
- B로 정식화, 나중에 컨트리뷰트

## 한국 시장 데이터 백엔드 비교 (2026-06-23 시점)

| 백엔드 | 강점 | 약점 |
|---|---|---|
| **pykrx** (현재) | 가볍다, KRX 직접, 별도 설치 0 | 백테스트 X, 외국인 수급 메트릭 약함, amount=0 |
| **yfinance** | 글로벌 시장, 미국 주식 | 한국 = EWY ETF만 (개별 종목 일부), 정확도 ↓ |
| **hades** (junhoyeo) | 백테스트 엔진 5전략, AI 친화 JSON, MIT | 첫 빌드 4분, 외국인 수급은 KRX 로그인 필요 |
| **KRX 직접** (data.go.kr) | 공식, 안정 | API 키 발급, rate limit |

**권장 조합**:
- 미국 시장 → yfinance
- 한국 시세 (단순 조회) → pykrx (가볍고 충분)
- 한국 백테스트 / 전략 검증 → hades subprocess
- 한국 외국인 수급 정밀 → hades + KRX 로그인 (옵션)

## 참고 링크

- hades GitHub: https://github.com/junhoyeo/hades
- hades README의 "Korean Market Rules" 섹션: 틱사이즈/VI/세금/가격제한 등 266 테스트로 검증
- pykrx 공식: https://github.com/sharebook-kr/pykrx
