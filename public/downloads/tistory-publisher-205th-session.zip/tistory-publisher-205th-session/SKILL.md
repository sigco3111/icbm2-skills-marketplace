---
name: tistory-publisher-205th-session
description: 205차 세션 노트 — Notion PATCH cleanup 자동화 + tistory.env 파싱 형식 함정
version: "1.0.0"
last_updated: "2026-07-07-205th"
---

# 205차 세션 노트 — Notion PATCH cleanup 자동화 + tistory.env 파싱 함정

## 핵심 발견 2가지

### 1) tistory.env 파싱 형식 함정 (205차 신규) ⭐

`tistory_publisher.py`의 세션 로드 코드는 `export TISTORY_XXX=...` 형식을 가정하지만, 실제 `~/.hermes/secrets/tistory.env`는 **`KEY=VALUE` 단순 형식** (export 접두사 없음). 205차 §3.11 5단계 보정 heredoc 작성 시 쿠키 로드가 실패해 처음에 발견.

**올바른 파싱 패턴 (205차 확정)**:
```python
cookies = {}
with open(os.path.expanduser('~/.hermes/secrets/tistory.env')) as f:
    for line in f:
        line = line.strip()
        if line.startswith('TISTORY_') and '=' in line and not line.startswith('#'):
            kv = line.split('=', 1)
            cookies[kv[0].replace('TISTORY_','')] = kv[1].strip()
```

**틀린 패턴 (205차 첫 시도에서 ValueError/HTTP 200 but HTML)**:
```python
# ❌ export 접두사 가정 (실제 파일에는 없음)
for line in f:
    if line.startswith('export '):
        kv = line[7:].split('=', 1)
        cookies[kv[0]] = kv[1].strip('"').strip("'")
# 결과: cookies = {} (빈 dict) → HTML 응답 받음
```

**영향**: §3.17 보정 heredoc을 자동화 스크립트(`scripts/post-publish-correct.sh`)로 만들 때 반드시 이 형식을 따라야 함. 200차/201차 세션 노트에는 `set -a; source ~/.hermes/secrets/tistory.env; set +a` shell source 방식을 썼지만, Python heredoc에서 직접 파싱할 때는 위 패턴이 필요.

### 2) Notion PATCH cleanup 자동화 (205차 신규) ⭐

202차 §3.19의 권장 작업 + 203차 §3.20.1의 "수동 매핑 유지" 방식이 **cron 환경에서 비효율**. 205차에서 **`state.last_topics.topic`의 30자 prefix를 Notion 페이지 이름과 자동 매칭**하는 패턴을 실전 통과시킴 → §3.20.1 v2로 격상.

**자동 cleanup 패턴 (205차 확정, 3/3 성공)**:
```python
# state.last_topics의 topic 이름 30자 prefix로 Notion 페이지와 매칭
state = json.loads(open('/Users/mac/.hermes/memory/blog_pipeline_state.json').read())
state_titles = [t.get('topic','') for t in state.get('last_topics',[]) if t.get('topic')]

# Notion 활성 페이지의 이름 30자와 비교
for p in all_pages:
    name = p['name'].lower()[:30]
    for st in state_titles:
        if st and (st[:30].lower() == name or name in st.lower()[:30] or st.lower()[:30] in name):
            to_patch.append((p['id'], p['url'], p['name']))
            break
```

**205차 실행 결과**:
- 1차 cleanup: 2/2 성공 (31177, 31179)
- 2차 cleanup: 3/3 성공 (31158 OpenTag, 31169 Figma, 31173 Art Institute)
- 총 5건 자동 비활성화 → 후보 4→1로 줄어듦

**장점**:
- `known_mappings` 수동 유지 부담 제거
- `state.last_topics`에 이미 있는 모든 발행 topic이 자동으로 cleanup 대상
- 발행 즉시 다음 cron부터 후보 풀에서 자동 제거

**제한**: state.last_topics의 topic과 Notion 페이지 이름이 **30자 prefix에서** 매칭되어야 함. 한글/영문 혼합 title에서 30자가 충분히 구별력을 가짐 (실전 5/5 매칭 성공).

## §3.21 false negative 실전 검증 (205차)

§3.21에서 발견된 `last_titles[:50]` prefix 매칭 false negative가 205차에서도 재현 우려가 있었지만, 다음 두 가지 안전망으로 우회:

1. **title 전체 비교** (last_titles_full set): 4차 dedup으로 추가
2. **Notion PATCH cleanup**: 후보 풀 자체를 축소

결과: 4건 후보 중 진짜 미발행 1건 (31170)만 남음 → 4중 dedup 통과 → 정상 발행.

## 205차 작업 요약

- §3.8.1 3-endpoint probe: ✅ 통과 (3/3, 200 OK)
- `blog_pipeline.py --refresh-topics`: 12개 토픽 로드
- §3.19/§3.20.1 Notion PATCH 자동 cleanup: 5건 (2+3) → 5/5 성공
- 4중 dedup (source URL + Tistory URL + hash + title 전체) → 31170 "덜한 것이 더 낫다" 선택
- `tistory_publisher.py --file` → **#915 정상 발행** (2,140자, AI 뉴스 1219746)
- §3.11 5단계 + §4 5-1 stats 보정 heredoc: 8필드 모두 동기화
  - stats.total_published: 898 → 899
  - by_category[AI 뉴스]: 0 → 1
  - daily_counts[2026-07-07][AI 뉴스]: 0 → 1
  - last_topics append (31170, source_url 포함)
  - published_urls.txt append (Tistory URL + title + date + category)
  - published_topics.json hash append
  - details append
- §3.5 4-way 검증: Tistory 915 = state 915 = urls 915 = details 915 → **drift 0**
- **누적 drift 121** (stats 899 vs Tistory totalCount 778) §3.16 별도 작업 대상 (재확인)

## 함정 요약 (다음 세션용)

| 함정 | 해결 |
|---|---|
| `tistory.env` 파싱 시 `export` 가정 | `TISTORY_` prefix + `=` split + `replace('TISTORY_','')` |
| Notion DB에 발행된 토픽 잔존 | 자동 cleanup with state.last_topics 30자 prefix 매칭 |
| `last_titles[:50]` false negative | title 전체 비교 + Notion PATCH cleanup 안전망 |
| Tistory `items[].id` 문자열 (§3.18) | `int(it['id'])` 캐스팅 필수 |
| `published_urls.txt` 비대칭 tab (§3.20.3) | `line.split('\t')[0]` + Tistory URL 필터 |

## 영구화 권장

- **tistory_publisher 스킬 §3.20.1 갱신**: 수동 `known_mappings` 사전 유지 → state.last_topics 자동 매칭으로 전환
- **tistory_publisher 스킬 §3.17 보정 heredoc 갱신**: tistory.env 파싱 형식을 `KEY=VALUE` 단순 형식으로 수정
- **Layer 3 v3 (다음 cron 작업 시)**: `scripts/notion-cleanup.py` 신규 — state.last_topics 기반 자동 cleanup
