---
name: image-analysis
description: 이미지 분석 스킬 — OpenRouter, MiniMax MCP, Gemini CLI 등 멀티 프로바이더로 이미지 인식/분석. 사용 가능한 도구 자동 선택.
version: 1.0.0
author: ICBM2
metadata:
  hermes:
    tags: [vision, image-analysis, multimodal, openrouter, minimax, gemini]
---

# 이미지 분석 스킬 (Image Analysis)

## 개요

ICBM2는 여러 이미지 분석 프로바이더를 보유하고 있습니다. 각 프로바이더는 특화된 용도가 있으며, 이 스킬이 자동으로 또는 명시적으로 적절한 도구를 선택합니다.

## 프로바이더별 용도

| 프로바이더 | 용도 | 우선순위 |
|-----------|------|---------|
| **OpenRouter (gemini-3-flash-preview)** | 기본 — 가장 빠른 비전 인식 | 1차 |
| **MiniMax MCP (`mcp_minimax_understand_image`)** | OpenRouter 402 에러 시 자동 폴백 | 2차 |
| **Gemini CLI** | OpenRouter 불가 시 백업 또는 명시 요청 | 3차 (명시 요청) |

## 사용 방법

### 기본 (자동 선택)
```
mcp_minimax_understand_image(image_source="...", prompt="...")
```
또는 `vision_analyze` 도구 — OpenRouter gemini-3-flash-preview를 자동으로 사용합니다.

### 명시적 요청
- `"gemini cli로 분석해줘"` → `gemini-cli-vision` 스킬 사용

## 프로바이더 상세

### 1. OpenRouter (기본)
- **모델:** `google/gemini-3-flash-preview`
- **도구:** `vision_analyze` 또는 `mcp_ddg_search_*` MCP
- **크레딧:** 유료 (402 에러 시 MiniMax로 자동 폴백)

### 2. MiniMax MCP (폴백)
- **모델:** MiniMax-VL (Coding Plan 구독자 무료)
- **도구:** `mcp_minimax_understand_image`
- **크레딧:** 402 에러 없음 (Coding Plan 무료)
- **MCP 서버:** MiniMax Coding Plan 서버가 이미 Hermes에 등록됨

### 3. Gemini CLI (백업)
- **사용 조건:**
  - OpenRouter 비전 모델 사용 불가 시 (자동 폴백)
  - 주인님이 명시적으로 `"gemini cli로 분석해줘"`라고 요청한 경우