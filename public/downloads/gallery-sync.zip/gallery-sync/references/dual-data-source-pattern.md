# Gallery Dual-Data-Source Bug (2026-05-25)

## Bug: "데이터 오류: 내장 데이터 없음" + Empty Page

**Symptom:** Gallery page shows only header "ICBM2 뮤직비디오 갤러리 × ◀ 이전 다음 ▶" with no cards.

**Root Cause:** Race condition between embedded JavaScript data and AJAX fetch.

### The Broken Pattern

```javascript
// index.html
var GALLERY_DATA = null;  // ← Initially null

// Later in the same script:
(function() {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", "gallery_data.json?t=" + Date.now(), true);
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
            GALLERY_DATA = JSON.parse(xhr.responseText);  // ← Overwrites embedded data!
            renderGallery();
        }
    };
    xhr.send();
})();

renderGallery();  // ← Runs with GALLERY_DATA=null immediately!
```

**Problem 1:** `renderGallery()` runs before AJAX completes → `GALLERY_DATA` is still `null` → renders empty gallery.

**Problem 2:** If AJAX fails, embedded data in the HTML is overwritten with `null`, and `renderGallery()` is never called again.

### The Working Pattern (Fixed)

```javascript
// Embedded directly as the primary data source
var GALLERY_DATA = {"entries": [...]}  // ← Set immediately with actual data

// Then AJAX runs ASYNCHRONOUSLY for live updates only (never blocks rendering)
(function() {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", "gallery_data.json?t=" + Date.now(), true);
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
            try {
                var newData = JSON.parse(xhr.responseText);
                if (newData && newData.entries && newData.entries.length > 0) {
                    // Only update if new data has entries
                    GALLERY_DATA = newData;
                    renderGallery();
                }
            } catch (e) {
                console.warn("JSON parse error:", e.message);
            }
        }
    };
    xhr.onerror = function() {
        console.warn("gallery_data.json fetch failed");  // Silent on failure
    };
    xhr.send();
})();

// Render immediately with embedded data
renderGallery();  // ← GALLERY_DATA already has data!
```

### Key Principles

1. **Embedded data must be the primary source** — Set `GALLERY_DATA` to the actual data before any function calls
2. **AJAX is optional live-update** — It fetches new data but failure is silent (doesn't break the page)
3. **Never initialize to `null`** — Always initialize with the embedded data
4. **Render immediately after initialization** — Not after an async operation

### Debugging This Pattern

```javascript
// Add at the start of renderGallery:
console.log("renderGallery called, GALLERY_DATA:", GALLERY_DATA);
if (!GALLERY_DATA || !GALLERY_DATA.entries || GALLERY_DATA.entries.length === 0) {
    console.error("Empty data - check embedded GALLERY_DATA in HTML source");
}
```