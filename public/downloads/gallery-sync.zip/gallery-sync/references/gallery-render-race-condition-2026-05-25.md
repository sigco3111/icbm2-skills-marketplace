# Gallery Rendering Bug — Dual Data Source Race Condition (2026-05-25)

## Symptom
Gallery page showed only header text "ICBM2 뮤직비디오 갤러리 × ◀ 이전 다음 ▶" — no cards rendered.

## Root Cause

**AJAX race condition + data overwrite pattern:**

1. `GALLERY_DATA = null` (initially null)
2. `renderGallery()` called immediately → uses `GALLERY_DATA.entries` → **empty (null → empty array)**
3. AJAX `fetch('gallery_data.json')` starts async
4. AJAX completes → `GALLERY_DATA = fetched_data` (overwrites embedded data)
5. But if `gallery_data.json` fetch fails → `GALLERY_DATA` stays null OR the embedded hardcoded data was never the source of truth

**Key insight:** The embedded `window.GALLERY_DATA = {...}` was being treated as a fallback, but the render function didn't wait for it — it tried to use `GALLERY_DATA` immediately while it was still null.

## The Fix

**Pattern: Embedded data MUST render immediately, AJAX is optional live-update only**

```javascript
// Step 1: Embedded data renders IMMEDIATELY (no wait)
window.GALLERY_DATA = {"entries": [...]};  // hardcoded inline

// Step 2: Render from embedded data
var entries = GALLERY_DATA ? GALLERY_DATA.entries : [];

// Step 3: AJAX for live-update (if fails, embedded data already rendered)
fetch('gallery_data.json')
  .then(r => r.json())
  .then(data => {
    GALLERY_DATA = data;
    renderGallery();  // re-render with fresh data
  })
  .catch(() => {});  // silent fail — embedded data already shown
```

## Alternative Fix (what was actually applied)

Used `window.EMBEDDED_GALLERY_DATA` as a separate constant for the embedded data, keeping `GALLERY_DATA` as the live-fetchable data:

```javascript
// Separate embedded data (never overwritten)
window.EMBEDDED_GALLERY_DATA = {...};  // source of truth

// Live fetch (optional update)
fetch('gallery_data.json')
  .then(r => r.json())
  .then(data => {
    GALLERY_DATA = data;
    renderGallery();
  });

// Render from EMBEDDED data immediately
var entries = GALLERY_DATA && GALLERY_DATA.entries.length > 0
    ? GALLERY_DATA.entries
    : EMBEDDED_GALLERY_DATA.entries;
```

## Key Lesson

**Never initialize a data variable as `null` when you have embedded data that should render immediately.** Either:
1. Initialize with embedded data, or
2. Use a separate constant for embedded data

The pattern `var DATA = null; // will be filled later` + immediate `renderGallery()` call guarantees an empty render on first load.

## Verification

```bash
# Check if GitHub Pages serves correct content
curl -s "https://sigco3111.github.io/icbm2-gallery/index.html" | python3 -c "
import sys, re, json
c = sys.stdin.read()
m = re.search(r'GALLERY_DATA\s*=\s*(\{.*?\})\s*;', c, re.DOTALL)
if m:
    d = json.loads(m.group(1))
    print(f'Entries: {len(d[\"entries\"])}')
    for e in d['entries']: print(f'  {e[\"date\"]} {e[\"topic\"][:30]}')
"
```

## Related
- gallery-sync SKILL.md — prevention checklist
- `references/dual-data-source-pattern.md` — theoretical background