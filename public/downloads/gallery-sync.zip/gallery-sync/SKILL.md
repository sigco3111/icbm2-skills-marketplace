---
name: gallery-sync
description: ICBM2 뮤직비디오 갤러리 자동 동기화 — gallery_data.json 변경 시 index.html 내장 데이터 자동 동기화 + 유효성 검증 + Git 푸시
trigger: gallery_data.json 수정 후 index.html 자동 동기화 필요 시
---

## 언제 쓰는가?
gallery_data.json을 수동/자동으로 수정한 후, index.html의 내장 데이터가 항상 동기화된 상태를 유지해야 할 때 실행한다.

## 사용법

```bash
bash ~/.hermes/scripts/gallery_build.sh
```

## 검증 체크리스트

- [ ] `images` 배열이 비어있지 않은지 확인 (비어있으면 에러)
- [ ] `gallery_data.json` JSON 유효성
- [ ] `index.html` 내장 데이터 = `gallery_data.json` 동일성 확인
- [ ] 불일치 시 자동 동기화
- [ ] Git 자동 커밋 & 푸시

## 예방 체크리스트 (갤러리 업데이트 전 반드시 확인)

- [ ] `gallery_data.json`에서 해당 entry의 `images` 배열이 비어있지 않은지 확인
  ```bash
  cat gallery_data.json | python3 -c "
  import json, sys
  data = json.load(sys.stdin)
  for e in data['entries']:
      if not e.get('images'):
          print(f'❌ [{e[\"date\"]}] {e[\"topic\"]} - images 배열 비어있음!')
          sys.exit(1)
  print('✅ 모든 entry에 이미지 있음')
  "
  ```
- [ ] build.sh 실행하여 index.html 동기화
- [ ] Git 푸시 후 GitHub Pages 배포 확인 (1~2분 소요)

## 문제 원인

| 문제 | 원인 |对策 |
|------|------|------|
| 카드에 이미지 없음 | `images: []` 빈 배열 | build 스크립트에서 빈 배열 检测시 에러 |
| 모달에 이미지 안 뜸 | `updateModalImage()`에서 `getImageSrc()` 미호출 | 항상 getImageSrc 거치도록 검증 |
| 내장 데이터陈旧 | index.html 업데이트 누락 | build.sh에서 자동 동기화 |
| **"ICBM2 뮤직비디오 갤러리 × ◀ 이전 다음 ▶" 만 표시** (2026-05-25) | AJAX race condition: `GALLERY_DATA=null` 상태에서 renderGallery 호출, `window.GALLERY_DATA` 하드코딩 데이터가 덮어씌워짐 | `window.EMBEDDED_GALLERY_DATA` 패턴으로 즉시 렌더링 후 AJAX는 선택적 live update만 |
| **家主님이 브라우저에서 직접 업로드 시 갤러리 카드 누락** (2026-05-25) | 스크립트 업로드가 아닌 수동 업로드 → `backup_to_gallery()` 자동 호출 안 됨 |家主님이 Telegram으로 YouTube URL告诉我 → ICBM2가 gallery_data.json 갱신 + git push |
| **`music_video_review.py`에서 `backup_to_gallery()` 호출 시 무시됨** (2026-05-25) | `backup_to_gallery()` 함수를 `import`하지 않아 NameError 발생하지만 스크립트에서 `try/except`로 묶여 조용히 실패 | `music_video_review.py`에 `sys.path.insert`로 `backup_to_gallery` import 추가, `--image-dir` 인자로 이미지 디렉토리 전달 |

## 경고 시스템 (index.html 내장)

`GALLERY_DATA` 로딩 시:
1. `images` 배열이 비어있는 entry 발견 → console.error + 경고 메시지
2. 모달 열 때 `MODAL_IMAGES.length === 0` → 아무 동작 안 함
## 수동 업로드 시 gallery 등록 프로세스 (2026-05-25)

家主님이 브라우저에서 직접 YouTube에 업로드한 경우, `backup_to_gallery()` 자동 호출이 안 됨.

**절대 규칙:**家主님이 브라우저에서 직접 YouTube에 업로드한 경우, 반드시 Telegram으로 YouTube URL을 알려줘야 gallery에 카드 등록 가능.

**ICBM2의 작업:**
1.家主님이 Telegram으로 YouTube URL 전송
2. ICBM2가 `~/.hermes/music_videos/gallery_gh/` repo pull
3. 생성된 이미지 파일 확인 (보통 `images_YYYYMMDD_HHMMSS/` 디렉토리)
4. gallery_data.json 갱신 + index.html 재생성
5. Git push

**핵심:**家主님이 직접 업로드한 YouTube URL을 gallery에 등록하려면 나에게 URL을 알려줘야 함. 자동으로 등록되지는 않음.

## 데이터 흐름

```
gallery_data.json (진실)
    → build.sh가 검증 후 index.html의 EMBEDDED_GALLERY_DATA에 동기화
    → GitHub Pages 배포
    → 브라우저: window.EMBEDDED_GALLERY_DATA로 즉시 렌더링
    → 선택적: gallery_data.json AJAX fetch → live update (실패해도 빈 화면 없음)
```

**핵심教训 (2026-05-25):** 내장 데이터와 AJAX fetch를 동시에 사용时要确保内嵌数据优先. 항상 내장 데이터로 즉시 렌더링하고, AJAX는 선택적 live update로만 사용.

## 관련 참고 자료

- `references/dual-data-source-pattern.md` — dual-data-source 문제의 원인, 해결 흐름, self-healer 오탐 패턴