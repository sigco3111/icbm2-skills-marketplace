# Notion Token Expiry — Failure Mode & Recovery

**Real incident:** Sunday weekly cron, 2026-06-07. Notion API returned
HTTP 401 "API token is invalid" for all 6 prepared weekly entries. The
token file at `~/.hermes/secrets/notion_token.txt` still existed (50
chars, ntn_ prefix valid) but had been revoked/expired server-side.

## Symptoms

- `POST /v1/pages` → 401 unauthorized
- `GET /v1/users/me` → 401 unauthorized
- `GET /v1/databases/{id}/query` → 401 unauthorized

Any of these on a fresh token = the token is dead. File existence +
correct format does not guarantee validity — Notion integrations can be
revoked from the workspace side at any time.

## Detection (preflight)

Before posting N entries, hit a free read endpoint to confirm the
token. The `/v1/users/me` call is the cheapest. Use the
`templates/notion_preflight.py` template — it returns `(ok, message)`
and the weekly script should abort on `not ok` and write a status file
instead.

## Recovery (status file fallback)

When preflight fails:

1. **Do NOT delete the prepared payloads.** Persist them so the next
   run (or manual fix) can replay without rebuilding them.
2. Write `~/.hermes/memory/reports/notion_YYYY-WNN_status.md` with:
   - Failure timestamp
   - Token file path + last-modified time
   - Target DB ID
   - All prepared entries (name, item, value, note) — verbatim
   - Recommended action (token rotation steps)
3. **Emit a Telegram alert** if `TELEGRAM_BOT_TOKEN` is set — silent
   weekly failures compound. A weekly report that quietly drops on
   the floor for 3 weeks before anyone notices is a worse outcome than
   a loud failure on the first week.
4. **Log the failure to the wiki log** (if combined with wiki lint in
   the same cron) so the cross-skill status is preserved.

The status file is the durable artifact — it survives reboots, cron
log rotations, and Telegram outages. Next successful run can re-read
the status file and replay payloads if the user has rotated the token.

## Token rotation (human action)

1. Notion workspace → Settings & Members → Connections (or Integrations)
2. Find the ICBM2 integration, click "..." → Re-issue secret
3. Copy the new secret (starts with `ntn_`)
4. Write to `~/.hermes/secrets/notion_token.txt` (single line, no
   trailing newline beyond standard)
5. Verify: `curl -H "Authorization: Bearer *** < secrets/notion_token.txt)"`
6. **Re-run the weekly report manually** with the now-valid token.
   The status file from step 2 still has the prepared payloads.

## Why api-key-manager alone didn't catch it

The `api-key-manager` skill tracks `*_expiry_YYYYMMDD.txt` filenames
where the expiry is **known upfront**. Notion integration tokens do
not declare an expiry in their payload — they expire silently when
the integration is revoked or the workspace owner changes. There is
no "Notion token expires on 2026-12-31" file you can write. The
defense is **periodic liveness probing** (the preflight pattern), not
date tracking. This is a real gap in api-key-manager for integrations
without a published expiry date.

## Related

- `templates/notion_preflight.py` — copy-paste preflight check
- `scripts/post_weekly_entries.py` — main posting loop with fallback
- `~/.hermes/memory/reports/notion_2026-W23_status.md` — example
  status file from the 2026-06-07 incident
