# Notion POST via `urllib.request` — Shell-Quote-Hazard-Free Template

**Why this exists:** On 2026-06-14 the bundled `scripts/post_weekly_entries.py` would
have worked, but my ad-hoc curl invocations failed repeatedly because the
shell-quoted `*** ` token in `-H "Authorization: Bearer *** tripped the terminal's
own masking layer and produced `unexpected EOF while looking for matching "'` errors.
Switching to Python's `urllib.request` made the POST call work on the first
attempt — no shell quoting at all.

## Use this when

- You're posting from a one-off Python session, a script, or a cron run
- The shell you're invoking from is unreliable with quoted tokens
- You want status code handling in Python (cleaner than parsing `curl` stdout)
- `subprocess.run(["curl", ...])` is failing or feels fragile

## Drop-in template

```python
import os, json, urllib.request, urllib.error, time

TK = open(os.path.expanduser("~/.hermes/secrets/notion_token.txt")).read().strip()
DB = "33c76f2e-9097-81be-9ea4-cefd03512e81"  # Weekly Report

ENTRIES = [
    {
        "name": "2026-W24 Tistory Blog",
        "week": "2026-W24",
        "item": "Tistory",
        "value": 78,
        "note": "주간 누적 78건 발행 (전주 W23 57건 대비 +37%).",
    },
    # ... up to 6
]

def post(entry):
    payload = {
        "parent": {"database_id": DB},
        "properties": {
            "Name":  {"title":     [{"text": {"content": entry["name"]}}]},
            "Week":  {"rich_text": [{"text": {"content": entry["week"]}}]},
            "Item":  {"select":    {"name": entry["item"]}},
            "Value": {"number":    entry["value"]},
            "Note":  {"rich_text": [{"text": {"content": entry["note"]}}]},
        },
    }
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        "https://api.notion.com/v1/pages",
        data=data,
        method="POST",
        headers={
            "Authorization": f"Bearer {TK}",
            "Notion-Version": "2022-06-28",
            "Content-Type": "application/json",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read())

success = 0
for e in ENTRIES:
    code, body = post(e)
    page_id = body.get("id", "—") if code == 200 else "—"
    err = body.get("message", "") if code != 200 else ""
    print(f"  HTTP {code} | {e['item']:8} | val={e['value']:>3} | {page_id}{'  ERR: '+err if err else ''}")
    if code == 200:
        success += 1
    time.sleep(0.4)  # polite — Notion is rate-limited per integration

print(f"\n{success}/{len(ENTRIES)} entries posted")
```

## Schema check before posting (also via `urllib`)

```python
import urllib.request, json
req = urllib.request.Request(
    "https://api.notion.com/v1/databases/33c76f2e-9097-81be-9ea4-cefd03512e81",
    headers={"Authorization": f"Bearer {TK}", "Notion-Version": "2022-06-28"},
)
with urllib.request.urlopen(req, timeout=10) as r:
    schema = json.loads(r.read())
for name, prop in schema["properties"].items():
    opts = ""
    if prop["type"] == "select":
        opts = " | options: " + ", ".join(o["name"] for o in prop["select"]["options"])
    print(f"  {name}: {prop['type']}{opts}")
```

## Status-file fallback (one-liner)

```python
import os
status_dir = os.path.expanduser("~/.hermes/memory/reports")
os.makedirs(status_dir, exist_ok=True)
path = os.path.join(status_dir, f"notion_{WEEK}_status.md")
with open(path, "w") as f:
    f.write(f"# Notion Weekly {WEEK} (FAILED)\n\n")
    f.write(f"Posted: {success}/{len(ENTRIES)}\n\n")
    for r, e in zip(results, ENTRIES):
        if r["code"] != 200:
            f.write(f"## {e['name']}\n```json\n{json.dumps(e, ensure_ascii=False, indent=2)}\n```\n")
print(f"Status file: {path}")
```

## Why not just use `subprocess.run(["curl", ...])`?

- Works fine when you've validated the file by hand.
- Fails silently (returns 401 with no helpful error) if the f-string token
  interpolation has a quote/escape bug — `f"Authorization: Bearer *** + tk,` (note the
  `+` and missing `"`) is a single-character bug that's hard to spot.
- The skill's bundled `post_weekly_entries.py` uses this pattern and works
  in practice, but for one-off debugging sessions `urllib.request` gives
  you a Python stack trace instead of a `curl` exit code + raw HTML.

## Verified

- 2026-06-14: 6/6 weekly entries posted to `Weekly Report` DB on first try
  with this template. Token rotation: tested via `/v1/users/me` first
  (also `urllib`), confirmed HTTP 200, then proceeded to POSTs.
