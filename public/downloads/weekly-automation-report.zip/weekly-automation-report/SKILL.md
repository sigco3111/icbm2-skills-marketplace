---
name: weekly-automation-report
description: 자동화 성과 주간 리포트를 Notion에 기록 — Tistory, 크론 잡 상태 종합
version: 1.0.0
author: icbm2
metadata:
  hermes:
    tags: [Automation, Report, Notion, Weekly]
prerequisites: []
---

# 자동화 성과 주간 리포트

매주 일요일에 자동화 성과를 종합 분석하여 Notion DB에 기록합니다.

## Notion DB

- **DB ID:** `33c76f2e-9097-81be-9ea4-cefd03512e81`
- **DB명:** Weekly Report
- **속성:** Name(title), Week(rich_text), Item(select), Value(number), Note(rich_text)
- **Item 옵션:** Idea Note, Ship or Slop, BotMadang, Tistory, Cron, Other

## 실행 단계

### 1. 데이터 수집

크론 잡 실행 로그와 메모리에서 주간 성과 수집:

```bash
# Tistory: 발행된 글 수 확인
# 크론 잡: 전체 크론 잡 상태 및 에러 수
```

### 2. Notion에 기록

각 항목별로 한 줄씩 DB에 페이지 생성:

```python
import os, json, subprocess
from datetime import datetime, timezone, timedelta

TK_PATH = os.environ["NOTION_TOKEN_PATH"]
DB_ID = "33c76f2e-9097-81be-9ea4-cefd03512e81"

with open(TK_PATH) as f:
    tk = f.read().strip()

payload = {
    "parent": {"database_id": DB_ID},
    "properties": {
        "Name": {"title": [{"text": {"content": "2026-W15 Idea Note"}}]},
        "Week": {"rich_text": [{"text": {"content": "2026-W15"}}]},
        "Item": {"select": {"name": "Idea Note"}},
        "Value": {"number": 168},
        "Note": {"rich_text": [{"text": {"content": "전주 대비 +12"}}]}
    }
}
with open("/tmp/notion_entry.json", "w") as f:
    json.dump(payload, f, ensure_ascii=False)

env = dict(os.environ)
env["NTK"] = tk
r = subprocess.run(
    f'curl -s -X POST --max-time 15 https://api.notion.com/v1/pages -H "Authorization: Bearer $NTK" -H "Notion-Version: 2022-06-28" -H "Content-Type: application/json" -d @/tmp/notion_entry.json',
    shell=True, capture_output=True, text=True, env=env
)
```

### 3. 품질 기준

- 다음 항목을 반드시 포함:
  1. Tistory 발행 수
  2. 크론 잡 정상 동작率
- 전주 대비 변화를 Note에 기록
- 특이사항(에러, 중단 등)이 있으면 Other 항목으로 추가

### 4. 완료 확인

주간 요약 테이블을 출력.
