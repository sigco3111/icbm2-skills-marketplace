---
name: weekly-automation-report
description: 자동화 성과 주간 리포트를 Notion에 기록 — Tistory, 크론 잡 상태 종합
version: 1.2.0
author: icbm2
metadata:
  hermes:
    tags: [Automation, Report, Notion, Weekly]
prerequisites: []
---

# 자동화 성과 주간 리포트

매주 일요일에 자동화 성과를 종합 분석하여 Notion DB에 기록합니다.

## Notion DB

- **DB ID:** `33c76f2e-9097-81be-9ea4-cefd03512e81`
- **DB명:** Weekly Report
- **속성:** Name(title), Week(rich_text), Item(select), Value(number), Note(rich_text)
- **Item 옵션:** Tistory, Cron, Other
  - ⚠️ Idea Note / Ship or Slop / BotMadang은 이미 비활성화됨 — 기록 금지

## 실행 단계

### 0단계: Notion 토큰 사전 검증 (필수)

**2026-06-07 incident:** Sunday weekly cron이 6개 항목 모두 Notion DB 기록에 실패. `secrets/notion_token.txt`는 존재했지만 Notion 통합이 해지/만료되어 HTTP 401. **이전 단계가 성공하는 것처럼 보였지만 모든 기록이 silently dropped** — 다음 주에야 발견됨.

**이제 매주 실행 시 사전 검증 필수:**

```bash
# 1) 토큰 파일 존재 + 형식 확인
test -s ~/.hermes/secrets/notion_token.txt || { echo "FAIL: token file missing"; exit 1; }

# 2) /v1/users/me로 실제 인증 확인
TK=$(cat ~/.hermes/secrets/notion_token.txt | tr -d '\n')
curl -s --max-time 10 https://api.notion.com/v1/users/me \
  -H "Authorization: Bearer *** -H "Notion-Version: 2022-06-28" | grep -q '"object": "user"' \
  || { echo "FAIL: token not authorized"; exit 1; }
```

**⚠️ Shell-curl 방식의 함정 (2026-06-14 확인):** `*** ` 마스킹이
터미널에 들어가는 도구(예: Hermes 자체 로깅)와 마주치면 셸 quote가
깨져서 `unexpected EOF` 오류 연발. 1차 preflight는 위 curl로
가볍게 통과시키되, **POST 단계는 Python `urllib.request`로 가는
것이 견고** — `references/notion-posting-urllib-fallback.md` 참조.
번들된 `templates/notion_preflight.py`는 Python으로 짜여 있어
이 문제가 없음 — 가능하면 그것을 우선 사용.

자세한 패턴은 `templates/notion_preflight.py` 참조. 검증 실패 시 → 1단계로 진행하지 말고 **상태 파일 fallback**으로 직행 (아래 §5).

### 1단계: 데이터 수집

크론 잡 실행 로그와 메모리에서 주간 성과 수집. 정적 스크립트 사용:

```bash
# 스크립트는 SKILL 내부에 번들되어 있음 — 절대 경로로 호출
SKILL_DIR=~/.hermes/skills/automation/weekly-automation-report
bash "$SKILL_DIR/scripts/tistory_publish_count.sh" 2026 23
python3 "$SKILL_DIR/scripts/cron_weekly_summary.py" 2026 23
```

**`scripts/...` 같은 상대 경로는 cwd에 따라 깨짐** — cron 컨텍스트에선 항상
절대 경로로 호출할 것. (Pitfalls §"script-location" 참조.)
(두 스크립트 모두 `scripts/` 디렉토리. cron 모드에서 `execute_code`가 차단되므로 반드시 정적 스크립트화할 것 — Pitfalls 참조.)

### 2단계: 엔트리 구성

최소 6개 항목 (Tistory 2건: 일반+뉴스레터, Cron 2건: 성공률+실패, Other 2건: Wiki 페이지 수 + 브로큰 링크). 각 항목은 dict:

```python
{
  "name":   "2026-W23 Tistory Blog",     # Name (title)
  "week":   "2026-W23",                  # Week
  "item":   "Tistory",                   # Item select
  "value":  57,                          # Value number
  "note":   "6/2 2건, 6/3-6/6 각 12건, 6/7 7건"  # Note
}
```

### 3단계: Notion에 기록

**권장: `scripts/post_weekly_entries.py` 사용** (preflight + status-file fallback 내장). 한 줄 호출:

```bash
# ENTRIES 리스트 채운 후
SKILL_DIR=~/.hermes/skills/automation/weekly-automation-report
python3 "$SKILL_DIR/scripts/post_weekly_entries.py"
```

스크립트가 자동으로:
- §0의 preflight 수행 (`templates/notion_preflight.py` 임포트)
- 성공 시 6개 항목 POST
- 실패 시 `~/.hermes/memory/reports/notion_WNN_status.md`에 페이로드 보존

수동 호출 (legacy, 권장 안 함) — `subprocess.run(["curl", ...])` 대신
**`urllib.request` 직접 호출이 견고** (셸 quote hazard 회피). 템플릿은
`references/notion-posting-urllib-fallback.md` 참조.

### 4단계: 품질 기준

- 다음 항목을 반드시 포함:
  1. Tistory 발행 수
  2. 크론 잡 정상 동작율
- 전주 대비 변화를 Note에 기록
- 특이사항(에러, 중단 등)이 있으면 Other 항목으로 추가
- Idea Note / Ship or Slop / BotMadang은 **기록하지 않음** (이미 비활성화된 자동화)

### 5단계: Status File Fallback (Notion 인증 실패 시)

**모든 항목 게시 실패 → silent drop 절대 금지.** `scripts/post_weekly_entries.py`가 자동으로:

1. `~/.hermes/memory/reports/notion_YYYY-WNN_status.md` 작성
   - 실패 시각, 토큰 파일, 타겟 DB
   - 6개 항목의 **전체 페이로드** (name/item/value/week/note verbatim)
   - 토큰 rotation 복구 단계
2. Telegram 알림 (가능 시) — `api-key-manager` 패턴 사용
3. 위키 log.md에도 기록 (composite cron의 경우)

**상태 파일은 다음 주에 토큰 갱신 후 재실행 시 replay 가능** — 페이로드를 다시 빌드할 필요 없음.

자세한 사례: `references/notion-token-expiry.md`.

### 6단계: 완료 확인

주간 요약 테이블을 출력. Notion 기록 성공/실패, 로컬 리포트 파일 경로, 상태 파일 경로(실패 시) 모두 명시.

## Pitfalls

- **`execute_code`는 cron 컨텍스트에서 차단됨** (2026-06-07 확인). Python 데이터 처리는 `write_file` + `terminal` 패턴 또는 정적 스크립트화. 인라인 Python이 필요한 단계는 모두 `scripts/`에 모듈로 분리.
- **`echo | python3` 같은 pipe-to-interpreter 패턴도 보안 가드(Tirith)에 의해 차단됨** (2026-06-07 확인). heredoc, write_file-then-exec, 또는 정적 스크립트 호출 사용.
- **Notion 토큰은 silent expire** — `secrets/notion_token.txt` 파일이 존재하고 형식이 맞아도 통합이 workspace에서 해지되면 401. 매 실행 시 preflight로 `/v1/users/me` probe 필수. 6주 연속 silent failure가 가장 위험 (2026-06-07 incident).
- **Notion Integration Token은 알려진 만료일이 없음** — `api-key-manager`의 `*_expiry_YYYYMMDD.txt` 패턴으로 추적 불가. liveness probing으로만 방어.
- **status file fallback은 옵션이 아니라 필수** — silent drop은 다음 주 발견 = 1주 데이터 손실. 매 실패 시 status 파일 + 텔레그램 알림.
- **Tistory 카운트는 `b1bca63a117a` cron 잡 기준** — 다른 잡은 발행 여부 마커가 다를 수 있음. `scripts/tistory_publish_count.sh`는 이 잡에 하드코딩됨; 다른 잡이 발행 잡이라면 마커 정규식 수정 필요.
- **weekly_report.py는 Tistory 발행 수를 직접 집계하지 않음** — `scripts/tistory_publish_count.sh` + `scripts/cron_weekly_summary.py`로 별도 산출 후 합산.
- **weekly_report.py 출력은 사람이 읽기 좋은 텍스트, Notion DB는 구조화** — 같은 데이터를 두 형식으로 각각 준비해야 함 (중복 작업이지만 의도된 분리).
- **skill-bundled scripts는 `~/.hermes/skills/<skill>/scripts/`에 있음** (2026-06-14 확인). `~/.hermes/scripts/`는 일반 스크립트 디렉토리라 skill-bundled scripts가 거기 있다고 가정하면 안 됨. cron/원라인 호출에선 반드시 `SKILL_DIR` 절대 경로로 호출. 또는 `skill_manage`로 skill을 `~/.hermes/skills/`에 두고 `python3 -m` 스타일로 import.
- **셸 heredoc/quote 내 토큰 마스킹 hazard** (2026-06-14 확인). `*** ` 문자열을 `-H "Authorization: Bearer ***` 같은 곳에 끼워 curl을 호출하면, 도구/터미널의 다른 마스킹 로직이 `*** `를 단어 경계로 잘못 처리해 `unexpected EOF while looking for matching "'` 오류가 연발. **해결:** Python `urllib.request`로 POST 자체를 보내면 셸 quote가 통째로 우회됨. 자세한 패턴: `references/notion-posting-urllib-fallback.md`.
- **Python `subprocess.run(["curl", ...])` 안에서도 f-string `+ tk,` 같은 표기 버그** (2026-06-14 file review). `f"...{tk}"`로 닫는 따옴표와 `,`가 정확히 매치되는지 read-back으로 확인할 것. f-string + 토큰 삽입은 한 글자만 잘못되어도 401로 떨어지고 root cause가 안 보임.
- **`scripts/tistory_publish_count.sh` TOTAL 0 false-negative** (2026-07-12 검증). 번들 스크립트는 `set -euo pipefail` + `xargs grep | wc -l` 조합인데, cron 컨텍스트에서 `set -e` + 빈 xargs 입력은 파이프라인을 `0` 카운트로 빠르게 종료시키면서 정상 종료. **스크립트 출력 TOTAL이 0이면 false-negative 의심** — 직접 검증하라:
  ```bash
  ls -1 ~/.hermes/cron/output/b1bca63a117a/YYYY-MM-DD_*.md \
    | xargs -I{} grep -l "발행 완료\|발행 성공" {} 2>/dev/null \
    | wc -l
  ```
  검증 결과 W28에서 42건 실제 파일 vs 스크립트 TOTAL 0 = false-negative. 2026-07-12 일요일 점검에서 수동 카운트로 5건(#218 #220 #222 #224 #229) 확정. **하드 룰:** 스크립트 TOTAL이 0이면 stop하고 직접 카운트 후 fallback 숫자로 보고. FIX 권고: 스크립트에서 `set -e` 제거 + `|| true`로 감싸거나 `xargs -r` 명시.
- **`cron_weekly_summary.py` vs `~/.hermes/scripts/weekly_report.py` 카운트 불일치** (2026-07-12 검증). 같은 W28이라도 두 스크립트가 다른 success count (145 vs 143, 17개 잡 동일하지만 success 분류 기준 차이). **Notion 기록은 `cron_weekly_summary.py` (145/2/98.6%) 사용**, weekly_report.py 텍스트 리포트는 별도 산출물. 두 결과를 무비교 합치면 합성 오류. Notion 기록 직전에 두 스크립트를 둘 다 돌려 1줄 비교 후 큰 쪽 선택할 것.
- **`scripts/post_weekly_entries.py`가 cron에서 자동 호출되지 않음** (2026-07-12 검증). 일요일 점검 cron(d7bd4309bbf0)은 skill을 로드하지만 정적 스크립트 자동 실행은 안 함 — agent가 §3 한 줄 명령을 수동 호출 필요. 호출 잊으면 silent 0건. FIX 권고: preflight + `entries.length` 체크를 묶어서 빈 entries면 즉시 fail.
- **Sunday composite cron(d7bd4309bbf0) — wiki lint → weekly_report → Notion 3-phase 워크플로 정형화** (2026-07-12 검증). §1 wiki lint 시 Obsidian Vault wiki가 `~/wiki/SCHEMA.md`로 떨어지지 않을 수 있으니 `find ~ -maxdepth 4 -type d -name wiki`로 경로 탐색 먼저. §2 weekly_report.py는 텍스트/사람용, §3 Notion은 별도 빌드(최소 7개 항목: Tistory×2 + Cron×2 + Other×3 = wiki-페이지수 + wiki-브로큰 + wiki-고아). **Other 슬롯에 자연스럽게 lint 결과를 흘려보낸다** — 이게 두 skill(`llm-wiki` §3 + `weekly-automation-report` §3) 결합 지점. Notion preflight 통과 후 `urllib.request`로 POST → status-file fallback은 safe-area, 모두 성공 시 status-file 불필요. **이 3-phase는 매주 반복이므로 §3 시작에 "Sunday composite cron: 3-phase 전부 실행" 헤더 권장** (현재 본문 §3-§4에 흩어져 있음, 다음 major version에서 구조화 가치).

## Support Files

- `templates/notion_preflight.py` — Notion 토큰 liveness probe (모든 Notion-writing 스킬에서 복사해 사용)
- `scripts/post_weekly_entries.py` — main posting loop (preflight + status-file fallback 내장)
- `scripts/tistory_publish_count.sh` — ISO 주차별 Tistory 발행 횟수 집계
- `scripts/cron_weekly_summary.py` — ISO 주차별 크론 잡 성공/실패 집계
- `references/notion-token-expiry.md` — 2026-06-07 incident 기록 + 복구 패턴
- `references/notion-posting-urllib-fallback.md` — 셸 quote hazard 회피용 `urllib.request` 기반 POST 템플릿 (2026-06-14 검증)
- `references/sunday-composite-cron-workflow.md` — 일요일 종합 점검 3-phase(lint → weekly_report → Notion) 풀 워크플로 + 정적 wiki_lint.py 템플릿 (2026-07-12 검증)
