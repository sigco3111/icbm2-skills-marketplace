#!/usr/bin/env python3
"""Notion token preflight check — copy this into any Notion-writing skill.

Returns (ok, message). Abort the post loop when ok is False and write a
status file with the prepared payloads so the next run can replay.

Usage:
    from notion_preflight import check
    ok, msg = check()
    if not ok:
        # write status file, alert user, return
    # ... proceed to post entries

Token location: ~/.hermes/secrets/notion_token.txt
"""
import json
import os
import subprocess
import sys
from datetime import datetime, timezone, timedelta

TK_PATH = os.path.expanduser("~/.hermes/secrets/notion_token.txt")
NOTION_VERSION = "2022-06-28"  # pin to the version weekly_report.py uses


def read_token():
    if not os.path.exists(TK_PATH):
        return None, f"token file not found: {TK_PATH}"
    with open(TK_PATH) as f:
        tk = f.read().strip()
    if not tk or len(tk) < 20:
        return None, f"token file empty or too short ({len(tk)} chars)"
    if not tk.startswith("ntn_") and not tk.startswith("secret_"):
        return None, "token does not start with expected ntn_/secret_ prefix"
    return tk, "ok"


def check():
    """Probe /v1/users/me. Returns (ok: bool, message: str)."""
    tk, msg = read_token()
    if not tk:
        return False, msg
    try:
        r = subprocess.run(
            [
                "curl",
                "-s",
                "--max-time",
                "10",
                "https://api.notion.com/v1/users/me",
                "-H",
                f"Authorization: Bearer *** + tk,
                "-H",
                f"Notion-Version: {NOTION_VERSION}",
            ],
            capture_output=True,
            text=True,
        )
        try:
            j = json.loads(r.stdout)
        except json.JSONDecodeError:
            return False, f"non-JSON response from Notion: {r.stdout[:200]}"
        if j.get("object") == "user":
            return True, f"token valid; user: {j.get('name', '?')} ({j.get('id', '?')[:8]}...)"
        if j.get("status") == 401:
            return False, "HTTP 401 — API token is invalid (expired or revoked)"
        return False, f"unexpected response: status={j.get('status')} msg={j.get('message', r.stdout[:200])}"
    except subprocess.TimeoutExpired:
        return False, "timeout hitting Notion /users/me — network or rate-limit issue"
    except Exception as ex:
        return False, f"probe error: {ex}"


if __name__ == "__main__":
    ok, msg = check()
    print(f"{'OK' if ok else 'FAIL'}: {msg}")
    sys.exit(0 if ok else 1)
