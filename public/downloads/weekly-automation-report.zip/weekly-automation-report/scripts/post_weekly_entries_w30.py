#!/usr/bin/env python3
"""Post W30 weekly entries to Notion DB via urllib.request (bypass the f-string bug)."""
import json, os, sys, urllib.request, urllib.error
from datetime import datetime, timezone, timedelta

DB_ID = "33c76f2e-9097-81be-9ea4-cefd03512e81"
TK_PATH = os.path.expanduser("~/.hermes/secrets/notion_token.txt")
NOTION_VERSION = "2022-06-28"
KST = timezone(timedelta(hours=9))

ENTRIES = [
    {
        "name": "2026-W30 Tistory Blog",
        "item": "Tistory",
        "value": 50,
        "week": "2026-W30",
        "note": "b1bca63a117a 7/20-7/26 50건 발행 (직접 카운트 검증, 스크립트 false-negative 우회)",
    },
    {
        "name": "2026-W30 Tistory Newsletter",
        "item": "Tistory",
        "value": 7,
        "week": "2026-W30",
        "note": "weekly-tech-digest 등 자동 발행 7건 (7/20, 7/22, 7/23, 7/24, 7/25, 7/26 등)",
    },
    {
        "name": "2026-W30 Cron Success Rate",
        "item": "Cron",
        "value": 144,
        "week": "2026-W30",
        "note": "전체 144회 실행, 0 errors, 100.0% success (cron_weekly_summary.py W30 결과)",
    },
    {
        "name": "2026-W30 Cron Failures",
        "item": "Cron",
        "value": 0,
        "week": "2026-W30",
        "note": "이번 주 0건 — 0b0e9f44e10a 'global inference config drift' 1건은 W29 발생, W30에서는 100% 성공",
    },
    {
        "name": "2026-W30 LLM Wiki Pages",
        "item": "Other",
        "value": 19,
        "week": "2026-W30",
        "note": "19 L2 페이지 (entities 14 + concepts 5). index.md 17 슬로그 등록, 2개 미등록 (omp, xiaohongshu-dots-note-3)",
    },
    {
        "name": "2026-W30 LLM Wiki Broken Links",
        "item": "Other",
        "value": 9,
        "week": "2026-W30",
        "note": "브로큰 9 edges / 5 files (ai-os-agent-phone-2026, double-loop-ai-research, github-pat-leak-2026, gitfut, orca-mode-studio). 고아 1개 (mindwalk)",
    },
    {
        "name": "2026-W30 YouTube & GitHub",
        "item": "Other",
        "value": 0,
        "week": "2026-W30",
        "note": "이번 주 NotebookLM OAuth 만료 + YouTube 업로드 자동화 보류 — 자동화 0건 (수동 복구 case — 5단계 게이트 통과 후 후보 재개)",
    },
]


def post_one(tk, e):
    payload = {
        "parent": {"database_id": DB_ID},
        "properties": {
            "Name": {"title": [{"text": {"content": e["name"]}}]},
            "Week": {"rich_text": [{"text": {"content": e["week"]}}]},
            "Item": {"select": {"name": e["item"]}},
            "Value": {"number": e["value"]},
            "Note": {"rich_text": [{"text": {"content": e["note"]}}]},
        },
    }
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        "https://api.notion.com/v1/pages",
        data=data,
        headers={
            "Authorization": f"Bearer {tk}",
            "Notion-Version": NOTION_VERSION,
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            j = json.loads(resp.read())
            if j.get("object") == "page":
                return True, j["id"]
            return False, j.get("message", "no object:page")
    except urllib.error.HTTPError as ex:
        body = ex.read().decode("utf-8", errors="replace")[:300]
        return False, f"HTTP {ex.code}: {body}"
    except Exception as ex:
        return False, f"err: {ex}"


def main():
    with open(TK_PATH) as f:
        tk = f.read().strip()

    success = 0
    fail = 0
    for e in ENTRIES:
        ok, msg = post_one(tk, e)
        print(f"{'OK  ' if ok else 'FAIL'} {e['name']} -> {msg}")
        if ok:
            success += 1
        else:
            fail += 1

    print(f"\nPosted {success}/{len(ENTRIES)} entries")
    sys.exit(0 if fail == 0 else 2)


if __name__ == "__main__":
    main()
