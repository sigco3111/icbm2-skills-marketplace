#!/usr/bin/env bash
# Count Tistory publish events for a given ISO week from cron output dirs.
# Usage: bash scripts/tistory_publish_count.sh <year> <iso_week>
# Example: bash scripts/tistory_publish_count.sh 2026 23
#   -> prints per-day breakdown + total
#
# Cron output dir convention: ~/.hermes/cron/output/<job_id>/YYYY-MM-DD_HH-MM-SS.md
# The b1bca63a117a job is the Tistory publisher.

set -euo pipefail
YEAR="${1:-}"
WEEK="${2:-}"
if [[ -z "$YEAR" || -z "$WEEK" ]]; then
  echo "usage: $0 <year> <iso_week>" >&2
  exit 1
fi

CRON_OUT="${HOME}/.hermes/cron/output"
TISTORY_JOB="b1bca63a117a"

# ISO week -> date range (Mon..Sun)
WEEK_START=$(python3 -c "import datetime; d=datetime.date.fromisocalendar($YEAR,$WEEK,1); print(d.isoformat())")
WEEK_END=$(python3 -c "import datetime; d=datetime.date.fromisocalendar($YEAR,$WEEK,7); print(d.isoformat())")

echo "Tistory publish count for ISO $YEAR-W$(printf '%02d' $WEEK) ($WEEK_START .. $WEEK_END)"
echo "---"

TOTAL=0
for d in $(python3 -c "
from datetime import date, timedelta
s = date.fromisoformat('$WEEK_START')
e = date.fromisoformat('$WEEK_END')
d = s
while d <= e:
    print(d.isoformat())
    d += timedelta(days=1)
"); do
  count=$(ls -1 "$CRON_OUT/$TISTORY_JOB/${d}_"*.md 2>/dev/null \
    | xargs -I{} grep -l "발행 완료\|발행 성공" {} 2>/dev/null \
    | wc -l | tr -d ' ')
  printf "%s: %s\n" "$d" "$count"
  TOTAL=$((TOTAL + count))
done

echo "---"
echo "TOTAL: $TOTAL"
