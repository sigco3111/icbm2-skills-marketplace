#家主님 공식 이미지 선호: 2D/Cartoon/Kawaii (2026-05-26)

##家主님 직접 피드백 (2026-05-26)
"이미지가 영 별로네... 앞으로 뮤직비디오 생성시 포토리얼리즘으로 하지말고 **2D, cartoon, kawaii 이미지로 생성**해줘."
→家主님이 포토리얼리즘 폐지를 직접 지시 → **이후 모든 뮤직비디오의 기본 이미지 스타일은 2D/Cartoon/Kawaii**

## 검증된 Working 이미지 프롬프트 3종 (2026-05-26)

### 이미지 1 — 직장인 파티/축하 장면
```
Cute kawaii chibi cartoon character with big sparkly eyes wearing office clothes and holding a coffee cup, cheerful office party scene with colorful confetti and sparkles, adorable chibi style illustration, pastel bright colors, clean vector art style, playful and fun atmosphere, no men only girls
```
**생성:** `mmx image "..." --seed 101 -o img0.png && mv image_001.jpg img0.png`

### 이미지 2 — 무대에서 노래하는 여성 가수
```
Cute chibi anime female vocalist with long flowing hair singing on a bright cheerful stage, wearing colorful party outfit with sequins, holding microphone joyfully, cute kawaii cartoon style, pastel rainbow colors, clean vector illustration, energetic pop concert scene with floating hearts and stars
```
**생성:** `mmx image "..." --seed 201 -o img1.png && mv image_001.jpg img1.png`

### 이미지 3 — 카페에서 친구들会和
```
Cute kawaii illustration of happy young women friends hanging out at a cozy cafe, drinking lattes and laughing together, chibi cartoon style with rosy cheeks, pastel warm colors, sparkly eyes, clean vector art, cheerful friendship vibes, bright sunny window background, adorable anime style characters
```
**생성:** `mmx image "..." --seed 301 -o img2.png && mv image_001.jpg img2.png`

##家主님 공식 음악 스타일 (2026-05-26家主님 직접 선택)
```
K-pop, powerful Korean female vocal, upbeat pop-rock, fast tempo, energetic band sound, electric guitar, hopeful and exciting anime opening style, driving bass, catchy chorus
```

##家主님 공식 가사 톤 (2026-05-26家主님 직접 지시)
"AI한테 자리 내준 직장인에게 희망차고 신나는 멜로디로 재치있게 위로하는 느낌으로"
