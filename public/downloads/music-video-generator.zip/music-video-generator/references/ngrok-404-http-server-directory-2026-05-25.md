# ngrok 검수 링크 404 오류 — HTTP 서버 디렉토리 문제 (2026-05-25)

## 문제现象

ngrok URL 생성 후 외부에서 접근 시 `404 File Not Found` 오류 발생.

```
Error response
Error code: 404
Message: File not found.
Error code explanation: HTTPStatus.NOT_FOUND - Nothing matches the given URI.
```

## 원인

`python3 -m http.server 8765`를 홈 디렉토리(~/)에서 실행하면 HTTP 서버가 `~/.hermes/` 등을 خدمة함.
ngrok은 `localhost:8765`를 프록시하지만 요청 경로의 파일이 `~/.hermes/`에 없음.

```bash
# ❌ 잘못된 방식: 홈 디렉토리에서 실행
cd ~  # 또는 workdir 미지정
/usr/bin/python3 -m http.server 8765  # → ~/.hermes/ 서빙

# ✅ 올바른 방식: 영상 디렉토리에서 실행
cd /tmp/qooqoo_mv
/usr/bin/python3 -m http.server 8766  # → /tmp/qooqoo_mv/ 서빙
```

## 검증된Working 순서 (2026-05-25)

```bash
# Step 1: 기존 프로세스 전체 정리
pkill -f "ngrok http" 2>/dev/null
pkill -f "python.*http.server" 2>/dev/null
sleep 2

# Step 2: 새 포트 사용 (8766) — 기존 포트(8765)와 충돌 방지
cd /target/video/directory
/usr/bin/python3 -m http.server 8766 &
sleep 2

# Step 3: ngrok tunnel 시작 (--pooling-enabled로 중복 허용)
ngrok http 8766 --pooling-enabled &
sleep 8

# Step 4: URL 확인
curl -s http://localhost:4040/api/tunnels | /usr/bin/python3 -c \
  "import sys,json; d=json.load(sys.stdin); [print(t['public_url']) for t in d.get('tunnels',[])]"

# Step 5: 파일 접근 검증
curl -sI http://localhost:8766/video_wave.mp4 | head -3
# → HTTP/1.0 200 OK 확인
```

## ngrok 프로세스 정리 체크리스트

| 항목 | 확인 방법 |
|------|---------|
| HTTP 서버 디렉토리 | `curl http://localhost:PORT/` → 원본 디렉토리 목록 확인 |
| 포트 점유 | `lsof -i :PORT` → PID 확인 |
| ngrok 프로세스 | `ps aux \| grep ngrok \| grep -v grep` |
| 파일 접근 가능 | `curl -sI http://localhost:PORT/filename.mp4 \| head -3` |

## 포트 선택 규칙

- 첫 시도: 8765
- 재시도 시: 8766, 8767, 8768 등 (점유 시 다음 번호)
- 포트 점유 시 `pkill -f "python.*http.server.${PORT}"` 후 재시작

## Python subprocess.Popen cwd 지정

```python
# ✅ 올바른 방식: cwd로 디렉토리 지정
http_proc = subprocess.Popen(
    ["/usr/bin/python3", "-m", "http.server", str(port)],
    cwd=video_dir,  # ← 필수!
    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
)

# ❌ 잘못된 방식: cwd 미지정 (홈 디렉토리에서 실행됨)
http_proc = subprocess.Popen(
    ["/usr/bin/python3", "-m", "http.server", str(port)],
    # cwd 없이 실행 → ~/.hermes/ 서빙
)
```

## 관련 증상

- `curl -s http://localhost:8765/` → `Directory listing for /` + `.git/`, `AGENTS.md` 등 표시 → 홈 디렉토리임
- 외부 ngrok URL로 접근 시 404 → 파일이 홈 디렉토리에 없음
- 로컬에서는 `curl -s http://localhost:8765/video_wave.mp4` → 200 OK (로컬 파일 시스템은 동일하므로 동작)

## ngrok URL Stale Tunnel 문제 (2026-05-26 추가)

**심각한 함정:** ngrok subprocess stdout에 "https://xxx.ngrok-free.dev" URL이 표시되지만, 실제 tunnel이 이전 session의 endpoint를 가리키는 경우.

**증상:**
```bash
# ngrok은 연결 successful이라고 출력
ngrok http 8767
# Forwarding  https://require-entangled-primer.ngrok-free.dev

# 하지만 외부에서 404
curl -s -I "https://require-entangled-primer.ngrok-free.dev/video_final.mp4"
# → HTTP/2 404
```

**원인:** ngrok 무료 계정이 동일한 endpoint에 복수 터널 동시 실행 불가. 새 포트(8767)에 연결해도 같은 endpoint 사용 시도 → 기존死了 tunnel override. 하지만 ngrok.stdout에는 새 URL이 표시되지 않음.

**실제 원인 확인:**
```bash
ps aux | grep ngrok | grep -v grep
# → 이미 실행 중인 ngrok 프로세스 발견 (다른 session의 것)

# ngrok API로 현재 tunnel 상태 확인
curl -s http://localhost:4040/api/tunnels
# → {"tunnels": [...]} 목록에서 public_url 확인
```

**해결:**
```bash
# 전체 ngrok 프로세스 강제 종료 + 새 포트 사용
pkill -9 -f "ngrok" 2>/dev/null; sleep 2
cd ~/.hermes/music_videos/{folder} && /usr/bin/python3 -m http.server 8768 &
ngrok http 8768
```

**검증 protocol (모든 경우 필수):**
```bash
# Step 1: local 파일 접근 확인
curl -s -I "http://localhost:{PORT}/video_final.mp4" | head -1
# → HTTP/1.0 200 OK (directory correct)

# Step 2: external URL 접근 확인 (실패하면 404)
curl -s -I "https://{ngrok_url}/video_final.mp4" 2>&1 | head -10
# → HTTP/2 200 이어야 한다
```

## 해결 요약

| 원인 | 해결 |
|------|------|
| HTTP 서버 홈 디렉토리 실행 | `cd /target/dir && python3 -m http.server PORT` 또는 `cwd=` 파라미터 |
| 기존 ngrok 세션 충돌 | `pkill -f "ngrok http"` 후 재시작, `--pooling-enabled` 사용 |
| 포트 충돌 | 새 포트 번호 사용 (8766, 8767...) |