# mmx image --out 경로 문제 + 3개 이미지 Ken Burns 버그 (2026-05-25)

## mmx image --out 파일명 버그 (확인됨 2026-05-25)

**문제:** `mmx image generate --out image_0.png`을 실행해도 이미지가 `image_001.jpg`로 저장됨.
**원인:** mmx-cli가 지정한 `--out` 파일명을 무시하고 항상 `image_001.jpg`로 저장.

**해결:** 생성 후 파일 리네이밍
```bash
mv image_001.jpg image_0.png
```

**패턴 (매번 발생):**
```bash
# 3개 이미지 생성 → 각 파일 리네이밍 필수
mmx image "..." --out image_0.png   # → image_001.jpg로 저장됨
mv image_001.jpg image_0.png

mmx image "..." --out image_1.png   # → image_001.jpg로 덮어씌워짐
mv image_001.jpg image_1.png

mmx image "..." --out image_2.png   # → image_001.jpg로 덮어씌워짐
mv image_001.jpg image_2.png
```

**핵심:** 각 생성 직후 즉시 리네이밍. 순차 생성 시 이전 파일이 덮어씌워짐.

## 3개 이미지 FFmpeg Concat 버그 (확인됨 2026-05-25)

**문제:** FFmpeg의 filter_complex `[0:v][1:v][2:v]concat=n=3:v=1:a=0[video]` 방식으로 3개 이미지를 합성하면 **1장만 반복**되는 버그.

**원인:** 이미지는 비디오와 달리 pts.time이 없음. `setpts=PTS+33.3/TB`가 이미지에서는 제대로 작동하지 않아 첫 번째 이미지만 반복.

**✅ 검증된 Working 방식 — 개별 세그먼트 생성 후 concat:**
```python
seg_times = [(0, 33.3), (33.3, 66.6), (66.6, 100)]
for idx, (img_path) in enumerate([...]):
    seg_start, seg_end = seg_times[idx]
    seg_duration = seg_end - seg_start
    
    r = subprocess.run([
        "ffmpeg", "-y", "-loop", "1", "-i", img_path,
        "-filter_complex",
        f"[0:v]scale=1920:1080:force_original_aspect_ratio=increase,crop=1920:1080,"
        f"zoompan=z='if(lte(pzoom,1.0),1.0+{0.15/seg_duration:.6f},pzoom)':"
        f"d={int(seg_duration*30)}:s=1920x1080:fps=30[vs]",
        "-map", "[vs]", "-t", str(seg_duration),
        "-c:v", "libx264", "-preset", "ultrafast", "-crf", "28",
        f"seg_{idx}.mp4"
    ])
    if r.returncode == 0:
        seg_files.append(f"seg_{idx}.mp4")

# concat.txt로 합성
with open("concat.txt", "w") as f:
    for sf in seg_files:
        f.write(f"file '{sf}'\n")

subprocess.run([
    "ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", "concat.txt",
    "-c:v", "libx264", "-preset", "fast", "-crf", "23",
    f"final_{TS}.mp4"
])
```

**❌ 절대 사용 금지:**
```bash
# 이 방식은 1장의 이미지만 반복됨 — 버그 발생
ffmpeg -y \
  -loop 1 -i img0.png -loop 1 -i img1.png -loop 1 -i img2.png \
  -filter_complex "[0:v][1:v][2:v]concat=n=3:v=1:a=0[video]" ...
```

**Fallback (zoompan 실패 시):**
```python
r = subprocess.run([
    "ffmpeg", "-y", "-loop", "1", "-i", img_path,
    "-vf", "scale=1920:1080,crop=1920:1080",
    "-t", str(seg_duration),
    "-c:v", "libx264", "-preset", "ultrafast", "-crf", "28",
    f"seg_{idx}.mp4"
])
```

## Equalizer 위치 — W-500:H-180 (절대 고정 좌표 금지)

**문제:** `overlay=920:600`은 1280x720에서만 우측 하단. 1920x1080에서는 중앙~우측에 배치됨.

**✅ 동적 좌표:**
```bash
ffmpeg -y -i main_video.mp4 -stream_loop -1 -i equalizer.gif \
  -filter_complex "[0:v][1:v]overlay=W-500:H-180:shortest=1[composed]" ...
```

## 이미지 프롬프트 — 남성 제외 + 포토리얼리즘 (2026-05-25)

모든 이미지 variant에 반드시 포함:
```
photorealistic, real photo, bright daylight, vivid colors, high-key lighting, sharp focus, professional camera, female subjects only, no men
```

**절대 금지 키워드:**
```
cartoon, kawaii, cute, anime, illustration, 2d, drawing, painting
```