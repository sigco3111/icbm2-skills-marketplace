# Gallery Page Browser Loading Issue — 2026-05-23

## Problem
GitHub Pages hosted gallery (`https://sigco3111.github.io/icbm2-gallery/`) gets stuck on "Loading..." forever in browser. Incognito mode also fails.

## Verified OK
- HTML structure: valid, `data` object embedded correctly
- JSON: valid, 2 entries with full lyrics (multi-line)
- Images: all 3 images return HTTP 200
- GitHub Pages: builds successfully (`gh api repos/.../pages/builds/latest` → "built")
- Minimal test page also shows same symptom (not just the full gallery)

## Symptoms
- `curl https://sigco3111.github.io/icbm2-gallery/` returns complete HTML with all entries
- Browser devtools shows gallery div stuck at `<p class="empty">Loading...</p>`
- Stats element never updated
- JS `gallery.innerHTML = html` assignment never executes (or executes but doesn't render)

## Tried
1. ES5 rewrite — `var` instead of `const`/`let`, `for` instead of `forEach`, string concat instead of template literals
2. Hard refresh (`Cmd+Shift+R`)
3. Incognito mode
4. Minimal test page (`<p>Loaded {data.entries.length} entries</p>`) — also failed
5. GitHub Pages force rebuild
6. Verified raw GitHub content URLs accessible

## Root Cause — TWO JavaScript Syntax Errors (Confirmed 2026-05-23)

## Bug 3: index.html Generated from Stale Corrupted index.html Instead of gallery_data.json (CRITICAL — 2026-05-23)

A third failure mode: `index.html` was regenerated from a pre-existing corrupted `index.html` (which already had log text in youtube_url), NOT from `gallery_data.json`.

**What happened:**
1. `gallery_data.json` was fixed (youtube_url cleaned to correct URL) — ✅
2. `index.html` regenerated — but from existing corrupted `index.html` (which had old log text)
3. GitHub API showed correct fix in `gallery_data.json`, but `index.html` on disk/staged was the corrupted version
4. GitHub Pages served the corrupted `index.html` from the just-pushed commit (which was built from stale source)

**Evidence:**
```bash
# gallery_data.json is CORRECT
git show origin/main:gallery_data.json | grep youtube_url | head -1
# → "youtube_url": "https://www.youtube.com/watch?v=x0qZE9NcDjc" ✅

# index.html was STILL CORRUPTED in the commit that followed
git show origin/main:index.html | grep youtube_url | head -1
# → "youtube_url": "Uploading: 애플ICloud가 내 고양이 사진으로...\nSUCCESS: https://..." ❌
```

**Diagnosis:**
```bash
# Check for stale data
curl -sL https://raw.githubusercontent.com/sigco3111/icbm2-gallery/main/index.html | grep "Uploading:"
# If output contains "Uploading:" → index.html was NOT regenerated from gallery_data.json

# Compare commit dates
cd gallery_gh && git log --oneline -3
# If index.html commit is LATER than gallery_data.json commit → was regenerated correctly
# If index.html commit is EARLIER → was regenerated from stale source

# Always compare the GitHub API response (authoritative) vs local file
curl -s "https://api.github.com/repos/sigco3111/icbm2-gallery/contents/index.html?ref=main" | \
  python3 -c "import base64,json,sys; print(json.load(sys.stdin)['content'][:200])"
```

**FIX — ALWAYS regenerate index.html from gallery_data.json:**
```python
# ✅ CORRECT pattern — read from JSON, generate fresh HTML
with open('gallery_data.json', 'r') as f:
    data = json.load(f)
entries_json = json.dumps(data, ensure_ascii=False)
html = f'''... var data = {entries_json}; ...'''  # embed from JSON source
with open('index.html', 'w', encoding='utf-8') as f:
    f.write(html)

# ❌ WRONG pattern — regenerate from existing index.html (may be stale)
# Don't do this! The existing index.html may already contain corrupted data.
```

**Prevention:** After any `gallery_data.json` modification, ALWAYS regenerate `index.html` from the JSON data source. Never from the previous index.html.

## After Fix — If Page Still Shows "Loading..." (Browser Cache Issue)

**GitHub API confirms fix is deployed correctly** — yet user still sees "Loading..." in browser.

### Diagnosis checklist
```bash
# 1. GitHub API confirms correct content is deployed
curl -s "https://api.github.com/repos/sigco3111/icbm2-gallery/contents/index.html?ref=main" | \
  python3 -c "import base64,json,sys; d=json.load(sys.stdin); print(base64.b64decode(d['content']).decode()[:500])"

# 2. curl from raw GitHub shows correct URLs (NOT log text)
curl -sL https://raw.githubusercontent.com/sigco3111/icbm2-gallery/main/index.html | \
  grep -o 'youtube_url": "[^"]*' | head -2

# 3. GitHub Pages URL (may be cached differently from raw URL)
curl -sL https://sigco3111.github.io/icbm2-gallery/ | \
  grep -o 'youtube_url": "[^"]*' | head -2
```

### If GitHub API shows CORRECT URLs but browser still fails:
**Cause:** GitHub Pages CDN caches for 600 seconds (`cache-control: max-age=600`).

**Solutions (in order):**
1. `Ctrl+Shift+R` (Chrome hard refresh)
2. DevTools → Network tab → "Disable cache" → reload
3. Try different browser (Safari/Firefox)
4. Wait 10+ minutes for CDN cache to expire
5. DevTools → Application → Storage → Clear site data → hard reload

### Telltale sign it's a cache issue (not a code issue):
- `curl` from terminal returns correct content ✅
- Browser devtools console shows no JS errors ✅
- `class="card"` count = 1 in browser (cached) ❌
- `class="card"` count = 3 in `curl` output ✅

## Root Cause — THREE Distinct Failure Modes (Confirmed 2026-05-23)

Playwright headless browser caught JS error: `"Unexpected string"` — script failed silently at parse time.

### Bug 1: Empty string `''` in onclick

```javascript
// ❌ INVALID — '' is not a valid JS string literal
onclick="showImage('' + entry.images[k] + '')"
// ✅ FIXED — escaped quotes
onclick="showImage(\'' + entry.images[k] + '\')"
```

### Bug 2: Regex literal with actual newline

```javascript
// ❌ BROKEN — \n in HTML source becomes literal newline (0x0A), not backslash-n
entry.lyrics.replace(/\n
/g, '<br>')

// ✅ FIXED — use \\n so JS sees backslash-n
entry.lyrics.replace(/\\n/g, '<br>')
```

## Verification

1. Extract inline `<script>` to temp file: `python3 -c "import re; ..."`
2. Run `node --check /tmp/gallery_test.js` — catches syntax errors instantly
3. Playwright `page.on("pageerror")` catches runtime errors that browser console may not show

## Fix Applied (2026-05-23)

All three bugs fixed in `index.html`. GitHub Pages CDN caches for 600s (`cache-control: max-age=600`) — may need hard refresh after push.

## Gallery Data (as of 2026-05-23)
```json
{
  "entries": [
    {
      "date": "2026-05-23",
      "topic": "서울의 달콤한 밤 - 라멘 냄새가 기억이 돼",
      "mood": "우타이테",
      "youtube_url": "https://www.youtube.com/watch?v=Co2e-aAIK_g",
      "short_url": "https://www.youtube.com/watch?v=WXMyziXxf4Y",
      "lyrics": "골목 끝 네온불빛이 반짝여 따뜻한 바람이 내 볼을 스쳐\n라멘摊에서 마주친 그 눈빛\n아무 말 없이 웃어주는 게 좋아",
      "images": [
        "https://raw.githubusercontent.com/sigco3111/icbm2-gallery/main/images/img1.png",
        "https://raw.githubusercontent.com/sigco3111/icbm2-gallery/main/images/img2.png",
        "https://raw.githubusercontent.com/sigco3111/icbm2-gallery/main/images/img3.png"
      ]
    },
    {
      "date": "2026-05-23",
      "topic": "서울의 달콤한 밤 (3분 32초 Extended)",
      "mood": "우타이테",
      "youtube_url": "https://www.youtube.com/watch?v=dgCVpvUCTSU",
      "short_url": "https://www.youtube.com/watch?v=duHYrEs5_JM",
      "lyrics": "네온불빛 아래 걷는 서울의 밤\n라멘 한 그릇에 담긴 따뜻한 기억\n시간이 흘러도不变的 너와 나",
      "images": [
        "https://raw.githubusercontent.com/sigco3111/icbm2-gallery/main/images/img1.png",
        "https://raw.githubusercontent.com/sigco3111/icbm2-gallery/main/images/img2.png",
        "https://raw.githubusercontent.com/sigco3111/icbm2-gallery/main/images/img3.png"
      ]
    }
  ]
}
```