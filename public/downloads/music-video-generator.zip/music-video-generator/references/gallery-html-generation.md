# Gallery HTML Generation — Critical Data Flow (2026-05-23)

## gallery_data.json → index.html 변환 규칙

### 1. 이미지 — 항상 images 배열 루프로 3개 모두 렌더링

```json
"images": [
  "https://raw.githubusercontent.com/sigco3111/icbm2-gallery/main/images/20260523_182054_image_0.png",
  "https://raw.githubusercontent.com/sigco3111/icbm2-gallery/main/images/20260523_182054_image_1.png",
  "https://raw.githubusercontent.com/sigco3111/icbm2-gallery/main/images/20260523_182054_image_2.png"
]
```

```html
<div class="card-img-wrap three">
  <img class="card-img" src="images[0]" onclick="openModal(this)">
  <img class="card-img" src="images[1]" onclick="openModal(this)">
  <img class="card-img" src="images[2]" onclick="openModal(this)">
</div>
```

**절대 하지 말 것:** HTML 소스에 1개만 하드코딩. 고양이ICloud 카드처럼 이미지가 3개인데 HTML에 1개만 있으면 사용자 보기에서 1개만 보임.

### 2. 가사 — preview 텍스트와 data-fulllyrics 속성 분리

```json
"lyrics": "골목 끝 네온불빛이 반짝여 따뜻한 바람이 내 볼을 스쳐\n라멘摊에서 마주친 그 눈빛\n아무 말 없이 웃어주는 게 좋아"
```

```html
<p class="lyrics-preview has-full"
   data-fulllyrics="골목 끝 네온불빛이 반짝여 따뜻한 바람이 내 볼을 스쳐
라멘摊에서 마주친 그 눈빛
아무 말 없이 웃어주는 게 좋아"
   onclick="showLyrics(this)">"골목 끝 네온불빛이 반짝여 따뜻한 바람이 내 볼을 스쳐..."</p>
```

**가사 없는 카드 (lyrics = ""):** `data-fulllyrics` 없이 `lyrics-preview` 클래스만 추가. 클릭해도 모달 안 열림 (의미 없으므로).

### 3. gallery_data.json 저장 시 주의

```python
# ✅ 올바름 — 전체 가사 저장 (preview는 JS에서 80자 자르기)
new_entry = {
    "lyrics": lyrics,  # 전체 가사 (개행 \n 포함)
    ...
}

# ❌ 잘못됨 — 200자만切片하면 preview = 전체가사 → 토글해도 같은 텍스트
new_entry = {
    "lyrics": lyrics[:200] if lyrics else "",
    ...
}
```

### 4. 고양이ICloud 카드처럼 images 배열이 3개인데 HTML에 1개만 출력되는 경우

**원인:** HTML 생성 시 images 배열을 사용하지 않고 단일 `image_url`만 사용.

**확인:** `grep -A5 "card-img-wrap" index.html` — 3개 img 태그가 있는지 확인.

**수정:** `index.html` 재생성 시 images 배열 기반 루프로 3개 img 렌더링.

### 5. today.txt 주제와 gallery_data.json 차이

| today.txt | gallery_data.json |
|-----------|-------------------|
| topics侯選 12개 (URL 포함) | 업로드 완료된 항목만 저장 |
|侯選/channel_topic侯選 | gallery_url, short_url, lyrics 저장 |
| `topic_url` →侯選 전송용 | gallery_topic侯選 ≠ gallery_data.json topic |

gallery_data.json의 topic은 YouTube 업로드 완료 후 저장되므로 gallery_topic侯選의 하위 집합.