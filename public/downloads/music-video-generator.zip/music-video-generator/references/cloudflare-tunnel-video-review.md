# Cloudflare Tunnel — 로컬 영상 검수용 공유 링크

## 왜 쓰는가

Telegram으로 영상 파일을 직접 전송하면:
- 용량 부담 (핸드폰 저장공간)
- Telegram 서버에 영상 저장

대신 **로컬 Mac의 영상 파일을 외부에서 열 수 있는 링크**로 공유.

## 설치

```bash
brew install cloudflared
```

## 사용법

### 1단계: 로컬 HTTP 서버 실행 (영상 디렉토리)

```bash
cd /Users/hjshin/.hermes/music_videos
python3 -m http.server 8765
```

### 2단계: Cloudflare Tunnel 실행

```bash
cloudflared --url http://localhost:8765
```

**출력 예시:**
```
+--------------------------------------------------------------------------------------------+
|  Your quick Tunnel has been created! Visit it at:                    |
|  https://random-words.trycloudflare.com                             |
+--------------------------------------------------------------------------------------------+
```

### 3단계: Telegram으로 링크 전송

```
🎬 뮤직비디오 검수

제목: {주제명}
설명: {설명}

🔗 검토 링크: https://random-words.trycloudflare.com/video_20260523_202145.mp4

✅ 확인 → YouTube 업로드
✏️ 수정 → 제목/설명 변경
```

### 4단계: 승인 → YouTube 업로드

사용자가 '확인' → `yt_upload.py`로 실제 업로드.

### 5단계: 종료

Cloudflare Tunnel 프로세스 중지 (세션마다 새 링크 생성).

## 스크립트화

`music_video_review_server.py`로 자동화:

```python
# 1. HTTP 서버 백그라운드 실행
http_proc = subprocess.Popen(
    ["python3", "-m", "http.server", "8765"],
    cwd=VIDEO_DIR, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
)

# 2. Cloudflare Tunnel 실행
cf_proc = subprocess.Popen(
    ["cloudflared", "--url", "http://localhost:8765"],
    stdout=subprocess.PIPE, stderr=subprocess.STDOUT
)

# 3. URL 파싱
for line in cf_proc.stdout:
    line = line.decode()
    if "trycloudflare.com" in line:
        url = re.search(r'https://[a-z-]+\.trycloudflare\.com', line).group(0)
        break

# 4. Telegram으로 전송
video_link = f"{url}/{video_filename}"
send_telegram(f"🔗 검토: {video_link}")

# 5.待機 (사용자 승인 대기)
# ...

# 6. 정리
cf_proc.terminate()
http_proc.terminate()
```

## ⚠️ 주의사항

1. **세션마다 링크 변경** — cloudflared quick tunnel은 재실행 시 새 URL 발급
2. **계정 없음 제한** — Cloudflare 계정 없이 사용 시 uptime 보장 없음 (실험용)
3. **포트 충돌** — 8765 이미 사용 중이면 다른 포트 사용
4. **토큰 불필요** — ngrok과 달리 Cloudflare Tunnel quick mode는 authtoken 없이 작동

## vs ngrok

| | Cloudflare Tunnel | ngrok |
|---|---|---|
| 설치 | `brew install cloudflared` | `brew install ngrok` + authtoken |
| 영구 URL | ❌ 세션마다 변경 | ❌ 세션마다 변경 |
| 계정 | 불필요 (quick mode) | authtoken 필요 |
| 비용 | 무료 | 무료 플랜 있음 |

## Telegram Bot Token과 Hermes 연결

**MEMO (2026-05-24):**
- `telegram_bot_token.txt` 파일에는 `PLACEHOLDER`만 있으나, Hermes Agent는 Telegram과 정상 연결되어 있음
- 실제 토큰은 Hermes Gateway 환경변수(`HERMES_TELEGRAM_BOT_TOKEN`)로 주입됨
- 영상 전송 시 Bot API 직접 호출은 404 에러 발생 → **Cloudflare Tunnel 방식 사용**