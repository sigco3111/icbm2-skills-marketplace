# GitHub Pages Gallery Setup (2026-05-23)

## GitHub Pages Limitations

GitHub Pages **does not support directory listing**. When you navigate to `/images/`, you get a 404 — there's no auto-generated file browser like Apache's `Indexes` option.

**Solution:** Static HTML page with hardcoded or dynamically generated image list.

## Setup Commands (One-Time)

```bash
# 1. Create public repo
gh repo create icbm2-gallery --public --description "ICBM2 Music Video Image Gallery"

# 2. Initialize local directory
mkdir -p ~/.hermes/music_videos/gallery_gh/images
cd ~/.hermes/music_videos/gallery_gh
git init
git remote add origin https://github.com/sigco3111/icbm2-gallery.git

# 3. Initial commit + push
echo "# ICBM2 Gallery" > README.md
git add .
git commit -m "Initial"
git branch -M main
git push -u origin main

# 4. Enable GitHub Pages (legacy /docs style)
gh api -X POST repos/sigco3111/icbm2-gallery/pages \
  -f build_type=legacy \
  -f source[branch]=main \
  -f source[path]=/

# 5. Wait for build (~30-60s), then check:
gh api repos/sigco3111/icbm2-gallery/pages/builds/latest
# Look for "status": "built"
```

## Page URL

- **Pages:** https://sigco3111.github.io/icbm2-gallery/
- **Repo:** https://github.com/sigco3111/icbm2-gallery

## Manual Rebuild (if needed)

```bash
gh api -X POST repos/sigco3111/icbm2-gallery/pages/builds
```

## Image Access (Direct URL)

Images are accessible directly at:
```
https://sigco3111.github.io/icbm2-gallery/images/{filename}.png
```

This works even if the index.html gallery doesn't load — useful for debugging.