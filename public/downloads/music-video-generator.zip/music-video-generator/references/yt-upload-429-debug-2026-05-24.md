# YouTube Upload 429 Debugging — 2026-05-24

## 상황
주인님이 "업로드" 요청 → 429 Quota Exceeded 오류 발생

## 디버깅 과정

### 1차 시도: 시스템 python3 실행
```bash
/usr/bin/python3 yt_upload.py ...
# → ModuleNotFoundError: No module named 'googleapiclient'
```

### 2차 시도: pip install 시도
```bash
pip3 install google-api-python-client google-auth-oauthlib
# → ERROR: Command errored out ... puccinialin
# pyodbc 충돌로 전체 설치 실패
```

### 3차 시도: /usr/local/bin/python3 시도
```bash
/usr/local/bin/python3 -c "from googleapiclient.discovery import build"
# → ModuleNotFoundError: No module named 'cryptography'
```

### 4차 시도: /usr/bin/python3 (3.9.6) 성공
```bash
/usr/bin/python3 -m pip install cryptography
/usr/bin/python3 -m pip install google-api-python-client google-auth-oauthlib
/usr/bin/python3 -c "from googleapiclient.discovery import build"  # OK
```

### 5차 시도: 429 발생 → 토큰 강제 리프레시
```python
# 429 발생했으나 토큰은 valid=True, expired=False로 보임
# 해결: creds.refresh(Request())로 강제 갱신 후 재시도 → 성공
```

## 핵심 교훈

1. **429 ≠ 실제 quota 소진** — 만료된 토큰이 가장 흔한 원인
2. **`/usr/bin/python3` (3.9.6)** 만 사용 — 시스템 전체 python에 올바른 모듈 세트 설치됨
3. 토큰이 "유효해 보여도" force refresh 후 재시도해야 함
4. 429 발생 시: 리프레시 → 指數 백오프 대기 → 재시도

## Python 환경 요약

| Python | 버전 | googleapiclient | cryptography | 비고 |
|--------|------|----------------|-------------|------|
| `/Library/Frameworks/Python.framework/Versions/3.8/bin/python3` | 3.8.8 | ⚠️ 충돌 | ⚠️ 누락 | pyodbc 충돌 |
| `/usr/local/bin/python3` | 3.8.8 | ⚠️ 충돌 | ⚠️ 누락 | 同上 |
| `/usr/bin/python3` | 3.9.6 | ✅ OK | ✅ OK | **사용해야 함** |

## 수정된 워크플로우

```python
import pickle, time, os, subprocess
from google.auth.transport.requests import Request

TOKEN_FILE = os.path.expanduser("~/.hermes/secrets/youtube_token.pickle")

def refresh_token_force():
    with open(TOKEN_FILE, "rb") as f:
        creds = pickle.load(f)
    creds.refresh(Request())
    with open(TOKEN_FILE, "wb") as f:
        pickle.dump(creds, f)

# 1. 업로드 전 무조건 토큰 리프레시
refresh_token_force()

# 2. 업로드 실행
PYTHON = "/usr/bin/python3"
result = subprocess.run([
    PYTHON, "/Users/hjshin/.hermes/scripts/yt_upload.py",
    video_path, "--title", title, "--description", description,
    "--tags", tags, "--category", "10", "--privacy", "public"
], capture_output=True, text=True)

# 3. 429 발생 시 리프레시 + 재시도
if "429" in result.stderr or "rateLimit" in result.stderr:
    refresh_token_force()
    time.sleep(20)  # 20초 대기
    # 재시도...
```