# music_video_producer.py 버그 및 해결 (2026-05-24)

## 1. HOME 변수 미정의 버그

**문제:**
```
NameError: name 'HOME' is not defined
  File "~/.hermes/scripts/music_video_producer.py", line 705
```

**원인:**
```python
# 잘못된 코드
review_script = os.path.join(HOME, ".hermes/scripts/music_video_review.py")

# 올바른 코드
review_script = os.path.join(os.path.expanduser("~"), ".hermes/scripts/music_video_review.py")
```

`HOME`은 Python 내장 글로벌 변수가 아니므로 항상 `os.path.expanduser("~")` 또는 `os.environ.get("HOME")` 사용.

---

## 2. Cron Timeout 120초 → 600초

**문제:** 뮤직비디오 생성 크론 잡이 120초(default `_DEFAULT_SCRIPT_TIMEOUT`)에서 타임아웃

**해결:** `~/.hermes/.env`에 다음 추가:
```
HERMES_CRON_SCRIPT_TIMEOUT=600
```
적용 후 gateway 재시작 불필요 (즉시 적용됨).

---

## 3. 0-byte 빈 동영상 파일 발생

**문제:** FFmpeg 합성 시 이미지→동영상 변환 과정에서_audio 동기화 문제로 0-byte 파일 다수 발생

**확인 명령:**
```bash
find ~/.hermes/music_videos/ -name "*.mp4" -size 0
```

**정리:**
```bash
find ~/.hermes/music_videos/ -name "*.mp4" -size 0 -delete
```

**추적:** 9개 0-byte 파일 정리됨 (2026-05-23 작업에서 발생)

---

## 4. 데이터베이스 ID 변경 이슈

Notion侯選 DB parent ID가 변경되어 404 오류 발생.
- 이전 ID: `36976f2e-9097-81e1-bb34-000b13fb3627`
- 실제 ID: `/search` API로 확인 필요 → parent ID 필요

Notion Database 생성 시 자동으로 parent ID가 할당되므로 `/search`로 확인 후 사용.

---

## 5. 속성명 한국어 사용

Notion DB에서 `주제` (title), `상태` (select), `분위기` (select) 등 한국어 속성명 사용.
→ validation_error 발생 시 속성명 확인 필요.