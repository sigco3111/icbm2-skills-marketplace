# ngrok 영상 검수 세션 (2026-05-24)

## 문제
Cloudflare Tunnel 사용 시 **Error 1033** 빈번하게 발생 — 영상에 외부 접근 불가

## 해결
**ngrok** 사용으로 전환 — 안정적인 외부 접근 링크 생성 확인됨

### ngrok 설치 및 설정
```bash
brew install ngrok
ngrok config add-authtoken <authtoken>  # ngrok.com 무료 계정에서 발급
```

### ngrok.com 무료 계정 발급
1. https://ngrok.com → Sign up → 무료 계정 생성
2. Dashboard → Your Authtoken 복사
3. 로컬: `ngrok config add-authtoken <token>`

## 검수 링크 생성 (Python)
```python
import subprocess, re, time, os

def create_ngrok_review_link(video_dir, port=8768):
    """ngrok으로 영상 검수용 외부 링크 생성"""
    
    # 1. HTTP 서버 시작 (영상 디렉토리에서 실행)
    http_proc = subprocess.Popen(
        ["python3", "-m", "http.server", str(port)],
        cwd=video_dir,
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
    )
    time.sleep(2)
    
    # 2. ngrok Tunnel 시작
    ngrok_proc = subprocess.Popen(
        ["ngrok", "http", str(port)],
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT
    )
    
    # 3. URL 추출 (ngrok API 사용)
    time.sleep(5)
    try:
        import urllib.request
        resp = urllib.request.urlopen("http://localhost:4040/api/tunnels")
        data = json.loads(resp.read().decode())
        for t in data.get('tunnels', []):
            if t.get('proto') == 'https':
                return t.get('public_url'), http_proc, ngrok_proc
    except:
        pass
    
    return None, http_proc, ngrok_proc

# 사용
url, http_proc, ngrok_proc = create_ngrok_review_link("/path/to/video/folder")
if url:
    video_link = f"{url}/video_wave.mp4"
    short_link = f"{url}/short.mp4"
    print(f"🎬 검수: {video_link}")
    print(f"📱 Shorts: {short_link}")
```

## ngrok API로 URL 확인 (4040 포트)
```bash
curl -s http://localhost:4040/api/tunnels | python3 -c "
import sys, json
d = json.load(sys.stdin)
for t in d.get('tunnels', []):
    print(t.get('public_url'), '->', t.get('config', {}).get('addr'))
"
```

## 프로세스 정리 (중요!)
```python
# 사용 후 반드시 종료
ngrok_proc.terminate()
http_proc.terminate()
```

## ⚠️ 주의사항
- ngrok 프로세스가 이미 실행 중이면 새 인스턴스 시작 시 `ERR_NGROK_334` 에러
- 새 포트 사용 또는 기존 프로세스 정리 후 재시작
- 무료 계정: 세션 종료 시 URL 회수, 재연결 시 새 URL 발급