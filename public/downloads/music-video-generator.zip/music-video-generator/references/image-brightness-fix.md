# 이미지 밝기 개선: 어두운 포토리얼리즘 문제 해결 (2026-05-24)

## 문제
MiniMax mmx CLI로 포토리얼리즘 스타일 이미지를 생성하면 항상 어두운 이미지가 나오는”问题 발생

## 원인
`cinematic photography`, `natural lighting`, `night scene`, `neon reflections` 등의 프롬프트가 어두운 조명 유발

## 해결책
모든 이미지 생성 프롬프트에 다음 조합 사용:
- ✅ `bright daylight, vivid colors, high-key lighting` — 밝고 생생한色彩
- ✅ `comedic contrast, playful light, cheerful atmosphere` — 유머/위트 테마에 최적
- ❌ `cinematic photography, natural lighting, low-key lighting, moody atmosphere` — 절대 사용 금지

## 적용 위치

### 1. music_video_producer.py (generate_image_variants 함수)
```python
variants = [
    f"{base_prompt}, bright daylight, vivid colors, high-key lighting",
    f"{base_prompt}, warm golden hour, saturated tones, playful light",
    f"{base_prompt}, sunny atmosphere, comedic contrast, cheerful mood"
]
```

### 2. SKILL.md 이미지 프롬프트 규칙
```markdown
- ✅ `photorealistic, bright daylight, vivid colors, high-key lighting` 필수
- ✅ 유머/위트 테마에 어울리는 밝고 활기찬 이미지: `comedic contrast, playful light, cheerful atmosphere`
- ❌ `cinematic photography`, `natural lighting`, `low-key lighting`, `moody atmosphere` — 절대 사용 금지
```

## 검증
2026-05-24 이후 생성 이미지에서 적용 확인됨