---
家主님 직접 입력 음악 프롬프트 참조 (2026-05-26)
家主님 직접 선택한 음악 스타일
---

##家主님 직접 선택한 음악 스타일 프롬프트 (2026-05-26)

**家主님 요청:** "포�트를 다음과 같이 변경해서 다시 생성해줘"

```
K-pop, powerful Korean female vocal, upbeat pop-rock, fast tempo,
energetic band sound, electric guitar, hopeful and exciting anime opening style,
driving bass, catchy chorus
```

**家主님 가사 톤 요청:** "AI한테 자리 내준 직장인에게 희망차고 신나는 멜로디로 재치있게 위로하는 느낌으로"

**家主님이 직접 가사 분량 요청:** "가사는 2~3분 분량으로 해줘" (기본 3분 대신 2~3분)

---

## 음악 프롬프트 빌드 패턴

家主님이 직접 제공한 프롬프트 → 그대로 mmx music generate에 사용

```bash
source ~/.hermes/secrets/minimax.env
mmx music generate \
  --api-key "$MINIMAX_API_KEY" \
  --prompt "K-pop, powerful Korean female vocal, upbeat pop-rock, fast tempo, energetic band sound, electric guitar, hopeful and exciting anime opening style, driving bass, catchy chorus" \
  --lyrics "$(cat lyrics_expanded.txt)" \
  --out music.mp3
```

## 가사 분량 컨트롤 (2~3분 vs 3분)

| 상황 | target_chars | 예상 길이 |
|------|-------------|---------|
|家主님 "2~3분 분량" 요청 | 1200~1500자 | ~2~3분 |
| 기본 (家主님 별도 요청 없음) | 1500~1800자 | ~3분 |
