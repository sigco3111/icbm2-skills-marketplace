# 투명 배경 이퀄라이저 GIF 오버레이 기법

## 문제
이퀄라이저 애니메이션을 영상에 오버레이할 때, 이퀄라이저 바 주변의 검은 배경이 영상을 가림.

## 해결책
PNG 시퀀스 → GIF (투명 배경) → FFmpeg overlay

### 1단계: Python으로 RGBA 프레임 생성 (PIL)

```python
from PIL import Image, ImageDraw
import math, os, random

WAVE_DIR = os.path.expanduser("~/.hermes/music_videos/wave_anim")
os.makedirs(WAVE_DIR, exist_ok=True)

w, h = 360, 120
num_bars = 20
bar_w = 12
bar_spacing = 6
margin_bottom = 15

# 네온 핑크→보라→블루 그라데이션
colors = [
    (255, 80, 120),   # 핑크
    (200, 80, 180),   # 보라
    (120, 80, 255),   # 블루
    (80, 150, 255),   # 스카이
]

random.seed(42)
base_heights = [random.randint(30, 80) for _ in range(num_bars)]

frames = []
for frame in range(30):  # 30fps × 1초 = 1초 루프
    img = Image.new('RGBA', (w, h), (0, 0, 0, 0))  # 완전 투명
    draw = ImageDraw.Draw(img)
    phase = frame * 0.3
    
    for i in range(num_bars):
        wave = math.sin(phase + i * 0.4) * 0.4 + 0.6
        bar_h = int(base_heights[i] * wave)
        bar_h = max(10, min(bar_h, h - margin_bottom - 10))
        
        x = i * (bar_w + bar_spacing)
        y = h - margin_bottom - bar_h
        
        color_idx = int((i / num_bars) * (len(colors) - 1))
        color = colors[min(color_idx, len(colors) - 1)]
        
        draw.rounded_rectangle([x, y, x + bar_w, h - margin_bottom],
                              radius=4, fill=color + (220,))
    frames.append(img)

# GIF 저장 (optimize=False로 투명도 보존)
frames[0].save(
    f'{WAVE_DIR}/wave_animation.gif',
    save_all=True,
    append_images=frames[1:],
    duration=int(1000/30),
    loop=0,
    optimize=False
)
for f in frames:
    f.close()
```

**핵심:**
- `Image.new('RGBA', ..., (0,0,0,0))` → 완전 투명 배경
- `color + (220,)` → alpha=220 (거의 불투명, 살짝 반투명)
- `rounded_rectangle` → 모서리 둥근 바
- `optimize=False` → 최적화 비활성화 (투명도 손실 방지)

### 2단계: FFmpeg로 영상에 오버레이

```bash
# 위치: 우측 하단 (1280x720 영상 기준)
# x=920: 1280 - 360 = 920 (우측 정렬)
# y=600: 720 - 120 = 600 (하단 정렬)

ffmpeg -y \
  -i main_video.mp4 \
  -stream_loop -1 -i wave_animation.gif \
  -filter_complex "[0:v][1:v] overlay=920:600:shortest=1" \
  -c:v libx264 -preset ultrafast -crf 23 \
  -c:a copy \
  final_with_wave.mp4
```

**옵션 설명:**
- `-stream_loop -1`: GIF를 영상 길이만큼 무한 반복
- `shortest=1`: 메인 영상이 끝나면 전체 종료
- `-c:a copy`: 오디오 재인코딩 불필요 (빠름)

## Ken Burns + 이퀄라이저 조합

이퀄라이저는 우측 하단 고정 → 좌측/중앙 이미지가 Ken Burns 효과로 zoom/pan:
- 이미지 1: zoom-in (1.0 → 1.15)
- 이미지 2: zoom-out (1.15 → 1.0)
- 이미지 3: zoom-in (1.0 → 1.12)

## 위치 조정 가이드

| 영상 해상도 | x (오른쪽 정렬) | y (하단 정렬) |
|-----------|----------------|---------------|
| 1280x720 | 920 (1280-360) | 600 (720-120) |
| 1920x1080 | 1560 (1920-360) | 960 (1080-120) |
