# music-video-pipeline Reference (absorbed into music-video-generator)

This file preserves the distinct structural content from `music-video-pipeline` for historical reference.
The pipeline skill has been merged into `music-video-generator` as the primary class-level skill.

## Cronjobs (from pipeline)

| Time | Job | Note |
|------|-----|------|
| 10:00 |侯選 수집 (jID: fcfd160352ff) | Reddit/X에서 유머/위트 자동 수집 — 블로그 GeekNews와 완전 별개 |
| 20:00 | Production + upload | `music_video_producer.py` |

## Notion DB Schema (from pipeline)

- **DB ID:** `36976f2e-9097-81e1-a373-e06f2da6e99c`
- **Page:** ICBM2 workspace (36376f2e-9097-8182-ab21-c5e61ae6b40a)
- **Properties:** 주제, 상태, 분위기, 음악스타일, 이미지프롬프트, 음악프롬프트, 뉴스출처, 영상경로, 유튜브URL, 생성일

## YouTube Upload Token Refresh Pattern (from pipeline — canonical)

```python
import pickle, time, os
from google.auth.transport.requests import Request

TOKEN_FILE = os.path.expanduser("~/.hermes/secrets/youtube_token.pickle")

def refresh_token_force():
    with open(TOKEN_FILE, "rb") as f:
        creds = pickle.load(f)
    if not creds.valid:
        creds.refresh(Request())
        with open(TOKEN_FILE, "wb") as f:
            pickle.dump(creds, f)
    return creds

# Before any upload:
refresh_token_force()
```

## YouTube 429 Retry Loop (from pipeline — canonical)

```python
for attempt in range(3):
    result = subprocess.run([PY, YT_SCRIPT, video_path,
        "--title", title, "--description", desc,
        "--tags", tags, "--privacy", "public"],
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=120)
    if "SUCCESS" in result.stdout.decode():
        break
    elif "429" in result.stderr.decode() or "rateLimit" in result.stderr.decode():
        refresh_token_force()
        time.sleep(2 ** attempt * 10)
    else:
        break
```

## mmx CLI Quick Reference (from pipeline)

```bash
# Image generation
mmx image generate --api-key "$MINIMAX_API_KEY" --prompt "..." --out output.png

# Music generation
mmx music generate --api-key "$MINIMAX_API_KEY" --prompt "..." --lyrics "..." --out output.mp3
```

## User Preferences (from pipeline — canonical)

| 항목 | 선호 |
|------|------|
| 보컬 | 한국어 여성 보컬 |
| 분위기 | 밝고 경쾌한 Upbeat |
| 가사 톤 | 유머와 재치있는 |
| 음악 장르 | 우타이테풍 (upbeat pop, 120-140 BPM) |
| 구조 | 후렴 선행형 (Hook First) |
| Shorts | 일반 영상과 항상 세트 업로드 |
| 이미지 스타일 | Blur letterbox (배경 이미지 블러 처리) |

## Playlist Analysis Summary (from pipeline)

User's YouTube playlist (116 songs):
- **Vocal:** Female dominant (K-pop covers, ballads)
- **Mood:** Romantic, sentimental, dreamy
- **Tempo:** Mid-tempo ballad centered
- **Instruments:** Acoustic guitar, piano based
- **Style examples:** IU, Blackpink, GFRIEND covers; Bon Jovi, MR.BIG, Richard Marx covers; 7080 remakes

## Cloudflare Tunnel Info (DEPRECATED — ngrok used instead)

Cloudflare Tunnel was replaced by ngrok (2026-05-24) due to Error 1033.
See `music-video-generator` main SKILL.md for ngrok-based video review.
This section kept for historical reference on the debugging path.

### Cloudflare Tunnel Quick Setup
```bash
brew install cloudflared
```

### Review Flow
1. Start HTTP server on port (e.g., 8766):
```python
import http.server, socketserver, os
socketserver.TCPServer.allow_reuse_address=True
os.chdir(os.path.expanduser('~/.hermes/music_videos'))
http.server.HTTPServer(('127.0.0.1', 8766), http.server.SimpleHTTPRequestHandler).serve_forever()
```

2. Start cloudflared tunnel:
```bash
nohup cloudflared --url http://127.0.0.1:8766 > /tmp/cf.log 2>&1 &
tail -20 /tmp/cf.log  # Look for https://*.trycloudflare.com
```

3. Send review link via Telegram

### Cloudflare Common Issues
- **OSError 48 (Address in use):** `lsof -i :8765` → `pkill -f "python.*http.server|python.*876"`
- **HTTP 530:** cloudflared can't reach origin — `curl -s http://127.0.0.1:8766/` to verify server
- **Empty logs:** cloudflared outputs to stderr — must redirect `> /tmp/cf.log 2>&1`

## FFmpeg Shorts (9:16) — canonical

```bash
ffmpeg -y -i {video} \
  -vf "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920" \
  -c:v libx264 -preset ultrafast -crf 28 \
  -c:a aac -b:a 128k -t 60 \
  {output}
```

## Ken Burns Effect (from pipeline)

FFmpeg zoompan has 4K compatibility issues on macOS. Use Python PIL instead:
- See `music-video-generator` SKILL.md for the full `create_ken_burns_frames()` implementation