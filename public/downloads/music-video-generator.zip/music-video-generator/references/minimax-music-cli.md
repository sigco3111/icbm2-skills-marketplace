# MiniMax CLI (mmx) Music Generation Reference

## Session Learnings (2026-05-23)

### API Key 인증 문제
`mmx`는 `--api-key` 인자가 없으면 `No credentials found` 에러 발생.
env에 `MINIMAX_API_KEY`가 있어도 명시적으로 `--api-key "$MINIMAX_API_KEY"`를 전달해야 함.

```bash
source ~/.hermes/secrets/minimax.env
mmx image generate --api-key "$MINIMAX_API_KEY" --prompt "..." --out output.png
mmx music generate --api-key "$MINIMAX_API_KEY" --prompt "..." --lyrics "..." --out output.mp3
```

### 음악 생성 모델
- 모델: `music-2.6`
- `--lyrics` 플래그 필수 (생략 시 `Lyrics are required` 에러)
- 출력: `.mp3` 파일 (기본 70-100초, 상세 가사 전달 시 3분+)

### 3분 이상 음악 만드는 법 (확인됨 2026-05-23)
`--duration` 파라미터 없음 — 작동하지 않음.
**방법: expand_lyrics() 함수로 자동 확장** (109자 → 1,591자 확인)

```python
# music_video_producer.py에 구현된 함수
STRUCTURE_TAGS = ['Verse', 'Chorus', 'Bridge', 'Pre-Chorus', 'Intro', 'Outro']

def expand_lyrics(text, target_chars=1500):
    """짧은 가사를 3분 분량(~1500자)으로 자동 확장
    - 구조 태그 [Verse], [Chorus] 등 인식
    - 섹션별 내용 분리 후 반복 추가
    - target_chars 도달 시停止 (max 50 iterations)
    """
    sections = {}
    current_tag = 'Intro'
    current_lines = []
    
    for line in text.split('\n'):
        stripped = line.strip()
        tag_match = None
        for tag in STRUCTURE_TAGS:
            if f'[{tag}]' in stripped or stripped.startswith(f'[{tag} '):
                tag_match = tag
                break
        if tag_match:
            if current_lines:
                sections[current_tag] = '\n'.join(current_lines)
            current_tag = tag_match
            current_lines = []
        elif stripped:
            current_lines.append(stripped)
    if current_lines:
        sections[current_tag] = '\n'.join(current_lines)
    
    result = text
    iterations = 0
    while len(result) < target_chars and iterations < 50:
        parts = []
        for tag in STRUCTURE_TAGS:
            if tag in sections and 'Outro' not in tag:
                num = ' 2' if '2' not in tag else ''
                parts.append(f'[{tag}{num}]\n' + sections[tag])
        if parts:
            result += '\n\n' + '\n\n'.join(parts)
        iterations += 1
    return result
```

**테스트:** 109자 원본 → 1,591자 확장 (약 3분 분량)

**이전 수동 방식 (더 이상 사용 안 함):** section마다 bar 수 명시方式是 번거로워서 `expand_lyrics()` 자동화로 대체.

### 가사 형식 (확인됨)
```
[intro] (la la la)
[verse1]
가사...
[pre-chorus]
...
[chorus]
...
[outro]
la la la~
```
- 섹션 마커: `[intro]`, `[verse1]`, `[pre-chorus]`, `[chorus]`, `[verse2]`, `[outro]`
- 한국어 가사만 사용 (일본어/한자 섞으면 인식 안 됨)
- 우타이테풍: 밝고 경쾌한 템포 (120-140 BPM), 전주→보컬→후렴 반복

### 이미지 생성 모델
- 모델: `image-01`
- `--api-key` 필수
- 출력: `.png` (보통 1024x1024)

## FFmpeg 영상 합성 (확인됨 패턴)

### 일반 영상 (16:9, 1280x720) — 3분 이상 영상 대응
```bash
ffmpeg -y \
  -loop 1 -i image.png \
  -i audio.mp3 \
  -vf "scale=1280:720:force_original_aspect_ratio=increase,crop=1280:720" \
  -c:v libx264 -preset ultrafast -crf 28 \
  -c:a aac -b:a 128k \
  -movflags +faststart \
  -shortest \
  output.mp4
```
- **`-preset ultrafast -crf 28`**: medium 대비 인코딩 2배 이상 빠름 (3분 영상 ~3분 소요)
- **`-shortest`**:音频 길이에 맞춰 영상 자동 종료 (手動 `-t` 불필요)
- **`-movflags +faststart`**: YouTube 업로드 "파일을 처리할 수 없음" 오류 방지 — 반드시 포함
- `-pix_fmt yuv420p`는老的 FFmpeg에서 boxblur 오작동 가능 → 제거

### Shorts (9:16, 1080x1920, 최대 60초)
```bash
ffmpeg -y \
  -i input.mp4 \
  -vf "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920" \
  -c:v libx264 -preset ultrafast -crf 28 \
  -c:a aac -b:a 128k \
  -t 60 \
  output_short.mp4
```
- Shorts는 일반 영상 생성 후 변환 (별도 이미지 불필요)
- `--shorts` flag를 yt_upload.py에 전달

## YouTube OAuth 토큰 만료 문제

**문제:** `youtube_token.pickle` 토큰이 만료되면 `creds.valid: False`
- 2일 전 인증이면 이미 만료 가능
- 만료 시 업로드 타임아웃 발생 (Google 서버 응답 없음)

**해결:**
```python
import pickle, os
from google.auth.transport.requests import Request

TOKEN_FILE = os.path.expanduser("~/.hermes/secrets/youtube_token.pickle")

with open(TOKEN_FILE, "rb") as f:
    creds = pickle.load(f)
if not creds.valid:
    creds.refresh(Request())
    with open(TOKEN_FILE, "wb") as f:
        pickle.dump(creds, f)
    print("Token refreshed!")
```

**적용:** `yt_upload.py`의 `get_authenticated_service()` 호출 전에 실행.
크론 재실행 간격이 1시간 이상일 때 필수 (매번 체크하는 것이 안전).

## 임시 Python venv (google-api-python-client 설치 문제)

**환경 문제:** `pyodbc` 版本冲突으로 pip install 실패
**해결:** 독립 가상환경 생성
```bash
python3 -m venv /tmp/yt_upload_venv
/tmp/yt_upload_venv/bin/pip install --upgrade pip
/tmp/yt_upload_venv/bin/pip install google-api-python-client google-auth-oauthlib
```
**사용:** `/tmp/yt_upload_venv/bin/python3 yt_upload.py ...`