# 영상이 두 번째 이미지 시점부터 검은 화면 문제 (2026-05-25)

## 문제
3개 세그먼트(seg0/seg1/seg2)를 FFmpeg concat으로 합칠 때, 두 번째 이미지 전환 시점부터 검은 화면이 나오는 문제 발생.

## 원인 분석
- 세그먼트별 생성: 각 67.4초 (202.2초 ÷ 3)
- concat.txt 사용 → 오디오 mux 과정에서 원본 영상의 오디오 처리가 제대로 안 됨
- video_final.mp4에서 영상 길이는 202초이지만 실제 영상이 3.6초만 재생됨 (frame count 확인 완료)

## 해결 방법
concat 후 오디오 mux를 별도 단계로 분리하지 않고, 처음부터 video_final.mp4를 video_only.mp4 + audio.aac mux로 생성:

```bash
# Step 1: 세그먼트 concat
ffmpeg -y -f concat -safe 0 -i concat.txt \
  -c:v libx264 -preset fast -crf 23 \
  video_only.mp4

# Step 2: 오디오 mux (video_final = 202초)
ffmpeg -y -i video_only.mp4 -i music.mp3 \
  -map 0:v -map 1:a -c:v copy -c:a aac -b:a 192k \
  -shortest -movflags +faststart \
  video_final.mp4

# Step 3: 이퀄라이저 overlay
ffmpeg -y -i video_final.mp4 -stream_loop 1 -i equalizer.gif \
  -filter_complex "[0:v][1:v]overlay=W-500:H-180:shortest=1[composed]" \
  -map "[composed]" -map 0:a \
  -c:v libx264 -preset fast -crf 23 -c:a copy \
  -movflags +faststart video_wave.mp4
```

## 핵심 교훈
- concat 후 mux는 반드시 `-shortest` 사용 (영상이 오디오 길이에 맞춤)
- 영상 길이 확인: `ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 video.mp4`
- frame 수 확인: `ffprobe -v error -show_entries stream=nb_frames -of default=noprint_wrappers=1 video.mp4`
  - 202초 × 25fps = 5050프레임이 정상, 90프레임(3.6초)면 문제 있음