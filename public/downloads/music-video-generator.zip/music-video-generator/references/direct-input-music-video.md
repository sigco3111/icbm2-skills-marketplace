# 주제 직접 입력 뮤직비디오 제작 (2026-05-25)

Notion DB를 사용하지 않고家主님 직접 입력으로 뮤직비디오를 제작하는 완전한 워크플로우.

##家主님 입력 예시

```
불자로서부처님오신날을좋아하지않는다. 절에가면다양한부처님들이있는데
(관세음보살,지장보살,문수보살등...) 어떻게이위대한분들을부처님오신날이라고
퉁치는 걸까? 관세음보살님오시는날,지장보살님오시는날,문수보살님오시는날
로따로해휴일로해야한다.
```

## 제작流程 (단계별)

### 1. 가사 확장 (expand_lyrics)
```python
def expand_lyrics(text, target_chars=1800):
    """家主님 입력 가사를 3분 분량으로 자동 확장"""
    # 500자 미만은 생성 차단
```

### 2. 음악 생성
```bash
source ~/.hermes/secrets/minimax.env
mmx music generate \
  --api-key "$MINIMAX_API_KEY" \
  --prompt "upbeat pop, Korean female vocal, warm emotional, comedic witty lyrics, 120-140 BPM, Hook First structure" \
  --lyrics "$(cat << 'LYRICS'
[Chorus]
불자로서 부처님오신날을 좋아하지 않는다
...
LYRICS
)" \
  --out /tmp/bulsa_music_v2.mp3
```

### 3. 음악 길이 검증
```bash
ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 /tmp/bulsa_music_v2.mp3
# 180초(3분) 이상이어야 함. 미만이면 가사를 더 늘리고 재시도
```

### 4. 이미지 3개 생성
```bash
source ~/.hermes/secrets/minimax.env
mmx image generate --api-key "$MINIMAX_API_KEY" \
  --prompt "A photorealistic scene of a young Korean female vocalist performing energetically on a bright temple festival stage, colorful Korean Buddhist decorations, playful crowd, bright daylight, vivid saturated tones, high-key lighting" \
  --out /tmp/bulsa_img1.png

# img2, img3도 동일 방식으로
```

### 5. 영상 합성 (3구간 concat)
```bash
# seg1: img1, 0-90초
ffmpeg -y -loop 1 -i /tmp/bulsa_img1.png -i /tmp/bulsa_music.mp3 \
  -vf "scale=1280:720:force_original_aspect_ratio=increase,crop=1280:720" \
  -c:v libx264 -preset ultrafast -crf 28 -c:a aac -b:a 128k -t 90 \
  -movflags +faststart /tmp/seg1.mp4

# seg2: img2, 90-180초 (오디오 구간 추출 → 영상 변환 → mux)
ffmpeg -y -i /tmp/bulsa_music.mp3 -ss 90 -t 90 -acodec aac -b:a 128k /tmp/audio_seg2.aac
ffmpeg -y -loop 1 -i /tmp/bulsa_img2.png \
  -vf "scale=1280:720:force_original_aspect_ratio=increase,crop=1280:720" \
  -c:v libx264 -preset ultrafast -crf 28 -t 90 -r 25 \
  -movflags +faststart /tmp/seg2_raw.mp4
ffmpeg -y -i /tmp/seg2_raw.mp4 -i /tmp/audio_seg2.aac \
  -c:v copy -c:a copy -movflags +faststart /tmp/seg2.mp4

# seg3: img3, 180초-끝 (마지막 구간)
# 음악 길이에 맞춰 -t 값 조정

# concat
cat > /tmp/concat.txt << 'EOF'
file '/tmp/seg1.mp4'
file '/tmp/seg2.mp4'
file '/tmp/seg3.mp4'
EOF
ffmpeg -y -f concat -safe 0 -i /tmp/concat.txt \
  -c:v libx264 -preset ultrafast -crf 23 \
  -c:a aac -b:a 128k -movflags +faststart /tmp/bulsa_final.mp4
```

### 6. 이퀄라이저 GIF + 오버레이
```bash
# GIF 생성 (PIL)
python3 << 'PYEOF'
from PIL import Image, ImageDraw; import math, os
WAVE_DIR = "/tmp/bulsa_wave"; os.makedirs(WAVE_DIR, exist_ok=True)
w, h = 360, 120; num_bars = 20; bar_w = 12; bar_spacing = 6; margin_bottom = 15
colors = [(255,80,120),(200,80,180),(120,80,255),(80,150,255)]
import random; random.seed(42)
base_heights = [random.randint(30,80) for _ in range(num_bars)]
frames = []
for frame in range(30):
    img = Image.new('RGBA', (w, h), (0,0,0,0)); draw = ImageDraw.Draw(img)
    phase = frame * 0.3
    for i in range(num_bars):
        wave = math.sin(phase + i*0.4)*0.4+0.6
        bar_h = max(10, min(int(base_heights[i]*wave), h-margin_bottom-10))
        x = i*(bar_w+bar_spacing); y = h-margin_bottom-bar_h
        color_idx = int((i/num_bars)*(len(colors)-1))
        draw.rounded_rectangle([x,y,x+bar_w,h-margin_bottom], radius=4, fill=colors[min(color_idx, len(colors)-1)]+(220,))
    frames.append(img)
frames[0].save(f'{WAVE_DIR}/wave.gif', save_all=True, append_images=frames[1:], duration=int(1000/30), loop=0, optimize=False)
for f in frames: f.close()
PYEOF

# 오버레이
ffmpeg -y \
  -i /tmp/bulsa_final.mp4 \
  -stream_loop -1 -i /tmp/bulsa_wave/wave.gif \
  -filter_complex "[0:v][1:v] overlay=920:600:shortest=1:format=auto" \
  -c:v libx264 -preset ultrafast -crf 28 -c:a copy \
  -movflags +faststart /tmp/bulsa_wave_overlay.mp4
```

### 7. Shorts (3단계 분리)
```bash
# Step 1: 오디오 추출 59초
ffmpeg -y -i /tmp/bulsa_wave_overlay.mp4 -vn -c:a aac -b:a 128k -t 59 /tmp/sa1.aac

# Step 2: 영상 scale만
ffmpeg -y -i /tmp/bulsa_wave_overlay.mp4 -an \
  -vf "scale=720:-2" \
  -c:v libx264 -preset ultrafast -crf 28 -pix_fmt yuv420p -r 25 -t 59 \
  /tmp/sv1.mp4

# Step 3: pad로 9:16
ffmpeg -y -i /tmp/sv1.mp4 -an \
  -vf "pad=720:1280:0:(oh-ih)/2:black" \
  -c:v libx264 -preset ultrafast -crf 28 -pix_fmt yuv420p -t 59 \
  /tmp/sv2.mp4

# Step 4: mux
ffmpeg -y -i /tmp/sv2.mp4 -i /tmp/sa1.aac \
  -c:v copy -c:a copy -movflags +faststart /tmp/bulsa_short.mp4

ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 /tmp/bulsa_short.mp4
# 59초 이하 확인
```

## 검수 → 업로드

家主님이 파일을 직접 확인 후 '업로드' 회신 → `/usr/bin/python3` yt_upload.py로 실제 업로드.