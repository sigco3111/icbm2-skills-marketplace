# music_video_producer.py — 버그 fixes needed (2026-05-25)

## Bug 1: FFmpeg concat filter_complex 방식으로 3개 이미지 합성 시 1장만 반복

**현재 코드에 있는 잘못된 패턴:**
```python
filter_complex = (
    "[0:v]scale=1920:1080:force_original_aspect_ratio=increase,crop=1920:1080,"
    "zoompan=z='min(zoom+0.003,1.15)':d=1000:s=1920x1080:fps=30,"
    "setpts=PTS-STARTPTS+0/TB[v0];"
    "[1:v]scale=1920:1080:force_original_aspect_ratio=increase,crop=1920:1080,"
    "zoompan=z='min(zoom+0.003,1.12)':d=1000:s=1920x1080:fps=30,"
    "setpts=PTS+33.3/TB[v1];"
    "[2:v]scale=1920:1080:force_original_aspect_ratio=increase,crop=1920:1080,"
    "zoompan=z='min(zoom+0.003,1.10)':d=1000:s=1920x1080:fps=30,"
    "setpts=PTS+66.6/TB[v2];"
    "[v0][v1][v2]concat=n=3:v=1:a=0[video]"
)
```

**이 패턴은 이미지에서는 1장만 반복됨 — 버그!**

**대신 사용해야 할 방식:** `references/multi-image-ken-burns.md` 참고 — 개별 세그먼트 생성 후 concat.txt로 합성.

## Bug 2: Equalizer overlay가 동적 좌표가 아닌 고정 좌표 사용

**현재:** `overlay=W-500:H-180` — 이것은 맞음
**검토 필요:** add_wave_overlay() 함수가 W-500:H-180을 사용하는지 확인

## Bug 3: mmx image --out 파일명 버그

각 mmx image 생성 직후 `mv image_001.jpg image_X.png`으로 리네이밍 필수.
현재 코드에서 이를 수행하는지 확인.