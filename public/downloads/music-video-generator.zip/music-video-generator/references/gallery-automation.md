# Gallery Automation — Known Issues & Patterns

## gallery_data.json lyrics 필드 0 글자 문제 (2026-05-23)

`backup_to_gallery()` 호출 후 `gallery_data.json`의 `lyrics` 필드가 0 글자인 문제가 발생.

**확인 방법:**
```python
python3 -c "
import json
d=json.load(open('~/.hermes/music_videos/gallery_gh/gallery_data.json'))
e=d['entries'][0]
print('lyrics len:', len(e.get('lyrics','')), 'chars')
print('lyrics sample:', e.get('lyrics','')[:300])
"
```

**증상:**
```python
lyrics len: 0 chars
lyrics sample:
```

**원인 추정:**
1. `music_video_producer.py`에서 `backup_to_gallery()` 호출 시 lyrics 인자가 빈 문자열로 전달
2. Notion에서 가사를 읽어오는 단계에서 실패
3. 데이터 파이프라인 어디선가 가사가 유실

**확인 체크리스트:**
- [ ] Notion DB에서 `음악프롬프트` 블록 읽기 성공했는가?
- [ ] `filter_lyrics()` 적용 후 빈 문자열이 아닌가?
- [ ] `backup_to_gallery()`에 전체 가사가 전달되었는가?
- [ ] JSON 저장 직후 `json.dump()` 예외 없이 완료되었는가?

**해결 방향:**
- 가사 파이프라인 전체 로깅 추가
- 각 단계별 가사 길이 로그 출력
- 0글자 시Exception 발생시켜 원인 추적