# 세탁기에서 사라진 양말 — 후렴 선행형 뮤직비디오 생성 로그

**생성일:** 2026-05-24
**주제:** 세탁기에서 사라진 양말 (세탁소 → 세탁기로 수정)
**분위기:** 유머러스한
**곡 구조:** 후렴 선행형 (Hook First / Immediate Chorus)

---

## 생성 결과

| 항목 | 값 |
|------|-----|
| 음악 길이 | 167.9초 (2분 48초) |
| 이미지 수 | 3장 |
| 세그먼트당 길이 | ~56초 |
| 메인 영상 | 1280×720, 9.9MB |
| Shorts | 1080×1920, 59초, 3.4MB |
| 이퀄라이저 | 투명 GIF 오버레이 (RGBA, 360×120) |

---

## mmx 음악 생성 (확인된 패턴)

**가사 길이 → 생성 길이:**
- 1,000자 이하: 70~100초 (너무 짧음)
- 1,500자+: 3분+ (167초 확인됨)

**핵심:** `--lyrics-optimizer` 사용 시 자동 생성이라 통제 불가. 반드시 `--lyrics` 직접 전달 + `expand_lyrics()` 함수로 1,500자 이상 확보.

```bash
mmx music generate \
  --api-key "$MINIMAX_API_KEY" \
  --prompt "upbeat pop, fun comedic mood, Korean female vocal..." \
  --lyrics "[Chorus]
세탁기 돌아가고 아무 생각 없이 텐션 올리던 Tuesday night
..."

# ❌ --duration 파라미터 없음 (작동 안 함)
# ✅ 가사 양으로 길이 조절
```

**후렴 선행형 가사 구조 (확인됨):**
```
[Chorus]  ← 가장 먼저
"세탁기야 제발 내 양말 좀 돌려줘..."

[Verse 1]
흰 양말 한 짝이 분명 안에서 춤추듯 활발했는데...

[Chorus]
...

[Verse 2]
...

[Chorus] ← 후렴 반복
```

---

## Python PIL 투명 GIF 이퀄라이저 (확인된 구현)

```python
from PIL import Image, ImageDraw
import math, os, random

def create_wave_animation_frames(output_path, width=360, height=120, num_frames=30, fps=30):
    num_bars = 20
    bar_w = 12
    bar_spacing = 6
    margin_bottom = 15

    colors = [
        (255, 80, 120),   # 핑크
        (200, 80, 180),   # 보라
        (120, 80, 255),   # 블루
        (80, 150, 255),   # 스카이
    ]

    random.seed(42)
    base_heights = [random.randint(30, 80) for _ in range(num_bars)]

    frames = []
    for frame in range(num_frames):
        img = Image.new('RGBA', (width, height), (0, 0, 0, 0))  # 투명 배경
        draw = ImageDraw.Draw(img)
        phase = frame * 0.3

        for i in range(num_bars):
            wave = math.sin(phase + i * 0.4) * 0.4 + 0.6
            bar_h = int(base_heights[i] * wave)
            bar_h = max(10, min(bar_h, height - margin_bottom - 10))

            x = i * (bar_w + bar_spacing)
            y = height - margin_bottom - bar_h

            color_idx = int((i / num_bars) * (len(colors) - 1))
            color = colors[min(color_idx, len(colors) - 1)]

            draw.rounded_rectangle([x, y, x + bar_w, height - margin_bottom],
                                  radius=4, fill=color + (220,))
        frames.append(img)

    frames[0].save(
        output_path,
        save_all=True,
        append_images=frames[1:],
        duration=int(1000/fps),
        loop=0,
        optimize=False
    )
    for f in frames:
        f.close()
```

**RGBA GIF의 핵심:** `Image.new('RGBA', ..., (0,0,0,0))` — 세 번째 채널 0이 투명도. PNG와 달리 GIF는 투명 팔레트인데, RGBA模式下에서 저장하면 투명도가 유지됨.

**저장 경로:** `~/.hermes/music_videos/wave_animation.gif` (재사용)

---

## FFmpeg 이퀄라이저 오버레이 (확인된 명령)

```bash
ffmpeg -y \
  -i video_wave.mp4 \
  -stream_loop -1 -i wave_animation.gif \
  -filter_complex "[0:v][1:v] overlay=920:600:shortest=1" \
  -c:v libx264 -preset ultrafast -crf 23 \
  -c:a copy \
  output_with_wave.mp4
```

**핵심:** `overlay=920:600` — 영상 1280×720 기준 우측 하단. `shortest=1`으로 영상 길이에 자동 맞춤.

---

## 3이미지 세그먼트 영상 파이프라인

```
음악.mp3 (167초)
  └── 3등분 (각 ~56초)
        ├── 세그먼트1: image_0.png + audio_1.mp3 → seg_1.mp4
        ├── 세그먼트2: image_1.png + audio_2.mp3 → seg_2.mp4
        └── 세그먼트3: image_2.png + audio_3.mp3 → seg_3.mp4
              └── ffmpeg concat → video.mp4
```

**주의:** `-shortest`와 `-t` 동시 사용 시 충돌 가능. 세그먼트별 `-t` 사용 권장.

---

## 주제 제안 → 선택 → Notion 등록 → 생성까지 흐름

```
1. 사용자에게 5개 주제 제안 (유머러스한 것 위주)
2. 사용자 선택 (수정 포함: "세탁소" → "세탁기")
3. Notion DB에 "대기" 또는 "승인" 상태로 등록
4. mmx image × 3 (cute cartoon, pastel, kawaii)
5. mmx music generate --lyrics (1,500자+)
6. Python PIL 이퀄라이저 GIF
7. FFmpeg 세그먼트 합성 + 오버레이
8. FFmpeg Shorts (9:16, 59초)
9. 파일 전송 or Cloudflare Tunnel 검수
```