# YouTube Direct Upload (No google-auth)

google-auth / google-api-python-client 설치 문제 시, requests만으로 YouTube에 업로드하는 방법.

## 상황

- `pip install` 실패 (pyodbc 충돌, Python 3.8 EOL 등)
- `google.auth._regional_access_boundary_utils` ModuleNotFoundError
- YouTube OAuth 토큰은 있는데 google-auth로 파싱 불가

## 해결책: 토큰만 직접 추출

```python
import os, json, requests

TOKEN_FILE = os.path.expanduser("~/.hermes/secrets/youtube_token.pickle")
CLIENT_FILE = os.path.expanduser("~/.hermes/secrets/client_secret_1088895812408-fa0fjavjisgfdaubidspvegqk0harjqg.apps.googleusercontent.com.json")

with open(TOKEN_FILE, 'rb') as f:
    data = f.read()

# Access token 추출 (pickle 바이트에서 ya29. 찾기)
token_start = data.find(b'ya29.')
token_end = data.find(b'\x94', token_start + 30)
access_token = data[token_start:token_end].decode('utf-8', errors='replace')

# Refresh token 추출
refresh_start = data.find(b'1//')
refresh_end = data.find(b'\x94', refresh_start + 20)
refresh_token = data[refresh_start:refresh_end].decode('utf-8', errors='replace')

with open(CLIENT_FILE) as f:
    client = json.load(f)

# 토큰 갱신
resp = requests.post("https://oauth2.googleapis.com/token", data={
    "client_id": client['installed']['client_id'],
    "client_secret": client['installed']['client_secret'],
    "refresh_token": refresh_token,
    "grant_type": "refresh_token"
})
token = resp.json()['access_token']
```

## 업로드 프로토콜 (Resumable Upload)

```python
# 1. 업로드 초기화
file_size = os.path.getsize(file_path)
body = json.dumps({
    "snippet": {
        "title": "제목",
        "description": "설명",
        "tags": ["태그1", "태그2"],
        "categoryId": "24"
    },
    "status": {"privacyStatus": "public", "selfDeclaredMadeForKids": False}
})

resp = requests.post(
    "https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status",
    headers={
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "X-Upload-Content-Type": "video/mp4",
        "X-Upload-Content-Length": str(file_size),
    },
    data=body.encode('utf-8')
)

location = resp.headers.get('location', '')  # 이 URL로 PUT

# 2. 파일 업로드
with open(file_path, 'rb') as f:
    video_data = f.read()

resp2 = requests.put(location, headers={
    "Authorization": f"Bearer {token}",
    "Content-Type": "video/mp4",
}, data=video_data)

# 3. 완료
video_id = resp2.json()['id']
print(f"https://www.youtube.com/watch?v={video_id}")
```

##Quota 초과 (429)

하루 6개 영상 제한. 초과 시:
```
429: "Quota exceeded for quota metric 'Video Uploads' and limit
'Video Uploads per day' ... quota_limit_value: 6"
```
파일은 로컬에 보관하고 다음 날 재시도.

## 403 Insufficient Permission

`channels?mine=true` 호출 시 403 발생하지만 **업로드는 정상 작동**. 
upload init (`/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status`)은 200 반환.