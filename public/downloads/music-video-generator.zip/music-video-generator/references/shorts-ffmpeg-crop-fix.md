# Shorts FFmpeg Crop Fix (2026-05-25)

## 문제

macOS FFmpeg 4.3.2에서 일반적인 Shorts 제작 명령이 실패:
```
# ❌ 모두 실패
ffmpeg -i input.mp4 -vf "scale=1920:1080,crop=1080:1920" ...   # Invalid argument
ffmpeg -i input.mp4 -vf "crop=1080:1920" ...                   # Failed to inject frame
ffmpeg -i input.mp4 -vf "scale=-2:1080,crop=1080:1920" ...    # Failed to inject frame
```

## 원인

원본 영상 (1280×720, pix_fmt: yuvj420p, Constrained Baseline profile)의 SAR/DAR 불일치가 필터 체인 초기화를 깨뜨림. `-an` 없이 필터 체인만 적용하면 실패.

## 검증된 3단계 Working 방법

```python
def make_shorts(in_path, out_path):
    audio_aac = out_path.replace(".mp4", "_audio.aac")
    tmp_video = out_path.replace(".mp4", "_raw.mp4")

    # Step 1: 오디오 추출 (demux — 가장 안전)
    subprocess.run([
        "ffmpeg", "-y", "-i", in_path,
        "-vn", "-c:a", "copy", "-t", "59", audio_aac
    ], capture_output=True, text=True, timeout=60)

    # Step 2: 영상만 9:16 세로로 변환 (scale+pady+crop → 이 순서만 가능)
    subprocess.run([
        "ffmpeg", "-y", "-i", in_path, "-an",
        "-vf", "scale=720:-2,pad=720:1280:0:(oh-ih)/2:black",
        "-c:v", "libx264", "-preset", "ultrafast", "-crf", "28",
        "-pix_fmt", "yuv420p", "-r", "25", "-t", "59", tmp_video
    ], capture_output=True, text=True, timeout=120)

    # Step 3: 영상 + 오디오 mux
    subprocess.run([
        "ffmpeg", "-y", "-i", tmp_video, "-i", audio_aac,
        "-c:v", "copy", "-c:a", "copy",
        "-movflags", "+faststart", out_path
    ], capture_output=True, text=True, timeout=60)

    # cleanup
    for f in [audio_aac, tmp_video]:
        try: os.remove(f)
        except: pass
```

## 한 줄 Bash 명령 (순서대로 실행)

```bash
INPUT=video.mp4
OUT=short.mp4

# 1. 오디오 추출
ffmpeg -y -i $INPUT -vn -c:a copy -t 59 ${OUT}_audio.aac

# 2. 영상 변환 (scale → pad → crop 같은 효과)
ffmpeg -y -i $INPUT -an \
  -vf "scale=720:-2,pad=720:1280:0:(oh-ih)/2:black" \
  -c:v libx264 -preset ultrafast -crf 28 \
  -pix_fmt yuv420p -r 25 -t 59 ${OUT}_raw.mp4

# 3. Mux
ffmpeg -y -i ${OUT}_raw.mp4 -i ${OUT}_audio.aac \
  -c:v copy -c:a copy -movflags +faststart $OUT

# 4. 정리
rm -f ${OUT}_audio.aac ${OUT}_raw.mp4
```

## 핵심 키

1. **반드시 오디오와 영상을 분리** — `scale/crop` 필터가 오디오와 공존할 때 실패
2. **scale先用** (`720:-2`) → 그 결과에 **pad** 추가 → 최종 720×1280
3. **pad 값이 정확**: `pad=720:1280` — FFmpeg pad는 출력 해상도 기준
4. **crop 필터 직접 사용 금지** — scale+pad 조합으로 동일한 효과 달성

## 트러블슈팅

| 증상 | 해결 |
|------|------|
| `Failed to inject frame` | scale+pad로 대체, crop 필터 사용 금지 |
| `non positive size for width` | pad 인자 순서 확인: `pad=w:h:x:y` |
| 오디오影音不同步 | mux 단계에서 `-c:a copy` 대신 re-encode: `-c:a aac -b:a 128k` |
| 生成된 영상 재생 불가 | `-pix_fmt yuv420p` 추가 및 `-movflags +faststart` 필수 |