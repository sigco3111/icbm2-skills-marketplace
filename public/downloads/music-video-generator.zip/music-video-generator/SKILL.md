---
name: music-video-generator
description: MiniMax CLI(mmx) 기반 뮤직비디오 자동 생성 파이프라인 — 주제 생성 → 이미지/음악/이퀄라이저 → YouTube 업로드(일반 영상 + Shorts). 주인님 직접 검토 후 진행하는 승인 루프 포함.
trigger: "music video generator mmx image music youtube shorts automation"
---

# Music Video Generator (mmx-cli 기반)

MiniMax CLI(mmx-cli)를 사용하여 자동으로 뮤직비디오를 생성하고 YouTube에 업로드하는 파이프라인.

## Architecture

```
오전 Cron (09:00)
  → 테마 3개 생성 → Notion DB 등록 → Telegram 알림
  → 주인님 검토 → 피드백 없으면 자동 진행

 Cron (3회/일, 주인님 승인 후)
  → mmx image (배경 이미지)
  → mmx music (한국어 여성 보컬 음악)
  → FFmpeg 이퀄라이저 애니메이션
  → FFmpeg 합성 (이미지 + 이퀄라이저 + 음악)
  → yt_upload.py (일반 영상 + Shorts 세트)
```

## 사전 요구사항

- `mmx` CLI 설치済み (`npm install -g mmx-cli`)
- Notion API Key (`NOTION_API_KEY`)
- YouTube OAuth 토큰 (`~/.hermes/secrets/youtube_token.pickle`)
- FFmpeg 설치済み

## ⚠️ Plus ($20/月) 플랜 제약

| 기능 | Plus ($20) | 권장 대안 |
|------|-----------|---------|
| **Hailuo 영상 생성** | ❌ 없음 | 이미지 + 이퀄라이저 애니메이션으로 시각적 충실도 확보 |
| **Music-2.6** | ✅ 100곡/일 | |
| **image-01** | ✅ 50장/일 | |
| **Speech 2.8** | ✅ 4,000글자/일 | |

**핵심 제약:** Plus 플랜에는 Hailuo-2.3 비디오 생성 기능이 없음.
대안으로 **배경 이미지 + 이퀄라이저 바 애니메이션**을 FFmpeg로 합성하여 뮤직비디오 수준의 시각적 콘텐츠를 만드는 방법을 사용한다.

## ⚠️ 알려진 함정: 가사 미전달 버그

`music_video_producer.py`의 초기 구현에서 음악 프롬프트에 **가사가 제대로 전달되지 않는 문제**가 있음.
Notion에 주제를 등록할 때 가사를 "음악프롬프트" 자식 블록에 저장하지만, `mmx music generate` 호출 시 해당 가사가 music prompt 필드에 포함되지 않는 경우가 있음.

**해결 방법:**
1. Cronjob 스크립트에서 Notion 자식 블록(가사)을 읽어서 music prompt에 수동 병합
2. 또는 주제 등록 시 가사를 "음악프롬프트" 속성 본문에 직접 삽입 (자식 블록 ❌)
3. 테스트: `mmx music generate` 후 생성된 음악의 가사를 들고 직접 확인

## mmx CLI 사용 패턴 (확인됨 2026-05-23) — `references/youtube-upload-fix.md`, `references/minimax-music-cli.md` 참고

### API Key 설정
```bash
source ~/.hermes/secrets/minimax.env
mmx image generate --api-key "$MINIMAX_API_KEY" --prompt "..." --out output.png
mmx music generate --api-key "$MINIMAX_API_KEY" --prompt "..." --lyrics "..." --out output.mp3
```

### 이미지 생성
- 모델: `image-01`
- `--api-key "$MINIMAX_API_KEY"` 필수 (env만 있어도 `--api-key` 없으면 `No credentials found` 에러)
- `--out` 경로 지정

### 음악 생성 — 3분 이상 만들기 (확인됨 2026-05-23)
**`--duration` 파라미터 없음** — 작동하지 않음.

**방법: expand_lyrics() 함수로 자동 확장** (109자 → 1,591자 확인)

`music_video_producer.py`에 구현된 `expand_lyrics()` 함수가 구조 태그를 인식해서 가사를 자동 확장합니다:

```python
STRUCTURE_TAGS = ['Verse', 'Chorus', 'Bridge', 'Pre-Chorus', 'Intro', 'Outro']

def expand_lyrics(text, target_chars=1500):
    """짧은 가사를 3분 분량(~1500자)으로 자동 확장
    - 구조 태그 [Verse], [Chorus] 등 인식
    - 섹션별 내용 분리 후 반복 추가
    - target_chars 도달 시停止 (max 50 iterations)
    """
    # 1. [Verse], [Chorus] 등 태그를 찾아서 섹션별 내용 파싱
    # 2. 원본 가사 뒤에 반복 섹션 추가
    # 3. 1500자 도달 시 종료
```

**mmx_music() 호출 전 적용:**
```python
lyrics = expand_lyrics(raw_lyrics, target_chars=1500)  # 3분 목표
```

**이전 수동 방식 (더 이상 사용 안 함):**
- section마다 bar 수 명시하는 수동 방식 → `expand_lyrics()` 자동화로 대체 (2026-05-23)

### FFmpeg 이미지→영상 변환 (3분 이상 영상 대응 — 확인됨 2026-05-23)
**일반 영상 (16:9, 1280x720, 음악 길이에 맞춤)**
```bash
ffmpeg -y \
  -loop 1 -i image.png \
  -i audio.mp3 \
  -vf "scale=1280:720:force_original_aspect_ratio=increase,crop=1280:720" \
  -c:v libx264 -preset ultrafast -crf 28 \
  -c:a aac -b:a 128k \
  -movflags +faststart \
  -shortest \
  output.mp4
```
- **`-preset ultrafast -crf 28`**: medium 대비 인코딩 2배 이상 빠름 (3분 영상 ~3분 소요)
- **`-shortest`**:音频 길이에 맞춰 영상 자동 종료 (手動 `-t` 불필요)
- **`-movflags +faststart`**: YouTube 업로드 "파일을 처리할 수 없음" 오류 방지 — 반드시 포함
- 3분 영상 인코딩: 약 3분 소요 (medium: 7분+, ultrafast: 3분)

### YouTube 업로드 스크립트
```bash
# 실행 방법 (positional file_path 먼저)
python3 yt_upload.py /path/to/video.mp4 \
  --title "제목" \
  --description "설명" \
  --tags "태그1,태그2" \
  --privacy public

# google-api-python-client가 conda/pyodbc 충돌로 설치 안 되면 → 수동 업로드 또는 curl API 호출
# /tmp/yt_upload_venv/bin/python3 yt_upload.py ...
```

### YouTube OAuth 토큰 자동 갱신 (매업로드 전 실행)

YouTube OAuth 토큰은 만료일이 있으며, 만료되면 API 호출 시 `creds.valid: False`가 됨.
**매업로드 전에 토큰을 확인하고 필요시 갱신하는 로직을 스크립트에 포함해야 함:**

```python
import pickle, os
from google.auth.transport.requests import Request

TOKEN_FILE = os.path.expanduser("~/.hermes/secrets/youtube_token.pickle")

def refresh_token_if_needed():
    with open(TOKEN_FILE, "rb") as f:
        creds = pickle.load(f)
    if not creds.valid:
        creds.refresh(Request())
        with open(TOKEN_FILE, "wb") as f:
            pickle.dump(creds, f)
        print("Token refreshed and saved!")
    return creds
```

이 로직을 `yt_upload.py`의 `get_authenticated_service()` 함수 앞에 삽입하면 토큰 만료로 인한 업로드 실패를 방지할 수 있음. 크론 재실행 간격이 길 때(>1시간) 특히 필수.

### YouTube OAuth 토큰 자동 갱신 (매업로드 전 실행)

YouTube OAuth 토큰은 만료일이 있으며, 만료되면 API 호출 시 `creds.valid: False`가 됨.
**매업로드 전에 토큰을 확인하고 필요시 갱신하는 로직을 스크립트에 포함해야 함:**

```python
import pickle, os
from google.auth.transport.requests import Request

TOKEN_FILE = os.path.expanduser("~/.hermes/secrets/youtube_token.pickle")

def refresh_token_if_needed():
    with open(TOKEN_FILE, "rb") as f:
        creds = pickle.load(f)
    if not creds.valid:
        creds.refresh(Request())
        with open(TOKEN_FILE, "wb") as f:
            pickle.dump(creds, f)
        print("Token refreshed and saved!")
    return creds
```

이 로직을 `yt_upload.py`의 `get_authenticated_service()` 함수 앞에 삽입하면 토큰 만료로 인한 업로드 실패를 방지할 수 있음. 크론 재실행 간격이 길 때(>1시간) 특히 필수.

**사용자 Python 환경 문제:** `pyodbc` 版本冲突으로 `pip install google-api-python-client` 실패 → `/tmp/yt_upload_venv`에 독립 가상환경 생성해서 사용 중. 스크립트 실행 시 이 venv 경로 우선 사용.

## ⚠️ YouTube 일일 Quota 초과 + 토큰 추출 패턴 (발견됨 2026-05-23)

**429 Quota Exceeded — 하루 6개 영상 제한:**
```
"code": 429, "message": "Quota exceeded for quota metric 'Video Uploads' and limit
'Video Uploads per day' of service 'youtube.googleapis.com'
for consumer 'project_number:1088895812408'
quota_limit_value: 6"
```
오늘 업로드: 고양이ICloud 3개 + 서울 시리즈 3개 = **6개 소진**. quota 리셋 전까지 모든 업로드 실패. 파일은 항상 로컬에 보관 → 다음 날 재시도.

**403 Insufficient Permission — upload scope는 정상 작동:**
`channels?mine=true` 호출 시 403 발생 → 하지만 `uploadType=resumable&part=snippet,status` POST는 200 반환. **업로드 자체는 정상**.

**google-auth 없는 환경에서 토큰 추출 (requests만으로 YouTube 업로드):**
pickle 파일을 google-auth 라이브러리 없이 파싱:
```python
with open(TOKEN_FILE, 'rb') as f:
    data = f.read()
access_token = data[data.find(b'ya29.'):data.find(b'\x94', data.find(b'ya29.')+30)].decode('utf-8')
refresh_token = data[data.find(b'1//'):data.find(b'\x94', data.find(b'1//')+20)].decode('utf-8')
# OAuth refresh
resp = requests.post("https://oauth2.googleapis.com/token", data={
    "client_id": client['installed']['client_id'],
    "client_secret": client['installed']['client_secret'],
    "refresh_token": refresh_token, "grant_type": "refresh_token"
})
token = resp.json()['access_token']
```

**⚠️ gallery_data.json URL 필드 오염 버그 (발견됨 2026-05-23):**
업로드 스크립트 로그 메시지가 `youtube_url`/`short_url`에 그대로 저장됨.
`"Uploading: ...\nSUCCESS: https://..."` → HTML 렌더링 시 페이지 무한 로딩.
**해결:** youtube_url/short_url에는 실제 URL만 저장. 로그 메시지 절대 금지.
→ 상세: `references/youtube-direct-upload.md`

---

## ⚠️ mmx CLI API Key 누락 버그 (발견됨 2026-05-23)

`mmx image`와 `mmx music` 모두 **반드시 `--api-key` 파라미터 필요**. env만 설정되어 있어도 `--api-key` 없으면 `No credentials found` 에러 발생.

**올바른 호출:**
```bash
# 이미지 생성
mmx image generate --api-key "$MINIMAX_API_KEY" --prompt "..." --out output.png

# 음악 생성
mmx music generate --api-key "$MINIMAX_API_KEY" --prompt "..." --lyrics "..." --out output.mp3
```

**Python 함수에서:**
```python
def mmx_image(prompt, output_path):
    api_key = os.environ.get("MINIMAX_API_KEY", "")
    cmd = ["mmx", "image", "generate", "--api-key", api_key, "--prompt", prompt, "--out", output_path]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
    return result.returncode == 0

def mmx_music(prompt_with_lyrics, output_path):
    api_key = os.environ.get("MINIMAX_API_KEY", "")
    # ... 가사 필터링 ...
    cmd = ["mmx", "music", "generate", "--api-key", api_key, "--prompt", style_prompt, "--out", output_path]
    # ...
```

## ⚠️ yt_upload.py 인자 형식 버그 (발견됨 2026-05-23)

`yt_upload.py`는 **positional arguments가 아니라 named arguments**를 사용. `music_video_producer.py`의 `upload_youtube()` 함수가 잘못된 형식으로 호출해서 업로드 실패.

**버그:**
```python
# ❌ 잘못됨 - positional arguments
cmd = [venv_python, script, video_path, title, description]
```

**수정:**
```python
# ✅ 올바름 - named arguments
cmd = [venv_python, script, video_path, "--title", title, "--description", description]
```

## ⚠️ YouTube OAuth 토큰 만료 시 자동 갱신 (확인됨 2026-05-23)

YouTube OAuth 토큰이 만료되면 API 호출 시 `creds.valid: False` → 업로드 실패.

**증상:** `"Token valid: False"` 출력 후 업로드 오류

**수동 갱신 방법:**
```bash
/tmp/yt_upload_venv/bin/python3 -c "
import pickle, os
from google.auth.transport.requests import Request
TOKEN_FILE = os.path.expanduser('~/.hermes/secrets/youtube_token.pickle')
with open(TOKEN_FILE, 'rb') as f:
    creds = pickle.load(f)
if not creds.valid:
    creds.refresh(Request())
    with open(TOKEN_FILE, 'wb') as f:
        pickle.dump(creds, f)
    print('Token refreshed!')
"
```

**자동 갱신 로직:** `yt_upload.py`의 `get_authenticated_service()` 앞에 토큰 유효성 검사 + 필요시 갱신 로직 삽입.

## 파이프라인 상세

### Phase 1: 테마 생성 (매일 09:00 Cron)

1. **테마 3개 생성**:
- 장르, 분위기, 시각 스타일, 영상 색감, 음악 장르 등을 랜덤 조합
- 각 테마: `{theme_name, genre, mood, visual_style, color_palette, music_prompt, image_prompt}`
- 음악 스타일 가중치: 우타이테풍 30%, K-pop ballad 40%, acoustic pop 20%, lo-fi 10% (플레이리스트 기반)
   - 한국어 여성 보컬 반영: music prompt에 `"Korean female vocal, warm tone"` 포함

2. **Notion DB 등록**:
   - DB: `MUSIC_VIDEO_THEMES` (새로 생성)
   - Property: Name(title), Status(select: 대기/승인/진행/완료), Genre(text), Mood(text), VisualStyle(text), ColorPalette(text), MusicPrompt(text), ImagePrompt(text), CreatedAt(date)

3. **Telegram 알림**:
   ```
   🎵 뮤직비디오候選 (3개)
   1. [{theme_name}] — {genre} / {mood}
   2. [{theme_name}] — {genre} / {mood}
   3. [{theme_name}] — {genre} / {mood}
   검토 후 16:00에 자동으로 진행됩니다.
   피드백 있으시면 지금 말씀해주세요.
   ```

### Phase 2: 진행 (승인 또는 16:00 자동)

**각 테마별 순차 진행:**

1. **이미지 생성**:
   ```bash
   mmx image "A {visual_style} scene, {color_palette}, cinematic lighting"
   ```

2. **음악 생성** (한국어 여성 보ocal 필수):
   ```bash
   mmx music generate \
     --prompt "{genre}, {mood}, Korean female vocal, warm emotional" \
     --out /tmp/music_video/theme_1.mp3
   ```

3. **이퀄라이저 애니메이션 생성** (FFmpeg):
   - 음악 길이에 맞춰 이퀄라이저 바 애니메이션 생성
   - 색상: `{color_palette}`에 맞게

4. **합성**:
   - 배경 이미지 + 이퀄라이저 overlay
   - 배경 이미지를 동영상으로 확장(슬라이드쇼 효과)
   - 음악과 동기화

5. **Shorts 제작**:
   - 같은 콘텐츠의 9:16 세로형 버전
   - 59초 이하

6. **YouTube 업로드** (일반 영상 + Shorts **세트**)

## ⚠️ 주제 출처 구분: 블로그용 vs 뮤직비디오용 (2026-05-23 추가)

**뮤직비디오 주제는 별도 Notion DB에서 관리** (Blog/Tistory 발행용 주제와 다름)
- Notion DB: `36976f2e-9097-81e1-a373-e06f2da6e99c`
- 스크립트: `~/.hermes/scripts/music_video_producer.py`
- **블로그 발행용 주제(긱뉴스 기반)와 다름** — 혼동하지 말 것

### 뉴스 주제 중 뮤직비디오로 적합한 조건

| ✅ 적합 (유머/위트+감성) | ❌ 부적합 (건式/기술적) |
|------------------------|----------------------|
| AI가 그림을盗作해서 법정 논쟁 | LLM 아키텍처 동향 (KV 공유) |
| 고양이 사진으로 Face ID解除 | 에이전트용 프로그래밍 언어 |
| 자율주행차가 표지판 오해 | 메모리 부족으로 가전 가격 재조정 |
| 현관 열쇠가 17개가 된 사연 | Firefox Web Serial 지원 발표 |

**핵심 기준:**
- **유머/위트**: 보는 사람이 웃을 수 있는 상황
- **공감**: "나도 저랬을 수 있다"는 공감대
- **구체적 시나리오**: 실제 벌어질 수 있는 상황
- **감정적 후렴**: 한 문장으로 정리되는 웃긴/감성적 결말

### ⚠️ 이미지 스타일 — 밝고 귀여운 cartoon/kawaii 필수 (2026-05-23)

**주인님 절대 요구사항:** 생성된 이미지가 "좀 무섭게 나왔다"는 피드백 이후, 모든 뮤직비디오 이미지는 **밝고 귀여운 cartoon/kawaii 스타일**로 생성해야 함.

| ❌ 피할 이미지 스타일 | ✅ 사용할 이미지 스타일 |
|---------------------|---------------------|
| 다크한暗黒스타일 | 밝은 파스텔 컬러 |
| 무섭거나 섬뜩한 분위기 |可爱的 캐릭터 |
|写实적인恐怖영화 | kawaii/귀여운 캐리커터 |
| 어두운 사이버펑크 | 컬러풀한 네온 라이트 |

**Notion 이미지프롬프트 작성 규칙:**
- `cute cartoon style`, `kawaii`, `pastel colors`, `adorable characters` 반드시 포함
- `dark`, `scary`, `horror`, `gloomy`, `eerie` 절대 사용 ❌
- 예시: `"Cute cartoon gallery with colorful paintings, playful AI robots, bright sunny atmosphere, kawaii style, pastel colors"`

### ❌ 피할候選 유형
- 무역협상, 펀드 출시, 스테로이드 올림픽 gibi 건式 주제
- 기술적 깊이가 있는 AI/ML 동향 (KV sharing, mHC, 압축 어텐션等)
- 정책/금융 지표 기반 주제

## 주제 선정 시 ⚠️ 주의 (2026-05-23)

**주인님 직접 피드백:** "오늘의 뮤직비디오 주제가 좀 별로임. 유머와 위트를 첨부할만한 주제로 다시 찾아줘"

현재 Notion DB候選 중 **스테로이드 올림픽**은 ❌ 부적합으로 분류된 주제가 섞여 있음.
건式/정치/스포츠 주제는 뮤직비디오로 재미없음.

**체크리스트:** 주제를 등록하기 전 반드시自問
1. ✅ 이 주제를 보면 **사람이 웃을 수 있는가**?
2. ✅ **구체적 시나리오**가 있는가 (추상적 명사 ❌)?
3. ✅ **공감/경험**을 유발하는가?
4. ✅ ❌ 무역협상, 펀드출시, 올림픽, 정치협상 같은 **건式주제**인가?

answered: No → 등록하지 말 것

**랜덤 조합 패턴:**
- `visual_styles`: cyberpunk city, aurora borealis, neon rain, vintage cinema, cosmic landscape, forest silhouette, ocean waves, mountain peaks
- `color_palettes`: neon blue/pink, warm sunset orange, deep purple/violet, monochromatic blue, golden hour, teal/cyan
- `genres`: synthwave, lo-fi jazz, ambient orchestral, chillhop, acoustic pop, cinematic epic
- `moods`: nostalgic, dreamy, energetic, melancholic, hopeful, mysterious, **comedic, hilarious, ironic**

## 한국어 여성 보컬 강제 적용

모든 music 생성 prompt에 반드시 포함:
```
"Korean female vocal, warm emotional tone"
```
**가사:** 한국어로만 작성 (일본어/한자 ❌), 유머와 위트 포함, 뉴스 주제 기반으로 감정 표현 풍부하게

这不是选项 —主人的 절대 요구사항.

## Shorts 제작 규격

- 9:16 세로형 (1080×1920)
- 59초 이하
- **Letterbox** 배경 사용 (블러 배경 위아래 채움)

## YouTube 설명 템플릿

```markdown
🎵 {theme_name} — {genre}

🎬 Music Video generated by ICBM2
🎤 Korean Female Vocal / {mood} mood

#MusicVideo #AI #KoreanVocal #mmx #ICBM
```

## ⚠️ 가사 필터링 — 한국어/영어만 허용 (확인됨 2026-05-23)

Notion의 음악프롬프트에 한자/일본어가 섞여 있으면 음악 생성 시 문제가 생김.
**음악 생성 전 가사에서 한자/일본어/기타 문자를 제거하는 함수를 반드시 사용:**

```python
import re

def filter_lyrics(text):
    """한국어(가-힣) + 영어 + 기본 punctuation만 남기고 제거"""
    filtered = re.sub(r'[^\uAC00-\uD7A3a-zA-Z0-9\s.,!?~()\-\'\"]+', '', text)
    filtered = re.sub(r'\s+', ' ', filtered).strip()
    return filtered
```

**적용 패턴:**
- Notion에서 `음악프롬프트` 읽기 → `filter_lyrics()` 적용 → `mmx music generate --lyrics` 전달
- Japanese/Chinese 섹션 마커는 유지 (`[Verse 1]`, `[Chorus]` 등 영어 태그만 허용)
- 실제 가사 내용에서 한자/일본어 제거 후 한국어만 남김

**테스트:**
```
원본: 골목 끝 네온불빛이 반짝여...街灯の下で二人歩いた... 우리만의秘密の夜
필터후: 골목 끝 네온불빛이 반짝여... 우리만의  (한자/일본어 제거됨)
```

**⚠️ mmx image 생성 — 출력 경로 문제 (발견됨 2026-05-23)**
`mmx image generate --out /path/to/output.png`을 실행해도 이미지가 다른 위치에 저장되는 경우가 있음:
- 지정한 `--out` 경로가 아닌 현재 디렉토리에 저장
- `.openclaw/workspace/` 폴더에 저장되는 경우도 있음

**확인 방법:** 생성 후 지정한 경로에 파일이 실제로 있는지 반드시 확인
```bash
ls -la /path/to/output.png  # 파일 없으면 다른 곳에서 찾기
find ~/.hermes -name "output.png" -newer /tmp/check  # 탐색
```

**대안:** `--out`을 반드시 현재 작업 디렉토리 기준의 절대경로로 지정하고, 생성 직후 파일 존재 확인. 없으면 해당 디렉토리에서 다시 검색.

### mmx image --out 경로 문제 (2026-05-23)
`--out` 경로를 지정해도 이미지가 다른 디렉토리에 저장되는 경우 있음.
**확인:** 생성 직후 `ls -la /path/to/output.png`로 파일 존재 확인. 없으면 `find ~/.hermes -name "*.png" -newer /tmp/check`로 검색.

## ⚠️ Ken Burns 효과 적용 방법 (확인됨 2026-05-23)

정지영상 아닌 느낌을 주려면 **Ken Burns 효과**(slow zoom/pan)가 가장 간단.

**FFmpeg zoompan 문제:** macOS FFmpeg 4.3.2의 `zoompan` 필터는 4K 입력에서 `Invalid argument` 에러 발생.
대신 **Python으로 Ken Burns 프레임 생성** 후 FFmpeg로 영상 조립:

```python
from PIL import Image
import os

def create_ken_burns_frames(src_path, output_dir, fps=25, dur=72, 
                            start_scale=1.0, end_scale=1.15):
    """Ken Burns 효과 프레임 생성 (Python PIL 방식)
    
    Args:
        src_path: 원본 이미지 경로
        output_dir: 프레임 저장 디렉토리
        fps: 프레임레이트
        dur: 지속 시간(초)
        start_scale: 시작 스케일 (1.0 = 원본)
        end_scale: 종료 스케일 (1.15 = 15% 확대)
    """
    src = Image.open(src_path)
    orig_w, orig_h = src.size
    total = fps * dur
    
    os.makedirs(output_dir, exist_ok=True)
    
    for frame in range(total):
        t = frame / fps
        progress = t / dur
        scale = start_scale + (end_scale - start_scale) * progress
        
        crop_w = int(1280 * scale)
        crop_h = int(720 * scale)
        left = (orig_w - crop_w) // 2
        top = (orig_h - crop_h) // 2
        
        cropped = src.crop((left, top, left + crop_w, top + crop_h))
        resized = cropped.resize((1280, 720), Image.LANCZOS)
        resized.save(os.path.join(output_dir, f"frame_{frame:05d}.png"))
        cropped.close()
        resized.close()
    
    src.close()
    return total
```

**권장 설정:**
- 이미지 1: `scale=1.0→1.15` (zoom in)
- 이미지 2: `scale=1.15→1.0` (zoom out)
- 이미지 3: `scale=1.0→1.12` (zoom in, 약간)

**FFmpeg로 프레임 → 영상:**
```bash
ffmpeg -y -framerate 25 -i frames_%05d.png -i audio.mp3 \
  -c:v libx264 -preset ultrafast -crf 23 \
  -c:a aac -b:a 192k \
  -movflags +faststart \
  output.mp4
```

## ⚠️ 다중 이미지 뮤직비디오 구성 (확인됨 2026-05-23)

3개 이미지로 구성된 뮤직비디오를 만들려면:

1. **이미지 3개 생성** (각각 다른 프롬프트 변형):
   ```bash
   mmx image generate --prompt "...variation 1..." --out img1.png
   mmx image generate --prompt "...variation 2..." --out img2.png
   mmx image generate --prompt "...variation 3..." --out img3.png
   ```

2. **음악 길이에 맞춰 3등분** (예: 212초 → 각 ~70초)

3. **세그먼트별 영상 생성** → 연결 (concat):
   ```bash
   # 세그먼트별 오디오 추출 + 영상
   for i in 1 2 3; do
     ffmpeg -y -i audio.mp3 -ss $(( (i-1) * 72 )) -t 72 -acodec copy audio_$i.mp3
     ffmpeg -y -loop 1 -i img$i.png -i audio_$i.mp3 \
       -vf "scale=1280:720:force_original_aspect_ratio=increase,crop=1280:720" \
       -c:v libx264 -preset ultrafast -crf 28 -c:a aac -b:a 192k \
       -t 72 seg_$i.mp4
   done
   
   # concat
   cat > concat.txt << EOF
   file 'seg_1.mp4'
   file 'seg_2.mp4'
   file 'seg_3.mp4'
   EOF
   ffmpeg -y -f concat -safe 0 -i concat.txt \
     -c:v libx264 -preset ultrafast -crf 23 \
     -c:a aac -b:a 192k \
     -movflags +faststart final.mp4
   ```

**결과:** 3개 이미지가 음악 구간마다 전환되는 뮤직비디오 (212초 = 3분 32초)

## 이미지 변형 프롬프트 생성 함수

```python
def generate_image_variants(base_prompt, output_dir, count=3):
    """기본 프롬프트에서 3개 변형 이미지 생성"""
    variants = [
        f"{base_prompt}, cinematic lighting, emotional atmosphere",
        f"{base_prompt}, night scene, neon reflections",
        f"{base_prompt}, warm tones, detailed composition"
    ]
    image_paths = []
    for i, variant in enumerate(variants[:count]):
        img_path = os.path.join(output_dir, f"image_{i}.png")
        if mmx_image(variant, img_path):
            image_paths.append(img_path)
    return image_paths
```

## ⚠️ 이퀄라이저 애니메이션 오버레이 (확인됨 2026-05-23)

**요구:** 영상 우측 하단에 이퀄라이저 느낌의 애니메이션 오버레이

**해결:** 투명 배경 GIF 방식

### 파이썬으로 투명 GIF 생성 (PIL)
```python
from PIL import Image, ImageDraw
import math, os

WAVE_DIR = os.path.expanduser("~/.hermes/music_videos/wave_anim")
os.makedirs(WAVE_DIR, exist_ok=True)

w, h = 360, 120
num_bars = 20
bar_w = 12
bar_spacing = 6
margin_bottom = 15

colors = [
    (255, 80, 120),   # 핑크
    (200, 80, 180),   # 보라
    (120, 80, 255),   # 블루
    (80, 150, 255),   # 스카이
]

import random
random.seed(42)
base_heights = [random.randint(30, 80) for _ in range(num_bars)]

frames = []
for frame in range(30):  # 30fps × 1초 = 루프
    img = Image.new('RGBA', (w, h), (0, 0, 0, 0))  # 투명 배경
    draw = ImageDraw.Draw(img)
    phase = frame * 0.3
    
    for i in range(num_bars):
        wave = math.sin(phase + i * 0.4) * 0.4 + 0.6
        bar_h = int(base_heights[i] * wave)
        bar_h = max(10, min(bar_h, h - margin_bottom - 10))
        
        x = i * (bar_w + bar_spacing)
        y = h - margin_bottom - bar_h
        
        color_idx = int((i / num_bars) * (len(colors) - 1))
        color = colors[min(color_idx, len(colors) - 1)]
        
        draw.rounded_rectangle([x, y, x + bar_w, h - margin_bottom],
                              radius=4, fill=color + (220,))
    frames.append(img)

frames[0].save(
    f'{WAVE_DIR}/wave_animation.gif',
    save_all=True,
    append_images=frames[1:],
    duration=int(1000/30),
    loop=0,
    optimize=False
)
for f in frames:
    f.close()
```

### FFmpeg로 메인 영상에 GIF 오버레이
**위치:** 우측 하단 (x=920, y=600) — 영상 해상도 1280×720 기준

```bash
ffmpeg -y \
  -i main_video.mp4 \
  -stream_loop -1 -i wave_animation.gif \
  -filter_complex "[0:v][1:v] overlay=920:600:shortest=1" \
  -c:v libx264 -preset ultrafast -crf 23 \
  -c:a copy \
  final_with_wave.mp4
```

**GIF 방식의 장점:**
- PNG 시퀀스보다 파일 크기 작음
- 투명도 완전 보존 (검은 배경 없음)
- `-stream_loop -1`로 영상 길이만큼 자동 반복

**RGBA AVI 방식 (GIF 실패 시 대체):**
```bash
# RGBA MP4 생성
ffmpeg -y -framerate 30 -i wave_%03d.png \
  -c:v libx264 -preset ultrafast -pix_fmt rgba -loop 0 wave_rgba.mp4

# 오버레이
ffmpeg -y -i main_video.mp4 -stream_loop -1 -i wave_rgba.mp4 \
  -filter_complex "[0:v][1:v] overlay=920:600:shortest=1" \
  -c:v libx264 -preset ultrafast -crf 23 -c:a copy output.mp4
```

## ⚠️ 이미지 GitHub Pages 갤러리 백업 (확인됨 2026-05-23)

생성된 이미지를 온라인에서 열람 가능하도록 **별도 GitHub repo + GitHub Pages**로 백업.

### Repo 생성 및 Pages 활성화
```bash
# 새 repo 생성
gh repo create icbm2-gallery --public --description "ICBM2 Music Video Image Gallery"

# gallery 디렉토리 clone
mkdir -p ~/.hermes/music_videos/gallery_gh
cd ~/.hermes/music_videos/gallery_gh && git init
git remote add origin https://github.com/sigco3111/icbm2-gallery.git

# GitHub Pages 활성화
gh api -X POST repos/sigco3111/icbm2-gallery/pages \
  -f build_type=legacy \
  -f source[branch]=main \
  -f source[path]=/
```

### 갤러리 HTML 구성
GitHub Pages는 directory listing을 지원하지 않으므로, **정적 HTML + 수동 이미지 목록** 사용:
→ **대체됨 (2026-05-23): `gallery_data.json` + 동적 HTML 생성 방식** (아래 참고)

### 동적 갤러리 HTML 자동 생성 (2026-05-23)

`gallery_data.json`에 모든 뮤직비디오 메타데이터를 저장하고, `index.html`을 자동 생성하는 방식:

```json
{
  "entries": [
    {
      "date": "2026-05-23",
      "topic": "서울의 달콤한 밤 - 라멘 냄새가 기억이 돼",
      "mood": "우타이테",
      "youtube_url": "https://www.youtube.com/watch?v=...",
      "short_url": "https://www.youtube.com/watch?v=...",
      "lyrics": "골목 끝 네온불빛이 반짝여...",
      "images": ["20260523_image_0.png", "..."],
      "image_url": "https://raw.githubusercontent.com/sigco3111/icbm2-gallery/main/images/20260523_image_0.png"
    }
  ]
}
```

**갤러리 HTML 특징:**
- 검색 기능 (topic + lyrics + date로 필터링)
- 각 카드에 YouTube/Shorts 링크 버튼
- 가사 미리보기 + 토글 (80자 미리보기 → 전체 가사)
- 카드별 3개 이미지 나란히 표시 (flexbox, 33.33% 너비)
- `gallery_data.json` 자동 갱신 → `index.html` 재생성 → Git push → Pages 자동 갱신

**⚠️ ES5 호환性问题 및 해결 (2026-05-23):**
GitHub Pages에서 JavaScript 실행 안 되는 문제 발생.
**원인:** template literal(`` ` ``), `forEach()`, `const`/`let` 등 ES6+ 문법.
**해결:** 모든 JS를 ES5 호환 코드로 재작성:
- `` `hello ${world}` `` → `'hello ' + world`
- `arr.forEach(x => ...)` → `for (var i = 0; i < arr.length; i++) { ... }`
- `gallery.innerHTML +=` → `html +=` 후 `gallery.innerHTML = html` (for 루프 내에서 `innerHTML +=` 피하기)
- 템플릿 리터럴 내 `${value}` → 문자열 연결 `+ value +`

**⚠️ 디버깅 필수: inline JS 문법 검사 (2026-05-23):**
HTML 파일의 inline `<script>`에 문법 오류가 있으면 `node --check`로 즉시 검출 가능:

```bash
python3 -c "
import re
with open('index.html') as f:
    content = f.read()
match = re.search(r'<script>\n(.*?)\n    </script>', content, re.DOTALL)
if match:
    with open('/tmp/script_test.js', 'w') as f:
        f.write(match.group(1))
" && node --check /tmp/script_test.js
```

**이方法で検出した 버그 2개:**
1. `onclick="showImage('' + ...)"` — `''` 빈 문자열이 JS 파싱 실패 (→ `\'\'`로 수정)
2. `replace(/\n/g)` — HTML에서 `\`와 `n`가 줄바꿈으로 분리됨 (→ `replace(/\\n/g)`로 수정)

**Playwright로 브라우저 에러 확인:**
```python
page.on("pageerror", lambda err: errors.append(str(err)))  # 콘솔에 안 보이는 parse error 잡기
```

**⚠️ 가사가 한 줄만 표시되는 문제 (2026-05-23):**
**원인:** `gallery_data.json`의 `lyrics` 필드에 개행 `\n` 없이 한 줄로 저장됨.
**해결:** 
1. `gallery_data.json`에 가사 전체 저장 (개행 `\n` 포함)
2. JS에서 `lyricsEscaped = entry.lyrics.replace(/\n/g, '<br>')`로 변환 후 표시
3. 미리보기: 80자까지만 표시, 초과 시 `...` 추가

**⚠️ 이미지가 1장만 표시되는 문제 (2026-05-23):**
**원인:** `image_url` 단일 필드만 사용.
**해결:** `images` 배열 필드 사용:
```json
"images": [
  "https://raw.githubusercontent.com/sigco3111/icbm2-gallery/main/images/img1.png",
  "https://raw.githubusercontent.com/sigco3111/icbm2-gallery/main/images/img2.png",
  "https://raw.githubusercontent.com/sigco3111/icbm2-gallery/main/images/img3.png"
]
```
HTML에서 루프로 렌더링.

**URL:** https://sigco3111.github.io/icbm2-gallery/

**갤러리 자동 갱신 워크플로우:**
```
크론 실행 (20시)
  → mmx image/music/영상 생성
  → YouTube 업로드 (성공)
  → backup_to_gallery() 호출
    1. gallery_data.json 로드
    2. 새 entry 추가 (topic, youtube_url, short_url, lyrics, images, image_url)
    3. index.html 재생성 (gallery_data 기반)
    4. Git push → Pages 자동 갱신
```

**Python 구현 핵심:**
```python
def backup_to_gallery(image_paths, topic, youtube_url, short_url, mood, lyrics):
    init_gallery_repo()
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    # gallery_data.json 갱신
    data = load_gallery_data()
    new_entry = {
        "date": datetime.now().strftime("%Y-%m-%d"),
        "topic": topic,
        "mood": mood,
        "youtube_url": youtube_url,
        "short_url": short_url,
        "lyrics": lyrics[:200] if lyrics else "",
        "images": [f"{timestamp}_{os.path.basename(p)}" for p in image_paths],
        "image_url": f"https://raw.githubusercontent.com/sigco3111/icbm2-gallery/main/images/{timestamp}_{os.path.basename(image_paths[0])}"
    }
    data["entries"].insert(0, new_entry)
    save_gallery_data(data)
    generate_gallery_html(data)  # index.html 재생성
    # Git push...
```

**유지 vs 삭제:**
- ✅ 이미지 → GitHub gallery에 백업 (images/ 폴더, timestamp prefixed)
- ✅ gallery_data.json → 매번 갱신
- ✅ wave_animation.gif → 재사용 위해 유지
- ❌ 음악/비디오/숏츠 → 처리 후 삭제 (용량 절약)

```html
<!-- index.html 예시 (갤러리 카드 grid) -->
<script>
const data = {"images": [
  {"name": "img1.png", "label": "Neon City Night", "date": "2026-05-23"},
  // ...
]};
data.images.forEach(img => {
  gallery.innerHTML += `<div class="card">
    <img src="images/${img.name}" alt="${img.label}">
    <div class="card-info"><h3>${img.label}</h3><p>${img.date}</p></div>
  </div>`;
});
</script>
```

**URL:** https://sigco3111.github.io/icbm2-gallery/

### 스크립트 연동 (최종 구현)
```python
import subprocess, shutil, os
github_repo = "https://github.com/sigco3111/icbm2-gallery.git"
gallery_dir = os.path.join(OUTPUT_DIR, "gallery_gh")

# gallery_gh가 git repo가 아니면 초기화 (한번만)
if not os.path.exists(os.path.join(gallery_dir, ".git")):
    os.makedirs(gallery_dir, exist_ok=True)
    subprocess.run(["git", "init"], cwd=gallery_dir, capture_output=True)
    subprocess.run(["git", "remote", "add", "origin", github_repo], cwd=gallery_dir, capture_output=True)
    subprocess.run(["git", "fetch", "origin"], cwd=gallery_dir, capture_output=True)
    subprocess.run(["git", "checkout", "-b", "main"], cwd=gallery_dir, capture_output=True)

# 이미지를 gallery_gh에 복사
if image_dir and os.path.exists(image_dir):
    for img in os.listdir(image_dir):
        if img.endswith('.png'):
            shutil.copy2(os.path.join(image_dir, img),
                        os.path.join(gallery_dir, "images", f"{timestamp}_{img}"))

# 음악/비디오/숏츠는 삭제
for path in [music_path, video_path, video_with_wave, short_path]:
    try:
        if path and os.path.exists(path): os.remove(path)
    except: pass

# GitHub에 푸시
subprocess.run(["git", "add", "."], cwd=gallery_dir, capture_output=True)
result = subprocess.run(["git", "commit", "-m", f"Gallery update {timestamp}"],
                       cwd=gallery_dir, capture_output=True)
if result.returncode == 0:
    subprocess.run(["git", "push", "origin", "main"], cwd=gallery_dir, capture_output=True)
```

**유지 vs 삭제:**
- ✅ 이미지 → GitHub gallery에 백업
- ✅ wave_animation.gif → 재사용 위해 유지
- ❌ 음악/비디오/숏츠 → 처리 후 삭제 (용량 절약)

**GitHub Pages 빌드:** 새 commit push 후 빌드 자동 시작. `gh api repos/.../pages/builds/latest`로 상태 확인 가능.

---

## 음악 길이 3분 이상 만들기 — expand_lyrics() 자동 확장 (확인됨 2026-05-23)

**`--duration` 파라미터 없음** — API가 자동으로 길이를 결정.

**핵심 원리:** 가사의 section 구조와 양이 생성される 음악의 길이를 결정.

**단순히 상세하게 쓸 경우:** 70~100초
**expand_lyrics() 함수 사용 시:** 1,500자+ → 3분+ (109자 → 1,591자 확인)

### expand_lyrics() 구현 (music_video_producer.py에 구현済み)

```python
STRUCTURE_TAGS = ['Verse', 'Chorus', 'Bridge', 'Pre-Chorus', 'Intro', 'Outro']

def expand_lyrics(text, target_chars=1500):
    """짧은 가사를 3분 분량(~1500자)으로 자동 확장"""
    # 1. 구조 태그 [Verse], [Chorus] 등 인식하여 섹션 분리
    # 2. 원본 가사 반복 추가 (target_chars 도달 시停止)
    # 3. 반복 시 태그에 번호 부여: [Verse] → [Verse 2]
```

**mmx_music()에서의 활용:**
```python
lyrics = expand_lyrics(raw_lyrics, target_chars=1500)  # 3분 목표
# mmx music generate --lyrics "$lyrics" ...
```

**주의:**gallery_data.json 저장 시 lyrics 필드에 전체(확장된) 가사 저장. preview는 별도 속성.
```html
<!-- ✅ 올바른 패턴: data-fulllyrics 속성에 전체 가사 저장 -->
<p class="lyrics-preview has-full"
   data-fulllyrics="골목 끝 네온불빛이 반짝여 따뜻한 바람이 내 볼을 스쳐
라멘摊에서 마주친 그 눈빛
아무 말 없이 웃어주는 게 좋아"
   onclick="showLyrics(this)">"골목 끝 네온불빛이 반짝여 따뜻한 바람이 내 볼을 스쳐..."</p>

<!-- ❌ 잘못된 패턴: preview 텍스트 자체가 전부여서 토글해도 의미 없음 -->
<p class="lyrics-preview" onclick="toggleLyrics(this)">"골목 끝 네온불빛이 반짝여..."</p>
```

**주인님 직접 피드백 (2026-05-23):** gallery 카드에 "3분 32초 Extended"라고 적혀있으나 실제 영상은 48초 — 가사가 짧아서 발생. 크론 로그에서 확인할 것.

**주인님 직접 피드백 (2026-05-23):** "가사 클릭하면 전체 가사 보기" 요청 → 구현했으나 시크릿창에서도 작동 안 함. 원인은 preview 텍스트("골목 끝...") 자체가 가사의 전부여서 토글해도 표시할 추가 텍스트가 없음. **가사 토글의 전제 조건:** gallery_data.json의 lyrics 필드에 실제 전체 가사保存在고, preview는 별도 짧은 텍스트여야 함. 현재 "서울의 달콤한 밤" 카드만 전체 가사가 저장되어 있어서 해당 카드만 토글 작동.

## Related Skills

- `music-video-pipeline`: Alternative class-level description for music video automation

## ⚠️ 0-byte 빈 파일 발생 방지 (발견됨 2026-05-23)

`music_video_producer.py` 실행 시 0-byte 빈 MP4 파일이 다수 발생하는 문제 발견.

**증상:**
```
-rw-r--r-- 1 hjshin  staff  0 May 23 21:50 short_t1_v2.mp4
-rw-r--r-- 1 hjshin  staff  0 May 23 21:50 short_t1_final_v2.mp4
(9개 파일 + test_multi/seg_1_kb.mp4)
```

**원인 추정:**
- FFmpeg 이미지→동영상 변환 시 audio sync 문제
- `--shortest` 플래그와 `-t` 시간指定 충돌
- Ken Burns 프레임 생성 단계에서 PIL→FFmpeg 연결 실패

**0-byte 파일 정리:**
```bash
find ~/.hermes/music_videos/ -name "*.mp4" -size 0 -mtime 0 -delete
```

**防范措施:**
1. FFmpeg 인코딩 직후 파일 크기 확인 — 0 byte면 인코딩 재시도
2. `-t` 시간指定과 `-shortest` 동시 사용 금지 (하나만 사용)
3. Ken Burns 프레임 생성 → FFmpeg 인코딩 파이프라인에서 프레임 파일 존재 확인 후 인코딩

```python
def verify_video_created(path, min_size=10000):
    """영상 생성 후 0-byte 방지 검증"""
    if not os.path.exists(path):
        return False
    size = os.path.getsize(path)
    if size < min_size:
        print(f"⚠️ 영상 크기 이상 ({size} bytes) — 재시도 필요")
        return False
    return True
```

**⚠️ Gallery lyrics 0글자 문제:** → `references/gallery-automation.md` 참고
Fixed three inline JS issues. Bugs 1+2 prevented gallery from rendering at all. Bug 3 prevented image lightbox even after syntax fix.

**Bug 1:** `onclick="showImage('' + ...)"` — `''` empty string breaks JS parse → fixed to `\'\'`
**Bug 2:** `replace(/\n/g)` where `\n` in HTML becomes actual newline → fixed to `replace(/\\n/g)`
**Bug 3 (silent):** Long `JSON.stringify()` in onclick gets silently truncated by browser, breaking the handler entirely. Fixed by using `data-images` + `data-index` attributes + delegated event listener instead of inline onclick.

Debug method: extract inline script → `node --check /tmp/script.js`. Playwright catches runtime errors via `page.on("pageerror")`.

**Gallery Lightbox Feature (2026-05-23):**
Added lightbox modal for in-page image viewing:
- Click any thumbnail → fullscreen lightbox with navigation
- ← → arrow keys navigate, ESC closes
- Background click closes
- Caption shows "X / Y" (image index)

```javascript
var currentImages = [];
var currentIndex = 0;

function openLightbox(src, images, index) {
    currentImages = images;
    currentIndex = index;
    document.getElementById('lightbox-img').src = src;
    document.getElementById('lightbox-caption').textContent = (index + 1) + ' / ' + images.length;
    document.getElementById('lightbox').classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeLightbox() {
    document.getElementById('lightbox').classList.remove('active');
    document.body.style.overflow = '';
}

function navigateLightbox(dir) {
    currentIndex = (currentIndex + dir + currentImages.length) % currentImages.length;
    document.getElementById('lightbox-img').src = currentImages[currentIndex];
    document.getElementById('lightbox-caption').textContent = (currentIndex + 1) + ' / ' + currentImages.length;
}

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') closeLightbox();
    if (e.key === 'ArrowLeft') navigateLightbox(-1);
    if (e.key === 'ArrowRight') navigateLightbox(1);
});
document.getElementById('lightbox').addEventListener('click', function(e) {
    if (e.target === this) closeLightbox();
});
```

CSS: `.lightbox` fixed overlay, `.lightbox.active { display: flex; }`, nav buttons positioned absolutely.

**⚠️ gallery_data.json → index.html 렌더링 시 반드시 지켜야 할 패턴 (2026-05-23):**

1. **이미지 3개 모두 렌더링**: `image_url` 단일 필드 사용 금지 → `images` 배열 루프로 3개 img 태그 생성:
```html
<div class="card-img-wrap three">
  <img class="card-img" src="images[0]" onclick="openModal(this)">
  <img class="card-img" src="images[1]" onclick="openModal(this)">
  <img class="card-img" src="images[2]" onclick="openModal(this)">
</div>
```
**실수 금지**: HTML 소스에 1개만 하드코딩하지 말 것 — 항상 images 배열 길이만큼 루프.

2. **가사 토글**: preview 텍스트와 전체 텍스트를 **별도 속성**으로 분리:
```html
<!-- ✅ 올바른 패턴 -->
<p class="lyrics-preview has-full"
   data-fulllyrics="골목 끝 네온불빛이 반짝여 따뜻한 바람이..."
   onclick="showLyrics(this)">"골목 끝 네온불빛이..."</p>

<!-- ❌ 잘못된 패턴: preview 텍스트 자체가 전부 -->
<p class="lyrics-preview" onclick="toggleLyrics(this)">"골목 끝 네온불빛이..."</p>
```
`data-fulllyrics` 없는 카드(가사 없음)는 토클해도 의미 없음.

**가사 토글 — preview와 fulllyrics를 반드시 분리해서 저장 (2026-05-23):**
```html
<!-- ✅ 올바른 패턴: data-fulllyrics 속성에 전체 가사 저장 -->
<p class="lyrics-preview has-full"
   data-fulllyrics="골목 끝 네온불빛이 반짝여 따뜻한 바람이 내 볼을 스쳐
라멘摊에서 마주친 그 눈빛
아무 말 없이 웃어주는 게 좋아"
   onclick="showLyrics(this)">"골목 끝 네온불빛이 반짝여 따뜻한 바람이 내 볼을 스쳐..."</p>

<!-- ❌ 잘못된 패턴: preview 텍스트 자체가 전부여서 토글해도 의미 없음 -->
<p class="lyrics-preview" onclick="toggleLyrics(this)">"골목 끝 네온불빛이 반짝여 따뜻한 바람이..."</p>
```
가사 없는 카드(예: 고양이ICloud 사건)는 `data-fulllyrics` 없이 토클해도 의미 없음.

**⚠️ Self-Healer 가양성 주의 — 단어 경계 필요 (ISS-037):**

Self-Healer의 `cron_self_healer.py`가 `jobs.json` 상태와 무관하게 크론 출력에서 `APIError` 패턴을 오탐하는 문제 (ISS-037로 추적).

**오탐 패턴:**
```python
r"(?:api.*(?:error|401|403|429|500)|unauthorized)"
```
이 패턴이 "notion-401-troubleshooting.md", "status code 401" 등 일반 텍스트의 `401`도 APIError로 오인식.

**실제 성공 여부 판단:**
```bash
grep -i "✅\|❌\|complete\|success" <job_output>.md
```

**개선 패턴 (단어 경계 추가):**
```python
r"\b(?:api.*(?:error|failed)|unauthorized|rate\s*limit)\b"
```

**문제 원인:** jobs.json은 모두 "ok" 상태이나, 출력 파일의 일반 텍스트에 "401", "API error" 등이 포함되어 있으면 오탐.

**체크리스트:** Self-Healer가 "실패"라고 표시해도 → jobs.json 상태 확인 → 실제 성공 여부 판단.

**YouTube Quota 초과 시 파일 처리 — 주인님 확인 필요 (2026-05-23):**

YouTube 일일 업로드 quota(6개/일) 소진 시:
1. 영상 파일은 항상 로컬에 유지 (`~/.hermes/music_videos/`)
2. 파일명 패턴: `video_YYYYMMDD_HHMMSS.mp4` (메인), `short_YYYYMMDD_HHMMSS.mp4` (Shorts)
3. **주인님이 텔레그램으로 파일 전송 요청 시** → Telegram Bot API로 직접 전송
   - Bot Token: `~/.hermes/secrets/telegram_bot_token.txt`
   - Chat ID: `~/.hermes/secrets/telegram_chat_id.txt`
   - **현재 토큰이 placeholder 상태** (`PLACEHOLDER_TOKEN_REPLACE_WITH_REAL`) → 전송 불가
   - 해결 방법: BotFather에서 새 토큰 발급 후 파일 교체

**주인님 확인용 파일 식별:**
- 오늘 제작된 영상: `video_20260523_202145.mp4` (석유값 동결), `video_t1.mp4` (스테로이드 올림픽)
- Shorts: `short_20260523_202145.mp4`, `short_t1_with_audio.mp4`
- 두 주제 모두 gallery에 없는 **신규 제작 영상**

**전송 명령 (BOT TOKEN 방식 — 이미지 전용):**
```bash
TOKEN=$(cat ~/.hermes/secrets/telegram_bot_token.txt | grep -v "^#" | tr -d ' \n')
CHAT=$(cat ~/.hermes/secrets/telegram_chat_id.txt | tr -d ' \n')
curl -s -F "chat_id=$CHAT" \
     -F "document=@/path/to/video.mp4" \
     -F "caption=🛢️ {주제명}" \
     "https://api.telegram.org/bot$TOKEN/sendDocument"
```

**주인님께 영상 보내드리는 방법 (2026-05-23 확인):**
```
1. 응답에 MEDIA:/path/to/video.mp4 포함 (이게 작동하는 유일한 방법)
2. hermes send CLI는 텍스트만 전송, 미디어 불가
3. Bot Token 방식은 이미지에는 작동하나 영상은 404 에러 (토큰 문제)
4. gallery_data.json의 youtube_url에 로그 텍스트 오염 버그 → 항상 URL만 저장
```

## 변경 이력

| 날짜 | 내용 |
|------|------|
| 2026-05-23 | 0-byte 빈 MP4 파일 발생 방지 패턴 추가 |
| 2026-05-23 | Self-Healer 가양성 오탐 패턴 문제 문서화 (ISS-037) |