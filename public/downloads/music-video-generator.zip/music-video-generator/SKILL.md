---
name: music-video-generator
description: MiniMax CLI(mmx) 기반 뮤직비디오 자동 생성 파이프라인 — 주제 생성 → 이미지/음악/이퀄라이저 → YouTube 업로드(일반 영상 + Shorts). 주인님 직접 검토 후 진행하는 승인 루프 포함.
trigger: "music video generator mmx image music youtube shorts automation"
---

## ⚠️ CRITICAL BUG — 3개 이미지 FFmpeg Concat으로 영상 제작 시 1장만 반복 (2026-05-25)

**문제:** FFmpeg의 filter_complex `[0:v][1:v][2:v]concat=n=3:v=1:a=0[video]` 방식으로 3개 이미지를 합성하면 **1장만 반복**되는 버그 발생.

**원인:** 이미지는 비디오와 달리 pts.time이 없음. `setpts=PTS+OFFSET/TB`가 이미지에서는 제대로 작동하지 않아 첫 번째 이미지만 반복.

**✅ 검증된 Working 방식:** 세그먼트별 개별 Ken Burns MP4 생성 후 concat:
```python
# Step 1: 각 이미지별 Ken Burns 세그먼트 생성
seg_times = [(0, 33.3), (33.3, 66.6), (66.6, 100)]
for idx, img_path in enumerate([img0, img1, img2]):
    dur = seg_times[idx][1] - seg_times[idx][0]
    subprocess.run(["ffmpeg", "-y", "-loop", "1", "-i", img_path,
        "-filter_complex", f"...zoompan...:d={int(dur*30)}:s=1920x1080:fps=30[vs]",
        "-map", "[vs]", "-t", str(dur), "-c:v", "libx264", "-preset", "ultrafast", "-crf", "28",
        f"seg_{idx}.mp4"])

# Step 2: 세그먼트 concat
with open("concat.txt", "w") as f:
    for i in range(3): f.write(f"file 'seg_{i}.mp4'\n")
subprocess.run(["ffmpeg", "-y", "-f", "concat", "-safe", "0",
    "-i", "concat.txt", "-c:v", "libx264", "-preset", "fast", "-crf", "23",
    "slide_final.mp4"])
```

**❌ 절대 사용 금지:**
```bash
ffmpeg -y -loop 1 -i img0.png -loop 1 -i img1.png -loop 1 -i img2.png \
  -filter_complex "[0:v][1:v][2:v]concat=n=3:v=1:a=0[video]" ...  # 1장만 반복됨!
```

**주의:** PIL Ken Burns 프레임 방식도 CPU/디스크 병목 → zoompan 세그먼트 방식 선호

---

# Music Video Generator (mmx-cli 기반)

**⚠️ 절대 규칙 — 검수 전 업로드 금지 (2026-05-25):**
家主님이 직접 검수하고 '업로드' 확인할 때까지 YouTube에 업로드하지 마세요.
`music_video_producer.py`의 `upload_youtube()`는 더미 상태이며, 실제 업로드는 `music_video_review.py --approved`에서만 가능합니다.

**⚠️ 음악 3분 보장 — 500자 미만 가사로 음악 생성 금지 (2026-05-25):**
`expand_lyrics()`로 가사 **1800자 이상** 확보 후 mmx music 호출. 500자 미만 가사는 생성 차단. 1000자 미만 시 4분 재확장 시도.

MiniMax CLI(mmx-cli)를 사용하여 자동으로 뮤직비디오를 생성하고 YouTube에 업로드하는 파이프라인.

## Architecture

```
家主님 직접 주제 입력 → expand_lyrics() 호출 → mmx music/image 생성 →家主님 검수 → 업로드
```

**⚠️ Notion DB 완전 폐지 (2026-05-25):**家主님이 "Notion 관련 노션은 제거되었음. 앞으로 해당 db는 사용하지마"라고 직접 지시. 
`music_video_producer.py`의 Notion 연동 로직은 더 이상 사용하지 않음. 
주제는家主님 직접 입력으로만 수집. 스크립트 직접 실행 또는 terminal에서 mmx 명령 직접 호출.

## 사전 요구사항

- `mmx` CLI 설치済み (`npm install -g mmx-cli`)
- Notion API Key (`NOTION_API_KEY`)
- YouTube OAuth 토큰 (`~/.hermes/secrets/youtube_token.pickle`)
- FFmpeg 설치済み

## ⚠️ Plus ($20/月) 플랜 제약

| 기능 | Plus ($20) | 권장 대안 |
|------|-----------|---------|
| **Hailuo 영상 생성** | ❌ 없음 | 이미지 + 이퀄라이저 애니메이션으로 시각적 충실도 확보 |
| **Music-2.6** | ✅ 100곡/일 | |
| **image-01** | ✅ 50장/일 | |
| **Speech 2.8** | ✅ 4,000글자/일 | |

**핵심 제약:** Plus 플랜에는 Hailuo-2.3 비디오 생성 기능이 없음.
대안으로 **배경 이미지 + 이퀄라이저 바 애니메이션**을 FFmpeg로 합성하여 뮤직비디오 수준의 시각적 콘텐츠를 만드는 방법을 사용한다.

## ⚠️ 알려진 함정: 가사 미전달 버그

`music_video_producer.py`의 초기 구현에서 음악 프롬프트에 **가사가 제대로 전달되지 않는 문제**가 있음.
Notion에 주제를 등록할 때 가사를 "음악프롬프트" 자식 블록에 저장하지만, `mmx music generate` 호출 시 해당 가사가 music prompt 필드에 포함되지 않는 경우가 있음.

**해결 방법:**
1. Cronjob 스크립트에서 Notion 자식 블록(가사)을 읽어서 music prompt에 수동 병합
2. 또는 주제 등록 시 가사를 "음악프롬프트" 속성 본문에 직접 삽입 (자식 블록 ❌)
3. 테스트: `mmx music generate` 후 생성된 음악의 가사를 들고 직접 확인

## mmx CLI 사용 패턴 (확인됨 2026-05-23) — `references/youtube-upload-fix.md`, `references/minimax-music-cli.md` 참고

### API Key 설정
```bash
source ~/.hermes/secrets/minimax.env
mmx image generate --api-key "$MINIMAX_API_KEY" --prompt "..." --out output.png
mmx music generate --api-key "$MINIMAX_API_KEY" --prompt "..." --lyrics "..." --out output.mp3
```

### 이미지 생성
- 모델: `image-01`
- `--api-key "$MINIMAX_API_KEY"` 필수 (env만 있어도 `--api-key` 없으면 `No credentials found` 에러)
- `--out` 경로 지정

### 음악 생성 — 3분 이상 만들기 (확인됨 2026-05-23)
**`--duration` 파라미터 없음** — 작동하지 않음.

**방법: expand_lyrics() 함수로 자동 확장** (109자 → 1,591자 확인)

`music_video_producer.py`에 구현된 `expand_lyrics()` 함수가 구조 태그를 인식해서 가사를 자동 확장합니다:

```python
STRUCTURE_TAGS = ['Verse', 'Chorus', 'Bridge', 'Pre-Chorus', 'Intro', 'Outro']

def expand_lyrics(text, target_chars=1500):
    """짧은 가사를 3분 분량(~1500자)으로 자동 확장
    - 구조 태그 [Verse], [Chorus] 등 인식
    - 섹션별 내용 분리 후 반복 추가
    - target_chars 도달 시停止 (max 50 iterations)
    """
    # 1. [Verse], [Chorus] 등 태그를 찾아서 섹션별 내용 파싱
    # 2. 원본 가사 뒤에 반복 섹션 추가
    # 3. 1500자 도달 시 종료
```

**mmx_music() 호출 전 적용:**
```python
lyrics = expand_lyrics(raw_lyrics, target_chars=1500)  # 3분 목표
```

**이전 수동 방식 (더 이상 사용 안 함):**
- section마다 bar 수 명시하는 수동 방식 → `expand_lyrics()` 자동화로 대체 (2026-05-23)

### FFmpeg 이미지→영상 변환 (3분 이상 영상 대응 — 확인됨 2026-05-23)
**일반 영상 (16:9, 1280x720, 음악 길이에 맞춤)**
```bash
ffmpeg -y \
  -loop 1 -i image.png \
  -i audio.mp3 \
  -vf "scale=1280:720:force_original_aspect_ratio=increase,crop=1280:720" \
  -c:v libx264 -preset ultrafast -crf 28 \
  -c:a aac -b:a 128k \
  -movflags +faststart \
  -shortest \
  output.mp4
```
- **`-preset ultrafast -crf 28`**: medium 대비 인코딩 2배 이상 빠름 (3분 영상 ~3분 소요)
- **`-shortest`**:音频 길이에 맞춰 영상 자동 종료 (手動 `-t` 불필요)
- **`-movflags +faststart`**: YouTube 업로드 "파일을 처리할 수 없음" 오류 방지 — 반드시 포함
- 3분 영상 인코딩: 약 3분 소요 (medium: 7분+, ultrafast: 3분)

### YouTube 업로드 스크립트
```bash
# 실행 방법 (positional file_path 먼저)
python3 yt_upload.py /path/to/video.mp4 \
  --title "제목" \
  --description "설명" \
  --tags "태그1,태그2" \
  --privacy public

# google-api-python-client가 conda/pyodbc 충돌로 설치 안 되면 → 수동 업로드 또는 curl API 호출
# /tmp/yt_upload_venv/bin/python3 yt_upload.py ...
```

## ⚠️ YouTube 429 — Real Quota + Token 두 가지 원인 (2026-05-25 업데이트)

**家主님 확인:** "업로드 쿼타는 충분하니 혹시 쿼타가 부족하다고하면 네가 뭔가 잘못처리하는 거임"

**원인 1 — 만료된 OAuth 토큰 (가장 흔함):**
`429 Quota Exceeded`가 나오지만 실제로 quota가 충분한 경우. 토큰이 만료되어 YouTube API가 잘못된 응답을返す 것.
- **증상:** `--approved` 없이直接 업로드 시 429, 토큰 refresh 후 업로드 성공
- **확인:** `creds.valid` → `False`이면 만료됨
- **해결:** 업로드 전 반드시 force refresh

**원인 2 — 실제 quota 소진:**
하루 6개 업로드 제한에 도달한 경우.
- **증상:** 1개 업로드 성공 후 2개째부터 429
- **확인:** YouTube 대시보드에서 오늘 업로드 영상 수 확인
- **해결:** 일반 영상과 Shorts를 같은 세트로 업로드하면 2개로 카운트됨 → quota 리셋(UTC 자정)까지 대기

**구분 방법:**
```python
# 먼저 토큰 refresh 시도
with open(TOKEN_FILE, "rb") as f:
    creds = pickle.load(f)
if creds.expired:
    creds.refresh(Request())
    with open(TOKEN_FILE, "wb") as f:
        pickle.dump(creds, f)
    print("Token refreshed")

# 토큰 유효한 상태에서 429 → 실제 quota 소진
result = upload_video(...)
if "429" in str(result) and creds.valid:
    print("Real quota exceeded - wait for reset")
```

**권장 python3:** `/usr/bin/python3` (3.9.6) — system Python, google-auth 2.50.0 정상. 모든 YouTube 업로드에는 반드시 이 Python 사용. hermes-agent venv Python (3.11)禁止 — `_regional_access_boundary_utils` 모듈 누락으로 무한 대기 발생.

```python
import pickle, time, os
from google.auth.transport.requests import Request

TOKEN_FILE = os.path.expanduser("~/.hermes/secrets/youtube_token.pickle")

def refresh_token_force():
    with open(TOKEN_FILE, "rb") as f:
        creds = pickle.load(f)
    if creds.expired:
        creds.refresh(Request())
        with open(TOKEN_FILE, "wb") as f:
            pickle.dump(creds, f)
        print("Token refreshed")

refresh_token_force()  # 항상 업로드 전 실행

# 업로드 실패 시 429면 토큰 갱신 후 대기 없이 즉시 재시도 (실제 quota일 수 있음)
```eal Quota (2026-05-24)

**주인님 확인:** "업로드 쿼타는 충분하니 혹시 쿼타가 부족하다고하면 네가 뭔가 잘못처리하는 거임"

`429 Quota Exceeded`는 대부분 **만료된 OAuth 토큰**이 원인이지 실제 quota 소진이 아님.

**해결:** 업로드 시도 전 토큰을 무조건 force-refresh. 그래도 429가 나오면 指數 백오프로 재시도.

**권장 python3:** `/usr/bin/python3` (3.9.6) — system Python, google-auth 2.50.0 정상. 모든 YouTube 업로드에는 반드시 이 Python 사용. hermes-agent venv Python (3.11)禁止 — `_regional_access_boundary_utils` 모듈 누락으로 무한 대기 발생.

```python
import pickle, time, os
from google.auth.transport.requests import Request

TOKEN_FILE = os.path.expanduser("~/.hermes/secrets/youtube_token.pickle")

def refresh_token_force():
    with open(TOKEN_FILE, "rb") as f:
        creds = pickle.load(f)
    creds.refresh(Request())
    with open(TOKEN_FILE, "wb") as f:
        pickle.dump(creds, f)

refresh_token_force()  # 항상 업로드 전 실행

for attempt in range(3):
    result = subprocess.run([...])
    if "SUCCESS" in result.stdout:
        break
    elif "429" in result.stderr or "rateLimit" in result.stderr:
        refresh_token_force()  # 대기 전 토큰 갱신
        time.sleep(2 ** attempt * 10)
    else:
        break
```

> ⚠️ 상세: `music-video-pipeline` skill의 YouTube Upload 섹션

## ⚠️ YouTube 일일 Quota 초과 + 토큰 추출 패턴 (발견됨 2026-05-23)

**429 Quota Exceeded — 하루 6개 영상 제한:**
```
"code": 429, "message": "Quota exceeded for quota metric 'Video Uploads' and limit
'Video Uploads per day' of service 'youtube.googleapis.com'
for consumer 'project_number:1088895812408'
quota_limit_value: 6"
```
오늘 업로드: 고양이ICloud 3개 + 서울 시리즈 3개 = **6개 소진**. quota 리셋 전까지 모든 업로드 실패. 파일은 항상 로컬에 보관 → 다음 날 재시도.

**403 Insufficient Permission — upload scope는 정상 작동:**
`channels?mine=true` 호출 시 403 발생 → 하지만 `uploadType=resumable&part=snippet,status` POST는 200 반환. **업로드 자체는 정상**.

**google-auth 없는 환경에서 토큰 추출 (requests만으로 YouTube 업로드):**
pickle 파일을 google-auth 라이브러리 없이 파싱:
```python
with open(TOKEN_FILE, 'rb') as f:
    data = f.read()
access_token = data[data.find(b'ya29.'):data.find(b'\x94', data.find(b'ya29.')+30)].decode('utf-8')
refresh_token = data[data.find(b'1//'):data.find(b'\x94', data.find(b'1//')+20)].decode('utf-8')
# OAuth refresh
resp = requests.post("https://oauth2.googleapis.com/token", data={
    "client_id": client['installed']['client_id'],
    "client_secret": client['installed']['client_secret'],
    "refresh_token": refresh_token, "grant_type": "refresh_token"
})
token = resp.json()['access_token']
```

**⚠️ gallery_data.json URL 필드 오염 버그 (발견됨 2026-05-23):**
업로드 스크립트 로그 메시지가 `youtube_url`/`short_url`에 그대로 저장됨.
`"Uploading: ...\nSUCCESS: https://..."` → HTML 렌더링 시 페이지 무한 로딩.
**해결:** youtube_url/short_url에는 실제 URL만 저장. 로그 메시지 절대 금지.
→ 상세: `references/youtube-direct-upload.md`

---

## ⚠️ mmx CLI API Key 누락 버그 (발견됨 2026-05-23)

`mmx image`와 `mmx music` 모두 **반드시 `--api-key` 파라미터 필요**. env만 설정되어 있어도 `--api-key` 없으면 `No credentials found` 에러 발생.

**올바른 호출:**
```bash
# 이미지 생성
mmx image generate --api-key "$MINIMAX_API_KEY" --prompt "..." --out output.png

# 음악 생성
mmx music generate --api-key "$MINIMAX_API_KEY" --prompt "..." --lyrics "..." --out output.mp3
```

**Python 함수에서:**
```python
def mmx_image(prompt, output_path):
    api_key = os.environ.get("MINIMAX_API_KEY", "")
    cmd = ["mmx", "image", "generate", "--api-key", api_key, "--prompt", prompt, "--out", output_path]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
    return result.returncode == 0

def mmx_music(prompt_with_lyrics, output_path):
    api_key = os.environ.get("MINIMAX_API_KEY", "")
    # ... 가사 필터링 ...
    cmd = ["mmx", "music", "generate", "--api-key", api_key, "--prompt", style_prompt, "--out", output_path]
    # ...
```

## ⚠️ yt_upload.py 호출 시 Python 版本 CRITICAL (2026-05-25)

**문제:** hermes-agent venv Python 3.11에서 `google.auth._regional_access_boundary_utils` 모듈 누락 → `ModuleNotFoundError` → subprocess 호출이 **무한 대기/Timeout** (300초 후에도 실패). `/usr/bin/python3` (Python 3.9)에는 해당 모듈 정상.

**모든 YouTube 업로드 호출 시 절대 규칙:**
```python
PY = "/usr/bin/python3"   # ✅ system Python (3.9) — 반드시 이것만
# ❌ ~/hermes-agent/venv/bin/python3 — venv Python 3.11 (누락 모듈)
```

**subprocess 호출 패턴:**
```python
PY = "/usr/bin/python3"
proc = subprocess.Popen(
    [PY, YT_SCRIPT, video_path,
     "--title", title, "--description", desc, "--tags", tags, "--privacy", "public"],
    stdout=subprocess.PIPE, stderr=subprocess.STDOUT
)
try:
    stdout, _ = proc.communicate(timeout=120)  # 120초면 충분
except subprocess.TimeoutExpired:
    proc.kill()
# stdout 파싱해서 "SUCCESS" 확인
```

**⚠️ `execute_code`에서 유의:** `execute_code`는 항상 hermes-agent venv Python 사용 → YouTube 업로드 로직은 반드시 `subprocess.Popen`으로 `/usr/bin/python3`을 별도 프로세스로 호출. `subprocess.run([sys.executable, ...])` 금지.

** yt_upload.py의 `get_authenticated_service()`는 내부에서 이미 Token refresh를 시도하나, hermes-agent venv python 사용 시 `ModuleNotFoundError`가 먼저 발생하여 refresh 시도 자체가 불가능해짐. 따라서 호출자가 선제적으로 `/usr/bin/python3`을 사용해야 함.**

**Token refresh 수동 확인:**
```bash
/usr/bin/python3 -c "
import pickle
from google.auth.transport.requests import Request
with open('~/.hermes/secrets/youtube_token.pickle','rb') as f:
    c = pickle.load(f)
if c.expired:
    c.refresh(Request())
    with open('~/.hermes/secrets/youtube_token.pickle','wb') as f:
        pickle.dump(c, f)
    print('refreshed!')
"
```

## ⚠️ yt_upload.py 인자 형식 버그 (발견됨 2026-05-23)

`yt_upload.py`는 **positional arguments가 아니라 named arguments**를 사용. `music_video_producer.py`의 `upload_youtube()` 함수가 잘못된 형식으로 호출해서 업로드 실패.

**버그:**
```python
# ❌ 잘못됨 - positional arguments
cmd = [venv_python, script, video_path, title, description]
```

**수정:**
```python
# ✅ 올바름 - named arguments
cmd = [venv_python, script, video_path, "--title", title, "--description", description]
```

## ⚠️ YouTube OAuth 토큰 만료 시 자동 갱신 (확인됨 2026-05-23)

YouTube OAuth 토큰이 만료되면 API 호출 시 `creds.valid: False` → 업로드 실패.

**증상:** `"Token valid: False"` 출력 후 업로드 오류

**수동 갱신 방법:**
```bash
/tmp/yt_upload_venv/bin/python3 -c "
import pickle, os
from google.auth.transport.requests import Request
TOKEN_FILE = os.path.expanduser('~/.hermes/secrets/youtube_token.pickle')
with open(TOKEN_FILE, 'rb') as f:
    creds = pickle.load(f)
if not creds.valid:
    creds.refresh(Request())
    with open(TOKEN_FILE, 'wb') as f:
        pickle.dump(creds, f)
    print('Token refreshed!')
"
```

**자동 갱신 로직:** `yt_upload.py`의 `get_authenticated_service()` 앞에 토큰 유효성 검사 + 필요시 갱신 로직 삽입.

## ⚠️ Cron 타임아웃 문제 (2026-05-24)

**문제:** `no_agent` 모드 크론은 120초 기본 타임아웃. 실제 스크립트 소요 시간은 ~760초(12분 이상)로 120초 내에서 완료 불가.

**실제 소요 시간:**
- 이미지 3장 생성: ~360초 (각 120초)
- 음악 생성: ~300초
- 영상 합성 + Shorts: ~100초

**해결: `HERMES_CRON_SCRIPT_TIMEOUT` 환경변수 설정 (가장 간단)**

```bash
# ~/.hermes/.env 파일에 추가 (cron 재시작 불필요, 즉시 적용)
HERMES_CRON_SCRIPT_TIMEOUT=600
```

**다른 설정 방법 (대안):**
- `config.yaml`에 추가: `cron: { script_timeout_seconds: 600 }`
- 또는: `hermes config set cron.script_timeout_seconds 600`

**권장 값:** 600초 (10분) — 이미지 3장 + 음악 + 영상 합성 충분히 허용

**참고:** `no_agent` 모드에서만 적용. agent mode 크론은 기본 600초 타임아웃.

## 파이프라인 상세

###家主님 직접 주제 입력 → 완전한 뮤직비디오 제작流程 (2026-05-25)

家主님이 주제를口语로 입력하면 → expand_lyrics()로 3분 가사 확장 → mmx music + mmx image 생성 → FFmpeg 영상 합성 →家主님 검수 → 업로드

**핵심: Notion 없이家主님 직접 입력만으로 진행**

1. **가사 확장** —家主님 입력 가사를 `expand_lyrics()`로 1800자 이상 확장 (target_chars=1800, 500자 미만은 생성 차단)
2. **음악 생성** — `mmx music generate` with Korean female vocal, 120-140 BPM, Hook First structure
3. **이미지 3개 생성** — `mmx image generate` × 3 (photorealism + Korean female vocalist, bright daylight)
4. **영상 합성** — FFmpeg concat으로 3개 이미지를 구간별로 전환하는 뮤직비디오 생성 (각 이미지 ~90초 구간)
5. **이퀄라이저 오버레이** — PIL RGBA GIF 방식을 overlay=920:600로 추가
6. **Shorts 제작** — 3단계 분리 FFmpeg 방식으로 9:16 세로형 59초 Shorts 생성
7. **검수** —家主님이 직접 파일 검수 후 '업로드' 회신 → 실제 YouTube 업로드

### Phase 1: 테마 생성 (매일 09:00 Cron)

1. **테마 3개 생성**:
- 장르, 분위기, 시각 스타일, 영상 색감, 음악 장르 등을 랜덤 조합
- 각 테마: `{theme_name, genre, mood, visual_style, color_palette, music_prompt, image_prompt}`
- 음악 스타일 가중치: 우타이테풍 30%, K-pop ballad 40%, acoustic pop 20%, lo-fi 10% (플레이리스트 기반)
   - 한국어 여성 보컬 반영: music prompt에 `"Korean female vocal, warm tone"` 포함

2. **Notion DB 등록**:
   - DB: `MUSIC_VIDEO_THEMES` (새로 생성)
   - Property: Name(title), Status(select: 대기/승인/진행/완료), Genre(text), Mood(text), VisualStyle(text), ColorPalette(text), MusicPrompt(text), ImagePrompt(text), CreatedAt(date)

3. **Telegram 알림**:
   ```
   🎵 뮤직비디오候選 (3개)
   1. [{theme_name}] — {genre} / {mood}
   2. [{theme_name}] — {genre} / {mood}
   3. [{theme_name}] — {genre} / {mood}
   검토 후 16:00에 자동으로 진행됩니다.
   피드백 있으시면 지금 말씀해주세요.
   ```

### Phase 2: 진행 (승인 또는 16:00 자동)

**각 테마별 순차 진행:**

1. **이미지 생성**:
   ```bash
   mmx image "A {visual_style} scene, {color_palette}, bright daylight, vivid colors, high-key lighting"
   ```

2. **음악 생성** (한국어 여성 보컬 + 우타이테풍 필수):
   ```bash
   mmx music generate \
     --prompt "upbeat pop, Korean female vocal, warm emotional, comedic witty lyrics, 120-140 BPM, Hook First structure" \
     --out /tmp/music_video/theme_1.mp3
   ```

3. **이퀄라이저 애니메이션 생성** (FFmpeg):
   - 음악 길이에 맞춰 이퀄라이저 바 애니메이션 생성
   - 색상: `{color_palette}`에 맞게

4. **합성**:
   - 배경 이미지 + 이퀄라이저 overlay
   - 배경 이미지를 동영상으로 확장(슬라이드쇼 효과)
   - 음악과 동기화

5. **Shorts 제작**:
   - 같은 콘텐츠의 9:16 세로형 버전
   - 59초 이하

6. **YouTube 업로드** (일반 영상 + Shorts **세트**)

### ⚠️家主님이 브라우저에서 직접 YouTube에 업로드 시 gallery 등록 안 됨 (2026-05-25)
**문제:**家主님이 브라우저에서 직접 YouTube에 업로드하면 `backup_to_gallery()`가 자동으로 호출되지 않아 gallery에 카드 등록이 안 됨.
**원인:** `backup_to_gallery()`는 `music_video_producer.py`에 정의되어 있고, `music_video_review.py`에서 이를 import하지 않아 NameError가 발생하지만 조용히 실패함.

**✅ 수정 완료 (2026-05-25):**
- `music_video_review.py` 상단에 `sys.path.insert`로 `backup_to_gallery` import 추가
- `music_video_producer.py`에서 `--image-dir` 인자로 생성된 이미지 디렉토리 전달
- `backup_to_gallery()` 호출 시 image_paths를 함께 전달하여 gallery에 이미지 자동 등록
**절대 규칙:**家主님이 브라우저에서 직접 YouTube에 업로드한 경우, 반드시 Telegram으로 YouTube URL을 알려줘야 gallery에 카드 등록 가능. 자동으로 등록되지는 않음.
**ICBM2의 작업:**家主님이 URL 전송 → gallery_data.json 갱신 + index.html 재생성 + Git push

## 파이프라인 상세

10시 크론(侯選 수집)이家主님께 전송하는侯選은 **최소 6개 이상**이어야 함.
3개만 전송하면家主님 선택지가 부족함.

**Cron 프롬프트 수정: jobs.json의 job ID fcfd160352ff prompt에서 3개→6개 반영됨 (2026-05-25)**

### 주제 출처 구분: 블로그용 vs 뮤직비디오용 (2026-05-23)

**뮤직비디오 주제는 별도 Notion DB에서 관리** (Blog/Tistory 발행용 주제와 다름)
- Notion DB: `36976f2e-9097-81e1-a373-e06f2da6e99c`
- 스크립트: `~/.hermes/scripts/music_video_producer.py`
- **블로그 발행용 주제(긱뉴스 기반)와 다름** — 혼동하지 말 것

### 주제 선정 기준: 유머와 재치 + 한국 국내 한정 (2026-05-25 업데이트)

**家主님이 명시적으로 해외 바이럴 주제를 거부하심:**
- ❌卢浮宫强盗, Coldplay Kiss Cam, Labubu狂気等 —家主님: "해외 주제는 공감이 안 되네"
- ✅採用 기준: 한국에서 발생한 실제 상황/사건, 한국인 공감 가능

**뉴스에서 찾든, 스스로 구상하든 상관없음 — 유일한 기준:**

| ✅採用 | ❌ 부적합 |
|------|------|
| **핵심** | 유머/위트가 있는 소재 | 건式/기술적 논의만 |
| **감정** | 보는 사람이 웃을 수 있는 상황 | dry한 설명 |
| **구조** | 구체적 시나리오 (누구/어디서/무엇을) | 추상적 명사 only |
| **출처** | 한국 국내 상황 | 해외 바이럴 (공감 안 됨) |
| **후렴** | 한 문장으로 정리되는 웃긴/감성적 결말 | 결말 없는 이야기 |

**예시 (採用 가능):**
- "편의점 아르바이트 초대가 꼬인 사연" — 구체적 상황 + 공감 + 결말 가능
- "고양이가 핸드폰으로 결제해버린 날" — everyday 유머 + 결말 웃음
- "옆집 아주미가 내 냉장고를 턴 진짜 이유" — everyday comedy
- (뉴스 기반) "AI가 그림을盗作해서 법정 논쟁"

**예시 (부적합):**
- LLM 아키텍처 동향 설명
- "AI가 발전하고 있다"는 추상적 주제
- 무역협상, 펀드출시 등dry한 주제

**Notion DB description (직접 수정 필요):**
```
유머와 재치가 있는 소재라면 뉴스 출처 없이도 자유롭게 등록 가능.
유일한 기준: 웃을 수 있는 상황, 구체적 시나리오, 한 문장 결말.
```

## ⚠️ 이미지 규칙 — 포토리얼리즘 + 여성만 허용 (2026-05-25 엄격화)

## ⚠️ 이미지 규칙 — 상황에 맞는 밝고 경쾌한 이미지 (2026-05-25 철회: 포토리얼리즘 폐지)

**家主님 피드백 (2026-05-25):** "포토리얼리즘은 포기 — 상황에 맞는 밝은 이미지로 직접 생성"

家主님께서 포토리얼리즘 이미지 생성 요청을 철회하심:
- ❌ `photorealistic, real photo, cinematic photography` 등 제거
- ✅ 상황에 맞는 밝고 경쾌한 이미지 (bright daylight, vivid colors, high-key lighting)
- ✅ 인물: 여성만 허용 (female subjects only, no men)
- ✅ 밝은 분위기 유지 (어두운 이미지 절대 금지)

**이미지 프롬프트 구조:**
```
[상황에 맞는 밝은 장면 묘사], female subjects only, bright daylight, vivid colors, high-key lighting, comedic contrast, cheerful atmosphere
```

## ⚠️ 이미지 스타일 —家主님 요청 시 2D/Cartoon/Kawaii 허용 (2026-05-25 변경)

**핵심 변경:**家主님이 명시적으로 다른 스타일을 요청하면 기본 규칙을Override할 수 있음.

**家主님이 직접 요청한 경우 — 2D/Cartoon/Kawaii 허용 (2026-05-25):**
-家主님: "내가 넌 포토리얼리즘에 재능이 없으 원래 규칙을 수정하라고 했는데, 앞으로도 노든 규칙을 수정하도록 2D, cartoon, kawaii 모두 허용"
- ✅家主님이 "귀여운 느낌"이라고 요청하면 → 2D/cartoon/kawaii 허용
- ✅家主님이 직접 다른 스타일 요청 시 → 해당 스타일로 진행
- ⚠️家主님이 별도 지시가 없으면 → 기존 규칙 (밝고 경쾌한 이미지, female subjects) 적용

**이미지 스타일 가이드 (家主님 요청별):**

|家主님 요청 |Allowed styles |예시 |
|-----------|---------------|-----|
| "귀여운 느낌" | 2D, cartoon, kawaii, chibi, illustration | 캐릭터 기반 MV |
| 별도 지시 없음 | 밝고 경쾌한 실사 이미지 (photorealistic 폐지) | 기본 MV |
| "포토리얼" | photorealistic only | (家主님이 직접 요청한 경우) |

**절대 금지 (家主님 요청 없을 때):**
- ❌ `men`, `male`, `guy`, `boy`, `man`, `people`, `crowd`, `group`
- ❌ 인물 없는 풍경/사물만Generated
- ❌ 어두운 이미지 (low-key, moody, cinematic photography)

**✅ 허용 (家主님 요청 시):**
- ✅ `cartoon, kawaii, cute, chibi, anime, illustration, pastel, 2D`
- ✅ 캐릭터 기반 이미지 (음식 먹방 캐릭터, 귀여운 동물 등)

**家主님 직접 입력 MV의 이미지 프롬프트 예시 (캐릭터 기반):**
```bash
#家主님이 "귀여운 느낌"이라고 요청 시
mmx image "Cute 2D cartoon character with round face and big eyes eating tteokbokki happily,
bright cheerful colors, kawaii style illustration, adorable chibi style character,
clean vector art style" --seed 101 -o image_0.png && mv image_001.jpg image_0.png
```

**핵심 원칙:**家主님이 스타일을 명시적으로 요청하면 기본 규칙과 관계없이 해당 스타일 사용. 요청 없는 경우에만 기본 규칙 적용.

**모든 이미지 프롬프트는 이 구조로 작성:**
```bash
# ✅ 올바른 호출 순서: 생성 직후 mv로 리네임
cd /target/dir && mmx image "female only prompt..." --seed 101 -o image_0.png && mv image_001.jpg image_0.png
cd /target/dir && mmx image "female only prompt..." --seed 201 -o image_1.png && mv image_001.jpg image_1.png
cd /target/dir && mmx image "female only prompt..." --seed 301 -o image_2.png && mv image_001.jpg image_2.png

# ❌ 절대 금지: 3개 동시 생성 후 리네임 (전부 image_001.jpg로 덮어씌워짐)
mmx image "p1" --seed 101 -o image_0.png &
mmx image "p2" --seed 102 -o image_1.png &
mmx image "p3" --seed 103 -o image_2.png &
wait
mv image_001.jpg image_0.png  # 1개만 남음!
```

**모든 이미지 프롬프트는 이 구조로 작성:**
```
[상황 설명, 한국 여성만], bright daylight, vivid colors, high-key lighting,
female subjects only, no men, only women, exclude male completely,
exclude crowd scenes, single person or small group only
```

**올바른 예시 (직장인 점심시간):**
```
Korean female office workers confused about lunch menu, women looking at phones with delivery app,
female colleagues in modern office cafeteria, bright daylight, vivid colors,
high-key lighting, female subjects only, no men, only women, single female characters
```

**올바른 예시 (직장인 점심시간):**
```
Korean female office workers confused about lunch menu, women looking at phones with delivery app,
female colleagues in modern office cafeteria, bright daylight, vivid colors,
high-key lighting, female subjects only, no men, only women, single female characters
```
**家主님 직접 요청 MV 이미지 프롬프트 예시:**

1. **캐릭터 기반 (귀여운 느낌家主님 요청 시):**
```
Cute 2D cartoon character with round face and big eyes eating tteokbokki happily,
bright cheerful colors, kawaii style illustration, adorable chibi style character,
clean vector art style
```

2. **기본 MV (家主님 별도 지시 없을 때 — 밝은 실사 이미지):**
```
A cheerful scene of a young Korean woman vocalist singing on a bright stage,
warm spotlight, colorful stage lights, bright daylight, vivid colors,
high-key lighting, comedic contrast, cheerful atmosphere
```

3. **음식/먹방 테마:**
```
A cheerful scene of a cute cartoon character with big eyes enjoying Korean street food,
convenience store background, bright daylight, vivid colors, kawaii chibi style,
adorable expression, clean vector art
```

4. **감성/유머:**
```
A warm close-up of a cute chibi character with an ironic smile,
bright cheerful colors, high-key lighting, playful kawaii style,
comedic contrast, witty atmosphere
```

### ⚠️ 이미지 밝기 문제 해결 (2026-05-24)
**문제:** 포토리얼리즘으로 생성하면 항상 어두운 이미지 발생
**원인:** `cinematic photography`, `natural lighting`, `night scene` 등이 어두운 조명 유발
**해결:** `bright daylight, vivid colors, high-key lighting` + `comedic contrast` 조합으로 밝고 활기찬 이미지 생성
→ 상세한 키워드 조합 표와 절대 금지 키워드 목록: `references/image-brightness-fix-2026-05-24.md`

### ⚠️ 여성 가수 비주얼 필수 (2026-05-25)
**문제:** "둘다 검수 탈락" — 이미지에 사람이 아예 없거나, 있어도 여성 가수가 아닌 것으로 파악됨
**원인:** 이미지 프롬프트에 female vocalist 비주얼 요구사항이 명시되지 않음

**모든 이미지 프롬프트의 첫 번째 요소:**
```
[실제 여성 가수가 노래하는 포토리얼리스트틱 장면]
```
**절대 금지:** 남성 인물, 군중 장면(가수 없는), 풍경/사물만

**예시 (옳음):**
```
A realistic photo of a young Korean female vocalist singing energetically on a bright stage,
warm spotlight, colorful stage lights, photorealistic, bright daylight, vivid colors, high-key lighting, comedic contrast, cheerful atmosphere
```

**예시 (옳음 - 골목 유머):**
```
A photorealistic scene of a young Korean woman vocalist performing on a sunny street stage,
colorful decorations, playful crowd, bright daylight, vivid saturated tones, high-key lighting,
comedic contrast, cheerful urban atmosphere
```

**예시 (옳음 - 감성 유머):**
```
A photorealistic close-up of a young Korean female vocalist with an ironic smile,
bright studio lighting, warm tones, high-key lighting, vivid colors, playful mood
```

### ⚠️ 음악 스타일 —家主님 선호도 (2026-05-25 확인 완료)
| 항목 | 선호 |
|------|------|
| 음악 장르 | 우타이테풍 (upbeat pop, 120-140 BPM) |
| 분위기 | 밝고 경쾌한 Upbeat |
| 가사 톤 | 유머와 재치있는 |
| 보컬 스타일 | 한국어 여성 보컬 (절대 필수) |
| 구조 | 후렴 선행형 (Hook First) |

**모든 음악 프롬프트에 반드시 포함:**
```
upbeat pop, Korean female vocal, warm emotional, comedic witty lyrics,
120-140 BPM, Hook First structure
```

**절대 사용 금지:**
- ❌ ballad,慢板,悲情的 (무조건 upbeat만)
- ❌ 남성 보컬
- ❌ 후렴이Verse 이후 나오는 구조

### ❌ 피할候選 유형
- 무역협상, 펀드 출시, 스테로이드 올림픽 gibi 건式주제
- 기술적 깊이가 있는 AI/ML 동향 (KV sharing, mHC, 압축 어텐션等)
- 정책/금융 지표 기반 주제

**참고:** 이 규칙은 2026-05-23 주제 재생성 세션에서 확인됨.

## 주제 선정 시 ⚠️ 주의 (2026-05-23)

**주인님 직접 피드백:** "오늘의 뮤직비디오 주제가 좀 별로임. 유머와 위트를 첨부할만한 주제로 다시 찾아줘"

현재 Notion DB候選 중 **스테로이드 올림픽**은 ❌ 부적합으로 분류된 주제가 섞여 있음.
건式/정치/스포츠 주제는 뮤직비디오로 재미없음.

**체크리스트:** 주제를 등록하기 전 반드시自問
1. ✅ 이 주제를 보면 **사람이 웃을 수 있는가**?
2. ✅ **구체적 시나리오**가 있는가 (추상적 명사 ❌)?
3. ✅ **공감/경험**을 유발하는가?
4. ✅ ❌ 무역협상, 펀드출시, 올림픽, 정치협상 같은 **건式주제**인가?

answered: No → 등록하지 말 것

**랜덤 조합 패턴:**
- `visual_styles`: cyberpunk city, aurora borealis, neon rain, vintage cinema, cosmic landscape, forest silhouette, ocean waves, mountain peaks
- `color_palettes`: neon blue/pink, warm sunset orange, deep purple/violet, monochromatic blue, golden hour, teal/cyan
- `genres`: synthwave, lo-fi jazz, ambient orchestral, chillhop, acoustic pop, cinematic epic
- `moods`: nostalgic, dreamy, energetic, melancholic, hopeful, mysterious, **comedic, hilarious, ironic**

## 한국어 여성 보컬 강제 적용

모든 music 생성 prompt에 반드시 포함:
```
"Korean female vocal, warm emotional tone"
```
**가사:** 한국어로만 작성 (일본어/한자 ❌), 유머와 위트 포함, 뉴스 주제 기반으로 감정 표현 풍부하게

这不是选项 —主人的 절대 요구사항.

## Shorts 제작 규격

- 9:16 세로형 (1080×1920)
- 59초 이하
- **Letterbox** 배경 사용 (블러 배경 위아래 채움)

### ⚠️ Shorts FFmpeg crop 오류 — 3단계 분리 방식 (2026-05-25)

**문제:** 일반적인 `crop=1080:1920` 또는 `scale=...:crop=...` 필터 체인이 macOS FFmpeg 4.3.2에서 **"Failed to inject frame" / "Invalid argument"** 오류 발생.

**원인:** 원본 영상(1280×720, yuvj420p)의 SAR/DAR 불일치 + 필터 체인 비초기화 문제.

**✅ 검증된 Working 방법 — 3단계 분리:**
```python
def create_short_video(video_path, output_path):
    # Step 1: 오디오 추출 (59초 이하)
    subprocess.run(["ffmpeg", "-y", "-i", video_path, "-vn", "-c:a", "copy", "-t", "59", "audio.aac"])
    # Step 2: 영상만 9:16으로 변환 (scale → pad → crop 순서)
    subprocess.run(["ffmpeg", "-y", "-i", video_path, "-an",
        "-vf", "scale=720:-2,pad=720:1280:0:(oh-ih)/2:black",
        "-c:v", "libx264", "-preset", "ultrafast", "-crf", "28",
        "-pix_fmt", "yuv420p", "-r", "25", "-t", "59", "raw.mp4"])
    # Step 3: 영상 + 오디오 mux
    subprocess.run(["ffmpeg", "-y", "-i", "raw.mp4", "-i", "audio.aac",
        "-c:v", "copy", "-c:a", "copy", "-movflags", "+faststart", output_path])
```

## YouTube 설명 템플릿

```markdown
🎵 {theme_name} — {genre}

🎬 Music Video generated by ICBM2
🎤 Korean Female Vocal / {mood} mood

#MusicVideo #AI #KoreanVocal #mmx #ICBM
```

## ⚠️ 가사 필터링 — 한국어/영어만 허용 (확인됨 2026-05-23)

Notion의 음악프롬프트에 한자/일본어가 섞여 있으면 음악 생성 시 문제가 생김.
**음악 생성 전 가사에서 한자/일본어/기타 문자를 제거하는 함수를 반드시 사용:**

```python
import re

def filter_lyrics(text):
    """한국어(가-힣) + 영어 + 기본 punctuation만 남기고 제거"""
    filtered = re.sub(r'[^\uAC00-\uD7A3a-zA-Z0-9\s.,!?~()\-\'\"]+', '', text)
    filtered = re.sub(r'\s+', ' ', filtered).strip()
    return filtered
```

**적용 패턴:**
- Notion에서 `음악프롬프트` 읽기 → `filter_lyrics()` 적용 → `mmx music generate --lyrics` 전달
- Japanese/Chinese 섹션 마커는 유지 (`[Verse 1]`, `[Chorus]` 등 영어 태그만 허용)
- 실제 가사 내용에서 한자/일본어 제거 후 한국어만 남김

**테스트:**
```
원본: 골목 끝 네온불빛이 반짝여...街灯の下で二人歩いた... 우리만의秘密の夜
필터후: 골목 끝 네온불빛이 반짝여... 우리만의  (한자/일본어 제거됨)
```

**⚠️ mmx image 생성 — 출력 경로 문제 (발견됨 2026-05-23)**
`mmx image generate --out /path/to/output.png`을 실행해도 이미지가 다른 위치에 저장되는 경우가 있음:
- 지정한 `--out` 경로가 아닌 현재 디렉토리에 저장
- `.openclaw/workspace/` 폴더에 저장되는 경우도 있음

**확인 방법:** 생성 후 지정한 경로에 파일이 실제로 있는지 반드시 확인
```bash
ls -la /path/to/output.png  # 파일 없으면 다른 곳에서 찾기
find ~/.hermes -name "output.png" -newer /tmp/check  # 탐색
```

# 3개 이미지 Ken Burns + ngrok 검수 파이프라인 참고 (2026-05-25)

**⚠️ FFmpeg zoompan 방식 사용 (PIL Ken Burns 금지 — 300초 타임아웃 빈번)**

**핵심 교훈:**
- ngrok URL 추출은 `execute_code` ❌ → `terminal(background=true)` 사용
- audio.aac 추출 시 `-c:a copy` ❌ → `-c:a aac` 사용

## ⚠️ PIL Ken Burns 대신 FFmpeg zoompan 사용 (2026-05-25)

**문제:** `create_ken_burns_frames()`로 800+ 프레임을 PIL로 생성 → execute_code 300초 타임아웃 빈번.

**✅ FFmpeg zoompan 방식 (58초로 3개 세그먼트 완료):**
```python
segments = [
    ("img0.png", "seg0.mp4", 0, 67.4),
    ("img1.png", "seg1.mp4", 67.4, 134.8),
    ("img2.png", "seg2.mp4", 134.8, 202.2),
]
for img_path, out_path, start_t, end_t in segments:
    dur = end_t - start_t
    cmd = [
        "ffmpeg", "-y", "-loop", "1", "-i", img_path,
        "-filter_complex",
        "zoompan=z='min(zoom+0.001,1.5)':d=25:x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)',scale=1280:720",
        "-t", str(dur), "-c:v", "libx264", "-preset", "ultrafast", "-crf", "28",
        "-pix_fmt", "yuv420p", out_path
    ]
    subprocess.run(cmd, capture_output=True, timeout=120)
```

**핵심:** execute_code에서 ngrok stdout readline() → 300초 타임아웃. ngrok URL 추출은 `terminal(background=true)` 사용.

## mmx image --out 파일명 버그 (확인됨 2026-05-25)
`--out` 경로를 지정해도 이미지가 다른 디렉토리에 저장되는 경우 있음.
**확인:** 생성 직후 `ls -la /path/to/output.png`로 파일 존재 확인. 없으면 `find ~/.hermes -name "*.png" -newer /tmp/check`로 검색.

### ⚠️ mmx image 출력 파일명 충돌 — 항상 image_001.jpg로 저장 (2026-05-25)

`mmx image generate --out image_X.png`을 실행해도 **항상 `image_001.jpg`로 저장**됨. 다른 이름 지정 시에도 image_001.jpg만 생성.

**Workaround:** 3개 이미지를 모두 다른 디렉토리에서 순차 생성하거나, 생성 후 리네임:
```bash
# 각 호출 후 즉시 리네임 (다른 이름으로)
cd /dir/for/img0 && mmx image ... -o image_0.png && mv image_001.jpg image_0.png
cd /dir/for/img1 && mmx image ... -o image_1.png && mv image_001.jpg image_1.png
cd /dir/for/img2 && mmx image ... -o image_2.png && mv image_001.jpg image_2.png

# 또는 같은 디렉토리: 호출 3번 → 리네임 3번 (순서 중요!)
mmx image ... --seed 101 -o image_0.png && mv image_001.jpg image_0.png
mmx image ... --seed 102 -o image_1.png && mv image_001.jpg image_1.png
mmx image ... --seed 103 -o image_2.png && mv image_001.jpg image_2.png
```

### ⚠️ mmx image --out 파라미터가 무시됨 — 같은 디렉토리에서 3장 생성 시 이미지 교체 문제 (2026-05-25)

같은 디렉토리에서 `--out image_0.png`, `--out image_1.png`, `--out image_2.png`로 호출하면:
- 각 호출이 `image_001.jpg`를 생성 (--out 파라미터 무시)
- 이전 `image_001.jpg`를 덮어씀 (전부 같은 파일)

**✅ 검증된 Working 순서:**
```bash
cd /target/dir
mmx image "prompt1" --seed 101 -o image_0.png && mv image_001.jpg image_0.png  # 1) 생성+리네임
mmx image "prompt2" --seed 102 -o image_1.png && mv image_001.jpg image_1.png  # 2) 생성+리네임
mmx image "prompt3" --seed 103 -o image_2.png && mv image_001.jpg image_2.png  # 3) 생성+리네임
ls *.png  # image_0.png, image_1.png, image_2.png 확인
```

**❌ 잘못된 순서 (동시에 3개 생성 후 리네임):**
```bash
mmx image "p1" ... -o image_0.png &
mmx image "p2" ... -o image_1.png &  # 이게 image_001.jpg를 덮어씀
mmx image "p3" ... -o image_2.png &
wait
mv image_001.jpg image_0.png  # 1개만 남음!
```

**⚠️ Ken Burns — PIL 대신 FFmpeg zoompan 사용 (300초 타임아웃 방지)**

**문제:** `create_ken_burns_frames()`로 800+ 프레임을 PIL로 생성 → execute_code 300초 타임아웃 빈번.
→ **FFmpeg zoompan 세그먼트 방식 사용** (58초로 3개 세그먼트 완료, 검증됨).

**패턴:** `references/audio-aac-0bytes-fix-2026-05-25.md` 참고.

**❌ PIL Ken Burns 방식 (사용 금지):**
```python
# 300초 타임아웃 빈번 — 사용 금지
create_ken_burns_frames(img_path, frames_dir, fps=25, dur=67.4, ...)
```
→ **FFmpeg zoompan 세그먼트 방식을 반드시 사용** (58초로 3개 세그먼트 완성이 검증됨).

**✅ FFmpeg zoompan 세그먼트 방식 (검증됨 2026-05-25):**
```python
segments = [
    ("img0.png", "seg0.mp4", 0, 67.4),
    ("img1.png", "seg1.mp4", 67.4, 134.8),
    ("img2.png", "seg2.mp4", 134.8, 202.2),
]
for img_path, out_path, start_t, end_t in segments:
    dur = end_t - start_t
    cmd = [
        "ffmpeg", "-y", "-loop", "1", "-i", img_path,
        "-filter_complex",
        "zoompan=z='min(zoom+0.001,1.5)':d=25:x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)',scale=1280:720",
        "-t", str(dur), "-c:v", "libx264", "-preset", "ultrafast", "-crf", "28",
        "-pix_fmt", "yuv420p", out_path
    ]
    subprocess.run(cmd, ...)
```
실행 시간: 58초 (PIL 대비 5배 이상 빠름).

```python
from PIL import Image
import os

def create_ken_burns_frames(src_path, output_dir, fps=25, dur=72,
                            start_scale=1.0, end_scale=1.15):
    """Ken Burns 효과 프레임 생성 (Python PIL 방식)

    Args:
        src_path: 원본 이미지 경로
        output_dir: 프레임 저장 디렉토리
        fps: 프레임레이트
        dur: 지속 시간(초)
        start_scale: 시작 스케일 (1.0 = 원본)
        end_scale: 종료 스케일 (1.15 = 15% 확대)

    ⚠️ PIL Ken Burns 버그 주의 (2026-05-25): src.close()를 copy() 이전에 실행해야 함.
    src.close()를 copy() 이후에 실행하면 "ValueError: Operation on closed image" 발생.
    """
    src = Image.open(src_path)
    orig_w, orig_h = src.size
    total = fps * dur

    os.makedirs(output_dir, exist_ok=True)

    # ⚠️ copy() 이전에 원본 닫기 (순서 중요!)
    img_copy = src.copy()
    src.close()  # 반드시 copy() 이후이 아니라 이전에 닫기

    for frame in range(total):
        t = frame / fps
        progress = t / dur
        scale = start_scale + (end_scale - start_scale) * progress

        crop_w = int(1280 * scale)
        crop_h = int(720 * scale)
        left = (orig_w - crop_w) // 2
        top = (orig_h - crop_h) // 2

        cropped = img_copy.crop((left, top, left + crop_w, top + crop_h))
        resized = cropped.resize((1280, 720), Image.LANCZOS)
        resized.save(os.path.join(output_dir, f"frame_{frame:05d}.png"))
        cropped.close()
        resized.close()

    img_copy.close()
    return total
```

**권장 설정:**
- 이미지 1: `scale=1.0→1.15` (zoom in)
- 이미지 2: `scale=1.15→1.0` (zoom out)
- 이미지 3: `scale=1.0→1.12` (zoom in, 약간)

**FFmpeg로 프레임 → 영상:**
```bash
ffmpeg -y -framerate 25 -i frames_%05d.png -i audio.mp3 \
  -c:v libx264 -preset ultrafast -crf 23 \
  -c:a aac -b:a 192k \
  -movflags +faststart \
  output.mp4
```

## ⚠️ 다중 이미지 뮤직비디오 구성 (확인됨 2026-05-23)

3개 이미지로 구성된 뮤직비디오를 만들려면:

1. **이미지 3개 생성** (각각 다른 프롬프트 변형):
   ```bash
   mmx image generate --prompt "...variation 1..." --out img1.png
   mmx image generate --prompt "...variation 2..." --out img2.png
   mmx image generate --prompt "...variation 3..." --out img3.png
   ```

2. **음악 길이에 맞춰 3등분** (예: 212초 → 각 ~70초)

3. **세그먼트별 영상 생성** → 연결 (concat):
   ```bash
   # 세그먼트별 오디오 추출 + 영상
   for i in 1 2 3; do
     ffmpeg -y -i audio.mp3 -ss $(( (i-1) * 72 )) -t 72 -acodec copy audio_$i.mp3
     ffmpeg -y -loop 1 -i img$i.png -i audio_$i.mp3 \
       -vf "scale=1280:720:force_original_aspect_ratio=increase,crop=1280:720" \
       -c:v libx264 -preset ultrafast -crf 28 -c:a aac -b:a 192k \
       -t 72 seg_$i.mp4
   done
   
   # concat
   cat > concat.txt << EOF
   file 'seg_1.mp4'
   file 'seg_2.mp4'
   file 'seg_3.mp4'
   EOF
   ffmpeg -y -f concat -safe 0 -i concat.txt \
     -c:v libx264 -preset ultrafast -crf 23 \
     -c:a aac -b:a 192k \
     -movflags +faststart final.mp4
   ```

**결과:** 3개 이미지가 음악 구간마다 전환되는 뮤직비디오 (212초 = 3분 32초)

## 이미지 변형 프롬프트 생성 함수

```python
def generate_image_variants(base_prompt, output_dir, count=3):
    """기본 프롬프트에서 3개 변형 이미지 생성"""
    variants = [
        f"{base_prompt}, bright daylight, vivid colors, high-key lighting",
        f"{base_prompt}, warm golden hour, saturated tones, playful light",
        f"{base_prompt}, sunny atmosphere, comedic contrast, cheerful mood"
    ]
    image_paths = []
    for i, variant in enumerate(variants[:count]):
        img_path = os.path.join(output_dir, f"image_{i}.png")
        if mmx_image(variant, img_path):
            image_paths.append(img_path)
    return image_paths
```

## ⚠️ 이퀄라이저 애니메이션 오버레이 — W-500:H-180 동적 좌표 필수 (2026-05-25)

**절대 고정 좌표 사용 금지:** `overlay=920:600`은 1280x720에서만 우측 하단. 1920x1080에서는 중앙~우측에 배치됨.

**✅ 올바른 동적 좌표:**
```bash
ffmpeg -y -i main_video.mp4 -stream_loop -1 -i equalizer.gif \
  -filter_complex "[0:v][1:v]overlay=W-500:H-180:shortest=1[composed]" ...
```

모든 해상도에서 자동으로 우측 하단에 배치됨.

### 프로페셔널 디자인 개선 (家主님 "힙성이 이상하다" 피드백 반영)

**프로페셔널 디자인 개선 (家主님 "힙성이 이상하다" 피드백 반영):**
- 복수 주파수 조합 (2.5Hz + 4.0Hz + 6.5Hz) → 자연스러운 리듬
- 7색 그라데이션 팔레트 (빨→주→노→초→하늘→파→보라)
- 반사 하이라이트 + 하단 mirror 바 → 입체적 효과
- 바 개수 24개, 중앙 바가 더 흔들림 (center_weight)
- 매번 다른 random.seed (자연스러움)

### Python 코드 (PIL 기반)

```python
from PIL import Image, ImageDraw
import math, random

def create_professional_equalizer(output_path, width=360, height=120, num_frames=30, fps=30):
    num_bars = 24
    bar_w, bar_spacing, margin = 10, 5, 10
    palette = [(255,80,100),(255,140,60),(255,200,50),(100,255,150),(60,200,255),(100,120,255),(180,80,255)]
    random.seed(None)
    bass_h = [random.randint(40,90) for _ in range(num_bars//3)]
    mid_h = [random.randint(30,70) for _ in range(num_bars//3)]
    treble_h = [random.randint(20,55) for _ in range(num_bars//3+1)]
    base_heights = bass_h + mid_h + treble_h
    frames = []
    for frame in range(num_frames):
        img = Image.new('RGBA', (width, height), (0,0,0,0))
        draw = ImageDraw.Draw(img)
        t = frame / fps
        for i in range(num_bars):
            w1 = math.sin(2*math.pi*2.5*t + i*0.35)*0.45
            w2 = math.sin(2*math.pi*4.0*t + i*0.55)*0.35
            w3 = math.sin(2*math.pi*6.5*t + i*0.80)*0.20
            cw = 1.0 - abs(i - num_bars/2) / (num_bars/2) * 0.4
            wave = max(0.15, min(1.0, (w1+w2+w3)*cw + 0.5))
            bar_h = max(8, min(int(base_heights[i]*wave), height-margin*2-4))
            x = margin + i*(bar_w+bar_spacing)
            y_top = (height-bar_h)//2; y_bot = y_top+bar_h
            ci = int((i/num_bars)*(len(palette)-1))
            c = palette[min(ci, len(palette)-1)]
            draw.rounded_rectangle([x, y_top, x+bar_w, y_bot], radius=3, fill=c+(220,))
            hh = max(2, bar_h//4)
            draw.rounded_rectangle([x+1, y_top, x+bar_w-1, y_top+hh], radius=2,
                                   fill=tuple(min(255,v+60) for v in c)+(180,))
            mh = max(3, bar_h//5)
            draw.rounded_rectangle([x, y_bot-mh, x+bar_w, y_bot], radius=2,
                                   fill=tuple(max(0,v-40) for v in c)+(140,))
        frames.append(img)
    frames[0].save(output_path, save_all=True, append_images=frames[1:],
                   duration=int(1000/fps), loop=0, optimize=False)
    for f in frames: f.close()
```

### FFmpeg overlay

```bash
# 1920x1080: x=1560, y=960 / 1280x720: x=920, y=600
ffmpeg -y -i main_video.mp4 -stream_loop -1 -i equalizer.gif \
  -filter_complex "[0:v][1:v] overlay=1560:960:shortest=1" \
  -c:v libx264 -preset fast -crf 23 -c:a copy final.mp4
```

**핵심 옵션:**
- `W-500`: 영상 너비 - 500 (우측에서 500px 여백)
- `H-180`: 영상 높이 - 180 (하단에서 180px 여백)
- `-stream_loop -1`: GIF를 영상 길이만큼 무한 반복
- `shortest=1`: 메인 영상이 끝나면 전체 종료

## 위치 가이드 (동적 좌표)

| 영상 해상도 | overlay 좌표 | 설명 |
|-----------|-------------|------|
| 1920x1080 | `W-500:H-180` | 우측 하단 (500px 우측, 180px 하단) |
| 1280x720 | `W-500:H-180` | 동일하게 동작 |
| 1080x1920 (Shorts) | `W-480:H-180` | Shorts도 동일한 상대 위치 |

**⚠️ 절대 고정 좌표 사용 금지:** `overlay=920:600`은 1280x720에서만 우측 하단. 1920x1080에서는 완전히 잘못된 위치(중앙~우측)에 배치됨.

## ⚠️ 이미지 GitHub Pages 갤러리 백업 (확인됨 2026-05-23)

생성된 이미지를 온라인에서 열람 가능하도록 **별도 GitHub repo + GitHub Pages**로 백업.

### Repo 생성 및 Pages 활성화
```bash
# 새 repo 생성
gh repo create icbm2-gallery --public --description "ICBM2 Music Video Image Gallery"

# gallery 디렉토리 clone
mkdir -p ~/.hermes/music_videos/gallery_gh
cd ~/.hermes/music_videos/gallery_gh && git init
git remote add origin https://github.com/sigco3111/icbm2-gallery.git

# GitHub Pages 활성화
gh api -X POST repos/sigco3111/icbm2-gallery/pages \
  -f build_type=legacy \
  -f source[branch]=main \
  -f source[path]=/
```

### 갤러리 HTML 구성
GitHub Pages는 directory listing을 지원하지 않으므로, **정적 HTML + 수동 이미지 목록** 사용:
→ **대체됨 (2026-05-23): `gallery_data.json` + 동적 HTML 생성 방식** (아래 참고)

### 동적 갤러리 HTML 자동 생성 (2026-05-23)

`gallery_data.json`에 모든 뮤직비디오 메타데이터를 저장하고, `index.html`을 자동 생성하는 방식:

```json
{
  "entries": [
    {
      "date": "2026-05-23",
      "topic": "서울의 달콤한 밤 - 라멘 냄새가 기억이 돼",
      "mood": "우타이테",
      "youtube_url": "https://www.youtube.com/watch?v=...",
      "short_url": "https://www.youtube.com/watch?v=...",
      "lyrics": "골목 끝 네온불빛이 반짝여...",
      "images": ["20260523_image_0.png", "..."],
      "image_url": "https://raw.githubusercontent.com/sigco3111/icbm2-gallery/main/images/20260523_image_0.png"
    }
  ]
}
```

**갤러리 HTML 특징:**
- 검색 기능 (topic + lyrics + date로 필터링)
- 각 카드에 YouTube/Shorts 링크 버튼
- 가사 미리보기 + 토글 (80자 미리보기 → 전체 가사)
- 카드별 3개 이미지 나란히 표시 (flexbox, 33.33% 너비)
- `gallery_data.json` 자동 갱신 → `index.html` 재생성 → Git push → Pages 자동 갱신

**⚠️ ES5 호환性问题 및 해결 (2026-05-23):**
GitHub Pages에서 JavaScript 실행 안 되는 문제 발생.
**원인:** template literal(`` ` ``), `forEach()`, `const`/`let` 등 ES6+ 문법.
**해결:** 모든 JS를 ES5 호환 코드로 재작성:
- `` `hello ${world}` `` → `'hello ' + world`
- `arr.forEach(x => ...)` → `for (var i = 0; i < arr.length; i++) { ... }`
- `gallery.innerHTML +=` → `html +=` 후 `gallery.innerHTML = html` (for 루프 내에서 `innerHTML +=` 피하기)
- 템플릿 리터럴 내 `${value}` → 문자열 연결 `+ value +`

**⚠️ 디버깅 필수: inline JS 문법 검사 (2026-05-23):**
HTML 파일의 inline `<script>`에 문법 오류가 있으면 `node --check`로 즉시 검출 가능:

```bash
python3 -c "
import re
with open('index.html') as f:
    content = f.read()
match = re.search(r'<script>\n(.*?)\n    </script>', content, re.DOTALL)
if match:
    with open('/tmp/script_test.js', 'w') as f:
        f.write(match.group(1))
" && node --check /tmp/script_test.js
```

**이方法で検出した 버그 2개:**
1. `onclick="showImage('' + ...)"` — `''` 빈 문자열이 JS 파싱 실패 (→ `\'\'`로 수정)
2. `replace(/\n/g)` — HTML에서 `\`와 `n`가 줄바꿈으로 분리됨 (→ `replace(/\\n/g)`로 수정)

**Playwright로 브라우저 에러 확인:**
```python
page.on("pageerror", lambda err: errors.append(str(err)))  # 콘솔에 안 보이는 parse error 잡기
```

**⚠️ 가사가 한 줄만 표시되는 문제 (2026-05-23):**
**원인:** `gallery_data.json`의 `lyrics` 필드에 개행 `\n` 없이 한 줄로 저장됨.
**해결:** 
1. `gallery_data.json`에 가사 전체 저장 (개행 `\n` 포함)
2. JS에서 `lyricsEscaped = entry.lyrics.replace(/\n/g, '<br>')`로 변환 후 표시
3. 미리보기: 80자까지만 표시, 초과 시 `...` 추가

**⚠️ 이미지가 1장만 표시되는 문제 (2026-05-23):**
**원인:** `image_url` 단일 필드만 사용.
**해결:** `images` 배열 필드 사용:
```json
"images": [
  "https://raw.githubusercontent.com/sigco3111/icbm2-gallery/main/images/img1.png",
  "https://raw.githubusercontent.com/sigco3111/icbm2-gallery/main/images/img2.png",
  "https://raw.githubusercontent.com/sigco3111/icbm2-gallery/main/images/img3.png"
]
```
HTML에서 루프로 렌더링.

**URL:** https://sigco3111.github.io/icbm2-gallery/

**갤러리 자동 갱신 워크플로우:**
```
크론 실행 (20시)
  → mmx image/music/영상 생성
  → YouTube 업로드 (성공)
  → backup_to_gallery() 호출
    1. gallery_data.json 로드
    2. 새 entry 추가 (topic, youtube_url, short_url, lyrics, images, image_url)
    3. index.html 재생성 (gallery_data 기반)
    4. Git push → Pages 자동 갱신
```

**Python 구현 핵심:**
```python
def backup_to_gallery(image_paths, topic, youtube_url, short_url, mood, lyrics):
    init_gallery_repo()
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    # gallery_data.json 갱신
    data = load_gallery_data()
    new_entry = {
        "date": datetime.now().strftime("%Y-%m-%d"),
        "topic": topic,
        "mood": mood,
        "youtube_url": youtube_url,
        "short_url": short_url,
        "lyrics": lyrics[:200] if lyrics else "",
        "images": [f"{timestamp}_{os.path.basename(p)}" for p in image_paths],
        "image_url": f"https://raw.githubusercontent.com/sigco3111/icbm2-gallery/main/images/{timestamp}_{os.path.basename(image_paths[0])}"
    }
    data["entries"].insert(0, new_entry)
    save_gallery_data(data)
    generate_gallery_html(data)  # index.html 재생성
    # Git push...
```

**유지 vs 삭제:**
- ✅ 이미지 → GitHub gallery에 백업 (images/ 폴더, timestamp prefixed)
- ✅ gallery_data.json → 매번 갱신
- ✅ wave_animation.gif → 재사용 위해 유지
- ❌ 음악/비디오/숏츠 → 처리 후 삭제 (용량 절약)

```html
<!-- index.html 예시 (갤러리 카드 grid) -->
<script>
const data = {"images": [
  {"name": "img1.png", "label": "Neon City Night", "date": "2026-05-23"},
  // ...
]};
data.images.forEach(img => {
  gallery.innerHTML += `<div class="card">
    <img src="images/${img.name}" alt="${img.label}">
    <div class="card-info"><h3>${img.label}</h3><p>${img.date}</p></div>
  </div>`;
});
</script>
```

**URL:** https://sigco3111.github.io/icbm2-gallery/

### 스크립트 연동 (최종 구현)
```python
import subprocess, shutil, os
github_repo = "https://github.com/sigco3111/icbm2-gallery.git"
gallery_dir = os.path.join(OUTPUT_DIR, "gallery_gh")

# gallery_gh가 git repo가 아니면 초기화 (한번만)
if not os.path.exists(os.path.join(gallery_dir, ".git")):
    os.makedirs(gallery_dir, exist_ok=True)
    subprocess.run(["git", "init"], cwd=gallery_dir, capture_output=True)
    subprocess.run(["git", "remote", "add", "origin", github_repo], cwd=gallery_dir, capture_output=True)
    subprocess.run(["git", "fetch", "origin"], cwd=gallery_dir, capture_output=True)
    subprocess.run(["git", "checkout", "-b", "main"], cwd=gallery_dir, capture_output=True)

# 이미지를 gallery_gh에 복사
if image_dir and os.path.exists(image_dir):
    for img in os.listdir(image_dir):
        if img.endswith('.png'):
            shutil.copy2(os.path.join(image_dir, img),
                        os.path.join(gallery_dir, "images", f"{timestamp}_{img}"))

# 음악/비디오/숏츠는 삭제
for path in [music_path, video_path, video_with_wave, short_path]:
    try:
        if path and os.path.exists(path): os.remove(path)
    except: pass

# GitHub에 푸시
subprocess.run(["git", "add", "."], cwd=gallery_dir, capture_output=True)
result = subprocess.run(["git", "commit", "-m", f"Gallery update {timestamp}"],
                       cwd=gallery_dir, capture_output=True)
if result.returncode == 0:
    subprocess.run(["git", "push", "origin", "main"], cwd=gallery_dir, capture_output=True)
```

**유지 vs 삭제:**
- ✅ 이미지 → GitHub gallery에 백업
- ✅ wave_animation.gif → 재사용 위해 유지
- ❌ 음악/비디오/숏츠 → 처리 후 삭제 (용량 절약)

**GitHub Pages 빌드:** 새 commit push 후 빌드 자동 시작. `gh api repos/.../pages/builds/latest`로 상태 확인 가능.

---

## 음악 길이 3분 이상 만들기 — expand_lyrics() 자동 확장 (확인됨 2026-05-23)

**`--duration` 파라미터 없음** — API가 자동으로 길이를 결정.

**핵심 원리:** 가사의 section 구조와 양이 생성される 음악의 길이를 결정.

**단순히 상세하게 쓸 경우:** 70~100초
**expand_lyrics() 함수 사용 시:** 1,500자+ → 3분+ (109자 → 1,591자 확인)

### expand_lyrics() 구현 (music_video_producer.py에 구현済み)

```python
STRUCTURE_TAGS = ['Verse', 'Chorus', 'Bridge', 'Pre-Chorus', 'Intro', 'Outro']

def expand_lyrics(text, target_chars=1500):
    """짧은 가사를 3분 분량(~1500자)으로 자동 확장"""
    # 1. 구조 태그 [Verse], [Chorus] 등 인식하여 섹션 분리
    # 2. 원본 가사 반복 추가 (target_chars 도달 시停止)
    # 3. 반복 시 태그에 번호 부여: [Verse] → [Verse 2]
```

**mmx_music()에서의 활용:**
```python
lyrics = expand_lyrics(raw_lyrics, target_chars=1500)  # 3분 목표
# mmx music generate --lyrics "$lyrics" ...
```

**주의:**gallery_data.json 저장 시 lyrics 필드에 전체(확장된) 가사 저장. preview는 별도 속성.
```html
<!-- ✅ 올바른 패턴: data-fulllyrics 속성에 전체 가사 저장 -->
<p class="lyrics-preview has-full"
   data-fulllyrics="골목 끝 네온불빛이 반짝여 따뜻한 바람이 내 볼을 스쳐
라멘摊에서 마주친 그 눈빛
아무 말 없이 웃어주는 게 좋아"
   onclick="showLyrics(this)">"골목 끝 네온불빛이 반짝여 따뜻한 바람이 내 볼을 스쳐..."</p>

<!-- ❌ 잘못된 패턴: preview 텍스트 자체가 전부여서 토글해도 의미 없음 -->
<p class="lyrics-preview" onclick="toggleLyrics(this)">"골목 끝 네온불빛이 반짝여..."</p>
```

**주인님 직접 피드백 (2026-05-23):** gallery 카드에 "3분 32초 Extended"라고 적혀있으나 실제 영상은 48초 — 가사가 짧아서 발생. 크론 로그에서 확인할 것.

**주인님 직접 피드백 (2026-05-23):** "가사 클릭하면 전체 가사 보기" 요청 → 구현했으나 시크릿창에서도 작동 안 함. 원인은 preview 텍스트("골목 끝...") 자체가 가사의 전부여서 토글해도 표시할 추가 텍스트가 없음. **가사 토글의 전제 조건:** gallery_data.json의 lyrics 필드에 실제 전체 가사가 저장되어 있고, preview는 별도 짧은 텍스트여야 함. 현재 "서울의 달콤한 밤" 카드만 전체 가사가 저장되어 있어서 해당 카드만 토글 작동.

**주인님 직접 피드백 (2026-05-24):** YouTube 429 발생 시 "쿼타 부족이 아니라 네가 잘못처리하는 거" — 만료된 토큰이 429의 가장 흔한 원인. 자세한 디버깅 과정과 수정된 워크플로우는 `references/yt-upload-429-debug-2026-05-24.md` 참고.

**⚠️ Notion API DB query 404 문제 — 외부 도구에서 Notion DB 등록 시 (2026-05-25):**
외부 도구(execute_code, plain curl)에서 `POST /v1/databases/{id}/query`가 404 반환. 해결: `references/notion-api-workaround.md` 참고 — search 엔드포인트 또는 parent page ID 방식 사용.

| 2026-05-24 | `HERMES_CRON_SCRIPT_TIMEOUT=600` 환경변수 추가 — 120초 스크립트 타임아웃 문제 해결 (`references/cron-script-timeout.md` 참고) |
| 2026-05-24 | ngrok으로 영상 검수 파이프라인 전환 — Cloudflare Tunnel 완전 폐기 (`references/ngrok-video-review.md` 신규 생성) |
| 2026-05-24 | YouTube 업로드 후 gallery 자동 갱신 안 되던 문제 해결 (`references/gallery-auto-update-2026-05-24.md` 신규 생성) |
| 2026-05-24 | Gallery 모달 이미지 뷰어 추가 + 삼겹살 AI 생성 이미지로 교체 (`references/gallery-modal-fix-2026-05-24.md` 신규 생성) |
| 2026-05-24 | 이미지 스타일 Photorealism만 허용 (cartoons/kawaii 완전 금지) —家主님 직접 피드백 반영 |
| 2026-05-24 | 후렴 선행형(Hook First) 구조 선호 기록 |
| 2026-05-24 | Cloudflare Tunnel 방식으로 영상 검수 링크 공유 — subprocess.Popen + readline() URL 추출 패턴 추가 |
| 2026-05-24 | 뉴스 수집 → Notion 등록 파이프라인 신규 추가 |
| 2026-05-23 | 0-byte 빈 MP4 파일 발생 방지 패턴 추가 |
| 2026-05-23 | Self-Healer 가양성 오탐 패턴 문제 문서화 (ISS-037) |

## Pipeline Overview (from music-video-pipeline)

```\n10:00 Cron ──→ Reddit/X 유머/위트 주제 수집 ──→ 3 Topics ──→ Notion ──→ Telegram Alert\n                                                             │\n                                                             ▼\n20:00 Cron ──→家主님이 선택한侯選 조회 ──→ [Process Loop]\n                                              │\n                        ┌─────────────────────┼─────────────────────┐\n                        ▼                     ▼                     ▼\n                   mmx image            mmx music            FFmpeg compose\n                        │                     │                     │\n                        └─────────────────────┼─────────────────────┘\n                                              ▼\n                                    music_video.mp4\n                                              │\n                         ┌────────────────────┴────────────────────┐\n                         ▼                                         ▼\n              ngrok review link                              Shorts (9:16)\n                         │                                         │\n                         ▼                                         ▼\n                   Telegram review                         (uploaded with main)\n                         │\n                         ▼\n              'confirm' ──→ YouTube Upload\n                         │\n                         ▼\n                   Notion Status → 완료\n```

## Components (from music-video-pipeline)

### Notion DB
- **DB ID:** `36976f2e-9097-81e1-a373-e06f2da6e99c`
- **Page:** ICBM2 workspace (36376f2e-9097-8182-ab21-c5e61ae6b40a)
- **Properties:** 주제, 상태, 분위기, 음악스타일, 이미지프롬프트, 음악프롬프트, 뉴스출처, 영상경로, 유튜브URL, 생성일

### Cronjobs
| Time | Job | Note |
|------|-----|------|
| 10:00 |侯選 수집 (jID: fcfd160352ff) | Reddit/X에서 유머/위트 자동 수집 — 블로그 GeekNews와 완전 별개 |
| 20:00 | Production + upload | `music_video_producer.py` |

## Related Files
- `references/direct-input-music-video.md` —家主님 직접 입력만으로 뮤직비디오를 제작하는 완전한 단계별流程 (2026-05-25)
- `references/review-enforcement-2026-05-25.md` — 검수 강제화: upload_youtube() 더미화, --approved 모드 필수,家主님 승인 루프
- `references/3min-lyrics-guarantee-2026-05-25.md` — 음악 3분 보장: expand_lyrics() 1800자 target + 재확장 로직 + 500자 이하 차단
- `references/pil-import-error-venv-path.md` — python3 vs venv 경로 충돌로 PIL ImportError 발생 시 해결 방법 (2026-05-25)
- `references/ngrok-404-http-server-directory-2026-05-25.md` — ngrok 404: HTTP 서버가 홈 디렉토리에서 실행
- `music-video-pipeline`: Alternative class-level description for music video automation

## 변경 이력

| 날짜 | 내용 |
|------|------|
| 2026-05-24 | 후렴 선행형(Hook First) 세션 기록 (`references/socks-washing-machine-session.md`) |
| 2026-05-24 | Cloudflare Tunnel 방식으로 영상 검수 링크 공유 |
| 2026-05-24 | 뉴스 수집 → Notion 등록 파이프라인 신규 추가 |
| 2026-05-24 | 이미지 스타일 가이드 명확화: cartoon + photorealistic 모두 "밝고 귀여운" 충족 시 혼용 가능 |
| 2026-05-23 | 0-byte 빈 MP4 파일 발생 방지 패턴 추가 |
| 2026-05-23 | Self-Healer 가양성 오탐 패턴 문제 문서화 (ISS-037) |

`music_video_producer.py` 실행 시 0-byte 빈 MP4 파일이 다수 발생하는 문제 발견.

**증상:**
```
-rw-r--r-- 1 hjshin  staff  0 May 23 21:50 short_t1_v2.mp4
-rw-r--r-- 1 hjshin  staff  0 May 23 21:50 short_t1_final_v2.mp4
(9개 파일 + test_multi/seg_1_kb.mp4)
```

**원인 추정:**
- FFmpeg 이미지→동영상 변환 시 audio sync 문제
- `--shortest` 플래그와 `-t` 시간指定 충돌
- Ken Burns 프레임 생성 단계에서 PIL→FFmpeg 연결 실패

**0-byte 파일 정리:**
```bash
find ~/.hermes/music_videos/ -name "*.mp4" -size 0 -mtime 0 -delete
```

**防范措施:**
1. FFmpeg 인코딩 직후 파일 크기 확인 — 0 byte면 인코딩 재시도
2. `-t` 시간指定과 `-shortest` 동시 사용 금지 (하나만 사용)
3. Ken Burns 프레임 생성 → FFmpeg 인코딩 파이프라인에서 프레임 파일 존재 확인 후 인코딩

```python
def verify_video_created(path, min_size=10000):
    """영상 생성 후 0-byte 방지 검증"""
    if not os.path.exists(path):
        return False
    size = os.path.getsize(path)
    if size < min_size:
        print(f"⚠️ 영상 크기 이상 ({size} bytes) — 재시도 필요")
        return False
    return True
```

**⚠️ Gallery lyrics 0글자 문제:** → `references/gallery-automation.md` 참고
Fixed three inline JS issues. Bugs 1+2 prevented gallery from rendering at all. Bug 3 prevented image lightbox even after syntax fix.

**Bug 1:** `onclick="showImage('' + ...)"` — `''` empty string breaks JS parse → fixed to `\'\'`
**Bug 2:** `replace(/\n/g)` where `\n` in HTML becomes actual newline → fixed to `replace(/\\n/g)`
**Bug 3 (silent):** Long `JSON.stringify()` in onclick gets silently truncated by browser, breaking the handler entirely. Fixed by using `data-images` + `data-index` attributes + delegated event listener instead of inline onclick.

Debug method: extract inline script → `node --check /tmp/script.js`. Playwright catches runtime errors via `page.on("pageerror")`.

**Gallery Lightbox Feature (2026-05-23):**
Added lightbox modal for in-page image viewing:
- Click any thumbnail → fullscreen lightbox with navigation
- ← → arrow keys navigate, ESC closes
- Background click closes
- Caption shows "X / Y" (image index)

```javascript
var currentImages = [];
var currentIndex = 0;

function openLightbox(src, images, index) {
    currentImages = images;
    currentIndex = index;
    document.getElementById('lightbox-img').src = src;
    document.getElementById('lightbox-caption').textContent = (index + 1) + ' / ' + images.length;
    document.getElementById('lightbox').classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeLightbox() {
    document.getElementById('lightbox').classList.remove('active');
    document.body.style.overflow = '';
}

function navigateLightbox(dir) {
    currentIndex = (currentIndex + dir + currentImages.length) % currentImages.length;
    document.getElementById('lightbox-img').src = currentImages[currentIndex];
    document.getElementById('lightbox-caption').textContent = (currentIndex + 1) + ' / ' + currentImages.length;
}

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') closeLightbox();
    if (e.key === 'ArrowLeft') navigateLightbox(-1);
    if (e.key === 'ArrowRight') navigateLightbox(1);
});
document.getElementById('lightbox').addEventListener('click', function(e) {
    if (e.target === this) closeLightbox();
});
```

CSS: `.lightbox` fixed overlay, `.lightbox.active { display: flex; }`, nav buttons positioned absolutely.

**⚠️ gallery_data.json → index.html 렌더링 시 반드시 지켜야 할 패턴 (2026-05-23):**

1. **이미지 3개 모두 렌더링**: `image_url` 단일 필드 사용 금지 → `images` 배열 루프로 3개 img 태그 생성:
```html
<div class="card-img-wrap three">
  <img class="card-img" src="images[0]" onclick="openModal(this)">
  <img class="card-img" src="images[1]" onclick="openModal(this)">
  <img class="card-img" src="images[2]" onclick="openModal(this)">
</div>
```
**실수 금지**: HTML 소스에 1개만 하드코딩하지 말 것 — 항상 images 배열 길이만큼 루프.

2. **가사 토글**: preview 텍스트와 전체 텍스트를 **별도 속성**으로 분리:
```html
<!-- ✅ 올바른 패턴 -->
<p class="lyrics-preview has-full"
   data-fulllyrics="골목 끝 네온불빛이 반짝여 따뜻한 바람이..."
   onclick="showLyrics(this)">"골목 끝 네온불빛이..."</p>

<!-- ❌ 잘못된 패턴: preview 텍스트 자체가 전부 -->
<p class="lyrics-preview" onclick="toggleLyrics(this)">"골목 끝 네온불빛이..."</p>
```
`data-fulllyrics` 없는 카드(가사 없음)는 토클해도 의미 없음.

**가사 토글 — preview와 fulllyrics를 반드시 분리해서 저장 (2026-05-23):**
```html
<!-- ✅ 올바른 패턴: data-fulllyrics 속성에 전체 가사 저장 -->
<p class="lyrics-preview has-full"
   data-fulllyrics="골목 끝 네온불빛이 반짝여 따뜻한 바람이 내 볼을 스쳐
라멘摊에서 마주친 그 눈빛
아무 말 없이 웃어주는 게 좋아"
   onclick="showLyrics(this)">"골목 끝 네온불빛이 반짝여 따뜻한 바람이 내 볼을 스쳐..."</p>

<!-- ❌ 잘못된 패턴: preview 텍스트 자체가 전부여서 토글해도 의미 없음 -->
<p class="lyrics-preview" onclick="toggleLyrics(this)">"골목 끝 네온불빛이 반짝여 따뜻한 바람이..."</p>
```
가사 없는 카드(예: 고양이ICloud 사건)는 `data-fulllyrics` 없이 토클해도 의미 없음.

**⚠️ Self-Healer 가양성 주의 — 단어 경계 필요 (ISS-037):**

Self-Healer의 `cron_self_healer.py`가 `jobs.json` 상태와 무관하게 크론 출력에서 `APIError` 패턴을 오탐하는 문제 (ISS-037로 추적).

**오탐 패턴:**
```python
r"(?:api.*(?:error|401|403|429|500)|unauthorized)"
```
이 패턴이 "notion-401-troubleshooting.md", "status code 401" 등 일반 텍스트의 `401`도 APIError로 오인식.

**실제 성공 여부 판단:**
```bash
grep -i "✅\|❌\|complete\|success" <job_output>.md
```

**개선 패턴 (단어 경계 추가):**
```python
r"\b(?:api.*(?:error|failed)|unauthorized|rate\s*limit)\b"
```

**문제 원인:** jobs.json은 모두 "ok" 상태이나, 출력 파일의 일반 텍스트에 "401", "API error" 등이 포함되어 있으면 오탐.

**체크리스트:** Self-Healer가 "실패"라고 표시해도 → jobs.json 상태 확인 → 실제 성공 여부 판단.

**YouTube Quota 초과 시 파일 처리 — 주인님 확인 필요 (2026-05-23):**

YouTube 일일 업로드 quota(6개/일) 소진 시:
1. 영상 파일은 항상 로컬에 유지 (`~/.hermes/music_videos/`)
2. 파일명 패턴: `video_YYYYMMDD_HHMMSS.mp4` (메인), `short_YYYYMMDD_HHMMSS.mp4` (Shorts)
3. **주인님이 텔레그램으로 파일 전송 요청 시** → Telegram Bot API로 직접 전송
   - Bot Token: `~/.hermes/secrets/telegram_bot_token.txt`
   - Chat ID: `~/.hermes/secrets/telegram_chat_id.txt`
   - **현재 토큰이 placeholder 상태** (`PLACEHOLDER_TOKEN_REPLACE_WITH_REAL`) → 전송 불가
   - 해결 방법: BotFather에서 새 토큰 발급 후 파일 교체

**주인님 확인용 파일 식별:**
- 오늘 제작된 영상: `video_20260523_202145.mp4` (석유값 동결), `video_t1.mp4` (스테로이드 올림픽)
- Shorts: `short_20260523_202145.mp4`, `short_t1_with_audio.mp4`
- 두 주제 모두 gallery에 없는 **신규 제작 영상**

**전송 명령 (BOT TOKEN 방식 — 이미지 전용):**
```bash
TOKEN=$(cat ~/.hermes/secrets/telegram_bot_token.txt | grep -v "^#" | tr -d ' \n')
CHAT=$(cat ~/.hermes/secrets/telegram_chat_id.txt | tr -d ' \n')
curl -s -F "chat_id=$CHAT" \
     -F "document=@/path/to/video.mp4" \
     -F "caption=🛢️ {주제명}" \
     "https://api.telegram.org/bot$TOKEN/sendDocument"
```

**주인님께 영상 보내드리는 방법 (2026-05-23 확인):**
```
1. 응답에 MEDIA:/path/to/video.mp4 포함 (이게 작동하는 유일한 방법)
2. hermes send CLI는 텍스트만 전송, 미디어 불가
3. Bot Token 방식은 이미지에는 작동하나 영상은 404 에러 (토큰 문제)
4. gallery_data.json의 youtube_url에 로그 텍스트 오염 버그 → 항상 URL만 저장
```

## 영상 검수 파이프라인 — ngrok 우선 (2026-05-24)

**⚠️ Cloudflare Tunnel은 완전 폐기 — Error 1033 빈번, 작동 안 함**

### ngrok 설치 및 설정 (1회만)

```bash
brew install ngrok
ngrok config add-authtoken <your-authtoken>  # ngrok.com 무료 계정에서 token 복사
```

### ngrok.com 무료 계정 및 Authtoken 설정

1. https://ngrok.com에서 계정 생성
2. Dashboard → Your Authtoken → 복사
3. 로컬에서 authtoken 등록:
```bash
ngrok config add-authtoken <your-authtoken>
```

### 검수 링크 생성 스크립트

```python
import subprocess, re, time, os

def create_review_link(video_dir, port=8768):
    """ngrok으로 영상 검수용 외부 접근 링크 생성"""

    # 1. HTTP 서버 시작
    http_proc = subprocess.Popen(
        ["python3", "-m", "http.server", str(port)],
        cwd=video_dir,
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
    )
    time.sleep(2)

    # 2. ngrok Tunnel 시작
    ngrok_proc = subprocess.Popen(
        ["ngrok", "http", str(port)],
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT
    )

    # 3. URL 추출 (ngrok API — localhost:4040)
    time.sleep(5)
    url = None
    try:
        import urllib.request
        resp = urllib.request.urlopen("http://localhost:4040/api/tunnels")
        data = json.loads(resp.read().decode())
        for t in data.get('tunnels', []):
            if t.get('proto') == 'https':
                url = t.get('public_url')
                break
    except:
        pass

ngrok_proc.kill()  # 필요 시 정리

# 사용 예시 끝

## 관련 참고 자료

- `references/video-concat-black-screen-fix.md` — concat+mux 영상의 검은 화면 문제 해결 (2026-05-25)
- `references/cloudflare-tunnel-url-extract.md` — cloudflare 터널 URL 추출
url, http_proc, ngrok_proc = create_review_link("/path/to/video/folder")
if url:
    video_link = f"{url}/video_wave.mp4"
    short_link = f"{url}/short.mp4"
    print(f"🔗 검수: {video_link}")
```

### 검수 요청 메시지 템플릿

```
🎬 뮤직비디오 검수

제목: {주제명}
분위기: {mood}
곡 구조: 후렴 선행형 (Hook First)
길이: {duration}

🔗 검토 링크:
- 메인: {url}/video_wave.mp4
- Shorts: {url}/short.mp4

✅ 확인 → YouTube 업로드
✏️ 수정 → 내용告诉他
```

### 사용 후 정리 (중요!)

```python
cf_proc.terminate()  # ngrok/cloudflared 종료
http_proc.terminate() # HTTP 서버 종료
```

## ngrok 기반 영상 검수 (2026-05-24)

**Cloudflare Tunnel 대신 ngrok 사용** — Error 1033 문제로 변경

### 설치
```bash
brew install ngrok
```

### 설정 (1회)
1. ngrok.com에서 무료 계정 생성
2. authtoken 복사
3. `ngrok config add-authtoken <token>`

### 사용법
```python
# HTTP 서버 + ngrok Tunnel
import subprocess, re, time

http_proc = subprocess.Popen(
    ["python3", "-m", "http.server", "8765"],
    cwd=video_dir, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
)

ngrok_proc = subprocess.Popen(
    ["ngrok", "http", "8765"],
    stdout=subprocess.PIPE, stderr=subprocess.STDOUT
)

url = None
while time.time() - start < 15:
    line = ngrok_proc.stdout.readline().decode()
    if "ngrok.io" in line:
        url = re.search(r'https://[a-z0-9]+\.ngrok\.io', line).group(0)
        break

video_link = f"{url}/{filename}"
# Telegram으로 링크 전송
```

### ⚠️ ngrok ERR_NGROK_334 — 기존 터널 충돌 해결 (2026-05-25)
### ⚠️ ngrok ERR_NGROK_334 — 기존 터널 충돌 해결 (2026-05-25)

**문제:** ngrok免费 계정에서 `failed to start tunnel: The endpoint 'https://xxx.ngrok-free.dev' is already online` 오류 발생 — 기존 실행 중인 ngrok 프로세스와 충돌.
**원인:** 무료 ngrok 계정은同一 endpoint에 두 개 이상의 터널을 동시에 실행 불가.
**해결 순서:**
1. 기존 ngrok 프로세스 전체 kill: `pkill -f "ngrok http"`
2. 새 터널 실행: `ngrok http <PORT> --pooling-enabled`
3. `--pooling-enabled` 플래그로 복수 터널 허용

### ⚠️ ngrok 검수 재시도 시 포트/프로세스 정리 (2026-05-25)

**문제:** `music_video_review.py`로 ngrok 검수를 재시도할 때 HTTP 服务器가 `python3.1` (hermes-agent venv)으로 실행되어 포트 점유 + `python3.9` (system Python)와 충돌.

**반드시 지켜야 할 순서:**
```bash
# Step 1: 모든 기존 프로세스 정리
pkill -f "ngrok http"      # ngrok 프로세스 kill
pkill -f "python.*http.server.*876"  # HTTP 서버 kill
lsof -i :8765             # 포트 8765 점유 확인

# Step 2: 포트가 여전히 점유되면 (python3.1이 점유 중)
kill -9 <PID>              # 해당 PID 강제 종료
sleep 1
lsof -i :8765             # 빈 상태 확인

# Step 3: ngrok 실행 전 HTTP 서버를 system python3.9로 먼저 시작
cd ~/.hermes/music_videos
/usr/bin/python3 -m http.server 8765  # background=true로 실행

# Step 4: ngrok tunnel 실행
ngrok http 8765            # background=true로 실행
# Step 5: ngrok URL 확인
sleep 8
curl -s http://localhost:4040/api/tunnels | python3 -c "import sys,json; d=json.load(sys.stdin); [print(t['public_url']) for t in d.get('tunnels',[])])"
```

**핵심教训:** `music_video_review.py`의 `start_http_server()`가 `subprocess.Popen(["python3", ...])`으로 시작하면 hermes-agent venv의 `python3.1`이 사용됨. 반드시 system `/usr/bin/python3` 사용.

### ⚠️ ngrok URL 추출 실패 시 대안

### ⚠️ ngrok URL 추출 — execute_code에서 subprocess.Popen 사용 시 타임아웃 빈번

**문제:** `execute_code`에서 ngrok stdout을 readline()으로 URL 추출 시 300초 execute_code 타임아웃 발생.
**원인:** ngrok이 tunnel 설정 완료 전에는 stdout에何も出力せず, URL 추출 대기 중 execute_code 300초限制突破.

**✅ 검증된 Working 방식 — terminal tool background=true 사용:**
```bash
# terminal에서 background=true로 HTTP 서버 + ngrok 동시 실행
terminal(background=true, command="/usr/bin/python3 -m http.server 8765")  # PID: 69701
terminal(background=true, command="ngrok http 8765")  # PID: 69764

# 10초 후 URL 추출
curl -s http://localhost:4040/api/tunnels | /usr/bin/python3 -c "import sys,json; d=json.load(sys.stdin); [print(t['public_url']) for t in d.get('tunnels',[])]"
# → https://require-entangled-primer.ngrok-free.dev
```

**핵심:** ngrok URL 추출은 `execute_code` ❌ → `terminal(background=true)` + curl 사용.

**관련:** `references/audio-aac-0bytes-fix-2026-05-25.md` — audio.aac 0 bytes, ngrok 타임아웃, FFmpeg zoompan 패턴

### ⚠️ 주의사항
- 무료 계정: 세션 종료 시 URL 회수, 재연결 시 새 URL 발급
- **ngrok 프로세스 중복 실행 시 `ERR_NGROK_334` 에러** — 새 포트 사용하거나 기존 프로세스 kill 후 재시작
- ngrok 실행 중이면 `curl http://localhost:4040/api/tunnels`로 현재 URL 확인 가능

---

## ⚠️ 크론 실행 시 모니터링 패턴 (중요!)

**`cronjob(action='list')`의 `last_status`는 스케줄 실행 기준만 반영**
수동 트리거(`cronjob run`)는 `last_run_at`만 갱신하고 `last_status`를 갱신하지 않음.

**올바른 확인 방법:**
```bash
# 1. 프로세스 존재 확인 (실행 중이면 PID가 보임)
ps aux | grep music_video_producer | grep -v grep

# 2. 출력 파일 timestamps (업데이트되면 완료됨)
ls -lt ~/.hermes/cron/output/a77ee904fa61/

# 3. 크론 job의 no_agent 스크립트 타임아웃 디폴트: 120초
#    → 600초로 증가: ~/.hermes/.env에 HERMES_CRON_SCRIPT_TIMEOUT=600 추가
```

## ❤️‍🔥 곡 구조 선호: 후렴 선행형 (Hook First) (2026-05-24)

家主님께서 후렴이 초반부터 나오는 **Hook First / Immediate Chorus** 구조의 곡을特别喜欢하십니다.

**뮤직비디오候選 시 필수 체크:**
- ✅ 후렴이 Verse 이전에 나오는 구조인지 확인
- ✅ 후렴이 인트로부터 시작하는 곡 우선 선택

**대표적인 Hook First 곡 예시:**
- 🎸 "Let It Be" - Beatles
- 🎹 "Imagine" - John Lennon
- 🎸 "Smells Like Teen Spirit" - Nirvana

**K-Pop에서 후렴 선행형 사례:**
- 인트로에서부터 클림맥 후렴이 나옴
- Verse가 짧거나 없이 후렴으로 시작

**가사 작성 시 구조:**
```
[Chorus]        ← 후렴이 먼저! (Hook First)
" ... 후렴 가사 ..."
[Verse 1]
...
[Chorus]
...
```

이 구조를 필수로 반영하여 음악 프롬프트 작성 시 `[Chorus]`를 맨 앞에 배치.

---

## 변경 이력

| 날짜 | 내용 |
|------|------|
| 2026-05-25 |家主님이 직접 요청 시 2D/cartoon/kawaii 허용 규칙 추가 (쯔양 MV 세션) |
| 2026-05-25 |侯選 수집 파이프라인 완전 개편 — GeekNews 기반 → Reddit/X 유머/위트 자유 수집 |
| 2026-05-24 | ngrok으로 영상 검수 파이프라인 전환 — Cloudflare Tunnel 완전 폐기 (`references/ngrok-video-review.md` 신규 생성) |
| 2026-05-24 | YouTube 업로드 후 gallery 자동 갱신 안 되던 문제 해결 (`references/gallery-auto-update-2026-05-24.md` 신규 생성) |
| 2026-05-24 | Gallery 모달 이미지 뷰어 추가 + 삼겹살 AI 생성 이미지로 교체 (`references/gallery-modal-fix-2026-05-24.md` 신규 생성) |
| 2026-05-24 | 이미지 스타일 Photorealism만 허용 (cartoons/kawaii 완전 금지) —家主님 직접 피드백 반영 |
| 2026-05-24 | 후렴 선행형(Hook First) 구조 선호 기록 |
| 2026-05-24 | Cloudflare Tunnel 방식으로 영상 검수 링크 공유 — subprocess.Popen + readline() URL 추출 패턴 추가 |
| 2026-05-24 | 뉴스 수집 → Notion 등록 파이프라인 신규 추가 |
| 2026-05-23 | 0-byte 빈 MP4 파일 발생 방지 패턴 추가 |
| 2026-05-23 | Self-Healer 가양성 오탐 패턴 문제 문서화 (ISS-037) |