---
name: rust-tui-game
description: Use when building a TUI game in Rust — ratatui stack.
tags: rust, tui, roguelike, ratatui, crossterm, hecs, doryen-fov, game-development
---

# Building TUI games in Rust (asciirogue-style)

Use when scaffolding, extending, or debugging a **terminal-user-interface game** in Rust — roguelikes, dungeon crawlers, ASCII arcades. Triggers: starting a new ratatui project; adding FOV / movement / ECS to an existing TUI prototype; needing to verify the game output without a real TTY (sandbox / CI); integrating `doryen-fov`.

> Cross-reference: the work this captures originated in `sigco3111/asciirogue` (5-crate workspace). Its `docs/SPEC.md` carries design notes; its `crates/app/src/main.rs` is the canonical exemplar.

---

## Stack primitives (versions pinned in asciirogue as of 2026-07-29)

| Layer | Crate | Notes |
|---|---|---|
| Terminal render | `ratatui 0.29` + `crossterm 0.28` | Standard pair. `Frame<'_>` lifetime is explicit (see gotchas). |
| ECS | `hecs 0.10` | Single-threaded, ergonomic for TUI scale. Avoid `specs` for new code. |
| FOV | `doryen-fov 0.1.1` (pure Rust port of libtcod's algorithm) | Trivial integration; see references for API surface. |
| Procgen / RNG | `bracket-random 0.8` or hand-rolled xorshift | Deterministic from seed = testable. |
| Serialization | `serde` + `ron` for save/load | RON > JSON (Rust-native, commentable). |

Avoid: `tui-rs` (deprecated, parent project migrated to ratatui), `bevy` + `bevy_tui` for simple TUI games (overkill), SDL/web bindings when pure TUI is the goal.

---

## Architecture: the 5-crate workspace pattern

This is what `asciirogue` uses:

```
project/
├── crates/
│   ├── core/       # hecs components (Position, Renderable, Viewshed, ...) — no render dep
│   ├── procgen/    # BSP / tables — no render dep
│   ├── combat/     # damage formulas, status effects — no hecs dep
│   ├── render/     # ratatui widgets, wall_glyph(), draw_world() — depends on procgen + core
│   └── app/        # main binary: hecs World, input loop, --dump mode, --help
├── Cargo.toml      # [workspace] + [workspace.dependencies]
├── README.md
└── docs/SPEC.md    # design notes (mirrored if distributed)
```

**Why**

- `core` is pure data — easy to unit-test.
- `procgen` is deterministic and pure — easy to fuzz with seeded tests.
- `combat` can be designed without committing to ECS or render — the maths stays self-contained.
- `render` depends on `procgen` + `core`; in asciirogue it takes `&hecs::World` as a parameter, which is pragmatic. If you want a hard dep boundary, split the renderer into "tile pass + entity pass" functions and have `app` drive both.
- `app` ties everything together and owns the `App` struct (dungeon, world, viewshed cache, panic-safe raw mode entry/exit).

In `Cargo.toml`, every dep a crate uses must be declared in `[workspace.dependencies]` and re-referenced as `ratatui = { workspace = true }` — keeps version drift impossible.

---

## Critical pitfall: headless verification

PTY-based TUI testing inside Hermes / CI / sandboxed environments is unreliable. `pty.fork()` + raw mode goes through several layers where output buffering, signal handling, and TTY discipline are out of your control. Don't waste time on it as a **first-class test target**.

Instead every TUI game should grow a `--dump` (or `--headless` / `--smoke`) CLI mode that:

1. Sets up the same `World`, dungeon, and viewshed as the TUI mode.
2. Renders to **stdout**, one frame at a time.
3. Writes a **state header** so regressions are visible without parsing every frame:
   ```
   ── seed 0x00000000CAFEBABE  11 rooms  player@(3,6)  visible 45 ──
   ```
4. For each tile, output one character:
   - entity glyph (`@`, `g`, …) if on that tile and currently `visible`
   - `wall_glyph(dungeon, x, y)` if visible wall
   - `.` for visible floor
   - dimmed `.` for revealed-but-not-visible floor (hidden = space)
5. Renders FOV-bearing entities, not just the dungeon.

```bash
asciirogue --dump --count 3 --seed 0xCAFEBABE
```

This is what made week-2 verifiable inside a sandbox without ever needing a real TTY. The same idea works for **any** TUI app: if the render can be reduced to a one-character-per-cell byte stream with a state header, you can test it.

Variants worth considering: `--step` (advance one turn and dump, repeat) tests AI / movement sequences without a keypress loop; `--png <file>` (write the same frame as a PNG via Pillow or qlmanage) skips ASCII parsing entirely if you only need visual review.

---

## Render-fn argument shape: take viewshed as a snapshot

```rust
pub fn draw_world(
    frame: &mut Frame<'_>,
    area: ratatui::layout::Rect,
    map: &Dungeon,
    world: &hecs::World,
    viewshed: &Viewshed,   // borrowed, not stored on the world itself
) { /* ... */ }
```

Viewshed lives on the player entity but the renderer takes the **current snapshot** as an argument. This decouples rendering from world-borrow timing — hecs doesn't allow simultaneous borrow of the world (for entity iteration) and a `&mut Viewshed` of one of its entities. The workaround in asciirogue:

```rust
let viewshed_snapshot = if let Ok(v) = self.world.get::<&Viewshed>(self.player) {
    Viewshed {
        range: v.range,
        visible: v.visible.clone(),
        revealed: v.revealed.clone(),
    }
} else { Viewshed::new(VIEW_RADIUS, MAP_W, MAP_H) };
draw_world(frame, centered, &self.dungeon, &self.world, &viewshed_snapshot);
```

Cost: a `Vec<bool>` and a `Vec<TilePos>` clone per frame. At TUI scale (≤120×60) this is free. At larger sizes, swap the snapshot for an `Arc<Viewshed>` or a channel — but measure first.

---

## Half-block rendering

The half-block palette (`▀`/`▄`/`█`/`▓`/`▒`) gives 2× vertical pixel density on a regular terminal, with full 24-bit RGB. The trick is the `wall_glyph()` 4-bit N/S/E/W bitmask function — see `references/half-block-and-fov.md` for the canonical algorithm and `thebracket/rustrogueliketutorial` chapter 16 for the reference implementation.

Going beyond 2× density: Braille (`U+2800`-range) gives 4× — but it's class-dependent. Half-block is the convention for ASCII-style roguelikes; Braille is for data visualisation. Don't mix mid-game.

---

## When to load this skill
When to load this skill:
- First commit of a new Rust TUI game
- Adding FOV / movement / ECS to an existing TUI prototype
- Planning to integrate `doryen-fov` (or any FOV library)
- Choosing between ratatui / `bevy_tui` / `crossterm`+`tui-rs` — short answer: ratatui.
- Needing to verify the game output without a real TTY (CI / sandbox)
- Considering `--dump` / `--headless` / `--smoke` mode
- User reports "X doesn't work" repeatedly for a feature that looks correct in
  code — see `references/headless-verification.md` §"Scenario-based headless
  probe" + `references/hecs-ratui-gotchas.md` §"draw_world 6th-parameter pattern"
  for the diagnostic + UX fix shape.

## What this skill does NOT cover

- Pure graphical games (ggez, macroquad, bevy-render) — wrong stack.
- Networked multiplayer. TUI games in this style are single-process; if you need it, layer `tungstenite` separately.
- Audio.
- Web TUI (Deno/Node + ratatui-wasm) — different deployment, similar API; the references may still apply but be skeptical.

---

## File map

```
rust-tui-game/
├── SKILL.md                 # this file
├── references/
│   ├── headless-verification.md   # the --dump pattern, ASCII frame format
│   ├── half-block-and-fov.md       # wall_glyph bitmask + doryen-fov API quirks
│   └── hecs-ratui-gotchas.md       # borrow scoping, lifetimes, deprecated APIs
├── templates/
│   ├── cargo-workspace.toml       # 5-crate workspace starter
│   └── app-main-stub.rs            # minimal main.rs with --dump + TUI loop
└── scripts/
    └── dump-verify.sh             # cargo build --release && --dump test runner
```
