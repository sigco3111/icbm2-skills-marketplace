// Minimal main.rs for a Rust TUI game with the --dump / --help pattern.
// Drop into crates/app/src/main.rs of the 5-crate workspace.

use anyhow::{Context, Result};
use asciirogue_core::{Direction, Position, Renderable, TilePos};
use asciirogue_procgen::{bsp, Dungeon, Tile};
use asciirogue_render::{draw_world, wall_glyph};
use crossterm::event::{Event, KeyCode, KeyEventKind};
use crossterm::terminal::disable_raw_mode;
use crossterm::execute;
use crossterm::terminal::LeaveAlternateScreen;
use hecs::World;
use ratatui::layout::{Constraint, Layout};
use ratatui::text::Span;
use ratatui::widgets::{Block, Borders, Paragraph};
use std::env;
use std::io;

const MAP_W: i32 = 60;
const MAP_H: i32 = 24;
const VIEW_RADIUS: i32 = 8;

struct App {
    dungeon: Dungeon,
    seed: u64,
    running: bool,
    blocks: Vec<bool>,
    world: World,
    player: hecs::Entity,
}

impl App {
    fn new(seed: u64) -> Self {
        let dungeon = bsp::generate(MAP_W, MAP_H, seed, bsp::Config::default());
        let blocks = build_blocks(&dungeon);
        let mut world = World::new();
        let (px, py) = dungeon.rooms.first().map(|r| r.center()).unwrap_or((MAP_W / 2, MAP_H / 2));
        let player = world.spawn((
            Position(TilePos(px, py)),
            Renderable::new('@', 0xFF_D6_5A),
            asciirogue_core::Viewshed::new(VIEW_RADIUS, MAP_W, MAP_H),
        ));
        Self { dungeon, seed, running: true, blocks, world, player }
    }

    fn handle(&mut self, ev: &Event) {
        if let Event::Key(k) = ev {
            if k.kind == KeyEventKind::Press {
                let dir = key_to_direction(&k.code);
                match k.code {
                    KeyCode::Char('q') | KeyCode::Char('Q') | KeyCode::Esc => self.running = false,
                    KeyCode::Char('r') | KeyCode::Char('R') => *self = App::new(self.seed.wrapping_add(1)),
                    _ => {}
                }
                if let Some(d) = dir { self.try_move(d); }
            }
        }
    }

    fn try_move(&mut self, dir: Direction) {
        let (dx, dy) = dir.delta();
        if dx == 0 && dy == 0 { return; }
        let cur = if let Ok(p) = self.world.get::<&Position>(self.player) { p.0 } else { return; };
        let next = TilePos(cur.0 + dx, cur.1 + dy);
        if !matches!(self.dungeon.at(next.0, next.1), Tile::Floor) { return; }
        if let Ok(mut p) = self.world.get::<&mut Position>(self.player) {
            p.0 = next;
        }
        // todo: recompute_fov() — see references/half-block-and-fov.md
    }

    fn draw(&self, frame: &mut ratatui::Frame) {
        let area = frame.area();
        let chunks = Layout::vertical([Constraint::Length(3), Constraint::Min(0), Constraint::Length(1)]).split(area);
        let title = Paragraph::new(Span::from(format!("seed {}  keys hjklyubn q=quit r=new-seed", self.seed)))
            .block(Block::default().borders(Borders::ALL));
        frame.render_widget(title, chunks[0]);
        // todo: render dungeon + viewshed + entities — see references/
        let map_chunk = chunks[1];
        let viewshed_snap = if let Ok(v) = self.world.get::<&asciirogue_core::Viewshed>(self.player) {
            asciirogue_core::Viewshed {
                range: v.range,
                visible: v.visible.clone(),
                revealed: v.revealed.clone(),
            }
        } else {
            asciirogue_core::Viewshed::new(VIEW_RADIUS, MAP_W, MAP_H)
        };
        draw_world(frame, map_chunk, &self.dungeon, &self.world, &viewshed_snap);
        let status = Paragraph::new(Span::from(format!("rooms {}  w/h {}x{}", self.dungeon.rooms.len(), MAP_W, MAP_H)));
        frame.render_widget(status, chunks[2]);
    }
}

fn key_to_direction(k: &KeyCode) -> Option<Direction> {
    match k {
        KeyCode::Char('h') => Some(Direction::Left),
        KeyCode::Char('j') => Some(Direction::Down),
        KeyCode::Char('k') => Some(Direction::Up),
        KeyCode::Char('l') => Some(Direction::Right),
        KeyCode::Char('y') => Some(Direction::UpLeft),
        KeyCode::Char('u') => Some(Direction::UpRight),
        KeyCode::Char('b') => Some(Direction::DownLeft),
        KeyCode::Char('n') => Some(Direction::DownRight),
        KeyCode::Char('.') => Some(Direction::None),
        _ => None,
    }
}

fn build_blocks(d: &Dungeon) -> Vec<bool> {
    let w = d.width as usize;
    let h = d.height as usize;
    (0..w * h).map(|i| !matches!(d.tiles[i], Tile::Floor)).collect()
}

fn run() -> Result<()> {
    let mut terminal = ratatui::init();
    let result = (|| -> Result<()> {
        let mut app = App::new(0xCAFE_BABE_DEAD_BEEF);
        while app.running {
            terminal.draw(|f| app.draw(f))?;
            if crossterm::event::poll(std::time::Duration::from_millis(50))? {
                let ev = crossterm::event::read()?;
                app.handle(&ev);
            } else {
                std::thread::sleep(std::time::Duration::from_millis(50));
            }
        }
        Ok(())
    })();
    ratatui::restore();
    result
}

fn dump_to_stdout(seed: u64, count: u32) -> Result<()> {
    for i in 0..count {
        let s = seed.wrapping_add(i as u64);
        let dungeon = bsp::generate(MAP_W, MAP_H, s, bsp::Config::default());
        let mut world = World::new();
        let (px, py) = dungeon.rooms.first().map(|r| r.center()).unwrap_or((MAP_W / 2, MAP_H / 2));
        let player_pos = TilePos(px, py);
        let player = world.spawn((
            Position(player_pos),
            Renderable::new('@', 0xFFD65A),
            asciirogue_core::Viewshed::new(VIEW_RADIUS, MAP_W, MAP_H),
        ));
        let blocks = build_blocks(&dungeon);
        // todo: vision::compute(player_pos, MAP_W, MAP_H, VIEW_RADIUS, &blocks, &mut out)
        let _ = player;
        println!("── seed 0x{:016X}  {} rooms  player@({},{}) ──", s, dungeon.rooms.len(), player_pos.0, player_pos.1);
        for y in 0..MAP_H {
            let mut line = String::with_capacity(MAP_W as usize);
            for x in 0..MAP_W {
                line.push(match dungeon.at(x, y) {
                    Tile::Wall  => wall_glyph(&dungeon, x, y),
                    Tile::Floor => '.',
                    Tile::Rock  => ' ',
                });
            }
            println!("{}", line);
        }
        println!();
    }
    Ok(())
}

fn main() -> Result<()> {
    let args: Vec<String> = env::args().collect();
    let dump_mode = args.iter().any(|a| a == "--dump");
    if dump_mode {
        let count: u32 = args.windows(2).find(|w| w[0] == "--count").and_then(|w| w[1].parse().ok()).unwrap_or(3);
        let seed: u64 = args.windows(2).find(|w| w[0] == "--seed").and_then(|w| w[1].parse().ok()).unwrap_or(0xCAFE_BABE_DEAD_BEEF);
        return dump_to_stdout(seed, count);
    }
    if args.iter().any(|a| a == "--help" || a == "-h") {
        eprintln!("Run with no args for TUI mode, --dump for headless ASCII frames.");
        return Ok(());
    }

    // panic hook — restore the terminal first. Install BEFORE any TUI enter.
    let original = std::panic::take_hook();
    std::panic::set_hook(Box::new(move |info| {
        let _ = disable_raw_mode();
        let _ = execute!(io::stderr(), LeaveAlternateScreen);
        original(info);
    }));
    run().context("runtime error")
}
