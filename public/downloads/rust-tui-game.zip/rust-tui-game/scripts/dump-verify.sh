#!/usr/bin/env bash
# Headless verification for a TUI game built with the rust-tui-game skill.
# Run after any change to render / procgen / FOV to make sure ASCII frames
# are still well-formed and the state header is sensible.
#
# Usage:  ./scripts/dump-verify.sh <seed> [count]
#
# Exit codes:
#   0  - all frames show at least one visible tile and at least one room
#   1  - dump command failed (build broken)
#   2  - dump produced no visible tile (FOV bug)
#   3  - dump produced no rooms (procgen bug)
set -euo pipefail

PROJECT="${PROJECT_ROOT:-$(git rev-parse --show-toplevel 2>/dev/null || pwd)}"
cd "$PROJECT"

SEED="${1:-0xCAFEBABE}"
COUNT="${2:-3}"

BIN="$PROJECT/target/release/$(grep -m1 '^name ' Cargo.toml | cut -d'"' -f2)"
if [[ -z "$BIN" ]]; then
  BIN=$(basename "$PROJECT")
fi

# 1. build
if ! cargo build --release --quiet 2>&1 | tee /tmp/build.log; then
  echo "✗ build failed" >&2
  cat /tmp/build.log
  exit 1
fi

# 2. dump
OUTPUT="$(./target/release/"$BIN" --dump --count "$COUNT" --seed "$SEED")"

# 3. check shape
if [[ -z "$OUTPUT" ]]; then
  echo "✗ dump produced no output" >&2
  exit 1
fi

# grep for state header — at least one
HEADER_COUNT=$(echo "$OUTPUT" | grep -c '^── seed' || true)
if [[ "$HEADER_COUNT" -lt "$COUNT" ]]; then
  echo "✗ expected $COUNT frames, got $HEADER_COUNT" >&2
  exit 1
fi

# check for signs of life
ROOM_LINE=$(echo "$OUTPUT" | grep -m1 'rooms' || true)
if [[ -z "$ROOM_LINE" ]]; then
  echo "✗ no rooms in output (procgen broken)" >&2
  exit 3
fi

PLAYER_LINE=$(echo "$OUTPUT" | grep -m1 'player@' || true)
if [[ -z "$PLAYER_LINE" ]]; then
  echo "✗ no player spawn in output" >&2
  exit 1
fi

# check the visible count is non-zero
if echo "$OUTPUT" | grep -q 'visible 0'; then
  echo "✗ FOV returned 0 visible tiles — check doryen-fov API call" >&2
  exit 2
fi

# final: print a digest
echo "✓ OK   $COUNT frame(s)  $(echo "$OUTPUT" | wc -l) lines"
echo "$OUTPUT" | head -8
echo "  ..."

# 4. optional diff vs baseline
if [[ -n "${BASELINE:-}" && -f "$BASELINE" ]]; then
  if diff -q <(echo "$OUTPUT") "$BASELINE" > /dev/null; then
    echo "✓ matches baseline $BASELINE"
  else
    echo "✗ differs from baseline $BASELINE"
    diff <(echo "$OUTPUT") "$BASELINE" | head -20
    exit 4
  fi
fi
