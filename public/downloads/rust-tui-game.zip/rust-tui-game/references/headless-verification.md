# Headless verification of TUI games (`--dump` pattern)

## Why this matters

The single most reliable way to verify a TUI game's render is to **stop trying to drive a real TTY** in your sandbox / CI / non-interactive shell. Instead, add a `--dump` CLI mode that prints one ASCII frame per turn to stdout, with a machine-readable state header. This pattern unlocked verifiable TUI progress on `asciirogue` week-2 inside a Hermes sandbox where `pty.fork()` + raw-mode `ratatui::restore()` never reached a clean exit.

## Required shape

```
./asciirogue --dump --count 3 --seed 0xCAFEBABE
```

output:

```
── seed 0x00000000CAFEBABE  11 rooms  player@(3,6)  visible 45 ──
                                                            
                                                            
                                                     ··     
  ████                             ···   ··············     
  ▀........···························   ·           ··     
  ▀......········g···         ·    ···   ·           ··     
  ▀@.▀·        ······         ·    ·········         ·      
  ...
```

Three properties that make it useful:

1. **Same code paths as the TUI mode.** Same `World`, same dungeon, same `vision::compute(...)`, same FOV. The dump is not a mock — it is the actual render reduced to a byte stream.
2. **A state header on every frame.** Run `git diff` on dump output across commits; regressions in dungeon shape, room count, player spawn, or visible tile count are immediately visible without parsing each frame.
3. **One character per cell.** Always. Even for entities that would normally take a 2x2 block in the TUI render — emit one `g`/`@` glyph per cell. ASCII-frame dump is for verification, not for prettiness.

## State header format (recommended)

```
── seed 0x00000000CAFEBABE  <N rooms>  player@(<x>,<y>)  visible <V> ──
```

Picking a fixed-width `<seed 0x016HEX>` keeps column-aligned output across seeds — easy to grep / diff. Don't include ticks yet; play may not advance tick-by-tick in `--dump` mode.

## Per-cell rendering recipe (FOV-aware)

```rust
fn render_cell(x: i32, y: i32,
               dungeon: &Dungeon,
               visible: &HashSet<(i32, i32)>,
               revealed: &[bool],
               entities: &HashMap<(i32, i32), char>) -> char {
    if let Some(&glyph) = entities.get(&(x, y)) {
        return glyph;
    }
    let here = dungeon.at(x, y);
    if visible.contains(&(x, y)) {
        return match here {
            Tile::Wall => wall_glyph(dungeon, x, y),
            Tile::Floor => '.',
            Tile::Rock => ' ',
        };
    }
    if matches!(here, Tile::Wall | Tile::Rock) {
        return ' ';
    }
    // floor not visible — dim
    '·'
}
```

This is exactly what `asciirogue`'s `dump_to_stdout` does. Encodes:

- visible > revealed > hidden — strictest visibility check first
- entities always beat tiles — `@` on a floor tile shows `@`
- hidden walls render as space (not `█`) so the **shape** of unknown rooms isn't leaked

## Why we still want this even with proper CI/TUI

Even when a sandbox reliably drives a real TTY (e.g. GH Actions with `xvfb-run`), `--dump` is faster, easier to grep, and diff-friendly. The only thing you give up is colour gradient verification — for that, see `--png` below.

## Variants worth implementing

| Flag | Behaviour | When it helps |
|---|---|---|
| `--dump --count N` | Print N frames (each with a different seed by `seed.wrapping_add(i)`) | Snapshot many dungeons |
| `--dump --steps N` | Advance N turns then print one frame | AI / energy-queue testing |
| `--dump --png <file>` | Write the ASCII frame as an image (use `qlmanage` on macOS, or Pillow) | Visual diff via image tools |
| `--dump --json` | Emit `{ state: {...}, cells: [[...]] }` | Programmatic inspection / assertions |

`--png` is especially good for visual regression: use `ImageMagick compare` or `git diff --no-index` on saved PNGs to catch palette / contrast regressions between commits.

## Common pitfall: panic hook still required in --dump mode

Even in `--dump` mode (no TTY ever opened), if the panic hook is installed only inside the TUI branch, a panic in procgen will leave the agent without context. Install it **before** the `--dump` vs TUI branch:

```rust
let original = std::panic::take_hook();
std::panic::set_hook(Box::new(move |info| {
    let _ = disable_raw_mode();
    let _ = execute!(io::stderr(), LeaveAlternateScreen);
    original(info);
}));
run_or_dump()?;
```

Disable it after, or accept the cost (a 3-line hook with negligible overhead).

## Scenario-based headless probe (`pickup_probe` pattern)

The `--dump` pattern verifies **renders**. The scenario-based probe verifies
**gameplay logic** for a specific user-reported bug without a TTY. Use this
when a function under suspicion keeps producing the "wrong" output for a
user's exact inputs and you need to know whether the function is wrong or
the inputs are wrong.

Recipe (works for any TUI game with an `App` struct + `World`):

1. **Expose probe-friendly getters** on the main struct. These are not
   user-facing; they exist so an `examples/<name>_probe.rs` can drive
   the engine:

   ```rust
   // crates/app/src/lib.rs
   impl App {
       pub fn world_ref(&self) -> &hecs::World { &self.world }
       pub fn world_mut(&mut self) -> &mut hecs::World { &mut self.world }
       pub fn messages(&self) -> &[String] { &self.messages }
       pub fn dungeon_ref(&self) -> &asciirogue_procgen::Dungeon { &self.dungeon }
       pub fn floor(&self) -> u32 { self.floor }
       pub fn step(&mut self, dir: Direction) -> bool { /* one turn */ }
   }
   ```

2. **Write `examples/<scenario>_probe.rs`** that:
   - Constructs the app with the user's exact seed
   - Teleports the player to the user's exact coordinate via `world_mut`
   - Spawns / despawns entities to mirror the on-screen state
   - Calls the suspected function (or sends a synthetic `crossterm::event::Event`)
   - **Prints every observable state** (player pos, inventory contents,
     ground items, message log) — not just "did it work"

3. **Three scenarios minimum**:
   - **A**: the exact bug repro. Should reveal whether the function is
     returning the right value for the user's exact case.
   - **B**: a degenerate case (empty input, all items removed, etc.)
     that should produce a known answer.
   - **C**: a fresh seed. Reveals whether the issue is reproducible
     across the whole dungeon or only in the user's specific layout.

4. **Run the probe and read the output**. If A produces a truthy
   `inventory delta = 0` and a non-empty ground-items list — that's the
   "function is correct, bug is UX" signal. If A panics or produces
   the wrong inventory change — that's a real code bug.

5. **Don't trust the probe if it doesn't exercise the same code paths**.
   If `App::handle(&ev)` for a synthetic key event doesn't fire the same
   branch as a real TTY keypress, the probe is a mock, not a verification.

This pattern caught the v0.5.4/v0.5.5 pickup confusion in ~5 minutes:
the user's reported symptom was "g doesn't work", but the probe showed
the function returning `PickupOutcome::NoItem` correctly because the
gold simply wasn't on the player's tile. The fix lived in the UI
layer (header distance hint + bold adjacent items), not the function.

Header probe (separately useful when `draw_world` is hard to drive): render
the **header string** `App::draw` builds as a plain Rust string, so you
can `assert_eq!(header, "...seed 1F 동굴 pickup: ↑ $ 2...")` without
ever touching a `Frame`. Same `App` state, no TUI overhead.
