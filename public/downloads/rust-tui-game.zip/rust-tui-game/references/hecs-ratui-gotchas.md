# hecs 0.10 + ratatui 0.29 + doryen-fov 0.1.1: gotchas

Distilled from one week of `asciirogue` development. These are not the entire API — they're the entries where the official docs / signature alone hides the trap.

---

## hecs 0.10

### `world.get::<&T>(entity)`, NOT `world.get::<T>(entity)`

This is the single most common compile error:

```
error[E0277]: the trait bound `Position: ComponentRef<'_>` is not satisfied
```

hecs `World::get` takes a `T: ComponentRef<'a>`. The valid `T`s are `&Q` and `&mut Q` for any component type `Q`. So:

```rust
// right
let pos = if let Ok(p) = self.world.get::<&Position>(self.player) { p.0 } else { /* fallback */ };
let mut_pos = if let Ok(mut p) = self.world.get::<&mut Position>(self.player) { p.0 = next; };
```

`world.get::<Position>(...)` will not compile even though it looks textbook. Don't try to find a way to make the bare type form work — just use `&T` / `&mut T`.

### Can't hold a borrow while iterating the world

Hecs doesn't allow you to do `world.get::<&mut Viewshed>(player)` and then `world.query::<(&Position, &Renderable)>().iter()` in the same scope — borrow checker rightly complains.

Two fixes, in order of frequency:

1. **Snapshot and drop the borrow.** `let snap = Viewshed { visible: v.visible.clone(), ..v.clone() };` then call a render fn that takes `&Viewshed`.
2. **Use an `Arc<Viewshed>`** and clone the `Arc` instead of the data — needed only at scale.

The cost of #1 at TUI scale (≤120×60) is free; do not pre-optimise.

### Variant: mutation + read of the same Vec inside the same logical frame

```rust
if let Ok(mut v) = self.world.get::<&mut Viewshed>(self.player) {
    v.visible = visible_buf;
    for &TilePos(x, y) in &v.visible {  // ← borrows v.visible
        v.revealed[(y * w + x) as usize] = true;  // ← also mutates v
    }
}
```

Rust complains because `&v.visible` (immutable) and `&mut v` overlap. Workaround: clone before mutating.

```rust
let visible_for_reveal: Vec<TilePos> = visible_buf.clone();
if let Ok(mut v) = self.world.get::<&mut Viewshed>(self.player) {
    v.visible = visible_buf;  // moves
    for &TilePos(x, y) in &visible_for_reveal {  // separate, fine
        v.revealed[(y * w + x) as usize] = true;
    }
}
```

### Component struct must be uniquely owned

`Renderable { glyph, fg_rgb }` is fine. `Renderable { glyph: &'static str }` would force you to leak strings — avoid.

For datatypes that need interior mutation (a turn counter, a hot path of bookkeeping), either:

- Keep the component purely-data and track state in a separate system (preferred at small scale)
- Use `Cell<i32>` / `RefCell<i32>` inside the component (small, ugly, but correct)

---

## ratatui 0.29

### `Frame<'_>` needs an explicit lifetime if you `#![deny(rust_2018_idioms)]`

```rust
// compile error: "hidden lifetime parameters in types are deprecated"
pub fn draw_map(frame: &mut Frame, area: Rect, map: &Dungeon) { /* ... */ }

// fix
pub fn draw_map(frame: &mut Frame<'_>, area: Rect, map: &Dungeon) { /* ... */ }
```

This applies to any `Frame` parameter when the crate has `#![deny(rust_2018_idioms)]`. The lifetime is `Frame<'_>`, an anonymous lifetime — short-form `'_` is the right idiom.

### `Buffer::get_mut(x, y)` is deprecated

```rust
// old (warning)
buf.get_mut(x, y).set_char(symbol).set_fg(color);

// current (use indexing)
buf[(x, y)].set_char(symbol).set_fg(color);
```

Indexing does the same thing and is in the trait surface for `IndexMut`. No reason to use the deprecated method.

### `Color::Rgb(u8, u8, u8)` ↔ 24-bit hex packing

Common pattern: store colours as `u32` on components (compact) and convert at render time:

```rust
let r = ((render.fg_rgb >> 16) & 0xFF) as u8;
let g = ((render.fg_rgb >>  8) & 0xFF) as u8;
let b = ( render.fg_rgb        & 0xFF) as u8;
let color = Color::Rgb(r, g, b);
```

### `Cell` has `set_style`, NOT `add_modifier` (ratatui 0.29)

The chainable modifier setter was removed. To add `BOLD` (or any other
`Modifier`) to a `Cell`:

```rust
// right
buf[(x, y)].set_char(glyph).set_fg(color);
buf[(x, y)].set_style(
    ratatui::style::Style::default()
        .add_modifier(ratatui::style::Modifier::BOLD),
);

// wrong — does not compile (E0599)
let mut cell = buf[(x, y)].set_char(glyph);
cell.add_modifier(Modifier::BOLD);
```

Use this for "highlight tiles within reach" UX — items on the player's
tile and its 4 cardinal neighbours get `BOLD` via a
`near_pickup_tiles: &HashSet<(i32, i32)>` argument to `draw_world`. See
"draw_world 6th-parameter pattern" below.

### `Viewshed::visible` is `Vec<TilePos>`, NOT `Vec<bool>`

The asymmetry is easy to miss because `revealed` IS `Vec<bool>`:

```rust
// right
for y in 0..h {
    for x in 0..w {
        vs.visible.push(TilePos(x, y));           // push TilePos
        vs.revealed[(y * w + x) as usize] = true; // cast: usize index required
    }
}

// wrong — expected `TilePos`, found `bool`
for cell in vs.visible.iter_mut() {
    *cell = true;
}
```

Test fixtures that build a `Viewshed` manually (e.g. for the
`draw_world_bolds_adjacent_pickups` render test) must mirror both field
types. The compiler will catch the type mismatch on `visible` but the
`usize` cast on `revealed[y * w + x]` is silent and will panic on small
types — always cast.

### `draw_world` 6th-parameter pattern: "highlight things in reach"

When the UI has a "you can interact with X right now" concept
(pickupable items, descend stairs, attackable enemies, unexplored
rooms), the canonical pattern is:

1. **Probe-friendly API on `App`** that returns either a small
   `Option<(distance, direction, glyph)>` for header hints, or a
   `HashSet<(i32, i32)>` of "in-reach tiles" for visual emphasis:

   ```rust
   pub fn nearest_pickup_info(&self) -> Option<(usize, Direction, char)> {
       nearest_pickup_info(&self.dungeon, &self.world, self.player)
   }
   ```

2. **Extend `draw_world` to take that set as a new argument**; apply
   `BOLD` (or any visual emphasis) when iterating entities in the
   existing pass-2 (entity) loop:

   ```rust
   pub fn draw_world(
       frame: &mut Frame<'_>,
       area: ratatui::layout::Rect,
       map: &Dungeon,
       world: &hecs::World,
       viewshed: &Viewshed,
       near_pickup_tiles: &std::collections::HashSet<(i32, i32)>,
   ) {
       // pass 1 (tiles): unchanged
       // pass 2 (entities): after set_char + set_fg:
       if near_pickup_tiles.contains(&(x, y)) {
           buf[(area.x + x as u16, area.y + y as u16)].set_style(
               ratatui::style::Style::default().add_modifier(
                   ratatui::style::Modifier::BOLD,
               ),
           );
       }
   }
   ```

3. **Header distance hint** so the user knows the answer **before**
   walking: `pickup: ↑ $ 2` means "gold, 2 tiles up". Same BFS,
   different consumer (header string builder).

4. **Cap any BFS at a small constant** (24 tiles is plenty for TUI
   scale) so a missing target doesn't walk the whole dungeon each
   frame. BFS must be 4-neighbourhood if you want a cardinal-direction
   hint that matches the first step the player would take.

The same shape generalises to next-floor stairs, lowest-HP enemy,
unexplored rooms — anything the user would benefit from knowing where
it is. Re-using `draw_world`'s existing 2-pass structure (tiles, then
entities) means emphasis lands on top of the entity glyph without
overwriting wall/floor tiles.

### Testing `draw_world` without a TTY: `ratatui::backend::TestBackend`

You can't call `draw_world` directly — it needs a `Frame<'_>`:

```rust
use ratatui::backend::TestBackend;
use ratatui::Terminal;

let backend = TestBackend::new(5, 5);
let mut terminal = Terminal::new(backend).unwrap();
terminal.draw(|frame| {
    draw_world(frame, area, &dungeon, &world, &vs, &near);
}).unwrap();
let buf = terminal.backend().buffer().clone();

// Now assert on individual cells:
assert!(buf[(2, 1)].style().add_modifier.contains(Modifier::BOLD));
```

This pattern is the right tool for any "renderer takes a Frame" test
in a headless / CI environment. Combine with the Viewshed-building
recipe above for full visual coverage.

### Panic safety: hook + `ratatui::restore()` are part of correctness

```rust
let original = std::panic::take_hook();
std::panic::set_hook(Box::new(move |info| {
    let _ = disable_raw_mode();
    let _ = execute!(io::stderr(), LeaveAlternateScreen);
    original(info);
}));
```

Without this, a panic inside the render loop leaves the terminal in raw mode — your shell prompt stops echoing. Add this **before** any TUI enter/leave calls, and test it (Ctrl-C inside `cargo run`).

### Always restore in `--dump` mode too

It's tempting to install the panic hook only inside the TUI branch. Don't — procgen panics then leave the agent with no context. Install once at the top of `main()`, and pay the 3-line overhead for both modes.

---

## doryen-fov 0.1.1

This is the trap-rich surface. Read carefully.

### `MapData::new(width, height)` — no transparency vector argument

```rust
// right
let mut map = MapData::new(width as usize, height as usize);
// then set per-cell
for y in 0..h {
    for x in 0..w {
        map.set_transparent(x, y, !blocks[x + y * w]);
    }
}
```

It does **not** take a `Vec<bool>` like the older API on some forks. It's an empty-all-transparent map you populate yourself.

### `transparent = true` means SEE THROUGH (inverse intuition)

`map.set_transparent(x, y, true)` — light passes through.
`map.set_transparent(x, y, false)` — light is blocked.

So translating from your dungeon's `blocks: Vec<bool>` (where `true = wall`) requires a `!blocks[...]` flip:

```rust
map.set_transparent(x, y, !blocks[x + y * width]);
```

This is the single biggest source of "FOV shows through walls" bugs.

### `compute_fov` takes 5 args, last one is `light_walls: bool`

```rust
fov.compute_fov(
    &mut map,
    origin_x as usize,
    origin_y as usize,
    radius as usize,
    true, // light_walls — walls on the edge of FOV are visible (no pitch-black rooms)
);
```

`light_walls = false` makes a wall only visible if the cell on the **player's side** of the wall is in FOV — gives a "pitch-black interior" effect for closed rooms. Roguelikes usually want `true`. Some games (Cogmind's blanket-dark rooms) want `false`.

### `is_in_fov` is on the **map**, not the algorithm

```rust
// right — read the result off `map`
for y in 0..h {
    for x in 0..w {
        if map.is_in_fov(x, y) { /* ... */ }
    }
}
```

Searching for `fov.is_in_fov(...)` on the `FovRecursiveShadowCasting` instance will fail to compile.

### There is no `FovRestriction` enum

The doryen-fov 0.1.1 API does **not** take an `FovRestriction` argument. Earlier versions did. Older code samples on the web that show `FovRestriction::EightWay` refer to a different fork. Your `compute_fov` call must omit it; the 4th (radius) parameter is the last positional one before the `light_walls` bool.

### `radius = 0` means **unlimited**, not "no vision"

Set `radius: 0` to "infinite sight"; the algorithm walks until it hits map edges. For player character FOV with a limited sight radius (default 8–10 tiles), set `radius = 8` explicitly.
