# Half-block rendering + doryen-fov API reference

Half-block (Unicode `▀`/`▄`/`█`/`▓`/`▒`) gives 2× vertical pixel density on a regular terminal. This file collects the two recipes that drive asciirogue's look: the `wall_glyph()` 4-bit bitmask and the FOV wrap.

For FOV version-specific quirks (API surface traps) see `hecs-ratui-gotchas.md`. This file is the *how*; that one is the *watch out*.

---

## The `wall_glyph()` 4-bit bitmask

For each wall tile, look at the 4 cardinal neighbours (N/S/E/W). Pack their "is this also a wall" booleans into a 4-bit mask:

```text
bit 0 (1)   N  — wall above
bit 1 (2)   S  — wall below
bit 2 (4)   W  — wall left
bit 3 (8)   E  — wall right
```

Then map the mask to one of the 16 possible half-block characters. Since there are 16 possible masks and we want every one to draw something readable, the cleanest is:

```rust
let n = is_wall( 0, -1) as u8; // 1
let s = is_wall( 0,  1) as u8; // 2
let w = is_wall(-1,  0) as u8 * 4; // 4
let e = is_wall( 1,  0) as u8 * 8; // 8
let mask = n | s | w | e;
```

A reasonable mapping (used by asciirogue and traceable back to `thebracket/rustrogueliketutorial` chapter 16):

```rust
match mask {
    0b0000 => ' ',  // no adjacent walls — degenerate; should not happen
    0b0001 => '▀',  // N only
    0b0010 => '▄',  // S only
    0b0100 => '█',  // W only
    0b1000 => '█',  // E only
    0b0011 => '█',  // N+S
    0b1100 => '█',  // W+E
    0b0110 => '█',  // S+W (corner)
    0b1001 => '█',  // N+E
    0b1010 => '█',  // S+E
    0b0101 => '█',  # N+W
    _      => '█',  // 3- or 4-way: solid wall body
}
```

This is the simplest sane mapping. For fancy code, see `bracket-lib`'s implementation — it distinguishes more corners and gives a smoother look at the cost of more cases.

---

## The render-pipeline shape that comes out of it

```rust
// pass 1: tile base layer (full dungeon)
for y in 0..h {
    for x in 0..w {
        let tile = dungeon.at(x, y);
        let cell = match tile {
            Tile::Wall  => (wall_glyph(dungeon, x, y), Color::Rgb(180, 180, 200)),
            Tile::Floor => ('·',                          Color::Rgb(110, 110, 130)),
            Tile::Rock  => (' ',                          Color::Reset),
        };
        buf[area + (x, y)] = cell;
    }
}

// pass 2: entities
for (_, (pos, renderable)) in world.query::<(&Position, &Renderable)>().iter() {
    let TilePos(x, y) = pos.0;
    let (r, g, b) = unpack_rgb(renderable.fg_rgb);
    buf[area + (x, y)] = (renderable.glyph, Color::Rgb(r, g, b));
}
```

This is the two-pass core of `asciirogue_render::draw_world`. Pass 2 overwrites pass 1 wherever an entity sits; entities that are off-screen are filtered in the same loop. For FOV-aware rendering, add the visibility gate at the start of pass 1 and at the start of pass 2:

```rust
// FOV-aware variant
let visible: HashSet<(i32, i32)> = viewshed.visible.iter()
    .map(|&TilePos(x, y)| (x, y))
    .collect();
let revealed_at = |x, y| ...;

let cell = if visible.contains(&(x, y)) {
    bright_for(tile)
} else if revealed_at(x, y) {
    dim_for(tile)
} else {
    (' ', Color::Reset)
};
```

Dim `Color::Rgb(60, 60, 70)` (about 1/3 brightness of bright) is a good default for "explored but not currently seen."

---

## Palette cheatsheet (asciirogue values — feel free to keep or replace)

| Tile | Visible | Revealed-only |
|---|---|---|
| Wall | `▀`/`▄`/`█` per `wall_glyph`, RGB(180,180,200) | same glyph, RGB(60,60,70) |
| Floor | `·`, RGB(140,140,170) | `·`, RGB(40,40,50) |
| Rock | `#`, RGB(80,80,90) | (space, Reset) |
| Player | `◉◉`, RGB(255,214,90) | (not shown) |
| Goblin | `██`, RGB(180,90,210) | (not shown) |

The 2-character "▀▀" / "██" / "◉◉" entity glyphs are a stylistic choice from `nobiscuit` / `mythos-adventure`; they read as "filled 2x1 cell" inside the half-block grid, giving the player a slightly bolder presence than the enemies. If you'd rather one char per cell, drop the doubled glyph — visual cost is minor.

---

## FOV-driven 4-bit masking vs wall_glyph

Note that `wall_glyph()` is independent of FOV — it always renders the wall shape based on **structural** adjacency. The FOV layer decides **whether to draw anything at all** (visible / revealed / hidden), not how. So you have two layers:

1. **Structural** (`wall_glyph`): what shape to draw for a wall, given the local geometry.
2. **Visibility** (FOV): whether to draw at all, and at what brightness.

Keep them separate. Trying to fuse them (e.g. "if a wall is in fog, draw different shape") couples geometry and optics and you'll regret it within a week.

---

## Suggested 7-segment palette for entities

If you have 8–10 entity types, using one distinct foreground RGB each is plenty. Don't use more — the eye gets fuzzy beyond 8 colours on a CRT-quality TUI.

Pre-tested palette:

```
player @  RGB(255,214, 90)  # warm gold
goblin g  RGB(180, 90,210)  # magenta
rat    r  RGB(230,130,130)  # pink
troll  T  RGB(210, 90, 90)  # red
snake  s  RGB( 90,200,100)  # green
undead U  RGB(160,160,170)  # ash
dragon D  RGB(240, 80, 80)  # bright red (boss)
gold   $  RGB(255,210, 70)  # yellow
potion !  RGB( 90,220,160)  # mint
door   +  RGB(190,150, 90)  # amber
stairs >  RGB(240,240,240)  # white
```

Storing each on a `Renderable { glyph, fg_rgb }` component takes 8 bytes per entity (1 char + 3 bytes via `u32` packing). Negligible.
