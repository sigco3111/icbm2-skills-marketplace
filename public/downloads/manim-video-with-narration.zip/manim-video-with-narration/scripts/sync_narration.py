#!/usr/bin/env python3
"""
Manim Video + Qwen3-TTS Narration Sync Script

Usage:
    python sync_narration.py --video-dir <manim_output_dir> --audio-dir <kaggle_output_dir> --scenes Scene00 Scene01 ... --output final.mp4

Example:
    python sync_narration.py \
        --video-dir /tmp/project/media/videos/script/720p30 \
        --audio-dir /tmp/kaggle-tts-output \
        --scenes Scene00_Title Scene01_Problem Scene02_Solution \
        --output /tmp/project/final_with_narration.mp4
"""

import argparse
import json
import os
import subprocess
import sys
import tempfile


def get_duration(path: str) -> float:
    """Get audio/video duration in seconds."""
    result = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "default=noprint_wrappers=1:nokey=1", path],
        capture_output=True, text=True
    )
    return float(result.stdout.strip())


def sync_scene(video_path: str, audio_path: str, output_path: str, crf: int = 23) -> float:
    """Adjust video speed to match audio duration and mux together."""
    video_d = get_duration(video_path)
    audio_d = get_duration(audio_path)
    
    speed = video_d / audio_d
    print(f"  Video: {video_d:.1f}s, Audio: {audio_d:.1f}s, Speed: {speed:.2f}x")
    
    if abs(speed - 1.0) < 0.03:
        # Close enough, just mux
        subprocess.run([
            "ffmpeg", "-y",
            "-i", video_path, "-i", audio_path,
            "-c:v", "copy", "-c:a", "aac", "-b:a", "128k",
            "-shortest", "-movflags", "+faststart",
            output_path
        ], capture_output=True)
    else:
        # Adjust video speed
        subprocess.run([
            "ffmpeg", "-y",
            "-i", video_path, "-i", audio_path,
            "-filter_complex", f"[0:v]setpts={1/speed}*PTS[v]",
            "-map", "[v]", "-map", "1:a",
            "-c:v", "libx264", "-preset", "fast", "-crf", str(crf),
            "-c:a", "aac", "-b:a", "128k",
            "-shortest", "-movflags", "+faststart",
            output_path
        ], capture_output=True)
    
    return get_duration(output_path)


def main():
    parser = argparse.ArgumentParser(description="Sync Manim video with TTS narration")
    parser.add_argument("--video-dir", required=True, help="Manim output directory (e.g., media/videos/script/720p30)")
    parser.add_argument("--audio-dir", required=True, help="Kaggle TTS output directory")
    parser.add_argument("--scenes", nargs="+", required=True, help="Scene names (e.g., Scene00_Title)")
    parser.add_argument("--output", required=True, help="Output final video path")
    parser.add_argument("--crf", type=int, default=23, help="Video CRF quality (default: 23)")
    parser.add_argument("--no-sync", action="store_true", help="Skip speed adjustment, just mux")
    args = parser.parse_args()
    
    # Load durations
    durations_path = os.path.join(args.audio_dir, "durations.json")
    if os.path.exists(durations_path):
        with open(durations_path) as f:
            audio_durs = json.load(f)
    else:
        audio_durs = {}
    
    # Create temp dir for adjusted scenes
    with tempfile.TemporaryDirectory() as tmpdir:
        concat_lines = []
        total_dur = 0
        
        print("=" * 60)
        print("Syncing scenes...")
        print("=" * 60)
        
        for scene in args.scenes:
            video_path = os.path.join(args.video_dir, f"{scene}.mp4")
            audio_path = os.path.join(args.audio_dir, f"{scene}.mp3")
            
            if not os.path.exists(video_path):
                print(f"WARNING: Video not found: {video_path}, skipping")
                continue
            if not os.path.exists(audio_path):
                print(f"WARNING: Audio not found: {audio_path}, skipping")
                continue
            
            adjusted_path = os.path.join(tmpdir, f"{scene}.mp4")
            
            if args.no_sync:
                # Just mux without speed adjustment
                subprocess.run([
                    "ffmpeg", "-y",
                    "-i", video_path, "-i", audio_path,
                    "-c:v", "copy", "-c:a", "aac", "-b:a", "128k",
                    "-shortest", "-movflags", "+faststart",
                    adjusted_path
                ], capture_output=True)
                dur = get_duration(adjusted_path)
                print(f"  {scene}: muxed ({dur:.1f}s)")
            else:
                dur = sync_scene(video_path, audio_path, adjusted_path, args.crf)
                print(f"  {scene}: synced ({dur:.1f}s)")
            
            concat_lines.append(f"file '{adjusted_path}'")
            total_dur += dur
        
        # Write concat file
        concat_path = os.path.join(tmpdir, "concat.txt")
        with open(concat_path, "w") as f:
            f.write("\n".join(concat_lines))
        
        # Final stitch
        print(f"\nStitching {len(concat_lines)} scenes ({total_dur:.1f}s total)...")
        subprocess.run([
            "ffmpeg", "-y", "-f", "concat", "-safe", "0",
            "-i", concat_path, "-c", "copy", args.output
        ], capture_output=True)
        
        final_dur = get_duration(args.output)
        final_size = os.path.getsize(args.output) / (1024 * 1024)
        
        print(f"\n{'=' * 60}")
        print(f"FINAL: {args.output}")
        print(f"Duration: {final_dur:.1f}s | Size: {final_size:.1f}MB")
        print(f"{'=' * 60}")


if __name__ == "__main__":
    main()
