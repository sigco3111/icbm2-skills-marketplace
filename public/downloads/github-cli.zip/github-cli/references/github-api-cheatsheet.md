# GitHub REST API Cheatsheet

Base URL: `https://api.github.com`

All requests need: `-H "Authorization: token $GITHUB_TOKEN"`

Use the `gh-env.sh` helper to set `$GITHUB_TOKEN`, `$GH_OWNER`, `$GH_REPO` automatically:
```bash
source skills/github/github-auth/scripts/gh-env.sh
```

## Repositories

| Action | Method | Endpoint |
|--------|--------|----------|
| Get repo info | GET | `/repos/{owner}/{repo}` |
| Create repo (user) | POST | `/user/repos` |
| Create repo (org) | POST | `/orgs/{org}/repos` |
| Update repo | PATCH | `/repos/{owner}/{repo}` |
| Delete repo | DELETE | `/repos/{owner}/{repo}` |
| List your repos | GET | `/user/repos?per_page=30&sort=updated` |
| List org repos | GET | `/orgs/{org}/repos` |
| Fork repo | POST | `/repos/{owner}/{repo}/forks` |
| Create from template | POST | `/repos/{owner}/{template}/generate` |
| Get topics | GET | `/repos/{owner}/{repo}/topics` |
| Set topics | PUT | `/repos/{owner}/{repo}/topics` |

## Repository Contents (file/folder CRUD without local working tree)

**용도**: `/Users/mac/work/<repo>` 없거나 `git remote` 셋업 없이 단일 파일만 푸시/패치/삭제. Bot·script·CI가 자주 사용. PR 생성 없이 main에 직접 atomic commit.

| Action | Method | Endpoint |
|--------|--------|----------|
| Get file/folder as JSON | GET | `/repos/{owner}/{repo}/contents/{path}?ref={branch}` |
| Get file as raw (text) | GET | `/repos/{owner}/{repo}/contents/{path}` with `-H "Accept: application/vnd.github.raw"` |
| Create or update file | PUT | `/repos/{owner}/{repo}/contents/{path}` |
| Delete file | DELETE | `/repos/{owner}/{repo}/contents/{path}` |

### Create/update PUT body

```json
{
  "message": "docs: update README",
  "content": "<base64-encoded file bytes>",
  "sha": "<current blob sha, REQUIRED for update>",
  "branch": "main"
}
```

### Workflow (PUT one file with `gh api`)

```bash
# 1. Read current blob sha (for atomic update)
BLOB_SHA=$(gh api repos/$GH_OWNER/$GH_REPO/contents/README.md --jq '.sha')

# 2. Base64 encode file (macOS BSD base64: no wrap; GNU: use -w 0)
B64=$(base64 -w 0 -i /path/to/file | tr -d '\n')

# 3. Build JSON payload — write to file, NOT heredoc (Korean multi-line + bash heredoc SyntaxError risk)
python3 -c "
import json, base64, sys
content = open('/path/to/file','rb').read()
print(json.dumps({
    'message': 'docs: update README',
    'content': base64.b64encode(content).decode(),
    'sha': '$BLOB_SHA',
    'branch': 'main'
}, ensure_ascii=False))" > /tmp/payload.json

# 4. PUT
gh api -X PUT "repos/$GH_OWNER/$GH_REPO/contents/README.md" --input /tmp/payload.json
```

### ⚠️ Pitfalls (2026-07-07 Repolis README patch 실측)

1. **`sha` 필수 (update 시)**: atomic 보장용 — 생략 시 다른 사람이 사이에 푸시해도 silent overwrite 위험. **GET으로 현재 blob sha를 먼저 읽어와 포함**.
2. **bash heredoc + 한국어 multi-line message**: `<<PYEOF ... PYEOF` 안에서 한국어 + `\n` + 영문 혼합 시 SyntaxError 가능. **payload는 항상 파일로 작성** (`python3 script.py > /tmp/payload.json`) 후 `--input` 플래그로 전달.
3. **`base64 -w 0`**: macOS 기본 BSD `base64`는 line wrap 안 함 (good), GNU `coreutils base64`는 wrap 함 → `-w 0` 명시.
4. **base64 payload size**: 큰 파일(> ~1MB) 직접 PUT 거부. GitHub API는 `content` 필드로 multi-MB blob 거부할 수 있음. 이땐 **Git Data API** (`/git/blobs` + `/git/trees` + `/git/refs/heads/...`) 3-step workflow 또는 임시 `git clone + push` 권장.
5. **Concurrent edit race**: 두 클라이언트가 동시에 PUT하면 둘 다 200이지만 later commit이 earlier을 덮어쓸 수 있음 → **`sha` 검증이 가장 안전**.
6. **Response 422 if sha missing on update**: `{"message":"sha is required when updating", ...}` → ① 본문 누락 또는 ② write_file이 빈 파일 만들었을 때 sha가 invalid. 둘 다 즉시 GET으로 blob sha 재확인.
7. **Commit author 자동**: 별도 `author`/`committer` 필드 생략 시 토큰 명의 (예: `sigco3111`)로 자동 작성됨. 커스텀 author 필요하면 `{"name":"x","email":"y"}` dict 추가.

### Real-world use case (Repolis README 9 patch → 1 atomic commit)

PR 안 만들고 main에 직접 한 번 commit:

```bash
BLOB=$(gh api repos/sigco3111/Repolis/contents/README.md --jq '.sha')
# download to /tmp/readme.md, edit, base64 encode
python3 -c "
import json, base64
content = open('/tmp/readme.md','rb').read()
print(json.dumps({
    'message': 'docs(Repolis): remove fixed repo counts, add live-sync badge',
    'content': base64.b64encode(content).decode(),
    'sha': '$BLOB',
    'branch': 'main'
}, ensure_ascii=False))" > /tmp/payload.json
gh api -X PUT repos/sigco3111/Repolis/contents/README.md --input /tmp/payload.json
# 응답: commit.sha (new commit), content.sha (new blob), parents[0].sha (HEAD before)
```

## Pull Requests

| Action | Method | Endpoint |
|--------|--------|----------|
| List PRs | GET | `/repos/{owner}/{repo}/pulls?state=open` |
| Create PR | POST | `/repos/{owner}/{repo}/pulls` |
| Get PR | GET | `/repos/{owner}/{repo}/pulls/{number}` |
| Update PR | PATCH | `/repos/{owner}/{repo}/pulls/{number}` |
| List PR files | GET | `/repos/{owner}/{repo}/pulls/{number}/files` |
| Merge PR | PUT | `/repos/{owner}/{repo}/pulls/{number}/merge` |
| Request reviewers | POST | `/repos/{owner}/{repo}/pulls/{number}/requested_reviewers` |
| Create review | POST | `/repos/{owner}/{repo}/pulls/{number}/reviews` |
| Inline comment | POST | `/repos/{owner}/{repo}/pulls/{number}/comments` |

### PR Merge Body

```json
{"merge_method": "squash", "commit_title": "feat: description (#N)"}
```

Merge methods: `"merge"`, `"squash"`, `"rebase"`.

### PR Review Events

`"APPROVE"`, `"REQUEST_CHANGES"`, `"COMMENT"`.

## Issues

| Action | Method | Endpoint |
|--------|--------|----------|
| List issues | GET | `/repos/{owner}/{repo}/issues?state=open` |
| Create issue | POST | `/repos/{owner}/{repo}/issues` |
| Get issue | GET | `/repos/{owner}/{repo}/issues/{number}` |
| Update issue | PATCH | `/repos/{owner}/{repo}/issues/{number}` |
| Add comment | POST | `/repos/{owner}/{repo}/issues/{number}/comments` |
| Add labels | POST | `/repos/{owner}/{repo}/issues/{number}/labels` |
| Remove label | DELETE | `/repos/{owner}/{repo}/issues/{number}/labels/{name}` |
| Add assignees | POST | `/repos/{owner}/{repo}/issues/{number}/assignees` |
| List labels | GET | `/repos/{owner}/{repo}/labels` |
| Search issues | GET | `/search/issues?q={query}+repo:{owner}/{repo}` |

Note: the Issues API also returns PRs. Filter with `"pull_request" not in item` when parsing.

## CI / GitHub Actions

| Action | Method | Endpoint |
|--------|--------|----------|
| List workflows | GET | `/repos/{owner}/{repo}/actions/workflows` |
| List runs | GET | `/repos/{owner}/{repo}/actions/runs?per_page=10` |
| List runs (branch) | GET | `/repos/{owner}/{repo}/actions/runs?branch={branch}` |
| Get run | GET | `/repos/{owner}/{repo}/actions/runs/{run_id}` |
| Download logs | GET | `/repos/{owner}/{repo}/actions/runs/{run_id}/logs` |
| Re-run | POST | `/repos/{owner}/{repo}/actions/runs/{run_id}/rerun` |
| Re-run failed | POST | `/repos/{owner}/{repo}/actions/runs/{run_id}/rerun-failed-jobs` |
| Trigger dispatch | POST | `/repos/{owner}/{repo}/actions/workflows/{id}/dispatches` |
| Commit status | GET | `/repos/{owner}/{repo}/commits/{sha}/status` |
| Check runs | GET | `/repos/{owner}/{repo}/commits/{sha}/check-runs` |

## Releases

| Action | Method | Endpoint |
|--------|--------|----------|
| List releases | GET | `/repos/{owner}/{repo}/releases` |
| Create release | POST | `/repos/{owner}/{repo}/releases` |
| Get release | GET | `/repos/{owner}/{repo}/releases/{id}` |
| Delete release | DELETE | `/repos/{owner}/{repo}/releases/{id}` |
| Upload asset | POST | `https://uploads.github.com/repos/{owner}/{repo}/releases/{id}/assets?name={filename}` |

## Secrets

| Action | Method | Endpoint |
|--------|--------|----------|
| List secrets | GET | `/repos/{owner}/{repo}/actions/secrets` |
| Get public key | GET | `/repos/{owner}/{repo}/actions/secrets/public-key` |
| Set secret | PUT | `/repos/{owner}/{repo}/actions/secrets/{name}` |
| Delete secret | DELETE | `/repos/{owner}/{repo}/actions/secrets/{name}` |

## Branch Protection

| Action | Method | Endpoint |
|--------|--------|----------|
| Get protection | GET | `/repos/{owner}/{repo}/branches/{branch}/protection` |
| Set protection | PUT | `/repos/{owner}/{repo}/branches/{branch}/protection` |
| Delete protection | DELETE | `/repos/{owner}/{repo}/branches/{branch}/protection` |

## User / Auth

| Action | Method | Endpoint |
|--------|--------|----------|
| Get current user | GET | `/user` |
| List user repos | GET | `/user/repos` |
| List user gists | GET | `/gists` |
| Create gist | POST | `/gists` |
| Search repos | GET | `/search/repositories?q={query}` |

## Pagination

Most list endpoints support:
- `?per_page=100` (max 100)
- `?page=2` for next page
- Check `Link` header for `rel="next"` URL

## Rate Limits

- Authenticated: 5,000 requests/hour
- Check remaining: `curl -s -H "Authorization: token $GITHUB_TOKEN" https://api.github.com/rate_limit`

## Common curl Patterns

```bash
# GET
curl -s -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$GH_OWNER/$GH_REPO

# POST with JSON body
curl -s -X POST \
  -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$GH_OWNER/$GH_REPO/issues \
  -d '{"title": "...", "body": "..."}'

# PATCH (update)
curl -s -X PATCH \
  -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$GH_OWNER/$GH_REPO/issues/42 \
  -d '{"state": "closed"}'

# DELETE
curl -s -X DELETE \
  -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$GH_OWNER/$GH_REPO/issues/42/labels/bug

# Parse JSON response with python3
curl -s ... | python3 -c "import sys,json; data=json.load(sys.stdin); print(data['field'])"

# PUT file contents (atomic, single commit) — see "Repository Contents" above for full pattern
curl -s -X PUT \
  -H "Authorization: token $GITHUB_TOKEN" \
  -H "Accept: application/vnd.github+json" \
  https://api.github.com/repos/$GH_OWNER/$GH_REPO/contents/path/to/file \
  -d "$(python3 -c "import json,base64; print(json.dumps({'message':'docs: update','content':base64.b64encode(open(\"file\",\"rb\").read()).decode(),'sha':'<current-blob-sha>','branch':'main'}, ensure_ascii=False))")"
```

## ⚠️ `gh repo create --source=. --push`의 remote 디폴트는 `upstream` (2026-07-02 추가)

`gh repo create X --public --source=. --push`로 신규 repo를 만들고 즉시 푸시하면 gh CLI는 **remote 이름을 `upstream`으로 자동 추가**함. 표준 이름인 `origin`이 아님.

**증상**:
```bash
gh repo create particle-fireworks --public --source=. --push
git remote -v
# upstream   https://github.com/.../particle-fireworks.git (fetch)
# upstream   https://github.com/.../particle-fireworks.git (push)
```

**문제**: 다른 스크립트 / GitHub Actions / 사용자가 `origin` 가정하면 일관성 깨짐. 검증 스크립트의 `git rev-parse origin/main`가 죽고 `git rev-parse upstream/main`만 살아있음.

**해결**:

```bash
# 1순위: --remote=origin 명시 (가장 단순)
gh repo create particle-fireworks --public --source=. --remote=origin --push
git remote -v
# origin   https://...

# 2순위: push 직후 rename
gh repo create X --source=. --push
git remote rename upstream origin
# 기존 origin이 있었다면: git remote rename origin github; git remote rename upstream origin

# 3순위: 검증이 remote 이름 무관하게 3중 SHA 비교에 집중 (가장 견고)
LOCAL=$(git rev-parse HEAD)
GH_MAIN=$(curl -s -H "Authorization: token $GITHUB_TOKEN" \
  "https://api.github.com/repos/$GH_OWNER/$GH_REPO/branches/main" \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['commit']['sha'])")
[ "$LOCAL" = "$GH_MAIN" ] && echo "✓ 푸시 사실관계 결정적" || echo "✗ 불일치"
```

**cross-reference**: `ad-hoc-verification` SKILL.md 함정 12 + `references/git-push-trust.md` 흔한 함정 #6.
