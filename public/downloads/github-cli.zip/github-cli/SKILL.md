---
name: github-cli
description: Work with GitHub from the terminal — auth, repos, issues, PRs, code review, CI workflows, releases, secrets, code search, and codebase metrics. Uses the `gh` CLI when available, otherwise `git` + GitHub REST API via `curl`. One umbrella for all GitHub work.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [GitHub, CLI, gh, git, Authentication, Repositories, Issues, Pull-Requests, Code-Review, Actions, CI/CD, Releases, Secrets]
---

# GitHub CLI

One class-level skill for all terminal-driven GitHub work. Each labeled section is a self-contained workflow. Pick the section that matches the task; cross-references between sections handle the rest.

**Sections (jump directly):**
1. [Authentication](#1-authentication) — set up `gh` or `git`+`curl` for unauthenticated machines
2. [Repository management](#2-repository-management) — clone, create, fork, settings, releases, gists
3. [Issues](#3-issues) — create, search, triage, label, assign, close
4. [Pull request workflow](#4-pull-request-workflow) — branch → commit → push → open PR → monitor CI → merge
5. [Code review](#5-code-review) — local pre-push review and on-PR review with inline comments
6. [GitHub Actions & CI](#6-github-actions--ci) — workflow YAML templates, secrets, monitoring, troubleshooting
7. [Codebase inspection](#7-codebase-inspection) — LOC, language breakdown, code-vs-comment ratios
8. [Auth detection helper](#8-auth-detection-helper) — pick `gh` or `git`+`curl` automatically

**When to use which section:**

| User wants... | Section |
|---|---|
| Set up GitHub auth, "I can't push", "configure gh" | [§1](#1-authentication) |
| Create a new repo, fork, clone, change settings, release | [§2](#2-repository-management) |
| Work with issues, triage, label, bulk close | [§3](#3-issues) |
| Branch → commit → PR → merge; CI fixing | [§4](#4-pull-request-workflow) |
| Review code (local or PR), inline comments, approve/request changes | [§5](#5-code-review) |
| Write a workflow YAML, debug CI, manage secrets, releases | [§6](#6-github-actions--ci) |
| "How big is this repo?", LOC, language breakdown | [§7](#7-codebase-inspection) |
| Need token + owner/repo in shell env automatically | [§8](#8-auth-detection-helper) |

---

## 1. Authentication

Set up GitHub access. Choose the path that matches what's installed on the machine.

**Always check first:**

```bash
git --version
gh --version 2>/dev/null || echo "gh not installed"
gh auth status 2>/dev/null || echo "gh not authenticated"
git config --global credential.helper 2>/dev/null || echo "no git credential helper"
```

**Decision tree:**

1. `gh auth status` shows authenticated → you're good, use `gh` for everything
2. `gh` is installed but not authenticated → use §1.2 below
3. `gh` is not installed → use §1.1 below (no sudo needed)

### 1.1 Git-Only Authentication (no `gh`, no sudo)

**Option A: HTTPS + Personal Access Token** — most portable, works everywhere.

1. Go to https://github.com/settings/tokens and generate a "classic" token with scopes `repo`, `workflow`, `read:org` (90-day expiration default).
2. Configure the credential helper:

```bash
git config --global credential.helper store
# Or cache in memory (8h):
git config --global credential.helper 'cache --timeout=28800'

# Trigger a credential prompt — username + paste token as "password"
git ls-remote https://github.com/<your-username>/<any-repo>.git
```

3. Set git identity:

```bash
git config --global user.name "Your Name"
git config --global user.email "your-email@example.com"
```

**Option B: SSH keys** — preferred for SSH-familiar users.

```bash
# Generate ed25519 key
ssh-keygen -t ed25519 -C "your-email@example.com" -f ~/.ssh/id_ed25519 -N ""
cat ~/.ssh/id_ed25519.pub   # add at https://github.com/settings/keys

# Test
ssh -T git@github.com   # expect: "Hi <username>! You've successfully authenticated..."

# Auto-rewrite HTTPS GitHub URLs to SSH
git config --global url."git@github.com:".insteadOf "https://github.com/"
```

**Troubleshooting quick-reference:**

| Problem | Solution |
|---|---|
| `git push` asks for password | Token-based auth required (HTTPS) or switch to SSH |
| `Permission to X denied` | Token missing `repo` scope — regenerate with `repo` |
| `fatal: Authentication failed` | `git credential reject` then re-auth |
| SSH `port 22: Connection refused` | Add `Host github.com` + `Port 443` + `Hostname ssh.github.com` in `~/.ssh/config` |
| Multiple GitHub accounts | Per-host SSH aliases in `~/.ssh/config`, or per-repo credential URLs |

### 1.2 `gh` CLI Authentication

```bash
# Interactive browser login
gh auth login

# Headless / SSH — token in stdin
echo "$TOKEN" | gh auth login --with-token

# After login, hand gh control over git credentials too
gh auth setup-git

# Verify
gh auth status
gh auth status --text   # human-readable
gh doctor               # installation health
```

### 1.3 API Access Without `gh`

```bash
# Export token (keeps it out of command history)
export GITHUB_TOKEN="<token>"

# Or extract from credential store
export GITHUB_TOKEN=$(grep "github.com" ~/.git-credentials 2>/dev/null | head -1 | sed 's|https://[^:]*:\([^@]*\)@.*|\1|')
```

All API calls in later sections use `$GITHUB_TOKEN`. See [§8](#8-auth-detection-helper) for a one-liner that sets everything up.

---

## 2. Repository Management

Create, clone, fork, configure, and manage GitHub repositories.

### 2.1 Cloning

Pure `git` — works identically with or without `gh`:

```bash
git clone https://github.com/owner/repo.git
git clone --depth 1 https://github.com/owner/repo.git     # shallow
git clone --branch develop https://github.com/owner/repo.git

# Shorter with gh
gh repo clone owner/repo
gh repo clone owner/repo -- --depth 1
```

### 2.2 Creating Repositories

**With `gh`:**

```bash
gh repo create my-new-project --public --clone
gh repo create my-new-project --private --description "Useful tool" --license MIT --clone
gh repo create my-org/my-new-project --public --clone
gh repo create my-project --source . --public --push   # from existing local dir
```

**With `curl`:**

```bash
# User-owned
curl -s -X POST -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/user/repos \
  -d '{"name":"my-new-project","description":"Useful tool","private":false,"auto_init":true,"license_template":"mit"}'

# Org-owned
curl -s -X POST -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/orgs/my-org/repos \
  -d '{"name":"my-new-project","private":false}'

# From template
curl -s -X POST -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/owner/template-repo/generate \
  -d "{\"owner\":\"$GH_USER\",\"name\":\"my-new-app\",\"private\":false}"
```

### 2.3 Forking

```bash
# gh
gh repo fork owner/repo-name --clone

# curl + git
curl -s -X POST -H "Authorization: token $GITHUB_TOKEN" https://api.github.com/repos/owner/repo-name/forks
sleep 3
git clone https://github.com/$GH_USER/repo-name.git
cd repo-name
git remote add upstream https://github.com/owner/repo-name.git

# Sync fork
git fetch upstream && git checkout main && git merge upstream/main && git push origin main
```

### 2.4 Repository Information

```bash
# gh
gh repo view owner/repo
gh repo list --limit 20
gh search repos "machine learning" --language python --sort stars

# curl
curl -s -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$GH_OWNER/$GH_REPO | python3 -c "
import sys, json
r = json.load(sys.stdin)
print(f\"Name: {r['full_name']}\nStars: {r['stargazers_count']}\nForks: {r['forks_count']}\nDefault: {r['default_branch']}\nLanguage: {r['language']}\")"
```

### 2.5 Repository Settings

```bash
# gh
gh repo edit --description "Updated" --visibility public
gh repo edit --enable-wiki=false --enable-issues=true
gh repo edit --default-branch main
gh repo edit --add-topic "machine-learning,python"
gh repo edit --enable-auto-merge

# curl (PATCH)
curl -s -X PATCH -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$GH_OWNER/$GH_REPO \
  -d '{"description":"Updated","has_wiki":false,"has_issues":true,"allow_auto_merge":true}'

# Topics
curl -s -X PUT -H "Authorization: token $GITHUB_TOKEN" \
  -H "Accept: application/vnd.github.mercy-preview+json" \
  https://api.github.com/repos/$GH_OWNER/$GH_REPO/topics \
  -d '{"names":["machine-learning","python"]}'
```

### 2.6 Branch Protection

```bash
curl -s -X PUT -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$GH_OWNER/$GH_REPO/branches/main/protection \
  -d '{
    "required_status_checks": {"strict": true, "contexts": ["ci/test","ci/lint"]},
    "enforce_admins": false,
    "required_pull_request_reviews": {"required_approving_review_count": 1},
    "restrictions": null
  }'
```

### 2.7 Secrets (GitHub Actions)

```bash
# gh — simple
gh secret set API_KEY --body "your-secret-value"
gh secret set SSH_KEY < ~/.ssh/id_rsa
gh secret list
gh secret delete API_KEY

# Per-environment
gh secret set API_KEY --env production

# Non-secret env vars
gh variable set VAR_NAME --body "value"

# curl — requires encryption with repo's public key
# Get public key
curl -s -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$GH_OWNER/$GH_REPO/actions/secrets/public-key

# Encrypt with PyNaCl, then PUT
# (use gh secret set unless you must script it via curl)
```

### 2.8 Releases

```bash
# gh
gh release create v1.0.0 --title "v1.0.0" --generate-notes
gh release create v2.0.0-rc1 --draft --prerelease --generate-notes
gh release create v1.0.0 ./dist/binary --title "v1.0.0" --notes "Release notes"
gh release list
gh release download v1.0.0 --dir ./downloads

# curl
curl -s -X POST -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$GH_OWNER/$GH_REPO/releases \
  -d '{"tag_name":"v1.0.0","name":"v1.0.0","body":"## Changelog\n- Feature A","generate_release_notes":true}'

# Upload asset
curl -s -X POST -H "Authorization: token $GITHUB_TOKEN" \
  -H "Content-Type: application/octet-stream" \
  "https://uploads.github.com/repos/$GH_OWNER/$GH_REPO/releases/$RELEASE_ID/assets?name=binary-amd64" \
  --data-binary @./dist/binary-amd64
```

### 2.9 Gists

```bash
gh gist create script.py --public --desc "Useful script"
gh gist list

# curl
curl -s -X POST -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/gists \
  -d '{"description":"Useful script","public":true,"files":{"script.py":{"content":"print(\"hello\")"}}}'
```

---

## 3. Issues

Create, search, triage, and manage GitHub issues. Each section shows `gh` first, then `curl` fallback.

### 3.1 Viewing Issues

```bash
# gh
gh issue list
gh issue list --state open --label "bug"
gh issue list --assignee @me
gh issue list --search "authentication error" --state all
gh issue view 42

# curl
curl -s -H "Authorization: token $GITHUB_TOKEN" \
  "https://api.github.com/repos/$GH_OWNER/$GH_REPO/issues?state=open&per_page=20" \
  | python3 -c "
import sys, json
for i in json.load(sys.stdin):
    if 'pull_request' not in i:
        labels = ', '.join(l['name'] for l in i['labels'])
        print(f\"#{i['number']:5}  {i['state']:6}  {labels:30}  {i['title']}\")"
```

### 3.2 Creating Issues

**Bug report and feature request templates are in `templates/bug-report.md` and `templates/feature-request.md`.** Fill them in and pass via `--body` / JSON `body`.

```bash
# gh
gh issue create --title "Login redirect ignores ?next= parameter" --body-file templates/bug-report.md --label "bug,backend" --assignee "username"

# curl
curl -s -X POST -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$GH_OWNER/$GH_REPO/issues \
  -d "{\"title\":\"Login redirect ignores ?next= parameter\",\"body\":\"$(cat templates/bug-report.md)\",\"labels\":[\"bug\",\"backend\"],\"assignees\":[\"username\"]}"
```

### 3.3 Managing Issues

**Labels:**

```bash
gh issue edit 42 --add-label "priority:high,bug"
gh issue edit 42 --remove-label "needs-triage"

# curl
curl -s -X POST -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$GH_OWNER/$GH_REPO/issues/42/labels \
  -d '{"labels":["priority:high","bug"]}'

# List labels
curl -s -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$GH_OWNER/$GH_REPO/labels | python3 -c "
import sys, json
for l in json.load(sys.stdin): print(f\"  {l['name']:30}  {l.get('description','')}\")"
```

**Assign / comment / close:**

```bash
gh issue edit 42 --add-assignee username
gh issue edit 42 --add-assignee @me
gh issue comment 42 --body "Investigating — root cause is in auth middleware."
gh issue close 42 --reason "not planned"
gh issue reopen 42

# curl equivalents
curl -s -X POST -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$GH_OWNER/$GH_REPO/issues/42/assignees \
  -d '{"assignees":["username"]}'

curl -s -X PATCH -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$GH_OWNER/$GH_REPO/issues/42 \
  -d '{"state":"closed","state_reason":"not_planned"}'
```

### 3.4 Linking Issues to PRs

Issues auto-close when a PR body contains these keywords:

```
Closes #42
Fixes #42
Resolves #42
```

```bash
# Create branch from issue
gh issue develop 42 --checkout
# or
git checkout main && git pull && git checkout -b fix/issue-42-login-redirect
```

### 3.5 Triage Workflow

```bash
gh issue list --label "needs-triage" --state open
# Read each, then for each:
gh issue edit <n> --add-label "priority:high,bug" --remove-label "needs-triage" --add-assignee <owner>
gh issue comment <n> --body "Triaged: <notes>"
```

### 3.6 Bulk Operations

```bash
# Close all "wontfix" issues
gh issue list --label "wontfix" --json number --jq '.[].number' | \
  xargs -I {} gh issue close {} --reason "not planned"

# curl equivalent
curl -s -H "Authorization: token $GITHUB_TOKEN" \
  "https://api.github.com/repos/$GH_OWNER/$GH_REPO/issues?labels=wontfix&state=open" \
  | python3 -c "import sys,json; [print(i['number']) for i in json.load(sys.stdin)]" \
  | while read num; do
    curl -s -X PATCH -H "Authorization: token $GITHUB_TOKEN" \
      https://api.github.com/repos/$GH_OWNER/$GH_REPO/issues/$num \
      -d '{"state":"closed","state_reason":"not_planned"}'
  done
```

---

## 4. Pull Request Workflow

Full PR lifecycle: branch → commit → push → open PR → monitor CI → fix failures → merge.

### 4.1 Branch + Commit

```bash
git fetch origin
git checkout main && git pull origin main
git checkout -b feat/add-user-authentication
```

Commit with [Conventional Commits](references/conventional-commits.md) format (full reference at `references/conventional-commits.md`):

```bash
git add src/auth.py src/models/user.py tests/test_auth.py
git commit -m "feat: add JWT-based user authentication

- Add login/register endpoints
- Add User model with password hashing
- Add auth middleware for protected routes"
```

Types: `feat`, `fix`, `refactor`, `docs`, `test`, `ci`, `chore`, `perf`, `style`, `build`, `revert`. Add `!` for breaking changes.

### 4.2 Push + Open PR

```bash
git push -u origin HEAD

# gh
gh pr create --title "feat: add JWT-based user authentication" \
  --body-file templates/pr-body-feature.md

# curl
BRANCH=$(git branch --show-current)
curl -s -X POST -H "Authorization: token $GITHUB_TOKEN" \
  -H "Accept: application/vnd.github.v3+json" \
  https://api.github.com/repos/$GH_OWNER/$GH_REPO/pulls \
  -d "{\"title\":\"feat: add JWT-based user authentication\",\"head\":\"$BRANCH\",\"base\":\"main\"}"
```

**PR body templates:** `templates/pr-body-feature.md` and `templates/pr-body-bugfix.md`.

**gh options:** `--draft`, `--reviewer user1,user2`, `--label "enhancement"`, `--base develop`.

### 4.3 Monitor CI Status

```bash
# gh
gh pr checks                # one-shot
gh pr checks --watch        # poll until done

# curl
SHA=$(git rev-parse HEAD)
curl -s -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$GH_OWNER/$GH_REPO/commits/$SHA/status \
  | python3 -c "
import sys, json
data = json.load(sys.stdin)
print(f\"Overall: {data['state']}\")
for s in data.get('statuses', []):
    print(f\"  {s['context']}: {s['state']} - {s.get('description','')}\")"

# Actions check-runs (separate from commit status)
curl -s -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$GH_OWNER/$GH_REPO/commits/$SHA/check-runs \
  | python3 -c "
import sys, json
for cr in json.load(sys.stdin).get('check_runs', []):
    print(f\"  {cr['name']}: {cr['status']} / {cr['conclusion'] or 'pending'}\")"
```

**Polling loop:**

```bash
SHA=$(git rev-parse HEAD)
for i in $(seq 1 20); do
  STATUS=$(curl -s -H "Authorization: token $GITHUB_TOKEN" \
    https://api.github.com/repos/$GH_OWNER/$GH_REPO/commits/$SHA/status \
    | python3 -c "import sys,json; print(json.load(sys.stdin)['state'])")
  echo "Check $i: $STATUS"
  if [ "$STATUS" = "success" ] || [ "$STATUS" = "failure" ] || [ "$STATUS" = "error" ]; then break; fi
  sleep 30
done
```

### 4.4 Auto-Fix CI Failures

**Step 1 — diagnose:**

```bash
# gh
gh run list --branch $(git branch --show-current) --limit 5
gh run view <RUN_ID> --log-failed

# curl
BRANCH=$(git branch --show-current)
curl -s -H "Authorization: token $GITHUB_TOKEN" \
  "https://api.github.com/repos/$GH_OWNER/$GH_REPO/actions/runs?branch=$BRANCH&per_page=5"

# Download failed run logs
curl -s -L -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$GH_OWNER/$GH_REPO/actions/runs/$RUN_ID/logs \
  -o /tmp/ci-logs.zip
cd /tmp && unzip -o ci-logs.zip -d ci-logs
```

Full failure-pattern reference: `references/ci-troubleshooting.md`.

**Step 2 — fix and re-push:**

```bash
# Edit files with patch/write_file
git add <fixed_files>
git commit -m "fix: resolve CI failure in <check_name>"
git push
```

**Step 3 — verify (re-run §4.3).**

**Auto-fix loop:** check CI → identify failure → fix code → commit/push → wait → re-check. Up to 3 attempts, then ask the user.

### 4.5 Merge

```bash
# gh
gh pr merge --squash --delete-branch
gh pr merge --auto --squash --delete-branch   # auto-merge when checks pass

# curl
PR_NUMBER=<number>
curl -s -X PUT -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$GH_OWNER/$GH_REPO/pulls/$PR_NUMBER/merge \
  -d "{\"merge_method\":\"squash\",\"commit_title\":\"feat: user authentication (#$PR_NUMBER)\"}"

# Delete branch
BRANCH=$(git branch --show-current)
git push origin --delete $BRANCH
git checkout main && git pull && git branch -d $BRANCH
```

Merge methods: `"merge"`, `"squash"`, `"rebase"`.

**Auto-merge via GraphQL (REST doesn't support it):**

```bash
PR_NODE_ID=$(curl -s -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$GH_OWNER/$GH_REPO/pulls/$PR_NUMBER \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['node_id'])")

curl -s -X POST -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/graphql \
  -d "{\"query\":\"mutation{enablePullRequestAutoMerge(input:{pullRequestId:\\\"$PR_NODE_ID\\\",mergeMethod:SQUASH}){clientMutationId}}\"}"
```

### 4.6 PR Quick Reference

| Action | gh | curl |
|---|---|---|
| List my PRs | `gh pr list --author @me` | `GET /repos/{o}/{r}/pulls?state=open` |
| View diff | `gh pr diff` | `git diff main...HEAD` (local) |
| Add comment | `gh pr comment N --body "..."` | `POST /repos/.../issues/N/comments` |
| Request review | `gh pr edit N --add-reviewer user` | `POST /pulls/N/requested_reviewers` |
| Close PR | `gh pr close N` | `PATCH /pulls/N` `{"state":"closed"}` |
| Check out PR | `gh pr checkout N` | `git fetch origin pull/N/head:pr-N && git checkout pr-N` |

---

## 5. Code Review

Review local changes before pushing, or open PRs on GitHub with inline comments.

### 5.1 Local Pre-Push Review

Pure `git` — works everywhere.

```bash
git diff --staged                                  # staged changes
git diff main...HEAD                               # all changes vs main
git diff main...HEAD --stat                        # file count summary
git diff main...HEAD --name-only                   # file list
```

**Common-issue grep:**

```bash
git diff main...HEAD | grep -n "print(\|console\.log\|TODO\|FIXME\|HACK\|XXX\|debugger"
git diff main...HEAD --stat | sort -t'|' -k2 -rn | head -10   # largest files
git diff main...HEAD | grep -in "password\|secret\|api_key\|token.*=\|private_key"
git diff main...HEAD | grep -n "<<<<<<\|>>>>>>\|======="  # merge conflict markers
```

**Review output format** (use the same for local + PR review):

```markdown
## Code Review Summary

### Critical
- **src/auth.py:45** — SQL injection: user input passed directly to query.
  Suggestion: Use parameterized queries.

### Warnings
- **src/models/user.py:23** — Password stored in plaintext. Use bcrypt or argon2.
- **src/api/routes.py:112** — No rate limiting on login endpoint.

### Suggestions
- **src/utils/helpers.py:8** — Duplicates logic in `src/core/utils.py:34`. Consolidate.

### Looks Good
- Clean separation of concerns in the middleware layer
- Good test coverage for the happy path
```

Full template + severity guide: `references/review-output-template.md`.

### 5.2 Review a PR on GitHub

```bash
# gh
gh pr view 123
gh pr diff 123
gh pr diff 123 --name-only
gh pr checks 123

# curl
curl -s -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$GH_OWNER/$GH_REPO/pulls/123 | python3 -c "
import sys, json
pr = json.load(sys.stdin)
print(f\"#{pr['number']} {pr['title']}\n{pr['user']['login']} {pr['head']['ref']} -> {pr['base']['ref']}\")"
```

**Check out PR locally for full review:**

```bash
git fetch origin pull/123/head:pr-123
git checkout pr-123
# Now: read_file, search_files, run tests freely
git diff main...pr-123   # diff against base

# Shorter with gh
gh pr checkout 123
```

### 5.3 Leave Comments

**General comment:**

```bash
gh pr comment 123 --body "Overall looks good, a few suggestions below."

# curl
curl -s -X POST -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$GH_OWNER/$GH_REPO/issues/123/comments \
  -d '{"body":"Overall looks good, a few suggestions below."}'
```

**Inline review comment:**

```bash
HEAD_SHA=$(gh pr view 123 --json headRefOid --jq '.headRefOid')

gh api repos/$GH_OWNER/$GH_REPO/pulls/123/comments --method POST \
  -f body="This could be simplified with a list comprehension." \
  -f path="src/auth/login.py" \
  -f commit_id="$HEAD_SHA" \
  -f line=45 -f side="RIGHT"

# curl
HEAD_SHA=$(curl -s -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$GH_OWNER/$GH_REPO/pulls/123 \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['head']['sha'])")

curl -s -X POST -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$GH_OWNER/$GH_REPO/pulls/123/comments \
  -d "{\"body\":\"...\",\"path\":\"src/auth.py\",\"commit_id\":\"$HEAD_SHA\",\"line\":45,\"side\":\"RIGHT\"}"
```

### 5.4 Submit a Formal Review (Approve / Request Changes)

```bash
# gh
gh pr review 123 --approve --body "LGTM!"
gh pr review 123 --request-changes --body "See inline comments."
gh pr review 123 --comment --body "Some suggestions, nothing blocking."

# curl — multi-comment atomic review
HEAD_SHA=$(curl -s -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$GH_OWNER/$GH_REPO/pulls/123 \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['head']['sha'])")

curl -s -X POST -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$GH_OWNER/$GH_REPO/pulls/123/reviews \
  -d "{
    \"commit_id\":\"$HEAD_SHA\",
    \"event\":\"COMMENT\",
    \"body\":\"Code review from Hermes Agent\",
    \"comments\":[
      {\"path\":\"src/auth.py\",\"line\":45,\"body\":\"Use parameterized queries.\"},
      {\"path\":\"src/models.py\",\"line\":23,\"body\":\"Hash passwords with bcrypt.\"}
    ]
  }"
```

Event values: `"APPROVE"`, `"REQUEST_CHANGES"`, `"COMMENT"`. The `line` field refers to the new file; use `"side": "LEFT"` for deleted lines.

### 5.5 Review Checklist

When reviewing (local or PR), systematically check:

- **Correctness** — Does it do what it claims? Edge cases? Error paths?
- **Security** — No hardcoded secrets, input validation, no SQL/XSS/path-traversal
- **Code Quality** — Clear naming, no over-abstraction, DRY, focused functions
- **Testing** — New paths tested, happy + error cases, maintainable tests
- **Performance** — No N+1, appropriate caching, no async blocking
- **Documentation** — Public APIs documented, non-obvious logic explained

### 5.6 PR Review Workflow (end-to-end)

When user asks "review PR #N":

```bash
# 1. Set up env (see §8)
source scripts/gh-env.sh

# 2. Gather PR context
gh pr view 123 && gh pr diff 123 --name-only && gh pr checks 123

# 3. Check out locally
git fetch origin pull/123/head:pr-123 && git checkout pr-123

# 4. Review
git diff main...HEAD
# Apply the §5.5 checklist

# 5. Run tests / linters if available
python -m pytest 2>&1 | tail -20
ruff check . 2>&1 | head -30

# 6. Submit review (§5.4)

# 7. Clean up
git checkout main && git branch -D pr-123
```

---

## 6. GitHub Actions & CI

### 6.1 Workflow File Structure

All workflows live in `.github/workflows/<name>.yml`:

```yaml
name: <workflow name>

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]
  workflow_dispatch:  # manual trigger

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      # ...
```

### 6.2 Common Triggers

```yaml
on:
  push:
    branches: [main]
    paths: ['src/**', 'tests/**']      # path filter
  pull_request:
    types: [opened, synchronize, reopened]
  schedule:
    - cron: '0 9 * * 1'                # weekly Monday 9am UTC
  workflow_dispatch:                    # manual
  workflow_call:                        # reusable
```

### 6.3 Workflow Templates

**Python CI:**

```yaml
name: Python CI
on: { push: { branches: [main] }, pull_request: { branches: [main] } }
jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix: { python-version: ['3.10', '3.11', '3.12'] }
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: { python-version: ${{ matrix.python-version }} }
      - run: pip install -r requirements.txt pytest ruff
      - run: ruff check .
      - run: pytest tests/ -v --tb=short
      - if: matrix.python-version == '3.12'
        uses: actions/upload-artifact@v4
        with: { name: coverage-report, path: htmlcov/ }
```

**Node.js CI:**

```yaml
name: Node.js CI
on: { push: { branches: [main] }, pull_request: { branches: [main] } }
jobs:
  build-and-test:
    runs-on: ubuntu-latest
    strategy: { matrix: { node-version: [18, 20] } }
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: ${{ matrix.node-version }}, cache: 'npm' }
      - run: npm ci
      - run: npm run lint
      - run: npm test
      - run: npm run build
```

**Docker build & push:**

```yaml
name: Docker Build & Push
on:
  push: { branches: [main], tags: ['v*'] }
jobs:
  docker:
    runs-on: ubuntu-latest
    permissions: { contents: read, packages: write }
    steps:
      - uses: actions/checkout@v4
      - uses: docker/login-action@v3
        with: { registry: ghcr.io, username: ${{ github.actor }}, password: ${{ secrets.GITHUB_TOKEN }} }
      - id: meta
        uses: docker/metadata-action@v5
        with: { images: ghcr.io/${{ github.repository }}, tags: |
            type=ref,event=branch
            type=semver,pattern={{version}}
            type=sha }
      - uses: docker/build-push-action@v5
        with: { context: ., push: true, tags: ${{ steps.meta.outputs.tags }}, cache-from: type=gha, cache-to: type=gha,mode=max }
```

**Auto release on tag:**

```yaml
name: Auto Release
on: { push: { tags: ['v*'] } }
jobs:
  release:
    runs-on: ubuntu-latest
    permissions: { contents: write }
    steps:
      - uses: actions/checkout@v4
        with: { fetch-depth: 0 }
      - id: changelog
        run: |
          PREV_TAG=$(git describe --tags --abbrev=0 HEAD^ 2>/dev/null || echo "")
          if [ -n "$PREV_TAG" ]; then
            CHANGES=$(git log ${PREV_TAG}..HEAD --pretty=format:"- %s (%h)" --no-merges)
          else
            CHANGES=$(git log --pretty=format:"- %s (%h)" --no-merges -20)
          fi
          echo "changes<<EOF" >> $GITHUB_OUTPUT
          echo "$CHANGES" >> $GITHUB_OUTPUT
          echo "EOF" >> $GITHUB_OUTPUT
      - uses: softprops/action-gh-release@v2
        with: { body: ${{ steps.changelog.outputs.changes }}, generate_release_notes: true }
```

### 6.4 Secrets & Environment Variables

Already covered in §2.7 (secrets) and §2.8 (env-vars). Quick reference:

```bash
gh secret set KEY --env production
gh variable set VAR --body "value" --env production
```

In workflows:

```yaml
env:
  API_KEY: ${{ secrets.API_KEY }}
```

### 6.5 Caching

```yaml
# pip
- uses: actions/cache@v4
  with:
    path: ~/.cache/pip
    key: ${{ runner.os }}-pip-${{ hashFiles('**/requirements.txt') }}

# npm (built into setup-node)
- uses: actions/setup-node@v4
  with: { node-version: 20, cache: 'npm' }

# Docker (in build-push-action)
cache-from: type=gha
cache-to: type=gha,mode=max
```

### 6.6 Matrix Builds

```yaml
jobs:
  test:
    runs-on: ${{ matrix.os }}
    strategy:
      fail-fast: false
      matrix:
        os: [ubuntu-latest, macos-latest, windows-latest]
        version: [1.18, 1.19, 1.20]
        exclude: [{ os: windows-latest, version: 1.18 }]
        include: [{ os: ubuntu-latest, version: 1.21, experimental: true }]
```

### 6.7 Reusable Workflows

**Caller (`caller.yml`):**

```yaml
jobs:
  test:
    uses: ./.github/workflows/reusable-test.yml
    with: { python-version: '3.12' }
    secrets: inherit
```

**Reusable (`reusable-test.yml`):**

```yaml
on:
  workflow_call:
    inputs: { python-version: { type: string, default: '3.11' } }
    secrets: { API_KEY: { required: false } }
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: { python-version: ${{ inputs.python-version }} }
      - run: pytest
```

### 6.8 Run Management

```bash
# List
gh run list --limit 10
# Detail
gh run view <RUN_ID>
# Failed log
gh run view <RUN_ID> --log-failed
# Manual trigger
gh workflow run <workflow_name> -f branch=develop
# Re-run / re-run failed
gh run rerun <RUN_ID>
gh run rerun <RUN_ID> --failed
# Cancel
gh run cancel <RUN_ID>
# Artifacts
gh run download <RUN_ID> --name artifact-name
```

### 6.9 Troubleshooting

| Problem | Cause | Fix |
|---|---|---|
| permission denied | Token scopes too narrow | Add `permissions:` block |
| timeout | Default 6h exceeded | Set `timeout-minutes:` |
| out of disk | Cache/artifact bloat | Prune `actions/cache` |
| rate limit | API overuse | Add caching, rotate tokens |
| flaky test | Nondeterministic | Use `retry` action or stabilize |
| `FileNotFoundError` in script | Missing referenced file | `gh api repos/.../contents/...` to confirm + recreate via `gh api --method PUT` |

**Tmate SSH debug session on failure:**

```yaml
- if: ${{ failure() }}
  uses: mxschmitt/action-tmate@v3
  with: { limit-access-to-actor: true }
  timeout-minutes: 15
```

### 6.10 Best Practices

1. Pin actions to commit SHA in production: `uses: actions/checkout@b4ffde65f46336ab88eb53be808477a3936bae11`
2. Use `permissions:` with minimum needed scopes
3. Use `fail-fast: false` in matrices
4. Separate environments (`production`, `staging`) for secrets
5. Name workflows descriptively: `ci-python.yml`, `deploy-prod.yml`

---

## 7. Codebase Inspection

`pygount`-powered LOC, language, and code-vs-comment metrics.

### 7.1 Basic Summary

```bash
pip install --break-system-packages pygount 2>/dev/null || pip install pygount

cd /path/to/repo
pygount --format=summary \
  --folders-to-skip=".git,node_modules,venv,.venv,__pycache__,.cache,dist,build,.next,.tox,.eggs,*.egg-info" \
  .
```

**Always** use `--folders-to-skip` — otherwise pygount crawls dependencies and may hang.

### 7.2 Folder Exclusions by Project Type

```bash
# Python
--folders-to-skip=".git,venv,.venv,__pycache__,.cache,dist,build,.tox,.eggs,.mypy_cache"

# JavaScript/TypeScript
--folders-to-skip=".git,node_modules,dist,build,.next,.cache,.turbo,coverage"

# General catch-all
--folders-to-skip=".git,node_modules,venv,.venv,__pycache__,.cache,dist,build,.next,.tox,vendor,third_party"
```

### 7.3 Filter by Language

```bash
pygount --suffix=py --format=summary .                 # only Python
pygount --suffix=py,yaml,yml --format=summary .       # multiple
```

### 7.4 Detail Output

```bash
# Per-file (default)
pygount --folders-to-skip=".git,node_modules,venv" .

# Sorted by code lines
pygount --folders-to-skip=".git,node_modules,venv" . | sort -t$'\t' -k1 -nr | head -20
```

### 7.5 Output Formats

```bash
pygount --format=summary .   # default — table
pygount --format=json .      # programmatic
```

### 7.6 Interpreting Results

Columns: **Language, Files, Code, Comment, %**

Pseudo-languages: `__empty__` (empty files), `__binary__`, `__generated__`, `__duplicate__`, `__unknown__`.

### 7.7 Pitfalls

1. **Always skip `.git`, `node_modules`, `venv`** — see §7.1
2. **Markdown = 0 code lines** — pygount classifies all markdown as comments (expected)
3. **JSON shows low code counts** — pygount parses JSON conservatively; use `wc -l` for accurate counts
4. **Large monorepos** — use `--suffix` to scope to specific languages

---

## 8. Auth Detection Helper

Use this pattern at the start of any GitHub workflow to set `$AUTH`, `$GITHUB_TOKEN`, `$GH_OWNER`, `$GH_REPO` correctly:

```bash
# Try gh first, fall back to git + curl
if command -v gh &>/dev/null && gh auth status &>/dev/null; then
  AUTH="gh"
else
  AUTH="git"
  if [ -z "$GITHUB_TOKEN" ]; then
    if [ -f $ENV_FILE ] && grep -q "^GITHUB_TOKEN=" $ENV_FILE; then
      GITHUB_TOKEN=$(grep "^GITHUB_TOKEN=" $ENV_FILE | head -1 | cut -d= -f2 | tr -d '\n\r')
    elif grep -q "github.com" ~/.git-credentials 2>/dev/null; then
      export GITHUB_TOKEN=$(grep "github.com" ~/.git-credentials 2>/dev/null | head -1 | sed 's|https://[^:]*:\([^@]*\)@.*|\1|')
    fi
  fi
fi
echo "Using: $AUTH"

# Extract owner/repo from remote (works for HTTPS and SSH)
REMOTE_URL=$(git remote get-url origin 2>/dev/null || echo "")
if [ -n "$REMOTE_URL" ]; then
  GH_OWNER_REPO=$(echo "$REMOTE_URL" | sed -E 's|.*github\.com[:/]||; s|\.git$||')
  GH_OWNER=$(echo "$GH_OWNER_REPO" | cut -d/ -f1)
  GH_REPO=$(echo "$GH_OWNER_REPO" | cut -d/ -f2)
  echo "Owner: $GH_OWNER, Repo: $GH_REPO"
fi

# If not in a git repo, query user
if [ "$AUTH" = "gh" ]; then
  GH_USER=$(gh api user --jq '.login')
else
  GH_USER=$(curl -s -H "Authorization: token $GITHUB_TOKEN" https://api.github.com/user | python3 -c "import sys,json; print(json.load(sys.stdin)['login'])")
fi
```

**Helper script:** `scripts/gh-env.sh` (sourced at the start of any session — sets all four vars).

---

## Quick Reference Table

| Action | gh | git + curl |
|---|---|---|
| Clone | `gh repo clone o/r` | `git clone https://github.com/o/r.git` |
| Create repo | `gh repo create name --public` | `POST /user/repos` |
| Fork | `gh repo fork o/r --clone` | `POST /forks` + `git clone` |
| List issues | `gh issue list` | `GET /issues?state=open` |
| Create issue | `gh issue create ...` | `POST /issues` |
| List PRs | `gh pr list --author @me` | `GET /pulls?state=open` |
| Create PR | `gh pr create ...` | `POST /pulls` |
| Merge PR | `gh pr merge --squash` | `PUT /pulls/N/merge` |
| Review PR | `gh pr review 123 --approve` | `POST /pulls/123/reviews` |
| List workflows | `gh workflow list` | `GET /actions/workflows` |
| Rerun CI | `gh run rerun ID` | `POST /actions/runs/ID/rerun` |
| Create release | `gh release create v1.0` | `POST /releases` |
| Set secret | `gh secret set KEY` | `PUT /actions/secrets/KEY` (encrypted) |

## Reference Files

- `references/ci-troubleshooting.md` — CI failure patterns and how to diagnose each
- `references/conventional-commits.md` — commit message format reference
- `references/review-output-template.md` — PR review comment template
- `references/github-api-cheatsheet.md` — REST API endpoints quick-reference
- `templates/bug-report.md` — issue body template
- `templates/feature-request.md` — issue body template
- `templates/pr-body-feature.md` — PR body template
- `templates/pr-body-bugfix.md` — PR body template
- `scripts/gh-env.sh` — sourced helper that sets `$GITHUB_TOKEN`, `$GH_OWNER`, `$GH_REPO`
