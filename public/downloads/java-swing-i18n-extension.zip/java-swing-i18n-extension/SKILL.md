---
name: java-swing-i18n-extension
description: Extend i18n on Java Swing game forks.
---

# Java Swing i18n Coverage Extension

Use when extending i18n coverage on a Java Swing application where most UI text is still hardcoded English — typical in turn-based strategy game forks (TripleA, FreeCol, jMonkeyEngine-based games).

Triggers: adding a new locale to a Swing fork, migrating hardcoded English literals to i18n lookups, fixing a `Locale.lookup()` regression that causes a new locale to silently load English.

## Architecture assumption (verify first)

Most Java Swing game forks use a **single-bundle properties** architecture:
- One base name → multiple locale files (`ui.properties`, `ui_de.properties`, `ui_ko.properties`).
- 50–200 keys per bundle. A single singleton (`I18nEngineFramework`, `MessagesBundle`) exposes `getText(key)`.

If the project has multiple bundles, check whether each bundle is registered for build-time test verification (see "Build-time safety net" below).

## Verified conversion pattern (TripleA)

```java
// 1. Add import (alphabetical, near other games.strategy.engine.framework imports)
import games.strategy.engine.framework.I18nEngineFramework;

// 2. JMenuBuilder / JMenuItemBuilder / JMenuItemCheckBoxBuilder — first arg
new JMenuBuilder("File", m) →
  new JMenuBuilder(I18nEngineFramework.get().getText("menubar.FileMenu.File"), m)

// 3. addMenuItem(String, KeyCode, Runnable) — LobbyMenu pattern
.addMenuItem("Exit", KeyCode.X, runnable) →
  .addMenuItem(I18nEngineFramework.get().getText("...Exit"), KeyCode.X, runnable)

// 4. JOptionPane msg/title — dynamic msg + static title
JOptionPane.showMessageDialog(frame, ui, "Game Options", type) →
  JOptionPane.showMessageDialog(frame, ui,
    I18nEngineFramework.get().getText("...GameOptionsTitle"), type)

// 5. JLabel inside dialogs (Roll Dice inputs)
new JLabel("Sides: ") →
  new JLabel(I18nEngineFramework.get().getText("...SidesOnTheDice"))
```

Properties entries (3 files):
```
menubar.GameMenu.Game=Game
menubar.GameMenu.Game=Spiel
menubar.GameMenu.Game=\uac8c\uc784
```

Korean uses `\uXXXX` escape; German/French use raw UTF-8 (ä ö ü ß é à).

## Build-time safety net

If the project has a test like `I18nResourceBundleTest.ensureLocalizedResultOfGetText`:
- Verifies every key has a value in every registered locale.
- For keys with English value >10 chars, verifies non-English locales return **different** strings.
- Run as build gate: `./gradlew :<module>:test --tests I18nResourceBundleTest`.

**Pitfall**: the test threshold is 10 chars. Short keys like "File" / "OK" pass even if untranslated — verify visually.

**Pitfall**: the test has a hardcoded `subclasses = List.of(I18nEngineFramework.class)`. New bundle subclasses must be added to this list or their keys are silently unverified.

## Pitfalls

### P1 — `Locale.lookup()` silently fails for new locales
`Locale.lookup(ranges, Collator.getAvailableLocales())` returns the **default** locale if no range entry matches the user's language. Adding a new locale to the language range map is necessary BUT NOT SUFFICIENT — `Collator.getAvailableLocales()` may not include it. Symptom: new locale loads English instead of expected translation. Fix: replace `Locale.lookup()` with an explicit `computeLocale()` that checks `system.getLanguage()` directly:

```java
private static Locale computeLocale() {
  final String lang = Locale.getDefault().getLanguage();
  if ("ko".equals(lang)) return Locale.KOREA;
  if ("de".equals(lang)) return Locale.GERMANY;
  return Locale.US;
}
```

### P2 — Subagent shells don't inherit `~/.zshrc`
Background subagents spawn in fresh shells. Java build commands fail with `Unable to locate a Java Runtime` even though the user shell has JAVA_HOME. Always prepend to every gradle/maven invocation:

```bash
export JAVA_HOME=/opt/homebrew/Cellar/openjdk@25/25.0.4/libexec/openjdk.jdk/Contents/Home
export PATH=$JAVA_HOME/bin:$PATH
java -version  # sanity check
./gradlew :game-headed:compileJava --console=plain 2>&1 | tail -10
```

Adjust `JAVA_HOME` for the actual JDK on the user's machine.

### P3 — Subagent encoding corruption on non-ASCII
Subagents writing German (`ä ö ü ß`) or French (`é à`) sometimes emit Latin-1 instead of UTF-8. Files compile OK but display broken (`Vollst�ndige` instead of `Vollständige`).

Verify after every properties edit:
```bash
python3 -c "
import sys
for f in ['path/to/ui.properties','path/to/ui_de.properties','path/to/ui_ko.properties']:
    with open(f,'rb') as fh:
        for i,line in enumerate(fh.readlines(),1):
            try: line.decode('utf-8')
            except UnicodeDecodeError as e:
                print(f'{f}:L{i}: not utf-8: {line[:80]!r}'); sys.exit(1)
print('utf-8 OK')
"
```
Re-write any failing line with `patch` using raw UTF-8 chars. Korean properties use `\uXXXX` escape; German properties do not.

### P4 — `JMenuBuilder.addMenuItem(String, ...)` empty-title crash
This overload throws `IllegalArgumentException` if title is null or blank. Build catches missing keys but not blank values — a typo that produces an empty translation will crash at menu open. Verify visually after deployment.

### P5 — Estimate inflation via official docs
TripleA's `docs/development/i18n_languages.md` quotes "12,628 strings in game-core" but those are **potentially translatable** strings, not the current translation target. Official goal is "5% (~650 strings)". Don't trust the high number — measure actual files with grep before committing to scope.

### P6 — Worker adds lines outside the diff scope (silent behavior change) ★
**Verified TripleA D2 (2026-07-28)**: Worker patching `getZoomMenu`'s `fitHeight` action listener accidentally pasted the `fitWidth` body's `ratio = Math.min(1, ratio);` clamp into `fitHeight` — which **changed behavior** (fitHeight no longer zooms past 1.0 even when map is shorter than window). Build still passed because both branches compile. Symptom: silent zoom regression only visible when user clicks "Fit Height" on a tall map.

**Defense**:
- **Diff review on EVERY file before commit** — `git diff <file>` and look for lines that weren't part of the replacement.
- If worker reports "I'm done" but only some files were touched, **read those files fresh** — patch tool results hide silent additions.
- Compare `git show HEAD:file` vs current — every added line must be justified by the prompt.

### P7 — Patch tool partial-match wipes lines (silent regression) ★
**Verified TripleA D2**: A `patch` call with a multi-line `old_string` matched a subset and replaced only part, deleting the `if (result != 0) { return; }` guard in the process. Build still passed because the code was syntactically valid (just logically broken — map zoom would always proceed even when user clicked Cancel).

**Defense**:
- When patching inside a long method, include **3+ lines of unique context on BOTH sides** of the target snippet.
- Run `git diff` after every patch to confirm only the intended lines changed.
- If worker reports "I had to recover from a partial-match", treat that file as **untrusted until re-read in full**.

### P8 — Worker adds properties keys that already exist (duplicate-key noise) ★
**Verified TripleA D2**: Worker pre-added some GameMenu/NetworkMenu keys. Human then patch-added the full set. End result: every key appeared twice in `ui.properties` / `ui_de.properties` / `ui_ko.properties`. Build passed (Java `Properties` keeps last value), smoke test passed (ResourceBundle returns last), but the files were unreadable.

**Defense — dedup before commit**:
```python
seen = set(); out = []
for line in open(f):
    if not line.strip(): out.append(line); continue
    key = line.split('=', 1)[0] if '=' in line else line
    if key in seen: continue
    seen.add(key); out.append(line)
open(f, 'w').write('\n'.join(out) + '\n')
```
Run this on all 3 properties files after every worker delegation, before commit.

**Verify with `comm -23`**: `comm -23 <(grep "^menubar\." en|sort -u) <(grep "^menubar\." ko|sort -u)` — should output nothing.

### P9 — Java `getText(...)` calls vs properties keys mismatch ★
**Verified TripleA D2**: Java code calls `getText("menubar.GameMenu.RollsNoEffectOnGame")` (worker chose this name). Human added keys to properties with name `RollsNoEffectLabel`. Build passed (key exists), but the **wrong key** gets looked up. Only smoke test that walks each Java `getText(...)` call against properties catches this.

**Defense**: After worker patch, **grep**:
```bash
grep -rE "getText\(\"" game-app --include="*.java" | sed 's/.*getText("//; s/").*//' | sort -u > /tmp/used_keys.txt
grep -E "^menubar\." game-app/game-core/src/main/resources/.../ui.properties | cut -d= -f1 | sort -u > /tmp/defined_keys.txt
diff /tmp/used_keys.txt /tmp/defined_keys.txt
```
Any line in the diff is a mismatch — fix either the Java call or the properties key.

### P10 — `addMenuItemWithHotkey(String, Runnable, KeyCode)` private helper (GameMenu pattern)
TripleA's `GameMenu.addMenuItemWithHotkey` is a **private static helper** that wraps `JMenuItemBuilder(title, keyCode)`. Patches must reach the first argument, not a `JMenuItemBuilder` literal:

```java
addMenuItemWithHotkey("Battle Calculator", () -> ..., mnemonic) →
addMenuItemWithHotkey(I18nEngineFramework.get().getText("menubar.GameMenu.BattleCalculator"), () -> ..., mnemonic)
```

This pattern is also used in TripleA's `ViewMenu.getZoomMenu` and `getMapFontAndColorEditorMenu` for property/option labels — same rule: replace the string arg with `getText(...)`.

### P11 — `patch` tool `path required` error after multiple `write_file` calls (3차-B verified ★)
**Verified 2026-07-28 3차-B**: After several `patch` calls with `mode='replace'` succeeded, subsequent calls in the same session **started failing with `path required`** even when `path` was passed in the payload. Root cause unclear — possibly tool-state drift after several `write_file` rewrites earlier in the session.

**Symptom**: same `mode='replace'` call shape that worked minutes earlier starts failing with `path required` or `old_string and new_string required`. Single-line, multi-line, `replace_all=true`/`false` all hit the same error.

**Fix**: write the entire file with `write_file`. This is more invasive (overwrites the whole file) but **works reliably** in any state. Verify after by `git diff <file>` to confirm only intended lines changed.

**Defensive playbook** when 2+ consecutive `patch` failures hit:
1. Stop calling `patch`.
2. Read the file in full (`read_file` with no limit).
3. `write_file` with the full updated content.
4. `git diff <file>` to confirm rewrite only touched the intended lines.

The 3차-B session rewrote 5 login panel files this way (LoginPanel, ChangeEmailPanel, ChangePasswordPanel, ForgotPasswordPanel, CreateAccountPanel) — each verified with `git diff` and a `:game-headed:compileJava` build gate. All 5 succeeded.

### P12 — `JPanel` field initializers with `JButton`/`JLabel`/`JCheckBoxBuilder` (3차-B verified ★)
**Verified 2026-07-28 3차-B**: Login panel files (LoginPanel, CreateAccountPanel, etc.) extend `JPanel` directly and assign widgets at field declaration time:

```java
private final JButton createAccount =
    new JButton(I18nEngineFramework.get().getText("lobby.LoginPanel.CreateAccount"));
private final JCheckBox rememberPassword =
    new JCheckBoxBuilder(
            I18nEngineFramework.get().getText("lobby.LoginPanel.RememberPassword"))
        .bind(ClientSetting.rememberLoginPassword)
        .build();
```

When converting, the field initializer is the natural patch target — but **`JCheckBoxBuilder` takes the label as the first constructor arg** (not `.label()` setter), while `JButtonBuilder` uses `.title(...)` setter. Read the file first to confirm the builder's API — patching the wrong call signature causes a compile error from a missing argument.

**Verification**: after every field-initializer patch, run the **compile gate** before moving to the next file. Field initializers depend on imports — `I18nEngineFramework` must be imported. A missing import breaks ALL field initializers in the file at once. Always include the import add in the same patch (or `write_file` rewrite) as the field changes.

### P13 — `AbstractAction` extends for in-game actions (3차-B verified ★)
**Verified 2026-07-28 3차-B**: `FindTerritoryAction.java` extends `AbstractAction` directly:

```java
public FindTerritoryAction(final TripleAFrame frame) {
  super(I18nEngineFramework.get().getText("ingame.TripleAFrame.FindTerritory"));
  this.frame = checkNotNull(frame);
}
```

Before D3, only `JMenuBuilder` and `SwingAction.of(...)` patterns were documented. `AbstractAction` extends shows up in `game-headed/.../ui/` (in-game actions) — search for `extends AbstractAction` whenever it's hard to find a menubar/lobby pattern match.

**Pitfall**: `super(String)` calls in `AbstractAction` subclasses are easy to miss because they're in the constructor body, not a method call. The grep pattern should be `extends AbstractAction` first, then `super(...)` calls inside the matching file.

### P14 — Delegate `startEvent` strings are NOT in scope for i18n (3차-C verified ★)
**Verified 2026-07-28 3차-C**: TripleA delegate packages call `bridge.getHistoryWriter().startEvent("English text")` ~75 times across `MoveDelegate`, `BattleDelegate`, `InitializationDelegate`, `BattleTracker`, `PoliticsDelegate`, `EndRoundDelegate`, `TriggerAttachment`, `RandomStartDelegate`, `TwoIfBySeaEndTurnDelegate`, `AirBattle`, `ServerGame`. These strings are stored in `HistoryNode.title` and serialized to:

1. **Save-game files** — Java `ObjectOutputStream` writes `HistoryNode.title` as-is. Replacing with `I18nEngineFramework.get().getText(...)` still serializes the resolved string, breaking save compatibility.
2. **Network protocol** — `@RemoteActionCode` annotated methods exchange `HistoryNode` over the wire. Translated titles break deserialization on the other end.

TripleA's `AGENTS.md` is explicit: "Save-game compatibility: Do NOT rename or delete private fields of classes extending GameDataComponent". The same logic applies to title text.

**Decision rule**: At a Java Swing fork, **delegate `startEvent` strings stay English forever**. Map them in user-visible menus/dialogs (where they enter the UI as a separate lookup) but leave the delegate-side call untouched. This is a **class-level trade-off**, not a work item. Documenting it up front prevents future sessions from re-trying to fix what cannot be fixed.

**Workaround scope** (when the user truly wants delegate strings translated): a separate "history log formatter" maps the English title to a Korean label at *display time* (in `HistoryLog.appendRenderedHistory` or equivalent) — keeping the underlying `HistoryNode.title` English. This is a one-time formatter pass, not a per-call lookup.

**Out of scope entirely**:
- Map XML data (country names, unit names, territory names) — these come from `triplea-maps/*` repos, not the engine. Translating them requires a separate i18n overlay scheme that the engine does not support.
- `ForgotPasswordConversation` NIO server responses — these are protocol strings exchanged with the network client, not UI labels.

## Worker orchestration (no Kanban, direct subagent dispatch) ★
**Updated 2026-07-28**: User feedback — "칸반 작업의 만족도가 낮음. 칸반을 사용하지 말고, 필요하면 서브에이전트를 생성해서 직접 오케스트레이션하도록." Kanban dispatchers add overhead for small i18n batches; direct `delegate_task` works better.

**Workflow**:
1. **Human** measures scope with `grep` (P5) and identifies priority files.
2. **Human** hand-edits 1 file as the **proven template** — builds, tests, ResourceBundle probe, all pass.
3. **Human** dispatches `delegate_task` to **one worker** with the verified pattern + JAVA_HOME export (P2) + utf-8 check (P3) + per-file build gate.
4. **Worker** processes N files, must stop and report if any single file fails to build.
5. **Human** runs the **5-step verification gauntlet** (not optional):
   - `git diff` per file — P6/P7 audit
   - `python3` utf-8 check (P3) + dedup script (P8)
   - `comm -23` Java↔properties mismatch check (P9)
   - `./gradlew :game-headed:compileJava :game-core:test --tests I18nResourceBundleTest` (build gate)
   - ResourceBundle smoke probe (Step 5 above)
6. **Human** commits. Worker never commits.

**Why human verifies**: Workers frequently report "BUILD SUCCESSFUL" while silently introducing:
- Regressions (P6 — added lines)
- Missing logic (P7 — patch deleted a branch)
- Wasted bytes (P8 — duplicate keys)
- Dead refs (P9 — key names diverged)

The pattern of "worker does N files → human verifies all of them → human commits" is the only known-working shape as of TripleA D2. Workers are not yet trustworthy for the verification step itself.

### Worker escape: bulk login-panel batch (3차-B verified ★)
When 5+ files share a tight key namespace (e.g. all 5 login panels share `lobby.LoginPanel.*`), **`write_file` the entire files instead of `patch`**. The login panel batch was 5 files × ~300 lines each, all touching the same key namespace — `patch` mid-flight started failing (P11), and `write_file` rewrites were faster than 5 retry cycles. Verification:

```bash
git diff <file>          # confirm only intended lines changed
./gradlew :game-headed:compileJava   # full compile gate
```

## Subagent prompt template

When delegating multi-file i18n extension, include in the worker prompt:
- Verified pattern block (above)
- JAVA_HOME export block (P2)
- utf-8 verification command (P3)
- Build-gate rule: "**빌드 실패 시 다음 파일 진행 금지** — 한 파일이라도 깨지면 멈추고 보고"
- "fabricate 금지 / OK 예감 표현 금지 / 실제 측정값만 보고"
- Final commit stays with the human: "커밋 안 함 (커밋은 사람 손으로)"
- Summary line: `SUMMARY: <processed>/<total>/<BUILD SUCCESSFUL|FAILED>/<utf8 broken lines>`

A full template lives at `templates/subagent-prompt.md`.

## TripleA-specific quick reference

- Base bundle: `game-app/game-core/src/main/resources/i18n/games/strategy/engine/framework/ui.properties` (+ `_de`, `_ko`)
- Locale registration: `I18nResourceBundle.java` — `mapSupportedLocales`, `getSupportedLanguages`, `computeLocale`
- Swing menus: `game-app/game-headed/src/main/java/games/strategy/triplea/ui/menubar/`
- Swing helpers: `lib/swing-lib/src/main/java/org/triplea/swing/JMenuBuilder.java`
- Test: `game-app/game-core/src/test/java/games/strategy/engine/framework/I18nResourceBundleTest.java`
- Fork remote: `sigco3111/triplea-kr` (origin), `triplea-game/triplea` (upstream)
- Login panels: `game-app/game-headed/src/main/java/games/strategy/engine/lobby/client/login/`

## Files
- `templates/subagent-prompt.md` — full worker dispatch prompt for multi-file menu i18n extension.
- `references/lobby-client-i18n.md` — lobby client UI i18n extension (TripleA D3, 2026-07-28). Patterns for `LobbyFrame`, `LobbyGamePanel`, `JDialogBuilder.title()`, `JTableBuilder.columnNames()`, multi-arg format strings, and pre-staging properties before worker dispatch.
- `references/tripleaframe-i18n.md` — TripleAFrame.java i18n extension (TripleA D4-A, 2026-07-28). The main in-game frame: tabs, JFrame title, drawString status overlay, bombing/scramble/suicide/rocket dialogs, conditional ternary buttons, and political-dialog suffix decomposition. Includes a tool-call-budget pitfall unique to mixing Java-patch and properties-add in the same session.
- `references/lobby-login-panels-i18n.md` — lobby login/account dialogs (TripleA 3차-B, 2026-07-28). The 5 `JPanel`-subclass login panels: `Util.getBanner(String)` image lookup, field-initializer i18n patterns, JOptionPane msg+title both keys, multi-key validator `Optional<String>`, `AbstractAction` super-call pattern, and the patch-tool failure escape hatch (P11 + write_file rewrite).
