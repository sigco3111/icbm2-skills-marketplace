# Lobby Client UI i18n (TripleA D3, 2026-07-28)

Verified pattern for extending i18n coverage to the **lobby client UI** files (`game-app/game-headed/src/main/java/games/strategy/engine/lobby/client/`). Builds on the menubar pattern (D2) but has new wrinkles.

## Trigger

When the prompt asks to convert hardcoded English string literals in `engine/lobby/client/ui/...` files — `LobbyFrame`, `LobbyGamePanel`, `LobbyGameTableModel`, `ReconnectOverlay`, `ActionConfirmation`, `ActionDurationDialog`, `BanPlayerModeratorAction`, `MutePlayerAction`, `ShowPlayersAction`, `DisconnectPlayerModeratorAction`, `PlayerInformationPopup`, `PlayerAliasesTab`, `PlayerBansTab`, `PlayerGamesTab`, `PlayerInfoSummaryTextArea`, `ShowPlayerInformationAction` — to `I18nEngineFramework.get().getText(...)`.

## Key namespace difference

Menubar uses `menubar.<FileMenu>.<Widget>` prefix. Lobby client UI uses **`lobby.<FilePascalCase>.<Widget>`** prefix. Never mix the two namespaces; menubar keys live in the same properties bundle (`ui.properties` family) but the prefix differentiates them.

Examples verified in D3:
- `lobby.LobbyFrame.Title=TripleA Lobby`
- `lobby.LobbyGamePanel.HostGame=Host Game`
- `lobby.ReconnectOverlay.DisconnectAndExit=Disconnect & Exit`
- `lobby.BanPlayerModeratorAction.ConfirmMsg=Are you sure you want to ban %s for %s`

## Patterns specific to lobby UI (NOT in menubar skill)

### 1. `JFrame` super-call title (LobbyFrame)
`public LobbyFrame(...) { super("TripleA Lobby"); }` — the title string is the first constructor arg. Replace inside the super-call (not via a setter):

```java
super(I18nEngineFramework.get().getText("lobby.LobbyFrame.Title"));
```

### 2. Swing toolbar `JButton` (LobbyGamePanel lines 54–55)
`new JButton("Host Game")` for the toolbar — same as menubar buttons. Wrap on a separate line if it exceeds Google Java Format column limit (the default formatter will reflow, but a hand-broken multi-line read better in diffs):

```java
final JButton hostGameButton =
    new JButton(I18nEngineFramework.get().getText("lobby.LobbyGamePanel.HostGame"));
joinGameButton = new JButton(I18nEngineFramework.get().getText("lobby.LobbyGamePanel.JoinGame"));
```

### 3. `SwingAction.of(...)` popup-menu items (LobbyGamePanel lines 216–217, 232–233)
Right-click popup menu actions are built with `SwingAction.of("Label", () -> handler)`. Same fix as menubar — wrap label with `getText(...)`. Patches of multiple `SwingAction.of` in a `List.of(...)` should target **one call at a time** for safe patch uniqueness (whole-block patches have failed match if any whitespace differs).

### 4. `JOptionPane.showConfirmDialog` — msg AND title both (bootGame, shutdownGame)
```java
JOptionPane.showConfirmDialog(null,
    "Are you sure you want to disconnect the selected game?",
    "Remove Game From Lobby",
    JOptionPane.OK_CANCEL_OPTION);
```
Both msg and title get separate keys: `RemoveGameMsg` and `RemoveGameTitle`. **Do NOT** collapse the whole dialog into a single key — the msg has a `%s` placeholder for player name in some actions (`BanPlayerModeratorAction`) and reusing the same key for different formats is wrong.

### 5. `JOptionPane.showMessageDialog` — single-arg msg (success info dialogs)
`JOptionPane.showMessageDialog(parent, "The game you selected has been disconnected from the lobby.")` — the single string is the msg body. No title to worry about. Key: `RemovedMsg`.

### 6. `JButtonBuilder("...")` and `JLabelBuilder.text("...")` (ActionDurationDialog)
TripleA's swing-lib builders take title/text as a String. Replace the first/labeled arg:
```java
new JButtonBuilder().title("OK")  →  new JButtonBuilder().title(I18nEngineFramework.get().getText("lobby.ActionDurationDialog.Ok"))
JLabelBuilder.builder().text("Select duration to " + actionName.label)
                  .text(I18nEngineFramework.get().getText("lobby.ActionDurationDialog.SelectDurationTo") + actionName.label)
```

### 7. `SwingComponents.promptUser(title, msg, runnable)` (BanPlayerModeratorAction, MutePlayerAction)
Title and msg are **both** user-visible. Use distinct keys: `ConfirmTitle`, `ConfirmMsg`. The msg is a format string with `%s`:
```java
"Are you sure you want to ban " + playerName + " for " + timespan
  →  I18nEngineFramework.get().getText("lobby.BanPlayerModeratorAction.ConfirmMsg")
        .formatted(playerName, timespan)
```
Or use String.format: `"...%s...%s...".formatted(...)`. Both produce the same outcome.

### 8. `JDialogBuilder.title("...")` (ReconnectOverlay, ShowPlayersAction, PlayerInformationPopup)
Dialog title uses `.title(...)` setter. Title may include a `%s` (player name) — keep it as a single format-string key:
```java
.title("Player: " + playerName.getValue())
.title(I18nEngineFramework.get().getText("lobby.PlayerInformationPopup.Title").formatted(playerName.getValue()))
```
**Pitfall**: do not split into a prefix key + concat — that prevents translators from reordering words.

### 9. Format strings inside the `properties` file
Keys with placeholders use Java's `%s`, `%d`, `%(name)s` syntax. The bundle calls `String.format(...)` under the hood. Verify with:
```bash
grep -E "%[sd]|%[0-9]+\$" ui.properties | head -20
```
For multi-arg format strings (e.g. `BanPlayerModeratorAction.ConfirmMsg=Are you sure you want to ban %s for %s`), the order of args in the Java `.formatted(a, b)` call must match the property placeholders — translator cannot reorder.

### 10. `JTableBuilder.columnNames("Name", "Last Date Used", "IP", "System ID")` (PlayerAliasesTab, PlayerBansTab)
The `columnNames(...)` varargs is a single call — patching it requires the **full literal list** in `old_string` to match uniquely. Replace each English header with a key reference:
```java
.columnNames(
    I18nEngineFramework.get().getText("lobby.PlayerAliasesTab.Name"),
    I18nEngineFramework.get().getText("lobby.PlayerAliasesTab.LastDateUsed"),
    I18nEngineFramework.get().getText("lobby.PlayerAliasesTab.Ip"),
    I18nEngineFramework.get().getText("lobby.PlayerAliasesTab.SystemId"))
```
Even if `Name` is identical across Aliases and Bans tabs (and possibly other places), keep them as **separate keys** (`PlayerAliasesTab.Name`, `PlayerBansTab.Name`). Translators may need different terms (German `Name` vs `Alias`) and a shared key blocks that.

### 11. String literals inside an exception/default branch (LobbyGameTableModel)
`switch (column) { ... default -> throw new IllegalStateException("Unknown column: " + column); }` — even error messages should be localized:
```java
default -> throw new IllegalStateException(
    I18nEngineFramework.get().getText("lobby.LobbyGameTableModel.UnknownColumn").formatted(column));
```
Pitfall: in a default/throw branch, the exception now depends on `I18nEngineFramework.get()` — if the bundle is missing the key, the throw itself fails with a different error. Keep a defensive fallback OR ensure the key is verified in the smoke probe.

## Multi-arg `String.format` ordering gotcha

When a property key has multiple placeholders (`%s %s`), translator may not preserve the order. Java's `String.format` and `.formatted` use **positional** indexing — `%1$s %2$s`. If translators swap, the swap propagates to runtime. Use named indices if you want reorder-safety:
```
lobby.X.Y=Please confirm %2$s for %1$s
```
Then `.formatted(playerName, timespan)`. Verify each format-string key in the smoke probe by calling `.formatted(...)` with a fixture and inspecting the output.

## Pre-add all properties keys before patching Java

Verified D3 sequence (faster and dedup-safe than incremental add-per-file):
1. List all keys you'll need across all 12+ files (one Python dict).
2. Write `ui.properties` (English) first — source of truth for keys and ordering.
3. Write `ui_de.properties` (UTF-8 raw text).
4. Write `ui_ko.properties` (`\uXXXX` escapes).
5. Verify: `python3 -c "for f in [...]: open(f,'rb').read().decode('utf-8')"` — must succeed.
6. Verify dedup: `comm -23 <(grep '^lobby\.' ui.properties|sort -u) <(grep '^lobby\.' ui_ko.properties|sort -u)` must be empty.
7. **Then** patch Java files one by one with build gate between each.

This sequence avoids the worker-mid-run "what key should this be?" decision fatigue and lets the smoke probe cover the full key set before any Java changes.

## Build gate per file

D3 sequence for each Java file:
1. Patch the file (one `old_string` → `new_string` per change).
2. Run `./gradlew :game-headed:compileJava --console=plain 2>&1 | tail -20`.
3. If `BUILD FAILED` → revert that file's patch with `git checkout <file>` and stop. Do NOT proceed to next file.
4. If `BUILD SUCCESSFUL` → proceed to next file.

Compile-only is faster than `test` (5–10s vs 30s+). Run the full `:game-core:test --tests I18nResourceBundleTest` only at the **end** of all 12 files.

## Keys D3 added (53 total)

Reference for any future session that extends lobby i18n — these keys already exist in the bundle, do not recreate:

- LobbyFrame: Title
- LobbyGamePanel: HostGame, JoinGame, BootGame, Shutdown, RemoveGameTitle, RemoveGameMsg, RemovedMsg, SendShutdownTitle, SendShutdownMsg, ShutdownSignalSentMsg
- LobbyGameTableModel: Available, UnknownColumn
- ReconnectOverlay: DisconnectAndExit, Title, ReconnectingMsg
- ActionConfirmation: Title
- ActionDurationDialog: Title, SelectDurationTo, Ok, Cancel
- BanPlayerModeratorAction: BanPlayer, ConfirmTitle, ConfirmMsg, SuccessTitle, SuccessMsg
- MutePlayerAction: MutePlayer, ConfirmTitle, ConfirmMsg
- ShowPlayersAction: ShowPlayers, PlayersInGameTitle, Close
- DisconnectPlayerModeratorAction: Label, ConfirmMsg
- PlayerInfoSummaryTextArea: NotRegistered, RegisteredOn, Ip, SystemId
- PlayerInformationPopup: Title, Close
- PlayerAliasesTab: Title, Name, LastDateUsed, Ip, SystemId
- PlayerBansTab: Title, Name, DateBanned, BanExpiry, Ip, SystemId
- PlayerGamesTab: Title
- ShowPlayerInformationAction: ShowInfo

## Worker limit warning (D3 learning)

**Verified 2026-07-28**: worker dispatched directly (no Kanban) on D3 hit the **tool-call iteration cap** mid-flight after processing LobbyFrame + 3 of LobbyGamePanel patches. Lesson: for 12+ file batches with this many string literals, pre-stage ALL properties keys in one Python heredoc, then either:
(a) split the worker batch into 2 sessions (6 files each), or
(b) **pre-stage properties BEFORE delegating to worker** — the worker only needs to do Java patches + per-file build verification, which fits comfortably in the budget.

When delegating, give the worker the **complete key list** in the prompt so it never has to design keys (which is what bloats tool calls).

## Subagent prompt template for D3-style work

```
... (verified pattern block) ...
... (JAVA_HOME export block) ...
... (utf-8 verification command) ...

KEY LIST (already added to all 3 properties files — DO NOT re-add):
lobby.LobbyFrame.Title=TripleA Lobby
lobby.LobbyGamePanel.HostGame=Host Game
... (full list) ...

FILES TO PATCH (per-file build gate between each):
- LobbyFrame.java
- LobbyGamePanel.java
... (12 files) ...

If tool-call budget runs out, stop after the last successful patch and report.
The human will resume from where you stopped.

Do NOT commit.
```

This skill section is the **lobby-client-specific extension** to the umbrella `java-swing-i18n-extension`. Read that skill first for the base pattern (P1–P10 pitfalls, encoding rules, build verification), then read this file for the lobby-specific patterns.
