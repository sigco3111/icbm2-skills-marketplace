# TripleAFrame i18n (TripleA D4-A, 2026-07-28)

Verified pattern for extending i18n coverage to **TripleAFrame.java** — the single biggest non-menus file in `game-app/game-headed/src/main/java/games/strategy/triplea/ui/`. This is the main in-game frame (2124 lines, 50+ hardcoded English strings). Builds on the menubar (D2) and lobby (D3) patterns but introduces several new classes of widgets that don't appear in menus.

## Trigger

When the prompt asks to convert hardcoded English in `TripleAFrame.java` to `I18nEngineFramework.get().getText(...)`. Also reusable for any other large Swing frame with mixed tab/button/dialog/format-string content.

## Key namespace

`ingame.TripleAFrame.<Widget>` — distinct from `menubar.*` and `lobby.*`. The triple-A umbrella skill's verification commands (`comm -23`) must filter on the right prefix to avoid false mismatches.

## Widget classes specific to TripleAFrame (not in menubar/lobby skills)

### 1. `JTabbedPane.addTab(String title, ...)` and `JTabbedPane.add(String title, ...)`
Tab titles are passed as the first arg. The `addTab(String, Component, KeyCode)` private helper accepts a hotkey — the **3-arg `addTab` is called with the title as a string literal at call sites**, replace at call sites:

```java
// 1. tabsPanel.add("History", ...) — older add() form, distinct from addTab(...)
tabsPanel.add(
    I18nEngineFramework.get().getText("ingame.TripleAFrame.TabHistory"),
    historyDetailPanel);

// 2. addTab(...) private helper — first arg
addTab(I18nEngineFramework.get().getText("ingame.TripleAFrame.TabActions"),
       actionButtonsPanel, KeyCode.C);
```

Each tab gets its own key — `TabHistory`, `TabActions`, `TabPlayers`, `TabTechnology`, `TabResources`, `TabTerritory`, plus `Edit` for edit mode. Never share a "Tab" key across tabs.

### 2. `super(String)` JFrame title with concatenation
TripleAFrame extends `JFrame`, and the constructor calls `super("TripleA - " + game.getData().getGameName())`. Replace the **prefix only**, keep the dynamic concat:

```java
super(
    I18nEngineFramework.get().getText("ingame.TripleAFrame.TitlePrefix")
        + game.getData().getGameName());
```

Key is `TitlePrefix`. Do not split into prefix + suffix — translators need freedom to reorder the game name.

### 3. `Graphics.drawString(String, int, int)` — status panel overlay
Edit-mode watermark `g.drawString("Edit Mode", x, y)` inside `paintComponent`. Same fix — wrap the literal with `getText(...)`:

```java
g.drawString(
    I18nEngineFramework.get().getText("ingame.TripleAFrame.EditMode"),
    (int) ((size.getWidth() - 200) / 2),
    (int) ((size.getHeight() - 100) / 2));
```

### 4. `EventThreadJOptionPane.showConfirmDialog` with Yes/No title (Exit Program / Leave Game)
The msg is a multi-line English string with `\n`. Title is a short literal that DOES get a key:

```java
EventThreadJOptionPane.showConfirmDialog(
    this,
    "Are you sure you want to exit TripleA?\nUnsaved game data will be lost.",
    I18nEngineFramework.get().getText("ingame.TripleAFrame.ExitProgram"),
    ConfirmDialogType.YES_NO);
```

Leave the msg alone (it's a runtime UX message that may already be elsewhere) OR wrap it too — depends on prompt scope. Keys: `ExitProgram`, `LeaveGame`.

### 5. `JOptionPane.showMessageDialog(parent, msg, "Error", ERROR_MESSAGE)` — error dialog
The hardcoded `"Error"` is a JOptionPane title. Replace only the title:

```java
showMessageDialogOffEdt(
    displayMessage,
    I18nEngineFramework.get().getText("ingame.TripleAFrame.ErrorTitle"),
    JOptionPane.ERROR_MESSAGE);
```

### 6. Strategic bombing raid — branching ternary on properties
The `Properties.getRaidsMayBePreceededByAirBattles(data.getProperties())` ternary is INSIDE a string concat for the message and a separate var for the bomb option. The original code is:

```java
final String message = (Properties.getRaidsMayBePreceededByAirBattles(...) ? "Bomb/Escort" : "Bomb") + " in " + location.getName();
final String bomb = (Properties.getRaidsMayBePreceededByAirBattles(...) ? "Bomb/Escort" : "Bomb");
final String normal = "Attack";
```

The fix has TWO ternary uses — they MUST share keys. Replace the whole ternary block (do not patch each ternary separately, fuzzy match will collide on similar code):

```java
final String message =
    (Properties.getRaidsMayBePreceededByAirBattles(data.getProperties())
            ? I18nEngineFramework.get().getText("ingame.TripleAFrame.BombEscort")
            : I18nEngineFramework.get().getText("ingame.TripleAFrame.Bomb"))
        + " in "
        + location.getName();
final String bomb =
    Properties.getRaidsMayBePreceededByAirBattles(data.getProperties())
        ? I18nEngineFramework.get().getText("ingame.TripleAFrame.BombEscort")
        : I18nEngineFramework.get().getText("ingame.TripleAFrame.Bomb");
final String normal = I18nEngineFramework.get().getText("ingame.TripleAFrame.Attack");
```

Keys: `BombEscort`, `Bomb`, `Attack`, `BombTitle` (the JOptionPane title at the bottom).

### 7. Format-string prefix concat (3 patterns)

TripleAFrame has many `"...some text..." + territory.getName()` patterns. Use `.MsgPrefix` suffix keys for the prefix:

| Pattern | Key |
|---|---|
| `"Select bombing target in " + territory.getName()` | `SelectBombingTargetMsgPrefix` |
| `"For Units: " + MyFormatter.unitsToTextNoOwner(bombers)` | `ForUnitsLabel` (the trailing space is part of the value) |
| `"Scramble To: " + scrambleTo.getName()` | `ScrambleToLabel` |
| `"From: " + from.getName()` | `FromLabel` (shared between scramble and air-battle panel) |
| `"Targets for rocket in " + from.getName()` | `RocketTargetMsgPrefix` |
| `"Select units to scramble to " + scrambleTo.getName()` | `SelectScrambleTitlePrefix` (used as JDialog title) |
| `"Select units to Suicide Attack using " + attackResourceToken.getName()` (×2 — JDialog title AND JLabel panel text) | `SelectSuicideAttackTitlePrefix`, `SelectSuicideAttackMsgPrefix` |
| `"Units in the following territories will die: " + ...` (joined with " " separator) | `UnitsDieMsgPrefix` |

**Pitfall**: trailing space is part of the key value. `"For Units: "` ends with a space — keep it that way in the properties file. Translators handle the spacing per language.

**Pitfall**: shared `FromLabel` between scramble and air-battle panel — both render the same English "From: X". Keep one key for now; if a future session needs to differentiate (e.g. "출발 공항" vs "출발 지역"), split into `ScrambleFromLabel` and `AirBattleFromLabel`.

### 8. Conditional ternary for ok/cancel buttons (movePhase ? "End Move Phase" : "Kill Planes")
Air-cannot-land dialog has phase-dependent button labels:

```java
final String ok =
    movePhase
        ? I18nEngineFramework.get().getText("ingame.TripleAFrame.EndMovePhase")
        : I18nEngineFramework.get().getText("ingame.TripleAFrame.KillPlanes");
final String cancel =
    movePhase
        ? I18nEngineFramework.get().getText("ingame.TripleAFrame.KeepMoving")
        : I18nEngineFramework.get().getText("ingame.TripleAFrame.ChangePlacement");
```

Keys: `EndMovePhase`, `KillPlanes`, `KeepMoving` (shared with units-cannot-fight), `ChangePlacement`, `AirCannotLandTitle` (the JOptionPane title).

### 9. Conditional suffix for political dialog (politics ? "Political " : "")
"Accept ... Proposal from ... ?" — the original is `"Accept " + (politics ? "Political " : "") + "Proposal from " + name + "?"`. Decompose into 4 keys to preserve translator flexibility:

```java
return EventThreadJOptionPane.showConfirmDialog(
    this,
    acceptanceQuestion,
    I18nEngineFramework.get().getText("ingame.TripleAFrame.AcceptPrefix")
        + (politics
            ? I18nEngineFramework.get().getText("ingame.TripleAFrame.AcceptPoliticalSuffix")
            : I18nEngineFramework.get().getText("ingame.TripleAFrame.AcceptProposalSuffix"))
        + playerSendingProposal.getName()
        + I18nEngineFramework.get().getText("ingame.TripleAFrame.AcceptSuffix"),
    ConfirmDialogType.YES_NO);
```

Keys: `AcceptPrefix` = `"Accept "`, `AcceptPoliticalSuffix` = `"Political "`, `AcceptProposalSuffix` = `""` (empty for non-political), `AcceptSuffix` = `" from " ... "?"`. German may want `"Annehmen: Politischer Vorschlag von %s?"` — keep separate keys so they can re-glue without code change.

### 10. Common dialog buttons (OK / Cancel / Don't attack / Select / None)
These are reused across many dialogs (getStrategicBombingRaidTarget, getRocketAttack, notifyTechResults, suicide attack, scramble). Same key works because translators will reuse the same translation everywhere:

```java
final String[] options = {
    I18nEngineFramework.get().getText("ingame.TripleAFrame.OK"),
    I18nEngineFramework.get().getText("ingame.TripleAFrame.Cancel")
};
```

Keys: `OK`, `Cancel`, `DontAttack` ("Don't attack"), `Select`, `None`.

**Note**: `OK` and `Cancel` are <10 chars — I18nResourceBundleTest (P9 in umbrella) won't enforce non-English translation. Verify visually after deployment.

## Strings NOT touched (out of scope for D4-A batch)

When tool-call budget runs out (this session), leave these for D4-B:
- History popup menu items: `Show Summary Log`, `Show Detailed Log`, `Export Gameboard Picture`, `Save Game at this point (BETA)` (lines 1860–1870)
- `Save Game from History` dialog title (line 1887)
- `Game Saved` message + title (line 1931–1932)
- `"Edit"` tab title (line 1821, distinct from TabHistory/TabActions/...)
- `"Select territory for air units to land, current territory is " + ...` (line 1104)
- `"Move air units to carrier"` (line 2079)
- `new String[] {"OK", "Cancel"}` in moveFightersToCarrierOffEdt (line 2083)

These are real i18n gaps but the D4-A batch ran out of tool-call budget mid-batch. D4-B should pick up here.

## Tool-call budget pitfall (TripleAFrame-specific)

**Verified D4-A (2026-07-28)**: D4-A's budget cap was hit AFTER completing ~50+ string patches across TripleAFrame.java but BEFORE adding the corresponding properties keys. Result: code compiles (Java doesn't validate keys at compile time) but runtime will throw `MissingResourceException` for every dialog the user opens.

**D3 already documented this lesson**: "If tool-call budget runs out, stop after the last successful patch and report." D4-A confirms the same lesson from a different angle — the difference is that D3 had a stage-ordered workflow (properties first, then Java patches) that D4-A didn't have because properties weren't pre-staged.

**Defensive pattern for future TripleA frame sessions**:

1. **Pre-stage ALL properties keys** in one Python heredoc (Python won't count against tool-call budget in the same way). 50 keys × 3 locales = 150 lines, all in one go.
2. **Verify dedup + utf-8 + comm** BEFORE any Java patches.
3. THEN dispatch the worker (or do it yourself) for Java patches.
4. Properties adds cost ~1 tool call. Java patches cost ~1 tool call each.

If you only have N tool calls left, **allocate the FIRST one to properties staging** — a single `write_file` that adds all 50 keys to all 3 files is recoverable; 50 Java patches without keys is not.

## Verified keys added in D4-A (45 total — partial; 8 more for D4-B)

| Key | English |
|---|---|
| `TitlePrefix` | `TripleA - ` |
| `ShowHistory` | `Show history` |
| `ShowCurrentGame` | `Show current game` |
| `EditMode` | `Edit Mode` |
| `TabHistory` | `History` |
| `TabActions` | `Actions` |
| `TabPlayers` | `Players` |
| `TabTechnology` | `Technology` |
| `TabResources` | `Resources` |
| `TabTerritory` | `Territory` |
| `ExitProgram` | `Exit Program` |
| `LeaveGame` | `Leave Game` |
| `ErrorTitle` | `Error` |
| `BombEscort` | `Bomb/Escort` |
| `Bomb` | `Bomb` |
| `Attack` | `Attack` |
| `BombTitle` | `Bomb?` |
| `SelectBombingTargetMsgPrefix` | `Select bombing target in ` |
| `ForUnitsLabel` | `For Units: ` |
| `SelectSuicideAttackMsgPrefix` | `Select Units to Suicide Attack using ` |
| `SelectSuicideAttackTitlePrefix` | `Select units to Suicide Attack using ` |
| `SelectScrambleTitlePrefix` | `Select units to scramble to ` |
| `ScrambleToLabel` | `Scramble To: ` |
| `Scramble` | `Scramble` |
| `FromLabel` | `From: ` |
| `Select` | `Select` |
| `None` | `None` |
| `EndMovePhase` | `End Move Phase` |
| `KillPlanes` | `Kill Planes` |
| `KeepMoving` | `Keep Moving` |
| `ChangePlacement` | `Change Placement` |
| `AirCannotLandTitle` | `Air cannot land` |
| `UnitsDieMsgPrefix` | `Units in the following territories will die: ` |
| `DoneMoving` | `Done Moving` |
| `UnitsCannotFightTitle` | `Units cannot fight` |
| `AcceptPrefix` | `Accept ` |
| `AcceptPoliticalSuffix` | `Political ` |
| `AcceptProposalSuffix` | `` (empty) |
| `AcceptSuffix` | ` from ` ... `?` (keep in one key, not split) |
| `RocketTargetMsgPrefix` | `Targets for rocket in ` |
| `SelectRocketTarget` | `Select Rocket Target` |
| `DontAttack` | `Don't attack` |
| `TechRoll` | `Tech roll` |
| `OK` | `OK` |
| `Cancel` | `Cancel` |

Note: `AcceptSuffix` should be one key with ` from ` + `?` glued — splitting loses translator flexibility. German translator can write `" von %s annehmen?"` in one key.

This skill section is the **TripleAFrame-specific extension** to the umbrella `java-swing-i18n-extension`. Read that skill first for the base pattern (P1–P10 pitfalls, encoding rules, build verification), then read this file for the frame-specific patterns.