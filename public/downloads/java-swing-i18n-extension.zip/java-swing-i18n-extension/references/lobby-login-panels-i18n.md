# Lobby Login Panels i18n (TripleA 3차-B, 2026-07-28)

Verified pattern for extending i18n coverage to the **5 lobby login/account dialog panels** in `game-app/game-headed/src/main/java/games/strategy/engine/lobby/client/login/`. These are distinct from the D3 lobby content (LobbyFrame, LobbyGamePanel, etc.) — the login panels are **standalone `JPanel` subclasses embedded into `JDialog`**, with their own widget idioms.

## Trigger

When the prompt asks to convert hardcoded English in any of these 5 files:
- `LoginPanel.java` — login screen (Username/Password/Remember Me/anonymous)
- `ChangeEmailPanel.java` — change email dialog
- `ChangePasswordPanel.java` — change password dialog (with live validation)
- `ForgotPasswordPanel.java` — "reset password" request dialog
- `CreateAccountPanel.java` — new account signup with multi-field validation

These extend `JPanel` directly (not `JFrame`). Each is a **modal `JDialog` host** that adds the panel to its content pane.

## Patterns specific to login panels (NOT in D3 lobby skill)

### 1. `JPanel` subclass constructor — `Util.getBanner(String)` image lookup

Each panel uses `Util.getBanner(title)` to display a header image whose filename is derived from the title. The title string is therefore a user-visible identity. Wrap with `I18nEngineFramework.get().getText(...)`:

```java
final JLabel label =
    new JLabel(
        new ImageIcon(
            Util.getBanner(
                I18nEngineFramework.get().getText("lobby.LoginPanel.BannerLogin"))));
```

Keys: `BannerLogin`, `ChangeEmailBanner`, `ChangePasswordBanner`, `CreateAccountBanner`, `ForgotPasswordBanner`. Translators can rename the banner image set per language if they need to — the key is the contract.

**Pitfall**: the banner key is **only used for the image lookup**, not displayed as text. A user with `<10` char banner would not trigger the I18nResourceBundleTest's enforce-translation check — but the bundle still needs the key (or the image won't load). Verify visually by checking the banner image actually renders.

### 2. `JButton("...")`, `JLabel("...")` field-assigned at declaration

Most fields are initialized at declaration (not in the constructor) to keep the constructor body short. Patch the field initializer directly:

```java
private final JButton createAccount =
    new JButton(I18nEngineFramework.get().getText("lobby.LoginPanel.CreateAccount"));
private final JLabel passwordLabel =
    new JLabel(I18nEngineFramework.get().getText("lobby.LoginPanel.PasswordLabel"));
```

**Pitfall**: `JCheckBoxBuilder(String)` and `JButtonBuilder(String).title(...)` are the same pattern but live in `org.triplea.swing`. Different field initializer grammars — do not mix them. Read the file first to confirm the builder being used.

### 3. `JOptionPane.showMessageDialog(parent, msg, title, type)` with both msg AND title as keys

```java
JOptionPane.showMessageDialog(
    this,
    I18nEngineFramework.get().getText("lobby.LoginPanel.NoPasswordMsg"),
    I18nEngineFramework.get().getText("lobby.LoginPanel.NoPasswordTitle"),
    JOptionPane.ERROR_MESSAGE);
```

Both msg and title get **separate keys** even when they're closely related (`NoPasswordMsg` + `NoPasswordTitle`). Same rule as D3 bootGame/shutdownGame — translators may need different wording for the title word ("오류" vs "비밀번호 없음") and reusing one key blocks that.

### 4. `String.format` with the i18n key as the first arg

Pattern for parameterised messages:

```java
String.format(
    I18nEngineFramework.get().getText("lobby.LoginPanel.PasswordTooShortMsg"),
    LobbyConstants.PASSWORD_MIN_LENGTH)
```

The property value is `Passwords must be at least %s characters long`. Korean uses `비밀번호는 적어도 %s자 이상이어야 합니다`. The `%s` placeholder must stay in the same ordinal position — translators can move it but the Java arg order is fixed.

**Pitfall**: if the format string has multiple placeholders, use **named indices** (`%1$s %2$s`) so translators can reorder without breaking the runtime:

```properties
lobby.LoginPanel.PasswordTooShortMsg=Passwords must be at least %1$s characters long
```

### 5. `JCheckBoxBuilder(String).bind(...)` login state

`LoginPanel` checkbox fields bind to `ClientSetting` for persistence:

```java
private final JCheckBox rememberPassword =
    new JCheckBoxBuilder(
            I18nEngineFramework.get().getText("lobby.LoginPanel.RememberPassword"))
        .bind(ClientSetting.rememberLoginPassword)
        .build();
```

Replace the **first** `.label()` / constructor arg — the bind call is a separate fluent step.

### 6. `anonymousLogin.isSelected()` flow toggles other component enabled-states

`LoginPanel.updateComponents()` greys out the password field when anonymous mode is selected. This is **logic, not i18n** — leave it alone. But: the JLabel that says "Password:" is still wrapped with `getText(...)` and gets **disabled via `setEnabled(false)`** when anonymous mode is on. The component stays readable in the bundle lookup but the runtime toggle is correct.

### 7. `ChangePasswordPanel.validatePasswordsAndUpdateValidationText()` — returns boolean AND sets JLabel text

```java
validationLabel.setText(
    I18nEngineFramework.get().getText("lobby.LoginPanel.PasswordsMustMatch"));
```

The label is a child of the same panel; i18n lookup happens at the call site, not in a pre-loaded cache. This is fine — `I18nEngineFramework.get()` is a singleton and lookup is cheap.

### 8. `CreateAccountPanel.validationMessage()` returns `Optional<String>` from MANY keys

The validator picks ONE key based on which check failed:

```java
private Optional<String> validationMessage() {
  if (!Arrays.equals(passwordField.getPassword(), passwordConfirmField.getPassword())) {
    return Optional.of(I18nEngineFramework.get().getText("lobby.LoginPanel.PasswordsMustMatch"));
  } else if (!PlayerEmailValidation.isValid(emailField.getText())) {
    return Optional.of(I18nEngineFramework.get().getText("lobby.LoginPanel.EmailMustBeValid"));
  } else if (!UserName.isValid(usernameField.getText())) {
    return UserName.validate(usernameField.getText());  // returns the validation message
  } else if (emailField.getText().isEmpty()) {
    return Optional.of(I18nEngineFramework.get().getText("lobby.LoginPanel.YouMustEnterEmail"));
  } else if (passwordField.getPassword().length == 0) {
    return Optional.of(I18nEngineFramework.get().getText("lobby.LoginPanel.YouMustEnterPassword"));
  } else if (passwordField.getPassword().length < ACCOUNT_PASSWORD_MIN_LENGTH) {
    return Optional.of(
        String.format(
            I18nEngineFramework.get().getText("lobby.LoginPanel.PasswordTooShortMsg"),
            LobbyConstants.PASSWORD_MIN_LENGTH));
  }
  return Optional.empty();
}
```

**Important**: when the validator's message is conditionally tied to `String.format`, the placeholder count must match the arg count. `PasswordTooShortMsg` has `%s` and gets one int — works. If a Korean translator adds a sentence ("비밀번호가 짧습니다. 최소 %s자 이상이어야 합니다"), the format run still produces one number — fine.

### 9. `Email updated to: ` + newEmail concatenation

`ChangeEmailPanel.submitAction` does:

```java
DialogBuilder.builder()
    .parent(parent)
    .title(I18nEngineFramework.get().getText("lobby.LoginPanel.EmailUpdateSuccessTitle"))
    .infoMessage(
        I18nEngineFramework.get().getText("lobby.LoginPanel.EmailUpdateSuccessMsg")
            + " "
            + newEmail)
    .showDialog();
```

The `EmailUpdateSuccessMsg` value is `Email updated to: ` (with trailing space + colon). The `newEmail` is appended directly to the looked-up value. This is cheaper than a `%s` format string but **locks the position** of the value — translators cannot reorder.

**Alternative**: define `EmailUpdateSuccessMsg=Email updated to: %s` and use `.formatted(newEmail)`. More flexible for translators. Pre-3차-B used this pattern; future cleanup opportunity.

### 10. `AbstractAction(String)` for menu/search actions

`FindTerritoryAction.java` extends `AbstractAction` and uses `super(String)` in the constructor:

```java
public FindTerritoryAction(final TripleAFrame frame) {
  super(I18nEngineFramework.get().getText("ingame.TripleAFrame.FindTerritory"));
  this.frame = checkNotNull(frame);
}
```

Same as `JFrame extends ... super(String)` — the constructor arg is the action's display name. Key: `ingame.TripleAFrame.FindTerritory`. Note the **namespace** — this lives in the `ingame.*` umbrella (not `lobby.*`), because the action is part of the in-game UI, not the lobby.

**Pitfall**: even though `org.triplea.swing.JMenuBuilder` and `SwingAction.of(...)` are the typical lobby/menubar action builders, `AbstractAction` extends directly still happens in the in-game UI (FindTerritoryAction is the only example D3/found so far). Look for it whenever you see `extends AbstractAction` or `super("...")` in `game-headed/.../ui/`.

## TripleAFrame residual strings (3차-B addendum)

D4-A left 8 strings in TripleAFrame unconverted because of tool-call budget. 3차-B picked up 2 of the simpler ones via `sed` (preferred for inline `String` args):

| Line | Original | Key | Korean |
|---|---|---|---|
| 1916 | `"Show Summary Log"` | `ingame.TripleAFrame.ShowSummaryLog` | 요약 기록 보기 |
| 1917 | `"Show Detailed Log"` | `ingame.TripleAFrame.ShowDetailedLog` | 세부 기록 보기 |

```bash
sed -i '' 's|.add("Show Summary Log", () -> showHistoryLog(popupHistoryPanel, false, clonedGameData))|.add(\n                I18nEngineFramework.get().getText("ingame.TripleAFrame.ShowSummaryLog"),\n                () -> showHistoryLog(popupHistoryPanel, false, clonedGameData))|' TripleAFrame.java
```

**Why sed over `patch` here**: `patch` was failing repeatedly with `path required` errors when called in the same session after multiple `write_file` rewrites. Sed is a clean fallback for **single-line arg replacements** that are easy to confirm with `grep`. After sed, verify with `git diff <file>` and `grep -n ShowSummaryLog <file>`.

6 more TripleAFrame strings remain unconverted (lines 1870's history popup items, Save Game from History instructions, Select territory for air units to land, Move air units to carrier, etc.) — pick up next session.

## Patch tool failure pattern (3차-B confirmed ★)

**Verified 2026-07-28 3차-B**: After several `patch` calls with `mode='replace'` succeeded, subsequent calls in the same session **started failing with `path required`** even when `path` was supplied. Console show:

```
error: "path required"
```

Root cause: when the assistant's tool call payload includes `patch` (key) for `mode='replace'`, the tool dispatcher appears to lose the `path` arg. The error didn't reflect the actual state.

**Symptom**: same `mode='replace'` call shape that worked minutes earlier starts failing with `path required`. Single-line, multi-line, and `replace_all=false` all hit the same error.

**Fix**: write the entire file with `write_file`. This is more invasive (overwrites the whole file) but **works reliably** in any state. Verify after by `git diff <file>` to confirm only intended lines changed.

**Defensive playbook** when 2+ consecutive `patch` failures hit:
1. Stop calling `patch`.
2. Read the file in full (`read_file` with no limit).
3. `write_file` with the full updated content.
4. `git diff <file>` to confirm the rewrite only touched the intended lines.

The 3차-B session rewrote 5 login panel files this way (LoginPanel, ChangeEmailPanel, ChangePasswordPanel, ForgotPasswordPanel, CreateAccountPanel) — each verified with `git diff` and a `:game-headed:compileJava` build gate. All 5 succeeded.

## Sequential workspace discipline (3차-B confirmed ★)

The 3차-B lesson overlaps with P11 in the umbrella **but with a key nuance**: pre-stage ALL properties keys in ONE write_file call (not 3 separate `patch` calls), then verify utf-8 + dedup + Java-mismatch (P9) before any Java patch. This is the **lobby-client learning** doubled-down by the 5-file login batch.

**Concrete sequence that worked for 3차-B (5 file batch)**:

1. **Single write_file** drops all 38 new keys into `ui.properties` (English) + `ui_ko.properties` (Korean `\uXXXX`).
2. **Verify**:
   - `python3 -c "for f in [...]: open(f,'rb').read().decode('utf-8')"`
   - `python3 -c "seen=set(); ..."` dedup script
   - key count parity: `wc -l ui.properties ui_ko.properties` must match
3. **Rewrite 5 Java files** with `write_file` (not `patch` — see patch-failure-pattern above).
4. **Build gate**: `./gradlew :game-headed:compileJava` (compile only, fast).
5. **installDist**: `./gradlew :game-headed:installDist --rerun-tasks`.
6. **Verify jar contains bundle**: `jar tf game-headed/build/install/game-headed/lib/game-core.jar | grep _ko.properties`.

If the build fails at step 4, **stop** — the 5 files are interdependent (LoginPanel, ChangeEmailPanel, ForgotPasswordPanel, CreateAccountPanel all share `lobby.LoginPanel.*` keys). Find the first compile error, fix, rebuild.

## Keys 3차-B added (38 total)

For cross-session reference — these keys now exist in the bundle:

| Group | Keys |
|---|---|
| Banner (image lookup) | `BannerLogin`, `ChangeEmailBanner`, `ChangePasswordBanner`, `CreateAccountBanner`, `ForgotPasswordBanner` |
| Common labels | `UsernameLabel`, `PasswordLabel`, `EmailLabel`, `ConfirmPasswordLabel`, `RememberPassword`, `LoginWithoutAccount`, `Login`, `Cancel`, `OK`, `CreateAccount`, `ForgotPassword` |
| Dialog titles | `ChangeEmailTitle`, `ChangePasswordTitle`, `ForgotPasswordDialogTitle` |
| Validation messages | `PasswordTooShortMsg`, `PasswordsMustMatch`, `PasswordIsTooShort`, `EmailMustBeValid`, `YouMustEnterEmail`, `YouMustEnterPassword`, `ClickToCreateAccount` |
| Error/Success titles | `InvalidUsernameTitle`, `InvalidUsernameMsg`, `NoPasswordTitle`, `NoPasswordMsg`, `InvalidPasswordTitle`, `InvalidNameTitle`, `InvalidEmailTitle`, `EmailUpdateSuccessMsg`, `EmailUpdateSuccessTitle` |
| TripleAFrame residual | `ingame.TripleAFrame.ShowSummaryLog`, `ingame.TripleAFrame.ShowDetailedLog` |
| FindTerritoryAction | `ingame.TripleAFrame.FindTerritory` |

**Note**: `lobby.LoginPanel.NoPasswordMsg` / `NoPasswordTitle` were chosen over D3's `lobby.ErrorMessage.*` convention because each login panel has its own private error context. Sharing would force translators to use the same "오류" word for an invalid username and a missing password — different concerns. The convention is **one key family per login panel** even when keys are shared across panels (e.g. `OK`, `Cancel`, `EmailLabel` used in 3 of the 5 panels).

This skill section is the **lobby-login-panels-specific extension** to the umbrella `java-swing-i18n-extension`. Read that skill first for the base pattern (P1–P10 pitfalls, encoding rules, build verification), then read this file for the login-panel-specific patterns. The D3 lobby content (`references/lobby-client-i18n.md`) covers the lobby main UI; this file covers the 5 login/credential dialog panels.
