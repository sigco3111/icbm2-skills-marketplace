---
name: visual-clean-room-redesign
title: Clean-room visual reproduction from public preview only
description: Reproduce a visual look without copying its source.
---

# Clean-room Visual Reproduction

Use when the user wants a recognizable visual look reproduced **without** copying original code, assets, shaders, textures, or geometry. Different from `visual-look-fork-not-rebuild`: that path requires an MIT/Apache OSS clone to fork; this path runs when the reference is a closed-license repo / preview-only / proprietary source — only the rendered visual is reusable, the code is not.

Trigger phrases: "원본이랑 똑같이", "clean room", "라이선스 때문에 복사 불가", "코드 복사 금지하고 비슷하게", or when `visual-look-fork-not-rebuild` cannot find an MIT/Apache fork.

## When to use this skill (decision rule)

```
[user asks for X visual look]
        ↓
[search for MIT/Apache OSS clone → visual-look-fork-not-rebuild]
        ↓
[none found, OR original LICENSE is missing/restrictive]
        ↓
[THIS SKILL — clean-room from public preview/live page only]
        ↓
[download only assets that are explicitly public preview images]
[never copy: code, geometry, shader code, embedded atlas textures, original cover art]
```

The single hardest rule: **only the public preview image (or screenshot) is the input. Code reading is forbidden.** If you find yourself opening the original repo to peek at a uniform or shader, you've already crossed the line.

## Clean-room workflow (7 phases)

### Phase 0 — Acceptable input audit
Before writing one line of code, write down exactly what you are allowed to reuse. For the `complete-shelf` case (2026-08-04) this was:
- ✅ Public preview JPG (`MengTo/complete-shelf/assets/complete-shelf-preview.jpg`, 1280×720) — visual reference only
- ❌ Repo code (`index.html`, embedded shaders)
- ❌ Embedded atlases / textures
- ❌ Cover artwork
- ❌ Geometry / camera constants

Save this audit as the first section of `.verify/reference-criteria.md`.

### Phase 1 — Pixel/percent acceptance criteria
Compose `.verify/reference-criteria.md` with **measurements** (not vibes):

| Axis | Reference measurement | Old MVP deficit | v2 acceptance target (1440×900) |
|---|---|---|---|
| Composition | book bbox `y=27–36%H`, shelf top `59–64%H`, footer top `75–80%H` | reader card 46% open by default | single composition, no side panel |
| 7-book row | exact 7, 1·7 cropped 55–75% | 7 spines, no real crop | 7 cover elements with ≥20% viewport crop at edges |
| Selected scale | selected `188×292px`, neighbors 88% / 87% | selected too tall | selected height `31–38%H`, neighbor 84–92% |
| Shelf | `y=470` rail, `y=537–613` walnut, 4+ layers | single dark box | 4+ horizontal walnut layers, width >100vw, height 12–20%H |
| Top chrome | serif 25px left, 8px spaced subtitle, 8px edition right | 92px glass nav bar | no chrome card, top-left serif + right edition only |
| Footer | `y=613–720` (15%H), three columns | glass nav cards | 18–24%H editorial band, three columns, 7 markers + OPEN pill |
| No card/glass | no floating card | right cream card | no `.reader`, no `backdrop-filter` on floats |
| Interaction | selection moves row + scale, OPEN = inspection | spine click = open reader | wheel/arrow/markers move selected; OPEN alone opens; Back/ESC works |

Quantify. A criteria doc without numbers is a wishlist.

### Phase 2 — Red Playwright DOM contract (TDD on visuals)
Write `tests/visual.spec.ts` against `data-testid` markers that **don't exist yet**. Run. Confirm RED.

```typescript
test('desktop exposes one cinematic seven-cover shelf and editorial chrome', async ({ page }) => {
  await page.setViewportSize({ width: 1440, height: 900 })
  await page.goto('/')
  const books = page.getByTestId('book-mesh')
  await expect(books).toHaveCount(7)
  // metadata on each node: data-book-index, data-title, data-accent
  // expect masthead-left, edition-meta, editorial-footer, position-marker (×7), OPEN visible
  // expect reader + inspection-mode NOT in DOM
  // arrow-key changes footer-title, does NOT open inspection
  // OPEN shows inspection-mode; Escape removes it
})
```

**Why DOM-first instead of screenshot-diff**: screenshot-diff is fragile across GPU/CI; DOM contract gives a stable "did the scene wire up correctly" check. Visual delta is then verified by `vision_analyze` on captured PNGs in Phase 4.

**Two pitfalls encountered (record them)**:
- `test.use({ launchOptions: ... })` outside a sync `describe` fails with "Playwright Test did not expect test.use() to be called here". Fix: configure `launchOptions` in `playwright.config.ts` `use:` block instead, or use `@playwright/test`'s project config.
- `tsconfig.node.json` with `"include": ["tests"]` pulls `.spec.ts` into node-tsc, which then errors on `window.innerWidth`/`getBoundingClientRect` types. Fix: `"include": ["tests/**/*.test.ts"]`.

### Phase 3 — Implementation patterns
The clean-room craft that worked for the complete-shelf rewrite:

1. **Fixed cinematic camera, no OrbitControls.** Drop drei `<OrbitControls />` entirely. A `CinematicCamera` component reads `selectedIndex`/`mode` from store, lerps `camera.position` toward `(0, 0.36, 13.5)` for shelf / `(0, 0.22, 8.5)` for inspection. Camera tracks selection index, books move via position offsets — not vice versa. OrbitControls in clean-room reads as "you're faking, the user can't reproduce this feel".

2. **Carousel distance, not raw index delta.** Wrap-around selection (7 books, arrow keys circle) must use `carouselDistance(i, selected)`:
   ```ts
   function carouselDistance(index, selected) {
     const raw = index - selected
     if (raw > 3) return raw - 7
     if (raw < -3) return raw + 7
     return raw
   }
   ```
   Then **short-circuit** lerp when `Math.abs(targetX - current.x) > SLOT_GAP * 4.5` to avoid the long-travel animation when wrapping.

3. **Procedural cloth weave via CanvasTexture.** Don't ship a PNG. Build it in code:
   ```ts
   const canvas = document.createElement('canvas')  // 256×256
   // 1) base accent fill
   // 2) diagonal gradient grain
   // 3) 1px vertical + horizontal lines every 4px (the weave)
   // 4) ~700 random 1px monochrome dots as noise
   const texture = new CanvasTexture(canvas)
   texture.repeat.set(1.6, 2.4)
   ```
   Reuse with `Map<accent, CanvasTexture>` cache. Bind as `map` + `bumpMap` on `meshStandardMaterial` (`bumpScale: 0.018`).

4. **One foil motif per book, drawn from index.** Don't copy the original cover art. Each book gets a unique procedural line shape — `THREE.Shape` with bezier / line / ring geometry — using the `index` to dispatch. Use `lineBasicMaterial` with `transparent opacity` for an embossed feel. Pass it through `<lineLoop>` with three nested scales (1.0, 1.18, 1.36) for the "concentric foil" look. Make 7 distinct motifs, not 3 repeated — the user will notice.

5. **Cover stack composition.** Each volume is a group of:
   - `<mesh>` with `<boxGeometry args={[W, H, D]} />` + `meshStandardMaterial` (cloth)
   - thin darker mesh at the spine edge (bookbinding)
   - thin lighter mesh at the page edge (paper color `#e9e2d3`)
   - `<FoilMotif>` on the front face (`z = D/2 + 0.005`)
   - Three `<Text>` from drei for kicker / title / subtitle
   
   Use `<mesh>` + `<boxGeometry>` instead of drei `<RoundedBox>` — the rounded corners on RoundedBox fight the editorial "sharp hardcover" silhouette and tend to make motifs look soft.

6. **Walnut shelf = 6 layered meshes.** Not one big slab. Front rail + 4 stacked moldings + 6 horizontal slat lines. Color palette: `#4a2b20 → #2b1812 → #3a2017 → #1e110d → #45271c → alternating #170d0a/#291611`. Width 32 (overshoots viewport) to ensure no edge-of-shelf visible.

7. **Editorial footer = grid, not glass cards.** Three columns: 42% copy / 26% controls / 32% markers. Dark translucent band `#2f2b2bf2` with subtle vertical line texture. **Never** use `backdrop-filter`. Center OPEN pill is `border-radius: 999px` with `1px solid rgba(235,229,219,.45)` — no fill until hover.

8. **Inspection = spread, not side panel.** The whole point is replacing the right-side cream card with a centered hardcover + dark editorial spread (cover on left, copy on right separated by `border-left: 1px solid rgba(232,218,196,.16)`). `BACK` button + `Escape` both call `close()`. Footer + masthead get `opacity: 0; transform: translateY(100%)` so the inspection mode owns the viewport.

9. **Selection × mode × inspection are three independent state slots.** Store shape:
   ```ts
   type ShelfState = {
     selectedIndex: number       // always set, default 0
     mode: 'shelf' | 'inspection'
     select(i)  // moves selection, does NOT open
     open()     // sets mode = 'inspection'
     close()    // sets mode = 'shelf', selection preserved
     next/previous()  // wraps 0↔6
   }
   ```
   This separation is what makes the editorial footer (which only cares about `selectedIndex`) coexist with the inspection spread (which only cares about `mode`).

### Phase 4 — Vision QA loop (≥2 rounds, mandatory)
Capture `1440×900` and `390×844` PNGs via headless Chrome (`executablePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'`). Run `vision_analyze` with a precise rubric question:

> "시각 QA N회차. 이 1440x900 구현을 complete-shelf 원본과 비교해 8축(상단 크롬, 7책 row, 중앙 선택, shelf, footer, 팔레트/재질, no card, 인터랙션) 각 10점 평가와 가장 큰 차이 3개를 픽셀/비율 목표로 제시해줘."

Capture the answer, fix the top-3 delta items, re-screenshot, run again. Stop when vision-analyze no longer flags a blocking defect.

**Two Playwright pitfalls encountered**:
- `page.goto(url, { waitUntil: 'networkidle' })` times out for Vite dev (constant HMR socket keeps it from going idle). Use `{ waitUntil: 'domcontentloaded' }` + `page.waitForTimeout(1600)` after canvas/footer visible.
- `page.on('requestfailed')` and `page.on('pageerror')` collectors must be set **before** `page.goto`. And `favicon.ico` 404 fires a `console error` — either embed an inline SVG favicon (recommended) or filter that one out.

### Phase 5 — No-original-asset audit
Before commit, verify the diff contains:
- ✅ No imports of source files from the reference repo
- ✅ No asset paths pointing into the reference repo
- ✅ No verbatim file copies (text compare against the original index.html if it was ever read — but it shouldn't have been)
- ✅ README.md has a "Clean-room" section explicitly stating: code/assets/shaders/textures/cover art from `<reference repo>` were NOT copied; only the public preview image was used as visual reference

The README paragraph that worked for complete-shelf:

> 이 프로젝트는 자체 설계한 신규 코드와 자산만으로 독립 구현했습니다. `<reference repo>`에서 "책장을 탐색하고 책을 열어 읽는다"는 시각적 아이디어만 참고했으며, 해당 저장소의 코드, 자산, 셰이더, 텍스처는 열람하거나 복사하지 않았습니다. 모든 커버 아트는 절차적 라인 아트/포일 모티프로 새로 생성했습니다.

### Phase 6 — Build + deploy + hash-match
Same as `vercel` skill, with one extra check: capture the JS bundle SHA256 locally and on the deployed alias — they must match. Common silent-fail pattern: Vercel serves old bundle after push because GitHub App webhook missed the commit. Fix with `vercel deploy --yes --prod --force`.

## Pitfalls (encountered, not theory)

- **Don't ship the source's preview image as a fallback** — even though `MengTo/complete-shelf-preview.jpg` is publicly downloadable, using it as your hero breaks the "no original assets" promise. Always build your own render.
- **`RoundedBox` reads as "kids' book" or "soap bar"**. The complete-shelf reference uses sharp hardcover corners; preserve that.
- **Drei `<Text>` on faces needs `anchorX="left"` + `letterSpacing: 0.08`** for Korean — center-anchored serif on a cover reads as Latin-style badge, not editorial typography.
- **`globalThis.innerWidth` not `window.innerWidth`** inside `useFrame` of an R3F component — TS strict DOM lib types sometimes omit it; `globalThis` is always typed.
- **Selection wrap short-circuit** is mandatory. Without it, pressing → from book 6 to 0 lerps the entire 7-book row 12.5 units across the viewport over ~2s, which looks broken instead of "snap to next".
- **Mobile footer must be 2-row grid**. Single-row `grid-template-columns: 1fr 1fr 1fr` overflows at 390px wide once 7 marker buttons + label try to fit. Use `grid-template-rows: 1fr 50px` and split: copy in row 1 (full-width), controls + markers in row 2.
- **Inspection copy scroll container**: `.inspection__copy` must have `max-height: calc(100vh - 180px); overflow-y: auto;`. Without it, long sections push the layout off-screen at viewport heights below 800px.
- **Don't ever read the reference repo's `index.html`** even to "verify one thing". The temptation is enormous when you're stuck; the cleanest defense is to never have opened it. If you've already opened it, document which lines you saw and exclude those lines' structural choices from your code.

## Reference case: complete-shelf (2026-08-04)

Reference: `MengTo/complete-shelf` (no LICENSE, no fork allowed)
Output: `sigco3111/hermes-knowledge-shelf` v2 redesign
- Pixel acceptance criteria → `.verify/reference-criteria.md`
- Red tests → `tests/visual.spec.ts` (Playwright)
- Green tests → `scripts/verify-ui.mjs` (verified 1440×900 + 390×844 with 0 console/page errors)
- Visual delta → 3 vision QA rounds, top-3 fixes each round

Time/token ledger: 1 round for criteria + RED tests, 3 rounds of impl+QA+refine, 1 round for build+deploy (left at deploy prep stage in the session that produced this skill).

## Related skills
- `visual-look-fork-not-rebuild` — fork-first path; try this first when an MIT/Apache clone exists
- `vercel` — deploy + bit-perfect SHA bundle verification
- `software-development/test-driven-development` — RED→GREEN→REFACTOR for visual contracts
- `software-development/ad-hoc-verification` — temp-script verification harness

## References
- `references/complete-shelf-case-2026-08-04.md` — full session transcript with diff snippets and pixel/percent deltas
- `references/visual-acceptance-template.md` — empty `.verify/reference-criteria.md` skeleton for new clean-room tasks
- `scripts/capture-shelves.mjs` — Playwright headless screenshot capture for 1440×900 + 390×844 in one pass
