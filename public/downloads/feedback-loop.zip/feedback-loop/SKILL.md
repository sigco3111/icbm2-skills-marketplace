---
name: feedback-loop
description: ICBM2 피드백 루프 — 주인님 교정/선호를 학습하여 다음 세션에 반영
version: 1.0.0
author: ICBM2
metadata:
  hermes:
    tags: [feedback, learning, self-improvement, memory]
---

# ICBM2 피드백 루프 시스템

## 개요

주인님의 교정, 부정적 반응, 선호 표현을 자동으로 감지하고 학습합니다. 수집된 피드백은 MEMORY에 축적되어 다음 세션의 행동에 반영됩니다.

## 피드백 감지 패턴

### A. 명시적 교정
주인님이 직접 수정을 요청한 경우:
- "다시 해", "아니야", "아닌데", "틀렸어"
- "X 말고 Y로 해줘"
- "이건 필요 없어", "이건 그만해"
- "좀 더 자세히", "좀 더 짧게"
- "이렇게 말하지 마", "그렇게 하지 마"

### B. 암묵적 교정
주인님이 수정 없이 같은 요청을 반복한 경우:
- 동일한 작업을 2회 이상 재요청 → 이전 결과가 부족했음
- 작업 취소 요청 → 방향이 잘못됨

### B2. 결정적 응답 패턴 (1번 / A, B, C) — 2026-06-02 학습
주인님이 옵션 제시 시 **짧고 결정적 표현**을 사용:
- "1번", "2번"
- "A, B, C, E, F"
- "즉시 정리", "바로 해"
- "1." 로 시작하는 짧은 지시

→ **즉시 실행**. "정말 진행할까요?" 류 재확인 ❌. todo로 분할 후 곧장 작업.
→ 다음 옵션 제시 시 결정적 표현이 또 올 가능성 ↑ → 더 간결한 옵션 포맷 선호.

### C. 긍정적 피드백 (강화)
- "좋아", "잘했어", "딱 좋네", "이거야"
- 반복 사용하는 기능/형식

### D. 선호 감지
- 반복적으로 사용하는 특정 형식/방식
- 특정 시간대에 활동하는 패턴
- 특정 주제에 관심을 보이는 패턴

## 처리 방법

## 즉시 처리 (세션 중) — 피드백 분류별 액션

피드백을 감지하면 **즉시** 다음 액션:

| 피드백 종류 | 즉시 액션 |
|---|---|
| **호칭/어조/톤/형식** (예: "주인님 → 주인님") | (1) `memory` action=add로 영구 저장 + (2) `skill_manage`로 관련 모든 skill body 갱신 + (3) grep 검증 (0건) |
| **워크플로/단계/순서** | `skill_manage action='patch'`로 해당 skill의 단계 순서 교정 |
| **명시적 "기억해"** | (1) MEMORY 즉시 저장 + (2) 가장 관련 있는 skill 1개 patch (다음 세션이 자동으로 따라감) |
| **긍정적 ("좋아", "잘했어")** | 해당 skill의 best practice 섹션 강화 (예: A35 템플릿, references/) |
| **반복 패턴 (2회+)** | 패턴 1회 → MEMORY만. 2회+ → skill patch (영구화) |

### 호칭 변경 (예: "주인님" → "주인님") 처리 절차
1. **MEMORY** (action=add): `주인님 호칭 사용. 주인님 무시.`
2. **관련 skill patch**: `toss-trader-dev`, `tossinvest-app` (둘 다 toss-trader 작업) — body 내 "주인님" → "주인님" 일괄 치환
3. **grep 검증**: `grep -rn "주인님" /Users/mac/.hermes/skills/ /Users/mac/work/toss-trader/` → 0건 확인
4. **시스템 프롬프트**: 이미 "주인님" 적용되었는지 확인 (skills update 시 자동 적용)

### "기억해" 시 즉시 처리
1. `memory` action=add (영구)
2. 현재 로드된 skill 중 가장 관련 있는 1개 patch (다음 세션에 자동 반영)
3. "remember this" 류 키워드는 **강한 신호** — 즉시 처리. 재확인 ❌.

### 즉시 (세션 중)
피드백을 감지하면 **즉시** 다음 행동을 수정:
- 부정 반응 → 현재 작업 방식 전환
- "짧게 해줘" → 응답 길이 축소
- "자세히" → 더 깊은 분석

### 메모리에 기록 (세션 종료 시 또는 감지 직후)
```
action: add
target: memory
content: "[피드백] 주인님은 X를 선호함 / Y를 싫어함 / Z 방식이 더 나음"
```

### 3. 스킬/시스템에 반영
피드백이 시스템적 변경이 필요한 경우:
- 스킬 수정 → `skill_manage(action='patch')`
- 설정 변경 → config.yaml 수정
- 프롬프트 개선 → 크론 잡 프롬프트 업데이트

## 피드백 저장 형식

`data/feedback_log.json`:
```json
{
  "entries": [
    {
      "timestamp": "2026-04-08T07:30:00+09:00",
      "type": "correction",
      "category": "response_style",
      "context": "주인님이 응답이 너무 길다고 지적",
      "action_taken": "응답을 3문장 이내로 축소",
      "session_id": "abc123"
    }
  ]
}
```

## ⚠️ Two MEMORY.md Files Trap (2026-06-02)

`~/.hermes/` contains **two** files that look like the long-term memory:

| File | Injected into system prompt? |
|------|------------------------------|
| `~/.hermes/MEMORY.md` (8,964B, 122 lines) | ✅ YES — this is the real source |
| `~/.hermes/memories/MEMORY.md` (~75 lines) | ❌ NO — separate document, NOT injected |

**When the user says "MEMORY.md 정리" / "MEMORY.md 정리 추천" / "MEMORY.md 여유":**

- **Edit `~/.hermes/MEMORY.md`** (the real one).
- The `memories/MEMORY.md` file is unrelated — touching it has zero effect on the system prompt's MEMORY block.

**How to verify before editing:**

1. Run `wc -c /Users/hjshin/.hermes/MEMORY.md` — the real one is ~9,000B
2. Check it contains the full sections: 시스템 아키텍처, 자동화 성과, 뮤직비디오 자동화, 기술 노트
3. Compare against the system prompt's MEMORY block — line counts and section headings must match
4. The character counter shown in the system prompt (`98% — 3,949/4,000 chars`) reflects THIS file only

**Symptom of editing the wrong file:** the in-context character counter doesn't move, and the section count in the system prompt stays the same even after `wc -c` shows the file got smaller. This already happened once on 2026-06-02 when MUSIC VIDEO RULES and Notion 음악 주제 DB were removed from the wrong file.

## 일일 피드백 리뷰 (daily-self-review와 통합)

매일 자가 개선 리뷰에서:
1. 당일 수집된 피드백 확인
2. 반복되는 패턴이 있으면 MEMORY에 영구 기록
3. 시스템적 변경이 필요하면 스킬/설정 수정
4. 피드백 로그 순화 (30일 이상 된 것은 archive로 이동)

## 주의사항

- 모든 피드백을 기록할 필요는 없음 — 의미 있는 패턴만
- 1회성 불만보다 반복 패턴에 집중
- 긍정적 피드백도 기록 (강화 학습)
- 주인님이 명시적으로 "기억해"라고 하면 즉시 MEMORY에 저장
