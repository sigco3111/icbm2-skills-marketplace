# Vite + React + TS 퍼즐 게임 빌드 패턴 (sigco-fruitbox 2026-08-08 실측)

sigco-fruitbox (사과게임) 세션에서 검증된 풀사이클 워크플로우. 본 레퍼런스는 SKILL.md 의 핵심 패턴에 더해, 자주 빠지는 디테일 + 검증 명령 + 타이밍을 정리.

## 트리거

- "OO 게임 만들어줘" 류 from-scratch 요청 (fork 아님)
- 격자/카드 기반 1인용 퍼즐, 1~3분 라운드
- 모바일 + 데스크탑, Vercel 정적 호스팅

## 풀스택 워크플로

### Step 1 — 프로젝트 디렉토리 + 보일러플레이트 (5분)

```bash
mkdir -p ~/work/<game-name>
cd ~/work/<game-name>
```

**`package.json`** — 위 SKILL.md §1 그대로 (React 18.3.1 + Vite 5.4 + TS 5.6 + Tailwind 3.4)

**`tsconfig.json`** — `noEmit:true` + references 없음 (composite 안 씀)

**`vite.config.ts`** — `host:true, port:5173` (LAN 접속 가능)

**`tailwind.config.js` + `postcss.config.js` + `index.html` + `src/index.css`** — SKILL.md §1 그대로

### Step 2 — 게임 엔진 (`game/` 폴더, 10분)

4개 파일로 분리:

```
src/game/
  random.ts   # mulberry32 PRNG + daily seed
  engine.ts   # 보드 생성, 검증, 적용, 힌트
  useGame.ts  # React 상태 머신
  storage.ts  # localStorage 헬퍼
```

**`random.ts` 핵심**:
- `mulberry32(seed)` — 결정론적 PRNG (32-bit 시드)
- `dailySeed(date)` — `YYYYMMDD` 정수
- `hashStringToInt(s)` — FNV-1a 해시 (시드 문자열 → 32-bit)

**`engine.ts` 핵심**:
- `ROWS`, `COLS`, `TOTAL` 상수
- `TARGET_SUMS = [8, 10, 12, 15]` — 매 판 랜덤 목표
- `Cell = number | null` (null = cleared)
- `createRound(roundIndex, explicitTarget?)` — PRNG + ensureSolvable
- `isValidSelection(board, r1, c1, r2, c2, target)` — 합 검증
- `applySelection(board, ...)` — 새 board 반환 (immutable)
- `findAnyValidRect(board, target)` — 힌트용 (전수 탐색)
- `aliveCount(board)` — alive 셀 카운트

**`useGame.ts` 상태 머신**:
- `status: 'idle' | 'playing' | 'over'`
- `selection: { r1, c1, r2, c2 } | null` (in-progress)
- `liveSum`, `liveAlive` (실시간 표시)
- `score`, `timeLeft`, `hintRect`, `hintUsed`
- Actions: `start`, `newRound`, `setDrag(r, c)`, `clearDrag()`, `commitDrag()`, `useHint()`

**타이머 useEffect 패턴**:
```ts
useEffect(() => {
  if (status !== 'playing') return;
  const id = window.setInterval(() => {
    setTimeLeft(t => t <= 1 ? (finish(), 0) : t - 1);
  }, 1000);
  return () => window.clearInterval(id);
}, [status, finish]);
```

**자동 종료 (perfect clear) useEffect**:
```ts
useEffect(() => {
  if (status === 'playing' && board && aliveCount(board) === 0) finish();
}, [board, status, finish]);
```

### Step 3 — UI 컴포넌트 (`components/` 폴더, 10분)

**`BoardView.tsx`** — 격자 렌더 + 드래그 셀렉션
**`HUD.tsx`** — 점수/타이머/타겟합 카드
**`GameOverPanel.tsx`** — 종료 모달

**셀 배치 전략**: 각 셀을 `position: absolute` + `left/top %` 로 배치. `aspect-ratio: 17/10` + `width: 100%; max-width: 680px` 로 반응형. CSS Grid 안 씀 (드래그 영역 시각화가 절대 위치 사각형이라 어울림).

```tsx
<div className="relative w-full max-w-[680px] aspect-[17/10]">
  {board.map((row, r) =>
    row.map((cell, c) => (
      <div key={`${r}-${c}`} className="absolute"
        style={{
          left: `${(c / 17) * 100}%`,
          top: `${(r / 10) * 100}%`,
          width: `${100 / 17}%`,
          height: `${100 / 10}%`,
        }}>
        <div className="...fruit-styling...">
          {cell}
        </div>
      </div>
    ))
  )}
  {/* Selection outline */}
  {selection && (
    <div className="absolute pointer-events-none border-2 border-white/80"
      style={{
        left: `${(selection.c1 / 17) * 100}%`,
        top: `${(selection.r1 / 10) * 100}%`,
        width: `${((selection.c2 - selection.c1 + 1) / 17) * 100}%`,
        height: `${((selection.r2 - selection.r1 + 1) / 10) * 100}%`,
      }} />
  )}
</div>
```

### Step 4 — i18n + storage (5분)

**`i18n.ts` 패턴**:
```ts
const dict = {
  ko: { title: '사과게임', /* ... */ },
  en: { title: 'Fruit Box', /* ... */ },
} as const;

export function useLang() {
  const [lang, setLangState] = useState<Lang>(() => {
    if (typeof window === 'undefined') return 'ko';
    const saved = localStorage.getItem('app.lang');
    if (saved === 'ko' || saved === 'en') return saved;
    return navigator.language.toLowerCase().startsWith('ko') ? 'ko' : 'en';
  });
  useEffect(() => {
    localStorage.setItem('app.lang', lang);
    document.documentElement.lang = lang;
  }, [lang]);
  return { lang, setLang: setLangState, t: (k: TKey) => dict[lang][k] ?? k };
}
```

**`storage.ts` SSR-safe wrapper**:
```ts
export function loadBest(): number {
  if (typeof window === 'undefined') return 0;
  return Number(localStorage.getItem('app.best') ?? '0');
}
export function saveBest(score: number): number {
  const cur = loadBest();
  if (score > cur) { localStorage.setItem('app.best', String(score)); return score; }
  return cur;
}
```

### Step 5 — 검증 (`tsc --noEmit` + `npm run build`, 2분)

```bash
npx tsc --noEmit   # 0 errors
npm run build      # 160KB JS / 17KB CSS
```

### Step 6 — Dev server + Playwright smoke (10분)

```bash
npm run dev  # 백그라운드
# 다른 터미널:
python3 /tmp/fb_smoke.py
```

**Playwright 5단계 검증** (전체 코드):

```python
import asyncio
from playwright.async_api import async_playwright
from collections import defaultdict

async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        ctx = await browser.new_context(viewport={"width": 900, "height": 1300}, locale="ko-KR")
        page = await ctx.new_page()

        # 1) console error zero
        errors = []
        page.on("pageerror", lambda e: errors.append(f"PAGEERROR: {e}"))
        page.on("console", lambda m: errors.append(...) if m.type in ("error","warning") else None)

        await page.goto("http://localhost:5173", wait_until="networkidle")
        await page.wait_for_selector("button:has-text('시작'), button:has-text('Start')")

        # 2) 셀 렌더 카운트
        cells = await page.locator("...selector...").all()
        assert len(cells) == ROWS * COLS, f"expected {ROWS*COLS} cells, got {len(cells)}"

        # 시작 클릭
        await page.click("button:has-text('시작'), button:has-text('Start')")
        await page.wait_for_timeout(300)

        # 3, 4) 격자 좌표 매핑 + valid pair 찾기
        data = await page.evaluate("""
          () => {
            const board = document.querySelector("...selector...");
            const rect = board.getBoundingClientRect();
            const kids = [...board.children];
            return {
              rect: { x: rect.x, y: rect.y, w: rect.width, h: rect.height },
              cells: kids
                .filter(k => /^\\d+$/.test(k.innerText.trim()))
                .map(k => {
                  const b = k.getBoundingClientRect();
                  return { v: parseInt(k.innerText, 10), cx: b.x + b.width/2, cy: b.y + b.height/2 };
                }),
            };
          }
        """)
        rect = data["rect"]
        target_text = await page.locator("text=목표 합").first.locator("xpath=..").inner_text()
        target = int(target_text.strip().split('\n')[-1])

        cw = rect["w"] / COLS
        ch = rect["h"] / ROWS
        rowmap = defaultdict(list)
        for c in data["cells"]:
            col = max(0, min(COLS-1, round((c["cx"] - rect["x"]) / cw)))
            row = max(0, min(ROWS-1, round((c["cy"] - rect["y"]) / ch)))
            rowmap[row].append({"v": c["v"], "col": col, "cx": c["cx"], "cy": c["cy"]})

        valid_pair = None
        for r, items in sorted(rowmap.items()):
            items.sort(key=lambda x: x["col"])
            for i in range(len(items)):
                for j in range(i+1, len(items)):
                    if items[i]["v"] + items[j]["v"] != target: continue
                    cols_between = set(range(items[i]["col"]+1, items[j]["col"]))
                    if not any(it["col"] in cols_between for it in items if it is not items[i] and it is not items[j]):
                        valid_pair = (items[i], items[j]); break
                if valid_pair: break
            if valid_pair: break

        assert valid_pair, "no valid pair found (solvability gate failed?)"
        a, b = valid_pair

        # 정확한 드래그
        await page.mouse.move(a["cx"], a["cy"])
        await page.mouse.down()
        for k in range(1, 8):
            await page.mouse.move(a["cx"] + (b["cx"]-a["cx"])*k/7, a["cy"] + (b["cy"]-a["cy"])*k/7)
            await page.wait_for_timeout(20)
        await page.mouse.up()
        await page.wait_for_timeout(400)

        score_text = await page.locator("text=점수").first.locator("xpath=..").inner_text()
        alive_text = await page.locator("text=남은 사과").first.locator("xpath=..").inner_text()
        # 점수 2 (두 사과) + 남은 168 확인

        # 5) 모바일 viewport
        await ctx.close()
        ctx = await browser.new_context(
            viewport={"width": 390, "height": 844},
            is_mobile=True, has_touch=True,
            device_scale_factor=3, locale="ko-KR",
        )
        page = await ctx.new_page()
        await page.goto("http://localhost:5173", wait_until="networkidle")
        # 동일 시나리오 재실행

        await browser.close()

asyncio.run(main())
```

### Step 7 — README + 배포 (5분)

**README.md 구조**:
- 🍎 헤더 + 한 줄 컨셉
- 🎮 규칙
- 🧩 기능
- 🛠️ 개발 (`npm install`, `dev`, `build`, `preview`)
- 🚀 배포 (Vercel)
- 📁 구조
- 🧠 시드 규칙
- 🎯 커스텀 규칙

**Vercel 배포**:
```bash
vercel deploy --prod --yes --token $(cat ~/.hermes/secrets/vercel_token.txt)
# vercel.json 불필요 (Vite 기본 OK)
```

## sigco-fruitbox 검증 결과 (2026-08-08)

| 검증 | 결과 |
|---|---|
| `tsc --noEmit` | 0 errors |
| `npm run build` | 159KB JS / 17KB CSS, 39 modules |
| Vite dev server | http://localhost:5173 → 200 OK |
| Playwright 데스크탑 valid pair | score 2, alive 168 |
| Playwright 모바일 (390×844) | score 2, alive 168 |
| 콘솔 에러 | 0건 |

**총 소요 시간**: ~30분 (코드 + 검증 + README)

## 자주 빠지는 디테일 6종

### 1. `composite` + `noEmit` 충돌 (TS6310)

`tsconfig.json`에서 `noEmit:true` + `references: [...]` 동시에 사용 불가. **해결**: references 제거 + 단일 tsconfig.

```json
// ❌ TS6310
{
  "compilerOptions": { "noEmit": true },
  "references": [{ "path": "./tsconfig.node.json" }]
}

// ✓ OK
{
  "compilerOptions": { "noEmit": true },
  "include": ["src", "vite.config.ts"]
}
```

**build 스크립트도 단순화**: `"build": "tsc --noEmit && vite build"` (composite 안 씀).

### 2. PointerEvent `setPointerCapture` 패턴

```tsx
const onPointerDown = (e: React.PointerEvent) => {
  draggingRef.current = true;
  pointerIdRef.current = e.pointerId;
  (e.target as Element).setPointerCapture?.(e.pointerId);
};

const onMove = (e: PointerEvent) => {
  if (!draggingRef.current) return;
  if (pointerIdRef.current !== null && e.pointerId !== pointerIdRef.current) return;
  // 추적
};

const onUp = (e: PointerEvent) => {
  if (pointerIdRef.current === e.pointerId) {
    draggingRef.current = false;
    pointerIdRef.current = null;
  }
};
```

**왜 window-level?** 컨테이너 밖에서도 드래그 추적. `pointermove`는 컨테이너 안에서만 발생 → 컨테이너 빠지면 추적 끊김. window-level 이 정답.

### 3. Playwright localStorage 공유 함정

같은 컨텍스트 재사용 시 localStorage 보존 → lang=en 박힌 상태로 시작 → 한국어 selector 실패.

**해결 1**: 매 테스트 fresh `browser.new_context()`.
**해결 2**: `locale='ko-KR'` 명시 + selector 양국어 fallback.
**해결 3**: `localStorage.removeItem('app.lang')` in `page.evaluate` 후 reload.

### 4. 임의 사과 2개 드래그 = score 0 정상

`findAnyValidRect`로 valid 1개 이상 확인된 보드라도, **임의 2개 사과 사이에 다른 사과가 끼면 합 ≠ target → commit 무시 → score 0**. 엔진 버그 아님. 진단은 valid pair 명시적 검색으로.

### 5. React StrictMode 더블 effect

`<React.StrictMode>`로 dev 모드에서 useEffect 두 번 호출. 본 게임은 첫 호출에서 createRound(1), 두 번째에서... `useEffect(() => { createRound(1); }, [])` 는 StrictMode 에서도 한 번만 실행 (effect 자체는 한 번). 단, `useState` 초기화 함수는 두 번 호출됨. 무거운 작업은 useEffect 안에서.

### 6. i18n useEffect 무한 루프

```ts
useEffect(() => {
  localStorage.setItem('app.lang', lang);
  document.documentElement.lang = lang;
}, [lang]);
```

`lang` 의존성 → setLang 호출 시 setState + re-render + effect 한 번 더 실행 (정상). 무한 루프 아님. 단 effect 안에서 `setLang` 호출하면 무한 루프 → 절대 X.

## 다음 단계 추천

- 사운드 효과 (Web Audio API)
- 콤보 시스템 (5+ 사과 한 번에 지우면 보너스)
- 리더보드 (외부 API)
- Google Analytics / Plausible
- 매일 시드 + 시드 공유 (URL ?seed=... 쿼리)

## 참고

- 메인 SKILL: `vite-react-game-from-scratch`
- 시드 PRNG 표준: mulberry32 (Tommy Ettinger)
- FNV-1a 해시: 32-bit 비암호화 해시, 시드 생성용
