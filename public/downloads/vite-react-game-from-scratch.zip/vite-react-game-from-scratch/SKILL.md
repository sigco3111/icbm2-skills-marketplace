---
name: vite-react-game-from-scratch
description: Vite+React+TS puzzle game from-scratch build pipeline.
category: devops
tags:
  - vite
  - react
  - typescript
  - tailwind
  - game
  - puzzle
  - from-scratch
  - playwright
  - vercel
  - pointer-events
  - daily-seed
when to use: >
  "OO 게임 만들어줘" 류 from-scratch 요청 (fork 아님).
  격자/카드 기반 1인용 퍼즐 게임 (드래그로 영역 선택, 합/조건 검증, 셀 제거).
  1~3분 라운드 + 시드 기반 콘텐츠 (매일/매판 다름).
  모바일 터치 + 데스크탑 마우스 둘 다 지원 필수.
  Vercel 정적 호스팅 (서버 0) 으로 배포.
  **React + Vite 풀스택 (TypeScript strict + Tailwind)** — Godot/Rust/순수 HTML 아닌.
  단, **인터랙티브 시각화 (Canvas, Three.js, D3.js)** 는 `canvas-static-site-pipeline` 변형 1 우선.
  **Web Component / 단일 script 위젯** 은 `interactive-widget-pages-deploy` 우선.
---

# Vite + React + TS 게임 From-Scratch 빌드 (sigco-fruitbox 2026-08-08 실측)

> fork 가 아니라 from-scratch. Vite+React+TS+Tailwind 풀스택 (UI + 게임 엔진 + 상태 머신) 으로 브라우저 게임을 처음부터 만드는 패턴.
> Athena Crisis fork 와 다른 점: clone + 의존성 교체 아니라 빈 디렉토리에서 `npm init` 부터.

## 트리거 (when to use)

다음 키워드가 들어오면 본 스킬:
- "OO 게임 만들어줘" / "퍼즐 게임 하나 만들어줘"
- 격자/카드 기반 인터랙션 (드래그 영역, 셀 매치, 카드 뒤집기, 보드 클릭)
- 1~3분 라운드 + 시드 콘텐츠 + 점수 시스템
- 모바일/데스크탑 모두 지원 + Vercel 정적 호스팅

다음이면 다른 스킬:
- 3D 시각화 (Three.js) / Canvas API 순수 그림 → `canvas-static-site-pipeline` 변형 1
- 단일 `<script>` 위젯 / Web Component → `interactive-widget-pages-deploy`
- Godot 4 게임 → `godot-game-bootstrap`
- Rust 서버 + TS 클라 → `rust-monorepo-game-dev`
- 기존 OSS 게임 fork + 한국어화 → `oss-fork-localization` / `vite-react-spa-game-fork`

## 워크플로 (8단계)

### 0. 컨셉 확정 (clarify)

`canvas-static-site-pipeline` §0 처럼 1차로 deliverable 분류:
- **격자 + 셀렉션** (사과게임, 스도쿠, 지뢰찾기) → 본 스킬
- **카드 매칭** (메모리, 21장) → 본 스킬 (셀렉션 = 카드 2장)
- **자동 진행 + DB** (incremental) → `incremental-game-design`
- **LLM NPC 시뮬** → `incremental-game-design` NIM 5세션 패턴

사용자가 "다 만들도 추가개선까지" 처럼 풀스택 위임 시 → **B 패턴 (전체 위임) + 추천 자동 결정** (`canvas-static-site-pipeline` §7.5.7 위임 모드).

### 1. 보일러플레이트 — Vite + React 18 + TS + Tailwind

#### `package.json` 핵심
```json
{
  "name": "<game-name>",
  "private": true,
  "version": "0.1.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "tsc --noEmit && vite build",
    "preview": "vite preview --host",
    "typecheck": "tsc --noEmit"
  },
  "dependencies": {
    "react": "^18.3.1",
    "react-dom": "^18.3.1"
  },
  "devDependencies": {
    "@types/node": "^22.10.0",
    "@types/react": "^18.3.12",
    "@types/react-dom": "^18.3.1",
    "@vitejs/plugin-react": "^4.3.4",
    "autoprefixer": "^10.4.20",
    "postcss": "^8.4.49",
    "tailwindcss": "^3.4.17",
    "typescript": "^5.6.3",
    "vite": "^5.4.11"
  }
}
```

**TypeScript composite 함정 회피**: `tsc -b` (composite) 와 `tsc --noEmit` (typecheck) 를 같은 tsconfig 에서 못 돌림. **build 스크립트는 `tsc --noEmit && vite build` 으로 단순화** (TS 검증 + Vite 빌드 분리). vite 가 자체 TS 검사를 함.

#### `tsconfig.json` (단일, noEmit, references 제거)
```json
{
  "compilerOptions": {
    "target": "ES2020",
    "useDefineForClassFields": true,
    "lib": ["ES2020", "DOM", "DOM.Iterable"],
    "module": "ESNext",
    "skipLibCheck": true,
    "moduleResolution": "bundler",
    "resolveJsonModule": true,
    "isolatedModules": true,
    "noEmit": true,
    "jsx": "react-jsx",
    "strict": true,
    "noUnusedLocals": false,
    "noUnusedParameters": false,
    "noFallthroughCasesInSwitch": true,
    "types": ["node"]
  },
  "include": ["src", "vite.config.ts"]
}
```

#### `vite.config.ts`
```ts
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: { host: true, port: 5173 },
});
```

#### `tailwind.config.js` + `postcss.config.js`
```js
// tailwind.config.js
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: { extend: {} },
  plugins: [],
};

// postcss.config.js
export default {
  plugins: { tailwindcss: {}, autoprefixer: {} },
};
```

#### `index.html`
```html
<!doctype html>
<html lang="ko">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="theme-color" content="#0f172a" />
    <title>{게임명}</title>
  </head>
  <body class="bg-slate-950 text-slate-100">
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
```

#### `src/index.css`
```css
@tailwind base;
@tailwind components;
@tailwind utilities;

html, body, #root { height: 100%; }
body {
  -webkit-user-select: none;
  user-select: none;
  -webkit-tap-highlight-color: transparent;
  overscroll-behavior: none;
}
.no-touch-default { touch-action: none; }
```

### 2. 폴더 구조 (sigco-fruitbox 표준)

```
src/
  main.tsx              React 부트스트랩
  App.tsx               최상위 (HUD + BoardView + GameOverPanel)
  index.css             Tailwind + 전역
  i18n.ts               사전 + useLang 훅
  game/
    random.ts           mulberry32 PRNG + 데일리 시드
    engine.ts           보드 생성, 검증, 적용, 힌트
    useGame.ts          상태 머신 훅
    storage.ts          localStorage 헬퍼
  components/
    BoardView.tsx       격자 + 드래그 셀렉션
    HUD.tsx             점수/타이머/카드
    GameOverPanel.tsx   종료 모달
```

### 3. 게임 엔진 — 결정론적 시드 + Solvability gate

#### 결정론적 시드 콘텐츠 (`random.ts`)
```ts
export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return function () {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function dailySeed(d = new Date()): number {
  return d.getFullYear() * 10000 + (d.getMonth() + 1) * 100 + d.getDate();
}

export function hashStringToInt(s: string): number {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}
```

#### Solvability gate (즉시 playable 보장)
```ts
function ensureSolvable(board, rng, target) {
  if (findAnyValidRect(board, target)) return board;
  for (let attempt = 0; attempt < 500; attempt++) {
    const trial = board.map(r => r.slice());
    for (let k = 0; k < 12; k++) {
      const r = Math.floor(rng() * ROWS);
      const c = Math.floor(rng() * COLS);
      trial[r][c] = 1 + Math.floor(rng() * 9);
    }
    if (findAnyValidRect(trial, target)) return trial;
  }
  return board;  // worst case: 사용자가 새 라운드 시작
}
```

**왜 중요**: PRNG 단독은 "dead-on-arrival" 보드 가능 → 사용자 첫 클릭 후 막힘 → 즉시 이탈. 500회 보정이면 거의 항상 통과.

### 4. 통합 PointerEvents 드래그 (마우스 + 터치)

`BoardView.tsx` — 마우스/터치 분기 없이 PointerEvents 하나로:

```tsx
const draggingRef = useRef(false);
const pointerIdRef = useRef<number | null>(null);

const onPointerDown = (e: React.PointerEvent) => {
  if (!containerRef.current) return;
  draggingRef.current = true;
  pointerIdRef.current = e.pointerId;
  const p = clientToCell(containerRef.current, e.clientX, e.clientY);
  if (p) onDragChange(p.r, p.c);
  (e.target as Element).setPointerCapture?.(e.pointerId);
};

useEffect(() => {
  const onMove = (e: PointerEvent) => {
    if (!draggingRef.current) return;
    if (pointerIdRef.current !== null && e.pointerId !== pointerIdRef.current) return;
    handleMove(e.clientX, e.clientY);
  };
  const onUp = () => handleUp();
  window.addEventListener('pointermove', onMove);
  window.addEventListener('pointerup', onUp);
  window.addEventListener('pointercancel', onUp);
  return () => { /* cleanup */ };
}, []);
```

**좌표 변환**:
```ts
function clientToCell(container: HTMLElement, x: number, y: number) {
  const rect = container.getBoundingClientRect();
  const lx = x - rect.left, ly = y - rect.top;
  const c = Math.max(0, Math.min(COLS - 1, Math.floor(lx / (rect.width / COLS))));
  const r = Math.max(0, Math.min(ROWS - 1, Math.floor(ly / (rect.height / ROWS))));
  return { r, c };
}
```

**핵심**:
- `pointerdown` 만 컨테이너에, `pointermove`/`pointerup` 은 window-level → 컨테이너 밖에서도 추적
- `setPointerCapture` 로 멀티터치 시 자기 포인터만 추적
- `touch-action: none` CSS 로 브라우저 기본 제스처 차단

### 5. 상태 머신 — useGame 훅

3-state 분리: `selection` (in-progress) → `commitDrag()` (검증 + 적용).

```ts
const setDrag = useCallback((r, c) => {
  setSelection(prev => {
    if (!prev) return { r1: r, c1: c, r2: r, c2: c };
    const sel = {
      r1: Math.min(prev.r1, r), c1: Math.min(prev.c1, c),
      r2: Math.max(prev.r2, r), c2: Math.max(prev.c2, c),
    };
    setLiveSum(rectSum(board, sel.r1, sel.c1, sel.r2, sel.c2));
    setLiveAlive(rectAliveCount(board, sel.r1, sel.c1, sel.r2, sel.c2));
    return sel;
  });
}, [board]);

const commitDrag = useCallback(() => {
  if (!board || !selection) { clearDrag(); return; }
  if (isValidSelection(board, selection.r1, selection.c1, selection.r2, selection.c2, target)) {
    const cleared = rectAliveCount(board, ...);
    setBoard(applySelection(board, ...));
    setScore(s => s + cleared);
  }
  clearDrag();
}, [board, selection, target]);
```

**타이머 useEffect**:
```ts
useEffect(() => {
  if (status !== 'playing') return;
  const id = window.setInterval(() => {
    setTimeLeft(t => t <= 1 ? (finish(), 0) : t - 1);
  }, 1000);
  return () => window.clearInterval(id);
}, [status, finish]);
```

**종료 자동 트리거** (보드 다 비우면):
```ts
useEffect(() => {
  if (status === 'playing' && board && aliveCount(board) === 0) finish();
}, [board, status, finish]);
```

### 6. i18n + localStorage

#### `i18n.ts` (사전 + useLang 훅)
```ts
export function useLang() {
  const [lang, setLang] = useState<Lang>(() => {
    if (typeof window === 'undefined') return 'ko';
    const saved = localStorage.getItem('app.lang');
    if (saved === 'ko' || saved === 'en') return saved;
    return navigator.language.toLowerCase().startsWith('ko') ? 'ko' : 'en';
  });
  useEffect(() => {
    localStorage.setItem('app.lang', lang);
    document.documentElement.lang = lang;
  }, [lang]);
  return { lang, setLang, t: (k: TKey) => dict[lang][k] ?? k };
}
```

#### `storage.ts` (SSR-safe wrapper)
```ts
function load(key: string, fallback: number) {
  if (typeof window === 'undefined') return fallback;
  return Number(localStorage.getItem(key) ?? String(fallback));
}
function saveBest(key: string, score: number) {
  const cur = load(key, 0);
  if (score > cur) { localStorage.setItem(key, String(score)); return score; }
  return cur;
}
function consumeToken(key: string) {
  if (localStorage.getItem(key) === '1') return false;
  localStorage.setItem(key, '1');
  return true;
}
```

### 7. Playwright 검증 (5단계)

```python
# 1) console error zero + pageerror catch
errors = []
page.on("pageerror", lambda e: errors.append(f"PAGEERROR: {e}"))
page.on("console", lambda m: errors.append(...) if m.type in ("error","warning") else None)

# 2) 셀 렌더 카운트 정확
cells = await page.locator("...selector...").all()
assert len(cells) == ROWS * COLS

# 3) invalid 드래그 → 점수 0 (회귀 방지 — 임의 합이 정확히 target 아닐 때 무시)
await page.mouse.move(a.cx, a.cy); await page.mouse.down()
await page.mouse.move(b.cx, b.cy, steps=10); await page.mouse.up()
# score 0 OK (임의 합은 정확히 target 아닐 가능성 큼)

# 4) valid 직사각형 → 점수 정확 (살아있는 셀 수)
# 격자 좌표 매핑 → 같은 행의 인접 2개 중 target 합 + 중간에 다른 사과 없음
for i in range(len(items)):
  for j in range(i+1, len(items)):
    if items[i]["v"] + items[j]["v"] != target: continue
    cols_between = set(range(items[i]["col"]+1, items[j]["col"]))
    if not any(it["col"] in cols_between for it in items if it is not items[i] and it is not items[j]):
      valid_pair = (items[i], items[j]); break

# 5) 모바일 viewport (390×844) 재검증
ctx = await browser.new_context(
  viewport={"width": 390, "height": 844},
  is_mobile=True, has_touch=True,
  device_scale_factor=3, locale="ko-KR",
)
```

**Playwright 함정**:
- localStorage 공유 → 매 테스트 fresh `browser.new_context()` 권장
- `'text=시작'` selector 가 lang=en 일 때 매칭 실패 → `'button:has-text('시작'), button:has-text('Start')'` 식 fallback 또는 `locale='ko-KR'` 명시
- viewport 잘림 → CSS `aspect-ratio: ROWS/COLS` + `max-width` 로 강제

### 8. Vercel 배포

Vite 정적 호스팅 기본 OK. `vercel.json` 불필요.

```bash
npm run build  # tsc --noEmit && vite build → dist/
vercel deploy --prod --yes --token $(cat ~/.hermes/secrets/vercel_token.txt)
# 또는: GitHub push + Vercel GitHub 통합 자동 배포
```

## 검증된 워크플로 (sigco-fruitbox 2026-08-08)

| 단계 | 산출물 | 검증 |
|---|---|---|
| 1. 보일러플레이트 | package.json + tsconfig + vite.config + tailwind.config | `npm install` ~134 packages |
| 2. 게임 엔진 | random.ts + engine.ts + useGame.ts | `npx tsc --noEmit` 0 errors |
| 3. UI | BoardView.tsx + HUD.tsx + GameOverPanel.tsx | `npm run build` ~160KB JS / ~17KB CSS |
| 4. i18n + storage | i18n.ts + storage.ts | localStorage round-trip |
| 5. Dev server | `npm run dev` | http://localhost:5173 → 200 OK |
| 6. Playwright smoke | valid pair drag | score 2, alive 168 |
| 7. Playwright mobile | iPhone 14 viewport | score 2, alive 168 |
| 8. README | 규칙 + 구조 + 시드 정책 | — |

**타이밍**: 1~4단계 ~15분, 5~7단계 ~10분, 8단계 ~5분. **총 ~30분** with 검증.

## 즉시 적용 규칙

1. **`tsconfig.json` = noEmit 단일** (composite 안 씀, references 제거)
2. **build 스크립트 = `tsc --noEmit && vite build`** (TS 검증 + Vite 빌드 분리)
3. **PointerEvents 통합** (mouse + touch 분기 X, window-level move/up)
4. **PRNG + Solvability gate** (즉시 playable 보장)
5. **Playwright 5단계** (console 0 + 셀 카운트 + invalid + valid + 모바일)
6. **localStorage = SSR-safe wrapper** (`typeof window === 'undefined'` 가드)
7. **i18n = localStorage + navigator 폴백** + document.documentElement.lang 동기화
8. **Vercel 정적 호스팅 = vercel.json 불필요** (Vite 기본 OK)

## 자주 빠지는 함정 4종

1. **localStorage 공유** — Playwright 컨텍스트는 같은 디렉토리 재사용 시 localStorage 보존. 매 테스트 fresh `browser.new_context()` 권장.
2. **selector 변형** — lang=en 이면 "Start", lang=ko 이면 "시작". selector 는 두 언어 동시 매칭 또는 `locale='ko-KR'` 명시.
3. **viewport 잘림** — 모바일 viewport에서 격자가 viewport 폭 넘으면 가로 스크롤. CSS `aspect-ratio: ROWS/COLS` + `max-width` 로 강제.
4. **composite + noEmit 충돌** — `tsc -b` (composite) 와 `tsc --noEmit` (typecheck) 를 같은 tsconfig 에서 못 돌림 (TS6310). **build 스크립트는 `tsc --noEmit && vite build`** 으로 단순화.

## 합계 검증 (Playwright 점수 0 false alarm)

**자주 하는 실수**: 임의 사과 2개를 드래그 → 합이 정확히 target 아님 → commit 무시 → 점수 0 → "엔진 버그?" 의심. **이건 정상**. valid 직사각형은 (a) 합 = target, (b) 사이에 다른 사과 없음. 임의 2개는 (a) 도 (b) 도 거의 만족 못 함.

**진단법**: 엔진의 `findAnyValidRect` 로 1개라도 valid 가 있는지 확인 → 0개면 solvability gate 실패 (rare). 1개 이상이면 드래그 코드 검증 (좌표 변환 + commit 분기). 

## 🔗 관련 스킬

- `canvas-static-site-pipeline` — 변형 1 (정적 웹) 의 상위. Canvas/Three.js 시각화는 이쪽. 본 스킬은 그 변형의 하위: Vite+React+TS 게임.
- `interactive-widget-pages-deploy` — 단일 `<script>` 위젯 / Web Component. 본 스킬은 풀스택 React.
- `vite-react-spa-game-fork` — fork 워크플로우. 본 스킬은 from-scratch.
- `godot-game-bootstrap` — Godot 4 게임. 본 스킬은 React/Vite.
- `rust-monorepo-game-dev` — Rust 서버 + TS 클라. 본 스킬은 순수 프론트엔드.

## 📁 첨부 파일

- `references/vite-react-ts-puzzle-game-build.md` — 본 스킬의 풀사이클 코드 스니펫 + 검증 명령 + 타이밍 (sigco-fruitbox 실측)
