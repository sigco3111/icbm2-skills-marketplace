# Source Integrity 3-Way Matrix (2026-07-07 jelly-tetris 재배포 실측)

Vercel alias에 서빙되는 HTML이 **사용자가 인식한 "원본"**과 어긋날 때의 진단 모드. 3개 source를 동시에 byte-level 비교해서 어느 쪽이 stale인지 즉시 판별.

## 트리거 시그널

| 사용자 발화 (verbatim 변형) | 해석 |
|---|---|
| "배포된 소스에 문제가 원본과 다름" | 원본 ≠ Vercel live 진단 시작 |
| "원본 소스 경로는 `<github-url>`" | 비교 기준 명시 (GitHub repo) |
| "원본 소스 경로는 `/Users/mac/work/<project>`" | 비교 기준이 **로컬 working tree** |
| 두 경로 모두 명시 | "원본"이 두 곳에 모두 존재 → 어느 쪽이 stale인지 즉시 판별 |

## 3-Way Matrix (★ 핵심)

Vercel이 서빙하는 HTML을 **세 source** 중 어떤 것이 진짜 원본인지 비교:

| Source 위치 | Fetch 방법 | 검증 |
|---|---|---|
| **Vercel alias** | `curl -sL https://<project>.vercel.app/` (anon, 200) | 사용자 공개 demo URL |
| **GitHub main HEAD** | `curl -sL https://raw.githubusercontent.com/<owner>/<repo>/<sha>/index.html` (raw CDN) | GitHub origin 진실 |
| **로컬 working tree** | `cat /Users/mac/work/<project>/index.html` | 사용자 머신의 최신 |

**판정 규칙**:

```text
md5(Vercel live) == md5(GitHub main HEAD) ?    일치   → Vercel이 GitHub main 반영 = 정상 자동배포
                                                불일치 → Vercel stale 또는 캐시 미반영

md5(로컬 working tree) == md5(GitHub main HEAD) ?   일치   → 로컬 = GitHub origin (push 완료)
                                                   불일치 → unstaged 변경 또는 origin이 stale

사용자 신호 "원본 = GitHub + 로컬" 둘 다일 때:
  → unstaged 변경이 의도된 새 버전 = commit + push → auto-deploy
  → unstaged 변경이 잔재 = reset 후 (선택) 사용자에게 확인
```

## 실측 워크플로 (jelly-tetris 2026-07-07 단계별)

### Step 1: 3 source 동시 fetch

```bash
# 1A. Vercel alias (anon, free URL)
curl -sL -o /tmp/vercel_live.html "https://<project>.vercel.app/"
echo "Vercel: $(md5 -q /tmp/vercel_live.html) / $(wc -l </tmp/vercel_live.html) lines"

# 1B. GitHub main HEAD raw
GH_SHA=$(curl -s "https://api.github.com/repos/<owner>/<repo>/commits/main" \
  | python3 -c "import sys, json; print(json.load(sys.stdin)['sha'])")
curl -sL -o /tmp/gh_main.html \
  "https://raw.githubusercontent.com/<owner>/<repo>/$GH_SHA/index.html"
echo "GitHub: $(md5 -q /tmp/gh_main.html) / $(wc -l </tmp/gh_main.html) lines"

# 1C. 로컬 working tree
echo "Local:  $(md5 -q /Users/mac/work/<project>/index.html) / $(wc -l </Users/mac/work/<project>/index.html) lines"
```

### Step 2: md5 대조표 + diff

```bash
diff -q /tmp/vercel_live.html /tmp/gh_main.html && echo "✅ Vercel ↔ GitHub IDENTICAL"
diff /tmp/gh_main.html /Users/mac/work/<project>/index.html | head -5
echo "---"
git -C /Users/mac/work/<project> rev-parse HEAD
git -C /Users/mac/work/<project> rev-parse origin/main
git -C /Users/mac/work/<project> status --short
```

### Step 3: unstaged diff 본체 + 카테고리화 (★ 이번 세션 핵심)

```bash
# 3A. JS 코드 변경 vs 단순 CSS 잔재 분류
DEL_JS=$(git -C <project> diff index.html | grep -E '^-' | grep -vE '^---' | grep -cE 'function|const|let|var|return|if|for|while')
INS_JS=$(git -C <project> diff index.html | grep -E '^\+' | grep -vE '^\+\+\+' | grep -cE 'function|const|let|var|return|if|for|while')
echo "deleted JS lines: $DEL_JS / inserted JS lines: $INS_JS"

# 3B. 한눈에 헤더 diff
git -C <project> diff index.html | awk '/^@@/ {n++; next} {if (n>=3) print}' | head -60
```

**판정**:

- **JS 큰 변경 (DEL/INS > 100줄)**: active code refactor — 보통 **의도된 새 버전**, commit + push + auto-deploy 흐름
- **CSS만 변경 / 추가 < 50줄**: 보통 단순 잔재, 사용자 확인 후 reset 또는 push
- **DEL/INS = 0**: 빈 diff, Vercel 비교만 다시

### Step 4: 사용자 액션 결정 (위임 패턴)

위임 받을 때 추천 흐름:

```text
진단 결과 보고 + 3-way 차이 표 + unstaged 카테고리 + 4옵션:
  A. commit + push + auto-deploy 의도된 새 버전 (추천)
  B. reset 후 redeploy (Vercel = GitHub HEAD 그대로 유지)
  C. 강제 vercel redeploy (Vercel 캐시 우회)
  D. 빈 commit `git commit --allow-empty -m "..."` + push (Vercel 트리거만)
```

**"위임할께" 신호 시 자동 추천 = A** (unstaged 변경이 새 버전이라는 가정 + 가장 보편적 흐름)

### Step 5: commit + push + 자동 재배포 트리거 + 검증

```bash
cd /Users/mac/work/<project>

# 안전 staging — 의도 변경만 add
git add index.html   # 의도 변경만. .gitignore 변경 등은 별도
git status --short

# commit (의도된 변경의 본질을 짧게 요약)
git commit -m "feat(<project>): <변경 요약>

<bullet list of key changes>
Vercel 자동 재배포 트리거됨.
Vercel live URL: https://<project>.vercel.app/

Live evidence (post-push):
- alias: 200 (재검증)
- bytes diff vs pre: 새 blob"

# push → Vercel GitHub App이 자동 트리거
git push origin main
```

### Step 6: 자동 배포 폴링 + alias 재검증

```bash
TOK=$(cat ~/.hermes/secrets/vercel_token.txt)

# 폴링 — 새로 prod deploy가 ● Ready 될 때까지 (보통 5~30초)
for i in 1 2 3 4 5 6 7 8 9 10 11 12; do
    NEW_DEPL=$(vercel ls --token "$TOK" 2>&1 | grep -oE '<project>-[a-z0-9]+-sigco3111s-projects\.vercel\.app' | head -1)
    if [ -n "$NEW_DEPL" ]; then
        AGE_LINE=$(vercel ls --token "$TOK" 2>&1 | grep -E "$NEW_DEPL" | head -2)
        echo "  attempt #$i: latest prod URL = $NEW_DEPL"
        echo "$AGE_LINE" | head -2 | sed 's/^/    /'
        break
    fi
    sleep 5
done
```

### Step 7: 5축 fresh evidence (post-push 확정)

```bash
# axis 1: alias 200
curl -s -o /dev/null -w "alias: %{http_code}\n" "https://<project>.vercel.app/"

# axis 2: alias byte-level md5
curl -sL -o /tmp/vercel_new.html "https://<project>.vercel.app/"
md5 -q /tmp/vercel_new.html

# axis 3: GitHub main HEAD @ new SHA md5
GH_NEW_SHA=$(git -C /Users/mac/work/<project> rev-parse HEAD)
curl -sL -o /tmp/gh_new.html "https://raw.githubusercontent.com/<owner>/<repo>/$GH_NEW_SHA/index.html"
md5 -q /tmp/gh_new.html

# axis 4: byte-level diff
diff -q /tmp/vercel_new.html /tmp/gh_new.html && echo "✅ IDENTICAL"

# axis 5: title 변경 반영
grep -oE '<title>[^<]+</title>' /tmp/vercel_new.html | head -1
```

## Vercel GitHub App 자동배포 의존성 확인

| 자동배포 안 되는 케이스 | 진단 명령 | 해결 |
|---|---|---|
| Vercel GitHub App 미설치 | `vercel ls` 의 "GitHub" 컬럼 부재 / Settings→Git | Vercel Dashboard에서 재연결 |
| App 권한 부족 | commit status API에 Vercel context 없음 | Vercel Settings → Git → authorize again |
| 푸시했지만 트리거 안 됨 | `last-modified` 헤더가 푸시 후 시간과 안 맞음 | App 권한 재설정 + empty commit retry |

**빈 commit 트릭 (auto-deploy 강제 트리거)**:
```bash
git commit --allow-empty -m "chore: trigger vercel redeploy" --no-verify
git push origin main
```
- 의도치 않은 commit 1개 추가되는 비용 (의미는 없는 메시지)
- 새 SHA 만들어 자동 트리거만 활성화

## 흔한 함정

### 함정 A: `vercel ls sigco3111s-projects/jelly-tetris` 형식 거부

Vercel CLI는 project-이름만 받습니다 (scope prefix ❌):
```bash
# ❌ 거부
vercel ls sigco3111s-projects/jelly-tetris
# Error: The provided argument "..." is not a valid project name

# ✅ 정상 — 인자 없이 ls하면 모든 프로젝트 표시
vercel ls
# 또는
vercel ls jelly-tetris
```

### 함정 B: `vercel inspect --format json` 출력이 stderr

```bash
# ❌ — JSON이 Vercel CLI 헤더에 묻혀 파싱 실패
vercel inspect "https://..." --token "$TOK" --format json | python3 -c "..."

# ✅ — 헤더 strip 후 파싱 (json.loads() raw.find('{') 기반)
vercel inspect "https://..." --token "$TOK" --format json 2>&1 > /tmp/inspect.json
python3 -c "
import json
raw = open('/tmp/inspect.json').read()
start = raw.find('{')
d = json.loads(raw[start:])
# ... d 사용
"
```

### 함정 C: 이전 deploy 검색 시 URL 매칭 실패

`vercel ls --token "$TOK" | grep` 패턴에서 team-scope prod URL은 hash-suffix 8자가 매칭되지 않으면 missed:
```bash
# ✅ regex 안정
vercel ls --token "$TOK" 2>&1 | grep -oE '<project>-[a-z0-9]+-sigco3111s-projects\.vercel\.app' | head -1
```

### 함정 D: GitHub main SHA가 빠른 polling으로 stale 인식

```bash
# 사용자가 방금 push → 즉시 commits/main API 호출 → 캐시 또는 race 가능
# 안전판 — 5초 sleep 후 fetch
sleep 5
GH_SHA=$(curl -s "https://api.github.com/repos/<owner>/<repo>/commits/main" \
  | python3 -c "import sys, json; print(json.load(sys.stdin)['sha'])")
```

### 함정 E: pre-commit 시 staging boundary 오염

staging 의도가 아닌 이전 세션 잔재(`M index.html`, `D *.png`)가 unstaged로 남아 있으면 `git add index.html` 한 줄만으로도 unstaged가 같이 add될 수 있어요. **항상 staging 직전에 `git status --short`로 의도 외 파일 확인**:
```bash
git status --short
# M index.html             ← 의도된 변경 (commit OK)
# D jelly-*.png           ← 이전 잔재 (unstaged 유지)
git add index.html        # 정확히 1개만 staged
```

## Push 후 자동배포 alias race 404 (vercel/SKILL.md 본문 참조)

푸시 직후 Vercel이 새 빌드 만드는 동안 alias가 10~30초간 HTTP 404 응답할 수 있음. **그래도 readme-template 검증은 raw.githubusercontent.com으로 → alias race 회피**:
```bash
# alias 검증은 마지막 (race window 통과 후)
sleep 15
curl -sI -o /dev/null -w "alias: %{http_code}\n" "https://<project>.vercel.app/"

# README raw는 race 영향 없음 — post-push 즉시 200 (raw CDN 캐시는 stale 가능)
curl -sI -o /dev/null -w "raw KR: %{http_code}\n" \
  "https://raw.githubusercontent.com/<owner>/<repo>/main/README.md"
```

## 적용 범위

- 단일 HTML 정적 사이트 (jelly-tetris 같은 coding-mission 결과)
- Vercel GitHub App 연결 자동배포
- 사용자 / GitHub / 로컬 3 source 비교가 가능한 모든 프로젝트

## 알려진 한계

- Vercel이 GitHub에 연결되지 않은 manual deploy 프로젝트는 이 패턴이 부분 적용 (auto-deploy 폴링 단계 skip)
- raw.githubusercontent.com의 raw CDN 캐시는 **5분 stale 가능** — 정확 비교는 REST API `/contents/` endpoint 사용 (`ad-hoc-verification-bash-heredoc-pitfall` 함정 11 + E.1 참조). 단 거의 모든 케이스에서 CDN 5분 안에 자동 반영되므로 raw fetch로 충분.

## 다음 적재 시그널

| 사용자 발화 | 이 reference 적용 |
|---|---|
| "배포된 거 다시 확인해줘" | Step 1~3로 Vercel + GitHub + 로컬 byte-level 비교 |
| "원본이랑 다른 것 같아" | Step 2 + 3으로 카테고리화 → 사용자에게 진단 보고 |
| "재배포해줘" / "다시 deploy" | Step 4 위임 또는 D(empty commit) + Step 5~7 |
| "force redeploy" | Step 5 빈 commit + Step 6~7 (auto-deploy 강제) |

## 관련 reference

- `vercel/SKILL.md` 본문 "팀스코프 anon 시 SSO 302" — alias 검증 시 팀스코프 prod 302 함정 회피
- `vercel/SKILL.md` 본문 "push 후 자동 재배포 확인 워크플로" — auto-deploy 트리거 후 확인 방법
- `vercel/references/jelly-tetris-full-cycle-mode.md` — Bootstrap 종료 후 deploy + README full-cycle (이 reference의 전 단계)
- `ad-hoc-verification-bash-heredoc-pitfall` 함정 11 + E.1 — raw CDN 캐시 vs REST API SHA 차원 통일
