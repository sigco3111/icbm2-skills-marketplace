# sigco-fruitbox Vercel webhook 복구 — 2026-08-07

## 컨텍스트
- 로컬: `/Users/mac/work/sigco-fruitbox` (Vite + React + TS + Tailwind 사과게임)
- GitHub: `sigco3111/fruitbox` (main 브랜치, 신규 생성 + push)
- Vercel: 기존 프로젝트 `sigco-fruitbox` (prj_fNLMAdVanUrId3Wb4a2A65BFs4C8) 이미 존재
- 핸드오프 직전 누군가 `vercel deploy` (CLI) 로 4h 전 production 배포 1건 존재

## 시나리오 타임라인

| 시각 (UTC) | 이벤트 |
|---|---|
| 2026-08-07T03:28:50Z | CLI 배포 (`dpl_4CDCzGDoGPHxDz7jLFBrL1j8qR2h`, source=cli, READY) |
| 2026-08-07T07:29:52Z | Vercel link 최초 생성 (link.createdAt) |
| 2026-08-07T07:30:39Z | 우리 `git push origin main` (initial commit 6b14b4e) |
| 2026-08-07T07:30:42Z | GitHub repo 생성 |
| 2026-08-07T08:01:01Z | 우리가 `vercel deploy --prod --yes` (CLI, source=cli) — 자동배포 트리거 안 됨이라 수동 |
| 2026-08-07T08:01:18Z | 빈 commit push → **자동 트리거 작동 확인** (source=git, READY, 17초 후) |

## 진단 단계 — 사용자가 두 URL로 의문 제기

### Q1: `@url: sigco-fruitbox-4hi13s51d-sigco3111s-projects.vercel.app/` 지금 여기에 배포된 상태인가?

**진단**:
```bash
# CLI로 배포 1건 조회
vercel ls --scope sigco3111s-projects | head -5
# → sigco-fruitbox (4h 전), source=cli, READY

# REST API로 source/gitMetadata 확인
curl -sS -H "Authorization: Bearer $TOK" \
  "https://api.vercel.com/v13/deployments/dpl_4CDCzGDoGPHxDz7jLFBrL1j8qR2h" \
  | jq '{source, gitMetadata, deployTrigger}'
# → source="cli", gitMetadata=null, deployTrigger=null
```

**결론**: Production URL에는 CLI로 배포한 4h 전 코드가 살아있고, 우리 main 푸시는 반영 안 됨. 자동배포가 죽어있는 상태.

### Q2: `@url: vercel.com/sigco3111s-projects/sigco-fruitbox` 여기에 깃허브 연결이 제대로 되었는지 확인해줘

**진단**:
```bash
# Vercel REST API: link 메타데이터 직접 조회
TOK=$(python3 -c "
import json, os
for path in ['/Users/mac/Library/Application Support/com.vercel.cli/auth.json',
             os.path.expanduser('~/.vercel/auth.json')]:
    if os.path.exists(path):
        print(json.load(open(path))['token']); break
")
PROJ_ID="prj_fNLMAdVanUrId3Wb4a2A65BFs4C8"
curl -sS -H "Authorization: Bearer $TOK" \
  "https://api.vercel.com/v9/projects/$PROJ_ID" | jq '.link'
```

**결과**:
```json
{
  "type": "github",
  "repo": "fruitbox",
  "repoId": 1326352000,
  "org": "sigco3111",
  "productionBranch": "main",
  "gitCredentialId": "cred_6459deea6843cbe0d0782939f3fe7e410d0859c8",
  "createdAt": 1786088392073,
  "deployHooks": []
}
```

→ **link는 살아있음** (type=github, repo=fruitbox, branch=main)

**하지만 GitHub webhook은 0개**:
```bash
gh api repos/sigco3111/fruitbox/hooks | jq 'length'  # → 0
```

→ link는 멀쩡한데 자동배포 webhook은 죽어있는 상태 (가장 잔인한 함정)

## 복구 시퀀스

### 1단계: 비대화형 disconnect
```bash
vercel git disconnect --yes
# → "Disconnected sigco3111/fruitbox."
```

**함정**: `--yes` 없으면 `? Are you sure you want to disconnect ... (y/N)`에서 hang. **반드시 비대화형 플래그 필수.**

### 2단계: 비대화형 connect
```bash
vercel git connect https://github.com/sigco3111/fruitbox --yes
# → "Found a repository in your local Git Config: https://github.com/sigco3111/fruitbox.git"
# → "Connecting GitHub repository: https://github.com/sigco3111/fruitbox"
# → "Connected"
```

### 3단계: link 메타 갱신 확인
```bash
curl -sS -H "Authorization: Bearer $TOK" \
  "https://api.vercel.com/v9/projects/$PROJ_ID" | jq '.link.createdAt'
# → 1786089643268 (이전 1786088392073 → 갱신됨, 약 125초 후)
```

### 4단계: 즉시 production 배포 (CLI로 1번, 그동안 사용자 코드가 반영되도록)
```bash
vercel deploy --prod --yes
# → Production      https://sigco-fruitbox-bg5qkxo00-sigco3111s-projects.vercel.app
# → ▲ Aliased       https://sigco-fruitbox.vercel.app
# → ✓ Ready in 11s
```

이 단계가 핵심 — disconnect+connect만으로는 기존 production URL이 옛 코드를 서빙하므로 사용자가 보기엔 변화 없음. **production을 한 번 새 코드 배포해야 alias가 갱신됨.**

### 5단계: 자동배포 트리거 검증 (★ 가장 빠른 신호)
```bash
# 빈 commit push
git commit --allow-empty -m "chore: trigger Vercel webhook test"
git push origin main

# 20~30초 대기
sleep 20

# 새 deployment의 source가 'git'인지
curl -sS -H "Authorization: Bearer $TOK" \
  "https://api.vercel.com/v6/deployments?projectId=$PROJ_ID&limit=3" \
  | jq '.deployments[] | {createdAt, source, state}'
```

**실측 결과**:
```
2026-08-07T08:01:18Z  source=git  state=READY     ← 자동 트리거 작동
2026-08-07T08:01:01Z  source=cli  state=READY     ← 우리가 직접 deploy
2026-08-07T03:28:50Z  source=cli  state=READY     ← 4h 전 기존 (link stale 시점)
```

→ 빈 commit push 후 **17초 만에** `source=git` deployment 출현 + READY. 자동배포 정상 복구.

### 6단계: production alias 실제 검증
```bash
curl -sI https://sigco-fruitbox.vercel.app | head -1
# → HTTP/2 200

curl -s https://sigco-fruitbox.vercel.app | head -10
# → <title>사과게임 · sigco fruitbox</title>
# → <script src="/assets/index-snSJS2x9.js">  ← 우리 build 자산 hash와 일치
```

## 핵심 교훈 5가지

### 1. `link.type=github` ≠ 자동배포 작동
- link 메타데이터는 살아있어도 자동배포 webhook은 죽어있을 수 있음
- 외관상 멀쩡한 link 상태가 가장 잔인한 false-positive

### 2. Vercel REST API가 link 상태를 결정적으로 보여줌
- `vercel ls`, `vercel inspect`로는 부족
- `GET /v9/projects/<id>`의 `.link` 객체가 SSoT
- 토큰은 macOS Application Support 캐시에서 추출

### 3. `vercel git disconnect/connect` 비대화형은 `--yes` 필수
- 다른 vercel 명령들과 동일 패턴이지만 명시 안 하면 hang

### 4. 빈 commit push가 자동배포 검증의 가장 빠른 신호
- 17초 안에 새 `source=git` deployment 출현
- 별도 Playwright/curl 검증 불요

### 5. disconnect+connect 후엔 production을 한 번 새로 배포
- 자동배포가 살아있어도 기존 alias는 옛 코드 그대로
- 사용자가 실제로 변화 보기 전엔 `vercel deploy --prod --yes` 1회 권장

## macOS Vercel CLI 58.7.1 캐시 위치 정정

**SKILL.md 기존 가정** (`~/.vercel/auth.json`) **틀림**:
- macOS + Vercel CLI 58.x: `~/Library/Application Support/com.vercel.cli/auth.json`
- 토큰 prefix: `vca_` (예: `vca_1Rx9...`, 60자)
- 다른 파일: `config.json`, `telemetry-session.json`, `telemetry-device.json`, `agent-preferences.json`

**자동 탐지 패턴**:
```bash
for path in \
    "/Users/mac/Library/Application Support/com.vercel.cli/auth.json" \
    "$HOME/.vercel/auth.json" \
    "$HOME/.local/share/com.vercel.cli/auth.json"; do
  [ -s "$path" ] && echo "FOUND: $path" && break
done
```

## Vercel REST API 엔드포인트 메모

| 용도 | 엔드포인트 |
|---|---|
| 프로젝트 메타 (link 포함) | `GET /v9/projects/<id>` |
| 프로젝트 목록 | `GET /v9/projects?limit=20` |
| 배포 목록 | `GET /v6/deployments?projectId=<id>&limit=N` |
| 단일 배포 메타 | `GET /v13/deployments/<deployment_id>` |

`/v9/projects/<id>/deployments`는 404 → `/v6/deployments?projectId=`로 우회.
