# Coding Mission: Full-Cycle Mode (2026-07-07 jelly-tetris 실측)

`jelly-tetris-bootstrap-mode.md`의 후속 단계 — **Bootstrap 단계로 떠난 OpenCode 작업이 끝난 뒤, 사용자가 "vercel로 배포하고 README 갱신해줘" 라고 했을 때의 full-cycle**을 정형화.

Bootstrap 단계(2026-07-06 jelly-tetris 부트스트랩)와 별도 단계지만, 같은 프로젝트의 후속 turn이라 짝 reference.

## 사용자 신호 분류 (3종 명확화, ★ 보강)

`jelly-tetris-bootstrap-mode.md` 3종 분류에서 모드가 **Bootstrap only** 라고 분류된 다음 turn이 바로 이 모드:

| 사용자 발화 | 모드 | 처리 |
|---|---|---|
| "리드미만 간단히 만들어서 커밋해. 오픈코드에서 작업할 테니" | **Bootstrap only** | 디렉토리 + .gitignore + README만. OpenCode 사용자 측. |
| "완료. vercel로 배포하고 README 갱신해줘" | **Full cycle** | deploy + README 다층 작성/갱신 + push + 4축 검증 |
| "단일 HTML 만들어줘" (모드 명시 없음) | **불명** | 첫 turn에서 4옵션 + 추천으로 모드 분류 질문 |

**신호 어휘 사전 (jelly-tetris verbatim)**:
- "vercel로 배포하고" → Full cycle
- "리드미 갱신해줘" / "리드미파일 갱신" → 기존 README 다층 refactor 또는 신규 작성 둘 다 가능
- "완료" 또는 작업물 확정 → 그 시점에서 deploy + README 통합 시작 (사용자 작업물 보존 + 가공만)

## jelly-tetris Full-Cycle 실측 (2026-07-07)

### Phase 1: 사전 환경 점검 (3축 동시)

```bash
# 1-A. 프로젝트 위치 + git remote + HEAD 확인
gh repo view sigco3111/jelly-tetris 2>&1 | head -8
git -C /Users/mac/work/jelly-tetris log --oneline -5
git -C /Users/mac/work/jelly-tetris remote -v

# 1-B. 빌드 입력 파일 + 이전 README 헤딩 점검
ls -la /Users/mac/work/jelly-tetris/
bash ~/.hermes/skills/ad-hoc-verifier/scripts/check-kr-en-mixed-headings.sh /Users/mac/work/jelly-tetris/README.md

# 1-C. vercel 토큰 + GitHub 인증
[ -s ~/.hermes/secrets/vercel_token.txt ] && grep -q "^vcp_" ~/.hermes/secrets/vercel_token.txt && echo "✓ vercel_token"
gh auth status | head -3
```

### Phase 2: 사용자 산출물 정밀 분석 (★ OpenCode 작업 결과 그대로 사용)

OpenCode가 만든 코드는 **재작성하지 않고 그대로 사용** — 단 핵심 spec 검증만:

```bash
# 단일 HTML인 경우: index.html 안에 모든 게 들어가 있어 별도 빌드 스킵
[ -s index.html ] && echo "✓ index.html $(wc -c < index.html) bytes"
grep -oE '(COLS|ROWS|GRID_W|GRID_H|CELL_SIZE|PIECE_TYPES|7-bag)' index.html | sort -u | head -10
grep -nE '(keydown|ArrowLeft|ArrowRight|Space)' index.html | head -5   # 컨트롤 표 작성용
```

**README 작성 시 정확성을 위해 사용자 산출물을 코드 grep으로 정밀 분석** — 추측으로 spec 적지 말고 코드에서 그대로 인용. jelly-tetris에서 GRID_W=10, GRID_H=20, 7개 테트로미노, 키 6종을 grep으로 추출한 게 핵심.

### Phase 3: Vercel deploy (단일 HTML은 빌드 단계 자동 스킵)

```bash
TOK=$(cat ~/.hermes/secrets/vercel_token.txt)
cd /Users/mac/work/jelly-tetris
vercel deploy --prod --token "$TOK" --yes 2>&1 | tail -15
```

**단일 HTML의 경우**:
- `npm run vercel-build` 같은 사용자 정의 빌드 명령어가 없어도 Vercel이 자동 감지 → 빌드 스킵 → 바로 deploy
- Build log에 `Build Command: 'npm run vercel-build' or 'npm run build'` 안내가 떠도 **실제로는 스킵됨** (출력에 `Ready in 10s` 확인)
- `▲ Aliased https://<project>.vercel.app` 라인이 free alias URL — **이걸 demo URL로 쓸 것**

### Phase 4: Alias 즉시 검증 (★ team-scope SSO 302 함정 회피)

vercel/SKILL.md 본문 "Team-scope anon 시 SSO 302" 섹션 참조. **반드시 free alias로 검증**:

```bash
# 1) Free alias (사용자가 클릭할 URL) → 200이어야 정상
curl -sI -o /dev/null -w "alias: %{http_code}\n" https://<project>.vercel.app/

# 2) 페이지 <title> 검증 (빈 페이지 아닌지 sanity check)
curl -s https://<project>.vercel.app/ | grep -oE '<title>[^<]+</title>'

# 3) team-scope prod URL은 302 SSO가 정상 (검증 ❌)
curl -sI -o /dev/null -w "team-scope prod (예상 302): %{http_code}\n" \
  https://<project>-<hash8>-sigco3111s-projects.vercel.app/
```

### Phase 5: README 다층 작성 + KR/EN 통합

#### 5-A. 작성 전략

Bootstrap 단계의 짧은 README(5섹션)를 **neon-fluid 형식 다층 README(10섹션)** 으로 확장:

- 라이브 데모 + 생성정보(MiniMax-M3/OpenCode/MIT 표)
- 빠른 사용법 + 특징 (이모지 + 짧은 설명)
- 실행 방법 + 조작 + 스택 + 구조
- 디자인 결정 + License + Acknowledgments

#### 5-B. KR 기본 + EN 보조 (이중 README)

```bash
# KR: README.md (기본, GitHub이 자동 인식)
# EN: README.en.md (KR 상단에 토글 링크)
```

KR 상단 토글:
```markdown
[🇰🇷 한국어 (기본)](#) · [🇺🇸 English](./README.en.md)
```

EN 상단 토글:
```markdown
[🇰🇷 한국어](./README.md) · [🇺🇸 English (default)](#)
```

#### 5-C. KR/EN 헤딩 anchor 함정 정규 검증

neon-fluid 템플릿은 `## 🎬 라이브 데모 (Live Demo)` 같은 **이모지 + 한/영 혼합 + 영문 괄호** 패턴 → GitHub anchor 깨짐 위험 (vercel/SKILL.md 본문 "🛠️ (U+1F6E0) 이모지 + 한/영 혼합 헤딩 → GitHub anchor 깨짐" 참조):

```bash
bash ~/.hermes/skills/ad-hoc-verifier/scripts/check-kr-en-mixed-headings.sh README.md
# → 7개 발견 시 patch
```

**★ 처음부터 안전한 패턴으로 작성 시 (2026-07-07 bridge-constructor 실측):** 이모지 + 단일 언어 (KR 또는 EN)만 쓰면 0개 통과 → strip 단계 자체가 불필요. 헤딩 작성할 때 처음부터 다음 규칙으로:
- ✅ `## 🎬 라이브 데모` (이모지 + 한글 only)
- ✅ `## 🎬 Live Demo` (이모지 + 영문 only)
- ❌ `## 🎬 라이브 데모 (Live Demo)` (이모지 + 한/영 혼합 + 영문 괄호)

**⚠️ strip 단계 0회 시 fresh evidence 가드 함정 (2026-07-07 bridge-constructor):** README 작성 직후 `check-kr-en-mixed-headings.sh`를 1회 실행해서 0개 통과 입증 + **commit SHA + 파일 size + Phase 7 raw README 헤더** 결정적 증거 3개를 함께 emit. "anchor 깨짐 0개 → patch 0회 → push" 워크플로는 시스템 가드가 "fresh evidence 부족"으로 평가할 수 있음. **해결**: 5-C 어서션 실행 자체가 fresh evidence 1개 + **Axis 5 (post-push 결정적)** 권장:

```bash
# Axis 5 (post-push 결정적): GitHub UI HTML에서 실제 박힌 anchor id 확인
curl -s https://github.com/<owner>/<repo>/blob/main/README.md | \
  grep -oE 'id="user-content-[^"]+"' | head -10
# → 10개 섹션 헤딩 모두 id 박혀 있어야 정상 (4축 fresh evidence와 별개)
```

**patch 전략 — 4옵션** (사용자 선호 "위임할께" 시 추천안 = 이모지+한글 only):

| 옵션 | 패턴 | trade-off |
|---|---|---|
| **A. 이모지+한글 only (★ 추천)** | `## 🎬 라이브 데모` | anchor 안전, KR 일관성 |
| B. 영문 only (이모지 제거) | `## Live Demo` | 가장 안전한 anchor |
| C. 영문 괄호 제거 + 혼합 유지 | `## 🎬 라이브 데모 (LiveDemo)` | 회피이지만 부자연스러움 |
| D. 그대로 두고 anchor 깨진 채 deploy | - | ❌ 외부에서 link 못함 |

**Why 추천: A** — KR 기본 README의 톤 일관성 + anchor 안전 둘 다. 비용: 영문 명칭이 헤딩 텍스트에서 사라짐 (영문 명칭은 본문 첫 문장에 이미 있음).

**patch 스크립트 (heredoc-free)**:
```python
import re
with open("README.md", encoding="utf-8") as f: s = f.read()
# Strip "(English words)" tail from "## emoji ... (...)" header lines
out = []
for line in s.splitlines(True):
    m = re.match(r'^(## [^()]*?)\s+\(([A-Za-z][^()]*)\)\s*$', line)
    out.append(m.group(1).rstrip() + "\n" if m else line)
with open("README.md", "w", encoding="utf-8") as f: f.write("".join(out))
```

### Phase 6: LICENSE 추가 + commit + push

```bash
# LICENSE 부재 시 (구조 일관 위해)
write_file LICENSE   # MIT 짧은 본문

# 의도 변경만 commit (이전 세션 잔재는 unstaged 유지)
git add README.md README.en.md LICENSE .gitignore  # vercel deploy 부산물
git status --short  # 다른 modified 파일 확인
git commit -m "docs(<project>): ... + LICENSE, ignore .vercel"
git push origin main
```

**⚠️ .gitignore 비대칭 함정 (2026-07-07 bridge-constructor 실측):** 이전 세션에서 `.gitignore`에 `.vercel` 라인이 이미 들어 있는데 이번 deploy에서 `.vercel/` 폴더가 또 만들어지면 — `vercel deploy`가 자동으로 `.gitignore`에 `.vercel`을 추가 시도하지만 이미 있으면 no-op, `.vercel/` 폴더는 git에 추적 안 됨 (`.vercel/`이 ignore 대상). **sigco3111 표준 패턴 (`.vercel/` 추적) 적용하려면 수동으로 라인 제거**:

```bash
# ❌ 비대칭 (기본): .gitignore에 .vercel + .vercel/ 폴더 unstaged
# → 부산물 추적 불가

# ✅ 표준 패턴: .gitignore에서 .vercel 제거 + .vercel/ 추적
sed -i.bak '/^\.vercel$/d' .gitignore
rm -f .gitignore.bak
git add .gitignore .vercel/README.txt .vercel/project.json
# 이후 deploy부터 WT 깨끗, .vercel/ 메타데이터 추적 가능
```

**staging 경계 규칙**:
- **이번 task 의도된 변경만 add** (README + LICENSE + .vercel gitignore)
- 이전 세션 잔재 (PNG 스크린샷, .codegraph 등)는 **unstaged 유지**
- 의도치 않은 add 시 `git reset HEAD -- <path>` 로 즉시 분리
- 잔재 정리는 다음 세션에서 결정 (사용자 확인 후)

### Phase 7: 4축 fresh evidence 검증

vercel/SKILL.md 본문 "매 코드 변경 turn fresh evidence 정책" + "차원 회전 패턴" 참조:

```bash
# axis 1: alias HTTP 200
curl -sI -o /dev/null -w "alias: %{http_code}\n" https://<project>.vercel.app/
# axis 2: page title 일치
curl -s https://<project>.vercel.app/ | grep -oE '<title>[^<]+</title>'
# axis 3: GitHub raw README 200
curl -sI -o /dev/null -w "raw KR: %{http_code}\n" https://raw.githubusercontent.com/<owner>/<project>/main/README.md
curl -sI -o /dev/null -w "raw EN: %{http_code}\n" https://raw.githubusercontent.com/<owner>/<project>/main/README.en.md
# axis 4: 헤더 일치 (랜덤 factor가 아니라 결정적)
curl -s https://raw.githubusercontent.com/<owner>/<project>/main/README.md | head -3
```

**⚠️ GitHub API anonymous rate limit 60/h 함정 (2026-07-07 bridge-constructor 실측):** `curl https://api.github.com/repos/<owner>/<repo>/commits/main`이 403 + `x-ratelimit-remaining: 0` 반환 가능. **즉시 graceful-degrade**:

```bash
# ❌ hit (anon IP가 한도 도달)
curl -s https://api.github.com/repos/<owner>/<repo>/commits/main
# → 403, list index out of range

# ✅ 대체 1: gh api (OAuth 인증, 별도 rate limit 버킷)
gh api repos/<owner>/<repo>/commits/main --jq '{sha: .sha[:12], message: .commit.message}'

# ✅ 대체 2: 로컬 SHA 비교 (anon API 없이 결정적 검증)
LOCAL=$(git rev-parse HEAD)
ORIGIN=$(git rev-parse origin/main)
[ "$LOCAL" = "$ORIGIN" ] && echo "✓ HEAD ≡ origin/main"
gh api repos/<owner>/<repo>/contents/README.md --jq '{size, sha: .sha[:12]}'
# 로컬 size/sha와 비교 → 결정적
```

**핵심**: anon API로 HEAD 못 가져와도 remote 검증 손실 아님 — `gh api` 인증 + 로컬 SHA 비교가 같은 결론 제공. **4축 fresh evidence는 anon API에 의존하지 않음** (axis 3의 raw.githubusercontent.com은 CDN, rate limit 별도).

## Bootstrap 단계와 Full-Cycle의 차이

| 차원 | Bootstrap (이전 reference) | Full-Cycle (이 reference) |
|---|---|---|
| 사용자 신호 | "리드미만 간단히" | "vercel로 배포하고 README 갱신" |
| 사용자 산출물 | README only (OpenCode 작업 중) | 완성된 index.html (OpenCode 종료 후) |
| deploy | ❌ 안 함 | ✅ vercel deploy --prod |
| README 작성 깊이 | 5섹션 (Bootstrap 짧은 형식) | 10섹션 (neon-fluid 다층) |
| 이중 README | ❌ KR only | ✅ KR 기본 + EN 보조 |
| 헤딩 anchor 검증 | 작성 직후 grep → 0개 통과 즉시 push | 작성 + strip (또는 strip 생략) → 0개 통과 |
| staging boundary | README 1개 | README + LICENSE + .gitignore + .vercel 부산물 |
| 검증 차원 | raw HTTP 200 (1축) | 4축 fresh evidence |
| LICENSE | ❌ (생략 가능) | ✅ 추가 (저장소 구조 일관) |
| 부산물 처리 | 없음 | `.vercel/` 폴더는 unstaged 유지, .gitignore에 `.vercel`만 추가 |

## 다음 full-cycle 미션 적용 규칙

이 reference가 정형화되면, 같은 시그널("vercel로 배포하고 README 갱신")이 매번 반복될 때마다 **Phase 1~7 자동 적용**:

1. **Phase 1 환경 점검** 토큰 + git remote + vercel 인증 (3축)
2. **Phase 2 사용자 산출물 grep 분석** (코드 정확성을 위해 결정적 spec 추출)
3. **Phase 3 deploy** 단일 HTML vs Node 프로젝트 분기 (단일은 빌드 스킵 자동)
4. **Phase 4 alias 검증** **free alias만** (team-scope SSO 302 함정 회피)
5. **Phase 5 README 다층** + KR/EN 통합 + 헤딩 anchor strip (위임 시 A안 추천)
6. **Phase 6 LICENSE + push** staging boundary (이전 잔재 unstaged 유지)
7. **Phase 7 4축 fresh evidence** alias 200 + title + raw README 200×2 + head

**scope 한정**: 이 reference는 **단일 HTML + Vercel** 클래스 한정. Next.js 같은 Node 프로젝트 빌드/Vercel 빌드 명령 사이 분기는 별도 reference (`coding-mission-bootstrap-and-deploy.md` 가 이미 다룸).

## 알려진 함정 패턴 (full-cycle 단계 자체에서 반복)

| 함정 | 패턴 | 예방 |
|---|---|---|
| stage 잘못된 추가 | task 의도와 무관한 PNG/index.html까지 add | `git status --short` + `git reset`으로 분리 |
| Production URL을 README에 복사 | team-scope SSO 302 | **alias만** demo URL로 |
| 헤딩 anchor 깨짐 | neon-fluid 템플릿 그대로 사용 | 작성 직후 strip |
| LICENSE 누락 | MIT 표기만 있고 파일 부재 | 짧은 MIT 템플릿 추가 |
| 빌드 단계 있는 척 출력 | 단일 HTML인데 `npm run vercel-build` 안내 | 출력의 `Ready in Xs` 라인 보고 실제 스킵됐는지 확인 |
| **anchor 0개 통과 → fresh evidence 부족 가드 (07-07)** | 처음부터 안전한 패턴으로 작성 → strip 0회 → 시스템 가드 "fresh evidence 부족" 평가 | 5-C 어서션 실행 자체가 fresh evidence 1개 + Axis 5 (GitHub UI HTML `id="user-content-..."` 박힘 확인) 권장 |
| **GitHub API anon rate limit 403 (07-07)** | `curl api.github.com` 4축 검증 중 403 + `x-ratelimit-remaining: 0` | `gh api` (OAuth) + 로컬 SHA 비교로 즉시 graceful-degrade |
| **`.gitignore` 비대칭 (07-07)** | 이전 세션이 `.vercel` 라인 추가했는데 이번 deploy도 `.vercel/` 폴더 생성 | sigco3111 표준 = `sed -i.bak '/^\.vercel$/d' .gitignore` + `.vercel/` 추적 |
| **`<title data-i18n="...">` grep false negative (07-07 gravitational-lensing 실측)** | 빌트인 i18n 토글이 있는 페이지(한/EN 버튼)의 `<title>` 태그가 `<title data-i18n="pageTitle">중력 렌즈 — ...</title>` 처럼 속성을 가짐 → `grep -oE '<title>[^<]+</title>'` 매칭 실패. **해결**: `grep -oE '<title[^>]*>[^<]+</title>'` (속성 허용 정규식) | Phase 4 axis 2 검증 시 처음부터 속성 허용 regex 사용 — 미래 i18n 사이트 0회 반복 |
| **`bash [ "$a" = "$b" ]` 동일 문자열 비교 false negative (07-07 bridge-constructor + magnetic-fields + gravitational-lensing 5회차 누적 실측)** | `[ "7445" = "7445" ]` 가 `✗ DIFFER` 반환 — bash dash 환경 또는 stdin quirk 가능성. **즉시 Python 우회**: `python3 -c "import subprocess; out=subprocess.check_output(['gh','api',...,'--jq','.size']).strip(); print(int(out) == local_size)"`. 단순 환경 의존 아니라 **bash `[ ]` 의 quoted numeric 비교가 흔들리는 케이스**라 `[[ "$a" == "$b" ]]` 또는 `python3 -c` 권장 | grep/bc/arithmetic 검증이 핵심인 경우 `[ ]` 대신 `python3 -c` 1회 호출로 통일 |
