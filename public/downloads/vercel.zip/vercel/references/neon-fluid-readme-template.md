# README "neon-fluid 14-section" template (2026-07-02 gray-scott)

## Context

After verifying several repos (`neon-fluid`, `gray-scott-reaction-diffusion`,
others), a stable 14-section README template has emerged. This file
documents the structure so future single-file WebGL / Canvas projects
don't reinvent it. This is the **post-Vercel-deploy** version of the
readme_template.md in this skill's references.

## Template

```markdown
# 🧪 <emoji> <repo-name>

> <one-sentence tagline> (max 120 chars)

<two-sentence hero paragraph explaining the visual / interactive hook>.

[🇰🇷 한국어 (기본)](#) · [🇺🇸 English](./README.en.md)

---

## 🎬 라이브 데모 (Live Demo)

> **👉 [https://<repo-name>.vercel.app/](https://<repo-name>.vercel.app/)** — 브라우저에서 바로 실행 (60fps)

| | |
|---|---|
| ![Demo](<shields>) | [![Repo](<shields>)](<github-url>) |
| ![Status](<shields>) | ![Stack](<shields>) |
| ![License](<shields>) | ![Deps](<shields>) |

### 🎮 빠른 사용법
1. 위 데모 링크 클릭 → 브라우저에서 페이지 열기
2. **마우스 인터랙션 1** — 결과
3. **마우스 인터랙션 2** — 결과
4. UI 컨트롤 — 슬라이더 / 버튼 / 프리셋
5. **단축키** — 키 목록

---

## 🤖 생성 정보 (Attribution)

| 항목 | 값 |
|---|---|
| **모델** | MiniMax-M3 |
| **실행 환경** | OpenCode CLI |
| **저장소** | [`sigco3111/<repo-name>`](<github-url>) |
| **라이브 데모** | [<alias-url>](<alias-url>) |
| **라이선스** | MIT |
| **의존성** | 없음 (Vanilla <stack>, 단일 HTML) |

### 📝 사용된 프롬프트 (원문)

\```
<original korean prompt here, verbatim>
\```

---

## ✨ 주요 특징 (Features)

- ⚡ **<feature1>** — 한 줄 설명
- 🔄 **<feature2>** — 한 줄 설명
- 🖱️ **<feature3>** — 한 줄 설명
- 🎛️ **<feature4>** — 한 줄 설명
- 📦 **단일 HTML** — 외부 의존성 0개
- 🔒 **온디바이스** — 모든 처리가 브라우저 안에서

---

## 🚀 실행 방법 (Quick Start)

### 방법 1: 라이브 데모 (가장 간단)
👉 [<alias-url>](<alias-url>) — 클릭 한 번

### 방법 2: 그냥 브라우저로 열기
\```bash
open index.html
\```

### 방법 3: 로컬 서버
\```bash
python3 -m http.server 8000
# → http://localhost:8000
\```

---

## 🎮 조작법 (Controls)

| 입력 | 효과 |
|---|---|
| **마우스 인터랙션** | 한 줄 설명 |
| **슬라이더 X** | 범위 + 단위 |
| **단축키** | 키 + 효과 |

### (옵션) 프리셋 표 / 시뮬레이션 파라미터 표

---

## 🛠️ 기술 스택 (Tech Stack)

| 영역 | 사용 기술 |
|---|---|
| **렌더링** | <API/version> |
| **시뮬레이션** | <algorithm> |
| **수치해석** | <method> |
| **입력** | <input API> |
| **UI** | <framework or vanilla> |
| **빌드** | 없음 (단일 HTML) |
| **의존성** | 없음 |

### (옵션) 수식 박스 — PDE / 알고리즘

---

## 📂 프로젝트 구조

\```
<repo-name>/
├── index.html      # 단일 HTML
└── README.md       # 한국어 (기본)
\```

---

## 🎨 디자인 결정 (Design Choices)

브레인스토밍 단계에서 내린 결정 4가지:

| 결정 포인트 | 선택 | 이유 |
|---|---|---|
| **결정 1** | 선택 | 이유 |
| **결정 2** | 선택 | 이유 |
| **결정 3** | 선택 | 이유 |
| **결정 4** | 선택 | 이유 |

### 직접 커스터마이즈하고 싶다면

\```js
const CONFIG = {
  KEY1: value,           // 설명
  KEY2: value,           // 설명
  // ... 더 많은 옵션은 코드 내 주석 참조
};
\```

---

## 🗺️ 로드맵 (Roadmap)

- [x] **v0.1** — 단일 HTML MVP
- [x] **v0.2** — 주요 기능
- [x] **v0.3** — Vercel 배포 + 라이브 데모  ← 항상 shipped
- [ ] **v0.4** — 다음 단계
- [ ] **v1.0** — 테스트 / 정식 출시

---

## 📜 License

MIT © 2026 sigco3111

---

## 🙏 Acknowledgments

- **모델**: MiniMax-M3 + OpenCode CLI
- **학술 / 레퍼런스**: <author, paper or github URL>
- **코딩미션 참조 페이지**: [cokac.com — 코드깎는노인](https://cokac.com/list/announcement/24)
```

## Rules of thumb distilled from this template

- 14 sections, always in this order. Skip a section rather than reorder.
- The "Live Demo" badges table always sits at row 2 (right after hero).
- shields.io badges use `for-the-badge` style for the live demo row and
  `flat-square` for the meta row below.
- Hero paragraph is 2 sentences: one for what it does, one for the hook.
- "Generation Info" attribution is mandatory for AI-coauthored projects.
- v0.1, v0.2, v0.3 of the roadmap are always checked before merging
  the README into the live repo (verify before commit, not after).
- Cross-link Acknowledgments to cokac.com — this is the coding-mission
  origin reference.
- Skip the English README file link if `README.en.md` does not exist yet
  (don't promise a translation that hasn't shipped).

## ⚠️ 이 템플릿의 한/영 혼합 헤딩은 그대로 두면 안 됨 (함정 17 v6.2 재발)

이 템플릿은 `## 🎬 라이브 데모 (Live Demo)`, `## 🛠️ 기술 스택 (Tech Stack)` 처럼 **이모지 + 한/영 혼합 + 영문 paren** 헤딩을 표준으로 박고 있음. **메모리에 함정이 박혀 있어도 코딩미션 bootstrap 단계에서 자동으로 떠올리지 못함**. 실측 (dynamic-web-strings, 2026-07-07): 1차 작성 직후 9개 헤딩이 모두 한/영 혼합 → GitHub HTML fetch에서 `user-content-️-기술-스택` (U+1F6E0 + U+FE0F 두 글자가 slug에 보존되어 비표준 prefix 발생) 또는 anchor 부재.

**반드시 commit 직전에 cleanup 단계 수행** — SKILL.md `함정 17 v6.2` 섹션의 "일괄 strip 단계" 참조. 동적 / 정적 코딩미션이 모두 영향.
