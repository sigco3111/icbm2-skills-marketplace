# Coding Mission: Bootstrap-Only Mode (2026-07-06 jelly-tetris 실측)

`coding-mission-bootstrap-and-deploy.md`의 0단계 "Bootstrap only" 분기를 jelly-tetris 사례 한 개로 구체화한 reference. **jelly-tetris**는 사용자가 명확히 "리드미만 간단히 만들어서 커밋해. 오픈코드에서 작업할 테니"라고 했고, 그게 정확히 Bootstrap only 모드 신호 — wind-tunnel-cfd는 같은 신호였지만 이번에 두 번째로 정확히 같은 패턴 반복.

## 사용자 신호 분류 (3종 명확화)

| 사용자 발화 | 모드 | 처리 |
|---|---|---|
| "리드미만 간단히 만들어서 커밋해. 오픈코드에서 작업할 테니" | **Bootstrap only** | 디렉토리 + .gitignore + README만. OpenCode 사용자 측. |
| "완료. vercel로 배포하고 README 갱신해줘" | **Full cycle** | deploy + README 작성/갱신 + push + 검증 |
| "단일 HTML 만들어줘" (모드 명시 없음) | **불명** | 첫 turn에서 4옵션 + 추천으로 모드 분류 질문 |

**신호 어휘 사전 (jelly-tetris verbatim)**:
- "리드미만" → Bootstrap only
- "오픈코드에서 작업할 테니" → OpenCode 핸드오프 신호, deploy는 다음 turn
- 미션 전체 미션 형태가 같아도 사용자 모드 의도는 매번 명확히 분류해야 함

## jelly-tetris Bootstrap 실측 (2026-07-06)

### Phase 1: 디렉토리 + git init
```bash
mkdir -p /Users/mac/work/jelly-tetris
cd /Users/mac/work/jelly-tetris
git init -b main
```

### Phase 2: README 작성 (Bootstrap only 단계 핵심)
jelly-tetris README는 **wind-tunnel-cfd 첫 README와 거의 같은 모양**:
- H1: `# Jelly Tetris`
- 한 줄 tagline
- 4-section: Overview / Features / Tech Notes / Attribution
- Attribution 표 + 원문 프롬프트 verbatim 박기
- Usage: open + http.server 두 옵션
- License: MIT

**차이점**: wind-tunnel-cfd 첫 README에는 "OpenCode will handle" 같은 핸드오프 단락 없었음 — jelly-tetris도 동일하게 **간단한 "Attribution" 섹션 + "Usage"만**. OpenCode가 작업할 내용은 README 섹션이 아니라 핸드오프 메시지로 전달.

### Phase 3: 사전 헤딩 검증 (★ strip 단계 생략의 핵심)

```bash
bash ~/.hermes/skills/ad-hoc-verifier/scripts/check-kr-en-mixed-headings.sh README.md
```

jelly-tetris 실측: README가 처음부터 한/영 혼합 헤딩 없이 작성됨 → **0개 통과** → Phase 4 strip 단계 자체를 생략 가능. **이게 가장 깔끔한 패턴** — wind-tunnel-cfd에서는 README 작성 시점에 패턴을 몰라서 한/영 혼합이 박혔고, Phase 4에서 strip하는 한 단계를 더 거쳤다.

**규칙 (Bootstrap only 단계에서 권장)**: README 작성 직후 `check-kr-en-mixed-headings.sh`로 0개 확인 → 그 즉시 push. strip 단계가 굳이 필요 없게 만드는 패턴.

### Phase 4: 커밋 + push

```bash
git add README.md
git -c user.name=sigco3111 -c user.email=sigco3111@users.noreply.github.com commit -m "Initial commit: project scaffold (README with OpenCode + MiniMax M3 attribution)"
gh repo create jelly-tetris --public --description "Jelly Tetris — soft-body physics puzzle game using Matter.js constrained meshes, squishy tetrominoes" --source=. --push --remote=origin
curl -sS -o /dev/null -w "README HTTP %{http_code}\n" https://raw.githubusercontent.com/sigco3111/jelly-tetris/main/README.md
```

**주의**: `gh repo create` 한 번에 `--push --remote=origin` 모두 처리하므로 별도 `git push` 불필요. `--remote=origin`을 빼먹으면 다음 push에서 `fatal: 'origin' does not appear to be a git repository` 터짐.

### Phase 5: 사용자 보고 (Bootstrap 종료)

```
| 항목 | 값 |
|---|---|
| 저장소 | https://github.com/sigco3111/jelly-tetris |
| 커밋 | <sha> |
| 헤딩 검증 | 한/영 혼합 0개 |
| raw README | HTTP 200 |
```

그리고 OpenCode 핸드오프 메시지 (다음 turn에서 OpenCode가 작업할 수 있도록):
```
cd /Users/mac/work/jelly-tetris
# 또는: gh repo clone sigco3111/jelly-tetris
```
+ 한 줄 미션: "`/Users/mac/work/jelly-tetris`에서 `index.html` 하나에 모든 코드를 담아 Matter.js soft-body 테트리스를 구현해줘. ... README Attribution 절대 수정 금지."

## wind-tunnel-cfd 대비 변경점

| 단계 | wind-tunnel-cfd (Bootstrap only #1) | jelly-tetris (Bootstrap only #2) |
|---|---|---|
| 사용자 신호 | "리드미만 간단히" | "리드미만 간단히" (verbatim 동일 패턴) |
| 헤딩 사전 검증 | ❌ 사전 grep 안 함 → Phase 4 strip에 의존 | ✅ 작성 직후 grep → 0개 통과 즉시 push |
| strip 커밋 | 필요 (배치 4개 헤딩 strip) | 불필요 |
| 커밋 수 | README 1개 (정제본) | README 1개 (정제본) |
| 푸시 검증 | raw README HTTP 200 | raw README HTTP 200 |

**교훈**: Bootstrap only 단계에서 **사전 헤딩 검증 한 줄**만 추가하면 strip 단계 통째로 제거 가능. 매 미션 시작 시 `writing the README → check-kr-en-mixed-headings.sh → push` 3-step 정규화 권장.

## 다음 미션 적용 (자동화 후보)

Bootstrap only 단계의 **3-step 워크플로를 helper로 정형화 가능**:

```bash
# ~/.hermes/skills/vercel/scripts/bootstrap-mission.sh (★ 미작성, 후보)
#!/usr/bin/env bash
set -eo pipefail
NAME="${1:?project name required}"
DESC="${2:?description required}"
WORKDIR="/Users/mac/work/${NAME}"

mkdir -p "$WORKDIR"
cd "$WORKDIR"
git init -b main -q

# README_TEMPLATE 생성 (README.md 작성은 사용자가 직접 — 컨텍스트 따라 다름)
echo "⚠️  README.md는 컨텍스트 따라 다르므로 직접 작성해주세요."
echo "권장 헤딩: 한국어 + 이모지만, 영문 괄호 섞지 말 것"
echo "Attribution 형식: MiniMax-M3 / OpenCode CLI"

# 1차 검증: 헤딩 안전성
if [ -s README.md ]; then
  echo "--- 헤딩 검증 ---"
  bash ~/.hermes/skills/ad-hoc-verifier/scripts/check-kr-en-mixed-headings.sh README.md
fi
```

**현실**: helper는 만들지 않았고 매 turn 인라인으로 처리. 미션 패턴이 정형화되면 helper로 빼는 게 다음 단계.

## OpenCode 핸드오프 메시지 형식 (★ 보강)

jelly-tetris에서 사용한 핸드오프 형식:

```
오픈코드 미션 한 줄:
> `/Users/mac/work/jelly-tetris`에서 `index.html` 하나에 모든 코드를 담아 Matter.js soft-body
> 테트리스를 구현해줘. 10×20 그리드, 7-bag 표준 회전 규칙, 각 테트로미노 = 입자 메시 + 거리/강성 제약,
> Canvas 2D로 변형된 형태 매 프레임 fill. README Attribution 절대 수정 금지.
```

wind-tunnel-cfd 핸드오프 형식과 **거의 동일** — 패턴 추출 가능:
- 경로 절대 명시
- `index.html` 단일 파일 강제
- 핵심 알고리즘 키워드 3~5개 (그리드 / 표준 / 메시 + 강성 / Canvas)
- "README Attribution 절대 수정 금지" 마무리 — 이 줄이 빠져도 되지만 OpenCode가 README를 refresh하다가 Attribution을 실수로 수정하는 사례 예방.

## 다음 full-cycle이 왔을 때의 핸드오프

이 reference 자체가 Phase 1 (Bootstrap only) 전용이므로, jelly-tetris OpenCode 작업이 끝나고 사용자가 "vercel로 배포하고 README 갱신해줘"라고 하면 → 본 skill의 `wind-tunnel-cfd-deploy.md`로 회귀. 3-step 워크플로는 양쪽 다 동일:
1. Vercel 토큰 점검 + whoami
2. vercel link + vercel deploy --prod
3. Playwright 시각 검증 + vision_analyze
4. README 헤딩 strip (이번엔 사전 검증으로 0개라 strip 생략 가능)
5. raw README + alias 200 + vercel ls Ready

## jelly-tetris vs wind-tunnel-cfd 코드 컨셉 (OpenCode 미션 결과 예측용)

Bootstrap 단계에선 알 수 없지만, 두 미션의 코드 컨셉은 명확히 다름:

| 차원 | wind-tunnel-cfd | jelly-tetris |
|---|---|---|
| 핵심 라이브러리 | 자체 LBM D2Q9 (외부 의존 0) | Matter.js (CDN) |
| 렌더링 | Canvas 2D ImageData | Canvas 2D (Mesh fill trace) |
| 격자/물리 해상도 | 200×100 고정 | 10×20 + soft-body 변형 |
| 입력 | 마우스 드래그 (장애물 그리기) | 키보드 (좌/우/회전/드롭) |
| 시각 검증 시 의도 확인 | 실린더 후류·가속 밴드 가시화 | 블록이 떨어져 쌓이며 wobble/squish 가시화 |

**Phase 4 vision_analyze 질문 분기** (OpenCode 작업 결과 보고 시):
- wind-tunnel-cfd: "Is there a working 2D wind tunnel CFD visualization with a heatmap?"
- jelly-tetris: "Is there a working Tetris game with visibly wobbly/squishy soft-body blocks?"

이 분기는 정형화되어 다음 미션에서 매번 분기 가능.
