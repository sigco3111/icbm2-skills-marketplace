# Hermes sub-shell 환경변수 격리 — redeploy 블로커 진단 (2026-07-27 evolve-kr v3 실측)

## 문제

`terminal(command='vercel --prod --token "$VERCEL_TOKEN" ...')` 호출 시 `Error: You defined "--token", but it's missing a value` 또는 `Error: No existing credentials found`로 실패. 부모 셸에서 `echo $VERCEL_TOKEN`은 정상 출력.

## 근본 원인

Hermes의 `terminal` tool은 **각 호출마다 새 sub-shell을 fork**한다. 부모 zsh 프로세스의 `export VERCEL_TOKEN=...`은 그 zsh 프로세스의 환경 테이블에만 있고, 자식 sub-shell은 `~/.zshrc` / `~/.zshenv`을 자동으로 re-source하지 않는 환경(예: `bash -c` 또는 비대화형 spawn)에서는 export 변수를 보지 못한다.

`~/.zshrc`에 `export VERCEL_TOKEN=...`가 있어도, 비대화형 sub-shell은 `~/.zshrc`를 source하지 않는 게 macOS 기본 (login shell vs non-interactive shell 차이).

## 즉시 진단 패턴 (4단계)

```bash
# 1단계: sub-shell에 박혀있는지 확인 (이게 가장 결정적)
echo "VERCEL_TOKEN='$VERCEL_TOKEN'" | sed 's/[A-Za-z0-9]\{4\}/<redacted>/g'
# → "<redacted>: <redacted> <redacted>: "  → 빈 값

# 2단계: 토큰 파일 직접 cat (parent shell과 격리됨)
ls -la ~/.hermes/secrets/vercel_token.txt 2>&1
TOK=$(cat ~/.hermes/secrets/vercel_token.txt 2>/dev/null)
echo "TOK length: ${#TOK}"  # → 0이면 파일 없거나 비어있음

# 3단계: 1차 시도 — env var 우선
vercel whoami --token "${VERCEL_TOKEN:-novalid}" 2>&1 | head -3
# → "Error: You defined..."  → env var 사용 불가 확인

# 4단계: 2차 시도 — 토큰 파일 직접
TOK=$(cat ~/.hermes/secrets/vercel_token.txt)
vercel whoami --token "$TOK" 2>&1 | head -3
# → "sigco3111"  → OK이면 이 경로로 redeploy
```

## 규칙

1. **Hermes terminal() 호출은 항상 sub-shell 격리 가정**. 부모 셸의 `export` 변수는 신뢰하지 말 것.
2. **시크릿은 항상 파일 경로로 cat**: `TOK=$(cat ~/.hermes/secrets/vercel_token.txt)` — env var `$VERCEL_TOKEN` 사용 ❌.
3. **2단 fallback 패턴 표준화**:
   ```bash
   TOK="${VERCEL_TOKEN:-}"
   [ -z "$TOK" ] && TOK="$(cat ~/.hermes/secrets/vercel_token.txt 2>/dev/null)"
   [ -z "$TOK" ] && { echo "❌ 토큰 없음 — ~/.hermes/secrets/vercel_token.txt 확인 필요"; exit 1; }
   vercel --prod --yes --token "$TOK"
   ```
4. **대안: `~/.zshenv`에 영구 박기** — `~/.zshenv`는 non-interactive shell에서도 자동 source되므로, 부모 셸에 `export VERCEL_TOKEN=...` 추가 후 **새 Hermes 세션 시작**하면 그때부터 sub-shell에서도 잡힘. 단 **기존 세션에는 영향 없음**.

## 진짜 원인 진단 매트릭스

| 증상 | sub-shell env var | 토큰 파일 | 해결 |
|---|---|---|---|
| `--token missing value` | ❌ 빈 값 | ✅ 존재 + valid | **파일 cat 우선 패턴** |
| `No existing credentials found` | ❌ 빈 값 | ❌ 부재 | 토큰 발급 또는 사용자에게 `/login` 위임 |
| `The specified token is not valid` | ✅ 값 있음 (또는 파일) | ❌ invalid | 토큰 회전 |
| `... 302 SSO` | ✅ 정상 | ✅ 정상 | team-scope URL 문제, free alias 사용 |

## evolve-kr v3 실측

```
$ echo "$VERCEL_TOKEN" | sed 's/[A-Za-z0-9]\{4\}/<redacted>/g'
<redacted>: <redacted> <redacted>:       ← 부모 셸 변수 sub-shell에서 빈 값

$ TOK=$(cat ~/.hermes/secrets/vercel_token.txt 2>/dev/null)
$ [ -z "$TOK" ] && echo "❌ 파일도 부재"
❌ 파일도 부재                              ← 토큰 파일도 부재

$ vercel whoami
Error: No existing credentials found.     ← 두 경로 다 실패 → "redeploy 차단"
```

→ redeploy가 두 가지 모두 불가능한 상태. 가장 빠른 우회:
- 사용자가 **Vercel 웹 UI에서 직접 Redeploy** 클릭
- 또는 토큰을 1Password에서 export해 subagent에 주입
- 또는 `vercel login` (인터랙티브) — 헤드리스 subagent에서는 불가

## 라이브 검증 헤더 falsification 패턴

redeploy 시도가 실패했는지 결정적으로 입증하는 헤더 3종 (live URL에 curl -I):

```bash
curl -sI "https://<project>.vercel.app/evolve/main.js" --max-time 15 | \
  grep -iE "etag|last-modified|x-vercel-cache"
# → etag: "097252116ca2465a49c686b07efde89e" (unchanged from previous probe)
# → last-modified: Mon, 27 Jul 2026 07:53:57 GMT (earlier than this session)
# → x-vercel-cache: HIT
# = Vercel이 여전히 옛 번들 서빙 중 = 새 배포 안 됨
```

**결정적 falsification**: 위 3개 헤더 중 **2개 이상**이 이전 probe와 동일하면, "redeploy 시도"는 성공이 아니다. 보고 시 "redeploy 완료"라고 쓰면 fabricate.

## GitHub push ≠ Vercel redeploy (★ 2026-07-27 실측 확정)

`git push origin main` 성공은 **GitHub HEAD만 갱신**한다. Vercel이 자동 배포하려면:

1. **Vercel 웹에서 Import 한 번 완료** (신규 저장소 첫 배포 시) — GitHub App + webhook 설치
2. **또는 GitHub repo에 vercel webhook 존재** (import 후 자동) — `gh api repos/<owner>/<repo>/hooks`로 확인 가능

`evolve-kr` 실측:
```bash
gh api repos/sigco3111/evolve-kr/hooks | grep -oE "vercel\.com|vercel-deploy"
# (empty)  ← Vercel webhook 부재
```

→ push는 GitHub에만 도달. Vercel은 옛 alias 그대로 서빙. 자동배포 활성화하려면:
- Vercel 대시보드 → "Add New Project" → Import → 첫 빌드 트리거
- 이후 push마다 자동 배포

**판단 기준**: 라이브 etag/last-modified가 stale이고 push만 했다면 → "redeploy 안 됨" 정직 보고.

## 보고 의무 (fabricate 금지)

redeploy 시도가 어떤 단계에서 막혔든, **다음 4개 사실을 모두 사용자 보고**:

1. 로컬 빌드 성공 여부 + 사이즈
2. git push 성공 여부 + commit SHA
3. vercel CLI 호출 결과 (실패 시 정확한 에러 메시지)
4. 라이브 URL의 etag/last-modified 상태 (변했는지 안 변했는지)

4개 중 하나라도 "❌"이면 "redeploy 완료"는 fabricate. "부분 완료 (push는 됐지만 Vercel 자동배포는 안 됨)" 같이 솔직하게 보고.

## 다음 subagent 핸드오프 노트

이 reference가 발견되면 다음 subagent는:
1. **첫 vercel 호출 전에** `echo $VERCEL_TOKEN | wc -c` 로 sub-shell env var 박힘 확인
2. 박혀있지 않으면 즉시 `TOK=$(cat ~/.hermes/secrets/vercel_token.txt)` 패턴으로 fallback
3. 둘 다 실패하면 사용자에게 `vercel login` 또는 토큰 주입 요청
4. 라이브 검증은 항상 etag + last-modified + x-vercel-cache 3종 동시 비교