# `.gitignore` vs `git ls-files` mismatch — rebuild + commit 패턴 (2026-07-27 evolve-kr v3 실측)

## 문제

`.gitignore`에 `evolve/main.js`가 박혀있지만, **이미 Git에 tracked 상태**인 파일을 esbuild가 다시 빌드하면:

```bash
$ git status --short
 M evolve/main.js     # ← modified로 표시 (staged 아님)

$ git add evolve/main.js
# → ??? .gitignore에 박혀있는데 어떻게 modified로?
```

## `.gitignore`의 두 가지 동작

| 상태 | 동작 |
|---|---|
| **Untracked 파일 (한 번도 `git add` 안 됨)** | `.gitignore`에 매치되면 `git add`가 무시 |
| **Tracked 파일 (한 번이라도 `git add` 됨)** | `.gitignore` 매치되든 말든 **이미 추적 중**. `git add`가 정상 작동 |

**즉, `.gitignore`는 untracked 파일만 차단**. 한번이라도 인덱스에 들어간 파일은 ignore되어도 modified로 계속 잡힘.

## evolve-kr v3 실측

```bash
$ cat .gitignore | grep -E "main\.js|wiki\.js"
evolve/main.js
wiki/wiki.js

$ git ls-files evolve/main.js wiki/wiki.js
evolve/main.js
wiki/wiki.js           # ← 둘 다 tracked 상태

$ grep -c "ko-KR" src/vars.js
2

# esbuild rebuild → evolve/main.js 2.2MB 새로 생성
$ npm run evolve

$ git status --short
 M evolve/main.js     # ← modified (staged 아님)
 M src/vars.js
 M wiki/wiki.js

# ⚠️ .gitignore 매치이지만 tracked이므로 modified로 정상 표시
```

## 표준 rebuild + commit 패턴

```bash
# 1) 빌드
npm run evolve
npm run evolve-less
npm run wiki
npm run wiki-less

# 2) staged 검증 — 명시적 경로 (git add . 보다 안전)
git add src/vars.js evolve/main.js wiki/wiki.js

# 3) commit
git -c user.name="Hermes" -c user.email="hermes@nous.local" commit -m "feat(i18n): ..."
git push origin main

# 4) WT clean 확인
git status --short    # → 비어있어야 정상
```

`git add -f` (`force`)는 **untracked ignore 파일을 강제 add**할 때 쓰는 옵션. evolve-kr처럼 이미 tracked인 파일은 `-f` 불요.

## 흔한 함정 회피

| 함정 | 증상 | 해결 |
|---|---|---|
| `git add .` 후 commit → .gitignore 무시됨 | tracked 파일이 commit됨 | 명시적 경로 staging 또는 의도적 commit |
| `.gitignore` 추가하면 tracked 파일도 untracked 됨 | ❌ 안 됨 | `git rm --cached` 필요 (의도적 untrack) |
| 빌드 산출물 커밋 안 됨 | Vercel 자동 배포 안 됨 | 위 표준 패턴으로 명시 commit |
| Build artifact 이미 tracked → .gitignore 추가 무의미 | 그대로 commit됨 | `git rm --cached` + .gitignore 추가 + commit |

## Vercel 자동배포와의 관계

Vercel은 `git push` → webhook으로 자동 배포. **GitHub HEAD에 build artifact (`evolve/main.js`)가 박혀있어야** 자동 배포 후 라이브 번들에 새 코드가 반영됨.

만약 빌드 산출물을 commit 안 하고 `.gitignore`로만 추적 제외하면:
- Vercel 빌드 머신은 **자체 빌드**를 다시 돌림 (`package.json`의 `buildCommand`)
- 이건 사용자 로컬 빌드와 다른 환경/Node 버전/캐시 상태 → **결정성 깨짐**

**권장**: 로컬 빌드 + commit + push 패턴이 가장 결정적. Vercel 빌드 머신에 의존하면 안 됨.

## 진짜로 build artifact를 untrack하고 싶을 때

`.gitignore`에 추가만 해선 안 됨. **두 단계**:

```bash
# 1) .gitignore에 추가
echo "dist/" >> .gitignore

# 2) 인덱스에서 제거 (실제 파일은 디스크에 남음)
git rm --cached -r dist/

# 3) commit
git add .gitignore
git commit -m "chore: dist/ untrack + .gitignore 추가"
```

evolve-kr는 의도적으로 `evolve/main.js`, `wiki/wiki.js`를 tracked 상태로 유지 (Vercel 자동 배포 + bit-perfect 검증 모두 Git HEAD가 source of truth).

## 체크리스트

rebuild + commit 워크플로 시작 전:
- [ ] `git ls-files evolve/main.js wiki/wiki.js` — 추적 상태 확인
- [ ] `.gitignore` 매치 여부 확인 (tracked면 modified로 정상 표시됨)
- [ ] 빌드 후 `git status --short` — modified 파일 목록
- [ ] 명시적 `git add <file>` — staged
- [ ] commit + push
- [ ] WT clean (`git status --short` 비어있음)
- [ ] 라이브 etag + last-modified 변화 확인 (redeploy 검증)