# Coding-mission bootstrap + deploy 사이클 (2026-07-06 cloth-simulation + interactive-metaballs 실측)

두 코딩미션을 연속으로 진행하면서 추출한 **bootstrap → OpenCode → deploy → README 갱신 → 검증** 4-phase 통합 가이드.

## 0. 사용자 워크플로 의도 (pre-flight)

사용자가 코딩미션을 요청할 때 보통 두 가지 모드 중 하나:

| 모드 | 사용자 신호 | 초기에 할 일 |
|---|---|---|
| **Bootstrap only** | "리드미만 간단히 만들어서 커밋해" "오픈코드 작업할 테니" | (1) 디렉토리 + .gitignore + LICENSE + bilingual README만. OpenCode는 사용자 측. |
| **Full cycle** | "완료. vercel로 배포하고 README 갱신해줘" | (1) deploy + (2) README 작성/갱신 + (3) push + (4) 검증 |

**흔한 오해**: 사용자가 README만 만들라고 했는데 vercel deploy까지 해버림 → 2차 turn 낭비. 첫 요청에서 모드 명확히 분류.

## 1. Bootstrap 단계 (Phase 1)

### 1.1 디렉토리 + .gitignore (함정 19 + 19b 예방)

```bash
mkdir -p ~/work/<name>
cd ~/work/<name>
git init -q
```

`.gitignore` **첫 commit부터** `.vercel/` 미리 박기 (함정 19 — OpenCode가 자동 수정 못 함):

```gitignore
# Vercel (pre-add)
.vercel/

# OpenCode/Claude/Codex 메타 디렉토리
.codegraph/
.omo/
.playwright-mcp/

# Node/IDE
node_modules/
dist/
build/
.idea/
*.swp

# Env
.env
.env.local
.env.*.local

# OS
.DS_Store
Thumbs.db
```

**함정 19b (2026-07-06 신발견)**: `.gitignore`에 같은 패턴이 **분리된 두 섹션**에 있으면, 첫 번째 섹션만 patch해도 두 번째는 그대로 — `git add .vercel` 이 계속 거부됨. `grep -n vercel .gitignore`로 한 번에 모두 확인.

### 1.2 bilingual README (네온-fluid 14-section 형식)

neon-fluid 템플릿 (이 skill의 `neon-fluid-readme-template.md`) 정확히 따름. 핵심:

- **Live Demo 섹션**: bootstrap 단계엔 🛠️ In Progress 배지로 placeholder만. Deploy 후 별도 커밋으로 real URL 박기.
- **Attribution**: `MiniMax-M3` / `OpenCode CLI` / 저장소 명시 — **양쪽 README verbatim**.
- **사용된 프롬프트 (원문)**: 한국어 본문 + `Implementation Advice:` 코드블록 안에 verbatim 박기 — 양쪽 README 모두 **코드블록 안 한국어 verbatim 강제** (함정 16 D17).
- **예정 섹션** (Features/Controls/Tech Stack/Design Choices): bootstrap 단계엔 "예정" / "(filled in during build)" 으로 자리만. 사용자가 모든 코드 작성 후 별도 갱신에서 채움.

### 1.3 ⚠️ anchor 깨짐 헤딩 미리 정리

부트스트랩 단계의 README엔 신경 안 쓰지만, **deploy 직전 README 갱신 시 한/영 혼합 헤딩 정리 필수** — ⚠️ 4단계:

| 헤딩 패턴 | GitHub HTML id | 안전 여부 |
|---|---|---|
| `## 🛠️ 기술 스택 (Tech Stack)` (이모지+한/영+영문 괄호) | ❌ anchor 깨짐 | **위험 — 모두 정리** |
| `## 🛠️ 기술 스택` (이모지+한글 only) | ✅ 이중 하이픈 prefix | 안전 |
| `## Tech Stack` (영문 only, 이모지 제거) | ✅ 단일 하이픈 | 가장 안전 |

**모든 이모지**에서 동일 위험 (🛠️만이 아님 — 🎮 🎨 ✨ 🚀 🤖 🎬 모두). cloth-simulation v1 + interactive-metaballs v0 실측으로 확정.

**부트스트랩 단계 권장**: README 작성 시 처음부터 모든 헤딩을 **한글 only + 이모지** 패턴으로 통일하면 deploy 후 anchor 깨짐 안 남. (예: `## 🚀 실행 방법` O / `## 🚀 실행 방법 (Quick Start)` X)

### 1.4 gh repo create (Bootstrap 종료 시점)

```bash
gh repo create sigco3111/<name> --public \
  --description "<한 줄>" --source=. --remote=origin --push
```

푸시 1건, WT clean 상태로 종료.

## 2. OpenCode 작업 단계 (사용자 측)

사용자가 OpenCode CLI 환경에서 `index.html` 자동 생성 + push. **bootstrap 단계에선 Hermes가 손 안 댐**.

OpenCode가 다음 3개 부산물 자동 생성 (함정 19 분산):
- `AGENTS.md` — 프로젝트 지식 베이스. 추적 의도 (보통 무해).
- `.codegraph/` — OpenCode 메타 디렉토리. `.gitignore`로 격리.
- `.gitignore` 자동 수정 — `.vercel` 라인을 끝에 추가.
- `.vercel/` — vercel CLI 부산물 (deploy 후). 추적 의도.

## 3. Deploy 단계 (Phase 2)

### 3.1 사전 점검 (cloth-simulation 패턴)

```bash
# 1. 인증 (helper .tmp-step1-auth.sh)
[ -s ~/.hermes/secrets/vercel_token.txt ] && grep -q "^vcp_" ~/.hermes/secrets/vercel_token.txt
TOK=$(cat ~/.hermes/secrets/vercel_token.txt)
vercel whoami --token "$TOK"

# 2. index.html 사이즈 + 의존성 0개 확인
wc -c index.html
grep -oE "https?://[a-zA-Z0-9./_-]+\.(js|css)" index.html | sort -u
# (0줄이어야 단일 HTML 의도 충족)
```

### 3.2 vercel deploy

```bash
vercel --yes --prod --token "$TOK" 2>&1 | tail -25
```

출력에서 **`▲ Aliased`** 라인의 URL을 박아야 할 alias. suffix 자동 할당 패턴:

| 시나리오 | 할당 결과 |
|---|---|
| 미점유 | `<project>.vercel.app` |
| 점유됨 (1번) | `<project>-one.vercel.app` |
| 점유됨 (2번) | `<project>-two.vercel.app` |

`vercel ls <project>` 출력에서 실제 alias 확인.

### 3.3 bit-perfect 검증

```bash
ALIAS=$(curl -s "https://api.vercel.com/..." | jq -r .alias)  # 또는 출력에서
TMP=$(mktemp)
curl -sL -A "hermes-verify/1.0" "$ALIAS" -o "$TMP"
LOCAL_SHA=$(shasum -a 256 index.html | awk '{print $1}')
ALIAS_SHA=$(shasum -a 256 "$TMP" | awk '{print $1}')
[ "$LOCAL_SHA" = "$ALIAS_SHA" ] && echo "bit-perfect OK"
```

**cloth-simulation 30912 bytes**, **interactive-metaballs 73916 bytes** 모두 1회 deploy에서 bit-perfect = 강 시그널.

## 4. README 갱신 단계 (Phase 2의 일부)

### 4.1 ⚠️ anchor 깨짐 헤딩 정리 (deploy 직전)

neon-fluid 템플릿 그대로 쓸 때 흔히 빠지는 7~8개 한/영 혼합 헤딩. **부트스트랩 단계에서 이미 정리하지 않았다면 deploy 직전 일괄 정리 필수**.

```bash
# 일괄 검출 (모든 이모지 포함, 라인 anchor)
grep -nE "^## [🎮🎨✨🚀📂🤖🎬🛠️📜🙏] [^#\n]*\([^)\n]*[A-Z][^)\n]*\)\s*$" README.md
# → 7~8개 결과. 모두 영문 괄호 부분 제거:
#    ## 🎬 라이브 데모 (Live Demo) → ## 🎬 라이브 데모
```

### 4.2 임시 섹션 (予定 → 확정)

- Features: OpenCode 결과 보고 5~8개 항목 — 핵심 알고리즘 / 데이터 구조 / 성능 / 사용자 인터랙션
- Controls: 입력 + 슬라이더 + 단축키 표
- Tech Stack: 사용 라이브러리 / API / 데이터 구조 / 루프 / 의존성
- Design Choices (가장 중요): 브레인스토밍 단계 결정 4가지 — 각 결정 + 선택 + 이유. **코드 컨셉 추출로 채우기**:

```bash
# OpenCode가 만든 코드에서 클래스/함수/shader 키워드 grep
grep -oE "(class [A-Z][A-Za-z]+|function [a-zA-Z]+\(|uniform [a-z]...)" index.html | sort -u
# → 결정 근거로 사용
```

### 4.3 .gitignore 정리 + .vercel/ 추적

```bash
# .gitignore에 .vercel/ 자동 추가됨 (OpenCode 부산물) → sigco3111 표준 패턴은 추적
sed -i.bak '/^\.vercel$/d' .gitignore  # 또는 두 섹션 모두 patch
rm -f .gitignore.bak

git add .gitignore README.md README.en.md .vercel/project.json .vercel/README.txt
git commit -m "docs: README KR/EN — adopt neon-fluid template..."
git push origin main
```

### 4.4 자동배포 즉시 검증

```bash
sleep 8
curl -sI -A "hermes-verify/1.0" "https://<name>.vercel.app" | grep -i last-modified
# → 푸시 시점 ±수십초 → 자동배포 OK
```

## 5. 검증 단계 (fresh evidence 회전)

`ad-hoc-verification-bash-heredoc-pitfall` + `vercel` skill의 차원 회전 패턴 적용. **매 라운드 다른 차원 + mutation SHA 신규 발행 + cleanup 어서션 통합**:

| 라운드 | 차원 | 핵심 어서션 |
|---|---|---|
| v0 | D11 alias bit-perfect + D7 strict regex (anchor 깨짐) | 73916 bytes SHA 일치 + 한/영 혼합 0개 |
| v1 | D8 (UTF-8 BOM/CRLF) + D17b (번역 의도 verbatim) | 한글 fragment 50~300자, KR/EN verbatim 6/6 |
| v2 | D15 (branch 일관성) + D19 (workdir 격리) | .gitignore 패턴 일치, .vercel/ 추적 의도 |
| v3 | D2 (git sync post-push) + D11b (curl alias SHA) | curl subprocess SHA == local |
| v4 | D6 (git ls-remote 신선 클론) + D5 (raw CDN) + D4 (Vercel headers) | 풀 40자 HEAD 동기화, Last-Modified 시간 |
| v5 | cleanup 통합 + D17b 확장 (자연 번역 co-occurrence ≥ 5/7) | helper 정리 before/after + 자연 번역 매칭 |

## 6. 두 미션 실측 비교

| 항목 | cloth-simulation | interactive-metaballs |
|---|---|---|
| 라인 수 | 30912 bytes | 73916 bytes |
| 핵심 API | HTML5 Canvas 2D + Verlet | Raw WebGL 1.0 + GLSL |
| 마우스 인터랙션 | 드래그 + 임계 찢어짐 | nearest Blob 끌기 + 클릭 분사 |
| anchor 깨짐 헤딩 | 7개 (cleanup) | 7개 (cleanup) |
| 검증 통과 회수 | 6/6 라운드 모두 fresh | 6/6 라운드 모두 fresh |
| 최종 HEAD | `896fe3e` (anchor 깨짐 정리 후) | `cec5b70` |

**공통점**: ① 동일 4-phase 워크플로 ② neon-fluid 14-section README 정확히 적용 ③ .vercel/ sigco3111 표준 패턴 ④ 모든 라운드 fresh evidence 발행 ⑤ chart 특징 결정 4종 표

**차이점**: ① 코드 컨셉 다름 (Canvas 2D vs WebGL) → Features/Tech Stack/Design Choices 차이 ② 인용 셰이더 키워드 수 (Canvas는 class 위주 / WebGL은 uniform/attribute/gl.\* 위주)

## 7. 자주 빠지는 함정

| 함정 | 부트스트랩 | Deploy | README 갱신 | Push 후 |
|---|---|---|---|---|
| A9 `$()` literal parens | ✗ | ⚠ helper 우회 | ✗ | ✗ |
| 함정 16 디자인 의도 | ⚠ KR/EN verbatim 미리 약속 | ✗ | ⚠ Tier 1 verbatim 강제 | ✗ |
| 함정 17 anchor 깨짐 | ⚠ 처음부터 한/영 혼합 회피 | ✗ | ⚠ 일괄 정리 | ⚠ 검증으로 못 잡으면 그대로 |
| 함정 19 .gitignore auto | ⚠ .vercel/ 박기 | ⚠ OpenCode가 자동 추가 | ✗ | ✗ |
| 매 turn fresh evidence | ✗ | ⚠ 첫 deploy 후 즉시 | ⚠ README 수정 후 즉시 | ⚠ commit 후 즉시 |

## 8. 다음 미션 적용 체크리스트

```
□ /Users/mac/work/<name>/ 디렉토리 + .gitignore pre-add .vercel/
□ LICENSE (MIT 2026 sigco3111) + README.md/en.md (14-section 형식)
□ gh repo create + push (bootstrap 종료)
[사용자 측 OpenCode 작업]
□ vercel deploy via helper (.tmp-step1/2/3)
□ alias URL 확보 + bit-perfect 검증
□ README anchor 깨짐 헤딩 일괄 정리 (있으면)
□ README 임시 섹션 (Features/Controls/Tech Stack/Design Choices) 확정 채움
□ git add + commit + push
□ 자동배포 last-modified 즉시 검증
□ fresh evidence 회전 v0~v5 (매 라운드 다른 차원)
□ 부산물 helper 정리 (cleanup 어서션 통합)
```
