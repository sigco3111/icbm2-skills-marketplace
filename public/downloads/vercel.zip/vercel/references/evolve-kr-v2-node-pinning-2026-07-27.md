# evolve-kr v2 — Node 핀 + bit-perfect SHA + Playwright headless 검증 (2026-07-27)

## 한 줄 요약

`content.js:4 'r.closest is not a function'` 사용자 보고 → **앱 외부 (브라우저 확장)** 진단 → Vercel 자동배포 silent fail 로 분류된 빌드 산출물 **bit-perfect SHA 검증 패턴 정착** + Node 버전 핀 3축 패턴 도입.

## 진단 — `content.js:4` 는 누구의 코드인가

사용자 보고: `content.js:4 'r.closest is not a function'`. 직관적으로 번들러 산출물처럼 보이지만 **3축 grep** 으로 즉시 외부 진단:

```bash
# 1) 파일 존재
ls src/content.js evolve/main.js wiki/wiki.js 2>/dev/null
# → evolve/main.js, wiki/wiki.js 만 존재. content.js 없음.

# 2) 호출 식별자 추적 (minified 번들 포함)
for f in evolve/main.js wiki/wiki.js; do
  echo "$f closest=" $(grep -c 'closest' "$f") \
       ".closest=" $(grep -c '\.closest' "$f")
done
# → closest=0 .closest=0 (양쪽 다 0건)

# 3) Playwright headless Chrome (확장 無) 으로 라이브 페이지 에러 캡처
# → page error 0건, console warning 0건
```

**판정**: `content.js` 는 **브라우저 확장 프로그램의 content script** (Chrome 확장 표준 파일명). 앱 코드 아님. **수정 대상 없음** — 사용자 환경 문제.

**`content.js` 가 외부 신호라는 결정적 식별자 3종**:
1. `closest` 호출이 로컬 소스 어디에도 없음
2. `content.js` 라는 파일명이 일반적이지 않은 빌드 산출물명 (esbuild/Vite 는 보통 `main.[hash].js`)
3. Playwright headless (확장 無) 에서 재현 안 됨

**사용자 대응**: "시크릿 모드 또는 확장 비활성화 상태에서 재확인" 안내. 앱 패치는 **no-op + 이중 보정 위험** (fork-first-investigation §Anti-patterns "분석 후에만 시도한 패치를 그대로 남기기" 와 동일 클래스).

## 빌드 결정성 발견 — Vercel 의 silent Node 버전 변경

Vercel 자동배포 silent fail 패턴이 여기서도 발동. **첫 배포는 우연히 성공한 듯 보였지만** 빌드 산출물 hash 가 일치하지 않음:

| 단계 | Vercel Node | 빌드 결과 | 결정성 |
|---|---|---|---|
| 첫 배포 (v1, `2db253dd`) | 24.x | esbuild 0.25.0 / less 3.13.0 / csso-cli 4.0.2 모두 install | 우연 OK |
| 자동배포 후 | 24.x → 22.x silent 변경 | `Skipping build cache since Node.js version changed from "24.x" to "22.x"` | **비결정** |

**3축 핀 패턴 도입** (v2):

```jsonc
// package.json
{
  "engines": { "node": "22.x" },
  "devDependencies": {
    "csso-cli": "4.0.2",   // ^ 제거
    "less": "3.13.0"       // ^ 제거
  },
  "dependencies": {
    "esbuild": "0.25.0"    // ^ 제거
  }
}

// vercel.json
{
  "outputDirectory": ".",
  "installCommand": "npm install --include=dev --no-save --package-lock=false esbuild@0.25.0 less@3.13.0 csso-cli@4.0.2",
  "buildCommand": "npm run evolve && npm run evolve-less && npm run wiki && npm run wiki-less"
}
```

**왜 3축 모두 필요한가**:
| 위치 | 차단 대상 |
|---|---|
| `engines.node: 22.x` | Vercel 빌드 머신의 Node 버전 강제 |
| `^` 제거 | install 단계에서 의도된 exact 버전 사용 |
| `installCommand` | 캐시 hit / silent 업그레이드 / 의도치 않은 패키지 변경 |

**Vercel 빌드 로그 검증** (v2 배포 후):
```
Running "install" command: `npm install --include=dev --no-save --package-lock=false esbuild@0.25.0 less@3.13.0 csso-cli@4.0.2`...
added 165 packages, and audited 166 packages in 7s
> evolveidle@1.4.10 evolve
> node buildEvolve.js
  evolve/main.js  2.2mb ⚠️
⚡ Done in 369ms
> evolveidle@1.4.10 wiki
> node buildWiki.js
  wiki/wiki.js  2.3mb ⚠️
⚡ Done in 338ms
```

## Bit-perfect SHA256 검증 — 결정적 입증

**README SHA 패턴을 빌드 산출물 (esbuild JS 번들) 로 확장** — 가장 결정적인 자동배포 검증.

```bash
# 1. 로컬 SHA (npm run build 직후)
LOCAL_MAIN=$(shasum -a 256 evolve/main.js | awk '{print $1}')
LOCAL_WIKI=$(shasum -a 256 wiki/wiki.js | awk '{print $1}')

# 2. 라이브 SHA (Vercel alias 에서 fetch + 캐시 buster)
curl -sSL --max-time 30 "https://evolve-kr.vercel.app/evolve/main.js?verify=$(git rev-parse --short HEAD)" \
  -o /tmp/live-main.js
LIVE_MAIN=$(shasum -a 256 /tmp/live-main.js | awk '{print $1}')

# 3. 결정적 비교
[ "$LOCAL_MAIN" = "$LIVE_MAIN" ] && echo "✓ bit-perfect"
```

**evolve-kr v2 실측**:
| 파일 | 로컬 SHA-256 | 라이브 SHA-256 | 일치 |
|---|---|---|---|
| `evolve/main.js` | `9c6a23e29370cb43bbd9a31db89546bff9680ae5a93747180a55c7979d758a89` | (동일) | ✓ |
| `wiki/wiki.js` | `abd20b28ab4742dcfe7a7e11e0a4e887a4cf7e6ab3fb8581420a435e0697624e` | (동일) | ✓ |

**왜 bit-perfect 가 가장 결정적인가**:
- **코드 동일성** (local == remote): 푸시 후 우리 HEAD 가 라이브 alias 에 서빙되고 있음을 입증
- **배포 정합성** (Vercel 이 의도한 빌드를 서빙): silent fail 옛 hash 캐시 hit 도 즉시 감지
- 기존 §"자동배포 silent fail" (sango-rising-dragons 2026-07-20) 의 결정판 — `x-vercel-cache: HIT` 옛 hash 응답도 잡아냄

## Playwright headless Chrome — SPA 인터랙티브 검증

SPA 게임 (Evolve Idle) 처럼 클라이언트 사이드 렌더링 + i18n 토글 + localStorage 영속화가 핵심인 경우 bit-perfect SHA 후 Playwright headless 로 page error 0건 확인:

```javascript
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({
    headless: true,
    executablePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
  });
  const p = await b.newPage();
  let errs = [];
  p.on('pageerror', e => errs.push(e.message));
  p.on('console', m => { if (m.type() === 'error' || m.type() === 'warning') cons.push(m.type() + ': ' + m.text()); });

  await p.goto('https://evolve-kr.vercel.app', { waitUntil: 'networkidle', timeout: 120000 });
  await p.waitForTimeout(3000);

  // 1) 기본 en-US 로딩 + 에러 0건 확인
  console.log({ title: await p.title(), pageErrors: errs });

  // 2) i18n 토글 — localStorage evolve JSON 압축 해제 + locale 변경 + reload
  await p.evaluate(() => {
    const raw = localStorage.getItem('evolved');
    const txt = LZString.decompressFromUTF16(raw);
    const g = JSON.parse(txt);
    g.settings.locale = 'ko-KR';
    localStorage.setItem('evolved', LZString.compressToUTF16(JSON.stringify(g)));
  });
  await p.reload({ waitUntil: 'networkidle' });
  await p.waitForTimeout(3000);

  // 3) 한글 렌더 확인 (hangul character count)
  const body = await p.locator('body').innerText();
  const hangul = (body.match(/[가-힣]/g) || []).length;
  console.log({ hangul, body: body.slice(0, 1000), errors: errs });

  await b.close();
  if (errs.length || !/[가-힣]/.test(body)) process.exit(2);
})();
```

**evolve-kr v2 실측**:
- 페이지 에러: **0건**
- 콘솔 warning/error: **0건**
- `ko-KR` 토글 후 한글 렌더: **52자 이상** (Top Bar / Race Info / Message Log / Resources / Tab Navigation 모두 한국어)
- 한국어가 처음부터 나오지 않는 것은 **에러가 아니라 `global.settings.locale` 의 디폴트가 `en-US`** 라서 그렇다. 사용자 인지는 설정에서 변경.

**핵심**: 한국어 미렌더 자체가 빌드 에러의 신호는 아님 — **빌드 에러면 Playwright `pageerror` 가 즉시 잡아냄**. 진짜 에러 신호는 `pageerror` 0건 여부.

## 운영 데이터 (evolve-kr v2 2026-07-27)

- **커밋**: `41a798a14a3382ee2df4bd4624239b8b02f965ac` (`fix(deploy): pin Node and build toolchain`)
- **푸시**: `2db253dd..41a798a1 main -> main`
- **Deployment ID**: `dpl_CJNsTwU5yYjNTrBdngkBNftGu85A`
- **Production URL (team-scope, anon 302)**: `https://evolve-12oo5595w-sigco3111s-projects.vercel.app`
- **Free alias (anon 200)**: `https://evolve-kr.vercel.app`
- **Alias HTTP**: HTTP/2 200, `x-vercel-cache: HIT` (정상 — 캐시 hit 라도 bit-perfect SHA 검증으로 통과 확인)
- **빌드 산출물 SHA**: evolve/main.js + wiki/wiki.js 모두 bit-perfect 일치

## 정형화된 deploy + verification 5-phase (evolve-kr v2 → v3+ 권장)

| Phase | 작업 | 검증 |
|---|---|---|
| 1. 핀 점검 | `engines.node` + exact version + `installCommand` 3축 박혀 있는지 | `grep` 로 정적 확인 |
| 2. 로컬 빌드 | `npm run build` 4개 exit 0 | 산출물 사이즈 + SHA |
| 3. 푸시 + 배포 | `git push origin main` → 자동배포 OR `vercel --prod --yes --non-interactive` | `git rev-parse HEAD == origin/main` + Vercel deploy id |
| 4. **bit-perfect SHA** | 라이브 fetch + `shasum -a 256` 비교 | 로컬 == 라이브 결정적 일치 |
| 5. **Playwright headless** | Chrome (확장 無) 에서 페이지 로드 + i18n 토글 + 한글 렌더 | `pageerror 0건` + `console warning 0건` + hangul > 0 |

## 교훈 — 3가지 (vercel/SKILL.md 본문 패치에 반영됨)

1. **`content.js` 같은 비표준 파일명 + "is not a function" 조합 → 가장 먼저 grep 으로 외부 진단** (v2 SKILL.md §"Bit-perfect SHA256 build artifact 검증" 인접)
2. **빌드 툴체인은 처음부터 3축 핀** (engines.node + exact version + installCommand) — 사후 핀은 캐시 충돌
3. **bit-perfect SHA + Playwright headless** 두 검증이 **함께** 자동배포의 결정적 입증

## 향후 적용 패턴

- **새 npm 프로젝트 부트스트랩** 시 처음부터 3축 핀 + bit-perfect SHA 검증 어서션 셋업
- **첫 자동배포 후** + **다음 변경 push 후** 매번 bit-perfect SHA 비교 — silent fail 즉시 감지
- **SPA 게임/i18n 토글/클라이언트 영속화** 앱은 Playwright headless 까지 추가 — 코드 동일성 + 인터랙티브 정합성 동시 입증