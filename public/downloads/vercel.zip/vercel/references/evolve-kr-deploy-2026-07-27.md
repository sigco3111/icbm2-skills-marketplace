# evolve-kr Vercel deploy 세션 노트 (2026-07-27)

## 한 줄 요약
Evolve (pmotschmann/Evolve fork 한국어화판, sigco3111/evolve-kr) 첫 Vercel 자동 배포 성공. 빌드 4종, free alias `evolve-kr.vercel.app` 200 OK, README 라이브 URL 박고 push.

## 세션에서 잡은 함정 3종 (모두 vercel SKILL.md에 패치됨)

### 1. 토큰 후보 위치 2종 검증 (★★★★★)
- `~/.vercel_token` (Jul 20 갱신, 더 최신 mtime) — **invalid**
- `~/.hermes/secrets/vercel_token.txt` (Jun 26 원본) — **valid**

**교훈**: mtime만으로 토큰 선택 금지. 두 후보 모두 `vercel whoami --token` 검증 후 채택. → SKILL.md에 "토큰 후보 위치 2종 검증" 섹션 추가.

### 2. `--non-interactive`로 remote 2개 프롬프트 회피 (★★★★★)
- 첫 `vercel --prod --yes` 호출이 "Which remote do you want to connect?" 에서 멈춤
- `--non-interactive` 한 방으로 해결 (stdin `printf "2\n"` 불요)
- → SKILL.md 비대화형 원격 선택 섹션에 **방법 1** 로 추가.

### 3. `--name` 플래그 deprecated (★)
- `vercel --prod --token ... --name evolve-kr` 호출 시 경고:
  ```
  The "--name" option is deprecated (https://vercel.link/name-flag)
  ```
- → SKILL.md 전제조건 옆에 단락 추가.

## 이 세션의 deploy 워크플로 (4빌드 npm pipeline)

```bash
# 1. 토큰 검증 (2종 모두 시도)
for c in ~/.vercel_token ~/.hermes/secrets/vercel_token.txt; do
  [ -s "$c" ] || continue
  TOK=$(cat "$c")
  R=$(vercel whoami --token "$TOK" 2>&1)
  echo "$R" | grep -qE "^sigco3111$" && { echo "✓ $c"; TOK_VALID="$TOK"; break; }
done

# 2. deploy (--non-interactive로 remote 2개 자동 처리)
export VERCEL_TOKEN="$TOK_VALID"
cd /Users/mac/work/evolve-kr
vercel --prod --yes --non-interactive --token "$VERCEL_TOKEN"
# → Created sigco3111s-projects/evolve-kr
# → Production: https://evolve-bmccxawm3-sigco3111s-projects.vercel.app  (team-scope, anon 302)
# → ▲ Aliased:  https://evolve-kr.vercel.app                          (free alias, anon 200)

# 3. alias 200 검증 + 4개 빌드 산출물 sanity check
curl -sI -L --max-time 15 https://evolve-kr.vercel.app | head -1
# → HTTP/2 200
for path in evolve/main.js evolve/evolve.css wiki/wiki.js wiki/wiki.css; do
  curl -s -o /dev/null -w "%{http_code}  $path\n" --max-time 10 "https://evolve-kr.vercel.app/$path"
done
# → 200  evolve/main.js, 200  evolve/evolve.css, 200  wiki/wiki.js, 200  wiki/wiki.css

# 4. README의 placeholder → 라이브 URL
# 19번 줄: "- 한국어 fork (배포 후 채워질 예정)"
#       → "- 한국어 fork (Vercel): https://evolve-kr.vercel.app"

# 5. 커밋 + push (--name deprecation 잡힌 부산물 .gitignore + .vercel/ 는 별도 검토)
git add README.md .gitignore
git -c user.name='sigco3111' -c user.email='sigco3111@users.noreply.github.com' \
    commit -m "docs: 라이브 Vercel URL README에 반영 (evolve-kr.vercel.app)"
git push origin main
# → cd968d65..2db253dd  main -> main
```

## npm 빌드 4종 — vercel.json
```json
{
  "outputDirectory": ".",
  "buildCommand": "npm run evolve && npm run evolve-less && npm run wiki && npm run wiki-less"
}
```

빌드 단계 (Vercel iad1, Washington D.C., 2 cores 8GB):
1. `npm install` — 165 packages in 3s
2. `npm run evolve` — esbuild로 `evolve/main.js` (2.2mb)
3. `npm run evolve-less` — `src/evolve.less` → `evolve/evolve.css`
4. `npm run wiki` — esbuild로 `wiki/wiki.js` (2.3mb)
5. `npm run wiki-less` — `src/wiki/wiki.less` → `wiki/wiki.css`
→ `▲ Aliased` + `Deployment ready` + `id: dpl_GizhYAdJBqhEEj6VdeDj46njKEgR`

## team-scope 302 vs free alias 200 — 이 케이스 특이점

- `https://evolve-bmccxawm3-sigco3111s-projects.vercel.app` (team-scope prod) → **302 SSO** (anon 사용자 차단)
- `https://evolve-kr.vercel.app` (free alias) → **200 anon 허용**

→ **공개 README에는 반드시 alias URL 박을 것** (SKILL.md §"Team-scope anon 시 SSO 302" 참조). 이건 모든 sigco3111s-projects team-scope에 공통 적용.

## 커밋 SHA / URL / 메시지 요약

- 커밋: `2db253dd docs: 라이브 Vercel URL README에 반영 (evolve-kr.vercel.app)` (+3 -2)
- 푸시: `cd968d65..2db253dd  main -> main`
- Alias: `https://evolve-kr.vercel.app` (HTTP 200, 3230 bytes index.html)
- 4 빌드 산출물 라이브 200 OK 모두 확인

## 향후 deploy 워크플로 정형화 후보

이 세션의 토큰 검증 + deploy + README patch + push는 정확히 6단계:
1. 토큰 후보 2종 검증 → TOK_VALID
2. `vercel --prod --yes --non-interactive --token "$TOK_VALID"` (4-빌드 npm pipeline)
3. alias 200 + 4개 산출물 200 검증
4. README placeholder → alias URL patch
5. `git add` + commit (sigco3111 user config 명시)
6. `git push origin main`

`scripts/vercel-deploy-and-update-readme.sh` 같은 1-스크립트로 정형화 가능. (다음 세션에서 필요 시 만들 것.)