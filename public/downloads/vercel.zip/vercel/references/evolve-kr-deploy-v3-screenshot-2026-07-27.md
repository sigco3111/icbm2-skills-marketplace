# evolve-kr Vercel deploy v3 세션 노트 (2026-07-27)

## 한 줄 요약
3차 evolve-kr 세션: 한국어 게임 스크린샷을 `docs/`에 복사 + README에 `![](docs/...)` 형식으로 첨부 + push + Vercel production redeploy까지 매끄럽게 완료. **2건의 신선한 함정**이 잡혀 SKILL.md에 박힘.

## 이 세션에서 잡은 함정 2종

### 1. `.gitignore` 차단 디렉터리의 자산 push — `git add -f` 우회 패턴 (★★★★★)

**배경**: evolve-kr의 `.gitignore`가 빌드 산출물 패턴으로 `docs/`를 통째로 차단:
```gitignore
wiki/wiki.css
docs            ← line 12
dist
```

사용자 요청은 한국어 게임 스크린샷을 `docs/screenshot-korean-game.png`로 복사 후 README에 첨부하는 것. `cp`는 성공하지만 `git add`가 **silent no-op**:

```bash
$ git add docs/screenshot-korean-game.png
$ git status --short
# (출력 없음)  ← 차단됨, error 없음

$ git check-ignore -v docs/screenshot-korean-game.png
.gitignore:12:docs  docs/screenshot-korean-game.png
```

**해결**: `git add -f docs/screenshot-korean-game.png` (force-add). push 직후 GitHub contents API로 박힘 확인:

```bash
$ git ls-files --stage -- docs/screenshot-korean-game.png
100644 7e98548c9ceacd998e7601c0cf02add14b2a616e 0   docs/screenshot-korean-game.png

$ curl -s -H "Accept: application/vnd.github+json" \
    "https://api.github.com/repos/sigco3111/evolve-kr/contents/docs/screenshot-korean-game.png?ref=main" \
    | python3 -c "import sys,json; d=json.load(sys.stdin); print(f\"name={d['name']} size={d['size']} sha={d['sha']}\")"
# name=screenshot-korean-game.png size=351437 sha=7e98548c9ceacd998e7601c0cf02add14b2a616e
```

**교훈**: SKILL.md §".vercelignore 빌드 입력 차단 함정"과 미러링되지만, **이번엔 `.gitignore`가 `docs/` 같은 디렉터리 자체를 차단**하는 케이스. 정적 사이트 fork의 흔한 패턴 — `dist/`, `build/`, `out/`, `public/`, `static/` 등도 같은 함정 발동. push한 줄이 GitHub에 안 박혔는데 `git push`는 성공으로 끝나는 **silent no-op**이 가장 잔인.

### 2. `--name` deprecated 경고 — deploy 직전 자기검증 어서션 필요 (★★★★)

**배경**: 1차 세션 노트(references/evolve-kr-deploy-2026-07-27.md)에서 이미 패치된 `vercel --name` deprecated 경고. SKILL.md 본 섹션에도 명시. **그런데 3차 세션에서 다시 `vercel --prod --yes --non-interactive --token "$TOK" --name evolve-kr`로 호출** → 매번 같은 deprecation 경고:

```
The "--name" option is deprecated (https://vercel.link/name-flag)
```

**근본 원인**: SKILL.md 본문을 읽었음에도 호출 사이트에서 패턴을 **외워서** 쓰는 약함. SKILL.md → 호출 사이트 사이에 한 줄 자기검증 어서션이 없으면 같은 실수 반복.

**해결 — deploy 직전 4축 자체 점검** (이제 SKILL.md 본 섹션에 박힘):
```bash
vercel_cmd="vercel --prod --yes --non-interactive --token \"$TOK\""
grep -q -- '--name' <<<"$vercel_cmd" && echo "❌ --name deprecated 포함" || echo "✓ --name 없음"
grep -q -- '--token' <<<"$vercel_cmd" || echo "❌ --token 없음"
grep -q -- '--non-interactive' <<<"$vercel_cmd" || echo "⚠️ --non-interactive 없음 (remote 2개 시 hang)"
grep -qE '^vcp_' <<<"$TOK" || echo "❌ TOK prefix 이상"
```

**교훈**: SKILL.md에 패치만 해서는 부족. **패치 → 호출 사이트 사이에 자동화된 어서션**을 함께 박을 것. 1차 evolve-kr 세션이 `--name`을 박은 게 처음이면 사고. **3차 세션이 같은 걸 또 박았다면** SKILL.md 학습이 호출 사이트까지 도달하지 못한 것 — 어서션이 정답.

## 이 세션의 deploy 워크플로 (5단계)

```bash
# 1. 인증 (2종 토큰 후보 검증 — SKILL.md §"토큰 후보 위치 2종 검증")
selected=''
for candidate in "$HOME/.hermes/secrets/vercel_token.txt" "$HOME/.vercel_token"; do
  if [ -s "$candidate" ]; then
    token=$(tr -d '\r\n' < "$candidate")
    result=$(vercel whoami --token "$token" 2>&1)
    if [ $? -eq 0 ]; then selected="$token"; break; fi
  fi
done
# → /Users/mac/.hermes/secrets/vercel_token.txt (sigco3111) — valid
```

```bash
# 2. 자산 복사 + README patch + force add
mkdir -p docs
cp "/Users/mac/Downloads/iScreen Shoter - Google Chrome - 260727174813.jpg" \
   docs/screenshot-korean-game.png
# 1851×931, 351437 bytes
# SHA-256: f73c4e39257ff07ad0e177c49796fe525478f4b938fa30f5351943202a746539

# README에 이미지 마커 삽입
# ## 플레이
#
# ![한국어 게임 스크린샷](docs/screenshot-korean-game.png)
# 🎮 **한국어 라이브 데모**: https://evolve-kr.vercel.app

# .gitignore의 docs/ 차단 우회
git add README.md
git add -f docs/screenshot-korean-game.png

git -c user.name='sigco3111' -c user.email='sigco3111@users.noreply.github.com' \
    commit -m "docs: 한국어 게임 스크린샷 README에 첨부"
# [main f62f9e5d] docs: 한국어 게임 스크린샷 README에 첨부
#  2 files changed, 2 insertions(+)

git push origin main
# 1c98ebc0..f62f9e5d  main -> main
```

```bash
# 3. Vercel redeploy
vercel --prod --yes --non-interactive --token "$selected"
# → Building… (iad1)
#   evolve/main.js  2.2mb ⚠️
#   wiki/wiki.js    2.3mb ⚠️
#   evolve/evolve.css + wiki/wiki.css
# Build Completed in 9s
# ▲ Aliased  https://evolve-kr.vercel.app
# {
#   "status": "ok",
#   "deployment": {
#     "id": "dpl_73Ea6E4ynRkRSfb1bVnRtZfvyY3E",
#     "readyState": "READY",
#     ...
#   }
# }
```

```bash
# 4. 검증 4축
# (a) GitHub HEAD API — 푸시 사실관계
python3 -c "import json,urllib.request; ..."
# github_head=f62f9e5dd0692abab8a29061244fc9a5ad628d7e
# github_subject=docs: 한국어 게임 스크린샷 README에 첨부

# (b) alias 본문 HTTP 200
curl -sSI --max-time 30 https://evolve-kr.vercel.app/ | head -1
# HTTP/2 200

# (c) 라이브 4개 산출물 HTTP 200
for path in '' 'evolve/main.js' 'evolve/evolve.css' 'wiki/wiki.js' 'wiki/wiki.css'; do
  code=$(curl -sS -L --max-time 30 -o /dev/null -w '%{http_code}' "https://evolve-kr.vercel.app/${path}")
  echo "$code  https://evolve-kr.vercel.app/${path}"
done
# 200, 200, 200, 200, 200  (모두 200)

# (d) 라이브 스크린샷 bit-perfect SHA
curl -sSL --max-time 30 https://evolve-kr.vercel.app/docs/screenshot-korean-game.png \
  -o /tmp/evolve-kr-live-screenshot
shasum -a 256 /tmp/evolve-kr-live-screenshot
# f73c4e39257ff07ad0e177c49796fe525478f4b938fa30f5351943202a746539
# → 로컬 SHA와 정확히 일치 ✓
```

## 커밋 / URL / SHA 요약

- 커밋: `f62f9e5d docs: 한국어 게임 스크린샷 README에 첨부` (+2 -0)
- 푸시: `1c98ebc0..f62f9e5d  main -> main`
- Vercel deployment: `dpl_73Ea6E4ynRkRSfb1bVnRtZfvyY3E`
- Alias: `https://evolve-kr.vercel.app` (HTTP 200, 5/5 paths OK)
- 스크린샷 SHA-256 (로컬 == 라이브): `f73c4e39257ff07ad0e177c49796fe525478f4b938fa30f5351943202a746539`

## 향후 보강 후보 (다음 세션)

- **`scripts/vercel-deploy-and-update-readme.sh` 정형화** (1차 노트에서 언급). 3차 워크플로 (토큰 검증 → asset copy + force-add → README patch → commit → push → redeploy → bit-perfect SHA 검증) 가 매번 같은 시퀀스 — 1-helper로 압축 가능. 다음 세션에서 README 갱신 요청 들어올 때 만들 것.
- **`--name` 회귀 방지 더 강한 어서션**: deploy 호출을 helper 안에 박고 helper 자체에 4축 grep 어서션을 통합하면, **에이전트가 helper를 호출하는 한** `--name`을 못 박음. helper = SKILL.md 규약의 enforcement layer.