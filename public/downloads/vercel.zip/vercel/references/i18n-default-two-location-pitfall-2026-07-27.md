# i18n 기본값 두 위치 함정 (2026-07-27 evolve-kr v3 실측)

## 문제

`src/vars.js` 같은 default settings 파일에 **같은 키가 2개 위치에 박혀있는** 패턴이 있음:

```js
// 위치 A: 초기 settings 객체 (라인 1316)
if (!global['settings']){
    global['settings'] = {
        showEvolve: true,
        locale: 'en-US',     // ← ①
        ...
    };
}

// 위치 B: fallback 할당 블록 (라인 1490-1491)
if (!global.settings['locale']){
    global.settings['locale'] = 'en-US';     // ← ②
}
```

**하나만 patch하면 드리프트 발생**:
- ①만 patch (locale: 'en-US' → locale: 'ko-KR') → 신규 유저 = 한국어 (정상)
- ②만 patch → 신규 유저 = 영문 (의도와 다름), 저장된 settings 가진 기존 유저는 ① 무관
- **둘 다 patch 필요**

## 발견 패턴 (grep)

```bash
# 한 줄로 두 위치 동시 발견
grep -n "locale: 'en-US'\|locale: \"en-US\"\|settings\['locale'\] = 'en-US'\|settings\[\"locale\"\] = \"en-US\"" src/vars.js
# 또는 esbuild/webpack 출력에서
grep -nE "locale:\s*['\"]en-US['\"]|locale\]\s*=\s*['\"]en-US['\"]" evolve/main.js
```

## 패치 패턴

```bash
# 위치 A — 초기화 객체
-        locale: 'en-US',
+        locale: 'ko-KR',

# 위치 B — fallback 할당
-if (!global.settings['locale']){
-    global.settings['locale'] = 'en-US';
-}
+if (!global.settings['locale']){
+    global.settings['locale'] = 'ko-KR';
+}
```

`patch` tool 2회 연속 (또는 `replace_all=true` 한 번 — 단 unique match 확인 필수).

## 검증

```bash
# 1) 로컬 source 확인
grep -c "locale.*en-US" src/vars.js   # → 0 (둘 다 patch됨)
grep -c "locale.*ko-KR" src/vars.js   # → 2

# 2) esbuild 번들 확인
grep -c 'locale:"en-US"' evolve/main.js   # → 0
grep -c 'locale:"ko-KR"' evolve/main.js   # → 1 (또는 2)

# 3) ⚠️ 단, locale registry map은 별도 — 'en-US' 같은 키는 locale 목록에 정상
grep -oE "'[a-z]{2}-[A-Z]{2}'" evolve/main.js   # → en-US, es-ES, pt-BR, ... ko-KR 모두 등장
# 이건 정상. "default로 박힌 'en-US' literal" 만 0이어야 통과
```

## 같은 함정이 있는 다른 라이브러리 패턴

| 라이브러리/프레임워크 | 두 위치 패턴 |
|---|---|
| **Evolve Idle (vars.js)** | globals.settings init + locale fallback |
| **Mastodon** | settings.defaults + User#locale fallback |
| **Django** | settings.LANGUAGE_CODE + middleware fallback |
| **Rails I18n** | I18n.default_locale + per-request locale override |
| **Next.js next-intl** | middleware defaultLocale + next.config.js localeDetection |

모두 **하나만 바꾸면 절반만 작동**. 2-pass patch가 표준.

## evolve-kr v3 실측

- `src/vars.js` 라인 1316 + 라인 1490-1491 — 두 위치 모두 `'ko-KR'`로 patch 성공
- 로컬 esbuild 출력 (`evolve/main.js`) grep:
  - `locale:"ko-KR"` 2회 (설정 default + fallback 모두 박힘) ✅
  - `locale:"en-US"` 0회 (default literal 박힘 부재) ✅
  - `'en-US':'English (US)'` 1회 (locale registry map — 정상)
- 커밋 `77a3a3f7 feat(i18n): ko-KR를 기본 로케일로 설정 (vars.js)` + push 성공
- **단, Vercel redeploy는 별개 blocker** — `references/hermes-subshell-env-isolation-2026-07-27.md` 참조

## 일반화 (다른 i18n 작업 시 적용)

i18n default 변경 작업 표준:
1. **grep으로 모든 en-US/en-XX literal 위치 발견**
2. **"default literal" vs "registry key" 분리** — 전자는 patch 대상, 후자는 patch 금지
3. **모든 default literal patch**
4. **빌드 후 esbuild/Vite/webpack 출력에서 0회 확인** (registry 키는 예외로 남음)
5. **라이브 검증 전 redeploy가 별개 단계임을 인지** — subagent 세션에서는 환경변수 격리로 redeploy 차단 가능

## 사용자 보고 형식

```text
✅ src/vars.js 2곳 패치 (라인 1316 + 1490)
✅ 4 builds 성공 (esbuild main.js 2.2MB / wiki.js 2.3MB / CSS csso OK)
✅ 로컬 grep: locale:"ko-KR" 2회, locale:"en-US" 0회 (literal), en-US 1회 (registry map)
✅ commit 77a3a3f7 + push origin main
❌ Vercel redeploy: $VERCEL_TOKEN sub-shell 격리로 vercel CLI 인증 실패
❌ 라이브 etag/last-modified: 여전히 stale (Mon Jul 27 07:53:57 GMT)
→ "부분 완료 (source 변경 + push 성공, Vercel redeploy는 사용자 웹 UI 한 번 클릭 필요)"
```

fabricate 없이 정직한 부분 보고가 표준.