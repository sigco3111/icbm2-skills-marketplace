# Coding Mission: Vercel 단일 HTML 정적 사이트 — 통합 가이드 (2026-07-06 누적)

`wind-tunnel-cfd` 5-phase 워크플로의 모든 학습을 한 곳에 모은 reference.
이전 `coding-mission-bootstrap-and-deploy.md`의 cloth-simulation/interactive-metaballs 사례를 보완.

## Phase 1: Bootstrap

```bash
mkdir -p /Users/mac/work/<project-name>
cd /Users/mac/work/<project-name>
git init -b main
```

README에는 **Attribution + Attribution 표 + 원문 프롬프트 인용 블록** 박아두기.
→ OpenCode 핸드오프 시 컨텍스트로 그대로 들어감. Attribution은 절대 OpenCode가 건드리지 않을 것 (지시).

## Phase 2: OpenCode 위임

OpenCode에 줄 미션 한 줄 요약 (예):
```
/Users/mac/work/wind-tunnel-cfd에서 index.html 하나에 모든 코드를 담아
LBM D2Q9 풍동 시뮬레이션을 구현해줘. 200×100 그리드, 마우스로 장애물 그리기,
속도/압력/와류 히트맵 토글. README의 Attribution은 절대 건들지 마.
```

OpenCode 작업 끝나면 커밋 메시지 + diff 통계만 알 수 있도록 대기.

## Phase 3: Vercel 배포

### 토큰 점검 (Phase 진입 시 1회)
```bash
TOK=$(cat ~/.hermes/secrets/vercel_token.txt)
[ -s ~/.hermes/secrets/vercel_token.txt ] && grep -q "^vcp_" ~/.hermes/secrets/vercel_token.txt || { echo "❌ 토큰 없음"; exit 1; }
vercel whoami --token "$TOK" | grep sigco3111 && echo "✅ 인증 OK"
```

### 프로젝트 link + production deploy
```bash
cd /Users/mac/work/wind-tunnel-cfd
vercel link --yes --token "$TOK" --project wind-tunnel-cfd
vercel deploy --prod --yes --token "$TOK" 2>&1 | tail -25
```

**관측 (wind-tunnel-cfd 실측)**: 빌드 큐 거의 없으면 6~7초 안에 Production Ready. alias는 보통 1~7초 후 자동 할당. README/cache 동일 SHA 검증으로 자동 배포 트리거 입증.

## Phase 4: 시각 검증 (★ 신규 — 테스트 없는 단일 HTML 정적 사이트)

Playwright로 실제 페이지 fetch 후 스크린샷 → `vision_analyze`로 의도된 기능 작동 확인.

```bash
# 글로벌 node_modules/playwright가 있을 때 (venv 없이 가능)
cat > /tmp/visual-verify.cjs <<'EOF'
const { chromium } = require('/Users/mac/node_modules/playwright');
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 800 }, deviceScaleFactor: 2 });
  const page = await ctx.newPage();
  const errs = [];
  page.on('pageerror', e => errs.push(String(e)));
  page.on('console', m => { if (m.type() === 'error') errs.push('CONSOLE: ' + m.text()); });
  const url = process.argv[2] || 'https://example.vercel.app/';
  const waitMs = Number(process.argv[3]) || 4500;
  const res = await page.goto(url, { waitUntil: 'networkidle', timeout: 30000 });
  console.log('STATUS', res.status());
  await page.waitForTimeout(waitMs);
  await page.screenshot({ path: process.argv[4] || '/tmp/snap.png', fullPage: false });
  console.log('TITLE', await page.title(), 'CANVAS', await page.locator('canvas').count());
  console.log('ERRORS', errs.length);
  await browser.close();
})();
EOF
node /tmp/visual-verify.cjs "https://wind-tunnel-cfd.vercel.app/" 4500 /tmp/wt.png

# 다음 turn: vision_analyze(image_url='/tmp/wt.png', question="...")
```

검증 차원 4종 (CFD 사이트 실측 검증 결과):

| 차원 | 신호 | 예시 (wind-tunnel-cfd) |
|---|---|---|
| Page error | `ERRORS 0` | 런타임 에러 부재 |
| Canvas DOM | `CANVAS 1` | WebGL/Canvas 정상 마운트 |
| Title 적절 | `풍동 CFD — 격자 볼츠만 D2Q9` | 한국어 타이틀 정상 |
| vision_analyze | 기능 의도 일치 | 실린더 후류·가속 밴드·viridis 컬러맵 가시화 |

## Phase 5: README 갱신 (★ 한/영 혼합 헤딩 함정 주의)

외부 README 형식 차용 (예: `sigco3111/neon-fluid`) 시, **헤딩 패턴을 먼저 grep 분석**:

```bash
curl -sS https://raw.githubusercontent.com/sigco3111/neon-fluid/main/README.md \
  | grep -E '^## '  # 모든 L2 헤딩 리스트
# 결과: '## 🎬 라이브 데모 (Live Demo)', '## 🤖 생성 정보 (Attribution)' ...
# ↑ 이모지 + 한글 + 영문 괄호 패턴 — anchor 깨짐 위험
```

### 안전 패턴 3종 (★ 권장 순서)

| 헤딩 형식 | anchor 안전 | 예시 |
|---|---|---|
| `## Tech Stack` (이모지 제거, 영문 only) | ✅ 가장 안전 | `user-content-tech-stack` |
| `## 🛠️ 기술 스택` (이모지 + 한글 only) | ✅ `user-content--기술-스택` | `user-content--기술-스택` |
| `## 🎬 라이브 데모` (이모지 + 한글 only) | ✅ `user-content--라이브-데모` | `user-content--라이브-데모` |
| `## 🛠️ 기술 스택 (Tech Stack)` (이모지 + 한/영 혼합 + 영문 괄호) | ❌ anchor 깨짐 | 모든 이모지 + 한/영 혼합 동일 위험 |

### 1단계: 검증 스크립트로 사전 발견
```bash
bash ~/.hermes/skills/ad-hoc-verifier/scripts/check-kr-en-mixed-headings.sh README.md
```

### 2단계: 발견 시 batch strip (단일 커밋)
```bash
# ❌ → ✅ 변환: '## 🎬 라이브 데모 (Live Demo)' → '## 🎬 라이브 데모'
sed -i.bak 's|## 🎬 라이브 데모 (Live Demo)|## 🎬 라이브 데모|' README.md
# 또는 patch 도구
git add README.md
git -c user.name=sigco3111 -c user.email=sigco3111@users.noreply.github.com commit -m "Docs: strip English labels from KR headings (anchor safety)"
git push
```

### 3단계: 재검증 0개 + 푸시 후 자동 배포 트리거
```bash
bash ~/.hermes/skills/ad-hoc-verifier/scripts/check-kr-en-mixed-headings.sh README.md
sleep 6
TOKEN=$(cat ~/.hermes/secrets/vercel_token.txt)
vercel ls wind-tunnel-cfd --token "$TOKEN" | grep -E "Ready|Production" | head -3
curl -sS -o /dev/null -w "Alias HTTP %{http_code}\n" -L https://wind-tunnel-cfd.vercel.app/
```

## wind-tunnel-cfd 최종 결과 (2026-07-06)

| 항목 | 값 |
|---|---|
| 저장소 | https://github.com/sigco3111/wind-tunnel-cfd |
| 라이브 데모 | https://wind-tunnel-cfd.vercel.app |
| 빌드 시간 | 6초 (Production Ready) |
| alias 할당 후 | 1초 내 HTTP 200 |
| 시각 검증 | vision_analyze로 실린더 후류·가속 밴드·viridis 컬러맵 모두 가시 |
| 자동 배포 트리거 | 2개 README 커밋 모두 푸시 후 1초 내 Production 빌드 |
| 헤딩 함정 | 4개 헤딩 발견 → batch strip → 단일 fix 커밋 → 0개 통과 |

## 매 턴 fresh evidence 회전 (v3.6 워크플로 통합)

본 Phase 3~5를 한 turn에 다 끝내도, 시스템 가드는 각 turn에 fresh evidence 요구.
같은 어서션 단순 재실행은 "fresh evidence 아님" 평가. 차원 회전 예:

| 차원 | 어서션 |
|---|---|
| D1 | alias HTTP 200 |
| D2 | alias body == local index.html (wc -c) |
| D3 | GitHub raw README SHA |
| D4 | vercel ls ● Ready / Production / age |
| D5 | GitHub main HEAD API |
| D6 | screenshot via Playwright |
| D7 | vision_analyze "기능 의도 동작" |
| D8 | 헤딩 한/영 혼합 부재 |

5~6 turn 회전으로 결정적 사실관계 확정.

## cleanup

```bash
rm -f /tmp/visual-verify.cjs /tmp/snap.png /tmp/wt.png
```

다음 세션 시 본 reference를 그대로 부르면 동일 워크플로 재현 가능.
