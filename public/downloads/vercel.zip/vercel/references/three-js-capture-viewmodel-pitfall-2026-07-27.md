# Three.js FPS의 viewmodel closeup 캡처 한계 + 우회 (2026-07-27 실측)

> **Reference** — canvas-static-site-pipeline / vercel 우산. mshumer 스타일 Three.js 정적 FPS 프로젝트의 viewmodel 시각 진단 시 함정 + 우회 4가지.

## 진단: `__APPLY_SHOT__`는 world 카메라만 옮긴다

`src/dev/shots.js`의 shot 핸들러는 다음만 실행:

```js
cam.position.fromArray(shot.pos);     // world camera 위치
cam.lookAt(target);                   // world camera 회전
player?.teleport?.(cam.position, cam.rotation); // 캡슐 동기화
shot.apply?.(engine, opts);           // debugPose('idle' | 'ads' | 'fire')
```

**viewCamera (1인칭 카메라)는 절대 안 건드림** — viewmodel은 viewCamera에 매달려 있어도 캡처는 world camera 시점. 결과:
- `weapon`/`ads`/`muzzle` 샷에서 viewmodel은 화면 모서리에 작게 보임
- 진짜 closeup (손·무기가 화면 70%+ 채움) 캡처 불가

## minimax-of-duty 실측 (2026-07-27)

`node tools/capture.mjs --shot=weapon --out=shots/before.png` → 1920x1080 PNG 정상 캡처 (16.6ms = 60fps). `vision_analyze` 결과:

- 화면 우하단에 rifle 일부 + 탄약 표시 + HUD
- **손가락은 안 보임** — closeup 부재
- 10.5M tri 렌더링은 정상 (3D 씬은 다 그려짐)

즉 캡처는 정상이지만 viewmodel 자체는 카메라에 안 잡힘.

## 우회 패턴 4가지

### 우회 1 — `handcloseup` 샷 + `viewOnly: true` 분기 (가장 정직, 큰 패치)

**`src/dev/shots.js`**:
```js
handcloseup: {
  pos: [0, 1.7, 0],
  look: [0, 1.7, -1],
  fov: 50,
  time: 16.5,
  viewOnly: true,
  apply: (e) => e.ctx.peek('weapons')?.debugPose?.('idle'),
  doc: 'Hand/weapon closeup. For hands.js diagnostics.',
},
```

**`__APPLY_SHOT__`** 안 (world camera 옮긴 후):
```js
if (shot.viewOnly) {
  // viewCamera만 옮김 + viewScene만 렌더하는 패스
  engine.viewCamera.position.fromArray(shot.pos);
  engine.viewCamera.lookAt(new THREE.Vector3().fromArray(shot.look));
  // ⚠️ render/index.js의 render path에 viewScene-only 분기 필요
  // (큰 패치 - HDR 파이프라인 그대로 + viewScene만 그리기)
}
```

### 우회 2 — `weapon` shot의 world camera를 viewmodel 위치에 가깝게 두기

`pos`를 **viewmodel이 매달려 있는 world 위치 (camera 앞 ~30cm)** 근처로 옮기면 viewmodel이 화면을 채움:

```js
weapon: {
  pos: [6.3, 1.7, 9.7],   // 원래 [6, 1.7, 10]에서 살짝 이동
  look: [...viewCamera가 보는 방향 보정...],
}
```

진짜 closeup은 아니지만 viewmodel이 더 커져서 **hands.js 1차 진단에 부분 도움** (손가락 슬랩·그림자 영역은 어쨌든 보임).

### 우회 3 — 라이브 데모에서 직접 gameplay

`https://<alias>.vercel.app` 실제 들어가서:
1. 캔버스 클릭 → 커서 고정
2. WASD로 거리 진입
3. 손가락/머티리얼/성능 직접 평가

자동화 어려움, **사용자 직접 봐야 함**. 진단 정확도 가장 높음.

### 우회 4 — viewer용 dev HTML 추가

`tools/dev/handview.html` 같은 정적 페이지를 작성하여 직접 viewmodel만 띄움 → 별도 캡처/평가.

## 판단 흐름

| 상황 | 권장 우회 |
|---|---|
| 간단 머티리얼/grime 1차 진단 | **2** (world camera 위치 보정) |
| rig/그립 자세 정밀 진단 | **1** (`handcloseup` + viewOnly 패치) |
| 사용자 게임 중 평가 | **3** (라이브 데모) |
| 반복 캡처 워크플로우 | **4** (전용 HTML dev 도구) |

## Pitfall

- **샷 doc을 믿지 말 것**: `weapon` 샷 doc은 "Hip-fire viewmodel — weapon silhouette, materials, hand rig"이지만 실제 캡처는 world camera 리포지션. **반드시 1회 캡처 후 시각 확인**해야 함.
- **`__APPLY_SHOT__` 패치 시 다른 샷에 영향 주의**: `viewOnly: true` 분기 외 모든 경로에서 world camera 정상 이동 필수. 조건문 위치 잘못되면 다른 샷들 깨짐.
- **render 패스 분기(viewScene-only)는 위험 큼**: HDR + tone mapping + FXAA가 viewModel만 보일 때 다르게 동작할 수 있음. **카메라 스왓 + 전체 패스 그대로 그리기**가 안전.
- **mshumer 외 Three.js FPS는 도구/구조가 다름**: `tools/capture.mjs`, `__APPLY_SHOT__`, `__READY__`는 mshumer/Claude-of-Duty 특화. 다른 프로젝트 (예: three.js examples)에서는 별도 진단 필요.

## 재사용

- 다른 Three.js FPS 프로젝트 (`canvas-static-site-pipeline` 우산의 일부)에서 viewmodel closeup 캡처가 필요할 때 → 우회 패턴 1~4 적용.
- 진단 시 **사용자 선호**: 사용자가 "라이브에서 직접 보고 싶다" → 우회 3, "자동 캡처 워크플로" → 우회 1 또는 4.
