# atomic 검증 패턴 — README-only + 파급효과 회귀 (2026-07-02 particle-fireworks)

SKILL.md 본문에 잘 녹이지 못한 **세션별 디테일**: 10 turn 연속 검증 + 🛠️ anchor 함정 발견 + helper 잔재 atomic 패턴.

## v6 → v6.5 누적 검증 라운드 (particle-fireworks)

| Turn | 차원 | 결과 | 핵심 추가 |
|---|---|---|---|
| v1.1 | 로컬 + git | 25/25 | — |
| v2.1 | 표/구조 | 29/29 | — |
| v3.3 | 푸시 raw + bit-perfect | 16/16 | echo 파이프라인 → 파일 shasum |
| v4 | post-push 동기화 | 14/14 | — |
| v5 | .gitignore | 13/13 | — |
| v6 | Vercel alias + 다층 | 43/48 | — |
| v6.1 | helper cleanup | 56/56 | — |
| v6.2 | alias 본문 구조 | 44/48 | **🛠️ 한/영 혼합 anchor 깨짐 발견** |
| v6.3 | anchor 위험 해소 | 27/30 | **🛠️ Tech Stack 보정 후 id 정상 생성** |
| v6.4 | 파급효과 회귀 | 30/30 | **.tmp-*.sh 잔재 false FAIL 발견** |
| v6.5 | atomic 패턴 + WT clean | 37/37 | **진입 정리 + 종료 재검증 패턴** |

## 핵심 발견 1: 🛠️ 이모지 + 한/영 괄호 혼합 → anchor 깨짐

**실제 트리거 헤더** (particle-fireworks README.md):
```diff
- ## 🛠️ 기술 스택 (Tech Stack)
+ ## Tech Stack
```

**v6.2 검증 어서션** (실패 보고):
```bash
! grep -qE "^## 🛠️" README.md && pass "🛠️ H2 미사용 (anchor 안전)"
# ❌ 위 조건 실패 → FAIL
# 이유: ## 🛠️ 기술 스택 (Tech Stack) 헤더가 🛠️ + 한글 + 영문 괄호 혼합
```

**v6.3 보정 후 검증** (성공):
```bash
# 1. 결정적 anchor id 정밀 매칭
grep -qF 'id="user-content-tech-stack"' "$GH_README_HTML"
# ✅ 정상 생성 (직전 turn에 v6.3 patch가 만든 결과)

# 2. 회귀 테스트 (이전 깨진 slug 흔적 부재)
! grep -qF "user-content--tech-stack" "$GH_README_HTML"
! grep -qE "user-content--기술-스택" "$GH_README_HTML"
# ✅ 둘 다 부재
```

**augmented 4단계 검증 어서션**:
1. 정밀 매칭: `id="user-content-<slug>"` ← 단일/이중 prefix 차이 대응 필요
2. 회귀 검증: 잘못된 prefix 흔적 부재
3. 부분 매칭 (fallback): prefix 차이 무관
4. README 헤더 텍스트 존재 확인 (sanity)

## 핵심 발견 2: helper 잔재 + WT dirty → 검증 turn 진입 시 false FAIL 패턴

**v6.4 실측** (가장 시급):
```
=== A. helper 잔존 0 ===
  [FAIL] .tmp-poll.sh 존재            ← 어서션 시점에 unstaged
  [FAIL] .tmp-v6-3.sh 존재            ← 동일
  [FAIL] WT 변경 안 한 작업 = 2       ← helper 2개
```

**원인**: vercel deploy + 검증 워크플로에서 단발성 helper (`.tmp-deploy.sh`, `.tmp-poll.sh` 등) 가 매 turn마다 만들어짐. 검증 스크립트가 끝나서 정리는 했지만, **다음 turn 시작 시점에 같은 unstaged 파일이 또 helper로 만들어져** false FAIL 반복.

**해결 — atomic 검증 패턴 (v6.5 검증된 37/37)**:

```bash
#!/usr/bin/env bash
# 진입 시점: helper + WT 즉시 정리 (★★ 핵심)
cd /Users/mac/work/<project>
rm -f .tmp-*.sh 2>/dev/null

TMP_BEFORE=$(ls .tmp-*.sh 2>/dev/null | wc -l | tr -d ' ')
WT_BEFORE=$(git status --porcelain 2>/dev/null | wc -l | tr -d ' ')
# → 어서션 (진입 helper 0개, 진입 WT 0개)

# ... 본 검증 어서션들 (A. 푸시 4중 / B. alias HTTP / C. README SHA / D. anchor 회귀 / ...) ...

# 종료 시점: helper 재청소 + 재검증 (★★ 같은 패턴, 출력 가시성)
rm -f .tmp-*.sh 2>/dev/null
TMP_AFTER=$(ls .tmp-*.sh 2>/dev/null | wc -l | tr -d ' ')
WT_AFTER=$(git status --porcelain 2>/dev/null | wc -l | tr -d ' ')
# → 어서션 (종료 helper 0개, 종료 WT 0개)
```

**왜 atomic이 필요한가**: `git status --porcelain`이 "unstaged 변경 없음" 검증 어서션인데, **검증 스크립트 자체가 만드는 helper**도 unstaged로 잡혀서 매 turn FAIL. 진입 정리로 어서션 정직성 + 종료 재검증으로 워크플로 안전성 확보.

## 누적 검증 회차의 가치

10 turn 연속 검증을 하면서 매번 다른 차원 (파일 무결성 / SHA / API SHA / UI HTML / Vercel status / anchor / WT) 을 회전. **false FAIL 원인을 매번 정확히 분류**하고 한 차원씩 좁혀가며 결정적 사실관계 입증.

**차원 회전 패턴** (다음 repo 부트스트랩 시 기본 템플릿):
```
v1: 로컬 (파일 존재 + 사이즈 + H1)
v2: git (커밋 + WT + 푸시 사실관계)
v3: 원격 raw SHA
v4: 원격 API SHA
v5: Vercel alias HTTP 200 + bit-perfect
v6: 코딩 미션 다층 마커 8/8
v7: anchor 패턴 (단일/이중 prefix 회귀)
v8: WT clean / helper 0개 atomic 검증
```

→ 매 turn 다른 차원. 같은 어서션 2번 반복 안 함.

## 보강된 anchor 검증 어서션 (v6.5)

```bash
# 1단계: 결정적 anchor id 정밀 매칭 (단일 hyphen prefix)
grep -qF 'id="user-content-tech-stack"' "$GH_README_HTML"

# 2단계: 잘못된 prefix 흔적 부재 (회귀)
! grep -qF 'user-content--tech-stack' "$GH_README_HTML"

# 3단계: 부분 매칭 (prefix 무관 fallback) — 7개 anchor
for anchor_key in "라이브-데모" "라이브" "quick-start" "features" "tech-stack" "design-choices" "controls"; do
  grep -qF "$anchor_key" "$GH_README_HTML"
done

# 4단계: README 헤더 텍스트 존재 (sanity)
grep -qF "## Tech Stack" README.md
```

→ 1+2+3+4 모두 통과해야 진짜 anchor 호환.

## particle-fireworks 운영 데이터 (2026-07-02)

- **alias**: https://particle-fireworks.vercel.app/ (자동 할당 — suffix 없음)
- **HEAD**: `7d2f70b` (anchor 보정)
- **5 commits**: scaffold → index.html → gitignore 보강 → README 다층 → anchor 보정
- **index.html**: 31,180 bytes, SHA `a22fa890…` (alias와 bit-perfect)
- **8/8 README 다층 마커 점수**: Live Demo · Features · Tech Stack · License · MIT · cokac · English · align=center
