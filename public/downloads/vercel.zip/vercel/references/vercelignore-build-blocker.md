# `.vercelignore` 빌드 차단 함정 — 진단 + 수정 (sango-rising-dragons 2026-07-20)

## 증상 (Vercel 빌드 로그)

```
> sango-rising-dragons@0.1.0 build
> tsc --noEmit && vite build

error TS18003: No inputs were found in config file '/vercel/path0/tsconfig.json'.
Specified 'include' paths were '["src"]' and 'exclude' paths were '[]'.
Error: Command "npm run build" exited with 2
```

Vite 단독 프레임워크도 동일 증상 가능: `rollup could not resolve` 또는 빈 `dist/`.

## 진단 3축 (로컬은 멀쩡한데 Vercel만 실패)

| 축 | 명령 | 정상 | 비정상 |
|---|---|---|---|
| 1. 로컬 빌드 | `npm run build` | ✓ 2.42s | 로컬은 멀쩡 — `.vercelignore` 무시 |
| 2. Vercel 업로드 파일 수 | `vercel --yes --prod` 첫 줄 로그 | `Uploading [====================] (1.6MB/1.6MB)` | **120 files** (정상 237+ 예상) |
| 3. `.vercelignore` 검사 | `grep -xE 'src|public|\*.ts|index.html|package.json|vercel.json' .vercelignore` | 빈 출력 | 하나라도 매치 |

**차이 신호**: 업로드 파일 수가 비정상적으로 적으면 `.vercelignore` 의심. sango-rising-dragons는 130개 로컬 파일 중 120개만 업로드 → 10개 (= src/ 11개 거의 정확) 누락 확인.

## 원인: `.vercelignore`가 빌드 입력을 차단

```gitignore
# ❌ 잘못된 .vercelignore (sango-rising-dragons v0.3 발견)
node_modules/
src/           ← 빌드 입력 (TypeScript 소스)
screenshots/
play.sh
.git/
.gitignore
*.md
!README.md
*.log
.DS_Store
public/        ← 런타임 데이터/에셋
*.ts           ← 빌드 입력
```

`.vercelignore`는 Vercel의 빌드 컨텍스트에 직접 적용 — `.gitignore`와 다름. `.gitignore`는 빌드 컨텍스트와 무관하지만 `.vercelignore`는 무시된 파일이 빌드 머신에 아예 안 올라감.

## 수정 (sigco3111 표준 정형)

```gitignore
# Vercel이 무시할 파일 (빌드/런타임과 무관한 로컬 산출물만)
node_modules/
.git/
.gitignore
screenshots/        # 시각 검증 부산물
*.log
.DS_Store
*.md
!README.md
```

**포함해야 할 것 (절대 차단 X)**: `src/`, `public/`, `*.ts`, `*.tsx`, `index.html`, `package.json`, `vercel.json`, `vite.config.*`, `tsconfig.json`.

## 보강: 원격 선택 비대화형 처리 (첫 배포 시)

`vercel --yes --prod` 첫 실행에서 **fork repo + upstream remote 둘 다 있을 때** GitHub 연결 프롬프트가 떠요:

```
? Which remote do you want to connect? (Use arrow keys)
❯ https://github.com/ryantsai/sango-rising-dragons.git (upstream)
  https://github.com/sigco3111/sango-rising-dragons-kr.git (origin)
```

**비결정적 인터랙티브 회피**:
```bash
# stdin으로 번호 선택 (위/아래 화살표 + Enter 동일 효과)
printf "2\n" | vercel --yes --prod --token "$TOK"
```

번호는 **출력 순서대로**: 위(1), 다음(2). `^B` (위), `^F` (아래)도 가능하지만 `printf "2\n"`이 가장 안전.

또는 비대화형 강제: `--git https://github.com/sigco3111/sango-rising-dragons-kr.git` 명시.

## 검증 (수정 후 재배포)

```bash
TOK=$(cat ~/.hermes/secrets/vercel_token.txt)
cd /Users/mac/work/sango-rising-dragons

# 1. 빌드 컨텍스트 파일 수 확인 (120 → 237+ 회복)
printf "2\n" | vercel --yes --prod --token "$TOK" 2>&1 | grep -E "Uploading|Downloading"

# 2. 빌드 성공 시그널
printf "2\n" | vercel --yes --prod --token "$TOK" 2>&1 | grep -E "Built in|✓ Ready"

# 3. alias 검증 (anon 200)
ALIAS="https://sango-rising-dragons.vercel.app"
curl -sI "$ALIAS" | head -1  # → HTTP/2 200
```

## 부산물 정리

`.vercelignore` 수정 후 재푸시 + `.gitignore`에서 `.vercel` 라인 제거 + `.vercel/` 커밋 패턴 동일 (§Vercel deploy 부산물 참조).

## 운영 데이터 (sango-rising-dragons 2026-07-20)

- **alias**: https://sango-rising-dragons.vercel.app (자동 할당, suffix 없음)
- **HEAD**: `b371ed8` (.vercelignore 수정) → `3a65bbe` (README Live Demo)
- **빌드**: vite v6.4.3, 17 modules transformed, 6.37s, 25s Ready
- **빌드 컨텍스트 변화**: 120 files → 237 files (src/ 11개 복귀)
- **한국어 데이터 fetch 확인**: `curl /data/ko/factions.json` → 조조군/유비군/손견군 정상 노출