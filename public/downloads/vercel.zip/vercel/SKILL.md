---
name: vercel
description: Vercel CLI 기반 배포 관리 — 프로젝트 배포, 환경변수 설정, 도메인 관리, 로그 확인, ... — 프로젝트 배포, 환경변수 설정, 도메인 관리, 로그 확인, 프로젝트 나열
---

# Vercel 배포 관리

Vercel CLI를 사용하여 프로젝트를 배포하고 관리하는 스킬.

## 전제 조건

- Vercel CLI 설치: `npm i -g vercel`
- 인증 완료: `~/.vercel/credentials.json` 또는 Vercel 토큰 (`~/.hermes/secrets/vercel_token.txt`)
- 계정: `vercel whoami`로 확인

## 토큰 위치

토큰 파일: `~/.hermes/secrets/vercel_token.txt`
토큰 형식: `vcp_...`

## 기본 명령어 패턴

모든 명령어에 `--token $(cat ~/.hermes/secrets/vercel_token.txt)` 또는 `--yes` 플래그를 사용하여 비대화형으로 실행.
토큰 포맷: vcp_xxxx... (실제 토큰은 ~/.hermes/secrets/vercel_token.txt에서 관리)
```
> ⚠️ `~/.vercel/auth.json`이 아님. 토큰이 없다면 `session_search`로 "vercel token deploy" 검색하여 이전 세션에서 토큰 확인 가능.

## 기본 명령어 패턴

모든 명령어에 `--token $VERCEL_TOKEN` 또는 `--yes` 플래그를 사용하여 비대화형으로 실행.

## 주요 작업

### 1. 프로젝트 나열

```bash
vercel list 2>&1
```

### 2. 프로젝트 배포 (새 프로젝트)

```bash
# GitHub 레포에서 배포
git clone <repo-url> /tmp/deploy-<name>
cd /tmp/deploy-<name>
vercel --yes --prod 2>&1
```

```bash
# 특정 빌드 설정으로 배포
cd /path/to/project
vercel --yes --prod \
  --build-command "npm run build" \
  --output-directory "dist" \
  --framework "vite" 2>&1
```

### 3. 기존 프로젝트에 재배포

```bash
cd /path/to/project
vercel --yes --prod 2>&1
```

### 4. 특정 프로젝트에 배포 (프로젝트명 지정)

```bash
vercel --yes --prod --project <project-name> 2>&1
```

### 5. 환경변수 관리

```bash
# 환경변수 추가
vercel env add <KEY> <environment> 2>&1
# environment: production, preview, development

# 환경변수 나열
vercel env ls <project-name> 2>&1

# 환경변수 삭제
vercel env rm <KEY> <environment> --yes 2>&1

# .env 파일에서 일괄 import
vercel env pull .env.local 2>&1
```

### 6. 도메인 관리

```bash
# 도메인 추가
vercel domains add <domain> <project-name> 2>&1

# 도메인 나열
vercel domains ls <project-name> 2>&1
```

### 7. 배포 로그 확인

```bash
# 최근 배포 로그
vercel logs <project-name> 2>&1

# 특정 배포 로그
vercel logs <deployment-url> 2>&1
```

### 8. 배포 내역 확인

```bash
vercel ls <project-name> 2>&1
```

### 9. 배포 롤백

```bash
# 특정 배포로 프로덕션 롤백
vercel rollback <project-name> <deployment-url> 2>&1
```

### 10. 프로젝트 삭제

```bash
vercel remove <project-name> --yes 2>&1
```

## 배포 워크플로우

### GitHub 레포 → Vercel 배포 전체 흐름

**Case A: 새 클론에서 배포**
1. 레포 클론: `git clone <url> /tmp/deploy-<name>`
2. 의존성 설치: `npm install` (필요시)
3. 빌드 설정 확인: `package.json` 의 scripts, framework 감지
4. 배포 실행: `vercel --yes --prod`
5. 결과 URL 확인 및 전달

**Case B: 기존 로컬 디렉토리에서 배포 (⚠️ 이 경우 먼저 git pull 필수)**
```bash
cd /path/to/project
git pull origin main  # 로컬이 원격보다 오래된 경우 먼저 동기화
vercel --yes --prod --token $(cat ~/.hermes/secrets/vercel_token.txt)
```

### 자동 감지되는 프레임워크

Vercel이 `package.json` 기반으로 자동 감지함:
- Next.js, Vite, React, Vue, Nuxt, Svelte, Astro, Remix, Gatsby 등
- 수동 지정이 필요한 경우 `--framework` 플래그 사용

## 주의사항

- `--yes` 플래그: 모든 프롬프트에 자동 응답 (비대화형 배포 필수)
- `--prod`: 프로덕션 배포 (생략 시 프리뷰 배포)
- 배포 실패 시 `vercel logs`로 원인 확인
- 대용량 프로젝트는 `--no-cache`로 캐시 무시 가능
- `/tmp/` 에 클론한 배포 폴더는 배포 완료 후 정리할 것
