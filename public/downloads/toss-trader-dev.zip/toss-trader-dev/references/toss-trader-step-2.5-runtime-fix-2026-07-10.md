# v1.0.1 런타임 fix 3건 (2026-07-10)

toss-trader v1.0 첫 실행 시 발견된 런타임 에러 3건 + fix. v1.1 이상 모든 toss-trader 작업에 적용 필수.

## Fix 1: `holdings.reduce is not a function`

### 증상
```
TypeError: holdings.reduce is not a function
    at Portfolio (components/Portfolio.tsx:125:28)
```

### 원인
토스 Open API `/api/v1/holdings` 응답:
```json
{
  "data": {
    "result": {
      "totalPurchaseAmount": { "krw": "0" },
      "items": []  // ← 배열
    }
  }
}
```
→ `data` 자체는 **객체**. 기존 코드가 `data`를 setHoldings에 넣어 `holdings = { result: { items: [] } }` (객체).
→ `.reduce(객체)` → TypeError.

`/api/v1/prices?symbols=...` 응답:
```json
{
  "data": {
    "result": [  // ← 배열
      { "symbol": "005930", "lastPrice": "75000", "currency": "KRW" }
    ]
  }
}
```
→ `data.result` = 배열. `lastPrice`는 **문자열**.

### Fix (components/Portfolio.tsx)

```typescript
// holdings: 객체 안 result.items 추출
const rawData = (holdingsBody as ApiEnvelope<unknown>).data;
const items = Array.isArray(rawData)
  ? (rawData as HoldingItem[])
  : (rawData as { result?: { items?: HoldingItem[] } })?.result?.items ?? [];
setHoldings(items);

// prices: 배열 또는 { result: [...] } 둘 다 처리 + lastPrice string → number
const rawPriceData = (priceBody as ApiEnvelope<unknown>).data;
const priceArr = Array.isArray(rawPriceData)
  ? (rawPriceData as Array<{ symbol: string; lastPrice: string | number }>)
  : ((rawPriceData as { result?: Array<{ symbol: string; lastPrice: string | number }> })?.result ?? []);
for (const p of priceArr) {
  if (p && typeof p.symbol === "string") {
    const n = Number(p.lastPrice);
    if (Number.isFinite(n)) priceMap[p.symbol] = n;
  }
}
```

### 패턴: 토스 API 응답 구조 처리

| endpoint | data 구조 | 비고 |
|---|---|---|
| `/api/v1/holdings` | `{ result: { items: [...], totalPurchaseAmount, marketValue, profitLoss } }` | 객체 |
| `/api/v1/prices` | `{ result: [{ symbol, lastPrice, currency, timestamp }] }` | 배열 |
| `/api/v1/accounts` | `{ result: [{ accountSeq, accountName }] }` | 배열 |
| `/api/v1/orders` (paper mock) | `{ result: { orderId, status, executedAt } }` | 객체 |

**공통**: `Array.isArray(rawData)` 가드 + `.result?.items ?? []` / `.result ?? []` 패턴.

## Fix 2: HMR WebSocket LAN IP 실패 → 인터랙션 차단

### 증상
- DevTools Console에 `WebSocket connection to 'ws://192.168.10.71:3000/_next/webpack-hmr?...' failed` 10개 에러
- 매수 진행 버튼, 발송 버튼 등 **클릭 자체가 안 먹음** (React onClick 핸들러 미등록)

### 원인
Next.js 16 dev mode가 HMR(Hot Module Reload)을 위해 WebSocket 사용. LAN IP(`192.168.10.71:3000`)로 연결 시도 → 방화벽/네트워크 차단 → hydration mismatch → React가 클라이언트 측 핸들러를 등록 안 함.

### Fix
```bash
# 1) 기존 dev 서버 종료
pkill -f "next dev"

# 2) 안전 모드로 재시작 (localhost만 바인딩)
cd /Users/mac/work/toss-trader
npx next dev -H 127.0.0.1 -p 3000
```

브라우저 `http://127.0.0.1:3000` 또는 `http://localhost:3000` 접속 → WebSocket도 localhost → 방화벽 통과 → hydration 정상 → 버튼 작동.

### 영향
- **dev 환경에서만 발생** (Vercel prod 영향 없음)
- LAN IP로 다른 PC에서 접속 시 같은 에러 → **localhost만 허용**
- 영구 해결은 `next.config.ts`의 `allowedDevOrigins` (Next 15+) 또는 `experimental.serverActions.allowedOrigins`. **v1.4+ 검토**.

## Fix 3: TELEGRAM_CHAT_ID = 봇 ID

### 증상
```
{"ok":false,"error_code":403,"description":"Forbidden: the bot can't send messages to the bot"}
```

### 원인
`TELEGRAM_BOT_TOKEN=8931342574:AAFaM76sXmyqrP_kweQc9-xcZVOpp-SA-4I`에서 콜론 앞 `8931342574` = **봇의 ID**. 이걸 그대로 `TELEGRAM_CHAT_ID=8931342574`로 설정 → 봇이 자기 자신한테 메시지 보내려 시도 → 403.

### Fix
1. Telegram 앱 → 검색 → **`@userinfobot`** → 채팅방 열기
2. **`/start`** 입력
3. 봇 응답: `Id: 712345678` (본인 user_id) → `.env`의 `TELEGRAM_CHAT_ID=712345678`

### 패턴: 시크릿 분리
- `TELEGRAM_BOT_TOKEN`: 봇의 인증 토큰 (`{bot_id}:{hash}` 형식)
- `TELEGRAM_CHAT_ID`: 메시지 **받을 사람/그룹**의 ID (봇과 다름)
- 봇 ID와 chat_id가 같으면 403.

상세: `references/telegram-chat-id.md`

## 적용 체크리스트

toss-trader v1.0.1 이전 사용자가 v1.0.1 이후로 업그레이드 시:
- [x] components/Portfolio.tsx가 holdings/prices 응답 가드 + lastPrice 변환 코드 포함 (v1.0.1 PR에 포함)
- [x] dev 서버 실행 명령이 `npx next dev -H 127.0.0.1 -p 3000` (README 비개발자 가이드)
- [x] TELEGRAM_CHAT_ID ≠ 봇 ID 검증 (Owner가 직접 userinfobot으로 확인)

## 검증

```bash
# dev 재시작 후 콘솔 확인
pkill -f "next dev"
npx next dev -H 127.0.0.1 -p 3000
# 브라우저 DevTools Console에 WebSocket 에러 0개
# 매수/매도 버튼 정상 작동
# 401 Unauthorized 또는 403 에러 0개
```

## 참고

- v1.0.1 커밋: `fix(portfolio): holdings.reduce 에러 + prices 응답 mismatch (81/81)`
- TDD 사이클: 1차 4/13 fail (TelegramConfirmMode 타입) → 2차 13/13 PASS
- 관련 fix: v1.1.4에서 4-모드 → 3-모드 단순화 시 CHAT_ID 호환성 유지
