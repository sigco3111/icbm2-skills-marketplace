---
title: tossinvest-agent 신규 아키텍처 (origin/main, 2026-07-14)
description: toss-trader → tossinvest-agent 리네임 + OpenCode runner + 12 endpoint 시장 컨텍스트 + 서버 메모리 세션 + 자동매매 Phase 8 계획
created: 2026-07-14
source_session: toss-trader `git reset --hard origin/main` 후 분석
applies_to: /Users/mac/work/toss-trader (현 origin/main = `a86a404`)
---

# tossinvest-agent — 현 origin/main 아키텍처

## TL;DR

**이름 변경**: `toss-trader` (투자 어시스턴트) → **`tossinvest-agent`** (자동매매 에이전트).
**핵심 의도**: kstost/stock 차용 + Codex CLI → **OpenCode CLI** 교체 (구독료 zero).
**자동매매 미구현**, Phase 8 계획만 README에 명시. **테스트 인프라 삭제됨** (vitest/Playwright 스크립트 0).

## 디렉토리 (v1.4.2 → origin/main 차이)

```
app/                                   # Next.js App Router
  page.tsx                             # 1108줄 단일 페이지 (shadcn/ui)
  layout.tsx
  api/
    session/route.ts                   # API Key/Secret 세션 생성 + .env.local 폴백
    session/credentials-info/route.ts  # env 키 사용 가능 여부 (값 안 줌)
    agent/run/route.ts                 # OpenCode 분석 (MarketContext 12 endpoint 첨부)
    order/route.ts                     # Toss 주문 요청 (LIMIT)
    stocks/
      search/route.ts                  # 종목 자동완성 (4단계 fuzzy)
      refresh/route.ts                 # 마스터 새로고침 (batch fetch + cache upsert)
    # 사라짐: history/ route (로컬 JSON 직접 조회로 page.tsx 내부 처리)
    # 사라짐: toss/[...path] relay (직접 호출로 전환)
    # 사라짐: telegram/send + callback (자동매매 단계에서 재도입 예정)
components/
  StockSearch.tsx                      # 종목 자동완성 UI (KR/US 통합)
  ui/                                  # shadcn/ui 8종 (badge/button/card/dropdown/input/label/textarea)
lib/
  agents/
    shared.ts                          # system prompt + 검증 (agent 공용)
    opencode/runner.ts                 # opencode run --format json spawn 래퍼
    index.ts                           # AGENT_KIND 라우터 (opencode/codex, codex는 미번들)
  agent.ts                             # 호환 re-export
  tossinvest.ts                        # 토스 Open API 클라이언트 + 토큰 캐싱
  market-context.ts                    # 12 endpoint 병렬 수집 + Promise.allSettled
  history.ts                           # history 파일 저장/조회 (1 record = 1 file)
  session-store.ts                     # 서버 메모리 세션 (globalThis 단일)
  stocks.ts                            # 4단계 fuzzy 매칭
  stocks-cache.ts                      # 동적 캐시 (런타임 종목 추가)
  stocks-seed.json                     # 정적 시드 (KR 3,739 / US 1,499)
  popular-stocks.ts                    # 인기 종목 리스트 (KR/US 주식 + ETF)
  types.ts                             # 공유 타입
  utils.ts                             # 포맷/유틸
schemas/investment-agent-output.schema.json
tossinvest_apidocs.json                # 토스증권 OpenAPI 문서
prompt.txt                             # 원작자 system prompt 원본 (참고용)
```

## 핵심 데이터 흐름

```
사용자: [시작] 클릭
  ↓
POST /api/session { apiKey, secretKey, targetSymbol, targetMarket, intervalSeconds }
  ├─ resolveCredentials() → .env.local 폴백 (TOSSINVEST_DEFAULT_API_KEY/SECRET)
  ├─ crypto.randomUUID()로 sessionId 생성
  └─ createSession() → globalThis.__tossinvestAgentSession 저장 + redactSession() 응답
  ↓
interval 마다 [자동 분석 트리거]
  ↓
POST /api/agent/run { sessionId }
  ├─ getSession(sessionId) → 글로벌 세션
  ├─ collectMarketContext(session, symbol, market)  ← 12 endpoint 병렬
  │   ├─ authenticate() → /oauth2/token (캐시됨)
  │   ├─ /api/v1/accounts → accountSeq
  │   └─ 12 endpoint Promise.allSettled (실패해도 진행)
  │       price / orderbook / recentTrades / priceLimits / candles
  │       stockInfo / warnings / marketCalendarKR / exchangeRate
  │       holdings / buyingPower / sellableQuantity
  ├─ runInvestmentAgent(session, context) → spawn opencode
  │   ├─ buildPrompt() → system prompt + MarketContext JSON 첨부
  │   ├─ opencode run --format json --auto --dir {cwd} -
  │   ├─ parseRecommendation() → schema 검증
  │   └─ redact() → apiKey/secretKey 마스킹
  ├─ writeHistory({ kind: "analysis", recommendation, context, ... })
  └─ updateLatestRecommendation() → 세션에 latestRecommendation 갱신
  ↓
사용자: [BUY] / [SELL] 버튼
  ↓
POST /api/order { sessionId, symbol, market, side, quantity, limitPrice, currency }
  ├─ session 검증
  ├─ createLimitOrder() → 토큰 재발급 → /api/v1/orders POST (LIMIT, confirmHighValueOrder=false)
  └─ writeHistory({ kind: "order", request, response })
```

## OpenCode Runner 함정 (lib/agents/opencode/runner.ts)

### spawn 패턴
```typescript
const args = ["run", "--format", "json", "--auto", "--dir", process.cwd(), "-"];
const child = spawn(opencodeBin, args, {
  cwd: process.cwd(),
  env: {
    ...process.env,
    TOSSINVEST_API_KEY: session.apiKey,
    TOSSINVEST_SECRET_KEY: session.secretKey,
    TOSSINVEST_APIDOCS_PATH: apiDocsPath,
    TOSSINVEST_HISTORY_DIR: historyPath,
    TOSSINVEST_BASE_URL: "https://openapi.tossinvest.com",
  },
  stdio: ["pipe", "pipe", "pipe"],
});
```

### stdout JSONL 파싱
- `--format json` → stdout은 JSONL, 최종 응답은 `{"type":"text","part":{"text":"..."}}`
- `parseRecommendation()`는 마크다운 펜스 + outermost `{...}` 양쪽 fallback
- 비어있거나 JSON이 아니면 즉시 throw (HOLD fallback)

### 안전장치
1. **timeout 10분** (`runTimeoutMs`) — SIGTERM 후 5초 뒤 SIGKILL
2. **redact 8자 미만 키 스킵** — JSON 깨짐 방지 (v1.4.2 candles와 동일 학습)
3. **trimForHistory 40000자** — history 파일 비대화 방지
4. **session 메모리 키** → child env로만 전달 (file/claude.md 등 외부 노출 차단)

### 검증 (parseRecommendation)
- `HOLD` → `order` 반드시 null
- `BUY/SELL` → `order` 필수 (quantity > 0, limitPrice > 0, currency KRW/USD)
- `confidence` 0~1, `references` URL http/https 필수
- 배열 wrapping 시 `[0]` 사용 (codex 등 일부 runner가 배열로 감쌈)

## 토큰 캐싱 (lib/tossinvest.ts)

```typescript
const tokenCache = new Map<string, CachedToken>();  // apiKey → { token, expiresAt }
const inflightToken = new Map<string, Promise<string>>();  // 동시 coalescing
const TOKEN_REFRESH_MARGIN_MS = 60 * 60 * 1000;  // 1h margin
```

- 토큰 lifetime = `expires_in` 또는 기본 24h
- 같은 apiKey 동시 요청 시 `inflightToken` Map으로 단일 in-flight 보장
- `authenticate()` = `getAccessToken() + getAccounts()`

## Session Store 함정 (lib/session-store.ts)

### 단일 세션 (globalThis 패턴)
```typescript
declare global {
  var __tossinvestAgentSession: SessionState | undefined;
}
// createSession() 시 덮어쓰기 → 동시 사용자 2명이면 세션 충돌
```

### `redactSession()` — 클라이언트 응답에 키 절대 미포함
```typescript
return {
  id, createdAt, instructions, intervalSeconds,
  targetSymbol, targetMarket, latestRecommendation, latestHistoryFile,
  // apiKey, secretKey 의도적 제외
};
```

## Market Context 12 endpoint

`lib/market-context.ts:collectMarketContext()` 패턴:

1. **auth 먼저** — 실패 시 ctx에 error 기록 + 즉시 반환
2. **9개 public endpoint** Promise.all — prices/orderbook/trades/price-limits/candles(1d×20)/stocks(stockInfo)/stocks/{symbol}/warnings/market-calendar/KR/exchange-rate
3. **3개 account-scoped endpoint** — holdings/buying-power/sellable-quantity (KRW/USD 분기)
4. **envelope unwrap** — `{result: ...}` 자동 처리 (`"result" in value` 체크)
5. **에러 수집** — `ctx.errors[]`에 endpoint/status/message 기록
6. **best-effort 캐시 upsert** — stockInfo 응답을 `lib/stocks-cache.ts`로 누적 (실패 무관)

### 비용 분석 (30초 주기 시)
- 1 oauth2/token (캐시) + 12 GET/주기 = ~1440/h
- 토스 rate limit 미공개지만 안전 범위

## 마스터 새로고침 (lib/stocks-cache.ts + stocks/refresh/route.ts)

- `POST /api/stocks/refresh?market=US|KR|all`
- `lib/popular-stocks.ts`에서 최대 100개 batch fetch (Toss API 100+ 시 500 반환 케이스)
- `inferMarket()` 정규화 — `NASDAQ/NYSE/AMEX/US → US`, 그 외 KR (단, symbol이 popular에 있으면 popular 매핑 우선)
- `upsertStockEntries()` → `stocks-cache.json` (gitignore됨, 런타임 누적)
- 응답: `{ added, total, market, missing, fetchedAt }`

## 자동매매 로드맵 (Phase 8, 미구현)

README 402-422줄 명시:

**안전장치 4중**:
1. 킬 스위치 `AUTO_TRADING_ENABLED=false` (기본값 false, 명시 true만 활성)
2. 세션 스코프 화이트리스트 (targetSymbol 외 거부)
3. 장 운영시간 + 휴장일 (KRX/US KST)
4. LLM 신뢰도 게이트 (confidence < 0.6 → HOLD 격하)

**계획서**: `.hermes/plans/2026-07-13_075854-full-autotrading.md`

**Phase 구성** (8단계 추정): vitest 복원 → 결정 인프라 → Audit → 장시간 → 신뢰도 → 스케줄러 → 4중 통합 → 알림+UI → 검증.

## 위험 요소 5건 (현 시점)

1. **세션 단일성** — `globalThis.__tossinvestAgentSession` 1개. 동시 사용자 = 충돌. **로컬 dev 전용 가정**.
2. **세션 메모리 평문 보관** — `apiKey`/`secretKey` 메모리 상주. Vercel serverless cold start 시 휘발 OK, 하지만 **모든 로그는 redact 필수** (현재 구현됨 ✅ — `redact()` 8자 미만 스킵).
3. **`/api/order` 직접 호출** — UI 버튼으로만 (현재 ✅), 그러나 **CSRF/세션 가드 없음**. 누구나 세션 ID 알면 BUY/SELL 가능 → **세션 ID는 UUID v4 + 응답에 포함되지만 HTTPS + 같은 origin 외 호출 시 차단 없음**.
4. **OpenCode runner `--auto`** — non-denied tool 자동 승인. child process spawn이므로 host filesystem 접근 가능 (env에 cwd 노출).
5. **자동매매 미구현** — `AUTO_TRADING_ENABLED=false` 기본값 필수.

## 안전 요소 ✅

- `redact()` 8자 미만 키 스킵 (JSON 깨짐 방지)
- `redactSession()` — 클라이언트 응답에서 키 완전 제거
- `credentials-info` — env 키 길이만 반환, 값 안 줌
- `writeHistory(epochSeconds)` — atomic write + suffix 충돌 회피
- 토큰 캐시 — `expires_in` + 1h refresh margin + concurrent coalescing
- envelope unwrap — `{result: ...}` 자동 처리
- `confidence 0-1`, `HOLD→order=null` 등 schema 검증
- `.env.local` chmod 600 + `.gitignore`로 안전

## 작업 시작 체크리스트 (현 origin/main)

```bash
# 1) cd
cd /Users/mac/work/toss-trader

# 2) 환경 점검
which opencode && opencode --version
ls -la .env .env.example
# .env에 TOSSINVEST_DEFAULT_API_KEY / SECRET (선택, .env.local 권장)

# 3) dev 서버
npm run dev
# http://localhost:3000

# 4) 자동매매 비활성 확인
grep "AUTO_TRADING_ENABLED" .env  # 없거나 false여야 함

# 5) 검증 (현 시점 테스트 스크립트 0)
npm run build   # 8 routes 빌드 OK 확인
npm run lint    # 0 errors
```

## 복구 패턴 (v1.4.2 ↔ tossinvest-agent 왕복)

```bash
# v1.4.2 candles fix SHA: 015e5e5 (reflog 90일)

# v1.4.2로 돌아가기 (옛 워크플로 복귀)
git reset --hard 015e5e5

# 다시 origin/main으로
git fetch origin && git reset --hard origin/main
# → v1.4.2는 reflog에서만 보존 (~90일)

# 양쪽 보존이 필요하면 브랜치
git checkout -b v1.4.x-legacy 015e5e5
# → main은 그대로 origin/main 유지
```

## References (SKILL.md 안 다른 참조 파일)

- `references/telegram-chat-id.md` — v1.4.x 전용 (Telegram confirm 사라짐, 참고용)
- `references/toss-trader-step-2.5-runtime-fix-2026-07-10.md` — v1.4.x 런타임 3건 fix
- `references/aws-sigv4-toss.md` — v1.3 storage (현 코드에서 사라짐, 참고용)
- `references/next-16-react-19-patterns.md` — Next 16 + React 19 패턴 (일부 적용)
- `references/v1.3-storage-and-e2e-mock.md` — v1.3 storage (현 코드에서 사라짐)
- `references/v1.4-candle-chart-pattern.md` — v1.4 캔들 차트 (현 코드에서 사라짐)
- `references/mock-realism-api-integration.md` — 일반화 가능한 mock 정합화 체크리스트 (여전히 유효)

## 다음 세션 권장

1. **자동매매 Phase 8 계획 검토** — `.hermes/plans/2026-07-13_075854-full-autotrading.md` 우선
2. **테스트 인프라 복원** — vitest + Playwright 다시 도입 (Phase 1)
3. **OpenCode NIM 호스팅 검증** — `~/.config/opencode/opencode.json` provider 설정
4. **자동매매 활성화 전 paper 모드 1주일** — README 421줄 권고