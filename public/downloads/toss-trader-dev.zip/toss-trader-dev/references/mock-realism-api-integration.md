# Mock Realism — API 통합 TDD 일반 교훈

**날짜**: 2026-07-10 (toss-trader v1.4.2 candles 학습에서 일반화)
**출처**: `/Users/mac/work/toss-trader` v1.4.2 (`fix(candles): v1.4.2 — 토스 Open API 응답 정규화`)
**적용 범위**: 모든 API 통합 프로젝트 (Next.js + Express + FastAPI + Go 등)

---

## 1. 핵심 함정: False GREEN

테스트가 인터페이스 **추측**으로 mock 작성 → GREEN → 코드 적용 → **런타임에서 조용히 실패**.

**toss-trader v1.4.2 실측**:
- 테스트 mock: `{ open: 285000, high: 297000, low: 282000, close: 296500, volume: 23806752, timestamp: 1700000000000 }`
- 실제 API 응답: `{ openPrice: "285000", highPrice: "297000", lowPrice: "282000", closePrice: "296500", volume: "23806752", timestamp: "2026-07-10T00:00:00.000+09:00" }`
- 차이: 필드명 4종 + string vs number + ISO vs epoch + envelope nested + 정렬
- 결과: 모든 값 `undefined` → `Math.min(...undefined) = NaN` → 차트 "데이터 없음" 표시

---

## 2. 진단 워크플로우 (실측 5단계)

```bash
# 1) 실제 응답 직접 확인 — 가장 중요 (가정 ❌)
curl -s "http://localhost:3000/api/<endpoint>?..." | python3 -m json.tool | head -50

# 2) 응답 vs mock 비교 (체크리스트):
#    - 필드명: openPrice vs open
#    - 타입: string "285000" vs number 285000
#    - envelope: { data: { result: { items: [...] } } } vs 직접 배열
#    - 정렬: newest-first vs oldest-first
#    - null/empty 처리

# 3) 차이점 있으면 mock 수정 → RED → GREEN
# 4) 정합화된 mock으로 기존 테스트 갱신 + 신규 케이스 추가
# 5) 시각/동작 검증 (Playwright DOM check, console error 0)
```

---

## 3. 6가지 Mock Realism 규칙

### 규칙 1: 필드명은 wire 그대로

```typescript
// ❌ 인터페이스 추측
const SAMPLE = [{ open: 70000, high: 71000 }];

// ✅ curl 응답 그대로
const SAMPLE = [{ openPrice: "70000", highPrice: "71000" }];
```

**Boundary에서 cast** (정규화 함수):
```typescript
function normalize(raw: unknown): MyType[] {
  return (raw as { items: MyRawType[] }).items.map((r) => ({
    open: Number(r.openPrice),  // boundary cast OK
    // ...
  }));
}
```

### 규칙 2: 타입은 wire 그대로 (특히 string number)

```typescript
// ❌ number로 추측
const SAMPLE = [{ lastPrice: 75000 }];

// ✅ string (실제 API)
const SAMPLE = [{ lastPrice: "75000" }];
```

**금융 API는 거의 다 string number** (정밀도 손실 방지).

### 규칙 3: Envelope 구조는 wire 그대로

```typescript
// ❌ 단일 envelope만 가정
const SAMPLE = [{ items: [...] }];

// ✅ nested envelope (Toss 패턴)
const SAMPLE = { data: { result: { items: [...] } } };

// 또는 양립 (둘 다 지원)
const SAMPLE = [
  [{ items: [...] }],  // 직접
  { data: { result: { items: [...] } } },  // nested
];
```

### 규칙 4: NaN 가드 (`as Type` cast는 거짓말)

```typescript
// ❌ cast만 — undefined가 흘러감
const items = raw as Candle[];
const min = Math.min(...items.map((c) => c.close));  // NaN 조용히

// ✅ Number.isFinite 가드
function toNumber(v: unknown): number {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  if (typeof v === "string") {
    const n = Number(v);
    return Number.isFinite(n) ? n : NaN;
  }
  return NaN;
}
const open = toNumber(r.openPrice);
if (!Number.isFinite(open)) return null;  // invalid 필터링
```

### 규칙 5: 정렬 가정 명시

```typescript
// API 응답이 newest-first (시계열 일반적) → 차트는 oldest-first 가정
// → 명시적 sort로 의도 표현
const candles = normalize(raw);
candles.sort((a, b) => a.timestamp - b.timestamp);  // oldest-first
```

### 규칙 6: test pass immediately = false GREEN 위험

```bash
# 첫 실행에서 통과하면 mock이 추측이라는 신호
npm test  # → ✓ 통과

# 추가 조치:
# - 실제 API 응답으로 mock 보강 (새 테스트 케이스로)
# - 기존 테스트는 type contract 문서로 유지, 새 테스트는 wire shape 검증
```

---

## 4. 체크리스트 (모든 API 통합 시)

```markdown
### Endpoint 점검
- [ ] curl로 실제 응답 직접 확인 (가정 X)
- [ ] 응답 구조 vs mock 구조 비교
  - [ ] 필드명 (openPrice vs open)
  - [ ] 타입 (string vs number)
  - [ ] envelope (nested vs direct)
  - [ ] 정렬 (newest-first vs oldest-first)
  - [ ] null/empty 처리
- [ ] 차이점 있으면 mock 수정 → RED → GREEN
- [ ] 시각/동작 검증 (DOM check, console error 0)

### Boundary 정규화 함수
- [ ] `toNumber()` / `toEpochMs()` 같은 헬퍼 사용
- [ ] `Number.isFinite()` NaN 가드
- [ ] invalid 항목 필터링 (null 반환 후 호출부에서 skip)
- [ ] envelope unwrap 순서 명시 (result → items? items → result?)

### Test 작성
- [ ] Mock이 wire shape 그대로 (string number, 실제 필드명)
- [ ] Type contract test (이상적 형태) + wire shape test (실제 형태) 분리
- [ ] 시각 검증 (Playwright DOM: SVG/element 개수 + 텍스트)
```

---

## 5. 흔한 False GREEN 사례 (참고)

| 프로젝트 | mock 형태 | 실제 API | 결과 |
|---|---|---|---|
| toss-trader v1.4 candles | `{ open: 285000, timestamp: 1700... }` | `{ openPrice: "285000", timestamp: "2026-..." }` | 차트 "데이터 없음" |
| 일반적인 holdings 응답 | `[{ symbol, quantity }]` | `{ result: { items: [{ symbol, quantity }] } }` | `holdings.reduce is not a function` (v1.0.1 실측) |
| 일반적인 prices 응답 | `[{ lastPrice: 75000 }]` | `{ result: [{ lastPrice: "75000" }] }` | `NaN` (계산식) |

---

## 6. 일반화: API 통합 TDD 원칙 (5가지)

1. **먼저 curl, 그 다음 mock** — 가정이 아닌 관측
2. **Mock = wire shape 그대로** — 정리는 정규화 함수에서
3. **Boundary에 가드** — `Number.isFinite()`, `Array.isArray()`, type narrowing
4. **정렬/순서 가정 명시** — sort 또는 reverse
5. **Test pass immediately 의심** — 실제 wire shape 테스트 추가

---

## 7. 적용 사례 (다른 프로젝트에 적용 시)

```bash
# 1) 새 프로젝트 / 새 endpoint 추가 시
curl -s "<API_URL>" | python3 -m json.tool > /tmp/response.json
cat /tmp/response.json

# 2) 응답 구조 파악 후 mock 작성
# 3) 테스트 작성 → RED → GREEN
# 4) 시각/동작 검증
```

**이 reference는 toss-trader를 떠나 모든 API 통합 프로젝트의 체크리스트로 사용 가능.**