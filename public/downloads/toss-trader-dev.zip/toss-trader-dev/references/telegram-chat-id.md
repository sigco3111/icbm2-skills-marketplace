# Telegram CHAT_ID 확인 가이드

## 자주 하는 실수 (v1.0.1 3번째 fix)

`TELEGRAM_BOT_TOKEN=123456:ABC-...`에서 콜론 앞 `123456` = **봇 ID**. 이걸 `TELEGRAM_CHAT_ID`에 그대로 넣으면 **403 Forbidden** ("the bot can't send messages to the bot").

**정확한 의미 분리**:
- `TELEGRAM_BOT_TOKEN`: 봇 자체의 인증 토큰 (`{bot_id}:{hash}` 형식)
- `TELEGRAM_CHAT_ID`: 메시지 **받을 사람/그룹**의 ID. 봇 ID와 다름.

## 본인 user_id 확인 (가장 빠름)

1. Telegram 앱 열기
2. 검색창에 **`@userinfobot`** 입력 → 채팅방 열기
3. **`/start`** 입력
4. 봇이 즉시 응답:
   ```
   Id: 123456789
   First: <이름>
   Lang: ko-KR
   ```
5. **Id 값 = `TELEGRAM_CHAT_ID`**

## 그룹 chat_id

- 일반 그룹: 음수 (예: `-1001234567890`)
- 채널: `@채널username` 또는 음수 ID
- 그룹에 봇 먼저 초대 후 `/getUpdates`로 확인:
  ```bash
  curl -s "https://api.telegram.org/bot<TOKEN>/getUpdates" | python3 -m json.tool
  ```
  → `chat.id` 값

## API 호출 예시

```bash
# 본인 user_id (private)
curl -X POST "https://api.telegram.org/bot<TOKEN>/sendMessage" \
  -d "chat_id=123456789" \
  -d "text=안녕"

# 그룹 (음수)
curl -X POST "https://api.telegram.org/bot<TOKEN>/sendMessage" \
  -d "chat_id=-1001234567890" \
  -d "text=그룹 알림"
```

## toss-trader default fallback

`TELEGRAM_BOT_TOKEN` 또는 `TELEGRAM_CHAT_ID` 둘 중 하나라도 비어있으면:
- `isDevFallback()` = true
- `sendOrderConfirm()` → `ok: true, devFallback: true, message: "TOSS_TELEGRAM_BOT_TOKEN 또는 TELEGRAM_CHAT_ID 미설정. dev fallback: 자동 confirm. 실사용 시 둘 다 설정 필요."`
- → UI에 "dev fallback" 뱃지 + 자동 confirm (3초 후)

## .env 템플릿 (v1.4+)

```bash
# BotFather @BotFather → /newbot → 토큰 받기
TELEGRAM_BOT_TOKEN=123456:AAFaM76sXmyqrP_kweQc9-xcZVOpp-SA-4I
# 본인 chat_id (@userinfobot으로 확인)
TELEGRAM_CHAT_ID=123456789
# confirm TTL (기본 5분)
TELEGRAM_CONFIRM_TTL_SEC=300
# confirm 모드 (v1.1.4)
TELEGRAM_CONFIRM_MODE=telegram
```

## 보안

- `TELEGRAM_BOT_TOKEN` = 메신저 평문 전송 절대 금지
- `~/.hermes/secrets/telegram_bot_token.txt` (chmod 600) 권장
- 회전 요청 시 토큰값 메시지 노출 금지
- terminal 명령만 제시 + "저장 완료" 신호 패턴
