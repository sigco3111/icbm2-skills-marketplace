# Next.js 16 + React 19 정형화 패턴 (toss-trader v1.x)

toss-trader v1.x (8단계 + v1.1.x + v1.2 + v1.3)에서 정형화된 Next.js 16 / React 19 / TypeScript 5 / Tailwind CSS 4 패턴.

## App Router

### Dynamic params (catch-all)
```typescript
// app/api/toss/[...path]/route.ts
interface RouteContext {
  params: Promise<{ path: string[] }>;  // ← Promise! (Next 15+ breaking)
}

export async function GET(req: NextRequest, ctx: RouteContext) {
  const { path } = await ctx.params;  // ← await 필수
  const tossPath = "/" + path.join("/");
  // ...
}
```

### Client vs Server component
```typescript
// app/page.tsx (Client) - "use client" 필수 (useState 사용)
"use client";
import { useState } from "react";
export default function Home() {
  const [tab, setTab] = useState<"dashboard" | "history">("dashboard");
  // ...
}

// app/api/*/route.ts (Server) - NextRequest/NextResponse
import { NextRequest, NextResponse } from "next/server";
export async function GET(req: NextRequest): Promise<NextResponse> {
  return NextResponse.json({ ... });
}
```

## useState for tabs (접근성)

```typescript
type Tab = "dashboard" | "history";

export default function Home() {
  const [tab, setTab] = useState<Tab>("dashboard");

  return (
    <>
      {/* 탭 네비게이션 */}
      <nav role="tablist" aria-label="대시보드 탭">
        <button
          type="button"
          role="tab"
          aria-selected={tab === "dashboard"}
          onClick={() => setTab("dashboard")}
          className={tab === "dashboard" ? "..." : "..."}
        >
          📊 Dashboard
        </button>
      </nav>

      {/* 탭 컨텐츠 */}
      {tab === "dashboard" && <DashboardContent />}
      {tab === "history" && <HistoryContent />}
    </>
  );
}
```

## setState in useEffect 우회 (5개 컴포넌트 정형화)

`react-hooks/set-state-in-effect` lint는 useEffect 안 직접 setState 호출을 금지. **해결**: `setTimeout(() => setX, 0)` 마이크로태스크 분리 + cleanup.

```typescript
// Portfolio.tsx (10초 polling)
useEffect(() => {
  const start = (): void => {
    void fetchData();
  };
  const t = setTimeout(start, 0);
  const interval = setInterval(() => {
    void fetchData();
  }, POLL_INTERVAL_MS);
  return () => {
    clearTimeout(t);
    clearInterval(interval);
  };
}, [fetchData]);

// ConfirmModeToggle.tsx (SSR hydration mismatch 회피)
useEffect(() => {
  const stored = loadConfirmMode();
  if (stored !== value) {
    onChange(stored);
  }
  // setTimeout 0 마이크로태스크 분리 (react-hooks/set-state-in-effect 우회)
  const t = setTimeout(() => setMounted(true), 0);
  return () => clearTimeout(t);
  // eslint-disable-next-line react-hooks/exhaustive-deps
}, []);
```

## Date.now() in event handler

`react-hooks/purity` lint는 render 중 `Date.now()`/`Math.random()` 금지. **이벤트 핸들러 안** 호출은 OK. 명시적 disable-line:

```typescript
const startPolling = async (orderId: string): Promise<void> => {
  setPolling(true);
  // eslint-disable-next-line react-hooks/purity -- 이벤트 핸들러 안, render 아님
  const startTime = Date.now();
  // ...
};
```

## TypeScript strict 패턴

```typescript
// Array.isArray + nullish coalescing (토스 API 응답 구조)
const rawData = (body as ApiEnvelope<unknown>).data;
const items = Array.isArray(rawData)
  ? (rawData as HoldingItem[])
  : (rawData as { result?: { items?: HoldingItem[] } })?.result?.items ?? [];

// Number.isFinite (NaN/Infinity 차단)
const n = Number(p.lastPrice);
if (Number.isFinite(n)) priceMap[p.symbol] = n;

// Optional chaining + nullish coalescing
const value = process.env.SOMETHING ?? "default";
const result = obj?.prop?.nested ?? fallback;
```

## Tailwind CSS 4

```typescript
// 다크모드 자동 (prefers-color-scheme)
<div className="bg-white dark:bg-zinc-950 text-zinc-900 dark:text-zinc-50">

// hover/active
<button className="bg-red-500 hover:bg-red-700 text-white">

// 3-컬럼 grid
<div className="grid lg:grid-cols-3 gap-4">

// sticky header
<thead className="sticky top-0 bg-white dark:bg-zinc-950">
```

## ESLint 9 + Next 16

```json
// .eslintrc / eslint.config.mjs
{
  "extends": ["next/core-web-vitals", "next/typescript"],
  "rules": {
    "@typescript-eslint/no-unused-vars": "warn"
  }
}
```

**자주 뜨는 에러**:
- `react-hooks/set-state-in-effect` → `setTimeout(() => setX, 0)` 우회
- `react-hooks/purity` → `eslint-disable-next-line` (이벤트 핸들러 안)
- `react/no-unescaped-entities` → `&quot;` escape

## TypeScript 5 strict + ?. / ??

```typescript
// 3-stage: optional + nullish + type narrow
const items = body?.data?.result?.items ?? [];
if (items.length > 0 && Array.isArray(items)) {
  for (const item of items) {
    if (item && typeof item.symbol === "string") { /* */ }
  }
}
```

## Playwright e2e (v1.2+)

```typescript
// strict mode .or() 함정 회피
await expect(page.getByRole("heading", { name: /History \(이력\)/ })).toBeVisible();

// 모달 안 element 격리
const modal = page.getByRole("heading", { name: "주문 confirm" }).locator("..");
await expect(modal.getByText(/005930/)).toBeVisible();

// localStorage 사전 설정
await page.addInitScript(() => {
  window.localStorage.setItem("toss-trader:confirm-mode", "auto");
});
```

## 빌드 / 검증

```bash
npm run build       # 0 errors
npm run lint        # 0 errors, 0 warnings
npm test            # vitest (default node)
npm run test:e2e    # playwright (chromium + webkit)
```

## 참고

- Next.js App Router: https://nextjs.org/docs/app
- React 19: https://react.dev/blog/2024/12/05/react-19
- Tailwind CSS 4: https://tailwindcss.com/docs
- toss-trader v1.2.1: README 비개발자 가이드 + Playwright e2e 패턴
