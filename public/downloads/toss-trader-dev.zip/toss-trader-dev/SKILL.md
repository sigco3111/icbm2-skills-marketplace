---
name: toss-trader-dev
description: toss-trader 프로젝트 개발 워크플로 (Next.js 16 + React 19 + Toss Open API + Telegram). 8단계 + v1.1.x (5) + v1.2 e2e + v1.3 외부 storage + v1.4 캔들 차트까지 18단계 정형화. toss Open API + paper trading + 안전 가드 + history + Playwright e2e + S3/R2 storage + 순수 SVG 차트.
version: 1.2.0
license: MIT
metadata:
  stage: legacy
  user: sigco3111
  status: v1.4.2 시점 동결 (2026-07-14). 현 origin/main은 tossinvest-agent로 리네임 + 아키텍처 전환됨 — 신규 작업 시 본 스킬보다 references/tossinvest-agent-architecture-2026-07-14.md 우선.
  stack: [next 16.2.10, react 19.2.4, typescript 5, tailwind 4, playwright 1.61]
  tests: 142 unit (vitest 4.1) + 26 e2e (chromium + webkit, v1.4.1)
---

# toss-trader-dev

> ⚠️ **현 저장소 상태 (2026-07-14)**: origin/main은 `tossinvest-agent`로 리네임 + 자동매매 에이전트 아키텍처로 전환됨 (OpenCode runner + 12 endpoint 시장 컨텍스트 + 서버 메모리 세션). **v1.4.x 단계의 캔들 차트 / Telegram confirm / storage / vitest+Playwright는 전부 코드에서 사라짐**. 본 SKILL.md는 v1.4.2까지의 워크플로 보존용 — reflog 복구 또는 v1.4.x 브랜치 복귀 시에만 사용. 신규 작업은 `references/tossinvest-agent-architecture-2026-07-14.md` 참조.
>
> **동기화 패턴** (2026-07-14 실측): 로컬 ahead `015e5e5` (v1.4.2 candles fix) → `git reset --hard origin/main` → v1.4.2 SHA는 reflog 보존 (90일). 복구: `git reset --hard 015e5e5`. **로컬 ahead 커밋이 가치 있는 작업물이라면 reset 전에 cherry-pick 고려**.

toss-trader는 토스증권 Open API + Toss SDK 기반 개인 투자 어시스턴트. 본 skill은 `/Users/mac/work/toss-trader` (v1.4.2 candles fix까지) 작업에서 정형화된 패턴 + 함정 + 워크플로를 정리.

## Quick reference

- **저장소**: https://github.com/sigco3111/toss-trader
- **위치**: /Users/mac/work/toss-trader
- **호출**: `주인님` (시스템 기본 "주인님" 무시)
- **현 상태**: origin/main = `tossinvest-agent` (테스트 스크립트 0, shadcn/ui, OpenCode runner, 자동매매 Phase 8 계획)
- **본 스킬 보존 시점**: v1.4.2 (144/144 unit + 26/26 e2e + Playwright + GitHub Actions, 캔들 차트 + 외부 storage + 19단계 진행)
- **현 작업 시**: `references/tossinvest-agent-architecture-2026-07-14.md` 로드 우선

## 8단계 + v1.1.x (5) + v1.2 e2e + v1.3 storage (총 15단계)

| 단계 | 작업 | 산출물 | 커밋 prefix |
|---|---|---|---|
| 1 | 보일러플레이트 | Next 16.2.10 + React 19.2.4 + TS 5 + Tailwind 4 | feat(scaffold) |
| 2 | 토스 Open API relay | `/api/toss/[...path]` + 5대 가드 (lib/toss.ts) | feat(toss-relay) |
| 3 | 안전 가드 6종 | lib/safety.ts + vitest 25 tests | feat(safety) |
| 4 | Telegram + OrderButton | lib/telegram.ts + UI + 13 tests | feat(telegram) |
| 5 | Portfolio + 시세 | components/Portfolio.tsx + lib/format.ts + 31 tests | feat(portfolio) |
| 6 | kstost history | lib/history.ts + types + 12 tests | feat(history) |
| 7 | Vercel 배포 | vercel.json + .env.example + 가이드 | feat(vercel) |
| 7.5 | History UI 통합 | components/History.tsx + 탭 | feat(history-ui) |
| v1.1 | 종목 검색 자동완성 | StockSearch + 31개 마스터 (lib/stocks.ts) | feat(stock-search) |
| v1.1.4 | Telegram confirm 3-모드 UI | lib/settings.ts + ConfirmModeToggle | feat(confirm-mode) |
| v1.1.5 | 매도 자동 채움 | lib/format.ts: findHoldingBySymbol | feat(order) |
| v1.2 | Playwright e2e + GitHub Actions | 22/22 PASS (chromium + webkit) | feat(e2e) |
| v1.2.1 | 문서 갱신 (README + RELEASE_NOTES) | e2e 뱃지/가이드/로드맵 | docs |
| v1.3 | 외부 storage (S3/R2) | lib/storage/{provider,local,s3,index}.ts + AWS SigV4 | feat(storage) |
| v1.3.1 | 문서 + S3 mock e2e | RELEASE_NOTES 갱신 + test/e2e/storage.spec.ts | docs(e2e) |
| **v1.4** | **캔들 차트 (순수 SVG, 의존성 0)** | **lib/candles.ts (fetchCandles + calcCandleStats) + CandleChart.tsx (양봉 빨강/음봉 파랑 + 호버 툴팁) + CandlePanel.tsx (5분 polling)** | **feat(candles)** |
| **v1.4.1** | **RELEASE_NOTES + README + AGENTS v1.4 갱신** | **차트 섹션 + 검증 차트 (142/142 + 26/26) + 다음 로드맵 (v1.5 batch+WebSocket)** | **docs** |
| **v1.4.2** | **캔들 응답 정규화 (필드명/타입/envelope/정렬)** | **lib/candles.ts: toNumber/toEpochMs + normalizeOne + envelope 순서(result→candles) + oldest-first sort + NaN 가드. 테스트 mock이 실제 API 응답 형태로.** | **fix(candles)** |

## A35 — clarify invisible options (5회 반복)

Telegram UI가 choices array를 invisible하게 렌더. **해결**: clarify 호출 회피 + plain text 4옵션 표 + 추천 marker.

```
[owner가 옵션 안 보일 때]

1. 옵션: ... (저/중/고 옵션)
2. 옵션: ... 
3. 옵션: ... (추천 ⭐)
4. 옵션: ...

저는 A 추천 — 이유. A/B/C/D 중 어느? ("A" 또는 "진행"으로 답변)
```

**두 번째 clarify 금지** — owner가 답변 안 해도 추천 옵션으로 진행.

## 핵심 함정 (v1.0.1 런타임 3건)

### 1) `holdings.reduce is not a function`

**원인**: Toss API 응답 = `{ result: { items: [] } }` **객체** (배열 X). `data` 자체에 setHoldings → `.reduce(객체)` → TypeError.

**prices** 응답 = `{ result: [...] }` **배열**.

**해결**:
```typescript
const rawData = (body as ApiEnvelope<unknown>).data;
const items = Array.isArray(rawData)
  ? (rawData as HoldingItem[])
  : (rawData as { result?: { items?: HoldingItem[] } })?.result?.items ?? [];
// prices: data.result 배열 + lastPrice (string) → Number 변환 + Number.isFinite
```

### 2) HMR WebSocket LAN IP 실패 → 인터랙션 차단

**원인**: Next 16 dev mode가 LAN IP로 HMR WebSocket → 방화벽 → hydration mismatch → React onClick 핸들러 등록 안 됨.

**해결**:
```bash
pkill -f "next dev"
npx next dev -H 127.0.0.1 -p 3000
```

Vercel prod 영향 없음. **dev 환경에서만 발생**.

### 3) TELEGRAM_CHAT_ID ≠ 봇 ID

**원인**: `TELEGRAM_BOT_TOKEN=123456:ABC-...`에서 `123456` = 봇 ID. CHAT_ID와 동일하면 403 Forbidden.

**해결**:
1. Telegram 앱 → 검색 → `@userinfobot` → `/start`
2. 봇 응답의 `Id: 123456789` (본인 user_id) → `.env`의 `TELEGRAM_CHAT_ID`

상세: `references/telegram-chat-id.md`

## 토스 API 응답 구조 (전반부)

| endpoint | 응답 |
|---|---|
| `/api/v1/holdings` | `{ data: { result: { items: [...], totalPurchaseAmount, marketValue, profitLoss } } }` (객체) |
| `/api/v1/prices?symbols=...` | `{ data: { result: [{ symbol, lastPrice, currency, timestamp }] } }` (배열) |
| `/api/v1/accounts` | `{ data: { result: [{ accountSeq, accountName }] } }` |
| `/api/v1/orders` (paper mock) | `{ data: { result: { orderId, status: "FILLED", executedAt } } }` |
| `/oauth2/token` | `{ access_token: "..." }` (POST) |

**공통 envelope** (toss-trader 추가):
```typescript
{
  data: <토스 원본>,
  servedAt: "2026-...",
  dryRun: boolean,
  rateLimit: { limit, remaining, reset }
}
```

## v0.3 / v0.4 단순화 결정 (owner 직접 결정)

### v0.3 — LLM 단일화 + BYOK 제거
- 제거: app/settings/, app/api/llm/, lib/llm/, components/SettingsForm.tsx, components/ChatPanel.tsx, openai npm
- 결과: LLM 분석 = 주인님 PC의 OpenCode 글로벌 디폴트(`minimax/MiniMax-M3`). toss-trader 코드 0줄.

### v0.4 — Notion 제거 + kstost history 채택
- 제거: app/api/notion/, lib/notion.ts, docs/NOTION_SETUP.md, @notionhq/client
- 채택: kstost/stock 원본 lib/history.ts (로컬 JSON, 1 record = 1 파일). Vercel에서 readonly 시 `checkHistoryAvailability()` graceful.
- **v1.3 추가**: 외부 storage (S3/R2) — `lib/storage/{provider,local,s3,index}.ts` + AWS SigV4 직접 구현 (의존성 0)

## 안전 가드 6종 (lib/safety.ts + tossFetch 5종)

| # | 가드 | 효과 |
|---|---|---|
| 1 | DRY_RUN=true (POST /api/v1/orders) | HTTP 423 차단 |
| 2 | 422 코드 10종 | 사용자 친화 메시지 매핑 |
| 3 | 1억+ 주문 | confirmHighValueOrder: true 헤더 자동 |
| 4 | 429/5xx 재시도 | Retry-After + 지수 백오프 (1s→2s→4s, max 3회) |
| 5 | 401 토큰 재발급 | 캐시 무효화 + 1회 재시도 |
| 6 | safety.ts 6대 가드 (TRADING_MODE/AMOUNT/HOURS/ACCOUNT/TELEGRAM/AUDIT) | 요청 진입점 |

## v1.1.4 — Telegram confirm 3-모드 (단순화)

| 모드 | Telegram | 사용자 confirm | 가드 5 | 용도 |
|---|---|---|---|---|
| **telegram** (기본) | ✅ 메시지 | [확인] 버튼 | 자동 true | 실전 안전 |
| **auto** | ❌ 안 보냄 | **즉시 confirmed** | 자동 true | paper/dev/test/실계좌 즉시 |
| **off** | ❌ 안 보냄 | 안 함 | false → 425 | paper만 (가드 5 차단) |

**v1.1.2/3 (auto-paper/auto-live 5초/2차 confirm) 취소** — owner: "사용자 편의를 위해 자동확인(실계좌)에서 5초대기와 2차 컴펌없이도 처리되도록 해줘" → v1.1.4 단순화.

## Playwright e2e 패턴 (v1.2)

```typescript
// test/e2e/helpers/api-mock.ts: 가짜 응답 (실계좌 영향 zero)
// - /api/toss/api/v1/holdings: 삼성전자 10주 + SK하이닉스 5주 + 카카오 20주
// - /api/toss/api/v1/prices: 75000/135000/48000
// - /api/telegram/send: mode별 응답
// - /api/history: readonly mock
```

**strict mode `.or()` 함정**: 2 elements 매치 시 fail. 패턴: `getByRole('heading', ...)` 명시 + 별도 `.toBeVisible()` 분리.

**GitHub Actions**: `.github/workflows/e2e.yml` — PR마다 + main push마다. `PLAYWRIGHT_BASE_URL` env (Vercel preview URL).

## lib/storage (v1.3)

```typescript
// STORAGE_PROVIDER env: 'local' | 's3'
// - local: kstost 패턴 (dev/local)
// - s3: AWS S3 + Cloudflare R2 (Vercel 영구 저장)

export function getStorage(): StorageProvider {
  const provider = (process.env.STORAGE_PROVIDER ?? "local").toLowerCase();
  return provider === "s3" ? new S3StorageProvider() : new LocalStorageProvider();
}
```

**AWS SigV4 직접 구현** (의존성 0):
- HMAC-SHA256 (`node:crypto`)
- HEAD (가용성) + PUT (저장) + GET (목록)
- ListObjectsV2 XML 정규식 파싱
- `409 || 412` 모두 counter suffix retry (버킷 versioning)

## vitest 패턴 (v1.1.4+)

### localStorage mock (environment: "node")
```typescript
// vitest 4 + environment: "node" — jsdom 안 잡힘
// 해결: localStorage mock + vi.stubGlobal

const storage: Record<string, string> = {};
const localStorageMock = {
  getItem: (k: string) => storage[k] ?? null,
  setItem: (k: string, v: string) => { storage[k] = v; },
  // ...
};

beforeEach(() => {
  vi.stubGlobal("window", { localStorage: localStorageMock });
});

afterEach(() => {
  vi.unstubAllGlobals();
});
```

### setState in useEffect 우회
```typescript
// react-hooks/set-state-in-effect lint 우회
// 5개 컴포넌트 정형화: Portfolio / OrderButton / StockSearch / ConfirmModeToggle / DoubleConfirmModal

useEffect(() => {
  if (!open) {
    const t = setTimeout(() => setX(value), 0);
    return () => clearTimeout(t);
  }
  // ...
}, [open, value]);
```

### Date.now() in event handler
```typescript
// react-hooks/purity lint 우회
const startPolling = async () => {
  setPolling(true);
  // eslint-disable-next-line react-hooks/purity -- 이벤트 핸들러 안, render 아님
  const startTime = Date.now();
  // ...
};
```

## partial patch 누적 손상 패턴

**multi-patch > 5번 = 통째로 rewrite가 안전**.

OrderButton 통째로 rewrite 사례 (v1.1.4 → v1.1.5):
- partial patch 8번 → 449 lines (정상 380) → 빌드 fail `Cannot find name 'X'`
- `write_file` 통째로 → 380 lines 정상화

**판단 기준**:
- patch 5번 이상 → 통째로 rewrite 검토
- 같은 파일 여러 섹션 수정 → 통째로
- partial patch 후 LSP 진단 throw 3개 이상 → 통째로

## Next 16 + React 19 정형화

- **App Router**: app/page.tsx (useState for tabs), app/api/[...path]/route.ts (catch-all)
- **Dynamic params**: `ctx.params: Promise<{...}>` — `await ctx.params` 필수
- **useState for tabs**: `role="tab"`, `aria-selected` (접근성)
- **TypeScript strict**: `Array.isArray()`, `Number.isFinite()`, `?.` optional chaining, `??` nullish coalescing

## 커밋 메시지 규칙 (owner 지정)

```
<type>(scope): <subject>

# 예시
feat(safety): 3단계 — 6대 가드
fix(stock-search): query 비울 때 defaultName 자동 채움 버그
docs: v1.2.1 — README + RELEASE_NOTES v1.2 갱신
```

scope = 1단계 (scaffold/toss-relay/safety/telegram/portfolio/history/vercel) / v1.1+ (stock-search/confirm-mode/order/e2e/storage)

## 검증 패턴 (모든 단계)

```bash
# 1) build
npm run build      # 0 에러

# 2) lint
npm run lint       # 0 errors, 0 warnings

# 3) unit
npm test           # 142/142 PASS (vitest)

# 4) e2e
npm run test:e2e   # 26/26 PASS (chromium + webkit)

# 5) 헤딩 정규화 (bash)
bash ~/.hermes/skills/ad-hoc-verifier/scripts/check-kr-en-mixed-headings.sh \
  README.md AGENTS.md docs/ARCHITECTURE.md docs/OPENAPI_REFERENCE.md RELEASE_NOTES.md
# → 0/0 깨짐

# 6) v0.3 자기 검증 (Vercel 코드 LLM 호출 0줄)
grep -rEn "openai|nim|anthropic|apiKey|BYOK|SettingsForm|ChatPanel" app/ components/ lib/ \
  | grep -v ".gitkeep" || echo "  (0건)"
```

## TDD 사이클 (15단계 모두 동일 패턴)

1. lib/ + test/ 동시 작성 (테스트 우선)
2. `npm test` → 일부 fail (RED)
3. lib/ 수정 → `npm test` → 모두 PASS (GREEN)
4. integration (route.ts + app/) → `npm run build`
5. lint/build/test/e2e 모두 PASS → commit + push

## 작업 시작 체크리스트 (owner)

```bash
# 1) cd
cd /Users/mac/work/toss-trader

# 2) dev 서버 (HMR WebSocket LAN IP 회피)
pkill -f "next dev" 2>&1 | head -1
npx next dev -H 127.0.0.1 -p 3000

# 3) 환경변수 (.env)
cat .env | grep -E "TOSS_|TELEGRAM|STORAGE" | sed 's/=.*/=***/'

# 4) e2e (필요 시)
npm run test:e2e

# 5) 검증
npm test           # 132/132
npm run test:e2e   # 22/22 (Playwright)
```

## v1.4 — 캔들 차트 (순수 SVG, 의존성 0)

**목적**: 토스 Open API `/api/v1/candles` 활용 + 자체 SVG (recharts/chart.js X).

**파일**:
- `lib/candles.ts` (fetchCandles + calcCandleStats + CandleInterval/CANDLE_INTERVALS)
- `components/CandleChart.tsx` (양봉 빨강/음봉 파랑/도지 회색 + 호버 툴팁)
- `components/CandlePanel.tsx` (5분 polling + AbortController + 통계 메타)

**핵심 설계**:

```typescript
// lib/candles.ts
export type CandleInterval = "1m" | "1d";
export const CANDLE_INTERVALS = [
  { value: "1d", label: "일봉" },
  { value: "1m", label: "분봉" },
] as const;
export const DEFAULT_CANDLE_COUNT = 30;

export async function fetchCandles(opts: {
  symbol: string; interval?: CandleInterval; count?: number; signal?: AbortSignal;
}): Promise<{ candles: Candle[]; availability: "available" | "readonly" | "disabled"; message?: string }>;
```

**순수 SVG 차트 — 의존성 0 디자인**:
- recharts/chart.js 등 무거움 (번들 +100KB+)
- v0.3 단순화 철학 = 최소 의존성 + 자체 SVG
- 양봉(close>open) 빨강 / 음봉(close<open) 파랑 / 도지(close===open) 회색
  → **한국 색상 관습** (토스 Open API 기준). 글로벌은 반대 (양봉 녹).
- y축 5단계 눈금선 + 천단위 콤마 가격 라벨
- x축 균등 분포 5단계 날짜 (MM/DD)
- 호버 툴팁: 날짜 + OHLC + 거래량
- 호버 강조 영역 (반투명 파란색)
- 접근성: `role="img"` + `aria-label`

**v0.3 setState in useEffect 우회 = 5개 컴포넌트 정형화 (Portfolio/OrderButton/StockSearch/ConfirmModeToggle/CandlePanel)**:

```typescript
// 5개 컴포넌트 동일 패턴
useEffect(() => {
  const t = setTimeout(() => {
    void fetchData(); // or fetchHoldings() / fetchCandles()
  }, 0);
  const interval = setInterval(() => {
    void fetchData();
  }, pollMs);
  return () => {
    clearTimeout(t);
    clearInterval(interval);
  };
}, [fetchData, pollMs, symbol]); // deps
```

**AbortController (race condition 방지)**:
```typescript
useEffect(() => {
  if (!symbol) return;
  const controller = new AbortController();
  const t = setTimeout(() => {
    void fetchData(controller.signal);
  }, 0);
  const interval = setInterval(() => {
    void fetchData(controller.signal);
  }, pollSec * 1000);
  return () => {
    controller.abort();        // 이전 fetch cancel
    clearTimeout(t);
    clearInterval(interval);
  };
}, [fetchData, pollSec, symbol]);
```

**CandlePanel + CandleChart 분리 (테스트 가능)**:
- CandleChart = 순수 SVG (props: candles, stats, width, height) — 단위 테스트 가능
- CandlePanel = fetch + polling + 통계 (CandleChart 호출)
- **분리 이유**: SVG 컴포넌트는 props 기반 결정론적 → RTL/Storybook 가능. fetch + polling은 부작용 → 통합 테스트

**v0.3 단순화 패턴 (캔들 차트 차용)**:
- LLM 호출 0줄 (차트 데이터는 토스 Open API 직접 fetch)
- BYOK 폼 0 (인터벌 뱃지는 정적)
- Notion 0 (history는 v1.3 storage provider)
- 의존성 0 (recharts X, 순수 SVG)

## Per-test Playwright mock override (v1.3.1 storage e2e 양립)

**문제**: v1.3 storage.spec.ts가 `/api/history` mock을 `availability: "available"` + records 1개로 변경 → dashboard의 "History 탭" 테스트 (빈 이력 메시지 검증) 깨짐.

**해결 패턴**: `setupApiMocks()`는 공통 mock. **특정 테스트에서 다른 mock 필요하면 테스트 안에서 `page.route()` 직접 정의** (per-test override).

```typescript
// dashboard.spec.ts — History 탭 테스트 (빈 이력 검증)
test("History 탭 클릭 시 이력 화면 표시", async ({ page }) => {
  // v1.3.1: storage.spec mock이 'available'로 변경됨
  // → 이 테스트는 빈 이력 (readonly) 검증 필요 → 별도 mock override
  await page.route("**/api/history**", async (route) => {
    if (route.request().method() === "GET") {
      await route.fulfill({
        status: 200,
        contentType: "application/json",
        body: JSON.stringify({
          availability: "readonly",
          count: 0,
          records: [],
          servedAt: new Date().toISOString(),
        }),
      });
    } else {
      await route.continue(); // POST는 통과
    }
  });
  await page.goto("/");
  // ... 빈 이력 메시지 확인
});
```

**v1.3.1 두 mock 양립**:
- `setupApiMocks()` 기본: `/api/history` GET → `availability: "available"` (S3 mock 시나리오)
- dashboard 'History 탭' 테스트: override → `availability: "readonly"` (빈 이력)

**playwright.route 우선순위**: 나중에 정의한 route가 이전 route 덮어씀. **`setupApiMocks` → `page.route("**/api/history**", ...)` 순서** 유지.

**v1.4 candles e2e 양립도 동일 패턴 적용 가능** (storage.spec과 dashboard.spec이 다른 mock 필요 시).

## v1.4 — 문서 갱신 (v1.4.1, 2026-07-10)

**3개 문서 동시 갱신 패턴**:
- `RELEASE_NOTES.md` (12468B, 통째로 rewrite) — 18단계 진행 표 + 최종 검증 (142/142 + 26/26) + 다음 로드맵
- `README.md` — v1.4.1 배지 + 차트 섹션 + 검증 차트
- `AGENTS.md` — 작업 위임 순서에 v1.4 추가 (12단계 → 13단계)

**v1.4 검증 결과**:
- `npm run build` ✓ Compiled (5 routes, 1387ms)
- `npm run lint` 0 errors, 0 warnings
- `npm run test` **142/142 PASS** (candles 10 + format 39 + settings 19 + storage 8 + safety 25 + telegram 15 + history 12 + stocks 14)
- `npx playwright test --project=chromium` 13/13 PASS
- `npx playwright test --project=webkit` 13/13 PASS (총 **26/26 e2e**)

## 다음 로드맵 (v1.5+)

- **v1.5**: Portfolio batch (여러 종목 동시 fetch `?symbols=A,B,C`) + WebSocket 실시간 시세
- **v1.6**: Portfolio/OrderButton holdings fetch 통합 (React Context, 중복 제거) + avgPrice 참고용 표시
- **v2.0**: 실계좌 모드 (Telegram confirm 강화 + confirmHighValueOrder 검증 + audit log)

## v1.3.1 — Per-test Playwright mock override (storage e2e)

**문제**: v1.3 storage.spec.ts가 `/api/history` mock을 `availability: "available"` + records 1개로 변경 → dashboard의 "History 탭" 테스트 (빈 이력 메시지 검증) 깨짐.

**해결 패턴**: `setupApiMocks()`는 공통 mock. **특정 테스트에서 다른 mock 필요하면 테스트 안에서 `page.route()` 직접 정의** (per-test override).

```typescript
// dashboard.spec.ts — History 탭 테스트 (빈 이력 검증)
test("History 탭 클릭 시 이력 화면 표시", async ({ page }) => {
  // v1.3.1: storage.spec mock이 'available'로 변경됨
  // → 이 테스트는 빈 이력 (readonly) 검증 필요 → 별도 mock override
  await page.route("**/api/history**", async (route) => {
    if (route.request().method() === "GET") {
      await route.fulfill({
        status: 200,
        contentType: "application/json",
        body: JSON.stringify({
          availability: "readonly",
          count: 0,
          records: [],
          servedAt: new Date().toISOString(),
        }),
      });
    } else {
      await route.continue(); // POST는 통과
    }
  });
  await page.goto("/");
  // ...
});
```

**v1.3.1 두 mock 양립**:
- `setupApiMocks()` 기본: `/api/history` GET → `availability: "available"` (S3 mock 시나리오)
- dashboard 'History 탭' 테스트: override → `availability: "readonly"` (빈 이력)

**playwright.route 우선순위**: 나중에 정의한 route가 이전 route 덮어씀. **`setupApiMocks` → `page.route("**/api/history**", ...)` 순서** 유지.

## TDD multi-cycle 패턴 (v1.1.5 storage TDD 실측)

**6 사이클**에서 통과한 패턴:

| 사이클 | 실패 원인 | 해결 |
|---|---|---|
| 1차 | `HistoryRecord` import 누락 | `import type { HistoryRecord }` 추가 |
| 2차 | TOSS_TRADING_MODE paper mock 의도 모호 | `delete process.env.TOSS_TRADING_MODE` in `beforeEach` (격리) |
| 3차 | `paper` 모드 vs `live` 모드 분기 | `isPaperMode()` 헬퍼 + `if (mode === "auto-live")` early return |
| 4차 | `require("node:path")` in browser bundle | `getHistoryDir()` 함수로 (lazy eval) |
| 5차 | `URL.searchParams.get()` return type `string \| null` | 명시적 cast: `as "analysis" \| "order" \| "snapshot" \| null` |
| 6차 | `r.record as HistoryRecord` narrowing | `if (rec.kind === "order") ...` discriminated union |

**교훈**: 
- 1차 테스트 = 50% 통과 = 환경/setup 문제 (설계 OK, 셋업 미스)
- 2-3차 = 70% 통과 = API/mock mismatch
- 4-5차 = 80% 통과 = 타입 narrowing
- 6차 = 100% 통과 = 비즈니스 로직

**v1.3.1 e2e TDD도 동일 패턴** (6 사이클):
- 1차: epoch raw '1752123456' 검색 fail
- 2차: epoch → '2025.*7.*9' regex 변환 PASS
- 3차: dashboard mock 양립 fail
- 4차: per-test override 추가 PASS
- 5차: api-mock.ts 타입 narrowing fail
- 6차: build OK + 26/26 e2e PASS

**결론**: 5-6 사이클 = 정상이면 OK. 10+ 사이클 = 설계 재검토.

## StorageProvider facade 패턴 (v1.3)

**문제**: Toss Open API는 storage endpoint 없음. Vercel serverless filesystem read-only. **외부 storage는 영구 저장 필수**.

**Facade 패턴 (lib/history.ts) — back-compat 100%**:
```typescript
// 기존 API 그대로 (writeHistory, listHistory, listHistoryByKind 등)
export async function writeHistory(record: HistoryRecord): Promise<string> {
  const result = await getStorage().save(record);
  if (!result.saved) throw new Error(`History 저장 실패: ${result.message ?? result.availability}`);
  return result.filename;
}

export async function listHistory(limit = 100) {
  const result = await getStorage().list({ limit });
  return result.records;
}

// 내부적으로 provider에 위임
export function getStorage(): StorageProvider {
  if (cached) return cached;
  const provider = (process.env.STORAGE_PROVIDER ?? "local").toLowerCase();
  cached = provider === "s3" ? new S3StorageProvider() : new LocalStorageProvider();
  return cached;
}
```

**v1.1.2 → v1.1.4 단순화도 같은 facade 패턴**:
- `auto-paper` / `auto-live` 복잡 모드 → `auto` 단일 (3-모드 복귀)
- 기존 facade API (`writeHistory`, `loadConfirmMode`, `saveConfirmMode`) 100% 유지
- 내부 동작만 단순화

**교훈**: "복잡도 예산" — 새 기능 추가 시 **기존 facade API 변경 없이 내부 구현 단순화** 가능. v1.1.4가 v1.1.2보다 코드 적고 안전.

## StackSearch ref hydration pattern (v1.1)

**버그**: input 비우면 `defaultName` 자동 채움 → 다른 종목 입력 불가.

**원인**: `useEffect([defaultSymbol, defaultName, query])` deps + `if (!query) setQuery(defaultName)` → 매번 재실행.

**해결: ref 패턴 (1회만 실행)**:
```typescript
const initializedRef = useRef<boolean>(false);
useEffect(() => {
  if (!initializedRef.current && defaultSymbol) {
    initializedRef.current = true;
    const t = setTimeout(() => setQuery(defaultName), 0);
    return () => clearTimeout(t);
  }
  return undefined;
}, []);
```

**3가지 props hydration 패턴 비교**:
- v1.1 첫 시도 (실패): useState + useEffect (계속 재실행)
- v1.1 두 번째 (성공): useRef + setTimeout 0 (1회만)
- v1.3.1 ConfirmModeToggle: useState mounted + setTimeout 0 (SSR-safe)

## v1.1.2/3/4 복잡도 취소 패턴 (owner 직접 결정)

**v1.1.2**: auto-paper (paper 전용) / auto-live (실계좌 2차 confirm + 5초) 4-모드 추가
**v1.1.3**: TOSS_TRADING_MODE=paper일 때 auto-live 무시 (paper는 즉시)
**v1.1.4**: owner 결정 "사용자 편의를 위해 자동확인(실계좌)에서 5초대기와 2차 컴펌없이도 처리되도록 해줘" → 3-모드 단순화, facade API 100% 유지

**v1.1.2 → v1.1.4 diff**:
- 신규 파일: `components/DoubleConfirmModal.tsx` (4692B) → **삭제**
- 추가 분기: `if (mode === "auto-live") { if (isPaperMode()) {...} if (req.doubleConfirmed) {...} ... }` → **단순 `if (mode === "auto") status=confirmed`**
- 가드 필드: `doubleConfirmed?: boolean` (OrderRequest) → **제거**
- facade: `TelegramConfirmMode = "telegram" | "auto-paper" | "auto-live" | "off"` → `"telegram" | "auto" | "off"`
- 테스트: 13 (telegram) → 15 (+2 paper/live 분기) → 15 (단순화 후 동일)

**교훈**: 안전 기능 추가는 facade 후속. **owner가 "단순화" 요청 시 facade API 100% 유지하면서 내부만 단순화 가능**. v1.1.2/3 코드는 PR에서 자연스럽게 사라짐.

## References

- `references/telegram-chat-id.md` — `@userinfobot` 사용법 + 봇 ID 함정
- `references/toss-trader-step-2.5-runtime-fix-2026-07-10.md` — holdings.reduce + HMR + CHAT_ID 3건 fix
- `references/aws-sigv4-toss.md` — AWS SigV4 4단계 서명 + S3/R2 endpoint 차이
- `references/next-16-react-19-patterns.md` — dynamic params, useState for tabs, setTimeout 0 패턴
- `references/v1.3-storage-and-e2e-mock.md` — StorageProvider facade + AWS SigV4 (의존성 0) + Playwright per-test mock override (v1.3.1)
- `references/v1.4-candle-chart-pattern.md` — 순수 SVG 차트 (의존성 0) + fetchCandles + AbortController + CandleChart/CandlePanel 분리 (v1.4) + v1.4.2 캔들 응답 정규화 함정 (필드명/타입/envelope/정렬) + Mock Realism 교훈
- `references/mock-realism-api-integration.md` — API 통합 mock 정합화 체크리스트 (v1.4.2에서 일반화, 다른 API 통합 프로젝트에도 적용)

## v1.4.2 — 토스 Open API 응답 점검 체크리스트

**모든 endpoint의 mock이 실제 응답 형태와 일치하는지 검증** (v1.4.2 candles 학습 후):

| endpoint | 상태 | 점검 필요 |
|---|---|---|
| `/api/v1/candles` | ✅ v1.4.2 완료 | (없음) |
| `/api/v1/holdings` | ⚠️ 부분 검증 | `result.items` fallback 있음, **mock도 같은 envelope 검증** |
| `/api/v1/prices` | ⚠️ 부분 검증 | `result` 배열 + **string `lastPrice` → Number 변환** 검증 필요 |
| `/api/v1/accounts` | ⚠️ 미검증 | `result` 배열, 응답 형태 직접 curl 확인 권장 |
| `/api/v1/orders` | ⚠️ 미검증 | paper mock envelope 직접 curl 확인 권장 |
| `/oauth2/token` | ✅ 알 수 있음 | `{ access_token }` 평면 구조 |

**점검 절차**:
```bash
# 1) dev 서버 띄우고
cd /Users/mac/work/toss-trader
npx next dev -H 127.0.0.1 -p 3000 &

# 2) 실제 응답 확인 (필드명 + 타입 + envelope + 정렬)
curl -s "http://127.0.0.1:3000/api/toss/api/v1/holdings" | python3 -m json.tool | head -30
curl -s "http://127.0.0.1:3000/api/toss/api/v1/prices?symbols=005930" | python3 -m json.tool | head -30
curl -s "http://127.0.0.1:3000/api/toss/api/v1/accounts" | python3 -m json.tool | head -30

# 3) test/*.test.ts의 mock과 비교 → 다르면 fix
```

## v1.4.2 — Next.js 16 + TypeScript .gitignore 필수 항목

**문제**: `create-next-app@latest` (Next.js 16.2.10) 보일러플레이트 `.gitignore`는 다음 자동생성 파일이 **빠짐**:
- `tsconfig.tsbuildinfo` (TypeScript 빌드 캐시, 100KB+)
- `next-env.d.ts` (Next.js 자동 생성, **편집 금지**)

**해결** (보일러플레이트 직후):
```gitignore
# next.js
/.next/
/out/

# typescript
*.tsbuildinfo
/next-env.d.ts
```

**검증**:
```bash
git status
# → tsconfig.tsbuildinfo, next-env.d.ts가 untracked로 안 보여야 함
```

**다음 프로젝트 체크리스트**:
- [ ] `git clone` 직후 `.gitignore`에 `*.tsbuildinfo` + `/next-env.d.ts` 추가
- [ ] `npm run build` 후 `git status`로 확인 (untracked 없어야 함)
- [ ] PR에 자동 생성 파일이 포함되면 보일러플레이트 점검

## v1.4.2 — Mock Realism 패턴 (API 통합 TDD 일반 교훈)

v1.4.2 candles 학습에서 추출한 일반 원칙. **다른 API 통합 프로젝트에도 적용**:

1. **Mock은 wire shape 그대로** — `as Type` cast는 boundary (정규화 함수)에서, **mock 안에서 ❌**
2. **string number vs number** — 실 API는 string으로 옴 (특히 금융 API), mock도 string이어야
3. **envelope unwrap 순서 검증** — `{ data: { result: { items: [...] } } }` 같은 nested 구조는 **curl로 직접 확인**
4. **NaN 가드** — `Math.min(...NaN) = NaN` 조용히 실패 → `Number.isFinite` 가드 필수
5. **정렬 가정 명시** — 토스 candles는 newest-first, 차트는 oldest-first 가정 → 명시적 sort
6. **test pass immediately = false GREEN 위험** — 첫 실행에서 통과하면 mock이 추측이라는 신호 → **추가 실패 테스트로 보강**

**진단 워크플로우** (실측):
```bash
# 1) 실제 응답 직접 확인 (가장 중요)
curl -s "http://localhost:3000/api/..." | python3 -m json.tool | head -50

# 2) 응답 vs mock 비교 (필드명 + 타입 + envelope + 정렬)
# 3) 차이점 있으면 mock 수정 → RED → GREEN
```

상세 case study: `references/v1.4-candle-chart-pattern.md` §18 + 일반화: `references/mock-realism-api-integration.md`
