---
name: obsidian
description: Read, search, and create notes in the Obsidian vault.
---

# Obsidian Vault

**Location:** Set via `OBSIDIAN_VAULT_PATH` environment variable (e.g. in `$ENV_FILE`).

If unset, defaults to `~/Documents/Obsidian Vault`.

Note: Vault paths may contain spaces - always quote them.

## Read a note

```bash
VAULT="${OBSIDIAN_VAULT_PATH:-$HOME/Documents/Obsidian Vault}"
cat "$VAULT/Note Name.md"
```

## List notes

```bash
VAULT="${OBSIDIAN_VAULT_PATH:-$HOME/Documents/Obsidian Vault}"

# All notes
find "$VAULT" -name "*.md" -type f

# In a specific folder
ls "$VAULT/Subfolder/"
```

## Search

```bash
VAULT="${OBSIDIAN_VAULT_PATH:-$HOME/Documents/Obsidian Vault}"

# By filename
find "$VAULT" -name "*.md" -iname "*keyword*"

# By content
grep -rli "keyword" "$VAULT" --include="*.md"
```

## Create a note

```bash
VAULT="${OBSIDIAN_VAULT_PATH:-$HOME/Documents/Obsidian Vault}"
cat > "$VAULT/New Note.md" << 'ENDNOTE'
# Title

Content here.
ENDNOTE
```

## Append to a note

```bash
VAULT="${OBSIDIAN_VAULT_PATH:-$HOME/Documents/Obsidian Vault}"
echo "
New content here." >> "$VAULT/Existing Note.md"
```

## Wikilinks

Obsidian links notes with `[[Note Name]]` syntax. When creating notes, use these to link related content.

---

# Install & Restore Workflow

## Install Obsidian (macOS)

```bash
brew install --cask obsidian
# → /Applications/Obsidian.app + /opt/homebrew/bin/obsidian (CLI)
```

Verify: `claude` 등 다른 도구는 `/opt/homebrew/bin/obsidian` symlink를 통해 CLI 호출 가능.

## Restore a vault from a zip backup

Backups commonly come as `obsidian_vault_YYYYMMDD.zip` containing a **single top-level folder** (often `wiki/`). The folder inside the zip is the **vault root** Obsidian should open — do NOT flatten it, because `.obsidian/` config (themes, plugins, app state) sits inside it.

```bash
# 1. Choose vault path
VAULT_PARENT="$HOME/Documents/ObsidianVault"
mkdir -p "$VAULT_PARENT"

# 2. Unzip
unzip -q ~/Desktop/Hermes_Official_Backup/obsidian_vault_20260626.zip -d "$VAULT_PARENT"
# → $VAULT_PARENT/wiki/ is the vault root (contains .obsidian/, index.md, ...)

# 3. Sanity check
ls "$VAULT_PARENT/wiki/.obsidian/"        # app.json, core-plugins.json, appearance.json
ls "$VAULT_PARENT/wiki/.obsidian/themes/"  # CSS theme folders
```

## Open the vault

**From terminal (URI scheme):**

```bash
open "obsidian://open?path=/Users/mac/Documents/ObsidianVault/wiki"
```

**First-run behavior:** Obsidian shows a **"Trust author of this folder"** dialog. The user must click **Trust author** in the GUI — this is unavoidable from headless/CI contexts (AppleScript keystroke events require Accessibility permission that Telegram sessions don't have).

**If the dialog doesn't appear (welcome screen instead):**
- Manually: ⌘O → select `~/Documents/ObsidianVault/wiki/` → Trust

**Important for Telegram/text-only sessions:** Do not attempt `screencapture` (returns "could not create image from display") or `osascript` keystroke automation (returns "보조 접근이 허용되지 않습니다" / "osascript에서 키스트로크를 보내도록 허용되지 않습니다"). These are blocked by macOS Screen Recording / Accessibility permissions that the user must grant manually in System Settings → Privacy & Security. **Always tell the user clearly: "Trust author 버튼을 직접 클릭해주세요"** rather than burning time on automation that will fail.

## Verify the vault is healthy

```bash
VAULT="$HOME/Documents/ObsidianVault/wiki"
echo "Total .md: $(find "$VAULT" -name '*.md' -not -path '*/.obsidian/*' | wc -l)"
echo "Total folders: $(find "$VAULT" -type d -not -path '*/.obsidian*' | wc -l)"
echo "Size: $(du -sh "$VAULT" | cut -f1)"
head -20 "$VAULT/index.md"   # confirm index page exists
```

---

# .obsidian/ Directory Anatomy

The hidden config directory inside every vault. **Backups SHOULD include this** — it carries the user's theme, plugin set, and appearance preferences.

| File / Folder | Purpose | What to read it for |
|---|---|---|
| `app.json` | Per-vault app state | Usually `{}`; rarely needs editing |
| `appearance.json` | Theme choice | `{"theme": "moonstone", "cssTheme": "GitHub Theme"}` — base theme + optional CSS override |
| `core-plugins.json` | Built-in plugin toggle map | `{"file-explorer": true, "graph": true, ...}` — 30+ boolean keys |
| `graph.json` | Graph view settings | Node size, link force, colors |
| `themes/<Name>/` | CSS theme bundles | Each has `theme.css` + `manifest.json`; users add custom themes here |
| `plugins/<id>/` | Community plugin state | `manifest.json` + `data.json` + `main.js` — installed via Obsidian UI |
| `workspace.json` | Pane layout (auto-generated) | Often missing in backups; Obsidian regenerates on close |

**Quick health check after restore:**

```bash
cat "$VAULT/.obsidian/appearance.json"    # confirm theme name
cat "$VAULT/.obsidian/core-plugins.json" # confirm plugin toggles
ls "$VAULT/.obsidian/themes/"            # confirm CSS themes present
```

---

# Vault Path Conventions

Obsidian accepts any folder as a vault root. Common layouts:

```
~/Documents/ObsidianVault/wiki/        ← backup restore pattern (one level deep)
~/Documents/MyVault/                   ← flat single-user vault
~/Documents/Work/notes/                ← vault co-located with other content
```

**Quote paths** — vault names frequently contain spaces (`"Obsidian Vault"` vs `ObsidianVault`).

**Empty placeholder files are normal in template-style backups** — files like `claude-code.md` (0 bytes) at the vault root are sidebar anchors, not data. Don't delete them on restore.

---

# Backup Best Practices (when creating a vault zip)

If you ever need to zip a vault to share/restore elsewhere:

```bash
cd "$VAULT_PARENT"
zip -r obsidian_vault_$(date +%Y%m%d).zip wiki/ \
  -x "wiki/.obsidian/workspace.json" \
  -x "wiki/.obsidian/plugins/*/data.json"
```

Exclude `workspace.json` (transient pane state) and plugin `data.json` (may contain tokens for some community plugins). Keep `core-plugins.json` + `appearance.json` + `themes/` + `plugins/*/manifest.json` — those are reproducible config the user expects.
