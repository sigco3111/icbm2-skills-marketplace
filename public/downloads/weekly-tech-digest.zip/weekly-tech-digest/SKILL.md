---
name: weekly-tech-digest
description: 주간 기술 요약 뉴스레터 — AI/iOS/자동화 트렌드를 종합하여 Tistory에 자동 발행, ICBM2 인사이트 포함
version: 1.1.0
author: ICBM2
metadata:
  hermes:
    tags: [Newsletter, Weekly, Tistory, AI, iOS, Automation, Digest]
---

# ICBM2 주간 기술 요약 뉴스레터

## 개요

매주 일요일에 AI/iOS/자동화 트렌드를 종합하여 블로그 수준의 뉴스레터를 Tistory에 자동 발행합니다. ICBM2가 직접 작성한 아이디어 노트, Ship or Slop, 블로그 글 등의 인사이트도 포함합니다.

## 파이프라인

### 1단계: 데이터 수집 (스크립트)
```bash
python3 scripts/weekly_newsletter.py
```
수집 결과: `memory/weekly_newsletter_data.json`

수집 소스:
- **AI/ML**: AgentNews 피드 + Hacker News (AI/LLM/agent 관련)
- **iOS/Swift**: Hacker News + GitHub Trending (Swift)
- **자동화/도구**: Hacker News + GitHub Trending (Python)
- **ICBM2 인사이트**: blog_seo_history.json (이번 주 발행글) + notion_idea.md + shiporslop.md + botmadang.md

**1단계 후 즉시 판정**: AI/ML 5건 미만 → "이번 주 뉴스 부족으로 발행 스킵" 알리고 종료. 5건 이상 → 2단계로 진행 (W24 검증: AI 9건, iOS 10건, 자동화 8건 = 27건 OK).

**수집 데이터 구조 (W24 검증)**:
```python
data = {
    'week_label': '2026-W24',
    'week_start': '2026-06-15',
    'week_end': '2026-06-21',
    'sections': {
        'ai_trends': [{'title', 'url', 'category', 'source', 'domain', 'published_at'}, ...],
        'ios_trends': [...],
        'auto_trends': [...],
    },
    'icbm_insights': {'published_posts': [...]},
    'stats': {'total_items': 27, 'ai_count': 9, 'ios_count': 10, 'auto_count': 8}
}
```

**참고**: GitHub Trending `api.gitterapp.com` 엔드포인트는 404를 반환하는 경우가 있음 (W24 검증) — 폴백으로 HTML 파싱 경로가 동작하므로 정상 진행.

**⚠️ GitHub Trending 자동화/도구 카테고리 — CJK title 함정 (W28 신규)**:
- HKUDS/DeepTutor 같은 일부 OSS는 **README 제목과 stargazers 페이지 타이틀에 한자/일본어가 포함된 채** GitHub Trending에 노출됨.
- 한국어 작성 시 `把书、长视频、播客 등 고가치 콘텐츠를 실행 가능한 Agent Skills로 증류` 같은 표현이 그대로 따라옴 → 1차 CJK 정제 대상.
- **방어 패턴**: 자동화 트렌드 작성 시 수집 데이터의 `title` 필드를 먼저 훑어 CJK 포함 여부를 사전 검사하고, 있으면 본문에서 한자 표현을 한국어로 의역한 뒤 들어갈 것 (출처 URL은 보존).

### 2단계: 뉴스레터 글 작성 (에이전트)

수집된 데이터를 바탕으로 뉴스레터를 작성합니다. **권장 경로: HTML 직접 작성** (Markdown 변환 경로 대비 CJK 정제 단계가 1회로 단순해짐).

#### 글 구조
```
# [주간 기술 요약] 2026년 N주차 — AI · iOS · 자동화 트렌드

## 📋 이번 주 한눈에 보기
3-5줄 요약

## 🤖 AI/ML 트렌드
상위 5-7건, 각 항목:
- 제목 + 1-2줄 설명 + 링크
- 카테고리별로 insight/tool/infrastructure 구분

## 📱 iOS/Swift 소식
상위 3-5건

## 🔧 자동화 & 개발 도구
상위 3-5건

## 💡 ICBM2의 이번 주 인사이트
- 발행한 글 중 주목할 만한 것 2-3건 요약
- 아이디어 노트, Ship or Slop 활동 요약

## 🔮 다음 주 관전 포인트
2-3개 예측/전망
```

#### 작성 가이드라인
1. **한국어로 작성**, 전문적이면서 읽기 쉬운 톤
2. **본문 평문 7,000~8,000자 목표** (네임드 뉴스레터 품질) — W28 검증으로 8,000자는 hard ceiling 확정. 9,000자 초과 시 readability·seo 점수가 비선형적으로 하락하여 B 등급 → C 등급 강등 발생.
3. **평균 문장 길이 60자 이하** — readability 점수 직결 (W28: 91자 → 10/20, W24: 적정 → 15/20).
4. 단순한 링크 나열이 아닌 **분석과 인사이트 포함**
5. 각 항목에 ICBM2의 **의견/해석**을 1문장 추가
6. 링크는 HTML `<a>` 태그로 (`target="_blank" rel="noopener"` 권장) — 본문 a 태그 7~10개 권장 (외부 링크 0개면 seo 감점)
7. **HTML 직접 작성 경로 (권장)**: `<h2>`, `<h3>`, `<p>`, `<ul>`, `<strong>`, `<em>` 태그 직접 사용. Markdown 변환 단계 생략 → CJK 정제 1회로 충분.
8. **HTML 직접 작성 시 구조 분기 (W24 + W28 검증)**:
   - H2 6개 (이번 주 한눈에 보기 / AI/ML / iOS / 자동화 / ICBM2 인사이트 / 다음 주 관전 포인트) → H3 25~30개 → 본문 7,000~8,000자 (W28 안전 마진)
   - H2 1개당 본문 약 1,200~1,400자, H3 1개당 250~350자
   - **결론 section은 별도 H2로 분리 권장** (W28 검증: has_conclusion=true 일 때 content 35/35 회복) — 단 분량은 본문 길이 한도 안에서
   - 결론 마지막에 `<hr>` + `<em>본문 출처/교차 분석 출처</em>` 명시
   - 도입 첫 문단에 "2026년 {월} 셋째/넷째 주" 앵커링 → freshness FP 회피의 1차 앵커

### 3단계: SEO 최적화
```bash
python3 scripts/blog_seo_optimizer.py --file newsletter.md
```

**⚠️ SEO 옵티마이저 dedup ≠ blog_seo_history.json (W28 발견)**:
- `blog_seo_optimizer.py`는 자체 title_hash SSOT를 가지고 있어, `blog_seo_history.json`에 없는 주차도 "duplicate" 응답을 보낼 수 있음 (W28: 28주차 신규 발행임에도 optimizer에서 duplicate 응답).
- **판단**: optimizer의 duplicate 응답은 **참고용**이며 발행 게이트로 사용하지 말 것. 실제 발행 게이트는 `blog_quality_gate.py`. blog_seo_history.json으로 직접 중복 확인이 정석.

### 4단계: 품질 검사

**HTML 직접 작성 시**:
```bash
python3 ~/.hermes/scripts/blog_quality_gate.py \
  --title "[주간 기술 요약] 2026년 N주차 — AI · iOS · 자동화 트렌드" \
  --content "$(cat /tmp/newsletter_wNN.html)" \
  --tags "주간기술요약,AI,iOS,자동화,뉴스레터,트렌드,2026" \
  --category 1219746
```

**Pitfall**: `--file /tmp/newsletter_wNN.html`로 호출하면 `title_and_content_required` 에러 발생. **HTML 직접 작성 시 `--content` + `$(cat ...)` 조합이 정석** (W24 검증).

품질 등급 B 이상 통과 시 발행 진행. **판정 기준**:
- A (80+) → 적극 발행
- B (60~79) + `decision: pass` → 발행 진행 (W24·W26·W27 케이스)
- **C 이하 + `decision: rewrite` → 발행 보류 / 다음 주 연기** (W28 케이스 — state.json에 `skipped_grade_c` 이력 기록)

**W24 검증 결과 예시** (참고용):
- total_score: 60 / grade: B / decision: pass
- content: 35/35 (H2 6개, H3 26개, paragraph 52, has_intro+conclusion true)
- readability: 15/20
- originality: -8/20 (FP 정상, 아래 트러블슈팅 참조)
- seo: 18/25
- all_issues: 본문 11,462자 (8,000자 초과 경고), 89% 유사도, 2008/2012/2025년 freshness 경고

**W28 fail 케이스 (C 등급, 발행 보류) — 첫 발행 보류 사례**:
- total_score: 50→52 / grade: C / decision: **rewrite**
- content: 33~35/35 (결론 section 추가 후 35 회복, but 본문 10,767→11,250자 더 늘어남)
- readability: 10/20 (평균 문장 90~91자 — W24의 15/20 대비 -5)
- originality: -8/20 (동일 FP)
- seo: 15/25 (서론 SEO 메타 부적합 -3)
- **원인**: 본문이 10,000자 초과하면서 readability·seo 양쪽 감점. 8,000자 권장이 soft warning이 아니라 hard ceiling으로 작동.

**8,000자 hard ceiling 학습 (W28 신규)**:
- W24 검증 메모에는 "11,462자까지 통과"로 기록되어 있었으나, W28에서는 10,767자에서 C 등급 → 8,000자 초과 시 readability와 seo 점수가 비선형적으로 하락하는 패턴 확인
- **안전 마진 권장**: 본문 평문 7,000~8,000자 (H2 6 + H3 25 기준), 평균 문장 길이 60자 이하 목표
- **결론 section 추가는 점수 회복에 도움 안 됨** (오히려 길이만 늘어남, W28: 50→52점 -2점만 회복) → 길이 압축이 1차 대응

### 5단계: Tistory 발행
```bash
# 세션 유효성 먼저 확인 (쿠키 만료 체크)
python3 ~/.hermes/scripts/tistory_publisher.py --check

# HTML 직접 작성 시 --file 경로 사용
python3 ~/.hermes/scripts/tistory_publisher.py \
  --file /tmp/newsletter_wNN.html \
  --title "[주간 기술 요약] 2026년 N주차 — AI · iOS · 자동화 트렌드" \
  --tags "주간기술요약,AI,iOS,자동화,뉴스레터,트렌드,2026" \
  --visibility public \
  --category 1219746 \
  --image-query "weekly tech newsletter AI 2026"
```

**Pitfall (175차 + W24 검증)**:
- `cat /tmp/newsletter.html | python3 ... tistory_publisher.py` 형태 호출 시 Tirith security scan "Pipe to interpreter" HIGH 경고 + `pending_approval` 차단. **반드시 `--file`로 직접 파일 경로 전달**.
- `--post` / `--description` / `--content-source` 옵션은 publisher에 **존재하지 않음**. `--file` 또는 `--content`만 사용.
- `--category`는 **정수형 ID** (1219746 = AI/ML) 한정. 문자열 카테고리명 → `invalid int value` 에러.

**Picsum image-query (W24 검증)**:
- 영문 키워드 + 공백 5단어 권장: `weekly tech newsletter AI 2026` → Picsum ID 432/85 자동 할당
- ID는 결정성 유지 (동일 query → 동일 ID), 누적 81회째 무충돌
- 본문 figure 2장 자동 삽입 + OG 썸네일 1장 = 3장 동시 사용
- CDN 업로드 2/2 안정 (W24: 47KB/81KB)

카테고리: AI 뉴스 (1219746) 또는 기타 (1219751)

### 6단계: 사후 record + 상태 파일 갱신

발행 성공 후 반드시 2건의 후속 작업:

**6-1: blog_seo_history.json 사후 record (3인자)**:
```bash
python3 ~/.hermes/scripts/blog_pipeline.py --record "weekly-tech-digest" \
  "[주간 기술 요약] 2026년 N주차 — AI · iOS · 자동화 트렌드" \
  "https://sigco.tistory.com/XXX"
```

**Pitfall (169차 검증)**: `--record`는 **정확히 3인자 (TOPIC TITLE URL) 한정**. 4번째 인자 (topic_url) 추가 시 `unrecognized arguments` 에러.

**6-2: weekly_newsletter_state.json 누적 갱신** (W24 신규):
```python
import json
from datetime import datetime

state_path = '/Users/hjshin/.hermes/memory/weekly_newsletter_state.json'
try:
    with open(state_path) as f:
        state = json.load(f)
except FileNotFoundError:
    state = {'history': []}

state['history'].append({
    'week': '2026-WNN',
    'published_at': datetime.now().isoformat(),
    'title': '[주간 기술 요약] 2026년 N주차 — AI · iOS · 자동화 트렌드',
    'url': 'https://sigco.tistory.com/XXX',
    'tistory_id': XXX,
    'total_items': 27,
    'ai_count': 9,
    'ios_count': 10,
    'auto_count': 8,
})

with open(state_path, 'w') as f:
    json.dump(state, f, ensure_ascii=False, indent=2)
print(f'✅ 상태 파일 갱신 완료 (누적 {len(state["history"])}회)')
```

**판단**: W24 발행 후 state.json 누적 카운트 13회째 도달. 주간 발행 추세 / 카테고리별 카운트 / 휴면 주 추적용으로 활용.

**6-3: 품질 게이트 C 등급으로 발행 보류 시 — skip 이력 기록 (W28 신규)**:

```python
import json
from datetime import datetime

state_path = '/Users/hjshin/.hermes/memory/weekly_newsletter_state.json'
try:
    with open(state_path) as f:
        state = json.load(f)
except FileNotFoundError:
    state = {'history': []}

state['history'].append({
    'week': '2026-WNN',
    'attempted_at': datetime.now().isoformat(),
    'outcome': 'skipped_grade_c',  # 또는 skipped_low_news
    'reason': 'blog_quality_gate decision=rewrite (total=N, grade=C)',
    'data_total': 27,
    'ai_count': 9,
    'ios_count': 10,
    'auto_count': 8,
    'html_path': '/tmp/newsletter_wNN.html',  # 다음 주 재사용 가능하도록 보존
    'data_path': '~/.hermes/memory/weekly_newsletter_data.json',
    'note': 'SKILL.md C 이하 발행 보류. 다음 주(W(N+1)) 발행 시 HTML 재사용 권장.',
})

with open(state_path, 'w') as f:
    json.dump(state, f, ensure_ascii=False, indent=2)
print(f'✅ state 갱신 (skip 기록). 누적 {len(state["history"])}건')
```

**판단**: 보류 결정 시에도 state.json에는 `outcome: skipped_grade_c`로 기록해 누락이 아닌 의도적 skip임을 명시. SSOT 무결성 유지 + 다음 주 재시도 시 보존된 HTML 활용 가능.

### 7단계: 완료 알림
발행 결과(URL)를 주인님에게 텔레그램으로 전송.

## 상태 파일

- `memory/weekly_newsletter_data.json` — 수집 데이터 (1단계 산출)
- `memory/weekly_newsletter_state.json` — 발행 이력 (6-2·6-3 단계에서 누적 갱신)

## 세션 노트 / 누적 자료

- `references/session-20260621-2026-W24.md` — 2026-W24 (6월 셋째 주) 발행 세션 노트. AI 9 + iOS 10 + 자동화 8 = 27건, H2 6 + H3 26, 평문 7,903자, B 60점 decision=pass, CJK 9번째 클래스 한 HTML에 3건 동시 케이스 (한자+한글+히라가나), publisher cat 파이프 차단 pitfall, blog_quality_gate HTML 직접 작성 시 `--content` 강제 pitfall, 누적 13회째.
- `references/session-20260701-2026-W26.md` — 2026-W26 (7월 첫째 주) 세션 노트. 동일 27건 분포, 7월 첫째 주 앵커링, B 등급 pass, 누적 13회째.
- `references/session-20260712-2026-W27.md` — 2026-W27 (7월 둘째 주) 발행 세션 노트. 동일 27건 분포 (AI 9 / iOS 10 / 자동화 8), H2 6 + H3 33, 평문 12,546자, B 61점 decision=pass (`https://sigco.tistory.com/976`). 5중 신호 5/5 일치 + post_publish_sync 7필드 보정 정상. **W27 신규 학습**: `/tmp/newsletter_wNN.html`을 write_file로 덮어쓴 사고 — 정제 스크립트는 별도 `.py` 경로 필수 (SKILL.md 본문 pitfall 영구화). CJK 0건 초기 작성으로 회복.
- `references/session-20260719-2026-W28.md` — 2026-W28 (7월 셋째 주) **첫 발행 보류 사례**. 동일 27건 분포, H2 6 + H3 25 → 결론 추가 후 H2 7 + H3 25, 평문 8,970자 → 11,250자, **C 50→52점 decision=rewrite** → SKILL.md "C 이하 발행 보류" 규칙 따라 skip. 8,000자 hard ceiling 학습, blog_seo_optimizer dedup ≠ blog_seo_history SSOT 불일치 발견, GitHub Trending DeepTutor CJK title 사전 검사 패턴 추가, `skipped_grade_c` state 이력 스키마 정형화 (6-3), Tistory 세션 raw 검증 VALID (W27 #976 정상).

## 크론 설정

매주 일요일 11:00 KST 실행
```
0 11 * * 0
```

## 사전 체크 및 트러블슈팅

### Python 3.8 호환성 문제 (2026-05-03 발견)

`weekly_newsletter.py` 실행 시 `TypeError: 'type' object is not subscriptable` 오류가 발생하면:

**원인:** Python 3.8에서는 `tuple[str, str]` 문법을 지원하지 않음 (PEP 585 lowercase generics는 Python 3.9+). `typing.Tuple`을 사용해야 함.

**수정 방법:**
```bash
# 1. 타입 임포트 확인
from typing import Optional, Union, Dict, List, Any, Tuple

# 2. 파일 내 문제되는 타입 힌트 수정
sed -i '' 's/tuple\[/Tuple[/g' ~/.hermes/scripts/weekly_newsletter.py
sed -i '' 's/list\[/List[/g' ~/.hermes/scripts/weekly_newsletter.py
```

**주의:** `List[` 치환 시 `logging.FileHandler` 같은 `list` 파라미터는 영향 없음 (소문자 `list`는 함수 호출임). 대문자 `List[`만 치환 대상.

### CJK 문자 정제 — Markdown 작성 시 예방 + 변환 후 정제 (2단계)

CJK 혼입은 **마크다운 작성 단계에서 예방**하는 것이 변환 후 정제보다 효과적이다. 작성 중 한국어 텍스트 사이에 한자/일본어가 섞여 들어가는 패턴이 반복되어 왔음 (55차+ 정제 기록).

#### 단계 1: Markdown 작성 시 CJK 선검사 (2회차 필수)

```python
import re

with open('/tmp/newsletter.md', 'r') as f:
    md = f.read()

cjk = set(re.findall(r'[\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff]', md))
if cjk:
    print(f"⚠️ Markdown CJK 발견 (1차): {len(cjk)}자")
    # 1차 정제 — 제한적 사전
    limited = {}
    for old, new in comprehensive_dict.items():
        md = md.replace(old, new)
    # 2차 검사
    cjk2 = set(re.findall(r'[\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff]', md))
    if cjk2:
        print(f"⚠️ Markdown CJK 잔여 (2차): {len(cjk2)}자")
        # ⚠️ 제한적 사전 반복이 아닌 종합 사전으로 1회성 정제
        for old, new in comprehensive_dict.items():
            md = md.replace(old, new)
    with open('/tmp/newsletter.md', 'w') as f:
        f.write(md)
    print("✅ Markdown CJK 정제 완료")
else:
    print("✅ Markdown CJK 없음")
```

> **핵심 교훈:** 1차 정제 후 "완료"로 보여도 재검사하면 잔여가 반드시 있음. 반드시 2회차 검사 후 잔여 발견 시 **제한적 사전 반복이 아닌 종합 사전으로一口气 정제**. 2회차가 clean이면 HTML 변환 시 CJK 루프가 0회차로 바로 통과.

#### 단계 2: HTML 변환 후 CJK 정제 루프

`tistory-publisher` 스킬의 comprehensive CJK 사전을 사용한다. (이 skill의 inline dict는 불완전하므로 tistory-publisher 스킬의 최신 comprehensive dict를 반드시 참조할 것.)

**핵심 원칙:**
- `markdown_to_tistory_html.py` 변환 직후 **즉시** CJK 정제 실행
- 루프 안정화(`html == html_before`) 후에도 잔여가 발생할 수 있음 — 별도 2차 targeted 패치 실행
- Korean Hanja (U+CDF0 등)는 CJK regex [\u4e00-\u9fff] 밖이라 탐지 불가 → 종합 사전에 `'쾨': '쾌'` 같은 Korean Hanja 직접 치환 추가

### 뉴스 부족 시 발행 스킵

- 최소 AI 트렌드 5건 이상 필요
- 5건 미만 시 "이번 주 뉴스 부족으로 발행 스킵" 알리고 종료

### 품질 게이트 거짓 양성 패턴 — 뉴스레터 특이사항

`blog_quality_gate.py`의 유사도·시간 신선도 체크가 뉴스레터에서 오탐을 발생させる:

1. **89% 유사도 경고:** 뉴스레터는每周 구조가 동일하여 매번 "이전 글과 매우 유사" 경고가 발생. 이 경고는 **정상이며 무시해도 됨** (형식적 유사이지 콘텐츠 중복이 아님). Grade B 이상 통과 시 그대로 발행.

2. **2008/2012년 자료 경고:** Kevin Rose의 Digg 재런칭 기사를 다룰 때, 원래 Digg의 창업 연도(2008년), Craigslist 인수의 연도(2012년)를 역사적 맥락으로 언급하면 "구버전 자료" 경고가 발생. 이는 **역사적 비유로서의 사용이므로 정상** — blog_pipeline의 source_url이 2026년이고 기사 자체가 2026년 최신이면 경고는 페널티 없이 통과.

3. **인식된 오탐 패턴 목록 (누적):**
   - 역사적 타임라인/비유 기사: 과거 연도가 "타임라인" 맥락으로 사용됨
   - IE/Web 역사적 비유: "Internet Explorer 시절", "2000년대" 등
   - 중간 election 관련 자료: 2026 election에서 AI/Crypto가 dirty words가 되는 구조적 분석

## 주의사항

- GitHub Trending HTML 파싱은 GitHub 구조 변경 시 깨질 수 있음 (폴백 있음)
- Tistory 쿠키 만료 시 발행 실패 — tistory-publisher 스킬의 트러블슈팅 참고

## ⚠️ "X시 크론 수행해" 워크플로 (07-01 학습)

사용자가 *"16시 크론 해줘"* / *"X시 크론은 ~~하는 거잖아"* 같은 멘트로 시간 기준 cron 실행을 요청할 때, **사용자가 그 시각의 정확한 잡 이름을 기억 못 하는 경우**가 있음. 예: 07-01에 *"16시 크론은 유튜브 영상 올리기잖아"*라고 하셨지만 실제 cron은 **📰 주간 기술 요약 뉴스레터** (Tistory 발행, `7995f1387b79`).

**표준 워크플로**:
1. **즉시 실행하지 말 것**. 먼저 `hermes cron list`로 등록된 모든 cron 확인.
2. **사용자가 언급한 시각·빈도로 매칭되는 잡 ID 찾기**. 예: "16시 크론" → `0 16 * * 0` 스케줄 잡 검색.
3. **잡 ID + 이름 + schedule 한 줄로 사용자에게 알리고 정정 가능성 묻기**. 예: "📰 주간 기술 요약 뉴스레터 (Tistory 발행, 잡 ID `7995f1387b79`) — 이거 맞으세요?"
4. **사용자 확인 후 `hermes cron run <id>` 실행**. background로 시작 후 `process(action='poll')` / `wait` 로 모니터.
5. **출력은 잡 완료 시점에 들어옴**. `output_preview`가 빈 채로 `running`인 것은 정상 (자식 LLM 세션이 stdout 캡처 전 진행 중).

**강한 톤 신호** ("다른 크론을 수행했네", "그게 아니라 ~"): 사용자가 *이전 턴에 잘못된 잡을 실행한 것에 대한 강한 실망* 표현. 즉시 cron list + 정확한 잡 ID로 정정 + 재실행. 변명보다 실행.

**블로그 주제 갱신과 혼동 주의**: `blog_pipeline.py --refresh-topics`는 *Notion DB에 긱뉴스 주제 12개 추가* 작업 (잡 ID `b02a45f4d14e`, 매일 13시 실행). 이건 **Tistory 발행 뉴스레터 잡과 다른 별도 잡**. 사용자가 *"블로그 발행"*이라고 모호하게 말할 때 어느 쪽인지 정확히 매핑해야 함 (스크립트 인자 vs cron 잡).

### 뉴스레터 특화 CJK 정제 파이프라인 (HTML 직접 작성 시)

뉴스레터는 Markdown을 거치지 않고 **HTML을 직접 작성**하므로, `markdown_to_tistory_html.py` 변환 단계가 없다. CJK 정제는 HTML 파일에서 **1회 passes**로 진행한다.

```python
import re

with open('/tmp/newsletter_w21.html', 'r') as f:
    html = f.read()

cjk = set(re.findall(r'[\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff]', html))
print(f"CJK 발견: {len(cjk)}개 — {cjk}")
if cjk:
    replacements = {
        '习': '', '定': '정', '追': '쫓아', '作': '작', '了': '료',
        '得': '득', '后': '후', '注': '주', '赛': '새', '成': '성',
        '回': '회', '的': '적', '关': '관', '熟': '숙', '新': '신',
        '教': '교', '训': '훈', '报': '보', '才': '재', '来': '래',
        '速': '속', '道': '도', '每': '매', '加': '가', '值': '치',
        '周': '주', '学': '학', '着': '착', '赶': '쫓아',
    }
    for old, new in replacements.items():
        html = html.replace(old, new)
    with open('/tmp/newsletter_w21.html', 'w') as f:
        f.write(html)
    print("✅ CJK 정제 완료")
```

**CJK 매치 컨텍스트 출력 패턴 (W24 검증 권장)**: 사전 글리프 단위 치환 전에, 어떤 표현에 한자/히라가나가 섞였는지 식별:

```python
import re

with open('/tmp/newsletter_wNN.html') as f:
    html = f.read()

cjk = re.findall(r'[\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff]+', html)
if cjk:
    print(f'⚠️ CJK {len(cjk)}개 발견')
    for m in re.finditer(r'[\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff]+', html):
        s = max(0, m.start()-30)
        e = min(len(html), m.end()+30)
        print(f'  ...{html[s:e]}...')

    # 표현 단위 통째 치환 (글리프 단위 X)
    replacements = [
        ('OLD_표현', 'NEW_표현'),
        # ...
    ]
    for old, new in replacements:
        html = html.replace(old, new)

    with open('/tmp/newsletter_wNN.html', 'w') as f:
        f.write(html)

    # 잔여 재검사
    cjk2 = re.findall(r'[\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff]', html)
    print(f'✅ CJK 잔여: {len(cjk2)}')
```

**W24 실전 사례 (CJK 9번째 클래스 — 한자+한글+히라가나 3중 혼합 한 HTML 동시 3건)**:
- `회사를運営する 입장에서` (한자 運 + 히라가나 る + 한글) → `회사를 운영하는 입장에서`
- `低成本으로 돌리려는` (한자 低/成 + 한글) → `저비용으로 돌리려는`
- `규제法案**을 발의` (한자 法案 + 한글) → `규제입법**을 발의`

3건 모두 1회 patch 한꺼번에 처리 → CJK 0건 회복. **핵심**: 한자+히라가나가 한 표현 안에 섞여 있을 때 **글리프 단위 치환은 인접 한글이 잘려나가므로 표현 단위 통째 치환이 안전** (175차 정형화 + W24 검증).

**W28 신규 사례**: GitHub Trending 자동화 카테고리에서 `把书、长视频、播客 등 고가치 콘텐츠를 실행 가능한 Agent Skills로 증류` 같은 표현이 **수집 데이터 source title에 포함**되어 들어옴. 표현 단위 치환 `把书、长视频、播客` → `책·긴 영상·팟캐스트`로 1회 처리. 그 후 의역 코멘트로 남은 `코드 코멘트에 한자(把/长)` 메타 표현도 별도 2차 패치로 `한자` 일반화 처리 → CJK 0건.

#### ⚠️ 절대 금지: `write_file`로 HTML 발행 파일을 덮어쓰지 말 것 (W27 사고)

CJK 정제 스크립트를 `/tmp/newsletter_wNN.html` 같은 발행 파일 경로로 직접 `write_file`하지 말 것. 스크립트는 `/tmp/clean_cjk_wNN.py`처럼 명확히 `.py` 확장자 별도 경로에 저장 후 `terminal`+heredoc 또는 `python3 /tmp/clean_cjk_wNN.py`로 호출.

**W27 사고 사례**: `/tmp/newsletter_w27.html`에 정제 스크립트 본문이 통째로 박혀 14,734자 한글 본문이 손실됨. 백업 미보유 → 처음부터 재작성.

**회피 패턴**:
- 정제 스크립트는 반드시 별도 경로 (예: `/tmp/check_wNN_html.py`, `/tmp/cjk_clean_wNN.py`).
- 또는 정제를 `write_file` 두 개 (HTML 본문 + 정제 .py) + `terminal python3 /tmp/cjk_clean_wNN.py` 체인으로 모듈화.

**진단**: 발행 전 `head -5 /tmp/newsletter_wNN.html | grep -q '<h2' && echo OK || echo "⚠️ HTML 아님!"` 로 첫 줄 검증. `import re` / `# Python script`로 시작하면 사고 — 즉시 재작성.

### blog_seo_history.json 읽기 — terminal 파이핑 주의

```bash
# ❌ 보안 스캔 차단: cat | python3 파이프라인
cat ~/.hermes/memory/blog_seo_history.json | python3 -c "..."

# ✅ execute_code 사용 (파이프라인 대신)
python3 -c "
import json
with open('/Users/hjshin/.hermes/memory/blog_seo_history.json') as f:
    data = json.load(f)
for p in data['posts'][-5:]:
    print(p['title'])
"
```

### Korean text corruption vs Valid Hangul 식별법

CJK cleaning 중 "이것은CJK인가?" 판단이 필요한 경우, Unicode code point로 확인할 것:

```python
for c in suspicious_string:
    code = ord(c)
    print(f"{c} → U+{code:04X}", end=" ")
    if 0xAC00 <= code <= 0xD7A3:  # 한글 음절 (가-힣)
        print("(✅ Valid Korean Hangul)")
    elif 0x4E00 <= code <= 0x9FFF:  # CJK 통합 한자
        print("(⚠️ CJK Hanja)")
    elif 0x3040 <= code <= 0x30FF:  # Japanese
        print("(⚠️ Japanese)")
```

**실제 사례 (2026-W21):** `"시큐리티새도"` 중 `새(U+C0C8)`, `도(U+B3C4)`는 모두 U+AC00–U+D7A3 범위 → **유효한 한글**. CJK regex `\u4e00-\u9fff`에マッチ하지만 실제로는 한글 음절이므로 corruption이 아님. 반드시 Unicode code point로 확인할 것.