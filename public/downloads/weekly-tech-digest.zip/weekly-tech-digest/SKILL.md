---
name: weekly-tech-digest
description: 주간 기술 요약 뉴스레터 — AI/iOS/자동화 트렌드를 종합하여 Tistory에 자동 발행, ICBM2 인사이트 포함
version: 1.0.0
author: ICBM2
metadata:
  hermes:
    tags: [Newsletter, Weekly, Tistory, AI, iOS, Automation, Digest]
---

# ICBM2 주간 기술 요약 뉴스레터

## 개요

매주 일요일에 AI/iOS/자동화 트렌드를 종합하여 블로그 수준의 뉴스레터를 Tistory에 자동 발행합니다. ICBM2가 직접 작성한 아이디어 노트, Ship or Slop, 블로그 글 등의 인사이트도 포함합니다.

## 파이프라인

### 1단계: 데이터 수집 (스크립트)
```bash
python3 scripts/weekly_newsletter.py
```
수집 결과: `memory/weekly_newsletter_data.json`

수집 소스:
- **AI/ML**: AgentNews 피드 + Hacker News (AI/LLM/agent 관련)
- **iOS/Swift**: Hacker News + GitHub Trending (Swift)
- **자동화/도구**: Hacker News + GitHub Trending (Python)
- **ICBM2 인사이트**: blog_seo_history.json (이번 주 발행글) + notion_idea.md + shiporslop.md + botmadang.md

### 2단계: 뉴스레터 글 작성 (에이전트)

수집된 데이터를 바탕으로 뉴스레터를 작성합니다.

#### 글 구조
```
# [주간 기술 요약] 2026년 N주차 — AI · iOS · 자동화 트렌드

## 📋 이번 주 한눈에 보기
3-5줄 요약

## 🤖 AI/ML 트렌드
상위 5-7건, 각 항목:
- 제목 + 1-2줄 설명 + 링크
- 카테고리별로 insight/tool/infrastructure 구분

## 📱 iOS/Swift 소식
상위 3-5건

## 🔧 자동화 & 개발 도구
상위 3-5건

## 💡 ICBM2의 이번 주 인사이트
- 발행한 글 중 주목할 만한 것 2-3건 요약
- 아이디어 노트, Ship or Slop 활동 요약

## 🔮 다음 주 관전 포인트
2-3개 예측/전망
```

#### 작성 가이드라인
1. **한국어로 작성**, 전문적이면서 읽기 쉬운 톤
2. **본문 3000자 이상** (네임드 뉴스레터 품질)
3. 단순한 링크 나열이 아닌 **분석과 인사이트 포함**
4. 각 항목에 ICBM2의 **의견/해석**을 1문장 추가
5. 링크는 HTML `<a>` 태그로
6. 마크다운 → Tistory HTML로 변환하여 발행

### 3단계: SEO 최적화
```bash
python3 scripts/blog_seo_optimizer.py --file newsletter.md
```

### 4단계: 품질 검사
```bash
python3 scripts/blog_quality_gate.py --file newsletter.md
```
품질 등급 B 이상 통과 시 발행 진행.

### 5단계: Tistory 발행
```bash
python3 scripts/tistory_publisher.py \
  --title "제목" \
  --content "HTML 내용" \
  --tags "주간기술요약,AI,iOS,자동화,뉴스레터,2026" \
  --visibility public \
  --category 1219746
```
카테고리: AI 뉴스 (1219746) 또는 기타 (1219751)

### 6단계: 완료 알림
발행 결과(URL)를 주인님에게 텔레그램으로 전송.

## 상태 파일

- `memory/weekly_newsletter_data.json` — 수집 데이터
- `memory/weekly_newsletter_state.json` — 발행 이력

## 크론 설정

매주 일요일 11:00 KST 실행
```
0 11 * * 0
```

## 사전 체크 및 트러블슈팅

### Python 3.8 호환성 문제 (2026-05-03 발견)

`weekly_newsletter.py` 실행 시 `TypeError: 'type' object is not subscriptable` 오류가 발생하면:

**원인:** Python 3.8에서는 `tuple[str, str]` 문법을 지원하지 않음 (PEP 585 lowercase generics는 Python 3.9+). `typing.Tuple`을 사용해야 함.

**수정 방법:**
```bash
# 1. 타입 임포트 확인
from typing import Optional, Union, Dict, List, Any, Tuple

# 2. 파일 내 문제되는 타입 힌트 수정
sed -i '' 's/tuple\[/Tuple[/g' ~/.hermes/scripts/weekly_newsletter.py
sed -i '' 's/list\[/List[/g' ~/.hermes/scripts/weekly_newsletter.py
```

**주의:** `List[` 치환 시 `logging.FileHandler` 같은 `list` 파라미터는 영향 없음 (소문자 `list`는 함수 호출임). 대문자 `List[`만 치환 대상.

### CJK 문자 정제

AI가 작성한 HTML 뉴스레터에 한자/일본어/중국어가 혼입되는 경우가 많음. 반드시 변환 직후 정제할 것.

```python
import re

def clean_cjk(html):
    replacements = {
        # Japanese hiragana
        'い': '이', 'と': '토', 'て': '테', 'し': '시', '来': '래',
        'う': '우', 'れ': '레', 'る': '루', 'が': '가', 'な': '나',
        'に': '니', 'は': '하', 'を': '오', 'だ': '다', 'か': '카',
        'ね': 'ネ',
        # Japanese katakana
        'ー': '', 'ン': '은', 'タ': '타', 'チ': '치', 'ニ': '니',
        'の': '',
        # Chinese characters (selected common ones)
        '視': '시', '据': '거', '域': '역', '执': '집', '投': '투',
        '驱': '구', '证': '증', '領': '영', '动': '동', '行': '행',
        '自': '자', '论': '론', '工': '공', '审': '심', '處': '처',
        '義': '의', '樣': '양', '長': '장', '會': '회', '現': '현',
        '場': '장', '測': '측', '構': '구', '發': '발', '場': '장',
        '通': '통', '能': '능', '言': '언', '付': '부', '申': '신',
        '清': '청', '解': '해', '市': '시', '查': '사', '主': '주',
        '化': '화', '生': '생', '上': '상', '取': '취', '斯': '스',
        '处': '처', '理': '리', '用': '용', '判': '판', '加': '가',
        '面': '면', '量': '량', '金': '금', '卡': '카드', '動': '동',
        '规': '규', '晰': '석', '得': '득', '活': '활', '货': '화',
        '力': '력', '庭': '정', '立': '립', '户': '호', '合': '합',
        '報': '보', '层': '층', '成': '성', '情': '정', '推': '추',
        '破': '파', '证': '증', '送': '송', '引': '인', '気': '기',
        '发': '발', '费': '비', '元': '원', '多': '다', '评': '평',
        '质': '질', '築': '축', '件': '건', '境': '경', '貨': '화',
        '学': '학', '喝': '흡', '可': '가', '反': '반', '旨': '지',
        '囲': '위', 'で': '데', '初': '초', '一': '일', '壁': '벽',
        '个': '개', 'さ': '사', '阶': '계', '恐': '공', '其': '기',
        '人': '인', '操': '조', '浮': '부', '小': '소', '語': '어',
        '逆': '역', '同': '동', '墙': '장', '応': '응', '専': '전',
        '不': '불', '周': '주', '味': '미', '段': '단', '專': '전',
        '盟': '맹', '粒': '립', '预': '예', '事': '사', '应': '응',
        '急': '급', '欧': '구', '惨': '참', '大': '대', '度': '도',
        '認': '인', '低': '저', '波': '파', '风': '풍', '职': '직',
        '識': '식', '透': '투', '限': '한', '閲': '열', '任': '임',
        '責': '책', '秘': '비', '詳': '상', '明': '명', '广': '광',
        '覧': '람', '策': '책', '业': '업', '対': '대', '密': '밀',
        '跨': '跨境', '场': '장', '测': '측',
    }
    for old, new in replacements.items():
        html = html.replace(old, new)
    return html

def has_cjk(text):
    return bool(re.search(r'[\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff]', text))

# 루프 — 없어질 때까지 반복
pass_num = 0
while has_cjk(html):
    html_before = html
    html = clean_cjk(html)
    pass_num += 1
    if html == html_before:
        remaining = set(re.findall(r'[\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff]', html))
        print(f"⚠️ 잔여 CJK: {remaining}")
        break
print(f"✅ CJK 정제 완료 ({pass_num}회차)")
```

### 뉴스 부족 시发行 스킵

- 최소 AI 트렌드 5건 이상 필요
- 5건 미만 시 "이번 주 뉴스 부족으로 발행 스킵" 알리고 종료

## 주의사항

- GitHub Trending HTML 파싱은 GitHub 구조 변경 시 깨질 수 있음 (폴백 있음)
- Tistory 쿠키 만료 시 발행 실패 — tistory-publisher 스킬의 트러블슈팅 참고
