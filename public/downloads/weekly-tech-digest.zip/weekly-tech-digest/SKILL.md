---
name: weekly-tech-digest
description: 주간 기술 요약 뉴스레터 — AI/iOS/자동화 트렌드를 종합하여 Tistory에 자동 발행, ICBM2 인사이트 포함
version: 1.0.0
author: ICBM2
metadata:
  hermes:
    tags: [Newsletter, Weekly, Tistory, AI, iOS, Automation, Digest]
---

# ICBM2 주간 기술 요약 뉴스레터

## 개요

매주 일요일에 AI/iOS/자동화 트렌드를 종합하여 블로그 수준의 뉴스레터를 Tistory에 자동 발행합니다. ICBM2가 직접 작성한 아이디어 노트, Ship or Slop, 블로그 글 등의 인사이트도 포함합니다.

## 파이프라인

### 1단계: 데이터 수집 (스크립트)
```bash
python3 scripts/weekly_newsletter.py
```
수집 결과: `memory/weekly_newsletter_data.json`

수집 소스:
- **AI/ML**: AgentNews 피드 + Hacker News (AI/LLM/agent 관련)
- **iOS/Swift**: Hacker News + GitHub Trending (Swift)
- **자동화/도구**: Hacker News + GitHub Trending (Python)
- **ICBM2 인사이트**: blog_seo_history.json (이번 주 발행글) + notion_idea.md + shiporslop.md + botmadang.md

### 2단계: 뉴스레터 글 작성 (에이전트)

수집된 데이터를 바탕으로 뉴스레터를 작성합니다.

#### 글 구조
```
# [주간 기술 요약] 2026년 N주차 — AI · iOS · 자동화 트렌드

## 📋 이번 주 한눈에 보기
3-5줄 요약

## 🤖 AI/ML 트렌드
상위 5-7건, 각 항목:
- 제목 + 1-2줄 설명 + 링크
- 카테고리별로 insight/tool/infrastructure 구분

## 📱 iOS/Swift 소식
상위 3-5건

## 🔧 자동화 & 개발 도구
상위 3-5건

## 💡 ICBM2의 이번 주 인사이트
- 발행한 글 중 주목할 만한 것 2-3건 요약
- 아이디어 노트, Ship or Slop 활동 요약

## 🔮 다음 주 관전 포인트
2-3개 예측/전망
```

#### 작성 가이드라인
1. **한국어로 작성**, 전문적이면서 읽기 쉬운 톤
2. **본문 3000자 이상** (네임드 뉴스레터 품질)
3. 단순한 링크 나열이 아닌 **분석과 인사이트 포함**
4. 각 항목에 ICBM2의 **의견/해석**을 1문장 추가
5. 링크는 HTML `<a>` 태그로
6. 마크다운 → Tistory HTML로 변환하여 발행

### 3단계: SEO 최적화
```bash
python3 scripts/blog_seo_optimizer.py --file newsletter.md
```

### 4단계: 품질 검사
```bash
python3 scripts/blog_quality_gate.py --file newsletter.md
```
품질 등급 B 이상 통과 시 발행 진행.

### 5단계: Tistory 발행
```bash
python3 scripts/tistory_publisher.py \
  --title "제목" \
  --content "HTML 내용" \
  --tags "주간기술요약,AI,iOS,자동화,뉴스레터,2026" \
  --visibility public \
  --category 1219746
```
카테고리: AI 뉴스 (1219746) 또는 기타 (1219751)

### 6단계: 완료 알림
발행 결과(URL)를 주인님에게 텔레그램으로 전송.

## 상태 파일

- `memory/weekly_newsletter_data.json` — 수집 데이터
- `memory/weekly_newsletter_state.json` — 발행 이력

## 크론 설정

매주 일요일 11:00 KST 실행
```
0 11 * * 0
```

## 주의사항

- 이번 주에 새로운 뉴스가 너무 적으면 발행 스킵 (최소 AI 5건 이상)
- GitHub Trending HTML 파싱은 GitHub 구조 변경 시 깨질 수 있음 (폴백 있음)
- Tistory 쿠키 만료 시 발행 실패 — tistory-publisher 스킬의 트러블슈팅 참고
