---
name: weekly-tech-digest
description: 주간 기술 요약 뉴스레터 — AI/iOS/자동화 트렌드를 종합하여 Tistory에 자동 발행, ICBM2 인사이트 포함
version: 1.0.0
author: ICBM2
metadata:
  hermes:
    tags: [Newsletter, Weekly, Tistory, AI, iOS, Automation, Digest]
---

# ICBM2 주간 기술 요약 뉴스레터

## 개요

매주 일요일에 AI/iOS/자동화 트렌드를 종합하여 블로그 수준의 뉴스레터를 Tistory에 자동 발행합니다. ICBM2가 직접 작성한 아이디어 노트, Ship or Slop, 블로그 글 등의 인사이트도 포함합니다.

## 파이프라인

### 1단계: 데이터 수집 (스크립트)
```bash
python3 scripts/weekly_newsletter.py
```
수집 결과: `memory/weekly_newsletter_data.json`

수집 소스:
- **AI/ML**: AgentNews 피드 + Hacker News (AI/LLM/agent 관련)
- **iOS/Swift**: Hacker News + GitHub Trending (Swift)
- **자동화/도구**: Hacker News + GitHub Trending (Python)
- **ICBM2 인사이트**: blog_seo_history.json (이번 주 발행글) + notion_idea.md + shiporslop.md + botmadang.md

### 2단계: 뉴스레터 글 작성 (에이전트)

수집된 데이터를 바탕으로 뉴스레터를 작성합니다.

#### 글 구조
```
# [주간 기술 요약] 2026년 N주차 — AI · iOS · 자동화 트렌드

## 📋 이번 주 한눈에 보기
3-5줄 요약

## 🤖 AI/ML 트렌드
상위 5-7건, 각 항목:
- 제목 + 1-2줄 설명 + 링크
- 카테고리별로 insight/tool/infrastructure 구분

## 📱 iOS/Swift 소식
상위 3-5건

## 🔧 자동화 & 개발 도구
상위 3-5건

## 💡 ICBM2의 이번 주 인사이트
- 발행한 글 중 주목할 만한 것 2-3건 요약
- 아이디어 노트, Ship or Slop 활동 요약

## 🔮 다음 주 관전 포인트
2-3개 예측/전망
```

#### 작성 가이드라인
1. **한국어로 작성**, 전문적이면서 읽기 쉬운 톤
2. **본문 3000자 이상** (네임드 뉴스레터 품질)
3. 단순한 링크 나열이 아닌 **분석과 인사이트 포함**
4. 각 항목에 ICBM2의 **의견/해석**을 1문장 추가
5. 링크는 HTML `<a>` 태그로
6. 마크다운 → Tistory HTML로 변환하여 발행

### 3단계: SEO 최적화
```bash
python3 scripts/blog_seo_optimizer.py --file newsletter.md
```

### 4단계: 품질 검사
```bash
python3 scripts/blog_quality_gate.py --file newsletter.md
```
품질 등급 B 이상 통과 시 발행 진행.

### 5단계: Tistory 발행
```bash
python3 scripts/tistory_publisher.py \
  --title "제목" \
  --content "HTML 내용" \
  --tags "주간기술요약,AI,iOS,자동화,뉴스레터,2026" \
  --visibility public \
  --category 1219746
```
카테고리: AI 뉴스 (1219746) 또는 기타 (1219751)

### 6단계: 완료 알림
발행 결과(URL)를 주인님에게 텔레그램으로 전송.

## 상태 파일

- `memory/weekly_newsletter_data.json` — 수집 데이터
- `memory/weekly_newsletter_state.json` — 발행 이력

## 크론 설정

매주 일요일 11:00 KST 실행
```
0 11 * * 0
```

## 사전 체크 및 트러블슈팅

### Python 3.8 호환성 문제 (2026-05-03 발견)

`weekly_newsletter.py` 실행 시 `TypeError: 'type' object is not subscriptable` 오류가 발생하면:

**원인:** Python 3.8에서는 `tuple[str, str]` 문법을 지원하지 않음 (PEP 585 lowercase generics는 Python 3.9+). `typing.Tuple`을 사용해야 함.

**수정 방법:**
```bash
# 1. 타입 임포트 확인
from typing import Optional, Union, Dict, List, Any, Tuple

# 2. 파일 내 문제되는 타입 힌트 수정
sed -i '' 's/tuple\[/Tuple[/g' ~/.hermes/scripts/weekly_newsletter.py
sed -i '' 's/list\[/List[/g' ~/.hermes/scripts/weekly_newsletter.py
```

**주의:** `List[` 치환 시 `logging.FileHandler` 같은 `list` 파라미터는 영향 없음 (소문자 `list`는 함수 호출임). 대문자 `List[`만 치환 대상.

### CJK 문자 정제 — Markdown 작성 시 예방 + 변환 후 정제 (2단계)

CJK 혼입은 **마크다운 작성 단계에서 예방**하는 것이 변환 후 정제보다 효과적이다. 작성 중 한국어 텍스트 사이에 한자/일본어가 섞여 들어가는 패턴이 반복되어 왔음 (55차+ 정제 기록).

#### 단계 1: Markdown 작성 시 CJK 선검사 (2회차 필수)

```python
import re

with open('/tmp/newsletter.md', 'r') as f:
    md = f.read()

cjk = set(re.findall(r'[\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff]', md))
if cjk:
    print(f"⚠️ Markdown CJK 발견 (1차): {len(cjk)}자")
    # 1차 정제 — 제한적 사전
    limited = {}
    for old, new in comprehensive_dict.items():
        md = md.replace(old, new)
    # 2차 검사
    cjk2 = set(re.findall(r'[\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff]', md))
    if cjk2:
        print(f"⚠️ Markdown CJK 잔여 (2차): {len(cjk2)}자")
        # ⚠️ 제한적 사전 반복이 아닌 종합 사전으로 1회성 정제
        for old, new in comprehensive_dict.items():
            md = md.replace(old, new)
    with open('/tmp/newsletter.md', 'w') as f:
        f.write(md)
    print("✅ Markdown CJK 정제 완료")
else:
    print("✅ Markdown CJK 없음")
```

> **핵심 교훈:** 1차 정제 후 "완료"로 보여도 재검사하면 잔여가 반드시 있음. 반드시 2회차 검사 후 잔여 발견 시 **제한적 사전 반복이 아닌 종합 사전으로一口气 정제**. 2회차가 clean이면 HTML 변환 시 CJK 루프가 0회차로 바로 통과.

#### 단계 2: HTML 변환 후 CJK 정제 루프

`tistory-publisher` 스킬의 comprehensive CJK 사전을 사용한다. (이 skill의 inline dict는 불완전하므로 tistory-publisher 스킬의 최신 comprehensive dict를 반드시 참조할 것.)

**핵심 원칙:**
- `markdown_to_tistory_html.py` 변환 직후 **즉시** CJK 정제 실행
- 루프 안정화(`html == html_before`) 후에도 잔여가 발생할 수 있음 — 별도 2차 targeted 패치 실행
- Korean Hanja (U+CDF0 등)는 CJK regex [\u4e00-\u9fff] 밖이라 탐지 불가 → 종합 사전에 `'쾨': '쾌'` 같은 Korean Hanja 직접 치환 추가

### 뉴스 부족 시 발행 스킵

- 최소 AI 트렌드 5건 이상 필요
- 5건 미만 시 "이번 주 뉴스 부족으로 발행 스킵" 알리고 종료

### 품질 게이트 거짓 양성 패턴 — 뉴스레터 특이사항

`blog_quality_gate.py`의 유사도·시간 신선도 체크가 뉴스레터에서 오탐을 발생させる:

1. **89% 유사도 경고:** 뉴스레터는每周 구조가 동일하여 매번 "이전 글과 매우 유사" 경고가 발생. 이 경고는 **정상이며 무시해도 됨** (형식적 유사이지 콘텐츠 중복이 아님). Grade B 이상 통과 시 그대로 발행.

2. **2008/2012년 자료 경고:** Kevin Rose의 Digg 재런칭 기사를 다룰 때, 원래 Digg의 창업 연도(2008년), Craigslist 인수의 연도(2012년)를 역사적 맥락으로 언급하면 "구버전 자료" 경고가 발생. 이는 **역사적 비유로서의 사용이므로 정상** — blog_pipeline의 source_url이 2026년이고 기사 자체가 2026년 최신이면 경고는 페널티 없이 통과.

3. **인식된 오탐 패턴 목록 (누적):**
   - 역사적 타임라인/비유 기사: 과거 연도가 "타임라인" 맥락으로 사용됨
   - IE/Web 역사적 비유: "Internet Explorer 시절", "2000년대" 등
   - 중간 election 관련 자료: 2026 election에서 AI/Crypto가 dirty words가 되는 구조적 분석

## 주의사항

- GitHub Trending HTML 파싱은 GitHub 구조 변경 시 깨질 수 있음 (폴백 있음)
- Tistory 쿠키 만료 시 발행 실패 — tistory-publisher 스킬의 트러블슈팅 참고

### 뉴스레터 특화 CJK 정제 파이프라인 (HTML 직접 작성 시)

뉴스레터는 Markdown을 거치지 않고 **HTML을 직접 작성**하므로, `markdown_to_tistory_html.py` 변환 단계가 없다. CJK 정제는 HTML 파일에서 **1회 passes**로 진행한다.

```python
import re

with open('/tmp/newsletter_w21.html', 'r') as f:
    html = f.read()

cjk = set(re.findall(r'[\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff]', html))
print(f"CJK 발견: {len(cjk)}개 — {cjk}")
if cjk:
    replacements = {
        '习': '', '定': '정', '追': '쫓아', '作': '작', '了': '료',
        '得': '득', '后': '후', '注': '주', '赛': '새', '成': '성',
        '回': '회', '的': '적', '关': '관', '熟': '숙', '新': '신',
        '教': '교', '训': '훈', '报': '보', '才': '재', '来': '래',
        '速': '속', '道': '도', '每': '매', '加': '가', '值': '치',
        '周': '주', '学': '학', '着': '착', '赶': '쫓아',
    }
    for old, new in replacements.items():
        html = html.replace(old, new)
    with open('/tmp/newsletter_w21.html', 'w') as f:
        f.write(html)
    print("✅ CJK 정제 완료")
```

### blog_seo_history.json 읽기 — terminal 파이핑 주의

```bash
# ❌ 보안 스캔 차단: cat | python3 파이프라인
cat ~/.hermes/memory/blog_seo_history.json | python3 -c "..."

# ✅ execute_code 사용 (파이프라인 대신)
python3 -c "
import json
with open('/Users/hjshin/.hermes/memory/blog_seo_history.json') as f:
    data = json.load(f)
for p in data['posts'][-5:]:
    print(p['title'])
"
```

### Korean text corruption vs Valid Hangul 식별법

CJK cleaning 중 "이것은CJK인가?" 판단이 필요한 경우, Unicode code point로 확인할 것:

```python
for c in suspicious_string:
    code = ord(c)
    print(f"{c} → U+{code:04X}", end=" ")
    if 0xAC00 <= code <= 0xD7A3:  # 한글 음절 (가-힣)
        print("(✅ Valid Korean Hangul)")
    elif 0x4E00 <= code <= 0x9FFF:  # CJK 통합 한자
        print("(⚠️ CJK Hanja)")
    elif 0x3040 <= code <= 0x30FF:  # Japanese
        print("(⚠️ Japanese)")
```

**실제 사례 (2026-W21):** `"시큐리티새도"` 중 `새(U+C0C8)`, `도(U+B3C4)`는 모두 U+AC00–U+D7A3 범위 → **유효한 한글**. CJK regex `\u4e00-\u9fff`에マッチ하지만 실제로는 한글 음절이므로 corruption이 아님. 반드시 Unicode code point로 확인할 것.
