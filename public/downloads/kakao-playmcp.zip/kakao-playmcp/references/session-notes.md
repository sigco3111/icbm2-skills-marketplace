# PlayMCP mcp-gateway — Live session trace

Session date: 2026-07-14
mcporter version: 0.12.3
OTT used: `3593f61d99d0ec6a234376c4ee9c5a2ba6b58b5c6cfa0f8311934bd56fe028a6` (single-use, spent)

## What worked

1. `bun add -g mcporter` → installed 0.12.3 at `~/.bun/bin/mcporter`. PATH not auto-set; had to `export PATH="$HOME/.bun/bin:$PATH"`.
2. `mcporter config add mcp-gateway https://playmcp.kakao.com/mcp --auth oauth --scope home` → wrote `~/.mcporter/mcporter.json` with `{"mcpServers":{"mcp-gateway":{"baseUrl":"https://playmcp.kakao.com/mcp","auth":"oauth"}}}`.
3. `curl -X POST https://playmcp.kakao.com/api/v1/auths/otts:exchange` → HTTP 200, returned access + refresh token.
4. `mcporter list mcp-gateway --output json` → status `"auth"`, issue statusCode 401, rawMessage `"Streamable HTTP error: Error POSTing to endpoint:"`.

## What blocked completion

After hand-writing `~/.mcporter/credentials.json` per the upstream guide's schema (`{version, entries: {"mcp-gateway|<hash>": {tokens, clientInfo, updatedAt}}}`), mcporter still returned 401. The hash was computed correctly (`92ef5a9fd655a681` from `printf '{"name":"mcp-gateway","url":"https://playmcp.kakao.com/mcp","command":null}' | shasum -a 256 | cut -c1-16`), and Bearer header was present. The guide's `credentials.json` schema is not what mcporter 0.12.x's vault expects.

Verified by `curl -i -X POST https://playmcp.kakao.com/mcp -H "Authorization: Bearer <access>" -d '{"jsonrpc":"2.0","id":1,"method":"initialize",...}'` — also returned 401. So either:
- The token audience doesn't match (token was for `https://playauth.kakao.com/playmcp`, accepted only at `https://playmcp.kakao.com/mcp` per `/.well-known/oauth-protected-resource/mcp`).
- The token was rejected for some other reason.

The exact mechanism was not resolved before OTT expired — session ended on a `vault set` recommendation that the user did not act on before pausing.

## Key evidence to keep

- Protected resource metadata:
  ```
  GET https://playmcp.kakao.com/.well-known/oauth-protected-resource/mcp
  → {"resource":"https://playmcp.kakao.com/mcp","authorization_servers":["https://playauth.kakao.com/playmcp"],"bearer_methods_supported":["header"]}
  ```
- WWW-Authenticate header on a 401 from the resource:
  ```
  www-authenticate: Bearer resource_metadata="https://playmcp.kakao.com/.well-known/oauth-protected-resource/mcp"
  ```
- OTT single-use error response:
  ```json
  {"code":"ERR-CHAT-90400","message":"유효하지 않거나 만료된 One Time Token입니다."}
  ```
- mcporter 0.12.3 `--help` exposes `vault set <server> --tokens-file <path>` — this is the path forward that was NOT taken in this session.

## Re-entry checklist for next session

1. Ask user for a fresh OTT from the toolbox.
2. Run `mcporter auth mcp-gateway --reset` first (clears any half-written vault state from this session).
3. Use `mcporter vault set mcp-gateway --tokens-file <tokens.json>` with the minimal `{access_token, token_type, refresh_token}` shape.
4. Verify with `mcporter list mcp-gateway --output json` — expect status `"ok"` and a non-empty `tools[]`.
5. If still `"auth"`, dump `~/.mcporter/` and `mcporter config list` to see where mcporter actually looked.