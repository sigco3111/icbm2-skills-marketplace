# MCP-Creator — Live session trace

Session date: 2026-07-14
mcporter version: 0.12.3
Test idea: PlayMCP game recommendation hub (18-game static catalog, 5 tools)

## What worked end-to-end

1. OTT exchange → access+refresh tokens → `mcporter vault set` (existing flow, see session-notes.md)
2. `mcporter list mcp-gateway --output json` → 34 tools exposed, including `mcpcreator.*` namespace (7 tools).
3. Discovered `MCP-Creator` as a registered PlayMCP server (id `69453941867372451`) — no separate install needed.
4. `mcporter call mcp-gateway.mcpcreator-create_mcp_server spec_text=<v1> name=playmcp-game-hub --output json` → got `owner_token`, `job_id=fb223baa...`, dashboard URLs.

## What failed and why

### Failure 1 — structural validation
- `get_job_status` after 35s: `generated spec failed structural validation: tools.0.response.fieldSelectors.N.path: Invalid string: must match pattern ^(\[\d+\]|[A-Za-z0-9_]+)(\.[A-Za-z0-9_]+|\[\d+\])*$`
- **Root cause**: spec used Korean field names (`이름`, `한줄`, `추천이유`) in the response shape. Validator regex rejects them.
- **Fix**: rewrote spec with explicit ASCII snake_case field names (`server_id`, `oneliner`, `recommendations`). Korean kept only in `oneliner` description strings.

### Failure 2 — LLM regression after fix
- v2 spec passed validation but produced 3 Wikipedia tools (`search_wikipedia`, `get_wikipedia_summary`, `get_random_wikipedia_article`) instead of the requested 5 game-hub tools.
- Tool naming artifact: `get_playmcp_18_mcp_18` (the LLM invented a tool trying to call 18 PlayMCP servers live).
- **Root cause**: spec asked Creator to "leverage PlayMCP API live", which the LLM can't actually do, so it fell back to its built-in safe default.

### Failure 3 — refine didn't help
- `refine_mcp_server` with "COMPLETELY REPLACE all existing tools. Do NOT use Wikipedia" → same result. LLM ignored the directive.

## Working solution (recommended, not yet verified)

Static catalog hardcoded into tool responses. State explicitly in the spec:
> "This server does NOT call any external live API. It uses a hardcoded catalog of N entries as static data baked into the tool responses."

Even with this fix attempted, **the LLM still regressed to Wikipedia tools**. The session ended without achieving the full 5-tool game hub. Recommended next steps (not yet executed):
- Try a single-tool spec first to confirm the static-catalog approach works
- Then incrementally `refine` to add tools one at a time
- Always verify with `mcporter list <name>` after each cycle

## Owner / token notes

- `owner_token` issued on first `create_mcp_server` call:
  `rTGXCxKzt3wWxN2r2gY-30zp1E-wfjQuLicZeNcbCtw.9208093bad95b3e41961da112454a8ebef52aa27bc1ba3379cd7e05b2454f7cd`
- Format: `<base64-ish>.<64-hex>` — the second part is rotated on every dashboard token issuance
- Reuse across create/refine/list/delete calls to keep all servers under one account
- After this session: **2 servers** under the owner:
  - `f8d14f8b-7ccb-4ecd-b607-e38cfcec26f7` — `active` (Wikipedia tools, live at `playmcp-game-hub-2b4cff`)
  - `ed3fd741-ffe0-4fb6-823c-b7380b67d93a` — `failed` (v1 attempt, slug `playmcp-game-hub`)
- To clean up later: `mcporter call mcp-gateway.mcpcreator-delete_server server_id=<ID> owner_token=<TOKEN>`

## mcporter-via-subprocess pitfall

When calling `mcporter` from inside `execute_code` (Python subprocess), the binary is **not on default $PATH** because `bun add -g` installs to `~/.bun/bin/`. Symptom:

```
FileNotFoundError: [Errno 2] No such file or directory: 'mcporter'
```

Fix: use absolute path `/Users/mac/.bun/bin/mcporter`. Same applies to other bun-global CLIs (`gjc`, `mmx`).

```python
MCPORTER = "/Users/mac/.bun/bin/mcporter"
subprocess.run([MCPORTER, "list", "mcp-gateway", "--output", "json"], ...)
```

## Open question for next session

Is there a way to **force** the Creator LLM to honor the spec instead of regressing to Wikipedia? Possible angles:
- Explicit `endpoint_descriptor` with a hand-written OpenAPI snippet (instead of `spec_text`)
- Very short, very imperative spec ("ONLY 2 tools. Tool 1 name MUST be X. Tool 2 name MUST be Y. NOTHING ELSE.")
- Repeated negative examples ("DO NOT include Wikipedia tools, weather tools, search tools, or any tool not in the list above")
