# MCP-Creator spec_text template

Copy and customize. Field names MUST be ASCII snake_case. Korean only in description strings.

## Single-tool template (highest success rate)

```text
Create a single-tool MCP server named "<SERVER_NAME>" with this EXACT specification.

TOOL 1 (the ONLY tool):
- name: <tool_name>
- description: <one-line in Korean or English>
- input: <param_name> (<type>, required/optional) — <description in Korean OK>
- response: { <field_a>: <type>, <field_b>: <type> }

EXAMPLE:
- Input: <param_name>="<sample>"
- Output: { "<field_a>": "<value>", "<field_b>": "<value>" }

VALIDATION REQUIREMENTS:
- response field names MUST match ^[a-z][a-z0-9_]*$
- field paths must use only [A-Za-z0-9_] and dots
- exactly 1 tool, no others
- no external API calls

DO NOT:
- do NOT add Wikipedia tools, weather tools, search tools, or any tool not listed above
- do NOT use Korean characters in field names
- do NOT call any external HTTP API
```

## Multi-tool template (lower success rate — try single first)

```text
Create a PlayMCP MCP server named "<SERVER_NAME>". This server uses a HARD-CODED static catalog — it does NOT call any external live API.

CATALOG (use these N entries as static data baked into tool responses):
1. { server_id: "id1", name: "이름1", category: "cat1", field_x: ..., field_y: ... }
2. { server_id: "id2", name: "이름2", category: "cat2", field_x: ..., field_y: ... }
[N entries total]

TOOLS (exactly N tools — no more, no less):

TOOL 1: <tool_1_name>
- input: <param1> (string, optional), <param2> (string, optional)
- response: { games: array of { server_id, name, category, duration_min, difficulty, oneliner, call_example } }

TOOL 2: <tool_2_name>
- input: <query> (string, required)
- response: { recommendations: array of { server_id, name, oneliner, reason, call_example } }

[... one tool per paragraph, name + 1-line schema each ...]

VALIDATION REQUIREMENTS:
- All response field names MUST be ASCII snake_case (server_id, duration_min, call_example, recommendations, games, example_calls, input_complexity)
- Field paths use only [A-Za-z0-9_] and dots — NEVER Korean characters, spaces, or hyphens in field names
- Korean characters ALLOWED only in: description strings, oneliner values, category labels displayed to user
- Hardcode the catalog data — do NOT call any external HTTP API

DO NOT:
- do NOT include Wikipedia tools
- do NOT include search_wikipedia, get_wikipedia_summary, get_random_wikipedia_article
- do NOT include weather, search, or any tool not listed above
- do NOT call PlayMCP API live
```

## Refine template (when refine ignored your spec)

```text
COMPLETELY REPLACE all existing tools. Delete every tool currently exposed.
Do NOT keep search_wikipedia, get_wikipedia_summary, get_random_wikipedia_article or any other Wikipedia tool.
Do NOT use Wikipedia, weather, search, or any external API.

Build exactly N tools, all responses from the static catalog below (NO external HTTP calls):

TOOL 1 (EXACT name): <tool_1_name>
  input: <params>
  response: { <field>: <type>, ... }

TOOL 2 (EXACT name): <tool_2_name>
  input: <params>
  response: { <field>: <type>, ... }

[... one tool per paragraph ...]

CATALOG: <hardcoded data>

VALIDATION:
- field names ASCII snake_case only
- paths match ^[A-Za-z0-9_]+(\.[A-Za-z0-9_]+|\[\d+\])*$
- exactly N tools total
```

## Call command

```bash
/Users/mac/.bun/bin/mcporter call mcp-gateway.mcpcreator-create_mcp_server \
  spec_text="$(cat spec.md)" \
  name="<server-name>" \
  --output json
```

## Polling command

```bash
/Users/mac/.bun/bin/mcporter call mcp-gateway.mcpcreator-get_job_status \
  job_id=<JOB_ID> \
  --output json
```

Wait ~30s, then poll. No push notification — you must poll.

## Verification command

```bash
/Users/mac/.bun/bin/mcporter config add <server-name> <PUBLIC_URL> --auth none --scope home
/Users/mac/.bun/bin/mcporter list <server-name> --output json
```

**Always inspect `tools[]` count and names** — Creator's "✅ 배포 완료" message can be misleading if LLM regressed.
