---
name: kakao-playmcp
description: Connect external AI agents to the Kakao PlayMCP gateway (https://playmcp.kakao.com/mcp) using the OTT → access-token exchange flow and mcporter as the local MCP client. Use when the user mentions "PlayMCP", "mcp-gateway", "Kakao MCP gateway", "OpenClaw 연결", "PlayMCP 도구함", or hands you a oneTimeToken (OTT) value to wire their toolbox into your agent.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [mcp, oauth, ott, kakao, playmcp, mcporter]
    related_skills: [mcporter]
prerequisites:
  commands: [mcporter, bun, curl]
---

# Kakao PlayMCP Gateway — Agent Connection

Connect an external AI agent to Kakao's PlayMCP gateway so the user's toolbox (up to 10 MCP servers selected at https://playmcp.kakao.com/toolbox) is reachable from the agent's tool surface.

## When to use

- User provides an **oneTimeToken** (OTT) in chat, often labelled `oneTimeToken: <hex>` — this is the trigger.
- User mentions "OpenClaw 연결", "PlayMCP 연결", "mcp-gateway 붙여줘", or wants to call any Kakao-registered MCP server from their agent.
- User wants to **verify** an existing PlayMCP connection (token still valid, toolbox tools still listed).

## Architecture (read this once)

```
PlayMCP website                  PlayMCP API                  MCP Gateway
┌──────────────────┐    OTT     ┌──────────────────┐         ┌──────────────┐
│ Toolbox (user)   │ ─────────▶ │ otts:exchange    │ ──────▶ │ /mcp         │
│ "OpenClaw 연결"  │            │ → access+refresh │ Bearer  │ (OAuth 2.1   │
└──────────────────┘            └──────────────────┘         │  protected   │
                                                             │  resource)   │
                                                             └──────────────┘
                                                                     ▲
                                                                     │ Bearer
                                                                     │
                                                          ┌──────────────────┐
                                                          │ Local MCP client │
                                                          │ (mcporter)       │
                                                          └──────────────────┘
```

- **OTT**: single-use token from "OpenClaw와 연결" button in the Toolbox. Expires after one exchange.
- **access/refresh tokens**: OAuth2 from `https://playauth.kakao.com/playmcp`. Access expires in ~12h, refresh in ~3 months.
- **Protected resource**: `https://playmcp.kakao.com/mcp` advertises its issuer at `/.well-known/oauth-protected-resource/mcp`.

## Connection workflow (8 steps)

### 1. Detect or request OTT

If the user's message already contains `oneTimeToken: <hex>`, skip steps 2–3 and start at step 4. Otherwise, ask the user to:
1. Log in at https://playmcp.kakao.com
2. Go to https://playmcp.kakao.com/toolbox
3. Click **"OpenClaw와 연결"**, copy the resulting prompt, paste it back

### 2. Install mcporter (if missing)

```bash
export PATH="$HOME/.bun/bin:$PATH"
command -v mcporter || bun add -g mcporter
command -v mcporter || echo "ABORT: mcporter install failed"
```

### 3. Register the gateway server

```bash
mcporter config add mcp-gateway https://playmcp.kakao.com/mcp --auth oauth --scope home
```

This writes `~/.mcporter/mcporter.json`. Result should mention `~/.mcporter/mcporter.json` (system config), not a project-local `./config/mcporter.json`.

### 4. Exchange OTT for tokens (ONE SHOT — OTT is single-use)

```bash
curl -sS -X POST 'https://playmcp.kakao.com/api/v1/auths/otts:exchange' \
  -H 'accept: */*' -H 'Content-Type: application/json' \
  -d '{"tokenValue":"<OTT>"}'
```

Response shape:
```json
{
  "accessToken":  {"tokenValue": "<JWT>", "expiresAt": "<ISO>"},
  "refreshToken": {"tokenValue": "<opaque>", "expiresAt": "<ISO>"}
}
```

If response is `{"code":"ERR-CHAT-90400","message":"유효하지 않거나 만료된 One Time Token입니다."}`: **the OTT is already spent**. Stop and ask the user for a fresh one from the toolbox UI.

### 5. Inject tokens into mcporter vault (mcporter 0.12.x)

DO NOT hand-write `~/.mcporter/credentials.json` — that schema (with `version`/`entries`/`clientInfo`) is from older mcporter versions and mcporter 0.12.x will not pick it up, leaving you with a 401. Use `vault set`:

```bash
# Build the tokens JSON file mcporter actually expects
cat > /tmp/playmcp-tokens.json <<EOF
{
  "access_token":  "<accessToken.tokenValue>",
  "token_type":    "Bearer",
  "refresh_token": "<refreshToken.tokenValue>"
}
EOF
chmod 600 /tmp/playmcp-tokens.json

mcporter vault set mcp-gateway --tokens-file /tmp/playmcp-tokens.json
rm -f /tmp/playmcp-tokens.json
```

### 6. Verify connection

```bash
mcporter list mcp-gateway --output json
```

Expected on success:
```json
{
  "name": "mcp-gateway",
  "status": "ok",
  "transport": "HTTP https://playmcp.kakao.com/mcp",
  "tools": [...]
}
```

Expected on failure (means step 5 didn't take):
```json
{
  "status": "auth",
  "issue": {"statusCode": 401, "rawMessage": "Streamable HTTP error..."}
}
```

If `auth` → re-run step 5 with `mcporter auth mcp-gateway --reset` first, then `vault set`.

### 7. Inspect tools (optional)

```bash
mcporter list mcp-gateway --schema   # full JSON schema for each tool
mcporter call mcp-gateway.<tool> key=value --output json
```

### 8. Hand off to the user

Report:
- Number of tools exposed
- 1-line sample call so the user can confirm in their own chat
- Token expiry (`accessToken.expiresAt`) — note that mcporter 0.12.x does NOT auto-refresh; user must re-run step 5 when access token expires, OR set up a refresh-token aware client

## Pitfalls (read before starting)

- **OTT is single-use.** Calling the exchange endpoint twice → second call returns `ERR-CHAT-90400`. Plan: collect the OTT, the desired mcporter config, the user info, etc. **before** the first call.
- **The hand-written credentials.json in the docs is misleading.** It looks authoritative but is the schema from a previous mcporter version. mcporter 0.12.x's vault ignores it. Always use `vault set`.
- **`mcporter config add ... --scope home` is required**, not optional. Without it the config may land in `./config/mcporter.json` (project-local) instead of `~/.mcporter/mcporter.json` (system-wide), breaking later commands run from other directories.
- **Bun PATH gotcha.** `bun add -g` installs to `~/.bun/bin/` which is not on `$PATH` by default. `mcporter` will appear "not installed" until you `export PATH="$HOME/.bun/bin:$PATH"` for the session, or append it to `~/.zshrc`.
- **mcporter 0.12.x does not auto-refresh.** When the access token expires (typically ~12h), `mcporter list` returns 401 again and you must re-run step 5 manually. There is no `mcporter vault refresh` command yet.
- **Cross-audience token rejection.** The tokens are issued for `https://playauth.kakao.com/playmcp` and only accepted on the `https://playmcp.kakao.com/mcp` resource. Don't try to use them against any other Kakao API.
- **The toolbox catalog is narrow — check it before assuming.** As of 2026-07-14 the verified `mcp-gateway` exposes only two non-trivial user-selectable tools: `worldagentcraft-*` (15 tools, the "World of AgentCraft" sandbox game — see `worldagentcraft-game_guide` for the full rulebook) and `KakaotalkChat-MemoChat` (send a message to myself). Other categories like parking (`findParking-search_parking_by_place`, `findParking-search_realtime_parking`, `findParking-search_ev_chargers_near_place`) require the user to add them to their toolbox at https://playmcp.kakao.com/toolbox first — DO NOT assume any product/utility/game tools are pre-loaded. When the user asks "what can I do via PlayMCP?" the honest answer is: enumerate via `mcporter list mcp-gateway --output json` and report only what's actually there. If the user wants agents/games/MCP servers beyond World of AgentCraft, they need to add them to their toolbox; see `mcp/mcporter` for ad-hoc MCP server connection without pre-registration.

## When to stop and ask

- User has not logged into PlayMCP → can't generate an OTT.
- OTT exchange returns `ERR-CHAT-90400` → OTT already used. Ask for a fresh one.
- `mcporter list` returns 401 after a clean `vault set` → token may have been issued for a different user / session. Ask user to regenerate from the toolbox UI.

## Reference

- Full upstream guide (Korean): https://playmcp.kakao.com/llms/mcp-connection-guide.md
- Index: https://playmcp.kakao.com/llms.txt
- Resource metadata: `https://playmcp.kakao.com/.well-known/oauth-protected-resource/mcp`
- Authorization server: `https://playauth.kakao.com/playmcp`
- See `references/session-notes.md` for live verification trace (2026-07-14, mcporter 0.12.3).
- See `references/mcp-creator.md` for MCP-Creator end-to-end workflow + LLM-regression pitfalls (verified 2026-07-14).
- See `templates/mcp-creator-spec.md` for a copy-paste-ready spec_text template that survives structural validation.

---

# MCP-Creator (server build flow)

MCP-Creator (PlayMCP server id `69453941867372451`) **generates new MCP servers from natural language**. It is exposed through `mcp-gateway` like any other toolbox server (7 tools under `mcpcreator.*`, no separate auth).

## When to use

- User wants to **create their own MCP server** ("이런 기능 있었으면 좋겠어 한 줄이면 끝").
- User wants to **modify or delete** a server previously created via MCP-Creator.
- User wants a dashboard link to manage their generated servers.

## The 7 tools (`mcpcreator.*` namespace)

| Tool | Required arg | Returns |
|---|---|---|
| `create_mcp_server` | `spec_text` | job_id + dashboard URLs + **`owner_token`** (one-time per session) |
| `get_job_status` | `job_id` | stage (`building` → `validated` → `deployed`) or failure reason |
| `list_my_servers` | (none) or `status` filter | table of user's servers |
| `get_server_details` | `server_id` | public URL, tool list, latency, deploy ref |
| `refine_mcp_server` | `server_id`, `spec_text` | new job_id (rebuild) |
| `delete_server` | `server_id` | enqueues teardown |
| `get_dashboard_link` | (none) or `server_id` | web dashboard URL |

All except `get_server_details` accept an optional `owner_token` argument.

## Workflow (8 steps)

### 1. Confirm the idea in one sentence
Hint: **single-tool ideas succeed most**. Multi-tool specs (5+ tools) have a high LLM-regression rate — see pitfall P1.

### 2. Write a structured `spec_text`
Use `templates/mcp-creator-spec.md`. Three absolute rules (verified 2026-07-14):
- **R1** — All response field names MUST be ASCII `[A-Za-z0-9_]+` separated by `.` or `[N]`. Korean characters, spaces, hyphens → **structural validation fails** with regex `^(\[\d+\]|[A-Za-z0-9_]+)(\.[A-Za-z0-9_]+|\[\d+\])*$`. Korean in `description` / `oneliner` is fine.
- **R2** — Spell out the exact tool name AND a one-line schema for each. LLM ignores vague instructions like "list games".
- **R3** — If the spec involves "calling other PlayMCP servers", **hardcode the data as a static catalog** instead. The LLM will otherwise invent impossible tool names (e.g. `get_playmcp_18_mcp_18`) and fail with "upstream unreachable".

### 3. `create_mcp_server` — first call (gets owner_token)
```bash
mcporter call mcp-gateway.mcpcreator-create_mcp_server \
  spec_text="<structured spec>" name="<server-name>" --output json
```
Response contains `owner_token`. **Save it immediately** — without it, later calls won't recognize you as the same owner.

### 4. Poll `get_job_status` after ~30s
```bash
mcporter call mcp-gateway.mcpcreator-get_job_status job_id=<JOB_ID> --output json
```
Typical cycle: building → validated → deployed in 20–40s. **No push notification** — you must poll.

### 5. Verify with `mcporter list <name>`
```bash
mcporter config add <server-name> <PUBLIC_URL> --auth none --scope home
mcporter list <server-name> --output json
```
**Always inspect actual tools** — never trust the dashboard claim. See P1.

### 6. If tools don't match spec → `refine_mcp_server`
Same pipeline as create. Begin the refine spec with "COMPLETELY REPLACE all existing tools. Delete all current tools. Do NOT use Wikipedia." to fight regression.

### 7. Pass `owner_token` on every subsequent call
```bash
mcporter call mcp-gateway.mcpcreator-refine_mcp_server \
  server_id=<ID> spec_text="..." owner_token=<TOKEN> --output json
```

### 8. Hand off
Public URL (Streamable HTTP) is reachable without re-doing OTT exchange. Claude Desktop / Cursor / ChatGPT can connect directly. Dashboard URL lets the user manage or delete later.

## Pitfalls (verified live 2026-07-14)

### P1. LLM regression to "safe default"
**Symptom**: `create_mcp_server` returns "✅ 배포 완료" but the actual tools exposed are `search_wikipedia`, `get_wikipedia_summary`, `get_random_wikipedia_article` — regardless of what your spec asked for. `refine_mcp_server` exhibits the same regression.
**Why**: Creator's LLM maps your spec to its built-in safe template when the spec is too complex, too vague, or asks for tools it can't easily synthesize.
**Fix**:
- Keep first spec **≤ 2 tools** with narrow scope.
- For larger hubs, begin the refine spec with "COMPLETELY REPLACE all existing tools. Do NOT use Wikipedia."
- **Always verify** with `mcporter list <name>` after each cycle.

### P2. Korean field name → structural validation fails
**Symptom**: `get_job_status` returns `generated spec failed structural validation: tools.0.response.fieldSelectors.N.path: Invalid string: must match pattern ...`
**Why**: The validator enforces the ASCII regex (see R1). Korean, hyphens, spaces all fail.
**Fix**: Field names = English snake_case. Korean belongs only in `description` strings.

### P3. Upstream unreachable (cross-MCP calls)
**Symptom**: `tool "get_X": upstream unreachable after retries — Upstream request failed`
**Why**: Your spec asks the Creator to call another PlayMCP server live. The LLM invents fake tool names which don't exist upstream.
**Fix**: Hardcode any cross-MCP data as a **static catalog**. State explicitly: "This server does NOT call any external live API."

### P4. owner_token loss
**Symptom**: `list_my_servers` returns empty even though you just created one.
**Fix**: Save the owner_token from the first `create_mcp_server` response (format: `<base64-ish>.<64-hex>`) and pass it to every later call.

### P5. No completion push
**Symptom**: Agent said "잠시 후 알려드리겠다" but never followed up.
**Fix**: Always poll. The Creator explicitly instructs the agent: "예고하지 마세요 — 생성 완료는 push 알림이 없습니다."

### P6. mcporter not in subprocess PATH
**Symptom**: `execute_code` → `subprocess.run(["mcporter", ...])` → `FileNotFoundError`.
**Why**: `bun add -g` puts the binary at `~/.bun/bin/mcporter`, not on default `$PATH`.
**Fix**: Use absolute path `/Users/mac/.bun/bin/mcporter`. Same applies to `gjc`, `mmx`, and any other bun-global install.

## Spec writing — what works

A spec that survives both structural validation AND LLM regression needs:
1. Numbered tools, each with `name + 1-line schema + required fields + response shape (field names spelled out explicitly)`
2. A "VALIDATION REQUIREMENTS" section restating the ASCII snake_case rule
3. A "DO NOT" section listing what the LLM must not do (use Wikipedia, call live APIs, use Korean field names)
4. For multi-tool servers: a "COMPLETELY REPLACE existing tools" directive at the top of any refine spec
5. Korean only in description strings — never in field names, paths, or identifiers

Full template: `templates/mcp-creator-spec.md`. Reference session trace: `references/mcp-creator.md`.