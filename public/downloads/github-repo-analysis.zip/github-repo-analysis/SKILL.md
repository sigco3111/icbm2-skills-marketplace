---
name: github-repo-analysis
description: Analyze a GitHub repo and generate Korean README.
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [macos, linux, windows]
metadata:
  hermes:
    tags: [github, analysis, readme, korean]
    related_skills: [writing-plans]
---

# GitHub Repository Analysis & Korean README Generation

## Overview
This skill automates taking a GitHub repository (public or private with a PAT), extracting its structure, assets, and key documentation, and drafting a comprehensive Korean `README_KR.md`.

## Pitfalls
- **Git LFS**: Repositories using large file storage need `git lfs install` and `git lfs pull` after cloning.
- **Shallow clone** (`--depth 1`) omits LFS binaries; use a full clone when assets are required.
- **Private repos** require a personal access token with `repo` scope.

## Steps
1. **Prepare environment**
   ```bash
   git lfs install   # ensure LFS support
   ```
2. **Clone the repository**
   - Public:
     ```bash
     git clone --depth 1 <repo_url> /tmp/<repo-name>
     ```
   - Private (PAT in env `GITHUB_PAT`):
     ```bash
     git clone --depth 1 https://${GITHUB_PAT}@github.com/<owner>/<repo>.git /tmp/<repo-name>
     ```
3. **Pull LFS assets (if any)**
   ```bash
   cd /tmp/<repo-name>
   git lfs pull
   ```
4. **Collect top‑level docs** (`README.md`, `LICENSE`, `ARCHITECTURE.md`, `SECURITY.md`, `CONTRIBUTING.md`).
5. **List major directories and summarize purpose** (e.g., `Assets/`, `Packages/`, `Logos/`).
6. **For Unity projects, detect missing commercial assets** by scanning `Assets/Plugins/` and `Assets/ThirdPartyResources/` and produce a table.
7. **Draft Korean README (`README_KR.md`)** with sections:
   - 프로젝트 개요
   - 라이선스
   - Unity 버전 및 필요 에셋 복구
   - 빌드·실행 방법
   - 기여 가이드
   - 참고: `references/<repo-name>.md`
8. **Save the README** in the repo root.
9. **Create reference analysis** `references/<repo-name>.md` containing raw directory list, asset table, and licensing notes.
10. **(Optional) Commit & push** if the user has write access.

## Output
- `README_KR.md` placed at repository root.
- `references/<repo-name>.md` with raw analysis for future reuse.

## Example Reference File (`references/piratenation-analysis.md`)
```markdown
# Pirate Nation Repository Analysis

## piratenation-art
- Files: 154 280 total, many tracked via Git LFS (PNG, MP4, etc.)
- License: CC0 1.0 Universal
- Key folders: `Combat Cards/`, `Founder's Pirate NFT/`, `Logos/`, `Voxel Game Assets/`

## piratenation-game
- Unity project (Unity 2022.3.51f1 LTS)
- License: MIT (code) + CC0 (art)
- Important docs: `README.md`, `ARCHITECTURE.md`, `SECURITY.md`, `CONTRIBUTING.md`
- Missing commercial Unity assets listed in table (see analysis).
```
---