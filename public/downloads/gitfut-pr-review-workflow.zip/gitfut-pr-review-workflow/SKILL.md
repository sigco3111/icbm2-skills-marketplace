---
name: gitfut-pr-review-workflow
description: Use when building sigco3111 GitFut PR queue.
---

# gitfut-pr-review-workflow

sigco3111 GitFut 카드(OVR 70, DEF 47) **DEF 점수 끌어올리기 전용** 워크플로우.
검증된 `gh` 명령 + 초보자 안전 가이드 + 거절 안전성 사실.

> ⚠️ **선행 스킬:** `gitfut-growth`(사용자 소유, outdated)는 background curator가 패치 불가. 이 스킬은 그 outdated 워크플로우의 **실제 작동하는 대체 구현**. 두 스킬은 같은 도메인이라 curator 합병 권장 — `hermes curator adopt gitfut-growth` → `gitfut-growth`에 본 스킬 내용 통합 권장.

## 1. GitFut 점수 메커니즘 (검증 사실)

GitFut 엔진은 **상호작용의 양**을 측정, **결과(승인/거절)를 측정하지 않음**:

| 메트릭 | 카운트 기준 | 거절 영향 |
|---|---|---|
| **Reviews** (DEF 주) | PR에 남긴 **댓글/리뷰 개수** | ❌ 무관 |
| **Comments** | 작성한 **총 댓글 수** | ❌ 무관 |
| **Active days** | 깃허브 **활동 일수** | ❌ 무관 |
| **Issues opened** (DEF 부) | 연 **이슈 수** | ❌ 무관 |
| **Pull requests** (PAS) | 연 **PR 수** | ⚠️ merged만 (리뷰와 별개) |

**핵심 안전 사실:**
- "Why?" 질문만 해도 Reviews +1 카운트 → DEF +0.1~0.2pt
- 거절/무시/승인 모두 동일하게 카운트
- **응답 없음 ≠ 거절 = 정상**. PR 100개 중 30-50% 응답률
- 메인테이너 답변 시 "알겠습니다 👍" → +2 카운트 (대화 길어질수록 누적)

## 2. 주간 PR 큐 생성 워크플로우 (검증됨, 2026-08-03 실측)

### Step 1: 데이터 수집

```bash
mkdir -p /tmp/gitfut-data
TODAY_MINUS_7=$(date -v-7d '+%Y-%m-%d')  # macOS. Linux: date -d '7 days ago' '+%Y-%m-%d'

# 5개 레포 — 라벨 필터 없이 (라벨 필터는 0 PR 되는 경우 많음)
for repo in anomalyco/opencode code-yeongyu/oh-my-openagent NousResearch/hermes-agent anomalyco/models.dev junhoyeo/tokscale; do
  safe_name=$(echo "$repo" | tr '/' '-')
  gh api "search/issues?q=is:open+is:pr+repo:${repo}+comments:0..3+created:>${TODAY_MINUS_7}&per_page=10" \
    --jq '.items[] | {n: .number, t: .title, u: .html_url, u2: .user.login, c: .comments, lab: [.labels[].name], d: .created_at}' \
    > "/tmp/gitfut-data/${safe_name}.json"
done
```

### Step 2: 후보 선정 (5개)

선정 기준:
- ✅ `comments:0..2` (대화 가능성 ↑)
- ✅ 한 레포당 1-2개 (큰 레포 과밀 방지)
- ✅ docs/typo/작은 fix 우선 (난이도 🟢)
- ✅ 한국어 컨텍스트에 자연스러운 주제 (i18n/번역/가격 등)
- ✅ 0 comments인 PR 우선 (이미 대화 없음 = 새 대화 부담 ↓)

**8/3 실측 결과:** opencode/oh-my-openagent/hermes-agent/models.dev 각 10 PR, tokscale 0 PR → 40개 중 5개 선정.

### Step 3: 코멘트 초안 3종 (PR마다)

각 PR에 대해 3종 초안 작성:

- 🟢 **"Why?" 질문형 (가장 안전)** — "이 부분 이렇게 구현하신 이유가 있나요?"
- 🟡 **docs 개선형** — "README의 X 부분 한국어 번역 PR을 보내도 될까요?"
- 🟠 **i18n 제안형** — "이 부분 한국어 컨트리뷰션 큐에 등록해드릴까요?"

**추천 진행:** 🟢 시작 → 응답 좋으면 🟡 → 한국 컨트리뷰터 모이면 🟠.

### Step 4: 출력 파일 (`~/Downloads/gitfut-weekly-pr-queue.md`)

```markdown
# GitFut Weekly PR Queue — YYYY-MM-DD

## 📊 카드 추정 / 목표
- OVR 70, DEF 47 → +0.5 OVR / 4주 목표

## 🎯 코멘트 전략
| 색상 | 전략 | 거절 위험 | 효과 |
|------|------|----------|------|
| 🟢 | "Why?" 질문형 | 매우 낮음 | DEF +0.1~0.2 |
| 🟡 | docs 개선형 | 낮음 | DEF +0.2~0.3 + PAS +0.1 |
| 🟠 | i18n 제안형 | 낮음 | DEF +0.1 + PAS +0.2 |

## 📋 후보 N개

### 1. <repo>#<n> — <title>
- URL / 난이도 / 댓글 수 / 선정 이유
**🟢 Why?:** ```{초안}```
**🟡 docs:** ```{초안}```
**🟠 i18n:** ```{초안}```
**행동:** [ ] 🟢 [ ] 🟡 [ ] 🟠 [ ] 스킵
```

**미러 정책 (07-31 user convention):** `~/Downloads/` + `~/work/gitfut/` 양쪽 저장 (`cp -p`).

## 3. 초보자용 PR 코멘트 게시 가이드 (사용자 직접 작업)

> 사용자가 "직접 PR해 본적 없음" 명시 시 (2026-08-03) 다음 절차 사용.

### Step 1: PR 페이지 열기
```
브라우저 주소창: https://github.com/<repo>/pull/<number>
```

### Step 2: Conversation 탭 하단으로
- PR 페이지 기본 탭 = Conversation
- 페이지 **맨 아래**까지 스크롤 → 댓글 입력 박스

### Step 3: 댓글 박스
```
┌─────────────────────────────────────────┐
│ Write a comment                         │
│ (텍스트 입력 영역)                       │
└─────────────────────────────────────────┘
[ Comment ]   ← 이것만 클릭 (Approve / Request changes 아님!)
```

### Step 4: 초안 붙여넣기 + 살짝 다듬기
초안 그대로 OK. 본인 말투 한 문장 추가 권장:

```
안녕하세요! 한국에서 <project> 잘 쓰고 있는 sigco3111입니다.

[초안 본문]

작은 제안이지만, 도움이 되시면 좋겠습니다. 🙂
```

### Step 5: Comment 버튼 클릭
- ⚠️ "Comment and approve" 같은 복합 버튼 없음 — 단순 "Comment"
- 클릭 후 페이지 갱신 → 내 댓글이 Conversation 탭에 표시

### Step 6: 끝, 알림 확인 (1회)
- 종 아이콘 🔔 → Notifications → Participating/Watching 모두 ON

### FAQ

- **Q. 영어로 써야 하나?** → 안전을 위해 영어 권장. 채팅창에 "번역해줘" 요청 시 즉시 영어 버전 제공.
- **Q. 메인테이너가 무시하면?** → 정상. PR 100개 중 30-50%만 응답. 무시 ≠ 거절. 다음 PR로 이동.
- **Q. 거절 답변 오면?** → "알겠습니다! 👍" 한 마디 = +2 카운트 (대화 카운트 추가).
- **Q. 계정 신규/한국어 프로필?** → 전혀 무관. 카운트는 동일.

## 4. 직접 해야 하는 것 (자동화 불가)

- [ ] GitHub UI에서 코멘트 **실제 게시** (자격/윤리)
- [ ] 컨트리뷰터 가이드라인 확인 (코멘트 게시 전)
- [ ] 응답 받은 후 후속 코멘트 작성
- [ ] 각 레포 Watch 추가 (월 1회, GitHub UI)
- [ ] 본인 카드를 README에 박았는지 확인 (월 1회)

## 5. 검증 체크리스트 (월 1회)

- [ ] `gh api user/sigco3111` → public_repos, followers 증가 추이
- [ ] gitfut.dev 본인 카드 캡처 → OVR/DEF 변화
- [ ] tension 완화 확인: SHO/PAS 동반 상승 여부
- [ ] **Reviews 카운트 단독 확인** (z-score 직접 측정 가능)

## 6. Pitfall

1. **`gh watch` 명령은 존재하지 않음** (2026-08-03 확인). Watch는 GitHub UI에서. 검색 풀은 gh api로.
2. **인위적 star/follow 절대 금지** — GitFut anti-gaming heuristic
3. **동일 레포에 한 PR만**: fork upstream에 PR 보내고 끝, 그 다음은 다른 레포로
4. **큰 레포 (opencode) 너무 자주** → rate limit + 시간 낭비. 목록 작게 유지.
5. **PR 너무 빨리 merge 요청** — 컨트리뷰터 가이드라인 먼저 읽기
6. **라벨 필터 (documentation, good-first-issue, help-wanted) 너무 빡셈** → 결과 0 PR 되는 경우 많음. 라벨 없이 검색.
7. **응답 오면 길게 변명 안 함** → "👍" 한 마디로 끝.
8. **🟢 Why? 만으로도 충분** — 거절 위험 0에 가까운 안전한 시작점.

## 7. Cron 등록 (선택)

`~/.hermes/cron/gitfut-weekly.json`:
```json
{
  "name": "gitfut-weekly-queue",
  "schedule": "0 9 * * 1",
  "prompt": "gitfut-pr-review-workflow 스킬 로드 후 sigco3111의 주간 PR 큐를 만들어 ~/Downloads/gitfut-weekly-pr-queue.md 에 저장 + ~/work/gitfut/ 미러",
  "skills": ["gitfut-pr-review-workflow"]
}
```

## 8. 예상 효과

- 댓글 5개 모두 🟢 게시 시:
  - **DEF:** +0.5~1.0pt (Reviews 5개)
  - **PAS:** +0.1~0.3pt (PR 코멘트 활동)
  - **OVR (z-score 기반):** +0.3~0.5pt
  - **tension penalty 완화:** SHO/PAS 동반 상승 기대

## 9. Related

- **다음 단계 자동화:** 4주 후 DEF +1.5~3pt 도달 시 cron 등록 (`hermes cron create`)
- **사용자 선호 (07-20, 07-24):** "위임할께" 패턴 OK, 큰 결정 단계적 검증. A→D 옵션 제시 + 추천 명시.
- **session_search 활용:** "gitfut" 키워드로 이전 주 결과 비교.
