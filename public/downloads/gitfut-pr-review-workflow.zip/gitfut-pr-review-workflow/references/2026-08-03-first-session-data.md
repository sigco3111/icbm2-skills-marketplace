# 2026-08-03 첫 세션 실측 데이터

신호: `gitfut-growth` 스킬 outdated (gh watch 명령 부재) + 사용자 "직접 PR해 본적 없음" → 본 워크플로우의 출발점.

## A 옵션 실행 로그 (2026-08-03)

### Phase 1: 데이터 수집
- **대상 5개 레포:** opencode / oh-my-openagent / hermes-agent / models.dev / tokscale
- **쿼리:** `is:open+is:pr+repo:<repo>+comments:0..3+created:>2026-07-27&per_page=10`
- **수집 결과:**
  - opencode: 10 PR
  - oh-my-openagent: 10 PR
  - hermes-agent: 10 PR
  - models.dev: 10 PR
  - tokscale: 0 PR (제외)

### Phase 2: 후보 5개 선정

| # | 레포 | PR | 제목 | 난이도 | 댓글 |
|---|------|----|----|--------|------|
| 1 | oh-my-openagent | #6537 | docs(issue-template): update stale OpenCode version placeholder | 🟢 | 0 |
| 2 | models.dev | #3965 | Update GitHub Copilot GPT-5.6 Terra and Luna pricing | 🟢 | 0 |
| 3 | models.dev | #3963 | deepseek-v4-flash reasoning_options omit `low` | 🟢 | 0 |
| 4 | hermes-agent | #77159 | feat(models): add four Gemini models to the OpenRouter curated list | 🟡 | 0 |
| 5 | opencode | #40163 | fix(tui): let the prompt Down arrow reach the end of the text | 🟢 | 0 |

### Phase 3: 코멘트 초안 예시 (PR #6537)

**🟢 Why? 질문형:**
```
안녕하세요! 이 issue template이 stale OpenCode 버전을 placeholder로 잡고 있던 거라면,
그냥 latest stable 버전(현재 1.x)을 가리키도록 자동화하는 것도 같이 고려해보셨나요?
매번 placeholder가 stale해지는 패턴이라서요.
(참고로 저는 한국어 컨트리뷰션 큐도 같이 정리해드릴 수 있어요!)
```

**🟡 docs 개선형:**
```
혹시 CONTRIBUTING.md나 README에도 이 OpenCode 버전 표기가 남아있다면 한 번에
업데이트하는 PR을 따로 보내도 괜찮을까요? template만 고치면 다른 곳에서 stale 마크가 남을 수 있을 것 같아서요.
```

**🟠 i18n 제안형:**
```
이 템플릿의 한국어 버전을 추가하면 한국 컨트리뷰터 입장에서도 도움이 될 것 같은데,
i18n 컨트리뷰션 큐에 등록해드릴까요?
```

### Phase 4: 출력 파일

- **메인:** `~/Downloads/gitfut-weekly-pr-queue.md` (8.5 KB)
- **미러:** `~/work/gitfut/gitfut-weekly-pr-queue.md` (8.5 KB)

## 발견된 함정

1. **`gh watch <repo>` 명령 부재** (스킬 문서 outdated)
   - 실제: `unknown command "watch" for "gh"`
   - 대안: GitHub UI에서 직접 Watch 추가
2. **라벨 필터 빡셈** → 결과 0 PR
   - `+label:documentation,good-first-issue,help-wanted` → 0
   - 대안: 라벨 필터 없이 검색

## 사용자 학습 신호 (08-03)

- **"직접 PR해 본적 없음"** → 초보자 가이드 필요 (이 스킬 §3)
- **"거절 당해도 점수 올라가나?"** → 안전 사실 정리 필요 (이 스킬 §1)
- **크론잡은 등록하지 말라** → 자동화 단계 보류, 수동 검증 우선

## 다음 주 (8/10 예정) 실행 시 참고

- 동일 5개 레포 반복
- 응답받은 PR은 🟡 → 🟠 단계 진행
- 미응답 PR은 다음 주에 다시 한 번 기회 (단, 같은 PR 2번 댓글은 하지 않음 — pitfall #7)
- 4주 후 (9월 초) DEF +1.5~3pt 도달 시 cron 등록 검토
