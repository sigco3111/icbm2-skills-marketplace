#!/bin/bash
# kiwi-companion 헤드리스 자동 검증 스크립트
# 사용법:
#   KIWI_DIR_OVERRIDE=... CONDA_PY_OVERRIDE=... SECRETS_FILE_OVERRIDE=... bash headless-test.sh
# 또는 환경변수를 스크립트 상단에서 export 한 뒤 실행.

set -e

# === 사용자 환경에 맞게 수정 ===
KIWI_DIR="${KIWI_DIR_OVERRIDE:-}"
CONDA_PY="${CONDA_PY_OVERRIDE:-}"
SECRETS_FILE="${SECRETS_FILE_OVERRIDE:-}"

if [ -z "$KIWI_DIR" ] || [ -z "$CONDA_PY" ] || [ -z "$SECRETS_FILE" ]; then
    cat <<EOF
[오류] 3개 환경변수가 필요합니다:
  KIWI_DIR         프로젝트 디렉토리 (예: ~/projects/kiwi-companion)
  CONDA_PY         conda kiwi 환경의 python 절대 경로
                   (예: /opt/anaconda3/envs/kiwi/bin/python)
  SECRETS_FILE     API 키가 들어있는 env 파일
                   (예: <HOME>/.hermes/secrets/minimax.env)

실행 예:
  export KIWI_DIR=...
  export CONDA_PY=...
  export SECRETS_FILE=...
  bash headless-test.sh
EOF
    exit 1
fi

cd "$KIWI_DIR" || { echo "[오류] $KIWI_DIR 없음"; exit 1; }

# API 키 로드
if [ ! -f "$SECRETS_FILE" ]; then
    echo "[오류] $SECRETS_FILE 없음"
    exit 1
fi
set -a
# shellcheck disable=SC1090
source "$SECRETS_FILE"
set +a

if [ -z "$MINIMAX_API_KEY" ]; then
    echo "[오류] MINIMAX_API_KEY 환경변수 비어있음"
    exit 1
fi

if [ ! -x "$CONDA_PY" ]; then
    echo "[오류] conda kiwi 환경 없음: $CONDA_PY"
    exit 1
fi

export SDL_VIDEODRIVER=dummy
export PYTHONPATH="$KIWI_DIR:$PYTHONPATH"

echo "================================================"
echo "kiwi-companion 헤드리스 검증"
echo "================================================"
echo

# 1. 의존성
echo "[1/4] 의존성 확인..."
"$CONDA_PY" -c "import pygame, pyttsx3, requests; print(f'  pygame={pygame.version.ver}, pyttsx3={pyttsx3.__version__}, requests OK')"

# 2. LLM
echo "[2/4] LLM 모듈 (감정 태그)..."
"$CONDA_PY" -c "
import llm
scenarios = [
    ('키위야 안녕!', 'happy'),
    ('회사에서 힘든 일', 'sad'),
    ('복권 1등!', 'surprised'),
    ('마음이 편해져', 'happy'),
    ('생각해봐야지', 'thinking'),
]
passes = 0
for text, expected in scenarios:
    r = llm.call_llm(text)
    actual = r['emotion']
    mark = 'PASS' if actual == expected else 'SOFT'
    if actual == expected: passes += 1
    print(f'  {mark} \"{text}\" -> [{actual}]')
print(f'  결과: {passes}/{len(scenarios)} 정확')
"

# 3. TTS
echo "[3/4] TTS 모듈..."
"$CONDA_PY" -c "
from tts import KiwiSpeaker
s = KiwiSpeaker()
print(f'  {s.describe()}')
s.say('테스트', blocking=False)
print('  TTS 발화 요청 OK')
"

# 4. Face
echo "[4/4] Face 모듈 (SDL dummy)..."
"$CONDA_PY" -c "
import threading, time, face
f = face.KiwiFace()
t = threading.Thread(target=f.run, daemon=True); t.start()
for _ in range(100):
    if f.is_ready(): break
    time.sleep(0.05)
print(f'  pygame 준비: {f.is_ready()}')
for emo in ['happy','sad','thinking','surprised','neutral']:
    f.set_emotion(emo); time.sleep(0.2)
f.set_speaking(True, 0.8); time.sleep(0.3); f.set_speaking(False)
f.request_quit()
print('  5감정 + 입 동기화 + 종료 OK')
"

echo
echo "전체 파이프라인 검증 (stdin 자동 입력)..."
printf '키위야 안녕!\n회사에서 힘든 일\n승진했다!!!\n고마워\nquit\n' | "$CONDA_PY" kiwi.py --no-tts 2>&1 | tail -10

echo
echo "검증 완료"
echo
echo "GUI 띄우기: cd $KIWI_DIR && bash run.sh"
