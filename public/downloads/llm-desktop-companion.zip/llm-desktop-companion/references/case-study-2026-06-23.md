# 세션 케이스 스터디 — 2026-06-23 (kiwi-companion v1, v2 안정화)

## 📍 세션 컨텍스트

- **사용자**: sigco3111 (Intel Mac mini, macOS 15.5)
- **요청**: "에르메스 PC에 stackchan 시뮬레이터를 설치하고 구동할 수 있나?"
- **최종 결과**: ✅ **동작함** (텍스트 입력 + 키위 얼굴 + Yuna TTS + LLM 감정 태그 + 메인 스레드 tick)
- **소요 시간**: ~50분 (브레인스토밍 10분 + v1 구현 15분 + 환경 함정 5분 + **크래시 디버깅 3회 15분**)
- **작업 위치**: `~/projects/kiwi-companion/`

---

## 1. 브레인스토밍 단계 (10분)

사용자 신호 받기 전까지의 결정 포인트 4개:

| # | 결정 | 옵션 제시 | 추천 | 사용자 선택 |
|---|------|----------|------|------------|
| 1 | 키위 얼굴 표현 | A. 시스템 이모지 / B. PNG 캐릭터 / C. PIL 그리기 | A | A |
| 2 | LLM 호출 | A. MiniMax 직접 / B. 로컬 Ollama / C. 폴백 체인 | A | A |
| 3 | 음성 입력(STT) | A. 텍스트만 / B. macOS STT / C. Whisper | A | A |
| 4 | 얼굴 표시 | A. pygame 별도 창 / B. 터미널 ASCII / C. 메뉴바 | A | A |

**후속 요청**: "너와 대화의 반응을 키위 얼굴에 반영할 수 있나?" → 4가지 매핑 옵션 → **"LLM 태그 + 입 동기화 + 눈 깜빡임"** 묶음 추천 → "그대로 진행해".

## 2. v1 구현 (15분)

4-모듈 구조로 즉석 빌드:
- `llm.py` — MiniMax API + 감정 태그 파싱
- `tts.py` — pyttsx3 + Yuna 우선순위 + `say` 폴백
- `face.py` — pygame 원형 도형 + 5감정 팔레트 + 깜빡임 + 입 보간
- `kiwi.py` — stdin input + LLM + TTS + face
- `run.sh` — conda kiwi 환경 자동 활성화 래퍼

**검증**: 헤드리스 `SDL_VIDEODRIVER=dummy`로 LLM 5/5 통과 + TTS Yuna 발화 + face 단독 OK.

## 3. 환경 발견 사항 + 첫 함정

- **Hermes 내부 python**: `/Library/Frameworks/Python.framework/Versions/3.8/bin/python3` (Python 3.8.8)
- **사용자 터미널 python**: `/Users/hjshin/opt/anaconda3/bin/python3` (conda base, Python 3.9)
- **MINIMAX_API_KEY**: `~/.hermes/secrets/minimax.env` (export 형태)
- **사용자 직접 실행 → `ModuleNotFoundError: No module named 'pygame'`**

### 함정 A: conda base pip 죽음

```bash
$ /Users/hjshin/opt/anaconda3/bin/pip install pygame pyttsx3
# → InvalidVersion: '4.0.0-unsupported'
```

`python -m pip`도 동일, `conda install`에도 pygame 없음.

**해결**: conda 환경 분리
```bash
/Users/hjshin/opt/anaconda3/bin/conda create -y -n kiwi python=3.11 pip
/Users/hjshin/opt/anaconda3/envs/kiwi/bin/python -m pip install pygame pyttsx3 requests
```

## 4. v1 실행 → 채팅 되는데 얼굴 안 보임

사용자: "kiwi와 채팅이 되는데, 얼굴은 안보임." → NSWindow 크래시 발생 (이때는 stderr가 안 보였음).

### 1차 크래시 진단 + 수정 (NSWindow 메인 스레드)

`face.py`가 `threading.Thread`에서 `pygame.display.set_mode()` 호출 → macOS Cocoa NSWindow은 메인 스레드 전용.

**리팩토링**: 워커 스레드 + 큐 패턴 도입
- `face.run()` → `face.init_pygame()` + `face.tick()` + `face.shutdown()` (모두 메인 스레드)
- LLM/TTS는 워커 스레드, `event_queue.Queue`로 메인에 신호 전달
- `kiwi.py` 메인 루프: 큐 비우기 → stdin 폴링 → face.tick() → time.sleep(0.005)

→ **수정 후 1차 크래시는 해결**.

## 5. v2 실행 → 2차 크래시

`face.py`에 `pygame.init()` + `pygame.time.Clock()` 사용 중이었음 (이전 NSWindow reference에 따라).

### 2차 크래시: 오디오 race (EXC_BAD_ACCESS)

크래시 리포트에서 활성 비동기 스레드 확인:
```
Thread 10: SDLTimer
Thread 11: AudioQueue thread
Thread 13: AQConverterThread
Thread 14: com.apple.audio.IOThread.client
Thread 16: AUScheduledParameterRefresher
```

`pygame.init()`이 `SDL_INIT_AUDIO` 자동 활성화 → SDL2 비동기 오디오 스레드들 띄움 → pyttsx3(macOS NSSpeechSynthesizer)와 오디오 디바이스 race → 메인 스레드 dict 조작 중 NULL deref.

**수정**: `pygame.init()` ❌ → `pygame.display.init() + pygame.font.init()` ✅만. `os.environ["SDL_AUDIODRIVER"] = "dummy"`로 오디오 디바이스 차단.

## 6. v3 실행 → 3차 크래시

오디오 스레드 5개는 사라졌지만 `SDLTimer`는 여전히 살아있음:

```
Thread 0 crashed:
  pgEvent_New + 4596 → PyDict_SetItemString → PyDict_SetItem (NULL deref)
  r15: empty_keys_struct
```

`pygame.time.Clock()`이 SDL 내부 timer 활성화 → `SDLTimer` 스레드가 메인 스레드의 `PyDict_SetItemString`과 race.

**수정**: `self._clock = pygame.time.Clock()` ❌ → `self._clock = None` + `time.sleep(0.005)`로 throttle. `tick()`에서 `self._clock.tick(60)` 호출 제거.

## 7. v3 실행 → ✅ 동작

```bash
$ bash run.sh
🥝 kiwi conda 환경 (Python 3.11) 으로 실행합니다.
[face] pygame 윈도우 생성: 480x480
[face] SDL driver: cocoa      ← 실제 macOS 백엔드
[face] mixer init: False      ← 오디오 race 차단 확인
[키위] 안녕~! 나는 키위야. 오늘 기분 어때?
```

활성 비동기 스레드: **0개 (NSEventThread만 — AppKit 메인)**.

사용자: "동작함."

## 8. 검증된 환경 (최종)

| 항목 | 값 |
|------|---|
| OS | macOS 15.5 (Intel Mac) |
| Python | 3.11.13 (conda kiwi env) |
| pygame | 2.6.1 |
| pyttsx3 | 2.99 |
| LLM | MiniMax-M3 (Anthropic 호환 API) |
| TTS | macOS Yuna (compact ko-KR) |
| 얼굴 | 480x480 Pygame, 메인 스레드 tick() 루프 |

## 9. 통합 테스트 결과

### LLM 5/5 시나리오 통과 (단일 호출)
| 입력 | 감정 | 결과 |
|------|------|------|
| "키위야 안녕!" | happy | ✓ |
| "회사에서 너무 힘든 일이 있었어" | sad | ✓ |
| "복권 1등 됐어!!!" | surprised | ✓ |
| "너랑 얘기하니까 마음이 편해져" | happy | ✓ |
| "승진했다!!" | surprised (단일) / neutral (대화 컨텍스트) | △ |

### 대화 컨텍스트 누적 시 약화
4~5턴 이상 누적되면 LLM이 감정 태그를 빼먹고 모두 neutral로 출력. 시스템 프롬프트 강화로 부분 개선되었지만 근본 해결 안 됨 → **v1은 "neutral 폴백"으로 표정은 항상 바뀌게**, v2는 2차 분류 권장.

## 10. 사용자 직접 실행 가이드 (최종)

```bash
cd ~/projects/kiwi-companion
bash run.sh
```

데스크탑 세션에서 pygame 윈도우가 뜨고, 텍스트 입력 시 키위가 표정 + 한국어 음성으로 응답. 종료: `quit` 입력 또는 ESC 또는 윈도우 X.

## 11. 미해결 이슈 / 로드맵

- [ ] **감정 태그 컨텍스트 약화** — 2차 분류 호출 또는 키워드 백업
- [ ] **음성 입력 (STT)** — Whisper (Intel Mac에서 무거움) 또는 macOS Speech Framework
- [ ] **PNG 외형** — 현재 pygame 도형 → 일러스트 PNG로 외형 업그레이드
- [ ] **표정 전환 부드럽게** — 0.3초 페이드 트랜지션
- [ ] **대화 로그 저장** — SQLite
- [ ] **cross-platform 가드** — 위 3대 함정은 macOS 한정. Linux/Windows에선 가드 코드 조건부 적용

## 12. 디자인 결정 (다층 README + 시드 시스템 차용)

- README는 한/영 병기 + 4가지 결정 사항 + 샘플 옵션 + 향후 확장 아이디어
- run.sh 래퍼로 환경 activate 자동화
- 4-모듈 분리 (llm / tts / face / main) — face 단독 죽어도 LLM은 살아있음
- LLM 응답 끝에 감정 태그 강제 + 파싱 — 구조화 출력의 가장 robust한 패턴
- **워커 스레드 + 큐 + 메인 스레드 pygame** — macOS Cocoa 제약 우회의 유일한 패턴

## 13. 핵심 학습 (다음 세션으로 carry-over)

### 디버깅 워크플로 (macOS pygame 크래시)
1. 크래시 리포트의 `Thread N::` 목록 확인
2. **예상치 못한 비동기 스레드** 찾기 (SDLTimer, AudioQueue, AQConverter, IOThread)
3. 한 가지씩 명시적 init으로 교체하며 비동기 스레드 사라지는지 확인
4. 헤드리스 `SDL_VIDEODRIVER=dummy`로 회귀

### 절대 하면 안 되는 3가지
1. `pygame.init()` (전체 init) — 오디오 race
2. `pygame.time.Clock()` — 타이머 race
3. `threading.Thread(target=face.run)` — NSWindow 제약

### 검증 체크리스트
```python
import pygame
assert not pygame.mixer.get_init()  # False여야 안전
```

## 14. 다음 세션 액션 (희정님 피드백 시)

- "감정 안 바뀌어요" → 키워드 백업 분류 추가
- "음성 입력" → macOS Speech Framework 우선 시도
- "외형 업그레이드" → PNG 5종 + face.py 이미지 로딩 추가
- "대화 저장" → SQLite + FTS5 인덱스
