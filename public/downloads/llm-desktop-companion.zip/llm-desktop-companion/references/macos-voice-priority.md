# macOS 시스템 음성 우선순위 가이드

macOS에는 177개 시스템 음성이 내장되어 있고, pyttsx3 NSSpeechSynthesizer 백엔드로 모두 접근 가능. 이 가이드는 다국어 TTS 동반자 만들 때 음성 선택 패턴을 정리한다.

## 🇰🇷 한국어 음성 우선순위

| 우선순위 | 이름 | ID 패턴 | 음질 | 비고 |
|---------|------|---------|------|------|
| 1 | Yuna | `com.apple.voice.compact.ko-KR.Yuna` | ⭐⭐⭐⭐⭐ | compact 고품질, 가장 자연스러움 |
| 2 | Kyung | `com.apple.voice.compact.ko-KR.Kyung` | ⭐⭐⭐⭐ | compact, 남성 |
| 3 | Eddy (ko-KR) | `com.apple.eloquence.ko-KR.Eddy` | ⭐⭐⭐ | Eloquence, 기계적 |
| 4 | Grandma/Flo/Reed/Rocko/Sandy/Shelley (ko-KR) | `com.apple.eloquence.ko-KR.*` | ⭐⭐ | Eloquence 계열 |
| 5 | 시스템 기본 | (ko-KR) | ⭐⭐ | 마지막 폴백 |

## ⚠️ Pitfall: 단순 substring 매칭 함정

```python
# ❌ 이 코드는 Yuna 대신 Eddy를 선택함
_KEYWORDS = ("yuna", "kyung", "ko_kr", "korean")  # 또는 any 순서

for v in voices:
    name = v.name.lower()
    if any(k in name for k in _KEYWORDS):
        return v
# 결과: "Eddy (Korean (South Korea))"가 "korean"으로 먼저 매칭됨
```

**이유**: `com.apple.eloquence.ko-KR.Eddy`의 name은 "Eddy (Korean (South Korea))"이고, "korean"이 "yuna"보다 앞 순서에 있으면 항상 Eddy가 선택됨.

## ✅ 해결: 우선순위 키워드 루프 + 정확 매칭

```python
_KOREAN_KEYS = ("yuna", "kyung", "ko-kr.yuna", "ko_kr.yuna", "korean")

def _find_korean_voice(engine):
    voices = engine.getProperty("voices")
    if not voices:
        return None

    # 우선순위대로 정확 매칭
    for keyword in _KOREAN_KEYS:
        for v in voices:
            name = (getattr(v, "name", "") or "").lower()
            vid = (getattr(v, "id", "") or "").lower()
            if keyword == "yuna":
                # Yuna는 정확한 단어 매칭 (단어 경계)
                if name == "yuna" or vid.endswith(".yuna") or "ko-kr.yuna" in vid:
                    return v
            elif keyword in name or keyword in vid:
                return v

    # 마지막 폴백: languages 속성에 'ko' 포함
    for v in voices:
        languages = getattr(v, "languages", []) or []
        if any("ko" in str(lang).lower() for lang in languages):
            return v
    return None
```

## 🇯🇵 일본어 / 🇨🇳 중국어 / 🇺🇸 영어 패턴

### 일본어
- **Kyoko** (compact) — `com.apple.voice.compact.ja-JP.Kyoko`
- Eloquence ja-JP: Eddy, Flo, Grandma, Grandpa, Reed, Rocko, Sandy, Shelley

### 중국어 (간체)
- **Tingting** (compact zh-CN) — `com.apple.voice.compact.zh-CN.Tingting`
- **Meijia** (compact zh-TW) — `com.apple.voice.compact.zh-TW.Meijia`
- Eloquence zh-CN/zh-TW 동일

### 영어
- **Samantha** (compact en-US, 기본) — `com.apple.voice.compact.en-US.Samantha`
- **Daniel** (compact en-GB) — `com.apple.voice.compact.en-GB.Daniel`
- **Karen** (compact en-AU) — `com.apple.voice.compact.en-AU.Karen`

## 🔧 사용 가능한 음성 목록 확인

```bash
python3 -c "
import pyttsx3
e = pyttsx3.init()
for v in e.getProperty('voices'):
    langs = getattr(v, 'languages', [])
    print(f'{v.name:30s} {str(v.id)[-30:]:30s} {[str(l) for l in langs]}')"
```

## 🛠️ pyttsx3 → macOS `say` 폴백

pyttsx3가 죽거나 음성 못 찾으면 `subprocess.Popen(["say", "-v", "Yuna", text])` 폴백. macOS는 `say` 바이너리에 compact 음성 우선 매칭.

```python
def _say_fallback(self, text, blocking):
    say_bin = shutil.which("say")
    if not say_bin:
        print(f"[키위(텍스트만)] {text}")
        return
    for voice in ["Yuna", "Kyung", ""]:  # 마지막은 시스템 기본
        cmd = [say_bin] + (["-v", voice] if voice else []) + [text]
        try:
            if blocking: subprocess.run(cmd, check=True, timeout=60)
            else: subprocess.Popen(cmd)
            return
        except Exception:
            continue
    print(f"[키위(폴백 실패)] {text}")
```

## ⚠️ Pitfall: pyttsx3 thread-safety

```python
import threading
self._lock = threading.Lock()

def say(self, text, blocking=False):
    with self._lock:  # 단일 락 직렬화 필수
        self.engine.say(text)
        if blocking:
            self.engine.runAndWait()
        else:
            threading.Thread(target=self._run_and_wait_safe, daemon=True).start()
```

**이유**: engine.runAndWait()는 thread-unsafe. 동시 호출 시 deadlock 또는 경합.

## ⚠️ Pitfall: main thread에서만 init 가능

일부 macOS 버전에서 pyttsx3.init()은 main thread에서만 호출 가능. **face 스레드에서 engine 생성 ❌**.

```python
# ❌ face 스레드에서 init
def face_run(self):
    self.engine = pyttsx3.init()  # 일부 버전에서 실패

# ✅ main에서 미리 init, face는 set_speaking만
face = KiwiFace()
face_thread.start()
speaker = KiwiSpeaker()  # main에서 init
```

## 📊 macOS 버전별 음성 가용성

- **macOS 10.13+**: 기본 compact 음성 (Yuna, Kyoko, Samantha 등) 포함
- **macOS 12+**: Eloquence 음성 8종 × 11개 언어 = 88개 음성 추가
- **macOS 14+**: Personal Voice 기능 (사용자 음성 복제, 시스템 설정 필요)

## 🔗 관련

- `pyttsx3` 공식 문서: https://pyttsx3.readthedocs.io/
- macOS `say` 명령: `man say`
- Apple Speech Synthesis: https://developer.apple.com/documentation/avfoundation/speech_synthesis