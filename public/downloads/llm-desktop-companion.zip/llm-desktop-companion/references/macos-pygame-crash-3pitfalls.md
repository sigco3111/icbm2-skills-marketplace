# macOS pygame 3대 Race Condition — 디버깅 케이스 스터디

**세션**: 2026-06-23 (kiwi-companion stackchan simulator)
**환경**: macOS 15.5 + Python 3.11.13 + pygame 2.6.1 + pyttsx3 2.99

이 문서는 한 세션에서 **3차례 연속 크래시**를 디버깅한 과정을 정리합니다. macOS + pygame + 비동기 음성 라이브러리를 조합할 때 **거의 반드시** 만나는 함정들입니다.

---

## TL;DR — 3가지 절대 하면 안 되는 패턴

| # | 패턴 | 결과 |
|---|------|------|
| 1 | `pygame.init()` (전체 init) | 오디오 race → EXC_BAD_ACCESS |
| 2 | `pygame.time.Clock()` 사용 | 타이머 race → pgEvent_New NULL deref |
| 3 | `threading.Thread(target=face.run)` | NSWindow 메인 스레드 제약 |

→ **명시적 init (`display.init()` + `font.init()`)만 + `time.sleep()` throttle + 메인 스레드 init/loop**

---

## 1차 크래시 — `pygame.init()` 오디오 race

### 증상

```
Exception Type:        EXC_BAD_ACCESS (SIGSEGV)
Exception Codes:       UNKNOWN_0xD at 0x0000000000000000
Thread 0: _PyEval_EvalFrameDefault + 158752
```

크래시 시 활성 비동기 스레드 (Thread 10~16):
```
Thread 10: SDLTimer
Thread 11: AudioQueue thread
Thread 13: AQConverterThread
Thread 14: com.apple.audio.IOThread.client
Thread 16: AUScheduledParameterRefresher
```

### 근본 원인

`pygame.init()`은 `SDL_INIT_AUDIO`를 자동 활성화. SDL2가 비동기로:
- `AudioQueue thread` (CoreAudio)
- `AQConverterThread` (오디오 포맷 변환)
- `com.apple.audio.IOThread.client` (HAL I/O)

이 스레드들이 띄워지는 동안 같은 프로세스의 `pyttsx3` (macOS NSSpeechSynthesizer)가 오디오 디바이스를 점유하려고 시도. **오디오 디바이스 핸들 race condition** → 메인 스레드 Python 바이트코드 실행 중 NULL 포인터 역참조.

### 잘못된 코드

```python
# ❌ 이렇게 하지 말 것
pygame.init()  # audio까지 자동 init
pygame.display.set_mode((480, 480))
pygame.time.Clock()  # timer까지 자동 init
```

### 수정

```python
# ✅ 명시적 subsystem init만
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")  # 오디오 race 차단
pygame.display.init()  # 이것만
pygame.font.init()     # 이것만
pygame.display.set_mode((480, 480))
# pygame.time.Clock() 안 만듦
```

### 디버깅 단계

1. 크래시 리포트의 `Thread N::` 목록 확인 → AudioQueue/AQConverter/IOThread가 보이면 pygame audio init 의심
2. `import pygame; pygame.mixer.get_init()` 결과가 `True`면 mixer/audio init 발동한 것
3. `os.environ["SDL_AUDIODRIVER"] = "dummy"` 환경변수로 오디오 디바이스 자체를 가짜로 만들어 차단

---

## 2차 크래시 — NSWindow 메인 스레드 제약

### 증상

```
pygame.error: NSWindow should only be instantiated on the main thread!
Exception in thread Thread-1 (run):
Traceback ...
  File ".../face.py", line 74, in run
    self._window = pygame.display.set_mode(...)
```

채팅은 동작 (LLM + TTS는 정상), **얼굴 윈도우만 안 뜸**.

### 근본 원인

macOS Cocoa의 `NSWindow` 객체는 **반드시 메인 스레드에서만** 생성 가능. `threading.Thread(target=face.run)`로 백그라운드 스레드에서 `pygame.display.set_mode()` 호출하면 macOS가 거부.

### 잘못된 코드

```python
# ❌ Linux/Windows에선 동작하지만 macOS에서 크래시
def main():
    face = KiwiFace()
    t = threading.Thread(target=face.run, daemon=True)
    t.start()
    # main thread는 stdin 입력 처리만
```

### 수정

```python
# ✅ 메인 스레드 = pygame, 워커 = LLM/TTS + 큐
import queue
event_queue = queue.Queue()

def llm_worker(user_text, ...):
    event_queue.put({"type": "thinking_start"})
    result = llm.call_llm(user_text)
    event_queue.put({"type": "emotion", ...})
    speaker.say(result["text"], blocking=False)
    event_queue.put({"type": "speaking_end"})

def main():
    face.init_pygame()  # 메인 스레드에서 set_mode ✓
    while not face.is_quit_requested():
        # 1) 큐 비우기 (워커 → 메인 신호)
        try:
            while True:
                ev = event_queue.get_nowait()
                # ev에 따라 face 상태 변경
        except queue.Empty: pass

        # 2) stdin 폴링
        if select.select([sys.stdin], [], [], 0.0)[0]:
            threading.Thread(target=llm_worker, ...).start()

        # 3) 한 프레임
        face.tick()
```

### Face API 리팩토링

`run()`을 3개 메서드로 분할, 모두 메인 스레드에서 호출:

```python
class KiwiFace:
    def init_pygame(self) -> bool:
        """한 번만 호출. NSWindow 생성."""
        pygame.display.init()  # 명시 init
        pygame.font.init()
        self._window = pygame.display.set_mode((480, 480))
        self._initialized = True
        return True

    def tick(self) -> bool:
        """매 프레임 호출. 이벤트 + draw + flip."""
        for event in pygame.event.get():
            if event.type == pygame.QUIT: return False
        self._update(time.time())
        self._draw()
        pygame.display.flip()
        return True

    def shutdown(self):
        pygame.quit()
```

setter 메서드 (`set_emotion`, `set_speaking`)는 단순 instance attr 변경이라 **어떤 스레드에서 호출해도 안전**.

### 디버깅 단계

1. `NSWindow should only be instantiated on the main thread!` 메시지 → 별도 스레드에서 `set_mode` 호출 중
2. `print(threading.current_thread())`로 어느 스레드에서 호출되는지 확인
3. `pygame.display.get_driver()` 결과가 `dummy`면 SDL_VIDEODRIVER가 leak된 거 (테스트 harness 충돌)

---

## 3차 크래시 — `pygame.time.Clock()` SDLTimer race

### 증상

```
Exception Type:        EXC_BAD_ACCESS (SIGSEGV)
Exception Codes:       KERN_INVALID_ADDRESS at 0x000000000000000f
rip: 0x000000000000000f  r15: empty_keys_struct

Thread 0:
0   ???                    0xf ???
1   python                 PyDict_SetItem + 3388
2   python                 PyDict_SetItemString + 77
3   event.cpython-...so    pgEvent_New + 4596
4   event.cpython-...so    pg_event_get + 696
5   python                 cfunction_call + 52
```

활성 비동기 스레드:
```
Thread 10: SDLTimer  ← pygame.time.Clock가 띄움
Thread 11: com.apple.NSEventThread
```

### 근본 원인

`pygame.time.Clock()` 인스턴스화 시 SDL 내부 timer가 활성화되어 `SDLTimer` 스레드 띄움. 이 스레드가 메인 스레드와 동시에 `PyDict_SetItemString` 호출 → dict가 비어있는 상태(`r15: empty_keys_struct`)에서 메타데이터 접근 → NULL deref.

### 잘못된 코드

```python
# ❌ Clock.tick()가 SDLTimer 활성화
self._clock = pygame.time.Clock()
while True:
    self._update(time.time())
    self._draw()
    pygame.display.flip()
    self._clock.tick(60)  # ← 이게 문제
```

### 수정

```python
# ✅ time.sleep()으로 throttle, Clock 안 씀
self._clock = None  # 명시적으로 안 만든다고 표시
while True:
    self._update(time.time())
    self._draw()
    pygame.display.flip()
    time.sleep(0.005)  # ~200 FPS cap, SDLTimer 안 띄움
```

### 디버깅 단계

1. 크래시 스택에 `pgEvent_New` 또는 `PyDict_SetItemString` 보이면 pygame 내부 dict 조작 중 죽음
2. 활성 스레드 목록에서 `SDLTimer` 찾기
3. `self._clock = pygame.time.Clock()` 호출 위치 찾기 — 제거하고 `time.sleep()`으로 대체
4. 검증: `SDL_VIDEODRIVER=dummy` 헤드리스에서 `self._clock = None`로도 정상 동작 확인

---

## 누적 디버깅 패턴

3번 모두 동일한 패턴으로 진단 가능:

1. **크래시 리포트의 활성 스레드 목록** 확인
2. **예상치 못한 비동기 스레드**가 있으면 (= `SDLTimer`, `AudioQueue`, `AQConverter`, `IOThread`, `AUScheduledParameterRefresher` 등) pygame의 자동 init 의심
3. **한 가지씩 명시적 init**으로 교체하며 비동기 스레드 사라지는지 확인
4. **헤드리스 `SDL_VIDEODRIVER=dummy`** 로 회귀 테스트 (실제 macOS cocoa 백엔드 + stdin 파이프)

### 검증 체크리스트 (안정성 가드)

```python
# face.py init 후 다음 확인:
import pygame
assert not pygame.mixer.get_init(), "mixer init됨 — 오디오 race 위험"
# SDLTimer 검증은 직접 불가하지만, mixxer init만 False여도 1차 크래시는 안전
```

```bash
# 헤드리스에서 검증
SDL_VIDEODRIVER=dummy python3 -c "
import face
f = face.KiwiFace()
assert f.init_pygame(), 'init 실패'
import pygame
assert not pygame.mixer.get_init()
f.shutdown()
print('SAFE: no mixer init')"
```

### 비동기 스레드 제거 후 최종 상태

| 스레드 | 출처 | 크래시 시 존재 |
|--------|------|----------------|
| NSEventThread | AppKit (필수) | 항상 (안전) |
| SDLTimer | `pygame.time.Clock()` | ❌ 제거 (3차) |
| AudioQueue / AQConverter / IOThread | `pygame.init()` audio | ❌ 제거 (1차) |
| AUScheduledParameterRefresher | CoreAudio | ❌ 제거 (1차) |

→ 최종 비동기 스레드는 AppKit 메인 NSEventThread 하나뿐. **메인 스레드 = 모든 pygame 작업**, 안전.

---

## macOS 외 플랫폼 노트

이 3가지 함정은 **macOS Cocoa에 특화**:
- **Linux (X11/Wayland)**: NSWindow 제약 없음. 1차/2차/3차 모두 발생 안 함. 단 `pygame.init()`은 audio init 발동하므로 Intel Linux에서도 mixer 안 쓸 거면 명시 init 권장.
- **Windows**: NSWindow은 MS 윈도우. 메인 스레드 제약은 유사하게 있음 (COM apartment). 패턴은 동일하게 적용.

→ **macOS가 가장 까다롭고, 검증된 패턴은 다른 플랫폼에서도 안전**.
