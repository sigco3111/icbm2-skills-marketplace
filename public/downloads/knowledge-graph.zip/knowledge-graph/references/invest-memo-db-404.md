# invest_memo DB 404 Issue

**Date discovered:** 2026-05-31
**Symptom:** `invest_memo` DB returns HTTP 404 — DB ID is wrong or DB was deleted in Notion

## Diagnosis

```
⚠️ 참고
- `invest_memo` DB가 404 에러 — DB ID가 잘못되었거나 삭제된 상태입니다.
  Notion에서 DB ID를 확인 후 스크립트의 `NOTION_INVEST_MEMO_DB_ID` 환경변수를 업데이트하세요.
```

## Required Action

1. Check Notion for the correct `invest_memo` DB ID
2. Update the `NOTION_INVEST_MEMO_DB_ID` environment variable in:
   - Shell profile (`~/.zshrc`, `~/.bashrc`) or
   - `knowledge_graph.py` script constants
3. Re-run the knowledge graph pipeline to confirm the DB is accessible

## DB IDs (last known)

| DB | Last Known ID | Status |
|----|---------------|--------|
| iOS Trend | `33c76f2e-9097-8112-84f6-c60096cc0e11` | OK |
| AI Model Tracker | `33c76f2e-9097-8132-9033-e434f4055b56` | OK |
| invest_memo | Unknown | ⚠️ 404 |
| Maintenance Report | `33c76f2e-9097-8198-bd1b-c3ea3cfbbae8` | OK |

## Notes

- The `invest_memo` DB is used for investment-related news and market commentary
- If the DB was deleted, a new one needs to be created in Notion with the same schema
- Until fixed, the knowledge graph will silently skip `invest_memo` entries (no fatal error)
