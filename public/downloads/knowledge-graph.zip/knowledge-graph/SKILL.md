---
name: knowledge-graph
description: ICBM2 지식 그래프 자동 구축 — Notion DB 데이터를 수집하여 엔티티/관계를 추출하고 인터랙티브 그래프로 시각화
version: 1.0.0
author: icbm2
metadata:
  hermes:
    tags: [knowledge-graph, visualization, notion, data-analysis]
---

# 지식 그래프 자동 구축

Notion의 여러 DB (iOS Trend, Invest Memo, AI Model Tracker, Learning Log, 아이디어 노트, 뉴스 클리핑 등)에서 데이터를 수집하고, 키워드 기반 엔티티 추출과 관계 매핑을 통해 지식 그래프를 자동 구축합니다.

## 파이프라인

1. **데이터 수집**: Notion API로 7개 DB에서 최근 90일 데이터 수집
2. **엔티티 추출**: 정규식 기반 키워드 매칭 (기술/회사/금융/주제)
3. **관계 구축**: 항목-엔티티, 같은 날짜, 같은 카테고리, 공동 출현 연결
4. **시각화**: D3.js 기반 인터랙티브 HTML 그래프 생성
- **GitHub Pages 배포**: 퍼블릭 저장소에 자동 푸시
6. **Notion 기록**: 🧠 지식 그래프 DB에 결과 자동 저장

## 사용법

```bash
# 전체 파이프라인 실행
python3 scripts/knowledge_graph.py

# 데이터 수집만
python3 scripts/knowledge_graph.py --collect

# 시각화만 (기존 데이터)
python3 scripts/knowledge_graph.py --visualize

# 통계 출력
python3 scripts/knowledge_graph.py --stats

# 키워드 검색
python3 scripts/knowledge_graph.py --query "AI"

# 수집 기간 지정 (30일)
python3 scripts/knowledge_graph.py --days 30

# 브라우저에서 열기
python3 scripts/knowledge_graph.py --open
```

## 출력

- **그래프 데이터**: `data/knowledge_graph/graph_data.json`
- **HTML 시각화**: `data/knowledge_graph/output/knowledge_graph.html`
- **GitHub Pages**: 본인 GitHub Pages URL에 배포
- **Notion DB**: `$NOTION_KG_DB_ID` (ICBM 봇 페이지 하위)
- **Notion Embed 뷰어**: ICBM 봇 페이지 하위 "🧠 지식 그래프 뷰어" 페이지

## GitHub Pages 자동 배포

스크립트 실행 시 자동으로 시각화 HTML을 퍼블릭 저장소에 푸시합니다:
1. 퍼블릭 저장소 로컬 경로에서 `git push`
2. GitHub Pages가 자동 배포
3. Notion Embed 뷰어에서 실시간 확인 가능

## 엔티티 카테고리

| 카테고리 | 예시 | 색상 |
|----------|------|------|
| technology | AI, LLM, Swift, PyTorch | 보라 |
| company | Apple, Google, NVIDIA | 노랑 |
| finance | 삼성전자, AAPL, KOSPI | 청록 |
| topic | 머신러닝, 에이전트, RAG | 핑크 |

## 연결 유형

- **mentions**: 항목이 특정 엔티티를 언급
- **same_date**: 같은 날짜에 기록된 항목들
- **same_category**: 같은 카테고리의 항목들
- **co_occurrence**: 함께 언급되는 엔티티들

## Notion DB 구조

- 이름 (title)
- 날짜 (date)
- 노드 수 (number)
- 연결 수 (number)
- 핵심 엔티티 (rich_text)
- 상태 (select: 완료/진행중/오류)

## 주의사항

- Notion API Rate Limit: ~3 req/sec (스크립트에서 0.35초 딜레이 적용)
- 대용량 데이터(아이디어 노트 300+건) 처리 시 약 30초 소요
- 엔티티 추출은 키워드 기반이므로 100% 정확하지 않음
- LLM 기반 엔티티 추출은 향후 개선 예정
- ⚠️ `invest_memo` DB 404 에러 발생 시: `references/invest-memo-db-404.md` 참조
