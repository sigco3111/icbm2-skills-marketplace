# 2026-08-04 — Git 자동 동기화 cron `388898171a79` 사례

## 상황

- **잡 ID**: `388898171a79`
- **잡 이름**: ICBM2 Git 자동 동기화
- **트리거**: 매일 21:00 (KST)
- **프롬프트 원본** (jobs.json 발췌, 줄바꿈 정리):
  ```
  ICBM2 Git 자동 동기화를 수행하라.

  ## 조건부 실행
  먼저 변경 여부를 확인하라:
  cd /Users/mac/hermes_bot && git status --porcelain
  변경 사항이 없으면 즉시 종료하라.

  변경 사항이 있으면:
  1. git add -A && git commit -m "auto-sync: $(date +%Y-%m-%d_%H%M)"
  2. git push origin main
  3. hermes_bot 저장소의 secrets/, scripts/, skills/ 동기화 확인

  또한 icbm2-knowledge-graph 저장소도 확인:
  cd /Users/mac/icbm2-knowledge-graph && git status --porcelain
  변경이 있으면 동일하게 add/commit/push.

  성공/실패 결과를 요약하라.
  ```

## 실제 환경과의 차이

| prompt 경로 | 실제 | 결과 |
|------------|------|------|
| `/Users/mac/hermes_bot` | **존재하지 않음** (이 PC에 원래 없었음) | cd 즉시 fail |
| `/Users/mac/icbm2-knowledge-graph` | `/Users/mac/.hermes/repos/icbm2-knowledge-graph` (.hermes/repos/ 통합) | cd 즉시 fail |

## 백업에서 발견한 옛 경로

`/Users/mac/.hermes/migration_fix_backup_20260626_131359/jobs.json.bak` (2026-06-26 PC 이전 시점 백업):
- 옛 경로: `/Users/hjshin/hermes_bot`, `/Users/hjshin/icbm2-knowledge-graph`
- 사용자명 변경(`hjshin` → `mac`) 후 prompt 갱신 안 됨
- 한 달 넘게 silent failure 유지

## 진단 출력 (skill 적용 시 예상)

```
=== cron-prompt-drift 검사 (2026-08-04 04:00) ===

[STALE]    388898171a79 → /Users/mac/hermes_bot
[STALE]    388898171a79 → /Users/mac/icbm2-knowledge-graph
[TINY-OUT] 388898171a79 → 0B avg (last 7d)
[USR-MISM] 388898171a79 → cd /Users/mac/hermes_bot (current=mac)

=== 요약: OK=0, STALE=2, TINY-OUTPUT=1, USER-MISMATCH=1 ===
```

## 처방 결정

이 cron은 잡 자체가 의미 있는가? 두 가지 중 하나:

### 옵션 A — 잡 복구 (jobs.json 직접 patch)

```bash
# 백업
cp ~/.hermes/cron/jobs.json ~/.hermes/cron/jobs.json.bak.$(date +%s)

# prompt의 stale 경로 → 실제 경로로 교체
# hermes_bot → $HOME/.hermes/repos/hermes_bot (또는 실제 존재하는 다른 이름 — 확인 필요)
# icbm2-knowledge-graph → $HOME/.hermes/repos/icbm2-knowledge-graph

# JSON 검증
jq . ~/.hermes/cron/jobs.json > /dev/null
```

### 옵션 B — 잡 폐기 (cron-decommission 워크플로)

- `hermes_bot` 자체가 이 PC에 존재한 적이 없고 사용자도 repo가 없어도 일상 워크플로에 지장 없음 (모든 자동화는 `~/.hermes/` 아래로 통합됨)
- `icbm2-knowledge-graph` 는 `knowledge-graph` 스킬이 매일 자동 갱신 중 (`hermes cron list` 확인)
- 잡의 본질적 가치는 **"git push 자동화"** 인데, 이미 `~/.hermes/repos/` 내부 repo는 별도 push 파이프라인이 있을 가능성 → `automation-decommission` 으로 안전 폐기 검토

## 사용자 결정 필요

이 보고서를 사용자한테 보내고 A(복구) vs B(폐기) 선택 요청. 또는 다음 세션에서 디폴트 추천(B — 폐기)을 명시하고 자동 진행 여부 묻기.

## 교훈 (skill 업데이트에 반영됨)

1. **크론 잡의 prompt에 절대경로를 하드코딩하면 PC 이전/사용자명 변경 후 silent failure 1순위 원인** — `automation-healthcheck` v1.6.0 추가 제안
2. **잡 ID가 한 달 넘게 같은 ID면 출력 파일 크기 모니터링으로 silent 잡 발견 가능** — `cron-prompt-drift/scripts/check_cron_path_drift.sh` 에 TINY-OUTPUT 상관관계 포함
3. **jobs.json 백업에는 항상 옛 prompt가 보존됨** — drift 진단의 비교 reference로 활용 가능