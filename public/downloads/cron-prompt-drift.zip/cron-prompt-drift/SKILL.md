---
name: cron-prompt-drift
description: Detect cron jobs with stale hardcoded paths failing.
tags: [cron, drift, paths, maintenance, ICBM2]
---

# Cron Prompt Drift Detection & Repair

## 클래스 정의

Hermes cron jobs의 `prompt` 필드에 하드코딩된 **절대경로**가 PC 이전 / 사용자명 변경 / repo 위치 재구조화 후 자동 갱신되지 않아 silent failure를 일으키는 패턴. 잡 자체는 "ok"로 표시되고 출력 파일도 갱신되지만, 첫 줄의 `cd <stale> && ...` 가 즉시 죽어 **빈 stdout**만 남는다. 사용자/관리자가 모른 채 수 주~수 개월간 silently.

## 트리거 신호 (이런 징후가 보이면 발동)

- 크론 잡의 `hermes cron logs <id> --limit 5` 출력이 모두 100 byte 미만 또는 stdout 0줄
- `~/.hermes/cron/output/<job_id>/` 의 최근 N개 파일 평균 크기 < 1KB
- 잡 ID가 `388898171a79` 처럼 오래된 ID인데 prompt에 `/Users/<old-name>/...` 패턴
- 백업/스냅샷에 동일 prompt의 옛 경로가 남아있음 (`migration_fix_backup_*/jobs.json.bak`)
- 잡의 prompt가 `cd /Users/mac/<X> && ...` 인데 `ls /Users/mac/<X>` 가 `No such file or directory`

## 사례: 2026-08-04 Git 자동 동기화 cron `388898171a79`

- **프롬프트 (stale)**: `cd /Users/mac/hermes_bot && git status --porcelain`
- **프롬프트 (stale)**: `cd /Users/mac/icbm2-knowledge-graph && git status --porcelain`
- **실제 위치**: `/Users/mac/.hermes/repos/icbm2-knowledge-graph`
- **백업 스냅샷 (06-26)**: `/Users/hjshin/hermes_bot` — 사용자명 변경(`hjshin` → `mac`) 후 미갱신
- **결과**: 한 달 넘게 silent, "[SILENT]" 종료, 알림 0건
- **범주**: silent failure (잡 status는 ok, 출력은 비어있음)

## 검출 절차

### 1단계: 잡 prompt에서 절대경로 추출

```bash
for jid in $(hermes cron list --json 2>/dev/null | jq -r '.[].id'); do
  prompt=$(hermes cron show "$jid" --json 2>/dev/null | jq -r '.prompt')
  paths=$(echo "$prompt" | grep -oE 'cd /[A-Za-z0-9/_.-]+' | sed -E 's/cd //; s/&&$//; s/`//g' | sort -u)
  for p in $paths; do
    [ -e "$p" ] || echo "[STALE] $jid → $p"
  done
done
```

### 2단계: 출력 파일 크기 상관관계

```bash
for jid in $(hermes cron list --json 2>/dev/null | jq -r '.[].id'); do
  outdir="$HOME/.hermes/cron/output/$jid"
  [ -d "$outdir" ] || continue
  avg=$(find "$outdir" -type f -mtime -7 -printf '%s\n' 2>/dev/null | awk '{s+=$1; n++} END{if(n>0) printf "%d", s/n; else print 0}')
  [ "$avg" -lt 1024 ] && echo "[TINY-OUTPUT] $jid → avg ${avg}B (last 7d)"
done
```

### 3단계: 사용자명 변경 흔적

```bash
# 옛 username 잔존 (hjshin → mac 이전 사례)
grep -lE 'cd /Users/[a-z]+/' ~/.hermes/cron/jobs.json | head
# 시스템 현재 username과 불일치 잡 ID 추출
CURRENT_USER=$(whoami)
grep -nE "cd /Users/[a-z]+/" ~/.hermes/cron/jobs.json | grep -v "cd /Users/$CURRENT_USER/" | head
```

### 4단계: repo 위치 재구조화 흔적

```bash
# ~/.hermes/repos/ 로 통합된 repo들 — jobs.json의 옛 위치 잔존 확인
ls ~/.hermes/repos/ 2>/dev/null
for repo in $(ls ~/.hermes/repos/ 2>/dev/null); do
  # jobs.json에서 옛 절대경로 패턴 (예: ~/work/$repo, ~/Documents/$repo 등) 잔존 확인
  grep -nE "(work|Documents|Desktop)/$repo[/'\") ]" ~/.hermes/cron/jobs.json | head
done
```

## 분류 (drift 카테고리)

| 카테고리 | 증상 | 일반적 원인 | 처방 |
|---------|------|-----------|------|
| **사용자명 변경** | `cd /Users/<old>/...` | macOS 계정명 변경 (`hjshin` → `mac` 등) | `sed -i.bak "s|/Users/<old>/|/Users/$CURRENT_USER/|g" jobs.json` |
| **repo 통합 이동** | `cd ~/work/<repo>` 또는 `~/Documents/<repo>` | `~/.hermes/repos/` 로 통합 후 미갱신 | prompt의 경로 부분만 교체 (commit hash 등 보존) |
| **다운로드 폴더 선호 변경** | `cd ~/Downloads/...` → `cd ~/work/Downloads/...` | 사용자 선호: 다운로드 폴더 = `~/Downloads/` (work-tree 아님) | work 경로 잔존 잡 모두 `~/Downloads/` 로 통일 |
| **스크립트/venv 이동** | `~/.hermes/scripts/<x>.py` 가 `~/.hermes/venvs/<x>/bin/<x>` 로 | venv 통합 | jobs.json의 스크립트 경로 부분만 patch |
| **PC 이전 (cross-machine)** | macOS A → macOS B, 다른 홈 디렉터리 | launchd cron restore 시 prompt에 A의 경로 그대로 복원 | 검출 후 일괄 sed 또는 jobs.json 재작성 |

## 수정 패턴

### A) jobs.json 직접 patch (가장 빠름)

```bash
cp ~/.hermes/cron/jobs.json ~/.hermes/cron/jobs.json.bak.$(date +%s)

# 1단계에서 [STALE] 잡은 prompt의 stale 경로 → 실제 경로로 sed 교체
# 예: hermes_bot → .hermes/repos/hermes_bot (또는 실제로는 hermes_agent_components 같은 다른 이름일 수 있음 — 반드시 확인)

# 변경 후 jobs.json 문법 검증
jq . ~/.hermes/cron/jobs.json > /dev/null && echo "JSON valid"
```

### B) hermes cron update 사용 (jobs.json 자동 동기화되는 경우)

```bash
hermes cron update <job_id> --prompt "$(cat new_prompt.txt)"
```

### C) 잡 재등록 (jobs.json에 잡 자체가 손상된 경우)

가장 안전: 백업의 jobs.json.bak.* 에서 prompt만 가져와서 새 잡으로 재등록, 옛 잡은 disable.

## 검증 절차 (수정 후)

```bash
# 1) prompt 안의 모든 cd 경로가 존재하는지
hermes cron show <id> --json | jq -r '.prompt' | grep -oE 'cd /[A-Za-z0-9/_.-]+' | while read p; do
  clean=$(echo "$p" | sed -E 's/cd //; s/&&$//; s/`//g')
  [ -e "$clean" ] && echo "OK: $clean" || echo "STILL-STALE: $clean"
done

# 2) 수동 dry-run
cd <real-path> && git status --porcelain   # prompt 첫 줄 그대로 실행

# 3) 다음 스케줄까지 대기 (또는 강제 트리거)
hermes cron run-now <job_id>   # 사용 가능한 경우
```

## 회귀 방지 패턴

### 새 잡 만들 때 prompt 작성 규칙

1. **절대경로 하드코딩 금지** — `${HOME}/...` 형태로 작성하고 cron prompt 환경 컨텍스트에 명시
2. **사전 검증 단계 추가** — prompt 첫 단계에 `test -d <path> || { echo "MISSING: <path>"; exit 1; }` 포함
3. **사용자에게 확인** — 잡 등록 전 `pwd` 와 `ls <path>` 출력 같이 보여주고 사용자 승인

### 정기 점검

- **월 1회**: `hermes cron list` 의 모든 잡 prompt를 grep으로 일괄 점검 (`cd /(Users|home)` 패턴)
- **PC 이전 후 필수**: 이전 직후 위 4단계 검출 절차 전체 실행 → stale 잡 일괄 보고
- **jobs.json git 추적**: `~/.hermes/cron/jobs.json` 을 가능한 git으로 추적 (단, daemon이 직접 쓰면 conflict 가능 → backup만)

### 진단 한 줄

```bash
hermes cron list --json | jq -r '.[] | .id' | while read jid; do
  her=$(hermes cron show "$jid" --json 2>/dev/null | jq -r '.prompt' | grep -oE 'cd /[A-Za-z0-9/_.-]+' | sed -E 's/cd //; s/&&$//; s/`//g' | head -1)
  [ -n "$her" ] && [ ! -e "$her" ] && echo "DRIFT: $jid → $her"
done
```

## 다른 클래스로의 확장

이 패턴은 cron prompt뿐 아니라 다음에도 적용 가능:

- **skill frontmatter `required_paths`** — skill이 절대경로를 강제하는 경우 동일 drift
- **AGENTS.md / AGENT.md의 코드 예시** — 절대경로 하드코딩 시 stale 가능
- **메모리 파일** — "X는 /Users/old/... 에 있다" 같은 사실 정보 — 사용자명 변경 후 stale
- **launchd plist의 WorkingDirectory** — `~/.openclaw/workspace` 처럼 옛 워크트리 경로 잔존 사례 검증됨 (v1.5.0 launchd 좀비 케이스)

## 지지 자료

- `automation-healthcheck` v1.5.0 — launchd 좀비 케이스에서 `com.icbm2.hermes-gateway` plist의 WorkingDirectory가 stale 워크트리였던 패턴 (TMI 회피 함정과 함께)
- `cron-stale-triage` — stale 알림 교차 검증 워크플로. prompt-path drift도 stale의 한 형태로 분류 가능
- `device-environment-migration` — macOS/Linux 디바이스 간 사용자 환경 이전 워크플로. PC 이전 후 이 스킬을 함께 실행 권장