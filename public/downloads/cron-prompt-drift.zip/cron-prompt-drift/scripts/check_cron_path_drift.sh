#!/usr/bin/env bash
# cron-prompt-drift: 잡 prompt의 절대경로 vs 실제 파일시스템 검증
# 사용법: bash check_cron_path_drift.sh
# 출력: [STALE] / [TINY-OUTPUT] / [USER-MISMATCH] / [OK] 한 줄 요약
set -u

JOBS_JSON="${HOME}/.hermes/cron/jobs.json"
REPOS_DIR="${HOME}/.hermes/repos"
CURRENT_USER="$(whoami)"

echo "=== cron-prompt-drift 검사 ($(date +%Y-%m-%d_%H:%M)) ==="
echo

if ! command -v jq >/dev/null 2>&1; then
  echo "jq 미설치 — 종료"
  exit 1
fi

if [ ! -f "$JOBS_JSON" ]; then
  echo "jobs.json 없음: $JOBS_JSON"
  exit 1
fi

STALE=0
TINY=0
MISMATCH=0
OK=0

# 1) prompt 안의 cd 절대경로 검사
mapfile -t JOB_IDS < <(jq -r '.[].id' "$JOBS_JSON" 2>/dev/null)

for jid in "${JOB_IDS[@]}"; do
  prompt=$(jq -r --arg id "$jid" '.[] | select(.id == $id) | .prompt' "$JOBS_JSON" 2>/dev/null)
  [ -z "$prompt" ] && continue

  while IFS= read -r raw; do
    clean=$(echo "$raw" | sed -E 's/^cd +//; s/ +&&.*$//; s/`//g; s/^ +//; s/ +$//')
    [ -z "$clean" ] && continue
    if [ -e "$clean" ]; then
      echo "[OK]       $jid → $clean"
      OK=$((OK+1))
    else
      echo "[STALE]    $jid → $clean"
      STALE=$((STALE+1))
    fi
  done < <(echo "$prompt" | grep -oE 'cd +/[A-Za-z0-9/_.-]+' || true)

  # 2) 출력 파일 크기 검사 (last 7d, 1KB 미만 = 의심)
  outdir="${HOME}/.hermes/cron/output/${jid}"
  if [ -d "$outdir" ]; then
    avg=$(find "$outdir" -type f -mtime -7 -printf '%s\n' 2>/dev/null | \
      awk '{s+=$1; n++} END{if(n>0) printf "%d", s/n; else print 0}')
    if [ "${avg:-0}" -lt 1024 ]; then
      echo "[TINY-OUT] $jid → ${avg}B avg (last 7d)"
      TINY=$((TINY+1))
    fi
  fi

  # 3) 사용자명 불일치
  wrong_user=$(echo "$prompt" | grep -oE 'cd +/Users/[a-z]+/' | \
    grep -v "cd /Users/${CURRENT_USER}/" | head -1)
  if [ -n "$wrong_user" ]; then
    echo "[USR-MISM] $jid → $wrong_user (current=$CURRENT_USER)"
    MISMATCH=$((MISMATCH+1))
  fi
done

echo
echo "=== 요약: OK=$OK, STALE=$STALE, TINY-OUTPUT=$TINY, USER-MISMATCH=$MISMATCH ==="

# STALE 1개 이상이면 exit 1 → cron_self_healer.py 같은 후속 워커가 알림 발송 가능
[ "$STALE" -gt 0 ] && exit 1
exit 0