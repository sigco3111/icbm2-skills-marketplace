---
name: colab-image-gen
description: Google Colab 또는 Kaggle Notebooks 무료 GPU(T4)로 SDXL/FLUX 이미지를 생성하는 자동화 파이프라인. Colab 무료 GPU 컴퓨팅 단위 소진 시 Kaggle 대안 사용(주 30시간 GPU 무료). 주인님 PC는 인텔 맥(M1 이전)이라 로컬 SD 불가 → 클라우드 GPU 필수.
---

# Colab Image Generation

Google Colab 무료 T4 GPU로 SDXL / FLUX 이미지 생성 API 서버를 구동하고, 로컬에서 클라이언트로 이미지를 요청합니다.

## 파일 위치

- **Colab 노트북:** `scripts/colab_image_gen.ipynb`
- **로컬 클라이언트:** `scripts/colab_image_client.py`

## 설정 방법

### 1단계: ngrok 계정 & 토큰 발급
1. https://dashboard.ngrok.com/get-started/your-authtoken 접속
2. 회원가입 (무료)
3. Authtoken 복사

### 2단계: Colab 노트북 실행
1. Google Colab에서 `colab_image_gen.ipynb` 열기
2. 런타임 → 런타임 유형 변경 → T4 GPU
3. ngrok 토큰을 노트북 3번 셀에 입력
4. 셀을 순서대로 실행 (모델 로드 ~2~3분)
5. 출력된 ngrok URL 복사 (예: `https://xxxx.ngrok-free.app`)

### 3단계: 로컬에서 사용
```bash
# 서버 상태 확인
python3 scripts/colab_image_client.py --status --url https://xxxx.ngrok-free.app

# 이미지 생성 (FLUX - 빠름)
python3 scripts/colab_image_client.py "A golden dragon at sunset" --model flux --url https://xxxx.ngrok-free.app

# 이미지 생성 (SDXL - 고품질)
python3 scripts/colab_image_client.py "A golden dragon at sunset" --model sdxl --steps 30 --guidance 7.5 --url https://xxxx.ngrok-free.app

# 출력 파일 지정
python3 scripts/colab_image_client.py "cute cat" -o ~/Desktop/cat.png --url https://xxxx.ngrok-free.app
```

## 지원 모델

| 모델 | 속도 | 퀄리티 | 추천 steps | 추천 guidance |
|------|------|--------|-----------|--------------|
| FLUX.1-schnell | ~3-5초 | 중상 | 4 (최대 8) | 3.5 |
| SDXL 1.0 | ~8-15초 | 상 | 25-30 | 7.0-7.5 |

## 한계

- Colab 무료 GPU: 하루 ~12-15시간 사용 가능 (연속 아님)
- 세션 1-4시간 후 자동 끊김 → 재실행 필요
- ngrok 무료: URL이 매번 바뀜 (유료 플랜에서 고정 가능)
- Colab 세션 초기 로딩 ~2-3분

## 주의사항

- ngrok 토큰을 공개하지 마세요
- Colab 세션이 끊기면 모델 재로드 필요
- 대량 생성 시 Colab 사용량 제한에 주의
