---
name: omo-config-strict-validation
description: omo v4.19.4+ config Zod strict schema 검증 + Deprecated silent fail 진단 워크플로. reasoning/models 스키마 키 역전 + [opencode] flatten + plugin entry 복원 + TUI default Build 패턴 11섹션 통합.
---

# omo Config Strict Schema Validation (v4.19.4+)

omo (npm dual-published as `oh-my-opencode` / `oh-my-openagent`) v4.18+ 의 config 는 Zod v4 strict schema 검증을 거쳐 로드됨. **알 수 없는 키는 즉시 reject**되어 첨부 config 가 그대로는 적용되지 않음. 이 스킬은 "omo 가 실행되지 않음" / "agent sisyphus not found" / "TUI 첫 화면이 Build 로 시작" / "doctor 가 18개 Deprecated 경고" 같은 증상의 1차 진단 + 수정 워크플로를 다룬다.

> **OMO_VERSION**: 4.19.4 (2026-08-06 검증). 이전 버전은 config 위치 / 키 셋이 다를 수 있음. **`bunx oh-my-openagent --version` 으로 먼저 확인.**
>
> **🚨 v4.19.4 schema 키 역전 (2026-08-06 실측)**: 이 스킬 초기 버전은 `reasoningEffort` + `fallback_models` 를 정식으로 표기했으나, **v4.19.4 실측 정반대** — `reasoning` + `models: [...]` 배열. 옛 패턴은 doctor 에서 "Deprecated" 18+ 경고로 표시되지만 strict 위반은 아니므로 silent fail. **2.4절 "v4.19.4 schema 키 역전 정리표" 반드시 참조.**

---

## 1. Config 위치 (omo v4.18+ 변경됨)

| 위치 | 상태 | 비고 |
|---|---|---|
| `~/.config/opencode/oh-my-openagent.json` | **legacy** | 플러그인이 startup migration 으로 자동 백업 + 이동. **옛 위치에 두면 `Legacy OMO configuration remains` 경고 + 일부 hook/agent 미적용** |
| **`~/.omo/omo.jsonc`** | **정식** | OmoConfigSchema strict 검증. 옛 위치에서 자동 migration 됨 |

**파일명 4종 모두 인식** (legacy 호환): `oh-my-openagent.jsonc`, `oh-my-openagent.json`, `oh-my-opencode.jsonc`, `oh-my-opencode.json`. **하지만 정식 위치는 `~/.omo/omo.jsonc`**.

```bash
# 현재 config 위치 + 파일 상태 확인
ls -la ~/.omo/omo.jsonc ~/.config/opencode/oh-my-openagent*.json 2>/dev/null
```

---

## 2. OmoConfigSchema strict 위반 키 (2026-08-06 실측, v4.19.4)

**`OmoConfigSchema` / `OmoAgentDefSchema` / `OmoCategoryConfigSchema` 모두 `.strict()`** — 알 수 없는 키는 즉시 reject. 위반 시 `bunx oh-my-openagent doctor` 가 위반 키 경로를 콤마로 나열.

### 2.1 최상위 키 (`OmoConfigSchema`)

| 키 | 상태 | 비고 |
|---|---|---|
| `$schema`, `agents`, `categories`, `models` | ✅ OK | 그대로 |
| `codegraph`, `task`, `teams` | ✅ OK | 그대로 |
| `profiles`, `_migrations`, `legacy_migrations` | ✅ OK | 그대로 |
| `[opencode]`, `[senpi]`, `[codex]` | ✅ OK | harness 별 config 블록 (단, **migration이 자동 추가** — 11절 참조) |
| `team_mode` | ❌ strict 위반 | **제거** |
| `background_task` | ❌ strict 위반 | **제거** |
| `providerConcurrency` (nested) | ❌ strict 위반 | `models` 카탈로그 + runtime env 로 이전 검토 |

### 2.2 Agent 정의 키 (`OmoAgentDefSchema`)

| 키 | 상태 | 비고 |
|---|---|---|
| `model`, `variant` | ✅ OK | 그대로 |
| **`reasoning`** | ✅ **OK (v4.19.4 정식)** | `reasoningEffort` 의 후속 키. `variant` → `reasoning` 자동 migration |
| `reasoningEffort` | ⚠️ **Deprecated** | doctor 가 "Deprecated reasoning config key" 경고 18개 출력. 작동은 하지만 옛 키 |
| `models: [...]` 배열 | ✅ OK | agent 의 모델 체인 (primary + fallback) |
| `tools: {...}`, `temperature`, `execution_mode`, `disable` | ✅ OK | 그대로 |
| `fallback_models: [...]` | ⚠️ **Deprecated** | `models: [{model, reasoning}, ...fallbacks]` 로 변환 권장 |
| `maxTokens`, `top_p`, `thinking` | ❌ strict 위반 | **카테고리로 이전** (agent 에는 없음) |

### 2.3 Category 정의 키 (`OmoCategoryConfigSchema`)

| 키 | 상태 | 비고 |
|---|---|---|
| `model`, `variant` | ✅ OK | 그대로 |
| `reasoning` | ✅ OK | agent 와 동일 |
| `reasoningEffort` | ⚠️ Deprecated | agent 와 동일 |
| **`models: [...]` 배열** | ✅ **OK (v4.19.4 정식)** | agent 와 동일한 형식 — 첫 entry 가 primary, 나머지 fallback |
| `fallback_models: [...]` | �️ **Deprecated** | `models: [...]` 로 변환 권장 |
| `tools`, `temperature`, `maxTokens`, `thinking`, `textVerbosity` | ✅ OK | 그대로 |
| `prompt_append`, `max_prompt_tokens` | ✅ OK | category 전용 |

### 2.4 � v4.19.4 schema 키 역전 정리표

이전 세션의 스킬(2026-08-06 초안)은 v4.19.4 와 정반대로 표기했음. **현재 정식 키**:

| 항목 | 옛 (잘못) | **v4.19.4 정식** |
|---|---|---|
| reasoning 키 | `reasoningEffort` | **`reasoning`** |
| category fallback | `fallback_models` | **`models: [...]` 배열** |
| agent fallback | `models: [...]` 배열 | `models: [...]` 배열 (동일) |
| config 위치 | `~/.omo/omo.jsonc` | ✅ 동일 |

**"Deprecated" ≠ "위반"**: doctor 가 "Deprecated" 만 띄우고 strict 위반은 안 하면 **silent fail**. config 로드되지만 옛 키는 무시되고 디폴트 모델 (anthropic/claude-opus-5 등) 로 fallback. **`bunx oh-my-openagent doctor --verbose | grep -A 30 "Configured Models"` 의 `●` / `○` 가 핵심 신호** — `○` 만 보이면 적용 안 된 것.

### 2.5 `models: [...]` 배열 entry 형식

agent / category 모두 `models` 배열을 쓸 수 있음. 각 entry 는:

```jsonc
"models": [
  { "model": "minimax-coding-plan/MiniMax-M3", "reasoning": "max" },  // primary
  "github-copilot/gpt-5.6-luna"                                          // string fallback (단순)
]
```

**migration이 자동 변환하는 형태 (실측)**:
- 옛 `category.quick: { model, reasoning, fallback_models: [...] }` → `category.quick: { model, reasoning, models: [{model, reasoning}, {model}, ...] }`
- 결과: `model` + `reasoning` (top-level) + `models` (배열) **둘 다** 박힘 — 중복이지만 strict 위반 아님 (in-memory 변환)

---

## 3. `variant` → `reasoning` 마이그레이션 (v4.19.4 의도된 동작)

omo v4.19.4 의 startup migration (`2026-08-reasoning-unification`) 이 **`variant` 키를 `reasoning`이라는 정식 키로 자동 변환**. 이건 **버그가 아니라 v4.19.4 의 의도된 동작**. `reasoning` 은 v4.19.4 정식 키.

**증상**: 옛 config (`variant: "max"`) 가 박혀있으면 첫 실행 시 `reasoning: "max"` 로 자동 변환. 그 결과 `reasoning` 키가 raw file 에 박힘. **`reasoningEffort` 를 쓰는 옛 config 였다면** doctor 가 "Deprecated reasoning config key" 경고 18개 띄움 (strict 위반은 아님 — silent fail).

**핵심**: 처음부터 `reasoning` �로 쓰면 migration 발동 안 함. `reasoningEffort` 쓰면 매 실행마다 deprecated 경고.

```jsonc
// ✅ v4.19.4 정식 (권장)
{ "model": "minimax-coding-plan/MiniMax-M3", "reasoning": "max" }

// ⚠️ 작동은 하지만 deprecated 경고 18개
{ "model": "minimax-coding-plan/MiniMax-M3", "reasoningEffort": "max" }

// 🔄 옛 키 — migration이 reasoning으로 자동 변환
{ "model": "minimax-coding-plan/MiniMax-M3", "variant": "max" }
```

**마이그레이션 마커**: 한 번 발동 후 `_migrations: ["2026-08-reasoning-unification", ...]` 박힘. 그 이후 raw file 의 `variant` 는 정상 변환됨. **`reasoningEffort` 는 박히지 않음** — omo 가 `reasoningEffort` 는 마이그레이션 대상으로 안 봄.

`reasoning` enum: `none | minimal | low | medium | high | xhigh | max`. **`xhigh` 와 `max` 가 모두 있음에 주의** (omo 고유).

## 4. `[opencode]` harness 블록 flatten 패턴 (v4.19.4 migration 추가)

omo v4.19.4 의 migration (`2026-07-opencode-config-unification`) 이 omo.jsonc 에 **`[opencode]` 블록을 자동 추가**할 수 있음. 이 블록 안의 `agents` / `categories` 가 top-level 키와 중첩됨:

```jsonc
// migration 직후 실제 파일
{
  "$schema": "...",
  "[opencode]": {
    "agents": { ... },           // ← top-level agents 와 중복 가능
    "categories": { ... }
  },
  "agents": { ... },             // ← top-level
  "categories": { ... },         // ← top-level
  "legacy_migrations": { ... },
  "_migrations": [...]
}
```

**증상**: top-level 과 `[opencode]` 안의 `agents` / `categories` 가 **다르다면** 어떤 게 적용되는지 모호. 보통 top-level 이 우선하지만, plugin 로딩 시점에 따라 in-memory merge 가 다르게 동작.

**해결**: 첨부 config 변환 시 **flat 으로 정규화**:

```python
# 첨부 config 정형화
cfg.pop("[opencode]", None)  # migration 추가 블록 제거
cfg.pop("legacy_migrations", None)  # migration 추적 메타 — 제거 후에도 _migrations 가 박혀있어 안전
```

**doctor 의 `[opencode]` 위치 표시**: `bunx oh-my-openagent doctor` 가 `Deprecated reasoning config key /Users/mac/.omo/omo.jsonc: agents.sisyphus.reasoningEffort` 처럼 **top-level 경로만** 보여줌 → `[opencode].agents.sisyphus.reasoning` 에 박혀있어도 무시될 수 있음. **top-level 로 옮기는 게 안전**.

---

## 5. 검증 워크플로 (3단계)

```bash
# 1) config 위치 확인 (정식 = ~/.omo/omo.jsonc)
ls -la ~/.omo/omo.jsonc ~/.config/opencode/oh-my-openagent*.json 2>/dev/null

# 2) strict 검증 (가장 빠른 진단 — 위반 키 경로가 콤마로 나열됨)
bunx oh-my-openagent doctor
# "✓ System OK" = strict 위반 없음
# "⚠ N issues found" = Deprecated (silent fail) 또는 strict 위반

# 3) verbose — user override 적용 여부 (Deprecated silent fail 진단)
bunx oh-my-openagent doctor --verbose | grep -A 30 "Configured Models"
# ● = user override 적용 (정상)
# ○ = provider fallback (Deprecated silent fail — 적용 안 됨)
```

**검증 통과 기준**:
- ✅ `✓ System OK` 출력
- ✅ verbose 의 모든 agent + category 옆 `●`
- ⚠️ "System OK" 인데 `○` 만 보이면 = **Deprecated silent fail** — 2.4절 역전표 보고 `reasoningEffort` → `reasoning`, `fallback_models` → `models: [...]` 변환

**⚠️ 비대화형 한계**: `opencode run --agent <name>` 은 opencode native agent registry 만 직접 부를 수 있음. omo 의 sisyphus/team-mode 등은 **TUI 에서 `/agent sisyphus`** 또는 `bunx oh-my-opencode run` (`--agent` 생략) 로만 동작. 비대화형 검증은 schema 통과 여부만 확인한다고 보면 됨.

**⚠️ `bunx oh-my-openagent` vs `bunx oh-my-opencode`**: 같은 dual-published 패키지 (4.19.x 까지). 둘 다 같은 동작. 단, **bun global install 시 `~/.bun/bin/` 에 심볼릭 링크가 안 만들어짐** (bun 특이 동작) — 항상 `bunx oh-my-openagent` 으로 호출. `which oh-my-openagent` 가 빈 결과여도 정상.

---

## 6. 첨부 config 변환 패턴 (v4.19.4 정식 키 기준)

사용자가 옛 형식 `oh-my-openagent.json` 을 첨부하거나 옛 PC config 를 가져왔을 때:

```python
import json, pathlib

ATTACHED = pathlib.Path("~/.config/opencode/oh-my-openagent.json")
LIVE = pathlib.Path("~/.omo/omo.jsonc")

cfg = json.loads(ATTACHED.read_text())

# 1) 최상위 strict 위반 키 제거
for k in ["team_mode", "background_task"]:
    cfg.pop(k, None)

# 2) [opencode] 블록 제거 (migration이 자동 추가하는 중첩 — top-level 우선)
cfg.pop("[opencode]", None)
cfg.pop("legacy_migrations", None)

# 3) reasoningEffort → reasoning (v4.19.4 정식 키)
def fix_reasoning(obj):
    if not isinstance(obj, dict):
        return
    if "reasoningEffort" in obj and "reasoning" not in obj:
        obj["reasoning"] = obj.pop("reasoningEffort")
    for v in obj.values():
        fix_reasoning(v)

for defn in cfg.get("agents", {}).values():
    fix_reasoning(defn)
for defn in cfg.get("categories", {}).values():
    fix_reasoning(defn)

# 4) fallback_models → models 배열 (agent / category 모두)
def normalize_models(obj):
    if not isinstance(obj, dict):
        return
    if "fallback_models" in obj:
        primary_model = obj.get("model")
        primary_reasoning = obj.get("reasoning")
        fallbacks = obj.pop("fallback_models")

        models = []
        if primary_model:
            entry = {"model": primary_model}
            if primary_reasoning:
                entry["reasoning"] = primary_reasoning
            models.append(entry)
        for fb in fallbacks:
            if isinstance(fb, str):
                models.append({"model": fb})
            elif isinstance(fb, dict):
                models.append(fb)

        # top-level 의 model / reasoning 은 유지 (in-memory 변환이 두 형태 모두 처리)
        if not obj.get("models"):
            obj["models"] = models
    for v in obj.values():
        normalize_models(v)

normalize_models(cfg.get("agents", {}))
normalize_models(cfg.get("categories", {}))

# 5) _migrations 마커 보존 (이미 박혀있으면 그대로)
if "_migrations" not in cfg:
    cfg["_migrations"] = ["2026-07-opencode-config-unification", "2026-08-reasoning-unification"]

# 6) 저장
LIVE.write_text(json.dumps(cfg, indent=2) + "\n")
```

이 6단계 끝나면 `bunx oh-my-openagent doctor --verbose | grep -A 30 "Configured Models"` 로 모든 agent 가 `●` 인지 확인.

---

## 7. 흔한 에러 → 해결 매트릭스

| 증상 | 원인 | 해결 |
|---|---|---|
| `agent "sisyphus" not found. Falling back to default agent` | omo config 의 user override 가 적용 안 됨 | `~/.omo/omo.jsonc` 위치 + strict 위반 키 확인 |
| `Invalid omo config at /Users/mac/.omo/omo.jsonc: agents.explore, agents.sisyphus-junior, agents.librarian` | agent 정의의 strict 위반 키 (옛: `fallback_models`) | 6절 변환 패턴 |
| `Legacy OMO configuration remains at /Users/mac/.config/opencode/oh-my-openagent.jsonc` | 옛 위치 파일이 아직 있음 | `rm ~/.config/opencode/oh-my-openagent.jsonc` (또는 `bunx oh-my-openagent config migrate`) |
| `TUI plugin entry missing from tui.json` | `tui.json` 자체가 없거나 plugin 미등록 | `~/.config/opencode/tui.json` (확장자 없음!) 에 `{"plugin": ["oh-my-openagent@latest"]}` 작성 |
| doctor 가 `✓ System OK` 인데 verbose 의 `Configured Models` 가 `○` 만 (● 0개) | **Deprecated silent fail** — `reasoningEffort` / `fallback_models` 옛 키 사용 중 | 2.4절 역전표 보고 `reasoning` + `models: [...]` 로 변환 |
| doctor 가 "Deprecated reasoning config key" 18개 | `reasoningEffort` 사용 (정식 키는 `reasoning`) | 6절 변환 패턴 3단계 |
| doctor 가 "Deprecated ... fallback_models" 3개 | `fallback_models` 사용 (정식 키는 `models: [...]`) | 6절 변환 패턴 4단계 |
| 모든 agent 가 invalid 표시되는데 파일은 깨끗해 보임 | `[opencode]` 블록 안에 또 agents/categories 가 박혀있음 (migration 자동 추가) | 4절 flatten — top-level 만 유지 |
| TUI 첫 화면이 `Build`로 시작 (sisyphus 가 default 안 뜸) | opencode 1.18.x sort 가 알파벳순 — `Build` 가 `Sisyphus` 앞 | 9절 패턴 (`agent/*.md` + `default_agent`) |

---

## 8. 알려진 함정 / 주의

- **migration 마커 충돌**: `_migrations` 가 박혀있는데 또 같은 마이그레이션 트리거 → no-op. 안전.
- **dual-published 패키지**: `bunx oh-my-openagent` 와 `bunx oh-my-opencode` 둘 다 같은 버전 출력. 같은 코드베이스 (rename transition).
- **provider ID 검증**: 첨부 config 의 `minimax-coding-plan/MiniMax-M3` 같은 provider ID 는 **opencode 의 `auth ls` 에 등록된 provider 와 일치해야** 함. 등록 안 됐으면 `opencode auth list` 로 확인 후 등록.
- **legacy 위치 자동 삭제**: omo v4.19+ 가 옛 위치 파일을 startup migration 시 자동 백업 + 제거할 수 있음. 작업 전 백업본 확인 권장.
- **TUI vs 비대화형 검증 격차**: `--agent sisyphus` 가 정상이어도 TUI 의 `/agent sisyphus` 가 다른 동작을 할 수 있음. 실제 사용 패턴은 TUI 기준.
- **`tui.json` 확장자 함정**: opencode 의 native TUI config 는 **`tui.json`** (확장자 없음). `tui.jsonc` 만들어도 opencode 가 무시 → TUI plugin 안 떠서 "Select agent" 모달 비어 보임. **`opencode.jsonc` 는 확장자 있음 (c)** — 이 둘 비대칭.
- **🚨 `opencode.json` plugin entry 소실 (2026-08-06 실측)**: `2026-07-opencode-config-unification` 마이그레이션이 **`~/.config/opencode/opencode.json`의 `plugin` entry를 정리하다가 소실**시킬 수 있음. **결과**: `tui.json`은 plugin 등록돼있지만 `opencode.json`은 빈 상태 → server plugin 부재 → **omo agent 11개 빌트인이 TUI "Select agent" 모달에 안 뜸** (build, plan native만 표시). **증상**: 사용자가 스크린샷 보내면 "agent not found" 또는 "agent 목록에 sisyphus 없음" 형태. **진단**: `bunx oh-my-opencode doctor` 가 `Server plugin entry missing from opencode.json` 경고. **복원**: `~/.config/opencode/opencode.jsonc`에 옛 `opencode.json.backup`에서 plugin/mcp 정의 가져와 다시 쓰기. **상세**: 9절 참조.
- **omo agent 전환 = Tab 키, 슬래시 명령 아님**: omo의 sisyphus/hephaestus 등은 **TUI에서 `Tab` 키로 순환 전환** (Build → Plan → ...). `/agent sisyphus` 같은 슬래시 명령은 opencode native agent list에만 동작. 사용자가 "Select agent" 모달을 띄웠는데 sisyphus 등 omo agent가 안 보이면 9절 패턴 진단.
- **bun global install 심볼릭 링크 부재**: `bun install -g oh-my-openagent` 후 `~/.bun/bin/` 에는 `gjc`, `mcporter` 등 다른 패키지만 있고 `oh-my-openagent` 링크가 없음 (bun 특이 동작). `which oh-my-openagent` 빈 결과는 **정상**. 항상 `bunx oh-my-openagent` 으로 호출.
- **Downloads 폴백 함정**: 첫 `bunx oh-my-openagent install` 실행 시 `~/.config/opencode/` 가 비어있으면 omo 가 **`~/Downloads/oh-my-openagent.json`** �로 config 를 떨어뜨림 (caller 가 임의의 cwd 라서). 정식 위치(`~/.config/opencode/oh-my-openagent.jsonc`)와 다른 곳. **재실행 시 cwd 확인 + Downloads 청소 필요**.
- **`agent list` 출력 함정**: `opencode agent list | grep -E "^[a-z]"` 는 primary 4개만 잡음. omo 빌트인 (`Sisyphus - ultraworker`, `Hephaestus - Deep Agent`, `Prometheus - Plan Builder`, `Atlas - Plan Executor`) 는 **첫 글자가 대문자**. grep 패턴 `[A-Z][a-zA-Z]+` 필요. 그리고 나머지 (Oracle, Librarian, Explore, Metis, Momus, Multimodal-looker, Sisyphus-junior) 7개는 plugin 내부 agent 라 `agent list` 에 안 뜨는 게 정상 — TUI Tab 순환으로만 접근 가능.

---

## 📎 부속 파일

- **`references/omo-schema-keys-reference.md`** — 4개 Zod 스키마 (`OmoConfigSchema`, `OmoAgentDefSchema`, `OmoCategoryConfigSchema`, `OmoAgentModelEntrySchema`, `OmoReasoningEffortSchema`) 의 정확한 허용 키 + enum + 실측 트랜스크립트 (strict 위반 디버깅 시 참고용).
- **`templates/omo.jsonc.minimax-coding-plan`** — MiniMax-M3 + GitHub Copilot 8 agent/8 category 정형 템플릿. `_migrations` 마커 포함, 그대로 복붙 후 provider/model ID 만 바꾸면 됨.
- **`templates/sisyphus.md`**, **`templates/hephaestus.md`** — opencode native `~/.config/opencode/agent/*.md` 형식 primary agent 정의. 9절 (TUI default = Build) 패턴에서 user override 모델 + `mode: primary` 박아 직접 복붙. frontmatter `mode: primary` 필수 (없으면 `(subagent)` 분류 → `default_agent` 에서 거부됨).
- **`scripts/validate-omo-config.py`** — doctor/JSON Schema 우회 자가 진단 스크립트. 4개 스키마를 Python 으로 시뮬레이션해서 정확한 위반 키 + 경로 (예: `agents.explore.fallback_models`) 출력. doctor 가 진단 메시지를 잘못 자를 때 정밀 진단용.
- **`scripts/diagnose-omo-tui.sh`** — opencode TUI 띄우고 Tab 순환 캡쳐 + plugin 등록 상태 확인. "Select agent" 모달에 sisyphus 등 omo agent 안 보이는 증상 진단용 (8절 패턴).

---

## 검증 기록 (2026-08-06)

| 단계 | 결과 |
|---|---|
| 첨부 config → 정식 위치 | ✅ `~/.omo/omo.jsonc` 적용 |
| 4단계 변환 (top-level 제거, agent fallback → models, reasoning 치환) | ✅ strict 위반 0건 |
| `bunx oh-my-opencode doctor` | ✅ `System OK` |
| `bunx oh-my-opencode doctor --verbose` 모델 override | ✅ **모든 agent 11개 + category 8개 ● 표시** (이전 세션의 ⚠️ 해결됨 — 핵심은 `_migrations` 마커 박아 startup migration의 잘못된 `reasoning` 변환을 차단) |
| TUI 첫 화면 `Build · <model> <provider>` | ✅ `Build · MiniMax-M3 MiniMax Token Plan (minimax.io)` (omo TUI 가 user config 모델로 부팅) |
| TUI Tab agent 순환 | ✅ `Build → Plan → Build → ...` (omo plugin 정상 로드, Tab 으로 11 agent 순환) |
| `opencode run --agent sisyphus` 비대화형 | ⚠️ 여전히 `agent not found` — **이건 omo 설계상 정상 동작** (omo agent 는 TUI `/agent <name>` 또는 `bunx oh-my-opencode run` (--agent 생략) 로만 동작. 비대화형 `--agent` 플래그는 opencode native registry 만 받음) |
| `~/.config/opencode/opencode.jsonc` plugin entry 복원 | ✅ migration 부작용으로 사라졌던 plugin entry 복원 → TUI "Select agent" 모달에 omo 빌트인 11개 표시 확인 (8절 패턴) |
| TUI 첫 화면 = `Sisyphus · MiniMax-M3 ...` | ✅ `default_agent: "sisyphus"` + `~/.config/opencode/agent/{sisyphus,hephaestus}.md` (`mode: primary`) 작성으로 default agent 강제 (9절 패턴). opencode 1.18.x sort shim 미작동 우회. |

**해결된 핵심 인사이트 (이전 ⚠️ → ✅)**: omo 빌트인 agent 디폴트 모델 override 는 **omo.jsonc 의 `agents.<name>.model` + `reasoningEffort` 정의로 정상 동작**한다. 이전 세션에서 `○` 만 보였던 이유는 두 가지 합류 — (1) `_migrations` 마커 미설정으로 startup `2026-08-reasoning-unification` migration 이 매 실행마다 raw file 을 `reasoning`(미허용) 으로 덮어쓰는 버그, (2) doctor 가 raw file 을 다시 strict 검증하면서 invalid 표시. **`_migrations: ["2026-08-reasoning-unification"]` 박고 처음부터 `reasoningEffort` 사용**하면 두 문제 모두 해소.

**완전 청소 → 재설치 패턴 실측 (2026-08-06)**: 사용자 "정상 PC 와 다르다" → 완전 제거 옵션 선택 → "백업 남기지 말라" 추가 지시. **3가지 함정** 동시 발견 + 우회 — (1) `brew uninstall opencode` 가 `ripgrep` autoremove → 즉시 `brew install ripgrep`, (2) `~/.omo/lsp-daemon/` 와 `~/.local/share/opencode/snapshot/` 가 `rm -rf` 직후 재생성 → daemon 종료 (`pkill` + `launchctl unload`) 후 sleep 10 → rm → sleep 5 → 재확인 패턴 확립, (3) `ls -la` 가 빈 디렉터리로 보여도 `ls -laR` 로 stamp/hash 파일 발견 → 단순 `total 0` 출력에 속으면 안 됨. 10절로 정형화.

## 9. `opencode.json` plugin entry 소실 패턴 (2026-08-06 실측)

omo v4.18+ 의 **`2026-07-opencode-config-unification` 마이그레이션이 `~/.config/opencode/opencode.json` 을 자동 정리**하면서 `plugin` entry 가 소실될 수 있음. `~/.omo/omo.jsonc` (config schema) 와는 별개의 문제 — **opencode 자체의 plugin 등록 entry** (`opencode.json`) 가 사라지는 것.

### 증상 (사용자 화면)

TUI 첫 화면 + `Tab` 키 또는 "Select agent" 모달:
- **omo 빌트인 agent 11개 (sisyphus, hephaestus, oracle, prometheus, atlas, momus, metis, librarian, explore, multimodal-looker, sisyphus-junior) 안 보임**
- `build`, `plan` native agent만 표시
- 모달 항목 옆에 `native` 라벨 표시 (omo plugin 미로드 상태의 시그널)

### 진단

```bash
bunx oh-my-opencode doctor
# ⚠ 1. oh-my-openagent is not registered
#    Plugin entry is missing from OpenCode configuration.
# ⚠ 2. Server plugin entry missing from opencode.json
#    The TUI plugin entry ("oh-my-openagent") is registered in tui.json,
#    but the server plugin (oh-my-openagent) is missing from opencode.json.
ls -la ~/.config/opencode/
# opencode.jsonc 가 있거나 (50 bytes 짜리 빈 상태) 없음
# opencode.json.backup 은 옛 plugin/mcp 정의 살아있음
```

### 복원 패턴

```python
import json, pathlib
BACKUP = pathlib.Path("~/.config/opencode/opencode.json.backup")
TARGET = pathlib.Path("~/.config/opencode/opencode.jsonc")  # 정식 위치
backup_cfg = json.loads(BACKUP.read_text())
new_cfg = {
    "$schema": backup_cfg.get("$schema", "https://opencode.ai/config.json"),
    "plugin": backup_cfg.get("plugin", ["oh-my-openagent@latest"]),
    "mcp": backup_cfg.get("mcp", {}),
}
TARGET.write_text(json.dumps(new_cfg, indent=2) + "\n")
```

복원 후 **opencode 재시작** (TUI 종료 후 새로 띄움). `tui.json`도 plugin 등록돼있는지 확인:
```bash
cat ~/.config/opencode/tui.json  # ["oh-my-openagent@latest"] 있어야 함
```

### 재발 방지

- `~/.config/opencode/opencode.json.backup` 파일을 **삭제하지 말 것** — plugin entry 손실 시 fallback
- migration 후 항상 `doctor` 실행 + `opencode.jsonc` 직접 grep으로 `plugin` 키 존재 확인
- omo installer 재실행도 같은 효과: `bunx oh-my-openagent install`

## 10. TUI 첫 화면이 `Build`로 시작하는 패턴 (2026-08-06 실측)

9절(plugin entry 복원)을 적용해도 **omo plugin은 로드되고 sisyphus 등 빌트인 agent는 TUI "Select agent" 모달에 표시되는데**, TUI 첫 화면 진입 시 **default agent가 여전히 `Build` (opencode native)**로 뜨는 경우가 있음. 사용자 의도는 "omo가 제대로 로드되면 sisyphus가 첫 화면에 떠야 함".

### 원인

opencode 1.18.x 의 `Agent.list()` 정렬이 **알파벳순**이라 `Build` 가 `Sisyphus` 보다 앞. omo v4.19.4 의 `installAgentSortShim()` 은 **opencode 1.4.x만 대응** (Remeda sortBy 동작 변경 때문) — 1.18.x 에서는 발동 안 함. 결과:
- plugin agent 등록은 됨 (`opencode agent list` 에 sisyphus 표시)
- TUI 첫 진입은 alphabetical 첫 항목인 `Build`로 시작

### 진단

```bash
# 1) omo plugin 정상 로드 + agent 등록 확인
opencode agent list | grep -E "^[a-z]"
# 기대: build, compaction, explore, general, plan, summary, title, hephaestus, sisyphus
# ❌ hephaestus / sisyphus 없으면 → 8절 패턴 (plugin entry 소실)

# 2) TUI 첫 화면 확인 (tmux)
tmux kill-session -t oc 2>/dev/null
tmux new-session -d -s oc "opencode"
sleep 6
tmux capture-pane -t oc -p | grep -E "·" | tail -3
# "Build · <model> <provider>" → omo plugin 동작 중이지만 default가 Build
tmux kill-session -t oc 2>/dev/null
```

### 해결: opencode native `default_agent` + `~/.config/opencode/agent/*.md`

opencode 의 native agent 정의 시스템이 plugin 등록보다 우선순위 높음. **두 단계로 default agent 를 강제**:

#### A. `~/.config/opencode/agent/<name>.md` 작성 (omo 빌트인 prompt 를 native 정의로 wrapping)

```markdown
---
name: sisyphus
description: Main orchestrator agent from oh-my-openagent
model: minimax-coding-plan/MiniMax-M3
mode: primary
reasoningEffort: max
---

You are Sisyphus, the main orchestrator agent from oh-my-openagent.

Your responsibilities:
- Plan complex coding tasks and break them down into steps
- Delegate work to specialized subagents (hephaestus, oracle, librarian, explore, etc.)
- Coordinate parallel work execution
- Maintain quality standards

Use Korean for communication with the user.
```

`mode: primary` 가 핵심 — 없으면 `(subagent)` 분류돼서 `default_agent` 에서 거부됨. `model` / `reasoningEffort` 는 omo.jsonc 와 일치시켜야 user override 효과 보존.

#### B. `~/.config/opencode/opencode.jsonc` 에 `default_agent` 추가

```jsonc
{
  "$schema": "https://opencode.ai/config.json",
  "plugin": ["oh-my-openagent@latest"],
  "default_agent": "sisyphus",
  "mcp": { ... }
}
```

opencode schema 공식 키 (`https://opencode.ai/config.json`): `"default_agent": {"type": "string", "description": "Default agent to use when none is specified. Must be a primary agent. Falls back to 'build' if not set or if the specified agent is invalid."}`. 빌트인 `Build` 가 fallback 디폴트.

#### 검증

```bash
# 1) 정식 opencode schema 키로 등록됐는지
opencode agent list | grep -E "^[a-z]"
# 기대: hephaestus (primary), sisyphus (primary) 등 9+ 개 표시

# 2) TUI 첫 화면
tmux kill-session -t oc 2>/dev/null
tmux new-session -d -s oc "opencode"
sleep 6
tmux capture-pane -t oc -p | grep -E "·" | tail -3
# 기대: "Sisyphus · MiniMax-M3 MiniMax Token Plan (minimax.io)" (사용자 의도대로)
tmux kill-session -t oc 2>/dev/null
```

#### 안 되는 대안 (실측 확인)

- `OPENCODE_DEFAULT_AGENT=sisyphus` env 변수 — TUI default 에 영향 없음
- `omo.jsonc` 의 `[opencode]` 블록에 `agent_order: ["sisyphus", ...]` — opencode 1.18.x 의 sort 가 무시 (shim 미작동)
- `default_run_agent: "sisyphus"` — `bunx oh-my-opencode run` CLI 에만 영향, TUI 무관
- `~/.zshrc` 에 env 설정 — TUI 무관 (실측)

> **opencode native schema 정식 출처**: `https://opencode.ai/config.json` (`default_agent` 키 정의). 11절 (references/omo-schema-keys-reference.md) 참조.

### 재발 방지

- opencode 업그레이드 시 sort 동작 바뀌면 shim 이 다시 작동할 수 있음 — 그땐 `.opencode/agent/*.md` 도 정리 검토
- user 가 `~/.config/opencode/agent/` 디렉토리 직접 삭제하면 default 가 `Build` 로 돌아감 — 의도치 않은 default 변경 알림 필요

## 11. 완전 청소 재설치 패턴 (clean uninstall + reinstall)

"설정이 정상 PC와 다르다" / "migration 백업이 너무 쌓였다" / "agent 가 안 보인다" 같은 누적 문제 시, 검증+수정보다 **완전 청소 → 재설치**가 더 빠른 경우가 있음. 사용자가 명시적으로 "완전 제거 → 재설치" 옵션을 선택하면 진행.

### 11.1 ⚠️ 핵심 함정: omo daemon 이 rm -rf 한 디렉터리를 즉시 재생성함 (2026-08-06 실측)

`~/.omo/lsp-daemon/` 와 `~/.local/share/opencode/snapshot/` 는 **omo LSP daemon + opencode snapshot 메커니즘이 백그라운드에서 유지**. `rm -rf` 직후 `ls -la` 는 빈 디렉터리로 보이지만 수 초 안에 하위 stamp / hash 파일이 다시 생성됨. **`rmdir` 실패나 `ls -laR` 로만 발견 가능**.

**증상**:
```bash
rm -rf ~/.omo/
ls -la ~/.omo/         # → total 0, . 과 .. 만 → "비어있음" �로 오해
rmdir ~/.omo/          # → "Directory not empty" 실패
ls -laR ~/.omo/        # → lsp-daemon/ 하위에 stamp 파일 다시 생성됨
```

**진단**:
```bash
ls ~/Library/LaunchAgents/ | grep -iE "opencode|oh-my|omo"
ps aux | grep -iE "opencode|oh-my|lsp-daemon" | grep -v grep
```

**해결** (daemon 종료 → 대기 → rm → 재확인):
```bash
pkill -f "opencode|oh-my|lsp-daemon" 2>/dev/null
launchctl unload ~/Library/LaunchAgents/*opencode* 2>/dev/null
sleep 10
rm -rf ~/.omo/ ~/.config/opencode/ ~/.local/share/opencode/ ~/.cache/opencode/
sleep 5
ls -laR ~/.omo/ ~/.local/share/opencode/ 2>&1 | head -10
# → "No such file or directory" 가 양쪽 모두 나오면 깨끗한 상태
```

### 11.2 ⚠️ brew uninstall opencode → ripgrep autoremove

`brew uninstall opencode` 가 **의존성 ripgrep 도 자동 제거**. Hermes `search_files` 가 `rg` 백엔드라 다른 도구(flywheel, re0, etc.)에서 필요할 가능성 높음. **항상 ripgrep 재설치**:

```bash
brew uninstall opencode
brew install ripgrep
```

**ripgrep 위치 검증 함정**: brew 는 `rg` 로 link 하고, `ripgrep` formula 명과 다른 이름. `which rg` 가 `/opt/homebrew/bin/rg` 이면 정상. `ls /opt/homebrew/bin/ripgrep` 가 "No such file" 이어도 정상임 (formula 명 ≠ bin 명). `rg --version` 로 최종 검증.

### 11.3 사용자 의도 신호 — 백업 보존 vs 완전 삭제

3-옵션 워크플로의 "[완전 제거 → 재설치 — 위험]" 사용자가 **추가로** "현재 설정 남기지 말고 모두 제거해" 같은 명시적 문구를 쓰면:

- ✅ **백업 단계 완전 생략** — `~/work/opencode-clean-*` 폴더도 만들지 않음
- ✅ **이전 단계의 스�샷도 삭제** (이미 만들었다면 `rm -rf`)
- ❌ **"혹시 모르니까 백업해두자" 같은 재확인 금지** — 결정됨, follow-up 1라운드 절약

**이전 워크플로 함정 (2026-08-06)**: 1단계의 `~/work/omo-reinstall-2026-08-06/` 폴더가 사용자 의도(모두 제거)와 충돌. 교정 후 삭제했으나 처음부터 안 만들었어야 했음. **provider (auth.json) 보존은 별개 결정** — 사용자가 명시하지 않으면 기본 보존하지 않음. 단, **provider 재등록은 매번 10분+ 작업**이므로 사용자 의도가 애매하면 1회 confirm 권장.

### 11.4 재설치 후 9단계 정형 레시피 (2026-08-06 실측)

```bash
# 1. 백업 (사용자가 명시적 거부 시 생략)
BACKUP=~/work/opencode-clean-$(date +%Y-%m-%d)
[ -n "$DO_BACKUP" ] && {
  mkdir -p $BACKUP
  cp -p ~/.local/share/opencode/auth.json $BACKUP/   # ← provider 재등록 안 하려면 필수
}

# 2. daemon 종료 (11.1 함정 방지)
pkill -f "opencode|oh-my|lsp-daemon" 2>/dev/null
launchctl unload ~/Library/LaunchAgents/*opencode* 2>/dev/null
sleep 5

# 3. brew uninstall + ripgrep 재설치 (11.2 함정)
brew uninstall opencode
brew install ripgrep

# 4. config / cache / db 삭제
rm -rf ~/.omo/ ~/.config/opencode/ ~/.local/share/opencode/ ~/.cache/opencode/

# 5. 5초 대기 후 재생성 여부 확인 (11.1 함정)
sleep 5
ls ~/.omo ~/.config/opencode ~/.local/share/opencode 2>&1 | grep -v "No such"
# → 빈 출력이면 성공

# 6. opencode 재설치 (Homebrew 정식 tap 또는 anomalyco/tap)
brew install opencode    # 또는: brew install anomalyco/tap/opencode
sleep 2
opencode --version       # 1.18.x 확인

# 7. omo plugin 등록 (bun global install)
bun install -g oh-my-openagent@latest
bunx oh-my-openagent install
sleep 2

# 8. Downloads 폴더에 떨어진 옛 config 청소 (8섹션 함정)
rm -f ~/Downloads/oh-my-openagent.json ~/Downloads/oh-my-openagent.jsonc

# 9. 정식 config 위치 + key 검증 (3섹션 / 2.4섹션)
ls -la ~/.omo/omo.jsonc ~/.config/opencode/opencode.jsonc ~/.config/opencode/tui.json
bunx oh-my-openagent doctor --verbose | grep -A 30 "Configured Models"
# 기대: 모든 agent + category 옆 ●
```

### 11.5 재설치 직후 5가지 silent fail 함정 (2026-08-06 실측)

재설치 후 **doctor 가 `System OK` 라도 다음 5가지를 못 잡음**:

1. **`reasoningEffort` / `fallback_models` 옛 키 사용** → "Deprecated" 18개 경고, Configured Models 가 `○` (8섹션 매트릭스 참조). → 6섹션 변환 패턴 적용.
2. **`[opencode]` 블록 안에 또 agents/categories 박힘** → top-level 과 in-memory merge 가 모호. → 4섹션 flatten 적용.
3. **`tui.json` 확장자 (`.jsonc` 아님)** 누락 → TUI plugin 안 떠서 "Select agent" 모달 비어 보임. → `tui.json` (확장자 없음) 별도 생성.
4. **`opencode.jsonc` 의 `plugin` entry 소실** → server plugin 부재. → 9섹션 패턴 (`opencode.json.backup` 에서 복원).
5. **`default_agent: sisyphus` + `agent/*.md` 미작성** → TUI 첫 화면이 `Build` 로 시작. → 10�션 패턴 (frontmatter `mode: primary` 필수).

### 11.6 재발 방지 / 부수 정리

- **daemon 종료 우선**: `rm -rf` 만 믿지 말 것. LaunchAgent + pkill 먼저
- **autoremove 의존성 추적**: brew formula uninstall 전 `brew deps --tree <formula>` 로 autoremove 후보 확인
- **bun cache (`~/.bun/install/cache/@opencode-ai`, ~868K)**: 보존해도 무방 — bunx 재실행 시 자동 재사용, 지우면 다음 실행이 더 느려짐
- **`brew cleanup` hint 가 출력에 묻힐 때**: `HOMEBREW_NO_INSTALL_CLEANUP=1` 로 cleanup 안 하거나, `--ignore-dependencies` 로 의존성 보존 가능
- **재설치 후 `bunx oh-my-openagent doctor --verbose` 첫 진단 권장**: `System OK` 만 보지 말고 `Configured Models` 의 `●` / `○` 까지 확인 — silent fail 5가지를 한 번에 잡음

## TUI 검증 패턴 (override 동작 확인)

`opencode run --agent <omo-agent>` 가 비대화형에서 실패해도 user override 가 실제로 적용됐는지는 TUI 부팅 화면으로 확인 가능:

```bash
# tmux 안에서 opencode TUI 띄우고 첫 화면 캡쳐
tmux kill-session -t oc 2>/dev/null
tmux new-session -d -s oc "opencode"
sleep 5
tmux capture-pane -t oc -p | grep -E "Build · .*Token|Provider" | head -3
tmux kill-session -t oc 2>/dev/null

# 기대 출력: "Build · <user-model> <provider-name>" (예: Build · MiniMax-M3 MiniMax Token Plan (minimax.io))
# ❌ 이 줄에 omo 빌트인 디폴트 (anthropic/claude-opus-5 등) 가 나오면 user override 미적용
```

DB 직접 조회로도 확인 가능:

```python
import sqlite3, json
c = sqlite3.connect('/Users/mac/.local/share/opencode/opencode.db').cursor()
c.execute("SELECT data FROM message ORDER BY time_created DESC LIMIT 1")
d = json.loads(c.fetchone()[0])
print(f"agent={d.get('agent')} modelID={d.get('modelID')} providerID={d.get('providerID')}")
# user override 적용 시: modelID = <user-config 모델>, providerID = <user-config provider>
```