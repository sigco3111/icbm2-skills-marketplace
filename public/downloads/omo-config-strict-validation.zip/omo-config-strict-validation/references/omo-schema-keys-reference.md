# omo Zod Schema 키 레퍼런스 (v4.19.4, 2026-08-06 검증)

omo (oh-my-openagent, npm dual-published as `oh-my-opencode`) v4.19.4 의 4개 Zod strict 스키마에서 허용되는 키와 실측 트랜스크립트 모음. doctor 가 위반 키를 잘못 자르거나 정확한 키 이름이 궁금할 때 참조.

> 소스: `~/.local/share/oh-my-openagent/packages/omo-config-core/src/schema/{config,agent,category,fallback-models}.ts`

## 1. OmoConfigSchema (최상위, `.strict()`)

```ts
export const OmoConfigSchema = z.object({
  $schema: z.string().optional(),
  categories: OmoCategoriesConfigSchema.optional(),
  agents: OmoAgentsConfigSchema.optional(),
  codegraph: OmoCodegraphSettingsSchema.optional(),
  task: OmoTaskSettingsSchema.optional(),
  teams: OmoTeamsConfigSchema.optional(),
  models: OmoModelCatalogSchema.optional(),
  "[opencode]": OmoOpenCodeHarnessConfigSchema.optional(),
  "[senpi]": OmoTypedHarnessConfigSchema.optional(),
  "[codex]": OmoTypedHarnessConfigSchema.optional(),
  profiles: z.record(z.string(), OmoConfigProfileSchema).default({}),
  _migrations: z.array(z.string()).optional(),
  legacy_migrations: z.record(z.string(), z.unknown()).optional(),
}).strict();
```

### 허용 키

| 키 | 비고 |
|---|---|
| `$schema` | JSON Schema URL (선택) |
| `categories`, `agents`, `codegraph`, `task`, `teams` | 빌트인 객체 |
| `models` | 모델 카탈로그 (별칭 → 풀 ID) |
| `[opencode]`, `[senpi]`, `[codex]` | harness 별 config 블록 |
| `profiles` | 프로필 정의 |
| `_migrations` | 적용된 migration ID 배열 |
| `legacy_migrations` | 옛 위치에서 자동 migration 시 기록 |

### 흔한 위반 키 (모두 reject)

| 키 | 이유 |
|---|---|
| `team_mode` | strict 위반 — 옛 위치에서 자동 migration 되긴 하지만 직접 두면 invalid |
| `background_task` | strict 위반 — 옛 위치에서 자동 migration 되긴 하지만 직접 두면 invalid |
| `disabled_agents`, `disabled_hooks`, `disabled_skills` | 옛 위치 schema 에는 있었지만 omo.jsonc 에는 없음 |
| `claude_code` | 옛 위치 schema |
| `providerConcurrency` | 옛 위치 schema (nested object) |
| `omo_agent`, `sisyphus_agent` | 옛 이름 (자동 migration 됨) |
| `experimental` | 옛 위치 schema |

## 2. OmoAgentDefSchema (agent 정의, `.strict()`)

```ts
export const OmoAgentDefSchema = z.object({
  description: z.string().optional(),
  prompt: z.string().optional(),
  model: z.string().optional(),
  models: z.array(OmoAgentModelEntrySchema).optional(),
  variant: z.string().optional(),
  reasoningEffort: OmoReasoningEffortSchema.optional(),
  tools: z.record(z.string(), z.boolean()).optional(),
  execution_mode: z.enum(["in-process", "process"]).optional(),
  background: z.boolean().optional(),
  max_depth: z.number().int().nonnegative().optional(),
  allowed_subagents: z.array(z.string()).optional(),
  disallowed_tools: z.array(z.string()).optional(),
  max_turns: z.number().int().nonnegative().optional(),
  temperature: z.number().min(0).max(2).optional(),
  disable: z.boolean().optional(),
}).strict();
```

### 허용 키

| 키 | 비고 |
|---|---|
| `description`, `prompt` | 메타 |
| `model` | 단일 모델 ID |
| `models` | 모델 체인 (primary + fallbacks) |
| `variant` | 자유 문자열 (omo 가 in-memory 변환) |
| `reasoningEffort` | enum (아래 5번) |
| `tools` | `{tool_name: bool}` 맵 |
| `execution_mode` | `"in-process"` or `"process"` |
| `background`, `disable`, `max_depth`, `max_turns`, `temperature` | 메타 |

### 흔한 위반 키

| 키 | 이유 / 해결 |
|---|---|
| **`fallback_models`** ❌ | **category 에서만 허용**. agent 에서는 `models: [primary, ...fallbacks]` 패턴 |
| `prompt_append` ❌ | category 전용 |
| `max_prompt_tokens` ❌ | category 전용 |
| `textVerbosity` ❌ | category 전용 |
| `maxTokens` ❌ | category 전용 (agent 는 미허용 — `models` 배열 entry 의 `maxTokens` 도 미허용) |
| `top_p` ❌ | category 전용 |
| `thinking` ❌ | category 전용 |
| `reasoning` ❌ | v4.19.4 migration 버그 출력 — `reasoningEffort` 로 치환 |

## 3. OmoCategoryConfigSchema (category 정의, `.strict()`)

```ts
export const OmoCategoryConfigSchema = z.object({
  description: z.string().optional(),
  model: z.string().optional(),
  fallback_models: OmoFallbackModelsSchema.optional(),  // ✅ category 만 허용!
  variant: z.string().optional(),
  temperature: z.number().min(0).max(2).optional(),
  top_p: z.number().min(0).max(1).optional(),
  maxTokens: z.number().optional(),
  thinking: OmoThinkingConfigSchema.optional(),
  reasoningEffort: OmoReasoningEffortSchema.optional(),
  textVerbosity: z.enum(["low", "medium", "high"]).optional(),
  tools: z.record(z.string(), z.boolean()).optional(),
  prompt_append: z.string().optional(),
  max_prompt_tokens: z.number().int().positive().optional(),
  is_unstable_agent: z.boolean().optional(),
  disable: z.boolean().optional(),
}).strict();
```

### category 전용 키 (agent 와 차이)

| 키 | 비고 |
|---|---|
| **`fallback_models`** ✅ | **여기만 허용** |
| `prompt_append`, `max_prompt_tokens` | 프롬프트 보정 |
| `textVerbosity` | `"low" \| "medium" \| "high"` |
| `top_p`, `thinking`, `is_unstable_agent` | 모델 튜닝 |

### category 위반 키

| 키 | 이유 |
|---|---|
| `models: [...]` ❌ | agent 에서만 허용 (category 에서는 `model` + `fallback_models` 패턴) |
| `reasoning` ❌ | v4.19.4 migration 버그 출력 |

## 4. OmoAgentModelEntrySchema (`models` 배열 내부, `.strict()`)

```ts
export const OmoAgentModelEntrySchema = z.union([
  z.string(),
  z.object({
    model: z.string(),
    variant: z.string().optional(),
    reasoningEffort: OmoReasoningEffortSchema.optional(),
  }).strict(),
]);
```

### 허용 형태

```jsonc
"models": [
  "provider/model-id",            // string entry — 단순 fallback
  {                                // object entry — primary + variant
    "model": "provider/model-id",
    "variant": "high",             // 자유 문자열
    "reasoningEffort": "high"      // enum
  }
]
```

### 흔한 위반 키 (object entry 안에서)

| 키 | 이유 |
|---|---|
| `temperature` ❌ | category fallback_models 에서만 허용 |
| `maxTokens` ❌ | category fallback_models 에서만 허용 |
| `thinking` ❌ | category fallback_models 에서만 허용 |
| `provider_options`, `providerOptions` ❌ | 미허용 |
| `textVerbosity` ❌ | category 만 |

## 5. OmoReasoningEffortSchema enum

```ts
export const OmoReasoningEffortSchema = z.enum([
  "none", "minimal", "low", "medium", "high", "xhigh", "max"
]);
```

### enum 값

| 값 | 의미 |
|---|---|
| `none` | 추론 비활성 |
| `minimal` | 최소 |
| `low` | 낮음 |
| `medium` | 중간 |
| `high` | 높음 |
| `xhigh` | 매우 높음 (omo 고유 — opencode native enum 과 구분) |
| `max` | 최대 |

### 흔한 위반 enum 값

| 값 | 이유 |
|---|---|
| `turbo` ❌ | 미허용 — 옛 omo config 의 GPT-5 turbo 매핑 |
| `default` ❌ | 미허용 |
| `auto` ❌ | 미허용 |
| `extra-high` ❌ | 미허용 — `xhigh` 가 정답 |
| `null` ❌ | 미허용 — 키 자체를 빼야 함 |

## 6. OmoFallbackModelsSchema (category 의 fallback_models 안에서만 사용)

```ts
export const OmoFallbackModelsSchema = z.union([
  z.string(),
  z.array(z.string()),
  z.array(OmoFallbackModelObjectSchema),
  z.array(z.union([z.string(), OmoFallbackModelObjectSchema])),
]);
```

### category fallback_models 객체 entry (`OmoFallbackModelObjectSchema`, `.strict()`)

```ts
z.object({
  model: z.string(),
  variant: z.string().optional(),
  reasoningEffort: OmoReasoningEffortSchema.optional(),
  temperature: z.number().min(0).max(2).optional(),  // ✅ 여기만 허용
  top_p: z.number().min(0).max(1).optional(),          // ✅ 여기만 허용
  maxTokens: z.number().optional(),                    // ✅ 여기만 허용
  thinking: OmoThinkingConfigSchema.optional(),        // ✅ 여기만 허용
}).strict()
```

**핵심**: `temperature`, `top_p`, `maxTokens`, `thinking` 는 **category 의 fallback_models 안의 객체**에서만 허용. agent 정의나 agent 의 models 배열에서는 미허용.

## 7. 실측 트랜스크립트 (2026-08-06)

### 7.1 첨부 config 그대로 두고 doctor 실행

```jsonc
// 첨부파일 일부
{
  "$schema": "https://raw.githubusercontent.com/code-yeongyu/oh-my-openagent/dev/assets/oh-my-openagent.schema.json",
  "agents": {
    "explore": {
      "model": "github-copilot/gpt-5.6-luna",
      "variant": "high",
      "fallback_models": ["minimax-coding-plan/MiniMax-M3"]   // ❌
    },
    ...
  },
  "team_mode": { ... },          // ❌
  "background_task": { ... }     // ❌
}
```

```
$ bunx oh-my-opencode doctor

⚠ 1 issue found:

1. Invalid configuration
   ../.omo/omo.jsonc: Invalid omo config at /Users/mac/.omo/omo.jsonc:
   agents.explore, agents.sisyphus-junior, agents.librarian,
```

**doctor 의 위반 키 자르기가 부정확**: `explore`, `sisyphus-junior`, `librarian` 만 invalid 표시하지만 `team_mode`, `background_task` 도 실제로 strict 위반. doctor 가 한 번에 하나의 카테고리만 보여주는 한계.

### 7.2 `variant` → `reasoning` 마이그레이션 버그

```
$ bunx oh-my-opencode doctor --verbose
...
═══ Configured Models ═══

Agents:
  ○ sisyphus: anthropic/claude-opus-5 (max) [capabilities: snapshot-backed]
  ...
```

이 시점에서 raw file 확인:

```bash
$ grep reasoning ~/.omo/omo.jsonc
"reasoning": "max",
"reasoning": "medium",
...
```

→ startup migration 이 `variant` → `reasoning`(미허용)으로 변환해버린 결과. **`_migrations: ["2026-08-reasoning-unification"]` 마커 박고 처음부터 `reasoningEffort` 사용**하면 해결.

### 7.3 해결 후 (모든 agent ●)

```
$ bunx oh-my-opencode doctor --verbose
...
═══ Configured Models ═══

Agents:
  ● sisyphus: minimax-coding-plan/MiniMax-M3 (max) [capabilities: snapshot-backed]
  ● hephaestus: minimax-coding-plan/MiniMax-M3 (medium) [capabilities: snapshot-backed]
  ● oracle: minimax-coding-plan/MiniMax-M3 (high) [capabilities: snapshot-backed]
  ● librarian: github-copilot/gpt-5.6-luna [capabilities: snapshot-backed]
  ● explore: github-copilot/gpt-5.6-luna [capabilities: snapshot-backed]
  ...

Categories:
  ● visual-engineering: minimax-coding-plan/MiniMax-M3 (max) [capabilities: snapshot-backed]
  ...

● = user override, ○ = provider fallback
```

→ **모든 agent + category 가 `●` (user override)** 표시. omo 빌트인 디폴트 (`anthropic/claude-opus-5`, `openai/gpt-5.6-sol` 등) 가 사용자 정의 모델로 정상 override 됨.

## 8. opencode 1.18.x native config / agent schema (omo 외부 의존)

9절 (TUI default = Build) 패턴은 **opencode 자체의 native schema**에 의존하므로 omo 스키마와 별도로 정리.

### 8.1 `~/.config/opencode/opencode.jsonc` 의 `default_agent` 키

opencode 1.18.x schema 출처: `https://opencode.ai/config.json`

```jsonc
{
  "default_agent": {
    "type": "string",
    "description": "Default agent to use when none is specified. Must be a primary agent. Falls back to 'build' if not set or if the specified agent is invalid."
  }
}
```

**3가지 제약**:
- `Must be a primary agent` — `mode: primary` 인 agent 만 등록 가능. subagent 는 invalid.
- `Falls back to 'build'` — invalid 한 agent 이름이면 opencode 의 native `build` agent 로 fallback. 사용자 의도와 무관.
- plugin agent 의 이름도 받지만, **plugin 미로드 시 fallback**.

### 8.2 `~/.config/opencode/agent/<name>.md` native agent 형식

| 필드 | 필수? | 의미 |
|---|---|---|
| `name` | ✅ | agent 식별자 |
| `description` | 권장 | UI / 모달 표시 |
| `model` | 권장 | `provider/model-id` 형식 |
| `mode` | 필수 (default agent 사용 시) | `"primary"` \| `"subagent"` \| `"all"`. `default_agent` 가리키려면 `"primary"` |
| `reasoningEffort` | 선택 | omo 와 같은 enum (`none`~`max`) |
| 본문 | ✅ | system prompt (markdown) |

**frontmatter 가 `mode: primary` 인 native agent 파일은 plugin 등록보다 우선순위 높음**. 즉 plugin agent 정의가 있어도 native agent 가 같은 이름으로 있으면 native 가 이김.

### 8.3 검증 가능 외부 신호

```bash
# opencode의 정식 agent list (mode 마커 확인)
opencode agent list | grep -E "^[a-z]"
# 각 행: "<name> (<mode>)" — primary / subagent 마커 확인

# opencode의 정식 schema 직접 확인
curl -s https://opencode.ai/config.json | python3 -c "import json,sys; s=json.load(sys.stdin); print(json.dumps({k:v for k,v in s['$defs'].items() if 'Agent' in k or 'agent' in k.lower()}, indent=2)[:2000])"
```

omo 와 opencode 의 schema 가 분리돼 있어 이중 검증이 필요. omo `doctor` OK 라도 TUI default agent 는 opencode native 정렬이 별도.