#!/bin/bash
# omo TUI 진단 스크립트 — opencode TUI에서 omo agent 빌트인이 보이는지 확인
#
# 증상: TUI "Select agent" 모달에 sisyphus, hephaestus 등이 안 보임
#       또는 build, plan native만 표시되고 omo plugin agent 안 뜸
#
# 출력:
#   - doctor 요약
#   - opencode.json / tui.json plugin 등록 상태
#   - tmux로 TUI 띄우고 Tab 5회 순환 캡쳐
#   - 각 단계의 agent 이름 + 모델 추출
#
# 사용: bash diagnose-omo-tui.sh
# 종료: tmux 세션 자동 정리

set -e

SESSION="omo_tui_diag"
echo "=== 1) doctor ==="
bunx oh-my-opencode doctor 2>&1 | head -10

echo ""
echo "=== 2) opencode config plugin 등록 상태 ==="
for f in ~/.config/opencode/opencode.json ~/.config/opencode/opencode.jsonc ~/.config/opencode/tui.json; do
    if [ -f "$f" ]; then
        echo "--- $f ---"
        cat "$f"
        echo ""
    fi
done

echo "=== 3) TUI agent 전환 캡쳐 (Tab 5회) ==="
tmux kill-session -t "$SESSION" 2>/dev/null || true
tmux new-session -d -s "$SESSION" "opencode"
sleep 6

echo "초기:"
tmux capture-pane -t "$SESSION" -p | grep -E "·" | tail -3

for i in 1 2 3 4 5; do
    tmux send-keys -t "$SESSION" Tab
    sleep 1
    agent=$(tmux capture-pane -t "$SESSION" -p | grep -oE "[A-Za-z][a-z\-]+ · " | head -1)
    echo "Tab #$i: ${agent:-<캡쳐 실패>}"
done

tmux kill-session -t "$SESSION" 2>/dev/null || true

echo ""
echo "=== 4) 진단 결과 해석 ==="
echo "Build → Plan → ... 전환 = omo plugin 정상 (sisyphus 등은 Plan/sisyphus 같은 위치)"
echo "Build → Build (전환 없음) = plugin 등록 안 됨 → 'Server plugin entry missing' 경고"
echo "→ 8절 패턴: ~/.config/opencode/opencode.jsonc plugin entry 복원 필요"