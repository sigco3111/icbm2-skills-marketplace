#!/usr/bin/env python3
"""
omo config strict 검증 자가 진단 스크립트 (v4.19.4 기준)

bunx oh-my-opencode doctor 가 진단 메시지를 자르거나 부정확할 때 정확한
위반 키 + 경로를 출력. 4개 Zod 스키마를 Python 으로 시뮬레이션.

사용법:
  python3 scripts/validate-omo-config.py [path/to/omo.jsonc]
  python3 scripts/validate-omo-config.py                # 기본 ~/.omo/omo.jsonc

종료 코드:
  0 — 위반 0건 (정상)
  1 — 위반 키 발견 (doctor 보다 정확한 경로 출력)
  2 — 파일 없음 / JSON 파싱 실패
"""
from __future__ import annotations
import json, sys, pathlib

# omo v4.19.4 스키마 정의 (omo-config-core/src/schema/ 에서 추출)
OMO_CONFIG_TOP_KEYS = {
    "$schema", "categories", "agents", "codegraph", "task", "teams", "models",
    "[opencode]", "[senpi]", "[codex]", "profiles", "_migrations", "legacy_migrations",
}
OMO_AGENT_DEF_KEYS = {
    "description", "prompt", "model", "models", "variant", "reasoningEffort",
    "tools", "execution_mode", "background", "max_depth", "allowed_subagents",
    "disallowed_tools", "max_turns", "temperature", "disable",
}
OMO_CATEGORY_DEF_KEYS = OMO_AGENT_DEF_KEYS | {
    "fallback_models", "top_p", "maxTokens", "thinking", "textVerbosity",
    "prompt_append", "max_prompt_tokens", "is_unstable_agent",
}
OMO_AGENT_MODEL_ENTRY_KEYS = {"model", "variant", "reasoningEffort"}
OMO_CATEGORY_FALLBACK_OBJECT_KEYS = OMO_AGENT_MODEL_ENTRY_KEYS | {
    "temperature", "top_p", "maxTokens", "thinking",
}
OMO_REASONING_EFFORT_ENUM = {"none", "minimal", "low", "medium", "high", "xhigh", "max"}


def validate(cfg: dict) -> list[str]:
    issues: list[str] = []

    # 1) 최상위 strict
    for k in cfg:
        if k not in OMO_CONFIG_TOP_KEYS:
            issues.append(f"TOP.unknown '{k}' (not in OmoConfigSchema allowed keys)")

    # 2) agents
    for name, defn in cfg.get("agents", {}).items():
        if not isinstance(defn, dict):
            issues.append(f"agents.{name}: not an object")
            continue
        for k in defn:
            if k not in OMO_AGENT_DEF_KEYS:
                issues.append(f"agents.{name}: unknown key '{k}'")
        if "reasoningEffort" in defn and defn["reasoningEffort"] not in OMO_REASONING_EFFORT_ENUM:
            issues.append(
                f"agents.{name}: reasoningEffort '{defn['reasoningEffort']}' "
                f"not in {OMO_REASONING_EFFORT_ENUM}"
            )
        # agent.models 내부
        for i, entry in enumerate(defn.get("models", [])):
            if isinstance(entry, dict):
                for k in entry:
                    if k not in OMO_AGENT_MODEL_ENTRY_KEYS:
                        issues.append(f"agents.{name}.models[{i}]: unknown key '{k}'")
                if entry.get("reasoningEffort") and entry["reasoningEffort"] not in OMO_REASONING_EFFORT_ENUM:
                    issues.append(
                        f"agents.{name}.models[{i}]: reasoningEffort '{entry['reasoningEffort']}' "
                        f"not in {OMO_REASONING_EFFORT_ENUM}"
                    )

    # 3) categories
    for name, defn in cfg.get("categories", {}).items():
        if not isinstance(defn, dict):
            issues.append(f"categories.{name}: not an object")
            continue
        for k in defn:
            if k not in OMO_CATEGORY_DEF_KEYS:
                issues.append(f"categories.{name}: unknown key '{k}'")
        if "reasoningEffort" in defn and defn["reasoningEffort"] not in OMO_REASONING_EFFORT_ENUM:
            issues.append(
                f"categories.{name}: reasoningEffort '{defn['reasoningEffort']}' "
                f"not in {OMO_REASONING_EFFORT_ENUM}"
            )
        # category.fallback_models 내부 (object 형태일 때만)
        for i, entry in enumerate(defn.get("fallback_models", [])):
            if isinstance(entry, dict):
                for k in entry:
                    if k not in OMO_CATEGORY_FALLBACK_OBJECT_KEYS:
                        issues.append(f"categories.{name}.fallback_models[{i}]: unknown key '{k}'")
                if entry.get("reasoningEffort") and entry["reasoningEffort"] not in OMO_REASONING_EFFORT_ENUM:
                    issues.append(
                        f"categories.{name}.fallback_models[{i}]: reasoningEffort "
                        f"'{entry['reasoningEffort']}' not in {OMO_REASONING_EFFORT_ENUM}"
                    )

    # 4) 명백한 흔한 함정 경고
    if "fallback_models" in cfg.get("agents", {}).get("sisyphus", {}):
        issues.append(
            "HINT: agents.sisyphus has 'fallback_models' — agent 정의에서는 미허용. "
            "category 로 옮기거나 'models' 배열 패턴으로 변환하세요."
        )
    if "reasoning" in cfg:
        issues.append(
            "HINT: 최상위에 'reasoning' 키 발견 — v4.19.4 migration 버그 출력입니다. "
            "'reasoningEffort' 로 치환 + '_migrations' 마커 필요."
        )

    return issues


def main() -> int:
    path = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "~/.omo/omo.jsonc").expanduser()
    if not path.exists():
        print(f"❌ 파일 없음: {path}", file=sys.stderr)
        return 2
    try:
        cfg = json.loads(path.read_text())
    except json.JSONDecodeError as e:
        print(f"❌ JSON 파싱 실패: {e}", file=sys.stderr)
        return 2

    issues = validate(cfg)
    if not issues:
        print(f"✅ {path}: 위반 0건 — 모든 키가 OmoConfigSchema / OmoAgentDefSchema / OmoCategoryConfigSchema strict 검증 통과")
        print(f"   다음 단계: bunx oh-my-opencode doctor 로 startup 검증")
        return 0

    print(f"❌ {path}: 위반 {len(issues)}건 발견\n")
    for i in issues:
        print(f"  - {i}")
    print(f"\n상세 가이드: bunx oh-my-opencode doctor + doctor --verbose")
    print(f"             omo-config-strict-validation SKILL 의 '2단계' 참조")
    return 1


if __name__ == "__main__":
    sys.exit(main())