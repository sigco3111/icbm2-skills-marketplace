---
name: pdf-report
description: "한국어 PDF 보고서 생성 — fpdf2 + Apple SD Gothic Neo 폰트로 한글 지원 PDF 문서 생성"
tags: [pdf, report, korean, document, productivity]
---

# PDF Report Generator (한국어)

fpdf2를 사용하여 한국어 PDF 보고서를 생성합니다.

## 전제 조건

- `fpdf2` 패키지 (시스템에 설치됨)
- Apple SD Gothic Neo 폰트 (macOS 기본 탑재)

## 한글 폰트 준비

스크립트 실행 전 반드시 TTC에서 TTF를 추출해야 합니다:

```python
from fontTools.ttLib import TTCollection

ttc = TTCollection('/System/Library/Fonts/AppleSDGothicNeo.ttc')
ttc[0].save('/tmp/AppleSDGothicNeoRegular.ttf')  # Regular
ttc[6].save('/tmp/AppleSDGothicNeoBold.ttf')       # Bold
```

## 기본 템플릿

```python
from fpdf import FPDF

class KRReport(FPDF):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.add_font('SDGothic', '', '/tmp/AppleSDGothicNeoRegular.ttf')
        self.add_font('SDGothic', 'B', '/tmp/AppleSDGothicNeoBold.ttf')

    def header(self):
        self.set_font('SDGothic', 'B', 10)
        self.set_text_color(120, 120, 120)
        self.cell(0, 8, 'ICBM2 Report', align='L')
        self.cell(0, 8, 날짜, align='R', new_x="LMARGIN", new_y="NEXT")
        self.set_draw_color(200, 200, 200)
        self.line(10, self.get_y(), 200, self.get_y())
        self.ln(5)

    def footer(self):
        self.set_y(-15)
        self.set_font('SDGothic', '', 8)
        self.set_text_color(150, 150, 150)
        self.cell(0, 10, f'{self.page_no()}/{{nb}}', align='C')

    def section_title(self, title):
        self.set_font('SDGothic', 'B', 14)
        self.set_text_color(30, 30, 80)
        self.cell(0, 10, title, new_x="LMARGIN", new_y="NEXT")
        self.set_draw_color(30, 30, 80)
        self.line(10, self.get_y(), 200, self.get_y())
        self.ln(3)

    def sub_title(self, title):
        self.set_font('SDGothic', 'B', 11)
        self.set_text_color(60, 60, 60)
        self.cell(0, 8, title, new_x="LMARGIN", new_y="NEXT")
        self.ln(1)

    def body_text(self, text):
        self.set_font('SDGothic', '', 10)
        self.set_text_color(40, 40, 40)
        self.multi_cell(0, 5.5, text)
        self.ln(2)

    def add_table(self, headers, rows, col_widths=None):
        if col_widths is None:
            col_widths = [190 / len(headers)] * len(headers)
        
        # 헤더
        self.set_font('SDGothic', 'B', 9)
        self.set_fill_color(30, 30, 80)
        self.set_text_color(255, 255, 255)
        for i, h in enumerate(headers):
            self.cell(col_widths[i], 8, h, border=1, fill=True, align='C')
        self.ln()
        
        # 데이터 행
        self.set_font('SDGothic', '', 8.5)
        self.set_text_color(40, 40, 40)
        for row_idx, row in enumerate(rows):
            self.set_fill_color(245, 245, 250) if row_idx % 2 == 0 else self.set_fill_color(255, 255, 255)
            
            max_lines = 1
            for i, cell_text in enumerate(row):
                lines = self.multi_cell(col_widths[i], 6, str(cell_text), dry_run=True, output="LINES")
                max_lines = max(max_lines, len(lines))
            row_height = 6 * max_lines
            
            # 페이지 나눔 처리
            if self.get_y() + row_height > 270:
                self.add_page()
                self.set_font('SDGothic', 'B', 9)
                self.set_fill_color(30, 30, 80)
                self.set_text_color(255, 255, 255)
                for i, h in enumerate(headers):
                    self.cell(col_widths[i], 8, h, border=1, fill=True, align='C')
                self.ln()
                self.set_font('SDGothic', '', 8.5)
                self.set_text_color(40, 40, 40)
            
            y_start = self.get_y()
            x_start = self.get_x()
            for i, cell_text in enumerate(row):
                x = x_start + sum(col_widths[:i])
                self.set_xy(x, y_start)
                self.multi_cell(col_widths[i], 6, str(cell_text), border=1, fill=True)
            self.set_y(max(self.get_y(), y_start + row_height))

pdf = KRReport()
pdf.alias_nb_pages()
pdf.set_auto_page_break(auto=True, margin=20)
```

## 사용 방법

1. `execute_code`로 스크립트 작성 후 `terminal`로 실행 (샌드박스에 fpdf2 없음)
2. 폰트 추출 → 스크립트 작성 → `python3 script.py`로 실행
3. 출력 경로: `~/.hermes/data/` 권장

## 주의사항

- **모든 PDF는 한국어로 작성** (주인님 기본 설정)
- 샌드박스 Python에는 fpdf2가 없으므로 반드시 로컬 `python3`로 실행
- `dry_run=True, output="LINES"` 사용 (`split_only`는 deprecated)
- 테이블 `col_widths` 합이 190이 되도록 조정 (A4 기준, 좌우 여백 10mm)
- `/tmp/` 폰트 파일은 세션 재시작 시 사라짐 — 매번 추출 필요
