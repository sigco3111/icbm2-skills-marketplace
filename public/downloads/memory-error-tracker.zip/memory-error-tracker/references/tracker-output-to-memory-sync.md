# Tracker 출력 → 메모리 동기화 패턴

`memory_error_tracker.py`는 최근 72시간 출력을 분류하고 상태 JSON을 갱신하지만, 현재 구현은 `issues.md`나 `MEMORY.md` 본문을 직접 수정하지 않는다. `needs_memory_update: true`는 **에이전트가 후속 동기화를 수행해야 한다는 신호**다.

## 실행 후 필수 순서

1. JSON 출력의 `new_issues`, `resolved_issues`, `categories`, `needs_memory_update`를 보존한다.
2. `new_issues`가 있으면 같은 라인에 카테고리 키워드와 실제 에러 마커가 함께 있는지 원문으로 교차 검증한다.
3. 진짜 신규 카테고리만 `memory/issues.md`에 다음 `ISS-NNN`으로 추가한다. 단어 매칭 FP는 새 ISS로 만들지 않는다.
4. `resolved_issues`는 기존 ISS와 연결한다. 단순 카테고리 소멸만으로 종료하지 말고, cron monitor의 critical/recoverable 0 또는 최신 잡 상태 등 독립 증거로 재확인한다.
5. `memory/issues.md`의 해당 행과 당일 점검 섹션을 갱신한다.
6. 알려진 이슈 요약을 `memory/MEMORY.md`와 루트 `MEMORY.md`에 동기화한다. 두 파일이 모두 존재하면 역할을 확인하고 서로 모순되지 않게 갱신한다.
7. 파일 재조회로 신규/해결 상태와 날짜가 실제 반영됐는지 검증한다.

## 판정 예시

- `YouTube: 1 → 0`: 기존 해결 ISS의 재확인으로 기록. 새 ISS 생성 불필요.
- `Cron Timeout: 2 → 0`: monitor에서 critical/recoverable도 0이면 기존 timeout 급증 ISS를 해결 처리할 수 있다.
- `needs_memory_update: false`: 당일 요약이 필요한 통합 정비에서는 카운트만 기록하고 이슈 상태는 바꾸지 않는다.

## 흔한 함정

- 스크립트 설명의 “issues.md + MEMORY.md 업데이트” 문구만 믿고 파일 변경을 가정하지 않는다. 현재 구현은 상태 저장과 JSON 출력까지만 한다.
- Self-Healer 감지 건수를 그대로 실제 에러 수로 쓰지 않는다. 같은 원인이 `missing_secret`과 `missing_file`로 중복될 수 있고, 출력 본문 재인용이 `output_error`로 잡힐 수 있다.
- Notion의 `에러 수`에는 raw detector 건수보다 교차 검증 후 남은 실제 운영 이슈 수를 기록한다.
