---
name: memory-error-tracker
description: 크론잡 출력 파일을 스캔하여 에러를 자동 추적 — issues.md + MEMORY.md 동기화
tags: [memory, error-tracking, automation, cron]
---

# Memory Error Tracker

크론잡 출력 파일을 스캔하여 에러를 자동으로 감지하고, `memory/issues.md`와 `MEMORY.md`를 업데이트합니다.

## 트리거 조건
- 매크론 자동 실행 (심야 통합 점검 03:30 직후 권장)
- 수동 실행: `python3 ~/.hermes/scripts/memory_error_tracker.py [--dry-run]`

## 핵심 설계 원칙

**에러는 단순 키워드 매칭이 아니라, "에러 마커 + 키워드" 조합으로 판정합니다.**

예: "stock"이라는 단어가 블로그 카테고리("투자/경제")로Mention만 된 경우 → 에러가 아님
예: "stock" + "❌" 또는 "error"가 동시에 있는 경우 → 실제 에러

## 스캔 범위
- `~/.hermes/cron/output/` 디렉토리의 모든 `.md` 파일
- 기본: 최근 72시간
- 에러 마커: `❌`, `error`, `exception`, `traceback`, `failed`, `⚠️`, `timeout`, `refused`, `rejected`, `unauthorized`, `404`

## 카테고리 분류 (개선됨)

| 카테고리 | 키워드 | 추가 조건 |
|---------|--------|---------|
| NotebookLM | `notebooklm` | 에러 마커 필수 |
| YouTube | `youtube` | 에러 마커 필수 |
| Notion Idea (DEAD) | `notion_idea` | 에러 마커 필수 |
| News-to-Wiki | `news_to_wiki` | 에러 마커 필수 |
| Stock Market | `주식 market`, `시황`, `코스피`, `코스닥`, `stock market`, `nyse` | 에러 마커 필수 + harmless 필터 |
| RSS Feeds | `rss`, `feed` | 에러 마커 필수 |
| GitHub | `REJECTED`, `secret scanning` | 항상 에러로 분류 |
| Cron Timeout | `timeouterror`, `605s`, `timed out` | 에러 마커 필수 |
| Sandbox | `sandbox`, `샌드박스` | 에러 마커 필수 |

### Harmless 패턴 (false positive 방지)

다음 패턴이 키워드와 함께 Mention되면 → 에러로 분류하지 않음:

```
투자/경제, 투자&경제, 경제 뉴스, stock/경제, market closed,
주말, 야간 장, holiday, after hours, market digest, 경제 브리핑
```

## 실행

```bash
# Dry run (상태 저장 없이 테스트)
python3 ~/.hermes/scripts/memory_error_tracker.py --dry-run

# 실제 실행 (상태 저장 + JSON 출력)
python3 ~/.hermes/scripts/memory_error_tracker.py
```

## 출력 형식

```
[2026-04-30T07:00] Memory Error Tracker Report
총 에러 파일 수: 26개

📊 카테고리별 현황:
     Other: 10개
     NotebookLM: 8개
     GitHub: 3개
     Notion Idea (DEAD): 3개
     Stock Market: 1개
     YouTube: 1개

[JSON OUTPUT]
{"new_issues": {}, "resolved_issues": {...}, ...}
```

## 메모리 업데이트 규칙

- **새 에러 카테고리 발견** → `issues.md`에 ISS-NNN으로 추가
- **기존 이슈와 동일 에러 반복** → 횟수만 증가
- **해결됨으로 표시된 이슈 재발생** → `진행중`으로 복원
- **MEMORY.md의 `알려진 이슈`**도同步 업데이트
- `needs_memory_update: true`일 때만 실제 메모리 파일 갱신

## ⚠️ 일반적인 false positive 패턴 (주의)

| 패턴 | 원인 | 해결 |
|------|------|------|
| Stock Market 36개 | "투자/경제" 카테고리 Mention | harmless 패턴으로 자동 필터링 |
| RSS Feed 205개 | RSS 키워드가 content에 Mention | 에러 마커 필수 규칙으로 자동 필터링 |
| "Notion Idea" 3개 | 스킬 프롬프트에 `notion_idea_token.txt` 참조 | 토큰 파일명 변경 후 72시간 지나면 자동 정리 |

## ⚠️ Secret 토큰 유출 주의

스킬 파일(SKILL.md)에 실제 토큰 값(예: `vcp_xxx`, `sk-xxx`)을 적지 마세요.
- 스킬 → generate-skills-data.py → skills.json → GitHub 푸시 → **secret scanning 탐지**
- 실제 토큰 값 대신 `~/.hermes/secrets/<name>.txt` 형식의 파일 경로만 기재
- 토큰이 유출되면: (1) 즉시 rotating, (2) SKILL.md에서 실제 값 제거, (3) GitHub unblock URL 클릭

## 종료 상태
- 0: 정상 (신규 에러 없음)
- 1: 신규 에러 발견 (issue registry 업데이트됨)
