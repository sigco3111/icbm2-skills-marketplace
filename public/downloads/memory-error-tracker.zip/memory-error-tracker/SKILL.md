---
name: memory-error-tracker
description: 크론잡 출력 파일을 스캔하여 에러를 자동 추적 — issues.md + MEMORY.md 동기화
tags: [memory, error-tracking, automation, cron]
---

# Memory Error Tracker

크론잡 출력 파일을 스캔하여 에러를 자동으로 감지하고, `memory/issues.md`와 `MEMORY.md`를 업데이트합니다.

## 트리거 조건
- 매크론 자동 실행 (매일 1회 권장)
- 수동 실행: 직접 호출

## 스캔 범위
- `~/.hermes/cron/output/` 디렉토리의 모든 `.md` 파일
- 에러 키워드: `❌`, `ERROR`, `Traceback`, `404`, `500`, `Timeout`, `REJECTED`

## 카테고리 분류
| 카테고리 | 키워드/패턴 |
|---------|-----------|
| NotebookLM | `notebooklm` in filename or content |
| YouTube | `youtube` in content |
| Notion Idea (DEAD) | `notion_idea` in content or filename |
| News-to-Wiki | `news_to_wiki` in content |
| Stock Market | `stock` in content |
| RSS Feeds | `rss`, `feed` in content |
| GitHub | `REJECTED`, `secret scanning` |
| Cron Timeout | `TimeoutError`, `605s` |

## 실행

```bash
python3 << 'EOF'
import subprocess, re
from pathlib import Path
from datetime import datetime

CRON_BASE = Path.home() / ".hermes" / "cron" / "output"
ISSUES_FILE = Path.home() / ".hermes" / "memory" / "issues.md"

def scan_errors():
    errors = {}
    for job_dir in CRON_BASE.iterdir():
        if not job_dir.is_dir():
            continue
        for output_file in job_dir.glob("*.md"):
            content = output_file.read_text(errors="ignore")
            if any(kw in content for kw in ["❌", "ERROR", "Traceback", "404", "REJECTED"]):
                # Categorize
                if "notebooklm" in content.lower():
                    cat = "NotebookLM"
                elif "youtube" in content.lower():
                    cat = "YouTube"
                elif "notion_idea" in content.lower():
                    cat = "Notion Idea (DEAD)"
                elif "news_to_wiki" in content.lower():
                    cat = "News-to-Wiki"
                elif "stock" in content.lower():
                    cat = "Stock Market"
                elif "rss" in content.lower() or "feed" in content.lower():
                    cat = "RSS Feeds"
                elif "REJECTED" in content or "secret scanning" in content:
                    cat = "GitHub"
                elif "TimeoutError" in content or "605s" in content:
                    cat = "Cron Timeout"
                else:
                    cat = "Other"
                
                if cat not in errors:
                    errors[cat] = 0
                errors[cat] += 1
    
    return errors

errors = scan_errors()
print(f"[{datetime.now().strftime('%Y-%m-%d %H:%M')}] Error scan:")
for cat, count in sorted(errors.items(), key=lambda x: -x[1]):
    print(f"  {cat}: {count}개")
EOF
```

## 출력 형식
```
[2026-04-28 12:00] Error scan:
  RSS Feeds: 205개
  NotebookLM: 33개
  Notion Idea (DEAD): 22개
  YouTube: 2개
  ...
```

## 메모리 업데이트 규칙
- 새 에러 카테고리 발견 → `issues.md`에 ISS-NNN으로 추가
- 기존 이슈와 동일 에러 반복 → 횟수만 증가
- 해결됨으로 표시된 이슈 재발생 → `진행중`으로 복원
- MEMORY.md의 `알려진 이슈`도同步 업데이트

## 종료 상태
- 0: 정상 (신규 에러 없음)
- 1: 신규 에러 발견 (issue registry 업데이트됨)
