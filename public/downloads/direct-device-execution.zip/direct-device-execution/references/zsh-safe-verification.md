# zsh Shell Script Safe Verification (Hermes 도구 환경)

Hermes의 `terminal` 도구는 **임시 bash 환경**에서 실행됨 (실제 zsh 세션이 아님). 이 환경에서 `source ~/.zshrc`나 zsh 전용 스크립트를 검증하면 잘못된 결과가 나옴.

## 문제 진단 (왜 도구 환경에서 zshrc가 깨져 보일까?)

```bash
# 도구 환경에서 실행해보면:
$ echo $SHELL
/bin/zsh                # ← /etc/passwd 값 (잘못된 신호)

$ ps -p $$ -o comm=
/opt/homebrew/bin/bash  # ← 실제 컨텍스트 (진짜 신호)
```

`bindkey`, `setopt`, `zsh/parameter`, `(I)` 같은 parameter expansion flag는 zsh 전용. bash에서 실행하면 모두 깨짐.

## 결정적 검증 패턴 (그대로 복붙)

### 1. zshrc 무결성 + 주요 통합 검증

```bash
zsh -c 'source ~/.zshrc 2>&1; echo "---EXIT=$?---"; \
  echo "=== bindkey (fzf 매핑 확인) ==="; \
  bindkey | grep -E "\^R|\^T|\\\\ec" | head -5; \
  echo "=== direnv hook ==="; \
  typeset -f _direnv_hook >/dev/null 2>&1 && echo "OK" || echo "FAIL"; \
  echo "=== fzf ==="; \
  command -v fzf >/dev/null && fzf --version | head -1 || echo "NOT INSTALLED"'
```

**해석 기준**:
- `EXIT=0` + 빈 에러 줄 → zshrc 정상
- `EXIT=0` + 에러 출력 → zshrc 안에 무해한 source 에러 (예: `compdef` 미정의). EXIT가 0이면 실제로는 정상.
- `EXIT≠0` → 진짜 망가짐. 어느 라인이 실패하는지 격리 필요.

### 2. 격리 테스트 (한 줄씩 떼어서)

```bash
# brew 공식 fzf 스크립트 — 깨지는지 확인
zsh -c 'source /opt/homebrew/opt/fzf/shell/key-bindings.zsh 2>&1; echo EXIT=$?'

# 사용자 커스텀 라인이 깨지는지 확인
zsh -c 'source <(fzf --zsh) 2>&1; echo EXIT=$?'
```

### 3. process substitution 위험도

```bash
# 위험 패턴 (zsh에서 깨질 수 있음)
source <(fzf --zsh)
source <(starship init zsh)
eval "$(starship init zsh)"  # ← eval은 OK, source는 위험

# 안전 패턴 (정적 파일 경로)
source /opt/homebrew/opt/fzf/shell/completion.zsh
```

## fzf 안전 통합 패턴 (복붙용)

`~/.zshrc` 끝에 그대로 추가:

```bash
# fzf: completion만 로드
if [ -f /opt/homebrew/share/zsh/site-functions/_fzf ]; then
  source /opt/homebrew/share/zsh/site-functions/_fzf 2>/dev/null
fi

# fzf key bindings (수동 — brew 공식 스크립트는 zsh 비호환)
if command -v fzf >/dev/null 2>&1; then
  bindkey '^T' fzf-file-widget     # Ctrl+T: 파일 fuzzy
  bindkey '^R' fzf-history-widget  # Ctrl+R: 히스토리
  bindkey '\ec' fzf-cd-widget      # Alt+C: cd
fi

# direnv
if command -v direnv >/dev/null 2>&1; then
  eval "$(direnv hook zsh)"
fi
```

## 자주 함께 깨지는 brew 패키지 list (검증 후 사용)

| 패키지 | zsh 호환 init | 안전한 init 방식 |
|---|---|---|
| `fzf` | ❌ key-bindings.zsh (bash 전용) | 수동 bindkey 등록 |
| `starship` | ✅ `eval "$(starship init zsh)"` | 그대로 OK |
| `direnv` | ✅ `eval "$(direnv hook zsh)"` | 그대로 OK |
| `zoxide` | ✅ `eval "$(zoxide init zsh)"` | 그대로 OK |
| `zsh-autosuggestions` | ✅ `source $(brew --prefix)/share/zsh-autosuggestions/zsh-autosuggestions.zsh` | 정적 경로 |
| `zsh-syntax-highlighting` | ✅ 동일 패턴 (정적 경로) | 정적 경로 |
| `atuin` | ✅ `eval "$(atuin init zsh)"` | 그대로 OK |

**fzf만 유일하게 예외**. 다른 패키지는 brew 안내대로 따라가도 대부분 안전.

## 신호로 셸 환경 빨리 식별하기

```bash
# 5초 진단 (실행 후 결정)
echo "SHELL=$SHELL"; ps -p $$ -o comm= | tr -d ' '; \
  echo "BASH_VERSION=${BASH_VERSION:-n/a}"; \
  echo "ZSH_VERSION=${ZSH_VERSION:-n/a}"; \
  command -v zsh >/dev/null && zsh --version || echo "no zsh"
```

| 출력 패턴 | 의미 | 다음 행동 |
|---|---|---|
| `ZSH_VERSION=5.x`, `BASH_VERSION=n/a` | 진짜 zsh 세션 | 그대로 진행 |
| `BASH_VERSION=5.x`, `ZSH_VERSION=n/a` | 도구 환경 bash | zshrc 검증 시 `zsh -c` 래핑 필수 |
| 둘 다 있음 | 의심스러움 — `zsh -c` 래핑 권장 |