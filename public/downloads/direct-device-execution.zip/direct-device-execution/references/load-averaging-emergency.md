# Load Average 폭주 + Telegram 무응답 — 응급 진단 (2026-07-05)

증상: Mac PC 정상 동작 + Telegram 봇 N시간~수십 시간 답 없음. Load average 평소 1~5 → 50+ 급등. Hermes 게이트웨이 살아있음 (`launchctl list | grep hermes` PID > 0). `~/.hermes/cron/ticker_heartbeat` 갱신 중이지만 큐 처리 안 됨.

## 5분 진단 (검증된 순서)

### 1단계: 시스템 핵심 4축 (30초)

```bash
# Load average
uptime | awk -F'load averages:' '{print $2}'
sysctl -n vm.loadavg

# Free RAM
vm_stat | grep "Pages free:" | awk '{printf "%.1f MB\n", $3 * 16 / 1024}'

# 스왑
sysctl vm.swapusage | awk '{print "used="$3, "free="$5}'

# 좀비 카운트
ps -A -o stat | grep -c "^Z"
```

**판정 기준**:
- Load > 30 (코어 10개면) → 🚨 폭주
- Free RAM < 200MB + 스왑 > 80% → 🚨 메모리 압박
- 좀비 > 0 → 별도 처리

### 2단계: 폭주 주범 후보 (1분)

```bash
# CPU TOP 15
ps -A -o pid,%cpu,%mem,rss,etime,stat,command | sort -rnk2 | head -15

# RSS TOP 15 (메모리 먹는 놈)
ps -A -o pid,%cpu,%mem,rss,etime,stat,command | sort -rnk4 | head -15
```

**흔한 주범**:
- `opencode run --model ...` 워커 다수 (oh-my-openagent 폭주)
- `node` LSP 데몬 다수
- `python3` cron 워커 누적

### 3단계: 좀비 vs 활성 분류 (P15 패턴, 30초)

```bash
# etime 4축 분류 (STAT + CPU + RSS + PPID)
ps -A -o pid,etime,%cpu,rss,stat,ppid,command | awk '
/opencode run --model/ && !/awk/ {
  e=$2
  total_h = 0
  if (e ~ /^[0-9]+-/) {
    split(e, a, "-"); split(a[2], t, ":")
    total_h = a[1]*24 + t[1]; if (t[2] != "") total_h += t[2]/60
  } else if (e ~ /:/) {
    n = split(e, a, ":")
    if (n==3) total_h = a[1] + a[2]/60
    else total_h = a[1]/60
  }
  
  # 4축 교차
  cpu_idle = ($4+0 < 1)
  rss_small = ($5+0 < 60000)
  stat_sleep = ($6 ~ /^S/)
  orphan = ($7 == 1)
  stat_running = ($6 ~ /^R/)
  
  is_zombie = cpu_idle && rss_small && stat_sleep && orphan
  is_active = stat_running || ($4+0 > 5)
  
  tag = is_zombie ? "🟥 좀비" : is_active ? "💎 활성" : "🟡 미분류"
  printf "%-7s etime=%-12s CPU=%-4s RSS=%-7s STAT=%-3s PPID=%-3s [%s]\n",
         $1, $2, $4, $5, $6, $7, tag
}'
```

**출력 예시** (2026-07-05):
```
37553   etime=02:51        CPU=22.2 RSS=429856  STAT=S+  PPID=1   [💎 활성]
38707   etime=01:35        CPU=34.4 RSS=455184  STAT=R+  PPID=1   [💎 활성]
```

### 4단계: 사용자 보고 → kill 승인 (1분)

표 형식으로 사용자 보고:
- 좀비 후보 N개 (4축 모두 일치)
- 활성 의심 N개 (CPU 또는 STAT=R 중 하나라도)
- 미분류 N개 (사용자 판단 요청)

**승인 옵션 제시**:
- **A. 안전 kill (P15+4축 분류된 좀비만)**
- **B. 더 강력 (좀비 + 미분류 포함)**
- **C. 신중 (5개 파일럿 → 10초 대기 → 결과 보고 → 잔여 결정)**
- **D. 재부팅 (사용자 수동)**

### 5단계: 안전한 kill 실행 (P16 패턴, 2분)

```bash
# C 안: 5개 파일럿
ZOMBIES=$(ps -A -o pid,etime,%cpu,rss,stat,ppid,command | awk '
/opencode run --model/ && !/awk/ {
  e=$2
  total_h = 0
  if (e ~ /^[0-9]+-/) {
    split(e, a, "-"); split(a[2], t, ":")
    total_h = a[1]*24 + t[1]
  } else if (e ~ /:/) {
    n = split(e, a, ":")
    if (n==3) total_h = a[1]
  }
  cpu_idle = ($4+0 < 1)
  rss_small = ($5+0 < 60000)
  stat_sleep = ($6 ~ /^S/)
  orphan = ($7 == 1)
  if (cpu_idle && rss_small && stat_sleep && orphan) print $1
}' | head -5)

for pid in $ZOMBIES; do
  kill -15 "$pid" 2>&1
done
sleep 5

# 결과 확인
ALIVE=0; for pid in $ZOMBIES; do
  ps -p "$pid" -o pid 2>/dev/null | grep -q "^$pid" && ALIVE=$((ALIVE+1))
done
echo "[파일럿 생존] $ALIVE/5"

# 0/5면 SIGTERM 잘 동작. 5/5 살아있으면 kill -9 필요 → 재보고 후 결정
```

### 6단계: 사후 검증 (30초)

```bash
# Load 회복 확인
uptime
echo ""
echo "=== 살아있는 워커 수 ==="
ps -A -o command | grep -c "opencode run --model"

# Hermes ticker 갱신 확인
stat -f "%Sm %N" ~/.hermes/cron/ticker_heartbeat ~/.hermes/cron/ticker_last_success
```

## 이번 세션 실측 결과 (2026-07-05)

| 지표 | 시작 | 1차 SIGTERM 후 | A 옵션 진행 후 (kill 중단) | 최종 회복 |
|---|---|---|---|---|
| Load (1m) | 52.47 | 46.15 | 11.80 | 10.14 |
| Free RAM | 54MB | 120MB | 6.8GB | 6.8GB |
| 좀비 | 2 | 0 | 0 | 0 |
| Hermes PID 723 | alive | alive | alive | alive |
| Telegram 워커 큐 | 막힘 | 부분 회복 | 정상 처리 | 정상 |

**교훈**:
- "오래됨 = 좀비" 단일 휴리스틱 ❌ (이번에 사용자 작업 34개를 SIGTERM 보냄)
- 4축 교차 + 사용자 보고 → 승인 후 kill 패턴 ✅
- 폭주 해결되면 Telegram 워커 큐는 자연 회복 (대부분 케이스)

## 예방 패턴 (다음 세션 워치독 설정)

- oh-my-openagent 워커 동시 spawn 상한: `~/.config/opencode/oh-my-openagent.json`의 `max_concurrent` 옵션
- NIM API 타임아웃: 60초 명시
- 워커 셀프 킬: RSS > 500MB + CPU < 1% + 5분 이상 → 자동 종료 (cron으로 10분마다 검사)

## 다음 액션 옵션

- **Telegram 워커만 unload/load**: `launchctl unload gui/501/ai.hermes.gateway && launchctl load ~/Library/LaunchAgents/ai.hermes.gateway.plist` (큐 안 비워질 때)
- **특정 cron만 일시 중단**: cronjob action='pause' job_id=<id>
- **전체 시스템 재부팅**: macmini 헤드리스면 사용자 수동 (Hermes는 remote shutdown 불가)