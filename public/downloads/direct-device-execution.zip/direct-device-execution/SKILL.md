---
name: direct-device-execution
description: "사용자 디바이스에 에이전트 도구를 직접 부려서 install/build/deploy/모니터링을 수행하는 워크플로. '직접 처리해줘', '그냥 해', '네가 다 해줘' 같은 시그널이 들어왔을 때 발동. 진단 → 환경 점검 → 도구 설치 → 실행 → 백그라운드 영구화 → 검증 → 사용자 보고 사이클. macOS/Linux 공통, brew/apt/pip/cargo 패키지 매니저별 분기, daemon/service/LaunchAgent/systemd 패턴, **alias vs function 선택 가이드 (조건부 로직이 필요한 반복 워크플로는 function 필수)**, Hermes의 terminal background / process 추적 / cron_mode 제약 우회법 포함."
version: 0.8.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [device-control, install, daemon, launchd, systemd, background-process, hermes-pattern]
    related_skills: [hermes-agent, hermes-gateway-doctor]
---

# Direct Device Execution

사용자가 "직접 처리해줘" / "그냥 네가 해" / "이 PC에서 작업해줘" 같은 시그널을 보냈을 때, 에이전트가 **사용자 본인 디바이스**에 직접 명령을 내려 작업을 완수하는 클래스.

## 트리거 시그널

- "직접 처리해줘" / "네가 다 해줘" / "그냥 진행해" / "내가 보기 싫으니까 끝까지 가"
- "이 PC에서 작업하자" / "이걸 설치해줘" / "이거 백그라운드로 돌려줘"
- "M4로 마이그레이션했는데 없는 게 많다" / "필요한 앱 하나씩 설치해줘" / "새 맥 셋업"
- 이전 세션에서 "Phase 0만 다른 PC에서, 본 작업은 이 PC에서" 결정 후 돌아옴

## 절대 트리거 X

- 사용자가 명시적으로 "이 PC 말고 다른 PC로" 라고 지시 (→ `python-oss-bootstrap` Phase 0 변형)
- cron/headless 모드 (→ `hermes-agent` cron_mode 패턴)
- 읽기 전용/리서치 작업 (→ 다른 스킬)

## 핵심 워크플로 (7단계)

### 1. 환경 진단 (1~3개 read-only terminal 호출)

먼저 대상 디바이스가 어떤 환경인지 빠르게 파악:

```bash
# OS / arch
uname -a

# 패키지 매니저 확인
which brew   # macOS Homebrew
which apt    # Debian/Ubuntu
which yum    # RHEL/Fedora
which dnf    # Fedora 22+
which pacman # Arch

# 도구 경로
which python3
which node
which go
```

> **주의**: `uname -m` 결과로 **Intel (x86_64)** vs **Apple Silicon (arm64)** 분기. `brew install` 경로가 `/usr/local/` vs `/opt/homebrew/`로 달라짐.

### 2. 도구 설치 (terminal foreground, 1~2분~10분)

가장 흔한 매니저별 명령:

```bash
# macOS
brew install <package>          # Intel: /usr/local, Apple Silicon: /opt/homebrew
brew install --cask <app>       # GUI 앱

# Debian/Ubuntu
sudo apt-get update && sudo apt-get install -y <package>

# Fedora
sudo dnf install -y <package>

# pip
python3 -m pip install <package> --user  # conda 환경은 pip 깨질 수 있음, 새 env 권장
```

> **conda 환경 함정**: base pip가 깨져있으면 새 환경 만들어서 설치. (`conda create -n <name> python=3.11 && conda activate <name> && pip install ...`)

설치 후 즉시 검증:

```bash
which <tool>
<tool> --version
```

### 3. 설정 파일 생성 (`write_file`)

설정 파일은 **항상 `write_file`로 직접 작성**. heredoc `cat > ...` 같은 거 쓰지 마세요.

```python
write_file(path="/Users/hjshin/xmrig-config.json", content="""
{
  "autosave": true,
  ...
}
""")
```

> **JSON 검증**: 자동 lint가 동작하니 별도 확인 불필요. YAML/TOML도 마찬가지.

### 4. 실행 (terminal foreground, 짧은 검증 후 백그라운드)

**첫 실행은 5~15초 포어그라운드로** — 즉시 에러를 확인하기 위해:

```bash
# 좋은 예
<tool> --config=~/config.json
# → 5~10초 안에 startup 로그 보임, 그 후 중단 (Ctrl+C)
```

**검증 후 백그라운드로 전환**:

```python
# foreground로 5~15초 돌리고 Ctrl+C 안 보내도 됨 (SIGTERM 받으면 끝남)
# 다음 호출에서 background로:
terminal(background=true, notify_on_complete=false,
         command="<tool> --config=~/config.json 2>&1 | tee ~/tool.log")
```

### 5. 검증 (별도 terminal 호출)

```bash
# 30초 정도 기다린 후
sleep 30 && tail -40 ~/tool.log

# 또는 SIGUSR1 같은 built-in 시그널
kill -USR1 <PID>

# 또는 풀 API/외부 검증
curl -s http://localhost:<port>/health
```

### 6. 영구화 (LaunchAgent / systemd)

재부팅 후에도 살아있어야 하면:

**macOS (LaunchAgent)**:
```bash
mkdir -p ~/Library/LaunchAgents
cat > ~/Library/LaunchAgents/com.local.<name>.plist << 'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key><string>com.local.<name></string>
    <key>ProgramArguments</key>
    <array>
        <string>/usr/local/bin/<tool></string>
        <string>--config=/Users/hjshin/<config></string>
    </array>
    <key>RunAtLoad</key><true/>
    <key>KeepAlive</key><true/>
    <key>ProcessType</key><string>Background</string>
    <key>StandardOutPath</key><string>/Users/hjshin/<name>.log</string>
    <key>StandardErrorPath</key><string>/Users/hjshin/<name>.log</string>
</dict>
</plist>
EOF
launchctl load ~/Library/LaunchAgents/com.local.<name>.plist
```

**Linux (systemd user service)**:
```bash
mkdir -p ~/.config/systemd/user
cat > ~/.config/systemd/user/<name>.service << 'EOF'
[Unit]
Description=<name>

[Service]
ExecStart=/usr/local/bin/<tool> --config=/home/<user>/<config>
Restart=always
StandardOutput=append:/home/<user>/<name>.log
StandardError=append:/home/<user>/<name>.log

[Install]
WantedBy=default.target
EOF
systemctl --user enable --now <name>.service
```

### 7. 사용자 보고 (한국어, 한 줄 진단 + 다음 단계)

- **진단 한 줄**: "XMRig 6.26 설치 + 채굴 시작 + 5.7 KH/s" 같은 한 줄 요약
- **관리 명령어 4~5개**: `pkill`, `tail -f`, `launchctl list`, `hermes config get` 등
- **다음 옵션 3~4개**: 모니터링 / 대시보드 / 중지 / 다른 작업

---

## Hermes 도구 제약 우회법 (필수)

### `execute_code` cron_mode BLOCKED

```text
BLOCKED: execute_code runs arbitrary local Python (including subprocess calls
that bypass shell-string approval checks). Cron jobs run without a user
present to approve it. Use normal tools instead.
```

→ `terminal` 도구로 우회. 한 줄 처리는 `terminal(command="python3 -c '...'")`.

### `terminal` `&` / nohup / disown 차단

```text
Foreground command uses '&' backgrounding. Use terminal(background=true) for
long-lived processes, then run readiness checks and tests in follow-up
terminal calls.
```

→ `terminal(background=true, notify_on_complete=...)`로 위임. `process` 도구로 lifecycle 관리.

자세한 우회 패턴: `hermes-agent` 스킬 → `references/direct-execution-and-cron-mode.md`.

---

## 자주 하는 실수 5가지

1. **`which brew`부터 안 함** — 패키지 매니저가 다르면 명령 자체가 다름. 무조건 1단계 진단 먼저.
2. **`write_file` 대신 `echo > config.json`** — JSON escape가 복잡해서 깨질 수 있음. 항상 `write_file`.
3. **백그라운드로 바로 시작** — 5~15초 포어그라운드로 startup 로그 확인 후 백그라운드 전환. 그래야 에러 즉시 발견.
4. **LaunchAgent만 등록하고 끝** — `launchctl load` 후 `launchctl list`로 PID 살아있는지 확인. 안 떠 있으면 plist 문법 오류.
5. **사용자 보고에 "되었습니다"만 적음** — hashrate, PID, 로그 경로, 관리 명령어 4종 같이 적어야 사용자가 다음 액션을 취할 수 있음.

## ⚠️ Pitfalls (실전 검증, 2026-06 XMRig 세션)

### P1. LaunchAgent `StandardOutPath` 버퍼 미플러시 (최우선)

- LaunchAgent의 `StandardOutPath` / `StandardErrorPath`는 **launchd가 즉시 디스크에 쓰지 않음** (block buffering).
- 프로세스가 50초 이상 stdout을 안 비우면 `~/xmrig.log` 같은 파일이 0바이트로 남음.
- **증상**: `ps`로 프로세스 살아있음, `launchctl list` OK, `kill -USR1` 반응 없음, 그런데 로그 파일만 비어있음.
- **해결 A (즉시)**: `tee` 사용 — `xmrig ... 2>&1 | tee /Users/hjshin/xmrig.log`을 `terminal(background=true)`로 실행.
- **해결 B (영구)**: plist에 `EnvironmentVariables` + `STDBUF=line` 강제 라인 버퍼링:
  ```xml
  <key>EnvironmentVariables</key>
  <dict>
      <key>STDBUF</key>
      <string>line</string>
  </dict>
  ```
  단, C/C++ 바이너리엔 `STDBUF`가 안 듣는 경우 많음 → 해결 A가 더 확실.
- **해결 C (재부팅 시)**: `KeepAlive=true` + 별도 watchdog (3분마다 log size > 0 확인 후 SIGTERM → 재시작).

### P2. `kill -USR1` 이 항상 작동하진 않음

- XMRig은 `SIGUSR1`로 hashrate 덤프를 지원하지만, **LaunchAgent가 SIGUSR1을 프로세스로 전달 안 할 수 있음** (macOS launchd 정책).
- 더 안정적인 진단법: `grep "miner.*speed" ~/xmrig.log | tail -3`로 최근 hashrate 추출.

### P3. `tee` + `background: true` 패턴이 가장 안정적

```bash
# ✅ 가장 안정적 (실전 검증)
terminal(background=true, command="xmrig --config=... 2>&1 | tee /Users/hjshin/xmrig.log")

# ❌ LaunchAgent 단독 (버퍼링으로 로그 안 보일 수 있음)
# launchctl load ~/Library/LaunchAgents/...

# ❌ nohup/disown (Hermes 환경에서 차단됨)
# nohup xmrig &  # → "Foreground command uses '&' backgrounding" 에러
```

### P3a. long-lived process의 Hermes idle 종료 패턴 (2026-08-04 실측, Hermes desktop preview)

**증상**: Vite dev server (`npm run dev -- --host 0.0.0.0 --port 5180`) 또는 다른 long-lived 서버를 `terminal(background=true, notify_on_complete=?)`로 띄워두면 **30~50분 후** `process.list`에서 `status: exited, exit_code: 143 (SIGTERM)` 또는 `exit_code: None`으로 종료됨. 사용자가 Hermes desktop의 preview pane에서 띄워둔 페이지를 새로고침하면 `ERR_CONNECTION_REFUSED`.

**원인**: Hermes의 `terminal(background=true)`는 **세션 단위 lifecycle에 묶여있음** (session_scoped: true). 사용자가 다른 작업으로 컨텍스트 전환 → idle → 프로세스에 SIGTERM 발송. 이는 데몬화(LaunchAgent/systemd)나 detach wrapper의 의도가 아니라 **순수 세션 lifecycle cleanup**.

**검증된 패턴 (사용자 preview에 dev server 띄울 때 표준)**:

```python
# 1) 띄울 때 — notify_on_complete는 silent로 (서버는 영원히 안 끝남)
terminal(background=true, notify_on_complete=False,
         command="cd /Users/mac/work/<project> && npm run dev -- --host 0.0.0.0 --port 5180 > /tmp/<name>-dev.log 2>&1")

# 2) 별도 명령으로 health check (반드시 동기로)
terminal(command="sleep 4 && curl -s -o /dev/null -w 'HTTP %{http_code}\\n' http://localhost:5180")

# 3) 죽었으면 — 같은 정형으로 재시작
terminal(background=true, notify_on_complete=False,
         command="cd /Users/mac/work/<project> && npm run dev -- --host 0.0.0.0 --port 5180 > /tmp/<name>-dev.log 2>&1")
```

**체크리스트 (사용자 dev/preview 워크플로)**:
- [ ] 띄울 때마다 `notify_on_complete=False` 명시 (그렇지 않으면 시스템이 "왜 안 끝나지?" 하면서 더 빨리 종료 압박)
- [ ] 사용자 preview에서 `ERR_CONNECTION_REFUSED` 보고 시 → 죽은 것 → `process.list`로 확인 → `status: exited` → 같은 정형으로 재시작
- [ ] `nohup`/`disown`/`setsid` 같은 detach wrapper 시도 ❌ — Hermes 가드가 거부 ("Foreground command uses shell-level background wrappers")
- [ ] **장기 영구화 필요 시** → P6 LaunchAgent로 승격 (재부팅 후에도 살아남음). 단 사용자 preview용 임시 띄우기는 그냥 재시작 정형으로 충분.
- [ ] **포트 충돌**: 재시작 전 이전 인스턴스가 살아있는지 확인 — `pgrep -f 'vite.*5180'` 또는 `lsof -i :5180`. 살아있으면 그대로 사용, 죽었으면 재시작.

**실측 시나리오** (Hermes desktop control room 프로젝트, 2026-08-04):
1. 위임이 Vite dev 띄움 (`proc_434e8a69799f`) → 47분 가동 후 exit_code=143 (SIGTERM)
2. 사용자 preview ERR_CONNECTION_REFUSED 보고
3. 재시작 (`proc_7c43cbd03e3f`) → 잠시 후 다시 종료
4. `notify_on_complete=False` 명시 + `> /tmp/hcr-dev.log 2>&1` 리다이렉트 → 안정화

**확인 정형** (재시작 후 항상):
```bash
sleep 4 && curl -s -o /dev/null -w "HTTP %{http_code} / %{time_total}s\n" http://localhost:5180
# → HTTP 200이면 정상. exit_code != 0이면 또 죽은 것.
```

**구분**: 사용자 preview에서 봤을 때 `ERR_CONNECTION_REFUSED` = 백엔드 죽음. `로딩 중 멈춤` = 백엔드 살아있지만 응답 지연. `빈 화면` = Vite 빌드 에러 (개발자 도구 콘솔 확인).

### P4. `cpu REDY threads X/Y` 후 첫 `accepted` 까지 1~3분

- XMRig은 풀 연결 → RandomX dataset 초기화 (~5~10초, 2.3GB 메모리 점유) → **첫 share 채굴** → 풀이 검증.
- Intel i5 6코어 기준 첫 `accepted` 로그까지 **약 1~3분**.
- "30초 지났는데 accepted 안 떴다" ≠ 문제. hashrate가 출력되고 있으면 정상.

### P6. LaunchAgent 등록 후 PID 검증 필수
- `launchctl load`가 성공해도 **PID가 0 (안 뜸)** 일 수 있음 (plist 문법 오류, path 문제).
- **증상**: `launchctl list | grep <name>` → 첫 컬럼이 0, 두 번째 컬럼도 `-` → 프로세스 안 떠 있음.
- **검증 명령**:
  ```bash
  launchctl load ~/Library/LaunchAgents/com.local.<name>.plist
  sleep 2
  launchctl list | grep <name>
  # 첫 컬럼 = PID, 두 번째 = 마지막 exit code
  # PID > 0 AND exit code = 0 → 정상
  # PID = 0 OR exit code ≠ 0 → plist 오류
  ```
- **PID 0일 때 진단**:
  ```bash
  # console.log 확인
  tail -30 ~/Library/Logs/<name>.log   # StandardOutPath가 별도면 그 경로
  # 또는
  log show --predicate 'process == "<tool>"' --last 5m
  # 대부분: 경로 오타 / binary 권한 / 환경변수 누락
  ```
- **해결**: plist 수정 → `launchctl unload` → `launchctl load` 재시도. 수정 사항이 잘 적용 안 되면 reboot 권장.

### P5. macOS `ps -o %cpu`는 100% 초과 표시

- Linux: `%cpu` = 0~100 (단일 코어 기준 점유).
- macOS: `%cpu` = 모든 코어 합산 (i5 6코어면 600%까지 가능).
- 276% = 풀 채굴 정상. 0~50% = 문제 있음.

### P7. Hermes PTY 백그라운드 + sudo는 사용자 입력 못 받음 (최우선)

- `terminal(background=true, pty=true, command="sudo -v && ...")`로 띄우면 **백그라운드라서 사용자한테 비번 입력창이 안 보임**.
- `pty=true`는 출력 가독성용이지 사용자 인터랙티브 입력을 메시지 채널로 전달하지 않음.
- 비번 안 묻는 NOPASSWD 환경이어도, 비대화형 sudo가 막히는 스크립트(예: brew 설치)가 fail함.
- **증상**: `Password:` 한 줄만 출력되고 `sudo: a password is required`로 fail. 사용자는 "아무 반응 없다"고 호소.
- **해결**: **사용자가 직접 macOS Terminal.app에서 비번 인증 한 번 → 그 다음 같은 세션에서 비번 필요한 명령 실행**.
  ```bash
  # 1단계: 사용자가 Terminal.app에서 직접
  sudo -v
  # → 비번 묻거나 자동 통과 (5분 캐시)
  
  # 2단계: 비번 필요한 명령 실행 (예: brew 설치)
  /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
  ```
- **에이전트가 할 일**: PTY 백그라운드로 sudo 띄우지 말고, **명령어 + 비번 인증 절차 2~3줄을 사용자에게 복사-붙여넣기 식으로 안내**. 설치 끝나면 "완료" 신호 받고 후속 작업 자동 진행.
- **판별법**: `sudo -n true`로 캐시 확인 → "NEED_PASSWORD" 나오면 PTY 백그라운드 시도 금지.

### P8. macOS Homebrew 설치 = 반드시 TTY (Terminal.app)

- `NONINTERACTIVE=1 /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"`는 비대화형 환경에서 `have_sudo_access` 단계에서 fail (install.sh:530).
- brew install.sh는 **TTY에서 비번 묻는 prompt → 사용자 입력 → 진행** 흐름을 가정.
- `SUDO_ASKPASS` 환경변수 우회도 가능하지만 설정 복잡 → 비추.
- **올바른 흐름 (M4 새 맥 시나리오, 2026-06-26 검증)**:
  1. `xcode-select -p` → `/Library/Developer/CommandLineTools` 확인 (M4 신형 macOS는 보통 CLT 사전 설치됨)
  2. 사용자에게 Terminal.app에서 `sudo whoami` 한 번 실행 부탁 → 비번 인증 or NOPASSWD 확인
  3. 같은 터미널에서 brew 설치 명령어 직접 실행
  4. 설치 완료 시 출력되는 PATH 등록 명령어:
     ```bash
     echo 'eval "$(/opt/homebrew/bin/brew shellenv)"' >> ~/.zprofile
     ```
  5. 사용자가 "설치 끝났어" 신호 → 에이전트가 `brew install <pkg>` 자동 진행
- **흔한 잘못된 시도들**:
  - `NONINTERACTIVE=1`로 비대화형 설치 → sudo fail
  - `sudo -S` (stdin 비번) → brew가 non-tty 감지하고 fail
  - TMUX/screen 안에서 실행 → 같은 TTY 문제

### P8a. `brew install --cask` 비대화 sudo 함정 (2026-07-08 Orca/Tailscale 세션 실측, P8 확장판)

- **증상**: `brew install --cask tailscale-app` → brew가 .pkg 인스톨러를 sudo로 호출 → `sudo: a terminal is required to read the password; either use the -S option to read from standard input or configure an askpass helper` 에러 → install fail.
- **PTY 모드 우회 ❌**: `terminal(pty=true, command="brew install --cask tailscale-app")` 도 같은 에러. PTY는 **출력 가독성용**이지 사용자 입력을 메시지 채널로 전달 안 함 (P13과 동일 모티프).
- **`brew install` (formula, --cask 없음)는 OK**: .pkg 인스톨러 단계가 없으니 sudo도 안 물음. 비대화 가능.
- **해결 패턴** (검증됨):
  1. **CLI만 필요한 경우**: `brew install <formula>` (--cask 안 붙임). 비대화 성공.
  2. **GUI 앱이 꼭 필요한 경우**: 사용자가 **Terminal.app (zsh)**에서 직접 `brew install --cask <app>` 실행 → 비번 1회 인증 → 끝나면 신호.
  3. **CLI만으로 충분한지 brainstorm**: GUI 앱이 없어도 CLI로 완결 가능한 도구가 많음 (Tailscale, gh, node, python, docker CLI 등). 일단 formula로 시도 → 부족하면 cask 설치 요청.
- **판별법**: `brew info <pkg>` → "Cask" 표시 있으면 cask (GUI), 없으면 formula (CLI). 비대화 환경에서는 formula 우선.
- **Tailscale 사례 (이번 세션)**:
  - `brew install --cask tailscale-app` ❌ (sudo 비대화)
  - `brew install tailscale` ✅ (formula, 1.98.8 비대화 설치 성공)
  - `tailscaled` 데몬은 root 권한 필요 → **userspace-networking 모드**로 user space 가동 (P18 참조).

- **Apple Silicon vs Intel 경로 차이** (이건 P5/P7과 무관하게 항상 분기):
  - M1/M2/M3/M4: `/opt/homebrew/bin/brew`
  - Intel: `/usr/local/bin/brew`

### P18. Tailscale 비대화 로그인 패턴 (2026-07-08 Orca 모바일 페어링 세션 실측)

- **시나리오**: Orca 등 데스크탑 앱 + 모바일(iPhone/iPad/Android) 페어링이 **LAN 미스매치**로 실패할 때, Tailscale 사설망(`100.x.x.x`)으로 우회. 근본 해결책이지만 비대화 환경에서 함정 다발.
- **3단계 함정 + 우회 패턴**:

| # | 함정 | 증상 | 우회 |
|---|---|---|---|
| 1 | `brew install --cask tailscale-app` 비대화 sudo | `sudo: a terminal is required` | `brew install tailscale` (formula) — CLI만 설치, 비대화 OK |
| 2 | `tailscaled` 기본 모드 = root 필요 | `tailscaled requires root; use sudo tailscaled` | `--tun=userspace-networking` 플래그로 user space 모드 (root 불필요) |
| 3 | `tailscaled` 경로 파싱 — 공백 포함 경로 | `tailscaled does not take non-flag arguments: ["Support/Tailscale/..."]` | `--statedir="..."` `--socket="..."` quoted (각각 `--state path` + `--socket path` 분리 입력 ❌) |

- **검증된 Tailscale 비대화 기동 패턴** (복사-붙여넣기 OK):
  ```bash
  # 1) CLI 설치 (formula)
  brew install tailscale

  # 2) userspace 데몬 background 기동
  mkdir -p "/Users/mac/Library/Application Support/Tailscale"
  /opt/homebrew/bin/tailscaled \
      --tun=userspace-networking \
      --statedir="/Users/mac/Library/Application Support/Tailscale" \
      --socket="/Users/mac/Library/Application Support/Tailscale/tailscaled.sock"
  # ↑ terminal(background=true) + notify_on_complete=false
  # ↑ 5초 후 ps -p $PID -o pid,state,etime,command 로 살아있나 확인
  # ↑ $! 대신 background session_id의 PID 기록
  ```

- **Tailscale 비대화 로그인 = auth key 필수 (브라우저 OAuth ❌)**:
  - `tailscale up` 또는 `tailscale login` → 브라우저 OAuth 띄우려 함 → 비대화에서 hang
  - **해결**: 사용자가 브라우저로 https://login.tailscale.com/admin/settings/keys 에서 **auth key** (reusable, 90일) 발급 → `tailscale up --authkey=<key>`로 비대화 인증
  - iPhone에도 같은 계정으로 Tailscale 앱 설치 → 로그인 → 100.x.x.x IP 자동 할당
  - 두 디바이스가 같은 Tailscale 계정에 등록되면 즉시 end-to-end 암호화 사설망 연결 (LAN/Wi-Fi/AP격리/이더넷 모두 무관)
- **Tailscale IP 추출 (페어링 주소로 전달)**:
  ```bash
  tailscale --socket="<socket>" ip -4
  # → 100.x.x.x 출력 (가장 첫 줄)
  # → orca serve --pairing-address 100.x.x.x --mobile-pairing 같은 도메인 도구로 전달
  ```
- **데몬 종료/정리**:
  ```bash
  # background session_id에 대해 process(action="kill")
  # tailscaled 종료 후 /Users/mac/Library/Application Support/Tailscale/ 디렉토리는 남겨둠 (재기동 시 state 재사용)
  rm -f "/Users/mac/Library/Application Support/Tailscale/tailscaled.state"  # 완전 초기화 시에만
  ```
- **제한**: userspace-networking 모드는 성능이 kernel TUN 모드보다 느림 (~30%). P2P 게임/대용량 스트리밍엔 부적합. 페어링/제어용 CLI 도구엔 충분.

### P10. `source <(...)` zsh process substitution 함정 (macOS zsh)

- `source <(some-command)`는 bash에서 잘 동작하지만 **zsh에선 문법 오류 또는 알 수 없는 행동을 보일 수 있음** (특히 `fzf --zsh`, `starship init zsh` 같은 multi-line 출력 시).
- **증상**: `zsh: parse error near ')'`, 또는 에러 없이 source는 되는데 키바인딩 미등록.
- **해결**: 항상 직접 파일 경로로 source하기.
  ```bash
  # ❌ zsh에서 깨짐
  source <(fzf --zsh)

  # ✅ 정적 파일 경로
  source /opt/homebrew/opt/fzf/shell/key-bindings.zsh
  ```
- **판별법**: 의심되는 source 라인만 떼어서 `zsh -c 'source <(some-cmd) 2>&1; echo EXIT=$?'`로 격리 테스트. 에러 나면 정적 파일 경로로 전환.

### P11. brew의 `fzf` 공식 key-bindings.zsh는 zsh 비호환 (2026-06-26 검증)

- `/opt/homebrew/opt/fzf/shell/key-bindings.zsh`와 `completion.zsh`는 **bash 전용 스크립트** (shebang 없음 + `() { ... }` 익명 함수 사용).
- macOS zsh에서 source하면: `예기치 않은 ')' 토큰 주변에서 문법 오류`, 그리고 다음 라인의 `(( ${+options} ))` 같은 bash 산술 문법도 깨져서 이후 source 라인 모두 연쇄 실패.
- **증상**: fzf 설치 → `.zshrc`에 공식 권장 방식(`source <(fzf --zsh)` 또는 `source .../key-bindings.zsh`) 추가 → 새 터미널마다 에러 5~6줄. direnv 같은 후속 source까지 같이 망가짐.
- **올바른 fzf 통합 패턴** (검증됨, 그대로 복사-붙여넣기):
  ```bash
  # fzf: completion만 로드 (key-bindings는 zsh 비호환이라 직접 등록)
  if [ -f /opt/homebrew/share/zsh/site-functions/_fzf ]; then
    source /opt/homebrew/share/zsh/site-functions/_fzf 2>/dev/null
  fi

  # fzf key bindings (수동 등록 — brew 공식 스크립트 우회)
  if command -v fzf >/dev/null 2>&1; then
    bindkey '^T' fzf-file-widget     # Ctrl+T: 파일 fuzzy 선택
    bindkey '^R' fzf-history-widget  # Ctrl+R: 히스토리 fuzzy 검색
    bindkey '\ec' fzf-cd-widget      # Alt+C: 하위 디렉토리 cd
  fi
  ```
- **다른 brew 패키지 동일 함정 위험군** (확인 후 사용): `starship`, `direnv`는 자체 init 스크립트가 zsh 호환 확인됨. `fzf`/`zoxide`/`zsh-autosuggestions` 같은 애들은 brew 설치 후 init 안내를 그대로 복붙하면 같은 함정 가능성. **검증 우선**.

### P12. 도구 환경의 terminal 셸 ≠ 사용자 셸 (Hermes 도구 제약, 최우선)

- Hermes가 띄우는 도구 환경의 `terminal` 도구는 **임시 bash 환경** (`/opt/homebrew/bin/bash` 또는 `/bin/bash`)에서 실행됨. `echo $SHELL`은 `/bin/zsh`이지만 실제 컨텍스트는 bash.
- **`source ~/.zshrc`를 이 bash 컨텍스트에서 실행하면 zsh 전용 명령이 모두 깨짐**:
  - `bindkey: 명령을 찾을 수 없음` (bindkey는 zsh builtin)
  - `_direnv_hook: 산술 문법 오류` (bash에서 `(I)` 같은 zsh parameter expansion flag 처리 못함)
  - `예기치 않은 ')' 토큰 주변에서 문법 오류` (fzf 공식 key-bindings.zsh의 bash 익명 함수)
- **증상**: 새 zshrc 라인을 추가 → `source ~/.zshrc`로 검증 → 산더미 에러 → "zshrc가 망가졌다"고 오해. 실제로는 zshrc는 멀쩡하고 도구 환경에서 잘못 검증한 것.
- **절대 규칙**: zshrc / zsh 전용 스크립트 검증은 **`zsh -c '...'` 패턴**으로:
  ```bash
  # ❌ 도구 환경에서 잘못 검증
  source ~/.zshrc && echo "OK"   # bash에서 zshrc를 실행 → 산더미 에러

  # ✅ 검증된 패턴 (zsh 컨텍스트로 명시 진입)
  zsh -c 'source ~/.zshrc 2>&1; echo "EXIT=$?"; \
    bindkey | grep -E "\^R|\^T" | head -3; \
    typeset -f _direnv_hook >/dev/null && echo "direnv OK" || echo "direnv FAIL"'
  ```
- **핵심**: `zsh -c`의 stdout에 EXIT=0이 나오면 zshrc 정상. bindkey/direnv/fzf 함수 검증도 같은 명령으로 한 번에.
- **시각적 신호로 셸 구분하기**:
  ```bash
  ps -p $$ -o comm=  # /opt/homebrew/bin/bash → 도구 환경 (주의)
                      # /bin/zsh           → 실제 zsh 세션 (안전)
  ```

### P17. Telegram 워커 sticky fallback IP → 13시간 답 없음 (Hermes 게이트웨이 함정, 2026-07-05 재발)

- 증상: Telegram 봇이 **N시간~수십 시간 동안 메시지 무응답**. `~/.hermes/cron/ticker_heartbeat`는 정상 갱신 (게이트웨이 살아있음), 외부 네트워크 정상, 사용자 작업도 정상 — **단순히 메시지 큐가 안 비워짐**.
- 진단 흐름 (이번 세션 검증):
  1. `ps -A -o etime` 로 opencode 워커 폭주 확인 → Load 50+ → 시스템 hang → 게이트웨이 큐 처리 불가
  2. **근본**: oh-my-openagent가 NIM gpt-oss-20b에 동시 워커 spawn → 응답 hang → CPU 100% × N개
  3. 결과: Telegram 워커가 fallback IP(149.154.166.110)에 sticky → SSL mismatch → httpx ReadError 영구 루프
- **근본 해결 (이 세션에서 적용)**:
  1. 폭주 워커 SIGTERM (P15 안전 분류 후)
  2. Load 50+ → 11 회복 후 자연 회복 (Telegram 워커 큐 자동 처리)
  3. 안 되면 launchctl unload → load로 게이트웨이 재시작
- **예방 (이 함정 재발 안 하게)**:
  - oh-my-openagent 워커 동시 spawn 상한 설정 (max_concurrent 옵션)
  - NIM API 타임아웃 60초 명시 (무한 hang 방지)
  - 워커 셀프 킬: RSS > 500MB + CPU < 1% + 5분 이상 → 자동 종료 패턴
- **상세 함정 + 워치독 스킬**: `~/.hermes/skills/hermes-gateway-doctor` 참조.

### P16. 폭주 워커 SIGTERM 전후 — 안전 4단계 (2026-07-05 검증)

- 이번 세션 7/5 부하 폭주 → SIGTERM 34개 동시 발송 → 사용자 작업이었음 → 데이터 손실 위기. 다음엔 이 순서:
  1. **사전 스냅샷**: `ps -A -o pid,etime,%cpu,rss,stat,ppid,command | tee /tmp/pre-kill.log` → kill 대상/대상 아님 명시적으로 분류 후 사용자 보고
  2. **소규모 파일럿**: 5개만 SIGTERM → 10초 후 상태 확인 (kill -15 graceful 정상 종료 처리되는지)
  3. **결과 보고**: "5개 종료, 부하 50→48 변화. 계속 진행?" → 사용자 확인 후 잔여 kill
  4. **사후 검증**: `ps` + `uptime` + `vm_stat` 30초 후 재측정 → 예상치 못한 좀비/사용자 작업 종료 감지
- **공통 모티프 (이번 세션 교훈)**: kill 판단할 때 **"오래됨" 단일 축 ❌**, "STAT + CPU + RSS + PPID" 4축 교차 확인. P15 awk 패턴 필수.
- **사용자 안전 옵션 (이번 세션 옵션 패턴)**: "A. 즉시 중단 + 정직 인정" / "B. 신중 kill" / "C. 재부팅". **사용자가 A 선택한 게 정답이었음** — 다른 어떤 결과보다 데이터 보존 우선.
- **공통 보고 템플릿**: 표 형식 (PID | etime | CPU | RSS | STAT | 분류) → 사용자 한눈에 검토 가능.

### P15. `ps -o etime` 패턴 분류 함정 — 오래됨 ≠ 좀비 (최우선, 2026-07-05)

- macOS `ps -A -o etime` 출력 형식이 **두 가지**:
  - **24시간 미만**: `HH:MM:SS` (예: `02:35`, `11:41`)
  - **24시간 이상**: `DD-HH:MM:SS` (예: `01-16:05:44`)
- 경계값이 **정확히 24시간**이라 awk 단순 분기 어려움.
- **증상 (이번 세션 2026-07-05 실전)**: Hermes 워커 폭주 진단 → `etime 01-16:05:44` 워커들을 "40시간+ 좀비"로 확신 → SIGTERM 34개 동시 발송 → 실제론 사용자 작업이었음. **데이터 손실 위기 + Telegram 큐 13시간 막힘**.
- **판별 4축** (하나라도 "활성" 신호면 좀비 아님):

| 축 | 좀비 신호 | 활성 신호 |
|---|---|---|
| **STAT** | `Ss`, `S+` (sleep + foreground 대기) | `R+`, `R` (실행 중) |
| **%CPU** | < 1% (정지) | > 5% (작업 중) |
| **RSS** | < 60MB (오래 묵힌 워커는 작음) | > 100MB (최근 생성/활성) |
| **PPID** | 1 (orphan, 부모 죽음) | launchd 데몬 or 활성 부모 |

- **올바른 분류 awk (검증됨, 그대로 복사)**:
  ```bash
  ps -A -o pid,etime,%cpu,rss,stat,ppid,command | awk '
  /<SUSPECT_PATTERN>/ && !/awk/ {
    e=$2
    # etime → 총 시간(소수)
    total_h = 0
    if (e ~ /^[0-9]+-/) {
      split(e, a, "-")
      split(a[2], t, ":")
      total_h = a[1]*24 + t[1]
      if (t[2] != "") total_h += t[2]/60
    } else if (e ~ /:/) {
      n = split(e, a, ":")
      if (n==3) total_h = a[1] + a[2]/60
      else total_h = a[1]/60  # MM:SS
    }
    
    # 좀비: STAT=Ss/S+ AND CPU<1% AND RSS<60K AND PPID=1
    zombie = ($5 ~ /^S/) && ($4+0 < 1) && ($5+0 < 60000) && ($6 == 1)
    active = ($5 ~ /^R/) || ($4+0 > 5)
    
    tag = zombie ? "🟥 좀비" : active ? "💎 활성" : "🟡 미분류"
    printf "%-7s etime=%-12s CPU=%-4s RSS=%-7s STAT=%-2s PPID=%-3s [%s]\n",
           $1, $2, $4, $5, $5, $6, tag
  }'
  ```
- **kill 전 안전 순서 (이건 P15와 묶음)**:
  1. 분류 결과를 사용자 보고 → "이게 좀비 후보 34개, 의심 없어?" 확인
  2. **SIGTERM (kill -15) 먼저** → 안 죽는 놈만 SIGKILL (kill -9)
  3. 5~10초 대기 후 `ps` 재확인 → 살아있으면 SIGKILL
  4. **사용자가 "응 진행" 신호 줘야 본격 kill** (이번 세션에서 사용자 요청으로 진행했지만 결과적으로 사용자 작업이었음 — 사용자도 정확한 분류 모르고 있었음)
- **이 함정이 발동하면**: 사용자에게 **즉시 정직 보고 + 추가 kill 중단 제안 + 부작용 인정**. 이번 세션처럼 "A 진행 (정직 인정 + kill 중단)" 옵션을 사용자한테 항상 준비.

### P19. Alias vs Function — 조건부 로직이 필요하면 function 필수 (2026-07-14, 시뮬레이션 fork 워크플로 세션)

- **alias는 단일 명령 치환**. `alias ga-sim='cd X && source Y && python3 reverie.py'`처럼 단순한 환경 준비 + 명령 실행에는 OK.
- **function은 조건부 + 다중 명령 + 파라미터 가능**. 시뮬레이션 fork처럼 **이전 실행 결과물 폴더가 매번 partial 상태로 남는 경우**, alias로는 자동 정리 불가능. function이 필수.

**증상** (Stanford generative_agents 시뮬레이션 fork 시나리오):
```bash
# ICBM_kr_test 폴더가 partial로 남은 상태에서
ga-sim   # → FileExistsError: '../../environment/frontend_server/storage/ICBM_kr_test'
# 매번 사용자가 수동으로 rm -rf 필요
```

**해결 패턴 (zsh, 검증됨)**:
```bash
# .zshrc 또는 alias 등록 시
ga-sim() {
  local proj_dir="/Users/mac/work/generative-agents-kr"
  local storage_dir="$proj_dir/environment/frontend_server/storage"
  local sim_name="ICBM_kr_test"  # 또는 인자로: $1

  # 1) 조건부 cleanup
  if [ -d "$storage_dir/$sim_name" ]; then
    echo "⚠️  $storage_dir/$sim_name 폴더가 이미 존재 — 삭제합니다 (자동)."
    rm -rf "$storage_dir/$sim_name"
  fi

  # 2) venv + env
  cd "$proj_dir" && source .venv/bin/activate && unset PYTHONPATH \\
    && export NVIDIA_API_KEY="***"

  # 3) 작업
  cd reverie/backend_server && python3 reverie.py
}

# Optional: 파라미터화
ga-cleanup() {
  local sim_name="${1:-ICBM_kr_test}"
  local dir="/Users/mac/work/generative-agents-kr/environment/frontend_server/storage/$sim_name"
  if [ -d "$dir" ]; then
    echo "🗑️  $dir 삭제"
    rm -rf "$dir"
  else
    echo "✅ $dir 없음 (정상)"
  fi
}
```

**Alias vs Function 비교표** (zsh 기준):

| 차원 | alias | function |
|------|-------|----------|
| **문법** | `alias name='cmd'` (단일 명령) | `name() { ... }` (블록) |
| **조건부 (`if`)** | ❌ 직접 불가 (subshell) | ✅ 자유 |
| **다중 명령** | `&&` 또는 `;`로 연결 (제한) | ✅ 줄바꿈 자유 |
| **로컬 변수** | ❌ shell scope 오염 위험 | ✅ `local` 키워드 |
| **인자** | ❌ 인자 못 받음 (heredoc으로 우회) | ✅ `$1`, `$@` 자유 |
| **에러 핸들링** | ❌ | ✅ `if` + `set -e` |
| **타이밍** | ~/.zshrc reload 시 즉시 | ~/.zshrc reload 시 즉시 (alias와 동등) |

**사용 시기**:
- 단순 `cd X && Y` → alias
- `if ...; ...; fi` → function
- `function 인자` → function (alias 못 받음)
- `local` 변수 → function (alias에서 누출 위험)

**`.zshrc`에 등록 후 즉시 반영** (새 shell 열 필요):
```bash
# ~/.zshrc 끝에
ga-sim() { ... }

# 또는 alias처럼 한 줄
ga-sim() { local proj_dir="/Users/mac/work/generative-agents-kr"; ... }
```

**검증**:
```bash
source ~/.zshrc  # 또는 새 shell
type ga-sim       # "ga-sim is a shell function" 출력
ga-sim            # 4단계 (cleanup + venv + env + 명령) 한 번에
```

**단점**: function은 syntax 에러 시 `.zshrc` 전체가 깨질 수 있음. → 추가 후 `zsh -i -c 'source ~/.zshrc; type ga-sim'`로 검증.

**자동 cleanup이 위험한 경우** (옵션 처리):
```bash
ga-sim() {
  local sim_name="${1:-ICBM_kr_test}"  # 인자 또는 기본값
  local dir="/Users/mac/work/generative-agents-kr/environment/frontend_server/storage/$sim_name"
  if [ -d "$dir" ]; then
    read "REPLY?⚠️  $dir 삭제할까요? (y/n): "
    [[ "$REPLY" =~ ^[Yy]$ ]] || return 1
    rm -rf "$dir"
  fi
  # ...
}
```

**고려: 새 simulation 워크플로 트리거** (다른 시뮬 OSS fork 시):
- 매번 fork 결과물 폴더가 남음
- 시뮬 실행 후 partial 상태 → 재실행 시 충돌
- 17분 이상 걸리는 long-running 시뮬 → 매번 깨끗하게 시작 보장
- cleanup 폴더명 시나리오명 매개변수화 (다른 시나리오 fork 가능성)

### P14. 단순 요청은 옵션 4개 없이 즉시 실행 (사용자 강한 코렉션, 2026-06-29)

- 사용자가 "그냥 X만 해줘" / "단순히 Y만" / "심플하게 Z" 같은 **명시적 단순 지시**를 보냈는데 옵션 4개를 제시하면 멈춤 신호로 받아들여짐.
- **기준**: 메시지에 "그냥/단순/바로" 가 들어가면 사용자 의도는 "브레인스토밍 ❌, 기본값으로 즉시 진행 ✅".
- **잘못된 패턴**: "이거 4가지 방법이 있어요 — A/B/C/D 추천은 A..." → 사용자가 "왜 물어봐?" 반응.
- **올바른 패턴**: 합리적 기본값 1개 선정 + 즉시 실행 + 결과 보고. 옵션은 결과 후 다음 액션으로만.
- **예외 (브레인스토밍 우선 워크플로우 발동해야 함)**: 음악/창작/프로젝트 디자인처럼 사용자 선호 "구현 전에 브레인스토밍 먼저" 클래스는 항상 A/B/C 제시 (별도 스킬: `canvas-static-site-pipeline` step 0). 단, **단순 요청 예외와 충돌 시 사용자 메시지 키워드가 우선** ("그냥 + 창작" → 단순 우선으로 진행하되 결과 후 사용자 피드백 받기).
- **반복 = 멈춤 신호**: 같은 지시를 두 번 하면 무조건 즉시 실행 + 결과. 더 묻지 않음.
- 사용자 프로필 메모리에도 "clarify 시 4옵션+추천" 선호는 적혀 있지만, **단순 요청 시에는 그 룰을 자동 off** 하는 게 사용자 가치 우선순위에 부합.

### P13. PTY + 인터랙티브 OAuth/login CLI (gh, gws, gcloud 등) = 사용자 수동 fallback (최우선)

- `terminal(background=true, pty=true, command="gh auth login --web")` 같은 흐름은 **PTY가 떴지만 사용자 입력 채널이 메시지 채널로 연결 안 됨**.
- **증상**: 첫 질문 `? Authenticate Git with your GitHub credentials? (Y/n)` 출력 후 멈춤. `process.write("Y")` + `process.submit("Y")` 둘 다 안 먹힘 (Enter 신호가 gh에 전달 안 됨). 30초 후 timeout.
- **원인**: Hermes의 PTY 모드는 **출력 가독성용**이지, 메시지 채널을 통한 인터랙티브 응답 전달용이 아님. brew/sudo와 같은 함정 카테고리 (P7/P8).
- **해결**: 사용자가 **직접 zsh 터미널에서 실행** + 끝나면 신호.
  ```bash
  # 1) 에이전트가 안내
  echo "Terminal.app (zsh) 에서 실행:
  gh auth login --web --git-protocol https
  끝나면 '끝났어' 한마디 주세요."

  # 2) 사용자가 직접 실행 → device code 복사 → 브라우저 인증

  # 3) 끝나면 에이전트가 검증
  gh auth status
  ```
- **근본 규칙**: "사용자 인증 필요한 모든 OAuth/device flow (gh, gcloud, gws, aws sso, huggingface-cli, wandb login, fly auth, vercel login 등) 는 PTY 백그라운드 시도 금지". 비대화형 비대화 + 사용자 수동이 유일한 안정 루트.
- **판별법**: 도움말에 `device`, `web`, `OAuth`, `paste`, `verification code` 키워드가 있으면 PTY 시도 안 함. `gh auth login --with-token < token.txt`처럼 비대화형 변형이 있으면 그걸 시도.

### P9. "M4로 마이그레이션했더니 없는 게 많다" 시나리오

- 새 PC / 마이그레이션 직후 자주 받는 요청: "필요한 앱 하나씩 설치해줘".
- **표준 워크플로**:
  1. 환경 진단 (1단계 그대로): `uname -m`, `which brew`, `which xcode-select` 등
  2. **설치 대상 목록 brainstorm**: 사용자가 "첫째로 X" 식으로 1개씩 주는 패턴 → 그때그때 1개씩 설치. 너무 영리하게 묶지 말 것.
  3. **각 앱 설치 전**: "이거 뭐하는 앱이야?" 1줄 확인 (오타/혼동 방지). 사용자가 "방금 cmux 설치해줘" 했는데 본인이 원하는 건 다른 cmux일 수 있음.
  4. **TUI/GUI 앱**: `brew install --cask <app>` → `/Applications/`에 설치, CLI 심볼릭 링크는 `/opt/homebrew/bin/`.
  5. **설치 후 검증**: 항상 `which <tool>` + `<tool> --version` 둘 다. PATH 등록 안 됐으면 `eval "$(/opt/homebrew/bin/brew shellenv)"` 권장.
  6. **사용자 보고**: 버전, 설치 경로, PATH 상태, 다음 옵션 3~4개.
- **이 워크플로 검증된 케이스** (2026-06-26): cmux 0.64.17 설치 → 5단계 todo로 추적 → brew 6.0.4 + cask 0.64.17 → `cmux --version` 정상.

---

## 📚 References

- `references/zsh-safe-verification.md` — macOS zshrc 검증 패턴 + fzf 안전 통합 + brew 패키지별 zsh init 호환성 표. P10/P11/P12 적용 시 먼저 읽기.
- `references/load-averaging-emergency.md` — Load average 폭주 + Telegram 무응답 5분 진단 (P15/P16/P17 통합). 시스템 핵심 4축 → 폭주 주범 → 4축 분류 → 사용자 보고 → kill 승인 → 사후 검증. 2026-07-05 실측 결과 표 + 예방 패턴.

## 환경별 매니저 빠른 참조

| OS | 매니저 | 설치 | 영구화 |
|---|---|---|---|
| macOS (Intel) | Homebrew | `brew install <pkg>` (경로 `/usr/local/`) | `~/Library/LaunchAgents/com.local.<name>.plist` |
| macOS (Apple Silicon) | Homebrew | `brew install <pkg>` (경로 `/opt/homebrew/`) | 동일 |
| Debian/Ubuntu | apt | `sudo apt-get install -y <pkg>` | `~/.config/systemd/user/<name>.service` |
| Fedora/RHEL | dnf/yum | `sudo dnf install -y <pkg>` | systemd user service |
| Arch | pacman | `sudo pacman -S <pkg>` | systemd user service |
| WSL2 | Linux | 위 Linux 중 하나 | systemd (WSL2 0.67+) |

---

## 실전 시나리오 3가지

### A. CPU 채굴 daemon (XMRig)

```bash
1. 환경 진단: uname -a → x86_64 (Intel), which brew → /usr/local/bin/brew
2. brew install xmrig (의존성 hwloc, libuv 자동)
3. write_file ~/xmrig-config.json (wallet + pool)
4. xmrig --config=~/xmrig-config.json 5~10초 → "READY" 확인
5. background=true, notify_on_complete=false로 전환
6. 30초 후 tail -f ~/xmrig.log → hashrate 확인
7. 보고: "i5-8500B 6코어 / Monero / ~1.5 KH/s / 24h 0.0002 XMR"
```

### B. 로컬 웹 대시보드 (FastAPI)

```bash
1. python3 -m pip install fastapi uvicorn  # 또는 poetry/pipenv
2. write_file ~/dashboard.py
3. python3 dashboard.py 5초 → "Uvicorn running on http://127.0.0.1:8000"
4. background=true 전환
5. curl -s http://localhost:8000/health
6. (선택) launchctl plist 등록
```

### C. Docker 컨테이너 영구 실행

```bash
1. which docker → /usr/local/bin/docker 확인
2. docker run -d --name <name> -p <port>:<port> <image>
3. docker ps | grep <name>  # 컨테이너 살아있는지
4. (선택) macOS: docker-compose 자동 시작
```

---

## 다음 단계 옵션 (사용자에게 항상 제시)

1. **그냥 두기** (재부팅하면 죽어도 OK)
2. **LaunchAgent/systemd 영구화** (재부팅 후에도 자동)
3. **모니터링 대시보드 추가** (실시간 hashrate/메트릭)
4. **다른 작업** (대시보드, 알림, 시각화 등)

어떤 옵션을 선택할지 사용자에게 물어보고 진행.

---

## 변경 이력

| 날짜 | 버전 | 내용 |
|---|---|---|
| 2026-06-16 | v0.1.0 | 초기 작성. "직접 처리해줘" 패턴 + 7단계 워크플로 + brew/apt/pip 매니저 분기 + LaunchAgent/systemd + Hermes cron_mode 우회법 |
| 2026-06-24 | v0.2.0 | XMRig 채굴 세션 실전 검증. P1~P5 추가 (LaunchAgent 버퍼, USR1 한계, tee 패턴, accepted 시간, macOS %cpu). 시나리오 A 작성. **P6 추가 (LaunchAgent 등록 후 `launchctl list` PID 검증 필수)**. |
| 2026-06-26 | v0.3.0 | M4 새 맥 마이그레이션 세션 검증. **P7 추가 (PTY 백그라운드 + sudo 사용자 입력 못 받음, Terminal.app 수동 인증 패턴)**, **P8 추가 (Homebrew 설치 = 반드시 TTY, install.sh:530 have_sudo_access fail, Apple Silicon vs Intel 경로 분기)**, **P9 추가 (M4 마이그레이션 후 "없는 게 많다" 시나리오 표준 워크플로)**, 트리거 시그널에 새 맥/마이그레이션 키워드 추가. |
| 2026-06-26 | v0.4.0 | macOS zsh 셸 스크립팅 함정 4종 추가. **P10 (source <(...) zsh process substitution 함정)**, **P11 (brew 공식 fzf key-bindings.zsh가 zsh 비호환 — `() {}` 익명 함수 + shebang 없음, 안전한 수동 bindkey 등록 패턴)**, **P12 (Hermes 도구 환경 terminal은 bash라 zshrc 검증 오탐 — 결정적 검증 패턴 `zsh -c 'source ~/.zshrc; ...'`, ps -p $$ -o comm= 식별법)**, **P13 (PTY + gh auth login / gcloud / gws 같은 인터랙티브 OAuth flow = 사용자 수동 fallback, 비대화형 변형 우선 시도)**, `references/zsh-safe-verification.md` 추가 (zsh 호환성 표 7종 패키지 + 격리 테스트 패턴). |
| 2026-06-29 | v0.5.0 | **P14 추가 — 단순 요청 즉시 실행 원칙 (사용자 강한 코렉션)**. 메시지에 "그냥/단순/바로" 키워드 들어가면 옵션 4개 ❌, 합리적 기본값 즉시 실행. 단, 창작/디자인 클래스 브레인스토밍 워크플로우는 예외 (키워드 충돌 시 사용자 메시지 우선). 반복 지시 = 무조건 즉시 실행. |
| 2026-07-05 | v0.6.0 | **시스템 부하 폭주 진단 + kill 안전성 세션 검증**. **P15 — `ps -o etime` 24시간 경계 패턴 분류 함정** (오래됨 ≠ 좀비, 4축 교차 판별 awk + kill 전후 안전 순서). **P16 — 폭주 워커 SIGTERM 전후 안전 4단계** (스냅샷→파일럿→보고→검증). **P17 — Telegram 워커 sticky fallback IP 13시간 답 없음 재발** + Hermes 게이트웨이 큐 막힘 워크플로 + oh-my-openagent 워커 상한/타임아웃/셀프킬 예방 3종. |
| 2026-07-08 | v0.7.0 | **Orca 모바일 페어링 트러블슈팅 세션 검증**. **P8a 추가** — `brew install --cask` 비대화 sudo fail (PTY 우회 ❌), formula 우선 + 사용자 Terminal.app 수동 fallback 패턴. **P18 추가** — Tailscale 비대화 로그인 패턴 (userspace-networking 모드 + `--statedir`/`--socket` quoted 경로 + auth key 발급 흐름), 3단계 함정 표 + 검증된 기동 명령어 + IP 추출 + 데몬 정리. |
| 2026-08-04 | v0.8.1 | **P3a 추가** — Hermes desktop preview 워크플로에서 long-lived dev server가 idle 후 SIGTERM 종료되는 패턴 실측 (Vite dev server 47분 가동 후 exit_code=143 두 번 재발). 사용자 preview ERR_CONNECTION_REFUSED는 백엔드 죽음 신호. **해결**: `background=true` + `notify_on_complete=False` + `> /tmp/<name>-dev.log 2>&1` 리다이렉트 + `sleep 4 && curl` 별도 검증. `nohup`/`disown`/`setsid` 가드 우회 시도 금지. Hermes 데스크탑 워크플로에 dev/preview 띄울 때 표준 패턴. |
