---
name: tistory-publisher
description: 'ICBM2 Tistory(sigco.tistory.com) 자동 발행 워크플로 — 트렌드 데이터 새로고침 → 카테고리별 발행 시도 → §3.5 3중 신호 검증 → §3.11 sync → §4 stats 보정의 정형 파이프라인. §3.8.1 세션 만료 가드 (302 → /auth/login) 통과시에만 publish 단계 진행, 실패시는 단순 skip 후 §3.5 검증만 실행. 가짜 발행(통계+1 + 실제 글 없음) 방지 최우선. cron으로 자동 실행되며 사용자가 직접 호출할 일은 드묾. 트리거 — "Tistory 발행", "블로그 자동 발행", "§3.8.1 가드", "가짜 발행 방지", "ICBM2 publish".'
---

# Tistory Publisher (ICBM2)

ICBM2 자동화 시스템의 Tistory 발행 워크플로. **288차+ 연속 all-green 운영 중** (2026-07-24 319차 기준 99회차, 2026-07-26 320차 zombie 302 후 322차 수동 회복 후 정상).

**가장 최근 세션**: 325차 (2026-07-27 00:01) — #1106 "인터페이스가 화면을 벗어나고 있다 - 채팅, 음성, 에이전트형 AI가 바꾸는 UX" 발행 (AI/ML, gn=31818, score 8.0) + §3.5 진입 시점 drift 자연 상태 처리 (297차 정형화 재확인 — daily_counts=0 + last=#1105 → 신호 4 미발동 → publish 가능) + **단일 패스 패턴 16연속 정형화** (305→325) + **신호 4 오탐 disambiguate 25연속 확정** (298→325) + **311차 fallback 패턴 미사용** — AI/ML 후보 충분으로 §3-a 즉시 ready (311~319차 fallback 반복에서 한 번도 호출되지 않음 → 후보 회복 정상). 연속 all-green **100회차 마일스톤**.

**가장 최근 세션 만료 점검**: 322차 (2026-07-26 17:13) — 세션 만료 후 수동 쿠키 갱신. REACTION_GUEST 진짜 hash(`684fb927c0b3ab...`)+ TSSESSION/`_T_ANO` 새 값, `__T_/__T_SECURE=1` fallback 유지. 3-endpoint probe HTTP 200 + `tistory_publisher.py --check-session` "총 962개 글" 정상 회복 + **함정 19 정형화** — `verify-tistory-cookie.sh` step [3] env 값-모양 hardcode의 false-positive 패치 (REACTION_GUEST/__T_/__T_SECURE 3건을 LENGTH 검증 + INFO 출력으로 soft화, verdict 로직에 RECOVERED 분기 추가). 패치 후 `PASS=13 FAIL=0 WARN=0 INFO=3` 정상 라벨. 만료 추이 5단계 갱신: 184차(6/29)→196차(7/2, 3일)→7/6(8일)→319차(7/24, 18일)→320차 zombie 302(7/26, 36시간)→**322차 수동 회복(7/26)**.

**325차 세션 노트**: [`references/session-20260727-325th-interface-leaves-screen-ux-shift.md`](references/session-20260727-325th-interface-leaves-screen-ux-shift.md)

**319차 세션 노트**: [`references/session-20260724-319th-omniroute-ai-gateway.md`](references/session-20260724-319th-omniroute-ai-gateway.md)

**318차 세션 노트**: [`references/session-20260724-318th-chrome-extension-personal-tools.md`](references/session-20260724-318th-chrome-extension-personal-tools.md)

**317차 세션 노트**: [`references/session-20260724-317th-nvchat-windows-llm-client.md`](references/session-20260724-317th-nvchat-windows-llm-client.md) (#1096), [`references/session-20260724-317th-making-things-philosophy.md`](references/session-20260724-317th-making-things-philosophy.md) (#1093 sibling)

**316차 세션 노트 (직전)**: [`references/session-20260723-316th-bento-singlefile-office.md`](references/session-20260723-316th-bento-singlefile-office.md)

**315차 세션 노트**: [`references/session-20260723-315th-linux-kernel-cve-432.md`](references/session-20260723-315th-linux-kernel-cve-432.md)

**314차 세션 노트**: [`references/session-20260722-314th-ai-prosperity-volition.md`](references/session-20260722-314th-ai-prosperity-volition.md)

## ⛔ 최우선 규칙

1. **§3.8.1 세션 만료 가드 통과시에만 publish 단계 진행**. 실패시 → 단순 skip + §3.5 검증만 실행 후 종료.
2. **가짜 발행 절대 금지**: 통계(daily_counts) +1 후 실제 Tistory 글 없이 종료 불가.
3. **중복 skip 후 publish 금지**: dedup 통과하지 않은 topic을 publish하면 통계 오염.
4. **publish 후 details/last 갱신 필수**: 191차 §8.5.2 무효화 환경 의존 패턴.

## 실행 절차

### 1단계: §3.8.1 세션 만료 가드 (필수, publish 직전)

`scripts/session_expiry_guard.sh` 실행. 통과시에만 다음 단계 진행.

```bash
unset PYTHONPATH
~/.hermes/skills/tistory-publisher/scripts/session_expiry_guard.sh
# exit 0 → 진행 / exit 1 → 세션 만료, skip
```

**⚠️ 303차 함정 10**: 가드가 exit 10 (NO_COOKIES), exit 3 (session_status 302), 또는 SyntaxError로 실패하는 환경이 있다 (Xcode python3 충돌 / user-site 격리 실패 / env -i가 source된 환경변수 미보존). **임시 우회** 가드 실패시 raw 검증을 cron이 직접 수행:

```bash
set -a; source ~/.hermes/secrets/tistory.env; set +a
unset PYTHONPATH PYTHONHOME
PYTHONNOUSERSITE=1
export PYTHONPATH=/Users/mac/Library/Python/3.9/lib/python/site-packages
/usr/bin/python3 -s << 'PYEOF'
import os, requests, re
cookies = {k.replace('TISTORY_',''): os.environ[k] for k in os.environ if k.startswith('TISTORY_')}
hdr = {'User-Agent':'Mozilla/5.0','Referer':'https://sigco.tistory.com/manage/','X-Requested-With':'XMLHttpRequest'}
r = requests.get('https://sigco.tistory.com/manage/posts.json?category=-3&page=1', cookies=cookies, headers=hdr, timeout=10, allow_redirects=False)
print(f'status={r.status_code}')
print(f'content_type={r.headers.get("content-type","?")}')
if r.status_code == 200 and 'application/json' in r.headers.get('content-type',''):
    try:
        data = r.json()
        items = data.get('items', [])
        first_id = items[0]['id'] if items else '?'
        print(f'first_id={first_id}')
        print('✅ OK: 세션 유효, 발행 진행')
    except Exception as e:
        print(f'⚠️ JSON parse fail: {e}')
elif r.status_code == 302 and '/auth/login' in r.headers.get('location',''):
    print('⏸️ SKIP: §3.8.1 세션 만료 (302 → /auth/login). 브라우저 쿠키 갱신 필요.')
else:
    print(f'⏸️ SKIP: 알 수 없는 만료 패턴 status={r.status_code}')
PYEOF
```

✅ VALID 기준: status=200 + content_type=application/json + `items[0]['id']`가 last_published_url과 일치하거나 직전 발행 #NNN보다 큼.

### 2단계: 트렌드 데이터 확인

```bash
unset PYTHONPATH
env -i HOME="$HOME" PATH=/usr/bin:/bin PYTHONPATH= /usr/bin/python3 \
  ~/.hermes/scripts/blog_pipeline.py --refresh-topics
```

### 3단계: 카테고리별 발행 시도 (AI/ML 우선) + 별도 publish 단계

**3-a. topic 선정 + 가이드라인 출력**:

```bash
unset PYTHONPATH
env -i HOME="$HOME" PATH=/usr/bin:/bin PYTHONPATH= /usr/bin/python3 \
  ~/.hermes/scripts/blog_pipeline.py --category 'AI/ML'
```

⚠️ **293차 함정**: `run_pipeline()`은 publish 자체를 실행하지 않고 `status=ready` JSON(가이드라인 + topic 메타)까지만 출력하고 종료한다. **publish는 별도 단계**로 `tistory_publisher.py`를 직접 호출해야 한다. SKILL.md의 이 3-a 단계는 **topic 선정 + 가이드라인 출력**까지만 책임지고, 3-b가 실제 발행을 담당한다.

**3-b. publish 단계 (297차 확정, `tistory_publisher.py` 직접 호출)**:

3-a에서 `status=ready`를 받은 직후, **별도 명령**으로 `tistory_publisher.py`를 직접 실행한다. cron 워크플로우가 두 호출을 모두 수행하는지 매 차 검증 필수.

```bash
set -a; source ~/.hermes/secrets/tistory.env; set +a
unset PYTHONPATH
/usr/bin/python3 ~/.hermes/scripts/tistory_publisher.py \
  --title "..." \
  --tags "tag1,tag2,..." \
  --visibility public \
  --category 1219746 \                          # ← int 카테고리 ID (AI/ML = 1219746)
  --source-url 'https://news.hada.io/topic?id=N' \
  --gn-topic-id N \
  --file /tmp/post_XXX.html                      # ← --file 사용 (--html-file 아님)
```

응답 stdout에서 `🔗 https://sigco.tistory.com/NNN` 패턴을 grep해 발행 URL 추출. `--record-topic`은 사용하지 않는다 (함정 1: placeholder 박힘).

**함정 7 (297차 신규) — `tistory_publisher.py` CLI 옵션 함정**

SKILL.md 본문이 `--category 'AI/ML'` (str)로 가이드하지만, 실제 인자 parser는 **int만** 받는다. str `'AI/ML'`을 넘기면 `argument --category: invalid int value: 'AI/ML'` 에러로 즉시 종료한다. 옵션 실측 표:

| 옵션 | 타입 | 비고 |
|------|------|------|
| `--title` | str | 필수 |
| `--tags` | str | comma-separated |
| `--visibility` | `public`/`private`/`friends` | 기본 public |
| `--category` | **int** | TISTORY 카테고리 ID (1219746=AI 뉴스, 1219747=개발 팁, 1219748=자동화&툴 리뷰, 1219750=투자&경제, 1219752=아이디어, 1219751=기타) |
| `--source-url` | str | 긱뉴스 URL |
| `--gn-topic-id` | int | 긱뉴스 토픽 ID |
| `--file <path>` | str | **Markdown 파일 경로** (H1=제목, `tags:` 라인=태그, 나머지는 내장 Markdown→HTML 변환; 이미 HTML을 넣어도 읽히지만 확장자/내용 기준은 Markdown) |
| ~~`--category-id`~~ | ❌ 미존재 | `--category` 사용 |
| ~~`--description`~~ | ❌ 미존재 | meta description은 Tistory가 자동 추출 |
| ~~`--html-file`~~ | ❌ 미존재 | `--file` 사용 |

**함정 13 (306차 신규) — `run_pipeline()` topic 선정 비결정성**: `~/.hermes/scripts/blog_pipeline.py --category 'AI/ML'`을 같은 세션 안에서 두 번 연속 호출하면 1회차엔 gn=31611 (Codex 272k), 2회차엔 gn=31599 (Qwen 3.8) 등 **호출마다 다른 후보**를 반환할 수 있다. Notion DB 활성 후보 셔플 / 폴링 순서 / `get_fallback_topic()` 내부 timestamp 의존성 등으로 비결정적 동작. **영향**: cron이 `run_pipeline()` stdout에서 topic을 추출해 publish 인자로 넘기는 패턴이라면, 호출 사이에 다른 후보가 들어와도 publish URL은 `https://sigco.tistory.com/NNN` grep으로 정상이라 외부 영향 없음 — 단, 같은 차에 두 번 publish하지 않도록 **publish URL 추출 후 동일 #NNN 중복 가드는 여전히 필수**. **운영 권장**: `run_pipeline()`을 한 번만 호출해 topic 확정 후 즉시 publish 단계로 진입. 306차 검증 (1회차=31611 → 즉시 publish #1060 → 정상).

#### 3-B. AI/ML 후보 소진 시 다른 카테고리 fallback (311차 신규, 정형화)

§3-a에서 `status=skip` + `"reason": "... 카테고리의 긱뉴스 주제와 트렌드 주제 모두 소진되었습니다"`를 받으면, 같은 차 cron은 곧바로 다른 카테고리로 fallback 시도한다. 사용자 instruction은 "AI/ML 우선 + 다른 카테고리 시도"를 명시하나 SKILL.md 본문에 정형 워크플로우가 없었다. 311차 첫 실전 검증으로 확정.

**fallback 시도 우선순위** (긱뉴스 트래픽 분포 + 개발자 블로그 특성 반영):
1. `개발도구` (1219748) — 가장 자주 후보 남음
2. `개발 팁` (1219747) — 가끔 후보 남음
3. `iOS/Swift` (해당 ID는 trends DB에서 동적) — 시즌 의존
4. `투자/경제` (1219750)
5. `아이디어` (1219752)
6. `기타` (1219751)

```bash
unset PYTHONPATH PYTHONHOME
PYTHONNOUSERSITE=1
export PYTHONPATH=/Users/mac/Library/Python/3.9/lib/python/site-packages
/usr/bin/python3 -s ~/.hermes/scripts/blog_pipeline.py --category '개발도구'
# status=ready → 3-b publish 단계로 진입
# status=skip → 다음 카테고리로 fallback
```

**3-b publish 단계** (선정된 카테고리 ID로 변경):
```bash
set -a; source ~/.hermes/secrets/tistory.env; set +a
unset PYTHONPATH PYTHONHOME
PYTHONNOUSERSITE=1
export PYTHONPATH=/Users/mac/Library/Python/3.9/lib/python/site-packages
/usr/bin/python3 -s ~/.hermes/scripts/tistory_publisher.py \
  --title "..." \
  --tags "tag1,tag2,..." \
  --visibility public \
  --category 1219748 \   # ← fallback 시점에 선정된 카테고리 ID (str '개발도구' 안 됨)
  --source-url '...' \
  --gn-topic-id N \
  --file /tmp/post_XXX.html
```

**3-b.5 commit_publish 카테고리 인자** (`blog_pipeline.py --commit`):
```bash
/usr/bin/python3 -s ~/.hermes/scripts/blog_pipeline.py --commit \
  "TOPIC_ID" "TITLE" "https://sigco.tistory.com/NNN" \
  "개발도구" \    # ← 카테고리명 (str, --category의 int와 다름!)
  "https://news.hada.io/topic?id=N"
```

**311차 실전 검증**:
- §3-a `blog_pipeline.py --category 'AI/ML'` → `status=skip` ("AI/ML 카테고리의 긱뉴스 주제와 트렌드 주제 모두 소진되었습니다")
- §3-b fallback: `--category '개발도구'` → `status=ready` + gn=31631 "수랭식 침대를 제어하는 API 클라이언트 bedctl"
- §3-b publish: `--category 1219748` (int) → #1074 발행 성공 (OG 썸네일 `https://blog.kakaocdn.net/dna/rP5nM/...` 설정)
- §3-b.5 commit: `--commit ... "개발도구" ...` (str) → stats.today={AI/ML:5, 개발도구:1}, total=68

**판정 매트릭스**: §3.8.1 raw VALID + §3.5 신호 4 오탐 확정(5-5 PASS) + 295차 무조건 발행 정책 + §3-a `status=skip` → §3-b fallback 진입. 카테고리 ID 매핑은 §3-b 함정 7 표 참조.

- **함정 16 (311차 신규)**: §3-b commit_publish 카테고리 인자 타입 — `--category`는 int(1219748)지만 `--commit`의 카테고리 인자는 str("개발도구"). 두 호출의 카테고리 인자 타입이 다르다 — 혼동 시 `argument --category: invalid int value: '개발도구'` (publish) 또는 stats.by_category에 새 str 키 누적 (commit). **원칙**: publish=`--category <int>`, commit=마지막 위치 인자에 `<str 카테고리명>`.
- **함정 17 (317차 신규, sibling subagent 발견)** — `build_post_XXX.py` 단일 큰 f-string 회피. 305차 패턴으로 본문 + docstring + 코드 블록 + 푸터를 한 개의 큰 f-string에 우겨넣으면 (a) `write_file` lint 단계에서 `SyntaxError: invalid syntax` (f-string 내부 비-ASCII docstring의 따옴표 매칭 깨짐) (b) sibling subagent write 경고 동시 노출. **해결 (317차 정형화)**: 본문을 `parts.append('<tag>...</tag>')` 리스트에 모으고 마지막에 `"\n".join(parts)`로 한 번만 합친다. 코드 블록은 `code_lines = [...]` → `code_html = '<pre><code class="language-xxx">' + "\n".join(code_lines) + '</code></pre>'`. 푸터는 `+ GN_URL +` concat. **장점**: lint 안정, sibling write 시에도 parts.append 단일 라인 patch 가능, 가독성·유지보수 ↑. **판정 (318차 정형화)**: 빌드 스크립트 본문 길이 기준으로 (a) **본문 3000자 미만 = 단일 f-string OK** (317차 #1096 6952자에서 lint 실패 발생, 318차 #1097 2776자 단일 f-string으로 정상 — 317차 NvChat이 함정 17 임계점 직상단 사례) (b) **본문 3000자 이상 + docstring/코드 블록/푸터 동시 사용 = 처음부터 parts.append() 권장**. 318차 실전 검증: 2776자 단일 f-string lint 정상 + sibling write 경고 0건.

#### 3-A. 무조건 발행 정책 (295차, 2026-07-19 사용자 확정)

사용자가 **"점수 관계 없이 무조건 발행" → "완전 무조건 발행 (모든 skip 제거)"**를 확정했다. 최신 정책이므로 과거 293~294차의 score/sensational/stale 품질 보류 규칙보다 우선한다.

- `get_fallback_topic()`은 score 재정렬, sensational 필터, 연도 기반 stale 필터를 적용하지 않고 **Notion 순서 그대로** 후보를 선택한다.
- `run_pipeline()`의 timeliness `block`/`warning`은 **경고 로그만 남기고 발행을 계속**한다.
- 유지되는 중단 조건은 운영상 불가능한 경우뿐이다: §3.8.1 세션 만료, exact hash/URL 중복, 후보 소진, publish 자체 실패.
- 선정 후 별도 품질 판단으로 다시 보류하지 않는다. 295차 사용자 결정으로 발행 품질보다 발행 연속성이 우선이다.

검증 기준:
```bash
unset PYTHONPATH
env -i HOME="$HOME" PATH=/usr/bin:/bin PYTHONPATH= /usr/bin/python3 \
  ~/.hermes/scripts/blog_pipeline.py --category 'AI/ML'
# 후보가 있으면 score·문구·연도와 무관하게 status=ready
```

**295차 실측**: Notion 첫 미발행 후보가 이전 필터 대상 문구와 2025 연도를 포함해도 선정되었고, `run_pipeline(force_category='AI/ML')`이 `status=ready`를 반환했다. 같은 시각 cron은 §3.8.1에서 302 만료를 감지해 publish 전 안전 중단했으므로, 무조건 발행 정책과 세션 안전 가드는 충돌하지 않는다.

#### 3-A-1. 새 날 drift는 자연 상태 (297차 확정)

§3.5 신호 1 (`last_url` 있는데 daily_counts[오늘]=0) drift 경고는 두 경우를 구분해야 한다:

| 조건 | 판정 | 액션 |
|------|------|------|
| daily_counts[오늘] ≥ 2 AND details[-1] 변동 없음 | **FAKE_PUBLISH** (289차 신호 4) | publish skip + stats 추가 박기 금지 |
| daily_counts[오늘] = 0 (어제 정상 발행이 오늘은 빈 새 날) | **자연 상태** (297차) | publish 진행 가능 (295차 정책) |

`last_published_url`은 마지막 발행을 가리키므로 자정 넘긴 직후엔 어제 글이 그대로 남고, daily_counts는 새 날이라 빈 상태 — drift 경고가 떠도 정상. FAKE_PUBLISH 미발동이면 발행 진행.

**판정 매트릭스**: §3.8.1 raw VALID + §3.5 신호 4 미발동(오늘 count=0 또는 ≥2인데 details[-1] 슬롯 변동) → 발행 진행.

### 4단계: §3.5 3중 신호 검증 (publish 직후 + 가드 skip시 둘 다)

```bash
unset PYTHONPATH
env -i HOME="$HOME" PATH=/usr/bin:/bin PYTHONPATH= /usr/bin/python3 \
  ~/.hermes/skills/tistory-publisher/scripts/check_state_consistency.py
```

3중 신호:
1. `state.last_published_url` — 직전 발행 슬롯
2. `state.daily_counts[오늘]` — 카테고리별 카운트
3. `state.last_topics[-1]` — 직전 발행 topic 메타

### 5단계: §3.11 5단계 sync + §4 5-1 stats 보정 (publish 성공시만)

**292차 실전 검증 패턴** — `tistory_publisher.py --record-topic`이 publish_post()의 entryUrl을 받지 못함. 인자로 준 URL이 그대로 `published_topics.json`에 박힘. → **URL placeholder 잔재 함정 회피 필수**.

#### 5-1. publish 단계에서 placeholder 절대 금지

```bash
# ❌ 잘못된 패턴 — "TBD" 같은 placeholder가 details/last에 그대로 박힘
python3 tistory_publisher.py --title "..." --content "..." \
  --record-topic "TOPIC" "TITLE" "https://sigco.tistory.com/TBD" "https://news.hada.io/topic?id=N"

# ✅ 올바른 패턴 — --record-topic 생략, publish 성공 URL만 받기
URL=$(python3 tistory_publisher.py --title "..." --content "..." 2>&1 | grep -oE 'https://sigco\.tistory\.com/[0-9]+')
# 또는 응답 파싱 후 commit_publish로 분리 호출
```

#### 5-2. publish 성공 후 보정 절차 (3개 패치)

publish_post()가 `entryUrl`을 stdout에 출력했으면 (✅ 발행 성공), 다음 3패치를 순서대로 실행:

```bash
set -a; source ~/.hermes/secrets/tistory.env; set +a
unset PYTHONPATH
env -i HOME="$HOME" PATH=/usr/bin:/bin PYTHONPATH= /usr/bin/python3 \
  ~/.hermes/scripts/blog_pipeline.py --commit "TOPIC_ID" "TITLE" "https://sigco.tistory.com/NNN" "AI/ML" "https://news.hada.io/topic?id=N"
# → state.json의 daily_counts/total/by_category/last_topics 갱신됨 (last_published_url은 미갱신 — 5-3에서 패치)
```

**5-2-A. published_topics.json details[].url 보정** (--record-topic으로 placeholder 박았을 경우 + 300차 확장: 누락 발행분 백필):
```bash
unset PYTHONPATH
/usr/bin/python3 << 'PYEOF'   # 296차 함정 6 회피: env -i 제거, 격리 모드 불필요
import json
from pathlib import Path
pt_path = Path.home() / '.hermes' / 'memory' / 'published_topics.json'
data = json.loads(pt_path.read_text())

# (1) 기존: placeholder URL → 실제 URL 보정 (함정 1)
for entry in data.get('details', []):
    if entry.get('url') in ('https://sigco.tistory.com/TBD', None, ''):
        entry['url'] = 'https://sigco.tistory.com/NNN'  # 실제 publish URL
last = data.get('last', {})
if last.get('url') in ('https://sigco.tistory.com/TBD', None, ''):
    last['url'] = 'https://sigco.tistory.com/NNN'
    data['last'] = last

# (2) 300차 신규: 누락 발행분 백필
# state.json의 details에는 있지만 published_topics.json에는 없는 URL을 백필
state_path = Path.home() / '.hermes' / 'memory' / 'blog_pipeline_state.json'
state = json.loads(state_path.read_text())
existing_urls = {d.get('url') for d in data.get('details', [])}
backfilled = 0
for d in state.get('details', []):
    url = d.get('url')
    if url and url not in existing_urls and url.startswith('https://sigco.tistory.com/'):
        data.setdefault('details', []).append({
            'topic': d.get('topic', '?'),
            'title': d.get('title', ''),
            'hash': '',  # 300차: 복원이므로 hash는 placeholder (외부 audit 영향 없음)
            'url': url,
            'date': (d.get('timestamp') or '')[:10] or '2026-07-20',
        })
        backfilled += 1
        existing_urls.add(url)

# (3) last 동기화 (state.details[-1] == url일 때)
state_last_url = state.get('last_published_url')
if state_last_url and data.get('last', {}).get('url') != state_last_url:
    state_last_entry = state.get('details', [{}])[-1]
    data['last'] = {
        'topic': state_last_entry.get('topic', '?'),
        'title': state_last_entry.get('title', ''),
        'hash': '',
        'url': state_last_url,
        'date': (state_last_entry.get('timestamp') or '')[:10] or '2026-07-20',
    }

pt_path.write_text(json.dumps(data, ensure_ascii=False, indent=2))
print(f'[5-2-A] placeholder 보정 + 누락 백필={backfilled}, details_len={len(data["details"])}')
PYEOF
```

**300차 확장 이유**: `commit_publish()`와 `tistory_publisher.py --publish-only`는 published_topics.json을 갱신하지 않음. 297~299차 모두 --record-topic 미사용 → state.json은 진실(#1050까지 추적), published_topics.json은 #1044에서 stale. 매 차 누락분이 누적되므로 5-2-A에서 **state.json → published_topics.json 단방향 백필**을 idempotent하게 수행. details URL 중복 체크로 안전.

**5-3. state.json last_published_url + last_published_id + details append 보정** (`commit_publish()`가 세 필드를 모두 갱신하지 않음, 293차 함정 4·5 + 298차 표준화):
```bash
unset PYTHONPATH
/usr/bin/python3 << 'PYEOF'
import json
from pathlib import Path
state_path = Path.home() / '.hermes' / 'memory' / 'blog_pipeline_state.json'
data = json.loads(state_path.read_text())
new_url = 'https://sigco.tistory.com/NNN'
new_id = 'NNN'
data['last_published_url'] = new_url   # commit_publish() 미갱신 (293차 함정 4)
data['last_published_id'] = new_id      # commit_publish() 미갱신 (293차 함정 5)

# details append (293차 함정 4 해결, 298차 5-3에 통합)
# 마지막 entry가 새 URL이 아니면 append — SSOT 자동 동기화
details = data.get('details', [])
if not details or details[-1].get('url') != new_url:
    details.append({
        'topic': '<TOPIC_ID>',
        'category': '<CATEGORY>',
        'title': '<TITLE>',
        'url': new_url,
        'timestamp': '<ISO_TIMESTAMP>'
    })
    data['details'] = details

state_path.write_text(json.dumps(data, ensure_ascii=False, indent=2))
print(f'[5-3] last=#{new_id} details_len={len(details)}')
PYEOF
```

**5-3 canonical topic hash 주의 (323차 실전)**: 수동으로 `published_topics.json`을 동기화할 때 `topics` 배열과 details의 `hash`는 블로그 제목이나 SEO 확장 제목이 아니라, `run_pipeline()`이 반환한 **원래 `topic` 문자열**의 `md5`여야 한다. 예를 들어 topic이 `stinkpot - SQLite 기반 Bash 셸 히스토리 검색기`이고 실제 Tistory 제목에 `— 개발자가 알아야 할 핵심 정리`가 붙었다면, 해시는 전자의 정확한 문자열로 계산한다. 그렇지 않으면 실제 글이 있어도 다음 후보 선정에서 중복으로 인식되지 않는다. `source_url`은 별도로 `published_urls.txt`에 기록한다.

**298차 표준화 이유**: 기존엔 5-3에서 last 두 필드만 갱신하고 details append는 별도 단계(또는 사용자 게이트)로 분리되어 매 차 293차 함정 4가 반복 노출됨. 5-3에 통합해 한 번의 스크립트로 세 필드 동기화. 단, details가 진짜 stale (Tistory 측 신규 글 없이 stats만 박힌 가짜 발행 잔재)인 경우엔 §3.5 신호 4 발동 상태로 publish skip이 우선 — 본 5-3은 정상 publish 완료 후에만 실행.



#### 5-4. 최종 §3.5 검증 (3중 신호 일치 확인)

```bash
unset PYTHONPATH
env -i HOME="$HOME" PATH=/usr/bin:/bin PYTHONPATH= /usr/bin/python3 \
  ~/.hermes/skills/tistory-publisher/scripts/check_state_consistency.py
# ✅ OK: 3중 신호 일치 확인되어야 정상 종료
```

#### 5-5. proxy check (실제 Tistory 글 존재 검증, 선택이지만 권장)

```bash
set -a; source ~/.hermes/secrets/tistory.env; set +a
unset PYTHONPATH PYTHONHOME
PYTHONNOUSERSITE=1
export PYTHONPATH=/Users/mac/Library/Python/3.9/lib/python/site-packages
/usr/bin/python3 -s << 'PYEOF'
import os, requests, re
cookies = {k.replace('TISTORY_',''): os.environ[k] for k in os.environ if k.startswith('TISTORY_')}
r = requests.get('https://sigco.tistory.com/NNN',
  cookies=cookies,
  headers={'User-Agent':'Mozilla/5.0'}, timeout=10, allow_redirects=False)
print(f'status={r.status_code}')
m = re.search(r'<title>([^<]+)</title>', r.text)
if m: print(f'title={m.group(1)[:80]}')
og = re.search(r'<meta property="og:title" content="([^"]+)"', r.text)
if og: print(f'og:title={og.group(1)[:80]}')
PYEOF
# status=200 + og:title 매칭 = 진짜 발행 확인 (함정 15: §1단계와 동일 격리 패턴 필수)
```

**함정 15 (309차)**: 위 예제는 SKILL.md 본문 5-5 예제를 §1단계 가드와 동일한 격리 패턴(`unset PYTHONPATH PYTHONHOME; PYTHONNOUSERSITE=1; export PYTHONPATH=user-site; /usr/bin/python3 -s`)으로 교체한 형태. 기존 단순 `unset PYTHONPATH`만으로는 `ModuleNotFoundError`가 발생할 수 있음 — 정형 패턴으로 통일.

#### §3.11/§4 보정 함정 정리 (292차 신규)

- **함정 1**: `--record-topic` URL 인자 = `tistory_publisher.py`가 그 값을 그대로 published_topics.json에 박음. publish_post()의 entryUrl을 받지 못함. → **URL 자리에 진짜 URL을 넣거나 placeholder 회피**
- **함정 2**: `commit_publish()`는 state.json의 last_published_url을 **갱신하지 않음** → 5-3 수동 패치 필수
- **함정 3**: 긱뉴스 본문 selector (`.topic-text`, `.topic-body`, `<p>`) 모두 본문이 아니라 코멘트만 잡힘 → **OG description 사용이 가장 안정적**
- **함정 4 (293차 신규, 298차 해소)**: `commit_publish()`가 `details` 배열에 새 entry를 append하는지 **검증 안 됨** — 293차 상태에서 #1044, #1045 발행 후 details[-1]이 #1043 그대로 stale. → **298차에 5-3 표준 보정에 details append 통합** (정상 publish + commit_publish 후 5-3 한 번 실행으로 세 필드 동기화). 진짜 가짜 발행 잔재 (Tistory 측 신규 글 없이 stats만 박힌 상태)인 경우엔 §3.5 신호 4가 발동하므로 publish skip이 우선.
- **함정 5 (293차 신규)**: `last_published_id` 필드 갱신 누락 — `last_published_url`은 "/1045"인데 `last_published_id="1043"`인 mismatch 상태. `commit_publish()`가 둘 다 갱신하지 않는다면 5-3에서 `last_published_id`도 함께 패치 필요. 두 필드의 SSOT 정합이 깨지면 차후 신호 1~3 판정에 혼란
- **함정 6 (296차 신규)**: heredoc + `env -i` 조합 함정 — `env -i ... /usr/bin/python3 << 'PYEOF' ... PYEOF` 패턴은 shell redirection 단계에서 두 명령을 합치려 하면서 `Non-UTF-8 code starting with '\xca'` SyntaxError로 실패한다. **해결**: 본문 생성 스크립트는 항상 별도 파일(`/tmp/build_post_XXX.py`)로 만들고 `env -i ... python3 /tmp/build_post_XXX.py > /tmp/post.html`로 실행. 또는 `set -a; source tistory.env` 후 heredoc만 사용 (격리 모드 포기).
- **함정 7 (297차 신규)**: `tistory_publisher.py` CLI 옵션 함정 — `--category`는 **int만** 받음. str `'AI/ML'`을 넘기면 즉시 종료. `--category-id` / `--description` / `--html-file` 옵션 미존재 (`--file` 사용). 옵션 실측 표는 §3-b 참고. SKILL.md 본문이 `--category 'AI/ML'`로 잘못 가이드되어 있어 다음 차에 또 함정 노출됨.
- **함정 8 (297차 신규, 299차 누적 가속)**: `commit_publish()` → `update_stats()` 결과 `by_category`에 정수 카테고리 ID가 키로 박힘 (예: `"1219746": 1`). 카테고리명 norm(`"AI/ML"`)이 아닌 ID가 누적되어 카테고리별 집계 시 duplicate. today 카운트는 정상이라 stats today 자체는 OK지만 by_category 키 누적이 누적됨. **판정**: SSOT 변경이라 임의 자동 보정 금지. **탐지 + 운영자 알림** 패턴 권장 — 매 차 publish 직후 `by_category` 키가 int만으로 구성됐는지 검사해 drift면 보고 라인에 명시.

  **누적 현황 (302차 기준)**:
  - 297차 #1048 발행: `by_category["1219746"] = 1` 추가
  - 298차 #1049 발행: `by_category["1219746"] = 1` 유지 (이미 존재 → 코드 동작은 `=` 할당, 신규 누적은 없음)
  - 299차 #1050 발행: `by_category["1219746"] = 1` 동일
  - 301차 #1052 발행: `by_category["1219746"] = 1` 동일 유지
  - **302차 #1053 발행**: `by_category["1219746"] = 1` 동일 유지 (5연속 동일 — 코드 동작 `=` 할당으로 첫 매핑 후 영구 누적 없음)
  - net: 정수 ID 키 1개가 카테고리명 `"AI/ML"` 키와 별도로 영구 누적 (297차 1회 추가 후 고정)

  **정형 보정 절차** (SSOT 변경 — 사용자 게이트 필수, cron은 drift 보고만, 임의 자동 실행 금지):
  ```bash
  unset PYTHONPATH
  /usr/bin/python3 << 'PYEOF'
  import json
  from pathlib import Path
  state_path = Path.home() / '.hermes' / 'memory' / 'blog_pipeline_state.json'
  data = json.loads(state_path.read_text())
  bc = data.get('by_category', {})
  ID_TO_NAME = {1219746:'AI/ML', 1219747:'개발 팁', 1219748:'개발도구',
                1219750:'투자/경제', 1219752:'아이디어', 1219751:'기타'}
  migrated = 0
  for k in list(bc.keys()):
      if k.isdigit() and int(k) in ID_TO_NAME:
          name = ID_TO_NAME[int(k)]
          bc[name] = bc.get(name, 0) + bc[k]
          del bc[k]
          migrated += 1
  data['by_category'] = bc
  state_path.write_text(json.dumps(data, ensure_ascii=False, indent=2))
  print(f'[by_category 정리] migrated={migrated}, keys={list(bc.keys())}')
  PYEOF
  ```

- **함정 9 (301차 신규)**: `env -i HOME=... PATH=... PYTHONPATH= /usr/bin/python3 /usr/bin/python3 <script>` 같이 `python3`를 두 번 쓰는 형태 → SyntaxError (`Non-UTF-8 code starting with '\xca' in file /usr/bin/python3 on line 1`). shell이 env 커맨드와 스크립트 경로를 합치려 하면서 python3 바이너리 자체를 스크립트로 오인. **해결**: `env -i ... /usr/bin/python3 <script>` 단일 형태로 호출. SKILL.md 본문 가이드는 이미 단일 형태지만, 자동화 스크립트 작성 시 실수하기 쉬운 함정 — **운영자가 copy-paste로 python3를 두 번 붙이지 않도록 주의**.
- **함정 10 (303차 신규) — 가드 격리 모드 자체의 환경 한계**: `session_expiry_guard.sh`는 `env -i HOME=... PATH=/usr/bin:/bin PYTHONPATH= /usr/bin/python3` 형태로 호출되지만 두 환경에서 실패한다.
  1. **Xcode python3 충돌**: macOS 환경에서 `/usr/bin/python3`가 Xcode 번들 (`/Applications/Xcode.app/...`)의 3.9.6을 가리키는 경우가 있음 (PATH 우선순위 의존). 그 python3에는 `requests` 모듈이 없어 `ModuleNotFoundError`로 가드 자체가 실패 (exit 10).
  2. **user-site 격리**: `requests`가 시스템이 아닌 `/Users/mac/Library/Python/3.9/lib/python/site-packages` (사용자 site-packages)에만 설치된 경우, `env -i PYTHONPATH=`로는 그 경로를 못 잡는다. `python -s` 옵션은 user-site를 비활성화하므로 정반대로 더 안 잡힘.
  3. **env -i가 source된 환경변수를 날림**: `set -a; source tistory.env; set +a`로 미리 TISTORY_* 쿠키를 export해도 `env -i`는 자기 뒤에 오는 환경변수만 보존하고 source로 이미 들어간 변수도 무시. 결과 cookies_count=0 → 302 오탐.

  **해결 (303차 실전 검증)**: 가드 스크립트 자체를 다음 형태로 교체:
  ```bash
  # ❌ 기존 (3가지 모두 깨짐)
  unset PYTHONPATH
  env -i HOME="$HOME" PATH=/usr/bin:/bin PYTHONPATH= /usr/bin/python3 ~/.hermes/skills/tistory-publisher/scripts/guard_inner.py

  # ✅ 안정적 형태 (303차 검증)
  set -a; source ~/.hermes/secrets/tistory.env; set +a
  unset PYTHONPATH PYTHONHOME
  PYTHONNOUSERSITE=1
  export PYTHONPATH=/Users/mac/Library/Python/3.9/lib/python/site-packages
  /usr/bin/python3 -s <guard_inner.py>
  ```

  **원칙**: 격리 모드(`env -i`)는 가드 단순화용 shortcut이 아니라 자체 버그 원인. (a) source한 환경변수 보존 + (b) `requests`가 사는 user-site PYTHONPATH 명시 + (c) `python3 -s`로 venv 누설 차단만으로도 충분히 격자. SKILL.md 본문 모든 `env -i ...` 호출은 시간이 지날수록 환경 의존성이 증가하므로 점진적으로 교체 권장.

  **임시 우회 (스크립트 수정 전까지)**: 가드 실패 시 raw 검증을 cron이 직접 실행:
  ```bash
  set -a; source ~/.hermes/secrets/tistory.env; set +a
  unset PYTHONPATH PYTHONHOME
  export PYTHONPATH=/Users/mac/Library/Python/3.9/lib/python/site-packages
  PYTHONNOUSERSITE=1 /usr/bin/python3 -s << 'PYEOF'
  import requests
  cookies = {k.replace('TISTORY_',''): os.environ[k] for k in os.environ if k.startswith('TISTORY_')}
  r = requests.get('https://sigco.tistory.com/manage/posts.json?category=-3&page=1',
      cookies=cookies, headers={'User-Agent':'Mozilla/5.0','Referer':'https://sigco.tistory.com/manage/','X-Requested-With':'XMLHttpRequest'},
      timeout=10, allow_redirects=False)
  print(f'status={r.status_code}')
  import re; ids = re.findall(r'"id"\s*:\s*"(\d+)"', r.text)
  print(f'first_ids={ids[:5]}')
  PYEOF
  ```
  status=200 + items[0].id 매칭 + application/json = ✅ VALID.
- **함정 11 (302차 확립, 304차 실전 재확인)**: **`execute_code` cron 차단 + write_file 분리 패턴**. Hermes의 `execute_code`는 cron 모드에서 `approvals.cron_mode` 가드로 차단되어 임의 로컬 파이썬 실행 불가 (`BLOCKED: execute_code runs arbitrary local Python`). **해결 패턴** (정형):
  ```bash
  # (a) write_file /tmp/build_post_XXX.py — body 문자열 + post_html 빌드
  # (b) read_file /tmp/build_post_XXX.py → 불필요 (이미 디스크에 박힘)
  # (c) /usr/bin/python3 -s /tmp/build_post_XXX.py → /tmp/post_XXX.html 생성
  # (d) tistory_publisher.py --file /tmp/post_XXX.html 직접 호출
  ```
  환경 격리 불필요 (`unset PYTHONPATH PYTHONHOME; PYTHONNOUSERSITE=1; export PYTHONPATH=user-site; /usr/bin/python3 -s` 형태로 303차 안정 패턴). 296차 함정 6 (heredoc + env -i SyntaxError)도 자동 회피. **304차 #1055 실전에서 이 패턴 정상 작동 재확인** (302차 확립, 303차 pass, 304차 pass — 정형 패턴).
- **함정 12 (304차 신규)**: **CDN 자체서명 SSL 경고는 발행에 영향 없음**. 본문 내 `https://cdn.sigco.dev/seed.jpg` 같은 자체서명 CDN URL 사용 시 `tistory_publisher.py`가 다음 경고 출력:
  ```
  ⚠️  이미지 다운로드 오류: HTTPSConnectionPool(host='cdn.sigco.dev', ...) 
      SSLError(SSLCertVerificationError(1, '[SSL: CERTIFICATE_VERIFY_FAILED] ...'))
  ```
  **발행 자체는 정상 성공** — Tistory가 CDN 업로드 실패한 이미지는 무시하고 텍스트/마크다운만 발행. 304차 #1055도 같은 패턴으로 정상 발행 (status=200 + og:title 매칭). **판정**: cron 로그 노이즈는 감수, 진짜 발행 판정은 §3.11 5-5 proxy check (status=200 + og:title 매칭) 단일 기준. 이미지 본문 삽입 실패가 발행 실패로 연결되지 않음.
- **함정 14 (307차 신규)**: **`import os` 누락 → NameError**. 5-5 proxy check heredoc 또는 §3.8.1 raw 검증 heredoc 작성 시 `os.environ`을 참조해야 하는데 `import os`를 빠뜨리면 즉시 `NameError: name 'os' is not defined`로 검증 단계 실패. SKILL.md 본문에 명시된 모든 heredoc 예제는 첫 줄에 `import os, requests, re`를 포함하나, 운영자가 heredoc 첫 줄을 `import requests, re`로만 작성할 때 흔히 발생하는 copy-paste 함정. **해결**: cron heredoc 첫 줄은 항상 `import os, requests, re` 세 모듈 포함. 정형 템플릿은 §1단계 가드 + §3.11 5-5 proxy check 두 곳에서 동일하게 적용.
- **함정 15 (309차 신규)**: **5-5 proxy check heredoc 격리 누락 → `ModuleNotFoundError: No module named 'requests'`**. SKILL.md 본문 §3.11 5-5 예제는 `set -a; source; unset PYTHONPATH; python3 -c "..."` 형태로 격리 미적용인데, §1단계 가드 / §3.8.1 raw 검증 / 본문 빌드는 `unset PYTHONPATH PYTHONHOME; PYTHONNOUSERSITE=1; export PYTHONPATH=/Users/mac/Library/Python/3.9/lib/python/site-packages; /usr/bin/python3 -s` 정형 패턴을 적용했다. **결과**: 5-5만 격리 안 하면 (a) Hermes venv의 urllib3가 import 시 깨지거나 (b) `requests`가 user-site에만 있을 때 모듈 못 찾음. **해결**: 5-5 proxy check도 §1단계 가드와 동일 격리 패턴 적용. **정형 템플릿**:
  ```bash
  set -a; source ~/.hermes/secrets/tistory.env; set +a
  unset PYTHONPATH PYTHONHOME
  PYTHONNOUSERSITE=1
  export PYTHONPATH=/Users/mac/Library/Python/3.9/lib/python/site-packages
  /usr/bin/python3 -s << 'PYEOF'
  import os, requests, re
  cookies = {k.replace('TISTORY_',''): os.environ[k] for k in os.environ if k.startswith('TISTORY_')}
  r = requests.get('https://sigco.tistory.com/NNN', cookies=cookies,
      headers={'User-Agent':'Mozilla/5.0'}, timeout=10, allow_redirects=False)
  print(f'status={r.status_code}')
  m = re.search(r'<title>([^<]+)</title>', r.text)
  if m: print(f'title={m.group(1)[:80]}')
  og = re.search(r'<meta property="og:title" content="([^"]+)"', r.text)
  if og: print(f'og:title={og.group(1)[:80]}')
  PYEOF
  ```
  → `og:title`까지 매칭 확인하면 진짜 발행 판정 확정. §3.11 5-5 예제 블록도 이 정형 패턴으로 통일 권장.
- **함정 16 (311차 신규)**: §3-b commit_publish 카테고리 인자 타입 — `--category`는 int(1219748)지만 `--commit`의 카테고리 인자는 str("개발도구"). 두 호출의 카테고리 인자 타입이 다르다 — 혼동 시 publish는 즉시 에러 종료, commit은 stats.by_category에 새 str 키 누적. **원칙**: publish=`--category <int>`, commit=마지막 위치 인자에 `<str 카테고리명>`.
- **함정 17 (317차 신규, sibling subagent 발견)** — `build_post_XXX.py` 단일 큰 f-string 회피. 305차 패턴으로 본문 + docstring + 코드 블록 + 푸터를 한 개의 큰 f-string에 우겨넣으면 (a) `write_file` lint 단계에서 `SyntaxError: invalid syntax` (f-string 내부 비-ASCII docstring의 따옴표 매칭 깨짐) (b) sibling subagent write 경고 동시 노출. **해결 (317차 정형화)**: 본문을 `parts.append('<tag>...</tag>')` 리스트에 모으고 마지막에 `"\n".join(parts)`로 한 번만 합친다. **판정 (318차 정형화)**: (a) **본문 3000자 미만 = 단일 f-string OK** (b) **본문 3000자 이상 + docstring/코드 블록/푸터 동시 사용 = parts.append() 권장**.
- **함정 19 (322차 신규)** — `verify-tistory-cookie.sh` step [3] env 값-모양 hardcode로 인한 false-positive. 스크립트가 `EXPECTED_LINES=("REACTION_GUEST=1" "__T_=1" "__T_SECURE=1" ...)` 형태로 fallback `=1`을 정상 패턴으로 가정해서, 주인님이 진짜 hash로 갱신하면 step [3]만 3건 FAIL로 단정되어도 step [5] check-session PASS + step [7] categories PASS면 진짜 회복이다. **판정 매트릭스**: step [5] ✅+ step [7] ✅ + step [3] FAIL ≤ 3 (모두 env 모양 drift) = **RECOVERED**. 322차 패치: step [3]을 `LENGTH_LINES`만 PASS/FAIL, `REACTION_GUEST/__T_/__T_SECURE`은 INFO 출력으로 soft 처리. verdict 로직: `FAIL ≤ 1` AND step [5] ✅ + step [7] ✅ = `✅ ad-hoc verification: RECOVERED`. 패치 후 result: `PASS=13 FAIL=0 WARN=0 INFO=3` + exit_code 0 정상.

## 🌅 아침 세션 만료 점검 cron (별도 워크플로우, 320차 정형화)

발행 cron(아래 §1~§5 단계)과 **다른 cron 잡**. 하루 1회 또는 정기적으로 Tistory 쿠키가 살아있는지만 검증. 세션이 만료됐으면 주인님께 텔레그램 알림.

**차이점**:
- 발행 cron: `session_expiry_guard.sh` 사용, publish까지 진행
- 아침 점검 cron: `verify-tistory-cookie.sh` 사용, 검증 + 알림만

### 아침 점검 cron 실행 절차 (320차 정형)

**1단계: ad-hoc 세션 검증 스크립트 실행**

```bash
bash ~/.hermes/skills/automation/tistory-publisher/scripts/verify-tistory-cookie.sh 2>&1
```

**2단계: 결과 해석**
- `RESULT: PASS=N FAIL=0 WARN=0` → ✅ 정상. 알림 불필요. 종료.
- `FAIL >= 1` → 세션 만료 의심. **3-endpoint probe로 §3.8 vs §3.8.1 구분**:

**3단계: 3-endpoint probe (FAIL 시)**
```bash
set -a; source ~/.hermes/secrets/tistory.env; set +a
unset PYTHONPATH PYTHONHOME
PYTHONNOUSERSITE=1
export PYTHONPATH=/Users/mac/Library/Python/3.9/lib/python/site-packages
/usr/bin/python3 -s << 'PYEOF'
import os, requests
cookies = {k.replace('TISTORY_',''): os.environ[k] for k in os.environ if k.startswith('TISTORY_')}
hdr = {'User-Agent':'Mozilla/5.0','Referer':'https://sigco.tistory.com/manage/','X-Requested-With':'XMLHttpRequest'}
for name, url in [('posts.json','https://sigco.tistory.com/manage/posts.json?category=-3&page=1'),
                  ('category.json','https://sigco.tistory.com/manage/category.json')]:
    r = requests.get(url, cookies=cookies, headers=hdr, timeout=10, allow_redirects=False)
    print(f'{name}: HTTP {r.status_code} | ct={r.headers.get("content-type","")[:30]} | loc={r.headers.get("location","")[:80]}')
PYEOF
```

- **HTTP 302 + Location `/auth/login`** → §3.8.1 Zombie 302 (쿠키는 env에 존재하지만 만료)
- **HTTP 200 + HTML** → §3.8 (쿠키 일부/전부 누락)
- 어쨌든 둘 다 사용자 개입 필요 (브라우저 로그인 후 쿠키 값 복사 → 메시지 전달)

**4단계: 가짜 발행 누적 확인** (만료 시점에 직전까지 cron이 정상이었다면 0건이지만 안전 확인):
```bash
python3 ~/.hermes/scripts/blog_pipeline.py --status 2>&1 | grep -v NotOpenSSL | head -20
python3 -c "
import json
from pathlib import Path
pt = json.loads(Path('/Users/mac/.hermes/memory/published_topics.json').read_text())
state = json.loads(Path('/Users/mac/.hermes/memory/blog_pipeline_state.json').read_text())
last_url_num = int(pt['last']['url'].split('/')[-1])
print(f'last.url 글번호: #{last_url_num}')
print(f'last_published_url: {state.get(\"last_published_url\", \"N/A\")}')
"
```

**5단계: 주인님 알림** — 텔레그램 DM 발송:
- **제목**: ⚠️ Tistory 세션 만료 — 브라우저에서 쿠키 갱신 필요
- **본문**: 만료 타입(§3.8 vs §3.8.1), 마지막 정상 발행, 가짜 발행 누적 추정, env 갱신 절차
- **갱신 절차**: 브라우저 DevTools → Application → Cookies → https://sigco.tistory.com → 5종 키 (`REACTION_GUEST`, `__T_`, `__T_SECURE`, `TSSESSION`, `_T_ANO`) 값 복사 → 메시지로 에이전트에 전달

### ⚠️ 절대 하지 말 것
- env 자동 갱신 시도 ❌ (사용자 브라우저 로그인 필요)
- stats 자동 롤백 실행 ❌ (가짜 발행 0건이어야 정상)
- 패치/스킬 수정 ❌ (이 cron은 검증 + 알림만)

### 🆘 함정 18 (320차 신규) — cron 모드에서 `hermes send` 호출 skip

cron 잡으로 실행 중일 때, `hermes send --to telegram:<chat_id>` 호출은 **그 cron의 자동 전달 대상과 동일한 chat_id**면 즉시 skip된다. 정확한 Hermes 응답:

```
Skipped send_message to telegram:8359527845. This cron job will already
auto-deliver its final response to that same target. Put the intended
user-facing content in your final response instead, or use a different
target if you want an additional message.
```

**원칙**: cron 모드에서 사용자 알림 = **final response 본문에 직접 작성**. 시스템이 final response를 cron의 configured destination으로 자동 전달함. `hermes send`는 (a) 다른 채널(예: 디스코드)에 동시 발송하거나 (b) 자동 전달 외 추가 메시지가 필요할 때만 사용.

**판정**: 메시지 파일을 `/tmp/...txt`로 만들고 `hermes send --file`로 발송하는 패턴은 정상이나, 대상이 cron의 자동 전달 chat_id와 동일하면 skip됨 — 이 경우 **final response에 본문 통합**이 정답.

### 📈 만료 추이 분석 (320차 갱신, 322차 신규 5단계)

주기적으로 만료 간격 측정 → 다음 만료 예측:
- 184차(6/29) → 196차(7/2) = **3일 만에 skip**
- 196차 → 7/6 = **8일 만료**
- 이후 319차(7/24)까지 약 **18일간 정상 운영**
- 319차(7/24) → 320차(7/26) zombie 302 = **약 36시간 만에 만료** — 평소보다 짧은 주기
- 320차(7/26 04:xx zombie 302) → 322차(7/26 17:13 manual 복구) = **2.5시간 응답 시간** (§3-B owner 페이지 외 반응시간)

**관찰**: 18일 → 36시간로 만료 주기가 급격히 짧아짐. 트래픽 변화 또는 Tistory 측 쿠키 회전 정책 변경 가능성. 정상 운영 시간 36시간 단축은 §3.8.1 owner-side 페이지 막힘 갱신 +0300 KST 자동 만료 회전 가설 후보. 다음 만료 시점 예측 어려움. **매일 아침 점검 cron이 더 자주 필요해질 수 있음** — W30 일요일 1건만 막혀도 7/28~29 안에 재발.

### 🆘 함정 19 (322차 신규) — `verify-tistory-cookie.sh` step [3] env 값-모양 hardcode로 인한 false-positive

`scripts/verify-tistory-cookie.sh` step [3]가 `EXPECTED_LINES=("REACTION_GUEST=1" "__T_=1" "__T_SECURE=1" ...)` 형태로 fallback `=1`을 정상 패턴으로 가정하고 있어서, **주인님이 진짜 hash로 쿠키를 갱신하면 step [3]만 3건 FAIL**로 단정되어도 step [5] check-session PASS + step [7] categories PASS면 진짜 회복이다.

**증상 (322차 실전)**:
```
[3] 환경변수 로드 + 값 검증
  ❌ FAIL: 로드 실패: REACTION_GUEST=1 (실제: REACTION_GUEST=684fb927c0b3ab...)
  ❌ FAIL: 로드 실패: __T_=1 (실제: __T_=1)  ← 정상 동작에서도 발생
  ❌ FAIL: 로드 실패: __T_SECURE=1 (실제: __T_SECURE=1)  ← 정상 동작에서도 발생

[5] tistory_publisher.py --check-session
  ✅ PASS: 세션 유효 (총 962개 글)

[7] --categories 호출
  ✅ PASS: 카테고리 6개 로드 성공

RESULT: PASS=13  FAIL=2  WARN=1
❌ ad-hoc verification: FAILED   ← 진짜 회복인데 cron이 fail로 오탐
```

**판정 매트릭스 (322차 정형)**:

| step [5] check-session | step [7] categories | step [3] env FAIL | 최종 verdict |
|-------------------------|---------------------|-------------------|--------------|
| ✅ PASS | ✅ PASS | 0건 | **CLEAN** |
| ✅ PASS | ✅ PASS | 1~3건 (모두 env 모양 drift) | **RECOVERED** (false-positive) |
| ✅ PASS | ✅ PASS | 4건 이상 OR 다른 키 누락 | 조사 필요 (사용자 게이트) |
| ✅ PASS | ❌ FAIL | — | 부분 회복 (categories 추가 디버그) |
| ❌ FAIL | — | — | 진짜 만료 / 망 |
| step [6] JSON parse FAIL | — | — | 환경 회귀 (사용자 사이트 누설) |

**핵심**: step [5] + step [7]이 단독 진짜 판정. step [3]의 값-모양 FAIL은 정보용으로 재라벨.

**해결 패치 (322차 정형)**:
1. `report()`에 `INFO` 분기 추가 + `INFO=0` 초기화 (`step [3] INFO 출력용`)
2. step [3]을 `LENGTH_LINES=(TSSESSION_LEN=40, _T_ANO_LEN=344)`만 PASS/FAIL 하고 `REACTION_GUEST/__T_/__T_SECURE` 3건은 `INFO`로 출력 — 값 모양 변동은 정상이므로 soft하게 표시
3. verdict 로직을 다음과 같이 수정:
   - `FAIL == 0` → `✅ ad-hoc verification: CLEAN`
   - `FAIL ≤ 1` AND step [5] PASS + step [7] PASS → `✅ ad-hoc verification: RECOVERED`
   - 그 외 → `❌ ad-hoc verification: FAILED`

패치 후 RUN: `bash ~/.hermes/skills/automation/tistory-publisher/scripts/verify-tistory-cookie.sh` → RESULT `PASS=13 FAIL=0 WARN=0 INFO=3` + exit_code 0 + ✅ CLEAN 정상 회복 라벨 확인 (322차 검증).

## ⚠️ 필수: 환경 격자 (Python venv PYTHONPATH 누설 차단)

Hermes venv의 urllib3가 Python 3.9 호환성 문제로 `/usr/bin/python3` import 시 깨짐. **모든 cron 스크립트는 격자 실행**:

```bash
unset PYTHONPATH
env -i HOME="$HOME" PATH=/usr/bin:/bin PYTHONPATH= /usr/bin/python3 <script>
```

자세한 함정 진단: `references/section-3-8-1-session-guard.md`.

## 보고 형식

- **발행 N건 정상**: `#NNN #NNN #NNN` 한 줄
- **발행 0건 (가드 skip)**: `⏸️ 가짜 발행 가능성 있는 발행 skip (§3.8.1 가드 적용)`
- **발행 0건 (정상 skip, 중복 등)**: 짧은 사유 한 줄 + `daily_counts` 변화 없음 명시

## References

- `references/session-20260726-323rd-stinkpot-topic-hash-and-file-semantics.md` — `--file`의 실제 Markdown 의미, publish 후 canonical topic hash 보정, state/published_topics 동기화 및 proxy 검증 순서
- `references/section-3-8-1-session-guard.md` — 세션 만료 가드 + venv PYTHONPATH 누설 함정 (288차 검증)
- `references/cron-watchdog-service-health.md` — cron 잡 수리·all-green과 실제 Tistory 세션 상태를 분리 판정하는 교차 검증 절차
- `references/section-3-5-state-consistency.md` — 3중 신호 검증 패턴 (288차 검증)
- `references/session-20260718-289th-fake-publish-detection.md` — 289차 가짜 발행 5건 누적 사건 + 신호 4 도입 배경 (289차 검증)
- `references/session-20260718-291st-guard-false-positive-and-fake-publish-residual.md` — 291차 가드 env -i 오탐 → raw 검증 워크어라운드 + 가짜 발행 잔재 skip 운영 (291차 검증)
- `references/session-20260719-292nd-record-topic-placeholder-and-commit-url-gap.md` — 292차 `--record-topic` URL placeholder 잔재 + `commit_publish()` last_published_url 미갱신 함정 + 3-패치 보정 시퀀스 (292차 검증)
- `references/session-20260719-293rd-status-ready-only-and-details-drift.md` — 293차 `run_pipeline()` status=ready 한계 발견 + details append 누락 drift + `last_published_id` vs URL mismatch + stale+sensational topic skip 판정 (293차 검증)
- `references/session-20260719-294th-score-resort-and-sensational-filter.md` — 294차 `get_fallback_topic()` score 재정렬 패치 (Notion 순서 ≠ score 순서) + sensational/stale 자동 필터 + GPT-5.6 #1046 수동 발행 + `re` import 누락 함정 + `--force-topic` CLI flag + score 정렬 깨짐 4-옵션 워크플로우 (294차 검증)
- `references/session-20260720-297th-cli-options-and-by-category-id-pollution.md` — 297차 `tistory_publisher.py` CLI 옵션 함정(--category int만, --category-id/--description/--html-file 미존재) + 옵션 실측 표 + by_category 정수 ID 키 오염 패턴 + SSOT 변경 사용자 게이트 (297차 검증)
- `references/session-20260720-298th-signal4-append-coincidence-and-5-3-unification.md` — 298차 §3.5 신호 4 오탐 케이스 (details append + last 동시 갱신 시 무조건 발동) + proxy check disambiguate 절차 + 5-3 표준 보정에 details append 통합 (293차 함정 4 해소) (298차 검증)
- `references/session-20260720-299th-bikeshed-llm-age-verification.md` — 299차 #1050 (Bikeshed, gn=31573, AI/ML) 발행 + §3.5 신호 4 오탐 disambiguate 패턴 재확인 + 297차 함정 8 누적 가속(by_category["1219746"] 영구 누적) + 정형 보정 절차 (299차 검증)
- `references/session-20260720-300th-mamdani-nyc-rental-ai-disclosure.md` — 300차 #1051 (Mamdani NYC 임대 광고 AI 공개, gn=31576, AI/ML) 발행 + **published_topics.json 누락 백필 패턴** (297~299차 #1048~#1050 누락분 보강) + 신호 4 오탐 disambiguate **3연속 확정** (298→299→300) + 가짜발행 vs 오탐 구분 매트릭스 (300차 검증)
- `references/session-20260720-301st-ai-wrapper-end-vertical-strategy.md` — 301차 #1052 ("AI 래퍼는 끝났다: 초기 스타트업을 위한 수직화 전략", gn=31598, AI/ML) 발행 + 신호 4 오탐 disambiguate **4연속 확정** (298→299→300→301) + 5-2-A 72건 단발 백필 안정성 + by_category 영구 누적 가설 확인 + 신규 함정 9 (`env -i ... python3 python3` 중복 호출)
- `references/session-20260720-302nd-task-economy-data-trillion-dollar-market.md` — 302차 #1053 ("태스크 이코노미 - 데이터가 만드는 다음 1조 달러 시장", gn=31608, AI/ML, score=4.0) 발행 + 신호 4 오탐 disambiguate **5연속 확정** (298→299→300→301→302) + 297차 함정 8 by_category 영구화 5연속 재확인 + 본문 빌드 시 write_file(/tmp/post_*.html) 분리 패턴 (execute_code cron 차단 회피)
- **references/session-20260720-303rd-ai-advice-overconfidence-stableqa.md** — 303차 #1054 ("AI 조언을 받으면 정확도는 3분의 1로 떨어지고 자신감은 2배 이상 높아짐", gn=31614, AI/ML) 발행 + §3.5 신호 4 오탐 disambiguate **6연속 확정** (298→299→300→301→302→303) + **함정 10 신규 (가드 격리 한계 3중 함정)** — Xcode python3 충돌 + user-site 격리 실패 + env -i 환경변수 손실 + 안정적 raw 검증 우회 패턴 (`set -a; source tistory.env; unset PYTHONPATH PYTHONHOME; PYTHONNOUSERSITE=1; export PYTHONPATH=user-site; /usr/bin/python3 -s`) + `response['items'][0]['id']` 직접 추출 패턴
- **references/session-20260720-304th-ai-decision-meltdown-adoption-guide.md** — 304차 #1055 ("AI 광풍이 전 세계의 의사결정을 무너뜨리고 있음", gn=31602, AI/ML) 발행 + §3.5 신호 4 오탐 disambiguate **7연속 확정** (298→299→300→301→302→303+**304**) + **`execute_code` cron 차단 회피 패턴 재확인** (302차 확립) — write_file + `/tmp/build_post_XXX.py` → `/usr/bin/python3 -s` 실행 → `/tmp/post_XXX.html` → `tistory_publisher.py --file`. heredoc + `env -i` SyntaxError (296차 함정 6) 회피. + **297차 함정 8 by_category["1219746"] 영구화 6연속 재확인** (297→304 = 8차 동일 유지, 코드 `=` 할당 동작, 첫 매핑 후 영구 잔존. 사용자 게이트 시 ID_TO_NAME 1회 보정 권장, cron은 drift 보고만) + **CDN 자체서명 SSL 경고는 발행에 영향 없음** (`https://cdn.sigco.dev/...` CERTIFICATE_VERIFY_FAILED 경고는 출력되나 Tistory가 CDN 업로드 실패 이미지는 무시하고 텍스트/마크다운만 정상 발행, cron 로그 노이즈 감수) + 303차 안정적 raw 검증 우회 패턴 (`set -a; source; unset; PYTHONNOUSERSITE=1; export PYTHONPATH=user-site; /usr/bin/python3 -s`) **304차 정상 작동 재확인**. 연속 all-green 84회차.
- **references/session-20260720-305th-spare-mac-claude-code-isolated-workstation.md** — 305차 #1056 ("여분의 Mac을 Claude Code 전용 제어 환경으로 만드는 단계별 가이드", gn=31591, AI/ML) 발행 + §3.5 신호 4 오탐 disambiguate **8연속 확정** (298→305) + **본문 빌드 단일 패스 강화 패턴 신규** — `build_post_XXX.py` 안에 `requests.get(gn_url) + <meta property="og:description"> regex` 임베드 → 긱뉴스 description 추출 + Picsum 이미지 + 본문 5644자 빌드를 한 패스로 통합. 함정 3 (selector 코멘트만) + 함정 6 (heredoc + env -i) + 함정 11 (`execute_code` cron 차단) 3중 동시 회피. 305차 daily_counts={AI/ML:9}. 연속 all-green 85회차.
- **references/session-20260721-306th-codex-272k-context-window-reduction.md** — 306차 #1060 ("OpenAI, Codex 모델 컨텍스트 크기를 372k에서 272k로 축소 — 무엇이 달라졌고 개발자는 어떻게 대응해야 할까", gn=31611, AI/ML) 발행 + §3.5 신호 4 오탐 disambiguate **9연속 확정** (298→306) + **함정 13 신규 (`run_pipeline()` topic 선정 비결정성)** — 같은 세션에서 `--category 'AI/ML'` 두 번 호출 시 1회차=gn=31611, 2회차=gn=31599로 다른 후보 반환 (Notion DB 활성 후보 셔플 / `get_fallback_topic()` timestamp 의존). 영향: publish URL grep 정상이라 외부 영향 없음, 단 동일 #NNN 중복 가드 여전히 필수. 운영 권장: `run_pipeline()` 한 번만 호출해 topic 확정 후 즉시 publish 단계 진입. **305차 단일 패스 패턴 306차 재확인** — `build_post_306.py` 안에 `og:description` regex 임베드 → 160자 추출 + Picsum 이미지 2장 → 본문 4088자 빌드. **303차 안정 raw 검증 패턴 306차 재확인** — `set -a; source; unset PYTHONPATH PYTHONHOME; PYTHONNOUSERSITE=1; export PYTHONPATH=user-site; /usr/bin/python3 -s` 형태로 §3.8.1 가드 정상 통과. **함정 8 by_category["1219746"]=1 영구 잔존 9연속 재확인** (297→306 = 10차 동일 유지). 306차 daily_counts={AI/ML:4}. 연속 all-green 86회차.
- **references/session-20260721-307th-supabase-2026-startup-survey.md** — 307차 #1062 ("Supabase가 조사한 2026년 스타트업 현황 — 풀스택 BaaS가 이끄는 새로운 개발 패러다임", gn=31604, AI/ML) 발행 + §3.5 신호 4 오탐 disambiguate **10연속 확정** (298→307) + **신규 발견 — `import os` 누락 시 NameError 패턴** — heredoc 내부 `os.environ` 참조 시 `import os`를 빠뜨리면 즉시 NameError로 검증 단계 실패 (303차 안정 raw 검증 패턴 + 5-5 proxy check에서 흔히 발생하는 copy-paste 함정). **해결**: heredoc 첫 줄에 `import os, requests, re` 세 모듈 항상 포함. **305차 단일 패스 패턴 307차 재확인** — `build_post_307.py` 안에 `requests.get(gn_url) + og:description regex` 임베드 → 160자 description 추출 + Picsum 이미지 2장 + 본문 6952자 빌드. **303차 안정 raw 검증 패턴 307차 재확인** — 가드 8개 쿠키 + manage/posts.json first_ids=['1061','1060','1059','1058','1057'] 정상. **함정 8 by_category["1219746"]=1 영구 잔존 10연속 재확인** (297→307 = 11차 동일 유지). 307차 daily_counts={AI/ML:6}. 연속 all-green 87회차. **함정 14 신규** — `import os` 누락 → NameError. 운영 원칙: cron heredoc 첫 줄은 항상 `import os, requests, re` 세 모듈 포함.
- **references/session-20260726-320th-cookie-expiry-morning-check.md** — 320차 아침 세션 만료 점검 cron (별도 워크플로우) — `verify-tistory-cookie.sh` 결과 PASS=13 / FAIL=2 / WARN=1, 3-endpoint probe에서 posts.json + category.json 둘 다 HTTP 302 + Location `/auth/login` (§3.8.1 Zombie 302 패턴, 쿠키 8개 env에 존재하지만 만료). 연속 all-green 99회차 → 잠정 중단, stats 오염 0건. **함정 18 신규 — cron 모드에서 `hermes send` 호출 skip** — `hermes send --to telegram:<cron_auto_delivery_chat_id>` 호출 시 "This cron job will already auto-deliver its final response to that same target. Put the intended user-facing content in your final response instead" 메시지와 함께 skip. **원칙**: cron 모드 사용자 알림 = final response 본문에 직접 작성, `hermes send`는 다른 채널 추가 발송시에만. 만료 추이 갱신: 18일 → 1.5일로 주기 급격히 짧아짐, 매일 아침 점검 cron 필요성 증가.
- **references/session-20260726-322nd-cookie-recovery-false-positive-fix.md** — 322차 수동 세션 갱신 — REACTION_GUEST 진짜 hash(`684fb927c0b3ab...`) + TSSESSION/`_T_ANO` 새로 복사, `__T_/__T_SECURE=1` fallback 유지 (3-endpoint probe posts.json HTTP 200 / `first_ids=['1099','1098','1097']` / category.json 200 / tistory_publisher.py `--check-session` "총 962개 글" 정상 회복). **함정 19 신규 — `verify-tistory-cookie.sh` step [3] env 값-모양 hardcode** — 스크립트가 `EXPECTED_LINES=("REACTION_GUEST=1" "__T_=1" "__T_SECURE=1" ...)` 형태로 fallback `=1`을 정상 패턴으로 가정했는데, 진짜 hash로 갱신하면 REACTION_GUEST 라인 3건이 모두 FAIL로 단정되어도 step [5] check-session PASS + step [7] categories PASS면 진짜 회복이다. **판정 매트릭스 (322차 정형)**: (1) step [5] ✅ + step [7] ✅ + step [6] ✅ = 단독 진짜 판정 (FAIL 개수 무관, step [3]의 3건 INFO 재라벨) (2) step [5] FAIL = 진짜 만료/망 (3) step [6] FAIL = 환경 회귀 (사용자 사이트 패키지 누설). **해결 패치**: (a) `report()`에 INFO 분기 추가 + `INFO=0` 초기화 (b) step [3]을 `LENGTH_LINES`만 PASS/FAIL + `REACTION_GUEST/__T_/__T_SECURE` 3건은 INFO 출력 (c) verdict 로직을 "FAIL=0 또는 step [5] PASS + step [7] PASS + FAIL≤1 = CLEAN/RECOVERED"로 변경. 패치 후 `PASS=13 FAIL=0 WARN=0 INFO=3` + exit_code 0 정상 라벨. 만료 추이 5단계 갱신: 184차(6/29)→196차(7/2,3일)→7/6(8일)→319차(7/24,18일)→320차 zombie 302(7/26,36시간)→**322차 수동 회복(7/26,2.5시간 응답)**. 정상 운영 시간 36시간 단축은 §3.8.1 owner-side 페이지 막힘 갱신 +0300 KST 자동 만료 회전 가설 후보.
- `references/session-20260723-316th-bento-singlefile-office.md` — 316차 #1089 ("Bento - 파일 하나에 모두 들어가는 오피스 스위트 — 단일 HTML 파일 오피스의 현 주소", gn=31704, AI/ML) 발행 + §3.5 신호 4 오탐 disambiguate **21연속 확정** (298→316) + **305차 단일 패스 패턴 316차 재확인 (12연속 정형화)** + 진입 시점 신호 4 + 5-5 disambiguate 트리거 **7연속 확정** (310/311/312/313/314/315/316) + **311차 fallback 패턴 후 정상 publish 복귀 6차 연속 안정 유지** (AI/ML ↔ 개발도구 폴백 주기적 반복) + 함정 회피 5중 동시 성공 (6/7/11/14/15) + 316차 daily_counts={AI/ML:8, 개발도구:1} (총 9건). 연속 all-green 96회차.

- **references/session-20260724-318th-chrome-extension-personal-tools.md** — 318차 #1097 ("Ask GN: 구글 크롬 확장 프로그램 개인적으로 만들어서 쓰고 계신것 있으신가요? — 실전 개발자 추천 모음", gn=31727, 개발도구, score 5.0, AI/ML 후보 소진으로 §3-B fallback) 발행 + §3.5 신호 4 오탐 disambiguate **23연속 확정** (298→318) + 진입 시점 신호 4 + 5-5 disambiguate 트리거 **9연속 확정** (310~318) + **311차 fallback 패턴 후 정상 publish 8차 연속 안정 유지** (311차 fallback → 312~314 AI/ML → 315 fallback → 316~317 AI/ML → **318차 fallback 재발**, fallback은 안정 운영 상태의 일부로 완전 정착) + **317차 함정 17 (parts.append()) 적용 경계 정형화** — 본문 2776자 단일 f-string lint 정상 + sibling write 경고 0건 → **임계 정형화: 본문 3000자 미만 = 단일 f-string OK, 3000자 이상 + docstring/codeblock/푸터 동시 = parts.append() 권장**. 317차 NvChat (6952자) = 함정 17 임계 직상단, 318차 Chrome Extension (2776자) = 함정 17 무관 사례. 진입 시점 5-5가 직전 차 발행 5건 disambiguate (daily_counts={AI/ML:4, 개발도구:0} 상태에서 5-5 #1093~#1096 모두 status=200+og:title 매칭 후 발행 단계 진입). 함정 회피 6중 동시 (6/7/8/11/14/15) + daily_counts={AI/ML:4, 개발도구:1} (총 5건), total=949. 연속 all-green 98회차.
- **references/session-20260724-317th-making-things-philosophy.md** — 317차 #1093 ("만든다는 것 — 직접 만들어야 하는 이유와 AI 시대의 가치", gn=31728, AI/ML) 발행 + §3.5 신호 4 오탐 disambiguate **22연속 확정** (298→317) + **305차 단일 패스 패턴 317차 재확인 (13연속 정형화)** + **317차 신규 관찰 — 1차 발행이라 daily_counts[오늘]=1 < 2 → 신호 4 미발동 자연 상태** + **함정 17 신규 — `build_post_XXX.py` 단일 큰 f-string 회피 (parts.append() 패턴)** — 본문 + docstring + 코드 블록 + 푸터를 한 개의 큰 f-string에 우겨넣으면 lint 단계에서 `SyntaxError: invalid syntax` + sibling subagent write 경고 동시 노출. 해결: `parts.append()` 리스트로 분리 후 `"\n".join(parts)` 합치기. 빌드 80줄+ 또는 docstring/코드/푸터가 f-string 안에서 함께 들어가는 경우엔 처음부터 parts.append() 패턴 권장. 317차 daily_counts={AI/ML:1}, total=87. 연속 all-green 97회차.
- **references/session-20260724-317th-nvchat-windows-llm-client.md** — 317차 cron 3번째 발행 (#1096, gn=31711, AI/ML, score 16.0) — "Show GN: NvChat — NVIDIA 무료 LLM을 단일 exe로 쓰는 윈도우 데스크톱 클라이언트". §3.5 신호 4 오탐 disambiguate 22연속 + 진입 시점 5-5 트리거 8연속 + 단일 패스 패턴 13연속 + 311차 fallback 이후 정상 publish 7차 연속 안정 유지. **5-3 패치 명시적 KST 타임존 사용** (`datetime.datetime.now(kst)` where kst=timezone(timedelta(hours=9))) — UTC/naive datetime 대신 한국 표준시로 details entry timestamp 박음. 본문 빌드는 sibling subagent 함정 17 패턴 회피하여 단순 f-string + 변수 보간으로 성공 (parts.append() 불필요). 함정 회피 6중 동시 (3/6/7/11/14/15) + 함정 16 (publish/commit 카테고리 타입 분리). daily_counts={AI/ML:4}, total=90.
- **references/session-20260724-319th-omniroute-ai-gateway.md** — 319차 #1098 ("OmniRoute — 흩어진 무료/저가 AI 티어를 하나로 묶는 게이트웨이", gn=31710, 개발도구, score 4.0) 발행 + §3.5 신호 4 오탐 disambiguate **24연속 확정** (298→319) + 진입 시점 신호 4 + 5-5 disambiguate 트리거 **10연속 확정** (310~319) + **단일 패스 패턴 15연속 정형화** — `build_post_319.py` 안에 `requests.get(gn_url) + <meta property="og:description"> regex` 임베드 → 159자 description 추출 ("하나의 로컬 엔드포인트(localhost:20128/v1)로 271개 프로바이더/500개 이상 모델을 연결하고 Claude Code/Codex/Cursor/Cline/Copilot 등 26개 코딩 툴을 설정 하나로 사용 90개 이상 무료 티어/40개 이상 영구 무료 계정을 통합해 월…") + Picsum 이미지 2장 (seed: omniroute-gateway / ai-tier-aggregation) + 코드 블록 2개 + 본문 2687자 빌드 → **#1098 발행 성공** (proxy status=200 + title="OmniRoute &mdash; 흩어진 무료/저가 AI 티어를 하나로 묶는 게이트웨이" + og:title="OmniRoute — 흩어진 무료/저가 AI 티어를 하나로 묶는 게이트웨이" 정확 매칭, OG 썸네일 `https://blog.kakaocdn.net/dna/bWo2gR/dJMcagGpYPY/AAAAAAAAAAA...` 정상 설정). §3.11 5-2 commit_publish (stats.today={AI/ML:4, 개발도구:2}, total=949, by_category["1219746"]=1 동일 유지 — 함정 8 영구 잔존 24연속) → 5-3 last+details 통합 보정 (#1098, details_len=171) → 5-2-A 백필 0건 (누적 동기화 완료) → 5-4 §3.5 신호 4 발동 (오탐 24연속) → 5-5 proxy check #1098 status=200 + og:title 정확 매칭 disambiguate 통과. **311차 fallback 패턴 후 정상 publish 9차 연속 안정 유지**: 311차(개발도구), 312~314(AI/ML), 315(개발도구), 316~317(AI/ML), 318(개발도구), **319(개발도구)** 모두 정상. **fallback은 진짜 일회성이 아니라 안정 운영 상태의 일부로 완전 정착** — AI/ML 후보 소진이 주기적으로 반복되는 패턴. **함정 회피 6중 동시 확인**: 함정 6 (heredoc + env -i SyntaxError) + 함정 7 (--category int만) + 함정 8 (by_category["1219746"]=1 영구 잔존 24연속) + 함정 11 (execute_code cron 차단 회피) + 함정 15 (5-5 proxy check 격리 패턴 적용) + 함정 17 (2687자 = 단일 f-string OK, parts.append 불필요 — 본문 3000자 미만 임계 재확인) 모두 319차 워크플로에서 자동 회피 성공. 319차 daily_counts={AI/ML:4, 개발도구:2} (총 6건). 연속 all-green 99회차.

### 323차 운영 보강 — `--file` 파싱 우회와 §3.5 결과 해석

- **`--file` 경로가 정상이고 Markdown도 유효한데 `--title과 --content 또는 --file이 필요합니다`가 반복되면 같은 호출을 재시도하지 않는다.** 임시 Markdown 파일을 읽어 `--content`로 직접 넘기고 `--title`을 명시하는 fallback을 사용한다. 예:
  ```bash
  CONTENT=$(/usr/bin/python3 -c 'from pathlib import Path; print(Path("/tmp/post_N.md").read_text(encoding="utf-8"), end="")')
  /usr/bin/python3 -s ~/.hermes/scripts/tistory_publisher.py \
    --title "실제 제목" --content "$CONTENT" --tags "..." \
    --visibility public --category 1219746 --source-url "..." --gn-topic-id N
  ```
  이후 stdout의 `🔗 https://sigco.tistory.com/NNN`만 성공 URL로 채택한다. `--file` 실패를 발행 성공으로 간주하거나 `--record-topic` placeholder를 넣지 않는다.
- 발행 성공 뒤 `commit`과 state/published_topics 동기화를 수행한 직후 `check_state_consistency.py`가 **FAKE_PUBLISH**를 반환할 수 있다. 이는 `details[-1]`와 `last_published_url`을 같은 새 슬롯으로 함께 보정하는 구조적 오탐일 수 있으므로, exit 1만으로 롤백하지 않는다. 먼저 해당 URL에 대해 **HTTP 200 + `og:title` 일치**를 확인한다. proxy가 PASS면 실제 발행으로 확정하고, 보고에는 `§3.5 구조적 오탐`을 명시한다. proxy 404 또는 제목 불일치일 때만 가짜 발행으로 판정하고 추가 stats 보정을 중단한다.
- 이번 세션의 최초 재현 기록은 `references/session-20260726-323rd-stinkpot-topic-hash-and-file-semantics.md`에 둔다.
- **324차 재검증**: 정상 Markdown + 명시적 `--title`에서도 같은 `--file` 오류가 재발했으며, 즉시 `--content` 단일 폴백으로 #1105 발행, stats 5→6, state/published_topics 동기화, proxy HTTP 200 + `og:title` 일치까지 확인했다. 상세 기록: `references/session-20260726-324th-file-content-fallback-validation.md`.


- `scripts/check_state_consistency.py` — 재사용 가능한 §3.5 검증

## 환경/제약

- `~/.hermes/secrets/tistory.env` — TISTORY_* 쿠키 환경변수 (set -a source 필수)
- `~/.hermes/memory/blog_pipeline_state.json` — SSOT for daily_counts/last_published_url/last_topics
- `~/.hermes/scripts/tistory_publisher.py` — `publish_post()` / `--record-topic` 진입점
- `~/.hermes/scripts/blog_pipeline.py` — `run_pipeline()` / 카테고리별 발행 오케스트레이션

## 검증 이력

- **288차 (2026-07-18)** — §3.8.1 302 만료 가드 동작 확인, §3.5 3중 신호 통과 (state drift 0), venv 격자 패턴 발견. 발행 0건 (세션 만료로 skip). 연속 all-green 75회차.
- **287차 (2026-07-18 04:04)** — 직전 발행 #1043 (SpaceX IPO, AI/ML). 이 상태가 288차 §3.5 검증의 baseline.
- **289차 (2026-07-18 06:01)** — 세션 가드 VALID 통과 + 트렌드 12개 새로고침. **daily_counts[2026-07-18] = AI/ML 4 + 개발팁 1 = 5건 누적, 그러나 details[-1]=#1043 (287차) 그대로, 신규 Tistory 글 없음 → 5건 가짜 발행 확정**. last_topics[-1]은 Bun(개발팁) stale. **판단: 발행 skip** (stats 추가 박기 = 오염 가중). **조치 완료 (SKILL.md 갱신)** — `check_state_consistency.py`에 (1) PEP 604 → `Optional[…]`로 3.9 호환화 (2) 신호 4 FAKE_PUBLISH (daily_counts[오늘] ≥ 2 + details[-1] 슬롯 변동 없음 → exit 1) 추가. 다음 차 워크플로우 권장: 실제 Tistory `#1044~` 카운트로 daily_counts[2026-07-18] 차감 보정.
- **290차 (2026-07-18)** — `session_expiry_guard.sh` 자체 버그 발견: `env -i` 격리 모드에서 `tistory.env`를 source 안 해서 cookies 미주입 → `NO_COOKIES` (exit 10) → `❌ FAIL: 가드 실행 실패 (exit=10)`. 우회 검증으로 raw `env -i ... TISTORY_*=$TISTORY_*` 호출 시 **status=200 VALID** (실제 세션은 정상). **버그 수정 필수**: `set -a; source ~/.hermes/secrets/tistory.env; set +a` 후 격리 모드 진입, 또는 `env -i` 제거하고 그냥 `unset PYTHONPATH`만. §3.5 신호 4 FAKE_PUBLISH 활성 (daily_counts=5, details[-1]=#1043, Tistory #1044~#1046 전부 404) → 단순 skip 유지 (stats 추가 = 오염 가중).
- **291차 (2026-07-18 21:01)** — §3.8.1 가드 env -i 격리 모드 EXPIRED 오탐 → raw 검증 (`source tistory.env` 후 격리 없이 직접 python3) 워크어라운드로 **진짜 status=200 VALID** 확인. 트렌드 12개 새로고침, AI/ML ready (AIM 서버 호스팅, timeliness.fresh). 그러나 §3.5 신호 4 FAKE_PUBLISH 발동 (daily_counts[2026-07-18]=5, details[-1]=#1043 변동 없음) → **publish skip** (컨텐츠 생성/게시 없이 단순 종료). cron이 가짜 발행 잔재 상태에서 stats 추가 박기 금지 패턴 재확인. **결정 매트릭스** 신규: §3.8.1 raw VALID + §3.5 신호 4 → skip 우선.
- **292차 (2026-07-19 05:03)** — §3.8.1 raw VALID + §3.5 신호 4 미발동 (daily_counts[2026-07-19]=0 깨끗) → AI/ML 발행 진행. Topic "Claude Fable 5, 7월 20일부터 Max/Team Premium 요금제에 기본 포함" 선정. 본문 3355자 + 이미지 2장 CDN 업로드 → **#1044 발행 성공** (og:title 매칭 확인). **§3.11/§4 보정 실전 검증**: (1) `--record-topic` URL 자리에 "TBD" placeholder 사용 → published_topics.json details[].url에 "TBD" 박힘 (함정 1) (2) `commit_publish()`는 state.json의 last_published_url 미갱신 (함정 2) → 수동 보정 2건 (5-2-A details URL + 5-3 last_published_url). 3중 신호 최종 ✅ 일치. 긱뉴스 본문 selector 모두 코멘트만 잡힘 → OG description 사용이 안정적 (함정 3). SKILL.md §3.11/§4 5단계 구체화 (placeholder 회피 + 5-2-A/B/C + 5-5 proxy check 패턴).
- **293차 (2026-07-19 19:01)** — §3.8.1 raw VALID (status=200, manage/posts 응답 id=1045~1044~1043 진짜 존재) + §3.5 3중 신호 일치 (last_published_url=#1045, last_topics[-1]=#1045, daily_counts[2026-07-19]={AI/ML:2}). **publish skip** (run_pipeline 결과 topic "AI 기업 로고는 왜 항문처럼 보일까? (2025)"로 stale+sensational 품질 정책 위반). **신규 발견 3건**: (a) `run_pipeline()`은 publish 안 하고 status=ready까지만 → cron이 별도 `tistory_publisher.py` 호출하는지 검증 필요 (SKILL.md §3단계에 명시 추가), (b) `blog_pipeline_state.json`의 `details` 배열 마지막 entry가 #1043 (7/18 stale) 그대로인데 실제 Tistory #1044/#1045는 발행됨 → **details append 누락 drift 패턴** (어제 #1044, #1045 발행 시 details 동기화 안 됨), (c) `last_published_id="1043"` stale / `last_published_url="https://sigco.tistory.com/1045"` 정합 → **두 필드 동시 갱신 권장** (commit_publish()가 둘 다 갱신하는지 검증 필요, 미갱신이면 5-3 함정 패치 확장). details/last_published_id 누락 보정은 SSOT 변경이라 사용자 확인 필요 (이번 차에는 보류).
- **294차 (2026-07-19 21:01)** — §3.8.1 raw VALID + §3.5 3중 신호 일치(깨끗). `run_pipeline()` 선정 topic이 sensational 표현("AI 기업 로고는 왜 항문처럼 보일까? (2025)") + timeliness.warning(2025 표기 stale) — 당시 §3-A 매트릭스 skip 적용. **신규 발견 (score 정렬 우선 알고리즘 깨짐 패턴)**: 9.0점 1순위 후보(GPT-5.6)가 트렌드에 있는데 sensational+stale 2순위가 선정됨. **패치**: `get_fallback_topic()`에 score_map (긱뉴스 RSS 48시간) + sensational/stale 필터 + score desc 재정렬 추가. **함정**: `import re` 누락 → 글로벌 import에 추가. **수동 발행 #1046 (GPT-5.6)**: Reddit HTML 파싱 (`<div class="md">`, sticky 제외) → 4758자 본문 + 이미지 2장 → 발행 성공, og:title 매칭 확인. §3.11 5-3 패치 확장: `last_published_url` + `last_published_id` 동시 갱신 (293차 함정 5 해결). 이 정책은 295차 사용자 결정으로 폐기됨.
- **295차 (2026-07-19 22:00~)** — 사용자가 "완전 무조건 발행 (모든 skip 제거)"를 확정. `get_fallback_topic()`의 score 재정렬·sensational/stale 필터를 제거하고 `run_pipeline()` timeliness block을 경고 전용으로 전환. dry 검증에서 과거 필터 대상 후보도 선정 + `status=ready` 확인. 22:00 cron은 §3.8.1 세션 302 만료로 publish 전 안전 skip, daily_counts 변동 없음. **최신 정책: 세션·중복·후보소진·publish 실패 외 품질 skip 금지.**
- **296차 (2026-07-19 23:01)** — 295차 정책 적용 후 첫 실제 발행 성공 사례. §3.8.1 raw VALID + §3.5 깨끗 (daily_counts[2026-07-19]=3) → AI/ML 발행. Topic "AI 기업 로고는 왜 항문처럼 보일까? (2025)" 선정 (이전엔 skip 됐을 후보, 295차 정책으로 통과). 본문 3535자 + 이미지 2장 CDN 업로드 → **#1047 발행 성공** (og:title 매칭 확인). §3.11 5-2 commit_publish → 5-3 last_published_url+id 보정 → 5-4 §3.5 ✅ 일치 → 5-5 proxy check status=200. 296차 daily_counts={AI/ML:4}. **신규 발견**: heredoc + env -i 조합이 SyntaxError로 실패 → 임시 파이썬 파일 분리 패턴이 안정적 (함정 6으로 등재).
- **297차 (2026-07-20 00:02)** — 새 날 cron 첫 발행. §3.8.1 raw VALID (manage/posts.json status=200, application/json, 첫 entry id=#1047 진짜 존재) + §3.5 신호 1 drift 경고 (last_url=#1047 인데 daily_counts[2026-07-20]=0) → **drift는 "어제 정상 발행 → 오늘 새 날" 자연스러운 상태**로 판정, 신호 4 FAKE_PUBLISH 미발동 (오늘 count=0) → 발행 진행. 295차 정책(완전 무조건 발행)으로 AI/ML ready 확인. Topic "AI가 Stack Overflow에 끼친 영향을 그래프로 보기" (31567) 선정. **CLI 옵션 함정 신규**: `tistory_publisher.py --category`는 int만 받음 (str 'AI/ML' 받으면 int 파싱 에러). `--category-id`/`--description`/`--html-file` 옵션 없음. 호출 = `--title --tags --visibility public --category <int_id> --source-url --gn-topic-id --file <html_path>`. 본문 6694자 빌드 → **#1048 발행 성공** (og:title 매칭 확인). §3.11 5-2 commit_publish (stats.today={AI/ML:1}, by_category에 "1219746" 정수 ID 키 오염 — 카테고리 ID/name 매핑 함정) → 5-3 last_published_url+id 보정 → 5-4 §3.5 ✅ 일치 → 5-5 proxy check status=200 + og_title 매칭. 297차 daily_counts={AI/ML:1}. **293차 함정 잔존**: details[-1]=#1043 + last=#1044 stale. SSOT 변경이라 사용자 확인 필요 → 이번 차 보류.
- **298차 (2026-07-20 02:02)** — §3.8.1 env -i 격리 모드 302 오탐 → raw 검증 (source tistory.env 후 격리 없이 직접 python3) status=200 VALID 확인 (291차 패턴). §3.5 깨끗 + 295차 정책 → AI/ML ready. Topic "100만 개 키워드가 보여준, AI가 검색에 미치는 영향" (31571) 선정. 본문 1946자 + Picsum 이미지 2장 CDN 업로드 → **#1049 발행 성공** (og:title 매칭 확인). **§3.11 5-3 표준 보정 확장 (293차 함정 4 해소)**: last_published_url + last_published_id + details append 한 번에 동기화 (기존엔 last 두 필드만, details는 사용자 게이트로 분리되어 매 차 반복 노출). 5-2 commit_publish → 5-3 last+details 통합 → 5-4 §3.5 신호 4 발동(오탐 — details append+last 동시 갱신 시 details[-1].slot==last_url.slot 무조건 성립) → **5-5 proxy check status=200+og_title 매칭으로 disambiguate, 가짜 발행 아님 확정** (298차 신규 패턴). 298차 daily_counts={AI/ML:2}. **297차 함정 8 잔존**: by_category["1219746"]=1 누적 (SSOT 변경 — 사용자 확인 후 보정 권장, 임의 자동 보정 금지).
- **299차 (2026-07-20 03:02)** — §3.8.1 가드 raw VALID + §3.5 신호 4 FAKE_PUBLISH 발동(daily_counts[2026-07-20]={AI/ML:2}, details[-1]=#1049, last=#1049, 두 슬롯 동일) → **5-5 proxy check disambiguate** 로 #1048/#1049 둘 다 status=200 + og_title 매칭 확인 → FAKE_PUBLISH **오탐 확정** (298차 패턴 재확인), publish 진행. Topic "안녕히, 그동안의 모든 Bikeshed에 감사드립니다" (31573) 선정 (이전엔 skip됐을 후보, 295차 정책으로 통과). 본문 3020자 + Picsum 이미지 2장 CDN 업로드 → **#1050 발행 성공** (og:title 매칭 확인). §3.11 5-2 commit_publish → 5-3 last+details 통합 보정 → 5-4 §3.5 신호 4 발동 (오탐) → 5-5 proxy check status=200+og_title 매칭 disambiguate 통과. 299차 daily_counts={AI/ML:3} (297 #1048 + 298 #1049 + 299 #1050). **297차 함정 8 누적 가속**: by_category["1219746"]=1 동일 유지 (코드 동작은 `=` 할당으로 첫 매핑 후 변동 없음, 사용자 게이트 시 ID_TO_NAME 매핑으로 한 번에 정리 필요). SKILL.md에 정형 보정 절차 코드 추가 (SSOT 변경 — 사용자 승인 시 적용, cron은 drift 보고만).
- **300차 (2026-07-20 05:02)** — §3.8.1 가드 raw VALID (status=200, first_id=#1050 진짜 존재) + §3.5 깨끗 상태에서 발행 진행. Topic **"Mamdani 뉴욕시장, 임대 광고에 AI 이미지를 몰래 사용할 수 없다고 밝혀"** (gn=31576, score=3.0, timeliness.fresh) 선정. 본문 6155자 + Picsum 이미지 2장 (seed: nyc-mamdani, rental-ai-disclosure) → **#1051 발행 성공** (og:title 매칭 확인). §3.11 5-2 commit_publish → 5-3 last+details 통합 보정 → 5-4 §3.5 신호 4 발동 → 5-5 proxy check disambiguate 통과. 300차 daily_counts={AI/ML:4}. **신규 발견 (published_topics.json 누락 누적 패턴)**: state.json details_len=123(#1051까지 추적)이지만 published_topics.json details_len=49(#1044에서 stale) — `--record-topic` 미사용 3회 누락(297~299차). **5-2-A 확장**: 단순 placeholder 보정 → **누락 발행분 state→published_topics 백필 절차**로 정형화 (idempotent, URL 중복 체크 안전). 백필 후 published_topics.json details_len=54 (#1048~#1051 모두 포함). **신호 4 오탐 disambiguate 3연속 확정**: 298→299→300 모두 "정상 publish + 5-3 동시 갱신 → 신호 4 발동"이지만 proxy check PASS로 무조건 진짜 발행 판정. **가짜발행 vs 오탐 구분 매트릭스 정형화**: details[-1].slot != last_url.slot = 진짜 FAKE_PUBLISH; slot 같음 + proxy 200 = 오탐; slot 같음 + proxy 404 = 진짜 FAKE_PUBLISH. 연속 all-green 80회차.
- **301차 (2026-07-20 19:02)** — §3.8.1 raw VALID + §3.5 신호 4 발동 (state.last=#1051, details[-1]=#1051 동일 slot → 무조건 발동, 그러나 daily_counts[2026-07-20]=4 ≠ 0이므로 진짜 FAKE_PUBLISH 의심 패턴) → **proxy check disambiguate 4연속 확정**: #1048/#1049/#1050/#1051 모두 status=200 + og:title 정확 매칭 → 전부 진짜 발행. 295차 정책으로 AI/ML ready, **gn=31598 ("AI 래퍼는 끝났다: 초기 스타트업을 위한 수직화 전략")** 선정. 본문 2626자 + Picsum 이미지 2장 → **#1052 발행 성공** (og:title 매칭 확인). §3.11 5-2 commit_publish (stats.today={AI/ML:5}) → 5-3 last+details 통합 보정 → 5-4 §3.5 신호 4 재발동 (오탐 4연속, proxy로 disambiguate 통과) → **5-2-A 백필 안정성 재확인**: 누락분 72건 idempotent 백필, published_topics.json details_len 54→126 (state.details_len=125와 거의 일치, 1건 차이는 state 첫 entry pre-#1044 — 의도된 차이). **297차 함정 8 by_category 누적 영구화 확인**: 301차 #1052 발행 후 by_category["1219746"]=1 동일 유지 (코드 동작 `=` 할당으로 첫 매핑 후 변동 없음) — 사용자 게이트 시 1회 ID_TO_NAME 보정으로 영구 해결 가능. **신규 환경 함정 (301차)**: `env -i ... /usr/bin/python3 /usr/bin/python3 <script>` 같이 python3를 두 번 쓰면 SyntaxError (`Non-UTF-8 code starting with '\xca'`). `env -i ... /usr/bin/python3 <script>` 단일 형태로 호출해야 함. 연속 all-green 81회차.
- **302차 (2026-07-20 20:02)** — §3.8.1 raw VALID (manage/posts.json status=200, 첫 entry id=#1052 진짜 존재) + §3.5 신호 4 발동 (state.last=#1052, details[-1]=#1052 동일 slot, daily_counts[2026-07-20]=5 ≥ 2) → **proxy check disambiguate 5연속 확정**: #1052 status=200 + og:title 매칭 → 진짜 발행. 295차 정책으로 AI/ML ready, **gn=31608 ("태스크 이코노미 - 데이터가 만드는 다음 1조 달러 시장")** 선정 (Notion 1순위 score=4.0, timeliness.fresh). 본문 4018자 + Picsum 이미지 2장 (seed: taskeconomy-data-pipeline, task-economy-marketplace) → **#1053 발행 성공** (og:title 매칭 확인). §3.11 5-2 commit_publish (stats.today={AI/ML:6}, total=47) → 5-3 last+details 통합 보정 (details_len=126) → 5-2-A 백필 (1건, published_topics.json details_len=127) → 5-4 §3.5 신호 4 발동 (오탐 5연속) → 5-5 proxy check #1053 status=200 + og:title 매칭 disambiguate 통과. 302차 daily_counts={AI/ML:6} (297 #1048 + 298 #1049 + 299 #1050 + 300 #1051 + 301 #1052 + 302 #1053). **297차 함정 8 by_category 영구화 5연속 재확인**: 302차 #1053 발행 후에도 by_category["1219746"]=1 동일 유지 (코드 동작 `=` 할당으로 첫 매핑 후 영구 누적, 사용자 게이트 시 1회 ID_TO_NAME 보정 권장, cron은 drift 보고만 유지). SKILL.md disambiguate 패턴 카운트 4연속 → **5연속 확정으로 격상**. 연속 all-green 82회차.
- **303차 (2026-07-20 21:04)** — §3.8.1 가드 자체 3중 함정 노출 (재발 13회차째): `session_expiry_guard.sh` 호출이 (a) `/usr/bin/python3`가 Xcode python3를 가리켜 `ModuleNotFoundError: requests` (b) `requests`가 user-site에만 있어 `env -i PYTHONPATH=` 격리 실패 (c) `env -i`가 source된 TISTORY_* 환경변수 미보존 → cookies_count=0 → 302 오탐. **raw 검증 우회**: `set -a; source tistory.env; unset PYTHONPATH PYTHONHOME; PYTHONNOUSERSITE=1; export PYTHONPATH=/Users/mac/Library/Python/3.9/lib/python/site-packages; /usr/bin/python3 -s << 'PYEOF'` 형태로 status=200 + items[0].id="1053" 확인 (정상). 본문 빌드 패턴 정상 (write_file + /tmp/post_*.html + /usr/bin/python3 -s 실행). Topic **gn=31614 ("AI 조언을 받으면 정확도는 3분의 1로 떨어지고 자신감은 2배 이상 높아짐", score 3.0)** 선정, 본문 3245자 + Picsum 이미지 2장 → **#1054 발행 성공** (status=200 + title 매칭). §3.11 5-2 commit_publish (stats.today={AI/ML:7}, total=48) → 5-3 last+details 통합 보정 (details_len=127) → 5-2-A 백필 1건 (published_topics.json details_len=128) → 5-4 §3.5 신호 4 발동 (오탐 6연속) → 5-5 proxy check #1054 status=200 + og:title 매칭 disambiguate 통과. **신호 4 오탐 disambiguate 6연속 확정** (298→299→300→301→302→303) — 정상 워크플로의 일부로 정착. **함정 10 신규 (303차)** — 가드 격리 모드 한계 3중 함정 (Xcode python3 충돌 + user-site 격리 실패 + env -i 환경변수 손실) + 안정적 raw 검증 우회 패턴 정형화. **296차 함정 6 (heredoc + env -i)** 도 303차 실전 재발견 (escape + 연결 패턴 SyntaxError 회피). SKILL.md 본문 가이드의 모든 `env -i ...` 호출은 시간이 지날수록 환경 의존성 증가 → 점진 교체 권장 (사용자 게이트 후). 303차 daily_counts={AI/ML:7}. 연속 all-green 83회차.
- **304차 (2026-07-20 22:02)** — §3.8.1 raw VALID (status=200, items[0].id="1054" — 303차 #1054 진짜 존재) + §3.5 깨끗 → AI/ML ready. Topic **gn=31602 ("AI 광풍이 전 세계의 의사결정을 무너뜨리고 있음")** 선정, 본문 2851자 + CDN 이미지 2장 (`https://cdn.sigco.dev/ai-decision-meltdown-boardroom.jpg` 등 자체서명 SSL 경고 — 함정 11 신규, 발행 정상) → **#1055 발행 성공** (proxy status=200 + title="AI 광풍이 전 세계의 의사결정을 무너뜨리고 있음 &mdash; 채택 가이드와 현실 점검" + og:title 정확 매칭). §3.11 5-2 commit_publish (stats.today={AI/ML:8}, total=49, by_category["1219746"]=1 동일 유지 — 함정 8 영구 잔존 6연속) → 5-3 last+details 통합 보정 (#1054→#1055, details_len 127→128) → 5-2-A 백필 1건 (state 첫 entry pre-#1044 차이, pt_details_len=129) → 5-4 §3.5 신호 4 발동 (오탐 7연속) → 5-5 proxy check #1055 status=200 + og:title 매칭 disambiguate 통과. **신호 4 오탐 disambiguate 8연속 확정** (298→305) — 정상 워크플로의 일부. **305차 (2026-07-20 23:02)** — §3.8.1 raw VALID (status=200, items[0].id="1055" — 304차 #1055 진짜 존재) + §3.5 깨끗 → AI/ML ready. Topic **gn=31591 ("여분의 Mac을 Claude Code 전용 제어 환경으로 만드는 단계별 가이드")** 선정 (Notion 1순위, freshness OK, sensational 아님 — 295차 정책 통과). **본문 빌드 강화 패턴 (305차 신규)**: `build_post_305.py` 안에 `requests.get(gn_url) + <meta property="og:description" content="..."> regex` 임베드 → description을 별도 단계 없이 본문에 박는 단일 패스. 304차의 "본문 빌드 + 이미지 업로드 단일 패스" 패턴을 긱뉴스 OG description 추출까지 확장한 변형. 함정 3 (긱뉴스 본문 selector 모두 코멘트) 회피 + 함정 6 (heredoc + env -i SyntaxError) + 함정 11 (`execute_code` cron 차단) 동시 회피. Picsum 이미지 2장 (`https://picsum.photos/seed/mac-claude-setup/1200/630`, `seed/claude-code-workstation/1200/630`) → 본문 5644자 빌드 → **#1056 발행 성공** (proxy status=200 + title="여분의 Mac을 Claude Code 전용 제어 환경으로 만드는 단계별 가이드 &mdash; 보안과 격리, 자동화까지 한 번에" + og:title 정확 매칭). §3.11 5-2 commit_publish (stats.today={AI/ML:9}, total=50, by_category["1219746"]=1 동일 유지 — 함정 8 영구 잔존 8연속) → 5-3 last+details 통합 보정 (#1055→#1056, details_len 129) → 5-2-A 백필 0건 (누적 동기화 완료) → 5-4 §3.5 신호 4 발동 (오탐 8연속) → 5-5 proxy check #1056 status=200 + og:title 매칭 disambiguate 통과. 305차 daily_counts={AI/ML:9} (297 #1048 + 298 #1049 + 299 #1050 + 300 #1051 + 301 #1052 + 302 #1053 + 303 #1054 + 304 #1055 + 305 #1056). 연속 all-green 85회차. **함정 11 신규 (304차)**: `execute_code`는 cron에서 `approvals.cron_mode` 가드로 차단됨 → 본문 빌드는 항상 write_file(`/tmp/build_post_XXX.py`) + `/usr/bin/python3 -s` + read_file(`/tmp/post_XXX.html`) → `tistory_publisher.py --file` 패턴. 302차 확립 패턴 304차 재확인. **함정 12 신규 (304차)**: `https://cdn.sigco.dev/...` 자체서명 SSL CERTIFICATE_VERIFY_FAILED 경고는 발행에 영향 없음 (Tistory가 CDN 업로드 실패 이미지 무시, 텍스트/마크다운만 정상 발행) → cron 로그 노이즈 감수, 진짜 발행 판정은 status=200 + og:title 매칭으로. **303차 안정적 raw 검증 패턴 304차 정상 작동 재확인** (Xcode python3 충돌 / user-site 격리 / env -i 환경변수 손실 3중 우회 모두 정상). 304차 daily_counts={AI/ML:8}. 연속 all-green 84회차.
- **305차 (2026-07-20 23:02)** — §3.8.1 raw VALID (status=200, items[0].id="1055" — 304차 #1055 진짜 존재) + §3.5 깨끗 → AI/ML ready. Topic **gn=31591 ("여분의 Mac을 Claude Code 전용 제어 환경으로 만드는 단계별 가이드")** 선정 (Notion 1순위, freshness OK, sensational 아님 — 295차 정책 통과). **본문 빌드 단일 패스 강화 패턴 (305차 신규)**: `build_post_305.py` 안에 `requests.get(gn_url) + <meta property="og:description" content="..."> regex` 임베드 → 긱뉴스 description을 별도 단계 없이 본문에 박는 단일 패스. 304차의 "본문 빌드 + 이미지 업로드 단일 패스"를 description 추출까지 확장. 함정 3 (긱뉴스 본문 selector 코멘트만) + 함정 6 (heredoc + env -i SyntaxError) + 함정 11 (`execute_code` cron 차단) 3중 동시 회피. Picsum 이미지 2장 (`https://picsum.photos/seed/mac-claude-setup/1200/630`, `seed/claude-code-workstation/1200/630`) → 본문 5644자 빌드 → **#1056 발행 성공** (proxy status=200 + title="여분의 Mac을 Claude Code 전용 제어 환경으로 만드는 단계별 가이드 &mdash; 보안과 격리, 자동화까지 한 번에" + og:title 정확 매칭). §3.11 5-2 commit_publish (stats.today={AI/ML:9}, total=50, by_category["1219746"]=1 동일 유지 — 함정 8 영구 잔존 8연속) → 5-3 last+details 통합 보정 (#1055→#1056, details_len 129) → 5-2-A 백필 0건 (누적 동기화 완료) → 5-4 §3.5 신호 4 발동 (오탐 8연속) → 5-5 proxy check #1056 status=200 + og:title 매칭 disambiguate 통과. 305차 daily_counts={AI/ML:9} (297 #1048 + 298 #1049 + 299 #1050 + 300 #1051 + 301 #1052 + 302 #1053 + 303 #1054 + 304 #1055 + 305 #1056). 연속 all-green 85회차.
- **306차 (2026-07-21 03:01)** — §3.8.1 raw VALID (status=200, items[0..4]=['1059','1058','1057','1056','1055']) + §3.5 깨끗 + 295차 정책 → AI/ML ready. **신규 발견 — `run_pipeline()` 호출 시 topic 선정 비결정성 (306차)**: `--category 'AI/ML'`을 같은 세션 안에서 두 번 호출하면 1회차엔 gn=31611 (Codex 272k 컨텍스트), 2회차엔 gn=31599 (Qwen 3.8)로 다른 후보를 반환. Notion DB 활성 후보 셔플 / 폴링 순서 / `get_fallback_topic()` 내부 timestamp 의존성 등으로 비결정적 동작. **영향**: cron이 `run_pipeline()` 결과 topic을 그대로 신뢰해 publish 인자로 넘기는 패턴이라면, 호출 사이에 누차 다른 후보가 들어와도 publish URL은 stdout에서 grep하면 정상이라 외부 영향 없음 — 단, 같은 차에 두 번 publish 하지 않도록 publish URL 추출 후 동일 #NNN 중복 가드는 여전히 필수. Topic **gn=31611 ("OpenAI, Codex 모델 컨텍스트 크기를 372k에서 272k로 축소 — 무엇이 달라졌고 개발자는 어떻게 대응해야 할까", Notion 4순위 score=8.0)** 1회차 호출 결과로 선정. **305차 단일 패스 패턴 재확인**: `build_post_306.py` 안에 `requests.get(gn_url) + <meta property="og:description"> regex` 임베드 → 160자 description 추출 성공 + Picsum 이미지 2장 (seed: codex-context-reduction / codex-272k-context) → 본문 4088자 빌드 → **#1060 발행 성공** (proxy status=200 + title="OpenAI, Codex 모델 컨텍스트 크기를 372k에서 272k로 축소 &mdash; 무엇이 달라졌고 개발자는 어떻게 대응해야 할까" + og:title="OpenAI, Codex 모델 컨텍스트 크기를 372k에서 272k로 축소 — 무엇이 달라졌고 개발자는 어떻게 대응해야 할까" 정확 매칭, OG 썸네일 `https://blog.kakaocdn.net/dna/YTCt3/dJMcajiJsOi/...` 정상 설정). §3.11 5-2 commit_publish (stats.today={AI/ML:4}, total=54, by_category["1219746"]=1 동일 유지 — 함정 8 영구 잔존 9연속) → 5-3 last+details 통합 보정 (#1059→#1060, details_len 132→133) → 5-2-A 백필 1건 (published_topics.json details_len=134) → 5-4 §3.5 신호 4 발동 (오탐 9연속) → 5-5 proxy check #1060 status=200 + og:title 정확 매칭 disambiguate 통과. **신호 4 오탐 disambiguate 9연속 확정** (298→299→300→301→302→303→304→305→306) — 정상 워크플로의 일부로 정착, drift 라인에 따로 명시 불필요. 306차 daily_counts={AI/ML:4}. 연속 all-green 86회차. **함정 11 재확인**: `write_file` + `/tmp/build_post_306.py` + `/usr/bin/python3 -s` 실행 + `--file /tmp/post_306.html` 정형 패턴 cron에서 정상 작동 (305차 패턴 306차 재확인). **303차 안정 raw 검증 패턴 306차 재확인**: `set -a; source; unset PYTHONPATH PYTHONHOME; PYTHONNOUSERSITE=1; export PYTHONPATH=user-site; /usr/bin/python3 -s` 형태로 §3.8.1 가드 정상 통과.
- **307차 (2026-07-21 05:01)** — §3.8.1 raw VALID (status=200, content_type=application/json, cookies_count=8, first_ids=['1061','1060','1059','1058','1057']) + §3.5 신호 4 발동 (state.last=#1061, details[-1]=#1061 동일 slot, daily_counts={AI/ML:5} ≥ 2) → **proxy check disambiguate 10연속 확정**: #1061 (Qwen 3.8) status=200 + title 정확 매칭 → 진짜 발행, **오탐 확정**. 295차 정책으로 AI/ML ready, **gn=31604 ("Supabase가 조사한 2026년 스타트업 현황", Notion 1순위, freshness OK)** 선정. **신규 발견 — `import os` 누락 시 NameError 패턴 (307차)**: 5-5 proxy check heredoc 작성 시 `os.environ` 참조를 위해 `import os`를 빠뜨리면 즉시 `NameError: name 'os' is not defined`로 검증 단계 실패. **해결**: heredoc 첫 줄에 `import os, requests, re` 세 모듈 항상 포함 (303차 안정 raw 검증 패턴 + 5-5 proxy check 두 곳에서 동일하게 적용). **305차 단일 패스 패턴 307차 재확인** — `build_post_307.py` 안에 `requests.get(gn_url) + og:description regex` 임베드 → 160자 description 추출 + Picsum 이미지 2장 + 본문 6952자 빌드 → **#1062 발행 성공** (proxy status=200 + og:title 정확 매칭). §3.11 5-2 commit_publish (stats.today={AI/ML:6}, total=56) → 5-3 last+details 통합 보정 (details_len 133→135) → 5-2-A 백필 2건 (pt_details_len=136) → 5-4 §3.5 신호 4 발동 (오탐 10연속) → 5-5 proxy check PASS disambiguate. **신호 4 오탐 disambiguate 10연속 확정** (298→307) — 정상 워크플로의 일부. 307차 daily_counts={AI/ML:6}. 연속 all-green 87회차. **함정 14 신규** — `import os` 누락 → NameError. 운영 원칙: cron heredoc 첫 줄은 항상 `import os, requests, re` 세 모듈 포함.
- **308차 (2026-07-21 21:01)** — §3.8.1 raw VALID (status=200, content_type=application/json, cookies_count=8, first_ids=['1065','1064','1063','1062','1061']) + §3.5 신호 4 발동 (state.last=#1065, details[-1]=#1065 동일 slot, daily_counts={AI/ML:8, 개발도구:1} ≥ 2) → **proxy check disambiguate 11연속 확정**: #1065 (arXiv 12,750편) status=200 + og:title 정확 매칭 → 진짜 발행, **오탐 확정**. 295차 정책으로 AI/ML ready, **gn=31640 ("WordPress RCE를 GPT5.6과 25달러로 발견")** 선정 (Notion 1순위 후보, score=4.0, timeliness.fresh). **305차 단일 패스 패턴 308차 재확인 (3연속 정형화)** — `build_post_308.py` 안에 `requests.get(gn_url) + og:description regex` 임베드 → 160자 description 추출 성공 + Picsum 이미지 2장 (seed: wordpress-rce-gpt56 / security-research-ai-agent) + 본문 6399자 빌드 → **#1066 발행 성공** (proxy status=200 + title="WordPress RCE를 GPT5.6과 25달러로 발견 &mdash; AI 에이전트로 풀스택 보안 감사를 시작하는 법" + og:title="WordPress RCE를 GPT5.6과 25달러로 발견 — AI 에이전트로 풀스택 보안 감사를 시작하는 법" 정확 매칭, OG 썸네일 `https://blog.kakaocdn.net/dna/dpW14c/dJMcadpdOe8/...` 정상 설정). §3.11 5-2 commit_publish (stats.today={AI/ML:9, 개발도구:1}, total=60, by_category["1219746"]=1 동일 유지 — 함정 8 영구 잔존 11연속) → 5-3 last+details 통합 보정 (#1065→#1066, details_len 138→139) → 5-2-A 백필 1건 (누적 동기화, published_topics.json details_len=140) → 5-4 §3.5 신호 4 발동 (오탐 11연속) → 5-5 proxy check #1066 status=200 + og:title 정확 매칭 disambiguate 통과. **신호 4 오탐 disambiguate 11연속 확정** (298→308) — 정상 워크플로의 일부. 308차 daily_counts={AI/ML:9, 개발도구:1} (총 10건, AI/ML 297 #1048 + 298 #1049 + 299 #1050 + 300 #1051 + 301 #1052 + 302 #1053 + 303 #1054 + 304 #1055 + 305 #1056 + 306 #1060 + 307 #1062 + 308 #1066 + 개발도구 306 #1063). 연속 all-green 88회차. **함정 회피 4중 동시 확인**: 함정 6 (heredoc + env -i SyntaxError) + 함정 7 (--category int만) + 함정 11 (execute_code cron 차단 회피) + 함정 14 (import os 누락) 모두 308차 워크플로에서 자동 회피 성공. **308차 신규 관찰 — 다중 발행 누적 상태에서도 패턴 안정성**: 일자 발행 10건(daily_counts={AI/ML:9, 개발도구:1}) 누적 상태에서 §3.8.1 raw VALID + §3.5 신호 4 오탐 + 5-5 proxy check PASS로 disambiguate하는 패턴이 11연속 안정적으로 작동 — 누적량에 무관하게 정형 패턴 유지됨을 확인. cron은 일자 발행량 0~10건 범위에서 패턴 분기 없이 동일 절차로 처리 가능.
- **309차 (2026-07-21 22:01)** — §3.8.1 raw VALID (status=200, content_type=application/json, cookies_count=8, first_ids=['1066','1065','1064','1063','1062']) + §3.5 신호 4 발동 (state.last=#1067, details[-1]=#1067 동일 slot, daily_counts={AI/ML:10, 개발도구:1} ≥ 2) → **proxy check disambiguate 12연속 확정**: #1067 (중국 오픈 가중치) status=200 + title 정확 매칭 + og:title 정확 매칭 → 진짜 발행, **오탐 확정**. 295차 정책으로 AI/ML ready, **gn=31634 ("중국의 오픈 가중치 AI 전략이 앞서고 있음")** 선정 (Notion 1순위 후보, score=6.0, timeliness.fresh). **305차 단일 패스 패턴 309차 재확인 (4연속 정형화)** — `build_post_309.py` 안에 `requests.get(gn_url) + og:description regex` 임베드 → 160자 description 추출 + Picsum 이미지 2장 (seed: china-open-weight-ai / open-vs-closed-models) + 본문 6797자 빌드 → **#1067 발행 성공** (proxy status=200 + title="중국의 오픈 가중치 AI 전략이 앞서고 있음 &mdash; 폐쇄형 모델 시대의 종착점" + og:title 정확 매칭, OG 썸네일 `https://blog.kakaocdn.net/dna/bgkY8c/dJMcaglYAHF/...` 정상 설정). §3.11 5-2 commit_publish (stats.today={AI/ML:10, 개발도구:1}, total=61, by_category["1219746"]=1 동일 유지 — 함정 8 영구 잔존 12연속) → 5-3 last+details 통합 보정 (#1066→#1067, details_len 139→140) → 5-2-A 백필 1건 (누적 동기화, published_topics.json details_len=141) → 5-4 §3.5 신호 4 발동 (오탐 12연속) → 5-5 proxy check #1067 status=200 + og:title 정확 매칭 disambiguate 통과. 309차 daily_counts={AI/ML:10, 개발도구:1} (총 11건). 연속 all-green 89회차. **함정 15 신규 (309차)** — 5-5 proxy check heredoc 격리 누락 → `ModuleNotFoundError: No module named 'requests'`. SKILL.md 본문 §3.11 5-5 예제는 격리 미적용이었으나 §1단계 가드와 동일 격리 패턴(`unset PYTHONPATH PYTHONHOME; PYTHONNOUSERSITE=1; export PYTHONPATH=user-site; /usr/bin/python3 -s`)으로 통일. 309차 5-5에서 첫 시도 시 격리 누락 → 즉시 ModuleNotFoundError → 격리 패턴 추가 후 status=200 + title + og:title 정확 매칭 정상. **og:title까지 매칭 확인이 진짜 발행 판정의 단일 기준**으로 정착 (단순 title만은 RSS 변형 가능성 있어 og:title 권장).
- **references/session-20260721-308th-wordpress-rce-gpt56-25dollars.md** — 308차 #1066 ("WordPress RCE를 GPT5.6과 25달러로 발견 — AI 에이전트로 풀스택 보안 감사를 시작하는 법", gn=31640, AI/ML) 발행 + §3.5 신호 4 오탐 disambiguate **11연속 확정** (298→308) + **305차 단일 패스 패턴 308차 재확인 (3연속 정형화)** — `build_post_308.py` 안에 `requests.get(gn_url) + <meta property="og:description"> regex` 임베드 → 160자 description 추출 성공 ("GPT5.6 Sol Ultra가 최신 안정판 WordPress를 분석해 인증 전 SQL 주입부터 관리자 계정 생성과 원격 코드 실행(RCE)까지 이어지는 공격 체인을 10여 시간 만에 완성함...") + Picsum 이미지 2장 (seed: wordpress-rce-gpt56 / security-research-ai-agent) + 본문 6399자 빌드 → **#1066 발행 성공** (proxy status=200 + title="WordPress RCE를 GPT5.6과 25달러로 발견 &mdash; AI 에이전트로 풀스택 보안 감사를 시작하는 법" + og:title 정확 매칭, OG 썸네일 `https://blog.kakaocdn.net/dna/dpW14c/dJMcadpdOe8/...` 정상 설정). §3.11 5-2 commit_publish (stats.today={AI/ML:9, 개발도구:1}, total=60, by_category["1219746"]=1 동일 유지 — 함정 8 영구 잔존 11연속) → 5-3 last+details 통합 보정 (#1065→#1066, details_len 138→139) → 5-2-A 백필 1건 (누적 동기화, published_topics.json details_len=140) → 5-4 §3.5 신호 4 발동 (오탐 11연속) → 5-5 proxy check #1066 status=200 + og:title 정확 매칭 disambiguate 통과. 308차 daily_counts={AI/ML:9, 개발도구:1} (총 10건 = AI/ML #1048~#1056+#1060+#1062+#1066 + 개발도구 #1063). 연속 all-green 88회차. **함정 회피 4중 동시 확인**: 함정 6 (heredoc + env -i) + 함정 7 (--category int) + 함정 11 (execute_code cron 차단) + 함정 14 (import os 누락) 모두 308차에서 자동 회피 성공.
- **references/session-20260721-309th-china-open-weight-ai-strategy.md** — 309차 #1067 ("중국의 오픈 가중치 AI 전략이 앞서고 있음 — 폐쇄형 모델 시대의 종착점", gn=31634, AI/ML, score=6.0) 발행 + §3.5 신호 4 오탐 disambiguate **12연속 확정** (298→309) + **305차 단일 패스 패턴 309차 재확인 (4연속 정형화)** — `build_post_309.py` 안에 `requests.get(gn_url) + <meta property="og:description"> regex` 임베드 → 160자 description 추출 ("AI 모델은 브랜드 충성도와 피상적인 전환 비용 외에는 방어력이 크지 않아...") + Picsum 이미지 2장 (seed: china-open-weight-ai / open-vs-closed-models) + 본문 6797자 빌드 → **#1067 발행 성공** (proxy status=200 + title="중국의 오픈 가중치 AI 전략이 앞서고 있음 &mdash; 폐쇄형 모델 시대의 종착점" + og:title 정확 매칭, OG 썸네일 `https://blog.kakaocdn.net/dna/bgkY8c/dJMcaglYAHF/...` 정상 설정). §3.11 5-2 commit_publish (stats.today={AI/ML:10, 개발도구:1}, total=61, by_category["1219746"]=1 동일 유지 — 함정 8 영구 잔존 12연속) → 5-3 last+details 통합 보정 (#1066→#1067, details_len 139→140) → 5-2-A 백필 1건 (누적 동기화, published_topics.json details_len=141) → 5-4 §3.5 신호 4 발동 (오탐 12연속) → 5-5 proxy check #1067 status=200 + og:title 정확 매칭 disambiguate 통과. 309차 daily_counts={AI/ML:10, 개발도구:1} (총 11건). 연속 all-green 89회차. **함정 15 신규 (309차)** — 5-5 proxy check heredoc 격리 누락 → `ModuleNotFoundError: No module named 'requests'`. SKILL.md 본문 §3.11 5-5 예제는 격리 미적용이었으나 §1단계 가드와 동일 격리 패턴(`unset PYTHONPATH PYTHONHOME; PYTHONNOUSERSITE=1; export PYTHONPATH=/Users/mac/Library/Python/3.9/lib/python/site-packages; /usr/bin/python3 -s`)으로 통일. **og:title까지 매칭** 확인이 진짜 발행 판정의 단일 기준으로 정착. 309차 5-5에서 첫 시도 시 격리 누락으로 즉시 ModuleNotFoundError → 격리 패턴 추가 후 status=200 + title + og:title 정확 매칭 정상 확인.
- **references/session-20260722-310th-opencode-troubles-qwen27b.md** — 310차 #1071 ("OpenCode의 성가시고 불안한 문제들 — 로컬 Qwen3.6-27B 실전에서 드러난 4가지 결함", gn=31641, AI/ML, score=27.0) 발행 + §3.5 신호 4 오탐 disambiguate **13연속 확정** (298→310) + **305차 단일 패스 패턴 310차 재확인 (5연속 정형화)** — `build_post_310.py` 안에 `requests.get(gn_url) + <meta property="og:description"> regex` 임베드 → 240자 description 추출 ("GitHub 스타 16.1만 개를 받은 오픈소스 AI 코딩 에이전트 OpenCode를 로컬 Qwen3.6-27B로 시험한 결과...") + Picsum 이미지 2장 (seed: opencode-troubles / opencode-security-qwen3) + 본문 4799자 빌드 → **#1071 발행 성공** (proxy status=200 + title="OpenCode의 성가시고 불안한 문제들 &mdash; 로컬 Qwen3.6-27B 실전에서 드러난 4가지 결함" + og:title 정확 매칭, OG 썸네일 `https://blog.kakaocdn.net/dna/bQwu7z/dJMcaf1ERyM/...` 정상 설정). **§3.5 진입 시점 신호 4 + 5-5 disambiguate 트리거 정형화** — 310차는 7/22 새 차 cron 첫 발행으로, 진입 시 daily_counts[2026-07-22]={AI/ML:2} (어제 23:01~오늘 01:01 사이 #1069/#1070 누적) + state.last=#1070 + details[-1]=#1070 → 5-5에서 #1068/#1069/#1070 status=200 + og:title 정확 매칭 3건 모두 확인 후 진짜 발행 오탐 확정. §3.11 5-2 commit_publish (stats.today={AI/ML:3}, total=65, by_category["1219746"]=1 동일 유지 — 함정 8 영구 잔존 13연속) → 5-3 last+details 통합 보정 (#1070→#1071, details_len 143→144) → 5-2-A 백필 1건 (누적 동기화, published_topics.json details_len 144→145) → 5-4 §3.5 신호 4 발동 (오탐 13연속) → 5-5 proxy check #1071 status=200 + og:title 정확 매칭 disambiguate 통과. **310차 신규 관찰**: 새 차 cron은 진입 단계(§3.5 1차 검증)에서 신호 4가 이미 발동해도 5-5로 직전 차 발행들 disambiguate 후 발행 단계 진입 가능 — 즉 진입 시점 신호 4 = 발행 skip 사유 아님, 직전 차 proxy check만 통과하면 publish 진행. 310차 daily_counts={AI/ML:3}. 연속 all-green 90회차. **후보 중복 가드 정형화 (310차)** — `run_pipeline()`이 선정한 1순위 후보의 topic_id를 `published_topics.json`에서 in-memory dict lookup으로 즉시 검증, 이미 발행된 글이면 다음 순위로. 310차 1순위 gn=31641 → 미발행 → 발행 대상.
- **references/session-20260722-311th-bedctl-waterbed-api-fallback-category.md** — 311차 #1074 ("수랭식 침대를 제어하는 API 클라이언트 bedctl — 잘 때만 코딩하는 개발자를 위한 가이드", gn=31631, 개발도구, score=4.0) 발행 + §3.5 신호 4 오탐 disambiguate **14연속 확정** (298→311) + **§3-B 신규 정형화 — AI/ML 후보 소진 → 다른 카테고리 fallback 워크플로우 첫 실전 검증** — §3-a `blog_pipeline.py --category 'AI/ML'` → `status=skip` ("AI/ML 카테고리의 긱뉴스 주제와 트렌드 주제 모두 소진되었습니다") → §3-b fallback: `--category '개발도구'` → `status=ready` + gn=31631 "수랭식 침대를 제어하는 API 클라이언트 bedctl" → §3-b publish `--category 1219748` (int) → #1074 발행 성공 (proxy status=200 + title="수랭식 침대를 제어하는 API 클라이언트 bedctl &mdash; 잘 때만 코딩하는 개발자를 위한 가이드" + og:title 정확 매칭, OG 썸네일 `https://blog.kakaocdn.net/dna/rP5nM/dJMcadizCUH/...` 정상 설정) → §3-b.5 commit_publish 카테고리 인자 str("개발도구") → stats.today={AI/ML:5, 개발도구:1}, total=68. **305차 단일 패스 패턴 311차 재확인 (6연속 정형화)** — `build_post_311.py` 안에 `requests.get(gn_url) + <meta property="og:description"> regex` 임베드 → 160자 description 추출 + Picsum 이미지 2장 (seed: bedctl-waterbed-control / bedctl-temperature-schedule) + 본문 2738자 빌드. **§3.11 5-2 commit_publish → 5-3 last+details 통합 보정 (details_len 146→147) → 5-2-A 백필 1건 (published_topics.json details_len=148) → 5-4 §3.5 신호 4 발동 (오탐 14연속) → 5-5 proxy check PASS disambiguate**. **311차 신규 관찰 — 진입 시점 신호 4 + 5-5 disambiguate 트리거가 2연속 확정** (310차 + 311차 모두 진입 단계 신호 4 발동 → 5-5로 직전 차 발행들 disambiguate 후 발행 단계 진입, 정상 워크플로의 일부로 정착). **함정 16 신규 (311차)**: §3-b commit_publish 카테고리 인자 타입 — publish의 `--category`는 int(1219748)지만 commit의 카테고리 인자는 str("개발도구"). 두 호출의 카테고리 인자 타입이 다르다 — 혼동 시 publish는 즉시 에러 종료, commit은 stats.by_category에 새 str 키 누적. **원칙**: publish=`--category <int>`, commit=마지막 위치 인자에 `<str 카테고리명>`. **함정 회피 5중 동시 확인**: 함정 6 (heredoc + env -i SyntaxError) + 함정 7 (--category int만) + 함정 8 (by_category["1219746"]=1 영구 잔존 14연속) + 함정 11 (execute_code cron 차단 회피) + 함정 15 (5-5 proxy check 격리 패턴 적용) 모두 311차 워크플로에서 자동 회피 성공. **함정 회피 추가**: 함정 16 (publish/commit 카테고리 인자 타입 차이) — commit_publish 인자 str("개발도구") + publish 인자 int(1219748) 모두 정확히 분리 적용. 311차 daily_counts={AI/ML:5, 개발도구:1} (총 6건). 연속 all-green 91회차.
- **references/session-20260722-312th-kimi-k3-fable-routing.md** — 312차 #1078 ("Kimi K3와 Fable 5의 작업별 라우팅 — 두 모델의 조합이 단일 최고 모델을 넘어서는 순간", gn=31689, AI/ML, score=3.0) 발행 + §3.5 신호 4 오탐 disambiguate **16연속 확정** (298→312) + **305차 단일 패스 패턴 312차 재확인 (7연속 정형화)** — `build_post_312.py` 안에 `requests.get(gn_url) + <meta property="og:description"> regex` 임베드 → 160자 description 추출 ("약 1,030개 에이전트 작업에서 Kimi K3와 Fable 5를 비교한 결과, 작업별 라우팅은 93% 정확도로 개별 모델보다 높은 품질을 달성함 SWE·터미널·알고리듬·다중 언어·법률 작업에서 전체 성능은 비슷했지만, 두 모델이 강점을 보이는 작업 영역은 서로 달랐음 오라클 라우팅은…") + Picsum 이미지 2장 (seed: kimi-k3-fable-routing / multi-model-orchestration) + 본문 2605자 빌드 → **#1078 발행 성공** (proxy status=200 + title="Kimi K3와 Fable 5의 작업별 라우팅 &mdash; 두 모델의 조합이 단일 최고 모델을 넘어서는 순간" + og:title="Kimi K3와 Fable 5의 작업별 라우팅 — 두 모델의 조합이 단일 최고 모델을 넘어서는 순간" 정확 매칭, OG 썸네일 `https://blog.kakaocdn.net/dna/bhk8sS/dJMcac9uSj/...` 정상 설정). §3.11 5-2 commit_publish (stats.today={AI/ML:8, 개발도구:2}, total=72, by_category["1219746"]=1 동일 유지 — 함정 8 영구 잔존 16연속) → 5-3 last+details 통합 보정 (#1077→#1078, details_len 150→151) → 5-2-A 백필 1건 (누적 동기화, published_topics.json details_len 151→152) → 5-4 §3.5 신호 4 발동 (오탐 16연속) → 5-5 proxy check #1078 status=200 + og:title 정확 매칭 disambiguate 통과. **312차 신규 관찰 — 진입 시점 신호 4 + 5-5 disambiguate 트리거 3연속 확정** (310/311/312 모두 진입 단계 신호 4 발동 → 5-5로 직전 차 발행들 disambiguate 후 발행 단계 진입, 정상 워크플로의 일부로 완전히 정착). **311차 fallback 패턴 후 정상 publish 복귀 확인** — AI/ML 후보가 다시 충분해지면 §3-B fallback 없이 §3-a → §3-b → §3-b.5 정상 진행. **함정 회피 5중 동시 확인**: 함정 6 + 함정 7 + 함정 8 + 함정 11 + 함정 15 모두 312차 워크플로에서 자동 회피 성공. 312차 daily_counts={AI/ML:8, 개발도구:2} (총 10건). 연속 all-green 92회차.

- **311차 (2026-07-22 05:02)** — §3.8.1 raw VALID (status=200, items[0..4]=['1073','1072','1071','1070','1069'], 8개 쿠키) + §3.5 신호 4 FAKE_PUBLISH 발동 (state.last=#1073, details[-1]=#1073 동일 slot, daily_counts[2026-07-22]={AI/ML:5} ≥ 2) → **5-5 proxy check disambiguate 14연속 확정**: #1069/#1070/#1071/#1072/#1073 모두 status=200 + og:title 정확 매칭 → 진짜 발행, 오탐 확정. 295차 정책으로 §3-a `blog_pipeline.py --category 'AI/ML'` 시도 → **`status=skip`** ("AI/ML 카테고리의 긱뉴스 주제와 트렌드 주제 모두 소진되었습니다"). **§3-B 신규 정형화 — AI/ML 후보 소진 시 다른 카테고리 fallback 워크플로우 첫 실전 검증** (311차). fallback 우선순위에 따라 `--category '개발도구'` 시도 → `status=ready` + gn=31631 "수랭식 침대를 제어하는 API 클라이언트 bedctl" 선정. **305차 단일 패스 패턴 311차 재확인 (6연속 정형화)** — `build_post_311.py` 안에 `requests.get(gn_url) + <meta property="og:description"> regex` 임베드 → 160자 description 추출 + Picsum 이미지 2장 (seed: bedctl-waterbed-control / bedctl-temperature-schedule) + 본문 2738자 빌드 → **#1074 발행 성공** (proxy status=200 + title="수랭식 침대를 제어하는 API 클라이언트 bedctl &mdash; 잘 때만 코딩하는 개발자를 위한 가이드" + og:title="수랭식 침대를 제어하는 API 클라이언트 bedctl — 잘 때만 코딩하는 개발자를 위한 가이드" 정확 매칭, OG 썸네일 `https://blog.kakaocdn.net/dna/rP5nM/dJMcadizCUH/...` 정상 설정). §3.11 5-2 commit_publish (stats.today={AI/ML:5, 개발도구:1}, total=68, by_category["1219746"]=1 동일 유지 — 함정 8 영구 잔존 14연속) → 5-3 last+details 통합 보정 (#1073→#1074, details_len 146→147) → 5-2-A 백필 1건 (누적 동기화, published_topics.json details_len=148) → 5-4 §3.5 신호 4 발동 (오탐 14연속) → 5-5 proxy check #1074 status=200 + og:title 정확 매칭 disambiguate 통과. **311차 신규 관찰 — 진입 시점 신호 4 + 5-5 disambiguate 트리거 2연속 확정** (310차 + 311차 모두 진입 단계 신호 4 발동 → 5-5로 직전 차 발행들 disambiguate 후 발행 단계 진입, 정상 워크플로의 일부로 정착). **함정 16 신규 (311차)** — §3-b commit_publish 카테고리 인자 타입: publish의 `--category`는 int(1219748)지만 commit의 카테고리 인자는 str("개발도구"). 두 호출의 카테고리 인자 타입이 다르다 — 혼동 시 publish는 즉시 에러 종료, commit은 stats.by_category에 새 str 키 누적. **원칙**: publish=`--category <int>`, commit=마지막 위치 인자에 `<str 카테고리명>`. **함정 회피 5중 동시 확인**: 함정 6 (heredoc + env -i SyntaxError) + 함정 7 (--category int만) + 함정 8 (by_category["1219746"]=1 영구 잔존 14연속) + 함정 11 (execute_code cron 차단 회피) + 함정 15 (5-5 proxy check 격리 패턴 적용) 모두 311차 워크플로에서 자동 회피 성공. **함정 회피 추가**: 함정 16 (publish/commit 카테고리 인자 타입 차이) — commit_publish 인자 str("개발도구") + publish 인자 int(1219748) 모두 정확히 분리 적용. 311차 daily_counts={AI/ML:5, 개발도구:1} (총 6건). 연속 all-green 91회차.
- **312차 (2026-07-22 21:01)** — §3.8.1 raw VALID (status=200, items[0..4]=['1077','1076','1075','1074','1073'], 8개 쿠키) + §3.5 신호 4 발동 (state.last=#1077, details[-1]=#1077 동일 slot, daily_counts[2026-07-22]={AI/ML:7, 개발도구:2} ≥ 2) → **5-5 proxy check disambiguate 15연속 확정**: #1069~#1077 모두 status=200 + og:title 정확 매칭 9건 확인 → 진짜 발행, 오탐 확정. 295차 정책으로 §3-a `blog_pipeline.py --category 'AI/ML'` 시도 → **`status=ready`** (AI/ML 후보 충분, 311차 fallback 후 정상 복귀 확인). Topic **gn=31689 ("Kimi K3와 Fable 5의 작업별 라우팅", Notion 12순위, score=3.0, freshness OK)** 선정. **305차 단일 패스 패턴 312차 재확인 (7연속 정형화)** — `build_post_312.py` 안에 `requests.get(gn_url) + <meta property="og:description"> regex` 임베드 → 160자 description 추출 ("약 1,030개 에이전트 작업에서 Kimi K3와 Fable 5를 비교한 결과, 작업별 라우팅은 93% 정확도로 개별 모델보다 높은 품질을 달성함 SWE·터미널·알고리듬·다중 언어·법률 작업에서 전체 성능은 비슷했지만, 두 모델이 강점을 보이는 작업 영역은 서로 달랐음 오라클 라우팅은…") + Picsum 이미지 2장 (seed: kimi-k3-fable-routing / multi-model-orchestration) + 본문 2605자 빌드 → **#1078 발행 성공** (proxy status=200 + title="Kimi K3와 Fable 5의 작업별 라우팅 &mdash; 두 모델의 조합이 단일 최고 모델을 넘어서는 순간" + og:title="Kimi K3와 Fable 5의 작업별 라우팅 — 두 모델의 조합이 단일 최고 모델을 넘어서는 순간" 정확 매칭, OG 썸네일 `https://blog.kakaocdn.net/dna/bhk8sS/dJMcac9uSj/...` 정상 설정). §3.11 5-2 commit_publish (stats.today={AI/ML:8, 개발도구:2}, total=72, by_category["1219746"]=1 동일 유지 — 함정 8 영구 잔존 16연속) → 5-3 last+details 통합 보정 (#1077→#1078, details_len 150→151) → 5-2-A 백필 1건 (누적 동기화, published_topics.json details_len 151→152) → 5-4 §3.5 신호 4 발동 (오탐 16연속) → 5-5 proxy check #1078 status=200 + og:title 정확 매칭 disambiguate 통과. **신호 4 오탐 disambiguate 16연속 확정** (298→312) — 정상 워크플로의 일부로 완전히 정착. **312차 신규 관찰 — 진입 시점 신호 4 + 5-5 disambiguate 트리거 3연속 확정** (310/311/312 모두 진입 단계 신호 4 발동 → 5-5로 직전 차 발행들 disambiguate 후 발행 단계 진입). **311차 fallback 패턴 후 정상 publish 복귀 확인**: AI/ML 후보가 다시 들어오면 §3-B fallback 없이 §3-a → §3-b → §3-b.5 정상 진행. **함정 회피 5중 동시 확인**: 함정 6 + 함정 7 + 함정 8 + 함정 11 + 함정 15 모두 312차 워크플로에서 자동 회피 성공. 312차 daily_counts={AI/ML:8, 개발도구:2} (총 10건). 연속 all-green 92회차.
- **313차 (2026-07-22 22:02)** — §3.8.1 raw VALID (status=200, content_type=application/json, cookies_count=8, first_ids=['1078','1077','1076','1075','1074']) + §3.5 신호 4 발동 (state.last=#1078, details[-1]=#1078 동일 slot, daily_counts[2026-07-22]={AI/ML:8, 개발도구:2} ≥ 2) → **5-5 proxy check disambiguate 16연속 확정**: #1074~#1078 모두 status=200 + og:title 정확 매칭 5건 확인 → 진짜 발행, 오탐 확정. 295차 정책으로 §3-a `blog_pipeline.py --category 'AI/ML'` → **`status=ready`** (AI/ML 후보 충분, 311차 fallback 후 정상 복귀 3차 연속 유지). Topic **gn=31684 ("AI 코딩 세션의 휘발성 맥락을 프로젝트 기억으로 남기기 — rhwp 적용 사례", Notion 7순위, score=7.0, freshness OK)** 선정. **305차 단일 패스 패턴 313차 재확인 (8연속 정형화)** — `build_post_313.py` 안에 `requests.get(gn_url) + <meta property="og:description"> regex` 임베드 → 160자 description 추출 + Picsum 이미지 2장 (seed: rhwp-project-memory / ai-coding-context-persistence) + 본문 3218자 빌드 → **#1079 발행 성공** (proxy status=200 + title="AI 코딩 세션의 휘발성 맥락을 프로젝트 기억으로 남기기 &mdash; rhwp 적용 사례" + og:title 정확 매칭, OG 썸네일 `https://blog.kakaocdn.net/dna/WR1zw/dJMb991xv50/...` 정상 설정). §3.11 5-2 commit_publish (stats.today={AI/ML:9, 개발도구:2}, total=73, by_category["1219746"]=1 동일 유지 — 함정 8 영구 잔존 17연속) → 5-3 last+details 통합 보정 (#1078→#1079, details_len=152) → 5-2-A 백필 1건 (누적 동기화, published_topics.json details_len 152→153) → 5-4 §3.5 신호 4 발동 (오탐 17연속) → 5-5 proxy check #1079 status=200 + og:title 정확 매칭 disambiguate 통과. **신호 4 오탐 disambiguate 17연속 확정** (298→313) — 정상 워크플로의 일부로 완전히 정착. **313차 신규 관찰 — 진입 시점 신호 4 + 5-5 disambiguate 트리거 4연속 확정** (310/311/312/313 모두 진입 단계 신호 4 발동 → 5-5로 직전 차 발행들 disambiguate 후 발행 단계 진입, 정상 워크플로의 일부). **311차 fallback 패턴 후 정상 publish 복귀 3차 연속 안정 유지**: 312차 + 313차 모두 AI/ML 후보 충분, §3-B fallback 없이 §3-a → §3-b → §3-b.5 정상 진행. **함정 회피 5중 동시 확인**: 함정 6 (heredoc + env -i SyntaxError) + 함정 7 (--category int만) + 함정 8 (by_category["1219746"]=1 영구 잔존 17연속) + 함정 11 (execute_code cron 차단 회피) + 함정 15 (5-5 proxy check 격리 패턴 적용) 모두 313차 워크플로에서 자동 회피 성공. 313차 daily_counts={AI/ML:9, 개발도구:2} (총 11건). 연속 all-green 93회차.

- **references/session-20260722-313th-rhwp-coding-memory.md** — 313차 #1079 ("AI 코딩 세션의 휘발성 맥락을 프로젝트 기억으로 남기기 — rhwp 적용 사례", gn=31684, AI/ML, score=7.0) 발행 + §3.5 신호 4 오탐 disambiguate **17연속 확정** (298→313) + **305차 단일 패스 패턴 313차 재확인 (8연속 정형화)** — `build_post_313.py` 안에 `requests.get(gn_url) + <meta property="og:description"> regex` 임베드 → 160자 description 추출 + Picsum 이미지 2장 (seed: rhwp-project-memory / ai-coding-context-persistence) + 본문 3218자 빌드 → **#1079 발행 성공** (proxy status=200 + title 정확 매칭 + og:title 정확 매칭, OG 썸네일 `https://blog.kakaocdn.net/dna/WR1zw/dJMb991xv50/...` 정상 설정). §3.11 5-2 commit_publish (stats.today={AI/ML:9, 개발도구:2}, total=73, by_category["1219746"]=1 동일 유지 — 함정 8 영구 잔존 17연속) → 5-3 last+details 통합 보정 (#1078→#1079, details_len 152) → 5-2-A 백필 1건 (누적 동기화, published_topics.json details_len 152→153) → 5-4 §3.5 신호 4 발동 (오탐 17연속) → 5-5 proxy check #1079 status=200 + og:title 정확 매칭 disambiguate 통과. **신호 4 오탐 disambiguate 17연속 확정** (298→313) — 정상 워크플로의 일부로 완전히 정착. **313차 신규 관찰 — 진입 시점 신호 4 + 5-5 disambiguate 트리거 4연속 확정** (310/311/312/313 모두 진입 단계 신호 4 발동 → 5-5로 직전 차 발행들 disambiguate 후 발행 단계 진입). **311차 fallback 패턴 후 정상 publish 복귀 3차 연속 유지** — 312차 + 313차 모두 AI/ML 후보 충분, §3-B fallback 없이 정상 진행. **함정 회피 5중 동시 확인**: 함정 6 + 함정 7 + 함정 8 + 함정 11 + 함정 15 모두 313차 워크플로에서 자동 회피 성공. 313차 daily_counts={AI/ML:9, 개발도구:2} (총 11건). 연속 all-green 93회차.
- **references/session-20260722-314th-ai-prosperity-volition.md** — 314차 #1080 ("AI 시대에 번영할 사람들 — volition이 지능을 대체하는 시대, 개발자가 살아남는 법", gn=31683, AI/ML, score=3.0) 발행 + §3.5 신호 4 오탐 disambiguate **18연속 확정** (298→314) + **305차 단일 패스 패턴 314차 재확인 (9연속 정형화)** — `build_post_314.py` 안에 `requests.get(gn_url) + <meta property="og:description"> regex` 임베드 → 159자 description 추출 + Picsum 이미지 2장 (seed: ai-prosperity-volition / ai-era-cognitive-economy) + 본문 2583자 빌드 → **#1080 발행 성공** (proxy status=200 + title="AI 시대에 번영할 사람들 &mdash; volition이 지능을 대체하는 시대, 개발자가 살아남는 법" + og:title 정확 매칭, OG 썸네일 `https://blog.kakaocdn.net/dna/bs081a/dJMb991xw3u/AAAAAAAAAAA...` 정상 설정). §3.11 5-2 commit_publish (stats.today={AI/ML:10, 개발도구:2}, total=74, by_category["1219746"]=1 동일 유지 — 함정 8 영구 잔존 18연속) → 5-3 last+details 통합 보정 (#1079→#1080, details_len 152→153) → 5-2-A 백필 1건 (누적 동기화, published_topics.json details_len 153→154) → 5-4 §3.5 신호 4 발동 (오탐 18연속) → 5-5 proxy check #1080 + #1077~#1079 모두 status=200 + og:title 정확 매칭 4건 disambiguate 통과. **신호 4 오탐 disambiguate 18연속 확정** (298→314) — 정상 워크플로의 일부로 완전히 정착. **314차 신규 관찰 — 진입 시점 신호 4 + 5-5 disambiguate 트리거 5연속 확정** (310/311/312/313/314 모두 진입 단계 신호 4 발동 → 5-5로 직전 차 발행들 disambiguate 후 발행 단계 진입, 정상 워크플로의 일부). **311차 fallback 패턴 후 정상 publish 복귀 4차 연속 안정 유지**: 311차(개발도구 fallback), 312차(AI/ML 복귀), 313차(AI/ML), 314차(AI/ML) 모두 정상. fallback은 진짜 일회성 패턴이 아니라 안정 운영 상태의 일부로 정착. **함정 회피 5중 동시 확인**: 함정 6 (heredoc + env -i SyntaxError) + 함정 7 (--category int만) + 함정 8 (by_category["1219746"]=1 영구 잔존 18연속) + 함정 11 (execute_code cron 차단 회피) + 함정 15 (5-5 proxy check 격리 패턴 적용) 모두 314차 워크플로에서 자동 회피 성공. 314차 daily_counts={AI/ML:10, 개발도구:2} (총 12건). 연속 all-green 94회차.
- **references/session-20260723-315th-linux-kernel-cve-432.md** — 315차 #1085 ("지난 24시간 동안 공개된 Linux 커널 CVE 432건 — 개발자가 우선 대응해야 할 취약점 분류", gn=31677, 개발도구) 발행 + §3.5 신호 4 오탐 disambiguate **20연속 확정** (298→315) + **305차 단일 패스 패턴 315차 재확인 (11연속 정형화)** — `build_post_315.py` 안에 `requests.get(gn_url) + <meta property="og:description"> regex` 임베드 → 160자 description 추출 + Picsum 이미지 2장 (seed: linux-kernel-cve-432 / cve-vulnerability-tracker) + 본문 4112자 빌드 → **#1085 발행 성공** (proxy status=200 + title="지난 24시간 동안 공개된 Linux 커널 CVE 432건 &mdash; 개발자가 우선 대응해야 할 취약점 분류" + og:title 정확 매칭, OG 썸네일 `https://blog.kakaocdn.net/dna/tHFvx/dJMcahSG6zJ/AAAAAAAAAAAA...` 정상 설정). §3.11 5-2 commit_publish (stats.today={AI/ML:4, 개발도구:1}, total=79, by_category["1219746"]=1 동일 유지 — 함정 8 영구 잔존 19연속) → 5-3 last+details 통합 보정 (#1084→#1085, details_len 158) → 5-2-A 백필 1건 (누적 동기화, published_topics.json details_len=159) → 5-4 §3.5 신호 4 발동 (오탐 20연속) → 5-5 proxy check #1084 + #1085 모두 status=200 + og:title 정확 매칭 2건 disambiguate 통과. **신호 4 오탐 disambiguate 20연속 확정** (298→315) — 정상 워크플로의 일부로 완전히 정착. **315차 신규 관찰 — 진입 시점 신호 4 + 5-5 disambiguate 트리거 6연속 확정** (310/311/312/313/314/315 모두 진입 단계 신호 4 발동 → 5-5로 직전 차 발행들 disambiguate 후 발행 단계 진입, 정상 워크플로의 일부). **311차 fallback 패턴 후 정상 publish 복귀 5차 연속 안정 유지**: 311차(개발도구 fallback), 312차(AI/ML 복귀), 313차(AI/ML), 314차(AI/ML), 315차(개발도구 fallback 재발) 모두 정상. **fallback은 안정 운영 상태의 일부로 정착** — AI/ML 후보 소진이 일시적이지 않고 주기적으로 반복되는 운영 패턴임을 확인. cron은 일자 단위 다중 발행 누적 상태(315차 진입 시 daily_counts={AI/ML:4})에서도 §3-B fallback → §3-b publish → §3-b.5 commit → 5-3 → 5-2-A → 5-4 → 5-5 정형 시퀀스 동일하게 적용 가능. **315차 신규 관찰 — 긱뉴스 본문이 Anubis 봇방지로 가려진 케이스 (31677)**: 긱뉴스 `https://news.hada.io/topic?id=31677` OG description 첫 80자가 "Hacker News 제목에 따르면 ... 공지 페이지는 대규모 웹 수집으로 인한 서버 중단과 자원 접근 제한을 막기 위해 Anubis 봇 방지 절차를 적용함 Hashcash…" 형태로 봇방지/Hashcash 안내가 prefix로 포함됨. description 추출 자체는 정상 동작하나 도입부 가공 시 "Anubis 봇방지 안내" 문구를 자연스럽게 다듬어야 함 (또는 첫 문장 그대로 노출). 향후 긱뉴스 트래픽 폭주 시 동일 패턴 가능 — 단일 패스 패턴(`build_post_XXX.py` 안에서 regex로 OG description 임베드)은 영향 없이 동작. **함정 회피 5중 동시 확인**: 함정 6 (heredoc + env -i SyntaxError) + 함정 7 (--category int만) + 함정 8 (by_category["1219746"]=1 영구 잔존 19연속) + 함정 11 (execute_code cron 차단 회피) + 함정 15 (5-5 proxy check 격리 패턴 적용) 모두 315차 워크플로에서 자동 회피 성공. 315차 daily_counts={AI/ML:4, 개발도구:1} (총 5건). 연속 all-green 95회차.
 - **references/session-20260723-316th-bento-singlefile-office.md** — 316차 #1089 ("Bento - 파일 하나에 모두 들어가는 오피스 스위트 — 단일 HTML 파일 오피스의 현 주소", gn=31704, AI/ML) 발행 + §3.5 신호 4 오탐 disambiguate **21연속 확정** (298→316) + **305차 단일 패스 패턴 316차 재확인 (12연속 정형화)** — `build_post_316.py` 안에 `requests.get(gn_url) + <meta property="og:description"> regex` 임베드 → 160자 description 추출 ("문서/편집기/뷰어/발표 도구를 하나의 .bento.html 파일에 담아, 브라우저만 있으면 열고 편집하고 발표할 수 있는 PowerPoint 대체제 약 570KB 파일 하나가 완전한 애플리케이션으로 동작하며, 계정/클라우드/설치 프로그램 없이 저장하고 이메일이나 AirDrop으로 전달…") + Picsum 이미지 2장 (seed: bento-office-singlefile / bento-all-in-one-document) + 본문 2741자 빌드 → **#1089 발행 성공** (proxy status=200 + title="Bento - 파일 하나에 모두 들어가는 오피스 스위트 &mdash; 단일 HTML 파일 오피스의 현 주소" + og:title 정확 매칭, OG 썸네일 `https://blog.kakaocdn.net/dna/Z6Ccu/dJMcacYe12W/AAAAAAAAAAAA...` 정상 설정). §3.11 5-2 commit_publish (stats.today={AI/ML:8, 개발도구:1}, total=85, by_category["1219746"]=1 동일 유지 — 함정 8 영구 잔존 20연속) → 5-3 last+details 통합 보정 (#1088→#1089, details_len 161→162) → 5-2-A 백필 1건 (누적 동기화, published_topics.json details_len=163) → 5-4 §3.5 신호 4 발동 (오탐 21연속) → 5-5 proxy check #1089 + #1088/#1087/#1086/#1085 모두 status=200 + og:title 정확 매칭 5건 disambiguate 통과. **신호 4 오탐 disambiguate 21연속 확정** (298→316) — 정상 워크플로의 일부로 완전히 정착. **316차 신규 관찰 — 진입 시점 신호 4 + 5-5 disambiguate 트리거 7연속 확정** (310/311/312/313/314/315/316 모두 진입 단계 신호 4 발동 → 5-5로 직전 차 발행들 disambiguate 후 발행 단계 진입). **311차 fallback 패턴 후 정상 publish 복귀 6차 연속 안정 유지**: 311차(개발도구 fallback), 312차(AI/ML 복귀), 313차(AI/ML), 314차(AI/ML), 315차(개발도구 fallback 재발), 316차(AI/ML 복귀) 모두 정상. fallback은 진짜 일회성이 아니라 안정 운영 상태의 일부로 정착 (AI/ML 후보 소진이 주기적으로 반복되는 운영 패턴). **함정 회피 5중 동시 확인**: 함정 6 (heredoc + env -i SyntaxError) + 함정 7 (--category int만) + 함정 11 (execute_code cron 차단 회피) + 함정 14 (import os 누락) + 함정 15 (5-5 proxy check 격리 패턴 적용) 모두 316차 워크플로에서 자동 회피 성공. **316차 관찰 — 진입 시점 5-5가 직전 차 4건(#1088/#1087/#1086/#1085) 모두 disambiguate**: daily_counts={AI/ML:7, 개발도구:1} 합계 8 상태에서 진입 시 신호 4 발동 → 5-5에서 직전 차 4건 모두 status=200+og:title 정확 매칭 확인 후 발행 단계 진입. cron은 직전 차 누적량과 무관하게 동일 패턴으로 처리 가능. 316차 daily_counts={AI/ML:8, 개발도구:1} (총 9건). 연속 all-green 96회차.

 ### 신호 4 disambiguate 24연속 확정 패턴 (319차 갱신 — 정형화)

§3.5 신호 4(FAKE_PUBLISH)가 발동했을 때 진짜 가짜 발행인지 오탐인지 구분하는 절차. 298→299→300→301→302→303→304→305→306→307→308→309→310→311→312→313→314→315→316→317→318→**319**차 24연속 동일 패턴으로 **정형 운영 패턴**으로 확정:

| 조건 | 판정 | 다음 액션 |
|------|------|----------|
| details[-1].url == last_published_url **AND** slot이 어제 stale 슬롯(예: #1043) | **진짜 FAKE_PUBLISH** | publish skip, stats 추가 박기 금지 |
| details[-1].url == last_published_url **AND** slot이 오늘 발행 슬롯(예: #1060) | **오탐 가능성** (298~306차 패턴) | **proxy check 의무** (5-5): #NNN status=200 + og:title 매칭 → 진짜 발행 확인 → publish 진행 |
| details[-1].url == last_published_url **AND** proxy 404 | **진짜 FAKE_PUBLISH** | publish skip |

**핵심**: 5-3에서 details append + last 두 필드를 같은 슬롯(#NNN)으로 동시에 갱신하면 `details[-1].slot == last_url.slot`이 무조건 성립 → 신호 4가 무조건 발동함. 이게 298~314차 오탐의 구조적 원인. proxy check로 disambiguate하는 것이 정형 운영 패턴. **20연속 cron은 매 차 proxy check 결과를 보고 라인에 명시**해야 운영자가 오탐/진짜를 즉시 구분 가능 — 304차부터는 "정상 워크플로의 일부"로 정착, drift 라인에 따로 명시하지 않아도 됨.

**중요**: 5-2-A 백필로 published_topics.json을 보정해도 5-3과 §3.5의 평가 순서 자체는 바뀌지 않음. 즉 매 차 §3.5 신호 4 발동 + proxy check PASS는 정상 워크플로우의 일부로 정착. 305차 #1056도 동일 패턴으로 정상 발행 확인.

**305차 본문 빌드 단일 패스 패턴 (긱뉴스 OG description 임베드)**: `build_post_XXX.py` 안에 `requests.get(gn_url) + og:description regex` 임베드 → 본문에 description 직접 박는 단일 패스. 304차의 "본문 빌드 + 이미지 업로드 단일 패스"를 긱뉴스 description 추출까지 확장한 변형. 함정 3 (긱뉴스 본문 selector 코멘트만 잡힘) + 함정 6 (heredoc + env -i SyntaxError) + 함정 11 (`execute_code` cron 차단) 3중 동시 회피.

## 🆘 가짜 발행 누적 감지 패턴 (289차 신규)

`check_state_consistency.py` 신호 4로 자동화됨 — cron 발행 워크플로우에서 exit code 1을 받으면 단순 skip:

- **트리거**: `daily_counts[오늘]` 합계 ≥ 2 **AND** `details[-1].url` == `last_published_url` (실제 새 글 0건)
- **판단**: stats는 박혔으나 Tistory 측 신규 글이 없음 = 직전 세션 가짜 발행 잔재
- **액션**: publish 단계 추가 진행 금지 (오염 가중). daily_counts 임의 보정은 SSOT 변경이므로 **사용자 확인 후에만** 수행.

## ✅ check_state_consistency.py 3.9 호환 (289차 패치 완료)

PEP 604 union (`str | None`, `int | None`) → `Optional[str]`, `Optional[int]` 변환으로 `/usr/bin/python3` (3.9)에서 정상 실행. 더 이상 inline 우회 불필요.

신호 4 추가로 drift 시나리오 커버리지 확장:
1. last_published_url ↔ last_topics[-1].url 불일치
2. last_url 있는데 daily_counts[오늘] = 0
3. 비정상 슬롯 (≤ 0)
4. **daily_counts[오늘] ≥ 2 + details[-1] 슬롯 변동 없음 (FAKE_PUBLISH)** ← 289차 신규