---
name: tistory-publisher
description: "Tistory 블로그 자동 발행 — 쿠키 기반 내부 API를 사용하여 글 작성/발행 (v2.7.127, 281st claude-secret-leak)"
version: "v2.7.127"
last_updated: "2026-07-17-281st-claude-secret-leak"
---
# Tistory Publisher Skill (v2.7.124)

> **본문은 최근 4~5차 핵심 발견 + cleanup cron 임무 상태만 유지**. 270차 이전 stable 운영 가이드는 reference로 분리.
> **2026-07-17 (280차)**: **green-run confirmation + §3.34 #21 정책 실전 7호** — **`#1027 OpenAI, EU 법원 상표권 분쟁에서 패소 — GPT는 일반 명사가 아니다`** (AI/ML/1219746, gn=31484, 9점, FRESH 1순위) 정상 발행. 연속 all-green **67회차 (213~280차)**. §3.34.40 v2 FRESH 4-field (FRESH 7개 식별: 31492/31484/31489/31478/31467/31476/31480; AI/ML 후보 5개 → §3.34 #21 AI/ML 우선 정책으로 점수 1순위 `31484` 픽) / §3.34.46 영구화 (`_try_md_endpoint(31484)` → status=200, 4444 bytes 1단계 `.md` fetch 정상) / §3.34.50 Topic Body 마커 7회째 (본문 평문 938자, 300자 가드 통과) / §3.34.47 격리 빌드 (`/tmp/tistory_drafts_280th/build_draft_31484.py` 7008 bytes UTF-8 선언 + 격리 호출 정상) / §3.34.53 `gfc` alias 4회째 (importlib spec_from_file_location 정상) / §3.34.55 `_try_md_endpoint(tid)` 단일 변수 할당 2회째 (279차 31496 + 280차 31484 = 21074/4444 bytes 모두 정상 fetch) / §3.34.54 `> ` blockquote 6번째 패턴 (이번 본문엔 `>` 라인 없어 미적용, 분기는 코드에 박혀있어 안전 가드 포함) / §3.5 5중 신호 5/5 `#1027` 일치 (`all_match: True`) / §3.34.52 IME 가드 (title ASCII 토큰 `AI`, `OpenAI`, `GPT` sanity check 통과 + 라이브 페이지 `<title>` cross-check 정상) / daily_counts[2026-07-17] = `{'AI/ML': 1}` (정확, cat_id 누설 0) / cleanup cron 임무 #16 dry-run `✅ 누설 없음` (66→**67회** 연속 all-green) / Picsum ID 982 (두 슬롯 동일) / 라이브 페이지 GET `status=200, size=62273, title tag='OpenAI, EU 법원 상표권 분쟁에서 패소 &mdash; GPT는 일반 명사가 아니다'` (실제 발행 확인). **§3.34 #21 AI/ML 우선 정책 실전 7호 (280차 검증)**: FRESH 7개 중 AI/ML 5 + 개발도구 1 + 개발팁 1 → §3.34.45 매트릭스 4번째 분기 정상 동작 확인 (255차 1호 → 266차 2호 → 268차 3호 → 269차 4호 → 270차 5호 → 271차 6호 → **280차 7호**). 본 세션 신규 발견 0건 — 모든 패턴(§3.8.1 가드 / §3.8.2 격리 / §3.11 sync / §3.34.40 v2 / §3.34.43 PWD / §3.34.46 영구화 / §3.34.47 격리 빌드 / §3.34.48 `*` 분기 / §3.34.50 Topic Body / §3.34.52 IME 가드 / §3.34.53 `gfc` alias / §3.34.54 `>` blockquote / §3.34.55 시그니처 함정 / §3.34 #21 정책 + #45 매트릭스) 정상 동작. 차감/추가 없음. 상세: `references/session-20260717-280th-openai-eu-trademark.md`.
> **2026-07-16 (279차)**: **green-run confirmation + §3.34.55 (NEW) `gfc` 시그니처 함정 2종 식별** — **`#1026 내가 Google DeepMind를 떠난 이유 — 한 연구자가 본 AI 윤리의 구조적 한계`** (AI/ML/1219746, gn=31496, 8점, FRESH AI/ML 1순위) 정상 발행. 연속 all-green 66회차 (213~279차). §3.34.40 v2 FRESH 4-field (FRESH 8개 식별: 31492/31484/31496/31489/31478/31508/31505/31504; AI/ML 후보 다수 → §3.34 #21 정책으로 점수 1순위 `31496` 픽) / §3.34.46 영구화 (`_try_md_endpoint(31496)` → status=200, 21074 bytes 1단계 `.md` fetch 정상) / §3.34.50 Topic Body 마커 7회째 (본문 평문 14695자, 300자 가드 통과, `- ` 본문 bullet 첫 줄 케이스 안전 검증) / §3.34.47 격리 빌드 (`/tmp/tistory_drafts_279th/build_draft_31496.py` 6792 bytes UTF-8 선언 + 격리 호출 정상) / §3.34.53 `gfc` alias 3회째 (importlib spec_from_file_location 정상) / §3.34.54 `> ` blockquote 5번째 패턴 (이번 본문엔 `> ` 라인 없어 미적용, 분기는 코드에 박혀있어 안전 가드 포함) / §3.5 5중 신호 5/5 `#1026` 일치 (`all_match: True`) / daily_counts[2026-07-16] = `{'AI/ML': 9, '개발도구': 2}` (AI/ML 8→9, +1 정확) / cleanup cron 임무 #16 dry-run `✅ 누설 없음` (65→**66회** 연속 all-green) / Picsum ID 851 (두 슬롯 동일) / 라이브 페이지 GET `status=200, size=100887, title tag='내가 Google DeepMind를 떠난 이유 &mdash; 한 연구자가 본 AI 윤리의 구조적 한계'` (실제 발행 확인). **§3.34.55 (NEW, 279차 식별, 즉시 보정)**: 244차 §3.34.34 가이드 + 261차 §3.34.46 박스에 적힌 두 시그니처 호출이 **279차 첫 시도에서 모두 hit**:
>   1. **`gfc.fetch_gn_content(tid)` 시그니처 함정** — SKILL.md 본문에 `fetch_gn_content(tid)` 가 `(title, content, source) tuple` 을 반환한다고 박혀있으나 (244차 §3.34.34 확인), 279차 호출에서 `TypeError: 'NoneType' object is not subscriptable` 반환 (실제 함수가 `Optional[Tuple[...]]` 으로 None 반환). **회피**: `fetch_gn_content(tid)` 단독 호출 회피. 본문 fetch는 무조건 `_try_md_endpoint(tid) -> Optional[str]` 단일 함수만 사용. (279차 1차 hit → 즉시 `_try_md_endpoint` 로 재호출하여 21074 bytes 정상 fetch).
>   2. **`gfc._try_md_endpoint(tid)` 시그니처 함정** — SKILL.md 본문에 시그니처가 `Optional[str]` (단일 문자열 반환) 라고 적혀있지만 (grep 261차 확인), 279차 두 번째 시도가 `text = gfc._try_md_endpoint(31496); status, text = ...` 형태로 적혀있었다면 `ValueError: too many values to unpack (expected 2)` 가 터질 위험. **확정**: 279차에 `_try_md_endpoint(31496)` 단일 인자 호출이 정상 작동 → `text` 가 곧 본문 문자열 (status 정보 없음, 단순 str 반환). (실제 코드 line 87: `def _try_md_endpoint(topic_id: int) -> Optional[str]:`). 본문 빌드 스니펫은 항상 단일 변수 할당만 사용. **적용 범위**: §3.34.46 본문 빌드의 모든 변형 (`build_draft_*.py` / `gn-markdown-to-tistory-html.py`). cleanup cron 임무 #35 신규 — `scripts/gn-fetch-content.py` 의 두 public 함수 시그니처를 module docstring에 명시 + SKILL.md §3.34.34 박스 코드 스니펫을 `_try_md_endpoint(tid)` 단일 호출로 통일.
>
>   단일 probe (가드 / sync / state 확인) 처럼 5~10줄짜리 short heredoc은 영향 없음. 차감/추가 없음. **본 세션 정정 — 244차 §3.34.34 "fetch_gn_content(tid)" 가드는 obsolete**: 279차 검증 결과 본문 빌드는 `_try_md_endpoint(tid)` 단일 함수만 사용 권장. 상세: `references/session-20260716-279th-deepmind-resignation.md`.
> **2026-07-16 (278차)**: **green-run confirmation + §3.34.54 (NEW) `> blockquote` 라우팅 분기 + §3.34.46 5번째 패턴 정착** — **`#1025 앤트로픽·블랙스톤이 15억 달러짜리 「구현」 회사를 차렸다 — 모델 말고 엔터프라이즈 AI 파일럿을 실제로 끝내는 Ode`** (AI/ML/1219746, gn=31490, 9점, FRESH AI/ML 1순위) 정상 발행. 연속 all-green 65회차 (213~278차). §3.34.40 v2 FRESH 4-field (FRESH 9개 식별: 31492/31490/31484/31489/31478/31467/31476/31480/31477; AI/ML 후보 다수 → §3.34 #21 정책으로 점수 1순위 `31490` 픽) / §3.34.46 영구화 (`_try_md_endpoint(31490)` 1349 bytes 1단계 `.md` fetch 정상) / §3.34.50 Topic Body 마커 6회째 (본문 평문 1279자, 300자 가드 통과) / §3.34.47 격리 빌드 (`/tmp/tistory_drafts_278th/build_draft_31490.py` 6334 bytes 격리 호출 정상) / §3.34.53 `gfc` alias 2회째 (importlib spec_from_file_location("gfc") 정상) / §3.34.52 IME 가드 (title ASCII 토큰 `AI`, `Ode` sanity check 통과 + 라이브 페이지 `<title>` cross-check 정상) / §3.5 5중 신호 5/5 `#1025` 일치 (`all_match: True`) / daily_counts[2026-07-16] = `{'AI/ML': 8, '개발도구': 2}` (AI/ML 7→8, +1 정확, cat_id 누설 0) / cleanup cron 임무 #16 64→**65회** / Picsum ID 939 (두 슬롯 동일) / 본문 평문 1279자 / 라이브 페이지 GET `status=200, size=54416, title tag='앤트로픽&middot;블랙스톤이 15억 달러짜리 「구현」 회사를 차렸다 &mdash; ... Ode'` (실제 발행 확인). **§3.34.54 (NEW, 278차 식별)**: GeekNews 본문이 `## Topic Body` 후 첫 줄이 `> Anthropic, Blackstone, Hellman & Friedman 3사가 ...` 로 시작하는 blockquote 형태인 케이스 — 260차 정착 `md_to_html` 4종 패턴(`## 헤더` / `### 헤더` / `- 리스트` / `**bold**`)은 `>` 라인을 일반 paragraph 로 떨어뜨려 `<p>&gt; ...</p>` 같은 HTML escape 결과물 생성. **회피**: `md_to_html` 에 `elif stripped.startswith(">"):` 분기 추가 → `<blockquote>` 태그 라우팅. **5번째 패턴 정착 (278차)**: 260차 4종 + 278차 `>` blockquote = 5종. **적용 범위**: §3.34.46 본문 빌드 / `gn-markdown-to-tistory-html.py` 모듈 / 후속 `build_draft_*.py` 모든 변형. 단일 probe (가드 / sync / state 확인) 처럼 5~10줄짜리 short heredoc은 영향 없음. cleanup cron 임무 #34 신규 — `gn-markdown-to-tistory-html.py` 모듈에 blockquote 분기 자동 반영 권장 (현재 빌드 스크립트 `build_draft_31490.py` 에 분기 박혀있어 후속 차엔 동일 패턴 적용). 차감/추가 없음. 상세: `references/session-20260716-278th-ode-implementation.md`.
> **2026-07-16 (277차)**: green-run confirmation + §3.34.53 (NEW, 실제 hit 없음, 사전 검증 패턴 정착)
> **2026-07-16 (276차)**: green-run confirmation + §3.34.52 (NEW) sync CLI title 인자 IME 자동 변환 오타 함정 1호 식별 — **`#1023 Codex Micro - OpenAI가 Work Louder와 만든 물리적 키보드`** (AI/ML/1219746, gn=31482, 11점). 연속 all-green 63회차. **§3.34.52 (NEW, 276차 식별)**: `post_publish_sync CLI --title "Work Louder..."` 호출시 macOS 한글 IME 활성 상태에서 `Louder` → `Lou더` 자동 변환. sync 결과 `triple_signal_match: true` 반환하지만 pt/state 3필드 모두 오타. 라이브 페이지 `<title>` 은 정상 (publish/sync 단계 title 인자 별개 전달). **회피**: (a) sync 호출 직전 `re.match(r"^[A-Za-z]+$", word)` ASCII 토큰 sanity check. (b) sync 직후 pt/state 3필드 영문 검증. (c) 라이브 페이지 `<title>` cross-check, 불일치시 json 직접 patch로 3필드 덮어쓰기. cleanup cron 임무 #32 신규 (ASCII 토큰 sanity check 자동화). 상세: `references/session-20260716-276th-codex-micro.md`.
> **2026-07-16 (274차)**: 274차 상세 — `references/session-20260716-274th-babel-tower-keeps-rising.md` 참조 (이전 차로 본문 압축). 핵심만: §3.34.50 Topic Body 마커 본문 추출 1호 실전 검증 + §3.34.51 splice backfill 가드 1호 식별 (271차 pt.details idx=109 splice 비정상). 연속 all-green 61회차.
> **271-272차**: 핵심만 — §3.34.50 Topic Body 마커 기반 본문 추출 정착 (272차 식별, 274차 1회 검증) + §3.34.51 splice backfill 가드 (273차 임시 보정 흐름, 273차 1회 검증) + §3.34.49 이미지 endpoint 함정 (`/manage/post/attach.json`, 271차 식별) + §3.34 #21 정책 실전 6호 (271차 FRESH 다수 혼재). 참조: `references/session-20260715-271st-bonsai-27b-slot-overwrite-drift.md`, `references/session-20260715-272nd-ai-hate-2026.md`. 연속 all-green 57~60회차.
> **2026-07-15 (270차)**: **green-run confirmation + §3.34 #21 AI/ML 우선 정책 실전 5호 (AI/ML FRESH 다수 정상 케이스) + 자정 사이 외부 2건 발행 drift 무해 검증** — **`#1012 Claude가 'load-bearing'을 말하지 않게 만드는 방법 — MessageDisplay 훅으로 LLM 말버릇을 인프라 차원에서 걸러내기`** (AI/ML/1219746, gn=31448, 7점, FRESH 1순위 — AI/ML 후보 중 점수 최고) 정상 발행 — §3.8.1 가드 통과 (`status=200, ct=application/json;charset=UTF-8, cookie_count=8`), §3.34.43 PWD 보강 (`PWD=/Users/mac`), §3.34.40 FRESH 4-field (TOP 12개 중 2개 자정 사이 외부 발행 31449 Codex / 31437 Precursor가 이미 PUB 처리 → FRESH 잔여 10개: AI/ML 7 + 개발도구 1 + 개발팁 2; **§3.34 #21 AI/ML 우선 정책**으로 AI/ML FRESH 7개 중 점수 1순위 `31448 (7점)` 픽), §3.34.46 영구화 (`_try_md_endpoint(31448)` 직접 호출 → status=200, 1단계 `.md` endpoint 즉시 fetch), §3.34.47 영구화 검증 7회차 (`write_file` 로 `/tmp/tistory_drafts_270th/build_draft_31448.py` UTF-8 선언 + 저장 → `python3 <script>.py` 격리 호출 정상, 6510 bytes 빌드 스크립트 무영향 — 263~269차 검증 패턴 그대로 적용), §3.34.48 `* ` 분기 + 4단계 헤더 강등 정규식 7회째 적용 (266차 정착 코드 그대로 복사 — 270차 본문은 모두 `- ` 패턴이라 hit 안 했지만 안전 가드 포함), §3.5 5중 신호 5/5 `#1012` 일치 (`triple_signal_match: true / all_match: True`), post_publish_sync `pt_updated: true / state_updated: true / errors: []`, daily_counts[2026-07-15] = `{'AI/ML': 4, '개발도구': 3, '개발팁': 1, '투자/경제': 1}` (AI/ML 3→4, +1 정확, cat_id 누설 0), state.details 88→89, pt.details 104→105 모두 박힘, cleanup cron 임무 #16 dry-run `✅ 누설 없음` (56→**57회** 연속 all-green), 이미지 2장 CDN 업로드 정상 (Picsum ID 838 자동 매칭 — 두 슬롯 모두 동일 ID, query: claude code hook message display replacement code terminal), 본문 3375자 (검증 2217자, 300자 가드 통과), 라이브 페이지 직접 GET `status=200, size=64944, title tag='Claude가 'load-bearing'을 말하지 않게 만드는 방법 &mdash; ...'` (실제 발행 확인). **연속 all-green 57회차 (213~270차)**. 가짜 발행 가드 정상. **본 세션 신규 발견 0건** — 269차 정착 패턴(§3.34.40 FRESH 4-field, §3.34.46 영구화, §3.34.47 격리 빌드, §3.34.48 `*` 분기 + 4단계 강등, §3.34 #21 정책, §3.11 sync, §3.5 5중 검증, cleanup #16) 모두 270차에 7회째 정상 동작. 264차 `#1000` → 265차 `#1002` → 266차 `#1003` → 267차 `#1004` → 268차 `#1009` → 269차 `#1010` → **270차 `#1012`** 7회 연속 동일 워크플로 정착. **§3.34 #21 정책 실전 5호 (270차 검증)**: 255차 1호 (FRESH AI/ML 1 + 기타 2 → AI/ML 픽), 266차 2호 (FRESH 모두 비-기타 비-AI/ML → 점수 1순위), 268차 3호 (FRESH 2개 모두 비-기타 비-AI/ML → 점수 1순위), 269차 4호 (FRESH 1개 단독 비-기타 비-AI/ML → 점수 1순위), **270차 5호** (FRESH 다수 AI/ML + 비-AI/ML 혼재 → AI/ML 점수 1순위 픽 — 254차 정책 확정 매트릭스 4번째 분기 "FRESH 'AI/ML' + 비-기타 혼재 → AI/ML 픽" 정상 검증). **§3.34.44 자정 사이 외부 발행 drift 무해 검증 (270차, 2호)**: 사전 검증에서 `state.last_published_url`이 `#1011` (자정 사이 외부 발행 흔적) 로 박혀있고, TOP 12개 후보 중 2개 (31449 Codex, 31437 Precursor) 가 이미 pt/state 양쪽에 정상 sync 된 상태. §3.5 5중 검증 모두 일치 유지 (`#1011` 모두 동일), FRESH 4-field 매칭이 정상 FRESH 10개를 정확히 식별. cron 차 사이 한 건 이상의 외부 발행이 일반화될 수 있음을 다시 한번 확인 (253차 식별 → 254차 1호 검증 → 270차 2호 검증). 차감/추가 없음. 모든 기존 패턴 정상 동작. 상세: `references/session-20260715-270th-load-bearing-hook.md`.
> **2026-07-15 (269차)**: green-run confirmation + §3.34 #21 정책 실전 4호 (FRESH 1개 단독 비-AI/ML 비-기타 케이스) — **`#1010 crates.io 6개월 개선 총정리`** (개발도구/1219748, gn=31417, 4점, FRESH 1순위 단독). 연속 all-green 56회차 (213~269차). §3.34.45 매트릭스 5번째 분기 단독 케이스 검증. 상세: `references/session-20260715-269th-crates-io-update.md`.
> **2026-07-15 (268차)**: green-run confirmation + FRESH 2개 비-AI/ML 케이스 + §3.34 #21 정책 실전 3호 (AI/ML FRESH=0) — **`#1009 GeekNews로 어쩌다가 취업하기`** (투자/경제/1219747, gn=31434, 5점). 연속 all-green 55회차. §3.34.45 매트릭스 5번째 분기 실전 검증. 상세: `references/session-20260715-268th-geeknews-career.md`.
> **2026-07-15 (267차)**: green-run confirmation + §3.34.47 영구화 검증 4회차 + §3.34.48 `*` 분기 4회째 — **`#1004 GhostLock, 15년간 모든 Linux 배포판에 존재한 스택 UAF`** (AI/ML/1219746, gn=31407, 4점). 연속 all-green 54회차. 4회 연속 동일 워크플로 정착. 상세: `references/session-20260715-267th-ghostlock.md`.
> **2026-07-14 (266차)**: green-run confirmation + §3.34.47 영구화 검증 3회차 + `*` 리스트 패턴 추가 식별 (§3.34.48 NEW) + §3.34 #21 정책 실전 2호 (AI/ML FRESH=0 케이스) + 모듈 import 함정 — **`#1003 Papermake - Typst 기반 PDF 문서 생성 서버`** (개발도구/1219748, gn=31432, 11점). 연속 all-green 53회차. **모듈 import 함정 (NEW, 266차)**: `import tistory_publisher.publish(...)` → `AttributeError` (CLI 인터페이스만 지원, subprocess 또는 격리 bash 패턴 사용). 상세: `references/session-20260714-266th-papermake-typst-pdf.md`.
> **2026-07-14 (265차)**: green-run confirmation + §3.34.47 영구화 두 번째 실전 검증 — **`#1002 Grok Build가 사용자 디렉터리 통째로 xAI 서버에 업로드`** (AI/ML/1219746, gn=31424, 6점). 연속 all-green 52회차. 264차 동일 워크플로 반복 적용 OK 확인. 상세: `references/session-20260714-265th-grok-build-upload.md`.
> **2026-07-14 (264차)**: **green-run confirmation + #1000 마일스톤 + §3.34.47 영구화 실전 검증** — **`#1000 Brain-AI Memory — 장기 실행 LLM 에이전트의 메모리 실패를 retrieval이 아닌 component lifecycle으로 진단하는 오픈 아키텍처`** (AI/ML/1219746, gn=31435, 13점, FRESH 1순위) 정상 발행 — §3.8.1 가드 통과 (`status=200, ct=application/json;charset=UTF-8, cookie_count=8`), §3.34.43 PWD 보강 (`PWD=/Users/mac`), §3.34.40 FRESH 4-field (TOP 12개 중 3개 259~263차 PUB 처리: 31404/31397/31411 → FRESH 잔여 9개 모두 AI/ML; §3.34 #21 AI/ML 우선 정책 + §3.34.39 후보 직접 점수 pick으로 13점 `31435` 픽, §3.34.45 '기타' 제외 정책은 FRESH에 '기타' 0개로 무효), §3.34.46 영구화 (`fetch_gn_content(31435)` → status=200, 1907 bytes 1단계 `.md` endpoint 즉시 fetch), §3.34.47 영구화 실전 검증 (`write_file` 로 `/tmp/tistory_drafts_264th/build_draft.py` UTF-8 선언 + 저장 → `python3 <script>.py` 격리 호출 정상, inline heredoc 회피), §3.5 5중 신호 5/5 `#1000` 일치 (`triple_signal_match: true / all_match: True`), post_publish_sync `pt_updated: true / state_updated: true / errors: []`, daily_counts[2026-07-14] = `{'AI/ML': 8}` (7→8, +1 정확, cat_id 누설 0), state.details 76→77, pt.details 92→93 모두 박힘, cleanup cron 임무 #16 dry-run `✅ 누설 없음` (49→**50회** 연속 all-green), 이미지 2장 CDN 업로드 정상 (query: ai agent memory brain architecture diagram neural, Picsum ID 809), 본문 3573자 (300자 가드 통과), 라이브 페이지 직접 GET `status=200, size=61832, title tag='Brain-AI Memory &mdash; ...'` (실제 발행 확인). **`#1000` 1000번째 글 마일스톤 + 연속 all-green 51회차 (213~264차)**. 가짜 발행 가드 정상. §3.34.46 + §3.34.47 영구화 모두 실전 검증 완료. 본 세션 신규 발견 없음 — 모든 기존 패턴 정상 동작. 차감/추가 없음. 상세: `references/session-20260714-264th-brain-ai-memory-1000th.md`.
> **2026-07-14 (263차)**: **green-run confirmation + §3.34.47 신규 함정 식별 (UTF-8 한글 heredoc + f-string 제약)** — **`#999 2026년에 왜 코드를 작성하는가 — AI 에이전트 시대에도 코드를 만져야 하는 5가지 이유`** (AI/ML/1219746, gn=31411, 9점, FRESH 1순위 — AI/ML 후보 중 점수 최고) 정상 발행 — §3.8.1 가드 통과 (`status=200, ct=application/json;charset=UTF-8, cookie_count=8`), §3.34.43 PWD 보강 (`PWD=/Users/mac`), §3.34.40 FRESH 4-field (TOP 12개 중 2개 261~262차 PUB 처리: 31404/31397 → FRESH 잔여 10개 식별: 개발도구 3 + AI/ML 4 + 개발팁 1 + 투자/경제 1 + 개발도구 1; §3.34 #21 AI/ML 우선 정책으로 AI/ML FRESH 4개 중 점수 1순위 `31411` 픽), §3.34.46 영구화 (`fetch_gn_content(31411)` → status=200, **10273 bytes** 1단계 `.md` endpoint 즉시 fetch), §3.5 5중 신호 5/5 `#999` 일치 (`triple_signal_match: true`), post_publish_sync `pt_updated: true / state_updated: true / errors: []`, daily_counts[2026-07-14] = `{'AI/ML': 7}` (6→7, +1 정확, cat_id 누설 0), state.details 75→76, pt.details 91→92 모두 박힘, cleanup cron 임무 #16 dry-run `✅ 누설 없음` (48→**49회** 연속 all-green), 이미지 2장 CDN 업로드 정상 (query: software engineer code editor terminal abstract factory, Picsum ID 782), 본문 검증 3311자 (300자 가드 통과), 라이브 페이지 직접 GET `status=200, size=57991, title tag='2026년에 왜 코드를 작성하는가 &mdash; ...'` (실제 발행 확인). **연속 all-green 50회차 (213~263차)**. 가짜 발행 가드 정상. **§3.34.47 (NEW, 263차 식별)**: `/usr/bin/python3` heredoc 안에서 `f"... {var.split(\" \",1)[1]} ..."` 처럼 §3.34.41 f-string 제약 + escaped quote 가 동시에 들어가고 본문 문자열이 한글 UTF-8이면 `SyntaxError: f-string expression part cannot include a backslash` 가 아니라 **`SyntaxError: Non-UTF-8 code starting with '\xec'`** 가 먼저 터짐 — bash heredoc body 인코딩과 Python source encoding 선언이 충돌. 263차 첫 시도에서 hit (`# -*- coding: utf-8 -*-` 미선언 inline heredoc + 한글 HTML 본문). **회피**: 길이가 30줄이 넘어가는 본문 빌드/HTML 변환 스크립트는 inline heredoc에 적지 말고 `write_file` 로 `/tmp/<session>/build_draft.py` 에 UTF-8 선언과 함께 저장 → `python3 <script>.py` 로 격리 호출. **적용 범위**: §3.34.46 본문 빌드 / 다중 카테고리 한도 처리 / 인트로+본문+결론 합치기 등 heredoc 본문이 길어지는 모든 변형. 단일 probe (가드 / sync / state 확인) 처럼 5~10줄짜리 short heredoc은 §3.34.41 정정 (string concat) 으로 충분. 차감/추가 없음. 모든 기존 패턴 정상 동작. 상세: `references/session-20260714-263rd-coding-still-worth-writing.md`.
>
> **2026-07-14 (262차)**: **green-run confirmation + §3.34.46 HTML 변환 들여쓰기/위장-헤더 함정 보완 (262차 식별)** — **`#998 프로덕션 AI 에이전트를 GPT-5.6으로 전환해 2.2배 빠르고 27% 저렴해진 과정 — 모델이 아니라 인프라 가정을 갈아끼워야 하는 이유`** (AI/ML/1219746, gn=31404, 16점, FRESH 1순위) 정상 발행 — §3.8.1 가드 통과 (`status=200, ct=application/json;charset=UTF-8, cookie_count=8`), §3.34.43 PWD 보강 (`PWD=/Users/mac`), §3.34.40 FRESH 4-field (TOP 12개 중 10개 이미 254~261차 PUB 처리 → FRESH 잔여 2개 모두 AI/ML: 31404/31367; §3.34.39 후보 직접 점수 pick으로 16점 `31404` 픽, #21 AI/ML 우선 정책 정상 동작), §3.34.46 영구화 (`_try_md_endpoint(31404)` 직접 호출 → status=200, **13506 bytes** 1단계 `.md` endpoint 즉시 fetch), §3.5 5중 신호 5/5 `#998` 일치 (`triple_signal_match: true`), post_publish_sync `pt_updated: true / state_updated: true / errors: []`, daily_counts[2026-07-14] = `{'AI/ML': 6}` (5→6, +1 정확, cat_id 누설 0), state.details 73→74, pt.details 89→90 모두 박힘, cleanup cron 임무 #16 dry-run `✅ 누설 없음` (47→**48회** 연속 all-green), 이미지 2장 CDN 업로드 정상 (query: ai agent gpt model migration cloud infrastructure code editor, Picsum ID 263), 본문 7341자 (검증 7151자, 300자 가드 통과), 라이브 페이지 직접 GET `status=200, size=66940, title tag='프로덕션 AI 에이전트를 GPT-5.6으로 전환해 2.2배 빠르고 27% 저렴해진 과정 &mdash; ...'` (실제 발행 확인). **연속 all-green 49회차 (213~262차)**. 가짜 발행 가드 정상. **§3.34.46 HTML 변환 들여쓰기/위장-헤더 함정 (NEW, 262차 식별, 즉시 보완)**: 260차 정착 "4가지 패턴만 다루면 됨" 가이드가 **들여쓬 sub-list + `- ## 헤더` 위장 항목** 두 케이스에서 깨짐을 262차 첫 시도에서 hit. (a) **들여쓰기 nested ul 함정** — GeekNews 본문에 `  - hero 영역이 화면 전체 폭을 채우는 사진 장면인지 검사함` 같은 indented sub-list 가 흔함. 2-space indent = 1 level 로 nested `<ul><ul><li>` 변환하려 했더니 md가 pseudo-nested (모든 `- ` 이 동등 top-level) 일 때 매 항목마다 `<ul>` 가 열리고 즉시 닫혀 시각적 리스트 미형성 → **회피**: indent 무시하고 모든 `- ` 를 top-level bullet로 취급, 연속된 `- ` 라인을 하나의 `<ul>...</ul>` 로 묶고 빈 줄에서만 close. (b) **`- ## 헤더` 위장 항목** — `- ## 기존 모델의 호출 방식에 맞춰진 제약` 같은 list-prefixed header 가 `<li>` 로 변환되면 의미 파괴 → **회피**: `- ` 변환 직전 item_text가 `## `/`### ` 로 시작하면 `<h2>`/`<h3>` 로 라우팅. 262차에 두 함정 모두 회피한 개선된 `md_to_html` 정착 (위 §3.34.46 박스의 정정 코드블록). 모든 기존 패턴 정상 동작. 차감/추가 없음. 상세: `references/session-20260714-262nd-gpt56-migration.md`.
>
> **2026-07-14 (261차)**: **green-run confirmation + §3.34.46 영구화 패치 (#23) 완료** — **`#996 LLM은 사랑하지만 과대광고는 싫다 — geohot이 본 AI 가치 포획의 진짜 승자`** (AI/ML/1219746, gn=31378, 7점, FRESH 1순위) 정상 발행 — §3.8.1 가드 통과 (`status=200, ct=application/json;charset=UTF-8, cookie_count=8`), §3.34.43 PWD 보강, §3.34.40 FRESH 4-field (TOP 12개 중 8개 254~260차 PUB 처리 → FRESH 잔여 4개 모두 AI/ML: 31378/31375/31367/31389; §3.34.39 후보 직접 점수 pick으로 31378 1순위, #21 AI/ML 우선 정책 정상 동작), §3.34.46 영구화 (`GN_MD_URL = GN_TOPIC_BASE + "/{tid}.md"` + `GN_TOPIC_BASE` 정의 순서 정정 + `_try_md_endpoint` docstring 갱신 → `_try_md_endpoint(31378)` 테스트 정상 fetch 9590 bytes, 1단계 `.md` endpoint 즉시 성공), §3.5 5중 신호 5/5 `#996` 일치 (`triple_signal_match: true`), post_publish_sync `pt_updated: true / state_updated: true / errors: []`, daily_counts[2026-07-14] = `{'AI/ML': 4}` (3→4, +1 정확, cat_id 누설 0), state.details 72→73, pt.details 88→89 모두 박힘, cleanup cron 임무 #16 dry-run `✅ 누설 없음` (46→47회 연속 all-green), cleanup cron 임무 #23 영구화 완료 (✅ 패치 적용 + 1단계 `.md` endpoint 즉시 fetch 검증), 이미지 2장 CDN 업로드 정상 (query: llm coding ai hype bubble skeptic, Picsum 자동 매칭 ID 365/68), 본문 7069자 (300자 가드 통과, 검증 통과 2429자), 라이브 페이지 직접 GET `status=200, size=65252, title tag='LLM은 사랑하지만 과대광고는 싫다 &mdash; ...'` (실제 발행 확인). **연속 all-green 48회차 (213~261차)**. 가짜 발행 가드 정상. **사소한 관찰**: state.details[-1] 가 `#995 GPT-5.6-Sol` (gn=31390, 자정 사이 외부 발행 흔적) 인 상태에서 cron 261차 시작 → §3.5 5중 검증으로 drift 무해 확인 후 정상 진행. daily_counts[2026-07-14]['AI/ML'] = 3 (260차 SKILL.md엔 2였으나 사후 1건 추가 발행됨). 모든 기존 패턴 정상 동작. 차감/추가 없음. 상세: `references/session-20260714-261st-llm-hype.md`.
>
> **2026-07-14 (260차)**: **green-run confirmation + §3.34.46 임시 우회 실전 검증 + 본문 변환 패턴 정착** — **`#994 AI 에이전트가 새로운 SaaS다 — "제품이 곧 업무"로 가는 a16z의 프레임`** (AI/ML/1219746, gn=31376) 정상 발행 — §3.8.1 가드 통과 (`status=200, ct=application/json;charset=UTF-8, cookie_count=8`), §3.34.43 PWD 보강 (`PWD=/Users/mac`), §3.34.40 FRESH 4-field (TOP 12개 중 6개 254~259차 PUB 처리 → FRESH 잔여 6개: 31376/31390/31378/31375/31367/31389 모두 AI/ML; §3.34.39 후보 직접 점수 pick으로 31376 1순위), §3.34.46 임시 우회 (`requests.get("https://news.hada.io/topic/31376.md")` 직접 호출, status=200, 8952 bytes, 본문 8300자) 정상 fetch, §3.5 5중 신호 5/5 `#994` 일치 (사전 `#993` → 사후 `#994` 모두 검증, `triple_signal_match: true`), post_publish_sync `pt_updated: true / state_updated: true / errors: []`, daily_counts[2026-07-14] = `{'AI/ML': 2}` (1→2, +1 정확, cat_id 누설 0), state.details 70→71, pt.details 86→87 모두 박힘, cleanup cron 임무 #16 dry-run `✅ 누설 없음` (45→46회 연속 all-green), 이미지 2장 CDN 업로드 정상 (query: ai agent saas call center restaurant workflow, Picsum 자동 매칭 ID 764/776), 본문 11411자 (300자 가드 통과), 라이브 페이지 직접 GET `status=200, size=71020, title tag='AI 에이전트가 새로운 SaaS다 &mdash; ...'` (실제 발행 확인). **연속 all-green 47회차 (213~260차)**. 가짜 발행 가드 정상. **§3.34.46 임시 우회 실전 검증 (260차 재확인)**: `scripts/gn-fetch-content.py`의 `GN_MD_URL = "https://news.hada.io/topic.md?id={tid}"` 가 여전히 stale 이지만, 260차에 `requests.get("https://news.hada.io/topic/{tid}.md")` 직접 호출 패턴으로 정상 본문 fetch 확인 (status=200, 8952 bytes; 259차엔 1251 bytes 였는데 31376은 본문이 더 길어서 8배). **영구화 패치 (#23 cleanup cron 임무)는 미적용 상태 유지** — 다음 차에 `GN_MD_URL = f"{GN_TOPIC_BASE}/{tid}.md"` 1줄 정정 시 본문 fetch가 1단계 `.md`에서 즉시 성공. **본문 변환 패턴 정착 (260차 NEW)**: GeekNews 마크다운을 Tistory HTML로 변환할 때 `## 헤더` / `### 헤더` / `- 리스트` / `**bold**` 4가지 패턴만 다루면 됨. 변환 알고리즘: 헤더는 `<h2>`/`<h3>`, `- ` 시작은 `<ul><li>` with `</ul>` close, 빈 줄은 리스트 close 트리거, `**bold**`는 `<strong>`. 본문 끝에 editorial 인트로 (Tistory 독자층 맞춤 한국어 1~2 단락) + 결론 ("한국 시장에서의 시사점" 1~2 단락 + 원문 링크) 추가하면 300자 가드 통과 + 발행 가독성 확보. 260차 11411자 (intro 540 + 본문 8300 + 결론 1700 + 마지막 단락). 차감/추가 없음. 모든 기존 패턴 정상 동작. 상세: `references/session-20260714-260th-ai-agent-saas.md`.
>
> **2026-07-14 (259차)**: **green-run confirmation + §3.34.46 gn-fetch-content URL stale** — **`#993 만든 SaaS를 AI에게 말만 하면 등록되는 MCP 서버 — saaskr.com이 등록 폼을 MCP로 열었다`** (AI/ML/1219746, gn=31397, 10점, FRESH 1순위) 정상 발행 — §3.8.1 가드 통과 (`status=200, ct=application/json;charset=UTF-8, cookie_count=8`), §3.34.43 PWD 보강 (`PWD=/Users/mac`), §3.34.40 FRESH 4-field (TOP 12개 후보 5개 PUB 처리: 31370/31373/31387/31381/31374 → FRESH 잔여 7개 모두 AI/ML: 31397/31376/31390/31378/31375/31367/31389), §3.5 5중 신호 5/5 `#993` 일치 (사전 `#992` → 사후 `#993` 모두 검증, `triple_signal_match: true`), post_publish_sync `pt_updated: true / state_updated: true / errors: []`, daily_counts[2026-07-14] = `{'AI/ML': 1}` ({}→{AI/ML:1}, +1 정확, cat_id 누설 0), state.details 69→70, pt.details 85→86 모두 박힘, cleanup cron 임무 #16 dry-run `✅ 누설 없음` (44→45회 연속 all-green), 이미지 2장 CDN 업로드 정상 (query: ai assistant chat message registration form submission, Picsum 자동 매칭 ID 62), 본문 1165자 (300자 가드 통과), 라이브 페이지 직접 GET `status=200, size=53699` (실제 발행 확인). **연속 all-green 45회차 (213~259차)**. 가짜 발행 가드 정상. **§3.34.46 (NEW, 259차 식별)**: **`scripts/gn-fetch-content.py` 의 `GN_MD_URL = "https://news.hada.io/topic.md?id={tid}"` 상수가 stale** — 스크립트 docstring은 "227~232차 6회째 100% 404, 사실상 dead path" 라고 박혀있으나, **실제 작동하는 URL은 `/topic/{tid}.md`** (예: `https://news.hada.io/topic/31397.md`). 259차에 직접 호출 → `status=200, 1251 bytes` 정상 응답 + 깨끗한 markdown (frontmatter + metadata + 본문 + 댓글). **영구화 권장** (#23 cleanup cron 임무): `GN_MD_URL` 을 `/topic/{tid}.md` 로 정정하면 1단계 `.md` fallback 이 가장 신뢰성 있는 fetch 경로로 부활 — HTML 파싱 fallback의 비표준 마크업 함정과 RSS summary fallback의 짧은 길이 함정을 모두 우회. 259차는 임시 우회 (`/tmp/fetch_31397_md.py` 직접 작성) 로 본문 확보했으나, 다음 차에 정식 패치 권장. 차감/추가 없음. 모든 기존 패턴 정상 동작. 상세: `references/session-20260714-259th-saaskr-mcp.md`.
>
> **2026-07-13 (258차)**: **green-run confirmation + #22 정책 무효 케이스** — **`#989 Claude Code는 프롬프트 전에 3.3만 토큰, OpenCode는 7천 토큰 — API 경계에서 발견한 코딩 에이전트 토큰 비용의 진짜 차이`** (AI/ML/1219746, gn=31373, 15점) 정상 발행 — §3.8.1 가드 통과 (`status=200, ct=application/json;charset=UTF-8, cookie_count=8`), §3.34.43 PWD 보강 (`PWD=/Users/mac`), §3.34.40 FRESH 4-field (TOP 12개 모두 AI/ML 카테고리, 31370/31351 PUB 처리 → FRESH 잔여 10개 모두 AI/ML), §3.5 5중 신호 5/5 `#989` 일치 (사전 `#988` → 사후 `#989` 모두 검증, `triple_signal_match: true`), post_publish_sync `pt_updated: true / state_updated: true / errors: []`, daily_counts[2026-07-13] = `{'개발팁': 1, '개발도구': 2, 'AI/ML': 5}` (4→5, +1 정확, cat_id 누설 0), state.details 65→66, pt.details 81→82 모두 박힘, cleanup cron 임무 #16 dry-run `✅ 누설 없음` (43→44회 연속 all-green), 이미지 2장 CDN 업로드 정상 (query: code editor terminal token meter api overhead measurement, Picsum 자동 매칭 ID 504), 본문 792자 (300자 가드 통과), 라이브 페이지 직접 GET `status=200, size=59015` (실제 발행 확인). **연속 all-green 44회차 (213~258차)**. 가짜 발행 가드 정상. **#22 정책 무효 케이스 (NEW, 258차 검증)**: 256차에서 식별한 #22 정책 ("'기타' 제외 > #21 AI/ML 우선")이 **FRESH 후보 모두 AI/ML**인 케이스에는 적용 불필요 — #21 단독 적용으로 충분. 즉 #22는 **FRESH 후보에 '기타'가 1개 이상 포함될 때만** 동작하는 가드. 258차는 FRESH 10개 모두 AI/ML → #22 무효, #21 정상 동작. 정책 우선순위 매트릭스 (§3.34.45) 그대로 유효. **사소한 호출 함정 (NEW, 258차 1회성)**: `strip-frontmatter.py`는 `<input> <output>` positional 2-arg 필수 — 단일 인자로 호출시 Usage 에러. 회피: 항상 두 개 인자 명시. 영구화 불필요 (1회성 호출 오타, 즉시 재호출로 해결). 본 세션 신규 패턴 발견 없음 — 모든 기존 playbook 정상 동작. 차감/추가 없음.
>
> **2026-07-13 (257차)**: **green-run confirmation** — **`#988 AgentsView — 여러 AI 코딩 에이전트의 세션 검색·분석·비용 추적 도구`** (AI/ML/1219746, gn=31370, 26점, FRESH 1순위) 정상 발행 — §3.8.1 가드 통과 (`status=200, ct=application/json;charset=UTF-8, cookie_count=8`), §3.34.43 PWD 보강 (`PWD=/Users/mac`), §3.34.40 FRESH 4-field (TOP 12개 모두 AI/ML 후보, 31351만 251차에 PUB 처리 → FRESH 잔여 11개; **AI/ML 후보 다수 FRESH → §3. — 발행 0건 정상 종료 (FRESH 후보 2개 모두 '기타' 카테고리). §3.8.1 가드 통과 (`status=200, ct=application/json, cookie_count=8`), §3.34.40 FRESH 4-field (TOP 12개 중 10개 이미 250~255차 PUB 처리 → FRESH 잔여 2개: 기타 `31338` (1.0점, Android 앱→웹페이지) + 기타 `31359` (0.5점, 세그멘테이션 오류); AI/ML FRESH 0개), §3.5 5중 신호 5/5 `#987` 일치 유지 (drift 무해, 사후 변동 0), `cleanup_daily_cat_id_leak.py` dry-run `✅ 누설 없음` (40→41회 연속 all-green), state.details 64, pt.details 80 변동 없음, daily_counts[2026-07-13] 변동 없음 (`{개발팁:1, 개발도구:2, AI/ML:3}`). **§3.34 #21 경계 조건 확정 (NEW, 256차)**: #21 가이드 "AI/ML FRESH=0 이면 다른 카테고리 발행 허용"이 **'기타' 카테고리에는 적용되지 않음** — `blog_pipeline.py` §1448~1456 (2026-06-08 영구화 정책) **"기타" 카테고리는 발행 대상에서 의도적으로 제외**. **정책 우선순위 확정**: `'기타' 제외 > #21 AI/ML 우선`. 즉 FRESH 후보가 모두 '기타'이면 → skip (이번 차가 실전 1호). FRESH 후보가 '기타' + 'AI/ML' 혼재이면 → AI/ML 픽 (#21 가이드 그대로). FRESH 후보가 '기타' + 'AI/ML 외 다른 카테고리' 혼재이면 → #21 가이드 + '기타' 제외 = 다른 카테고리 발행 허용. 본 세션 신규 코드 변경 없음 — **#22 cleanup cron 임무로 정책 우선순위 박기**. 차감/추가 없음. 모든 기존 패턴(§3.8.1 / §3.8.2 / §3.5 / §3.11 / §3.34.39~44 / #21) 정상 동작.
> **2026-07-13 (255차)**: **green-run confirmation + AI/ML 우선 가이드 (#21) 실전 적용 1호** — **`#987 하드 테크오프 신화에 대한 한 가지 회의 — geohot의 「AI 2040과 지능 숭배」`** (AI/ML/1219746, gn=31360, 3점) 정상 발행 — §3.8.1 가드 통과 (`status=200, ct=application/json, cookie_count=8`), §3.34.43 PWD 보강 (`PWD=/Users/mac`), §3.34.40 FRESH 4-field (TOP 9개 AI/ML+개발도구+개발팁 후보 31340/31351/31349/31342/31350/31343/31355/31352/31348 모두 250~254차 PUB 처리 → FRESH 잔여 3개: AI/ML `31360` + 기타 `31338`/`31359`; **AI/ML FRESH 1개 발견 → §3.34 #21 AI/ML 우선 정책**으로 `31360` 픽), §3.5 5중 신호 5/5 `#987` 일치 (사전 `#986` → 사후 `#987` 모두 검증, `triple_signal_match: true`), post_publish_sync `pt_updated: true / state_updated: true / errors: []`, daily_counts[2026-07-13] = `{'개발팁': 1, '개발도구': 2, 'AI/ML': 3}` (AI/ML 2→3, +1 정확, cat_id 누설 0), state.details 63→64, pt.details 79→80 모두 박힘, pt.last.{title, gn_topic_id=31360, source_url} 3필드 정상, cleanup cron 임무 #16 dry-run `✅ 누설 없음`, 이미지 2장 CDN 업로드 정상 (query: underwater data center submarine cables intelligence, Picsum 자동 매칭), 본문 2732자 (300자 가드 통과), 라이브 페이지 직접 GET `status=200, size=63485` (실제 발행 확인). **연속 all-green 40회차 (213~255차)**. 가짜 발행 가드 정상. §3.34.39~44 (240~254차 발견) + §3.8.2 격리 패턴 (244차 정정) + §3.34.41 3.9-safe string concat (245차) + §3.34.43 PWD 보강 (247차) + §3.34.44 cron 차 사이 last URL drift (254차 확정) + **§3.34 #21 AI/ML 우선 정책 (254차 식별 → 255차 실전 1호)** 모두 통과. **#21 실전 검증 (NEW, 255차)**: 254차 본문이 "FRESH 1순위가 개발도구였으나 그대로 진행"이었음. 255차에는 FRESH 후보가 AI/ML 1 + 기타 2 — **#21 정책 그대로 AI/ML 픽이 정답**으로 입증. 차후 AI/ML 후보가 0인 사이클에서도 #21 정책 자체가 가드 깨지 않음 (FRESH 4-field 매칭은 점수 무관, 카테고리 무관 — 카테고리 혼재 위험 없음). **§3.34.44 drift 패턴 두 번째 관찰 (255차)**: 사전 검증에서 `state.last_published_url` 이 `#986` 으로 박혀있음 (254차 차 종료값, 자정 사이 추가 발행 없음 — 같은 날 같은 차). 5중 검증 모두 일치 유지. 254차 관찰의 "자정 사이 외부 발행" 케이스와 다른 케이스 (한 차 내 외부 발행이 없는 정상 케이스) — 두 패턴 모두 drift-immune. 본 세션 신규 발견 없음 — 모든 패턴 정착. 차감/추가 없음. 상세: `references/session-20260713-255th-ai-2040.md`.
> **2026-07-13 (254차)**: **green-run confirmation + §3.34.44 실전 검증 확정** — **`#986 마담 Semver가 펼쳐본 오픈소스 maintainer의 1년 — 아카이브하지 않은 저장소의 미래`** (개발도구/1219748, gn=31355, 4점) 정상 발행 — §3.8.1 가드 통과 (`status=200, ct=application/json, cookie_count=8`), §3.34.43 PWD 보강 (`PWD=/Users/mac`), §3.34.40 FRESH 4-field (TOP 8개 AI/ML+개발도구+개발팁 후보 31340/31351/31349/31342/31350/31343/31352/31348 모두 250~253차 PUB 처리 → FRESH 잔여 4개: 개발도구 31355 + 기타 31338/31358/31357, AI/ML 카테고리 후보 0개), §3.5 5중 신호 5/5 `#986` 일치 (사전 `#985` → 사후 `#986` 모두 검증, `triple_signal_match: true`), post_publish_sync `pt_updated: true / state_updated: true / errors: []`, daily_counts[2026-07-13] = `{'개발팁': 1, '개발도구': 2, 'AI/ML': 2}` (개발도구 1→2, +1 정확, cat_id 누설 0), state.details 62→63, pt.details 78→79 모두 박힘, pt.last.{title, gn_topic_id=31355, source_url} 3필드 정상, cleanup cron 임무 #16 dry-run `✅ 누설 없음`, 이미지 2장 CDN 업로드 정상 (query: tarot cards developer repository maintenance vintage, Picsum 자동 매칭), 본문 3146자 (300자 가드 통과), 라이브 페이지 직접 GET `status=200, len=66530` (실제 발행 확인). **연속 all-green 39회차 (213~254차)**. 가짜 발행 가드 정상. §3.34.39~43 (240~247차 발견) + §3.8.2 격리 패턴 (244차 정정) + §3.34.41 3.9-safe string concat (245차) + §3.34.43 PWD 보강 (247차) + §3.34.44 cron 차 사이 last URL drift (253차 식별 → 254차 실전 검증 완료) 모두 통과. **§3.34.44 실전 검증 (NEW, 254차)**: 사전 검증에서 `state.last_published_url` 이 `#985`로 박혀있음 — 직전 cron 차(자정 사이) 외부에서 추가 발행된 흔적. 5중 신호 모두 일치 유지되어 drift 무해 확정. **신규 가드 룰 — "AI/ML 우선 + 카테고리 균형"**: 254차 FRESH 1순위가 개발도구였으나 §3.34.39 후보 직접 점수 pick 패턴에 따라 그대로 진행 (4점 후보 정상 발행). 추후 AI/ML TOP 후보가 0이 되는 사이클에서는 다른 카테고리 발행 허용 — **단 AI/ML 후보가 1개 이상 FRESH이면 무조건 AI/ML 우선** (가짜 발행 가드는 FRESH 4-field 매칭이므로 카테고리 혼재 위험 없음). 본 세션 신규 발견 없음 — 모든 패턴 정착. 차감/추가 없음. 상세: `references/session-20260713-254th-madame-semver.md`.
> **2026-07-13 (253차)**: **green-run confirmation** — **`#982 Ant, 경량 JavaScript 런타임과 생태계 — 8.6MB 단일 바이너리로 V8/JSC 우회하는 새로운 접근`** (개발팁/1219747, gn=31348, 4점) 정상 발행 — §3.8.1 가드 통과 (`status=200, ct=application/json, cookie_count=8`), §3.34.43 PWD 보강 (`PWD=/Users/mac`), §3.34.40 FRESH 4-field (TOP 7 AI/ML 후보 31340/31351/31349/31342/31350 모두 250~252차 PUB 처리 + 후속 차 pt.details 축적 → FRESH 잔여: 개발팁 `31348` + AI/ML `31343`; 1순위 픽 = 31348 단, AI/ML TOP FRESH는 31343 하나뿐), §3.5 5중 신호 5/5 `#982` 일치 (사전 `#981` → 사후 `#982` 모두 검증, `triple_signal_match: true`), post_publish_sync `pt_updated: true / state_updated: true / errors: []`, daily_counts[2026-07-13] = `{'개발팁': 1}` (+1 정확, cat_id 누설 0), state.details 58→59, pt.details 74→75 모두 박힘, pt.last.{title, gn_topic_id=31348, source_url} 3필드 정상, cleanup cron 임무 #16 dry-run `✅ 누설 없음`, 이미지 2장 CDN 업로드 정상 (query: javascript runtime code terminal, Picsum 자동 매칭), 본문 2736자 (300자 가드 통과). **연속 all-green 38회차 (213~253차)**. 가짜 발행 가드 정상. §3.34.39~43 (240~247차 발견) + §3.8.2 격리 패턴 (244차 정정) + §3.34.41 3.9-safe string concat (245차) + §3.34.43 PWD 보강 (247차) 모두 통과. **사소한 관찰 (§3.34.44 후보, 253차 식별)**: 사전 검증에서 `state.last_published_url` 이 이미 `#981` 로 박혀있음 (전날 자정 무렵 추가 발행된 흔적) → 즉 **새벽 사이 이미 1건 발행이 일어났음**. 5중 검증 모두 일치 유지되어 drift 무해. 다만 cron 자동화 관점에서 "이전 cron 차의 마지막 URL과 새 cron 호출 직전 URL이 다를 수 있다"는 점을 명시 — pt/details 비교시 항상 **현재 시점의 last url** 을 source-of-truth로 사용. 본 세션 신규 발견 없음 — 모든 패턴이 정착된 playbook 그대로 정상 동작. 차감/추가 없음.
> **2026-07-12 (252차)**: **green-run confirmation** — **`#980 에어팟 노이즈캔슬링 중 이름 들리면 자동으로 주변음 허용 — EarsUp 살펴보기`** (5점, 31350) 정상 발행 — §3.8.1 가드 통과 (`status=200, ct=application/json;charset=UTF-8, cookie_count=8`), §3.34.43 PWD 보강 (`PWD=/Users/mac`), §3.34.40 FRESH 4-field (251차에 TOP 6개 모두 PUB 처리: 31340/31349/31342/31334/31329/31327/31326 → FRESH 5개 식별 31350/31348/31343/31338/31336, 후순위 FRESH `31350` 1순위 픽), §3.5 5중 신호 5/5 `#980` 일치 (사전 `#979` → 사후 `#980` 모두 검증), post_publish_sync `triple_signal_match: true`, daily_counts[2026-07-12] = `{'개발도구': 1, 'AI/ML': 11}` (10→11, +1 정확, cat_id 누설 0), state.details 76→77, pt.details +1 모두 박힘, cleanup cron 임무 #16 dry-run 누설 없음. 이미지 2장 CDN 업로드 정상 (query: AirPods macOS menu bar app name detection transparency, Picsum 자동 매칭 첫 시도 적중). **연속 all-green 37회차 (213~252차)**. 가짜 발행 가드 정상. §3.34.39~43 (240~247차 발견) + §3.8.2 격리 패턴 (244차 정정) + §3.34.41 3.9-safe string concat (245차) + §3.34.43 PWD 보강 (247차) 모두 통과. 본 세션 신규 발견 없음 — 모든 패턴이 정착된 playbook 그대로 정상 동작. 차감/추가 없음.
> **2026-07-12 (251차)**: **green-run confirmation** — **`#978 NVIDIA·CoreWeave·Nebius가 만든 GPU 붐의 순환 금융 구조`** (10점, 31349) 정상 발행 — §3.8.1 가드 통과 (`status=200, ct=application/json; cookie_count=8`), §3.34.43 PWD 보강 (`PWD=/Users/mac`), §3.34.40 FRESH 4-field (TOP 1 = 31340 Boko Haram이 250차 처리, 후순위 FRESH `31349` 1순위 픽, FRESH 6개 식별: 31349/31342/31350/31348/31343/31338), §3.5 5중 신호 5/5 `#978` 일치 (사전 `#977` → 사후 `#978` 모두 검증), post_publish_sync `triple_signal_match: true`, daily_counts[2026-07-12] = `{'개발도구': 1, 'AI/ML': 9}` (8→9, +1 정확, cat_id 누설 0), state.details 54→55, pt.details 70→71 모두 박힘, cleanup cron 임무 #16 dry-run 누설 없음. 이미지 2장 CDN 업로드 정상 (query: data center GPU server racks). **연속 all-green 36회차 (213~251차)**. 가짜 발행 가드 정상. §3.34.39~43 (240~247차 발견) + §3.11 sync (241차) + §3.34.41 (245차 수정본 가드 heredoc) 모두 통과. 본 세션 신규 발견 없음 — 모든 패턴이 정착된 playbook 그대로 정상 동작. 차감/추가 없음.
> **2026-07-12 (250차)**: **green-run confirmation** — **`#974 SpaceX, 대역폭 100배 위해 Starlink 위성 10만 기 추가 발사 추진`** (3점, 31334) 정상 발행 — §3.8.1 가드 통과 (3.9-safe string concat), §3.34.43 PWD 보강 (`PWD=/Users/mac`), §3.34.40 FRESH 4-field (TOP 1~4 = 31308/31318/31324/31307 + 31305/31323 모두 249차 이전 PUB 처리 → 후순위 FRESH `31334` 1순위 픽, FRESH 잔여 2개: 31320/31315), §3.5 5중 신호 5/5 `#974` 일치 (사전 `#973` → 사후 `#974` 모두 검증), post_publish_sync `triple_signal_match: true`, daily_counts[2026-07-12] = `{'개발도구': 1, 'AI/ML': 5}` (4→5, +1 정확, cat_id 누설 0), cleanup cron 임무 #16 dry-run 누설 없음. 이미지 2장 CDN 업로드 정상 (query: satellite constellation space orbital network). **연속 all-green 35회차 (213~250차)**. 가짜 발행 가드 정상. §3.34.39~43 (240~247차 발견) + §3.11 sync (241차) 모두 통과. 본 세션 신규 발견 없음 — 모든 패턴이 정착된 playbook 그대로 정상 동작. 차감/추가 없음.
> **2026-07-12 (249차)**: **green-run confirmation** — **`#970 AI 스크레이퍼 공격으로 유지가 어려워지는 개방형 웹`** (4점, 31323) 정상 발행 — §3.8.1 가드 통과 (3.9-safe string concat), §3.34.43 PWD 보강 (`PWD=/Users/mac`), §3.34.40 FRESH 4-field (TOP 1~4 = 31308/31318/31324/31307 + 31305 모두 248차 이전 PUB 처리 → 후순위 FRESH `31323` 1순위 픽, FRESH 잔여 6개: 31327/31326/31320/31315/31313/31309), §3.5 5중 신호 5/5 `#970` 일치, post_publish_sync `triple_signal_match: true`, daily_counts[2026-07-12] = `{'개발도구': 1, 'AI/ML': 1}` (+1 정확, cat_id 누설 0), cleanup cron 임무 #16 dry-run 누설 없음. 이미지 2장 CDN 업로드 정상 (query: network firewall security bot traffic). **연속 all-green 34회차 (213~249차)**. 가짜 발행 가드 정상. §3.34.39~43 (240~247차 발견) 모두 통과. 본 세션 신규 발견 없음 — 모든 패턴(§3.8.1 string concat / §3.8.2 격리 / §3.34.43 PWD / §3.34.41 f-string 회피 / §3.34.40 FRESH 4-field / §3.11 sync / §3.5 5중 / #16 dry-run)이 정착된 playbook 그대로 정상 동작. 차감/추가 없음.
> **2026-07-12 (248차)**: **green-run confirmation + 사소한 관찰 1건** — **`#969 개발자 GitHub → Codeberg`** (5점, 31305) 정상 발행 — §3.8.1 가드 통과, §3.34.39 FRESH 4-field (TOP 1~4 모두 PUB 처리: 31308 Apple Silicon, 31318 Apple 소송, 31324 Damn Interesting, 31307 사람 유지보수 — 후순위 FRESH 31305 1순위 픽), §3.5 5중 신호 5/5 `#969` 일치, post_publish_sync `triple_signal_match: true`, daily_counts[2026-07-12]['개발도구'] = 1 (+1 정확), cleanup cron 임무 #16 dry-run cat_id 누설 0. **연속 all-green 33회차 (213~248차)**. 가짜 발행 가드 정상. §3.34.39~43 (240~247차 발견) 모두 통과. **사소한 관찰**: 247차 본문이 daily_counts[2026-07-11]['AI/ML'] = 9 라고 적혀있으나 실제 state엔 11 (247차 시점에 #967 + #968 두 건의 stats 보정이 본문 기록엔 누락 — 실제 발행/sync 모두 성공, 차감/추가 없음, 후속 차 reference 정합성 자동 검증). 그 외 격리 패턴 PWD 이중 보강 (`PWD=/Users/mac` + `cd /Users/mac`), §3.34.41 string concatenation, §3.34.40 FRESH 4-field 매칭 모두 정상 동작 — 247차 영구화 검증 OK. 상세: `references/session-20260712-248th-codeberg-publish.md`.
> **2026-07-11 (247차)**: §3.34.43 (NEW) — **`env -i ... /bin/bash -c '...'` 호출 시 bash 스타트업 시 자동 `cd` 시도** → `bash: 행 2번: cd: /Users/mac/.hermes/repos/icbm2-knowledge-graph: No such file or directory` 로 exit 126. 247차 `post_publish_sync.py sync` 첫 호출에서 hit. 회피: bash 서브쉘 시작 시 `cd /Users/mac` 명시 또는 `PWD=/Users/mac` 환경변수 명시. 모든 격리 패턴 호출에서 적용 가능 — 영구화. 그 외 **`#966 htmldrop+MCP`** (8점, 31300) 정상 발행 — §3.8.1 가드 통과, §3.34.40 FRESH 4-field (TOP 1 = 31308 Apple Silicon이 PUB 처리 → 후순위 FRESH `31300` 픽), §3.5 5중 신호 5/5 `#966` 일치, post_publish_sync `triple_signal_match: true`, daily_counts[2026-07-11]['AI/ML'] = 9 (7→9, +2 정확), cleanup cron 임무 #16 dry-run cat_id 누설 0. **연속 all-green 32회차 (213~247차)**. 가짜 발행 가드 정상. §3.34.39~42 (240~246차 발견) 모두 통과. 상세: `references/session-20260711-247th-pwd-bash-cd-fix.md`.
> **2026-07-11 (246차)**: **green-run confirmation**
> **2026-07-11 (245차)**: §3.34.41 신규 — **`/usr/bin/python3` (3.9) 은 f-string 안에 백슬래시 quote 허용 안 함** (`SyntaxError: f-string expression part cannot include a backslash`). §3.8.1 가드 heredoc의 `print(f"... ct={r.headers.get(\"content-type\",\"\")[:50]}")` 패턴은 3.9 fallback에서 SyntaxError로 가드 자체가 막힘 → 세션 만료 오판 위험. 245차 첫 실행에서 hit, 즉시 string concatenation 으로 재작성하여 해결. **본문 §3.8.1 코드블록은 245차 수정 버전으로 정정** (아래). 그 외 **#962 코딩 평가(signal/noise 분리) + #963 Microsoft Flint** 두 건 정상 발행 — §3.34.40 4-step 명시 패턴, FRESH 4-field 매칭, post_publish_sync 7필드 보정, §3.5 5중 신호 일치 모두 통과. daily_counts[2026-07-11]['AI/ML'] = 6 (4→6, +2 정확), cleanup cron 임무 #16 cat_id 누설 0. 연속 all-green **30회차 (213~245차)**. 가짜 발행 가드 정상. 상세: `references/session-20260711-245th-two-publishes.md`.
> **2026-07-11 (244차)**: §3.34.39 보완 (**후보 직접 점수 정렬 + FRESH 4-field 명시 매칭 패턴**) 정착 — `blog_pipeline.py --refresh-topics --dry-run` 으로 후보 topic_id 12개 + 점수/카테고리 동시 추출, pt.details + state.details 양쪽 교차 매칭 후 FRESH 판정 → `--category`/`--force-topic` 호출 없이도 정확히 0점 손실로 첫 pick 가능. 244차 `#31286 LLM 번아웃 (19점)` 첫 pick에서 publish `#960` 성공. **§3.5 5중 신호 영구 보정 (242차 본문 오표기 정정)** — 242차에 "pt.last.url = state['published_topics']['last'].url" 형태로 적혀있었으나 **state 파일엔 `published_topics` 키 없음**. 진짜 4/5번 신호는 `~/.hermes/memory/published_topics.json` (별도 파일) 의 `last.url` + `details[-1].url`. 244차 검증 후 영구 보정 형식:
> 1. `state.last_published_url`
> 2. `state.last.url`
> 3. `state.details[-1].url`
> 4. **`published_topics.json` last.url** (별도 파일, source-of-truth)
> 5. **`published_topics.json` details[-1].url** (별도 파일, source-of-truth)
>
> state.json엔 `last_topics`, `last_post`, `last`, `details`, `last_published_url` 만 존재 — `state['published_topics']` 로 lookup 시도하지 말 것. **격리 패턴 정정 (244차)**: 243차 본문이 `env -i` 후 외부에서 source한 env를 노출 — 사실 `env -i`가 모든 환경변수 날리므로 cookie count=0 → 세션 만료 오판. 정정: `env -i HOME=... PATH=... /bin/bash -c 'set -a; source tistory.env; set +a; /usr/bin/python3 << EOF'` 형태로 bash 안에서 source 후 child python 상속. **execute_code cron 차단 (244차)**: cron 컨텍스트에서 `execute_code`은 `BLOCKED: ... bypass shell-string approval checks` 로 거부됨 → `terminal`+heredoc 또는 `write_file`로 draft.md 저장 후 `tistory_publisher.py --file` 직접 호출. cleanup cron 임무 #16 dry-run **29회 연속 all-green** (213~244차). 가짜 발행 가드 정상 동작. 상세: `references/session-20260711-244th-fresh-pick-and-pt-source.md`.
>
> **2026-07-11 (243차)**: 두 가지 cron 자동화 한계 발견 — (a) **`blog_pipeline.py --category 'AI/ML'` 의 후보 pick이 점수 무관** — 첫 실행 `31301 (3점)`, 두번째 실행 `Tencent Hy3 (이미 발행 #958)`. 즉 fresh 후보 우선순위가 무너지고 마지막 published 토픽 주변을 순환. cron 컨텍스트에서 `--category` 단독 호출은 가짜 pick 위험. (b) **`--force-topic <id>` 는 source_url/topic_url을 빈 값으로 박음** (output JSON에 `"source_url": ""`, `"topic_url": ""`) → `tistory_publisher.py --source-url` 단계로 이어질 정보 미주입. cron 자동 publish 진행시 본문 작성 단계가 별도 LLM 컨텍스트에 강제 의존. (c) **state 경로 명세 일치 확인**: 진짜 state 파일은 `~/.hermes/memory/blog_pipeline_state.json` (블로그 파이프라인 통합 state). `post_publish_sync.py sync-from-pt` 가 `~/.hermes/state/tistory_state.json` 를 lookup하지만 해당 파일은 부재 → sync-from-pt 결과가 `pt_updated: true / state_updated: true / errors: [] / triple_signal_match: true` 반환하지만 **사실상 pt→pt noop**. 진짜 drift 보정은 별도 heredoc이 필요했음 (이번 차는 5중 신호가 이미 일치하여 drift 무해). 다음 차에 `post_publish_sync.py` 가 통합 state 경로를 lookup하도록 패치 권장. **§3.34.39 보완은 244차 reference + 본문에 코드 스니펫 신규 영구화**.
>
> **2026-07-11 (242차)**: §3.5 신호 **5중 검증** 정식화 + `post_publish_sync.py` CLI 실전 검증 — **§3.5 검증 항목이 실제로는 5개**임 확인 (`state.last_published_url` + `state.last.url` + `state.details[-1].url` + `pt.last.url` + `pt.details[-1].url` 전부 동일해야 함). SKILL.md 본문이 "3중"이라고 표기된 부분은 **legacy 5중** 으로 갱신. **`post_publish_sync.py` CLI 형태 영구화**: 단순 `--url` 플래그가 아닌 `sync` 서브커맨드 + `--url/--title/--gn-topic-id/--category/--source-url/--category-id(선택)` 형태. 242차 `#959 OpenAI GPT 5.6` 발행에서 §3.8.1 가드 통과 + `env -i` §3.8.2 격리로 publish 성공 + sync 결과 `triple_signal_match: true` 보고 확인. **`tistory_publisher.py` CLI 인수 함정 (NEW)**: `--topic-url` / `--auto-record` 는 **존재하지 않는 옵션** (사용시 `unrecognized arguments` 에러). 실제 옵션은 `--source-url <URL>` + `--gn-topic-id <N>` 분리. **244차 보정**: 242차 본문에 적힌 `pt.last.url = state['published_topics']['last'].url` 은 사실 — state.json에는 `published_topics` 키가 없고 pt는 `~/.hermes/memory/published_topics.json` 별도 파일. 위 244차 영구 보정 형식 참조. 상세: `references/session-20260711-242nd-five-signal-and-cli-args.md`.
>
> **2026-07-10 (241차)**: §3.11 5-1 자동 보정 신규 영구화 (NEW, 두 번째로 중요) — **`tistory_publisher.py`가 발행 성공해도 pt/state/stats를 자동 갱신하지 않음** 확인 (240차 #958 발행 후 검증 단계에서 발견). 매 세션마다 §3.11 5-1 heredoc 수동 작성은 비효율 → `scripts/post_publish_sync.py` 신규 (publish_url, title, gn_topic_id, category, source_url 인자 → pt.last + pt.details + state.details + state.last_published_url + state.last + state.daily_counts[today][category] +1 원샬 동기화). **§3.5 사전 drift 자동 감지 → publish 전 보정 후 진행** 워크플로 정착. cleanup cron 임무 #16 dry-run **28회 연속 all-green** (213~241차) + §3.8.2 격리 패턴 적용 OK. 상세: `references/session-20260710-241st-post-publish-sync.md`.
>
> **2026-07-10 (240차)**: §3.8.1 세션 만료 1회 실전 검증 + **hermes-agent venv 격리 패턴 신규 영구화** (NEW, 가장 중요) — §3.8.1 `manage/posts.json` 호출이 **302 → `/auth/login` 리다이렉트**로 세션 만료 확정. publish 단계 skip + §3.5 3중 신호 검증만 실행 후 정상 종료. **가드 통과 못해도 reports는 항상 정상 보고** (이번 차는 "발행 0건 + 세션 만료" 리포트). **hermes-agent venv의 `urllib3 2.6.x`가 Python 3.11.15와 비호환 (PEP 604 union syntax 3.10+ 필요)** → `TypeError: unsupported operand type(s) for |: 'type' and 'type'` 로 `import requests` 실패. **`/usr/bin/python3` (3.9) + `PYTHONPATH=/Users/mac/Library/Python/3.9/lib/python/site-packages` 격리 패턴 표준화** — system site에 `requests-2.32.5` + `urllib3-2.6.3` 설치되어 있어 동작. `env -i HOME=/Users/mac PATH=/usr/bin:/bin /usr/bin/python3 ...` 형태로 venv 영향 완전 차단. **§3.5 3중 신호 일치 OK 유지** (239차 §3.34.36 heredoc 보정 결과 — `#957 Muse Spark 1.1` last+details 모두 박힘) + `stats.daily_counts[2026-07-10] = {'AI/ML': 4, '개발도구': 1, '개발팁': 1}` (cat_id 누설 없음) + cleanup cron 임무 #16 dry-run **27회 연속 all-green** (213~240차) + **§3.8.1 가드 동작 정상 검증 (302 감지 정확)** + **§3.8.2 격리 패턴 (NEW) 영구화** — `scripts/isolate_hermes_python.py` 신규 (모든 cron 작업에서 hermes venv python3 호출 실패시 격리 fallback). 상세: `references/session-20260710-240th-cookie-expired-venv-isolation.md`.

## §3.8.2 격리 패턴 (NEW, 240차) — 244차 정정 반영

hermes-agent venv의 `urllib3 2.6.x`가 Python 3.11.15와 비호환 (PEP 604 union syntax 3.10+ 필요). 모든 cron 작업에서 `python3` 호출이 `TypeError: unsupported operand type(s) for |: 'type' and 'type'`로 실패할 때 다음 격리 패턴 사용. **244차 정정**: `env -i` 자체가 모든 환경변수 날리므로, 외부에서 source한 env는 격리 child에 노출되지 않음. `bash -c 'set -a; source ...; set +a; python3'` 형식으로 **source 단계도 격리 안에서** 수행해야 함. **245차 보완**: 격리 패턴으로 호출되는 `python3`는 `/usr/bin/python3` (**Python 3.9**) — 3.9는 **f-string 안 백슬래시 quote 미허용** (PEP 701 이전 제약). §3.8.1 가드 heredoc은 반드시 string concatenation 패턴으로 작성 (§3.34.41 참조).

```bash
# ✅ 244차 정정 패턴 (권장) — 247차: PWD 추가 필수
env -i HOME=/Users/mac PATH=/usr/bin:/bin PWD=/Users/mac /bin/bash -c '
set -a
source ~/.hermes/secrets/tistory.env
set +a
/usr/bin/python3 << "PYEOF"
import sys, os
sys.path.insert(0, "/Users/mac/Library/Python/3.9/lib/python/site-packages")
import requests
cookies = {k.replace("TISTORY_",""): os.environ[k] for k in os.environ if k.startswith("TISTORY_")}
print("cookie count:", len(cookies))
PYEOF
'
# 또는 bash 안에 `cd /Users/mac` 첫 줄 (PWD 미설정시)
```

`scripts/isolate_hermes_python.py` — `guard_tistory_session()` 함수로 §3.8.1 가드 호출 가능. CLI 1회 실행:

```bash
env -i HOME=/Users/mac PATH=/usr/bin:/bin PWD=/Users/mac /bin/bash -c '
set -a; source ~/.hermes/secrets/tistory.env; set +a
/usr/bin/python3 ~/.hermes/skills/automation/tistory-publisher/scripts/isolate_hermes_python.py
'
```

> ⚠️ **isolate_hermes_python.py 자체 호출 함정 (258차 발견)**: 위 예시는 1회 실행용 — bash 안에서 source 후 child python 상속. 그러나 **스크립트 자체는 source 단계를 거치지 않으므로**, 워치독/자동화에서 스크립트를 격리 없이 직접 호출 (`python3 isolate_hermes_python.py`)하면 cookies=0 → 302 → `§3.8.1 세션 만료` 오판. 258차 1차 probe에서 hit → 즉시 격리 bash 안 source 후 2차 probe로 정상 통과 확인. **다음 차 자동화에서 해당 스크립트를 호출할 땐 반드시 위 4-line 격리 bash 패턴으로 감싸라**. 스크립트 내부에 `source ~/.hermes/secrets/tistory.env` 자동 호출을 추가하는 패치는 보류 — 현재 워치독 호출 경로 없음.

## §3.11 5-1 자동 보정 (NEW, 241차)

**핵심 발견**: `tistory_publisher.py --file ...`가 "발행 성공" 메시지를 출력하고 pt/state/stats를 자동 갱신하지 않음. 매 세션마다 §3.11 5-1 보정 heredoc을 수동으로 작성해야 했는데, 이제 `scripts/post_publish_sync.py`로 영구화.

```bash
env -i HOME=/Users/mac PATH=/usr/bin:/bin PWD=/Users/mac /bin/bash -c '
set -a
source ~/.hermes/secrets/tistory.env
set +a
/usr/bin/python3 << PYEOF
import sys, os
sys.path.insert(0, "/Users/mac/Library/Python/3.9/lib/python/site-packages")
sys.path.insert(0, "/Users/mac/.hermes/skills/automation/tistory-publisher/scripts")
import post_publish_sync
post_publish_sync.sync(
    publish_url="https://sigco.tistory.com/960",
    title="LLM 번아웃이 온 것 같아요 — ...",
    gn_topic_id=31286,
    category="AI/ML",
    source_url="https://news.hada.io/topic?id=31286"
)
PYEOF
'
```

**또는 CLI 1회 실행** (242차 실전 검증, `sync` 서브커맨드 + `--category-id` 선택):

```bash
env -i HOME=/Users/mac PATH=/usr/bin:/bin PWD=/Users/mac /bin/bash -c '
set -a; source ~/.hermes/secrets/tistory.env; set +a
/usr/bin/python3 ~/.hermes/skills/automation/tistory-publisher/scripts/post_publish_sync.py sync \
  --url "https://sigco.tistory.com/960" \
  --title "LLM 번아웃이 온 것 같아요 — 같은 문체·같은 환각의 반복이 만든 피로와 5가지 대응법" \
  --gn-topic-id 31286 \
  --category "AI/ML" \
  --category-id 1219746 \
  --source-url "https://news.hada.io/topic?id=31286"
'
```

> ⚠️ **CLI 인수 함정 (242차 발견)**: 단순 `--url ...` 만 단독으로 넘기면 `argparse error: invalid choice: 'https://...'` 에러남. 반드시 `sync` 서브커맨드를 먼저 명시할 것. `--category-id` 는 생략 가능 (자동 매핑되지만 명시 권장 — cleanup cron 임무 #16 cat_id 누설 방지).
>
> ⚠️ **CLI title 오타 검증 (258차 발견)**: `sync --title "..."` 로 박은 title 문자열에 숫자 단위(예: `Java 1.0` vs `Java 5.0`, `1만` vs `10만`)가 포함된 경우 오타 가능. **사후 검증 단계 권장**:
> 1. sync 직후 pt.last.title + state.last.title + state.details[-1].title 3필드가 모두 publish 직전 draft 제목과 정확히 일치하는지 확인.
> 2. 불일치시 → 직접 json 파일에 load 후 3필드 모두 같은 값으로 덮어쓰기 보정 (sync 스크립트는 다시 호출할 필요 없음, noop 위험).
> 3. publish 된 Tistory 페이지 자체의 <title> 태그는 별도로 고치려면 브라우저 단에서 수정 — 자동 sync는 pt/state만 보정.
>
> **함정 패턴 예시 (258차)**: draft 본문엔 `Java 1.0` 정상이었는데 CLI title 인자에 `Java 5.0` (자릿수 비슷한 오타) 으로 박힘 → sync 결과 `triple_signal_match: true` 반환했지만 실제론 오타. **원문/원본 draft의 원래 title substring을 다시 확보한 뒤** pt/state 양쪽 일괄 덮어쓰기가 정답.

**동기화 대상** (7필드 원샬):

1. `pt['last']` — hash, topic, title, date, url, source_url, gn_topic_id
2. `pt['details']` — append entry (hash, topic, title, url, date)
3. `pt['topics'][hash]` — dict 인덱스 (있으면)
4. `state['last_published_url']`, `state['last_published_id']`
5. `state['last']` — title, url, date
6. `state['details']` — append entry (topic_id, title, url, date, category, category_id, gn_topic_id, source_url)
7. `state['daily_counts'][today][category]` += 1

**§3.5 사전 drift 감지 → publish 전 보정 후 진행 워크플로 (244차 5중 검증 영구 보정)**:

- publish 직전, 다음 **5개 URL이 모두 일치**하는지 검증. **pt는 state 내부 dict가 아니라 `published_topics.json` 별도 파일**:
  ```python
  import json
  state = json.load(open('/Users/mac/.hermes/memory/blog_pipeline_state.json'))
  pt = json.load(open('/Users/mac/.hermes/memory/published_topics.json'))
  sigs = {
      '1. state.last_published_url': state.get('last_published_url'),
      '2. state.last.url': state['last']['url'] if isinstance(state.get('last'), dict) else None,
      '3. state.details[-1].url': state['details'][-1]['url'] if state.get('details') else None,
      '4. pt.last.url': pt['last']['url'] if isinstance(pt.get('last'), dict) else None,
      '5. pt.details[-1].url': pt['details'][-1]['url'] if pt.get('details') else None,
  }
  all_match = len(set(sigs.values())) == 1
  ```
- 불일치시 → `post_publish_sync.py sync-from-pt` 호출 (pt를 source-of-truth로 state 보정). 단, 243차 §3.34.39 (c) 함정 — sync-from-pt 가 잘못된 경로 lookup하므로 결과 `triple_signal_match: true` 만 믿지 말 것.
- 일치시 → publish 진행
- 244차 검증: publish 직전 5중 모두 `#959` 일치 확인 후 진행, publish 후 모두 `#960` 으로 갱신 확인

## §3.34.43 격리 패턴 PWD/cd 함정 (NEW, 247차)

`env -i HOME=... PATH=... /bin/bash -c '...'` 호출 시 hermes 셸 bashrc가 자동 `cd /Users/mac/.hermes/repos/icbm2-knowledge-graph` 시도 → **exit 126 (`bash: 행 N번: cd: ...: No such file or directory`)** 으로 명령 자체가 실행 안 됨. 247차 `post_publish_sync.py sync` 첫 호출에서 hit, `cd` 라인만 stderr로 출력되고 본 python3 호출 안 됨.

**회피 패턴 (3가지 중 택일)**:

```bash
# ✅ 패턴 1: PWD 환경변수 명시
env -i HOME=/Users/mac PATH=/usr/bin:/bin PWD=/Users/mac /bin/bash -c '
set -a; source ~/.hermes/secrets/tistory.env; set +a
/usr/bin/python3 ... '

# ✅ 패턴 2: bash 서브쉘 시작 시 cd 명시
env -i HOME=/Users/mac PATH=/usr/bin:/bin /bin/bash -c '
cd /Users/mac
set -a; source ~/.hermes/secrets/tistory.env; set +a
/usr/bin/python3 ... '

# ✅ 패턴 3: bash 호출 대신 source + python 직접 호출
env -i HOME=/Users/mac PATH=/usr/bin:/bin /usr/bin/python3 - << 'PYEOF'
... PYEOF
```

**적용 범위**: §3.8.1 가드, §3.11 sync, §3.34.40 publish, §3.34.42 verify-tistory-cookie 격리 호출 등 **모든 `env -i ... /bin/bash -c '...'` 형태**. §3.34.40 FRESH 4-field 매칭처럼 python 단독 호출은 영향 없음 (bash 거치지 않음).

> 패턴 3이 가장 단순하지만 heredoc에서 source가 필요한 경우 (Tistory 쿠키 env) 불가 → 패턴 1 또는 2 권장.

## §3.34.39 보완: 후보 직접 점수 pick 패턴 (NEW, 244차)

`blog_pipeline.py --category '<cat>'` 또는 `--force-topic <id>` 단독 호출 회피. cron 자동 발행에선 다음 4-step 명시 패턴:

```bash
# 1. 후보 12개 + 점수 추출 (--category 무관, refresh만 dry-run)
python3 ~/.hermes/scripts/blog_pipeline.py --refresh-topics --dry-run 2>&1 | \
  grep -E 'URL:' | head -12
# → 31286(19), 31281(11), 31291(10), 31287(10), 31300(9), 31275(PUB), 31283(8),
#   31280(6), 31290(PUB), 31279(PUB), 31276(PUB), 31301(3) (예시)

# 2. FRESH 4-field 매칭 (python 격리 패턴 안)
env -i HOME=/Users/mac PATH=/usr/bin:/bin /usr/bin/python3 << 'PYEOF'
import json
pt = json.load(open('/Users/mac/.hermes/memory/published_topics.json'))
state = json.load(open('/Users/mac/.hermes/memory/blog_pipeline_state.json'))
pt_published = set()
for d in pt.get('details', []):
    for k in ['topic', 'topic_id', 'gn_topic_id']:
        if k in d and str(d[k]).isdigit():
            pt_published.add(str(d[k]))
state_published = set()
for d in state.get('details', []):
    for k in ['topic_id', 'gn_topic_id']:
        if k in d and str(d[k]).isdigit():
            state_published.add(str(d[k]))
candidates = ['31286','31281','31291','31287','31300','31275','31283',
              '31280','31290','31279','31276','31301']
fresh = [c for c in candidates if c not in pt_published and c not in state_published]
already = [c for c in candidates if c in pt_published or c in state_published]
print(f"FRESH: {fresh}")
print(f"PUB:   {already}")
PYEOF

# 3. TOP FRESH 후보로 draft 작성 (write_file로 markdown 저장)
# /tmp/tistory_drafts_<session>/draft-<topic_id>-<slug>.md

# 4. 명시 publish (--source-url + --gn-topic-id + --category-id int + --image-query)
env -i HOME=/Users/mac PATH=/usr/bin:/bin PWD=/Users/mac /bin/bash -c '
set -a; source ~/.hermes/secrets/tistory.env; set +a
/usr/bin/python3 /Users/mac/.hermes/scripts/tistory_publisher.py \
  --title "<TITLE>" --category 1219746 \
  --file /tmp/tistory_drafts_<session>/draft-<topic_id>-<slug>.md \
  --source-url "https://news.hada.io/topic?id=<topic_id>" \
  --gn-topic-id <topic_id> \
  --image-query "<korean or english query>"
'

# 5. post_publish_sync sync (7필드 보정)
# 위 §3.11 sync 호출 형식
```

## §3.34.46 gn-fetch-content 영구화 완료 (259차 식별, 260차 실전 검증, 261차 패치 ✅)

**261차 cleanup cron 임무 #23 영구화 완료**: `scripts/gn-fetch-content.py` 의 `GN_MD_URL = GN_TOPIC_BASE + "/{tid}.md"` 정정 + `GN_TOPIC_BASE` 정의 순서 보정 (line 48→49로 이동) + `_try_md_endpoint` docstring 갱신. 261차에 `_try_md_endpoint(31378)` 테스트 → status=200, **9590 bytes** 정상 fetch. 1단계 `.md` endpoint가 즉시 성공 → HTML/RSS fallback 까지 fallthrough하던 stale 함정 종료.

> **영구화 코드 패치 적용 시 두 가지 함정 (261차 식별, 즉시 정정)**:
> 1. **f-string 모듈 로드 시점 평가 함정** — `GN_MD_URL = f"{GN_TOPIC_BASE}/{{tid}.md"` 형태로 적으면 Python이 모듈 로드 시점에 line 순서대로 f-string을 평가. line 48에서 `GN_TOPIC_BASE`가 아직 정의 안 됐으므로 `NameError: name 'GN_TOPIC_BASE' is not defined` 발생. → 정정: `GN_TOPIC_BASE + "/{tid}.md"` (string concatenation은 런타임 lazy 평가라 정의를 뒤로 미뤄도 OK).
> 2. **정의 순서 함정** — `GN_TOPIC_BASE` 정의를 `GN_MD_URL` 보다 **앞 줄**에 두어야 함. string concatenation 사용시에도 안전을 위해 권장.
>
> 위 두 함정은 §3.34.41 f-string 제약과는 다른 차원의 함정 — §3.34.41은 heredoc 안 f-string 안 백슬래시 quote, 이건 모듈 상수 정의 시 f-string 평가 순서. 둘 다 명확히 구분해서 회피.

**영구화 후 본문 fetch 호출 (가장 단순한 패턴, 임시 우회 heredoc 불필요)**:

```python
import importlib.util
spec = importlib.util.spec_from_file_location('gfc', '/Users/mac/.hermes/skills/automation/tistory-publisher/scripts/gn-fetch-content.py')
gfc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gfc)
content = gfc._try_md_endpoint(31378)
# → 9590 bytes (status=200, 깨끗한 markdown)
```

또는 `gfc.fetch_gn_content(31378)` 호출로 `(title, content, source)` tuple 확보 (244차 §3.34.34 확인된 public API).

**본문 추출 정규화 패턴 (260차 정착)**:
```python
import re
text = r.text
# 1. Comments 섹션 제거
m = re.search(r"\n## Comments", text)
if m:
    text = text[:m.start()]
# 2. Metadata 섹션 (## Metadata 다음 - 키:값 리스트) 제거
m_meta = re.search(r"\n## Metadata", text)
if m_meta:
    after_meta = text[m_meta.end():]
    lines = after_meta.split("\n")
    body_lines = []
    in_meta = True
    for line in lines:
        # "- key: value" 또는 빈 줄 → 메타데이터로 간주 skip
        if in_meta and (line.startswith("- ") or line.strip() == "" or line.startswith("  ")):
            continue
        in_meta = False
        body_lines.append(line)
    text = "\n".join(body_lines).strip()
# 3. "## Topic Body" 헤더 한 줄 제거
text = re.sub(r"^## Topic Body\s*\n+", "", text)
```

**Tistory HTML 변환 패턴 (260차 정착, 262차 보완, 278차 5번째 패턴 추가)**:
- `## 헤더` → `<h2>헤더</h2>`
- `### 헤더` → `<h3>헤더</h3>`
- `- 항목` → `<ul><li>항목</li></ul>` (빈 줄 = `</ul>` close 트리거)
- `**bold**` → `<strong>bold</strong>`
- `> 인용` → `<blockquote>인용</blockquote>` (278차 정착, §3.34.54)

> ⚠️ **262차 식별 — 리스트 들여쓰기 / 그룹화 함정**: GeekNews 본문에는 `## 기존 모델의 호출 방식에 맞춰진 제약` 같은 **헤더로 위장된 `-` 항목**(예: `- ## 기존 모델의 호출 방식에 맞춰진 제약`)이나 들여쓬 하위 리스트(`  - ...`)가 흔함. 두 함정:
> 1. **들여쓬 sub-list를 nested `<ul>`로 변환하려고 ul_stack 패턴을 쓰면 깨짐** — 262차 첫 시도에서 들여쓰기 depth를 측정해 `<ul><ul><li>` 를 쌓았더니 md가 nested 가 아닌 pseudo-nested (모든 `- `이 동등한 top-level bullet) 일 때 매 항목마다 `<ul>` 가 새로 열리고 즉시 닫혀 시각적으로 리스트가 아님. → **회피**: indent 무시하고 모든 `- `를 top-level bullet로 취급, 연속된 `- ` 라인들을 하나의 `<ul>...</ul>` 로 묶고 빈 줄에서만 close. 들여쓰기는 시각적 깊이일 뿐 마크다운 의미상 모두 형제 항목.
> 2. **`- ## 헤더` 형식의 위장된 헤더** — GeekNews 마크다운에서 가끔 `- ## 기존 모델의 호출 방식에 맞춰진 제약` 같이 list-prefixed header 가 나옴. `<li>` 로 변환되면 의미 파괴. → **회피**: `- ` 변환 직전 item_text가 `## `/`### `로 시작하면 `<h2>`/`<h3>` 로 라우팅 (indented header는 별도 처리).
>
> **262차 정착 정규식 + 함수 (개선된 md_to_html)**:
> ```python
> def md_to_html(md):
>     out = []
>     in_ul = False
>     for line in md.split("\n"):
>         stripped = line.lstrip()
>         if stripped.startswith("- "):
>             item_text = stripped[2:].strip()
>             # 헤더 위장된 list item 라우팅
>             if item_text.startswith("## ") or item_text.startswith("### "):
>                 if in_ul: out.append("</ul>"); in_ul = False
>                 tag = "h2" if item_text.startswith("## ") else "h3"
>                 out.append(f"<{tag}>{html.escape(item_text.split(' ',1)[1])}</{tag}>")
>                 continue
>             if not in_ul:
>                 out.append("<ul>")
>                 in_ul = True
>             item_esc = html.escape(item_text)
>             item_esc = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", item_esc)
>             item_esc = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r'<a href="\2">\1</a>', item_esc)
>             out.append("<li>" + item_esc + "</li>")
>         elif line.startswith("### "):
>             if in_ul: out.append("</ul>"); in_ul = False
>             out.append("<h3>" + html.escape(line[4:].strip()) + "</h3>")
>         elif line.startswith("## "):
>             if in_ul: out.append("</ul>"); in_ul = False
>             out.append("<h2>" + html.escape(line[3:].strip()) + "</h2>")
>         elif stripped == "":
>             if in_ul: out.append("</ul>"); in_ul = False
>         elif stripped == "---":
>             if in_ul: out.append("</ul>"); in_ul = False
>             out.append("<hr>")
>         else:
>             if in_ul: out.append("</ul>"); in_ul = False
>             p_html = html.escape(line)
>             p_html = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", p_html)
>             p_html = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r'<a href="\2">\1</a>', p_html)
>             out.append("<p>" + p_html + "</p>")
>     if in_ul: out.append("</ul>")
>     return "\n".join(out)
> ```

**editorial 인트로/결론 추가 패턴 (260차 정착, 한국어 1~2 단락)**:
```html
<!-- intro: 한국 독자층 맞춤 1~2 단락 + 원문 링크 -->
<p><a href="https://news.hada.io/topic?id=31376">GeekNews에 공유된 ...</a>을 보면, ...</p>
<p>흥미로운 건 이 프레임이 단순한 유행어 가설이 아니라는 점입니다. ...</p>

<!-- 본문 (GeekNews → HTML 변환) -->

<!-- conclusion: 한국 시장 시사점 1~2 단락 + 원문 링크 -->
<h2>한국 시장에서의 시사점</h2>
<p>한국 SaaS 시장에서도 이미 ...</p>
<p>특히 <strong>고객 응대, 예약·배차, 분류·검토, 보고서 작성</strong> 같은 ...</p>
<p style="color:#666;font-size:0.9em;">원문: <a href="https://news.hada.io/topic?id=31376">GeekNews #31376</a></p>
```

**261차 검증 결과**: `_try_md_endpoint(31378)` 직접 호출 → 9590 bytes (1단계 `.md` endpoint 즉시 fetch). 2장 Picsum CDN 업로드 정상 (query: llm coding ai hype bubble skeptic, ID 365/68). 5중 신호 모두 `#996` 일치. publish 성공. **영구화 패치 완료 — 259~260차 임시 우회 heredoc 패턴 불필요**.

**262차 보완**: `md_to_html` 함수를 재사용 가능한 모듈로 추출 → `scripts/gn-markdown-to-tistory-html.py` (CLI + 모듈 둘 다 지원). 262차 정착판은 260차 4종 패턴 + 262차 보완 2종 함정(들여쓰기 nested ul, `- ## ` 위장 header) 회피 포함. CLI 사용법: `python3 gn-markdown-to-tistory-html.py <topic_id> --with-intro --with-conclusion --out /tmp/draft.html`. 모듈: `from gn_markdown_to_tistory_html import build_full_html; build_full_html(31404, "https://news.hada.io/topic?id=31404")`.

**§3.34.46 본문 → Tistory HTML 변환 4종 패턴 + editorial 인트로/결론 추가**: 아래 "절대 하지 말 것" 박스의 마지막 항목 참조.

## §3.34 핵심 함정 (최근 5차 압축 요약)

- **§3.34.55 (279차, NEW)**: **`gfc` 시그니처 함정 2종 — `fetch_gn_content` / `_try_md_endpoint` 호출 시 shape 불일치** — (a) `gfc.fetch_gn_content(tid)` 는 SKILL.md §3.34.34 (244차 확인) 에 `(title, content, source) tuple` 반환으로 박혀있으나 279차 호출에서 **`TypeError: 'NoneType' object is not subscriptable`** 반환 (실제 함수가 `Optional[Tuple[...]]` 으로 None 반환). → **회피**: 본문 fetch는 무조건 `text = gfc._try_md_endpoint(tid)` 단일 함수만 사용. (b) `gfc._try_md_endpoint(tid)` 시그니처는 grep으로 확인된 `Optional[str]` (단일 문자열 반환) 이 맞지만 (실제 코드 line 87), 만약 `status, text = gfc._try_md_endpoint(tid)` 형태로 적으면 `ValueError: too many values to unpack (expected 2)` 가 터짐. → **확정**: 항상 `text = gfc._try_md_endpoint(tid)` 단일 변수 할당. 279차 검증 — 31496 호출 → 21074 bytes 정상 fetch. **적용 범위**: §3.34.46 본문 빌드의 모든 변형 (`build_draft_*.py` / `gn-markdown-to-tistory-html.py`). cleanup cron 임무 #35 신규 — `scripts/gn-fetch-content.py` 의 두 public 함수 시그니처를 module docstring에 명시 + SKILL.md §3.34.34 박스 코드 스니펫을 `_try_md_endpoint(tid)` 단일 호출로 통일 권장.

- **§3.34.54 (278차, NEW)**: **`md_to_html` `> blockquote` 라우팅 분기 추가 — 5번째 패턴 정착** — GeekNews 본문 (특히 gn=31490 Ode, gn=31378 geohot LLM, 요약문이 `## Topic Body` 직후 `> ` 로 시작하는 케이스) 이 첫 줄을 `>` blockquote 로 시작. 260차 정착 4종 패턴은 `>` 라인을 일반 paragraph 로 떨어뜨려 `<p>&gt; ...</p>` 같은 HTML escape 결과물 생성 (시각적이지 않고 원문 의도 파괴). **회피**: `md_to_html` 에 5번째 분기 `elif stripped.startswith(">"):` 추가 → `<blockquote>` 태그로 라우팅. **적용 범위**: §3.34.46 본문 빌드의 모든 변형 (`build_draft_*.py` / `gn-markdown-to-tistory-html.py`). 278차 첫 빌드에서 hit → 즉시 분기 추가하여 해결. 후속 차 본문 빌드 스크립트에는 분기 박혀있어 동일 패턴 적용 가능. **5번째 패턴 정착 (278차)**: 260차 4종 + 278차 `> ` blockquote = 5종. cleanup cron 임무 #34 신규 — `scripts/gn-markdown-to-tistory-html.py` 모듈에 blockquote 분기 자동 반영 권장.

- **§3.34.53 (277차, NEW, 실제 hit 없음, 사전 검증 패턴 정착)**: **`gn-fetch-content.py` 하이픈 vs 언더스코어 importlib 함정** — `import gn_fetch_content` (언더스코어) → `ModuleNotFoundError`. importlib `spec_from_file_location("gfc", ".../gn-fetch-content.py")` 패턴으로 짧은 alias 사용 권장. `gn-markdown-to-tistory-html.py`, `gn-fetch-md.py` 등 모든 하이픈 파일 동일 패턴. 본문 안 영문 자동완성 토큰 (`roadmap` / `load_map` / `loadmap`) 변환 가능성 — `grep -E "load_map|loadmap" build_draft_*.py` + draft.html 저장 직후 `re.search(r"load_map|loadmap", html_content)` 이중 검증. cleanup cron 임무 #33 신규 — `gfc` alias 표준화 + 자동 변환 guard 정규식 자동 삽입.

- **§3.34.52 (276차, NEW)**: **post_publish_sync CLI `--title` 인자 한글 IME 자동 변환 오타 함정** — `--title "Codex Micro - OpenAI가 Work Louder..."` 형태로 영문+한글 혼재 title을 `--title` 인자로 넘길 때, **macOS 한글 IME가 활성 상태**에서 `Work Louder` 같은 영문 단어가 `Lou더` (한글 자판 자동 변환) 로 박힘. sync 결과는 `triple_signal_match: true` 를 반환하지만 pt.last.title + state.last.title + state.details[-1].title 3필드가 모두 오타 박힘. 라이브 페이지 `<title>` 태그는 publish 단계의 별도 title 인자 (publish 단계는 정상 `Louder` 박힘) 와 sync 단계의 title 인자가 별개로 전달되어 영향 분기 → Tistory는 정상 표시하지만 pt/state는 오타. **회피**: (a) sync 호출 직전 `re.match(r"^[A-Za-z]+$", title.split()[i])` ASCII 토큰 sanity check. (b) sync 직후 pt/state 3필드 영문 검증. (c) 라이브 페이지 `<title>` cross-check (`curl -sL url | grep '<title>'`) — Tistory 표시 title과 pt/state 3필드 불일치시 json 직접 patch 로 3필드 모두 같은 값으로 덮어쓰기 보정. (d) IME OFF 후 title 작성. 258차 §3.11 CLI title 오타 함정 + 본 차 276차 IME 변환 함정의 영구 결합 가드. **적용 범위**: §3.11 post_publish_sync CLI 호출 시 `--title` 인자. cleanup cron 임무 #32 신규 — sync 스크립트에 ASCII 토큰 sanity check 자동화 권장.

- **§3.34.50 (272차, NEW)**: **`gn-fetch-content` 본문 추출 260차 정착 로직 한계 — `## Metadata` 다음 `- 키:값` 라인 skip** — 260차 정착 정규식이 `## Metadata` 이후 모든 `- ` 시작 라인 + 빈 줄을 메타데이터로 간주 skip. 그러나 GeekNews 일부 본문은 `## Topic Body` 후 첫 줄이 `- 신경망 발전에 기대를 걸었던 **20년 경력의 머신러닝 실무자**가 ...` 같은 meta 아닌 bullet 으로 시작 → skip 로직이 본문 bullet 까지 잘라내 body_html 이 67 bytes (정상 ~3000 bytes 대비 1/45) 로 떨어짐. 272차 첫 빌드에서 hit. **회피**: 본문 추출을 `## Topic Body` 헤더 마커 기반으로 정정. `re.search(r"## Topic Body\s*\n+(.*)", text, re.DOTALL)` 로 Topic Body 이후 본문만 잡고 `re.search(r"\n## Comments", body)` 로 Comments 직전 컷. 260차 4-step (frontmatter / metadata / comments skip) 로직 대신 사용 권장. 모든 `gn-fetch-content.py` 후속 본문 빌드 스크립트(특히 `scripts/gn-markdown-to-tistory-html.py` 가 본 빌드 호출시) 에 적용. 진짜 본문 길이 sanity check 必 — `len(re.sub(r"<[^>]+>", "", html))` 평문 길이가 300자 미만이면 본문 추출 단계 버그로 즉시 재추출. **영구화 위치**: `scripts/gn-fetch-content.py` 본문 추출 함수를 Topic Body 마커 기반으로 정정하거나, 후속 빌드 스크립트가 동일한 마커 기반 정규식으로 본문 추출. cleanup cron 임무 #29 신규 — 다음 차에 모듈 정정 패치 권장.
- **§3.34.51 (273차, NEW)**: **pt.details splice 누락 drift 케이스 — §3.34.40 v2 만으론 부족** — 271차 #1013 `Bonsai 27B` (gn=31450) 발행 후 pt.details array에 entry가 splice 누락된 상태로 박힘. 272차 §3.34.40 v2 (pt.last.gn_topic_id guard) 적용으로 FRESH 매칭에서는 31450 제외 OK지만 (v2가 정상 가드), pt.details 자체에는 271차 31450 entry가 부재 → 273차 cron에서 splice 누락 식별 (5중 신호 검증 중 state.details[-1] != pt.last 같은 비대칭으로 감지). 라이브 페이지 #1013 정상 Bonsai 27B 점유는 확인됨. **회피 (273차 임시 보정)**: splice backfill entry 직접 json append → 5중 신호 깨짐 → 즉시 entry 제거 후 publish → §3.11 sync가 새 publish URL 기준으로 자동 정정. **영구화 (cleanup cron 임무 #30 신규)**: (a) **FRESH 4-field v3 강화** — `pt.last.gn_topic_id` 만으론 부족. **publish URL 슬롯별 title prefix 매칭**으로 이미 발행된 주제 후보를 추가 검증. 예: pt.details에 없는 슬롯이라도 라이브 페이지에서 발행된 제목이 박혀있으면 FRESH 후보 제외. (b) **`scripts/cleanup-pt-details-splice.py` 신규** — historical splice 누락 자동 감지 + backfill (lib API로 라이브 페이지 슬롯 title 수집 후 pt/details 매칭 보정). 273차 임시 보정 흐름: ① splice backfill entry 추가 → ② 5중 신호 검증 → ③ state.details[-1]=#1013, pt.last=#1015 비대칭 감지 → ④ backfill entry 즉시 제거 → ⑤ 5중 신호 #1015 복구 → ⑥ publish → ⑦ §3.11 sync로 #1016 all_match 정정. **적용 범위**: §3.34.40 4-step 패턴 2단계 (FRESH 4-field 매칭) + §3.5 5중 신호 검증 직전 splice drift sanity check.
- **§3.34.40 v2 (272차, 보강)**: **FRESH 4-field 매칭 시 `pt.last.gn_topic_id` 도 pub set 에 포함** — 271차에 식별된 슬롯 덮어쓰기 drift 케이스에서 `pt.last.gn_topic_id=31450` 가 `pt.details` 의 마지막 항목에 splice 누락된 채로 박혀있음. v1 FRESH 4-field 매칭은 pt.details 와 state.details 만 lookup 하므로 31450 이 FRESH 로 오인되어 새 publish 후보로 pick. **회피**: `pt.last.gn_topic_id` 가 가리키는 topic_id 도 pub set 에 명시 추가. 272차 적용 결과 FRESH 8 → 7개 (31450 제외) 정확히 식별. **적용 범위**: §3.34.40의 4-step 패턴 2단계 (FRESH 4-field 매칭) 파이썬 스니펫. `pt_last_gn = str(pt.get('last',{}).get('gn_topic_id'))` 추출 후 `pt_published.add(pt_last_gn)` 호출.

- **§3.34.49 (271차, NEW)**: **이미지 업로드 endpoint 함정** — 직접 `requests.post` 로 Tistory 이미지 업로드 endpoint probe 시 `/manage/post/image`, `/manage/post/attach`, `/manage/post/photo` 모두 `405 Method Not Allowed` 반환 (text/html). 진짜 endpoint는 `/manage/post/attach.json` (`tistory_publisher.py` 의 `ATTACH_ENDPOINT` 상수). 정상 호출 패턴: `requests.post(ATTACH_ENDPOINT, files={"file": (fname, image_data, content_type)}, cookies=cookies, headers={"Accept":"application/json", "Origin":TISTORY_BLOG_URL, "Referer":f"{TISTORY_MANAGE_URL}/newpost/"}, timeout=15)` → `status=200, ct=application/json;charset=UTF-8`, JSON 응답에 `"url"` 필드로 `https://blog.kakaocdn.net/dna/...` 형태 CDN URL 반환. **참고용 함정 가이드**: cron 자동화에선 `tistory_publisher.py --image-query` 가 이 endpoint를 내부 호출하므로 직접 probe 불필요. 271차엔 디버깅 과정에서 endpoint 검증하다 405 받음 → `ATTACH_ENDPOINT` 로 정정하여 정상 CDN 업로드 확인. 차감/추가 없음 — 가이드 추가만으로 충분.
- **§3.34.48 (266차, NEW)**: **GeekNews 본문 `* ` 들여쓰기 리스트 패턴 추가 함정** — GeekNews 31432 (Papermake) 본문이 `- ` 외 `* ` 들여쓰기 패턴을 혼용 (`* 완전한 감사 추적(Audit Trail)` 등). 262차 정착 `md_to_html` 은 `- ` 만 처리하여 `* ` 라인이 그냥 `<p>` 로 떨어져 들여쓴 sub-list가 시각적으로 평평한 본문으로 변환됨. **회피**: `md_to_html` 에 `elif stripped.startswith("* ") and not stripped.startswith("**"):` 분기 추가 (bold `**` 시작은 제외) → `* ` 도 동일하게 `<ul><li>` 변환. 266차 첫 빌드에서 hit → 즉시 분기 추가하여 해결. **적용 범위**: §3.34.46 본문 빌드의 모든 변형. 266차 검증: 빌드 스크립트에 정규식 `md_norm = re.sub(r"^#### (.+)$", r"### \1", md, flags=re.MULTILINE)` (4단계 헤더 → 3단계 강등) + `* ` 분기 추가하여 266차 Papermake 본문 정상 처리. 차감/추가 없음 — 4단계 헤더 (####) 와 `* ` 들여쓰기는 GeekNews 마크다운의 일반적 변형으로 빈번히 등장.
- **§3.34.47 (263차, NEW)**: `/usr/bin/python3` 격리 패턴의 inline bash heredoc 안에서 길이가 30줄이 넘어가는 본문 빌드/HTML 변환 스크립트를 적을 때, §3.34.41 f-string 백슬래시 제약 + 본문 문자열 안의 `\"` escape + 한글 UTF-8 본문이 한꺼번에 걸려 `SyntaxError: Non-UTF-8 code starting with '\xec'` 또는 `SyntaxError: f-string expression part cannot include a backslash` 가 연쇄 발생. 263차 첫 시도에서 `md_to_html` (본문 2801자) + intro/conclusion (각 540/1700자) + 4종 escape + f-string 안 `item_text.split(\" \",1)[1]` 가 한 heredoc 안에 들어감. **회피**: `write_file` 로 빌드 스크립트를 `/tmp/<session>/build_draft.py` 에 `# -*- coding: utf-8 -*-` 선언과 함께 저장 → `python3 <script>.py` 로 격리 호출. **적용 범위**: §3.34.46 본문 빌드 / 다중 카테고리 한도 처리 / 인트로+본문+결론 합치기 등. 단일 probe (가드 / sync / state 확인) 처럼 5~10줄짜리 short heredoc은 §3.34.41 정정 (string concat) 으로 충분. **266차 검증**: 동일 패턴 3회째 정상 적용 (`/tmp/tistory_drafts_266th/build_draft.py`, 5618 bytes 빌드 스크립트 무영향).
- **§3.34.46 (259차 식별, 260차 실전 검증, 261차 영구화 완료 ✅)**: `scripts/gn-fetch-content.py`의 `GN_MD_URL` 상수가 `https://news.hada.io/topic.md?id={tid}` 형태 (stale) 였는데, 긱뉴스의 실제 작동 URL은 `/topic/{tid}.md`. 1단계 `.md` fallback이 항상 fail → step 2 HTML fallback (비표준 마크업 함정) / step 3 RSS fallback (짧은 길이 함정) 까지 fallthrough. 259차 1251 bytes / 260차 8952 bytes 임시 우회로 검증 → **261차 cleanup cron 임무 #23 영구화 완료**: `GN_MD_URL = GN_TOPIC_BASE + "/{tid}.md"` + `GN_TOPIC_BASE` 정의 순서 보정. `_try_md_endpoint(31378)` 테스트 → status=200, 9590 bytes. **임시 우회 heredoc 패턴 불필요** — public API `fetch_gn_content(tid)` 또는 `_try_md_endpoint(tid)` 직접 호출. **영구화 시 두 가지 코드 함정 (261차 식별)**: (1) `GN_MD_URL = f"{GN_TOPIC_BASE}/{{tid}.md"` 형태는 모듈 로드 시점에 line 순서대로 f-string 평가 → line 48에서 `GN_TOPIC_BASE` 미정의로 `NameError` → string concatenation 사용; (2) `GN_TOPIC_BASE` 정의가 `GN_MD_URL` 뒤에 있으면 안 됨 (앞 줄에 정의). 본문 → Tistory HTML 변환 4종 패턴 + editorial 인트로/결론 패턴 260차 정착 그대로 유효.
- **§3.34.45 (256차, NEW)**: **#21 가이드 경계 조건 + '기타' 제외 정책 우선순위** — `blog_pipeline.py` §1448~1456 (2026-06-08 영구화) 가 '기타' 카테고리를 발행 대상에서 제외. §3.34 #21 가이드 "AI/ML FRESH=0 이면 다른 카테고리 발행 허용" 은 '기타' 카테고리에는 적용 안 됨. **우선순위**: `'기타' 제외 > #21 AI/ML 우선`. FRESH 후보 매트릭스별 결정:
  - FRESH 모두 '기타' → **skip** (256차 실전 1호)
  - FRESH '기타' + 'AI/ML' 혼재 → **AI/ML 픽** (#21)
  - FRESH '기타' + 'AI/ML 외 다른 카테고리' 혼재 → **다른 카테고리 발행 허용** (#21 + '기타' 제외)
  - FRESH 'AI/ML' 단독 또는 'AI/ML' + 비-기타 혼재 → **AI/ML 픽** (#21)
  - FRESH 모두 'AI/ML 외 비-기타' → **점수 1순위 픽** (카테고리 균형, §3.34.39)
- **§3.34.44 (253차 식별 → 254차 실전 검증 완료, NEW)**: cron 차 사이 last URL drift — 사전 검증에서 `state.last_published_url` 이 직전 cron 차의 마지막 URL이 아닐 수 있음 (자정 사이 또는 외부에서 추가 발행된 흔적). **5중 검증 모두 일치 유지되어 drift 무해**가 확인됨 (254차: 사전 `#985` → 사후 `#986`, 모두 일치). 그러나 cron 자동화 워크플로에서 **pt/details 비교시 항상 현재 시점의 last url 을 source-of-truth로 사용**해야 함 — 직전 cron 차 reference의 last URL 과 비교하지 말 것. 코드 패치 불필요 (§3.5 5중 검증 + §3.11 sync 가 이미 drift-immune). 운영 가이드 추가: cron 차 사이 한 건 이상의 외부 발행이 일반화될 수 있음을 인정 (수동 발행, 다른 cron 인스턴스 등).
- **§3.34.43 (247차, NEW)**: `env -i HOME=... PATH=... /bin/bash -c '...'` 호출 시 bash 스타트업 시 자동 `cd /Users/mac/.hermes/repos/icbm2-knowledge-graph` 시도 → `bash: 행 N번: cd: ...: No such file or directory` 로 exit 126, 본 python3 호출 안 됨. **회피**: `cd /Users/mac` 명시 또는 `PWD=/Users/mac` 환경변수 추가. 모든 격리 패턴 호출에 적용.
- **§3.34.42 (246차, NEW)**: `verify-tistory-cookie.sh` [5]단계의 `tistory_publisher.py --check-session`가 **매 cron마다 §3.8.2 격리 함정**(hermes venv urllib3 2.6.x ≠ Python 3.11.15)으로 FAIL — 실제 세션 정상이어도 스크립트 리포트는 "FAIL=1". `env -i` + `/usr/bin/python3` 격리 패턴으로 probe 한 posts.json / category.json 은 HTTP 200 + JSON (2xx, 302 없음), §3.5 5중 신호 일치, 세션 진짜 정상. **패치 후보**: 스크립트 [5] 단계를 격리 패턴 호출로 교체 (e.g. `env -i HOME=... PATH=... /usr/bin/python3 /Users/mac/.hermes/scripts/tistory_publisher.py --check-session`). 246차엔 패치 미적용 — 운영자가 (a) 무시 운영 vs (b) 스크립트 격리화 선택.
- **§3.34.41 (245차, NEW)**: **`/usr/bin/python3` (Python 3.9) 는 f-string 내부에 백슬래시 quote 미허용** — `SyntaxError: f-string expression part cannot include a backslash`. §3.8.1 가드 heredoc에 흔히 적힌 `print(f"... ct={r.headers.get(\"content-type\",\"\")[:50]}")` 패턴이 3.9에서 SyntaxError → 가드 자체가 막혀 **세션 만료 오판 + 가짜 발행 가드 무력화** 위험. 회피: string concatenation `print("... ct=" + r.headers.get("content-type","")[:50])`. 또는 `%` formatting. 또는 `content_type = r.headers.get("content-type","")[:50]` 변수 추출 후 f-string 외부 사용. 격리 패턴(`/usr/bin/python3`)은 3.9다 — 항상 이 제약이 적용됨. (§3.8.2 격리 패턴, §3.34.40 후보 pick 패턴의 모든 heredoc에 적용.)
- **§3.34.40 (244차)**: 후보 직접 점수 pick + FRESH 4-field 매칭 패턴 영구화. `blog_pipeline.py --category` 단독 호출 pick 버그 회피. **§3.5 5중 신호 영구 보정**: 242차 본문이 `pt.last.url = state['published_topics']['last'].url` 였는데 state.json엔 `published_topics` 키 부재. 진짜 pt는 `~/.hermes/memory/published_topics.json` 별도 파일 (state가 아니라). **격리 패턴 정정**: `env -i bash -c 'set -a; source tistory.env; set +a; python3'` (source 단계도 격리 안). **execute_code cron 차단**: `BLOCKED: ... bypass shell-string approval checks` → write_file + tistory_publisher.py --file 우회.
- **§3.34.39 (243차)**: **`blog_pipeline.py --category '<cat>'` 의 후보 pick이 점수 무관** — fresh 후보(예: 19점 LLM 번아웃) 대신 마지막 published 토픽 주변을 순환 pick (3점 31301 → 이미 발행된 Tencent Hy3). cron 자동 발행에서 `--category` 단독 호출은 가짜 pick 위험. 대안은 후보 목록을 직접 점수 정렬 후 `record_published_topic`로 명시 처리. **`--force-topic <id>` 는 source_url/topic_url을 빈 값** 으로 박음 → publish 단계의 tistory_publisher.py --source-url 인자로 전달 불가. cron 컨텍스트 본문 발행은 사실상 불가. **`post_publish_sync.py sync-from-pt` 가 잘못된 state 경로 lookup** — 코드: `~/.hermes/state/tistory_state.json` (부재), 진실: `~/.hermes/memory/blog_pipeline_state.json`. 결과 `pt_updated: true` 만 보고하고 state는 noop (다음 차 코드 패치 권장 — `STATE_FILE = HERMES_DIR / 'memory' / 'blog_pipeline_state.json'` 으로 정규화).
- **§3.34.38 (242차)**: `tistory_publisher.py`에 `--topic-url` / `--auto-record` 옵션은 **존재하지 않음** → `unrecognized arguments` 에러. 진짜 옵션은 `--source-url <URL>` + `--gn-topic-id <N>` 분리. 또한 §3.5 신호 검증은 **3중이 아니라 5중** (state.last_published_url + state.last.url + state.details[-1].url + pt.last.url + pt.details[-1].url — **단 244차 보정: pt는 published_topics.json 별도 파일**).
- **§3.34.37 (241차)**: `tistory_publisher.py`가 pt/state/stats 자동 동기화 안 함 → `scripts/post_publish_sync.py` 신규 (publish 후 필수 호출). **CLI는 `sync` 서브커맨드 필수** (242차 확인).
- **§3.34.36 (239차)**: `blog_pipeline.py --record` 3-arg가 `pt['last'].url = None` 박기 가능 → (a') pt['last'].url 별도 검증 필수. `scripts/blog-pipeline-record-url-guard.py` 권장.
- **§3.34.33 (238차)**: `post-publish-correct.sh` 5-1단계 heredoc이 cat_id("1219746")를 stats key로 박는 버그 — `scripts/cleanup_daily_cat_id_leak.py`로 자동 보정 (cleanup cron 임무 #16).
- **§3.34.34 (238차)**: `gn-fetch-content` 본문 필요시 `importlib.util.spec_from_file_location()` 로 모듈 로드 후 `result[1]` 참조 (CLI는 300자 preview만). 함수명 `fetch_gn_content` (244차 확인), 결과 `(title, content, source)` tuple.
- **§3.34.35 (238차)**: `--image-query` cron 전달 의무 — Picsum router 자동 매핑은 동작하나 cron 프롬프트 누락시 본문 그림 0장.
- **§3.34.32 (236차)**: `tistory_publisher.py --category`는 int ID만 허용 (`AI/ML` 문자열 실패), `state.daily_counts` 구조는 `{date: {category: count}}` dict-of-dict-of-int.
- **§3.34.31 (235차)**: pt와 state 두 파일 drift 가드 — `post-publish-correct.sh`는 pt만 동기화, state 6단계 sync heredoc 매 세션 필수 → 241차 `post_publish_sync.py`로 영구화.
- **§3.34.30 (234차)**: `blog_pipeline.py --category`는 guideline만 출력, 실제 publish는 `tistory_publisher.py --file /tmp/draft.md` 명시 호출이 표준.
- **§3.34.29 (233차)**: `commit_publish` + `record_published_topic` 분기 — 단일 박기 자동 보정 불가, 수동 heredoc 보정 필수 → 241차 `post_publish_sync.py`로 부분 해결.
- **§3.34.28 (231차)**: §3.30.4 historical drift 자동 복구 가드 한계 — cleanup cron 임무 #15 health check 알림만.

## cleanup cron 임무 상태 (264차)

- **#1 (retroactive-gn-topic-id)**: 영구화 미완료, historical drift 누적 (231차 ~920 / 248차 갱신 필요)
- **#12 (gn-fetch-content 영구화)**: claim 거짓 — 실제 위치 `scripts/gn-fetch-content.py <topic_id>` (positional), 결과는 `(title, content, source)` tuple (245차 확인)
- **#16 (daily cat_id 누설 cleanup)**: ✅ 영구화 완료 (`scripts/cleanup_daily_cat_id_leak.py`), **54회 연속 all-green** (213~267차)
- **#15 (state.details drift health check)**: 신규, 알림만 (가짜 publish 가드 깨질 위험)
- **#17 (post_publish_sync 영구화, 241차)**: ✅ 신규 완료 (`scripts/post_publish_sync.py`) — 매 세션 §3.11 5-1 heredoc 대체
- **#18 (f-string §3.8.1 SyntaxError 트랩, 245차)**: 🆕 식별 — 코드 패치 후보: `scripts/guard_tistory_session_39safe.py` (3.9 호환 문자열 처리) 또는 SKILL.md §3.8.1 템플릿을 모두 `%`-formatting / concatenation 으로 정규화. 246차 본문 코드블록은 정정 완료 (이 README 본문은 245차 수정본).
- **#19 (격리 패턴 PWD/cd 자동 cd 함정, 247차)**: 🆕 식별 (§3.34.43) — `env -i ... bash -c '...'` 호출 시 bashrc 자동 `cd` 가 exit 126 유발. SKILL.md 모든 격리 bash 예시에 `PWD=/Users/mac` 또는 `cd /Users/mac` 보강 완료 (247차). 코드 패치 불필요 (bashrc는 hermes 셸 환경 종속 → SKILL.md 가이드로 충분).
- **#20 (cron 차 사이 last URL drift, 253차 식별 → 254차 실전 검증 완료)**: ✅ **확정** (§3.34.44) — 사전 검증에서 `state.last_published_url` 이 직전 cron 차의 `#985` 으로 박혀있음 (자정 사이 추가 발행된 흔적). **5중 검증 모두 일치 유지되어 drift 무해** 확정. cron 자동화 워크플로에서 "이전 cron 차 사이 한 건 이상이 발행될 수 있다"는 사실 영구화. pt/details 비교시 항상 **현재 시점의 last url** 을 source-of-truth로 사용할 것. 코드 패치 불필요 (§3.5 5중 검증 + §3.11 sync 가 이미 drift-immune).
- **#21 (카테고리 균형 + AI/ML 우선 가이드, 254차)**: 🆕 식별 — 254차에 FRESH 1순위가 개발도구였음 (AI/ML TOP 8개 모두 처리됨). **운영 가이드**: AI/ML 후보가 1개 이상 FRESH이면 무조건 AI/ML 우선. AI/ML FRESH가 0이면 다른 카테고리 발행 허용 (FRESH 4-field 매칭이 가짜 발행 가드이므로 카테고리 혼재 위험 없음). 코드 패치 불필요 (§3.34.40 후보 직접 점수 pick 패턴이 이미 점수 기준 자동 정렬).
- **#22 (#21 경계 조건 + '기타' 제외 정책 우선순위, 256차)**: 🆕 식별 (§3.34.45) — `blog_pipeline.py` §1448~1456 (2026-06-08 영구화) 가 '기타' 카테고리를 발행 대상에서 의도적 제외. #21 가이드는 '기타' 카테고리에 적용되지 않음. **정책 우선순위**: `'기타' 제외 > #21 AI/ML 우선`. FRESH 후보 매트릭스별 결정 가이드 §3.34.45 참조. 256차 실전 1호: FRESH 후보 2개 모두 '기타' (31338 Android 앱→웹페이지 1.0점 / 31359 세그멘테이션 오류 0.5점) → 정상 skip. 코드 패치 불필요 (가짜 발행 가드는 FRESH 4-field 매칭으로 동작, 정책 우선순위 명확화로 충분).
- **#23 (gn-fetch-content URL 형식 stale, 259차 식별 → 260차 실전 검증 → 261차 영구화 완료 ✅)**: ✅ **영구화 완료** — `scripts/gn-fetch-content.py` 의 `GN_MD_URL = GN_TOPIC_BASE + "/{tid}.md"` + `GN_TOPIC_BASE` 정의 순서 정정 (line 48에서 line 49로 이동) + `_try_md_endpoint` docstring 갱신. 261차에 `_try_md_endpoint(31378)` 테스트 → status=200, 9590 bytes 정상 fetch. 1단계 `.md` endpoint가 즉시 성공. 259차/260차 임시 우회 패턴(`requests.get(f"https://news.hada.io/topic/{tid}.md")`)이 더 이상 필요 없음 — cleanup cron 임무 #23 종료.
- **#24 (inline heredoc UTF-8 한글 + f-string 제약 동시 hit, 263차 식별 → 264차 실전 검증 → 265차 두 번째 검증 → 266차 세 번째 검증 ✅)**: 🆕 식별 → ✅ **실전 검증 완료 (3회)** (§3.34.47) — `env -i ... bash -c '... << PYEOF ... PYEOF'` 형태로 길이 30줄+ 본문 빌드/HTML 변환 스크립트를 inline heredoc에 직접 적으면, §3.34.41 f-string 백슬래시 제약 + 본문 안 `\"` escape + 한글 UTF-8 본문 문자열이 한꺼번에 걸려 `SyntaxError: Non-UTF-8 code starting with '\xec'` 또는 `f-string expression part cannot include a backslash` 가 연쇄 발생. 263차 첫 시도에서 hit → SKILL.md 가이드 추가. **264차 검증**: `#1000` 본문 빌드 (`/tmp/tistory_drafts_264th/build_draft.py`, 99줄) 에 `write_file` + 격리 호출 패턴 실전 적용 → 정상 동작 (md_to_html 본문 2088자 + intro/conclusion 540+1700자 + UTF-8 한글 + f-string 안 백슬래시 quote 모두 무영향). **265차 검증**: `#1002` 본문 빌드 (`/tmp/tistory_drafts_265th/build_draft.py`, 약 90줄) 에 동일 패턴 반복 적용 → 정상 동작 (md_to_html 본문 1979자 + intro 1단락 + conclusion 한국 개발 환경 5가지 적용 단계 + UTF-8 한글 + f-string 안 백슬래시 quote 모두 무영향). **266차 검증**: `#1003` 본문 빌드 (`/tmp/tistory_drafts_266th/build_draft.py`, 5618 bytes) 에 동일 패턴 3회째 적용 → 정상 동작 (md_to_html 본문 890자 + intro 1단락 + conclusion 한국 SI/스타트업 시사점 + UTF-8 한글 + `* ` 들여쓰기 리스트 패턴 + 4단계 헤더 강등 정규식 모두 무영향). **적용 범위**: §3.34.46 본문 빌드 / 다중 카테고리 한도 처리 / 인트로+본문+결론 합치기 등. 단일 probe (가드 / sync / state 확인) 처럼 5~10줄짜리 short heredoc은 §3.34.41 정정 (string concat) 으로 충분. SKILL.md 본문 + "절대 하지 말 것" 박스에 §3.34.47 항목 추가 완료.
- **#25 (`md_to_html` `* ` 들여쓰기 리스트 패턴 + 모듈 import 함정, 266차 식별, 즉시 보완)**: 🆕 식별 — (a) GeekNews 본문이 `- ` 외 `* ` 들여쓰기 패턴을 혼용 (`* 완전한 감사 추적(Audit Trail)`) — 262차 정착 `md_to_html` 은 `- ` 만 처리하여 `* ` 라인이 `<p>` 로 떨어짐 → `elif stripped.startswith("* ") and not stripped.startswith("**"):` 분기 추가하여 `<ul><li>` 변환 보강. (b) `import tistory_publisher; tistory_publisher.publish(...)` 시도 → `AttributeError: module 'tistory_publisher' has no attribute 'publish'` (모듈에 `publish` 함수 부재, **CLI 인터페이스만 지원**). 회피: `subprocess` 로 `python3 /Users/mac/.hermes/scripts/tistory_publisher.py --title ... --file ...` 호출하거나 `terminal` + 격리 bash 패턴 (§3.34.40 4단계 패턴 4번 항목 그대로). 코드 패치 불필요 — 가이드 추가만으로 충분. SKILL.md 본문 + "절대 하지 말 것" 박스에 §3.34.48 + 모듈 import 함정 항목 추가 완료.
- **#26 (cleanup cron 임무 #16 56회 연속 all-green + §3.34 #21 정책 실전 4호, 269차 검증 완료)**: 🆕 식별 — 269차에 FRESH 후보 단독 (개발도구 `31417` 4점 단일) 케이스에서 §3.34 #21 정책 + §3.34.45 매트릭스 5번째 분기 정상 동작 확인. cleanup cron 임무 #16 `cleanup_daily_cat_id_leak.py` dry-run 55→56회 연속 all-green 유지. Picsum ID 449 자동 매칭 (rust crates.io source code viewer query) — 두 슬롯 모두 동일 ID 자동 매칭, 첫 시도 적중. 코드 패치 불필요 — §3.34 #21 정책 + §3.34.45 매트릭스 가이드 그대로 유효. 차감/추가 없음.
- **#27 (cleanup cron 임무 #16 57회 연속 all-green + §3.34 #21 정책 실전 5호 + §3.34.44 자정 사이 외부 발행 drift 무해 2호 검증, 270차 검증 완료)**: 🆕 식별 — 270차에 (a) FRESH 10개 중 AI/ML 7 + 비-AI/ML 3 혼재 케이스에서 §3.34 #21 정책 + §3.34.45 매트릭스 4번째 분기 "FRESH 'AI/ML' + 비-기타 혼재 → AI/ML 점수 1순위 픽" 정상 동작 확인 (255차 1호, 266차 2호, 268차 3호, 269차 4호 → **270차 5호**). (b) 사전 검증에서 `state.last_published_url`이 `#1011` (자정 사이 외부 발행 흔적) 로 박혀있고, TOP 12개 후보 중 2개 (31449 Codex, 31437 Precursor) 가 이미 pt/state 양쪽에 정상 sync — §3.5 5중 검증 모두 일치 유지, FRESH 4-field 매칭이 정상 FRESH 10개를 정확히 식별. **§3.34.44 자정 사이 외부 발행 drift 무해 2호 검증** (254차 1호 → **270차 2호**). cron 차 사이 한 건 이상의 외부 발행이 일반화될 수 있음을 다시 한번 확인. cleanup cron 임무 #16 dry-run 56→57회 연속 all-green 유지. Picsum ID 838 자동 매칭 (claude code hook message display replacement code terminal query) — 두 슬롯 모두 동일 ID 자동 매칭, 첫 시도 적중. 코드 패치 불필요 — 모든 기존 패턴(§3.5 5중 검증, §3.11 sync, §3.34 #21 정책 + #45 매트릭스, §3.34.44 drift 무해, §3.34.47 격리 빌드, §3.34.48 `* ` 분기) 그대로 유효. 차감/추가 없음.
- **#28 (cleanup cron 임무 #16 58회 연속 all-green + §3.34 #21 정책 실전 6호 + §3.34.44 슬롯 덮어쓰기 drift 케이스 3호 + §3.34.49 이미지 endpoint 함정, 271차 검증 완료)**: 🆕 식별 — 271차에 (a) FRESH 8개 중 AI/ML 5 + 개발도구 1 + 개발팁 2 혼재 케이스에서 §3.34 #21 정책 + §3.34.45 매트릭스 분기 1 정상 동작 확인 (255차 1호, 266차 2호, 268차 3호, 269차 4호, 270차 5호 → **271차 6호**). (b) **§3.34.44 슬롯 덮어쓰기 drift 케이스 3호 (NEW, 271차 식별)**: 사전 검증에서 `state.last_published_url`이 `#1013 + gn=31458`로 박혀있었으나 (자정 사이 외부 발행 흔적), 실제 Tistory 라이브 페이지의 `#1013` 슬롯은 우리 publish 인 `gn=31450 Bonsai 27B` 가 점유. 즉 자정 사이 외부 발행이 슬롯 `#1013` 을 차지하고 있었고 우리가 그 슬롯을 덮어쓰며 publish. `post_publish_sync` 가 우리 publish (`gn=31450`) 기준으로 pt/state/details/last/stats 모두 정정 박아서 §3.5 5중 검증 일치 유지 — drift → sync 자동 보정 사이클 정상 (253차 식별 → 254차 1호 → 270차 2호 → **271차 3호**). (c) **§3.34.49 이미지 업로드 endpoint 함정 (NEW, 271차 식별)**: 직접 probe 시 `/manage/post/image`, `/manage/post/attach`, `/manage/post/photo` 모두 405 → 진짜 endpoint는 `/manage/post/attach.json` (ATTACH_ENDPOINT 상수). cron 자동화에선 `--image-query` 가 내부 호출하므로 직접 probe 불필요. cleanup cron 임무 #16 dry-run 57→58회 연속 all-green 유지. Picsum ID 자동 매칭 (bonsai-27b-mobile-on-device-ai-smartphone-tree query) — 첫 시도 적중. 코드 패치 불필요 — 가이드 추가만으로 충분 (drift 패턴 + endpoint 함정 둘 다 자동화 워크플로에서 외부 영향 없음). 차감/추가 없음.
- **#29 (gn-fetch-content 본문 추출 Topic Body 마커 기반 정착, 272차)**: 🆕 — 260차 정착 "## Metadata skip" 로직이 일부 본문(`## Topic Body` 직후 `- 신경망 ...` bullet 시작)에서 body_html 67 bytes 로 잘림. **회피**: `## Topic Body` 헤더 마커 기반 추출 (`re.search(r"## Topic Body\s*\n+(.*)", text, re.DOTALL)` + Comments 직전 컷). `scripts/gn-fetch-content.py` 본문 추출 함수 Topic Body 마커 기반으로 정정 권장 (cleanup cron 임무 미완료). 연속 all-green 59회차 유지.
- **#30 (pt.details splice 누락 drift, 273차 식별 → 274차 1회 검증)**: 🆕 — 271차 #1013 `Bonsai 27B` (gn=31450) 발행 후 pt.details array에 splice 누락 → 273차 5중 신호 비대칭 감지. **회피**: §3.34.40 v3 강화 (publish URL 슬롯별 title prefix 매칭) + `scripts/cleanup-pt-details-splice.py` 신규 모듈 권장 + splice drift sanity check. cleanup cron 임무 미완료.
- **#31 (274차 §3.34.50 Topic Body 1회 검증 + §3.34.51 splice 잔재, 영구화 미완료)**: 🆕 — 274차 `_try_md_endpoint(31451)` → Topic Body 마커 추출로 평문 2158자 정상 (§3.34.50 2호 검증). pt.details idx=109 entry의 `topic` 필드에 title 전체 잔재 발견. 연속 all-green 61회차. cleanup cron 임무 #30 신규 모듈 권장 유지.
- **#32 (276차 §3.34.52 sync CLI title IME 자동 변환 오타 함정 1호 식별, 영구화 미완료)**: 🆕 식별 — 276차 `#1023 Codex Micro` 발행 시 post_publish_sync CLI `--title` 인자에 `Work Louder` 같은 영문+한글 혼재 토큰 + macOS 한글 IME 활성 상태 → `Louder` → `Lou더` 자동 변환. sync 결과 `triple_signal_match: true` 반환했지만 pt.last.title + state.last.title + state.details[-1].title 3필드 모두 오타 박힘. 라이브 페이지 `<title>` 태그는 publish 단계의 별도 title 인자로 정상 표시 → 5중 신호 검증으로는 못 잡는 hidden drift. 276차 즉시 정정: json 직접 patch로 3필드 모두 `Work Louder` 로 덮어쓰기. **영구화 권장** (`scripts/post_publish_sync.py`): (a) CLI 호출 직전 `--title` 인자 ASCII 토큰 sanity check (`re.match(r"^[A-Za-z]+$", word)`) + 한글+영문 혼재 경고. (b) sync 직후 pt/state 3필드 영문 검증 자동 보고. (c) 라이브 페이지 `<title>` cross-check 자동화 (`curl -sL url | grep '<title>'` 결과와 pt/state.title 비교 후 불일치시 경고). (d) IME OFF 후 title 작성 권장 메시지. 기존 패턴(§3.8.1 가드 / §3.8.2 격리 / §3.11 sync CLI `sync` 서브커맨드 / §3.34.40 v2 / §3.34.43 PWD / §3.34.46 영구화 / §3.34.47 격리 빌드 / §3.34.48 `*` 분기 / §3.34.49 endpoint / §3.34.50 Topic Body / §3.34.51 splice backfill / §3.34 #21 정책 / §3.34.45 매트릭스 / cleanup cron 임무 #16) 모두 276차 4회째 정상 동작 — 연속 all-green **63회차 (213~276차)** 유지. Picsum ID 583 자동 매칭 (mechanical keyboard rgb joystick macro pad agent control desk accessory query) 첫 시도 적중. cleanup cron 임무 #16 dry-run 62→**63회** 연속 all-green 유지. 차감/추가 없음 — 가이드 추가만으로 충분.
- **#33 (277차 §3.34.53 `gn-fetch-content.py` 하이픈 importlib + 본문 영문 자동완성 변환 guard, 영구화 미완료)**: 🆕 식별 — 277차 `#1024` 발행 시 `import gn_fetch_content` (언더스코어) 시도 → `ModuleNotFoundError`. `gn-fetch-content.py`, `gn-markdown-to-tistory-html.py`, `gn-fetch-md.py` 등 모든 하이픈 파일 동일 패턴. 277차엔 `importlib.util.spec_from_file_location("gfc", ".../gn-fetch-content.py")` 짧은 alias로 정상 fetch. 본문 안 영문 자동완성 토큰 (`roadmap` / `load_map` / `loadmap`) 변환 가능성은 277차엔 `로드맵` 한국어로 대체하여 무영향. **영구화 권장**: (a) 모든 빌드 스크립트에서 `gfc` alias 표준화. (b) `grep -E "load_map|loadmap" build_draft_*.py` + draft.html 저장 직후 `re.search(r"load_map|loadmap", html_content)` 이중 검증 자동화. 기존 패턴(§3.8.1 가드 / §3.8.2 격리 / §3.11 sync CLI / §3.34.40 v2 / §3.34.43 PWD / §3.34.46 영구화 / §3.34.47 격리 빌드 / §3.34.48 `*` 분기 / §3.34.50 Topic Body / §3.34.52 IME 변환 / §3.34 #21 정책 / §3.34.45 매트릭스 / cleanup cron 임무 #16) 모두 277차 5회째 정상 동작 — 연속 all-green **64회차 (213~277차)** 유지. Picsum ID 699 자동 매칭. cleanup cron 임무 #16 dry-run 63→**64회** 연속 all-green 유지.
- **#36 (281차 §3.34 #21 AI/ML 우선 정책 실전 8호 + cleanup cron 임무 #16 68회 연속 all-green, 281차 검증 완료)**: 🆕 식별 — 281차에 FRESH 5개 중 AI/ML 4 + 개발도구 1 + 개발팁 1 (개발팁 14점 후보 포함) 혼재 케이스에서 §3.34 #21 정책 + §3.34.45 매트릭스 4번째 분기 "FRESH 'AI/ML' + 비-기타 혼재 → AI/ML 점수 1순위 픽" 정상 동작 확인 (255차 1호, 266차 2호, 268차 3호, 269차 4호, 270차 5호, 271차 6호, 280차 7호 → **281차 8호**). 비-AI/ML 후보가 더 높은 점수를 가지고 있어도 AI/ML 정책이 우선 → 개발팁 14점 후보 자동 제외, AI/ML 6점 픽 확정. 기존 패턴(§3.8.1 가드 / §3.8.2 격리 / §3.11 sync CLI / §3.34.40 v2 / §3.34.43 PWD / §3.34.46 영구화 / §3.34.47 격리 빌드 / §3.34.48 `*` 분기 / §3.34.50 Topic Body / §3.34.52 IME 변환 / §3.34.53 `gfc` alias / §3.34.54 `>` blockquote / §3.34.55 시그니처 / §3.34 #21 정책 / §3.34.45 매트릭스 / cleanup cron 임무 #16) 모두 281차 3~8회째 정상 동작 — 연속 all-green **68회차 (213~281차)** 유지. Picsum ID 1024 자동 매칭 (claude ai chat memory coffee shop leak data exfiltration prompt injection query) — 두 슬롯 모두 동일 ID 자동 매칭, 첫 시도 적중. cleanup cron 임무 #16 dry-run 67→**68회** 연속 all-green 유지. **사소한 관찰 (281차 1회성, 영구화 불필요)**: `blog_pipeline.py --json` 옵션은 존재하지 않음 (`--refresh-topics` 가 stdout 으로 JSON 부분 dump) → 2>/dev/null 로 stderr 분리 후 `text[text.find("{"):text.rfind("}")+1]` 슬라이스 파싱 또는 `grep -E 'URL:|score|category'` 텍스트 파싱 권장. 본 세션 신규 발견 0건 — 모든 패턴 정착. 차감/추가 없음.
- **#35 (`gfc` 시그니처 함정 2종 — `fetch_gn_content` / `_try_md_endpoint` shape 불일치, 279차 식별, 영구화 미완료)**: 🆕 식별 — (a) `gfc.fetch_gn_content(tid)` 호출이 SKILL.md §3.34.34 (244차 확인) 가이드와 달리 279차 첫 시도에서 `TypeError: 'NoneType' object is not subscriptable` 반환. 실제 함수가 `Optional[Tuple[...]]` 으로 None 반환 → tuple unpack 시 NoneType subscriptable 에러. (b) `gfc._try_md_endpoint(tid)` 는 단일 문자열 반환 (`Optional[str]`) 이지만 `status, text = ...` 형태로 적으면 `ValueError: too many values to unpack (expected 2)` 가 터질 위험 (279차엔 단일 변수 할당으로 회피). 279차에 본문 빌드는 `_try_md_endpoint(tid)` 단일 함수만 사용 확정. **영구화 권장** (`scripts/gn-fetch-content.py`): (i) 두 public 함수의 정확한 시그니처 + None 가능성을 module docstring에 명시. (ii) `fetch_gn_content(tid)` 결과를 호출자가 무조건 None 체크하도록 가드 추가. (iii) SKILL.md §3.34.34 박스 코드 스니펫을 `_try_md_endpoint(tid)` 단일 호출로 통일. 기존 패턴(§3.8.1 가드 / §3.8.2 격리 / §3.11 sync CLI / §3.34.40 v2 / §3.34.43 PWD / §3.34.46 영구화 / §3.34.47 격리 빌드 / §3.34.48 `*` 분기 / §3.34.50 Topic Body / §3.34.52 IME 변환 / §3.34.53 `gfc` alias / §3.34.54 `>` blockquote / §3.34 #21 정책 / §3.34.45 매트릭스 / cleanup cron 임무 #16) 모두 279차 4~7회째 정상 동작 — 연속 all-green **66회차 (213~279차)** 유지. Picsum ID 851 자동 매칭 (ai ethics governance google deepmind resignation contract framework query) — 두 슬롯 모두 동일 ID 자동 매칭, 첫 시도 적중. cleanup cron 임무 #16 dry-run 65→**66회** 연속 all-green 유지. 코드 패치 1건 권장 (`scripts/gn-fetch-content.py` docstring + 가드 추가). 차감/추가 없음.
- **#34 (278차 §3.34.54 `> blockquote` 라우팅 분기 + 5번째 패턴 정착, 영구화 미완료)**: 🆕 식별 — 278차 `#1025 Ode` 발행 시 `md_to_html` 4종 패턴(`## 헤더` / `### 헤더` / `- 리스트` / `**bold**`)이 `> ` blockquote 라인을 일반 paragraph 로 떨어뜨려 `<p>&gt; ...</p>` 같은 HTML escape 결과물 생성. 278차 본문 (`gn=31490`) 은 `## Topic Body` 직후 `> Anthropic, Blackstone, Hellman & Friedman 3사가 ...` 로 시작 → 첫 줄이 시각적이지 않고 원문 의도 파괴. **회피 (278차 정착)**: `md_to_html` 에 5번째 분기 `elif stripped.startswith(">"):` 추가 → `<blockquote>` 태그로 라우팅. **5번째 패턴 정착 (278차)**: 260차 4종 + 278차 `> ` blockquote = 5종. **적용 범위**: §3.34.46 본문 빌드의 모든 변형 (`build_draft_*.py` / `gn-markdown-to-tistory-html.py`). 278차엔 `build_draft_31490.py` 에 분기 박혀있어 후속 차엔 동일 패턴 적용 가능. 기존 패턴(§3.8.1 가드 / §3.8.2 격리 / §3.11 sync CLI / §3.34.40 v2 / §3.34.43 PWD / §3.34.46 영구화 / §3.34.47 격리 빌드 / §3.34.48 `*` 분기 / §3.34.50 Topic Body / §3.34.52 IME 변환 / §3.34.53 `gfc` alias / §3.34 #21 정책 / §3.34.45 매트릭스 / cleanup cron 임무 #16) 모두 278차 5~7회째 정상 동작 — 연속 all-green **65회차 (213~278차)** 유지. Picsum ID 939 자동 매칭 (anthropic blackstone ode enterprise ai implementation consultant team query) — 두 슬롯 모두 동일 ID 자동 매칭, 첫 시도 적중. cleanup cron 임무 #16 dry-run 64→**65회** 연속 all-green 유지. **영구화 권장** (`scripts/gn-markdown-to-tistory-html.py`): 모듈의 `md_to_html` 함수에 blockquote 분기 자동 반영. 현재 `build_draft_*.py` 만 분기 추가되어 있어 모듈 차원 패치 필요. 차감/추가 없음.

## 절대 하지 말 것

- ❌ 통계 +1 후 실제 Tistory 글 없이 종료 (가짜 발행 버그 원인)
- ❌ 세션 만료 시 publish 단계 진행 (가짜 발행 누적)
- ❌ 중복 topic skip 후에도 publish (통계 오염 방지)
- ❌ publish 후 details/last/stats 미갱신 (191차 §8.5.2 무효화 환경 의존) → `scripts/post_publish_sync.py` 호출 필수
- ❌ §3.5 drift 감지 후 publish 진행 (drift 상태로 publish하면 stats +1되지만 pt/state sync 안 됨)
- ❌ hermes venv python3 호출 (urllib3 2.6.x 비호환) → §3.8.2 격리 패턴 사용 (244차: bash -c 안에서 source 후 python 상속)
- ❌ frontmatter 포함된 draft.md 직접 publish (300자 미만으로 검증 실패) → `scripts/strip-frontmatter.py` 선처리
- ❌ **cron에서 `blog_pipeline.py --category '<cat>'` 단독 호출로 publish 후보 pick** (§3.34.39) — 점수 무관 순환 pick 위험. 후보 직접 점수 정렬 후 `record_published_topic` 또는 `commit_publish` 명시 호출. **244차 보완**: `--refresh-topics --dry-run` JSON 직접 점수 정렬 + FRESH 4-field 명시 매칭 패턴.
- ❌ **cron에서 `--force-topic <id>` 단독으로 publish** (§3.34.39) — source_url/topic_url 미주입. tistory_publisher.py 가 draft 본문 + url 인자 필요.
- ❌ **`post_publish_sync.py sync-from-pt`의 `state_updated: true` 를 그대로 신뢰** — 코드 state 경로(`~/.hermes/state/tistory_state.json`)가 부재하여 noop. 진짜 drift 보정은 heredoc으로 직접 통합 state 파일 갱신.
- ❌ **`execute_code` cron 호출** (244차) — `BLOCKED: ... bypass shell-string approval checks` 거부. → `terminal`+heredoc 또는 `write_file` 후 `tistory_publisher.py --file` 호출.
- ❌ **state.json에서 `state['published_topics']['last'].url` lookup** (§3.34.40, 244차 정정) — 그 키는 부재. 진짜 pt source-of-truth는 `~/.hermes/memory/published_topics.json` 별도 파일. §3.5 5중 신호 검증 스니펫은 위 박스 참조.
- ❌ **`/usr/bin/python3` heredoc 안에서 f-string에 백슬래시 quote 사용** (§3.34.41, 245차) — `SyntaxError: f-string expression part cannot include a backslash`. §3.8.2 격리 패턴의 python3는 항상 Python 3.9. `headers.get(\"content-type\",\"\")[:50]` 같은 패턴은 100% SyntaxError. → string concatenation 또는 변수 추출 후 f-string 외부 사용. 본문 §3.8.1 가드 heredoc은 245차 수정본이 표준.
- ❌ **`/usr/bin/python3` inline heredoc 안에 30줄이 넘어가는 본문 빌드/HTML 변환 스크립트 작성** (§3.34.47, 263차 신규) — `f"... {var.split(\" \",1)[1]} ..."` 같은 §3.34.41 패턴 + `\"` escape + 한글 UTF-8 본문 문자열이 한 heredoc 안에 동시 등장하면 `SyntaxError: Non-UTF-8 code starting with '\xec'` 가 먼저 터지거나 f-string SyntaxError가 연쇄 발생. 263차 첫 시도에서 hit (md_to_html 본문 빌드 + intro/conclusion 합치기). → `write_file` 로 `/tmp/<session>/build_draft.py` 에 `# -*- coding: utf-8 -*-` 선언과 함께 저장 후 `python3 <script>.py` 격리 호출. 단일 probe (가드 / sync / state 확인) 처럼 5~10줄짜리 short heredoc은 §3.34.41 정정 (string concat) 으로 충분.
- ❌ **`env -i HOME=... PATH=... /bin/bash -c '...'` 호출 시 `cd /Users/mac` 또는 `PWD=/Users/mac` 누락** (§3.34.43, 247차) — bashrc 자동 `cd` 로 exit 126. §3.8.1 가드/§3.11 sync/§3.34.42 verify 등 모든 격리 bash 호출에 영향.
- ❌ **`scripts/gn-fetch-content.py` 의 stale `GN_MD_URL` 우회 패턴 작성** (§3.34.46, 259차 식별 → 261차 영구화 완료 ✅) — 더 이상 `requests.get("https://news.hada.io/topic/{tid}.md")` 임시 우회 heredoc 작성 불필요. cleanup cron 임무 #23 영구화 완료: `_try_md_endpoint(tid)` 또는 `fetch_gn_content(tid)` public API 직접 호출 (위 §3.34.46 박스 코드 참조).
- ❌ **GeekNews 마크다운 원본 그대로 Tistory publish** (260차 정착) — Tistory는 markdown 미지원. §3.34.46 박스의 HTML 변환 패턴(헤더/리스트/bold 4종) + editorial 인트로/결론 추가 필수. 300자 가드 통과 못함.
- ❌ **들여쓬 sub-list를 nested `<ul>` 로 변환** (262차 식별) — GeekNews의 indented sub-list는 마크다운 의미상 모두 형제 bullet, 시각적 깊이일 뿐. nested ul_stack 패턴은 매 항목마다 `<ul>` 가 열리고 즉시 닫혀 리스트 미형성. → indent 무시하고 모든 `- ` 를 top-level bullet 로 취급, 연속된 `- ` 라인을 하나의 `<ul>...</ul>` 로 묶고 빈 줄에서만 close.
- ❌ **`- ## 헤더` 위장 항목을 `<li>` 로 변환** (262차 식별) — GeekNews 본문에 `- ## 기존 모델의 호출 방식에 맞춰진 제약` 같은 list-prefixed header 가 나옴. `<li>` 로 변환되면 의미 파괴. → `- ` 변환 직전 item_text가 `## `/`### ` 로 시작하면 `<h2>`/`<h3>` 로 라우팅.
- ❌ **`* ` 들여쓰기 리스트를 `<p>` 로 변환** (§3.34.48, 266차 식별) — GeekNews 본문 (특히 gn=31432 Papermake) 이 `- ` 외 `* ` 들여쓰기 패턴을 혼용 (`* 완전한 감사 추적(Audit Trail)`). 262차 정착 `md_to_html` 은 `- ` 만 처리하여 `* ` 라인이 그냥 `<p>` 로 떨어져 들여쓴 sub-list가 시각적으로 평평한 본문으로 변환됨. → `md_to_html` 에 `elif stripped.startswith("* ") and not stripped.startswith("**"):` 분기 추가 (bold `**` 시작은 제외). 266차 첫 빌드에서 hit → 즉시 분기 추가하여 해결. **적용 범위**: §3.34.46 본문 빌드의 모든 변형.
- ❌ **`import tistory_publisher; tistory_publisher.publish(...)` 모듈 함수 호출** (266차 식별) — `AttributeError: module 'tistory_publisher' has no attribute 'publish'` (모듈에 `publish` 함수 부재, **CLI 인터페이스만 지원**). → `subprocess` 로 `python3 /Users/mac/.hermes/scripts/tistory_publisher.py --title ... --file ...` 호출하거나 `terminal` + 격리 bash 패턴 (§3.34.40 4단계 패턴 4번 항목 그대로).
- ❌ **`/manage/post/image`, `/manage/post/attach`, `/manage/post/photo` 로 직접 이미지 업로드** (§3.34.49, 271차 신규) — 모두 `405 Method Not Allowed` (text/html). 진짜 endpoint는 `/manage/post/attach.json` (`tistory_publisher.py` 의 `ATTACH_ENDPOINT` 상수). 정상 호출: `files={"file": (fname, data, content_type)}` + `headers={"Accept":"application/json", "Origin":TISTORY_BLOG_URL, "Referer":f"{TISTORY_MANAGE_URL}/newpost/"}`. cron 자동화에선 `tistory_publisher.py --image-query` 가 내부에서 호출하므로 직접 probe 불필요 — 가이드 추가만으로 충분.
- ❌ **자정 사이 외부 발행이 직전 슬롯을 차지한 상태에서 무심코 publish 후 §3.5 5중 검증 미수행** (§3.34.44 슬롯 덮어쓰기 케이스, 271차 식별) — 사전 검증의 `state.last_published_url`이 자정 사이 외부 발행 흔적으로 박혀있을 수 있음. 5중 신호 일치 (모두 `#1013` 처럼 같은 슬롯) 라고 판단되면 정상 진행하되, publish 직후 라이브 페이지 `window.T.entryInfo` + `<title>` 태그로 우리 publish 가 실제 점유했는지 1차 확인 권장 (진짜 우리 글이 박힌 슬롯이면 sync 보정 정상 — drift 무해). 라이브 페이지 검증 실패시 → §3.11 `post_publish_sync` 가 publish URL 기준으로 pt/state/details/last/stats 자동 보정 (drift → sync 사이클 정상 동작 확인).
- ❌ **`scripts/gn-fetch-content.py` 후속 빌드 스크립트에서 260차 정착 "## Metadata skip" 로직 그대로 사용** (§3.34.50, 272차 식별) — `## Topic Body` 이후 첫 줄이 `- 신경망 ...` 같은 본문 bullet 으로 시작하는 경우 skip 로직이 본문까지 잘라내 body_html 이 67 bytes (정상 ~3000 의 1/45) 로 떨어짐. → Topic Body 마커 기반 추출로 정정: `re.search(r"## Topic Body\s*\n+(.*)", text, re.DOTALL)` + `re.search(r"\n## Comments", body)`. 평문 길이 sanity check 必 — `len(re.sub(r"<[^>]+>", "", html))` 가 300자 미만이면 본문 추출 단계 버그로 즉시 재추출.
- ❌ **FRESH 4-field 매칭 시 `pt.last.gn_topic_id` 가 pub set 에 없는 v1 로직 사용** (§3.34.40 v2, 272차 보강) — 271차 슬롯 덮어쓰기 drift 케이스에서 `pt.last.gn_topic_id` 가 가리키는 토픽이 `pt.details` 에 splice 누락된 채로 박혀있어 v1 FRESH 매칭이 중복 publish 후보로 pick. → pub set 에 `pt_last_gn = str(pt.get('last',{}).get('gn_topic_id'))` + `pt_published.add(pt_last_gn)` 추가. cron 자동화 워크플로에서 v1 은 obsolete, v2 필수.
- ❌ **splice 누락 drift 검증 없이 publish 진행** (§3.34.51, 273차 신규) — `pt.last.gn_topic_id` 가 v2 guard로 FRESH 매칭에서 제외해도 pt.details array 자체에 entry가 부재할 수 있음 (271차 splice 누락 사례). publish 직전 5중 신호 검증 시 `state.details[-1].url` vs `pt.last.url` 비대칭이면 splice 누락 의심 → 임시 backfill entry 추가 → 5중 신호 재검증 → 비대칭 발견시 즉시 entry 제거 + publish → §3.11 sync가 자동 정정. 또는 `scripts/cleanup-pt-details-splice.py` (cleanup cron 임무 #30 신규) 로 publish 전 historical splice 자동 보정. 라이브 페이지 직접 GET으로 슬롯 title 확인 후 FRESH 후보 제외도 권장 (publish URL 슬롯별 title prefix 매칭).
- ❌ **`gfc.fetch_gn_content(tid)` 단독 호출** (§3.34.55, 279차 신규) — 244차 §3.34.34 가이드는 `(title, content, source) tuple` 반환이라고 박혀있으나 279차에 `TypeError: 'NoneType' object is not subscriptable` 반환 (실제 함수가 `Optional[Tuple[...]]` 으로 None 반환). → 본문 fetch는 무조건 `text = gfc._try_md_endpoint(tid)` 단일 함수만 사용. `fetch_gn_content` 호출은 권장하지 않음 (None 반환 위험).
- ❌ **`status, text = gfc._try_md_endpoint(tid)` 형태의 tuple unpack** (§3.34.55, 279차 신규) — `_try_md_endpoint` 시그니처는 `Optional[str]` (단일 문자열 반환) — 실제 코드 line 87. tuple unpack 시도시 `ValueError: too many values to unpack (expected 2)`. → 항상 `text = gfc._try_md_endpoint(tid)` 단일 변수 할당. 279차 검증: 31496 호출 → 21074 bytes 정상 fetch.
- ❌ **`> ` blockquote 라인을 일반 paragraph 로 변환** (§3.34.54, 278차 신규) — GeekNews 본문 (특히 gn=31490 Ode, 요약문이 `## Topic Body` 직후 `> Anthropic, Blackstone...` 로 시작하는 케이스) 이 첫 줄을 `>` blockquote 로 시작. 260차 정착 4종 패턴은 `>` 라인을 일반 paragraph 로 떨어뜨려 `<p>&gt; ...</p>` 같은 HTML escape 결과물 생성 (시각적이지 않고 원문 의도 파괴). → `md_to_html` 에 5번째 분기 `elif stripped.startswith(">"):` 추가 → `<blockquote>` 태그로 라우팅. 278차 첫 빌드에서 hit → 즉시 분기 추가하여 해결. **5번째 패턴 정착 (278차)**: 260차 4종 + 278차 `> ` blockquote = 5종. **적용 범위**: §3.34.46 본문 빌드의 모든 변형 (`build_draft_*.py` / `gn-markdown-to-tistory-html.py`). cleanup cron 임무 #34 신규.

- ❌ **`gn-fetch-content.py` 호출시 module name을 `gn_fetch_content` (언더스코어)로 적기** (§3.34.53, 277차) — `ModuleNotFoundError`. importlib `spec_from_file_location` 호출시 짧은 alias (`gfc`) 사용. 본문 안 영문 자동완성 토큰 (`roadmap`/`load_map`/`loadmap`) 변환 가능성도 함께 검증. cleanup cron 임무 #33.
- ❌ **§3.11 post_publish_sync CLI 호출 시 `--title` 인자에 영문+한글 혼재 토큰 + macOS 한글 IME 활성 상태로 전달** (§3.34.52, 276차 신규) — `Work Louder` 같은 영문 단어가 `Lou더` 로 자동 변환 박힘. sync 결과 `triple_signal_match: true` 반환하지만 pt.last.title + state.last.title + state.details[-1].title 3필드 모두 오타. 라이브 페이지 `<title>` 태그는 publish 단계 별도 title 인자로 정상 표시되어 5중 신호 검증으로는 못 잡음. → sync 호출 직전 IME OFF 또는 영문 단어 부분 ASCII 검증 (`re.match(r"^[A-Za-z]+$", word)`). sync 직후 pt/state 3필드 영문 검증 + 라이브 페이지 `<title>` cross-check (`curl -sL url | grep '<title>'`) — 불일치시 json 직접 patch로 3필드 모두 같은 값으로 덮어쓰기 보정.
