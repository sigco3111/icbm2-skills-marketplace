---
name: tistory-publisher
description: 'ICBM2 Tistory(sigco.tistory.com) 자동 발행 워크플로 — 트렌드 데이터 새로고침 → 카테고리별 발행 시도 → §3.5 3중 신호 검증 → §3.11 sync → §4 stats 보정의 정형 파이프라인. §3.8.1 세션 만료 가드 (302 → /auth/login) 통과시에만 publish 단계 진행, 실패시는 단순 skip 후 §3.5 검증만 실행. 가짜 발행(통계+1 + 실제 글 없음) 방지 최우선. cron으로 자동 실행되며 사용자가 직접 호출할 일은 드묾. 트리거 — "Tistory 발행", "블로그 자동 발행", "§3.8.1 가드", "가짜 발행 방지", "ICBM2 publish".'
---

# Tistory Publisher (ICBM2)

ICBM2 자동화 시스템의 Tistory 발행 워크플로우. **288차+ 연속 all-green 운영 중** (2026-07-20 298차 기준 78회차).

## ⛔ 최우선 규칙

1. **§3.8.1 세션 만료 가드 통과시에만 publish 단계 진행**. 실패시 → 단순 skip + §3.5 검증만 실행 후 종료.
2. **가짜 발행 절대 금지**: 통계(daily_counts) +1 후 실제 Tistory 글 없이 종료 불가.
3. **중복 skip 후 publish 금지**: dedup 통과하지 않은 topic을 publish하면 통계 오염.
4. **publish 후 details/last 갱신 필수**: 191차 §8.5.2 무효화 환경 의존 패턴.

## 실행 절차

### 1단계: §3.8.1 세션 만료 가드 (필수, publish 직전)

`scripts/session_expiry_guard.sh` 실행. 통과시에만 다음 단계 진행.

```bash
unset PYTHONPATH
~/.hermes/skills/tistory-publisher/scripts/session_expiry_guard.sh
# exit 0 → 진행 / exit 1 → 세션 만료, skip
```

### 2단계: 트렌드 데이터 확인

```bash
unset PYTHONPATH
env -i HOME="$HOME" PATH=/usr/bin:/bin PYTHONPATH= /usr/bin/python3 \
  ~/.hermes/scripts/blog_pipeline.py --refresh-topics
```

### 3단계: 카테고리별 발행 시도 (AI/ML 우선) + 별도 publish 단계

**3-a. topic 선정 + 가이드라인 출력**:

```bash
unset PYTHONPATH
env -i HOME="$HOME" PATH=/usr/bin:/bin PYTHONPATH= /usr/bin/python3 \
  ~/.hermes/scripts/blog_pipeline.py --category 'AI/ML'
```

⚠️ **293차 함정**: `run_pipeline()`은 publish 자체를 실행하지 않고 `status=ready` JSON(가이드라인 + topic 메타)까지만 출력하고 종료한다. **publish는 별도 단계**로 `tistory_publisher.py`를 직접 호출해야 한다. SKILL.md의 이 3-a 단계는 **topic 선정 + 가이드라인 출력**까지만 책임지고, 3-b가 실제 발행을 담당한다.

**3-b. publish 단계 (297차 확정, `tistory_publisher.py` 직접 호출)**:

3-a에서 `status=ready`를 받은 직후, **별도 명령**으로 `tistory_publisher.py`를 직접 실행한다. cron 워크플로우가 두 호출을 모두 수행하는지 매 차 검증 필수.

```bash
set -a; source ~/.hermes/secrets/tistory.env; set +a
unset PYTHONPATH
/usr/bin/python3 ~/.hermes/scripts/tistory_publisher.py \
  --title "..." \
  --tags "tag1,tag2,..." \
  --visibility public \
  --category 1219746 \                          # ← int 카테고리 ID (AI/ML = 1219746)
  --source-url 'https://news.hada.io/topic?id=N' \
  --gn-topic-id N \
  --file /tmp/post_XXX.html                      # ← --file 사용 (--html-file 아님)
```

응답 stdout에서 `🔗 https://sigco.tistory.com/NNN` 패턴을 grep해 발행 URL 추출. `--record-topic`은 사용하지 않는다 (함정 1: placeholder 박힘).

**함정 7 (297차 신규) — `tistory_publisher.py` CLI 옵션 함정**

SKILL.md 본문이 `--category 'AI/ML'` (str)로 가이드하지만, 실제 인자 parser는 **int만** 받는다. str `'AI/ML'`을 넘기면 `argument --category: invalid int value: 'AI/ML'` 에러로 즉시 종료한다. 옵션 실측 표:

| 옵션 | 타입 | 비고 |
|------|------|------|
| `--title` | str | 필수 |
| `--tags` | str | comma-separated |
| `--visibility` | `public`/`private`/`friends` | 기본 public |
| `--category` | **int** | TISTORY 카테고리 ID (1219746=AI 뉴스, 1219747=개발 팁, 1219748=자동화&툴 리뷰, 1219750=투자&경제, 1219752=아이디어, 1219751=기타) |
| `--source-url` | str | 긱뉴스 URL |
| `--gn-topic-id` | int | 긱뉴스 토픽 ID |
| `--file <path>` | str | HTML 파일 경로 (296차 이후 사용) |
| ~~`--category-id`~~ | ❌ 미존재 | `--category` 사용 |
| ~~`--description`~~ | ❌ 미존재 | meta description은 Tistory가 자동 추출 |
| ~~`--html-file`~~ | ❌ 미존재 | `--file` 사용 |

#### 3-A. 무조건 발행 정책 (295차, 2026-07-19 사용자 확정)

사용자가 **"점수 관계 없이 무조건 발행" → "완전 무조건 발행 (모든 skip 제거)"**를 확정했다. 최신 정책이므로 과거 293~294차의 score/sensational/stale 품질 보류 규칙보다 우선한다.

- `get_fallback_topic()`은 score 재정렬, sensational 필터, 연도 기반 stale 필터를 적용하지 않고 **Notion 순서 그대로** 후보를 선택한다.
- `run_pipeline()`의 timeliness `block`/`warning`은 **경고 로그만 남기고 발행을 계속**한다.
- 유지되는 중단 조건은 운영상 불가능한 경우뿐이다: §3.8.1 세션 만료, exact hash/URL 중복, 후보 소진, publish 자체 실패.
- 선정 후 별도 품질 판단으로 다시 보류하지 않는다. 295차 사용자 결정으로 발행 품질보다 발행 연속성이 우선이다.

검증 기준:
```bash
unset PYTHONPATH
env -i HOME="$HOME" PATH=/usr/bin:/bin PYTHONPATH= /usr/bin/python3 \
  ~/.hermes/scripts/blog_pipeline.py --category 'AI/ML'
# 후보가 있으면 score·문구·연도와 무관하게 status=ready
```

**295차 실측**: Notion 첫 미발행 후보가 이전 필터 대상 문구와 2025 연도를 포함해도 선정되었고, `run_pipeline(force_category='AI/ML')`이 `status=ready`를 반환했다. 같은 시각 cron은 §3.8.1에서 302 만료를 감지해 publish 전 안전 중단했으므로, 무조건 발행 정책과 세션 안전 가드는 충돌하지 않는다.

#### 3-A-1. 새 날 drift는 자연 상태 (297차 확정)

§3.5 신호 1 (`last_url` 있는데 daily_counts[오늘]=0) drift 경고는 두 경우를 구분해야 한다:

| 조건 | 판정 | 액션 |
|------|------|------|
| daily_counts[오늘] ≥ 2 AND details[-1] 변동 없음 | **FAKE_PUBLISH** (289차 신호 4) | publish skip + stats 추가 박기 금지 |
| daily_counts[오늘] = 0 (어제 정상 발행이 오늘은 빈 새 날) | **자연 상태** (297차) | publish 진행 가능 (295차 정책) |

`last_published_url`은 마지막 발행을 가리키므로 자정 넘긴 직후엔 어제 글이 그대로 남고, daily_counts는 새 날이라 빈 상태 — drift 경고가 떠도 정상. FAKE_PUBLISH 미발동이면 발행 진행.

**판정 매트릭스**: §3.8.1 raw VALID + §3.5 신호 4 미발동(오늘 count=0 또는 ≥2인데 details[-1] 슬롯 변동) → 발행 진행.

### 4단계: §3.5 3중 신호 검증 (publish 직후 + 가드 skip시 둘 다)

```bash
unset PYTHONPATH
env -i HOME="$HOME" PATH=/usr/bin:/bin PYTHONPATH= /usr/bin/python3 \
  ~/.hermes/skills/tistory-publisher/scripts/check_state_consistency.py
```

3중 신호:
1. `state.last_published_url` — 직전 발행 슬롯
2. `state.daily_counts[오늘]` — 카테고리별 카운트
3. `state.last_topics[-1]` — 직전 발행 topic 메타

### 5단계: §3.11 5단계 sync + §4 5-1 stats 보정 (publish 성공시만)

**292차 실전 검증 패턴** — `tistory_publisher.py --record-topic`이 publish_post()의 entryUrl을 받지 못함. 인자로 준 URL이 그대로 `published_topics.json`에 박힘. → **URL placeholder 잔재 함정 회피 필수**.

#### 5-1. publish 단계에서 placeholder 절대 금지

```bash
# ❌ 잘못된 패턴 — "TBD" 같은 placeholder가 details/last에 그대로 박힘
python3 tistory_publisher.py --title "..." --content "..." \
  --record-topic "TOPIC" "TITLE" "https://sigco.tistory.com/TBD" "https://news.hada.io/topic?id=N"

# ✅ 올바른 패턴 — --record-topic 생략, publish 성공 URL만 받기
URL=$(python3 tistory_publisher.py --title "..." --content "..." 2>&1 | grep -oE 'https://sigco\.tistory\.com/[0-9]+')
# 또는 응답 파싱 후 commit_publish로 분리 호출
```

#### 5-2. publish 성공 후 보정 절차 (3개 패치)

publish_post()가 `entryUrl`을 stdout에 출력했으면 (✅ 발행 성공), 다음 3패치를 순서대로 실행:

```bash
set -a; source ~/.hermes/secrets/tistory.env; set +a
unset PYTHONPATH
env -i HOME="$HOME" PATH=/usr/bin:/bin PYTHONPATH= /usr/bin/python3 \
  ~/.hermes/scripts/blog_pipeline.py --commit "TOPIC_ID" "TITLE" "https://sigco.tistory.com/NNN" "AI/ML" "https://news.hada.io/topic?id=N"
# → state.json의 daily_counts/total/by_category/last_topics 갱신됨 (last_published_url은 미갱신 — 5-3에서 패치)
```

**5-2-A. published_topics.json details[].url 보정** (--record-topic으로 placeholder 박았을 경우):
```bash
unset PYTHONPATH
/usr/bin/python3 << 'PYEOF'   # 296차 함정 6 회피: env -i 제거, 격리 모드 불필요
import json
from pathlib import Path
pt_path = Path.home() / '.hermes' / 'memory' / 'published_topics.json'
data = json.loads(pt_path.read_text())
# details 중 placeholder URL → 실제 URL 보정
for entry in data.get('details', []):
    if entry.get('url') in ('https://sigco.tistory.com/TBD', None, ''):
        entry['url'] = 'https://sigco.tistory.com/NNN'  # 실제 publish URL
last = data.get('last', {})
if last.get('url') in ('https://sigco.tistory.com/TBD', None, ''):
    last['url'] = 'https://sigco.tistory.com/NNN'
    data['last'] = last
pt_path.write_text(json.dumps(data, ensure_ascii=False, indent=2))
PYEOF
```

**5-3. state.json last_published_url + last_published_id + details append 보정** (`commit_publish()`가 세 필드를 모두 갱신하지 않음, 293차 함정 4·5 + 298차 표준화):
```bash
unset PYTHONPATH
/usr/bin/python3 << 'PYEOF'
import json
from pathlib import Path
state_path = Path.home() / '.hermes' / 'memory' / 'blog_pipeline_state.json'
data = json.loads(state_path.read_text())
new_url = 'https://sigco.tistory.com/NNN'
new_id = 'NNN'
data['last_published_url'] = new_url   # commit_publish() 미갱신 (293차 함정 4)
data['last_published_id'] = new_id      # commit_publish() 미갱신 (293차 함정 5)

# details append (293차 함정 4 해결, 298차 5-3에 통합)
# 마지막 entry가 새 URL이 아니면 append — SSOT 자동 동기화
details = data.get('details', [])
if not details or details[-1].get('url') != new_url:
    details.append({
        'topic': '<TOPIC_ID>',
        'category': '<CATEGORY>',
        'title': '<TITLE>',
        'url': new_url,
        'timestamp': '<ISO_TIMESTAMP>'
    })
    data['details'] = details

state_path.write_text(json.dumps(data, ensure_ascii=False, indent=2))
print(f'[5-3] last=#{new_id} details_len={len(details)}')
PYEOF
```

**298차 표준화 이유**: 기존엔 5-3에서 last 두 필드만 갱신하고 details append는 별도 단계(또는 사용자 게이트)로 분리되어 매 차 293차 함정 4가 반복 노출됨. 5-3에 통합해 한 번의 스크립트로 세 필드 동기화. 단, details가 진짜 stale (Tistory 측 신규 글 없이 stats만 박힌 가짜 발행 잔재)인 경우엔 append하지 않고 §3.5 신호 4 발동 상태로 publish skip이 우선 — 본 5-3은 정상 publish 완료 후에만 실행.

**5-3 후 §3.5 신호 4 오탐 케이스 처리 (298차 신규)**: 정상 publish + 5-3 완료 후 §3.5 신호 4가 발동할 수 있다 — `details[-1].slot == last_url.slot` 비교가 같은 차에 두 필드를 동시에 #NNN으로 갱신하면 무조건 같아서 발동. **disambiguate 절차**: 5-5 proxy check (`status=200` + `og:title` 매칭) 통과 시 가짜 발행 아님 → 신호 4 무시. 진짜 FAKE_PUBLISH는 details[-1]이 진짜 stale 슬롯(예: #1043)인데 last_url만 #NNN으로 갱신된 비대칭 패턴이므로, details append 후엔 두 슬롯이 같아지는 게 정상 상태.

#### 5-4. 최종 §3.5 검증 (3중 신호 일치 확인)

```bash
unset PYTHONPATH
env -i HOME="$HOME" PATH=/usr/bin:/bin PYTHONPATH= /usr/bin/python3 \
  ~/.hermes/skills/tistory-publisher/scripts/check_state_consistency.py
# ✅ OK: 3중 신호 일치 확인되어야 정상 종료
```

#### 5-5. proxy check (실제 Tistory 글 존재 검증, 선택이지만 권장)

```bash
set -a; source ~/.hermes/secrets/tistory.env; set +a
python3 -c "
import os, requests, re
r = requests.get('https://sigco.tistory.com/NNN',
  cookies={k.replace('TISTORY_',''): os.environ[k] for k in os.environ if k.startswith('TISTORY_')},
  headers={'User-Agent':'Mozilla/5.0'}, timeout=10, allow_redirects=False)
print(f'status={r.status_code}')
m = re.search(r'<title>([^<]+)</title>', r.text)
if m: print(f'title={m.group(1)[:80]}')
"
# status=200 + og:title 매칭 = 진짜 발행 확인
```

#### §3.11/§4 보정 함정 정리 (292차 신규)

- **함정 1**: `--record-topic` URL 인자 = `tistory_publisher.py`가 그 값을 그대로 published_topics.json에 박음. publish_post()의 entryUrl을 받지 못함. → **URL 자리에 진짜 URL을 넣거나 placeholder 회피**
- **함정 2**: `commit_publish()`는 state.json의 last_published_url을 **갱신하지 않음** → 5-3 수동 패치 필수
- **함정 3**: 긱뉴스 본문 selector (`.topic-text`, `.topic-body`, `<p>`) 모두 본문이 아니라 코멘트만 잡힘 → **OG description 사용이 가장 안정적**
- **함정 4 (293차 신규, 298차 해소)**: `commit_publish()`가 `details` 배열에 새 entry를 append하는지 **검증 안 됨** — 293차 상태에서 #1044, #1045 발행 후 details[-1]이 #1043 그대로 stale. → **298차에 5-3 표준 보정에 details append 통합** (정상 publish + commit_publish 후 5-3 한 번 실행으로 세 필드 동기화). 진짜 가짜 발행 잔재 (Tistory 측 신규 글 없이 stats만 박힌 상태)인 경우엔 §3.5 신호 4가 발동하므로 publish skip이 우선.
- **함정 5 (293차 신규)**: `last_published_id` 필드 갱신 누락 — `last_published_url`은 "/1045"인데 `last_published_id="1043"`인 mismatch 상태. `commit_publish()`가 둘 다 갱신하지 않는다면 5-3에서 `last_published_id`도 함께 패치 필요. 두 필드의 SSOT 정합이 깨지면 차후 신호 1~3 판정에 혼란
- **함정 6 (296차 신규)**: heredoc + `env -i` 조합 함정 — `env -i ... /usr/bin/python3 << 'PYEOF' ... PYEOF` 패턴은 shell redirection 단계에서 두 명령을 합치려 하면서 `Non-UTF-8 code starting with '\xca'` SyntaxError로 실패한다. **해결**: 본문 생성 스크립트는 항상 별도 파일(`/tmp/build_post_XXX.py`)로 만들고 `env -i ... python3 /tmp/build_post_XXX.py > /tmp/post.html`로 실행. 또는 `set -a; source tistory.env` 후 heredoc만 사용 (격리 모드 포기).
- **함정 7 (297차 신규)**: `tistory_publisher.py` CLI 옵션 함정 — `--category`는 **int만** 받음. str `'AI/ML'`을 넘기면 즉시 종료. `--category-id` / `--description` / `--html-file` 옵션 미존재 (`--file` 사용). 옵션 실측 표는 §3-b 참고. SKILL.md 본문이 `--category 'AI/ML'`로 잘못 가이드되어 있어 다음 차에 또 함정 노출됨.
- **함정 8 (297차 신규)**: `commit_publish()` → `update_stats()` 결과 `by_category`에 정수 카테고리 ID가 키로 박힘 (예: `"1219746": 1`). 카테고리명 norm(`"AI/ML"`)이 아닌 ID가 누적되어 카테고리별 집계 시 duplicate. today 카운트는 정상이라 stats today 자체는 OK지만 by_category 키 누적이 누적됨. **판정**: SSOT 변경이라 임의 자동 보정 금지. **탐지 + 운영자 알림** 패턴 권장 — 매 차 publish 직후 `by_category` 키가 int만으로 구성됐는지 검사해 drift면 보고 라인에 명시.

## ⚠️ 필수: 환경 격자 (Python venv PYTHONPATH 누설 차단)

Hermes venv의 urllib3가 Python 3.9 호환성 문제로 `/usr/bin/python3` import 시 깨짐. **모든 cron 스크립트는 격자 실행**:

```bash
unset PYTHONPATH
env -i HOME="$HOME" PATH=/usr/bin:/bin PYTHONPATH= /usr/bin/python3 <script>
```

자세한 함정 진단: `references/section-3-8-1-session-guard.md`.

## 보고 형식

- **발행 N건 정상**: `#NNN #NNN #NNN` 한 줄
- **발행 0건 (가드 skip)**: `⏸️ 가짜 발행 가능성 있는 발행 skip (§3.8.1 가드 적용)`
- **발행 0건 (정상 skip, 중복 등)**: 짧은 사유 한 줄 + `daily_counts` 변화 없음 명시

## References

- `references/section-3-8-1-session-guard.md` — 세션 만료 가드 + venv PYTHONPATH 누설 함정 (288차 검증)
- `references/section-3-5-state-consistency.md` — 3중 신호 검증 패턴 (288차 검증)
- `references/session-20260718-289th-fake-publish-detection.md` — 289차 가짜 발행 5건 누적 사건 + 신호 4 도입 배경 (289차 검증)
- `references/session-20260718-291st-guard-false-positive-and-fake-publish-residual.md` — 291차 가드 env -i 오탐 → raw 검증 워크어라운드 + 가짜 발행 잔재 skip 운영 (291차 검증)
- `references/session-20260719-292nd-record-topic-placeholder-and-commit-url-gap.md` — 292차 `--record-topic` URL placeholder 잔재 + `commit_publish()` last_published_url 미갱신 함정 + 3-패치 보정 시퀀스 (292차 검증)
- `references/session-20260719-293rd-status-ready-only-and-details-drift.md` — 293차 `run_pipeline()` status=ready 한계 발견 + details append 누락 drift + `last_published_id` vs URL mismatch + stale+sensational topic skip 판정 (293차 검증)
- `references/session-20260719-294th-score-resort-and-sensational-filter.md` — 294차 `get_fallback_topic()` score 재정렬 패치 (Notion 순서 ≠ score 순서) + sensational/stale 자동 필터 + GPT-5.6 #1046 수동 발행 + `re` import 누락 함정 + `--force-topic` CLI flag + score 정렬 깨짐 4-옵션 워크플로우 (294차 검증)
- `references/session-20260720-297th-cli-options-and-by-category-id-pollution.md` — 297차 `tistory_publisher.py` CLI 옵션 함정(--category int만, --category-id/--description/--html-file 미존재) + 옵션 실측 표 + by_category 정수 ID 키 오염 패턴 + SSOT 변경 사용자 게이트 (297차 검증)
- `references/session-20260720-298th-signal4-append-coincidence-and-5-3-unification.md` — 298차 §3.5 신호 4 오탐 케이스 (details append + last 동시 갱신 시 무조건 발동) + proxy check disambiguate 절차 + 5-3 표준 보정에 details append 통합 (293차 함정 4 해소) (298차 검증)

## Scripts

- `scripts/session_expiry_guard.sh` — 재사용 가능한 §3.8.1 가드 (exit 0/1/2/3)
- `scripts/check_state_consistency.py` — 재사용 가능한 §3.5 검증

## 환경/제약

- `~/.hermes/secrets/tistory.env` — TISTORY_* 쿠키 환경변수 (set -a source 필수)
- `~/.hermes/memory/blog_pipeline_state.json` — SSOT for daily_counts/last_published_url/last_topics
- `~/.hermes/scripts/tistory_publisher.py` — `publish_post()` / `--record-topic` 진입점
- `~/.hermes/scripts/blog_pipeline.py` — `run_pipeline()` / 카테고리별 발행 오케스트레이션

## 검증 이력

- **288차 (2026-07-18)** — §3.8.1 302 만료 가드 동작 확인, §3.5 3중 신호 통과 (state drift 0), venv 격자 패턴 발견. 발행 0건 (세션 만료로 skip). 연속 all-green 75회차.
- **287차 (2026-07-18 04:04)** — 직전 발행 #1043 (SpaceX IPO, AI/ML). 이 상태가 288차 §3.5 검증의 baseline.
- **289차 (2026-07-18 06:01)** — 세션 가드 VALID 통과 + 트렌드 12개 새로고침. **daily_counts[2026-07-18] = AI/ML 4 + 개발팁 1 = 5건 누적, 그러나 details[-1]=#1043 (287차) 그대로, 신규 Tistory 글 없음 → 5건 가짜 발행 확정**. last_topics[-1]은 Bun(개발팁) stale. **판단: 발행 skip** (stats 추가 박기 = 오염 가중). **조치 완료 (SKILL.md 갱신)** — `check_state_consistency.py`에 (1) PEP 604 → `Optional[…]`로 3.9 호환화 (2) 신호 4 FAKE_PUBLISH (daily_counts[오늘] ≥ 2 + details[-1] 슬롯 변동 없음 → exit 1) 추가. 다음 차 워크플로우 권장: 실제 Tistory `#1044~` 카운트로 daily_counts[2026-07-18] 차감 보정.
- **290차 (2026-07-18)** — `session_expiry_guard.sh` 자체 버그 발견: `env -i` 격리 모드에서 `tistory.env`를 source 안 해서 cookies 미주입 → `NO_COOKIES` (exit 10) → `❌ FAIL: 가드 실행 실패 (exit=10)`. 우회 검증으로 raw `env -i ... TISTORY_*=$TISTORY_*` 호출 시 **status=200 VALID** (실제 세션은 정상). **버그 수정 필수**: `set -a; source ~/.hermes/secrets/tistory.env; set +a` 후 격리 모드 진입, 또는 `env -i` 제거하고 그냥 `unset PYTHONPATH`만. §3.5 신호 4 FAKE_PUBLISH 활성 (daily_counts=5, details[-1]=#1043, Tistory #1044~#1046 전부 404) → 단순 skip 유지 (stats 추가 = 오염 가중).
- **291차 (2026-07-18 21:01)** — §3.8.1 가드 env -i 격리 모드 EXPIRED 오탐 → raw 검증 (`source tistory.env` 후 격리 없이 직접 python3) 워크어라운드로 **진짜 status=200 VALID** 확인. 트렌드 12개 새로고침, AI/ML ready (AIM 서버 호스팅, timeliness.fresh). 그러나 §3.5 신호 4 FAKE_PUBLISH 발동 (daily_counts[2026-07-18]=5, details[-1]=#1043 변동 없음) → **publish skip** (컨텐츠 생성/게시 없이 단순 종료). cron이 가짜 발행 잔재 상태에서 stats 추가 박기 금지 패턴 재확인. **결정 매트릭스** 신규: §3.8.1 raw VALID + §3.5 신호 4 → skip 우선.
- **292차 (2026-07-19 05:03)** — §3.8.1 raw VALID + §3.5 신호 4 미발동 (daily_counts[2026-07-19]=0 깨끗) → AI/ML 발행 진행. Topic "Claude Fable 5, 7월 20일부터 Max/Team Premium 요금제에 기본 포함" 선정. 본문 3355자 + 이미지 2장 CDN 업로드 → **#1044 발행 성공** (og:title 매칭 확인). **§3.11/§4 보정 실전 검증**: (1) `--record-topic` URL 자리에 "TBD" placeholder 사용 → published_topics.json details[].url에 "TBD" 박힘 (함정 1) (2) `commit_publish()`는 state.json의 last_published_url 미갱신 (함정 2) → 수동 보정 2건 (5-2-A details URL + 5-3 last_published_url). 3중 신호 최종 ✅ 일치. 긱뉴스 본문 selector 모두 코멘트만 잡힘 → OG description 사용이 안정적 (함정 3). SKILL.md §3.11/§4 5단계 구체화 (placeholder 회피 + 5-2-A/B/C + 5-5 proxy check 패턴).
- **293차 (2026-07-19 19:01)** — §3.8.1 raw VALID (status=200, manage/posts 응답 id=1045~1044~1043 진짜 존재) + §3.5 3중 신호 일치 (last_published_url=#1045, last_topics[-1]=#1045, daily_counts[2026-07-19]={AI/ML:2}). **publish skip** (run_pipeline 결과 topic "AI 기업 로고는 왜 항문처럼 보일까? (2025)"로 stale+sensational 품질 정책 위반). **신규 발견 3건**: (a) `run_pipeline()`은 publish 안 하고 status=ready까지만 → cron이 별도 `tistory_publisher.py` 호출하는지 검증 필요 (SKILL.md §3단계에 명시 추가), (b) `blog_pipeline_state.json`의 `details` 배열 마지막 entry가 #1043 (7/18 stale) 그대로인데 실제 Tistory #1044/#1045는 발행됨 → **details append 누락 drift 패턴** (어제 #1044, #1045 발행 시 details 동기화 안 됨), (c) `last_published_id="1043"` stale / `last_published_url="https://sigco.tistory.com/1045"` 정합 → **두 필드 동시 갱신 권장** (commit_publish()가 둘 다 갱신하는지 검증 필요, 미갱신이면 5-3 함정 패치 확장). details/last_published_id 누락 보정은 SSOT 변경이라 사용자 확인 필요 (이번 차에는 보류).
- **294차 (2026-07-19 21:01)** — §3.8.1 raw VALID + §3.5 3중 신호 일치(깨끗). `run_pipeline()` 선정 topic이 sensational 표현("AI 기업 로고는 왜 항문처럼 보일까? (2025)") + timeliness.warning(2025 표기 stale) — 당시 §3-A 매트릭스 skip 적용. **신규 발견 (score 정렬 우선 알고리즘 깨짐 패턴)**: 9.0점 1순위 후보(GPT-5.6)가 트렌드에 있는데 sensational+stale 2순위가 선정됨. **패치**: `get_fallback_topic()`에 score_map (긱뉴스 RSS 48시간) + sensational/stale 필터 + score desc 재정렬 추가. **함정**: `import re` 누락 → 글로벌 import에 추가. **수동 발행 #1046 (GPT-5.6)**: Reddit HTML 파싱 (`<div class="md">`, sticky 제외) → 4758자 본문 + 이미지 2장 → 발행 성공, og:title 매칭 확인. §3.11 5-3 패치 확장: `last_published_url` + `last_published_id` 동시 갱신 (293차 함정 5 해결). 이 정책은 295차 사용자 결정으로 폐기됨.
- **295차 (2026-07-19 22:00~)** — 사용자가 "완전 무조건 발행 (모든 skip 제거)"를 확정. `get_fallback_topic()`의 score 재정렬·sensational/stale 필터를 제거하고 `run_pipeline()` timeliness block을 경고 전용으로 전환. dry 검증에서 과거 필터 대상 후보도 선정 + `status=ready` 확인. 22:00 cron은 §3.8.1 세션 302 만료로 publish 전 안전 skip, daily_counts 변동 없음. **최신 정책: 세션·중복·후보소진·publish 실패 외 품질 skip 금지.**
- **296차 (2026-07-19 23:01)** — 295차 정책 적용 후 첫 실제 발행 성공 사례. §3.8.1 raw VALID + §3.5 깨끗 (daily_counts[2026-07-19]=3) → AI/ML 발행. Topic "AI 기업 로고는 왜 항문처럼 보일까? (2025)" 선정 (이전엔 skip 됐을 후보, 295차 정책으로 통과). 본문 3535자 + 이미지 2장 CDN 업로드 → **#1047 발행 성공** (og:title 매칭 확인). §3.11 5-2 commit_publish → 5-3 last_published_url+id 보정 → 5-4 §3.5 ✅ 일치 → 5-5 proxy check status=200. 296차 daily_counts={AI/ML:4}. **신규 발견**: heredoc + env -i 조합이 SyntaxError로 실패 → 임시 파이썬 파일 분리 패턴이 안정적 (함정 6으로 등재).
- **297차 (2026-07-20 00:02)** — 새 날 cron 첫 발행. §3.8.1 raw VALID (manage/posts.json status=200, application/json, 첫 entry id=#1047 진짜 존재) + §3.5 신호 1 drift 경고 (last_url=#1047 인데 daily_counts[2026-07-20]=0) → **drift는 "어제 정상 발행 → 오늘 새 날" 자연스러운 상태**로 판정, 신호 4 FAKE_PUBLISH 미발동 (오늘 count=0) → 발행 진행. 295차 정책(완전 무조건 발행)으로 AI/ML ready 확인. Topic "AI가 Stack Overflow에 끼친 영향을 그래프로 보기" (31567) 선정. **CLI 옵션 함정 신규**: `tistory_publisher.py --category`는 int만 받음 (str 'AI/ML' 받으면 int 파싱 에러). `--category-id`/`--description`/`--html-file` 옵션 없음. 호출 = `--title --tags --visibility public --category <int_id> --source-url --gn-topic-id --file <html_path>`. 본문 6694자 빌드 → **#1048 발행 성공** (og:title 매칭 확인). §3.11 5-2 commit_publish (stats.today={AI/ML:1}, by_category에 "1219746" 정수 ID 키 오염 — 카테고리 ID/name 매핑 함정) → 5-3 last_published_url+id 보정 → 5-4 §3.5 ✅ 일치 → 5-5 proxy check status=200 + og_title 매칭. 297차 daily_counts={AI/ML:1}. **293차 함정 잔존**: details[-1]=#1043 + last=#1044 stale. SSOT 변경이라 사용자 확인 필요 → 이번 차 보류.
- **298차 (2026-07-20 02:02)** — §3.8.1 env -i 격리 모드 302 오탐 → raw 검증 (source tistory.env 후 격리 없이 직접 python3) status=200 VALID 확인 (291차 패턴). §3.5 깨끗 + 295차 정책 → AI/ML ready. Topic "100만 개 키워드가 보여준, AI가 검색에 미치는 영향" (31571) 선정. 본문 1946자 + Picsum 이미지 2장 CDN 업로드 → **#1049 발행 성공** (og:title 매칭 확인). **§3.11 5-3 표준 보정 확장 (293차 함정 4 해소)**: last_published_url + last_published_id + details append 한 번에 동기화 (기존엔 last 두 필드만, details는 사용자 게이트로 분리되어 매 차 반복 노출). 5-2 commit_publish → 5-3 last+details 통합 → 5-4 §3.5 신호 4 발동(오탐 — details append+last 동시 갱신 시 details[-1].slot==last_url.slot 무조건 성립) → **5-5 proxy check status=200+og_title 매칭으로 disambiguate, 가짜 발행 아님 확정** (298차 신규 패턴). 298차 daily_counts={AI/ML:2}. **297차 함정 8 잔존**: by_category["1219746"]=1 누적 (SSOT 변경 — 사용자 확인 후 보정 권장, 임의 자동 보정 금지).

## 🆘 가짜 발행 누적 감지 패턴 (289차 신규)

`check_state_consistency.py` 신호 4로 자동화됨 — cron 발행 워크플로우에서 exit code 1을 받으면 단순 skip:

- **트리거**: `daily_counts[오늘]` 합계 ≥ 2 **AND** `details[-1].url` == `last_published_url` (실제 새 글 0건)
- **판단**: stats는 박혔으나 Tistory 측 신규 글이 없음 = 직전 세션 가짜 발행 잔재
- **액션**: publish 단계 추가 진행 금지 (오염 가중). daily_counts 임의 보정은 SSOT 변경이므로 **사용자 확인 후에만** 수행.

## ✅ check_state_consistency.py 3.9 호환 (289차 패치 완료)

PEP 604 union (`str | None`, `int | None`) → `Optional[str]`, `Optional[int]` 변환으로 `/usr/bin/python3` (3.9)에서 정상 실행. 더 이상 inline 우회 불필요.

신호 4 추가로 drift 시나리오 커버리지 확장:
1. last_published_url ↔ last_topics[-1].url 불일치
2. last_url 있는데 daily_counts[오늘] = 0
3. 비정상 슬롯 (≤ 0)
4. **daily_counts[오늘] ≥ 2 + details[-1] 슬롯 변동 없음 (FAKE_PUBLISH)** ← 289차 신규