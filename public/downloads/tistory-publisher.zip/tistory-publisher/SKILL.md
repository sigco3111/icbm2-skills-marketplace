---
name: tistory-publisher
description: Tistory 블로그 자동 발행 — 쿠키 기반 내부 API를 사용하여 글 작성/발행
version: "1.8.26"
last_updated: "2026-06-09-94th-cron"
references:
  - blog-pipeline-stuck-diagnosis.md   # 87차: "할당량 소진" 오해 → 주제 풀 고갈 진단
  - known-issues.md
  - cjk-dictionary-75.md
  - korean-text-corruption-patterns.md
  - cjk-loop-residuals-1-75.md
  - quality-gate-false-positives.md
  - session-20260524.md
  - session-20260525.md
  - cjk-70th-batch.md
  - cjk-71st-batch.md
  - cjk-72nd-batch.md
  - cjk-74th-batch.md
  - session-20260529.md
  - session-20260529-75th.md
  - cjk-prevention-checklist.md
  - session-20260530.md
  - cjk-77th-batch.md
  - cjk-78th-batch.md
  - execute_code-cron-blocked.md
  - session-20260601.md
  - cjk-79th-batch.md
  - session-20260602.md
  - cjk-80th-batch.md
  - cjk-81st-batch.md
  - cron-mode-constraints.md
  - zero-cjk-pattern.md
  - session-20260603.md
  - session-20260604.md
  - image-auto-insert-policy-conflict.md
  - session-20260607.md
  - session-20260608.md
  - session-20260608-84th.md
  - session-20260608-85th.md
  - session-20260608-86th.md
  - session-20260608-88th.md   # 88차: 트렌드 비교형 false positive + grade JSON 키 검증
  - session-20260608-88th-publish.md   # 88차 발행 세션: 14단계 워크플로우 실전 검증 + has_conclusion false positive + readability 감점
  - session-20260608-89th.md   # 89차: --record 4인자 함정 재실수 + 본문 figure 2장 + publisher 자동 OG 동시 사용 무충돌 검증 + readability 단문 25% 가설 1차 검증
  - session-20260608-90th.md   # 90차: S 등급 86.0점 첫 달성 + readability 단문 25% 가설 2차 검증 (14/20) + --record 3인자 안정화 재확인
  - session-20260608-91st.md   # 91차: H2 7개 확장 시 readability 역효과 (12/20) 검증 + A 등급 75점 fallback + 단문 25% 가설 3차 검증
  - session-20260608-92nd.md   # 92차: H2 9개 readability 12/20 (H2 7개와 동점) 검증 + "요약" 단독 H2의 has_conclusion false positive 3회 확정 + A 78점
  - session-20260608-93rd.md   # 93차: H2 5개 readability 10/20 (본문 3052자 영향) + "마무리" 키워드도 has_conclusion false 회귀 + dfn 영문 오타 clean_cjk 미감지
  - session-20260608-94th.md   # 94차: 92차 권고 3종("## 결론", "## 결론: 핵심 정리", "## 결론과 마무리") 전부 has_conclusion false 확정 + SKILL.md 가설 전면 정정 + 가설 폐기 선언
---

# Tistory 자동 발행 스킬

## ⚠️ Known Issues

### 🔴 이미지 + 개행 누락 문제 (2개월 이상 미해결)
**Symptom:** 발행된 블로그 글에 이미지가 표시되지 않고, 개행(line break)이 완전히 사라짐.
**First reported:** 2026-04-20 21시 발행 글
**Status:** 미해결 (learning-gap-tracker 등록됨, 우선순위 high)
**Root cause:** 未特定 — `tistory_publisher.py`의 HTML 생성 로직 분석 필요

### 🟡 Korean word boundary corruption (2026-05-23, 70차 및 2026-05-26, 72차)
CJK 정제 시 Chinese 복합어가 포함된 Korean 문장이 점진적으로 파괴됨. `references/korean-text-corruption-patterns.md` 및 `references/cjk-72nd-batch.md` 참조.

**72차 신규 패턴:** "很有意思하다" → "有意思하다" → "하다." (순차 문자 제거). Chinese 복합어 "很有意思"의 개별 문자(很/有/意/思)가 CJK cleaning dict로 순차 제거되어 문장이 파괴됨. 예방: CJK cleaning 전 preemptive Chinese → Korean 교체 실행.

**85차 신규 패턴:** 2글자 단일 Chinese compound `试用` (시용/체험) 가 한국어 문장 끝에 그대로 보존. 1차 CJK 검사(`[\u4e00-\u9fff]`)가 2자 모두 검출. **72차와 달리 단계적 파괴가 아니라 단일 출현**이라 `patch` 도구로 `试用` → `체험` 직접 치환이 가장 빠름. 예방: 1차 CJK 검사 시 `[\u4e00-\u9fff]{2,}` 인접 그룹 감지 → 한국어 동의어 일괄 치환 제안 로직 검토 (86차~).

**86차 신규 패턴:** 동사 통째 CJK `跟不上` (따라가지 못하다) 가 한국어 어순(`~이 跟不上 ~`)에 그대로 보존. 1차 CJK 검사(`[\u4e00-\u9fff]+`)에서 1건으로 검출되어 발견 즉시 한국어 구문(`~이 ~를 따라가지 못하는`)으로 교체. **85차 단일 compound와 같은 계열**이지만 동사/숙어라는 점에서 더 은밀. **3종 CJK corruption 패턴 통합 분류:** (1) 단계적 파괴형 (70/72차) → CJK cleaning 루프가 글자 순차 제거, (2) 단일 compound 보존형 (85차) → 1차 검사로 사전 차단, (3) 동사 통째형 (86차) → 1차 검사로 사전 차단. **공통점: 모두 1차 CJK 검사에서 검출 가능** → clean_cjk 루프 진입 전에 1차 검사로 사전 차단하는 게 가장 안전. 87차~ 1차 검사 + 한국어 동의어 사전 일괄 치환 로직 도입 권장 (자세한 86차 실행 검증은 `references/session-20260608-86th.md` 참조).

### 🟡 markdown_to_tistory_html.py 제목 인식 문제 (2026-05-22)
`blog_quality_gate.py --file`가 H1을 제목으로 오인. `--title` CLI로 별도 전달. **2026-06-08 84차 확인:** `--file`만 단독 사용 시 `{"error": "title_and_content_required"}` 에러 반환. 반드시 `--title` 명시.

### 🟡 blog_pipeline.py --record 시그니처 분쟁 (84차 발견, 89차 재실수)
**현 시그니처 (84차/89차 검증):** `python3 ~/.hermes/scripts/blog_pipeline.py --record "TOPIC" "TITLE" "URL"` — **3인자. 4번째 인자 없음.**

**89차 재실수 사례:** 4인자(`... "URL" "TOPIC_URL"`)로 호출 → `unrecognized arguments` 에러로 거절됨. 88차 세션 노트와 SKILL.md 본문에는 "3인자"라고 명시했으나 매 세션 새로 합류하는 에이전트가 같은 함정에 빠짐. SKILL.md 본문 강화 + 세션 노트 + `--help` 출력 패턴 모두로 못 막았음.

**강제 규칙 (90차~):**
1. `python3 ~/.hermes/scripts/blog_pipeline.py --help` 를 **출판 직전 (record 단계 #13)** 무조건 실행해 `--record` 행을 직접 확인.
2. **3인자**만 사용. `topic_url`을 4번째 인자로 넘기는 코드는 작성하지 마라.
3. `topic_url`이 따로 필요한 경우, `published_urls.txt`에 URL만 들어가는지 확인하는 것만으로 충분 (84차/89차 검증: 3인자도 `published_urls.txt` 정상 갱신). TOPIC_URL은 `published_topics.json` 해시에 자동 포함되지 않으므로 별도 저장 불필요.

`--help` 출력 예시 (84차/89차 동일):
```
--record TOPIC TITLE URL
```

### 🟡 rm -rf 후 cwd 소실로 git 명령 실패 (2026-06-08 84차 발견)
**Symptom:** Step 7에서 `rm -rf /tmp/blog-images-repo && git clone ...`를 cron 모드(작업 디렉터리 = `~/.hermes/hermes-agent` 등)에서 실행하면, `rm -rf`가 현재 작업 디렉터리를 지워서 `fatal: Unable to read current working directory: getcwd: cannot access parent directories: No such file or directory` 에러 발생. 후속 `cd /tmp/blog-images-repo`도 실패.
**원인:** heredoc/파이프 없이 한 줄에 `rm -rf` + 다른 명령 결합 시 bash가 첫 명령의 부작용으로 cwd를 잃음.
**해결:** 각 git/rm 명령을 `workdir=/tmp` 또는 `workdir=/tmp/blog-images-repo`로 분리 호출 (terminal 도구 `workdir` 파라미터 사용). `cd /tmp && rm -rf ... && git clone ...`도 cwd 변경에 의존하므로 신뢰도 낮음. **terminal 도구에서는 `workdir`을 명시적으로 지정하는 것이 가장 안전.**

### 🟡 "할당량 소진" 메시지 오해 — 진짜 원인은 주제 풀 소진 (2026-06-08 87차 발견)
**Symptom:** cron이 `'기타' 카테고리의 긱뉴스 주제와 트렌드 주제 모두 소진되었습니다`라는 skip 메시지를 뱉음. 사용자도 운영자도 처음에 "발행 횟수 제한(할당량)"으로 오해함.
**진짜 원인 (코드 검증 완료):**
- `MAX_POSTS_PER_CATEGORY_PER_DAY`는 무제한(현 100 안전망), `can_publish_category()`는 사실상 항상 True → **카운트 제한은 아님**
- 진짜 차단은 (a) `select_best_category()`가 후보 카테고리 순회 중 available topic 0개만 만나서 None 리턴, 또는 (b) `run_pipeline()`이 후보 카테고리에서 1순위(긱뉴스)·2순위(트렌드) 둘 다 dedup에 걸려 skip
- dedup은 두 군데: `~/.hermes/memory/published_topics.json`(topic hash) + `~/.hermes/memory/published_urls.txt`(긱뉴스 URL)
- **자주 보이는 진짜 트리거: Notion 긱뉴스 fallback DB가 텅 빔.** `~/.hermes/memory/fallback_topics_cache.json`이 카테고리 6개 중 '개발팁' 2개만 담고 있으면, AI/ML/iOS/개발도구/투자/경제/아이디어/기타 모두 available=0이라 발행 불가. `b02a45f4d14e` (블로그 주제 갱신) 크론이 평일 13시에 한 번만 돌기 때문에 캐시 신선도가 떨어지면 발행 불가 시간대가 길어짐.
**진단 절차 (사용자 요청 시 즉시 실행):**
1. `python3 ~/.hermes/scripts/blog_pipeline.py --status` → 카테고리별 오늘 발행 건수와 "기타" 제외 표시 확인
2. `cat /Users/hjshin/.hermes/memory/fallback_topics_cache.json | python3 -c "import json,sys; d=json.load(sys.stdin); t=d.get('topics',{}); [print(f'  {c}: {len(v)}') for c,v in t.items()]; print('cached_at:', d.get('cached_at'))"` → 카테고리별 토픽 수
3. `wc -l /Users/hjshin/.hermes/memory/published_urls.txt` → 누적 dedup URL 수
4. `python3 ~/.hermes/scripts/blog_pipeline.py --refresh-topics` → Notion 긱뉴스 DB 재충전 (12개 선정)
5. 위 후에도 발행 안 되면: `cat /Users/hjshin/.hermes/memory/blog_pipeline_state.json | python3 -m json.tool | head -40` 으로 daily_counts가 비정상 누적됐는지 확인
**해결 옵션 (상황별):**
- "주제 풀이 정말 텅 빔" → `--refresh-topics` 후 다음 cron 주기 대기
- "하루 N건 이상 발행하고 싶음" → `MAX_POSTS_PER_CATEGORY_PER_DAY` 조정 (코드에 명시된 100 안전망 참고)
- "'기타' 카테고리가 자주 발목 잡음" → `select_best_category()`의 priority 리스트에서 제외, `run_pipeline()`에 None 가드 추가
**자동 진단 스크립트:** `references/blog-pipeline-stuck-diagnosis.md` 참조, `scripts/diagnose_blog_skip.sh` 사용

### 🟡 Notion 긱뉴스 fallback DB 캐시 신선도 갱신 주기 불일치 (2026-06-08 87차 발견)
**Symptom:** `load_fallback_topics_from_notion()`이 1시간 캐시를 쓰는데, 새 긱뉴스가 매시간 RSS에 올라옴에도 cron이 1시간마다 돌면 12개 캐시가 빠르게 소진됨. 한 사이클에 12개 다 발행되고 나면 그 다음 11시간은 skip.
**완화:** Notion 긱뉴스 DB에 후보가 항상 12개 이상 있도록 `--refresh-topics`를 수동으로 자주 돌리거나, `b02a45f4d14e` 크론의 주기를 늘려야 함 (단, 1시간 cron이 트래픽을 유발할 수 있어 신중).

---

## 개요

Tistory 공식 Open API가 종료된 후, 브라우저 내부 API를 사용하여 Python으로 블로그 글을 자동 발행합니다.

## 진단 스크립트 (87차)

skip 알람이 울리면 즉시:

```bash
bash ~/.hermes/skills/automation/tistory-publisher/scripts/diagnose_blog_skip.sh
```

→ 5초 안에 원인 + 해결 출력. 자세한 진단 절차는 `references/blog-pipeline-stuck-diagnosis.md`.

---

## cron 모드 표준 워크플로우 (84차 검증, 14단계)

`execute_code`는 cron 모드에서 차단됨 (`references/cron-mode-constraints.md` 참조). 아래 14단계는 **모두 `terminal` 도구 + `python3 -c "..."` heredoc**으로만 실행해야 한다.

1. `python3 ~/.hermes/scripts/blog_pipeline.py` (terminal) → JSON에서 `selected_topic` 확인
2. `mcp_ddg_search_fetch_content URL` → 긱뉴스 본문 수집 (DDG 검색 0 results 시 즉시 폴백, 본문만으로 진행)
3. `write_file /tmp/blog_post.md` → 한국어 Markdown 초안 (CJK 사전 삽입 금지)
4. `python3 -c "import re... [\u4e00-\u9fff] 검사"` (terminal) → Markdown CJK 1차 검사
5. `python3 ~/.hermes/scripts/markdown_to_tistory_html.py /tmp/blog_post.md /tmp/blog_tistory.html` (terminal)
6. `python3 -c "...clean_cjk 루프..."` (terminal) → HTML CJK cleaning
7. `rm -rf /tmp/blog-images-repo && git clone https://github.com/sigco3111/blog-images.git /tmp/blog-images-repo` (terminal, `workdir=/tmp` 명시)
8. `curl -sL "https://picsum.photos/seed/{키워드}/800/400" -o /tmp/blog-images-repo/2026MMDD-{키워드}-{해시}.jpg` (terminal, `workdir=/tmp/blog-images-repo`)
9. `cd /tmp/blog-images-repo && git add && git commit && git push origin main` (terminal, `workdir=/tmp/blog-images-repo`)
10. `python3 -c "...figure 커버 삽입..."` (terminal) → HTML `<h1` 앞에 cover figure 삽입
11. `python3 ~/.hermes/scripts/blog_quality_gate.py --title "제목" --file /tmp/blog_tistory.html --tags "..." --category "개발도구"` (terminal) → A 등급 확인
12. `python3 ~/.hermes/scripts/tistory_publisher.py --title "제목" --content "$(cat /tmp/blog_tistory.html)" --tags "..." --visibility public --category 1219748` (terminal) → 발행. **85차 확인:** publisher는 본문 `<figure>` 를 그대로 보존하면서 **별도** OG 썸네일 이미지를 자동 업로드·설정. 본문 figure와 OG 썸네일은 독립. **89차 검증:** 본문 figure **2장** (커버 1 + 인라인 1) + publisher OG 자동 업로드 동시 사용 시 충돌 없음. OG 썸네일은 1장만 자동 업로드·설정되며 본문 figure 2장은 그대로 보존됨. 3장 이상은 미검증.
13. `python3 ~/.hermes/scripts/blog_pipeline.py --record "주제" "발행된 제목" "발행 URL"` (terminal) → 중복 방지 기록
14. `rm -f /tmp/blog_post.md /tmp/blog_tistory.html` (terminal) → 임시 파일 정리

## ⚠️ 88차 검증: quality_gate 호출은 `head -30` (grade/decision/총점 위치)
**Pitfall:** 14단계 #11에서 `python3 ~/.hermes/scripts/blog_quality_gate.py ... | tail -50`을 쓰면 JSON이 길어 `total_score`/`grade`/`decision`이 잘려 안 보임. `breakdown` 내부 detail만 출력됨. 88차에서 첫 `tail -50`은 A 등급을 놓치고 `head -30`으로 재호출.
**표준 호출 (89차~):**
```bash
python3 ~/.hermes/scripts/blog_quality_gate.py \
  --title "..." --file /tmp/blog_tistory.html \
  --tags "..." --category "..." 2>&1 | head -30
```
→ 1~2줄에 `total_score`, `grade`, `decision` (pass/fail)이 모두 나옴.

## ⚠️ 88차 발견: `has_conclusion: false` false positive — 마지막 H2는 "결론"으로
**Symptom:** 88차 본문에 `## 요약: 핵심 포인트 5가지`가 분명히 있는데도 `breakdown.content.has_conclusion: false`로 감점. (게이트가 헤더 텍스트에 "결론" 또는 "마무리" 키워드를 기대하는 듯, "요약"으로는 매칭 안 됨 — 코드 미확인)
**해결 (89차~ 권장):** 본문 마지막 H2를 다음 중 하나로 작성:
- `## 결론: 핵심 정리` 또는
- `## 마무리: 향후 전망` 또는
- `## 요약과 결론` (두 키워드 모두 포함)
→ has_conclusion true 판정 시 가점 회수 (76점 → 80점대 진입 가능).

**92차 3회 검증으로 패턴 확정:**
- 88차: `## 요약: 핵심 포인트 5가지` → has_conclusion false
- 91차: `## 요약: 핵심 포인트 5가지` → has_conclusion false
- 92차: `## 요약: 핵심 정리` → has_conclusion false
- **결론:** "요약" 단독으로는 트리거 안 됨. **마지막 H2에 "마무리" 또는 "결론" 키워드를 반드시 포함**하라. "요약:" prefix만 붙이지 말고, "마무리: 핵심 정리" 또는 "결론과 요약" 형태로 끝내라.

## ⚠️ 88차 발견: readability 11/20 감점 회피 — 단문 30% 섞기
**Symptom:** 88차 본문 평균 문장 길이 71.186자 (86문장) → readability 11/20. 80점대 진입 저해.
**해결 (89차~ 권장):** H2 섹션 하나당 4~5문장, 그중 1~2개는 20~30자 단문. 한 문단(80~120자)을 2개로 쪼개기. 목표: 평균 50~60자.
**89차 실전 검증:** "마무리: 향후 전망" H2 + 본문 단문 비중 약 25% → 평균 76.95자 (78문장) → readability 12/20. 88차 대비 +1점. 목표 50~60자에 한참 못 미치지만 단문 섞기만 해도 효과 있음. 90차~ 더 적극적으로 한 문단을 2개로 쪼개서 평균 50자대 진입 시도.

**90차 실전 검증 (2차):** H2 5개 + "마무리: 향후 전망" H2 + 단문 7~8개 (비중 25%) → 평균 72.9자 (63문장) → readability 14/20. **S 등급 86.0점 첫 달성.** 88→89→90 가설 검증 결과:
- 88차: 11/20 (단문 비중 0%)
- 89차: 12/20 (단문 5개, 25%)
- 90차: 14/20 (단문 7~8개, 25% + H2 5개 압축)
- **결론:** 단문 + 짧은 섹션 조합이 readability 14/20을 안정적으로 뽑아냄. 91차~ 동일 패턴 유지. 평균 50자대 진입보다 14/20을 안정적으로 유지하는 게 우선.

**91차 실전 검증 (3차) — 가설 부분 반증 + 정정:** H2 7개 (90차 5개에서 +2개) + "마무리: 향후 전망" H2 → 평균 72.5자 (87문장) → readability **12/20** (90차 대비 -2점). **A 등급 75.0점 (90차 S 86.0점 대비 -11점).** 본문은 양호했으나 H2를 늘리자 각 H2 내 문장 수가 늘어 평균 문장 길이가 거의 동일했고, 단문 25% 비중이 본문 길이 증가로 희석됐다.
- 88차: 11/20 (단문 0%, H2 적음)
- 89차: 12/20 (단문 5개, 25%)
- 90차: 14/20 (단문 7~8개, 25% + H2 **5개**)
- 91차: 12/20 (단문 비슷, H2 **7개**)
- **정정된 결론 (91차~):** H2 개수 자체보다 **H2당 문장 수**가 readability 핵심. 92차~ **H2 5개 ±1 (4~6개)** + **단문 7~8개 (25%)** + **H2당 4~5문장** 패턴을 안정화 권장. H2 7개 이상으로 확장하면 각 H2가 더 많은 분량을 가져 평균 문장 길이가 다시 70자대로 올라가 14/20 회복 불가.

**92차 실전 검증 (4차) — H2 황금대 4~6개 최종 확정:** H2 9개 (91차 7개에서 +2개) + "요약: 핵심 정리" H2 (has_conclusion false) → 평균 67.7자 (53문장) → readability **12/20** (91차와 동점). **A 등급 78.0점 (90차 S 86.0점 대비 -8점).**
- **92차: 12/20 (단문 비슷, H2 **9개**)** ← 신규
- **최종 결론 (92차~):** H2 4~6개가 readability 황금대. H2 7개 이상은 본문 길이 확장으로 단문 비중이 희석되고 H2당 문장 수가 늘어나 점수 회복 불가. **93차~ H2 4~6개 + 마지막 H2에 "마무리" 또는 "결론" 키워드 + 단문 25%** 세 가지 동시 충족 권장. S 등급 80점대 회수 조건.

**93차 실전 검증 (5차) — H2 5개 readability 10/20 (90차 14/20 대비 -4점) + "마무리" has_conclusion false 회귀:**
- H2 5개 (92차 황금대 내) + "마무리: 1차 빌드가 로드맵에 없다면" H2 (has_conclusion false 회귀) + 본문 3052자 → 평균 67.3자 (44문장) → readability **10/20** (90차 14/20 대비 -4점). **A 78점.**
- **추가 정정 (93차~):** H2 4~6개가 readability 12/20을 안정적으로 보장하지만, **90차 14/20은 H2 5개 + 본문 2300~2500자 + 단문 7~8개 + 마지막 H2 has_conclusion true의 4중 조합**이었던 것으로 추정. 93차는 H2 5개 + 본문 3052자(더 김) → 90차보다 본문이 길어 단문 비중이 희석되고 readability 10/20으로 하락. **94차~ H2 4~6개 + 본문 2300~2500자(tistory_publisher "Content 검증 통과" 기준) + 단문 7~8개 + 마지막 H2 `## 결론: ...`** 4중 조합 권장.
- **94차~ 마지막 H2 자유 선택 가능:** has_conclusion 가설 폐기. 어떤 키워드를 쓰든 false이므로, 마지막 H2 텍스트에 시간 쓰지 말고 주제/흐름에 맞는 자연스러운 제목을 사용하라. 가설 폐기 + 코드 read 권장은 `references/session-20260608-94th.md` 참조.

**94차 전면 정정 — 92차 권고 후보 3종 전부 false 확정 (가설 폐기):**
- 94차에 92차 1순위~3순위 후보(`## 결론`, `## 결론: 핵심 정리`, `## 결론과 마무리`)를 순차 시도했으나 **전부 has_conclusion false** (3회 추가 검증). 88→91→92→93→94 누적 7회 false. 92차 가설이 완전히 틀렸음이 실전으로 확정.
- **가설 폐기 선언 (95차~):** keyword trial-and-error로 has_conclusion을 true로 만들려는 시도를 그만둬라. 본문 마지막 H2 후보는 자유롭게 선택해도 무방 (어떤 키워드도 false이므로).
- **실제 해결 (95차~ 권장):** `~/.hermes/scripts/blog_quality_gate.py` 소스를 직접 read → `has_conclusion` 또는 `conclusion` 검색 → 실제 트리거 조건 (정규식? 길이? 마지막 문단? 첫 문장?) 파악. 코드 검증 전까지는 has_conclusion false가 기본값이라고 가정.
- **영향 평가 (94차 실측):** has_conclusion false는 2~4점 감점 (content 33~34/35). decision=pass(75점)에는 영향 없음. S 등급 80점대 진입에는 영향. 현시점 패치 우선순위 낮음. **96차~ 가설 검증 후 시간 있을 때 코드 읽기 권장.**
- **94차~ 마지막 H2 자유 선택 가능:** has_conclusion 가설 폐기. 어떤 키워드를 쓰든 false이므로, 마지막 H2 텍스트에 시간 쓰지 말고 주제/흐름에 맞는 자연스러운 제목을 사용하라. 가설 폐기 + 코드 read 권장은 `references/session-20260608-94th.md` 참조.

- Tistory 블로그 계정
- 쿠키 파일: `$TISTORY_COOKIE_PATH` (예: `secrets/tistory.env`)
- Python requests 라이브러리

## 쿠키 획득 방법

1. Chrome에서 https://www.tistory.com 로그인
2. 브라우저에서 글쓰기 후 [발행] 클릭
3. F12 → Network 탭 → "로그 유지" 체크
4. `post.json` 요청 우클릭 → Copy → Copy as cURL
5. 쿠키 값 추출 후 `$TISTORY_COOKIE_PATH`에 저장

### 쿠키 필드

| 쿠키 | 환경변수명 | 설명 |
|------|-----------|------|
| REACTION_GUEST | TISTORY_REACTION_GUEST | 게스트 토큰 |
| \_\_T\_ | TISTORY\_\_\_T\_ | 로그인 플래그 |
| \_\_T\_SECURE | TISTORY\_\_\_T\_SECURE | 보안 플래그 |
| TSSESSION | TISTORY_TSSESSION | 세션 ID |
| \_T\_ANO | TISTORY\_\_T\_ANO | 인증 토큰 (주기적 갱신 필요) |

⚠️ **\_T\_ANO 쿠키는 시간이 지나면 만료됩니다.** 발행 실패 시 다시 쿠키를 갱신하세요.

## API 명세

### 글 발행

```
POST https://{blog}.tistory.com/manage/post.json
Content-Type: application/json
Cookie: REACTION_GUEST=...; __T_=1; __T_SECURE=1; TSSESSION=...; _T_ANO=...
```

### 요청 본문 (JSON)

```json
{
  "id": "0",
  "title": "글 제목",
  "content": "<p data-ke-size=\"size16\">HTML 본문</p>",
  "slogan": "",
  "visibility": 0,
  "category": 0,
  "tag": "태그1,태그2",
  "published": 1,
  "password": "8자리문자",
  "uselessMarginForEntry": 1,
  "cclCommercial": 0,
  "cclDerive": 0,
  "type": "post",
  "attachments": [],
  "recaptchaValue": "",
  "draftSequence": null
}
```

### 응답

성공:
```json
{"entryUrl": "https://blog.tistory.com/123"}
```

실패:
```json
{"data": null, "message": "에러 메시지"}
```

### 파라미터 설명

| 파라미터 | 설명 | 값 |
|----------|------|-----|
| id | "0"=신규, 기존 ID=수정 | string |
| visibility | 공개 범위 | 20=공개, 0=비공개 (2026-04-08 검증) |
| category | 카테고리 ID | 0=카테고리 없음 |
| published | 발행 여부 | 1=발행, 0=임시저장 |
| type | 글 타입 | "post" 또는 "page" |
| password | 랜덤 8자리 | md5 해시 일부 |
| uselessMarginForEntry | 여백 설정 | 1 (고정) |

### 이미지 업로드

```
POST https://{blog}.tistory.com/manage/post/attach.json
Content-Type: multipart/form-data
Cookie: (same as post endpoint)
```

요청: `file` 필드에 이미지 파일 전송

응답:
```json
{"name":"image.jpg", "url":"https://blog.kakaocdn.net/dna/...", "key":"...", "filename":"img.jpg", "size":12345}
```

### 이미지 삽입 (GitHub 호스팅)

Tistory CDN 업로드(`attach.json`)는 불안정하므로 사용하지 마라. **GitHub 저장소를 이미지 호스팅**으로 사용한다.

**이미지 저장소:** `sigco3111/blog-images` (public)
**로컬 클론:** `/tmp/blog-images-repo/`

**이미지 추가 방법:**
```bash
cd /tmp/blog-images-repo && git pull
cp /path/to/image.jpg /tmp/blog-images-repo/{이름}.jpg
cd /tmp/blog-images-repo && git add {이름}.jpg && git commit -m "Add {이름}" && git push origin main
```

**GitHub raw URL 형식:**
```
https://raw.githubusercontent.com/sigco3111/blog-images/main/{filename}
```

**HTML 삽입:**
```html
<figure data-ke-type="image" data-ke-style="alignCenter">
  <img src="https://raw.githubusercontent.com/sigco3111/blog-images/main/{filename}"/>
  <figcaption>캡션 텍스트</figcaption>
</figure>
```

### 기타 API

| 엔드포인트 | 설명 |
|-----------|------|
| GET /manage/posts.json?category=-3&page=1 | 글 목록 |
| GET /manage/category.json | 카테고리 목록 |
| GET /manage/post/{id}.json | 글 상세 (수정 시) |
