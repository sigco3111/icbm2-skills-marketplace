---
name: tistory-publisher
description: 'ICBM2 Tistory(sigco.tistory.com) 자동 발행 워크플로 — 트렌드 데이터 새로고침 → 카테고리별 발행 시도 → §3.5 3중 신호 검증 → §3.11 sync → §4 stats 보정의 정형 파이프라인. §3.8.1 세션 만료 가드 (302 → /auth/login) 통과시에만 publish 단계 진행, 실패시는 단순 skip 후 §3.5 검증만 실행. 가짜 발행(통계+1 + 실제 글 없음) 방지 최우선. cron으로 자동 실행되며 사용자가 직접 호출할 일은 드묾. 트리거 — "Tistory 발행", "블로그 자동 발행", "§3.8.1 가드", "가짜 발행 방지", "ICBM2 publish".'
---

# Tistory Publisher (ICBM2)

ICBM2 자동화 시스템의 Tistory 발행 워크플로우. **287차+ 연속 all-green 운영 중** (2026-07-18 기준 75회차).

## ⛔ 최우선 규칙

1. **§3.8.1 세션 만료 가드 통과시에만 publish 단계 진행**. 실패시 → 단순 skip + §3.5 검증만 실행 후 종료.
2. **가짜 발행 절대 금지**: 통계(daily_counts) +1 후 실제 Tistory 글 없이 종료 불가.
3. **중복 skip 후 publish 금지**: dedup 통과하지 않은 topic을 publish하면 통계 오염.
4. **publish 후 details/last 갱신 필수**: 191차 §8.5.2 무효화 환경 의존 패턴.

## 실행 절차

### 1단계: §3.8.1 세션 만료 가드 (필수, publish 직전)

`scripts/session_expiry_guard.sh` 실행. 통과시에만 다음 단계 진행.

```bash
unset PYTHONPATH
~/.hermes/skills/tistory-publisher/scripts/session_expiry_guard.sh
# exit 0 → 진행 / exit 1 → 세션 만료, skip
```

### 2단계: 트렌드 데이터 확인

```bash
unset PYTHONPATH
env -i HOME="$HOME" PATH=/usr/bin:/bin PYTHONPATH= /usr/bin/python3 \
  ~/.hermes/scripts/blog_pipeline.py --refresh-topics
```

### 3단계: 카테고리별 발행 시도 (AI/ML 우선)

```bash
unset PYTHONPATH
env -i HOME="$HOME" PATH=/usr/bin:/bin PYTHONPATH= /usr/bin/python3 \
  ~/.hermes/scripts/blog_pipeline.py --category 'AI/ML'
```

### 4단계: §3.5 3중 신호 검증 (publish 직후 + 가드 skip시 둘 다)

```bash
unset PYTHONPATH
env -i HOME="$HOME" PATH=/usr/bin:/bin PYTHONPATH= /usr/bin/python3 \
  ~/.hermes/skills/tistory-publisher/scripts/check_state_consistency.py
```

3중 신호:
1. `state.last_published_url` — 직전 발행 슬롯
2. `state.daily_counts[오늘]` — 카테고리별 카운트
3. `state.last_topics[-1]` — 직전 발행 topic 메타

### 5단계: §3.11 5단계 sync + §4 5-1 stats 보정 (publish 성공시만)

- `details[-1].url`이 직전 글 번호와 안 바뀌었으면 → heredoc으로 `last + details` 동시 append
- `daily_counts[오늘]` 안 올라갔으면 → §4 5-1 보정 코드 실행
- §3.11/§4 상세 내용은 다음 차 워프룔에서 references에 추가 예정 (현재 미검증)

## ⚠️ 필수: 환경 격자 (Python venv PYTHONPATH 누설 차단)

Hermes venv의 urllib3가 Python 3.9 호환성 문제로 `/usr/bin/python3` import 시 깨짐. **모든 cron 스크립트는 격자 실행**:

```bash
unset PYTHONPATH
env -i HOME="$HOME" PATH=/usr/bin:/bin PYTHONPATH= /usr/bin/python3 <script>
```

자세한 함정 진단: `references/section-3-8-1-session-guard.md`.

## 보고 형식

- **발행 N건 정상**: `#NNN #NNN #NNN` 한 줄
- **발행 0건 (가드 skip)**: `⏸️ 가짜 발행 가능성 있는 발행 skip (§3.8.1 가드 적용)`
- **발행 0건 (정상 skip, 중복 등)**: 짧은 사유 한 줄 + `daily_counts` 변화 없음 명시

## References

- `references/section-3-8-1-session-guard.md` — 세션 만료 가드 + venv PYTHONPATH 누설 함정 (288차 검증)
- `references/section-3-5-state-consistency.md` — 3중 신호 검증 패턴 (288차 검증)
- `references/session-20260718-289th-fake-publish-detection.md` — 289차 가짜 발행 5건 누적 사건 + 신호 4 도입 배경 (289차 검증)
- `references/session-20260718-291st-guard-false-positive-and-fake-publish-residual.md` — 291차 가드 env -i 오탐 → raw 검증 워크어라운드 + 가짜 발행 잔재 skip 운영 (291차 검증)

## Scripts

- `scripts/session_expiry_guard.sh` — 재사용 가능한 §3.8.1 가드 (exit 0/1/2/3)
- `scripts/check_state_consistency.py` — 재사용 가능한 §3.5 검증

## 환경/제약

- `~/.hermes/secrets/tistory.env` — TISTORY_* 쿠키 환경변수 (set -a source 필수)
- `~/.hermes/memory/blog_pipeline_state.json` — SSOT for daily_counts/last_published_url/last_topics
- `~/.hermes/scripts/tistory_publisher.py` — `publish_post()` / `--record-topic` 진입점
- `~/.hermes/scripts/blog_pipeline.py` — `run_pipeline()` / 카테고리별 발행 오케스트레이션

## 검증 이력

- **288차 (2026-07-18)** — §3.8.1 302 만료 가드 동작 확인, §3.5 3중 신호 통과 (state drift 0), venv 격자 패턴 발견. 발행 0건 (세션 만료로 skip). 연속 all-green 75회차.
- **287차 (2026-07-18 04:04)** — 직전 발행 #1043 (SpaceX IPO, AI/ML). 이 상태가 288차 §3.5 검증의 baseline.
- **289차 (2026-07-18 06:01)** — 세션 가드 VALID 통과 + 트렌드 12개 새로고침. **daily_counts[2026-07-18] = AI/ML 4 + 개발팁 1 = 5건 누적, 그러나 details[-1]=#1043 (287차) 그대로, 신규 Tistory 글 없음 → 5건 가짜 발행 확정**. last_topics[-1]은 Bun(개발팁) stale. **판단: 발행 skip** (stats 추가 박기 = 오염 가중). **조치 완료 (SKILL.md 갱신)** — `check_state_consistency.py`에 (1) PEP 604 → `Optional[…]`로 3.9 호환화 (2) 신호 4 FAKE_PUBLISH (daily_counts[오늘] ≥ 2 + details[-1] 슬롯 변동 없음 → exit 1) 추가. 다음 차 워크플로우 권장: 실제 Tistory `#1044~` 카운트로 daily_counts[2026-07-18] 차감 보정.
- **290차 (2026-07-18)** — `session_expiry_guard.sh` 자체 버그 발견: `env -i` 격리 모드에서 `tistory.env`를 source 안 해서 cookies 미주입 → `NO_COOKIES` (exit 10) → `❌ FAIL: 가드 실행 실패 (exit=10)`. 우회 검증으로 raw `env -i ... TISTORY_*=$TISTORY_*` 호출 시 **status=200 VALID** (실제 세션은 정상). **버그 수정 필수**: `set -a; source ~/.hermes/secrets/tistory.env; set +a` 후 격리 모드 진입, 또는 `env -i` 제거하고 그냥 `unset PYTHONPATH`만. §3.5 신호 4 FAKE_PUBLISH 활성 (daily_counts=5, details[-1]=#1043, Tistory #1044~#1046 전부 404) → 단순 skip 유지 (stats 추가 = 오염 가중).
- **291차 (2026-07-18 21:01)** — §3.8.1 가드 env -i 격리 모드 EXPIRED 오탐 → raw 검증 (`source tistory.env` 후 격리 없이 직접 python3) 워크어라운드로 **진짜 status=200 VALID** 확인. 트렌드 12개 새로고침, AI/ML ready (AIM 서버 호스팅, timeliness.fresh). 그러나 §3.5 신호 4 FAKE_PUBLISH 발동 (daily_counts[2026-07-18]=5, details[-1]=#1043 변동 없음) → **publish skip** (컨텐츠 생성/게시 없이 단순 종료). cron이 가짜 발행 잔재 상태에서 stats 추가 박기 금지 패턴 재확인. **결정 매트릭스** 신규: §3.8.1 raw VALID + §3.5 신호 4 → skip 우선.

## 🆘 가짜 발행 누적 감지 패턴 (289차 신규)

`check_state_consistency.py` 신호 4로 자동화됨 — cron 발행 워크플로우에서 exit code 1을 받으면 단순 skip:

- **트리거**: `daily_counts[오늘]` 합계 ≥ 2 **AND** `details[-1].url` == `last_published_url` (실제 새 글 0건)
- **판단**: stats는 박혔으나 Tistory 측 신규 글이 없음 = 직전 세션 가짜 발행 잔재
- **액션**: publish 단계 추가 진행 금지 (오염 가중). daily_counts 임의 보정은 SSOT 변경이므로 **사용자 확인 후에만** 수행.

## ✅ check_state_consistency.py 3.9 호환 (289차 패치 완료)

PEP 604 union (`str | None`, `int | None`) → `Optional[str]`, `Optional[int]` 변환으로 `/usr/bin/python3` (3.9)에서 정상 실행. 더 이상 inline 우회 불필요.

신호 4 추가로 drift 시나리오 커버리지 확장:
1. last_published_url ↔ last_topics[-1].url 불일치
2. last_url 있는데 daily_counts[오늘] = 0
3. 비정상 슬롯 (≤ 0)
4. **daily_counts[오늘] ≥ 2 + details[-1] 슬롯 변동 없음 (FAKE_PUBLISH)** ← 289차 신규