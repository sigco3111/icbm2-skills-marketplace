---
name: tistory-publisher
description: Tistory 블로그 자동 발행 — 쿠키 기반 내부 API를 사용하여 글 작성/발행
version: "v2.7.116"
last_updated: "2026-07-15-269th-crates-io-update"
---
# Tistory Publisher Skill (v2.7.116)

> **본문은 최근 5~6차 핵심 발견 + cleanup cron 임무 상태만 유지**. 232차 이전 stable 운영 가이드는 reference로 분리.
> **2026-07-15 (269차)**: **green-run confirmation + §3.34 #21 정책 실전 4호 (FRESH 1개 단독 비-AI/ML 비-기타 케이스)** — **`#1010 crates.io 6개월 개선 총정리 — 코드 뷰어, GitHub 분리, Svelte 이관까지 한 번에 풀어본 운영 인프라 재정의`** (개발도구/1219748, gn=31417, 4점, FRESH 1순위 — TOP 12개 중 11개 이미 259~268차 PUB 처리, FRESH 잔여 1개 단독) 정상 발행 — §3.8.1 가드 통과 (`status=200, ct=application/json;charset=UTF-8, cookie_count=8`), §3.34.43 PWD 보강 (`PWD=/Users/mac`), §3.34.40 FRESH 4-field (TOP 12개 중 11개 259~268차 PUB 처리: 31435/31432/31431/31411/31437/31406/31424/31408/31434/31407/31433 → FRESH 잔여 1개 단독: 개발도구 `31417`; **AI/ML FRESH=0** → §3.34 #21 정책 + §3.34.45 매트릭스 "FRESH 모두 'AI/ML 외 비-기타' → 점수 1순위 픽" 5번째 분기 단독 적용), §3.34.46 영구화 (`_try_md_endpoint(31417)` 직접 호출 → status=200, **7138 bytes** 1단계 `.md` endpoint 즉시 fetch), §3.34.47 영구화 검증 6회차 (`write_file` 로 `/tmp/tistory_drafts_269th/build_draft.py` UTF-8 선언 + 저장 → `python3 <script>.py` 격리 호출 정상, 6991 bytes 빌드 스크립트 무영향 — 263~268차 검증 패턴 그대로 적용), §3.34.48 `* ` 분기 + 4단계 헤더 강등 정규식 6회째 적용 (266차 정착 코드 그대로 복사 — 269차 본문은 모두 `- ` 패턴이라 hit 안 했지만 안전 가드 포함), §3.5 5중 신호 5/5 `#1010` 일치 (`all_match: True`), post_publish_sync `pt_updated: true / state_updated: true / errors: [] / triple_signal_match: true`, daily_counts[2026-07-15] = `{'AI/ML': 2, '개발도구': 3, '개발팁': 1, '투자/경제': 1}` (개발도구 2→3, +1 정확, cat_id 누설 0), state.details 86→87, pt.details 102→103 모두 박힘, cleanup cron 임무 #16 dry-run `✅ 누설 없음` (55→**56회** 연속 all-green), 이미지 2장 CDN 업로드 정상 (query: rust crates.io source code viewer package registry code terminal, Picsum ID 449, 두 슬롯 모두 동일 ID 자동 매칭 — 첫 시도 적중), 본문 4884자 (300자 가드 통과), 라이브 페이지 직접 GET `status=200, size=73349, title tag='crates.io 6개월 개선 총정리 &mdash; ...'` (실제 발행 확인). **연속 all-green 56회차 (213~269차)**. 가짜 발행 가드 정상. **본 세션 신규 발견 0건** — 268차 정착 패턴(§3.34.40 FRESH 4-field, §3.34.46 영구화, §3.34.47 격리 빌드, §3.34.48 `*` 분기 + 4단계 강등, §3.34.45 매트릭스 5번째 분기, §3.11 sync, §3.5 5중 검증, cleanup #16) 모두 269차에 6회째 정상 동작. 264차 `#1000` → 265차 `#1002` → 266차 `#1003` → 267차 `#1004` → 268차 `#1009` → **269차 `#1010`** 6회 연속 동일 워크플로 정착. **§3.34 #21 정책 실전 4호 검증**: 255차 1호 (FRESH AI/ML 1 + 기타 2 → AI/ML 픽), 266차 2호 (FRESH 모두 비-기타 비-AI/ML → 점수 1순위), 268차 3호 (FRESH 2개 모두 비-기타 비-AI/ML → 점수 1순위), **269차 4호** (FRESH 1개 단독 비-기타 비-AI/ML → 점수 1순위 픽). §3.34.45 매트릭스 5번째 분기 (`"FRESH 모두 'AI/ML 외 비-기타' → 점수 1순위 픽"`) 가드 단독 케이스에서도 정상 동작 확인. 차감/추가 없음. 모든 기존 패턴 정상 동작. 상세: `references/session-20260715-269th-crates-io-update.md`.
> **2026-07-15 (268차)**: **green-run confirmation + FRESH 2개 비-AI/ML 케이스 + §3.34 #21 정책 실전 3호 (AI/ML FRESH=0, 비-기타 비-AI/ML 카테고리 다수)** — **`#1009 GeekNews로 어쩌다가 취업하기 — 투자 AI 프로덕트 Cresco가 첫 커리어로 이어지기까지`** (투자/경제/1219747, gn=31434, 5점, FRESH 1순위 — 점수 1순위) 정상 발행 — §3.8.1 가드 통과 (`status=200, ct=application/json;charset=UTF-8, cookie_count=8`), §3.34.43 PWD 보강 (`PWD=/Users/mac`), §3.34.40 FRESH 4-field (TOP 12개 중 10개 이미 259~267차 PUB 처리 → FRESH 잔여 2개: 투자/경제 `31434` (5점) + 개발도구 `31417` (4점, crates.io); **AI/ML FRESH=0** → §3.34 #21 정책에 의해 다른 카테고리 발행 허용, §3.34 #22 '기타' 제외 정책에 의해 둘 다 '기타' 아님 → 발행 허용, **점수 1순위 `31434 (5점, 투자/경제)` 픽**), §3.34.46 영구화 (`_try_md_endpoint(31434)` 직접 호출 → status=200, **2772 bytes** 1단계 `.md` endpoint 즉시 fetch), §3.34.47 영구화 검증 5회차 (`write_file` 로 `/tmp/cron_268th/build_draft.py` UTF-8 선언 + 저장 → `python3 <script>.py` 격리 호출 정상, 6243 bytes 빌드 스크립트 무영향 — 263~267차 검증 패턴 그대로 적용), §3.34.48 `* ` 분기 + 4단계 헤더 강등 정규식 5회째 적용 (266차 정착 코드 그대로 복사 — 268차 본문은 모두 `- ` 패턴이라 hit 안 했지만 안전 가드 포함), §3.5 5중 신호 5/5 `#1009` 일치 (`triple_signal_match: true / all_match: True`), post_publish_sync `pt_updated: true / state_updated: true / errors: []`, daily_counts[2026-07-15] = `{'AI/ML': 2, '개발도구': 2, '개발팁': 1, '투자/경제': 1}` (투자/경제 0→1, +1 정확, cat_id 누설 0), state.details 85→86, pt.details 101→102 모두 박힘, cleanup cron 임무 #16 dry-run `✅ 누설 없음` (54→**55회** 연속 all-green), 이미지 2장 CDN 업로드 정상 (query: investment ai product startup founder laptop coffee, Picsum ID 853), 본문 6856 bytes / 3308자 (300자 가드 통과), 라이브 페이지 직접 GET `status=200, size=65448, title tag='GeekNews로 어쩌다가 취업하기 &mdash; ...'` (실제 발행 확인). **연속 all-green 55회차 (213~268차)**. 가짜 발행 가드 정상. **본 세션 신규 발견 0건** — 267차 정착 패턴(`* ` 분기, write_file 격리 빌드, §3.34.46 영구화) + 266차 정착 §3.34 #21 + §3.34 #22 정책 (FRESH 모두 비-AI/ML 비-기타 → 점수 1순위 픽) + §3.34.45 매트릭스 5번째 분기 "FRESH 모두 'AI/ML 외 비-기타' → 점수 1순위 픽" 모두 268차에 실전 3호 적용. 266차 Papermake → 267차 GhostLock → 268차 GeekNews 취업 3회 연속 동일 워크플로 정착. **§3.34 #21 정책 실전 3호 검증**: 255차 1호 (FRESH AI/ML 1 + 기타 2 → AI/ML 픽), 266차 2호 (FRESH 모두 비-기타 비-AI/ML → 점수 1순위), **268차 3호** (FRESH 2개 모두 비-기타 비-AI/ML → 점수 1순위). §3.34.45 매트릭스 5번째 분기 (`"FRESH 모두 'AI/ML 외 비-기타' → 점수 1순위 픽"`) 가드 정상 동작 확인. 차감/추가 없음. 모든 기존 패턴 정상 동작. 상세: `references/session-20260715-268th-geeknews-career.md`.
> **2026-07-15 (267차)**: **green-run confirmation + §3.34.47 영구화 검증 4회차 + §3.34.48 `* ` 분기 + 4단계 헤더 강등 정규식 4회째 적용** — **`#1004 GhostLock, 15년간 모든 Linux 배포판에 존재한 스택 UAF — 15년 동안 Linux 2.6.39~7.1에 잠복한 커널 UAF의 실체와 완화 가이드`** (AI/ML/1219746, gn=31407, 4점, FRESH 1순위 — AI/ML 후보 단독) 정상 발행 — §3.8.1 가드 통과 (`status=200, ct=application/json;charset=UTF-8, cookie_count=8`), §3.34.43 PWD 보강 (`PWD=/Users/mac`), §3.34.40 FRESH 4-field (TOP 12개 중 6개 262~266차 PUB 처리: 31404/31435/31432/31411/31406/31424 → FRESH 잔여 6개: 개발도구 3 + AI/ML 1 + 개발팁 1 + 투자/경제 1; **§3.34 #21 AI/ML 우선 정책**으로 AI/ML FRESH 4점 후보 `31407` 픽), §3.34.46 영구화 (`fetch_gn_content(31407)` → status=200, **15863 bytes** 1단계 `.md` endpoint 즉시 fetch), §3.34.47 영구화 검증 4회차 (`write_file` 로 `/tmp/tistory_drafts_267th/build_draft.py` UTF-8 선언 + 저장 → `python3 <script>.py` 격리 호출 정상, 7749 bytes 빌드 스크립트 무영향 — 263~266차 검증 패턴 그대로 적용), §3.34.48 `* ` 분기 + 4단계 헤더 강등 정규식 4회째 적용 (266차 정착 코드 그대로 복사 — 267차 본문은 모두 `- ` 패턴이라 hit 안 했지만 안전 가드 포함), §3.5 5중 신호 5/5 `#1004` 일치 (`triple_signal_match: true / all_match: True`), post_publish_sync `pt_updated: true / state_updated: true / errors: []`, daily_counts[2026-07-15] = `{'AI/ML': 1}` ({}→{AI/ML:1}, +1 정확, cat_id 누설 0), state.details 80→81, pt.details 96→97 모두 박힘, cleanup cron 임무 #16 dry-run `✅ 누설 없음` (53→**54회** 연속 all-green), 이미지 2장 CDN 업로드 정상 (query: linux kernel vulnerability exploit container escape dark code, Picsum ID 121), 본문 12952자 / 인트로 522자 / 결론 1305자 / 평문 11336자 (300자 가드 통과), 라이브 페이지 직접 GET `status=200, size=75459, title tag='GhostLock, 15년간 모든 Linux 배포판에 존재한 스택 UAF &mdash; ...'` (실제 발행 확인). **연속 all-green 54회차 (213~267차)**. 가짜 발행 가드 정상. **본 세션 신규 발견 0건** — 266차 식별 패턴(`* ` 분기, 4단계 헤더 강등) + 263차 정착 §3.34.47 격리 빌드 모두 4회째 정상 동작. 264차 `#1000` → 265차 `#1002` → 266차 `#1003` → 267차 `#1004` 4회 연속 동일 워크플로 정착. 차감/추가 없음. 모든 기존 패턴 정상 동작. 상세: `references/session-20260715-267th-ghostlock.md`.
> **2026-07-14 (266차)**: **green-run confirmation + §3.34.47 영구화 검증 3회차 + `* ` 리스트 패턴 추가 식별 + §3.34 #21 AI/ML 우선 정책 실전 2호 (AI/ML FRESH=0 케이스) + 모듈 import 함정** — **`#1003 Papermake - Typst 기반의 셀프 호스팅 가능한 PDF 문서 생성 서버`** (개발도구/1219748, gn=31432, 11점, FRESH 1순위) 정상 발행 — §3.8.1 가드 통과 (`status=200, ct=application/json;charset=UTF-8, cookie_count=8`), §3.34.43 PWD 보강 (`PWD=/Users/mac`), §3.34.40 FRESH 4-field (TOP 12개 중 5개 AI/ML 후보 31404/31435/31411/31406/31424 모두 262~265차 PUB 처리 → FRESH 잔여 7개: 개발도구 4 + 개발팁 1 + 투자/경제 1 + AI/ML 1; **§3.34 #21 AI/ML FRESH=0 케이스** → 다른 카테고리 발행 허용, FRESH 1순위 `31432 (11점, 개발도구)` 픽), §3.34.46 영구화 (`fetch_gn_content(31432)` → status=200, **1587 bytes** 1단계 `.md` endpoint 즉시 fetch, 본문 890자 추출), §3.34.47 영구화 검증 3회차 (`write_file` 로 `/tmp/tistory_drafts_266th/build_draft.py` UTF-8 선언 + 저장 → `python3 <script>.py` 격리 호출 정상, 5618 bytes 빌드 스크립트 무영향 — 263~265차 검증 패턴 그대로 적용), **§3.34.48 `* ` 리스트 패턴 추가 함정 (NEW, 266차 식별, 즉시 보완)**: GeekNews 31432 본문이 `- ` 외 `* ` 들여쓰기 패턴 혼용 (`* 완전한 감사 추적(Audit Trail)` 등). 기존 262차 정착 `md_to_html` 은 `- ` 만 처리하여 `* ` 라인이 그냥 `<p>` 로 떨어져 들여쓴 sub-list가 시각적으로 평평한 본문으로 변환됨. **회피**: `* ` 패턴도 동일하게 `<ul><li>` 변환 (stripped.startswith("* ") 분기 추가, 단 `**` bold 시작은 제외). 266차 첫 빌드에서 hit → 즉시 분기 추가하여 해결. 본문 빌드 스크립트에 정규식 `md_norm = re.sub(r"^#### (.+)$", r"### \1", md, flags=re.MULTILINE)` (4단계 헤더 → 3단계 강등) 추가하여 266차 Papermake 본문 정상 처리, §3.5 5중 신호 5/5 `#1003` 일치 (`triple_signal_match: true / all_match: True`), post_publish_sync `pt_updated: true / state_updated: true / errors: []`, daily_counts[2026-07-14] = `{'AI/ML': 10, '개발도구': 1}` (개발도구 0→1, +1 정확, cat_id 누설 0), state.details 79→80, pt.details 95→96 모두 박힘, cleanup cron 임무 #16 dry-run `✅ 누설 없음` (52→**53회** 연속 all-green), 이미지 2장 CDN 업로드 정상 (query: typst pdf document generation server code terminal abstract, Picsum ID 651), 본문 검증 1715자 (300자 가드 통과), 라이브 페이지 직접 GET `status=200, size=56153, title tag='Papermake - Typst 기반의 셀프 호스팅 가능한 PDF 문서 생성 서버'` (실제 발행 확인). **연속 all-green 53회차 (213~266차)**. 가짜 발행 가드 정상. **모듈 import 함정 (NEW, 266차 식별)**: `import tistory_publisher; tistory_publisher.publish(...)` 시도 → `AttributeError: module 'tistory_publisher' has no attribute 'publish'` (모듈에 `publish` 함수 부재, **CLI 인터페이스만 지원**). 회피: `subprocess` 로 `python3 /Users/mac/.hermes/scripts/tistory_publisher.py --title ... --file ...` 호출하거나 `terminal` + 격리 bash 패턴 (§3.34.40 4단계 패턴 4번 항목 그대로). **§3.34 #21 AI/ML FRESH=0 케이스 실전 2호 (266차 검증)**: FRESH 후보 AI/ML=0 + 개발도구/개발팁/투자/경제 등 다른 카테고리 다수 → **점수 1순위 비-기타 카테고리 픽** (266차 31432 11점 개발도구). §3.34.45 매트릭스 5번째 분기 ("FRESH 모두 'AI/ML 외 비-기타' → 점수 1순위 픽") 실전 검증. 차감/추가 없음. 모든 기존 패턴 정상 동작. 상세: `references/session-20260714-266th-papermake-typst-pdf.md`.
> **2026-07-14 (265차)**: **green-run confirmation + §3.34.47 영구화 두 번째 실전 검증** — **`#1002 Grok Build가 사용자 디렉터리 통째로 xAI 서버에 업로드 — AI 에이전트 샌드박스의 현실적 교훈`** (AI/ML/1219746, gn=31424, 6점, FRESH 1순위) 정상 발행 — §3.8.1 가드 통과 (`status=200, ct=application/json;charset=UTF-8, cookie_count=8`), §3.34.43 PWD 보강 (`PWD=/Users/mac`), §3.34.40 FRESH 4-field (TOP 12개 중 4개 262~264차 PUB 처리: 31404/31435/31411/31406 → FRESH 잔여 8개; §3.34 #21 AI/ML 우선 정책으로 AI/ML FRESH 점수 1순위 `31424` 픽), §3.34.46 영구화 (`_try_md_endpoint(31424)` 직접 호출 → status=200, **3643 bytes** 1단계 `.md` endpoint 즉시 fetch), §3.34.47 영구화 두 번째 실전 검증 (`write_file` 로 `/tmp/tistory_drafts_265th/build_draft.py` UTF-8 선언 + 저장 → `python3 <script>.py` 격리 호출 정상, inline heredoc 회피 — 264차 `#1000` 빌드와 동일 패턴 반복 적용 OK 확인), §3.5 5중 신호 5/5 `#1002` 일치 (`triple_signal_match: true / all_match: True`), post_publish_sync `pt_updated: true / state_updated: true / errors: []`, daily_counts[2026-07-14] = `{'AI/ML': 10}` (9→10, +1 정확, cat_id 누설 0), state.details 77→78, pt.details 93→94 모두 박힘, cleanup cron 임무 #16 dry-run `✅ 누설 없음` (51→**52회** 연속 all-green), 이미지 2장 CDN 업로드 정상 (query: home directory upload privacy sandbox ai agent, Picsum ID 935/565), 본문 검증 2843자 (300자 가드 통과), 라이브 페이지 직접 GET `status=200, size=65205, title tag='Grok Build가 사용자 디렉터리 통째로 xAI 서버에 업로드 &mdash; ...'` (실제 발행 확인). **연속 all-green 52회차 (213~265차)**. 가짜 발행 가드 정상. §3.34.46 + §3.34.47 영구화 모두 두 번째 실전 검증 완료. 본 세션 신규 발견 없음 — 모든 기존 패턴 정상 동작 (264차 → 265차 동일 워크플로 그대로 적용 가능 확인). 차감/추가 없음. 상세: `references/session-20260714-265th-grok-build-upload.md`.
> **2026-07-14 (264차)**: **green-run confirmation + #1000 마일스톤 + §3.34.47 영구화 실전 검증** — **`#1000 Brain-AI Memory — 장기 실행 LLM 에이전트의 메모리 실패를 retrieval이 아닌 component lifecycle으로 진단하는 오픈 아키텍처`** (AI/ML/1219746, gn=31435, 13점, FRESH 1순위) 정상 발행 — §3.8.1 가드 통과 (`status=200, ct=application/json;charset=UTF-8, cookie_count=8`), §3.34.43 PWD 보강 (`PWD=/Users/mac`), §3.34.40 FRESH 4-field (TOP 12개 중 3개 259~263차 PUB 처리: 31404/31397/31411 → FRESH 잔여 9개 모두 AI/ML; §3.34 #21 AI/ML 우선 정책 + §3.34.39 후보 직접 점수 pick으로 13점 `31435` 픽, §3.34.45 '기타' 제외 정책은 FRESH에 '기타' 0개로 무효), §3.34.46 영구화 (`fetch_gn_content(31435)` → status=200, 1907 bytes 1단계 `.md` endpoint 즉시 fetch), §3.34.47 영구화 실전 검증 (`write_file` 로 `/tmp/tistory_drafts_264th/build_draft.py` UTF-8 선언 + 저장 → `python3 <script>.py` 격리 호출 정상, inline heredoc 회피), §3.5 5중 신호 5/5 `#1000` 일치 (`triple_signal_match: true / all_match: True`), post_publish_sync `pt_updated: true / state_updated: true / errors: []`, daily_counts[2026-07-14] = `{'AI/ML': 8}` (7→8, +1 정확, cat_id 누설 0), state.details 76→77, pt.details 92→93 모두 박힘, cleanup cron 임무 #16 dry-run `✅ 누설 없음` (49→**50회** 연속 all-green), 이미지 2장 CDN 업로드 정상 (query: ai agent memory brain architecture diagram neural, Picsum ID 809), 본문 3573자 (300자 가드 통과), 라이브 페이지 직접 GET `status=200, size=61832, title tag='Brain-AI Memory &mdash; ...'` (실제 발행 확인). **`#1000` 1000번째 글 마일스톤 + 연속 all-green 51회차 (213~264차)**. 가짜 발행 가드 정상. §3.34.46 + §3.34.47 영구화 모두 실전 검증 완료. 본 세션 신규 발견 없음 — 모든 기존 패턴 정상 동작. 차감/추가 없음. 상세: `references/session-20260714-264th-brain-ai-memory-1000th.md`.
> **2026-07-14 (263차)**: **green-run confirmation + §3.34.47 신규 함정 식별 (UTF-8 한글 heredoc + f-string 제약)** — **`#999 2026년에 왜 코드를 작성하는가 — AI 에이전트 시대에도 코드를 만져야 하는 5가지 이유`** (AI/ML/1219746, gn=31411, 9점, FRESH 1순위 — AI/ML 후보 중 점수 최고) 정상 발행 — §3.8.1 가드 통과 (`status=200, ct=application/json;charset=UTF-8, cookie_count=8`), §3.34.43 PWD 보강 (`PWD=/Users/mac`), §3.34.40 FRESH 4-field (TOP 12개 중 2개 261~262차 PUB 처리: 31404/31397 → FRESH 잔여 10개 식별: 개발도구 3 + AI/ML 4 + 개발팁 1 + 투자/경제 1 + 개발도구 1; §3.34 #21 AI/ML 우선 정책으로 AI/ML FRESH 4개 중 점수 1순위 `31411` 픽), §3.34.46 영구화 (`fetch_gn_content(31411)` → status=200, **10273 bytes** 1단계 `.md` endpoint 즉시 fetch), §3.5 5중 신호 5/5 `#999` 일치 (`triple_signal_match: true`), post_publish_sync `pt_updated: true / state_updated: true / errors: []`, daily_counts[2026-07-14] = `{'AI/ML': 7}` (6→7, +1 정확, cat_id 누설 0), state.details 75→76, pt.details 91→92 모두 박힘, cleanup cron 임무 #16 dry-run `✅ 누설 없음` (48→**49회** 연속 all-green), 이미지 2장 CDN 업로드 정상 (query: software engineer code editor terminal abstract factory, Picsum ID 782), 본문 검증 3311자 (300자 가드 통과), 라이브 페이지 직접 GET `status=200, size=57991, title tag='2026년에 왜 코드를 작성하는가 &mdash; ...'` (실제 발행 확인). **연속 all-green 50회차 (213~263차)**. 가짜 발행 가드 정상. **§3.34.47 (NEW, 263차 식별)**: `/usr/bin/python3` heredoc 안에서 `f"... {var.split(\" \",1)[1]} ..."` 처럼 §3.34.41 f-string 제약 + escaped quote 가 동시에 들어가고 본문 문자열이 한글 UTF-8이면 `SyntaxError: f-string expression part cannot include a backslash` 가 아니라 **`SyntaxError: Non-UTF-8 code starting with '\xec'`** 가 먼저 터짐 — bash heredoc body 인코딩과 Python source encoding 선언이 충돌. 263차 첫 시도에서 hit (`# -*- coding: utf-8 -*-` 미선언 inline heredoc + 한글 HTML 본문). **회피**: 길이가 30줄이 넘어가는 본문 빌드/HTML 변환 스크립트는 inline heredoc에 적지 말고 `write_file` 로 `/tmp/<session>/build_draft.py` 에 UTF-8 선언과 함께 저장 → `python3 <script>.py` 로 격리 호출. **적용 범위**: §3.34.46 본문 빌드 / 다중 카테고리 한도 처리 / 인트로+본문+결론 합치기 등 heredoc 본문이 길어지는 모든 변형. 단일 probe (가드 / sync / state 확인) 처럼 5~10줄짜리 short heredoc은 §3.34.41 정정 (string concat) 으로 충분. 차감/추가 없음. 모든 기존 패턴 정상 동작. 상세: `references/session-20260714-263rd-coding-still-worth-writing.md`.
>
> **2026-07-14 (262차)**: **green-run confirmation + §3.34.46 HTML 변환 들여쓰기/위장-헤더 함정 보완 (262차 식별)** — **`#998 프로덕션 AI 에이전트를 GPT-5.6으로 전환해 2.2배 빠르고 27% 저렴해진 과정 — 모델이 아니라 인프라 가정을 갈아끼워야 하는 이유`** (AI/ML/1219746, gn=31404, 16점, FRESH 1순위) 정상 발행 — §3.8.1 가드 통과 (`status=200, ct=application/json;charset=UTF-8, cookie_count=8`), §3.34.43 PWD 보강 (`PWD=/Users/mac`), §3.34.40 FRESH 4-field (TOP 12개 중 10개 이미 254~261차 PUB 처리 → FRESH 잔여 2개 모두 AI/ML: 31404/31367; §3.34.39 후보 직접 점수 pick으로 16점 `31404` 픽, #21 AI/ML 우선 정책 정상 동작), §3.34.46 영구화 (`_try_md_endpoint(31404)` 직접 호출 → status=200, **13506 bytes** 1단계 `.md` endpoint 즉시 fetch), §3.5 5중 신호 5/5 `#998` 일치 (`triple_signal_match: true`), post_publish_sync `pt_updated: true / state_updated: true / errors: []`, daily_counts[2026-07-14] = `{'AI/ML': 6}` (5→6, +1 정확, cat_id 누설 0), state.details 73→74, pt.details 89→90 모두 박힘, cleanup cron 임무 #16 dry-run `✅ 누설 없음` (47→**48회** 연속 all-green), 이미지 2장 CDN 업로드 정상 (query: ai agent gpt model migration cloud infrastructure code editor, Picsum ID 263), 본문 7341자 (검증 7151자, 300자 가드 통과), 라이브 페이지 직접 GET `status=200, size=66940, title tag='프로덕션 AI 에이전트를 GPT-5.6으로 전환해 2.2배 빠르고 27% 저렴해진 과정 &mdash; ...'` (실제 발행 확인). **연속 all-green 49회차 (213~262차)**. 가짜 발행 가드 정상. **§3.34.46 HTML 변환 들여쓰기/위장-헤더 함정 (NEW, 262차 식별, 즉시 보완)**: 260차 정착 "4가지 패턴만 다루면 됨" 가이드가 **들여쓬 sub-list + `- ## 헤더` 위장 항목** 두 케이스에서 깨짐을 262차 첫 시도에서 hit. (a) **들여쓰기 nested ul 함정** — GeekNews 본문에 `  - hero 영역이 화면 전체 폭을 채우는 사진 장면인지 검사함` 같은 indented sub-list 가 흔함. 2-space indent = 1 level 로 nested `<ul><ul><li>` 변환하려 했더니 md가 pseudo-nested (모든 `- ` 이 동등 top-level) 일 때 매 항목마다 `<ul>` 가 열리고 즉시 닫혀 시각적 리스트 미형성 → **회피**: indent 무시하고 모든 `- ` 를 top-level bullet로 취급, 연속된 `- ` 라인을 하나의 `<ul>...</ul>` 로 묶고 빈 줄에서만 close. (b) **`- ## 헤더` 위장 항목** — `- ## 기존 모델의 호출 방식에 맞춰진 제약` 같은 list-prefixed header 가 `<li>` 로 변환되면 의미 파괴 → **회피**: `- ` 변환 직전 item_text가 `## `/`### ` 로 시작하면 `<h2>`/`<h3>` 로 라우팅. 262차에 두 함정 모두 회피한 개선된 `md_to_html` 정착 (위 §3.34.46 박스의 정정 코드블록). 모든 기존 패턴 정상 동작. 차감/추가 없음. 상세: `references/session-20260714-262nd-gpt56-migration.md`.
>
> **2026-07-14 (261차)**: **green-run confirmation + §3.34.46 영구화 패치 (#23) 완료** — **`#996 LLM은 사랑하지만 과대광고는 싫다 — geohot이 본 AI 가치 포획의 진짜 승자`** (AI/ML/1219746, gn=31378, 7점, FRESH 1순위) 정상 발행 — §3.8.1 가드 통과 (`status=200, ct=application/json;charset=UTF-8, cookie_count=8`), §3.34.43 PWD 보강, §3.34.40 FRESH 4-field (TOP 12개 중 8개 254~260차 PUB 처리 → FRESH 잔여 4개 모두 AI/ML: 31378/31375/31367/31389; §3.34.39 후보 직접 점수 pick으로 31378 1순위, #21 AI/ML 우선 정책 정상 동작), §3.34.46 영구화 (`GN_MD_URL = GN_TOPIC_BASE + "/{tid}.md"` + `GN_TOPIC_BASE` 정의 순서 정정 + `_try_md_endpoint` docstring 갱신 → `_try_md_endpoint(31378)` 테스트 정상 fetch 9590 bytes, 1단계 `.md` endpoint 즉시 성공), §3.5 5중 신호 5/5 `#996` 일치 (`triple_signal_match: true`), post_publish_sync `pt_updated: true / state_updated: true / errors: []`, daily_counts[2026-07-14] = `{'AI/ML': 4}` (3→4, +1 정확, cat_id 누설 0), state.details 72→73, pt.details 88→89 모두 박힘, cleanup cron 임무 #16 dry-run `✅ 누설 없음` (46→47회 연속 all-green), cleanup cron 임무 #23 영구화 완료 (✅ 패치 적용 + 1단계 `.md` endpoint 즉시 fetch 검증), 이미지 2장 CDN 업로드 정상 (query: llm coding ai hype bubble skeptic, Picsum 자동 매칭 ID 365/68), 본문 7069자 (300자 가드 통과, 검증 통과 2429자), 라이브 페이지 직접 GET `status=200, size=65252, title tag='LLM은 사랑하지만 과대광고는 싫다 &mdash; ...'` (실제 발행 확인). **연속 all-green 48회차 (213~261차)**. 가짜 발행 가드 정상. **사소한 관찰**: state.details[-1] 가 `#995 GPT-5.6-Sol` (gn=31390, 자정 사이 외부 발행 흔적) 인 상태에서 cron 261차 시작 → §3.5 5중 검증으로 drift 무해 확인 후 정상 진행. daily_counts[2026-07-14]['AI/ML'] = 3 (260차 SKILL.md엔 2였으나 사후 1건 추가 발행됨). 모든 기존 패턴 정상 동작. 차감/추가 없음. 상세: `references/session-20260714-261st-llm-hype.md`.
>
> **2026-07-14 (260차)**: **green-run confirmation + §3.34.46 임시 우회 실전 검증 + 본문 변환 패턴 정착** — **`#994 AI 에이전트가 새로운 SaaS다 — "제품이 곧 업무"로 가는 a16z의 프레임`** (AI/ML/1219746, gn=31376) 정상 발행 — §3.8.1 가드 통과 (`status=200, ct=application/json;charset=UTF-8, cookie_count=8`), §3.34.43 PWD 보강 (`PWD=/Users/mac`), §3.34.40 FRESH 4-field (TOP 12개 중 6개 254~259차 PUB 처리 → FRESH 잔여 6개: 31376/31390/31378/31375/31367/31389 모두 AI/ML; §3.34.39 후보 직접 점수 pick으로 31376 1순위), §3.34.46 임시 우회 (`requests.get("https://news.hada.io/topic/31376.md")` 직접 호출, status=200, 8952 bytes, 본문 8300자) 정상 fetch, §3.5 5중 신호 5/5 `#994` 일치 (사전 `#993` → 사후 `#994` 모두 검증, `triple_signal_match: true`), post_publish_sync `pt_updated: true / state_updated: true / errors: []`, daily_counts[2026-07-14] = `{'AI/ML': 2}` (1→2, +1 정확, cat_id 누설 0), state.details 70→71, pt.details 86→87 모두 박힘, cleanup cron 임무 #16 dry-run `✅ 누설 없음` (45→46회 연속 all-green), 이미지 2장 CDN 업로드 정상 (query: ai agent saas call center restaurant workflow, Picsum 자동 매칭 ID 764/776), 본문 11411자 (300자 가드 통과), 라이브 페이지 직접 GET `status=200, size=71020, title tag='AI 에이전트가 새로운 SaaS다 &mdash; ...'` (실제 발행 확인). **연속 all-green 47회차 (213~260차)**. 가짜 발행 가드 정상. **§3.34.46 임시 우회 실전 검증 (260차 재확인)**: `scripts/gn-fetch-content.py`의 `GN_MD_URL = "https://news.hada.io/topic.md?id={tid}"` 가 여전히 stale 이지만, 260차에 `requests.get("https://news.hada.io/topic/{tid}.md")` 직접 호출 패턴으로 정상 본문 fetch 확인 (status=200, 8952 bytes; 259차엔 1251 bytes 였는데 31376은 본문이 더 길어서 8배). **영구화 패치 (#23 cleanup cron 임무)는 미적용 상태 유지** — 다음 차에 `GN_MD_URL = f"{GN_TOPIC_BASE}/{tid}.md"` 1줄 정정 시 본문 fetch가 1단계 `.md`에서 즉시 성공. **본문 변환 패턴 정착 (260차 NEW)**: GeekNews 마크다운을 Tistory HTML로 변환할 때 `## 헤더` / `### 헤더` / `- 리스트` / `**bold**` 4가지 패턴만 다루면 됨. 변환 알고리즘: 헤더는 `<h2>`/`<h3>`, `- ` 시작은 `<ul><li>` with `</ul>` close, 빈 줄은 리스트 close 트리거, `**bold**`는 `<strong>`. 본문 끝에 editorial 인트로 (Tistory 독자층 맞춤 한국어 1~2 단락) + 결론 ("한국 시장에서의 시사점" 1~2 단락 + 원문 링크) 추가하면 300자 가드 통과 + 발행 가독성 확보. 260차 11411자 (intro 540 + 본문 8300 + 결론 1700 + 마지막 단락). 차감/추가 없음. 모든 기존 패턴 정상 동작. 상세: `references/session-20260714-260th-ai-agent-saas.md`.
>
> **2026-07-14 (259차)**: **green-run confirmation + §3.34.46 gn-fetch-content URL stale** — **`#993 만든 SaaS를 AI에게 말만 하면 등록되는 MCP 서버 — saaskr.com이 등록 폼을 MCP로 열었다`** (AI/ML/1219746, gn=31397, 10점, FRESH 1순위) 정상 발행 — §3.8.1 가드 통과 (`status=200, ct=application/json;charset=UTF-8, cookie_count=8`), §3.34.43 PWD 보강 (`PWD=/Users/mac`), §3.34.40 FRESH 4-field (TOP 12개 후보 5개 PUB 처리: 31370/31373/31387/31381/31374 → FRESH 잔여 7개 모두 AI/ML: 31397/31376/31390/31378/31375/31367/31389), §3.5 5중 신호 5/5 `#993` 일치 (사전 `#992` → 사후 `#993` 모두 검증, `triple_signal_match: true`), post_publish_sync `pt_updated: true / state_updated: true / errors: []`, daily_counts[2026-07-14] = `{'AI/ML': 1}` ({}→{AI/ML:1}, +1 정확, cat_id 누설 0), state.details 69→70, pt.details 85→86 모두 박힘, cleanup cron 임무 #16 dry-run `✅ 누설 없음` (44→45회 연속 all-green), 이미지 2장 CDN 업로드 정상 (query: ai assistant chat message registration form submission, Picsum 자동 매칭 ID 62), 본문 1165자 (300자 가드 통과), 라이브 페이지 직접 GET `status=200, size=53699` (실제 발행 확인). **연속 all-green 45회차 (213~259차)**. 가짜 발행 가드 정상. **§3.34.46 (NEW, 259차 식별)**: **`scripts/gn-fetch-content.py` 의 `GN_MD_URL = "https://news.hada.io/topic.md?id={tid}"` 상수가 stale** — 스크립트 docstring은 "227~232차 6회째 100% 404, 사실상 dead path" 라고 박혀있으나, **실제 작동하는 URL은 `/topic/{tid}.md`** (예: `https://news.hada.io/topic/31397.md`). 259차에 직접 호출 → `status=200, 1251 bytes` 정상 응답 + 깨끗한 markdown (frontmatter + metadata + 본문 + 댓글). **영구화 권장** (#23 cleanup cron 임무): `GN_MD_URL` 을 `/topic/{tid}.md` 로 정정하면 1단계 `.md` fallback 이 가장 신뢰성 있는 fetch 경로로 부활 — HTML 파싱 fallback의 비표준 마크업 함정과 RSS summary fallback의 짧은 길이 함정을 모두 우회. 259차는 임시 우회 (`/tmp/fetch_31397_md.py` 직접 작성) 로 본문 확보했으나, 다음 차에 정식 패치 권장. 차감/추가 없음. 모든 기존 패턴 정상 동작. 상세: `references/session-20260714-259th-saaskr-mcp.md`.
>
> **2026-07-13 (258차)**: **green-run confirmation + #22 정책 무효 케이스** — **`#989 Claude Code는 프롬프트 전에 3.3만 토큰, OpenCode는 7천 토큰 — API 경계에서 발견한 코딩 에이전트 토큰 비용의 진짜 차이`** (AI/ML/1219746, gn=31373, 15점) 정상 발행 — §3.8.1 가드 통과 (`status=200, ct=application/json;charset=UTF-8, cookie_count=8`), §3.34.43 PWD 보강 (`PWD=/Users/mac`), §3.34.40 FRESH 4-field (TOP 12개 모두 AI/ML 카테고리, 31370/31351 PUB 처리 → FRESH 잔여 10개 모두 AI/ML), §3.5 5중 신호 5/5 `#989` 일치 (사전 `#988` → 사후 `#989` 모두 검증, `triple_signal_match: true`), post_publish_sync `pt_updated: true / state_updated: true / errors: []`, daily_counts[2026-07-13] = `{'개발팁': 1, '개발도구': 2, 'AI/ML': 5}` (4→5, +1 정확, cat_id 누설 0), state.details 65→66, pt.details 81→82 모두 박힘, cleanup cron 임무 #16 dry-run `✅ 누설 없음` (43→44회 연속 all-green), 이미지 2장 CDN 업로드 정상 (query: code editor terminal token meter api overhead measurement, Picsum 자동 매칭 ID 504), 본문 792자 (300자 가드 통과), 라이브 페이지 직접 GET `status=200, size=59015` (실제 발행 확인). **연속 all-green 44회차 (213~258차)**. 가짜 발행 가드 정상. **#22 정책 무효 케이스 (NEW, 258차 검증)**: 256차에서 식별한 #22 정책 ("'기타' 제외 > #21 AI/ML 우선")이 **FRESH 후보 모두 AI/ML**인 케이스에는 적용 불필요 — #21 단독 적용으로 충분. 즉 #22는 **FRESH 후보에 '기타'가 1개 이상 포함될 때만** 동작하는 가드. 258차는 FRESH 10개 모두 AI/ML → #22 무효, #21 정상 동작. 정책 우선순위 매트릭스 (§3.34.45) 그대로 유효. **사소한 호출 함정 (NEW, 258차 1회성)**: `strip-frontmatter.py`는 `<input> <output>` positional 2-arg 필수 — 단일 인자로 호출시 Usage 에러. 회피: 항상 두 개 인자 명시. 영구화 불필요 (1회성 호출 오타, 즉시 재호출로 해결). 본 세션 신규 패턴 발견 없음 — 모든 기존 playbook 정상 동작. 차감/추가 없음.
>
> **2026-07-13 (257차)**: **green-run confirmation** — **`#988 AgentsView — 여러 AI 코딩 에이전트의 세션 검색·분석·비용 추적 도구`** (AI/ML/1219746, gn=31370, 26점, FRESH 1순위) 정상 발행 — §3.8.1 가드 통과 (`status=200, ct=application/json;charset=UTF-8, cookie_count=8`), §3.34.43 PWD 보강 (`PWD=/Users/mac`), §3.34.40 FRESH 4-field (TOP 12개 모두 AI/ML 후보, 31351만 251차에 PUB 처리 → FRESH 잔여 11개; **AI/ML 후보 다수 FRESH → §3. — 발행 0건 정상 종료 (FRESH 후보 2개 모두 '기타' 카테고리). §3.8.1 가드 통과 (`status=200, ct=application/json, cookie_count=8`), §3.34.40 FRESH 4-field (TOP 12개 중 10개 이미 250~255차 PUB 처리 → FRESH 잔여 2개: 기타 `31338` (1.0점, Android 앱→웹페이지) + 기타 `31359` (0.5점, 세그멘테이션 오류); AI/ML FRESH 0개), §3.5 5중 신호 5/5 `#987` 일치 유지 (drift 무해, 사후 변동 0), `cleanup_daily_cat_id_leak.py` dry-run `✅ 누설 없음` (40→41회 연속 all-green), state.details 64, pt.details 80 변동 없음, daily_counts[2026-07-13] 변동 없음 (`{개발팁:1, 개발도구:2, AI/ML:3}`). **§3.34 #21 경계 조건 확정 (NEW, 256차)**: #21 가이드 "AI/ML FRESH=0 이면 다른 카테고리 발행 허용"이 **'기타' 카테고리에는 적용되지 않음** — `blog_pipeline.py` §1448~1456 (2026-06-08 영구화 정책) **"기타" 카테고리는 발행 대상에서 의도적으로 제외**. **정책 우선순위 확정**: `'기타' 제외 > #21 AI/ML 우선`. 즉 FRESH 후보가 모두 '기타'이면 → skip (이번 차가 실전 1호). FRESH 후보가 '기타' + 'AI/ML' 혼재이면 → AI/ML 픽 (#21 가이드 그대로). FRESH 후보가 '기타' + 'AI/ML 외 다른 카테고리' 혼재이면 → #21 가이드 + '기타' 제외 = 다른 카테고리 발행 허용. 본 세션 신규 코드 변경 없음 — **#22 cleanup cron 임무로 정책 우선순위 박기**. 차감/추가 없음. 모든 기존 패턴(§3.8.1 / §3.8.2 / §3.5 / §3.11 / §3.34.39~44 / #21) 정상 동작.
> **2026-07-13 (255차)**: **green-run confirmation + AI/ML 우선 가이드 (#21) 실전 적용 1호** — **`#987 하드 테크오프 신화에 대한 한 가지 회의 — geohot의 「AI 2040과 지능 숭배」`** (AI/ML/1219746, gn=31360, 3점) 정상 발행 — §3.8.1 가드 통과 (`status=200, ct=application/json, cookie_count=8`), §3.34.43 PWD 보강 (`PWD=/Users/mac`), §3.34.40 FRESH 4-field (TOP 9개 AI/ML+개발도구+개발팁 후보 31340/31351/31349/31342/31350/31343/31355/31352/31348 모두 250~254차 PUB 처리 → FRESH 잔여 3개: AI/ML `31360` + 기타 `31338`/`31359`; **AI/ML FRESH 1개 발견 → §3.34 #21 AI/ML 우선 정책**으로 `31360` 픽), §3.5 5중 신호 5/5 `#987` 일치 (사전 `#986` → 사후 `#987` 모두 검증, `triple_signal_match: true`), post_publish_sync `pt_updated: true / state_updated: true / errors: []`, daily_counts[2026-07-13] = `{'개발팁': 1, '개발도구': 2, 'AI/ML': 3}` (AI/ML 2→3, +1 정확, cat_id 누설 0), state.details 63→64, pt.details 79→80 모두 박힘, pt.last.{title, gn_topic_id=31360, source_url} 3필드 정상, cleanup cron 임무 #16 dry-run `✅ 누설 없음`, 이미지 2장 CDN 업로드 정상 (query: underwater data center submarine cables intelligence, Picsum 자동 매칭), 본문 2732자 (300자 가드 통과), 라이브 페이지 직접 GET `status=200, size=63485` (실제 발행 확인). **연속 all-green 40회차 (213~255차)**. 가짜 발행 가드 정상. §3.34.39~44 (240~254차 발견) + §3.8.2 격리 패턴 (244차 정정) + §3.34.41 3.9-safe string concat (245차) + §3.34.43 PWD 보강 (247차) + §3.34.44 cron 차 사이 last URL drift (254차 확정) + **§3.34 #21 AI/ML 우선 정책 (254차 식별 → 255차 실전 1호)** 모두 통과. **#21 실전 검증 (NEW, 255차)**: 254차 본문이 "FRESH 1순위가 개발도구였으나 그대로 진행"이었음. 255차에는 FRESH 후보가 AI/ML 1 + 기타 2 — **#21 정책 그대로 AI/ML 픽이 정답**으로 입증. 차후 AI/ML 후보가 0인 사이클에서도 #21 정책 자체가 가드 깨지 않음 (FRESH 4-field 매칭은 점수 무관, 카테고리 무관 — 카테고리 혼재 위험 없음). **§3.34.44 drift 패턴 두 번째 관찰 (255차)**: 사전 검증에서 `state.last_published_url` 이 `#986` 으로 박혀있음 (254차 차 종료값, 자정 사이 추가 발행 없음 — 같은 날 같은 차). 5중 검증 모두 일치 유지. 254차 관찰의 "자정 사이 외부 발행" 케이스와 다른 케이스 (한 차 내 외부 발행이 없는 정상 케이스) — 두 패턴 모두 drift-immune. 본 세션 신규 발견 없음 — 모든 패턴 정착. 차감/추가 없음. 상세: `references/session-20260713-255th-ai-2040.md`.
> **2026-07-13 (254차)**: **green-run confirmation + §3.34.44 실전 검증 확정** — **`#986 마담 Semver가 펼쳐본 오픈소스 maintainer의 1년 — 아카이브하지 않은 저장소의 미래`** (개발도구/1219748, gn=31355, 4점) 정상 발행 — §3.8.1 가드 통과 (`status=200, ct=application/json, cookie_count=8`), §3.34.43 PWD 보강 (`PWD=/Users/mac`), §3.34.40 FRESH 4-field (TOP 8개 AI/ML+개발도구+개발팁 후보 31340/31351/31349/31342/31350/31343/31352/31348 모두 250~253차 PUB 처리 → FRESH 잔여 4개: 개발도구 31355 + 기타 31338/31358/31357, AI/ML 카테고리 후보 0개), §3.5 5중 신호 5/5 `#986` 일치 (사전 `#985` → 사후 `#986` 모두 검증, `triple_signal_match: true`), post_publish_sync `pt_updated: true / state_updated: true / errors: []`, daily_counts[2026-07-13] = `{'개발팁': 1, '개발도구': 2, 'AI/ML': 2}` (개발도구 1→2, +1 정확, cat_id 누설 0), state.details 62→63, pt.details 78→79 모두 박힘, pt.last.{title, gn_topic_id=31355, source_url} 3필드 정상, cleanup cron 임무 #16 dry-run `✅ 누설 없음`, 이미지 2장 CDN 업로드 정상 (query: tarot cards developer repository maintenance vintage, Picsum 자동 매칭), 본문 3146자 (300자 가드 통과), 라이브 페이지 직접 GET `status=200, len=66530` (실제 발행 확인). **연속 all-green 39회차 (213~254차)**. 가짜 발행 가드 정상. §3.34.39~43 (240~247차 발견) + §3.8.2 격리 패턴 (244차 정정) + §3.34.41 3.9-safe string concat (245차) + §3.34.43 PWD 보강 (247차) + §3.34.44 cron 차 사이 last URL drift (253차 식별 → 254차 실전 검증 완료) 모두 통과. **§3.34.44 실전 검증 (NEW, 254차)**: 사전 검증에서 `state.last_published_url` 이 `#985`로 박혀있음 — 직전 cron 차(자정 사이) 외부에서 추가 발행된 흔적. 5중 신호 모두 일치 유지되어 drift 무해 확정. **신규 가드 룰 — "AI/ML 우선 + 카테고리 균형"**: 254차 FRESH 1순위가 개발도구였으나 §3.34.39 후보 직접 점수 pick 패턴에 따라 그대로 진행 (4점 후보 정상 발행). 추후 AI/ML TOP 후보가 0이 되는 사이클에서는 다른 카테고리 발행 허용 — **단 AI/ML 후보가 1개 이상 FRESH이면 무조건 AI/ML 우선** (가짜 발행 가드는 FRESH 4-field 매칭이므로 카테고리 혼재 위험 없음). 본 세션 신규 발견 없음 — 모든 패턴 정착. 차감/추가 없음. 상세: `references/session-20260713-254th-madame-semver.md`.
> **2026-07-13 (253차)**: **green-run confirmation** — **`#982 Ant, 경량 JavaScript 런타임과 생태계 — 8.6MB 단일 바이너리로 V8/JSC 우회하는 새로운 접근`** (개발팁/1219747, gn=31348, 4점) 정상 발행 — §3.8.1 가드 통과 (`status=200, ct=application/json, cookie_count=8`), §3.34.43 PWD 보강 (`PWD=/Users/mac`), §3.34.40 FRESH 4-field (TOP 7 AI/ML 후보 31340/31351/31349/31342/31350 모두 250~252차 PUB 처리 + 후속 차 pt.details 축적 → FRESH 잔여: 개발팁 `31348` + AI/ML `31343`; 1순위 픽 = 31348 단, AI/ML TOP FRESH는 31343 하나뿐), §3.5 5중 신호 5/5 `#982` 일치 (사전 `#981` → 사후 `#982` 모두 검증, `triple_signal_match: true`), post_publish_sync `pt_updated: true / state_updated: true / errors: []`, daily_counts[2026-07-13] = `{'개발팁': 1}` (+1 정확, cat_id 누설 0), state.details 58→59, pt.details 74→75 모두 박힘, pt.last.{title, gn_topic_id=31348, source_url} 3필드 정상, cleanup cron 임무 #16 dry-run `✅ 누설 없음`, 이미지 2장 CDN 업로드 정상 (query: javascript runtime code terminal, Picsum 자동 매칭), 본문 2736자 (300자 가드 통과). **연속 all-green 38회차 (213~253차)**. 가짜 발행 가드 정상. §3.34.39~43 (240~247차 발견) + §3.8.2 격리 패턴 (244차 정정) + §3.34.41 3.9-safe string concat (245차) + §3.34.43 PWD 보강 (247차) 모두 통과. **사소한 관찰 (§3.34.44 후보, 253차 식별)**: 사전 검증에서 `state.last_published_url` 이 이미 `#981` 로 박혀있음 (전날 자정 무렵 추가 발행된 흔적) → 즉 **새벽 사이 이미 1건 발행이 일어났음**. 5중 검증 모두 일치 유지되어 drift 무해. 다만 cron 자동화 관점에서 "이전 cron 차의 마지막 URL과 새 cron 호출 직전 URL이 다를 수 있다"는 점을 명시 — pt/details 비교시 항상 **현재 시점의 last url** 을 source-of-truth로 사용. 본 세션 신규 발견 없음 — 모든 패턴이 정착된 playbook 그대로 정상 동작. 차감/추가 없음.
> **2026-07-12 (252차)**: **green-run confirmation** — **`#980 에어팟 노이즈캔슬링 중 이름 들리면 자동으로 주변음 허용 — EarsUp 살펴보기`** (5점, 31350) 정상 발행 — §3.8.1 가드 통과 (`status=200, ct=application/json;charset=UTF-8, cookie_count=8`), §3.34.43 PWD 보강 (`PWD=/Users/mac`), §3.34.40 FRESH 4-field (251차에 TOP 6개 모두 PUB 처리: 31340/31349/31342/31334/31329/31327/31326 → FRESH 5개 식별 31350/31348/31343/31338/31336, 후순위 FRESH `31350` 1순위 픽), §3.5 5중 신호 5/5 `#980` 일치 (사전 `#979` → 사후 `#980` 모두 검증), post_publish_sync `triple_signal_match: true`, daily_counts[2026-07-12] = `{'개발도구': 1, 'AI/ML': 11}` (10→11, +1 정확, cat_id 누설 0), state.details 76→77, pt.details +1 모두 박힘, cleanup cron 임무 #16 dry-run 누설 없음. 이미지 2장 CDN 업로드 정상 (query: AirPods macOS menu bar app name detection transparency, Picsum 자동 매칭 첫 시도 적중). **연속 all-green 37회차 (213~252차)**. 가짜 발행 가드 정상. §3.34.39~43 (240~247차 발견) + §3.8.2 격리 패턴 (244차 정정) + §3.34.41 3.9-safe string concat (245차) + §3.34.43 PWD 보강 (247차) 모두 통과. 본 세션 신규 발견 없음 — 모든 패턴이 정착된 playbook 그대로 정상 동작. 차감/추가 없음.
> **2026-07-12 (251차)**: **green-run confirmation** — **`#978 NVIDIA·CoreWeave·Nebius가 만든 GPU 붐의 순환 금융 구조`** (10점, 31349) 정상 발행 — §3.8.1 가드 통과 (`status=200, ct=application/json; cookie_count=8`), §3.34.43 PWD 보강 (`PWD=/Users/mac`), §3.34.40 FRESH 4-field (TOP 1 = 31340 Boko Haram이 250차 처리, 후순위 FRESH `31349` 1순위 픽, FRESH 6개 식별: 31349/31342/31350/31348/31343/31338), §3.5 5중 신호 5/5 `#978` 일치 (사전 `#977` → 사후 `#978` 모두 검증), post_publish_sync `triple_signal_match: true`, daily_counts[2026-07-12] = `{'개발도구': 1, 'AI/ML': 9}` (8→9, +1 정확, cat_id 누설 0), state.details 54→55, pt.details 70→71 모두 박힘, cleanup cron 임무 #16 dry-run 누설 없음. 이미지 2장 CDN 업로드 정상 (query: data center GPU server racks). **연속 all-green 36회차 (213~251차)**. 가짜 발행 가드 정상. §3.34.39~43 (240~247차 발견) + §3.11 sync (241차) + §3.34.41 (245차 수정본 가드 heredoc) 모두 통과. 본 세션 신규 발견 없음 — 모든 패턴이 정착된 playbook 그대로 정상 동작. 차감/추가 없음.
> **2026-07-12 (250차)**: **green-run confirmation** — **`#974 SpaceX, 대역폭 100배 위해 Starlink 위성 10만 기 추가 발사 추진`** (3점, 31334) 정상 발행 — §3.8.1 가드 통과 (3.9-safe string concat), §3.34.43 PWD 보강 (`PWD=/Users/mac`), §3.34.40 FRESH 4-field (TOP 1~4 = 31308/31318/31324/31307 + 31305/31323 모두 249차 이전 PUB 처리 → 후순위 FRESH `31334` 1순위 픽, FRESH 잔여 2개: 31320/31315), §3.5 5중 신호 5/5 `#974` 일치 (사전 `#973` → 사후 `#974` 모두 검증), post_publish_sync `triple_signal_match: true`, daily_counts[2026-07-12] = `{'개발도구': 1, 'AI/ML': 5}` (4→5, +1 정확, cat_id 누설 0), cleanup cron 임무 #16 dry-run 누설 없음. 이미지 2장 CDN 업로드 정상 (query: satellite constellation space orbital network). **연속 all-green 35회차 (213~250차)**. 가짜 발행 가드 정상. §3.34.39~43 (240~247차 발견) + §3.11 sync (241차) 모두 통과. 본 세션 신규 발견 없음 — 모든 패턴이 정착된 playbook 그대로 정상 동작. 차감/추가 없음.
> **2026-07-12 (249차)**: **green-run confirmation** — **`#970 AI 스크레이퍼 공격으로 유지가 어려워지는 개방형 웹`** (4점, 31323) 정상 발행 — §3.8.1 가드 통과 (3.9-safe string concat), §3.34.43 PWD 보강 (`PWD=/Users/mac`), §3.34.40 FRESH 4-field (TOP 1~4 = 31308/31318/31324/31307 + 31305 모두 248차 이전 PUB 처리 → 후순위 FRESH `31323` 1순위 픽, FRESH 잔여 6개: 31327/31326/31320/31315/31313/31309), §3.5 5중 신호 5/5 `#970` 일치, post_publish_sync `triple_signal_match: true`, daily_counts[2026-07-12] = `{'개발도구': 1, 'AI/ML': 1}` (+1 정확, cat_id 누설 0), cleanup cron 임무 #16 dry-run 누설 없음. 이미지 2장 CDN 업로드 정상 (query: network firewall security bot traffic). **연속 all-green 34회차 (213~249차)**. 가짜 발행 가드 정상. §3.34.39~43 (240~247차 발견) 모두 통과. 본 세션 신규 발견 없음 — 모든 패턴(§3.8.1 string concat / §3.8.2 격리 / §3.34.43 PWD / §3.34.41 f-string 회피 / §3.34.40 FRESH 4-field / §3.11 sync / §3.5 5중 / #16 dry-run)이 정착된 playbook 그대로 정상 동작. 차감/추가 없음.
> **2026-07-12 (248차)**: **green-run confirmation + 사소한 관찰 1건** — **`#969 개발자 GitHub → Codeberg`** (5점, 31305) 정상 발행 — §3.8.1 가드 통과, §3.34.39 FRESH 4-field (TOP 1~4 모두 PUB 처리: 31308 Apple Silicon, 31318 Apple 소송, 31324 Damn Interesting, 31307 사람 유지보수 — 후순위 FRESH 31305 1순위 픽), §3.5 5중 신호 5/5 `#969` 일치, post_publish_sync `triple_signal_match: true`, daily_counts[2026-07-12]['개발도구'] = 1 (+1 정확), cleanup cron 임무 #16 dry-run cat_id 누설 0. **연속 all-green 33회차 (213~248차)**. 가짜 발행 가드 정상. §3.34.39~43 (240~247차 발견) 모두 통과. **사소한 관찰**: 247차 본문이 daily_counts[2026-07-11]['AI/ML'] = 9 라고 적혀있으나 실제 state엔 11 (247차 시점에 #967 + #968 두 건의 stats 보정이 본문 기록엔 누락 — 실제 발행/sync 모두 성공, 차감/추가 없음, 후속 차 reference 정합성 자동 검증). 그 외 격리 패턴 PWD 이중 보강 (`PWD=/Users/mac` + `cd /Users/mac`), §3.34.41 string concatenation, §3.34.40 FRESH 4-field 매칭 모두 정상 동작 — 247차 영구화 검증 OK. 상세: `references/session-20260712-248th-codeberg-publish.md`.
> **2026-07-11 (247차)**: §3.34.43 (NEW) — **`env -i ... /bin/bash -c '...'` 호출 시 bash 스타트업 시 자동 `cd` 시도** → `bash: 행 2번: cd: /Users/mac/.hermes/repos/icbm2-knowledge-graph: No such file or directory` 로 exit 126. 247차 `post_publish_sync.py sync` 첫 호출에서 hit. 회피: bash 서브쉘 시작 시 `cd /Users/mac` 명시 또는 `PWD=/Users/mac` 환경변수 명시. 모든 격리 패턴 호출에서 적용 가능 — 영구화. 그 외 **`#966 htmldrop+MCP`** (8점, 31300) 정상 발행 — §3.8.1 가드 통과, §3.34.40 FRESH 4-field (TOP 1 = 31308 Apple Silicon이 PUB 처리 → 후순위 FRESH `31300` 픽), §3.5 5중 신호 5/5 `#966` 일치, post_publish_sync `triple_signal_match: true`, daily_counts[2026-07-11]['AI/ML'] = 9 (7→9, +2 정확), cleanup cron 임무 #16 dry-run cat_id 누설 0. **연속 all-green 32회차 (213~247차)**. 가짜 발행 가드 정상. §3.34.39~42 (240~246차 발견) 모두 통과. 상세: `references/session-20260711-247th-pwd-bash-cd-fix.md`.
> **2026-07-11 (246차)**: **green-run confirmation**
> **2026-07-11 (245차)**: §3.34.41 신규 — **`/usr/bin/python3` (3.9) 은 f-string 안에 백슬래시 quote 허용 안 함** (`SyntaxError: f-string expression part cannot include a backslash`). §3.8.1 가드 heredoc의 `print(f"... ct={r.headers.get(\"content-type\",\"\")[:50]}")` 패턴은 3.9 fallback에서 SyntaxError로 가드 자체가 막힘 → 세션 만료 오판 위험. 245차 첫 실행에서 hit, 즉시 string concatenation 으로 재작성하여 해결. **본문 §3.8.1 코드블록은 245차 수정 버전으로 정정** (아래). 그 외 **#962 코딩 평가(signal/noise 분리) + #963 Microsoft Flint** 두 건 정상 발행 — §3.34.40 4-step 명시 패턴, FRESH 4-field 매칭, post_publish_sync 7필드 보정, §3.5 5중 신호 일치 모두 통과. daily_counts[2026-07-11]['AI/ML'] = 6 (4→6, +2 정확), cleanup cron 임무 #16 cat_id 누설 0. 연속 all-green **30회차 (213~245차)**. 가짜 발행 가드 정상. 상세: `references/session-20260711-245th-two-publishes.md`.
> **2026-07-11 (244차)**: §3.34.39 보완 (**후보 직접 점수 정렬 + FRESH 4-field 명시 매칭 패턴**) 정착 — `blog_pipeline.py --refresh-topics --dry-run` 으로 후보 topic_id 12개 + 점수/카테고리 동시 추출, pt.details + state.details 양쪽 교차 매칭 후 FRESH 판정 → `--category`/`--force-topic` 호출 없이도 정확히 0점 손실로 첫 pick 가능. 244차 `#31286 LLM 번아웃 (19점)` 첫 pick에서 publish `#960` 성공. **§3.5 5중 신호 영구 보정 (242차 본문 오표기 정정)** — 242차에 "pt.last.url = state['published_topics']['last'].url" 형태로 적혀있었으나 **state 파일엔 `published_topics` 키 없음**. 진짜 4/5번 신호는 `~/.hermes/memory/published_topics.json` (별도 파일) 의 `last.url` + `details[-1].url`. 244차 검증 후 영구 보정 형식:
> 1. `state.last_published_url`
> 2. `state.last.url`
> 3. `state.details[-1].url`
> 4. **`published_topics.json` last.url** (별도 파일, source-of-truth)
> 5. **`published_topics.json` details[-1].url** (별도 파일, source-of-truth)
>
> state.json엔 `last_topics`, `last_post`, `last`, `details`, `last_published_url` 만 존재 — `state['published_topics']` 로 lookup 시도하지 말 것. **격리 패턴 정정 (244차)**: 243차 본문이 `env -i` 후 외부에서 source한 env를 노출 — 사실 `env -i`가 모든 환경변수 날리므로 cookie count=0 → 세션 만료 오판. 정정: `env -i HOME=... PATH=... /bin/bash -c 'set -a; source tistory.env; set +a; /usr/bin/python3 << EOF'` 형태로 bash 안에서 source 후 child python 상속. **execute_code cron 차단 (244차)**: cron 컨텍스트에서 `execute_code`은 `BLOCKED: ... bypass shell-string approval checks` 로 거부됨 → `terminal`+heredoc 또는 `write_file`로 draft.md 저장 후 `tistory_publisher.py --file` 직접 호출. cleanup cron 임무 #16 dry-run **29회 연속 all-green** (213~244차). 가짜 발행 가드 정상 동작. 상세: `references/session-20260711-244th-fresh-pick-and-pt-source.md`.
>
> **2026-07-11 (243차)**: 두 가지 cron 자동화 한계 발견 — (a) **`blog_pipeline.py --category 'AI/ML'` 의 후보 pick이 점수 무관** — 첫 실행 `31301 (3점)`, 두번째 실행 `Tencent Hy3 (이미 발행 #958)`. 즉 fresh 후보 우선순위가 무너지고 마지막 published 토픽 주변을 순환. cron 컨텍스트에서 `--category` 단독 호출은 가짜 pick 위험. (b) **`--force-topic <id>` 는 source_url/topic_url을 빈 값으로 박음** (output JSON에 `"source_url": ""`, `"topic_url": ""`) → `tistory_publisher.py --source-url` 단계로 이어질 정보 미주입. cron 자동 publish 진행시 본문 작성 단계가 별도 LLM 컨텍스트에 강제 의존. (c) **state 경로 명세 일치 확인**: 진짜 state 파일은 `~/.hermes/memory/blog_pipeline_state.json` (블로그 파이프라인 통합 state). `post_publish_sync.py sync-from-pt` 가 `~/.hermes/state/tistory_state.json` 를 lookup하지만 해당 파일은 부재 → sync-from-pt 결과가 `pt_updated: true / state_updated: true / errors: [] / triple_signal_match: true` 반환하지만 **사실상 pt→pt noop**. 진짜 drift 보정은 별도 heredoc이 필요했음 (이번 차는 5중 신호가 이미 일치하여 drift 무해). 다음 차에 `post_publish_sync.py` 가 통합 state 경로를 lookup하도록 패치 권장. **§3.34.39 보완은 244차 reference + 본문에 코드 스니펫 신규 영구화**.
>
> **2026-07-11 (242차)**: §3.5 신호 **5중 검증** 정식화 + `post_publish_sync.py` CLI 실전 검증 — **§3.5 검증 항목이 실제로는 5개**임 확인 (`state.last_published_url` + `state.last.url` + `state.details[-1].url` + `pt.last.url` + `pt.details[-1].url` 전부 동일해야 함). SKILL.md 본문이 "3중"이라고 표기된 부분은 **legacy 5중** 으로 갱신. **`post_publish_sync.py` CLI 형태 영구화**: 단순 `--url` 플래그가 아닌 `sync` 서브커맨드 + `--url/--title/--gn-topic-id/--category/--source-url/--category-id(선택)` 형태. 242차 `#959 OpenAI GPT 5.6` 발행에서 §3.8.1 가드 통과 + `env -i` §3.8.2 격리로 publish 성공 + sync 결과 `triple_signal_match: true` 보고 확인. **`tistory_publisher.py` CLI 인수 함정 (NEW)**: `--topic-url` / `--auto-record` 는 **존재하지 않는 옵션** (사용시 `unrecognized arguments` 에러). 실제 옵션은 `--source-url <URL>` + `--gn-topic-id <N>` 분리. **244차 보정**: 242차 본문에 적힌 `pt.last.url = state['published_topics']['last'].url` 은 사실 — state.json에는 `published_topics` 키가 없고 pt는 `~/.hermes/memory/published_topics.json` 별도 파일. 위 244차 영구 보정 형식 참조. 상세: `references/session-20260711-242nd-five-signal-and-cli-args.md`.
>
> **2026-07-10 (241차)**: §3.11 5-1 자동 보정 신규 영구화 (NEW, 두 번째로 중요) — **`tistory_publisher.py`가 발행 성공해도 pt/state/stats를 자동 갱신하지 않음** 확인 (240차 #958 발행 후 검증 단계에서 발견). 매 세션마다 §3.11 5-1 heredoc 수동 작성은 비효율 → `scripts/post_publish_sync.py` 신규 (publish_url, title, gn_topic_id, category, source_url 인자 → pt.last + pt.details + state.details + state.last_published_url + state.last + state.daily_counts[today][category] +1 원샬 동기화). **§3.5 사전 drift 자동 감지 → publish 전 보정 후 진행** 워크플로 정착. cleanup cron 임무 #16 dry-run **28회 연속 all-green** (213~241차) + §3.8.2 격리 패턴 적용 OK. 상세: `references/session-20260710-241st-post-publish-sync.md`.
>
> **2026-07-10 (240차)**: §3.8.1 세션 만료 1회 실전 검증 + **hermes-agent venv 격리 패턴 신규 영구화** (NEW, 가장 중요) — §3.8.1 `manage/posts.json` 호출이 **302 → `/auth/login` 리다이렉트**로 세션 만료 확정. publish 단계 skip + §3.5 3중 신호 검증만 실행 후 정상 종료. **가드 통과 못해도 reports는 항상 정상 보고** (이번 차는 "발행 0건 + 세션 만료" 리포트). **hermes-agent venv의 `urllib3 2.6.x`가 Python 3.11.15와 비호환 (PEP 604 union syntax 3.10+ 필요)** → `TypeError: unsupported operand type(s) for |: 'type' and 'type'` 로 `import requests` 실패. **`/usr/bin/python3` (3.9) + `PYTHONPATH=/Users/mac/Library/Python/3.9/lib/python/site-packages` 격리 패턴 표준화** — system site에 `requests-2.32.5` + `urllib3-2.6.3` 설치되어 있어 동작. `env -i HOME=/Users/mac PATH=/usr/bin:/bin /usr/bin/python3 ...` 형태로 venv 영향 완전 차단. **§3.5 3중 신호 일치 OK 유지** (239차 §3.34.36 heredoc 보정 결과 — `#957 Muse Spark 1.1` last+details 모두 박힘) + `stats.daily_counts[2026-07-10] = {'AI/ML': 4, '개발도구': 1, '개발팁': 1}` (cat_id 누설 없음) + cleanup cron 임무 #16 dry-run **27회 연속 all-green** (213~240차) + **§3.8.1 가드 동작 정상 검증 (302 감지 정확)** + **§3.8.2 격리 패턴 (NEW) 영구화** — `scripts/isolate_hermes_python.py` 신규 (모든 cron 작업에서 hermes venv python3 호출 실패시 격리 fallback). 상세: `references/session-20260710-240th-cookie-expired-venv-isolation.md`.

## §3.8.2 격리 패턴 (NEW, 240차) — 244차 정정 반영

hermes-agent venv의 `urllib3 2.6.x`가 Python 3.11.15와 비호환 (PEP 604 union syntax 3.10+ 필요). 모든 cron 작업에서 `python3` 호출이 `TypeError: unsupported operand type(s) for |: 'type' and 'type'`로 실패할 때 다음 격리 패턴 사용. **244차 정정**: `env -i` 자체가 모든 환경변수 날리므로, 외부에서 source한 env는 격리 child에 노출되지 않음. `bash -c 'set -a; source ...; set +a; python3'` 형식으로 **source 단계도 격리 안에서** 수행해야 함. **245차 보완**: 격리 패턴으로 호출되는 `python3`는 `/usr/bin/python3` (**Python 3.9**) — 3.9는 **f-string 안 백슬래시 quote 미허용** (PEP 701 이전 제약). §3.8.1 가드 heredoc은 반드시 string concatenation 패턴으로 작성 (§3.34.41 참조).

```bash
# ✅ 244차 정정 패턴 (권장) — 247차: PWD 추가 필수
env -i HOME=/Users/mac PATH=/usr/bin:/bin PWD=/Users/mac /bin/bash -c '
set -a
source ~/.hermes/secrets/tistory.env
set +a
/usr/bin/python3 << "PYEOF"
import sys, os
sys.path.insert(0, "/Users/mac/Library/Python/3.9/lib/python/site-packages")
import requests
cookies = {k.replace("TISTORY_",""): os.environ[k] for k in os.environ if k.startswith("TISTORY_")}
print("cookie count:", len(cookies))
PYEOF
'
# 또는 bash 안에 `cd /Users/mac` 첫 줄 (PWD 미설정시)
```

`scripts/isolate_hermes_python.py` — `guard_tistory_session()` 함수로 §3.8.1 가드 호출 가능. CLI 1회 실행:

```bash
env -i HOME=/Users/mac PATH=/usr/bin:/bin PWD=/Users/mac /bin/bash -c '
set -a; source ~/.hermes/secrets/tistory.env; set +a
/usr/bin/python3 ~/.hermes/skills/automation/tistory-publisher/scripts/isolate_hermes_python.py
'
```

> ⚠️ **isolate_hermes_python.py 자체 호출 함정 (258차 발견)**: 위 예시는 1회 실행용 — bash 안에서 source 후 child python 상속. 그러나 **스크립트 자체는 source 단계를 거치지 않으므로**, 워치독/자동화에서 스크립트를 격리 없이 직접 호출 (`python3 isolate_hermes_python.py`)하면 cookies=0 → 302 → `§3.8.1 세션 만료` 오판. 258차 1차 probe에서 hit → 즉시 격리 bash 안 source 후 2차 probe로 정상 통과 확인. **다음 차 자동화에서 해당 스크립트를 호출할 땐 반드시 위 4-line 격리 bash 패턴으로 감싸라**. 스크립트 내부에 `source ~/.hermes/secrets/tistory.env` 자동 호출을 추가하는 패치는 보류 — 현재 워치독 호출 경로 없음.

## §3.11 5-1 자동 보정 (NEW, 241차)

**핵심 발견**: `tistory_publisher.py --file ...`가 "발행 성공" 메시지를 출력하고 pt/state/stats를 자동 갱신하지 않음. 매 세션마다 §3.11 5-1 보정 heredoc을 수동으로 작성해야 했는데, 이제 `scripts/post_publish_sync.py`로 영구화.

```bash
env -i HOME=/Users/mac PATH=/usr/bin:/bin PWD=/Users/mac /bin/bash -c '
set -a
source ~/.hermes/secrets/tistory.env
set +a
/usr/bin/python3 << PYEOF
import sys, os
sys.path.insert(0, "/Users/mac/Library/Python/3.9/lib/python/site-packages")
sys.path.insert(0, "/Users/mac/.hermes/skills/automation/tistory-publisher/scripts")
import post_publish_sync
post_publish_sync.sync(
    publish_url="https://sigco.tistory.com/960",
    title="LLM 번아웃이 온 것 같아요 — ...",
    gn_topic_id=31286,
    category="AI/ML",
    source_url="https://news.hada.io/topic?id=31286"
)
PYEOF
'
```

**또는 CLI 1회 실행** (242차 실전 검증, `sync` 서브커맨드 + `--category-id` 선택):

```bash
env -i HOME=/Users/mac PATH=/usr/bin:/bin PWD=/Users/mac /bin/bash -c '
set -a; source ~/.hermes/secrets/tistory.env; set +a
/usr/bin/python3 ~/.hermes/skills/automation/tistory-publisher/scripts/post_publish_sync.py sync \
  --url "https://sigco.tistory.com/960" \
  --title "LLM 번아웃이 온 것 같아요 — 같은 문체·같은 환각의 반복이 만든 피로와 5가지 대응법" \
  --gn-topic-id 31286 \
  --category "AI/ML" \
  --category-id 1219746 \
  --source-url "https://news.hada.io/topic?id=31286"
'
```

> ⚠️ **CLI 인수 함정 (242차 발견)**: 단순 `--url ...` 만 단독으로 넘기면 `argparse error: invalid choice: 'https://...'` 에러남. 반드시 `sync` 서브커맨드를 먼저 명시할 것. `--category-id` 는 생략 가능 (자동 매핑되지만 명시 권장 — cleanup cron 임무 #16 cat_id 누설 방지).
>
> ⚠️ **CLI title 오타 검증 (258차 발견)**: `sync --title "..."` 로 박은 title 문자열에 숫자 단위(예: `Java 1.0` vs `Java 5.0`, `1만` vs `10만`)가 포함된 경우 오타 가능. **사후 검증 단계 권장**:
> 1. sync 직후 pt.last.title + state.last.title + state.details[-1].title 3필드가 모두 publish 직전 draft 제목과 정확히 일치하는지 확인.
> 2. 불일치시 → 직접 json 파일에 load 후 3필드 모두 같은 값으로 덮어쓰기 보정 (sync 스크립트는 다시 호출할 필요 없음, noop 위험).
> 3. publish 된 Tistory 페이지 자체의 <title> 태그는 별도로 고치려면 브라우저 단에서 수정 — 자동 sync는 pt/state만 보정.
>
> **함정 패턴 예시 (258차)**: draft 본문엔 `Java 1.0` 정상이었는데 CLI title 인자에 `Java 5.0` (자릿수 비슷한 오타) 으로 박힘 → sync 결과 `triple_signal_match: true` 반환했지만 실제론 오타. **원문/원본 draft의 원래 title substring을 다시 확보한 뒤** pt/state 양쪽 일괄 덮어쓰기가 정답.

**동기화 대상** (7필드 원샬):

1. `pt['last']` — hash, topic, title, date, url, source_url, gn_topic_id
2. `pt['details']` — append entry (hash, topic, title, url, date)
3. `pt['topics'][hash]` — dict 인덱스 (있으면)
4. `state['last_published_url']`, `state['last_published_id']`
5. `state['last']` — title, url, date
6. `state['details']` — append entry (topic_id, title, url, date, category, category_id, gn_topic_id, source_url)
7. `state['daily_counts'][today][category]` += 1

**§3.5 사전 drift 감지 → publish 전 보정 후 진행 워크플로 (244차 5중 검증 영구 보정)**:

- publish 직전, 다음 **5개 URL이 모두 일치**하는지 검증. **pt는 state 내부 dict가 아니라 `published_topics.json` 별도 파일**:
  ```python
  import json
  state = json.load(open('/Users/mac/.hermes/memory/blog_pipeline_state.json'))
  pt = json.load(open('/Users/mac/.hermes/memory/published_topics.json'))
  sigs = {
      '1. state.last_published_url': state.get('last_published_url'),
      '2. state.last.url': state['last']['url'] if isinstance(state.get('last'), dict) else None,
      '3. state.details[-1].url': state['details'][-1]['url'] if state.get('details') else None,
      '4. pt.last.url': pt['last']['url'] if isinstance(pt.get('last'), dict) else None,
      '5. pt.details[-1].url': pt['details'][-1]['url'] if pt.get('details') else None,
  }
  all_match = len(set(sigs.values())) == 1
  ```
- 불일치시 → `post_publish_sync.py sync-from-pt` 호출 (pt를 source-of-truth로 state 보정). 단, 243차 §3.34.39 (c) 함정 — sync-from-pt 가 잘못된 경로 lookup하므로 결과 `triple_signal_match: true` 만 믿지 말 것.
- 일치시 → publish 진행
- 244차 검증: publish 직전 5중 모두 `#959` 일치 확인 후 진행, publish 후 모두 `#960` 으로 갱신 확인

## §3.34.43 격리 패턴 PWD/cd 함정 (NEW, 247차)

`env -i HOME=... PATH=... /bin/bash -c '...'` 호출 시 hermes 셸 bashrc가 자동 `cd /Users/mac/.hermes/repos/icbm2-knowledge-graph` 시도 → **exit 126 (`bash: 행 N번: cd: ...: No such file or directory`)** 으로 명령 자체가 실행 안 됨. 247차 `post_publish_sync.py sync` 첫 호출에서 hit, `cd` 라인만 stderr로 출력되고 본 python3 호출 안 됨.

**회피 패턴 (3가지 중 택일)**:

```bash
# ✅ 패턴 1: PWD 환경변수 명시
env -i HOME=/Users/mac PATH=/usr/bin:/bin PWD=/Users/mac /bin/bash -c '
set -a; source ~/.hermes/secrets/tistory.env; set +a
/usr/bin/python3 ... '

# ✅ 패턴 2: bash 서브쉘 시작 시 cd 명시
env -i HOME=/Users/mac PATH=/usr/bin:/bin /bin/bash -c '
cd /Users/mac
set -a; source ~/.hermes/secrets/tistory.env; set +a
/usr/bin/python3 ... '

# ✅ 패턴 3: bash 호출 대신 source + python 직접 호출
env -i HOME=/Users/mac PATH=/usr/bin:/bin /usr/bin/python3 - << 'PYEOF'
... PYEOF
```

**적용 범위**: §3.8.1 가드, §3.11 sync, §3.34.40 publish, §3.34.42 verify-tistory-cookie 격리 호출 등 **모든 `env -i ... /bin/bash -c '...'` 형태**. §3.34.40 FRESH 4-field 매칭처럼 python 단독 호출은 영향 없음 (bash 거치지 않음).

> 패턴 3이 가장 단순하지만 heredoc에서 source가 필요한 경우 (Tistory 쿠키 env) 불가 → 패턴 1 또는 2 권장.

## §3.34.39 보완: 후보 직접 점수 pick 패턴 (NEW, 244차)

`blog_pipeline.py --category '<cat>'` 또는 `--force-topic <id>` 단독 호출 회피. cron 자동 발행에선 다음 4-step 명시 패턴:

```bash
# 1. 후보 12개 + 점수 추출 (--category 무관, refresh만 dry-run)
python3 ~/.hermes/scripts/blog_pipeline.py --refresh-topics --dry-run 2>&1 | \
  grep -E 'URL:' | head -12
# → 31286(19), 31281(11), 31291(10), 31287(10), 31300(9), 31275(PUB), 31283(8),
#   31280(6), 31290(PUB), 31279(PUB), 31276(PUB), 31301(3) (예시)

# 2. FRESH 4-field 매칭 (python 격리 패턴 안)
env -i HOME=/Users/mac PATH=/usr/bin:/bin /usr/bin/python3 << 'PYEOF'
import json
pt = json.load(open('/Users/mac/.hermes/memory/published_topics.json'))
state = json.load(open('/Users/mac/.hermes/memory/blog_pipeline_state.json'))
pt_published = set()
for d in pt.get('details', []):
    for k in ['topic', 'topic_id', 'gn_topic_id']:
        if k in d and str(d[k]).isdigit():
            pt_published.add(str(d[k]))
state_published = set()
for d in state.get('details', []):
    for k in ['topic_id', 'gn_topic_id']:
        if k in d and str(d[k]).isdigit():
            state_published.add(str(d[k]))
candidates = ['31286','31281','31291','31287','31300','31275','31283',
              '31280','31290','31279','31276','31301']
fresh = [c for c in candidates if c not in pt_published and c not in state_published]
already = [c for c in candidates if c in pt_published or c in state_published]
print(f"FRESH: {fresh}")
print(f"PUB:   {already}")
PYEOF

# 3. TOP FRESH 후보로 draft 작성 (write_file로 markdown 저장)
# /tmp/tistory_drafts_<session>/draft-<topic_id>-<slug>.md

# 4. 명시 publish (--source-url + --gn-topic-id + --category-id int + --image-query)
env -i HOME=/Users/mac PATH=/usr/bin:/bin PWD=/Users/mac /bin/bash -c '
set -a; source ~/.hermes/secrets/tistory.env; set +a
/usr/bin/python3 /Users/mac/.hermes/scripts/tistory_publisher.py \
  --title "<TITLE>" --category 1219746 \
  --file /tmp/tistory_drafts_<session>/draft-<topic_id>-<slug>.md \
  --source-url "https://news.hada.io/topic?id=<topic_id>" \
  --gn-topic-id <topic_id> \
  --image-query "<korean or english query>"
'

# 5. post_publish_sync sync (7필드 보정)
# 위 §3.11 sync 호출 형식
```

## §3.34.46 gn-fetch-content 영구화 완료 (259차 식별, 260차 실전 검증, 261차 패치 ✅)

**261차 cleanup cron 임무 #23 영구화 완료**: `scripts/gn-fetch-content.py` 의 `GN_MD_URL = GN_TOPIC_BASE + "/{tid}.md"` 정정 + `GN_TOPIC_BASE` 정의 순서 보정 (line 48→49로 이동) + `_try_md_endpoint` docstring 갱신. 261차에 `_try_md_endpoint(31378)` 테스트 → status=200, **9590 bytes** 정상 fetch. 1단계 `.md` endpoint가 즉시 성공 → HTML/RSS fallback 까지 fallthrough하던 stale 함정 종료.

> **영구화 코드 패치 적용 시 두 가지 함정 (261차 식별, 즉시 정정)**:
> 1. **f-string 모듈 로드 시점 평가 함정** — `GN_MD_URL = f"{GN_TOPIC_BASE}/{{tid}.md"` 형태로 적으면 Python이 모듈 로드 시점에 line 순서대로 f-string을 평가. line 48에서 `GN_TOPIC_BASE`가 아직 정의 안 됐으므로 `NameError: name 'GN_TOPIC_BASE' is not defined` 발생. → 정정: `GN_TOPIC_BASE + "/{tid}.md"` (string concatenation은 런타임 lazy 평가라 정의를 뒤로 미뤄도 OK).
> 2. **정의 순서 함정** — `GN_TOPIC_BASE` 정의를 `GN_MD_URL` 보다 **앞 줄**에 두어야 함. string concatenation 사용시에도 안전을 위해 권장.
>
> 위 두 함정은 §3.34.41 f-string 제약과는 다른 차원의 함정 — §3.34.41은 heredoc 안 f-string 안 백슬래시 quote, 이건 모듈 상수 정의 시 f-string 평가 순서. 둘 다 명확히 구분해서 회피.

**영구화 후 본문 fetch 호출 (가장 단순한 패턴, 임시 우회 heredoc 불필요)**:

```python
import importlib.util
spec = importlib.util.spec_from_file_location('gfc', '/Users/mac/.hermes/skills/automation/tistory-publisher/scripts/gn-fetch-content.py')
gfc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gfc)
content = gfc._try_md_endpoint(31378)
# → 9590 bytes (status=200, 깨끗한 markdown)
```

또는 `gfc.fetch_gn_content(31378)` 호출로 `(title, content, source)` tuple 확보 (244차 §3.34.34 확인된 public API).

**본문 추출 정규화 패턴 (260차 정착)**:
```python
import re
text = r.text
# 1. Comments 섹션 제거
m = re.search(r"\n## Comments", text)
if m:
    text = text[:m.start()]
# 2. Metadata 섹션 (## Metadata 다음 - 키:값 리스트) 제거
m_meta = re.search(r"\n## Metadata", text)
if m_meta:
    after_meta = text[m_meta.end():]
    lines = after_meta.split("\n")
    body_lines = []
    in_meta = True
    for line in lines:
        # "- key: value" 또는 빈 줄 → 메타데이터로 간주 skip
        if in_meta and (line.startswith("- ") or line.strip() == "" or line.startswith("  ")):
            continue
        in_meta = False
        body_lines.append(line)
    text = "\n".join(body_lines).strip()
# 3. "## Topic Body" 헤더 한 줄 제거
text = re.sub(r"^## Topic Body\s*\n+", "", text)
```

**Tistory HTML 변환 패턴 (260차 정착, 262차 보완)**:
- `## 헤더` → `<h2>헤더</h2>`
- `### 헤더` → `<h3>헤더</h3>`
- `- 항목` → `<ul><li>항목</li></ul>` (빈 줄 = `</ul>` close 트리거)
- `**bold**` → `<strong>bold</strong>`

> ⚠️ **262차 식별 — 리스트 들여쓰기 / 그룹화 함정**: GeekNews 본문에는 `## 기존 모델의 호출 방식에 맞춰진 제약` 같은 **헤더로 위장된 `-` 항목**(예: `- ## 기존 모델의 호출 방식에 맞춰진 제약`)이나 들여쓬 하위 리스트(`  - ...`)가 흔함. 두 함정:
> 1. **들여쓬 sub-list를 nested `<ul>`로 변환하려고 ul_stack 패턴을 쓰면 깨짐** — 262차 첫 시도에서 들여쓰기 depth를 측정해 `<ul><ul><li>` 를 쌓았더니 md가 nested 가 아닌 pseudo-nested (모든 `- `이 동등한 top-level bullet) 일 때 매 항목마다 `<ul>` 가 새로 열리고 즉시 닫혀 시각적으로 리스트가 아님. → **회피**: indent 무시하고 모든 `- `를 top-level bullet로 취급, 연속된 `- ` 라인들을 하나의 `<ul>...</ul>` 로 묶고 빈 줄에서만 close. 들여쓰기는 시각적 깊이일 뿐 마크다운 의미상 모두 형제 항목.
> 2. **`- ## 헤더` 형식의 위장된 헤더** — GeekNews 마크다운에서 가끔 `- ## 기존 모델의 호출 방식에 맞춰진 제약` 같이 list-prefixed header 가 나옴. `<li>` 로 변환되면 의미 파괴. → **회피**: `- ` 변환 직전 item_text가 `## `/`### `로 시작하면 `<h2>`/`<h3>` 로 라우팅 (indented header는 별도 처리).
>
> **262차 정착 정규식 + 함수 (개선된 md_to_html)**:
> ```python
> def md_to_html(md):
>     out = []
>     in_ul = False
>     for line in md.split("\n"):
>         stripped = line.lstrip()
>         if stripped.startswith("- "):
>             item_text = stripped[2:].strip()
>             # 헤더 위장된 list item 라우팅
>             if item_text.startswith("## ") or item_text.startswith("### "):
>                 if in_ul: out.append("</ul>"); in_ul = False
>                 tag = "h2" if item_text.startswith("## ") else "h3"
>                 out.append(f"<{tag}>{html.escape(item_text.split(' ',1)[1])}</{tag}>")
>                 continue
>             if not in_ul:
>                 out.append("<ul>")
>                 in_ul = True
>             item_esc = html.escape(item_text)
>             item_esc = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", item_esc)
>             item_esc = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r'<a href="\2">\1</a>', item_esc)
>             out.append("<li>" + item_esc + "</li>")
>         elif line.startswith("### "):
>             if in_ul: out.append("</ul>"); in_ul = False
>             out.append("<h3>" + html.escape(line[4:].strip()) + "</h3>")
>         elif line.startswith("## "):
>             if in_ul: out.append("</ul>"); in_ul = False
>             out.append("<h2>" + html.escape(line[3:].strip()) + "</h2>")
>         elif stripped == "":
>             if in_ul: out.append("</ul>"); in_ul = False
>         elif stripped == "---":
>             if in_ul: out.append("</ul>"); in_ul = False
>             out.append("<hr>")
>         else:
>             if in_ul: out.append("</ul>"); in_ul = False
>             p_html = html.escape(line)
>             p_html = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", p_html)
>             p_html = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r'<a href="\2">\1</a>', p_html)
>             out.append("<p>" + p_html + "</p>")
>     if in_ul: out.append("</ul>")
>     return "\n".join(out)
> ```

**editorial 인트로/결론 추가 패턴 (260차 정착, 한국어 1~2 단락)**:
```html
<!-- intro: 한국 독자층 맞춤 1~2 단락 + 원문 링크 -->
<p><a href="https://news.hada.io/topic?id=31376">GeekNews에 공유된 ...</a>을 보면, ...</p>
<p>흥미로운 건 이 프레임이 단순한 유행어 가설이 아니라는 점입니다. ...</p>

<!-- 본문 (GeekNews → HTML 변환) -->

<!-- conclusion: 한국 시장 시사점 1~2 단락 + 원문 링크 -->
<h2>한국 시장에서의 시사점</h2>
<p>한국 SaaS 시장에서도 이미 ...</p>
<p>특히 <strong>고객 응대, 예약·배차, 분류·검토, 보고서 작성</strong> 같은 ...</p>
<p style="color:#666;font-size:0.9em;">원문: <a href="https://news.hada.io/topic?id=31376">GeekNews #31376</a></p>
```

**261차 검증 결과**: `_try_md_endpoint(31378)` 직접 호출 → 9590 bytes (1단계 `.md` endpoint 즉시 fetch). 2장 Picsum CDN 업로드 정상 (query: llm coding ai hype bubble skeptic, ID 365/68). 5중 신호 모두 `#996` 일치. publish 성공. **영구화 패치 완료 — 259~260차 임시 우회 heredoc 패턴 불필요**.

**262차 보완**: `md_to_html` 함수를 재사용 가능한 모듈로 추출 → `scripts/gn-markdown-to-tistory-html.py` (CLI + 모듈 둘 다 지원). 262차 정착판은 260차 4종 패턴 + 262차 보완 2종 함정(들여쓰기 nested ul, `- ## ` 위장 header) 회피 포함. CLI 사용법: `python3 gn-markdown-to-tistory-html.py <topic_id> --with-intro --with-conclusion --out /tmp/draft.html`. 모듈: `from gn_markdown_to_tistory_html import build_full_html; build_full_html(31404, "https://news.hada.io/topic?id=31404")`.

**§3.34.46 본문 → Tistory HTML 변환 4종 패턴 + editorial 인트로/결론 추가**: 아래 "절대 하지 말 것" 박스의 마지막 항목 참조.

## §3.34 핵심 함정 (최근 5차 압축 요약)

- **§3.34.48 (266차, NEW)**: **GeekNews 본문 `* ` 들여쓰기 리스트 패턴 추가 함정** — GeekNews 31432 (Papermake) 본문이 `- ` 외 `* ` 들여쓰기 패턴을 혼용 (`* 완전한 감사 추적(Audit Trail)` 등). 262차 정착 `md_to_html` 은 `- ` 만 처리하여 `* ` 라인이 그냥 `<p>` 로 떨어져 들여쓴 sub-list가 시각적으로 평평한 본문으로 변환됨. **회피**: `md_to_html` 에 `elif stripped.startswith("* ") and not stripped.startswith("**"):` 분기 추가 (bold `**` 시작은 제외) → `* ` 도 동일하게 `<ul><li>` 변환. 266차 첫 빌드에서 hit → 즉시 분기 추가하여 해결. **적용 범위**: §3.34.46 본문 빌드의 모든 변형. 266차 검증: 빌드 스크립트에 정규식 `md_norm = re.sub(r"^#### (.+)$", r"### \1", md, flags=re.MULTILINE)` (4단계 헤더 → 3단계 강등) + `* ` 분기 추가하여 266차 Papermake 본문 정상 처리. 차감/추가 없음 — 4단계 헤더 (####) 와 `* ` 들여쓰기는 GeekNews 마크다운의 일반적 변형으로 빈번히 등장.
- **§3.34.47 (263차, NEW)**: `/usr/bin/python3` 격리 패턴의 inline bash heredoc 안에서 길이가 30줄이 넘어가는 본문 빌드/HTML 변환 스크립트를 적을 때, §3.34.41 f-string 백슬래시 제약 + 본문 문자열 안의 `\"` escape + 한글 UTF-8 본문이 한꺼번에 걸려 `SyntaxError: Non-UTF-8 code starting with '\xec'` 또는 `SyntaxError: f-string expression part cannot include a backslash` 가 연쇄 발생. 263차 첫 시도에서 `md_to_html` (본문 2801자) + intro/conclusion (각 540/1700자) + 4종 escape + f-string 안 `item_text.split(\" \",1)[1]` 가 한 heredoc 안에 들어감. **회피**: `write_file` 로 빌드 스크립트를 `/tmp/<session>/build_draft.py` 에 `# -*- coding: utf-8 -*-` 선언과 함께 저장 → `python3 <script>.py` 로 격리 호출. **적용 범위**: §3.34.46 본문 빌드 / 다중 카테고리 한도 처리 / 인트로+본문+결론 합치기 등. 단일 probe (가드 / sync / state 확인) 처럼 5~10줄짜리 short heredoc은 §3.34.41 정정 (string concat) 으로 충분. **266차 검증**: 동일 패턴 3회째 정상 적용 (`/tmp/tistory_drafts_266th/build_draft.py`, 5618 bytes 빌드 스크립트 무영향).
- **§3.34.46 (259차 식별, 260차 실전 검증, 261차 영구화 완료 ✅)**: `scripts/gn-fetch-content.py`의 `GN_MD_URL` 상수가 `https://news.hada.io/topic.md?id={tid}` 형태 (stale) 였는데, 긱뉴스의 실제 작동 URL은 `/topic/{tid}.md`. 1단계 `.md` fallback이 항상 fail → step 2 HTML fallback (비표준 마크업 함정) / step 3 RSS fallback (짧은 길이 함정) 까지 fallthrough. 259차 1251 bytes / 260차 8952 bytes 임시 우회로 검증 → **261차 cleanup cron 임무 #23 영구화 완료**: `GN_MD_URL = GN_TOPIC_BASE + "/{tid}.md"` + `GN_TOPIC_BASE` 정의 순서 보정. `_try_md_endpoint(31378)` 테스트 → status=200, 9590 bytes. **임시 우회 heredoc 패턴 불필요** — public API `fetch_gn_content(tid)` 또는 `_try_md_endpoint(tid)` 직접 호출. **영구화 시 두 가지 코드 함정 (261차 식별)**: (1) `GN_MD_URL = f"{GN_TOPIC_BASE}/{{tid}.md"` 형태는 모듈 로드 시점에 line 순서대로 f-string 평가 → line 48에서 `GN_TOPIC_BASE` 미정의로 `NameError` → string concatenation 사용; (2) `GN_TOPIC_BASE` 정의가 `GN_MD_URL` 뒤에 있으면 안 됨 (앞 줄에 정의). 본문 → Tistory HTML 변환 4종 패턴 + editorial 인트로/결론 패턴 260차 정착 그대로 유효.
- **§3.34.45 (256차, NEW)**: **#21 가이드 경계 조건 + '기타' 제외 정책 우선순위** — `blog_pipeline.py` §1448~1456 (2026-06-08 영구화) 가 '기타' 카테고리를 발행 대상에서 제외. §3.34 #21 가이드 "AI/ML FRESH=0 이면 다른 카테고리 발행 허용" 은 '기타' 카테고리에는 적용 안 됨. **우선순위**: `'기타' 제외 > #21 AI/ML 우선`. FRESH 후보 매트릭스별 결정:
  - FRESH 모두 '기타' → **skip** (256차 실전 1호)
  - FRESH '기타' + 'AI/ML' 혼재 → **AI/ML 픽** (#21)
  - FRESH '기타' + 'AI/ML 외 다른 카테고리' 혼재 → **다른 카테고리 발행 허용** (#21 + '기타' 제외)
  - FRESH 'AI/ML' 단독 또는 'AI/ML' + 비-기타 혼재 → **AI/ML 픽** (#21)
  - FRESH 모두 'AI/ML 외 비-기타' → **점수 1순위 픽** (카테고리 균형, §3.34.39)
- **§3.34.44 (253차 식별 → 254차 실전 검증 완료, NEW)**: cron 차 사이 last URL drift — 사전 검증에서 `state.last_published_url` 이 직전 cron 차의 마지막 URL이 아닐 수 있음 (자정 사이 또는 외부에서 추가 발행된 흔적). **5중 검증 모두 일치 유지되어 drift 무해**가 확인됨 (254차: 사전 `#985` → 사후 `#986`, 모두 일치). 그러나 cron 자동화 워크플로에서 **pt/details 비교시 항상 현재 시점의 last url 을 source-of-truth로 사용**해야 함 — 직전 cron 차 reference의 last URL 과 비교하지 말 것. 코드 패치 불필요 (§3.5 5중 검증 + §3.11 sync 가 이미 drift-immune). 운영 가이드 추가: cron 차 사이 한 건 이상의 외부 발행이 일반화될 수 있음을 인정 (수동 발행, 다른 cron 인스턴스 등).
- **§3.34.43 (247차, NEW)**: `env -i HOME=... PATH=... /bin/bash -c '...'` 호출 시 bash 스타트업 시 자동 `cd /Users/mac/.hermes/repos/icbm2-knowledge-graph` 시도 → `bash: 행 N번: cd: ...: No such file or directory` 로 exit 126, 본 python3 호출 안 됨. **회피**: `cd /Users/mac` 명시 또는 `PWD=/Users/mac` 환경변수 추가. 모든 격리 패턴 호출에 적용.
- **§3.34.42 (246차, NEW)**: `verify-tistory-cookie.sh` [5]단계의 `tistory_publisher.py --check-session`가 **매 cron마다 §3.8.2 격리 함정**(hermes venv urllib3 2.6.x ≠ Python 3.11.15)으로 FAIL — 실제 세션 정상이어도 스크립트 리포트는 "FAIL=1". `env -i` + `/usr/bin/python3` 격리 패턴으로 probe 한 posts.json / category.json 은 HTTP 200 + JSON (2xx, 302 없음), §3.5 5중 신호 일치, 세션 진짜 정상. **패치 후보**: 스크립트 [5] 단계를 격리 패턴 호출로 교체 (e.g. `env -i HOME=... PATH=... /usr/bin/python3 /Users/mac/.hermes/scripts/tistory_publisher.py --check-session`). 246차엔 패치 미적용 — 운영자가 (a) 무시 운영 vs (b) 스크립트 격리화 선택.
- **§3.34.41 (245차, NEW)**: **`/usr/bin/python3` (Python 3.9) 는 f-string 내부에 백슬래시 quote 미허용** — `SyntaxError: f-string expression part cannot include a backslash`. §3.8.1 가드 heredoc에 흔히 적힌 `print(f"... ct={r.headers.get(\"content-type\",\"\")[:50]}")` 패턴이 3.9에서 SyntaxError → 가드 자체가 막혀 **세션 만료 오판 + 가짜 발행 가드 무력화** 위험. 회피: string concatenation `print("... ct=" + r.headers.get("content-type","")[:50])`. 또는 `%` formatting. 또는 `content_type = r.headers.get("content-type","")[:50]` 변수 추출 후 f-string 외부 사용. 격리 패턴(`/usr/bin/python3`)은 3.9다 — 항상 이 제약이 적용됨. (§3.8.2 격리 패턴, §3.34.40 후보 pick 패턴의 모든 heredoc에 적용.)
- **§3.34.40 (244차)**: 후보 직접 점수 pick + FRESH 4-field 매칭 패턴 영구화. `blog_pipeline.py --category` 단독 호출 pick 버그 회피. **§3.5 5중 신호 영구 보정**: 242차 본문이 `pt.last.url = state['published_topics']['last'].url` 였는데 state.json엔 `published_topics` 키 부재. 진짜 pt는 `~/.hermes/memory/published_topics.json` 별도 파일 (state가 아니라). **격리 패턴 정정**: `env -i bash -c 'set -a; source tistory.env; set +a; python3'` (source 단계도 격리 안). **execute_code cron 차단**: `BLOCKED: ... bypass shell-string approval checks` → write_file + tistory_publisher.py --file 우회.
- **§3.34.39 (243차)**: **`blog_pipeline.py --category '<cat>'` 의 후보 pick이 점수 무관** — fresh 후보(예: 19점 LLM 번아웃) 대신 마지막 published 토픽 주변을 순환 pick (3점 31301 → 이미 발행된 Tencent Hy3). cron 자동 발행에서 `--category` 단독 호출은 가짜 pick 위험. 대안은 후보 목록을 직접 점수 정렬 후 `record_published_topic`로 명시 처리. **`--force-topic <id>` 는 source_url/topic_url을 빈 값** 으로 박음 → publish 단계의 tistory_publisher.py --source-url 인자로 전달 불가. cron 컨텍스트 본문 발행은 사실상 불가. **`post_publish_sync.py sync-from-pt` 가 잘못된 state 경로 lookup** — 코드: `~/.hermes/state/tistory_state.json` (부재), 진실: `~/.hermes/memory/blog_pipeline_state.json`. 결과 `pt_updated: true` 만 보고하고 state는 noop (다음 차 코드 패치 권장 — `STATE_FILE = HERMES_DIR / 'memory' / 'blog_pipeline_state.json'` 으로 정규화).
- **§3.34.38 (242차)**: `tistory_publisher.py`에 `--topic-url` / `--auto-record` 옵션은 **존재하지 않음** → `unrecognized arguments` 에러. 진짜 옵션은 `--source-url <URL>` + `--gn-topic-id <N>` 분리. 또한 §3.5 신호 검증은 **3중이 아니라 5중** (state.last_published_url + state.last.url + state.details[-1].url + pt.last.url + pt.details[-1].url — **단 244차 보정: pt는 published_topics.json 별도 파일**).
- **§3.34.37 (241차)**: `tistory_publisher.py`가 pt/state/stats 자동 동기화 안 함 → `scripts/post_publish_sync.py` 신규 (publish 후 필수 호출). **CLI는 `sync` 서브커맨드 필수** (242차 확인).
- **§3.34.36 (239차)**: `blog_pipeline.py --record` 3-arg가 `pt['last'].url = None` 박기 가능 → (a') pt['last'].url 별도 검증 필수. `scripts/blog-pipeline-record-url-guard.py` 권장.
- **§3.34.33 (238차)**: `post-publish-correct.sh` 5-1단계 heredoc이 cat_id("1219746")를 stats key로 박는 버그 — `scripts/cleanup_daily_cat_id_leak.py`로 자동 보정 (cleanup cron 임무 #16).
- **§3.34.34 (238차)**: `gn-fetch-content` 본문 필요시 `importlib.util.spec_from_file_location()` 로 모듈 로드 후 `result[1]` 참조 (CLI는 300자 preview만). 함수명 `fetch_gn_content` (244차 확인), 결과 `(title, content, source)` tuple.
- **§3.34.35 (238차)**: `--image-query` cron 전달 의무 — Picsum router 자동 매핑은 동작하나 cron 프롬프트 누락시 본문 그림 0장.
- **§3.34.32 (236차)**: `tistory_publisher.py --category`는 int ID만 허용 (`AI/ML` 문자열 실패), `state.daily_counts` 구조는 `{date: {category: count}}` dict-of-dict-of-int.
- **§3.34.31 (235차)**: pt와 state 두 파일 drift 가드 — `post-publish-correct.sh`는 pt만 동기화, state 6단계 sync heredoc 매 세션 필수 → 241차 `post_publish_sync.py`로 영구화.
- **§3.34.30 (234차)**: `blog_pipeline.py --category`는 guideline만 출력, 실제 publish는 `tistory_publisher.py --file /tmp/draft.md` 명시 호출이 표준.
- **§3.34.29 (233차)**: `commit_publish` + `record_published_topic` 분기 — 단일 박기 자동 보정 불가, 수동 heredoc 보정 필수 → 241차 `post_publish_sync.py`로 부분 해결.
- **§3.34.28 (231차)**: §3.30.4 historical drift 자동 복구 가드 한계 — cleanup cron 임무 #15 health check 알림만.

## cleanup cron 임무 상태 (264차)

- **#1 (retroactive-gn-topic-id)**: 영구화 미완료, historical drift 누적 (231차 ~920 / 248차 갱신 필요)
- **#12 (gn-fetch-content 영구화)**: claim 거짓 — 실제 위치 `scripts/gn-fetch-content.py <topic_id>` (positional), 결과는 `(title, content, source)` tuple (245차 확인)
- **#16 (daily cat_id 누설 cleanup)**: ✅ 영구화 완료 (`scripts/cleanup_daily_cat_id_leak.py`), **54회 연속 all-green** (213~267차)
- **#15 (state.details drift health check)**: 신규, 알림만 (가짜 publish 가드 깨질 위험)
- **#17 (post_publish_sync 영구화, 241차)**: ✅ 신규 완료 (`scripts/post_publish_sync.py`) — 매 세션 §3.11 5-1 heredoc 대체
- **#18 (f-string §3.8.1 SyntaxError 트랩, 245차)**: 🆕 식별 — 코드 패치 후보: `scripts/guard_tistory_session_39safe.py` (3.9 호환 문자열 처리) 또는 SKILL.md §3.8.1 템플릿을 모두 `%`-formatting / concatenation 으로 정규화. 246차 본문 코드블록은 정정 완료 (이 README 본문은 245차 수정본).
- **#19 (격리 패턴 PWD/cd 자동 cd 함정, 247차)**: 🆕 식별 (§3.34.43) — `env -i ... bash -c '...'` 호출 시 bashrc 자동 `cd` 가 exit 126 유발. SKILL.md 모든 격리 bash 예시에 `PWD=/Users/mac` 또는 `cd /Users/mac` 보강 완료 (247차). 코드 패치 불필요 (bashrc는 hermes 셸 환경 종속 → SKILL.md 가이드로 충분).
- **#20 (cron 차 사이 last URL drift, 253차 식별 → 254차 실전 검증 완료)**: ✅ **확정** (§3.34.44) — 사전 검증에서 `state.last_published_url` 이 직전 cron 차의 `#985` 으로 박혀있음 (자정 사이 추가 발행된 흔적). **5중 검증 모두 일치 유지되어 drift 무해** 확정. cron 자동화 워크플로에서 "이전 cron 차 사이 한 건 이상이 발행될 수 있다"는 사실 영구화. pt/details 비교시 항상 **현재 시점의 last url** 을 source-of-truth로 사용할 것. 코드 패치 불필요 (§3.5 5중 검증 + §3.11 sync 가 이미 drift-immune).
- **#21 (카테고리 균형 + AI/ML 우선 가이드, 254차)**: 🆕 식별 — 254차에 FRESH 1순위가 개발도구였음 (AI/ML TOP 8개 모두 처리됨). **운영 가이드**: AI/ML 후보가 1개 이상 FRESH이면 무조건 AI/ML 우선. AI/ML FRESH가 0이면 다른 카테고리 발행 허용 (FRESH 4-field 매칭이 가짜 발행 가드이므로 카테고리 혼재 위험 없음). 코드 패치 불필요 (§3.34.40 후보 직접 점수 pick 패턴이 이미 점수 기준 자동 정렬).
- **#22 (#21 경계 조건 + '기타' 제외 정책 우선순위, 256차)**: 🆕 식별 (§3.34.45) — `blog_pipeline.py` §1448~1456 (2026-06-08 영구화) 가 '기타' 카테고리를 발행 대상에서 의도적 제외. #21 가이드는 '기타' 카테고리에 적용되지 않음. **정책 우선순위**: `'기타' 제외 > #21 AI/ML 우선`. FRESH 후보 매트릭스별 결정 가이드 §3.34.45 참조. 256차 실전 1호: FRESH 후보 2개 모두 '기타' (31338 Android 앱→웹페이지 1.0점 / 31359 세그멘테이션 오류 0.5점) → 정상 skip. 코드 패치 불필요 (가짜 발행 가드는 FRESH 4-field 매칭으로 동작, 정책 우선순위 명확화로 충분).
- **#23 (gn-fetch-content URL 형식 stale, 259차 식별 → 260차 실전 검증 → 261차 영구화 완료 ✅)**: ✅ **영구화 완료** — `scripts/gn-fetch-content.py` 의 `GN_MD_URL = GN_TOPIC_BASE + "/{tid}.md"` + `GN_TOPIC_BASE` 정의 순서 정정 (line 48에서 line 49로 이동) + `_try_md_endpoint` docstring 갱신. 261차에 `_try_md_endpoint(31378)` 테스트 → status=200, 9590 bytes 정상 fetch. 1단계 `.md` endpoint가 즉시 성공. 259차/260차 임시 우회 패턴(`requests.get(f"https://news.hada.io/topic/{tid}.md")`)이 더 이상 필요 없음 — cleanup cron 임무 #23 종료.
- **#24 (inline heredoc UTF-8 한글 + f-string 제약 동시 hit, 263차 식별 → 264차 실전 검증 → 265차 두 번째 검증 → 266차 세 번째 검증 ✅)**: 🆕 식별 → ✅ **실전 검증 완료 (3회)** (§3.34.47) — `env -i ... bash -c '... << PYEOF ... PYEOF'` 형태로 길이 30줄+ 본문 빌드/HTML 변환 스크립트를 inline heredoc에 직접 적으면, §3.34.41 f-string 백슬래시 제약 + 본문 안 `\"` escape + 한글 UTF-8 본문 문자열이 한꺼번에 걸려 `SyntaxError: Non-UTF-8 code starting with '\xec'` 또는 `f-string expression part cannot include a backslash` 가 연쇄 발생. 263차 첫 시도에서 hit → SKILL.md 가이드 추가. **264차 검증**: `#1000` 본문 빌드 (`/tmp/tistory_drafts_264th/build_draft.py`, 99줄) 에 `write_file` + 격리 호출 패턴 실전 적용 → 정상 동작 (md_to_html 본문 2088자 + intro/conclusion 540+1700자 + UTF-8 한글 + f-string 안 백슬래시 quote 모두 무영향). **265차 검증**: `#1002` 본문 빌드 (`/tmp/tistory_drafts_265th/build_draft.py`, 약 90줄) 에 동일 패턴 반복 적용 → 정상 동작 (md_to_html 본문 1979자 + intro 1단락 + conclusion 한국 개발 환경 5가지 적용 단계 + UTF-8 한글 + f-string 안 백슬래시 quote 모두 무영향). **266차 검증**: `#1003` 본문 빌드 (`/tmp/tistory_drafts_266th/build_draft.py`, 5618 bytes) 에 동일 패턴 3회째 적용 → 정상 동작 (md_to_html 본문 890자 + intro 1단락 + conclusion 한국 SI/스타트업 시사점 + UTF-8 한글 + `* ` 들여쓰기 리스트 패턴 + 4단계 헤더 강등 정규식 모두 무영향). **적용 범위**: §3.34.46 본문 빌드 / 다중 카테고리 한도 처리 / 인트로+본문+결론 합치기 등. 단일 probe (가드 / sync / state 확인) 처럼 5~10줄짜리 short heredoc은 §3.34.41 정정 (string concat) 으로 충분. SKILL.md 본문 + "절대 하지 말 것" 박스에 §3.34.47 항목 추가 완료.
- **#25 (`md_to_html` `* ` 들여쓰기 리스트 패턴 + 모듈 import 함정, 266차 식별, 즉시 보완)**: 🆕 식별 — (a) GeekNews 본문이 `- ` 외 `* ` 들여쓰기 패턴을 혼용 (`* 완전한 감사 추적(Audit Trail)`) — 262차 정착 `md_to_html` 은 `- ` 만 처리하여 `* ` 라인이 `<p>` 로 떨어짐 → `elif stripped.startswith("* ") and not stripped.startswith("**"):` 분기 추가하여 `<ul><li>` 변환 보강. (b) `import tistory_publisher; tistory_publisher.publish(...)` 시도 → `AttributeError: module 'tistory_publisher' has no attribute 'publish'` (모듈에 `publish` 함수 부재, **CLI 인터페이스만 지원**). 회피: `subprocess` 로 `python3 /Users/mac/.hermes/scripts/tistory_publisher.py --title ... --file ...` 호출하거나 `terminal` + 격리 bash 패턴 (§3.34.40 4단계 패턴 4번 항목 그대로). 코드 패치 불필요 — 가이드 추가만으로 충분. SKILL.md 본문 + "절대 하지 말 것" 박스에 §3.34.48 + 모듈 import 함정 항목 추가 완료.
- **#26 (cleanup cron 임무 #16 56회 연속 all-green + §3.34 #21 정책 실전 4호, 269차 검증 완료)**: 🆕 식별 — 269차에 FRESH 후보 단독 (개발도구 `31417` 4점 단일) 케이스에서 §3.34 #21 정책 + §3.34.45 매트릭스 5번째 분기 정상 동작 확인. cleanup cron 임무 #16 `cleanup_daily_cat_id_leak.py` dry-run 55→56회 연속 all-green 유지. Picsum ID 449 자동 매칭 (rust crates.io source code viewer query) — 두 슬롯 모두 동일 ID 자동 매칭, 첫 시도 적중. 코드 패치 불필요 — §3.34 #21 정책 + §3.34.45 매트릭스 가이드 그대로 유효. 차감/추가 없음.

## 절대 하지 말 것

- ❌ 통계 +1 후 실제 Tistory 글 없이 종료 (가짜 발행 버그 원인)
- ❌ 세션 만료 시 publish 단계 진행 (가짜 발행 누적)
- ❌ 중복 topic skip 후에도 publish (통계 오염 방지)
- ❌ publish 후 details/last/stats 미갱신 (191차 §8.5.2 무효화 환경 의존) → `scripts/post_publish_sync.py` 호출 필수
- ❌ §3.5 drift 감지 후 publish 진행 (drift 상태로 publish하면 stats +1되지만 pt/state sync 안 됨)
- ❌ hermes venv python3 호출 (urllib3 2.6.x 비호환) → §3.8.2 격리 패턴 사용 (244차: bash -c 안에서 source 후 python 상속)
- ❌ frontmatter 포함된 draft.md 직접 publish (300자 미만으로 검증 실패) → `scripts/strip-frontmatter.py` 선처리
- ❌ **cron에서 `blog_pipeline.py --category '<cat>'` 단독 호출로 publish 후보 pick** (§3.34.39) — 점수 무관 순환 pick 위험. 후보 직접 점수 정렬 후 `record_published_topic` 또는 `commit_publish` 명시 호출. **244차 보완**: `--refresh-topics --dry-run` JSON 직접 점수 정렬 + FRESH 4-field 명시 매칭 패턴.
- ❌ **cron에서 `--force-topic <id>` 단독으로 publish** (§3.34.39) — source_url/topic_url 미주입. tistory_publisher.py 가 draft 본문 + url 인자 필요.
- ❌ **`post_publish_sync.py sync-from-pt`의 `state_updated: true` 를 그대로 신뢰** — 코드 state 경로(`~/.hermes/state/tistory_state.json`)가 부재하여 noop. 진짜 drift 보정은 heredoc으로 직접 통합 state 파일 갱신.
- ❌ **`execute_code` cron 호출** (244차) — `BLOCKED: ... bypass shell-string approval checks` 거부. → `terminal`+heredoc 또는 `write_file` 후 `tistory_publisher.py --file` 호출.
- ❌ **state.json에서 `state['published_topics']['last'].url` lookup** (§3.34.40, 244차 정정) — 그 키는 부재. 진짜 pt source-of-truth는 `~/.hermes/memory/published_topics.json` 별도 파일. §3.5 5중 신호 검증 스니펫은 위 박스 참조.
- ❌ **`/usr/bin/python3` heredoc 안에서 f-string에 백슬래시 quote 사용** (§3.34.41, 245차) — `SyntaxError: f-string expression part cannot include a backslash`. §3.8.2 격리 패턴의 python3는 항상 Python 3.9. `headers.get(\"content-type\",\"\")[:50]` 같은 패턴은 100% SyntaxError. → string concatenation 또는 변수 추출 후 f-string 외부 사용. 본문 §3.8.1 가드 heredoc은 245차 수정본이 표준.
- ❌ **`/usr/bin/python3` inline heredoc 안에 30줄이 넘어가는 본문 빌드/HTML 변환 스크립트 작성** (§3.34.47, 263차 신규) — `f"... {var.split(\" \",1)[1]} ..."` 같은 §3.34.41 패턴 + `\"` escape + 한글 UTF-8 본문 문자열이 한 heredoc 안에 동시 등장하면 `SyntaxError: Non-UTF-8 code starting with '\xec'` 가 먼저 터지거나 f-string SyntaxError가 연쇄 발생. 263차 첫 시도에서 hit (md_to_html 본문 빌드 + intro/conclusion 합치기). → `write_file` 로 `/tmp/<session>/build_draft.py` 에 `# -*- coding: utf-8 -*-` 선언과 함께 저장 후 `python3 <script>.py` 격리 호출. 단일 probe (가드 / sync / state 확인) 처럼 5~10줄짜리 short heredoc은 §3.34.41 정정 (string concat) 으로 충분.
- ❌ **`env -i HOME=... PATH=... /bin/bash -c '...'` 호출 시 `cd /Users/mac` 또는 `PWD=/Users/mac` 누락** (§3.34.43, 247차) — bashrc 자동 `cd` 로 exit 126. §3.8.1 가드/§3.11 sync/§3.34.42 verify 등 모든 격리 bash 호출에 영향.
- ❌ **`scripts/gn-fetch-content.py` 의 stale `GN_MD_URL` 우회 패턴 작성** (§3.34.46, 259차 식별 → 261차 영구화 완료 ✅) — 더 이상 `requests.get("https://news.hada.io/topic/{tid}.md")` 임시 우회 heredoc 작성 불필요. cleanup cron 임무 #23 영구화 완료: `_try_md_endpoint(tid)` 또는 `fetch_gn_content(tid)` public API 직접 호출 (위 §3.34.46 박스 코드 참조).
- ❌ **GeekNews 마크다운 원본 그대로 Tistory publish** (260차 정착) — Tistory는 markdown 미지원. §3.34.46 박스의 HTML 변환 패턴(헤더/리스트/bold 4종) + editorial 인트로/결론 추가 필수. 300자 가드 통과 못함.
- ❌ **들여쓬 sub-list를 nested `<ul>` 로 변환** (262차 식별) — GeekNews의 indented sub-list는 마크다운 의미상 모두 형제 bullet, 시각적 깊이일 뿐. nested ul_stack 패턴은 매 항목마다 `<ul>` 가 열리고 즉시 닫혀 리스트 미형성. → indent 무시하고 모든 `- ` 를 top-level bullet 로 취급, 연속된 `- ` 라인을 하나의 `<ul>...</ul>` 로 묶고 빈 줄에서만 close.
- ❌ **`- ## 헤더` 위장 항목을 `<li>` 로 변환** (262차 식별) — GeekNews 본문에 `- ## 기존 모델의 호출 방식에 맞춰진 제약` 같은 list-prefixed header 가 나옴. `<li>` 로 변환되면 의미 파괴. → `- ` 변환 직전 item_text가 `## `/`### ` 로 시작하면 `<h2>`/`<h3>` 로 라우팅.
- ❌ **`* ` 들여쓰기 리스트를 `<p>` 로 변환** (§3.34.48, 266차 식별) — GeekNews 본문 (특히 gn=31432 Papermake) 이 `- ` 외 `* ` 들여쓰기 패턴을 혼용 (`* 완전한 감사 추적(Audit Trail)`). 262차 정착 `md_to_html` 은 `- ` 만 처리하여 `* ` 라인이 그냥 `<p>` 로 떨어져 들여쓴 sub-list가 시각적으로 평평한 본문으로 변환됨. → `md_to_html` 에 `elif stripped.startswith("* ") and not stripped.startswith("**"):` 분기 추가 (bold `**` 시작은 제외). 266차 첫 빌드에서 hit → 즉시 분기 추가하여 해결. **적용 범위**: §3.34.46 본문 빌드의 모든 변형.
- ❌ **`import tistory_publisher; tistory_publisher.publish(...)` 모듈 함수 호출** (266차 식별) — `AttributeError: module 'tistory_publisher' has no attribute 'publish'` (모듈에 `publish` 함수 부재, **CLI 인터페이스만 지원**). → `subprocess` 로 `python3 /Users/mac/.hermes/scripts/tistory_publisher.py --title ... --file ...` 호출하거나 `terminal` + 격리 bash 패턴 (§3.34.40 4단계 패턴 4번 항목 그대로).
