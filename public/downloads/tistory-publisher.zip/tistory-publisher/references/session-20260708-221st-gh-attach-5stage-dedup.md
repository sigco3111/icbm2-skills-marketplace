# 221차 (2026-07-08) — gh-attach — CLI로 GitHub 이슈/PR에 이미지, 파일 첨부하기

## 작업 타임라인

1. **§3.8.1 3-endpoint probe**: ✅ 200 OK (Tistory max=933 시작)
2. **§3.30.4 0단계 state health check**: ✅ drift 0 (Tistory=933, state=933, details=933)
3. **feeds.feedburner.com RSS fetch**: 50 entries (Atom), 20개 토픽 추출
4. **§3.34.11 5단계 dedup cron 직접 실행**:
   - 박힌 gn_topic_id: [31218, 31221, 31224, 31225] (218~220차 누적 4건)
   - 4건 skip (모두 GN_TOPIC_ID 매칭)
   - 16건 fresh
5. **`blog_pipeline.py --refresh-topics`**: 12개 긱뉴스 토픽 (그러나 stale - 이미 발행된 #31225/31224/31221/31218을 fresh로 표시, §3.34.18.5 stale fresh=true 함정)
6. **`blog_pipeline.py --category 'AI/ML'`**: #31218 Ternlight를 stale fresh=true로 반환 → §3.34.18.5 함정 확인
7. **cron 5단계 dedup 결과로 1순위 선택**: #31216 gh-attach (5.0점, 개발도구 카테고리)
8. **긱뉴스 `.md` endpoint**: 200 OK / 2,052 bytes (31216)
9. **§3.23.1 frontmatter strip**: 2,052 → 본문 1,287자
10. **heredoc 한국어 본문 작성**: 1,414자 (POSTEOF single-quoted, §3.34.1 `--file` 옵션)
11. **tistory_publisher.py --file 옵션 발행**: ✅ publish #934 (validate_content 1,287자, Picsum 2장 자동 삽입, OG 썸네일 설정)
12. **§3.11 5단계 stats 보정**:
    - Tistory API category='자동화&툴 리뷰' (1219748)
    - normalize_cat_key('자동화&툴 리뷰') = '자동화&툴 리뷰' (함정 — 매핑 누락)
    - §3.32.2 alias_map 보강: '자동화&툴 리뷰' → '개발도구' 수동 매핑
    - by_category['자동화&툴 리뷰']: 0→1 (1건) → '개발도구': 133→134 (이관)
    - daily_counts['2026-07-08']['자동화&툴 리뷰']: 0→1 → '개발도구': 1→2
    - total: 933→934
13. **§3.34.13 details에 gn_topic_id 박기**: #934 with gn_topic_id=31216 (누적 5건)
14. **§3.34.3 last_topics 정리**: 0건 (Tistory URL 항목 제거)
15. **§3.33.1 §3.32.1 cleanup**:
    - DB schema dump: status='상태', url='URL' (한글 — §3.33.3 4회째 검증)
    - 전체 query: 2,114 페이지 (220차 2,102에서 +12)
    - 31216 URL 매칭: 18건 (활성 1 + 비활성 17)
    - PATCH 1/1 → 비활성화 ✅
16. **§3.5 3중 신호 검증**: ✅ drift 0 (시작 933=933=933, 종료 934=934=934)

## §3.34.18.5 stale fresh=true 함정 실전 재확인

221차에 `blog_pipeline.py --category 'AI/ML'` 실행 시:
- #31218 Ternlight (gn_topic_id=31218, 이미 details 박힘) → **stale fresh=true 반환**
- #31224 30 Papers (gn_topic_id=31224, 이미 details 박힘) → stale fresh=true
- #31225 루프 시작하기 (gn_topic_id=31225, 이미 details 박힘) → stale fresh=true
- #31221 Google 데이터센터 (gn_topic_id=31221, 이미 details 박힘) → stale fresh=true

**blog_pipeline.py는 details의 gn_topic_id를 보지 않고 Notion DB의 활성 페이지만 확인** → 두 진실 공급원이 분리되어 stale 판정. cron이 feeds.feedburner.com RSS + 5단계 dedup으로 정정하여 정상 skip.

## normalize_cat_key() alias_map 신규 발견 (221차)

**§3.32.2 매핑 표에 `'자동화&툴 리뷰' (1219748) → '개발도구'` 추가 필요**:

```python
# 현재 normalize_cat_key.py alias_map 확인 필요
# alias_map = {
#     'AI 뉴스': 'AI/ML',
#     '투자&경제': '투자/경제',
#     # '자동화&툴 리뷰': '개발도구',  ← 221차 발견, alias_map 보강 필요
# }
```

**영구화 권장**:
1. `scripts/normalize_cat_key.py`에 `'자동화&툴 리뷰' → '개발도구'` alias_map 추가
2. 221차에 stats 보정 단계에서 수동 매핑 (alias_map 미보강 임시 처리)

## by_category 변형 키 누적 (221차 추가)

220차 §3.34.18.3 발견 3쌍 + 221차 1쌍 추가:
- `'AI 뉴스': 1` ↔ `'AI/ML': 719` (220차)
- `'개발': 1` ↔ `'개발도구': 134` (220차)
- `'개발팁': 12` ↔ `'개발 팁': 13` (220차)
- **`'자동화&툴 리뷰': 0` ↔ `'개발도구': 134` (221차 신규)** ← alias_map 보강 필요

**영구화**: `scripts/normalize_cat_key.py --merge` 1회 cleanup + alias_map에 `'자동화&툴 리뷰'` 추가 + `'개발'` → `'개발도구'` 단어 경계 매핑 추가.

## Notion cleanup 9회 연속 통과 (213~221차)

| 차수 | cleanup 결과 | 페이지 수 | URL 매칭 | PATCH |
|---|---|---|---|---|
| 213차 | (drift 복구로 cleanup skip) | - | - | - |
| 214차 | §3.31.1 89 PATCH (광범위) | 1,934 | (전체 cleanup) | 89 |
| 215차 | §3.32.1 1/18 | 1,925 | 18 (활성 1) | 1 |
| 216차 | §3.33.1 1/1 | 1,944 | 1 (활성) | 1 |
| 217차 | §3.33.1 1/12 | 2,030 | 12 (활성 1) | 1 |
| 218차 | §3.33.1 1/2 | 2,078 | 2 (활성 1) | 1 |
| 219차 | §3.33.1 1/3 | 2,090 | 3 (활성 1) | 1 |
| 220차 | §3.33.1 1/4 | 2,102 | 4 (활성 1) | 1 |
| **221차** | **§3.33.1 1/18** | **2,114** | **18 (활성 1)** | **1** |

## gn_topic_id 박기 누적 (5건)

- 218차: #930 (gn_topic_id=31218), #931 (gn_topic_id=31225)
- 219차: #932 (gn_topic_id=31221)
- 220차: #933 (gn_topic_id=31224)
- **221차: #934 (gn_topic_id=31216)** ← 신규
- 잔여 누락 9건 (#921~929) → `scripts/retroactive-gn-topic-id.py` 1회 cleanup 임무

## §3.33.3 Blog DB ID grep 동적 추출 4회째 검증

221차에 `34276f2e-9097-811e-ab69-f8759ecf0be7` 정상 추출. **216차 / 218차 / 219차 / 221차 연속 4회 영구화 검증**.

## 영구화 all-green (221차)

| 패턴 | 차수 | 221차 결과 |
|---|---|---|
| §3.8.1 3-endpoint probe | 196차 | ✅ 200 OK |
| §3.30.4 0단계 state health check | 213차 | ✅ drift 0 (시작: 933=933=933) |
| §3.34.10 feeds.feedburner.com RSS | 218차 | ✅ 50 entries |
| §3.34.11 5단계 dedup cron 직접 | 218차 | ✅ 4건 skip (모두 GN_TOPIC_ID 매칭), 16건 fresh |
| §3.34.18.5 stale fresh=true 함정 | 220차 | ⚠️ blog_pipeline.py --category가 stale fresh 반환, cron이 정정 |
| §3.29.4 긱뉴스 `.md` endpoint | 212차 | ✅ 2,052 bytes (31216) |
| §3.34.1 `tistory_publisher.py --file` 옵션 | 217차 | ✅ 1,414자 heredoc 파일 발행 성공 |
| §3.32.2 cat_key 정규화 | 215차 | ⚠️ alias_map에 '자동화&툴 리뷰' 누락 발견 (수동 매핑 처리) |
| §3.11 5단계 + §4 5-1 stats 보정 | 200차 | ✅ by_category['개발도구'] 133→134 (alias_map 보강 후) |
| §3.34.13 details에 gn_topic_id 박기 | 218차 | ✅ #934에 gn_topic_id=31216 (누적 5건) |
| §3.34.3 last_topics 0개 정리 | 217차 | ✅ 0건 |
| §3.33.1 §3.32.1 cleanup | 216차 | ✅ 2,114 페이지 / 31216 매칭 18건 / PATCH 1/1 |
| §3.33.3 Blog DB ID grep 동적 추출 | 216차 | ✅ 정상 추출 (4회째) |
| §3.5 3중 신호 검증 | 195차 | ✅ drift 0 (종료: 934=934=934) |

**누적 영구화 all-green 통과**: 213차~221차 **연속 9회** (drift 0 시작/종료 + cleanup + stats 보정 풀 사이클 안정화).

## 핵심 교훈

1. **§3.34.18.5 stale fresh=true 함정 실전 재확인**: `blog_pipeline.py --category 'AI/ML'`이 4건의 이미 발행된 gn_topic_id를 stale fresh=true로 반환. **영구화 강화**: `scripts/5stage-dedup-cron.py` 신규 + `blog_pipeline.py --category` 자체에 5단계 dedup 통합.
2. **§3.32.2 alias_map 누락 — '자동화&툴 리뷰' (1219748)**: 221차에 stats 보정 시 alias_map 미보강 → normalize_cat_key가 그대로 반환 → 수동으로 '개발도구'로 매핑. **영구화**: `scripts/normalize_cat_key.py` alias_map에 `'자동화&툴 리뷰' → '개발도구'` 추가.
3. **gn_topic_id 박기 누적 5건 (#930~#934)**: 5단계 dedup이 정확히 작동하는 핵심. 221차에 4건 skip 모두 GN_TOPIC_ID 매칭으로 정상 처리.
4. **cleanup 9회 연속 통과 (213~221차)**: 풀 사이클 안정화 단계 정착. cleanup heredoc이 silent fail 없이 정상 작동.
5. **§3.33.3 Blog DB ID grep 4회째 영구화 검증**: 216차/218차/219차/221차 연속 정상 작동.
6. **publish #934 정상 발행**: "gh-attach — CLI로 GitHub 이슈/PR에 이미지, 파일 첨부하기" (1,287자, Picsum 2장, OG 썸네일 자동 설정).
