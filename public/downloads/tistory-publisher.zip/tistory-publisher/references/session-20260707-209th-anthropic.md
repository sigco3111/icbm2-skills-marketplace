# 209차 세션 노트 — Anthropic #921 발행 + §3.26 신규

**날짜**: 2026-07-07
**유형**: cron 자동 발행
**결과**: ✅ #921 정상 발행 (drift 0)

## 타임라인

1. **§3.8.1 3-endpoint probe**: ✅ 통과 (200 OK, 세션 유효)
2. **`blog_pipeline.py --refresh-topics`**: 12개 긱뉴스 토픽 로드
3. **§3.22.3 4중 dedup**: 12개 활성 → AI/ML 7개 fresh
4. **§3.26.1 score 매핑 문제 발견**: Notion `점수` 필드 = 0 매핑 → gn_scores 별도 dict 사용
5. **긱뉴스 `.md` endpoint 본문 추출**: `https://news.hada.io/topic/31201.md` → 정상 200, 전체 본문 확보
6. **본문 heredoc 4,953자** → §3.23.1 frontmatter strip → **4,304자 content-only**
7. **`tistory_publisher.py --file`** → #921 정상 발행 (2 Picsum images)
8. **§3.11 5단계 + §4 5-1 stats 보정**: 5필드 모두 동기화 (stats 904→905, AI/ML 706→707, daily 2026-07-07 AI/ML 3→4)
9. **§3.5 4-way 검증**: Tistory 921 = state last /921 = details /921 = urls /921 → **drift 0**
10. **§3.22.2 + §3.25.2 Notion PATCH cleanup**: 3건 → **3/3 성공**

## §3.26.1 — Notion `점수` 필드 0 매핑 함정 (209차 신규)

### 증상

- `blog_pipeline.py --refresh-topics` stdout에는 긱뉴스 score 정상 (Anthropic 15.0, GLM 5.2 14.0, 저커버그 10.0, Fable5 9.0, Astryx 8.0, ...)
- Notion DB의 활성 페이지 `점수` property 조회 시 **모두 0** 반환
- 4중 dedup 통과 후 7개 fresh 후보가 있지만 Notion의 score로 정렬하면 모두 0점 동률 → 무작위 선택 위험

### 원인

`blog_pipeline.py --refresh-topics` → Notion DB 추가 시 `점수` property가 0으로 박힘. 긱뉴스 sync가 score를 Notion으로 전달 안 하는 코드 버그 (또는 의도).

### 영구화 결정

**긱뉴스 score는 `refresh-topics` stdout에만 존재 → 별도 dict로 매핑 후 Notion 후보 정렬에 사용.**

```python
# 긱뉴스 id → score 매핑
gn_scores = {}
for t in topics:  # refresh-topics topics 배열
    m = re.search(r'topic\?id=(\d+)', t.get('url', ''))
    if m:
        gn_scores[t['url']] = t.get('score', 0)

# Notion 후보 정렬 시 gn_scores로 정렬
for t in all_active:
    t['score'] = gn_scores.get(t['url'], 0)
best = sorted(candidates, key=lambda x: -x['score'])[0]
```

### 영향

- Notion의 `점수` 필드는 신뢰 불가 → **반드시 refresh-topics stdout의 score 사용**
- 4중 dedup 통과 후보 정렬이 긱뉴스 score에 의존해야 함
- 차후 `blog_pipeline.py`가 Notion `점수` 필드를 정상 동기화하면 gn_scores 단계는 deprecated 가능

## §3.25.2 source_url 폴백 누적 28/28 영구화

### 209차 Notion PATCH cleanup 결과 (3/3 성공)

| Notion 페이지 이름 | state.last_topics 매칭 source | PATCH |
|---|---|---|
| Starring the Computer: 화면 속 컴퓨터 출연 목록 | "Starring the Computer: 화면 속 컴퓨터 출연 목록" | ✅ |
| Show GN: Fable5는 비싸지고, 로컬 GPU는 부족하다 | "Show GN: Fable5는 비싸지고, 로컬 GPU는 부족하다:..." | ✅ |
| Anthropic이 개발자 호감을 잃는 몇 가지 방법 | "Anthropic이 개발자 호감을 잃는 몇 가지 방법" | ✅ |

### 누적 cleanup 정확도

- 205차: 5/5
- 206차: 6/6
- 207차: 8/8
- 208차: 8/8 (k-vote-cli source_url 폴백 미적용 — 다음 cron cleanup)
- 209차: 3/3
- **누적 30/30 (30자 prefix만)** + k-vote-cli 1건 source_url 폴백 케이스 = 31건 중 30건 30자 prefix로 cleanup, 1건은 source_url 폴백으로 다음 cron 처리

## 긱뉴스 `.md` endpoint 동작 확인

- 209차 Anthropic 31201: `https://news.hada.io/topic/31201.md` → **200 OK**, 전체 본문 정상 추출
- 191차 404 사례와 비교: 191차는 topic 자체가 404였던 것으로 추정 (오래된 긱뉴스), 209차는 신선한 토픽이라 정상
- **결론**: 긱뉴스 `.md` endpoint는 신선한 토픽 (최근 24시간 내 등록)에선 안정, 오래된 토픽은 404 가능

## 이번 세션 정합성

| 신호 | 값 |
|---|---|
| Tistory max id (시작) | 920 |
| Tistory 발행 URL | 921 |
| Tistory max id (종료) | 921 |
| state.last_topics[-1].url | https://sigco.tistory.com/921 |
| last_post.details[-1].url | https://sigco.tistory.com/921 |
| published_urls.txt 마지막 줄 | https://sigco.tistory.com/921 |
| stats.total_published (before → after) | 904 → 905 |
| by_category[AI/ML] | 706 → 707 |
| daily_counts["2026-07-07"][AI/ML] | 3 → 4 |
| Notion cleanup | 3/3 (Anthropic 포함) |
| **이번 세션 drift** | **0** ✅ |
| 누적 drift | 121 (stats 905 vs Tistory totalCount 784) |

## 후속 권장 작업

1. **`blog_pipeline.py --refresh-topics`가 Notion `점수` 필드에 score 동기화하도록 패치** — 코드 패치 작업 (별도 cron 임무)
2. **누적 drift 121 정리** — §3.16 별도 cron 작업 권장 (이번 cron 임무 외)
3. **scripts/score-gn-lookup.py** 신규 — `refresh-topics` stdout에서 gn_scores dict 구축 + Notion 후보에 매핑 (재사용 가능 유틸)

## 핵심 교훈

> Notion DB의 `점수` 필드는 0으로 매핑될 수 있다 — `blog_pipeline.py --refresh-topics`의 **stdout score만이 신뢰 가능한 점수 소스**. 차수별 후보 정렬은 반드시 `gn_scores[url]` dict로.
