# Recognized Quality Gate False Positive Patterns

Quality gate's time freshness check (`20\d{2}` detection) frequently fires on legitimate content. When `decision == "rewrite"` with `grade == "B"`, these are known false positives — proceed with publishing instead of retrying.

## Pattern 1: Historical Benchmark Context
- **Trigger:** Old benchmark years (2019, 1959, etc.) cited as reference points within a 2026 study
- **Example:** "벤치마크 코퍼스 2019년创设...LMBench 1959년..." inside a 2026-05-18 article
- **Why false positive:** Genuine academic citation of historical benchmarks is normal; the article's publish date is 2026
- **Proceed if:**
  1. Article topic selected by blog_pipeline (source is 2026 GeekNews)
  2. Past years are in "benchmark/corpora/database" citation context
  3. No "최신", "완벽가이드", "2026" in title

## Pattern 2: Historical/Retrospective Timeline Articles
- **Trigger:** Article body covers 2022–2025 event timeline as its main subject
- **Example:** "AI 슬롭의 현황: 수치로 본 충격" with tables of 2022-2025 data
- **Why false positive:** The subject IS the historical data; dates are factual, not "old information dressed as new"
- **Proceed if:**
  1. Blog_pipeline selected topic, source URL posted in 2026
  2. Past dates are the topic's core content (timeline/historical section)
  3. No "최신 정보 업데이트" claim

## Pattern 3: Historical Web/Technology Metaphors
- **Trigger:** "Internet Explorer 시절", "2000년대", "IE/Netscape 시대" used as analogies
- **Example:** "과거 IE 시절의”问题이 다시 반복되고 있다" in a 2026 browser article
- **Why false positive:** Explicitly historical analogy, not present-tense claims
- **Proceed if:**
  1. Title/body mentions 2026 publication or latest developments
  2. Past years are clearly in analogy/context (" 시절", "세대", "시대")
  3. No "최신", "완벽가이드", "2026" in title

## Pattern 4: Tool Feature Descriptions
- **Trigger:** "2024년 이전에 공개된 모델", "2023년 Benchmark" in a tool's feature description
- **Example:** `whichllm` article — model comparison section describing recency-aware feature, mentions 2023/2024 model history
- **Why false positive:** The dates describe the tool's evaluation criteria, not the article's freshness
- **Proceed if:**
  1. Tool's core feature explanation requires referencing past model history
  2. No "최신 완벽가이드" in title
  3. Blog pipeline selected topic (source is 2026)

## Pattern 5: Company/Startup Factual History in News Articles (2026-05-20 cron)
- **Trigger:** "2022년 설립", "2024년 12월 valuation" referenced as factual background in a current news article
- **Example:** Stainless 인수 article — "2022년 설립된 Stainless", "2024년 12월 1억 5천만 달러 →短短 5개월 만에 3억 달러" — factual historical data, not stale content
- **Why false positive:** Company founding year and valuation history are legitimate factual context; article dated May 18, 2026
- **Proceed if:**
  1. Blog pipeline selected topic (source is 2026 GeekNews)
  2. Past dates describe company/institution history as factual background (설립, 투자 라운드, valuation, 인물 이력)
  3. Title has no "최신", "완벽가이드", "2026" hype
  4. Article publish date is 2026

## Decision Flowchart

```
quality_gate output: grade + decision
        │
        ▼
decision == "retry_with_new_topic"? → YES → stop, new topic
        │
       NO
        │
        ▼
decision == "rewrite" AND grade == "B"?
        │
       YES → Check false positive patterns above
             Match any pattern? → PROCEED to Step 7
             No match? → stop, rewrite
        │
       NO
        │
        ▼
grade >= 60? → YES → PROCEED to Step 7
        │
       NO → stop
```

## Verification Checklist Before Proceeding on False Positive

Before overriding a "rewrite" decision, confirm ALL of:
- [ ] `blog_pipeline` selected this topic (source is 2026 GeekNews/trend)
- [ ] Title has no "최신", "완벽가이드", "2026" hype
- [ ] Past years are in: benchmark citation, historical timeline, analogy, company history, or tool-feature-description context
- [ ] Content is genuinely about the 2026-present topic (not stale content)
