# 196차 세션 노트 (2026-07-02T19:00, cron 자동)

## 결과: ⏸️ 발행 skip — §3.8.1 Zombie 302 (세션 만료)

## 배경
- 195차 후 약 13시간 경과
- 대상 주제: "LongCat-2.0 공개 — Nvidia 없이 학습한 1.6조 파라미터 오픈소스 모델" (긱뉴스 #31019)
- §3.11 5단계 + §4 5-1 stats 보정 매번 실행 패턴이 3회째(193차+194차+195차) 영구화된 상태
- 195차 마지막 정상 발행: #903 (EU 디지털 ID 지갑)

## 1단계: `blog_pipeline.py` topic 선정
- JSON 출력:
  - status: "ready"
  - category: "AI/ML"
  - topic: "LongCat-2.0 공개 - Nvidia 없이 학습한 1.6조 파라미터 오픈소스 모델"
  - source_url: "https://news.hada.io/topic?id=31019"
  - timeliness_check.is_fresh: true

## 2단계: 중복 판정
- `published_topics.json` details 최근 30건 중 "LongCat" 검색 → 0건 → **신규 주제 확인**
- last = #903 (195차 EU 디지털 ID 지갑) → 발행 진행 결정

## 3단계: 긱뉴스 본문 fetch (195차 §8.10.2 패턴)
- 결과: **HTTP 200 | 23969 bytes** → `.md` endpoint 정상 (195차 200과 일치, 191차/194차 404와 교대 패턴)
- 긱뉴스 본문 23,969자, 깨끗한 markdown (메타데이터 + topic body 포함)

## 4단계: 본문 작성
- 3,765자 / H2 8개 / 1회 컷 정형화 (181차 §1 패턴, 7KB README 1,500~1,700자 + 7KB raw fetch case)
- 카테고리: AI/ML (ID 1219746)
- 196차 신규 주제: LongCat-2.0, LSA(Light Sparse Attention), AI ASIC 슈퍼팟 학습, Claude Code/OpenClaw/Hermes 통합

## 5단계: 발행 시도
- ✅ Content 검증 통과 (3,433자)
- ✅ Picsum 이미지 검색 성공 2장
- ❌ CDN 업로드 0/2 (인증 필요)
- ❌ `POST /manage/post.json` → `❌ 발행 오류: Expecting value: line 2 column 2 (char 2)`
- ❌ 발행 실패

## 6단계: §3.8 vs §3.8.1 구분 진단 (3-endpoint probe)

### 6.1 §3.8 진단 oneliner (195차 패턴)
- 결과: `EXPIRED` + status=200 + content-type=text/html
- §3.8 (200 HTML) 패턴으로 보임 — **그런데 더 정밀 진단이 필요**

### 6.2 §3.8.1 3-endpoint probe (196차 확립, `allow_redirects=False` 필수)

**결과**:
```
❌ EXPIRED-302 | GET /manage/posts.json (글 목록): HTTP 302 | ct= | loc=https://www.tistory.com/auth/login?redirectUrl=https%3A%2F%2
❌ EXPIRED-302 | GET /manage/category.json (카테고리): HTTP 302 | ct= | loc=https://www.tistory.com/auth/login?redirectUrl=https%3A%2F%2
✅ OK | GET / (블로그 홈): HTTP 200 | ct=text/html;charset=UTF-8 | loc=
```

→ **§3.8.1 Zombie 302 확립** — manage API 2개가 모두 login redirect, 블로그 홈은 정상 (공개 페이지)

### 6.3 §3.8.1의 핵심 차이 (vs §3.8)
- §3.8: HTTP 200 + HTML 응답 (Tistory가 권한 없는 페이지 반환, 쿠키 일부/전부 누락 케이스)
- §3.8.1: **HTTP 302 + Location: /auth/login** (Tistory가 세션 invalid로 login redirect, 쿠키는 env에 존재하지만 만료)

### 6.4 쿠키 길이 검증 (단순)
- `REACTION_GUEST`: 길이=1 (fallback)
- `__T_`: 길이=1 (fallback)
- `__T_SECURE`: 길이=1 (fallback)
- `TSSESSION`: 길이=40
- `_T_ANO`: 길이=344

→ **5종 모두 값 존재, 길이 정상** — 단순 길이 검증으로는 만료 판정 불가

### 6.5 env 갱신 일자
- `~/.hermes/secrets/tistory.env` 최종 갱신: 2026-06-29 (184차)
- 196차 시점: 2026-07-02
- 경과: **3일** → Tistory 세션이 만료된 시점

## 7단계: §3.11 5단계 skip (196차 신규)

세션 만료 시 §3.11 5단계는 실행할 필요 없음:
- 1단계 HTTP fetch: skip (Tistory 글 없음)
- 2단계 published_urls.txt append: **skip 안 함** (이 단계는 발행과 무관)
- 3단계 blog_pipeline --record 3-arg: **skip** (Tistory URL 없음)
- 4단계 pt last+details append: **skip** (Tistory URL 없음)
- 5단계 §3.5 3중 신호 검증: **실행** (가짜 발행 여부만 확인)

## 8단계: §3.5 3중 신호 검증 (가짜 발행 0건 확인)
- (a) details[-1].url: #903 (195차 정상)
- (b) last.url: #903 (195차 정상)
- (c) stats today AI/ML: 11 (195차 정상)
- (d) stats total: 885 (195차 정상)
- (e) last.topic: EU 디지털 ID 지갑 (195차 정상)
- sigco URL 라인 수: 355 (195차와 동일)

→ **모두 195차 정상 발행 값 그대로** → 가짜 발행 0건 확인

## 자동화 안전도 (196차 종료 시점)

| 지표 | 값 |
|---|---|
| 마지막 정상 발행 | #903 (195차, 2026-07-02T06:01) |
| LongCat-2.0 | ⏸️ 보류 (다음 cron — 쿠키 갱신 후) |
| 가짜 발행 누적 | 0건 (3중 신호 검증 통과) |
| 세션 | ❌ 만료 (§3.8.1 Zombie 302) |
| §3.5 3중 신호 | 정상 (변동 없음) |
| §3.11 5단계 | skip (세션 만료 시) |
| 쿠키 env 갱신 일자 | 2026-06-29 (184차, 3일 경과) |

## 신규 발견 (196차) — 3건

### 1. §3.8.1 Zombie 302 패턴 (중대)
- 184차 6/29에 env 갱신한 5종 쿠키가 3일 경과 후 실제 만료
- env에는 5종 모두 값 존재 + 길이 정상
- Tistory 서버가 세션 invalid로 판정 → manage API가 login redirect (302)
- §3.8 (200 HTML) vs §3.8.1 (302 login) — 둘 다 동일 에러지만 만료 메커니즘 다름
- **3-endpoint probe로만 구분 가능** — `allow_redirects=False` 필수

### 2. §3.8.1 진단 oneliner (heredoc + `set -a; source`)
- §3.8 진단은 `python3 -c "..."` one-liner로 충분했음
- §3.8.1은 3-endpoint probe가 필요해 heredoc 패턴 강제
- 196차 확립: `set -a; source ~/.hermes/secrets/tistory.env; set +a` + `python3 << 'PYEOF' ... PYEOF`
- **`allow_redirects=False`가 핵심** — True로 두면 302 응답이 자동으로 따라가서 login 페이지 HTML을 받아버림 → §3.8 (200 HTML)과 구분 불가

### 3. §3.11 5단계 skip 워크플로 (cron 모드)
- 세션 만료 시 §3.11 5단계는 실행할 필요 없음
- 4단계(`blog_pipeline --record` 3-arg)만 실행해도 pt/details 동기화 + Tistory 글 없음 → partial state 발생 위험
- **올바른 패턴**: 3-endpoint probe → EXPIRED-302 → §3.11 5단계 skip → §3.5 3중 신호 검증으로 가짜 발행 0건 확인 → 사용자 알림 → 다음 cron에서 재시도

## §3.8.1 판정 기준 (196차 확정)
| status | Location | 판정 | § |
|---|---|---|---|
| 200 | (없음) + JSON | ✅ 정상 | — |
| 200 | (없음) + HTML manage | ❌ EXPIRED-200 | §3.8 |
| 200 | (없음) + HTML, JS로 login 체크 | ❌ EXPIRED-200-JS | §3.8 (variant) |
| **302** | **`/auth/login`** | **❌ EXPIRED-302** | **§3.8.1 (196차)** |
| 200 | (없음) + HTML 홈 | ✅ 정상 (공개 페이지) | — |

## §3.5 3중 신호 검증 — §3.8.1 skip 케이스 (196차)
| (a) details URL | (b) last URL | (c) stats today | 판정 |
|---|---|---|---|
| 195차 그대로 (#903) | 195차 그대로 (#903) | 195차 그대로 (11) | ✅ 가짜 발행 0건 (단순 skip) |
| 195차와 다름 | 195차와 다름 | 195차와 다름 | ⚠️ 가짜 발행 — §3.11 5단계 + 5-1 보정 필요 |

## 사용자 알림 (희정님)
브라우저에서 sigco.tistory.com 로그인 → DevTools → Application → Cookies → `https://sigco.tistory.com`에서 5개 키(`REACTION_GUEST`, `__T_`, `__T_SECURE`, `TSSESSION`, `_T_ANO`) 값 추출 → `~/.hermes/secrets/tistory.env` 갱신 부탁드립니다. §3.9 절차대로 진행하시면 됩니다.

쿠키 갱신 후 다음 cron에서 LongCat-2.0 주제가 자동 재선정되어 발행됩니다.

## 다음 cron (197차) 이월 TODO
1. `tistory_publisher.py --check` 명령이 §3.8 vs §3.8.1 구분 출력 (현재는 둘 다 동일 에러)
2. §3.8.1 진단 oneliner를 `scripts/diagnose-tistory-session.sh`로 영구화 (196차 heredoc 패턴)
3. §3.11 5단계 skip 워크플로를 `scripts/post-publish-skip-if-expired.sh`로 영구화
4. §3.5 판정 기준에 §3.8.1 skip 케이스 추가 (단순 skip + 변동 없음 = 정상) — SKILL.md §3.5에 표로 추가

## 임시 파일 정리
- ✅ `/tmp/draft_31019.md`, `/tmp/news_31019.md`, `/tmp/news_31019.html`, `/tmp/check.html` 모두 정리 완료
