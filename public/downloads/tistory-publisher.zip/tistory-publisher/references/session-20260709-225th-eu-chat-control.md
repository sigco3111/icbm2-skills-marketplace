# 225차 세션 노트 — EU Chat Control #942 발행 (§3.34.23)

**날짜**: 2026-07-09
**주제**: EU Chat Control 1.0과 2.0 — 임시 예외와 영구 규제의 두 트랙
**Tistory URL**: https://sigco.tistory.com/942
**카테고리**: AI/ML (1219746)
**글자 수**: 2,152자 (validate_content)
**gn_topic_id**: 31231

---

## 1. 작업 타임라인 (225차)

1. **§3.8.1 3-endpoint probe**: ✅ 세션 유효, Tistory max=941 (시작)
2. **§3.30.4 0단계 state health check**: ✅ drift 0 (941=941=941, by_category['AI/ML']=724, total=940)
3. **`blog_pipeline.py --refresh-topics`**: 12개 긱뉴스 토픽 수집
4. **feeds.feedburner.com RSS fetch**: 50 entries (Atom XML namespace)
5. **§3.34.11 5단계 dedup cron 직접 실행** (225차 신규 패턴):
   - 후보 20개 (최신순)
   - 🟢 Fresh 9건: #31242, #31233, #31232, #31231, #31230, #31229, #31226, #31222 + 1건
   - 🛑 Skip 11건: 모두 **GN_TOPIC_ID 매칭** (정확도 100%) — details.gn_topic_id에 박힌 11개
6. **`blog_pipeline.py --category 'AI/ML'` stale fresh=true 4회째 재확인**: #31223 no-mistakes를 fresh=true 반환 (gn_topic_id=31223 details에 이미 박혀있음) → cron 5단계 dedup이 정정
7. **1순위 결정**: #31231 Chat Control 1.0과 2.0 (4,163자 본문, points=1, comments=1) → 카테고리 'AI 뉴스' (Tistory name) → 정규화 key 'AI/ML'
8. **긱뉴스 `.md` endpoint fetch**: ✅ 200 OK, 10,472 bytes
9. **§3.23.1 frontmatter strip**: 10,472 → 4,163자 (원본 body)
10. **한국어 본문 heredoc 작성**: 2,364자 → validate_content 2,152자 (정확)
11. **§3.34.1 `--file` 옵션 발행**: `/tmp/post_chat_control.md` → publish #942
    - Picsum 이미지 2장 자동 삽입 (CDN 업로드 2/2, OG 썸네일 설정)
    - **§3.34.19 source footer 자동 박힘**: 긱뉴스 #31231 출처 링크 본문 하단
12. **§3.11 5단계 + §3.34.13 gn_topic_id 박기 + §4 5-1 stats 보정**:
    - state.last.id: 941 → **942**
    - last_titles: 21개 → 22개
    - details count: 22 → **23** (#942 append, gn_topic_id=31231 박기)
    - by_category['AI/ML']: 724 → **725**
    - daily_counts['2026-07-09']['AI/ML']: 3 → **4**
    - total: 940 → **941**
13. **§3.34.3 last_topics 정리**: 0건 (Tistory URL 항목 없음)
14. **§3.33.1 §3.32.1 cleanup**: 전체 query **2,270 페이지** (224차 2,114에서 +156) / 31231 매칭 0건 / PATCH 0/0 (정상)
15. **§3.5 3중 신호 검증**: ✅ drift 0 (942=942=942)

---

## 2. §3.34.23 신규 발견 — `blog_pipeline.py --category` stale fresh=true 4회째 재확인 (⭐⭐)

### 누적 표 (220→222→224→225)

| 차수 | stale fresh=true 반환된 topic_id | 실제 상태 | cron 5단계 dedup 정정 |
|---|---|---|---|
| 220차 (2026-07-08) | #31218 Ternlight | details.gn_topic_id=31218 박힘 (#930) | ✅ |
| 222차 (2026-07-08) | #31221 Ternlight | details.gn_topic_id=31221 박힘 (#932) | ✅ |
| 224차 (2026-07-09) | #31219 코딩 배우기 | details.gn_topic_id=31219 박힘 (#939) | ✅ |
| **225차 (2026-07-09)** | **#31223 no-mistakes** | **details.gn_topic_id=31223 박힘 (#936)** | **✅** |

### 원인 (225차 재확인)
- `blog_pipeline.py --category 'AI/ML'`은 **Notion DB의 `활성` 상태만** 확인
- `details.gn_topic_id` 매칭 단계가 없어서 이미 발행된 긱뉴스를 fresh=true로 반환
- Notion DB `활성` 필드와 details의 gn_topic_id가 **분리된 진실 공급원**

### 영구화 (225차 시점)
- ✅ **cron이 직접 feeds.feedburner.com RSS fetch + §3.34.11 5단계 dedup 실행**이 우회 패턴으로 안정 작동
- ❌ **blog_pipeline.py 자체에 5단계 dedup 통합은 미해결** (§3.34.18.5 임무 6번)
- 누적 정확도: **4/4 회** cron 정정 성공 (1순위 결정 시 stale 후보 항상 skip)

### 영구화 권장 (다음 cron 작업자용)
1. **`scripts/5stage-dedup-cron.py` 신규** — 재사용 가능한 cron 전용 5단계 dedup (임무 5번)
2. **`scripts/blog_pipeline.py` 보강** — `--category` 옵션에 5단계 dedup 통합 (임무 6번)
3. **`feeds.feedburner.com` RSS + details.gn_topic_id + last_titles 30p 매칭**을 blog_pipeline.py 안에서 실행

---

## 3. 5단계 dedup 225차 실전 패턴 (cron 직접 실행, ⭐⭐)

### 후보 20개 명시적 5단계 매칭 결과

| 후보 topic_id | 긱뉴스 RSS title (30p) | 매칭 단계 | 결과 |
|---|---|---|---|
| #31242 | `TypeScript v7 Released` | (없음) | 🟢 FRESH |
| #31240 | `집에서 직접 DNA 시퀀싱하기` | GN_TOPIC_ID | 🛑 SKIP ✅ |
| #31239 | `Kokoro로 로컬 CPU에서 고품질 TTS 실` | GN_TOPIC_ID | 🛑 SKIP ✅ |
| #31238 | `Trusted Publishing을 패키지 신뢰 신` | GN_TOPIC_ID | 🛑 SKIP ✅ |
| #31233 | `Dua Lipa, 포르투갈에 금서·검열 도서 ` | (없음) | 🟢 FRESH |
| #31232 | `EU, 판매되는 모든 차량에 운전자 모니` | (없음) | 🟢 FRESH |
| #31231 | `Chat Control 1.0과 2.0 설명` | (없음) | 🟢 FRESH (1순위) |
| #31230 | `운동복 반바지 조임끈을 더 잘 묶는 방` | (없음) | 🟢 FRESH |
| #31229 | `98%는 그리 많지 않음` | (없음) | 🟢 FRESH |
| #31228 | `Microsoft, id Software의 idTech 팀 ` | GN_TOPIC_ID | 🛑 SKIP ✅ |
| #31227 | `EU 의회, Chat Control 1차 관문 통과` | GN_TOPIC_ID | 🛑 SKIP ✅ |
| #31226 | `StreetComplete: 작은 퀘스트로 OpenS` | (없음) | 🟢 FRESH |
| #31225 | `루프 시작하기` | GN_TOPIC_ID | 🛑 SKIP ✅ |
| #31224 | `30 Papers - 일리야 서츠케버 추천 A` | GN_TOPIC_ID | 🛑 SKIP ✅ |
| #31223 | `no-mistakes - git push 할 때 실수를 ` | GN_TOPIC_ID (⚠️ stale) | 🛑 SKIP ✅ |
| #31222 | `더 건강한 Clippy를 위한 공동 리뷰 제` | (없음) | 🟢 FRESH |
| #31221 | `Google, 기후를 위협하는 디지털 비대` | GN_TOPIC_ID | 🛑 SKIP ✅ |
| #31220 | `Odin 1.0, ‘Odin 2027’로 2027년 1월 ` | (없음) | 🟢 FRESH |
| #31219 | `코딩 배우기는 여전히 가치 있다` | GN_TOPIC_ID | 🛑 SKIP ✅ |
| #31218 | `Ternlight - 브라우저(WASM)에서 실행` | GN_TOPIC_ID | 🛑 SKIP ✅ |

**정확도: 11/11 = 100%** (모든 skip이 정확한 gn_topic_id 매칭)
**false negative: 0건** (5단계 dedup이 218차 §3.34.11 발견 1건 false negative 패턴을 정상 작동으로 전환)

### 1순위 결정 로직 (225차)
- 후보 9건 fresh 중 body 길이 + 발행 가치로 1순위 결정
- #31231 Chat Control (4,163자, 정책/규제 주제, 7월 9일 의회 표결 시점성)
- AI/ML 카테고리 (정책 + 기술 양쪽 관련)

---

## 4. §3.34.19 source footer 10번째 검증 (225차 영구화)

- 본문 하단에 긱뉴스 #31231 출처 박힘: `**원본 출처**: [긱뉴스 #31231 — Chat Control 1.0과 2.0 설명](https://news.hada.io/topic?id=31231)`
- `tistory_publisher.py --file --source-url --gn-topic-id` argparse 정상 작동
- `append_source_footer()` + `extract_gn_topic_id()` 멱등성 가드 (중복 박기 방지) 정상
- 누적 검증 차수: 10회 (216차~225차)

---

## 5. 영구화 all-green (225차) — 16종 패턴 통과

| 패턴 | 차수 | 225차 결과 |
|---|---|---|
| §3.8.1 3-endpoint probe | 196차 | ✅ 200 OK 3/3 (Tistory max=941 시작) |
| §3.30.4 0단계 state health check | 213차 | ✅ drift 0 (941=941=941) |
| `--refresh-topics` 12개 토픽 | 208차 | ✅ 12개 |
| §3.34.10 feeds.feedburner.com RSS | 218차 | ✅ 50 entries |
| **§3.34.11 5단계 dedup cron 직접** | 218차 | ✅ 20개 후보 9 fresh + 11 skip (정확도 100%) |
| §3.29.4 긱뉴스 `.md` endpoint | 212차 | ✅ 10,472 bytes / 200 OK |
| §3.23.1 frontmatter strip | 206차 | ✅ 10,472 → 4,163자 |
| §3.34.1 `tistory_publisher.py --file` | 217차 | ✅ 2,152자 heredoc 파일 발행 성공 |
| §3.32.2 cat_key 정규화 | 215차 | ✅ `normalize_cat_key('AI 뉴스')` → 'AI/ML' |
| §3.11 5단계 + §4 5-1 stats 보정 | 200차 | ✅ by_category['AI/ML'] 724→725 |
| §3.34.13 details에 gn_topic_id 박기 | 218차 | ✅ #942에 gn_topic_id=31231 박기 (누적 10건) |
| §3.34.3 last_topics 0개 정리 | 217차 | ✅ 0건 |
| §3.33.1 §3.32.1 cleanup | 216차 | ✅ 2,270 페이지 / 31231 매칭 0건 / PATCH 0/0 |
| §3.33.3 Blog DB ID grep | 216차 | ✅ 5회째 정상 추출 |
| **§3.34.19 source footer 자동 박기** | 221차 | ✅ 10번째 검증 — 긱뉴스 #31231 footer |
| §3.5 3중 신호 검증 | 195차 | ✅ drift 0 (942=942=942) |

**누적 영구화 all-green 통과 차수**: 213~225차 **연속 13회** (drift 0 시작/종료 + cleanup + stats 보정 풀 사이클 안정화).

---

## 6. 누적 통계 (225차 시점)

### gn_topic_id 박기 누적 10건 (218차 발견 → 225차 정상 작동의 핵심)

| 차수 | Tistory # | gn_topic_id | 카테고리 | 상태 |
|---|---|---|---|---|
| 218차 | #930 | 31218 (Ternlight) | AI/ML | ✅ |
| 218차 | #931 | 31225 (루프 시작하기) | AI/ML | ✅ |
| 219차 | #932 | 31221 (Google 데이터센터) | AI/ML | ✅ |
| 220차 | #933 | 31224 (30 Papers) | AI/ML | ✅ |
| 222차 | #935 | 31227 (EU 의회 Chat Control) | AI/ML | ✅ |
| 223차 | #936 | 31239 (Kokoro TTS) | AI/ML | ✅ |
| 224차 | #939 | 31219 (코딩 배우기) | AI/ML | ✅ |
| 225차 | #942 | **31231 (Chat Control 1.0과 2.0)** | AI/ML | ✅ |

**박기 누락 9건** (#921~#929): `scripts/retroactive-gn-topic-id.py` 1회 cleanup 임무 (임무 1번)

### cleanup 13회 연속 all-green (213~225차 표)

| 차수 | cleanup 결과 | 페이지 수 | URL 매칭 | PATCH |
|---|---|---|---|---|
| 213차 | (drift 복구로 cleanup skip) | - | - | - |
| 214차 | §3.31.1 89 PATCH (광범위) | 1,934 | (전체 cleanup) | 89 |
| 215차 | §3.32.1 1/18 | 1,925 | 18 (활성 1) | 1 |
| 216차 | §3.33.1 1/1 | 1,944 | 1 (활성) | 1 |
| 217차 | §3.33.1 1/12 | 2,030 | 12 (활성 1) | 1 |
| 218차 | §3.33.1 1/2 | 2,078 | 2 (활성 1) | 1 |
| 219차 | §3.33.1 1/3 | 2,090 | 3 (활성 1) | 1 |
| 220차 | §3.33.1 1/4 | 2,102 | 4 (활성 1) | 1 |
| 221차 | §3.33.1 1/18 | 2,114 | 18 (활성 1) | 1 |
| 222차 | §3.33.1 0/0 | 2,114 | 0 | 0 |
| 223차 | §3.33.1 0/0 | 2,114 | 0 | 0 |
| 224차 | §3.33.1 0/0 | 2,114 | 0 | 0 |
| **225차** | **§3.33.1 0/0** | **2,270** | **0** | **0** |

**225차 특이사항**: URL 매칭 0건 → PATCH 0/0 (정상 — Notion DB에 31231 긱뉴스 페이지가 아직 안 만들어짐, 또는 이미 비활성). 0 PATCH는 silent fail이 아니라 **URL 미존재**의 정상 결과.

---

## 7. §3.34.23 핵심 교훈 (225차)

1. **§3.34.23 stale fresh=true 4회째 재확인 — blog_pipeline.py 자체 수정은 미해결**: 220차 §3.34.18.5에 처음 발견 → 222차 2회째 → 224차 3회째 → 225차 4회째. cron이 직접 feeds.feedburner.com RSS + 5단계 dedup 실행이 우회 패턴으로 안정 작동 중 (225차 11건 skip 모두 정확도 100%). **영구화 권장**: blog_pipeline.py 자체에 5단계 dedup 통합 (임무 6번) — 다음 cron 작업자가 이 임무를 처리해야 함.

2. **feeds.feedburner.com RSS + 5단계 dedup cron 직접 실행 패턴 완전 안정화**: 225차에 후보 20개 → 9건 fresh + 11건 skip (모두 gn_topic_id 매칭). 박기 누적 10건 덕분에 11건 모두 정확 skip. 218차 §3.34.13 발견 부작용이 225차에 완전 정상 작동으로 전환.

3. **§3.34.19 source footer 10번째 검증 — 영구화 영구 안정화**: 221차 옵션 A 채택 후 5차수 (221~225차) 연속 정상 작동. `--source-url`/`--gn-topic-id` argparse + `append_source_footer()` + `extract_gn_topic_id()` 패턴이 영구 단계 진입.

4. **cleanup 13회 연속 all-green — 안정화 단계 완전 정착**: §3.33.1 §3.32.1 cleanup이 silent fail 없이 정상 작동. 225차 0 PATCH는 URL 미존재의 정상 결과 — silent fail과 구분.

5. **last_topics 0개 정리 패턴 (217차 발견) 부작용 없음 재확인**: 225차 시작 시 0건 → 5단계 dedup source_url 매칭 단계 무력화되지만 gn_topic_id 단계로 폴백 정상.

6. **§3.32.2 cat_key 정규화 영구화 정상 작동**: Tistory API `category='AI 뉴스'` → `normalize_cat_key('AI 뉴스')` → `'AI/ML'` 정상. by_category['AI/ML'] 724→725 정확.

7. **Tistory max=941 → 942 정상 발행**: §3.5 3중 신호 (Tistory=942, state=942, details=942) drift 0 통과. 가짜 발행 가능성 0%.

---

## 8. cleanup cron 임무 누적 (225차 시점, 미해결)

| # | 임무 | 우선순위 | 의존성 | 225차 상태 |
|---|---|---|---|---|
| 1 | 박기 누락 일괄 (`#921~#929` 등 gn_topic_id) | 중 | `feeds.feedburner.com` RSS + Tistory posts.json | 미해결 |
| 2 | 박기 누락 자동화 (post-publish 후크) | **최고** | `tistory_publisher.py --record-topic` 4인자 | 미해결 |
| 3 | Blog DB ID 분리 | 낮음 | `blog_pipeline.py`의 `NOTION_FALLBACK_DB_ID` import 통일 | 미해결 (grep 패턴 안정) |
| 4 | by_category 변형 키 합산 (`AI 뉴스`/`AI/ML` + `개발`/`개발도구` + `개발팁`/`개발 팁`) | 중 | alias_map 보강 | 미해결 |
| 5 | 재사용 가능한 cron 전용 5단계 dedup | **높음** | feeds.feedburner.com + details + last_titles | 미해결 (cron heredoc 패턴으로 우회) |
| 6 | `blog_pipeline.py --category`에 5단계 dedup 통합 | **높음** | Notion DB `활성` + details `gn_topic_id` + details title prefix 동시 매칭 | 미해결 (stale fresh=true 4회째 재확인) |
| 7 | `notion-cleanup-v3.py --deactivate-published-topics` (활성 필터 X) | 낮음 | §3.32.1 schema dump + 전체 query + URL 매칭 | 미해결 |
| 8 | Notion 동일 URL 중복 페이지 archive (URL당 1건만 유지) | 낮음 | DB schema dump + URL 매핑 | 미해결 |
| 9 | `scripts/state-recovery-213th.py --dry-run / --apply` | 낮음 | §3.30.4 0단계 health check 코드를 스크립트화 | 미해결 |
| 10 | post-publish 후크 atomic write 강화 | 중 | `os.replace()` atomic + retry 3회 | 미해결 |
| 11 | `--refresh-topics`의 자동 cleanup dry-run default | 낮음 | `--refresh-topics --dry-run` 또는 cleanup 단계 분리 | 미해결 |

---

## 9. 다음 차수 (226차) 작업자용 가이드

1. **§3.8.1 probe → §3.30.4 health check → feeds.feedburner.com RSS + 5단계 dedup → §3.34.1 --file 발행**이 안정 패턴. 그대로 이어가도 됨.
2. **stale fresh=true 4회째 재확인** — blog_pipeline.py 자체 수정은 미해결이지만 cron 직접 5단계 dedup으로 우회 중. 임무 6번 처리 시 우선 작업 권장.
3. **cleanup cron 임무 1번 + 2번**이 가장 시급 — 박기 누락 9건 일괄 정리 + post-publish 자동 박기 단계 추가.
4. **drift 0 → publish → cleanup → stats 보정 → drift 검증** 풀 사이클이 안정화 단계 완전 정착. 다음 차수도 동일 패턴으로 진행.

---

**세션 노트 메타**: 225차 작업 타임라인 + §3.34.23 stale fresh=true 4회째 누적 + 5단계 dedup 정확도 100% + 16종 영구화 패턴 all-green + gn_topic_id 박기 누적 10건 + cleanup 13회 연속 all-green + 누적 통계 + cleanup cron 임무 11개 상태.