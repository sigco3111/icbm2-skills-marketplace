# 198차 세션 — `blog_pipeline.py run_pipeline()` 사전 박기(pre-increment) 함정 발견

## 배경
197차에서 세션 만료 회복 + 가짜 발행 36건 롤백 + 자동화 3-layer 패치 완료.
197차 5-B cron 가드 (`b1bca63a117a` Tistory 발행 cron)에 publish 진입 시점 3-endpoint probe 추가됨.

## 결정적 발견
희정님 요청: "정상동작을 확인할 수 있도록 블로그포스팅 크론을 하나 실행해봐"

### 시도 1: `python3 ~/.hermes/scripts/blog_pipeline.py --category 'AI/ML'`
- **결과**: `status: ready` + guidline JSON 출력 (topic="더 나은 모델, 더 나빠진 도구", source_url=긱뉴스 #31148)
- **stats 변화**: 888 → 889 (자동 +1)
- **details/last 변화**: 변동 없음 (#903 그대로)
- **Tistory 실제 글 수**: 766 → 766 (변동 0)

즉 **`blog_pipeline.py --category` 한 번 실행 = 자동 가짜 발행 1건**.

## 근본 원인 (code trace)

`/Users/mac/scripts/blog_pipeline.py` 1963~1981줄:
```python
# 5. Update state (pre-increment to prevent double-publish)
today = datetime.now(KST).strftime("%Y-%m-%d")
if today not in state["daily_counts"]:
    state["daily_counts"][today] = {}
state["daily_counts"][today][category] = state["daily_counts"][today].get(category, 0) + 1
state["last_topics"].append({"topic": topic, "category": category, "timestamp": ...})
state["last_topics"] = state["last_topics"][-20:]
state["stats"]["total_published"] = state["stats"].get("total_published", 0) + 1
by_cat = state["stats"].get("by_category", {})
by_cat[category] = by_cat.get(category, 0) + 1
state["stats"]["by_category"] = by_cat
save_state(state)
```

**핵심**: guidline 출력 단계에서 stats 4개 필드 동시 +1 + last_topics.append → save_state. 그리고 LLM 본문 생성 + Tistory API 호출은 어디에서도 안 일어남.

### half-pipeline 패턴

`main()` 2082줄:
```python
result = run_pipeline(
    force_topic=args.force_topic,
    force_category=args.category,
)
print(json.dumps(result, ensure_ascii=False, indent=2))
```

즉 `blog_pipeline.py --category`는 **guidline JSON + stats 사전 박기**만 하고 종료. 실제 본문 생성 + Tistory API 호출은 외부 워커가 담당.

## 197차 5-B cron 가드의 사각지대

5-B 가드는 cron 진입 시점 (`b1bca63a117a` cron의 prompt 앞단)에 3-endpoint probe heredoc을 두어 publish를 막음. 그러나:

- **cron 경로**: cron prompt → 가드 → 통과 시 publish → 정상 또는 skip
- **`blog_pipeline.py --category` 직접 호출 경로**: 가드 밖 → pre-increment 박힘 → 실제 발행은 별도 워커 호출에 의존

즉 cron 가드는 publish까지 가드하지만, **run_pipeline()의 pre-increment 자체는 가드 범위 밖**.

## D 작업 (희정님 결정) — 진단 + 직접 발행 + 롤백 한 번에

희정님: "A" 진단 → 변경: "D로 해줘" (진단 + 직접 발행 + 롤백 한 번에)

### 5단계 절차

#### 1단계: 가짜 발행 1건 롤백 (blog_pipeline --category가 박은 통계)
```bash
python3 << 'PYEOF'
import json
from pathlib import Path
state_p = Path('/Users/mac/.hermes/memory/blog_pipeline_state.json')
state = json.loads(state_p.read_text())
# last_topics 마지막 1건 = 가짜 entry
last = state['last_topics'][-1] if state.get('last_topics') else {}
print('가짜 entry:', last)  # {'topic': '더 나은 모델, 더 나빠진 도구', 'category': 'AI/ML', 'timestamp': '2026-07-06T07:02'}
# daily_counts today 차감
key = '2026-07-06'
if state['daily_counts'].get(key, {}).get('AI/ML', 0) > 0:
    state['daily_counts'][key]['AI/ML'] -= 1
state['stats']['total_published'] -= 1
state['stats']['by_category']['AI/ML'] -= 1
if state.get('last_topics'):
    state['last_topics'] = state['last_topics'][:-1]
state_p.write_text(json.dumps(state, ensure_ascii=False, indent=2))
PYEOF
```
- 롤백 결과: total 888, by_category AI/ML 697, daily_counts today {AI/ML: 0, 개발도구: 0}, last_topics size 0

#### 2단계: 본문 작성
- 후보: 긱뉴스 #31148 "더 나은 모델, 더 나빠진 도구" (lucumr.pocoo.org 원문)
- 긱뉴스 fetch: HTTP 200, 16,157 bytes (1차 .md endpoint 성공)
- 작성 방식: LLM 컨텍스트에서 직접 markdown 본문 /tmp/draft_31148.md 작성
- 정형화: 5,716자 / H2 8개 / 표 2개 / 코드블록 1개 (7KB+ 정형화 1회 컷 충족)

#### 3단계: tistory_publisher.py 직접 발행
```bash
python3 ~/.hermes/scripts/tistory_publisher.py \
  --title "더 나은 모델, 더 나빠진 도구 — LLM 도구 호출 역설과 하네스의 미래" \
  --file /tmp/draft_31148.md \
  --tags "AI/ML,Claude,도구호출,strict,하네스,Llama,Grammar,에이전트" \
  --category 1219746 \
  --visibility public \
  --image-query "improving tools abstract circuit board"
```
- ✅ 발행 성공: https://sigco.tistory.com/904
- Content 검증 통과: 5,716자
- Picsum 이미지 2장 자동 + CDN 업로드 2/2 + OG 썸네일 자동

#### 4단계: §3.11 5단계 보강 + §4 5-1 stats 보정 워크플로
```bash
python3 << 'PYEOF'
import json, hashlib
from pathlib import Path
from datetime import datetime

state_p = Path('/Users/mac/.hermes/memory/blog_pipeline_state.json')
topics_p = Path('/Users/mac/.hermes/memory/published_topics.json')
urls_p = Path('/Users/mac/.hermes/memory/published_urls.txt')

pt = json.loads(topics_p.read_text())
state = json.loads(state_p.read_text())

now = datetime.now().strftime('%Y-%m-%dT%H:%M')
TOPIC = '더 나은 모델, 더 나빠진 도구'
TITLE = '더 나은 모델, 더 나빠진 도구 — LLM 도구 호출 역설과 하네스의 미래'
URL = 'https://sigco.tistory.com/904'
SRC_URL = 'https://news.hada.io/topic?id=31148'
CATEGORY = 'AI/ML'
hash12 = hashlib.sha1((TOPIC + URL).encode()).hexdigest()[:12]

# (a) last 갱신
pt['last'] = {'date': now, 'topic': TOPIC, 'title': TITLE, 'url': URL, 'source_url': SRC_URL}

# (b) details append (191차 발견 — last만 갱신하면 details[-1]이 직전 글 그대로)
pt.setdefault('details', []).append({
    'date': now, 'topic': TOPIC, 'title': TITLE, 'url': URL, 'source_url': SRC_URL,
    'category': CATEGORY, 'hash': hash12,
})
topics_p.write_text(json.dumps(pt, ensure_ascii=False, indent=2))
print(f'✅ pt[last] + details 동시 동기화: {URL}')

# (c) published_urls.txt append
with open(urls_p, 'a') as f:
    f.write(f'{SRC_URL}\n{URL}\n')
print(f'✅ published_urls.txt append 완료')

# (d) §4 5-1 stats 보정 (192차 발견 — tistory_publisher 직접 호출은 daily_counts +1 안 함)
key = '2026-07-06'
state['daily_counts'].setdefault(key, {})
state['daily_counts'][key][CATEGORY] = state['daily_counts'][key].get(CATEGORY, 0) + 1
state['stats']['total_published'] = state['stats'].get('total_published', 0) + 1
state['stats'].setdefault('by_category', {})
state['stats']['by_category'][CATEGORY] = state['stats']['by_category'].get(CATEGORY, 0) + 1
state_p.write_text(json.dumps(state, ensure_ascii=False, indent=2))
print(f'✅ stats 보정: AI/ML today={state["daily_counts"][key].get(CATEGORY)} total={state["stats"]["total_published"]}')
PYEOF
```

#### 5단계: §3.5 3중 신호 검증 + Tistory HTTP 200 검증
```bash
# 3중 신호
python3 -c "
import json
from pathlib import Path
pt = json.loads(Path('/Users/mac/.hermes/memory/published_topics.json').read_text())
state = json.loads(Path('/Users/mac/.hermes/memory/blog_pipeline_state.json').read_text())
print(f'(a) details[-1].url: {pt[\"details\"][-1][\"url\"]}')
print(f'(b) last.url:        {pt[\"last\"][\"url\"]}')
print(f'(c) stats today:     {state[\"daily_counts\"].get(\"2026-07-06\", {})}')
print(f'(d) stats total:     {state[\"stats\"][\"total_published\"]}')
"
# → (a)(b) #904 일치, (c) AI/ML: 1, (d) 889

# Tistory HTTP 200 + og:title 매치
curl -s -o /tmp/check_904.html -w "HTTP %{http_code} | %{size_download} bytes\n" "https://sigco.tistory.com/904"
grep -oE '<meta property="og:title"[^>]*>' /tmp/check_904.html
grep -q "더 나은 모델, 더 나빠진 도구" /tmp/check_904.html && echo "✅ 본문 매치"
```

## 최종 결과

| 지표 | Before | After |
|---|---|---|
| blog_pipeline state.total | 888 | **889 (+1)** ✅ |
| blog_pipeline state AI/ML | 697 | **698** |
| blog_pipeline last_topics size | (196차 후 0) | (실제 발행 1건 처리, 0 그대로) |
| published_topics details | #903 마지막 | **#904 마지막** |
| published_topics last | #903 | **#904** |
| published_urls.txt | 마지막 줄 (#903) | **#904 + 긱뉴스 #31148 src URL 추가** |
| Tistory 실제 글 수 (`--check-session`) | 766 | **767 (+1)** |
| Tistory #404 페이지 검증 | - | **HTTP 200, 69,759 bytes, og:title 일치, 본문 키워드 매치** |

## §3.14 — 198차 영구화 신규 함정

**`blog_pipeline.py --category 'CAT'` 한 번 실행 = 자동 가짜 발행 1건.**

`run_pipeline()` 1965~1981줄의 pre-increment + save_state()가 LLM 본문 생성/Tistory API 호출 없이 stats만 +1 박는 구조적 결함. half-pipeline 패턴 (guidline만)에서 발행은 외부 워커가 별도 책임.

## 조치 옵션 (희정님 결정 후 적용)

### 옵션 (i) — 근본 해결: pre-increment → post-increment 이관
- `run_pipeline()`을 2-phase로 split: phase 1 (guidline + dry-run), phase 2 (publish 후 +1)
- 작업량: 중간 (코드 split + main() 2개 모드), 영향도 중간
- 장점: 가짜 발행 루트 자체 차단

### 옵션 (ii) — `--guideline-only` 플래그 추가
- `main()` argparse에 `--guideline-only` 추가 → stats 박기 skip
- 작업량: 적음, 영향도 낮음
- 장점: 단일 호출로 guidline만 받는 표준 path

### 옵션 (iii) — Layer 3 자동 정리 (이미 존재, 197차 §8.12)
- `scripts/rollback-fake-publish.sh`가 격차 자동 검출 + 일별 롤백
- 작업량: 0 (이미 존재)
- 단점: 가짜 발행 발생 자체는 못 막음

## 다음 cron (199차+) 이월 TODO

1. **`run_pipeline()` pre-increment → post-increment 이관** (희정님 옵션 결정 후, 옵션 (i))
2. **`--guideline-only` 플래그 추가** (옵션 (ii))
3. **half-pipeline 패턴 문서화** — `blog_pipeline.py --help`에 명시
4. **Layer 3 cron 알림 등록** — 격차 > N 시 텔레그램 알림
5. **"PUBLISH vs READY" 모드 분리** — `blog_pipeline.py`를 2개 entry로 split (`--ready-mode`, `--publish-mode`)

## 부수 발견

- **`tistory_publisher.py --record 3-arg` 호출 시 stdout buffer 잔존 가능성**: 198차 검증 시 `print` + `return` 패턴 (2082줄 main())이 정상 동작 확인. false alarm.
- **`tistory_publisher.py --check-session` 글 수 정확**: 766 → 767 (+1) 정확한 1건 차이 확인 → §3.8.1 §3.11 5단계 보강 정합성 입증.
- **Picsum 키워드 다양성**: `improving tools abstract circuit board` → 2장 매치 (1051 + 313) — 자동 OG 썸네일 정확.
