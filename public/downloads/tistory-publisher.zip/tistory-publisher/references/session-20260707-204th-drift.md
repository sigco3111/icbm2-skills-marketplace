# 204차 — DRIFT #913 발행 + §3.21 3중 dedup false negative 발견 + Notion PATCH cleanup 7건 (2026-07-07)

## 발행 결과
- **#913 DRIFT — LLM 하나를 Mac과 CUDA로 나눠 돌리는 오픈소스 분산 추론** (AI/ML 1219746)
- 1,210자 / 6 H2 / 2 Picsum images (distributed-computing-cluster-gpu)
- §3.5 4-way 정합: Tistory max 913 = state last 913 = urls last 913 = details last 913 ✅
- drift = 0 (stats +1, Tistory +1)
- 누적 drift 124 (stats 897 vs Tistory totalCount 773) — §3.16 별도 cron 작업 대상 유지

## 워크플로 (half-pipeline §3.18 + §3.20 패턴)
1. §3.8.1 3-endpoint probe → 200 OK (세션 유효)
2. `blog_pipeline.py --refresh-topics` → 12개 토픽 갱신
3. Notion API 직접 조회 → 12개 활성 + 3중 dedup 시도 → last_titles[:50] false negative 확인
4. 명시 매핑(`known_mappings` 사전)으로 진짜 미발행 후보 (31177) 선택 — DRIFT (Fable5/DRIFT)
5. heredoc으로 본문 작성 → `tistory_publisher.py --file` 호출 → #913 정상 발행
6. §3.11 5단계 + §4 5-1 stats 보정 heredoc 실행 → 4필드 동기화
7. §3.20.1 Notion PATCH cleanup 7건 (#906/908/909/910/911/912/913) → 7/7 성공
8. §3.5 4-way 검증 → drift 0

## §3.21 핵심 발견: 3중 dedup `last_titles[:50]` prefix false negative

### 증상
- state.last_topics 마지막 글: "DRIFT — LLM 하나를 Mac과 CUDA로 나눠 돌리는 오픈소스 분산 추론"
- Notion 활성 후보: "Show GN: Fable5는 비싸지고, 로컬 GPU는 부족하다: LLM 하나를 Mac & CUDA로"
- `last_titles = {t.get('title','').lower()[:50] for t in state.get('last_topics',[])}` → `{"drift — llm 하나를 mac과 cuda로 나눠 돌리는 오픈소스 ..."}`
- 후보 31177 name.lower()[:50] = "show gn: fable5는 비싸지고, 로컬 gpu는 부족하다: llm 하..."
- 매칭: ❌ 다른 prefix, false negative (의도와 다르게 후보 풀에 들어옴)

### 원인
- §3.19 3중 dedup의 title prefix 매칭이 한글 + 영문 혼합 50자에서 거의 unique
- 사실 false negative의 risk는 **같은 글이 아니어도 무관한 토픽이 통과할 위험**이 더 높음 (다행히 이번 우연한 정렬로 정상이었을 뿐)

### 영구화 결정 (3가지 옵션)
1. **(권장)** §3.20.1 Notion PATCH cleanup으로 후보 풀 자체 축소 — 매 세션 시작 시 `known_mappings` 사전으로 이미 발행한 페이지 비활성화
2. **`known_mappings` 사전 기반 명시 skip** — 204차 적용 패턴 (소스 코드 heredoc 안에 매핑 직접 유지)
3. **(차선)** hash + URL dedup만 사용, `last_titles[:50]` 줄 완전히 제거

### 영향
- 202/203차 모두 동일 false negative 위험 노출 — 만약 그때 운이 나빴다면 중복 발행 발생
- §3.21 후속 작업으로 모든 3중 dedup 코드 경로에서 `last_titles[:50]` 제거

## Notion PATCH cleanup 7건 확장 (§3.20.1)
203차 4건에서 204차 7건으로 확장 (#906/908/909/910/911/912/913). 7/7 안정 확인. 매핑 사전 영구 단계.

## 확인된 §3.20 함정 회피
- §3.20.2 `--category` int 함정 → 1219746 사용 정상
- §3.20.3 비대칭 tab 포맷 + 비-Tistory URL → `line.split('\t')[0]` + `sigco.tistory.com` 필터 안전

## 후속 권장 작업 (다음 cron 임무)
1. **§3.21 3가지 dedup 강화 패턴 중 (1) Notion PATCH cleanup 자동화** 권장 — `known_mappings_build.py` 스크립트로 state.last_topics + published_urls.txt → Notion PATCH 매핑 자동 생성
2. **§3.16 누적 drift 124 별도 cron 작업** 분리 유지 — drift 정리는 이번 cron 임무 외
3. **§3.19 3중 dedup 코드 패치** — `tistory-publisher` 또는 `blog_pipeline`의 dedup 함수에서 `last_titles[:50]` 패턴 제거, hash + URL dedup만 사용

## 환경 노트
- `execute_code` cron BLOCKED 제약 195차부터 계속 — 모든 heredoc은 `terminal` + `python3 heredoc` 사용
- session은 여전히 DB cuid 없이 active
