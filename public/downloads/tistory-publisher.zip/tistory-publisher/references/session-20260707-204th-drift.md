# 204차 — DRIFT 발행 (#913) + 3중 dedup 통과 + Notion 7건 PATCH cleanup

## 발행 결과
- **#913 DRIFT — LLM 하나를 Mac과 CUDA로 나눠 돌리는 오픈소스 분산 추론** (AI/ML, 1219746)
- 1,210자 / 6 H2 / 2 Picsum images
- §3.5 4-way 정합: Tistory max 913 = state last 913 = urls last 913 = details last 913 ✅
- drift = 0 (stats +1, Tistory +1)

## 워크플로 (half-pipeline §3.18 패턴)
1. §3.8.1 3-endpoint probe → 200 OK (세션 유효)
2. `blog_pipeline.py --refresh-topics` → 12개 토픽 갱신
3. Notion API 직접 조회 → 12개 활성 + 3중 dedup으로 후보 계산
4. 후보 중 **AI/ML 9점 Fable5/DRIFT (31177)** 선택 (이미 발행된 31168/31170/31173/31161은 last_topics[:50] prefix에 안 잡혀 후보로 나타남 → 매핑으로 명시 skip)
5. heredoc으로 본문 작성 → `tistory_publisher.py --file` 호출 → #913 발행
6. §3.11 5단계 + §4 5-1 stats 보정 heredoc 실행 → 4필드 모두 동기화
7. Notion PATCH cleanup 7건 → 7/7 성공 (#906/908/909/910/911/912/913 모두 비활성화 + 마지막 사용일=2026-07-07)
8. §3.5 3중 신호 검증 → drift 0

## 확인된 사항
- §3.20.1 Notion PATCH cleanup 패턴이 7건으로 확장되어도 안정 작동
- §3.19 3중 dedup의 last_titles[:50] prefix 매칭이 부정확하여 명시 매핑이 더 신뢰성 있음 (이번에 last_titles[:50] = "DRIFT" vs Notion 후보 "Show GN: Fable5는 비싸지고..." → 매칭 안 됨, 그래서 통과했는데 사실은 다른 글). 차후 §3.19 규칙 강화 검토.
- §3.20.2 --category int 함정 회피 (1219746 사용) 정상 작동
- §3.20.3 published_urls.txt 비대칭 tab 포맷 첫 컬럼 파싱 + 비-Tistory URL 필터 안전성 확인

## 후속 작업
- §3.19 last_titles[:50] prefix 매칭 강화: 전체 title로 비교 또는 hash 사용
- §3.16 누적 drift 124 (stats 897 vs Tistory totalCount 773) 별도 cron 작업 분리 유지
- §3.20.2 카테고리 ID 매핑(automation=1219748, AI 뉴스=1219746) 추가 작업 시 `--categories` 1회 조회 패턴 영구화
