# 281차 세션 노트 (2026-07-17) — Claude 비밀 유출 공격

## 결과
- **#1029 정상 발행** — `Claude를 속여 사용자의 가장 깊은 비밀을 유출시킨 방법 — 메모리·웹 탐색 결합이 만든 검색 상위 노이즈 공격과 한국 사용자가 꺼야 할 기본값`
- AI/ML/1219746, gn=31478, 6점, FRESH 1순위 (§3.34 #21 AI/ML 우선 정책 + §3.34.45 매트릭스 4번째 분기)
- 연속 all-green **68회차** (213~281차)
- cleanup cron 임무 #16 dry-run `✅ 누설 없음` (67→**68회**)

## 패턴/가드 동작 확인
- §3.8.1 가드 통과 (`status=200, ct=application/json;charset=UTF-8, cookie_count=8`)
- §3.34.43 PWD 보강 (`PWD=/Users/mac`)
- §3.34.40 v2 FRESH 4-field (FRESH 5개 식별: 31492/31478/31467/31476/31480; AI/ML 후보 4개 → 점수 1순위 `31478 (6점)` 픽)
- §3.34.46 영구화 (`_try_md_endpoint(31478)` → status=200, 10205 bytes 1단계 `.md` fetch)
- §3.34.50 Topic Body 마커 8회째 (본문 평문 4671자, 300자 가드 통과)
- §3.34.47 격리 빌드 (`/tmp/tistory_drafts_281st/build_draft_31478.py` 7062 bytes UTF-8 선언 + 격리 호출 정상)
- §3.34.53 `gfc` alias 5회째 (importlib spec_from_file_location 정상)
- §3.34.54 `> ` blockquote 분기 코드 유지 (이번 본문엔 `>` 라인 없음, 분기 안전 가드 포함)
- §3.34.55 `_try_md_endpoint(tid)` 단일 변수 할당 3회째 (31478 → 10205 bytes 정상 fetch)
- §3.34.48 `* ` 분기 코드 유지
- §3.5 5중 신호 5/5 `#1029` 일치 (`all_match: True`)
- §3.34.52 IME 가드 (title ASCII 토큰 `Claude` sanity check 통과 + 라이브 페이지 `<title>` cross-check 정상)
- §3.11 sync `pt_updated: true / state_updated: true / triple_signal_match: true`
- §3.34.44 drift 무해 검증 — 사전 검증에서 `state.last_published_url = #1028`, 5중 모두 일치

## 결과 수치
- daily_counts[2026-07-17] = `{'AI/ML': 3}` (정확, cat_id 누설 0)
- state.details 106→107, pt.details 121→122 모두 박힘
- Picsum ID 1024 (두 슬롯 동일)
- 라이브 페이지 GET `status=200, size=61638, title tag='Claude를 속여 사용자의 가장 깊은 비밀을 유출시킨 방법 &mdash; 메모리&middot;웹 탐색 결합이 만든 검색 상위 노이즈 공격과 한국 사용자가 꺼야 할 기본값'` (실제 발행 확인)
- 본문 4590자 (publish 단계 content 검증), 평문 4671자 (300자 가드 통과)

## §3.34 #21 정책 실전 8호 (281차 검증)
255차 1호 → 266차 2호 → 268차 3호 → 269차 4호 → 270차 5호 → 271차 6호 → 280차 7호 → **281차 8호**
이번 케이스: FRESH 5개 중 AI/ML 4 (6/5/3점 + 게재 분류가 다른 후보) + 개발도구 1 + 개발팁 1 → §3.34 #21 정책으로 AI/ML 점수 1순위 6점 `31478` 픽 (개발팁 14점 후보는 AI/ML 우선 정책으로 자동 제외).

## 본 세션 신규 발견 0건
모든 패턴(§3.8.1 가드 / §3.8.2 격리 / §3.11 sync / §3.34.40 v2 / §3.34.43 PWD / §3.34.46 영구화 / §3.34.47 격리 빌드 / §3.34.48 `*` 분기 / §3.34.50 Topic Body / §3.34.52 IME 가드 / §3.34.53 `gfc` alias / §3.34.54 `>` blockquote / §3.34.55 시그니처 함정 / §3.34 #21 정책 + #45 매트릭스) 정상 동작. 차감/추가 없음.

## 참고: --json 옵션 함정 (281차 1회성)
`blog_pipeline.py` 에는 `--json` 옵션이 없음 (`--refresh-topics` 가 stdout 으로 JSON 부분만 dump). → 2>/dev/null 로 stderr 분리 후 `text[text.find("{"):text.rfind("}")+1]` 로 JSON 슬라이스 파싱, 또는 `grep -E 'URL:|score|category'` 로 텍스트 파싱 권장. 영구화 불필요 (1회성 옵션 오타).