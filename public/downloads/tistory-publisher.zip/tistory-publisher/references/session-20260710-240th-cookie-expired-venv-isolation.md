# 240차 세션 — 쿠키 만료 + hermes venv 격리 패턴 (2026-07-10)

## 결과 요약
**발행 0건** — §3.8.1 세션 만료 가드 SKIP. 그러나 가드 동작 검증 + §3.8.2 격리 패턴 신규 발견 + §3.5 3중 신호 일치 확인 + cleanup cron 임무 #16 dry-run 27회 연속 all-green.

## 발견 #1 (NEW, 가장 중요): hermes-agent venv의 urllib3가 Python 3.11.15와 비호환

### 증상
```python
import requests
```
→ `urllib3/_base_connection.py` 로딩 시
```
TypeError: unsupported operand type(s) for |: 'type' and 'type'
```

### 원인
hermes-agent venv에 설치된 `urllib3 2.6.x`는 PEP 604 union syntax (`bytes | str`, `type | None` 등)를 사용. 이 문법은 **Python 3.10+** 컴파일러가 필요. venv의 python3는 3.11.15라 *런타임에는* OK여야 하지만, hermes venv의 인터프리터가 어딘가에서 3.9로 fallback되는 듯한 동작 관측. 정확한 진단은 시간 부족, **동작 패턴만 확인**.

### 격리 패턴 (검증 완료)
venv 영향을 완전 차단하고 system Python 3.9 + 사용자 site-packages 사용:

```bash
env -i HOME=/Users/mac PATH=/usr/bin:/bin /usr/bin/python3 << 'PYEOF'
import sys
sys.path.insert(0, '/Users/mac/Library/Python/3.9/lib/python/site-packages')
# ... 스크립트 본문 ...
PYEOF
```

`env -i`로 VIRTUAL_ENV 등 모든 venv 관련 환경변수 제거 + `PATH`를 시스템 전용으로 제한. `PYTHONPATH`로 사용자 site-packages 강제 주입. `/Users/mac/Library/Python/3.9/lib/python/site-packages`에 다음이 설치되어 있어 동작:
- `requests-2.32.5` (외부 의존성 OK)
- `urllib3-2.6.3` (LibreSSL 2.8.3 미지원 경고는 나오지만 동작)

### 검증된 호출 패턴
```bash
set -a && source ~/.hermes/secrets/tistory.env && set +a && \
  env -i HOME=/Users/mac PATH=/usr/bin:/bin /usr/bin/python3 << 'PYEOF'
import sys
sys.path.insert(0, '/Users/mac/Library/Python/3.9/lib/python/site-packages')
import os, requests
cookies = {k.replace('TISTORY_',''): os.environ[k] for k in os.environ if k.startswith('TISTORY_')}
hdr = {'User-Agent':'Mozilla/5.0','Referer':'https://sigco.tistory.com/manage/','X-Requested-With':'XMLHttpRequest'}
r = requests.get('https://sigco.tistory.com/manage/posts.json?category=-3&page=1',
                 cookies=cookies, headers=hdr, timeout=10, allow_redirects=False)
# ... 가드 로직 ...
PYEOF
```

## 발견 #2: §3.8.1 가드 동작 정상 검증
- `manage/posts.json?category=-3&page=1` 호출 → **HTTP 302** + `Location: /auth/login`
- 가드 코드 정확히 SKIP 분기 진입 → "⏸️ SKIP: §3.8.1 세션 만료" 출력
- 가드 통과 못해도 §3.5 3중 신호 검증은 정상 실행 (state 파일은 로컬이라 영향 없음)
- **publish 단계 완전 skip → 가짜 발행 위험 0**

## 발견 #3: §3.5 3중 신호 일치 OK (239차 보정 결과 유지)
- a) `pt['last'].url` = `'https://sigco.tistory.com/957'` ✅
- b) `details[-1].url` = `'https://sigco.tistory.com/957'` ✅
- c) `state.details count` = 33
- 3중 신호 일치 — 239차 §3.34.36에서 heredoc으로 박은 보정 결과가 다음 세션까지 유지됨

## 발견 #4: cleanup cron 임무 #16 dry-run all-green
- 27회 연속 (213~240차) — 누적 cat_id 누설 0건
- `stats.daily_counts[2026-07-10] = {'AI/ML': 4, '개발도구': 1, '개발팁': 1}` (정상 한글 key만)

## 조치 필요 (다음 cron 전)
1. **브라우저 쿠키 갱신**: sigco.tistory.com 로그인 → dev tools에서 `manage/posts.json` 호출 가능한 fresh 쿠키 export → `~/.hermes/secrets/tistory.env` 갱신
2. **hermes venv urllib3 재설치** (영구 fix): `~/.hermes/hermes-agent/venv/bin/pip install --upgrade 'urllib3<2' requests` (LibreSSL 호환 위해 1.x로 다운그레이드 또는 urllib3 2.0+ 요구 Python 3.10+ 확인 후 venv 인터프리터 업그레이드)

## 영구화 권장
- **§3.8.2 격리 패턴**: 모든 cron 작업 §3.8.1 가드 호출 시 hermes venv 격리 fallback 추가
- **§3.8.1 가드 §3.5 검증 자동 동반**: 가드 실패해도 §3.5 3중 신호는 항상 실행 (이미 처리됨, 본 세션 검증)

## 메모
- 이번처럼 "발행 0건 + 세션 만료" 상황에서도 reports는 정상 발송되어야 함 (silent 아님)
- §3.5 3중 신호 검증을 §3.8.1 가드 직후 항상 동반하면 sanity check 역할
- 격리 패턴은 다른 cron 작업 (cleanup, healthcheck)에도 적용 가능 — 동일한 venv 문제 겪을 가능성 높음