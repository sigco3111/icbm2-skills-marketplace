# 354차 (2026-08-05 19:01) — AI 이미지 블로그 신뢰 + 함정 26 다중 CJK swap

## 발행

- **#1181** ("AI 생성 이미지 때문에 당신의 블로그를 읽기 싫어진다 — 직접 그린 그림의 신뢰 가치", gn=32142, AI/ML, 본문 1,885자, Picsum 2장)
- 단일 패스 45연속 + 신호 4 disambiguate 44연속 + 진입 5-5 24연속 + fallback 복귀 36연속
- 연속 all-green **127회차**
- daily_counts={AI/ML:1}, total=174

## 🆘 함정 26 다중 CJK swap 정형 (354차 신규 — 단일 차 최다)

**트리거**: `write_file /tmp/build_post_354.py` 직후 sibling subagent write warning 자동 발생 → 한국어 단어가 한자로 swap.

**354차 실측 (단일 차 4건 동시)**:
- `幻觉` ×3 라인 (완성도幻觉, 완성도幻觉·브랜드..., 요약 리스트 안의 `완성도幻觉`)
- `这种现象` ×1 라인 (특히 기술·일상·에세이 카테고리에서这种现象이 두드러진다)

**swap 패턴 누적**:
| 차수 | swap 건수 | swap 후보 |
|------|----------|----------|
| 333차 | 1 | 입장 → 立场 |
| 342차 | 1 | 정기 → 定时 |
| 343차 | 1 | 자세 → 姿勢 |
| 347차 | 3 | 수랭 → 液냉, 공감대 → 共识, 일 → 仕事 |
| **354차** | **4** | **幻觉 → 환상 ×3, 这种现象 → 이·이러한 현상** |

추세: 단일 차 동시 발생 건수가 증가 (347차 3건 → 354차 4건). 빌드 시점 정형 검출 + 자동 복원 루프가 필수.

## 자동 복원 루프 정형 (354차 신규)

CJK swap 발견 시 다음 6단계를 1회차에 모두 처리:

```bash
# (1) 빌드 산출물에서 CJK substring 검출
/usr/bin/python3 -c "
import re
from pathlib import Path
html = Path('/tmp/post_NNN.html').read_text(encoding='utf-8')
hits = re.findall(r'[\u4e00-\u9fff]+', html)
print(f'CJK substrings={hits}')
print(f'count={len(hits)}')
# 한자 substring이 들어간 라인 컨텍스트 출력
for h in hits:
    for line in html.split('\n'):
        if h in line:
            print(f'  → {line[:150]}')
"
# → CJK substrings=['幻觉'] count=2 (alt 태그 1 + 본문 1)
# → '幻觉' 들어간 라인: 1) 완성도幻觉...  2) ...완성도幻觉·브랜드...

# (2) 빌드 스크립트에서 동일 substring grep
grep -n '幻觉\|这种现象' /tmp/build_post_NNN.py

# (3) read_file로 의심 라인 직접 확인
# (4) patch() 한 건씩 한국어 원문 복원 (幻觉 → 환상, 这种现象 → 이 현상)
# (5) 재빌드
unset PYTHONPATH PYTHONHOME; PYTHONNOUSERSITE=1
export PYTHONPATH=/Users/mac/Library/Python/3.9/lib/python/site-packages
/usr/bin/python3 -s /tmp/build_post_NNN.py
# → cjk_suspicious=0 확인

# (6) parts.append 카운트 변동 없음 확인 (prefix 손실 변형 미발생 진단)
grep -c 'parts.append' /tmp/build_post_NNN.py
```

**루프 종료 조건**:
- 빌드 산출물 `cjk_suspicious_count=0` ✅
- `parts.append` 카운트 변동 없음 (354차: 33 → 33, prefix 손실 변형 미발생) ✅
- lint 통과 ✅

**354차 검증 결과**: 4건 동시 swap → patch() 3회 (幻觉 3 라인 + 这种现象 1 라인, 幻觉 한 라인 두 군데라 patch 한 줄로 한 번에 처리) → 재빌드 → cjk_suspicious=0 → 정상 publish.

## 한국어 대안 사전 (354차 갱신)

| 중국어/한자 | 한국어 원문 | swap 차수 |
|------------|------------|----------|
| 立场 | 입장 | 333차 |
| 定时 | 정기 | 342차 |
| 姿勢 | 자세 | 343차 |
| 液냉 | 수랭 (수랭식) | 347차 |
| 共识 | 공감대 | 347차 |
| 仕事 | 일 (작업) | 347차 |
| **幻觉** | **환상** | **354차 신규** |
| **这种现象** | **이/이러한 현상** | **354차 신규** |

## 빌드 검증 매트릭스 (354차 정형)

| 검증 항목 | 기준 | 354차 실측 |
|----------|------|----------|
| exit code | 0 | 0 ✅ |
| bytes | 1500+ | 2525 ✅ |
| text_len (HTML 태그 제거) | 1500+ | 1885 ✅ |
| img_count | ≥ 1 (Picsum) | 2 ✅ |
| code_block_count | 본문 성격에 따라 | 0 ✅ |
| source_in_body | True (footer 자동) | True ✅ |
| cjk_suspicious | 0 (한글 깨끗) | 0 ✅ (재빌드 후) |
| parts.append count | 변동 없음 | 33 → 33 ✅ |

## 이번 차 워크플로 정상 작동 확인

- ✅ §3.8.1 raw 가드 (first_ids=['1180','1179','1178','1177','1176'])
- ✅ `blog_pipeline.py --category 'AI/ML'` 단일 호출 → `status=ready` (gn=32142)
- ✅ 단일 패스 빌드 (parts.append() 정형 + Picsum 2장 + 1885자)
- ✅ **함정 26 다중 CJK 4건 동시 swap → 자동 검출·복원 루프 1회차 처리** (354차 정형)
- ✅ `tistory_publisher.py --content "$CONTENT"` 셸 치환 (324차 정형)
- ✅ Picsum 2장 자동 업로드 (image.jpg 10KB + 52KB)
- ✅ OG 썸네일 `https://blog.kakaocdn.net/dna/b5B8V9/dJMcaazw2HO/AAAAAAAAAAA...` 자동
- ✅ 5-2 commit (today={AI/ML:1}, total=174, by_category 영구 잔존)
- ✅ 5-3 KST 타임존 명시 (317차 정형)
- ✅ 5-2-A 누락 백필 1건 정상
- ✅ §3.5 3중 신호 일치 (today={AI/ML:1}, last=#1181, last_topics[-1].url=#1181)
- ✅ 5-5 proxy check disambiguate PASS (status=200 + og:title 정확 + source_present=True + cjk_suspicious=0)

## 누적 통계

- 354차 daily_counts={AI/ML:1}, total=174
- 함정 26 swap 누적 차수: 333, 342, 343, 347, **354** (5차, 최대 4건/차)
- by_category["1219746"]=1 영구 잔존 58차 누적 (297→354)
- 5-2-A 누락 백필 누적 패턴 정상 (state→published_topics 단방향 idempotent)
- 신호 4 disambiguate 연속 확정 44연속 (298→354)
