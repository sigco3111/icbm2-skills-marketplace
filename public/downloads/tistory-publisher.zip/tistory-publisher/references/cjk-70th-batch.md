# CJK Loop Residuals — 70차 누적 (2026-05-26)

## 70차 신규 발견 (Codex 활용 사례 블로그 글)

| 문자 | Unicode | 의미 | 출처 | 처리 |
|------|---------|------|------|------|
| 胆 | U+80C6 | 쓸개, 용기 | Markdown 모델 혼입 | `'胆': '담'` |
| 丸 | U+4E38 | 알, 환 | Markdown 모델 혼입 | `'丸': '환'` |
| ご | U+3054 | Japanese | Markdown 모델 혼입 | `'ご': ''` |
| 之外的 | - | Korean+Hanja 결합 | --title CLI 바이패스 | `'之外的': '이외의'` |

## 70차 발생 경위

**원인:** Markdown 작성 시 모델이 Korean 텍스트 사이에 Chinese/Japanese 캐릭터를 직접 생성

**주시 대상 패턴:**
- `開発자之外的` — Korean+Hanja 결합 형태 (`之外的` = "이외의")
- Japanese hiragana `ご` — ご飯(ごはん) 등에서 유입
- Chinese 한자 `丸`(환), `胆`(담) — GeekNews 원문 참조 시 혼입

**방지법:**
1. Markdown 작성 시 Korean-only 강제 — Chinese/Japanese 표현은 한국어 대응 표현으로 번역 후 작성
2. `--title` CLI 인자도 별도 CJK 검사 대상 — 제목 생성 시에도 Korean-only 적용
3. `之外的` 같은 Korean+Hanja 결합 형태는 단어 단위 사전 `'之外的': '이외의'`로 제거

## CJK 종합 사전 배치 기준

SKILL.md의 comprehensive dict에 배치하며, 배치 위치는 **69차 Katakana 누락 보강 항목 뒤**:
```
# 70차 (2026-05-26): Codex 활용 사례 블로그 글 — Markdown 작성 단계 모델 혼입
'胆': '담', '丸': '환', 'ご': '',
# 70차: Korean+Hanja 결합 형태
'之外的': '이외의',
```

## 이전 차수 참고

- 69차: Katakana 누락 (`ビ`, `ュ`, `レ`) + Chinese 복합어 (`規模`, `影響` 등)
- 68차: Korean Hanja 쾨 → 快 변환 후 CJK regex 밖(U+CDF0) 문자
- 67차: GeekNews Chinese 복합어 대량 유입 (`規模`, `影響`, `攻撃` 등 18개)
- 66차: `虚`, `拟`, `主`, `流` — Chinese 복합어 직접 생성
