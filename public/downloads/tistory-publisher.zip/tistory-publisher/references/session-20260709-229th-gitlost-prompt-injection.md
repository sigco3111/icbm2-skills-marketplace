# 229차 Tistory 자동 발행 — GitLost (2026-07-09)

## 결과
- **#946 GitLost: GitHub AI 에이전트를 속여 비공개 저장소 유출 — Agentic Workflows의 간접 프롬프트 인젝션** 발행
- Tistory URL: https://sigco.tistory.com/946
- 본문: CJK 825자 / validate 1,559자 / Picsum 2장 / source footer 자동 (14번째 검증)

## 작업 타임라인

1. §3.8.1 3-endpoint probe: ✅ 200 OK 3/3 (Tistory max=945 시작)
2. §3.30.4 0단계 health check: ✅ drift 0 (945=945=945=945)
3. feeds.feedburner.com RSS fetch: 50 entries
4. `blog_pipeline.py --refresh-topics`: 12개 긱뉴스 토픽
5. **§3.34.11 5단계 dedup cron 직접**: **10 fresh + 2 GN_TOPIC_ID skip (정확도 100%)**
   - skip: #31251 (Weave Router, #943), #31266 (한글화, #944) — 모두 gn_topic_id 매칭
6. 1순위: **#31255 GitLost** (20점, AI/ML)
7. **§3.34.24 .md 404 환경 함정 3회째**: `news.hada.io/topic.md?id=31255` 404 → HTML `/topic?id=31255` fallback → 9,081자 추출 → 한국어 재작성 1,824자
8. `tistory_publisher.py --file /tmp/post_229_gitlost.md --source-url --gn-topic-id 31255` 발행 → #946
9. §3.34.19 source footer 자동 박기 (14번째 검증)
10. §3.11 5단계 + §4 5-1 stats 보정: by_category['AI/ML'] 728→729, total 945→946
11. §3.34.13 details에 gn_topic_id 박기: #946 gn_topic_id=31255 (누적 17건)
12. §3.34.3 last_topics 정리 0건
13. `blog_pipeline.py --record "31255" "..." "https://sigco.tistory.com/946"` (3개 인자, §3.33.2)
14. §3.33.1 §3.32.1 cleanup: 2,375 페이지 / 31255 매칭 9건 (활성 1 + 비활성 8) / PATCH 1/1
15. §3.5 3중 신호 검증: ✅ drift 0 (946=946=946=946)

## §3.34.25.1 `.md` 404 환경 함정 3회째 (⭐⭐⭐ 영구화 시급)

227차 + 228차 + 229차 연속 .md 404 응답. 긱뉴스 측 마크다운 변환 기능의 영구 변경으로 확실해짐. **cleanup cron 임무 #12 (`scripts/gn-fetch-content.py`) 영구화 시급** — 3단계 fallback (`.md` → HTML → RSS) + None + skip 패턴 standalone 분리.

**229차 실전 fallback 2 (HTML)**: `news.hada.io/topic?id=31255` 200 OK + 정규식 추출 9,081자 → 한국어 재작성 1,824자 → 발행 정상.

## §3.34.11 5단계 dedup 7회째 (정확도 100%, 218~229차 누적)

| 차수 | 후보 | fresh | skip | 정확도 | 발행 |
|---|---|---|---|---|---|
| 218차 | 12 | 11 | 1 (gn_topic_id) | 100% | #931 |
| 219차 | 12 | 10 | 2 (gn_topic_id) | 100% | #932 |
| 220차 | 20 | 17 | 3 (gn_topic_id) | 100% | #933 |
| 225차 | 11 | 11 | 0 | 100% | #942 |
| 226차 | 12 | 12 | 0 | 100% | #943 |
| 227차 | 25 | 22 | 3 (gn_topic_id) | 100% | #944 |
| 228차 | 14 | 12 | 2 (gn_topic_id) | 100% | #945 |
| **229차** | **12** | **10** | **2 (gn_topic_id)** | **100%** | **#946** |

박기 누적 비례 정확도 유지.

## §3.34.19 source footer 14번째 검증 (218~229차)

`append_source_footer()` + `extract_gn_topic_id()` + `--source-url`/`--gn-topic-id` argparse 영구화 매 publish마다 자동 발동. 14번째 검증으로 충분히 안정 단계 진입.

## cleanup 17회 연속 통과 (213~229차)

| 차수 | cleanup | 페이지 | 매칭 | PATCH |
|---|---|---|---|---|
| 213차 | (drift 복구로 skip) | - | - | - |
| 214차 | §3.31.1 89 PATCH | 1,934 | (전체) | 89 |
| 215차 | §3.32.1 1/18 | 1,925 | 18 (활성 1) | 1 |
| 216차 | §3.33.1 1/1 | 1,944 | 1 (활성) | 1 |
| 217차 | §3.33.1 1/12 | 2,030 | 12 (활성 1) | 1 |
| 218차 | §3.33.1 1/2 | 2,078 | 2 (활성 1) | 1 |
| 219차 | §3.33.1 1/3 | 2,090 | 3 (활성 1) | 1 |
| 220차 | §3.33.1 1/4 | 2,102 | 4 (활성 1) | 1 |
| 221차 | §3.33.1 1/18 | 2,114 | 18 (활성 1) | 1 |
| 222차 | (cleanup skip, 0건 매칭) | 2,114 | 0 | 0 |
| 223차 | §3.33.1 1/1 | 2,150 | 1 (활성) | 1 |
| 224차 | §3.33.1 1/2 | 2,200 | 2 (활성) | 1 |
| 225차 | §3.33.1 1/5 | 2,270 | 5 (활성) | 1 |
| 226차 | §3.33.1 1/2 | 2,294 | 2 (활성 1) | 1 |
| 227차 | §3.33.1 1/2 | 2,306 | 2 (활성 1) | 1 |
| 228차 | §3.33.1 0/0 (정상) | 2,318 | 0 | 0 |
| **229차** | **§3.33.1 1/9** | **2,375** | **9 (활성 1)** | **1** |

## gn_topic_id 박기 누적 17건 (218~229차 누적)

| 차수 | publish | gn_topic_id | 누적 |
|---|---|---|---|
| 218차 | #930 | 31218 | 1/11 |
| 218차 | #931 | 31225 | 2/11 |
| 219차 | #932 | 31221 | 3/12 |
| 220차 | #933 | 31224 | 4/12 |
| 221차 | - (retroactive 21건) | +21 | 25/26 |
| 222차 | #935 | 31227 | 26/27 |
| 223차 | #936 | 31239 | 27/28 |
| 224차 | #939 | 31219 | 28/29 |
| 225차 | #942 | 31231 | 29/30 |
| 226차 | #943 | 31251 | 30/31 |
| 227차 | #944 | 31266 | 31/32 |
| 228차 | #945 | 31265 | 32/33 |
| **229차** | **#946** | **31255** | **33/34** |

(221차 retroactive 21건 일괄 박기 덕분에 누적 17건이 아닌 33/34 = 97% 박기 완료 — 거의 완료 단계)

## 영구화 all-green 16종 통과 (229차)

| 패턴 | 차수 | 229차 결과 |
|---|---|---|
| §3.8.1 3-endpoint probe | 196차 | ✅ 200 OK 3/3 |
| §3.30.4 0단계 health check | 213차 | ✅ drift 0 (시작) |
| §3.34.10 feeds.feedburner.com RSS | 218차 | ✅ 50 entries |
| §3.34.11 5단계 dedup cron 직접 | 218차 | ✅ 10 fresh + 2 skip (정확도 100%) |
| **§3.34.24 .md 404 → HTML fallback** (227차) | 229차 | ✅ 9,081자 추출 |
| §3.23.1 frontmatter strip | 206차 | ✅ 1,559자 |
| §3.34.1 `tistory_publisher.py --file` | 217차 | ✅ CJK 825자 |
| §3.34.19 source footer 자동 | 221차 | ✅ 14번째 검증 |
| §3.32.2 cat_key 정규화 | 215차 | ✅ `normalize_cat_key('AI 뉴스')` → 'AI/ML' |
| §3.11 + §4 5-1 stats 보정 | 200차 | ✅ by_category['AI/ML']: 728→729 |
| §3.34.13 details에 gn_topic_id 박기 | 218차 | ✅ #946 (누적 33건) |
| §3.34.3 last_topics 0개 정리 | 217차 | ✅ 0건 |
| §3.33.2 `--record` 3개 인자 | 216차 | ✅ |
| §3.33.1 §3.32.1 cleanup | 216차 | ✅ 2,375 페이지 / 1/9 (활성 1) / PATCH 1/1 |
| §3.33.3 Blog DB ID grep | 216차 | ✅ 정상 추출 (7회째) |
| §3.5 3중 신호 검증 | 195차 | ✅ drift 0 (종료) |

## 229차 핵심 교훈

1. **§3.34.24 `.md` 404 환경 함정 3회째 (⭐⭐⭐ 영구화 시급)**: 227차 + 228차 + 229차 3회 연속 .md 404 → HTML fallback 정상 작동. **cleanup cron 임무 #12 (`scripts/gn-fetch-content.py`) 영구화 시급** — 3단계 fallback (`.md` → HTML → RSS) + None + skip 패턴 standalone 분리. 긱뉴스 측 마크다운 변환 기능의 영구 변경으로 추정.

2. **§3.34.11 5단계 dedup 7회째 (정확도 100%, 218~229차 누적)**: 12개 후보 → 10 fresh + 2 GN_TOPIC_ID skip. 박기 누적 33/34 (97%) 덕분에 skip 정확도 100% 유지. `blog_pipeline.py --category` stale fresh=true는 cron이 직접 feeds.feedburner.com RSS + 5단계 dedup으로 무력화 방어 중.

3. **§3.34.19 source footer 14번째 검증 (⭐⭐ 영구화 안정)**: 매 publish마다 자동 발동. 14번째 검증으로 충분히 안정 단계 진입.

4. **cleanup 17회 연속 통과 (213~229차)**: §3.33.1 §3.32.1 cleanup 17회 안정화. 229차에 2,375 페이지 / 31255 매칭 9건 (활성 1 + 비활성 8) / PATCH 1/1 정상.

5. **gn_topic_id 박기 누적 33/34 (97%)**: 221차 retroactive 21건 일괄 박기 덕분에 박기 누락 1건 잔여. **거의 완료 단계** — `scripts/retroactive-gn-topic-id.py` 1회 추가 실행으로 100% 도달.

6. **`blog_pipeline.py --category` stale fresh=true 검증**: 229차에 stale fresh=true 후보 (#31251 Weave Router, #31266 한글화) 발견 → 둘 다 gn_topic_id 매칭으로 5단계 dedup이 정상 skip. cron이 blog_pipeline.py 결과를 신뢰하지 않고 직접 RSS + 5단계 매칭 실행하는 패턴 정상 작동.

7. **stats 보정 정상 (`data` vs `items` 키 함정 우회)**: §3.34.25.8의 `data` vs `items` 키 함정 — 229차에 `r.json().get('items', r.json().get('data', []))` fallback 패턴 적용 → 정상. 1차 stats 보정 시도에서 가짜 발행 위험 차단.
