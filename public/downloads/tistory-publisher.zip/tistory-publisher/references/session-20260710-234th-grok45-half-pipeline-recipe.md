# 234차 (2026-07-10) — Grok 4.5 / half-pipeline + file publish + 5단계 수동 보정 recipe

> 세션 요약 + 본 세션에서 실전 검증된 클래스-레벨 패턴만 기록. 일회성 변수는 본문에서 제외.

## 1. 배경 / 트리거

- 크론 잡 `b1bca63a117a 📝 Tistory 자동 발행 (SEO+트렌드)` 발화 (234차)
- §3.8.1 세션 만료 가드 통과 (HTTP 200, application/json)
- 트렌드 12개 refresh 완료, 후보 score ≥5.0:
  - AI/ML: **Grok 4.5 공개 (31256, score 7.0)**, Maek (이미 #950 발행), ...
  - 개발도구: ts6to7 (31264), Chatto (31253)
  - 개발팁: Bun→Rust (31263), Uniqlo (31252)
- published_topics.json 검증: Maek(31259)·Davit(31243)·GPT‑Live(31254)만 박힘. **Grok 4.5 / Bun / Chatto / ts6to / Uniqlo 전부 fresh**.
- 오늘 AI/ML 1건 이미 발행(Maek), 그러나 quota 무제한 → 진행 OK.

## 2. 핵심 발견 — 클래스 레벨

### §A. `tistory_publisher.py --publish`는 존재하지 않는다
크론 프롬프트의 "1단계: 트렌드 → 2단계: `blog_pipeline.py --category`" 흐름은 **half-pipeline**임이 198차부터 확정.
- `blog_pipeline.py --category 'AI/ML'` → **guideline JSON만 출력** (실제 publish 안 함)
- `blog_pipeline.py --commit ...`은 **stats 박기 전담** (publish 자체는 안 함)
- **실제 publish는 `tistory_publisher.py --file /tmp/draft.md ...`로 명시 호출**해야 함
- `tistory_publisher.py`는 `--title` + (`--content` 또는 `--file`) + `--category` + `--tags` + `--image-query` + `--source-url` + `--gn-topic-id` + `--record-topic` 인자 필수

→ **234차 신규 영구화**: 셋 중 하나라도 빠지면 publish 자체가 fail 또는 stats 오염. 크론 워커는 본문을 직접 markdown으로 작성한 뒤 `--file`로 박는 것이 검증된 표준 패턴.

### §B. `tistory_publisher.py --record-topic`이 `details[-1].url = ''`로 박는 함정 — 5회째 영구 누적
이번 세션도 정확히 재현:
1. `tistory_publisher.py --record-topic "Grok 4.5 공개" "..." "" "https://news.hada.io/topic?id=31256"` 호출
2. publish는 성공, `https://sigco.tistory.com/951` 응답
3. 그러나 record 단계에서 `details[-1].url = ""` (빈 문자열) 박힘
4. `last.url`도 갱신 안 됨 (Last에는 박혔으나 `details`에는 미반영)
5. `published_urls.txt`에 `#951`도 누락

→ **231~234차 4회 연속** 동일 패턴. §3.11 5단계 heredoc 보정은 더 이상 임시방편이 아니라 **영구 워크플로의 일부**. SKILL.md 본문 헤더에서 "환경 의존" 표현은 obsolete — **반드시 매 세션 실행**.

### §C. gn_topic_id 포맷 이원화 — numeric vs title 혼재
`details[-1].topic` 필드 박기 패턴이 두 가지로 공존:
- **numeric (정상)**: `"31256"`, `"31254"`, `"31243"` (retroactive-gn-topic-id.py로 보정된 신규 박기)
- **title string (구형)**: `"Show GN: Lucene search core 기여 팀이 만든 Local-first AI Memory Workspace, Maek"` (233차 Maek 발행 시점)

원인: Maek은 retroactive 스크립트 도입 전 발행이라 title로 박힘. 231~234차 신규 발행분은 전부 numeric. cleanup cron 임무 #1 잔여 919 박기 누락분은 1회 실행 시 일괄 numeric화 가능 (`scripts/retroactive-gn-topic-id.py` — 단, 위치는 `~/.hermes/skills/automation/tistory-publisher/scripts/` 내부, 영구화 claim 거짓).

→ **234차 확인**: dedup 매칭은 numeric이든 title이든 prefix-30 매칭으로 동작 OK. 추가 보정 불필요.

### §D. §3.30.4 historical drift 가드의 올바른 동작
이번 세션 검증:
- `stats.total_published = 0` (raw)
- 실제 Tistory 글: 951건
- 차이: 951 박기 누락
- `len(details[url 박힌 것])` = 50

내가 한 작업: `stats.total_published = 50`으로 박기. **가짜 박기(951로 세팅) 안 함**. 이게 §3.30.4 가드가 의도한 "drift 그대로 두기" 동작. 232차 ~919 누락도 동일하게 처리. cleanup cron 임무 #1 실행 전까지는 drift가 정상 상태.

→ **234차 신규 영구화**: 매 세션 stats 보정 시 **절대 `total_published = tistory_max_id`로 박지 말 것**. 가짜 publish 가드 깨짐. `total_published = len(details with url)`로만 박기.

## 3. 실전 5단계 보정 recipe (234차 검증)

```bash
# Step 1: details[-1].url 보정
python3 << 'PYEOF'
import json
path = '/Users/mac/.hermes/memory/published_topics.json'
with open(path) as f:
    d = json.load(f)
det = d.get('details', [])
if det and not det[-1].get('url', '').strip():
    det[-1]['url'] = 'https://sigco.tistory.com/951'  # 실제 응답 URL
    det[-1]['topic'] = '31256'  # gn_topic_id numeric
with open(path, 'w', encoding='utf-8') as f:
    json.dump(d, f, ensure_ascii=False, indent=2)
PYEOF

# Step 2: stats 보정 (drift 가드 준수)
python3 << 'PYEOF'
import json
path = '/Users/mac/.hermes/memory/published_topics.json'
with open(path) as f:
    d = json.load(f)
stats = d.setdefault('stats', {})
det_count = len([x for x in d.get('details', []) if x.get('url', '').strip()])
stats['total_published'] = det_count  # 절대 tistory_max로 박지 말 것
today = '2026-07-10'
dc = stats.setdefault('daily_counts', {})
dc[today] = 1
bc = stats.setdefault('by_category', {})
bc['AI/ML'] = bc.get('AI/ML', 0) + 1
with open(path, 'w', encoding='utf-8') as f:
    json.dump(d, f, ensure_ascii=False, indent=2)
PYEOF

# Step 3: published_urls.txt 박기
echo "https://sigco.tistory.com/951" >> ~/.hermes/memory/published_urls.txt
echo "https://news.hada.io/topic?id=31256" >> ~/.hermes/memory/published_urls.txt
sort -u ~/.hermes/memory/published_urls.txt -o ~/.hermes/memory/published_urls.txt
```

또는 `scripts/post-publish-correct.sh` (205차 신규, 영구화 완료) 한 줄 실행:
```bash
bash ~/.hermes/skills/automation/tistory-publisher/scripts/post-publish-correct.sh \
  "Grok 4.5 공개" "https://sigco.tistory.com/951" 31256 AI/ML
```
→ **234차 권장**: 수동 heredoc 대신 `post-publish-correct.sh` 사용 (cleanup cron 임무 검증된 도구).

## 4. 환경 / 메트릭

- 세션 가드: ✅ OK (HTTP 200)
- 본문 길이: CJK 2,783자 (validate ≥300 OK, target 1,500~2,500 적정)
- 이미지: Picsum 2장 → Kakao CDN 업로드 87KB + 29KB
- OG 썸네일: https://blog.kakaocdn.net/dna/cluGnL/dJMcafm1l5A/... (자동 설정)
- Footer: `원본출처: 긱뉴스 — https://news.hada.io/topic?id=31256 (GN #31256)` 자동 박힘 (source footer 검증 19번째)
- cleanup cron: 22회 연속 all-green 예정 (213~234차, 본 세션 publish 0건 cleanup 영향 없음)

## 5. cleanup cron 임무 누적 현황 (234차)

| 임무 | 상태 | 비고 |
| --- | --- | --- |
| #1 박기 누락 919 (historical drift) | 잔여 | 240차 이전 1회 실행 시급. **본 세션은 실행 안 함** (drift 가드 의도된 동작 준수) |
| #12 gn-fetch-content.py 영구화 | **claim 거짓** | 스킬 디렉토리 내부에만 존재, `~/.hermes/scripts/`로 영구화 미완 |
| #15 historical drift health check (231차 신규) | 미구현 | 알림만 — 자동 실행은 가짜 publish 가드 깨질 위험 |
| retroactive-gn-topic-id.py 영구화 | **claim 거짓** | 232차 "영구화 시급성 최대"였으나 위치 검증 시급 |

## 6. 한 줄 결론

- 발행: **#951 "Grok 4.5 공개"** (AI/ML, CJK 2,783자, Picsum 2장, source footer 19번째)
- 본 세션 핵심 학습: **`tistory_publisher.py` 직접 호출 + `post-publish-correct.sh` 박기**가 검증된 표준. `blog_pipeline.py`는 guideline + stats 전담.
- 235차부터 적용: §3.11 5단계 보정을 SKILL.md 본문에서 "환경 의존 임시" → **"매 세션 영구 실행"** 표현으로 격상.
