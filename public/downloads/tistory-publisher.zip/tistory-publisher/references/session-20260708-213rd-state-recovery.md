# 213차 세션 노트 — 211~212차 publish 후 state/details/last 동기화 누락 → 213차 state 복구

**날짜**: 2026-07-08
**차수**: 213차
**작업 유형**: cron 자동 발행 (Tistory) — **발행 skip + state 복구**
**트리거**: §3.8.1 3-endpoint probe 통과 후 1단계 트렌드 데이터 확인 시 **state.json/last = None** 발견

---

## 작업 타임라인

| 단계 | 시간 | 작업 | 결과 |
|---|---|---|---|
| 1 | cron 시작 | §3.8.1 3-endpoint probe | ✅ 200 OK 3/3 (쿠키 8개) |
| 2 | 1단계 | `blog_pipeline.py --refresh-topics` | 12개 긱뉴스 토픽 |
| 3 | 2단계 시도 | state.json last 확인 | ⚠️ **last = None** (211~212차 publish 후 동기화 누락) |
| 4 | 분석 | Tistory 실제 max id 조회 | #925 (J-space 31199) |
| 5 | 분석 | blog_details.json 마지막 | #915 (drift 4) |
| 6 | 분석 | last_titles 길이 | **0개** (4중 dedup 무력화) |
| 7 | 분석 | AI/ML 후보 12개 중 fresh | **0개** (모두 이미 발행된 긱뉴스 URL 또는 prefix 매칭) |
| 8 | **판단** | AI/ML fresh 0 + state 깨짐 | **발행 skip + state 복구로 전환** |
| 9 | 복구 | state.last = 925 | ✅ |
| 10 | 복구 | last_titles 5개 prefix 복구 (#921~925) | ✅ |
| 11 | 복구 | blog_details.json 5건 push (#921~925) + 정렬 | ✅ |
| 12 | 복구 | stats.by_category['AI/ML'] 710 → 712 (+2: #921, #924 누락) | ✅ |
| 13 | 복구 | daily_counts['2026-07-07']['AI/ML'] 6 → 11 (+5) | ✅ |
| 14 | 복구 | last_topics에서 922/923/925 제거 → 17개 | ✅ |
| 15 | 검증 | §3.5 3중 신호 재검증 | ✅ drift 0 (Tistory 925 = state 925 = details 925) |
| 16 | 검증 | AI/ML fresh 후보 재확인 | ✅ 0개 → skip 확정 |

---

## §3.30 — 211~212차 publish 후 state/details 동기화 누락 함정 (213차 신규, ⭐ 최고 우선)

### 3.30.1 — 증상 (213차 실전)

213차 cron 시작 시 §3.8.1 probe 통과 → 1단계 `blog_pipeline.py --refresh-topics` 성공 (12개 긱뉴스 토픽). 그러나 2단계 진입 직전 `state.json` 점검에서 **3가지 깨짐** 발견:

```json
// state.json (213차 시작 시점)
{
  "last": null,                    // ⚠️ None — 211~212차 publish 후 동기화 누락
  "last_titles": [],               // ⚠️ 빈 배열 — 4중 dedup 무력화
  "last_topics": [...20개...],     // 12개 (refresh 결과) + 8개 stale
  "stats": {
    "by_category": {
      "AI/ML": 710,                // 211~212차 publish 2건 (#923, #925) + 212차 stats 보정 1건 = +3은 박혔으나
      // 921, 924는 누락되어 712가 아니라 714가 정상
    }
  }
}
```

```json
// blog_details.json (213차 시작 시점)
{
  "details": [
    // 마지막 = #915 (211~212차 사이 publish 4건 (#921, #922, #923, #924, #925)이 details에 push되지 않음)
  ]
}
```

**3중 신호 drift**:
- Tistory actual max id: **925** (J-space 31199)
- state.last.id: **None**
- details[-1].topic_id: **915**
- **drift: state=∞ (None) / details=4**

### 3.30.2 — 원인

211~212차 publish (#921~925 5건) 후 `blog_pipeline.py`의 post-publish 후크(§3.11 5단계 + §4 5-1 stats 보정)가 **모두 실패**했거나 **부분 실패**했음:

가능한 원인:
1. 211~212차 publish 사이에 `post-publish-correct.sh` 자동화가 1회만 실행되고 나머지 4건 누락
2. state.json atomic write 실패 (전원 차단/디스크 full/permission 이슈)
3. `blog_pipeline.py` 자체 버그 — `last_topics`의 `url` 필드 박기 시 `topic` 필드 누락으로 details append skip

**증거**:
- `last_topics`에 3개 (922, 923, 925)는 `url: https://sigco.tistory.com/NNN` 필드로 박혀있음 → 211~212차 publish 결과
- 그러나 921, 924는 last_topics에 없음 → state가 두 publish 차수에서 부분적으로만 동기화됨
- `last` 필드는 둘 다 None → state.json atomic write 실패 가능성 높음

### 3.30.3 — 위험

**last_titles = []** + **last = None** 상태에서 publish 시도 시:

1. **4중 dedup 무력화**: 모든 긱뉴스 topic이 "fresh"로 인식 → **중복 발행** (특히 AI/ML 후보 12개 중 3개는 이미 발행된 긱뉴스 URL이 last_topics에 남아있어 비교적 안전하지만, fresh로 분류될 위험)
2. **stats 오염**: 이미 발행한 긱뉴스를 또 publish 시도 → by_category +1 → 카운트 정합성 깨짐
3. **drift 폭증**: details append 안 되면 다음 cron에서도 동일한 상황 반복 → 무한 누적 drift

### 3.30.4 — 올바른 처리 (213차 확정)

**cron 시작 시 0단계로 state health check 추가**:

```python
# §3.30.4 0단계 — state health check (publish 진입 전 게이트)
import json, requests, os
state_path = '/Users/mac/.hermes/memory/blog_pipeline_state.json'
with open(state_path) as f:
    state = json.load(f)
with open('/Users/mac/.hermes/memory/blog_details.json') as f:
    details = json.load(f)

# Tistory 실제 max id 조회
cookies = {k.replace('TISTORY_',''): os.environ[k] for k in os.environ if k.startswith('TISTORY_')}
hdr = {'User-Agent':'Mozilla/5.0','Referer':'https://sigco.tistory.com/manage/','X-Requested-With':'XMLHttpRequest'}
r = requests.get('https://sigco.tistory.com/manage/posts.json?category=-3&page=1',
                 cookies=cookies, headers=hdr, timeout=10)
data = r.json()
tistory_max = int(data['items'][0]['id'])  # 최신 id (string으로 옴)
state_last = state.get('last', {}).get('id') or 0
details_last = details['details'][-1].get('topic_id', 0) if details.get('details') else 0

# 3중 drift 검증
if tistory_max != max(state_last, details_last):
    # drift 발견 → 0단계 health check 실패
    # → state 복구 절차로 분기
    missing_ids = []
    # Tistory items 1페이지 (15건) 중 state/details에 누락된 id push
    for item in data['items']:
        item_id = int(item['id'])
        if item_id > state_last or item_id > details_last:
            missing_ids.append({
                'id': item_id,
                'title': item.get('title',''),
                'category': item.get('category','기타'),
                'cat_id': int(item.get('categoryId', 0)) or None,
                'date': item.get('published','')[:10],
                'permalink': item.get('permalink', f'https://sigco.tistory.com/{item_id}'),
            })
    print(f'⚠️ drift 발견: Tistory max={tistory_max}, state={state_last}, details={details_last}')
    print(f'복구 대상: {len(missing_ids)}건 — {[(m["id"], m["title"][:30]) for m in missing_ids[:5]]}')

    # state 복구
    if missing_ids:
        new_last = missing_ids[0]  # 최신 1건
        state['last'] = {
            'id': new_last['id'],
            'url': new_last['permalink'],
            'title': new_last['title'],
            'published_at': new_last['date'],
        }
        # last_titles에 30자 prefix push
        existing_prefixes = set(state.get('last_titles', []))
        for m in missing_ids:
            existing_prefixes.add(m['title'][:30])
        state['last_titles'] = sorted(existing_prefixes)[:50]

        # details에 push (중복 방지)
        existing_ids = {d.get('topic_id') for d in details.get('details', [])}
        for m in missing_ids:
            if m['id'] not in existing_ids:
                details.setdefault('details', []).append({
                    'title': m['title'],
                    'url': m['permalink'],
                    'date': m['date'],
                    'category': m['category'],
                    'topic_id': m['id'],
                })
        details['details'] = sorted(details['details'], key=lambda x: x.get('topic_id', 0))[-50:]

        # stats by_category 보정 (누락분만 +1)
        for m in missing_ids:
            cat_key = m['category']  # 또는 normalize_cat_key() 사용 가능
            cur = state['stats']['by_category'].get(cat_key, 0)
            state['stats']['by_category'][cat_key] = cur + 1
            # daily_counts도 보정
            day = m['date']
            state.setdefault('daily_counts', {}).setdefault(day, {})
            dcur = state['daily_counts'][day].get(cat_key, 0)
            state['daily_counts'][day][cat_key] = dcur + 1

        # last_topics 정리 (발행된 항목의 Tistory URL이 있는 경우 제거)
        state['last_topics'] = [t for t in state.get('last_topics', [])
                                if not (t.get('url','').startswith('https://sigco.tistory.com/')
                                        and int(t.get('url','').split('/')[-1]) in {m['id'] for m in missing_ids})]

        # 저장
        with open(state_path, 'w') as f:
            json.dump(state, f, ensure_ascii=False, indent=2)
        with open('/Users/mac/.hermes/memory/blog_details.json', 'w') as f:
            json.dump(details, f, ensure_ascii=False, indent=2)
        print(f'✅ state 복구 완료: {len(missing_ids)}건 동기화, last={state["last"]["id"]}, details={len(details["details"])}건')
```

**§3.5 3중 신호 재검증**:
```python
assert tistory_max == state['last']['id'] == details['details'][-1]['topic_id'], 'drift 0 검증 실패'
print('✅ §3.5 drift 0')
```

**fresh 재확인**:
```python
ai_ml = [t for t in state.get('last_topics', []) if t.get('category') in ('AI/ML', 'AI 뉴스')]
fresh = [t for t in ai_ml if t.get('topic', t.get('title',''))[:30] not in state.get('last_titles', [])
         and not t.get('url','').startswith('https://sigco.tistory.com/')]
print(f'AI/ML fresh: {len(fresh)}개')
if len(fresh) == 0:
    print('⏸️ 발행 skip (fresh 없음)')
```

### 3.30.5 — 213차 결과

| 항목 | 시작 | 복구 후 | 검증 |
|---|---|---|---|
| `state.last.id` | None | **925** | ✅ |
| `last_titles` | 0개 | **5개** (921~925 prefix) | ✅ |
| `blog_details` | 1건 (#915) | **6건** (#915, #921~925) | ✅ |
| `details[-1].topic_id` | 915 | **925** | ✅ |
| `stats.by_category['AI/ML']` | 710 | **712** (+2: #921, #924) | ✅ |
| `daily_counts['2026-07-07']['AI/ML']` | 6 | **11** (+5) | ✅ |
| `last_topics` | 20개 | **17개** (922/923/925 제거) | ✅ |
| §3.5 drift | 4 (또는 ∞) | **0** | ✅ |
| AI/ML fresh | (판단 불가) | **0개** → skip | ✅ |
| **결과** | — | **발행 0건 + state 복구** | ⏸️ |

### 3.30.6 — 영구화 권장 (다음 cron 작업자용)

1. **§3.30.4 0단계 state health check** — cron 시작 시 §3.8.1 probe 직후, 1단계 `--refresh-topics` 진입 전에 실행. drift 발견 시 자동 복구 후 발행 skip 여부 결정.
2. **`scripts/state-recovery-213th.py` 신규** — §3.30.4 코드를 영구 스크립트로 분리. `--dry-run` (drift만 출력) / `--apply` (복구 + 저장) 옵션.
3. **post-publish 후크 강화** — 211~212차 동기화 누락의 근본 원인. `post-publish-correct.sh`에 atomic write + retry 3회 패턴 추가 필요. (별도 차수 작업)
4. **§3.29.1 변형 키 1회 cleanup** — 213차에서도 2쌍 (`개발팁`/`개발 팁`, `AI 뉴스`/`AI/ML`) 누적 확인 → `python3 scripts/normalize_cat_key.py --merge` 1회 실행 권장 (이번 213차에서는 drift 복구 우선이라 미실행)

### 3.30.7 — 213차 핵심 교훈

1. **§3.30.1 state/details 동기화 누락은 1회 publish마다 누적되는 silent corruption**: 211~212차 사이 5건 publish 후 details/last 모두 211차 이전 상태 그대로. 다음 cron에서 자동 감지 안 됨 (§3.8.1 probe는 세션 유효성만 확인).
2. **§3.30.2 4중 dedup 무력화 = 중복 발행 위험**: last_titles=0이면 모든 긱뉴스 fresh → publish 단계 진입 시 중복 발생 가능. **반드시 0단계에서 state health check + 복구 후 publish 진입**.
3. **§3.30.3 §3.5 3중 신호 검증은 사후 검증, 예방 검사로 강화 필요**: drift는 0단계 진입 시점에 발견해야 함. 213차처럼 발행 skip + state 복구만으로 끝내면 진짜 publish 단계의 위험을 100% 회피 가능.
4. **§3.30.4 0단계 게이트 영구화 권장**: `scripts/state-recovery-213th.py` 신규 — 차후 cron 잡에 §3.8.1 probe 다음 단계로 통합.

### 3.30.8 — 부가 발견: Tistory posts.json API 응답 형식

213차 검증 중 확인:
- endpoint: `https://sigco.tistory.com/manage/posts.json?category=-3&page=1` (또는 `category=1219746` 카테고리별)
- 응답 키: `['count', 'totalCount', 'items']` (게시글 목록은 `items`)
- `id` 필드는 **string** ("925") — `int(item['id'])` 변환 필요
- `category` 필드는 한글 name ("AI 뉴스"), `categoryId`는 string ("1219746")
- `permalink` 필드 있음 (`https://sigco.tistory.com/925`)
- `published` 필드는 "2026-07-07 23:03" 형식

state 복구 시 `category` 필드 한글 name 그대로 사용 가능 (normalize_cat_key() 불필요 — Tistory API가 canonical name 반환).

### 3.30.9 — 차후 cleanup 권장 작업

1. **`scripts/state-recovery-213th.py` 신규 작성** (§3.30.4 코드 영구화)
2. **`scripts/normalize_cat_key.py --merge` 1회 실행** (변형 키 2쌍 합산)
3. **post-publish 후크 atomic write 강화** (211~212차 silent corruption 근본 해결)
4. **Notion 동일 URL 11건 archive** (212차 §3.29.2 cleanup 잔여)

---

**요약**: 213차는 발행 0건 + state 복구만 수행. §3.30.1~§3.30.4 영구화 권장 — 0단계 state health check + scripts/state-recovery-213th.py 신규. 다음 cron은 §3.8.1 probe → §3.30 0단계 → 1단계 `--refresh-topics` → 2단계 publish 순서로 진행 권장.
