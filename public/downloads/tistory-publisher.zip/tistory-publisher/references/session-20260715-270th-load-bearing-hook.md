# 270차 세션 노트 (2026-07-15) — Claude 'load-bearing' MessageDisplay 훅

## 발행 결과

**✅ #1012 정상 발행** — `Claude가 'load-bearing'을 말하지 않게 만드는 방법 — MessageDisplay 훅으로 LLM 말버릇을 인프라 차원에서 걸러내기` (AI/ML/1219746, gn=31448, 7점, FRESH 1순위)

- 라이브 URL: https://sigco.tistory.com/1012
- title tag (실제): `Claude가 'load-bearing'을 말하지 않게 만드는 방법 &mdash; MessageDisplay 훅으로 LLM 말버릇을 인프라 차원에서 걸러내기`
- 라이브 페이지: status=200, size=64944 bytes

## 검증 매트릭스

| 항목 | 결과 |
|------|------|
| §3.8.1 가드 | ✅ status=200, ct=application/json;charset=UTF-8, cookie_count=8 |
| §3.34.43 PWD 보강 | ✅ PWD=/Users/mac |
| §3.34.40 FRESH 4-field | ✅ TOP 12개 중 2개 자정 사이 외부 발행 (31449, 31437) 이미 PUB 처리 → FRESH 잔여 10개 식별 |
| §3.34 #21 정책 | ✅ FRESH AI/ML 7 + 비-AI/ML 3 혼재 → AI/ML 1순위 (31448, 7점) 픽 — 254차 매트릭스 4번째 분기 |
| §3.34.46 gn-fetch-content | ✅ _try_md_endpoint(31448) → 1단계 `.md` endpoint 즉시 fetch |
| §3.34.47 격리 빌드 | ✅ /tmp/tistory_drafts_270th/build_draft_31448.py (6510 bytes, UTF-8 한글 + intro/conclusion + 4단계 헤더 강등 + `* ` 분기 모두 무영향) — 7회째 정착 |
| §3.34.48 `* ` 분기 + 4단계 강등 | ✅ 266차 정착 코드 그대로 복사 (270차 본문은 모두 `- ` 패턴이라 hit 안 했지만 안전 가드 포함) |
| §3.5 5중 신호 | ✅ state.last_published_url / state.last.url / state.details[-1].url / pt.last.url / pt.details[-1].url 모두 https://sigco.tistory.com/1012 일치 |
| post_publish_sync | ✅ pt_updated: true / state_updated: true / errors: [] / triple_signal_match: true |
| daily_counts[2026-07-15] | ✅ {'AI/ML': 4, '개발도구': 3, '개발팁': 1, '투자/경제': 1} (AI/ML 3→4, +1 정확, cat_id 누설 0) |
| state.details | ✅ 88→89 (+1) |
| pt.details | ✅ 104→105 (+1) |
| cleanup cron 임무 #16 | ✅ 56→57회 연속 all-green |
| 이미지 | ✅ Picsum ID 838, query: claude code hook message display replacement code terminal, 두 슬롯 모두 동일 ID 자동 매칭 |
| 본문 | ✅ 3375자 (검증 2217자, 300자 가드 통과) |

## §3.34 #21 AI/ML 우선 정책 실전 5호 매트릭스 검증

254차에 확정한 정책 우선순위 매트릭스:

| FRESH 후보 구성 | 결정 | 검증 차수 |
|----------------|------|-----------|
| 모두 '기타' | skip | 256차 1호 |
| '기타' + 'AI/ML' 혼재 | AI/ML 픽 (#21) | — |
| '기타' + 'AI/ML 외 다른 카테고리' 혼재 | 다른 카테고리 발행 허용 (#21 + '기타' 제외) | — |
| 'AI/ML' 단독 또는 'AI/ML' + 비-기타 혼재 | AI/ML 픽 (#21) | 255차 1호, **270차 2호** |
| 모두 'AI/ML 외 비-기타' | 점수 1순위 픽 (카테고리 균형, §3.34.39) | 266차 1호, 268차 2호, 269차 3호 |

270차는 4번째 분기 ("'AI/ML' + 비-기타 혼재 → AI/ML 픽") 실전 2호 검증. FRESH 10개 중 AI/ML 7개 (`31448 7점`, `31458 6점`, `31450 6점`, `31443 6점`, `31456 3점`, `31455 3점`, `31454 3점`) + 비-AI/ML 3개 (`31447 7점 개발도구`, `31457 7점 개발팁`, `31451 4점 개발팁`) → AI/ML 점수 1순위 `31448 (7점)` 정상 픽.

## §3.34.44 자정 사이 외부 발행 drift 무해 2호 검증

270차 사전 검증 시점:
- `state.last_published_url` = `https://sigco.tistory.com/1011` (269차 외부 발행 흔적, **자정 사이 발행**)
- `state.details[-1]` = `{'topic_id': 31449, 'title': 'Codex가 서브에이전트 프롬프트 암호화를 시작함 ...', 'url': 'https://sigco.tistory.com/1011', ...}` — 정상 sync 완료
- `pt.details[-1]` = 동일하게 `#1011`

TOP 12개 후보 중 2개 (`31449 Codex`, `31437 Precursor`) 가 이미 pt/state 양쪽에 정상 sync 된 상태 — 270차 cron 진입 시 FRESH 4-field 매칭이 12개 후보에서 10개 FRESH + 2개 already-published 를 정확히 식별.

§3.5 5중 검증 모두 일치 유지 → drift 무해 확정 (253차 식별 → 254차 1호 검증 → **270차 2호 검증**). cron 자동화 워크플로에서 "이전 cron 차 사이 한 건 이상의 발행이 일반화될 수 있다"는 사실이 다시 한번 확인됨. 코드 패치 불필요 — §3.5 5중 검증 + §3.11 sync 가 이미 drift-immune.

## 후속 차 참고

- cleanup cron 임무 #16: 57회 연속 all-green 유지
- 270차 신규 발견 없음 — 모든 기존 패턴(§3.8.1 / §3.8.2 / §3.5 / §3.11 / §3.34.39~48 / #21 / #22 / #25) 정상 동작
- §3.34.47 격리 빌드 패턴 7회째 정착 — 차후 본문 빌드도 동일 패턴 (`write_file` → `python3 <script>.py` 격리 호출) 적용 가능
- §3.34 #21 정책 매트릭스 4번째 분기 실전 2호 검증 완료 (270차)
- §3.34.44 자정 사이 외부 발행 drift 무해 2호 검증 완료 (270차)

## 빌드 스크립트 위치

- `/tmp/tistory_drafts_270th/build_draft_31448.py` (6510 bytes)
- `/tmp/tistory_drafts_270th/draft-31448-load-bearing.html` (생성된 HTML draft)

## publish 명령어

```bash
env -i HOME=/Users/mac PATH=/usr/bin:/bin PWD=/Users/mac /bin/bash -c '
set -a
source ~/.hermes/secrets/tistory.env
set +a
/usr/bin/python3 /Users/mac/.hermes/scripts/tistory_publisher.py \
  --title "Claude가 'load-bearing'을 말하지 않게 만드는 방법 — MessageDisplay 훅으로 LLM 말버릇을 인프라 차원에서 걸러내기" \
  --category 1219746 \
  --file /tmp/tistory_drafts_270th/draft-31448-load-bearing.html \
  --source-url "https://news.hada.io/topic?id=31448" \
  --gn-topic-id 31448 \
  --image-query "claude code hook message display replacement code terminal"
'
```

## post_publish_sync 명령어

```bash
env -i HOME=/Users/mac PATH=/usr/bin:/bin PWD=/Users/mac /bin/bash -c '
set -a
source ~/.hermes/secrets/tistory.env
set +a
/usr/bin/python3 /Users/mac/.hermes/skills/automation/tistory-publisher/scripts/post_publish_sync.py sync \
  --url "https://sigco.tistory.com/1012" \
  --title "Claude가 'load-bearing'을 말하지 않게 만드는 방법 — MessageDisplay 훅으로 LLM 말버릇을 인프라 차원에서 걸러내기" \
  --gn-topic-id 31448 \
  --category "AI/ML" \
  --category-id 1219746 \
  --source-url "https://news.hada.io/topic?id=31448"
'
```