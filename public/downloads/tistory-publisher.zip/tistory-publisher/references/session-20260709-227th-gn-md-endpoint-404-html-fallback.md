# 227차 세션 (2026-07-09): 긱뉴스 .md endpoint 404 + HTML fallback 신규

## 작업 타임라인

1. §3.8.1 3-endpoint probe: ✅ 200 OK 3/3 (Tistory max_id=943 시작)
2. §3.30.4 0단계 state health check: ✅ drift 0 (Tistory=943, state=943, details=24)
3. `--refresh-topics`: 12개 긱뉴스 토픽 (Grok 4.5 7점 / TypeScript 7 발표 4점 등)
4. §3.34.10 feeds.feedburner.com RSS fetch: 50 entries 정상
5. **§3.34.11 5단계 dedup cron 직접**: 25개 후보 명시적 매칭
   - 22 fresh (모두 5단계 모두 통과)
   - 3 skip (모두 GN_TOPIC_ID 매칭): #31251 Weave Router (#943), #31240 DNA 시퀀싱, #31239 Kokoro (#936)
6. `blog_pipeline.py --category 'AI/ML'`: 1순위 #31266 "고전 게임 한글화 에이전트 스킬" (false positive 없음)
7. **§3.34.24.1 발견**: `news.hada.io/topic.md?id=31266` 404 Not Found
8. **전수 점검**: RSS 25개 후보 모두 `topic.md` 404 → 긱뉴스 측 endpoint 변경
9. **§3.34.24.2 fallback 2 (HTML)**: `news.hada.io/topic?id=31266` 200 OK + 정규식 추출
   - `<script>` / `<style>` 제거
   - `<[^>]+>` 태그 제거 → 줄바꿈
   - HTML entity unescape
   - 1,478자 본문 확보
10. **가짜 발행 차단 가드**: 본문 추출 길이 200자 미만이면 fallback 3 (RSS) 시도, 전부 실패 시 발행 skip
11. §3.23.1 frontmatter strip + heredoc 본문 작성 (POSTEOF single-quoted)
    - CJK 1,265자 / validate 1,990자 / 4,728 bytes
    - Picsum 이미지 2장 (image 자동 삽입)
12. `tistory_publisher.py --file /tmp/post_227.md --source-url ... --gn-topic-id 31266` 발행 → #944
13. §3.34.19 source footer 12번째 검증 ✅ — 긱뉴스 URL footer 자동 박힘
14. §3.11 5단계 + §4 5-1 stats 보정 (heredoc — tistory_publisher.py 후크가 발동하지 않아 수동 보정):
    - state.last.id: 943 → 944
    - state.stats.total: 943 → 944
    - state.stats.by_category['AI/ML']: 726 → 727
    - daily_counts[today]['AI/ML']: 0 → 1
15. §3.34.13 details에 gn_topic_id 박기: #944 gn_topic_id=31266 (누적 15/25 = 60%)
16. §3.34.3 last_topics 0개 정리 (Tistory URL 항목 제거)
17. §3.33.1 §3.32.1 cleanup:
    - DB schema dump: status='상태', url='URL', title='이름' (한글)
    - 전체 query 2,306 페이지 (226차 2,294에서 +12)
    - 31266 URL 매칭: 2건 (활성 1 + 비활성 1)
    - PATCH 1/1 → 비활성화 ✅
18. §3.5 3중 신호 검증: ✅ drift 0 (944=944=944)
19. **213~227차 연속 15회 영구화 all-green 통과**

## 핵심 발견 (227차)

### §3.34.24.1 — 긱뉴스 `.md` endpoint 404

| endpoint | 226차 | **227차** |
|----------|-------|-----------|
| `news.hada.io/topic.md?id=N` | ✅ 200 OK | 🔴 **404 Not Found** |
| `news.hada.io/topic?id=N` (HTML) | ✅ 200 OK | ✅ 200 OK |
| `feeds.feedburner.com/geeknews-feed` | ✅ 200 OK | ✅ 200 OK (50 entries) |

**원인 가설**:
- 긱뉴스 측 글 자체는 살아있음 (RSS + HTML 페이지 모두 정상)
- `.md` 변환 endpoint만 일시적/지속적으로 막힘
- §3.29.4 패턴 무력화 — 22개 후보 본문 fetch 직접 실패 → 가짜 발행 위험
- 영구화 시급: cleanup cron 임무 #12 (gn-fetch-content fallback script)

### §3.34.24.2 — HTML `/topic?id=N` fallback

```python
import urllib.request, re, html

req = urllib.request.Request(
    f"https://news.hada.io/topic?id={topic_id}",
    headers={"User-Agent": "Mozilla/5.0"}
)
content = urllib.request.urlopen(req, timeout=15).read().decode('utf-8')
body = re.sub(r'<script[^>]*>[\s\S]*?</script>', '', content)
body = re.sub(r'<style[^>]*>[\s\S]*?</style>', '', body)
text = re.sub(r'<[^>]+>', '\n', body)
text = html.unescape(text)
text = re.sub(r'\n{3,}', '\n\n', text)
return text.strip()
```

**결과**: 1,478자 본문 확보 (성공)

### §3.34.24.2 3단계 fallback wrapper

```python
def fetch_gn_content_or_skip(topic_id):
    import urllib.error
    # 1단계: .md (있으면 가장 깨끗)
    try:
        req = urllib.request.Request(
            f"https://news.hada.io/topic.md?id={topic_id}",
            headers={"User-Agent": "Mozilla/5.0"}
        )
        return urllib.request.urlopen(req, timeout=10).read().decode('utf-8', errors='ignore')
    except urllib.error.HTTPError as e:
        if e.code != 404:
            raise
    # 2단계: HTML (가장 reliable — 227차 검증)
    html_text = fetch_gn_html(topic_id)
    if html_text and len(html_text) > 200:
        return html_text
    # 3단계: RSS content (fallback)
    rss_text = fetch_gn_rss_content(topic_id)
    if rss_text and len(rss_text) > 100:
        return rss_text
    # 4단계: 가짜 발행 차단
    return None
```

### 영구화 all-green 15종 + 신규 발견 1건

| 패턴 | 227차 결과 |
|---|---|
| §3.8.1 probe | ✅ 200 OK 3/3 |
| §3.30.4 health check | ✅ drift 0 시작 |
| §3.34.10 RSS | ✅ 50 entries |
| §3.34.11 5단계 dedup cron 직접 | ✅ 22 fresh + 3 skip |
| §3.34.24.1 .md endpoint 404 | 🔴 **신규 발견 — 22개 후보 모두 404** |
| §3.34.24.2 HTML fallback | ✅ 1,478자 추출 |
| §3.23.1 frontmatter strip | ✅ 1,990자 validate |
| §3.34.1 tistory_publisher.py --file | ✅ CJK 1,265자 |
| §3.34.19 source footer | ✅ 12번째 검증 |
| §3.32.2 cat_key 정규화 | ✅ 'AI 뉴스' → 'AI/ML' |
| §3.11 + §4 5-1 stats 보정 | ✅ by_category['AI/ML'] 726→727 |
| §3.34.13 gn_topic_id 박기 | ✅ #944 누적 15/25 |
| §3.34.3 last_topics 정리 | ✅ 0건 |
| §3.33.1 cleanup | ✅ 2,306 페이지 / 31266 매칭 2건 / PATCH 1/1 |
| §3.33.3 Blog DB ID grep | ✅ 정상 추출 (6회째) |
| §3.5 3중 신호 검증 | ✅ drift 0 종료 |

## cleanup cron 임무 누적 12개 (227차 신규 +1)

| # | 임무 | 우선순위 | 227차 상태 |
|---|---|---|---|
| 1~11 | (이전 11개 임무) | (이전) | (이전과 동일) |
| **12** | **`scripts/gn-fetch-content.py` 신규** (3단계 fallback wrapper) | **높음** | 🟡 잔여 (227차 임시 heredoc으로 운영) |

**227차 신규 임무 #12**: 긱뉴스 본문 fetch 통합 wrapper (.md → HTML → RSS) + 전부 실패 시 None 반환 + 발행 skip. 227차에 임시 heredoc으로 fallback 2 (HTML) 성공했으나 영구화 시급.

## 핵심 교훈

1. **`news.hada.io/topic.md` endpoint가 227차에 404 응답 — RSS는 정상 / HTML은 정상** = 환경 함정. §3.29.4 (212차 영구화) 패턴 무력화. 영구화: `scripts/gn-fetch-content.py` (cleanup cron 임무 #12).
2. **HTML `/topic?id=N` fallback으로 가짜 발행 차단**: 본문 1,478자 확보 → heredoc → `tistory_publisher.py --file` 발행 → #944 정상. fetch 결과 길이 200자 미만 → fallback 3, 전부 실패 → 발행 skip.
3. **§3.34.19 source footer 12번째 검증**: footer 영구화가 매 회차 안정. 12번째 검증으로 충분히 안정 단계 진입.
4. **§3.34.11 5단계 dedup 정확도 100%**: 박기 누적 15건 덕분에 GN_TOPIC_ID 매칭 정확 skip (3건 모두 정확).
5. **gn_topic_id 박기 누적 15/25 (60%)**: 매 publish마다 +1 박기. 잔여 10건 → retroactive cleanup 시 100% 도달.
6. **cleanup 15회 연속 통과**: 213~227차 풀 사이클 안정화.
7. **cleanup cron 임무 #12 신규**: `scripts/gn-fetch-content.py` — 본문 fetch 통합 wrapper. 다음 작업자용.
