# 가짜 발행(false-positive stats) 롤백 — 2026-06-26 발견

## 증상

`python3 ~/.hermes/scripts/blog_pipeline.py --category <CAT>` 실행 시:

1. stdout에 guideline JSON만 출력 (title_suggestions, seo_tips, publish_config 등)
2. **Tistory URL이 응답에 없음**
3. exit_code는 0
4. 그럼에도 `--status` 결과는:
   - `daily_counts["YYYY-MM-DD"][category]`: +1
   - `stats.total_published`: +1
   - `stats.by_category[category]`: +1
   - `last_topics` 마지막 항목: 방금 실패한 주제

## 원인

스크립트 흐름: **guideline 출력 → Tistory API 호출 → 성공 시 `record_published_topic()`**
- guideline 단계에서 통계 카운터 + last_topics가 먼저 박힘
- Tistory API 호출이 실패하거나 early-return해도 **롤백 로직이 없음**
- `record_published_topic`은 성공 URL을 받아야 호출되는데, 그 전에 실패하면 통계만 오염됨
- 진짜 발행 이력 (`published_topics.json`, `published_urls.txt`)은 깨끗 — 이게 진단 단서

## 진단 체크리스트 (가짜 발행 vs 진짜 발행 구분)

| 파일 | 진짜 발행 | 가짜 발행 (이 버그) |
|---|---|---|
| `blog_pipeline_state.json` `last_topics` | 마지막 항목 추가 | 마지막 항목 추가 (**오염**) |
| `blog_pipeline_state.json` `daily_counts` | +1 | +1 (**오염**) |
| `blog_pipeline_state.json` `stats.total_published` | +1 | +1 (**오염**) |
| `blog_pipeline_state.json` `stats.by_category` | +1 | +1 (**오염**) |
| `published_topics.json` `details` | 마지막에 추가됨 | **깨끗** (가짜면 없음) |
| `published_topics.json` `topics` (hash set) | hash 추가됨 | **깨끗** |
| `published_urls.txt` | Tistory URL 추가됨 | **깨끗** |

→ **status에서 카운터 증가했어도 published_topics.json의 마지막 details 항목에 없으면 가짜 발행**

## 롤백 레시피

```python
import json, shutil
from datetime import datetime
from pathlib import Path

state_path = Path("/Users/mac/.hermes/memory/blog_pipeline_state.json")

# 1) 백업
ts = datetime.now().strftime("%Y%m%d_%H%M%S")
backup_dir = Path(f"/Users/mac/.hermes/migration_fix_backup_{ts}_blog_rollback")
backup_dir.mkdir(parents=True, exist_ok=True)
shutil.copy2(state_path, backup_dir / "blog_pipeline_state.json.bak")

# 2) 실패한 주제 식별 (last_topics에서 동일 시각 항목들)
with open(state_path) as f:
    state = json.load(f)

failed_topics = [...]  # 중복 제목 리스트 (보통 같은 시각 다발)

# 3) 정리
today = datetime.now().strftime("%Y-%m-%d")
state["last_topics"] = [t for t in state["last_topics"] if t["topic"] not in failed_topics]
state["daily_counts"][today]["AI/ML"] = max(0, state["daily_counts"][today]["AI/ML"] - len(failed_topics))
state["stats"]["total_published"] -= len(failed_topics)
state["stats"]["by_category"]["AI/ML"] -= len(failed_topics)

with open(state_path, "w") as f:
    json.dump(state, f, ensure_ascii=False, indent=2)
```

## 검증 절차

롤백 후:

1. `python3 ~/.hermes/scripts/blog_pipeline.py --status` → 카운터 정상 복귀 확인
2. `tail ~/.hermes/memory/published_urls.txt` → 진짜 발행 URL 목록 (가짜건 없음)
3. `tail ~/.hermes/memory/published_topics.json` → 마지막 details = 진짜 발행 글

## 예방 (TODO)

스크립트 측 권장 수정: `run_pipeline()`가 Tistory API 실패 시 `state`를 롤백하는 try/except + finally 패턴. **현 구현은 미구현** (2026-06-26 기준). `published_topics.json`과 `blog_pipeline_state.json` 사이의 정합성을 마지막에 cross-check하는 safety-net 한 줄 (`if url_not_in_published_topics: state -= 1`) 추가하면 가짜 카운트 자동 차단 가능.

## 발견 세션

- **날짜**: 2026-06-26
- **환경**: M4 macOS, `/Users/mac`, cron 1시간 주기 발행 중
- **상황**: 주인님가 직접 발행 3회 연속 시도 → 모두 가짜 (같은 시각 15:12 다발)
- **복구**: 832건 → 829건으로 정상화, 백업 위치 `~/.hermes/migration_fix_backup_20260626_151643_blog_rollback/`
- **사용자 캐치 신호**: "가장최신 글은 오늘 14:59분에 올라온 글임" — status의 카운터와 실제 Tistory URL 목록이 불일치함을 주인님가 먼저 눈치챔

## 사용자 행동 패턴 메모

- 주인님는 **status 카운터를 실제 Tistory URL과 교차 검증**한다. 가짜 발행 패턴 발생 시 가장 빠른 진단은 "published_urls.txt 마지막 줄 시각"과 "blog_pipeline_state.json last_topics 시각" 비교.
- Tistory 블로그 자체를 직접 들어가서 "오늘의 마지막 글 시각"을 확인하는 것도 신뢰할 수 있는 1차 검증 수단.