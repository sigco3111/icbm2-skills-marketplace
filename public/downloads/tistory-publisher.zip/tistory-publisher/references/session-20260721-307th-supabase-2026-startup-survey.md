# 307차 — Supabase 2026 스타트업 현황 발행 (#1062)

**날짜**: 2026-07-21 05:01 (cron)
**결과**: #1062 발행 성공, 연속 all-green 87회차
**카테고리**: AI/ML (1219746)
**topic**: gn=31604 "Supabase가 조사한 2026년 스타트업 현황"

## 세션 타임라인

| 단계 | 명령/패턴 | 결과 |
|------|-----------|------|
| §3.8.1 가드 | `set -a; source tistory.env; unset PYTHONPATH PYTHONHOME; PYTHONNOUSERSITE=1; export PYTHONPATH=user-site; /usr/bin/python3 -s` heredoc | ✅ VALID (status=200, cookies=8, first_ids=['1061','1060','1059','1058','1057']) |
| 트렌드 새로고침 | `blog_pipeline.py --refresh-topics` | 12개 |
| AI/ML ready | `blog_pipeline.py --category 'AI/ML'` | status=ready, gn=31604 선정 |
| §3.5 (publish 전) | `check_state_consistency.py` | ⚠️ 신호 4 FAKE_PUBLISH 발동 (state.last=#1061, details[-1]=#1061, daily_counts={AI/ML:5}) |
| disambiguate proxy | #1061 status=200 + title 매칭 | ✅ 오탐 확정 (9연속) |
| build_post_307.py | `requests.get(gn_url) + og:description regex` 단일 패스 | 6952자, description 160자 추출 |
| publish | `tistory_publisher.py --file /tmp/post_307.html` | ✅ #1062 |
| §3.11 5-2 commit | stats today={AI/ML:6}, total=56 | ✅ |
| §3.11 5-3 patch | last_published_url+id+details append | details_len 133→135 |
| §3.11 5-2-A 백필 | placeholder 보정 0 + 누락 백필 2건 | pt_details_len=136 |
| §3.5 (publish 후) | 신호 4 발동 (오탐 10연속) | ⚠️ |
| §3.11 5-5 proxy | #1062 status=200 + og:title 매칭 | ✅ 진짜 발행 |

## 핵심 발견 — 함수 14 신규 (307차): `import os` 누락 → NameError

307차 첫 proxy check 호출에서 heredoc 첫 줄을 `import requests, re`로만 작성 → `os.environ` 참조 시 `NameError: name 'os' is not defined`로 즉시 실패.

**원인**: §3.8.1 가드 raw 검증 + §3.11 5-5 proxy check 두 곳의 heredoc은 모두 `os.environ`으로 TISTORY_* 쿠키를 읽어야 함. SKILL.md 본문에 명시된 정형 패턴은 `import os, requests, re`로 시작하나, 운영자가 두 모듈만 import하는 형태로 단축하면 즉시 실패.

**해결**: cron heredoc 첫 줄은 항상 `import os, requests, re` 세 모듈 포함.

```bash
# ❌ 307차 첫 시도 (실패)
set -a; source ~/.hermes/secrets/tistory.env; set +a
unset PYTHONPATH PYTHONHOME
PYTHONNOUSERSITE=1
export PYTHONPATH=/Users/mac/Library/Python/3.9/lib/python/site-packages
/usr/bin/python3 -s << 'PYEOF'
import requests, re   # ← os 누락
cookies = {k.replace('TISTORY_',''): os.environ[k] for k in os.environ if k.startswith('TISTORY_')}
...
PYEOF
# → NameError: name 'os' is not defined

# ✅ 정형 패턴 (즉시 패치 후 정상)
/usr/bin/python3 -s << 'PYEOF'
import os, requests, re   # ← 세 모듈 항상 첫 줄
cookies = {k.replace('TISTORY_',''): os.environ[k] for k in os.environ if k.startswith('TISTORY_')}
...
PYEOF
```

**운영 원칙**: cron heredoc 첫 줄은 `import os, requests, re`로 시작하는 것이 정형. SKILL.md 본문의 모든 heredoc 예제 (303차 안정 가드 raw 검증 + 5-5 proxy check)도 이미 이 패턴을 따르고 있으므로 정형 패턴 재사용 시 안전.

## 재확인된 패턴

- **303차 안정 raw 검증 패턴 307차 재확인**: `set -a; source tistory.env; unset PYTHONPATH PYTHONHOME; PYTHONNOUSERSITE=1; export PYTHONPATH=user-site; /usr/bin/python3 -s` 형태가 §3.8.1 가드에서 정상 작동. cookies=8, status=200, content_type=application/json 확인.
- **305차 단일 패스 빌드 패턴 307차 재확인**: `build_post_307.py` 안에 `requests.get(gn_url) + <meta property="og:description"> regex` 임베드 → 160자 description 추출 + Picsum 이미지 2장 + 본문 6952자 빌드를 한 패스로 통합. 함정 3 (긱뉴스 본문 selector 코멘트만) + 함정 6 (heredoc + env -i) + 함정 11 (`execute_code` cron 차단) 3중 회피.
- **신호 4 오탐 disambiguate 10연속 확정**: 298→307차 10연속 동일 패턴. `details[-1].slot == last_url.slot` 구조적 무조건 발동 → proxy check로 disambiguate하는 것이 정형 운영 패턴. drift 라인에 따로 명시 불필요.
- **함정 8 by_category["1219746"]=1 영구 잔존 10연속 재확인** (297→307 = 11차 동일 유지). 코드 동작 `=` 할당으로 첫 매핑 후 변동 없음. 사용자 게이트 시 1회 ID_TO_NAME 보정 권장, cron은 drift 보고만 유지.

## 운영 메트릭

- 307차 daily_counts={AI/ML:6}, total=56
- details_len: 133 → 135 (5-3 patch)
- pt_details_len: 134 → 136 (5-2-A 백필 2건)
- by_category 누적: "AI/ML": 755, "1219746": 1 (영구 잔존)

## 토픽 메타

- **topic_id**: 31604
- **title**: "Supabase가 조사한 2026년 스타트업 현황 — 풀스택 BaaS가 이끄는 새로운 개발 패러다임"
- **url**: https://sigco.tistory.com/1062
- **source_url**: https://news.hada.io/topic?id=31604
- **og:description**: "스타트업 빌더 2,000명을 조사한 결과, 2025~2026년 사이 창업자는 더 고령·비기술·1인 중심으로 바뀌었고 AI 작성 코드가 일반화됐으며 창업 지역도 넓어짐 Anthropic이 개발 도구·유료 구독·모델 공급자·에이전트 SDK에서 선두로 올라섰고, Claude Code 사용률…" (160자)
- **본문**: 6952자, Picsum 이미지 2장 (seed: supabase-2026-startup, baas-startup-trend)
- **tags**: Supabase, BaaS, 스타트업, AI통합, Postgres, Firebase, 인프라, LLM, 2026트렌드
- **OG 썸네일**: https://blog.kakaocdn.net/dna/bzSvQN/dJMcajiJt6V/AAAAAAAAAAA... (정상 설정)