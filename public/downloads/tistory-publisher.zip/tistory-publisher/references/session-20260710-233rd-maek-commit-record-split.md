# 233차 (2026-07-10) — Maek + commit_publish/record_published_topic 분기 함정

## 결과
- 발행 **#950 "Lucene 코어 기여 팀의 로컬-퍼스트 AI 메모리 워크스페이스 Maek"** 정상
- AI/ML 카테고리 1순위, gn_topic_id=31259, 본문 4575자 (validate 4082자), Picsum 2장, source footer 18번째 검증
- §3.8.1 세션 만료 가드 / §3.11 5단계 / §3.5 3중 신호 모두 ALL PASS
- cleanup 21회 연속 all-green (213~233차)

## 핵심 발견 1: cleanup cron 임무 #12 영구화 claim 거짓 — `scripts/gn-fetch-content.py` 경로 불일치
- **SKILL.md 헤더 (v2.7.81)**: "`scripts/gn-fetch-content.py` 영구화 완료" + "~/.hermes/scripts/gn-fetch-content.py"
- **실제**: `ls ~/.hermes/scripts/gn-fetch-content.py` → **No such file or directory**
- **실제 존재 위치**: `~/.hermes/skills/automation/tistory-publisher/scripts/gn-fetch-content.py` (스킬 디렉토리 내부만)
- **함정**: 헤더 claim을 신뢰하고 직접 호출 시도 시 `import` 실패 → 본문 추출 불가 → 발행 skip 가능
- **회피**: 호출 시 `~/.hermes/skills/automation/tistory-publisher/scripts/gn-fetch-content.py <topic_id>` (positional arg, `--topic-id` 아님)
- **같은 패턴 의심**: `scripts/retroactive-gn-topic-id.py`도 231차 헤더에 "영구화 시급성 최대" → cleanup cron 임무 #1 잔여. 실제 위치 검증 필요.

## 핵심 발견 2: §3.34.29 — `commit_publish` + `record_published_topic` 분기 함정 (NEW)
- **현상**: `tistory_publisher.py --file ...`로 발행 직후 `record_published_topic` 호출 안 됨 (별도 인자 구조). 사후 `--record-topic`도 작동 안 함.
- **결과**: `blog_pipeline_state.json`의 `last.id` / `details[-1].topic_id`는 직전 발행(#949 GPT-Live) 그대로, stats만 `commit_publish()` 호출로 +1.
- **구조적 원인**:
  - `record_published_topic()` (blog_pipeline.py L1823) → `published_topics.json` 갱신 (hash dedup용, last.details 구조 다름)
  - `commit_publish()` (blog_pipeline.py L1871) → `blog_pipeline_state.json` 갱신 (stats + daily_counts + last_topics만, **last/details는 안 건드림**)
  - **`last` / `details` 박기는 별도 heredoc 수동 작업 필요** (§3.11 5단계)
- **올바른 호출 시퀀스**:
  1. `tistory_publisher.py --file ... --category 1219746 --source-url ... --gn-topic-id ...` → URL 확보
  2. `commit_publish(topic, title, url, category, source_url)` → stats 박기
  3. **heredoc으로 직접** `state.last` / `state.details[-1]` 동시 append (Python `pathlib.Path(...).write_text(json.dumps(...))` 방식)
- **233차 보정 절차**:
  ```python
  state = json.loads(state_path.read_text())
  state['last'] = {"id": 950, "url": "https://sigco.tistory.com/950", "title": "...", "gn_topic_id": 31259, ...}
  state['details'].append({"topic_id": 950, "gn_topic_id": 31259, ...})
  state['details'] = state['details'][-50:]
  state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding='utf-8')
  ```
- **§3.30.4 자동 복구 가드 강화**: 232차에 health check historical drift 감지 추가됐지만, **단일 박기 누락은 여전히 수동 보정 필요**. cleanup cron 임무 #1 (누적 919) 실행 전까지 drift 누적.

## 검증 절차 (233차 실전)
1. **세션 만료 가드**: `set -a; source ~/.hermes/secrets/tistory.env; set +a` + Python 스크립트로 `/manage/posts.json` 200/JSON 응답 확인
2. **트렌드 갱신**: `python3 ~/.hermes/scripts/blog_pipeline.py --refresh-topics` → 12개 후보 (7 fresh + 5 skip)
3. **가이드 추출**: `python3 ~/.hermes/scripts/blog_pipeline.py --category 'AI/ML'` → topic, tistory_category_id, guidelines
4. **본문 추출**: `python3 ~/.hermes/skills/automation/tistory-publisher/scripts/gn-fetch-content.py 31259` → title, content_md (HTML fallback `article` 매칭 2940자), url
5. **HTML 빌드**: markdown → HTML 변환 + 섹션 헤더 + Picsum 2장 + source footer
6. **발행**: `tistory_publisher.py --file body.html --category 1219746 --tags "..." --source-url ... --gn-topic-id 31259 --image-query "..."` → `https://sigco.tistory.com/950`
7. **stats 보정**: `commit_publish(...)` 호출 → today.AI/ML +1, total 927
8. **last/details 박기**: heredoc으로 state.last + state.details 동시 append (cleanup cron 임무 #1 미해결 상태에서 수동)
9. **§3.5 3중 신호 검증**: 신호1(Tistory /950 200 + Maek/Lucene/31259 in body) + 신호2(state.last.id=950 + details[-1].topic_id=950) + 신호3(stats today.AI/ML >= 1 + total >= 927)

## cleanup cron 잔여 임무
- **#1 박기 누락 919** — 240차 이전 1회 실행 시급 (`scripts/retroactive-gn-topic-id.py` 영구화 + 박기 누락 일괄 보정)
- **#12 gn-fetch-content 영구화** — 헤더 claim 거짓. `~/.hermes/scripts/`로 복사 필요
- **#15 historical drift health check** — 231차 신규, 알림만 (자동 실행은 가짜 publish 가드 깨질 위험)

## 다음 세션 액션
1. cleanup cron 임무 #12 진짜 영구화 (헤더 claim 정합화)
2. cleanup cron 임무 #1 1회 실행 (박기 누락 919 일괄 보정)
3. §3.11 5단계 자동화 검토: `tistory_publisher.py`가 publish 성공 시 자동 `commit_publish` + last/details 박기 호출하도록 wrap