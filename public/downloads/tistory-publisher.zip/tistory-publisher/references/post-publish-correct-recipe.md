# Post-Publish Correct Recipe (211차 패치 적용, 200차 5단계 보정 heredoc + §3.28.1 한글 key 패치)

`tistory_publisher.py --file`로 publish 성공 후 **반드시 실행**할 stats/last_topics/details/published_urls.txt 4곳 동시 보정 heredoc. `--record-topic` 의존도 0.

> **211차 패치 (2026-07-07)**: §3.27.1 drift 측정 함정 발견 — 1페이지만 스캔 시 `tistory_total`이 15로 가짜 신호 출력. 검증 heredoc에 drift 라인 제거. §3.5 3중 신호만 신뢰.

## 트리거 조건
- `publish_post()` 출력 URL이 `https://sigco.tistory.com/NNN`이면
- Tistory max id (page1 top[0].id)와 local max (published_urls.txt의 max) 비교
- `remote_id == local_max + 1`이면 정상 발행 → **5단계 보정 heredoc 실행**

## 5단계 보정 heredoc (그대로 복사해서 사용)

```bash
set -a; source ~/.hermes/secrets/tistory.env; set +a
python3 << 'PYEOF'
import os, json, re, requests
cookies = {k.replace('TISTORY_',''): os.environ[k] for k in os.environ if k.startswith('TISTORY_')}
hdr = {'User-Agent':'Mozilla/5.0','Referer':'https://sigco.tistory.com/manage/','X-Requested-With':'XMLHttpRequest'}

# 1단계: Tistory max id (1페이지)
r = requests.get('https://sigco.tistory.com/manage/posts.json?category=-3&page=1',
                 cookies=cookies, headers=hdr, timeout=10)
top = r.json().get('items', [])[0]
remote_id = int(top['id'])
remote_title = top['title']

# 2단계: local max
urls_path = os.path.expanduser('~/.hermes/memory/published_urls.txt')
local_max = max([int(m.group(1)) for m in 
                 (re.search(r'tistory\.com/(\d+)', l) for l in open(urls_path)) if m] + [0])

# 3단계: 보정 필요 여부
assert remote_id == local_max + 1, f"비정상: remote={remote_id} local={local_max}"

# 4단계: state 갱신
state_path = os.path.expanduser('~/.hermes/memory/blog_pipeline_state.json')
with open(state_path) as f: state = json.load(f)
new_url = f'https://sigco.tistory.com/{remote_id}'
# (topic/topic_url/published_at은 caller가 직접 채워넣거나 placeholder 유지)
topic = os.environ.get('TISTORY_TOPIC', '<topic>')
topic_url = os.environ.get('TISTORY_TOPIC_URL', '<topic_url>')
state.setdefault('last_topics', []).append({
    'title': remote_title, 'url': new_url,
    'topic': topic, 'topic_url': topic_url,
    'category': 'AI/ML', 'published_at': '2026-07-06'
})
state['last_topics'] = state['last_topics'][-50:]
stats = state.setdefault('stats', {})
stats['total_published'] = stats.get('total_published', 0) + 1
stats.setdefault('by_category', {})['AI/ML'] = stats['by_category'].get('AI/ML', 0) + 1
stats.setdefault('daily_counts', {}).setdefault('2026-07-06', {})['AI/ML'] = \
    stats['daily_counts'].get('2026-07-06', {}).get('AI/ML', 0) + 1
stats['last_published_at'] = '2026-07-06T20:01'
state.setdefault('last_post', {}).setdefault('details', []).append({
    'title': remote_title, 'url': new_url, 'category': 'AI/ML',
    'published_at': '2026-07-06T20:01'
})
state['last_post']['details'] = state['last_post']['details'][-50:]
with open(state_path, 'w') as f:
    json.dump(state, f, indent=2, ensure_ascii=False)

# 5단계: published_urls.txt append
with open(urls_path, 'a') as f:
    f.write(f'{new_url}\t{remote_title}\t2026-07-06\tAI/ML\n')

print(f'✅ 보정 완료: #{remote_id} {remote_title[:50]}')
print(f'   stats.total_published: {stats["total_published"]}')
print(f'   last_topics[-1].url: {state["last_topics"][-1]["url"]}')
print(f'   details[-1].url: {state["last_post"]["details"][-1]["url"]}')
print(f'   daily_counts[2026-07-06][AI/ML]: {stats["daily_counts"]["2026-07-06"]["AI/ML"]}')
PYEOF
```

## 검증 heredoc (보정 후 즉시 실행) — 211차 §3.27.1 패치 적용

```bash
set -a; source ~/.hermes/secrets/tistory.env; set +a
python3 << 'PYEOF'
import os, json, re, requests
cookies = {k.replace('TISTORY_',''): os.environ[k] for k in os.environ if k.startswith('TISTORY_')}
hdr = {'User-Agent':'Mozilla/5.0','Referer':'https://sigco.tistory.com/manage/','X-Requested-With':'XMLHttpRequest'}
r = requests.get('https://sigco.tistory.com/manage/posts.json?category=-3&page=1', cookies=cookies, headers=hdr, timeout=10)
top = r.json().get('items', [])[0]
tistory_max = int(top['id'])
urls_path = os.path.expanduser('~/.hermes/memory/published_urls.txt')
with open(urls_path) as f:
    tistory_lines = [l for l in f if l.strip() and 'sigco.tistory.com' in l]
url_last = tistory_lines[-1].split('\t')[0].strip() if tistory_lines else ''
with open(os.path.expanduser('~/.hermes/memory/blog_pipeline_state.json')) as f: state = json.load(f)
state_last = state['last_topics'][-1]['url']

def extract_id(u):
    m = re.search(r'/(\d+)$', u.rstrip('/'))
    return int(m.group(1)) if m else 0

# §3.5 3중 신호 검증 (drift 라인 출력 안 함 — §3.27.1)
match = tistory_max == extract_id(state_last) == extract_id(url_last)
print(f'§3.5 3중 신호: Tistory {tistory_max} | state {extract_id(state_last)} | urls {extract_id(url_last)} | match={match}')
print(f'stats.total: {state["stats"]["total_published"]} | details[-1]: {state["last_post"]["details"][-1]["url"]}')
# 누적 drift는 별도 5페이지 routine (skipped here to avoid §3.27.1 false positive)
PYEOF
```

기대 출력 예 (200차 #907):
```
§3.5 3중 신호: Tistory 907 | state 907 | urls 907 | match=True
stats.total: 891 | details[-1]: https://sigco.tistory.com/907
```

## 사용 시 주의

- `topic`/`topic_url`/날짜는 caller가 환경변수 또는 heredoc에서 직접 주입
- 카테고리가 'AI/ML'이 아니면 heredoc 내 `'AI/ML'` 문자열을 해당 카테고리로 변경
- §3.8.1 3-endpoint probe로 세션 유효 먼저 확인 후 이 heredoc 실행
- heredoc 실행 후 §3.5 3중 신호 재검증 필수

## §3.18 보강 (201차 — half-pipeline 2건 연속 통과)

**Tistory `items[].id`는 문자열로 옴** — 위 heredoc들은 모두 `int(top['id'])` 캐스팅을 포함하므로 안전. 단, 변형 시 `max(ids)` 같은 호출을 추가하면 `TypeError: '>' not supported between instances of 'str' and 'str'` 발생. 반드시 `[int(it.get('id', 0)) for it in items if it.get('id')]` 형태 유지.

**half-pipeline 영구 워크플로 (201차 확정)**:
1. `blog_pipeline.py --refresh-topics` → 12개 토픽 로드
2. §3.8.1 3-endpoint probe (manage/posts.json 200 OK)
3. `blog_pipeline.py --category 'X'` → guidline + stats 사전 박기 (publish API 호출 안 함)
4. heredoc/cat heredoc으로 LLM 본문 작성 (1500~2500자)
5. `tistory_publisher.py --file <md> --title ... --category <id> --tags ... --image-query '...'` 호출
6. **이 5단계 보정 heredoc 실행** (Tistory 1페이지 fetch + int 캐스팅 + 4필드 동기화)
7. §3.5 3중 신호 검증

**201차 실전 결과**:
- Cross Entropy Loss #908 (AI/ML) + Art Institute API #909 (개발도구) 2건 연속 정상 발행
- §3.5 3중 신호 모두 일치, drift 0
- `tistory_publisher.py --record-topic` 호출 안 함 (5회 연속 환경 의존 패턴 회피)

**누적 drift 121 별도 cron 작업 권장** (199차 §3.16 재확인) — 이번 임무 외.

## §3.27.1 — 1페이지 스캔 시 drift 라인 출력 회피 (210차 신규, 211차 패치)

**함정**: 200차 확정 보정 heredoc의 검증 부분 끝에 `print(f'누적 drift: ...')` 같은 라인을 추가하면 `tistory_total = len(all_ids) = 15` (1페이지만 fetch) → 누적 drift 891 같은 가짜 신호 출력. 209차 §3.16 5페이지 스캔이 진짜 누적 drift 121을 산출.

**210차 실전 (수정 전)**:
```
📊 Tistory max id: 922 (scanned: 15)
📊 누적 drift: 891 (stats 906 - tistory_total 15)
```

**211차 패치 후 (현재)**: 검증 heredoc에서 drift 라인 제거 + §3.5 3중 신호만 출력. 누적 drift는 별도 5페이지 routine 사용.

**누적 drift 5페이지 routine (필요시 사용)**:
```python
# 5페이지 스캔으로 진짜 누적 drift 산출
all_ids = []
for p in range(1, 6):
    r = requests.get(f'https://sigco.tistory.com/manage/posts.json?category=-3&page={p}',
                     cookies=cookies, headers=hdr, timeout=10)
    if r.status_code != 200: break
    data = r.json()
    for it in data.get('items', []):
        try: all_ids.append(int(it.get('id', 0)))
        except: pass
    if not data.get('hasMore', data.get('has_more', False)): break
real_tistory_total = len(all_ids)
print(f'누적 drift (5페이지): {stats["total_published"] - real_tistory_total}')  # 진짜 수치
```

**단일 세션 drift 검증**: stats delta == 1이면 drift 0 (Tistory delta는 +1로 고정). 매 세션마다 검증 권장.

**211차 권장 사용 패턴**:
1. 위 5단계 보정 heredoc 실행
2. 위 검증 heredoc (211차 패치) 실행 → §3.5 3중 신호 match=True 확인
3. 누적 drift가 궁금하면 별도 5페이지 routine 실행 (필수 아님)

## §3.28.1 — stats 보정 시 한글 key 강제 (211차 신규 함정)

**함정**: 보정 heredoc 작성 시 Tistory 카테고리 int ID (`1219746`)를 `by_category`의 key로 직접 박으면 **가짜 통계 누적**. 실제 `stats.by_category`의 key는 **한글** (`'AI/ML'`, `'개발도구'` 등).

```python
# ❌ 211차 사용 (가짜 by_category['1219746'] = 17 박힘)
cat_id = '1219746'
state['stats']['by_category'][cat_id] = cur + delta  # 진짜 AI/ML (한글) 보정 누락

# ✅ 영구 패턴: Tistory int ID → 한글 카테고리 이름 매핑 후 사용
CAT_KEY_MAP = {
    '1219746': 'AI/ML',
    '1219747': '개발 팁',
    '1219748': '개발도구',
    '1219751': '기타',
    '1219752': '아이디어',
    '1219750': '투자&경제',
}
cat_key = CAT_KEY_MAP.get(str(cat_id), 'AI/ML')
state['stats']['by_category'][cat_key] = state['stats']['by_category'].get(cat_key, 0) + 1
state['daily_counts']['2026-07-07'][cat_key] = state['daily_counts'].get('2026-07-07', {}).get(cat_key, 0) + 1
```

**위 5단계 보정 heredoc은 이미 `'AI/ML'` 한글 key로 직접 박혀 있어 안전**. 단, 변형 시 int ID로 박는 경우 반드시 `CAT_KEY_MAP` 거치기. 211차에서는 `cat_id = '1219746'`로 별도 보정 코드 작성하다가 가짜 키 발생 → 즉시 제거 + 한글 key로 +1 보정 완료.

**영구화 권장 (다음 cron 작업자용)**:
1. 모든 stats 보정 heredoc 작성 시 한글 key 직접 사용 (`'AI/ML'`)
2. int ID가 필요한 경우 `CAT_KEY_MAP` 매핑 필수
3. 보정 후 검증: `print(list(state['stats']['by_category'].keys()))` → 한글 key만 보여야 정상
