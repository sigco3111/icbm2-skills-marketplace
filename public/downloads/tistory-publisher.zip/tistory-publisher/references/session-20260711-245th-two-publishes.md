# 245차 세션 노트 (2026-07-11) — 두 건 발행 + f-string §3.8.1 트랩

## 결과 요약

- 발행 2건: **#962 코딩 평가(signal/noise 분리) + #963 Microsoft Flint**
- 카테고리: 둘 다 AI/ML (cat_id 1219746)
- source: GeekNews topic 31291 + 31287
- daily_counts[2026-07-11]['AI/ML'] = 5 → **6** (정확 +2)
- cleanup cron 임무 #16 cat_id 누설 0 / 5중 신호 일치 OK
- 가짜 발행 가드 정상

## §3.34.41 신규 발견: §3.8.1 가드 heredoc의 f-string SyntaxError

### 증상

`/usr/bin/python3` (Python 3.9) 으로 격리 패턴 호출되는 §3.8.1 가드 heredoc이 SyntaxError로 즉시 실패:

```python
print(f"⏸️ SKIP: 알 수 없는 만료 패턴 status={r.status_code} ct={r.headers.get(\"content-type\",\"\")[:50]}")
```

→ `SyntaxError: f-string expression part cannot include a backslash`

이유: PEP 701 이전 (Python 3.9) f-string 내부는 단일 expression만 허용, 그 안에 `\"` 같은 백슬래시 quote 사용 불가.

### 영향

- 가드 단계 자체가 SyntaxError로 abort → "발행 0건 + 가드 미실행" 보고 → 본문 publish 단계로 잘못 진행될 위험 (가짜 발행 가드 무력화)
- 245차 첫 실행에서 hit, 곧바로 string concatenation `print("... status=" + str(r.status_code) + " ct=" + ct)` 로 재작성

### 245차 수정본 (SKILL.md 본문에 영구화)

```python
env -i HOME=/Users/mac PATH=/usr/bin:/bin /bin/bash -c '
set -a
source ~/.hermes/secrets/tistory.env
set +a
/usr/bin/python3 << "PYEOF"
import os, sys
sys.path.insert(0, "/Users/mac/Library/Python/3.9/lib/python/site-packages")
import requests
cookies = {k.replace("TISTORY_",""): os.environ[k] for k in os.environ if k.startswith("TISTORY_")}
print("cookie count:", len(cookies))
hdr = {"User-Agent":"Mozilla/5.0","Referer":"https://sigco.tistory.com/manage/","X-Requested-With":"XMLHttpRequest"}
r = requests.get("https://sigco.tistory.com/manage/posts.json?category=-3&page=1", cookies=cookies, headers=hdr, timeout=10, allow_redirects=False)
ct = r.headers.get("content-type","")[:50]
if r.status_code == 302 and "/auth/login" in r.headers.get("location",""):
    print("⏸️ SKIP: §3.8.1 세션 만료 (302 → /auth/login). 브라우저 쿠키 갱신 필요.")
elif r.status_code == 200 and "application/json" in r.headers.get("content-type",""):
    print("✅ OK: 세션 유효, 발행 진행")
else:
    print("⏸️ SKIP: status=" + str(r.status_code) + " ct=" + ct)
PYEOF
'
```

### 회피 패턴 3가지 (246차+ 가드 작성시 참고)

1. **변수 추출** (가장 안전): `ct = r.headers.get("content-type","")[:50]; print(f"... status={r.status_code} ct={ct}")`
2. **문자열 concatenation**: `print("... ct=" + r.headers.get("content-type","")[:50])`
3. **% formatting**: `print("... status=%s ct=%s" % (r.status_code, r.headers.get("content-type","")[:50]))`

### cleanup cron 임무 #18 후속 권장

- `scripts/guard_tistory_session_39safe.py` 신규 (3.9 호환 보장)
- 또는 SKILL.md §3.8.1 + §3.8.2 템플릿 일괄 audit (모두 string concatenation으로 정규화)
- `#18` cron 임무로 등록하여 247차+ 매 세션 3.9 제약 회피 검증

## 245차 발행 디테일

### #962 — 코딩 평가에서 신호와 잡음 분리하기

- topic_id: 31291
- source: https://news.hada.io/topic?id=31291 (OpenAI SWE-Bench Pro 30% 깨진 작업 분석)
- draft: /tmp/tistory_drafts_245/draft-31291-coding-eval.md (9295자)
- image-query: "coding evaluation benchmark chart abstract"
- Picsum 2장 CDN 업로드 OK
- 본문 구성: 원문 + 5가지 시사점 + 실무 적용

### #963 — Microsoft Flint AI 시각화 언어

- topic_id: 31287
- source: https://news.hada.io/topic?id=31287
- draft: /tmp/tistory_drafts_245/draft-31287-flint.md (7242자)
- image-query: "data visualization chart language Microsoft Flint"
- Picsum 2장 CDN 업로드 OK
- 본문 구성: 원문 + 왜 Flint가 중요한가 4가지 + 실무 적용

### 공통 워크플로

1. §3.8.1 가드 (수정본) → ✅ OK
2. §3.34.40 4-step: 후보 12개 추출 → FRESH 4-field 매칭 (FRESH: [31291, 31287, 31300, 31283, 31280, 31301, 31297], PUB: 5개)
3. §3.5 5중 신호 사전 검증 → ALL MATCH (#961)
4. gn-fetch-content.py 31291 / 31287 (각각 10171자 / 6982자)
5. markdown draft 작성 (write_file 대신 heredoc + open().write())
6. tistory_publisher.py --source-url + --gn-topic-id + --image-query + --category 1219746 명시 호출
7. post_publish_sync.py sync (7필드 보정) → pt_updated=true/state_updated=true
8. §3.5 5중 신호 사후 검증 → ALL MATCH (#963 → 마지막 발행 추적 확인)
9. cleanup 임무 #16 cat_id 누설 검증 → 0

## 다음 차 후속 (246차)

- 임무 #18 f-string 3.9 호환 정규화 패치 (선택)
- 임무 #1 retroactive-gn-topic-id 영구화 (historical drift ~920건 갱신 필요)
- 임무 #15 state.details drift health check 활성화 검토
