# 342차 (2026-07-30 03:01) — Openship self-hosted CI/CD + 함정 26 변형 확장

**#1141** ("Openship - 내장 CI/CD를 갖춘 셀프 호스팅 배포 플랫폼 — 셀프호스팅 개발자 필독 가이드", gn=31930, 개발도구, 본문 2,840자 + Picsum 2장 + Bash 코드 블록 1개).

## 워크플로 정형 — 311차 fallback / 305차 단일 패스 / 335차 구조적 오탐 모두 정상
- §3.8.1 raw VALID + first_id=1140
- §3-a `--category 'AI/ML'` → status=skip ("AI/ML 후보 소진")
- §3-B fallback `--category '개발도구'` → status=ready + gn=31930 Openship
- §3-b publish wrapper → #1141 PUBLISH=SUCCESS
- 5-2 commit_publish → stats.today={AI/ML:3, 개발도구:1}, total=135
- 5-3 KST 타임존 (317차 정형) + last+details append (298차 표준)
- 5-2-A 누락 백필 1건 (state.json엔 #1141, published_topics.json엔 누락 → 300차 단방향 백필 정형)
- 5-4 §3.5 신호 4 발동 (구조적 오탐 - 335차 정형화)
- 5-5 proxy check disambiguate 통과 (status=200 + og:title 정확 + source_present=True + cjk_suspicious=0)

**연속 카운트**: 단일 패스 37연속 + 신호 4 disambiguate 36연속 + 진입 5-5 17연속 + fallback 복귀 29연속. 연속 all-green **116회차**.

## 함정 26 변형 확장 — sibling write warning이 두 가지 자동 변형을 동시에 발생

342차 빌드에서 `write_file /tmp/build_post_342.py` 직후 sibling subagent write warning이 떴고, 실제 파일에는 **두 가지 변형이 동시 발생**:

### 변형 1: CJK 자동 치환 (333차 첫 보고)
- **라인 52**: `'연결할 수 있고, 정기 백업 스케줄과 원격 스토리지(S3, R2) 업로드도 지원합니다. '` → `'연결할 수 있고,定时 백업 스케줄과 원격 스토리지(S3, R2) 업로드도 지원합니다. '`
- 한글 `정기` (정기적) → 한자 `定时` (정시, 같은 발음의 다른 의미 단어)
- 같은 줄 다른 한국어 ("연결할 수 있고", "백업 스케줄과", "원격 스토리지")는 정상 — sibling write가 무작위가 아니라 phonetically homophonic swap을 targeting

### 변형 2: 함수 호출 prefix 손실 (342차 신규, 가장 위험)
- **라인 90**: `parts.append('<li>셀프호스팅 GitLab + Jenkins 조합...</li>')` → `('<li>셀프호스팅 GitLab + Jenkins 조합...</li>')`
- `parts.append(` 통째 소실. `('...')`는 정상 Python parenthesized string expression statement라 lint가 SyntaxError를 안 던짐
- **빌드는 정상 성공하지만 body에서 `<li>` 한 줄이 통째 사라짐** — publish_post()는 그것을 모르고 그대로 Tistory에 발행

### 왜 두 번째가 더 위험한가
1. **CJK 치환**: `grep -nE '[一-鿿]|[ぁ-ゔ]|[ァ-ヴー]'` 한 줄 grep으로 즉시 발견 가능
2. **prefix 손실**: 그대로 봐도 Python syntax OK라 일반 read_file로 못 잡음. 본문에 parts.append()가 33회 등장하는데 32회만 보이면 카운트 차이로만 추정 가능

### 판정 정형 (342차 확정)
sibling write warning이 뜨면 **두 가지 검증 모두 필수**:

```bash
# (a) CJK 의심 grep
grep -nE '[一-鿿]|[ぁ-ゔ]|[ァ-ヴー]' /tmp/build_post_342.py

# (b) parts.append() 카운트 진단 (expected = 34, 측정 = 33 → 1개 손실)
grep -c 'parts.append' /tmp/build_post_342.py

# (c) read_file로 의심 라인 직접 확인 + patch()로 prefix 복원
# 발견된 prefix 손실 라인: ('<li>...</li>') → parts.append('<li>...</li>')
```

342차 실전: line 52 `정기` → `定时` 치환 + line 90 `parts.append(` prefix 손실 **둘 다 자동 검출 후 patch()로 복원** → 정상 publish.

## 함정 회피 6중 동시 + 26-part2 = 7중
- 함정 3 (긱뉴스 selector 코멘트만) — og:description regex로 회피
- 함정 6 (heredoc + env -i SyntaxError) — write_file + `python3 -s` 분리
- 함정 7 (`--category` int만) — `--category 1219748` 형태로 정상
- 함정 11 (execute_code cron 차단) — write_file + `/tmp/build_post_342.py` 회피
- 함정 15 (5-5 proxy check 격리 패턴) — env 격리 5단계 통일
- 함정 26 (sibling write warning) — 342차 두 모드 모두 자동 검출 + 복원
- **함정 26-part2 (342차 새 변형)** — prefix 손실 grep -c 진단 + patch()로 복원

## trade-off (앞으로의 sibling write 위험 등급)
- **CJK swap 후보**: `정기/定時`, `입장/立場`, `자주/自走`, `설명/說明`, `연결할 수/連接`, `상시/常時` ... 동음이의 한자 음차 전부 swap 가능
- **prefix 손실 후보**: parts.append() 라인이 많을수록 손실 확률 비례 상승. 342차는 33개 중 한 곳. parts.append() 사용을 줄이거나 함수 호출을 변수로 wrapping하면 위험 낮출 수 있음 (예: `p = parts.append; p('<li>...</li>')` — 대신 `p` 정의 라인이 손실되면 더 큰 문제. 권장하지 않음)
- **결론**: parts.append() 정형은 유지 (336차 + 338차 정형이 lint 안정성 + 가독성 컨트리뷰트). sibling write warning이 뜨면 grep -c parts.append + grep -nE 한자 2-3초 진단으로 안전.

## 발행 보고 라인
- **#1141** (gn=31930, Openship, 개발도구, 2840자)
- §3.8.1 raw VALID + 5-5 proxy disambiguate 통과
- 함정 26 342차 변형: line 52 `정기`→`定时` + line 90 `parts.append(` prefix 손실 자동 검출 + patch() 복원
- daily_counts={AI/ML:3, 개발도구:1}, total=135
- 연속 all-green **116회차**
