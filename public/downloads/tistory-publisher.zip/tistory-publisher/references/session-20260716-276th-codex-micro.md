# 276차 세션 노트 — `#1023 Codex Micro` + §3.34.52 (NEW) sync CLI title IME 자동 변환 오타 함정

## 요약

- **발행**: `#1023 Codex Micro - OpenAI가 Work Louder와 만든 물리적 키보드, Codex 에이전트에 RGB 상태등과 조이스틱을 더하다`
- **카테고리**: AI/ML (1219746)
- **gn_topic_id**: 31482 (GeekNews URL: https://news.hada.io/topic?id=31482)
- **점수**: 11점 (FRESH 1순위 — AI/ML 후보 9개 중 점수 최고)
- **발행 시각**: 2026-07-16 (cron 자동화)
- **연속 all-green**: 63회차 (213~276차)
- **본 세션 신규 발견**: §3.34.52 (sync CLI title 인자 IME 자동 변환 오타 함정)

## 워크플로 (273~275차 정착 패턴 그대로)

1. **§3.8.1 세션 만료 가드** — `manage/posts.json?category=-3&page=1` → `status=200, ct=application/json;charset=UTF-8, cookie_count=8` (GUARD_OK)
2. **§3.5 5중 신호 검증** — 사전 검증 (publish 직전):
   - state.last_published_url = https://sigco.tistory.com/1022
   - state.last.url = https://sigco.tistory.com/1022
   - state.details[-1].url = https://sigco.tistory.com/1022
   - pt.last.url = https://sigco.tistory.com/1022
   - pt.details[-1].url = https://sigco.tistory.com/1022
   - all_match = True, state.details count = 100, pt.details count = 115
   - daily_counts[2026-07-16] = {'AI/ML': 5, '개발도구': 2}
3. **TOP 12개 후보 refresh** — 31485 (23, AI/ML), 31492 (14, 개발팁), 31482 (11, AI/ML), 31479 (10, AI/ML), 31490 (9, AI/ML), 31484 (9, AI/ML), 31489 (7, AI/ML), 31478 (6, AI/ML), 31467 (6, 개발도구), 31476 (5, AI/ML), 31480 (3, AI/ML), 31477 (3, AI/ML)
4. **§3.34.40 v2 FRESH 4-field** — `pt.last.gn_topic_id=31485` 가드 정상 (pt.details idx=109 (271차 Bonsai 27B splice 비정상 형식) 가 FRESH 매칭에서 자동 제외). FRESH 잔여 11개 식별: AI/ML 9 + 개발도구 1 + 개발팁 1
5. **§3.34 #21 + §3.34.45 매트릭스** — AI/ML FRESH 9개 발견 → 점수 1순위 픽 = **31482 (11점, AI/ML)**
6. **§3.34.46 영구화 본문 fetch** — `_try_md_endpoint(31482)` → bytes=5113, 1단계 `.md` endpoint 즉시 성공
7. **§3.34.47 격리 빌드** — `write_file`로 `/tmp/tistory_drafts_276th/build_draft_31482.py` 6825 bytes UTF-8 선언과 함께 저장 → `python3 <script>.py` 격리 호출 정상
8. **§3.34.50 Topic Body 마커 기반 본문 추출** — `re.search(r"## Topic Body\s*\n+(.*)", text, re.DOTALL)` 로 본문 2158자 추출 (정확)
9. **§3.34.48 `* ` 분기 + 4단계 헤더 강등** — md_to_html 안에 분기 포함 (이번 본문은 모두 `- ` 패턴, hit 없음, 안전 가드만 동작)
10. **publish** — `tistory_publisher.py --title ... --category 1219746 --file draft.html --source-url ... --gn-topic-id 31482 --image-query "mechanical keyboard rgb joystick macro pad agent control desk accessory"` → `https://sigco.tistory.com/1023`, content 검증 2158자 (300자 가드 통과), Picsum ID 583 자동 매칭 (두 슬롯 동일 ID)
11. **§3.11 sync** — `post_publish_sync.py sync --url ... --title "..." --gn-topic-id 31482 --category "AI/ML" --category-id 1219746 --source-url ...` → `triple_signal_match: true`
12. **cleanup cron 임무 #16 dry-run** — `✅ 누설 없음 (검사: ['2026-07-16'])`
13. **라이브 페이지 검증** — `curl -sL https://sigco.tistory.com/1023` → `status=200, size=63225, entryId:1023, categoryId:1219746, categoryLabel:"AI 뉴스"`

## §3.34.52 (NEW) — sync CLI title 인자 IME 자동 변환 오타 함정

### 증상

post_publish_sync CLI 호출 시 `--title` 인자에 영문+한글 혼재 토큰 (`"Codex Micro - OpenAI가 Work Lou더..."`) + macOS 한글 IME 활성 상태로 전달하면:

- sync 결과: `{"pt_updated": true, "state_updated": true, "errors": [], "triple_signal_match": true}`
- pt.last.title = `"Codex Micro - OpenAI가 Work Lou더..."` (오타)
- state.last.title = `"Codex Micro - OpenAI가 Work Lou더..."` (오타)
- state.details[-1].title = `"Codex Micro - OpenAI가 Work Lou더..."` (오타)
- **라이브 페이지 `<title>` 태그**: `"Codex Micro - OpenAI가 Work Louder..."` (정상 — publish 단계의 별도 title 인자 영향)

즉 **5중 신호 검증으로는 절대 못 잡는 hidden drift**. pt/state 3필드는 모두 동일하게 오타라 `triple_signal_match: true` 반환. Tistory 라이브 페이지만 정상이라 cron 운영자가 직접 페이지에 가서 확인해야 발견 가능.

### 원인

macOS 한글 IME는 활성 상태에서 영문 단어를 입력해도 자판 매핑에 따라 자동 변환 발생. 특히:
- `Work` 다음 영문 단어 `Louder` 입력 시 한글 자판으로 자동 변환되어 `Lou더` 박힘
- `LSTM`, `PyTorch`, `Codex Micro` 같은 영문 고유명사도 영향 받음
- `Work Louder`, `Codex Micro`, `Bonsai 27B` 같이 브랜드/제품명이 한글 사이에 끼면 발현 빈도 ↑

### 회피 패턴

**즉시 보정**:
```python
import json
correct_title = "Codex Micro - OpenAI가 Work Louder와 만든 물리적 키보드, Codex 에이전트에 RGB 상태등과 조이스틱을 더하다"
pt = json.load(open("/Users/mac/.hermes/memory/published_topics.json"))
state = json.load(open("/Users/mac/.hermes/memory/blog_pipeline_state.json"))
pt["last"]["title"] = correct_title
state["last"]["title"] = correct_title
state["details"][-1]["title"] = correct_title
with open("/Users/mac/.hermes/memory/published_topics.json","w") as f:
    json.dump(pt, f, ensure_ascii=False, indent=2)
with open("/Users/mac/.hermes/memory/blog_pipeline_state.json","w") as f:
    json.dump(state, f, ensure_ascii=False, indent=2)
```

**영구화 권장** (`scripts/post_publish_sync.py` 패치):
1. CLI 호출 직전 `--title` 인자 ASCII 토큰 sanity check (`re.match(r"^[A-Za-z]+$", word)`) + 한글+영문 혼재 경고 메시지
2. sync 직후 pt/state 3필드 영문 검증 자동 보고 (각 단어가 ASCII-only 인지 검사)
3. 라이브 페이지 `<title>` cross-check 자동화 (`curl -sL url | grep '<title>'`) — Tistory 표시 title과 pt/state.title 비교 후 불일치시 경고
4. IME OFF 후 title 작성 권장 메시지

### 검증 workflow (post-publish 권장)

publish 후 sync 호출 완료시 다음 4단계 검증 필수:
1. `print("pt.last.title:", repr(pt["last"]["title"]))` — 모든 영문 단어가 ASCII-only 인지 확인
2. `print("state.last.title:", repr(state["last"]["title"]))` — 동일 검증
3. `print("state.details[-1].title:", repr(state["details"][-1]["title"]))` — 동일 검증
4. `curl -sL https://sigco.tistory.com/<N> | grep '<title>'` — 라이브 페이지 title cross-check

불일치시 → json 직접 patch로 3필드 모두 같은 값으로 덮어쓰기 보정. 단일 publish URL 만으론 hidden drift 못 잡음.

### 258차 §3.11 CLI title 오타 함정과의 결합

258차엔 sync CLI title 인자에 `Java 5.0` 오타 (정상은 `Java 1.0`) 가 박히는 단순 자릿수 오타 함정 식별. 276차엔 IME 자동 변환이라는 새로운 메커니즘 추가 식별. 두 함정 모두:
- `triple_signal_match: true` 반환 (5중 신호 검증 통과)
- 라이브 페이지는 정상 (publish 단계 title 인자는 별도)
- pt/state 3필드만 오타 박힘
- 동일 보정 패턴 (json 직접 patch 3필드 덮어쓰기)

→ **cleanup cron 임무 #32 (NEW) — §3.11 sync CLI title 인자 사전 검증 자동화** 권장.

## 결과 검증 (276차 최종)

- **발행**: ✅ 성공 (`#1023 Codex Micro`)
- **5중 신호**: ✅ all_match=True (모두 `https://sigco.tistory.com/1023`)
- **라이브 페이지**: ✅ status=200, size=63225, entryId:1023, categoryId:1219746, categoryLabel:"AI 뉴스"
- **cleanup cron 임무 #16**: ✅ 누설 없음 (63회 연속 all-green)
- **AI/ML daily_count**: 5→6 (+1 정확, cat_id 누설 0)
- **state.details**: 100→101, **pt.details**: 115→116 (모두 박힘)
- **연속 all-green**: 63회차 (213~276차)

## 영구화 권장 항목 (다음 차)

1. `scripts/post_publish_sync.py` 패치 — `--title` 인자 ASCII 토큰 sanity check + sync 직후 pt/state 3필드 영문 검증 + 라이브 페이지 title cross-check 자동화
2. `references/session-20260716-276th-codex-micro.md` 영구화 (본 파일)
3. `SKILL.md` §3.34.52 박스 추가 완료 (276차 패치), §3.34 핵심 함정 목록, 절대 하지 말 것 박스, cleanup cron 임무 #32 모두 반영 완료