# 263차 — 2026-07-14 — "2026년에 왜 코드를 작성하는가"

## 발행 결과
- **글 #**: 999
- **제목**: `2026년에 왜 코드를 작성하는가 — AI 에이전트 시대에도 코드를 만져야 하는 5가지 이유`
- **카테고리**: AI/ML (1219746)
- **gn_topic_id**: 31411
- **점수**: 9.0 (FRESH AI/ML 후보 중 1순위)
- **URL**: https://sigco.tistory.com/999
- **본문**: 3311자 (검증 통과, 300자 가드 OK)
- **라이브 페이지**: status=200, size=57991, title tag 정상
- **이미지**: 2장 (Picsum ID 782, query: software engineer code editor terminal abstract factory)

## §3.34.40 FRESH 4-field + §3.34 #21 AI/ML 우선
- TOP 12개 후보 중 2개 (31404 GPT-5.6, 31397 saaskr MCP) 이미 261~262차 PUB 처리
- FRESH 잔여 10개: 개발도구 3 + AI/ML 4 + 개발팁 1 + 투자/경제 1
- FRESH AI/ML 4개: 31411 (9점), 31406 (8점), 31424 (6점), 31407 (4점)
- #21 정책으로 AI/ML FRESH 점수 1순위 `31411` 픽

## §3.34.47 신규 함정 (263차 식별)

**증상**: `env -i HOME=... PATH=... /bin/bash -c '... /usr/bin/python3 << "PYEOF" ... PYEOF'` 형태의 inline bash heredoc 안에서 길이 30줄+ 본문 빌드/HTML 변환 스크립트를 적을 때, §3.34.41 f-string 백슬래시 제약 + 본문 안 `\"` escape + 한글 UTF-8 본문 문자열이 한꺼번에 걸려 `SyntaxError: Non-UTF-8 code starting with '\xec'` 가 먼저 터지거나 `SyntaxError: f-string expression part cannot include a backslash` 가 연쇄 발생.

**263차 첫 시도 hit 지점**:
```python
# ❌ inline heredoc 안 — §3.34.47 hit
out.append(f"<{tag}>{html.escape(item_text.split(\" \",1)[1])}</{tag}>")
# 위 라인이 §3.34.41 f-string + escape + 한글 본문 컨텍스트에서 SyntaxError
```

**회피 패턴 (영구화)**:
```python
# ✅ 우회 1: f-string 안 split 제거 (string concat)
tag = "h2" if item_text.startswith("## ") else "h3"
rest = item_text.split(" ", 1)[1] if " " in item_text else ""
out.append("<" + tag + ">" + html.escape(rest) + "</" + tag + ">")
```

근본 해결이 안 될 때 (heredoc 본문 길이 30줄+, 다중 intro/conclusion 합치기 등):
```bash
# ✅ 우회 2: write_file + 격리 호출 (가장 확실)
# 1. write_file 로 빌드 스크립트 저장
# /tmp/tistory_drafts_<session>/build_draft.py
# 첫 줄: # -*- coding: utf-8 -*-
# 본문: importlib / md_to_html / intro+conclusion

# 2. 격리 bash 안에서 호출
env -i HOME=/Users/mac PATH=/usr/bin:/bin PWD=/Users/mac /bin/bash -c '
set -a; source ~/.hermes/secrets/tistory.env; set +a
/usr/bin/python3 /tmp/tistory_drafts_263rd/build_draft.py
'
```

**적용 범위**:
- §3.34.46 본문 빌드 (`md_to_html` + intro + body + conclusion)
- 다중 카테고리 한도 처리
- 인트로+본문+결론 합치기
- 인용구 / 코드블록 / 표 변환 등 본문이 길어지는 모든 변형

**단, 단일 probe (가드 / sync / state 확인) 처럼 5~10줄짜리 short heredoc은 §3.34.41 정정 (string concat) 으로 충분** — write_file 오버헤드 회피.

## §3.34.46 영구화 활용
- `fetch_gn_content(31411)` 호출 → status=200, **10273 bytes** 1단계 `.md` endpoint 즉시 fetch
- 261차 cleanup cron 임무 #23 영구화 정상 동작 — 임시 우회 heredoc 불필요

## §3.5 5중 신호 5/5 `#999` 일치
- state.last_published_url = https://sigco.tistory.com/999
- state.last.url = https://sigco.tistory.com/999
- state.details[-1].url = https://sigco.tistory.com/999
- pt.last.url = https://sigco.tistory.com/999
- pt.details[-1].url = https://sigco.tistory.com/999
- ALL_MATCH: True
- triple_signal_match: true

## post_publish_sync 7필드 보정
- `pt_updated: true / state_updated: true / errors: []`
- daily_counts[2026-07-14] = {'AI/ML': 7} (6→7, +1 정확, cat_id 누설 0)
- state.details 75→76, pt.details 91→92 모두 박힘

## cleanup cron 임무 #16 dry-run
- `✅ 누설 없음 (검사: ['2026-07-14'])`
- **49회 연속 all-green (213~263차)**

## 결과
- **연속 all-green 50회차 (213~263차)**. 가짜 발행 가드 정상.
- 모든 기존 패턴 (§3.8.1 / §3.8.2 / §3.5 / §3.11 / §3.34.39~46 / #21) 정상 동작.
- 차감/추가 없음.
- §3.34.47 신규 — inline heredoc + UTF-8 한글 + f-string 제약 동시 hit 시 `write_file` + 격리 호출 패턴.
