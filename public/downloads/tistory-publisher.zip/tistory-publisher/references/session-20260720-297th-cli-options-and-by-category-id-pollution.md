# 297차 (2026-07-20 00:02) — CLI 옵션 함정 + by_category ID 오염

## 결과
- §3.8.1 raw VALID (status=200, application/json, 첫 entry id=#1047 진짜 존재)
- §3.5 신호 1 drift 경고 — **어제 정상 발행 → 오늘 새 날 → daily_counts[오늘]=0 자연 상태**로 판정, 신호 4 FAKE_PUBLISH 미발동
- 295차 정책(완전 무조건 발행)으로 AI/ML ready. Topic "AI가 Stack Overflow에 끼친 영향을 그래프로 보기" (#31567)
- **#1048 발행 성공** (og:title 매칭 확인, status=200)
- daily_counts[2026-07-20] = {AI/ML: 1}

## 신규 발견

### 함정 7 — `tistory_publisher.py` CLI 옵션 함정

SKILL.md 본문이 `--category 'AI/ML'` (str)로 잘못 가이드되어 있었음. 실제 parser는 **int만** 받는다:

```
argument --category: invalid int value: 'AI/ML'
```

옵션 실측:
- ✅ `--title`, `--tags`, `--visibility`, `--category <int>`, `--source-url`, `--gn-topic-id`, `--file <path>`
- ❌ `--category-id` / `--description` / `--html-file` 미존재

카테고리 ID 매핑 (TISTORY):
| ID | 카테고리 |
|----|----------|
| 1219746 | AI 뉴스 |
| 1219747 | 개발 팁 |
| 1219748 | 자동화&툴 리뷰 |
| 1219750 | 투자&경제 |
| 1219752 | 아이디어 |
| 1219751 | 기타 |

**해결**: §3-b 단계 신설 + 옵션 실측 표 추가. 다음 차 cron은 실측 표 기반 호출.

### 함정 8 — `commit_publish()` → `update_stats()` by_category 오염

`--commit "..." "..." "..." "AI/ML" "..."` 호출 시 카테고리명 `"AI/ML"`이 아닌 정수 ID `"1219746"`이 by_category 키로 박힘.

```
by_category {
  "AI/ML": 741,         # 정상 누적
  "iOS/Swift": 18,      # 정상 누적
  "개발도구": 138,       # 정상 누적
  ...
  "1219746": 1,         # ← 신규 오염 (정수 ID 키)
}
```

**판정**: today 카운트는 정상이라 stats today 자체는 OK. by_category에 int 키가 누적되는 건 SSOT 변경 → **사용자 확인 후에만 정리**, 매 차 자동 보정 금지.

**권장 운영 패턴**: 매 차 `blog_pipeline.py --commit` 직후 by_category 키에 int-only 항목이 있으면 cron 보고에 ⓘ 표시.

## §3.11 보정 워크플로 실전

1. `tistory_publisher.py` 발행 → stdout `🔗 https://sigco.tistory.com/1048` 추출
2. `blog_pipeline.py --commit "31567" "제목" "https://sigco.tistory.com/1048" "AI/ML" "https://news.hada.io/topic?id=31567"` — daily_counts/total/by_category/last_topics 갱신
3. **5-3 수동 패치**: `last_published_url` + `last_published_id` 갱신 (commit_publish() 미갱신)
4. §3.5 검증 ✅ 3중 신호 일치
5. Proxy check: status=200 + og:title 매칭

## 293차 drift 잔존 (SSOT 변경 — 사용자 확인 보류)

- `state.details[-1] = #1043` (7/18 stale)
- `published_topics.json.last = #1044` (7/19 stale)
- 7/19 #1045, #1046, #1047과 오늘 #1048이 sync 안 됨

매 차 반복되는 drift. 자동화 워크플로우 어디서도 `details.append + last 갱신` 안 됨. 사용자 확인 시 명시적 보정 코드 실행 권장.

## 시사점

1. **CLI 옵션은 실측 우선**: SKILL.md 본문 예제가 stale일 수 있음. 신규 단계마다 `argparse --help` 또는 짧은 호출로 검증 후 본문 갱신.
2. **SSOT 변경은 사용자 게이트**: daily_counts 차감, details append, by_category ID 키 정리 같은 SSOT 변경은 매 차 자동화하지 말 것.
3. **새 날 drift은 자연 상태**: last_url은 어제 마지막 글, today daily_counts는 0 → "drift"지만 정상. FAKE_PUBLISH 신호 4(오늘 count ≥ 2 + details 변동 없음)와 구분.
