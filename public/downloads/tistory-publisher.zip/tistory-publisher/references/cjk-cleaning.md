# CJK Cleaning — 한국어-한자/일본어/중국어 혼입 방지 레퍼런스

## 핵심 원칙

1. **Markdown 작성 단계에서 CJK를 근본적으로 방지** — 웹 검색 결과나 기사 원문을 복사할 때 Chinese 문자가 함께 붙을 수 있음
2. **HTML 변환 전에 Markdown에서 먼저 탐지** — `markdown_to_tistory_html.py` 변환 전에 CJK 선검사 실행
3. **HTML 변환 후 루프 정제** — `html == html_before` 조건으로 안정화될 때까지 반복
4. **루프 안정화 후에도 잔여 CJK가 있을 수 있음** — 반드시 2차 정제 실행

## Markdown CJK 선검사 (HTML 변환 전)

```python
import re

def check_markdown_cjk(md_path):
    with open(md_path, 'r') as f:
        md = f.read()
    cjk = set(re.findall(r'[\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff]', md))
    if cjk:
        print(f"⚠️ Markdown에서 CJK 발견: {cjk}")
        return cjk
    return set()

def clean_markdown_cjk(md_path, replacements):
    with open(md_path, 'r') as f:
        md = f.read()
    for old, new in replacements.items():
        md = md.replace(old, new)
    cjk = set(re.findall(r'[\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff]', md))
    if cjk:
        print(f"⚠️ 정제 후 잔여 CJK: {cjk}")
    else:
        print("✅ Markdown CJK 완전 제거 완료")
    with open(md_path, 'w') as f:
        f.write(md)
    return md
```

## HTML CJK 정제 (markdown_to_tistory_html.py 변환 후)

### CJK 문자 Regex

```python
# CJK 문자 탐지
import re
def has_cjk(text):
    return bool(re.search(r'[\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff]', text))

# CJK 문자 추출
def get_cjk_chars(text):
    return set(re.findall(r'[\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff]', text))
```

### CLEANING_LOOP — 루프 기반 정제

```python
def clean_cjk_loop(html, replacements, max_passes=20):
    """CJK가 없어질 때까지 루프 돌기. 안정화되면 2차 정제 실행."""
    pass_num = 0
    while has_cjk(html):
        html_before = html
        for old, new in replacements.items():
            html = html.replace(old, new)
        pass_num += 1
        if html == html_before:
            # 루프 안정화 — 잔여 문자 2차 정제
            remaining = get_cjk_chars(html)
            print(f"⚠️ CJK 루프 {pass_num}회차 후 잔여: {remaining} — 2차 정제 실행")
            for old, new in SECOND_PASS_FIXES.items():
                html = html.replace(old, new)
            remaining = get_cjk_chars(html)
            if remaining:
                print(f"⚠️ 2차 정제 후 잔여: {remaining}")
            break
        if pass_num > max_passes:
            print(f"⚠️ {max_passes}회차 초과 — 잔여: {get_cjk_chars(html)}")
            break
    else:
        print(f"✅ CJK 완전 정제 완료 ({pass_num}회차)")
    return html
```

### 2차 정제 잔여 문자 (누적)

```python
SECOND_PASS_FIXES = {
    # 38차
    '年': '년', '间': '간', '当': '당', '时': '시', '成': '성',
    # 39차
    '房': '방', '起': '기', '音': '음', '料': '료', '购': '구',
    '压': '압', '敌': '적', '点': '점', '感': '감', '足': '족',
    '频': '빈', '塑': '소', '文': '문', '碾': '년도', '植': '식', '力': '력',
    # 40차
    '判': '판', '优': '우', '物': '물', '凌': '능', '訓': '훈',
    '层': '층', '做': '작', '晨': '신', '劲': '근', '断': '단',
    '致': '치', '导': '도',
    # 41차
    '重': '중', '无': '무', '启': '계', '比': '비', '速': '속',
    '導': '도', '向': '향', '缝': '봉', '加': '가', '傘': '산',
    # 기타 자주 발견
    '拠': '거', 'ほ': '호', 'ど': '도', '无': '무', 'ろ': '로',
    '証': '증', '上': '상', '移': '이', '万': '만', '历': '력',
    '能': '능', '几': '기', '实': '실', '处': '처', '识': '식',
}
```

### Cyrillic 잔여 (CJK regex 밖)

```python
cyrillic = set(re.findall(r'[\u0400-\u04FF]', html))
if cyrillic:
    print(f"⚠️ Cyrillic 잔여: {cyrillic}")
    for c in cyrillic:
        html = html.replace(c, '')
```

### Korean Hanja Corruption 검증

```python
CORRUPTION_COMPLETE = ['开发', '发表', '韩', '中', '文']
for pat in CORRUPTION_COMPLETE:
    if pat in html:
        print(f"⚠️ Korean Hanja corruption (complete): {pat}")

MIXED_PATTERNS = ['례외', '热潮', '实证', '研究', '無', '無検討']
for pat in MIXED_PATTERNS:
    if pat in html:
        print(f"⚠️ Mixed CJK-in-Korean suspicious: {pat}")
```

## 주기적으로 발견되는 Chinese 단어 → Korean 매핑

```python
CHINESE_WORD_REPLACEMENTS = {
    '记录': '기록',
    '实用': '실용',
    '实时': '실시간',
    '的同时': '동시에',
    '举动': '조치',
    '负责': '책임',
    '原则': '원칙',
    '対応': '대응',
    '동호会': '동호회',
    '社区': '커뮤니티',
    '激烈': '열렬',
    '赞同': '동의',
    '当地时间': '현지 시간',
    '当地时间': '현지 시간',
}
```

## 대표적 유입 경로

| 출처 | 패턴 | 예시 |
|------|------|------|
| GeekNews 원문 | Chinese 단어가 한국어 사이에 삽입 | 受影响→수영향, 发生→발생 |
| Wikipedia/위키독스 | 한국어 한자 섞인 표현 | 移動 중 → 이동 중 |
| 검색 결과 복사 | Chinese/Japanese 문자 포함 | "plástica" → "플라스틱" |
| 모델 생성 | 모델이 직접 Chinese 텍스트 생성 | "Microsoft傘下의 GitHub" |

## 품질 체크포인트 요약

| 단계 | 파일 | 체크포인트 |
|------|------|-----------|
| 1 | Markdown 작성 직후 | CJK 선검사 — 있으면 정제 후 저장 |
| 2 | markdown_to_tistory_html.py 변환 직후 | 루프 정제 실행 |
| 3 | 루프 안정화 후 | 2차 정제 + 잔여 탐지 |
| 4 | 최종 HTML | corruption/잔여 검증 |
