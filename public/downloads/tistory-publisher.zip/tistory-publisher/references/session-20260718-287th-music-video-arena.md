# 287차 (2026-07-18) — 100달러 AI 뮤직비디오 제작 대결

**글**: #1039 100달러 AI 뮤직비디오 제작 대결 — Claude Fable 5 vs. GPT-5.6 Sol (AI/ML/1219746, gn=31522, 10점, FRESH 1순위)

**연속 all-green**: 74회차 (213~287차)

## 한 줄 요약

FRESH 6개 중 AI/ML 1 (31522, 10점) + 비-AI/ML 5 (개발도구 2 + 개발팁 3) → §3.34 #21 정책으로 AI/ML 픽 (실전 14호). 정상 발행 → §3.34.44 drift 무해 8호 검증.

## 검증 결과

- §3.8.1 가드: status=200, ct=application/json;charset=UTF-8, cookie_count=8 ✅
- §3.34 #21 AI/ML 우선 정책 실전 14호 (255→266→268→269→270→271→280→281→282→283→284→285→286→287차)
- §3.34.46 영구화: `_try_md_endpoint(31522)` → status=200, 14505 bytes 1단계 .md 즉시 fetch
- §3.34.50 Topic Body 마커 11회째: 본문 평문 5391자 (intro 400 + body 4500 + conclusion 500, 300자 가드 통과)
- §3.34.47 격리 빌드: `/tmp/tistory_drafts_287th/build_draft_31522.py` 6790 bytes
- §3.34.53 gfc alias 7회째: importlib spec_from_file_location 정상
- §3.34.55 시그니처 함정 회피: `_try_md_endpoint(tid)` 단일 변수 할당만 사용
- §3.34.44 drift 무해 8호 (253→254→270→282→283→284→285→286→**287차**)
- §3.34.48 `* ` 분기 + 4단계 헤더 강등 정규식 10회째: 본문엔 hit 안 했지만 안전 가드 포함
- §3.34.54 `> ` blockquote 9번째 분기: 본문엔 `> ` 라인 없어 미적용 (안전 가드 포함)

## publish 후 검증

- 5중 신호 5/5 `#1039` 일치 (state.last_published_url + state.last.url + state.details[-1].url + pt.last.url + pt.details[-1].url, all_match: True)
- `state.last_published_id: 1039`, `pt.last.gn_topic_id: 31522`, `pt.last.title` 정상
- `state.details`: 116→117, `pt.details`: 131→132
- `daily_counts[2026-07-18] = {'AI/ML': 1}` (정확, cat_id 누설 0)
- post_publish_sync `pt_updated: true / state_updated: true / errors: []`
- 이미지 2장 CDN 업로드 정상 (Picsum ID 36 자동 매칭 — 두 슬롯 동일, 영문 자연어 query 첫 빌드 적중)
- 라이브 페이지 GET `status=200, size=74121, <title>정상`
- cleanup cron 임무 #16 dry-run: ✅ 누설 없음 (73→**74회** 연속 all-green)

## 본 세션 관찰 + §3.34.41 적용 범위 확장 (NEW)

5~15줄짜리 짧은 inline 점검 heredoc (5중 신호 사전 검증 / splice drift sanity check / splice backfill 검증) 에서도 f-string `\"` escape 함정이 동일하게 hit 가능함을 287차에 확인.

**원인 회고**: 사전 검증 Python heredoc에서
```
print(f"  state.details count: {len(state.get(\"details\",[]))}")
```
→ `SyntaxError: f-string expression part cannot include a backslash` (Python 3.9)

`state.get(\"details\",[])` 의 escaped `\"` 가 f-string 안에서 3.9가 거부 (PEP 701 이전 제약). SKILL.md §3.34.41 박스는 §3.34.46 본문 빌드에 한정되어 있어 짧은 진단 스크립트도 동일 hit 가능함을 박스에 적지 않았음.

**회피 패턴**:
- f-string 대신 `+ str(...)` concat
- 또는 변수 추출 후 f-string 외부 사용
- 또는 `%`-formatting
- 또는 `%` 명시 포맷팅 (예: `"%s: %s" % (k, v)`)

**운영 원칙**: 격리 python3 heredoc은 f-string 안에 `\\\"` 또는 `\\\\` escape 들어가면 무조건 실패한다고 가정. 가능하면 `+ str(...)` concat 권장.

사전 검증에서 SyntaxError → 5중 신호 검증 종료 못함 → publish 단계 무의미 (drift 무해 판단 불가) → cron 차 종료 위험.

## §3.34 #21 정책 매트릭스 검증 (287차 식별)

| FRESH 후보 | 정책 결정 | 검증 차 |
|---|---|---|
| AI/ML 0개 + 비-AI/ML (개발도구 + 개발팁) | skip 또는 점수 1순위 (단, '기타' 0개면 매트릭스 3번째 분기) | 254차~269차 |
| AI/ML ≥ 1 + 비-기타 혼재 | **AI/ML 점수 1순위 픽** | **255·266·268·269·270·271·280·281·282·283·284·285·286·287차 14호** |
| AI/ML 0 + 비-기타 다수 | 비-기타 카테고리 점수 1순위 픽 | 254차~269차 |
| 모두 '기타' | skip (256차 실전 1호) | 256차 |

287차는 두 번째 분기: FRESH 6개 (AI/ML 1 + 개발도구 2 + 개발팁 3) → AI/ML 점수 1순위 (31522, 10점) 픽.

## 후보 매트릭스 (287차)

TOP 12개 (blog_pipeline.py --refresh-topics --dry-run 결과):

| 순위 | 카테고리 | 점수 | topic_id | 제목 | FRESH? |
|---|---|---|---|---|---|
| 1 | AI/ML | 15.0 | 31498 | GPU 없이 13년 된 Xeon에서 Gemma 4 26B | PUB (283차) |
| 2 | AI/ML | 10.0 | **31522** | **100달러 AI 뮤직비디오 제작 대결** | **FRESH → 발행** |
| 3 | 개발팁 | 9.0 | 31501 | 정부·기업·비영리단체가 자유 FOSS AI 투자 | PUB (286차) |
| 4 | 개발팁 | 8.0 | 31518 | 우리는 떼돈을 벌게 될 것이다 | FRESH |
| 5 | 개발팁 | 8.0 | 31514 | LinkedIn 채용 과제 사기 | FRESH |
| 6 | AI/ML | 7.0 | 31509 | 커널 개발에서 LLM 사용에 관한 Linus | PUB (284차) |
| 7 | 개발팁 | 6.0 | 31521 | 명세 3장으로 PWA 앱+서버 | FRESH |
| 8 | AI/ML | 6.0 | 31508 | NotebookLM, Gemini Notebook | PUB (285차) |
| 9 | AI/ML | 3.0 | 31516 | Pandas 창시자 | PUB (286차) |
| 10 | AI/ML | 3.0 | 31513 | Decoy Font | PUB (286차) |
| 11 | 개발도구 | 3.0 | 31510 | LeafWiki | FRESH |
| 12 | 개발도구 | 2.0 | 31512 | OnePlus 미국·유럽 운영 중단 | FRESH |

FRESH 6개 중 AI/ML = 1 (31522) → §3.34 #21 정책 그대로 AI/ML 1순위 픽.

## §3.34.55 시그니처 함정 회피 (287차 검증)

```python
import importlib.util
spec = importlib.util.spec_from_file_location(
    "gfc",
    "/Users/mac/.hermes/skills/automation/tistory-publisher/scripts/gn-fetch-content.py",
)
gfc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gfc)
text = gfc._try_md_endpoint(31522)  # 단일 변수 할당
# → 14505 bytes (status=200, 1단계 .md endpoint 즉시 성공)
```

`fetch_gn_content(tid)` 호출은 권장하지 않음 (279차 검증 — None 반환 위험).

## 본 세션 신규 발견 0건 — 모든 정착 패턴 정상 동작

- §3.8.1 가드
- §3.8.2 격리 패턴 (PWD 보강)
- §3.11 post_publish_sync CLI (`sync` 서브커맨드)
- §3.34.40 v2 FRESH 4-field 매칭
- §3.34.43 PWD/cd 함정 회피
- §3.34.46 gn-fetch-content 영구화 (1단계 .md)
- §3.34.47 격리 빌드 (write_file → python3 격리 호출)
- §3.34.48 `* ` 분기 + 4단계 헤더 강등
- §3.34.50 Topic Body 마커
- §3.34.53 gfc alias
- §3.34.54 `> ` blockquote
- §3.34.55 `_try_md_endpoint(tid)` 단일 변수 할당
- §3.34 #21 정책 + §3.34.45 매트릭스
- §3.34.44 drift 무해
- cleanup cron 임무 #16 daily cat_id 누설 cleanup

## cleanup cron 임무 상태

- **#41 (287차, NEW)**: §3.34 #21 정책 실전 14호 + §3.34.44 drift 무해 8호 + §3.34.41 적용 범위 확장 관찰 (NEW). 연속 all-green **74회차 마일스톤**. FRESH 6개 중 AI/ML 1 + 비-AI/ML 5 ('기타' 0개) → 매트릭스 4번째 분기 정상. 비-AI/ML 8점·6점·3점·2점 후보 5개 자동 배제, AI/ML 10점 픽. §3.34.44 drift 무해 8호: 사전 `state.last_published_url=#1038` + `pt.last.gn_topic_id=31501` (자정 사이 286차 정상 케이스 — 외부 발행 흔적 없음), v2 FRESH 4-field 매칭 정상 식별 → publish 후 sync `#1039` 무해 회복. cleanup #16 dry-run 73→**74회**. Picsum ID 36 자동 매칭 (영문 자연어 query 첫 빌드 적중). 본문 5391자. 본 세션 신규 §3.34.41 적용 범위 확장 관찰 — 5~15줄 짧은 inline 점검 heredoc도 동일 회피 패턴 적용. 차감/추가 없음.
