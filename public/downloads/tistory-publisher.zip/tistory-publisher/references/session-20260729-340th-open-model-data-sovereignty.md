# 340차: proxy-first 발행 트랜잭션 재검증

## 결과
- 주제: `오픈 모델이 예상 밖의 해방감을 준 이유` (gn=31917, AI/ML)
- 실제 제목: `오픈 모델이 주는 해방감 — 내 데이터와 AI를 다시 내 손에`
- 발행 URL: `https://sigco.tistory.com/1137`
- 본문: 순수 텍스트 1,623자, 이미지 2장, 코드 블록 1개

## 재사용 가능한 실행 순서
1. raw 세션 가드가 `HTTP 200 + application/json + first_id`를 확인한 뒤에만 진행한다.
2. 트렌드 갱신과 진입 시점 §3.5 검사를 병렬 실행할 수 있다.
3. 진입 §3.5가 직전 정상 슬롯에서 신호 4를 내면 직전 URL의 `HTTP 200 + og:title + source URL`로 구조적 오탐을 먼저 해소한다.
4. `blog_pipeline.py --category`는 한 번만 호출해 원래 topic과 source URL을 고정한다.
5. 본문은 `parts.append()`로 만들고 코드 블록은 `code_lines + "\n".join()`으로 분리한다. 발행 전 순수 텍스트 길이, 이미지 수, 의심 CJK 문자를 검사한다.
6. `/tmp/publish_N.py` 래퍼에서 `publish_post()`를 호출한다. tags는 쉼표 구분 문자열이다.
7. 숫자형 URL을 받은 직후, 상태를 건드리기 전에 proxy로 `HTTP 200 + og:title 정확 일치 + source_present + CJK 없음`을 확인한다.
8. proxy가 통과한 뒤에만 `--commit`, state 5-3, published_topics 5-2-A를 실행한다.
9. canonical hash는 SEO 제목이 아니라 pipeline의 원래 topic 문자열 MD5를 사용한다.
10. 최종 §3.5 신호 4는 신규 슬롯 동시 보정 때문에 발생할 수 있다. 동일 URL의 최종 proxy가 통과하면 구조적 오탐으로 확정한다.

## 관찰
- commit 후 `daily_counts[2026-07-29].AI/ML`은 8→9, total은 131이 됐다.
- state.last, state.details[-1], published_topics.last가 모두 #1137로 일치했다.
- `by_category["1219746"]=1` 잔존은 기존 정책대로 자동 수정하지 않았다.
