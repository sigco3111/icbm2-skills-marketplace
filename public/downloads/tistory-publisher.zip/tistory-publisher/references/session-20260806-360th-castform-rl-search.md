# 360차 (2026-08-06 22:02) — Castform 4B RL 검색

## 발행
**#1195** — "100배 저렴한 오픈 모델로 검색에서 GPT-5.6 Sol 능가하기 — Castform 4B 실전 가이드" (gn=32204, AI/ML, 본문 2,194자 + Picsum 2장 + Python 코드 1개).

## 결과
- §3.8.1 세션 만료 가드: ✅ VALID (first_id=1194)
- §2 트렌드 갱신: ✅ 긱뉴스 12개 후보 추가
- §3-a AI/ML ready: gn=32204 (Castform)
- §3-b publish: `--content` 단일 폴백 정형 113회차 연속 검증. OG 썸네일 `https://blog.kakaocdn.net/dna/mwGgI/dJMcad3Z5QQ/AAAAAAAAAAAA...` 자동.
- §3.11 5단계 sync: 5-3 (last+details 통합, KST 타임존 명시) → 5-2-A (백필 1건 + last 명시 동기화 #1195)
- §3.5 3중 신호: 신호 4 발동 → **구조적 오탐** (5-3에서 details+last 동시 갱정 패턴 + 누적치 daily_counts 합계 매칭)
- §3.5 5-5 proxy check: ✅ status=200 + og:title 정확 매칭 + source_present=True + cjk_suspicious=False → 진짜 발행 확정
- Tistory posts.json: #1195 정상 노출, #1193/#1194 state.json details 일치

## 연속 카운터 갱신
- 단일 패스 45연속 (316→360)
- §3.5 신호 4 disambiguate 26연속 (298→360)
- 진입 5-5 25연속
- fallback 복귀 37연속
- **연속 all-green 133회차**

## 함정 회피 (8종)
- **함정 3**: 긱뉴스 본문 selector 코멘트만 → og:description regex로 본문 메타 추출 (대체 패턴)
- **함정 6**: heredoc + env -i SyntaxError → write_file + /tmp/build_post_NNN.py 분리 패턴
- **함정 7**: `--category` int만 → `--category 1219746` (int) 정확
- **함정 11**: `execute_code` cron 차단 → write_file + `/usr/bin/python3 -s /tmp/build_post_NNN.py`
- **함정 14**: `import os, re, requests, sys, json, pathlib` 6개 모듈 첫 줄 명시 (343차 정형)
- **함정 15**: 5-5 proxy check 격리 패턴 (`unset PYTHONPATH PYTHONHOME; PYTHONNOUSERSITE=1; export PYTHONPATH=user-site; /usr/bin/python3 -s`)
- **함정 25**: parts.append() 본문 작은따옴표 매칭 → 처음부터 double quotes 사용 (332차 정형)
- **함정 26**: sibling subagent CJK 자동 치환 (이번 차 신규 2건) → patch()로 한국어 원문 복원
- **함정 27**: source_in_body=False는 publish_post()가 source_url 인자로 footer 자동 박아주는 정상 동작
- **함정 31 변형 A/B**: 355차/356차 검증된 가드 self-crash 우회 정형 그대로 적용

## swap 후보 사전 확장 (360차 신규 2건)
- `背景下` → `이런 배경에서` (sibling subagent 자동 치환)
- `轨迹` → `흐름` (sibling subagent 자동 치환)

**기존 swap 후보 단어 사전 누적**:
- 입장/立场 (333차)
- 자세/姿勢 (343차)
- 정기/定時 (342차)
- 자주/自走 (343차 변형)
- 설명/說明 (이전 차 누적)
- 자격/資格 (이전 차)
- 이유/理由 (이전 차)
- 수랭/液냉 (347차)
- 공감대/共识 (347차)
- 일/仕事 (347차)
- **背景下/이런 배경에서 (360차 신규)**
- **轨迹/흐름 (360차 신규)**

**판정 강화**: CJK 공유 한자 영역 동음이의 한자 음차는 sibling subagent write warning이 뜨면 자동 치환 가능. swap 후보 단어 사전에 포함된 한국어 단어가 본문에 들어가면 빌드 직후 `grep -nE '[一-鿿]|[ぁ-ゔ]|[ァ-ヴー]'` 검출 → `patch()`로 한국어 원문 복원이 정형 패턴. **새 swap 후보 발견 시 매 차 SKILL.md 본문에 추가 권장**.

## 본문 빌드 단일 패스 검증 6종 (350차 정형)
- exit=0 ✅
- bytes=4039 ✅
- text_len=2194 ✅ (target 2500 부근, OK)
- img=2 ✅
- code=1 ✅
- source_in_body=False ✅ (publish_post() footer 자동 처리, 함정 27)
- cjk_suspicious=False ✅ (patch() 2건 복원 후)

## daily_counts 누적치 매칭 구조적 오탐 정형 (360차 재확인)
360차 §3.5 신호 4 발동 패턴:
- `daily_counts[2026-08-06] = {'AI/ML': 9}` (오늘 cron 누적 1건 + 이전 차 누적 8건 = 합계 9)
- `details[-1] = #1195` (이번 차 발행 슬롯)
- `last_published_url = https://sigco.tistory.com/1195`

5-3에서 details+last를 같은 슬롯(#1195)으로 동기화하면 `details[-1].url == last_published_url`이 무조건 성립 + daily_counts[오늘] ≥ 2 (누적치) → 신호 4 발동. 이게 298~360차 오탐의 구조적 원인. **proxy check로 disambiguate하는 것이 정형 운영 패턴으로 완전 정착** (24→26연속). 5-5에서 status=200 + og:title 매칭 확인되면 진짜 발행으로 확정.

## by_category["1219746"]=1 영구 잔존 63연속 재확인
297→360차 = 64차 동일 유지. 사용자 게이트 보정 안 됨, cron drift 보고만 유지. 이번 차도 `"개발도구": 152, "투자/경제": 14, "기타": 14, "아이디어": 6, "개발 팁": 14, "개발팁": 2, "1219746": 1` 상태 그대로.

## 실행 시간
22:01 §1 가드 → 22:02 §5-3 last+details 동기화 → 22:02 §5-5 proxy check 통과. 총 ~1분 (단일 cron 발행 정상 소요 시간).
