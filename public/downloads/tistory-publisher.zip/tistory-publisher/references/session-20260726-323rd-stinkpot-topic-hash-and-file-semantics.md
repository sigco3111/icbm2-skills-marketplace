# 323차 Tistory 발행 세션 기록

## 이번 세션에서 실제로 확인한 것

- 세션 가드: Tistory 관리 API HTTP 200, `application/json`, 최신 게시물 `#1103` → 발행 진행 가능.
- 트렌드 갱신 후 AI/ML 후보 `gn=31827`, 원문 주제 `Show GN: 엄랭으로 틱택토 AI를 만들어 봤습니다.` 선정.
- `/tmp/post_31827.md`는 정상 생성되었지만 `tistory_publisher.py --file /tmp/post_31827.md`가 두 번 연속 `--title과 --content 또는 --file이 필요합니다`로 종료했다. 동일 명령 반복 대신 Markdown을 읽어 `--content`에 직접 전달하고 `--title`을 명시하는 fallback으로 전환했다.
- `--content` fallback 발행 결과: 실제 URL `https://sigco.tistory.com/1104`, HTTP 200, `og:title`이 발행 제목과 일치.
- `blog_pipeline.py --commit` 후 `daily_counts[2026-07-26]={'AI/ML': 5}` 확인.
- canonical dedup hash는 SEO 확장 제목이 아니라 원래 topic 문자열 `Show GN: 엄랭으로 틱택토 AI를 만들어 봤습니다.`의 MD5 `079b1415d1330ba0a923c8a7f9d5e507`로 기록했다.
- state의 `last_published_url`, `last_published_id`, `details`와 `published_topics.json`의 `topics`, `last`, `details`를 실제 URL과 canonical hash로 동기화했다.
- 최종 consistency checker는 같은 신규 슬롯이 `details[-1]`와 `last_published_url`에 함께 존재해 FAKE_PUBLISH exit 1을 냈다. 그러나 proxy HTTP 200 + `og:title` 일치로 실제 발행임을 확인했으므로 구조적 오탐으로 판정했다.

## 재사용 규칙

1. `--file` 실패 시 같은 호출을 무한 반복하지 말고 `--content` + 명시적 `--title` fallback을 사용한다.
2. 발행 URL은 stdout의 `🔗 https://sigco.tistory.com/NNN`에서만 추출한다.
3. publish 전에 `--record-topic`을 사용하지 않으며, placeholder URL은 절대 기록하지 않는다.
4. commit/sync 뒤 consistency exit 1이 나오면 먼저 실제 URL proxy와 `og:title`을 확인한다. 200+제목 일치면 오탐, 404/불일치면 가짜 발행으로 처리한다.
5. topic dedup hash는 SEO용 확장 제목이 아닌 pipeline이 반환한 원문 topic 문자열의 MD5를 사용한다.
