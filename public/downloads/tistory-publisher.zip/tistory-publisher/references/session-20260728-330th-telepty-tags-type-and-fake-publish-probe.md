# 330차 — telepty 발행 wrapper의 tags 타입과 §3.5 오탐 검증

## 재현 요약

- 후보: GN 31842 `Show GN: telepty — 여러 머신에 흩어진 AI 에이전트 세션 컨트롤 플레인`
- 첫 standalone wrapper는 `tags=["telepty", ...]` 리스트를 넘겨 이미지 업로드와 OG 썸네일 설정까지 진행했지만 최종 Tistory POST가 HTTP 500으로 실패했다.
- `~/.hermes/scripts/tistory_publisher.py`를 확인한 결과 `publish_post()`가 그대로 `post_data["tag"] = tags`를 넣으므로, 이 경로의 `tags`는 comma-separated 문자열이어야 한다.
- `TAGS = "telepty,AI에이전트,ClaudeCode,Codex,tmux,멀티에이전트,개발도구"`로 수정 후 실제 발행 성공: `https://sigco.tistory.com/1120`.

## 운영 규칙

1. standalone wrapper를 만들 때 함수 시그니처와 `post_data` 타입을 먼저 확인한다.
2. `tags`는 리스트가 아닌 문자열로 전달한다.
3. 이미지 업로드 성공이나 OG 썸네일 설정은 최종 발행 성공의 증거가 아니다.
4. `PUBLISH=SUCCESS URL=https://sigco.tistory.com/NNN`이 출력되고 실제 URL proxy가 HTTP 200 + `og:title` 일치할 때만 commit/state 동기화를 수행한다.
5. §3.5가 `FAKE_PUBLISH`를 반환해도 `daily_counts >= 2` 및 details/last가 같은 최신 슬롯이면 구조적 오탐일 수 있다. 최신 URL proxy를 먼저 확인하고, HTTP 200 + 제목 일치면 실제 발행으로 확정한다.

## 검증 출력

- publish wrapper: `PUBLISH=SUCCESS URL=https://sigco.tistory.com/1120`
- proxy: `status=200`, `og:title=telepty — 여러 머신의 AI 에이전트 세션을 한곳에서 지휘하는 컨트롤 플레인`
- 최종 상태: `state.json`과 `published_topics.json` 모두 #1120 반영
- 최종 §3.5 검사는 구조적 `FAKE_PUBLISH`로 exit 1이었으나 proxy PASS로 오탐 판정
