# 184차 세션 — Tistory 쿠키 갱신 워크플로 (2026-06-29)

## 배경
183차(Zombie 200 패턴)에서 세션 만료 진단 레시피 추가 후, 184차에서 실제 쿠키 만료 → 사용자 가이드 → env 갱신 → 검증 흐름이 다시 등장.

## 사용자 요청
```
python3 ~/.hermes/scripts/tistory_publisher.py --check-session
# → ❌ 연결 오류: Expecting value: line 2 column 2 (char 2)
```

## 진단 결과

### 1단계: 직접 API 호출
```bash
curl -sI "https://sigco.tistory.com/manage/posts.json?category=-3&page=1" \
  -H "Cookie: TISTORY_*" -H "User-Agent: Mozilla/5.0"
# → HTTP/2 302
# → location: https://www.tistory.com/auth/login?redirectUrl=...
```

→ **쿠키 만료 확정** (Tistory가 로그인 페이지로 리다이렉트)

### 2단계: 사용자 가이드 — 쿠키 추출
처음에 "TISTORY_* 쿠키 5종 복사하라"고 안내했더니 사용자가 "네가 말한 값이 없음" 응답.

**문제**: 브라우저 DevTools에는 **`TISTORY_*` prefix 없이** 저장됨. 스크립트가 prefix를 env 파일에서 제거하고 COOKIE_NAMES 5개(`REACTION_GUEST`, `__T_`, `__T_SECURE`, `TSSESSION`, `_T_ANO`)를 dict로 만들어 requests에 전달.

**수정 가이드**:
- DevTools → Application 탭 → Cookies → `https://sigco.tistory.com` 또는 `https://www.tistory.com`
- prefix 없이 5개 이름 찾기: `REACTION_GUEST`, `__T_`, `__T_SECURE`, `TSSESSION`, `_T_ANO`
- Network 탭 → `posts.json` 요청 → Cookie 헤더 값이 한 줄로 묶여있음 (그게 정답)

### 3단계: 사용자 제공 값 (184차)
```
__T_ : 1
__T_SECURE : 1
TSSESSION : d1a2d57de15d72fae49df4ce544c25f9215aca12
_T_ANO : GYd5UwGLPcAHD3VlBwkX+NJ1a7wSQ2SWs+/YuMtpubJwwcLNg0akNLI2zGazjudX+K7EOxziF6mUDsvsQREJopQB6RFIA8JB2C6nT5SoDtn9iSX+iifqNjZCM0Iubc330IKXMPKMj8yYM0uDWU9A6F4LD33LxsJks81ahf1GD5CrYE7lL/PSBYlrM6D7nxcnHH4l1T2JybgW81G5AuIkfI4P1phnhO709Ummf3zaLP2Wqnyfqx5UpmU4v0fxbSKDzXrCJ/pbR1tW50L4iKcZ9tJ0Iyrtrg1aeYUswl/kza7aD0Y/VA7crByeANsXyQA/WMIiDOafXNV8pmDEHOXvWg==
```
- `REACTION_GUEST` 누락 → 기본값 `1`로 채움 (없어도 발행 가능)

### 4단계: env 파일 갱신
```bash
cp ~/.hermes/secrets/tistory.env ~/.hermes/secrets/tistory.env.bak.1782688685
# → 5개 키 갱신 (786B)
```

### 5단계: 검증
```bash
python3 ~/.hermes/scripts/tistory_publisher.py --check-session
# → ✅ 세션 유효 (총 732개 글)
```

✅ 성공!

## 새 함정 발견 (3가지)

### 함정 1: 사용자가 `TISTORY_*` prefix로 쿠키를 찾으려 함
- 스크립트는 prefix 없이 COOKIE_NAMES 5개를 찾음
- **사용자 안내 시 "prefix 없이 찾으라"고 명시** 필요

### 함정 2: 검증 스크립트 false positive
- `curl -H "Cookie: TISTORY_*=..."` → Tistory 서버는 `TISTORY_*`라는 쿠키 모름 → 무시 → 302 (false positive)
- `requests`는 dict에서 도메인 매칭으로 5개만 골라 전송 → 정상 작동

### 함정 3: 검증 스크립트 작성 시 `$()` 마스킹 깨짐
- `$(cat ~/.hermes/secrets/vercel_token.txt)` 같은 패턴이 마스킹 단계에서 깨져서 syntax error
- 해결: `read -r TOKEN < file` + `export TOKEN` + 별도 sub-script에 환경변수 전달

## 추가된 스킬 자산
- `SKILL.md` §3.9 (쿠키 prefix 혼동 함정)
- `SKILL.md` §3.10 (검증 false positive 회피)
- `references/session-20260629-184th-cookie-refresh.md` (이 문서)
- `scripts/verify-tistory-cookie.sh` (ad-hoc 검증 자동화)

## 향후 개선 (TODO)
- 사용자 안내 시 "DevTools → Application → Cookies → https://sigco.tistory.com → prefix 없이 5개 이름" 스크린샷 첨부
- `verify-tistory-cookie.sh` 자동 cron 등록 (주 1회 세션 체크) — false positive 방지 가드