# 262차 세션 노트 — 2026-07-14 — GPT-5.6 마이그레이션 발행 + §3.34.46 HTML 변환 함정 보완

## 발행 결과
**#998 정상 발행** — `https://sigco.tistory.com/998`
- 제목: 프로덕션 AI 에이전트를 GPT-5.6으로 전환해 2.2배 빠르고 27% 저렴해진 과정 — 모델이 아니라 인프라 가정을 갈아끼워야 하는 이유
- 카테고리: AI/ML (1219746), gn_topic_id=31404, 16점 (FRESH 1순위)
- 본문 7341자 (검증 7151자, 300자 가드 통과)
- 이미지 2장 CDN 업로드 (Picsum ID 263)

## 검증 통과 신호
- §3.8.1 세션 가드: `status=200, ct=application/json;charset=UTF-8, cookie_count=8` ✅
- §3.5 5중 신호: `triple_signal_match: true` (모두 `#998`) ✅
- post_publish_sync: `pt_updated: true / state_updated: true / errors: []` ✅
- daily_counts[2026-07-14]['AI/ML'] = 6 (5→6, +1 정확)
- cleanup cron #16: 47→**48회** 연속 all-green ✅
- 라이브 페이지 GET: `status=200, size=66940, title tag='프로덕션 AI 에이전트를 GPT-5.6으로 ...'` ✅

## §3.34.46 HTML 변환 들여쓰기/위장-헤더 함정 (NEW, 262차 식별)

### 함정 1: 들여쓬 sub-list를 nested `<ul>` 로 변환
- GeekNews 본문에 `  - hero 영역이 화면 전체 폭을 채우는 사진 장면인지 검사함` 같은 2-space indented sub-list 가 흔함
- 262차 첫 시도에 indent depth = 2 space / 1 level 로 nested `<ul><ul><li>` 변환 시도
- 결과: md가 pseudo-nested (모든 `- ` 이 동등한 top-level bullet) 일 때 매 항목마다 `<ul>` 가 열리고 즉시 닫혀 시각적 리스트 미형성
- 21개 `<ul>` 그룹이 분산되어 한 줄짜리 리스트 21개로 출력됨

**회피 (262차 정착)**: indent 무시하고 모든 `- ` 를 top-level bullet로 취급, 연속된 `- ` 라인을 하나의 `<ul>...</ul>` 로 묶고 빈 줄에서만 close.

### 함정 2: `- ## 헤더` 위장 항목을 `<li>` 로 변환
- GeekNews 본문에 `- ## 기존 모델의 호출 방식에 맞춰진 제약` 같은 list-prefixed header 가 나옴
- 262차 첫 시도에 `<li>## 기존 모델의 호출 방식에 맞춰진 제약</li>` 로 변환 → 의미 파괴

**회피 (262차 정착)**: `- ` 변환 직전 item_text가 `## `/`### ` 로 시작하면 `<h2>`/`<h3>` 로 라우팅.

### 개선된 md_to_html 함수
위 §3.34.46 SKILL.md 박스의 코드블록 참조. 핵심 변경:
1. `line.lstrip()` 후 `startswith("- ")` 만 검사 (들여쓰기 무시)
2. item_text 가 `## `/`### ` 시작하면 헤더 라우팅
3. `---` → `<hr>`, 빈 줄은 그냥 skip (no extra paragraph)

## 워크플로 검증
1. §3.8.1 가드 (격리 패턴 + 3.9-safe string concat) ✅
2. `--refresh-topics --dry-run` 으로 후보 12개 + 점수 추출 ✅
3. FRESH 4-field 매칭 (pt_published + state_published 교집합) ✅
4. 16점 `31404` 픽 (FRESH AI/ML 1순위, #21 정책 정상) ✅
5. `gn-fetch-content._try_md_endpoint(31404)` → 13506 bytes (1단계 `.md` endpoint 즉시) ✅
6. 본문 정규화 (Comments/Metadata/Topic Body 제거) ✅
7. md_to_html 개선 버전으로 HTML 변환 + editorial 인트로/결론 추가 ✅
8. publish (--source-url + --gn-topic-id + --category-id + --image-query) ✅
9. post_publish_sync (sync 서브커맨드 + 6필드) ✅
10. §3.5 5중 검증 모두 `#998` 일치 ✅
11. 라이브 페이지 GET 200 + title tag 정상 ✅
12. cleanup cron #16 dry-run all-green ✅

## 차감/추가
- 차감: 없음
- 추가: §3.34.46 HTML 변환 함정 2건 보완 (들여쓰기 nested ul, `- ## ` 위장 header) — 정정 코드블록 + 절대 하지 말 것 2개 항목

## 환경/도구 관찰
- §3.8.2 격리 패턴 (env -i HOME/PATH/PWD + bash -c + set -a/source/set +a + /usr/bin/python3) 정상 동작
- §3.34.41 f-string 제약 (3.9) 회피 위해 string concat 패턴 일관 적용
- §3.34.43 PWD 보강 (`PWD=/Users/mac`) 정상
- §3.34.46 gn-fetch-content 영구화 정상 (1단계 `.md` endpoint 즉시 fetch)
- 모든 기존 패턴 (§3.8.1 / §3.8.2 / §3.11 / §3.5 / §3.34.39~46 / #21) 정상 동작

## 연속 all-green
**49회차 (213~262차)** — 가짜 발행 가드 깨짐 없음.