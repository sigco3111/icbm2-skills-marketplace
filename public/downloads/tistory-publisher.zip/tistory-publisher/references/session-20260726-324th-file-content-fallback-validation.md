# 324차 — `--file` 재발 시 `--content` 단일 폴백 검증

## 재현

정상 Markdown 파일(`/tmp/post_324.md`)과 명시적 `--title`을 함께 넘겼지만 `tistory_publisher.py`가 다음 오류로 종료했다.

```text
❌ --title과 --content 또는 --file이 필요합니다.
```

같은 `--file` 호출을 반복하지 않고, 파일 내용을 그대로 읽어 `--content`로 한 번만 전환했다.

```bash
CONTENT=$(/usr/bin/python3 -c 'from pathlib import Path; print(Path("/tmp/post_N.md").read_text(encoding="utf-8"), end="")')
/usr/bin/python3 -s ~/.hermes/scripts/tistory_publisher.py \
  --title "$TITLE" --content "$CONTENT" \
  --tags "$TAGS" --visibility public --category "$CATEGORY_ID" \
  --source-url "$SOURCE_URL" --gn-topic-id "$GN_ID"
```

## 결과

- Markdown → HTML 자동 변환 및 본문 검증 통과
- 실제 발행 URL `https://sigco.tistory.com/1105` 획득
- proxy HTTP 200 및 `og:title` 정확 일치
- `daily_counts[오늘]` 5 → 6
- state `last_published_url`, `last_published_id`, `details[-1]` 및 `published_topics.last`가 모두 #1105로 동기화
- §3.5는 구조적 FAKE_PUBLISH 오탐을 반환했지만 proxy가 실제 글을 확인했으므로 정상 발행으로 확정

## 재사용 규칙

1. `--file` 파싱 오류는 동일 호출을 반복하지 말고 `--content`로 한 번만 폴백한다.
2. 성공 판정은 stdout의 숫자형 발행 URL만 채택한다.
3. commit 및 canonical topic hash 동기화 후 proxy `HTTP 200 + og:title`을 최종 진실로 사용한다.
4. §3.5 exit 1만 보고 롤백하지 않는다. 새 슬롯과 proxy가 일치하면 구조적 오탐이다.
