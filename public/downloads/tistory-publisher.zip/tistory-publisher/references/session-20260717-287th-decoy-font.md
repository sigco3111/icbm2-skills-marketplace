# 287차 세션 (2026-07-17) — `#1037 Decoy Font`

## 발행 결과
- **슬롯**: `#1037`
- **gn_topic_id**: 31513
- **카테고리**: AI/ML (1219746)
- **점수**: 3점 (FRESH AI/ML 1순위)
- **원본**: [GeekNews #31513 Decoy Font](https://news.hada.io/topic?id=31513)
- **라이브**: https://sigco.tistory.com/1037
- **상태**: ✅ 정상 발행

## 연속 all-green
- **74회차** (213~287차, 가짜 발행 가드 정상)

## 워크플로 정착 패턴 (287차 모두 정상 동작)

### 1. §3.8.1 세션 만료 가드 통과
```
status=200, ct=application/json;charset=UTF-8, cookie_count=8
→ ✅ OK: 세션 유효, 발행 진행
```

### 2. §3.34.40 v2 FRESH 4-field 매칭
- TOP 12개 후보 (286차 refresh-topics dry-run 결과):
  - 31498 (AI/ML 15점), 31501 (개발팁 9점), 31518 (개발팁 8점), 31514 (개발팁 8점)
  - 31509 (AI/ML 7점), 31521 (개발팁 6점), 31508 (AI/ML 6점), 31516 (AI/ML 3점)
  - 31513 (AI/ML 3점), 31510 (개발도구 3점), 31512 (개발도구 2점), 31507 (개발팁 2점)
- PUB set (이미 발행):
  - pt.details + state.details 양쪽 lookup
  - pt.last.gn_topic_id=31516 (286차 publish 잔재, v2 guard로 추가)
- FRESH 잔여 8개: 31501/31518/31514/31521/31513/31510/31512/31507
- '기타' FRESH = 0개

### 3. §3.34 #21 정책 + §3.34.45 매트릭스 4번째 분기
- FRESH 8개 중 AI/ML 1 (31513) + 비-AI/ML 7 (개발팁 4 + 개발도구 2 + 기타 0)
- 매트릭스 4번째 분기: "FRESH 'AI/ML' + 비-기타 혼재 → AI/ML 점수 1순위 픽"
- AI/ML 후보가 1개뿐이지만 비-기타 카테고리 점수 (개발팁 9점) 보다 우선
- → **픽: 31513 (AI/ML, 3점)**
- 비-AI/ML 9점 후보 `31501` + 8점 후보 `31518/31514` + 6점 후보 `31521` 자동 배제

### 4. §3.34.46 gn-fetch-content 영구화 호출
```python
import importlib.util
spec = importlib.util.spec_from_file_location(
    'gfc', '/Users/mac/.hermes/skills/automation/tistory-publisher/scripts/gn-fetch-content.py'
)
gfc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gfc)
text = gfc._try_md_endpoint(31513)
# → status=200, 6099 bytes 정상 fetch (1단계 .md endpoint)
```

### 5. §3.34.50 Topic Body 마커 기반 본문 추출
```python
m = re.search(r"## Topic Body\s*\n+(.*)", text, re.DOTALL)
body_md = m.group(1) if m else text
m_cmt = re.search(r"\n## Comments", body_md)
if m_cmt:
    body_md = body_md[:m_cmt.start()]
# → 본문 평문 2871자 (300자 가드 통과)
```

### 6. §3.34.47 격리 빌드 스크립트
- 경로: `/tmp/tistory_drafts_287th/build_draft_31513.py`
- 크기: 6850 bytes (UTF-8 선언 + `gfc` alias + md_to_html 5종 패턴 + intro/conclusion)
- 호출: `env -i HOME=/Users/mac PATH=/usr/bin:/bin PWD=/Users/mac /usr/bin/python3 <script>.py`
- 결과: draft-31513.html 4597 bytes, 본문 평문 3216자

### 7. publish (CLI 격리 bash 패턴)
```bash
env -i HOME=/Users/mac PATH=/usr/bin:/bin PWD=/Users/mac /bin/bash -c '
set -a; source ~/.hermes/secrets/tistory.env; set +a
/usr/bin/python3 /Users/mac/.hermes/scripts/tistory_publisher.py \
  --title "Decoy Font — AI와 OCR에는 다른 문자를 읽히는 TTF 글꼴이 공간 주파수 착시로 푸는 AI 스크래핑 문제" \
  --category 1219746 \
  --file /tmp/tistory_drafts_287th/draft-31513.html \
  --source-url "https://news.hada.io/topic?id=31513" \
  --gn-topic-id 31513 \
  --image-query "ttf decoy font typography hidden message hybrid image anti-ai text"
'
```

### 8. §3.11 post_publish_sync (7필드 보정)
```bash
env -i HOME=/Users/mac PATH=/usr/bin:/bin PWD=/Users/mac /bin/bash -c '
set -a; source ~/.hermes/secrets/tistory.env; set +a
/usr/bin/python3 ~/.hermes/skills/automation/tistory-publisher/scripts/post_publish_sync.py sync \
  --url "https://sigco.tistory.com/1037" \
  --title "..." \
  --gn-topic-id 31513 \
  --category "AI/ML" \
  --category-id 1219746 \
  --source-url "https://news.hada.io/topic?id=31513"
'
# → {"pt_updated": true, "state_updated": true, "errors": [], "triple_signal_match": true}
```

### 9. §3.5 5중 신호 검증
| 신호 | 값 |
|---|---|
| 1. state.last_published_url | https://sigco.tistory.com/1037 |
| 2. state.last.url | https://sigco.tistory.com/1037 |
| 3. state.details[-1].url | https://sigco.tistory.com/1037 |
| 4. pt.last.url | https://sigco.tistory.com/1037 |
| 5. pt.details[-1].url | https://sigco.tistory.com/1037 |

**all_match: True** ✅

### 10. daily_counts + state/pt.details 카운트
- daily_counts[2026-07-17] = `{'AI/ML': 10, '개발팁': 1}` (AI/ML 9→10, +1 정확)
- state.details 114→115
- pt.details 129→130

## cleanup cron 임무 상태
- **#16 dry-run**: `✅ 누설 없음` (73→**74회** 연속 all-green)
- cat_id 누설 0

## 이미지
- Picsum ID **410** 자동 매칭 (두 슬롯 동일)
- Query: "ttf decoy font typography hidden message hybrid image anti-ai text" (자연 영문 query 첫 빌드 적중)

## 라이브 페이지 검증
- `curl -sL https://sigco.tistory.com/1037` → status=200, size=58926
- `<title>` 태그: `Decoy Font &mdash; AI와 OCR에는 다른 문자를 읽히는 TTF 글꼴이 공간 주파수 착시로 푸는 AI 스크래핑 문제`

## §3.34 #21 AI/ML 우선 정책 실전 14호 (287차 검증)
- FRESH 8개 중 AI/ML 1 + 비-AI/ML 7, '기타' 0개 → 매트릭스 4번째 분기 정상
- 비-AI/ML 9점 후보 (`31501`) + 8점 후보 (`31518/31514`) + 6점 후보 (`31521`) 자동 배제
- 연혁: 255차 1호 → 266차 2호 → 268차 3호 → 269차 4호 → 270차 5호 → 271차 6호 → 280차 7호 → 281차 8호 → 282차 9호 → 283차 10호 → 284차 11호 → 285차 12호 → 286차 13호 → **287차 14호**

## §3.34.55 _try_md_endpoint 단일 변수 할당 5회째 검증
- 279차 31496 (21074 bytes) + 280차 31484 (4444) + 285차 31508 (5844) + 286차 31516 (10443) + **287차 31513 (6099)** 모두 정상 fetch

## 본 세션 신규 발견 0건
- 모든 기존 패턴(§3.8.1 가드 / §3.8.2 격리 / §3.11 sync / §3.34.40 v2 / §3.34.43 PWD / §3.34.46 영구화 / §3.34.47 격리 빌드 / §3.34.48 `*` 분기 / §3.34.50 Topic Body / §3.34.53 `gfc` alias / §3.34.54 `>` blockquote / §3.34.55 시그니처 함정 / §3.34 #21 정책 + #45 매트릭스 / cleanup #16) 정상 동작
- 차감/추가 없음