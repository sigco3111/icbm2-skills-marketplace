# 216차 세션 노트 (2026-07-08) — GPT-5.6 Sol Ultra #928 발행 + §3.33 신규 cleanup 함정

## 작업 요약

- **발행 #928**: GPT-5.6 Sol Ultra, Codex에 자동 sub-agent 오케스트레이션을 가져오다
- **Tistory URL**: https://sigco.tistory.com/928
- **카테고리**: AI 뉴스 (id=1219746 → 정규화 `'AI/ML'`)
- **긱뉴스 topic**: 31195 (https://news.hada.io/topic?id=31195)
- **본문**: 1,894자 (validate_content) / 3,254자 (HTML 원본)
- **이미지**: Picsum 자동 2장 (CDN 업로드 2/2, OG 썸네일 자동 설정)
- **3중 신호 검증**: ✅ Tistory=928 = state.last=928 = details[-1]=928, drift 0
- **stats 보정**: by_category[AI/ML] 714→715, daily_counts[2026-07-08][AI/ML] 2→3

## §3.33 신규 함정 (216차 발견)

### §3.33.1 — §3.32.1 cleanup heredoc의 "활성 필터 query" 함정 (216차 신규, ⭐⭐ cleanup 진단 함정)

**배경**: §3.32.1 cleanup heredoc이 처음 작성될 때 활성 페이지만 query하는 패턴이었음:
```python
# 잘못된 cleanup (활성 필터)
body = {"page_size": 100, "filter": {"property": status_prop, "select": {"equals": "활성"}}}
```

**문제**: 215차의 18건 사례를 다시 보면:
- URL 매칭 18건
- 활성 1건 + 비활성 17건
- **활성 필터 query → 1건만 응답 → 1건만 PATCH** (정상처럼 보임)

그러나 이 패턴은 **이미 cleanup으로 비활성화된 페이지가 다시 cleanup 시도되는 상황**(예: cleanup 스크립트가 실패했거나, 다른 차수에서 다시 활성화된 경우)을 발견 못 함. **§3.32.1의 핵심 가치는 "DB schema dump로 한글/영문 속성명 자동 감지"이지, "활성 필터링"이 아님.**

**216차 정답 cleanup heredoc**:
```python
# §3.33.1 — 전체 query + URL 매칭 (활성 필터 X)
body = {"page_size": 100}
all_pages = []
cursor = None
while True:
    body_iter = dict(body)
    if cursor:
        body_iter["start_cursor"] = cursor
    req = urllib.request.Request(
        f"https://api.notion.com/v1/databases/{DB_ID}/query",
        data=json.dumps(body_iter).encode('utf-8'),
        headers={**hdr, 'Content-Type': 'application/json'}
    )
    result = json.loads(urllib.request.urlopen(req, timeout=30).read())
    all_pages.extend(result.get('results', []))
    if not result.get('has_more'):
        break
    cursor = result.get('next_cursor')

print(f'전체 페이지 수: {len(all_pages)}')

# URL 매칭 (활성/비활성 무관) → 활성 페이지만 PATCH
target_url = "https://news.hada.io/topic?id=31195"
patches = 0
for page in all_pages:
    page_url = page.get('properties', {}).get(url_prop, {}).get('url', '') or ''
    page_id = page['id']
    page_status = page.get('properties', {}).get(status_prop, {}).get('select', {}).get('name', '?')

    if page_url == target_url:
        if page_status == '활성':
            # PATCH (활성 → 비활성)
            patch_body = {"properties": {status_prop: {"select": {"name": "비활성"}}}}
            req = urllib.request.Request(
                f"https://api.notion.com/v1/pages/{page_id}",
                data=json.dumps(patch_body).encode('utf-8'),
                headers={**hdr, 'Content-Type': 'application/json'},
                method='PATCH'
            )
            result = json.loads(urllib.request.urlopen(req, timeout=10).read())
            new_status = result.get('properties', {}).get(status_prop, {}).get('select', {}).get('name', '?')
            print(f'  ✅ {page_id[:8]} → {new_status}')
            patches += 1
        else:
            # 이미 비활성 → skip
            print(f'  ⏭️  {page_id[:8]} (이미 {page_status})')

print(f'\n총 PATCH: {patches}')

# 추가로 URL 매칭 모든 페이지의 status 분포 진단
url_status_dist = {}
for page in all_pages:
    page_url = page.get('properties', {}).get(url_prop, {}).get('url', '') or ''
    if page_url == target_url:
        s = page.get('properties', {}).get(status_prop, {}).get('select', {}).get('name', '?')
        url_status_dist[s] = url_status_dist.get(s, 0) + 1
print(f'URL 매칭 status 분포: {url_status_dist}')
# 예: {'활성': 1, '비활성': 17} → 정상 cleanup 후 {'비활성': 18}
```

**216차 실전 결과**:
- 전체 query: 1,944 페이지 (213차 1,934에서 +10 추가)
- 31195 URL 매칭: **1건** (활성)
- PATCH 1/1 → 비활성화
- ✅ 정상 cleanup

**영구화 권장**:
1. **`scripts/notion-cleanup-v3.py --deactivate-published-topics`**: 발행된 긱뉴스 topic URL을 입력받아 전체 DB query → URL 매칭 활성 페이지만 PATCH → 분포 진단 출력.
2. **활성 필터 query는 사용하지 말 것** — cleanup 자체의 silent fail 가시성 확보가 핵심.
3. **§3.32.1의 핵심은 "속성명 한글/영문 자동 감지"이지 "활성 필터링"이 아님** — 이 둘을 분리해서 기억할 것.

### §3.33.2 — `blog_pipeline.py --record-topic` 명령어 오용 함정 (216차 신규, ⭐⭐ 도구 사용 함정)

**배경**: §3.12 §3.13 등 이전 차수 문서에서 `blog_pipeline.py --record-topic TOPIC TITLE URL TOPIC_URL` 4개 인자 명령을 안내. 그러나 **216차 실전에서 이 명령을 실행하면**:

```
usage: blog_pipeline.py [-h] [--category CATEGORY] [--force-topic FORCE_TOPIC]
                        [--status] [--reset-daily] [--record TOPIC TITLE URL]
                        [--refresh-fallbacks] [--refresh-topics] [--dry-run]
                        [--commit TOPIC TITLE URL CATEGORY SOURCE_URL]
blog_pipeline.py: error: unrecognized arguments: --record-topic 31195 ...
```

**원인**: `blog_pipeline.py`의 `--record` 명령은 **3개 인자** (`TOPIC TITLE URL`)이지, `--record-topic`이 아님. 4개 인자(`TOPIC URL TOPIC_URL`)는 **`tistory_publisher.py --record-topic TOPIC TITLE URL TOPIC_URL`** 명령어임.

**올바른 사용**:
```bash
# blog_pipeline.py — 3개 인자 (last_titles + details 기록)
python3 ~/.hermes/scripts/blog_pipeline.py --record "31195" "GPT-5.6 Sol Ultra..." "https://sigco.tistory.com/928"
# → "✅ 발행 기록 추가: 31195 → GPT-5.6 Sol Ultra... | URL: ..."

# tistory_publisher.py — 4개 인자 (URL 기반 중복 방지 기록)
python3 ~/.hermes/scripts/tistory_publisher.py --record-topic "31195" "GPT-5.6 Sol Ultra..." "https://sigco.tistory.com/928" "https://news.hada.io/topic?id=31195"
# → published_urls.txt에 기록되어 URL 기반 중복 방지
```

**영구화 권장**:
1. cron 종료 시 `--record-topic` 대신 **`--record` 3개 인자** 사용 (이게 §3.11 5단계의 핵심).
2. 4개 인자가 필요한 경우는 `tistory_publisher.py --record-topic`으로 명시.
3. §3.12 §3.13 본문에서 4개 인자 예시를 보여줄 때 "이 예시는 `tistory_publisher.py --record-topic` 명령"으로 명시.

### §3.33.3 — Notion Blog DB ID 위치 (216차 신규, ⭐⭐ 환경 함정)

**배경**: cleanup heredoc 작성 시 DB ID가 필요. 216차에 `~/.hermes/secrets/notion_blog_db_id.txt` 파일이 **존재하지 않음** 확인:
```bash
$ ls ~/.hermes/secrets/ | grep -i notion
notion_token.txt  # 토큰만 존재
```

**올바른 위치**: **`~/.hermes/scripts/blog_pipeline.py`의 `NOTION_FALLBACK_DB_ID = "34276f2e-9097-811e-ab69-f8759ecf0be7"`** 하드코딩 (2026-07-08 시점).

**영구화 권장**:
1. cleanup heredoc 작성 시 위 하드코딩 값을 직접 사용 (현재 시점).
2. 또는 `grep NOTION_FALLBACK_DB_ID ~/.hermes/scripts/blog_pipeline.py`로 동적 추출:
```bash
DB_ID=$(grep -E "^NOTION_FALLBACK_DB_ID" ~/.hermes/scripts/blog_pipeline.py | sed -E 's/.*= *"([^"]+)".*/\1/')
```
3. 차후 `~/.hermes/secrets/notion_blog_db_id.txt`로 분리 시 secrets 파일 추가 + blog_pipeline.py도 동일하게 import.

### §3.33.4 — 216차 작업 타임라인

1. §3.8.1 3-endpoint probe: ✅ 200 OK 3/3 (Tistory max=927)
2. §3.30.4 0단계 state health check: ✅ drift 0 (Tistory=927, state=927, details=927)
3. `blog_pipeline.py --refresh-topics`: 12개 긱뉴스 토픽 (Anthropic 15점 / GLM 5.2 14점 / 저커버그 10점 / 취미 8점 / Astryx 8점 / gh-attach 7점 / J-space 6점 / GPT-5.6 5점 / 코드 청결도 4점 / Homegames 4점 / sneakerweb 3점 / Fable 3점)
4. `blog_pipeline.py --category 'AI/ML'`: score=15 Anthropic 후보 (state.last_topics에 동일 URL 박힘 → skip) → 1순위 GPT-5.6 #31195 (5점) 선택
5. 긱뉴스 `.md` endpoint 200 OK (7,001 bytes / 87 lines)
6. §3.23.1 frontmatter strip: 7,001 bytes → 7,000자
7. 한국어 본문 heredoc 1,894자 (validate_content)
8. Picsum 이미지 2장 자동 삽입 (CDN 업로드 2/2, OG 썸네일 자동 설정)
9. publish #928 (Tistory URL: `https://sigco.tistory.com/928`)
10. §3.33.1 §3.32.1 수정 cleanup heredoc (전체 query + URL 매칭):
    - 속성명 매핑: status='상태', title='이름', url='URL'
    - 전체 query: 1,944 페이지
    - 31195 URL 매칭: 1건 (활성)
    - PATCH 1/1 → 비활성화 ✅
11. §3.11 5단계 + §4 5-1 stats 보정:
    - Tistory API `category='AI 뉴스'` → `normalize_cat_key('AI 뉴스') = 'AI/ML'`
    - `by_category['AI/ML']: 714→715`
    - `daily_counts['2026-07-08']['AI/ML']: 2→3`
    - state.last.id=928, last_titles +1
12. `blog_details.json` append: topic_id=928, title=..., url=https://sigco.tistory.com/928
13. `blog_pipeline.py --record "31195" "..." "https://sigco.tistory.com/928"` (3개 인자)
14. §3.5 3중 신호 검증: ✅ drift 0 (Tistory=928 = state=928 = details=928)

### §3.33.5 — 영구화 all-green (216차)

| 패턴 | 차수 | 216차 결과 |
|---|---|---|
| §3.8.1 3-endpoint probe | 196차 | ✅ 200 OK 3/3 |
| §3.30.4 0단계 state health check | 213차 | ✅ drift 0 (시작) |
| §3.29.4 긱뉴스 `.md` endpoint | 212차 | ✅ 7,001 bytes (21195) |
| §3.23.1 frontmatter strip | 206차 | ✅ 7,000자 |
| §3.18 half-pipeline 직접 publish | 198~216차 | ✅ 1,894자 |
| §3.28.1 + §3.32.2 한글 key 정규화 | 211~215차 | ✅ `normalize_cat_key('AI 뉴스')` → 'AI/ML' |
| **§3.33.1 §3.32.1 수정 cleanup** (216차 신규) | 216차 | ✅ 전체 query + URL 매칭 1/1 (활성 1건 비활성화) |
| §3.32.1 Notion 한글 속성명 매핑 | 215차 | ✅ `상태`/`이름`/`URL` 자동 감지 |
| §3.5 3중 신호 검증 | 195차 | ✅ drift 0 (종료) |
| §3.11 + §4 5-1 stats 보정 | 200차 | ✅ 정상 +1 |
| **§3.33.2 `--record` 3개 인자** (216차 신규) | 216차 | ✅ 정상 등록 |
| **§3.33.3 blog_pipeline.py DB ID 하드코딩** (216차 신규) | 216차 | ✅ NOTION_FALLBACK_DB_ID 사용 |

**누적 영구화 all-green 통과 차수**: 213차~216차 연속 4회 (drift 0 시작/종료 + cleanup + stats 보정 풀 사이클).

### §3.33.6 — 216차 핵심 교훈

1. **§3.33.1 §3.32.1 cleanup은 활성 필터 X, 전체 query + URL 매칭**: §3.32.1의 핵심 가치는 "DB schema dump로 한글/영문 속성명 자동 감지"이지 "활성 필터링"이 아님. 활성 필터 query는 cleanup 자체의 silent fail를 가린다. **영구화**: cleanup heredoc은 항상 전체 query → URL 매칭 → 활성 페이지만 PATCH. 216차 1,944 페이지에서 31195 매칭 1건 → PATCH 1/1 → 정상.
2. **§3.33.2 `--record-topic` 명령어 오용**: `blog_pipeline.py`는 `--record TOPIC TITLE URL` (3개 인자), `tistory_publisher.py`는 `--record-topic TOPIC TITLE URL TOPIC_URL` (4개 인자). cron은 `blog_pipeline.py --record` 3개 인자 사용.
3. **§3.33.3 Notion Blog DB ID는 blog_pipeline.py에 하드코딩**: `~/.hermes/secrets/notion_blog_db_id.txt` 없음 → cleanup heredoc은 `NOTION_FALLBACK_DB_ID = "34276f2e-9097-811e-ab69-f8759ecf0be7"` 직접 사용 또는 grep으로 동적 추출.
4. **213~216차 연속 4회 영구화 all-green**: 0단계 health check → publish → cleanup → stats 보정 → drift 검증 풀 사이클이 안정화 단계 정착. cleanup heredoc의 §3.33.1 수정으로 silent fail 가능성 차단.

## 세션 노트 메타데이터

- **차수**: 216차
- **날짜**: 2026-07-08
- **발행 #**: 928
- **긱뉴스 topic**: 31195 (GPT-5.6 Sol Ultra)
- **영구화 차수**: 213~216차 연속 4회
- **관련 차수**: 215차 (§3.32 Notion 한글 속성명), 213차 (§3.30 state recovery), 212차 (§3.29 normalize)