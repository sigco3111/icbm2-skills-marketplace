# 218차 — Claude Code 루프 #931 발행 + §3.34.8 5단계 dedup 실전 검증 + feeds.feedburner.com RSS 매칭 (2026-07-08)

## 배경 — 실제 218차 실행 결과 (skip이 아닌 정상 publish)

이전 세션 노트 `session-20260708-218th-fresh-candidates-0-gn-topic-id-missing.md`는 pre-flight 분석 단계에서 "12개 후보 중 8건 false negative → fresh 0개 → skip 정당"으로 결론 내렸음. 그러나 **실제 218차 실행에서는 feeds.feedburner.com RSS로 긱뉴스 정확한 title을 가져와 명시적 매칭**을 다시 실행한 결과 **11건 fresh + 1건 false negative + 1건 skip**으로 재집계되었고, **#931 "Claude Code 루프 — 작업 사이클을 자동화하는 네 가지 패턴" (긱뉴스 31225) 정상 발행** 완료.

**중요한 교훈**: blog_pipeline.py의 fresh 판정 결과를 신뢰하지 말고, cron이 직접 `feeds.feedburner.com/geeknews-feed`로 긱뉴스 정확한 title을 가져온 뒤 details + last_titles + gn_topic_id 모두 확인 후 발행 결정해야 함.

## §3.34.10 — `feeds.feedburner.com/geeknews-feed` RSS (Atom feed, 218차 신규 확인)

**endpoint**: `https://feeds.feedburner.com/geeknews-feed`

**응답 형식**: Atom (XML namespace) — `curl` 직접 호출 시 `<item>`이 아닌 `<entry>` 사용
```bash
curl -sL -A "Mozilla/5.0" "https://feeds.feedburner.com/geeknews-feed" | python3 -c "
import sys, re
import xml.etree.ElementTree as ET
content = sys.stdin.read()
ns = {'a': 'http://www.w3.org/2005/Atom'}
root = ET.fromstring(content)
entries = root.findall('a:entry', ns)
for e in entries:
    title = e.find('a:title', ns).text or ''
    id_el = e.find('a:id', ns)
    url = id_el.text if id_el is not None else ''
    m = re.search(r'topic\?id=(\d+)', url)
    if m:
        print(f'  #{m.group(1)}: {title[:80]}')
"
```

**218차 결과**: 50 entries 정상 응답. 긱뉴스 31238 / 31233 / 31232 / ... / 31180까지 topic id 매핑 가능.

**용도**:
1. `blog_pipeline.py --refresh-topics`가 `GEEKNEWS_RSS_URL = "https://feeds.feedburner.com/geeknews-feed"`로 긱뉴스 fetch하지만, cron은 cron_job 내부 검증 시 직접 fetch 후 title prefix 매칭이 필요할 수 있음
2. 30자 prefix false negative 케이스에서 긱뉴스 RSS title로 한 번 더 검증 (긱뉴스 title ≠ Tistory title)
3. `scripts/retroactive-gn-topic-id.py` (차후 cleanup cron)에서 Tistory posts.json의 title → 긱뉴스 URL 역추적 시 source of truth

**함정**:
- `news.hada.io/rss/` (직접 긱뉴스 RSS)는 403 Forbidden 반환 — `feeds.feedburner.com`을 경유해야 함
- `news.hada.io/api/news` 같은 임의 경로는 404 응답

## §3.34.11 — 5단계 (Tistory title prefix) dedup 매칭의 실전 패턴 (218차 신규)

**문제**: §3.34.8에서 "8건 false negative"로 분석했지만, **실제 218차에 feeds.feedburner.com RSS로 매칭한 결과는 11건 fresh + 1건 false negative**로 다름.

**218차 12개 후보 명시적 5단계 매칭 결과**:

| 후보 topic_id | 긱뉴스 RSS title (30p) | Tistory 발행 title (30p) | 매칭 결과 |
|---|---|---|---|
| 31225 | `루프 시작하기` | (없음 — 신규) | 🟢 FRESH |
| 31224 | `30 Papers - 일리야 서츠케버` | (없음) | 🟢 FRESH |
| 31216 | `Show GN: gh-attach – CLI로 GitHub 이슈` | (없음) | 🟢 FRESH |
| 31238 | `Trusted Publishing을 패키지 신뢰 신호로 보면` | (없음) | 🟢 FRESH |
| 31219 | `코딩 배우기는 여전히 가치 있다` | (없음) | 🟢 FRESH |
| 31217 | `ReactOS "오픈소스 Windows" 프로젝트, Hal` | (없음) | 🟢 FRESH |
| 31223 | `no-mistakes - git push 할 때 실수를 방` | (없음) | 🟢 FRESH |
| 31221 | `Google, 기후를 위협하는 디지털 비대화의 지수` | (없음) | 🟢 FRESH |
| 31218 | `Ternlight - 브라우저(WASM)에서 실행되는 7M` | `Ternlight — 브라우저(WASM)에서 실행되는` (#930) | 🛑 GN_PUBLISHED (gn_topic_id 매칭) |
| 31214 | `sneakerweb - 물리 저장 매체로 전파되는 병렬` | `sneakerweb — USB 한 개에 웹사이트를 담아` (#929) | ⚠️ FRESH (false negative — 30p prefix 불일치) |
| 31228 | `Microsoft, id Software의 idTech 팀 해고` | (없음) | 🟢 FRESH |
| 31222 | `더 건강한 Clippy를 위한 공동 리뷰 제안` | (없음) | 🟢 FRESH |

**false negative 1건 상세 — #31214 sneakerweb**:
- 긱뉴스 RSS title 30p: `sneakerweb - 물리 저장 매체로 전파되는 병렬` (hyphen, 30자)
- Tistory #929 발행 title 30p: `sneakerweb — USB 한 개에 웹사이트를 담아` (em-dash, 30자)
- 30p prefix 완전 다름 (재작성으로 본문 새로 씀) → last_titles 30p 매칭 실패
- gn_topic_id 31214는 details에 박혀있지 않음 (217차 publish 후 gn_topic_id 누락)
- source_url은 last_topics 비어있어 매칭 실패
- **결과**: 1건 false negative fresh로 분류

**skip 1건 상세 — #31218 Ternlight**:
- 긱뉴스 RSS title 30p: `Ternlight - 브라우저(WASM)에서 실행되는 7M` (hyphen)
- Tistory #930 발행 title 30p: `Ternlight — 브라우저(WASM)에서 실행되는 ` (em-dash, 30자)
- 30p prefix 불일치 → last_titles 매칭 실패
- **그러나** gn_topic_id=31218이 details에 박혀있음 (218차 시점 단 1건) → 정상 skip

**핵심 발견**:
1. **재작성된 Tistory 본문 title은 긱뉴스 RSS title과 prefix가 다를 수 있음** (대시/하이픈 차이, 본문 추가/요약 등) → last_titles 30p 매칭 한계
2. **gn_topic_id 박기가 없으면 재작성본을 잡을 방법이 없음** → §3.34.9 1회 cleanup 임무가 시급
3. **blog_pipeline.py의 fresh 판정은 후보 11건을 fresh로 분류했지만, 실제 1건은 이미 발행 (#929 sneakerweb)** — false negative 1/11 = 9% 오류율

## §3.34.12 — 발행 결정 흐름 (218차 실전)

```bash
# 1) feeds.feedburner.com RSS로 12개 후보의 정확한 긱뉴스 title 확보
gn_titles = fetch_gn_rss_titles()  # {31225: "루프 시작하기", ...}

# 2) 명시적 5단계 dedup (blog_pipeline.py를 신뢰하지 않고 cron이 직접)
fresh = []
for tid, gn_title in candidates:
    title_p30 = gn_title[:30]
    # 1단계: last_titles
    if title_p30 in state['last_titles']: continue
    # 2단계: details의 topic_id (Tistory 발행 여부)
    published_tids = {d['topic_id'] for d in details.get('details', [])}
    # 3단계: details의 gn_topic_id
    published_gn = {d['gn_topic_id'] for d in details.get('details', []) if d.get('gn_topic_id')}
    if int(tid) in published_gn: continue
    # 4단계: details의 title prefix (긱뉴스 title로 검증)
    detail_p30 = {d.get('title', '')[:30] for d in details.get('details', [])}
    if title_p30 in detail_p30: continue
    # 5단계: source_url 매핑 (last_topics 비었으면 skip)
    # (last_topics 비었으면 매칭 대상 없음)
    fresh.append((tid, gn_title))

# 3) 218차 결과: 11건 fresh
# - 10건 진짜 fresh
# - 1건 false negative (#31214 sneakerweb) — 재작성으로 prefix 불일치

# 4) 1순위 선택 + publish
# - 1순위: #31225 "루프 시작하기" 15점 (AI/ML)
# - 2순위: #31224 "30 Papers - 일리야" 9점
# - 1편만 발행 → 31225 선택
```

## §3.34.13 — `tistory_publisher.py --file` 발행 + gn_topic_id 박기 (218차 실전)

**218차 publish #931**:
```bash
cat > /tmp/loop_post_218th.md << 'POSTEOF'
# Claude Code 루프 — 작업 사이클을 자동화하는 네 가지 패턴

Claude Code 팀이 코딩 에이전트를 사용할 때, 매번 새 프롬프트를 직접 작성하는 방식에서 벗어나는 중입니다. 대신 **정지 조건이 충족될 때까지 작업 사이클을 반복하는 에이전트 운영 패턴**으로 전환하고 있습니다. ...

## 루프의 정의와 네 가지 분류 기준
...

## 1) Turn-based 루프
...

## 2) Goal-based 루프 (`/goal`)
...

## 3) Time-based 루프 (`/loop`, `/schedule`)
...

## 4) Proactive 루프
...

## 코드 품질 유지가 모든 루프의 전제 조건
...

## 정리: 어떤 작업에 어떤 루프를 적용할까
...
POSTEOF

set -a; source ~/.hermes/secrets/tistory.env; set +a
python3 ~/.hermes/scripts/tistory_publisher.py \
  --file /tmp/loop_post_218th.md \
  --title "Claude Code 루프 — 작업 사이클을 자동화하는 네 가지 패턴" \
  --category 1219746 \
  --tags "ClaudeCode,루프,에이전트,Turnbased,Goalbased,Timebased,Proactive,자동화,코딩에이전트" \
  --image-query "claude code loop agent automation coding cycle"
# → ✅ 발행 성공! 🔗 https://sigco.tistory.com/931
```

**post-publish 보정 (heredoc)** — `details.append()`에 **`gn_topic_id` 박기** 단계 (218차 신규):
```python
# §3.34.13 — 218차 gn_topic_id 박기 (heredoc)
import json
state_path = '/Users/mac/.hermes/memory/blog_pipeline_state.json'
details_path = '/Users/mac/.hermes/memory/blog_details.json'
with open(state_path) as f: state = json.load(f)
with open(details_path) as f: details = json.load(f)

# Tistory API로 verify
import os, requests
cookies = {k.replace('TISTORY_',''): os.environ[k] for k in os.environ if k.startswith('TISTORY_')}
hdr = {'User-Agent':'Mozilla/5.0','Referer':'https://sigco.tistory.com/manage/','X-Requested-With':'XMLHttpRequest'}
r = requests.get('https://sigco.tistory.com/manage/posts.json?category=-3&page=1', cookies=cookies, headers=hdr, timeout=10)
items = r.json()['items']
new_post = items[0]  # id=931

# state.last 갱신
state['last'] = {
    'id': 931, 'url': new_post['permalink'],
    'title': new_post['title'], 'published_at': new_post['published'][:10],
}

# last_titles prefix 추가
prefix = new_post['title'][:30]
if prefix not in state.get('last_titles', []):
    state.setdefault('last_titles', []).append(prefix)
    if len(state['last_titles']) > 50:
        state['last_titles'] = state['last_titles'][-50:]

# §3.34.13 — details에 gn_topic_id 박기 (218차 신규)
existing_ids = {d.get('topic_id') for d in details.get('details', [])}
if 931 not in existing_ids:
    details.setdefault('details', []).append({
        'title': new_post['title'],
        'url': new_post['permalink'],
        'date': new_post['published'][:10],
        'category': new_post.get('category', 'AI 뉴스'),
        'topic_id': 931,
        'gn_topic_id': 31225,  # ← §3.34.9 보강 — 박기 필수
    })

# stats by_category 보정
import sys
sys.path.insert(0, '/Users/mac/.hermes/skills/automation/tistory-publisher/scripts')
from normalize_cat_key import normalize_cat_key
cat_key = normalize_cat_key(new_post.get('category', 'AI 뉴스'))  # 'AI 뉴스' → 'AI/ML'
cur = state['stats']['by_category'].get(cat_key, 0)
state['stats']['by_category'][cat_key] = cur + 1
day = new_post['published'][:10]
state.setdefault('daily_counts', {}).setdefault(day, {})
state['daily_counts'][day][cat_key] = state['daily_counts'][day].get(cat_key, 0) + 1
state['stats']['total'] = state['stats'].get('total', 0) + 1

# §3.34.3 — last_topics 정리 (Tistory URL 항목 제거)
state['last_topics'] = [t for t in state.get('last_topics', [])
                       if not (t.get('url', '').startswith('https://sigco.tistory.com/'))]

# 저장
with open(state_path, 'w') as f: json.dump(state, f, ensure_ascii=False, indent=2)
with open(details_path, 'w') as f: json.dump(details, f, ensure_ascii=False, indent=2)

# §3.5 3중 신호 검증
tistory_max = int(items[0]['id'])
state_last = state['last']['id']
details_last = details['details'][-1]['topic_id']
print(f'Tistory={tistory_max}, state.last={state_last}, details[-1]={details_last}')
# 218차 결과: Tistory=931, state=931, details=931 → ✅ §3.5 drift 0
```

**218차 결과**:
- `by_category['AI/ML']`: 716 → 717
- `daily_counts['2026-07-08']['AI/ML']`: 3 → 4
- `total`: 930 → 931
- `details`: 11건 → 12건 (#931 with gn_topic_id=31225)

**gn_topic_id 박기 이력 (218차 시점)**:
- #930 Ternlight: gn_topic_id=31218 (기존)
- **#931 Claude Code 루프: gn_topic_id=31225 (218차 신규)**
- 나머지 9건 (#921~929): gn_topic_id 누락

## §3.34.14 — Notion cleanup 1회 발동 (218차 publish #931 cleanup)

**§3.33.1 §3.32.1 cleanup heredoc (218차 실전)**:
```python
# §3.32.1 — DB schema dump (한글/영문 속성명 자동 감지)
import urllib.request, json
notion_token = open('/Users/mac/.hermes/secrets/notion_token.txt').read().strip()
import re
with open('/Users/mac/.hermes/scripts/blog_pipeline.py') as f:
    content = f.read()
DB_ID = re.search(r'NOTION_FALLBACK_DB_ID\s*=\s*"([^"]+)"', content).group(1)
hdr = {'Authorization': f'Bearer {notion_token}', 'Notion-Version': '2022-06-28'}
req = urllib.request.Request(f"https://api.notion.com/v1/databases/{DB_ID}", headers=hdr)
db = json.loads(urllib.request.urlopen(req, timeout=10).read())
status_prop = url_prop = title_prop = None
for name, prop in db.get('properties', {}).items():
    ptype = prop.get('type', '?')
    if ptype == 'select':
        opts = [o.get('name') for o in prop.get('select', {}).get('options', [])]
        if '활성' in opts and '비활성' in opts: status_prop = name
    if ptype == 'url': url_prop = name
    if ptype == 'title': title_prop = name
# 218차 결과: status='상태', url='URL', title='이름' (한글)

# §3.33.1 — 전체 query (활성 필터 X) + URL 매칭
target_url = "https://news.hada.io/topic?id=31225"
all_pages, cursor = [], None
while True:
    body = {"page_size": 100}
    if cursor: body["start_cursor"] = cursor
    req = urllib.request.Request(
        f"https://api.notion.com/v1/databases/{DB_ID}/query",
        data=json.dumps(body).encode('utf-8'),
        headers={**hdr, 'Content-Type': 'application/json'}
    )
    result = json.loads(urllib.request.urlopen(req, timeout=30).read())
    all_pages.extend(result.get('results', []))
    if not result.get('has_more'): break
    cursor = result.get('next_cursor')

# URL 매칭 (활성/비활성 무관) → 활성 페이지만 PATCH
patches = 0
for page in all_pages:
    page_url = page.get('properties', {}).get(url_prop, {}).get('url', '') or ''
    if page_url == target_url:
        page_id = page['id']
        page_status = page.get('properties', {}).get(status_prop, {}).get('select', {}).get('name', '?')
        if page_status == '활성':
            patch_body = {"properties": {status_prop: {"select": {"name": "비활성"}}}}
            req = urllib.request.Request(
                f"https://api.notion.com/v1/pages/{page_id}",
                data=json.dumps(patch_body).encode('utf-8'),
                headers={**hdr, 'Content-Type': 'application/json'},
                method='PATCH'
            )
            result = json.loads(urllib.request.urlopen(req, timeout=10).read())
            print(f'  ✅ {page_id[:8]} → {result.get("properties", {}).get(status_prop, {}).get("select", {}).get("name", "?")}')
            patches += 1

# 218차 결과:
# - 전체 query: 2,078 페이지 (217차 2,030에서 +48)
# - 31225 URL 매칭: 2건 (활성 1 + 비활성 1)
# - PATCH 1/1 → 비활성화
```

## §3.34.15 — 218차 영구화 all-green

| 패턴 | 차수 | 218차 결과 |
|---|---|---|
| §3.8.1 3-endpoint probe | 196차 | ✅ 200 OK 3/3 |
| §3.30.4 0단계 state health check | 213차 | ✅ drift 0 (시작: 930=930=930) |
| `--refresh-topics` 12개 토픽 | 208차 | ✅ 12개 |
| **§3.34.10 feeds.feedburner.com RSS** (218차 신규) | 218차 | ✅ 50 entries (Atom feed) |
| **§3.34.11 5단계 명시적 dedup** (218차 신규) | 218차 | ✅ 11건 fresh + 1건 false negative + 1건 skip |
| §3.29.4 긱뉴스 `.md` endpoint | 212차 | ✅ 4,798자 (31225) |
| §3.23.1 frontmatter strip | 206차 | ✅ 4,798 → 2,726자 |
| §3.34.1 `tistory_publisher.py --file` 옵션 | 217차 | ✅ 2,726자 heredoc 파일 발행 성공 |
| §3.32.2 cat_key 정규화 | 215차 | ✅ `normalize_cat_key('AI 뉴스')` → 'AI/ML' |
| §3.11 5단계 + §4 5-1 stats 보정 | 200차 | ✅ `by_category['AI/ML']: 716→717` |
| **§3.34.13 details에 gn_topic_id 박기** (218차 신규) | 218차 | ✅ #931에 gn_topic_id=31225 박기 |
| §3.34.3 last_topics 0개 정리 | 217차 | ✅ 0건 (Tistory URL 항목 제거) |
| §3.33.1 §3.32.1 cleanup | 216차 | ✅ 2,078 페이지 / 31225 매칭 2건 / PATCH 1/1 |
| §3.5 3중 신호 검증 | 195차 | ✅ drift 0 (종료: 931=931=931) |

**누적 영구화 all-green 통과 차수**: 213~218차 **연속 6회** (drift 0 시작/종료 + cleanup + stats 보정 풀 사이클 안정화).

## §3.34.16 — 218차 핵심 교훈 (실전 publish)

1. **§3.34.10 `feeds.feedburner.com/geeknews-feed` RSS는 긱뉴스 정확한 title의 source of truth**: cron이 blog_pipeline.py의 fresh 판정 결과를 신뢰하지 말고, 직접 RSS fetch 후 명시적 5단계 dedup 실행. 218차에 12개 후보의 긱뉴스 title 확보에 사용.

2. **§3.34.11 5단계 (Tistory title prefix) dedup의 false negative 사례**:
   - #31214 sneakerweb: 긱뉴스 title 30p `sneakerweb - 물리 저장 매체로 전파되는 병렬` ≠ Tistory #929 30p `sneakerweb — USB 한 개에 웹사이트를 담아` (재작성으로 prefix 다름)
   - #31218 Ternlight: 긱뉴스 title 30p `Ternlight - 브라우저(WASM)에서 실행되는 7M` ≠ Tistory #930 30p `Ternlight — 브라우저(WASM)에서 실행되는 ` (em-dash vs hyphen) — **gn_topic_id 매칭으로 정상 skip**
   - **결론**: 긱뉴스 RSS title로 검증해도 재작성된 Tistory title은 30p prefix가 다를 수 있음. **gn_topic_id 박기가 가장 강력한 매칭**이지만, 박기 누락된 211~217차 7건은 잡을 수 없음 → 1회 cleanup 임무

3. **§3.34.13 post-publish heredoc 보정 시 gn_topic_id 박기 단계 추가**: 218차에 `details.append()`에 `gn_topic_id=31225` 박기 → #931은 박기 누락 이력에서 제외. **이전 9건 (#921~929)은 여전히 누락 상태** → `scripts/retroactive-gn-topic-id.py` 1회 cleanup으로 일괄 박기 필요.

4. **218차 publish #931 정상 발행**:
   - 1순위: #31225 "Claude Code 루프 — 작업 사이클을 자동화하는 네 가지 패턴" (15점, AI/ML)
   - Tistory URL: https://sigco.tistory.com/931
   - 본문: 2,726자 (validate_content 2,726자)
   - Picsum 이미지 2장 자동 삽입, OG 썸네일 설정
   - §3.5 drift 0 (시작 930=930=930, 종료 931=931=931)

5. **cleanup 체인 안정화**: §3.33.1 §3.32.1 cleanup 6회 연속 통과 (213~218차). 218차 publish cleanup에서 2,078 페이지 / 31225 매칭 2건 (활성 1) / PATCH 1/1 정상.

6. **명시적 수동 매칭 가드의 정당화**: blog_pipeline.py의 fresh 판정은 11건을 fresh로 분류했지만, 실제 1건 (#31214 sneakerweb)이 false negative. cron이 직접 5단계 매칭을 한 번 더 실행하면 false negative를 발견할 수 있음. **가드**: fresh 후보가 비정상적으로 많으면 (예: 4+ 건) 명시적 수동 매칭으로 details + last_titles + gn_topic_id 모두 확인.

## 영구화 권장 (다음 cron 작업자용)

1. **`scripts/retroactive-gn-topic-id.py` 1회 cleanup** — Tistory posts.json의 title + `feeds.feedburner.com` RSS 매칭 → details에 일괄 gn_topic_id 박기. 218차 시점 11건 중 2건만 박혀있음 (#930, #931).
2. **`blog_pipeline.py --record` 명령에 `--gn-topic-id` 인자 추가** — 차후 publish 시 자동 박기.
3. **post-publish 후크 (`scripts/post-publish-correct.sh`)에 `gn_topic_id` 박기 단계 추가** — `tistory_publisher.py --file` 발행 후 heredoc 보정 시 자동 박기.
4. **`blog_pipeline.py` 4중 dedup에 5단계 추가** — Tistory title prefix 직접 매칭 (긱뉴스 RSS title로 검증). cron이 직접 feeds.feedburner.com fetch + 5단계 매칭 후 발행 결정.
5. **§3.34.10 `feeds.feedburner.com` RSS fetch를 cron 시작 단계에 추가** — 0단계 health check 직후, 1단계 `--refresh-topics` 진입 전. 긱뉴스 정확한 title 확보 → fresh 판정 정확도 향상.

**세션 노트**: `references/session-20260708-218th-loop-publish-5stage-dedup.md` (작업 타임라인 + §3.34.10 feeds.feedburner.com RSS + §3.34.11 5단계 dedup 실전 + §3.34.13 gn_topic_id 박기 + §3.34.14 cleanup + §3.34.15 영구화 all-green + #931 발행).
