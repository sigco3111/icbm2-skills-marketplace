# 316차 세션 노트 (2026-07-23 20:00)

## 결과
- **#1089 발행 성공** — "Bento - 파일 하나에 모두 들어가는 오피스 스위트 — 단일 HTML 파일 오피스의 현 주소" (gn=31704, AI/ML)
- proxy status=200 + title + og:title 정확 매칭
- OG 썸네일 `https://blog.kakaocdn.net/dna/Z6Ccu/dJMcacYe12W/AAAAAAAAAAAA...` 정상 설정
- Picsum 이미지 2장 (seed: bento-office-singlefile / bento-all-in-one-document)
- 본문 2741자 빌드

## 워크플로우
1. **§3.8.1 가드**: raw VALID (status=200, application/json, 8 쿠키, first_ids=['1088','1087','1086','1085','1084'])
2. **§3.5 진입 시점**: 신호 4 FAKE_PUBLISH 발동 (state.last=#1088, details[-1]=#1088, daily_counts[2026-07-23]={AI/ML:7, 개발도구:1} 합계 8) → **5-5 proxy check disambiguate 21연속 트리거**:
   - #1088 (디자이너 칼) status=200 + og:title 매칭 ✅
   - #1087 (미국 5대 기술기업 SPV) status=200 + og:title 매칭 ✅
   - #1086 ('No AI' 표시) status=200 + og:title 매칭 ✅
   - #1085 (Linux 커널 CVE 432) status=200 + og:title 매칭 ✅
   - → 직전 차 발행 4건 모두 진짜 발행, 신호 4 오탐 확정
3. **§3-a**: AI/ML status=ready (gn=31704 "Bento - 파일 하나에 모두 들어가는 오피스 스위트")
4. **§3-b 단일 패스 패턴 (12연속 정형화, 305차 확립)**: `build_post_316.py` 안에 `requests.get(gn_url) + <meta property="og:description"> regex` 임베드 → 160자 description 추출
5. **§3.11 5단계 보정**:
   - 5-2 commit_publish (stats.today={AI/ML:8, 개발도구:1}, total=85)
   - 5-3 last_published_url+id 보정 (#1088→#1089, details_len 161→162)
   - 5-2-A 백필 1건 (누적 동기화, pt_details_len 162→163)
   - 5-4 §3.5 신호 4 발동 (구조적 오탐 — details append+last 동시 갱신 시 무조건 발동)
   - 5-5 proxy check #1089 status=200 + og:title 정확 매칭 disambiguate 통과

## 관찰
- **연속 all-green 96회차** (288차 가드 도입 이후)
- **신호 4 오탐 disambiguate 21연속 확정** (298→316) — 정상 워크플로의 일부로 완전히 정착
- **305차 단일 패스 패턴 12연속 정형화**
- **진입 시점 신호 4 + 5-5 disambiguate 트리거 7연속 확정** (310~316)
- **311차 fallback 패턴 후 정상 publish 복귀 6차 연속 안정 유지** — fallback은 안정 운영 상태의 일부로 정착

## 함정 회피 5중 동시 확인
- 함정 6 (heredoc + env -i SyntaxError)
- 함정 7 (--category int만)
- 함정 11 (execute_code cron 차단 회피)
- 함정 14 (import os 누락)
- 함정 15 (5-5 proxy check 격리 패턴)
- 모두 316차 워크플로에서 자동 회피 성공

## 함정 8 영구 잔존 20연속
- by_category["1219746"]=1 정수 ID 키 누적 (297차 #1048 발행 시 첫 매핑 후 영구 잔존)
- 사용자 게이트 시 ID_TO_NAME 1회 보정으로 영구 해결 가능
- cron은 drift 보고만 유지 (임의 자동 보정 금지)

## 다음 차 운영 권장
- cron이 매 차 진입 시 §3.5 신호 4가 발동해도 5-5 proxy check disambiguate는 정형 패턴 — drift 라인에 명시 불필요
- 단일 패스 패턴 (`build_post_NNN.py`) 그대로 유지
- by_category["1219746"]=1 영구 누적은 사용자 게이트 전까지 drift 보고만 유지
