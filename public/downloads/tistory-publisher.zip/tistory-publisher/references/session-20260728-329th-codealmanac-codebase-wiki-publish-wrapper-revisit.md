# 329차 세션 노트 — CodeAlmanac 코드베이스 위키, publish wrapper 재확인, 5-2-A 안전망 확장

**시각**: 2026-07-28 00:03 KST
**차수**: 329차
**all-green 회차**: 104회차

## 발행 결과

- **#1118** "CodeAlmanac - AI 코딩 에이전트를 위한 코드베이스 위키 — 코드베이스 전체를 한 번에 이해시키는 검색 인프라"
- gn=31845, AI/ML (1219746)
- 본문 4714자 (코드 블록 4개 + 이미지 2장 + 푸터)
- OG 썸네일 `https://blog.kakaocdn.net/dna/bdbACE/dJMcacRscLQ/AAAAAAAAAAA...` 정상
- proxy status=200 + title 정확 매칭 + og:title 정확 매칭

## 워크플로우 8단계 정상 작동

1. §3.8.1 raw VALID (status=200, content_type=application/json, cookies=8, first_id=#1117 — 328차 #1117 진짜 존재)
2. 트렌드 12개 새로고침
3. AI/ML ready (`status=ready`, gn=31845, timeliness.ok)
4. 진입 단계 §3.5 신호 1 drift — daily_counts=0 (자연 상태, 어제 #1117 정상) — 발행 진행
5. 본문 빌드 `/tmp/build_post_329.py` (단일 패스, description fetch + body 생성)
6. publish wrapper `/tmp/publish_329.py` (`from tistory_publisher import load_cookies, publish_post` 직접 호출)
7. §3.11 5단계 sync (5-2 commit, 5-3 last+details, 5-2-A 안전망 1건)
8. §3.5 3중 신호 일치 + §3.11 5-5 proxy check PASS

## 329차 신규/재확인 학습

### 1. 함정 17 임계점 정량화 갱신

| 차수 | 본문 | 코드 블록 | docstring/푸터 | 단일 f-string | 비고 |
|------|------|-----------|----------------|---------------|------|
| 317차 #1096 NvChat | 6952자 | 다수 | 있음 | ❌ SyntaxError | 임계점 직상단 |
| 318차 #1097 Chrome Ext | 2776자 | 적음 | 있음 | ✅ OK | 함정 17 무관 |
| **329차 #1118 CodeAlmanac** | **4714자** | **4개** | **푸터** | **✅ OK** | **본 갱신** |

**판정 갱신**:
- 본문 길이보다 **f-string 내부 결합 복잡도**가 더 강한 신호.
- **본문 < 5000자 + 결합 ≤ 3중** = 단일 f-string OK
- **본문 ≥ 5000자 또는 결합 ≥ 4중** = parts.append() 권장
- **코드 블록 개수가 가장 강한 신호** — 4개 이상이면 docstring/푸터와 결합 시 lint 위험.

**왜 317차 6952자가 실패하고 329차 4714자가 성공했나?**
- 317차는 본문 + docstring(다수) + 코드 블록(다수) + 푸터 + 마지막 출처 링크 모두 단일 f-string 안에 결합. f-string 내부 `{...}` 안의 docstring이 non-ASCII 따옴표와 만나면서 SyntaxError.
- 329차는 본문 + 4개 코드 블록 + 푸터만 결합. docstring을 f-string 안에 넣지 않고 별도 변수로 분리. 결합 수가 3중이라 lint가 OK.

### 2. 5-2-A 안전망 (4) 단계 신규 추가

기존 (1)~(3):
```python
# (1) placeholder URL 보정 (함정 1)
# (2) 누락 발행분 state→pt 백필 (300차)
# (3) last 동기화 (state.details[-1] == url일 때)
```

329차 신규 (4):
```python
# (4) 이번 차 발행분 state.details[-1] 직접 entry 추가 안전망 (idempotent URL 중복 체크)
# commit_publish()가 published_topics.json을 갱신하지 않을 때 (300차 패턴) +
# (2) 백필이 이미 처리한 entry도 idempotent로 한 번 더 안전.
# 누락 시 published_topics.last 동기화 단계가 stale URL을 가리킬 수 있으므로 cron이 직접 추가.
state_last_entry = state.get('details', [{}])[-1]
if state_last_entry.get('url') and state_last_entry.get('url').startswith('https://sigco.tistory.com/'):
    if state_last_entry.get('url') not in existing_urls:
        data.setdefault('details', []).append({
            'topic': state_last_entry.get('topic', '?'),
            'title': state_last_entry.get('title', ''),
            'hash': '',
            'url': state_last_entry.get('url'),
            'date': (state_last_entry.get('timestamp') or '')[:10] or '2026-07-28',
        })
        backfilled += 1
```

**329차 실전**: (4) 안전망이 1건 직접 추가 (`details_len=191→192`). cron이 commit_publish() 누락 + (2) 백필 단계 누락 모두 회피.

### 3. 328차 standalone publish wrapper 패턴 329차 재확인

두 파일 분리 패턴이 안정:
- `/tmp/build_post_NNN.py` — `requests.get(gn_url) + og:description regex` + body 생성 + `/tmp/post_NNN.html` write
- `/tmp/publish_NNN.py` — `from tistory_publisher import load_cookies, publish_post` 직접 호출 + stdout "PUBLISH=SUCCESS URL=..." 단일 메시지

```python
# /tmp/publish_329.py 핵심 5줄
import sys; from pathlib import Path
sys.path.insert(0, str(Path.home() / ".hermes" / "scripts"))
from tistory_publisher import load_cookies, publish_post
cookies = load_cookies()
url = publish_post(cookies, TITLE, content, tags=TAGS, visibility="public",
                   category=CATEGORY_ID, source_url=SOURCE_URL, gn_topic_id=GN_TOPIC_ID)
print(f"PUBLISH=SUCCESS URL={url}" if url and url.startswith("https://sigco.tistory.com/") else f"PUBLISH=FAIL result={url}")
```

**장점**: 
- cron이 grep하기 좋은 stdout (PUBLISH=SUCCESS 단일 메시지)
- 함정 20 (terminal inline python3 -c "..." 따옴표/이스케이프 섞이면 `command parser limit or malformed executable payload`로 terminal 거부) 회피
- 함정 11 (`execute_code` cron 차단 회피) — publish_post()는 `tistory_publisher.py`에 이미 있으므로 cron이 직접 호출 가능
- 격리 패턴 통일 (`unset PYTHONPATH PYTHONHOME; PYTHONNOUSERSITE=1; export PYTHONPATH=user-site; /usr/bin/python3 -s`)

### 4. 311차 fallback 패턴 정착 확인

**311차 fallback → 312~328차 AI/ML 정상 → 329차 AI/ML 정상 — 18차 연속 안정 유지.**

fallback은 진짜 일회성이 아니라 안정 운영 상태의 일부로 완전 정착. AI/ML 후보 소진이 주기적으로 반복되는 운영 패턴. cron은 fallback 또는 정상 중 어느 쪽이든 동일 시퀀스(§3-a → §3-b → §3-b.5 → §3.11 5단계 → §3.5 → §3.11 5-5)로 처리 가능.

## 함정 회피 5중 동시

- 함정 6 (heredoc + env -i SyntaxError) — heredoc 대신 `/tmp/build_post_329.py` 별도 파일
- 함정 11 (execute_code cron 차단 회피) — write_file + `/usr/bin/python3 -s` 실행
- 함정 14 (import os 누락) — proxy check heredoc 첫 줄에 `import os, requests, re` 모두 포함
- 함정 15 (5-5 proxy check 격리 패턴 적용) — `unset PYTHONPATH PYTHONHOME; PYTHONNOUSERSITE=1; export PYTHONPATH=user-site; /usr/bin/python3 -s`
- 함정 20 (inline python3 heredoc 회피) — `/tmp/publish_329.py` standalone wrapper 패턴

## drift 보고 (cron은 drift만 보고, 사용자 게이트 후 보정)

- by_category에 `"1219746": 1` 정수 ID 키 누적 (297차 함정 8 영구 누적 패턴, ID_TO_NAME 매핑 1회 보정 권장)
- 신규 차 진입 시 daily_counts[오늘]=0 drift는 자연 상태 (297차 정형화)

## 권장 후속 작업 (사용자 게이트 시)

1. **297차 함정 8 ID_TO_NAME 매핑 보정** — by_category의 `"1219746"` 키를 `"AI/ML"` 키에 합산 (사용자 승인 후 1회 실행)
2. **함정 17 임계점 재산정** — SKILL.md 본문 갱신 완료 (3000자 → 결합 복잡도 + 5000자 길이 가이드)

## 329차 발행 통계

- daily_counts[2026-07-28]={AI/ML:1}
- total=112
- by_category={AI/ML:801, iOS/Swift:18, 개발도구:148, 투자/경제:14, 기타:14, 아이디어:6, 개발 팁:14, 개발팁:2, "1219746":1}
- state.details_len=191 → 192 (5-2-A 안전망으로 1건 추가)
- published_topics.details_len=192
- 연속 all-green 104회차