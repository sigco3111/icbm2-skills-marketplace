# 223차 세션노트 (2026-07-09) — Kokoro TTS #936 발행 + stale fresh=true 3회째

## §3.34.21 — 223차 `blog_pipeline.py --category` stale fresh=true **3회째** 실전 확인 + cleanup 11회 연속 (⭐⭐)

**223차 cron 결과 요약**:
- §3.30.4 0단계 health check ✅ drift 0 (935=935=935 시작)
- feeds.feedburner.com RSS 50 entries → §3.34.11 5단계 dedup cron 직접: **42 fresh + 8 skip** (정확도 100%, skip 8건 모두 gn_topic_id/last_titles 매칭)
- `blog_pipeline.py --category 'AI/ML'` **stale fresh=true (#31218 Ternlight)** → §3.34.18.5 1회째 / §3.34.20 2회째 / **§3.34.21 3회째** 재확인 → cron 5단계 dedup이 정정
- 1순위 **#31239 Kokoro TTS** (RSS 50개 중 fresh 후보 1순위) 선택 → publish **#936** (3,270자, Picsum 2장, source footer 자동, gn_topic_id=31239 박기)
- §3.34.19 source footer 영구화 실전 검증 ✅ (--source-url/--gn-topic-id argparse 정상 발동)
- §3.34.13 gn_topic_id 박기 누적 **7건** (#930/#931/#932/#933/#935/#936)
- §3.33.1 §3.32.1 cleanup: 2,126 페이지 / 31239 매칭 4건 / PATCH 1/1
- §3.5 drift 0 (936=936=936 종료)
- **cleanup 213~223차 누적 11회 연속 all-green** (이전 9회 → 11회로 갱신)
- **5단계 dedup cron 직접 실행 6회째** (218~223차 누적)

### §3.34.21.1 — stale fresh=true 3회째 — cleanup cron 임무 #6 우선순위 상향 (⭐⭐⭐)

**이력 (3회 연속 동일 함정)**:

| 차수 | 헤더 | stale fresh=true 반환 | 정정 결과 | 영구화 단계 |
|---|---|---|---|---|
| 220차 | §3.34.18.5 | #31218 Ternlight | ✅ 5단계 dedup | "stale fresh=true" 1회째 기록 |
| 222차 | §3.34.20 | (다른 카테고리 시도, 동일 패턴) | ✅ 5단계 dedup | "stale fresh=true 2회째" |
| **223차** | **§3.34.21** | **#31218 Ternlight (재확인)** | ✅ **5단계 dedup** | **"stale fresh=true 3회째 — 임무 #6 최우선"** |

**영향**:
- `blog_pipeline.py --category`는 Notion DB의 `활성` 상태만 보고 details의 `gn_topic_id` 매칭 안 함 (둘이 분리된 진실 공급원) → 이미 발행한 긔를 fresh=true로 반환
- 3회 연속 동일 패턴 = **도구 자체의 구조적 결함** (일회성 버그 아님)
- cron이 매번 feeds.feedburner.com RSS + 5단계 dedup으로 정정 중이지만, **블로그파이프라인 단독 실행 시 중복 발행 위험**

**영구화 권장 (cleanup cron 임무 #6, 우선순위 상향)**:
1. **`blog_pipeline.py --category`에 5단계 dedup 통합** — Notion DB 활성 + details gn_topic_id + details title prefix 동시 매칭으로 `is_fresh` 판정 정정
2. **단독 실행 가드 추가** — `if not state.get('cron_managed_5stage'):` 시 `is_fresh=false` 강제 + cron_managed_5stage=True 플래그
3. **`scripts/5stage-dedup-cron.py` 신규** — 재사용 가능한 cron 전용 5단계 dedup (cleanup cron 임무 #5)
4. **`blog_pipeline.py` 자체에 `is_fresh` 정정 hook** — `state.details.gn_topic_id` 매칭 시 `is_fresh=false` 강제

### §3.34.21.2 — by_category 변형 키 4쌍 누적 (221차 발견 + 223차 재확인, ⭐)

223차 dump 재확인 (cleanup 후 11개 키):

```
'AI 뉴스': 1           ↔ 'AI/ML': 721       (정규화 안 됨)
'개발': 1              ↔ '개발도구': 134     (부분 문자열)
'개발팁': 12           ↔ '개발 팁': 1        (공백 변형)
'자동화&툴 리뷰': 0     ← alias_map 누락 (221차 발견, 223차 미해결)
```

**영구화**: `scripts/normalize_cat_key.py --merge` 1회 cleanup + alias_map에 `'자동화&툴 리뷰' (Tistory 1219748) → '개발도구'` 추가. drift 0 단일 세션 검증은 통과하지만 누적 카테고리별 카운트 정합성 깨짐. (cleanup cron 임무 #4)

### §3.34.21.3 — cleanup cron 임무 누적 7개 (v2.7.73 시점, 미해결)

| # | 임무 | 우선순위 | 의존성 |
|---|---|---|---|
| 1 | `scripts/retroactive-gn-topic-id.py` 1회 실행 | 중 | RSS + posts.json |
| 2 | `post-publish-correct.sh`에 gn_topic_id 박기 단계 | **최고** | publisher 4인자 |
| 3 | `~/.hermes/secrets/notion_blog_db_id.txt` 분리 | 낮음 | grep 패턴 |
| 4 | by_category 변형 키 cleanup (`normalize_cat_key.py --merge`) | 중 | alias_map 보강 |
| 5 | `scripts/5stage-dedup-cron.py` 신규 | **높음** | RSS + 5단계 |
| 6 | `blog_pipeline.py --category`에 5단계 dedup 통합 | **⭐ 상향** | details.gn_topic_id 매칭 |
| 7 | Notion 동일 URL 중복 페이지 archive | 중 | DB schema dump |

### §3.34.21.4 — 223차 작업 타임라인

1. §3.8.1 3-endpoint probe ✅ (Tistory max=935 시작)
2. §3.30.4 0단계 health check ✅ drift 0 (935=935=935)
3. `blog_pipeline.py --refresh-topics`: 12개 긱뉴스 토픽 추가 + 11개 기존 비활성화
4. feeds.feedburner.com RSS fetch (50 entries)
5. §3.34.11 5단계 dedup cron 직접: 50 후보 → **42 fresh + 8 skip**
   - SKIP 8건: #31227/#31225/#31224/#31221/#31218/#31216/#31209/#31201 (모두 GN_TOPIC_ID/LAST_TITLES 매칭)
6. `blog_pipeline.py --category 'AI/ML'` stale fresh=true (#31218 Ternlight) → 5단계 dedup으로 정정
7. 1순위 #31239 Kokoro TTS 선택 (RSS fresh 후보 중 1순위)
8. 긱뉴스 `.md` endpoint: 200 OK, ~10KB 본문
9. §3.23.1 frontmatter strip → 한국어 본문 heredoc 3,270자
10. **§3.34.1 `--file` + §3.34.19 `--source-url`/`--gn-topic-id`** 옵션 발행 → #936 (Picsum 2장, OG 썸네일)
11. §3.11 5단계 + §4 5-1 stats 보정:
    - Tistory API `category='AI 뉴스'` → `normalize_cat_key('AI 뉴스') = 'AI/ML'`
    - `by_category['AI/ML']: 720→721`
    - `daily_counts['2026-07-09']['AI/ML']: 0→1`
    - `total: 935→936`
12. **§3.34.13 details에 gn_topic_id=31239 박기** (누적 7건)
13. §3.34.3 `last_topics`: Tistory URL 항목 제거 (정리)
14. §3.33.1 §3.32.1 cleanup: 2,126 페이지 / 31239 매칭 4건 / PATCH 1/1 → 비활성화
15. §3.5 3중 신호 검증 ✅ drift 0 (936=936=936)

### §3.34.21.5 — 영구화 all-green (223차)

| 패턴 | 차수 | 223차 결과 |
|---|---|---|
| §3.8.1 3-endpoint probe | 196차 | ✅ 200 OK 3/3 |
| §3.30.4 0단계 state health check | 213차 | ✅ drift 0 (시작: 935=935=935) |
| §3.34.10 feeds.feedburner.com RSS | 218차 | ✅ 50 entries |
| **§3.34.11 5단계 dedup** | 218차 | ✅ 42 fresh + 8 skip (정확도 100%) |
| §3.29.4 긱뉴스 `.md` endpoint | 212차 | ✅ 200 OK (31239) |
| §3.23.1 frontmatter strip | 206차 | ✅ ~10KB → 3,270자 |
| §3.34.1 `tistory_publisher.py --file` 옵션 | 217차 | ✅ 3,270자 heredoc 파일 발행 성공 |
| **§3.34.19 source footer 영구화** (3회째 검증) | 221차 | ✅ --source-url/--gn-topic-id argparse + append_source_footer 정상 |
| §3.32.2 cat_key 정규화 | 215차 | ✅ `normalize_cat_key('AI 뉴스')` → 'AI/ML' |
| §3.11 5단계 + §4 5-1 stats 보정 | 200차 | ✅ `by_category['AI/ML']: 720→721` |
| §3.34.13 details에 gn_topic_id 박기 (7번째) | 218차 | ✅ #936에 gn_topic_id=31239 박기 |
| §3.34.3 last_topics 0개 정리 | 217차 | ✅ 0건 |
| §3.33.1 §3.32.1 cleanup (11회째) | 216차 | ✅ 2,126 페이지 / 31239 매칭 4건 / PATCH 1/1 |
| §3.33.3 Blog DB ID grep 동적 추출 (5회째) | 216차 | ✅ 정상 추출 |
| **§3.34.18.5 stale fresh=true 3회째** (223차 신규) | 223차 | ⚠️ #31218 Ternlight → cron 5단계 dedup 정정 |
| §3.5 3중 신호 검증 | 195차 | ✅ drift 0 (종료: 936=936=936) |

**누적 영구화 all-green 통과 차수**: 213~223차 **연속 11회** (drift 0 시작/종료 + cleanup + stats 보정 풀 사이클 안정화).

### §3.34.21.6 — 223차 핵심 교훈

1. **`blog_pipeline.py --category` stale fresh=true 3회째** (§3.34.21.1, ⭐⭐⭐): 220차 / 222차 / 223차 연속 동일 패턴 (Ternlight #31218을 fresh=true로 반환). **cleanup cron 임무 #6 우선순위 상향** — 단독 실행 시 중복 발행 위험, cron이 5단계 dedup으로 매번 정정 중이지만 도구 자체 보강 필요. 영구화: blog_pipeline.py 자체에 5단계 dedup 통합 + 단독 실행 가드 (`cron_managed_5stage` 플래그).

2. **§3.34.19 source footer 영구화 3회째 검증**: 221차 적용 / 222차 검증 / **223차 실전 발행 #936**. `--source-url`/`--gn-topic-id` argparse + `append_source_footer()` 멱등성 정상. 박기 누적 7건.

3. **cleanup 11회 연속 (213~223차) all-green**: 풀 사이클 안정화 단계 정착. §3.33.1 §3.32.1 cleanup이 silent fail 없이 정상 작동.

4. **5단계 dedup cron 직접 실행 6회째 (218~223차)**: blog_pipeline.py의 fresh 판정을 신뢰하지 않고 cron이 직접 RSS + 5단계 매칭 실행 패턴 정착. 정확도 100%.

5. **gn_topic_id 박기 누적 7건**: 218차 2건 / 219차 1건 / 220차 1건 / 221차 1건(retroactive) / 222차 1건 / **223차 1건**. retroactive 9건 잔여.

6. **`by_category` 변형 키 4쌍 누적**: alias_map 누락 `'자동화&툴 리뷰'` → `normalize_cat_key()`가 그대로 반환 → stats 가짜 키 누적. cleanup cron 임무 #4로 `normalize_cat_key.py --merge` 1회 실행 권장.

7. **223차 publish #936 정상 발행**: 1순위 #31239 "Kokoro로 로컬 CPU에서 고품질 TTS 실행하기 — 82M 파라미터, OpenAI 호환 인터페이스" (AI/ML). Tistory URL: `https://sigco.tistory.com/936`. 본문: 3,270자 (validate_content 3,270자). Picsum 이미지 2장 자동 삽입 + OG 썸네일 설정 + source footer 자동. §3.5 drift 0 (시작 935=935=935, 종료 936=936=936).

**세션 노트 끝.**