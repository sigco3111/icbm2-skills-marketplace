# 187차 세션 노트 (2026-06-29) — endpoint 단수형/복수형 함정

## 한줄 요약
Tistory 발행 API 호출 시 endpoint 경로를 단수형 `/manage/post.json`으로 사용해야 한다. 복수형 `/manage/posts.json`은 GET 전용이라 POST 시 405 + HTML 에러 페이지를 반환한다.

## 시간순 로그

### 21:00 — cron 트리거, blog_pipeline.py 실행
- `python3 ~/.hermes/scripts/blog_pipeline.py` → selected_topic = "Tokenmaxxing은 죽었다, Tokenmaxxing 만세"
- source_url = `https://news.hada.io/topic?id=30931`
- category = AI/ML (1219746)
- 가짜/중복 아님 → 발행 진행 결정

### 21:01 — 세션 체크
- `python3 ~/.hermes/scripts/tistory_publisher.py --check-session` → `✅ 세션 유효 (총 734개 글)`
- 다음 글 = 735번 → #872 예상 (정확히는 #872, 184~186차 사이 발행분 누적)

### 21:02 — 원문 fetch
- `curl https://news.hada.io/topic?id=30931` → 12gramsofcarbon.com 원문 본문 추출 성공
- 주요 내용: tokenmaxxing의 진화, 누적 정확성 흐름, 보안 분야 100M 토큰 예산, 오픈 모델 GLM 5.2 vs Opus 가격 비교, 소프트웨어 팩토리 전망

### 21:04 — 본문 작성 (3,385자)
- H2 7개: 도입 / 첫 변곡점 / 보안 / 오픈 모델 / 두 형태 / 전망 / 요약
- Picsum 이미지 2장 삽입 (tokens-burn, openmodel-loop)
- 가격 비교표 1개 (GLM 5.2 vs Opus 4.X vs Haiku 4.5)
- 태그 8개

### 21:05 — 첫 POST 시도 (실패)
- endpoint: `https://sigco.tistory.com/manage/posts.json` (복수형)
- HTTP status: 400 (params로 보냄)
- 응답: "Your browser sent an invalid request"
- 원인: `params=` 사용 → Tistory는 JSON body 기대

### 21:06 — 두 번째 POST 시도 (실패)
- endpoint: `https://sigco.tistory.com/manage/posts.json` (복수형)
- multipart/form-data로 변경
- HTTP status: 405
- Content-Type: text/html;charset=UTF-8
- 응답: "권한이 없거나 존재하지 않는 페이지입니다" HTML
- **첫 번째 endpoint 단수형/복수형 함정 발견**

### 21:07 — 세 번째 POST 시도 (성공)
- endpoint: `https://sigco.tistory.com/manage/post.json` (단수형) ⭐
- JSON body, Content-Type: application/json
- HTTP status: 200
- Content-Type: application/json;charset=UTF-8
- 응답: `{"entryUrl":"https://sigco.tistory.com/872"}`

### 21:08 — record (§3.12 우회 패턴)
- `blog_pipeline.py --record "주제" "제목" "URL"` 3-arg
- `echo "https://news.hada.io/topic?id=30931" >> published_urls.txt`
- `echo "https://sigco.tistory.com/872" >> published_urls.txt`

### 21:09 — last.url 보정 (§3.11 잔재)
- `details[-1].url`은 정상 (`https://sigco.tistory.com/872`)
- `last.url`은 MISSING → Python one-liner로 보정

## 핵심 발견 — endpoint 매핑

| 경로 | 메서드 | 용도 | 187차 시도 결과 |
|---|---|---|---|
| `/manage/post.json` | POST | **글 작성/발행/수정** | ✅ HTTP 200, `{"entryUrl":"https://sigco.tistory.com/872"}` |
| `/manage/posts.json` | GET | 글 목록 조회 | (POST 시) ❌ HTTP 405, HTML 에러 |
| `/manage/post/attach.json` | POST | 이미지/첨부 업로드 | (정상) |
| `/manage/category.json` | GET | 카테고리 목록 | (정상) |

## 함정 구분표 (HTTP status → 어떤 §?)

| HTTP | Content-Type | 응답 내용 | 통계 영향 | 진단 |
|---|---|---|---|---|
| **200** | application/json | `{"entryUrl":"..."}` | +1 | ✅ 정상 |
| **200** | application/json | `{"entryUrl":"..."}` but `details[-1].url=""` | +1 | §3.11 record URL 빈값 (사후 보정 4단계) |
| **200** | text/html | Tistory 메인 페이지 | 0 | §3.8 세션 만료 (쿠키 갱신 필요) |
| **400** | text/html | "Your browser sent an invalid request" | 0 | request 형식 오류 (params→json, multipart 등) |
| **405** | text/html | "권한이 없거나 존재하지 않는 페이지" | 0 | **§3.13 endpoint 오류 (단수형 교정)** |
| **302** | text/html | 로그인 페이지로 리다이렉트 | 0 | 인증 실패 (쿠키 도메인 매칭 오류 가능) |

## 검증 코드 (§3.13 진단 oneliner)

```python
import os, requests
cookies = {k.replace('TISTORY_', ''): os.environ[k] for k in os.environ if k.startswith('TISTORY_')}
headers = {'User-Agent': 'Mozilla/5.0', 'Referer': 'https://sigco.tistory.com/manage/post'}

for url in [
    'https://sigco.tistory.com/manage/post.json',   # 단수형
    'https://sigco.tistory.com/manage/posts.json',  # 복수형
]:
    r = requests.post(url, json={'id':'0'}, cookies=cookies, headers=headers, timeout=10)
    print(f'{url}: HTTP {r.status_code} {r.headers.get("content-type","")[:30]}')

# 예상 출력:
# post.json: HTTP 200 application/json
# posts.json: HTTP 405 text/html
```

## 발행 성공 확인

```
HTTP status: 200
Content-Type: application/json;charset=UTF-8
Response: {"entryUrl":"https://sigco.tistory.com/872"}
```

- 새 글 번호: **#872** (이전 734 → 735번 예상이 184~186차 사이 누적으로 어긋남, 정상)
- sigco.tistory.com URL 개수 (published_urls.txt): 324
- 전체 통계: 843 → 844 (AI/ML: 659 → 660)
- 오늘 AI/ML 7건 중 5건째 (할당량 무제한)

## 다음 세션을 위한 권장

1. **endpoint 직접 호출 시 단수형 사용** — `POST /manage/post.json`
2. **권장: `publish_post()` 함수 import** — `tistory_publisher.py`의 검증된 함수 사용
3. **405 응답 시 §3.13 1차 확인** — endpoint 경로부터 점검
4. **func() 미사용 시 endpoint 매핑 표** — `references/session-20260629-187th-endpoint-405.md` 참조

## TODO (근본 해결, 미수정)

- `tistory_publisher.py`의 `POST_ENDPOINT` 상수 export → 다른 스크립트에서 import 가능
- 또는 `publish_post()` 함수를 wrapper로 만들어 endpoint 의존성 캡슐화
- 현재 상태: cron + ad-hoc 호출자가 endpoint 경로를 알거나 함수를 직접 import해야 안전
