# 242차 세션 — §3.5 5중 검증 정식화 + CLI 인수 함정 확정

**날짜**: 2026-07-11 (Saturday)
**발행**: `#959 OpenAI GPT 5.6 출시` (https://sigco.tistory.com/959)
**세션 만료 가드 (§3.8.1)**: ✅ 통과 (status=200, content-type=application/json)
**격리 패턴 (§3.8.2)**: ✅ 적용 (`env -i` + system python3)
**사전 drift 감지**: ✅ 5중 신호 일치 (state.last_published_url + state.last.url + state.details[-1].url + pt.last.url + pt.details[-1].url 모두 `#958`)
**발행 후 sync**: ✅ `post_publish_sync.py sync ...` → `triple_signal_match: true` 보고

## §3.5 신호 5중 검증 정식화 배경

241차까지 SKILL.md 본문에는 "3중 신호"라고 표기되어 있었으나, 실제로 매 세션 heredoc 보정 코드와 cron 가드 코드를 보면 5개 URL을 비교하고 있었음:

1. `state['last_published_url']`
2. `state['last']['url']`
3. `state['details'][-1]['url']`
4. `pt['last']['url']`
5. `pt['details'][-1]['url']`

242차 검증 결과 5개 모두 `https://sigco.tistory.com/958` 일치 → publish 진행 → publish 후 모두 `#959` 로 갱신 확인. SKILL.md 본문을 **3중 → 5중** 으로 갱신.

## `post_publish_sync.py` CLI 인수 형태 확정

241차 SKILL.md 본문에 적힌 CLI 예제는 단순 `--url ...` 플래그였으나, 실제 스크립트는 `sync` / `sync-from-pt` **서브커맨드** 방식. 242차에서 단순 `--url` 단독 호출시 다음과 같이 실패:

```
usage: post_publish_sync.py [-h] {sync,sync-from-pt} ...
post_publish_sync.py: error: argument cmd: invalid choice: 'https://sigco.tistory.com/959'
```

정확한 형태:

```bash
env -i HOME=/Users/mac PATH=/usr/bin:/bin /usr/bin/python3 \
  ~/.hermes/skills/automation/tistory-publisher/scripts/post_publish_sync.py sync \
  --url 'https://sigco.tistory.com/959' \
  --title '...' \
  --gn-topic-id 31275 \
  --category 'AI/ML' \
  --category-id 1219746 \
  --source-url 'https://news.hada.io/topic?id=31275'
```

`--category-id` 는 선택이지만 명시 권장 (cleanup cron 임무 #16 cat_id 누설 방지).

## `tistory_publisher.py` CLI 인수 함정

241차까지 사용한 옵션:
- `--topic-url <URL>` (가짜)
- `--auto-record` (가짜)

242차 호출시 두 옵션 모두 `unrecognized arguments` 에러. 실제 옵션은:
- `--source-url <URL>` (긱뉴스 원본 URL, footer 박기용)
- `--gn-topic-id <N>` (긱뉴스 N번, sync 단계 전파)

또한 `--record-topic TOPIC TITLE [URL [TOPIC_URL]]` 형태로 publish 후 자동 record도 가능 (positional 4개 인자). cron에서는 명시 호출이 표준.

## 발행 성공 후 5중 신호 검증 결과

```
=== §3.5 5중 신호 최종 ===
state.last_published_url = https://sigco.tistory.com/959
state.last.url            = https://sigco.tistory.com/959
state.details[-1].url    = https://sigco.tistory.com/959
pt.last.url               = https://sigco.tistory.com/959
pt.details[-1].url        = https://sigco.tistory.com/959

✅ 5중 신호 완전 일치

daily_counts[2026-07-11] = {'AI/ML': 1}
```

## 발견/수정 사항 요약

1. §3.5 신호 3중 → **5중** 정식화
2. `post_publish_sync.py` CLI에 **`sync` 서브커맨드 + `--category-id` 선택** 반영
3. `tistory_publisher.py` CLI에 `--topic-url` / `--auto-record` **가짜 옵션 함정** 경고 추가
4. `pt` 직접 json 로드시 dict일 수도 / set일 수도 있음 주의 (`blog_pipeline.load_published_topics()`는 set 반환, 직접 json.load 하면 dict)

## cleanup cron 임무 상태 (242차)

- **#16**: 29회 연속 all-green (213~242차, 이번 세션 cat_id 누설 없음)
- **#17**: `post_publish_sync.py` 정상 동작 확인
- **#15**: 알림만, 이번 세션 drift 없음
- **#1**: 영구화 미완료, 갱신 불필요 (이번 세션은 신규 발행)
- **#12**: claim 거짓 상태 유지