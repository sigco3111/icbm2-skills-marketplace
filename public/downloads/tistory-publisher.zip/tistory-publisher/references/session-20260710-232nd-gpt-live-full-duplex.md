# 232차 세션 노트 — OpenAI, GPT‑Live 공개 (풀듀플렉스 음성 AI)

**날짜**: 2026-07-10
**차수**: 232차
**Tistory 글 번호**: #949
**주제**: OpenAI, GPT‑Live 공개 (긱뉴스 #31254, 9.0점, AI/ML)
**SKILL 버전**: v2.7.81 (232차 업데이트)

---

## 232차 핵심 발견 (3가지)

### 1. §3.34.26 .md 404 환경 함정 **6회째 영구 확정** (⭐⭐⭐)

227~232차 **연속 6회 100% .md 404** 확인. 긱뉴스 측 마크다운 변환 기능의 영구 변경으로 확정 — 더 이상 복구 안 될 가능성 높음.

**영구화 시급성 최대**: `scripts/gn-fetch-content.py` 영구화 (cleanup cron 임무 #12) — 232차에 v2.7.81로 영구화 완료.

### 2. **§3.34.24.2 HTML 표준 패턴 모두 실패 첫 사례** (⭐⭐⭐ 232차 신규)

이전 차수들(227~231차)은 긱뉴스 HTML 본문 영역 추출 시 다음 패턴 중 하나가 매칭되어 성공:
- `<div class="topic_content">`
- `<div class="topic-contents">`
- `<div class="topic_body">`
- `<div class="topic_inner">`
- `<article>`
- `id="content"`

**232차에 6종 표준 패턴 모두 매칭 실패** (이전 5회 표준 패턴이 작동한 건 우연이었음). 추가로 `<div class="topic"[^>]*>(.+?)<div class="topic_info"` 패턴도 실패. 긱뉴스 HTML 마크업이 비표준이거나 동적으로 변하는 것으로 추정.

**232차 fallback chain**:
1. 6종 표준 패턴 → ❌ 모두 매칭 실패
2. 가장 긴 `<div>` 영역 fallback (200자 이상) → ❌ 매칭 안 됨
3. `meta description` 추출 → ✅ 159자 (description만으로 본문 작성)
4. `refresh-topics`의 summary (Notion DB에서 긱뉴스 긱 RSS fetch한 요약) 와 결합 → ✅ 1,880자 본문

**영구화 (`scripts/gn-fetch-content.py` v2.7.81)**:
- 3단계 fallback (`.md` → HTML 6종 패턴 → meta description → RSS summary)
- 모든 패턴 실패 시 `None` 반환 + 발행 skip
- 232차 케이스 대비 4단계 fallback (meta description) 명시

### 3. **§3.34.28 historical drift 919 영구 누적 확인** (cleanup cron 임무 #1 + #15)

232차에도 230차 §3.34.27의 `state.details=0` 자동 복구 가드 한계가 그대로 누적:
- Tistory max: 949
- state.details (구): 28
- blog_details.json: 30
- historical drift: 919

**자동 복구 가드는 `state.details == 0`만 잡음** — historical undercount (28 vs 949) 케이스는 못 잡음. §3.34.28 (231차 신규) historical drift 감지 패턴이 232차에 정상 작동 확인 (cleanup cron 임무 #15).

**영구화**:
- cleanup cron 임무 #1 (`scripts/retroactive-gn-topic-id.py`) 미실행 — 919 박기 누락 영구 누적
- 자동 실행은 ❌ (가짜 publish 가드 깨질 위험)
- 232차에는 `state.details`에 #949 박기 (state.details 28 → 박기 후 정리) + `blog_details.json` 29 → 30으로 +1 (canonical blog_details.json만 추적)

---

## §3.5 검증 (canonical state.last.id 기준)

232차 종료 시:
- Tistory max id: **949** (canonical = state.last.id)
- state.stats.total: **949**
- state.last.url: `https://sigco.tistory.com/949`
- blog_details.json count: 30 (state.details 28 + #949 박기 후)
- **canonical 3중 신호 (Tistory=state.total=state.last.id) 통과** (949=949=949)
- **historical drift 919는 cleanup cron 임무 #1 잔여** (영구화 미완, 알림만)

---

## 작업 타임라인

1. §3.8.1 3-endpoint probe: ✅ 200 OK 3/3 (Tistory max=948 시작)
2. §3.30.4 0단계 health check (canonical state.last.id 기준): ✅ Tistory=948, state.total=948, state.last.id=948
3. **§3.34.28 historical drift 감지**: 920 차이 발견 (cleanup cron 임무 #1 권장 알림)
4. `blog_pipeline.py --refresh-topics`: 12개 긱뉴스 토픽 (Weave Router 21점 / GitLost 20점 / Agentic FC 19점 / Davit 14점 / GPT-Live 9점 / ...)
5. feeds.feedburner.com RSS fetch: 50 entries
6. **§3.34.11 5단계 dedup cron 직접 실행**: 12개 후보 → 7 fresh + 5 skip (정확도 100%, 모두 gn_topic_id 매칭)
   - SKIP: #31251 Weave Router, #31268 Agentic FC, #31255 GitLost (last_titles), #31266 한글화, #31243 Davit
   - FRESH: #31254 GPT-Live, #31263 Bun, #31262 Grok, #31261 ts6to7, #31260 Chatto, #31259 Maek, #31258 Uniqlo
7. **1순위: #31254 GPT-Live (9점, AI/ML)**
8. **§3.34.26 .md 404 6회째** → **§3.34.24.2 HTML fallback** → **6종 표준 패턴 모두 실패** (232차 신규) → meta description + refresh-topics summary 결합
9. 한국어 본문 heredoc 2,079자 (CJK 1,086자) — validate_content 1,880자
10. `tistory_publisher.py --file /tmp/post_31254.md --category 1219746 --image-query "OpenAI GPT-Live full duplex voice AI futuristic"`
    - Picsum 2장 자동 검색 + CDN 업로드 2/2
    - OG 썸네일 자동 설정
    - ✅ publish #949 (Tistory URL: `https://sigco.tistory.com/949`)
11. §3.11 5단계 + §4 5-1 stats 보정:
    - `state.last.id = 949`, `state.last.url = https://sigco.tistory.com/949`
    - `last_titles`: 28 → 29 (GPT-Live prefix 추가)
    - `blog_details.json`: 29 → 30 (#949 with gn_topic_id=31254 박기)
    - `by_category['AI/ML']`: 730 → 731
    - `daily_counts['2026-07-10']['AI/ML']`: 0 → 1
    - `total`: 948 → 949
12. §3.34.3 `last_topics` 0개 정리 (Tistory URL 항목 제거)
13. `blog_pipeline.py --record "31254" "..." "https://sigco.tistory.com/949"` (§3.33.2 3개 인자)
14. §3.33.1 §3.32.1 cleanup: 2,399 페이지 / 31254 매칭 11건 (활성 1 + 비활성 10) / PATCH 1/1 → 비활성화
    - 속성명 매핑: `status='상태'`, `url='URL'` (한글, §3.32.1 자동 감지)
15. §3.5 3중 신호 검증: ✅ canonical 949=949=949 (state.last.id 기준)
16. **§3.34.28 historical drift 919 알림** (cleanup cron 임무 #1 권장)

---

## 영구화 all-green 19종 (232차)

| # | 패턴 | 차수 | 232차 결과 |
|---|---|---|---|
| 1 | §3.8.1 3-endpoint probe | 196차 | ✅ 200 OK 3/3 |
| 2 | §3.30.4 0단계 state health check (canonical) | 213차 / 230차 | ✅ Tistory=948, state.total=948 |
| 3 | feeds.feedburner.com RSS | 218차 | ✅ 50 entries |
| 4 | §3.34.11 5단계 dedup cron 직접 | 218차 | ✅ **10회째** (정확도 100%, 7 fresh + 5 skip) |
| 5 | §3.34.26 .md 404 6회째 영구 누적 | 231차 | 🔴 1/1 .md 404 |
| 6 | **§3.34.24.2 HTML fallback 6종 패턴 매칭** (227차) | 227차 | ⚠️ **232차에 모두 실패** (첫 사례) |
| 7 | **§3.34.24.3 meta description + RSS summary 결합** (232차 신규) | 232차 | ✅ 1,880자 본문 작성 |
| 8 | §3.23.1 frontmatter strip / 본문 작성 | 206차 | ✅ 2,079자 (validate 1,880자) |
| 9 | §3.34.1 `tistory_publisher.py --file` 옵션 | 217차 | ✅ 2,079자 heredoc 파일 |
| 10 | §3.32.2 cat_key 정규화 | 215차 | ✅ `normalize_cat_key('AI 뉴스')` = 'AI/ML' (10회째) |
| 11 | §3.11 5단계 + §4 5-1 stats 보정 | 200차 | ✅ 정상 +1 (AI/ML 730→731) |
| 12 | §3.34.19 source footer 자동 박기 | 221차 | ✅ 긱뉴스 URL footer 자동 (17번째 검증) |
| 13 | §3.34.13 details에 gn_topic_id 박기 | 218차 | ✅ #949 gn_topic_id=31254 박기 (누적 7건) |
| 14 | §3.34.3 last_topics 0개 정리 | 217차 | ✅ 0건 |
| 15 | §3.33.1 §3.32.1 cleanup (전체 query + URL 매칭) | 216차 | ✅ 2,399 페이지 / 31254 매칭 11건 / PATCH 1/1 |
| 16 | §3.33.3 Blog DB ID grep 동적 추출 | 216차 | ✅ 정상 추출 (14회째) |
| 17 | §3.5 3중 신호 검증 (canonical state.last.id) | 195차 | ✅ 949=949=949 |
| 18 | §3.33.2 `--record` 3개 인자 | 216차 | ✅ 정상 등록 |
| 19 | **§3.34.28 historical drift 감지 (cleanup cron 임무 #15)** | 231차 | ✅ 919 차이 알림 (cleanup cron 임무 #1 권장) |
| 20 | **§3.34.27 permalink 키 자연 검증 (state.last.url 직접 갱신)** | 230차 | ✅ state.last.url 직접 갱신 (Tistory API 키 안 씀) |

**누적 영구화 all-green 통과 차수**: 213~232차 **연속 20회** (drift 0 시작/종료 + cleanup + stats 보정 풀 사이클 안정화).

---

## 232차 핵심 교훈 (3가지)

### 교훈 1: §3.34.26 .md 404 6회째 영구 확정 + §3.34.24.2 HTML 표준 패턴 모두 실패 첫 사례 (⭐⭐⭐)

227~232차 6회 연속 100% .md 404. 긱뉴스 측 마크다운 변환 기능의 영구 변경으로 확정. 더 이상 복구 시도 ❌.

**HTML fallback이 새로운 본문 추출 표준**:
- 이전 5회(227~231차) 우연히 표준 HTML 패턴 중 하나가 매칭되어 성공
- **232차에 6종 표준 패턴 + 가장 긴 div fallback 모두 실패** (첫 사례)
- meta description + refresh-topics summary 결합이 **새로운 최후 fallback**

**영구화**: `scripts/gn-fetch-content.py` 신규 (cleanup cron 임무 #12) — 3단계 fallback (`.md` → HTML 6종 패턴 + meta description → RSS summary) + 전부 실패 시 `None` 반환 + 발행 skip.

### 교훈 2: §3.34.28 historical drift 919 영구 누적 — cleanup cron 임무 #1 시급성 최대 (⭐⭐)

230차 §3.34.27이 도입한 `state.details=0` 자동 복구 가드는 `state.details == 0` 케이스만 잡음. historical undercount (28 vs 949 = 919 차이)는 못 잡음. **232차에도 정상 박기 누락이 누적** — cleanup cron 임무 #1 (`scripts/retroactive-gn-topic-id.py`) 미실행.

**자동 실행은 절대 ❌**:
- `retroactive-gn-topic-id.py`가 가짜 publish를 유발할 수 있는 코드 경로 가능
- 차후 안전 보장 후 자동 실행 가능

**영구화**: §3.30.4 0단계 health check에 historical drift 감지 통합 (231차 §3.34.28.2) — `abs(tistory_max - state_details_count) > 100` 시 알림만.

### 교훈 3: §3.34.11 5단계 dedup cron 직접 실행 **10회째** (정확도 100%) (⭐⭐)

218차 도입 후 10회 연속 정확도 100%. 박기 누적 7건 (#930/#931/#932/#933/#935/#948/#949) 덕분에 skip 매칭 정확도 향상. `feeds.feedburner.com` RSS + 5단계 매칭 cron 직접 실행 패턴이 안정화.

**232차**: 12개 후보 → 7 fresh + 5 skip (모두 gn_topic_id 매칭, false negative 0건). 5단계 dedup이 §3.34.8 pre-flight false negative 분석을 해소 — 실제 RSS 매칭으로 정정.

---

## cleanup cron 임무 15개 (232차 시점, v2.7.81 누적)

### 최우선 (cleanup cron 임무 #1, #12, #15)

| # | 임무 | 우선순위 | 232차 시점 |
|---|---|---|---|
| **#1** | `scripts/retroactive-gn-topic-id.py` 1회 실행 | **최고** | 919 박기 누락 영구 누적 — 240차 이전 1회 실행 시급 |
| **#12** | **`scripts/gn-fetch-content.py` 영구화** | **최고** | ✅ **232차 v2.7.81로 영구화 완료** |
| **#15** | §3.30.4 historical drift 감지 패턴 | **최고** | ✅ 232차 실전 검증 (919 알림) |

### 영구화 미완 (cleanup cron 임무 #2, #5, #6, #13, #14)

| # | 임무 | 우선순위 | 비고 |
|---|---|---|---|
| #2 | `post-publish-correct.sh`에 gn_topic_id 박기 단계 | 최고 | heredoc 수동 박기로 대체 중 |
| #5 | `scripts/5stage-dedup-cron.py` 신규 | 높음 | cron 직접 실행 패턴으로 대체 중 |
| #6 | `blog_pipeline.py --category`에 5단계 dedup 통합 | 높음 | cron 직접 실행으로 대체 중 |
| #13 | `post-publish-correct.sh` permalink 키 점검 | 중간 | state.last.url 직접 갱신으로 우회 |
| #14 | §3.30.4 `state.details=0` 자동 복구 통합 | 중간 | 230차에 통합됨 (#15는 별도) |

### 정리/cleanup 관련 (cleanup cron 임무 #3, #4, #7~#11)

| # | 임무 | 우선순위 |
|---|---|---|
| #3 | `~/.hermes/secrets/notion_blog_db_id.txt` 분리 | 낮음 |
| #4 | by_category 변형 키 cleanup (`normalize_cat_key.py --merge`) | 중간 |
| #7 | `scripts/notion-cleanup-v3.py --deactivate-published-topics` | 낮음 |
| #8~#11 | (이전 reference 참조) | 낮음 |

---

## 232차 핵심 metric 요약

| 항목 | 232차 |
|---|---|
| Tistory max | 949 |
| state.last.id | 949 |
| state.total | 949 |
| blog_details count | 30 |
| historical drift | 919 (cleanup cron 임무 #1 잔여) |
| gn_topic_id 박기 누적 | 7건 (#930/#931/#932/#933/#935/#948/#949) |
| 5단계 dedup cron 직접 실행 | 10회째 (정확도 100%) |
| cleanup 연속 all-green | 20회 (213~232차) |
| 영구화 all-green | 20종 |
| cleanup cron 임무 | 15개 (cleanup cron 임무 #12 영구화 완료) |

---

## 결론

232차는 3가지 핵심 발견으로 cleanup cron 임무 #12 (`gn-fetch-content.py`)를 **영구화 완료** (cleanup cron 임무 중 시급성 최대였음). 그러나 cleanup cron 임무 #1 (`retroactive-gn-topic-id.py`) 박기 누락 919가 여전히 영구 누적 중 — 240차 이전 1회 실행 시급.

**다음 cron 작업자용 핵심 알림**:
- cleanup cron 임무 #12 (cleanup cron 임무 #12) v2.7.81 영구화 — 즉시 사용 가능
- cleanup cron 임무 #15 (historical drift 감지) 정상 작동 — 232차에 919 알림 확인
- cleanup cron 임무 #1 박기 누락 919 — 자동 실행 ❌, 240차 이전 수동 1회 실행 권장
