# 342차 — 송재경 Open MMO (gn=31940, #1140)

**2026-07-30 02:01** — `#1140` ("송재경, AI와 게임 — Open MMO로 돌아온 전설적 개발자가 그리는 다음 판의 그림", gn=31940, AI/ML, 본문 2,795자, Picsum 2장, 태그 8개). 305차 단일 패스 37연속 + parts.append() 정형 37연속 + §3.5 신호 4 disambiguate 36연속 + 진입 5-5 17연속 + fallback 복귀 29연속. **정형 정상 차** — 340차/341차와 동일 패턴, 새 함정/관찰 없음.

## 워크플로우 실행

1. **§3.8.1 가드 (VALID)**: raw 검증 status=200 + content_type=application/json + first_id=1139 ✅
2. **§3-a topic 선정**: run_pipeline `--category 'AI/ML'` → status=ready + gn=31940 "송재경, AI와 게임" (긱뉴스 카테고리: AI/ML)
3. **긱뉴스 본문 검증**: urllib + og:description regex → "AI 특이점은 이미 진입했다. 우리가 모르고 있을 뿐" '바람의나라', '리니지', '아키에이지'를 만든 송재경이 오픈소스 MMORPG 프로젝트 Open MMO를 공개하고 AI 시대의 개발 경험과 전망을 공유함. Open MMO는 인간 플레이어와 AI 에이전트가 동일한 프로토콜로 접… (정상 추출)
4. **§3-b 본문 빌드**: `build_post_342.py` 단일 패스 — parts.append() 정형 (335차 + 336차 + 340차 + 341차 동일) + Picsum 2장 + 본문 마지막에 source URL 명시 라인 (`<p>원문 보기: <a href="https://news.hada.io/topic?id=31940">긱뉴스 — 송재경, AI와 게임</a></p>`)
5. **§3-b publish**: tistory_publisher.py `--content` 단일 폴백 (324차 4회차 검증)
   - title: "송재경, AI와 게임 — Open MMO로 돌아온 전설적 개발자가 그리는 다음 판의 그림"
   - tags: "송재경,OpenMMO,MMORPG,AI에이전트,오픈소스,게임개발,바람의나라,리니지" (8개)
   - category: 1219746 (int)
   - source-url: https://news.hada.io/topic?id=31940
   - gn-topic-id: 31940
   - 응답: `🔗 https://sigco.tistory.com/1140` (Content 검증 통과: 2382자)
   - OG 썸네일 자동: `https://blog.kakaocdn.net/dna/lT6wq/dJMcacjEK3E/AAAAAAAAAAAA...`
6. **§3.11 5-2 commit**: blog_pipeline `--commit` 정상 (total=134, today={AI/ML:3}, by_category["1219746"]=1 영구 잔존 38연속)
7. **§3.11 5-3 state.json**: last_published_url=#1140, last_published_id=1140, details append, KST 타임존 (317차 정형)
8. **§3.11 5-2-A published_topics.json**: 누락 백필 1건 (state.json엔 #1140, published_topics.json엔 누락 → 300차 + 337차 + 342차 정형 정상), last 동기화 정상
9. **§3.5 3중 신호**: 신호 4 발동 (구조적 오탐 — 5-3 last+details 동기화 시 무조건 발동, 36연속 정형)
10. **§3.11 5-5 proxy check**: status=200 + og:title="송재경, AI와 게임 — Open MMO로 돌아온 전설적 개발자가 그리는 다음 판의 그림" 정확 매칭 + source_present=True + cjk_suspicious=0 → 진짜 발행 확인

## 🔍 정형 검증 사례

- **2795자 케이스 + parts.append() 정형**: 318차 정형("3000자 미만 = 단일 f-string OK") 기준 아래지만 안전 우선으로 parts.append() 사용. 335차/#1129 (2730자) + 338차/#1135 (3103자) + 340차/#1138 (3666자) + 341차/#1139 (3665자) 사이의 중간 케이스 추가. parts.append() 정형이 본문 길이와 무관하게 안정 작동 검증.
- **본문 내 source URL 명시 라인**: publish_post()가 source_url 인자를 받아 footer 자동 박기하지만, 본문 마지막에 별도 `<p>원문 보기: <a href="...">긱뉴스 — 제목</a></p>` 라인 직접 추가. 5-5 proxy check의 source_present=True는 본문 직접 박힌 URL로 확인 (footer와 별개). 335차 함정 27 (빌드 시점 ≠ publish 후) 정상 작동.
- **OG title 매칭 일치**: publish_post()가 `&mdash;` HTML entity를 og:title에는 일반 `—` (em-dash) 그대로 유지. og:title="송재경, AI와 게임 — Open MMO로 돌아온 전설적 개발자가 그리는 다음 판의 그림" = 빌드 title 동일.

## 📊 stats

- **total**: 134
- **today (2026-07-30)**: {AI/ML: 3}
- **by_category**: {AI/ML: 821, iOS/Swift: 18, 개발도구: 150, 투자/경제: 14, 기타: 14, 아이디어: 6, 개발 팁: 14, 개발팁: 2, "1219746": 1} (정수 ID 영구 잔존 38연속, 297→342)
- **details_len**: 213 (state.json), 214 (published_topics.json)
- **last_published_url**: https://sigco.tistory.com/1140
- **last_topics[-1]**: {topic: '31940', category: 'AI/ML', title: '송재경, AI와 게임 — Open MMO로 돌아온 전설적 개발자가 그리는 다음 판의 그림', url: 'https://sigco.tistory.com/1140', timestamp: '2026-07-30T02:02'}

## 🎯 누적 카운터

- **연속 all-green**: 116회차 (288차 ~ 342차)
- **단일 패스 305차 패턴**: 37연속 (306→342)
- **parts.append() 정형**: 37연속 (306→342)
- **§3.5 신호 4 disambiguate**: 36연속 (298→342)
- **진입 5-5**: 17연속 (310→342)
- **fallback 복귀**: 29연속 (311→342)
- **`--content` 단일 폴백**: 5회차 검증 (324→339→340→341→342)
- **`by_category["1219746"]=1` 영구 잔존**: 38연속 (297→342)
- **5-2-A 누락 백필**: 매 차 1건 정형 (300→342 정형)

## 📝 결론

**정형 정상 차** — 340차/341차 정형화 (parts.append() + `--content` 단일 폴백 + §3.5 구조적 오탐 disambiguate + 5-2-A 백필) 그대로 재현, **새 함정/관찰 없음**. 2795자 케이스도 parts.append() 정형이 안정 작동 (318차 "3000자 미만 = 단일 f-string OK" 정형 확장 점검 통과). 116회차 all-green 연속. 다음 차(343차)도 동일 정형으로 진행 가능.
