# 349차 (2026-08-01 04:00) — DeepSeek V4 Flash 0731 MoE 효율 분석

## 발행
- **#1165** — "DeepSeek V4 Flash 0731의 지능·성능·가격 분석 — MoE 효율의 새 기준점"
- gn=32020, AI/ML, 본문 2465자 + Picsum 2장 + Python 코드 블록 1개
- OG 썸네일 `https://blog.kakaocdn.net/dna/R4WRC/dJMcajb0lZO/AAAAAAAAAAAA...`

## 연속 all-green 123회차
- 단일 패스 44연속 + parts.append() 정형 44연속
- §3.5 신호 4 disambiguate 43연속 (298→349)
- 진입 5-5 24연속 + fallback 복귀 36연속
- 324차 `--content` 단일 폴백 정형 **12회차 검증** (324→344→345→346→347→348→349)

## 정형 정상 차
- 348차 정형화 그대로 재현, 새 함정/관찰 0건
- 305차 단일 패스 패턴 (build_post 안 og:description 임베드) 349차 정상 작동
- 328차 standalone publish wrapper (`/tmp/publish_349.py`에서 publish_post() 직접 호출)
- 332차 parts.append() double-quote 정형 + 336차 code_lines 분리 정형 그대로 적용
- 336차 5-2-A ↔ 5-3 실행 순서 정상 (5-3 → 5-2-A 순서)
- 333차/342차/347차 sibling write warning 자동 검증 단계 정상 (CJK grep 0건, parts.append 카운트 32회 일치)
- 335차 §3.5 구조적 오탐 정형 정상 작동 (5-3에서 last+details 동시 갱신 → 신호 4 무조건 발동 → proxy check disambiguate)
- 335차 source URL substring + CJK grep proxy 검증 단계 정상

## 발견 사항
- **함정 8 by_category 영구 잔존 재확인 (349차)**: `commit_publish()` 결과 by_category에 `"1219746": 1` 정수 키 1개 추가됨. 297차부터 누적된 drift — 사용자 게이트 보정 대기 중, cron은 drift 보고만.
- by_category는 ID_TO_NAME 사전이 있으면 1줄 보정으로 정리 가능하지만 SSOT 변경이라 사용자 게이트 필수.

## 빌드 디테일
- 긱뉴스 description 추출: "최대 추론 설정이 AAII에서 50점을 기록해, Kimi K3 (max) 와 GLM-5.2 (max)에 이어 3위임 2,840억 개 전체 파라미터 중 토큰마다 130억 개만 활성화하는 MoE 모델이며, 텍스트 입출력과 100만 토큰 컨텍스트를 지원함 API 가격은 100만 토큰당 입력…"
- Picsum 이미지: deepseek-v4-flash-bench + moe-architecture-perf
- 본문 6섹션 (도입 → 사양 → 활용 → 가격분석 → 전망 → 요약)
- Python 코드 블록: DeepSeek API 호출 예제 (OpenAI 호환 클라이언트, reasoning.effort="max")

## 발행 후 stats
- daily_counts: {AI/ML: 5} (오늘 +1)
- total: 159
- by_category: AI/ML=845, iOS/Swift=18, 개발도구=151, 투자/경제=14, 기타=14, 아이디어=6, 개발 팁=14, 개발팁=2, **1219746=1** (정수 키 drift)
- 5-2-A 누락 백필 1건 (state.json엔 #1165, published_topics.json엔 누락 → 300차 + 336차 + 337차 정형 순서 정상)

## 발행 검증
- §3.8.1 raw 가드: first_ids=['1164', '1163', '1162', '1161', '1160'] (status=200, application/json)
- 5-5 proxy check: status=200 + og:title="DeepSeek V4 Flash 0731의 지능·성능·가격 분석 — MoE 효율의 새 기준점" 정확 매칭 + source_present=True + cjk_suspicious=False
- publish_post() 이미지 2장 업로드 (1/2 26KB, 2/2 56KB) + OG 썸네일 자동 설정

## 5-5 검증 출력
```
status=200
title=DeepSeek V4 Flash 0731의 지능&middot;성능&middot;가격 분석 &mdash; MoE 효율의 새 기준점
og:title=DeepSeek V4 Flash 0731의 지능·성능·가격 분석 — MoE 효율의 새 기준점
source_present=True
cjk_suspicious=False
og:image=https://img1.daumcdn.net/thumb/R800x0/?scode=mtistory2&fname=...
```

## 결론
#1165 정상 발행. 123회차 연속 all-green.