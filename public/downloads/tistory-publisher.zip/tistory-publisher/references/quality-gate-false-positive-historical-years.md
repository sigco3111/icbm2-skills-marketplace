# Quality Gate False Positive — Grade D + Historical Year References (2026-06-03)

**Status:** 🟡 Known false positive, recognized and bypassed
**First observed:** 2026-06-03 21:00 KST publish (`sigco.tistory.com/619`)
**Related:** `references/quality-gate-false-positives.md`

## Symptom

Tistory 품질 게이트가 비교/타임라인 글이나 역사적 맥락을 담은 글에서 의도치 않게 **Grade D**를 반환:

- 2026-06-03 21:00 글: `$4조 IPO 흡수 시나리오` — **Grade D (23점)** (실제 발행은 false positive로 통과)
- 점수 분석: 6개 과거 연도(2000, 2008, 2019, 2020, 2021, 2024) × -10점 = -60점
- 긱뉴스 2026 발행 글 + 제목에 freshness 강조 없음 + 과거 연도가 비교/타임라인 맥락 → **모두 recognized false positive 패턴 충족**

## 기존 recognized false positive 패턴 (3가지)

SKILL.md 기준:

1. 긱뉴스 2026 발행 글
2. 과거 연도가 비교/타임라인 맥락
3. 제목에 freshness 강조 없음

→ 위 3가지 **모두** 충족 시 발행 진행

## 새 발견 패턴 (2026-06-03)

과거 연도(`1990s`, `2000`, `2008`, `2019`, `2020`, `2021`, `2024` 등)가 **본문에 비교/타임라인 맥락으로 6회 이상** 등장하면:

- 각 매칭 × -10점 = 큰 음수 누적 → Grade D 강제
- **그러나** 글이 2026년 최신 주제를 다루면 false positive

**4번째 패턴 후보**:
> 본문 내 과거 연도가 비교/타임라인 맥락(인용 부호·역사적 비유·타임라인 표)으로 등장하고, 긱뉴스 2026 출처 + 제목이 시의성을 다루면 false positive 허용

## 권장 액션

다음 SKILL.md patch 시 적용:

```yaml
# 기존 3개 패턴에 추가
4. 본문에 과거 연도 6회+ 등장 + 비교/타임라인 맥락 + 긱뉴스 2026 출처 → Grade D여도 발행 진행
```

(다음 quality-gate-false-positives.md 업데이트 시 반영)

## 검증

2026-06-03 발행 사례:
- 입력: "주식시장은 Anthropic, SpaceX, OpenAI를 삼킬 수 있을까?" (긱뉴스 #30116)
- 점수: Grade D (23점)
- false positive 통과: ✅
- 발행: sigco.tistory.com/619, public, 4,338자
- 결과: 정상 발행 (사용자 피드백 대기 중)

## Related

- `references/quality-gate-false-positives.md` — 기존 false positive 룰셋
- SKILL.md "Recognized false positive 패턴" 섹션
- ISS-027 (Cron 출력 bloat) — 매일 3건 발행으로 출력 누적 가속화
