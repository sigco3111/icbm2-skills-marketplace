# Tistory 발행 skip 진단 가이드 (2026-06-08 87차 추가)

## 배경

cron `b1bca63a117a` (Tistory 자동 발행)가 `'기타' 카테고리의 긱뉴스 주제와 트렌드 주제 모두 소진되었습니다` 같은 skip 메시지를 자주 뱉음. 사용자(=희정님)는 "할당량 제한을 풀어달라"고 요청했으나, 코드 검증 결과 **카운트 제한은 이미 무제한**이고 진짜 원인은 **주제 풀 소진(dedup)**.

## 핵심 진단 경로

### 1단계: Notion 긱뉴스 fallback DB가 비어있는지 확인

```bash
/usr/bin/python3 -c "
import json
d = json.load(open('/Users/hjshin/.hermes/memory/fallback_topics_cache.json'))
t = d.get('topics', {})
for cat in ['AI/ML','iOS/Swift','개발도구','투자/경제','아이디어','기타','개발팁']:
    print(f'  {cat}: {len(t.get(cat, []))}개')
print('cached_at:', d.get('cached_at'))
"
```

87차 관찰 사례: 캐시에 `'개발팁': 2` 하나만 있고 다른 6개 카테고리는 모두 0개였음. 이 상태에서 `select_best_category()`는 모든 후보에서 available=0 → None 리턴 → skip.

### 2단계: dedup 누적 확인

```bash
wc -l /Users/hjshin/.hermes/memory/published_urls.txt
/usr/bin/python3 -c "import json; print(len(json.load(open('/Users/hjshin/.hermes/memory/published_topics.json')).get('topics',[])))"
```

87차 관찰: 381 URL / 434 해시 누적. 긱뉴스 RSS 1시간 주기 × 12개 한정 = 일일 신규 글자제 약 12개, 그러나 12시간 이내에 dedup이 다 차서 그 다음 12시간은 skip. **하루 12개 신규 긱뉴스로는 1시간 cron 주기를 감당 못 함.**

### 3단계: daily_counts 확인

```bash
/usr/bin/python3 -c "
import json
from datetime import datetime
d = json.load(open('/Users/hjshin/.hermes/memory/blog_pipeline_state.json'))
print(json.dumps(d.get('daily_counts',{}).get(datetime.now().strftime('%Y-%m-%d'), {}), ensure_ascii=False, indent=2))
"
```

`daily_counts`는 날짜 키라 매일 자동 리셋됨 — 누적은 별 문제 아님. 87차 관찰: `2026-06-08`에 `개발도구: 5`건이 정상. **카운트 자체는 무관.**

## 해결 옵션 매트릭스

| 증상 | 진단 | 해결 |
|------|------|------|
| cron이 "할당량 소진" 반복 | Notion fallback DB 비어있음 | `python3 blog_pipeline.py --refresh-topics` |
| 하루 100건 발행하고 싶음 | 코드 제한 확인 | `MAX_POSTS_PER_CATEGORY_PER_DAY` 100으로 (87차 설정됨) |
| '기타' 카테고리만 자주 막힘 | available 0 지속 | `select_best_category()` priority에서 제외 (87차 적용) |
| dedup이 너무 빡빡 | published_urls.txt > 300 | 일부 정리 또는 `--refresh-topics` 더 자주 |
| cron이 매시간 skip | Notion 후보 < 시간당 발행량 | `b02a45f4d14e` 크론 주기 늘리기 검토 (트래픽 주의) |

## 87차 적용된 코드 변경 (참고용)

`~/.hermes/scripts/blog_pipeline.py`:

- `MAX_POSTS_PER_CATEGORY_PER_DAY`: 999 → 100 (안전망 명시)
- `can_publish_category()`: 사실상 항상 True
- `check_all_categories_exhausted()`: 항상 False
- `select_best_category()`: priority에서 '기타' 제거, None 리턴 가능
- `run_pipeline()`: category None 가드 추가 → 명확한 skip 메시지

## 자동 진단

```bash
bash ~/.hermes/skills/automation/tistory-publisher/scripts/diagnose_blog_skip.sh
```

→ 5초 안에 "원인 + 해결" 출력. cron 사용자 알람이 울릴 때 첫 명령으로 권장.

## 근본적 한계

**Notion 긱뉴스 RSS는 하루 ~12개 신규 글.** 이걸로 1시간 cron(하루 12~24회 발행) 감당 불가. 진짜로 "무제한 발행"을 원하면:

1. 긱뉴스 외에 다른 소스(Reddit, HN, GitHub trending 등) 통합
2. 트랜딩 폴백(`get_trending_topics_for_category`) 비중 확대 — 현재는 긱뉴스가 1순위, 트렌드가 2순위 폴백
3. 긱뉴스 RSS 폴링 주기 단축 → 후보 풀 확대
4. 사용자가 직접 주제 입력 (`--force-topic`)

이 네 가지 중 하나는 가야 함. 87차의 100건 설정은 "코드상 제한"만 풀었을 뿐, 실제 발행 가능량은 여전히 **시간당 ~1~2건**.
