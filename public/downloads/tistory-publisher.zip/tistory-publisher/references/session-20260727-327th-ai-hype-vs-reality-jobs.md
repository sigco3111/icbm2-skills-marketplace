# 327차 — 일자리에 무슨 일이 벌어지고 있나? AI 과대광고와 현실 구분하기

**발행일**: 2026-07-27 06:05 KST
**글 번호**: #1112
**카테고리**: AI/ML (1219746)
**긱뉴스 토픽**: https://news.hada.io/topic?id=31837 (gn=31837)
**본문 길이**: 5881자 (parts.append() 정형화, 3000자 이상 + 코드 블록 + 푸터 동시 케이스)
**연속 all-green**: **102회차** (288~327)

## 제목 + 본문 빌드

- 제목: "일자리에 무슨 일이 벌어지고 있나? AI 과대광고와 현실 구분하기 — 데이터가 말하는 진짜 일자리 충격과 12개월 생존 전략"
- 본문 5개 섹션: ① 데이터가 말하는 것 (0.77%p vs 0.85%p) ② 진짜 충격을 받는 그룹 (청년 사무직) ③ 현실 점검 프레임 3단계 (자가 진단 → AI 활용 → 영역 정의) ④ 향후 12개월 전망 ⑤ 핵심 세 줄 요약
- 코드 블록 1개 (Python 자가 진단 5영역 체크리스트)
- 이미지 2장 (Picsum seed: ai-hype-vs-reality-jobs, labor-market-ai-exposure-bands)
- OG 썸네일 정상 설정 (`https://blog.kakaocdn.net/dna/cCXMI3/dJMcaftUUh1/...`)

## 정형화 패턴 연속 카운트 갱신

- **신호 4 오탐 disambiguate 27연속 확정** (298→327) — 정상 워크플로우의 일부로 정착
- **진입 시점 신호 4 + 5-5 disambiguate 트리거 18연속** (310~327) — cron은 직전 차 누적량과 무관하게 동일 패턴
- **단일 패스 빌드 패턴 18연속 정형화** (305→327) — 305차 OG description 임베드 pattern 재확인
- **parts.append() 정형화 18연속** (305→327) — 본문 3000자 이상 케이스 정형화 재확인 (318차 함정 17 정형 임계)
- **311차 fallback 패턴 미사용 18차 연속** — AI/ML 후보 9개로 충분 정상

## §3.11 5단계 시퀀스

1. **§3.8.1 가드 raw VALID**: status=200 + first_id=#1111 (326차 가장 최근 발행)
2. **§1 트렌드 새로고침**: blog_pipeline.py --refresh-topics → 12개 갱신 (AI/ML 9개 + 개발도구 2개 + 개발팁 1개)
3. **§3-a AI/ML ready**: status=ready + gn=31837 "일자리에 무슨 일이 벌어지고 있나? AI 과대광고와 현실 구분하기" 선정 (1순위, score 3.0, freshness OK)
4. **§3-3 본문 빌드**: write_file(`/tmp/build_post_327.py`) + /usr/bin/python3 -s + 5881자 빌드 → /tmp/post_327.html
5. **§3-b publish**: --category 1219746 (int) → #1112 발행 (title 4196자 검증 통과, 이미지 2장 CDN 업로드)
6. **§3-b.5 commit_publish**: stats.today=AI/ML:4, 개발도구:3, total=106
7. **5-3 last+details 통합 보정**: state.details 184→185, last=#1112
8. **5-2-A 백필**: 1건 (누적 동기화), pt.details 185→186
9. **5-4 §3.5 신호 4 발동**: 예상대로 (details[-1]=last url 동시 갱신 → 구조적 오탐)
10. **5-5 proxy check disambiguate**: #1112/#1111/#1110/#1109/#1108 5건 모두 status=200 + title/og:title 정확 매칭 → 오탐 확정

## 함정 회피 매트릭스 (5중 동시)

- **함정 6** (heredoc + env -i SyntaxError): 격리 모드 없이 set -a source + 격리 패턴으로 우회
- **함정 7** (--category int만): publish 인자 int 1219746 명시
- **함정 8** (by_category["1219746"]=1 영구 잔존): 102연속 재확인 (사용자 게이트 시 ID_TO_NAME 1회 보정 권장, cron은 drift 보고만)
- **함정 11** (execute_code cron 차단 회피): write_file(`/tmp/build_post_327.py`) + /usr/bin/python3 -s + read_file(`/tmp/post_327.html`) → tistory_publisher.py --file 패턴
- **함정 15** (5-5 proxy check 격리 패턴): §1단계 가드와 동일 격리 패턴 적용

## 본문 빌드 코드 패턴 관찰

- `fetch_og_description(url, max_chars=160)` 함수 — 긱뉴스 OG description 160자 trim 추출 (함정 3 회피)
- `parts.append('<h1>...</h1>')` 헤더 + OG description blockquote 임베드
- 5개 본문 섹션 + 1개 코드 블록 + 1개 요약 + 1개 푸터 = 30+ parts.append() 항목
- KST 타임존 명시 timestamp (`datetime.timezone(timedelta(hours=9))`, 323차 정형화 재확인)

5881자 본문 = 318차 함정 17 정형 임계(3000자) 정확히 적용, parts.append() 30+ 항목 단일 f-string 회피 정상.

## §3.5 신호 4 구조적 오탐 패턴 정형화

5-3에서 details append + last 두 필드를 같은 슬롯(#NNN)으로 동시 갱신 시 details[-1].slot == last_url.slot이 무조건 성립 → 신호 4 무조건 발동. 298~327차 모두 동일 패턴.

**disambiguate 절차**: 5-5 proxy check에서 직전 차 발행 5건 모두 status=200 + og:title 매칭 확인 → 진짜 발행 판정. cron은 매 차 동일 절차로 disambiguate.

## 누적 카운트 보고

327차 daily_counts={AI/ML:4, 개발도구:3} (총 7건). by_category["1219746"]=1 영구 잔존 102연속 — SSOT 변경이라 사용자 게이트 시 ID_TO_NAME 매핑 보정 권장 (cron은 임의 자동 보정 금지).

## 연속 all-green 102회차

288차 세션 만료 가드 → 327차까지 매 차 동일 패턴 시퀀스로 정상 운영 유지. 매 cron 패턴 분기 없이 동일 시퀀스 적용 가능.
