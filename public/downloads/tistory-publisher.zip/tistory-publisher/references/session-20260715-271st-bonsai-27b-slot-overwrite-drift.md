# 271차 세션 노트 — Bonsai 27B + §3.34.44 슬롯 덮어쓰기 drift 케이스 3호

**날짜**: 2026-07-15
**세션**: 271차 (cron 자동 발행)
**결과**: ✅ green-run confirmation, **연속 all-green 58회차 (213~271차)**

## 발행 결과 요약

- **글 번호**: `#1013 Bonsai 27B - 휴대폰에서 실행되는 27B급 온디바이스 모델이 보여준 것`
- **카테고리**: AI/ML (1219746)
- **gn_topic_id**: 31450 (6점)
- **정책 적용**: §3.34 #21 AI/ML 우선 + §3.34.45 매트릭스 분기 1 ("FRESH 'AI/ML' + 비-기타 혼재 → AI/ML 점수 1순위 픽")
- **FRESH 잔여**: 8개 (AI/ML 5 + 개발도구 1 + 개발팁 2) → AI/ML FRESH 중 점수 1순위 31450 (6점) 픽
- **PUB 이미 처리**: 4개 (자정 사이 외부 발행: 31449 Codex, 31437 Precursor, 31448 load-bearing hook, 31458 AI에 생각 떠넘김)
- **daily_counts**: `{'AI/ML': 6, '개발도구': 3, '개발팁': 1, '투자/경제': 1}` (AI/ML 5→6, +1 정확)

## 워크플로 단계별 검증

1. **§3.8.1 세션 가드**: `env -i HOME=... PATH=... PWD=... /bin/bash -c '...'` 격리 패턴 + 247차 PWD 보강 → `status=200, content-type=application/json;charset=UTF-8, cookie_count=8, OK_SESSION_VALID`
2. **§3.34.40 FRESH 4-field 매칭**: TOP 12개 후보 중 4개 (31449/31437/31448/31458) 가 이미 pt/state 양쪽에 sync → FRESH 잔여 8개
3. **§3.34.46 gn-fetch-content 영구화**: `_try_md_endpoint(31450)` 직접 호출 → `status=200, 9763 bytes` 1단계 `.md` endpoint 즉시 fetch
4. **§3.34.47 격리 빌드**: `write_file` 로 `/tmp/tistory_drafts_271st/build_draft.py` UTF-8 선언 + 5360 bytes 저장 → `python3 <script>.py` 격리 호출 정상
5. **§3.34.48 `* ` 분기 + 4단계 헤더 강등 정규식**: 266차 정착 코드 그대로 복사 — 본문 모두 `- ` 패턴이라 hit 안 했지만 안전 가드 포함
6. **§3.34 #21 + §3.34.45 매트릭스 분기 1**: AI/ML FRESH 5개 중 점수 1순위 `31450 (6점)` 픽 (실전 6호)
7. **publish**: `tistory_publisher.py --title ... --category 1219746 --content "$(cat draft_31450.html)" --image-query "bonsai 27b mobile on-device ai smartphone tree" --source-url ... --gn-topic-id 31450` → `✅ 발행 성공! https://sigco.tistory.com/1013`
8. **§3.5 5중 신호 검증**: 모두 `https://sigco.tistory.com/1013` 일치, `triple_signal_match: true, all_match: True`
9. **§3.11 post_publish_sync**: `sync` 서브커맨드 + 7필드 박기 → `pt_updated: true, state_updated: true, errors: []`
10. **cleanup cron 임무 #16 dry-run**: `✅ 누설 없음` (58회 연속 all-green)
11. **라이브 페이지 검증**: `status=200, size=68442, window.T.entryInfo={entryId:1013, categoryId:1219746, categoryLabel:"AI 뉴스"}, <title>Bonsai 27B...</title>` ✅

## §3.34.44 슬롯 덮어쓰기 drift 케이스 (NEW, 271차 식별)

### 문제 상황
사전 검증에서 `state.last_published_url=https://sigco.tistory.com/1013` + `gn_topic_id=31458` ("우리는 너무 많은 생각을 AI에 떠넘기고 있는가?") 으로 박혀있었음 — 자정 사이 외부에서 발행된 흔적.

### 실제 발행 후 발견
우리 publish 인 `gn=31450 Bonsai 27B` 가 `tistory_publisher.py` 통해 슬롯 `#1013` 으로 발행됨. 그런데 사전 검증의 `state.last_published_url` 은 이미 `#1013` 을 가리키고 있었음 → **슬롯 충돌**.

### 라이브 페이지 검증으로 진짜 점유자 확인
```bash
curl -s 'https://sigco.tistory.com/1013' -H 'User-Agent: Mozilla/5.0' -o /tmp/check_1013.html
grep -E '<title>|name="description"' /tmp/check_1013.html
# → <title>Bonsai 27B - 휴대폰에서 실행되는 27B급 온디바이스 모델이 보여준 것</title>
# → window.T.entryInfo = {"entryId":1013,"isAuthor":false,"categoryId":1219746,"categoryLabel":"AI 뉴스"}
```
→ 슬롯 `#1013` 의 진짜 점유자는 우리 publish 인 Bonsai 27B. 즉 자정 사이 외부 발행 글이 `#1014` 로 밀려났거나 별도 ID 로 이동.

### 해결
`post_publish_sync sync --url "https://sigco.tistory.com/1013" --title "Bonsai 27B..." --gn-topic-id 31450 --category "AI/ML" --category-id 1219746 --source-url ...` 호출 → pt/state/details/last/stats 모두 `gn=31450` 기준으로 정정 박힘. §3.5 5중 검증 다시 일치.

### drift → sync 자동 보정 사이클 누적 검증
- 253차: drift 패턴 식별
- 254차: 1호 (5중 일치 + drift 무해)
- 270차: 2호 (자정 사이 외부 2건 발행 흔적)
- **271차: 3호 (슬롯 덮어쓰기 케이스, NEW)**

### 운영 가이드 추가
- 사전 검증의 `state.last_published_url` 이 자정 사이 외부 발행 흔적으로 박혀있을 수 있음
- 5중 신호 일치 (모두 같은 슬롯 URL) 라고 판단되면 정상 진행하되, **publish 직후 라이브 페이지 검증으로 우리 글이 실제 점유했는지 확인** 권장
- 진짜 우리 글이 박힌 슬롯이면 sync 보정 정상 → drift 무해
- 라이브 페이지 검증 실패 (직전 외부 발행 글이 여전히 노출) 시 → `post_publish_sync` 가 우리 publish URL 기준으로 자동 보정 → 5중 검증 재일치

## §3.34.49 이미지 업로드 endpoint 함정 (NEW, 271차 식별)

### 문제 상황
이미지 업로드 디버깅 과정에서 endpoint 직접 probe 시도:
```python
# ❌ 모두 405 Method Not Allowed 반환
requests.post("https://sigco.tistory.com/manage/post/image", files=files, ...)
requests.post("https://sigco.tistory.com/manage/post/attach", files=files, ...)
requests.post("https://sigco.tistory.com/manage/post/photo", files=files, ...)
# → status=405, content-type=text/html;charset=UTF-8
```

### 진짜 endpoint
```python
# ✅ /manage/post/attach.json (.json 접미사 필수)
ATTACH_ENDPOINT = f"{TISTORY_MANAGE_URL}/post/attach.json"
# = "https://sigco.tistory.com/manage/post/attach.json"

# 정상 호출 패턴
files = {"file": (fname, image_data, content_type)}
headers = {
    "User-Agent": "Mozilla/5.0 (...)",
    "Accept": "application/json",
    "Origin": TISTORY_BLOG_URL,  # "https://sigco.tistory.com"
    "Referer": f"{TISTORY_MANAGE_URL}/newpost/",  # "https://sigco.tistory.com/manage/newpost/"
}
r = requests.post(ATTACH_ENDPOINT, files=files, cookies=cookies, headers=headers, timeout=15)
# → status=200, content-type=application/json;charset=UTF-8
# → JSON 응답: {"name": "image.jpg", "url": "https://blog.kakaocdn.net/dna/.../img.jpg", "key": "..."}
```

### cron 자동화에서의 적용
`tistory_publisher.py --image-query` 옵션이 내부에서 `ATTACH_ENDPOINT` 를 호출하므로 **cron 자동화에선 endpoint 직접 probe 불필요**. 271차는 디버깅 과정에서 endpoint 검증하다 405 받음 → `ATTACH_ENDPOINT` 로 정정하여 정상 CDN 업로드 확인. **참고용 함정 가이드로만 기록**.

## 패턴 정착 확인 (누적 all-green 카운트)

- §3.8.1 세션 가드: 240~271차 (32회)
- §3.8.2 격리 패턴: 244~271차 (28회)
- §3.11 post_publish_sync: 241~271차 (31회)
- §3.34.40 후보 직접 점수 pick: 244~271차 (28회)
- §3.34.41 f-string 회피: 245~271차 (27회)
- §3.34.42 verify-tistory-cookie 격리화: 246~271차 (26회)
- §3.34.43 PWD 보강: 247~271차 (25회)
- §3.34.44 cron 차 사이 drift: 253~271차 (19회) — 271차 슬롯 덮어쓰기 sub-case 추가
- §3.34.45 #22 정책 우선순위: 256~271차 (16회)
- §3.34.46 gn-fetch-content 영구화: 261~271차 (11회)
- §3.34.47 격리 빌드: 263~271차 (9회)
- §3.34.48 `* ` 분기 + 4단계 헤더 강등: 266~271차 (6회)
- §3.34 #21 AI/ML 우선 정책: 254~271차 (18회) — 271차 실전 6호
- §3.34 #22 '기타' 제외 정책: 256~271차 (16회)
- cleanup cron 임무 #16 cat_id 누설 cleanup: 213~271차 (58회 연속 all-green)

## 신규 발견 요약 (271차)

1. **§3.34.44 슬롯 덮어쓰기 drift 케이스 (3호, NEW)** — 사전 검증의 last URL 이 자정 사이 외부 발행 슬롯을 가리키고 있을 때 publish 하면 슬롯 덮어쓰기 발생. `post_publish_sync` 가 우리 publish URL 기준으로 자동 보정 → 5중 검증 재일치. **drift → sync 사이클 정상 동작 3회째 확인**.
2. **§3.34.49 이미지 업로드 endpoint 함정 (NEW)** — `/manage/post/image`, `/manage/post/attach`, `/manage/post/photo` 모두 405. 진짜 endpoint는 `/manage/post/attach.json` (ATTACH_ENDPOINT 상수). cron 자동화에선 `--image-query` 가 내부 호출하므로 직접 probe 불필요.

## 차감/추가

- 차감: 없음
- 추가: 없음
- 모든 기존 패턴(§3.5 5중 검증, §3.11 sync, §3.34 #21 + #45, §3.34.44 drift 무해, §3.34.47 격리 빌드, §3.34.48 `*` 분기, §3.34.46 gn-fetch 영구화, §3.8.1 가드, §3.8.2 격리 패턴) 정상 동작 확인.