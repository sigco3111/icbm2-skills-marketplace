# 349차: HANDBOOK.md 에이전트 정책 준수 벤치마크 발행

- 일시: 2026-07-31 23:01 KST
- 발행: `https://sigco.tistory.com/1160`
- 원본: `https://news.hada.io/topic?id=31994`
- 카테고리: AI/ML (`1219746`)

## 검증된 실행 결과

1. 세션 raw guard: HTTP 200, JSON, 최신 글 `#1159`로 유효.
2. 진입 시 §3.5 신호 4가 `#1159`를 가짜 발행으로 경고했으나 proxy가 HTTP 200, 정확한 `og:title`, 출처 URL 존재를 확인해 구조적 오탐으로 판별.
3. 후보는 pipeline을 한 번만 호출해 확정했고 canonical topic hash, source URL 모두 중복 아님을 확인.
4. 본문은 `parts.append()` + `code_lines` 구조로 빌드: 4,824 bytes, 순수 텍스트 1,979자, 이미지 2장, 코드 블록 1개, 의심 CJK 없음.
5. standalone `publish_post()` wrapper로 발행. 이미지 2장 업로드와 OG 썸네일 생성 후 숫자 URL `#1160` 반환.
6. commit 뒤 today AI/ML이 11→12로 증가. state details/last와 published_topics last를 모두 `#1160`으로 동기화.
7. 최종 proxy: HTTP 200 + `og:title` 정확 일치 + source URL 존재. §3.5 신호 4는 동일한 구조적 오탐으로 재발했으나 proxy로 실제 발행 확정.

## 재사용할 보강점

- `parts.append()` 무결성 검사의 expected count를 사람이 상수로 적지 않는다. 이번 빌드에서 수동 기대값을 17로 잘못 적었지만 실제 호출은 18이었다. 빌드 스크립트 자체가 생성한 섹션 목록 길이, 또는 별도 manifest를 기준으로 계산해 비교한다. 수동 expected count 불일치는 본문 손실과 구분하기 어렵다.
- `commit_publish()` 결과에서 `by_category["1219746"]=1` 숫자 키가 다시 관찰됐다. 이전의 "영구 잔존 해소 추정"은 확정 사실로 취급하지 말고 매 차 drift 탐지만 유지한다. 자동 병합은 SSOT 변경이므로 기존 사용자 게이트 원칙을 따른다.
- 최종 성공 판정은 consistency 스크립트 exit code 단독이 아니라 숫자 URL + proxy 200 + 정확한 og:title + source URL + state URL 동기화 + today 증가를 함께 사용한다.
