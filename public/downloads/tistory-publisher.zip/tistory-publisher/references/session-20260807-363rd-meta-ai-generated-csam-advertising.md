# 363차 (2026-08-07 05:01) — #1201 Meta AI 생성 CSAM 광고

**Show GN**: Meta, AI 생성 아동 성적 학대 이미지가 포함된 광고 게재 (gn=32211, AI/ML, 본문 측정 2,734자 + Picsum 2장 + Python 코드 블록 1개). 단일 패스 **48연속** + §3.5 신호 4 disambiguate **29연속** + 진입 5-5 **28연속** + fallback 복귀 **40연속** + admin API 교차 검증 **3회차**.

## 함정 26 변형 C (mojibake / U+FFFD) 재발 — 363차 신규 사례

sibling subagent write warning 직후 한글 1자가 `�` (U+FFFD)로 깨지는 변형이 **363차에서 한 번 더 재발**했습니다. 361차 Zed DeltaDB에서 처음 보고된 패턴의 두 번째 실전 사례.

### 363차 실측

```python
# 원본
parts.append('<h2>5. 전망 — AI 광고 거버넌스의 재설계</h2>')
# sibling write 후 (line 97)
parts.append('<h2>5. 전망 — AI 광고 거버�스의 재설계</h2>')
```

`거버넌스`의 `넌` 한 글자 (U+B17C)가 U+FFFD로 swap. 빌드 시 CJK grep (a)는 의도된 한글/한자 매칭이 다수라 false positive 양산, parts.append 카운트 (b)도 37회로 expected와 일치. **결정적 신호는 mojibake grep (c)** — `grep -n '�' /tmp/build_post_363.py` 1회로 단독 검출.

### false-positive 노이즈 분석

본문이 한국어 위주 + 영문 고유명사 (Meta/Facebook/Instagram/CSAM/NCMEC/FTC/DSA/NSFW/red-team/blue-team/PIL/torch/open_clip) + 일부 한자 (학대/광고/구조) 가 섞여 있어서 표준 CJK regex `grep -nE '[一-鿿]|[ぁ-ゔ]|[ァ-ヴー]'`는 한국어 자체가 아니라 한자/히라가나/가타카나만 잡지만, 363차 본문에는 다음이 의도적으로 들어가서 grep 결과가 노이즈:
- 한자 substring: 학대/광고/검열/사건/구조/콘텐츠/모더레이션/이미지/시스템 (한국어 어휘의 한자 어원 흔적, sibling swap 결과가 아님)
- 의도 영문 약어: NSFW/CSAM/FTC/DSA/SLA/NCMEC/PIL 등

→ grep 결과에 의도 매칭이 많아져서 진짜 swap 케이스를 시그널로 인식하기 어려움. **판정 (363차 정형 강화)**:
- (a) CJK grep 결과 = 0건 → 안전 (sibling swap 없음)
- (b) CJK grep 결과 = 한국어 동음이의 한자 swap 의심 단어 (`입장/立場`, `자주/自走`, `설명/說明`, `정기/定時`, `자세/姿勢`, `자격/資格`, `이유/理由`, `수�/液냉`, `공감대/共识`, `일/仕事`) 등장 → swap 의심 → patch() 복원
- (c) CJK grep 결과 = 의도된 한자(인명/회사/고유명사) OR 한자 어원 흔적 → 안전 (false positive 무시)
- **(d) mojibake grep 결과 = 1건+ → 결정적 swap 신호 → patch() 복원 (CJK grep 결과 무관)**

### 363차 회피 흐름

1. `write_file /tmp/build_post_363.py` 응답에 sibling write warning 감지
2. (a) CJK grep → 다수 false positive (의도 매칭)
3. (b) `grep -c 'parts.append'` → 37회 expected 일치
4. (c) **`grep -n '�' /tmp/build_post_363.py` → 1건 검출** (line 97 `거버�스`)
5. `patch()` 한 줄 복원 → `거버넌스`로 정상화
6. 재빌드 → 정상 publish

### 함정 26 누적 통계 (333→363)

| 차수 | 변형 | 검출 방법 | swap 단어 |
|------|------|----------|----------|
| 333 | CJK 자동 치환 | (a) CJK grep | 입장 → 立场 |
| 342 | CJK + 함수 prefix 손실 | (a) CJK grep + (b) parts.append 카운트 | 정기 → 定时 + `parts.append(` 통째 소실 |
| 343 | CJK 자동 치환 | (a) CJK grep | 자세 → 姿勢 |
| 347 | CJK 3건 동시 | (a) CJK grep | 수랭/공감대/일 |
| 360 | CJK 2건 | (a) CJK grep | 背景下/轨迹 |
| 361 | mojibake/U+FFFD | (c) mojibake grep (CJK grep은 0건) | 이 → � |
| **363** | **mojibake/U+FFFD** | **(c) mojibake grep (CJK grep은 false positive 다수)** | **넌 → �** |

### 정형 강화 (363차 확정)

- **3종 grep 모두 필수**, 단 (c) mojibake grep이 가장 결정적.
- 본문에 의도된 한자/한글이 많을수록 CJK grep은 false positive 양산 → 노이즈 속에서 진짜 swap을 시그널로 인식하기 어려움. **판정 우선순위**: (c) mojibake grep > (b) parts.append 카운트 > (a) CJK grep.
- mojibake grep은 문자열 리터럴 안의 모든 `�`를 잡으므로 의도 케이스 가능성 거의 없음 (한자/한글이 깨졌다는 명확한 신호).
- 빌드 후 본문 HTML (`/tmp/post_363.html`)에도 동일 grep 적용 권장 — sibling write가 HTML까지 영향 줄 가능성 (363차는 .py 단계에서 검출됐지만 안전망 차원).

## admin API 교차 검증 3회차 (361→363)

363차 #1201 발행 후 proxy + admin API 양쪽 모두 disambiguate 통과:

```
=== PROXY #1201 ===
status=200
title=Meta, AI 생성 아동 성적 학대 이미지가 포함된 광고 게재 — 콘텐츠 모더레이션의 구조적 한계
og:title=Meta, AI 생성 아동 성적 학대 이미지가 포함된 광고 게재 — 콘텐츠 모더레이션의 구조적 한계
source_present=True
cjk_or_mojibake=False
=== ADMIN posts.json ===
first_ids=['1201', '1200', '1199', '1198', '1197']
verdict_first_id==1201: True
```

admin posts.json 최상단 id가 이번 차 발행 슬롯(1201)과 일치 → 가짜 발행 원천 불가능. 361차 #1197, 362차 #1198, 363차 #1201 연속 3회차 정상 작동.

## 빌드 단일 패스 48연속

`build_post_363.py` 안에 `requests.get(gn_url) + og:description regex` 임베드 → 159자 description 추출 + Picsum 2장 + Python 코드 블록 1개 (`code_lines` 패턴) + 본문 2,808자 빌드. 305차 단일 패스 정형 48연속 회차.

## 판정 매트릭스 실전

- 본문 2,808자 (< 3000자 임계) + Python 코드 블록 1개 → **판정 (a) + 안전 편향으로 parts.append() 정형 선택** (336차 함정 28 회피 자동)
- `code_lines = [...]` + `'\n'.join(code_lines)` 336차 정형 그대로 적용

## 발행 통계

- **#1201** (gn=32211, AI/ML)
- daily_counts={AI/ML:5, 개발도구:1} (오늘 6건)
- total=193
- 5-3 details_len=273, last_topics_len=20
- 5-2-A details_len=276, 누락 백필 1건 (state→published_topics 정상 단방향 백필)

## 운영 보강 (363차 추가)

- **mojibake grep이 가장 결정적**: CJK grep false positive 노이즈가 많은 본문(한국어 위주 + 한자 어원 흔적 + 영문 약어)에서 sibling swap의 진짜 시그널은 거의 항상 `�` 1자로 압축된다. CJK grep 결과 0건이어도 mojibake grep은 항상 별도 실행할 것.
- **판정 우선순위 (363차 정형)**: (c) mojibake grep > (b) parts.append 카운트 > (a) CJK grep. 3종 모두 실행하되 의심 시그널은 (c) 우선.
- **빌드 후 HTML 추가 grep**: `/tmp/post_XXX.html`에도 동일 mojibake grep 적용 권장. sibling write가 빌드 스크립트 단계는 정상이지만 HTML 출력까지 영향 주는 케이스 안전망.

## 연속 all-green 카운터 갱신 (363차 기준)

- 단일 패스: **48연속**
- §3.5 신호 4 disambiguate: **29연속**
- 진입 5-5: **28연속**
- fallback 복귀: **40연속**
- admin API 교차 검증: **3회차**
- 함정 26 변형 C 재발: **2회차** (361→363)
- by_category 영구 잔존: **67연속** (297→363)
