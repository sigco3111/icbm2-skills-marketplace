# 277차 세션 — #1024 「Machine Learning Study 혼자 해보기」

**날짜**: 2026-07-16 (277차)
**슬롯**: #1024
**카테고리**: AI/ML (1219746)
**gn_topic_id**: 31479 (10점, FRESH AI/ML 1순위)
**연속 all-green**: 64회차 (213~277차)

## §3.34.53 (NEW, 277차 정착) — 영문 자동완성 토큰 오타 guard

**실제 hit 없음** — 사전 검증 패턴 정착만. 277차 빌드 과정에서 식별:

### (a) `gn-fetch-content.py` 하이픈 vs 언더스코어 importlib 패턴

```python
# ❌ 277차 첫 시도 — ModuleNotFoundError
import gn_fetch_content  # 언더스코어 (실제 파일은 하이픈)

# ❌ 277차 첫 시도 — module name 자동완성에 오염
importlib.util.spec_from_file_location(
    "gn_fetch_content",  # 자동완성이 언더스코어로 박힘
    "/Users/mac/.hermes/skills/automation/tistory-publisher/scripts/gn-fetch-content.py"
)
# → 파일은 찾지만 module name이 오염된 상태

# ✅ 표준 패턴 — 짧은 alias 권장
importlib.util.spec_from_file_location(
    "gfc",  # ← 짧고 자동완성 영향 적음
    "/Users/mac/.hermes/skills/automation/tistory-publisher/scripts/gn-fetch-content.py"
)
gfc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gfc)
```

**적용 대상**: `gn-fetch-content.py`, `gn-fetch-md.py`, `gn-markdown-to-tistory-html.py` 등 모든 하이픈(-) 파일명.

### (b) build_draft_*.py 본문 안 영문 자동완성 토큰 변환 가능성

275차 이전 워크플로에서 사용된 `roadmap` / `load_map` / `loadmap` 같은 변형 토큰이 자동완성 후보로 학습됐을 가능성. 277차엔 한국어 `로드맵`으로 대체하여 무영향.

**이중 검증 패턴**:
```bash
# 1) build_draft_*.py 작성 직전
grep -E "load_map|loadmap|load_map" /tmp/tistory_drafts_*/build_draft_*.py

# 2) draft.html 저장 직후
re.search(r"load_map|loadmap", html_content)  # hit시 즉시 patch
```

## §3.34.46 영구화 패턴 (277차 5회째 검증)

```python
import importlib.util
spec = importlib.util.spec_from_file_location(
    "gfc",
    "/Users/mac/.hermes/skills/automation/tistory-publisher/scripts/gn-fetch-content.py"
)
gfc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gfc)
result = gfc.fetch_gn_content(31479)
# → 277차: 4427 bytes, 본문 평문 3560자 (Topic Body marker)
```

## Topic Body 추출 + 4단계 헤더 강등 + `* ` 분기 (모두 277차 정상)

```python
# Topic Body 마커
m = re.search(r"## Topic Body\s*\n+(.*)", content, re.DOTALL)
body = m.group(1)
m2 = re.search(r"\n## Comments", body)
if m2:
    body = body[:m2.start()]
body = body.strip()

# 4단계 헤더 강등
body = re.sub(r"^#### (.+)$", r"### \1", body, flags=re.MULTILINE)

# md_to_html (262차 정착 + 266차 * 분기 보강)
# 본문: 31479는 `#### 1. 문서의 목적` + `* 이 글은...` 패턴
```

## publish 결과

```bash
✅ OK: 277차 발행 성공
URL: https://sigco.tistory.com/1024
본문 평문: 4268자 (300자 가드 통과)
이미지: Picsum ID 699 (두 슬롯 동일)
5중 신호: state.last_published_url, state.last.url, state.details[-1].url,
         pt.last.url, pt.details[-1].url 모두 #1024 일치
title ASCII sanity: Machine/Learning/Study/GitHub 4개 모두 OK
daily_counts[2026-07-16]: {'AI/ML': 7, '개발도구': 2} (AI/ML 6→7, +1)
cleanup cron 임무 #16: ✅ 누설 없음 (63→64회 연속 all-green)
```

## 핵심 결론

- §3.34 #21 AI/ML 우선 정책 + §3.34.45 매트릭스 4번째 분기 6회째 검증 (255차 1호 → 266차 2호 → 268차 3호 → 269차 4호 → 270차 5호 → **277차 6호**)
- §3.34.40 v2 FRESH 4-field 정상 (pt.last.gn_topic_id=31482 가드)
- §3.34.50 Topic Body marker 5회째 정상
- §3.34.46 영구화 5회째 정상 (1단계 `.md` endpoint)
- §3.34.48 `* ` 분기 4회째 정상
- §3.34.52 IME 변환 회피 (영문 4개 토큰 sanity check 통과)
- **§3.34.53 사전 검증 패턴 정착** (실제 hit 없음)

## 영구화 권장 (cleanup cron 임무 #33 신규)

1. build_draft_*.py 작성 템플릿에 `gfc` alias 표준화 주석
2. 본문 안 영문 자동완성 토큰 (`roadmap`/`load_map`/`loadmap`) 사전 검증 자동화
3. draft.html 저장 직후 `re.search(r"load_map|loadmap", html_content)` 검증 + patch 자동화

## 차감/추가

- 차감: 없음
- 추가: cleanup cron 임무 #33 (build_draft_*.py 자동 변환 guard 정규식 자동 삽입)
