# 함정 26 CJK 자동 치환 swap 후보 사전

`write_file /tmp/build_post_NNN.py` 응답에 sibling subagent write 경고가 떴을 때 lint는 통과해도 본문이 한자로 자동 swap되는 패턴의 누적 swap 후보 모음.

## 누적 swap 후보 (확정 + 가설)

| 한국어 | 한자 | 비고 |
|--------|------|------|
| 입장 | 立場 | 333차 확정 |
| 자주 | 自走 | 가설 |
| 설명 | 說明 | 가설 |
| 정기 | 定時 | 342차 확정 |
| 자세 | 姿勢 | 343차 확정 |
| 자격 | 資格 | 가설 |
| 이유 | 理由 | 가설 |
| 수랭 | 液냉 | **347차 신규** |
| 공감대 | 共识 | **347차 신규** |
| 일 (작업 의미) | 仕事 | **347차 신규** |

**347차**: 단일 차 swap 최다 3건 동시 발생. 표준 grep `grep -nE '[一-鿿]|[ぁ-ゔ]|[ァ-ヴー]' /tmp/build_post_347.py` 한 번에 3건 모두 검출 → `patch()` 3회로 한국어 원문 복원.

## 정형 대응 (sibling write warning 직후 필수 5단계)

1. lint 결과 확인 (SyntaxError 없으면 build 정상 가능)
2. `grep -nE '[一-鿿]|[ぁ-ゔ]|[ァ-ヴー]' /tmp/build_post_NNN.py` 한자/CJK 의심 grep
3. `grep -c 'parts.append' /tmp/build_post_NNN.py` 카운트 진단 (expected vs 실제)
4. 의심 라인 read_file + patch() 복원
5. 모든 단계 OK면 publish 진행

## 누적 빈도 (333차~347차)

- 333차: 1건 (입장 → 立場)
- 342차: 1건 (정기 → 定時)
- 343차: 1건 (자세 → 姿勢)
- 347차: **3건 동시** (수랭/공감대/일 → 液냉/共识/仕事)

미래 차에서 4건+ 발생 시 본 문서에 추가.

## CKJ 위험도 평가

- **고위험**: 본문에 동음이의 한자 swap 후보 단어 + parts.append() 라인 다수 + 코드 블록 1개+
- **저위험**: 본문 < 2000자 + parts.append() 라인 10개 이하 + 단일 f-string OK 케이스
