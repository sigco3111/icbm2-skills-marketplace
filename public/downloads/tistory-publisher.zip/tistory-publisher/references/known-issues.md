# Known Issues — Tistory Publisher Skill
Last updated: 2026-05-27

## 🔴 이미지 + 개행 누락 문제 (2개월 이상 미해결)
**Symptom:** 발행된 블로그 글에 이미지가 표시되지 않고, 개행(line break)이 완전히 사라짐.
**First reported:** 2026-04-20 21시 발행 글
**Status:** 미해결 (learning-gap-tracker 등록됨, 우선순위 high)
**Root cause:** 未特定 — `tistory_publisher.py`의 HTML 생성 로직 분석 필요

## 🟡 Korean word boundary corruption (2026-05-23, 70차 및 2026-05-26, 72차)
**Symptom:** CJK 정제 시 Chinese 복합어가 포함된 Korean 문장이 점진적으로 파괴됨.
**72차 신규 패턴:** "很有意思하다" → "有意思하다" → "하다." (순차 문자 제거). Chinese 복합어 "很有意思"의 개별 문자(很/有/意/思)가 CJK cleaning dict로 순차 제거.
**예방:** CJK cleaning 전 preemptive Chinese → Korean 교체 실행.

## 🟡 Japanese/Chinese 조사(particles) 정제 누락 (2026-05-27, 75차)
**Symptom:** Korean 문장 속 Japanese/Chinese 조사 `오`가 CJK regex 탐지 밖이라 CJK 루프를 통과한 후 HTML에 남아 발행됨.
**Root cause:** CJK regex [\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff]는 Japanese/Chinese 품사 markup(particles)을 탐지하지 못함.
**대응:** HTML 변환 직후 문자 치환 — `html.replace('오 ', 'ろ ')` 시도. 단어 앞의 Korean particle만 교체 대상.
**예방:** Markdown 작성 시 Korean-only 입력.

## 🟡 markdown_to_tistory_html.py 제목 인식 문제 (2026-05-22)
`blog_quality_gate.py --file`가 H1을 제목으로 오인. `--title` CLI로 별도 전달.
