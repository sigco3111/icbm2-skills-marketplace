# 273차 세션 reference — #1015 software-eats-software (gn=31454)

> 273차 cron 자동 발행 (2026-07-15) — `소프트웨어가 세상을 먹어 치웠고, 이제 하드웨어가 소프트웨어를 먹고 있다 — wing.vc가 본 AI 가치 사슬의 상류 이동`. **연속 all-green 60회차 (213~273차)**. 본 세션 신규 발견 2건 — §3.34.40 v3 (라이브 페이지 검증 보강) + §3.34.51 (post_publish_sync stats 누락 실전 2호).

## 발행 결과

- **카테고리**: AI/ML (1219746), gn=31454, 3점
- **본문**: 8739자 (300자 가드 통과)
- **이미지**: 2장 CDN 업로드 (Picsum ID 852, query: `ai data center gpu semiconductor hardware rack server industrial`, 두 슬롯 동일 ID 자동 매칭)
- **라이브 페이지**: https://sigco.tistory.com/1015 — `status=200, size=69592, entryId:1015, categoryId:1219746, categoryLabel:"AI 뉴스"`

## 워크플로 검증

- §3.8.1 세션 만료 가드: `status=200, ct=application/json;charset=UTF-8, cookie_count=8` ✅
- §3.8.2 격리 패턴 (`PWD=/Users/mac` + `cd /Users/mac`) ✅
- §3.34.40 v3 UNION 매칭: FRESH 6개 (31457/31447/31451/31456/31455/31454), 이미 발행 6개 (31449/31437/31448/31458/31450/31443) — 31450은 pt/state 양쪽 splice 누락이라 라이브 페이지 검증으로만 catch 가능
- §3.34 #21 AI/ML 우선 + §3.34.45 매트릭스 분기 4 ("FRESH AI/ML + 비-기타 혼재 → AI/ML 점수 1순위 픽") 정상 동작
- §3.34.46 gn-fetch-content 영구화 API 직접 호출 (`_try_md_endpoint(31454)`) → status=200, **9347 bytes**
- §3.34.47 격리 빌드 (`/tmp/tistory_drafts_273rd/build_draft_31454.py`, 6893 bytes) → 정상
- §3.34.48 `* ` 들여쓰기 분기 적용 (이번 본문엔 hit 없음, 안전 가드)
- §3.34.50 Topic Body 마커 기반 본문 추출 정상 (body_md 8625자) — 260차 정착 skip 로직이었다면 본문 bullet까지 잘라내 67 bytes로 떨어졌을 케이스
- §3.11 post_publish_sync: `pt_updated: true / state_updated: true / errors: [] / triple_signal_match: true` 보고
- §3.5 5중 신호 5/5 `#1015` 일치 (`all_match: True`)
- cleanup cron 임무 #16 dry-run: `✅ 누설 없음`

## §3.34.40 v3 (NEW, 273차 식별) — 라이브 페이지 검증 보강

### 문제 정의
271차 §3.34.44 슬롯 덮어쓰기 drift 케이스에서 `pt.last.gn_topic_id=31450` 이 박혀있었으나 **pt.details엔 31450이 splice 누락**된 채로 외부 발행 흔적 (`state.last_published_url=#1013 + 31458`) 이 박힘. 272차 §3.34.40 v2 (`pt.last.gn_topic_id` 를 pub set 에 추가) 로 guard 보강했으나, **273차 검증 결과 31450 (Bonsai 27B, 라이브 페이지 #1013에 정상 점유 중) 이 여전히 FRESH 로 분류**됨.

### root cause
- pt.details: 31450 항목 splice 누락 (271차 publish 후 sync가 details에 append 안 함)
- state.details: 31450 항목 부재 (271차 publish 시 state.last 가 외부 발행 흔적인 31458 으로 박혀있어 sync가 우리 publish 무시)
- pt.last.gn_topic_id: 31450이 아닌 31443 (다음 cron 차의 publish가 last를 덮어씀)
- state.last.gn_topic_id: 빈 값

⇒ v2 guard는 `pt.last.gn_topic_id` 만 추가했으므로 31450을 catch 못함. **state.last_published_url 로 라이브 슬롯 #N 의 실제 점유자를 알 수 있는 유일한 단서는 라이브 페이지 직접 GET.**

### 회피 패턴 (v3 UNION 매칭)

```python
import json, requests, re
pt = json.load(open('/Users/mac/.hermes/memory/published_topics.json'))
state = json.load(open('/Users/mac/.hermes/memory/blog_pipeline_state.json'))

# 1. pt_gn_set: pt.details 전체 + pt.last.{topic, gn_topic_id, topic_id}
pt_gn_set = set()
for d in pt.get('details', []):
    for k in ['topic', 'topic_id', 'gn_topic_id']:
        if k in d and str(d[k]).isdigit():
            pt_gn_set.add(str(d[k]))
for k in ['topic', 'gn_topic_id', 'topic_id']:
    v = str(pt.get('last', {}).get(k, '') or '')
    if v.isdigit(): pt_gn_set.add(v)

# 2. state_gn_set: state.details 전체 + state.last.{topic, gn_topic_id, topic_id}
state_gn_set = set()
for d in state.get('details', []):
    for k in ['topic_id', 'gn_topic_id', 'topic']:
        if k in d and str(d[k]).isdigit():
            state_gn_set.add(str(d[k]))
for k in ['topic', 'gn_topic_id', 'topic_id']:
    v = str(state.get('last', {}).get(k, '') or '')
    if v.isdigit(): state_gn_set.add(v)

# 3. LIVE_VERIFIED: 라이브 페이지 직접 GET으로 마지막 N개 슬롯의 실제 gn_topic_id 확보
LIVE_VERIFIED = set()
last_url = state.get('last_published_url', '')
# /manage/newpost 마지막 슬롯 / 마지막 5개 슬롯 검증
# 또는 자동화 워크플로에서: 직전 publish 의 entry_id 부터 거꾸로 5개 슬롯 검증
for entry_id_offset in range(0, 5):
    if not last_url:
        break
    try:
        entry_id = int(last_url.rstrip('/').split('/')[-1]) - entry_id_offset
        if entry_id < 1: break
        r = requests.get(f'https://sigco.tistory.com/{entry_id}', timeout=15)
        if r.status_code == 200:
            # 본문 안의 "GeekNews #N" 또는 "news.hada.io/topic?id=N" 링크 패턴 추출
            m = re.search(r'news\.hada\.io/topic\?id=(\d+)', r.text)
            if m:
                LIVE_VERIFIED.add(m.group(1))
            elif '외부 발행' in r.text or 'GeekNews에 공유' not in r.text:
                # 외부 발행 슬롯 — gn_topic_id 추출 불가, 그대로 skip
                pass
    except Exception:
        pass

# 4. v3 UNION
union = pt_gn_set | state_gn_set | LIVE_VERIFIED
fresh = [c for c in candidates if c not in union]
```

### v3 적용 결과 (273차)
- v2 guard (union without LIVE): FRESH 7개 (31457/31447/31450/31451/31456/31455/31454) → 31450 잘못 포함
- v3 guard (union with LIVE_VERIFIED): FRESH 6개 (31457/31447/31451/31456/31455/31454) → 31450 정확 제외

### 라이브 페이지 검증 비용 분석
- 5개 슬롯 × HTTP GET 15초 timeout = 최대 75초 (병렬 호출 시 ~20초)
- drift 케이스는 한 차에 한 건 — 정상 차엔 LIVE_VERIFIED가 비어있어 비용 없음
- 권장: 매 차가 아닌 **§3.5 5중 신호 불일치 또는 state.last_published_url drift 감지시만** 라이브 페이지 검증 1회 수행

### 영구화 권장 (cleanup cron 임무 #30)
- cleanup 스크립트: `scripts/post_publish_sync_repair.py` (NEW, 273차 권장)
- publish 직후 `state.details` 마지막 항목의 url과 라이브 페이지의 `entryId` 일치 확인 + 라이브 본문에서 gn_topic_id 추출 → `pt.details` 에 누락 발견시 splice 자동 보정
- 273차엔 권장만 — 다음 차 cleanup cron 자동화에서 패치

## §3.34.51 (NEW, 273차 식별) — post_publish_sync stats 누락 실전 2호

### 문제 정의
`post_publish_sync.py sync` 호출 결과가 `{pt_updated: true, state_updated: true, errors: [], triple_signal_match: true}` 모두 OK로 보고했으나, **state.daily_counts['2026-07-15']['AI/ML'] +1 누락 + state.details[-1] 미append**. 243차 §3.34.39 (c) sync 함정 실전 2호 (1호는 243차 식별 자체).

### root cause
- `post_publish_sync.py sync` 코드가 `state['last_published_url']` + `state['last']` + `state['last_published_id']` 3필드는 갱신하지만 **state.details append + state.daily_counts +1 두 필드 누락**
- `triple_signal_match: true` 는 `state.last_published_url` + `state.last.url` + `state.details[-1].url` 비교인데 — **state.details[-1]가 직전 차 발행 항목 그대로** 라서 일치하는 것처럼 보임 (실제로는 우리 publish가 details에 안 박혔는데 "이전 details[-1]의 url"과 "새 last_published_url"이 다름 → `triple_signal_match: false` 가 되어야 정상이지만…)

### 회피 패턴 (§3.11 5-1 stats 보정 heredoc — 191차 정착 보강, 273차 재확인)

post_publish_sync 후 **반드시 직접 보정**:

```bash
env -i HOME=/Users/mac PATH=/usr/bin:/bin PWD=/Users/mac /usr/bin/python3 << 'PYEOF'
import json
from datetime import datetime, timezone, timedelta
KST = timezone(timedelta(hours=9))
now = datetime.now(KST)
today = now.strftime('%Y-%m-%d')

state_path = '/Users/mac/.hermes/memory/blog_pipeline_state.json'
state = json.load(open(state_path))

# publish 시점 기준으로 보정 (publish 시점이 7/15 자정 무렵이면 7/15 stats에 박아야)
pub_date = "2026-07-15"  # ← publish URL #1015 의 실제 발행 일자
if pub_date not in state.setdefault('daily_counts', {}):
    state['daily_counts'][pub_date] = {}
prev_ai = state['daily_counts'][pub_date].get('AI/ML', 0)
state['daily_counts'][pub_date]['AI/ML'] = prev_ai + 1

# state.details에 #1015 entry append (sync가 누락)
new_entry = {
    'topic_id': 31454,
    'title': '소프트웨어가 세상을 먹어 치웠고, ...',
    'url': 'https://sigco.tistory.com/1015',
    'date': '2026-07-15',
    'category': 'AI/ML',
    'category_id': 1219746,
    'gn_topic_id': 31454,
    'source_url': 'https://news.hada.io/topic?id=31454',
    'topic': '31454',
}
state.setdefault('details', []).append(new_entry)

# 7/16 등 다른 날짜에 잘못 박힌 stats 정리
if today != pub_date and today in state['daily_counts'] and 'AI/ML' in state['daily_counts'][today]:
    cur_today_ai = state['daily_counts'][today]['AI/ML']
    if cur_today_ai >= 1:
        state['daily_counts'][today]['AI/ML'] = max(0, cur_today_ai - 1)

# 저장
with open(state_path, 'w', encoding='utf-8') as f:
    json.dump(state, f, ensure_ascii=False, indent=2)
PYEOF
```

### 검증
- 보정 전: `state.daily_counts['2026-07-15']['AI/ML'] = 7` (sync 후 +1 누락)
- 보정 후: `state.daily_counts['2026-07-15']['AI/ML'] = 8` (정확, +1)
- `state.details[-1]` = `{topic_id: 31454, url: 'https://sigco.tistory.com/1015', ...}` (append 정상)
- §3.5 5중 신호 5/5 일치 (`all_match: True`)

### 영구화 권장 (cleanup cron 임무 #31)
- `scripts/post_publish_sync.py` 자체 패치: `sync` 함수가 `state['details'].append(new_entry)` + `state['daily_counts'][pub_date][category] += 1` 두 줄 명시 추가
- 273차엔 권장만 — sync 스크립트는 core utility라 영구화 시 cron 자동화 워크플로 외 영향 점검 필요
- 임시 회피: §3.11 5-1 stats 보정 heredoc 매 차 직접 호출

## 결론

- **연속 all-green 60회차 (213~273차)** — 가짜 발행 가드 정상
- **본 세션 신규 발견 2건**: §3.34.40 v3 + §3.34.51
- **기존 패턴 정상 동작**: §3.8.1, §3.8.2, §3.11 (sync 후 보정 필요), §3.34.40 v2, §3.34.43, §3.34.46, §3.34.47, §3.34.48, §3.34.49, §3.34.50, §3.34 #21 + §3.34.45 매트릭스, cleanup #16
- **cleanup cron 임무 신규 2건**: #30 (v3 라이브 페이지 보강 자동화) + #31 (sync 스크립트 자체 패치)
- **차감/추가 없음** — 모든 기존 패턴 정착 유지