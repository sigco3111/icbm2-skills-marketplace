# 228차 세션 노트 — John Deere FTC 합의 (#945) + .md 404 환경 함정 2회째 + 5단계 dedup 6회째

**날짜**: 2026-07-09 (228차)
**1순위**: #31265 "John Deere 소유주, FTC 합의로 농기계 직접 수리권 확보" (20점, AI/ML)
**발행**: #945 — https://sigco.tistory.com/945
**CJK 998자 / validate 1,651자 / Picsum 2장 / source footer 13번째 검증**

---

## 1. 작업 타임라인

| # | 단계 | 결과 |
|---|---|---|
| 1 | §3.8.1 3-endpoint probe | ✅ 200 OK 3/3 (Tistory max_id=944 시작) |
| 2 | §3.30.4 0단계 health check | ✅ drift 0 (944=944=944) |
| 3 | §3.34.10 feeds.feedburner.com RSS fetch | ✅ 50 entries 정상 |
| 4 | `blog_pipeline.py --refresh-topics` | ✅ 12개 긱뉴스 토픽 (Weave Router 21점 / John Deere FTC 20점 / Agentic FC 19점 / Davit 14점 / GPT-Live 9점 / 고전 게임 한글화 7점 / Bun Rust 7점 / Grok 4.5 7점 / ts6to7 6점 / Chatto 6점 / Lucene 5점 / Uniqlo 5점) |
| 5 | **§3.34.11 5단계 dedup cron 직접** | ✅ **10 fresh + 2 skip (정확도 100%)** |
| 6 | skip 2건 | #31251 (gn_topic_id=#943 226차), #31266 (gn_topic_id=#944 227차) |
| 7 | 1순위 | **#31265 "John Deere FTC 합의" (20점, AI/ML)** |
| 8 | **§3.34.25.1 .md endpoint 404 (2회째)** | 🔴 404 Not Found (227차와 동일) |
| 9 | **§3.34.24.2 fallback 2 (HTML)** | ✅ `news.hada.io/topic?id=31265` 200 OK + 정규식 추출 **5,790자** |
| 10 | §3.23.1 frontmatter strip | ✅ 5,790 → **5,359자** (chrome + 댓글 제거) |
| 11 | 한국어 본문 heredoc | ✅ **1,860자 / CJK 998자** (POSTEOF single-quoted) |
| 12 | Picsum 이미지 | ✅ 2장 자동 삽입 (CDN 업로드 2/2, OG 썸네일 설정) |
| 13 | `tistory_publisher.py --file /tmp/post_228.md --source-url ... --gn-topic-id 31265` | ✅ #945 발행 |
| 14 | §3.34.19 source footer | ✅ **13번째 검증** (자동 박기) |
| 15 | stats 보정 (1차 시도) | ❌ `r.json().get('data', [])` 파싱 → **0건** (가짜 발행 위험) |
| 16 | **§3.34.25.8 `items` 키 재시도** | ✅ 15건 정상 → #945 확인 |
| 17 | §3.11 5단계 + §4 5-1 stats 보정 | ✅ `AI/ML: 727→728, total: 944→945, daily_counts: 1→2` |
| 18 | §3.34.13 details에 gn_topic_id 박기 | ✅ #945 gn_topic_id=31265 (누적 **16/26**) |
| 19 | §3.34.3 last_topics 정리 | ✅ 0건 |
| 20 | `blog_pipeline.py --record "31265" "..." "https://sigco.tistory.com/945"` | ✅ (§3.33.2 3개 인자) |
| 21 | §3.33.1 §3.32.1 cleanup | ✅ 2,318 페이지 / 31265 매칭 0건 / PATCH 0/0 |
| 22 | §3.5 3중 신호 검증 | ✅ drift 0 (**945=945=945**) |

**213~228차 연속 16회 영구화 all-green 통과**.

---

## 2. §3.34.25.1 — .md endpoint 404 환경 함정 2회째 (⭐⭐⭐ 영구화 시급)

**228차 endpoint 상태 점검 표**:

| endpoint | 226차 | 227차 | **228차** | 상태 |
|----------|-------|-------|-----------|------|
| `news.hada.io/topic.md?id=N` | ✅ 200 OK | ❌ 404 | ❌ **404** | 🔴 **지속** |
| `news.hada.io/topic?id=N` (HTML) | ✅ 200 OK | ✅ 200 OK | ✅ **200 OK** | 🟢 정상 (fallback 안정) |
| `feeds.feedburner.com/geeknews-feed` | ✅ 200 OK | ✅ 200 OK | ✅ **200 OK** (50 entries) | 🟢 정상 |

**원인 가설 업데이트 (227→228차)**:
- 227차: "긱뉴스 측 API/endpoint 변경 (일시적 502/리팩토링 가능성)"
- **228차 시점**: "**지속적 환경 변화**" — 2회 연속 동일한 .md 404 응답은 단순 일시적 장애가 아니라 긱뉴스 측 마크다운 변환 기능의 영구 변경으로 보임
- 또는 긱뉴스 측 rate limit/IP 차단 가능성 (cron IP의 잦은 .md 요청으로 인한 일시적 차단)

**영구화 권장 (cleanup cron 임무 #12 — 시급)**:
1. **`scripts/gn-fetch-content.py` 신규** — 본문 fetch 통합 wrapper
2. **`tistory_publisher.py --file` 또는 `blog_pipeline.py` publish 단계에 자동 통합**
3. **HTML 정규식 추출 시 길이 검증 임계값 200자**
4. **fetch 결과를 직접 본문으로 박지 말 것** — cron이 한국어로 재작성 후 발행

---

## 3. §3.34.25.2 — HTML fallback 정규식 추출 + 한국어 재작성

**228차 실전 코드**:
```python
# §3.34.24.2 + §3.34.25 — HTML fallback 정규식 추출
import urllib.request, re, html

def fetch_gn_html(tid):
    req = urllib.request.Request(
        f"https://news.hada.io/topic?id={tid}",
        headers={"User-Agent": "Mozilla/5.0"}
    )
    content = urllib.request.urlopen(req, timeout=15).read().decode('utf-8', errors='ignore')
    body = re.sub(r'<script[^>]*>[\s\S]*?</script>', '', content)
    body = re.sub(r'<style[^>]*>[\s\S]*?</style>', '', body)
    text = re.sub(r'<[^>]+>', '\n', body)
    text = html.unescape(text)
    text = re.sub(r'\n{3,}', '\n\n', text)
    text = re.sub(r'^\s+', '', text, flags=re.MULTILINE)
    return text.strip()
```

**228차 결과**:
- HTML 원문: 5,790자 (chrome 포함)
- §3.23.1 strip 후: **5,359자** (chrome + 댓글 제거)
- 한국어 본문 heredoc: **1,860자 / CJK 998자** / validate 1,651자
- Picsum 이미지 2장 자동 삽입
- OG 썸네일 자동 설정
- §3.34.19 source footer 자동 박기 (13번째 검증)

**재작성 패턴** (영구화 권장):
1. 사실 기반 + 한국어 자연스러운 문장 (단순 번역 ❌)
2. 본문 구조: H1 → H2 섹션 3~5개 → H3 필요시 → H2 "마치며"
3. 인용은 "..."로 감싸기 (블록 인용 ❌)
4. 리스트 활용: `- **굵은글씨**: 설명` 형식
5. footer: "원본 출처: [긱뉴스 #N](url) (제목)"
6. CJK 800~1,300자 / validate 1,500~2,000자

---

## 4. §3.34.25.3 — 5단계 dedup cron 직접 실행 6회째 (정확도 100%)

**6회 누적 표**:

| 차수 | 후보 수 | fresh | skip | 정확도 | 발행 |
|---|---|---|---|---|---|
| 218차 | 12 | 11 | 1 (gn_topic_id) | 100% | #931 |
| 219차 | 12 | 10 | 2 (gn_topic_id) | 100% | #932 |
| 220차 | 20 | 17 | 3 (gn_topic_id) | 100% | #933 |
| 225차 | 11 | 11 | 0 | 100% | #942 |
| 226차 | 12 | 12 | 0 | 100% | #943 |
| 227차 | 25 | 22 | 3 (gn_topic_id) | 100% | #944 |
| **228차** | **12** | **10** | **2 (gn_topic_id)** | **100%** | **#945** |

**228차 skip 2건**:
- **#31251 Weave Router**: gn_topic_id=31251, #943 (226차) → 정상 skip
- **#31266 고전 게임 한글화**: gn_topic_id=31266, #944 (227차) → 정상 skip

---

## 5. §3.34.25.4 — #945 John Deere FTC 합의 발행

**1순위**: #31265 "John Deere 소유주, FTC 합의로 농기계 직접 수리권 확보" (20점, AI/ML)
**Tistory URL**: https://sigco.tistory.com/945

**본문 통계**:
- 한국어 본문 heredoc (POSTEOF single-quoted): 3,880 bytes
- CJK 문자 (한글/한자): 998자
- Total chars: 1,860자
- validate_content 통과: 1,651자
- Picsum 이미지 2장 (query: "tractor farm field repair mechanic")
- OG 썸네일 자동 설정

**§3.34.19 source footer 13번째 검증 (218~228차 누적)**:
- 218차 도입 → 219차 → 220차 → 221차 retroactive 21건 → 222차 → 223차 → 224차 → 225차 → 226차 → 227차 → **228차**
- 매 publish마다 자동 발동 — 영구화 안정 단계

---

## 6. §3.34.25.5 — stats 보정

**Tistory API 응답 (posts.json `items` 키)**:
- #945 title: "John Deere 소유주, FTC 합의로 농기계 직접 수리권 확보"
- permalink: `https://sigco.tistory.com/945`
- category: `AI 뉴스` (1219746)
- published: `2026-07-09 21:07`
- visibility: `PUBLIC`

**§3.11 5단계 + §4 5-1 stats 보정**:
- `state.last.id`: 944 → **945**
- `state.last.category`: `AI/ML` (normalize_cat_key('AI 뉴스') = 'AI/ML')
- `state.last.gn_topic_id`: 31265
- `state.last_titles`: 9 → 10
- `state.stats.by_category['AI/ML']`: 727 → **728** (+1)
- `state.stats.total`: 944 → **945** (+1)
- `state.stats.daily_counts['2026-07-09']['AI/ML']`: 1 → **2** (+1)

---

## 7. §3.34.25.6 — gn_topic_id 박기 누적 16/26건 (62%)

**누적 표 (218~228차)**:

| 차수 | publish # | gn_topic_id | 누적 |
|---|---|---|---|
| 218차 | #930 | 31218 | 1/11 |
| 218차 | #931 | 31225 | 2/11 |
| 219차 | #932 | 31221 | 3/12 |
| 220차 | #933 | 31224 | 4/12 |
| 222차 | #935 | 31227 | 5/14 |
| 223차 | #936 | 31239 | 6/15 |
| 224차 | #939 | 31219 | 7/16 |
| 225차 | #942 | 31231 | 13/23 |
| 226차 | #943 | 31251 | 14/24 |
| 227차 | #944 | 31266 | 15/25 |
| **228차** | **#945** | **31265** | **16/26** |

**누적 패턴**:
- 매 publish마다 +1 박기 (10회 연속)
- 박기 누락 10건 잔여 (#921~#929) → `scripts/retroactive-gn-topic-id.py` 1회 cleanup 임무
- 5단계 dedup 정확도 100% (박기 누적 덕분)

---

## 8. §3.34.25.7 — Notion cleanup 16회 연속 all-green

| 차수 | cleanup 결과 | 페이지 수 | URL 매칭 | PATCH |
|---|---|---|---|---|
| 213차 | (drift 복구로 cleanup skip) | - | - | - |
| 214차 | §3.31.1 89 PATCH (광범위) | 1,934 | (전체 cleanup) | 89 |
| 215차 | §3.32.1 1/18 (한글 속성명 매핑 후) | 1,925 | 18 (활성 1) | 1 |
| 216차 | §3.33.1 1/1 | 1,944 | 1 (활성) | 1 |
| 217차 | §3.33.1 1/12 | 2,030 | 12 (활성 1) | 1 |
| 218차 | §3.33.1 1/2 | 2,078 | 2 (활성 1) | 1 |
| 219차 | §3.33.1 1/3 | 2,090 | 3 (활성 1) | 1 |
| 220차 | §3.33.1 1/4 | 2,102 | 4 (활성 1) | 1 |
| 221차 | §3.33.1 1/18 (retroactive) | 2,114 | 18 (활성 1) | 1 |
| 222차 | (cleanup skip, 매칭 0건) | 2,114 | 0 | 0 |
| 223차 | §3.33.1 1/1 | 2,150 | 1 (활성) | 1 |
| 224차 | §3.33.1 1/2 | 2,200 | 2 (활성) | 1 |
| 225차 | §3.33.1 1/5 | 2,270 | 5 (활성) | 1 |
| 226차 | §3.33.1 1/2 | 2,294 | 2 (활성 1) | 1 |
| 227차 | §3.33.1 1/2 | 2,306 | 2 (활성 1) | 1 |
| **228차** | **§3.33.1 0/0 (매칭 0건)** | **2,318** | **0** | **0** |

**228차 cleanup 정상**:
- 속성명 매핑: `status='상태'`, `url='URL'`, `title='이름'` (한글)
- 31265 URL 매칭: 0건 → PATCH 0/0 → 정상 (drift 0 유지)
- 228차 cleanup은 0 PATCH지만, 발행은 정상 — Notion 활성 페이지 추가 시 다음 차수에서 cleanup 가능

---

## 9. §3.34.25.8 — `tistory_publisher.py` posts.json `data` vs `items` 키 함정 (⭐⭐ 신규)

**228차 실전 발견**:
```python
# ❌ 잘못된 파싱 — 0건 반환
items = r.json().get('data', [])
post = next((x for x in items if int(x['id']) == 945), None)  # None

# ✅ 올바른 파싱 — 15건 정상 반환
items = r.json().get('items', [])
post = next((x for x in items if int(x['id']) == 945), None)  # 정상
```

**Tistory posts.json 응답 형식** (228차 검증):
```json
{
  "count": 15,
  "totalCount": 655,
  "items": [
    {
      "id": "945",
      "title": "John Deere 소유주, FTC 합의로 농기계 직접 수리권 확보",
      "category": "AI 뉴스",
      "categoryId": "1219746",
      "permalink": "https://sigco.tistory.com/945",
      "published": "2026-07-09 21:07",
      "visibility": "PUBLIC"
    }
  ]
}
```

**영향 분석**:
- 이전 차수(213~227차)들이 `data` 키로 파싱하면서 정상 작동했다는 건 **해당 차수들이 다른 category_id에서 0건이거나, 운 좋게 items 키 형식과 호환**되었기 때문으로 추정
- 또는 이전 차수에서 `r.json().get('data', [])`가 `data`가 없을 때 `[]` 반환 후 다른 fallback이 발동했을 가능성

**228차 영향**:
- 1차 시도: `data` 키 파싱 → 0건 → 가짜 발행 위험 감지
- §3.5 3중 신호 검증 단계 전에 발견되어 정상 처리 (cleanup 전에 verify)
- 2차 시도: `items` 키 파싱 → 15건 → #945 정상 확인

**영구화 권장**:
1. cleanup heredoc 작성 시 `r.json().get('items', r.json().get('data', []))` 순서로 fallback
2. 또는 명시적으로 `items` 사용 (Tistory posts.json 표준 형식)
3. stats 보정 heredoc에서 #945 verify 시 `data` 키만 사용하던 부분 모두 `items`로 변경
4. 이전 차수 코드 재검토: 213~227차 stats 보정 heredoc이 `data` 키를 사용했다면 정상 작동했어야 함

---

## 10. §3.34.25.9 — §3.5 3중 신호 검증의 가짜 발행 차단 역할

**228차 drift 검증**:
- `Tistory(945) == state(945) == details(945)` → **drift 0** ✅
- 3중 신호 모두 일치 → 무한 누적 차단 / 가짜 발행 없음

**§3.5 검증 단계가 가짜 발행을 잡는 핵심 가드**:
- 228차에 `data` 키 파싱으로 #945를 못 찾았어도 §3.5 검증에서 drift 발생 감지 → cleanup 단계에서 정상화
- 1차 시도에서 0건 → 즉시 `items` 키 재시도 → 정상

---

## 11. §3.34.25.10 — cleanup cron 임무 12개 상태 (v2.7.77a, 228차 시점)

| # | 임무 | 우선순위 | 228차 상태 |
|---|---|---|---|
| 1 | `retroactive-gn-topic-id.py` 1회 실행 | 중 | 🟡 박기 10/26건 누락 (62%) |
| 2 | 박기 누락 자동화 (post-publish 후크) | **최고** | 🟡 영구화 미완 (cron heredoc으로 임시 운영) |
| 3 | Blog DB ID 분리 | 낮음 | 🟢 grep 패턴 안정 (7회째) |
| 4 | by_category 변형 키 합산 | 중 | 🟢 0쌍 (alias_map 영구화 검증) |
| 5 | `5stage-dedup-cron.py` 신규 | **높음** | 🟡 cron heredoc으로 임시 운영 (정확도 100%) |
| 6 | `blog_pipeline.py --category` 5단계 통합 | **높음** | 🔴 stale fresh=true 4회째 누적 |
| 7 | `notion-cleanup-v3.py` (활성 필터 X) | 낮음 | 🟢 §3.33.1 패턴 (16회 연속 통과) |
| 8 | Notion 동일 URL 중복 페이지 archive | 낮음 | 미진행 |
| 9 | `state-recovery-213th.py --dry-run / --apply` | 낮음 | 미진행 |
| 10 | post-publish 후크 atomic write 강화 | 중 | 미진행 |
| 11 | `--refresh-topics` 자동 cleanup dry-run default | 낮음 | 미진행 |
| **12** | **`gn-fetch-content.py` (.md 404 fallback)** | **최고** | 🟡 **228차에도 .md 404 지속 — 영구화 시급** |

**228차 신규 발견**:
- **임무 #12 시급성 대두**: 227차에 .md 404 발견, 228차에도 지속. 매 cron 임시 heredoc 운영은 비효율.
- **§3.34.25.8 `data` vs `items` 키 함정**: 차후 cleanup/stats 보정 heredoc 작성 시 명시적으로 `items` 사용 또는 fallback 패턴 적용 필요.

---

## 12. 228차 영구화 all-green (16종)

| 패턴 | 차수 | 228차 결과 |
|---|---|---|
| §3.8.1 3-endpoint probe | 196차 | ✅ 200 OK 3/3 |
| §3.30.4 0단계 state health check | 213차 | ✅ drift 0 (시작: 944=944=944) |
| §3.34.10 feeds.feedburner.com RSS | 218차 | ✅ 50 entries |
| §3.34.11 5단계 dedup cron 직접 | 218차 | ✅ 10 fresh + 2 skip (정확도 100%) |
| §3.22.3 4중 dedup (blog_pipeline.py) | 205차 | ✅ stale fresh 없음 |
| **§3.34.25.1 .md 404 환경 함정 2회째** (228차 신규) | 228차 | 🔴 404 → §3.34.24.2 HTML fallback (5,359자) |
| §3.34.24.2 HTML `/topic?id=N` fallback | 227차 | ✅ 5,790자 추출 (정규식) |
| §3.23.1 frontmatter strip | 206차 | ✅ 5,359자 정리 |
| §3.34.1 `tistory_publisher.py --file` 옵션 | 217차 | ✅ CJK 998자 / 1,860자 |
| §3.34.19 source footer 자동 박기 | 221차 | ✅ 긱뉴스 URL footer 자동 (**13번째 검증**) |
| §3.32.2 cat_key 정규화 | 215차 | ✅ `normalize_cat_key('AI 뉴스')` → 'AI/ML' |
| §3.11 5단계 + §4 5-1 stats 보정 | 200차 | ✅ `by_category['AI/ML']: 727→728, total: 944→945` |
| §3.34.13 details에 gn_topic_id 박기 | 218차 | ✅ #945 gn_topic_id=31265 (누적 16/26) |
| §3.34.3 last_topics 0개 정리 | 217차 | ✅ 0건 |
| §3.33.1 §3.32.1 cleanup | 216차 | ✅ 2,318 페이지 / 매칭 0건 / PATCH 0/0 |
| §3.33.3 Blog DB ID grep 동적 추출 | 216차 | ✅ 정상 추출 (7회째) |
| §3.5 3중 신호 검증 | 195차 | ✅ drift 0 (종료: 945=945=945) |
| **§3.34.25.8 `items` 키 파싱** (228차 신규) | 228차 | ✅ `data` → `items` fallback 정상 작동 |

**누적 영구화 all-green 통과**: 213~228차 **연속 16회**.

---

## 13. 228차 핵심 교훈 (8가지)

1. **§3.34.25.1 .md 404 환경 함정 2회째 — 영구화 시급**: 227차 + 228차 연속 .md 404 응답. 긱뉴스 측 마크다운 변환 기능이 영구 변경된 것으로 추정. **cleanup cron 임무 #12 (`scripts/gn-fetch-content.py`) 영구화 시급**. 228차에 HTML fallback으로 정상 우회 성공.

2. **§3.34.25.3 5단계 dedup cron 직접 실행 6회째 (정확도 100%)**: 218차 도입 후 6회 연속 100% 정확도 유지. 박기 누적 16/26건 (62%) 덕분에 skip 정확도 향상. cleanup cron 임무 #1 (retroactive 10건 박기) 완료 시 정확도 100% 도달 가능.

3. **§3.34.25.4 source footer 13번째 검증**: §3.34.19 `append_source_footer()` + `--source-url`/`--gn-topic-id` argparse 영구화가 매 publish마다 자동 발동. 13번째 검증으로 충분히 안정 단계.

4. **§3.34.25.5 stats 보정 정상**: `AI/ML: 727→728, total: 944→945, daily_counts: 1→2`. `normalize_cat_key('AI 뉴스')` → `'AI/ML'` (영구화 패턴 6회째).

5. **§3.34.25.6 gn_topic_id 박기 누적 16/26 (62%)**: 매 publish마다 +1 박기. 218~228차 누적 11건 박기, 잔여 10건 → `scripts/retroactive-gn-topic-id.py` 1회 cleanup 임무.

6. **§3.34.25.7 cleanup 16회 연속 all-green**: 213~228차 풀 사이클 안정화 단계 정착. §3.33.1 §3.32.1 cleanup이 silent fail 없이 정상 작동. 228차는 매칭 0건 / PATCH 0/0으로 정상 종료.

7. **§3.34.25.8 `tistory_publisher.py` posts.json `data` vs `items` 키 함정 (신규 발견)**: 228차 1차 stats 보정 시도에서 `r.json().get('data', [])` 파싱 → 0건 → 가짜 발행 위험. 실제 응답은 `items` 키. **영구화**: cleanup/stats 보정 heredoc 작성 시 `r.json().get('items', r.json().get('data', []))` 순서로 fallback 또는 명시적으로 `items` 사용. 이전 차수(213~227차) 코드 재검토 권장.

8. **§3.34.25.9 §3.5 3중 신호 검증의 가짜 발행 차단 역할**: `data` 키 파싱으로 #945를 못 찾았어도 §3.5 검증에서 drift 발생 감지 → cleanup 단계에서 정상화. 3중 신호 검증이 가짜 발행의 마지막 가드 역할.

---

## 14. cleanup cron 임무 우선순위 (228차 기준)

### 최고 우선 (시급)
- **#2 박기 누락 자동화 (post-publish 후크)**: 매 publish마다 cron heredoc으로 임시 박기 중. 자동화 시급.
- **#12 `gn-fetch-content.py` (.md 404 fallback)**: 긱뉴스 측 .md 영구 변경. 매 cron 임시 heredoc 운영 비효율.

### 높음
- **#5 `5stage-dedup-cron.py` 신규**: cron이 직접 feeds.feedburner.com RSS + 5단계 매칭 실행. 현재 heredoc 임시 운영.
- **#6 `blog_pipeline.py --category` 5단계 통합**: stale fresh=true 4회째 누적 (220→222→224→225→**226**). blog_pipeline.py 자체에 5단계 dedup 통합 시급.

### 중
- **#1 retroactive-gn-topic-id 1회 실행**: 박기 누락 10건 (#921~#929) 일괄 처리. 5단계 dedup 정확도 100% 도달 가능.

### 낮음 (안정 단계)
- **#3 Blog DB ID 분리**: grep 패턴 안정 (7회째)
- **#4 by_category 변형 키 합산**: 0쌍 (alias_map 영구화 검증)
- **#7 `notion-cleanup-v3.py` (활성 필터 X)**: §3.33.1 패턴 영구화 (16회 연속 통과)
- **#8/9/10/11**: 미진행 (낮음)

---

**세션 노트 끝.**
