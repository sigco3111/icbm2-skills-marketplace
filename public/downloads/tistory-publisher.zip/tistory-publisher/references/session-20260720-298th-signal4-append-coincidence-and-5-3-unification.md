# 298차 세션 노트 (2026-07-20 02:02)

## 핵심 결과
- **발행 1건 정상**: `#1049` (AI/ML, 긱뉴스 #31571 "100만 개 키워드가 보여준, AI가 검색에 미치는 영향")
- §3.8.1 raw VALID + §3.5 깨끗 + 295차 정책으로 발행 진행
- 연속 all-green 78회차

## 신규 발견 3건

### 1. §3.5 신호 4 오탐 케이스 (CANONICAL 판정 절차 격상)
- 정상 publish + 5-3 (last_published_url+id+details append 동시 갱신) 후 §3.5 신호 4가 발동함
- 원인: 신호 4 로직이 `details[-1].slot == last_url.slot` 단순 비교 — 같은 차에 두 필드를 동시에 #NNN으로 갱신하면 무조건 발동
- **disambiguate 절차 확립**: 5-5 proxy check (status=200 + og:title 매칭) 통과 시 가짜 발행 아님 → 신호 4 무시 가능
- 진짜 FAKE_PUBLISH는 비대칭 패턴 (details[-1]이 진짜 stale 슬롯인데 last_url만 #NNN으로 갱신) — proxy check status=404/302 또는 og_title 불일치로 구분
- SKILL.md §5-3에 명시 추가, 향후 check_state_consistency.py 신호 4 로직 개선 시 참고

### 2. 5-3 표준 보정에 details append 통합 (293차 함정 4 해소)
- 기존: 5-3은 last_published_url + last_published_id 두 필드만, details append는 별도 단계 (사용자 게이트 필요)
- 298차: 5-3에 details append 통합 → 정상 publish 후 5-3 한 번 실행으로 세 필드 동기화
- 안전성: 진짜 가짜 발행 잔재 시엔 §3.5 신호 4가 publish 전후에 발동하므로 publish skip이 우선 — 5-3의 details append는 정상 publish + commit_publish 완료 후에만 실행됨

### 3. 297차 함정 8 (by_category 정수 ID 키 오염) 잔존
- 298차 commit_publish → by_category["1219746"]=1 누적 (AI/ML 카테고리명 norm 대신 int ID가 키로 박힘)
- SSOT 변경이라 사용자 확인 후 보정 권장, 임의 자동 보정 금지 — 매 차 보고 라인에 명시

## 적용된 워크플로우 (298차 실전)
1. §3.8.1 raw 검증 (env -i 격리 모드 오탐 → source tistory.env 후 격리 없이 직접 python3) → status=200 VALID
2. §3.5 baseline (깨끗)
3. 트렌드 새로고침 (12개)
4. AI/ML category → status=ready (topic 31571, timeliness=ok)
5. 빌드 스크립트 `/tmp/build_post_31571.py` → `/tmp/post_31571.html` (OG description 160자 추출, Picsum 이미지 검색용 query)
6. tistory_publisher.py 직접 호출 (CLI 옵션 함정 7 적용: `--category 1219746` int)
7. 응답 stdout에서 `🔗 https://sigco.tistory.com/1049` 추출
8. §3.11 5-2 commit_publish → 5-3 통합 패치 (last+details) → 5-4 §3.5 신호 4 발동(오탐) → 5-5 proxy check status=200+og_title 매칭 → 가짜 발행 아님 확정
9. daily_counts[2026-07-20]={AI/ML:2}, total=43

## SKILL.md 변경 사항
- §5-3 코드 + 절차 확장: last_published_url + last_published_id + details append 한 번에 동기화
- §5-3 후 §3.5 신호 4 오탐 처리 disambiguate 절차 명시 (298차 신규)
- 함정 4 (293차) 항목 갱신: "293차 신규, 298차 해소" — 5-3 통합으로 해결
- 검증 이력에 298차 추가
- 연속 all-green 78회차 (288차+)
