# 343차 (2026-07-30 19:01) — #1144 "Matz가 친절하다"는 사실은 중요하지 않다

**Topic**: "Matz가 친절하다"는 사실은 중요하지 않다 (gn=31963, AI/ML)
**URL**: https://sigco.tistory.com/1144
**Body**: 4,690자 / Picsum 2장 / Python 코드 블록 1개 (code_lines 패턴)
**Counters**: daily_counts={AI/ML:6, 개발도구:1}, total=138
**Status**: 연속 all-green **117회차**

## 발행 트랜잭션 결과

| 단계 | 결과 |
|------|------|
| §3.8.1 가드 | ✅ status=200, first_ids=['1143','1142','1141','1140','1139'] |
| §3-a topic 선정 | ✅ status=ready (gn=31963) |
| OG description 추출 | ✅ "Ruby 커뮤니티의 MINASWAN..." 200자 |
| 빌드 (parts.append 정형) | ✅ bytes=9962, body_chars=4690, images=2, parts=35 |
| sibling write warning | ⚠️ detected (line 81 CJK swap) |
| patch() 복원 | ✅ `자세` → 한국어 원문 |
| 재빌드 후 검증 | ✅ CJK grep 0건 / parts.append count=36 |
| §3-b publish | ✅ URL=https://sigco.tistory.com/1144 |
| §3.11 commit | ✅ stats.today={AI/ML:6, 개발도구:1}, total=138 |
| 5-3 last+details | ✅ #1144, details_len=217 |
| 5-2-A 동기화 | ✅ placeholder 보정 + 누락 백필=1, details_len=218, last.url=#1144 |
| §3.5 신호 4 | ⚠️ 발동 (구조적 오탐 — 정형 37연속) |
| 5-5 proxy check | ✅ status=200 + og:title 정확 매칭 + source_present=True + cjk_suspicious=0 |

## 신규 발견 — 두 가지

### 1. 함정 26 3차 재발 (343차 신규 swap)

sibling write warning이 또 다시 발동. 이번에는 본문 한국어 `자세` (의미: 자세/태도) → 한자 `姿勢`로 자동 치환. 함정 26의 CKJ swap 변형 누적 데이터:

| 차수 | 한국어 | 한자 (자동 치환) |
|------|--------|-----------------|
| 333차 | 입장 | 立场 |
| 342차 | 정기 | 定时 |
| **343차** | **자세** | **姿勢** |

swap 후보 단어 사전이 점점 명확해짐: 동음이의 한자 음차 (한국어 발음 = 한자 다른 의미) 가 swap 대상.

- `자세` (태도) ↔ `姿勢` (자세/몸의 자세) — 한국어 한자어 사전 따라가면 후자지만 보통 `자세` 한국어 단어로 사용
- `정기` (주기) ↔ `定時` (정해진 시간) — 한국어 단어로 더 흔함
- `입장` (의견/태도) ↔ `立场` (입장) — 동일 의미 한자

원칙: 본문이 동음이의 한자 후보 단어를 포함하면 처음부터 grep 패턴을 정형화하거나 다른 표현으로 회피하는 게 안전. CKJ 영역이 본문에 들어가면 sibling write 자동치환 위험 등급 ↑.

### 2. `import re` 누락 → NameError (343차 신규 mini-fall)

빌드 검증 라인 추가하다가 NameError 발견:

```python
from pathlib import Path
from datetime import datetime, timezone, timedelta

# ... 본문 빌드 로직 ...

text_len = len(re.sub(r'<[^>]+>', '', final_html))   # ← NameError: name 're' is not defined
```

`from pathlib import Path`만 import, `re`는 빠짐. 함정 14(`import os` 누락)와 같은 계열이지만:
- `os`는 heredoc 단계 (가드/5-5 검증)에서 자주 등장
- `re`는 빌드 검증 단계 (`re.sub()`로 HTML 태그 제거)에서만 등장

lint는 SyntaxError를 던지지 않고 빌드 시점에 NameError로 실패 → 빌드가 silent 통과되지 않음 (그래서 발견은 즉시 됨). patch()로 `import re` 한 줄 추가 → 정상 빌드.

**정형 원칙**: 빌드 스크립트 첫 줄은 항상 정형 import:

```python
import os, re, requests, sys, json
from pathlib import Path
from datetime import datetime, timezone, timedelta
```

회피 패턴이 아니라 처음부터 안전 import로 통일.

## 함정 회피 7중 동시 (이번 차)

1. **함정 6** — `env -i ... /usr/bin/python3 /usr/bin/python3` 두 번 호출 회피
2. **함정 7** — `--category` int (1219746), `--commit` 카테고리 str ("AI/ML") 정확
3. **함정 8** — by_category["1219746"]=1 영구 잔존 (47차 동일 유지)
4. **함정 11** — `execute_code` cron 차단 회피 (write_file + /tmp 분리)
5. **함정 14 (확장)** — `import re` 누락 NameError → patch 한 줄로 복원
6. **함정 15** — 5-5 proxy check 격리 패턴 정확
7. **함정 26** — sibling write CJK swap (`자세 → 姿勢`) 검출 → patch() 복원

## 누적 카운터 갱신

- 단일 패스 **38연속** (305→343)
- parts.append() 정형 **38연속**
- §3.5 신호 4 disambiguate **37연속 확정** (298→343)
- 진입 5-5 **18연속**
- fallback 복귀 **30연속**
- `--content` 단일 폴백 정형 **6회차 검증** (324→339→340→341→342→343)
- by_category["1219746"] 영구 잔존 **47차 동일 유지** (297→343)

## 관찰

1. **함정 26 swap 후보 단어 사전이 누적** — 동음이의 한자음차 단어가 본문에 들어가면 sibling write 자동치환 위험 등급 ↑.
2. **`import re` 누락은 빌드 시점 즉시 발견** — `os`와 달리 herodoc 단계가 아니라 빌드 단계라 silent 통과 없이 즉시 감지.
3. **본문 4690자 + Python 코드 블록 1개 케이스** — 338차 정형 (3103자 + Python 1개) 의 +50% 확장. parts.append() + code_lines 분리 정형이 추가 분기 없이 lint 정상 통과.
4. **함정 27 (source URL 검사 ≠ publish 후 footer)** — 335차 정형 재확인. publish_post()가 footer 자동 박기.

## 다음 차 운영 보강 (343차 신규 관찰)

- **build_post_NNN.py 첫 줄 import 정형 템플릿** (위 343차 신규 mini-fall 참조).
- **본문 CKJ swap 후보 단어 사전 체크** — `grep -nE '[一-鿿]|[ぁ-ゔ]|[ァ-ヴー]'` 무조건 1회. 후보 사전: 입장/立場, 자세/姿勢, 정기/定時, 자주/自走, 설명/說明, 조사/調査, 자격/資格, 이유/理由, 인사/人事, 인사/印寫, 관심/關心, 지원/支援, 주의/注意, 운동/運動, 이사/理事, 성적/成績.
- **build_post_NNN.py 작성 시 큰 docstring 또는 첫 줄에 정형 import 6개 박기** — lint 단계에서 즉시 검증되어 silent 누락 방지.
