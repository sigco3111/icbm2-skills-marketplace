# 280차 — OpenAI, EU 법원 상표권 분쟁에서 패소 — #1027

**일자**: 2026-07-17
**슬롯**: #1027
**gn_topic_id**: 31484
**제목**: `OpenAI, EU 법원 상표권 분쟁에서 패소 — GPT는 일반 명사가 아니다`
**카테고리**: AI/ML (1219746)
**점수**: 9.0
**본문**: https://news.hada.io/topic?id=31484
**연속 all-green**: **67회차** (213~280차)

## 워크플로 (정상 정착 패턴)

1. **§3.8.1 세션 만료 가드** (격리 패턴 + PWD): `status=200, ct=application/json;charset=UTF-8` → ✅ 정상.
2. **`blog_pipeline.py --refresh-topics`**: 12개 후보 수집.
3. **§3.34.40 v2 FRESH 4-field 매칭**: PUB 5개 (31485/31482/31479/31490/31496) + FRESH 7개 식별 (31492 개발팁 / 31484/31489/31478/31476/31480 AI/ML / 31467 개발도구).
4. **§3.34 #21 AI/ML 우선 정책**: FRESH AI/ML 5개 중 점수 1순위 `31484 (9pt)` 픽.
5. **§3.34.55 `gfc._try_md_endpoint(31484)` 단일 변수 할당**: 4444 bytes fetch 정상 (279차 31496 → 21074 bytes). §3.34.46 영구화 7회째 + §3.34.55 시그니처 함정 회피 2회째.
6. **§3.34.47 격리 빌드**: `/tmp/tistory_drafts_280th/build_draft_31484.py` 7008 bytes UTF-8 선언 + 격리 호출 (5회째). `md_to_html` 5종 패턴 (§3.34.46 4종 + §3.34.48 `*` + §3.34.54 `>`) 모두 포함.
7. **§3.34.50 Topic Body 마커 기반 본문 추출**: 7회째 (260차 정착 → 272차 식별 → 274차 1회 검증 → 280차 7회째). 본문 평문 938자.
8. **publish**: `--title ... --category 1219746 --file ... --source-url ... --gn-topic-id 31484 --image-query "eu court justice gavel brand trademark logo abstract"` → Picsum ID 982 자동 매칭 (두 슬롯 동일), CDN 업로드 2/2 → `✅ 발행 성공! https://sigco.tistory.com/1027`.
9. **§3.11 `post_publish_sync sync` CLI**: 7필드 보정 → `triple_signal_match: true`.
10. **§3.5 5중 신호 사후 검증**: 5/5 일치 (all_match: True). pt.last.title + state.last.title + state.details[-1].title 모두 동일.
11. **§3.34.52 IME 가드 cross-check**: 라이브 페이지 `<title>` 태그 = `'OpenAI, EU 법원 상표권 분쟁에서 패소 &mdash; GPT는 일반 명사가 아니다'` (pt/state 3필드와 일치 → 정상).
12. **라이브 페이지 GET**: `status=200, size=62273` (실제 발행 확인).
13. **cleanup cron 임무 #16 dry-run**: `✅ 누설 없음` (66→**67회** 연속 all-green).

## 핵심 발견 / 함정 회피

- **§3.34.55 `_try_md_endpoint(tid)` 단일 변수 할당 2회째**: 279차에 식별된 함정 패턴을 280차에도 동일 적용 (`text = gfc._try_md_endpoint(31484)`). tuple unpack 시도 안 함. `Optional[str]` 시그니처 정상 동작.
- **§3.34.53 `gfc` alias 4회째**: `importlib.util.spec_from_file_location('gfc', '.../gn-fetch-content.py')` 패턴 정상.
- **§3.34.54 `>` blockquote 분기 6번째 패턴 (이번 본문엔 hit 없음, 분기 안전 가드 포함)**: 280차 본문엔 `>` 라인 없었지만 `build_draft_31484.py` 안에 `elif stripped.startswith(">"):` 분기가 박혀있어 후속 차 본문에 `>` blockquote 등장시 자동 라우팅 (278차 정착 분기).
- **§3.34.52 IME 변환 가드**: title에 `OpenAI`, `EU`, `GPT` 같은 ASCII 토큰이 영문 그대로 보존되어 있는지 sanity check 통과. 라이브 페이지 `<title>` cross-check 일치.
- **§3.34 #21 AI/ML 우선 정책 실전 7호 검증**: FRESH 7개 중 AI/ML 5 + 개발도구 1 + 개발팁 1 → AI/ML 점수 1순위 픽. §3.34.45 매트릭스 4번째 분기 "FRESH 'AI/ML' + 비-기타 혼재 → AI/ML 점수 1순위 픽" 누적 7회 정상 동작 (255차 1호 → 266차 2호 → 268차 3호 → 269차 4호 → 270차 5호 → 271차 6호 → **280차 7호**).

## 사용된 격리 bash 패턴

```bash
# §3.8.1 가드
env -i HOME=/Users/mac PATH=/usr/bin:/bin PWD=/Users/mac /bin/bash -c '
set -a; source ~/.hermes/secrets/tistory.env; set +a
/usr/bin/python3 << PYEOF ...
PYEOF'

# §3.34.47 빌드 스크립트 호출
env -i HOME=/Users/mac PATH=/usr/bin:/bin PWD=/Users/mac /bin/bash -c '
set -a; source ~/.hermes/secrets/tistory.env; set +a
/usr/bin/python3 /tmp/tistory_drafts_280th/build_draft_31484.py'

# publish (직접 호출, §3.34.40 4단계 패턴 4번 항목)
# sync (242차 CLI 서브커맨드 형식, --category-id 명시)
```

## 후속 차 작업 권장

- 281차: FRESH 6개 (`31492` 개발팁 / `31489`/`31478`/`31476`/`31480` AI/ML / `31467` 개발도구) 중 §3.34 #21 정책 + §3.34.45 매트릭스 4번째 분기 정상 동작 예상. AI/ML 점수 1순위 `31489 (7pt)` (메모리상) 픽 후보.
- 영구화 패치 추가 없음 — 모든 패턴 정상 동작.
