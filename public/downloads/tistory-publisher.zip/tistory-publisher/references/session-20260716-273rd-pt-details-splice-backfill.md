# 273차 세션 reference — pt.details splice 누락 drift 케이스 보정

**날짜**: 2026-07-16
**세션 차수**: 273차 (cron 자동)
**작업 결과**: `#1016 Physical AI의 머니볼` 정상 발행 — 연속 all-green 60회차 (213~273차)

## 핵심 발견

### §3.34.51 (NEW, 273차 식별) — pt.details splice 누락 drift 케이스

272차 §3.34.50 정착 + §3.34.40 v2 적용에도 불구하고, 273차 cron에서 또 다른 splice 누락 패턴 발견:

**케이스**: 271차 #1013 `Bonsai 27B` (gn=31450) 발행 후 pt.details에 entry가 splice 누락. 272차 cron의 pt.last.gn_topic_id=31450 v2 guard로 FRESH 매칭에서 제외되었지만 (v2 정정으로 FRESH 7개 식별 정확), **pt.details array 자체에는 31450 entry가 없었음**. 

**증상**:
- pt.last.gn_topic_id = 31450 (정상 박힘)
- pt.details[-1] = #1014 `AI 혐오` (gn=31443, 272차 발행)
- pt.details에 #1013 31450 entry 부재 (271차 splice 누락)
- 라이브 페이지 #1013 = `Bonsai 27B` 정상 발행 확인

**해결 (273차 적용)**:
1. **§3.34.51 FRESH 4-field v3 강화 권장** — `pt.last.gn_topic_id` 만으론 부족. **publish URL 슬롯별 title prefix 매칭**으로 이미 발행된 주제 후보를 추가 검증. 예: pt.details에 없는 #1013 슬롯이라도 라이브 페이지에서 `Bonsai 27B` 제목이 박혀있으면 FRESH 후보 31450 제외.
2. **273차 임시 보정**: splice backfill entry를 직접 json append → 5중 신호 깨짐 (state.details[-1]=#1013, pt.last=#1015) → 즉시 entry 제거 후 정상화. publish 후 §3.11 sync가 자동으로 올바른 5중 신호 정정 박음.

**영구화 패치 후보**:
- `scripts/fresh-pick-guard.py` — `pt.last.gn_topic_id` + (옵션) 라이브 페이지 slot title prefix 매칭
- `scripts/cleanup-pt-details-splice.py` — historical splice 누락 자동 감지 + backfill

## 워크플로 (273차 적용)

1. §3.8.1 가드 — `status=200, ct=application/json;charset=UTF-8, cookie_count=8` ✅
2. `blog_pipeline.py --refresh-topics --dry-run` → TOP 12 후보 (31449~31454)
3. §3.34.40 v2 FRESH 4-field 매칭 → FRESH 7개 (31457/31447/31450/31451/31456/31455/31445)
4. §3.34.51 splice 누락 식별 — 31450이 FRESH에 잘못 포함 (pt.details 누락)
5. 라이브 페이지 직접 GET으로 31450=#1013 Bonsai 27B 발행 확인 → FRESH 후보에서 제외
6. 임시 splice backfill → 5중 신호 깨짐 → 즉시 backfill entry 제거 (273차는 5중 all_match #1015 복구)
7. §3.34 #21 + §3.34.45 매트릭스: AI/ML FRESH 3개 (31456/31455/31445) 중 동점 → **31456 Physical AI의 머니볼 픽**
8. §3.34.50 Topic Body 마커 기반 본문 fetch → 11257자 정상
9. §3.34.47 격리 빌드 (`/tmp/tistory_drafts_273rd/build_draft_31456.py` 5549 bytes UTF-8 선언 + 저장 → `python3 build_draft_31456.py` 정상, 10586자 평문)
10. §3.34.46 md_to_html 변환 — 262차 정착 + 266차 `* ` 분기 + 4단계 헤더 강등 모두 적용
11. publish (`--image-query "robot arm factory automation physical ai warehouse"`, Picsum ID 835 자동 매칭)
12. §3.11 sync → 7필드 보정 + §3.5 5중 신호 `#1016` all_match: true
13. cleanup cron 임무 #16 dry-run ✅ 누설 없음 (60회 연속 all-green)
14. 라이브 페이지 직접 GET → entryId=1016, categoryId=1219746, title 정상

## 검증 결과

- **publish URL**: https://sigco.tistory.com/1016 ✅
- **entryId/categoryId**: 1016 / 1219746 (AI/ML) ✅
- **title tag**: `Physical AI의 머니볼 &mdash; ...` ✅
- **본문 평문**: 10586자 (300자 가드 통과) ✅
- **이미지**: 2장 CDN 업로드 (Picsum ID 835, 자동 매칭) ✅
- **§3.5 5중 신호**: all_match ✅
- **§3.11 sync**: triple_signal_match: true ✅
- **cleanup cron 임무 #16**: 60회 연속 all-green ✅
- **연속 all-green 60회차 (213~273차)** ✅

## 차감/추가

- **본 세션 신규 발견 1건** — §3.34.51 pt.details splice 누락 drift 케이스
- 기존 패턴(§3.8.1 가드 / §3.8.2 격리 / §3.11 sync / §3.34.40 v2 / §3.34.43 PWD / §3.34.46 영구화 / §3.34.47 격리 빌드 / §3.34.48 `*` 분기 / §3.34.49 endpoint / §3.34.50 Topic Body / §3.34 #21 정책 / §3.34.45 매트릭스 / cleanup cron 임무 #16) 모두 정상 동작
- **영구화 권장**: `scripts/fresh-pick-guard.py` (라이브 페이지 슬롯 title prefix 매칭), `scripts/cleanup-pt-details-splice.py` (historical splice 자동 보정)
- **cleanup cron 임무 #30 신규**: §3.34.51 pt.details splice 누락 자동 감지 + backfill