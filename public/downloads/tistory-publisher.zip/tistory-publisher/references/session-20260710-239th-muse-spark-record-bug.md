# 239차 세션 (2026-07-10) — Muse Spark #957 발행 + §3.34.36 `--record` None 박기 신규 버그

## TL;DR

- 1순위 #31279 (score=4) "Muse Spark 1.1 공개" 발행 → sigco.tistory.com/957 (AI/ML)
- 본문 2,273자 / Picsum id=966×2 Kakao CDN 105KB×2
- **§3.34.36 신규 버그 발견**: `blog_pipeline.py --record "TOPIC" "TITLE" "URL"` 3-arg가 `pt['last'].url = None` 박음
- **post-publish-correct.sh curl 단계 sandbox 환경 의존** (HTTP 000, set -e로 즉시 종료)

## §3.34.36 — `--record` None 박기 버그 실전 재현

### 재현 순서 (이번 세션에서 정확히 일어난 일)

```bash
# 1) publish 성공
python3 ~/.hermes/scripts/tistory_publisher.py --file /tmp/draft_muse.md --category 1219746 ...
# → ✅ 발행 성공! https://sigco.tistory.com/957

# 2) pt 직접 동기화 (heredoc)
python3 -c "..."  # last.url + details[-1].url 모두 sigco.tistory.com/957 박기

# 3) blog_pipeline --record 3-arg 호출
python3 ~/.hermes/scripts/blog_pipeline.py --record "Muse Spark 1.1 공개" "Muse Spark 1.1 공개 — Meta의 ..." "https://sigco.tistory.com/957"
# → ✅ 발행 기록 추가: ... (성공 메시지 출력)

# 4) §3.5 3중 신호 검증 → ❌ pt.last.url = None 발견!
```

### 검증 결과

```
RSS max id: 957
pt.last.url: None          ← ❌ 박혀야 할 값이 None
pt.last.title: Muse Spark 1.1 공개 — Meta의 멀티모달 에이전트 추론 모델, 무엇이 달라졌나  ← OK
pt.details count: 50
details[-1].url: https://sigco.tistory.com/957  ← OK
state.today_counts: {'AI/ML': 5, '개발팁': 1, '개발도구': 1}  ← OK
state.total_published: 37  ← OK
```

### 분석

`--record` 3-arg 호출이 `pt['last']` dict를 **전체 새 dict로 덮어쓰면서 `url` 키를 누락**. 이전 235차 §3.34.31 검증에서는 "URL은 박힌다"였으나 **이번엔 박히지 않음**. 가능한 원인:

- `blog_pipeline.py`의 `record_published_topic()` 함수가 pt format을 변경했을 가능성 (235차~239차 사이 업데이트)
- 3-arg 시그니처 자체 문제 (TITLE이 사실은 URL 자리로 들어가거나)
- 환경 의존 (Python 3.12 vs 3.9, --record 내부 동작 분기)

### 보정 (직접 heredoc)

```python
pt['last']['url'] = 'https://sigco.tistory.com/957'
pt['last']['source_url'] = 'https://news.hada.io/topic?id=31279'
pt['last']['gn_topic_id'] = 31279
```

→ §3.5 3중 신호 (a)번 `details[-1].url == ""` 가드는 못 잡음 (details는 정상). **(a')번 `pt['last'].url == sigco_max` 매치 검증이 추가로 필요**.

### 권장 영구화

**`scripts/blog-pipeline-record-url-guard.py` 신규 작성 권장**:

```python
#!/usr/bin/env python3
"""
blog_pipeline.py --record 호출 후 pt['last'].url 박힘 검증 + None 누설시 자동 보정.
§3.34.36 영구화 가드.
사용: blog_pipeline.py --record ... && python3 blog-pipeline-record-url-guard.py <URL>
"""
import json, sys
from pathlib import Path

EXPECTED_URL = sys.argv[1]
p = Path.home() / '.hermes/memory/published_topics.json'
pt = json.loads(p.read_text())
last_url = pt.get('last', {}).get('url')

if last_url is None or last_url == '':
    # 자동 보정: details[-1].url 참조
    detail_url = pt.get('details', [{}])[-1].get('url')
    if detail_url and detail_url != EXPECTED_URL:
        # details와 기대값이 다르면 직접 박기
        pt['last']['url'] = EXPECTED_URL
        if 'source_url' not in pt['last']:
            # gn_topic_id에서 복원
            pt['last']['source_url'] = f"https://news.hada.io/topic?id={pt['last'].get('gn_topic_id', '')}"
        p.write_text(json.dumps(pt, ensure_ascii=False, indent=2))
        print(f"✅ pt['last'].url 보정: {EXPECTED_URL}")
    elif detail_url == EXPECTED_URL:
        pt['last']['url'] = EXPECTED_URL
        p.write_text(json.dumps(pt, ensure_ascii=False, indent=2))
        print(f"✅ pt['last'].url 보정 (from details): {EXPECTED_URL}")
    else:
        print(f"❌ 보정 불가: details[-1].url={detail_url}, 기대값={EXPECTED_URL}")
        sys.exit(1)
elif last_url == EXPECTED_URL:
    print(f"✅ pt['last'].url 정상: {last_url}")
else:
    print(f"⚠️ pt['last'].url 불일치: 박힘={last_url}, 기대={EXPECTED_URL}")
```

## `post-publish-correct.sh` curl 단계 sandbox 환경 의존

### 문제

```bash
# 1단계
curl -s -o /tmp/check_post_publish.html -w "HTTP %{http_code} | %{size_download} bytes\n" "$URL"
# → HTTP 000 | 0 bytes (sandbox 외부 네트워크 차단)
```

`set -e`로 즉시 종료 → 2~5-1단계 미실행.

### 영향

post-publish-correct.sh는 sandbox에서 실행 못 함. 직접 heredoc으로 4단계 + 5-1단계 실행해야 함.

### 권장 수정 (cleanup cron 임무 #17 후보)

```bash
# 1단계 수정안
curl -s -o /tmp/check_post_publish.html -w "HTTP %{http_code} | %{size_download} bytes\n" "$URL" || {
    echo "⚠️ curl 실패 (sandbox?): RSS max id로 검증 대체"
    rss_max=$(python3 -c "import urllib.request,re; r=urllib.request.urlopen('https://sigco.tistory.com/rss',timeout=10).read().decode(); print(max(int(i) for i in re.findall(r'sigco\.tistory\.com/(\d+)', r)))")
    if [ "$rss_max" = "${URL##*/}" ]; then
        echo "✅ RSS max=$rss_max == URL=${URL##*/} (대체 검증 통과)"
    else
        echo "❌ 대체 검증 실패: rss_max=$rss_max != URL=${URL##*/}"
        exit 1
    fi
}
```

## §3.5 3중 신호 검증 격상 (a'번 추가)

### 이전 (235차)

```
(a) details[-1].url == "" ? → False | 실제: sigco.tistory.com/957
(b) pt[last].url 없음? → False | 실제: sigco.tistory.com/957
(c) state stats today
(d) state stats total
(e) details[-1].gn_topic_id 박힘?
```

### 권장 격상 (이번 세션 발견 후)

```
(a) details[-1].url == sigco_max ? → True | 실제: sigco.tistory.com/957
(a') pt[last].url == sigco_max ? → True | 실제: sigco.tistory.com/957  ← NEW
(b) pt[last].url 없음 (None) ? → False
(c) state stats today
(d) state stats total
(e) details[-1].gn_topic_id 박힘?
(f) state.details count vs Tistory max 차이 < 1000 (cleanup cron 임무 #15)
```

## cleanup cron 임무 상태 (239차)

| 임무 | 상태 | 비고 |
|---|---|---|
| #1 (retroactive-gn-topic-id.py 영구화) | 시급 | 231차 historical drift 920 누적 |
| #12 (gn-fetch-content.py 영구화) | 미완료 | 233차 검증 거짓 |
| #15 (historical drift health check) | 미구현 | 231차 제안, 알림만 |
| #16 (cleanup_daily_cat_id_leak.py) | ✅ 영구화 완료 | 238차, 26회 연속 all-green |
| #17 (record-url-guard.py) | 신규 제안 | 239차 §3.34.36 |
| #18 (post-publish-correct curl 우회) | 신규 제안 | 239차 sandbox 의존 |

## 통계

- 이번 세션 cleanup: **26회 연속 all-green** (213~239차)
- daily_counts[2026-07-10] = {'AI/ML': 5, '개발팁': 1, '개발도구': 1}
- state.stats.total_published = 37
- Tistory sigco.tistory.com RSS max = 957
- 1순위 #31279 "Muse Spark 1.1" #957 발행 (CJK 998자 / Picsum 2장 id=966×2 / Kakao CDN 105KB×2 / source footer 25번째 검증)