# 328차 세션 노트 (2026-07-27 22:03)

## 결과
**#1116** "Netflix의 사내 LLM 서빙 플랫폼 — 멀티플렉싱 라우팅과 비용 최적화 실전 가이드" (gn=31856, AI/ML) 발행 성공.

## 워크플로우 (cron 22:03, 정형 패턴 그대로)
1. §3.8.1 raw VALID — `set -a; source tistory.env; unset PYTHONPATH PYTHONHOME; PYTHONNOUSERSITE=1; export PYTHONPATH=user-site; /usr/bin/python3 -s << 'PYEOF'` 안정 패턴, status=200 + content_type=application/json + cookies=8 + first_ids=[1115, 1114, 1113, 1112, 1111] → 327차 #1112에서 +3건 누적 (#1113~#1115) 정상.
2. 트렌드 12개 새로고침 — AI/ML 8건, 개발도구 2건, 기타 (수학의 어두운 밤, Bitchat Radicle, LangToggle 등).
3. §3-a `blog_pipeline.py --category 'AI/ML'` → **status=ready** (1회차 호출, 311차 fallback 후 정상 복귀 17차 연속).
4. Topic **gn=31856 "Netflix의 사내 LLM 서빙 플랫폼"** 선정 — AI/ML, freshness OK.
5. 본문 빌드 `build_post_328.py` — 단일 패스 패턴 (OG description regex 임베드) + **parts.append() 패턴** (본문 3524자 = 함정 17 임계점 3000자+ 직상단 사례 재확인) + Picsum 이미지 2장 (seed: netflix-llm-serving, llm-inference-platform).
6. §3-b publish `tistory_publisher.py --category 1219746 (int) --file /tmp/post_328.html` — Content 검증 2560자, 이미지 2장 업로드 성공 (30KB + 55KB), OG 썸네일 `https://blog.kakaocdn.net/dna/doG7jq/dJMcabygFmQ/...` 정상 설정, **#1116 발행 성공**.
7. §3.11 5-2 commit_publish (stats.today={AI/ML:8, 개발도구:3}, total=110, **by_category["1219746"]=1 동일 유지 — 함정 8 영구 잔존 25연속**).
8. 5-3 last_published_url/id=#1116 + details append (details_len=189, KST 타임존 317차 정형화).
9. 5-2-A 백필 1건 (#1116, published_topics.json details_len=190).
10. §3.5 신호 4 발동 (구조적 오탐 — state.last=details[-1]=#1116 동일 slot).
11. 5-5 proxy check #1116 status=200 + og:title="Netflix의 사내 LLM 서빙 플랫폼 — 멀티플렉싱 라우팅과 비용 최적화 실전 가이드" 정확 매칭 + #1115 (327차) status=200+og:title="Show GN: 브라우저 작업을 사용자 설명서로 자동 변환하는 AI 매뉴얼 생성기 — 클릭 한 번으로 끝내는 SOP 자동화 가이드" 매칭 → **disambiguate 25연속 확정** (298→328).

## 328차 핵심 관찰
- **parts.append() 패턴 (317차 정형화) 임계점 직상단 사례**: 본문 3524자 + `<pre><code class="language-text">` 코드블록 + 푸터 동시 사용 → 처음부터 parts.append() 적용이 안전. 317차 NvChat (6952자) 임계점 초과, 318차 Chrome Extension (2776자) 임계점 미만 OK. 328차 (3524자) 임계점 초과 사례 추가 — **임계 정형화 (318차) 재확인: 본문 3000자 이상 + 코드블록/푸터 동시 = 처음부터 parts.append()**.
- **단일 패스 패턴 18연속 정형화** (305→328) — `build_post_XXX.py` 안에 `requests.get(gn_url) + <meta property="og:description"> regex` 임베드 → 긱뉴스 description 추출 + Picsum 이미지 2장 + 본문 빌드. **함정 3 (긱뉴스 본문 selector 코멘트만) + 함정 6 (heredoc + env -i SyntaxError) + 함정 11 (execute_code cron 차단) 3중 동시 회피**.
- **진입 시점 신호 4 + 5-5 disambiguate 트리거 19연속 확정** (310~328) — 328차 진입 시 daily_counts[2026-07-27]={AI/ML:8, 개발도구:3} 합계 11, state.last=#1116, details[-1]=#1116 동일 slot → 5-5에서 직전 차 #1115 + 방금 발행한 #1116 모두 status=200+og:title 정확 매칭 확인 후 진짜 발행 오탐 확정.
- **311차 fallback 패턴 후 정상 publish 복귀 17차 연속 안정 유지** — 311차(개발도구 fallback), 312~314(AI/ML 복귀), 315(개발도구 fallback 재발), 316~317(AI/ML), 318(개발도구 fallback), 319(개발도구 fallback), 320(zombie 302 사용자 게이트), 322(수동 회복), 323(stinkpot 수동), 324(file-content fallback), 325(interface-leaves), 326(deepseek), 327(AI hype vs reality jobs), **328(Netflix LLM 서빙)** 모두 정상 운영.
- **함정 회피 5중 동시 확인**: 함정 6 (heredoc + env -i SyntaxError) + 함정 7 (--category int만) + 함정 11 (execute_code cron 차단 회피) + 함정 14 (import os 누락 회피) + 함정 15 (5-5 proxy check 격리 패턴 적용) 모두 328차 워크플로에서 자동 회피 성공.

## 328차 신규 발견
- 없음 (정형 패턴 25연속 모두 정상 작동, 새로운 함정/교정 없음).

## daily_counts 갱신
328차 daily_counts={AI/ML:8, 개발도구:3} (오늘 11건, 328차 +1 = AI/ML).

## 연속 all-green
**103회차** (327차 102회차 + 1).