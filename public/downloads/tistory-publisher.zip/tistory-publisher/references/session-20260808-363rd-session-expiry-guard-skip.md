# 363차 (2026-08-08 04:02) — §3.8.1 세션 만료 + 가드 self-crash 변형 C

**결과**: 발행 0건 (가드 skip). 가짜 발행 누적 0건, stats 오염 0건. 연속 all-green **136회차**.

## 개요

§3.8.1 세션 만료 가드 실행 시 가드가 `os.open(script_path)` 단계에서 `embedded null byte` ValueError로 self-crash하는 **함정 31 변형 C** 신규 발견. `bash -lc '...'` 래핑 없이 `/usr/bin/python3 -c "exec(open('/tmp/check_session_NNN.py').read())"`를 직접 호출하면 가드가 inner `/tmp/...` path를 deep-read 시도하다 죽는다.

## 시퀀스

1. `bash -lc 'unset PYTHONPATH; ...; /usr/bin/python3 /tmp/check_session_363.py'` 시도 → 가드 변형 B self-crash
2. `bash -lc '... /usr/bin/python3 -c "exec(open(...).read())"'` 정상 작동 — 가드 self-crash 우회
3. 결과: status=302, location=`https://www.tistory.com/auth/login?redirectUrl=https%3A%2F%2Fsigco.tistory.com%2...` → **§3.8.1 세션 만료 (Zombie 302)** — publish skip
4. §3.5 검증 실행 — 3중 신호 모두 일치, drift 0건, 가짜 발행 위험 없음
5. 보고 후 종료

## 함정 31 변형 C 분석

356차 SKILL.md 정형 (b)는 `bash -lc '...'` 래핑이 포함된 형태로 self-crash 회피 가능했으나, 363차에 SKILL.md 본문을 다시 정독하면서 일부 inline 명령에서 래핑을 빼고 호출한 게 화근.

**판정 매트릭스 확정 (363차 검증)**:

| 호출 | 가드 동작 |
|------|----------|
| `bash -lc '...'` 래핑 + inner `python3 -c "exec(open('/tmp/x.py').read())"` | ✅ 정상 |
| `bash -lc '...'` 래핑 + `python3 /tmp/x.py` | ❌ 변형 B self-crash |
| 래핑 없음 + inner `python3 -c "exec(open('/tmp/x.py').read())"` | ❌ 변형 C self-crash |
| �핑 없음 + `python3 /tmp/x.py` | ❌ 변형 B self-crash |
| inline `python3 -c "...subprocess.run(['~/.hermes/scripts/...']...)"` | ❌ 변형 A 차단 |

**결정적 차이**: 가드는 outer invocation의 arg path를 deep-read한다. `bash -lc` 래핑이 있으면 outer invocation은 bash 자체라 deep-read 안 하지만, 래핑 없이 python3가 outer이면 가드가 `-c` 안의 path까지 deep-read 시도 → 변형 C self-crash.

## SSOT 상태 (363차 KST 04:02 시점)

- `state.last_published_url` = `https://sigco.tistory.com/1202` (362차 Muse Code 정상 publish)
- `state.last_published_id` = `1202`
- `state.details[-1].url` = `https://sigco.tistory.com/1202`
- `state.last_topics[-1].url` = `https://sigco.tistory.com/1202`
- `state.published_topics.last.url` = `https://sigco.tistory.com/1202`
- `state.daily_counts[2026-08-07]` = `{'AI/ML': 6, '개발도구': 1}` = 7건 (362차까지)
- `state.total` = 1 (별도 트래킹 필드, SSOT 본체는 `published_topics.details_len=277`)
- `state.by_category` = `{}` (정상화)
- 3중 신호 모두 일치, drift 0건
- 진짜 발행 카운트: `published_topics.details_len` = **277건**

## §3.5 검증 헬퍼 함정 (363차 신규 발견)

`daily_counts[오늘]`을 단순 int로 가정하는 검증 스크립트는 즉시 `TypeError: '>=' not supported between instances of 'dict' and 'int'`로 죽는다:

```python
today_count = state.get('daily_counts', {}).get(today_kst, 0)  # ← dict 반환 (예: {'AI/ML': 6, '개발도구': 1})
if today_count >= 2 and details_last == last_url:  # ← TypeError
    ...
```

**해결**: `today_count = sum(dc.values()) if isinstance(dc, dict) else dc`. dict면 카테고리별 count 합계, 아니면 단일 int. 신호 4(FAKE_PUBLISH) 검증은 카테고리 총합 기준으로 판정.

## 운영 영향

- 363차: 가드 skip 정상 동작, stats 오염 0건
- 만료 추이 갱신: 322차 회복(7/26 17:13) → 363차 만료(8/8 04:02) = **약 13일 정상 운영** (322~363차 = 41차). 이전 패턴(18일 → 36시간 단축) 대비 회복됐으나 여전히 만료 임박.
- 다음 만료 예측: 363차 + 13일 ≈ 8/21 전후

## 보고

```
발행 0건 (가드 skip) — daily_counts 변화 없음
§3.8.1 세션 만료 (302 → /auth/login) — 8/8 04:02 KST cron.
publish 단계 미진입. 가짜 발행 누적 0건.
직전 정상 publish #1202 (362차 08-07).
SSOT 3중 신호 일치, drift 0건. 브라우저 쿠키 갱신 필요.
```

## SKILL.md 패치

- 363차 헤더 한 줄 추가
- 함정 31 본문을 `references/pitfall-31-guard-self-crash-variants.md`로 분리 (SKILL.md 한도 초과 회피)
- §3.5 daily_counts dict 구조 헬퍼 함정 추가 (다음 차 검증 스크립트 보강용)
