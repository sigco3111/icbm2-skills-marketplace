# 291차 (2026-07-18 21:01) — 가드 오탐 + 가짜 발행 잔재 누적 skip

## 배경

288~290차에 걸쳐 다음 두 가지 알려진 이슈가 공존:
- **289차**: daily_counts[2026-07-18] = 5건 누적인데 실제 Tistory 글 0건 (가짜 발행 잔재)
- **290차**: `session_expiry_guard.sh`의 `env -i` 격리 모드에서 tistory.env 누설 버그

291차 cron은 두 이슈를 동시에 마주침.

## 가드 오탐 → raw 검증 워크어라운드 (NEW)

### 문제
`env -i HOME=... PATH=... PYTHONPATH= ... /usr/bin/python3 << PYEOF` 패턴은 격리 모드에서 부모 셸의 `set -a; source tistory.env; set +a`로 주입한 환경변수도 python heredoc의 `os.environ`에 들어가지 않음. 결과: `NO_COOKIES` (exit 10) 또는 실제 cookies 누락으로 `EXPIRED` (302) 판정 → 가드 실패로 skip 처리.

### 워크어라운드 (291차 실전 검증)
가드 실행 후 `EXPIRED` 또는 `NO_COOKIES` 받으면, **raw 검증**으로 진짜 세션 상태 확인:

```bash
set -a; source ~/.hermes/secrets/tistory.env; set +a
unset PYTHONPATH
/usr/bin/python3 << 'PYEOF'
import os, requests
cookies = {k.replace('TISTORY_',''): os.environ[k] for k in os.environ if k.startswith('TISTORY_')}
hdr = {'User-Agent':'Mozilla/5.0','Referer':'https://sigco.tistory.com/manage/','X-Requested-With':'XMLHttpRequest'}
r = requests.get('https://sigco.tistory.com/manage/posts.json?category=-3&page=1',
                cookies=cookies, headers=hdr, timeout=10, allow_redirects=False)
print(f"status={r.status_code} ct={r.headers.get('content-type','-')[:60]}")
if r.status_code == 302:
    print(f"location={r.headers.get('location','-')}")
PYEOF
```

판정:
- `status=200` + `application/json` → **진짜 VALID**, 가드 스크립트 버그로 오탐된 것. publish 단계 진행.
- `status=302` + `location`에 `/auth/login` → **진짜 EXPIRED**. 단순 skip.

### 가드 스크립트 영구 수정 (다음 차 권장)
`session_expiry_guard.sh`에서 격리 모드 진입 **전**에 `set -a; source ~/.hermes/secrets/tistory.env; set +a` 수행 후 격리 모드로 진입하거나, 단순화해서 `env -i` 제거하고 `unset PYTHONPATH`만 사용. 290차 권고와 동일.

## 가짜 발행 잔재 누적 skip (289차 패턴 재확인)

291차 시점 상태:
```
daily_counts[2026-07-18] = {AI/ML: 4, 개발팁: 1} (total=5)
details[-1].url = https://sigco.tistory.com/1043 (287차 baseline 그대로)
last_topics[-1].url = https://sigco.tistory.com/952 (Bun, 7/10 stale)
```

→ 신호 4 FAKE_PUBLISH 발동. Tistory 측 실제 `#1044~` 전부 404 확인됨 (290차).

**판단**: 단순 skip 유지. publish 추가 진행 시 stats +1 = 오염 가중.

## 결정 매트릭스 (291차 신규)

publish 단계 진입 전 다음 4개 조건 동시 확인:

| §3.8.1 가드 | §3.5 신호 4 | 컨텐츠 생성 | 액션 |
|---|---|---|---|
| VALID | OK | OK | publish 진행 |
| **VALID (raw 검증 후)** | **FAKE_PUBLISH** | OK | **skip (291차)** |
| VALID | OK | OK이지만 중복 | skip (dedup) |
| EXPIRED | (무관) | (무관) | skip (가드) |
| raw 검증 EXPIRED | (무관) | (무관) | skip (진짜 만료) |

**중요**: §3.8.1 가드가 raw 검증으로 VALID이어도, §3.5 신호 4가 발동하면 publish skip가 우선. stats 추가 박기가 가짜 발행 잔재를 더 악화시킴.

## 다음 차 워크플로우 권장 (290차와 동일)

1. 사용자 확인 후 `daily_counts[2026-07-18]` 차감 보정 (실제 Tistory `#1044~#N` 카운트로)
2. `last_topics[-1]` 갱신 (실제 발행 후 details/last 동기화)
3. `session_expiry_guard.sh` env -i 버그 수정 (env -i 제거 또는 source 후 격리)

## 검증 이력 갱신

- **291차 (2026-07-18 21:01)** — §3.8.1 가드 env -i 격리 모드 EXPIRED 오탐 → raw 검증으로 진짜 VALID 확인. 트렌드 12개 새로고침, AI/ML ready (AIM 서버 호스팅, timeliness.fresh). 그러나 §3.5 신호 4 FAKE_PUBLISH 발동 (daily_counts[2026-07-18]=5, details[-1]=#1043 변동 없음) → publish skip. 컨텐츠 생성/게시 없이 단순 skip. cron이 가짜 발행 잔재 상태에서 stats 추가 박기 금지 패턴 재확인.