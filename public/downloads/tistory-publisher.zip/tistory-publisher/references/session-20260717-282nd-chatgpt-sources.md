# 282차 세션 — ChatGPT 출처 네트워크 트래픽 분석 (gn=31476)

**날짜**: 2026-07-17 (cron 자동 발행)
**슬롯**: #1030
**제목**: ChatGPT는 실제로 어떻게 출처를 고르는가 — 네트워크 트래픽으로 역추적한 1,240개 레코드의 시사점
**원문**: https://news.hada.io/topic?id=31476

## 핵심 결과
- **연속 all-green 69회차** (213~282차)
- AI/ML 카테고리 (1219746) 정상 발행, entryId=1030 검증
- 본문 평문 9036자 (300자 가드 통과, 검증 8851자)
- 이미지 2장 (Picsum ID 235, 두 슬롯 동일, 첫 시도 적중)
- 5중 신호 5/5 `#1030` 일치 (`all_match: True`)
- sync `triple_signal_match: true`, errors=[]
- daily_counts[2026-07-17] = `{'AI/ML': 4}` (3→4, +1 정확)
- cleanup cron 임무 #16 dry-run 68→**69회** 연속 all-green

## §3.34 #21 정책 실전 9호
FRESH 4개 식별: 31492(개발팁 14점) / 31467(개발도구 6점) / 31476(AI/ML 5점) / 31480(AI/ML 3점)
→ §3.34.45 매트릭스 4번째 분기 "FRESH 'AI/ML' + 비-기타 혼재 → AI/ML 점수 1순위 픽" 정상 동작
→ 비-AI/ML 후보(개발팁 14점)가 더 높은 점수를 가지고 있어도 AI/ML 정책이 우선
→ 31476 픽 확정 (AI/ML 5점)

## §3.34.44 자정 사이 외부 발행 drift 무해 3호 (282차 관찰)
사전 검증에서:
- `state.last_published_url = https://sigco.tistory.com/1029` (자정 사이 281차 외부 발행 흔적)
- `pt.last.gn_topic_id = '31478'` (281차 마지막 발행 토픽)

§3.34.40 v2 FRESH 4-field 매칭에서 `pt_last_gn='31478'` pub set 추가 후:
- FRESH 4개 (31492/31467/31476/31480) 정확히 식별
- 282차 정상 publish 후 sync 보정으로 `#1030` drift 무해 회복
- §3.5 5중 검증 모두 일치 유지

cron 차 사이 한 건 이상의 외부 발행이 일반화될 수 있음을 세 번째로 확인 (253차 식별 → 254차 1호 → 270차 2호 → **282차 3호**).

## 본문 빌드 (282차)
- `/tmp/tistory_drafts_281st_31476/build_draft.py` (6236 bytes, UTF-8 선언)
- `/tmp/tistory_drafts_281st_31476/draft.html` (22080 bytes)
- intro 540자 + 본문 8062자 (5종 md_to_html 패턴) + conclusion 1756자 + 마지막 단락

## 동작 검증된 패턴
- §3.8.1 가드 (status=200, ct=application/json;charset=UTF-8, cookies=8)
- §3.8.2 격리 (`env -i HOME=... PATH=... PWD=... /bin/bash -c '...'` + `/usr/bin/python3` 3.9)
- §3.11 sync CLI (`sync` 서브커맨드 + 7필드 보정)
- §3.34.40 v2 (FRESH 4-field + pt_last_gn pub set 추가)
- §3.34.43 PWD 보강 (`PWD=/Users/mac` 명시)
- §3.34.46 영구화 (`_try_md_endpoint(31476)` → 10264 bytes)
- §3.34.47 격리 빌드 (write_file + 격리 호출)
- §3.34.48 `*` 분기 (이번 본문엔 `-` 만 사용, 분기 안전 가드)
- §3.34.50 Topic Body 마커 (9566자 본문 추출)
- §3.34.52 IME 가드 (title ASCII 토큰 sanity check)
- §3.34.53 `gfc` alias (importlib spec_from_file_location("gfc"))
- §3.34.54 `>` blockquote (이번 본문엔 `>` 라인 없어 미적용)
- §3.34.55 시그니처 (`text = _try_md_endpoint(tid)` 단일 변수 할당)
- §3.34 #21 정책 + §3.34.45 매트릭스
- cleanup cron 임무 #16 (`cleanup_daily_cat_id_leak.py`)

## 라이브 페이지 검증
```
window.T.entryInfo = {"entryId":1030,"isAuthor":false,"categoryId":1219746,"categoryLabel":"AI 뉴스"};
<title>ChatGPT는 실제로 어떻게 출처를 고르는가 &mdash; 네트워크 트래픽으로 역추적한 1,240개 레코드의 시사점</title>
```

## 본 세션 신규 발견
**0건** — 모든 패턴 정착된 playbook 그대로 정상 동작.