# CJK 71차 루프 잔여 (2026-05-26 새벽 cron — DeepSeek Reasonix 블로그 글)

## 발견 경위

Markdown CJK 선검사 1차에서 20자 발견 → 종합 사전 1차 정제로 13자 제거 → 잔여 7자 → targeted final-pass로 제거 완료.

## 잔여 CJK 문자 (7자)

| 문자 | Unicode | 한글 대응 | 비고 |
|------|---------|-----------|------|
| 谋 | U+8C0B | — (제거) | Chinese —谋求/策略 |
| 竞 | U+7ADE | — (제거) | Chinese —竞争/竞赛 |
| 试 | U+8BD5 | 시 | Chinese —试验/测试 |
| 环 | U+73AF | 환 | Chinese —环境/环节 |
| 争 | U+4E89 | 쟁 | Chinese —争论/竞争 |
| 議 | U+8BA0 | 의 | Traditional Chinese —議論/協議 |
| 較 | U+8BD6 | 교 | Traditional Chinese —比较 |

## 유입 경로

GeekNews 원문 기사에서 Chinese/Japanese 텍스트가 한국어 사이에 직접 섞여 들어옴.
model이 Markdown 작성 시 Korean 텍스트 사이에 Chinese 캐릭터를 직접 생성.

## 종합 사전 추가 여부

- 7자 모두 종합 사전에 **누락**되어 있었음
- 이후 동일 세션 내 targeted final-pass로 제거 완료
- **종합 사전에 반드시 추가** 필요 (누적)

## 후속 조치

- [x] SKILL.md comprehensive dict에 7자 추가 (71차)
- [ ] 이후 세션에서 동일 문자 재등장 시 SKILL.md 종합 사전 적용 여부 확인
