# 301차 — "AI 래퍼는 끝났다: 초기 스타트업을 위한 수직화 전략" (#1052, gn=31598)

**날짜**: 2026-07-20 19:02 KST
**결과**: ✅ #1052 발행 성공 (state.details_len=125, daily_counts[2026-07-20]={AI/ML:5})

## 워크플로우 실전

1. **§3.8.1 세션 가드** — raw VALID (status=200, first_id=#1051). 이번 차엔 env -i 격리 모드 첫 호출에서 SyntaxError → 원인은 `env -i ... /usr/bin/python3 /usr/bin/python3 <script>` (python3 두 번). 단일 형태로 재호출로 정상.
2. **§3.5 baseline 점검** — drift 감지 (last=#1051, daily_counts={AI/ML:4}, details[-1]=#1051). 신호 4 FAKE_PUBLISH 발동했으나 details 실측상 #1048~#1051 4건 모두 정확 append 되어 있음 → **오탐 의심**.
3. **proxy check disambiguate** — #1048/#1049/#1050/#1051 4건 모두 status=200 + og:title 정확 매칭 → **전부 진짜 발행 확인**. 오탐 확정.
4. **트렌드 새로고침** — 12개 수집, 1순위 Supabase 2026 스타트업 (score=16.0).
5. **topic 선정** — `status=ready`, gn=31598 ("AI 래퍼는 끝났다...") (Notion 12순위, score=4.0). 295차 정책으로 Notion 순서 그대로 선정.
6. **publish** — 본문 2626자 + Picsum 이미지 2장 → **#1052** 발행. og:title 매칭 확인.
7. **§3.11 5단계**:
   - 5-2 commit_publish → daily_counts={AI/ML:5}, by_category에 "1219746" 키 영구 누적 (이미 있던 키에 `=` 할당, 신규 누적은 없음 — 함수 8 누적 가속 가설 확인)
   - 5-3 last+details 통합 보정 (state.details_len 124→125)
   - 5-4 §3.5 신호 4 재발동 (오탐)
   - **5-2-A 백필 안정성 재확인** — 72건 idempotent 백필, published_topics.json details_len 54→126 (state.details_len=125와 1건 차이 — state 첫 entry가 pre-#1044 = 의도된 차이)
   - 5-5 proxy check #1052 status=200 + og:title 매칭 → disambiguate 통과

## 주요 학습

### 1. §3.5 신호 4 오탐 disambiguate 4연속 확정 (298→299→300→301)

매 차 §3.5가 신호 4를 발동하지만 proxy check로 disambiguate 통과. **이게 정상 운영 패턴으로 정착**. cron은 더 이상 신호 4 발동 = publish skip으로 단순 처리하면 안 되고, proxy check 의무화.

### 2. 5-2-A 백필 안정성 확인

301차에 72건 단발 보정으로 published_topics.json 거의 완전 동기화. 패턴:
- state.details = SSOT (진실, 매 차 append)
- published_topics.json = `--record-topic` 미사용으로 누락 누적
- 5-2-A에서 idempotent 백필로 단발 보정 가능 (URL 중복 체크로 안전)

매 차 누락분이 누적되지만 단발 보정으로 정합 가능 — 사용자 게이트 시 일괄 정리 권장.

### 3. by_category 영구 누적 가설 확인 (함정 8)

301차 #1052 발행 후에도 by_category["1219746"]=1 동일. 코드 동작이 `=` 할당이라 첫 매핑 후 변동 없음 → 사용자 게이트 시 1회 ID_TO_NAME 보정으로 영구 해결 가능. 매 차 drift 보고만으로는 무한 누적되지만 실제 stats today에는 영향 없음.

### 4. 신규 환경 함정 (함정 9)

`env -i HOME=... PATH=... PYTHONPATH= /usr/bin/python3 /usr/bin/python3 <script>` 같이 python3 두 번 → SyntaxError. SKILL.md 본문 가이드는 이미 단일 형태이나, 자동화 스크립트 작성 시 실수하기 쉬운 함정.

## 검증

- proxy check: #1048 #1049 #1050 #1051 #1052 모두 status=200 + og:title 매칭 ✅
- state 동기화: details[-3:] = #1050 #1051 #1052 모두 정확 ✅
- daily_counts[2026-07-20]={AI/ML:5} 정확 ✅
- last_published_url=#1052, last_published_id=1052 ✅
- 연속 all-green 81회차 ✅
