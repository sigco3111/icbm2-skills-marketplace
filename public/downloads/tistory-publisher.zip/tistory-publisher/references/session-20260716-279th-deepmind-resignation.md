# 279차 세션 (2026-07-16) — #1026 Google DeepMind 퇴사

## 발행 결과
- **#1026 내가 Google DeepMind를 떠난 이유 — 한 연구자가 본 AI 윤리의 구조적 한계**
- gn=31496, 8점, AI/ML (1219746), FRESH 1순위
- 연속 all-green 66회차 (213~279차)

## §3.34.55 (NEW) — `gfc` 시그니처 함정 2종

279차 첫 빌드에서 두 가지 시그니처 shape 불일치를 hit. 둘 다 SKILL.md 본문 가이드와 다른 실제 함수 동작.

### 함정 1: `gfc.fetch_gn_content(tid)` 
- SKILL.md §3.34.34 (244차 확인) 가이드: `(title, content, source) tuple` 반환
- 실제 동작 279차: `TypeError: 'NoneType' object is not subscriptable` 반환
- 실제 함수: `Optional[Tuple[str, str, str]]` → None 반환
- **회피**: `fetch_gn_content` 단독 호출 회피. 무조건 `_try_md_endpoint(tid)` 단일 함수 사용.

### 함정 2: `gfc._try_md_endpoint(tid)`
- SKILL.md §3.34.46 박스 가이드: 단일 문자열 반환
- 실제 grep 확인 (line 87): `def _try_md_endpoint(topic_id: int) -> Optional[str]:` → 단일 str
- 279차엔 단일 변수 할당으로 정상 fetch (21074 bytes)
- **위험**: `status, text = gfc._try_md_endpoint(tid)` 형태 적으면 `ValueError: too many values to unpack (expected 2)`
- **회피**: 항상 `text = gfc._try_md_endpoint(tid)` 단일 변수 할당.

### 적용 범위
- §3.34.46 본문 빌드의 모든 변형 (`build_draft_*.py` / `gn-markdown-to-tistory-html.py`)
- 단일 probe (가드 / sync / state 확인) 처럼 5~10줄짜리 short heredoc은 영향 없음

### 영구화 권장 (cleanup cron 임무 #35)
- `scripts/gn-fetch-content.py` 의 두 public 함수 시그니처를 module docstring에 명시
- `fetch_gn_content` 호출자가 무조건 None 체크하도록 가드 추가
- SKILL.md §3.34.34 박스 코드 스니펫을 `_try_md_endpoint(tid)` 단일 호출로 통일

## §3.34.50 Topic Body 마커 7회째 (279차 검증)

31496 본문 첫 줄이 `- Google DeepMind 연구 과학자였던 Alexander Matt Turner는...` 인데
Topic Body 마커 매칭이 정상 작동하여 15239자 본문 확보. 272차 식별 위험(`- ` 본문 bullet 첫 줄) 케이스가 재현되지 않음을 1회 더 확인.

## 빌드 스크립트
- `/tmp/tistory_drafts_279th/build_draft_31496.py` (6792 bytes, UTF-8 선언, 격리 호출 정상)
- 본문 평문 14695자 (intro 540 + 본문 12455 + conclusion 1700)

## 5중 신호 검증
1. state.last_published_url = https://sigco.tistory.com/1026
2. state.last.url = https://sigco.tistory.com/1026
3. state.details[-1].url = https://sigco.tistory.com/1026
4. pt.last.url = https://sigco.tistory.com/1026
5. pt.details[-1].url = https://sigco.tistory.com/1026
- all_match: True
- triple_signal_match: true

## post_publish_sync 결과
- pt_updated: true
- state_updated: true
- errors: []
- triple_signal_match: true

## daily_counts
- 2026-07-16: {'AI/ML': 9, '개발도구': 2} (AI/ML 8→9, +1 정확)
- state.details 103→104, pt.details 118→119

## cleanup cron 임무 #16
- ✅ dry-run 누설 없음 (65→66회 연속 all-green)

## 이미지
- query: "ai ethics governance google deepmind resignation contract framework"
- Picsum ID 851 (두 슬롯 동일, 첫 시도 적중)

## 라이브 페이지 GET
- status=200, size=100887
- title tag: `'내가 Google DeepMind를 떠난 이유 &mdash; 한 연구자가 본 AI 윤리의 구조적 한계'`

## 차감/추가
- 차감: 244차 §3.34.34 "fetch_gn_content(tid)" 가드 = obsolete (279차 검증 결과 본문 빌드는 `_try_md_endpoint(tid)` 단일 함수만 사용 권장)
- 추가: §3.34.55 (gfc 시그니처 함정 2종), cleanup cron 임무 #35