# 353차 — Bonsai 발행: raw 가드·중복 판정·proxy-first 동기화

- **대상:** `Bonsai - Jane Street의 UI 라이브러리`, 긱뉴스 `32116`, AI/ML.
- **세션 가드:** 공식 `session_expiry_guard.sh`는 `env -i` 때문에 `TISTORY_*` 쿠키가 사라져 `NO_COOKIES`/exit=10을 반환했다. publish는 보류하고, `tistory.env`를 명시적으로 파싱해 쿠키 8개를 구성한 raw probe로 재검증했다. `manage/posts.json`이 HTTP 200 + `application/json`이고 최신 ID가 실제 최신 글과 일치할 때만 VALID로 판정한다. 302→`/auth/login`, HTML 응답, 최신 ID 불일치는 안전 skip.
- **중복 판정:** 과거 `Bonsai 27B` 글은 이름만 유사하고 topic/source가 달라 중복이 아니었다. 정확한 topic 원문, GN topic ID, source URL과 canonical MD5(`d299b0172ca2ef0ef5c91179d369afbc`)를 함께 검사한다. hash는 SEO 확장 제목이 아니라 pipeline 원문으로 계산한다.
- **진입 시점 drift:** 시작 상태에서 daily count가 3인데 `details[-1]`이 #1179라 §3.5 FAKE_PUBLISH가 먼저 울렸다. 새 글을 고르기 전에 기존 `last_published_url`을 proxy로 확인해 HTTP 200·제목·출처가 실제로 존재하는지 판정해야 한다. 실제 글이면 임의 롤백/추가 stats 보정을 하지 않고 legacy/구조적 drift로 기록한 뒤, exact 중복 검사 후 진행한다.
- **빌드 검증의 작은 함정:** 검증 스크립트의 f-string 표현식 안에 정규식 백슬래시를 직접 넣으면 Python 3.9에서 SyntaxError가 날 수 있다. `text_len = ...`처럼 값을 먼저 계산한 뒤 f-string에 변수만 넣는다. `write_file` 직후 lint와 실행 exit code를 모두 확인한다.
- **실제 발행:** wrapper에서 `publish_post()`를 직접 호출하고 tags는 comma-separated 문자열, category는 정수 `1219746`, source URL과 `gn_topic_id=32116`을 전달했다. 실제 stdout에서 `PUBLISH=SUCCESS URL=https://sigco.tistory.com/1180`을 확인한 뒤에만 상태를 수정했다.
- **동기화 순서:** `--commit` → 5-3(`last_published_url`, `last_published_id`, `details`, `last_topics`) → 5-2-A(`published_topics` URL/hash/last) 순서를 지켰다. `--record-topic`이나 placeholder URL은 사용하지 않는다.
- **최종 판정:** 상태를 새 URL로 맞추자 `check_state_consistency.py`가 FAKE_PUBLISH exit=1을 냈지만, 이는 새 `details[-1]`과 `last_published_url`을 같은 슬롯에 보정할 때 생기는 구조적 신호였다. 관리 API 최신 ID `1180`, 글 HTTP 200, 정확한 `og:title`, source URL 포함, 상태 파일 일치, URL 단일 entry를 한 번에 확인해 실제 발행으로 확정했다. 같은 검사기를 인자만 바꿔 반복하지 말고 proxy-first로 disambiguate한다.

## 재사용 체크리스트

1. 공식 가드 실패 시 publish 금지 → 쿠키 보존 raw probe.
2. 후보 선정 호출은 한 번만 하고, 원문 topic/ID/source를 SSOT로 고정.
3. exact hash·URL 중복 검사 후 본문 빌드.
4. 실제 숫자 URL 확인 전 commit/state/stats 수정 금지.
5. publish 후 proxy와 상태를 함께 확인하고 §3.5 exit=1의 구조적 오탐 여부를 판정.
