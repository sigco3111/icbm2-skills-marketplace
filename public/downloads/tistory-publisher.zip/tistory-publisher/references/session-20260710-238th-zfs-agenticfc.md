# 238차 — ZFS NAS + Agentic FC, §3.34.33 실전 재현/보정

## 환경

- OS: macOS 26.5.1
- Python venv 깨짐 (urllib3 typing.X | Y 패턴으로 즉시 fail) → `/usr/bin/env -u VIRTUAL_ENV /usr/bin/python3 -E` 로 우회 (`/tmp/_freshpy.sh` 셸 래퍼).
- Tistory 쿠키 유효 (HTTP 200 + JSON 응답, §3.8.1 패턴 통과).

## 발행 결과

### #955 — Synology, QNAP, TrueNAS 없이 최소 ZFS NAS 구축하기

- **gn_topic_id**: 31276 (ZFS NAS 2024) — 자동 선정 1순위
- **category**: AI/ML (1219746), 한글 카테고리 키 "AI/ML"
- **CJK**: 1,719자 / bytes: 8,703
- **이미지**: Picsum 2장 자동 매핑 (`data center server storage` → picsum 29+11) → Kakao CDN 213KB+76KB
- **URL**: https://sigco.tistory.com/955
- **post-publish-correct.sh 결과**: ✅ 6단계 모두 정상, gn_topic_id=31276 박힘 확인
- **source footer 검증**: 23번째 (#954 → #955 이어서)

### #956 — Agentic FC

- **gn_topic_id**: 31268 (Agentic FC)
- **category**: 개발도구 (1219748), 한글 카테고리 키 "개발도구"
- **CJK**: 1,837자 / bytes: 7,374
- **이미지**: Picsum 2장 자동 매핑 (`soccer football stadium tactical` → picsum 180+495) → Kakao CDN 92KB+54KB
- **URL**: https://sigco.tistory.com/956
- **post-publish-correct.sh 결과**: ✅ 6단계 모두 정상, gn_topic_id=31268 박힘 확인
- **source footer 검증**: 24번째

## §3.34.33 함정 — 실제 재현 + 보정 패턴 1차 검증

### 재현 패턴 (5-1단계 heredoc)

`post-publish-correct.sh` 의 5-1단계 stats 보정 heredoc 은 다음 한 줄로 stats 에 +1 한다:

```python
state['daily_counts'][key]['$CATEGORY'] = state['daily_counts'][key].get('$CATEGORY', 0) + 1
```

여기서 `$CATEGORY` 가 cron 호출 시 **cat_id 문자열** 로 박히면 (`"1219746"`), 한글 key 가 아닌 int ID 그대로 day_entry 새 키로 누적된다. 235~237 차 동안 누적된 결과:

```python
daily_counts['2026-07-10'] = {
    'AI/ML': 4,        # 정상 한글 key
    '개발도구': 1,      # 정상 한글 key
    '개발팁': 1,        # 정상 한글 key
    '1219746': 1,       # ❌ 가짜 cat_id 누설 (이전 세션에서 이미 박힘)
}
```

### 보정 패턴 (cleanup heredoc — 본 세션 1차 적용)

```python
import json
from pathlib import Path
p = Path.home() / '.hermes/memory/blog_pipeline_state.json'
state = json.loads(p.read_text())
key = '2026-07-10'
day_entry = state['daily_counts'].get(key, {})
cat_id = '1219746'
if str(cat_id) in day_entry:
    val = day_entry.pop(str(cat_id))
    day_entry['AI/ML'] = day_entry.get('AI/ML', 0) + val
    state['daily_counts'][key] = day_entry
    p.write_text(json.dumps(state, ensure_ascii=False, indent=2))
```

### 영구화 fix (cleanup cron 임무 #16)

`scripts/cleanup_daily_cat_id_leak.py` 신규 — cat_id 누설 자동 검출·삭제·한글 key 합산. publish 후 1회 또는 cleanup cron에 추가 권장.

```bash
python3 ~/.hermes/skills/automation/tistory-publisher/scripts/cleanup_daily_cat_id_leak.py
python3 ~/.hermes/skills/automation/tistory-publisher/scripts/cleanup_daily_cat_id_leak.py --all    # 모든 날짜
python3 ~/.hermes/skills/automation/tistory-publisher/scripts/cleanup_daily_cat_id_leak.py --dry-run
```

## §3.34.34 gn-fetch-content.py 우회 패턴

`fetch_gn_content(tid)` 는 tuple `(title, content, url)` 반환 + CLI 실행은 300자 preview. 본문 전체가 필요할 때 다음 패턴 사용 (본 세션 검증):

```python
import importlib.util
spec = importlib.util.spec_from_file_location(
    "gnfetch",
    "/Users/mac/.hermes/skills/automation/tistory-publisher/scripts/gn-fetch-content.py",
)
mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
title, content, url = mod.fetch_gn_content(31276)
# title: str (49자), content: str (10,713자), url: str
```

또는 `result[0]`, `result[1]`, `result[2]` 로 인덱싱.

## §3.34.35 --image-query cron 전달 의무화

cron 프롬프트에서 `--image-query "<keyword>"` 가 누락되면 본문 그림 0장 (auto-insert 안 됨). 본 세션 cron 헤더에 query 가 포함되어 있어 Picsum 자동 router 로 2장 매핑 정상 동작:

| topic | image-query | Picsum IDs |
|---|---|---|
| #955 ZFS NAS | `data center server storage` | 29 + 11 |
| #956 Agentic FC | `soccer football stadium tactical` | 180 + 495 |

## 정리

| 항목 | 값 |
|---|---|
| 세션 만료 가드 | ✅ 통과 |
| 가짜 발행 가드 | ✅ 통과 (#955, #956 둘 다 실제 글 존재) |
| stats today cat_id 누설 | ❌ → ✅ 보정 완료 |
| gn_topic_id 박기 | ✅ 둘 다 정상 (`details[-1].gn_topic_id` 확인) |
| post-publish-correct.sh 6-arg 시그니처 | ✅ 정상 (TITLE 자리에 한글 제목) |
| source footer 검증 | 23, 24번째 |
| cleanup all-green | 25회 연속 (213~238차) |

## 다음 cleanup cron 후보

- **임무 #16 (238차 확정)**: `cleanup_daily_cat_id_leak.py` — 본 세션 추가, 244차 이전 cleanup cron 에 등록 권장.
