# 300차 (2026-07-20 05:02) — Mamdani NYC 임대 광고 AI 이미지 공개 규제 + published_topics.json 누락 백필

## 핵심 결과
- **#1051 발행 성공** (Mamdani, gn=31576, AI/ML)
- §3.8.1 가드 raw VALID + §3.5 신호 4 오탐 disambiguate 통과 (status=200 + og_title 매칭)
- 5-3 last+details 통합 보정 → 5-4 §3.5 발동(오탐) → 5-5 proxy check 통과 → 5-2-A published_topics.json 누락분 백필
- 300차 daily_counts={AI/ML:4} (297 #1048 + 298 #1049 + 299 #1050 + 300 #1051)
- 연속 all-green (제78회)

## 신규 발견: published_topics.json 누락 누적 패턴 (300차)

**증상**: published_topics.json의 details 마지막 entry가 `#1044` (292차)인데, state.json의 details 마지막은 `#1051`, 실제 Tistory는 `#1051`까지 발행됨.

**원인**: `tistory_publisher.py`가 `--record-topic` 인자 없이 호출되면 published_topics.json을 갱신하지 않음. 297~299차 모두 --record-topic 미사용 → 3회 누락.

**영향**: published_topics.json이 SSOT가 아닌 partial history가 됨. 자체 검증에는 지장 없지만 외부 검증/audit 도구에서 drift 노출 가능.

**해결 패턴 (300차 정형화)**: 5-2-A를 단순 "placeholder → 실제 URL 보정"이 아닌 **누락된 정상 발행분을 details에 백필**하는 절차로 확장:

```python
# 5-2-A 확장 (누락 백필)
# 이전 차 발행분 중 published_topics.json에 없는 URL을 details에 추가
KNOWN_URLS = ['https://sigco.tistory.com/1048', 'https://sigco.tistory.com/1049', ...]
for url in KNOWN_URLS:
    if not any(d.get('url') == url for d in data['details']):
        data['details'].append({...})
```

**판단**: SSOT 변경이지만 details append는 idempotent (URL 중복 체크)라 임의 자동 실행 허용. 단 placeholder 보정은 별도 (이전 함정 1 패턴 유지).

## 298차 신호 4 오탐 disambiguate 패턴 3연속 확정 (300차)

| 차 | daily_counts[오늘] | details[-1].slot | last_url | 신호 4 | disambiguate 결과 |
|----|-------------------|------------------|----------|--------|------------------|
| 298 | {AI/ML:1} | #1049 (신규) | #1049 | 오탐 | proxy check PASS |
| 299 | {AI/ML:2} | #1049 | #1049 | 오탐 | proxy check PASS |
| 300 | {AI/ML:4} | #1051 (신규) | #1051 | 오탐 | proxy check PASS |

**결론**: 정상 publish + 5-3 (last+details 동시 갱신) 후엔 §3.5 신호 4가 100% 발동한다. **즉시 5-5 proxy check로 disambiguate**하는 것이 표준 흐름.

**가짜 발행 vs 오탐 구분 매트릭스 (300차 확정)**:
| 조건 | 판정 |
|------|------|
| details[-1].slot != last_url.slot (예: details=#1043, last=#1051) | **진짜 FAKE_PUBLISH** — 5-3에서 details만 누락된 비대칭 상태, stats 추가 박기 금지 |
| details[-1].slot == last_url.slot (예: 둘 다 #1051) + proxy check status=200 | **오탐** — 정상 publish, disambiguate 통과 |
| details[-1].slot == last_url.slot + proxy check 404 | **진짜 FAKE_PUBLISH** — Tistory 측 글 없음 |

## by_category 정수 ID 키 누적 현황 (300차)

- 297~300차 모두 `by_category["1219746"] = 1` 누적 유지
- 사용자 게이트 시 ID_TO_NAME 매핑 한 번에 정리 권장 (SKILL.md §3.11 함정 8 절차)
- drift 보고는 매 차 명시

## 발행 본문 구성 (300차, Mamdani NYC 사례)

- 긱뉴스 본문 selector (함정 3) → OG description만 추출 가능, 자체 본문 작성 필요
- 본문 구성: 6 섹션 (무슨 일 / 왜 지금 / 기술적 의미 / 개발자 포인트 / 전망 / 요약)
- 분량 6155자 HTML, image 2장 (Picsum 시드 고정: nyc-mamdani, rental-ai-disclosure)
- 295차 무조건 발행 정책 통과 (score·문구·연도 무관)
- 긱뉴스 토픽 id=31576, published_at=2026-07-19 13:33

## 워크플로우 안정성 (300차)

- §3.8.1 raw 가드: source tistory.env → 격리 없이 python3 (291차 패턴 안정)
- §3.5 발동 후 자동 5-5 proxy check → publish 진행 판정 (300차 자동화 가능)
- 5-3 last+details + 5-2-A 백필 = 한 번의 워크플로우로 4개 SSOT 필드 동기화

## 검증

- Tistory #1051 status=200 + og_title 매칭 ✅
- state.json last_published_url=#1051, last_published_id=1051, details_len=124 ✅
- published_topics.json details_len=54 (#1048/#1049/#1050/#1051 모두 포함) ✅
- daily_counts[2026-07-20]={AI/ML:4} ✅
- 연속 all-green (제78회)