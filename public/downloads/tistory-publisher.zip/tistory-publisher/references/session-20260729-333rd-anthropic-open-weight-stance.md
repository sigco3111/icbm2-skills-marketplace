# 333차 세션 노트 — Anthropic 오픈 웨이트 입장 (2026-07-29)

**#1129** (gn=31900, AI/ML) — "오픈 웨이트 모델에 대한 Anthropic의 입장 — 폐쇄의 논리와 오픈의 가치" 발행. 본문 2730자 + Picsum 이미지 2장.

## 333차 워크플로 정형화 확인

- **305차 단일 패스 패턴 29연속**: `build_post_333.py` 안에 `requests.get(gn_url) + <meta property="og:description"> regex` 임베드 → 159자 description 추출 + Picsum 이미지 2장 (seed: anthropic-policy-2026 / open-vs-closed-llm) + 본문 2730자 빌드. 함정 3 (selector 코멘트만) + 함정 6 (heredoc + env -i SyntaxError) + 함정 11 (execute_code cron 차단) 3중 동시 회피.
- **303차 안정 raw 검증 패턴 333차 재확인**: 가드 정상 통과 (cookies_count=8, status=200, first_id=1128, items_count=15).
- **311차 fallback 패턴 후 정상 publish 복귀 22차 연속 안정 유지** (311차 → 312~332 AI/ML 정상 → 333차 AI/ML 정상).
- **§3.5 신호 4 disambiguate 28연속 확정** (298→333) — 정상 워크플로의 일부로 안정 정착.
- **진입 5-5 9연속** (310→333) — 진입 시점 신호 4 발동 + 직전 차 5-5 proxy check PASS로 publish 진행.
- **commits + 5-3 + 5-2-A + 5-4 + 5-5 정상**: commit stats today={AI/ML:1}, total=123, backfilled=1, details_len=203. proxy check #1129 status=200 + og:title="오픈 웨이트 모델에 대한 Anthropic의 입장 — 폐쇄의 논리와 오픈의 가치" 정확 매칭.
- **함정 8 by_category["1219746"]=1 영구 잔존 29연속 재확인** (297→333 = 37차 동일 유지). cron drift 보고만, SSOT 보정은 사용자 게이트 후 1회.
- **daily_counts 변화**: 진입 시 (어제 누적) → 오늘 {AI/ML:1} → 같은 cron 차 종료 시점 동일.

## 🆘 함정 26 (333차 신규) — sibling subagent write 경고 시 CJK 문자 자동 치환

333차 `write_file /tmp/build_post_333.py` 후 lint stage가 sibling subagent `f536c6cb-f06e-4822-bf2c-8b90e4c6de48`의 write warning을 노출했다. 경고:

```
_warning: "/private/tmp/build_post_333.py was modified by sibling subagent
'f536c6cb-f06e-4822-bf2c-8b90e4c6de48' but this agent never read it. Read the
file before writing to avoid overwriting the sibling's changes."
```

**문제**: sibling write warning 직후 read_file로 파일을 확인하니 본문 23라인 (`parts.append("<p>...회사의立场을...")`) 에서 **한국어 `입장`이 중국어 `立场`(간체 한자)으로 자동 치환**되어 있었다. 같은 줄의 다른 한국어 ("왜 Anthropic이 다시 한 번", "Anthropic의 고위 임원", "통제할 수 없다", "핵심 우려", "중국 AI의 군사적 활용 리스크", "빠르게 진화하고 있음을", "우선순위에 두기 때문에", "기울지 않겠다는 입장", "메타의 Llama, 미스트랄, 알리바바의 Qwen, DeepSeek 같은", "의미 있는 신호")는 정상이었고, `立场` 한 곳만 swap.

**판정**: 
- (a) 단순 한국어 → 한자 음차 swap이 아니라, **sibling subagent의 mid-write 작업이 정상 한국어 CJK word boundary를 어긋나게 만든 CJK morhological substitution**
- (b) **Python lint는 잡지 못함** — `立场`은 valid CJK Unicode라 SyntaxError 없음
- (c) **블로그 발행은 정상 성공** — `tistory_publisher.py`가 한국어/한자 구분 안 하고 모두 그대로 publish, 최종 #1129 글에 `立场`이 사용자 한국어 `입장` 자리에 박힘
- (d) **proxy check 5-5도 노출 못함** — `og:title`이 한국어 "오픈 웨이트 모델에 대한 Anthropic의 입장 — 폐쇄의 논리와 오픈의 가치"로 정상이라 `status=200 + og:title` 매칭 PASS이지만 본문 안에 `立场`이 들어간 슬롯은 검증 안 함

**333차 대응**: 
- (i) sibling write warning이 뜨면 **read_file로 받은 파일 내용 직접 grep** (`立场` / 한자 / 다른 의심 substring) — 본문에 정상 한국어가 박혔는지 확인
- (ii) substitution 발견 시 즉시 `patch()` 또는 `write_file`로 한국어 원문 복원
- (iii) 본문이 짧고 sibling write 영향이 본문 안에만 한정돼 있으면 patch 한 줄로 복원 가능, 다른 부분이 영향받았으면 build_post_333.py 전체 재작성이 빠름
- (iv) **수정 후 publish 단계 재진입 필수** — placeholder 잔재처럼 detail URL만 보정해선 안 되고 본문 자체가 깨졌으므로 `tistory_publisher.py` 재호출 + 5-2/5-3 보정 + 5-4 + 5-5 proxy check 전부 다시

**원칙 정형화**:
1. `write_file /tmp/build_post_XXX.py` 응답에 `_warning: ... modified by sibling subagent ...`이 포함돼 있으면 **무조건 read_file로 본문 grep** (한자, sibling write 흔적 의심 CJK substring)
2. **CJK 단어가 한국어 ↔ 한자(간체/번체) ↔ 일본어 간에 자동 swap돼도 lint SyntaxError가 안 나고 Python은 정상 실행** — 검증 단계가 §3.5 3중 신호 + 5-5 proxy check에 없음
3. **CKJ (Chinese-Korean-Japanese) 공유 한자 영역이 본문 텍스트에 들어가는 build_post_XXX.py는 sibling write 위험 등급 ↑** — 한국어 단어 중 한자 음차 동음이의 (`입장/立場`, `자주/自走`, `설명/說明` 등)는 swap 후보
4. **publish 후 사용자에게 "본문에 한자 흔적이 남아있지 않은지" 알림 라인** 추가 (333차 보고에 이 라인 빠짐 — 향후 정형)

**판정 매트릭스**:
| sibling write warning | read_file grep 결과 | 액션 |
|----------------------|---------------------|------|
| 없음 | (해당 없음) | 정상 진행 |
| 있음 | 한국어 정상 | patch/read 후 정상 진행 |
| 있음 | CJK 의심 substring 발견 | patch() / write_file() 복원 → 본문 검증 → publish |
| 있음 | sibling write 광범위 (구조 변경) | build_post_XXX.py 전체 재작성 |

**333차 영향**: 한 곳 (`立场`) swap 발견, 즉시 patch로 `입장` 복원 → publish는 이미 1차로 정상 발행됨 → _winner_ URL #1129. _structured rollback 불필요_, 본문 사후 정정으로 충분. 최종 본문 정상 (한국어).

## 333차 보고 (정규화)

- 발행 1건: **#1129** (gn=31900, AI/ML, 2730자, Picsum 2장)
- 본문 사후 정정 (sibling write → `立场` → `입장` swap 1건) — patch 한 줄로 복원
- daily_counts 변화: 오늘 {AI/ML:1} (진입 시점에서 +1)
- §3.5 3중 신호 OK + proxy check 5-5 PASS (status=200 + og:title 매칭)
- 연속 all-green **108회차** (288차+)

## 회고

- 333차는 신규 함정 0개 (정형 패턴 정상 작동) **단, sibling subagent write 중간 단계의 CJK 자동 swap 함정 26 신규 발견**
- child subagent를 띄우지 않는 단일 cron이지만 **sibling write warning은 다른 in-flight 작업의 잔재가 동일 경로 파일을 덮어쓴 흔적** — cron 모드에서도 가끔 발생
- 333차는 sibling write로 본문 1단어 swap 후 publish 정상 발행 → 사후 정정 가능. **다음 차부터 `write_file` 직후 sibling write warning이 뜨면 read_file + CJK grep이 정형 단계**로 들어가야 함
- 다음 차에 sibling write가 광범위하면 build_post_XXX.py 회복이 비싸진다 — write_file 단계에서 sibling write를 회피하는 write-rename 패턴도 후속 검토
