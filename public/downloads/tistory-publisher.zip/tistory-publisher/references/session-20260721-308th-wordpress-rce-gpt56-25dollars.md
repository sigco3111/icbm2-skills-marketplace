# 308차 세션 노트 — WordPress RCE를 GPT5.6과 25달러로 발견

**날짜**: 2026-07-21 21:01 KST
**Topic**: gn=31640 — "WordPress RCE를 GPT5.6과 25달러로 발견"
**Tistory URL**: https://sigco.tistory.com/1066
**Category**: AI/ML (1219746)

## 워크플로우

- §3.8.1 raw VALID (status=200, content_type=application/json, cookies_count=8, first_ids=['1065','1064','1063','1062','1061'])
- 트렌드 12개 새로고침
- AI/ML ready (gn=31640, WordPress RCE + GPT-5.6, timeliness.ok)
- §3.5 신호 4 발동 (state.last=#1065, details[-1]=#1065 동일 slot, daily_counts={AI/ML:8, 개발도구:1} ≥ 2)
- 5-5 proxy check disambiguate 통과 (#1065 status=200 + og:title 정확 매칭 → 오탐 확정)
- 5-2 commit_publish (stats.today={AI/ML:9, 개발도구:1}, total=60)
- 5-3 last+details 통합 보정 (last=#1066, details_len 138→139)
- 5-2-A 백필 1건 (누적 동기화, pt_details_len 139→140)
- 5-4 §3.5 신호 4 발동 (오탐 11연속)
- 5-5 proxy check #1066 status=200 + og:title 정확 매칭 → 진짜 발행 확인
- 본문 빌드: 305차 단일 패스 패턴 (og:description 임베드, write_file + /usr/bin/python3 -s)

## 발행 결과

- **#1066** — "WordPress RCE를 GPT5.6과 25달러로 발견 — AI 에이전트로 풀스택 보안 감사를 시작하는 법"
  - 본문 6399자 + Picsum 이미지 2장 (seed: wordpress-rce-gpt56, security-research-ai-agent)
  - og:description: "GPT5.6 Sol Ultra가 최신 안정판 WordPress를 분석해 인증 전 SQL 주입부터 관리자 계정 생성과 원격 코드 실행(RCE)까지 이어지는 공격 체인을 10여 시간 만에 완성함..."
  - OG 썸네일: https://blog.kakaocdn.net/dna/dpW14c/dJMcadpdOe8/...

## 누적 카운트

- **신호 4 오탐 disambiguate 11연속 확정** (298→308) — 정상 워크플로의 일부로 정착
- **297차 함정 8 by_category["1219746"]=1 영구 잔존 11연속 재확인** (297→308)
- 308차 daily_counts={AI/ML:9, 개발도구:1} (총 10건)
- 연속 all-green 88회차

## 함정 회피 4중 동시 확인

- 함정 6 (heredoc + env -i SyntaxError) — write_file + `/usr/bin/python3 -s` 단일 호출로 회피
- 함정 7 (--category int만) — `--category 1219746` int 형태로 호출
- 함정 11 (execute_code cron 차단) — write_file + `/tmp/build_post_308.py` + `/usr/bin/python3 -s` 정형 패턴
- 함정 14 (import os 누락) — 5-5 proxy check heredoc 첫 줄에 `import os, requests, re` 3모듈 포함

## 308차 신규 관찰 — 다중 발행 누적 상태에서도 패턴 안정성

일자 발행 10건(daily_counts={AI/ML:9, 개발도구:1}) 누적 상태에서 §3.8.1 raw VALID + §3.5 신호 4 오탐 + 5-5 proxy check PASS로 disambiguate하는 패턴이 11연속 안정적으로 작동. 누적량에 무관하게 정형 패턴 유지됨을 확인. cron은 일자 발행량 0~10건 범위에서 패턴 분기 없이 동일 절차로 처리 가능.

## 본문 빌드 단일 패스 패턴 (305→306→307→308, 4연속 재확인)

`build_post_308.py` 안에 `requests.get(gn_url) + og:description regex` 임베드 → 긱뉴스 description을 별도 단계 없이 본문에 박는 단일 패스. 4연속 정상 작동 확인 — 정형 패턴으로 완전히 정착. 함정 3 (긱뉴스 본문 selector 코멘트만 잡힘) + 함정 6 (heredoc + env -i SyntaxError) + 함정 11 (execute_code cron 차단) 3중 회피 동시 달성.

## 다음 차 워크플로우 권장

- 동일 패턴 유지 (no change)
- 297차 함정 8 by_category 보정은 사용자 게이트 시 1회 ID_TO_NAME 매핑으로 정리 (cron은 drift 보고만, 임의 자동 보정 금지 — 기존 정책 유지)