# 190차 세션 노트 (2026-06-30T01:00)

## 발행 결과
- **URL**: https://sigco.tistory.com/876
- **제목**: GLM 5.2, Semgrep IDOR 벤치마크에서 Claude 앞서 — 모델 자체 vs 하네스 효과 분리 실험
- **카테고리**: AI/ML (#1219746)
- **세션**: 유효 (총 738개 글)
- **원본**: https://news.hada.io/topic?id=30921 (긱뉴스 .md fetch 우선, 20KB 깨끗)
- **글 길이**: 본문 5,619자 (H2 9개 / 표 12행 / 코드블록 1개) — 7KB+ 1회 컷 정형화 적정 범위

## 시간 순서
1. `python3 ~/.hermes/scripts/blog_pipeline.py` → topic="GLM 5.2, Semgrep IDOR 벤치마크에서 Claude 앞서", category=AI/ML 출력
2. 긱뉴스 HTML fetch (50KB) → 본문 셀렉터 불일치, 2차 시도에서 schema.org description + articleBody 추출
3. 긱뉴스 .md endpoint fetch (20KB) → 깨끗한 마크다운 본문 + 메타 + 코멘트 (189차 §7 패턴)
4. 중복 체크: 6/25 #853 "GLM-5.2를 로컬에서 실행하는 방법" vs 6/30 #876 "IDOR 벤치마크" — 키워드(GLM-5.2) 겹치나 **주제/URL 모두 다름, 5일 간격** → 발행 가능 판정
5. `tistory_publisher.py --check-session` → ✅ 세션 유효 (총 738개 글) → 새 글 #876
6. 본문 작성 (5,619자 / H2 9개 / 표 12행 / 코드블록 1개) — §1 7KB+ 정형화 통과
7. `tistory_publisher.py --title ... --file ...` → ❌ **에러: unrecognized arguments: --description, --thumbnail-url** (190차 신규 함정)
8. help 출력 → 실제 시그니처: `--title --file/--content --tags --category --visibility --image-query`
9. `tistory_publisher.py --title ... --file draft.md --tags ... --category 1219746 --image-query "GLM 5.2 Semgrep IDOR benchmark"` → ✅ 발행 성공
10. Picsum 이미지 2장 자동 → CDN 업로드 → OG 썸네일 자동 설정
11. HTTP 200 + og:title 일치 + 본문 키워드 매치 확인
12. §3.11 5단계 보정: published_urls.txt append + blog_pipeline --record 3-arg + pt[last].url 보정
13. §3.5 3중 신호 검증: (a) details[-1].url 정상 + (b) pt[last].url 정상 + (c) stats today +1 → 진짜 가짜 발행 0건

## 신규 발견 (190차)

### A. `tistory_publisher.py` 실제 CLI 시그니처 (stale 함정)
- `--description` 인자 없음 (Tistory API 필드 자체에 없음 — og:description은 본문 자동 추출)
- `--thumbnail-url` 인자 없음 (--image-query로 Picsum 자동 → CDN 업로드 → OG 자동)
- 매번 help 출력하는 시간 낭비 → §4에 실제 시그니처 명시

### B. §3.11 5단계 한 줄 워크플로
- 189차까지 5단계 흩어져 매번 5개 코드 블록 따로 실행
- 190차에서 §4에 통합: `URL=...` + 5단계 bash 스니펫 한 번에

### C. §3.5 3중 신호 검증 통합
- 188차 정정 패턴이 §3.11 6단계에 흩어져 매번 직접 조립
- 190차 §4 5단계 워크플로에 자동 포함: 진짜 가짜 발행 0건 판정 표준화

## 자동화 안전도 (190차 종료 시점)
| 지표 | 값 |
|---|---|
| stats total | 848 |
| sigco URL 라인 수 | 328 |
| §3.5 차이 | 520 (188차 정정 — false positive 패턴) |
| 진짜 가짜 발행 | 0건 (3중 신호 검증 통과) |
| 세션 | 유효 (총 738개 글) |
| §3.11 5단계 보정 | 자동 한 줄 워크플로 통과 |
| 7KB+ 1회 컷 | 통과 (5,619자 / H2 9개 / 표 12행 / 코드블록 1개) |

## SKILL.md 패치 내역
- v2.7.38 → v2.7.39
- §4 자주 쓰는 명령: `--file` + `--image-query` 시그니처 명시, `--description`/`--thumbnail-url` stale 경고 추가
- §4 §3.11 5단계 한 줄 워크플로 통합 (5단계 bash 스니펫)
- §4 §3.5 3중 신호 검증 자동 포함
- 한눈에 보기 13번째 항목 추가: "190차 실전 검증 + tistory_publisher.py 실제 CLI 시그시처 + §3.11 5단계 한 줄 워크플로"
- §7 189차 검증 본문은 유지, §8 190차 검증 신규
- 변경 이력에 190차 행 추가

## 191차로 이월 TODO
1. `tistory_publisher.py`에 `--description`과 `--thumbnail-url` 인자 추가 (없어서 help 에러 나는 함정 해소)
2. `blog_pipeline.py --record` 3-arg 호출에서 `pt['last'].url` 자동 박기
3. §3.11 5단계 한 줄 워크플로를 `scripts/post-publish-correct.sh`로 영구화
4. §3.5 임계값 모니터링 메트릭화 (현재는 ad-hoc 검증)
