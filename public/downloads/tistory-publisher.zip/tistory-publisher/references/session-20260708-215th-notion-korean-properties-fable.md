# 215차 — Fable/reMarkable Tom Riddle 일기장 발행 + Notion 속성명 한글/영문 mismatch 함정 (2026-07-08)

## 작업 요약
- **publish**: #927 (긱뉴스 31208, AI/ML 1219746, 3,708자 → 2 Picsum images)
- **시작 drift**: 0 (Tistory=926, state=926, details=926)
- **종료 drift**: 0 (Tistory=927, state=927, details=927)
- **발행 1건 + 영구화 10종 all-green**

## §3.32.1 — Notion DB 속성명 한글/영문 mismatch (215차 발견, ⭐⭐ cleanup 진단 함정)

### 증상
§3.29.2 publish cleanup heredoc이 Notion PATCH 시 영문 `Status`/`Name`/`URL` 가정 → 실제 DB 속성명이 한글 (`상태`/`이름`/`URL`)이면:
- `props.get('Status', {})` → `{}` (키 없음)
- `status = '?'` (모든 페이지)
- `if status == '활성':` → 매칭 0건 → **0 PATCH**
- **가짜 cleanup**: active 페이지가 그대로 남음 → 무한 누적

### 215차 실전 진단 타임라인
1. **첫 시도 (영문 가정)**: 18건 매칭 / 상태 분포 0 / `총 PATCH: 0/18`
2. **DB schema dump**: `GET /v1/databases/{DB_ID}` → properties 순회
3. **속성명 확인**: `상태: select (options: ['활성', '비활성'])` / `이름: title` / `URL: url` / `등록일: date` / `카테고리: select` / `출처: select` / `마지막 사용일: date` (모두 한글)
4. **재시도 (한글 속성명)**: 18건 매칭 / `상태 분포: {'활성': 1, '비활성': 17}` / `총 PATCH: 1/18`

### 영구화 패턴
```python
# §3.32.1 — DB schema dump로 실제 속성명 확인
import urllib.request, json
hdr = {'Authorization': f'Bearer {NOTION_TOKEN}', 'Notion-Version': '2022-06-28'}
req = urllib.request.Request(f"https://api.notion.com/v1/databases/{DB_ID}", headers=hdr)
db = json.loads(urllib.request.urlopen(req, timeout=10).read())

# select + '활성'/'비활성' options 탐색
status_prop = None
for name, prop in db.get('properties', {}).items():
    if prop.get('type') == 'select':
        opts = [o.get('name') for o in prop.get('select', {}).get('options', [])]
        if '활성' in opts and '비활성' in opts:
            status_prop = name
            break
print(f"상태 속성명: {status_prop!r}")

# PATCH 시 한글 속성명 사용
patch_body = {
    "properties": {
        status_prop: {"select": {"name": "비활성"}}
    }
}
```

### 차후 작업자용 권장
1. **`scripts/notion-cleanup-v3.py`에 §3.32.1 schema dump 통합** — `--verify-only` 모드 + 스키마 dump 출력 + 한글/영문 자동 매핑
2. **cleanup heredoc은 매 실행 시 schema dump 1회** (캐시 가능) + 동적 속성명 사용
3. **fail-safe**: PATCH 후 `select.name` 응답이 `'비활성'`인지 검증 (silently failed PATCH 방지)

## §3.32.2 — Tistory 카테고리 ID vs 정규화 key 매핑 표 (215차 발견, ⭐⭐ 영구화 기준표)

| Tistory ID | Tistory name (`category` 필드) | stats 정규화 key | 비고 |
|---|---|---|---|
| 1219746 | AI 뉴스 | AI/ML | §3.28.1 alias_map |
| 1219747 | 개발 팁 | 개발 팁 | §3.29.1 정규화 |
| 1219748 | 자동화&툴 리뷰 | 개발도구 | §3.29.1 alias_map |
| 1219750 | 투자&경제 | 투자/경제 | §3.29.1 alias_map |
| 1219751 | 기타 | 기타 | 직접 매핑 |
| 1219752 | 아이디어 | 아이디어 | 직접 매핑 |

**핵심**: Tistory API `category` 필드는 Tistory의 한글 name (`'AI 뉴스'`, `'자동화&툴 리뷰'`)이며, stats 정규화 key (`'AI/ML'`, `'개발도구'`)와는 별개. `normalize_cat_key()` 통과 필수.

**§3.30.7 4번 보강**: 213차에서 "Tistory API `category` 필드는 canonical name → normalize 불필요"는 잘못된 결론. 215차에서 `1219746 → 'AI 뉴스' → 'AI/ML'` 분리 확인.

## 작업 타임라인

### 1. §3.8.1 3-endpoint probe (게이트)
- 전체 posts: 200 OK (Tistory max=926)
- AI/ML 1219746: 200 OK (Tistory max=926)
- 개발도구 1219747: 200 OK (Tistory max=920)
- ✅ ALL OK

### 2. §3.30.4 0단계 state health check
- Tistory max: 926 / state.last.id: 926 / details[-1].topic_id: 926
- last_titles: 6개 / by_category: 'AI/ML': 713
- ✅ drift 0

### 3. blog_pipeline.py --refresh-topics
- 12개 긱뉴스 토픽 (Anthropic 15점 / GLM 5.2 14점 / 저커버그 10점 / 취미 8점 / Astryx 8점 / gh-attach 7점 / J-space 6점 / GPT-5.6 5점 / 코드 청결도 4점 / Homegames 4점 / sneakerweb 3점 / **Fable 3점**)
- output JSON status=ok / source=geeknews

### 4. blog_pipeline.py --category 'AI/ML'
- score=15 Anthropic 후보 (state.last_topics에 동일 URL 박힘 → skip)
- 1순위 Fable #31208 (긱뉴스 URL `https://news.hada.io/topic?id=31208`) fallback 선택
- status=ready / category=AI/ML / tistory_category_id=1219746

### 5. 긱뉴스 .md endpoint + 본문 작성
- `https://news.hada.io/topic/31208.md` → 200 OK, 16,567 bytes
- frontmatter strip: 16,567 → 4,827자
- 한국어 heredoc 본문: 3,708자 (validate_content 3,681자)

### 6. publish_post
- title: "Fable이 reMarkable을 Harry Potter의 Tom Riddle 일기장으로 바꿈 — 손글씨로 답하는 LLM 일기장"
- category: 1219746 / visibility: public / type: post
- Picsum 이미지 2장 자동 삽입 (CDN 업로드 2/2 성공)
- OG 썸네일 자동 설정 (`https://blog.kakaocdn.net/dna/...`)
- 결과: **URL: https://sigco.tistory.com/927**

### 7. §3.11 5단계 + §4 5-1 stats 보정
- Tistory posts.json[0]: id=927 / title=Fable... / category='AI 뉴스' / categoryId='1219746' / published=2026-07-08 02:06
- normalize_cat_key('AI 뉴스') → 'AI/ML'
- state.last = {id: 927, url: https://sigco.tistory.com/927, ...}
- last_titles 7개 (Fable prefix 추가)
- last_titles_full에 Fable 추가
- details push (#927, 중복 방지)
- by_category['AI/ML']: 713 → 714
- daily_counts['2026-07-08']['AI/ML']: 1 → 2
- last_topics 정리 (Tistory URL 매칭 항목 제거)

### 8. §3.29.2 publish cleanup (Notion PATCH)
- 1단계 영문 가정 시도: 0/18 (status 모두 '?')
- DB schema dump: 한글 `상태` / `이름` / `URL` 확인
- 2단계 한글 매칭 시도: 18건 / 상태 분포 {'활성': 1, '비활성': 17} / **1/18 PATCH 성공**

### 9. §3.5 3중 신호 검증
- Tistory max: 927 / state.last.id: 927 / details[-1].topic_id: 927
- ✅ drift 0

## 영구화 all-green (215차)

| 패턴 | 차수 | 215차 결과 |
|---|---|---|
| §3.8.1 3-endpoint probe | 196차 | ✅ 200 OK 3/3 |
| §3.30.4 0단계 state health check | 213차 | ✅ drift 0 |
| §3.23.1 frontmatter strip | 206차 | ✅ 16,567 bytes → 4,827자 |
| §3.18 half-pipeline 직접 heredoc | 198~215차 | ✅ 3,708자 (validate 3,681자) |
| §3.28.1 + §3.29.1 한글 key 정규화 | 211~212차 | ✅ `normalize_cat_key('AI 뉴스')` → 'AI/ML' |
| §3.29.2 모든 매칭 PATCH | 212차 | ✅ 1/1 (활성 1건 비활성화) |
| §3.25.1 3-tier fallback | 208차 | ✅ AI/ML 1 fresh (Fable) |
| §3.5 3중 신호 검증 | 195차 | ✅ drift 0 |
| **§3.32.1 Notion 한글 속성명 매핑** (215차 신규) | 215차 | ✅ 0/18 → 1/18 (스키마 dump 후 정상) |
| **§3.32.2 Tistory ID vs 정규화 key 매핑** (215차 신규) | 215차 | ✅ 1219746='AI 뉴스' → 'AI/ML' |
| §3.29.4 긱뉴스 `.md` endpoint GN+ 응답 | 212차 | ✅ 16,567 bytes / 200 OK (212차 14,728 → 215차 16,567) |

## 차후 cleanup cron 임무 (215차 누적)
1. `scripts/notion-cleanup-v3.py`에 §3.32.1 schema dump 통합 (한글/영문 자동 매핑 + fail-safe 검증)
2. `scripts/normalize_cat_key.py --merge` 1회 실행 (by_category 변형 키 2쌍 합산)
3. `scripts/state-recovery-213th.py` 신규 (§3.30.4 0단계 health check + 자동 복구 영구화)
4. post-publish 후크 atomic write 강화 (213차 §3.30 silent corruption 방지)
5. Notion DB 자체 archive cleanup (1934 페이지 / 926 unique URL / 최대 23개 중복)

## 핵심 교훈
1. **§3.32.1 Notion 속성명 한글/영문 mismatch**: §3.29.2 cleanup heredoc은 영문 가정 → DB 스키마 dump 후 동적 매핑 필수. 215차에 0/18 → 1/18 복구 성공.
2. **§3.32.2 Tistory 카테고리 ID vs 정규화 key 매핑 표**: 단일 진실 공급원 = `normalize_cat_key()`. alias_map 신규 발견 시 추가.
3. **영구화 all-green 10종 통과**: 0단계 health check → publish → cleanup → stats 보정 → drift 검증 풀 사이클이 안정화 단계 진입.
4. **§3.30.7 4번 결론 보강**: "Tistory API `category` 필드는 canonical name → normalize 불필요"는 잘못된 결론 → 215차에서 `normalize_cat_key()` 필수 확인.
