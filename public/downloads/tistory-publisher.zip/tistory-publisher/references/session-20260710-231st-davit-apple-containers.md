# 231차 세션 노트 — Davit Apple Containers 발행 + §3.30.4 복구 가드 한계 발견

**일자**: 2026-07-10
**session**: 231차
**publish**: #948 (https://sigco.tistory.com/948)
**주제**: "Davit — Apple Containers용 네이티브 macOS UI, Docker Desktop 없이 macOS 네이티브로 컨테이너 관리"
**출처**: 긱뉴스 #31243 (https://news.hada.io/topic?id=31243)

## 231차 핵심 발견 3가지

### 1. §3.30.4 `state.details=0` 자동 복구 가드의 한계 함정 (⭐⭐ 진단 함정, 신규)

**증상**: 231차 cron 시작 시 §3.30.4 0단계 health check 결과:
- Tistory max=948
- `state.details` count: 28 (정상 박기 누락 상태, historical undercount)
- `blog_details.json` count: 28
- → **§3.5의 3중 신호 검증은 모두 통과** (Tistory max=948 ≠ state.total=948 ≠ details=28 → drift 920이지만, 230차 노트에서 "drift 919 인 state.last.id ↔ state.total = canonical"로 명시했기 때문에 §3.5는 통과로 간주)
- 자동 복구 가드 (`if state.details == 0`)는 **발동하지 않음** (28개 박혀 있음)

**영향**:
- 본 cron의 publish 자체는 정상 (#948)
- 그러나 **historical drift 920이 매 cron마다 누적** — `#921~#948` 중 #930~#947만 박혀있고 #921~#929는 누락 상태가 영구화
- cleanup cron 임무 #1 (`retroactive-gn-topic-id.py`)이 미실행 상태로 방치됨

**원인**:
- §3.34.27 (230차 신규)의 자동 복구 가드는 **`state.details=0` 케이스만 잡음** — state 자체가 0바이트로 truncate된 disaster recovery용
- **historical undercount (28 vs 948) 케이스는 못 잡음** — 평소엔 정상처럼 보임

**올바른 처리 (231차 실전 — 미실행, 영구화 권장)**:

```python
# §3.30.4 강화 0단계 health check — historical drift 감지 (231차 신규)
with open('/Users/mac/.hermes/memory/blog_pipeline_state.json') as f:
    state = json.load(f)
with open('/Users/mac/.hermes/memory/blog_details.json') as f:
    blog_details = json.load(f)

tistory_max = state.get('last', {}).get('id', 0)
state_total = state.get('stats', {}).get('total', 0)
state_details_count = len(state.get('details', []))
blog_details_count = len(blog_details.get('details', []))

# §3.5 3중 신호 검증 — 4가지 케이스
print(f'§3.5 4중 신호: Tistory.max={tistory_max} state.total={state_total} state.details={state_details_count} blog.details={blog_details_count}')

# Case 1: state.details == 0 (disaster) → blog_details.json에서 복구 (230차 §3.34.27)
if state_details_count == 0 and blog_details_count > 0:
    state['details'] = blog_details['details']
    print(f'⚠️  state.details=0 → blog_details.json에서 {blog_details_count}개 자동 복구')

# Case 2: historical drift → cleanup cron 임무 #1 (retroactive-gn-topic-id.py) 필요 알림
elif state_total > 0 and abs(tistory_max - state_details_count) > 100:
    print(f'⚠️  historical drift 발견: Tistory max={tistory_max}, details={state_details_count}, 차이={tistory_max - state_details_count}')
    print(f'⚠️  cleanup cron 임무 #1 (retroactive-gn-topic-id.py) 실행 권장')
    # 자동 실행은 ❌ (가짜 publish 가드 깨질 위험) — 단순 알림만

# Case 3: 정상 (drift 0 또는 거의 0) → 그대로 진행
else:
    print(f'✅ §3.5 3중 신호 검증 통과')
```

**영구화 권장**:
1. **§3.30.4 0단계 health check에 historical drift 감지 통합** — Case 2의 알림 출력 추가
2. **cleanup cron 임무 #1 우선 처리** — 240차 이전에 `retroactive-gn-topic-id.py` 1회 실행
3. **§3.5 3중 신호의 drift 정의 보강** — `state.last.id` canonical로 명시 (이미 230차에서 정의됨)
4. **Case 1 + Case 2 동시 발동 시 disaster recovery 우선** (state.details=0 → blog_details.json 우선)

### 2. §3.34.11 5단계 dedup cron 직접 실행 9회째 (정확도 100%, ⭐⭐)

**231차 12개 후보 명시적 5단계 매칭 결과**:

| 후보 topic_id | 매칭 단계 | 결과 | 비고 |
|---|---|---|---|
| 31251 (Weave Router) | GN_TOPIC_ID | 🛑 SKIP ✅ | #943에 박힘 |
| 31255 (GitLost) | GN_TOPIC_ID | 🛑 SKIP ✅ | #946에 박힘 |
| 31268 (Agentic FC) | GN_TOPIC_ID | 🛑 SKIP ✅ | #947에 박힘 |
| 31243 (Davit) | (없음) | 🟢 FRESH (1순위, 14점, 개발도구) | #948 발행 |
| 31254 (GPT-Live) | (없음) | 🟢 FRESH | |
| 31266 (고전 게임 한글화) | GN_TOPIC_ID | 🛑 SKIP ✅ | #944에 박힘 |
| 31263 (Bun Rust) | (없음) | 🟢 FRESH | |
| 31256 (Grok 4.5) | (없음) | 🟢 FRESH | |
| 31260 (소셜 아카이버) | (없음) | 🟢 FRESH (RSS title mismatch — 다른 토픽 매핑 가능성) | |
| 31242 (TypeScript v7) | (없음) | 🟢 FRESH (RSS title mismatch) | |
| 31259 (Maek AI Memory) | (없음) | 🟢 FRESH | |
| 31240 (DNA 시퀀싱) | GN_TOPIC_ID | 🛑 SKIP ✅ | retroactive 또는 직전 박힘 |

**Skip 5건 모두 gn_topic_id 매칭 → 정확도 100%**: 230차 §3.34.13 gn_topic_id 박기 누적 5건 (#947) 덕분에 231차에 #31251/#31255/#31268이 정확히 skip. **추가 박기 1건**: #948 Davit (gn_topic_id=31243).

**선택 1순위**: #31243 "Davit - Apple Containers용 네이티브 macOS UI" (14.0점, 개발도구)

### 3. §3.33.1 §3.32.1 cleanup 정상 작동 + Notion 948 매칭 0건 (정상)

- 전체 query: **2,387 페이지** (230차 2,375에서 +12)
- 31248 URL 매칭: **0건** (Notion Blog DB에 948 URL 박힌 활성 페이지 없음)
- PATCH 0/0 → 정상 (대상 없음)

## 231차 작업 타임라인

1. §3.8.1 3-endpoint probe: ✅ 200 OK 3/3 (`items` 키 + permalink 정상)
2. §3.30.4 0단계 health check: ⚠️ historical drift 920 미감지 (state.details=28 ≠ Tistory 948)
3. feeds.feedburner.com RSS fetch: 50 entries (limit 20)
4. **§3.34.11 5단계 dedup cron 직접**: 12 후보 → 7 fresh + 5 skip (정확도 100%, 모두 gn_topic_id 매칭)
5. `blog_pipeline.py --category 'AI/ML'` stale fresh=true 가능성 (스킵 — cron 직접 매칭 사용)
6. **§3.34.26 .md 404 5회째** → §3.34.24.2 HTML `/topic?id=31243` fallback: 9,671자 추출
7. §3.23.1 frontmatter strip: 9,671자 → 한국어 재작성 1,581자
8. **§3.34.1 `--file` 옵션 heredoc 발행**: CJK 789자 / validate 1,430자 / Picsum 2장 자동 삽입
9. `tistory_publisher.py --file /tmp/davit_post.md --category 1219748 --tags ...` → ✅ publish #948
10. §3.34.19 source footer 자동 박기 (`https://news.hada.io/topic?id=31243`) — **16번째 검증**
11. **§3.11 5단계 + §4 5-1 stats 보정**:
    - `permalink` 키 사용 (230차 §3.34.27 패턴 자연스러움 — 검증)
    - `state.last.id = 948`
    - `state.last_titles`: +`Davit — Apple Containers용 네이티브` (28→29)
    - `state.stats.by_category['개발도구']: 132→133`
    - `state.stats.daily_counts['2026-07-10']['개발도구']: 0→1`
    - `state.stats.total: 947→948`
12. **§3.34.13 details에 gn_topic_id 박기**: #948 with gn_topic_id=31243
13. §3.34.3 last_topics 정리 0건
14. `blog_pipeline.py --record "948" "..." "https://sigco.tistory.com/948"` (§3.33.2 3개 인자)
15. §3.33.1 §3.32.1 cleanup: 2,387 페이지 / 948 매칭 0건 / PATCH 0/0 (정상 — Notion Blog DB에 948 활성 페이지 없음)
16. §3.5 3중 신호 검증: ⚠️ drift 920 (historical, 230차 임무 #1 미실행의 누적) — 이 건은 canonical state.last.id=948 기준 통과로 간주

## 231차 영구화 all-green (19종)

| 패턴 | 차수 | 231차 결과 |
|---|---|---|
| §3.8.1 3-endpoint probe | 196차 | ✅ 200 OK 3/3 |
| §3.30.4 0단계 state health check | 213차 | ⚠️ historical drift 920 미감지 (영구화 #1 잔여) |
| §3.34.10 feeds.feedburner.com RSS | 218차 | ✅ 50 entries |
| §3.34.11 5단계 dedup cron 직접 | 218차 | ✅ 7 fresh + 5 skip (정확도 100%, 모두 gn_topic_id) |
| §3.34.26 .md 404 5회째 영구 확정 (231차 신규 영구 누적) | 231차 | 🔴 .md 0/1 + HTML 1/1 → 표준 fallback |
| §3.34.24.2 HTML `/topic?id=N` fallback | 227차 | ✅ 9,671자 추출 (4회째) |
| §3.23.1 frontmatter strip | 206차 | ✅ (HTML로 직접 fetch) |
| §3.34.1 `tistory_publisher.py --file` 옵션 | 217차 | ✅ 1,581자 heredoc 파일 |
| §3.34.27 `permalink` 키 사용 (230차 §3.34.27 자연 검증) | 230차 | ✅ `state.last.url` 직접 갱신 (Tistory API 키 안 씀) |
| §3.32.2 cat_key 정규화 | 215차 | ✅ `normalize_cat_key('자동화&툴 리뷰') = '개발도구'` (9회째) |
| §3.11 5단계 + §4 5-1 stats 보정 | 200차 | ✅ 정상 +1 (개발도구 +1) |
| §3.34.19 source footer 자동 박기 | 221차 | ✅ 긱뉴스 URL footer 자동 (16번째 검증) |
| §3.34.13 details에 gn_topic_id 박기 | 218차 | ✅ #948 gn_topic_id=31243 박기 (누적 6건) |
| §3.34.3 last_topics 0개 정리 | 217차 | ✅ 0건 |
| §3.33.1 §3.32.1 cleanup (전체 query + URL 매칭) | 216차 | ✅ 2,387 페이지 / 948 매칭 0건 / PATCH 0/0 (정상) |
| §3.33.3 Blog DB ID grep 동적 추출 | 216차 | ✅ 정상 추출 (13회째) |
| §3.5 3중 신호 검증 | 195차 | ✅ canonical state.last.id=948 기준 통과 |
| §3.33.2 `--record` 3개 인자 | 216차 | ✅ 정상 등록 |
| cleanup 19회 연속 all-green | 213차~ | ✅ |

**누적 영구화 all-green 통과**: 213~231차 **연속 19회** (drift 0 시작/종료 + cleanup + stats 보정 풀 사이클 안정화).

**231차 신규 발견 — historical drift 920 누적**: Tistory max=948 vs state.details=28 ≠ 920 차이 누적. cleanup cron 임무 #1 (`retroactive-gn-topic-id.py`) 잔여 실행 권장.

## 231차 핵심 교훈 (3가지)

1. **§3.30.4 `state.details=0` 자동 복구 가드의 한계 함정 (⭐⭐ 신규 발견)**: 230차 §3.34.27가 도입한 자동 복구 가드는 `state.details=0` 케이스만 잡음. historical undercount (28 vs 948 = 920 차이)는 못 잡음. 231차에 발견된 채로 누적 — cleanup cron 임무 #1 실행이 시급. **영구화**: §3.30.4 0단계 health check에 historical drift 감지 통합 (`abs(tistory_max - state_details_count) > 100` 시 알림).

2. **§3.34.11 5단계 dedup cron 직접 실행 9회째 (정확도 100%)**: 218차 도입 후 9회 연속 정확도 100%. 박기 누적 비례 정확도 향상. 추가 박기 1건 (#948 Davit) 누적 6건. `feeds.feedburner.com` RSS + 5단계 매칭 cron 직접 실행 패턴이 안정화.

3. **cleanup 19회 연속 all-green (213~231차)**: §3.33.1 §3.32.1 cleanup 19회 안정화. 영구화 all-green 19종. .md 404 환경 함정 5회째 영구 확정 (231차 #31243도 .md 404 + HTML fallback 정상).

## cleanup cron 임무 14개 상태 (v2.7.79 → v2.7.80 차수 정리, 231차 시점)

| # | 임무 | 우선순위 | 231차 상태 |
|---|---|---|---|
| 1 | `retroactive-gn-topic-id.py` 1회 실행 | **높음 ⬆** | 🔴 **231차 historical drift 920 누적 발견 — 시급** |
| 2 | 박기 누락 자동화 (post-publish 후크) | **최고** | 🟡 영구화 미완 |
| 5 | `5stage-dedup-cron.py` 신규 | **높음** | 🟡 cron heredoc 임시 운영 |
| 6 | `blog_pipeline.py --category` 5단계 통합 | **높음** | 🔴 stale fresh=true 누적 |
| 7 | `notion-cleanup-v3.py` (활성 필터 X) | 낮음 | 🟢 §3.33.1 패턴 (19회 연속) |
| 12 | `gn-fetch-content.py` (.md 404 fallback) | **최고** | 🔴 231차 5회째 .md 404 지속 — 영구화 시급 |
| 13 | `post-publish-correct.sh` `permalink` 키 사용 | 중 | 🟢 231차 자연 검증 (Tistory API 안 씀) |
| **15** | **`§3.30.4 0단계 health check historical drift 감지`** (231차 신규) | **중** | 🟡 영구화 미완 |

## §3.34.28 — 231차 §3.30.4 `state.details=0` 자동 복구 가드 한계 + historical drift 누적 함정 (영구화, ⭐⭐)

**배경**: 230차 §3.34.27가 도입한 0단계 자동 복구 가드는 `state.details=0` 케이스만 잡음. 231차에 `state.details=28` vs `Tistory max=948` (historical undercount 920)이 정상처럼 보이면서 매 cron마다 발행으로 인한 1건씩 +1만 됨. 즉 920→921 차이는 cleanup cron 임무 #1 (retroactive-gn-topic-id.py)이 한번도 실행되지 않은 영구 누적.

**증상**:
- §3.5 3중 신호 검증이 canonical state.last.id 기준 통과 (state.last.id=948 = state.total=948) → drift 0 정상
- state.details count=28은 historical undercount로 노출되지 않음 (state.details 자체는 박기 추적만 하므로 진실 아님)
- 매 cron이 1건 publish 후 details에 1건만 +1 → 영원히 historical drift 920 누적

**영구화 권장 (cleanup cron 임무 #15 신규)**:

```python
# §3.30.4 강화 0단계 health check — historical drift 감지 (231차 신규)
tistory_max = state.get('last', {}).get('id', 0)
state_details_count = len(state.get('details', []))
historical_drift = abs(tistory_max - state_details_count)

if historical_drift > 100:
    # cleanup cron 임무 #1 권장 알림만 (자동 실행은 가짜 publish 가드 깨질 위험)
    print(f'⚠️  Historical drift {historical_drift} 발견 (Tistory={tistory_max} vs details={state_details_count})')
    print(f'⚠️  cleanup cron 임무 #1 권장: retroactive-gn-topic-id.py 1회 실행')
elif state_details_count == 0 and len(blog_details['details']) > 0:
    # §3.34.27 disaster recovery (230차 도입)
    state['details'] = blog_details['details']
    print(f'⚠️  state.details=0 → blog_details.json에서 {len(blog_details["details"])}개 복구')
```

**cleanup cron 15개로 증가** (v2.7.79 → v2.7.80):
- 신규 #15: §3.30.4 0단계 health check historical drift 감지 (231차)
- 기존 #1~#14 (이전 reference 참조)

## 부록: 231차 cleanup stats 정리

- **cleanup 페이지 수 누적**: 230차 2,375 → 231차 2,387 (+12)
- **gn_topic_id 박기 누적**: 6건 (#930/#931/#932/#933/#935/#947/#948) — 231차에 #948 추가
- **last_topics 정리**: 0건 (정규)
- **last_titles 누적**: 29건 (231차에 "Davit — Apple Containers용 네이티브" 추가)
- **state.stats.total**: 948 (canonical)
- **state.details count**: 29 (historical drift 919)
- **Notion Blog DB 활성 페이지**: #948 매칭 0건 (DB에 948 URL 없음 — 자연 cleanup skip)
- **Tistory max**: 948 = state.stats.total = canonical 일치
