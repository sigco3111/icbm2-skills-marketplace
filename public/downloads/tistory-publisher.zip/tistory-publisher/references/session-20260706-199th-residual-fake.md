# 199차 세션 (2026-07-06 19:08 KST) — half-pipeline cron 자동화 첫 실전 + 잔재 가짜 발행 검출

## 컨텍스트
- 작업: ICBM2 Tistory 자동 발행 cron
- §3.8.1 세션 가드: ✅ 통과 (status 200, cookie valid)
- §3.14 half-pipeline 패턴 적용: `blog_pipeline.py --category` 미사용, LLM이 본문 직접 작성 → `tistory_publisher.py --file`로 발행

## 주요 발견 ① — 197차 롤백 잔재물

cron 진입 시 상태 점검 중 발견:

### 발견된 잔재
| 위치 | 내용 | 197차 롤백 시 정리됐나? |
|---|---|---|
| `last_topics` | `{topic: "round3-unit-test", url: "https://sigco.tistory.com/996", ...}` | ❌ **잔존** (1건) |
| `published_urls.txt` | `tistory.com/996`, `997`, `998`, `999` 4줄 | ❌ **잔존** (4건) |
| `details` | `round3-dedup-test` × 4건 | ❌ **잔존** (4건) |
| `daily_counts[2026-07-06].AI/ML` | 1 (fake unit test) | ❌ **잔존** |
| `stats.total_published` | 890 (= 889 + 1 fake) | ❌ **잔존** |
| `stats.by_category.AI/ML` | 698 (= 697 + 1 fake) | ❌ **잔존** |

**원인 분석**: 197차 롤백 코드는 `last_topics[-1]` pop + `daily_counts[date][cat] -= 1` + `stats.total -= 1`만 했음. `published_urls.txt`와 `details`의 round* prefix 필터는 누락. 198차(희정님 수동 세션)는 `last_topics`를 완전히 덮어쓰면서 자연 소멸했지만, **cron 자동화처럼 append-only 경로에서는 잔재가 영구히 남음**.

### 즉시 롤백 (199차 1단계)
```python
# (a) last_topics 필터
real_topics = [x for x in state['last_topics'] 
               if not ('/99' in x.get('url','') and '/990' <= x['url'][-3:] <= '/999')
               and not any(x.get(k,'').lower().startswith(p) for k in ['topic','title'] 
                          for p in ['round','test','debug'])]
state['last_topics'] = real_topics

# (b) stats 차감
state['daily_counts']['2026-07-06']['AI/ML'] -= 1  # 1 → 0
state['stats']['total_published'] -= 1  # 890 → 889
state['stats']['by_category']['AI/ML'] -= 1  # 698 → 697

# (c) details 필터
pt['details'] = [x for x in pt['details'] 
                 if not any(str(x.get(k,'')).lower().startswith(p) for k in ['topic','title'] 
                            for p in ['round','test','debug'])]

# (d) published_urls.txt 정리
urls_p.write_text('\n'.join([l for l in content.splitlines() 
                              if not ('tistory.com/99' in l 
                                     and any(f'/99{x}' in l for x in [6,7,8,9]))]))
```
- 롤백 후: total=889, AI/ML=697, today AI/ML=0, last_topics에 Safari MCP(#905)만 남음

## 주요 발견 ② — half-pipeline 패턴 cron 자동화 첫 실전

### 발행 결과
- **#906 OpenTag** — Slack용 Claude Tag의 오픈소스 대안, 그리고 셀프 호스팅 AI 에이전트의 진짜 가치
- 긱뉴스 #31158 (score 16.0, AI/ML)
- 본문: 7,770자 / 10 H2 / 표 2개 / Picsum 이미지 2장 자동 삽입 / OG 썸네일 자동 설정
- 1회 컷 (5,716자+ 정형화 충족)

### 워크플로
1. **세션 가드** (§3.8.1) — manage/posts.json probe status 200
2. **트렌드 갱신** — `blog_pipeline.py --refresh-topics` (12 topics)
3. **중복 검사** — `tistory_duplicate_checker.py --title ...` (0 matches / 756 sources)
4. **본문 작성** — `/tmp/draft_opentag.md` (LLM 직접 작성, 198차 §3.14 half-pipeline)
5. **HTML 변환** — `markdown_to_tistory_html.py` (18,148 bytes)
6. **발행** — `tistory_publisher.py --file ... --image-query "open source ai agent slack bot terminal"`
7. **§3.11 5단계 + §4 5-1 stats 보정** — last + details + published_urls + daily_counts + total + by_category + last_topics
8. **§3.5 3중 신호 검증** — details[-1]=#906, last=#906, today AI/ML=1
9. **Layer 3 max ID 비교** — manage/posts.json 5페이지 max=906 = publish target ✅

### §3.5 검증 결과
| 신호 | 값 | 통과 |
|---|---|---|
| Tistory manage/posts.json 최신 | #906 OpenTag | ✅ |
| details[-1].url | https://sigco.tistory.com/906 | ✅ |
| last.url | https://sigco.tistory.com/906 | ✅ |
| daily_counts[2026-07-06] | {AI/ML: 1, 개발도구: 0, 개발팁: 1} | ✅ |
| stats.total_published | 890 | ✅ |
| stats.by_category.AI/ML | 698 | ✅ |
| last_topics[-1] | OpenTag #906 19:08 | ✅ |
| Tistory HTTP 200 | 74,099 bytes | ✅ |
| og:title 매치 | "OpenTag — Slack용 Claude Tag..." | ✅ |
| 본문 키워드 매치 | grep -q "OpenTag" | ✅ |
| 5페이지 max ID | 906 = publish target | ✅ |

## §3.16 — Tistory vs stats 누적 drift 분석

**관측값**:
- `stats.total_published` = 890
- Tistory `manage/posts.json` `totalCount` = 769
- **누적 drift = 121**

**199차 단일 세션 drift**:
- stats delta: 889 → 890 = +1
- Tistory delta: 768 → 769 = +1
- **세션 drift = 0** ✅

**결론**: 121 drift는 195차 이전까지 누적된 legacy 차이. 199차가 늘린 게 아님. 단독 정리는 별도 cron 작업이 필요하지만 이번 임무 외.

## §3.15 — Layer 3 강화 권장 사항

`scripts/rollback-fake-publish.sh` 또는 다음 cron 진입 시 자동 실행할 권장 패턴:

```bash
# (1) published_urls.txt 페이크 ID 패턴
grep -E 'tistory\.com/9[6-9][0-9]' ~/.hermes/memory/published_urls.txt

# (2) Tistory max ID vs last_url 비교
# (5페이지 manage/posts.json 순회, max(id) 추출)
# if max_id > 905 and last_url_int < max_id - 5:  # 잔재 가능성 경고
#   → manual review 권장

# (3) round/test/debug prefix scan
grep -iE '"(topic|title)":\s*"(round|test|debug)' \
     ~/.hermes/memory/blog_pipeline_state.json
```

**권장 빈도**: cron 진입 시 매회 (1초 이내) + 주 1회 종합 정리 (희정님 결정 후 적용).

## 다음 cron (200차+) 이월 TODO

1. **§3.15 Layer 3 자동화** — 위 3가지 grep을 cron 진입 시 heredoc으로 자동 실행 + 잔재 발견 시 알림
2. **누적 drift 121 정리** — `stats.total`을 Tistory max ID와 정합화 (단, by_category/daily_counts도 같이 — 희정님 결정 필요)
3. **§3.14 pre-increment → post-increment 이관** — `run_pipeline()` 2-phase split (희정님 옵션 (i) 결정 보류 중)
4. **§3.14 `--guideline-only` 플래그** — 옵션 (ii) 보류 중

## 부수 발견

- **`tistory_publisher.py` `--record-topic` 자동 동기화 무효화 3회째 재현** (193→194→199): 199차도 cron 자동 경로에서 자동 동기화 안 됨. §3.11 5단계 수동 보정 **영구화 필수** 재확인.
- **Picsum 키워드 다양성**: `open source ai agent slack bot terminal` → 2장 매치 (id/59 + id/876). 198차 `improving tools abstract circuit board`와 비교 시 키워드가 구체적일수록 다른 id 매치.
- **Notion DB 갱신 정상**: 12개 긱뉴스 주제 추가, 12개 비활성화, 0 실패.
- **세션 만료 시점 추정**: 7/2 06:53 → 7/6 06:53 = 정확히 4일. 다음 만료 가설 모니터링 (8일 주기는 196차 가설이었지만 4일이 실측).
