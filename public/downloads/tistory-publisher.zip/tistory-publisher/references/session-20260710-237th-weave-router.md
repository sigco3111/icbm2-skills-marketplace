# 237차 — Weave Router 발행 (2026-07-10)

## 요약
- 1순위 #31251 "Weave Router" #954 발행 (AI/ML, CJK 1,765자 / Picsum 2장 → Kakao CDN 54KB+89KB / source footer **22번째 검증**)
- `--image-query router` 정상 동작 (router-0=311, router-1=515)
- 12 후보 dedup 결과: 10 fresh + 2 dup (31266/31263 — 어제 발행분)
- cleanup **24회 연속 all-green** (213~237차)

## §3.34.33 — `post-publish-correct.sh` 가 stats에 `category_id`를 key로 박는 신규 함정 (NEW)

`post-publish-correct.sh` 5-1단계 stats 보정 heredoc은 `state['stats']['daily_counts'][date][cat_id]` 패턴으로 박는다. 여기서 `cat_id`는 **Tistory int ID 문자열** (`"1219746"`). 

```python
# post-publish-correct.sh 내부 (실제 heredoc 발췌)
cat_id = "1219746"  # 6번째 arg (CATEGORY)
dc = stats['daily_counts']
day_entry = dc.setdefault(today_str, {})
day_entry[cat_id] = day_entry.get(cat_id, 0) + 1  # ❌ '1219746' 키 박힘
```

**결과**: `stats.daily_counts['2026-07-10']` = `{'AI/ML': 3, '개발도구': 1, '개발팁': 1, '1219746': 1}` (4개 키). §3.5 검증 시 `day_entry.get('AI/ML', 0) >= 1` 체크는 통과하지만, `by_category`에는 `AI/ML`이 +1 안 됨 (의도 미반영). **가짜 통계 누적이 아님 — `1219746` 키가 day_entry에만 박힘** (237차 검증: by_category는 `1219746` 키 0개, day_entry에만 1개).

**§3.28.1 한글 key 매핑 패턴은 `sh` 스크립트 heredoc에 적용 안 됨** — 5-1단계가 `cat_id`를 직접 사용. `post-publish-correct-recipe.md`의 5단계 보정 heredoc (수동 호출 버전)은 한글 key `'AI/ML'` 직접 사용이므로 정상.

**정답 보정 (6단계 state sync heredoc에 추가)**:
```python
# 1) post-publish-correct.sh가 박은 가짜 키 제거
day_entry = dc.setdefault(today, {})
if '1219746' in day_entry:
    del day_entry['1219746']  # post-publish-correct.sh 박기 무효화
# 2) 한글 key 'AI/ML'로 +1
day_entry['AI/ML'] = day_entry.get('AI/ML', 0) + 1
```

**영구화 권장 (다음 cron 작업자용)**:
1. `post-publish-correct.sh` 실행 후 **반드시** 6단계 state sync heredoc 실행 (§3.34.31 + 6단계에 `del day_entry['1219746']` 1줄 추가)
2. 또는 `post-publish-correct.sh` 자체를 패치 (5-1단계 cat_id → CAT_KEY_MAP 매핑) — 다음 cleanup cron 임무 #16 후보
3. §3.5 검증 `day_entry.get('AI/ML', 0) >= 1` 체크는 post-sh 실행 직후 실패할 수 있음 — 보정 후 재검증

## §3.34.34 — `gn-fetch-content.py` CLI는 300자 preview만 출력 (NEW, 사소)

`scripts/gn-fetch-content.py <topic_id>` CLI는 `print(content[:300])`만 stdout에 출력. **전체 본문이 필요한 경우 `importlib.util`로 모듈 로드**해서 `fetch_gn_content(tid)` 직접 호출:

```python
import importlib.util
spec = importlib.util.spec_from_file_location("gfc", "/Users/mac/.hermes/skills/automation/tistory-publisher/scripts/gn-fetch-content.py")
mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
result = mod.fetch_gn_content(31251)  # (title, content, url) 또는 None
```

**사소하지만 cron 작업 시 본문 작성에 필요**. 또는 `python3 -c "import sys; sys.path.insert(0, '/Users/mac/.hermes/skills/automation/tistory-publisher/scripts'); from gn_fetch_content import fetch_gn_content; ..."` 형태로 path 추가.

## §3.34.35 — `--image-query router` 카테고리 자동 라우팅 (NEW, 237차 첫 실전)

- `--image-query router` → Picsum 자동 2장 (router-0=311, router-1=515), Kakao CDN 업로드 54KB+89KB
- 헤더 `image-query` 검색어 → 자동 Picsum ID 매핑. Picsum ID 311 = 폭포 사진, 515 = 커피/노트북. "router" 추상 검색어에도 reasonable 매칭
- cron 프롬프트에 `--image-query` 인자 누락 시 → 자동 생략되며 본문 그림 0장 가능. **반드시 cron에서 `--image-query <topic keyword>` 전달 권장**

## 6단계 state sync heredoc (237차 실행본, 238차+ 재사용)

```python
import json
from datetime import date, datetime

with open('/Users/mac/.hermes/memory/blog_pipeline_state.json') as f:
    state = json.load(f)
with open('/Users/mac/.hermes/memory/published_topics.json') as f:
    pt = json.load(f)

today = date.today().isoformat()
now_iso = datetime.now().isoformat(timespec='minutes')

# 1) state.last 갱신
state['last'] = {
    'url': NEW_URL,  # 'https://sigco.tistory.com/954'
    'title': TITLE,
    'gn_topic_id': GN_TOPIC_ID,
    'category': CATEGORY_NAME,  # 'AI/ML'
    'category_id': CATEGORY_ID,  # 1219746
    'source_url': SOURCE_URL,
    'date': today,
}

# 2) state.details append
state['details'].append({
    'topic_id': TOPIC_ID,  # 954
    'title': TITLE,
    'url': NEW_URL,
    'date': today,
    'category': CATEGORY_NAME,
    'category_id': CATEGORY_ID,
    'gn_topic_id': GN_TOPIC_ID,
    'source_url': SOURCE_URL,
    'topic': str(GN_TOPIC_ID),
})

# 3) stats.daily_counts: post-sh 가짜 키 제거 + 한글 key +1
dc = state['stats'].setdefault('daily_counts', {})
day_entry = dc.setdefault(today, {})
if str(CATEGORY_ID) in day_entry:
    del day_entry[str(CATEGORY_ID)]
day_entry[CATEGORY_NAME] = day_entry.get(CATEGORY_NAME, 0) + 1

# 4) total_published += 1
state['stats']['total_published'] = state['stats'].get('total_published', 0) + 1

# 5) last_post 갱신 (cron 검증용)
state['last_post'] = {
    'url': NEW_URL, 'title': TITLE,
    'gn_topic_id': GN_TOPIC_ID,
    'category': CATEGORY_NAME, 'category_id': CATEGORY_ID,
    'source_url': SOURCE_URL, 'date': today,
    'published_at': now_iso,
}

# 6) last_titles / last_titles_full 갱신 (있으면)
if 'last_titles' in state:
    state['last_titles'] = [TITLE] + list(state.get('last_titles', [''])[1:])
if 'last_titles_full' in state:
    state['last_titles_full'] = [TITLE] + list(state.get('last_titles_full', [''])[1:])

with open('/Users/mac/.hermes/memory/blog_pipeline_state.json', 'w') as f:
    json.dump(state, f, ensure_ascii=False, indent=2)
```

## 검증 (§3.5 3중 신호)
```
(1) state.details[-1].url: https://sigco.tistory.com/954
(2) pt.last.url: https://sigco.tistory.com/954
(3) stats.daily_counts[2026-07-10]: {'AI/ML': 4, '개발도구': 1, '개발팁': 1}
(4) state.last.url: https://sigco.tistory.com/954
(5) total_published: 34
(6) state.last_post.url: https://sigco.tistory.com/954
판정: ✅ ALL GREEN
```

## 237차 후속 권장 (cleanup cron 임무 후보)
- **임무 #16 (NEW)**: `post-publish-correct.sh` 5-1단계 패치 — `cat_id` → CAT_KEY_MAP 매핑 후 한글 key로 박기
- 임무 #1 잔여: `retroactive-gn-topic-id.py` 영구화 (231차 시급성 최대, 미실행)
- 임무 #12 잔여: `gn-fetch-content.py` 영구화 claim 거짓 (233차 검증, 미실행)
