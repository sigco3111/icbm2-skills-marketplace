# 362차 (2026-08-07 02:01) — #1198 Discovery Loop

**결과**: `#1198` "Discovery Loop — Jeff Dean이 만드는 과학 실험 자동화 AI 시스템"
(gn=32186, AI/ML, 본문 3,079자 / 발행 측정 3,013자 + Picsum 2장 + Python 코드 1개).
연속 all-green **135회차**. daily_counts={AI/ML:3}, total=153.

## 카운터

- 단일 패스 **47연속**
- §3.5 신호 4 disambiguate **28연속**
- 진입 5-5 **27연속**
- fallback 복귀 **39연속** (이번 차는 AI/ML 직접, fallback 미진입)
- 함정 8 `by_category["1219746"]=1` 잔재 **66연속**
- §3.5 신호 4 admin API 교차 검증 **2회차** (361차 신규 → 362차 재확인)

## 함정 32 신규 — 중복 검사 스크립트 `int` topic 크래시

publish 전 dedup 검사에서 `published_topics.json` / `blog_pipeline_state.json`의
`details[].topic` 값을 문자열로 가정하고 `.lower()`를 호출하면 즉시 죽는다.

```
AttributeError: 'int' object has no attribute 'lower'
```

**원인**: `topic` 필드는 대부분 문자열(`"Discovery Loop"`, `"32186"`)이지만,
과거 차수에서 긱뉴스 topic id가 **정수형 그대로** 박힌 entry가 섞여 있다.
`d.get('topic','')`는 기본값만 방어할 뿐 int 값 자체는 그대로 반환한다.

**해결**: dedup 비교 시 모든 필드를 `str()`로 감싼다.

```python
hits = [d for d in pt.get('details', [])
        if d.get('hash') == h
        or topic.lower() in str(d.get('topic', '')).lower()
        or topic.lower() in str(d.get('title', '')).lower()]
```

`title`도 동일하게 감쌀 것 — 같은 계열 오염 가능성이 있다.
함정 14(`import os` 누락) / 함정 23(변수명 오타)과 같은 "검증 단계 자체가 죽는" 계열.
**중복 검사가 죽으면 publish 진입 판정을 못 하므로 무조건 먼저 고치고 재실행**한다
(검사 실패를 "중복 없음"으로 간주하고 진행하면 안 됨).

## 긱뉴스 본문 전체 추출 레시피 (함정 3 확장)

이번 차는 og:description이 **160자에서 잘려서** 5개 섹션 본문을 짜기에 부족했다.
그리고 구조 셀렉터는 둘 다 실패했다:

- `<div class="topic_contents">` → NO MATCH
- `itemprop="articleBody"` → NO MATCH

**작동한 방법** (script/style 제거 후 전체 텍스트에서 앵커 슬라이스):

```python
import requests, re
s = requests.get('https://news.hada.io/topic?id=NNNNN',
                 headers={'User-Agent': 'Mozilla/5.0'}, timeout=20)
t = re.sub(r'<script[^>]*>.*?</script>', ' ', s.text, flags=re.S)
t = re.sub(r'<style[^>]*>.*?</style>',  ' ', t,      flags=re.S)
txt = re.sub(r'\s+', ' ', re.sub(r'<[^>]+>', ' ', t))
i = txt.find('앵커_소제목')          # og:description 끝부분 단어를 앵커로
print(txt[i:i+2500] if i > 0 else txt[:2500])
```

362차 실측: 2,500자 규모의 본문 + **HN 토론 코멘트까지** 한 번에 확보돼,
"회의적인 시선" 섹션(정책 병목 / 태양광 이미 경제성 확보 / Karpathy autoresearch 유사성)을
근거 있게 쓸 수 있었다. 347차의 "HN 코멘트 컨텍스트 활용" 패턴을 셀렉터 없이 재현한 셈.

**판정**: og:description이 200자 미만이면 이 전체 텍스트 추출로 바로 넘어간다.
`<script>` 제거를 빼먹으면 JSON-LD 블록이 그대로 섞여 앵커 검색이 오염된다 — 이 두 줄이 핵심.

## 보고서 산문 자체의 CJK 혼입 (함정 26 계열, 경미)

최종 보고 라인을 쓰는 중 한국어 `관리 목록`이 `管理 list`로 섞여 나가 자체 정정했다.
함정 26의 CJK swap이 **빌드 스크립트뿐 아니라 최종 응답 산문에서도** 나타날 수 있다.
빌드 파일 3종 grep과 별개로, 발행 보고 문장도 한 번 훑고 내보낸다.

## 정형 재현 확인 (새 함정 아님)

- §3.8.1 raw 가드: cookies_count=8, status=200, `first_ids=['1197'…]`
- `--content` 단일 폴백 정형 (`--file` 미사용)
- parts.append() 23줄 + `code_lines` 리스트 분리 (코드 1개)
- 빌드 3종 grep: CJK 0 / mojibake 0 / `parts.append` 27→23회 expected 일치
- sibling write warning **미발생**
- 5-3 (state) → 5-2-A (published_topics) 순서 준수, 백필 1건
- canonical hash = 원본 topic `Discovery Loop`의 md5 `f948c03caadeb5c0b566c32713c0b8c4`
- 5-5 proxy: 200 + og:title 정확 + source_present=True + img 2
- admin 교차: `admin_first_ids=['1198','1197','1196','1195']`, 최상단 제목 일치
