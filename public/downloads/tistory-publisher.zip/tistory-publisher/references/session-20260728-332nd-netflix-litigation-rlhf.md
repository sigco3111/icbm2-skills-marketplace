# 332차 세션 노트 — Netflix 신뢰 훈련 소송 (2026-07-28 22:01)

**발행 #1127** — "Netflix 직원, 리트릿 신뢰 훈련에서 개인사 공유 후 해고됐다며 소송 — 신뢰 모델이 흔들리는 순간"
- 카테고리: AI/ML (1219746)
- 긱뉴스 토픽: gn=31909
- 본문: 2380자 + Picsum 이미지 2장 (seed: netflix-litigation-2026 / litigation-ai-trust)
- OG 썸네일: `https://blog.kakaocdn.net/dna/bUmCNN/dJMcaidd5Ma/AAAAAAAAAAA...`
- proxy check: status=200 + title=`Netflix 직원, 리트릿 신뢰 훈련에서 개인사 공유 후 해고됐다며 소송 &mdash; 신뢰 모델이 흔들리는 순간` + og:title=`Netflix 직원, 리트릿 신뢰 훈련에서 개인사 공유 후 해고됐다며 소송 — 신뢰 모델이 흔들리는 순간` 정확 매칭

## 연속 카운트 갱신
- §3.5 신호 4 오탐 disambiguate **27연속 확정** (298→332)
- 진입 시점 신호 4 + 5-5 disambiguate 트리거 **8연속 확정** (310~317)
- 305차 단일 패스 패턴 **28연속 정형화**
- 311차 fallback 패턴 후 정상 publish 복귀 **21차 연속 안정 유지**
- 연속 all-green **107회차**

## 워크플로 타임라인
1. **§3.8.1 raw VALID** — manage/posts.json status=200, content_type=application/json, cookies_count=8, first_id=1126 (직전 #1126 331차 발행 진짜 존재 확인). 303차 안정 raw 검증 패턴 (`set -a; source tistory.env; unset PYTHONPATH PYTHONHOME; PYTHONNOUSERSITE=1; export PYTHONPATH=user-site; /usr/bin/python3 -s`) 정상 작동.
2. **§3-a topic 선정** — `blog_pipeline.py --category 'AI/ML'` → `status=ready` + gn=31909 "Netflix 직원, 리트릿 신뢰 훈련에서 개인사 공유 후 해고됐다며 소송". freshness OK, 295차 무조건 발행 정책 통과.
3. **build_post_332.py 빌드** — 305차 단일 패스 패턴 (gn_url fetch + og:description regex 159자 추출 + Picsum 2장 + 본문 빌드) + 317차 정형화 parts.append() 패턴 + **332차 신규: parts.append() 본문 작은따옴표 매칭 깨짐 회피** (자세한 함정 25 참조).
4. **publish** — `tistory_publisher.py --category 1219746 --file /tmp/post_332.html` → #1127 발행 성공.
5. **§3.11 5-2 commit_publish** — stats.today={AI/ML:8, 개발도구:2}, total=121, by_category["1219746"]=1 동일 유지 (함정 8 영구 잔존 28연속).
6. **§3.11 5-3 last+details 통합 보정** — #1126→#1127, details_len=200 (state) / KST 타임존 timestamp.
7. **§3.11 5-2-A 백필** — 1건 (누적 동기화), published_topics.json details_len=201.
8. **§3.11 5-4 §3.5 신호 4 발동** — 오탐 27연속 (state.last=#1127 == details[-1]=#1127 동일 slot, daily_counts 합계=10 ≥ 2).
9. **§3.11 5-5 proxy check disambiguate** — #1127 status=200 + og:title 정확 매칭 (오탐 확정) + #1126 status=200 + og:title 정확 매칭 (직전 차 발행도 진짜 확인). 신호 4 오탐 확정 → 정상 publish 처리.

## 함수 회피 7중 동시 성공
- 함정 6 (heredoc + env -i SyntaxError) — `unset PYTHONPATH; PYTHONNOUSERSITE=1; export PYTHONPATH=user-site; /usr/bin/python3 -s` 격리 패턴
- 함정 7 (`--category` int만) — `--category 1219746` 정확히 int 인자
- 함정 8 (by_category["1219746"]=1 영구 잔존) — drift 보고만, 임의 자동 보정 금지
- 함정 11 (`execute_code` cron 차단) — write_file(`/tmp/build_post_332.py`) + `/usr/bin/python3 -s` + `--file /tmp/post_332.html` 패턴
- 함정 14 (`import os` 누락) — heredoc 첫 줄 `import os, requests, re` 세 모듈 포함
- 함정 15 (5-5 proxy check 격리 패턴) — §1단계 가드와 동일 격리 적용
- 함정 17 (단일 f-string 회피) — 본문 2380자 < 3000자지만 docstring/코드블록/푸터 동시 사용으로 parts.append() 권장 임계 적용

## 신규 발견 — 함정 25

**문제**: `parts.append('<h2>1. 사건의 핵심: \'훈련 데이터 = 사용자 발언\'이 된 시대</h2>')` 형태로 작은따옴표(`'`)가 들어간 제목을 single-quoted 문자열로 감싸려고 `\'` 이스케이프 시도 → `write_file` lint 단계에서 `SyntaxError: unterminated string literal (detected at line 44) (line 44, column 14)` 즉시 실패.

**원인**: 317차 parts.append() 패턴은 single quotes 기본 사용. 본문에 작은따옴표가 들어가면 `\'` 이스케이프가 필요하지만, 332차 첫 작성 시 escape 누락 + Python parser가 line 44에서 매칭이 어긋나 SyntaxError 발생.

**해결 (332차 정형화)**: 본문 텍스트에 `'`, `"`, `\n` 등 escape가 필요한 문자가 포함될 가능성이 있는 parts.append() 라인은 **처음부터 double quotes**(`"..."`)로 감싼다. 332차 재작성:
```python
parts.append("<h2>1. 사건의 핵심: '훈련 데이터 = 사용자 발언'이 된 시대</h2>")
```
→ 정상 작동.

**원칙**:
1. parts.append() 작성 시 본문 안에 작은따옴표(`'`) 포함 가능성이 보이면 처음부터 double quotes 사용
2. 큰따옴표(`"`)가 본문에 들어갈 때는 반대로 single quotes 사용
3. 둘 다 들어가는 경우는 삼중따옴표(`"""..."""`) 또는 `chr(34)`, `chr(39)` 같은 escape 함수 사용
4. 332차에는 첫 작성에서 lint 에러 → patch tool의 자동 보정 시도 → 여전히 pre-existing lint 에러로 분류 → 전체 재작성이 가장 빠른 해결이었음. 향후엔 첫 작성 시 quote 종류를 미리 결정.

## 본문 구성
- 도입 (H2): "들어가며: 신뢰 훈련 데이터가 그대로 법정으로 갔다" — Netflix 사건 소개 + AI 정렬 사회적 정당성
- OG description blockquote: 159자 (긱뉴스에서 추출)
- 1번 섹션: "사건의 핵심: '훈련 데이터 = 사용자 발언'이 된 시대" — RLHF + 사용자 데이터 라벨러
- 코드 블록 1: 리트리뷰 워커 입력 흐름 다이어그램 (텍스트 박스)
- 2번 섹션: "왜 해고 사유가 곧 신뢰 모델의 결함이 되는가" — 4가지 책임 영역
- 3번 섹션: "개발자에게 주는 시사점 — 우리 모델은 안전한가" + 코드 블록 2 (RLHF 점검 체크리스트)
- 4번 섹션: "전망: 신뢰 모델의 다음 12개월"
- 요약 + 출처

## 운영 메모
- 진입 시점 daily_counts={AI/ML:8, 개발도구:2} (직전 차 10건 누적) — 일자 발행 누적 상태에서도 패턴 안정성 확인 (308차부터 관찰된 패턴 지속)
- 진입 단계 신호 4 + 5-5에서 직전 차 #1126 disambiguate 후 발행 단계 진입 (8연속 확정)
- by_category 영구 누적 (함정 8) — 사용자 게이트 시 ID_TO_NAME 1회 보정 가능하나 cron은 drift 보고만 유지
- details_len 200 (state) / pt_details_len 201 (1건 백필) — 누적 동기화 정상
- 332차 daily_counts={AI/ML:8, 개발도구:2} (총 10건), total=121