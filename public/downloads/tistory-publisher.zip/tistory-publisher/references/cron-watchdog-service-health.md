# Cron 점검 잡 수리 후 실제 서비스 상태 교차 검증

## 핵심

Cron 잡의 `last_status=ok`와 monitor all-green은 **점검 잡이 실행됐음**만 뜻한다. 점검 대상 서비스가 정상이라는 뜻은 아니다.

## 적용 절차

1. provider/model drift 같은 scheduler 오류를 지원되는 update 경로로 수리한다.
2. 잡을 수동 실행해 execution completed와 jobs 상태를 재확인한다.
3. **최신 cron output의 Response를 반드시 읽는다.**
4. 잡이 호출한 원본 endpoint를 같은 인증값으로 직접 probe한다.
5. 최종 monitor를 재실행한다.
6. 다음 두 상태를 분리해 보고한다.
   - scheduler: 수리됨/정상
   - service: 정상/만료/인증 실패/기타

## 판정 표

| Scheduler | 직접 서비스 probe | 결론 |
|---|---|---|
| 정상 | 정상 | 정상 |
| 정상 | 실패 | 운영 이슈 유지 |
| 수리됨 | 실패 | 수리 완료 + 서비스 이슈 유지 |
| 실패 | 미확인 | scheduler 장애, 서비스 상태 미확인 |

## Tistory 세션 점검 예시

- unpinned cron의 provider drift를 현재 provider/model에 고정
- 수동 실행 completed, jobs `last_status=ok`
- 최종 monitor all-green
- 그러나 최신 output과 manage API probe가 로그인 redirect를 반환
- 결론: **cron 수리는 완료됐지만 Tistory 세션은 만료 상태**

## Python harness와 실제 API 실패 분리

Hermes venv의 `PYTHONPATH`가 macOS 시스템 Python에 섞이면 dependency import가 먼저 실패할 수 있다. 이때 harness 실패를 곧바로 쿠키 만료로 해석하지 않는다. 안정된 격리 환경으로 다시 실행한 후 실제 HTTP 상태를 판정한다.

```bash
set -a; source ~/.hermes/secrets/tistory.env; set +a
unset PYTHONPATH PYTHONHOME
PYTHONNOUSERSITE=1
export PYTHONPATH="$HOME/Library/Python/3.9/lib/python/site-packages"
/usr/bin/python3 -s <probe.py>
```

probe는 redirect를 자동 추적하지 않고 status, content-type, location을 출력해야 한다.

## 유지보수 규칙

- `os.environ`을 쓰는 heredoc은 반드시 `import os` 포함.
- verifier Traceback과 HTTP 302/200을 별도 증거로 기록.
- 서비스 만료가 확인되면 publish와 stats 변경은 중단하고 상태 정합만 검증.
- monitor가 최종 정상이어도 서비스 이슈는 issues/리포트에서 제거하지 않는다.
