# blog_pipeline.py freshness 처리 가이드 (108차 신규)

## 108차 freshness warning 사례

`blog_pipeline.py` 출력이 다음과 같이 freshness warning을 동반할 수 있다:

```json
{
  "status": "ready",
  "category": "개발도구",
  "topic": "HTMX가 너무 멋져서 직접 만들었다 (2024)",
  "timeliness_check": {
    "is_fresh": false,
    "severity": "warning",
    "warnings": [
      "주제에 2024년이 명시되어 있지만 현재는 2026년입니다"
    ]
  }
}
```

108차는 `is_fresh: false` + `severity: warning` 상태였으나 긱뉴스 20시간 전 공유, 사례 자체는 시의성 유효 → **발행 진행** (A 70점 / pass).

## severity 단계별 처리 가이드 (108차~)

| severity | is_fresh | 권장 액션 | 비고 |
|----------|----------|-----------|------|
| (없음) | true | 발행 진행 | 정상 케이스 |
| `warning` | false | **발행 진행** (108차 검증) | 주제에 연도 표기, 긱뉴스 공유 시점이 최근이면 사례 유효 |
| `fail` | false | **skip 권장** (108차 미관찰) | 코드 read 후 정확히 파악 필요 |
| (다른 severity) | ? | 코드 read 후 결정 | 알려지지 않은 단계 |

## freshness severity 단계 분류 로직 read 권장 (다음 세션 작업)

```bash
grep -n "severity\|is_fresh\|timeliness" ~/.hermes/scripts/blog_pipeline.py | head -30
```

`severity` 결정 로직 파악 후 본 문서 업데이트. 특히:
- 어떤 조건에서 `warning` vs `fail`로 분기되는가?
- 1년 이상 차이 시 무조건 `fail`인가?
- 긱뉴스 공유 시점 기준 보정이 있는가?

## freshness warning 무시 위험

- 108차 사례: HTMX 자체는 2024년 글이지만 긱뉴스가 2026-06-09 공유 (20시간 전). 사례의 본질적 가치는 시의성 무관.
- 2024년 기술이라도 2026년에 다시 화제 (HTMX, SvelteKit 등)는 정상적임.
- 단순히 "연도가 다름"으로 skip하면 긱뉴스 RSS를 통한 시의성 있는 주제 절반 이상을 놓침.

## freshness가 정말로 fail이어야 하는 경우

- 2020년 이전 글로, 2026년 맥락에서 부정확하거나 위험한 정보
- deprecated API/라이브러리 사례
- 1년 이상 + 같은 카테고리 글이 이미 충분히 발행됨
