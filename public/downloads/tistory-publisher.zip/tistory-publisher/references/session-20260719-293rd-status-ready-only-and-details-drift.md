# 293차 세션 (2026-07-19 19:01) — Status=Ready 한계 + Details Drift

## 요약
§3.8.1 가드 VALID + §3.5 3중 신호 일치 — 정상 운영 가능 상태였지만 publish skip (저품질 topic 선정 + SSOT drift 발견).

## 검증 1: §3.8.1 raw 검증 (291차 워크어라운드 재사용)

```bash
set -a; source ~/.hermes/secrets/tistory.env; set +a
python3 << 'PYEOF'
import os, requests
cookies = {k.replace('TISTORY_',''): os.environ[k] for k in os.environ if k.startswith('TISTORY_')}
hdr = {'User-Agent':'Mozilla/5.0','Referer':'https://sigco.tistory.com/manage/','X-Requested-With':'XMLHttpRequest'}
r = requests.get('https://sigco.tistory.com/manage/posts.json?category=-3&page=1', cookies=cookies, headers=hdr, timeout=10, allow_redirects=False)
print(f"status: {r.status_code}")
PYEOF
```

결과: `status=200`, `content-type=application/json;charset=UTF-8`, `body[:200]: {"count":15,"totalCount":908,"items":[{"id":"1045",...}]`

→ **세션 VALID, 실제 Tistory #1045가 최신 글 → 어제 2건 발행은 진짜 발행**

## 검증 2: §3.5 3중 신호

```bash
unset PYTHONPATH
env -i HOME="$HOME" PATH=/usr/bin:/bin PYTHONPATH= /usr/bin/python3 \
  ~/.hermes/skills/tistory-publisher/scripts/check_state_consistency.py
```

결과:
- `today=2026-07-19 daily_counts={'AI/ML': 2} (total=2)`
- `last_published_url=https://sigco.tistory.com/1045`
- `last_topics[-1]={'topic': '31554', ..., 'url': 'https://sigco.tistory.com/1045', 'timestamp': '2026-07-19T06:02'}`
- `✅ OK: 3중 신호 일치` (exit 0)

→ **§3.5 통과, 신호 4 FAKE_PUBLISH 미발동**

## 검증 3: 트렌드 새로고침

```bash
unset PYTHONPATH
env -i HOME="$HOME" PATH=/usr/bin:/bin PYTHONPATH= /usr/bin/python3 \
  ~/.hermes/scripts/blog_pipeline.py --refresh-topics
```

12개 새로고침, AI/ML 1순위는 "GPT-5.6이 프롬프트로 볼록 최적화의 30년 공백을 메움" (9점, 7/19 09:35). 2순위 "AI 코드 검토가 타당한 반론이 될 수 없는 이유" (7점). 3순위 "Kimi K3의 순간" (6점). 모두 freshness 양호.

## 검증 4: AI/ML run_pipeline() 결과

```bash
~/.hermes/scripts/blog_pipeline.py --category 'AI/ML'
```

결과: `status=ready, topic="AI 기업 로고는 왜 항문처럼 보일까? (2025)"`

```json
"timeliness_check": {
  "is_fresh": false,
  "severity": "warning",
  "warnings": ["주제에 2025년이 명시되어 있지만 현재는 2026년입니다"]
}
```

→ **⚠️ 293차 함정 발견**: `run_pipeline()`은 publish 자체를 실행하지 않고 status=ready로 가이드라인 JSON 출력 후 종료. cron 워크플로우가 별도 단계로 컨텐츠 생성 + `tistory_publisher.py` 직접 호출을 수행해야 함. SKILL.md §3단계는 topic 선정까지만 책임짐.

→ **선정 topic 자체도 부적합**: 9점/GPT-5.6 미선정, 3점/sensational 주제 선정됨. score 정렬 우선 알고리즘 깨진 듯. "항문" 표현도 품질 정책상 발행 부적합.

## ⛔ 신규 발견: SSOT Drift (details append 누락 + last_published_id mismatch)

### 발견 4-A: details 배열 stale

`blog_pipeline_state.json`의 `details[]` 마지막 3개:
```
id=31524 url=https://sigco.tistory.com/1041 date=2026-07-18
id=31525 url=https://sigco.tistory.com/1042 date=2026-07-18
id=31523 url=https://sigco.tistory.com/1043 date=2026-07-18
```

그러나 실제 Tistory #1044, #1045는 어제 7/19에 발행됨. **details append 누락**.

→ `commit_publish()`가 details에 새 entry를 추가하지 않는 듯. 함수 코드 line 1881 부근에 명시된 절차는 "daily_counts/total/by_category/last_topics 박기"로, details append는 거론 없음. **검증 필요한 함수**: `commit_publish` 본체 안에 `details.append(...)` 호출이 있는지.

### 발견 4-B: last_published_id vs URL mismatch

```json
"last_published_url": "https://sigco.tistory.com/1045",
"last_published_id": "1043"
```

URL은 1045인데 id는 1043. **두 필드가 동일한 정보를 두 번 저장하면서 동기화 깨짐**.

→ `commit_publish()`가 `last_published_id` 필드를 갱신하지 않거나, 별도 패스가 URL만 갱신. SKILL.md §3.11 함정 5로 등록.

### 발견 4-C: published_topics.json은 정상

`published_topics.json`의 `details[]`는 어제 #1044, #1045까지 정상 기록:
```
"hash": "c748d08c853dce45d5413435a4c3aa10",
"url": "https://sigco.tistory.com/1044",
"date": "2026-07-19T05:03"
```

→ record_published_topic()은 작동했음. **details는 `published_topics.json`만 있고 `blog_pipeline_state.json`엔 미러링 누락**. 두 파일의 `details` 의미가 다름 — `published_topics.json`의 details는 "전체 발행 이력 + hash" / `blog_pipeline_state.json`의 details는 "가벼운 인덱스+url"로 추정. 두 SSOT 간 의미 차이가 문서화되지 않아 drift 감지 어려움.

## 조치 결정

- 이번 차에서는 publish skip (저품질 topic 선정)
- details/last_published_id 누락 보정은 SSOT 변경이므로 사용자 확인 필요 — 임의 보정 안 함
- 다음 cron 차(294차)에 1순위 후보(GPT-5.6 등 7~9점)가 ready로 선정되면 publish 진행
- 295차 이상에서 details 누락 보정 안건 사용자 보고 후 일괄 처리

## SKILL.md 갱신 항목 (293차)

1. §3단계 함정 추가: "run_pipeline()은 publish 안 함, 별도 tistory_publisher.py 호출 필요"
2. §3-A publish skip 판정 매트릭스 추가: timeliness warning + low score + sensational → skip
3. §3.11 함정 4, 5 추가: details append 누락 + last_published_id mismatch
4. 검증 이력에 293차 항목 추가
5. Reference에 session-20260719-293rd 문서 추가
