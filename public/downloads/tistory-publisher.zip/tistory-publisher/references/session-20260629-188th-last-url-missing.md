# 188차 — `pt['last'].url` 누락 + §3.5 임계값 false positive

**날짜**: 2026-06-29
**차수**: 188
**핵심 발견**: `blog_pipeline.py --record TOPIC TITLE URL` 3-arg 호출이 `pt['last']` dict에는 `url` 키를 동기화하지 않음.

## 환경

- 글: "Claude Code로 내 MRI 2차 소견을 받아봄" (AI/ML, 본문 2,940자)
- 발행: `tistory_publisher.py --file ... --image-query "medical-ai-mri"` → https://sigco.tistory.com/873 (✅ HTTP 200)
- record: `blog_pipeline.py --record "주제" "제목" "URL"` → ✅ details[-1].url 채워짐, ❌ pt['last'].url 빈값

## 발견된 함정

### 함정 A: `last.url` 미동기화

`blog_pipeline.py --record TOPIC TITLE URL` 실행 후:
- `pt['details'][-1].url` = "https://sigco.tistory.com/873" ✅
- `pt['details'][-1].source_url` = 없음 ❌
- `pt['last'].url` = 없음 ❌
- `pt['last'].source_url` = 없음 ❌

→ 후속 검증/모니터링 스크립트가 `pt['last'].get('url')`을 읽을 때 `None` 또는 `KeyError` 발생.

### 함정 B: §3.5 임계값 false positive

```
stats.total_published: 845
sigco URL 라인 수 (published_urls.txt): 325
차이: 520
```

§3.5 공식 "stats - sigco URL 수 = 가짜 발행 누적" 적중. 그러나 실제로는:
- `published_urls.txt`는 1~2년치 누적 컬렉션
- 일부 cron은 `source URL`(news.hada.io 등)만 append하고 `sigco.tistory.com` URL은 안 박음
- 520개 차이는 가짜 발행 누적이 아니라 append 패턴의 불일치

### 진짜 가짜 발행 신호 (3중 조합)

| 신호 | 의미 |
|---|---|
| (a) `details[-1].url == ""` | record 시 URL이 빈값 (§3.11) |
| (b) `pt['last'].url` 없음 | last dict에 url 안 박힘 (188차) |
| (c) `stats.daily_counts[today][cat] > 0` 증가 | 통계는 카운트됨 |

세 개가 동시에 성립해야 가짜 발행 확정. `stats.total - urls count` 단일 비교는 판정 금지.

## 보정 코드 (3단계, 30초)

```python
import json
from pathlib import Path

# 1) pt['last'] 보정
p = Path('/Users/mac/.hermes/memory/published_topics.json')
pt = json.loads(p.read_text())
if not pt['last'].get('url'):
    pt['last']['url'] = 'https://sigco.tistory.com/873'
    pt['last']['source_url'] = 'https://news.hada.io/topic?id=30928'
    p.write_text(json.dumps(pt, ensure_ascii=False, indent=2))
    print('✅ last.url 보정')

# 2) state.json의 last_topics 동기화
sp = Path('/Users/mac/.hermes/memory/blog_pipeline_state.json')
s = json.loads(sp.read_text())
for t in s.get('last_topics', []):
    if 'MRI' in (t.get('topic') or ''):
        if not t.get('url'):
            t['url'] = 'https://sigco.tistory.com/873'
            t['source_url'] = 'https://news.hada.io/topic?id=30928'
            print('✅ state.last_topics 동기화')
sp.write_text(json.dumps(s, ensure_ascii=False, indent=2))

# 3) 검증
print(f'last.url: {pt["last"].get("url")}')
print(f'details[-1].url: {pt["details"][-1].get("url")}')
```

## 근본 해결 (TODO, 188차 미수정)

- `blog_pipeline.py`의 `record_published_topic()` 함수가 `pt['last']` dict에 `url`/`source_url`도 동기화하도록 패치
- 또는 `record-topic TOPIC TITLE URL TOPIC_URL` 4-arg 호출 시 source URL도 last에 박도록 통일
- §3.5 임계값 공식은 "신호 (c)일별 카운트 증가 + 3중 조합"으로 재정의 필요

## 발행 결과

- 본문: 2,940자 (3,298자 raw, 4KB 미만 → §1 1회 컷 안전 구간)
- Picsum 자동 2장 (CDN 업로드 완료)
- 발행 URL: https://sigco.tistory.com/873
- 세션: 735 → 736개 글
