# 207차 — Jetendard #917 + §3.19 stale 반환 cron 재발 + delegate_task 제약

**일자**: 2026-07-07 (화)
**세션 ID**: 207th half-pipeline cron
**발행 URL**: https://sigco.tistory.com/917 (Jetendard 폰트)
**drift**: 0

## 타임라인

1. **§3.8.1 3-endpoint probe**: `manage/posts.json?category=-3&page=1` 호출 → 200 OK + JSON → ✅ 세션 유효
2. **`blog_pipeline.py --refresh-topics`**: 긱뉴스 RSS 50개 → 24시간 내 29개 → 점수 필터 12개 토픽
3. **`blog_pipeline.py --category 'AI/ML'`**: **stale 반환** — "덜한 것이 더 낫다" (31170 → 이미 #915로 발행됨). §3.19 fire-and-forget 버그 cron 환경 재발.
4. **4중 dedup 직접 호출 (외부 워커 override)**: refresh-topics 12개 → last_titles_full + published_sources + pub_hashes + Tistory URL → 5개 FRESH
5. **FRESH 후보 (점수순)**:
   - Jetendard 폰트 (31174, AI/ML, 3점) ✅ 선택
   - AI 코딩 시대 개발자 역할 변화 (31165, 개발팁, 8점)
   - Figma 다음 단계 (31166, 개발팁, 4점)
   - OpenPrinter (31161, 개발도구, 4점)
   - k-vote-cli (31178, 개발팁, 3점)
6. **delegate_task 본문 생성 위임 시도**: 백그라운드 실행 → process 목록에 안 뜸 → 본문 파일 0KB → 시간 제약으로 abort
7. **직접 heredoc/write_file 본문 작성**: 4184자 markdown + YAML frontmatter (`title/date/category/tags/source/description`)
8. **`strip_fm.py` heredoc**: 4184자 → 3839자 content-only
9. **`tistory_publisher.py --file`**: category 1219746, tags 8개, image-query "typography, monospace, code, terminal, developer"
10. **Picsum 이미지 2장** 자동 삽입 (id=983, id=161, 1080x720)
11. **✅ 발행 성공**: https://sigco.tistory.com/917
12. **§3.11 5단계 + §4 5-1 stats 보정 heredoc** (§3.22.1 tistory.env 형식 적용):
    - last_topics append (31174)
    - stats.total_published: 900 → 901
    - stats.by_category[AI/ML]: 705 → 706
    - stats.daily_counts[2026-07-07][AI/ML]: 0 → 1
    - daily_counts (top-level) +1
    - last_post.details append
    - published_urls.txt append (URL\tTITLE\tDATE\tCATEGORY)
13. **§3.5 3중 신호 검증**: Tistory max=917 = state last /917 = urls last /917 → **drift 0**
14. **§3.22.2 Notion PATCH 자동 cleanup**: 30자 prefix 자동 매칭 8건 (이번 발행한 Jetendard 포함) → **8/8 PATCH 성공**
15. **누적 drift 121** (stats 901 vs Tistory totalCount 780) — §3.16 별도 작업 대상 (재확인)

## 핵심 발견

### 발견 1: §3.19 stale 반환 cron 환경에서 다시 재발

**증상 (207차)**:
```bash
$ python3 ~/.hermes/scripts/blog_pipeline.py --category 'AI/ML'
# 결과: "덜한 것이 더 낫다" (31170) → 이미 #915로 발행한 글
```

**원인 (가설 재확인)**:
- `update_notion_topic_last_used()`는 fire-and-forget (return value 검증 안 함)
- Notion API silent fail (401, 500, property 오타 모두 silent swallow)
- 매 cron 호출 시 같은 stale 토픽 반환

**영구화 결정**: 외부 워커는 `blog_pipeline.py --category`를 **절대 신뢰하면 안 됨**. 4중 dedup 패턴을 외부 워커가 직접 실행해야 함.

### 발견 2: Notion PATCH 자동 cleanup 누적 25/25 영구화

**누적 실행 결과**:
- 205차: 5/5
- 206차: 6/6
- 207차: 8/8 (이번 발행한 Jetendard 포함)
- **합계: 25/25 = 누적 100% 성공**

**핵심 안전망**: cleanup 자체가 매 세션마다 자동 실행되면 매 cron이 fresh 후보 풀에서 시작 → §3.19 stale 버그의 **자동 회복** (코드 패치 없이).

### 발견 3: frontmatter strip §3.23.1 cron 환경 영구화

**strip_fm.py heredoc (207차 영구 패턴)**:
```python
import sys
src, dst = sys.argv[1], sys.argv[2]
with open(src) as f: content = f.read()
if content.startswith('---'):
    end = content.find('---', 3)
    content = content[end+3:].lstrip('\n')
with open(dst, 'w') as f: f.write(content)
print(f'✅ Stripped to {dst}, length={len(content)} chars')
```

**결과**: 4184자 → 3839자 content-only → 검증 "✅ 3565자" → 정상 발행 #917

### 발견 4: ⚠️ delegate_task cron 환경 제약 (신규)

**증상**:
- `delegate_task(goal=..., context=...)` 호출 → dispatch 완료 알림 받음
- `process list`에 subagent 없음
- 결과 폴링 불가 (delegate_task는 자체 백그라운드 메커니즘)
- 본문 파일 `/tmp/blog_207th/jetendard_post.md` = 0KB (아직 미생성)
- 시간 제약으로 직접 heredoc 작성 후 발행

**결론**:
- `delegate_task`는 **수동 세션** (사용자 폴링 가능) 또는 **결과 검증 폴링 가능** 환경에서만 안정
- **cron 자동 환경**은 dispatcher가 즉시 결과 반환 보장 안 함 → **직접 write_file/heredoc 권장**
- 짧은 본문 (1500~2500자 한국어) 은 직접 작성해도 1분 이내 가능

**half-pipeline §3.18 패턴 갱신**:
- 3단계 "외부 워커가 본문을 heredoc으로 작성" → "직접 write_file/heredoc으로 작성 또는 안정 환경 위임"

## 영구화 권장

1. **§3.19 stale 반환 우회**: 모든 cron에서 `blog_pipeline.py --category` 무시 + 4중 dedup 직접 호출
2. **§3.22.2 Notion PATCH cleanup cron 진입 시 routine**: §3.19 자동 회복 + 후보 풀 자동 축소
3. **§3.23.1 frontmatter strip 영구**: `--file` 호출 직전 필수 단계
4. **delegate_task 제약**: cron 환경에서는 직접 작성 우선 (시간 제약 + 안정성)
5. **half-pipeline §3.18 6단계 워크플로 영구화**: 207차 패턴이 표준

## 후속 권장 작업 (다음 cron)

1. **누적 drift 121 정리** (§3.16): 별도 cron 임무로 분리. Tistory 실제 페이지 수와 stats.total_published 불일치 — `manage/posts.json` 전체 순회 max(id) + totalCount 비교.
2. **`update_notion_topic_last_used()` 코드 패치** (코드 임무): fire-and-forget → blocking + raise. fire-and-forget silent fail 차단. CRITICAL 우선순위.
3. **`blog_pipeline.py get_fallback_topic()` self-dedup 추가**: Notion PATCH에 의존하지 말고, 자체적으로 `state.last_topics`와 source URL 비교 후 이미 발행한 토픽 skip.

## 세션 검증 결과

| 신호 | 값 |
|---|---|
| Tistory max id (page1) | 917 |
| state.last_topics[-1].url | https://sigco.tistory.com/917 |
| state.last_post.details[-1].url | https://sigco.tistory.com/917 |
| published_urls.txt last Tistory URL | https://sigco.tistory.com/917 |
| stats.total_published | 901 (before 900) |
| stats.by_category[AI/ML] | 706 (before 705) |
| stats.daily_counts[2026-07-07][AI/ML] | 1 |
| drift | 0 ✅ |
| Notion PATCH 자동 cleanup | 8/8 ✅ |

## 결론

207차 = **half-pipeline cron 환경 4번째 통과** (199/201/206/207). §3.19 stale 반환 우회 + Notion 자동 cleanup 누적 25/25 + frontmatter strip + delegate_task 제약 발견 = 영구 단계 + 신규 함정 노출. 다음 cron은 208차에서 §3.16 누적 drift 정리를 별도 임무로 분리 권장.
