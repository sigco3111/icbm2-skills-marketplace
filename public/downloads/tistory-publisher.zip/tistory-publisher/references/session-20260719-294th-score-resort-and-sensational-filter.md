# 294차 세션 — score 재정렬 패치 + sensational/stale 자동 필터 + 수동 발행 #1046

**날짜**: 2026-07-19 21:30 KST
**모드**: 사용자 트리거 ("오늘 오후 티스토리는 왜 발행이 안되고 있지?")
**핵심 작업**: `get_fallback_topic()` score 정렬 우선 알고리즘 깨짐 → 패치

## 1. 트리거 — 왜 발행 안 됐나

cron `b1bca63a117a`는 정상 작동 (ok 표시)했으나 19:00~21:01 모두 0건 발행.
21:01 로그 분석 결과:
- §3.8.1 raw VALID 통과
- §3.5 3중 신호 일치 (깨끗)
- `run_pipeline()` 선정 topic = "AI 기업 로고는 왜 항문처럼 보일까? (2025)"
- 두 가지 skip 사유: sensational("항문") + timeliness.warning(2025 stale)
- **문제**: 트렌드 score 1순위 = "GPT-5.6이 프롬프트로..." (9.0점) 인데 3.0점 sensational 후보가 선정됨

## 2. 근본 원인 — Notion DB 순서 ≠ score 순서

`load_fallback_topics_from_notion()`은 Notion에서 긱뉴스 12개를 가져올 때:
- `상태=활성` + `마지막 사용일 비어있음` 필터로 query
- `마지막 사용일` asc 정렬 (가장 오래 미사용한 것 우선)
- **score 속성 자체를 Notion에서 안 가져옴**

→ Notion DB의 원래 순서(생성/업데이트 순)로 `get_fallback_topic()`이 첫 번째 후보를 선정
→ score 9.0 후보가 10번째에 있어도 3.0 sensational 후보가 먼저 선정됨

## 3. 패치 — score_map 기반 재정렬

`get_fallback_topic()` 진입 직후 `fetch_geeknews_rss(hours=48)`로 실시간 score 계산 → `score_map[title]` / `score_map[topic_id]` 생성 → fallbacks를 score desc로 재정렬.

### 3-1. 패치 코드 핵심

```python
# === 294차 신규: score 매핑 생성 ===
score_map = {}
try:
    rss_articles = fetch_geeknews_rss(hours=48)
    if rss_articles:
        for art in rss_articles:
            m = re.search(r'id=(\d+)', art.get('url', '') or art.get('link', ''))
            topic_id = m.group(1) if m else None
            s = _score_article(art)
            title = art.get('title', '').strip()
            if title:
                score_map[title] = s
            if topic_id:
                score_map[topic_id] = s
except Exception as e:
    logger.warning(f"score_map 생성 실패 (294차), 기본 정렬 사용: {e}")

# === 294차: sensational/stale 필터 ===
SENSATIONAL_KEYWORDS = ('항문', 'fetish', 'nsfw', '혐오', '비하')
STALE_YEAR_PATTERN = re.compile(r'\b202[0-5]\b')

def is_sensational_or_stale(entry):
    t = entry.get('topic', '') if isinstance(entry, dict) else entry
    if any(kw in t.lower() for kw in SENSATIONAL_KEYWORDS):
        return True, 'sensational'
    if STALE_YEAR_PATTERN.search(t):
        return True, 'stale_year'
    return False, None

filtered = [e for e in fallbacks if not is_sensational_or_stale(e)[0]]
filtered.sort(key=entry_score, reverse=True)

# mismatch 경고
if filtered and fallbacks and (filtered[0] != fallbacks[0]):
    logger.warning(f"⚠️ 294차 score 재정렬: '{fallbacks[0]}' → '{filtered[0]}'")
fallbacks = filtered
```

### 3-2. 검증

```
--- Notion 후보 (원본 순서) ---
  1. Show GN: 유튜브 댓글에서 체스 플레이 매크 프로그램
  2. AI 기업 로고는 왜 항문처럼 보일까? (2025)
  ...
  10. GPT-5.6이 프롬프트로 볼록 최적화의 30년 공백을 메움

--- score 재정렬 후 선정 (294차) ---
⚠️ 294차 score 재정렬: Notion 순서 'Show GN: 유튜브 댓글...' → score 우선 'GPT-5.6이 프롬프트로...'
선정: ('AI 코드 검토가 타당한 반론이 될 수 없는 이유', 'https://news.hada.io/topic?id=31578')
```

✅ sensational "항문" + stale "(2025)" 둘 다 skip됨. 9.0점 GPT-5.6은 이미 발행됐으니(이 세션에서 #1046 발행), 다음 후보인 7점이 선정됨 (정상).

## 4. 함정 — `re` import 누락

`get_fallback_topic()`에서 `re.compile()` 사용하지만 `import re` 누락 → NameError. 글로벌 import에 `import re` 추가 필요.

```python
# blog_pipeline.py 상단 imports
import hashlib
import json
import logging
import os
import re   # ← 294차 추가
import sys
import time
```

## 5. 수동 발행 #1046 — GPT-5.6 148분 볼록 최적화 증명

### 5-1. 본문 추출

- 긱뉴스 원본 URL: `https://news.hada.io/topic?id=31570`
- OG description = 다른 글 매칭 (군론) → 무시
- Reddit 원본 `old.reddit.com/r/math/comments/1uxj3cy/...` 에서 `<div class="md">` 본문 + top 댓글 추출
- 토픽 sticky 제외 (`Welcome to /r/math`, `Rule 1`, `FAQ` 매치 skip)
- Reddit JSON endpoint (`.json`) 차단됨 → HTML 파싱 필요

### 5-2. publish 본문 (4758자)

```html
<p><strong>TL;DR</strong>: ...</p>
<h2>📌 무슨 일이 있었나</h2>
<p>{selftext 3000자 excerpt}</p>
<h2>💬 Reddit 디스커션 핵심</h2>
<h3>프롬프트 구성과 솔의 역할</h3><p>{comment1}</p>
<h3>메모리/이전 대화 활용도</h3><p>{comment2}</p>
<h2>🧠 이게 왜 중요한가</h2>
<ul>...</ul>
<h2>🔗 출처</h2>
<ul>...</ul>
```

### 5-3. publish CLI

```bash
set -a; source ~/.hermes/secrets/tistory.env; set +a
unset PYTHONPATH
env -i HOME="$HOME" PATH=/usr/bin:/bin PYTHONPATH= \
  /usr/bin/python3 ~/.hermes/scripts/tistory_publisher.py \
  --title "GPT-5.6이 프롬프트로 볼록 최적화의 30년 공백을 메움 — ..." \
  --content "$(cat /tmp/post_31570.html)" \
  --tags "ICBM,AI,LLM,GPT-5.6,수학,볼록최적화,Lean,기하급수적연구,OpenAI" \
  --visibility public \
  --category 1219746
# → https://sigco.tistory.com/1046
```

⚠️ **`--category 1219746` (Tistory AI/ML 카테고리 ID)** 직접 지정 — `--force-topic`과 별개.

### 5-4. `--force-topic` (CLI flag)

`blog_pipeline.py --force-topic '31570'` 으로 1순위 강제 가능.
(`--topic-override`는 없는 flag → argparse error)

## 6. §3.11 5단계 보정 실전

발행 성공 후 drift 발생 (last_published_url=#1045인데 새 글 #1046):

```python
# 5-3 패치 — last_published_url + last_published_id 동시 갱신 (293차 함정 5 해결)
state['last_published_url'] = 'https://sigco.tistory.com/1046'
state['last_published_id'] = '1046'   # ← 294차 추가
```

✅ §3.5 3중 신호 일치 복구 (last_published_url=#1046, last_topics[-1]=#1046).

## 7. proxy check 통과

```
status=200
title=GPT-5.6이 프롬프트로 볼록 최적화의 30년 공백을 메움 &mdash; 148분 ...
og:title=GPT-5.6이 프롬프트로 볼록 최적화의 30년 공백을 메움 — ...
```

✅ 진짜 발행 확인.

## 8. 워크플로우 답변 패턴 (사용자 선호)

"score 정렬 깨짐 → 어떻게 할까?" 질문에 4개 옵션 제시:

- **A**: 1순위 수동 발행
- **B**: 다음 cron 대기 (트렌드 새로고침)
- **C**: 1순위 강제 발행
- **D**: 알고리즘 패치

사용자 답변: "c+d" → ① C 즉시 실행 (9.0점 GPT-5.6 #1046 발행) ② D 알고리즘 패치 (`get_fallback_topic()` score 재정렬). 

→ 다음 세션부터 **C+D**가 score 깨짐 패턴의 기본 응답 템플릿이 됨.

## 9. 핵심 교훈

1. **Notion DB의 원본 순서는 운영상 score 순서가 아님** — 발행 시점엔 반드시 실시간 재정렬 필요
2. **sensational/stale 필터는 코드 레벨에서 자동화** — 사람이 매번 점검할 수 없음
3. **`commit_publish()`의 SSOT 갱신 누락** — `last_published_url` + `last_published_id` 둘 다 수동 패치 필요
4. **Reddit JSON endpoint 막힘** — HTML `<div class="md">` 파싱이 fallback
5. **score 1순위 skip 시 사용자에게 알림** — 단순 skip은 9.0점 가치를 잃게 됨
