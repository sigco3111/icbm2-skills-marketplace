# Tistory Session Expiry — Zombie 200 패턴 (183차, 2026-06-27)

## 증상 (3-layer 진단 가능)

`python3 ~/.hermes/scripts/tistory_publisher.py --check` 또는 `--check-session` 실행 시:

```
❌ 연결 오류: Expecting value: line 2 column 2 (char 2)
```

흔히 "API 다운" 또는 "블록"으로 오인되지만, 실제는 **쿠키 만료**. 3가지 신호로 확정 가능:

| Layer | 정상 | 만료 |
|---|---|---|
| HTTP status | 200 | **200** (응답 자체는 성공) |
| Content-Type | `application/json` | **`text/html;charset=UTF-8`** |
| Body | `{"posts":[...], "totalCount":867}` | `<!doctype html>...<title>TISTORY</title>` (Tistory 메인 페이지) |

→ **만료는 HTTP 200으로 위장하지만 Content-Type이 JSON이 아니라 HTML로 떨어짐**. JSON 파서가 line 2 col 2에서 깨짐 (`<!doctype html>`의 `<` 기호).

## 왜 가짜 발행과 헷갈리는가

- `tistory_publisher.py`의 `check_session()`은 `r.json().get("totalCount")` 로 판정 → JSON 파싱 실패 = `False` 반환 + 예외 출력
- `publish_post()`도 동일하게 JSON을 기대 → 같은 에러
- 통계는 박히지 않음 (가짜 발행 §3은 통계만 박히는 다른 함정)
- 즉: **만료 = 통계 안 더러짐 + URL 안 박힘 = 사실상 안전 (단순 skip)**

## 진단 1줄 (cron 환경)

```bash
source ~/.hermes/memory/tistory.env 2>/dev/null || set -a && source ~/.hermes/secrets/tistory.env && set +a
python3 -c "
import os, requests
ck = ['TISTORY_REACTION_GUEST','TISTORY___T_','TISTORY___T_SECURE','TISTORY_TSSESSION','TISTORY__T_ANO']
missing = [k for k in ck if not os.environ.get(k)]
print('MISSING env:', missing if missing else 'none')
cookies = {k.replace('TISTORY_',''): os.environ[k] for k in ck if os.environ.get(k)}
r = requests.get('https://sigco.tistory.com/manage/posts.json?category=-3&page=1',
                 cookies=cookies, headers={'User-Agent':'Mozilla/5.0','Referer':'https://sigco.tistory.com/manage/'}, timeout=10)
print('status:', r.status_code, '| content-type:', r.headers.get('content-type'))
print('verdict:', 'OK' if 'application/json' in r.headers.get('content-type','') else 'EXPIRED')
"
```

**verdict 분기**:
- `OK` → 다른 원인 (블록 / 네트워크 / 일시 장애) → `--check` 한 번 더
- `EXPIRED` → 사용자 조치 필요 (쿠키 5종 갱신)

## cron 환경 함정 (2026-06-27 발견)

`source ~/.hermes/secrets/tistory.env`만 호출하면 **자식 프로세스로 export가 전파되지 않음**. Python은 키를 못 읽음.

```bash
# ❌ 이러면 KeyError 발생
source ~/.hermes/secrets/tistory.env
python3 -c "import os; print(os.environ['TISTORY_REACTION_GUEST'])"
# → KeyError: 'TISTORY_REACTION_GUEST'

# ✅ `set -a`로 자동 export 활성화
set -a; source ~/.hermes/secrets/tistory.env; set +a
python3 -c "import os; print(os.environ['TISTORY_REACTION_GUEST'])"
# → 정상 출력
```

`tistory_publisher.py`는 자체적으로 `load_cookies()`에서 .env 파일을 직접 파싱하므로 정상 동작하지만, **직접 API 호출로 진단할 때는 `set -a` 필수**.

## 사용자 조치 안내 텍스트 (cron 보고용)

```
Tistory 세션 만료. ~/.hermes/secrets/tistory.env 의 쿠키 5종 갱신 필요:
  TISTORY_REACTION_GUEST, TISTORY___T_, TISTORY___T_SECURE, TISTORY_TSSESSION, TISTORY__T_ANO
방법: 브라우저 sigco.tistory.com 로그인 → DevTools Network → manage/posts.json 호출 헤더의
Cookie 값 복사 → 환경변수 갱신
검증: python3 ~/.hermes/scripts/tistory_publisher.py --check
```

## cron 동작 결정 트리

```
tistory_publisher 호출
  ├─ check_session False + Content-Type HTML → EXPIRED → --record 안 함 → 종료
  ├─ check_session False + Content-Type JSON → 일시 장애 → 1회 재시도 → 그래도 실패 시 종료
  └─ check_session True → 정상 발행
```

## 만료 빈도 추적 (메트릭 후보)

매번 사용자 개입이면 운영 마찰 큼. `daily-self-review` 크론에 "Tistory 쿠키 평균 수명 (일)" 메트릭 추가 후보:
- 발행 성공일 - 직전 만료일 차이 평균
- 30일 미만이면 만료 빈발 경보 → 갱신 자동화 (Playwright 로그인) 검토

## 관련

- `references/false-positive-stats-rollback.md` — 통계는 박혔는데 URL은 없는 케이스 (§3과 다른 함정)
- `references/post-publish-verification-recipe.md` — 발행 후 검증
- SKILL.md §3 가짜 발행 함정 (본 만료 함정과 직교: 가짜 = 통계 오염 / 만료 = skip)