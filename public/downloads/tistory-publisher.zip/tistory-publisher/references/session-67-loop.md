# 67차 루프 기록 (2026-05-20 — Tokenova 블로그 글)

## 발견된 CJK 문자

Markdown CJK 선검사 1차에서 8자 발견: `的`, `锁`, `工`, `丽`, `解`, `了`, `华`, `作`

1차 제한적 사전 정제 → 잔여 8자 동일
종합 사전 1차 정제 → 잔여 3자: `丽`(U+4E3D), `华`(U+534D), `锁`(U+9501)
targeted final-pass로 3자 모두 빈 문자열 치환 후 제거 완료

## 원인 분석

이字符들은 Unicode range CJK Unified Ideographs에 속하며, 일반적인 Chinese/Japanese 표현이 아닌 개별 한자였다. `的`(적)는 综合 사전에 이미 있었으나 others (`锁`, `丽`, `华`)는 누락되어 있었다.

**추정 유입 경로:** GeekNews 원문을 웹 검색으로 fetching할 때, CSS/JS등의 부수적 텍스트가 함께 포함되거나, 클립보드 복사 과정에서 미량의 Chinese 문자가 섞인 것으로 추정.

## 교훈

1. **综合 사전에 없는 새로운 단일 한자가漏出할 수 있음** — 특히 웹Fetching 단계에서 추정하지 못한 Chinese 문자가 섞이는 경우
2. **targeted final-pass는 항상 별도로 실행** — 综合 사전 통과 후에도 잔여가 있을 수 있음
3. **빈 문자열 치환(`''`)도 유효한 정제手段** — 대응하는 Korean 표현이 없을 때 사용

## 추가된 정제 매핑

```python
'丽': '',  # 제거 (Korean 대응 없음)
'华': '',  # 제거 (Korean 대응 없음)
'锁': '',  # 제거 (Korean 대응 없음)
```

## 참고 사항

- HTML 변환 0회차 통과 (Markdown CJK 제거 후 HTML에서 추가 CJK 없음)
- 품질 평가: Grade A (78점)
- 발행 완료: https://sigco.tistory.com/453