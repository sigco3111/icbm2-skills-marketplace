# Session 335 — proxy-first publish with post-publish source footer

## Context

이번 실행은 §3.8.1 raw 세션 가드가 `HTTP 200 + application/json`으로 통과한 뒤 AI/ML 후보 `gn=31902`를 선정해 실제 Tistory `#1131`으로 발행했다. 본문은 `/tmp/build_post_335.py`에서 `parts.append()`로 빌드했고, 실행 결과는 `exit 0`, 6,454 bytes, 순수 텍스트 2,517자, 이미지 2장이었다.

## 새로 확인한 운영 규칙

1. **본문 빌드 전 source URL 검사와 publish 후 source URL 검사를 분리한다.** 빌드 스크립트의 `SOURCE_IN_BODY=False`는 실패가 아니다. `publish_post()`가 `source_url`을 받아 이미지 처리 후 출처 footer를 자동으로 추가하기 때문이다. source URL은 반드시 publish 후 Tistory response 본문에서 검사한다.
2. **publish wrapper의 성공 기준은 숫자형 URL이다.** `PUBLISH=SUCCESS URL=https://sigco.tistory.com/1131`을 실제 stdout에서 확인하기 전에는 `--commit`, stats, details를 건드리지 않는다.
3. **proxy 검증은 제목만으로 끝내지 않는다.** `HTTP 200 + og:title 정확 매칭 + source URL 존재 + 의심 CJK 문자열 없음`을 확인하면 글 존재뿐 아니라 핵심 전달 품질도 확인할 수 있다.
4. **§3.5 FAKE_PUBLISH exit 1은 proxy보다 우선하지 않는다.** 이번에도 commit 및 `last_published_url`/details 동기화 후 `daily_counts=3`과 동일 슬롯 때문에 FAKE_PUBLISH가 발생했다. 신규 URL의 proxy가 `HTTP 200`이고 `og:title`이 일치하면 구조적 오탐으로 기록한다. proxy 404/제목 불일치일 때만 진짜 가짜 발행으로 중단한다.
5. **상태 동기화는 URL idempotency를 유지한다.** `state.json`의 `last_published_url`, `last_published_id`, `details[-1]`을 새 URL로 맞추고, `published_topics.json`은 URL 중복을 확인한 뒤 누락 entry만 추가한다.
6. **수동으로 published_topics entry를 만들 때 canonical hash를 빈 문자열로 두지 않는다.** 이번 실행의 안전망 entry는 URL 추적에는 충분했지만, 다음 후보 dedup에 필요한 hash는 pipeline이 반환한 원래 topic 문자열의 MD5여야 한다. 후속 정비 시 `md5("31902")`로 교정하거나, topic hash 계산 함수가 있으면 그 함수를 사용한다. SEO 확장 제목의 hash는 금지한다.

## 재현 순서

```text
가드 → refresh-topics → category 1회 선정 → 원문 topic/URL dedup →
parts.append() 본문 빌드 및 메타 검사 → standalone publish wrapper →
숫자형 URL 확인 → proxy(200/og:title/source/CJK) → commit →
state + published_topics URL-idempotent sync → §3.5 exit 1이면 proxy로 disambiguate
```

## 보고

#1131 실제 발행 성공. stats.today는 AI/ML 3건으로 증가했고, by_category에는 기존의 `"1219746": 1` drift가 유지됐다. 이 ID 키는 SSOT 변경이므로 자동 병합하지 않고 보고만 해야 한다.
