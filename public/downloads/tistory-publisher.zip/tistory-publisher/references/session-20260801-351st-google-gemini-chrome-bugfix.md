# 351차 — Google Gemini Chrome 버그 자동 수정 (2026-08-01 22:01)

## 발행 결과
- **#1171** (gn=32019, AI/ML, 본문 1,800자, Picsum 2장, 5개 섹션)
- **제목**: Google, AI로 6월에 지난 2년치보다 많은 Chrome 버그 수정 — Gemini 에이전트가 바꾼 보안 엔지니어링

## 정형 패턴 재현
- **단일 패스 44연속** + 신호 4 disambiguate **51연속 확정** (298→351) + 진입 5-5 26연속 + fallback 복귀 36연속
- **324차 `--content` 단일 폴백 정형 15회차 검증** (324→339→340→341→345→346→347→348→349→350→351)
- **빌드 검증 6종 정형** (350차) — exit 0 + bytes + text_len + image_count + code_block_count + source_in_body + cjk_suspicious 모두 통과

## 새 함정 / 관찰
1. **빌드 스크립트 PYEOF_MARKER 잔재 함정 (351차 신규, write_file 함수정)** — write_file로 본문 빌드 스크립트 마지막에 heredoc 종료 표식 `PYEOF_MARKER`를 placeholder로 남겼다가 파일에 그대로 박힘. 그대로 실행 시 `NameError: name 'PYEOF_MARKER' is not defined`로 빌드 실패 가능. 351차에서는 patch()로 1줄 제거 후 정상 publish. **정형 원칙 (351차 정형)**: write_file로 빌드 스크립트 만들 때 heredoc 종료 표식(`PYEOF`/`PYEOF_MARKER`/`EOF` 등)을 **파일 끝에 절대 포함하지 않는다**. 빌드 명령은 exit 0 확인 후 본문 검증으로 한 번 더 점검.

2. **1800자 케이스 검증** — 본문 1,800자 (< 3000자 임계), 코드 블록 0개 → 단일 parts.append() 정형 정상 작동. Picsum 이미지 2장 정상 업로드 (40KB + 94KB). OG 썸네일 `https://blog.kakaocdn.net/dna/bTSNx3/...` 자동 설정.

3. **325차 fallback 후 정상 publish 36차 연속** — fallback은 안정 운영 상태의 일부로 완전 정착. 351차도 AI/ML 후보 정상 (직전 차 350차에 이어 AI/ML 연속).

## 워크플로우
1. §3.8.1 세션 만료 가드: status=200, first_ids=['1170',...] → VALID ✅
2. 트렌드 새로고침: 12개 (2026-08-01T22:00)
3. AI/ML 후보 선정: status=ready, gn=32019 (Google AI Chrome 버그)
4. 긱뉴스 OG description 추출: 159자 (Chrome은 Gemini 기반 에이전트로 1,072개 버그 수정)
5. 본문 빌드: parts.append() 정형 + Picsum 2장 → /tmp/post_351.html (1,800자)
6. publish: tistory_publisher.py --content 단일 폴백 (324차 정형) → #1171 발행 성공
7. commit_publish: stats.today={AI/ML:11}, total=165
8. 5-3 동기화: last=#1171 + details append (KST 타임존 명시)
9. 5-2-A 백필: 누락 1건 (state.json엔 #1171, published_topics.json엔 누락) + last 동기화
10. §3.5 신호 4 발동 (구조적 오탐, 정형 패턴) → proxy check disambiguate
11. 5-5 proxy: status=200 + og:title 정확 + source_present=True + cjk_suspicious=0 ✅

## 함정 회피
- 함정 6 (heredoc + env -i SyntaxError): `env -i ... python3 /tmp/build_post_351.py` 단일 호출
- 함정 7 (`--category` int): `--category 1219746` (int)
- 함정 8 (by_category["1219746"]=1 영구 잔존): cron drift 보고만, 자동 보정 금지
- 함정 11 (`execute_code` cron 차단): write_file + /tmp/build_post_351.py + /usr/bin/python3 -s
- 함정 15 (5-5 격리 누락): §1단계 가드와 동일 격리 패턴
- 함정 17 (parts.append 정형): 1800자 + 5개 섹션 → 처음부터 parts.append() 한 줄 정형
- 함정 26 (sibling write warning): write_file 직후 CJK grep → 0건, parts.append 카운트 정상
- **함정 30 (351차 신규)**: write_file로 빌드 스크립트 작성 시 heredoc 종료 표식 잔재 → patch()로 1줄 제거

## stats
- daily_counts={AI/ML:11}, total=165
- by_category["1219746"]=1 영구 잔존 55차 누적 (297→351)
- 5-2-A 누락 백필: 1건 (#1171, state.json엔 있고 published_topics.json엔 누락)

## 검증 결과
- §3.8.1 가드: status=200 + first_ids 매칭 ✅
- 빌드 검증 6종: exit 0 + bytes 4638 + text_len 1800 + images 2 + code 0 + source False (publish_post()가 footer 자동) + cjk 0
- publish: https://sigco.tistory.com/1171 ✅
- 5-5 proxy: status=200 + og:title "Google, AI로 6월에 지난 2년치보다 많은 Chrome 버그 수정 — Gemini 에이전트가 바꾼 보안 엔지니어링" 정확 + source_present=True + cjk_suspicious=0 ✅
- §3.5 신호 4: 구조적 오탐 (5-3 details+last 동시 갱신 정형) → proxy check로 disambiguate

## 연속 기록
- 단일 패스: **44연속** (305→351)
- 신호 4 disambiguate: **51연속** (298→351)
- 진입 5-5: **26연속** (310→351)
- fallback 복귀: **36연속** (311→351)
- 324차 `--content` 폴백: **15회차 검증** (324→351)
- **연속 all-green 125회차** (350→351)
