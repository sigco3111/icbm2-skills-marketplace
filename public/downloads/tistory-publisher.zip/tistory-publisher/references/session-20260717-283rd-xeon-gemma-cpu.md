---
session: 283rd
date: 2026-07-17
topic_id: 31498
title: "#1032 13년 된 Xeon에서 GPU 없이 Gemma 4 26B를 초당 5토큰으로 굴려보게 된 과정 — AVX2 폴백·MOE 그래프 빌더 함정·ggml 패치를 Claude와 한 달간 디버깅한 기록"
gn: 31498
category: AI/ML
category_id: 1219746
score: 15
fresh_rank: 1 (개발팁 14점 후보 §3.34 #21 정책으로 자동 배제)
---

# 283차 — `#1032 13년 된 Xeon에서 GPU 없이 Gemma 4 26B` (cron 자동 발행)

**날짜**: 2026-07-17
**슬롯**: #1032
**제목**: 13년 된 Xeon에서 GPU 없이 Gemma 4 26B를 초당 5토큰으로 굴려보게 된 과정 — AVX2 폴백·MOE 그래프 빌더 함정·ggml 패치를 Claude와 한 달간 디버깅한 기록
**원문**: https://news.hada.io/topic?id=31498

## 핵심 결과
- **연속 all-green 70회차** (213~283차)
- AI/ML 카테고리 (1219746) 정상 발행, entryId=1032 검증
- 본문 평문 6663자 (300자 가드 통과)
- 이미지 2장 (Picsum ID 472, 두 슬롯 동일, 첫 시도 적중 — 자연어 query 그대로 통과)
- 5중 신호 5/5 `#1032` 일치 (`all_match: True`)
- sync `triple_signal_match: true`, errors=[]
- daily_counts[2026-07-17] = `{'AI/ML': 6}` (5→6, +1 정확, cat_id 누설 0)
- cleanup cron 임무 #16 dry-run 69→**70회** 연속 all-green

## §3.34 #21 AI/ML 우선 정책 실전 10호 (283차 검증)
FRESH 2개 식별:
- `31498` (AI/ML, 15점) — `<strong>Xeon E5-2690 v2</strong>` + GPU 없이 Gemma 4 26B
- `31492` (개발팁, 14점) — Grok Build 오픈 소스 공개

§3.34.45 매트릭스 4번째 분기 "FRESH 'AI/ML' + 비-기타 혼재 → AI/ML 점수 1순위 픽" 정상 동작:
- 비-AI/ML 후보(개발팁 14점)가 1점 더 높아도 AI/ML 정책이 우선
- AI/ML 15점 `31498` 픽 확정, 개발팁 14점 `31492` 자동 배제

연속 검증:
- 255차 (1호) → 266차 (2호) → 268차 (3호) → 269차 (4호) → 270차 (5호)
- → 271차 (6호) → 280차 (7호) → 281차 (8호) → 282차 (9호) → **283차 (10호)**

## §3.34.44 자정 사이 외부 발행 drift 무해 4호 (283차 NEW 관찰)
사전 검증에서:
- `state.last_published_url = https://sigco.tistory.com/1031` (자정 사이 282차 외부 발행 흔적)
- `pt.last.gn_topic_id = '31480'` (282차 마지막 발행 토픽)

§3.34.40 v2 FRESH 4-field 매칭 정상:
- `pt_last_gn='31480'` pub set 추가 후 FRESH 2개 정확 식별
- 283차 정상 publish 후 sync 보정으로 `#1032` drift 무해 회복
- §3.5 5중 검증 모두 일치 유지

**추가 관찰 — state.details vs pt.details 갭 (NEW, §3.34.51 누적 경고)**:
- `state.details count: 109`
- `pt.details count: 124`
- **갭 15개 = historical splice drift 누적**

§3.11 sync + v2 FRESH guard로 FRESH 매칭에서 자동 차단 중이나, historical 누적이 15개까지 자람. cleanup cron 임무 #30 `cleanup-pt-details-splice.py` 신구 모듈 권장 미완료 상태.

cron 차 사이 한 건 이상의 외부 발행이 일반화됨을 네 번째로 확인:
- 253차 (식별) → 254차 (1호) → 270차 (2호) → 282차 (3호) → **283차 (4호)**

## 본문 빌드 (283차)
- `/tmp/tistory_drafts_283rd/build_draft_31498.py` (9095 bytes, UTF-8 선언)
- `/tmp/tistory_drafts_283rd/draft_31498.html` (8708 bytes)
- 본문 평문 6663자 (intro + 본문 5868자 + conclusion)
- `_try_md_endpoint(31498)` → 12110 bytes 1단계 `.md` fetch 정상

## intro / conclusion 패턴 (260차 정착)
- intro: 한국 독자층 맞춤 1~2 단락 (Xeon E5-2690 v2 + AVX2 폴백 + Claude 디버깅 컨텍스트)
- conclusion: 한국 IDC 환경 시사점 3가지 (비용 효율 / 에어갭 대응 / 엔지니어링 훈련)
  + 한계 (디코딩 5.2 토큰/초로 사람 대화 불가, 배치 검토 잡에만 적합)

## 동작 검증된 패턴 (모두 정상)
- §3.8.1 가드 (status=200, ct=application/json;charset=UTF-8, cookies=8)
- §3.8.2 격리 (`env -i HOME=... PATH=... PWD=... /bin/bash -c '...'` + `/usr/bin/python3` 3.9)
- §3.11 sync CLI (`sync` 서브커맨드 + 7필드 보정)
- §3.34.40 v2 (FRESH 4-field + pt_last_gn pub set 추가)
- §3.34.43 PWD 보강 (`PWD=/Users/mac` 명시)
- §3.34.46 영구화 (`_try_md_endpoint(31498)` → 12110 bytes)
- §3.34.47 격리 빌드 (write_file + 격리 호출)
- §3.34.48 `*` 분기 (이번 본문엔 `-` 만 사용, 분기 안전 가드)
- §3.34.50 Topic Body 마커 (5868자 본문 추출)
- §3.34.52 IME 가드 (title ASCII 토큰 sanity check)
- §3.34.53 `gfc` alias (importlib spec_from_file_location("gfc"))
- §3.34.54 `>` blockquote (이번 본문엔 `>` 라인 없어 미적용)
- §3.34.55 시그니처 (`text = _try_md_endpoint(tid)` 단일 변수 할당, 4회째)
- §3.34 #21 정책 + §3.34.45 매트릭스
- cleanup cron 임무 #16 (`cleanup_daily_cat_id_leak.py`)

## Picsum 자동 매칭 — cleanup cron 임무 #38 신규
자연어 query도 첫 빌드에서 안정적으로 매칭:
- query: `old server cpu heatsink xeon vintage datacenter llama gemma running`
- 결과: ID 472 (두 슬롯 동일, 첫 시도 적중)
- Picsum router 자동 매칭이 영문 자연어 + 키워드 혼용 query를 안정 처리 — 기존 가이드에 이미 자연스럽게 적용

## 라이브 페이지 검증
```
window.T.entryInfo = {"entryId":1032,"isAuthor":true,"categoryId":1219746,"categoryLabel":"AI 뉴스"};
<title>13년 된 Xeon에서 GPU 없이 Gemma 4 26B를 초당 5토큰으로 굴려보게 된 과정 &mdash; AVX2 폴백&middot;...</title>
status=200, size=79234
```

## 본 세션 신규 발견
**0건** — 모든 패턴 정착된 playbook 그대로 정상 동작.

## 후속 작업 권장
1. cleanup cron 임무 #30: `scripts/cleanup-pt-details-splice.py` 신구 모듈 — pt.details와 state.details splice drift 자동 보정 (historical 누적이 15개까지 누적, 한계 도달).
2. cleanup cron 임무 #38: 기존 가이드에 "Picsum query는 영문 자연어 + 키워드 혼용 형태 권장" 명시 (현재 가이드 보강).
