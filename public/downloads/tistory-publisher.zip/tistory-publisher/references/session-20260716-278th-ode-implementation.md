# 278차 세션 (2026-07-16) — Ode with Anthropic 발행 + §3.34.54 신규

## 발행 내역
- `#1025` 앤트로픽·블랙스톤이 15억 달러짜리 「구현」 회사를 차렸다 — 모델 말고 엔터프라이즈 AI 파일럿을 실제로 끝내는 Ode
  - 카테고리: AI/ML (cat_id=1219746)
  - gn_topic_id=31490, 9점, FRESH AI/ML 1순위
  - 라이브: https://sigco.tistory.com/1025 (status=200, size=54416)
- 연속 all-green **65회차** (213~278차)
- Picsum ID 939 (두 슬롯 동일 자동 매칭)

## 워크플로 체크
- §3.8.1 가드 통과 (cookie_count=8)
- §3.34.40 v2 FRESH 4-field (FRESH 9개 식별)
- §3.34.46 영구화 (`_try_md_endpoint(31490)` 1349 bytes 1단계 fetch)
- §3.34.50 Topic Body 마커 6회째 (본문 평문 1279자)
- §3.34.47 격리 빌드 (`/tmp/tistory_drafts_278th/build_draft_31490.py` 6334 bytes)
- §3.34.53 `gfc` alias 2회째 (importlib spec_from_file_location 정상)
- §3.34.52 IME 가드 (title ASCII 토큰 `AI`, `Ode` sanity + 라이브 `<title>` cross-check OK)
- §3.5 5중 신호 5/5 `#1025` 일치 (`all_match: True`)
- daily_counts[2026-07-16]['AI/ML'] = 8 (7→8, +1 정확)
- cleanup cron 임무 #16 dry-run 65회 연속 all-green

## §3.34.54 (NEW) — `md_to_html` 5번째 패턴: `> blockquote` 라우팅

### 식별 케이스
- 278차 본문 (`gn=31490`) 은 `## Topic Body` 직후 `> Anthropic, Blackstone, Hellman & Friedman 3사가 ...` 로 시작
- 260차 정착 4종 패턴(`## 헤더` / `### 헤더` / `- 리스트` / `**bold**`)은 `>` 라인을 일반 paragraph 로 떨어뜨림
- 결과: `<p>&gt; Anthropic, Blackstone...</p>` (HTML escape + 시각적이지 않음 + 원문 의도 파괴)

### 회피 — `md_to_html` 에 5번째 분기 추가

```python
elif stripped.startswith(">"):
    if in_ul:
        out.append("</ul>")
        in_ul = False
    quote_text = stripped.lstrip(">").strip()
    out.append("<blockquote>" + html.escape(quote_text) + "</blockquote>")
```

### 적용 범위
- §3.34.46 본문 빌드의 모든 변형
- `build_draft_*.py` / `gn-markdown-to-tistory-html.py` 모듈 둘 다 영향
- 278차엔 `build_draft_31490.py` 에 분기 박혀있어 후속 차엔 동일 패턴 적용 가능

### 영향 받던 케이스 (이미 본 세션 / 차세션 hit 케이스)
- gn=31490 Ode with Anthropic (278차, 첫 hit)
- gn=31378 geohot LLM 과대광고 (261차 — 본문 `<blockquote>` 누락 가능성, 재검증 권장)

### 영구화 권장 (cleanup cron 임무 #34)
- `scripts/gn-markdown-to-tistory-html.py` 모듈의 `md_to_html` 함수에 blockquote 분기 자동 반영
- 현재 `build_draft_*.py` 만 분기 추가되어 있어 모듈 차원 패치 필요

## 검증 결과 (278차 publish 후)
- 라이브 페이지 `<title>`: `앤트로픽&middot;블랙스톤이 15억 달러짜리 「구현」 회사를 차렸다 &mdash; 모델 말고 엔터프라이즈 AI 파일럿을 실제로 끝내는 Ode` (Ode 정상)
- §3.5 5중 신호 모두 `#1025` 일치
- pt.last.title + state.last.title + state.details[-1].title 모두 동일 (IME 변환 0)
- 가짜 발행 가드 정상

## 차감/추가
- 차감: 없음
- 추가: §3.34.54 신규 (5번째 패턴) + cleanup cron 임무 #34
- 277차 정착 패턴(§3.34.50 Topic Body / §3.34.46 영구화 / §3.34.47 격리 빌드 / §3.34.48 `*` 분기 / §3.34.52 IME 가드 / §3.34.53 `gfc` alias / §3.34 #21 정책 / §3.11 sync / §3.5 5중 검증 / cleanup #16) 모두 278차 5~7회째 정상 동작 — 워크플로 정착 완료.