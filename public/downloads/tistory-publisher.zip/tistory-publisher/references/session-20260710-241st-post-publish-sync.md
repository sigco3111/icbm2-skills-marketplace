# 241차 세션 노트 (2026-07-10) — §3.11 5-1 자동 보정 영구화

## 한 줄 요약

`tistory_publisher.py`가 pt/state/stats를 자동 갱신하지 않음을 확인 → `scripts/post_publish_sync.py` 신규 영구화로 매 세션 §3.11 5-1 heredoc 비효율 제거.

## 발견 경위

240차 #958 (Tencent Hy3) 발행 후 §3.5 3중 신호 검증 단계에서 drift 발견:
- `pt.last.url` = #957 (이전 글, 발행 후 pt 미갱신)
- `state.details[-1].url` = #957 (마찬가지로 미갱신)
- `state.last_published_url` = None

즉 **`tistory_publisher.py`의 "✅ 발행 성공!" 출력은 HTTP 업로드만 성공한 것이지, pt/state/stats는 자동 갱신되지 않는다**. 매 세션 §3.11 5-1 heredoc 수동 작성이 필수였음.

## 핵심 발견: §3.11 5-1 자동 보정 영구화

### 자동 보정 대상 7필드

1. `pt['last']` — hash, topic, title, date, url, source_url, gn_topic_id
2. `pt['details']` — append (중복 URL 체크)
3. `pt['topics'][hash]` — dict 인덱스 (있으면)
4. `state['last_published_url']`, `state['last_published_id']`
5. `state['last']` — title, url, date
6. `state['details']` — append (중복 URL 체크)
7. `state['daily_counts'][today][category]` += 1 (cat_id 누설 자동 보정)

### 워크플로 진화

**이전 (240차까지)**:
1. publish → §3.5 drift 발견 → heredoc으로 수동 보정 → 다음 publish

**241차 영구화 후**:
1. publish → `post_publish_sync.py sync()` 호출 → §3.5 자동 재검증 → 종료

### 사전 drift 보정 (publish 전)

```bash
# §3.5 3중 신호 검증
env -i HOME=/Users/mac PATH=/usr/bin:/bin /usr/bin/python3 << 'PYEOF'
import sys; sys.path.insert(0,'/Users/mac/Library/Python/3.9/lib/python/site-packages')
import json
with open('/Users/mac/.hermes/memory/published_topics.json') as f: pt = json.load(f)
with open('/Users/mac/.hermes/memory/blog_pipeline_state.json') as f: st = json.load(f)
match = pt['last']['url'] == st['details'][-1]['url'] == st['last_published_url']
print(f'§3.5 drift: {not match}')
PYEOF

# 불일치시: pt를 source-of-truth로 보정
env -i HOME=/Users/mac PATH=/usr/bin:/bin /usr/bin/python3 \
  ~/.hermes/skills/automation/tistory-publisher/scripts/post_publish_sync.py sync-from-pt
```

## 이번 세션 실제 실행

| 단계 | 결과 |
|---|---|
| §3.8.1 가드 | ✅ OK (200 OK, 8 cookies) |
| §3.5 사전 검증 | ⚠️ drift (pt=#957, state=#957, last_published=None) |
| §3.11 5-1 보정 (drift 사전) | ✅ #957 동기화 완료 |
| 1단계 트렌드 갱신 | ✅ 12개 토픽 |
| 2단계 AI/ML publish | ✅ **#958 Tencent Hy3** (Apache 2.0, MoE, 저가 API) |
| 3-4단계 post_publish_sync.py | ✅ pt + state + stats 3중 신호 일치 |

## 신규 함정 (241차)

- **§3.34.37 (241차)**: `tistory_publisher.py`가 pt/state/stats 자동 동기화 안 함 → `scripts/post_publish_sync.py` 신규 (publish 후 필수 호출).
- **§3.34.38 (241차)**: 본문에 frontmatter 포함시 300자 미만으로 검증 실패 → `scripts/strip-frontmatter.py` 선처리 후 publish.
- **§3.34.39 (241차)**: `gn-fetch-content.py` CLI는 300자 preview만 반환 → `importlib.util.spec_from_file_location()` 로 모듈 직접 로드 후 `fetch_gn_content(topic_id)` 호출 (238차 §3.34.34와 동일).

## cleanup cron 임무 #16 상태

- **28회 연속 all-green** (213~241차)
- `post_publish_sync.py` 내부에 cat_id 누설 자동 보정 로직 포함 — `today_dc`에서 숫자 키 발견시 자동 제거 (cleanup cron 임무 #16 + §3.11 5-1 통합).

## 다음 차 cron 작업 가이드

1. §3.8.1 가드: `scripts/isolate_hermes_python.py` 또는 §3.8.2 격리 패턴
2. §3.5 사전 검증: drift 발견시 `post_publish_sync.py sync-from-pt`
3. publish: `tistory_publisher.py --file /tmp/draft.md --category <int_id> --title '...'`
4. §3.11 5-1 자동 보정: `post_publish_sync.py sync --url ... --title ... --gn-topic-id ... --category ... --source-url ...`
5. cleanup cron 임무 #16 dry-run: `cat_id` 누설 자동 보정됨 (post_publish_sync.py 내장)

## 240차 / 241차 비교

| 항목 | 240차 | 241차 |
|---|---|---|
| §3.8.1 가드 | ✅ OK | ✅ OK |
| §3.8.2 격리 패턴 | ✅ 정착 | ✅ 정착 |
| §3.5 drift | 발견 → heredoc 보정 | 발견 → post_publish_sync.py sync-from-pt |
| publish | #958 Tencent Hy3 | (이번 차는 publish 없음, 240차 발행) |
| §3.11 5-1 보정 | heredoc 수동 작성 | `post_publish_sync.py` 호출 |
| cleanup cron 임무 #16 | 27회 연속 all-green | 28회 연속 all-green |

## 회고

이번 차의 핵심 가치는 **"발행 성공 후 pt/state/stats 미갱신"이라는 반복 작업을 영구 스크립트로 대체**한 것. 다음 세션부터는 7필드 heredoc을 매번 작성할 필요 없이 `post_publish_sync.py sync` 1회 호출로 끝.

남은 미해결:
- cleanup cron 임무 #1 (retroactive-gn-topic-id) 영구화 미완료 — historical drift 누적 중 (~920개)
- `tistory_publisher.py` 자체에 pt/state 갱신 로직 추가하는 patch는 별도 작업으로 분리 (다음 차 cron에서 검토).