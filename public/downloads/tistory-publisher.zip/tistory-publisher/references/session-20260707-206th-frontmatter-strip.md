# 206차 — `--file` frontmatter strip 필수 + Notion PATCH 자동 cleanup 6/6 재확인

**날짜**: 2026-07-07
**차수**: 206 (cron 자동)
**환경**: cron 자동 (Hermes scheduled job, no user present)

## 작업 요약

- **발행**: #916 "의미가 보이는 프로젝트를 설계하는 법" (AI/ML, 1219746, 2,167자 / 6 H2 / 2 Picsum images)
- **drift**: 0 (4-way 정합: Tistory 916 = state 916 = urls 916 = details 916)
- **누적 drift**: 121 (stats 900 vs Tistory totalCount 779) §3.16 별도 작업 대상

## §3.23.1 — `--file` frontmatter strip 필수 (신규 영구화)

### 문제 발견
206차에서 LLM이 생성한 markdown 본문이 표준 frontmatter (`---\ntitle: ...\ndate: ...\ncategory: ...\ntags: ...\nsource: ...\n---\n`)를 포함하는 형태였음. 이를 그대로 `tistory_publisher.py --file`로 전달하니 content 검증 단계에서 거절:

```bash
$ python3 ~/.hermes/scripts/tistory_publisher.py --file /tmp/blog_206th/post_31176.md ...
❌ Content 텍스트 길이 부족: 107자 < 300자 (최소 필요)
```

- 파일 실제 크기: 5,540 bytes / 2,500자 (한글)
- 인식된 content 길이: **107자** ← frontmatter 메타데이터 줄만 인식되고 `# 본문` 시작 부분은 검증에서 누락

### 원인 (코드 측면)

`tistory_publisher.py`의 content 검증 로직은 `read_file().strip()`으로 파일 전체를 읽고 첫 300자를 확인. frontmatter가 포함된 경우:

```markdown
---
title: "AI 시대, 의미가 보이는 프로젝트를 설계하는 법"
date: 2026-07-07
category: AI/ML
tags: AI시대,데이터모델링,TODO앱,소프트웨어설계,의미있는프로젝트
source: https://news.hada.io/topic?id=31176
---

# AI 시대, 의미가 보이는 프로젝트를 설계하는 법
...
```

frontmatter가 `# 본문` 직전까지 차지해서 300자 검증에 실패. 결과: "텍스트 길이 부족".

### 해결 (206차 확정)

`--file` 호출 직전에 frontmatter strip 단계 추가:

```python
with open('/tmp/blog_206th/post_31176.md') as f:
    content = f.read()

# frontmatter strip
if content.startswith('---'):
    end = content.find('---', 3)
    content = content[end+3:].lstrip('\n')

# content-only 파일로 저장
with open('/tmp/blog_206th/post_31176_content.txt', 'w') as f:
    f.write(content)

# --file에 content-only 전달
# python3 ~/.hermes/scripts/tistory_publisher.py \
#   --file /tmp/blog_206th/post_31176_content.txt \
#   --title "..." --category 1219746 --tags "..." --image-query "..."
```

**결과**: `📄 Content 검증 통과: 2167자` → 정상 발행 #916.

### half-pipeline §3.18 패턴 갱신 (4→5단계)

| 단계 | 변경 전 (198~205차) | 변경 후 (206차+) |
|---|---|---|
| 1 | `blog_pipeline.py --category 'X'` | 동일 |
| 2 | guidline JSON 파싱 | 동일 |
| 3 | 외부 워커 본문 작성 | 동일 (frontmatter 포함 가능) |
| **4 (신규)** | — | **§3.23.1 frontmatter strip** |
| 5 (구 4) | `tistory_publisher.py --file` | `tistory_publisher.py --file <content_only_path>` |
| 6 (구 5) | §3.11 5단계 + §4 5-1 stats 보정 | 동일 (tistory.env §3.22.1 형식) |

### 장기 권장
- `scripts/strip-frontmatter.py` standalone 작성 (또는 heredoc 1줄)
- 또는 `tistory_publisher.py` 자체에 `--strip-frontmatter` 옵션 추가 (코드 패치 — 별도 cron 임무)

## §3.23.2 — Notion PATCH 자동 cleanup 6/6 재확인

205차 §3.22.2의 30자 prefix 매칭이 206차에서도 6/6 성공 → 영구 단계 격상 재확인.

### 206차 매칭 결과

| Notion 페이지 이름 | state.last_topics 매칭 (30자 prefix) | PATCH |
|---|---|---|
| 덜한 것이 더 낫다, 대체로 | "덜한 것이 더 낫다, 대체로 — AI 시대 제품..." | ✅ |
| 많이 조회되지 않은 콘텐츠 | "많이 조회되지 않은 콘텐츠" | ✅ |
| Starring the Computer: 화면 속 컴퓨터 출연 목록 | "Starring the Computer: 화면 속 컴퓨터 출연 목록" | ✅ |
| AI 시대, Figma를 다시 생각하다 | "AI 시대, Figma를 다시 생각하다 — 캔버스가..." | ✅ |
| Show GN: Fable5는 비싸지고, 로컬 GPU는 부족하다 | "Show GN: Fable5는 비싸지고, 로컬 GPU는 부족하다..." | ✅ |
| OpenTag - Slack용 Claude Tag의 오픈소스 대안 | "OpenTag - Slack용 Claude Tag의 오픈소스 대안" | ✅ |

**누적 11/11** (205차 5/5 + 206차 6/6). 한글/영문 혼합 title에서 30자 prefix가 안정적으로 매칭됨.

## 타임라인

| 시각 (추정) | 작업 | 결과 |
|---|---|---|
| T+0:00 | §3.8.1 3-endpoint probe | ✅ 3/3, 200 OK |
| T+0:01 | Tistory max id fetch | 915 (205차 일치) |
| T+0:02 | `blog_pipeline.py --refresh-topics` | 12개 토픽 |
| T+0:03 | Notion 활성 조회 | 12개 (last_topics 8개 일치, cleanup 후보 6개) |
| T+0:04 | §3.23.2 Notion PATCH 자동 cleanup | 6/6 ✅ |
| T+0:05 | 4중 dedup 재계산 | 12→6 후 3개 후보 (AI/ML 2 + 개발도구 1) |
| T+0:06 | 후보 31176 "의미가 보이는 프로젝트" 선택 | AI/ML 요약 풍부성 우선 |
| T+0:08 | heredoc으로 markdown 작성 (frontmatter 포함) | 2,500자 |
| T+0:09 | §3.23.1 frontmatter strip → content-only | 2,167자 |
| T+0:09 | `tistory_publisher.py --file` | ✅ #916 발행 |
| T+0:10 | §3.11 5단계 + §4 5-1 stats 보정 heredoc | 5필드 동기화 (stats 899→900, AI/ML 704→705) |
| T+0:11 | §3.5 4-way drift validation | ✅ drift 0 |

## 보정 heredoc 핵심 코드 (§3.22.1 tistory.env 파싱 형식)

```python
# §3.22.1 — tistory.env 파싱 형식 (export 접두사 ❌)
cookies = {}
with open(os.path.expanduser('~/.hermes/secrets/tistory.env')) as f:
    for line in f:
        line = line.strip()
        if line.startswith('TISTORY_') and '=' in line and not line.startswith('#'):
            kv = line.split('=', 1)
            cookies[kv[0].replace('TISTORY_','')] = kv[1].strip()

# §3.18 + §3.23.1 — int 캐스팅 (Tistory items[].id는 문자열)
ids = [int(it.get('id', 0)) for it in items if it.get('id')]
max_id = max(ids) if ids else 0

# §3.20.3 — published_urls.txt 비대칭 tab 포맷 안전 파싱
with open('/Users/mac/.hermes/memory/published_urls.txt') as f:
    tistory_lines = [l for l in f if 'sigco.tistory.com' in l]
    last_id = int(tistory_lines[-1].split('\t')[0].rstrip('/').split('/')[-1]) if tistory_lines else 0
```

## 후속 권장 작업

1. **`scripts/strip-frontmatter.py` 작성** — `tistory_publisher.py --file` 호출 직전 standalone strip 유틸
2. **`tistory_publisher.py --strip-frontmatter` 옵션 추가** (코드 패치) — LLM이 frontmatter 포함 markdown 생성 시 자동 처리
3. **누적 drift 121 §3.16 정리** — 별도 cron 작업으로 stats.total_published 보정 (stats - 121 = Tistory totalCount)
4. **`last_titles_full` 4중 dedup** — 205차 §3.22.3 영구 단계, 206차 자동 적용됨

## 결론

206차는 **drift 0**으로 깔끔하게 종료. §3.23.1 frontmatter strip 함정이 신규 영구 단계로 격상됨. §3.22 영구 단계들 (4중 dedup, Notion PATCH 자동 cleanup, tistory.env 파싱 형식)이 206차 cron 환경에서도 모두 정상 작동 확인. 누적 drift 121은 별도 cron 작업으로 분리.