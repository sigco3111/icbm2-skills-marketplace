# 320차 (2026-07-26) — 아침 세션 만료 점검 cron + 함정 18 신규 (hermes send cron skip)

## 시간
2026-07-26 아침 (cron 자동 실행).

## 워크플로우 종류
**발행 cron이 아님**. 아침 점검 cron은 `verify-tistory-cookie.sh`로 쿠키만 검증하고 만료시 알림. publish 단계 없음.

## 진단 결과

**ad-hoc verify (`verify-tistory-cookie.sh`): PASS=13 / FAIL=2 / WARN=1**
- env 파일 무결성, 5종 키 존재, 백업 보존, 환경변수 로드 = 모두 PASS
- **FAIL**: `tistory_publisher.py --check-session` → JSON 파싱 실패 (302 HTML 응답)
- **FAIL**: `'Expecting value'` 에러 회귀 방지 실패
- **WARN**: `--categories` 호출 결과 비어있음

**3-endpoint probe (직접 검증)**:
- `posts.json`: **HTTP 302** → Location `https://www.tistory.com/auth/login?redirectUrl=...`
- `category.json`: **HTTP 302** → 동일
- cookies_count: **8** (env에는 살아있으나 서버가 만료 처리)

**판정**: §3.8.1 Zombie 302 (쿠키는 env에 존재하지만 서버가 만료로 거부).

## 현재 상태

- 마지막 정상 발행: **#1099** (2026-07-24 03:04경)
- `state.last_published_url`: `https://sigco.tistory.com/1099`
- 오늘(2026-07-26) 발행: **0건** (cron skip 유지)
- stats.total_published: 93 (정상 누적)
- **연속 all-green 99회차 → 현재 잠정 중단**

## 안전 동작 확인

- `§3.8.1` 가드 정상 작동 → publish skip으로 **가짜 발행 0건** (stats 오염 없음)
- env 자동 갱신 시도 안 함 ✓
- stats 롤백 실행 안 함 ✓
- 패치/스킬 수정 안 함 ✓ (검증 + 알림만)

## 🆘 함정 18 — cron 모드에서 `hermes send` 호출 skip (320차 신규)

**문제**: cron 잡 자동 전달 대상과 동일한 chat_id로 `hermes send` 호출 시 즉시 skip.

**시도 1**: `hermes send --to telegram` (home channel 미설정):
```
hermes send: No home channel set for telegram to determine where to send the message.
Either specify a channel directly with 'telegram:CHANNEL_NAME', or set a home channel via:
hermes config set TELEGRAM_HOME_CHANNEL <channel_id>
```

**시도 2**: `hermes send --to telegram:8359527845 -s "..." --file /tmp/tistory_expired_alert.txt`:
```
Skipped send_message to telegram:8359527845. This cron job will already auto-deliver
its final response to that same target. Put the intended user-facing content in your
final response instead, or use a different target if you want an additional message.
```

**해결**: final response 본문에 알림 내용을 직접 작성. 시스템이 cron의 configured destination으로 자동 전달.

**원칙 (320차 정형화)**:
- cron 모드 사용자 알림 = **final response 본문에 직접 통합**
- `hermes send`는 (a) 다른 채널(예: 디스코드)에 동시 발송하거나 (b) 자동 전달 외 추가 메시지가 필요할 때만 사용
- 메시지 파일을 `/tmp/...txt`로 만들고 `--file` 옵션으로 발송하는 패턴은 정상이나, **대상이 cron의 자동 전달 chat_id와 동일하면 skip됨** → final response 통합이 정답

## 📈 만료 추이 갱신

| 시점 | 만료 간격 | 비고 |
|------|-----------|------|
| 184차(6/29) → 196차(7/2) | 3일 | 초기 트래픽 적음 |
| 196차 → 7/6 | 8일 | 안정화 단계 |
| ~319차(7/24) | 18일 정상 | 발행 cron 99회 연속 all-green |
| 319차(7/24) → 320차(7/26) | **1.5일** | 평소보다 급격히 짧음 |

**관찰**: 18일 → 1.5일로 만료 주기가 급격히 짧아짐. 트래픽 변화 또는 Tistory 측 쿠키 회전 정책 변경 가능성. 다음 만료 시점 예측 어려움. **매일 아침 점검 cron이 더 자주 필요해질 수 있음**.

## 정형 워크플로우 (320차 SKILL.md 반영 완료)

- **발행 cron**: `session_expiry_guard.sh` → publish까지 진행 (기존 §1~§5)
- **아침 점검 cron**: `verify-tistory-cookie.sh` → 검증 + 알림만 (320차 신규 §「🌅 아침 세션 만료 점검 cron」)

두 워크플로우는 별개 cron 잡. 아침 점검 cron에서 FAIL 시 가짜 발행은 0건이어야 정상 (publish 단계가 없으므로).

## References

- SKILL.md §「🌅 아침 세션 만료 점검 cron (별도 워크플로우, 320차 정형화)」
- SKILL.md 함정 18 — cron 모드에서 `hermes send` 호출 skip
- `references/section-3-8-1-session-guard.md` — §3.8.1 Zombie 302 가드 패턴