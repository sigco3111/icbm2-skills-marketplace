# 341차: parts.append() + code_lines 분리 정형 재검증

## 결과
- 주제: `탈옥한 Kindle에서 활용하는 더 많은 Tailscale 기능` (gn=31954, AI/ML)
- 실제 제목: `탈옥한 Kindle에서 활용하는 더 많은 Tailscale 기능 — KOReader와 TUN 모드 실전 가이드`
- 발행 URL: `https://sigco.tistory.com/1139`
- 본문: 순수 텍스트 3,665자, 발행 측정 3,109자, 이미지 2장, Bash 코드 블록 1개
- OG 썸네일: `https://blog.kakaocdn.net/dna/bE9KAj/dJMcaiRL7mj/AAAAAAAAAAA...`

## 핵심 패턴 재확인

이번 차는 340차 정형화 (parts.append() + code_lines 분리 + `--content` 단일 폴백 + §3.5 구조적 오탐 disambiguate)를 그대로 재현한 **정형 정상 차**였다. 새 함정/관찰 없음 — 정형 패턴의 안정성을 입증.

### 빌드 패턴 (340차 + 336차 결합)
- `parts.append("<h2>...</h2>")`, `parts.append("<p>...</p>")` 리스트로 본문 모음
- `parts.append("<pre><code>...</code></pre>")` 안에 multiline HTML literal을 직접 박으면 `\\n` 박혀서 SyntaxError → **무조건 `code_lines = [...]` + `'<pre><code class="language-xxx">' + "\\n".join(code_lines) + '</code></pre>'` 정형**
- 본문 + 이미지 2장 + 코드 1개 = `parts.append()` 정형 권장 판정 (338차 정형: 본문 ≥ 3000자 + 코드 1개)

### publish 패턴
- `--content "$CONTENT"` 단일 폴백 (324→339→340→341차 = **4회차 검증**) — `--file` parser 거부 패턴 안정화
- `set -a; source tistory.env; unset PYTHONPATH PYTHONHOME; PYTHONNOUSERSITE=1; export PYTHONPATH=user-site; /usr/bin/python3 -s` 정형 격리 (303차 안정 패턴)

### 검증 패턴
- 진입 시점 §3.5 신호 4 발동 (구조적 오탐) → 직전 #1138의 5-5 proxy disambiguate
- publish 직후 `--commit` → 5-3 last+details 통합 보정 → 5-2-A 누락 백필 1건 + last 명시 동기화
- 최종 §3.5 신호 4 발동 (구조적 오탐 — 5-3에서 details+last 같은 슬롯 보정 시 무조건) → 동일 URL의 5-5 proxy check PASS (status=200 + og:title 정확 + source_present=True + cjk_suspicious=0)
- → `§3.5 구조적 오탐` 보고 (335차 정형화 패턴, 35연속 disambiguate)

## 관찰
- daily_counts[2026-07-30] AI/ML: 1→2 (340차 마지막이 #1138 어제 → 341차 #1139 = 오늘 1차), total=133
- state.last, state.details[-1], published_topics.last 모두 #1139 일치
- 5-2-A 누락 백필 1건 자동 처리 (state.json엔 #1139, published_topics.json엔 누락 → 300차 정형 패턴)
- `by_category["1219746"]=1` 정수 ID 키 영구 잔존 36연속 (297→341) — SSOT 변경 사용자 게이트 후 보정 권장
- 연속 all-green **115회차**

## 340차 → 341차 정형 패턴 안정성 확인
- 진입 5-5 **16연속** (310→341)
- 단일 패스 **36연속** (305→341)
- 신호 4 disambiguate **35연속** (298→341)
- `--content` 단일 폴백 **4회차 검증** (324→339→340→341)
- fallback 복귀 **28연속** (311→341) — 341차는 AI/ML 정상 ready, fallback 미발동