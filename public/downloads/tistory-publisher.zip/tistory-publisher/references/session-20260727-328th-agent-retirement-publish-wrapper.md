# 328차 — AI 코딩 에이전트 정리와 standalone publish wrapper

- **발행일**: 2026-07-27 23:09 KST
- **글 번호**: #1117
- **카테고리**: AI/ML (`1219746`)
- **긱뉴스 토픽**: `gn=31873`, `https://news.hada.io/topic?id=31873`
- **canonical topic**: `Show GN: 에이전트를 22개까지 늘렸다가 17개로 줄인 이야기`
- **canonical MD5**: `c5003e71ea53194553769131d1596d3b`

## 새로 확인한 패턴

### 1. 대형 `--content` shell substitution은 실행 전 거부될 수 있음

HTML 파일 전체를 아래처럼 인자에 삽입한 호출은 실행되지 않았다.

```bash
tistory_publisher.py --content "$(python3 - <<'PYEOF' ... PYEOF)" ...
```

실제 결과는 `pending_approval`과 `command parser limit or malformed executable payload`였고, Tistory 요청 자체는 발생하지 않았다. 같은 inline 호출을 재시도하지 않고 `/tmp/publish_328.py`를 작성해 `publish_post()`를 직접 호출했다.

래퍼 실행 결과:

```text
이미지 업로드 성공 2/2
OG 썸네일 설정
PUBLISH=SUCCESS
URL=https://sigco.tistory.com/1117
```

이 방식은 `--content`의 셸 인자 크기·따옴표 문제를 피하면서 기존 이미지 CDN 업로드, 출처 푸터, 카테고리, 공개 범위를 그대로 사용한다.

### 2. `write_file`에 heredoc 종료 표식을 넣지 말 것

빌드 파일 마지막에 우발적으로 `PYEOF`가 남아 첫 실행에서 다음 결과가 발생했다.

```text
본문 파일 생성 및 로그 출력 완료
NameError: name 'PYEOF' is not defined
exit_code=1
```

본문 파일이 생성됐다는 사실만으로 성공 처리하면 안 된다. 종료 표식을 제거하고 빌드 스크립트를 다시 실행해 exit 0을 확인해야 한다. 산출물은 별도로 존재 여부, 크기, 순수 본문 길이, 이미지 수를 검사한다.

### 3. `§3.5 FAKE_PUBLISH`는 proxy로 해소

`--commit` 후 `daily_counts`는 `AI/ML: 8→9`, 총 일일 건수는 11→12로 증가했다. `last_published_url`, `last_published_id`, state details, published_topics details/last, canonical hash, source URL을 #1117로 동기화한 직후 §3.5 신호 4가 구조적으로 발동했다.

최종 proxy 결과:

```text
status=200
og_title=에이전트를 22개까지 늘렸다가 17개로 줄인 이야기 — AI 코딩 에이전트 정리와 운영 원칙
PROXY=PASS
has_source=True
```

따라서 실제 발행으로 확정했다. `published_urls.txt`에는 원본 URL과 Tistory URL이 각각 한 번 기록됐고, `published_topics.json`에는 canonical topic의 MD5를 저장했다.

## 재사용 순서

1. 발행 직전 raw 세션 가드 재검증.
2. canonical hash, state details, published URL 세 축으로 중복 재검증.
3. 본문 빌드 스크립트 exit 0 + 산출물 검사.
4. 긴 본문은 임시 standalone wrapper에서 `publish_post()` 직접 호출.
5. 숫자형 URL을 stdout에서 확보한 뒤에만 `blog_pipeline.py --commit`.
6. state/published_topics/published_urls 동기화.
7. §3.5 실행 후 신호 4면 HTTP 200 + `og:title` 정확 일치로 판정.
