# 289차 (2026-07-18 06:01) — 가짜 발행 누적 5건 감지

## 한 줄 요약

세션 가드 VALID 통과했으나 daily_counts[2026-07-18]에 AI/ML 4 + 개발팁 1 = **5건 가짜 발행 누적** 상태에서 publish 단계 skip.

## 입력 상태

| 항목 | 값 |
|---|---|
| 세션 만료 가드 | ✅ VALID (TISTORY_* 8개 쿠키, env 격리 후 inline source) |
| 트렌드 새로고침 | ✅ 12개 (Notion DB 갱신) |
| `daily_counts[2026-07-18]` | `{"AI/ML": 4, "개발팁": 1}` (합계 5) |
| `details[-1].url` | `https://sigco.tistory.com/1043` (SpaceX IPO, 287차) |
| `last_published_url` | `https://sigco.tistory.com/1043` (== details[-1]) |
| `last_topics[-1].title` | `Bun을 Rust로 다시 쓰기` (stale, 개발팁 7/10 발행 잔재로 추정) |

## §3.5 3중 신호 결과 (인라인 검증)

- [A] `last_published_url` == `details[-1].url` → ✅
- [B] `details[-1].title(SpaceX)` vs `last_topics[-1].title(Bun)` → ⚠️ **MISMATCH**
- [C] **`daily_counts[2026-07-18]` 합계 5 vs `details[-1]` 변동 없음** → ⏸️ **FAKE_PUBLISH_SUSPECTED**

## 발행 결정

**skip** — 추가 publish 시 stats +1 박으면 6/6/6 가짜 누적 → SSOT 복구 불가 영역으로 빠짐.

## 발견된 함정 3가지

### 1. `session_expiry_guard.sh` 자체 격리 (`env -i`) 는 `set -a; source tistory.env` 무효화

스크립트는 격리된 env에서 실행되므로 `set -a`로 셸에 source한 TISTORY_* 가 내부 python에 안 들어감. **289차 우회**:

```bash
set -a; source ~/.hermes/secrets/tistory.env >/dev/null 2>&1; set +a
COOKIE_VALS=$(env | grep '^TISTORY_' | sed 's/^/export /' | tr '\n' ';')
env -i HOME="$HOME" PATH=/usr/bin:/bin PYTHONPATH= \
  bash -c "$COOKIE_VALS /usr/bin/python3 <<'PYEOF' ... PYEOF"
```

근본 해결: `session_expiry_guard.sh` 첫 줄에서 `set -a; source ~/.hermes/secrets/tistory.env; set +a` 후 export된 변수만 env -i에 `-u KEY`로 명시 주입하는 패턴으로 리팩터 필요.

### 2. `check_state_consistency.py` PEP 604 union → SyntaxError on 3.9

`def extract_slot(url: str | None) -> int | None` 가 `/usr/bin/python3` (3.9)에서 즉시 죽음. **289차 패치 완료**: `Optional[str]` / `Optional[int]` 로 변환, `from typing import Optional` 추가.

### 3. drift 시나리오 4번째 케이스 (가짜 발행 누적) 검출 누락

기존 신호 1/2/3은 모두 "직전 1건 발행 상태의 정합성"만 봄. **`daily_counts[오늘]` ≥ 2 + `details[-1]` 슬롯 변동 없음** = 누적된 가짜 발행을 못 잡음. **289차 패치 완료**: 신호 4 FAKE_PUBLISH 추가, `daily_counts[today]` ≥ 2 AND `last_detail_slot == last_slot` 이면 drift로 마킹.

## 다음 차 워크플로우

1. **Tistory 실제 글 카운트로 daily_counts 보정**: `https://sigco.tistory.com/manage/posts.json?page=1` 에서 오늘 published posts 수 카운트 → daily_counts[2026-07-18] 차감
2. `last_topics[-1]` 강제 동기화: `details[-1].url` 과 `details[-1].title` 을 cron 발행 직후 즉시 write (현재는 details만 갱신되고 last_topics는 stale 가능)
3. session_expiry_guard.sh 리팩터 (함정 1번 참조)

## 코드 스니펫 (신호 4 재현용)

```bash
unset PYTHONPATH
env -i HOME="$HOME" PATH=/usr/bin:/bin PYTHONPATH= \
  /usr/bin/python3 ~/.hermes/skills/tistory-publisher/scripts/check_state_consistency.py
# exit 1 + "가짜 발행 의심" 메시지 → publish skip
```

## 검증 이력

- **289차 (2026-07-18 06:01)** — 첫 발견. inline 검증으로 우회 후 skip 결정.
- **289차 패치 (같은 세션)** — check_state_consistency.py 3.9 호환 + 신호 4 추가.