# 193차 세션 노트 (2026-07-02T00:00) — DPP 프롬프트 발행 + 191차 §8.5.2 가설 무효화

## 발행 결과
- 글 번호: #897 (https://sigco.tistory.com/897)
- 주제: "Show GN: [프롬프트] AI 1:1 밀착 원어민 튜터 — DPP(결정론적 프롬프트 프로토콜) 5단계로 배우는 튜터 프롬프트 설계"
- 본문: 3,876자 / H2 7개 / 표 1개 / 코드블록 1개 (7KB 정형화 1회 컷)
- Picsum 2장 + CDN 업로드 2/2 + OG 썸네일 자동
- 세션: ✅ 759개 글

## ⭐ 중대 발견: 191차 §8.5.2 가설 무효화

191차 reference는 "`publish_post()`가 details/last 자동 동기화한다"고 확립했음.
193차에서 같은 호출 패턴으로 발행 → **자동 동기화 안 일어남**.

### 검증 출력 (193차)
```bash
$ python3 -c "import json; pt = json.load(open('/Users/mac/.hermes/memory/published_topics.json')); ..."
# → last.url: https://sigco.tistory.com/896  ← 직전 글 그대로
# → details[-1].url: https://sigco.tistory.com/896  ← 직전 글 그대로
# → last.topic: 상무부, Claude Fable 5와 Mythos 5 수출 통제 해제  ← 직전 글
```

Tistory에는 #897 정상 발행됨 (curl og:title 매치 확인). local state만 stale.

### 원인 가설 (미확정, 194차 TODO)
- `publish_post()`가 이미 pt/details에 동일 URL이 있으면 skip하는 로직?
- cron 환경 변수/작업 디렉터리 차이?
- 191차는 새로 작성된 글이어서 통과, 193차는 어떤 조건에서 자동 동기화 skip?

### 조치
§3.11 5단계 + §4 5-1 stats 보정 **매번 실행**으로 격상. 191차 §8.5.2 가설 신뢰 금지.

## 워크플로 실행 결과
1. `blog_pipeline.py` JSON 출력: selected_topic = "Show GN: [프롬프트] AI 1:1 밀착 원어민 튜터" (31002)
2. 긱뉴스 본문 130자 (짧음), `github.com/Long-night-bebe/Deterministic-Prompt-Protocol` 링크 → README fetch (1,171자, 5단계 DPP 설명)
3. 7KB 케이스로 판단 → H2 7개 / 표 1개 / 코드블록 1개 / 3,876자 1회 컷 작성
4. `tistory_publisher.py --title ... --file ... --image-query ...` 직접 호출
5. ✅ Tistory 발행 #897
6. `curl https://sigco.tistory.com/897` → HTTP 200 + og:title 매치
7. §3.11 5단계 + §4 5-1 보정 실행:
   - `published_urls.txt`: 31002 + #897 append
   - `blog_pipeline --record` 3-arg: ✅
   - `pt['last']` + `details` 동시 append
   - `daily_counts['2026-07-02']['AI/ML']` +1, `stats.total_published` 871→872, `stats.by_category['AI/ML']` +1

## 자동화 안전도
| 지표 | 값 |
|---|---|
| stats total | 872 |
| AI/ML today (2026-07-02) | 2 |
| sigco URL 라인 수 | 335 |
| §3.5 차이 | 537 (false positive 패턴) |
| 진짜 가짜 발행 | 0건 |

## 194차 이월 TODO
- `publish_post()`가 항상 pt/details/urls.txt 동기화하도록 강제
- §3.11 5단계 + 5-1 stats 보정 영구화 스크립트 (`scripts/post-publish-correct.sh`)
- 191차 §8.5.2 환경 의존성 원인 조사 (skip 로직? cron 환경 차이?)