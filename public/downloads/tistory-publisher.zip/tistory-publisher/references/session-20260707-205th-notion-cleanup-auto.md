# 205차 세션 노트 — Notion PATCH 자동 cleanup + tistory.env 파싱 함정

> 일자: 2026-07-07
> 작업: "덜한 것이 더 낫다" #915 발행 + Notion PATCH cleanup 자동화 패턴 확립

## 작업 요약

| 단계 | 결과 |
|---|---|
| §3.8.1 3-endpoint probe | ✅ 3/3 200 OK (manage/posts.json, manage/category.json, manage/blog.json=HTML) |
| `--refresh-topics` | 12개 토픽 |
| Notion PATCH 1차 cleanup | ✅ 2/2 (31177 Fable5/DRIFT, 31179 Starring the Computer) |
| Notion PATCH 2차 cleanup | ✅ 3/3 (31158 OpenTag, 31169 Figma, 31173 Art Institute) |
| 4중 dedup | 4건 → 1건 (31170) |
| `tistory_publisher.py --file` | ✅ #915 정상 발행 (2,140자) |
| §3.11 5단계 + §4 5-1 stats 보정 | ✅ 8필드 동기화 |
| §3.5 4-way 검증 | ✅ Tistory 915 = state 915 = urls 915 = details 915 (drift 0) |
| 누적 drift | 121 (stats 899 vs Tistory totalCount 778) |

## 핵심 학습 3가지

### 1) `tistory.env` 파싱 형식 함정

`~/.hermes/secrets/tistory.env`는 `KEY=VALUE` 단순 형식 (export 접두사 ❌). Python heredoc에서 직접 파싱 시 shell source 방식(`set -a; source ...`)을 흉내내려다 `export` prefix를 가정하면 cookies={} 빈 dict → HTML 응답.

**올바른 파싱**:
```python
cookies = {}
with open(os.path.expanduser('~/.hermes/secrets/tistory.env')) as f:
    for line in f:
        line = line.strip()
        if line.startswith('TISTORY_') and '=' in line and not line.startswith('#'):
            kv = line.split('=', 1)
            cookies[kv[0].replace('TISTORY_','')] = kv[1].strip()
```

영향: 200차 §3.17 보정 heredoc 예시 코드가 모두 잘못된 형식 가정. `scripts/post-publish-correct.sh` 작성 시 패치 필요.

### 2) Notion PATCH cleanup 자동화 (5/5 성공)

203차 §3.20.1의 수동 `known_mappings` 유지 부담을 **`state.last_topics.topic`의 30자 prefix**와 Notion 페이지 이름 자동 매칭으로 격상.

```python
state_titles = [t.get('topic','') for t in state.get('last_topics',[]) if t.get('topic')]
for p in all_pages:
    name = p['name'].lower()[:30]
    for st in state_titles:
        if st and (st[:30].lower() == name or name in st.lower()[:30] or st.lower()[:30] in name):
            to_patch.append((p['id'], p['url'], p['name']))
            break
```

30자 prefix 매칭이 한글/영문 혼합 title에서 충분히 구별력 제공 (5/5 매칭).

### 3) 4중 dedup 영구화

204차 §3.21 권장 3가지 결합:
1. Notion PATCH cleanup (후보 풀 축소)
2. hash + URL dedup
3. **title 전체 비교** (`last_titles_full` set, `last_titles[:50]` ❌)

4중 dedup으로 4건 후보 → 1건 통과 확인.

## 누적 drift 121 (재확인)

- 205차 종료: stats.total_published=899, Tistory totalCount=778
- 이번 세션 단일 drift=0 (913→915 Tistory delta=2, stats delta=2)
- §3.16 별도 cron 작업 권장 (재확인)

## 후속 권장 작업

1. `scripts/post-publish-correct.sh` 작성 (§3.22.1 파싱 형식 적용, §3.22.2 자동 cleanup 통합)
2. `scripts/notion-cleanup.py` standalone (state.last_topics 기반 자동 cleanup)
3. `update_notion_topic_last_used()` blocking 패치 (silent fail 차단)
4. 누적 drift 121 정리 (별도 cron 임무)
