# 336차 (2026-07-29 03:01) — Bun의 Rust 재작성 (#1132, AI/ML)

**연속 all-green 110회차** (335→336). 단일 패스 31연속 + 신호 4 disambiguate 30연속 + 진입 5-5 11연속 + fallback 복귀 24연속.

## 발행 메타
- 글 번호: **#1132**
- 제목: Bun의 Rust 재작성은 어떻게 진행되고 있나? — JavaScript 런타임의 Rust 전환 현황과 성능 임팩트
- 카테고리: AI/ML (1219746)
- 긱뉴스 토픽: gn=31897 "Bun의 Rust 재작성은 어떻게 진행되고 있나?"
- 본문: 4,782자 (Picsum 이미지 2장 + Rust 코드 블록 1개 + source footer)
- 빌드: `/tmp/build_post_336.py` → `/tmp/post_336.html` (8,092 bytes)
- publish wrapper: `/tmp/publish_336.py` (`publish_post()` 직접 호출)
- 발행 응답: `PUBLISH=SUCCESS URL=https://sigco.tistory.com/1132`
- OG 썸네일: `https://blog.kakaocdn.net/dna/b6EE6H/...` 정상 설정

## 핵심 학습 — 함정 28 신규

### 증상 (336차 실전 첫 시도)
```python
# build_post_336.py 첫 작성 시 — parts.append() 안에 multiline literal 박음
parts.append('<pre><code class="language-rust">// 모듈 캐시 키 생성 — Rust 포팅 버전 (의사코드)
use std::hash::{Hash, Hasher};
use xxhash_rust::xxh64;
# ... 24줄 ...
</code></pre>')
```

**결과**:
```
SyntaxError: unterminated string literal (detected at line 38) (line 38, column 14)
```

### 자동 변환 시도 (실패)
```python
# re.sub로 parts.append() 따옴표 매칭 자동 변환
import re
def repl(m):
    inner = m.group(1)
    return f'parts.append("{inner}")'
new_text = re.sub(r"parts\.append\('([^']*)'\)", repl, text)
```
- 단일 `<p>...</p>` 라인: 정상 변환
- `<pre><code>...</code></pre>` multiline 라인: `[^']*` greedy match가 첫 `'`에서 멈춰서 `\nline2\nline3` 부분이 변환되지 않고 Python literal에 그대로 박힘
- 결과: `SyntaxError: invalid syntax (<unknown>, line 38)` 잔존

### 해결 (정형)
```python
# 코드 블록은 무조건 code_lines 리스트로 분리
code_lines = [
    "// 모듈 캐시 키 생성 — Rust 포팅 버전 (의사코드)",
    "use std::hash::{Hash, Hasher};",
    "use xxhash_rust::xxh64;",
    "",
    "pub struct ModuleKey {",
    # ...
    "}",
]
parts.append("<pre><code class=\"language-rust\">" + "\n".join(code_lines) + "</code></pre>")
```

**판정 기준 (336차 정형화)**: parts.append() 안에 다음이 들어가면 처음부터 `code_lines = [...]` 패턴 사용:
- (a) `<pre>...</pre>` / `<code>...</code>` 블록
- (b) `<ul>...</ul>` + `<li>` 여러 줄
- (c) `<table>...</table>` 여러 줄
- (d) 본문에 의도적인 `\n` 박힘

**원칙 (332차 정형 강화)**: parts.append() 인자에 multiline HTML 리터럴이 들어가면 처음부터 `[lines]` 리스트 + `"\n".join(lines)` 패턴으로 작성. single-quoted `'...'` + multiline literal 조합은 항상 회피.

## 핵심 학습 — 5-2-A ↔ 5-3 실행 순서 보강

### 증상 (336차 실전)
1. publish 성공 (#1132)
2. `commit_publish()` 실행 → state.json 갱신 (total=126, today=AI/ML:4)
3. **5-2-A (published_topics.json 보정) 먼저 실행** ← 잘못된 순서
4. 5-2-A의 (3)번 last 동기화 단계가 `state.last_published_url`을 읽음
5. 그 시점에 state.json은 5-3 미실행 → `last_published_url=#1131` (335차 글) 그대로
6. **published_topics.last.url = `https://sigco.tistory.com/1131`** ← 어제 글로 stale 박힘
7. 5-3 실행 → state.json은 #1132로 갱신, but published_topics는 #1131 stale

### 해결 (정형)
**순서**: 5-3 (state.json) → 5-2-A (published_topics.json) → 사후 명시 동기화

**사후 명시 동기화 fallback** (5-2-A가 stale로 박혔을 때 단순 한 줄 패치):
```bash
unset PYTHONPATH
/usr/bin/python3 << 'PYEOF'
import json
from pathlib import Path
pt_path = Path.home() / '.hermes' / 'memory' / 'published_topics.json'
pt = json.loads(pt_path.read_text())
pt['last'] = {
    'topic': '<TOPIC_ID>',
    'title': '<TITLE>',
    'hash': '',
    'url': 'https://sigco.tistory.com/NNN',
    'date': '<YYYY-MM-DD>',
}
pt_path.write_text(json.dumps(pt, ensure_ascii=False, indent=2))
print(f"last 동기화: url={pt['last']['url']}")
PYEOF
```

336차 사후 적용: `last.url`이 `#1131` → `#1132`로 즉시 복구.

## §3.5 신호 4 disambiguate 30연속 (구조적 오탐 정형 유지)

발행 직후:
```
today=2026-07-29 daily_counts={'AI/ML': 4} (total=4)
last_published_url=https://sigco.tistory.com/1132
last_topics[-1]={'topic': '31897', ...}
⚠️ DRIFT 감지:
  - 가짜 발행 의심 (FAKE_PUBLISH): daily_counts[2026-07-29] 합계=4 지만 details[-1]=#1132 (last_published_url 변동 없음)
```

**proxy check disambiguate**:
```
status=200
title=Bun의 Rust 재작성은 어떻게 진행되고 있나? &mdash; JavaScript 런타임의 Rust 전환 현황과 성능 임팩트
og:title=Bun의 Rust 재작성은 어떻게 진행되고 있나? — JavaScript 런타임의 Rust 전환 현황과 성능 임팩트
source_present=True
cjk_suspect_hits=[]
```

→ 진짜 발행 확인. §3.5 FAKE_PUBLISH 구조적 오탐 정형화 (335차 확립) 그대로 정상 작동.

## 검증 이력 갱신
- 연속 all-green **110회차** (336차 = 2026-07-29 03:01)
- daily_counts={AI/ML:4}, total=126
- by_category 영구 잔존 ("1219746": 1) — drift 보고만, 보정 보류
- 5-2-A 0건 백필 (이미 동기화 완료), 5-3 details_len=205

## 함정 회피 동시 성공 (8중)
- **함정 6** (heredoc + env -i SyntaxError 회피) — write_file + `/usr/bin/build_post_336.py` 분리
- **함정 7** (`--category` int만) — `--category 1219746` (int)
- **함정 8** (by_category 영구 잔존 drift 보고만)
- **함정 11** (`execute_code` cron 차단 회피) — write_file 패턴
- **함정 15** (5-5 proxy check 격리 패턴 적용) — `unset PYTHONPATH PYTHONHOME; PYTHONNOUSERSITE=1; export PYTHONPATH=user-site; /usr/bin/python3 -s`
- **함정 17** (parts.append() 정형) — 본문 4782자 + 코드 블록 + 푸터 동시 사용
- **함정 25** (작은따옴표 매칭 깨짐 회피) — 처음부터 double quotes 사용
- **함정 27** (빌드 시점 source URL 검사 ≠ publish 후 footer) — 5-5 proxy에서 source_present=True 확인
- **신규 — 함정 28** (multiline HTML literal SyntaxError) — `code_lines = [...]` + `"\n".join(code_lines)` 정형 패턴
- **신규 — 5-2-A ↔ 5-3 순서** — 5-3 먼저 → 5-2-A 나중, 사후 명시 동기화 fallback

## 다음 차 운영 권장 (337차)
- parts.append() 작성 시 multiline HTML 들어가는지 1차로 grep — 있으면 처음부터 `code_lines` 패턴
- publish 직후 sync 스크립트에서 5-3 → 5-2-A 순서 명시적으로 유지
- 5-2-A last 동기화 결과 검증: `published_topics.last.url`이 `state.last_published_url`과 일치하는지 `grep` 확인
- proxy check 정형 패턴 (5-5) + source_present + cjk_suspect_hits grep 모두 stdout에 명시