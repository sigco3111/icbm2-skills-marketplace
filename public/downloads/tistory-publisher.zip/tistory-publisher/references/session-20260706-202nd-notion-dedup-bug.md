# 202차 세션 노트 — Notion DB dedup 동기화 버그 + 3중 dedup 패턴

**날짜**: 2026-07-06 (화)
**시간**: 22:00 KST ~ 22:10 KST
**모드**: cron 자동화 (no user presence)
**결과**: ✅ #910 정상 발행 (drift 0, 4-way sync)

## 타임라인

| 시각 | 단계 | 산출 |
|---|---|---|
| 22:00 | §3.8.1 3-endpoint probe | ✅ 200 OK 3/3 |
| 22:01 | `refresh-topics` | 12개 긱뉴스 토픽 로드 (OpenTag 16점, Figma 9점 등) |
| 22:02 | `--category 'AI/ML'` | Cross Entropy Loss 반환 (재선택 버그) |
| 22:03 | Notion API 직접 조회 | 31168/31169/31173 모두 활성 잔존 확인 |
| 22:04 | 3중 dedup 코드 실행 | 31169 Figma AI 시대 후보 선정 |
| 22:05 | heredoc 본문 작성 | 2,704자 / 12 H2 / 7 H3 |
| 22:06 | `tistory_publisher.py --file` | #910 발행 ✅ |
| 22:07 | §3.11 5단계 + §4 5-1 stats 보정 | stats 893→894, 4곳 sync |
| 22:08 | §3.5 4-way 검증 | Tistory /910 = state /910 = details /910 = urls /910 ✅ |
| 22:10 | 보고 | #910 한 줄 보고 |

## 핵심 발견 — Notion DB dedup 동기화 버그 (§3.19)

**증상**: `blog_pipeline.py --category 'AI/ML'` 호출 시 이미 오늘 발행한 Cross Entropy Loss (31168, #908)을 다시 반환.

**원인 흐름**:
1. `update_notion_topic_last_used(topic_text, category)` 호출
2. 내부적으로 `_notion_api("PATCH", ...)` 호출
3. Notion API 응답 실패 시 (401/500/네트워크) `except Exception: pass`로 silent swallow
4. caller도 fire-and-forget이므로 실패 감지 불가
5. Notion DB 상태가 "활성" 그대로 유지 → 다음 호출 시 같은 topic 재선택

**재현 조건**:
- Notion API 토큰 401 (예: expired)
- Notion 페이지 ID 쿼리 실패 (예: 페이지 archived)
- 네트워크 일시 장애

**영향 범위**:
- 같은 세션 내 연속 발행 시 동일 토픽 재시도 위험
- 크론 자동화의 blind spot (사용자 인지 어려움)
- `published_urls.txt`에는 기록되지만 Notion에는 미반영 → dedup 분기

## 해결 — 3중 dedup 패턴 (영구 단계 격상)

외부 워커가 `blog_pipeline.py --category` 결과를 신뢰하지 않고, 다음 3중 dedup으로 직접 후보를 선정한다:

### Step 1: Notion 활성 토픽 직접 조회

```python
import json, urllib.request, os
token = open(os.path.expanduser('~/.hermes/secrets/notion_token.txt')).read().strip()

all_active = []
cursor = None
while True:
    body = {'page_size': 100, 'filter': {'property': '상태', 'select': {'equals': '활성'}}}
    if cursor: body['start_cursor'] = cursor
    req = urllib.request.Request(
        'https://api.notion.com/v1/databases/34276f2e-9097-811e-ab69-f8759ecf0be7/query',
        data=json.dumps(body).encode('utf-8'),
        headers={
            'Authorization': f'Bearer {token}',
            'Notion-Version': '2022-06-28',
            'Content-Type': 'application/json',
        },
        method='POST',
    )
    with urllib.request.urlopen(req, timeout=20) as resp:
        data = json.loads(resp.read())
    for r in data.get('results', []):
        props = r['properties']
        name = ''
        cat = ''
        url = ''
        for pname, p in props.items():
            if pname == '이름' and p.get('type') == 'title':
                t = p.get('title', [])
                if t: name = t[0].get('plain_text', '')
            elif pname == '카테고리' and p.get('type') == 'select':
                s = p.get('select')
                if s: cat = s.get('name', '')
            elif pname == 'URL' and p.get('type') == 'url':
                url = p.get('url', '')
        if url:
            all_active.append({'name': name, 'cat': cat, 'url': url})
    if not data.get('has_more'): break
    cursor = data.get('next_cursor')
```

### Step 2: 3중 dedup 필터

```python
import hashlib
state = json.loads(open('/Users/mac/.hermes/memory/blog_pipeline_state.json').read())
last_titles = {t.get('title', '').lower() for t in state.get('last_topics', [])}
last_topics_lower = {t.get('topic', '').lower() for t in state.get('last_topics', [])}

with open('/Users/mac/.hermes/memory/published_urls.txt') as f:
    pub_urls = {line.split('\t')[0].strip() for line in f if line.strip()}

pt = json.loads(open('/Users/mac/.hermes/memory/published_topics.json').read())
pub_hashes = {t['hash'] for t in pt.get('topics', []) if isinstance(t, dict)}

TARGET_CAT = 'AI/ML'
candidates = []
for t in all_active:
    if t['cat'] != TARGET_CAT: continue                       # 카테고리 필터
    if t['url'] in pub_urls: continue                         # 1차: URL dedup (published_urls.txt)
    h = hashlib.md5(t['name'].encode()).hexdigest()
    if h in pub_hashes: continue                              # 2차: hash dedup (published_topics.json)
    if t['name'].lower() in last_topics_lower: continue       # 3차-a: state.last_topics.topic
    if t['name'].lower() in last_titles: continue             # 3차-b: state.last_topics.title
    candidates.append(t)

# 점수순 정렬은 별도 (긱뉴스 refresh 시 받은 점수)
print(f'Available candidates: {len(candidates)}')
best = candidates[0] if candidates else None
```

### Step 3: 후보 선정 후 half-pipeline

선정된 topic으로 heredoc으로 본문 작성 → `tistory_publisher.py --file` 호출 → §3.11 5단계 + §4 5-1 stats 보정.

## §3.11 5단계 + §4 5-1 stats 보정 (202차 실행 완료)

전체 heredoc은 `references/post-publish-correct-recipe.md` 참조. 202차 실행 결과:

```
✅ Step 1: published_topics.json 갱신 (657개 hash)
✅ Step 2: state.last_topics append
✅ Step 3: state.last_post.details append
✅ Step 4: stats total_published → 894, by_category[AI/ML] → 701, daily_counts[2026-07-06][AI/ML] → 2
✅ Step 5: published_urls.txt append (Tistory URL + hada.io URL 31169)
```

## §3.5 4-way 검증 (202차 통과)

```
Tistory max id:     /910
state.last_topics:  /910
state.details[-1]:  /910
urls.txt last:      /910
stats.total:        894
Tistory totalCount: 773
✅ PASS: 4-way sync OK, drift=0
누적 drift: stats(894) - Tistory(773) = 121 (legacy, §3.16)
```

## 신규 함정 — `published_urls.txt` 마지막 줄 비-Tistory URL

202차 검증 heredoc 첫 시도:
```python
# ❌ ValueError: invalid literal for int() with base 10: 'anthropic-openai-product-market-fit'
last_id = int(lines[-1].split('\t')[0].rstrip('/').split('/')[-1])
```

원인: `simonwillison.net/2026/May/27/anthropic-openai-product-market-fit/`이 마지막 줄에 있음 (200차에서 source URL로 추가됨). 즉 `lines[-1]`이 Tistory URL이라는 보장이 없음.

**202차 확정 코드 (Tistory URL 필터 후 마지막)**:
```python
# ✅
tistory_lines = [l for l in lines if 'sigco.tistory.com' in l]
last_pub_id = int(tistory_lines[-1].split('\t')[0].rstrip('/').split('/')[-1]) if tistory_lines else 0
```

**적용 범위**:
- §3.5 4-way 검증 heredoc
- §3.11 5단계 + §4 5-1 stats 보정 heredoc의 urls.txt append 후 검증
- Layer 3 자동 검출 스크립트

## 후속 권장 작업 (별도 cron)

### Notion DB 일괄 정리 (최우선)

오늘 발행된 활성 토픽 3건(31168, 31169, 31173) + 잔재 페이크 URL 4건 자동 정리:

```python
# Notion 31168/31169/31173 PATCH: 상태=비활성 + 마지막 사용일=2026-07-06
for page_id in ['<31168 page_id>', '<31169 page_id>', '<31173 page_id>']:
    _notion_api("PATCH", f"pages/{page_id}", {
        "properties": {
            "상태": {"select": {"name": "비활성"}},
            "마지막 사용일": {"date": {"start": "2026-07-06"}},
        }
    })
```

### `update_notion_topic_last_used()` blocking 강화 (코드 패치)

```python
def update_notion_topic_last_used(topic_name: str, category: str = None):
    """Update the '마지막 사용일' field for a topic in Notion DB."""
    # ... (기존 코드) ...
    if result.status == 401: raise NotionAuthError(...)
    if not result: raise NotionQueryError(...)
    # caller에서 try/except로 명시 처리
```

fire-and-forget을 의도된 silent fail로 두면 안 됨 → caller가 명시적으로 처리하거나 skip 결정.

### 누적 drift 121 별도 작업 (202차 발견)

`stats.total_published(894) - Tistory.totalCount(773) = 121` (§3.16 별도 작업 분리 권장). 

drift 원인 가설:
- 195차 이전 누적 publish 실패 후 재시도 안 함
- Notion API 일시 장애로 published_topics.json은 갱신 안 됐지만 Tistory는 발행된 건
- 197차 가짜 발행 36건 롤백 시 일부 Tistory 글은 그대로 남아있음 (Layer 1 가드가 Tistory만 보호, stats만 차감)

별도 cron으로 max 5페이지 순회하며 Tistory total_count와 비교 후 누락분 진단.

## 환경 / 설정 메모

- 202차 시점 `~/.hermes/secrets/notion_token.txt` 길이 50자 (정상)
- Tistory API 정상 (max id 910, totalCount 773)
- published_urls.txt 774개 URL 포함
- 마지막 발행 시각 2026-07-06T22:07:20 KST

## 교훈

1. **`blog_pipeline.py --category` 결과를 신뢰하지 말 것** — Notion 동기화 버그로 인해 같은 토픽 재선택 가능. 3중 dedup으로 외부 워커가 직접 검증.
2. **`update_notion_topic_last_used`는 fire-and-forget 함정** — Notion API silent fail이 상태 오염을 만든다. blocking + raise로 변경 필요.
3. **`published_urls.txt` 마지막 줄은 Tistory URL이 아닐 수 있다** — 검증 heredoc은 반드시 필터 후 사용.
4. **half-pipeline은 외부 워커의 책임이 크다** — `blog_pipeline.py`만 믿지 말고 own judgment로 dedup + validate + publish + record 4단계를 모두 수행.

## 다음 세션이 봐야 할 것

- §3.19 3중 dedup 패턴 (외부 워커가 토픽 선택할 때)
- §3.5 4-way 검증 (published_urls.txt 필터링 코드)
- Notion DB 일괄 정리 작업 (오늘 발행된 활성 잔존 3건 비활성화)
- 누적 drift 121 별도 cron 작업 (legacy 정리)
