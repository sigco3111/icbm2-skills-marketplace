# 337차 — DevClip (gn=31924, AI/ML) — Show GN: 클립보드 매니저 24일 클로드코드 출시

**날짜**: 2026-07-29 (cron 자동 발행, KST 20:00~20:01)
**결과**: ✅ #1134 발행 성공
**카테고리**: AI/ML (1219746)
**소스**: https://news.hada.io/topic?id=31924
**본문**: 2,398자 + Picsum 2장 + source footer (publish_post() 자동 박기)

## 카운터 갱신 (337차 기준)
- **단일 패스 32연속** (305차 패턴 — `requests.get(gn_url)` + og:description regex 임베드)
- **parts.append() 12연속** (332차/336차 정형)
- **§3.5 신호 4 disambiguate 31연속** (298→337)
- **진입 5-5 12연속** (310→337)
- **fallback 복귀 25연속** (311→337)
- **by_category["1219746"]=1 영구 잔존 31연속** (297→337 = 41차 동일 유지)
- **연속 all-green 111회차** (288차+)

## 워크플로 실행 순서 (337차 실전, 336차 정형 그대로)

### 1. §3.8.1 세션 만료 가드
- raw 검증 패턴: `set -a; source; unset PYTHONPATH PYTHONHOME; PYTHONNOUSERSITE=1; export PYTHONPATH=user-site; /usr/bin/python3 -s`
- 결과: status=200, content_type=application/json;charset=UTF-8, first_id=1133, items_count=15
- **✅ VALID — 발행 진행**

### 2. 트렌드 새로고침
- `blog_pipeline.py --refresh-topics` → 12개 트렌드 (개발팁/AI/ML/개발도구 mix)
- gn=31924 "DevClip – 클립보드 매니저를 24일간 클로드코드로 만들어 출시하기까지" (score 2.0, AI/ML)

### 3. 3-a 후보 선정
- `blog_pipeline.py --category 'AI/ML'` → status=ready, gn=31924, 카테고리 ID=1219746, timeliness_check ok
- 295차 무조건 발행 정책 + 305차 단일 패스 패턴 유지

### 4. 3-b 빌드 (`/tmp/build_post_337.py`)
- **305차 패턴**: `requests.get(gn_url) + <meta property="og:description"> regex` 임베드 → 158자 추출
  - 추출 결과: "복사한 것들이 하나씩 쌓이고 나중에 골라 쓰는 macOS 클립보드 매니저입니다. 수익화를 염두에 두고 만들었습니다. 첫날 이미 가격 이야기가 나왔고 사흘 뒤에 어떤 모델로 팔지 정했으니, 취미로 만들다 얼떨결에 올린..."
- **parts.append() 정형** (332차/336차): 19개 parts 모두 double quotes(`"..."`)로 감쌈
  - 본문에 작은따옴표(`'`) 다수 포함 — '24일간 Claude Code로 만들어 출시하기까지', '마지막 N개 보존', '큐레이션 매니저' 등
  - 자동 변환 (`re.sub(r"parts\.append\('([^']*)'\)", ...)`) 없이 처음부터 double quotes로 작성 → 정형 패턴 정상
- **Picsum 2장**: `devclip-clipboard-manager-2026` / `devclip-claude-code-journey` 시드
- 빌드 결과: `[body chars] 2398` + `[file] /tmp/post_337.html (4695 bytes)`

### 5. Sibling write warning 검증 (333차 함정 26 정형)
- `write_file` 직후 응답: `_warning: ... modified by sibling subagent 'b135848e-...'`
- **read_file + CJK grep 검증**:
  - 한자 substring grep: 0건
  - CKJ 공유 한자 음차 후보 (`立场|自走|说明|开展|选择|集中|决定|发布|产品|设计|推出`): 0건
- sibling이 파일을 보존한 것으로 판정 — 추가 조치 불필요

### 6. 3-b publish 단계
- `tistory_publisher.py --title "..." --tags "DevClip,클립보드매니저,ClaudeCode,macOS도구,AI페어프로그래밍" --category 1219746 --source-url ... --gn-topic-id 31924 --file /tmp/post_337.html`
- 결과:
  - 📄 Content 검증 통과: 1,894자 (publish_post가 단락 단위 검증으로 일부 제거)
  - 🖼️ 이미지 업로드 성공 (1/2) 92KB + (2/2) 27KB
  - 🖼️ OG 썸네일 설정: `https://blog.kakaocdn.net/dna/b9Oygh/dJMcaae9Vxb/AAAAAAAAAAA...`
  - ✅ 발행 성공
  - 🔗 https://sigco.tistory.com/1134

### 7. 5-2 commit_publish
- **함정 9 1회 재발**: `env -i ... /usr/bin/python3 /usr/bin/python3 <script>` 형태로 python3를 두 번 쓰는 패턴
  - 첫 시도: `env -i ... /usr/bin/python3 python3 blog_pipeline.py --commit ...` → SyntaxError: Non-UTF-8 code starting with '\xca' in file /usr/bin/python3
  - 두 번째 시도: `env -i ... /usr/bin/python3 blog_pipeline.py --commit ...` (단일 형태) → 정상 작동
- 결과: today={AI/ML:6}, total=128, by_category 정상

### 8. 5-3 state.json 보정
- last_published_url=1134, last_published_id=1134, details_len=207 (1건 append)
- timestamp는 KST 명시: `2026-07-29T20:00:00+09:00`

### 9. 5-2-A published_topics.json 동기화 (5-3 이후 실행, 336차 정형 순서)
- (1) placeholder 보정: 0건
- (2) 누락 백필: 1건
- (3) last 동기화: state_last_url=1134 → published_topics.last.url=1134
- 결과: details_len=208, last_url=https://sigco.tistory.com/1134

### 10. 5-4 §3.5 3중 신호 검증
- today=2026-07-29 daily_counts={'AI/ML': 6}
- last_published_url=#1134
- last_topics[-1] 정상
- **⚠️ 신호 4 발동 (구조적 오탐 31연속)**: details[-1]=#1134 == last_published_url (5-3에서 동시 갱신) → 매 차 무조건 발동

### 11. 5-5 proxy check (335차 정형 — disambiguate)
- status=200
- title=`Show GN: DevClip &ndash; 클립보드 매니저를 24일간 클로드코드로 만들어 출시하기까지`
- og:title=`Show GN: DevClip – 클립보드 매니저를 24일간 클로드코드로 만들어 출시하기까지` (정확 매칭)
- source_present=True (https://news.hada.io/topic?id=31924 본문 substring 존재)
- suspicious_cjk_count=0 (CJK 한자 치환 없음, 333차 함정 26 검증)
- **✅ 진짜 발행 확정** (구조적 오탐 disambiguate 성공)

## 함정 회피 카운트 (337차)
- 함정 6 (heredoc + env -i SyntaxError): 자동 회피 (write_file + /usr/bin/python3 -s)
- 함정 7 (--category int만): 회피 (1219746)
- **함정 9 1회 재발** (env -i + python3 중복) → 정형 패턴 단일 호출로 재시도 정상 복구
- 함정 11 (execute_code cron 차단): 자동 회피 (write_file)
- 함정 14 (import os 누락): 자동 회피 (heredoc 첫 줄에 `import os, requests, re`)
- 함정 15 (5-5 proxy 격리 패턴): 자동 회피 (정형 PYTHONNOUSERSITE+export PYTHONPATH)
- 함정 26 (sibling write → CJK 치환): 자동 회피 (read_file + grep 0건 확인 후 진행)
- **함정 회피 7중 동시 성공**

## 337차 특이사항 / 학습 포인트

1. **함정 9 (env -i + python3 중복) 재발 패턴**: cron 워크플로에서 commit 단계 직전 heredoc 작성 시 흔히 python3를 두 번 붙이는 실수 발생. 305차 이후 단일 형태를 강조했지만 337차 실전에서 1회 재발. **권장 자동화**: 명령어 호출 전 정규식 `/python3 python3/` → `python3` 자동 변환하는 wrapper 또는 `set -e`로 즉시 fail 후 정형 가이드 다시 호출하는 패턴 권장. 337차는 즉시 재시도로 정상화했으나 SSOT 정형화 후보.

2. **og:description 158자 추출**: 305차 단일 패스 패턴이 33차 연속 안정 작동. 긱뉴스 description이 본문 인트로 100~200자로 일관되어 SEO description으로 적합. publish_post의 meta description 자동 추출도 안정.

3. **parts.append() 본문에 작은따옴표 다수 (332차 정형)**: 337차 본문에 `'24일간 Claude Code...`, `'마지막 N개 보존'`, `'큐레이션 매니저'`, `'선택과 집중'`, `'24일 만에 출시'`, `'무엇을 만들고 누구에게 어떻게 파는가'` 등 작은따옴표 6+개 포함. 처음부터 double quotes로 작성 → 정형 패턴 정상 작동 (SyntaxError 0건).

4. **sibling write warning 무영향 케이스**: 337차는 sibling이 파일을 그대로 보존한 케이스. CJK grep 0건 + 본문 정상 = 추가 조치 불필요. 매 차 sibling warning이 나도 일관되게 read_file + grep 단계 거치는 운영 패턴 유지 권장.

5. **OG 썸네일 정상 설정**: Picsum 시드 2장 모두 92KB / 27KB 정상 업로드 + OG 썸네일 `https://blog.kakaocdn.net/dna/b9Oygh/...` 자동 설정 확인. publish_post()의 이미지 처리 + OG 자동 박기 안정.

6. **5-2-A 누락 백필 1건**: state.json의 details에는 #1134 포함되었지만 published_topics.json에는 누락된 상태였음 (300차 패턴). 5-2-A 백필이 정상 작동하여 URL-idempotent 동기화. 337차 단발이지만 누락분이 누적될 가능성 → 5-2-A 백필 단계는 매 차 필수.

## 다음 차 권장
- 338차도 같은 정형 워크플로 (단일 패스 + parts.append() + 5-3→5-2-A) 유지
- 함정 9 자동 회피 wrapper 도입 검토 (336차 SKILL.md 보강 시 후보)
- `requests.get()` og:description 추출 단일 패스 패턴은 33차 연속 안정 → 305차 정형의 SSOT