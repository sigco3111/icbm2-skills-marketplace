# 261차 세션 — LLM은 사랑하지만 과대광고는 싫다 (#996)

## 한 줄 요약
- **#996 LLM은 사랑하지만 과대광고는 싫다 — geohot이 본 AI 가치 포획의 진짜 승자** (gn=31378, AI/ML, 7점) 정상 발행
- §3.34.46 cleanup cron 임무 **#23 영구화 패치 완료** (GN_MD_URL 정정)
- 연속 all-green **48회차** (213~261차)

## 발행 흐름

1. **§3.8.1 세션 만료 가드** — `status=200, ct=application/json;charset=UTF-8, cookie_count=8` 통과
2. **§3.34.40 FRESH 4-field 매칭** — TOP 12개 중 8개 PUB 처리 → FRESH 잔여 4개 모두 AI/ML: `31378/31375/31367/31389`. §3.34.39 후보 직접 점수 pick으로 `31378` 1순위 (7점).
3. **§3.34.46 본문 fetch (영구화 후 1호)** — `_try_md_endpoint(31378)` 호출 → status=200, **9590 bytes** 정상 fetch. 임시 우회 패턴 없이 1단계 `.md` endpoint가 즉시 성공.
4. **본문 → Tistory HTML 변환** — 260차 정착 패턴 그대로: `### 헤더` → `<h3>`, `- 리스트` → `<ul><li>`, 빈 줄은 `</ul>` close 트리거, `**bold**` → `<strong>`. 인트로 + 본문 + 결론 3-part 구조로 7069자 draft.
5. **§3.8.1 publish** — `tistory_publisher.py --title ... --category 1219746 --file draft.md --source-url ... --gn-topic-id 31378 --image-query 'llm coding ai hype bubble skeptic'`. 검증 통과 2429자, 이미지 2장 (Picsum ID 365/68) CDN 업로드 정상, `https://sigco.tistory.com/996` 발행 성공.
6. **§3.11 post_publish_sync** — `sync --url ... --title ... --gn-topic-id 31378 --category AI/ML --category-id 1219746 --source-url ...` → `pt_updated: true / state_updated: true / errors: [] / triple_signal_match: true`.
7. **§3.5 5중 신호 사후 검증** — 5개 URL 모두 `https://sigco.tistory.com/996` 일치 (`triple_signal_match: true`). drift 무해.
8. **daily_counts 갱신** — `state.daily_counts[2026-07-14]` = `{'AI/ML': 4}` (3→4, +1 정확).
9. **state.details 72→73 / pt.details 88→89** 모두 정상 박힘.
10. **cleanup cron 임무 #16 dry-run** — `✅ 누설 없음` (47회 연속 all-green).
11. **라이브 페이지 GET** — `status=200, size=65252, title tag='LLM은 사랑하지만 과대광고는 싫다 &mdash; ...'` (실제 발행 확인).

## §3.34.46 cleanup cron 임무 #23 영구화 패치 (261차 ✅ 완료)

**식별 (259차)**: `scripts/gn-fetch-content.py`의 `GN_MD_URL = "https://news.hada.io/topic.md?id={tid}"` 상수가 stale. 긱뉴스의 실제 작동 URL은 `/topic/{tid}.md`.

**임시 우회 (259~260차)**: 매 차마다 `requests.get(f"https://news.hada.io/topic/{tid}.md")` 직접 호출.

**영구화 (261차)**: 1줄 정정 + 보조 정정 2건.

### 적용 패치

```diff
--- a/scripts/gn-fetch-content.py
+++ b/scripts/gn-fetch-content.py
@@ -45,9 +45,9 @@
 from typing import Optional, Tuple
 
 GN_TOPIC_URL = "https://news.hada.io/topic?id={tid}"
+GN_TOPIC_BASE = "https://news.hada.io/topic"
 GN_MD_URL = GN_TOPIC_BASE + "/{tid}.md"  # §3.34.46 영구화: /topic/{tid}.md 가 실제 작동 URL
 GN_RSS_URL = "https://feeds.feedburner.com/geeknews-feed"
-GN_TOPIC_BASE = "https://news.hada.io/topic"

@@ -85,7 +85,7 @@

 def _try_md_endpoint(topic_id: int) -> Optional[str]:
-    """1단계: .md endpoint (227~232차 6회째 100% 404, 사실상 dead)."""
+    """1단계: .md endpoint (§3.34.46, 259차 식별, 260차 검증, 261차 영구화)."""
```

### 패치 검증 (261차)

```
$ python3 -c "
import importlib.util
spec = importlib.util.spec_from_file_location('gfc', '.../gn-fetch-content.py')
gfc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gfc)
print(gfc.GN_MD_URL)
# → https://news.hada.io/topic/{tid}.md
print(gfc._try_md_endpoint(31378))
# → 9590 bytes
"
```

**결과**: 1단계 `.md` endpoint가 즉시 fetch 성공. 향후 모든 차에서 임시 우회 heredoc 작성 불필요 — `_try_md_endpoint(tid)` 함수 직접 호출로 정상 본문 확보.

### 패치 함정 (261차 식별 → 즉시 정정)

1. **f-string 모듈 로드 시점 평가 함정**: `GN_MD_URL = f"{GN_TOPIC_BASE}/{{tid}.md"` 형태로 적으면, line 48에서 GN_TOPIC_BASE가 아직 정의되지 않아 `NameError` 발생 (line 50에서 정의됨). → 정정: `GN_TOPIC_BASE + "/{tid}.md"` (string concatenation).
2. **정의 순서 함정**: `GN_TOPIC_BASE` 정의를 `GN_MD_URL` 앞으로 이동해야 함.

## 사소한 관찰 (261차)

cron 261차 시작 시점에 `state.details[-1]` 가 `#995 GPT-5.6-Sol` (gn=31390) 으로 박혀있었음 — 직전 SKILL.md 기록 (260차, `#994 AI 에이전트가 새로운 SaaS다`) 과 다름. 즉 **260차 종료 후 261차 시작 전 사이에 자정 사이 외부에서 한 건 더 발행**된 흔적. §3.5 5중 검증 모두 `#995` 일치 → drift 무해 확정 (§3.34.44 패턴과 동일). `daily_counts[2026-07-14]['AI/ML'] = 3` (260차 SKILL.md엔 2였으나 사후 1건 추가 발행됨).

261차 진행 흐름:
- 사전: 5중 모두 `#995` (drift 감지지만 일치 유지로 무해)
- 사후: 5중 모두 `#996` (정상 박힘)

pt/details 비교시 항상 **현재 시점의 last url** 을 source-of-truth로 사용 (260차 §3.34.44 박스 그대로 유효).

## 패턴 정착 상태

- §3.34.39 후보 직접 점수 pick + FRESH 4-field 매칭 (244차) — 정상 동작
- §3.34.40 4-step 명시 패턴 (244차) — 정상 동작
- §3.34.41 3.9-safe string concat (245차) — 정상 동작 (heredoc 안 string concat으로 작성)
- §3.34.43 격리 패턴 PWD 보강 (247차) — `PWD=/Users/mac` 정상 동작
- §3.34.44 cron 차 사이 last URL drift (254차) — 정상 처리 (drift 감지 + 5중 일치 확인)
- §3.34.45 #21 + '기타' 제외 정책 우선순위 (256차) — 261차는 FRESH 모두 AI/ML → #21 정상 동작 (#22 무효)
- §3.34.46 영구화 완료 (261차) — 1단계 `.md` endpoint 즉시 fetch
- §3.5 5중 신호 검증 — 사전/사후 모두 일치
- §3.8.1 세션 만료 가드 — 정상 통과
- §3.8.2 격리 패턴 — 정상 동작
- §3.11 post_publish_sync — 7필드 보정 정상
- §3.34.43 PWD — 정상 동작
- cleanup cron 임무 #16 dry-run — 47회 연속 all-green
- cleanup cron 임무 **#23 영구화 완료** ✅

## 결론

- **#996 발행 정상 완료** (실제 라이브 페이지 확인, 가짜 발행 가드 통과)
- **cleanup cron 임무 #23 영구화 완료** (다음 차부터 `_try_md_endpoint(tid)` 함수 직접 호출로 본문 fetch 가능, 임시 우회 heredoc 작성 불필요)
- 본 세션 신규 패턴 발견 없음 — 모든 기존 playbook 정상 동작
- 차감/추가 없음
