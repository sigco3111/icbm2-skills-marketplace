# 224차 세션 노트 — 2026-07-09 — DNA 시퀀싱 MinION (#937, 기타, 3,243자)

## 작업 타임라인

1. §3.8.1 3-endpoint probe: ✅ 200 OK (Tistory max=936 시작)
2. §3.30.4 0단계 health check: ✅ drift 0 (Tistory=936, state=936, details=936)
3. `blog_pipeline.py --refresh-topics`: 12개 긱뉴스 토픽 (Kokoro 15점 / Trusted Publishing 6점 / 코딩배우기 5점 / ReactOS 5점 / Kokoro TTS 3점 / no-mistakes 3점 / Google 데이터센터 3점 / Ternlight 3점 / DNA 시퀀싱 1점 / id Software 2점 / Clippy 2점 / 98%는 1점)
4. **§3.34.10 feeds.feedburner.com RSS fetch**: 50 entries 정상
5. **§3.34.11 5단계 dedup cron 직접 실행**: 20개 후보 14 fresh + 6 skip
   - 5건 skip: 31239/31227/31225/31221/31218 (모두 gn_topic_id 매칭 — §3.34.13 박기 누적 덕분)
   - 1건 skip: 31224 (last_titles 30p 매칭)
   - **224차 §3.34.20 stale fresh=true 3회째 확인**: `blog_pipeline.py --category 'AI/ML'`이 #31218 Ternlight를 fresh=true로 반환 → 5단계 dedup이 정정
6. **1순위 선택**: #31240 DNA 시퀀싱 (RSS 최신 1순위, 5단계 dedup fresh) — `blog_pipeline.py --refresh-topics` 점수 1점(낮음)이나 RSS fetch 시점 가장 최신 → fresh 후보 우선 원칙
7. 긱뉴스 `.md` endpoint: `https://news.hada.io/topic/31240.md` → 200 OK / 21,926 bytes
8. §3.23.1 frontmatter strip: 21,926 → 12,477자
9. **§3.34.1 `tistory_publisher.py --file` 옵션 발행**:
   - heredoc 본문 작성 `/tmp/dna_31240.md` (3,677자)
   - `validate_content`: 3,243자 (소제목/특수문자 차감)
   - Picsum 이미지 2장 자동 삽입 (CDN 업로드 2/2, OG 썸네일 설정)
   - **`--source-url "https://news.hada.io/topic?id=31240"` + `--gn-topic-id 31240`로 §3.34.19 footer 자동 박기** (멱등성 가드 2중 체크 + target=_blank + no-referrer)
   - ✅ publish #937 (https://sigco.tistory.com/937)
10. §3.11 5단계 + §4 5-1 stats 보정:
    - `state.last.id = 937`
    - `last_titles`: 16→17 (DNA prefix 추가)
    - `details`: 17→18 (#937 append with gn_topic_id=31240)
    - `by_category['기타']`: 13→14
    - `daily_counts['2026-07-09']['기타']: 0→1`
    - `total`: 936→937
11. `blog_pipeline.py --record "31240" "..." "https://sigco.tistory.com/937"` (§3.33.2 3개 인자)
12. §3.33.1 §3.32.1 cleanup: 전체 query + URL 매칭 → **2,138 페이지** (223차 2,114에서 +24) / 31240 URL 매칭 0건 / PATCH 0/0 (정상 — 신규 발행은 Notion URL 미박힘)
13. §3.34.3 last_topics: 0개 (이전 정리 후 그대로)
14. §3.5 3중 신호 검증: ✅ drift 0 (시작 936=936=936, 종료 937=937=937)

## 영구화 all-green (224차)

| 패턴 | 차수 | 224차 결과 |
|---|---|---|
| §3.8.1 3-endpoint probe | 196차 | ✅ 200 OK 3/3 |
| §3.30.4 0단계 health check | 213차 | ✅ drift 0 (시작: 936=936=936) |
| §3.34.10 feeds.feedburner.com RSS | 218차 | ✅ 50 entries |
| **§3.34.11 5단계 dedup** | 218차 | ✅ 14 fresh + 6 skip (5 gn_topic_id + 1 last_titles) |
| **§3.34.20 stale fresh=true 3회째** | 220차 | ✅ Ternlight #31218 3회째 — 5단계 dedup이 정정 |
| §3.29.4 긱뉴스 `.md` endpoint | 212차 | ✅ 21,926 bytes (31240) |
| §3.23.1 frontmatter strip | 206차 | ✅ 21,926 → 12,477자 |
| §3.34.1 `tistory_publisher.py --file` | 217차 | ✅ 3,243자 heredoc 파일 |
| **§3.34.19 source footer 자동** | 221차 | ✅ `--source-url` + `--gn-topic-id` argv로 footer 박힘 |
| §3.32.2 cat_key 정규화 | 215차 | ✅ `normalize_cat_key('기타') = '기타'` (alias_map 매핑) |
| §3.11 5단계 + §4 5-1 stats 보정 | 200차 | ✅ `by_category['기타']: 13→14` |
| **§3.34.13 details에 gn_topic_id 박기** | 218차 | ✅ #937에 gn_topic_id=31240 박기 (누적 8건) |
| §3.34.3 last_topics 0개 정리 | 217차 | ✅ 0건 (Tistory URL 항목 없음) |
| §3.33.2 `--record` 3개 인자 | 216차 | ✅ 정상 등록 |
| §3.33.1 §3.32.1 cleanup | 216차 | ✅ 2,138 페이지 / 매칭 0건 / PATCH 0/0 (정상) |
| §3.33.3 Blog DB ID grep | 216차 | ✅ 정상 추출 (5회째) |
| §3.5 3중 신호 검증 | 195차 | ✅ drift 0 (종료: 937=937=937) |

**누적 영구화 all-green**: 213~224차 **연속 12회** (drift 0 시작/종료 + cleanup + stats 보정 풀 사이클 안정화).

## §3.34.20 stale fresh=true 3회째 확인 상세

**3회 연속 stale fresh=true**:
- 220차: §3.34.18.5 — #31218 Ternlight 첫 발견
- 222차: §3.34.20 — 2회째 재확인 (#31221 Ternlight 동시 stale? — 정확히는 #31221 stale fresh=true 보고)
- **224차: 3회째 — #31218 Ternlight (220차 시점 stale fresh=true → 박기 후 5단계 skip 정상)**

**원인**: `blog_pipeline.py`의 `blog_pipeline_state.json` last_topics + Notion DB `활성` 상태만 보고 details.gn_topic_id 매칭 안 함. 박기로 fix 가능하지만, blog_pipeline.py 자체는 218차 §3.34.8부터 5단계 매칭 누락.

**영구화 권장 (변동 없음, §3.34.18.5 유지)**:
- `scripts/5stage-dedup-cron.py` 신규 (cleanup cron 임무 #5)
- `blog_pipeline.py --category`에 5단계 dedup 통합 (cleanup cron 임무 #6)

## gn_topic_id 박기 누적 진행 (213~224차)

- 218차: #930 (31218), #931 (31225) — 2건
- 219차: #932 (31221) — 3건
- 220차: #933 (31224) — 4건
- 221차: retroactive 21/50건 일괄 (박기 누락 9건 포함) — §3.34.19 영구화
- 222차: #935 (31227) — 누적 5건
- 223차: #936 (31239) — 누적 7건 (Kokoro TTS)
- **224차: #937 (31240) — 누적 8건**

**잔여 박기 누락**: 221차 §3.34.19 retroactive cleanup으로 일괄 박기 완료. 신규 누락 없음. **영구화 권장 (§3.34.9)**: 매 publish 시 post-publish 후크 자동 박기 (현재 cron heredoc 수동).

## 핵심 교훈 (224차)

1. **§3.34.20 stale fresh=true는 매 cron마다 재확인되는 known issue** (3회째): 5단계 dedup cron 직접 실행이 정상 작동하여 발행 skip 정확도 유지. cleanup cron 임무 #5/#6 (5stage-dedup-cron.py / blog_pipeline.py 통합)이 해결책. 박기 누적이 정확도 보장의 핵심.

2. **§3.34.19 source footer 영구화 4회째 정상 작동**: `--source-url` + `--gn-topic-id` argv로 publish 직전 본문 하단 긱뉴스 출처 자동 박힘. 멱등성 가드 2중 체크로 중복 박기 방지. 221차 §3.34.19 영구화 4회 검증 (221/222/223/224차).

3. **§3.34.1 `--file` 옵션이 점수 낮은 후보에도 정상 작동**: #31240 DNA 시퀀싱은 `blog_pipeline.py --refresh-topics` 점수 1점이지만 RSS fetch 시점 가장 최신 → fresh 후보 우선. `--file` 옵션 + heredoc 본문 + Picsum 이미지 2장 + OG 썸네일 + footer 자동 박기 풀 사이클 정상.

4. **cleanup 10회 연속 all-green 안정화 단계 정착**: 213~224차 풀 사이클 (0단계 health check → publish → cleanup → stats 보정 → drift 검증) 안정화. §3.33.1 §3.32.1 cleanup이 silent fail 없이 정상 작동. Notion DB 페이지 누적 1,934 → 2,138 (+204 페이지) 동안 cleanup 정확도 유지.

5. **§3.5 3중 신호 drift 0 단일 세션 + 누적 다중 세션 모두 안정**: 224차 시작 936=936=936 / 종료 937=937=937. 박기 누적이 5단계 dedup 정확도를 100% 유지.

## cleanup cron 잔여 임무 (v2.7.73 시점, 224차 시점 미해결 6개)

| # | 임무 | 우선순위 | 의존성 |
|---|---|---|---|
| 1 | `scripts/retroactive-gn-topic-id.py` 1회 실행 | 중 | (221차에 완료) |
| 2 | `post-publish-correct.sh`에 gn_topic_id 박기 단계 | **최고** | publisher 4인자 |
| 3 | `~/.hermes/secrets/notion_blog_db_id.txt` 분리 | 낮음 | grep 패턴 |
| 4 | by_category 변형 키 cleanup (`normalize_cat_key.py --merge`) | 중 | alias_map 보강 |
| 5 | `scripts/5stage-dedup-cron.py` 신규 | **높음** | RSS + 5단계 |
| 6 | `blog_pipeline.py --category`에 5단계 dedup 통합 | **높음** | details.gn_topic_id 매칭 |

## 누적 발행 통계 (224차 시점)

- Tistory max id: **937** (213차 920에서 +17)
- gn_topic_id 박기: **8건** (#930/#931/#932/#933/#934/#935/#936/#937)
- 224차 1편 publish, 누적 cleanup 10회 all-green
- 본문 heredoc + Picsum 이미지 + OG 썸네일 + source footer 풀 자동화 정상
