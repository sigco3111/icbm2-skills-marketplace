# 197차 세션 (2026-07-06 06:53 KST) — 사용자 진단 요청 + §3.14 cron 가짜 발행 누적 결함

## 컨텍스트

사용자 요청: "블로그포스팅이 안되는 것 같은 데 확인해줘" + "A-2 진행"

## 진단 결과

- 세션: ❌ 만료 (§3.8.1 Zombie 302 — 3-endpoint probe로 확정)
- 4일 누적 가짜 발행: **36건** (7/3:10, 7/4:11, 7/5:11, 7/6:4)
- 마지막 실제 발행: 7/2 #903
- stats.total = 924, 실제 마지막 글 = #903 → 자동화 통계 오염

## 발견 3건

### (1) §3.14 = cron 가짜 발행 누적 결함

196차 §3.8.1 + §3.11 5단계 skip 워크플로는 **단일 skip**은 안전하나, 사용자가 개입하기 전까지 cron이 24시간에 수십 회 호출 → 매번 +1 누적 → 약 36건 가짜 발행 누적

**근본 원인**:
- `cron_publish`의 호출 패턴: `blog_pipeline.py --category 'AI/ML'`
- `blog_pipeline.py`는 Step 1 가이드라인 생성 → 통계 +1, Step 2 publish_post() 호출
- 세션 만료 시 Step 2 302 → Step 1의 +1만 남음
- 196차 워크플로는 Step 2만 skip → Step 1의 누적 +1을 못 막음

**영구적 해결 (TODO)**:
- cron 진입 시 `--check` 게이트 (가장 단순)
- blog_pipeline.py의 가이드라인 카운팅을 publish 성공 후로 이동 (§3 §3.3 미수정 TODO와 동일)

### (2) §3.8.1의 `__T_/__T_SECURE/REACTION_GUEST=1` 단독 진단 함정

- `tistory_publisher.py` 코드 82~85줄이 `__T_=1`, `__T_SECURE=1`, `REACTION_GUEST=1`을 **스크립트 권장 default**로 안내
- 즉 이 3종의 길이=1은 정상 fallback이라 단독 만료 신호 ❌
- §3.8.1 만료 판정은 **반드시 3-endpoint probe의 302 + `/auth/login`** 신호
- 184차 reference "REACTION_GUEST 누락 → 기본값 1로 채움 (없어도 발행 가능)" 패턴의 후속 함정

### (3) `last_topics[*].date` 빈값 신호

- `state['last_topics']`의 모든 entry가 `date='?'` (= missing)
- 185차 이후 §3.11 record 버그가 누적되어 date 박힘 자체가 안 됨
- 7/3~7/6 cron 발행들의 진짜 trace를 last_topics에서 못 찾음 (시점 역추적 불가)
- §3.5 표에 197차 신규 신호로 추가

## 진단 oneliner (영구화)

```bash
# §3.14 + §3.11 + §3.5 통합 진단
python3 << 'PYEOF'
import json
from pathlib import Path
from datetime import datetime, timedelta

pt = json.loads(Path('/Users/mac/.hermes/memory/published_topics.json').read_text())
state = json.loads(Path('/Users/mac/.hermes/memory/blog_pipeline_state.json').read_text())

details = pt.get('details', [])

print('날짜       | daily_counts | details | 차이(가짜추정)')
print('-' * 60)
total_fake = 0
for i in range(7):
    d = (datetime.now() - timedelta(days=i)).strftime('%Y-%m-%d')
    daily = sum(state.get('daily_counts', {}).get(d, {}).values())
    details_count = sum(1 for x in details if x.get('date','').startswith(d) and 'sigco.tistory.com' in x.get('url',''))
    diff = daily - details_count
    if diff > 0: total_fake += diff
    print(f'  {d}  | {daily:13} | {details_count:7} | {diff:5}')

print()
print(f'7일 누적 가짜 발행 추정: ~{total_fake}건')
print(f'  last.url: {pt.get("last",{}).get("url","MISSING")}')
print(f'  last.date: {pt.get("last",{}).get("date","MISSING")}')

last_topics = state.get('last_topics', [])
no_date = sum(1 for t in last_topics if not t.get('date'))
print(f'  last_topics date 빈값: {no_date}건 (§3.11 record 버그 누적)')
PYEOF
```

## 4일 누적 실전 (7/3~7/6)

| 날짜 | daily_counts 합계 | details 박힌 sigco URL 수 | 차이 (가짜 추정) |
|---|---|---|---|
| 2026-07-03 | 10 | 0 | **10** |
| 2026-07-04 | 11 | 0 | **11** |
| 2026-07-05 | 11 | 0 | **11** |
| 2026-07-06 (부분) | 4 | 0 | **4** |
| **누적** | **36** | **0** | **36** |

## 이전 세션과의 비교

| 세션 | 가짜 발행 누적 | 진단 | 대응 |
|---|---|---|---|
| 182차 (6/26) | 3건 (15:12) | §3 패턴 | 사용자가 즉시 인지 + 롤백 |
| 196차 (7/2 19:00) | 0건 | §3.8.1 skip | 단일 skip + 알림 → 사용자가 7/6 06:53 질의 시점에 4일치 누적 |
| **197차 (7/6)** | **36건 (7/3~7/6 4일)** | **§3.14 = 196차 워크플로의 구조적 결함** | **사용자 진단 요청 → 발견** |

## 사용자 작업 흐름

1. A-2 진행 중 — 사용자가 브라우저에서 TSSESSION + _T_ANO 새 값 추출 → 에이전트에게 전달 예정
2. 에이전트가 env 갱신 후 3-endpoint probe OK 확인
3. 에이전트가 §3.2 롤백 패턴으로 36건 차감
4. cron은 다음 next_run_at 시점에 정상 발행 재개
5. 영구 해결 패치는 198차로 이월

## 신규 발견 — 만료 주기 가설

- 과거: 3개월+ 유지
- 6/29 ~ 7/2: 3일 만에 만료 (184차 갱신)
- 7/6까지 보류 중 (4일 경과)

**가설 3개**:
1. Tistory 보안 정책 변경 (2026년 6월 이후)
2. _T_ANO의 absolute expiration 7~10일
3. 7/5 PC 진단 (Chrome 원격 데몬 문제) 후 브라우저 측 세션 종료

**가장 가능성 높은 조합: ①+③** (Tistory 정책 강화 + PC 이슈가 겹쳐 만료 가속)

**확정 방법 (10분 작업, 198차 권고)**:
- `scripts/verify-tistory-cookie.sh` 자동 cron 등록 (184차 TODO — 현재 미실행)
- 매일 1회 `--check` → 만료 시 알림 → 정확한 만료 시점 측정

## 변경 사항 (스킬)

- §3.14 신규 — cron 가짜 발행 누적 결함 + 진단 oneliner + 4일 누적 표
- §3.5 3중 신호 판정 표에 2행 추가 (last_topics[*].date 빈값 5건 이상, daily_counts - details 박힌[d] 7일 누적 > 5건)
- §3.8.1에 `__T_/__T_SECURE/REACTION_GUEST=1` 단독 진단 함정 주의 명시
- 한눈에 보기 20가지로 확장
- §6 변경 이력 v2.7.46 행 추가
