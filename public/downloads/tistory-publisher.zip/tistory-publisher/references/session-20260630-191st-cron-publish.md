# 191차 세션 노트 (2026-06-30T03:00)

**발행 글**: https://sigco.tistory.com/878
**주제**: EU, 비공개로 Chat Control 입법 추진 — 개발자가 주목해야 할 양대 쟁점
**카테고리**: 개발도구 (ID 1219748)
**소스**: https://news.hada.io/topic?id=30925

## 워크플로 요약

1. `python3 ~/.hermes/scripts/blog_pipeline.py` → 주제 + tistory_category_id + guidelines JSON 출력
2. 긱뉴스 `.md` endpoint 시도 → **404** (191차 신규 발견, 189차/190차 패턴과 다름)
3. 긱뉴스 HTML fallback → `<div class=topic_contents>` 영역에서 1,938자 추출
4. `tistory_publisher.py --file` + `--image-query` 호출 (URL 인자 없이) → ✅ #878 자동 발행
5. §3.11 5단계 보정 (190차 패턴) — 단, `details` append 누락 발견 → 191차 보강 코드 확립
6. §3.5 3중 신호 검증 → 가짜 발행 0건

## 191차 신규 발견 3건 (SKILL.md §8.5)

### 1) 긱뉴스 `.md` endpoint가 404
- 189차/190차 패턴: `https://news.hada.io/topic/<id>.md` 우선 호출
- 191차: topic id 30925 → 404
- 원인: 긱뉴스가 일부 토픽에서 .md 라우트 폐지한 듯
- 대응: HTML fallback 패턴 확립 — `<div class=topic_contents><div><div id='topic_contents'>` 영역 추출
- 추출 코드: §8.5.1 참조

### 2) `tistory_publisher.py` URL 자동 확보
- 190차 §8.1 권고: "cron에서 항상 3번째 인자로 Tistory URL placeholder 전달"
- 191차 실전: URL 인자 없이 호출했는데도 정상 박힘
- 원인: `publish_post()`가 Tistory API 응답의 `entryUrl`을 내부 변수로 잡고 자동 동기화
- 결론: URL placeholder는 불필요, 190차 권고 무효화
- 단, §3.11 5단계는 권장 유지 (cron 환경 차이 흡수)

### 3) §3.11 5단계에 `details` append 누락
- 190차 §8.2 워크플로는 `last` 갱신만 있었음
- 191차: `details[-1]`이 여전히 직전 글이어서 append 패턴 필요
- 보강 코드: §8.5.3 참조 (last 갱신 + details append 동시)
- 192차: §3.11 5단계 + §4 자주 쓰는 명령에도 통합 필요

## 7KB+ 1회 컷 정형화 통과 (191차)

- 본문: 2,665자 (검증 통과) / 2,903자 (코드블록 제외)
- H2: 7개
- 코드블록: 1개
- 이미지: Picsum 자동 2장 (encryption europe parliament security) + CDN 업로드 2/2
- OG 썸네일: 자동 설정

## 자동화 안전도 (191차 종료 시점)

| 지표 | 값 |
|---|---|
| 발행 글 | #878 — 정상 |
| stats total | 850 |
| sigco URL 라인 수 | 330 |
| §3.5 차이 | 520 (188차 정정 — false positive 패턴) |
| 진짜 가짜 발행 | 0건 |
| 세션 | 유효 (740개 글) |
| §3.11 5단계 | last + details 동시 append 패턴 확립 |
| 7KB+ 1회 컷 | 통과 |

## 192차로 이월 TODO

1. 긱뉴스 `.md` → HTML `class=topic_contents` 폴백을 `blog_pipeline.py` fetch 단계에 통합
2. §3.11 5단계 보강 (`details` append 포함)을 `scripts/post-publish-correct.sh`로 영구화
3. 191차 발견 3건을 §4 자주 쓰는 명령에 통합 (긱뉴스 .md fallback oneliner + details append 코드)
4. 191차 reference에 명시된 stale 함수 `tistory_publisher.py`의 `--record-topic` 단독 record-only 미지원은 §3.12 그대로 유효
