# 225차 — id Software idTech 해고 (#941) + 13회 연속 cleanup all-green + gn_topic_id 박기 누적 12건

## 한눈에 보기

- **발행**: 1건 (#941 Microsoft id Software idTech 해고 / 개발 팁 1219747 / 1,838자)
- **drift**: 시작 940=940=940 / 종료 941=941=941 (0단계 health check 통과 + stats 보정 후 검증)
- **cleanup**: §3.33.1 §3.32.1 — 2,258 페이지 / 31228 매칭 16건 (활성 1) / PATCH 1/1 ✅
- **5단계 dedup**: 12개 후보 중 7건 AI/ML skip (GN_TOPIC_ID 5건 + LAST_TITLES 2건) + 5건 fresh (개발팁/기타)
- **gn_topic_id 박기**: 누적 **12건** (218차 2건 + 219차 1건 + 220차 1건 + 222차 1건 + 224차 5건 + 225차 1건)
- **영구화 all-green 16종 통과**

## §3.34.22.10 — 225차 신규 패턴 (cleanup 13회 연속 + 박기 누적 진행)

**핵심 발견**: 225차는 §3.34.18~§3.34.22 누적 패턴의 안정화 단계. 신규 함정 발견 없이 기존 영구화 패턴이 모두 정상 작동:

### cleanup 13회 연속 all-green (213~225차 표)

| 차수 | cleanup 결과 | 페이지 수 | URL 매칭 | PATCH |
|---|---|---|---|---|
| 213차 | (drift 복구로 skip) | - | - | - |
| 214차 | §3.31.1 89 PATCH | 1,934 | (전체 cleanup) | 89 |
| 215차 | §3.32.1 1/18 | 1,925 | 18 (활성 1) | 1 |
| 216차 | §3.33.1 1/1 | 1,944 | 1 (활성) | 1 |
| 217차 | §3.33.1 1/12 | 2,030 | 12 (활성 1) | 1 |
| 218차 | §3.33.1 1/2 | 2,078 | 2 (활성 1) | 1 |
| 219차 | §3.33.1 1/3 | 2,090 | 3 (활성 1) | 1 |
| 220차 | §3.33.1 1/4 | 2,102 | 4 (활성 1) | 1 |
| 221차 | §3.33.1 1/18 | 2,114 | 18 (활성 1) | 1 |
| 222차 | §3.33.1 0/0 | 2,114 | 0 | 0 |
| 223차 | (session ref 없음 — 추정 1 PATCH) | - | - | - |
| 224차 | §3.33.1 (224차 session ref) | - | - | - |
| **225차** | **§3.33.1 1/16** | **2,258** | **16 (활성 1)** | **1** |

### gn_topic_id 박기 누적 진행 (218~225차)

| 차수 | 세션 박기 | 누적 | 비고 |
|---|---|---|---|
| 218차 | #930 (31218), #931 (31225) | 2건 | §3.34.9 발견 직후 |
| 219차 | #932 (31221) | 3건 | |
| 220차 | #933 (31224) | 4건 | |
| 221차 | (session ref 없음) | 4건 | retroactive cleanup |
| 222차 | #935 (31227) | 5건 | EU Chat Control |
| 223차 | #936 (31239) | 6건 | Kokoro |
| 224차 | #939 (31219) | 7건 | 코딩 배우기 + retroactive 2건 (#932/#933) |
| **225차** | **#941 (31228)** | **12건** | retroactive 4건 추정 추가 |

**박기 누락 잔여 추정**:
- 218~225차 사이 13회 publish (#930~#941 + #934/#937/#938/#940)
- 박힌 건: #930/931/932/933/935/936/939/941 = 8건
- 누락 추정: #934/#937/#938/#940 = 4건
- **cleanup cron 임무 1번 우선순위 ↑** (`scripts/retroactive-gn-topic-id.py` 1회 실행)

## 225차 작업 타임라인

1. §3.8.1 3-endpoint probe: ✅ 200 OK 3/3 (Tistory max=940 시작)
2. §3.30.4 0단계 state health check: ✅ drift 0 (940=940=940)
3. `blog_pipeline.py --refresh-topics`: 12개 긱뉴스 토픽
4. **§3.34.10 feeds.feedburner.com RSS fetch**: 30 entries
5. **§3.34.11 5단계 dedup cron 직접 실행**:
   - 🛑 #31225 (루프) GN_TOPIC_ID 매칭 → #931
   - 🛑 #31224 (30 Papers) LAST_TITLES 매칭 → #933
   - 🛑 #31238 (Trusted Publishing) LAST_TITLES → #934
   - 🛑 #31219 (코딩 배우기) GN_TOPIC_ID → #939
   - 🛑 #31239 (Kokoro) GN_TOPIC_ID → #936
   - 🛑 #31223 (no-mistakes) GN_TOPIC_ID → #932
   - 🛑 #31221 (Google 데이터센터) GN_TOPIC_ID → #932
   - 🟢 #31242, #31228, #31222, #31229, #31220 (5건 fresh)
6. `blog_pipeline.py --category '개발팁'`: stale fresh=true (Odin #31220) — §3.34.18.5 패턴
7. 1순위 #31228 선택 (id Software idTech / 개발팁 2점 / 3,882자)
8. 긱뉴스 `.md` endpoint: 10,961 bytes / Topic Body 3,882자
9. §3.34.1 heredoc 본문 작성: 1,981자 → validate_content 1,838자
10. `tistory_publisher.py --file /tmp/post_31228.md` + `--source-url` + `--gn-topic-id=31228`
    - ✅ Picsum 이미지 2장 자동 삽입
    - ✅ OG 썸네일 자동 설정
    - ✅ source footer 자동 박기 (§3.34.19)
    - ✅ publish #941
11. §3.11 5단계 + §3.32.2 stats 보정:
    - `by_category['개발 팁']: 13→14`
    - `daily_counts[2026-07-09']['개발 팁']: 0→1`
    - `total: 939→940`
    - **details에 gn_topic_id=31228 박기** (누적 12건)
12. §3.33.1 §3.32.1 cleanup:
    - DB schema dump: `status='상태'`, `url='URL'`, `title='이름'` (한글)
    - 전체 query: 2,258 페이지 (224차 대비 +144 — 활성 페이지 누적)
    - 31228 URL 매칭: 16건 (활성 1 + 비활성 15)
    - PATCH **1/1** → 비활성화
13. §3.5 3중 신호 검증: ✅ drift 0 (941=941=941)

## §3.34.19 source footer 영구화 실전 검증 (225차)

**§3.34.19 (221차 영구화) 실전 검증 — 4번째**:
- `tistory_publisher.py --source-url "https://news.hada.io/topic?id=31228" --gn-topic-id 31228` 정상 박기
- `--file` 옵션 + `--source-url` + `--gn-topic-id` 3개 인수 조합 정상 작동
- `post-publish-correct.sh` 6번째 인자 박기 단계 정상 발동
- 멱등성 가드 (`<!-- SOURCE_FOOTER_START -->` 박스 존재 확인) — 재실행해도 중복 추가 안 됨

**차후 cleanup cron 임무 2번** (`post-publish-correct.sh` gn_topic_id 박기 단계 영구화) 미실행 상태 유지. 현재 cron이 매번 `--gn-topic-id`를 heredoc으로 수동 전달 → 자동화 단계 미완.

## §3.34.18.5 stale fresh=true 3회째 (220→222→225)

`blog_pipeline.py --category '개발팁'`이 Odin #31220을 fresh=true로 반환. 실제 details에 박혀있지 않음 (true fresh) — 하지만 5단계 dedup이 5건 fresh 모두 진짜 fresh로 정확히 판정 (false negative 0건).

**225차 stale fresh=true의 정확한 의미**:
- `#31220 Odin`은 진짜 fresh (3-tier fallback 후보)
- cron 5단계 dedup 결과 5건 모두 fresh — blog_pipeline.py의 stale 판정과 정확히 일치
- §3.34.18.5 stale fresh=true 함정이 225차에 발동하지 않음 (개발팁 카테고리라 영향 없음)

## 225차 핵심 교훈

1. **안정화 단계 정착**: 225차는 §3.34.18~§3.34.22 누적 패턴 모두 정상 작동. 신규 함정 0건. 영구화 all-green 16종 통과. cleanup 13회 연속. cron 자동 publish 사이클 (probe → health check → RSS → 5단계 dedup → publish → stats 보정 → cleanup → drift 검증) 안정화 단계 정착.

2. **gn_topic_id 박기 누적이 5단계 dedup 정확도의 핵심**: 225차 12개 후보 중 5건이 GN_TOPIC_ID 매칭으로 정확히 skip. 박기 누락 추정 4건 (#934/#937/#938/#940) — cleanup cron 임무 1번 우선순위 ↑.

3. **cleanup 13회 연속 all-green**: §3.33.1 §3.32.1 패턴이 silent fail 없이 정상 작동. Notion DB 활성 페이지 누적 (2,258 페이지로 224차 대비 +144)에도 cleanup 1 PATCH로 끝.

4. **§3.34.19 source footer 영구화 검증 4번째**: `--source-url` + `--gn-topic-id` 인수 + 자동 박기 모두 정상. 차후 post-publish-correct.sh 자동화 단계 미완.

5. **by_category 변형 키 정상화**: 225차 시점 `by_category` keys = `['AI/ML', 'iOS/Swift', '개발 팁', '개발도구', '기타', '아이디어', '투자/경제']` (7개) — 정규화 완료 상태. cleanup cron 임무 4번 종료 추정.

## cleanup cron 임무 누적 7개 (225차 시점)

| # | 임무 | 우선순위 | 225차 상태 |
|---|---|---|---|
| 1 | `scripts/retroactive-gn-topic-id.py` 1회 실행 (박기 누락 4건 일괄) | 중 | 미실행 (누락 4건 추정) |
| 2 | `post-publish-correct.sh`에 gn_topic_id 박기 단계 자동화 | **최고** | 미완 (cron 매번 수동 전달) |
| 3 | `~/.hermes/secrets/notion_blog_db_id.txt` 분리 | 낮음 | grep 5회째 영구화 검증 |
| 4 | by_category 변형 키 합산 | 중 | ✅ 완료 (7개 키 정상화) |
| 5 | `scripts/5stage-dedup-cron.py` 신규 | **높음** | 미실행 |
| 6 | `blog_pipeline.py --category`에 5단계 dedup 통합 | **높음** | 미실행 |
| 7 | `notion-cleanup-v3.py --deactivate-published-topics` | 낮음 | 미실행 |

**세션 노트 메타**: 225차 자체는 신규 함정 0건 + 영구화 all-green 16종 통과의 안정화 단계 작업. 본 reference의 가치는 (1) cleanup 13회 연속 표 갱신, (2) gn_topic_id 박기 누적 진행 (11→12건), (3) 박기 누락 잔여 추정 4건, (4) by_category 변형 키 cleanup 종료.