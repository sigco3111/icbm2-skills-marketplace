# 220차 세션 노트 — #933 "30 Papers" 5단계 dedup 2회째 + 8회 연속 cleanup all-green

**날짜**: 2026-07-08
**차수**: 220차
**Tistory max id**: 시작 932 → 종료 **933**
**발행**: #933 "30 Papers - 일리야 서츠케버 추천 AI 핵심 논문 입문 가이드" (AI/ML, 1,762자, Picsum 2장)
**URL**: https://sigco.tistory.com/933
**drift**: 0 (시작 932=932=932, 종료 933=933=933)

## 1. 0단계 게이트 통과
- §3.8.1 3-endpoint probe: ✅ 200 OK 3/3 (Tistory max=932)
- §3.30.4 0단계 state health check: ✅ drift 0

## 2. feeds.feedburner.com RSS + 5단계 dedup
- 50 entries (limit 20)
- 5단계 dedup cron 직접 실행 결과: 17 fresh + 3 skip (모두 gn_topic_id 매칭)
  - Skip 3건: #31225 (gn_topic_id=31225, #931), #31221 (gn_topic_id=31221, #932), #31218 (gn_topic_id=31218, #930)
  - 1순위 FRESH: #31224 "30 Papers" (9.0점, AI/ML)
- `blog_pipeline.py --category 'AI/ML'`은 #31218 Ternlight를 stale fresh=true 반환 → cron 5단계 dedup이 정정 (§3.34.18.5 함정 발견)

## 3. 긱뉴스 fetch + 본문 작성 + 발행
- 긱뉴스 `.md` endpoint: 200 OK / 20,999 bytes / 339 lines
- §3.23.1 frontmatter strip: 20,999 → 12,076자
- heredoc 본문 1,862자 (POSTEOF single-quoted)
- `tistory_publisher.py --file /tmp/post_31224.md ...` → validate_content 1,762자 / Picsum 2장 자동 삽입 / OG 썸네일 설정

## 4. §3.11 5단계 + §4 5-1 stats 보정
- state.last.id = 933
- last_titles: 12→13 (30 Papers prefix 추가)
- details: 13→14 (#933 append with **gn_topic_id=31224** ← §3.34.13 박기 누적 4건)
- by_category['AI/ML']: 718→719 (정규화 cat_key)
- daily_counts['2026-07-08']['AI/ML']: 5→6
- total: 932→933
- §3.34.3 last_topics 0개 (발행 후 정리)

## 5. §3.33.1 §3.32.1 cleanup (8회 연속 통과)
- 전체 query: 2,102 페이지 (219차 2,090에서 +12)
- 31224 URL 매칭: 4건 (활성 1 + 비활성 3)
- PATCH 1/1 → 비활성화 ✅
- §3.33.3 Blog DB ID grep 4회째 영구화 검증

## 6. by_category 변형 키 3쌍 발견 (§3.34.18.3)
- `'AI 뉴스': 1` ↔ `'AI/ML': 719` (변형 1쌍 — 단순 합산)
- `'개발': 1` ↔ `'개발도구': 132` (**부분 문자열 — 수동 확인 권장**)
- `'개발팁': 12` ↔ `'개발 팁': 12` (공백 정규화)
- 누적 합계 26건 → `scripts/normalize_cat_key.py --merge` 1회 cleanup 임무
- 상세: `references/220th-by-category-variant-keys.md`

## 7. 영구화 all-green 17개 패턴
모두 ✅ 통과 (cleanup 8회 연속 + drift 0 시작/종료 + stats 보정 + gn_topic_id 박기 4건 + 5단계 dedup 2회째).
§3.34.18.5 blog_pipeline.py stale fresh=true 함정만 발견 (영구화 임무 추가).

## 8. 후속 cleanup cron 임무 목록 (10개 + 1)
1. `scripts/retroactive-gn-topic-id.py` 신규 — 박기 누락 9건 (#921~#929) 일괄
2. `scripts/post-publish-correct.sh` gn_topic_id 박기 자동화
3. `~/.hermes/secrets/notion_blog_db_id.txt`로 DB ID 분리
4. `scripts/normalize_cat_key.py --merge` 1회 실행
5. `scripts/5stage-dedup-cron.py` 신규 — 재사용 가능한 cron 전용 5단계 dedup
6. `blog_pipeline.py --category`에 5단계 dedup 통합 (Notion DB + details + gn_topic_id 동시 매칭)
7. Notion 동일 URL archive (URL당 1건)
8. `scripts/notion-cleanup-v3.py --deactivate-published-topics` (활성 필터 X)
9. `scripts/state-recovery-213th.py --dry-run / --apply`
10. post-publish 후크 atomic write 강화 (`os.replace()` + retry 3회)
11. `--refresh-topics` 자동 cleanup dry-run default

## 9. 핵심 발견 (5가지)
1. **박기 누적 비례 5단계 dedup 정확도 향상** (#931+#932+#933 = 4건 박기)
2. **blog_pipeline.py --category stale fresh=true** (Notion DB 활성만 보고 details의 gn_topic_id 모름)
3. **by_category 변형 키 3쌍 누적** (212차 이후 누적 패턴)
4. **cleanup 체인 안정화 8회 연속 통과** (213~220차 풀 사이클)
5. **gn_topic_id 박기 4건 누적 → 차후 retroactive cleanup 시 100% 정확도 가능**
