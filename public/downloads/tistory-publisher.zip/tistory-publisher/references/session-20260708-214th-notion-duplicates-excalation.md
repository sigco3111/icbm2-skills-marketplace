# 214차 세션 노트 — `--refresh-topics` 광범위 Notion cleanup + 동일 URL 다중 페이지 누적

**날짜**: 2026-07-08
**차수**: 214
**주제**: GLM 5.2와 다가오는 AI 추론 마진 붕괴 (#926)
**긱뉴스 토픽**: https://news.hada.io/topic?id=31209 (GN+)

## 작업 타임라인

1. **§3.8.1 3-endpoint probe**: ✅ 200 OK (세션 유효)
2. **§3.30.4 0단계 state health check**: ✅ drift 0 (Tistory=925, state=925, details=925) — 213차 복구 영구화 정상
3. **`blog_pipeline.py --refresh-topics`**: 12개 긱뉴스 토픽 refresh
   - 출력: `deactivated: 12, added: 12, failed: 0` (정상처럼 보임)
4. **Notion DB active 페이지 query**: 12개 active 페이지 발견 (refresh-topics의 cleanup이 비활성화 실패 또는 새 active 페이지 추가)
5. **cleanup 89 PATCH 실행**: 12개 URL × 평균 7.4 페이지 모두 비활성화 → active=0
6. **DB 전체 진단**: 1934 페이지 / 926 unique URL / 평균 2.09 페이지/URL / 최대 23개 중복
7. **§3.5 3중 신호 재검증**: ✅ drift 0
8. **fresh 후보 11개**: AI/ML 6, 개발도구 3, 개발팁 2
9. **score=14 GLM 5.2** (긱뉴스 31209) 선택
10. **긱뉴스 본문 fetch**: `.md` endpoint 200 OK, 12,319 bytes
    - body clean: 12,152자 → frontmatter strip → 11,114자
11. **article 빌드**: 도입 256자 + body + footer = **11,370자**
12. **publish #926**: Picsum 2장 자동 삽입 (CDN 업로드 2/2), OG 썸네일 설정
13. **§3.11 + §4 5-1 stats 보정**: state/details/daily_counts 정상
14. **§3.5 3중 신호 최종 검증**: ✅ drift 0

## §3.31 핵심 발견

### §3.31.1 — `--refresh-topics` cleanup 광범위 발동

**증상**:
```
Notion active URLs: 12
Refresh topics URLs: 12
Overlap: 12

# cleanup 결과
Total PATCH: 89
After cleanup active pages: 0
```

**문제**: 12개 URL × 평균 7.4 페이지 = 89 PATCH. 1개 cleanup에 89 PATCH는 부작용:
- DB 자체 오염 가속화 (1934 페이지 → 89 페이지가 비활성화)
- PATCH rate limit 위험 (Notion API: 평균 3 req/sec)
- cleanup이 의도된 12건 비활성화를 넘어 DB 자체를 손상

**영구화 권장**:
1. `scripts/notion-cleanup-v3.py --archive-duplicates` 명시적 스크립트
2. `--refresh-topics`의 자동 cleanup → dry-run default

### §3.31.2 — Notion DB 다중 페이지 누적 실전 확인

**진단 결과** (DB 전체 query):
- Total pages: 1934
- Unique URLs: 926
- URL당 평균: 2.09 페이지
- 최대 중복: 23개 (5개 URL: 31161, 31166, 31165, 31169, 31158)
- Status: `{'비활성': 1934}` (cleanup으로 모두 비활성화됨)

**근본 원인**:
- `update_notion_topic_last_used()` 함수가 fire-and-forget으로 매번 신규 페이지 생성
- 200차 이전 silent fail 패턴이 214차까지 누적
- **Notion DB 자체 cleanup이 시급** — URL당 1건만 남기고 archive

### §3.31.2 — 진단 함정 (출력 truncate)

첫 cleanup heredoc 출력:
```
89 PATCH 모두 page_id 39676f2e로 갔음
```
→ 사실은 **모든 PATCH가 다른 페이지로 정상 분산**됐지만, 출력 truncate로 동일 page_id처럼 보였던 진단 함정. 실제 DB scan으로 확인하니 페이지별 다른 page_id였음.

**올바른 진단**: cleanup 후 항상 DB 전체 scan + URL별 페이지 수 분포 출력.

## 영구화 all-green (214차)

| 패턴 | 차수 | 214차 결과 |
|---|---|---|
| §3.8.1 3-endpoint probe | 196차 | ✅ 200 OK |
| §3.30.4 0단계 state health check | 213차 | ✅ drift 0 |
| §3.22.2 + §3.28.2 + §3.29.2 Notion cleanup 3단계 매칭 | 211~212차 | ⚠️ 광범위 발동 (89 PATCH) |
| §3.23.1 frontmatter strip | 206차 | ✅ 12,152자 → 11,114자 |
| §3.18 half-pipeline 직접 heredoc 본문 | 198~212차 | ✅ 11,370자 |
| §3.11 + §4 5-1 stats 보정 | 200차 | ✅ 정상 |
| §3.5 3중 신호 검증 | 195차 | ✅ drift 0 |
| §3.29.4 긱뉴스 `.md` endpoint | 212차 | ✅ 12,319 bytes / 200 OK |

## 차후 cleanup cron 임무 (214차 누적)

1. **`scripts/notion-cleanup-v3.py --archive-duplicates` 신규** — §3.22.2 + §3.25.2 + §3.28.2 + §3.29.2 + §3.31.1 통합
2. **`--refresh-topics`의 cleanup 로직 dry-run default** — 자동 cleanup 발동 차단
3. **Notion DB 자체 archive cleanup** — 1934 페이지 → URL당 1건만 남기고 archive (1000+ 페이지 제거)
4. **`scripts/state-recovery-213th.py` 신규** — §3.30.4 0단계 health check 영구 스크립트
5. **`scripts/normalize_cat_key.py --merge` 1회 실행** — by_category 변형 키 2쌍 합산
6. **post-publish 후크 atomic write 강화** — 211~212차 silent corruption 재발 방지

## publish #926 상세

- **Tistory URL**: https://sigco.tistory.com/926
- **제목**: GLM 5.2와 다가오는 AI 추론 마진 붕괴
- **카테고리**: AI/ML (1219746)
- **태그**: AI, LLM, GLM, 추론비용, 오픈웨이트
- **공개**: public
- **이미지**: Picsum 2장 (ai-inference-cost-0, ai-inference-cost-1)
- **OG 썸네일**: https://blog.kakaocdn.net/dna/wTR1V/dJMcaalzDeU/AAAAAAAAAAAA...

### 본문 빌드

```
## 도입 (256자)
+ 긱뉴스 본문 (11,114자)
+ ## 출처 footer (191자)
= 11,370자 (Tistory 한도 65,535자 이내)
```

### stats 보정 결과

| 항목 | 시작 | publish 후 |
|---|---|---|
| state.last.id | 925 | 926 |
| last_titles | 5개 | 6개 |
| blog_details | 6건 | 7건 (#926 마지막) |
| by_category['AI/ML'] | 712 | 713 |
| daily_counts['2026-07-08']['AI/ML'] | 0 | 1 |
| stats.total_posts | (계산 안 됨) | 1 |

## 핵심 교훈

1. **`--refresh-topics`의 cleanup 출력은 표면적**: `deactivated: 12, added: 12`는 정상처럼 보이지만 실제로 89 PATCH가 발동되어 DB 오염 가속화. cleanup은 명시적 스크립트로 분리.

2. **Notion DB 자체 cleanup이 시급**: 1934 페이지 / 926 unique URL / 평균 2.09 페이지/URL / 최대 23개 중복 → URL당 1건만 유지하고 archive하는 별도 cron 임무 필요.

3. **publish 흐름은 정상**: §3.30.4 0단계 + §3.5 3중 검증 + stats 보정이 모두 정상 작동 → #926 발행 성공.

4. **진단 함정 (출력 truncate)**: 첫 cleanup 결과에서 "모두 같은 page_id"로 보이는 건 출력 truncate 함정. 실제 DB scan 필요.

## 다음 차수 권장

1. `scripts/notion-cleanup-v3.py --archive-duplicates` 즉시 작성
2. `--refresh-topics`의 cleanup 코드 제거 또는 dry-run default
3. Notion DB archive cleanup 1회 실행 (1934 → ~926 페이지)