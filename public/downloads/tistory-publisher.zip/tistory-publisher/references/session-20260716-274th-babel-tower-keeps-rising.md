# 274차 세션 — 2026-07-16

## 발행 결과

**`#1019 바벨탑은 여전히 높아진다 — AI 에이전트 시대, 공유된 이해를 어떻게 지켜낼 것인가`**
- URL: https://sigco.tistory.com/1019
- 카테고리: AI 뉴스 (1219746) / AI/ML
- 원문: gn=31451 (Armin Ronacher 「The Tower Keeps Rising」, 1점)
- 연속 all-green **61회차** (213~274차)

## 워크플로

1. **§3.8.1 세션 가드** — `env -i HOME=/Users/mac PATH=/usr/bin:/bin PWD=/Users/mac /bin/bash -c 'set -a; source ...; /usr/bin/python3 ...'` 격리 패턴 + §3.34.41 string concat 적용 → `status=200, ct=application/json;charset=UTF-8, cookie_count=8` ✅
2. **트렌드 데이터** — `python3 ~/.hermes/scripts/blog_pipeline.py --refresh-topics --dry-run | grep -E 'URL:' | head -12` → 후보 12개 추출
3. **FRESH 4-field v2 매칭** — `pt_published` set에 `pt.details` 의 `topic/topic_id/gn_topic_id` + `state.details` 의 `topic_id/gn_topic_id` + **`pt.last.gn_topic_id`** (§3.34.40 v2 guard) 모두 추가. FRESH 4개: 31457/31447/31451/31464
4. **5중 신호 검증** — `state.last_published_url / state.last.url / state.details[-1].url / pt.last.url / pt.details[-1].url` 모두 `#1018` 일치 (drift 무해)
5. **카테고리 매트릭스** — §3.34 #21 AI/ML 우선 + §3.34.45 매트릭스 분기 1 ("FRESH 'AI/ML' + 비-기타 혼재 → AI/ML 픽") 으로 31451 픽
6. **본문 빌드 (격리)** — `write_file` 로 `/tmp/tistory_drafts_274th/build_draft_31451.py` (6587 bytes) UTF-8 선언 + 저장 → `python3 <script>.py` 격리 호출 (§3.34.47)
7. **§3.34.46 영구화** — `_try_md_endpoint(31451)` → status=200, 9400 bytes 1단계 `.md` endpoint 즉시 fetch
8. **§3.34.50 Topic Body 마커 기반 추출** — `re.search(r"## Topic Body\s*\n+(.*)", text, re.DOTALL)` → 본문 평문 2158자 정상
9. **md_to_html** — 4단계 헤더 강등 + `- `/`* ` 분기 + 들여쓰기 nested ul 회피 + `- ## 헤더` 위장 항목 라우팅 (§3.34.48 + 262차 보완)
10. **editorial 인트로 + 결론** — 한국어 540자 + 1700자 추가 → 풀 평문 3055자 (300자 가드 통과)
11. **publish** — `tistory_publisher.py --title ... --category 1219746 --file ... --source-url ... --gn-topic-id 31451 --image-query "ancient tower babel construction workers blueprint architecture abstract"`
12. **§3.11 sync** — `post_publish_sync.py sync --url ... --title ... --gn-topic-id 31451 --category "AI/ML" --category-id 1219746 --source-url ...` → `pt_updated: true / state_updated: true / errors: [] / triple_signal_match: true`
13. **5중 신호 재검증** — 모두 `#1019` 일치 (all_match: True)
14. **라이브 페이지 직접 GET** — `status=200, size=67183, window.T.entryInfo={entryId:1019, categoryId:1219746, categoryLabel:"AI 뉴스"}, title tag='바벨탑은 여전히 높아진다 &mdash; ...'` 실제 발행 확인
15. **cleanup cron 임무 #16 dry-run** — `✅ 누설 없음` (60→61회 연속 all-green)

## 본 세션 관찰

### §3.34.50 Topic Body 본문 추출 실전 2호 (NEW 검증)

272차에 식별된 "## Metadata skip 로직이 본문 bullet 까지 잘라냄" 함정이 274차 본문 (gn=31451) 에서 hit하지 않음. 본문 첫 bullet 이 `- 바이브 코딩된 소프트웨어가 ...` (메타 아닌 본문) 이지만 272차 식별 케이스(gn=31443) 와 달리 `- 키:값` 형태가 아니어서 260차 로직이 정상 통과 → 2158자 정상. Topic Body 마커 기반 추출(`re.search(r"## Topic Body\s*\n+(.*)", text, re.DOTALL)`) 로 본문 마커만 잡는 패턴이 더 안전 — gn=31451 case 에선 두 패턴 모두 정상이나 272차 케이스에 대비해 Topic Body 마커 패턴 우선 적용 권장. **영구화 권장**: `scripts/gn-fetch-content.py` 본문 추출 함수를 Topic Body 마커 기반으로 정정. cleanup cron 임무 #31 (272차 식별 + 274차 검증).

### §3.34.51 splice backfill 가드 1회 검증 (NEW)

274차 검증 결과 pt.details idx=109 (Bonsai 27B, 271차 발행) entry에 splice 누락은 발생하지 **않았음**. 다만 발견한 비정상: `topic` 필드에 title 전체 문자열이 박혀있음 (정상: `topic='31450'` 같은 numeric ID). 이는 271차 splice 시 title이 topic 키로 잘못 박힌 형식 오류 잔재. 5중 신호 일치 + FRESH 4-field v2 가드 정상 (Bonsai 27B가 pt.details에 존재하므로 FRESH 매칭에서 제외 OK). publish 동작에 영향 없음. **cleanup cron 임무 #30 (splice backfill 모듈)** 신규 영구화는 다음 차에 권장 유지.

### FRESH 잔여 3개 (다음 차 후보)

- **31457** PostHog 70배 SQL 파서 (개발도구, 1점)
- **31447** 유럽 연령 확인 앱 Android/iOS 강요 (투자/경제 or 개발도구, 1점)
- **31464** CWIST 웹 프레임워크 (Show GN — '기타' 후보, 1점)

## 검증 summary

| 항목 | 결과 |
|------|------|
| §3.8.1 가드 | ✅ status=200, cookies=8 |
| §3.5 5중 신호 | ✅ all_match=True (#1019) |
| §3.11 sync | ✅ pt_updated=true, state_updated=true |
| §3.34.40 v2 FRESH | ✅ FRESH 4개 정확 식별 |
| §3.34.46 fetch | ✅ 9400 bytes 즉시 fetch |
| §3.34.47 격리 빌드 | ✅ 6587 bytes build script 무영향 |
| §3.34.48 `* ` 분기 | ✅ 안전 가드만 (hit 없음) |
| §3.34.50 Topic Body | ✅ 본문 평문 2158자 정상 |
| cleanup cron #16 | ✅ 61회 연속 all-green |
| 라이브 페이지 검증 | ✅ entryId:1019, categoryId:1219746 |
| daily_counts | {'AI/ML': 4} (3→4, +1 정확, cat_id 누설 0) |
| cat_id 누설 | ✅ 0건 |

## 차감/추가

- 차감: 없음
- 추가: 없음 — 모든 기존 패턴(§3.8.1 / §3.8.2 / §3.11 / §3.34.40 v2 / §3.34.43 / §3.34.46 / §3.34.47 / §3.34.48 / §3.34.49 / §3.34.50 / §3.34 #21 + §3.34.45 / cleanup cron 임무 #16) 정상 동작. 271차 식별 splice backfill 가이드가 다음 차 cleanup cron 임무 #30으로 영구화 권장.
