# 알려진 Tistory 카테고리 ID (203차 검증)

Tistory `category.json` API는 블로그마다 고유 ID를 반환한다. `sigco.tistory.com` 블로그에서 자주 쓰이는 카테고리 ID:

| 카테고리 이름 | ID | 매핑 이름 | 검증 차수 | 용도 |
|---------|-----|---------|----------|------|
| AI 뉴스 | **1219746** | AI/ML | 158, 159, 160, 203차 | AI 관련 주제 |
| 개발 팁 | 1219747 | — | 203차 | 개발 팁 (미사용) |
| **자동화&툴 리뷰** | **1219748** | **개발도구** | **203차 신규** | **도구/오픈소스 리뷰** |
| 투자&경제 | 1219750 | — | 203차 | 투자/경제 (미사용) |
| 기타 | 1219751 | — | 203차 | 기타 (fallback) |
| 아이디어 | 1219752 | — | 203차 | 아이디어 (미사용) |

## 발행 시 카테고리 결정 절차

1. `blog_pipeline.py` JSON 출력의 `tistory_category_id` 필드 사용 (자동으로 카테고리 매핑됨)
2. 기본값 0이면 `--categories` 인자로 목록 조회 후 적절한 ID 선택
3. ID 0은 거부되므로 (`--category는 필수입니다` 에러) 반드시 유효 ID 입력

## ⚠️ `--category` int 함정 (203차 신규)

`tistory_publisher.py --category` argparse는 **int만 받는다**. 카테고리 **이름**을 전달하면 즉시 거절:

```bash
# ❌ 거절됨
python3 ~/.hermes/scripts/tistory_publisher.py --file ... --category '개발도구' ...
tistory_publisher.py: error: argument --category: invalid int value: '개발도구'

# ✅ int ID로 전달
python3 ~/.hermes/scripts/tistory_publisher.py --file ... --category 1219748 ...
```

**모를 때 1회 조회**:
```bash
python3 ~/.hermes/scripts/tistory_publisher.py --categories
```

출력:
```
  [1219746] AI 뉴스
  [1219747] 개발 팁
  [1219748] 자동화&툴 리뷰
  [1219750] 투자&경제
  [1219751] 기타
  [1219752] 아이디어
```

## half-pipeline 패턴 (203차 확정)

```bash
# 1) 매핑 확인 (캐시 또는 수동)
python3 ~/.hermes/scripts/tistory_publisher.py --categories

# 2) --category <int_id>로 publish
python3 ~/.hermes/scripts/tistory_publisher.py --file <path> \
  --title "..." \
  --category 1219748 \
  --tags "..." \
  --image-query "..."
```

## Pitfalls

- `tistory_publisher.py`는 `--category`가 0이면 거절함. blog_pipeline의 `tistory_category_id`가 0이 아닌지 확인
- 카테고리 ID는 블로그마다 다름 (sigco.tistory.com 전용 ID). 다른 블로그 발행 시에는 그 블로그의 `category.json`에서 새로 조회
- 카테고리 ID가 변경되었을 수 있으므로 (Tistory 내부 정책), 가끔 1회 검증 필요. `blog_pipeline.py`의 `tistory_category_id`가 신뢰 가능한 최신 값
- **카테고리 이름은 신뢰 불가** (203차 함정) — 항상 int ID로 전달