# 203차 세션 노트 — Notion DB 직접 PATCH cleanup + 2건 발행 + `--category` int 함정

**날짜**: 2026-07-06 (화)
**시간**: 23:00 KST ~ 23:10 KST
**모드**: cron 자동화 (no user presence)
**결과**: ✅ #911 (AI/ML) + #912 (개발도구) 정상 발행 (drift 0)

## 타임라인

| 시각 | 단계 | 산출 |
|---|---|---|
| 23:00 | §3.8.1 3-endpoint probe | ✅ 200 OK 3/3 (Tistory top id=910) |
| 23:01 | `refresh-topics` | 12개 토픽 |
| 23:02 | Notion API 직접 조회 | 활성 12개 |
| 23:02 | 3중 dedup 실행 | AI/ML 6개 + 개발도구 2개 미발행 후보 (문제 발견!) |
| 23:03 | Notion PATCH cleanup (4건) | 31158/31169/31170/31173 비활성화 ✅ |
| 23:04 | 3중 dedup 재실행 | AI/ML 4개 + 개발도구 1개 |
| 23:05 | `blog_pipeline.py --category 'AI/ML'` | 31170 "덜한 것이 더 낫다" guidline |
| 23:06 | heredoc 본문 작성 (2,910자) | 12 H2, 2 Picsum images |
| 23:07 | `tistory_publisher.py --file` | **#911 발행** ✅ |
| 23:08 | §3.11 5단계 + §4 5-1 stats 보정 | stats 894→895, 4곳 sync |
| 23:08 | `blog_pipeline.py --category '개발도구'` 시도 | `--category '개발도구'` → **error: invalid int value** |
| 23:09 | `tistory_publisher.py --categories` 조회 | AI 뉴스=1219746, 개발 팁=1219747, **자동화&툴 리뷰=1219748** |
| 23:09 | `--category 1219748` 재시도 | **#912 발행** ✅ |
| 23:10 | §3.11 5단계 + §4 5-1 stats 보정 | stats 895→896, 4곳 sync |
| 23:10 | §3.5 3중 신호 검증 | Tistory /912 = state /912 = urls /912 ✅ |

## 핵심 발견 1 — Notion DB PATCH 직접 cleanup이 정상 작동 (영구화)

202차 권장 작업으로 남겨둔 "Notion DB 일괄 정리"를 203차에서 **직접 PATCH API 호출로 실행**했고 모두 200 OK로 성공.

**확정 패턴 (다음 cron부터 routine으로)**:
```python
import json, urllib.request, os
token = open(os.path.expanduser('~/.hermes/secrets/notion_token.txt')).read().strip()

# 1) 매핑 정의 (source URL → Tistory URL)
known_mappings = {
    'https://news.hada.io/topic?id=31173': 'https://sigco.tistory.com/909',
    'https://news.hada.io/topic?id=31169': 'https://sigco.tistory.com/910',
    'https://news.hada.io/topic?id=31158': 'https://sigco.tistory.com/906',
}

# 2) 활성 페이지 URL 매핑 조회
all_pages = []
cursor = None
while True:
    body = {'page_size': 100, 'filter': {'property':'상태','select':{'equals':'활성'}}}
    if cursor: body['start_cursor'] = cursor
    req = urllib.request.Request(
        'https://api.notion.com/v1/databases/34276f2e-9097-811e-ab69-f8759ecf0be7/query',
        data=json.dumps(body).encode('utf-8'),
        headers={'Authorization': f'Bearer {token}', 'Notion-Version':'2022-06-28', 'Content-Type':'application/json'},
        method='POST')
    with urllib.request.urlopen(req, timeout=20) as resp:
        data = json.loads(resp.read())
    for r in data['results']:
        url = r['properties'].get('URL', {}).get('url', '')
        if url: all_pages.append({'id': r['id'], 'url': url})
    if not data.get('has_more'): break
    cursor = data.get('next_cursor')

notion_lookup = {p['url']: p['id'] for p in all_pages}

# 3) 매칭되는 페이지 PATCH
for source_url, tistory_url in known_mappings.items():
    if source_url in notion_lookup:
        patch_body = {'properties': {
            '상태': {'select': {'name': '비활성'}},
            '마지막 사용일': {'date': {'start': '2026-07-06'}}
        }}
        req2 = urllib.request.Request(
            f'https://api.notion.com/v1/pages/{notion_lookup[source_url]}',
            data=json.dumps(patch_body).encode('utf-8'),
            headers={'Authorization': f'Bearer {token}', 'Notion-Version':'2022-06-28', 'Content-Type':'application/json'},
            method='PATCH')
        with urllib.request.urlopen(req2, timeout=15) as resp:
            print(f'✅ PATCH OK: {source_url}')
```

**203차 실행 결과**: 4/4 PATCH 성공 (31158/31169/31170/31173).

**영구화 결정**: 
- 위 패턴을 매 cron 진입 시 1회 실행 (3중 dedup 직전).
- `known_mappings`은 수동으로 유지 (자동화 안 함 — drift 감지용 의도적 수동 매핑).
- 또는 `update_notion_topic_last_used()` 함수를 blocking + raise로 패치 (장기 과제).

## 핵심 발견 2 — `tistory_publisher.py --category`는 int만 받음 (함정)

203차에서 `tistory_publisher.py --category '개발도구'` 호출 시:
```
tistory_publisher.py: error: argument --category: invalid int value: '개발도구'
```

**원인**: argparse type이 int. 카테고리 이름이 아닌 ID를 전달해야 함.

**해결**: `python3 ~/.hermes/scripts/tistory_publisher.py --categories`로 ID 목록 조회 후 int로 전달.

**203차 시점 sigco.tistory.com 카테고리 ID 매핑 (영구화)**:

| 카테고리 이름 | ID | 비고 |
|---|---|---|
| AI 뉴스 | **1219746** | 기존 알림 |
| 개발 팁 | 1219747 | 미사용 |
| **자동화&툴 리뷰** | **1219748** | `개발도구` 매핑 (203차 확정) |
| 기타 | 1219751 | — |
| 아이디어 | 1219752 | — |
| 투자&경제 | 1219750 | — |

**영구화 결정**: §3.18 half-pipeline 패턴의 `--category <id>` 단계에 `tistory_publisher.py --categories` 1회 조회 후 ID 매핑. **이름은 신뢰 불가**.

**half-pipeline 패턴 갱신**:
```bash
# 1) 카테고리 ID 매핑 조회 (1회)
python3 ~/.hermes/scripts/tistory_publisher.py --categories

# 2) --category <int_id>로 publish
python3 ~/.hermes/scripts/tistory_publisher.py --file <path> \
  --title "..." \
  --category 1219748 \      # ← int (이름 ❌)
  --tags "..." \
  --image-query "..."
```

## 핵심 발견 3 — title dedup이 substring match가 아님 (202차 §3.19 보강)

203차에서 31173 (Art Institute)이 **이미 #909로 발행됐음에도 3중 dedup을 통과함**. 

**원인**:
- `last_topics[-2]['title']` = "많이 조회되지 않은 콘텐츠 — Art Institute of Chicago API로 숨겨진 작품을 발견하는 법"
- Notion 풀 이름 = "많이 조회되지 않은 콘텐츠 — Art Institute..."
- 체크 코드: `if t['name'].lower() in last_titles` — 이건 **exact substring**이지 prefix match가 아님.
- Notion `이름` 필드는 풀 디스크립션 미포함 ("많이 조회되지 않은 콘텐츠"만), last_topics `title`은 풀 디스크립션 포함.
- 결과: **정확히 일치하지 않음 → dedup 미통과 → 잘못된 후보로 선정**.

**해결**: 202차 §3.19 패턴에 **4차 dedup 추가** (Notion 직접 비활성화):

```python
# 기존 3중 dedup 통과한 후보들
candidates = [...]

# 4차: Notion PATCH로 직접 비활성화 (영구화)
for source_url in to_deactivate:
    patch_notion_page(source_url)
```

또는 **title 정규화 함수** 추가:
```python
def normalize_title(t):
    """Notion과 last_topics의 제목 차이를 메우는 정규화"""
    # "—" 이후 제거, "..." 이후 제거, 앞뒤 공백 제거, 소문자
    t = t.split('—')[0].split('...')[0].strip().lower()
    return t

# 3차 dedup 정규화 비교
if normalize_title(t['name']) in {normalize_title(x) for x in last_titles}:
    continue
```

**203차 실전**: 정규화 함수 대신 Notion PATCH 직접 cleanup으로 해결 (4/4 성공). 다음 cron에서도 같은 패턴 적용 권장.

## §3.11 5단계 + §4 5-1 stats 보정 (203차 실행)

`references/post-publish-correct-recipe.md` 그대로 사용, 2회 실행:

**#911 발행 후**:
```
stats.total_published: 894 → 895
stats.by_category[AI/ML]: 701 → 702
stats.daily_counts["2026-07-06"][AI/ML]: 2 → 3
last_topics.append({title, url, category, published_at})
published_urls.txt append (https://sigco.tistory.com/911 + 제목)
published_topics.json append (hash)
```

**#912 발행 후**:
```
stats.total_published: 895 → 896
stats.by_category[개발도구]: 130 → 131
stats.daily_counts["2026-07-06"][개발도구]: 1 → 2
```

## §3.5 3중 신호 검증 (203차 통과)

```
① Tistory page1 top[0].id: 912
② state.last_topics[-1].url: https://sigco.tistory.com/912
③ published_urls.txt 마지막 Tistory URL id: 912
✅ PASS: 3-way sync, drift 0

누적 drift: stats.total_published(896) - Tistory.totalCount(773) = 123 (legacy, §3.16)
이번 세션 단일 drift: 2 - 2 = 0 ✅
```

## 신규 함정 — tab-separated `published_urls.txt` 비대칭 포맷

203차 검증 중 발견: 줄마다 trailing field 수가 다름.

**신규 줄 포맷 (202차부터)**:
```
https://sigco.tistory.com/911\t덜한 것이 더 낫다, 대체로...\n
https://sigco.tistory.com/908\t...\t2026-07-06\tAI/ML\n  ← category 컬럼 추가됨
https://simonwillison.net/...\n  ← 비-Tistory URL도 섞여있음
```

**영향**: `line.split('\t')` 후 인덱스 접근 시 `IndexError` 가능. 모든 파싱은 **첫 컬럼만** 사용하도록 강제:
```python
# ✅ 안전한 첫 컬럼 추출
url = line.split('\t')[0].strip()

# ❌ 위험
category = line.split('\t')[3]  # 일부 줄은 4개 필드, 일부는 1개
```

## 후속 권장 작업

### `update_notion_topic_last_used()` blocking 강화 (장기)
- fire-and-forget을 raise로 변경
- caller에서 try/except 명시 처리
- 203차 PATCH 패턴이 routine이 되기 전까지 안전망 필요

### `tistory_publisher.py --category` 인자 개선 (장기)
- argparse type을 `int`에서 `str_or_int`로 변경
- 카테고리 이름 입력 시 자동 ID 매핑
- 또는 alias 사전 (`{"AI/ML": 1219746, "개발도구": 1219748, ...}`)

### 누적 drift 123 별도 cron (203차 업데이트)
- §3.16 권장 작업 그대로 유효
- 203차 종료 시점: stats 896 vs Tistory totalCount 773, drift 123
- 이번 세션 단일 drift는 0

## 환경 / 설정 메모

- 203차 시점 Notion API token 길이 50자 (정상)
- Tistory API 정상 (max id 912, totalCount 773)
- published_urls.txt ~363개 URL
- 마지막 발행 시각 2026-07-06T23:09:30 KST

## 다음 세션이 봐야 할 것

- §3.20 Notion PATCH 직접 cleanup 패턴 (cron routine으로 격상)
- §3.20 `--category` int 함정 (영구화)
- §3.20 `published_urls.txt` 비대칭 tab 포맷 (첫 컬럼만 파싱)
- 누적 drift 123 별도 cron (legacy 정리)