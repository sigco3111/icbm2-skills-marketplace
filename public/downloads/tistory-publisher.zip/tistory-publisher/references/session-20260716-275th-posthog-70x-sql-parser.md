---
session_id: 275th-posthog-70x-sql-parser
date: 2026-07-16
topic_id: 31457
entry_id: 1020
category: 개발도구 (1219748)
gn_topic_id: 31457
score: 7.0
result: ✅ green-run (publish 성공 + sync 성공 + 라이브 페이지 확인)
all_green_streak: 62 (213~275차)
status: clean-confirm
---

# 275차 세션 노트 — PostHog 70x SQL 파서 (`#1020`)

## 발행 결과

- **entry_id**: `#1020` (https://sigco.tistory.com/1020)
- **제목**: PostHog가 코드를 거의 보지 않고 70배 빠른 SQL 파서를 만든 법 — ANTLR을 재귀 하강으로 갈아끼울 때의 검증 패턴
- **카테고리**: 개발도구 (1219748, label "자동화&툴 리뷰")
- **본문 평문 길이**: 5177자 (300자 가드 통과)
- **이미지**: 2장 CDN 업로드 (Picsum ID 654, 동일 ID 매칭)
- **라이브 페이지 GET**: status=200, size=74363, entryId:1020 일치

## 워크플로

1. **§3.8.1 가드**: status=200, ct=application/json;charset=UTF-8, cookie_count=8 → ✅ OK 세션 유효
2. **FRESH 4-field 매칭 (v2)**: TOP 12개 중 §3.34.40 v2 + `pt.last.gn_topic_id` guard 적용 → AI/ML 후보 8개 모두 PUB, FRESH 잔여 3개 (개발팁 31457 + 개발도구 31447/31464)
3. **§3.34 #21 + #22 + #45 매트릭스**: FRESH 모두 비-AI/ML 비-기타 → §3.34.45 5번째 분기 "점수 1순위 픽" → 31457 (7점)
4. **§3.34.46 영구화**: `_try_md_endpoint(31457)` → status=200, 5795 bytes 즉시 fetch
5. **§3.34.47 격리 빌드**: `/tmp/tistory_drafts_275th/build_draft_31457.py` 5972 bytes UTF-8 + 격리 호출
6. **§3.34.50 Topic Body 본문 추출 3회째**: 평문 5177자 정상 (260차 정착 "## Metadata skip" 함정 회피)
7. **publish**: tistory_publisher.py --file --source-url --gn-topic-id --image-query
8. **§3.5 5중 신호**: publish 후 5중 검증 → 모두 #1019로 drift (publish 직후 sync 미실시 상태 확인)
9. **§3.11 sync**: post_publish_sync.py sync → pt_updated: true, state_updated: true, errors: []
10. **§3.5 5중 신호 재검증**: 모두 #1020 일치 (all_match: True)
11. **cleanup cron 임무 #16 dry-run**: ✅ 누설 없음 (61→62회 연속 all-green)

## §3.34 #21 정책 실전 7호 검증

- 255차 1호 (FRESH AI/ML 1 + 기타 2 → AI/ML 픽)
- 266차 2호 (FRESH 모두 비-기타 비-AI/ML → 점수 1순위)
- 268차 3호 (FRESH 2개 모두 비-기타 비-AI/ML → 점수 1순위)
- 269차 4호 (FRESH 1개 단독 비-기타 비-AI/ML → 점수 1순위)
- 270차 5호 (FRESH 다수 AI/ML + 비-AI/ML 혼재 → AI/ML 점수 1순위)
- 271차 6호 (FRESH 다수 AI/ML + 비-AI/ML 혼재 → AI/ML 점수 1순위)
- **275차 7호 (FRESH 3개 모두 비-AI/ML 비-기타 → 점수 1순위 픽)**

§3.34.45 매트릭스 5번째 분기 정상 동작 누적 검증.

## §3.34.50 Topic Body 본문 추출 실전 3호 검증

- 272차 식별 (31443 AI 혐오 본문 → Topic Body 마커 패턴 정착)
- 274차 1회 실전 검증 (31451 바벨탑)
- **275차 2회 실전 검증 (31457 PostHog SQL)** — 3회째

31457 본문은 `- PostHog는 ANTLR...` 으로 시작하나 Topic Body 마커 기반 추출이 정확히 잡아냄. 260차 정착 "## Metadata skip" 로직의 본문 bullet 오인 함정이 안전하게 회피됨.

## 신규 발견

**0건** — 274차 정착 패턴 (§3.34.50 Topic Body, §3.34.51 splice backfill 가드, §3.34.46 영구화, §3.34.47 격리 빌드, §3.34.48 `*` 분기, §3.34 #21 정책 + §3.34.45 매트릭스, §3.11 sync, §3.5 5중 검증, cleanup #16) 모두 275차에 정상 동작.

## 영구화 패치 후보 (다음 차에 권장)

1. `scripts/gn-fetch-content.py` 본문 추출 함수를 Topic Body 마커 기반으로 정정 (cleanup cron 임무 #31)
2. `scripts/cleanup-pt-details-splice.py` 신규 모듈로 historical splice 자동 보정 (cleanup cron 임무 #30)

## 일일 통계

- daily_counts[2026-07-16] = `{'AI/ML': 4, '개발도구': 1}` (개발도구 0→1, +1 정확, cat_id 누설 0)
- state.details 97→98, pt.details 112→113