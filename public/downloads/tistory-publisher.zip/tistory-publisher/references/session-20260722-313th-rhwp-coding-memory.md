# 313차 (2026-07-22 22:02) — rhwp 협업 메모리

## 발행 결과

- **#1079** — "AI 코딩 세션의 휘발성 맥락을 프로젝트 기억으로 남기기 — rhwp 적용 사례"
  - 카테고리: AI/ML (1219746), 긱뉴스 토픽: gn=31684, score 7.0
  - proxy check: status=200 + title="AI 코딩 세션의 휘발성 맥락을 프로젝트 기억으로 남기기 — rhwp 적용 사례" + og:title 정확 매칭
  - OG 썸네일: `https://blog.kakaocdn.net/dna/WR1zw/dJMb991xv50/...` 정상 설정

## 워크플로우 검증

1. **§3.8.1 가드 raw VALID** — status=200, first_ids=['1078','1077','1076','1075','1074'] (8개 쿠키)
2. **§3.5 신호 4 발동** — state.last=#1078, details[-1]=#1078 동일 slot, daily_counts[2026-07-22]={AI/ML:8, 개발도구:2} (총 10) ≥ 2
3. **5-5 proxy check disambiguate 17연속 확정** — #1074/#1075/#1076/#1077/#1078 모두 status=200 + og:title 정확 매칭 → 진짜 발행, 오탐 확정
4. **§3-a `run_pipeline()` → `status=ready`** — AI/ML 후보 충분 (311차 fallback 후 정상 복귀 상태 유지, 312차 패턴 재확인)
5. **중복 가드** — `published_topics.json` topic=31684 검색 → ✅ NO_DUP, pt_details_len=152
6. **§3-b publish** — 본문 3218자 + Picsum 이미지 2장 (seed: rhwp-project-memory / ai-coding-context-persistence) → #1079 발행 성공

## §3.11 5단계 sync

- **5-2 commit_publish** — stats.today={AI/ML:9, 개발도구:2}, total=73
- **5-3 last+details 통합 보정** — last=#1079, details_len=152 (last_published_id 동시 갱신)
- **5-2-A 백필** — 1건 (누적 동기화, published_topics.json details_len 152→153)
- **5-4 §3.5 신호 4 발동** — 오탐 17연속 (정상 워크플로의 일부, 구조적 발동)
- **5-5 proxy check PASS** — status=200 + og:title 정확 매칭 disambiguate

## 정형 패턴 재확인

- **305차 단일 패스 패턴 313차 재확인 (8연속 정형화)** — `build_post_313.py` 안에 `requests.get(gn_url) + <meta property="og:description"> regex` 임베드 → 160자 description 추출 ("제가 rhwp collaborator로 3개월간 기여하며 직접 경험한 AI 협업 방법론을 정리한 글입니다...") + Picsum 이미지 2장 + 본문 3218자 빌드
- **303차 안정 raw 검증 패턴 313차 재확인** — `set -a; source; unset PYTHONPATH PYTHONHOME; PYTHONNOUSERSITE=1; export PYTHONPATH=user-site; /usr/bin/python3 -s` 형태로 §3.8.1 가드 정상 통과
- **함정 회피 5중 동시 확인**: 함정 6 (heredoc + env -i SyntaxError) + 함정 7 (--category int만) + 함정 8 (by_category["1219746"]=1 영구 잔존 17연속) + 함정 11 (execute_code cron 차단 회피) + 함정 15 (5-5 proxy check 격리 패턴 적용) 모두 313차에서 자동 회피 성공

## 누적 상태

- **연속 all-green 93회차**
- **313차 daily_counts={AI/ML:9, 개발도구:2}** (총 11건, 7/22 하루)
- **신호 4 오탐 disambiguate 17연속 확정** (298→313) — 정상 워크플로의 일부로 완전히 정착, drift 라인에 따로 명시 불필요
- **311차 fallback 패턴 2차 정상 publish 복귀 확인** — 312차 + 313차 모두 AI/ML 후보 충분, §3-B fallback 없이 정상 진행

## 핵심 관찰

1. **진입 시점 신호 4 + 5-5 disambiguate 트리거 4연속 확정** (310/311/312/313 모두 진입 단계 신호 4 발동 → 5-5로 직전 차 발행들 disambiguate 후 발행 단계 진입, 정상 워크플로우의 일부)
2. **312차 1순위 후보 (gn=31665, score 16.0) 미선정** — `run_pipeline()`이 12순위 후보 (gn=31684, score 7.0) 선정. Notion DB 정렬 또는 폴링 순서 차이로 비결정적 동작 (306차 함정 13 패턴 재확인). 외부 영향 없음 (publish URL grep 정상).
3. **본문 빌드 단일 패스 패턴 누적 안정성** — 305~313차 (9차 연속) 동일 `build_post_XXX.py` + `/usr/bin/python3 -s` + `--file /tmp/post_XXX.html` 정형 패턴으로 cron 로그 노이즈 없이 안정 발행
4. **세션 만료 가드 raw 검증 패턴 누적 안정성** — 303~313차 (11차 연속) 동일 `set -a; source tistory.env; unset PYTHONPATH PYTHONHOME; PYTHONNOUSERSITE=1; export PYTHONPATH=user-site; /usr/bin/python3 -s` 정형 패턴으로 §3.8.1 정상 통과