# 352차 — 티스토리 쿠키 수동 회수 + 즉시 cron 트리거 워크플로우

**날짜**: 2026-08-03 06:53–07:01 KST
**세션 컨텍스트**: cookie 만료 후 자동화 cron `b1bca63a117a` 가 0건 발행 → 사용자 발화 "쿠키 만료" → 회수 → 사용자 발화 "어제 오늘 못 올린 거 발행" → 즉시 트리거 1회 → 352차 #1174 정상 발행 (AI/ML, gn=32060, 본문 2,039자 / 빌드 4,756B + Picsum 2 + Python 1).

상위 스킬 본문: SKILL.md §3.8.2 (쿠키 수동 회수) + §3.0.1 (즉시 트리거 모드) 참조.

---

## 1. 트리거 — 이 노트를 여는 신호

| 신호 | 진단 |
|---|---|
| `verify-tistory-cookie.sh` 의 `[5] --check-session` FAIL | `Expecting value: line 2 column 2` = 302 → /auth/login zombie |
| `state.json` 또는 `blog_pipeline_state.json` daily_counts[오늘] = 0 (정상이면 6~12) | 자동화 cron이 가드에서 멈춤 |
| `0b0e9f44e10a` (07:00 일일 쿠키 체크) cron output에 FAIL 라인 | 아침 무렵 자동 감지 |
| 사용자가 "Tistory 발행 안 돼", "쿠키 만료", "트래픽 0" 같은 발화 | 즉시 §3.8.2 진입 |

단순히 "쿠키 만들어줘" 사용자 발화는 §3.8.2 정형 절차로 분기. 자동화 skip 잔재 (어제 N건 / 오늘 0건) 확인 후 "지금 1~2건 발행해줘" 발화는 §3.0.1 + §3.8.2 결합.

## 2. 6개 절대 규칙 (쿠키 회수 시)

Subagent 격리 갱신 시 위반하면 즉시 작업 중지 + 보고. 본문에서 검증됨.

1. **다른 값 절대 건드리지 마라.** `TISTORY_BLOG_NAME=sigco`, `TISTORY_BLOG_ID=8158930`, `TISTORY_BLOG_URL=https://sigco.tistory.com` 이 3개는 헷갈리면 두지 말고 그대로.
2. **백업 필수.** 작업 전 기존 `tistory.env`를 `tistory.env.bak.YYYYMMDD_HHMMSS` 로 복사. 형식은 기존 백업과 동일 (예: `tistory.env.bak.20260803_065342`).
3. **주석 라인 갱신.** `# 마지막 갱신: 2026-07-26 17:13 KST (322차 수동 갱신 — ...)` 형식 유지. 새 내용: 현재 시각 KST + "324차 쿠키 교체" 같은 기억표시.
4. **파일 끝 newline 보장.** 마지막 값 뒤에 newline 하나 없는 경우 lint 단계에서 누락 감지.
5. **diff로 5개 라인만 다른지 검증.** REACTION_GUEST / `__T_` / `__T_SECURE` 가 이전과 같은 값일 수 있고 (가짜 변경 아님, 정상), TSSESSION + `_T_ANO` 만 바뀌는 게 보통. BLOG_* 3개는 항상 동일.
6. **FAIL 시 자가 회복 시도 금지.** 어떤 단계에서 어떤 메시지로 실패했는지 그대로 부모에게 보고.

## 3. Subagent 격리 갱신 패턴

직접 `write_file`로 `tistory.env` 만지지 말고 subagent에 위임하는 이유:

- 컨텍스트 보호: `tistory.env` 본문은 1263B, 5개 쿠키값이 평문. 본 세션 컨텍스트에 들어오면 부담.
- 검증 자동화: 백업 → 갱신 → verify-tistory-cookie.sh → diff 4단계를 한 번에 묶어서 실행.
- 6개 규칙 강제: 부모가 "변경했다" 만 보고하는 거 의존하지 않고, subagent가 단계별 exit code + 마지막 5줄 보고.

### 부모 → subagent context 템플릿

```text
## 작업: Tistory 쿠키 5개 교체 + 검증

희정님이 sigco.tistory.com 브라우저 세션에서 추출한 새 쿠키 5개로
`~/.hermes/secrets/tistory.env` 교체 작업. macOS, bash.

## 새 쿠키 5개 (사용자 제공값)
REACTION_GUEST=<40자 hex>
__T_=1
__T_SECURE=1
TSSESSION=<40자 hex>
_T_ANO=<base64 ~344자>

## 6개 절대 규칙
1. BLOG_NAME=sigco, BLOG_ID=8158930, BLOG_URL 절대 불변
2. 백업: cp -p ~/.hermes/secrets/tistory.env ~/.hermes/secrets/tistory.env.bak.$TS
3. # 마지막 갱신: ... 주석을 새 시각 + 차수 표기로 갱신
4. 파일 맨 끝 newline 보장
5. 다른 패키지/스크립트 실행 금지
6. FAIL 시 자가 회복 시도 금지 — 무엇이 실패했는지만 보고

## 4단계 실행
1. 백업 (TS=$(date +%Y%m%d_%H%M%S)) + ls -la 확인
2. env 갱신 — wc -l로 백업/신규 라인 수 일치 확인
3. bash ~/.hermes/skills/automation/tistory-publisher/scripts/verify-tistory-cookie.sh
   기대: RESULT: PASS=13 FAIL=0 WARN=0, [5] "세션 유효 (총 NNN개 글)"
4. diff ~/.hermes/secrets/tistory.env ~/.hermes/secrets/tistory.env.bak.$TS
   기대: 5개 쿠키 라인만 차이 (BLOG_* 3개 동일)

## 보고 형식
- 백업 절대경로
- 1단계 exit code
- 2단계 cat 마지막 5줄
- 3단계 RESULT + [5] 라인
- 4단계 diff (5개 쿠키만 다른지)
- FAIL 있으면 그대로 보고
```

## 4. 즉시 트리거 패턴 (cron run)

자동화 cron `b1bca63a117a` (Tistory 자동 발행 (SEO+트렌드)) — schedule `0 19,20,21,22,23,0,1,2,3,4,5,6 * * *` (오후 7시 ~ 오전 6시 매시). 사용자가 "지금 발행해줘" 요청 시:

```bash
# 1) job_id 확인 (cronjob list)
# 2) 즉시 run
# cronjob(action='run', job_id='b1bca63a117a')
# 3) 응답: executed=true, execution_success=true, last_run_at 갱신
# 4) 출력 파일 정착점 (보통 30~90초 후):
#    ~/.hermes/cron/output/<job_id>/<YYYY-MM-DD_HH-MM-SS>.md
# 5) read_file로 그 파일을 읽어서 결과 추출
```

### ⚠️ attach_to_session 안 쓰는 이유

- `attach_to_session=True` 로 보내면 결과가 부모 세션의 /content 로 들어옴
- 단 attach 안 해도 부모가 직접 `~/.hermes/cron/output/<job_id>/<timestamp>.md` 를 read_file로 읽으면 같은 효과
- 폼 목록에서 `attach_to_session` 비추: 본 세션은 "지금 한 번만" 패턴이고, recurring 으로 만들 의도가 없음

### 결과 파일 read_file로 픽업

```text
# 예: 352차 결과 파일
/Users/mac/.hermes/cron/output/b1bca63a117a/2026-08-03_07-01-22.md

# 헤더 (line 1~30) / 푸터 (마지막 5~10줄) 가 핵심
# SKILL.md 본문이 100KB+ 이므로 중간 본문 (skill 자격증명) 은 무시
# Response 섹션 (마지막 1~3줄) 만 보면:
#   - 발행 #NNN URL
#   - 카테고리 (AI/ML 등)
#   - stats (daily_counts, total)
#   - all-green 연속 차수
```

## 5. 352차 실행 결과

| 항목 | 값 |
|---|---|
| 백업 | `/Users/mac/.hermes/secrets/tistory.env.bak.20260803_065342` (1179B) |
| 검증 | RESULT: PASS=13 FAIL=0 WARN=0, [5] "세션 유효 (총 1036개 글)" |
| 즉시 트리거 | 07:01:22 publish complete → #1174 "Flint - AI 시대를 위한 시각화 언어" |
| state.json | daily_counts[8/3]={AI/ML:1}, total=165 |
| 연속 all-green | 126회차 |
| 백업 3개 누적 | 20260726_171301 (322차), 20260803_065342 (352차) + 1 |

## 6. 만료 추적 (헤더 주석 패턴)

```text
# 마지막 갱신: 2026-08-03 06:53 KST (352차 수동 갱신)
# 만료 추적: 184차(6/29) → 196차(7/2, 3일) → 7/6(8일) → 319차(7/24, 18일)
#           → 320차 zombie 302(7/26, 36시간) → 322차 수동 회복(7/26) → 352차(8/3, 8일)
# 다음 만료 가설: 8일 패턴 안정화 — 다음 8/11 만료 가능성 큼
```

8일 패턴 안정화 추세. 7/24 18일 → 7/26 36시간(zombie) → 8/3 8일. 자동화 cron `0b0e9f44e10a` (07:00 일일 쿠키 체크)가 매 아침 자동 감지.

## 7. 다음 회차에 대한 권장

- **발행 누락 자동 복구**: "어제 N건 / 오늘 0건" 패턴에서, daily_counts 차이를 자동 산출해서 다음 cron에서 자동 fallback 발행하면 더 좋음. 단 **가짜 발행 방지**가 최우선이므로 한 곳에서만 헬퍼 결정.
- **쿠키 만료 가설 검증**: 8일 패턴이 3~4회 더 반복되면 (≈ 8/24까지) 가설 확정. 그때까지 8/3, 8/11, 8/19, 8/24 4회 데이터.
- **즉시 트리거 카운터**: 사용자가 "지금 발행" 발화 시 카운트해서 monthly report에 반영. 자동화 cron에 의한 발행과 구분.

---

**관련 세션 노트**:
- 351차: `references/session-20260801-351st-google-gemini-chrome-bugfix.md` — `#1171` 발행 + CJK swap 정형
- 322차: `references/tistory-publisher-session-20260726-322nd-cookie-resume.md` (존재 시) — zombie 302 회복
- 320차: zombie 302 패턴 첫 노출

**관련 함정** (SKILL.md 본문):
- §3.8.1 세션 만료 가드
- §3.7.4 (336차) parts.append() + code_lines 분리
- §3.11 5단계 sync (5-2-A published_topics 백필, 5-3 state.json last 갱신)
- §3.5 3중 신호 검증 (1 state.last_published_url, 2 daily_counts[오늘], 3 last_topics[-1])
