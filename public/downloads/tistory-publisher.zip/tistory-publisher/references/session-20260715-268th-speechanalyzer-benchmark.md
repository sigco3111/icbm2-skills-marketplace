# 268차 (2026-07-15) — `#1007 Apple SpeechAnalyzer API, Whisper·이전 API와 비교 벤치마크`

> 한 줄 요약: §3.34 #22 시나리오 (FRESH = 'AI/ML 외 비-기타' 카테고리 + 점수 1순위 픽) 실전 3호. §3.34.46 + §3.34.47 + §3.34.48 모두 5회째 적용 — 신규 발견 0건. **실행 환경 추가**: `execute_code` 가 cron 컨텍스트에서 subprocess 격리 호출도 차단 — `terminal`+heredoc 단독 사용 정착.

## 발행 결과

- **글**: `#1007 Apple SpeechAnalyzer API, Whisper·이전 API와 비교 벤치마크 — M2 Pro 온디바이스 WER 2.12%로 Whisper Small을 1.7배 앞서다`
- **URL**: https://sigco.tistory.com/1007
- **cat_id**: 1219747 (개발팁)
- **gn_topic_id**: 31408
- **score**: 6.0 (TOP 12개 후보 중 9개 이미 258~267차 처리 → FRESH 3개: 31408 개발팁 6점 / 31434 투자/경제 5점 / 31417 개발도구 4점)
- **연속 all-green**: 55회차 (213~268차)
- **cleanup cron 임무 #16**: 55회 연속 all-green

## 워크플로

1. §3.8.1 가드: `status=200, ct=application/json;charset=UTF-8, cookie_count=8` ✅
2. §3.34.40 FRESH 4-field 매칭: 후보 12개 중 ALREADY 9개 + FRESH 3개 (개발팁 31408 + 투자/경제 31434 + 개발도구 31417)
3. **§3.34 #22 시나리오 실전 3호 (§3.34.45 매트릭스 5번 분기)**: FRESH 후보 = 'AI/ML 0개' + 'AI/ML 외 비-기타 3개' → 점수 1순위 비-기타 카테고리 픽 (31408 6점 개발팁)
4. §3.34.46 영구화: `fetch_gn_content(31408)` → status=200, **8449 bytes** 1단계 `.md` endpoint 즉시 fetch (public API)
5. §3.34.47 격리 빌드: `write_file`로 `/tmp/tistory_drafts_268th/build_draft.py` UTF-8 선언 저장 → `python3 <script>.py` 격리 호출 정상 (md_to_html 본문 5975자 + intro 880 + conclusion 1020 + UTF-8 한글 + 4단계 헤더 강등 정규식 모두 무영향)
6. §3.34.48 `* ` 분기: 268차 본문은 모두 `- ` 패턴이라 hit 안 했지만 266차 정착 분기 + 4단계 헤더 강등 정규식 그대로 코드에 포함 (안전 가드)
7. 빌드: 본문 7360자 (intro 880 + body 5460 검출 + conclusion 1020 + 원문 링크, 300자 가드 통과)
8. §3.5 5중 신호 사전 검증: 모두 `#1006` 일치 → publish 진행
9. publish: `tistory_publisher.py --title ... --category 1219747 --file ... --source-url "https://news.hada.io/topic?id=31408" --gn-topic-id 31408 --image-query "speech recognition waveform apple silicon mac on-device"`
   - 결과: Picsum CDN 2장 업로드 성공 (ID 966, 105KB × 2)
   - publish URL: `https://sigco.tistory.com/1007`
10. post_publish_sync: `pt_updated: true / state_updated: true / errors: [] / triple_signal_match: true`
11. §3.5 5중 신호 사후 검증: 5/5 모두 `https://sigco.tistory.com/1007` 일치
12. daily_counts[2026-07-15]: `{'AI/ML': 1, '개발도구': 2, '개발팁': 1}` (개발팁 0→1, +1 정확, cat_id 누설 0)
13. state.details 83→84, pt.details 99→100 (+1 정확)
14. cleanup cron 임무 #16 dry-run: `✅ 누설 없음` (54→55회 연속)
15. 라이브 페이지 GET: `status=200, body=63063 bytes, title tag='Apple SpeechAnalyzer ...'` (실제 발행 확인)

## 본문 빌드 스크립트 핵심

- 266차 정착 `md_to_html` 4종 패턴(헤더/리스트/bold) + §3.34.48 `* ` 분기 + 4단계 헤더 강등 정규식
- editorial 인트로 2단락 (한국 독자층 + M2 Pro 온디바이스 WER 컨텍스트 + 1.7배 우위 비교) + 결론 2단락 (한국 iOS·macOS 개발자 시사점 + Inscribe 멀티 엔진 표준 아키텍처)
- 4단계 헤더 강등이 268차 본문에는 hit 안 했지만 정규식 자체는 266차 정착 패턴 그대로 적용 (안전 가드)
- `* ` 분기도 268차 본문(31408)에서 hit 안 함 (모두 `- ` 패턴) — 그러나 266차 정착 분기 그대로 코드에 포함

## §3.34.46 정규화 패턴 (268차 적용)

31408 본문은 다음 패턴을 가짐:

```
## Metadata
- GeekNews HTML: [...]
- GeekNews Markdown: [...]

## Topic Body
- Apple M2 Pro에서...
- 기존 **SFSpeechRecognizer**의 WER는...
...
```

→ 정규화: `## Metadata` 섹션의 `- key: value` 라인 모두 제거 + `## Topic Body` 헤더 제거 + Description blockquote 제거

→ 변환 결과: 깔끔한 HTML (h3/list/p 만)

## 신규 발견

- **본 세션 신규 패턴 발견 0건** — 267차 정착 패턴(`* ` 분기, 4단계 헤더 강등) + 263차 정착 §3.34.47 격리 빌드 모두 5회째 정상 동작
- **268차 관찰 (사소, 정찰 동작 변경 없음)**: `execute_code` 가 cron 컨텍스트에서 `subprocess.run(['env', '-i', ...])` 호출도 차단 — `BLOCKED: execute_code runs arbitrary local Python (including subprocess calls that bypass shell-string approval checks)` 메시지로 거부. 이는 §3.34.40에 이미 영구화된 함정과 동일 ("❌ execute_code cron 호출 ... → terminal+heredoc 또는 write_file 후 tistory_publisher.py --file 호출"). 268차 첫 가드 호출 시 hit → 즉시 write_file + terminal 로 우회하여 정상 진행. 코드 패치 불필요.
- 268차 = 267차와 동일 워크플로 정착 — 264차 `#1000` → 265차 `#1002` → 266차 `#1003` → 267차 `#1004` → 268차 `#1007` 5회 연속

## 차감/추가

- 없음. 모든 기존 패턴 정상 동작.

## 운영 가이드 (268차)

- 268차는 §3.34.45 매트릭스의 **5번째 분기** (`FRESH 모두 'AI/ML 외 비-기타' → 점수 1순위 픽`) 실전 3호 — 266차 Papermake (11점 개발도구) → 268차 SpeechAnalyzer (6점 개발팁)
- `md_to_html` 은 §3.34.46 + §3.34.48 박스 코드를 그대로 복사해서 `build_draft.py`에 포함
- `gn-fetch-content.py` 의 public API `fetch_gn_content(tid)` 또는 `_try_md_endpoint(tid)` 직접 호출 — 임시 우회 heredoc 불필요
- `execute_code` 호출은 cron 컨텍스트에서 완전 차단되므로 §3.34.40의 "❌ execute_code cron 호출" 박스 그대로 적용 — terminal + heredoc 또는 write_file + tistory_publisher.py 단독 사용

## 다음 차 권장

- 269차에 FRESH 후보에 '기타' 카테고리가 하나라도 포함되면 → §3.34.45 매트릭스 2번 분기 (`'기타' + 'AI/ML' 혼재 → AI/ML 픽`)
- 269차에 FRESH 후보 모두 '기타' → 정상 skip (256차 #22 시나리오)
- 269차에 AI/ML FRESH 후보 1개 이상 → §3.34 #21 정책 그대로 AI/ML 픽
- 모든 §3.34.46 + §3.34.47 + §3.34.48 박스 코드 그대로 재사용 (코드 패치 불필요)
