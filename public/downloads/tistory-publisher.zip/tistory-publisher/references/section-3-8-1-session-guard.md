# §3.8.1 세션 만료 가드 — 세션 쿠키 만료 감지 + 안전 skip

## 목적

Tistory 쿠키가 만료되어 `/manage/posts.json` endpoint가 302 redirect to `/auth/login`으로 떨어지는 케이스를 publish 직전에 감지. **만료 상태에서는 publish 단계를 절대 진행하지 않는다** — 통계(daily_counts)만 +1 되고 실제 글은 박히지 않는 "가짜 발행" 누적을 차단하는 1차 방어선.

## 발동 트리거

- 매 cron 차시 publish 직전 1회 (1단계)
- 가짜 발행 의심 보고를 받은 직후 (수동 재검증)

## 검증된 가드 코드 (288차 검증, status=302 + ct=None + loc=/auth/login)

```bash
unset PYTHONPATH
set -a; source ~/.hermes/secrets/tistory.env; set +a
env -i HOME="$HOME" PATH=/usr/bin:/bin PYTHONPATH= \
  /usr/bin/python3 << 'PYEOF'
import os, requests
cookies = {k.replace('TISTORY_',''): os.environ[k] for k in os.environ if k.startswith('TISTORY_')}
hdr = {'User-Agent':'Mozilla/5.0','Referer':'https://sigco.tistory.com/manage/','X-Requested-With':'XMLHttpRequest'}
r = requests.get('https://sigco.tistory.com/manage/posts.json?category=-3&page=1',
                cookies=cookies, headers=hdr, timeout=10, allow_redirects=False)
if r.status_code == 302 and '/auth/login' in r.headers.get('location',''):
    print('⏸️ SKIP: §3.8.1 세션 만료 (302 → /auth/login). 브라우저 쿠키 갱신 필요.')
elif r.status_code == 200 and 'application/json' in r.headers.get('content-type',''):
    print('✅ OK: 세션 유효, 발행 진행')
else:
    print(f'⏸️ SKIP: 알 수 없는 만료 패턴 status={r.status_code}')
PYEOF
```

## ⚠️ 핵심 함정: Hermes venv의 PYTHONPATH 누설 (288차 신규 발견)

`/usr/bin/python3`은 시스템 Python 3.9 (Xcode 번들) + 자체 site-packages에 requests 2.32.5가 설치되어 있어 정상 동작. 그런데 Hermes venv(`/Users/mac/.hermes/hermes-agent/venv`)에는 Python 3.11용 urllib3가 들어있는데 **이 venv가 `PYTHONPATH`로 노출되면 시스템 python3의 import까지 깨진다**.

증상:
```
File ".../urllib3/_base_connection.py", line 10, in <module>
    bytes, typing.IO[typing.Any], typing.Iterable[bytes | str], str
TypeError: unsupported operand type(s) for |: 'type' and 'type'
```

원인: Python 3.11의 PEP 604 union syntax (`X | Y`)를 3.9가 못 읽음. venv의 urllib3가 더 먼저 import되어 시스템 site-packages를 가림.

**해결: 격자 실행 (verify된 표준 패턴)**
```bash
unset PYTHONPATH
env -i HOME="$HOME" PATH=/usr/bin:/bin PYTHONPATH= /usr/bin/python3 <script>
```

`env -i`로 모든 환경변수 제거 후 HOME/PATH/PYTHONPATH만 명시 — venv 누설 0. NotOpenSSLWarning (LibreSSL vs OpenSSL 1.1.1) 한 줄은 뜨지만 동작에는 영향 없음.

## 가드 출력 의미

| 출력 | 의미 | 다음 행동 |
|------|------|----------|
| `✅ OK: 세션 유효, 발행 진행` | status=200 + ct=application/json | 2단계(trend refresh) 진행 |
| `⏸️ SKIP: §3.8.1 세션 만료` | status=302 + loc=/auth/login | publish skip, §3.5 검증만 실행, 종료 |
| `⏸️ SKIP: 알 수 없는 만료 패턴 status=N` | 그 외 모든 케이스 | publish skip, 안전 우선, 종료 |

## 가드 통과 후 보강

세션 가드 통과시에도 publish 자체에서 또 302가 떨어질 수 있음 (race). 따라서 `tistory_publisher.py publish_post()`의 return code도 확인해야 함 — status 200 + URL 포함이 정상 종료 신호.

## 갱신 정책

세션 만료 시: 사용자에게 브라우저에서 Tistory 재로그인 안내. 쿠키 자동 갱신 메커니즘은 없음 (수동).