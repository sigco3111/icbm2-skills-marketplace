# 186차 — `tistory_publisher.py --record-topic` is NOT record-only (2026-06-29)

> §3.12 신규 함정의 실세션 검증 노트. 185차에서 잘못 안내한 "record-topic 으로 사후 record" 워크플로가 실제로는 동작하지 않음을 확인하고 우회 패턴 확립.

## 세션 컨텍스트

- **시점**: 2026-06-29 20:00 (cron 자동 발행 트리거)
- **대상 주제**: "GTM을 위한 AI가 성과를 내지 못한 이유 (그리고 해결 방법)"
- **출처**: https://news.hada.io/topic?id=30924
- **카테고리**: AI/ML (ID 1219746)
- **결과**: https://sigco.tistory.com/871 발행 성공

## 시퀀스 (실제 발췌)

### 1. 정상 발행 (publish)
```bash
python3 /Users/mac/.hermes/scripts/tistory_publisher.py \
  --title "GTM을 위한 AI가 성과를 내지 못한 이유 (그리고 해결 방법)" \
  --content "$(cat /tmp/gtm_post.html)" \
  --tags "AI,GTM,영업자동화,SDR,ContextLayer,B2B영업,컨텍스트엔지니어링" \
  --category 1219746 \
  --visibility public \
  --image-query "GTM Context Layer B2B sales strategy"
# → ✅ 발행 성공!
# → 🔗 https://sigco.tistory.com/871
```

### 2. ❌ 첫 record 시도 (실패 — §3.11 패턴이 통하지 않음)
```bash
python3 /Users/mac/.hermes/scripts/tistory_publisher.py \
  --record-topic "GTM을 위한 AI가..." "GTM을 위한 AI가..." \
  "https://sigco.tistory.com/871" "https://news.hada.io/topic?id=30924"
# → ❌ --title과 --content 또는 --file이 필요합니다.
# → exit code 1
```

**원인**: argparse의 `--record-topic nargs='+'` 가 인자는 받지만, publish 분기 진입 후 `args.content or args.file` 검증에서 실패.

### 3. ✅ 우회 패턴 (성공 — 30초 소요)
```bash
# (a) blog_pipeline.py 의 3-arg --record 사용
python3 ~/.hermes/scripts/blog_pipeline.py --record \
  "GTM을 위한 AI가 성과를 내지 못한 이유 (그리고 해결 방법)" \
  "GTM을 위한 AI가 성과를 내지 못한 이유 (그리고 해결 방법)" \
  "https://sigco.tistory.com/871"
# → ✅ 발행 기록 추가: ... | URL: https://sigco.tistory.com/871

# (b) source URL 별도 append (--record는 4번째 인자 안 받음)
echo "https://news.hada.io/topic?id=30924" >> ~/.hermes/memory/published_urls.txt
echo "https://sigco.tistory.com/871" >> ~/.hermes/memory/published_urls.txt

# (c) 검증
python3 -c "
import json
pt = json.load(open('/Users/mac/.hermes/memory/published_topics.json'))
print('details[-1].url:', pt['details'][-1].get('url'))
print('last.url:', pt['last'].get('url', 'MISSING'))
"
# → details[-1].url: https://sigco.tistory.com/871
# → last.url: https://sigco.tistory.com/871
```

## 핵심 학습

### `tistory_publisher.py --record-topic` 의 진짜 의미

| 호출 형태 | 동작 | record-only? |
|---|---|---|
| `--record-topic "T" "Title" "URL"` (3-arg) | publish 분기 → content 없으면 실패 | ❌ |
| `--record-topic "T" "Title" "URL" "srcURL"` (4-arg) | publish 분기 → content 없으면 실패 | ❌ |
| `--title X --content Y --record-topic "T" "Title" "URL"` (동시) | publish 실행 + 완료 시 record | ⚠️ (publish와 묶임) |

→ **명시적 record-only 모드는 없음**. `blog_pipeline.py --record` 가 유일한 record-only 진입점.

### 185차 §3.11 의 잘못된 부분

§3.11 사후 보정 패턴 4단계에서:
```python
# 185차 가이드: blog_pipeline.py --record 사용 (O) ← 이건 맞음
# 단, "tistory_publisher.py --record-topic" 으로 보정 가능" ← 틀림
```

→ 186차 정정: **모든 사후 record 는 `blog_pipeline.py --record TOPIC TITLE URL` + `echo srcURL >> published_urls.txt` 로 통일**.

## 부수 발견: orphan entry 누적

`published_topics.json` 의 `details` 배열에 이전 세션에서 §3.11 로 박힌 entry 가 그대로 남아있음:
- 2026-06-29T08:29: `open-vs-closed-llm-2026` (url="")

이 entry 는 6/29 08:29 의 자동 발행에서 `tistory_publisher.py --record-topic` 이 url 인자 없이 호출되어 박힌 것으로 추정. 186차 session 에서 §3.12 우회 패턴 검증 시 발견.

**권고**: weekly/daily self-review 시 다음 oneliner 로 orphan 검출:
```bash
python3 -c "
import json
pt = json.load(open('/Users/mac/.hermes/memory/published_topics.json'))
orphans = [d for d in pt.get('details', []) if d.get('url') == '']
print(f'orphan entries (url=\"\"): {len(orphans)}건')
for d in orphans:
    print(f'  {d.get(\"date\")} | {d.get(\"topic\", \"?\")[:60]}')
"
# → 1건 이상이면 §3.11 4단계 보정 패턴 적용
```

## §3.11 ↔ §3.12 함수정 매트릭스

| 시나리오 | 권장 명령 | 검증 |
|---|---|---|
| 정상 publish + record 동시 | `tistory_publisher.py --title X --content Y --record-topic "T" "Title" "URL" "srcURL"` | 자동 |
| Publish 완료 후 사후 record | `blog_pipeline.py --record "T" "Title" "URL"` + `echo "srcURL" >> published_urls.txt` | details[-1].url |
| §3.11 보정 (URL 빈값 entry) | 위와 동일 + python patch (3단계/4단계) | grep url '' count = 0 |
| Cron 자동화 | `blog_pipeline.py --category X` (전체 파이프라인 위임) | published_urls.txt last 1줄 |

## 다음 세션 권장 액션

1. **cron 명령 갱신**: `tistory_publisher.py --record-topic` 단독 호출 라인이 있으면 `blog_pipeline.py --record` 로 변경
2. **orphan 정리**: 현 시점 `open-vs-closed-llm-2026` (6/29 08:29) url="" entry 보정 (4단계 패턴 적용, 2분)
3. **monitoring 강화**: `daily-self-review` 크론에 orphan url='' count 메트릭 추가 (182차 §3.6 후보 + 186차 확장)

## 관련 references

- `references/session-20260629-185th-record-url-blank.md` — 185차 원래 진단
- `references/post-publish-verification-recipe.md` — 발행 후 검증 레시피
- `references/false-positive-stats-rollback.md` — 가짜 발행 통계 롤백

## 메타

- **회차**: 186차
- **날짜**: 2026-06-29
- **발행 글 수**: 1 (#871 GTM AI)
- **소요 시간**: 30초 (record 우회만)
- **stat 변동**: stats.total_published 842→843 (정상)
