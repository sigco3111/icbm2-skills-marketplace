# 266차 세션 — #1003 Papermake - Typst 기반 PDF 문서 생성 서버 (개발도구)

**날짜**: 2026-07-14
**세션 차수**: 266
**발행 결과**: ✅ 정상 발행
**발행 URL**: https://sigco.tistory.com/1003
**발행 제목**: Papermake - Typst 기반의 셀프 호스팅 가능한 PDF 문서 생성 서버
**카테고리**: 개발도구 (1219748)
**긱뉴스 topic_id**: 31432
**점수**: 11점 (FRESH 1순위)
**연속 all-green**: 53회차 (213~266차)
**cleanup cron 임무 #16**: 53회 연속 all-green

---

## 1. 워크플로 통과

| 단계 | 결과 |
|------|------|
| §3.8.1 세션 만료 가드 | ✅ `status=200, ct=application/json;charset=UTF-8, cookie_count=8` |
| §3.34.43 PWD 보강 | ✅ 모든 격리 bash 호출에 `PWD=/Users/mac` |
| §3.34.40 FRESH 4-field | ✅ TOP 12개 중 5개(31404/31435/31411/31406/31424) 이미 262~265차 PUB 처리 → FRESH 7개 식별 |
| §3.34 #21 AI/ML 우선 정책 | ✅ AI/ML FRESH=0 → 다른 카테고리 발행 허용, FRESH 1순위 31432 (11점, 개발도구) 픽 |
| §3.34.46 gn-fetch-content 영구화 | ✅ `fetch_gn_content(31432)` → status=200, 1587 bytes 1단계 `.md` endpoint 즉시 fetch |
| §3.34.47 write_file 빌드 패턴 | ✅ `/tmp/tistory_drafts_266th/build_draft.py` (5618 bytes) UTF-8 선언 + 격리 호출 정상 |
| §3.5 5중 신호 검증 | ✅ 모두 `#1003` 일치 (triple_signal_match: true / all_match: True) |
| §3.11 sync 7필드 보정 | ✅ pt_updated: true / state_updated: true / errors: [] |

## 2. 결과 수치

- `daily_counts[2026-07-14]`: `{'AI/ML': 10, '개발도구': 1}` (개발도구 0→1, +1 정확, cat_id 누설 0)
- `state.details`: 79→80, `pt.details`: 95→96 모두 박힘
- 이미지 2장 CDN 업로드 정상 (query: typst pdf document generation server code terminal abstract, Picsum ID 651)
- 본문 검증 1715자 (300자 가드 통과)
- 라이브 페이지 직접 GET `status=200, size=56153, title tag='Papermake - Typst 기반의 셀프 호스팅 가능한 PDF 문서 생성 서버'`

## 3. 266차 신규 발견 (3건)

### §3.34.48 `* ` 리스트 패턴 추가 함정 (NEW)
**문제**: GeekNews 31432 (Papermake) 본문이 `- ` 외 `* ` 들여쓰기 패턴을 혼용 (`* 완전한 감사 추적(Audit Trail)`). 262차 정착 `md_to_html` 은 `- ` 만 처리하여 `* ` 라인이 그냥 `<p>` 로 떨어짐 → 들여쓴 sub-list가 시각적으로 평평한 본문으로 변환됨.

**회피**:
```python
# md_to_html 함수에 추가
elif stripped.startswith("* ") and not stripped.startswith("**"):
    # `**bold**` 시작은 bold 변환 라인으로 위임 (이미 p_html 처리됨)
    if in_ul: out.append("</ul>"); in_ul = False
    out.append("<ul>"); in_ul = True
    item_text = stripped[2:].strip()
    item_esc = html.escape(item_text)
    item_esc = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", item_esc)
    out.append("<li>" + item_esc + "</li>")
```

**추가 보완**: 4단계 헤더 `####` 를 3단계로 강등하는 정규식
```python
md_norm = re.sub(r"^#### (.+)$", r"### \1", md, flags=re.MULTILINE)
```
266차 Papermake 본문이 `#### 목적` / `#### 주요기능` 같은 4단계 헤더 사용 → md_to_html이 h3로 처리 가능하도록 사전 정규화.

### §3.34 #21 AI/ML FRESH=0 케이스 실전 2호
**상황**: TOP 12개 후보 중 AI/ML 카테고리 5개 모두 262~265차 PUB 처리됨 → FRESH 후보 AI/ML=0 + 개발도구 4 + 개발팁 1 + 투자/경제 1 + AI/ML 1 = 7개.

**§3.34.45 매트릭스 5번째 분기 검증**:
- FRESH 모두 'AI/ML 외 비-기타' → **점수 1순위 픽** (카테고리 균형)
- 266차 픽: `31432` (11점, 개발도구) ✅

이전 254차에도 동일 케이스 (FRESH 1순위 개발도구 4점 픽) 있었음. 이번 266차로 매트릭스 5번째 분기가 두 번째 실전 검증 완료.

### 모듈 import 함정
**문제**: `import tistory_publisher; tistory_publisher.publish(...)` 시도 → `AttributeError: module 'tistory_publisher' has no attribute 'publish'`. **모듈에 `publish` 함수 부재, CLI 인터페이스만 지원**.

**회피**: 
1. `subprocess` 로 `python3 /Users/mac/.hermes/scripts/tistory_publisher.py --title ... --file ...` 호출
2. 또는 `terminal` + 격리 bash 패턴 (§3.34.40 4단계 패턴 4번 항목 그대로)

266차 1차 시도가 `AttributeError`로 막힘 → 즉시 격리 bash + CLI 호출로 재시도 → 정상 publish 성공.

## 4. 본문 빌드 코드 패턴 (266차 정착)

```python
# /tmp/tistory_drafts_266th/build_draft.py
# -*- coding: utf-8 -*-
"""266차 빌드 스크립트: #1003 Papermake - Typst 기반 PDF 생성 서버 (개발도구)"""
import html, re, sys, json

with open("/tmp/31432_clean.md") as f:
    md = f.read()

def md_to_html(md):
    out = []
    in_ul = False
    for line in md.split("\n"):
        stripped = line.lstrip()
        if stripped.startswith("- "):
            # 262차 정착 그대로
            ...
        elif stripped.startswith("* ") and not stripped.startswith("**"):  # 266차 추가
            if in_ul: out.append("</ul>"); in_ul = False
            out.append("<ul>"); in_ul = True
            item_text = stripped[2:].strip()
            item_esc = html.escape(item_text)
            item_esc = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", item_esc)
            out.append("<li>" + item_esc + "</li>")
        elif line.startswith("### "):
            # ...
        elif stripped == "":
            if in_ul: out.append("</ul>"); in_ul = False
        # ... 나머지
    if in_ul: out.append("</ul>")
    return "\n".join(out)

# 4단계 헤더 → 3단계 강등 (266차 추가)
md_norm = re.sub(r"^#### (.+)$", r"### \1", md, flags=re.MULTILINE)
body_html = md_to_html(md_norm)

# editorial 인트로 (한국 독자층 1~2 단락 + 원문 링크)
# 본문 (md_to_html 변환)
# 결론 ("한국 SI/스타트업 시사점" + 원문 링크)
# → 2402자 빌드, 검증 1715자 (300자 가드 통과)
```

## 5. publish + sync 호출 패턴 (266차 정착)

```bash
# 1. publish (--file + 격리 bash + PWD)
env -i HOME=/Users/mac PATH=/usr/bin:/bin PWD=/Users/mac /bin/bash -c '
set -a; source ~/.hermes/secrets/tistory.env; set +a
/usr/bin/python3 /Users/mac/.hermes/scripts/tistory_publisher.py \
  --title "Papermake - Typst 기반의 셀프 호스팅 가능한 PDF 문서 생성 서버" \
  --category 1219748 \
  --file /tmp/tistory_drafts_266th/draft.html \
  --source-url "https://news.hada.io/topic?id=31432" \
  --gn-topic-id 31432 \
  --image-query "typst pdf document generation server code terminal abstract"
' 2>&1 | tail -40

# → "✅ 발행 성공! 🔗 https://sigco.tistory.com/1003"

# 2. sync (CLI 1회 실행, sync 서브커맨드 + --category-id)
env -i HOME=/Users/mac PATH=/usr/bin:/bin PWD=/Users/mac /bin/bash -c '
set -a; source ~/.hermes/secrets/tistory.env; set +a
/usr/bin/python3 ~/.hermes/skills/automation/tistory-publisher/scripts/post_publish_sync.py sync \
  --url "https://sigco.tistory.com/1003" \
  --title "Papermake - Typst 기반의 셀프 호스팅 가능한 PDF 문서 생성 서버" \
  --gn-topic-id 31432 \
  --category "개발도구" \
  --category-id 1219748 \
  --source-url "https://news.hada.io/topic?id=31432"
'

# → {"pt_updated": true, "state_updated": true, "errors": [], "triple_signal_match": true}

# 3. 5중 신호 검증 (publish_url 5필드 모두 일치 확인)
# → state.last_published_url = state.last.url = state.details[-1].url
#   = pt.last.url = pt.details[-1].url = https://sigco.tistory.com/1003

# 4. cleanup cron 임무 #16 dry-run
/usr/bin/python3 ~/.hermes/skills/automation/tistory-publisher/scripts/cleanup_daily_cat_id_leak.py --dry-run
# → ✅ 누설 없음 (검사: ['2026-07-14'])
```

## 6. 차감/추가 없음

모든 기존 패턴 정상 동작:
- §3.8.1 가드 ✓
- §3.8.2 격리 패턴 ✓
- §3.11 sync 7필드 ✓
- §3.5 5중 신호 ✓
- §3.34.39 후보 직접 점수 pick ✓
- §3.34.40 FRESH 4-field ✓
- §3.34.41 f-string 회피 ✓
- §3.34.43 PWD 보강 ✓
- §3.34.46 gn-fetch-content 영구화 ✓
- §3.34.47 write_file 빌드 패턴 ✓ (3회째 검증)
- §3.34 #21 AI/ML 우선 정책 ✓ (2회째 실전)
- cleanup cron 임무 #16 ✓