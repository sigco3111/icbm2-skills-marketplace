# 317차 (2026-07-24 00:03 KST) — 만든다는 것

## 발행 결과

**#1093** "만든다는 것 — 직접 만들어야 하는 이유와 AI 시대의 가치" (gn=31728, AI/ML, score=N/A)

## 전체 흐름

- **§3.8.1 가드**: raw VALID (status=200, 8개 쿠키, first_ids=['1092','1091','1090','1089','1088'])
- **§3-a AI/ML ready**: gn=31728 "만든다는 것" (Notion 1순위, freshness OK)
- **§3-b publish**: 본문 5446자 + Picsum 이미지 2장 (seed: making-things-philosophy / craft-over-automation) → **#1093 발행 성공**
  - title="만든다는 것 &mdash; 직접 만들어야 하는 이유와 AI 시대의 가치"
  - og:title="만든다는 것 — 직접 만들어야 하는 이유와 AI 시대의 가치" 정확 매칭
  - OG 썸네일 `https://blog.kakaocdn.net/dna/2fSFU/dJMcaixqkq4/...` 정상 설정
- **§3.11 5단계 보정 완료**:
  - 5-2 commit_publish (stats.today={AI/ML:1}, total=87, by_category["1219746"]=1 — 함정 8 영구 잔존 21연속)
  - 5-3 last + details 통합 (last=#1093, details_len 165→166)
  - 5-2-A 백필 1건 (누적 동기화, published_topics details_len 166→167)
  - 5-4 §3.5 신호 4 미발동 (정상 publish 후 details + last 동시 갱신, 같은 차 첫 발행이라 daily_counts[오늘]=1 ≥ 2 미충족 → 자연 상태)
  - 5-5 proxy check #1093 status=200 + og:title 정확 매칭 disambiguate PASS

## 확정 카운트 갱신

- **신호 4 오탐 disambiguate 22연속 확정** (298→317)
- **305차 단일 패스 패턴 317차 재확인 (13연속 정형화)**: `build_post_317.py` 안에 `requests.get(gn_url) + <meta property="og:description"> regex` 임베드 → 160자 description 추출 성공 ("생성형 AI로 프로젝트를 완성해도 요청한 사람과 실제 제작 주체가 다르다면, '내가 만들었다'는 성취감을 얻기 어려움 프롬프트에는 비전·판단·소통·기술이 필요하지만, 직접 만드는 기술보다는 다른 존재에게 제작을 맡기는 기술에 가까움 직접 작성한 177줄짜리 스페인어 플래시카드 시스템은…")
- **303차 안정 raw 검증 패턴 317차 재확인** (가드 8개 쿠키 + JSON 응답 정상)

## 함정 회피 5중 동시 확인

함정 6 (heredoc + env -i SyntaxError) + 함정 7 (--category int) + 함정 8 (by_category["1219746"]=1 영구 잔존) + 함정 11 (execute_code cron 차단 회피) + 함정 15 (5-5 proxy 격리 패턴) 모두 317차 워크플로에서 자동 회피 성공.

## 317차 신규 함정 (함정 17 신규) — build_post_XXX.py 단일 큰 f-string 회피

**증상**: 305차 패턴을 따라 `build_post_XXX.py`를 작성할 때, 본문 + 코드 블록(docstring 포함) + 푸터(f-string으로 `{GN_URL}`/`{TOPIC_ID}` 등 보간)을 한 개의 큰 f-string에 우겨넣으면 다음 두 가지가 동시에 발생할 수 있다:

1. `write_file` → lint 단계에서 `SyntaxError: invalid syntax (line 82, column 8)` 형태의 에러. 보통 f-string 안에 들어간 docstring의 비-ASCII 한국어 + 따옴표 매칭이 lint 단계에 걸림.
2. sibling subagent write 경고 — `/tmp/build_post_XXX.py`는 동시에 여러 cron이 접근할 수 있어, 다른 작업이 같은 파일을 덮어쓰면서 lint 실패 + sibling warning이 동시 노출.

**해결 (317차 확정)** — 본문을 작은 단위로 `parts.append()` 리스트에 모으고, 마지막에 `"\n".join(parts)`로 한 번만 합친다:

```python
parts = []
parts.append('<p><img src="https://picsum.photos/seed/foo/1200/630"></p>')
parts.append("<p>본문 1단락...</p>")
parts.append("<h2>섹션 1</h2>")
parts.append("<p>본문 2단락...</p>")

# 코드 블록은 별도 string 리스트로 합치고 pre/code로 감싼다
code_lines = ["import requests", "r = requests.get(...)", ...]
code_html = '<pre><code class="language-python">' + "\n".join(code_lines) + "</code></pre>"
parts.append(code_html)

# 푸터도 concat (f-string 보간 부분만 따로)
parts.append("<p><em>원문: <a href=\"" + GN_URL + "\">" + TOPIC_TITLE + "</a></em></p>")

body = "\n".join(parts)
html_doc = (
    "<!DOCTYPE html><html lang=\"ko\"><head>"
    "<meta charset=\"utf-8\">"
    "<title>" + TOPIC_TITLE + "</title>"
    "</head><body>" + body + "</body></html>"
)
```

**장점**: f-string 안에서 비-ASCII docstring을 만나는 일이 없고, sibling write가 발생해도 lint는 안정적이며, body 부분 교체 시 parts.append() 한 줄만 patch하면 된다 (기존 단일 f-string 통째 patch 대비 가독성·유지보수 ↑).

**판정**: 빌드 스크립트가 80줄 이상이거나 docstring/코드 블록/푸터가 f-string 안에서 함께 들어가는 경우엔 처음부터 parts.append() 패턴으로 시작한다. 짧은 빌드(< 50줄)는 기존 f-string도 lint 통과하나, 동일 함정 회피 차원에서 정형화 권장.

## 317차 신규 관찰 — 빌드 스크립트 자체 단순화 규칙

build_post_XXX.py 작성 시 다음 우선순위로 단순화:

1. f-string은 메타데이터 보간(`{TOPIC_TITLE}`, `{desc}`, `{GN_URL}` 등 짧은 변수) + body 미리 합쳐질 곳에만.
2. 본문 paragraph/H2/code/pre 같은 구조 블록은 `parts.append('<tag>...</tag>')` 리스트.
3. docstring에 들어가는 한국어는 짧은 1-2줄로, f-string 외부에 위치 (변수명은 영문).
4. 코드 블록(`<pre><code class="language-xxx">`)은 list[str] → `"\n".join()` → wrap.

**효과**: lint 실패 → 재작성 cycle 0회. 317차 첫 시도 lint 에러 + sibling warning 동시 발생 후 두 번째 시도에 정상 통과, 본문 발행까지 5분. 향후 차 cron이 동일 함정에 빠질 때 처음부터 parts.append() 패턴으로 작성하면 단일 패스 성공.

## 통계

- 317차 daily_counts={AI/ML:1}
- 누적 total=87
- by_category: {"AI/ML": 782, "iOS/Swift": 18, "개발도구": 142, "투자/경제": 14, "기타": 14, "아이디어": 6, "개발 팁": 14, "개발팁": 2, "1219746": 1}
  - 함정 8 by_category["1219746"]=1 영구 잔존 **21연속 재확인** (297→317 = 21차 동일 유지)

## 연속 all-green

**97회차** (316→317차).
