# 292차 (2026-07-19) — `--record-topic` placeholder 잔재 + `commit_publish()` last_published_url 미갱신 함정

## 핵심 발견

이번 차에서 `tistory_publisher.py`의 두 함정이 실전 검증됨:

### 함정 1: `--record-topic` URL placeholder 박힘

`scripts/tistory_publisher.py:782-862`를 보면, `--record-topic` 인자로 받은 `TOPIC TITLE URL [TOPIC_URL]`을 `record_published_topic()`에 그대로 넘김. publish_post()가 반환한 entryUrl은 받지 못함.

```bash
# ❌ 잘못된 사용
python3 tistory_publisher.py \
  --title "..." --content "..." \
  --record-topic "31545" "TITLE" "https://sigco.tistory.com/TBD" "https://news.hada.io/topic?id=31545"
# → published_topics.json details[].url = "https://sigco.tistory.com/TBD" (그대로 박힘)
```

**올바른 패턴**: placeholder 안 쓰기. 진짜 URL을 publish 후 post-hoc patch로 박거나, `--record-topic` 인자 자체를 생략하고 `commit_publish()`로 분리 호출.

### 함정 2: `commit_publish()` 가 last_published_url 미갱신

`scripts/blog_pipeline.py:1871-1940`를 보면, `commit_publish()`는 다음 필드만 갱신:
- `daily_counts[today][category]` += 1
- `last_topics.append(...)`
- `stats["total_published"]` += 1
- `stats["by_category"][category]` += 1
- `published_urls.txt` 갱신

**`last_published_url`은 건드리지 않음**. §3.5 3중 신호 검증 시 drift 발생.

## 해결 패턴 (3-패치 시퀀스)

publish_post() 성공 → 3-패치 실행:

```bash
# 5-2. state.json stats 동기화 (commit_publish)
python3 blog_pipeline.py --commit "TOPIC_ID" "TITLE" "URL" "AI/ML" "SOURCE_URL"

# 5-2-A. published_topics.json details[].url 보정 (placeholder 잔재 있을 때)
python3 -c "
import json
from pathlib import Path
data = json.loads((Path.home()/'.hermes/memory/published_topics.json').read_text())
for e in data.get('details', []):
    if e.get('url') in ('https://sigco.tistory.com/TBD', None, ''):
        e['url'] = 'https://sigco.tistory.com/NNN'
last = data.get('last', {})
if last.get('url') in ('https://sigco.tistory.com/TBD', None, ''):
    last['url'] = 'https://sigco.tistory.com/NNN'
    data['last'] = last
(Path.home()/'.hermes/memory/published_topics.json').write_text(json.dumps(data, ensure_ascii=False, indent=2))
"

# 5-3. state.json last_published_url 수동 패치
python3 -c "
import json
from pathlib import Path
data = json.loads((Path.home()/'.hermes/memory/blog_pipeline_state.json').read_text())
data['last_published_url'] = 'https://sigco.tistory.com/NNN'
(Path.home()/'.hermes/memory/blog_pipeline_state.json').write_text(json.dumps(data, ensure_ascii=False, indent=2))
"

# 5-4. §3.5 3중 신호 검증
~/.hermes/skills/tistory-publisher/scripts/check_state_consistency.py
# → ✅ OK: 3중 신호 일치

# 5-5. proxy check (Tistory #NNN 실재 검증)
curl -I https://sigco.tistory.com/NNN
# → status=200 + og:title 매칭
```

## 부가 발견: 긱뉴스 본문 selector 함정

`<p>`, `<article>`, `<div class="topic-body">`, `<div id="contents">` 모두 본문이 아니라 코멘트만 잡힘. 

**가장 안정적**: `<meta property="og:description" content="...">` 사용. OG description이 긱뉴스 측에서 핵심 정보를 모두 담고 있음.

## 검증 결과

| 항목 | 결과 |
|------|------|
| §3.8.1 raw 가드 | ✅ status=200 VALID |
| §3.5 신호 4 FAKE_PUBLISH | ✅ 미발동 (daily_counts[2026-07-19]=0 시작) |
| Tistory #1044 발행 | ✅ status=200, og:title 매칭 |
| §3.11/§4 보정 3-패치 | ✅ 모두 실행 후 3중 신호 일치 |
| 연속 all-green | 75 → 76회차 |

## 잔재 이슈

- `daily_counts[2026-07-18]` = AI/ML 4 + 개발팁 1 = 5건 가짜 발행 잔재 (289차 발견) **미해소** — 사용자 확인 후 차감 보정 필요
- `total` 필드는 표시 안 되는데 long drift 가능성 — 별도 점검 필요