# 285차 세션 — 2026-07-17 (Gemini Notebook 리브랜딩)

## 발행 결과

- **#1035** `NotebookLM이 Gemini Notebook으로 이름을 바꿨다 — 독립형 도구를 지키면서 Gemini 생태계로 확장하는 Google의 균형점`
- URL: `https://sigco.tistory.com/1035`
- gn_topic_id: `31508` (점수 6.0, 카테고리 AI/ML)
- 본문 평문: 2088자 (intro 540 + 본문 1796 + 결론 ~750) — 300자 가드 통과
- Picsum ID: `603` (두 슬롯 동일, query: `google notebook research study ai cloud analysis desktop interface`)
- 라이브 페이지 검증: `status=200`, title tag 정상

## 운영 체크리스트 통과

- [x] §3.8.1 가드: `status=200, ct=application/json;charset=UTF-8, cookie_count=8`
- [x] §3.34.43 PWD 보강: `PWD=/Users/mac` 명시
- [x] §3.34.40 v2 FRESH 4-field 매칭 (12개 → FRESH 9개 정확 식별)
- [x] §3.34.55 `_try_md_endpoint(tid)` 단일 변수 할당 (`text = gfc._try_md_endpoint(31508)`)
- [x] §3.34.46 영구화: 5844 bytes 1단계 `.md` fetch 정상
- [x] §3.34.50 Topic Body 마커 추출 (`re.search(r'## Topic Body\s*\n+(.*)', text, re.DOTALL)`)
- [x] §3.34.47 격리 빌드: `write_file` → `/tmp/tistory_drafts_285th/build_draft_31508.py` (5887 bytes) → `python3` 격리 호출
- [x] §3.34.53 `gfc` alias: `importlib.util.spec_from_file_location("gfc", ".../gn-fetch-content.py")`
- [x] §3.34.54 `>` blockquote 분기 (이번 본문엔 `>` 라인 없어 미적용)
- [x] §3.34.48 `*` 분기 (이번 본문엔 `*` 패턴 없어 미적용)
- [x] §3.34 #21 정책 + §3.34.45 매트릭스: AI/ML FRESH 4개 중 점수 1순위 픽
- [x] §3.11 sync: `pt_updated: true / state_updated: true / errors: [] / triple_signal_match: true`
- [x] §3.5 5중 신호: 5/5 `#1035` 일치 (`all_match: True`)
- [x] cleanup cron 임무 #16: dry-run `✅ 누설 없음` (71→**72회** 연속 all-green)

## §3.34 #21 정책 실전 12호

FRESH 9개 카테고리 분포:

| 카테고리 | 후보 수 | 후보 (점수) |
|---|---|---|
| AI/ML | 4 | `31508` (6점), `31516` (3점), `31513` (3점), `31496` (PUB, 제외됨) |
| 개발도구 | 2 | `31510` (3점), `31512` (2점) |
| 개발팁 | 4 | `31501` (9점), `31518` (8점), `31514` (8점), `31521` (6점) |
| 기타 | 0 | — |

→ §3.34 #21 정책 적용: AI/ML FRESH 중 점수 1순위 `31508 (6점)` 픽. 비-AI/ML 후보들 중 14점짜리 `31501` (FOSS AI 투자) 자동 배제됨.

## §3.34.44 drift 무해 6호

사전 검증에서 `state.last_published_url=#1034` (Linu Torvalds 커널 LLM use, 자정 사이 외부 발행 흔적), `pt.last.gn_topic_id=31509` — 두 신호 모두 283~284차 차 사이 외부 발행이 슬롯을 덮어쓴 흔적. v2 FRESH 4-field 매칭이 정상 식별 후 publish → sync `#1035` 로 무해 회복.

## 핵심 코드 패턴 (285차 검증, 권장 정착)

### 1. FRESH 4-field 매칭 (§3.34.40 v2)

```python
import json
pt = json.load(open('/Users/mac/.hermes/memory/published_topics.json'))
state = json.load(open('/Users/mac/.hermes/memory/blog_pipeline_state.json'))
pt_published = set()
for d in pt.get('details', []):
    for k in ['topic', 'topic_id', 'gn_topic_id']:
        if k in d and str(d[k]).isdigit():
            pt_published.add(str(d[k]))
state_published = set()
for d in state.get('details', []):
    for k in ['topic_id', 'gn_topic_id']:
        if k in d and str(d[k]).isdigit():
            state_published.add(str(d[k]))
pt_last_gn = str(pt.get('last',{}).get('gn_topic_id'))
if pt_last_gn.isdigit():
    pt_published.add(pt_last_gn)
```

### 2. `_try_md_endpoint(tid)` 단일 호출 (§3.34.55)

```python
import importlib.util, re
spec = importlib.util.spec_from_file_location('gfc', '/Users/mac/.hermes/skills/automation/tistory-publisher/scripts/gn-fetch-content.py')
gfc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gfc)
text = gfc._try_md_endpoint(31508)  # Optional[str] — None 가드 권장
if not text:
    sys.exit(1)
# Topic Body 마커 기반 추출
m = re.search(r'## Topic Body\s*\n+(.*)', text, re.DOTALL)
body = m.group(1) if m else text
m2 = re.search(r'\n## Comments', body)
if m2:
    body = body[:m2.start()]
```

### 3. `md_to_html` 5종 패턴 (§3.34.46 + 278차 5번째 정착)

- `## 헤더` → `<h2>` (들여쓰기 무시)
- `### 헤더` → `<h3>`
- `- 항목` / `* 항목` (bold `**` 시작 제외) → `<ul><li>`, 빈 줄에서만 `</ul>` close
- `**bold**` → `<strong>`
- `> 인용` → `<blockquote>` (5번째 정착)

### 4. 격리 publish + sync (§3.11 + §3.34.43)

```bash
# Publish
env -i HOME=/Users/mac PATH=/usr/bin:/bin PWD=/Users/mac /bin/bash -c '
set -a; source ~/.hermes/secrets/tistory.env; set +a
/usr/bin/python3 /Users/mac/.hermes/scripts/tistory_publisher.py \
  --title "<TITLE>" --category 1219746 \
  --file /tmp/tistory_drafts_285th/draft-31508-gemini-notebook.html \
  --source-url "https://news.hada.io/topic?id=31508" \
  --gn-topic-id 31508 \
  --image-query "google notebook research study ai cloud analysis desktop interface"
'

# Sync
env -i HOME=/Users/mac PATH=/usr/bin:/bin PWD=/Users/mac /bin/bash -c '
set -a; source ~/.hermes/secrets/tistory.env; set +a
/usr/bin/python3 ~/.hermes/skills/automation/tistory-publisher/scripts/post_publish_sync.py sync \
  --url "https://sigco.tistory.com/1035" \
  --title "<TITLE>" \
  --gn-topic-id 31508 \
  --category "AI/ML" \
  --category-id 1219746 \
  --source-url "https://news.hada.io/topic?id=31508"
'
```

## 본 세션 신규 발견

**0건** — 254~284차 정착된 모든 패턴(§3.8.1 가드 / §3.8.2 격리 / §3.11 sync / §3.34.40 v2 / §3.34.43 PWD / §3.34.46 영구화 / §3.34.47 격리 빌드 / §3.34.48 `*` 분기 / §3.34.50 Topic Body / §3.34.53 `gfc` alias / §3.34.54 `>` blockquote / §3.34.55 시그니처 함정 / §3.34 #21 정책 + #45 매트릭스 / §3.34.44 drift 무해 / cleanup #16) 정상 동작.

## 운영 관찰

- 285차 본문은 "## Topic Body" 마커 직후 `- Google은 ...` bullet 으로 시작하지만 §3.34.50 Topic Body 마커 기반 추출이 정상 처리 (1796자 본문 확보). 272차에 식별된 "## Metadata skip" 함정은 우회 완료.
- FRESH 후보에 비-AI/ML 후보가 다수 섞여있을 때 (`28501` 9점 개발팁, `31518` 8점 개발팁, `31514` 8점 개발팁, `31521` 6점 개발팁) §3.34 #21 정책이 정확히 동작하여 AI/ML 6점 픽. 254차 정책 확정이 12회차 연속 검증.
- cleanup #16 dry-run 72회 연속 all-green 유지. cat_id 누설 0.
