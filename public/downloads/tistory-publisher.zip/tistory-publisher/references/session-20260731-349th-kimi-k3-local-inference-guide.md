# 349차 (2026-07-31 22:01)

**#1159** (Kimi K3 로컬 실행 가이드 — 2.8T 파라미터 오픈 웨이트 모델을 Unsloth GGUF로 돌리는 법, gn=32008, AI/ML, 본문 1,777자, Picsum 2장, Bash 코드 블록 1개).

- §3.8.1 raw VALID (status=200, first_ids=['1158','1157','1156','1155','1154'])
- 단일 패스 44연속 + parts.append() 정형 44연속 + §3.5 신호 4 disambiguate 43연속 + 진입 5-5 24연속 + fallback 복귀 36연속
- 324차 `--content` 단일 폴백 정형 12회차 검증 (324→344→345→346→347→348→349)
- 정형 정상 차 — 348차 정형화(parts.append() + code_lines 분리 + `--content` 단일 폴백 + §3.5 구조적 오탐 disambiguate) 그대로 재현, 새 함정/관찰 0건
- 본문 1777자 (< 3000자 임계) + Bash 코드 블록 1개 → 346차 판정 매트릭스 (a) 등급이지만 처음부터 parts.append() 정형 적용 (안전 우선)
- sibling write warning 1회 → grep -nE '[一-鿿]|[ぁ-ゔ]|[ァ-ヴー]' 검증으로 print문의 regex 자체만 검출 (정상, CJK swap 0건), parts.append 14회 (정상)
- build script: `requests.get(gn_url)` + `og:description` regex + `<article>` 추출 → 5586자 본문 확보 → 1777자 본문 빌드 (긱뉴스 article 추출 셀렉터 안정화)
- 5-2-A 누락 백필 1건 (state.json엔 #1159, published_topics.json엔 누락 → 336차 + 337차 + 348차 정형 순서 정상)
- publish_post() OG 썸네일 `https://blog.kakaocdn.net/dna/USKJa/dJMcabyi2jw/AAAAAAAAAAAA...` 자동
- 5-5 proxy check disambiguate 통과 (status=200 + og:title 정확 매칭 + source_present=True + cjk_suspicious=False)
- daily_counts={AI/ML:11}, total=153, by_category 영구 누적 잔존 (`"1219746": 1` 49연속 — 297→349)
- 연속 all-green **123회차**
