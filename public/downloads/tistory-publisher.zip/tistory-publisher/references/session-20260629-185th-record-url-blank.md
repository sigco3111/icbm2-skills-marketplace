# 185차 세션 (2026-06-29) — record-topic URL 빈값 버그 + 사후 보정

## 한 줄 요약

`tistory_publisher.py --record-topic` 호출 시 stdout에는 URL이 표시되지만, 실제 `record_published_topic()`에는 URL이 빈 문자열로 전달되어 local state에 URL 미기록. Tistory 글은 정상 발행됨 (HTTP 200). §3.5 검증 임계값(통계 - URL 수)으로는 가짜 발행으로 적중하지만, 실제로는 "글은 발행됐고 URL 기록만 안 됨" 상태 — **§3 가짜 발행(글 안 올라감)과 직교하는 별개 함정**.

## 시나리오 전체 로그

```
[19:00] cron 자동 실행
  python3 ~/.hermes/scripts/blog_pipeline.py
  → status: ready, topic: "AI 슬롭과 온라인 소음에 대한 최고의 답은 Robin Williams에게서 나온다"
  → source_url: https://news.hada.io/topic?id=30917
  → guidline 정상 출력

[19:01] 중복 검사
  - 30917 매치: 0건 (신선)
  - published_topics.json details에 30917 없음
  - stats.total_published: 842, AI/ML: 658
  - last_topics에 신규 토픽 박힘 (guidline 출력 시점)
  - 가짜 발행 누적: stats.total_published(842) - sigco URL 수(320) = 522 (시계열 누적)

[19:02] 본문 작성 (1,670자 실 텍스트, H2 5개, 인용구 1, 코드블록 1)
  → /tmp/tistory_draft/post_30917.md (마크다운)
  → /tmp/tistory_draft/post_30917_html.txt (HTML 2,128자)
  → 1회 컷 정형화 (H2 5개 = 181차 구간 외, H2 다수 OK)

[19:02] Tistory 발행
  python3 ~/.hermes/scripts/tistory_publisher.py \
    --title "..." --content "$(cat ...html)" --tags "..." \
    --visibility public --category 1219746 --image-query "..." \
    --record-topic "..." "..."
  → 세션 유효: ✅ 세션 유효 (총 732개 글) → 새 글 733
  → Picsum 이미지 2장 자동 삽입
  → 발행 성공: 🔗 https://sigco.tistory.com/870
  → record-topic 출력:
      📝 주제 record 완료: AI 슬롭과 온라인 소음... | URL: ...

[19:02] 발행 후 검증 (의심 단계)
  - curl https://sigco.tistory.com/870 → HTTP 200, 60,855 bytes ✅
  - og:title / og:description / 메타 description 모두 정상
  - 본문 키워드 "AI 슬롭과 온라인 소음" 매치 ✅
  → 실제 글은 정상 발행 확인

[19:02] BUT! local state 검증에서 발견:
  - published_urls.txt 마지막: 858, 867, simonwillison.net/... (870 미기록)
  - published_topics.json details 마지막 entry: {"topic": "...", "title": "...", "hash": "...", "url": "", "date": "2026-06-29T19:02"} ← 빈 URL
  - published_topics.json last: {"hash", "topic", "title", "date"} ← url 키 없음
  - stats.total_published: 842 (그대로)
  - last_topics 마지막 entry의 date/url도 비어있음

[19:02] §3.11 진단: --record-topic 호출 시 args.record_topic = ["topic", "title"] (URL 없음)
  → url_arg = args.record_topic[2] if len(args.record_topic) > 2 else "" → 빈 문자열
  → record_published_topic(topic, title, "", "") 호출됨
  → stdout에는 "URL: https://sigco.tistory.com/870" 표시되지만 실제 record에는 빈 URL 전달

[19:03] 사후 보정 (4단계, 2분)
  1) curl로 URL 확인 (HTTP 200, 60,855 bytes, 본문 키워드 매치)
  2) published_urls.txt에 870 + 30917 추가 (2줄)
  3) published_topics.json details[-1].url = "https://sigco.tistory.com/870" 보정
  4) blog_pipeline_state.json last_topics의 빈 date/url/source_url 보정

[19:03] 최종 검증
  - sigco.tistory.com 라인 수: 320 → 321
  - stats.total_published: 842 (가짜 발행 누적 521로 1 줄어듦)
  - details에 870 박힘: 1건
  - §3.5 임계값: 521 (여전히 양수지만 이번 건은 정상 발행이었음)
```

## 근본 원인 가설

`tistory_publisher.py`의 `--record-topic` 동작:
```python
parser.add_argument("--record-topic", nargs='+', metavar="TOPIC", ...)
# args.record_topic = ["topic", "title", "url", "topic_url"]
url_arg = args.record_topic[2] if len(args.record_topic) > 2 else ""
record_published_topic(topic_arg, title_arg or "", url_arg or "", topic_url_arg or "")
```

- **버그 1**: stdout에 표시되는 URL은 `data.tistory.url` (Tistory API 응답) → args.url_arg로 전달 안 됨
- **버그 2**: args.record_topic에 URL이 없으면 빈 문자열로 fallback → record_published_topic이 빈 URL 박음
- **버그 3**: 빈 URL이 박힌 entry는 details에 그대로 남고, last dict에는 url 키 자체가 없음 (KeyError 발생)

## §3 가짜 발행과의 차이

| 차원 | §3 가짜 발행 | §3.11 record 버그 |
|---|---|---|
| 통계 박힘 | ✅ +1 | ✅ +1 (guidline 시점) |
| URL 박힘 | ❌ 0 (Tistory API 실패) | ❌ 0 (record 호출 시 빈값) |
| 실제 Tistory 글 | ❌ 안 올라감 | ✅ 정상 발행 |
| §3.5 임계값 | 적중 (가짜) | 적중 (false positive) |
| 롤백 필요 | ✅ 통계 차감 | ❌ URL 보정 |

## 사후 보정 4단계 패턴 (185차 신규 표준)

```bash
# 1단계: Tistory URL 확인 (마지막 글 번호 기반)
python3 ~/.hermes/scripts/tistory_publisher.py --check-session
# → "✅ 세션 유효 (총 732개 글)" → 새 글은 733

curl -s -o /tmp/check.html -w "HTTP %{http_code} | %{size_download} bytes\n" "https://sigco.tistory.com/733"
grep -o "AI 슬롭과 온라인 소음" /tmp/check.html | head -1
# → 매치되면 실제 발행 확인

# 2단계: published_urls.txt에 URL 추가
echo "https://sigco.tistory.com/870" >> ~/.hermes/memory/published_urls.txt
echo "https://news.hada.io/topic?id=30917" >> ~/.hermes/memory/published_urls.txt

# 3단계: published_topics.json의 빈 URL entry 보정
python3 -c "
import json
from pathlib import Path
p = Path('/Users/mac/.hermes/memory/published_topics.json')
pt = json.loads(p.read_text())
last = pt['details'][-1]
if last.get('url') == '' and last.get('topic'):
    last['url'] = 'https://sigco.tistory.com/870'
    last['source_url'] = 'https://news.hada.io/topic?id=30917'
    pt['last']['url'] = 'https://sigco.tistory.com/870'
    p.write_text(json.dumps(pt, ensure_ascii=False, indent=2))
    print(f'✅ details[-1].url 보정 완료')
"

# 4단계: blog_pipeline_state.json의 last_topics 동기화
python3 -c "
import json
from pathlib import Path
p = Path('/Users/mac/.hermes/memory/blog_pipeline_state.json')
s = json.loads(p.read_text())
for t in s.get('last_topics', []):
    if t.get('topic') == '<TOPIC_NAME>' and not t.get('date'):
        t['date'] = '2026-06-29T19:02'
        t['url'] = 'https://sigco.tistory.com/870'
        t['source_url'] = 'https://news.hada.io/topic?id=30917'
p.write_text(json.dumps(s, ensure_ascii=False, indent=2))
"
```

## 근본 해결 (TODO, 185차 미수정)

- `tistory_publisher.py`에서 Tistory API 응답의 `data.tistory.url`을 내부 변수로 보관한 후 `args.record_topic[2]`가 빈값이면 fallback
- 또는 `record_published_topic` 호출 직전에 stdout URL → args URL 자동 보완하는 로직 추가
- 현재는 args에만 의존 → cron에서 URL 누락 시 빈값 박힘

## 예방 (185차 권고)

- cron 명령에 항상 **3번째 인자로 Tistory URL placeholder 전달** (또는 사후 검증 1단계 추가)
- `python3 ~/.hermes/scripts/tistory_publisher.py --check-session`으로 마지막 글 번호 먼저 확인 후 cron 실행
- 발행 직후 `details[-1].url` 1차 검증 → 빈값이면 §3.11 보정 패턴 즉시 적용 (2분 작업)

## 핵심 교훈

- **stdout만 신뢰하지 말 것** — `tistory_publisher.py`는 record 결과를 stdout에 표시하지만, 실제 record 인자(args)는 비어있을 수 있음
- **details 배열 + urls.txt 양쪽 검증 필수** — 한쪽만 박혔다고 "정상"이라고 단정하지 말 것
- **§3.5 임계값은 "글 발행 + URL 기록"의 불변식을 측정** — URL 기록 실패도 임계값에 잡힘
- **가짜 발행 ≠ URL 미기록** — 가짜 발행을 의심할 때 실제 Tistory 페이지 200 + 본문 키워드 매치까지 확인하면 §3 vs §3.11 구분 가능

## 다음 세션 TODO

- [ ] `tistory_publisher.py`의 `--record-topic` 로직 수정 (Tistory 응답 URL을 args.url_arg fallback으로 사용)
- [ ] cron 명령에 Tistory URL placeholder 자동 주입 스크립트 (`scripts/inject-record-url.sh`)
- [ ] §3.5 임계값 자동 모니터링 (521 누적 → daily-self-review에 메트릭 추가)
