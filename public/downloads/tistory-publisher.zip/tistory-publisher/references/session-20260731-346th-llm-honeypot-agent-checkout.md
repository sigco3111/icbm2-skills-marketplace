# 346차 — LLM 허니팟 (gn=31987, AI/ML, #1149)

**발행**: 2026-07-31 00:01 (cron)
**글 번호**: #1149 (last_published_id=1149, total=143)
**제목**: LLM 허니팟 — 에이전트를 속여 결제 정보를 노출시키는 기만적 보안 테스트의 작동 원리
**소스**: https://news.hada.io/topic?id=31987
**카테고리**: AI/ML (1219746)
**본문**: 2,564자 (30 parts) + Picsum 2장 + inline `<code>` 4회 + source footer 자동

## 워크플로우 정형 (모두 정형 그대로 재현)

- 1단계 §3.8.1 가드: posts.json first_id=1148, items_count=15 ✅ VALID
- 2단계 `--refresh-topics` → 12개 후보 새로고침
- 3단계 `--category 'AI/ML'` → `status=ready` topic="LLM 허니팟" gn=31987
- 3-b publish: standalone wrapper `/tmp/publish_346.py` (함정 20 정형 — 셸 `--content "$(...)"` 회피)
- 5-3 → 5-2-A 순서 (336차 정형 — state.json 먼저, 그다음 published_topics.json)
- §3.5 3중 신호 검증: today=1 자연 상태 (신호 4 미발동) ✅
- 5-5 proxy check: status=200 + og:title 정확 + source_present=True + cjk_suspicious=False

## 단일 패스 연속 + 신호 4 disambiguate 갱신

| 지표 | 직전 (345차) | 346차 | 누적 |
|------|--------------|-------|------|
| 단일 패스 패턴 (305~) | 40연속 | 41연속 | 41 |
| parts.append() 정형 (317~) | 40연속 | 41연속 | 41 |
| §3.5 신호 4 disambiguate | 39연속 | 40연속 | 298→346 = 49차 |
| 진입 5-5 트리거 (310~) | 20연속 | 21연속 | 21 |
| fallback 복귀 (311~) | 32연속 | 33연속 | 33 |
| `--content` 단일 폴백 (324~) | 8회차 검증 | 9회차 검증 | 9 |
| 연속 all-green | 119회차 | **120회차** | 120 |

## 함정 재발 / 신규 관찰

### 함수정 12 Picsum read-timeout 변형 (346차 신규)

304차 #1055에서 `cdn.sigco.dev` SSL verify 실패 패턴(함정 12)을 처음 보고. 346차에서는 SSL verify 단계는 통과했지만 **다운로드 단계에서 read timeout** 발생:

```
⚠️  이미지 다운로드 오류: HTTPSConnectionPool(host='fastly.picsum.photos', port=443): Read timed out. (read timeout=15)
🖼️  이미지 업로드 중... (1/2)
🖼️  이미지 업로드 성공: image.jpg (49KB)
🖼️  이미지 업로드 중... (2/2)
🖼️  OG 썸네일 설정: https://blog.kakaocdn.net/dna/bRYHBW/dJMcacxf214/AAAAAAAAAAA...
PUBLISH=SUCCESS URL=https://sigco.tistory.com/1149
```

`publish_post()` 내부에서 자동 재시도 → 두 번째 시도는 정상 다운로드 + 업로드. **SSL verify 실패(304차) → read timeout(346차) 두 변형** 모두 같은 패턴으로 안전.

**판정**: 함수정 12 갱신 — Picsum 자체 CDN read timeout도 자동 재시도로 안전. cron 로그 노이즈 감수. 진짜 발행 판정은 §3.11 5-5 proxy check (status=200 + og:title 매칭) 단일 기준.

### 판정 매트릭스 4단계 갱신 (346차)

이전 3단계:
- (a) 본문 < 3000자 + multiline block 0개 = 단일 f-string OK (318차)
- (b) 본문 3000자+ 또는 multiline block 1개+ = parts.append() 권장 (338차)
- (c) 본문 5000자+ 또는 multiline block 2개+ = parts.append() 필수 (340차)

346차 실전 — 본문 2,564자 (< 3000자) + multiline `<pre><code>` 0개이지만 **inline `<code>` 4회**:

- inline `<code>`만 있으면 parts.append() 안에 직접 박아도 lint 정상
- multiline `<pre><code>`만 code_lines 분리 패턴 필요
- inline `<code>`는 f-string 안에 single-quoted든 double-quoted든 안전

**4단계 정형**:
- (a) 본문 < 3000자 + multiline block 0개 + inline `<code>` 소수 = 단일 f-string OK
- (b) **본문 < 3000자 + multiline block 0개 + inline `<code>` 다수 = parts.append() 권장** (346차 실전)
- (c) 본문 3000자+ 또는 multiline block 1개+ = parts.append() 권장
- (d) multiline block 2개+ 또는 본문 5000자+ = parts.append() 필수

**판정 핵심**: multiline `<pre><code>` 블록 개수가 가장 강한 신호. inline `<code>`는 parts.append() 정형 채택 시 무리 없이 통합 가능.

### 함수정 8 by_category 영구 잔존 해소 추정 (346차)

345차까지 누적 패턴: `stats.by_category`에 정수 키 `"1219746": 1` 영구 잔존 (297→345 = 49차 동일 유지).

346차 stats 결과:
```json
"by_category": {
  "AI/ML": 829,
  "iOS/Swift": 18,
  "개발도구": 151,
  "투자/경제": 14,
  "기타": 14,
  "아이디어": 6,
  "개발 팁": 14,
  "개발팁": 2
}
```

**`"1219746"` 정수 키 부재**. 두 가지 시나리오:
- (a) 사용자가 이전 게이트에서 ID_TO_NAME 마이그레이션 보정 적용 (296차 함정 8 정형 절차대로)
- (b) `commit_publish()` 또는 stats update 경로가 카테고리명을 직접 사용하도록 변경됨

**판정**: 어느 쪽이든 cron의 임의 자동 보정 필요 없음 — 사용자 게이트 결정 사항이거나 코드 변경이므로 drift 보고만. 다음 차 cron 진입 시 by_category 키 norm 상태 재확인.

## 빌드 스크립트 패턴 (재현 가능)

```python
# /tmp/build_post_NNN.py
import os, re, requests, sys, json
from pathlib import Path

url = 'https://news.hada.io/topic?id=NNNN'
r = requests.get(url, headers={'User-Agent':'Mozilla/5.0'}, timeout=10)
og = re.search(r'<meta property="og:description" content="([^"]+)"', r.text)
desc = og.group(1) if og else ''

parts = []
parts.append('<h1>...</h1>')
parts.append('<p>요약: ...</p>')
parts.append('<figure><img src="https://picsum.photos/seed/<slug>/1024/640" alt="..." /><figcaption>...</figcaption></figure>')
# ... 섹션별 parts.append() (inline <code> 포함 OK)
final_html = "\n".join(parts)

# 검증
text_len = len(re.sub(r'<[^>]+>', '', final_html))
img_count = final_html.count('<img ')
code_count = final_html.count('<code>') + final_html.count('<code ')
source_in_body = 'https://news.hada.io/topic?id=NNNN' in final_html
cjk_suspicious = re.search(r'[一-鿿]|[ぁ-ゔ]|[ァ-ヴー]', final_html)
print(f'PARTS_COUNT={len(parts)} CHARS={text_len} IMAGES={img_count} CODE_INLINE={code_count} SOURCE_IN_BODY={source_in_body} CJK_SUSPICIOUS={bool(cjk_suspicious)}')

Path('/tmp/post_NNN.html').write_text(final_html, encoding='utf-8')
```

```python
# /tmp/publish_NNN.py
import sys
from pathlib import Path
sys.path.insert(0, str(Path.home() / ".hermes" / "scripts"))
from tistory_publisher import load_cookies, publish_post

TITLE = "..."
TAGS = "tag1,tag2,..."  # comma-separated string (NOT list — 330차 정형)
CONTENT = Path("/tmp/post_NNN.html").read_text(encoding="utf-8")
SOURCE_URL = "https://news.hada.io/topic?id=NNNN"
GN_TOPIC_ID = "NNNN"

url = publish_post(
    load_cookies(),
    TITLE,
    CONTENT,
    tags=TAGS,  # str 필수
    visibility="public",
    category=1219746,  # int 필수
    source_url=SOURCE_URL,
    gn_topic_id=GN_TOPIC_ID,
)
if url and "tistory.com" in url:
    print(f"PUBLISH=SUCCESS URL={url}")
else:
    print(f"PUBLISH=FAIL url={url}")
```

실행:
```bash
unset PYTHONPATH PYTHONHOME
PYTHONNOUSERSITE=1
export PYTHONPATH=/Users/mac/Library/Python/3.9/lib/python/site-packages
/usr/bin/python3 -s /tmp/build_post_NNN.py
/usr/bin/python3 -s /tmp/publish_NNN.py
```

## 발행 후 동기화 (5-3 → 5-2-A 순서)

5-3 state.json 갱신 (last + details + KST timestamp):
```bash
unset PYTHONPATH
/usr/bin/python3 << 'PYEOF'
import json, datetime
from pathlib import Path
state_path = Path.home() / '.hermes' / 'memory' / 'blog_pipeline_state.json'
data = json.loads(state_path.read_text())
new_url = 'https://sigco.tistory.com/NNNN'
new_id = 'NNNN'
data['last_published_url'] = new_url
data['last_published_id'] = new_id
details = data.get('details', [])
if not details or details[-1].get('url') != new_url:
    kst = datetime.timezone(datetime.timedelta(hours=9))
    ts = datetime.datetime.now(kst).isoformat()
    details.append({
        'topic': 'NNNN', 'category': 'AI/ML',
        'title': '...', 'url': new_url, 'timestamp': ts,
    })
    data['details'] = details
state_path.write_text(json.dumps(data, ensure_ascii=False, indent=2))
print(f'[5-3] last=#{new_id} details_len={len(details)}')
PYEOF
```

5-2-A published_topics.json 누락 백필 + last 동기화:
```bash
unset PYTHONPATH
/usr/bin/python3 << 'PYEOF'
import json
from pathlib import Path
pt_path = Path.home() / '.hermes' / 'memory' / 'published_topics.json'
data = json.loads(pt_path.read_text())
state_path = Path.home() / '.hermes' / 'memory' / 'blog_pipeline_state.json'
state = json.loads(state_path.read_text())
existing_urls = {d.get('url') for d in data.get('details', [])}
backfilled = 0
for d in state.get('details', []):
    url = d.get('url')
    if url and url not in existing_urls and url.startswith('https://sigco.tistory.com/'):
        data.setdefault('details', []).append({
            'topic': d.get('topic', '?'),
            'title': d.get('title', ''),
            'hash': '', 'url': url,
            'date': (d.get('timestamp') or '')[:10] or '2026-07-31',
        })
        backfilled += 1
        existing_urls.add(url)
state_last_url = state.get('last_published_url')
if state_last_url:
    state_last_entry = state.get('details', [{}])[-1]
    data['last'] = {
        'topic': state_last_entry.get('topic', '?'),
        'title': state_last_entry.get('title', ''),
        'hash': '',
        'url': state_last_url,
        'date': (state_last_entry.get('timestamp') or '')[:10] or '2026-07-31',
    }
pt_path.write_text(json.dumps(data, ensure_ascii=False, indent=2))
print(f'[5-2-A] backfilled={backfilled} details_len={len(data["details"])} last_url={data["last"]["url"]}')
PYEOF
```

## 회고

346차는 "정형 그대로 재현" 차. 새 함정/관찰 없음 (Picsum read-timeout은 함수정 12 변형). parts.append() 정형 + code_lines 미사용 + inline `<code>`만 사용 → lint 정상 + 빌드 2,564자 + publish #1149 성공. **연속 all-green 120회차**.

다음 차 주의:
- by_category 영구 잔존 해소 추정 — 정수 ID 키가 사라진 이유 확인 필요 (사용자 게이트 or 코드 변경)
- inline `<code>` 다수 케이스의 안정성 추가 검증 (다음 차에 inline 6+회 테스트)
- Picsum read timeout 자동 재시도 안전성 추가 검증