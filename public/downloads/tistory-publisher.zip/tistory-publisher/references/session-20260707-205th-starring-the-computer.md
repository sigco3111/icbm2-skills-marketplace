# 205차 — 화면 속 컴퓨터 #914 발행 + Notion PATCH cleanup 강화

**날짜**: 2026-07-07
**임무**: Tistory cron 자동 발행
**결과**: 1편 정상 발행 (#914), drift 0

## 작업 요약

### 1단계: 세션 만료 가드
- §3.8.1 3-endpoint probe → 200 OK ✅

### 2단계: 트렌드 로드
- `blog_pipeline.py --refresh-topics` → 12개 토픽

### 3단계: Notion PATCH cleanup (영구화 단계 §3.20.1)
- 진입 시점에 이미 발행된 5건 + 1건 = 6건 PATCH
  - 31173 (Art Institute) → 비활성
  - 31169 (Figma) → 비활성
  - 31170 (덜한 것) → 비활성
  - 31158 (OpenTag) → 비활성
  - 31161 (OpenPrinter) → 비활성
  - 31177 (DRIFT) → 비활성 (state 매핑 자동)
- 매핑 소스: `state.last_topics` 자동 매핑 (1건) + 202/203차의 수동 `known_mappings` (5건)

### 4단계: 3중 dedup (§3.19 + §3.21)
- Notion 활성 12개 → 11개 (PATCH 1건 반영) → 6개
- dedup 통과: AI/ML 3개 (31174/31176/31179), 개발팁 3개 (31178/31166/31165)
- 점수 최고: AI/ML = 31179 (4.0, Starring the Computer), 개발팁 = 31165 (8.0)
- 명령 규칙상 AI/ML 우선 → **31179 Starring the Computer 선택**

### 5단계: 본문 작성
- `tistory_publisher.py --file` → 2,795자 (게시 기준), 6,374바이트 (소스)
- 14 H2, 이미지 2장 (Picsum retro computer on movie set)
- **#914 정상 발행**

### 6단계: §3.11 5단계 + §4 5-1 stats 보정
- Tistory max=914 / state last=913 / urls=913 / details=0 → **drift 3-way (publish path skip)**
- 보정 heredoc 실행:
  - state.last_topics append (913→914)
  - stats.total_published 897→898
  - stats.by_category[AI/ML] 703→704
  - stats.daily_counts[2026-07-07][AI/ML] 0→1
  - details append
  - published_urls.txt append
  - Notion PATCH 31179 → 비활성

### 7단계: §3.5 4-way 정합
- Tistory max=914 = state=914 = urls=914 = details=914 → **drift 0** ✅
- 이번 세션 단일 drift: 0

## 신규 / 발견 사항

### 1) state.last_topics source_url 비어있는 케이스
- 5건 (OpenTag, OpenPrinter, Art Institute, Figma, 덜한 것) 모두 `source_url=""`로 저장되어 있었음
- PATCH cleanup 시 `state.last_topics` 자동 매핑이 31177(DRIFT) 1건만 잡힘
- **해결**: 202/203차의 수동 `known_mappings` 사전을 fallback으로 사용 (5/5 성공)

### 2) stats.by_category[AI/ML] = 703 → 704
- 704라는 큰 수치는 누적 (오늘 첫 발행 = 0+1 = 1이 아님)
- 이는 §3.16 누적 drift (124) 의 일부 — `by_category`는 publish 횟수 기반, Tistory totalCount 기반이 아님
- 정상 (이번 세션 delta: +1)

### 3) details append 후 count=48
- §3.20.3 비대칭 tab 포맷으로 details 갱신 누락 누적 → 보정 시 48건
- 100개 cap 적용

## 후속 권장 작업 (다음 cron 임무)

1. **state.last_topics source_url 보강**: 기존 5건의 source_url을 채워서 자동 매핑 가능하게
   - `tistory_id → hada_url` 역매핑 테이블을 별도 파일로 유지
2. **누적 drift 124 정리**: §3.16 별도 cron 작업 (이번 임무 외)
3. **Layer 3 v2 자동화**: `scripts/rollback-fake-publish.sh`에 §3.20.1 PATCH cleanup 통합
4. **3중 dedup `last_titles[:50]` 제거**: §3.21 — 현 cron 작업에서는 적용 안 함 (3중 dedup은 source_url + hash + URL만 사용했음, title 패턴 자체를 안 씀)

## 발행 #914 메타

- **제목**: 화면 속 컴퓨터, 그 이름에 깃든 기억들 — Starring the Computer
- **카테고리**: AI/ML (1219746)
- **태그**: 영화, 드라마, 컴퓨터역사, 레트로, 오픈소스, IT역사
- **이미지**: Picsum retro computer on movie set (2장)
- **소스 URL**: https://news.hada.io/topic?id=31179
- **발행 URL**: https://sigco.tistory.com/914
- **게시 글자 수**: 2,795자 (CDN 업로드 후)
- **원본 글자 수**: 6,374 bytes (소스 .md)
