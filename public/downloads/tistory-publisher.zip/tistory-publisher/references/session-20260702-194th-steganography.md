# 194차 — Claude Code 스테가노그래피 (Tistory #901, 2026-07-02T04:00)

## 핵심 결론

**§8.5.2 "publish_post() 자동 동기화" 가설 무효화가 193차 단일 사례가 아니라 환경 의존 패턴으로 확정**됨. 193차/194차 모두 cron 자동 모드에서 `pt['last']`/`details[-1]`가 직전 글 그대로 stale. **§3.11 5단계 + §4 5-1 stats 보정 영구화 필수**.

## 발행 결과

| 항목 | 값 |
|---|---|
| 글 번호 | #901 (https://sigco.tistory.com/901) |
| 제목 | 클로드 코드는 요청에 스테가노그래피 표시를 하고 있음 — 바이너리에 숨은 분류 마커 분석 |
| 카테고리 | AI/ML (1219746) |
| 글자 수 | 3,838자 (검증 통과) / H2 7개 / 표 1개 |
| 이미지 | Picsum 2장 (encryption-steganography-binary-code-0/1) → CDN 업로드 2/2 |
| 소스 | 긱뉴스 #30980 (HTML `class=topic_contents` 폴백) |
| 세션 | 유효 (총 763개 글) |

## §8.5.2 무효화 2회 연속 재현 — 환경 의존 패턴 확정

| 회차 | 호출 환경 | 결과 |
|---|---|---|
| 191차 (가설 확립) | cron 자동 | details/last 자동 동기화 관측 |
| 192차 | cron 자동 | details/last 자동 동기화 관측 |
| **193차 (1차 무효화)** | cron 자동 | details/last #896 stale |
| **194차 (2차 무효화)** | cron 자동 | **details/last #900 stale** |

194차에서 동일 패턴 stale 재현 → 단일 우연 아닌 환경 의존 패턴 확정. 191차/192차의 "자동 동기화 관측"이 오히려 이례적 케이스였음.

### 194차 진단 출력 (발행 직후)

```bash
python3 -c "import json; pt = json.load(open('/Users/mac/.hermes/memory/published_topics.json')); ..."
# → last.url: https://sigco.tistory.com/900  (직전 글 — Ornith-1.0)
# → details[-1].url: https://sigco.tistory.com/900  (직전 글)
# → last.topic: Ornith-1.0 - 에이전트형 코딩을 위한 자기 개선 오픈소스 모델
```

## 보정 실행 (4단계 + 5-1)

1. Tistory URL HTTP 200 + og:title 매치 확인 ✅
2. `published_urls.txt` append (source + sigco) ✅
3. `blog_pipeline --record` 3-arg ✅
4. `pt['last']` + `details` 동시 append (last만 갱신하는 함정 회피) ✅
5-1. stats today 보정 (tistory_publisher 직접 호출은 daily_counts +1 안 함) ✅
5. 3중 신호 검증 (a/b/c 모두 정상) ✅

## 3중 신호 검증 결과

| 신호 | 판정 | 실제 값 |
|---|---|---|
| (a) details[-1].url | ✅ 정상 | `https://sigco.tistory.com/901` |
| (b) pt[last].url | ✅ 정상 | `https://sigco.tistory.com/901` |
| (c) stats today AI/ML | ✅ +1 | 9 → 10 |
| (d) stats total | ✅ +1 | 879 → 880 |

**진짜 가짜 발행: 0건.**

## 자동화 안전도 (194차 종료 시점)

| 지표 | 값 |
|---|---|
| 발행 글 | #901 — Claude Code 스테가노그래피 |
| stats total | 880 (5-1 수동 보정 후) |
| AI/ML today | 10 (5-1 수동 보정 후) |
| sigco URL 라인 수 | +2 (source + sigco) |
| §3.5 차이 | 539 (188차 false positive 패턴) |
| 진짜 가짜 발행 | 0건 |
| 세션 | 유효 (763개 글) |
| §3.11 5단계 + 5-1 | 매번 실행으로 확정 |

## 195차로 이월 TODO

1. `tistory_publisher.py` `publish_post()`가 항상 pt/details/urls.txt 동기화하도록 강제 — **우선순위 격상** (패턴 확정에 따른)
2. §3.11 5단계 + 5-1 stats 보정 영구화 스크립트 (`scripts/post-publish-correct.sh`) — 192차/193차 이월
3. §8.5.2 환경 의존성 원인 조사 (가설 ① 동일 URL skip, ② publish_post() 내부 상태, ③ cron 환경변수 차이) — **소스 코드 diff 추적 필요**

## 부가 발견

- 긱뉴스 `.md` endpoint 192KB 시도가 404 → HTML `class=topic_contents` 폴백 1차 시도 성공 (3,526자 추출)
- §3.13 endpoint 단수형 자동 안전 / §3.8 세션 사전 진단 정상 작동
- `execute_code` cron BLOCKED 제약 재확인 → terminal 도구로 즉시 전환
