# 259차 세션 (2026-07-14)

## 결과
**#993 만든 SaaS를 AI에게 말만 하면 등록되는 MCP 서버** 정상 발행.

- 카테고리: AI/ML (cat_id=1219746)
- gn_topic_id: 31397
- 점수: 10점 (FRESH 1순위)
- URL: https://sigco.tistory.com/993
- 본문: 1165자 (300자 가드 통과)
- 이미지: 2장 (Picsum ID 62, query: ai assistant chat message registration form submission)
- 라이브 GET: status=200, size=53699

## 검증
- §3.8.1: status=200, ct=application/json;charset=UTF-8, cookie_count=8 ✅
- §3.5 5중 신호: 사전 `#992` → 사후 `#993` 모두 일치 ✅
- §3.11 sync: pt_updated=true, state_updated=true, triple_signal_match=true, errors=[] ✅
- daily_counts[2026-07-14]['AI/ML']: {}→{AI/ML: 1} (+1 정확, cat_id 누설 0) ✅
- state.details 69→70, pt.details 85→86 ✅
- cleanup cron 임무 #16 dry-run: ✅ 누설 없음 (45회 연속 all-green) ✅
- 연속 all-green 45회차 (213~259차) ✅

## 정책 적용
- TOP 12 후보 (전 차) 31370/31373/31387/31381/31374 = 5개 PUB 처리됨 (258차까지)
- FRESH 잔여 7개 모두 AI/ML (31397/31376/31390/31378/31375/31367/31389)
- §3.34 #21 AI/ML 우선 정책 — FRESH 다수 AI/ML → AI/ML 1순위 (31397, 10점)
- §3.34 #22 ('기타' 제외) 정책 무효 — FRESH 후보에 '기타' 없음

## §3.34.46 신규 발견 — gn-fetch-content.py URL stale

`scripts/gn-fetch-content.py` 의 `GN_MD_URL = "https://news.hada.io/topic.md?id={tid}"` 가 dead path 라고 박혀있으나, **실제 작동 URL은 `https://news.hada.io/topic/{tid}.md`** (예: `https://news.hada.io/topic/31397.md`).

**증거**:
- 227~232차 기록: 6회 연속 100% 404 (dead path)
- 259차 실전 호출: `requests.get("https://news.hada.io/topic/31397.md")` → status=200, 1251 bytes
- 응답 본문: 깨끗한 markdown (frontmatter + metadata + 본문 + 댓글)

**영구화 패치 후보 (#23 cleanup cron 임무)**:
`gn-fetch-content.py` 의 `GN_MD_URL` 을 `f"{GN_TOPIC_BASE}/{tid}.md"` 로 1줄 정정하면 1단계 `.md` fallback 이 가장 신뢰성 있는 fetch 경로로 부활. HTML 파싱 fallback의 비표준 마크업 함정과 RSS summary fallback의 짧은 길이 함정을 모두 우회 가능.

**임시 우회 (영구화 전까지)**:
- `scripts/gn-fetch-md.py` 신규 (이 skill 의 scripts/ 에 위치) — 직접 `/topic/{tid}.md` 호출
- 또는 1회성: `requests.get("https://news.hada.io/topic/{tid}.md")`

259차는 임시 우회 (`/tmp/fetch_31397_md.py` 직접 작성) 로 본문 확보. 다음 차에 정식 패치 또는 본 skill 스크립트 사용 권장.

## 신규 발견
- §3.34.46 + cleanup cron 임무 #23: gn-fetch-content.py URL stale
- 모든 기존 패턴 정상 동작
- draft 본문은 한국어 가이드 형태 (topic summary → 핵심 코드/실제 사용법 → 왜 흥미로운가 → 참고 링크) — 후속 차도 동일 템플릿 가능