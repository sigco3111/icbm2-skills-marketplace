# 236차 세션 — 고전 게임 한글화 에이전트 스킬 #953 발행 (2026-07-10)

## §3.34.32 핵심 발견 (NEW)

### 1. `tistory_publisher.py --category` int 강제
- `--category 'AI/ML'` → `argparse: error: argument --category: invalid int value: 'AI/ML'`
- 정답: `--category 1219746` (int ID 직접 전달)
- 매핑 확인: `python3 ~/.hermes/scripts/tistory_publisher.py --categories` 서브커맨드 사용
- **혼동 원인**: `blog_pipeline.py --category 'AI/ML'`은 string OK. 두 스크립트의 인자 처리가 다름. cron 프롬프트에 둘 다 같은 형식으로 적혀 있어 발생.
- **영구화 권장**: cron 프롬프트의 §2단계 헤더를 "각 카테고리마다 `python3 blog_pipeline.py --category 'AI/ML'` (string) → `python3 tistory_publisher.py --category 1219746` (int ID)"로 명시 분리. 또는 환경변수/매핑 dict로 통일.

### 2. `state.daily_counts` 구조 함정
- 구조: `{date: {category: count}}` (dict-of-dict-of-int)
- 잘못된 코드: `state['stats']['daily_counts'][today] = state['stats'].get('daily_counts', {}).get(today, 0) + 1`
  → `TypeError: unsupported operand type(s) for +: 'dict' and 'int'` (왼쪽이 dict여서 +1 불가)
- 정답:
  ```python
  state['stats']['daily_counts'].setdefault(today, {})
  state['stats']['daily_counts'][today]['AI/ML'] = state['stats']['daily_counts'].get(today, {}).get('AI/ML', 0) + 1
  ```
- **영구화 권장**: state sync heredoc 템플릿을 `references/state-sync-template.py`로 만들어 둔다. 카테고리 추가 시 setdefault로 안전하게 +1.

### 3. `post-publish-correct.sh` 6-arg 시그니처 shift 함정 실제 재현
- 헤더에 이미 명시된 함정이지만 본 세션에서 1차 호출 시 실제 만남:
  ```bash
  bash .../post-publish-correct.sh "고전 게임을 한글화하는 방법론" \
    "https://sigco.tistory.com/953" "31266" "AI/ML"  # ← 4-arg만
  ```
- 결과: SRC_URL 자리에 `"AI/ML"` (카테고리명) 박힘, CATEGORY는 빈값
- 정정: 6-arg 호출
  ```bash
  bash .../post-publish-correct.sh \
    "고전 게임을 한글화하는 방법론" \
    "Show GN: 고전 게임을 한글화하는 방법론을 담은 에이전트 스킬" \
    "https://sigco.tistory.com/953" \
    "https://news.hada.io/topic?id=31266" \
    "AI/ML" \
    "31266"
  ```
- 5-1단계 stats 보정으로 today AI/ML=2, total=32 (post-publish-correct.sh가 자동 +1)
- §3.34.31 6단계 state sync heredoc으로 state 파일 동기화 완료 (details[-1]=953, daily_counts[2026-07-10][AI/ML]=3)

## 발행 결과

| 항목 | 값 |
|---|---|
| tistory # | 953 |
| source topic | news.hada.io/topic?id=31266 |
| 카테고리 | AI/ML (1219746) |
| 제목 | Show GN: 고전 게임을 한글화하는 방법론을 담은 에이전트 스킬 |
| 본문 | CJK 1,820자 (validate 통과) |
| 이미지 | Picsum 2장 → Kakao CDN 71KB+135KB |
| OG 썸네일 | 자동 설정 |
| source footer 검증 | 21번째 |
| cleanup cron | 23회 연속 all-green (213~236차) |

## 본문 (publish된 body)

1. 도입: AI로 고전 게임을 한글화한다는 발상 (Opus 4.6 + Max20 × 2)
2. 핵심 내용 3섹션: 플랫폼별 텍스트 압축 포맷 역공학 / Opus 4.6 컨텍스트 활용과 검증 루프 / 코드 개입 최소화를 위한 도구 인터페이스
3. 실용 팁 4항목: 도구 우선 설계 / 시각 피드백 루프 / 한글 폰트 모듈 분리 / 컨텍스트 윈도우 절약
4. 전망: 고전 게임 보존과 로컬라이제이션의 미래
5. 요약 5 bullet
6. 출처 footer (news.hada.io 링크)

## cleanup cron 임무 현황 (236차)

- ✅ cron 임무 #12 `gn-fetch-content.py` 영구화: **claim 거짓 확정** (스킬 디렉토리 내부에만 존재, `~/.hermes/scripts/`에는 없음)
- ⏳ cron 임무 #1 `retroactive-gn-topic-id.py` 영구화: 미완료
- ⏳ cron 임무 #15 historical drift health check: 미구현
- cleanup 23회 연속 all-green

## 다음 세션 권장 액션

- cron 프롬프트 헤더의 §2단계에 `tistory_publisher.py` int ID 매핑 명시 (AI/ML=1219746 외에 다른 카테고리도 검증 필요)
- state sync heredoc을 재사용 가능한 `references/state-sync-template.py`로 추출
