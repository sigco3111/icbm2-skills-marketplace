# 197차 세션 노트 — 7/6 세션 만료 회복 + 가짜 발행 36건 롤백 + 자동화 패치

## 배경
196차(7/2)에서 §3.8.1 Zombie 302 적중 → cron 단순 skip + §3.5 3중 신호 검증으로 가짜 발행 0건 확인.
**그러나 다음 cron 시도부터 196차 가드가 적용 안 됨** → 4일 누적 가짜 발행 36건 (7/3~7/6).

## 진단 (7/6 06:53 KST, 희정님 요청)
1. `tistory_publisher.py --check` → ❌ `Expecting value: line 2 column 2 (char 2)`
2. 3-endpoint probe → §3.8.1 Zombie 302 (HTTP 302 + Location `/auth/login`)
3. `published_topics.json` 검증 → 마지막 정상 발행 7/2 #903, details 7/3 이후 0건
4. `daily_counts` 7/3~7/6 = AI/ML 38 + 개발도구 8 = **46건 가짜 발행 누적**
5. `last_topics` 20건 중 20건 모두 가짜 (details에 박힌 topic과 매치 안 됨)

## 회복 (7/6 06:55 KST, A-2 진행)

### 1단계: env 갱신
- `tistory.env.bak.20260706_065213` 백업 생성
- 사용자 제공 2종 (TSSESSION + _T_ANO) 갱신
- REACTION_GUEST / __T_ / __T_SECURE = 1 fallback 유지 (스크립트 권장 default)
- 환경 갱신 라인 카운트: TISTORY_* 5개 키 모두 정상

### 2단계: 3-endpoint probe (§3.8.1 해소 확인)
- ✅ `/manage/posts.json`: HTTP 200 + application/json
- ✅ `/manage/category.json`: HTTP 200 + application/json
- ✅ `/` (블로그 홈): HTML, 정상 공개 페이지 (false positive일 뿐)

### 3단계: `--check-session`
- `✅ 세션 유효 (총 766개 글)` (#903이 마지막 — 가짜 발행은 실제론 안 올라감)

### 4단계: 가짜 발행 롤백
- 백업: `/Users/mac/.hermes/migration_fix_backup_20260706_065519_blog_rollback`
- 롤백 카테고리별: `{'AI/ML': 28, '개발도구': 8}` (총 36건)
- stats.total_published: 924 → 888
- daily_counts 7/3~7/6: 모두 0으로 초기화
- by_category: AI/ML 725→697, 개발도구 137→129
- last_topics: 20건 모두 가짜로 판정 → 0건 (details에 박힌 topic set과 매치 안 됨)

### 5단계: 자동화 패치
- **5-A**: 매일 아침 7시 세션 체크 cron 신규 등록 (`🍪 Tistory 세션 일일 체크`, job_id 0b0e9f44e10a)
  - PASS면 1줄 보고, FAIL이면 3-endpoint probe 진단 + 텔레그램 알림 + 가짜 발행 누적 추산
- **5-B**: 기존 Tistory 발행 cron (`📝 Tistory 자동 발행`) prompt 갱신
  - 발행 직전 3-endpoint probe (heredoc) — §3.8.1 적중 시 단순 skip (가짜 발행 차단)
  - §3.11 5단계 + §4 5-1 stats 보정 워크플로 매번 실행 영구화
  - 다음 실행: 2026-07-06 19:00 KST
- **5-C**: `scripts/rollback-fake-publish.sh` 신규 (가짜 발행 격차 자동 검출 + 일별 롤백)
  - dry-run 지원 (`--dry-run`)
  - 격차 계산: `stats.total_published - (details 박힌 sigco URL의 최대 번호)`
  - 격차 양수면 daily_counts 최근 일자부터 차감 → stats.total_published → by_category 3개 필드 동시

## 자동화 안전도 (197차 종료 시점)

| 지표 | 값 |
|---|---|
| 마지막 정상 발행 | #903 (195차, 7/2) |
| 197차 신규 발행 | 0 (회복 작업만) |
| 가짜 발행 누적 | 0건 (3중 신호 + 5-B 가드 활성) |
| 세션 | ✅ 유효 (총 766개 글) |
| §3.5 3중 신호 | 정상 (변동 없음) |
| stats 격차 | -15 (188차 정정 false positive 패턴, 자동화 정상) |
| §3.11 5단계 + 5-1 | 영구화 완료 (195차+196차+197차 확정) |
| 세션 체크 cron | 매일 7시 (`0b0e9f44e10a`) |
| 발행 가드 | 매일 19~次日 06시 (`b1bca63a117a`) — 다음 실행 19:00 |

## 만료 분석 — 왜 일주일 만에 만료됐는가 (197차 신규 발견)

### 단서 3개
1. **env 갱신일**: 184차 6/29 08:18 → 196차 7/2 skip → 7/6 만료 확인 = **총 8일**
2. **184차 reference**: "REACTION_GUEST 누락 → 기본값 1로 채움" + `__T_/__T_SECURE`도 1 fallback
3. **이전 백업**: `tistory.env.bak.1782688685` (184차 시점) 단 1개 — 이전 쿠키 비교 불가

### 가설 4개 (확률순)
- **가설 ① (단독 결정적일 수 있음)**: Tistory 보안 정책 변경 — anonymous 세션 idle timeout 단축
- **가설 ②**: Tistory 측 absolute expiration (계정 단위, 7~30일)
- **가설 ③**: `_T_ANO` 1회용 토큰 의심 (Kakao OAuth anonymous 단기 만료)
- **가설 ④**: PC CRD/Chrome 원격 데몬 문제로 브라우저 측 세션 인증 신호 사라짐

### 가장 가능성 높은 조합: ① + ④
- Tistory가 6월 이후 anonymous 세션 정책 강화 + Chrome 데몬 종료로 브라우저 측 세션 인증 신호 사라짐
- 둘 다 사실이면 "예전 3개월 → 지금 8일" 정상이 됨

### 실측 가능 (다음 만료 시점 측정)
- **5-A cron이 매일 세션 체크** → 다음 만료 발생 시 정확한 시점 (만료 후 며칠 만에 skip됐는지) 측정 가능
- 5-A cron의 출력이 누적되면 패턴 확정

## 신규 발견 (197차) — 2건

### 1. 가짜 발행 격차 음수 가능성 (false positive 패턴 확정)
- **격차 = stats.total_published - (details 최대 sigco 글 번호)**
- 정상 상태에서도 음수 가능 (188차 정정 — sigco URL 카운트 vs stats 격차 false positive 패턴)
- 이번 회복 후: stats 888 vs max sigco #903 → **격차 -15** (정상)
- 가짜 발행 자동 롤백 스크립트(`rollback-fake-publish.sh`)에서 격차 ≤ 0이면 skip — false positive 방지

### 2. 발행 cron 가드 부재 (196차 §8.11.3 워크플로 미적용)
- 196차에서 확립한 skip 워크플로(§3.11 5단계 skip + §3.5 3중 신호 검증)가 다음 cron 시도부터 적용 안 됨
- 원인: §3.11 5단계는 publish 후 검증 단계, **publish 직전 만료 감지 가드가 누락**
- 197차 패치: 발행 cron prompt 앞에 3-endpoint probe heredoc 추가 — publish 전 만료 시 단순 skip

## §3 가짜 발행 누적 패턴 — 영구화 권고

가짜 발행 차단은 3가지 레이어로 구성:
1. **Layer 1 (5-B publish cron 가드)**: 발행 직전 3-endpoint probe → §3.8.1 적중 시 publish 단계 진입 차단
2. **Layer 2 (196차 §3.11 5단계 skip 워크플로)**: publish 시도 후 만료 감지 시 details/last/urls.txt 동기화 skip
3. **Layer 3 (197차 `rollback-fake-publish.sh`)**: 누적 격차 자동 검출 + 일별 롤백 (5-A cron이 daily report로 격차 추적)

이제 197차 종료 시점엔 3-layer 모두 활성. **다음 만료 시점**: 5-A cron이 자동 감지 + 즉시 알림.

## 임시 파일 정리
- `/tmp/draft_*.md`, `/tmp/news_*.md`, `/tmp/news_*.html`, `/tmp/check.html` 모두 없음 (이번 세션에서 생성 안 함)

## 다음 cron (198차+) 이월 TODO
1. `tistory_publisher.py --check` 명령이 §3.8 vs §3.8.1 구분 출력 (현재는 둘 다 동일 에러 — 196차 이월 TODO 그대로)
2. `scripts/diagnose-tistory-session.sh` 영구화 (196차 heredoc 패턴 + 5-A cron에서 활용 가능)
3. `scripts/post-publish-skip-if-expired.sh` 영구화 (196차 이월)
4. `verify-tistory-cookie.sh`를 `rollback-fake-publish.sh`와 통합 — 단일 `tistory-health-check.sh`로 (5-A cron에서 활용)
5. 5-A cron이 7/6 07:00에 첫 실행됨 — 결과 모니터링 + 만료 패턴 데이터 누적 시작
6. **§3 가짜 발행 격차 자동 알림**: 격차 > N 일때 텔레그램 알림 (현재는 격차 -15 음수 정상, 0건)

## 결정적 신규 메트릭 (5-A cron 1주일 누적 후)
- **쿠키 발급 후 만료까지 평균 일수** (이번 회복: 8일 = 184차~197차)
- **세션 만료 skip 후 첫 사용자 알림까지 시간** (이번 회복: 4일 = 196차~7/6)
- **가짜 발행 일일 누적** (이번 회복: 7/3=10, 7/4=11, 7/5=11, 7/6=4)
