# 348차 세션 노트 (2026-07-31 19:01)

**발행 글**: #1156 "AI 미학 — ✨·반짝이는 텍스트·작은 아이콘이 만드는 새로운 소프트웨어 관용구" (gn=32004, AI/ML, 본문 2,214자 / 발행 측정 2,293자 + Picsum 2장)

## 세션 결과
- **단일 패스 43연속** + parts.append() 정형 43연속 + §3.5 신호 4 disambiguate 42연속 + 진입 5-5 23연속 + fallback 복귀 35연속
- **324차 `--content` 단일 폴백 정형 11회차 검증** (324→344→345→346→347→**348**)
- 5-2-A 누락 백필 1건 (state.json엔 #1156, published_topics.json엔 누락 → 정형 패턴 정상)
- 5-5 proxy check disambiguate 통과: status=200 + og:title 정확 + source_present=True + cjk_suspicious=0 → §3.5 신호 4 = 구조적 오탐 확정
- daily_counts={AI/ML:8}, total=152
- 연속 all-green **122회차**

## 워크플로우
1. §3.8.1 가드 통과 (status=200, first_id=1155)
2. `--refresh-topics` → 12개 트렌드 새로고침
3. `--category 'AI/ML'` → status=ready, gn=32004 (AI 미학, Jim Nielsen's blog)
4. 긱뉴스 og:description (~200자) + `<article><section class='article-content' itemprop='articleBody'>` 셀렉터로 본문 추출 (ul/li/h2/hr 구조 정확)
5. parts.append() 패턴으로 본문 빌드 (text_len=2214, 측정 2293자, CJK 의심 0)
6. `tistory_publisher.py --content` 직접 전달 → #1156 발행 성공 (Picsum 2장 자동 업로드 37KB+49KB)
7. `blog_pipeline.py --commit` → stats.today={AI/ML:8}, total=152, by_category["1219746"]=1 (297차 정형 잔존)
8. 5-3 (state.json last+details, KST timestamp) + 5-2-A (published_topics.json 백필+last 동기화) 정형 순서 (336차 보강)
9. §3.5 신호 4 발동 (구조적 오탐 — 5-3에서 last+details 동시 갱신) → 5-5 proxy check로 disambiguate → 정상 발행 확정

## 새 함정 / 관찰
- **없음** — 347차까지 모든 패턴 그대로 재현, 새 함정/관찰 0건
- **긱뉴스 article 본문 추출 셀렉터 안정화 확인**: `<article>` 안의 `<section class='article-content' itemprop='articleBody'>` 셀렉터로 ul/li/h2/hr 구조가 정확히 추출됨. 305차 단일 패스 패턴이 그대로 유효
- **빌드 vs 발행 측정 차이 ~79자** (2214 → 2293): publish_post()가 source_url footer 자동 박기 + HTML entity 미세 차이로 추정
- **OG 썸네일 자동 설정**: `https://blog.kakaocdn.net/dna/crqqCv/dJMcacjFX5Z/AAAAAAAAAAA...` (publish_post() 자동)
- **함정 8 by_category["1219746"]=1 영구 잔존 49연속 재확인** (297→348 = 52차 동일 유지, 사용자 게이트 시 ID_TO_NAME 1회 보정 권장, cron은 drift 보고만)

## 정형 워크플로우 검증 체크리스트
- [x] §3.8.1 가드: status=200 + content_type=application/json
- [x] 2-a: `--category 'AI/ML'` status=ready
- [x] 3-a 단일 호출 (함정 13 회피)
- [x] 3-b publish: `--content` 단일 폴백 (324차+339차 정형, 11회차 검증)
- [x] parts.append() + CJK 의심 0 (함정 25 + 26 회피)
- [x] code_lines 분리 불필요 (코드 블록 0개, 346차 판정 매트릭스 (a) 케이스)
- [x] 5-3 → 5-2-A 정형 순서 (336차 보강)
- [x] §3.5 신호 4 → 5-5 proxy disambiguate (구조적 오탐 정상)
- [x] 5-2-A 누락 백필 1건 (300차 정형)
- [x] by_category["1219746"]=1 drift 보고 (cron은 보정 안 함)