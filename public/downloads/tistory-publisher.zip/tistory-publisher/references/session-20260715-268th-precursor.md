# 268차 (2026-07-15): `#1006 Precursor — Cloudflare의 세션 단위 봇 탐지 시스템`

## 한 줄 요약

**`#1006 Precursor — Cloudflare의 세션 단위 봇 탐지 시스템: 마우스 호와 인지 지연을 1조 요청 규모로 누적 평가하는 새로운 행동 서명`** (개발도구/1219748, gn=31437, 8점, FRESH 1순위) 정상 발행 — **연속 all-green 55회차 (213~268차)**.

## 워크플로 (267차와 동일 패턴, 5회째 검증)

1. **§3.8.1 가드 통과** — `env -i HOME=/Users/mac PATH=/usr/bin:/bin PWD=/Users/mac /bin/bash -c 'set -a; source ~/.hermes/secrets/tistory.env; set +a; /usr/bin/python3 << PYEOF ...'` 격리 bash 패턴. `status=200, ct=application/json;charset=UTF-8, cookie_count=8`. 세션 유효.

2. **§3.34.39 + §3.34.40 4-step 명시 패턴 (FRESH 4-field 매칭)**:
   - Step 1: `blog_pipeline.py --refresh-topics --dry-run` → 12개 후보 + 점수
   - Step 2: 격리 python으로 FRESH 식별 (pt/state details 4-field 셋 lookup)
   - Step 3: 점수 1순위 픽
   - Step 4: 명시 publish

3. **FRESH 매트릭스 분석 (267차 패턴 그대로)**: AI/ML FRESH=0 (31404/31435/31411/31406/31424/31407 모두 262~267차 PUB 처리), FRESH 잔여:
   - 31437 (개발도구, 8점) — **1순위 픽**
   - 31408 (개발팁, 6점)
   - 31434 (투자/경제, 5점)
   - 31422 (기타, 1점)
   - §3.34.45 정책: '기타' 제외 + 점수 1순위 픽 → **31437 (개발도구 8점) 확정**

4. **§3.34.46 영구화 경로 fetch** — `_try_md_endpoint(31437)` → status=200, **10444 bytes** 즉시 fetch (gn-fetch-content.py 261차 영구화). 본문 4487자 정규화 후.

5. **§3.34.47 격리 빌드 패턴 (264~267차 4회째, 268차 5회째)**: `/tmp/tistory_drafts_268th/build_draft_31437.py` 에 `write_file` 로 UTF-8 선언 + 저장 → `python3 <script>.py` 격리 호출. §3.34.41 f-string 백슬래시 제약 회피. 빌드 결과: body_html 5397자, FULL_HTML 6692자 (평문 4836자, 300자 가드 통과).

6. **§3.34.48 `* ` 분기 + 4단계 헤더 강등 정규식 5회째 적용** — 268차 본문은 모두 `- ` 패턴이라 hit 없었지만 안전 가드로 정착 코드 그대로 복사.

7. **Publish** — `tistory_publisher.py --title ... --category 1219748 --file draft.html --source-url ... --gn-topic-id 31437 --image-query "cloudflare bot defense security network shield fingerprint"`. 이미지 2장 CDN 업로드 (Picsum ID 407 동일 매칭).

8. **§3.11 sync (5-1 자동 보정)** — `post_publish_sync.py sync --url #1006 --title ... --gn-topic-id 31437 --category 개발도구 --category-id 1219748 --source-url ...`. 결과: `pt_updated: true / state_updated: true / errors: [] / triple_signal_match: true`.

9. **§3.5 5중 신호 일치 검증**: state.last_published_url / state.last.url / state.details[-1].url / pt.last.url / pt.details[-1].url 모두 `https://sigco.tistory.com/1006` 일치. `all_match: True`.

10. **cleanup cron 임무 #16 dry-run** — `cleanup_daily_cat_id_leak.py --dry-run` → ✅ 누설 없음 (`54→55회 연속 all-green`, 213~268차).

11. **라이브 페이지 직접 GET 검증**: `curl https://sigco.tistory.com/1006` → status=200, size=73840 bytes, `<title>` 태그 = `Precursor &mdash; Cloudflare의 세션 단위 봇 탐지 시스템: 마우스 호와 인지 지연을 1조 요청 규모로 누적 평가하는 새로운 행동 서명` (실제 발행 확인).

## §3.34 핵심 함정 (268차 신규 식별)

### §3.34.50 (268차, NEW): cron 차 사이 외부 발행 흔적 1회성 패턴

**관찰**: `/tmp/tistory_drafts_268th/` 디렉토리에 `build_draft.py` + `draft-31431-xcode-no-gui.html` 파일이 이미 존재했음 (267차 직후 시점 누군가 작성한 흔적, 31431은 268차 시작 시점에 이미 `#1005`로 publish 완료된 상태). state.details[-1] = 31431 (`#1005`) 정상 박힘 + `/tmp/tistory_drafts_268th/` 잔재 동시 발견.

**영향**: 영향 없음 — 5중 신호 검증 모두 일치하여 drift 무해. **회피 불필요** — cron 차 사이에 다른 자동화 또는 수동 발행이 일어날 수 있다는 사실은 이미 §3.34.44 (253차)에서 정착.

**운용 가이드 추가**: cron 차 시작 시 `/tmp/tistory_drafts_<session>/` 디렉토리가 **이전 세션 잔재로 채워져 있어도 무시** — 해당 잔재는 이전 차의 publish 사이클 또는 다른 자동화 인스턴스의 부산물일 수 있음. 본 세션의 draft는 무조건 새로 빌드 (덮어쓰기 또는 신규 파일명). 차감/추가 없음 — 단순 관찰로 종결.

## 본 세션 검증 결과

| 항목 | 값 |
|------|-----|
| §3.8.1 가드 | status=200, ct=application/json, cookie_count=8 ✅ |
| FRESH 4-field | 모두 일치 ✅ |
| 본문 검증 | 평문 4836자, 300자 가드 통과 ✅ |
| 이미지 CDN | 2장 업로드 성공 (Picsum ID 407) ✅ |
| 5중 신호 | all_match: True ✅ |
| post_publish_sync | pt_updated / state_updated / triple_signal_match 모두 true ✅ |
| daily_counts[2026-07-15] | `{AI/ML: 1, 개발도구: 2}` (개발도구 +1 정확) ✅ |
| state.details | 81 → 82, pt.details 97 → 98 ✅ |
| cat_id 누설 | 0 (cleanup #16 dry-run ✅) ✅ |
| 라이브 GET | status=200, size=73840, title tag 일치 ✅ |

## 누적 워크플로 정착 (264~268차 동일 패턴 5회째)

- §3.34.39 + §3.34.40 4-step 명시 패턴 (FRESH 4-field 매칭)
- §3.34.46 `.md` 영구화 endpoint 직접 호출 (임시 우회 불필요)
- §3.34.47 격리 빌드 패턴 (write_file + UTF-8 선언 + `/tmp/<session>/build_draft.py`)
- §3.34.48 `* ` 들여쓰기 리스트 분기 + 4단계 헤더 강등 정규식
- §3.34.43 PWD 환경변수 또는 `cd /Users/mac` 명시
- §3.11 sync 5-1 자동 보정 (7필드 원샬)
- §3.5 5중 신호 검증 (pt/state 5필드 일치)
- cleanup cron 임무 #16 cat_id 누설 dry-run

## 신규 학습

- **본 세션 신규 발견 없음** — 267차 정착 워크플로 그대로 정상 동작. 차감/추가 없음.
- 264차 `#1000` → 265차 `#1002` → 266차 `#1003` → 267차 `#1004` → **268차 `#1006`** 5회 연속 동일 워크플로 정착 검증.

## 카테고리 균형 (268차 발행 기준)

| 카테고리 | 2026-07-15 누적 |
|----------|----------------|
| AI/ML | 1 (267차 #1004 GhostLock) |
| 개발도구 | 2 (268차 #1006 Precursor, 본 세션) + 1 (외부 #1005 Xcode 31431, 267차 후속) |

운영 정상 — cron 자동 발행 + 수동/외부 발행이 자연스럽게 섞여 일일 다중 카테고리 발행이 이루어지는 패턴 (253차 §3.34.44 정착).
