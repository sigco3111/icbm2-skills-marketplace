# 334차 세션 기록 — Bun Zig→Rust 마이그레이션 발행

## 결과

- 선정 topic: `AI로 11일 만에 끝낸 Bun의 Zig→Rust 재작성에서 배울 점`
- GeekNews URL: `https://news.hada.io/topic?id=31890`
- 실제 제목: `AI로 11일 만에 끝낸 Bun의 Zig→Rust 재작성에서 배울 점 — 개발자가 알아야 할 핵심 정리`
- Tistory URL: `https://sigco.tistory.com/1130`
- 카테고리: AI/ML (`1219746`)
- 본문 빌드: `HTML_BYTES=9595`, `TEXT_CHARS=3549`, `IMAGE_COUNT=2`, `H2_COUNT=8`, 의심 CJK 치환 0
- publish wrapper: `/tmp/publish_334.py`, `tags`는 comma-separated 문자열로 전달
- 실제 publish 출력: 이미지 2장 CDN 업로드 성공, OG 썸네일 설정, `PUBLISH=SUCCESS URL=https://sigco.tistory.com/1130`
- proxy: HTTP 200, `og:title` 정확 일치, source URL 포함, `立场/立場/自走/說明` 흔적 없음
- commit: `daily_counts[2026-07-29]`의 AI/ML이 1에서 2로 증가, 전체 124건
- 상태 보정: `last_published_url=#1130`, `last_published_id=1130`, state details와 published_topics details/last 동기화, canonical hash=`md5("31890")`=`b6cce1d2ea012409f22932d7e11c396e`

## 재현 절차

1. 발행 직전 기본 `session_expiry_guard.sh`를 실행한다. 가드 자체가 환경 오류로 실패하면 publish하지 않고, `TISTORY_*`를 source한 안정 raw probe로 `manage/posts.json`의 `HTTP 200 + application/json + items[0].id`를 확인한다.
2. `blog_pipeline.py --refresh-topics` 후 `--category 'AI/ML'`을 **한 번만** 실행하고 JSON 결과를 저장한다. 이번에는 gn=31890이 선정됐다.
3. topic과 SEO 확장 제목을 별도 중복 검사한다. 이번 결과는 두 검사 모두 `is_duplicate=false`, `match_count=0`이었다.
4. 본문은 큰 f-string 대신 `parts.append()` 배열로 작성하고, 별도 `/tmp/build_post_334.py`를 실행한다. build 출력의 바이트 수·텍스트 길이·이미지 수·source URL·CJK 검사 결과를 확인한다.
5. `/tmp/publish_334.py`에서 `publish_post(load_cookies(), TITLE, CONTENT, tags=TAGS, visibility='public', category=1219746, source_url=..., gn_topic_id='31890')`를 호출한다. `tags`는 리스트가 아니라 문자열이다.
6. 숫자형 실제 URL을 얻기 전에는 `commit_publish()`와 상태 파일 수정을 하지 않는다. 이번 실제 URL은 #1130이었다.
7. URL proxy에서 `HTTP 200`, `og:title == 실제 제목`, source URL 포함, 본문 CJK 의심 문자열 부재를 확인한다.
8. `blog_pipeline.py --commit TOPIC TITLE URL 'AI/ML' SOURCE_URL`을 호출한 뒤 state의 last URL/id/details를 보정한다. published_topics는 URL idempotency와 canonical topic hash를 함께 보장한다.
9. 최종 `check_state_consistency.py`가 신호 4로 exit 1을 내더라도, 새 URL proxy가 통과하면 구조적 오탐이다. 이번 세션에서도 `daily_counts={'AI/ML': 2}`와 details[-1]=#1130 때문에 같은 경고가 발생했고, proxy PASS로 정상 발행을 확정했다.

## 핵심 교훈

- 상태 검사기의 신호 4는 “새 슬롯이 실제로 존재하는가”를 직접 확인하지 않는다. 5-3이 last와 details를 같은 새 URL로 맞추는 정상 경로에서도 발동한다. 따라서 proxy 검증은 선택이 아니라 disambiguation 단계다.
- `commit_publish()`는 통계를 갱신하지만 last URL/id와 published_topics를 모두 완결하지 않을 수 있다. 성공 URL을 확보한 뒤 3개 SSOT를 명시적으로 확인·보정한다.
- 본문 품질은 `og:title`만으로 검증되지 않는다. sibling write warning 또는 CJK 텍스트가 있는 환경에서는 response body grep을 추가한다.
- `by_category["1219746"]` 같은 기존 SSOT drift는 자동으로 합치지 않는다. 사용자 게이트 대상은 탐지·보고만 한다.
