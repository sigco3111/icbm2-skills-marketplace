# 247차 세션 (2026-07-11) — §3.34.43 격리 패턴 PWD/cd 함정 + #966 htmldrop 발행

## 발행 결과
- **1건 발행**: `https://sigco.tistory.com/966`
- **주제**: AI가 만든 HTML, 링크 하나로 바로 공유하기 — htmldrop과 MCP로 끝내는 공유 파이프라인 (8점, gn 31300)
- **카테고리**: AI/ML (1219746)
- **draft**: `/tmp/tistory_drafts_247/draft-31300-htmldrop-link.md` (2060자)

## §3.34.43 (NEW) — 격리 패턴 bash 자동 `cd` 함정

### 발생 시점
247차 `post_publish_sync.py sync` 첫 호출 시. `env -i HOME=... PATH=... /bin/bash -c '...'` 명령이 다음 에러로 exit 126:

```
/opt/homebrew/bin/bash: 행 2번: cd: /Users/mac/.hermes/repos/icbm2-knowledge-graph: No such file or directory
```

bashrc의 `cd /Users/mac/.hermes/repos/icbm2-knowledge-graph` 자동 실행 → 디렉토리 부재 → bash 서브쉘 종료 (exit 126 = 외부 명령 실패) → 본 python3 호출 안 됨.

### 회피 패턴 (3가지)
1. `PWD=/Users/mac` 환경변수를 env -i 리스트에 추가
2. bash 첫 줄에 `cd /Users/mac` 명시
3. bash 거치지 않고 python3 heredoc 직접 (단 source 단계 필요한 경우 불가)

### 247차 적용
- `PWD=/Users/mac` 박스로 sync 호출 → `triple_signal_match: true` 정상
- SKILL.md 본문 §3.8.2 / §3.11 / §3.34.40 4-step 4곳 모두 `PWD=/Users/mac` 추가
- §3.34.43 신규 섹션 등록, 절대 하지 말 것에 추가, cleanup 임무 #19 등록

## 검증 단계 전체 통과 (32회 연속 all-green)
- §3.8.1 가드: 200 OK + JSON, cookie count=8
- §3.34.40 FRESH 4-field: TOP 1 = 31308 (PUB 처리) → 후순위 FRESH 31300 픽
- §3.5 5중 신호: publish 전후 모두 일치 (직전 #965 → 신규 #966)
- §3.11 sync: `triple_signal_match: true`
- §3.34.33 cat_id 누설 가드: daily_counts[2026-07-11]['AI/ML'] = 9 (정확한 +2)
- cleanup cron 임무 #16 dry-run: 누설 없음

## 학습 (영구화)
- **§3.34.43 격리 패턴 PWD/cd 함정**: 모든 `env -i ... bash -c` 호출에 `PWD=/Users/mac` 또는 `cd /Users/mac` 명시 필수

---

## 247차 후속 실행 (cron 자동 발행 작업) — 검증 추가

위 차에서 SKILL.md 본문에 §3.34.43을 영구화한 직후, cron 자동 발행 작업이 이어졌고 §3.34.43 회피 패턴을 실전 검증했다.

### 발행: 1건 (#968)
- **#968** — 사람이 유지보수할 것처럼 코드를 작성하라 — LLM이 흡수해 되돌려줄 코드 패턴은 좋은 상태로 유지해야 한다
  - category: AI/ML (1219746)
  - GN topic: 31307 (5점)
  - 본문: 2426자
  - 이미지: Picsum 2장
  - URL: https://sigco.tistory.com/968

### §3.34.43 실전 적용 검증
- 격리 호출에 `PWD=/Users/mac` 박스로 sync 호출 → `triple_signal_match: true` 정상 반환
- `cd /Users/mac` 보조 패턴도 publish 단계에서 적용 — 두 회피 패턴 모두 정상 동작 확인

### 검증 단계 전체 통과 (33회 연속 all-green)
- §3.8.1 가드: 200 OK + JSON, cookie count=8
- §3.34.40 FRESH 4-field: 12개 후보 중 FRESH 9개 식별, TOP 1 = 31307 (5점, 미발행)
- §3.5 5중 신호: 모두 `https://sigco.tistory.com/968` 일치
- §3.11 sync: `triple_signal_match: true`
- §3.34.33 cat_id 누설 가드: daily_counts[2026-07-11]['AI/ML'] = 11 (10 → 11, +1 정확)
- cleanup cron 임무 #16 dry-run: 누설 없음 (33회 연속)

### 새로운 발견 없음
이번 차는 246~247차에 정리된 §3.34.43, §3.34.39, §3.34.41 패턴이 모두 정상 동작함을 검증한 안정 운영 회차. SKILL.md 본문 추가 수정 불필요.

## 다음 차 후보 (FRESH 잔여 8개)
- 31305 (5점, 개발도구), 31323 (4점, AI/ML), 31326 (3점), 31320 (3점), 31315 (3점), 31313 (3점), 31309 (3점), 31301 (3점)

## 다음 차 권장 작업
1. FRESH 잔여 후보 중 점수순으로 다음 픽
2. §3.34.42 verify-tistory-cookie.sh 격리화 패치 적용 여부 결정 (246차 발견 사항, 미적용)
3. §3.34.41 f-string §3.8.1 코드 패치 후보 (`scripts/guard_tistory_session_39safe.py`) — 246차 발견, 미적용
4. cleanup cron 임무 #1 retroactive-gn-topic-id 영구화 (231차 ~920건 drift, 후순위)

## 핵심 마일스톤
- **cleanup cron 임무 #16 33회 연속 all-green** (213~247차) — 운영 안정성 정착
- **연속 all-green 35회차** (213~247차) — 전체 cron 자동화 워크플로 안정
