# 247차 세션 (2026-07-11) — §3.34.43 격리 패턴 PWD/cd 함정 + #966 htmldrop 발행

## 발행 결과
- **1건 발행**: `https://sigco.tistory.com/966`
- **주제**: AI가 만든 HTML, 링크 하나로 바로 공유하기 — htmldrop과 MCP로 끝내는 공유 파이프라인 (8점, gn 31300)
- **카테고리**: AI/ML (1219746)
- **draft**: `/tmp/tistory_drafts_247/draft-31300-htmldrop-link.md` (2060자)

## §3.34.43 (NEW) — 격리 패턴 bash 자동 `cd` 함정

### 발생 시점
247차 `post_publish_sync.py sync` 첫 호출 시. `env -i HOME=... PATH=... /bin/bash -c '...'` 명령이 다음 에러로 exit 126:

```
/opt/homebrew/bin/bash: 행 2번: cd: /Users/mac/.hermes/repos/icbm2-knowledge-graph: No such file or directory
```

bashrc의 `cd /Users/mac/.hermes/repos/icbm2-knowledge-graph` 자동 실행 → 디렉토리 부재 → bash 서브쉘 종료 (exit 126 = 외부 명령 실패) → 본 python3 호출 안 됨.

### 회피 패턴 (3가지)
1. `PWD=/Users/mac` 환경변수를 env -i 리스트에 추가
2. bash 첫 줄에 `cd /Users/mac` 명시
3. bash 거치지 않고 python3 heredoc 직접 (단 source 단계 필요한 경우 불가)

### 247차 적용
- `PWD=/Users/mac` 박스로 sync 호출 → `triple_signal_match: true` 정상
- SKILL.md 본문 §3.8.2 / §3.11 / §3.34.40 4-step 4곳 모두 `PWD=/Users/mac` 추가
- §3.34.43 신규 섹션 등록, 절대 하지 말 것에 추가, cleanup 임무 #19 등록

## 검증 단계 전체 통과 (32회 연속 all-green)
- §3.8.1 가드: 200 OK + JSON, cookie count=8
- §3.34.40 FRESH 4-field: TOP 1 = 31308 (PUB 처리) → 후순위 FRESH 31300 픽
- §3.5 5중 신호: publish 전후 모두 일치 (직전 #965 → 신규 #966)
- §3.11 sync: `triple_signal_match: true`
- §3.34.33 cat_id 누설 가드: daily_counts[2026-07-11]['AI/ML'] = 9 (정확한 +2)
- cleanup cron 임무 #16 dry-run: 누설 없음

## 학습 (영구화)
- **§3.34.43 격리 패턴 PWD/cd 함정**: 모든 `env -i ... bash -c` 호출에 `PWD=/Users/mac` 또는 `cd /Users/mac` 명시 필수
