# 243차 세션 노트 — blog_pipeline pick 순환 + state 경로 불일치

**날짜**: 2026-07-11
**세션 차수**: 243
**트리거**: Tistory cron 자동 발행 워크플로 한계 발견

## 핵심 발견 3가지

### (a) `blog_pipeline.py --category 'AI/ML'` 후보 pick이 점수 무관

cron이 `python3 ~/.hermes/scripts/blog_pipeline.py --category 'AI/ML'` 실행:

```json
{
  "status": "ready",
  "topic": "나는 Stanley Lieber를 죽이지 않았다: 9front로 그리는 법",
  "source_url": "https://news.hada.io/topic?id=31301",
  "category": "AI/ML"
}
```

점수 3점 후보(31301) pick. 다시 실행:

```json
{
  "status": "ready",
  "topic": "Tencent, 오픈소스 모델 Hy3 공개",
  "source_url": "https://news.hada.io/topic?id=31290"
}
```

이미 발행된 `#958 Hy3` 재pick. 즉 fresh 후보(19점 LLM 번아웃 31286) 무시, 마지막 published 토픽 주변 순환.

**원인 추정**: `blog_pipeline.run_pipeline`의 `_select_topic`이 점수 정렬 결과 대신 published_urls.txt 기반 회피 → 캐시·큐 소진 → 마지막 항목 fallback. 코드 미추적 (다음 차 정밀 디버깅 권장).

### (b) `--force-topic <id>` 가 source_url/topic_url 미주입

```
python3 ~/.hermes/scripts/blog_pipeline.py --force-topic '31286' --category 'AI/ML'
```

출력:
```json
{
  "topic": "31286",
  "source_url": "",
  "topic_url": ""
}
```

→ 본문 작성 단계의 `tistory_publisher.py --source-url <URL>` 인자로 전달할 값 없음.

**함의**: cron 컨텍스트에서 LLM 본문 작성 1500자+를 자동으로 처리해야 하지만, `tistory_publisher.py --source-url` 인자 + draft 1500자 본문이 모두 필요. **cron-only 자동 publish는 사실상 불가**.

### (c) `post_publish_sync.py sync-from-pt` 의 state 경로 오류

코드 (스킬 본문에 명시된 위치):
- `~/.hermes/state/tistory_state.json`

실제 부재. 진짜 통합 state:
- `~/.hermes/memory/blog_pipeline_state.json`

결과 `sync-from-pt` 호출시 `pt_updated: true / state_updated: true / errors: [] / triple_signal_match: true` 반환하지만, state 파일이 코드 경로에 부재하여 **사실상 noop** — pt만 자기 자신 동기화.

이번 차는 5중 신호가 모두 `#959` 일치하여 drift 무해. 다음 차(`post_publish_sync.py`) 패치 권장:
- `STATE_FILE = HERMES_DIR / 'memory' / 'blog_pipeline_state.json'` 으로 정규화
- 또는 별도 helper인 `scripts/integrated_state_path.py` 가 통합 lookup

## 발행 skip 사유 최종 (4가지 누적)

1. §3.5 5중 신호 ✅ 모두 `#959` 일치
2. today=2026-07-11 AI/ML 2건 발행 이미 완료 (#958 Hy3 + #959 GPT 5.6)
3. blog_pipeline pick 순환 버그 — fresh 후보 무시, published 주변 순환
4. --force-topic source_url 미주입 — cron 자동 publish 실행 불가

## 진단 정상 지표

- §3.8.1 세션 가드: ✅ `manage/posts.json` 200 OK
- §3.5 5중 신호: ✅ 모두 `#959`
- cleanup cron 임무 #16 dry-run: **29회 연속 all-green** (cat_id 누설 없음)
- sync-from-pt 호출: `triple_signal_match: true` (noop이지만 false negative 없음)

## 다음 차 권장 패치

1. `scripts/post_publish_sync.py` — `STATE_FILE` 경로를 `memory/blog_pipeline_state.json` 으로 정규화
2. `blog_pipeline.py --category 'AI/ML'` 의 pick 알고리즘을 explicit score 순 정렬 + fallback 큐 분리
3. cron 자동 publish 워크플로 자체 재설계 (본문 작성 단계는 사람/LLM 컨텍스트 필수 명시)
