# 200차 세션 노트 (2026-07-06) — `--record-topic` 환경 의존 3회 연속 확정

## 한 줄 결론
`tistory_publisher.py --record-topic`은 **publish API만 standalone**, record path는 caller 모듈 의존. cron 환경에서 3회 연속 record path silent fail → **§3.11 5단계 + §4 5-1 stats 보정 = 항상 필수 영구 단계**로 완전 격상.

## 타임라인
- 20:00 cron 진입, §3.8.1 3-endpoint probe → 200 OK (세션 유효)
- 20:00 blog_pipeline.py --refresh-topics → 긱뉴스 12개 갱신
- 20:01 blog_pipeline.py --category 'AI/ML' → dbtrail 주제 가이드라인 출력 (stats +1 pre-increment)
- 20:01 dbtrail 본문 .md 작성 (3,437자, H2 7개)
- 20:02 tistory_publisher.py --file → **#907 정상 발행** + "주제 record 완료" 출력
- 20:02 §3.5 3중 신호 검증 → **discrepancy 발견**:
  - Tistory max: 907 ✅
  - local urls max: 906 ❌ (record 미실행)
  - last_topics[-1].url: /906 ❌
  - details[-1]: (없음) ❌
  - stats.total: 890 (기대 891) ❌
- 20:03 §3.11 5단계 + §4 5-1 stats 보정 heredoc 실행 → 4필드 + urls 동시 갱신
- 20:03 재검증: Tistory=907, local=907, last_topics=/907, details=/907, stats=891, daily=1 ✅ **drift 0**

## 핵심 발견

### `--record-topic` 환경 의존 패턴 (3회 연속)

| 차수 | 환경 | publish 성공 | record 출력 | stats 갱신 | 영향 |
|---|---|---|---|---|---|
| 191차 | manual (희정님 직접) | ✅ | "record 완료" | ✅ 갱신됨 | 정상 |
| 193차 | cron 자동 | ✅ | "record 완료" | ❌ 미갱신 | publish +0, stats +0 |
| 194차 | cron 자동 | ✅ | "record 완료" | ❌ 미갱신 | publish +0, stats +0 |
| **200차** | **cron 자동** | **✅** | **"record 완료"** | **❌ 미갱신** | **publish +1, stats +0** |

**원인 분석**:
- `tistory_publisher.py`의 `record_published_topic()` 함수는 `blog_pipeline.record_published_topic`을 import해서 호출
- cron 환경에서 `tistory_publisher.py`가 standalone으로 실행되면 blog_pipeline 모듈 import는 성공하지만, 내부 record_published_topic 함수 호출 시 **caller context의 state.json path/scope 차이**로 silent fail
- `print("주제 record 완료: ...")`는 함수 자체의 try/except 후속 메시지이므로, 실제 state.json 갱신이 안 됐는데도 "완료" 출력

### record 의존성 제거 워크플로 (영구 단계)

`--record-topic` 인자 사용을 **deprecated** 처리. 대신:

1. publish 완료 후 publish 출력 URL을 받음
2. **Tistory max id 1페이지만 직접 fetch** (record 의존 0)
3. `last_topics[-1].url`의 id가 max보다 1 작으면 → **무조건 보정 코드 실행**
4. 보정 코드는 `terminal` + `python3 heredoc`으로 stats/last_topics/details/published_urls.txt 4곳 동시 갱신

상세 코드는 SKILL.md §3.17 참조.

## 환경 의존 체크리스트 (다음 cron 작업 시)

- [ ] `tistory_publisher.py --file`로 publish 실행
- [ ] publish URL 출력값 (`https://sigco.tistory.com/NNN`) 캡처
- [ ] Tistory page1 max id 직접 fetch
- [ ] `last_topics[-1].url`의 id와 max id 비교
- [ ] **반드시 stats 보정 heredoc 실행** (4필드 + urls)
- [ ] §3.5 3중 신호 재검증

## 가짜 발행 0건 검증
- 진입 시 ① last_topics 필터링 → round*/test*/debug 없음 ✅
- ② published_urls.txt에 #99[6-9] 페이크 ID 없음 ✅
- ③ Tistory max id 906 vs local 906 = gap 0 ✅
- 199차 잔재 모두 정리된 상태에서 진입

## 통계
- 발행: 1건 (#907 dbtrail)
- 보정 작업: 1회 (5단계 heredoc)
- drift: 0 (이번 세션)
- 누적 drift: 121 (legacy, 195차 이전)
- §3.5 3중 신호: 모두 일치
- §3.11 5단계: 통과

## 후속 권장 작업
1. `scripts/post-publish-correct.sh`에 §3.17 5단계 보정 로직 통합
2. Layer 3 v2: `last_topics[-1].url.id` < `Tistory page1 top[0].id` → 자동 보정 트리거
3. 누적 drift 121 정리는 별도 cron 작업으로 분리 (이번 임무 외)
