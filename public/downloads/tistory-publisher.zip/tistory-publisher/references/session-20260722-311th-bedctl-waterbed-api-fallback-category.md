# 311차 — 수랭식 침대를 제어하는 API 클라이언트 bedctl (개발도구, AI/ML 후보 소진 → fallback 워크플로우 첫 실전 검증)

**날짜**: 2026-07-22 05:02 KST
**발행 글**: https://sigco.tistory.com/1074
**제목**: 수랭식 침대를 제어하는 API 클라이언트 bedctl — 잘 때만 코딩하는 개발자를 위한 가이드
**카테고리**: 개발도구 (1219748)
**긱뉴스 토픽**: https://news.hada.io/topic?id=31631 (gn=31631, score=4.0)
**연속 all-green**: 91회차

---

## 핵심 신규 발견 (311차 — 정형화 가치)

### 1. §3-B 신규 — AI/ML 후보 소진 시 다른 카테고리 fallback 워크플로우

사용자 instruction은 "AI/ML 우선 + 다른 카테고리 시도"를 명시했으나, SKILL.md 본문에는 정형 워크플로우가 없었다. 311차가 첫 실전 검증 사례.

**워크플로우**:
1. §3-a `blog_pipeline.py --category 'AI/ML'` 호출
2. 응답이 `status=skip` + `"reason": "... 카테고리의 긱뉴스 주제와 트렌드 주제 모두 소진되었습니다"` → **AI/ML 후보 소진**
3. 같은 차 cron은 곧바로 fallback 카테고리 시도 (우선순위: 개발도구 → 개발 팁 → iOS/Swift → 투자/경제 → 아이디어 → 기타)
4. §3-b `blog_pipeline.py --category '개발도구'` → `status=ready` + topic 선정
5. §3-b publish 단계: `--category 1219748` (int) 호출
6. §3-b.5 commit_publish: 마지막 위치 인자에 `"개발도구"` (str) 전달

**311차 실측**:
- §3-a `blog_pipeline.py --category 'AI/ML'` → `status=skip` ("AI/ML 카테고리의 긱뉴스 주제와 트렌드 주제 모두 소진되었습니다")
- §3-b fallback: `--category '개발도구'` → `status=ready` + gn=31631 "수랭식 침대를 제어하는 API 클라이언트 bedctl" (Notion 12순위 score=4.0)
- §3-b publish: `--category 1219748` (int) → #1074 발행 성공
- §3-b.5 commit: `--commit ... "개발도구" ...` (str) → stats.today={AI/ML:5, 개발도구:1}, total=68

### 2. 함정 16 신규 (311차) — publish/commit 카테고리 인자 타입 차이

publish의 `--category`는 int(1219748)지만 commit의 카테고리 인자는 str("개발도구"). 두 호출의 카테고리 인자 타입이 다르다.

**혼동 시**:
- publish: `argument --category: invalid int value: '개발도구'` 에러로 즉시 종료
- commit: stats.by_category에 새 str 키 누적 (예: `"개발도구": 1` 정상 or `"개발도구_잘못된_형태": 1` 오염)

**원칙**:
- `tistory_publisher.py --category` = `<int>` (1219746, 1219747, 1219748, 1219750, 1219751, 1219752)
- `blog_pipeline.py --commit` 마지막 위치 인자 = `<str 카테고리명>` (AI/ML, 개발도구, 개발 팁, 투자/경제, 기타, 아이디어)

### 3. 신호 4 오탐 disambiguate 14연속 확정 (310차 13연속 → 311차 14연속)

§3.5 진입 시점에서 daily_counts[2026-07-22]={AI/ML:5} (어제 23:01~오늘 01:01 사이 #1069/#1070/#1071/#1072/#1073 누적) + state.last=#1073 + details[-1]=#1073 → 신호 4 FAKE_PUBLISH 발동.

5-5 proxy check에서 #1069/#1070/#1071/#1072/#1073 모두 status=200 + og:title 정확 매칭 확인 → **오탐 확정**, 발행 단계 진입.

310차 + 311차 모두 진입 단계 신호 4가 이미 발동했지만 5-5 disambiguate로 정상 publish 진행 → 진입 시점 신호 4 = 발행 skip 사유 아님, 직전 차 proxy check만 통과하면 publish 진행 패턴 **2연속 확정**.

### 4. §3-B 함정 회피 5중 동시 확인

| 함정 | 회피 방법 | 311차 적용 |
|------|-----------|------------|
| 함정 6 (heredoc + env -i SyntaxError) | 본문 빌드는 write_file + `/usr/bin/python3 -s /tmp/build_post_XXX.py` 분리 | ✅ build_post_311.py + /usr/bin/python3 -s |
| 함정 7 (--category int만) | publish 호출 시 int(1219748) 전달 | ✅ publish `--category 1219748` |
| 함정 8 (by_category["1219746"]=1 영구 잔존) | drift 보고만, 임의 자동 보정 금지 | ✅ 311차도 동일 유지 (14연속) |
| 함정 11 (execute_code cron 차단) | write_file + `/tmp/build_post_311.py` 분리 | ✅ 정상 작동 |
| 함정 14 (import os 누락) | heredoc 첫 줄에 `import os, requests, re` | ✅ §3.8.1 / 5-5 모두 적용 |
| 함정 15 (5-5 격리 누락) | §1단계와 동일 격리 패턴 (`unset PYTHONPATH PYTHONHOME; PYTHONNOUSERSITE=1; export PYTHONPATH=user-site; /usr/bin/python3 -s`) | ✅ 5-5 적용 |
| **함정 16 (publish/commit 카테고리 타입)** | publish=int, commit=str 분리 | ✅ publish=1219748, commit="개발도구" |

### 5. 305차 단일 패스 패턴 6연속 정형화

`build_post_311.py` 안에 `requests.get(gn_url) + <meta property="og:description"> regex` 임베드 → 160자 description 추출 + Picsum 이미지 2장 (seed: bedctl-waterbed-control / bedctl-temperature-schedule) + 본문 2738자 빌드. 함정 3 (긱뉴스 본문 selector 코멘트만) + 함정 6 (heredoc + env -i SyntaxError) + 함정 11 (`execute_code` cron 차단) 3중 동시 회피.

305→306→307→308→309→310→**311**차 6연속 동일 패턴으로 정형화.

---

## 발행 상세

### §3.8.1 raw 검증 결과

```
status=200
content_type=application/json;charset=UTF-8
cookies_count=8
first_ids=['1073', '1072', '1071', '1070', '1069']
✅ OK: 세션 유효, 발행 진행
```

직전 발행 #1071 (310차)에서 #1073까지 2건 추가됨 (어제 23:01~오늘 01:01 사이 cron 누적).

### §3.5 신호 4 검증

```
today=2026-07-22 daily_counts={'AI/ML': 5} (total=5)
last_published_url=https://sigco.tistory.com/1073
last_topics[-1]={'topic': '31663', 'category': 'AI/ML', 'title': 'Nativ - 프런티어급 오픈 모델을 Mac에서 로컬 실행', 'url': 'https://sigco.tistory.com/1073', 'timestamp': '2026-07-22T04:02'}
⚠️ DRIFT 감지:
  - 가짜 발행 의심 (FAKE_PUBLISH): daily_counts[2026-07-22] 합계=5 지만 details[-1]=#1073 (last_published_url 변동 없음)
⚠️ FAIL: §3.5 drift (가짜 발행 의심 — §3.11/§4 보정 검토)
```

### 5-5 proxy check (5건 모두)

```
#1069: status=200 title='인간 수학자, 반례 찾기에서 AI에 추월당하다 &mdash; 세 난제와 Lean 검증 흐름 한 번에 정리' og:title='인간 수학자, 반례 찾기에서 AI에 추월당하다 — 세 난제와 Lean 검증 흐름 한 번에 정리'
#1070: status=200 title='Kimi Work: 지식 노동자를 위한 차세대 데스크톱 AI 에이전트 &mdash; Cron&middot;로컬 파일&middot;자동화를 한 화' og:title='Kimi Work: 지식 노동자를 위한 차세대 데스크톱 AI 에이전트 — Cron·로컬 파일·자동화를 한 화면에'
#1071: status=200 title='OpenCode의 성가시고 불안한 문제들 &mdash; 로컬 Qwen3.6-27B 실전에서 드러난 4가지 결함' og:title='OpenCode의 성가시고 불안한 문제들 — 로컬 Qwen3.6-27B 실전에서 드러난 4가지 결함'
#1072: status=200 title='구글 제미나이 새 모델(3.6 Flash, 3.5 Flash-Lite, 3.5 Flash Cyber) 출시 &mdash; 개발자가 알아야 할 모' og:title='구글 제미나이 새 모델(3.6 Flash, 3.5 Flash-Lite, 3.5 Flash Cyber) 출시 — 개발자가 알아야 할 모든 것'
#1073: status=200 title='Nativ - 프런티어급 오픈 모델을 Mac에서 로컬 실행' og:title='Nativ - 프런티어급 오픈 모델을 Mac에서 로컬 실행'
```

5건 모두 status=200 + og:title 정확 매칭 → **진짜 발행 확인, 신호 4 오탐 14연속 확정**.

### §3-a + §3-b fallback 워크플로우

**§3-a (AI/ML 시도)**:
```bash
unset PYTHONPATH PYTHONHOME
PYTHONNOUSERSITE=1
export PYTHONPATH=/Users/mac/Library/Python/3.9/lib/python/site-packages
/usr/bin/python3 -s ~/.hermes/scripts/blog_pipeline.py --category 'AI/ML'
```
응답: `{"status": "skip", "reason": "'AI/ML' 카테고리의 긱뉴스 주제와 트렌드 주제 모두 소진되었습니다"}`

**§3-b (개발도구 fallback)**:
```bash
unset PYTHONPATH PYTHONHOME
PYTHONNOUSERSITE=1
export PYTHONPATH=/Users/mac/Library/Python/3.9/lib/python/site-packages
/usr/bin/python3 -s ~/.hermes/scripts/blog_pipeline.py --category '개발도구'
```
응답: `status=ready` + gn=31631 "수랭식 침대를 제어하는 API 클라이언트 bedctl"

### §3-b publish 단계

```bash
set -a; source ~/.hermes/secrets/tistory.env; set +a
unset PYTHONPATH PYTHONHOME
PYTHONNOUSERSITE=1
export PYTHONPATH=/Users/mac/Library/Python/3.9/lib/python/site-packages
/usr/bin/python3 -s ~/.hermes/scripts/tistory_publisher.py \
  --title "수랭식 침대를 제어하는 API 클라이언트 bedctl — 잘 때만 코딩하는 개발자를 위한 가이드" \
  --tags "bedctl,수랭식침대,Chilipad,개발도구,CLI,수면자동화,HomeAssistant,시스템자동화" \
  --visibility public \
  --category 1219748 \
  --source-url 'https://news.hada.io/topic?id=31631' \
  --gn-topic-id 31631 \
  --file /tmp/post_311.html
```

응답:
```
📄 Content 검증 통과: 2101자
📝 제목: 수랭식 침대를 제어하는 API 클라이언트 bedctl — 잘 때만 코딩하는 개발자를 위한 가이드
🏷️  태그: bedctl,수랭식침대,Chilipad,개발도구,CLI,수면자동화,HomeAssistant,시스템자동화
🖼️  이미지 업로드 중... (1/2)
🖼️  이미지 업로드 성공: image.jpg (116KB)
🖼️  이미지 업로드 중... (2/2)
🖼️  이미지 업로드 성공: image.jpg (26KB)
🖼️ OG 썸네일 설정: https://blog.kakaocdn.net/dna/rP5nM/dJMcadizCUH/AAAAAAAAAAAA...
✅ 발행 성공!
🔗 https://sigco.tistory.com/1074
```

### §3-b.5 commit_publish (카테고리 str 인자)

```bash
/usr/bin/python3 -s ~/.hermes/scripts/blog_pipeline.py --commit \
  "31631" "수랭식 침대를 제어하는 API 클라이언트 bedctl — 잘 때만 코딩하는 개발자를 위한 가이드" \
  "https://sigco.tistory.com/1074" "개발도구" \
  "https://news.hada.io/topic?id=31631"
```

응답:
```json
{
  "committed": true,
  "stats": {
    "total": 68,
    "today": {"AI/ML": 5, "개발도구": 1},
    "by_category": {"AI/ML": 765, ..., "개발도구": 140, ..., "1219746": 1}
  }
}
```

### 5-3 last+details 통합 보정

```
[5-3] last=#1074 details_len=147
```

### 5-2-A 백필

```
[5-2-A] placeholder 보정 + 누락 백필=1, details_len=148
```

### 5-4 §3.5 (재실행 후)

```
today=2026-07-22 daily_counts={'AI/ML': 5, '개발도구': 1} (total=6)
last_published_url=https://sigco.tistory.com/1074
last_topics[-1]={'topic': '31631', 'category': '개발도구', 'title': '수랭식 침대를 제어하는 API 클라이언트 bedctl — 잘 때만 코딩하는 개발자를 위한 가이드', ...}
⚠️ DRIFT 감지:
  - 가짜 발행 의심 (FAKE_PUBLISH): daily_counts[2026-07-22] 합계=6 지만 details[-1]=#1074 (last_published_url 변동 없음)
```

### 5-5 #1074 proxy check (발행 직후)

```
status=200
title=수랭식 침대를 제어하는 API 클라이언트 bedctl &mdash; 잘 때만 코딩하는 개발자를 위한 가이드
og:title=수랭식 침대를 제어하는 API 클라이언트 bedctl — 잘 때만 코딩하는 개발자를 위한 가이드
```

status=200 + og:title 정확 매칭 → 진짜 발행 확인, 신호 4 오탐 확정.

---

## 운영 영향

### 일자 발행 누적

311차 daily_counts={AI/ML:5, 개발도구:1} (총 6건). 308차부터 누적량 증가 추세 (308차 10건 → 309차 11건 → 310차 새 차 누적 3건 → 311차 6건). 다중 발행 누적 상태에서도 §3.8.1 raw VALID + §3.5 신호 4 오탐 + 5-5 proxy check PASS disambiguate 패턴 14연속 안정적으로 작동.

### AI/ML 후보 소진 빈도

311차에서 첫 후보 소진 발생. 트래픽 분포상 AI/ML 카테고리가 긱뉴스에서 가장 자주 갱신되지만, 같은 차 cron이 빠르게 발행하면 같은 Notion 활성 후보가 빠르게 소진됨. fallback 워크플로우 정형화로 발행 연속성 보장.

### by_category 영구 누적 가속

311차 #1074 발행 후에도 by_category["1219746"]=1 동일 유지 (14연속). 코드 동작은 `=` 할당으로 첫 매핑 후 영구 누적. SSOT 변경이라 cron은 drift 보고만, 임의 자동 보정 금지.

---

## 다음 차 (312차+) 권장

1. **§3-B fallback 워크플로우가 정형화됨** — AI/ML 후보 소진시 자동으로 개발도구 → 개발 팁 → iOS/Swift 순으로 fallback. 더 이상 매 차 사용자 instruction 참고 불필요.

2. **진입 시점 신호 4 + 5-5 disambiguate 패턴 2연속 확정 (310차 + 311차)** — 새 차 cron이나 다중 발행 누적 시에도 §3.5 1차 검증에서 신호 4 발동 → 5-5로 직전 차 발행들 disambiguate 후 발행 단계 진입은 정상 워크플로의 일부. drift 라인에 따로 명시 불필요.

3. **by_category 영구 누적 사용자 게이트 보류** — 14연속 영구 잔존이지만 SSOT 변경이라 cron은 drift 보고만 유지. 사용자가 한 번 ID_TO_NAME 보정하면 영구 해결.

4. **글 발행 시 카테고리 fallback 사용 통계** — 추후 글 후보 소진 빈도가 높아지면 cron 로그에 fallback 발생 횟수 추적 가능 (311차 = 첫 발생).

---

## 한 줄 요약

311차 = #1074 "수랭식 침대를 제어하는 API 클라이언트 bedctl" 발행 + **§3-B fallback 워크플로우 첫 실전 검증** + 함정 16 (publish/commit 카테고리 인자 타입) 신규 + 신호 4 오탐 disambiguate **14연속 확정** + 305차 단일 패스 패턴 **6연속 정형화** + 함정 회피 5중 동시 확인. 연속 all-green 91회차.
