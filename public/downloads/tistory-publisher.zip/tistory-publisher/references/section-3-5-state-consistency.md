# §3.5 3중 신호 검증 — state drift 0 확인

## 목적

`~/.hermes/memory/blog_pipeline_state.json` 의 3개 필드가 일관된 상태인지 검증. publish 직후와 가드 skip 직후 **둘 다** 실행 — drift 0이면 정상, 비정상이면 가짜 발행 의심.

## 3중 신호

| 신호 | 필드 | 의미 |
|------|------|------|
| 1 | `last_published_url` | 직전 발행 슬롯 (sigco.tistory.com/NNN) |
| 2 | `daily_counts[YYYY-MM-DD]` | 오늘 카테고리별 카운트 |
| 3 | `last_topics[-1]` | 직전 발행 topic 메타 (topic/category/title/url/timestamp) |

## 검증 알고리즘 (288차 검증, drift=0 케이스)

```bash
unset PYTHONPATH
env -i HOME="$HOME" PATH=/usr/bin:/bin PYTHONPATH= \
  /usr/bin/python3 << 'PYEOF'
import json
from datetime import date
s = json.load(open('/Users/mac/.hermes/memory/blog_pipeline_state.json'))
today = date.today().isoformat()
dc = s.get('daily_counts', {}).get(today, {})
lt = s.get('last_topics', [])
print(f'today={today} daily_counts={dc}')
print(f'last_published_url={s.get("last_published_url")}')
print(f'last_topics[-1]={lt[-1] if lt else None}')
# 3중 신호 일관성:
#  - last_published_url != None 이면 last_topics[-1]도 있어야 함
#  - last_topics[-1]['url'] == last_published_url
#  - daily_counts[오늘] 카테고리 합계 ≥ 1 (오늘 발행이 있었다면)
ok = True
if s.get('last_published_url') and lt:
    if lt[-1].get('url') != s.get('last_published_url'):
        print('⚠️ DRIFT: last_topics[-1].url ≠ last_published_url')
        ok = False
print('✅ OK: 3중 신호 일치' if ok else '⚠️ FAIL: drift 감지')
PYEOF
```

## 정상 케이스 (288차)

```
today=2026-07-18 daily_counts={'AI/ML': 4, '개발팁': 1}
last_published_url=https://sigco.tistory.com/1043
last_topics[-1]={'topic': 'SpaceX IPO...', 'category': 'AI/ML', 'title': 'SpaceX 주가...', 'url': 'https://sigco.tistory.com/1043', 'timestamp': '...'}
✅ OK: 3중 신호 일치
```

## drift 감지시 의미

| 증상 | 가능한 원인 |
|------|----------|
| `last_published_url` 갱신됐는데 `daily_counts` 안 올라감 | §4 5-1 stats 보정 누락 |
| `daily_counts` 올랐는데 `last_published_url` 그대로 | publish는 됐는데 state sync 누락 (가짜 발행 의심) |
| `last_topics[-1].url` ≠ `last_published_url` | commit_publish() 도중 부분 실패 |
| `daily_counts[카테고리]` 합계 0인데 `last_published_url` 존재 | cat_id 누설 — §3.34 cleanup 필요 |

## 호출 시점

- **publish 직후** (성공한 경우): 5중 신호 일치 여부 확인
- **§3.8.1 가드 skip 직후** (실패로 skip한 경우): drift 0 확인 (가짜 발행 residue 검사)
- **cron daily_counts 정합성 자동 점검** (nightly-maintenance-workflow 등)

## 가짜 발행 vs 정상 skip 구분

| 상황 | daily_counts | last_published_url | 판정 |
|------|--------------|---------------------|------|
| §3.8.1 가드 skip | 변동 없음 | 변동 없음 | ✅ 정상 skip |
| 정상 publish 성공 | +1 | +1 | ✅ 정상 |
| daily_counts +1 + last_url 변경 안 됨 | +1 | 그대로 | ⚠️ 가짜 발행 (stats만 박힘) |
| last_url +1 + daily_counts 그대로 | 그대로 | +1 | ⚠️ publish 성공 + sync 누락 |

## 주의

§3.5 검증은 **로컬 state의 일관성**만 확인. Tistory 서버 측 actual URL 박힘 여부는 §3.11 5단계 (live page probe + details[-1].url) 에서 별도 확인 필요 — 가드 skip으로 publish를 안 한 288차 같은 경우엔 §3.11 step 5는 skip 가능.