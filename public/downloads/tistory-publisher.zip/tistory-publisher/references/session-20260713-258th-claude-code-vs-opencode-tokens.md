# 258차 세션 (2026-07-13)

## 결과

**#989 Claude Code는 프롬프트 전에 3.3만 토큰, OpenCode는 7천 토큰** 정상 발행.

- 카테고리: AI/ML (cat_id=1219746)
- gn_topic_id: 31373
- 점수: 15점 (FRESH 1순위)
- URL: https://sigco.tistory.com/989
- 본문: 792자 (300자 가드 통과)
- 이미지: 2장 (Picsum ID 504)
- 라이브 GET: status=200, size=59015

## 검증

- §3.8.1: status=200, ct=application/json;charset=UTF-8, cookie_count=8 ✅
- §3.5 5중 신호: 사전 `#988` → 사후 `#989` 모두 일치 ✅
- §3.11 sync: pt_updated=true, state_updated=true, errors=[] ✅
- daily_counts[2026-07-13]['AI/ML']: 4→5 (+1 정확, cat_id 누설 0) ✅
- state.details 65→66, pt.details 81→82 ✅
- cleanup cron 임무 #16 dry-run: ✅ 누설 없음 (43→44회 연속 all-green) ✅
- 연속 all-green 44회차 (213~258차) ✅

## 정책 적용

- TOP 12 후보 모두 AI/ML 카테고리
- FRESH 10개 모두 AI/ML
- #21 AI/ML 우선 정책으로 1순위 픽 (15점 31373)
- #22 ('기타' 제외) 정책 무효 — '기타' 후보 0개

## 사소한 관찰

**#22 정책 무효 케이스 (NEW)**: 256차에서 식별한 #22 정책 ('기타' 제외 > #21 AI/ML 우선) 이 FRESH 후보 모두 AI/ML인 경우 적용 불필요. 즉 #22는 **FRESH 후보에 '기타' 1개 이상 포함될 때만** 동작하는 가드. 정책 우선순위 매트릭스 (§3.34.45) 그대로 유효.

## 호출 함정 (1회성)

`strip-frontmatter.py <input.md> <output.txt>` — positional 2-arg 필수. 단일 인자 호출시 Usage 에러. 영구화 불필요 (즉시 재호출로 해결).

## 신규 발견

없음 — 모든 기존 패턴 (§3.8.1/§3.8.2/§3.5/§3.11/§3.34.39~45) 정상 동작.