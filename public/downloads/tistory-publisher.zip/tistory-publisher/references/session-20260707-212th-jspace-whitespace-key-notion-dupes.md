# 212차 — J-space #925 + `stats.by_category` 공백 변형 키 + Notion 동일 URL 11건 중복 + 3단계 매칭 42/42 (2026-07-07)

## 차수 요약
- **발행**: #925 "언어 모델 안의 글로벌 워크스페이스 — Anthropic이 발견한 J-space의 의미" (AI/ML 1219746, 1,875자 → strip 후 1,764자 Tistory 검증, 2 Picsum images)
- **선정 토픽**: 긱뉴스 31199 (J-space) / score 6.0 / Anthropic의 글로벌 워크스페이스 GWT 실험
- **3중 신호 검증**: Tistory 925 = state last /925 = details /925 = urls /925 → **drift 0**
- **누적 Notion cleanup**: 42/42 (205~212차)

## 신규 함정 4가지 (§3.29 영구화)

### §3.29.1 — `stats.by_category` 공백 변형 키 함정 (⭐ 최고 우선)

state.json에 동일 카테고리의 **공백 변형 키**가 별도로 누적된 문제 발견:
```json
"by_category": {
  "AI/ML": 709,
  "AI 뉴스": 1,        ← ⚠️ 변형
  "개발 팁": 1,        ← ⚠️ 변형
  "개발팁": 12,        ← ⚠️ 변형 (공백 없음)
  "개발": 1,            ← 부분 매칭
  "개발도구": 132,
  ...
}
```

§3.28.1 한글 key 함정과 별개 — 이미 **stale 데이터**가 누적된 상태에서 보정 시 `cat_key = '개발 팁'`이 1을 반환하고 `cat_key = '개발팁'`이 12를 반환하는 분기. **drift 0 단일 세션 검증은 통과**하지만 카테고리별 누적 카운트는 영구 정합성 깨짐.

**영구화 권장**: `normalize_cat_key()` 함수로 모든 변형 → 단일 정규화 키 매핑 후 보정.

### §3.29.2 — Notion 동일 긱뉴스 URL 11건 중복 페이지

publish #925 cleanup 시 긱뉴스 31199 URL이 **Notion DB에 11건 등록**되어 있음:
- 1건 active (이번에 비활성화)
- 10건 이미 inactive (과거 fire-and-forget silent fail 이력)

cleanup heredoc이 1건만 PATCH하므로 다른 매칭이 active로 남으면 무한 cleanup 루프 위험. **모든 매칭 PATCH**로 영구화.

### §3.29.3 — 3단계 매칭 영구화 42/42

| 매칭 단계 | 누적 | 212차 |
|---|---|---|
| 30자 prefix (§3.22.2) | ✅ 100% | 2/2 (GLM 5.2, Anthropic) |
| source_url 폴백 (§3.25.2) | ✅ 100% | 0/0 (이번은 30자로 처리) |
| URL 직접 매칭 (§3.28.2) | ✅ 100% | 2/2 (취미, 저커버그) |
| **모든 매칭 PATCH** (§3.29.2) | **✅ 신규** | **1/1 (J-space)** |
| **누적** | **42/42** | **5/5 (cleanup 4 + publish 1)** |

### §3.29.4 — 긱뉴스 `.md` endpoint GN+ 응답 200

191차 §8.5: 404 / 195차: 200 / **212차: 200 (14,728 bytes)**
- GN+ (GeekNews Plus) 표시 토픽도 정상 응답
- 폴백 체인 1순위로 확정

## 작업 타임라인 (13단계)

1. §3.8.1 3-endpoint probe: ✅ 200 OK 3/3
2. Tistory max id: 924 → 925
3. `blog_pipeline.py --refresh-topics`: 12개 토픽
4. 3단계 Notion PATCH cleanup: 4/4 (30자 2 + URL 직접 2)
5. 4중 dedup: AI/ML 4 fresh (J-space 6점 / Ryzen 3점 / Fable 3점 / GPT-5.6 5점)
6. score dict: gn_scores 12개 → 6점 J-space 선택
7. 3-tier fallback: AI/ML 4 fresh → 1순위 (발동 안 함)
8. 긱뉴스 `.md` endpoint: 200, 14,728 bytes
9. 한국어 본문 heredoc 1,875자 → strip → 1,764자 → publish #925
10. stats 보정: 한글 key 정상 +1 (cat_key = 'AI/ML')
11. §3.5 3중 신호 검증: ✅ drift 0
12. publish #925 (31199) cleanup: URL 직접 매칭 1/1
13. §3.29.1 발견: by_category 변형 키 2쌍 (`개발팁`/`개발 팁`, `AI 뉴스`/`AI/ML`)

## 핵심 교훈

1. **공백 변형 키 함정 (212차 최우선)**: §3.28.1 한글 key 함정과 별개. `normalize_cat_key()` 영구화 권장.
2. **Notion 중복 페이지 누적**: update_notion_topic_last_used()가 fire-and-forget으로 매번 신규 페이지를 만든 이력. cleanup 시 모든 매칭 PATCH 필수.
3. **3단계 매칭 누적 42/42**: 30자 prefix → source_url → URL 직접 fallback이 안정 동작.

## 차후 권장 작업 (별도 cron 임무)

1. **by_category 변형 키 합산 cleanup**: `개발팁: 12 + 개발 팁: 1 → 개발 팁: 13` (개발팁은 0으로), `AI 뉴스: 1 → AI/ML` 합산
2. **Notion 동일 URL 중복 페이지 archive**: 긱뉴스 URL당 가장 최근 1건만 유지, 나머지 archive
3. **누적 drift 121 정리**: §3.16 별도 5페이지 스캔 routine으로 121 정산
