# 218차 — fresh 후보 0개 (모두 이미 발행) + §3.34.3 `last_topics` 0개 정리 부작용 + gn_topic_id 박기 누락 발견 (2026-07-08)

## 배경

218차 cron에서 §3.30.4 0단계 state health check 통과 → §3.5 3중 신호 drift 0 → 1단계 `--refresh-topics` 12개 긱뉴스 토픽 수집. 그러나 2단계 진입 직전 **명백한 중복 패턴** 발견:

- AI/ML 1순위 후보 (Ternlight #31218)가 details에 이미 발행 (#930)된 긱뉴스
- §3.22.3 4중 dedup이 fresh=true로 잘못 분류
- 12개 후보 전수 매칭 결과 8개가 fresh로 분류되지만, **8개 모두 details에 이미 발행된 긱뉴스**

→ **fresh 후보 0개 → 발행 skip → §3.5 drift 0 유지** 결정.

## 핵심 발견 (§3.34.8 — 218차 신규, ⭐⭐ fresh 분류 정확도 함정)

### §3.34.8 — `last_topics` 0개 정리 + gn_topic_id 박기 누락의 부작용 (218차 신규)

**증상**: 
- §3.34.3 (217차) 패턴: 발행 후 `last_topics`에서 Tistory URL 박힌 항목 모두 제거 → 0개
- 211~212차 publish 시 `details.append()`에서 **`gn_topic_id` 필드 미박기** (post-publish 후크 버그)
- 결과: 218차 details에는 gn_topic_id가 31218 (Ternlight) **단 1건만** 박혀있음

**218차 12개 후보 4중 dedup 매칭 (수동 검증)**:

| 후보 topic_id | 후보 제목 | §3.22.3 4중 dedup 결과 | 실제 details |
|---|---|---|---|
| 31201 | Anthropic이 개발자 호감을 잃는 몇 가지 방법 | 🛑 LAST_TITLES | ✅ #921 발행 |
| 31209 | GLM 5.2와 다가오는 AI 추론 마진 붕괴 | 🛑 LAST_TITLES | ✅ #922, #926 발행 |
| 31203 | 저커버그, "AI 에이전트 기술이 기대보다 느리게 발전 | 🛑 LAST_TITLES | ✅ #923 발행 |
| 31207 | AI 시대에 취미가 곧 비즈니스 기회가 되는 이유 | ⚠️ FRESH (false negative) | ✅ #924 발행 |
| 31190 | Astryx - Meta가 공개한 오픈소스 디자인 시스템 | ⚠️ FRESH (false negative) | ❌ 미발행 |
| 31213 | gh-attach – CLI로 GitHub 이슈/PR에 이미지, 파일 첨부하기 | ⚠️ FRESH | ❌ 미발행 |
| 31204 | 언어 모델 안의 글로벌 워크스페이스 | ⚠️ FRESH (false negative) | ✅ #925 발행 |
| 31214 | ReactOS "오픈소스 Windows" 프로젝트, Half-Life 2 실행 가능해짐 | ⚠️ FRESH | ❌ 미발행 |
| 31195 | GPT-5.6 Sol Ultra는 Codex에 탑재될 것임 | ⚠️ FRESH (false negative) | ✅ #928 발행 |
| 31210 | 코드 청결도는 코딩 에이전트에 영향을 미치는가? 통제된 최소쌍 연구 | ⚠️ FRESH | ❌ 미발행 |
| 31218 | Ternlight, 브라우저(WASM)에서 실행되는 7MB 임베딩 모델 | 🛑 GN_PUBLISHED | ✅ #930 발행 |
| 31214 (sneakerweb) | sneakerweb - 물리 저장 매체로 전파되는 병렬 웹 | ⚠️ FRESH (false negative) | ✅ #929 발행 |

**§3.22.3 4중 dedup의 3단계 매칭이 모두 무력화된 이유**:

1. **gn_topic_id 단계**: details에 gn_topic_id가 31218 단 1건만 → 31218 Ternlight만 잡힘
2. **source_url 단계**: last_topics가 0개 (§3.34.3) → 모든 후보 source_url 매칭 실패
3. **last_titles prefix 단계**: 30자 prefix 매칭 (5건만 매칭 — title이 정확히 일치하는 경우만)

→ **prefix가 한 글자라도 다르면 (대시/콤마, "해자" vs "비즈니스 기회") false negative**:
- "취미가 곧 해자 — AI 시대에 살아남는 비즈니스 모델 3가지" (#924)
- "AI 시대에 취미가 곧 비즈니스 기회가 되는 이유" (긱뉴스 31207)
- 30자 prefix: `취미가 곧 해자 — AI 시대에 살아남는 비` vs `AI 시대에 취미가 곧 비즈니스 기회가 되` — 완전 다름

**영구화 권장**:

1. **`blog_pipeline.py`의 §3.22.3 4중 dedup에 5단계 추가**:
   ```python
   # §3.34.8 — 5단계: Tistory details의 topic_id 직접 매칭 (긱뉴스 topic_id와 별개)
   # 긱뉴스 글이 Tistory N번에 발행됐는지 검증
   published_tistory_ids = {it['topic_id'] for it in details.get('details', [])}
   # ... 후보 중 details에 이미 있는 후보는 skip
   ```

2. **post-publish 후크 수정** — `blog_pipeline.py`의 `details.append()`에 `gn_topic_id` 박기 단계 추가:
   ```python
   details['details'].append({
       'title': ..., 'url': ..., 'date': ..., 'category': ...,
       'topic_id': tistory_id,  # Tistory N번
       'gn_topic_id': gn_topic_id,  # 긱뉴스 N번
   })
   ```

3. **§3.34.3 `last_topics` 0개 정리 시 source_url 보존** — `last_topics`에서 Tistory URL 항목 제거할 때 **source_url은 별도 dict에 보존** (또는 `details[-N].gn_topic_id` 조회):
   ```python
   # §3.34.3 보강 — last_topics 정리 시 source_url 매핑 보존
   source_url_map = {it.get('gn_topic_id'): it.get('source_url', '')
                     for it in state.get('last_topics', [])
                     if it.get('url', '').startswith('https://sigco.tistory.com/')}
   state['source_url_map'] = source_url_map  # 진실 공급원
   # last_topics 비우기
   state['last_topics'] = []
   ```

4. **cleanup 차수에서 gn_topic_id 역추적** — Notion DB에 긱뉴스 URL 매칭 시 details의 gn_topic_id로 Tistory URL 역추적:
   ```python
   for it in details.get('details', []):
       if it.get('gn_topic_id') == gn_topic_id and it.get('url', '').startswith('https://sigco.tistory.com/'):
           tistory_url = it['url']
           break
   ```

### §3.34.9 — `details`의 `gn_topic_id` 박기 누락 이력 (218차 신규)

**증상**: details에 11건 중 **gn_topic_id가 박힌 건 1건 (31218, #930)** 뿐. 211~217차 모든 publish에서 누락.

**영향**:
- §3.22.3 4중 dedup의 gn_topic_id 단계 무력화
- Notion cleanup 시 details → Tistory URL 역추적 불가
- stats 보정 시 어떤 긱뉴스가 어떤 Tistory 글에 매핑되는지 추적 불가

**영구화 권장**:
1. `scripts/post-publish-correct.sh`에 gn_topic_id 박기 단계 추가
2. 또는 `blog_pipeline.py --record` 명령에 `--gn-topic-id` 인자 추가:
   ```bash
   python3 ~/.hermes/scripts/blog_pipeline.py --record "929" "sneakerweb ..." "https://sigco.tistory.com/929" --gn-topic-id 31214
   ```
3. 차후 차수에서 1회 cleanup: `scripts/retroactive-gn-topic-id.py` — Tistory posts.json의 title에서 긱뉴스 URL 역추적 → details에 일괄 박기

## 218차 작업 타임라인

1. §3.8.1 3-endpoint probe: ✅ 200 OK 3/3 (Tistory max=930 시작)
2. §3.30.4 0단계 state health check: ✅ drift 0 (Tistory=930, state=930, details=930)
3. `blog_pipeline.py --refresh-topics`: 12개 긱뉴스 토픽
4. `blog_pipeline.py --category 'AI/ML'`: Ternlight #31218 fresh=true (false positive) → 명시적 검증
5. **§3.34.8 발견** — 12개 후보 4중 dedup 수동 매칭:
   - 🛑 LAST_TITLES 매칭: 3건 (31201, 31209, 31203)
   - 🛑 GN_PUBLISHED 매칭: 1건 (31218)
   - ⚠️ FRESH (false negative): 8건 — **모두 details에 이미 발행된 긱뉴스**
6. **결정**: fresh 후보 0개 (실질) → 발행 skip
7. §3.5 3중 신호 검증: ✅ drift 0 (Tistory=930 = state=930 = details=930)
8. **cleanup skip** — 새로 발행된 긔 없으므로 cleanup 단계 불필요

## 영구화 all-green (218차)

| 패턴 | 차수 | 218차 결과 |
|---|---|---|
| §3.8.1 3-endpoint probe | 196차 | ✅ 200 OK 3/3 |
| §3.30.4 0단계 state health check | 213차 | ✅ drift 0 (시작: 930=930=930) |
| `--refresh-topics` 12개 토픽 | 208차 | ✅ 12개 |
| §3.22.3 4중 dedup (수동 검증) | 205차 | ⚠️ **8건 false negative** → §3.34.8 발견 |
| §3.5 3중 신호 검증 | 195차 | ✅ drift 0 (종료: 930=930=930) |
| **§3.34.8 last_topics 0개 + gn_topic_id 누락 부작용** (218차 신규) | 218차 | ⚠️ fresh 후보 0개 → skip |
| **§3.34.9 details의 gn_topic_id 박기 누락 이력** (218차 신규) | 218차 | ⚠️ 11건 중 1건만 박힘 → cleanup cron 임무 |

**누적 영구화 all-green**: 213~217차 연속 5회 + 218차 0단계 통과 (drift 0 시작/종료). 단 §3.22.3 4중 dedup의 false negative가 8건 발견됨.

## 218차 핵심 교훈

1. **§3.34.8 `last_topics` 0개 + gn_topic_id 박기 누락 = 4중 dedup 무력화**: §3.34.3 (217차)의 `last_topics` 0개 정리는 source_url 매칭 단계를 무력화. details의 `gn_topic_id` 박기 누락 (211~217차)은 gn_topic_id 단계를 무력화. 두 부작용이 합쳐져 12개 후보 중 8개가 false negative fresh로 분류. **영구화**: blog_pipeline.py 4중 dedup에 5단계 (Tistory topic_id 직접 매칭) 추가 + post-publish 후크에 gn_topic_id 박기 단계 추가.

2. **§3.34.9 details에 gn_topic_id 박기 누락 이력**: 211~217차 7회 publish 중 gn_topic_id 박힌 건 1회 (#930 Ternlight). 215~217차 영구화 단계가 이 박기 누락을 잡지 못함. **영구화**: `scripts/retroactive-gn-topic-id.py` 1회 cleanup으로 일괄 박기 (Tistory posts.json의 title에서 긱뉴스 URL 역추적) + post-publish 후크에 gn_topic_id 박기.

3. **218차 skip 결정의 정당성**: 4중 dedup이 8건 false negative를 발생시키지만, 명시적 수동 매칭으로 **8건 모두 details에 이미 발행된 긱뉴스**임을 확인. fresh 후보 0개 (실질) → 발행 skip 정당. drift 0 유지로 무한 누적 차단.

4. **cleanup skip 정당성**: 218차는 새로 발행한 글이 없으므로 Notion cleanup 단계 불필요. §3.33.1 §3.32.1 cleanup은 매 publish마다 실행하는 게 아니라 **발행 시에만** 실행하는 게 효율적 (drift 0이면 cleanup도 0 PATCH).

**세션 노트**: `references/session-20260708-218th-fresh-candidates-0-gn-topic-id-missing.md` (작업 타임라인 + §3.34.8 last_topics 0개 + gn_topic_id 누락 부작용 + §3.34.9 박기 누락 이력 + 12개 후보 수동 매칭 표 + 발행 skip 결정).
