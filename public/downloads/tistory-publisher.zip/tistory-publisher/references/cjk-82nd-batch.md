# CJK 82차 누적 (2026-06-06, Gemma 4 QAT 블로그 글)

## 이번 세션 발견

**주제:** Gemma 4 QAT 모델: 모바일과 노트북 효율성을 위한 압축 최적화
**글 URL:** https://sigco.tistory.com/657
**소스:** https://news.hada.io/topic?id=30218

### 발견된 CJK

Markdown 1차 선검사에서 2자 발견:
- `卖` (U+5356, 매) — "**卖点**"(셀링 포인트)의 일부로 GeekNews 원문에서 유입
- `点` (U+70B9, 점) — "**卖点**"의 일부, comprehensive dict에 이미 `'点': '점'` 등록되어 있었음

종합 사전 1회차 정제 후 `卖` 1자 잔여 → 2차 targeted final-pass로 `卖` 빈 문자열 제거 완료.

### 사전 보강 항목

```python
# 82차 추가 (2026-06-06 — Gemma 4 QAT 블로그 글)
'卖': '',  # 卖 (U+5356, 매) — "卖点" (셀링 포인트) 등 Chinese 단어에서 유입
```

### 패턴 분석

`卖点`(셀링 포인트, marketing point)는 **한국어 번역 시 "핵심卖点" 같은 식으로 한자가 섞여 들어오는 패턴**이 자주 발견된다. 점(点)은 사전에 있었으나 매(卖)는 누락. 결합형 사전 처리:
```python
'卖点': '핵심 포인트',  # (선택적) 결합형 단어 단위 사전
```

다만 결합형 사전은 다른 글에서 "卖点"가 다른 의미로 쓰일 가능성도 있으므로 단일 문자 처리만 우선 등록한다. 향후 83차+에서 결합형도 발견되면 단어 단위로 추가.

### 권장: 보강된 부분 확인 후 사용

이 references 파일에 등록된 항목은 SKILL.md의 comprehensive dict에 누적 반영해야 한다. 82차 항목은 현재 references에 보존되어 있으며, 다음 SKILL.md 정비 시 (예: 5차 누적 단위) 본 dict에 머지될 예정.

### 이 세션의 발행 성공 메트릭

- **글자수:** 3,712자 (Markdown 원문 3,884자에서 CJK 2자 + 보조 표현 정제 후)
- **Grade:** S (85점) — content 33/35, readability 16/20, originality 20/20, SEO 16/25
- **HTML CJK 루프:** 0회차 통과
- **블록된 execute_code:** ✅ 정상적으로 terminal로 fallback (cron-mode-constraints.md 참조)
