# 352차 — Karpathy의 펠리컨 발행과 proxy-first 동기화

- 실행 시각: 2026-08-03 20:01~20:20 KST
- 후보: 원문 topic `Karpathy의 펠리컨`, GN `32070`, 원본 `https://news.hada.io/topic?id=32070`
- 실제 제목: `펠리컨은 끝났다 — Karpathy가 던진 LLM 평가의 다음 질문`
- 카테고리: `AI/ML` / publish 인자 `1219746`

## 검증 및 발행

1. 기본 `session_expiry_guard.sh`는 `env -i`에서 쿠키가 전달되지 않아 실패했다. 같은 세션에서 raw fallback으로 쿠키를 source한 뒤 Tistory 관리 API를 직접 확인했고, `status=200`, `content-type=application/json;charset=UTF-8`, 최근 ID `1174,1173,1172,1171,1170`을 확인했다.
2. `--refresh-topics`는 exit 0으로 12개 후보를 갱신했다. AI/ML 후보를 **한 번만** 호출해 `status=ready`, GN `32070`을 확정했다.
3. topic 원문 MD5 `4080ea6fe8521bb298a6d724bc8d8e62`가 `published_topics.json`에 없고, 원본 URL과 최근 Tistory 글 목록에도 매칭이 없음을 확인했다.
4. 본문은 `parts.append()` + `"\n".join(parts)`로 빌드했다. 실제 publish wrapper 실행 결과:
   - 이미지 2장 CDN 업로드 성공(각 약 58~59KB)
   - OG 썸네일 설정 성공
   - `PUBLISH=SUCCESS URL=https://sigco.tistory.com/1175`
5. 발행 직후 proxy: `status=200`, `og:title` 정확 일치, source URL 존재, `cjk_suspicious=False`.

## 상태 동기화

- `blog_pipeline.py --commit`은 exit 0으로 `total=169`, 오늘 `AI/ML=2`, `AI/ML` 누적 `854`를 반환했다.
- commit 뒤 `last_published_url`, `last_published_id`, state `details`, published_topics의 canonical hash/`last`/원본 URL을 URL-idempotent하게 맞췄다.
- `check_state_consistency.py --today 2026-08-03`는 오늘 합계가 2이고 `details[-1]`과 last URL이 같은 새 슬롯이라 `FAKE_PUBLISH`를 보고했다. 이는 이 보정 구조에서 생기는 신호 4 구조적 오탐이다.
- 동일 URL을 다시 proxy 검증해 실제 글임을 재확인했으므로 카운터를 추가로 올리거나 롤백하지 않고 `proxy-first 구조적 오탐`으로 판정했다.

## 재사용 규칙

- 후보 선정 명령은 카테고리별로 재호출하지 말고 첫 `status=ready` JSON을 SSOT로 고정한다.
- 성공 URL을 받기 전에는 commit/state/published_topics를 수정하지 않는다.
- 오늘 날짜 판정이 필요한 consistency check는 cron의 로컬 날짜가 KST와 다를 수 있으므로 KST 날짜를 명시하거나 KST-aware wrapper를 사용한다.
- `write_file`의 lint 통과는 실행 성공의 증거가 아니다. 실제 인터프리터 exit 0, 산출물 존재/바이트/내용 지표를 확인한 뒤 publish한다.
