# 201차 세션 노트 (2026-07-06)

## 작업 요약

ICBM2 Tistory 자동 발행 cron 작업.
- §3.8.1 3-endpoint probe 통과
- half-pipeline 패턴 2건 연속 cron 자동 환경 통과 (Cross Entropy #908 + Art Institute #909)
- §3.11 5단계 + §4 5-1 stats 보정 heredoc 2회 실행
- §3.5 3중 신호 최종 drift 0
- 누적 drift 121 (별도 cron 작업 대상, 이번 임무 외)

## 타임라인

1. 21:01 — `blog_pipeline.py --refresh-topics` → 12개 토픽 로드
2. 21:01 — §3.8.1 3-endpoint probe (manage/posts.json, manage/, home) → 3/3 200 OK
3. 21:01 — `blog_pipeline.py --category 'AI/ML'` → guidline (Cross Entropy Loss, 31168) + stats 사전 박기
4. 21:02 — heredoc으로 4,191자 본문 작성 (`~/.hermes/tmp/blog/2026-07-06-aiml-cross-entropy-memory.md`)
5. 21:02 — `tistory_publisher.py --file` → #908 정상 발행, Picsum 2장 삽입
6. 21:02 — 보정 heredoc: stats 891→892, last_topics/details/published_urls.txt 동기화
7. 21:03 — `blog_pipeline.py --category '개발도구'` → guidline (Art Institute API, 31173) + stats 사전 박기
8. 21:03 — heredoc으로 2,338자 본문 작성 (`~/.hermes/tmp/blog/2026-07-06-devtools-unviewed-content.md`)
9. 21:03 — `tistory_publisher.py --file` → #909 정상 발행, Picsum 2장 삽입
10. 21:03 — 보정 heredoc: stats 892→893, last_topics/details/published_urls.txt 동기화
11. 21:03 — §3.5 3중 신호 최종 검증: Tistory top[0].id=909, state last=909, urls last=909 → drift 0

## half-pipeline 영구 가이드 (다음 cron 작업자용)

**절대 `tistory_publisher.py --record-topic`을 호출하지 마라** (4회 연속 환경 의존 패턴, deprecated 영구화).

**올바른 워크플로**:
1. `blog_pipeline.py --refresh-topics` → 트렌드 토픽 로드
2. §3.8.1 3-endpoint probe (manage/posts.json 200 OK 확인)
3. `blog_pipeline.py --category 'X'` → guidline + stats 사전 박기 (publish API 호출 안 함)
4. heredoc/cat heredoc으로 LLM 본문 작성 (1500~2500자, H2 2개+, code block, 이미지 placeholder)
5. `tistory_publisher.py --file <md> --title ... --category <id> --tags ... --image-query '...'` 호출
6. §3.11 5단계 + §4 5-1 stats 보정 heredoc 실행:
   - Tistory 1페이지 fetch (manage/posts.json?category=-3&page=1)
   - `int(it['id'])` 캐스팅 필수 (문자열 함정)
   - `state.last_topics[-1].url`의 id < Tistory top[0].id → stats +1 보정
7. §3.5 3중 신호 검증: Tistory top[0].id == state last == urls last

## 신규 함정 — Tistory `items[].id` 문자열

201차 첫 시도에서 `max(ids)` 직접 호출 시 `TypeError: '>' not supported between instances of 'str' and 'str'` 또는 `ValueError: max() arg is an empty sequence` 발생.

**원인**: Tistory API가 `items[].id`를 **문자열**로 반환 (`"908"`). 200차 §3.17 Layer 3 v2에서는 이 캐스팅을 빠뜨릴 수 있음.

**해결**:
```python
ids = [int(it.get('id', 0)) for it in items if it.get('id')]
top_id = ids[0] if ids else 0  # max() 대신 [0] 사용 (정렬 가정, manage/posts.json은 최신순)
```

또는 명시적 max:
```python
max_id = max(ids) if ids else 0
```

## §3.18 영구화 결정

- half-pipeline 패턴 = **영구 단계** (199차 첫 통과 → 201차 2건 연속 통과)
- `tistory_publisher.py --record-topic` = **deprecated 영구화** (191/193/194/200/201 = 5회 연속 환경 의존)
- `int(it['id'])` 캐스팅 = **영구 함정** (모든 보정 heredoc에 포함 필수)
- 누적 drift 121 = **별도 cron 작업 대상** (199차 §3.16 권장 재확인)

## 환경 의존 5회 연속 표

| 차수 | publish | record 출력 | stats 갱신 | 환경 |
|------|---------|-------------|-----------|------|
| 191차 | #890 성공 | "record 완료" | ✅ 갱신됨 | 가설 (이론상 자동) |
| 193차 | #897 성공 | "record 완료" | ❌ 미갱신 | cron 자동 |
| 194차 | #901 성공 | "record 완료" | ❌ 미갱신 | cron 자동 |
| 200차 | #907 성공 | "record 완료" | ❌ 미갱신 | cron 자동 |
| **201차** | **#908, #909 성공** | **호출 안 함** | **✅ 직접 heredoc 보정** | **cron 자동** |

201차는 `tistory_publisher.py --record-topic`을 호출하지 않고 §3.11 5단계 + §4 5-1 stats 보정 heredoc을 외부 워커가 직접 실행 → 4필드 100% 동기화. 이것이 영구 워크플로.

## 발행 결과

| # | 카테고리 | 제목 | URL |
|---|---------|------|-----|
| 908 | AI/ML (1219746) | 메모리 아끼면서 Cross Entropy Loss 계산하기 — 128K Context LLM 학습 실전 가이드 | https://sigco.tistory.com/908 |
| 909 | 개발도구 (1219747) | 많이 조회되지 않은 콘텐츠 — Art Institute of Chicago API로 숨겨진 작품을 발견하는 법 | https://sigco.tistory.com/909 |

## 후속 권장 (다음 cron 작업)

- 누적 drift 121 별도 cron 작업 분리 (199차 §3.16 재확인)
- `scripts/post-publish-correct.sh`에 `int(it['id'])` 캐스팅 추가 (200차 §3.17 Layer 3 v2)
- half-pipeline 패턴을 영구 단계로 SKILL.md에 명시 완료
