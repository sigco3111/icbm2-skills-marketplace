# 361차 (2026-08-07 01:01) — #1197 Zed DeltaDB 얼리 액세스

- **주제**: Zed DeltaDB 얼리 액세스 — 커밋 사이의 작업 과정과 대화를 함께 기록하는 버전 관리
- **gn**: 32195 / **카테고리**: AI/ML (1219746)
- **본문**: 2,970자 + Picsum 2장 + Python 코드 블록 1개 (`code_lines` 분리 정형)
- **parts.append()**: 27회 (expected 일치)
- **결과**: #1197 정상 발행. 연속 all-green 134회차.

## 신규 함정 — 함정 26 세 번째 변형 (mojibake / U+FFFD)

`write_file` 응답에 sibling subagent write warning이 떴고, 기존 정형 검증 두 항목은
**둘 다 통과**했다:

```
$ grep -c 'parts.append' build_post_361.py
27                      # expected 일치 → 함정 26 prefix 손실 변형 아님

$ grep -nE '[一-鿿]|[ぁ-ゔ]|[ァ-ヴー]' build_post_361.py
CJK_NONE                # → 함정 26 CJK swap 변형도 아님
```

그런데 세 번째 grep에서 1건 검출:

```
$ grep -n '�' build_post_361.py
56:parts.append("<p>에이전트를 병렬로 굴려 본 경험이 있다면 ��� 지점이 왜 중요한지 ...
```

한글 `이` 한 글자가 U+FFFD replacement character로 깨져 있었다.

### 왜 기존 검증을 빠져나가는가

| 검증 단계 | 결과 | 이유 |
|-----------|------|------|
| `write_file` lint | `status: ok` | `�` 는 문자열 **내용**이라 문법적으로 완전히 유효 |
| CJK grep `[一-鿿]` 등 | 0건 | U+FFFD는 한자/가나 유니코드 영역이 아님 |
| `parts.append` count | 27 = expected | prefix는 멀쩡함 |
| **`grep -n '�'`** | **1건 검출** | ← 이 항목만 잡아낸다 |

즉 333차(CJK swap) / 342차(prefix 손실) 어느 쪽 시그니처와도 겹치지 않는 독립 변형이다.
검출 못 하면 깨진 글자가 그대로 Tistory에 발행된다 (§3.5도 5-5 proxy도 본문 글자 단위
검사는 안 하므로 사후 발견도 어렵다).

### 조치

`patch()` 한 줄로 한글 원문 복원 → 재빌드 → `NO_REPLACEMENT_CHAR` 확인 → 정상 publish.

```
patch(old="경험이 있다면 ��� 지점이 왜 중요한지",
      new="경험이 있다면 이 지점이 왜 중요한지")
```

### 정형 반영

sibling write warning 시 검증을 **3종 grep**으로 확장 (SKILL.md 함정 26):
(a) CJK swap grep, (b) `parts.append` count, (c) **`grep -n '�'` mojibake grep**.
(a)가 0건이어도 (c)는 반드시 별도 실행.

## §3.5 신호 4 — admin API 교차 검증 (361차 보강)

5-3에서 `details[-1]`과 `last_published_url`을 같은 새 슬롯으로 동시 갱신하는 구조 때문에
신호 4는 매 차 필연 발동한다 (46연속). 이번 차는 proxy(200 + og:title)에 더해
**manage/posts.json admin API**로 한 번 더 교차 확인했다:

```python
r = requests.get('https://sigco.tistory.com/manage/posts.json?category=-3&page=1',
                 cookies=cookies, headers=hdr, timeout=15, allow_redirects=False)
items = r.json().get('items', [])
# admin_first_ids= ['1197', '1196', '1195', '1194']
# admin_top_title= Zed DeltaDB 얼리 액세스 — 커밋 사이의 ...
```

**proxy보다 강한 증거인 이유**: proxy는 블로그 프론트엔드 렌더링 결과라 캐시/스킨 영향을
받을 수 있지만, admin posts.json은 Tistory 관리 DB의 글 목록 자체다. 신규 글이 목록 최상단에
있고 제목이 일치하면 실제 DB에 저장됐다는 뜻이므로 가짜 발행이 원천적으로 불가능하다.
신호 4 판정이 애매하거나 proxy 결과를 한 번 더 확인하고 싶을 때 이 교차 검증을 쓴다.
§3.8.1 가드에서 이미 같은 엔드포인트를 호출하므로 추가 비용도 거의 없다.

## 정형 그대로 재현된 부분

- §3.8.1: `session_expiry_guard.sh` exit 10/3 실패 → raw HTTP 폴백 (함정 10 정형)
- 중복 판정: canonical hash = `md5("Zed DeltaDB 얼리 액세스")` = `cf0c0aeb…` (SEO 확장 제목 아님)
- publish: inline `python3 -c` + `publish_post()` 직접 호출 (함정 31 변형 A/B 회피)
- 5-3 → 5-2-A 순서 준수 (336차 정형), KST 타임존 명시 (317차 정형)
- 5-2-A 백필 1건 (state.json엔 #1197, published_topics.json엔 누락 — 정형 패턴)
- `source_in_body=False` 빌드 검사 → publish 후 `source_present=True` (함정 27 정형)
- by_category `"1219746": 1` 잔재 65연속 (함정 8, 보고만)
