# 352차 (2026-08-02 15:00) — `#1173` 가짜 저자 NeurIPS 구두 발표 채택 사건

## 결과
- **#1173** "가짜 저자를 신고한 연구 논문 두 편이 모두 구두 발표로 채택됨 — 학술 AI 남용의 현실과 심사 체계의 한계" (gn=32039, AI/ML, 본문 2,420자 / 발행 측정 2,417자, Picsum 2장, Bash 코드 블록 1개, source footer 자동).
- 단일 패스 **45연속** + parts.append() 정형 **45연속** + §3.5 신호 4 disambiguate **52연속** (298→352) + 진입 5-5 27연속 + fallback 복귀 37연속.
- **324차 `--content` 단일 폴백 정형 16회차 검증** (324→352 모두 정상 publish).
- **빌드 검증 6종 정형 재확인** (351차 정형 그대로) — bytes=5640 / text_len=2420 / images=2 / code_blocks=1 / source_in_body=False(함정 27: publish_post footer 자동) / cjk_suspicious=False.
- **함정 28 정밀화 (352차 진짜 원인 발견)** — 기존 SKILL.md 진술("parts.append() 안에 multiline HTML literal → SyntaxError unterminated string literal")은 **336차 케이스만** 묘사한 것. **352차 실전은 다른 증상**: `<pre><code>...</code></pre>` HTML 리터럴을 single `f'<...>\n...\n...</pre>'` 박았는데 lint 단계 SyntaxError가 아니라 **runtime `ValueError: Invalid format specifier`**로 죽음. f-string 형식 해석이 `\n` 직후의 `{...}` 같은 패턴을 specifier로 잘못 해석한 게 진짜 원인.
  - 336차 fix(`code_lines = [...]` 리스트 + `"\n".join(code_lines)`)는 **양쪽 케이스 모두 해결** — 352차에서 동일 fix 재적용 1회로 정상 빌드.
  - **판정 매트릭스 보강**: parts.append() 안에 multiline HTML literal이 들어가면 처음부터 `code_lines = [...]` 패턴 사용 (336차 + 352차 동시 검증). `f-string + multiline + backslash` 트리플 조합은 **runtime 에러와 lint 에러 둘 다 발생 가능** — 정형 fix 하나로 양쪽 다 커버.
- **§3.5 2중 drift 동시 발동 (352차 신규 관찰)** — commit_publish 직전 §3.5 실행 시 두 가지 drift 동시 노출:
  1. `last_published_url=#1173` ≠ `last_topics[-1].url=#1172` (직전 차 마지막 발행 #1172가 last_topics에 stale 잔존)
  2. `daily_counts[2026-08-02]={}` 빈 상태 (어제 정상 발행 후 오늘 첫 발행이라 297차 정형 자연 상태)
  - **해결**: 5-2 commit_publish 실행 → today={AI/ML:1} + last_topics[-1]=#1173 → §3.5 3중 신호 일치 OK.
  - **정형**: commit_publish 실행 전 §3.5 drift는 5-2 단계에서 자연 해소될 가능성이 높음. **exit 1만 보고 rollback/stop 금지**, commit_publish 시도 후 재검증. 352차 실전: 첫 §3.5 FAIL → commit_publish → 두 번째 §3.5 PASS (proxy 200 + og:title 매칭 + commit stats 갱신의 3중 시점 일치).
- **5-2-A 1건 백필 정상** — state.json엔 #1173 이미 포함 (5-3 patch에서 append), published_topics.json엔 누락 → 5-2-A 단방향 백필 정상 작동 (336차 + 337차 + 347차 + 351차 + 352차 5연속 정형).
- publish_post() OG 썸네일 `https://blog.kakaocdn.net/dna/bIDoHg/dJMcabLZSlQ/AAAAAAAAAAA...` 자동.
- 5-5 proxy check disambiguate 통과 (status=200 + og:title 정확 + source_present=True + cjk_suspicious=False).
- stats total=167, today={AI/ML:1}, by_category["1219746"]=1 영구 잔존 **56차 누적** (297→352, 351차 정형 그대로).
- 연속 all-green **126회차**.

## 진짜 함정 28 — f-string multiline literal의 두 얼굴

336차에 발견된 함정 28은 **두 가지 다른 증상**으로 나타날 수 있다:

| 케이스 | 트리거 | 증상 | 발생 위치 |
|--------|--------|------|-----------|
| **336차 (lint 단계)** | `parts.append('문자열\n한 줄 더')` (작은따옴표 + multiline literal) | `SyntaxError: unterminated string literal` | lint (Python 파서) |
| **352차 (runtime 단계)** | `parts.append(f'문자열\n{var}\n더')` (f-string + multiline literal) | `ValueError: Invalid format specifier` | runtime (f-string 형식 해석) |

**판정 매트릭스 (352차 정밀화)**:
- parts.append() 안에 다음이 들어가면 **처음부터 `code_lines = [...]` + `"\n".join(code_lines)` 패턴**:
  1. `<pre>...</pre>` / `<code>...</code>` 블록
  2. `<ul>...</ul>` + `<li>` 여러 줄
  3. `<table>...</table>` 여러 줄
  4. 본문에 의도적인 `\n` 박힘
  5. **f-string + multiline + 백슬래시 트리플 (352차 신규)** — `f'...{var}\n...'` 안에 multiline literal

**fix는 동일**: `code_lines = [...]` 리스트 + `"\n".join(code_lines)` 한 줄 문자열. 336차 fix가 352차 runtime 에러도 해결한 이유 — multiline literal을 parts.append() 밖으로 빼면 f-string 형식 해석에서 제외됨.

## 작업 순서 (352차 실전 검증)

1. §3.8.1 가드 raw 검증 (303차 안정 패턴) → status=200 + first_id=1172 ✅
2. --refresh-topics → 12개 주제 갱신 (AI/ML 6, 개발도구 2, 개발팁 3, 기타 1)
3. --category 'AI/ML' → status=ready (gn=32039 가짜 저자 사건, score=3.0)
4. write_file /tmp/build_post_352.py (parts.append() 33건, Picsum 2장, Bash 코드 1개)
5. lint: SyntaxError 없음 (sibling write warning 0건 — 333차 함정 26 미발동)
6. /usr/bin/python3 -s 빌드 실행 → **ValueError: Invalid format specifier** (함정 28 변형)
7. patch() 1회: `f'<pre><code>...</code></pre>'` → `code_lines = [...]` + `"\n".join(code_lines)` 정형 (336차 fix 재적용)
8. 재빌드 → OK bytes=5640 text_len=2420 images=2 code_blocks=1 source_in_body=False cjk_suspicious=False
9. publish (324차 + 339차 정형 `--content` 단일 폴백) → 🔗 https://sigco.tistory.com/1173 + OG 썸네일 자동
10. 5-3 last + details 통합 보정 → state.details=246→247
11. 5-2-A 1건 백필 + last 동기화 (#1173) → published_topics.details_len=247
12. §3.5 첫 검증 → ⚠️ DRIFT 2건 (last≠last_topics + today 비어있음) — **commit_publish 미실행 상태**
13. 5-2 commit_publish → today={AI/ML:1}, total=167 정상 갱신
14. §3.5 두 번째 검증 → ✅ OK 3중 신호 일치 (commit_publish가 5-3과 last_topics 갱신을 모두 trigger)
15. 5-5 proxy check → status=200 + og:title 정확 + source_present=True + cjk_suspicious=False

**핵심 관찰 (352차 신규)**: §3.5 drift가 commit_publish **전**에 발동하는 게 정상. commit_publish가 today + last_topics 두 필드를 모두 갱신하므로, 5-3 (last+details) → 5-2 (commit_publish) → §3.5 순서가 정형. 5-3만 거치고 5-2를 안 하면 §3.5 FAIL이 1차로 발동하는 게 정상 워크플로우의 일부. **rollback/stop 금지**, commit_publish 시도 후 §3.5 재실행으로 disambiguate.

## 시계열 정형

- **§3.8.1 가드** (1단계) → **§3.11 5-3** (state last+details) → **§3.11 5-2-A** (published_topics 백필+last) → **§3.5** (1차 검증, commit 전이라 drift 정형) → **§3.11 5-2 commit_publish** (stats today+total+by_category) → **§3.5** (2차 검증, 신호 일치 OK) → **§3.11 5-5** (proxy check disambiguate).
- 위 7단계 시퀀스가 한 트랜잭션이며, 1차 §3.5 FAIL이 commit 전 drift의 **정형 신호**. drift는 commit_publish 실행으로 자연 해소됨.

## 검증 출력 (352차 실측)

```
§3.8.1 가드: status=200, content_type=application/json;charset=UTF-8, first_id=1172 ✅
refresh-topics: 12개 갱신 (AI/ML 6, 개발도구 2, 개발팁 3, 기타 1)
--category 'AI/ML': status=ready, gn=32039, score=3.0
빌드 1차: ValueError: Invalid format specifier (함정 28 변형)
빌드 2차: OK bytes=5640 text_len=2420 images=2 code_blocks=1 source_in_body=False cjk_suspicious=False
publish: 🔗 https://sigco.tistory.com/1173, OG 썸네일 https://blog.kakaocdn.net/dna/bIDoHg/...
5-3: state.details=247, last_published_url=https://sigco.tistory.com/1173
5-2-A: published_topics.details_len=247, last=https://sigco.tistory.com/1173
§3.5 1차: ⚠️ DRIFT 2건 (last≠last_topics #1172 + today={})
5-2 commit_publish: today={AI/ML:1}, total=167, by_category["1219746"]=1
§3.5 2차: ✅ OK 3중 신호 일치
5-5 proxy: status=200, og:title 정확 매칭, source_present=True, cjk_suspicious=False
```
