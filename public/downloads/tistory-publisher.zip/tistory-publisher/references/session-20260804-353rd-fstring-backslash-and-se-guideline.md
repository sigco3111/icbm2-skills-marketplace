# 353차 검증 차 신규 — f-string backslash + SE guideline 본문 검증

353차 webapp-ai 빌드 검증 차에서 발견한 두 가지 신규 함정. 모두 빌드 단계 (write_file / 실행 직후 검증) 에서 발생하며 publish 전에 차단 가능.

## 함정 1 — f-string backslash

### 증상

`write_file`로 작성한 빌드/검증 스크립트에서 `print(f"…{re.findall(r'<img\\b', text, re.I)}…")` 같은 f-string 보간 식 안에 escape(`\b`, `\s`, `\d`, `\"` 등)가 들어가면 Python 3.9가 lint 단계에서 즉시 거부한다.

```
SyntaxError: f-string expression part cannot include a backslash
```

### 원인

PEP 701 이전 (Python 3.9까지 포함) f-string의 보간 표현식은 backslash를 포함할 수 없다. `re` 모듈의 escape 문자(`\b`, `\s`, `\d`, `\"`)를 f-string 안에 직접 박으면 무조건 lint 실패. Python 3.12+ 부터는 PEP 701로 허용되지만 `/usr/bin/python3` (3.9.x)는 여전히 거부한다.

### 해결

`re.findall` 결과를 먼저 변수에 분리한 뒤 f-string에는 변수만 보간한다.

```python
image_count = len(re.findall(r'<img\b', final_html, re.I))
code_block_count = len(re.findall(r'<pre\b[^>]*>.*?<code\b', final_html, re.I | re.S))
print(f'bytes={Path("/tmp/post_353.html").stat().st_size} '
      f'text_len={len(plain)} '
      f'img_count={image_count} '
      f'code_block_count={code_block_count} '
      f'src_in_body={SOURCE_URL in final_html}')
```

또는 f-string 자체를 제거하고 단순 `print()` + `,` 구분자로 출력한다. **parts.append() 정형이 이 함정을 자연스럽게 우회한다** — f-string 본문 길이가 짧아져서 `\b` escape가 들어갈 일이 줄어든다.

### 실전 재현 (353차)

```python
# ❌ 실패 (f-string 안에 \b 직접 박힘)
print(f'img_count={len(re.findall(r"<img\\b", final_html, re.I))}')

# ✅ 정상 (변수 분리 후 보간)
image_count = len(re.findall(r'<img\b', final_html, re.I))
print(f'img_count={image_count}')
```

patch() 1회로 변수 분리 → lint 정상 + 빌드 성공 (6016 bytes / 2459자 / img 2 / code 1).

## 함정 2 — SE guideline 본문 길이 검증

### 배경

Tistory SE 키워드 가이드라인은 빌드 시점에 항상 일치해야 한다.

| 항목 | 값 |
|------|----|
| `target_length` | 2500 |
| `min_length` | 1500 |
| `include_code` | true (코드 블록 ≥ 1) |
| `include_images` | true (Picsum 이미지 ≥ 1) |
| `tone` | 전문+접근 |
| `structure` | 도입 → 핵심 2-4섹션 → 실용 → 전망 → 요약 |

### 증상

353차 02:19 KST에 발행된 #1179의 1차 빌드 결과는:

```
bytes=2291 text_len=921 img_count=0 code_block_count=0 src_in_body=True cjk_suspicious=False
```

921자 / 0 img / 0 code — 모두 SE guideline 위반. parts.append() 정형이 정착한 350차 이후 차들은 모두 본문 2200~2800자 / Picsum 2장 / Python 코드 1개였으므로 SE 검증을 통과했는데, 353차 1차 빌드만 정형이 누락된 상태로 publish됐다.

### 판정

빌드 검증 스크립트(`/tmp/validate_353.py` 등)에서 `BUILD=PASS/FAIL`을 명시적으로 print하고, 다음 6종 모두 충족해야 PASS:

- `bytes > 0` (HTML 생성됨)
- `text_len >= min_length` (≥ 1500)
- `image_count >= 1` (Picsum ≥ 1)
- `code_block_count >= 1` (코드 블록 ≥ 1)
- `source_in_body=True`
- `cjk_suspicious=False`

FAIL이면 publish 단계 진입 전에 본문 보강 + 재빌드 필수.

### 본문 보강 패턴 (parts.append() 정형)

SE guideline을 자연스럽게 맞추는 최소 정형:

```python
parts = []
parts.append("<h2>도입 — 핵심 이슈</h2>")
parts.append("<p>첫 단락 (도입)…</p>")
# Picsum 1 (시드: 영문 슬러그-1)
parts.append('<img src="https://picsum.photos/seed/webapp-ai/1200/630" alt="…" />')
parts.append("<h2>1. 첫 번째 핵심 섹션</h2>")
parts.append("<p>…</p>")
parts.append("<ul>")
parts.append("<li>항목 1</li>")
parts.append("<li>항목 2</li>")
parts.append("<li>항목 3</li>")
parts.append("</ul>")
parts.append("<h2>2. 두 번째 핵심 섹션</h2>")
parts.append("<p>…</p>")
# Picsum 2 (시드: 영문 슬러그-2)
parts.append('<img src="https://picsum.photos/seed/ai-integration/1200/630" alt="…" />')
parts.append("<h2>3. 실용 / 전망</h2>")
parts.append("<ol>")
parts.append("<li>…</li>")
parts.append("<li>…</li>")
parts.append("</ol>")
# 코드 블록 (language-{python|javascript|bash})
code_html = '<pre><code class="language-javascript">' + '\n'.join(code_lines) + '</code></pre>'
parts.append(code_html)
parts.append("<h2>전망과 요약</h2>")
parts.append("<p>…</p>")
parts.append("<hr>")
parts.append(f'<p class="source">원문: <a href="{SOURCE_URL}">{SOURCE_URL}</a></p>')
```

이 정형으로 깔면 자연스럽게 2300~2700자 / img 2 / code 1 / source 1 / heading 4개 정착. 검증 차에서는 본문 길이 + img + code + source 4종만 BUILD=PASS로 보면 충분.

## 검증 차 ID 중복 가드 (353차 검증 차)

같은 차 cron에 이미 publish된 발행분(예: 353차 02:19 KST #1179)에 대해 검증 차가 또 publish 단계를 돌리면:

- `last_published_id`가 동일하게 박혀 신호 4 drift 발생
- stats daily_counts 이중 박힘
- 진짜 발행인지 가짜 발행인지 모호

따라서 검증 차에서는 publish 단계 자체를 skip하고 다음 3종 wrapper로 전환한다:

- `/tmp/proxy_existing_NNN.py` — 이미 발행된 URL에 대해 status=200 + og:title 매칭 검증
- `/tmp/sync_existing_NNN.py` — 5-3 + 5-2-A 동기화 (state.last + last_topics + details + pt.last)
- `/tmp/check_existing_NNN.py` — §3.5 check_state_consistency.py 호출 + 4-URL 일치 확인

wrapper 이름 자체가 의도를 명확히 한다 (기존 발행분 검증이라는 의미).

## structural_signal4 정형화

`check_state_consistency.py` exit 1과 동시에 다음 4개 URL이 모두 일치하면 **구조적 오탐** 확정 (335차 + 298차 정형):

| 필드 | 위치 |
|------|------|
| `state.last_published_url` | `blog_pipeline_state.json` |
| `state.last_topics[-1].url` | `blog_pipeline_state.json` |
| `state.details[-1].url` | `blog_pipeline_state.json` |
| `published_topics.last.url` | `published_topics.json` |

proxy check가 `status=200 + og:title 정확 + source_present`이면 진짜 발행 확정, 신호 4 drift는 무시.

353차 검증 차 최종 출력:

```
state_last=https://sigco.tistory.com/1179
last_topic=https://sigco.tistory.com/1179
details_last=https://sigco.tistory.com/1179
published_topics_last=https://sigco.tistory.com/1179
structural_signal4=True
CHECK=PASS_STRUCTURAL_FALSE_POSITIVE
```

## SKILL.md 정형 참고

이 함정들은 모두 빌드 시점에 차단 가능하므로 publish 직전 `BUILD=PASS/FAIL` print + 6종 검증 정착이 핵심. SKILL.md 본문 §3-b "본문 빌드 단일 패스 패턴"에 다음 한 줄 추가 권장:

> 빌드 직후 `validate_353.py` 같은 검증 스크립트로 `BUILD=PASS/FAIL`을 명시 print하고, FAIL이면 publish 전에 본문 보강 + 재빌드 필수. SE guideline (1500자+ / 이미지 1장+ / 코드 1개+) 동시 충족이 단일 판정 기준.