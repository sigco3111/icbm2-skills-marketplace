# 363차 (2026-08-07 06:01) — #1202 Muse Code와 Muse Spark 1.2 공개

## 발행 요약
- **#1202**: Muse Code와 Muse Spark 1.2 공개 — Meta의 차세대 터미널 코딩 에이전트
- gn=32213, AI/ML (Tistory 카테고리 ID 1219746)
- 본문 2,197자 / 발행 측정 2,249자
- Picsum 2장 (79KB / 54KB 업로드)
- OG 썸네일 자동: `https://blog.kakaocdn.net/dna/dkw2VG/dJMcabd0XeW/AAAAAAAAAAA...`
- publish_post() stdout: `🔗 https://sigco.tistory.com/1202`

## 카운터 갱신
- 단일 패스 **46연속**
- §3.5 신호 4 disambiguate **29연속**
- 진입 5-5 **28연속**
- fallback 복귀 **40연속**
- 연속 all-green **136회차**

## 검증 결과
- §3.8.1 RAW VALID: status=200, content_type=application/json, first_ids=['1201','1200','1198','1197'], items_count=15
- 5-5 proxy check disambiguate:
  - proxy status=200
  - og:title="Muse Code와 Muse Spark 1.2 공개 — Meta의 차세대 터미널 코딩 에이전트" 정확 매칭
  - source_present=True (`news.hada.io` substring 발견)
  - mojibake=False (U+FFFD 0건)
  - cjk_suspicious=True (Tistory chrome 영향 — 의도 케이스)
- admin API 교차 검증 (361차 정형):
  - admin_first_ids=['1202','1201','1200','1199']
  - admin_first_title="Muse Code와 Muse Spark 1.2 공개 — Meta의 차세대 터미널 코딩 에이전트"
  - admin_top1_match=True → 가짜 발행 원천적으로 불가능 확정
- commit_publish: stats today={AI/ML:6, 개발도구:1} (총 7건), total=194
- 5-3 state.json 동기화: last=#1202, details_len=274, last_topics_len=20
- 5-2-A published_topics.json: 누락 백필 1건 정상, last.url=https://sigco.tistory.com/1202

## 정형 패턴 재현 확인
- 305차 단일 패스 (og:description 160자 + Picsum 2장 + 본문 빌드) — 12+회차 연속 작동
- 324차 `--content` 단일 폴백 — 12회차 검증 (324→344→345→346→347→348→349→350→352→362→363차), 안정화 단계
- 311차 AI/ML 직접 발행 (fallback 미사용)
- 317차 5-3 KST 타임존 명시 (datetime.timezone(timedelta(hours=9)))
- 333차+361차 sibling write warning 3종 검증 정형 (CJK grep / parts.append count / mojibake grep)
- 361차 admin API 교차 검증 정형 (proxy보다 강한 증거)
- 332차+340차 parts.append() + double quotes 정형 (코드 블록 0개라 code_lines 불필요)
- 336차 5-2-A ↔ 5-3 실행 순서 보강 (5-3 → 5-2-A)

## 함정 회피 8종 (3/6/7/11/14/15/17/26)
- **함정 3** (긱뉴스 본문 selector 코멘트만) → og:description 160자 사용
- **함정 6** (heredoc + env -i SyntaxError) → write_file + `python3 -s /tmp/build_post_363.py` 패턴
- **함정 7** (--category int만) → `--category 1219746` int로 전달
- **함정 11** (execute_code cron 차단) → write_file + /tmp/build_post_363.py + `python3 -s` 실행
- **함정 14** (import os 누락) → `import os, requests, re` 모두 포함
- **함정 15** (5-5 격리 누락) → `unset PYTHONPATH PYTHONHOME; PYTHONNOUSERSITE=1; export PYTHONPATH=user-site` 정형
- **함정 17** (단일 큰 f-string 회피) → parts.append() 정형 33 lines, `<p>` 단일 라인만이라 code_lines 분리 불필요
- **함정 26** (sibling write warning) → 3종 grep (CJK/parts.append count/mojibake) + read_file 라인 직접 확인

## 관찰

### CJK regex false-positive (proxy check Tistory chrome)
5-5 proxy check의 `re.search(r'[一-鿿]|[ぁ-ゔ]|[ァ-ヴー]', r.text)`가 본문은 깨끗한 한국어 + Picsum 이미지뿐인데도 `cjk_suspicious=True` 반환. Tistory 자체 chrome/UI 텍스트(댓글, 사이드바, 메타 영역 등)가 CJK 영역 문자를 포함해서 발생. 빌드 스크립트 print()는 `cjk_suspicious=False` (body 자체는 깨끗) → **build vs proxy 불일치로 Chrome 영향 식별 가능**. 매트릭스 (a)+(d) 케이스로 publish 진행 — og:title 매칭 + admin API 교차 검증 + source URL substring이 진짜 발행 판정의 단독 기준. **판정**: proxy의 `cjk_suspicious=True` 단독으로는 차단 사유 안 �.

### sibling write warning 검증 라인 의도 케이스
write_file 후 응답의 sibling write warning 정형 검증 시 검증용 print 문 안의 `re.search(r"[一-鿿]...")` 자체가 grep 1건 매치 + `"�" not in final_html` 검사 자체가 mojibake grep 1건 매치. 의도된 검사 코드이지 swap된 한자가 아님. `read_file`로 라인 직접 확인해서 한국어 원문이 보존됐는지 확인이 최종 판정. **판정**: line 66/67 매치는 정상 검증 출력 의도 케이스 — 무시.

### 363차 본문 빌드 단일 패스 정상 작동 재확인
og:description 160자 추출 → Picsum 2장 → 본문 2197자 빌드 → /tmp/post_363.html 2778 bytes → publish_post() OG 썸네일 자동 설정. 305차 정형이 12+ 회차 연속 정상 작동 중. 본문 < 3000자 단일 패스 영역이라 parts.append() 정형만 적용하고 code_lines 분리는 불필요 (코드 블록 0개).

## 빌드 검증 출력
```
BUILD_OK bytes=2778 text_len=2197 image_count=2 cjk_suspicious=False
mojibake_check=OK
SAVED /tmp/post_363.html
```

## 발행 commit 결과
```json
{
  "committed": true,
  "topic": "32213",
  "title": "Muse Code와 Muse Spark 1.2 공개 — Meta의 차세대 터미널 코딩 에이전트",
  "url": "https://sigco.tistory.com/1202",
  "category": "AI/ML",
  "stats": {
    "total": 194,
    "today": {"AI/ML": 6, "개발도구": 1},
    "by_category": {"AI/ML": 878, "iOS/Swift": 18, "개발도구": 153, "투자/경제": 14, "기타": 14, "아이디어": 6, "개발 팁": 14, "개발팁": 2, "1219746": 1}
  }
}
```
