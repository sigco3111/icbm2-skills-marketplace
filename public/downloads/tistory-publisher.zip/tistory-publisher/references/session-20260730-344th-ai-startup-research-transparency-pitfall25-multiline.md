# 344차 — AI 스타트업 연구 투명성 (gn=31981) — 함정 25 멀티라인 f-string 변형 재발

**날짜**: 2026-07-30 21:01
**블로그 글**: #1146 (https://sigco.tistory.com/1146)
**긱뉴스 토픽**: https://news.hada.io/topic?id=31981
**주제**: "AI 주요 스타트업들은 연구 결과를 거의 공개하지 않음"
**카테고리**: AI/ML (1219746)
**상태**: ✅ 발행 성공 — 연속 all-green **118회차**

---

## 발행 지표

| 항목 | 값 |
|------|-----|
| 본문 길이 | 3,766자 |
| 빌드 결과 크기 | 4,479 chars (`/tmp/post_344.html`) |
| Picsum 이미지 | 2장 |
| Python 코드 블록 | 1개 (`code_lines` 리스트 정형) |
| OG 썸네일 | `https://blog.kakaocdn.net/dna/bSfaWH/...` |
| daily_counts | {AI/ML:8, 개발도구:1} (총 9건) |
| total | 140 |
| 단일 패스 | **39연속** (305차 이후) |
| 신호 4 disambiguate | **38연속 확정** (298→344) |
| 진입 5-5 | **19연속** |
| fallback 복귀 | **31연속** |

## 누적 정형 검증

- `--content` 단일 폴백 정형 **7회차 검증** (324→339→340→341→342→343→344 모두 정상 publish)
- `--file` parser 거부 패턴 완전 안정화 — `/tmp/post_N.html`는 `CONTENT=$(...)` 셸 치환 → `--content "$CONTENT"` 직접 전달
- parts.append() 정형 39연속 — 모든 차에 일관 적용
- 5-3 (state.json last+details append) → 5-2-A (published_topics.json 동기화) 정형 순서 (336차) 정상 작동
- 5-2-A 누락 백필 1건 (state.json엔 #1146, published_topics.json 누락 → 매 차 정상)

---

## 🆘 함정 25 멀티라인 f-string 변형 재발 (344차 신규)

### 증상

`/tmp/build_post_344.py`의 도입부에서 다음과 같이 멀티라인 f-string으로 본문을 나누려 했음:

```python
parts.append(f'<p>2026년 상반기, AI 산업의 투명성에 대한 의문이 다시 한 번 제기되고 있습니다. '
             f'Anthropic, OpenAI, Google DeepMind 같은 프런티어 AI 회사들은 '안전하고 책임있는 AI 개발'을 내세우지만, '
             f'실제 연구 결과 공개와 외부 협업은 매우 제한적이라는 분석이 나오고 있습니다. '
             f'이 글에서는 최근 보고된 데이터를 바탕으로 AI 주요 스타트업들의 연구 투명성을 살펴보고, '
             f'개발자·연구자·정책 입안자가 주목해야 할 시사점을 정리합니다.</p>')
```

**lint 단계 즉시 실패**:
```
SyntaxError: invalid syntax. Perhaps you forgot a comma? (line 69, column 14)
```

### 원인

- `f'...'` 5줄 연속인데 그중 3번째 라인에 본문 텍스트의 작은따옴표('안전하고 책임있는 AI 개발')가 박혀 있음
- lint가 f-string 안에 박힌 작은따옴표(')를 single-quoted로 명시한 f-string의 종료 따옴표(`'`)와 충돌로 오인
- `SyntaxError: invalid syntax. Perhaps you forgot a comma?` 메시지 — 단순 누락이 아니라 f-string 전체 무효화

### 332차 함정 25 정형 (single-line) 의 한계

```python
parts.append("<h2>1. 사건의 핵심: '훈련 데이터 = 사용자 발언'이 된 시대</h2>")
```

이 정형은 parts.append() 인자가 한 줄일 때만 작동. 멀티라인 f-string으로 본문을 여러 줄로 나누면, 각 라인마다 small-quote 매칭을 피할 수 없음.

### 해결 (344차 정형)

3가지 옵션 중 처음부터 채택:

| 옵션 | trade-off |
|------|-----------|
| (a) **HTML entity 치환** — `'` → `&lsquo;` / `&rsquo;`, `"` → `&ldquo;` / `&rdquo;` | lint 단계 통과 보장, 본문 출력 그대로 (Tistory가 entity 렌더링) |
| (b) **한 줄 문자열로 강제 통합** | 가독성 ↓, lint 단계 통과 |
| (c) **double quotes 한 줄 정형** (332차 함정 25 그대로) | 멀티라인 어려움, 본문이 짧을 때만 가능 |

344차는 (a) + (b) 조합 채택:

```python
parts.append('<p>2026년 상반기, AI 산업의 투명성에 대한 의문이 다시 한 번 제기되고 있습니다. Anthropic, OpenAI, Google DeepMind 같은 프런티어 AI 회사들은 &lsquo;안전하고 책임있는 AI 개발&rsquo;을 내세우지만, 실제 연구 결과 공개와 외부 협업은 매우 제한적이라는 분석이 나오고 있습니다. 이 글에서는 최근 보고된 데이터를 바탕으로 AI 주요 스타트업들의 연구 투명성을 살펴보고, 개발자·연구자·정책 입안자가 주목해야 할 시사점을 정리합니다.</p>')
```

`patch()` 1회로 line 67-71 멀티라인 f-string 5줄을 한 줄 single-quoted parts.append()로 대체 → lint 정상 + 빌드 3766자.

### 가장 위험한 조합 (342차 함정 26과 결합 시)

멀티라인 f-string이 functions 호출 prefix 손실 변형(`('...')` parenthesized string)과 결합되면 lint는 SyntaxError를 안 던지고 정상 빌드하면서 **body에서 한 줄 통째 사라짐**. 가능하면 본문 빌드 처음부터:

- **단일 f-string 한 줄 정형** (긴 본문은 parts.append() 여러 줄 정형)
- **작은따옴표 의심 시 HTML entity 치환**
- **f-string + 작은따옴표 매칭 위험 회피** 위해 처음부터 double quotes one-line 정형

### 정형 원칙 (344차 강화)

> 본문 빌드 시 멀티라인 f-string parts.append() 라인에서 작은따옴표 / 큰따옴표 / 의도된 `\n` / multiline HTML literal 중 하나가 끼면 처음부터 entity 치환 + 한 줄 통합. **회피 보다는 처음부터 안전**.

---

## §3.5 + 5-5 검증

### §3.5 drift (구조적 오탐 — 298→344 47연속)

```
today=2026-07-30 daily_counts={'AI/ML': 8, '개발도구': 1} (total=9)
last_published_url=https://sigco.tistory.com/1146
last_topics[-1]={...url:'https://sigco.tistory.com/1146'...}
⚠️ DRIFT 감지:
  - 가짜 발행 의심 (FAKE_PUBLISH): daily_counts[2026-07-30] 합계=9 지만 details[-1]=#1146 (last_published_url 변동 없음)
⚠️ FAIL: §3.5 drift (가짜 발행 의심 — §3.11/§4 보정 검토)
```

5-3에서 last_published_url + last_published_id + details 모두 #1146로 동기화하면서 무조건 발동 (구조적 오탐).

### 5-5 proxy check disambiguate

```
status=200
title=AI 주요 스타트업들은 연구 결과를 거의 공개하지 않음 &mdash; 투명성 보고서 분석과 개발자가 알아야 할 시사점
og:title=AI 주요 스타트업들은 연구 결과를 거의 공개하지 않음 — 투명성 보고서 분석과 개발자가 알아야 할 시사점
source_present=True
cjk_suspicious=0
```

오탐 확정 — 정상 publish 완료.

---

## 빌드 / 검증 정량

```
body_len=5876 (article selector에서 긱뉴스 본문 1차 추출)
key_points=8
text_len=3766
img_count=2
source_in_body=False (publish_post() footer가 자동 박아 줌, 함정 27)
cjk_suspicious=0
SUCCESS: /tmp/post_344.html (4479 chars, 3766 text)
```

## 회고

- 343차 `import re` mini-fall에 이어 344차는 본문 빌드 multiline f-string + 작은따옴표 매칭 깨짐 — 둘 다 "멀티라인 의도 + 단일 라인 매칭 가정" 패턴. **정형 원칙 강화**: 멀티라인 의도가 본문을 둘로 나누는 게 목적이라면 처음부터 entity 치환 + 한 줄 통합. 가독성이 우선이라면 html 분리/서식화(h2/p 분리) 권장. parts.append() 라인이 늘어날수록 lint 위험도 비례.
- 39연속 단일 패스 — 매 차 정형화한 패턴들 (`--content` 단일 폴백, parts.append(), code_lines 리스트, 5-3+5-2-A 순서, 5-5 proxy disambiguate)이 서로 결합해서 정상 publish 한 번에 도달. 핸드오프 비용 최소화.
- 연속 all-green 118회차 진입 — 287차 이후 누적. 자동화 운영 신뢰도의 정량적 마일스톤.
