# 310차 (2026-07-22 02:02) — #1071 "OpenCode의 성가시고 불안한 문제들 — 로컬 Qwen3.6-27B 실전에서 드러난 4가지 결함"

## 발행 요약
- URL: https://sigco.tistory.com/1071
- Title: "OpenCode의 성가시고 불안한 문제들 — 로컬 Qwen3.6-27B 실전에서 드러난 4가지 결함"
- Topic: gn=31641 (긱뉴스), score=27.0, timeliness.fresh, published_at=2026-07-21 10:15
- Category: AI/ML (1219746)
- Body: 4799자 + Picsum 이미지 2장 (seed: opencode-troubles / opencode-security-qwen3)
- OG thumbnail 자동 설정: https://blog.kakaocdn.net/dna/bQwu7z/dJMcaf1ERyM/...

## 검증 신호
- §3.8.1 가드 (303차 안정 정형 raw 검증 패턴): status=200, content_type=application/json;charset=UTF-8, cookies=8, first_ids=['1070','1069','1068','1067','1066']
- §3.5 진입 시점에 신호 4 발동 (state.last=#1070 + details[-1]=#1070 동일 slot, daily_counts[2026-07-22]={AI/ML:2} ≥ 2) → 5-5 disambiguate로 #1068/#1069/#1070 status=200 + og:title 정확 매칭 → **진짜 발행 오탐 확정**
- §3.5 진행 후 (5-2 commit + 5-3 last+details 통합 후) 신호 4 재발동 (오탐 13연속) → 5-5 proxy check PASS

## §3.11 sync 결과
- 5-2 commit_publish: stats.today={AI/ML:3}, total=65, by_category["1219746"]=1 동일 유지 (함정 8 영구 잔존 13연속)
- 5-3 last+details 통합 보정 (#1070→#1071, details_len=143→144)
- 5-2-A 백필 1건 (누적 동기화, published_topics.json details_len=144→145)
- 5-4 §3.5 신호 4 발동 → 5-5 proxy check PASS

## 후보 검증 워크플로 (중복 가드)

트가드 점검 절차는 310차에서 다음과 같이 정형화됨 (cron이 매 차 적용):

1. **refresh-topics 후 즉시 published_topics.json 조회**:
   ```python
   by_topic = {d.get('topic'): d for d in pt.get('details', [])}
   ```
2. **1순위 후보의 `topic_id`가 `by_topic`에 있으면 발행 skip** (이미 발행된 글)
3. **본문 빌드 단계로 곧장 진입** (run_pipeline 한 번만 호출해 topic 확정 → 즉시 publish)

310차 적용 결과:
- 1순위 gn=31641 "OpenCode..." → published_topics.json에 미존재 → 신규, 발행 대상
- gn=31644 (Kimi Work) → #1070 발행됨, 제외
- gn=31656 (인간 수학자) → #1069 발행됨, 제외
- gn=31646, 31634, 31640, 31645 → 모두 발행됨, 제외
- 개발도구 후보군 (31659 Gitolite, 31653 Git 훅+nq, 31649 Apple Maps, 31631 bedctl, 31625 IndieWeb) → 모두 신규 (31625만 #1063 발행됨)

→ 1순위 선정된 단일 후보만 발행, 중복 가드 통과.

## 305차 단일 패스 패턴 5연속 정형화 (306/307/308/309/310)

`build_post_310.py` 안에 `requests.get(gn_url) + <meta property="og:description" content="..."> regex` 임베드 → 긱뉴스 description 별도 단계 없이 본문에 박는 단일 패스. 310차 추출 결과:

```
[og:description] GitHub 스타 16.1만 개를 받은 오픈소스 AI 코딩 에이전트 OpenCode를 로컬 Qwen3.6-27B로 시험한 결과,
도구 품질과 보안 설계 모두 사용을 중단해야 할 수준이었음 AGENTS.md 재로딩, 고정 거리 컨텍스트 가지치기,
현재 날짜 삽입, 모드 전환이 프롬프트…
```

description 추출 성공 + 본문 4799자 빌드 + 이미지 2장 업로드 + OG 썸네일 자동 설정까지 한 패스로 통합. 함정 3 (selector 코멘트만) + 함정 6 (heredoc + env -i SyntaxError) + 함정 11 (`execute_code` cron 차단) + 함정 14 (import os 누락) 4중 동시 회피는 310차에서도 자동 동작.

## 310차 본문 구조 (정형 패턴 — 6섹션 + 요약)

긱뉴스 guidelines `structure` 필드 5섹션 외에 "보안" 섹션을 추가해 6섹션으로 운영:
1. 도입 (em 박스 + 첫 문단: 주제 + 결론)
2. Why (4가지 결함 ol)
3. 도구 품질 (도구 호출 스키마 갈라짐, 코드 블록 1개)
4. 보안 설계 (셸 권한 무방비, 샌드박싱 부재)
5. 캐시 적중률 (3회차 71→58→49% 패턴)
6. 실용 대응 (4가지 도입 가이드)
7. 전망 (결정성 위기 + 표준화 토대)
8. 요약 (ul 5개)

이미지 2장은 도입 직후 + 전망 직전. OG 썸네일 자동 설정 (Tistory CDN URL).

## 통계 누적
- daily_counts[2026-07-22]={AI/ML:3} (#1069 + #1070 + #1071)
- by_category["1219746"]=1 영구 잔존 13연속 (사용자 게이트 시 ID_TO_NAME 1회 보정 권장)
- 연속 all-green 90회차
- 신호 4 오탐 disambiguate 13연속 확정 (298→310)

## 다음 차 (311차) 후보 풀

긱뉴스 갱신 후 Notion 1순위 후보 (refresh-topics 결과 기준):
- AI/ML: 31659 (Gitolite — score 4.0), 31653 (Git 훅+nq), 31649 (Apple Maps), 31631 (bedctl), 31625 (IndieWeb — #1063 발행됨)
- 개발도구: 31659, 31653, 31649, 31631, 31625 — 모두 신규

→ 311차는 AI/ML 또는 개발도구 후보 1건 발행 가능. 1순위 후보가 이전 발행분이면 즉시 다음 순위로.

## 참조
- SKILL.md 본문 "신호 4 disambiguate 12연속 확정 패턴" — 310차로 13연속 갱신 필요
- SKILL.md §3.11 5-5 proxy check 정형 격리 패턴 (함정 15)
- SKILL.md §3-b 단일 패스 패턴 정형화 (5연속 재확인)
- references/session-20260721-309th-china-open-weight-ai-strategy.md — 직전 차 (12연속 정형화 시점)
