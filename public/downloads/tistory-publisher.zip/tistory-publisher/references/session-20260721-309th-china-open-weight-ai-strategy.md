# 309차 (2026-07-21 22:01) — #1067 "중국의 오픈 가중치 AI 전략이 앞서고 있음"

## 발행 요약
- URL: https://sigco.tistory.com/1067
- Title: "중국의 오픈 가중치 AI 전략이 앞서고 있음 — 폐쇄형 모델 시대의 종착점"
- Topic: gn=31634 (긱뉴스), score=6.0, timeliness.fresh
- Category: AI/ML (1219746)
- Body: 6797자 + Picsum 이미지 2장 (seed: china-open-weight-ai / open-vs-closed-models)
- OG thumbnail 자동 설정: https://blog.kakaocdn.net/dna/bgkY8c/dJMcaglYAHF/...

## 검증 신호
- §3.8.1 가드: status=200, content_type=application/json, cookies_count=8, first_ids=['1066','1065','1064','1063','1062']
- §3.5 신호 4 발동 (오탐 12연속, 298→309) — state.last=#1067 + details[-1]=#1067 동일 slot, daily_counts={AI/ML:10, 개발도구:1} ≥ 2
- 5-5 proxy check: status=200 + title 정확 매칭 + og:title 정확 매칭 → 진짜 발행 확정

## §3.11 sync 결과
- 5-2 commit_publish: stats.today={AI/ML:10, 개발도구:1}, total=61, by_category["1219746"]=1 동일 유지 (함정 8 영구 잔존 12연속)
- 5-3 last+details 통합 보정 (#1066→#1067, details_len 139→140)
- 5-2-A 백필 1건 (누적 동기화, published_topics.json details_len=141)
- 5-4 §3.5 신호 4 발동 → 5-5 proxy check PASS

## 신규 발견 (309차)

### 함정 15 — 5-5 proxy check heredoc 격리 누락
SKILL.md 본문 §3.11 5-5 예제는 `set -a; source; unset PYTHONPATH; python3 -c "..."` 형태로 격리 미적용. 그러나 §1단계 가드 / §3.8.1 raw 검증 / 본문 빌드는 `unset PYTHONPATH PYTHONHOME; PYTHONNOUSERSITE=1; export PYTHONPATH=/Users/mac/Library/Python/3.9/lib/python/site-packages; /usr/bin/python3 -s` 정형 패턴 적용.

**결과**: 309차 5-5에서 첫 시도 시 격리 누락 → 즉시 `ModuleNotFoundError: No module named 'requests'` (Hermes venv 격리 누설 + user-site 격리 실패 동일 패턴).

**해결**: 5-5 proxy check도 §1단계 가드와 동일 격리 패턴 적용. `og:title`까지 매칭 확인이 진짜 발행 판정의 단일 기준.

### 305차 단일 패스 패턴 4연속 정형화 (306/307/308/309)
`build_post_XXX.py` 안에 `requests.get(gn_url) + <meta property="og:description"> regex` 임베드 패턴이 4연속 안정 작동. 긱뉴스 description 추출 + Picsum 이미지 2장 + 본문 빌드를 단일 패스로 통합. 함정 3 (selector 코멘트만) + 함정 6 (heredoc + env -i) + 함정 11 (`execute_code` cron 차단) 3중 동시 회피는 4연속 모두 자동 회피.

## 통계 누적
- daily_counts[2026-07-21]={AI/ML:10, 개발도구:1} (총 11건)
- by_category["1219746"]=1 영구 잔존 12연속 (사용자 게이트 시 1회 ID_TO_NAME 보정 권장)
- 연속 all-green 89회차

## 참조
- SKILL.md 본문 함정 15 — 5-5 proxy check heredoc 격리 누락 + 정형 템플릿
- SKILL.md 본문 "신호 4 disambiguate 12연속 확정 패턴" (309차 갱신)
- SKILL.md §3.11 5-5 예제 블록도 §1단계 가드와 동일 격리 패턴으로 통일