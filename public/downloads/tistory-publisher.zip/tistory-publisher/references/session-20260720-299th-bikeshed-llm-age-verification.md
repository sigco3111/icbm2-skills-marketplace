# 299차 (2026-07-20 03:02) — §3.5 신호 4 오탐 재확인 + #1050 Bikeshed 발행 + 함정 8 누적 가속

## 결과 요약

- §3.8.1 가드 raw VALID (status=200, application/json)
- 트렌드 12개 새로고침
- Topic: "안녕히, 그동안의 모든 Bikeshed에 감사드립니다" (gn=31573, AI/ML)
- 본문: 3020자 + Picsum 이미지 2장 CDN 업로드
- 발행: **#1050** https://sigco.tistory.com/1050
- og:title 매칭 ✅ / proxy status=200 ✅
- daily_counts[2026-07-20] = {AI/ML: 3} (297 #1048, 298 #1049, 299 #1050)
- 연속 all-green 79회차

## §3.5 신호 4 오탐 disambiguate 재확인

publish 전 §3.5 검증에서 FAKE_PUBLISH 발동:
- daily_counts[2026-07-20]={AI/ML:2}, details[-1]=#1049, last_published_url=#1049
- 두 슬롯 동일 → 신호 4 발동

그러나 진짜 가짜 발행 잔재가 아닌 298차 #1049 정상 발행의 details[-1]=#1049, last=#1049 자연 상태.

**disambiguate 절차 (298차 패턴)**: 5-5 proxy check status=200 + og:title 매칭 → FAKE_PUBLISH 오탐 확정.

proxy check 결과:
- #1049: status=200, og_title="100만 개 키워드가 보여준, AI가 검색에 미치는 영향..." (296차 #1047/297차 #1048/298차 #1049 모두 진짜 존재)
- #1048: status=200, og_title="AI가 Stack Overflow에 끼친 영향을 그래프로 보기..."
- #1050: status=200, og_title="안녕히, 그동안의 모든 Bikeshed에 감사드립니다..."

→ publish 진행.

## 본문 빌드 패턴 (296차 함정 6 회피)

`/tmp/build_post_bikeshed.py` 별도 파일로 작성 → `/usr/bin/python3 /tmp/build_post_bikeshed.py` 실행.
heredoc + env -i 조합 SyntaxError 회피 패턴 그대로 사용.

OG description 긱뉴스 메타에서 추출 (293차 안정 패턴). 본문 3020자 (목표 2500자 상회).

## 297차 함정 8 누적 가속 — 사용자 확인 요청

publish 3건(#1048/#1049/#1050)에 걸쳐 `by_category["1219746"]` 정수 ID 키가 누적됨:
- 297차 #1048: 첫 추가 → by_category["1219746"]=1
- 298차 #1049: 동일 키 존재 → 코드 동작이 `=` 할당이라 변동 없음
- 299차 #1050: 동일 → 변동 없음
- 현재 state.json by_category = {"AI/ML": 743, "iOS/Swift": 18, ..., "1219746": 1}

SSOT 변경이라 cron은 임의 자동 보정 금지, drift 보고만. SKILL.md 함정 8 섹션에 정형 보정 절차 코드 추가 — 사용자 승인 시 즉시 적용 가능.

## publish 워크플로우 검증 (298차 5-3 표준 보정 패턴)

- 5-2 commit_publish: stats.today={AI/ML:3}, by_category["1219746"]=1 (정수 ID 누적)
- 5-3 last+details 통합 보정: last_published_url+id=#1050, details append
- 5-4 §3.5 신호 4 발동 (오탐)
- 5-5 proxy check disambiguate 통과

5-3 표준 보정 + 5-5 disambiguate 패턴이 두 차 연속 정상 작동 확인.

## 다음 차 권장

1. §3.8.1 가드 raw VALID + §3.5 깨끗 또는 신호 4 오탐 disambiguate 통과 → publish 진행
2. 사용자 승인 시 함정 8 by_category 정수 ID 키 한 번에 정리 (SKILL.md 정형 코드 실행)
3. 연속 all-green 80회차 진입
