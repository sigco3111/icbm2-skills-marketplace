# 가짜 발행 우회 — tistory_publisher.py 직접 호출 패턴 (185차, 2026-06-29)

> 182차에서 도입된 `blog_pipeline.py --category 'AI/ML'` 가짜 발행 함정(통계 +1, URL 0)을
> 우회하기 위한 패턴. `tistory_publisher.py --file` 직접 호출 + `--record-topic`로
> 진짜 발행 + 통계 일관성 유지.

## 🚨 가짜 발행 함정 재확인 (182차)

`blog_pipeline.py --category 'AI/ML'` 4회 호출 결과:
- 1회: guidline JSON 출력 (정상)
- 2회: 다른 주제 guidline 출력 (통계 +1, URL 0)
- 3회: 다른 주제 guidline 출력 (통계 +1, URL 0)
- 4회: 또 다른 주제 guidline 출력 (통계 +1, URL 0)

**패턴**: 매번 다른 주제를 출력하고 **본문 생성 + Tistory API 호출 단계로 안 넘어감**. 통계는 박히지만 URL은 안 박힘 → 가짜 발행.

## ✅ 우회 패턴 — tistory_publisher.py 직접 호출

### 핵심 명령

```bash
# 1. 카테고리 ID 확인
python3 ~/.hermes/scripts/tistory_publisher.py --categories

# 2. 본문 마크다운 작성
cat > /tmp/post-content.md << 'CONTENT_EOF'
# 제목 본문

본문 내용 (1500~3000자)
CONTENT_EOF

# 3. 직접 발행 (--file 모드)
python3 ~/.hermes/scripts/tistory_publisher.py \
  --title "게시글 제목" \
  --tags "AI,LLM,태그" \
  --visibility public \
  --category 1219746 \
  --file /tmp/post-content.md \
  --record-topic "topic-slug" "게시글 제목"
```

### 출력 예시 (성공)

```
📄 Content 검증 통과: 1761자
📝 제목: 오픈 웨이트 LLM과 폐쇄형 LLM의 격차 — 2026년 상반기 현황
📎 공개: public
🏷️  태그: AI,LLM,오픈웨이트,폐쇄형,벤치마크

🔍 무료 이미지(Picsum)로 2장 검색 중...
🖼️  이미지 2장 삽입 완료 (CDN 업로드: 2/2)
✅ 발행 성공!
🔗 https://sigco.tistory.com/869
📝 주제 record 완료
```

### 자동 보너스

- **이미지 자동 삽입**: Picsum 무료 스톡에서 검색어 매칭 → Tistory CDN 업로드
- **OG 썸네일 자동 설정**: blog.kakaocdn.net CDN URL
- **record-topic**: published_topics.json + stats 동시 갱신

## 📝 --record-topic 인자 의미

```
--record-topic TOPIC TITLE [URL [TOPIC_URL]]
```

- 3개: (TOPIC, TITLE, URL) — 하위 호환
- 4개: (TOPIC, TITLE, URL, TOPIC_URL) — TOPIC_URL 기반 중복 방지

본 패턴에서는 **3개 인자**로 충분:
- `TOPIC`: 슬러그 (예: "open-vs-closed-llm-2026")
- `TITLE`: 게시글 제목
- `URL`: Tistory 발행 URL (성공 후 출력됨)

## 🔧 발행 전 안전 검증

### 1) dry-run으로 가짜 발행 패턴 우회 확인

```bash
python3 ~/.hermes/scripts/blog_pipeline.py --dry-run --category 'AI/ML'
# → guidline JSON만 출력 (통계 안 박힘)
# → dry-run이 정상 작동하면 진짜 발행 결정
```

### 2) 가짜 발행 롤백 패턴 (182차)

발행 후 가짜 발행이 발생했다면 (stats.total_published가 URL 수보다 많음):

```bash
# 1단계: 백업
python3 -c "
import shutil
from datetime import datetime
from pathlib import Path
ts = datetime.now().strftime('%Y%m%d_%H%M%S')
backup_dir = Path.home() / f'.hermes/migration_fix_backup_{ts}_blog_rollback'
backup_dir.mkdir(parents=True, exist_ok=True)
shutil.copy2(Path.home() / '.hermes/memory/blog_pipeline_state.json',
             backup_dir / 'blog_pipeline_state.json.bak')
"

# 2단계: 4개 필드 동시 차감 (N = 가짜 발행 건수)
python3 -c "
import json
from pathlib import Path

p = Path.home() / '.hermes/memory/blog_pipeline_state.json'
state = json.loads(p.read_text())
N = 3  # 오늘 가짜 발행 건수로 조정
today = '2026-06-29'  # 오늘 날짜로 조정

state['last_topics'] = [t for t in state.get('last_topics', [])
                       if not (t.get('category') == 'AI/ML' and t.get('date', '').startswith(today))]
state['daily_counts'].setdefault(today, {})
state['daily_counts'][today]['AI/ML'] = max(0, state['daily_counts'][today].get('AI/ML', 0) - N)
state['stats']['total_published'] -= N
state['stats']['by_category']['AI/ML'] -= N

p.write_text(json.dumps(state, ensure_ascii=False, indent=2))
"

# 3단계: 검증
python3 ~/.hermes/scripts/blog_pipeline.py --status
```

### 3) Notion 트렌드 갱신 (트렌드 데이터 2개월+ 묵은 경우)

```bash
python3 ~/.hermes/scripts/blog_pipeline.py --refresh-topics
# → GeekNews RSS에서 신선한 12개 주제 가져옴
```

## 🎯 발행 의사결정 플로우

```
[블로그 발행 요청]
        │
        ▼
[--refresh-topics]  ← 트렌드 데이터 2개월+ 묵으면
        │
        ▼
[--dry-run --category 'X']  ← 주제 후보 1개
        │
        ▼
[통계 vs URL 갭 체크]  ← published_topics.json details에 없는지 확인
        │
   ┌────┴────┐
   ▼         ▼
[중복]    [신선]
   │         │
[skip]   [진짜 발행 결정]
              │
         ┌────┴────────────────┐
         ▼                     ▼
[--category 'X']      [--file 직접 호출]
(가짜 발행 위험 ↑)    (가짜 발행 패턴 우회 ✅)
         │                     │
         ▼                     ▼
[stats +1 + URL 0]   [stats +1 + URL 1 (정상)]
[롤백 필요]           [✅ 완료]
```

**권장**: 처음부터 `--file` 직접 호출로 시작. `blog_pipeline.py --category 'X'`는 본문 자동 생성 + 이미지 자동 삽입을 위한 고급 옵션으로만 사용 (성공률 확인된 경우).

## 🔗 참고

- `SKILL.md` §3 (가짜 발행 함정, 182차)
- `SKILL.md` §3.2 (롤백 3단계 패턴)
- `SKILL.md` §3.4 (예방 가이드)
- `references/false-positive-stats-rollback.md` (false-positive 통계 롤백)
- `references/session-20260626-182nd.md` (가짜 발행 최초 발견)