# 267차 (2026-07-15) — `#1004 GhostLock, 15년간 모든 Linux 배포판에 존재한 스택 UAF`

> 한 줄 요약: §3.34 #21 AI/ML 우선 정책 + §3.34.46 영구화 + §3.34.47 격리 빌드 + §3.34.48 `* ` 분기 모두 4번째 회차 무영향 정상 동작. 본 세션 신규 발견 0건.

## 발행 결과

- **글**: `#1004 GhostLock, 15년간 모든 Linux 배포판에 존재한 스택 UAF — 15년 동안 Linux 2.6.39~7.1에 잠복한 커널 UAF의 실체와 완화 가이드`
- **URL**: https://sigco.tistory.com/1004
- **cat_id**: 1219746 (AI/ML)
- **gn_topic_id**: 31407
- **score**: 4.0 (TOP 12개 중 6개 이미 262~266차 처리, FRESH 잔여 6개 중 AI/ML 1개 픽)
- **연속 all-green**: 54회차 (213~267차)
- **cleanup cron 임무 #16**: 54회 연속 all-green

## 워크플로

1. §3.8.1 가드: `status=200, ct=application/json;charset=UTF-8, cookie_count=8` ✅
2. §3.34.40 FRESH 4-field: 6개 ALREADY(31404/31435/31432/31411/31406/31424) + 6개 FRESH(개발도구 3 + AI/ML 1 + 개발팁 1 + 투자/경제 1)
3. §3.34 #21 AI/ML 우선 정책 → `31407 (AI/ML 4점)` 픽
4. §3.34.46 영구화: `fetch_gn_content(31407)` → status=200, **15863 bytes** 1단계 `.md` endpoint 즉시 fetch
5. §3.34.47 격리 빌드: `write_file`로 `/tmp/tistory_drafts_267th/build_draft.py` (7749 bytes) UTF-8 선언 저장 → `python3 <script>.py` 격리 호출 정상
6. §3.34.48 `* ` 분기 보강: `md_to_html`에 `elif stripped.startswith("* ") and not stripped.startswith("**"):` 분기 추가
7. 4단계 헤더 강등 정규식: `md = re.sub(r"^#### (.+)$", r"### \1", md, flags=re.MULTILINE)` 266차 정착 패턴 적용
8. 빌드: 본문 12952자 / 인트로 522자 / 결론 1305자 / 평문 11336자 (300자 가드 통과)
9. §3.5 5중 신호 사전 검증: 모두 `#1003` 일치 → publish 진행
10. publish: `tistory_publisher.py --title ... --category 1219746 --file ... --source-url "https://news.hada.io/topic?id=31407" --gn-topic-id 31407 --image-query "linux kernel vulnerability exploit container escape dark code"`
11. post_publish_sync: `pt_updated: true / state_updated: true / triple_signal_match: true`
12. §3.5 5중 신호 사후 검증: 모두 `#1004` 일치
13. daily_counts[2026-07-15]: `{'AI/ML': 1}` ({}→{AI/ML:1}, +1 정확)
14. state.details 80→81, pt.details 96→97 (+1 정확)
15. cleanup cron 임무 #16 dry-run: `✅ 누설 없음` (53→54회 연속)
16. 라이브 페이지 GET: `status=200, size=75459, title tag=정확`

## 본문 빌드 스크립트 핵심

- 266차 정착 `md_to_html` 4종 패턴(헤더/리스트/bold) + §3.34.48 `* ` 분기 + 4단계 헤더 강등 정규식
- editorial 인트로 1단락 (한국 독자층 + 15년 futex race 컨텍스트) + 결론 5단계 (커널 버전 확인 / 컨테이너 호스트 우선 / 로컬 사용자 권한 감사 / IoC 모니터링 / 72시간 긴급 패치)
- 4단계 헤더 강등이 267차 본문에는 hit 안 했지만 정규식 자체는 266차 정착 패턴 그대로 적용 (안전 가드)
- `* ` 분기는 267차 본문에서 hit 안 함 (31407 본문은 모두 `- ` 패턴) — 그러나 266차 정착 분기 그대로 코드에 포함

## 신규 발견

- 본 세션 **신규 발견 0건** — 266차 식별 패턴(`* ` 분기, 4단계 헤더 강등, §3.34.47 격리 빌드) 모두 267차에 1회성 무영향 적용
- 266차 보강 검증: `* ` 분기 + 4단계 헤더 강등 정규식 + §3.34.47 격리 빌드 = 3가지 266차 신규 보강 모두 267차에 정상 통과

## 차감/추가

- 없음. 모든 기존 패턴 정상 동작.

## 운영 가이드 (267차)

- 264차 `#1000`, 265차 `#1002`, 266차 `#1003`, 267차 `#1004` — 4회 연속 동일 워크플로 정착
- 차후 차에서는 266차 보강(`* ` 분기, 4단계 헤더 강등)이 코드베이스에 안정적으로 포함되어 추가 보강 불필요
- `md_to_html` 은 §3.34.46 + §3.34.48 박스 코드를 그대로 복사해서 `build_draft.py`에 포함

## 다음 차 권장

- 268차에 FRESH 후보가 모두 '기타'거나 0개면 → 정상 skip
- 268차에 §3.34.46 + §3.34.48 박스 코드 그대로 재사용 (코드 패치 불필요)
- 268차에 §3.34 #21 AI/ML 우선 정책 그대로 적용 (코드 패치 불필요)
