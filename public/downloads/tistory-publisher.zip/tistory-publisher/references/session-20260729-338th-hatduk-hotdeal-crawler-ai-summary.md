# 338차 — 핫덕 (gn=31942, AI/ML, #1135)

**날짜**: 2026-07-29 21:01
**발행**: `https://sigco.tistory.com/1135`
**제목**: Show GN: 핫딜모음 게시판 여러 곳 크롤링해서 AI로 요약해주는 사이드 프로젝트 만들었습니다 (핫덕) — 개발자가 알아야 할 핵심 정리
**카테고리**: AI/ML (1219746)
**stats**: today={AI/ML:7}, total=129

## 빌드

- **본문 길이**: 3,103자 (15 parts.append() parts)
- **이미지**: Picsum 2장 (seed: hatduk-crawler / ai-summary-pipeline)
- **코드 블록**: Python 1개 (24줄, `code_lines = [...]` + `"\n".join(code_lines)` 패턴 — 336차 함정 28 정형)
- **빌드 패턴**: 305차 단일 패스 — `requests.get(gn_url) + <meta property="og:description"> regex` 임베드 → 159자 description 추출
- **publish wrapper**: `/tmp/publish_338.py` standalone (328차 정형), `tags="핫덕,핫딜크롤러,AI요약,LLM,사이드프로젝트,긱뉴스,크롤러,자동화"` (comma-separated str — 330차 정형)

## 검증

- **§3.8.1 가드**: status=200 + content_type=application/json + first_id=1134 → ✅ VALID
- **publish_post()**: 이미지 업로드 2장 성공, OG 썸네일 `https://blog.kakaocdn.net/dna/bu3zNR/...` 자동 설정
- **5-3 state.json**: last=#1135, details_len=208, timestamp KST 명시 (`datetime.datetime.now(kst)` — 317차 정형)
- **5-2-A 백필**: 1건 (이번 차 발행분 자동 안전망 — 329차 정형)
- **§3.5 신호 4**: 발동 (구조적 오탐 정형 — 335차 정형)
- **5-5 proxy disambiguate**: status=200 + og:title="Show GN: ... (핫덕) — 개발자가 알아야 할 핵심 정리" 정확 매칭 + source_present=True + cjk_suspicious=False → 진짜 발행 확정

## 새로 확인된 정형 패턴

### 3103자 경계 사례 — parts.append() 정형 정상 작동

318차 정형("본문 3000자 미만 = 단일 f-string OK")을 정확히 넘는 본문(3,103자). 처음부터 parts.append() 정형 선택 → lint 정상, publish 정상. 336차 함정 28 (multiline HTML literal → SyntaxError) 정형(`code_lines = [...]` + `"\n".join(code_lines)`)도 동시 회피. **판정 보강**: 본문 3000자 근처부터는 본문 길이뿐 아니라 코드 블록 개수를 함께 봐야 한다. 코드 블록 1개 + 본문 3100자 = parts.append() 정형 권장 (단일 f-string으로 시도하면 본문 길이 + multiline literal 결합 시 lint 위험).

**판정 매트릭스 갱신 (338차)**:

| 본문 길이 | 코드 블록 | 권장 패턴 |
|-----------|-----------|-----------|
| < 3000자 | 0개 | 단일 f-string OK |
| < 3000자 | 1~2개 | 단일 f-string OK (functions 안 f-string으로 가능) |
| 3000~5000자 | 1개 | **parts.append() 권장** (3103자 사례) |
| 3000~5000자 | 2개+ | parts.append() 필수 |
| 5000자+ | 1개+ | parts.append() 필수 |

**판정 원칙 (338차 정형 강화)**: 본문이 3000자 이상이거나 코드가 들어가는 순간 parts.append() 패턴을 기본으로 사용. 단일 f-string은 본문 < 3000자 + 코드 0개일 때만 시도.

## 함정 회피 동시 성공 (10중)

3, 6, 7, 8, 11, 14, 15, 17, 25, 27, 28 — 모두 자동 회피.

- 함정 3 (긱뉴스 본문 selector 코멘트만) → og:description regex 사용
- 함정 6 (heredoc + env -i SyntaxError) → write_file + 별도 실행
- 함정 7 (--category int만) → 1219746 (int)
- 함정 8 (by_category["1219746"]=1 영구 잔존 32연속)
- 함정 11 (execute_code cron 차단) → write_file 패턴
- 함정 14 (import os) → 5-5 proxy check에서 `import os, requests, re` 명시
- 함정 15 (5-5 proxy 격리) → §1단계와 동일 격리 패턴
- 함정 17 (단일 f-string 위험) → parts.append() 정형 처음부터 사용
- 함정 25 (parts.append 작은따옴표) → 본문 작은따옴표 없어서 정상, double quotes 사용
- 함정 27 (빌드 시점 source 검사 ≠ publish 후 footer) → publish_post()가 footer 자동 박음, 5-5 proxy source_present=True로 확인
- 함정 28 (parts.append() 안에 multiline HTML literal) → code_lines 패턴 정형

## 다음 차 운영 포인트

- 339차 진입 시 §3.5 신호 4 발동 예상 (구조적 필연성) → 5-5 proxy check 1회로 disambiguate
- by_category["1219746"]=1 영구 잔존 33연속 예정 — 사용자 게이트 시 ID_TO_NAME 1회 보정 가능 (SSOT 변경이라 cron은 drift 보고만)
- daily_counts={AI/ML:7} → 339차 발행 시 {AI/ML:8} 예상

연속 all-green **112회차**.
