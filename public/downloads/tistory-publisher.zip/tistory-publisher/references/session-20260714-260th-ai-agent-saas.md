# 260차 (2026-07-14) — AI 에이전트가 새로운 SaaS다

## 발행 결과
- **글 번호**: #994
- **제목**: AI 에이전트가 새로운 SaaS다 — "제품이 곧 업무"로 가는 a16z의 프레임
- **카테고리**: AI/ML (cat_id=1219746)
- **gn_topic_id**: 31376
- **source_url**: https://news.hada.io/topic?id=31376
- **원본 URL**: https://news.hada.io/topic/31376.md
- **글자 수**: 11411자 (intro 540 + GeekNews 본문 8300 + 결론 1700 + 마지막 단락)

## 사전 검증 결과 (모두 통과)
- §3.8.1 세션 만료 가드: cookie_count=8, status=200, ct=application/json;charset=UTF-8
- §3.5 5중 신호 (사전): 모두 `#993` (직전 차 종료값) 일치
- §3.34.40 FRESH 4-field: FRESH 6개 식별 (31376/31390/31378/31375/31367/31389 모두 AI/ML)
- §3.34.39 후보 직접 점수 pick: 31376 1순위

## 핵심 발견 2건

### 1. §3.34.46 임시 우회 패턴 실전 검증
- 259차 식별 + 260차 실전 검증: `requests.get("https://news.hada.io/topic/{tid}.md")` 직접 호출이 정상 fetch
- 260차 31376 fetch: status=200, 8952 bytes (259차 31397은 1251 bytes — 본문 길이 비례)
- 영구화 패치(#23 cleanup cron 임무) 미적용 상태 — 다음 차에 `GN_MD_URL = f"{GN_TOPIC_BASE}/{tid}.md"` 1줄 정정 시 즉시 정상화

### 2. 본문 변환 패턴 정착 (260차 NEW)
- GeekNews 마크다운 4가지 패턴만 다루면 됨:
  - `## 헤더` → `<h2>헤더</h2>`
  - `### 헤더` → `<h3>헤더</h3>`
  - `- 항목` → `<ul><li>항목</li></ul>` (빈 줄 = `</ul>` close)
  - `**bold**` → `<strong>bold</strong>`
- 본문 추출 정규화: Comments 섹션 제거 + Metadata 섹션 제거 (line-by-line with `- key: value` 패턴) + "## Topic Body" 헤더 제거
- editorial 인트로/결론 (한국어 1~2 단락) 추가 → 300자 가드 통과 + 발행 가독성 확보
- 260차 11411자: intro 540 + 본문 8300 + 결론 1700 + 마지막 단락

## 사후 검증 결과 (모두 통과)
- §3.5 5중 신호 (사후): 모두 `#994` 일치 (all_match: true)
- post_publish_sync: pt_updated=true, state_updated=true, errors=[], triple_signal_match=true
- daily_counts[2026-07-14] = {'AI/ML': 2} (1→2, +1 정확, cat_id 누설 0)
- state.details 70→71, pt.details 86→87
- 라이브 페이지 GET: status=200, size=71020, title tag='AI 에이전트가 새로운 SaaS다 &mdash; ...'
- cleanup cron 임무 #16 dry-run: ✅ 누설 없음 (46회 연속 all-green, 213~260차)

## 발행 통계
- 연속 all-green 47회차 (213~260차)
- 본 세션 차감/추가 없음

## 다음 차 액션
- 영구화 패치 (#23 cleanup cron 임무): `GN_MD_URL = f"{GN_TOPIC_BASE}/{tid}.md"` 1줄 정정 → 1단계 `.md`에서 즉시 본문 fetch
- 본문 변환 패턴은 §3.34.46 박스에 영구화 완료 (다음 차부터 재사용 가능)
