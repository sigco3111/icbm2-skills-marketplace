# 343차 — proxy-first 발행과 canonical 동기화 재검증

## 결과
- 주제: `Show GN: guru-maker - 스스로 발전하는 투자 에이전트`
- 발행 URL: `https://sigco.tistory.com/1142`
- 카테고리: AI/ML (`1219746`)
- 본문: 2,513자, 이미지 2장, 코드 블록 1개

## 재사용 가능한 실행 정형
1. 세션 가드에서 HTTP 200 + JSON + 최신 글 ID를 확인한다.
2. `blog_pipeline.py --category`는 한 번만 호출하고, 반환 JSON을 해당 실행의 SSOT로 고정한다.
3. canonical topic과 source URL을 `published_topics.json`, `published_urls.txt`, state에서 모두 검사한 뒤 중복이 없을 때만 진행한다.
4. 본문은 `parts.append()`로 빌드하고 코드 블록은 `code_lines` + `"\n".join(...)`으로 분리한다.
5. 빌드 직후 다음을 확인한다.
   - Python lint와 실행 exit 0
   - 본문 바이트/문자 수
   - 이미지와 코드 블록 수
   - CJK 의심 치환 0건
   - `parts.append` 실제 개수와 작성 시 기대 개수 일치
6. standalone wrapper에서 `publish_post()`를 호출한다. `tags`는 쉼표 구분 문자열로 넘긴다.
7. 숫자형 발행 URL을 받은 직후, commit 전에 proxy 검증을 먼저 수행한다.
   - HTTP 200
   - `og:title` 정확 일치
   - source URL 존재
   - 의심 CJK 0건
8. proxy PASS 뒤에만 `--commit`과 state/published_topics canonical 동기화를 실행한다.
9. 최종 `check_state_consistency.py`가 신호 4로 exit 1이어도, 동일 URL의 proxy 검증이 통과했다면 구조적 오탐으로 확정한다.

## 이번 차에서 재확인된 함정
- `commit_publish()` 출력의 `stats.total`과 state 최상위 `total` 필드는 같은 구조라고 가정하면 안 된다. 성공 판정은 `daily_counts` 증분과 실제 URL/proxy를 기준으로 한다.
- canonical hash는 SEO 제목이나 숫자 ID가 아니라 pipeline이 반환한 원래 topic 문자열의 MD5다.
- source footer는 `publish_post()`가 발행 시 추가하므로 빌드 파일에서 source URL이 없더라도 실패가 아니다. proxy 본문에서 확인한다.
- 최종 상태 검증의 신호 4는 새 `details[-1]`과 `last_published_url`을 같은 슬롯으로 맞추는 정상 동기화에서도 구조적으로 발생한다. exit code만 보고 롤백하거나 재발행하지 않는다.

## 검증 증거
- publish stdout: `PUBLISH=SUCCESS URL=https://sigco.tistory.com/1142`
- proxy: `status=200`, `title_match=True`, `source_present=True`, `cjk_suspicious=False`
- 상태: `daily_counts[2026-07-30]` 합계 4→5, AI/ML 3→4
- state/published_topics last URL: 모두 `#1142`
