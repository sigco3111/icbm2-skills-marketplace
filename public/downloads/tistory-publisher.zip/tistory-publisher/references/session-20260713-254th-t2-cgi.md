---
session: 254th
date: 2026-07-13
type: green-run confirmation
gn_topic_id: 31335
tistory_url: https://sigco.tistory.com/985
category: AI/ML
category_id: 1219746
score: 1.0
title: 『터미네이터 2』 기술의 구술사(2017) — T-1000을 만든 ILM의 6개월과 자체 도구들
---

# 254차 — T-1000 VFX 구술사 (gn=31335, 1점, AI/ML)

## 결과 요약
- **§3.8.1 가드 통과**: `status=200, ct=application/json;charset=UTF-8, cookie_count=8`
- **§3.34.43 PWD 보강**: `PWD=/Users/mac` 명시
- **§3.34.40 FRESH 4-field**: TOP 12 후보 (31340/31351/31349/31342/31350/31352/31348/31343/31334/31338/31336/31335) 중 9건 모두 state.details에 PUB 처리됨 → FRESH 3개 (31338/31336/31335) 중 점수 최우선 31335 픽
- **§3.5 5중 신호 일치**: 사전 검증 시 모두 `#984` → 발행 후 모두 `#985` 일치
- **post_publish_sync**: `pt_updated: true / state_updated: true / errors: [] / triple_signal_match: true`
- **daily_counts[2026-07-13]**: `{'개발팁': 1, '개발도구': 1, 'AI/ML': 2}` (+1 정확, cat_id 누설 0)
- **state.details 61→62, pt.details 77→78** 모두 박힘
- **이미지 2장 CDN 업로드 정상**: query=`vintage 1990s computer graphics workstation SGI monitor dark room`
- **본문 2,768자** (300자 가드 통과)
- **연속 all-green 39회차** (213~254차)

## 본 세션 관찰 (사소함, 신규 발견 없음)

### 1. Picsum 동일 이미지 매칭 (관찰용, 가드 영향 없음)
같은 image_query로 2장 요청 시 **Picsum이 두 번 같은 ID(907)를 반환**하는 현상 관찰. 이번 차는 본문 그림 위치가 달라 시각적으로 자연스러웠고 가짜 발행 가드엔 영향 없음. 일반적으로 query를 변형하거나 `--image-count 1`로 줄이는 것을 고려. (현재 `--image-count` 옵션 미확인 — 254차엔 시도 안 함.)

### 2. gn-fetch-content 양호 동작 (관찰용)
- `gn-fetch-content.py` 직접 호출 (Python 3.9, importlib.util.spec_from_file_location 패턴) 정상 동작
- 31335: 13,675자 추출 (HTML fallback, `article` 패턴)
- 31338 (Android 앱→웹): 4,152자
- 31336 (Emacs 서비스): 7,175자
- 244차 §3.34.40 명시 그대로 — 충분한 본문 확보 가능

### 3. FRESH 4-field 매칭 실전 재확인
244차에 도입된 4-step 패턴이 정확히 동작:
1. `--refresh-topics --dry-run`으로 후보 12개 추출
2. 격리 python3로 pt/details + state/details 양쪽 교차 → FRESH 판정
3. write_file로 draft.md 저장
4. 격리 bash (`PWD=/Users/mac` 명시)로 `tistory_publisher.py --file ...` 호출
5. `post_publish_sync.py sync` 7필드 보정

이번 차 31335 픽까지 0점 손실. **§3.34.39 (a) `--category` 단독 호출 회피** 원칙 그대로 유효.

## 본 세션 미적용 (의도적)
- `--image-count` 변형 시도: 안 함 (query가 한 번에 적중했고 본문 2장에 같은 ID여도 시각 OK)
- `tistory_publisher.py --check-session` 호출: 안 함 (실전 publish 검증으로 세션 OK 이미 확인됨)
- `verify-tistory-cookie.sh` 실행: 안 함 (§3.34.42 격리 함정 — 246차부터 안 씀)

## SKILL.md 본문 갱신 사항
- 없음 (모든 패턴 정착, 신규 발견 없음)
- §3.34.44 후보 (253차 cron 차 사이 drift)는 이번 차에서도 drift 무해 — 5중 검증 일치 유지