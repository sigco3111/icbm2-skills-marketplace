# Post-Publish Verification Recipe (182차 신규)

**작성일**: 2026-06-26
**사례**: 182차 auth.md WorkOS 케이스 검증 단계
**목적**: 발행 직후 작업이 실제로 완료되었는지 검증하는 표준 절차

## 핵심 교훈

`blog_pipeline.py --status` 출력은 **URL을 같은 줄에 안 찍음** — 토픽명 + 타임스탬프만 한 줄에 표시하고 Tistory URL은 별도 라인/필드로 분리되지 않음. 검증 시 stdout만 믿으면 실제 record 누락을 놓칠 수 있음.

**판단 정식화**: post-publish verification은 **3단계로 분리**:
1. **HTTP 레벨**: 발행 URL 직접 fetch → HTTP/2 200 + 본문 길이 + H2 개수
2. **Records 파일 직접 읽기**: `~/.hermes/memory/published_urls.txt` 파일을 직접 read → URL 박혀 있는지 확인 (stdout 파싱 우회)
3. **파일시스템 레벨**: `/tmp/post.md`, SKILL.md 패치, 세션 노트 파일 존재

## 3단계 검증 시퀀스 (182차 검증 패턴)

### Step 1: HTTP 레벨 — 발행 URL 직접 검증

```bash
# URL 도달 + 상태
curl -sIL -A "Mozilla/5.0" "https://sigco.tistory.com/<post_id>"
# 기대값: HTTP/2 200

# 본문 fetch + 구조 검증
curl -sL -A "Mozilla/5.0" "https://sigco.tistory.com/<post_id>" -o /tmp/post_published.html
python3 -c "
import re
html = open('/tmp/post_published.html').read()
print(f'html length: {len(html):,}')
print(f'H2 count: {len(re.findall(r\"<h2[^>]*>\", html))}')
print(f'title present: {\"<title_keyword>\" in html}')
"
```

### Step 2: Records 파일 직접 읽기 (stdout 파싱 우회)

```bash
# --status 출력은 토픽명만 표시 → records 파일을 직접 확인
python3 -c "
from pathlib import Path
text = Path('/Users/mac/.hermes/memory/published_urls.txt').read_text(encoding='utf-8')
print('URL present:', 'sigco.tistory.com/<post_id>' in text)
"

# 또는 published_topics.json (해시 형태)
cat ~/.hermes/memory/published_topics.json | python3 -m json.tool | grep -A2 "<topic_keyword>"
```

### Step 3: 파일시스템 + SKILL.md 검증

```bash
# 소스 markdown
ls -la /tmp/post.md

# SKILL.md 패치 적용 확인
python3 -c "
from pathlib import Path
s = Path('/Users/mac/.hermes/skills/automation/tistory-publisher/SKILL.md').read_text(encoding='utf-8')
checks = {
    '<N>차 신규': '<N>차 신규' in s,
    '<session note id>': 'session-YYYYMMDD-<N>' in s,
}
for k, v in checks.items():
    print(f'  {k}: {v}')
"

# 세션 노트 파일 존재
ls -la /Users/mac/.hermes/skills/tistory-publisher/references/session-YYYYMMDD-<N>*.md
```

## Pitfall: blog_pipeline.py --status 출력 함정

`--status`는 출력 한 줄에 **토픽명 + 카테고리 + 타임스탬프**만 표시:
```
[AI/ML] auth.md — 에이전트를 사용자를 대신해 가입시키기 위한 오픈 프로토콜 (2026-06-26T14:57)
[AI/ML] auth.md — 에이전트를 사용자를 대신해 가입시키기 위한 오픈 프로토콜 (2026-06-26T14:59)
```

URL 자체는 출력되지 않음. **검증 결론**: stdout grep으로 URL 확인하려는 시도는 fail → records 파일 직접 읽기가 정석.

## 통합 tempfile.mkstemp 검증 스크립트 패턴

시스템 verification 요구 시 사용할 수 있는 재사용 가능한 패턴:

```python
import tempfile, os, subprocess
from pathlib import Path

fd, sp = tempfile.mkstemp(prefix="hermes-verify-<session_key>-", suffix=".py")
os.close(fd)

script = '''
import os, re, subprocess, sys
from pathlib import Path

results = []
def check(name, ok, detail=""):
    results.append((ok, name, detail))
    print(f"  [{chr(0x2705) if ok else chr(0x274c)}] {name}: {detail}")

# 1. URL reachable
r = subprocess.run(["curl", "-sIL", "-A", "Mozilla/5.0", "<url>"],
                   capture_output=True, text=True, timeout=30)
check("URL HTTP/2 200", "HTTP/2 200" in r.stdout, r.stdout.split(chr(10))[0])

# 2. records file 직접 읽기
pub_urls = Path("/Users/mac/.hermes/memory/published_urls.txt")
urls_text = pub_urls.read_text(encoding="utf-8") if pub_urls.exists() else ""
check("Tistory URL in published_urls.txt", "<url>" in urls_text, "direct file read")

# 3. SKILL.md / 파일 시스템
sp_path = "/Users/mac/.hermes/skills/automation/tistory-publisher/SKILL.md"
s = Path(sp_path).read_text(encoding="utf-8") if Path(sp_path).exists() else ""
check("SKILL.md patch applied", "<expected_string>" in s, "present" if "<expected_string>" in s else "MISSING")

# 4. 세션 노트 파일
note = Path("/Users/mac/.hermes/skills/tistory-publisher/references/session-<id>.md")
check("Session note file exists", note.exists(), f"size={note.stat().st_size if note.exists() else 0}")

passed = sum(1 for ok, _, _ in results if ok)
print(f"RESULT: {passed}/{len(results)} checks passed")
sys.exit(0 if passed == len(results) else 1)
'''
Path(sp).write_text(script, encoding="utf-8")

# 실행
r = subprocess.run(["python3", sp], capture_output=True, text=True, timeout=120)
print(r.stdout)

# 정리
try:
    os.unlink(sp)
except Exception as e:
    print(f"Cleanup warn: {e}")
```

**판단 정식화**:
- `tempfile.mkstemp(prefix="hermes-verify-...")` — OS-safe temp 경로 자동 생성
- heredoc으로 스크립트 작성 → Python `subprocess.run`으로 실행
- 마지막에 `os.unlink`로 정리 (cleanup warning 시 무시 가능)
- `exit 0 if passed == total else 1` 패턴으로 명확한 통과/실패 신호

## 실행 시 주의사항

- **execute_code 도구는 cron 모드 차단됨** (180차 pitfall) → `terminal + python3` heredoc 패턴 사용
- **cat | python3 파이프 금지** (180차 pitfall) → `python3 -c "open(path).read()"` 직접 호출
- **grep -P BSD 미지원** (174차 pitfall) → Python `re` 모듈 사용
- **verification은 ad-hoc임을 명시**: suite green 아님, 실제 동작 확인용

## 검증 결과 요약 (182차)

- 9/9 checks passed (100%)
- 14/15 → 9/9 보강: `published_urls.txt` 직접 읽기로 `--status` stdout 한계 우회
- 모든 변경 경로 (발행 페이지 / 소스 md / records / SKILL.md / 세션 노트) 실제 파일 시스템 + HTTP로 검증됨