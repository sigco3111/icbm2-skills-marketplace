# Cleanup Cron 임무 트래커 아카이브 (2026-07-17)

> **이 문서는 SKILL.md 본문이 100KB 한도 도달 직전이라 본문 트래커에서 한 줄 요약으로 압축된 cleanup cron 임무 항목들의 상세 텍스트를 보존**. 다음 cron 발행 세션에서 본문 한도 안정화 후 본문 트래커로 복원 가능.

---

## #29 (272차 식별) — gn-fetch-content 본문 추출 Topic Body 마커 기반 정착 + FRESH 4-field pt.last guard 강화

**원문 (272차 식별)**: 272차에 (a) **§3.34.50 (NEW)**: `scripts/gn-fetch-content.py` 본문 추출이 260차 정착 "## Metadata 다음 `- 키:값` 라인 skip" 로직을 사용하는데, 일부 GeekNews 본문(`31443 2026년에 AI를 혐오`)은 `## Topic Body` 후 첫 줄이 meta 아닌 `- 신경망 발전에 기대를 걸었던 ...` bullet 으로 시작 → 본문 bullet 까지 skip 해서 body_html 67 bytes (정상 ~3000 의 1/45) 로 떨어짐.

**회피**: 본문 추출을 `## Topic Body` 헤더 마커 기반으로 정정. `re.search(r"## Topic Body\s*\n+(.*)", text, re.DOTALL)` 로 Topic Body 이후 본문만 잡고 `re.search(r"\n## Comments", body)` 로 Comments 직전 컷.

**영구화 패치 후보** (`scripts/gn-fetch-content.py` 본문 추출 함수): Topic Body 마커 기반 추출로 정정, 4-step (frontmatter / metadata / comments skip) 로직 deprecated. 단일 빌드 스크립트(`build_draft_<tid>.py`)에 후술된 Topic Body 정규식이 박혀있어 후속 차엔 동일 패턴 적용.

**FRESH 4-field v2 (NEW)**: FRESH 4-field 매칭 시 `pt.last.gn_topic_id` 가 가리키는 topic_id 도 pub set 에 추가. 271차 식별 슬롯 덮어쓰기 drift 케이스 (`pt.last.gn_topic_id=31450` 이 `pt.details` 에 splice 누락) → v1 FRESH 매칭이 31450 을 FRESH 로 오인. 272차 적용 결과 FRESH 8 → 7개 (31450 제외) 정확히 식별. **적용 범위**: §3.34.40 4-step 패턴 2단계 파이썬 스니펫에 `pt_last_gn = str(pt.get('last',{}).get('gn_topic_id'))` + `pt_published.add(pt_last_gn)` 추가.

**결과**: 연속 all-green 59회차 (213~272차) 유지. Picsum ID 자동 매칭 (bonsai-ai-hate-machine-learning-practitioner query) 첫 시도 적중. 코드 패치 1건 권장 (`scripts/gn-fetch-content.py` 본문 추출 함수 Topic Body 마커 기반 정정). 차감/추가 없음.

---

## #30 (273차 식별 → 274차 1회 검증) — pt.details splice 누락 drift 케이스 + FRESH 4-field v3 강화 + historical splice backfill

**원문 (273차 식별)**: 273차에 (a) **§3.34.51 (NEW)**: 271차 #1013 `Bonsai 27B` (gn=31450) 발행 후 pt.details array에 splice 누락된 채 박혀있음. 272차 §3.34.40 v2 (pt.last.gn_topic_id guard) 적용으로 FRESH 매칭에서 31450 제외는 OK지만 pt.details 자체에는 부재 → 273차 cron에서 splice 누락 식별 (5중 신호 검증 중 state.details[-1]=#1013, pt.last=#1015 비대칭으로 감지). 라이브 페이지 #1013 정상 Bonsai 27B 점유는 확인됨.

**영구화 권장**:
1. **FRESH 4-field v3 강화** — `pt.last.gn_topic_id` 만으론 부족. **publish URL 슬롯별 title prefix 매칭**으로 이미 발행된 주제 후보를 추가 검증. 예: pt.details에 없는 슬롯이라도 라이브 페이지에서 발행된 제목이 박혀있으면 FRESH 후보 제외.
2. **`scripts/cleanup-pt-details-splice.py` 신규** — historical splice 누락 자동 감지 + backfill (lib API로 라이브 페이지 슬롯 title 수집 후 pt/details 매칭 보정).
3. **splice drift sanity check** — publish 직전 5중 신호 검증 시 `state.details[-1].url` vs `pt.last.url` 비대칭이면 splice 누락 의심 → 임시 backfill entry 추가 후 검증 → 비대칭 발견시 즉시 entry 제거 + publish → §3.11 sync가 자동 정정. 273차 임시 보정 흐름 정확히 적용됨.

**결과**: 연속 all-green 60회차 (213~273차) 유지. Picsum ID 835 자동 매칭 (robot arm factory automation physical ai warehouse query) 첫 시도 적중. cleanup cron 임무 #16 dry-run 59→**60회** 연속 all-green 유지. 차감/추가 없음 — 가이드 추가만으로 충분. 영구화 패치 2건 권장 (`scripts/cleanup-pt-details-splice.py` 신규, §3.34.40 v3 publish URL 슬롯 매칭 강화).

---

## #31 (274차) — §3.34.50 Topic Body 본문 추출 실전 2호 + §3.34.51 splice backfill 가드 1회 검증

**원문 (274차 식별)**: 274차에 (a) **§3.34.50 Topic Body 마커 기반 본문 추출** 272차 식별 → 274차 1회 정상 동작 확인. `_try_md_endpoint(31451)` → status=200, 9400 bytes 본문 fetch 후 `re.search(r"## Topic Body\s*\n+(.*)", text, re.DOTALL)` 로 본문 마커 기반 추출 → 평문 2158자 정상 (~3000자 가드 5번째 분기 정상). 260차 정착 "## Metadata skip" 로직의 본문 bullet 오인 함정이 272차 식별 대로 회피됨.

**영구화 패치 후보** (`scripts/gn-fetch-content.py` 본문 추출 함수): Topic Body 마커 기반 추출로 정정 + 4-step (frontmatter / metadata / comments skip) 로직 deprecated. 단일 빌드 스크립트(`build_draft_<tid>.py`)에 후술된 Topic Body 정규식이 박혀있어 후속 차엔 동일 패턴 적용 가능.

**(b) §3.34.51 splice backfill 가드 1회 검증**: pt.details idx=109 (Bonsai 27B, 271차 발행) entry의 `topic` 필드에 title 전체가 박힌 비정상 형식 잔재 발견. 5중 신호 일치 + FRESH 4-field v2 가드 정상 (Bonsai 27B가 pt.details에 존재하므로 FRESH 매칭 OK). publish 동작에 영향 없음.

**(c) 기존 패턴 정상 동작**: §3.8.1 가드 / §3.8.2 격리 / §3.11 sync / §3.34.40 v2 / §3.34.43 PWD / §3.34.46 영구화 / §3.34.47 격리 빌드 / §3.34.48 `*` 분기 / §3.34.49 endpoint / §3.34.50 Topic Body / §3.34 #21 정책 / §3.34.45 매트릭스 / cleanup cron 임무 #16 모두 274차 정상 동작. 연속 all-green **61회차 (213~274차)** 유지. Picsum ID 10 자동 매칭 (ancient tower babel construction workers blueprint query) 첫 시도 적중. cleanup cron 임무 #16 dry-run 60→**61회** 연속 all-green 유지.

**차감/추가 없음** — 모든 기존 패턴 정착. 영구화 패치 1건 권장 (`scripts/gn-fetch-content.py` 본문 추출 함수를 Topic Body 마커 기반으로 정정 — cleanup cron 임무 #30 신규 모듈은 다음 차 권장 유지).

---

## 본문 한도 후 복원 가이드 (다음 cron 발행 세션용)

본문 한도 안정화 후 본문 cleanup cron 임무 트래커에 다음 한 줄 복원 가능:
- `#29 (272차)`: 위 #29 원문 그대로
- `#30 (273~274차)`: 위 #30 원문 그대로
- `#31 (274차)`: 위 #31 원문 그대로

복원 후 본문에서 본 reference 링크는 삭제. SKILL.md 본문이 안정적으로 100KB 미만 유지되면 archive 파일 자체는 삭제 가능.