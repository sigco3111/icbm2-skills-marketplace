303차 세션 — AI 조언 오버컨피던스 StableQA 메타 분석 (#1054, gn=31614) 발행 + 가드 격리 한계 3중 함정 발견

## 시간
2026-07-20 21:04 KST (cron 자동)

## 발행 결과
- **#1054** (AI/ML, gn=31614, score 3.0) — "AI 조언을 받으면 정확도는 3분의 1로 떨어지고 자신감은 2배 이상 높아짐" (StableQA 메타 분석)
- 본문 3245자 + Picsum 이미지 2장 (seed: aiadvice-overconfidence, stableqa-meta-analysis)
- tags: AI연구, AI조언, 인간-AI협업, 인지편향, AI거버넌스, 연구결과, 오버컨피던스, ICBM2
- og:title 정확 매칭 (proxy check status=200 + title="AI 조언을 받으면 정확도는 3분의 1로 떨어지고 자신감은 2배 이상 높아짐")

## 워크플로 정상 부분
- §3.5 신호 4 발동 (예상 패턴, 6연속)
- §3.11 5-5 proxy check disambiguate 통과 → 진짜 발행
- 5-2-A 백필 1건 (idempotent)
- 5-3 last+details 통합 보정 (#1053 → #1054, details_len 126→127)
- commit_publish stats.today={AI/ML:7}, total=48

## 신규 발견 3건 (303차 핵심)

### 발견 1 — `session_expiry_guard.sh` 가드 격리 한계 3중 함정
`session_expiry_guard.sh`가 290차에서 처음 발견된 env -i 격리 버그가 303차에도 잔존. 3가지 환경에서 모두 깨짐:

1. **Xcode python3 충돌**: `/usr/bin/python3`가 Xcode 번들(`/Applications/Xcode.app/Contents/Developer/usr/bin/python3`, 3.9.6)을 가리키는 PATH 환경에서 `ModuleNotFoundError: No module named 'requests'` → exit 10.
2. **user-site 격리 실패**: `requests`가 `/Users/mac/Library/Python/3.9/lib/python/site-packages`에만 설치된 경우 `env -i PYTHONPATH=`로는 못 잡음. `python -s` 옵션은 user-site를 비활성화하므로 정반대로 더 안 잡힘.
3. **env -i가 source된 환경변수를 무시**: `set -a; source tistory.env; set +a`로 미리 TISTORY_* 쿠키를 export해도 `env -i`는 자기 뒤에 오는 환경변수만 보존. 결과 cookies_count=0 → 302 오탐.

**해결 (303차 실전 검증)**: 가드 스크립트 자체를 다음 형태로 교체해야 함:
```bash
set -a; source ~/.hermes/secrets/tistory.env; set +a
unset PYTHONPATH PYTHONHOME
PYTHONNOUSERSITE=1
export PYTHONPATH=/Users/mac/Library/Python/3.9/lib/python/site-packages
/usr/bin/python3 -s <guard_inner.py>
```

**원칙**: 격리 모드(`env -i`)는 가드 단순화용 shortcut이 아니라 자체 버그 원인. (a) source한 환경변수 보존 + (b) `requests`가 사는 user-site PYTHONPATH 명시 + (c) `python3 -s`로 venv 누설 차단만으로도 충분히 격자.

### 발견 2 — `/usr/bin/python3` macOS PATH 의존성
macOS에서 `/usr/bin/python3`가 가리키는 python이 PATH 우선순위 의존:
- 일치 케이스: `/Applications/Xcode.app/.../python3` (Xcode Command Line Tools 3.9.6)
- 충돌 케이스: homebrew python or 다른 셰뱅

이번 차에서는 `/usr/bin/python3`가 Xcode python을 가리켰음 → `requests` 없음. `which python3`로 확인 필수.

### 발견 3 — `response['items'][0]['id']`로 진짜 발행 검증
301차까지 `re.findall(r'"id"\s*:\s*(\d+)', r.text)`로 첫 5개 id 추출했으나 이번 차에는 빈 리스트 반환. 직접 `r.json()['items'][0]['id']`로 진짜 첫 entry id 추출 → "1053" (302차 발행글) 정상 확인. 더 정확한 검증 패턴.

## disambiguate 6연속 확정
298→299→300→301→302→**303** 동일 패턴:
1. 정상 publish + 5-3 동시 갱신
2. §3.5 신호 4 발동 (구조적으로 무조건 같음)
3. §3.11 5-5 proxy check status=200 + title 매칭 → 진짜 발행
4. publish 진행

→ **이 패턴은 정상 워크플로의 일부로 정착**, 더 이상 drift 보고 라인에 명시하지 않아도 됨.

## by_category 영구 누적 6연속 (297차 함정 8)
303차 #1054 발행 후에도 `by_category["1219746"]=1` 동일 유지. 코드 동작 `=` 할당으로 297차 첫 매핑 후 신규 누적은 없지만, 카테고리명 norm(`AI/ML`)과 분리된 1개 키가 영구 누적. SSOT 변경이라 사용자 게이트 시 1회 ID_TO_NAME 보정 권장. 사용자 게이트 없으면 cron은 drift 보고만 유지.

## 누적 통계
- 연속 all-green **83회차** (303차 포함)
- 303차 daily_counts={AI/ML:7}
- 발행 누적: 297 #1048 + 298 #1049 + 299 #1050 + 300 #1051 + 301 #1052 + 302 #1053 + 303 #1054

## 후속 과제 (SSOT 변경 — 사용자 게이트 권장)
1. **session_expiry_guard.sh 자체 재작성**: 3중 함정 해소 (env -i 제거 + PYTHONPATH 명시 + `python3 -s`). 290차 보고 후 13회차 동안 미해결 상태.
2. **by_category 1회 ID_TO_NAME 보정**: SSOT 변경이므로 사용자 승인 필요. 영구 해결.
3. **SKILL.md 본문의 모든 `env -i ...` 호출 점진 교체**: 시간이 지날수록 환경 의존성 증가 (Xcode python 충돌, user-site 격리, 쿠키 누수).
