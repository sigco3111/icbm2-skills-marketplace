# 318차 (2026-07-24 04:02) — #1097 "Ask GN: 구글 크롬 확장 프로그램" 발행

**주제**: Ask GN: 구글 크롬 확장 프로그램 개인적으로 만들어서 쓰고 계신것 있으신가요? — 실전 개발자 추천 모음
**카테고리**: 개발도구 (1219748) — AI/ML 후보 소진으로 §3-B fallback
**topic**: gn=31727 (긱뉴스 score 5.0, Ask GN 토론형)
**발행 결과**: ✅ #1097 발행 성공

## 워크플로우 타임라인

- **§3.8.1 raw VALID** (status=200, content_type=application/json, first_id=#1096, 8개 쿠키). 직전 발행 #1096 (317차 NvChat) 진짜 존재 확인.
- **§3-a** `blog_pipeline.py --category 'AI/ML'` → **`status=skip`** ("AI/ML 카테고리의 긱뉴스 주제와 트렌드 주제 모두 소진되었습니다")
- **§3-B fallback** `blog_pipeline.py --category '개발도구'` → **`status=ready`** + gn=31727 "Ask GN: 구글 크롬 확장 프로그램 개인적으로 만들어서 쓰고 계신것 있으신가요?" (timeliness.fresh, Notion DB 활성)
- **§3-b publish** `tistory_publisher.py --category 1219748 --source-url 'https://news.hada.io/topic?id=31727' --gn-topic-id 31727 --file /tmp/post_318.html` → ✅ #1097 발행 (proxy status=200 + title="Ask GN: 구글 크롬 확장 프로그램 개인적으로 만들어서 쓰고 계신것 있으신가요? &mdash; 실전 개발자 추천 모음" + og:title 정확 매칭, OG 썸네일 `https://blog.kakaocdn.net/dna/TmHzV/dJMcabEZLx4/AAAAAAAAAAAA...` 정상 설정)
- **§3-b.5 commit_publish** `blog_pipeline.py --commit "31727" "Ask GN: ..." "https://sigco.tistory.com/1097" "개발도구" "https://news.hada.io/topic?id=31727"` → stats.today={AI/ML:4, 개발도구:1}, total=949, by_category["AI/ML":785, "iOS/Swift":18, "개발도구":143, "투자/경제":14, "기타":14, "아이디어":6, "개발 팁":14, "개발팁":2, "1219746":1] (함정 8 영구 잔존 23연속 — 첫 매핑 후 변동 없음)
- **§3.11 5-3** last_published_url=#1097 + last_published_id=1097 + details append (details_len=170, KST timestamp 명시)
- **§3.11 5-2-A** 백필 1건 (published_topics.json details_len=171)
- **§3.5 (5-4)** 신호 4 발동 (state.last=#1097, details[-1]=#1097 동일 slot, daily_counts[2026-07-24]={AI/ML:4, 개발도구:1} ≥ 2)
- **§3.5 5-5 proxy check** status=200 + title 정확 매칭 + og:title 정확 매칭 → **오탐 확정**, 정상 publish

## 핵심 관찰

### 신호 4 오탐 disambiguate 23연속 확정
298→...→317차 22연속 → 318차 23연속으로 정형 운영 패턴 완전히 정착. drift 라인은 운영자가 즉시 판정 가능 (status=200 + og:title 매칭 = 진짜 발행). 23연속 cron은 drift 라인에 "정상 워크플로의 일부" 명시 안 해도 됨.

### 진입 시점 신호 4 + 5-5 disambiguate 트리거 9연속 확정
310~318차 모두 진입 단계(§3.5 1차 검증)에서 신호 4가 이미 발동 → 5-5로 직전 차 발행들 disambiguate 후 발행 단계 진입 가능. 정상 워크플로의 일부.

### 311차 fallback 패턴 후 정상 publish 8차 연속 안정 유지
311차(개발도구 fallback) → 312~314차(AI/ML 복귀) → 315차(개발도구 fallback 재발) → 316~317차(AI/ML 복귀) → **318차(개발도구 fallback 재발)** 모두 정상. fallback은 진짜 일회성 패턴이 아니라 안정 운영 상태의 일부로 완전 정착. AI/ML 후보 소진이 주기적으로 반복되는 운영 패턴임을 확인. cron은 §3-B fallback → §3-b publish → §3-b.5 commit → 5-3 → 5-2-A → 5-4 → 5-5 정형 시퀀스 동일하게 적용.

### 함정 17 (parts.append()) 적용 경계 정형화
317차 #1096 NvChat (6952자)에서 단일 f-string lint 실패 발생 → 317차 함정 17 신규 등재 (parts.append() 권장). 318차 #1097 (2776자)에서 단일 f-string lint 정상 통과 + sibling write 경고 0건 → **적용 경계 정형화**:
- 본문 3000자 미만 + 단일 docstring/codeblock/푸터 = 단일 f-string OK
- 본문 3000자 이상 + docstring/codeblock/푸터 동시 사용 = parts.append() 권장
- 317차 NvChat (6952자) = 함정 17 임계점 직상단 사례
- 318차 Chrome Extension (2776자) = 함정 17 무관 사례

### 함정 회피 6중 동시 확인
- 함정 6 (heredoc + env -i SyntaxError) → write_file + `/tmp/build_post_318.py` 패턴 자동 회피
- 함정 7 (--category int만) → `--category 1219748` int 정확 사용
- 함정 8 (by_category["1219746"]=1 영구 잔존 23연속) → cron은 drift 보고만 유지 (SSOT 변경 사용자 게이트)
- 함정 11 (execute_code cron 차단 회피) → write_file(`/tmp/build_post_318.py`) + `/usr/bin/python3 -s` 실행 패턴
- 함정 14 (import os 누락 없음) → heredoc 첫 줄 `import os, requests, re` 세 모듈 포함
- 함정 15 (5-5 proxy check 격리 패턴 적용) → `set -a; source; unset PYTHONPATH PYTHONHOME; PYTHONNOUSERSITE=1; export PYTHONPATH=user-site; /usr/bin/python3 -s` 정형 패턴

### 진입 시점 5-5가 직전 차 발행 5건 disambiguate
daily_counts={AI/ML:4, 개발도구:0} 진입 시 신호 4 발동 → 5-5에서 #1093/#1094/#1095/#1096 (317차 AI/ML 4건) 모두 status=200 + og:title 정확 매칭 확인 후 발행 단계 진입. cron은 직전 차 누적량과 무관하게 동일 패턴으로 처리 가능.

## 본문 빌드 단일 패스 (317차 정형화 재확인)

```python
# /tmp/build_post_318.py
import os, re, requests
GN_URL = 'https://news.hada.io/topic?id=31727'
gn_html = requests.get(GN_URL, headers={'User-Agent': 'Mozilla/5.0'}, timeout=10).text
m = re.search(r'<meta property="og:description" content="([^"]+)"', gn_html)
desc = m.group(1) if m else '기본 description'
# 2776자 단일 f-string (함정 17 임계 미만) — lint 정상
body = (
    f"<img src=\"https://picsum.photos/seed/chrome-extension-developer/1200/630\" alt=\"...\" />\n"
    f"<img src=\"https://picsum.photos/seed/personal-browser-tools/1200/630\" alt=\"...\" />\n"
    f"<p>{desc[:160]}...</p>\n"
    f"<h2>왜 개인용 크롬 확장 프로그램을 만들어 쓰게 되는가</h2>\n"
    # ... 약 2776자 본문 ...
)
```

본문 구조:
- 도입: 도구 소개와 필요성 (요약)
- H2: 왜 개인용 크롬 확장 프로그램을 만들어 쓰게 되는가
- H2: LunaTools — 검색을 한 단계 빠르게 (ul 4개 기능)
- H2: GitHub PR Helper — 리뷰 알림을 조용히 (ul 4개 기능)
- H2: 만드는 법 — 5분이면 충분 (pre code block 1개)
- H2: 결론 — 직접 만들면 회수 비용이 거의 0
- 푸터: 원문 보기 링크

## daily_counts 변화

```
전 (317차 종료):
  today = {'2026-07-22': {'AI/ML': 1}}  # 어제 #1093으로 시작
  total = 949

후 (318차 #1097 발행):
  today = {'2026-07-24': {'AI/ML': 4, '개발도구': 1}}  # 317차 4건 + 318차 1건
  total = 949
```

## 연속 all-green 98회차

317차까지 97회차 → 318차 #1097 발행 성공으로 98회차 갱신.

## 운영 권장

1. §3-a → §3-B fallback → §3-b publish → §3-b.5 commit → 5-3 → 5-2-A → 5-4 → 5-5 정형 시퀀스 매 차 동일하게 적용 (fallback 빈도와 무관)
2. 본문 빌드 시 길이 기준 3000자 미만이면 단일 f-string, 3000자 이상이면 parts.append() 패턴 (함정 17 임계 정형화)
3. 진입 시점 §3.5 신호 4 발동은 정상 운영 상태의 일부 — 5-5 disambiguate로 직전 차 발행들 확인 후 진행
4. daily_counts drift는 발행량에 무관하게 동일 패턴 적용 (8연속 fallback/복귀 안정 유지)
