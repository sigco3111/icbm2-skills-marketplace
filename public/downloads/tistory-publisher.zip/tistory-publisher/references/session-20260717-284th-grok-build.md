---
session: 284th
date: 2026-07-17
topic_id: 31492
title: "#1033 Grok Build가 오픈 소스로 공개됨 — Rust로 만든 xAI 터미널 코딩 에이전트, TUI·에이전트 런타임·도구를 크레이트 단위로 풀었다"
gn: 31492
category: 개발팁
category_id: 1219747
score: 14
fresh_rank: 1 (FRESH 2개 모두 개발팁, AI/ML FRESH=0)
---

# 284차 — `#1033 Grok Build가 오픈 소스로 공개됨` (cron 자동 발행)

**날짜**: 2026-07-17
**슬롯**: #1033
**제목**: Grok Build가 오픈 소스로 공개됨 — Rust로 만든 xAI 터미널 코딩 에이전트, TUI·에이전트 런타임·도구를 크레이트 단위로 풀었다
**원문**: https://news.hada.io/topic?id=31492
**출처**: https://github.com/xai-org/grok-build

## 핵심 결과
- **연속 all-green 71회차** (213~284차)
- 개발팁 카테고리 (1219747) 정상 발행, entryId=1033 검증
- 본문 평문 3827자 (300자 가드 통과)
- 이미지 2장 (Picsum ID 848/610, rust terminal tui code editor query) 두 슬롯 자동 매칭
- 5중 신호 5/5 `#1033` 일치 (`all_match: True`)
- sync `triple_signal_match: true`, errors=[]
- daily_counts[2026-07-17] = `{'AI/ML': 6, '개발팁': 1}` (+1 정확, cat_id 누설 0)
- cleanup cron 임무 #16 dry-run 70→**71회** 연속 all-green

## §3.34 #21 AI/ML 우선 정책 실전 11호 (284차 검증)
FRESH 2개 식별:
- `31492` (개발팁, 14점) — Grok Build 오픈 소스 공개 (xAI)
- `31501` (개발팁, 9점) — 자유·오픈소스 AI 투자

AI/ML FRESH=0 → §3.34 #21 정책 "AI/ML FRESH=0이면 다른 카테고리 발행 허용" + §3.34.45 매트릭스 "FRESH 모두 비-기타 비-AI/ML → 점수 1순위 픽" → 개발팁 14점 `31492` 픽.

연속 검증:
- 255차 (1호) → 266차 (2호) → 268차 (3호) → 269차 (4호) → 270차 (5호)
- → 271차 (6호) → 280차 (7호) → 281차 (8호) → 282차 (9호) → 283차 (10호) → **284차 (11호)**

## §3.34.44 자정 사이 외부 발행 drift 무해 5호 (NEW, 284차 검증)
사전 검증에서:
- `state.last_published_url = https://sigco.tistory.com/1032` (자정 사이 283차 외부 발행 흔적)
- `pt.last.gn_topic_id = 31498` (283차 마지막 발행 토픽)

§3.34.40 v2 FRESH 4-field 매칭 정상:
- `pt_last_gn='31498'` pub set 추가 후 FRESH 2개 (31492, 31501) 정확 식별
- 284차 정상 publish 후 sync 보정으로 `#1033` drift 무해 회복
- §3.5 5중 검증 모두 일치 유지
- state.details count: 110→111, pt.details count: 125→126 모두 박힘 정상

cron 차 사이 한 건 이상의 외부 발행이 일반화됨을 다섯 번째로 확인:
- 253차 (식별) → 254차 (1호) → 270차 (2호) → 282차 (3호) → 283차 (4호) → **284차 (5호)**

## 본문 빌드 (284차)
- `/tmp/tistory_drafts_284th/build_draft_31492.py` (6564 bytes, UTF-8 선언)
- `/tmp/tistory_drafts_284th/draft_31492.html`
- 본문 평문 3827자 (intro 1단락 + 본문 3585자 + conclusion 2단락 + 마지막 단락)
- `_try_md_endpoint(31492)` → 8693 bytes 1단계 `.md` fetch 정상
- Topic Body 마커 추출 (272차 §3.34.50) — `- ` bullet 시작 본문도 정상 추출

## intro / conclusion 패턴 (260차 정착)
- intro: 한국 독자층 맞춤 1단락 (Grok Build + Apache 2.0 + 외부 기여 X 컨텍스트)
- conclusion: 한국 개발 환경 시사점 2단락 (TUI + Rust 모노레포 + ACP 프로토콜)
  + 원문/소스 링크 1줄

## md_to_html 빌드 (260차 정착 + 262차 보완 + 266차 * 분기 + 278차 > blockquote)
빌드 스크립트 `build_draft_31492.py` 에 5종 분기 모두 포함:
- `## 헤더` / `### 헤더` 라우팅
- `- ` 리스트 (들여쓰기 무시, 빈 줄 close 트리거)
- `- ## 위장 헤더` 라우팅
- `* ` 리스트 (bold `**` 시작 제외)
- `> ` blockquote 라우팅

이번 본문엔 `- ` 외 다른 패턴 없어 5종 중 1종만 적용 (안전 가드만).

## 동작 검증된 패턴 (모두 정상)
- §3.8.1 가드 (status=200, ct=application/json;charset=UTF-8, cookies=8)
- §3.8.2 격리 (`env -i HOME=... PATH=... PWD=... /bin/bash -c '...'` + `/usr/bin/python3` 3.9)
- §3.11 sync CLI (`sync` 서브커맨드 + 7필드 보정)
- §3.34.40 v2 (FRESH 4-field + pt_last_gn pub set 추가)
- §3.34.43 PWD 보강 (`PWD=/Users/mac` 명시)
- §3.34.46 영구화 (`_try_md_endpoint(31492)` → 8693 bytes)
- §3.34.47 격리 빌드 (write_file + 격리 호출)
- §3.34.48 `*` 분기 (이번 본문엔 `-` 만 사용, 분기 안전 가드)
- §3.34.50 Topic Body 마커 (3585자 본문 추출)
- §3.34.52 IME 가드 (title ASCII 토큰 sanity check)
- §3.34.53 `gfc` alias (importlib spec_from_file_location("gfc"))
- §3.34.54 `>` blockquote (이번 본문엔 `>` 라인 없어 미적용)
- §3.34.55 시그니처 (`text = _try_md_endpoint(tid)` 단일 변수 할당)
- §3.34 #21 정책 + §3.34.45 매트릭스
- §3.34 #39 (NEW) — 영문 자연어 Picsum query 첫 빌드 적중 검증 (rust terminal tui code editor agent command line → ID 848/610, 두 슬롯 동일)
- cleanup cron 임무 #16 (`cleanup_daily_cat_id_leak.py`)

## cleanup cron 임무 #39 (NEW, 284차 신규)
영문 자연어 + 키워드 혼용 Picsum query의 안정적 매칭 검증:
- query: `rust terminal tui code editor agent command line`
- 결과: ID 848/610 (두 슬롯 동일, 첫 시도 적중)
- 283차 자연어 query 첫 적중에 이어 두 번째 검증 — 영문 자연어 query의 안정적 사용 권장

## 라이브 페이지 검증
```
window.T.entryInfo = {"entryId":1033,"isAuthor":false,"categoryId":1219747,"categoryLabel":"개발 팁"};
<title>Grok Build가 오픈 소스로 공개됨 &mdash; Rust로 만든 xAI 터미널 코딩 에이전트, TUI&middot;에이전트 런타임&middot;도구를 크레이트 단위로 풀었다</title>
status=200, size=70378
```

## 본 세션 신규 발견
**0건** — 모든 패턴 정착된 playbook 그대로 정상 동작. 모든 기존 함정 회피 + 71회 연속 all-green.

## 후속 작업 권장
1. cleanup cron 임무 #30: `scripts/cleanup-pt-details-splice.py` 신구 모듈 — pt.details와 state.details splice drift 자동 보정 (historical 누적이 15개까지 누적, 한계 도달). 282차~284차 관찰 유지.
2. cleanup cron 임무 #39: 영문 자연어 Picsum query 안정 매칭 패턴 가이드에 추가.