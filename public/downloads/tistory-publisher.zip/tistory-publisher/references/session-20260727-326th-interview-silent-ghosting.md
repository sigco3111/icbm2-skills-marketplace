# 326차 (2026-07-27 01:00) — 면접 후 연락이 끊겼나요? 해독 신호

**§3.8.1 raw VALID** (status=200, first_id=1106, cookies_count=8) + §3.5 신호 4 FAKE_PUBLISH 발동 (state.last=#1107, details[-1]=#1107 동일 slot, daily_counts[2026-07-27]={AI/ML:1, 개발도구:1} ≥ 1) → **proxy check disambiguate 25연속 확정**: #1107/#1106/#1105 모두 status=200 + og:title 정확 매칭 → 진짜 발행, 오탐 확정.

295차 정책 + 311차 fallback 패턴 → AI/ML 후보 소진 → `--category '개발도구'` fallback. Topic **gn=31821 ("면접 후 연락이 끊겼나요?", 개발도구)** 선정 (Notion 1순위 후보). **305차 단일 패스 패턴 326차 재확인 (17연속 정형화)** — `build_post_326.py` 안에 `requests.get(gn_url) + <meta property="og:description"> regex` 임베드 → 122자 description 추출 ("Did They Ghost You? 는 면접 뒤 명확한 거절이나 안내 없이 연락을 끊은 회사를 익명으로 기록하는 공개 서비스임 승인된 제보 56...") + Picsum 이미지 2장 (seed: interview-silent-no / follow-up-cadence) + 본문 2778자 빌드 → **#1107 발행 성공** (proxy status=200 + title="면접 후 연락이 끊겼나요? &mdash; 해독 가능한 신호와 다음 행동" + og:title="면접 후 연락이 끊겼나요? — 해독 가능한 신호와 다음 행동" 정확 매칭, OG 썸네일 `https://blog.kakaocdn.net/dna/bWPGg6/dJMcagNdXG8/AAAAAAAAAAA...` 정상 설정).

§3.11 5-2 commit_publish (stats.today={AI/ML:1, 개발도구:1}, total=101, by_category["1219746"]=1 동일 유지 — 함정 8 영구 잔존 26연속) → 5-3 last+details 통합 보정 (#1106→#1107, details_len=180) → 5-2-A 백필 1건 (누적 동기화, published_topics.json details_len=181) → 5-4 §3.5 신호 4 발동 (오탐 25연속) → 5-5 proxy check #1107 + #1106/#1105 status=200 + og:title 정확 매칭 disambiguate 통과.

**326차 신규 관찰 — 진짜 개발자 도구 주제 fallback 정착**: 311차(bedctl), 315차(Linux Kernel CVE), 318차(Chrome Extension), 319차(OmniRoute), 326차(면접 후 연락 — ReplySet 류) 모두 정상 publish → **fallback이 단순 "개발도구 카테고리 ID로 publish"가 아니라 개발자 실전에서 자주 다뤄지는 주제(취업 도구, 디버깅, 개발 워크플로우, API 클라이언트)로 자연스럽게 흘러가는 패턴**. cron은 일자 다중 발행 누적(326차 진입 시 daily_counts={AI/ML:1, 개발도구:1})에서도 §3-B fallback → §3-b publish → §3-b.5 commit → 5-3 → 5-2-A → 5-4 → 5-5 정형 시퀀스 동일하게 적용 가능.

**신호 4 오탐 disambiguate 25연속 확정** (298→326) — 정상 워크플로의 일부로 완전히 정착. **311차 fallback 패턴 후 정상 publish 11차 연속 안정 유지** — fallback은 진짜 일회성이 아니라 안정 운영 상태의 일부. **단일 패스 패턴 17연속 정형화** (305→326). **함정 회피 6중 동시 확인**: 함정 6 (heredoc + env -i SyntaxError) + 함정 7 (--category int만) + 함정 8 (by_category["1219746"]=1 영구 잔존 26연속) + 함정 11 (execute_code cron 차단 회피) + 함정 14 (import os 누락 없음) + 함정 15 (5-5 proxy check 격리 패턴 적용) 모두 326차 워크플로에서 자동 회피 성공. **함정 17 (parts.append()) 정형 임계점 무관** — 2778자 = 단일 f-string OK (317차 정형 임계 그대로 적용). **325차 연속 all-green 99 → 326차 100회차 마일스톤 부근**.

326차 daily_counts={AI/ML:1, 개발도구:1} (총 2건). 연속 all-green **100회차 마일스톤 임박** (다음 차부터 326차 포함 카운트).
