# 235차 (2026-07-10) — Bun→Rust / 234차 누락분 복구 + 두 state 파일 drift 가드

> 세션 요약 + 본 세션에서 실전 검증된 클래스-레벨 패턴만 기록. 일회성 변수는 본문에서 제외.

## 1. 배경 / 트리거

- 크론 잡 `b1bca63a117a 📝 Tistory 자동 발행 (SEO+트렌드)` 발화 (235차)
- §3.8.1 세션 만료 가드 통과 (HTTP 200, application/json)
- 트렌드 12개 refresh 완료, fresh 후보 score ≥5.0:
  - **AI/ML**: 31256 Grok 4.5 (234차 #951 발행, state 누락)
  - **개발도구**: 31264 ts6to7, 31253 Chatto
  - **개발팁**: **31263 Bun→Rust (score 7.0, 1순위)**, 31252 Uniqlo

## 2. 핵심 발견 — 클래스 레벨

### §A. 두 state 파일 drift 함정 (가장 중요한 신규 발견)

`tistory_publisher.py`는 **두 개의 state 파일**을 동시에 관리한다:
- `~/.hermes/memory/published_topics.json` (pt) — **`post-publish-correct.sh`의 4단계가 쓰는 파일**
- `~/.hermes/memory/blog_pipeline_state.json` (state) — **§3.5 3중 신호 검증이 읽는 파일**

`post-publish-correct.sh`는 `pt['last']` + `pt['details']` 갱신까지만 수행하고, **`state['last']` / `state['details']` / `state['last_post']` / `state['last_topics']` / `state['stats']`는 자동으로 동기화하지 않는다**.

→ 234차에서 #951 Grok 4.5가 Tistory엔 발행됐는데 `state.json`엔 누락된 이유가 이것. RSS에서만 951이 보이고, 235차 시작 시점에 §3.5 3중 신호로 확인 시 state만 950에서 멈춰 있었음.

**→ §3.11 5단계 보정 v2 — `post-publish-correct.sh` 다음 줄에 6단계 state 동기화 heredoc이 매 세션 필수**:

```bash
# 6단계: blog_pipeline_state.json 동기화 (post-publish-correct.sh가 안 함)
python3 << 'PYEOF'
import json
path = '/Users/mac/.hermes/memory/blog_pipeline_state.json'
with open(path) as f:
    s = json.load(f)
# published_topics.json의 last entry를 그대로 state에 반영
new_entry = {
    'topic_id': 952,  # 실제 발행된 post id
    'title': '...',
    'url': 'https://sigco.tistory.com/952',
    'date': '2026-07-10',
    'category': '개발팁',
    'category_id': 1219747,
    'gn_topic_id': 31263,
    'source_url': 'https://news.hada.io/topic?id=31263',
}
s['details'].append(new_entry)
s['last'] = {'id': 952, 'url': new_entry['url'], 'title': new_entry['title'], 'date': new_entry['date'], 'category': '개발팁', 'category_id': 1219747, 'gn_topic_id': 31263, 'gn_url': new_entry['source_url']}
# stats 보정 (drift 가드 준수 — 절대 tistory_max로 박지 말 것)
det_url_count = len([x for x in s['details'] if x.get('url', '').strip()])
s['stats']['total_published'] = det_url_count
s['stats']['by_category']['개발팁'] = s['stats']['by_category'].get('개발팁', 0) + 1
with open(path, 'w', encoding='utf-8') as f:
    json.dump(s, f, ensure_ascii=False, indent=2)
PYEOF
```

### §B. RSS가 "실제 발행된 max post id"의 진실 공급원

`https://sigco.tistory.com/manage/posts.json?category=...`는 HTTP 200을 주지만 **`posts: []` (빈 배열)**만 반환한다. 이 API로는 max post id를 알 수 없다.

→ **RSS 피드** `https://sigco.tistory.com/rss`가 유일하게 신뢰할 수 있는 truth source. `<link>https://sigco.tistory.com/N</link>` 패턴에서 N을 파싱하면 max id가 정확.

```bash
# 234차 누락분 복구 시 RSS 검증
curl -sL "https://sigco.tistory.com/rss" | grep -oE "sigco.tistory.com/[0-9]+" | sort -u
# → 942, 943, ..., 950, 951 (state는 950, 실제 마지막은 951)
```

→ 235차 신규 발행 후에도 #952가 RSS에 박혔는지 같은 방법으로 1차 검증.

### §C. `--file` 모드 frontmatter 함정

`tistory_publisher.py --file /tmp/draft.md`는 내부 `read_markdown_file()`이 **첫 줄이 `# Title` (H1)** 이어야 정상 동작. `--title`을 명시해도 무관.

draft.md가 frontmatter (`---\ntitle: ...\n...---\n`)로 시작하면 → 82자만 추출 → 300자 미만 검증 실패 → 발행 안 됨.

**해결**: frontmatter 제거한 body-only 파일을 별도로 만들고 그걸 `--file`에 넘긴다.

```bash
python3 -c "
with open('/tmp/draft.md') as f: t = f.read()
body = t.split('---', 2)[2].strip() if t.startswith('---') else t
with open('/tmp/draft_body.md', 'w', encoding='utf-8') as f: f.write(body)
"
# 그 다음 tistory_publisher.py --file /tmp/draft_body.md ...
```

→ **235차 영구화**: frontmatter는 `tistory_publisher.py`의 `--file`과 호환되지 않음. draft 작성 시 본문만 있는 body 파일을 만들거나, 위 1줄로 strip.

### §D. `post-publish-correct.sh` 6-arg 시그니처 (cron 프롬프트 예시 거짓 검증)

크론 프롬프트의 예시는:
```bash
bash post-publish-correct.sh "TOPIC" "URL" GN_NUM CATEGORY  # 4개
```

**실제 시그니처는 6개**:
```bash
bash post-publish-correct.sh \
  "TOPIC" \
  "TITLE" \
  "URL" \
  "SRC_URL" \
  "CATEGORY" \
  "GN_TOPIC_ID"
```

`TOPIC`과 `TITLE`이 별개. `TITLE`을 빼먹으면 shell 변수가 한 칸씩 밀려 `URL` 자리에 TOPIC이 들어가서 4단계가 잘못된 값으로 박힘.

→ **235차 영구화**: 크론 프롬프트의 post-publish-correct.sh 예시 4개 인자 호출은 **버그**. 반드시 6개 인자로 호출. SKILL.md 본문 헤더 표현도 정정 필요.

## 3. 실전 5+1단계 보정 recipe (235차 검증)

1. (1단계) `tistory_publisher.py --file /tmp/draft_body.md` 발행 → `#952` 응답
2. (2단계) `post-publish-correct.sh TOPIC TITLE URL SRC_URL CAT GN` 6인자 호출 → `pt` 파일 5단계 박기
3. (3단계, **신규 6단계**) `state.json` 동기화 heredoc → §3.5 3중 신호 검증 통과
4. (4단계) RSS feed 1줄 grep으로 `sigco.tistory.com/952` 박힘 확인

## 4. 환경 / 메트릭

- 세션 가드: ✅ OK (HTTP 200)
- 235차 발행: #952 Bun→Rust (개발팁, CJK 1,848자, Picsum 2장, source footer 20번째 검증)
- 234차 복구: #951 Grok 4.5 (state 누락분 보정, gn_topic_id 31256 박기)
- OG 썸네일: Kakao CDN 자동 설정
- cleanup cron 영향 없음 (이번 세션은 발행 1건 + 복구 1건)

## 5. 한 줄 결론

- **두 state 파일 drift가 §3.5 3중 신호 함정**의 root cause. `post-publish-correct.sh`는 `published_topics.json`만 동기화, `blog_pipeline_state.json`은 6단계 heredoc 수동 동기화 필수.
- **`manage/posts.json`은 빈 배열**, RSS가 truth source.
- **`--file`은 frontmatter 비호환**, body-only 파일 별도 생성.
- **`post-publish-correct.sh` 6-arg 시그니처**, 크론 프롬프트의 4-arg 예시는 버그.
- 236차부터 적용: SKILL.md 본문 헤더 §3.11 5단계 → **5+1단계 (state sync heredoc)** 격상, §3.34.29 ~ §3.34.30에 §A/B/C/D 클래스-레벨 함정 4종 영구화.
