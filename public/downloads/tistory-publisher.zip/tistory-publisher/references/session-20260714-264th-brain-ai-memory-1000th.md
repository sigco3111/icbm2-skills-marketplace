# 264차 세션 — `#1000` 마일스톤 + §3.34.47 영구화 실전 검증

**날짜**: 2026-07-14
**결과**: **`#1000` 정상 발행** — Brain-AI Memory (gn=31435, AI/ML/1219746, 13점)
**연속 all-green**: **51회차** (213~264차)
**cleanup cron 임무 #16 dry-run**: 49→**50회** 연속 all-green

## 세션 마일스톤

- **`#1000` 1000번째 글 발행** — `sigco.tistory.com/1000`. 본문 3573자, 이미지 2장, 라이브 페이지 GET `status=200, size=61832` 확인.
- **연속 all-green 50회 (213~263차) → 51회 (213~264차)** 돌파.
- **TOP 12 후보 FRESH 9개 모두 AI/ML** — §3.34 #21 AI/ML 우선 정책 단독 적용, §3.34.45 '기타' 제외 정책은 무효 (FRESH에 '기타' 없음).
- **본문 빌드 스크립트 (write_file + 격리 호출)** 실전 검증 — inline heredoc 회피 패턴 (§3.34.47 영구화) 정상 동작.

## 워크플로

1. **§3.8.1 가드**: `env -i HOME=... PATH=... PWD=... bash -c 'set -a; source tistory.env; set +a; python3'` 격리 호출 → `status=200, ct=application/json;charset=UTF-8, cookie_count=8` 통과.
2. **트렌드 refresh + 후보 점수**: `blog_pipeline.py --refresh-topics --dry-run` → TOP 12: `31404, 31435, 31432, 31397, 31431, 31411, 31406, 31424, 31408, 31434, 31417, 31407`.
3. **§3.34.40 FRESH 4-field 매칭**: 3개 (31404/31397/31411) 이미 263차 PUB → FRESH 9개 모두 AI/ML (`31435, 31432, 31431, 31406, 31424, 31408, 31434, 31417, 31407`).
4. **§3.34.39 후보 직접 점수 pick**: FRESH 1순위 13점 `31435` 픽 (AI/ML).
5. **§3.34.46 본문 fetch**: `_try_md_endpoint(31435)` 직접 호출 → status=200, 1907 bytes.
6. **§3.34.47 본문 빌드 (write_file + 격리 호출)**: `write_file`로 `/tmp/tistory_drafts_264th/build_draft.py` (UTF-8 선언 포함) 저장 → `python3 <script>.py` 격리 호출. inline heredoc 회피 정상.
7. **§3.34.46 md_to_html 변환**: 262차 정착판 (들여쓰기 nested ul 회피 + `- ##` 위장 header 라우팅) 정상 동작.
8. **editorial 인트로/결론 추가**: 260차 정착 패턴 그대로.
9. **strip-frontmatter.py 선처리**: `draft-31435-brain-ai-memory.md` → `draft-31435-brain-ai-memory.body.md` (3573자).
10. **publish**: `tistory_publisher.py --file --category 1219746 --source-url --gn-topic-id 31435 --image-query "ai agent memory brain architecture diagram neural"` → `https://sigco.tistory.com/1000`.
11. **§3.11 post_publish_sync**: `sync --url --title --gn-topic-id --category --category-id --source-url` → `pt_updated: true / state_updated: true / errors: [] / triple_signal_match: true`.
12. **§3.5 5중 신호 검증**: 5/5 `#1000` 일치 (`all_match: True`).
13. **stats 확인**: `daily_counts[2026-07-14] = {'AI/ML': 8}` (7→8, +1 정확, cat_id 누설 0).
14. **cleanup cron 임무 #16 dry-run**: `✅ 누설 없음` 50회 연속 all-green.
15. **라이브 페이지 직접 GET**: `status=200, size=61832, title='Brain-AI Memory &mdash; ...'` 확인.

## §3.34.47 영구화 실전 검증

264차 빌드 스크립트는 §3.34.47 함정 회피 패턴 그대로 따름:

1. `mkdir -p /tmp/tistory_drafts_264th` 디렉토리 생성.
2. `write_file`로 `/tmp/tistory_drafts_264th/build_draft.py` 저장 — 첫 줄에 `# -*- coding: utf-8 -*-` 선언, f-string 안 백슬래시 quote 없음 (모두 `split(" ", 1)[1]` 같은 plain split, escape 없음), md_to_html 함수 본문은 plain string concatenation.
3. `env -i HOME=/Users/mac PATH=/usr/bin:/bin PWD=/Users/mac /bin/bash -c 'set -a; source tistory.env; set +a; /usr/bin/python3 /tmp/tistory_drafts_264th/build_draft.py'` 격리 호출.
4. 빌드 결과 `DRAFT_OK`, body_chars=2088, total_chars=2178 (frontmatter strip 후 3573자).

§3.34.41 f-string 제약 + §3.34.47 UTF-8 한글 + 30줄+ inline heredoc 함정 — 모두 회피. 263차 식별 → 264차 첫 실전 검증 성공.

## 후보 매트릭스 (264차)

| 후보 | 점수 | 카테고리 | 상태 | 비고 |
|------|------|----------|------|------|
| 31404 | 16 | AI/ML | PUB (262차) | |
| 31435 | 13 | AI/ML | **PUB (264차)** | **#1000** |
| 31432 | ? | AI/ML | FRESH | 265차+ 후보 |
| 31397 | 10 | AI/ML | PUB (259차) | |
| 31431 | ? | AI/ML | FRESH | 265차+ 후보 |
| 31411 | 9 | AI/ML | PUB (263차) | #999 |
| 31406 | ? | AI/ML | FRESH | 265차+ 후보 |
| 31424 | ? | AI/ML | FRESH | 265차+ 후보 |
| 31408 | ? | AI/ML | FRESH | 265차+ 후보 |
| 31434 | ? | AI/ML | FRESH | 265차+ 후보 |
| 31417 | ? | AI/ML | FRESH | 265차+ 후보 |
| 31407 | ? | AI/ML | FRESH | 265차+ 후보 |

## drift 관찰

- **사전 검증**: 5중 신호 모두 `#999` (263차 마지막) — 직전 cron 차 마지막 정상. 자정 사이 추가 발행 없음.
- **사후 검증**: 5중 신호 모두 `#1000` — 정상 진행.
- **state.details 76→77 (+1)**, **pt.details 92→93 (+1)** — 1건 박힘.
- **daily_counts[2026-07-14]['AI/ML'] = 7→8 (+1)** — 정확.

## 신규 발견

**없음**. §3.34.46 영구화 + §3.34.47 영구화 + §3.34.43 PWD 보강 + §3.11 sync + §3.5 5중 검증 + §3.34 #21 AI/ML 우선 정책 + §3.34.40 FRESH 4-field + §3.34.39 후보 직접 점수 pick — 모든 패턴이 정착된 playbook 그대로 정상 동작.

## cleanup cron 임무 상태 (264차)

- **#16 (cat_id 누설 cleanup)**: ✅ 50회 연속 all-green (213~264차).
- **#23 (gn-fetch-content URL 영구화)**: ✅ 완료 (261차).
- **#17 (post_publish_sync 영구화)**: ✅ 완료 (241차).
- **#18 (f-string §3.8.1 SyntaxError)**: 코드 패치 미완료, SKILL.md 가이드로 운영 중.
- **#19 (격리 패턴 PWD/cd)**: ✅ 영구화 (247차).
- **#20 (cron 차 사이 last URL drift)**: ✅ 확인 (254차).
- **#21 (AI/ML 우선)**: ✅ 확인 (255차).
- **#22 (기타 제외 + AI/ML 우선 우선순위)**: ✅ 확인 (256차).
- **#24 (inline heredoc UTF-8 한글 + f-string 제약)**: ✅ 영구화 가이드 (263차 식별) + 264차 실전 검증.

## 차감/추가

차감/추가 없음. 모든 기존 패턴 정상 동작.
