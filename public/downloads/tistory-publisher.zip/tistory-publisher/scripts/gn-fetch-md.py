#!/usr/bin/env python3
"""
gn-fetch-md.py — 긱뉴스 토픽을 .md endpoint로 직접 fetch (259차 식별, §3.34.46)

**왜 필요한가**:
  - `scripts/gn-fetch-content.py` 의 `GN_MD_URL` 상수가 `topic.md?id={tid}` 라 dead path.
  - 실제 작동하는 URL은 `/topic/{tid}.md` — 259차에 200 OK + 1251 bytes 정상 응답 확인.
  - 1단계 `.md` fallback 이 정상 동작하면 HTML 파싱 fallback의 비표준 마크업 함정과
    RSS summary fallback의 짧은 길이 함정을 모두 우회 가능.

**사용법**:
  python3 gn-fetch-md.py <topic_id>
  → status, size, markdown 텍스트 (frontmatter 포함) 출력

**영구화 권장 (#23 cleanup cron 임무)**:
  `gn-fetch-content.py` 의 `GN_MD_URL` 을
  `f"{GN_TOPIC_BASE}/{tid}.md"` 로 정정하면 본 스크립트 없이도 step 1에서 즉시 성공.
  그때까지 본 스크립트는 step 1~3 우회용으로 사용.

**격리 패턴 (§3.8.2)**:
  env -i HOME=/Users/mac PATH=/usr/bin:/bin PWD=/Users/mac /usr/bin/python3 - \\
    ~/.hermes/skills/automation/tistory-publisher/scripts/gn-fetch-md.py <topic_id>
"""
import sys
import urllib.request
import urllib.error

GN_TOPIC_BASE = "https://news.hada.io/topic"
USER_AGENT = "Mozilla/5.0"


def fetch_md(topic_id: int, timeout: int = 15):
    url = f"{GN_TOPIC_BASE}/{topic_id}.md"
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, len(r.read().decode("utf-8")), r.read().decode("utf-8")
    except (urllib.error.HTTPError, urllib.error.URLError, TimeoutError) as e:
        return None, 0, str(e)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 gn-fetch-md.py <topic_id>")
        sys.exit(1)
    tid = int(sys.argv[1])
    status, size, body = fetch_md(tid)
    print(f"status: {status}  size: {size}")
    if status == 200 and size > 100:
        print("--- markdown (frontmatter 포함) ---")
        print(body)
    else:
        print(f"FAIL: {body}")
        sys.exit(1)