#!/bin/bash
# verify-tistory-cookie.sh
# Tistory 쿠키 갱신 후 ad-hoc 검증 (184차 신규)
#
# 검증 항목:
#   1) ~/.hermes/secrets/tistory.env 파일 존재 + 5개 키 모두 존재
#   2) 백업 파일 보존
#   3) 환경변수 로드 후 5개 값 비어있지 않음
#   4) 스크립트가 요구하는 정확한 키 이름 매칭
#   5) tistory_publisher.py --check-session → 세션 유효
#   6) JSON 파싱 에러 ('Expecting value') 없음
#   7) --categories 호출로 추가 동작 검증
#
# 사용법:
#   bash verify-tistory-cookie.sh
#
# 디자인 노트:
#   - requests가 도메인 매칭으로 5개 쿠키만 골라 보내는 특성 활용
#   - curl 시뮬레이션은 prefix 때문에 false positive → 사용 안 함
#   - 스크립트 자체 결과만 신뢰 (curl 우회)

set -u

PASS=0
FAIL=0
WARN=0
report() {
    if [ "$1" = "PASS" ]; then
        echo "  ✅ PASS: $2"
        PASS=$((PASS + 1))
    elif [ "$1" = "FAIL" ]; then
        echo "  ❌ FAIL: $2"
        FAIL=$((FAIL + 1))
    else
        echo "  ⚠️  WARN: $2"
        WARN=$((WARN + 1))
    fi
}

echo "================================================"
echo "  Tistory 쿠키 검증 (184차 ad-hoc 패턴)"
echo "================================================"
echo ""

# [1] env 파일 무결성
echo "[1] ~/.hermes/secrets/tistory.env 무결성"
ENV_FILE="$HOME/.hermes/secrets/tistory.env"
if [ -f "$ENV_FILE" ]; then
    SIZE=$(wc -c < "$ENV_FILE" | tr -d ' ')
    report PASS "env 파일 존재: ${SIZE}B"
else
    report FAIL "env 파일 없음"
fi

REQUIRED_KEYS="TISTORY_REACTION_GUEST TISTORY___T_ TISTORY___T_SECURE TISTORY_TSSESSION TISTORY__T_ANO"
for key in $REQUIRED_KEYS; do
    if grep -q "^${key}=" "$ENV_FILE" 2>/dev/null; then
        report PASS "키 ${key} 존재"
    else
        report FAIL "키 ${key} 누락"
    fi
done

# [2] 백업
echo ""
echo "[2] 백업 파일 보존"
BAK_COUNT=$(ls -1 "$HOME/.hermes/secrets/tistory.env.bak."* 2>/dev/null | wc -l | tr -d ' ')
if [ "$BAK_COUNT" -ge 1 ]; then
    LATEST_BAK=$(ls -1t "$HOME/.hermes/secrets/tistory.env.bak."* 2>/dev/null | head -1)
    report PASS "백업 ${BAK_COUNT}개 (최신: $(basename "$LATEST_BAK"))"
else
    report FAIL "백업 파일 없음"
fi

# [3] 환경변수 로드
echo ""
echo "[3] 환경변수 로드 + 값 검증"
LOAD_OUTPUT=$(bash -c '
set -u
source "$HOME/.hermes/secrets/tistory.env"
echo "REACTION_GUEST=${TISTORY_REACTION_GUEST:-<MISSING>}"
echo "__T_=${TISTORY___T_:-<MISSING>}"
echo "__T_SECURE=${TISTORY___T_SECURE:-<MISSING>}"
echo "TSSESSION_LEN=${#TISTORY_TSSESSION}"
echo "_T_ANO_LEN=${#TISTORY__T_ANO}"
' 2>&1)

EXPECTED_LINES=(
    "REACTION_GUEST=1"
    "__T_=1"
    "__T_SECURE=1"
    "TSSESSION_LEN=40"
    "_T_ANO_LEN=344"
)
for expected in "${EXPECTED_LINES[@]}"; do
    if echo "$LOAD_OUTPUT" | grep -qF "$expected"; then
        report PASS "로드 OK: $expected"
    else
        report FAIL "로드 실패: $expected (실제: $(echo "$LOAD_OUTPUT" | grep -F "${expected%%=*}"))"
    fi
done

# [4] 스크립트 키 매칭
echo ""
echo "[4] 스크립트 요구 키와 일치"
SCRIPT_FILE="$HOME/.hermes/scripts/tistory_publisher.py"
if grep -q 'COOKIE_NAMES = \["REACTION_GUEST", "__T_", "__T_SECURE", "TSSESSION", "_T_ANO"\]' "$SCRIPT_FILE"; then
    report PASS "스크립트 COOKIE_NAMES 일치"
else
    report FAIL "스크립트 COOKIE_NAMES 매칭 실패"
fi

# [5] 세션 체크 (스크립트 자체 = 신뢰 가능)
echo ""
echo "[5] tistory_publisher.py --check-session"
SESSION_OUTPUT=$(python3 "$HOME/.hermes/scripts/tistory_publisher.py" --check-session 2>&1 | grep -v "NotOpenSSLWarning\|warnings.warn")

if echo "$SESSION_OUTPUT" | grep -q "세션 유효"; then
    POST_COUNT=$(echo "$SESSION_OUTPUT" | grep -oE "[0-9]+개 글" | grep -oE "[0-9]+")
    if [ -n "$POST_COUNT" ]; then
        report PASS "세션 유효 (총 ${POST_COUNT}개 글)"
    else
        report PASS "세션 유효 (글 수 미표시)"
    fi
else
    report FAIL "세션 체크 실패: $SESSION_OUTPUT"
fi

# [6] JSON 파싱 에러 회귀 방지
echo ""
echo "[6] 'Expecting value' 에러 회귀 방지"
if echo "$SESSION_OUTPUT" | grep -q "Expecting value"; then
    report FAIL "JSON 파싱 에러 회귀"
else
    report PASS "JSON 파싱 에러 없음"
fi

# [7] --categories 추가 검증
echo ""
echo "[7] --categories 호출 (추가 동작 검증)"
CAT_OUTPUT=$(python3 "$HOME/.hermes/scripts/tistory_publisher.py" --categories 2>&1 | grep -v "NotOpenSSLWarning\|warnings.warn")
if echo "$CAT_OUTPUT" | grep -qE "\[[0-9]+\]"; then
    CAT_COUNT=$(echo "$CAT_OUTPUT" | grep -cE "\[[0-9]+\]")
    report PASS "카테고리 ${CAT_COUNT}개 로드 성공"
else
    report WARN "카테고리 로드 결과 비어있음"
fi

echo ""
echo "================================================"
echo "  RESULT: PASS=${PASS}  FAIL=${FAIL}  WARN=${WARN}"
echo "================================================"

if [ "$FAIL" -eq 0 ]; then
    echo "✅ ad-hoc verification: CLEAN"
    exit 0
else
    echo "❌ ad-hoc verification: FAILED"
    exit 1
fi