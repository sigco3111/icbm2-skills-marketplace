#!/usr/bin/env python3
"""§3.5 3중 신호 검증 — state.json drift 감지.

Usage:
    check_state_consistency.py
    check_state_consistency.py --state /path/to/state.json
    check_state_consistency.py --quiet   # drift 없으면 출력 없음

Exit codes:
    0 = drift 없음 (3중 신호 일치)
    1 = drift 감지 (가짜 발행 의심)
    2 = state 파일 부재
    3 = 파싱 실패

검증 항목:
    1. last_published_url == last_topics[-1].url (둘 다 있을 때)
    2. daily_counts[오늘] 카테고리 합계 ≥ 1 (오늘 발행이 있었다면)
    3. last_published_url 슬롯 번호가 양수 정수
"""
import argparse
import json
import sys
from datetime import date
from pathlib import Path
from typing import Optional

# /usr/bin/python3 (3.9) 호환 — PEP 604 union 런타임 평가 회피
# (289차 발견: type hint만 평가되므로 Optional[str] 변환으로 해결)

DEFAULT_STATE = Path.home() / ".hermes" / "memory" / "blog_pipeline_state.json"


def extract_slot(url: Optional[str]) -> Optional[int]:
    """sigco.tistory.com/NNN → NNN"""
    if not url:
        return None
    try:
        return int(url.rstrip("/").split("/")[-1])
    except (ValueError, IndexError):
        return None


def main() -> int:
    ap = argparse.ArgumentParser(description="§3.5 3중 신호 검증")
    ap.add_argument("--state", type=Path, default=DEFAULT_STATE,
                    help=f"state.json 경로 (default: {DEFAULT_STATE})")
    ap.add_argument("--today", default=None, help="YYYY-MM-DD (default: today)")
    ap.add_argument("--quiet", action="store_true", help="drift 없으면 출력 없음")
    args = ap.parse_args()

    if not args.state.exists():
        print(f"❌ FAIL: state 파일 없음 ({args.state})", file=sys.stderr)
        return 2

    try:
        s = json.loads(args.state.read_text(encoding="utf-8"))
    except Exception as e:
        print(f"❌ FAIL: state 파싱 실패 ({type(e).__name__}: {e})", file=sys.stderr)
        return 3

    today = args.today or date.today().isoformat()
    daily_counts = s.get("daily_counts", {}).get(today, {})
    last_url = s.get("last_published_url")
    last_slot = extract_slot(last_url)
    last_topics = s.get("last_topics", [])
    last_topic_url = last_topics[-1].get("url") if last_topics else None
    last_topic_slot = extract_slot(last_topic_url)
    today_total = sum(daily_counts.values()) if isinstance(daily_counts, dict) else 0
    details = s.get("details", [])
    last_detail_url = details[-1].get("url") if details else None
    last_detail_slot = extract_slot(last_detail_url)

    ok = True
    drifts = []

    # 신호 1: last_published_url == last_topics[-1].url
    if last_url and last_topic_url and last_url != last_topic_url:
        drifts.append(f"last_published_url({last_url}) ≠ last_topics[-1].url({last_topic_url})")
        ok = False

    # 신호 2: daily_counts 오늘 합계 ≥ 1 (오늘 발행이 있었다면)
    if last_topic_url and today_total == 0:
        # last_topics가 오늘 것일 때만 체크
        # timestamp 파싱은 보수적으로 생략, 합계 0이면 의심
        drifts.append(f"last_url={last_url} 인데 daily_counts[{today}]={daily_counts} (합계 0)")
        ok = False

    # 신호 3: 슬롯 번호 양수 정수
    if last_slot is not None and last_slot <= 0:
        drifts.append(f"비정상 슬롯: last_published_url={last_url}")
        ok = False

    # 신호 4 (289차 신규): daily_counts[오늘] ≥ 2 인데 details[-1] 슬롯이 변동 없음 = 가짜 발행 누적
    # (stats는 박혔으나 실제 Tistory 글이 발행되지 않은 상태 — publish 단계 추가 진행 시 오염 가중)
    if (
        today_total >= 2
        and last_detail_slot is not None
        and last_slot is not None
        and last_detail_slot == last_slot
    ):
        drifts.append(
            f"가짜 발행 의심 (FAKE_PUBLISH): daily_counts[{today}] 합계={today_total} "
            f"지만 details[-1]=#{last_detail_slot} (last_published_url 변동 없음) — "
            f"실제 Tistory 신규 글 0건"
        )
        ok = False

    if not args.quiet or not ok:
        print(f"today={today} daily_counts={daily_counts} (total={today_total})")
        print(f"last_published_url={last_url}")
        print(f"last_topics[-1]={last_topics[-1] if last_topics else None}")

    if ok:
        if not args.quiet:
            print("✅ OK: 3중 신호 일치")
        return 0
    else:
        print("⚠️ DRIFT 감지:")
        for d in drifts:
            print(f"  - {d}")
        print("⚠️ FAIL: §3.5 drift (가짜 발행 의심 — §3.11/§4 보정 검토)")
        return 1


if __name__ == "__main__":
    sys.exit(main())