#!/usr/bin/env python3
"""gn-markdown-to-tistory-html.py — GeekNews 마크다운을 Tistory HTML로 변환 (262차 정착판)

§3.34.46 의 md_to_html 함수. 260차 정착 4종 패턴 + 262차 보완 2종 함정 회피:
1. 들여쓬 sub-list nested ul 함정 (indent 무시, 모든 `- ` 를 top-level bullet)
2. `- ## 헤더` 위장 항목 함정 (`- ` 변환 직전 header 라우팅)

사용법:
  python3 gn-markdown-to-tistory-html.py <topic_id> [--out path] [--with-intro] [--with-conclusion]

또는 모듈로:
  from gn_markdown_to_tistory_html import md_to_html, build_full_html, fetch_and_convert
  html = build_full_html(gn_topic_id=31404, source_url="https://news.hada.io/topic?id=31404")

importlib 사용시:
  import importlib.util
  spec = importlib.util.spec_from_file_location("gmt", "/Users/mac/.hermes/skills/automation/tistory-publisher/scripts/gn-markdown-to-tistory-html.py")
  gmt = importlib.util.module_from_spec(spec)
  spec.loader.exec_module(gmt)
  html = gmt.build_full_html(31404, "https://news.hada.io/topic?id=31404")
"""
import sys, os, re, html, argparse, importlib.util

# ---- gn-fetch-content 모듈 로드 (262차 영구화된 §3.34.46)
GN_FETCH_PATH = os.path.join(os.path.dirname(__file__), "gn-fetch-content.py")


def _load_gfc():
    """gn-fetch-content 모듈을 importlib 로 로드."""
    spec = importlib.util.spec_from_file_location("gfc", GN_FETCH_PATH)
    gfc = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(gfc)
    return gfc


def normalize_md(text):
    """260차 정착: Comments / Metadata / Topic Body / 첫 # 제목 제거."""
    m = re.search(r"\n## Comments", text)
    if m:
        text = text[:m.start()]
    m_meta = re.search(r"\n## Metadata", text)
    if m_meta:
        after_meta = text[m_meta.end():]
        lines = after_meta.split("\n")
        body_lines = []
        in_meta = True
        for line in lines:
            if in_meta and (line.startswith("- ") or line.strip() == "" or line.startswith("  ")):
                continue
            in_meta = False
            body_lines.append(line)
        text = "\n".join(body_lines).strip()
    text = re.sub(r"^## Topic Body\s*\n+", "", text)
    lines = text.split("\n", 1)
    if lines[0].startswith("# "):
        text = lines[1] if len(lines) > 1 else ""
    return text.strip()


def md_to_html(md):
    """GeekNews 마크다운 → Tistory HTML 변환 (262차 정착판).

    4종 패턴 + 2종 함정 회피:
    - ## 헤더 / ### 헤더 / - 항목 / **bold** (4종)
    - 들여쓰기 무시 (모든 `- ` 를 top-level bullet)
    - `- ## ` 위장 항목 헤더 라우팅
    - `---` → `<hr>`, 빈 줄은 skip
    - `[text](url)` → `<a href="url">text</a>` (보너스)
    """
    out = []
    in_ul = False
    for line in md.split("\n"):
        stripped = line.lstrip()
        if stripped.startswith("- "):
            item_text = stripped[2:].strip()
            # 함정 2: `- ## 헤더` 위장 항목 → 헤더로 라우팅
            if item_text.startswith("## ") or item_text.startswith("### "):
                if in_ul:
                    out.append("</ul>")
                    in_ul = False
                if item_text.startswith("## "):
                    tag = "h2"
                    content = item_text[3:].strip()
                else:
                    tag = "h3"
                    content = item_text[4:].strip()
                out.append("<" + tag + ">" + html.escape(content) + "</" + tag + ">")
                continue
            if not in_ul:
                out.append("<ul>")
                in_ul = True
            item_esc = html.escape(item_text)
            item_esc = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", item_esc)
            item_esc = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r'<a href="\2">\1</a>', item_esc)
            out.append("<li>" + item_esc + "</li>")
        elif line.startswith("### "):
            if in_ul:
                out.append("</ul>")
                in_ul = False
            out.append("<h3>" + html.escape(line[4:].strip()) + "</h3>")
        elif line.startswith("## "):
            if in_ul:
                out.append("</ul>")
                in_ul = False
            out.append("<h2>" + html.escape(line[3:].strip()) + "</h2>")
        elif stripped.startswith("# "):
            if in_ul:
                out.append("</ul>")
                in_ul = False
            out.append("<h2>" + html.escape(stripped[2:].strip()) + "</h2>")
        elif stripped == "":
            if in_ul:
                out.append("</ul>")
                in_ul = False
            # 빈 줄은 그냥 skip (extra paragraph 없음)
        elif stripped == "---":
            if in_ul:
                out.append("</ul>")
                in_ul = False
            out.append("<hr>")
        else:
            if in_ul:
                out.append("</ul>")
                in_ul = False
            p_html = html.escape(line)
            p_html = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", p_html)
            p_html = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r'<a href="\2">\1</a>', p_html)
            out.append("<p>" + p_html + "</p>")
    if in_ul:
        out.append("</ul>")
    return "\n".join(out)


def make_intro(gn_topic_id, source_url, lead="이 글은 GeekNews에 공유된"):
    """editorial 인트로 (260차 정착 — 한국어 1~2 단락 placeholder)."""
    return (
        '<p><a href="' + source_url + '">GeekNews #' + str(gn_topic_id) + '</a>에서 다룬 사례는 '
        + lead
        + " 흥미로운 단서들을 남긴다. 본문에서는 핵심 내용을 정리하고 한국 독자 입장에서의 시사점을 덧붙인다.</p>"
        "<p>아래는 GeekNews 원문의 본문을 한국어로 옮긴 것이다.</p>"
    )


def make_conclusion(gn_topic_id, source_url, custom_blurb=None):
    """editorial 결론 (260차 정착 — 한국 시장 시사점 1~2 단락 placeholder)."""
    blurb = custom_blurb or "이 사례는 한국 시장에서도 참고할 만한 시사점을 남긴다."
    return (
        "<h2>한국 시장에서의 시사점</h2>"
        "<p>" + blurb + "</p>"
        '<p style="color:#666;font-size:0.9em;">원문: <a href="'
        + source_url
        + '">GeekNews #'
        + str(gn_topic_id)
        + "</a></p>"
    )


def build_full_html(gn_topic_id, source_url, lead=None, custom_blurb=None, custom_intro=None, custom_conclusion=None):
    """gn-fetch-content → normalize → md_to_html → intro + body + conclusion 원샬 변환."""
    gfc = _load_gfc()
    raw = gfc._try_md_endpoint(gn_topic_id)
    if not raw:
        raise RuntimeError("gn-fetch-content._try_md_endpoint returned None for " + str(gn_topic_id))
    md = normalize_md(raw)
    body_html = md_to_html(md)
    intro = custom_intro if custom_intro else make_intro(gn_topic_id, source_url, lead or "이 글은 GeekNews에 공유된")
    conclusion = custom_conclusion if custom_conclusion else make_conclusion(gn_topic_id, source_url, custom_blurb)
    return intro + "\n" + body_html + "\n" + conclusion


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("topic_id", type=int, help="GeekNews topic id")
    ap.add_argument("--source-url", default=None)
    ap.add_argument("--out", default=None, help="출력 파일 경로 (생략시 stdout)")
    ap.add_argument("--with-intro", action="store_true", help="editorial 인트로 포함")
    ap.add_argument("--with-conclusion", action="store_true", help="editorial 결론 포함")
    ap.add_argument("--lead", default=None, help="인트로 첫 문장 custom")
    ap.add_argument("--blurb", default=None, help="결론 blurb custom")
    args = ap.parse_args()

    src = args.source_url or ("https://news.hada.io/topic?id=" + str(args.topic_id))
    gfc = _load_gfc()
    raw = gfc._try_md_endpoint(args.topic_id)
    if not raw:
        sys.stderr.write("ERR: _try_md_endpoint returned None\n")
        sys.exit(1)
    md = normalize_md(raw)
    body_html = md_to_html(md)

    parts = []
    if args.with_intro:
        parts.append(make_intro(args.topic_id, src, args.lead or "이 글은 GeekNews에 공유된"))
    parts.append(body_html)
    if args.with_conclusion:
        parts.append(make_conclusion(args.topic_id, src, args.blurb))
    full = "\n".join(parts)

    if args.out:
        with open(args.out, "w") as f:
            f.write(full)
        sys.stderr.write("OK: " + args.out + " (" + str(len(full)) + " chars)\n")
    else:
        sys.stdout.write(full + "\n")


if __name__ == "__main__":
    main()