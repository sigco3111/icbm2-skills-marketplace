#!/bin/bash
# post-publish-correct.sh — §3.11 5단계 + §4 5-1 stats 보정 영구화 스크립트 (194차 신규)
# §3.34.9 영구화: details.append()에 gn_topic_id 박기 추가 (§원본출처-개선)
#
# 사용법:
#   ./post-publish-correct.sh <TOPIC> <TITLE> <URL> <SRC_URL> [CATEGORY] [GN_TOPIC_ID]
#
# 예시:
#   ./post-publish-correct.sh \
#     "클로드 코드는 스테가노그래피 표시를 함" \
#     "클로드 코드는 요청에 스테가노그래피 표시를 하고 있음 — 바이너리에 숨은 분류 마커 분석" \
#     "https://sigco.tistory.com/901" \
#     "https://news.hada.io/topic?id=30980" \
#     "AI/ML" \
#     "30980"
#
# 효과:
#   1) Tistory URL HTTP 200 + og:title 매치 확인
#   2) published_urls.txt append (source + sigco)
#   3) blog_pipeline --record 3-arg
#   4) pt['last'] + details 동시 append (last만 갱신하는 함정 회피)
#       → details에 gn_topic_id 박기 (§3.34.9 영구화)
#   5) §3.5 3중 신호 검증
#   5-1) stats today 보정 (tistory_publisher 직접 호출은 daily_counts +1 안 함)
#
# 의존성: python3, curl, jq 불필요 (python으로 inline 처리)
# 출처: SKILL.md §3.11 5단계 + §4 5단계 + 5-1 (192차/194차 확립 패턴) + §3.34.9 (218차) + §원본출처-개선

set -e

TOPIC="${1:?TOPIC 인자 필요}"
TITLE="${2:?TITLE 인자 필요}"
URL="${3:?URL 인자 필요}"
SRC_URL="${4:?SRC_URL 인자 필요}"
CATEGORY="${5:-AI/ML}"
# §원본출처-개선: 6번째 인자 = gn_topic_id (선택, 없으면 SRC_URL에서 추출)
GN_TOPIC_ID="${6:-}"

echo "=== post-publish-correct.sh 시작 ==="
echo "TOPIC: $TOPIC"
echo "URL: $URL"
echo "SRC_URL: $SRC_URL"
echo "CATEGORY: $CATEGORY"
echo

# 1) Tistory URL HTTP 200 + og:title 확인
echo "--- 1단계: HTTP 200 + og:title 확인 ---"
curl -s -o /tmp/check_post_publish.html -w "HTTP %{http_code} | %{size_download} bytes\n" "$URL"
if ! grep -q 'og:title' /tmp/check_post_publish.html; then
    echo "❌ og:title 매치 실패 — URL이 진짜 글 페이지인지 확인 필요"
    exit 1
fi
echo "✅ HTTP 200 + og:title 매치"
echo

# 2) published_urls.txt append (source + sigco)
echo "--- 2단계: published_urls.txt append ---"
echo "$SRC_URL" >> ~/.hermes/memory/published_urls.txt
echo "$URL" >> ~/.hermes/memory/published_urls.txt
echo "✅ append 완료"
echo

# 3) blog_pipeline --record 3-arg
echo "--- 3단계: blog_pipeline --record ---"
python3 ~/.hermes/scripts/blog_pipeline.py --record "$TOPIC" "$TITLE" "$URL"
echo

# 4) pt['last'] + details 동시 append
echo "--- 4단계: pt[last] + details 동시 append (gn_topic_id 박기 §3.34.9) ---"
python3 << PYEOF
import json, hashlib, re
from pathlib import Path
from datetime import datetime

p = Path.home() / '.hermes/memory/published_topics.json'
pt = json.loads(p.read_text())
now = datetime.now().strftime('%Y-%m-%dT%H:%M')
hash12 = hashlib.sha1(("$TOPIC" + "$URL").encode()).hexdigest()[:12]

# §3.34.9 영구화: gn_topic_id 박기
# 1순위: 6번째 인자 (GN_TOPIC_ID)
# 2순위: SRC_URL에서 추출 (news.hada.io/topic?id=N 패턴)
gn_topic_id_str = "$GN_TOPIC_ID"
if not gn_topic_id_str:
    m = re.search(r'news\.hada\.io/topic\?id=(\d+)', "$SRC_URL")
    if m:
        gn_topic_id_str = m.group(1)
gn_topic_id_int = int(gn_topic_id_str) if gn_topic_id_str else None

# (a) last 갱신 (188차 발견) + §원본출처-개선: last에도 gn_topic_id 박기
pt['last'] = {
    'date': now, 'topic': "$TOPIC", 'title': "$TITLE",
    'url': "$URL", 'source_url': "$SRC_URL",
}
if gn_topic_id_int is not None:
    pt['last']['gn_topic_id'] = gn_topic_id_int

# (b) details append (191차 발견 — last만 갱신하면 details[-1]이 직전 글 그대로)
detail_entry = {
    'date': now, 'topic': "$TOPIC", 'title': "$TITLE",
    'url': "$URL", 'source_url': "$SRC_URL",
    'category': "$CATEGORY", 'hash': hash12,
}
if gn_topic_id_int is not None:
    detail_entry['gn_topic_id'] = gn_topic_id_int  # §3.34.9 핵심 — details에 긱뉴스 N번 박기

pt.setdefault('details', []).append(detail_entry)
p.write_text(json.dumps(pt, ensure_ascii=False, indent=2))
print(f"✅ last + details 동시 동기화: $URL")
print(f"   gn_topic_id: {gn_topic_id_int if gn_topic_id_int else '(추출 실패 — SRC_URL 패턴 확인 필요)'}")
PYEOF
echo

# 5) §3.5 3중 신호 검증
echo "--- 5단계: 3중 신호 검증 (gn_topic_id 박기 확인 포함) ---"
python3 << PYEOF
import json
from pathlib import Path
from datetime import datetime

pt = json.loads((Path.home() / '.hermes/memory/published_topics.json').read_text())
state = json.loads((Path.home() / '.hermes/memory/blog_pipeline_state.json').read_text())
d = pt['details'][-1]
last = pt['last']
key = datetime.now().strftime('%Y-%m-%d')
print(f'(a) details[-1].url == "" ? → {d.get("url","") == ""} | 실제: {d.get("url","?")}')
print(f'(b) pt[last].url 없음? → {not last.get("url")} | 실제: {last.get("url","MISSING")}')
print(f'(c) stats today AI/ML: {state["daily_counts"].get(key, {}).get("$CATEGORY", 0)}')
print(f'(d) stats total: {state["stats"]["total_published"]}')
# §3.34.9 영구화 검증: gn_topic_id 박힘 확인
gn_id = d.get('gn_topic_id')
print(f'(e) details[-1].gn_topic_id 박힘? → {"있음 (" + str(gn_id) + ")" if gn_id else "❌ 없음 — §3.34.9 박기 누락"}')
print()
print('판정:')
if d.get("url") == "" or not last.get("url"):
    print('  ⚠️ §3.11 보정 필요 (URL 누락)')
elif d.get("url") == "$URL" and last.get("url") == "$URL":
    if gn_id:
        print('  ✅ 정상 발행 (a/b 정상 + §3.34.9 gn_topic_id 박힘)')
    else:
        print('  ⚠️ 정상 발행이나 gn_topic_id 박기 누락 — SRC_URL 패턴 확인 필요')
else:
    print(f'  ⚠️ URL 불일치: details={d.get("url")}, last={last.get("url")}')
PYEOF
echo

# 5-1) stats today 보정 (192차 신규 — tistory_publisher.py 직접 호출은 daily_counts 안 올림)
echo "--- 5-1단계: stats today 보정 ---"
python3 << PYEOF
import json
from pathlib import Path
from datetime import datetime

p = Path.home() / '.hermes/memory/blog_pipeline_state.json'
state = json.loads(p.read_text())
key = datetime.now().strftime('%Y-%m-%d')
state['daily_counts'].setdefault(key, {})
state['daily_counts'][key]['$CATEGORY'] = state['daily_counts'][key].get('$CATEGORY', 0) + 1
state['stats']['total_published'] = state['stats'].get('total_published', 0) + 1
state['stats'].setdefault('by_category', {})
state['stats']['by_category']['$CATEGORY'] = state['stats']['by_category'].get('$CATEGORY', 0) + 1
p.write_text(json.dumps(state, ensure_ascii=False, indent=2))
print(f'✅ stats 보정: $CATEGORY today = {state["daily_counts"][key]["$CATEGORY"]}, total = {state["stats"]["total_published"]}')
PYEOF
echo
echo "=== post-publish-correct.sh 완료 ==="
