#!/bin/bash
# tistory-publisher 가짜 발행 롤백 스크립트 (2026-06-26)
# 사용법: bash rollback_false_positive.sh "주제1" "주제2" ...
# 작동 전제: blog_pipeline_state.json에 last_topics 항목으로 박혀있고,
#           published_topics.json에는 없는 (가짜) 발행 주제들

set -euo pipefail

STATE="/Users/mac/.hermes/memory/blog_pipeline_state.json"
TS=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/Users/mac/.hermes/migration_fix_backup_${TS}_blog_rollback"

if [ "$#" -eq 0 ]; then
    echo "Usage: $0 '주제1' '주제2' ..."
    echo "Tip: 가짜 발행 의심 주제를 quoted string으로 전달"
    exit 1
fi

mkdir -p "$BACKUP_DIR"
cp "$STATE" "$BACKUP_DIR/blog_pipeline_state.json.bak"
echo "✅ 백업: $BACKUP_DIR/blog_pipeline_state.json.bak"

python3 <<EOF
import json
from datetime import datetime
from pathlib import Path

state_path = Path("$STATE")
with open(state_path) as f:
    state = json.load(f)

failed_topics = """$(printf '%s\n' "$@")""".strip().split('\n')

before_lt = len(state["last_topics"])
state["last_topics"] = [t for t in state["last_topics"] if t["topic"] not in failed_topics]
print(f"✅ last_topics: {before_lt} → {len(state['last_topics'])}건")

today = datetime.now().strftime("%Y-%m-%d")
# 가장 영향 큰 카테고리 자동 추정 (실패 주제들이 속한 카테고리)
# 단일 카테고리 가정 — 다중 카테고리면 직접 수정 필요
# 안전하게 AI/ML 기본값, 다른 카테고리는 수동 수정
target_cat = "AI/ML"
n_failed = len(failed_topics)

if today in state["daily_counts"] and target_cat in state["daily_counts"][today]:
    before = state["daily_counts"][today][target_cat]
    state["daily_counts"][today][target_cat] = max(0, before - n_failed)
    print(f"✅ daily_counts[{today}][{target_cat}]: {before} → {state['daily_counts'][today][target_cat]}")

before_total = state["stats"]["total_published"]
state["stats"]["total_published"] = before_total - n_failed
print(f"✅ stats.total_published: {before_total} → {state['stats']['total_published']}")

before_cat = state["stats"]["by_category"][target_cat]
state["stats"]["by_category"][target_cat] = before_cat - n_failed
print(f"✅ stats.by_category[{target_cat}]: {before_cat} → {state['stats']['by_category'][target_cat]}")

with open(state_path, "w") as f:
    json.dump(state, f, ensure_ascii=False, indent=2)
print("✅ 롤백 완료")
EOF

echo ""
echo "=== 검증: status 재확인 ==="
python3 /Users/mac/.hermes/scripts/blog_pipeline.py --status | head -20