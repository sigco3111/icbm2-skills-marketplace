#!/usr/bin/env python3
"""
React SPA / Vite / Next.js 등 클라이언트 렌더 사이트에서
JS bundle에 직렬화된 FAQ·about·features 카피를 추출한다.

사용법:
    python3 extract_spa_faq.py <URL>

예시:
    python3 extract_spa_faq.py https://landlink.sh/

동작:
    1. <URL> fetch → HTML에서 <script src="/assets/*.js"> 경로 추출
    2. JS bundle fetch (980KB~1MB)
    3. 정규식으로 question:`...` ,answer:`...` 블록 추출
    4. 추가로 title:`...` ,paragraphs:`...` 같은 직렬화 카피도 추출
    5. stdout에 Q/A 페어 + 단문 카피 출력

판별 신호:
    - curl <URL> 결과 본문이 100B 미만 + 한 줄 tagline만 잡히면 SPA 의심
    - <script src="/assets/..."> 경로가 보이면 React/Vite 빌드
    - FAQ·about 페이지가 <body>에 없고 JS bundle에 인라인 직렬화됨
"""

import re
import sys
import urllib.request
from pathlib import Path


def fetch(url: str) -> str:
    req = urllib.request.Request(
        url,
        headers={"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36"},
    )
    with urllib.request.urlopen(req, timeout=15) as r:
        return r.read().decode("utf-8", errors="ignore")


def find_js_bundles(html: str) -> list[str]:
    """HTML에서 JS bundle 경로 추출 (Vite/Next.js 패턴)."""
    paths = set()
    for pat in [
        r'src="(/assets/[^"]+\.js)"',
        r'src="(/_next/static/[^"]+\.js)"',
        r'src="(/static/[^"]+\.js)"',
        r'src="(/build/[^"]+\.js)"',
    ]:
        for m in re.finditer(pat, html):
            paths.add(m.group(1))
    return sorted(paths)


def extract_qa_blocks(js: str) -> list[tuple[str, str]]:
    """question:`...` ,answer:`...` 정규식 매칭으로 FAQ 추출."""
    results = []
    i = 0
    while True:
        qpos = js.find("question:`", i)
        if qpos == -1:
            break
        apos = js.find("answer:`", qpos)
        if apos == -1:
            break
        astart = apos + len("answer:`")
        aend = js.find("`", astart)
        if aend == -1:
            break
        a_text = js[astart:aend]
        qstart = qpos + len("question:`")
        qend = js.find("`", qstart)
        if qend == -1:
            break
        q_text = js[qstart:qend]
        # 너무 짧거나 코드 같은 건 스킵
        if 20 < len(q_text) < 500 and 20 < len(a_text) < 3000:
            results.append((q_text, a_text))
        i = aend + 1
    return results


def extract_title_blocks(js: str) -> list[str]:
    """title:`...` 직렬화 카피 추출 (features/about 섹션 헤드라인)."""
    results = []
    for m in re.finditer(r'title:`([^`\\n]{15,500})`', js):
        t = m.group(1).strip()
        # 코드/식별자 스킵
        if t.count("{") > 2 or t.count("=") > 3 or t.startswith("function"):
            continue
        if t not in results:
            results.append(t)
    return results


def extract_paragraph_blocks(js: str) -> list[str]:
    """paragraphs:[`...`,`...`] 직렬화 단문 추출."""
    results = []
    for m in re.finditer(r'paragraphs:\[`([^`\\n]{50,2000})`', js):
        p = m.group(1).strip()
        if p.count("{") > 2 or p.count("=") > 2:
            continue
        if p not in results:
            results.append(p)
    return results


def main():
    if len(sys.argv) < 2:
        print("Usage: python3 extract_spa_faq.py <URL>", file=sys.stderr)
        sys.exit(1)

    url = sys.argv[1]
    print(f"Fetching {url} ...\n")
    try:
        html = fetch(url)
    except Exception as e:
        print(f"❌ fetch 실패: {e}", file=sys.stderr)
        sys.exit(1)

    bundles = find_js_bundles(html)
    if not bundles:
        print("❌ JS bundle 없음. SPA가 아닐 수 있음.", file=sys.stderr)
        sys.exit(1)

    print(f"JS bundle {len(bundles)}개 발견:")
    for b in bundles[:5]:
        print(f"  • {b}")
    if len(bundles) > 5:
        print(f"  ... +{len(bundles) - 5} more\n")

    # 가장 큰 bundle 우선 (보통 index-*.js)
    target = next((b for b in bundles if "index" in b), bundles[0])
    if not target.startswith("http"):
        # 상대경로 → 절대경로 변환
        from urllib.parse import urljoin
        target = urljoin(url, target)

    print(f"\nFetching {target} ...")
    try:
        js = fetch(target)
    except Exception as e:
        print(f"❌ bundle fetch 실패: {e}", file=sys.stderr)
        sys.exit(1)

    print(f"JS bundle 크기: {len(js):,} chars\n")

    # Q/A 추출
    qa = extract_qa_blocks(js)
    print(f"=== Q/A 블록 {len(qa)}건 ===\n")
    for i, (q, a) in enumerate(qa, 1):
        print(f"--- Q{i}: {q}")
        print(f"    A: {a[:500]}{'...' if len(a) > 500 else ''}\n")

    # title 추출
    titles = extract_title_blocks(js)
    if titles:
        print(f"\n=== title:` 블록 {len(titles)}건 ===\n")
        for t in titles[:20]:
            print(f"  • {t[:300]}")
        if len(titles) > 20:
            print(f"  ... +{len(titles) - 20} more")

    # paragraphs 추출
    paras = extract_paragraph_blocks(js)
    if paras:
        print(f"\n=== paragraphs:` 블록 {len(paras)}건 ===\n")
        for p in paras[:10]:
            print(f"  • {p[:500]}{'...' if len(p) > 500 else ''}")
            print()
        if len(paras) > 10:
            print(f"  ... +{len(paras) - 10} more")


if __name__ == "__main__":
    main()
