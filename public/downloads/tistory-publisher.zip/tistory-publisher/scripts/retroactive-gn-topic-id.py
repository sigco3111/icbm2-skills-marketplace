#!/usr/bin/env python3
"""
retroactive-gn-topic-id.py — §3.34.9 cleanup 1회 임무 (220차 정의, §원본출처-개선 구현)

목적:
  `published_topics.json`의 `details[]` 배열에서 `gn_topic_id` 박히지 않은 항목을 찾아
  긱뉴스 RSS/URL을 역추적하여 일괄 박기.

근본 원인:
  211~217차 7회 publish (#921~930) 중 post-publish 후크가 `gn_topic_id` 박기 누락.
  218차 시점 details 11건 중 박힌 건 1건 (#930 Ternlight) → 박기 누락 6+건.

매칭 전략 (4단계 fallback):
  1단계: `source_url`이 `news.hada.io/topic?id=N` 패턴이면 즉시 추출
  2단계: `title`을 `feeds.feedburner.com` RSS 긱뉴스 피드와 prefix 매칭
  3단계: Tistory posts.json (있는 경우) 에서 tistory_url → 긱뉴스 URL 매핑
  4단계: 매칭 실패 시 dry-run 모드면 "수동 확인 필요" 출력, 실제 모드면 skip

사용법:
  # dry-run (기본)
  python3 retroactive-gn-topic-id.py

  # 실제 적용
  python3 retroactive-gn-topic-id.py --apply

  # 특정 entry만 (날짜 prefix)
  python3 retroactive-gn-topic-id.py --apply --date 2026-07-08
"""
import argparse
import json
import re
import sys
from datetime import datetime
from pathlib import Path
from urllib.parse import urljoin

try:
    import requests
except ImportError:
    print("❌ 'requests' 패키지 필요. 설치: pip install requests")
    sys.exit(1)


GEEKNEWS_RSS = "https://feeds.feedburner.com/GeekNews"
TISTORY_POSTS_JSON = Path.home() / "tistory_posts.json"  # optional, 있으면 사용
MEMORY_DIR = Path.home() / ".hermes/memory"
PUBLISHED_TOPICS = MEMORY_DIR / "published_topics.json"


def load_details():
    """published_topics.json 로드 + details 배열 반환."""
    if not PUBLISHED_TOPICS.exists():
        print(f"❌ {PUBLISHED_TOPICS} 없음")
        sys.exit(1)
    pt = json.loads(PUBLISHED_TOPICS.read_text())
    return pt, pt.get("details", [])


def extract_gn_topic_id_from_source_url(source_url: str):
    """1단계: source_url에서 즉시 추출."""
    if not source_url:
        return None
    m = re.search(r"news\.hada\.io/topic\?id=(\d+)", source_url)
    return int(m.group(1)) if m else None


def fetch_geeknews_rss():
    """2단계: 긱뉴스 RSS fetch (feedburner 경유)."""
    try:
        r = requests.get(GEEKNEWS_RSS, timeout=15, headers={"User-Agent": "Mozilla/5.0"})
        if r.status_code != 200:
            print(f"⚠️ 긱뉴스 RSS HTTP {r.status_code} — 2단계 매칭 skip")
            return []
        # Simple RSS parser (extract <item><title>, <link>, <guid>)
        items = []
        for m in re.finditer(
            r"<item>(.*?)</item>", r.text, flags=re.DOTALL
        ):
            block = m.group(1)
            title_m = re.search(r"<title>(.*?)</title>", block, flags=re.DOTALL)
            link_m = re.search(r"<link>(.*?)</link>", block)
            guid_m = re.search(r"<guid[^>]*>(.*?)</guid>", block)
            title = re.sub(r"<!\[CDATA\[(.*?)\]\]>", r"\1", title_m.group(1)) if title_m else ""
            link = link_m.group(1) if link_m else ""
            gn_id = None
            id_m = re.search(r"news\.hada\.io/topic\?id=(\d+)", link or guid_m.group(1) if guid_m else "")
            if id_m:
                gn_id = int(id_m.group(1))
            items.append({"title": title.strip(), "link": link.strip(), "gn_id": gn_id})
        return items
    except Exception as e:
        print(f"⚠️ 긱뉴스 RSS fetch 실패: {e}")
        return []


def match_title_to_rss(title: str, rss_items, prefix_len=20):
    """2단계: title prefix 매칭 (case-insensitive, normalize whitespace)."""
    if not title or not rss_items:
        return None

    def normalize(s):
        # strip whitespace + lowercase + remove punctuation
        s = re.sub(r"\s+", "", s.lower())
        s = re.sub(r"[^\w가-힣]", "", s)
        return s

    target = normalize(title[:prefix_len * 2])  # generous prefix
    for item in rss_items:
        cand = normalize(item["title"][:prefix_len * 2])
        if target and cand and (target[:prefix_len] == cand[:prefix_len]):
            return item
    return None


def load_tistory_posts_map():
    """3단계: tistory_posts.json이 있으면 로드 (선택)."""
    if not TISTORY_POSTS_JSON.exists():
        return {}
    try:
        data = json.loads(TISTORY_POSTS_JSON.read_text())
        # 다양한 스키마 대응 — list[dict] 또는 dict
        if isinstance(data, list):
            return {p.get("url", ""): p for p in data if p.get("url")}
        elif isinstance(data, dict):
            return data
    except Exception as e:
        print(f"⚠️ tistory_posts.json 파싱 실패: {e}")
    return {}


def find_missing(details):
    """details 중 gn_topic_id가 박히지 않은 항목만 반환.

    §3.34.9 정의: 211~217차 박기 누락 항목만 대상.
    정상 항목(gn_topic_id 박힘)은 skip.
    """
    missing = []
    for i, d in enumerate(details):
        # 이미 gn_topic_id가 박혀있으면 skip
        if d.get("gn_topic_id"):
            continue
        # 긱뉴스 URL이 없으면 매칭 불가 (주간 기술 요약 같은 비-긱뉴스 글)
        source_url = d.get("source_url", "")
        if not source_url or "news.hada.io" not in source_url:
            continue
        missing.append((i, d))
    return missing


def main():
    parser = argparse.ArgumentParser(description="Retroactively fill gn_topic_id in published_topics.json details")
    parser.add_argument("--apply", action="store_true", help="실제 적용 (기본은 dry-run)")
    parser.add_argument("--date", help="특정 날짜 (YYYY-MM-DD) 항목만 처리")
    args = parser.parse_args()

    mode = "APPLY" if args.apply else "DRY-RUN"
    print(f"=== retroactive-gn-topic-id.py ({mode}) ===")
    print(f"timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S %Z')}")
    print()

    pt, details = load_details()
    print(f"전체 details: {len(details)}개")

    missing = find_missing(details)
    if args.date:
        missing = [(i, d) for i, d in missing if d.get("date", "").startswith(args.date)]
    print(f"gn_topic_id 박기 누락: {len(missing)}개")
    if not missing:
        print("✅ 박기 누락 항목 없음")
        return 0

    # 2단계용: 긱뉴스 RSS fetch (1회)
    print("\n긱뉴스 RSS fetch 중... (2단계 매칭용)")
    rss_items = fetch_geeknews_rss()
    print(f"  RSS 항목 수: {len(rss_items)}")

    # 3단계용: tistory_posts.json (선택)
    tistory_map = load_tistory_posts_map()
    if tistory_map:
        print(f"  Tistory posts.json 매핑: {len(tistory_map)}건")

    # 각 missing 항목 처리
    filled = 0
    failed = []
    for idx, d in missing:
        title = d.get("title", "")
        source_url = d.get("source_url", "")
        tistory_url = d.get("url", "")
        original_id = d.get("gn_topic_id")

        # 1단계: source_url에서 추출
        gn_id = extract_gn_topic_id_from_source_url(source_url)

        # 2단계: title prefix 매칭
        if gn_id is None:
            rss_match = match_title_to_rss(title, rss_items)
            if rss_match and rss_match.get("gn_id"):
                gn_id = rss_match["gn_id"]
                matched_via = f"RSS prefix ({rss_match['title'][:30]}...)"
            else:
                matched_via = "❌ 매칭 실패"
        else:
            matched_via = "source_url 패턴"

        # 3단계: tistory_posts.json (있는 경우)
        if gn_id is None and tistory_url in tistory_map:
            post = tistory_map[tistory_url]
            gn_id = post.get("gn_topic_id")
            if gn_id:
                matched_via = f"tistory_posts.json ({tistory_url})"

        # 보고
        status = "✅" if gn_id else "❌"
        print(f"\n  [{status}] #{idx} {title[:50]}")
        print(f"      source_url: {source_url[:60]}")
        print(f"      매칭 경로:  {matched_via}")
        if gn_id:
            print(f"      → gn_topic_id: {gn_id}")
            if args.apply:
                d["gn_topic_id"] = gn_id
                filled += 1
        else:
            failed.append({"idx": idx, "title": title, "source_url": source_url})

    # 결과
    print()
    print("=" * 60)
    print(f"결과: {filled}/{len(missing)}개 박기 ({mode})")
    if failed:
        print(f"\n❌ 수동 확인 필요 ({len(failed)}개):")
        for f in failed:
            print(f"  - #{f['idx']} {f['title'][:50]}")
            print(f"    source_url: {f['source_url']}")
            print(f"    → 긱뉴스 RSS에서 수동 검색 권장")

    if args.apply and filled > 0:
        # 백업
        backup = PUBLISHED_TOPICS.with_suffix(f".json.bak.{datetime.now().strftime('%Y%m%d_%H%M%S')}")
        backup.write_text(json.dumps(pt, ensure_ascii=False, indent=2))
        print(f"\n💾 백업: {backup}")
        # 저장
        PUBLISHED_TOPICS.write_text(json.dumps(pt, ensure_ascii=False, indent=2))
        print(f"✅ 저장 완료: {PUBLISHED_TOPICS}")
    elif not args.apply:
        print(f"\n💡 실제 적용하려면 --apply 플래그 추가")

    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(main())