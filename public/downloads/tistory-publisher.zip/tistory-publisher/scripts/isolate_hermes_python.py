#!/usr/bin/env python3
"""§3.8.2 격리 패턴 — hermes-agent venv urllib3 비호환 우회

cron 환경에서 §3.8.1 가드 코드 (requests + tistory 쿠키) 실행 시 hermes venv의
urllib3 2.6.x가 Python 3.11.15에서 PEP 604 union syntax로 깨지는 문제.

해결: /usr/bin/python3 (3.9) + PYTHONPATH=/Users/mac/Library/Python/3.9/lib/python/site-packages
      + env -i로 venv 환경변수 완전 차단

사용법:
  bash run_isolated_python.sh << 'PYEOF'
  import requests
  ...
  PYEOF

또는 함수형:
  from isolate_hermes_python import run_isolated
  output = run_isolated("import requests; print(requests.__version__)")
"""
import os
import subprocess
import sys
from pathlib import Path


ISOLATED_PYTHON = "/usr/bin/python3"
SYSTEM_SITE_PACKAGES = "/Users/mac/Library/Python/3.9/lib/python/site-packages"


def run_isolated(python_code: str, env_extra: dict = None, timeout: int = 30) -> tuple:
    """격리된 Python 환경에서 코드 실행

    Returns:
        (stdout, stderr, exit_code)
    """
    # 격리 환경 구성
    env = {
        "HOME": "/Users/mac",
        "PATH": "/usr/bin:/bin",
        "PYTHONPATH": SYSTEM_SITE_PACKAGES,
    }
    if env_extra:
        env.update(env_extra)

    # PYTHONPATH 주입 코드 prepend
    full_code = (
        "import sys\n"
        f"sys.path.insert(0, '{SYSTEM_SITE_PACKAGES}')\n"
        + python_code
    )

    result = subprocess.run(
        [ISOLATED_PYTHON, "-c", full_code],
        env=env,
        capture_output=True,
        text=True,
        timeout=timeout,
    )
    return result.stdout, result.stderr, result.returncode


def guard_tistory_session() -> str:
    """§3.8.1 세션 만료 가드 — 격리 패턴 적용

    Returns:
        'EXPIRED' | 'OK' | 'UNKNOWN'
    """
    code = """
import os, requests
cookies = {k.replace('TISTORY_',''): os.environ[k] for k in os.environ if k.startswith('TISTORY_')}
hdr = {'User-Agent':'Mozilla/5.0','Referer':'https://sigco.tistory.com/manage/','X-Requested-With':'XMLHttpRequest'}
r = requests.get('https://sigco.tistory.com/manage/posts.json?category=-3&page=1',
                 cookies=cookies, headers=hdr, timeout=10, allow_redirects=False)
if r.status_code == 302 and '/auth/login' in r.headers.get('location',''):
    print('EXPIRED')
elif r.status_code == 200 and 'application/json' in r.headers.get('content-type',''):
    print('OK')
else:
    print(f'UNKNOWN:{r.status_code}')
"""
    stdout, stderr, exit_code = run_isolated(code)
    if "EXPIRED" in stdout:
        return "EXPIRED"
    elif "OK" in stdout:
        return "OK"
    else:
        return f"UNKNOWN:{stdout.strip()}"


if __name__ == "__main__":
    # CLI: §3.8.1 가드 1회 실행
    result = guard_tistory_session()
    print(f"[§3.8.2 격리 가드] 세션 상태: {result}")
    if result == "EXPIRED":
        print("⏸️ SKIP: §3.8.1 세션 만료 (302 → /auth/login). 브라우저 쿠키 갱신 필요.")
        sys.exit(2)
    elif result == "OK":
        print("✅ OK: 세션 유효, 발행 진행")
        sys.exit(0)
    else:
        print(f"⏸️ SKIP: 알 수 없는 만료 패턴: {result}")
        sys.exit(3)