#!/usr/bin/env bash
# §3.8.1 세션 만료 가드 — Tistory 쿠키 만료 감지
# Usage: session_expiry_guard.sh
# Exit codes:
#   0 = 세션 유효, 발행 진행 가능
#   1 = 세션 만료 (302 → /auth/login), skip 필요
#   2 = 알 수 없는 만료 패턴, 안전 skip
#   3 = 가드 실행 실패 (네트워크/타임아웃 등), 안전 skip
#
# ⚠️ 중요: Hermes venv의 PYTHONPATH 누설을 차단하기 위해 격자 실행 필수.
#    이 스크립트 내부에서 `unset PYTHONPATH; env -i ...` 수행.

set -u

ENV_FILE="${HOME}/.hermes/secrets/tistory.env"
[[ -f "$ENV_FILE" ]] || { echo "❌ FAIL: $ENV_FILE not found" >&2; exit 3; }

# 격자 실행: venv 누설 차단
unset PYTHONPATH
output=$(env -i HOME="$HOME" PATH=/usr/bin:/bin PYTHONPATH= \
  /usr/bin/python3 << 'PYEOF'
import os, sys, requests
cookies = {k.replace('TISTORY_',''): os.environ[k] for k in os.environ if k.startswith('TISTORY_')}
if not cookies:
    print('NO_COOKIES')
    sys.exit(10)
hdr = {'User-Agent':'Mozilla/5.0','Referer':'https://sigco.tistory.com/manage/','X-Requested-With':'XMLHttpRequest'}
try:
    r = requests.get('https://sigco.tistory.com/manage/posts.json?category=-3&page=1',
                    cookies=cookies, headers=hdr, timeout=10, allow_redirects=False)
except Exception as e:
    print(f'NETWORK_ERROR: {type(e).__name__}: {e}')
    sys.exit(11)

if r.status_code == 302 and '/auth/login' in r.headers.get('location',''):
    print('EXPIRED')
elif r.status_code == 200 and 'application/json' in r.headers.get('content-type',''):
    print('VALID')
else:
    print(f'UNKNOWN: status={r.status_code} ct={r.headers.get("content-type")}')
PYEOF
) || { echo "❌ FAIL: 가드 실행 실패 (exit=$?)" >&2; exit 3; }

case "$output" in
    VALID)
        echo "✅ OK: 세션 유효, 발행 진행"
        exit 0
        ;;
    EXPIRED)
        echo "⏸️ SKIP: §3.8.1 세션 만료 (302 → /auth/login). 브라우저 쿠키 갱신 필요."
        exit 1
        ;;
    NO_COOKIES)
        echo "❌ FAIL: TISTORY_* 환경변수 없음"
        exit 3
        ;;
    NETWORK_ERROR:*)
        echo "⏸️ SKIP: §3.8.1 네트워크 오류 (${output#NETWORK_ERROR:})"
        exit 3
        ;;
    UNKNOWN:*)
        echo "⏸️ SKIP: §3.8.1 알 수 없는 만료 패턴 (${output#UNKNOWN:})"
        exit 2
        ;;
    *)
        echo "⏸️ SKIP: §3.8.1 파싱 실패 (raw=$output)"
        exit 3
        ;;
esac