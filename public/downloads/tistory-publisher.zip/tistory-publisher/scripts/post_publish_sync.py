#!/usr/bin/env python3
"""
post_publish_sync.py — §3.11 5-1 자동 보정 스크립트 (241차 영구화)

tistory_publisher.py가 발행 성공해도 pt/state/stats를 자동 갱신하지 않으므로,
이 스크립트로 7필드 원샬 동기화한다.

동기화 대상:
  1. pt['last'] — hash, topic, title, date, url, source_url, gn_topic_id
  2. pt['details'] — append entry (hash, topic, title, url, date)
  3. pt['topics'][hash] — dict 인덱스 (있으면)
  4. state['last_published_url'], state['last_published_id']
  5. state['last'] — title, url, date
  6. state['details'] — append entry
  7. state['daily_counts'][today][category] += 1

Usage (모듈):
    import post_publish_sync
    post_publish_sync.sync(
        publish_url='https://sigco.tistory.com/958',
        title='Tencent, 오픈소스 모델 Hy3 공개',
        gn_topic_id=31290,
        category='AI/ML',
        source_url='https://news.hada.io/topic?id=31290'
    )

Usage (CLI):
    env -i HOME=/Users/mac PATH=/usr/bin:/bin /usr/bin/python3 \\
        post_publish_sync.py --url 'https://sigco.tistory.com/958' \\
        --title 'Tencent, 오픈소스 모델 Hy3 공개' \\
        --gn-topic-id 31290 --category 'AI/ML' \\
        --source-url 'https://news.hada.io/topic?id=31290'

Usage (drift 자동 보정):
    post_publish_sync.sync_from_pt()  # pt를 source-of-truth로 state 보정
"""
import argparse
import hashlib
import json
import os
import sys
from datetime import datetime

PT_PATH = '/Users/mac/.hermes/memory/published_topics.json'
STATE_PATH = '/Users/mac/.hermes/memory/blog_pipeline_state.json'

# 카테고리 ID 매핑 (known-category-ids.md 참조)
CATEGORY_ID_MAP = {
    'AI/ML': 1219746,
    '개발도구': None,  # unknown — env 또는 인자로 전달
    '개발팁': None,
    'iOS/Swift': None,
}


def _now_iso() -> str:
    return datetime.now().strftime('%Y-%m-%dT%H:%M')


def _today() -> str:
    return datetime.now().strftime('%Y-%m-%d')


def _hash_topic(title: str) -> str:
    return hashlib.md5(title.encode('utf-8')).hexdigest()


def _post_id_from_url(url: str) -> str:
    return url.rstrip('/').split('/')[-1]


def sync(publish_url: str, title: str, gn_topic_id: int,
         category: str, source_url: str, category_id: int = None) -> dict:
    """7필드 원샬 동기화. 발행 후 1회 호출 필수."""
    now_iso = _now_iso()
    today = _today()
    post_id = _post_id_from_url(publish_url)
    topic_hash = _hash_topic(title)

    # category_id 자동 매핑 (인자 없을 시)
    if category_id is None:
        category_id = CATEGORY_ID_MAP.get(category)
        if category_id is None:
            # fallback: env TISTORY_DEFAULT_CAT_ID
            env_cid = os.environ.get('TISTORY_DEFAULT_CAT_ID')
            if env_cid:
                category_id = int(env_cid)
            else:
                # 마지막 수단: 0 (검증 실패 명시)
                category_id = 0
                print(f"[WARN] category_id unknown for '{category}', using 0 (verify manually)")

    result = {'pt_updated': False, 'state_updated': False, 'errors': []}

    # === 1) post_topics.json ===
    try:
        with open(PT_PATH) as f:
            pt = json.load(f)

        new_pt_last = {
            'hash': topic_hash,
            'topic': title.split('—')[0].strip() if '—' in title else title,
            'title': title,
            'date': now_iso,
            'url': publish_url,
            'source_url': source_url,
            'gn_topic_id': gn_topic_id,
        }
        pt['last'] = new_pt_last

        # details: 중복 URL 체크 후 append
        existing_urls = {d.get('url') for d in pt.get('details', [])}
        if publish_url not in existing_urls:
            pt.setdefault('details', []).append({
                'topic': new_pt_last['topic'],
                'title': title,
                'hash': topic_hash,
                'url': publish_url,
                'date': now_iso,
            })

        # topics dict (있으면)
        if isinstance(pt.get('topics'), dict):
            pt['topics'][topic_hash] = {
                'title': title,
                'url': publish_url,
                'date': today,
                'topic_id': gn_topic_id,
            }

        with open(PT_PATH, 'w') as f:
            json.dump(pt, f, ensure_ascii=False, indent=2)
        result['pt_updated'] = True
    except Exception as e:
        result['errors'].append(f'pt sync failed: {e}')

    # === 2) state.json ===
    try:
        with open(STATE_PATH) as f:
            state = json.load(f)

        state['last_published_url'] = publish_url
        state['last_published_id'] = post_id
        state['last'] = {
            'title': title,
            'url': publish_url,
            'date': now_iso,
        }

        # details: 중복 URL 체크 후 append
        existing_state_urls = {d.get('url') for d in state.get('details', [])}
        if publish_url not in existing_state_urls:
            state.setdefault('details', []).append({
                'topic_id': gn_topic_id,
                'title': title,
                'url': publish_url,
                'date': today,
                'category': category,
                'category_id': category_id,
                'gn_topic_id': gn_topic_id,
                'source_url': source_url,
                'topic': str(gn_topic_id),
            })

        # daily_counts +1 (cat_id 누설 가드: 키는 카테고리명)
        dc = state.setdefault('daily_counts', {})
        today_dc = dc.setdefault(today, {})
        # cat_id 누설 검사 (cleanup cron 임무 #16 로직)
        bad_keys = [k for k in today_dc if k.isdigit()]
        if bad_keys:
            print(f"[FIX] Removing cat_id leak keys: {bad_keys}")
            for k in bad_keys:
                today_dc.pop(k, None)
        today_dc[category] = today_dc.get(category, 0) + 1
        dc[today] = today_dc

        with open(STATE_PATH, 'w') as f:
            json.dump(state, f, ensure_ascii=False, indent=2)
        result['state_updated'] = True
    except Exception as e:
        result['errors'].append(f'state sync failed: {e}')

    # === 3) §3.5 3중 신호 재검증 ===
    try:
        with open(PT_PATH) as f:
            pt = json.load(f)
        with open(STATE_PATH) as f:
            state = json.load(f)
        pt_url = pt['last'].get('url')
        st_url = state['details'][-1].get('url') if state.get('details') else None
        last_pub = state.get('last_published_url')
        match = (pt_url == st_url == last_pub)
        result['triple_signal_match'] = match
        if not match:
            result['errors'].append(
                f'§3.5 3중 신호 불일치: pt={pt_url} state={st_url} last_published={last_pub}'
            )
    except Exception as e:
        result['errors'].append(f'verification failed: {e}')

    return result


def sync_from_pt() -> dict:
    """pt를 source-of-truth로 state 보정 (drift 감지 시 publish 전 호출)."""
    try:
        with open(PT_PATH) as f:
            pt = json.load(f)
        with open(STATE_PATH) as f:
            state = json.load(f)

        pt_last = pt.get('last', {})
        if not pt_last or not pt_last.get('url'):
            return {'fixed': False, 'reason': 'pt.last.url missing'}

        publish_url = pt_last['url']
        title = pt_last.get('title', '')
        gn_topic_id = pt_last.get('gn_topic_id', 0)
        source_url = pt_last.get('source_url', '')

        # state에서 category 추출 (있으면)
        category = 'AI/ML'
        category_id = 1219746
        for d in reversed(state.get('details', [])):
            if d.get('url') == publish_url:
                category = d.get('category', 'AI/ML')
                category_id = d.get('category_id', 1219746)
                break

        return sync(publish_url, title, gn_topic_id, category, source_url, category_id)
    except Exception as e:
        return {'fixed': False, 'reason': str(e)}


def main():
    parser = argparse.ArgumentParser(description='§3.11 5-1 자동 보정 (post_publish_sync)')
    sub = parser.add_subparsers(dest='cmd')

    sync_cmd = sub.add_parser('sync', help='publish 후 7필드 원샬 동기화')
    sync_cmd.add_argument('--url', required=True, help='발행된 글 URL (예: https://sigco.tistory.com/958)')
    sync_cmd.add_argument('--title', required=True, help='글 제목')
    sync_cmd.add_argument('--gn-topic-id', type=int, required=True, help='GN topic_id')
    sync_cmd.add_argument('--category', required=True, help='카테고리명 (예: AI/ML)')
    sync_cmd.add_argument('--source-url', required=True, help='GN 원본 URL')
    sync_cmd.add_argument('--category-id', type=int, default=None, help='Tistory 카테고리 ID (생략시 자동 매핑)')

    sub.add_parser('sync-from-pt', help='pt를 source-of-truth로 state 보정 (drift 감지 시)')

    args = parser.parse_args()

    if args.cmd == 'sync':
        result = sync(args.url, args.title, args.gn_topic_id, args.category,
                      args.source_url, args.category_id)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(0 if result.get('triple_signal_match') else 1)
    elif args.cmd == 'sync-from-pt':
        result = sync_from_pt()
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(0 if result.get('triple_signal_match') else 1)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == '__main__':
    main()