#!/usr/bin/env python3
"""
gn-fetch-content.py — 긱뉴스 토픽 본문 fetch 영구화 스크립트
Cleanup Cron 임무 #12 (v2.7.78~ 영구화 시급)

배경 (227~232차):
  - 긱뉴스 `.md` endpoint (`/topic.md?id=N`)가 **6회째 연속 100% 404** (227~232차 영구 확정)
  - 긱뉴스 측 마크다운 변환 기능의 영구 변경으로 보임 — 더 이상 복구 안 될 가능성 높음
  - HTML `/topic?id=N` (200 OK)은 정상 응답하지만, 본문 영역 마크업이 비표준
  - 232차에 표준 HTML 패턴 (`<div class="topic_content">` / `topic_body` / `topic_inner` / `<article>` / `id="content"`) **모두 매칭 실패** — 첫 사례

함정 이력:
  - 227차: HTML `<div class="topic_contents">` 패턴으로 1,478자 추출 성공
  - 228차: HTML fallback 정규식으로 5,359자 추출 → 한국어 재작성 1,860자
  - 229차: HTML fallback 9,081자 추출 → 한국어 재작성
  - 230차: HTML fallback 1,651자 추출
  - 231차: HTML fallback 9,671자 추출
  - **232차: 표준 HTML 패턴 모두 실패 → meta description + refresh-topics summary 결합이 유일**

3단계 fallback (절대 순서):
  1. `.md` endpoint (`/topic.md?id=N`) — 6회째 100% 404, 사실상 dead path
  2. HTML `/topic?id=N` + 정규식 패턴 6종 (가장 긴 `<div>` fallback 포함)
  3. `meta description` + `feeds.feedburner.com` RSS summary 결합 (최후 fallback)

전부 실패 시:
  - `None` 반환 + 발행 skip (가짜 발행 방지)
  - cleanup cron 로그는 stderr로 "❌ content 추출 완전 실패" 출력

사용법:
  from gn_fetch_content import fetch_gn_content
  result = fetch_gn_content(topic_id=31254)
  if result is None:
      # 발행 skip
      pass
  else:
      title, content_text, source_url = result
      # content_text로 한국어 본문 작성
"""

import urllib.request
import urllib.error
import re
import sys
import xml.etree.ElementTree as ET
from typing import Optional, Tuple

GN_TOPIC_URL = "https://news.hada.io/topic?id={tid}"
GN_MD_URL = "https://news.hada.io/topic.md?id={tid}"
GN_RSS_URL = "https://feeds.feedburner.com/geeknews-feed"
GN_TOPIC_BASE = "https://news.hada.io/topic"

USER_AGENT = "Mozilla/5.0"

# §3.34.24.2 — HTML 본문 영역 추출 정규식 패턴 6종
HTML_CONTENT_PATTERNS = [
    (r'<div class="topic_content">(.+?)</div>', 'topic_content'),
    (r'<div class="topic-contents">(.+?)</div>', 'topic-contents'),
    (r'<div class="topic-content">(.+?)</div>', 'topic-content (hyphen)'),
    (r'<div class="topic_body"[^>]*>(.+?)<div class="topic_info"', 'topic_body'),
    (r'<div class="topic_inner"[^>]*>(.+?)<div class="topic_info"', 'topic_inner'),
    (r'<div[^>]*class="[^"]*desc[^"]*"[^>]*>(.+?)</div>', 'desc'),
    (r'<article[^>]*>(.+?)</article>', 'article'),
    (r'<div[^>]*id="content"[^>]*>(.+?)</div>', 'id=content'),
    (r'<div class="topic"[^>]*>(.+?)<div class="topic_info"', 'topic + topic_info'),
    (r'<!-- topic content -->(.+?)<!-- // topic content -->', 'comment delim'),
]


def _fetch_url(url: str, timeout: int = 10) -> Optional[str]:
    """단일 URL fetch. 실패 시 None."""
    try:
        req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.read().decode("utf-8")
    except (urllib.error.HTTPError, urllib.error.URLError, TimeoutError) as e:
        return None


def _strip_html(html: str) -> str:
    """HTML 태그 제거 + 공백 정규화."""
    text = re.sub(r"<[^>]+>", " ", html)
    text = re.sub(r"&[a-z]+;", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def _try_md_endpoint(topic_id: int) -> Optional[str]:
    """1단계: .md endpoint (227~232차 6회째 100% 404, 사실상 dead)."""
    content = _fetch_url(GN_MD_URL.format(tid=topic_id))
    if content and len(content) > 100:
        return content
    return None


def _try_html_endpoint(topic_id: int) -> Optional[Tuple[str, str, str]]:
    """
    2단계: HTML /topic?id=N + 정규식 패턴 6종.
    Returns: (title, content_text, source_url) 또는 None.
    """
    html = _fetch_url(GN_TOPIC_URL.format(tid=topic_id))
    if not html:
        return None

    # title 추출
    title_match = re.search(r"<title>(.+?)\s*\|\s*GeekNews</title>", html)
    if not title_match:
        title_match = re.search(r"<title>(.+?)</title>", html)
    title = title_match.group(1) if title_match else f"토픽 {topic_id}"

    # 패턴 6종 시도
    for pattern, name in HTML_CONTENT_PATTERNS:
        m = re.search(pattern, html, re.DOTALL)
        if m:
            text = _strip_html(m.group(1))
            if len(text) > 100:
                print(f"  ✅ HTML fallback 매칭: {name} → {len(text)}자", file=sys.stderr)
                return title, text, GN_TOPIC_URL.format(tid=topic_id)

    # 패턴 매칭 안 되면 가장 긴 <div> 영역 fallback
    divs = re.findall(r"<div[^>]*>(.{200,5000}?)</div>", html, re.DOTALL)
    if divs:
        best = max(divs, key=len)
        text = _strip_html(best)
        if len(text) > 100:
            print(f"  ✅ HTML fallback (가장 긴 div) → {len(text)}자", file=sys.stderr)
            return title, text, GN_TOPIC_URL.format(tid=topic_id)

    # 232차 케이스: 모든 표준 패턴 실패 → meta description 사용
    m = re.search(r'<meta name="description" content="(.+?)"', html)
    if m:
        desc = m.group(1)
        print(f"  ⚠️  HTML 표준 패턴 실패 → meta description fallback: {len(desc)}자", file=sys.stderr)
        return title, desc, GN_TOPIC_URL.format(tid=topic_id)

    return None


def _try_rss_summary(topic_id: int) -> Optional[Tuple[str, str, str]]:
    """
    3단계: feeds.feedburner.com RSS에서 긱뉴스 summary 추출 (최후 fallback).
    Returns: (title, summary, source_url) 또는 None.
    """
    content = _fetch_url(GN_RSS_URL)
    if not content:
        return None

    try:
        ns = {"a": "http://www.w3.org/2005/Atom"}
        root = ET.fromstring(content)
        entries = root.findall("a:entry", ns)
        for e in entries:
            id_el = e.find("a:id", ns)
            if id_el is None:
                continue
            url = id_el.text or ""
            m = re.search(r"topic\?id=(\d+)", url)
            if m and int(m.group(1)) == topic_id:
                title = (e.find("a:title", ns).text or "").strip()
                summary_el = e.find("a:summary", ns)
                summary = (summary_el.text or "").strip() if summary_el is not None else ""
                if summary and len(summary) > 50:
                    print(f"  ⚠️  RSS summary fallback: {len(summary)}자", file=sys.stderr)
                    return title, summary, GN_TOPIC_URL.format(tid=topic_id)
    except (ET.ParseError, AttributeError):
        pass
    return None


def fetch_gn_content(topic_id: int) -> Optional[Tuple[str, str, str]]:
    """
    긱뉴스 토픽 본문을 3단계 fallback으로 추출.

    Returns:
        (title, content_text, source_url) 튜플 — 성공
        None — 전부 실패 (발행 skip 필수)

    사용 예:
        result = fetch_gn_content(31254)
        if result is None:
            print("❌ content 추출 완전 실패 — 발행 skip")
            return
        title, content, url = result
        # content로 한국어 본문 작성
    """
    # 1단계: .md
    md = _try_md_endpoint(topic_id)
    if md:
        print(f"  ✅ .md 200: {len(md)} bytes", file=sys.stderr)
        # .md는 frontmatter strip 필요 (§3.23.1)
        text = re.sub(r"^---.+?---\s*", "", md, count=1, flags=re.DOTALL)
        return None, text.strip(), GN_MD_URL.format(tid=topic_id)

    # 2단계: HTML
    html_result = _try_html_endpoint(topic_id)
    if html_result:
        return html_result

    # 3단계: RSS summary
    rss_result = _try_rss_summary(topic_id)
    if rss_result:
        return rss_result

    print(f"  ❌ content 추출 완전 실패 (topic_id={topic_id}) — 발행 skip", file=sys.stderr)
    return None


# CLI 사용 (디버그 / 단독 실행)
if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 gn-fetch-content.py <topic_id>")
        sys.exit(1)
    tid = int(sys.argv[1])
    result = fetch_gn_content(tid)
    if result is None:
        print("❌ FAIL")
        sys.exit(1)
    title, content, url = result
    print(f"✅ title: {title}")
    print(f"✅ content: {len(content)}자")
    print(f"✅ url: {url}")
    print(f"\n--- 미리보기 (300자) ---")
    print(content[:300])
