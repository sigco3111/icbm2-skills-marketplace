#!/usr/bin/env python3
"""
notion-cleanup-v3.py — 215차 영구화 Notion cleanup (모든 매칭 PATCH + DB schema dump 통합)

3단계 매칭 (30자 prefix → source_url 폴백 → URL 직접 매칭) + **모든 매칭 PATCH** (§3.29.2)
+ **§3.32.1 DB schema dump 동적 속성명 매핑** (한글/영문 자동 감지)
+ **§3.31.1 cleanup 모드 분리**: --verify-only / --deactivate-active / --archive-duplicates
+ **fail-safe 검증**: PATCH 후 select.name 응답 확인 (§3.32.1)

caller context: cron 자동 환경 (subprocess.Popen 없음, terminal + python3 heredoc)

사용법:
  # 현재 active 페이지 verify (DRY RUN)
  python3 notion-cleanup-v3.py --verify-only

  # 활성 페이지만 비활성화 (publish cleanup 기본 동작)
  python3 notion-cleanup-v3.py --deactivate-active

  # 동일 URL 다중 페이지 archive (URL당 1건만 남기고 archive)
  python3 notion-cleanup-v3.py --archive-duplicates
"""

import json
import os
import sys
import urllib.request
import urllib.error
from collections import Counter

# ============ 설정 ============
NOTION_DB_ID = '34276f2e-9097-811e-ab69-f8759ecf0be7'
NOTION_TOKEN_PATH = os.path.expanduser('~/.hermes/secrets/notion_token.txt')
STATE_PATH = '/Users/mac/.hermes/memory/blog_pipeline_state.json'
TODAY = '2026-07-08'  # cron 임무 시 오늘 날짜로 교체


# §3.32.1 — DB schema dump + 동적 속성명 매핑
def fetch_db_schema():
    """DB schema dump로 실제 속성명 (한글/영문) 매핑.

    Returns:
        dict: {'status_prop': str, 'title_prop': str, 'url_prop': str, ...}

    §3.32.1 핵심: select + '활성'/'비활성' options 탐색으로 한글/영문 자동 감지.
    """
    token = open(NOTION_TOKEN_PATH).read().strip()
    req = urllib.request.Request(
        f'https://api.notion.com/v1/databases/{NOTION_DB_ID}',
        headers={
            'Authorization': f'Bearer {token}',
            'Notion-Version': '2022-06-28',
        },
    )
    with urllib.request.urlopen(req, timeout=10) as resp:
        db = json.loads(resp.read())

    properties = db.get('properties', {})
    schema = {}

    # 상태 (status) — select + '활성'/'비활성' options 탐색
    for name, prop in properties.items():
        if prop.get('type') == 'select':
            opts = [o.get('name') for o in prop.get('select', {}).get('options', [])]
            if '활성' in opts and '비활성' in opts:
                schema['status_prop'] = name
                break

    # 이름 (title) — type=title
    for name, prop in properties.items():
        if prop.get('type') == 'title':
            schema['title_prop'] = name
            break

    # URL — type=url
    for name, prop in properties.items():
        if prop.get('type') == 'url':
            schema['url_prop'] = name
            break

    # 카테고리 (category) — type=select
    for name, prop in properties.items():
        if prop.get('type') == 'select' and name != schema.get('status_prop'):
            opts = [o.get('name') for o in prop.get('select', {}).get('options', [])]
            if 'AI/ML' in opts or '개발도구' in opts or '개발팁' in opts:
                schema['category_prop'] = name
                break

    # 마지막 사용일 — type=date
    for name, prop in properties.items():
        if prop.get('type') == 'date' and '사용' in name:
            schema['last_used_prop'] = name
            break

    return schema, properties


def fetch_active_pages(schema):
    """Notion DB의 활성 상태 페이지 모두 조회 (동적 속성명 매핑).

    §3.32.1: schema['status_prop'] 사용 (한글 '상태' 또는 영문 'Status' 자동 감지)
    """
    token = open(NOTION_TOKEN_PATH).read().strip()
    status_prop = schema.get('status_prop', '상태')
    title_prop = schema.get('title_prop', '이름')
    url_prop = schema.get('url_prop', 'URL')
    cat_prop = schema.get('category_prop', '카테고리')

    pages = []
    cursor = None
    while True:
        body = {
            'page_size': 100,
            'filter': {'property': status_prop, 'select': {'equals': '활성'}},
        }
        if cursor:
            body['start_cursor'] = cursor
        req = urllib.request.Request(
            f'https://api.notion.com/v1/databases/{NOTION_DB_ID}/query',
            data=json.dumps(body).encode('utf-8'),
            headers={
                'Authorization': f'Bearer {token}',
                'Notion-Version': '2022-06-28',
                'Content-Type': 'application/json',
            },
            method='POST',
        )
        with urllib.request.urlopen(req, timeout=20) as resp:
            data = json.loads(resp.read())
        for r in data['results']:
            props = r['properties']
            # §3.32.1 동적 매핑
            name = (
                props.get(title_prop, {}).get('title', [{}])[0].get('plain_text', '')
                if props.get(title_prop, {}).get('title')
                else ''
            )
            cat = (
                props.get(cat_prop, {}).get('select', {}).get('name', '')
                if props.get(cat_prop, {}).get('select')
                else ''
            )
            url = props.get(url_prop, {}).get('url', '') or ''
            if url:
                pages.append({'id': r['id'], 'name': name, 'cat': cat, 'url': url})
        if not data.get('has_more'):
            break
        cursor = data.get('next_cursor')
    return pages


def fetch_all_pages(schema):
    """전체 페이지 (활성 + 비활성) 조회 — archive-duplicates 모드용."""
    token = open(NOTION_TOKEN_PATH).read().strip()
    title_prop = schema.get('title_prop', '이름')
    url_prop = schema.get('url_prop', 'URL')

    pages = []
    cursor = None
    while True:
        body = {'page_size': 100}
        if cursor:
            body['start_cursor'] = cursor
        req = urllib.request.Request(
            f'https://api.notion.com/v1/databases/{NOTION_DB_ID}/query',
            data=json.dumps(body).encode('utf-8'),
            headers={
                'Authorization': f'Bearer {token}',
                'Notion-Version': '2022-06-28',
                'Content-Type': 'application/json',
            },
            method='POST',
        )
        with urllib.request.urlopen(req, timeout=20) as resp:
            data = json.loads(resp.read())
        for r in data['results']:
            props = r['properties']
            name = (
                props.get(title_prop, {}).get('title', [{}])[0].get('plain_text', '')
                if props.get(title_prop, {}).get('title')
                else ''
            )
            url = props.get(url_prop, {}).get('url', '') or ''
            if url:
                pages.append({'id': r['id'], 'name': name, 'url': url, 'created': r.get('created_time', '')})
        if not data.get('has_more'):
            break
        cursor = data.get('next_cursor')
    return pages


def patch_page_inactive(page_id, date_str, schema, dry_run=False):
    """페이지 상태를 비활성 + 마지막 사용일 설정.

    §3.32.1 fail-safe: PATCH 후 select.name 응답이 '비활성'인지 검증.
    """
    if dry_run:
        return True  # dry-run 모드

    token = open(NOTION_TOKEN_PATH).read().strip()
    status_prop = schema.get('status_prop', '상태')
    last_used_prop = schema.get('last_used_prop', '마지막 사용일')

    body = {
        'properties': {
            status_prop: {'select': {'name': '비활성'}},
        }
    }
    if last_used_prop:
        body['properties'][last_used_prop] = {'date': {'start': date_str}}

    req = urllib.request.Request(
        f'https://api.notion.com/v1/pages/{page_id}',
        data=json.dumps(body).encode('utf-8'),
        headers={
            'Authorization': f'Bearer {token}',
            'Notion-Version': '2022-06-28',
            'Content-Type': 'application/json',
        },
        method='PATCH',
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            result = json.loads(resp.read())
            # §3.32.1 fail-safe 검증
            actual_status = result.get('properties', {}).get(status_prop, {}).get('select', {}).get('name', '')
            if actual_status != '비활성':
                print(f'  ⚠️ PATCH 응답 status 불일치: expected=비활성, actual={actual_status}')
                return False
            return True
    except urllib.error.HTTPError as e:
        print(f'  ❌ PATCH 실패: {page_id[:20]}... → HTTP {e.code}')
        return False


def archive_page(page_id, dry_run=False):
    """페이지 archive (§3.31.1 archive-duplicates 모드)."""
    if dry_run:
        return True
    token = open(NOTION_TOKEN_PATH).read().strip()
    req = urllib.request.Request(
        f'https://api.notion.com/v1/pages/{page_id}',
        data=json.dumps({'archived': True}).encode('utf-8'),
        headers={
            'Authorization': f'Bearer {token}',
            'Notion-Version': '2022-06-28',
            'Content-Type': 'application/json',
        },
        method='PATCH',
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return True
    except urllib.error.HTTPError as e:
        print(f'  ❌ archive 실패: {page_id[:20]}... → HTTP {e.code}')
        return False


def find_matching_pages(all_pages, state):
    """3단계 매칭: 30자 prefix → source_url → URL 직접. 모든 매칭 반환."""
    state_titles = [t.get('topic', '') for t in state.get('last_topics', []) if t.get('topic')]
    state_sources = {t.get('source_url', '') for t in state.get('last_topics', []) if t.get('source_url')}

    matches = []
    for p in all_pages:
        matched = False
        match_method = None

        # 1차: 30자 prefix 매칭 (§3.22.2)
        name = p['name'].lower()[:30]
        for st in state_titles:
            if st and (
                st[:30].lower() == name
                or name in st.lower()[:30]
                or st.lower()[:30] in name
            ):
                matched = True
                match_method = '30자 prefix'
                break

        # 2차: source_url 직접 매칭 (§3.25.2)
        if not matched and p['url'] in state_sources:
            matched = True
            match_method = 'source_url'

        # 3차: state.last_topics[*].url에 매칭되는 긱뉴스 URL이 있는지 (publish cleanup용)
        if not matched:
            for lt in state.get('last_topics', []):
                if lt.get('source_url') == p['url']:
                    matched = True
                    match_method = 'URL 직접 (§3.28.2)'
                    break

        if matched:
            matches.append((p, match_method))

    return matches


def main():
    if len(sys.argv) < 2 or sys.argv[1] not in ('--verify-only', '--deactivate-active', '--archive-duplicates'):
        print('사용법: notion-cleanup-v3.py [--verify-only | --deactivate-active | --archive-duplicates]')
        print('  --verify-only         : 현황만 출력 (DRY RUN)')
        print('  --deactivate-active   : 활성 페이지만 비활성화 (publish cleanup)')
        print('  --archive-duplicates  : URL당 1건만 남기고 archive (§3.31.1)')
        sys.exit(1)

    mode = sys.argv[1]
    dry_run = (mode == '--verify-only')

    # §3.32.1 — DB schema dump로 동적 속성명 매핑
    print(f'🔍 DB schema dump 중...')
    schema, raw_properties = fetch_db_schema()
    print(f'   매핑 결과:')
    for k, v in schema.items():
        print(f'     {k}: {v!r}')

    if not os.path.exists(STATE_PATH):
        print(f'❌ state.json 없음: {STATE_PATH}')
        sys.exit(1)
    state = json.loads(open(STATE_PATH).read())

    if mode == '--archive-duplicates':
        # §3.31.1 archive-duplicates: URL당 1건만 남기고 archive
        all_pages = fetch_all_pages(schema)
        print(f'\n📊 전체 페이지: {len(all_pages)}건')

        # URL → pages 매핑
        url_to_pages = {}
        for p in all_pages:
            url_to_pages.setdefault(p['url'], []).append(p)

        # URL당 페이지 수 분포 진단 (§3.31.2)
        url_counts = Counter()
        for url, pages in url_to_pages.items():
            url_counts[len(pages)] += 1
        print(f'   페이지 수 분포: {dict(url_counts.most_common())}')

        # 중복 URL (2건 이상) → 가장 최근 1건만 남기고 archive
        archived = 0
        for url, pages in url_to_pages.items():
            if len(pages) > 1:
                # created_time 기준 정렬 (가장 최근 1건만 유지)
                pages.sort(key=lambda x: x.get('created', ''), reverse=True)
                keep = pages[0]
                to_archive = pages[1:]
                if not dry_run:
                    for p in to_archive:
                        if archive_page(p['id']):
                            archived += 1
                else:
                    archived += len(to_archive)
                print(f'   {url[:60]} → {len(pages)}건 (keep: {keep["name"][:30]}, archive: {len(to_archive)})')

        print(f'\n=== archive-duplicates: {archived}건 ({"DRY RUN" if dry_run else "APPLIED"}) ===')
        return

    # --verify-only / --deactivate-active
    print(f'\n📊 Notion 활성 페이지 조회 중...')
    all_pages = fetch_active_pages(schema)
    print(f'   활성: {len(all_pages)}건')

    print(f'📊 state.last_topics: {len(state.get("last_topics", []))}건')

    print(f'📊 3단계 매칭 실행 (30자 prefix → source_url → URL 직접)...')
    matches = find_matching_pages(all_pages, state)
    print(f'   매칭: {len(matches)}건')

    if not matches:
        print('✅ 매칭 없음 → cleanup 불필요')
    else:
        # 중복 URL 카운트 (위생 작업 알림)
        url_counts = {}
        for p, _ in matches:
            url_counts[p['url']] = url_counts.get(p['url'], 0) + 1
        dupes = {u: c for u, c in url_counts.items() if c > 1}
        if dupes:
            print(f'⚠️ 동일 URL 다중 매칭 {len(dupes)}개 (모두 PATCH):')
            for u, c in dupes.items():
                print(f'   - {u} → {c}건')

        # §3.29.2: 모든 매칭 PATCH (1건만 ❌)
        patched = 0
        for p, method in matches:
            if patch_page_inactive(p['id'], TODAY, schema, dry_run):
                patched += 1
                dup_marker = ' [중복]' if url_counts.get(p['url'], 0) > 1 else ''
                action = 'VERIFY' if dry_run else 'PATCH'
                print(f'  ✅ {action} ({method}): {p["name"][:50]}{dup_marker}')

        print(f'\n=== Notion cleanup: {patched}/{len(matches)} 성공 ({"DRY RUN" if dry_run else "APPLIED"}, {TODAY}) ===')

    # §3.29.1: by_category 변형 키 발견 알림
    by_cat = state.get('stats', {}).get('by_category', {})
    variants = {
        'AI/ML': ['AI 뉴스', 'AI뉴스'],
        '개발 팁': ['개발팁', '개발 팁'],
        '개발도구': ['개발 도구', '개발도구'],
        'iOS/Swift': ['iOS/swift', 'iOS/Swift', 'iOS/SWIFT'],
    }
    found_variants = []
    for canonical, variants_list in variants.items():
        for v in variants_list:
            if v in by_cat and v != canonical:
                found_variants.append((canonical, v, by_cat[v]))

    if found_variants:
        print(f'\n⚠️ §3.29.1 by_category 공백 변형 키 발견 ({len(found_variants)}건):')
        for canonical, variant, count in found_variants:
            print(f'   {variant!r}: {count} → {canonical!r}: {by_cat.get(canonical, 0)} 합산 권장')

    # §3.32.2: Tistory 카테고리 ID vs 정규화 key 매핑 검증
    print(f'\n📊 §3.32.2 stats.by_category 정규화 key 검증:')
    for k in sorted(by_cat.keys()):
        if k in ('AI/ML', '개발 팁', '개발도구', 'iOS/Swift', '투자/경제', '아이디어', '기타'):
            print(f'   ✅ {k!r}: {by_cat[k]}')


if __name__ == '__main__':
    main()
