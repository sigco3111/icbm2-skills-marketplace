#!/usr/bin/env python3
"""
strip_frontmatter.py — markdown YAML frontmatter 제거 유틸 (§3.23.1)

Tistory 발행 시 `--file`에 frontmatter 포함 markdown을 전달하면
content 검증에서 "Content 텍스트 길이 부족" 에러가 발생한다.
이 스크립트는 frontmatter를 strip한 content-only 파일을 생성한다.

Usage:
    python3 strip_frontmatter.py <input.md> <output.txt>

Example:
    python3 strip_frontmatter.py /tmp/blog_206th/post_31176.md /tmp/blog_206th/post_31176_content.txt
    # → content-only 파일을 --file에 전달
    python3 ~/.hermes/scripts/tistory_publisher.py --file /tmp/blog_206th/post_31176_content.txt ...
"""
import sys
import os


def strip_frontmatter(content: str) -> str:
    """
    markdown의 YAML frontmatter (---\\n...\\n---\\n)를 제거하고 본문만 반환.

    Args:
        content: frontmatter 포함 가능 markdown 문자열

    Returns:
        frontmeter 제거된 본문 (앞뒤 공백 정리됨)
    """
    content = content.lstrip('\n')
    if content.startswith('---'):
        # 첫 번째 '---' 다음의 '---' 위치 찾기
        end = content.find('---', 3)
        if end != -1:
            content = content[end + 3:].lstrip('\n')
    return content


def main():
    if len(sys.argv) != 3:
        print(f"Usage: {sys.argv[0]} <input.md> <output.txt>", file=sys.stderr)
        print(f"Example: {sys.argv[0]} post.md post_content.txt", file=sys.stderr)
        sys.exit(1)

    input_path = sys.argv[1]
    output_path = sys.argv[2]

    if not os.path.exists(input_path):
        print(f"❌ Input file not found: {input_path}", file=sys.stderr)
        sys.exit(1)

    with open(input_path) as f:
        content = f.read()

    stripped = strip_frontmatter(content)

    with open(output_path, 'w') as f:
        f.write(stripped)

    orig_len = len(content)
    stripped_len = len(stripped)
    removed = orig_len - stripped_len

    print(f"✅ Frontmatter stripped: {input_path} → {output_path}")
    print(f"   Original: {orig_len} chars")
    print(f"   Stripped: {stripped_len} chars (removed {removed} chars of frontmatter)")
    print(f"   Next: tistory_publisher.py --file {output_path} ...")


if __name__ == '__main__':
    main()