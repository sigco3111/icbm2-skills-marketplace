#!/usr/bin/env python3
"""
normalize_cat_key.py — §3.29.1 stats.by_category 공백 변형 키 정규화 유틸

caller: §3.11 5단계 + §4 5-1 stats 보정 heredoc의 cat_key 박기 직전에 호출.

사용법:
    from normalize_cat_key import normalize_cat_key
    cat_key = normalize_cat_key(topic.get('category', ''))
    cur = state['stats']['by_category'].get(cat_key, 0)
    state['stats']['by_category'][cat_key] = cur + 1
"""


def normalize_cat_key(cat_input):
    """공백 변형 → 단일 정규화 키 (212차 확정).

    alias_map은 §3.29.1에서 영구 단계. 새 변형 발견 시 alias_map에 추가.
    """
    if not cat_input:
        return '기타'
    s = cat_input.strip()
    alias_map = {
        # AI/ML
        'AI/ML': 'AI/ML',
        'AI 뉴스': 'AI/ML',  # 통계 통합 (Tistory 카테고리는 'AI 뉴스' 1219746)
        'AI뉴스': 'AI/ML',
        'ai/ml': 'AI/ML',
        # 개발 팁
        '개발 팁': '개발 팁',
        '개발팁': '개발 팁',
        '개발 팁 ': '개발 팁',
        'Development Tips': '개발 팁',
        # 개발도구
        '개발도구': '개발도구',
        '개발 도구': '개발도구',
        'Dev Tools': '개발도구',
        # iOS/Swift
        'iOS/Swift': 'iOS/Swift',
        'iOS/swift': 'iOS/Swift',
        'iOS/SWIFT': 'iOS/Swift',
        'ios/swift': 'iOS/Swift',
        # 기타
        '투자&경제': '투자/경제',
        '투자/경제': '투자/경제',
        '기타': '기타',
        '아이디어': '아이디어',
    }
    return alias_map.get(s, s)


def merge_variants(state):
    """state.json의 by_category 변형 키를 정규화 키로 합산 (1회 cleanup용).

    §3.29.1 stale cleanup routine. 사용:
        state = json.load(open('...blog_pipeline_state.json'))
        merge_variants(state)
        json.dump(state, open('...blog_pipeline_state.json', 'w'), indent=2, ensure_ascii=False)
    """
    by_cat = state.get('stats', {}).get('by_category', {})
    variants = {
        'AI/ML': ['AI 뉴스', 'AI뉴스', 'ai/ml'],
        '개발 팁': ['개발팁', '개발 팁 '],
        '개발도구': ['개발 도구'],
        'iOS/Swift': ['iOS/swift', 'iOS/SWIFT', 'ios/swift'],
        '투자/경제': ['투자&경제'],
    }
    merged = {}
    for canonical, variant_list in variants.items():
        # 정규화 키의 기존 값
        canonical_val = by_cat.get(canonical, 0)
        # 변형 키들의 값 합산
        variant_sum = sum(by_cat.get(v, 0) for v in variant_list)
        # 합산 결과
        total = canonical_val + variant_sum
        if total > 0 or canonical in by_cat:
            merged[canonical] = total
        # 변형 키 제거
        for v in variant_list:
            by_cat.pop(v, None)
    # 정규화 대상이 아닌 키는 그대로 유지
    for k, v in by_cat.items():
        if k not in merged:
            merged[k] = v
    state['stats']['by_category'] = merged
    return state


if __name__ == '__main__':
    import json
    import sys

    if len(sys.argv) > 1 and sys.argv[1] == '--merge':
        # 1회 cleanup 모드
        state_path = '/Users/mac/.hermes/memory/blog_pipeline_state.json'
        state = json.load(open(state_path))
        before_keys = sorted(state.get('stats', {}).get('by_category', {}).keys())
        merge_variants(state)
        after_keys = sorted(state['stats']['by_category'].keys())
        json.dump(state, open(state_path, 'w'), indent=2, ensure_ascii=False)
        print(f'✅ by_category cleanup 완료')
        print(f'   before: {before_keys}')
        print(f'   after:  {after_keys}')
    else:
        # 사용 예시
        examples = ['AI/ML', 'AI 뉴스', 'AI뉴스', '개발 팁', '개발팁', '개발 도구', '']
        for ex in examples:
            print(f'  {ex!r:20s} → {normalize_cat_key(ex)!r}')
