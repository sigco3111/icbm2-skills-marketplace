#!/bin/bash
# rollback-fake-publish.sh
# 가짜 발행 자동 롤백 스크립트 (2026-07-06 197차 신규)
#
# 증상: §3 가짜 발행 — 통계는 +1 박혔지만 실제 Tistory 글은 안 올라감
#       이 스크립트는 (a) stats total vs last sigco URL 글 번호 격차 +
#       (b) daily_counts 최근 N일 누적 검출 후 자동 차감
#
# 사용법:
#   bash rollback-fake-publish.sh                    # 자동 검출 + 일별 롤백
#   bash rollback-fake-publish.sh --dry-run          # 차감 대상만 출력 (실제 수정 X)
#   bash rollback-fake-publish.sh --date 2026-07-06  # 특정 날짜만 롤백
#
# 디자인 노트:
#   - §3 가짜 발행 판정: details 박힌 sigco URL 번호 vs stats.total_published 격차
#   - 단, 188차 정정: stats total - sigco URL 카운트 격차만으로는 false positive
#   - 이 스크립트는 **details에 박힌 sigco URL의 최대 번호** vs **stats.total_published**를 비교
#     → 격차만큼 가짜 발행으로 간주하고 daily_counts부터 차감 (최신 날짜순)

set -e

STATE=/Users/mac/.hermes/memory/blog_pipeline_state.json
TOPICS=/Users/mac/.hermes/memory/published_topics.json

echo "═══════════════════════════════════════════════════════"
echo "  가짜 발행 자동 롤백 (197차 신규)"
echo "═══════════════════════════════════════════════════════"

# unknown flag 가드 (197차 보강 — 검증 §6에서 발견)
case "$1" in
    ""|--dry-run|--date)
        : ;;
    -*)
        echo "❌ 알 수 없는 플래그: $1"
        echo "사용법: $0 [--dry-run|--date YYYY-MM-DD]"
        exit 2
        ;;
esac

# (1) JSON 로드
LAST_SIGCO=$(python3 -c "
import json
pt = json.loads(open('$TOPICS').read())
urls = [d.get('url','') for d in pt.get('details',[]) if 'sigco.tistory.com' in d.get('url','')]
nums = [int(u.rsplit('/', 1)[-1]) for u in urls]
print(max(nums) if nums else 0)
")

TOTAL_PUB=$(python3 -c "
import json
s = json.loads(open('$STATE').read())
print(s['stats']['total_published'])
")

GAP=$((TOTAL_PUB - LAST_SIGCO))

echo ""
echo "details의 마지막 sigco URL 글 번호: #$LAST_SIGCO"
echo "stats.total_published:              $TOTAL_PUB"
echo "격차 (= 가짜 발행 누적 추정):         $GAP"

if [ "$GAP" -le 0 ]; then
    echo ""
    echo "✅ 격차 0 또는 음수 — 가짜 발행 없음. 종료."
    exit 0
fi

if [ "$1" = "--dry-run" ]; then
    echo ""
    echo "(dry-run) 롤백 대상 daily_counts 최근 7일:"
    python3 -c "
import json
s = json.loads(open('$STATE').read())
for d in sorted(s.get('daily_counts',{}).keys())[-7:]:
    print(' ', d, ':', s['daily_counts'].get(d, {}))
"
    exit 0
fi

# (2) 백업
TS=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="$HOME/.hermes/migration_fix_backup_${TS}_blog_rollback"
mkdir -p "$BACKUP_DIR"
cp "$STATE" "$BACKUP_DIR/blog_pipeline_state.json.bak"
cp "$TOPICS" "$BACKUP_DIR/published_topics.json.bak"
echo ""
echo "✅ 백업: $BACKUP_DIR"

# (3) 격차만큼 daily_counts 최근 일자부터 차감
echo ""
echo "롤백 실행 중 (격차 = $GAP)..."
python3 << PYEOF
import json
from datetime import datetime, timedelta

state = json.loads(open('$STATE').read())
state_orig = json.loads(open('$STATE').read())

# 격차
gap = $GAP

# daily_counts 오늘 + 어제부터 차감 (가짜 발행이 최근에 집중된 패턴)
target_dates = sorted(state.get('daily_counts', {}).keys(), reverse=True)
rollback_log = []

remaining = gap
for date_key in target_dates:
    if remaining <= 0:
        break
    counts = state['daily_counts'].get(date_key, {})
    date_total = sum(counts.values())
    if date_total == 0:
        continue
    if date_total <= remaining:
        # 전액 차감
        rollback_log.append((date_key, dict(counts)))
        remaining -= date_total
        state['daily_counts'][date_key] = {k: 0 for k in counts}
    else:
        # 부분 차감
        rollback_log.append((date_key, dict(counts)))
        per_cat = {}
        # 비율로 분배
        for cat, n in counts.items():
            take = min(n, (n * remaining) // date_total) if date_total > 0 else 0
            if take > 0:
                per_cat[cat] = take
                state['daily_counts'][date_key][cat] = max(0, n - take)
        # 나머지는 가장 큰 카테고리에서
        leftover = remaining - sum(per_cat.values())
        if leftover > 0 and counts:
            big_cat = max(counts, key=counts.get)
            state['daily_counts'][date_key][big_cat] = max(0, state['daily_counts'][date_key].get(big_cat, 0) - leftover)
            per_cat[big_cat] = per_cat.get(big_cat, 0) + leftover
        remaining = 0

# stats.total_published 차감
total_rolled = $GAP - remaining
state['stats']['total_published'] = max(0, state['stats']['total_published'] - total_rolled)

# by_category 차감
for date_key, cats in rollback_log:
    for cat, n in cats.items():
        cur = state['stats'].get('by_category', {}).get(cat, 0)
        if cur > 0:
            state['stats']['by_category'][cat] = max(0, cur - (n - state['daily_counts'][date_key].get(cat, 0)))

with open('$STATE', 'w') as f:
    json.dump(state, f, ensure_ascii=False, indent=2)

print()
print("롤백 결과:")
print(f"  차감: {total_rolled}건")
print(f"  stats.total_published: $TOTAL_PUB → {state['stats']['total_published']}")
for date_key, cats in rollback_log:
    print(f"  {date_key}: {cats} → {state['daily_counts'][date_key]}")

print()
print("✅ 롤백 완료")
PYEOF

echo ""
echo "═══════════════════════════════════════════════════════"
echo "  검증: status 재확인"
echo "═══════════════════════════════════════════════════════"
python3 ~/.hermes/scripts/blog_pipeline.py --status 2>&1 | grep -v NotOpenSSL | head -15
