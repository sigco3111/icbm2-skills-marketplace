#!/usr/bin/env python3
"""
rollback-fake-publish.py
블로그 파이프라인 "가짜 발행" 롤백 표준 스크립트 (182차 신규, 2026-06-26).

증상: blog_pipeline.py 실행 시 guidline까지 출력하고 통계는 박혔는데
Tistory URL은 안 박힌 케이스. 5분 안에 깨끗하게 롤백.

Usage:
    # 1) 가짜 발행 N건 직접 차감 (대화형)
    python3 rollback-fake-publish.py --category 'AI/ML' --count 3 --today 2026-06-26

    # 2) 자동 감지 (통계 today - published_topics last.date URL 차이로 N 산출)
    python3 rollback-fake-publish.py --auto

    # 3) Dry-run (차감 없이 변경 사항만 출력)
    python3 rollback-fake-publish.py --auto --dry-run

환경: ~/.hermes/memory/blog_pipeline_state.json 직접 수정.
백업: migration_fix_backup_${TS}_blog_rollback/blog_pipeline_state.json.bak
"""
import argparse
import json
import shutil
import sys
from datetime import datetime, timezone, timedelta
from pathlib import Path

KST = timezone(timedelta(hours=9))
HERMES_DIR = Path("~/.hermes").expanduser()
STATE_FILE = HERMES_DIR / "memory" / "blog_pipeline_state.json"
PUBLISHED_URLS = HERMES_DIR / "memory" / "published_urls.txt"
PUBLISHED_TOPICS = HERMES_DIR / "memory" / "published_topics.json"


def now_kst() -> str:
    return datetime.now(KST).strftime("%Y%m%d_%H%M%S")


def detect_fake_count(category: str, today: str) -> int:
    """자동 감지: 통계 today - 실제 URL 카운트 = 가짜 발행 수."""
    if not STATE_FILE.exists():
        return 0
    state = json.loads(STATE_FILE.read_text(encoding="utf-8"))
    stat_count = state.get("daily_counts", {}).get(today, {}).get(category, 0)

    # published_topics.json의 details 중 today + category 추측 (URL 있는 것만)
    real_count = 0
    if PUBLISHED_TOPICS.exists():
        pt = json.loads(PUBLISHED_TOPICS.read_text(encoding="utf-8"))
        for d in pt.get("details", []):
            date = d.get("date", "")
            if date.startswith(today) and d.get("url", "").startswith("https://sigco.tistory.com/"):
                real_count += 1

    fake = max(0, stat_count - real_count)
    return fake


def find_failed_topics(state: dict, category: str, today: str, n: int) -> list:
    """state.last_topics에서 오늘 + 카테고리 매칭되는 마지막 N개 topic."""
    candidates = [
        t for t in state.get("last_topics", [])
        if t.get("timestamp", "").startswith(today) and t.get("category") == category
    ]
    return [c["topic"] for c in candidates[-n:]]


def rollback(category: str, count: int, today: str, dry_run: bool = False) -> int:
    if not STATE_FILE.exists():
        print(f"❌ {STATE_FILE} 없음")
        return 1

    state = json.loads(STATE_FILE.read_text(encoding="utf-8"))

    # N 검증
    actual_today = state.get("daily_counts", {}).get(today, {}).get(category, 0)
    if count > actual_today:
        print(f"⚠️ 요청 {count}건 > 통계 today {actual_today}건. {actual_today}건으로 제한.")
        count = actual_today
    if count <= 0:
        print("✅ 롤백할 가짜 발행 0건. 종료.")
        return 0

    failed_topics = find_failed_topics(state, category, today, count)

    print(f"=== 롤백 예정 ({count}건) ===")
    for t in failed_topics:
        print(f"  - {t}")
    print(f"=== 카테고리: {category} / 날짜: {today} ===")

    if dry_run:
        print("\n[dry-run] 실제 변경 없음. 위 {0}건 차감 예정.".format(count))
        return 0

    # 1) 백업
    ts = now_kst()
    backup_dir = HERMES_DIR / f"migration_fix_backup_{ts}_blog_rollback"
    backup_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(STATE_FILE, backup_dir / "blog_pipeline_state.json.bak")
    print(f"\n✅ 백업: {backup_dir}/blog_pipeline_state.json.bak")

    # 2) 4개 필드 동시 차감
    before_lt = len(state["last_topics"])
    state["last_topics"] = [t for t in state["last_topics"] if t["topic"] not in failed_topics]
    state["daily_counts"].setdefault(today, {})
    state["daily_counts"][today][category] = max(0, state["daily_counts"][today].get(category, 0) - count)
    state["stats"]["total_published"] -= count
    state["stats"]["by_category"][category] -= count

    STATE_FILE.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"✅ last_topics: {before_lt} → {len(state['last_topics'])}건 ({count}건 제거)")
    print(f"✅ daily_counts['{today}']['{category}']: {actual_today} → {state['daily_counts'][today][category]}")
    print(f"✅ stats.total_published: -{count}")
    print(f"✅ stats.by_category['{category}']: -{count}")

    # 3) 다른 파일 오염 확인
    print(f"\n=== 다른 파일 '15:12' 흔적 확인 ===")
    for f in [PUBLISHED_TOPICS, PUBLISHED_URLS,
              HERMES_DIR / "memory" / "blog_seo_history.json",
              HERMES_DIR / "memory" / "blog_quality_history.json"]:
        if not f.exists():
            continue
        try:
            content = f.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            content = f.read_text(encoding="utf-8", errors="ignore")
        n = content.count("15:12")
        status = "✅ 깨끗" if n == 0 else f"⚠️ {n}건"
        print(f"  {f.name}: {status}")

    return 0


def main():
    p = argparse.ArgumentParser(description="블로그 가짜 발행 롤백")
    p.add_argument("--auto", action="store_true", help="통계 vs URL 차이로 자동 감지")
    p.add_argument("--category", default="AI/ML", help="카테고리 (기본: AI/ML)")
    p.add_argument("--count", type=int, default=0, help="롤백할 가짜 발행 건수")
    p.add_argument("--today", default=datetime.now(KST).strftime("%Y-%m-%d"), help="날짜 (YYYY-MM-DD)")
    p.add_argument("--dry-run", action="store_true", help="실제 변경 없이 미리보기")
    args = p.parse_args()

    if args.auto:
        n = detect_fake_count(args.category, args.today)
        print(f"[auto] 가짜 발행 감지: {n}건 ({args.category} / {args.today})")
        if n == 0:
            print("✅ 가짜 발행 0건. 종료.")
            return 0
        return rollback(args.category, n, args.today, dry_run=args.dry_run)
    else:
        if args.count <= 0:
            print("❌ --count N 또는 --auto 필요")
            return 1
        return rollback(args.category, args.count, args.today, dry_run=args.dry_run)


if __name__ == "__main__":
    sys.exit(main())
