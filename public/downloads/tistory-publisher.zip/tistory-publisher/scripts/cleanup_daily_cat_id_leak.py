#!/usr/bin/env python3
"""cleanup-daily-cat-id-leak.py — §3.34.33 cleanup cron 임무 #16 (238차+ 영구화)

state['daily_counts'][date]에 cat_id (정수 Tistory ID 문자열)가 누설되어 박힌 케이스를
자동 검출·삭제·한글 key로 +1 합산. cron_cleanup 또는 cron publish 후에 1회 실행.

Usage:
    python3 cleanup_daily_cat_id_leak.py                # 오늘자만 검사
    python3 cleanup_daily_cat_id_leak.py --date 2026-07-10
    python3 cleanup_daily_cat_id_leak.py --all          # 모든 날짜 검사
    python3 cleanup_daily_cat_id_leak.py --dry-run      # 변경 없이 출력만

Exit codes:
    0 = clean (누설 없음)
    1 = 수정 발생
    2 = 에러
"""

import argparse
import json
import sys
from pathlib import Path

STATE_FILE = Path.home() / ".hermes" / "memory" / "blog_pipeline_state.json"

# Tistory int ID 들 — 누설 시 자동 합산 대상
KNOWN_CAT_IDS = {"1219746", "1219747", "1219748", "1219750", "1219751", "1219752"}
# tistory_publisher 의 category_id ↔ 한글 key 매핑
KOREAN_CAT_BY_ID = {
    "1219746": "AI/ML",
    "1219747": "개발 팁",
    "1219748": "자동화&툴 리뷰",
    "1219750": "투자&경제",
    "1219752": "아이디어",
    "1219751": "기타",
}


def cleanup_for_date(state, date_key, dry_run=False):
    daily = state.get("daily_counts", {})
    day_entry = daily.get(date_key)
    if not isinstance(day_entry, dict):
        return False, ""

    leaked_ids = [k for k in list(day_entry.keys()) if str(k) in KNOWN_CAT_IDS]
    if not leaked_ids:
        return False, ""

    lines = []
    for cat_id in leaked_ids:
        val = day_entry.get(cat_id, 0)
        korean = KOREAN_CAT_BY_ID.get(cat_id, "?")
        del day_entry[cat_id]
        day_entry[korean] = day_entry.get(korean, 0) + val
        lines.append(f"{date_key}: cat_id {cat_id} ({val}건) → {korean}에 합산")

    if not dry_run:
        daily[date_key] = day_entry

    return True, "\n".join(lines)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--date", help="YYYY-MM-DD 특정일자만 검사")
    p.add_argument("--all", action="store_true", help="모든 날짜 검사")
    p.add_argument("--dry-run", action="store_true", help="실제 변경 없이 출력만")
    args = p.parse_args()

    if not STATE_FILE.exists():
        print(f"❌ state 파일 없음: {STATE_FILE}", file=sys.stderr)
        return 2

    state = json.loads(STATE_FILE.read_text())

    if args.date:
        dates = [args.date]
    elif args.all:
        dates = list(state.get("daily_counts", {}).keys())
    else:
        from datetime import datetime, timezone, timedelta
        kst = timezone(timedelta(hours=9))
        dates = [datetime.now(kst).strftime("%Y-%m-%d")]

    any_change = False
    for d in dates:
        changed, msg = cleanup_for_date(state, d, dry_run=args.dry_run)
        if changed:
            any_change = True
            print(f"🧹 {msg}")

    if any_change and not args.dry_run:
        STATE_FILE.write_text(json.dumps(state, ensure_ascii=False, indent=2))
        print(f"✅ state 파일 저장: {STATE_FILE}")
    elif not any_change:
        print(f"✅ 누설 없음 (검사: {dates})")
    else:
        print("[dry-run] 변경사항 있음. --dry-run 제거 후 재실행.")

    return 1 if any_change else 0


if __name__ == "__main__":
    sys.exit(main())
