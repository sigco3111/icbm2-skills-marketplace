#!/usr/bin/env python3
"""
§3.23.1 / §3.24.3 frontmatter strip — 207차 영구 패턴

Usage:
    python3 strip-frontmatter.py <input.md> <output.txt>

기존 `scripts/strip-frontmatter.py` 가 이미 존재하므로 이 스크립트는 207차 패턴을
별도 영구화 단계로 고정. half-pipeline §3.18 4단계 직전에 호출.
"""
import sys

src = sys.argv[1]
dst = sys.argv[2]

with open(src) as f:
    content = f.read()

if content.startswith('---'):
    end = content.find('---', 3)
    content = content[end+3:].lstrip('\n')

with open(dst, 'w') as f:
    f.write(content)

print(f'✅ Stripped to {dst}, length={len(content)} chars')

# 검증: 300자 미만이면 거절됨 (Tistory content 검증)
if len(content) < 300:
    print(f'⚠️  WARNING: content {len(content)}자 < 300자 한계 → Tistory 거절 가능')
    sys.exit(1)
