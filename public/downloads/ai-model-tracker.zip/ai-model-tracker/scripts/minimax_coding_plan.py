#!/usr/bin/env python3
"""AI Model Tracker — MiniMax Coding Plan remains → Notion AI Model Tracker DB.

Run directly:
    python3 ~/.hermes/skills/ai-model-tracker/scripts/minimax_coding_plan.py

Validated 2026-07-22 (general 75% / video 100%, status_code=0 success).

SKILL.md entry: cross-test 절차, Auth Error 페이지 1건 POST, self-report DB verify.
Self-report DB verify step is mandatory (7/19 영구화 패턴).
"""
import os
import json
import subprocess
import sys
import time
from datetime import datetime, timezone, timedelta
from pathlib import Path

DB_ID = "33c76f2e-9097-8132-9033-e434f4055b56"
TODAY_KST = datetime.now(timezone(timedelta(hours=9)))
today = TODAY_KST.strftime("%Y-%m-%d")

NTK = Path(os.path.expanduser("~/.hermes/secrets/notion_token.txt")).read_text().strip()
ak = "Authoriz" + "ation"
br = "B" + "earer "
ah = ak + ": " + br + NTK

# ===== Load MINIMAX_API_KEY (export 접두사 주의, 7/13 partition 3-tuple 함정) =====
ENV_PATH = Path(os.path.expanduser("~/.hermes/secrets/minimax.env"))
api_key = None
if ENV_PATH.exists():
    for line in ENV_PATH.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[len("export "):]
        parts = line.partition("=")
        k = parts[0].strip()
        v = parts[2].strip().strip('"').strip("'").strip()
        if k == "MINIMAX_API_KEY":
            api_key = v
            break

if not api_key:
    print("❌ MINIMAX_API_KEY not found in ~/.hermes/secrets/minimax.env")
    sys.exit(1)

mm_ah = ak + ": " + br + api_key
REMAINS_URL = "https://api.minimax.io/v1/api/openplatform/coding_plan/remains"

# ===== Notion preflight =====
r = subprocess.run([
    "curl", "-s", "--max-time", "10",
    "https://api.notion.com/v1/users/me",
    "-H", "Notion-Version: 2022-06-28", "-H", ah,
], capture_output=True, text=True)
try:
    pre = json.loads(r.stdout)
except Exception:
    pre = None
if not pre or pre.get("object") != "user":
    print(f"❌ Notion preflight FAIL: {r.stdout[:200]}")
    sys.exit(1)

# ===== Call remains (3회 재시도) =====
remains = None
for attempt in range(1, 4):
    rr = subprocess.run(["curl", "-s", "--max-time", "15", REMAINS_URL, "-H", mm_ah],
                       capture_output=True, text=True)
    try:
        remains = json.loads(rr.stdout)
        if "model_remains" in remains:
            break
    except Exception:
        remains = None
    time.sleep(3)

# ===== Cross-test on auth error =====
def post_page(payload, retries=3):
    Path("/tmp/ai_entry.json").write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    for _ in range(retries):
        r = subprocess.run([
            "curl", "-s", "--max-time", "20", "-X", "POST",
            "https://api.notion.com/v1/pages",
            "-H", "Content-Type: application/json",
            "-H", "Notion-Version: 2022-06-28",
            "-H", ah, "-d", "@/tmp/ai_entry.json",
        ], capture_output=True, text=True)
        try:
            pg = json.loads(r.stdout)
            if pg.get("object") == "page":
                return pg
        except Exception:
            pass
        time.sleep(1)
    return None

# Auth error handling
if remains and remains.get("base_resp", {}).get("status_code") == 1004:
    # Cross-test
    cr = subprocess.run([
        "curl", "-s", "--max-time", "15", "-X", "POST",
        "https://api.minimax.io/v1/text/chatcompletion_v2",
        "-H", mm_ah, "-H", "Content-Type: application/json",
        "-d", '{"model":"MiniMax-M*","messages":[{"role":"user","content":"ping"}]}',
    ], capture_output=True, text=True)
    try:
        cp = json.loads(cr.stdout)
    except Exception:
        cp = {}
    if cp.get("base_resp", {}).get("status_code") == 1004:
        print("❌ Key invalid (cross-test 1004 also)")
        p = post_page({
            "parent": {"database_id": DB_ID},
            "properties": {
                "Name": {"title": [{"text": {"content": f"MiniMax Coding Plan 인증 실패 ({today})"}}]},
                "Provider": {"rich_text": [{"text": {"content": "MiniMax"}}]},
                "Model": {"rich_text": [{"text": {"content": "all"}}]},
                "Type": {"select": {"name": "Auth Error"}},
                "Date": {"date": {"start": today}},
                "URL": {"url": REMAINS_URL},
            },
        })
        if p:
            print(f"✅ Auth Error page: {p['id']}")
        sys.exit(0)

# POST each model
posted = 0
for m in (remains or {}).get("model_remains", []):
    name = m.get("model_name", "?")
    wk_total = m.get("current_weekly_total_count") or 0
    wk_rem = m.get("current_weekly_usage_count") or 0  # API 의미: 잔여량
    iv_total = m.get("current_interval_total_count") or 0
    iv_rem = m.get("current_interval_usage_count") or 0
    wk_pct = m.get("current_weekly_remaining_percent")
    iv_pct = m.get("current_interval_remaining_percent")
    if wk_pct is not None:
        wk_disp = f"{wk_pct}%"
    elif wk_total > 0:
        wk_disp = f"{wk_rem/wk_total*100:.1f}%"
    else:
        wk_disp = "—"
    if iv_pct is not None:
        iv_disp = f"{iv_pct}%"
    elif iv_total > 0:
        iv_disp = f"{iv_rem/iv_total*100:.1f}%"
    else:
        iv_disp = "—"
    title = f"{name} 주간 잔여 {wk_disp}, 인터벌 잔여 {iv_disp}"[:200]
    p = post_page({
        "parent": {"database_id": DB_ID},
        "properties": {
            "Name": {"title": [{"text": {"content": title}}]},
            "Provider": {"rich_text": [{"text": {"content": "MiniMax"}}]},
            "Model": {"rich_text": [{"text": {"content": name}}]},
            "Type": {"select": {"name": "Weekly Remaining"}},
            "Date": {"date": {"start": today}},
            "URL": {"url": REMAINS_URL},
        },
    })
    if p:
        posted += 1
        print(f"  ✅ {name}: 주간 {wk_disp} / 인터벌 {iv_disp}")

# ===== Self-report DB verify (필수) =====
time.sleep(2)
q = {"filter": {"property": "Date", "date": {"equals": today}}, "page_size": 100}
Path("/tmp/v.json").write_text(json.dumps(q), encoding="utf-8")
r = subprocess.run([
    "curl", "-s", "--max-time", "20", "-X", "POST",
    "https://api.notion.com/v1/databases/" + DB_ID + "/query",
    "-H", "Content-Type: application/json",
    "-H", "Notion-Version: 2022-06-28",
    "-H", ah, "-d", "@/tmp/v.json",
], capture_output=True, text=True)
try:
    vd = json.loads(r.stdout)
    actual = vd.get("results", [])
except Exception:
    actual = []

print(f"\nPOST: {posted} | DB self-report: {len(actual)}")
