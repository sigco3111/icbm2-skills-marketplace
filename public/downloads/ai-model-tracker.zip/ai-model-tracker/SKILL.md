---
name: ai-model-tracker
description: 미니맥스/ NVIDIA NIM 등 AI 모델 API 사용량을 체크하고 Notion에 기록합니다. 그룹 멤버십 잔여량, 모델별 사용량 추적, 임계치 경고가 필요할 때 사용합니다.
---

# AI Model Usage Tracker

미니맥스/ NVIDIA NIM API 사용량을 체크하고 Notion에 기록합니다.

## 사용량 조회 API

### 미니맥스 코딩 플랜 잔여량

```bash
curl -s "https://api.minimax.io/v1/api/openplatform/coding_plan/remains" \
  -H "Authorization: Bearer $MINIMAX_API_KEY"
```

**실제 응답 구조 (snake_case):**
```json
{
  "model_remains": [
    {
      "start_time": 1777284000000,
      "end_time": 1777302000000,
      "remains_time": 12660048,
      "current_interval_total_count": 4500,
      "current_interval_usage_count": 4222,
      "model_name": "MiniMax-M*",
      "current_weekly_total_count": 45000,
      "current_weekly_usage_count": 43786,
      "weekly_start_time": 1777248000000,
      "weekly_end_time": 1777852800000,
      "weekly_remains_time": 563460048
    }
  ],
  "base_resp": { "status_code": 0, "status_msg": "success" }
}
```

**⚠️ 중요: usage_count = 잔여량! (실제 사용 아님)**

**필드 설명 (실제 API 기준):**
- `model_name`: 모델명 (MiniMax-M*, speech-hd, coding-plan-vlm 등)
- `start_time`/`end_time`: Interval 윈도우 기간 (Unix ms)
- `remains_time`: Interval 잔여 시간 (ms)
- `current_interval_total_count`: Interval 할당량
- `current_interval_usage_count`: **Interval 잔여량** (실제 사용 아님)
- `current_weekly_total_count`: 주간 할당량
- `current_weekly_usage_count`: **주간 잔여량** (실제 사용 아님)
- `weekly_start_time`/`weekly_end_time`: 주간 윈도우 (Unix ms)
- `weekly_remains_time`: 주간 잔여 시간 (ms, 전체 모델 통합)

**실제 사용량 = total_count - usage_count**

## 사용량 계산 (Python)

```python
import json
from datetime import datetime

data = json.load(open("response.json"))

for m in data["model_remains"]:
    name = m["model_name"]
    start = m["start_time"]
    end = m["end_time"]
    remains_time = m["remains_time"]
    interval_total = m["current_interval_total_count"]
    interval_usage = m["current_interval_usage_count"]
    weekly_total = m["current_weekly_total_count"]
    weekly_usage = m["current_weekly_usage_count"]

    # === 시간 기반 (Interval Window 기준) ===
    window_ms = end - start
    window_h = window_ms / 3600000
    used_time_ms = window_ms - remains_time
    time_usage_pct = used_time_ms / window_ms * 100 if window_ms > 0 else 0

    # === 요청 수 기반 (usage_count = 잔여량!) ===
    interval_remaining = interval_usage  # interval_usage가 실제로는 잔여량
    weekly_remaining = weekly_usage     # weekly_usage가 실제로는 잔여량
    interval_used = interval_total - interval_usage    # 실제 사용량
    weekly_used = weekly_total - weekly_usage          # 실제 사용량

    print(f"=== {name} ===")
    print(f"  Interval: 할당={interval_total}, 잔여={interval_remaining}, 사용={interval_used}")
    print(f"  Weekly: 할당={weekly_total}, 잔여={weekly_remaining}, 사용={weekly_used}")
    print(f"  Interval Window: {window_h:.1f}h ({datetime.fromtimestamp(start/1000)} ~ {datetime.fromtimestamp(end/1000)})")
    print(f"  시간 사용률: {time_usage_pct:.1f}%")
```

## ⚠️ 중요: Interval vs Weekly 구분

**Interval quota**: 짧은 윈도우 (5시간 또는 24시간) 내 요청 수 제한
**Weekly quota**: 주간 총 요청 수 제한

예시:
- `MiniMax-M*`: Interval 4,500회 (5시간), Weekly 45,000회
- `speech-hd`: Interval 4,000회 (24시간), Weekly 28,000회

**잔여량 = min(interval_remaining, weekly_remaining)** 가 아닌, **각각 독립적으로 해석**

## Notion에 사용량 기록

**Notion DB:** `33f76f2e-9097-8116-a225-c0c23f1a8a9d` (성과 대시보드)

**기록 속성:**
- `날짜`: date (오늘)
- `카테고리`: select ("AI Model")
- `지표명`: select (모델명)
- `값`: number (잔여 시간, ms)
- `단위`: select ("ms")

```bash
NOTION_API_KEY=$(cat ~/.hermes/secrets/notion_token.txt)

# 잔여 시간 레코드 생성
curl -s -X POST "https://api.notion.com/v1/pages" \
  -H "Authorization: Bearer $NOTION_API_KEY" \
  -H "Notion-Version: 2025-09-03" \
  -H "Content-Type: application/json" \
  -d "{
    \"parent\": {\"database_id\": \"33f76f2e-9097-8116-a225-c0c23f1a8a9d\"},
    \"properties\": {
      \"날짜\": {\"date\": {\"start\": \"$(date +%Y-%m-%d)\"}},
      \"카테고리\": {\"select\": {\"name\": \"AI Model\"}},
      \"지표명\": {\"select\": {\"name\": \"$MODEL_NAME\"}},
      \"값\": {\"number\": $REM_TIME},
      \"단위\": {\"select\": {\"name\": \"ms\"}}
    }
  }"
```

## 사용량 체크 & 경고 로직

```bash
# 임계치 경고 (잔여 15% 이하)
WARN_THRESHOLD=0.15
CRITICAL_THRESHOLD=0.05

usage_pct=$(echo "scale=3; ($endTime - $startTime - $remainsTime) / ($endTime - $startTime)" | bc)

if [ "$(echo "$usage_pct >= 0.95" | bc)" -eq 1 ]; then
  echo "🚨 [$MODEL_NAME] 사용량 $usage_pct% - 위험!"
elif [ "$(echo "$usage_pct >= 0.85" | bc)" -eq 1 ]; then
  echo "⚠️ [$MODEL_NAME] 사용량 $usage_pct% - 주의"
fi
```

## 주요 모델 목록

- MiniMax-M2.7
- MiniMax-M2.7-highspeed
- MiniMax-M2.5
- MiniMax-M2.5-highspeed
- MiniMax-M2.1
- MiniMax-M2.1-highspeed
- MiniMax-M2

## 시크릿 파일

- 미니맥스 API Key: `~/.hermes/secrets/minimax.env` (export MINIMAX_API_KEY=...)
- Notion Token: `~/.hermes/secrets/notion_token.txt`

## 참고 자료

자세한 API 응답 필드와 에러 코드는 `references/usage-api.md`를 참조하세요.
