---
name: ai-model-tracker
description: AI 모델 릴리즈/업데이트를 매일 Notion에 기록 — 새 모델 출시, 벤치마크, 가격 변동 추적
version: 1.0.0
author: icbm2
metadata:
  hermes:
    tags: [AI, Model, Tracker, Notion, Daily]
prerequisites:
  secret_files: [notion_idea_token.txt]
---

# AI 모델 트래커

매일 AI 모델 관련 주요 소식을 Notion DB에 기록합니다.

## Notion DB

- **DB ID:** `33c76f2e-9097-8132-9033-e434f4055b56`
- **DB명:** AI Model Tracker
- **속성:** Name(title), Date(date), Model(rich_text), Provider(rich_text), Type(select), URL(url)
- **Type 옵션:** Language, Image, Code, Audio, Multimodal, Other

## 실행 단계

### 1. 뉴스 수집

다음 소스에서 당일 AI 모델 관련 소식 수집:

- HN: AI/ML 관련 글
- Reddit: r/MachineLearning, r/LocalLLaMA
- 모델 제공사 공지: OpenAI, Anthropic, Google, Meta, Mistral 등
- HuggingFace: 인기 모델 업데이트

### 2. Notion에 기록

```python
import os, json, subprocess
from datetime import datetime, timezone, timedelta

TK_PATH = os.path.expanduser("~/.hermes/secrets/notion_idea_token.txt")
DB_ID = "33c76f2e-9097-8132-9033-e434f4055b56"
today = datetime.now(timezone(timedelta(hours=9))).strftime("%Y-%m-%d")

with open(TK_PATH) as f:
    tk = f.read().strip()

payload = {
    "parent": {"database_id": DB_ID},
    "properties": {
        "Name": {"title": [{"text": {"content": "GPT-5 Released"}}]},
        "Date": {"date": {"start": today}},
        "Model": {"rich_text": [{"text": {"content": "GPT-5"}}]},
        "Provider": {"rich_text": [{"text": {"content": "OpenAI"}}]},
        "Type": {"select": {"name": "Language"}},
        "URL": {"url": "https://..."}
    }
}
with open("/tmp/notion_entry.json", "w") as f:
    json.dump(payload, f, ensure_ascii=False)

env = dict(os.environ)
env["NTK"] = tk
r = subprocess.run(
    f'curl -s -X POST --max-time 15 https://api.notion.com/v1/pages -H "Authorization: Bearer $NTK" -H "Notion-Version: 2022-06-28" -H "Content-Type: application/json" -d @/tmp/notion_entry.json',
    shell=True, capture_output=True, text=True, env=env
)
```

### 3. 품질 기준

- **최소 3개, 최대 7개** 항목 기록
- 새 모델 출시, 주요 업데이트, 벤치마크 결과, 가격 변동 포함
- Model/Provider 속성은 반드시 기입
- 각 항목에 1-2문장 요약을 페이지 본문에 추가
- **URL 속성은 항상 기록** (공식 발표, 문서, HuggingFace, GitHub 등 반드시 링크 포함)
- 한국어로 작성

### 4. 완료 확인

기록된 항목 수를 출력.
