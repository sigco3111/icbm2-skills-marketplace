# MiniMax Image Generation API (image-01)

## Endpoint

```
POST https://api.minimax.io/v1/image_generation
```

## Request

```json
{
  "model": "image-01",
  "prompt": "A man in a white t-shirt, full-body, standing front view, outdoors, with the Venice Beach sign in the background, Los Angeles. Fashion photography in 90s documentary style, film grain, photorealistic.",
  "aspect_ratio": "16:9",
  "response_format": "url",
  "n": 3,
  "prompt_optimizer": true
}
```

## Parameters

| 파라미터 | 타입 | 필수 | 기본값 | 설명 |
|---------|------|------|--------|------|
| `model` | enum | ✅ | - | `image-01` 고정 |
| `prompt` | string | ✅ | - | 이미지 설명 (최대 1500자) |
| `aspect_ratio` | enum | ❌ | `1:1` | 가로세로비 |
| `width` | int | ❌ | - | px [512, 2048], 8로 나누어져야 함 |
| `height` | int | ❌ | - | px [512, 2048], 8로 나누어져야 함 |
| `response_format` | enum | ❌ | `url` | `url` 또는 `base64` |
| `seed` | int64 | ❌ | random | 재현성 시드 |
| `n` | int | ❌ | 1 | 생성 이미지 수 (1~9) |
| `prompt_optimizer` | bool | ❌ | false | 프롬프트 자동 최적화 |

## aspect_ratio options

- `1:1` (1024x1024)
- `16:9` (1280x720)
- `4:3` (1152x864)
- `3:2` (1248x832)
- `2:3` (832x1248)
- `3:4` (864x1152)
- `9:16` (720x1280)
- `21:9` (1344x576)

## Response

```json
{
  "id": "03ff3cd0820949eb8a410056b5f21d38",
  "data": {
    "image_urls": ["URL1", "URL2", "URL3"]
  },
  "metadata": {
    "failed_count": "0",
    "success_count": "3"
  },
  "base_resp": {
    "status_code": 0,
    "status_msg": "success"
  }
}
```

⚠️ **URL 만료:** 반환된 URL은 24시간 후에 만료됩니다. 필요시 `base64`로 받거나 즉시 다운로드하세요.

## 에러 코드

| status_code | 의미 |
|-------------|------|
| 0 | 성공 |
| 10001 | 파라미터 에러 |
| 10002 | 인증 실패 |
| 10003 | 권한 없음 |
| 20000 | 서버 에러 |

## 사용량 (2026-05-19 기준)

- Interval: 50/50 (100% 잔여)
- Weekly: 350/350 (100% 잔여)

## 참고

MCP 도구 `mcp_minimax_understand_image`는 이미지 **이해/분석**만 가능.
이미지 **생성**은 이 REST API를 직접 호출해야 합니다.