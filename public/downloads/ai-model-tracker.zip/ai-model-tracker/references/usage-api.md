# 미니맥스 API 사용량 상세 가이드

## 코딩 플랜 잔여량 API

**Endpoint:**
```
GET https://api.minimax.io/v1/api/openplatform/coding_plan/remains
```

**Headers:**
```
Authorization: Bearer {MINIMAX_API_KEY}
Content-Type: application/json
```

## 전체 응답 구조

```json
{
  "model_remains": [
    {
      "model_name": "MiniMax-M*",
      "start_time": 1777284000000,
      "end_time": 1777302000000,
      "remains_time": 12660048,
      "current_interval_total_count": 4500,
      "current_interval_usage_count": 4209,
      "current_weekly_total_count": 45000,
      "current_weekly_usage_count": 43773,
      "weekly_start_time": 1777248000000,
      "weekly_end_time": 1777852800000,
      "weekly_remains_time": 563460048
    }
  ],
  "base_resp": {
    "status_code": 0,
    "status_msg": "success"
  }
}
```

## ⚠️ 핵심: usage_count = 잔여량 (실제 사용 아님!)

API 설계상 `usage_count`가 **잔여량**을 의미합니다. 실제 사용량은 `total_count - usage_count`로 계산해야 합니다.

## 필드 상세

| 필드 | 타입 | 설명 |
|------|------|------|
| `model_name` | string | 모델 이름 |
| `start_time` | int64 | Interval 윈도우 시작 (Unix ms) |
| `end_time` | int64 | Interval 윈도우 종료 (Unix ms) |
| `remains_time` | int64 | 잔여 시간 (ms) |
| `current_interval_total_count` | int | Interval 할당량 |
| `current_interval_usage_count` | int | **Interval 잔여량** (실제 사용 아님) |
| `current_weekly_total_count` | int | 주간 할당량 |
| `current_weekly_usage_count` | int | **주간 잔여량** (실제 사용 아님) |
| `weekly_start_time` | int64 | 주간 윈도우 시작 |
| `weekly_end_time` | int64 | 주간 윈도우 종료 |
| `weekly_remains_time` | int64 | 주간 잔여 시간 (ms) |

## 사용량 계산 공식

```python
# 실제 사용량 계산
interval_actual_usage = current_interval_total_count - current_interval_usage_count
weekly_actual_usage = current_weekly_total_count - current_weekly_usage_count

# 잔여 시간 기반 사용률
window_ms = end_time - start_time
used_time_ms = window_ms - remains_time
time_usage_ratio = used_time_ms / window_ms
```

## 상태 기준 (잔여량 기준)

| 잔여率 | 상태 | 이모지 |
|--------|------|--------|
| > 50% | 안전 | 🟢 |
| 20% ~ 50% | 주의 | 🟡 |
| < 20% | 위험 | 🔴 |
| < 5% | 심각 | 🚨 |

## 에러 코드

| statusCode | 의미 |
|------------|------|
| 0 | 성공 |
| 10001 | 파라미터 에러 |
| 10002 | 인증 실패 |
| 10003 | 권한 없음 |
| 20000 | 서버 에러 |

## 윈도우 기간

일반적으로 7일(604800000 ms) 윈도우로 설정됩니다.
