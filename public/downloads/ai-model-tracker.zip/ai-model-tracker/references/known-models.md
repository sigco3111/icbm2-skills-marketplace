# Known MiniMax Models — Observed API Responses

API 응답에서 실제로 관측된 모델명 추적표. **사전 가정 금지** — 매 실행 시 `response["model_remains"][*]["model_name"]`을 동적으로 읽을 것.

## 응답 변경 이력

| 날짜 | 응답 모델 | interval_total | weekly_total | percent 필드 |
|------|----------|---------------|--------------|-------------|
| 2026-06-02~03 | `general`, `video` | 0 | 0 | 응답에 포함됨 |
| **2026-06-04** | `general`, `video` | 0 | 0 | **응답에 누락** ⚠️ |

## 카테고리형 모델 (2026-06 현재)

- `general` — 범용 코딩/추론 카테고리 (구 `MiniMax-M*` 추정)
- `video` — 비디오 생성 카테고리 (구 `MiniMax-Hailuo-2.3-*` 추정)

**⚠️ 0/0 응답 처리:** `current_interval_total_count=0`이고 `current_remaining_percent` 필드도 없으면 "데이터 없음"으로 표기. Notion 기록 자체는 성공 처리 (API 호출 정상).

## 기존 모델 목록 (deprecated, 응답 안 함)

- `MiniMax-M*` — 2026-06-04 응답에 없음
- `coding-plan-vlm` — 2026-06-04 응답에 없음
- `coding-plan-search` — 2026-06-04 응답에 없음
- `speech-hd` — 2026-06-04 응답에 없음
- `music-2.5`, `music-2.6`, `music-cover` — 응답 안 함
- `lyrics_generation` — 응답 안 함
- `MiniMax-Hailuo-2.3-Fast-6s-768p` — 응답 안 함
- `MiniMax-Hailuo-2.3-6s-768p` — 응답 안 함
- `image-01` — 응답 안 함 (image generation API는 별도 엔드포인트)

## 분석 메모

- API가 **카테고리 단위** 응답으로 변경된 것으로 보임 — 실제 quota 추적은 카테고리 단위로 통합됨
- 모델별 세분화 quota가 필요하면 별도 엔드포인트가 있는지 확인 필요
- `general` vs `video` 외에 다른 카테고리(`audio` 등)가 향후 추가될 가능성 있음
