# MIT 라이선스 템플릿 (legacy-source-public-release)

옛날 게임 소스를 공개 저장소에 올릴 때 사용하는 표준 MIT 라이선스 템플릿입니다.

## 표준 패턴

```text
MIT License

Copyright (c) <연도> sigco3111

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

NOTE: This license covers the source code and game resources authored by the
copyright holder. <외부 SDK 목록> are NOT included in this repository and
remain the property of <소유자>.
```

## 연도 표기 패턴

| 게임/시점 | Copyright 연도 |
|---|---|
| 2002년 콘솔 게임 (CS) | `Copyright (c) 2002 sigco3111` |
| 2003년 게임들 (BS, BlueMB, consol_shooting) | `Copyright (c) 2003 sigco3111` |
| 제작 시점 불명 | `Copyright (c) sigco3111` (연도 생략) |

## 외부 SDK NOTE 패턴 (환경별)

### Visual C++ 6.0 기반 Windows 게임 (consol_shooting, flamesword, gateheavens)

```text
NOTE: This license covers the source code and game resources authored by the
copyright holder. Visual C++ 6.0, Windows SDK, and winmm.lib are NOT included
in this repository and remain the property of Microsoft.
```

### DirectDraw/DirectInput 기반 (flamesword, gateheavens)

```text
NOTE: This license covers the source code and game resources authored by the
copyright holder. Visual C++ 6.0, DirectDraw, DirectInput, and Windows
Multimedia API (winmm) are NOT included in this repository and remain the
property of Microsoft.
```

### DirectDraw/DirectSound + RPG (dnb-action-rpg, gateheavens)

```text
NOTE: This license covers the source code and game resources authored by the
copyright holder. DirectX SDK (DirectDraw, DirectInput, DirectShow) is NOT
included in this repository and remain the property of Microsoft.
```

### GP32 게임 (gp32-blaster-vertical, gp32-bluemarble-king)

```text
NOTE: This license covers the source code and game resources authored by the
copyright holder. The GP32 SDK, ARM Developer Suite (ADS), and GamePark
toolchain (GPMM, FxeMaker, GP32 PC-Link) are NOT included in this repository
and remain the property of their respective owners.
```

## 작성 시 주의

1. **Copyright (c)는 본인 이름으로** — `sigco3111`
2. **외부 SDK는 반드시 NOTE에 명시** — 라이선스 위반 예방
3. **"remain the property of"** — 소유권 명시 표현 일관 사용
4. **Microsoft/ARM 등 정확한 소유자 표기** — 추측 금지

## 검증 체크리스트

- [ ] Copyright 연도 일치 (해당 게임의 원작 연도)
- [ ] NOTE의 외부 SDK 목록이 README 빌드 환경 섹션과 일치
- [ ] NOTE의 소유자 표기가 Microsoft / ARM / GamePark 등으로 정확
- [ ] 마지막 줄 끝 마침표 일관