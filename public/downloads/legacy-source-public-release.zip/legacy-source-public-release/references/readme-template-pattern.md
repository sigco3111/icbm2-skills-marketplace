# 화려한 README 작성 패턴 (legacy-source-public-release)

옛날 게임 소스를 GitHub 공개 저장소에 푸시할 때 사용자가 선호하는 README 패턴입니다.

2026-07-31 기준, 6개 저장소에서 검증된 패턴:

- `gp32-blaster-vertical`
- `gp32-bluemarble-king` (28KB)
- `dnb-action-rpg` (13KB + 매뉴얼 스크린샷 22장)
- `win32-console-shooter` (19KB)
- `flamesword-action` (28KB + BS史料 스크린샷)
- `gateheavens-shmup` (28KB)

## 구조

```text
1. 상단 메타 (배지 4~5개 + 제목 + 한 줄 설명 + 경고 callout)
2. --- 구분선
3. 📜 목차 (앵커 링크)
4. --- 구분선
5. 📸 관련 자료 (해당 시 — 목차 바로 아래)
6. --- 구분선
7. 개요 (본 게임 설명)
8. 🎮 게임 컨셉 / 화면 미리보기 (ASCII 다이어그램)
9. ✨ 주요 특징 표
10. ⌨️ 조작법 표
11. 📂 폴더 구성 (이모지 트리)
12. 🧱 코드 모듈 (실제 소스 스니펫)
13. 🧬 / 🏗️ 시스템 아키텍처 (다이어그램)
14. 게임 시스템별 섹션
15. ⚙️ 빌드 환경
16. 🔨 빌드 방법
17. 🐛 알려진 한계
18. 📜 라이선스
19. 📁 원본 출처
20. 📸 관련 자료 (또 다른 부록 자료)
21. Tip
```

## 각 섹션 작성 가이드

### 상단 메타

```markdown
# 🏛️ <게임명> — <장르>

> <핵심 한 줄 설명>
> <프로젝트 성격 설명 — 비영리 개인 프로젝트 등>

![platform](https://img.shields.io/badge/platform-Windows-0078d4?style=flat-square) 
![lang](https://img.shields.io/badge/C%2B%2B-VC%2B%2B%206.0-00599c?style=flat-square) 
![graphics](https://img.shields.io/badge/graphics-DirectDraw-red?style=flat-square) 
![license](https://img.shields.io/badge/license-MIT-blue?style=flat-square)
```

### 경고 callout (자료가 다른 프로젝트일 때)

```markdown
> ⚠️ 본 섹션의 자료는 **본 저장소와 다른 별도 프로젝트**입니다.
```

### 📜 목차

```markdown
## 📜 목차

- [개요](#-개요)
- [🎮 게임 컨셉](#-게임-컨셉)
- [✨ 주요 특징](#-주요-특징)
- [... 모든 섹션 앵커 링크]
```

### 🎮 게임 화면 미리보기 (ASCII 다이어그램)

```text
┌─────────────────────────────────────────────────────────────┐
│  ❤❤❤❤❤❤❤❤❤❤                ⬆⬆⬆⬆⬆⬆⬆⬆                       │
│                                                             │
│                        ✦ Player                             │
│                                                             │
│   ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒                │
│         ┌─────┐                                              │
│         │ Typhon │  ← 보스                                    │
│         └─────┘                                              │
│                                                             │
│ ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░ Sc: 1234500 │
└─────────────────────────────────────────────────────────────┘
```

> ⚠️ 위 다이어그램은 README용 ASCII 일러스트이며 실제 게임은 ... 으로 그려집니다.
```

### ✨ 주요 특징 표

```markdown
| 영역 | 설명 |
|---|---|
| 🎨 **렌더링** | DirectDraw 7 + Back Buffer + Color Key |
| ⌨️ **입력** | DirectInput 키보드 폴링 |
| 🧠 **커맨드 시스템** | `m_Comm[8]` + `CQueue<int> InputQue` |
| 🦸 **캐릭터** | `CHero` + `CPlayer` 두 계층 |
| 👹 **적 3종** | 돼지/병아리/뱀 |
```

### 🧱 코드 모듈 (실제 소스 스니펫)

소스 코드에서 발췌한 5~15줄 코드 블록:

```cpp
class CGame {
    int m_Dest;

public:
    CGame();
    virtual ~CGame();
    int  InputMainMenu();
    void DrawMainMenu();
    void DrawInterFace(BYTE Lv, BYTE Ston, BYTE Potion,
                       CSprite* ItemSpr, BYTE Select);
};
```

### 🧬 시스템 아이어그램

```text
[Keyboard]
    │
    ▼
[DirectInput Poll]
    │
    ▼
[CHero::Update]
    │
    ├─→ InputQue.push(...)
    │
    ▼
[Combo Matching]
    │
    └─→ ATTACK2_STATE
```

### 🐛 알려진 한계

```markdown
1. **VC++ 6 빌드 시스템** — `mini.dsp`/`mini.dsw`는 최신 VS에서 직접 열리지 않음
2. **DirectDraw 7 API** — Windows 10/11에서 호환성 모드 필요
3. **이름 오타** — `Ememy.cpp/.h` (`Enemy`의 오타)
4. **한국어 주석 인코딩** — 주석이 EUC-KR, 빌드 시 경고 가능
```

### 📁 원본 출처

```markdown
이 저장소는 다음 경로의 사본입니다.

\```text
~/work/backup/01-public/<FolderName>/
\```

원본 빌드 산출물(...)은 공개 저장소에서 제외했습니다.
```

### Tip (푸터)

```markdown
> 🕹️ **Tip**: Windows 10 이상에서는 `cmd.exe` 창 크기를 80×25 이상으로 맞춰야 화면이 깨지지 않습니다.
```

## 코드 스니펫 길이 가이드

- **함수 단위** (5~20줄) — 적절
- **클래스 선언** (10~30줄) — 적절
- **매우 긴 함수 본체** (50줄+) — 핵심 부분만 발췌 + "..." 생략
- **include 문/전처리** — 스니펫에 포함하지 말 것

## 표 사용 가이드

- 2~3열 권장 (이름 + 설명)
- 4열 이상은 가독성 저하
- 너무 큰 표는 헤더 그룹화 고려

## 📸 관련 자료 섹션 위치

- **기본**: 목차 바로 아래, 개요 위
- **이유**: 사용자가 "위치를 목차 위로 변경해줘" 명시 요청
- **목차에도 추가**: `[📸 관련 자료](#-관련-자료)` 앵커 링크