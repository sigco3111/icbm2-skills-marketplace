# 빌드 산출물 정리 항목 (환경별)

옛날 게임 소스를 GitHub 공개 저장소에 푸시할 때, 빌드 부산물과 환경 파일은 반드시 제외해야 합니다.

## 공통 (모든 환경)

| 패턴 | 설명 |
|---|---|
| `.DS_Store` | macOS 메타데이터 |
| `*.bak`, `*.tmp` | 백업·임시 |
| `Debug/`, `Release/`, `debug/`, `release/` | 빌드 출력 디렉터리 (대소문자 모두) |

## Visual C++ 6.0

| 패턴 | 설명 |
|---|---|
| `*.opt` | VC6 작업 영역 옵션 |
| `*.plg` | 빌드 로그 |
| `*.ncb` | IntelliSense DB |
| `*.positions` | VC6 위치 정보 |
| `*.aps` | 리소스 미리보기 |
| `*.suo` | 사용자 환경 옵션 |
| `*.user` | VC 사용자 환경 |
| `BuildLog.htm` | 빌드 로그 HTML |
| `*.pch` | 프리컴파일 헤더 |
| `*.sbr` | 브라우저 정보 파일 |
| `*.bsc` | Browse 정보 DB |
| `*.exp`, `*.lib`, `*.log`, `*.dep` | VS2005+ 빌드 부산물 |

## Visual Studio 2005 / 2008 / 2010+

| 패턴 | 설명 |
|---|---|
| `*.vcproj`, `*.sln` | **프로젝트 파일이므로 포함 대상** |
| `ipch/`, `*.ipch` | IntelliSense 프리컴파일 |
| `.vs/` | VS 2015+ 사용자 환경 |
| `.vscode/` | VS Code 환경 |

## 빌드 산출물 (모든 환경)

| 패턴 | 설명 |
|---|---|
| `*.obj` | 오브젝트 파일 |
| `*.exe` | 실행 파일 (공개 시 Releases에 별도 업로드 고려) |
| `*.dll` | 동적 라이브러리 |
| `*.pdb` | 디버그 심볼 |
| `*.idb` | 최소 재빌드 정보 |
| `*.ilk` | 증분 링크 |
| `*.res` | 리소스 바이너리 |
| `*.tlog` | 추적 로그 |
| `*.lastbuildstate` | 빌드 상태 |

## Windows 단축아이콘

| 패턴 | 설명 |
|---|---|
| `*.lnk` | 작업 환경 단축아이콘 (제작자 PC에서만 의미) |

## GP32 / ARM 프로젝트

| 패턴 | 설명 |
|---|---|
| `*.fxe` | GP32 실행 파일 |
| `*.elf` | ARM 실행 파일 |
| `*.gxb` | GP32 GPMM 빌드 출력 |
| `ads.zip` | ADS SDK (유료, 라이선스 위반 우려) |

## macOS 임시 파일

| 패턴 | 설명 |
|---|---|
| `~$*.*` | Office 임시 파일 |
| `*.swp` | vim 스왑 |
| `.DS_Store` | macOS 메타데이터 |

## 빌드 산출물 정리 Python 패턴

```python
from pathlib import Path
import shutil, fnmatch

root = Path("/Users/mac/work/github/<repo-name>")

# 패턴 정의
patterns = [
    "*.opt", "*.plg", "*.ncb", "*.positions", "*.aps", "*.suo",
    "*.obj", "*.sbr", "*.exe", "*.pdb", "*.idb", "*.pch",
    "*.ilk", "*.bsc", "*.res", "*.tlog", "BuildLog.htm",
    "*.lnk", ".DS_Store",
    # GP32 프로젝트면 추가
    # "*.fxe", "*.elf", "*.gxb",
]

removed = 0
for f in list(root.rglob("*")):
    if not f.is_file(): continue
    for pat in patterns:
        if fnmatch.fnmatch(f.name, pat):
            f.unlink()
            removed += 1
            break

# 빌드 디렉터리 통째로 삭제
for d in [root/"Release", root/"Debug", root/"debug", root/"release"]:
    if d.exists(): shutil.rmtree(d)

print(f"삭제된 파일: {removed}개")
```

## 빈 폴더 자동 제거

빌드 산출물 정리 후 빈 디렉터리가 남으면 그것도 정리:

```python
for d in sorted(root.rglob('*'), key=lambda p: -len(p.parts)):
    if d.is_dir() and not any(d.iterdir()):
        try: d.rmdir()
        except OSError: pass
```

## 주의: 절대 삭제하면 안 되는 것

- `.git/` — git 저장소 (정리 대상 아님)
- `*.dsp`, `*.dsw` — VC++ 6 프로젝트 파일 (포함 대상)
- `*.vcproj`, `*.sln` — VC 2005+ 프로젝트 파일 (포함 대상)
- `*.vbp`, `*.vbw`, `*.frx` — VB6 프로젝트 파일 (포함 대상)
- 매뉴얼 HTM, JPG 스프라이트, 사운드 WAV/SFK — 게임 자산