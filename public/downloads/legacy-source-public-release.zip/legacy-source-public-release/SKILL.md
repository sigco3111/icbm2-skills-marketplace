---
name: legacy-source-public-release
description: "옛날 VC++ 6 / GP32 / DirectDraw 개인 소스를 GitHub 공개로 푸시하는 워크플로우."
trigger: "옛날 게임 소스 공개, GitHub 푸시 파이프라인, 빌드 산출물 정리, VC++ 6 프로젝트 공개, GP32 공개."
last_updated: 2026-07-31
status: active
---

# Legacy Source Public Release

옛날 개인 개발 프로젝트(VC++ 6, GP32 SDK, DirectDraw 등)를 GitHub 공개 저장소로 푸시할 때 따라야 할 표준 워크플로우입니다.

## 보장 사항

- **원본 폴더는 절대 손대지 않습니다** — 사용자가 백업 원본을 보존해야 합니다
- **공개 가능 여부를 먼저 사용자에게 확인합니다** — 민감한 SDK/에셋이 섞여 있으면 비공개 분리
- **빌드 산출물과 환경 파일을 자동 제외합니다** — `*.obj`, `*.sbr`, `*.pdb`, `*.opt`, `*.plg`, `*.ncb`, `*.positions`, `*.lnk`, `.DS_Store`
- **`*.res` (컴파일된 리소스)** — `*.rc`로 재생성 가능. 기본 `.gitignore`에 포함시키되, **사용자에게 포함 여부 한 번 확인** (IsoMapTool 사례: 2026-07-31 `Debug/IsoMapTool.res` 포함 결정)
- **README를 사용자가 좋아하는 화려한 패턴으로 작성합니다** — shields.io 배지, 이모지 헤더, 목차, ASCII 다이어그램, 코드 스니펫, 알려진 한계
- **GitHub API로 푸시 결과를 직접 검증합니다** — 단순히 "됐다"가 아니라 visibility, 커밋 SHA, 파일 목록을 확인
- **README 안 보일 때 대응 방법을 알고 있습니다** — 캐시, 시크릿 모드, raw URL

## 워크플로우 (8단계 + 1 follow-up)

### 1단계: 사전 확인

- 사용자에게 **공개/비공개/보류 중 어디로 분류할지** 먼저 확인 (단순 "올려줘"는 위험)
- **`@folder:` 같은 외부 워크스페이스 경로**가 입력되면 → 작업 사본(`/Users/mac/work/github/<repo-slug>/`)을 즉시 만들어 원본을 보호하고 사본에서만 작업
- **민감한 SDK**(GP32 SDK, ADS, DirectX SDK), 타사 에셋, 개인정보가 포함되어 있지 않은지 점검
- 분량이 크면(>100MB) 사전에 사용자에게 알림
- **`BackUp/` 같은 단계별 백업 ZIP** 폴더가 있으면 → README에 히스토리 표를 만들 것인지, ZIP을 그대로 포함할지, 표만 보존할지 사용자에게 확인 (B-1/B-2/B-3 옵션 제시, 추천 포함)

### 2단계: 작업 사본 폴더 생성 (원본 절대 보존)

```bash
mkdir -p /Users/mac/work/github
cp -a "/path/to/original/folder" /Users/mac/work/github/<repo-name>
```

- 절대 원본 폴더에 파일을 추가/삭제/이동하지 않음
- `cp -a`로 권한/타임스탬프 보존
- 작업 사본에서 모든 후속 작업 수행

### 3단계: 빌드 산출물 정리

자세한 환경별 정리 항목은 [`references/build-outputs-to-exclude.md`](references/build-outputs-to-exclude.md) 참조.

핵심 정리 대상:

- **VC++ 6 / Visual Studio 환경**: `*.opt`, `*.plg`, `*.ncb`, `*.positions`, `*.aps`, `*.suo`, `*.user`, `Debug/`, `Release/`
- **빌드 산출물**: `*.obj`, `*.sbr`, `*.exe`, `*.pdb`, `*.idb`, `*.pch`, `*.ilk`, `*.bsc`, `*.res`
- **GP32 툴체인 산출물**: `*.fxe`, `*.elf`, `*.gxb`
- **Windows 단축아이콘**: `*.lnk` (작업 환경 잔재)
- **macOS 메타데이터**: `.DS_Store`
- **빈 폴더/디렉터리**: `Release/`, `Debug/`, `__*` 같은 더미 디렉터리

Python 한 줄로 일괄 정리하는 패턴:

```python
from pathlib import Path
import shutil, fnmatch
root = Path("/Users/mac/work/github/<repo-name>")
for f in list(root.rglob("*")):
    if not f.is_file(): continue
    for pat in ("*.opt","*.plg","*.ncb","*.positions","*.sbr","*.obj",
                "*.exe","*.pdb","*.idb","*.pch","*.ilk","*.bsc","*.lnk"):
        if fnmatch.fnmatch(f.name, pat): f.unlink(); break
for d in [root/"Release", root/"Debug"]:
    if d.exists(): shutil.rmtree(d)
```

### 4단계: README 작성 (사용자 선호 패턴)

사용자가 "화려하고 자세하게"를 선호하므로 [`references/readme-template-pattern.md`](references/readme-template-pattern.md) 참조.

핵심 요소:

- **상단**: shields.io 배지 4~5개 + 제목 + 짧은 설명 + 경고 callout(다른 프로젝트 자료 첨부 시)
- **목차**: 모든 섹션 앵커 링크, `[📸 관련 자료]`는 상단 배치 시 목차에도 추가
- **섹션 헤더**: 이모지 + 텍스트 (예: `## 🎮 게임 컨셉`)
- **ASCII 다이어그램**: 화면/구조 표현
- **코드 스니펫**: 실제 소스에서 발췌한 작은 코드 블록
- **표**: 2~3열 위주, 너무 크지 않게
- **알려진 한계**: 명시적으로 적기 (사용자 신뢰 ↑)
- **원본 출처**: 어디서 왔는지 명시
- **새 섹션 위치**: 목차 바로 아래, 개요 위가 기본

### 5단계: LICENSE 작성

자세한 템플릿은 [`references/license-mit-template.md`](references/license-mit-template.md) 참조.

- 기본은 MIT
- 마지막 NOTE에 "이 라이선스는 작성자가 직접 만든 소스/리소스에 한정. 외부 SDK(VC++ 6, DirectDraw, DirectSound, GP32 SDK, ADS 등)는 Microsoft/ARM 소유로 본 저장소에 미포함" 명시

### 6단계: .gitignore 작성

자세한 템플릿은 [`templates/.gitignore-template.md`](templates/.gitignore-template.md) 참조.

환경별로 매크로 형태가 다르지만, 공통 베이스:

```gitignore
# macOS
.DS_Store

# Visual C++ 6 / Visual Studio (host build)
*.opt, *.plg, *.ncb, *.positions, *.aps, *.suo
Debug/, Release/

# Build output
*.obj, *.sbr, *.exe, *.pdb, *.idb, *.pch, *.ilk, *.bsc, *.res

# Windows shortcut icons
*.lnk

# IDE / editor
.vs/, .vscode/, *.swp
```

GP32/ARM 프로젝트면 추가로:

```gitignore
# GP32 toolchain build artifacts
*.fxe, *.elf, *.gxb
```

DirectX 프로젝트면:

```gitignore
# DirectX SDK 의존 — 별도 설치 필요 (본 저장소 미포함)
```

### 7단계: gh CLI 인증 + git 푸시

```bash
# 인증 확인
gh auth status

# git 초기화
git init -q -b main
git config user.email "[email protected]"
git config user.name "sigco3111"
git add .
git status --short | wc -l  # 스테이지된 파일 수 확인
git commit -q -m "<커밋 메시지>"

# 공개 저장소 생성 + 푸시
gh repo create <name> --public --description "<한 줄 설명>" --source . --push
```

**커밋 메시지 패턴** (사용자 선호):

```
<게임 이름> <장르> 공개 릴리스

- <모듈 1>: <역할>
- <모듈 2>: <역할>
- ...
- 공개: 소스 + 게임 리소스 (MIT)
- 제외: <SDK>, 빌드 산출물, 환경 파일
```

### 8단계: GitHub API 검증

푸시 후 반드시 검증 (사용자가 "안 보인다"고 자주 질문함):

```bash
# 1. 저장소 메타데이터
gh repo view <name> --json name,visibility,url

# 2. 커밋 SHA 확인
gh api repos/sigco3111/<name>/commits/main | python3 -c "
import sys, json
c = json.load(sys.stdin)
print('SHA:', c['sha'][:7])
print('Message:', c['commit']['message'].splitlines()[0])
"

# 3. README 크기 + 내용 확인
gh api repos/sigco3111/<name>/readme | python3 -c "
import sys, json, base64
r = json.load(sys.stdin)
content = base64.b64decode(r['content']).decode('utf-8')
print('Size:', len(content), 'chars')
print('Image refs:', content.count('!['))
"

# 4. raw URL 직접 fetch — README가 실제로 CDN에 서빙되는지 마지막 확인
curl -s -o /dev/null -w "HTTP %{http_code} / size %{size_download} bytes\n" \
  "https://raw.githubusercontent.com/sigco3111/<name>/main/README.md"
```

`gh repo create --push`는 silent fail이 가끔 있어서, **`gh repo view` + `curl raw` 이중 검증**이 표준 (2026-07-31 IsoMapTool 검증 패턴). 사용자에게 정량 수치(visibility, SHA, 파일 수, README bytes, HTTP status) 모두 보고.

### 9단계: README 안 보일 때 대응

푸시 후 사용자가 "안 보인다"고 하면 다음을 순서대로 확인:

1. **GitHub API로 실제 푸시 검증** — visibility, 커밋 SHA, README content
2. **브라우저 캐시** 안내 — `Cmd/Ctrl + Shift + R` 강력 새로고침
3. **시크릿/프라이빗 창**에서 직접 URL 열기
4. **raw URL 확인** — `https://raw.githubusercontent.com/sigco3111/<repo>/main/README.md`

## 알려진 함정 (Pitfalls)

1. **로컬 `file://` 경로는 GitHub에서 렌더링되지 않음**
   - 매뉴얼/스크린샷은 반드시 작업 사본의 `docs/` 폴더로 복사 후 상대 경로(`docs/foo.jpg`)로 참조
   - 절대 절대경로(`/Users/mac/...`)나 `file:///Users/mac/...` 사용 금지

2. **원격에 다른 커밋이 이미 있으면 `git push`가 rejected됨**
   - `git pull --rebase origin main` 후 충돌 마커 수동 제거
   - `GIT_EDITOR=true git rebase --continue`로 비대화 진행
   - 충돌 해결 시 "원격 HEAD 내용 + 내 변경" 둘 다 살리기

3. **GitHub README 캐시**
   - 푸시 직후 1~2분 안에 반영 안 될 수 있음
   - 시크릿 모드 또는 강력 새로고침으로 해결

4. **사용자가 매뉴얼/스크린샷을 다른 프로젝트와 혼동할 수 있음**
   - README에 `> ⚠️ 본 섹션의 자료는 다른 별도 프로젝트입니다.` callout 명시
   - 섹션 첫 줄에 분명히 표시

5. **빈 폴더가 자동 생성되어 잡음**
   - 작업 사본 생성 직후 빈 폴더 미리 제거 (`Release/`, `__*` 등)

6. **GitHub 100MB 파일 제한**
   - 단일 파일 100MB 초과 시 push 실패
   - 분량이 큰 MP3/BMP는 Git LFS 사용 검토 (사용자에게 확인)

7. **사용자가 "원본에 추가"를 요청할 수 있음**
   - 옵션 1 (보류), 옵션 2 (코드만), 옵션 3 (전체 공개), 옵션 4 (원본에 README 추가) 중 선택지를 제시
   - 원본 보존 원칙은 공개 푸시에 한정. 로컬 README 추가는 OK

8. **사용자가 README 안 보일 때 자주 재확인 요청**
   - "푸시한 것 맞나?"는 거의 매번 발생
   - GitHub API 검증 결과(SHA, 파일 목록)를 정량적으로 보여주면 안심함

9. **스크린샷 부착 시 자료 해석**
   - `manual/Etc/*.htm`은 EUC-KR 인코딩 — 복원해야 의미 파악 가능
   - `cat` 후 한글 깨짐은 정상. 본문 의미는 코드로 재해석 (개발자 노트 인용 가능)
   - 예: BS.htm "Three Cucumber", "Map Tool, Sprite Tool, AI"

10. **`@folder:` 외부 경로는 원본 보존 필수**
    - 워크스페이스 외부의 `@folder:` 참조는 항상 `/Users/mac/work/github/<repo-slug>/` 작업 사본으로 복사 후 진행
    - Context warning "path is outside the allowed workspace"가 뜨면 즉시 작업 사본 모드
    - 02-private/ 백업은 외부 SDK/회사 자료 가능성 → 공개 전 무조건 옵션 제시

11. **`BackUp/` 단계별 ZIP 폴더 처리**
    - 2000년대 백업 습관으로 `BackUp/<기능명>.zip`이 10~20개 들어있는 경우 많음 (IsoMapTool 18개, 1.5MB)
    - 옵션 3종 (B-1/B-2/B-3) 중 **B-2 (제외 + README 표만 보존)** 가 가장 깔끔
    - B-1 선택 시 1.5MB 가량이라 부담 없지만, README에 단계 표가 이미 있으면 표와 실제 파일이 일치한다는 장점
    - `BackUp/*.zip`을 `.gitignore`에 한 줄로 차단

12. **`*.res` (컴파일된 리소스) 결정**
    - `*.rc`가 이미 추적되면 `*.res`는 재빌드 산출물. 기본은 `.gitignore`에 포함
    - 단, 사용자가 명시적으로 "포함" 결정하면 그대로 push (`.gitignore`는 동작 안 함)
    - 결정 기록: 2026-07-31 IsoMapTool — `Debug/IsoMapTool.res` 포함

13. **`git add -A -n` 으로 push 전 미리보기**
    - `git add -A -n` → 스테이지될 파일 목록 dry-run (실제 add 안 됨)
    - `Debug/IsoMapTool.res` 같은 잔재가 빠져나가는지 마지막 확인
    - `git ls-files` (add/commit 후) → 추적 파일 수로 사용자 보고

## 사용자 선호 (확정된 패턴)

이 워크플로우는 다음 사용자 선호가 검증된 상태입니다 (2026-07-31):

- **README는 화려하고 자세하게** — 목차 + 이모지 헤더 + shields.io 배지 + ASCII 다이어그램 + 코드 스니펫 + 알려진 한계 + 라이선스
- **새 섹션은 목차 바로 아래에 배치** — "위치를 목차 위로 변경해줘" 선호 확인
- **원본 폴더는 절대 건드리지 않음** — 옵션 B (실제 이동/이름 변경) 선택 시만 예외
- **공개 저장소에 스크린샷/매뉴얼 포함 시 callout 명시** — "본 저장소와 다른 별도 프로젝트" 구분
- **푸시 후 GitHub API 검증 결과를 정량적으로 보고** — "안 보인다는" 사용자 질문에 대비
- **풀네임 미공개 게임은 "Three Cucumber" 같은 팀명/별칭도 README에 포함**
- **매뉴얼 HTM(JPG)의 EUC-KR 원문을 복원해 README에 인용** — "Map Tool과 Sprite Tool을 직접 만들어 사용해보고..."
- **`@folder:` 외부 경로 작업 시 작업 사본 자동 생성** — `/Users/mac/work/github/<repo-slug>/` 패턴 (memory 정책과 정합)
- **`*.res` (컴파일된 리소스) 결정은 사용자에게 한 번 더 확인** — `*.rc` 존재 여부 기준
- **`BackUp/` 단계별 ZIP은 옵션 3종 제시 + 추천 포함** — B-1 (README+ZIP 모두), B-2 (표만 보존, 추천), B-3 (ZIP+상세 diff)
- **푸시 후 `gh repo view` + `curl raw.githubusercontent` 이중 검증** — GitHub API + raw URL 둘 다 정상이어야 완료 보고

## 참고 자료

- [`references/build-outputs-to-exclude.md`](references/build-outputs-to-exclude.md) — 환경별 빌드 산출물 정리 항목 (VC++ 6, VS2005+, GP32, DirectX, VB6)
- [`references/readme-template-pattern.md`](references/readme-template-pattern.md) — 화려한 README 작성 패턴 (배지·이모지·목차·ASCII·코드 스니펫·알려진 한계)
- [`references/license-mit-template.md`](references/license-mit-template.md) — MIT 라이선스 템플릿 + 외부 SDK NOTE 패턴
- [`templates/.gitignore-template.md`](templates/.gitignore-template.md) — VC++ 6/GP32/DirectDraw/DnB 공통 .gitignore 완성 템플릿

## 검증된 사례 (Verified Cases)

2026-07-31 기준 공개 완료된 sigco3111 레거시 프로젝트:

| 폴더 | repo-slug | 분량 | 비고 |
| :--- | :--- | :---: | :--- |
| `01-public/GP32/부루마블대왕/` | `gp32-bluemarble-king` | - | 공개 |
| `01-public/GP32/일단피해 소스/` | `gp32-blaster-vertical` | - | 공개 |
| `01-public/Win/DnB/` | `dnb-action-rpg` | - | 공개 |
| `01-public/Win/consol_shooting/` | `win32-console-shooter` | - | 공개 |
| `01-public/Win/FlameSword/` | `flamesword-action` | - | 공개 |
| `01-public/Win/GateHeavens/` | `gateheavens-shmup` | - | 공개 |
| `01-public/GP32/GP32_리소스 모음/` | `gp32-resource-archive` | - | 비공개 |
| **`02-private/IsoMapTool/`** | **`IsoMapTool`** | **348KB / 43 files** | **공개 (이번 세션, MFC 다이아몬드 아이소메트릭, BackUp ZIP 18개 제외, Debug/*.res 포함 결정)** |