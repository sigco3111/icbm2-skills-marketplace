---
name: auto-researcher
description: 심층 자동 조사 — 주제를 받아 여러 소스에서 수집 후 종합 리포트 작성
version: 1.0.0
author: icbm2
metadata:
  hermes:
    tags: [Research, Report, Automation, Notion, Arxiv]
prerequisites:
  secret_files: [notion_token.txt]
---

## 개요

주제 하나를 입력받아 Arxiv, Hacker News, Reddit, 기술 블로그, 뉴스 등 여러 소스에서 자동으로 조사하여 종합 리포트를 작성합니다. 2단계 리서치(빠른 서베이 → 심층 조사) 방식으로 진행합니다.

## 데이터 소스

### 1. Arxiv (학술 논문)

```bash
curl -s "https://export.arxiv.org/api/query?search_query=all:QUERY&max_results=5&sortBy=submittedDate&sortOrder=descending"
```

- arxiv 스킬의 search_arxiv.py 활용: `python3 scripts/search_arxiv.py "QUERY" --sort date --max 5`
- Semantic Scholar API로 인용수/관련 논문 확인

### 2. Hacker News

```bash
# HN 검색 (Algolia API)
curl -s "https://hn.algolia.com/api/v1/search?query=QUERY&tags=story&hitsPerPage=10"
```

- 상위 10개 스토리 + 댓글 인사이트

### 3. Reddit

```bash
# Reddit 검색 (공개 API)
curl -s "https://www.reddit.com/search.json?q=QUERY&sort=relevance&t=month&limit=10" -H "User-Agent: ICBM2/1.0"
```

- r/MachineLearning, r/LocalLLaMA, r/programming 등

### 4. 일반 웹 검색

- terminal에서 curl 또는 web_extract로 관련 페이지 수집
- 주요 기술 블로그, 공식 문서 등

## 2단계 리서치 프로세스

### 1단계: 빠른 서베이 (Quick Survey)

1. 모든 소스에서 관련 자료 수집 (각 5-10개)
2. 제목/초록/요약만 빠르게 스캔
3. 핵심 테마와 중요 자료 3-5개 선정
4. 주인님에게 "이 방향으로 심층 조사할까요?" 확인 (대화형) 또는 자동 진행 (크론)

### ⚠️ 함정: 레퍼런스 매칭 단정 ("이거다!" 함정)

추천/제안 단계에서 "이 자료가 정확히 우리 케이스다!" 같은 **강한 단정**을 즉시 하지 말 것. 특히:
- 제목/요약만 보고 우리 요구사항과 80% 매칭되면 반드시 **2단계 (본문 fetch)** 에서 차이점 확인
- 차원 차이(예: RTS vs 턴제, 실시간 vs 세션형, 캐릭터 수, 시간 단위)를 표로 정리해서 사용자에게 보여주기
- 결정권은 사용자에게 위임. "추천: A (사유), 차이점: B, 대안: C/D"

**왜 함정인가**: 2026-06-12 AI 게임 빌더 세션에서 arxiv 2510.18395 (MASMP, RTS 게임 AI)를 검색 1순위로 "정확히 우리 케이스"라 추천했으나, 사용자가 "RTS 아닌 턴제"라고 짚자 실제론 시간 모델·결정 주기·메모리 단위 모두 다름. MASMP의 state machine 아이디어는 차용했지만, 더 적합한 자료들(LoreKit, NarrativeEngine-P)이 별도 조사로 드러남. **검색 결과 1위 ≠ 우리 케이스 1위**.

**회피 패턴**:
- 추천 시 **"왜 맞는지/안 맞는지" 분기를 1개 이상 동시 제시** (예: "A는 X 측면에서 맞지만 Y에서 안 맞음, Z는 정반대")
- 1단계 서베이에서 비교표 형식 후보 3개로 압축 (단정 금지)
- 본문 fetch 전까지 "정확히 맞다" 표현 사용 금지 — "유력하다"까지만

### 2단계: 심층 조사 (Deep Dive)

1. 선정된 자료의 전문 읽기
2. 크로스 참조 (여러 소스의 정보 교차 검증)
3. 핵심 인사이트 추출
4. 종합 리포트 작성

## 리포트 출력 형식

```
🔍 자동 조사 리포트: [주제]
📅 조사일: YYYY-MM-DD

📋 실행 요약
(3-5문장으로 전체 조사 결과 요약)

📌 핵심 인사이트
1. (가장 중요한 발견)
2. (두 번째 중요한 발견)
3. (세 번째 중요한 발견)

📊 소스별 분석

📄 학술 논문 (Arxiv)
• 논문1 제목 [arXiv ID] — 요약 2-3문장
• 논문2 제목 [arXiv ID] — 요약 2-3문장

💬 커뮤니티 의견 (HN/Reddit)
• HN 토론 요약 — 주요 의견 2-3개
• Reddit 토론 요약 — 주요 의견 2-3개

📰 뉴스/블로그
• 기사/블로그 요약 2-3개

🔗 관련 자료
• 링크1 — 설명
• 링크2 — 설명

🤖 ICBM2 분석
(주인님 관점에서 왜 중요한지, 관련 트렌드, 액션 아이템)
```

## Notion 저장

### DB: 아이디어 노트

- DB ID: 32e76f2e-9097-8081-98d0-f54524fe4c47

### DB: Tech Doc Translator

- DB ID: 31afa83b-8e35-447b-8e9d-8d21e8917ade
- 논문/기술 문서는 여기에도 기록

### 저장 방법

```python
import os, json, subprocess
TK_PATH = os.environ.get("NOTION_TOKEN_PATH", os.path.expanduser("~/.hermes/secrets/notion_token.txt"))
with open(TK_PATH) as f:
    tk = f.read().strip()

# Notion API 호출 패턴 (다른 스킬들과 동일)
```

## delegate_task 활용 (병렬 수집)

여러 소스를 병렬로 수집할 때 delegate_task를 활용:

- 서브에이전트 1: Arxiv 논문 수집
- 서브에이전트 2: HN/Reddit 토론 수집
- 서브에이전트 3: 웹 뉴스/블로그 수집
- → 결과를 메인에서 통합

## 사용 예시

### 텔레그램에서

- "GPT-5 성능 비교 조사해줘" → 종합 리포트
- "Rust vs Go 2026 트렌드 조사" → 비교 분석 리포트
- "최근 멀티모달 AI 모델 트렌드 알려줘" → 트렌드 리포트
- "이 논문 심층 분석해줘 arXiv:2402.03300" → 단일 논문 심층 분석

### 크론에서 (자동 조사)

- 특정 주제를 정기적으로 모니터링 (예: 주간 AI 트렌드)

## 관련 스킬

- arxiv (논문 검색)
- tech-doc-translator (기술 문서 번역)
- blogwatcher (블로그 모니터링)
- dev-news-to-wiki (뉴스 아카이빙)
- notion (Notion API)

## 주의사항

- 출처를 반드시 표시
- 여러 소스의 정보를 교차 검증
- 단일 소스에 편중되지 않도록 주의
- 한국어로 리포트 작성
- 최대 3-5개 핵심 인사이트로 압축 (너무 길면 요약)
- 조사 완료 후 "더 깊이 파고들 부분이 있으면 말씀해주세요" 안내
