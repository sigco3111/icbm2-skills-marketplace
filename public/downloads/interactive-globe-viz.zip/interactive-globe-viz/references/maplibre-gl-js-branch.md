# maplibre-gl-js Branch — Visual-First Globe / Map Viz

Verified 2026-08-06 against maplibre-gl-js v5+ when researching alternatives to Globe.gl
for projects that need **3D depth + interaction + free data + no API key**.

This is a **companion** to the Globe.gl skill, not a replacement. Maplibre-gl-js is
optimized for *raster/vector tiles + 3D terrain + globe projection*; Globe.gl is
optimized for *points-on-sphere + giant point clouds*. Choose by data shape.

## When to prefer maplibre-gl-js over Globe.gl

| Need | Globe.gl | maplibre-gl-js |
|---|---|---|
| 42K points on a sphere | ✅ Spatial grid + culling | ❌ Tile-based, not point-optimized |
| 3D terrain + extruded buildings | ⚠️ Requires GLTF + custom shaders | ✅ Built-in raster-dem + fill-extrusion |
| Atmosphere / sky / fog | ❌ Custom shaders | ✅ `setFog()` + `setProjection('globe')` |
| 14K vector points + lines + polygons | ✅ Polygons/pings rings | ✅ GeoJSON source + layers |
| Real-time satellite / aircraft | ❌ Re-render every frame | ✅ Tile-based, smooth |
| Mapbox 3D Tiles integration | ❌ | ✅ `add-3d-tiles-using-threejs` |
| Free, no API key, no token | ✅ | ✅ |

**Rule of thumb**: if the visualization is *map-shaped* (latitude/longitude * TILE),
use maplibre. If it's *point-cloud-shaped* (thousands of lat/lng points), use Globe.gl.

## Phase 0-alt: Choose maplibre and validate data

Three steps before any code:

### 1. Pick a free base map

All API-key-free:

- **OpenStreetMap raster** — `https://tile.openstreetmap.org/{z}/{x}/{y}.png` (standard)
- **OpenFreeMap Positron** — vector tiles, API key 0 (https://openfreemap.org/)
- **AWS Terrarium DEM** — `https://elevation-tiles-prod.s3.amazonaws.com/terrarium/{z}/{x}/{y}.png`
  - **3D depth의 핵심**. RGB 인코딩 elevation. Use with `encoding: 'terrarium'`.
- **AWS Normalize DEM** — same path with `/normalize/` (smoother 3D)

### 2. Validate every data endpoint before integrating

Don't trust the API docs. Probe with `scripts/probe-data-endpoint.sh` (below). The
2026-08-06 session found **2 endpoints dead that were widely recommended**:

- ❌ OpenSky Network (`/api/states/all`) — timed out
- ❌ OpenAQ v2/v3 — HTTP 401/410 Gone
- ✅ USGS earthquake GeoJSON feed — alive (1.4MB weekly)
- ✅ Open-Meteo — alive, no key
- ✅ ISS Open Notify — alive, 100 bytes
- ✅ NASA EONET — alive
- ✅ Wikipedia geosearch API — alive
- ✅ GBFS (mobilitydata) — alive

**Always probe before adding a layer**. Add the output to your build notes.

### 3. Pick the projection

maplibre v3+ supports `globe` projection natively:

```ts
new maplibregl.Map({
  style: 'https://tiles.openfreemap.org/styles/positron',
  projection: 'globe',  // ← turns the map into a 3D globe
  center: [127, 37.5],
  zoom: 2,
  pitch: 0,
});

map.on('style.load', () => {
  map.setFog({  // atmosphere + sky color
    color: 'rgb(186, 210, 235)',
    'high-color': 'rgb(36, 92, 223)',
    'horizon-blend': 0.02,
    'space-color': 'rgb(11, 11, 25)',
  });
});
```

This is the **fastest path to a 3D globe with atmosphere** — single Map config + one
`setFog` call. The Globe.gl equivalent needs a custom sky shader.

## Verified free data sources (August 2026)

All endpoints verified alive with `scripts/probe-data-endpoint.sh`. Re-probe before
shipping if more than 30 days pass.

### JSON one-liners (drop-in)

| Data | Endpoint | Effect |
|---|---|---|
| ISS real-time | http://api.open-notify.org/iss-now.json | Marker on globe, animate |
| ISS detailed | https://api.wheretheiss.at/v1/satellites/25544 | Lat/lng/alt/velocity |
| USGS Earthquakes (week) | https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_week.geojson | GeoJSON, color by depth |
| NASA EONET events | https://eonet.gsfc.nasa.gov/api/v3/events?status=open&limit=100 | Wildfires, volcanoes, storms |
| Open-Meteo | https://api.open-meteo.com/v1/forecast?latitude=37.5&longitude=127&hourly=temperature_2m&forecast_days=7 | Per-coordinate weather |
| Wikipedia geosearch | https://en.wikipedia.org/w/api.php?action=query&list=geosearch&gscoord=37.5\|127&gsradius=5000&format=json | Knowledge clusters |

### Downloadable datasets (one-time fetch)

| Data | URL | Size |
|---|---|---|
| OpenFlights airports | https://raw.githubusercontent.com/jpatokal/openflights/master/data/airports.dat | 1MB CSV |
| GBFS (world bike share) | https://gbfs.mobilitydata.org/ | 50KB+ index |
| AWS Terrarium DEM tiles | https://elevation-tiles-prod.s3.amazonaws.com/terrarium/{z}/{x}/{y}.png | Per-tile 20KB |
| GEBCO bathymetry | https://www.gebco.net/data_and_products/gridded_bathymetry_data/ | Multi-GB |
| NASA Black Marble | https://earthdata.nasa.gov/learn/articles/nasa-black-marble | Multi-GB (login) |

### Known dead (do not use without re-probing)

| Data | Endpoint | Status |
|---|---|---|
| OpenSky Network | https://opensky-network.org/api/states/all | Timeout (2026-08-06) |
| OpenAQ | https://api.openaq.org/v2/latest | 410 Gone (2026-08-06) |
| OpenAQ v3 | https://api.openaq.org/v3/latest | 401 Unauthorized (2026-08-06) |
| OpenRailwayMap | https://a.tiles.openrailwaymap.org/standard/{z}/{x}/{y}.png | 403 Forbidden |
| OpenTopoMap | https://a.tile.opentopomap.org/{z}/{x}/{y}.png | 403 Forbidden |

## 95 visual examples catalog (maplibre official)

137 official examples at https://maplibre.org/maplibre-gl-js/docs/examples/ —
**95 (69%) are visual**. Categorized for the user's "3D depth · composition · material
· lighting" preference:

### 🌍 3D Globe / Planet (7)
- [Globe with Vector Map](https://maplibre.org/maplibre-gl-js/docs/examples/display-a-globe-with-a-vector-map/)
- [Globe with Fill Extrusion](https://maplibre.org/maplibre-gl-js/docs/examples/display-a-globe-with-a-fill-extrusion-layer/)
- [Globe with Atmosphere](https://maplibre.org/maplibre-gl-js/docs/examples/display-a-globe-with-an-atmosphere/) **🥇**
- [Zoom & Planet Size on Globe](https://maplibre.org/maplibre-gl-js/docs/examples/zoom-and-planet-size-relation-on-globe/)
- [3D Model on Globe (Three.js)](https://maplibre.org/maplibre-gl-js/docs/examples/add-a-3d-model-to-globe-using-threejs/)
- [Custom Layer on Globe](https://maplibre.org/maplibre-gl-js/docs/examples/add-a-custom-layer-with-tiles-to-a-globe/)
- [Simple Custom Layer on Globe](https://maplibre.org/maplibre-gl-js/docs/examples/add-a-simple-custom-layer-on-a-globe/)

### 🏔️ 3D Terrain (9)
- [3D Terrain](https://maplibre.org/maplibre-gl-js/docs/examples/3d-terrain/)
- [Sky Fog Terrain](https://maplibre.org/maplibre-gl-js/docs/examples/sky-fog-terrain/) **🥈**
- [Heatmap on Globe with Terrain](https://maplibre.org/maplibre-gl-js/docs/examples/create-a-heatmap-layer-on-a-globe-with-terrain-elevation/)
- [Hybrid Satellite with Terrain](https://maplibre.org/maplibre-gl-js/docs/examples/display-a-hybrid-satellite-map-with-terrain-elevation/)
- [3D Models on Terrain (Three.js)](https://maplibre.org/maplibre-gl-js/docs/examples/adding-3d-models-using-threejs-on-terrain/)
- [Multidirectional Hillshade](https://maplibre.org/maplibre-gl-js/docs/examples/add-a-multidirectional-hillshade-layer/)
- [Hillshade Layer](https://maplibre.org/maplibre-gl-js/docs/examples/add-a-hillshade-layer/)
- [Contour Lines](https://maplibre.org/maplibre-gl-js/docs/examples/add-contour-lines/)
- [Color Relief Layer](https://maplibre.org/maplibre-gl-js/docs/examples/add-a-color-relief-layer/)

### 🏙️ 3D Buildings / Models (7)
- [Display Buildings in 3D](https://maplibre.org/maplibre-gl-js/docs/examples/display-buildings-in-3d/) **🥉**
- [Extrude Polygons for 3D Indoor](https://maplibre.org/maplibre-gl-js/docs/examples/extrude-polygons-for-3d-indoor-mapping/)
- [Building Color by Zoom](https://maplibre.org/maplibre-gl-js/docs/examples/change-building-color-based-on-zoom-level/)
- [3D Model (Three.js)](https://maplibre.org/maplibre-gl-js/docs/examples/add-a-3d-model-using-threejs/)
- [3D Model (Babylon.js)](https://maplibre.org/maplibre-gl-js/docs/examples/add-a-3d-model-with-babylonjs/)
- [3D Model with Shadow (Three.js)](https://maplibre.org/maplibre-gl-js/docs/examples/add-a-3d-model-with-shadow-using-threejs/) 🎁
- [3D Tiles (Three.js)](https://maplibre.org/maplibre-gl-js/docs/examples/add-3d-tiles-using-threejs/)

### 🎬 Animation (14)
- [Animate Camera Around Point](https://maplibre.org/maplibre-gl-js/docs/examples/animate-map-camera-around-a-point/) 🎁
- [Fly to a Location](https://maplibre.org/maplibre-gl-js/docs/examples/fly-to-a-location/)
- [Animate Point Along Route](https://maplibre.org/maplibre-gl-js/docs/examples/animate-a-point-along-a-route/)
- [Customize Camera Animations](https://maplibre.org/maplibre-gl-js/docs/examples/customize-camera-animations/)
- [Game-like Controls](https://maplibre.org/maplibre-gl-js/docs/examples/navigate-the-map-with-game-like-controls/)
- [First Person Walk](https://maplibre.org/maplibre-gl-js/docs/examples/walk-around-a-map-in-first-person/)
- [Animate a Line](https://maplibre.org/maplibre-gl-js/docs/examples/animate-a-line/)
- [Animate a Marker](https://maplibre.org/maplibre-gl-js/docs/examples/animate-a-marker/)
- [Animate a Point](https://maplibre.org/maplibre-gl-js/docs/examples/animate-a-point/)
- [Animate Series of Images](https://maplibre.org/maplibre-gl-js/docs/examples/animate-a-series-of-images/)
- [Animate Symbol to Follow Mouse](https://maplibre.org/maplibre-gl-js/docs/examples/animate-symbol-to-follow-the-mouse/)
- [Fly to Location by Scroll](https://maplibre.org/maplibre-gl-js/docs/examples/fly-to-a-location-based-on-scroll-position/)
- [Slowly Fly to a Location](https://maplibre.org/maplibre-gl-js/docs/examples/slowly-fly-to-a-location/)
- [Jump to Series of Locations](https://maplibre.org/maplibre-gl-js/docs/examples/jump-to-a-series-of-locations/)

### 🎨 Style / Visual (12)
- [Satellite Map](https://maplibre.org/maplibre-gl-js/docs/examples/display-a-satellite-map/)
- [Gradient Line](https://maplibre.org/maplibre-gl-js/docs/examples/create-a-gradient-line-using-an-expression/)
- [Gradient Dashed Line](https://maplibre.org/maplibre-gl-js/docs/examples/create-a-gradient-dashed-line-using-an-expression/)
- [Data-driven Line Style](https://maplibre.org/maplibre-gl-js/docs/examples/style-lines-with-a-data-driven-property/)
- [Change Layer Color](https://maplibre.org/maplibre-gl-js/docs/examples/change-a-layers-color-with-buttons/)
- [Hover Effect](https://maplibre.org/maplibre-gl-js/docs/examples/create-a-hover-effect/)
- [Polygon Pattern](https://maplibre.org/maplibre-gl-js/docs/examples/add-a-pattern-to-a-polygon/)
- [Canvas Source](https://maplibre.org/maplibre-gl-js/docs/examples/add-a-canvas-source/)
- [Add a Video](https://maplibre.org/maplibre-gl-js/docs/examples/add-a-video/)
- [Stretchable Image](https://maplibre.org/maplibre-gl-js/docs/examples/add-a-stretchable-image/)
- [Animated Icon](https://maplibre.org/maplibre-gl-js/docs/examples/add-an-animated-icon-to-the-map/)
- [Generated Icon](https://maplibre.org/maplibre-gl-js/docs/examples/add-a-generated-icon-to-the-map/)

### 📊 Visualization / Data (9)
- [Heatmap Layer](https://maplibre.org/maplibre-gl-js/docs/examples/create-a-heatmap-layer/)
- [Style Clusters](https://maplibre.org/maplibre-gl-js/docs/examples/create-and-style-clusters/)
- [HTML Clusters](https://maplibre.org/maplibre-gl-js/docs/examples/display-html-clusters-with-custom-properties/)
- [Population Density](https://maplibre.org/maplibre-gl-js/docs/examples/visualize-population-density/)
- [Update Feature Realtime](https://maplibre.org/maplibre-gl-js/docs/examples/update-a-feature-in-realtime/)
- [Live Realtime Data](https://maplibre.org/maplibre-gl-js/docs/examples/add-live-realtime-data/)
- [Time Slider](https://maplibre.org/maplibre-gl-js/docs/examples/create-a-time-slider/)
- [deck.gl REST API](https://maplibre.org/maplibre-gl-js/docs/examples/create-deckgl-layer-using-rest-api/)
- [Toggle deck.gl](https://maplibre.org/maplibre-gl-js/docs/examples/toggle-deckgl-layer/)

### 🌐 Interactive / UI (18)
- [Display a Map](https://maplibre.org/maplibre-gl-js/docs/examples/display-a-map/)
- [Popup on Click](https://maplibre.org/maplibre-gl-js/docs/examples/display-a-popup-on-click/)
- [Popup on Hover](https://maplibre.org/maplibre-gl-js/docs/examples/display-a-popup-on-hover/)
- [Draggable Marker](https://maplibre.org/maplibre-gl-js/docs/examples/create-a-draggable-marker/)
- [Draggable Point](https://maplibre.org/maplibre-gl-js/docs/examples/create-a-draggable-point/)
- [Default Marker](https://maplibre.org/maplibre-gl-js/docs/examples/add-a-default-marker/)
- [Custom Icons](https://maplibre.org/maplibre-gl-js/docs/examples/add-custom-icons-with-markers/)
- [Symbol on Click](https://maplibre.org/maplibre-gl-js/docs/examples/center-the-map-on-a-clicked-symbol/)
- [Polygon Info on Click](https://maplibre.org/maplibre-gl-js/docs/examples/show-polygon-information-on-click/)
- [Filter by Text Input](https://maplibre.org/maplibre-gl-js/docs/examples/filter-symbols-by-text-input/)
- [Filter by Toggle List](https://maplibre.org/maplibre-gl-js/docs/examples/filter-symbols-by-toggling-a-list/)
- [Filter within Layer](https://maplibre.org/maplibre-gl-js/docs/examples/filter-within-a-layer/)
- [Features Under Mouse](https://maplibre.org/maplibre-gl-js/docs/examples/get-features-under-the-mouse-pointer/)
- [Box Zoom Selection](https://maplibre.org/maplibre-gl-js/docs/examples/select-features-with-boxzoomend-callback/)
- [Display a Popup](https://maplibre.org/maplibre-gl-js/docs/examples/display-a-popup/)
- [Popup on Marker](https://maplibre.org/maplibre-gl-js/docs/examples/attach-a-popup-to-a-marker-instance/)
- [Add an Icon to the Map](https://maplibre.org/maplibre-gl-js/docs/examples/add-an-icon-to-the-map/)
- [Filter Symbols Using Global State](https://maplibre.org/maplibre-gl-js/docs/examples/filter-layer-symbols-using-global-state/)

### 🗺️ GeoJSON / Data (7)
- [Add a GeoJSON Line](https://maplibre.org/maplibre-gl-js/docs/examples/add-a-geojson-line/)
- [Add a GeoJSON Polygon](https://maplibre.org/maplibre-gl-js/docs/examples/add-a-geojson-polygon/)
- [Multiple Geometries from One Source](https://maplibre.org/maplibre-gl-js/docs/examples/add-multiple-geometries-from-one-geojson-source/)
- [Draw GeoJSON Points](https://maplibre.org/maplibre-gl-js/docs/examples/draw-geojson-points/)
- [Update GeoJSON Polygons](https://maplibre.org/maplibre-gl-js/docs/examples/update-geojson-polygons/)
- [View Local GeoJSON](https://maplibre.org/maplibre-gl-js/docs/examples/view-local-geojson/)
- [View Local GeoJSON (experimental)](https://maplibre.org/maplibre-gl-js/docs/examples/view-local-geojson-experimental/)

### 🛰️ Other Notable (12)
- [360 Photosphere](https://maplibre.org/maplibre-gl-js/docs/examples/enter-a-360-photosphere/)
- [Render World Copies](https://maplibre.org/maplibre-gl-js/docs/examples/render-world-copies/)
- [Set Pitch & Bearing](https://maplibre.org/maplibre-gl-js/docs/examples/set-pitch-and-bearing/)
- [Center Above Ground](https://maplibre.org/maplibre-gl-js/docs/examples/set-center-point-above-ground/)
- [Vanishing Point Padding](https://maplibre.org/maplibre-gl-js/docs/examples/offset-the-vanishing-point-using-padding/)
- [Map Transform](https://maplibre.org/maplibre-gl-js/docs/examples/customize-the-map-transform-constrain/)
- [Level of Detail](https://maplibre.org/maplibre-gl-js/docs/examples/level-of-detail-control/)
- [Rich Text Labels](https://maplibre.org/maplibre-gl-js/docs/examples/display-and-style-rich-text-labels/)
- [Variable Label Placement](https://maplibre.org/maplibre-gl-js/docs/examples/variable-label-placement/)
- [Across 180th Meridian](https://maplibre.org/maplibre-gl-js/docs/examples/display-line-that-crosses-180th-meridian/)
- [Geocode Nominatim](https://maplibre.org/maplibre-gl-js/docs/examples/geocode-with-nominatim/)
- [Sync Multiple Maps](https://maplibre.org/maplibre-gl-js/docs/examples/sync-movement-of-multiple-maps/)

## 5-minute quickstart

```ts
import maplibregl from 'maplibre-gl';

const map = new maplibregl.Map({
  container: 'map',
  style: {
    version: 8,
    sources: {
      osm: {
        type: 'raster',
        tiles: ['https://tile.openstreetmap.org/{z}/{x}/{y}.png'],
        tileSize: 256,
      },
      terrain: {
        type: 'raster-dem',
        tiles: ['https://elevation-tiles-prod.s3.amazonaws.com/terrarium/{z}/{x}/{y}.png'],
        encoding: 'terrarium',
        tileSize: 256,
      },
    },
    layers: [{ id: 'osm', type: 'raster', source: 'osm' }],
    terrain: { source: 'terrain', exaggeration: 1.5 },
  },
  center: [127, 37.5],
  zoom: 4,
  pitch: 60,           // 3D 깊이
  projection: 'globe', // 행성으로 변환
  maxPitch: 85,
});
```

Add `map.setFog({})` in `style.load` for atmosphere.

## Pitfalls (maplibre-specific)

1. **Don't use the GLSL `fog_max` technique from Globe.gl** — maplibre has `setFog()`,
   use it instead. Custom shaders fight the library.
2. **Tile-based, not point-based** — visualizing 42K points is slow. Use clustering
   (built-in `cluster: true` on GeoJSON sources) or fall back to Globe.gl.
3. **`maxPitch: 85`** is the hard limit. Setting `pitch: 90` silently fails.
4. **globe projection requires v3+** — older maplibre-gl-js doesn't support it.
5. **Raster-dem tiles are 256×256**. For 512×512 retina, set `tileSize: 512` and use
   `maxzoom: 14` to avoid blurry edges.
6. **`fill-extrusion` requires a polygon GeoJSON**. To extrude points, you need a
   custom layer or convert points to small polygons first.
7. **OpenFreeMap style URL is heavy** (~3MB JSON). Load it once, cache aggressively.
8. **Pitch + bearing combos can flip the up vector** — bind them explicitly when
   animating to avoid mid-animation disorientation.

## When to use this reference vs the main SKILL.md

- **Main skill** (Globe.gl + spatial grid + 4K-point optimization) → use for: point
  clouds, lat/lng-heavy datasets, simple marker visualizations.
- **This reference** (maplibre-gl-js + 3D terrain + atmosphere) → use for: 3D depth
  requirement, GeoJSON-heavy, terrain/extrusion, real-time vector data.

**Hybrid pattern**: maplibre for the globe + terrain + atmosphere, Globe.gl as an
overlay layer for point clouds. Both libraries coexist via `map.addLayer()` custom
layers — but requires Three.js bridge and is heavy. Avoid unless necessary.
