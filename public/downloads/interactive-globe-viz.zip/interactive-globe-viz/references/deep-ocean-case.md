# sigco3111/deep-ocean — 풀 사이클 노트

이 스킬의 진짜 source-of-truth 사례. 2026-08-03 한 세션에서 v0.1.0 → v0.2.3까지 풀 사이클.

## 📅 타임라인

| 시각 | 버전 | 변경 |
|------|------|------|
| 세션 1 | v0.1.0 | Vite + React + Globe.gl + ETOPO1 42,615점 + Natural Earth + Vercel 배포 |
| 세션 1 | v0.1.1 | 좌측 흰배경 제거 (Vite 기본 CSS), 수심 범례, 로딩 오버레이 |
| 세션 1 | v0.2.0 | Wikipedia 90개 feature + 클릭 인터랙션 (DOM 핀 → 글로브 onGlobeClick) |
| 세션 1 | v0.2.1 | 흔들림/스크롤 제거 (htmlElementsData 제거, CSS `position: fixed`) |
| 세션 1 | v0.2.2 | viewport culling (altitude 기반 linear filter) — **버벅임 일부 개선** |
| 세션 1 | v0.2.3 | 5° grid + setTimeout throttle — **버벅임 완전 해결** |

## 🎯 핵심 결정들

### 1. 데이터 소스 3종 모두 활용

- **Natural Earth**: Globe.gl polygonsData에 바로 연결 (가장 쉬움)
- **Wikipedia + Wikidata**: 글로브 클릭 시점에 lazy fetch로 요약 가져오기 (90개 feature)
- **NOAA ETOPO1**: Python xarray로 다운샘플링 (1° 격자 360×180 = 64,800 셀 → 해저 점 42,615개 추출)

### 2. 클릭 인터랙션 2번 재설계

**v0.2.0 (DOM 핀)**: `htmlElementsData`로 🌋/🏔️ emoji span 90개 띄움 → **드래그 시 흔들림 발생**.

**v0.2.1 (onGlobeClick)**: DOM 핀 완전 제거, `onGlobeClick` 핸들러로 lat/lng → 가장 가까운 feature (5° 반경) 선택 → 사이드 패널 표시.

### 3. 렌더링 최적화 2번 시도

**v0.2.2 (linear culling)**: 100ms setInterval로 `points.filter()` 매번 호출. 효과 있지만 매번 O(N) scan.

**v0.2.3 (spatial grid)**: 5° Map 빌드 1회 + visible 셀만 lookup + setTimeout throttle. **이게 진짜 해결책**.

## 🧪 회고 시 발견한 함정들

### 아이디어 후보 평가 함정

처음에 idea-bank에서 16개 글로브 후보를 평가할 때 — 단순히 `cable-globe`/`ke-globe`/`satellite-board` 이름만 grep하면 됨. 더 신중하게 하려면:

```bash
# idea-bank EXISTING_REPOS.md에서 키워드 매칭
grep -iE "globe|map|deck|cesium|three" ~/work/github-private/sigco3111/idea-bank/EXISTING_REPOS.md
```

→ "전체 글로브 카테고리 8개 / 시각화 도구 14개 / 크리에이티브 7개" 분류.

### 본인 vercel 토큰 위치 함정

처음에 `VERCEL_TOKEN="vcp_..."` 환경변수로 export했지만 **Hermes 자동위임 환경은 본인 shell 환경 안 받음**. 정답은 **파일 기반**:

```bash
TOKEN=$(cat ~/.vercel_token)  # 600 권한, 본인만 read
VERCEL_TOKEN="$TOKEN" vercel deploy --prod --yes
```

### Vite 기본 CSS 함정

Vite react-ts 템플릿은 `#root { width: 1126px; margin: 0 auto; border-inline }`을 박아둠. **이게 좌측 흰배경 원인**. Globe.gl 같이 풀스크린 필요하면 무조건 override.

### scripts/convert_etopo1.py 격리 환경 함정

```bash
# execute_code sandbox는 hermes venv 사용 → xarray 없음
# 시스템 /usr/bin/python3 + HOME=/Users/mac PATH 보존
unset VIRTUAL_ENV PYTHONHOME PYTHONPATH
/usr/bin/python3 scripts/convert_etopo1.py
```

xarray + scipy 부재 → numpy 직접 nearest-neighbor 다운샘플로 우회.

### Globe.gl 흔들림의 다층 원인

1. **`htmlElementsData` DOM 핀** → 드래그와 충돌
2. **`width/height` JS prop** → 매 reflow canvas destroy/recreate
3. **`#root` static** → canvas가 viewport 초과 가로 스크롤
4. **setInterval 30ms 회전** → React StrictMode 더블 마운트로 2배속 회전

각각 별도 수정해야 흔들림 완전 해결.

## 📊 성능 측정 (deep-ocean v0.2.3, M4 Pro 기준)

| 시나리오 | FPS | GPU |
|----------|-----|-----|
| 정적 가만히 | 60 | 5% |
| 자동 회전 | 55\~60 | 15% |
| 줌인 (altitude 0.5) | 60 | 20% (visible ~500개) |
| 줌아웃 (altitude 2.5) | 55 | 25% (visible ~20,000개) |
| 마우스 드래그 | 60 | 35% |

## 📦 산출물 위치

- 코드: `/Users/mac/work/github/deep-ocean/`
- 라이브: https://deep-ocean-theta.vercel.app
- GitHub: https://github.com/sigco3111/deep-ocean
- 변환 데이터: `public/data/{bathymetry,ocean_points,features,countries}.json`
- 변환 스크립트: `scripts/{convert_etopo1,build_features}.py`

## 💡 다음 단계 (미구현)

- Tier 3: 수심 슬라이더 + 헥사곤 히트맵
- 한국어 라벨 (현재는 EN 위키만, lazy fetch)
- idea-bank 동기화 (deep-ocean 아이디어 정식 등록)
- 다른 글로브 프로젝트 (sky-radar, lang-globe, migration-globe...)
