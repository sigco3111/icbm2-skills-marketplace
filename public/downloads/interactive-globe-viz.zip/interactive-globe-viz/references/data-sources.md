# Globe.gl 데이터 소스 통합 — 검증된 패턴

Globe.gl 프로젝트에서 자주 쓰는 무료 데이터 소스 + 각 함정. sigco3111/deep-ocean v0.1.0\~v0.2.0 실측.

## 📊 소스 3종 비교

| 소스 | 크기 | 형식 | 사용 시점 |
|------|------|------|---------|
| **Natural Earth 110m** | 725KB | GeoJSON | 즉시. Globe.gl polygonsData에 직결 |
| **Wikipedia + Wikidata** | ~50KB 결과 | JSON | feature 50\~200개 — 카테고리 멤버 + P625 좌표 |
| **NOAA ETOPO1** | 300MB → 1.9MB | NetCDF → JSON | 해저/지형 점 4만+. 변환 필수 |

## 🟢 Natural Earth (즉시 사용)

```bash
curl -sL "https://raw.githubusercontent.com/martynafford/natural-earth-geojson/master/110m/cultural/ne_110m_admin_0_countries.json" -o public/data/countries.json
```

- `features[].geometry` → Globe.gl `polygonsData` 직접 사용
- 177개국, polygon stroke + cap color만 지정하면 끝
- 다른 해상도: 50m (5MB), 10m (50MB+) — Globe.gl엔 110m이 최적

## 🟡 Wikipedia + Wikidata (50\~200개 feature)

### ❌ Wikidata SPARQL `wdt:P31 wd:Qxxx` 함정

처음 시도: `SELECT ?item WHERE { ?item wdt:P31 wd:Q23498 }` (해구) → **0\~10개 결과만 나옴**. 위키 편집자마다 P31 분류가 일관성 없어서 많은 item이 다른 parent type에 속함.

**해결**: Wikipedia category member API가 더 안정적.

### ✅ 안정 패턴: EN 위키 카테고리 멤버 → 위키테이션 좌표

```python
# 1) 카테고리 멤버 수집
categories = [
    "Category:Oceanic_trenches_of_the_Pacific_Ocean",
    "Category:Submarine_volcanoes",
    "Category:Seamounts",
]
for cat in categories:
    url = f"https://en.wikipedia.org/w/api.php?action=query&list=categorymembers&cmtitle={cat}&cmlimit=50&format=json&cmtype=page"
    # 페이지네이션: cmcontinue 반복

# 2) 각 제목 → pageprops.wikibase_item 추출
# 3) Wikidata SPARQL 배치: P625 (좌표) 일괄 조회
sparql = """SELECT ?item ?coord WHERE {
    VALUES ?item { wd:Q1 wd:Q2 ... }
    ?item wdt:P625 ?coord .
}"""
```

### ⚠️ 한국어 라벨 함정

`action=query&prop=langlinks&lllang=ko`로 한국어 라벨 일괄 가져오기 시 **rate limit 429 (Too Many Requests)** 빈번. 

**해결**: EN 라벨만 저장하고, 클릭 시 `https://ko.wikipedia.org/api/rest_v1/page/summary/{title}`로 lazy fetch (rate limit 안 걸림).

### ✅ 매핑 결과 (deep-ocean 검증)
- 110개 제목 → 90개 좌표 추출 (20%는 좌표 없음)
- 해구 35개 (Mariana, Aleutian, Japan, Izu-Ogasawara...)
- 해저 화산 55개 (Adams, Bowie, Brothers, Apolaki...)

## 🔴 NOAA ETOPO1 (해저 깊이)

### 데이터 흐름

```
NOAA ETOPO1 NetCDF (376MB 압축 / 890MB 압축해제)
  → xarray.open_dataset()
  → lat/lon/x/y 좌표 추론
  → numpy 다운샘플링 (60 arc-second → 1° = 360×180)
  → JSON 저장 (1.9MB)
```

### ⚠️ ETOPO1 좌표 함정

ETOPO1 grd.gz는 좌표가 `lat/lon`이 아니라 **`x/y`** 일 수 있음 (sph2grid 변환된 형태). 반드시 확인:

```python
ds = xr.open_dataset('ETOPO1.nc', engine='netcdf4')
print(f"dims: {dict(ds.dims)}")  # {'x': 21601, 'y': 10801}
print(f"coords: {list(da.coords)}")  # ['x', 'y']일 가능성

# coords 값으로 추론: x 범위가 -180~180 = lon, y 범위가 -90~90 = lat
```

### ⚠️ 격리된 Python 환경

`/usr/bin/python3`는 시스템 Python (PEP 668 무관, lib access 가능). `execute_code` sandbox는 hermes-venv 가서 xarray 못 봄. **반드시 terminal로 격리 실행**:

```bash
unset VIRTUAL_ENV PYTHONHOME PYTHONPATH
/usr/bin/python3 scripts/convert_etopo1.py
```

`xarray` + `netCDF4`는 시스템 pip으로 설치 (Homebrew python):
```bash
env -i HOME=/Users/mac PATH=/usr/local/bin:/usr/bin:/bin \
  /usr/bin/pip3 install --user xarray netCDF4
```

### ⚠️ scipy 없는 환경

xarray의 `interp(method='linear')`는 scipy 필요. **대안**: numpy 직접 nearest-neighbor 다운샘플:

```python
def nearest_idx(arr, vals):
    return np.array([np.argmin(np.abs(arr - v)) for v in vals])

lat_idx = nearest_idx(orig_lat, target_lats)
lon_idx = nearest_idx(orig_lon, target_lons)
z = z_full[np.ix_(lat_idx, lon_idx)]
```

## 🔍 검증 한 줄 API 테스트

```bash
# NOAA ETOPO1
curl -sI "https://www.ngdc.noaa.gov/mgg/global/relief/ETOPO1/data/ice_surface/grid_registered/netcdf/ETOPO1_Ice_g_gmt4.grd.gz" | head -1

# Wikidata SPARQL (인증 없이 가능, Accept 헤더 빼야 200)
curl -s -G "https://query.wikidata.org/sparql" \
  --data-urlencode "query=SELECT ?item WHERE { ?item wdt:P31 wd:Q23498 } LIMIT 5" \
  -H "Accept: application/json" | python3 -c "import json,sys; print(len(json.load(sys.stdin).get('results',{}).get('bindings',[])))"

# Wikipedia REST summary
curl -s "https://ko.wikipedia.org/api/rest_v1/page/summary/마리아나_해구" | python3 -c "import json,sys; print(json.load(sys.stdin).get('title'))"
```
