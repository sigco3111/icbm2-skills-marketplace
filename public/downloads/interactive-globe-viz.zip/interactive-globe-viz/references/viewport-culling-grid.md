# Viewport Culling + 5° Spatial Grid — 풀 패턴

Globe.gl에서 **수천 개 이상 점**을 효율적으로 렌더링하는 검증된 패턴. sigco3111/deep-ocean v0.2.2 → v0.2.3 실측 기준 PC 버벅임이 사실상 사라짐.

## 🚨 증상 (이 패턴이 필요한 신호)

- 글로브 회전 시 PC가 끊기듯 버벅임 (CPU/GPU 점유율 급상승)
- 42,000+ 점이 매 프레임 렌더링되어 보임 (DevTools Performance 탭에서 점 점유율 확인 가능)
- 점 데이터는 정적인데 매 프레임 React 리렌더 발생

## 🎯 핵심 개념 3가지

### 1. Spatial Grid (5° 셀 Map)

전체 점을 격자로 한 번만 빌드. lookup O(1) 평균.

```ts
const GRID_SIZE = 5;  // 5° 셀

function gridKey(lat: number, lon: number): string {
  return `${Math.floor((lat + 90) / GRID_SIZE)}:${Math.floor((lon + 180) / GRID_SIZE)}`;
}

function buildOceanGrid(points: readonly OceanPoint[]): Map<string, OceanPoint[]> {
  const grid = new Map<string, OceanPoint[]>();
  for (const point of points) {
    const key = gridKey(point.lat, point.lon);
    const cell = grid.get(key);
    if (cell) cell.push(point);
    else grid.set(key, [point]);
  }
  return grid;
}
```

**왜 5°?** Globe.gl altitude 1.0에서 약 28° 가시 스팬 → 셀 5\~6개만 lookup. 더 작으면(1°) 셀이 너무 많아져서 Map 사이즈만 커지고 효과 없음. 더 크면(10°) 한 셀에 너무 많은 점이 들어.

### 2. Viewport Culling (altitude 기반)

카메라 altitude에 비례해 가시 lat/lng 영역 계산. zoom-in → 좁은 영역, zoom-out → 넓은 영역.

```ts
const VIEWPORT_OVERSCAN = 1.6;  // 60% 여유분 (회전 중 깜빡임 방지)

function visibleOceanPoints(
  grid: ReadonlyMap<string, readonly OceanPoint[]>,
  view: Viewport,
): OceanPoint[] {
  // altitude 1.0 → 28° 스팬, altitude 0.5 → 14°, altitude 2.5 → 70°
  const span = Math.min(180, Math.max(8, view.altitude * 28)) * VIEWPORT_OVERSCAN;
  const minLat = Math.max(-90, view.lat - span / 2);
  const maxLat = Math.min(90, view.lat + span / 2);
  const minLng = view.lng - span / 2;
  const maxLng = view.lng + span / 2;

  const points: OceanPoint[] = [];
  // 가시 영역의 격자 셀만 lookup — O(가시 셀 수)
  for (let lat = Math.floor((minLat + 90) / GRID_SIZE); lat <= Math.floor((maxLat + 90) / GRID_SIZE); lat++) {
    for (let lon = Math.floor((minLng + 180) / GRID_SIZE); lon <= Math.floor((maxLng + 180) / GRID_SIZE); lon++) {
      // ⚠️ lon wraparound: dateline 넘어가는 셀 안전 처리
      const cell = grid.get(`${lat}:${((lon % 72) + 72) % 72}`);
      if (cell) points.push(...cell);
    }
  }
  return points;
}
```

**lon wraparound 함정**: longitude는 ±180° 범위인데, minLng가 -200° 같은 값이 되면 셀 인덱스가 음수가 됨. `((lon % 72) + 72) % 72` 패턴으로 항상 0\~71 범위로 정규화.

**OVERSCAN 1.6이 필요한 이유**: 회전 인터벌(120ms) 동안 점이 viewport 경계에서 깜빡이지 않게 여유분 확보. 너무 크면(>2) 불필요한 점까지 렌더링.

### 3. setTimeout Throttle (setInterval 아님)

`setInterval`은 매 tick마다 **무조건** setState 호출 → 같은 visible이라도 React 리렌더 발생. throttle로 한 번에 한 setState만:

```tsx
const CAMERA_UPDATE_MS = 120;  // ~8 FPS — 충분히 부드럽고 GPU 부담 적음

useEffect(() => {
  let timeoutId: ReturnType<typeof setTimeout> | undefined;

  const updateVisiblePoints = () => {
    timeoutId = undefined;
    if (!globeEl.current || !oceanPoints.length) return;
    setVisiblePoints(visibleOceanPoints(oceanGrid, globeEl.current.pointOfView()));
  };

  const scheduleUpdate = () => {
    // 살아있는 timeout 있으면 스킵 — throttle 핵심
    if (timeoutId === undefined) timeoutId = setTimeout(updateVisiblePoints, CAMERA_UPDATE_MS);
  };

  updateVisiblePoints();  // 초기 1회

  // window resize도 viewport 갱신 필요
  window.addEventListener('resize', scheduleUpdate);
  const id = setInterval(scheduleUpdate, CAMERA_UPDATE_MS);

  return () => {
    if (timeoutId !== undefined) clearTimeout(timeoutId);
    clearInterval(id);
    window.removeEventListener('resize', scheduleUpdate);
  };
}, [oceanGrid, oceanPoints.length]);  // grid 변경 시에만 재빌드
```

## 🎯 흔들림 진단

글로브가 **좌우로 흔들리거나 스크롤되는** 별개 증상은 references/dom-html-elements-jitter.md (별도 추가 예정) 또는 아래 빠른 진단:

1. **`htmlElementsData` 사용했나?** → ❌ 즉시 제거하고 `onGlobeClick` + spatial lookup으로 변경
2. **`width/height={window.innerWidth}` prop 사용했나?** → ❌ 즉시 제거, CSS `100vw/100vh !important`로 강제
3. **`#root { position: fixed }` 누락?** → ❌ 추가
4. **여전히 흔들림** → Globe.gl 자체 인터랙션 + Three.js OrbitControls 충돌 가능 → `controls()` prop 명시적 disable

## 📊 성능 비교 (deep-ocean 실측)

| 조건 | FPS | GPU 점유 |
|------|-----|----------|
| 42,615개 한 번에 렌더링 (v0.2.1) | 12\~18 FPS | 60\~80% |
| + viewport culling (v0.2.2) | 30\~45 FPS | 30\~50% |
| + 5° grid + throttle (v0.2.3) | **55\~60 FPS** | **15\~25%** |

(대략치. PC 사양에 따라 다름)
