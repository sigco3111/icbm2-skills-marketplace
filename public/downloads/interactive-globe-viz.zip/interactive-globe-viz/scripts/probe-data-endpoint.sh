#!/usr/bin/env bash
# Probe a list of public data endpoints for liveness.
# Usage: probes.sh [urls.txt]
# Each line: <name>|<url>
# Output: <status>|<name>|<bytes>|<elapsed_s>|<url>

set -u

probe() {
  local name="$1" url="$2"
  local start size http
  start=$(date +%s.%N)
  # -L follows redirects; -s silent; -w writes final size to stderr
  size=$(curl -sL -A "Mozilla/5.0" -o /dev/null -w "%{http_code}|%{size_download}" \
    --max-time 10 "$url" 2>/dev/null || echo "ERR|0")
  local elapsed
  elapsed=$(echo "$(date +%s.%N) - $start" | bc)

  IFS='|' read -r http size <<< "$size"
  if [[ "$http" =~ ^(2[0-9][0-9]|3[0-9][0-9])$ ]]; then
    printf "✅ %-30s | HTTP %s | %s bytes | %.2fs\n" "$name" "$http" "$size" "$elapsed"
  else
    printf "❌ %-30s | HTTP %s | %s bytes | %.2fs\n" "$name" "$http" "$size" "$elapsed"
  fi
}

if [ $# -ge 1 ] && [ -f "$1" ]; then
  while IFS='|' read -r name url; do
    [ -z "$name" ] && continue
    probe "$name" "$url"
  done < "$1"
else
  # Default probe list (verified 2026-08-06)
  cat <<'EOF' | while IFS='|' read -r name url; do
    [ -z "$name" ] && continue
    probe "$name" "$url"
  done
ISS real-time|http://api.open-notify.org/iss-now.json
ISS detailed|https://api.wheretheiss.at/v1/satellites/25544
USGS Earthquakes (week)|https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_week.geojson
NASA EONET events|https://eonet.gsfc.nasa.gov/api/v3/events?status=open&limit=10
Open-Meteo (Seoul)|https://api.open-meteo.com/v1/forecast?latitude=37.5&longitude=127&hourly=temperature_2m&forecast_days=1
OpenFlights airports|https://raw.githubusercontent.com/jpatokal/openflights/master/data/airports.dat
GBFS NYC Citi Bike|https://gbfs.citibikenyc.com/gbfs/gbfs.json
Wikipedia geosearch|https://en.wikipedia.org/w/api.php?action=query&list=geosearch&gscoord=37.5|127&gsradius=5000&format=json
OpenSky (will fail)|https://opensky-network.org/api/states/all
OpenAQ (will fail)|https://api.openaq.org/v2/latest?limit=10
EOF
fi
