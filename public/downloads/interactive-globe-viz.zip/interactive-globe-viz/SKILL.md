---
name: interactive-globe-viz
description: "Globe.gl/react-globe.gl 프로젝트 부트스트랩. 4만+ 점 성능 최적화 신호."
trigger: "Globe.gl / maplibre-gl-js / react-globe.gl / three-globe 기반 인터랙티브 3D 글로브·지도 시각화 프로젝트 부트스트랩 또는 성능 최적화. '글로브 시각화', '3D 지구본 데이터', '해저/지형 시각화', '포인트 4만개 렌더링', 'maplibre', 'globe with atmosphere', '3D terrain', 'sky fog' 같은 요청에 발동. 시그니처 신호: thousands of points on globe, viewport culling, Globe.gl camera jitter, maplibre globe projection, OpenFreeMap, AWS Terrarium DEM. maplibre-gl-js branch는 references/maplibre-gl-js-branch.md 참조."
version: 0.2.0
author: icbm2
metadata:
  hermes:
    tags: [globe-gl, react-globe.gl, three-globe, maplibre-gl-js, openfreemap, terrarium-dem, webgl, data-viz, performance, viewport-culling, spatial-grid, 3d-terrain, atmosphere]
    related_skills: [pixijs-v8-pitfalls, canvas-static-site-pipeline, python-oss-bootstrap]
status: battle-tested-deep-ocean + maplibre-branch-verified-2026-08-06
---

# Interactive Globe.gl Data Viz — Class-Level Workflow

Globe.gl (`react-globe.gl`, `globe.gl`, `three-globe`) 기반 **인터랙티브 3D 글로브 데이터 시각화** 프로젝트의 class-level 워크플로. 검증 사례: sigco3111/deep-ocean — NOAA ETOPO1 42,615개 해저 점 + Wikipedia 90개 feature (해구/화산) + Vercel 배포까지 풀 사이클.

## ⚠️ 시그니처 함정 — 4만개 점 한 번에 렌더링

Globe.gl `<Globe pointsData={...}>`는 prop으로 받은 배열의 **모든 점**을 매 프레임 렌더링합니다. 점 1\~2천 개까지는 부드럽지만, **4만 개 이상**이 되면:

- GPU가 점 1개당 pixel-perfect culling 못 함 → PC 버벅임
- 100ms setInterval로 `pointsData` 새 배열 교체해도 React + WebGL 양쪽에서 매번 전체 리셋
- 카메라 줌인해도 **가려진 점들도 계속 그려짐** (성능 낭비)

**해결 패턴** (v0.2.2 → v0.2.3 검증):
1. **spatial grid**: 한 번만 빌드, 5° 셀 Map
2. **viewport culling**: 카메라 altitude 기반 lat/lng 가시 영역 계산, 가시 셀만 lookup
3. **setTimeout throttle**: setInterval이 매번 setState 호출 안 하게, 살아있는 timeout 체크

→ references/viewport-culling-grid.md에 풀 코드 + 단계별 가이드.

## 🌐 Globe.gl vs maplibre-gl-js — Choose first

The user has been doing explicit narrowing in this class of work:
"멋진 비주얼" → "비용/API 키 0" → "구체 저장소" → "공식 예제 사용 가능?".

**Default to the user's narrowing pattern**: don't bundle 50 examples. Start with
~10 candidates, expect the user to narrow on cost/no-cost, then on specific repos,
then on official examples. The narrowing signal is **always** about reducing the
search space, not expanding it.

**Globe.gl branch** (this skill, primary):
- 4K+ point clouds optimized via spatial grid + viewport culling
- Smooth lat/lng sphere rendering
- Custom Three.js scene control
- Sea/terrain/entertainment viz

**maplibre-gl-js branch** (see references/maplibre-gl-js-branch.md):
- 3D terrain via raster-dem + AWS Terrarium
- Atmosphere via `setFog()` + `projection: 'globe'`
- 3D buildings via fill-extrusion
- GeoJSON-heavy / tile-based datasets
- Free public data sources (no API key)

**Default to maplibre-gl-js** when the user's first request mentions any of:
atmosphere, terrain, buildings, GeoJSON, vector tiles, real-time data feed.
**Default to Globe.gl** when the user mentions: points on a sphere, ping/rings,
giant point clouds, or no terrain/buildings requirements.

## 🌐 Globe.gl 기본 워크플로

### Phase 0: 데이터 소스 결정 (Free API 우선)

Globe.gl 프로젝트는 보통 다음 중 하나를 시각화:

| 도메인 | 무료 소스 |
|--------|---------|
| 해저/지형 | NOAA ETOPO1 (300MB NetCDF → 1° 격자 JSON), GEBCO |
| 국가 경계 | Natural Earth 110m GeoJSON (725KB, 즉시 사용) |
| 지리 feature (해구/화산/산맥) | Wikipedia category API + Wikidata P625 좌표 |
| 실시간 항공/위성 | OpenSky Network, Launch Library |
| 시뮬레이션 | 자체 생성 |

**반드시 검증**: Wikipedia REST summary API는 `https://{lang}.wikipedia.org/api/rest_v1/page/summary/{title}` — 글로브 위 핀 클릭 → lazy fetch 패턴.

### Phase 1: Vite + React + TS 스캐폴드

```bash
npm create vite@latest . -- --template react-ts -y
npm install react-globe.gl three three-globe @types/three
```

핵심 deps:
- `react-globe.gl` (React wrapper)
- `three` + `three-globe` (WebGL 코어)
- `@types/three` (TS 타입)

Globe.gl 기본 prop 셋업 (베이스 코드):
```tsx
<Globe
  globeImageUrl="//unpkg.com/three-globe/example/img/earth-blue-marble.jpg"
  bumpImageUrl="//unpkg.com/three-globe/example/img/earth-topology.png"
  backgroundColor="rgba(0,0,0,0)"
  polygonsData={...}      // 육지 polygon
  pointsData={...}        // 데이터 점
  ringsData={...}         // 위치 pulsing ring
  onGlobeClick={...}      // 캔버스 직접 클릭 핸들러
  // ❌ htmlElementsData={...} ← 흔들림 원인, 절대 쓰지 말 것
  // ❌ width/height={window.innerWidth} ← 매 프레임 reflow
/>
```

### Phase 2: HTML 구조 (overflow 가드)

Globe.gl은 canvas에 `position: absolute` 박는데, **`#root`가 `position: fixed` 아니면 가로 스크롤 발생**:

```css
html, body { margin: 0; padding: 0; overflow: hidden; touch-action: none; overscroll-behavior: none; }
#root { width: 100vw; height: 100vh; position: fixed; top: 0; left: 0; overflow: hidden; }
#root canvas { width: 100vw !important; height: 100vh !important; position: absolute !important; }
```

### Phase 3: 데이터 통합

#### 3-A. Natural Earth (즉시)
- `https://raw.githubusercontent.com/martynafford/natural-earth-geojson/master/110m/cultural/ne_110m_admin_0_countries.json`
- Globe.gl `polygonsData`로 직접 사용

#### 3-B. Wikipedia + Wikidata (해구/화산)
- EN 위키 카테고리: `Pacific_trenches`, `Submarine_volcanoes`, `Seamounts`
- 카테고리 멤버 → 각 제목의 Wikidata item → P625 좌표
- Python 일괄 변환 → `features.json` (~50KB)
- Globe.gl `ringsData`로 시각화

#### 3-C. NOAA ETOPO1 (해저 깊이)
- 300MB NetCDF → xarray + numpy 다운샘플링 (1° 격자) → TopoJSON/JSON
- 절대 좌표 (x/y)일 수 있어 coords로 lat/lon 추론 필수
- 변환 스크립트 패턴은 references/data-sources.md 참조

### Phase 4: 클릭 인터랙션

**🚨 함정: `htmlElementsData` 절대 쓰지 마세요**

Globe.gl의 `htmlElementsData`는 DOM element를 globe 위에 띄우는데:
- 마우스 드래그와 충돌 → DOM element가 끌려가는 듯 흔들림
- 100+ element면 성능 저하

**올바른 패턴: `onGlobeClick` + spatial lookup**
```tsx
onGlobeClick={({ lat, lng }) => {
  if (!features.length) return;
  let best: Feature | null = null;
  let bestDist = Infinity;
  for (const f of features) {
    const d = Math.hypot(f.lat - lat, f.lon - lng);
    if (d < bestDist) { bestDist = d; best = f; }
  }
  if (best && bestDist < 5) handleFeatureClick(best);  // 5° 반경
}}
```

사이드 패널은 `position: absolute; right: 16px`로 띄우고, 클릭 시 카메라 자동 zoom (`pointOfView({lat, lng, altitude: 1.2}, 800)`).

## 🚀 성능 최적화 (Viewport Culling)

`oceanPoints.length > 10,000`이면 **무조건 culling 필요**. 단계별 가이드는 references/viewport-culling-grid.md 참조.

**간단 요약**:
```tsx
// 1. 5° grid 한 번만 빌드
const oceanGrid = useMemo(() => buildOceanGrid(oceanPoints), [oceanPoints]);

// 2. visible 영역 계산 (altitude 기반)
const latitudeSpan = Math.min(180, Math.max(8, view.altitude * 28)) * OVERSCAN;

// 3. setTimeout throttle로 visible setState
let timeoutId: ReturnType<typeof setTimeout> | undefined;
const scheduleUpdate = () => {
  if (timeoutId === undefined) timeoutId = setTimeout(updateVisiblePoints, CAMERA_UPDATE_MS);
};
```

## 🚢 배포

[Vercel](https://vercel.com) 무료 플랜 + GitHub 자동 deploy:
1. `~/.vercel_token` 파일에 본인 토큰 저장 (이미 있으면 활용)
2. `VERCEL_TOKEN=$(cat ~/.vercel_token) vercel deploy --prod --yes`
3. Framework: Vite (자동 감지)
4. Build: `npm run build`, Output: `dist/`

**본인 vercel 토큰 위치 검증 (Bash 함정 회피)**:
- `~/.vercel_token` 파일이 600 권한이면 `cat`으로 직접 읽기 가능
- Hermes 자동위임 환경에서는 `env | grep -i vercel`로 안 보일 수 있음 (TERMINAL_VERCEL_RUNTIME 변수가 Vercel sandbox 자체 변수)

## 📁 참조 문서

- `references/viewport-culling-grid.md` — 5° grid + throttle 풀 패턴 + 흔들림 진단
- `references/data-sources.md` — NOAA + Wikipedia + Natural Earth 통합, 각 함정
- `references/deep-ocean-case.md` — sigco3111/deep-ocean v0.1.0 → v0.2.3 풀 사이클 노트
- `references/maplibre-gl-js-branch.md` — maplibre-gl-js branch (2026-08-06): 95 visual examples catalog + verified free data sources + 5-min quickstart. **Use when the project needs 3D terrain / atmosphere / buildings / GeoJSON-heavy / no API key** (vs Globe.gl's point-cloud strength).

## 🛠️ 스크립트

- `scripts/probe-data-endpoint.sh` — Public data endpoint liveness probe. Run before any new viz integration; the 2026-08-06 session found 2 widely-recommended endpoints dead (OpenSky Network, OpenAQ). Default list covers ISS, USGS, EONET, Open-Meteo, OpenFlights, GBFS, Wikipedia, plus the known-dead ones for negative verification.

## ⚠️ 검증된 함정 (Pitfalls)

1. **`htmlElementsData` 절대 금지** — DOM이 globe 위에 떠서 drag-rotate와 충돌, 흔들림 유발. → `onGlobeClick` + spatial lookup 사용
2. **`width/height={window.innerWidth}` prop 사용 금지** — 매 프레임 reflow, canvas destroy+recreate. → CSS `100vw/100vh !important`
3. **`#root { position: fixed }` 누락** — body `overflow: hidden`만으로는 부족, canvas가 viewport 초과해서 가로 스크롤 발생
4. **Globe.gl 인터랙션이 글로브 클릭 우선** — `pointer-events: none`인 UI 패널이 아니면 글로브 클릭이 가로채김. 사이드 패널은 `pointer-events: auto` 명시
5. **Wikidata P31 SPARQL 일관성 없음** — instance 분류가 위키 편집자에 따라 다름. → **Wikipedia category API가 더 안정적**
6. **Wikipedia langlinks API rate limit (429)** — 한국어 라벨 일괄 가져오기 ❌. → EN 라벨로 시작, 위키 REST lazy fetch는 rate limit 안 걸림
7. **자동 회전 인터벌 `setInterval(..., 30)`** — React StrictMode 더블 마운트로 2개 인터벌 실행 → 회전 속도 2배. → `useEffect` cleanup 또는 single instance 패턴
8. **Globe.gl의 OrbitControls가 자동 import** — `controls()` prop 명시 안 하면 자체 컨트롤 활성화. 외부 camera control 원하면 명시적으로 disable
9. **4만+ 점 setState 100ms** — visiblePoints state 업데이트마다 React 리렌더 + WebGL buffer reset → GPU 압박. → setTimeout throttle로 120ms에 한 번만
10. **Globe.gl의 canvas inline style** — React 컴포넌트가 직접 inline style 박아서 외부 CSS override 어려움. → `!important` 강제

## ★ Twin Lab / 픽셀아트 룩 fork-first 워크플로 (2026-08-04 학습)

isometric 2.5D + 픽셀아트 사무실 (Twin Lab 류) 룩은 자기 코드로 못 따라잡음. W17ant/Claude-Office (56⭐, MIT) 같은 검증된 OSS가 이미 같은 컨셉으로 만들어져있음.

**판단 기준**:
- 사용자가 "Twin Lab 룩 1:1", "픽셀아트 사무실", "isometric control room" 류 요청
- 자기 코드 시도 5번 위임 후에도 비율/애니메이션/디테일 사용자 거절
- **MIT/Apache 라이선스** OSS 후보 확인되면 즉시 fork

**워크플로**:
1. **`git clone --depth 1 https://github.com/{oss}/{repo}.git /tmp/{repo}-fork`** (참조만)
2. 우리 repo에 **새 브랜치 `phase{N}-fork` 생성** + 이전 시도 브랜치 보존
3. fork 코드 복사 + **Electron/server 같은 우리 안 쓰는 부분 제거** (브라우저 전용)
4. **내용 교체만**: 부서명/캐릭터명/색/데이터 소스
5. **CREDITS.md** MIT 표기
6. 빌드 + dev 서버 + gh-pages 재배포

**검증된 사례**: W17ant/Claude-Office → 우리 sigco3111/hermes-control-room으로 fork + Hermes 8개 부서 매핑. ~30분 작업으로 Twin Lab 룩 거의 1:1 도달.

**vs 자기 코드 직접 작성**:
- ❌ 5번 위임 후에도 "비현실적 비율", "원본이 더 좋다" 사용자 거절
- ✅ Fork 1번으로 사용자 만족
