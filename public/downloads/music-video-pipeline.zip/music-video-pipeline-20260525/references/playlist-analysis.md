# YouTube Playlist Analysis
**Playlist:** 스트림음악 (PLoSIoPWNjwhIXO1AiaUZRLfrAMWfbiTl5)
**Total:** 116 songs

## Genre Distribution
| Genre | Approx % |
|-------|----------|
| K-Pop/J-Pop Covers | ~40% |
| Western Covers | ~30% |
| Ballad/Romantic | ~60% |
| Retro Korean | ~15% |

## Key Artists
- **K-Pop:** IU, Blackpink, GFRIEND, 비바체, 이문세, 신하울, Crush
- **Western:** Bon Jovi, MR.BIG, Richard Marx, Michael Bolton, ElyOtto
- **MBC Entertainment:** 커버세션,cover곡 위주

## Music Characteristics

| Aspect | Analysis |
|--------|----------|
| **Vocal** | Female voice dominant (cover的特性) |
| **Mood** | Romantic, sentimental, dreamy |
| **Tempo** | Mid-tempo ballad centered |
| **Instruments** | Acoustic guitar, piano based |
| **Lyrics theme** | Love, longing, warmth |
| **Duration** | 2:30 ~ 5:00 range |

## Top Viewed Tracks (Reference for style matching)
1. ElyOtto - SugarCrash! (11M views) → energetic, playful
2. Bon Jovi - Always Female Cover (2.9M) → classic rock ballad
3. Crush - 가sia (899K) → R&B/pop Korean
4. IU - Love wins all (26M) → emotional ballad
5. Kent Carter - To Be With You (35K) → acoustic romantic

## Application to Music Video Pipeline
- Generate Korean female vocal music
- Prefer ballad/R&B/acoustic styles
- Mood: warm, romantic, slightly melancholic
- Avoid: heavy metal, rap-only, speed metal

## Playlist URL
https://youtube.com/playlist?list=PLoSIoPWNjwhIXO1AiaUZRLfrAMWfbiTl5