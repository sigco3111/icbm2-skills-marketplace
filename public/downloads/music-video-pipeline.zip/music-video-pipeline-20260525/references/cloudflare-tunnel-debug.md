# Cloudflare Tunnel Debugging Notes (2026-05-24)

## Session Summary

Goal: Use Cloudflare Quick Tunnel to share music video files for Telegram review — instead of sending large files directly (storage concerns).

**Result: PARTIAL** — cloudflared installed, server running on port 8766, but HTTP 530 errors occurred.

## Root Causes Investigated

1. **Port already in use (Errno 48)** — Multiple HTTP servers and cloudflared processes accumulated
2. **HTTP 530 from Cloudflare** — Cloudflare can't reach origin server
   - Server was binding to `localhost:8766`, cloudflared pointing to `127.0.0.1:8766` — should be same, but multiple servers on same port caused conflicts
   - Quick Tunnel has no uptime SLA, may drop connections without account

## Final Working Configuration

```bash
# Kill everything first
pkill -f "python.*876" && pkill -f cloudflared
sleep 2

# 1. HTTP server — bind to 127.0.0.1 (not 0.0.0.0)
python3 -c "
import http.server, socketserver, os
os.chdir('/Users/hjshin/.hermes/music_videos')
socketserver.TCPServer.allow_reuse_address=True
http.server.HTTPServer(('127.0.0.1', 8766), http.server.SimpleHTTPRequestHandler).serve_forever()
"

# 2. Cloudflare tunnel
cloudflared --url http://127.0.0.1:8766
# Check log for: https://*.trycloudflare.com
```

## Known Issues with Quick Tunnel

- **No account**: No uptime guarantee, URL changes every restart
- **Account-linked tunnel** (free): Create via `cloudflared tunnel create <name>`, then `cloudflared tunnel route dns <name> <subdomain>.trycloudflare.com` — gives permanent URL
- **530 errors**: Usually port conflict or server not responding — verify with `curl http://127.0.0.1:8766/`

## Telegram Bot Token

Located at `~/.hermes/secrets/telegram_bot_token.txt` (not env var). Token was a placeholder (PLACEHOLDER_TOKEN_REPLACE_WITH_REAL) — actual token found in old state snapshot at:
`~/.hermes/state-snapshots/20260518-001517-pre-update/.env`

Format: `8763625036:...` ( Telegram Bot API token format: `<bot_id>:<token>`)

**For sending videos**: Use `sendVideo` API, not `sendDocument` — Telegram will handle as native video.

```bash
BOT_TOKEN=$(cat ~/.hermes/secrets/telegram_bot_token.txt | grep -v '^#' | tr -d '\n')
CHAT_ID=$(cat ~/.hermes/secrets/telegram_chat_id.txt)
curl -s -X POST "https://api.telegram.org/bot${BOT_TOKEN}/sendVideo" \
  -F "chat_id=${CHAT_ID}" \
  -F "video=@/path/to/video.mp4" \
  -F "caption=🎬 검수 요청..."
```

## Alternatives Considered

1. **Google Drive** — Upload video, share link. Works everywhere but requires upload time.
2. **GitHub release** — Upload as release asset, permanent URL, but requires commit.
3. **ngrok** — Similar to cloudflared, URL changes each session. Requires authtoken setup.