---
name: music-video-pipeline
description: End-to-end AI music video pipeline — topic generation from news, Notion approval workflow, image/music generation via MiniMax CLI, FFmpeg video composition, YouTube + Shorts upload.
version: 1.0.0
author: ICBM2
license: MIT
metadata:
  hermes:
    tags: [music, video, youtube, automation, minimax, notion, python]
    homepage: 
prerequisites:
  commands: [mmx, ffmpeg, ffprobe, python3, gh]
  env_vars: [NOTION_API_KEY]
  files:
    - ~/.hermes/secrets/notion_token.txt
    - ~/.hermes/secrets/youtube_token.pickle
    - ~/.hermes/scripts/music_video_producer.py
    - ~/.hermes/scripts/yt_upload.py
    - /tmp/yt_upload_venv/bin/python3 (venv with google-api-python-client)
    - ~/.hermes/music_videos/gallery_gh/ (git repo for GitHub Pages gallery)
---

# Music Video Pipeline

Automatically generate, approve, and publish AI music videos on YouTube from daily news topics.

## Pipeline Overview

```
10:00 Cron ──→ Reddit/X 유머/위트 주제 수집 ──→ 3 Topics ──→ Notion ──→ Telegram Alert
                                                             │
                                                             ▼
20:00 Cron ──→家主님이 선택한侯選 조회 ──→ [Process Loop]
                                              │
                        ┌─────────────────────┼─────────────────────┐
                        ▼                     ▼                     ▼
                   mmx image            mmx music            FFmpeg compose
                        │                     │                     │
                        └─────────────────────┼─────────────────────┘
                                              ▼
                                    music_video.mp4
                                              │
                         ┌────────────────────┴────────────────────┐
                         ▼                                         ▼
              ngrok review link                              Shorts (9:16)
                         │                                         │
                         ▼                                         ▼
                   Telegram review                         (uploaded with main)
                         │
                         ▼
              'confirm' ──→ YouTube Upload
                         │
                         ▼
                   Notion Status → 완료
```

## Components

### Notion DB
- **DB ID:** `36976f2e-9097-81e1-a373-e06f2da6e99c`
- **Page:** ICBM2 workspace (36376f2e-9097-8182-ab21-c5e61ae6b40a)
- **Properties:** 주제, 상태, 분위기, 음악스타일, 이미지프롬프트, 음악프롬프트, 뉴스출처, 영상경로, 유튜브URL, 생성일

### Cronjobs
| Time | Job | Note |
|------|-----|------|
| 10:00 |侯選 수집 (jID: fcfd160352ff) | Reddit/X에서 유머/위트 자동 수집 — 블로그 GeekNews와 완전 별개 |
| 20:00 | Production + upload | `music_video_producer.py` |
| 20:00 | Production + upload | `music_video_producer.py` |

## Topic Generation (10:00 Cron)

**⚠️ 블로그 파이프라인(GeekNews 기반)과 완전 별개** — 뮤직비디오候選는 Reddit/X에서 유머/위트 주제로 자유롭게 수집.博客侯選와는 아무런 연관 없음.

###侯選 수집 소스
- Reddit: r/funny, r/mildlyinteresting, r/therewasanattempt, r/nottheonion
- X/Twitter: trending 중 유머/위트 있는 소재
-家主님 playlist 분석 (116곡, female vocal/K-pop ballad/romantic, 30% 우타이테풍)

###侯선 기준
**유머/위트 + 구체적 시나리오 + 영상화 가능**. 뉴스 출처 없이 자유롭게 구상도 가능.

### Output → Notion DB
Each topic entry contains:
- **주제:** "뉴스키워드 - 상황" (description style)
- **상태:** 대기 / 승인 / 보류 / 완료
- **분위기:** 차분한 / 밝은 / 감성적 / 강렬한
- **음악스타일:** K-pop ballad / acoustic pop / lo-fi / R&B
- **이미지프롬프트:** Visual direction for background image
- **음악프롬프트:** Full prompt including lyrics with humor/wit
- **뉴스출처:** Source news URL

###侯選 전송 형식 (2026-05-25)
家主님께 전송:
```
🎬 뮤직비디오侯選 (오전)

아래 중 원하는 주제를 골라주세요:

1. [주제명] - 한줄 설명
2. [주제명] - 한줄 설명
3. [주제명] - 한줄 설명

번호를 선택해 주세요.
```

### Approval Flow
1. 10:00 Cron이侯選 3개를 Notion에 등록 +家主님께 Telegram 전송
2.家主님이候選 중 번호 선택 (or 직접 주제 제안)
3. 선택된侯選 → 20:00 Cron에서 제작 진행
4. 피드백 있으면 반영, 없으면 선택된侯選 그대로 진행

## Production (20:00 Cron)

### Script
`~/.hermes/scripts/music_video_producer.py`

### Processing Steps
1. Query Notion DB: `상태 == "승인"` OR `상태 == "대기"` (max 3)
2. For each topic:
   - `mmx image generate --prompt "{image_prompt}" --out {path}.png`
   - `mmx music generate --prompt "{music_prompt}" --out {path}.mp3`
   - `FFmpeg` compose: image + audio → video
   - `FFmpeg` create Shorts: 9:16 crop, ≤60s
3. **ngrok review step** — do NOT upload yet
   - Start local HTTP server on port 8765 serving `~/.hermes/music_videos/`
   - Run `cloudflared --url http://localhost:8765` to get public URL
   - Send review link to Telegram: `{cloudflare_url}/{video_filename}.mp4`
   - Include title, description, and approval instructions
4. **Wait for user confirmation** — `confirm` → upload, `edit` → modify and re-review
5. On approval: `yt_upload.py` upload video + Shorts
6. Update Notion status to 완료

### FFmpeg Video Composition
```bash
ffmpeg -y \
  -loop 1 -i {image} -i {audio} \
  -vf "scale=1280:720:force_original_aspect_ratio=increase,crop=1280:720" \
  -c:v libx264 -preset ultrafast -crf 28 \
  -c:a aac -b:a 128k \
  -movflags +faststart \
  -shortest \
  {output}
```
- `-preset ultrafast -crf 28`: 3분 영상 인코딩 ~3분 (medium: 7분+)
- `-shortest`: audio 길이에 맞춰 자동 종료 (manual `-t` 불필요)
- `-movflags +faststart`: YouTube 호환성 필수
## YouTube Upload — Token Refresh + 429 Retry Strategy (2026-05-24)

**Critical insight (2026-05-24):** A `429 Quota Exceeded` error on upload is most often caused by **stale OAuth token**, NOT actual quota exhaustion. The fix: force-refresh the token BEFORE retrying, not after assuming quota is really exhausted.

```python
import pickle, time
from google.auth.transport.requests import Request

TOKEN_FILE = "~/.hermes/secrets/youtube_token.pickle"

def refresh_token_force():
    """Always refresh before upload — prevents 429 from stale tokens."""
    with open(os.path.expanduser(TOKEN_FILE), "rb") as f:
        creds = pickle.load(f)
    creds.refresh(Request())
    with open(os.path.expanduser(TOKEN_FILE), "wb") as f:
        pickle.dump(creds, f)

# Before any upload attempt:
refresh_token_force()

# On 429 during upload — retry after force refresh:
for attempt in range(3):
    result = subprocess.run([...upload...])
    if result.returncode == 0:
        break
    if "429" in result.stderr or "rateLimit" in result.stderr:
        refresh_token_force()  # ← token refresh BEFORE waiting
        time.sleep(2 ** attempt * 10)
    else:
        break
```

**User confirmed (2026-05-24):** "업로드 쿼타는 충분하니 혹시 쿼타가 부족하다고하면 네가 뭔가 잘못처리하는 거임" — quota is not the issue; the agent was mishandling stale tokens.

**Correct python3 to use:** `/usr/bin/python3` (3.9.6) — has `google-api-python-client`, `cryptography`, and `google-auth-oauthlib` all correctly installed. Do NOT use `/usr/local/bin/python3` (3.8.8, module conflicts) or the venv python for this script.

## ⚠️ mmx CLI API Key 누락 버그 (발견됨 2026-05-23)

`mmx image`와 `mmx music` 모두 **반드시 `--api-key` 파라미터 필요**. env만 설정되어 있어도 `--api-key` 없으면 `No credentials found` 에러 발생.

```bash
mmx image generate --api-key "$MINIMAX_API_KEY" --prompt "..." --out output.png
mmx music generate --api-key "$MINIMAX_API_KEY" --prompt "..." --lyrics "..." --out output.mp3
```

## ⚠️ yt_upload.py 인자 형식 버그 (발견됨 2026-05-23)

`yt_upload.py`는 positional arguments가 아니라 named arguments 사용. `music_video_producer.py`의 `upload_youtube()` 함수가 잘못된 형식으로 호출해서 업로드 실패.

```python
# ❌ 잘못됨
cmd = [venv_python, script, video_path, title, description]

# ✅ 올바름
cmd = [venv_python, script, video_path, "--title", title, "--description", description]
```

## Gallery 페이지 "Loading..." 안 넘어가는 문제 — 원인 별 진단 (2026-05-23)

| 원인 | 증상 | 확인 방법 | 해결 |
|------|------|---------|------|
| `gallery_data.json`에 로그 텍스트가 URL 대신 저장됨 | JSON parse error 콘솔 | `curl raw.githubusercontent.com/...index.html \| grep youtube_url` 1번째 entry 확인 | JSON에서 URL만 추출, `index.html` 재생성 후 git push |
| GitHub Pages 캐시 | curl로는 정상인데 브라우저만 안 됨 | 시크릿창에서도 동일 | `Ctrl+Shift+R` (하드 새로고침) 또는 다른 브라우저로 확인 |
| ES5 문법 오류 | 콘솔에 JS 에러 | DevTools → Console 탭 | `forEach`→`for`, template literal→문자열 연결, const→var 변환 |
| Gallery lyrics 0글자 문제 | `gallery_data.json`의 `lyrics` 필드에 전체 가사 저장 안 됨 | `load_gallery_data()` 후 저장 시 `lyrics[:200]`切片 | 전체 가사 `lyrics` 저장, preview는 JS에서 80자 자르기 |

**디버깅 순서:**
1. `curl -sL https://sigco3111.github.io/icbm2-gallery/`로 HTML 내려받기
2. `var data =` 블록에서 첫 번째 entry의 `youtube_url`이 `https://www.youtube.com/`로 시작하는지 확인
3. `</html>`前で `class="card"` 몇 개인지 확인 (`grep -c 'class="card"'`)
4. 카드 수 ≠ entries 수이면 JS 실행 문제 → DevTools Console 확인

### GitHub Pages 강제 갱신
```bash
cd ~/.hermes/music_videos/gallery_gh
git commit --allow-empty -m "force pages rebuild"
git push origin main
# 30초 후 https://sigco3111.github.io/icbm2-gallery/ 방문
```

## 주제 선정 기준 — 유머/위트 필수 (2026-05-23)

| ✅ 적합 | ❌ 부적합 |
|--------|----------|
| AI가 그림을盗作해서 법정 논쟁 | 무역협상, 펀드 출시 |
| 고양이 사진으로 Face ID解除 | LLM 아키텍처 동향 |
| 자율주행차가 표지판 오해 | 정책/금융 지표 |

**핵심:** 구체적 시나리오 + 유머/위트. 보는 사람이 웃을 수 있는 상황.

**FFmpeg Shorts (9:16)**
```bash
ffmpeg -y -i {video} \
  -vf "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920" \
  -c:v libx264 -preset ultrafast -crf 28 \
  -c:a aac -b:a 128k -t 60 \
  {output}
```
- Shorts는 일반 영상 생성 후 변환 (별도 이미지 불필요)
- `--shorts` flag를 yt_upload.py에 전달

## User Preferences

- **Vocals:** Korean female voice only
- **Lyrics:** Based on news topic, with humor and wit
- **Description format:** News-derived, description-style (not tags/brackets)
- **Shorts:** Always paired with main video upload
- **Image style:** Blur letterbox (original image blurred as background) over black padding
- **Auto-approve:** No feedback within same day = approved at 20:00
- **Review before upload:** Always use Cloudflare Tunnel link (not Telegram file attachment) for video review — prevents phone storage bloat

## Playlist Analysis (Reference)

User's YouTube playlist (116 songs):
- **Vocal:** Female dominant (K-pop covers, ballads)
- **Mood:** Romantic, sentimental, dreamy
- **Tempo:** Mid-tempo ballad centered
- **Instruments:** Acoustic guitar, piano based
- **Style examples:** IU, Blackpink, GFRIEND covers; Bon Jovi, MR.BIG, Richard Marx covers; 7080 remakes

## Known Constraints

- **Plus $20 Plan:** No video generation (Hailuo). Image/Music/Speech only.
- Music video = static image + equalizer-style visual + audio composition
- For actual video generation, upgrade to Max tier or higher

### 음악 길이 — 3분 이상 만들기 (확인됨 2026-05-23)
`--duration` 파라미터 작동 안 함.
**방법: 매우 긴 가사 + section별 bar 수 명시** (자세한 예: `music-video-generator` skill의 `references/minimax-music-cli.md` 참고)
- 결과: 212초 (3분 32초) 성공
- 우타이테풍: 밝은 템포 + 빠른 전주→보컬 전환으로 길이 유지

### 가사 필터링 — 한국어/영어만 허용 (2026-05-23)
Notion의 음악프롬프트에 한자/일본어가 섞여 있으면 음악 생성 시 문제 발생.
`music_video_producer.py`에 `filter_lyrics()` 함수 포함 — 생성 전 한자/일본어 제거.

### 다중 이미지 구성 — 3개 이미지 뮤직비디오 (2026-05-23)
FFmpeg concat 방식으로 3개 이미지 전환 뮤직비디오 구현 완료.
각 이미지 ~70초 구간, 총 212초 (3분 32초) 영상.

**FFmpeg concat 사용법:**
```bash
# 1. 각 이미지 세그먼트 생성 (시간 구간별)
ffmpeg -y -loop 1 -i img1.png -i audio.mp3 -ss 0 -t 72 \
  -vf "scale=1280:720" -c:v libx264 -preset ultrafast -crf 28 -c:a aac -t 72 seg1.mp4
ffmpeg -y -loop 1 -i img2.png -i audio.mp3 -ss 72 -t 72 \
  -vf "scale=1280:720" -c:v libx264 -preset ultrafast -crf 28 -c:a aac -t 72 seg2.mp4

# 2. concat list 작성
cat > concat.txt << 'EOF'
file '/path/seg1.mp4'
file '/path/seg2.mp4'
file '/path/seg3.mp4'
EOF

# 3. 연결
ffmpeg -y -f concat -safe 0 -i concat.txt -c copy output.mp4
```

### 이퀄라이저 애니메이션 오버레이 — 투명 배경 (2026-05-23)
동영상 우측 하단에 이퀄라이저 바 애니메이션 overlay.
방법: **GIF 투명 배경** → overlay

**구현 단계:**
1. Python PIL로 wave 바 프레임 생성 (RGBA, 투명 배경)
2. FFmpeg로 프레임 → GIF 인코딩 (`palettegen` + `paletteuse`)
3. 메인 영상에 GIF overlay (loop)
4. 최종 영상 YouTube 업로드

**GIF overlay 방법:**
```bash
ffmpeg -y -i main_video.mp4 -stream_loop -1 -i wave_loop.gif \
  -filter_complex "[0:v][1:v] overlay=920:600:shortest=1" \
  -c:v libx264 -preset ultrafast -crf 23 -c:a copy output_with_wave.mp4
```
- `920:600` = 우측 하단 위치 (1280-360, 720-120)
- GIF는 투명 alpha 채널 완전 보존 (mp4는 불가)

**Python wave 애니메이션 생성:**
```python
from PIL import Image, ImageDraw
import math, os

WAVE_DIR = os.path.expanduser("~/.hermes/music_videos/wave_frames")
os.makedirs(WAVE_DIR, exist_ok=True)

w, h = 360, 120
num_bars = 20
bar_w = 12
bar_spacing = 6
margin_bottom = 15
colors = [(255, 80, 120), (200, 80, 180), (120, 80, 255), (80, 150, 255)]

import random
random.seed(42)
base_heights = [random.randint(30, 80) for _ in range(num_bars)]

for frame in range(30):  # 30fps 1초 루프
    img = Image.new('RGBA', (w, h), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    phase = frame * 0.3
    
    for i in range(num_bars):
        wave = math.sin(phase + i * 0.4) * 0.4 + 0.6
        bar_h = int(base_heights[i] * wave)
        bar_h = max(10, min(bar_h, h - margin_bottom - 10))
        x = i * (bar_w + bar_spacing)
        y = h - margin_bottom - bar_h
        color_idx = int((i / num_bars) * (len(colors) - 1))
        color = colors[min(color_idx, len(colors) - 1)]
        draw.rounded_rectangle([x, y, x + bar_w, h - margin_bottom], 
                              radius=4, fill=color + (220,))
    
    img.save(f'{WAVE_DIR}/wave_{frame:03d}.png')
    img.close()
```

**GIF 인코딩 (투명도 보존):**
```bash
ffmpeg -y -framerate 30 -i wave_%03d.png \
  -vf "palettegen=stats_mode=diff" palette.png
ffmpeg -y -framerate 30 -i wave_%03d.png -i palette.png \
  -lavfi "paletteuse=dither=bayer:bayer_scale=3:diff_mode=rectangle" \
  -loop 0 wave_loop.gif
```

**단일 이미지 + 이퀄라이저 오버레이 방식 (2026-05-23 — 최종 선택)**
사용자 요청: "다른 효과 다 빼고, 멋진 이퀄라이저 느낌의 애니메이션만 우측 하단에 노출해줘"

→ 멀티이미지/Ken Burns 모두 제거. 단일 배경 이미지 + 우측 하단 wave 애니메이션.
이 방식이 가장 단순하고 효과적.

### GitHub Pages 갤러리 — 이미지 + 가사 + YouTube URL 자동 백업 (2026-05-23)
매일 생성되는 뮤직비디오 이미지를 GitHub Pages (`https://sigco3111.github.io/icbm2-gallery/`)에 자동 백업.

**Gallery repo:** `https://github.com/sigco3111/icbm2-gallery.git`
**Local path:** `~/.hermes/music_videos/gallery_gh/`
**갤러리 구조:**
```
icbm2-gallery/
├── index.html          # 자동 생성 (ES5 호환 JavaScript)
├── gallery_data.json   # 이미지/가사/YouTube URL 저장
└── images/             # 생성된 이미지들
```

**gallery_data.json 포맷:**
```json
{
  "entries": [{
    "date": "2026-05-23",
    "topic": "제목",
    "mood": "우타이테",
    "youtube_url": "https://youtube.com/watch?v=...",
    "short_url": "https://youtube.com/watch?v=... (Shorts)",
    "lyrics": "가사 (여러 줄 \\n으로 구분)",
    "images": [
      "https://raw.githubusercontent.com/sigco3111/icbm2-gallery/main/images/img1.png",
      "https://raw.githubusercontent.com/sigco3111/icbm2-gallery/main/images/img2.png",
      "https://raw.githubusercontent.com/sigco3111/icbm2-gallery/main/images/img3.png"
    ]
  }]
}
```

**갤러리 자동갱신 플로우:**
1. `music_video_producer.py`의 `backup_to_gallery()` 호출
2. `load_gallery_data()` → 기존 entries에 새 entry 추가
3. `generate_gallery_html(data)` → `index.html` 재생성
4. git add → commit → push
5. GitHub Pages 자동 반영 (~20-30초)

**갤러리 HTML 특징:**
- ES5 호환 JavaScript (forEach/template literal 금지 — 일부 호스팅 환경에서 문제)
- 카드별 3개 이미지 나란히 표시 (flexbox, 33.33% 너비)
- 가사 더보기 토글 (80자 미리보기 → 전체 가사, `\n` → `<br>` 변환)
- 검색: topic + lyrics + date로 필터링

**문제 해결:**
- JavaScript 실행 안 됨 → ES5 호환 코드로 재작성 (const→var, forEach→for loop, template literal→문자열 연결)
- 가사가 한 줄만 표시됨 → `gallery_data.json`에 `\n` 개행 포함한 전체 가사 저장, JS에서 `replace(/\n/g, '<br>')` 처리
- 이미지 1장만 표시됨 → `images` 배열로 3개 이미지 URL 저장, HTML에서 루프 렌더링

**GitHub Pages 활성화:**
```bash
gh api -X POST repos/sigco3111/icbm2-gallery/pages \
  -f build_type=legacy -f source[branch]=main -f source[path]=/
```

### Ken Burns 효과 — 정지영상 아닌 느낌 (2026-05-23)
**FFmpeg zoompan의 4K 입력 호환性问题** → Python PIL로 Ken Burns 프레임 생성 후 FFmpeg 조립.
`music_video_producer.py`에 Ken Burns 로직 포함.

## Cloudflare Tunnel — Quick Setup & Debugging (2026-05-24)

**⚠️ Cloudflare Tunnel은 완전 폐기 — ngrok 사용 (2026-05-24)**

### Setup
```bash
brew install cloudflared
```

### Review Flow (Production Step)
1. Start HTTP server on random available port (e.g., 8766):
```python
import http.server, socketserver, os
socketserver.TCPServer.allow_reuse_address=True
os.chdir(os.path.expanduser('~/.hermes/music_videos'))
# Bind to 127.0.0.1 only — cloudflared connects locally
http.server.HTTPServer(('127.0.0.1', 8766), http.server.SimpleHTTPRequestHandler).serve_forever()
```

2. Start cloudflared tunnel — capture output via file redirection:
```python
# background=True with nohup redirect to log file
nohup cloudflared --url http://127.0.0.1:8766 > /tmp/cf.log 2>&1 &
# Then read log: tail -20 /tmp/cf.log
# Look for: https://*.trycloudflare.com
```

3. Send review link to Telegram:
```
🎬 뮤직비디오 검수

🔗 영상: {cloudflare_url}/{video_filename}.mp4
📝 제목: {title}
📋 설명: {description}

✅ 확인 → 업로드
✏️ 수정 → 내용告诉他
```

4. On user `confirm`: upload to YouTube, update Notion to 완료

### Common Issues & Fixes

**`OSError: [Errno 48] Address already in use`**
- Another process is using the port. Find it: `lsof -i :8765`
- Kill stale servers: `pkill -f "python.*http.server\|python.*876"` before restarting

**Cloudflare returns HTTP 530**
- Usually means cloudflared can't reach the origin (127.0.0.1)
- Verify server is running: `curl -s http://127.0.0.1:8766/ | head -2`
- If server binds to `localhost:8766` but cloudflared uses `127.0.0.1:8766` — these are the same on macOS (IPv4 loopback)
- Quick Tunnel (no account) is ephemeral — URL changes every restart, OK for per-session review

**Cloudflared logs show empty / no output**
- cloudflared outputs to stderr, not stdout
- Must redirect: `cloudflared ... > /tmp/cf.log 2>&1`
- Or pipe through `script` command to capture PTY output

**Multiple cloudflared processes**
- Always `pkill -f cloudflared` before restarting to avoid conflicts

### Telegram Token
- Bot token is in `~/.hermes/secrets/telegram_bot_token.txt` (not env var)
- Chat ID in `~/.hermes/secrets/telegram_chat_id.txt`
- The `send_telegram()` in existing scripts reads from env vars — set them before calling

## References

- `references/playlist-analysis.md` — Full 116-song analysis
- `references/youtube-api-operations.md` — YouTube API quota/token workaround, FFmpeg Shorts 제작, gallery debugging
- `references/minimax-music-cli.md` — MiniMax music generation CLI reference
- `references/cloudflare-tunnel-debug.md` — Port binding issues, HTTP 530 root causes
- `scripts/music_video_producer.py` — Production script
- `scripts/wave_animator.py` — 이퀄라이저 애니메이션 생성기 (GIF 투명 배경)