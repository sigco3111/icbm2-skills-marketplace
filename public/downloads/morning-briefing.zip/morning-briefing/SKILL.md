---
name: morning-briefing
description: 매일 아침 통합 인사이트 브리핑 — 날씨, 주식, 뉴스, 자동화 성과, 일정을 교차 분석
version: 2.0.0
author: ICBM2
metadata:
  hermes:
    tags: [Briefing, Telegram, Daily Report, Automation, Intelligence]
---

# ICBM2호 통합 아침 브리핑 v2

## 개요

전날의 자동화 성과 + 오늘의 필수 정보(날씨/주식/뉴스/일정)를 수집하여 **교차 분석 인사이트**와 함께 텔레그램으로 브리핑합니다. 단순한 요약이 아닌, 주인님의 의사결정에 실질적으로 도움이 되는 인사이트를 제공합니다.

## 개인화 시스템 v3

브리핑은 매일 주인님의 관심사와 활동 패턴에 맞게 **개인화**됩니다.

### 개인화 데이터 수집 (최우선)

```bash
# 오늘의 개인화 설정 가져오기 (반드시 첫 단계에서 실행)
python3 scripts/briefing_personalizer.py
```

이 스크립트는 주인님의 최근 7일간 활동, 요일별 패턴, 관심사 가중치를 분석하여:
- **섹션 우선순위**: 어떤 뉴스를 먼저 보여줄지
- **강조 키워드**: 특별히 주목할 키워드
- **맥락 노트**: 요일/활동에 따른 인사이트
- **주식 관심 종목**: 시황에서 특별히 표시할 종목

를 결정합니다.

### 브리핑 생성 규칙 (개인화 반영)

1. `briefing_personalizer.py` 출력의 `section_priority` 순서대로 섹션 배치
2. `emphasis_keywords`에 포함된 키워드가 관련 뉴스에 있으면 ⭐ 마크로 하이라이트
3. `contextual_notes`의 내용을 브리핑 도입부에 자연스럽게 반영
4. `stock_watchlist`의 종목을 주식 시황에서 일반 종목보다 먼저/상세히 표시
5. 관심사 가중치가 높은 카테고리의 뉴스를 더 많이 수집 (AI/ML > 투자 > 자동화 순)

## 데이터 소스

### A. 오늘의 날씨

```bash
# OpenWeatherMap 또는 wttr.in
curl -s "wttr.in/Seoul?format=j1" --max-time 10
```

**수집 항목:**
- 기온(최고/최저), 체감온도
- 강수 확률, 강수량
- 습도, 풍속
- 자외선 지수
- 하늘 상태 (맑음/흐림/비/눈)

### B. 주식 시황

```bash
# 미국 시장 (전일 종가)
# Yahoo Finance API 또는 직접 크롤링
curl -s "https://query1.finance.yahoo.com/v8/finance/chart/^GSPC?range=1d&interval=1d" --max-time 10

# 한국 시장 (전일 종가 — 장 마감 후)
python3 -c "
from pykrx import stock
df = stock.get_index_ohlcv('20260407', '20260407', '0001')  # 코스피
" 2>/dev/null || echo "pykrx not available"

# 또는 curl 기반 대체:
curl -s "https://m.stock.naver.com/api/index/KOSPI/basic" --max-time 10
```

**수집 항목:**
- 코스피/코스닥 전일 종가, 등락률
- 나스닥/S&P500 전일 종가, 등락률
- 주요 종목 (삼성전자, 애플, 테슬라 등) — 가장 최근 거래 가격
- USD/KRW 환율

### C. AI/기술 뉴스

```bash
# AgentNews — AI 에이전트 전용 뉴스 피드 (무료, 인증 불필요, 매시간 업데이트)
curl -s "https://agent.news/api/v1/feed" --max-time 10

# Hacker News (AI 관련)
curl -s "https://hacker-news.firebaseio.com/v0/topstories.json" --max-time 10 | head -c 500

# 또는 DuckDuckGo 검색
# "AI artificial intelligence news today 2026"
# "애플 Apple news today 2026"
```

**수집 항목:**
- AgentNews 피드: 최신 AI 인프라/도구/인사이트 (최대 3건) — 카테고리(insight/tool/infrastructure/show)별 분류
- AI/ML 관련 헤드라인 (최대 5건)
- 애플/iOS 개발 관련 헤드라인 (최대 3건)
- 주인님 관심사 관련 뉴스 (투자, 자동화)

**AgentNews 피드 파싱:**
```json
{
  "schema": "agentnews/feed/1.0",
  "items": [
    {
      "title": "...",
      "url": "...",
      "category": "insight|tool|infrastructure|show",
      "published_at": "ISO8601",
      "points": 0,
      "comment_count": 0
    }
  ]
}
```
- `category`가 `insight`인 것을 우선 표시
- `tool`과 `infrastructure`는 도구 발견용으로 유용
- 브리핑에서는 `[AgentNews]` 레이블로 구분 표시

### D. 자동화 성과 (기존 + 확장)

#### D-1. 봇마당

```bash
API_KEY=$(cat $BOTMADANG_API_KEY_PATH)
curl -s --max-time 10 "https://botmadang.org/api/v1/posts?limit=50" \
  -H "Authorization: Bearer $API_KEY"
curl -s --max-time 10 "https://botmadang.org/api/v1/agents/$BOTMADANG_AGENT_ID/comments" \
  -H "Authorization: Bearer $API_KEY"
```

#### D-2. Ship or Slop KR

**상태 파일:** `memory/shiporslop.md`

#### D-3. 자가 치유 리포트

**상태 파일:** `memory/self_heal_YYYY-MM-DD.md`

#### D-4. 크론 잡 품질

```bash
python3 scripts/cron_quality_monitor.py --json 2>/dev/null
```

또는 `memory/cron_quality.md`

### E. 일정 (가능한 경우)

- Apple Reminders: `remindctl list --today` (macOS)
- Google Calendar: Google Workspace API
- Notion 일기장: 최근 일기에서 언급된 일정

---

## 교차 분석 (핵심 차별점)

단순한 데이터 나열이 아닌, 데이터 소스 간 교차 분석으로 **실질적 인사이트**를 도출합니다.

### 분석 규칙

1. **날씨 × 일정**: 비/눈 확률 > 60% + 야외 일정 → "오늘 우산 챙기세요" / 기온 < 5°C → "따뜻하게 입으세요"
2. **주식 × 뉴스**: 주요 종목 관련 뉴스가 있으면 함께 표시 (예: "애플 -1.2% │ WWDC 발표 관련 기사")
3. **자동화 × 크론 품질**: 전일 실패한 크론이 있으면 원인과 해결 상태 요약
4. **뉴스 × 관심사**: AI/투자/자동화 관련 대형 뉴스가 있으면 하이라이트
5. **성과 트렌드**: 봇마당 카르마/Ship or Slop 성과가 전주 대비 어떻게 변했는지

### 인사이트 형식

```
💡 오늘의 인사이트
• [날씨] 오후 비 예상 — 퇴근길 우산 필수
• [주식] 코스피 3일 연속 상승세, 반도체 섹터 강세
• [뉴스] 애플 iOS 20 베타 공개 — 주말에 체크해보세요
```

---

## 브리핑 포맷 (Telegram — 개인화 반영)

```
☀️ ICBM2호 아침 브리핑 — MM월 DD일 (요일)
💡 [개인화 노트 — contextual_notes 중 하나]

━━━━━━━━━━━━━━━━━━

🌤 오늘의 날씨
• 서울: 맑️ 18°C / 25°C (체감 17°C)
• 오후 강수확률 20%
• 자외선 지수: 보통

━━━━━━━━━━━━━━━━━━

📈 주식 시황
⭐ [관심 종목 — stock_watchlist]
• 삼성전자: 85,000 (+2.1%) ▲
• 애플: 195,000 (+0.5%) ▲
[일반 시황]
• 코스피: 2,890 (+1.2%) ▲
• 나스닥: 18,500 (+0.8%) ▲
• USD/KRW: 1,340원

━━━━━━━━━━━━━━━━━━

📰 오늘의 뉴스 [section_priority 순서로 배치]
⭐ [emphasis_keywords 포함 뉴스는 하이라이트]
• [AgentNews] ⭐ AI 에이전트 생태계 주요 뉴스
• [AgentNews] 새로운 AI 도구/인프라 발견
• ⭐ OpenAI GPT-6 출시 — AI 관심도 UP
• 애플 WWDC 2026 일정 발표
• 한국 반도체 수출 3개월 연속 증가

━━━━━━━━━━━━━━━━━━

💡 오늘의 인사이트
• [interest_ranking 기반] 관심사와 연관된 인사이트 우선
• [주식×뉴스] 반도체 관련 뉴스 3건 — 삼성전자 긍정적
• [관심사] 애플 WWDC 관련 — 주말에 체크 추천

━━━━━━━━━━━━━━━━━━

🤖 어제 자동화 성과
• 봇마당: 게시글 3, 댓글 12, ⭐ 카르마 450 (+15)
• Ship or Slop: 리서치 2, 아이디어 3 (Ship 2/Slop 1)
• 블로그 발행: N건 (품질 S: N, A: N, 스킵: N)
• 크론 정상: 12/13 ⚠️ 1건 실패 (자가 치유 완료)

━━━━━━━━━━━━━━━━━━

🕐 오늘 자동화 일정
• 블로그 모니터링: 09:00
• 주식 시황 브리핑: 18:30
• 자가 개선 리뷰: 23:00
```

---

## 생성 규칙

1. **전일 자동화**: 어제 00:00 ~ 23:59 KST 기준
2. **오늘 정보**: 날씨/주식/뉴스는 당일 기준
3. **활동 없으면 생략**: 해당 섹션에 데이터 없으면 "어제 활동 없음"
4. **간결하게**: 전체 30줄 이내 (Telegram 메시지 길이 제한)
5. **교차 분석 우선**: 💡 인사이트 섹션이 가장 중요 — 반드시 의미 있는 인사이트 1~3개 포함
6. **API 타임아웃 대비**: 각 소스 10초 타임아웃, 실패 시 해당 섹션 "데이터 수집 실패"로 표시
7. **curl에 반드시 `--max-time 10` 설정**

---

## 실행 순서

### 0단계: 개인화 설정 로드 (최우선)
```bash
python3 scripts/briefing_personalizer.py
```
출력의 `section_priority`, `emphasis_keywords`, `contextual_notes`, `stock_watchlist`를 브리핑 생성에 반영.

### 1단계: 데이터 수집 (병렬)
날씨, 주식, 뉴스(AgentNews + HN + DDG), 자동화 성과를 동시에 수집.
- AgentNews 피드를 최우선으로 조회 → AI/에이전트 생태계 최신 트렌드 확보
- 주식: `stock_watchlist`의 종목을 개별 조회하여 상세 표시
- 뉴스: `emphasis_keywords` 관련 뉴스를 추가로 검색

### 2단계: 교차 분석
수집된 데이터를 바탕으로 인사이트 도출. `interest_ranking`을 반영하여 주인님 관심사와 연관된 인사이트 우선.

### 3단계: 브리핑 생성
포맷에 맞춰 메시지 작성 (한국어). 개인화 설정에 따라 섹션 순서와 강조점 조정.

### 4단계: 전송
최종 응답으로 브리핑 반환 (deliver=origin으로 텔레그램 전송).

---

## 주의사항

- Telegram은 마크다운 테이블 미지원 → 이모지 + 글머리 기호 사용
- Notion API는 `Notion-Version: 2022-06-28` 헤더 필수
- pykrx 미설치 시 curl 대체 소스 사용
- 모든 API 호출에 --max-time 10
- 한국어로 작성
