---
name: google-veo-api
description: Google Veo 3.1 API를 통한 AI 영상 생성 — 텍스트/이미지 기반 영상 클립 생성, 오디오 포함, 연장, 다운로드
---

# Google Veo 3.1 API 가이드

## 개요
Google Gemini API를 통해 Veo 3.1 모델로 AI 영상을 프로그래밍 방식으로 생성.

## 전제조건
- Google AI Studio 또는 Google Cloud Console에서 API 키 발급
- Gemini API 접근 권한 (Google Workspace Enterprise 계정)

## 모델
- `veo-3.1-generate-preview`

## 지원 기능
- 텍스트 → 영상 (8초, 720p/1080p/4K)
- 네이티브 오디오 포함 (효과음, 대화, 배경음악)
- 이미지 기반 영상 생성 (참조 이미지 최대 3장)
- 첫/마지막 프레임 지정 생성
- 비디오 연장
- 가로(16:9) / 세로(9:16) 비율

## Python 예시
```python
from google import genai
import time

client = genai.Client()
operation = client.models.generate_videos(
    model="veo-3.1-generate-preview",
    prompt="일몰이 지는 해변가를 걷는 사람, 파도 소리",
)

while not operation.done:
    time.sleep(10)
    operation = client.operations.get(operation)

operation.response.generated_videos[0].video.save("output.mp4")
```

## REST 예시
```bash
curl -s "https://generativelanguage.googleapis.com/v1beta/models/veo-3.1-generate-preview:predictLongRunning" \
  -H "x-goog-api-key: $GEMINI_API_KEY" \
  -H "Content-Type: application/json" \
  -X POST \
  -d '{"instances": [{"prompt": "프롬프트 텍스트"}]}'
```

## API 없이 앱 전용인 것들
- **Lyria (음악 생성)** — Google Vids 앱 내에서만
- **NotebookLM Audio Overview** — NotebookLM 웹앱에서만
- **Google Flow** — Flow 웹앱에서만

## 참고
- API 키 발급: https://aistudio.google.com
- 공식 문서: Google AI for Developers > Veo
