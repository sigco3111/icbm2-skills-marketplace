# gjc (gajae-code) Reference

`gjc`는 **gajae-code**라는 npm/bun 패키지가 설치하는 CLI 바이너리 이름입니다 (패키지명 ≠ 바이너리명). Claude Code/Codex/OpenCode와 같은 클래스의 autonomous coding agent지만, **provider 라우팅에 중점**을 둔 한국 개발자(Yeachan-Heo) 프로젝트입니다.

> 바이너리 = `gjc` / 패키지 = `gajae-code` / 글로벌 설치 경로 = `~/.bun/install/global/node_modules/gajae-code/`
> 둘을 혼동하면 검색이 안 됨. **"gajae가 실행이 안 돼" → `gjc`를 찾아야 함.**

## 1. 설치 & PATH 트랩 (2026-07-13 검증)

**bun 글로벌 설치 (추천):**
```bash
bun add -g gajae-code
```

**설치 후 흔한 함정:**
- 바이너리는 `~/.bun/bin/gjc`로 떨어지는데, **PATH에 `~/.bun/bin`이 빠져 있으면 `command not found`**
- `which gjc` → 빈 결과 + `gjc: 명령을 찾을 수 없음`

**PATH 추가:**
```bash
# 1회성
export PATH="$HOME/.bun/bin:$PATH"

# 영구 (.zshrc)
echo 'export PATH="$HOME/.bun/bin:$PATH"' >> ~/.zshrc
source ~/.zshrc
```

**검증:**
```bash
gjc --version         # → gjc v0.10.1 같은 출력
gjc --help            # → USAGE/FLAGS/EXAMPLES
```

## 2. 글로벌 설치 위치 (디버깅용)

```bash
# 바이너리 심볼릭 링크 확인
ls -la ~/.bun/bin/gjc
# → ~/.bun/bin/gjc -> ../../node_modules/gajae-code/bin/gjc.js

# 글로벌 패키지 위치
ls ~/.bun/install/global/node_modules/ | head
# → gajae-code@0.10.1, oh-my-openagent@..., playwright@... 등

# 설치된 글로벌 패키지 목록
bun pm ls -g
```

**핵심:** `gajae`라는 명령은 존재하지 않음. 패키지명 ≠ 바이너리명이라는 점 기억.

## 3. CLI 플래그 (실측 2026-07-13)

| Flag | 용도 |
|------|------|
| `--model=<value>` | 모델 fuzzy 매칭 ("opus", "gpt-5.2", "openai/gpt-5.2" 형식) |
| `--smol=<value>` | 경량 모델 (`GJC_SMOL_MODEL` env 동등) |
| `--slow=<value>` | 추론 모델 (`GJC_SLOW_MODEL` env 동등) |
| `--plan=<value>` | 아키텍처 플래닝 모델 (`GJC_PLAN_MODEL` env 동등) |
| `--mpreset=<profile>` | 프로필 활성화 (한 번에 모델 + 역할별 모델 오버라이드) |
| `--default` | `--mpreset`을 영구 기본값으로 저장 |
| `--provider=<value>` | provider 직접 지정 (legacy, `--model` 권장) |
| `--api-key=***` | API 키 직접 전달 |
| `--credential=<selector>` | 저장된 credential 사용 (`email:`, `id:`, `account:`, `project:`, `provider/email:`) |
| `--system-prompt=<value>` | 시스템 프롬프트 교체 |
| `--append-system-prompt=<value>` | 시스템 프롬프트에 텍스트/파일 추가 |
| `--allow-home` | `~`에서 시작 시 자동 temp dir 전환 비활성화 |
| `--mode=<value>` | 출력 모드: text (default), json, rpc, acp, rpc-ui, bridge |
| `-p, --print` | 비대화형 (프롬프트 처리 후 종료) |
| `-c, --continue` | 이전 세션 계속 |
| `-r, --resume=<id>` | 특정 세션 재개 (ID prefix/경로/picker 가능) |
| `--session-dir=<dir>` | 세션 저장 경로 |
| `--no-session` | 세션 저장 안 함 (ephemeral) |
| `--models=<patterns>` | Alt+N 순환용 모델 패턴 (쉼표 구분) |
| `--no-tools` | 모든 빌트인 도구 비활성화 |
| `--no-lsp` | LSP/포맷팅/진단 비활성화 |
| `--no-pty` | PTY 기반 bash 실행 비활성화 |
| `--tmux` | tmux 안에서 인터랙티브 시작 |
| `--tools=<list>` | 활성화할 도구 (쉼표 구분) |
| `--thinking=<level>` | 추론 레벨: ultra/high/medium/low |
| `--hook=<file>` | hook/extension 로드 (반복 가능) |
| `-e, --extension=<file>` | extension 로드 (반복 가능) |
| `--no-extensions` | extension discovery 비활성화 |
| `--no-skills` | skills discovery 비활성화 |
| `--skills=<patterns>` | skills glob 필터 (예: `git-*,docker`) |
| `--no-rules` | rules discovery 비활성화 |
| `--export=<file>` | 세션을 HTML로 export 후 종료 |
| `--list-models=<query>` | 사용 가능한 모델 목록 (fuzzy 검색) |
| `--no-title` | 자동 제목 생성 비활성화 |

## 4. 모델 설정 (provider 등록)

### 4.1 가장 흔한 401 함정

```bash
$ gjc --list-models
No models available. Set API keys in environment variables.
```

→ credential이 어디에도 없음. **반드시 `--api-key` 또는 환경변수 + provider 등록이 선행**되어야 함.

### 4.2 모델 직접 지정 (임시)

```bash
# 한 번만 쓸 때
gjc --model minimax/MiniMax-M3 "프롬프트"
gjc --model MiniMax-M3 "프롬프트"

# 영구화
gjc --mpreset minimax --default
```

### 4.3 환경변수 방식

`~/.zshrc`에 추가:
```bash
export GJC_MODEL=minimax/MiniMax-M3
```

### 4.4 OpenAI-compatible provider 등록 (gjc setup provider)

```bash
gjc setup provider
# 또는 인앱 /provider add
```

이 워크플로는 OpenAI-compatible (대부분의 중국 모델 API 포함) 및 Anthropic-compatible API를 위한 **공유 온보딩**을 제공합니다. 필요한 정보:
- API base URL
- API key (또는 환경변수명)
- 사용 가능한 model ID 목록

## 5. 다른 코딩 에이전트와 비교

| 항목 | gjc | Claude Code | Codex | OpenCode |
|------|-----|-------------|-------|----------|
| 패키지명 | `gajae-code` | `@anthropic-ai/claude-code` | `@openai/codex` | `opencode-ai` |
| 바이너리 | `gjc` | `claude` | `codex` | `opencode` |
| 글로벌 bin | `~/.bun/bin/gjc` | npm global | npm global | npm/brew |
| 모델 라우팅 | Multi-provider (OpenAI-compat) | Anthropic + custom | OpenAI + custom | OpenRouter/ZAI/GLM/Ollama |
| 프로필 시스템 | `--mpreset` (네이밍/저장) | `--model` | `--model` | `--model` |
| OpenAI-compat 등록 | 내장 (`gjc setup provider`) | 수동 (`ANTHROPIC_BASE_URL`) | 수동 | 수동 |
| 세션 | `--continue`, `--resume` | `--continue`, `--resume`, `--fork-session` | ❌ | `-c`, `-s` |
| 도구 비활성화 | `--no-tools`, `--no-lsp`, `--no-pty`, `--no-skills`, `--no-rules` | `--bare`, 개별 | 제한적 | `--no-tools` 등 |
| Skills | `--skills=` glob, `--no-skills` | `.claude/commands/` | ❌ | plugins |
| Hook/Extension | `--hook`, `-e/--extension` | hooks (settings.json) | ❌ | plugins |
| Bridge/RPC | `--mode bridge`, `rpc`, `acp`, `rpc-ui` | `--output-format json` | ❌ | `--format json` |

## 6. 자주 만나는 함정

1. **패키지명 ≠ 바이너리명** — `gajae-code` 설치 후 `gajae` 실행 → 실패. 바이너리는 `gjc`.
2. **PATH에 `~/.bun/bin` 없음** — `command not found`. brew/rbenv 사용자 특히 자주 빠짐 (bun은 brew 설치되지만 PATH는 자동 추가 안 됨).
3. **API 키는 있지만 provider 미등록** — `--list-models` 결과가 "No models available"이면 키가 있어도 모델 안 보임. `--api-key` 또는 `gjc setup provider` 필수.
4. **401 invalid api key** — endpoint가 맞지 않을 가능성. `api.minimax.chat`이 표준이지만 일부 환경은 다른 도메인. 키 차단은 피하려고 여러 endpoint 시도 금지 (한 번에 1개만).
5. **Python 3.9 (xcode legacy) urllib3 경고** — bun은 무관하지만 시스템 Python으로 curl 테스트하면 `NotOpenSSLWarning` 잔뜩. 무시 가능.

## 7. 진단 빠른 명령어

```bash
# 1. PATH 확인
which gjc || echo "❌ PATH 없음 — export PATH=\$HOME/.bun/bin:\$PATH"

# 2. 패키지 vs 바이너리 매칭 확인
ls ~/.bun/install/global/node_modules/ | grep gajae
ls -la ~/.bun/bin/gjc

# 3. 버전 확인
gjc --version

# 4. 모델 가용성
gjc --list-models | head -5

# 5. 특정 모델 검색 (fuzzy)
gjc --list-models=minimax
gjc --list-models=opus
```

## 8. 사용 예시

```bash
# 비대화형 (한 번 실행)
gjc -p "이 파일에서 버그 찾아줘: @bug.py"

# 인터랙티브 + 초기 프롬프트
gjc "src/ 디렉토리의 모든 .ts 파일 목록 보여줘"

# 파일 첨부
gjc @prompt.md @image.png "이 이미지 색깔이 뭐야?"

# 세션 계속
gjc --continue "이전에 뭐 얘기했지?"

# 다른 모델로 (fuzzy)
gjc --model opus "이 코드 리팩토링해줘"

# 영구 프로필 저장 (다음 세션부터 기본)
gjc --mpreset minimax --default

# 웹 검색 키 없이 (DuckDuckGo 자동 fallback)
gjc "최신 React 버전 알려줘"
```
