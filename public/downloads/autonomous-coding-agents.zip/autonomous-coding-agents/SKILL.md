---
name: autonomous-coding-agents
description: Delegate coding work to a CLI-based autonomous coding agent (Claude Code, OpenAI Codex, OpenCode, or gjc/gajae-code) via the Hermes terminal. Covers one-shot tasks, interactive PTY orchestration via tmux, parallel worktrees, PR review, and session continuation. Pick a sub-reference for the specific agent's flags, modes, and quirks.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [Coding-Agent, Claude-Code, Codex, OpenCode, Anthropic, OpenAI, Autonomous, Refactoring, Code-Review, PTY, tmux, Automation]
---

# Autonomous Coding Agents

Delegate coding work to an autonomous CLI agent. This umbrella covers three tools:

- **[Claude Code](#claude-code)** (`claude`) — Anthropic's agent. Best for: complex multi-step work, subagent orchestration, large refactors. See `references/claude-code.md` for full flag reference.
- **[Codex](#codex)** (`codex`) — OpenAI's agent. Best for: one-shot tasks, batch PR reviews. See `references/codex.md`.
- **[OpenCode](#opencode)** (`opencode`) — Provider-agnostic open-source agent. Best for: model-flexible tasks, OpenRouter/ZAI/GLM routing. See `references/opencode.md`.
- **[gjc](#gjc-gajae-code)** (`gjc`) — gajae-code 패키지가 설치하는 CLI. **패키지명(`gajae-code`) ≠ 바이너리명(`gjc`)** — bun 글로벌 설치 후 `~/.bun/bin`이 PATH에 빠져 있으면 `command not found`. Multi-provider 라우팅(OpenAI-compatible)에 중점. `--mpreset` 프로필 시스템 + 내장 `gjc setup provider` 온보딩. See `references/gjc.md`.

Each sub-reference has the full per-agent flag list, auth flow, and quirks. This umbrella is the shared orchestration layer.

**Sections:**
1. [Common orchestration patterns](#common-orchestration-patterns) — all three agents
2. [Claude Code](#claude-code) — see `references/claude-code.md`
3. [Codex](#codex) — see `references/codex.md`
4. [OpenCode](#opencode) — see `references/opencode.md`
4b. [gjc (gajae-code)](#gjc-gajae-code) — see `references/gjc.md`
5. [Cross-agent comparison](#cross-agent-comparison) — when to use which
6. [Parallel worktree pattern](#parallel-worktree-pattern) — fix N issues in parallel
7. [PR review with coding agents](#pr-review-with-coding-agents)
8. [Common pitfalls](#common-pitfalls)

---

## 1. Common Orchestration Patterns

All three agents follow the same conceptual lifecycle, with agent-specific implementation details.

### 1.1 One-Shot Task (non-interactive)

Print-style execution: agent reads input, makes changes, exits. No PTY needed.

```bash
# Claude Code
terminal(command="claude -p 'Add error handling to all API calls in src/' --allowedTools 'Read,Edit' --max-turns 10", workdir="/path/to/project", timeout=120)

# Codex
terminal(command="codex exec 'Add dark mode toggle to settings'", workdir="~/project", pty=true)

# OpenCode
terminal(command="opencode run 'Add retry logic to API calls and update tests'", workdir="~/project")
```

`--max-turns` / `--full-auto` flags cap agentic loops and prevent runaway costs. **Always set these for one-shots.**

### 1.2 Interactive Multi-Turn (PTY via tmux)

For iterative work, the agent needs a real terminal. Hermes's terminal tool doesn't run a long-lived TUI directly, so use tmux.

```bash
# Start tmux session
terminal(command="tmux new-session -d -s coding-work -x 140 -y 40")

# Launch the agent inside
terminal(command="tmux send-keys -t coding-work 'cd /path/to/project && <agent-cli>' Enter")

# Wait for startup, then send the task
sleep 5
terminal(command="tmux send-keys -t coding-work '<your task prompt>' Enter")

# Monitor
terminal(command="sleep 15 && tmux capture-pane -t coding-work -p -S -50")

# Send follow-up
terminal(command="tmux send-keys -t coding-work '<follow-up>' Enter")

# Exit cleanly
terminal(command="tmux kill-session -t coding-work")
```

### 1.3 Background Long-Running Task

For tasks that won't finish within a normal terminal call:

```bash
terminal(command="<agent> <args>", workdir="~/project", background=true, pty=true)
# Returns session_id

# Monitor
process(action="poll", session_id="<id>")
process(action="log", session_id="<id>")

# Send input if agent asks a question
process(action="submit", session_id="<id>", data="yes")

# Kill
process(action="kill", session_id="<id>")
```

**PTY is mandatory** for all three agents in interactive mode. Without it they hang silently.

### 1.4 Auth Setup (All Agents)

| Agent | Auth command | Verify |
|---|---|---|
| Claude Code | `claude auth login` (browser) or `claude auth login --console` (API key) or `--sso` (Enterprise) | `claude auth status` |
| Codex | `codex auth login` or set `OPENAI_API_KEY` | `codex auth list` |
| OpenCode | `opencode auth login` or set provider env vars (`OPENROUTER_API_KEY`, etc.) | `opencode auth list` |

For OpenCode, the binary may resolve differently across shells — always verify:

```bash
which -a opencode
opencode --version
```

If behavior differs from a fresh terminal, pin the explicit path: `$HOME/.opencode/bin/opencode run '...'`.

### 1.5 Git Repository Required

All three agents refuse to run outside a git repo (some enforce this strictly).

```bash
# For scratch work
REVIEW=$(mktemp -d) && git clone https://github.com/user/repo.git $REVIEW && cd $REVIEW
```

---

## 2. Claude Code

**Full reference:** `references/claude-code.md` (CLI flags, settings hierarchy, hooks, MCP integration, custom subagents, cost tips).

**Quick start:**

```bash
# Install
npm install -g @anthropic-ai/claude-code

# Auth (one-time)
claude

# One-shot
terminal(command="claude -p 'Add error handling to API calls' --allowedTools 'Read,Edit' --max-turns 10", workdir="/project", timeout=120)

# Structured output
terminal(command="claude -p 'Analyze auth.py for security issues' --output-format json --max-turns 5", workdir="/project", timeout=120)

# Resume session
terminal(command="claude -p 'Continue' --continue", workdir="/project")
```

**Claude-specific advantages:**
- **Subagent orchestration** — Claude can spawn and coordinate subagents mid-task
- **Agent teams** (`--teammate-mode tmux`) — multiple Claude instances communicate
- **CLAUDE.md auto-load** — project context file consumed automatically
- **Custom slash commands** — `.claude/commands/<name>.md` for repeatable workflows
- **Worktree isolation** (`-w feature-x`) — built-in branch isolation

**PTY dialog handling (CRITICAL):**

Claude Code shows up to two confirmation dialogs on first launch:

1. **Workspace Trust** — "Yes, I trust this folder" (default, just press Enter)
2. **Bypass Permissions** — appears only with `--dangerously-skip-permissions`. Default is "No, exit" — must Down then Enter.

```bash
# Robust pattern
sleep 4 && tmux send-keys -t <session> Enter          # trust dialog
sleep 3 && tmux send-keys -t <session> Down          # permissions
sleep 0.3 && tmux send-keys -t <session> Enter
```

After first trust acceptance, trust dialog won't recur. Permissions dialog recurs with `--dangerously-skip-permissions`.

**Two orchestration modes:**

- **Print mode (`-p`)** — non-interactive, exits when done. **Preferred for most tasks.** Skips ALL dialogs.
- **Interactive PTY** — full conversational REPL. Use when you need multi-turn iteration or slash commands.

**Cost & performance:**

- Use `--max-turns` (print mode only) to cap agentic loops
- Use `--max-budget-usd` for cost caps (minimum ~$0.05)
- Use `--effort low` for simple tasks, `high`/`max` for complex
- Use `--bare` for CI (skips plugins/hooks/MCP/CLAUDE.md)
- Use `--model haiku` for cheap simple tasks
- Pipe input instead of file reads: `cat file | claude -p "analyze"`
- Session lasts 5 hours; start fresh for distinct tasks

**Context window health:**

- `< 70%` — normal, full precision
- `70-85%` — precision drops; use `/compact`
- `> 85%` — hallucination risk spikes; `/compact` or `/clear`

---

## 3. Codex

**Full reference:** `references/codex.md`.

**Quick start:**

```bash
# Install
npm install -g @openai/codex

# Auth (one-time)
codex auth login
# or: export OPENAI_API_KEY

# One-shot (PTY required)
terminal(command="codex exec 'Add dark mode toggle to settings'", workdir="~/project", pty=true)

# Background long task
terminal(command="codex exec --full-auto 'Refactor the auth module'", workdir="~/project", background=true, pty=true)
```

**Key flags:**

| Flag | Effect |
|---|---|
| `exec "prompt"` | One-shot execution, exits when done |
| `--full-auto` | Sandboxed, auto-approves file changes |
| `--yolo` | No sandbox, no approvals (fastest, most dangerous) |

**Codex-specific quirks:**

- **MUST run inside a git repo** — refuses otherwise
- **`pty=true` mandatory** in all terminal calls — Codex is an interactive app
- **No `--continue` style flags** — Codex's session model is different

**Batch PR reviews:**

```bash
# Fetch all PR refs
git fetch origin '+refs/pull/*/head:refs/remotes/origin/pr/*'

# Review multiple PRs in parallel
terminal(command="codex exec 'Review PR #86. git diff origin/main...origin/pr/86'", workdir="~/project", background=true, pty=true)
terminal(command="codex exec 'Review PR #87. git diff origin/main...origin/pr/87'", workdir="~/project", background=true, pty=true)
```

---

## 4. OpenCode

**Full reference:** `references/opencode.md`.

**Quick start:**

```bash
# Install
npm i -g opencode-ai@latest
# or: brew install anomalyco/tap/opencode

# Auth
opencode auth login
# or: set OPENROUTER_API_KEY etc.

# Verify
opencode auth list   # must show at least one provider

# One-shot
terminal(command="opencode run 'Add retry logic to API calls and update tests'", workdir="~/project")

# Interactive
terminal(command="opencode", workdir="~/project", background=true, pty=true)
```

**Common flags:**

| Flag | Use |
|---|---|
| `run 'prompt'` | One-shot execution |
| `--continue` / `-c` | Continue last session |
| `--session <id>` / `-s` | Resume specific session |
| `--model provider/model` | Force specific model |
| `--format json` | Machine-readable output |
| `--file <path>` / `-f` | Attach files |
| `--thinking` | Show model thinking |
| `--variant <level>` | Reasoning effort |
| `--title <name>` | Name the session |

**TUI keybindings (interactive mode):**

| Key | Action |
|---|---|
| Enter | Submit (press twice if needed) |
| Tab | Switch between agents (build/plan) |
| Ctrl+P | Command palette |
| Ctrl+X L | Switch session |
| Ctrl+X M | Switch model |
| Ctrl+X N | New session |
| Ctrl+C | Exit (NOT `/exit`!) |

**Important:** `/exit` is NOT a valid OpenCode command — it opens an agent selector. Use `Ctrl+C` (`\x03`) or `process(action="kill")` to exit.

**Session & cost management:**

```bash
opencode session list                # past sessions
opencode stats                       # total usage
opencode stats --days 7 --models anthropic/claude-sonnet-4
```

**PR review:**

```bash
# Built-in
terminal(command="opencode pr 42", workdir="~/project", pty=true)

# Or in a fresh clone
REVIEW=$(mktemp -d) && git clone https://github.com/user/repo.git $REVIEW && cd $REVIEW
opencode run 'Review this PR vs main. Report bugs, security risks, test gaps.' -f <files>
```

**oh-my-openagent concurrency limit pitfall:**

`oh-my-openagent` runs parallel agents via `background_task` — this can hit ZAI/GLM provider concurrency limits in the afternoon.

**Mitigations:**

1. Limit parallel agents in oh-my-openagent config
2. Spread across providers (geminicli2api, etc.)
3. Switch to Claude Code in the afternoon
4. Use a mix of GLM 5.1/5/4.5/4.6v (already in use)

---

## 4b. gjc (gajae-code)

**Full reference:** `references/gjc.md`.

> ⚠️ **패키지명 ≠ 바이너리명 함정**: `gajae-code` 패키지를 설치하면 바이너리는 `gjc`. "gajae가 실행 안 돼" → `gjc`를 찾으면 됨.

**Quick start:**

```bash
# Install (bun)
bun add -g gajae-code

# PATH 추가 (bun 글로벌 bin이 자동 등록 안 됨)
export PATH="$HOME/.bun/bin:$PATH"

# Verify
gjc --version           # → gjc v0.10.1

# 모델 지정 (provider 등록 후 또는 --api-key)
gjc --model minimax/MiniMax-M3 "프롬프트"

# 비대화형
gjc -p "이 파일 버그 찾아줘: @bug.py"

# 영구 프로필
gjc --mpreset minimax --default

# OpenAI-compatible provider 등록 (중국 모델 API 등)
gjc setup provider
```

**gjc-specific advantages:**
- **Multi-provider 라우팅** — Claude/Anthropic 외 OpenAI-compat (대부분 중국 모델 API) 지원
- **프로필 시스템** — `--mpreset <name>`으로 모델 + 역할별(smol/slow/plan) 모델을 한 번에 활성화
- **공유 온보딩** — `gjc setup provider` / `/provider add`로 OpenAI-compat/Anthropic-compat API 등록 절차가 통일됨
- **풍부한 disable 플래그** — `--no-tools`, `--no-lsp`, `--no-pty`, `--no-skills`, `--no-rules`, `--no-extensions` 세밀 제어
- **Bridge/RPC 모드** — `--mode bridge|rpc|acp|rpc-ui`로 외부 도구 통합
- **확장 시스템** — `--hook`, `-e/--extension`로 커스텀 hook/extension 파일 직접 로드

**자주 만나는 함정 (2026-07-13 검증):**
1. `~/.bun/bin`이 PATH에 없으면 `command not found` — brew/rbenv 사용자 특히 자주 빠짐
2. `--list-models`가 "No models available" → credential이 어디에도 없음, 키가 있어도 provider 등록 전엔 모델 안 보임
3. `--api-key` 또는 환경변수가 등록 안 된 상태에서 `--model minimax/...` 호출 → 인증 실패

---

## 5. Cross-Agent Comparison

| Dimension | Claude Code | Codex | OpenCode | gjc |
|---|---|---|---|---|
| Provider | Anthropic | OpenAI | Any (OpenRouter/ZAI/GLM/Ollama) | Any (OpenAI-compat/Anthropic-compat) + built-in onboarding |
| Best for | Complex refactors, multi-agent, subagent orchestration | One-shots, batch reviews, simple refactors | Model-flexible tasks, cost optimization, offline use | Multi-provider 라우팅, 프로필 영구화, 정밀 도구/extension 제어 |
| PTY required | Interactive only | Always | Interactive only | Interactive only |
| `--print`/`exec` | `-p` flag | `exec` subcommand | `run` subcommand | `-p` flag |
| Session continuation | `--continue`, `--resume <id>`, `--fork-session` | Limited | `-c`, `-s <id>` | `--continue`, `-r/--resume <id>` |
| Worktree isolation | `-w feature-x` | Manual | Manual | Manual |
| Subagent spawning | Yes (built-in) | No | Tab between build/plan agents | No (CLI는 단일; extension 가능) |
| Custom slash commands | `.claude/commands/` | No | No | `/model` Profiles + `/provider add` |
| MCP integration | `claude mcp add` | Limited | Limited | Limited |
| Cost cap | `--max-budget-usd` | None built-in | Manual via provider | `--max-budget` style cap via provider |
| Provider 등록 도구 | 수동 | 수동 | 수동 | **내장 `gjc setup provider` / `/provider add`** |
| Profile 시스템 | `--model` 단일 | `--model` 단일 | `--model` 단일 | **`--mpreset <name>` (smol/slow/plan 동시 설정)** |
| Bridge/RPC 모드 | `--output-format json` | ❌ | `--format json` | **`--mode bridge\|rpc\|acp\|rpc-ui`** |

**Decision rule:**

- **Reach for Claude Code first** when: complex multi-step task, subagent spawning needed, want session continuation, want cost caps
- **Reach for Codex when**: simple one-shot, OpenAI-only environment, batch review of many PRs
- **Reach for OpenCode when**: need specific non-Anthropic/non-OpenAI model, offline Ollama, want flexible provider routing
- **Reach for gjc when**: 여러 provider를 영구 프로필로 관리하고 싶음, OpenAI-compat provider를 가이드된 온보딩으로 등록하고 싶음, `--no-tools/--no-lsp/--no-skills` 같은 세밀 제어가 필요함, bridge/rpc 모드로 외부 도구 통합

### 5.1 Session Switcher — Cross-Agent Detailed Comparison (2026-07-07)

사용자가 "Codex도 OpenCode의 세션 스위치와 같은 거 없나?" 라고 물을 때 — **세 가지 도구가 완전히 다른 세션 철학**을 가짐. 한 줄 답변만으론 부족하니 상세 비교:

| 기능 | Claude Code | Codex | OpenCode |
|---|---|---|---|
| 세션 ID 발행 | 자동 (UUID) | ❌ CLI는 미발행 (Cloud만) | 자동 (`ses_abc123...`) |
| 마지막 세션 이어가기 | `--continue` | ❌ 없음 | `-c` / `--continue` |
| 특정 세션 ID 재개 | `--resume <id>`, `--fork-session` | ❌ 없음 | `-s <id>` / `--session` |
| TUI 즉시 전환 (live) | Claude Code TUI 자체 | ❌ TUI 매우 단순 | `Ctrl+X L` (session), `Ctrl+X M` (model), `Ctrl+X N` (new) |
| 여러 세션 동시 유지 | ✅ 세션별 disk 영속화 | ❌ exec 1회 = 1세션 (실행 후 종료) | ✅ session store 누적 |
| 세션 목록 | `claude session list` (제한적) | ❌ 없음 | `opencode session list` |
| 세션 이름 지정 | ❌ | ❌ | `--title "name"` |
| 비용/통계 추적 | `/cost` 명령 | ❌ 없음 | `opencode stats --days 7` |
| CLI 설계 목표 | "오래 사는 대화" | "각 요청은 독립 (API 호출 멘탈 모델)" | "오래 사는 대화 + 멀티 에이전트" |

**Why Codex에 세션 스위치가 없는가** — 설계 철학 차이:
- **OpenCode/Claude Code** = "에이전트가 컨텍스트를 누적하며 학습하는 대화" 철학 → disk 영속화 + 멀티세션 스위처 필수
- **Codex** = "API 호출과 비슷한 멘탈 모델, 각 작업은 독립" 철학 → 1회 exec 후 종료, 컨텍스트 없음

**Codex에서 세션 비슷한 것 흉내내는 3가지 패턴:**
1. **별도 worktree + git으로 기억** — `git worktree add -b feat/x` + Codex가 각 worktree에서 exec → git이 컨텍스트 역할
2. **Codex Cloud (웹 인터페이스)** — 웹에서만 세션 resume 지원, CLI 워크플로에선 사용 불가
3. **tmux + 여러 Codex 프로세스 동시 실행** — `terminal(background=true, pty=true)` 로 띄우고 tmux pane 전환, **세션 공유는 git으로만**

**전환 의사결정 가이드** — "Codex로 갈까?" 고민할 때:
- **YES, Codex로 가도 무방** — 각 코딩미션이 독립 (OpenCode로 일했다면 같은 패턴), 1-shot 작업 많음, 배치 PR 리뷰 많음
- **NO, OpenCode 유지** — "어제 작업 이어서" 패턴이 잦음, 컨텍스트 누적 학습이 핵심, oh-my-openagent 멀티 에이전트 활용

**scoping 한정** — 이 비교는 **CLI 사용 워크플로 기준**. Codex Cloud (웹), Claude.ai 웹, OpenCode 서버 모드는 별도.

---

## 6. Parallel Worktree Pattern

Fix N issues in parallel using git worktrees. Each gets a fresh branch + directory.

```bash
# Create worktrees
terminal(command="git worktree add -b fix/issue-78 /tmp/issue-78 main", workdir="~/project")
terminal(command="git worktree add -b fix/issue-99 /tmp/issue-99 main", workdir="~/project")

# Launch agent in each (Claude example)
terminal(command="claude -p --yolo 'Fix issue #78: <description>. Commit when done.'", workdir="/tmp/issue-78", background=true, pty=true)
terminal(command="claude -p --yolo 'Fix issue #99: <description>. Commit when done.'", workdir="/tmp/issue-99", background=true, pty=true)

# Monitor
process(action="list")

# After completion, push and create PRs
terminal(command="cd /tmp/issue-78 && git push -u origin fix/issue-78")
terminal(command="gh pr create --repo user/repo --head fix/issue-78 --title 'fix: ...' --body '...'")

# Cleanup
terminal(command="git worktree remove /tmp/issue-78", workdir="~/project")
```

**Important:** use separate workdirs/worktrees per parallel agent. Sharing one directory causes collisions.

---

## 7. PR Review with Coding Agents

### 7.1 Quick Review (one agent)

```bash
# In a worktree for safety
REVIEW=$(mktemp -d) && git clone https://github.com/user/repo.git $REVIEW && cd $REVIEW
gh pr checkout 42

# Claude
terminal(command="claude -p 'Review this diff thoroughly for bugs, security issues, test gaps' --max-turns 5", workdir="$REVIEW", timeout=120)

# Codex
terminal(command="codex review --base origin/main", workdir="$REVIEW", pty=true)

# OpenCode
terminal(command="opencode run 'Review this PR vs main. Report bugs, security risks.' -f $(git diff origin/main --name-only | head -20 | tr '\n' ' ')", workdir="$REVIEW", timeout=120)
```

### 7.2 Batch Review (parallel)

```bash
# Fetch all PR refs
git fetch origin '+refs/pull/*/head:refs/remotes/origin/pr/*'

# Review N PRs in parallel
for n in 86 87 88; do
  terminal(command="codex exec 'Review PR #$n. git diff origin/main...origin/pr/$n'", workdir="~/project", background=true, pty=true) &
done
wait

# Post results
gh pr comment 86 --body '<review output>'
```

### 7.3 Inline Comments via API

After review, post findings as PR comments:

```bash
# Claude-style: emit JSON, then post
gh pr comment 86 --body "$REVIEW_OUTPUT"

# Atomic multi-comment review via API
HEAD_SHA=$(curl -s -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$GH_OWNER/$GH_REPO/pulls/86 \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['head']['sha'])")

curl -s -X POST -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$GH_OWNER/$GH_REPO/pulls/86/reviews \
  -d "{\"commit_id\":\"$HEAD_SHA\",\"event\":\"COMMENT\",\"body\":\"AI review\",\"comments\":[...]}"
```

See the `github-cli` skill (§5) for full PR review workflow.

---

## 8. Common Pitfalls (All Agents)

1. **PTY missing → silent hang.** Always `pty=true` for interactive sessions. Print mode / one-shot doesn't need PTY (Claude, OpenCode) — but Codex always does.
2. **Run from a git repo.** All three refuse non-git dirs. `mktemp -d && git init` for scratch.
3. **Max-turns runaway.** Always set `--max-turns` for one-shots. Default may not exist; set 5-20 explicitly.
4. **Sharing one working dir across parallel agents** → file collisions. Use worktrees or separate dirs.
5. **Don't kill slow sessions prematurely.** Agents may be doing multi-step work; check progress with `process(action="log")`.
6. **Cost caps for Claude:** `--max-budget-usd 0.05` is minimum (system prompt cache alone costs ~$0.05). Setting lower errors immediately.
7. **PATH mismatch in OpenCode** can pick the wrong binary/model config. Pin explicit path if needed.
8. **OpenCode `/exit` is invalid** — it opens an agent selector. Use `Ctrl+C` or kill.
9. **Codex's auth** may be in `~/.codex/auth.json` (CLI OAuth) rather than `OPENAI_API_KEY` env. Don't assume missing env = missing auth.
10. **Claude Code's interactive mode** requires tmux for state observation (`capture-pane` + `send-keys`). Bare `pty=true` works but is blind to the agent's state.
11. **gjc 패키지명 ≠ 바이너리명** — `gajae-code` 설치 후 `gjc` 실행. `gajae`라는 명령은 존재하지 않음.
12. **gjc PATH** — bun 글로벌 설치 후 `~/.bun/bin`이 PATH에 없으면 `command not found`. brew/rbenv 사용자에게 특히 자주 발생. `export PATH="$HOME/.bun/bin:$PATH"` 추가 필요.
13. **gjc credential 등록** — API 키가 있어도 `gjc setup provider` 또는 `--api-key`/`--credential`로 provider 등록 전에는 `--list-models`가 "No models available" 반환.

---

## Related Skills

- **`github-cli`** — full GitHub workflow including PR creation, review, and CI
- **`plan`** — write implementation plans for delegation
- **`subagent-driven-development`** — use this umbrella's agents in TDD-driven task execution
- **`requesting-code-review`** — pre-commit verification (static scan + tests + reviewer subagent)
- **`kanban-orchestrator` / `kanban-worker`** — Hermes's native multi-agent dispatch (different mechanism from CLI agents)
