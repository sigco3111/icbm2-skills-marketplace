---
name: autonomous-coding-agents
description: Delegate coding work to a CLI-based autonomous coding agent (Claude Code, OpenAI Codex, or OpenCode) via the Hermes terminal. Covers one-shot tasks, interactive PTY orchestration via tmux, parallel worktrees, PR review, and session continuation. Pick a sub-reference for the specific agent's flags, modes, and quirks.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [Coding-Agent, Claude-Code, Codex, OpenCode, Anthropic, OpenAI, Autonomous, Refactoring, Code-Review, PTY, tmux, Automation]
---

# Autonomous Coding Agents

Delegate coding work to an autonomous CLI agent. This umbrella covers three tools:

- **[Claude Code](#claude-code)** (`claude`) — Anthropic's agent. Best for: complex multi-step work, subagent orchestration, large refactors. See `references/claude-code.md` for full flag reference.
- **[Codex](#codex)** (`codex`) — OpenAI's agent. Best for: one-shot tasks, batch PR reviews. See `references/codex.md`.
- **[OpenCode](#opencode)** (`opencode`) — Provider-agnostic open-source agent. Best for: model-flexible tasks, OpenRouter/ZAI/GLM routing. See `references/opencode.md`.

Each sub-reference has the full per-agent flag list, auth flow, and quirks. This umbrella is the shared orchestration layer.

**Sections:**
1. [Common orchestration patterns](#common-orchestration-patterns) — all three agents
2. [Claude Code](#claude-code) — see `references/claude-code.md`
3. [Codex](#codex) — see `references/codex.md`
4. [OpenCode](#opencode) — see `references/opencode.md`
5. [Cross-agent comparison](#cross-agent-comparison) — when to use which
6. [Parallel worktree pattern](#parallel-worktree-pattern) — fix N issues in parallel
7. [PR review with coding agents](#pr-review-with-coding-agents)
8. [Common pitfalls](#common-pitfalls)

---

## 1. Common Orchestration Patterns

All three agents follow the same conceptual lifecycle, with agent-specific implementation details.

### 1.1 One-Shot Task (non-interactive)

Print-style execution: agent reads input, makes changes, exits. No PTY needed.

```bash
# Claude Code
terminal(command="claude -p 'Add error handling to all API calls in src/' --allowedTools 'Read,Edit' --max-turns 10", workdir="/path/to/project", timeout=120)

# Codex
terminal(command="codex exec 'Add dark mode toggle to settings'", workdir="~/project", pty=true)

# OpenCode
terminal(command="opencode run 'Add retry logic to API calls and update tests'", workdir="~/project")
```

`--max-turns` / `--full-auto` flags cap agentic loops and prevent runaway costs. **Always set these for one-shots.**

### 1.2 Interactive Multi-Turn (PTY via tmux)

For iterative work, the agent needs a real terminal. Hermes's terminal tool doesn't run a long-lived TUI directly, so use tmux.

```bash
# Start tmux session
terminal(command="tmux new-session -d -s coding-work -x 140 -y 40")

# Launch the agent inside
terminal(command="tmux send-keys -t coding-work 'cd /path/to/project && <agent-cli>' Enter")

# Wait for startup, then send the task
sleep 5
terminal(command="tmux send-keys -t coding-work '<your task prompt>' Enter")

# Monitor
terminal(command="sleep 15 && tmux capture-pane -t coding-work -p -S -50")

# Send follow-up
terminal(command="tmux send-keys -t coding-work '<follow-up>' Enter")

# Exit cleanly
terminal(command="tmux kill-session -t coding-work")
```

### 1.3 Background Long-Running Task

For tasks that won't finish within a normal terminal call:

```bash
terminal(command="<agent> <args>", workdir="~/project", background=true, pty=true)
# Returns session_id

# Monitor
process(action="poll", session_id="<id>")
process(action="log", session_id="<id>")

# Send input if agent asks a question
process(action="submit", session_id="<id>", data="yes")

# Kill
process(action="kill", session_id="<id>")
```

**PTY is mandatory** for all three agents in interactive mode. Without it they hang silently.

### 1.4 Auth Setup (All Agents)

| Agent | Auth command | Verify |
|---|---|---|
| Claude Code | `claude auth login` (browser) or `claude auth login --console` (API key) or `--sso` (Enterprise) | `claude auth status` |
| Codex | `codex auth login` or set `OPENAI_API_KEY` | `codex auth list` |
| OpenCode | `opencode auth login` or set provider env vars (`OPENROUTER_API_KEY`, etc.) | `opencode auth list` |

For OpenCode, the binary may resolve differently across shells — always verify:

```bash
which -a opencode
opencode --version
```

If behavior differs from a fresh terminal, pin the explicit path: `$HOME/.opencode/bin/opencode run '...'`.

### 1.5 Git Repository Required

All three agents refuse to run outside a git repo (some enforce this strictly).

```bash
# For scratch work
REVIEW=$(mktemp -d) && git clone https://github.com/user/repo.git $REVIEW && cd $REVIEW
```

---

## 2. Claude Code

**Full reference:** `references/claude-code.md` (CLI flags, settings hierarchy, hooks, MCP integration, custom subagents, cost tips).

**Quick start:**

```bash
# Install
npm install -g @anthropic-ai/claude-code

# Auth (one-time)
claude

# One-shot
terminal(command="claude -p 'Add error handling to API calls' --allowedTools 'Read,Edit' --max-turns 10", workdir="/project", timeout=120)

# Structured output
terminal(command="claude -p 'Analyze auth.py for security issues' --output-format json --max-turns 5", workdir="/project", timeout=120)

# Resume session
terminal(command="claude -p 'Continue' --continue", workdir="/project")
```

**Claude-specific advantages:**
- **Subagent orchestration** — Claude can spawn and coordinate subagents mid-task
- **Agent teams** (`--teammate-mode tmux`) — multiple Claude instances communicate
- **CLAUDE.md auto-load** — project context file consumed automatically
- **Custom slash commands** — `.claude/commands/<name>.md` for repeatable workflows
- **Worktree isolation** (`-w feature-x`) — built-in branch isolation

**PTY dialog handling (CRITICAL):**

Claude Code shows up to two confirmation dialogs on first launch:

1. **Workspace Trust** — "Yes, I trust this folder" (default, just press Enter)
2. **Bypass Permissions** — appears only with `--dangerously-skip-permissions`. Default is "No, exit" — must Down then Enter.

```bash
# Robust pattern
sleep 4 && tmux send-keys -t <session> Enter          # trust dialog
sleep 3 && tmux send-keys -t <session> Down          # permissions
sleep 0.3 && tmux send-keys -t <session> Enter
```

After first trust acceptance, trust dialog won't recur. Permissions dialog recurs with `--dangerously-skip-permissions`.

**Two orchestration modes:**

- **Print mode (`-p`)** — non-interactive, exits when done. **Preferred for most tasks.** Skips ALL dialogs.
- **Interactive PTY** — full conversational REPL. Use when you need multi-turn iteration or slash commands.

**Cost & performance:**

- Use `--max-turns` (print mode only) to cap agentic loops
- Use `--max-budget-usd` for cost caps (minimum ~$0.05)
- Use `--effort low` for simple tasks, `high`/`max` for complex
- Use `--bare` for CI (skips plugins/hooks/MCP/CLAUDE.md)
- Use `--model haiku` for cheap simple tasks
- Pipe input instead of file reads: `cat file | claude -p "analyze"`
- Session lasts 5 hours; start fresh for distinct tasks

**Context window health:**

- `< 70%` — normal, full precision
- `70-85%` — precision drops; use `/compact`
- `> 85%` — hallucination risk spikes; `/compact` or `/clear`

---

## 3. Codex

**Full reference:** `references/codex.md`.

**Quick start:**

```bash
# Install
npm install -g @openai/codex

# Auth (one-time)
codex auth login
# or: export OPENAI_API_KEY

# One-shot (PTY required)
terminal(command="codex exec 'Add dark mode toggle to settings'", workdir="~/project", pty=true)

# Background long task
terminal(command="codex exec --full-auto 'Refactor the auth module'", workdir="~/project", background=true, pty=true)
```

**Key flags:**

| Flag | Effect |
|---|---|
| `exec "prompt"` | One-shot execution, exits when done |
| `--full-auto` | Sandboxed, auto-approves file changes |
| `--yolo` | No sandbox, no approvals (fastest, most dangerous) |

**Codex-specific quirks:**

- **MUST run inside a git repo** — refuses otherwise
- **`pty=true` mandatory** in all terminal calls — Codex is an interactive app
- **No `--continue` style flags** — Codex's session model is different

**Batch PR reviews:**

```bash
# Fetch all PR refs
git fetch origin '+refs/pull/*/head:refs/remotes/origin/pr/*'

# Review multiple PRs in parallel
terminal(command="codex exec 'Review PR #86. git diff origin/main...origin/pr/86'", workdir="~/project", background=true, pty=true)
terminal(command="codex exec 'Review PR #87. git diff origin/main...origin/pr/87'", workdir="~/project", background=true, pty=true)
```

---

## 4. OpenCode

**Full reference:** `references/opencode.md`.

**Quick start:**

```bash
# Install
npm i -g opencode-ai@latest
# or: brew install anomalyco/tap/opencode

# Auth
opencode auth login
# or: set OPENROUTER_API_KEY etc.

# Verify
opencode auth list   # must show at least one provider

# One-shot
terminal(command="opencode run 'Add retry logic to API calls and update tests'", workdir="~/project")

# Interactive
terminal(command="opencode", workdir="~/project", background=true, pty=true)
```

**Common flags:**

| Flag | Use |
|---|---|
| `run 'prompt'` | One-shot execution |
| `--continue` / `-c` | Continue last session |
| `--session <id>` / `-s` | Resume specific session |
| `--model provider/model` | Force specific model |
| `--format json` | Machine-readable output |
| `--file <path>` / `-f` | Attach files |
| `--thinking` | Show model thinking |
| `--variant <level>` | Reasoning effort |
| `--title <name>` | Name the session |

**TUI keybindings (interactive mode):**

| Key | Action |
|---|---|
| Enter | Submit (press twice if needed) |
| Tab | Switch between agents (build/plan) |
| Ctrl+P | Command palette |
| Ctrl+X L | Switch session |
| Ctrl+X M | Switch model |
| Ctrl+X N | New session |
| Ctrl+C | Exit (NOT `/exit`!) |

**Important:** `/exit` is NOT a valid OpenCode command — it opens an agent selector. Use `Ctrl+C` (`\x03`) or `process(action="kill")` to exit.

**Session & cost management:**

```bash
opencode session list                # past sessions
opencode stats                       # total usage
opencode stats --days 7 --models anthropic/claude-sonnet-4
```

**PR review:**

```bash
# Built-in
terminal(command="opencode pr 42", workdir="~/project", pty=true)

# Or in a fresh clone
REVIEW=$(mktemp -d) && git clone https://github.com/user/repo.git $REVIEW && cd $REVIEW
opencode run 'Review this PR vs main. Report bugs, security risks, test gaps.' -f <files>
```

**oh-my-openagent concurrency limit pitfall:**

`oh-my-openagent` runs parallel agents via `background_task` — this can hit ZAI/GLM provider concurrency limits in the afternoon.

**Mitigations:**

1. Limit parallel agents in oh-my-openagent config
2. Spread across providers (geminicli2api, etc.)
3. Switch to Claude Code in the afternoon
4. Use a mix of GLM 5.1/5/4.5/4.6v (already in use)

---

## 5. Cross-Agent Comparison

| Dimension | Claude Code | Codex | OpenCode |
|---|---|---|---|
| Provider | Anthropic | OpenAI | Any (OpenRouter/ZAI/GLM/Ollama) |
| Best for | Complex refactors, multi-agent, subagent orchestration | One-shots, batch reviews, simple refactors | Model-flexible tasks, cost optimization, offline use |
| PTY required | Interactive only | Always | Interactive only |
| `--print`/`exec` | `-p` flag | `exec` subcommand | `run` subcommand |
| Session continuation | `--continue`, `--resume <id>`, `--fork-session` | Limited | `-c`, `-s <id>` |
| Worktree isolation | `-w feature-x` | Manual | Manual |
| Subagent spawning | Yes (built-in) | No | Tab between build/plan agents |
| Custom slash commands | `.claude/commands/` | No | No |
| MCP integration | `claude mcp add` | Limited | Limited |
| Cost cap | `--max-budget-usd` | None built-in | Manual via provider |

**Decision rule:**

- **Reach for Claude Code first** when: complex multi-step task, subagent spawning needed, want session continuation, want cost caps
- **Reach for Codex when**: simple one-shot, OpenAI-only environment, batch review of many PRs
- **Reach for OpenCode when**: need specific non-Anthropic/non-OpenAI model, offline Ollama, want flexible provider routing

---

## 6. Parallel Worktree Pattern

Fix N issues in parallel using git worktrees. Each gets a fresh branch + directory.

```bash
# Create worktrees
terminal(command="git worktree add -b fix/issue-78 /tmp/issue-78 main", workdir="~/project")
terminal(command="git worktree add -b fix/issue-99 /tmp/issue-99 main", workdir="~/project")

# Launch agent in each (Claude example)
terminal(command="claude -p --yolo 'Fix issue #78: <description>. Commit when done.'", workdir="/tmp/issue-78", background=true, pty=true)
terminal(command="claude -p --yolo 'Fix issue #99: <description>. Commit when done.'", workdir="/tmp/issue-99", background=true, pty=true)

# Monitor
process(action="list")

# After completion, push and create PRs
terminal(command="cd /tmp/issue-78 && git push -u origin fix/issue-78")
terminal(command="gh pr create --repo user/repo --head fix/issue-78 --title 'fix: ...' --body '...'")

# Cleanup
terminal(command="git worktree remove /tmp/issue-78", workdir="~/project")
```

**Important:** use separate workdirs/worktrees per parallel agent. Sharing one directory causes collisions.

---

## 7. PR Review with Coding Agents

### 7.1 Quick Review (one agent)

```bash
# In a worktree for safety
REVIEW=$(mktemp -d) && git clone https://github.com/user/repo.git $REVIEW && cd $REVIEW
gh pr checkout 42

# Claude
terminal(command="claude -p 'Review this diff thoroughly for bugs, security issues, test gaps' --max-turns 5", workdir="$REVIEW", timeout=120)

# Codex
terminal(command="codex review --base origin/main", workdir="$REVIEW", pty=true)

# OpenCode
terminal(command="opencode run 'Review this PR vs main. Report bugs, security risks.' -f $(git diff origin/main --name-only | head -20 | tr '\n' ' ')", workdir="$REVIEW", timeout=120)
```

### 7.2 Batch Review (parallel)

```bash
# Fetch all PR refs
git fetch origin '+refs/pull/*/head:refs/remotes/origin/pr/*'

# Review N PRs in parallel
for n in 86 87 88; do
  terminal(command="codex exec 'Review PR #$n. git diff origin/main...origin/pr/$n'", workdir="~/project", background=true, pty=true) &
done
wait

# Post results
gh pr comment 86 --body '<review output>'
```

### 7.3 Inline Comments via API

After review, post findings as PR comments:

```bash
# Claude-style: emit JSON, then post
gh pr comment 86 --body "$REVIEW_OUTPUT"

# Atomic multi-comment review via API
HEAD_SHA=$(curl -s -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$GH_OWNER/$GH_REPO/pulls/86 \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['head']['sha'])")

curl -s -X POST -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$GH_OWNER/$GH_REPO/pulls/86/reviews \
  -d "{\"commit_id\":\"$HEAD_SHA\",\"event\":\"COMMENT\",\"body\":\"AI review\",\"comments\":[...]}"
```

See the `github-cli` skill (§5) for full PR review workflow.

---

## 8. Common Pitfalls (All Agents)

1. **PTY missing → silent hang.** Always `pty=true` for interactive sessions. Print mode / one-shot doesn't need PTY (Claude, OpenCode) — but Codex always does.
2. **Run from a git repo.** All three refuse non-git dirs. `mktemp -d && git init` for scratch.
3. **Max-turns runaway.** Always set `--max-turns` for one-shots. Default may not exist; set 5-20 explicitly.
4. **Sharing one working dir across parallel agents** → file collisions. Use worktrees or separate dirs.
5. **Don't kill slow sessions prematurely.** Agents may be doing multi-step work; check progress with `process(action="log")`.
6. **Cost caps for Claude:** `--max-budget-usd 0.05` is minimum (system prompt cache alone costs ~$0.05). Setting lower errors immediately.
7. **PATH mismatch in OpenCode** can pick the wrong binary/model config. Pin explicit path if needed.
8. **OpenCode `/exit` is invalid** — it opens an agent selector. Use `Ctrl+C` or kill.
9. **Codex's auth** may be in `~/.codex/auth.json` (CLI OAuth) rather than `OPENAI_API_KEY` env. Don't assume missing env = missing auth.
10. **Claude Code's interactive mode** requires tmux for state observation (`capture-pane` + `send-keys`). Bare `pty=true` works but is blind to the agent's state.

---

## Related Skills

- **`github-cli`** — full GitHub workflow including PR creation, review, and CI
- **`plan`** — write implementation plans for delegation
- **`subagent-driven-development`** — use this umbrella's agents in TDD-driven task execution
- **`requesting-code-review`** — pre-commit verification (static scan + tests + reviewer subagent)
- **`kanban-orchestrator` / `kanban-worker`** — Hermes's native multi-agent dispatch (different mechanism from CLI agents)
