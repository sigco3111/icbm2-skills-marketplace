#!/usr/bin/env bash
# validate-companion-stack.sh
# Full validation pass for a kiwi-style companion without launching a window.
# Exercises: LLM API call, TTS init, face module under dummy SDL.
#
# Usage: validate-companion-stack.sh /path/to/companion-dir
# Expects: llm.py, tts.py, face.py in the directory

set -euo pipefail

DIR="${1:?Usage: $0 <companion-dir>}"

if [[ ! -d "$DIR" ]]; then
  echo "ERROR: $DIR not found" >&2
  exit 2
fi

cd "$DIR"

echo "=== Validating companion stack in $DIR ==="
echo

# 1. LLM
if [[ -f llm.py ]] && [[ -n "${LLM_API_KEY:-${MINIMAX_API_KEY:-}}" ]]; then
  echo "[1/3] LLM call test..."
  if python3 llm.py "테스트" 2>&1 | tail -3; then
    echo "  [OK] LLM responded"
  else
    echo "  [FAIL] LLM call failed"
    exit 1
  fi
else
  echo "[1/3] LLM test skipped (no llm.py or no API key)"
fi

# 2. TTS
if [[ -f tts.py ]]; then
  echo "[2/3] TTS init test..."
  python3 -c "
import sys
sys.path.insert(0, '.')
from tts import KiwiSpeaker
s = KiwiSpeaker()
print(f'  [OK] TTS: {s.describe()}')
"
else
  echo "[2/3] TTS test skipped (no tts.py)"
fi

# 3. Face (headless)
if [[ -f face.py ]]; then
  echo "[3/3] Face module headless test..."
  SDL_VIDEODRIVER=dummy python3 -c "
import sys, threading, time
sys.path.insert(0, '.')
import face

f = face.KiwiFace()
t = threading.Thread(target=f.run, daemon=True)
t.start()
for _ in range(100):
    if f.is_ready():
        break
    time.sleep(0.05)
else:
    print('  [FAIL] Face did not become ready in 5s')
    sys.exit(1)

for e in ['neutral', 'happy', 'sad', 'thinking', 'surprised']:
    f.set_emotion(e)
    time.sleep(0.1)
f.set_speaking(True, 0.7)
time.sleep(0.3)
f.set_speaking(False)
f.request_quit()
time.sleep(0.3)
print('  [OK] Face module cycled all 5 emotions + mouth sync + clean exit')
"
else
  echo "[3/3] Face test skipped (no face.py)"
fi

echo
echo "=== Validation complete ==="
