# 🥝 Kiwi Companion (Minimal Template)

Copy-and-modify starter for a desktop companion simulator. Drop into a new directory, edit the constants and `EMOTION_PALETTE` in `face.py`, and run.

## Files

| File | Purpose |
|---|---|
| `llm.py` | LLM API client with emotion tag parsing |
| `tts.py` | pyttsx3 + Korean voice selection |
| `face.py` | pygame face renderer with blink + mouth sync |
| `kiwi.py` | Main loop, argparse, threading |

## Setup

```bash
# Install deps (one-time)
python3 -m pip install --user pygame pyttsx3

# Source API key
source ~/.hermes/secrets/minimax.env

# Run
python3 kiwi.py
```

## Customization points

1. **Character personality** — edit `SYSTEM_PROMPT` in `llm.py`
2. **Face colors** — edit `EMOTION_PALETTE` in `face.py`
3. **Window size** — edit `WINDOW_SIZE` in `face.py`
4. **Emotion count** — add to `EMOTION_PALETTE`, `VALID_EMOTIONS`, and the prompt
5. **Different LLM** — swap `call_llm()` body, keep the `{"text", "emotion", "raw"}` return contract

## What works out of the box

- 5 emotions: happy / sad / thinking / surprised / neutral
- Random eye blink every 3-5.5s
- Mouth opens/closes when speaking
- 20-turn conversation memory window
- Headless validation via `SDL_VIDEODRIVER=dummy`
- Korean TTS with Yuna (compact) voice
- Graceful shutdown on Ctrl-C / EOF / window X
