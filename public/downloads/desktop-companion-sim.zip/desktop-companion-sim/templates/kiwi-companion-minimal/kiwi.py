#!/usr/bin/env python3
"""
Kiwi Companion - Main loop (template)
"""
import argparse
import os
import sys
import threading
import time
from typing import List, Dict

import llm
from tts import KiwiSpeaker
import face


def speak_with_mouth_sync(speaker, face_obj, text: str):
    face_obj.set_speaking(True, amplitude=0.7)
    speaker.say(text, blocking=True)
    face_obj.set_speaking(False, amplitude=0.0)


def main_loop(face_obj, speaker, use_tts=True, max_history=20):
    conversation: List[Dict] = []

    print()
    print("=" * 50)
    print("🥝 Companion — 데스크탑 시뮬레이터")
    print("=" * 50)
    print(f"  - 얼굴: pygame 윈도우")
    print(f"  - LLM:  {llm.MODEL}")
    print(f"  - TTS:  {speaker.describe()}")
    print(f"  - 종료: 'quit' / 'exit' / 'q' / ESC / 윈도우 X")
    print("=" * 50)
    print()

    face_obj.set_emotion("happy")
    greeting = "안녕~! 만나서 반가워."
    print(f"[키위] {greeting}")
    if use_tts:
        speaker.say(greeting, blocking=False)
    conversation.append({"role": "assistant", "content": greeting})

    while True:
        try:
            user_input = input("\n[나] ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n[키위] 잘 가~!")
            face_obj.set_emotion("happy")
            if use_tts:
                speaker.say("잘 가~!", blocking=False)
            time.sleep(2)
            break

        if not user_input:
            continue
        if user_input.lower() in ("quit", "exit", "q", "종료"):
            print("[키위] 종료할게~!")
            face_obj.set_emotion("neutral")
            if use_tts:
                speaker.say("알겠어, 다음에 또 봐!", blocking=False)
            time.sleep(1.5)
            break

        face_obj.set_emotion("thinking")
        face_obj.set_speaking(False)
        print("[키위 생각 중...]", end="\r", flush=True)
        try:
            result = llm.call_llm(user_input, conversation=conversation[-max_history:])
        except Exception as e:
            print(f"\n[오류] LLM 호출 실패: {e}")
            face_obj.set_emotion("sad")
            continue

        text = result["text"]
        emotion = result["emotion"]

        face_obj.set_emotion(emotion)
        print(f"[키위:{emotion}] {text}")
        if use_tts:
            speak_with_mouth_sync(speaker, face_obj, text)
        else:
            face_obj.set_speaking(True, amplitude=0.7)
            time.sleep(min(len(text) * 0.08, 2.5))
            face_obj.set_speaking(False)

        conversation.append({"role": "user", "content": user_input})
        conversation.append({"role": "assistant", "content": text})
        if len(conversation) > max_history * 2:
            conversation = conversation[-max_history * 2:]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--no-tts", action="store_true", help="음성 끄기")
    args = parser.parse_args()

    if not os.environ.get("LLM_API_KEY"):
        print("[오류] LLM_API_KEY 환경변수가 없습니다.")
        print("실행 전: source ~/.hermes/secrets/minimax.env")
        sys.exit(1)

    face_obj = face.KiwiFace()
    threading.Thread(target=face_obj.run, daemon=True).start()

    timeout = 5.0
    waited = 0.0
    while not face_obj.is_ready() and waited < timeout:
        time.sleep(0.05)
        waited += 0.05

    speaker = KiwiSpeaker()

    try:
        main_loop(face_obj, speaker, use_tts=not args.no_tts)
    finally:
        face_obj.request_quit()
        speaker.stop()
        time.sleep(0.3)


if __name__ == "__main__":
    main()
