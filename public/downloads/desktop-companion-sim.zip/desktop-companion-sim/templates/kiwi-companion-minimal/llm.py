"""
Kiwi Companion - LLM Module (template)
Replace MiniMax with another provider by swapping call_llm().
"""
import os
import re
import json
from typing import List, Dict, Optional
import urllib.request
import urllib.error

# 감정 태그 정규식
EMOTION_RE = re.compile(r"\[emotion:\s*(happy|sad|thinking|surprised|neutral)\s*\]", re.IGNORECASE)
VALID_EMOTIONS = {"happy", "sad", "thinking", "surprised", "neutral"}

SYSTEM_PROMPT = """너의 이름은 '키위'야. (replace with your character)

[성격]
- 다정하고 명랑하지만, 사용자의 감정에 공감할 줄 알아
- 한국어로 대화 (존댓말 기본, 친근하게)
- 답변은 1~3문장으로 짧고 자연스럽게

[감정 표현]
모든 답변 끝에 반드시 다음 중 하나의 감정 태그를 붙여줘 (대괄호로):
[emotion:happy]    — 기쁨, 즐거움, 신남, 공감의 미소
[emotion:sad]      — 슬픔, 위로가 필요할 때
[emotion:thinking] — 생각 중, 의문, 분석
[emotion:surprised]— 놀라움, 반전, 깜짝
[emotion:neutral]  — 일반 대화, 인사
"""

BASE_URL = os.environ.get("LLM_BASE_URL", "https://api.minimax.io") + "/anthropic/v1/messages"
MODEL = os.environ.get("LLM_MODEL", "MiniMax-M3")


def call_llm(user_text: str, conversation: Optional[List[Dict]] = None) -> Dict:
    api_key = os.environ.get("LLM_API_KEY")
    if not api_key:
        raise RuntimeError("LLM_API_KEY 환경변수가 없습니다.")

    if conversation is None:
        conversation = []
    messages = list(conversation) + [{"role": "user", "content": user_text}]

    payload = {
        "model": MODEL,
        "max_tokens": 512,
        "system": SYSTEM_PROMPT,
        "messages": messages,
    }

    req = urllib.request.Request(
        BASE_URL,
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
        },
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"LLM API HTTP {e.code}: {body[:300]}")
    except urllib.error.URLError as e:
        raise RuntimeError(f"LLM API 연결 실패: {e.reason}")

    raw_text = ""
    for block in data.get("content", []):
        if block.get("type") == "text":
            raw_text += block.get("text", "")

    emotion = "neutral"
    match = EMOTION_RE.search(raw_text)
    if match:
        emotion = match.group(1).lower()
        if emotion not in VALID_EMOTIONS:
            emotion = "neutral"
    text = EMOTION_RE.sub("", raw_text).strip()

    return {"text": text, "emotion": emotion, "raw": raw_text}


if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("사용법: python3 llm.py '키위야 안녕!'")
        sys.exit(1)
    user_input = " ".join(sys.argv[1:])
    print(f"[사용자] {user_input}")
    result = call_llm(user_input)
    print(f"[키위]   {result['text']}")
    print(f"[감정]   {result['emotion']}")
