# 🥝 Kiwi v2 — Face Design + Crashes Session (2026-06-23, continuation)

Extension of `kiwi-stackchan-session.md` covering the second session that:
1. Resolved the third pygame crash (the elusive one)
2. Made the face actually look like StackChan (not just a green circle)
3. Discovered the pygame.arc direction trap via vision verification

Read this when:
- You're trying to make a desktop companion face look polished (not "a green circle with dots")
- Your pygame program is crashing in `event.cpython-311-darwin.so` / `pg_event_get` / `PyDict_SetItemString` even after the NSWindow fix
- `pygame.draw.arc` is drawing the wrong direction (∩ when you want ∪) and the obvious angle math doesn't help

---

## 1. Crash #3 — `SDLTimer` + `PyDict_SetItemString` race (the one that survived mixer init fix)

### Symptom

```text
Thread 0 Crashed::  Dispatch queue: com.apple.main-thread
0   ???                              0xf ???
1   python                           PyDict_SetItem + 3388
2   python                           PyDict_SetItemString + 77
3   event.cpython-311-darwin.so      pgEvent_New + 4596
4   event.cpython-311-darwin.so      pg_event_get + 696
...
Thread 10: SDLTimer  ← SDLTimer thread is still alive
```

Active threads after `display.init() + font.init()` (no `pygame.init()`):
```
Thread 10: SDLTimer           ← still here, even without mixer
Thread 11: com.apple.NSEventThread
```

### Why mixer init: False was NOT enough

`pygame.init()` activates SDL_INIT_AUDIO → AudioQueue/IOThread spawn → race with pyttsx3.
`pygame.mixer.init()` is the explicit audio init → same spawn.
We thought `display.init() + font.init()` only would be enough.

**It wasn't.** The remaining crash was caused by `pygame.time.Clock()`:

```python
self._clock = pygame.time.Clock()  # ← this creates SDLTimer thread
...
self._clock.tick(60)               # ← per-frame call
```

`pygame.time.Clock()` is the **other** thing that activates SDL's timer subsystem → spawns the `SDLTimer` thread → that thread posts events back to the main thread via a Python dict (the `pgEvent_New` → `PyDict_SetItemString` path) → race with whatever else is touching Python state → NULL deref at offset 0xf (a few bytes into a destroyed dict).

### The fix

Remove `pygame.time.Clock()` entirely. Frame timing is just "don't burn CPU":

```python
# In init_pygame:
# DO NOT do: self._clock = pygame.time.Clock()
self._clock = None  # explicitly unused

# In tick:
pygame.display.flip()
# DO NOT do: self._clock.tick(60)
# The main loop's time.sleep(0.005) is enough to throttle.
```

### Verification: what threads should look like after the fix

```bash
SDL_VIDEODRIVER=dummy python3 -c "
import sys; sys.path.insert(0, '.')
import face
f = face.KiwiFace()
ok = f.init_pygame()
print(f'init ok: {ok}')
f.shutdown()
"
```

After init, the active thread set should be **only** NSEventThread (AppKit) — no SDLTimer, no AudioQueue.

If you see SDLTimer still alive: `pygame.time.get_init()` returns True → you have a `Clock()` somewhere.

### Why this is a pygame 2.6.1 + Python 3.11 + macOS 15.5 specific bug

Pygame's timer subsystem calls back into the Python interpreter to construct `pygame.event.Event` objects, which goes through `PyDict_SetItemString("type"/"dict"/etc., value)`. The SDLTimer thread does this on its own thread. If main thread is mid-`PyDict_SetItem` (also possible from your own event-loop code) when SDLTimer fires, both touch the same dict internals without a lock → classic double-free / use-after-free → NULL deref.

Pygame's `pygame.event.get()` on the main thread is supposed to drain the queue before re-inserting, but with `pygame.init()` + `pygame.time.Clock()` + macOS cocoa + a 60fps loop there's enough timing slack for the race.

**Workaround that's known safe on Intel Mac:** never call `pygame.time.Clock()` and never call `pygame.init()`. Use `display.init()` + `font.init()` only.

---

## 2. StackChan-style face design — the emotion → eye/mouth mapping

### v1 was "a green circle with dots"

The first version rendered:
- Green circle (no body color, no highlights)
- Two small black eyes with white pupils
- A mouth drawn as one of {arc, circle, line} based on emotion string

User feedback: **"지금은 외형이 너무 별로임. StackChan과 같은 외형이면 좋겠음."**

### v2 redesign (4 decisions)

| Decision | What we picked | Why |
|---|---|---|
| ① Body | Brown circle (not green) + highlight + 12 fixed-position black "seeds" | Kiwi is brown, not green. Seeds are the visual signature of a kiwi. |
| ② Eyes | White sclera + dark pupil + 2 highlights (stackchan signature) | Looks "alive" with the highlights, not like dead circles |
| ③ Eye style per emotion | Different shape per emotion, not just color | `^ ^` (happy), `; ;` (sad with tear drops), `--` (thinking), `O O` (big surprised), `●●` (neutral) |
| ④ Mouth style per emotion | Different shape per emotion, not just arc | Big `∪` (open smile) vs small `o` (surprised) vs frown `∩` (sad) |

### The emotion palette as a single source of truth

Instead of `if emotion == "happy": draw X` scattered through the code, centralize all emotion visuals in `EMOTION_PALETTE`:

```python
EMOTION_PALETTE = {
    "happy": {
        "bg": (255, 248, 220),
        "body": (139, 111, 71),        # warm brown
        "cheek": (255, 156, 174),      # pink
        "eye_style": "closed_happy",   # ^ ^
        "mouth_style": "open_smile",   # big ∪
        "eye_color": (40, 30, 20),
        "mouth_color": (180, 60, 80),
    },
    "sad": { "body": (110, 95, 70), "eye_style": "sad", "mouth_style": "frown", ... },
    "thinking": { "body": (130, 115, 85), "eye_style": "line", "mouth_style": "small", ... },
    "surprised": { "body": (160, 130, 85), "eye_style": "big", "mouth_style": "o", ... },
    "neutral": { "body": (143, 115, 75), "eye_style": "circle", "mouth_style": "smile", ... },
}
```

This is the "data over code" pattern — adding a new emotion is a dict entry, not a function branch.

### The eye/mouth style dispatch

```python
def _draw_eye(self, x, y, color, style):
    if self._is_blinking:
        pygame.draw.line(...)  # always line when blinking
        return
    if style == "closed_happy":  # ^ ^
        for side in (-1, 1):
            pygame.draw.arc(window, color, (x-24, y-14, 48, 28), 0, math.pi, 5)
    elif style == "sad":         # ; ;
        pygame.draw.line(window, color, (x-18, y), (x+18, y), 4)
        pygame.draw.circle(window, color, (x-20, y+12), 3)  # tear
        pygame.draw.circle(window, color, (x-20, y+22), 2)  # tear drop
    elif style == "line":        # --
        pygame.draw.line(...)
    elif style == "big":         # O O
        pygame.draw.circle(window, (255,255,255), (x,y), 28)
        pygame.draw.circle(window, color, (x,y), 22)
        pygame.draw.circle(window, (255,255,255), (x-8, y-8), 7)  # big highlight
    # ... etc
```

### The "no seeds on the face" rule (data ≠ display)

The kiwi body has 12 black seed dots positioned randomly. But if a seed lands in the eye/mouth region, the face looks wrong. Solution: **render seeds first, then eyes/mouth, and skip seeds that would overlap the face center**.

```python
# Draw body
pygame.draw.circle(window, body_color, (cx, cy), FACE_RADIUS)

# Draw seeds, but skip ones that would land in the eye/mouth region
for _ in range(12):
    angle = rng.uniform(0, 2*math.pi)
    dist = rng.uniform(70, FACE_RADIUS - 25)
    sx, sy = int(cx + math.cos(angle)*dist), int(cy + math.sin(angle)*dist)
    # Center has the face features — don't put seeds there
    if abs(sy - cy) < 60 and abs(sx - cx) < 90:
        continue
    pygame.draw.circle(window, (50, 40, 25), (sx, sy), 2)

# Draw eyes + mouth LAST (on top of any stray seeds)
```

This is the "data ≠ display" principle: just because data exists doesn't mean you have to show it. Apply the same to (a) Notion DB columns you don't render, (b) YouTube B-roll you don't use, (c) README sections you don't write.

---

## 3. The pygame.arc direction trap (the 2-hour bug)

### The trap

You want to draw a smile (∪, upward-opening curve). Naive math:

```python
# "0 = 3 o'clock, 0.5π = 6 o'clock, π = 9 o'clock, 1.5π = 12 o'clock"
# "Clockwise sweep = 0 → 0.5π → π → 1.5π → 2π"
# "For ∪, sweep through 12 o'clock: 0.5π → 1.5π"
pygame.draw.arc(window, color, rect, 0.5*math.pi, 1.5*math.pi, 5)
```

**This draws a circle (full half), not ∪.** When the bbox is small enough that the arc gets clipped, it looks like S-curve, not a smile.

### What actually happens (vision-verified)

pygame.arc with rect `R` and angles `a1 < a2` draws the segment of the ellipse inscribed in `R` going counter-clockwise from `a1` to `a2`. The key insight (verified with vision on rendered test PNGs):

| Angle range | Where the arc lands in the rect |
|---|---|
| **0 ~ π** | TOP of rect (above center, like ∩) |
| **π ~ 2π** | BOTTOM of rect (below center, like ∪) |
| **0.5π → 1.5π** | Full circle (180° sweep, both endpoints at left) |
| **0.25π → 0.75π** | BOTTOM half (∪ shape, smile) |
| **0 → 2π** | Full circle |

So to draw a smile (∪) — the part of the ellipse below the center — use **0.25π → 0.75π** (not what intuition suggests).

To draw a frown (∩) — the part above the center — use **0 → π**.

### The reliable recipe

| Want | Use |
|---|---|
| Smile ∪ (mouth turns up) | `0.25π → 0.75π` |
| Frown ∩ (mouth turns down) | `0 → π` |
| Half-circle (left/right side) | `0.5π → 1.5π` |
| Full circle | `0 → 2π` |

And **always test with `SDL_VIDEODRIVER=dummy` + `pygame.image.save` + vision verification** when an arc should be a specific shape. Don't trust the math from memory.

### Vision-debug the arc

```python
import os
os.environ['SDL_VIDEODRIVER'] = 'dummy'
import pygame, math
pygame.init()
screen = pygame.display.set_mode((600, 400))
screen.fill((255, 255, 255))

# Draw 6 test arcs with different angle combos
for i, (start, end, label) in enumerate([
    (0, math.pi, "0→π"),
    (0.5*math.pi, 1.5*math.pi, "0.5π→1.5π"),
    (0.25*math.pi, 0.75*math.pi, "0.25π→0.75π"),
    (0, 0.5*math.pi, "0→0.5π"),
    (math.pi, 2*math.pi, "π→2π"),
    (0.15*math.pi, 0.85*math.pi, "0.15π→0.85π"),
]):
    x, y = 50 + (i % 3) * 200, 50 + (i // 3) * 200
    pygame.draw.rect(screen, (200, 200, 200), (x, y, 150, 150), 1)
    pygame.draw.arc(screen, (255, 0, 0), (x, y, 150, 150), start, end, 3)
    font = pygame.font.Font(None, 20)
    screen.blit(font.render(label, True, (0,0,0)), (x, y + 155))

pygame.image.save(screen, "arc_test.png")
# Read arc_test.png with vision and label each as "∪" or "∩"
```

Then ask vision: "for each red arc, is the curve convex-up (∪) or convex-down (∩)?" The map is what you actually want, not what pygame's docs suggest.

---

## 4. The "PNG preview for visual verification" workflow

When the deliverable is a visual change (face redesign, layout tweak, color shift), you can't trust your own code or your own vision tool to validate. The user is the only ground truth.

### The pattern

1. **Write a small `save_previews.py` script** that loops over the parameter space (emotion, state) and saves a PNG per combination.
2. **Run it with `SDL_VIDEODRIVER=dummy`** — no need for an actual display.
3. **Open the folder in Finder** (`open ~/projects/.../preview`) and let the user click through.
4. **Iterate on the worst offenders only** — don't try to perfect all 5 at once; ask the user which one is most wrong and fix that.

### Why this beats "let me just look at the rendered output and tell you"

- Vision tool confusion: in the same session, vision called `0.15π → 0.85π` first "∪" then "∩" then "∪" depending on the surrounding context. The user is the only consistent oracle.
- Subpixel rendering / anti-aliasing choices: pygame by default doesn't anti-alias arcs. What looks "almost right" in the code may render visibly jagged.
- Multiple emotions are coupled: changing happy's mouth curve changes sad's perception too. The user can spot if "happy looks too much like sad" — code-only reviewers can't.

### Code template

```python
# save_previews.py
import os, sys
os.environ['SDL_VIDEODRIVER'] = 'dummy'
sys.path.insert(0, '/Users/hjshin/projects/your-companion')

import pygame
import face  # your module

OUT = os.path.expanduser('~/projects/your-companion/preview')
os.makedirs(OUT, exist_ok=True)

f = face.KiwiFace()
f.init_pygame()

for emotion in ['happy', 'sad', 'thinking', 'surprised', 'neutral']:
    f.set_emotion(emotion)
    f.set_speaking(False)
    f._update(0)
    f._draw()
    pygame.display.flip()
    pygame.image.save(f._window, f'{OUT}/face_{emotion}.png')
    print(f'✓ {emotion}')

f.shutdown()
```

Then: `open ~/projects/your-companion/preview` — user clicks each PNG and tells you what's wrong.

---

## 5. Summary — what v2 added over v1

| v1 (after first session) | v2 (after this session) |
|---|---|
| Crashed in pygame.init (NSWindow) | Crashed in pygame.time.Clock (SDLTimer race) — third crash class |
| 1 generic green circle face | Brown kiwi body with seeds + 5 distinct emotion styles (eye shape + mouth shape) |
| Random "if emotion == X" branches | EMOTION_PALETTE dict as single source of truth |
| "Trust vision to verify" | "Trust user to verify" via PNG preview workflow |
| Arc angles guessed | Arc angles vision-verified via test PNG grid |

If you're starting a new companion from scratch, **copy v2's face.py structure** (EMOTION_PALETTE + eye_style/mouth_style + headless preview script) rather than v1.
