# macOS TTS Voice Selection

How to find, prioritize, and select Korean voices on macOS for pyttsx3-based TTS. Includes the Yuna vs Eddy tradeoff and fallback to the `say` command.

## Voice landscape (macOS 15.5)

177 total voices. Korean options:

| Voice ID | Name | Quality | Notes |
|---|---|---|---|
| `com.apple.voice.compact.ko-KR.Yuna` | Yuna | ⭐⭐⭐⭐⭐ | Best choice, natural female |
| `com.apple.eloquence.ko-KR.Eddy` | Eddy (Korean) | ⭐⭐ | Male, robotic Eloquence synth |
| `com.apple.eloquence.ko-KR.Flo` | Flo (Korean) | ⭐⭐ | Female Eloquence, similar to Yuna but more robotic |
| `com.apple.eloquence.ko-KR.Grandma` | Grandma (Korean) | ⭐⭐ | Older female Eloquence |
| `com.apple.eloquence.ko-KR.Grandpa` | Grandpa (Korean) | ⭐⭐ | Older male Eloquence |
| `com.apple.eloquence.ko-KR.Reed` | Reed (Korean) | ⭐⭐ | Male Eloquence |
| `com.apple.eloquence.ko-KR.Rocko` | Rocko (Korean) | ⭐⭐ | Male Eloquence |
| `com.apple.eloquence.ko-KR.Sandy` | Sandy (Korean) | ⭐⭐ | Female Eloquence |
| `com.apple.eloquence.ko-KR.Shelley` | Shelley (Korean) | ⭐⭐ | Female Eloquence |

**Kyung and Sora** are mentioned in some online docs but not present on current macOS. Yuna is the only high-quality compact Korean voice.

## Inspection command

```bash
python3 -c "
import pyttsx3
e = pyttsx3.init()
voices = e.getProperty('voices')
ko = [v for v in voices if any('ko' in str(l).lower() for l in getattr(v, 'languages', []))]
for v in ko:
    print(f'{v.name:20s} {v.id}')
"
```

Output:
```
Yuna                  com.apple.voice.compact.ko-KR.Yuna
Eddy (Korean (South Korea))  com.apple.eloquence.ko-KR.Eddy
Flo (Korean (South Korea))  com.apple.eloquence.ko-KR.Flo
...
```

## Selection algorithm

**Priority:** Yuna (best) → Kyung (if available) → any other Korean by language attr.

```python
_KOREAN_PREFERENCE_KEYS = ("yuna", "kyung", "ko-kr.yuna", "ko_kr.yuna", "korean")

def _find_korean_voice(engine):
    for keyword in _KOREAN_PREFERENCE_KEYS:
        for v in engine.getProperty("voices"):
            name = (getattr(v, "name", "") or "").lower()
            vid = (getattr(v, "id", "") or "").lower()
            if keyword == "yuna":
                # Yuna exact match — avoid matching other Korean voices
                if name == "yuna" or vid.endswith(".yuna") or "ko-kr.yuna" in vid:
                    return v
            elif keyword in name or keyword in vid:
                return v
    # Final fallback: any voice with Korean in languages
    for v in engine.getProperty("voices"):
        for lang in getattr(v, "languages", []) or []:
            if "ko" in str(lang).lower():
                return v
    return None
```

## The substring matching pitfall

The naive approach:

```python
# ❌ BUGGY
for v in voices:
    if "yuna" in v.id.lower():
        return v  # may return Eddy or other voices that appear first
```

The first voice in the list whose id contains "yuna" wins. On macOS 15.5, Eddy appears **before** Yuna in the default iteration order, and "ko-kr" in the regex pattern `ko_kr.yuna` will match Eddy's id because both contain "ko-kr" or "ko_kr".

The fix: **exact match** (not substring) or **endswith**:

```python
# ✓ CORRECT
if name == "yuna" or vid.endswith(".yuna"):
    return v
```

The exact-match approach is robust to voice ordering changes across macOS versions.

## Thread-safety

pyttsx3's engine is **not thread-safe**. Concurrent `say()` calls from different threads corrupt the audio queue (you get garbled output or silent failure).

```python
import threading

class KiwiSpeaker:
    def __init__(self):
        self._lock = threading.Lock()
        self.engine = pyttsx3.init()
        # ...

    def say(self, text, blocking=False):
        with self._lock:
            self.engine.say(text)
            if blocking:
                self.engine.runAndWait()
            else:
                threading.Thread(
                    target=self._run_and_wait_safe, daemon=True
                ).start()

    def _run_and_wait_safe(self):
        with self._lock:
            self.engine.runAndWait()
```

The lock around `runAndWait` is non-obvious but necessary — `runAndWait` blocks until the queue is drained, and another thread's `say` could enqueue mid-drain.

## Fallback to `say` command

If pyttsx3 fails (e.g., audio device unavailable, headless SSH session), fall back to the macOS `say` binary:

```python
import subprocess

def _say_fallback(self, text, blocking):
    cmd = ["say", "-v", "Yuna", text]  # explicit Korean voice
    if blocking:
        subprocess.run(cmd, check=True, timeout=60)
    else:
        subprocess.Popen(cmd)  # fire-and-forget
```

`say` doesn't need a `threading.Lock` because each invocation is a separate process.

## Why Yuna sounds better than Eloquence Korean

- **Yuna (compact):** recorded human voice, then compressed → natural prosody, slight reverb, recognizable as "person"
- **Eloquence family:** parametric synthesis from rules → flat intonation, no breath, robotic
- For TTS that gets spoken for 5-30 seconds at a time (companion sim use case), Yuna is dramatically less fatiguing

If you must use Eloquence (e.g., Yuna is unavailable on an older macOS), Flo is the least-robotic of the Eloquence Korean variants.

## Adding more voices

macOS System Settings → Accessibility → Spoken Content → System voice → Customize... lets you download additional Korean voices if any become available. As of 2026, Yuna is the only compact Korean option; Eloquence is built-in.

## Init order with pygame

**On macOS, init pygame BEFORE pyttsx3.** pygame's `pygame.init()` initializes SDL which may grab the audio device; if pyttsx3 tries to init first, you can get `OSError` on some macOS versions.

```python
# ✓ CORRECT
pygame.init()
pygame.display.set_mode(...)
# ... face thread ready ...
speaker = KiwiSpeaker()  # pyttsx3 init after pygame

# ❌ RISKY
speaker = KiwiSpeaker()  # may grab audio device
pygame.init()  # may fail to grab the same device
```

In our actual build we got lucky and the reverse order worked, but the canonical pattern is pygame-first.
