# Notion API 함정 6가지 (실측 2026-07-09 + ICBM2 누적)

sink = Notion인 모든 파이프라인에서 반드시 숙지. `notion` 스킬 본체에는 이미 있지만, **periodic-data-pipeline 관점에서 워커 코드를 짤 때 자주 빠지는 부분**을 보강.

## 🚨 함정 0 (P0): 토큰 노출 사고 (2026-07-09 실측)

**상황**: 사용자가 Notion integration token (`ntn_319...`) 을 텔레그램으로 평문 전송. 채팅 로그에 영구 저장됨. 즉시 회전(rotate) 후 새 토큰은 직접 파일 저장 패턴으로 변경.

**원칙**:

1. **절대 어떤 메신저/채팅에도 API 토큰·비밀키 평문 전송 금지**. 텔레그램·디스코드·슬랙·이메일·GitHub 이슈·Notion 코멘트·어디든.
2. **저장 패턴**: `echo "ntn_..." > ~/.hermes/secrets/<name>.txt && chmod 600 <name>.txt` 만 허용.
3. **사용자가 토큰 보내면 즉시 차단 + 회전 안내**:
   - 회전: integration 설정 페이지 → "Delete integration" 또는 "Rotate key" → 즉시 무효화
   - 새 토큰: 사용자가 직접 파일에 저장 → 저쪽에서 "회전 완료" 한마디만 받기
4. **load_notion_token()은 mode 600 검증 필수** (워크커 첫 import 시점에 fail-loud):

```python
def load_notion_token(token_file: Path) -> str:
    if not token_file.exists():
        raise FileNotFoundError(...)
    mode = oct(token_file.stat().st_mode & 0o777)
    if mode != "0o600":
        raise PermissionError(f"토큰 파일 권한 {mode} (0o600 이어야 함). chmod 600 {token_file}")
    token = token_file.read_text().strip()
    if not token.startswith(("ntn_", "secret_")):
        raise ValueError(f"토큰 형식 이상: {token[:10]}...")
    return token
```

5. **A "successful" setup that involves a token appearing in chat is a security regression**, not progress. 챗봇이 멈춰도 OK, 토큰 노출되면 작업 중단.

**회전 레시피 (3분)**:
1. notion.so/profile/integrations → 기존 integration → Delete
2. + New integration → 새 토큰
3. `echo "ntn_NEW" > ~/.hermes/secrets/<project>.txt && chmod 600 ~/.hermes/secrets/<project>.txt`
4. "회전 완료" 받기 → 진행

## 🚨 함정 0b (P0): parse_page_id URL Trailing Anchor 버그 (2026-07-09 실측)

Notion URL에서 32자 hex page_id 추출 시, naive regex가 URL 끝이 아닌 **임의 위치의 32자 substring**을 매칭. URL 전체 길이가 길수록 발동 확률 ↑ (제목 slug + 한글 URL에서 빈번).

**실패 케이스**:
```python
url = "https://www.notion.so/카톡-아카이브/KakaoTalk-Timeline-36976f2e909781e1bb34000b13fb3627"
# ❌ BAD: 32자 hex를 URL 전체에서 매칭
m = re.search(r"([a-f0-9]{32})", url.replace("-", ""))
# → "e36976f2e909781e1bb3400b13fb362" (잘못된 위치)

# ✅ GOOD: URL 끝에 anchor
cleaned = url.replace("-", "")
m = re.search(r"([a-f0-9]{32})\s*$", cleaned)
# → "36976f2e909781e1bb34000b13fb3627" (정확)
```

또는 **하이픈 포함 형식 (8-4-4-4-12) passthrough**:
```python
m2 = re.match(r"^([a-f0-9]{8})-([a-f0-9]{4})-([a-f0-9]{4})-([a-f0-9]{4})-([a-f0-9]{12})$", url_or_id)
```

→ 두 패턴 합치면 bare ID / dashed ID / full URL 모두 처리. **DB 생성 endpoint는 page_id가 정확해야 하므로 첫 호출에서부터 trailing anchor 필수**.

## 함정 1: API 버전 — DB 생성 vs 페이지 생성

```text
DB 생성:  POST /v1/databases   Notion-Version: 2022-06-28
페이지 생성: POST /v1/pages    Notion-Version: 2025-09-03
쿼리:      POST /v1/data_sources/{id}/query   Notion-Version: 2025-09-03
```

- **2025-09-03으로 DB 생성 시도** → `"Creating new databases with data sources is not supported in this endpoint for API version 2025-09-03"`
- **2022-06-28으로 페이지 생성 시도** → 2025-09-03의 data_sources 패러다임과 호환 안 됨
- → **워크커에서 2개 버전 헤더를 다 발사**해야 함. 단일 헤더로 통합 안 됨.

## 함정 2: 이중 ID

```json
{
  "id": "36976f2e-9097-81e1-bb34-000b13fb3627",      // data_source_id — 쿼리 전용
  "parent": {
    "database_id": "36976f2e-9097-81e1-a373-e06f2da6e99c"  // 진짜 database_id — 페이지 생성
  }
}
```

| 작업 | endpoint | ID |
|---|---|---|
| row 쿼리 | `POST /v1/data_sources/{id}/query` | `data_source_id` (응답의 `id` 필드) |
| 페이지 생성 | `POST /v1/pages` `parent.database_id` | `parent.database_id` |
| DB 인트로스펙션 | `GET /v1/databases/{id}` | 둘 다 사용 가능 |

**증상**: 잘못된 ID로 페이지 생성 → `404 object_not_found`.

## 함정 3: 한국어 property name

ICBM2 기존 DB는 한국어 property name 사용 (`이름`, `날짜`, `상태`, `단톡방`, `시간대`, `메시지 수`, `활성 사용자 수`, `토픽 수`). Notion API 문서는 영어 예제 (`Name`, `Date`, `Status`)를 쓰는데, **한국어 DB에 영어 name 보내면 `400 validation_error`**.

**해결**: DB 첫 push 전에 반드시 introspect:

```bash
curl -s "https://api.notion.com/v1/databases/{DATABASE_ID}" \
  -H "Authorization: Bearer $NOTION_API_KEY" \
  -H "Notion-Version: 2022-06-28" | \
  jq '.properties | to_entries[] | "\(.key): \(.value.type)"'
```

→ `notion` 스킬 `references/db-schema-introspection.md`에 Python 예제 있음.

## 함정 4: row 표시 순서 = 생성 순서

Notion은 row를 **created_at 오름차순**으로 표시. API의 `sorts` 파라미터로 정렬은 가능하지만, **기본 보기에서 정렬 안 하면 생성 순서대로 보임**.

**문제**: 시간순으로 push하면 가장 최근 row가 맨 아래 → 사용자가 "맨 위 보고 싶은데 왜 옛날 거부터?" 혼란.

**해결**: 시간 오름차순으로 정렬된 데이터라면, **역순으로 push** (가장 마지막 row를 먼저 생성, 가장 오래된 row를 마지막에 생성). 그러면 Notion 기본 보기 = 시간 오름차순 ✅.

## 워커에서 자주 빠지는 5가지 (이 클래스 한정)

1. **429 rate limit** — Notion API는 분당 ~3 req/s. 1000 row push하면 5분 걸림. **push 사이에 sleep(0.4) 필수**.
2. **빈 데이터 처리** — 단톡방에 메시지 0건일 때 row를 push할지 말지 결정. push하면 노이즈, 안 하면 "왜 누락?" 고민. → **"0건이어도 row는 push하되 본문은 'No activity in this window'로"** 권장.
3. **DB의 Select 옵션 자동 추가** — `select` 타입은 새 옵션을 push할 때 자동 추가되지만, **`multi_select`는 자동 추가 안 됨** → 미리 모든 옵션을 DB 생성 시 정의해두거나 첫 push 시 한 번 옵션 만들어두기.
4. **token 절대 메시지로 발송 금지** — 사용자에게 `echo "..." > ~/.hermes/secrets/... && chmod 600` 안내. 텔레그램/슬랙 로그에 토큰 남으면 사고.
5. **DB title은 `title` 타입 property여야** — 첫 번째 property는 무조건 title이어야 UI에서 row가 보임. 다른 property 먼저 만들면 Notion이 자동 title 만들지만 property 이름이 "Name"이 됨 → 한국어 DB에서는 "이름"으로 rename 필요.

## 실측 워커 코드 골격 (이 클래스 표준)

```python
# pipeline/push.py
import os, time, json, urllib.request

NOTION_KEY = open(os.path.expanduser("~/.hermes/secrets/notion_token_kakao.txt")).read().strip()
HEADERS_PAGE = {
    "Authorization": f"Bearer {NOTION_KEY}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}
HEADERS_DB = {**HEADERS_PAGE, "Notion-Version": "2022-06-28"}

def push_row(database_id: str, props: dict, body_blocks: list):
    """DB row 1개 push. 429 자동 재시도."""
    payload = {
        "parent": {"database_id": database_id},
        "properties": props,
        "children": body_blocks,
    }
    tmp = "/tmp/notion_push_payload.json"
    with open(tmp, "w") as f:
        json.dump(payload, f, ensure_ascii=False)
    
    for attempt in range(3):
        req = urllib.request.Request(
            "https://api.notion.com/v1/pages",
            data=open(tmp, "rb").read(),
            headers=HEADERS_PAGE,
            method="POST",
        )
        try:
            with urllib.request.urlopen(req) as resp:
                return json.loads(resp.read())
        except urllib.error.HTTPError as e:
            if e.code == 429:
                time.sleep(2 ** attempt)
                continue
            raise
```

→ inline JSON ❌, temp file ✅ (heredoc shell escape 함정 회피).
