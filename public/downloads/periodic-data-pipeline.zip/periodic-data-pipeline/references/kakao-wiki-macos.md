# kakao-wiki macOS Provider 실측 가이드

source = 카카오톡 단톡방 (kakao-wiki) 일 때의 설치/권한/실측 함정. 2026-07-09 kakao-timeline 파이프라인에서 검증.

## 설치

### 의존성

```bash
# brew (macOS Apple Silicon)
which brew && brew --version | head -1

# PyYAML (kakao-wiki는 표준 라이브러리만, 하지만 rooms.yaml 로드용)
pip3 install --user pyyaml
```

### kakao-wiki 받기

```bash
# git clone (brew tap보다 단순, 1줄)
cd ~/work && git clone https://github.com/treylom/kakao-wiki.git

# 또는 brew
brew tap NomaDamas/katok https://github.com/NomaDamas/katok.git
brew install kakaocli  # kakao-wiki 의존성 중 하나
```

### kakao-wiki 단독 실행 (참고용)

```bash
cd ~/work/kakao-wiki
python3 scripts/collect.py --room "정확한_카톡_방이름" --provider macos --out ./out
# → out/<방이름>-<날짜>.raw.csv + out/<방이름>-<날짜>.normalized.json
```

## 권한 — 2가지 모두 필요

### 1. Full Disk Access (TCC)

`~/Library/Containers/com.kakao.KakaoTalkMac/` 아래 파일을 읽기 위해.

1. 시스템 설정 → 개인정보 보호 및 보안 → **Full Disk Access**
2. 사용 중인 터미널 (Terminal.app 또는 iTerm) 추가
3. **kakao-wiki 실행 파일도** 추가 (`/opt/homebrew/bin/kmsg` 등)

### 2. 손쉬운 사용 (Accessibility)

macos provider는 osascript로 카톡 GUI를 클릭하므로, 터미널에 **손쉬운 사용** 권한도 필요.

1. 시스템 설정 → 개인정보 보호 및 보안 → **손쉬운 사용**
2. Terminal.app 체크

## 🚨 P0: 카톡 앱이 반드시 켜져 있어야 함

macos provider는 **osascript로 사람이 클릭하는 순서**를 재현:
- 앱 포커스 → 채팅 탭 → 방 열기
- 설정 → 대화 내용 관리 → "텍스트 파일로 저장"

→ 카톡 앱이 안 떠있거나, 방이 안 열려있으면 **자동화 실패**. launchd 워커는 백그라운드에서 GUI 앱 launch 시도하지만 sandboxing으로 실패할 수 있음.

**해결**: **카톡 앱 항상 켜놓기 정책**이 가장 안정. macmini가 24/7 켜져있다는 전제.

## 🚨 P0: 익명 export 만료 주기 단축 (07-06 memory)

2026년 초 3개월+ → 2026-07 기준 **4일**로 단축. 원인 = ①Tistory 정책 강화 또는 ④Chrome 원격데몬 종료 (카톡도 비슷한 영향 추정).

**대응**:
- `kakaocli` 기반 DB provider는 `🧪 실험적` — 호스트에서 키 유도 성공해야 동작
- macos provider가 막히면 워커는 `🟡 부분` 상태로 row push (자동화는 죽지 않음)
- 다음 세션 만료 발견 시: 5-A cron 알림 → 수동 `python3 scripts/collect.py ... --provider macos` 1회 실행 → 이후 자동화 self-heal

## 🚨 P1: 카톡 단일 세션 제약

**카카오톡은 한 계정이 한 기기에서만 로그인됨**. macos provider가 카톡을 launch해서 로그인하는 순간, 다른 기기(폰)의 카톡 세션이 끊김.

**대응**:
- 워커는 **수집이 도는 동안만** 카톡 세션 점유
- 안 돌 땐 다른 기기로 자유롭게 사용
- → Windows/헤드리스 환경의 무인 자동화는 ❌. macOS GUI 환경 한정.

## P1: 셀렉터 의존 (UI 변경에 취약)

osascript가 카톡 UI의 **버튼 인덱스 + 메뉴 텍스트**에 의존. 카카오톡 앱 업데이트 시 셀렉터 다시 잡아야 함. 다행히 kakao-wiki는 **방 검증 2단계**로 잘못된 방을 조용히 수집하지 않고 fail-fast:

1. GUI 방 검증 — 내보내기 전 방 창 존재 확인
2. CSV 방 검증 — 나온 CSV가 정말 대상 방 것인지 확인 (한글 NFC substring), 아니면 즉시 실패

## P1: 동시에 2개 이상 워커 실행 ❌

`/tmp/kakao-gui.lock` mutex로 동시 실행 직렬화. 워커 2개가 동시에 collect 호출하면 한쪽은 30초+ 대기.

**해결**: collect.py 시작 시 `FileLock` 적용 (이미 구현됨 in kakao-timeline).

## P1: normalized.json 스키마 (2026-07-09 실측)

kakao-wiki의 정규화 출력 (`*normalized.json`) 스키마 — **실측으로 검증된 진짜 구조**:

```json
{
  "schema_version": "1",
  "proof_class": "in-process",
  "source": "/Users/mac/work/kakao-timeline/archive/tmp/codefactory/코드팩토리-2026-07-09.raw.csv",
  "count": 428,
  "unique_users": 60,
  "filtered_bot_announcement": 23,
  "first_time": "",
  "last_time": "2026-07-09 11:28:26",
  "messages": [
    {
      "time": "2026-07-09 07:08:06",
      "user": "아라방구 / 클로드코드",
      "msg": "빅테크 실적이 사상 최고치를..."
    },
    {
      "time": "",
      "user": "",
      "msg": "메시지가 삭제되었습니다."
    }
  ]
}
```

**핵심 주의사항 (2026-07-09 실측, summarize.py 첫 실행 함정)**:
- 메시지 dict 키는 **`time` / `user` / `msg`**. 흔한 착각은 `timestamp` / `user_name` / `content` — 이 가정으로 작성하면 user/content/timestamp 키가 없어서 0명/0건 결과.
- **삭제된 메시지**: `time` / `user` 모두 빈 문자열, `msg` = "메시지가 삭제되었습니다." (filtered_bot_announcement, 보통 ~20건).
- **count vs unique_users**: 428건 중 23건이 filtered_bot_announcement. messages 배열 길이는 count와 같음 (정확).
- **first_time 비어있을 수 있음**: macos provider의 한계. `last_time`은 비교적 정확.
- **워크스페이스 형식**: `아라방구 / 클로드코드`처럼 "닉네임 / 워크스페이스" 패턴. 같은 사람도 워크스페이스 다르면 다르게 표시 → hash가 다르게 나옴 → active_user_count 약간 과대 가능 (성능 영향 미미).

**워커 코드 helper (반드시 키 호환성 보장)**:

```python
def extract_msg(m: dict) -> str:
    return m.get("msg") or m.get("content") or m.get("message") or ""

def extract_user(m: dict) -> str:
    return m.get("user") or m.get("user_name") or m.get("sender") or ""

def extract_time(m: dict) -> str:
    return m.get("time") or m.get("timestamp") or m.get("sent_at") or ""
```

→ **첫 실행 시 한 번** 키 확인:
```bash
python3 -c "import json; d=json.load(open(p)); print(list(d.keys())); print(list(d['messages'][0].keys()))"
```

**버그 1줄 시그니처**: 0명/0건 결과 + `time/user/msg`로 안 바뀌었으면 → `user_name/content` 가정. 위 helper로 수정.

## 카톡 raw 7일 TTL 후 삭제

kakao-timeline의 `cleanup.py`는 7일 지난 raw 폴더를 자동 삭제:
```python
ARCHIVE_DIR / "raw" / "YYYY-MM-DD" / "<room_id>"  # 이 구조
```

sink = Notion에는 **요약만** push하므로 raw는 macmini 디스크에만 존재 → 7일 후 자동 삭제.

## 통합 워커 (kakao-timeline 구조 예시)

```
~/work/kakao-timeline/
├── config/
│   ├── rooms.yaml          # 동적 방 목록 (id, kakao_room, notion_property_team, active)
│   ├── notion.yaml         # token_file, page_id, database_id, data_source_id
│   └── pipeline.yaml       # windows(4-슬롯), raw_retention_days, llm.provider
├── pipeline/
│   ├── common.py           # load_notion_token (mode 600 검증), logger, FileLock, hash_user_id
│   ├── collect.py          # kakao-wiki 래퍼 + 6h 슬라이스
│   ├── summarize.py        # 2-tier LLM 요약 + PII 마스킹
│   ├── notion_upload.py    # DB 자동 생성 + row push
│   ├── cleanup.py          # 7일 TTL
├── logs/                   # 일별 log 파일
├── archive/raw/            # TTL 7일
└── run.sh                  # cron entrypoint
```

권한: `chmod 700 ~/work/kakao-timeline/pipeline/*.py ~/work/kakao-timeline/run.sh` (다른 사용자 실행 X).

## launchd plist 예시 (kakao-timeline 4-슬롯)

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>com.user.kakao-timeline</string>
  <key>ProgramArguments</key>
  <array>
    <string>/bin/bash</string>
    <string>-c</string>
    <string>cd /Users/mac/work/kakao-timeline && TZ=KST-9 ./run.sh 2>&1 | tee -a logs/launchd-stdout.log</string>
  </array>
  <key>StartCalendarInterval</key>
  <array>
    <dict><key>Hour</key><integer>0</integer><key>Minute</key><integer>5</integer></dict>
    <dict><key>Hour</key><integer>6</integer><key>Minute</key><integer>5</integer></dict>
    <dict><key>Hour</key><integer>12</integer><key>Minute</key><integer>5</integer></dict>
    <dict><key>Hour</key><integer>18</integer><key>Minute</key><integer>5</integer></dict>
  </array>
  <key>StandardOutPath</key>
  <string>/Users/mac/work/kakao-timeline/logs/launchd-stdout.log</string>
  <key>StandardErrorPath</key>
  <string>/Users/mac/work/kakao-timeline/logs/launchd-stderr.log</string>
  <key>RunAtLoad</key>
  <false/>
</dict>
</plist>
```

```bash
launchctl load ~/Library/LaunchAgents/com.user.kakao-timeline.plist
# 진단
launchctl list | grep kakao-timeline
# 수동 실행 (디버깅)
launchctl start com.user.kakao-timeline
# 제거
launchctl unload ~/Library/LaunchAgents/com.user.kakao-timeline.plist
```

## 진단 체크리스트 (카톡 워커 안 돌 때)

- [ ] 카톡 앱이 켜져 있는가 (`ps aux | grep -i kakaotalk`)
- [ ] 카톡 앱에 해당 단톡방이 열려 있는가 (osascript가 클릭할 대상 필요)
- [ ] 카톡 앱의 방 이름이 `rooms.yaml`의 `kakao_room`과 **정확히** 일치하는가 (이모지/공백/워크스페이스 prefix 차이 주의)
- [ ] Terminal.app이 Full Disk Access + 손쉬운 사용 둘 다 받았는가
- [ ] kakao-wiki 의존성 (`pip3 install --user pyyaml`, `kmsg` 등) OK인가
- [ ] `kakaocli` 키가 호스트에 유도되어 있는가 (DB provider 쓸 때)
- [ ] launchd 절전 깨우기 옵션 ON (시스템 설정 → 에너지 → "네트워크 액세스 시 깨우기")
- [ ] 워커 stdout/stderr 로그 (`logs/launchd-stderr.log`) 에 무엇이라 적혀 있는가
- [ ] Notion API 4대 함정 (버전/이중 ID/한국어 property/parse_page_id trailing) 통과
- [ ] **summarize.py 키 호환성** (`time/user/msg` 폴백 helper) — 0명/0건 결과면 1순위로 의심
