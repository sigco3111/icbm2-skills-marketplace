# katok macOS 실측 가이드 (kakao-wiki 대안, 2026-07-09)

source = 카카오톡 단톡방 데이터 소스로 **NomaDamas/katok** 을 쓰는 경우. kakao-wiki가 fragile할 때 (특히 kmsg 미설치 + GUI 부작용) 안정적 대안.

## 왜 katok인가 — kakao-wiki 비교

| | **kakao-wiki** | **katok** |
|---|---|---|
| 데이터 소스 | 카톡 GUI "텍스트 파일로 저장" 메뉴 자동 클릭 | `~/Library/Containers/com.kakao.KakaoTalkMac/` SQLCipher DB 직접 읽기 |
| 의존성 | `kmsg` CLI (설치 어려움) + brew tap NomaDamas + pyyaml | `cargo` (brew install katok) |
| **GUI 자동화** | ✅ 카톡 창/메뉴 클릭 (osascript) | ❌ DB 직접 읽기 → **카톡 UI 안 건드림** |
| 안정성 | fragile — UI 상태 의존, 사용자 방 닫힘 가능 | 안정 — Rust + SQLite |
| macOS 권한 | Full Disk Access + 손쉬운 사용 2개 | **Full Disk Access 1개** |
| Apple Silicon | ✅ | ✅ (Intel ❌) |
| 검색 기능 | 없음 (수집만) | BM25 + EmbeddingGemma vector + keyword |
| archive 형식 | `*.normalized.json` (CSV→JSON) | `archive.sqlite3` (SQLite DB) |
| 메시지 키 | `time` / `user` / `msg` | `timestamp` / `sender_nickname` / `text` |
| 데이터 디렉토리 | kakao-wiki repo 안 out/ | `~/Library/Application Support/katok/archive.sqlite3` |
| 익명 export 만료 | 4일 (07-06 memory) | 영향 적음 (DB 직접 읽기라 export 안 씀) |

**결론**: 카톡 창을 닫지 않고 싶고, 안정성이 우선이면 **katok**이 정답. 수집 → LLM 요약 → Notion push 구조는 동일.

## 설치 (5~6분 — Rust 컴파일)

```bash
# brew tap
brew tap NomaDamas/katok https://github.com/NomaDamas/katok.git
brew trust nomadamas/katok  # "untrusted tap" 에러 시 한 번만
brew install katok
# → 4~5분 소요 (cargo가 Rust 소스 컴파일)
```

설치 후:
```bash
which katok
# /opt/homebrew/bin/katok

# macOS TCC 권한 자동 안내 (시스템 설정 열기)
katok permissions macos
# → 시스템 설정 > 개인정보 보호 및 보안 > 전체 디스크 접근 패널이 열림
# → Terminal.app 추가 + 체크

# 진단 (permission prompt 없이)
katok doctor --json
```

## 핵심 명령 5개

```bash
# 1. DB → archive.sqlite3 (전체 메시지 동기화)
katok sync --source macos --json

# 2. vector index 구축 (semantic 검색용, 1회만)
katok index --json

# 3. 검색 (3가지)
katok search keyword "010-1234-5678" --json
katok search bm25 "세금 신고 일정" --json
katok search semantic "지난 회의에서 논의된 일정" --json

# 4. chunk 조회
katok chunk get <chunk-id> --json
katok chunk context <chunk-id> --json   # 인접 chunk
katok chunk parent <chunk-id> --json   # 5분 parent window
```

## archive.sqlite3 스키마 (실측, 2026-07-09)

```sql
CREATE TABLE messages (
    account_hash TEXT NOT NULL,
    chat_id TEXT NOT NULL,
    chat_name TEXT NOT NULL,
    chat_type TEXT NOT NULL,
    message_id TEXT NOT NULL,
    sender_id TEXT NOT NULL,
    sender_nickname TEXT NOT NULL,
    timestamp TEXT NOT NULL,
    text TEXT NOT NULL,
    message_type TEXT NOT NULL,
    reply_to_message_id TEXT,
    PRIMARY KEY(account_hash, chat_id, message_id)
);
```

`SELECT DISTINCT chat_id, chat_name FROM messages` 로 모든 방 목록 + chat_id 확인 가능.

## 파이프라인 통합 패턴 (kakao-timeline 실측)

`katok sync` 의 출력은 JSON envelope이지만 **archive.sqlite3 파일**이 진짜 결과물. 워커는 이 sqlite를 직접 SELECT:

```python
# pipeline/katok_collect.py (핵심 부분)
import sqlite3
from pathlib import Path

ARCHIVE = Path.home() / "Library/Application Support/katok/archive.sqlite3"

def read_archive_messages(archive_path: Path) -> list[dict]:
    conn = sqlite3.connect(str(archive_path))
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute("""
        SELECT chat_id, chat_name, chat_type,
               message_id, sender_id, sender_nickname,
               timestamp, text, message_type
        FROM messages
        ORDER BY timestamp
    """)
    out = []
    for r in cur.fetchall():
        d = dict(r)
        # 우리 summarize.py 스키마에 맞춤 (user, time, msg)
        out.append({
            "time": d["timestamp"],
            "user": d["sender_nickname"],
            "msg": d["text"],
            "chat_id": d["chat_id"],
            "chat_name": d["chat_name"],
        })
    conn.close()
    return out

def filter_window(messages, since: str, until: str):
    """6h 슬라이스. kakao-wiki와 동일 패턴."""
    from datetime import datetime, timezone, timedelta
    KST = timezone(timedelta(hours=9))
    since_dt = datetime.strptime(since, "%Y-%m-%d %H:%M:%S").replace(tzinfo=KST)
    until_dt = datetime.strptime(until, "%Y-%m-%d %H:%M:%S").replace(tzinfo=KST)
    out = []
    for m in messages:
        try:
            msg_dt = datetime.strptime(m["time"][:19], "%Y-%m-%d %H:%M:%S").replace(tzinfo=KST)
        except (ValueError, TypeError):
            continue
        if since_dt <= msg_dt < until_dt:
            out.append(m)
    return out
```

## rooms.yaml 보강 (chat_id 추가)

```yaml
rooms:
  - id: hermes
    kakao_room: "에르메스단"      # 사람용 표시
    chat_id: ""                  # katok sync 후 채움 (sqlite SELECT 결과)
    notion_property_team: "에르메스단"
    active: true
```

`chat_id` 가 비어있으면 `chat_name == kakao_room` 폴백 매칭. 있으면 정확.

```bash
# chat_id 확인
sqlite3 ~/Library/Application\ Support/katok/archive.sqlite3 \
  "SELECT chat_id, chat_name FROM messages GROUP BY chat_id"
```

## ⚠️ kakao-wiki의 두 가지 큰 약점 (katok으로 해결)

### 약점 1: kmsg 의존성 — silent fail

kakao-wiki의 `macos_osascript.sh` Step 2:
```bash
kmsg read "${ROOM}" --limit 1 --keep-window 2>/dev/null
```

- `kmsg` CLI는 brew 공식 패키지 아님 (`brew search kmsg` → 결과 없음)
- 별도 GitHub repo (jkf87/openclaw-kakao 등)에서 설치
- 미설치 시 exit 1 → `2>/dev/null`로 silent fail → **Step 2.5 GUI hard-assert fail**로 끝

**해결책 3가지**:
1. (✅ 권장) **katok으로 전환**
2. (수동) kmsg 직접 설치 + 카톡 권한 부여 → 복잡
3. (우회) `macos_osascript.sh`의 `kmsg read` 라인을 osascript로 직접 패치 → 다음 `git pull`에서 충돌

### 약점 2: GUI 부작용 — 사용자 카톡 방을 닫아버림

`macos_osascript.sh`는 카톡 UI를 자동 조작:
- Step 0: 카카오톡 활성화
- Step 1: 채팅 탭 전환
- Step 2: 방 열기 (kmsg 또는 osascript)
- Step 3~5: 메뉴 클릭 → "텍스트 파일로 저장"

이 과정에서:
- 카톡의 다른 방 창들이 **닫히거나** 다른 방으로 전환될 수 있음
- 사용자가 카톡으로 작업 중이면 **방해**됨
- Step 2.5의 GUI hard-assert가 `Window`라는 빈 창이 끼어들면 fail

**katok은 DB를 직접 읽으므로 이 문제 완전 회피.**

## 진단 체크리스트 (katok 워커 안 돌 때)

- [ ] `which katok` 으로 설치 확인
- [ ] Terminal.app에 **Full Disk Access** 줬는지 (`katok permissions macos` 가이드)
- [ ] `katok doctor --json` 으로 `archive.status` 가 `"present"` 인지
- [ ] `katok sync --source macos --json` 1회 수동 실행해보기 (실패 시 stderr 확인)
- [ ] `~/Library/Application Support/katok/archive.sqlite3` 파일 존재 + 크기 > 0
- [ ] sqlite3 으로 messages 테이블 직접 SELECT해서 데이터 확인
- [ ] rooms.yaml의 `chat_id` 또는 `kakao_room`이 실제 chat_name과 일치
- [ ] macmini 절전 깨우기 ON

## kakao-wiki → katok 마이그레이션 (실측 체크리스트)

1. **kakao-wiki 설치는 그대로 둠** — 어차피 git clone이라 안 깨짐
2. **katok 설치** (5분) + Full Disk Access 권한 (사용자 1분)
3. **첫 sync 1회 수동 실행**: `katok sync --source macos --json`
4. **chat_id 목록 확인**: `sqlite3 .../archive.sqlite3 "SELECT DISTINCT chat_id, chat_name FROM messages"`
5. **rooms.yaml에 chat_id 채우기** (옵션, 없어도 chat_name 매칭)
6. **파이프라인 코드 분기**:
   - `pipeline/katok_collect.py` (신규) — sqlite 읽기 + 6h 슬라이스
   - `pipeline/collect.py` (기존) — kakao-wiki wrapper, 백업으로 남겨둠
   - `run.sh`가 katok_collect 호출하도록 변경
7. **launchd plist는 그대로** — 6h 주기 cron은 변동 없음
8. **launchd unload/load 또는 시스템 재시작** (한 번)

## 외부 의존성 정리

| | kakao-wiki | katok |
|---|---|---|
| brew tap | (없음, git clone만) | `NomaDamas/katok` |
| brew formula | (없음) | `katok` (rust 소스 컴파일) |
| brew install 시간 | 0 | 4~5분 |
| cargo | ❌ | ✅ (brew install rust 자동) |
| kmsg | ⚠️ 필요 (없으면 silent fail) | ❌ |
| macOS TCC | Full Disk + Accessibility 2개 | Full Disk 1개 |
| 카톡 앱 | 항상 켜있어야 | 상관없음 |
| macmini 24/7 | 필수 | 권장 (launchd cron) |
