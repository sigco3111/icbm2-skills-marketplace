# 2-tier LLM Summarization (긴 본문 압축 패턴)

source 본문이 길어서 (카톡 1000건/일, RSS 1일 50건+, 긴 이메일 등) LLM 한 번에 요약하면 토픽이 2~3개로 뭉뚱그려질 때, **2-tier로 쪼개서 처리**하는 패턴.

2026-07-09 kakao-timeline에서 실측 검증. 1000건/일 카톡 단톡방 1개 요약이 baseline.

## 왜 1-tier가 안 되는가

```python
# ❌ BAD: 한 번에 1000건 LLM에 던짐
prompt = f"""
다음 카카오톡 대화 {len(messages)}건을 5개 토픽으로 요약하세요.
{messages}

요약:
"""
result = llm(prompt, max_tokens=2000)
# → "팀 회의 / 잡담 / 점심 메뉴 / 결정사항 / 기타" 같은 거대한 카테고리로 뭉뚱그려짐
# → 핵심 토픽 2~3개, 시간 흐름 손실
```

LLM의 attention이 메시지 1000건에 분산 → **상위 N개 토픽만 잡고 세부 토픽 다 놓침**. 시간순 정렬도 깨짐.

## 2-tier 패턴

```python
def two_tier_summarize(messages):
    # === Tier 1: 시간 chunk별 짧은 요약 ===
    tier1 = []
    for chunk in chunk_by_time(messages, window="30m"):
        s = llm.summarize(
            chunk=chunk,
            style="brief",          # 3-5줄로
            max_tokens=400,
        )
        tier1.append({"window": chunk.window, "summary": s, "msg_count": len(chunk)})
    
    # === Tier 2: Tier 1 결과 → 토픽 클러스터링 + 통합 ===
    tier2_prompt = f"""
다음은 한 단톡방의 {len(tier1)}개 시간 구간 요약입니다 (총 {sum(c['msg_count'] for c in tier1)}건).
이걸 다음 JSON 형식으로 정리하세요. 한국어.

{{
  "topics": [
    {{"name": "토픽명", "summary": "2-3줄 요약"}}
  ],
  "decisions": ["결정사항1", "결정사항2"],
  "action_items": [
    {{"who": "담당자", "what": "할 일", "when": "기한"}}
  ]
}}

시간 구간 요약들:
{tier1}

JSON:
"""
    tier2_raw = llm.summarize(prompt=tier2_prompt, max_tokens=2000)
    tier2 = json.loads(extract_json(tier2_raw))  # robust parse
    return {"tier1": tier1, "tier2": tier2, "msg_count": len(messages)}
```

## 핵심 디테일

### Tier 1: chunk 크기

| 메시지 빈도 | 권장 chunk |
|---|---|
| 카톡 (수 분~수십 분 1건) | 30분, ~50건 |
| 이메일/뉴스 (하루 10~50건) | 1일 1chunk |
| RSS (시간당 1~5건) | 1시간 |
| 긴 로그 (수천 줄) | 100줄 |

**너무 작으면**: LLM 호출 수 폭증, 비용/시간 ↑↑
**너무 크면**: 1-tier와 다를 게 없음

### Tier 1: 메시지 마스킹 (PII)

LLM에 보내기 **전** 마스킹:

```python
# ✅ GOOD: \b 대신 명시적 non-digit 경계 (한글/공백 호환)
#   \b는 한글과 어울리지 않아 한국어 텍스트에서 매칭 0건 가능
PHONE_RE = re.compile(r"(?:^|[^\d])(01[0-9]-?\d{3,4}-?\d{4})(?:[^\d]|$)")
EMAIL_RE = re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.-]+\b")
URL_RE = re.compile(r"https?://\S+")
# 계좌는 좁게 (전화 마스킹 후 잔여 패턴만)
ACCOUNT_RE = re.compile(r"(?:^|[^\d])(\d{2,4}-?\d{2}-?\d{4,8})(?:[^\d]|$)")

def mask_pii(text):
    # ⚠️ 순서 중요: 전화 → 이메일 → URL → 계좌
    # 1) 전화 먼저 (계좌 regex가 전화번호를 잡아먹는 함정 회피)
    # 2) capture group이라 sub는 lambda로 처리
    text = PHONE_RE.sub(lambda m: m.group(0).replace(m.group(1), "[전화]"), text)
    text = EMAIL_RE.sub("[이메일]", text)
    text = URL_RE.sub("[URL]", text)
    text = ACCOUNT_RE.sub(lambda m: m.group(0).replace(m.group(1), "[계좌]"), text)
    return text

# 참여자 이름은 hash로 대체
def hash_user_id(name):
    return "●" + hashlib.md5(name.encode()).hexdigest()[:4]
```

→ Tier 2 결과에는 hash로만 등장. 사람이 Notion에서 봐도 누가 뭘 말했는지 식별 가능 (동일 hash는 동일 인물이므로).

**PII 마스킹 함정 3가지 (2026-07-09 실측)**:

1. **`\b`는 한글과 어울리지 않음** — `'내 번호 010-1234-5678이야'`에서 `\b01[0-9]\b`이 매칭 0건. 한글+숫자 경계가 word boundary로 인식 안 됨. **해결**: `(?:\b|(?<=[^\d]))` 같은 lookbehind, 또는 본 코드처럼 `(?:^|[^\d])` 명시.
2. **ACCOUNT_RE `\d{3,6}-?\d{2,6}-?\d{2,6}`는 전화번호도 잡음** — `010-1234-5678`을 `010-1234` + `5678`로 잘라 `[계좌]`로 잘못 마스킹. **해결**: 전화 먼저 마스킹 + 계좌 regex를 `(\d{2,4}-?\d{2}-?\d{4,8})`로 좁힘.
3. **마스킹 순서 무시하면 위 1, 2번이 계속 발동** — 전화 마스킹을 가장 먼저.

### Tier 1: LLM 실패 시 fallback

```python
tier1 = []
for chunk in chunks:
    try:
        summary = llm.summarize(chunk)
    except Exception as e:
        # Tier 1 chunk 1개 실패해도 전체 파이프라인은 계속
        LOG.error(f"Tier 1 chunk {i} 실패: {e}")
        summary = "(요약 실패)"
    tier1.append({"window": ..., "summary": summary, "msg_count": len(chunk)})
```

→ Tier 1 부분 실패는 Tier 2 결과가 "성공이지만 일부 누락" 정도. sink row는 🟢 완료로 push.

### Tier 2: JSON 추출 (LLM이 형식 어김)

```python
def extract_json(text: str) -> dict:
    """LLM 출력에서 첫 번째 { ... } 블록 추출."""
    # 1차: pure JSON 시도
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    # 2차: 첫 { 부터 마지막 } 까지
    m = re.search(r"\{.*\}", text, re.DOTALL)
    if m:
        try:
            return json.loads(m.group(0))
        except json.JSONDecodeError:
            pass
    # 3차: 폴백 — raw 텍스트 그대로
    return {"raw": text, "topics": [], "decisions": [], "action_items": []}
```

→ Tier 2 LLM이 한국어 본문 + JSON 형식을 동시에 못 지키는 경우 흔함. graceful degradation.

## Tier 2가 필요 없는 경우

다음이면 1-tier로 충분 (Tier 1 생략):

- 본문이 짧음 (50줄 이하)
- 토픽이 명확히 1~2개 (예: 뉴스 헤드라인 1개)
- 실시간성 필요 (스트리밍 응답)

→ **Tier 1 → Tier 2 분기 조건**을 코드에 명시:

```python
if len(messages) <= 50:
    return one_tier_summarize(messages)
return two_tier_summarize(messages)
```

## 비용 추정 (카톡 1000건/일, 4-슬롯)

| 단계 | 호출 수 | 토큰 (in/out) | 비용 |
|---|---|---|---|
| Tier 1 (16 chunk × 4 슬롯) | 64 | 2k/0.4k | 약 $0.5/일 |
| Tier 2 (4 슬롯 × N방) | N×4 | 4k/2k | 약 $0.3/일 |
| **합계** | | | **$0.8/일** |

→ NIM/MiniMax 무료 티어 + 방 5개면 거의 0. **1-tier 무한루프보다 훨씬 안정**.

## sink로 push할 때 (Notion)

```python
def build_blocks(tier1, tier2, msg_count, active_users):
    blocks = []
    
    # 메타
    blocks.append(heading_2("📊 메타"))
    blocks.append(bullet(f"메시지 {msg_count}건 / 활성 사용자 {len(active_users)}명"))
    blocks.append(bullet(f"참여자 (마스킹): {', '.join(active_users)}"))
    
    # 토픽
    if tier2.get("topics"):
        blocks.append(heading_2("💬 핵심 토픽"))
        for t in tier2["topics"]:
            blocks.append(bullet(f"{t['name']}: {t['summary']}", bold_prefix=True))
    
    # 결정
    if tier2.get("decisions"):
        blocks.append(heading_2("✅ 결정 사항"))
        for d in tier2["decisions"]:
            blocks.append(bullet(d))
    
    # 액션
    if tier2.get("action_items"):
        blocks.append(heading_2("📌 액션 아이템"))
        for it in tier2["action_items"]:
            text = f"{it['who']}: {it['what']}"
            if it.get("when"):
                text += f" (기한: {it['when']})"
            blocks.append(to_do(text))  # to_do 블록 = Notion 체크박스
    
    # Tier 1 raw (있으면)
    if tier1:
        blocks.append(heading_2("🕐 시간대별 요약"))
        for t1 in tier1:
            blocks.append(bullet(f"[{t1['window']}] {t1['summary']} ({t1['msg_count']}건)"))
    
    return blocks
```

→ Notion 사용자가 row 클릭하면 본문에 토픽/결정/액션/시간대별 전부 펼쳐짐. DB는 SSOT, 본문이 디테일.

## 흔한 실수

1. **Tier 1 chunk 너무 작음** (5분) → LLM 호출 수 폭증, 비용 10배. 30분이 sweet spot.
2. **Tier 2 JSON 못 파싱** → `extract_json` 없이 그냥 `json.loads(result)` 하면 KeyError. → robust 파서 필수.
3. **Tier 1 결과를 Tier 2에 raw 텍스트로만 보냄** → LLM이 다시 "어떤 토픽이었지?" 잊어버림. → **메타데이터 포함** (시간, 메시지 수, 핵심 발화자).
4. **Tier 1/Tier 2 사이에 dedup 안 함** → 같은 토픽이 30분 chunk 3개에 다 등장 → Tier 2에서 한 토픽으로 묶어줘야 함. → cluster_topics가 LLM의 역할.
5. **raw 보관 정책 없음** → 1000건/일 × 30일 = 30K 메시지, 디스크 압박. → 7일 TTL + sink=요약만.
