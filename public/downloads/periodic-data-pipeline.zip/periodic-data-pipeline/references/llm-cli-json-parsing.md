# LLM CLI 응답 파싱 패턴 (2026-07-09 실측)

대부분의 LLM CLI는 응답이 **JSON envelope**으로 옴 (Anthropic Messages API, OpenAI Chat Completions, MiniMax Messages API). `--quiet --output text` 같은 플래그가 작동하는 CLI도 있지만 **항상 보장 안 됨**. sink로 보내기 전엔 text만 추출해야 함.

## 대표 케이스: `mmx text chat`

```bash
$ mmx text chat --message "안녕" --max-tokens 30
{
  "id": "069e34a0874206dcac3c82c0ebe28c95",
  "type": "message",
  "role": "assistant",
  "model": "MiniMax-M2.7",
  "content": [
    {
      "thinking": "The user said \"안녕\"...",
      "type": "thinking"
    }
  ],
  "usage": {...}
}
```

`content` 배열에 `type=thinking`만 있고 `type=text` 없음 (max_tokens 부족). `--output text`는 무시되거나 partial.

## 일반화된 text 추출 패턴

```python
import json, subprocess

def llm_call(prompt: str, max_tokens: int = 1000, cmd: list[str] | None = None) -> str:
    """CLI 응답에서 첫 번째 type=text 블록 추출. 실패 시 raw JSON 반환."""
    if cmd is None:
        cmd = ["mmx", "text", "chat", "--message", prompt,
               "--max-tokens", str(max_tokens), "--quiet"]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
    if result.returncode != 0:
        raise RuntimeError(f"CLI 실패: {result.stderr[:200]}")
    try:
        data = json.loads(result.stdout)
    except json.JSONDecodeError:
        return result.stdout.strip()  # plain text CLI (예: ollama, 일부 경량 CLI)
    # JSON envelope: content 배열에서 text 블록 추출
    for key in ("content", "choices", "message"):  # API별 위치
        items = data.get(key)
        if isinstance(items, list):
            texts = [c.get("text", "") for c in items if c.get("type") in ("text", None)]
            if texts:
                return "".join(texts).strip()
        elif isinstance(items, dict) and "content" in items:  # OpenAI chat.completion.message
            return items["content"].strip()
    # 그래도 못 찾으면 raw 반환 (Tier 2에서 raw 폴백 처리)
    return result.stdout.strip()
```

## CLI별 envelope 위치 요약

| CLI | envelope | text 위치 | 비고 |
|---|---|---|---|
| `mmx text chat` | MiniMax Messages API | `content[].type=text` | thinking만 있으면 raw |
| `claude` (Anthropic) | Messages API | `content[].type=text` | 동일 구조 |
| `ollama run` | plain text | (없음) | `--output text` 정상 |
| `openai` chat | Chat Completions | `choices[0].message.content` | 약간 다름 |
| `gh models` | Chat Completions | `choices[0].message.content` | 동일 |

## mmx 인증 패턴

```bash
# 1회만
source ~/.hermes/secrets/minimax.env
mmx auth login --api-key "$MINIMAX_API_KEY"
# 이후 ~/.mmx/config.json에 저장되어 재사용
```

`mmx auth status`로 확인 가능. 인증 안 하면 `{"error": {"code": 3, "message": "No credentials found."}}`.

## sink push 시점의 위험

LLM CLI가 `--quiet`도 stdout에 JSON dump하면, 그걸 그대로 `subprocess.run(...).stdout`으로 받아 `text`로 sink에 push할 수 있음. → **반드시 위 패턴으로 text만 추출**.

특히 **마크다운 응답이 LLM 출력인 경우**, sink가 Notion이면 블록 변환이 필요 → JSON envelope를 sink에 그대로 push하지 말고 text만 추출 후 별도 `markdown_to_blocks()` (별도 reference).

## 흔한 실수 3가지

1. **`--quiet`만 믿고 stdout을 그대로 사용** → JSON envelope가 sink에 들어감.
2. **`max_tokens` 너무 작게** → text 블록 생성 전에 thinking에 토큰 다 소진 → row가 비어 보임. Tier 1은 `max_tokens=400` 이상, Tier 2는 `max_tokens=2000` 이상.
3. **CLI의 stderr에 progress 출력** → `result.stdout`만 보고 error 놓침. `returncode != 0`이면 stderr도 확인.