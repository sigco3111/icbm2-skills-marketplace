# launchd macOS Quirks (2026-07-09 kakao-timeline 실측)

launchd는 macOS의 cron 대체. **LaunchAgent** (사용자별, `~/Library/LaunchAgents/`) 형태로 워커 등록. 주기적 워커, 부팅 시 자동 시작 등에 사용.

## 등록 / 해제

```bash
# 등록 (이름은 자유, 보통 com.<user>.<project>)
cp my.plist ~/Library/LaunchAgents/com.mac.kakaotimeline.run.plist
chmod 600 ~/Library/LaunchAgents/com.mac.kakaotimeline.run.plist
launchctl unload ~/Library/LaunchAgents/com.mac.kakaotimeline.run.plist 2>/dev/null
launchctl load -w ~/Library/LaunchAgents/com.mac.kakaotimeline.run.plist

# 상태 확인
launchctl list | grep <project>
# PID 출력됨 (- 면 미실행)

# 상세 진단
launchctl print "gui/$(id -u)/com.mac.kakaotimeline.run"
# ⚠️  gui/$(id -u) prefix 필수 (아래 함정 4)

# 수동 1회 트리거
launchctl start "gui/$(id -u)/com.mac.kakaotimeline.run"
# (수동 트리거는 prefix 없어도 작동하지만 일관성 위해 prefix 권장)

# 제거
launchctl unload ~/Library/LaunchAgents/com.mac.kakaotimeline.run.plist
rm ~/Library/LaunchAgents/com.mac.kakaotimeline.run.plist
```

## 표준 plist (4-슬롯, TZ 명시)

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.<user>.<project></string>

    <key>ProgramArguments</key>
    <array>
        <string>/bin/bash</string>
        <string>/Users/<user>/work/<project>/run.sh</string>
    </array>

    <key>WorkingDirectory</key>
    <string>/Users/<user>/work/<project></string>

    <!-- 4-슬롯 (00, 06, 12, 18시) -->
    <key>StartCalendarInterval</key>
    <array>
        <dict>
            <key>Hour</key><integer>0</integer>
            <key>Minute</key><integer>0</integer>
        </dict>
        <dict>
            <key>Hour</key><integer>6</integer>
            <key>Minute</key><integer>0</integer>
        </dict>
        <dict>
            <key>Hour</key><integer>12</integer>
            <key>Minute</key><integer>0</integer>
        </dict>
        <dict>
            <key>Hour</key><integer>18</integer>
            <key>Minute</key><integer>0</integer>
        </dict>
    </array>

    <!-- ⚠️  TZ 명시 필수 (KST 환경에서 9시간 밀림 방지) -->
    <key>EnvironmentVariables</key>
    <dict>
        <key>TZ</key><string>Asia/Seoul</string>
        <key>PATH</key><string>/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin</string>
    </dict>

    <key>RunAtLoad</key>
    <false/>  <!-- 부팅 시 자동 시작 비활성 (워커 안정화 후 변경) -->

    <key>StandardOutPath</key>
    <string>/Users/<user>/work/<project>/logs/launchd.out.log</string>
    <key>StandardErrorPath</key>
    <string>/Users/<user>/work/<project>/logs/launchd.err.log</string>

    <key>ExitTimeOut</key>
    <integer>600</integer>  <!-- 10분 타임아웃 -->
    <key>Nice</key>
    <integer>5</integer>
</dict>
</plist>
```

→ `plutil -lint ~/Library/LaunchAgents/com.x.y.plist`로 문법 검증.

## 함정 4가지 (2026-07-09 kakao-timeline 실측)

### 함정 1: timezone 미명시 → 9시간 밀림

macOS 시스템 timezone이 KST여도 launchd는 cron을 **시스템 timezone**으로 해석. macOS timezone이 UTC인 환경(KST인데 시간대 자동 설정을 끈 상태)에서는 cron이 9시간 밀림.

**해결**: plist env에 `TZ=Asia/Seoul` 명시. 또는 스크립트 안에서 `TZ=KST-9 date` 사용.

### 함정 2: `launchctl print/start` 라벨 prefix

```bash
# ❌ BAD: Domain does not support requested action
launchctl print com.mac.kakaotimeline.run

# ✅ GOOD: gui/$(id -u) prefix
launchctl print "gui/$(id -u)/com.mac.kakaotimeline.run"
```

`launchctl list` / `launchctl start`는 prefix 없이도 작동하지만, `print` / `bootstrap` / `bootout`은 **반드시 prefix 필요**. 일관성 위해 항상 prefix 사용.

### 함정 3: 절전 모드

macmini가 절전 들어가면 launchd 워커도 멈춤. 시스템 설정 → 에너지 → **"네트워크 액세스를 위해 깨우기"** 활성화. 또는 macmini를 "절전 안 함" 모드로.

### 함정 4: GUI 의존 워커

카톡/kakaowiki 같이 macOS GUI 자동화 기반 sink는 워커 시점에 **앱이 켜져있어야** 함. 안 떠 있으면 launchd 워커는 백그라운드에서 GUI 앱 launch 시도하지만 sandboxing/TCC로 실패할 수 있음.

**해결**: 앱을 항상 켜놓는 정책이 가장 안정. 또는 `osascript -e 'tell application "KakaoTalk" to activate'` 같은 명령을 워커 시작 시 추가 (kakao-wiki 자체가 GUI 활성화 단계 포함).

## 디버깅 체크리스트

워커 안 돎 / 실패 시 순서대로:

1. `launchctl list | grep <project>` → 등록되어 있고 PID 있는지
2. `launchctl print "gui/$(id -u)/<label>"` → `state` (`not running` / `waiting` / `running` / `error`)
3. `cat logs/launchd.err.log` → stderr
4. `cat logs/launchd.out.log` → stdout (성공 시엔 안 만들어질 수 있음 — `>` redirection만 있고 워커가 stdout 안 쓰면)
5. `bash run.sh` 직접 실행 → 어떤 단계에서 실패하는지
6. 시스템 콘솔 (`/Applications/Utilities/Console.app`) → `subsystem == com.apple.launchd` 필터

## 워커 실행 환경

launchd로 등록된 워커는 **상호작용 세션이 아님**:

- `~/.zshrc` / `~/.bashrc` 안 로드 (login shell 아님)
- `PATH`가 매우 좁음 (plist env에서 명시)
- 사용자 GUI 세션 토큰 없음 (일부 API/CLI 실패)
- SSH_AUTH_SOCK 상속됨

→ **스크립트 안에서 PATH/TZ/env 명시적으로 설정**하거나 plist에 박을 것.

## 흔한 실수

1. **RunAtLoad=true로 부팅 시 자동 시작** → macOS 부팅 후 카톡 앱이 안 떠있으면 워커가 GUI 의존 단계에서 실패. **처음엔 false, 안정화 후 true**.
2. **StandardOutPath 안 지정** → launchd가 stdout을 `/dev/null`로 보냄. 항상 명시.
3. **WorkingDirectory 안 지정** → 스크립트 안의 상대경로가 깨짐. 명시.
4. **Unload 없이 plist 수정** → 변경 사항 반영 안 됨. unload → load -w.
5. **root LaunchDaemon vs 사용자 LaunchAgent 혼동** → GUI 자동화는 **LaunchAgent** (사용자 세션). LaunchDaemon (root)은 GUI 접근 불가.