#!/bin/bash
# recent N시간 내 push 성공/실패 row 검증
# Notion search API로 카운트

set -e

NOTION_KEY=$(cat ~/.hermes/secrets/notion_token_kakao.txt)
HOURS="${1:-24}"  # 기본 24시간
DB_NAME="${2:-KakaoTalk Timeline}"

# ISO 8601 — N시간 전 (Notion created_time filter용)
AFTER=$(python3 -c "from datetime import datetime, timedelta, timezone; print((datetime.now(timezone.utc) - timedelta(hours=$HOURS)).strftime('%Y-%m-%dT%H:%M:%S.000+00:00'))")

# Notion search
echo "Searching Notion pages (DB=$DB_NAME, after=$AFTER)..."

PAYLOAD=$(cat <<EOF
{
  "query": "$DB_NAME",
  "filter": {"value": "page", "property": "object"},
  "sort": {"direction": "descending", "timestamp": "created_time"}
}
EOF
)

echo "$PAYLOAD" > /tmp/notion_verify.json

RESPONSE=$(curl -s -X POST "https://api.notion.com/v1/search" \
  -H "Authorization: Bearer $NOTION_KEY" \
  -H "Notion-Version: 2025-09-03" \
  -H "Content-Type: application/json" \
  -d @/tmp/notion_verify.json)

# Python으로 후처리
python3 <<PYEOF
import json
resp = json.loads('''$RESPONSE''')
results = resp.get("results", [])

# filter to last N hours
from datetime import datetime, timezone, timedelta
cutoff = datetime.now(timezone.utc) - timedelta(hours=$HOURS)
recent = [p for p in results if datetime.fromisoformat(p["created_time"].replace("Z", "+00:00")) > cutoff]

# count by state
states = {"🟢 완료": 0, "🟡 부분": 0, "🔴 실패": 0}
for p in recent:
    state_prop = p.get("properties", {}).get("상태", {}).get("select")
    if state_prop:
        name = state_prop.get("name", "")
        states[name] = states.get(name, 0) + 1

print(f"최근 {$HOURS}시간 내 push 결과:")
print(f"  🟢 완료: {states.get('🟢 완료', 0)}건")
print(f"  🟡 부분: {states.get('🟡 부분', 0)}건")
print(f"  🔴 실패: {states.get('🔴 실패', 0)}건")
print(f"  총: {len(recent)}건")
PYEOF
