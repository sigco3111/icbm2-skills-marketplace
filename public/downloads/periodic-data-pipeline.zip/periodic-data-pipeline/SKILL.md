---
name: periodic-data-pipeline
description: 주기적 데이터 수집 → 변환 → 외부 API push 자동화 파이프라인 클래스. "X를 Notion에 자동으로 올려줘", "주식/뉴스/날씨/카톡/GitHub trending을 주기적으로 Notion DB에 push", "launchd cron으로 6시간마다 자동 동기화", "외부 데이터 소스 → Notion DB 파이프라인" 같은 요청에 발동. SSOT=Notion DB / launchd 워커 / 2-tier LLM 요약(긴 본문) / PII 마스킹 / raw TTL 정책 / 동적 소스(YAML) / 부분 실패 시 재시도. brainstorming 4옵션 + 직접 추천 + 비가역 경고가 강하게 작용하는 클래스 — 사용자가 결정 단계에서 자주 흔들리므로 옵션 4개 제시 + 추천 명시 + 결정 묻기 패턴 강제. Notion-only 아님 — GH Pages/Discord/Slack도 sink 후보, 단 Notion이 프라이버시와 SSOT 면에서 가장 안전.
version: 0.3.0
author: hermes-curator
license: MIT
metadata:
  hermes:
    tags: [automation, notion, kakao-wiki, katok, launchd, pipeline, sync, periodic, cron, kakao-timeline]
    homepage: null
---
# Periodic Data Pipeline (외부 → sink 자동화 클래스)
# Periodic Data Pipeline (외부 → sink 자동화 클래스)

## 트리거

다음 키워드/요청 중 하나라도 매칭되면 로드:

- X를 자동으로 Notion에 올려줘
- 주식/뉴스/날씨/카톡/GitHub/RSS/CSV를 주기적으로 Notion DB에 push
- launchd/cron으로 N시간마다 자동 동기화
- 외부 데이터 소스 → Notion DB 파이프라인
- 단톡방 요약을 자동으로 Notion에 정리
- 이 레포의 GitHub trending/release를 Notion에 기록

## 이 클래스가 다루는 구체 작업 예시 (2026-07-09 검증)

| 데이터 소스 | 변환 | sink | 주기 |
|---|---|---|---|
| 카카오톡 단톡방 (kakao-wiki) | 2-tier LLM 요약 (시간 chunk → 토픽 통합) | Notion DB | 6h |
| 한국/미국 주식 (yfinance) | 시세 + 변동률 | Notion DB | 매일 |
| GitHub trending (gh-trending) | AI/ML/iOS 필터 | Notion DB + Telegram 다이제스트 | 매일 |
| RSS/블로그 (blogwatcher) | LLM 요약 | Notion + LLM Wiki | 매시간 |
| 공공데이터 (data.go.kr) | 변환 + 임계치 알림 | Notion + Telegram | 매일 |

모두 같은 구조: collect → transform → push → cleanup → verify. 이 스킬은 그 구조를 한 번 캡처해서 도메인별 변형 시간을 0으로 만든다.

---

## 클래스-레벨 워크플로 (7단계)

### 0단계: 브레인스토밍 — 이 단계가 가장 중요

사용자가 "자동으로 X를 Notion에 올려줘" 같은 추상 요청을 하면, 4가지 결정을 4개 옵션 비교표로 정리해 한 번에 묶어 묻는다. 순차로 4번 따로 묻지 말 것 — 한 번에 묶어야 사용자가 흐름 안에서 결정 가능.

**반드시 제시할 4개 옵션 구조 (이 순서로)**:

1. **sink 선택** (Notion / GH Pages / Obsidian / Telegram / 로컬만)
2. **빈도 + 자동화 깊이** (수동 / 반자동 / 풀자동)
3. **SSOT 위치** (sink = SSOT / macmini 로컬 = SSOT / 양쪽 병행)
4. **raw 보관 정책** (raw 영구 / 7일 TTL / sink만 영구)

각 옵션은 표로 비교, **하나만 추천 표시**, 마지막에 어떤 구성으로 진행할까요 한 번에 묻기. 4번 묻는 게 아니라 1번에 묶어서 물음.

**사용자 결정 흔들림 대비 패턴** (2026-07-09 실측):

- 사용자는 첫 선택에서 2~3번 마음을 바꾸는 게 정상 — "수동으로" → "자동으로", "텔레그램 알림 있음" → "알림 빼자", "옵션 1" → "옵션 5" → "Notion" 식
- → 4옵션 표는 최종 결정이 아니라 후보 생성으로 위치시킴
- → 사용자가 바꾸면 "그럼 새 옵션 8을 그려볼게요"로 빠르게 재구성, **결정 변경에 대한 미안함/사과 표현 금지** (이건 정상 워크플로 일부)

### 1단계: 환경 점검

병렬로 확인:

```bash
# - 작업 디렉토리 (사용자 prefs: ~/work/)
ls -la ~/work 2>/dev/null
# - 패키지 매니저
which brew && brew --version | head -1
# - sink 앱/서비스 실행 상태 (예: 카톡)
ps aux | grep -i kakaotalk | grep -v grep
# - OS/아키텍처 (Apple Silicon인지)
sw_vers && uname -m
# - 토큰/시크릿 파일
ls ~/.hermes/secrets/ 2>/dev/null
```

**token을 절대 메시지로 받지 말 것** — 사용자에게 `echo "ntn_..." > ~/.hermes/secrets/... && chmod 600` 패턴 안내, 저쪽에서는 "저장 완료" 한마디만 받기. 텔레그램/슬랙 채팅 로그에 토큰이 남으면 안 됨.

### 2단계: sink 측 사전 작업 (사용자 UI 작업)

- **Notion**: 새 워크스페이스 → 새 integration → 토큰 → 루트 페이지 → integration 공유 → page_id URL 공유
- **GH Pages**: repo 생성 → 토큰 시크릿 등록
- **Telegram 봇**: 이미 있으면 token 재사용

→ 이 단계는 **사용자 UI 작업이라 시간 듦**. 병렬로 가능하면 사용자에게 "Notion UI 작업하는 동안 코드 작성" 제안. 단 **사용자가 순차로 가겠다고 하면 그대로 따르기** (병렬 강요 금지).

### 3단계: 디렉토리 구조 + YAML SSOT

```text
~/work/<project>/
├── config/
│   ├── sources.yaml       # 동적 소스 목록 (방/리포/RSS URL 등)
│   └── sink.yaml          # sink 설정 (Notion token, DB id)
├── pipeline/
│   ├── collect.py         # 소스에서 원본 추출
│   ├── transform.py       # 2-tier LLM 요약 / 정규화
│   ├── push.py            # sink API 호출
│   ├── cleanup.py         # raw TTL (보통 7일)
│   └── verify.py          # 최근 N건 push 확인
├── logs/
└── archive/
    └── raw/               # 로컬만, TTL 후 자동 삭제
```

**SSOT는 sink (Notion DB)가 권장** — single source of truth이면서 동시에 UI. macmini 로컬은 raw 캐시.

### 4단계: 2-tier LLM 요약 패턴 (긴 본문일 때)

카톡/뉴스처럼 메시지가 1000건 가까이 되는 경우 **한 번에 LLM에 던지면 토픽 2~3개로 뭉뚱그려짐**. 반드시 2-tier:

```python
# pipeline/transform.py (개념)
def two_tier_summarize(messages):
    # 1차: 시간 윈도우 chunk별 (보통 30분~1h)
    tier1 = []
    for chunk in chunk_by_time(messages, window="30m"):
        s = llm.summarize(chunk, style="brief")  # 3-5줄
        tier1.append({"window": chunk.window, "summary": s})
    
    # 2차: tier1 결과 묶어서 토픽 클러스터링 + 통합
    tier2 = llm.cluster_topics(tier1, style="detailed")
    
    return {
        "topics": tier2.topics,
        "decisions": tier2.decisions,
        "action_items": tier2.action_items,
        "msg_count": len(messages),
    }
```

### 5단계: Notion DB 스키마 (sink = Notion일 때)

**Notion API 함정 4가지 (반드시 숙지)**:

1. **API 버전**: DB 생성은 `2022-06-28`, 페이지 생성/조회는 `2025-09-03` — `notion` 스킬 참조
2. **이중 ID**: `data_source_id`는 쿼리용, `database_id`(`parent.database_id`)는 페이지 생성용 — 섞으면 404
3. **한국어 property name**: ICBM2 기존 DB는 한국어 (`이름`, `날짜`, `상태`) — 영어 `Name`/`Date`/`Status` 쓰면 400
4. **row 표시 순서 = 생성 순서**: 1→18 표시하려면 18→1 역순으로 push

**스키마 표준**:

| Property | Type | 용도 |
|---|---|---|
| 제목 | Title | 시각적 식별자 (예: "2026-07-09 06-12시 — 팀A") |
| 소스 | Select | 단톡방/리포/RSS 이름 (방 동적 추가 = Select 값 추가) |
| 시간대 | Date (range) | 수집 윈도우 시작~끝 |
| 메시지 수 | Number | 카운트 (검증용) |
| 활성 사용자 수 | Number | 참여자 수 |
| 토픽 수 | Number | 2-tier 후 토픽 개수 |
| 상태 | Select | 🟢 완료 / 🟡 부분 / 🔴 실패 |

Body는 토픽별 요약 + 결정사항 + 액션아이템 (heading_2 + bulleted_list_item 블록).

### 6단계: launchd cron 등록 (macOS)

```xml
<!-- ~/Library/LaunchAgents/com.<user>.<project>.plist -->
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>com.<user>.<project></string>
  <key>ProgramArguments</key>
  <array>
    <string>/bin/bash</string>
    <string>-c</string>
    <string>cd ~/work/<project> && python3 pipeline/run.py 2>&1 | tee -a logs/launchd-stdout.log</string>
  </array>
  <key>StartCalendarInterval</key>
  <array>
    <dict><key>Hour</key><integer>0</integer><key>Minute</key><integer>5</integer></dict>
    <dict><key>Hour</key><integer>6</integer><key>Minute</key><integer>5</integer></dict>
    <dict><key>Hour</key><integer>12</integer><key>Minute</key><integer>5</integer></dict>
    <dict><key>Hour</key><integer>18</integer><key>Minute</key><integer>5</integer></dict>
  </array>
  <key>StandardOutPath</key>
  <string>~/work/<project>/logs/launchd-stdout.log</string>
  <key>StandardErrorPath</key>
  <string>~/work/<project>/logs/launchd-stderr.log</string>
  <key>RunAtLoad</key>
  <false/>
</dict>
</plist>
```

```bash
launchctl load ~/Library/LaunchAgents/com.<user>.<project>.plist
# 진단
launchctl list | grep <project>
# 수동 1회 실행 (디버깅)
launchctl start com.<user>.<project>
# 제거
launchctl unload ~/Library/LaunchAgents/com.<user>.<project>.plist
```

**macOS 함정 4가지**:

1. **절전 모드**: macmini가 절전 들어가면 launchd 워커도 멈춤 → 시스템 설정 → 에너지 → "네트워크 액세스 시 깨우기" 활성화
2. **GUI 의존 sink (kakao-wiki macos provider 등)**: GUI 앱이 동시에 떠 있어야 함. 안 떠 있으면 launchd 워커는 백그라운드에서 GUI 앱 launch 시도하지만 sandboxing으로 실패할 수 있음 → **앱 항상 켜놓기 정책이 가장 안정**
3. **timezone 명시 (KST 환경)**: macOS timezone이 KST여도 launchd plist는 cron을 시스템 timezone으로 해석. **plist env에 `TZ=Asia/Seoul` 명시**하거나 스크립트 안에서 `TZ=KST-9 date` 사용. 안 그러면 macOS timezone이 UTC인 환경에서 cron이 9시간 밀림.
4. **`launchctl print/start` 라벨 prefix**: `com.x.y` 라벨 등록 후 `launchctl start com.x.y`는 작동하지만 `launchctl print com.x.y`는 `Domain does not support requested action`. **해결**: `launchctl print "gui/$(id -u)/com.x.y"`로 prefix. 수동 트리거도 `launchctl start "gui/$(id -u)/com.x.y"` 권장.

### 7단계: 검증 (verify.py)

Notion search 또는 query API로 최근 N건 push 확인:

```python
# pipeline/verify.py
import os, json
from datetime import datetime, timedelta

def verify_recent_push(hours: int = 24):
    """최근 N시간 내 push 성공/실패 row 카운트"""
    # Notion search with query="프로젝트명" + filter=created_time>now-Nh
    # → 성공: state='🟢 완료' row 수
    # → 실패: state='🔴 실패' row 수
    # → 누락: (예상 push 횟수) - (실제 row 수)
```

→ `automation-healthcheck` 스킬에 `periodic-data-pipeline.verify` 항목 추가하면 좋은 통합.

---

## ⚠️ 비가역 결정 + 안전장치

### 비가역 결정 3가지 (구현 전 확인)

1. **public GH Pages에 무엇을 push** — raw 대화는 **절대 금지**. 한 번 푸시한 md는 GitHub 캐시에 영구. summary만.
2. **Notion 워크스페이스 공유 범위** — 다른 사람이 같이 쓰는 워크스페이스에 raw push하면 노출. **별도 워크스페이스 강력 권장**.
3. **Notion integration 권한** — workspace-level integration은 모든 페이지 접근 가능. 페이지-level로 좁히기.

### 안전장치 3중

- **token 시크릿 파일**: `~/.hermes/secrets/<name>.txt` + `chmod 600`. GH/공개 repo 절대 X.
- **raw TTL**: macmini 로컬 7일 후 자동 삭제. sink는 요약만.
- **Notion Share to web OFF**: 기본값은 워크스페이스 내부만. "Share to web" 실수로 켜면 public.

---

## 흔한 함정 7가지

1. **Notion API version 2025-09-03으로 DB 생성 시도** → "Creating new databases with data sources is not supported" 에러. **DB 생성은 반드시 2022-06-28**.
2. **data_source_id를 페이지 생성 parent로 사용** → 404. **parent.database_id** 사용.
3. **카톡 익명 export 만료** (07-06 memory): 3개월+ → 4일로 단축. macos provider 막히면 sink push가 🟡 부분으로 떨어짐 → 알림 채널이 있으면 "수집 실패" 발송.
4. **LLM 한 번에 1000건 요약** → 토픽 뭉뚱그려짐. 반드시 2-tier. (`references/two-tier-llm-summarization.md`)
5. **launchd + macOS 절전** → 워커 안 돎. "깨우기" 옵션 필수.
6. **bash 산술 octal 함정** — `WINDOW_START=06:00`일 때 `$((10#$(${WINDOW_START%:*}) + 6))`는 `$(06)` → `06: command not found` (`$()`는 명령 치환). **해결**: `$((10#${WINDOW_START%:*} + 6))` — 안쪽 `$()` 빼기. 같은 패턴이 다른 시간 계산 (cron wrapper, 슬라이스 로직)에도 흔함.
7. **LLM CLI `--quiet`는 silent JSON 출력일 수 있음** — `mmx text chat`은 응답이 JSON envelope (content 배열에 thinking/text). `--output text` 안 먹음. **해결**: `references/llm-cli-json-parsing.md` 패턴으로 text 블록 추출.
8. **kakao-wiki의 kmsg 의존성 silent fail** (2026-07-09) — `kmsg read`가 없으면 exit 1 + `2>/dev/null`로 stderr 숨김 → 다음 단계의 `Step 2.5 GUI hard-assert`가 fail → "방 부재" 에러. **해결**: katok (DB 직접 읽기) 또는 `macos_osascript.sh`의 kmsg 라인을 osascript 폴백으로 패치. **kakao-wiki를 sink로 쓸 때는 `which kmsg` 1회 확인 필수**.
9. **kakao-wiki의 GUI 부작용** (2026-07-09) — `macos_osascript.sh`가 카톡 UI를 자동 조작하면서 사용자가 열어둔 **카톡 창이 닫히거나 다른 방으로 전환**될 수 있음. **해결**: katok (DB 직접 읽기 = GUI 안 건드림) 또는 워커 실행 시 사용자에게 "카톡 안 만지는 시간" 양해. **첫 실행 후 사용자에게 "카톡 창이 그대로인지" 확인받기**가 안정 패턴.

---

## 템플릿 파일 (templates/)

- `templates/sources.yaml` — 동적 소스 목록 (방/리포/RSS)
- `templates/sink.yaml` — sink 설정 (Notion token, DB id, 옵션)
- `templates/launchd.plist` — 4-스롯 launchd 등록 템플릿
- `templates/run.sh` — 통합 실행 스크립트 (collect + transform + push + cleanup)

## 스크립트 (scripts/)

- `scripts/verify_recent.sh` — Notion search로 최근 24h push 검증
- `scripts/raw_cleanup.sh` — 7일 지난 raw CSV 자동 삭제

## 레퍼런스 (references/)

- `references/notion-pitfalls.md` — Notion API 6대 함정 + 한국어 property name + **토큰 노출 사고 (2026-07-09) + parse_page_id trailing anchor 버그**
- `references/kakao-wiki-macos.md` — kakao-wiki macos provider 설치/권한/주의 (**2026-07-09 실측**: 손쉬운 사용/Full Disk Access, 카톡 앱 항상 켜기, 익명 export 만료 4일, 셀렉터 의존, 단일 세션 제약, **kmsg silent fail + GUI 부작용으로 사용자 카톡 방이 닫히는 함정**)
- `references/katok-macos.md` — **katok (NomaDamas/katok) 대안 (2026-07-09 추가)**: kakao-wiki의 두 약점 (kmsg silent fail, GUI 부작용) → katok이 안정적 대안. brew tap + Full Disk Access 1개, archive.sqlite3 스키마, 파이프라인 통합 코드 패턴, 마이그레이션 체크리스트
- `references/launchd-macos-quirks.md` — 절전/GUI 앱/플릿 디버깅 (**2026-07-09 추가**: TZ=Asia/Seoul 명시, `gui/$(id -u)` prefix)
- `references/two-tier-llm-summarization.md` — 2-tier 요약 패턴 + 프롬프트 템플릿 (**2026-07-09 kakao-timeline 실측**: 30분 chunk, PII 마스킹, JSON extract, 1000건/일 기준 $0.8/일, **PII regex 함정 3종 — `\b` 한글 비호환 / ACCOUNT_RE가 전화번호 잡아먹음 / 마스킹 순서 중요**)
- `references/llm-cli-json-parsing.md` — `mmx text chat` 등 LLM CLI 응답이 JSON envelope일 때 text 블록 추출 패턴 (**2026-07-09 추가**)
- `references/brainstorming-4-options-pattern.md` — 결정 흔들림 사용자에 대한 옵션 4개 비교표 패턴 (2026-07-09 7회 결정 변경 실측)
