---
name: legacy-game-source-archive
description: "VC++ 6 또는 GP32 게임 백업을 GitHub 공개로 정리·푸시할 때 사용합니다."
trigger: "VC++ 6 / DirectDraw / GP32 게임 백업을 GitHub 공개로 정리·푸시할 때"
last_updated: 2026-07-31
status: active
---

# Legacy Game Source Archive → GitHub 공개

`/Users/mac/work/backup/01-public/<Game>/` 같은 본인 비영리 게임 백업 폴더를 GitHub 공개 저장소로 정리·푸시하는 작업을 위한 클래스-레벨 워크플로우.

## 핵심 원칙

1. **원본 절대 수정 금지** — `/Users/mac/work/backup/...` 폴더는 손대지 않는다. 작업 사본은 `/Users/mac/work/github/<repo-slug>/` 에 만들어 그 안에서만 작업한다.
2. **빌드 산출물 정리** — VC++ 6 / GP32 / DirectDraw 시점의 부산물을 `.gitignore`로 제외하고, 푸시 사본에서는 실제 파일도 제거한다.
3. **README는 "화려하고 자세하게"** — 사용자가 명시적으로 요청한 품질 기준. shields.io 배지, ASCII 다이어그램, 클래스 계층, 시스템 아키텍처 다이어그램, 코드 스니펫, 코드 모듈 표, emoji 풀 폴더 트리, 알려진 한계 섹션, 외부 SDK 원 소유자 고지.
4. **푸시 후 GitHub API 검증 필수** — `visibility`, `commits/main`, `readme size`, `contents/` 루트 트리, 커밋 해시 일치.
5. **비공개 vs 공개 트랩** — 사용자가 "공개"를 명시하기 전엔 옵션 제시. 비공개 푸시 후 "README 안 보임" 질문이 오면 GitHub UI의 README 자동 미리보기가 비공개에선 비활성이라서 그런 것 — 코드 탭 README.md 직접 클릭 안내.

## 워크플로우 (7단계)

### 1단계: 작업 사본 폴더 생성

```bash
mkdir -p /Users/mac/work/github
cp -a "/Users/mac/work/backup/01-public/<Game>" /Users/mac/work/github/<repo-slug>
```

<repo-slug>는 GitHub 저장소 URL 슬러그로, 보통 영문 소문자 + 하이픈. 예: `flamesword-action`, `gp32-bluemarble-king`, `dnb-action-rpg`.

검증된 슬러그 매핑 (2026-07-31 기준):

| 원본 백업 폴더 | 작업 사본 | GitHub repo-slug | 공개 |
|---|---|---|---|
| `01-public/GP32/부루마블대왕/` | `/Users/mac/work/github/gp32-bluemarble-king/` | `gp32-bluemarble-king` | 공개 |
| `01-public/GP32/일단피해 소스/` | `/Users/mac/work/github/gp32-blaster-vertical/` | `gp32-blaster-vertical` | 공개 |
| `01-public/Win/DnB/` | `/Users/mac/work/github/dnb-action-rpg/` | `dnb-action-rpg` | 공개 |
| `01-public/Win/consol_shooting/` | `/Users/mac/work/github/win32-console-shooter/` | `win32-console-shooter` | 공개 |
| `01-public/Win/FlameSword/` | `/Users/mac/work/github/flamesword-action/` | `flamesword-action` | 공개 |
| `01-public/Win/GateHeavens/` | `/Users/mac/work/github/gateheavens-shmup/` | `gateheavens-shmup` | 공개 |
| `01-public/GP32/GP32_리소스 모음/` | `/Users/mac/work/github/gp32-resource-archive/` | `gp32-resource-archive` | 비공개 |

### 2단계: 빌드 산출물 정리

작업 사본에서 다음 패턴을 일괄 제거한다 (VC++ 6 / GP32 / DirectDraw 시점 통합).

```python
from pathlib import Path
import shutil, fnmatch

root = Path('/Users/mac/work/github/<repo-slug>')
patterns = [
    '*.opt', '*.plg', '*.ncb', '*.positions', '*.aps', '*.suo',
    '*.obj', '*.sbr', '*.exe', '*.pdb', '*.idb', '*.pch', '*.ilk', '*.bsc',
    '*.res', '*.tlog', '*.lastbuildstate', 'BuildLog.htm',
    'Debug/', 'Release/', 'debug/', 'release/',
    # GP32 / ADS
    '*.fxe', '*.elf', '*.gxb',
    '*.lnk',
    # 기타
    '.DS_Store', 'ALZ*.TMP',
]
for f in list(root.rglob('*')):
    if not f.is_file(): continue
    for pat in patterns:
        if fnmatch.fnmatch(f.name, pat):
            f.unlink(); break
# 빈 Debug/Release 폴더도 정리
for d in sorted(root.rglob('*'), key=lambda p: -len(p.parts)):
    if d.is_dir() and not any(d.iterdir()) and d.name in {'Debug','Release','debug','release'}:
        try: d.rmdir()
        except OSError: pass
```

자세한 패턴은 `references/vc6-build-patterns.md`, `references/gp32-ads-exclusion.md` 참고.

### 3단계: .gitignore 작성

`templates/.gitignore`를 작업 사본 루트에 복사한 뒤, 프로젝트별 추가 항목(임시 파일, 스크립트 언어 캐시 등)만 덧붙인다. 표준 템플릿에는 다음이 포함된다.

- macOS: `.DS_Store`
- Visual C++ 6 / Visual Studio: `*.opt`, `*.plg`, `*.ncb`, `*.positions`, `*.aps`, `*.suo`, `Debug/`, `Release/`
- 빌드 산출물: `*.obj`, `*.sbr`, `*.exe`, `*.pdb`, `*.idb`, `*.pch`, `*.ilk`, `*.bsc`, `*.res`
- GP32: `*.fxe`, `*.elf`, `*.gxb`, `*.lnk`
- IDE: `.vs/`, `.vscode/`, `*.swp`, `*.bak`, `*.tmp`

### 4단계: README.md 작성 ("화려하고 자세하게")

표준 구조 (참고: `references/elaborate-readme-template.md`):

1. **타이틀** + shields.io 배지 4~5개 (platform / lang / graphics / input / license)
2. **목차** (10개 이상 항목, 앵커 링크)
3. **개요** — 게임 정체, 플랫폼, 엔진, 빌드 시점
4. **게임 화면 미리보기** — ASCII 다이어그램
5. **주요 특징 표** — 10개 이상 항목
6. **조작 / 커맨드 표** — 키 매핑 + 상태 머신 enum
7. **폴더 트리** — emoji 포함
8. **코드 모듈 표** — 각 모듈별 역할 + 라인 수
9. **시스템 아키텍처 다이어그램** — 게임 루프 + 클래스 계층 + 데이터 흐름
10. **캐릭터 / 적 / 보스** — 기획 메모(`0stage.txt` 등) 분석 결과 반영
11. **스테이지 / 사운드 / 그래픽** — 표 형식
12. **빌드 환경 / 빌드 방법** — VC6 / VS2005+ 두 가지
13. **알려진 한계** — 구 SDK, 한글 주석, 이름 오타, 전역 변수 등 7~8개
14. **라이선스** — MIT + 외부 SDK 원 소유자 명시
15. **원본 출처**

README는 가능하면 **15~25KB** 분량으로 작성한다. 짧으면 "화려하지 않게" 느껴진다.

#### 스크린샷 / 이미지 임베드 패턴

게임 화면, 매뉴얼 스크린샷, 기획 자료 이미지 등을 README에 넣고 싶으면:

```bash
# 작업 사본에 docs/ 폴더를 만들고 이미지 사본 복사
mkdir -p /Users/mac/work/github/<repo-slug>/docs
cp /Users/mac/work/backup/01-public/<Game>/<image>.jpg \
   /Users/mac/work/github/<repo-slug>/docs/<descriptive-name>.jpg
```

```markdown
<!-- README 안에서 -->
![화면 1](docs/screen-01.jpg)
![메뉴얼](docs/manual-page.jpg)
```

GitHub README는 `file://`, `http://localhost`, 절대경로 등을 렌더링하지 않는다. 반드시 **저장소 내 상대 경로 + 이미지를 git에 포함**시켜야 한다.

다른 시리즈/시제품 자료를史料로 첨부할 때(예: 2002년 첫 C++ 콘솔 게임 CS.htm의 스크린샷)는 README 본문에 "본 저장소와는 다른 프로젝트지만史料적 가치가 있어 첨부" 같은 출처를 명시한다. 사용자가 혼동하지 않도록.

### 5단계: LICENSE 작성

`templates/LICENSE` (MIT, sigco3111 저작권, 외부 SDK 제외 고지)를 작업 사본 루트에 복사한다.

### 6단계: git init / add / commit

```bash
cd /Users/mac/work/github/<repo-slug>
git init -q -b main
git config user.email "sigco3111@users.noreply.github.com"
git config user.name "sigco3111"
git add .
git commit -q -m "<Game> 공개 릴리스 (소스 + 리소스 + 매뉴얼)

- ... (모듈별 bullet)
- 공개: <포함된 것>
- 제외: <제외된 SDK, 빌드 산출물>"
```

### 7단계: gh repo create public + push + 검증

```bash
gh repo create <repo-slug> --public \
  --description "<Game> (<장르>) (비영리 개인 프로젝트, 공개)" \
  --source . --push
```

푸시 후 반드시 **GitHub API로 검증**한다.

```bash
# 1. 저장소 정보
gh repo view <repo-slug> --json name,visibility,url,defaultBranchRef,description

# 2. 루트 파일 목록
gh api repos/sigco3111/<repo-slug>/contents/ \
  | python3 -c "import sys,json; r=json.load(sys.stdin); print('루트 항목 수:', len(r)); [print(' ', e['type'], e['name']) for e in r]"

# 3. 최신 커밋
gh api repos/sigco3111/<repo-slug>/commits/main \
  | python3 -c "import sys,json; c=json.load(sys.stdin); print('커밋:', c['sha'][:7], c['commit']['message'].splitlines()[0])"

# 4. README 크기
gh api repos/sigco3111/<repo-slug>/readme \
  | python3 -c "import sys,json; r=json.load(sys.stdin); print('README size:', r['size'], 'bytes,', r['path'])"

# 5. 커밋 개수
gh api repos/sigco3111/<repo-slug>/commits \
  | python3 -c "import sys,json; cs=json.load(sys.stdin); print('커밋 수:', len(cs)); [print(' ', c['sha'][:7], '-', c['commit']['message'].splitlines()[0]) for c in cs]"
```

5가지 모두 정상으로 나와야 완료.

### 7.5단계: 푸시 후 추가 변경 사이클 (사용자 follow-up)

초기 푸시 후 사용자가 다음과 같은 follow-up을 자주 보낸다:

- "README 안 보임" → 비공개 저장소 UI 한계 → 코드 탭 README.md 직접 안내 (함정 1)
- "스크린샷 첨부해줘" + `file:///...` 경로 → 상대 경로 + `docs/` 복사 (함정 8)
- "다른 자료도 추가" → 작업 사본에 사본 추가 후 커밋 + push
- "이름 X로 바꿔줘" → README + 커밋 메시지 양쪽 갱신

```bash
cd /Users/mac/work/github/<repo-slug>

# 1. 작업 (파일 추가/수정)
# ...

# 2. 변경분 확인
git status --short

# 3. rebase 안전 (원격에 다른 커밋이 있을 수 있음 — 함정 7)
git fetch origin
GIT_EDITOR=true git pull --rebase origin main
# 충돌 시 수동 해결 + git add + GIT_EDITOR=true git rebase --continue

# 4. 커밋
git add .
git commit -q -m "<follow-up 설명>"

# 5. 푸시
git push origin main

# 6. 검증 (GitHub API 5가지)
# ... 7단계 검증 스크립트 재실행
```

## 비공개 vs 공개 결정 흐름

```
사용자가 "공개" 명시?
├─ Yes → 위 워크플로우 그대로 (--public)
└─ No  → clarify로 옵션 제시
        ├─ 1. 공개 (--public)
        ├─ 2. 비공개 (--private)
        ├─ 3. 로컬에만 (푸시 안 함)
        └─ 4. 멈춤
```

옵션 제시 시 **추천을 명시**한다 (사용자 선호: 추천 없는 옵션 나열은 1라운드 follow-up 낭비).

## 알려진 함정

### 1. "README가 안 보입니다" 사용자 보고

GitHub는 **비공개** 저장소에 대해 README 자동 미리보기 패널을 비워둔다. 업로드 실패가 아니다. 코드 탭 → README.md 직접 클릭 안내.

### 2. `gh repo create --public --push`가 silent fail

가끔 네트워크 일시 오류로 푸시가 안 되어도 exit code 0. 반드시 7단계의 5가지 검증으로 실제 푸시 확인.

### 3. `ads.zip` (ADS SDK), `*.fxe`/`*.elf`/`*.gxb` (GP32 빌드 산출물) 누락

이들은 절대 GitHub 공개에 포함되면 안 된다. `.gitignore`만으로 불충분 — 작업 사본에서 실제 파일을 **삭제**해야 한다.

### 4. README에 외부 SDK 빌드 재현 불가 명시

`ADS` / `DirectX SDK` / `GP32 SDK`는 공개 저장소에 포함하지 않으므로 README에 "본 저장소에는 빌드에 필요한 SDK가 포함되어 있지 않으며 별도 확보 필요"를 명시.

### 5. 매뉴얼 HTM이 EUC-KR 인코딩

2000년대 한국어 매뉴얼은 대부분 EUC-KR. UTF-8 변환 시 깨짐 가능. 원본 그대로 보존하고, README에서 "원본 인코딩 유지" 명시.

### 6. 큰 저장소(>400MB) 푸시 시 1차 시도 실패

`gh repo create --push`가 OOM/네트워크 오류로 실패할 수 있다. 재시도하기보다 `git push origin main`으로 분리해서 실행하면 안정적.

### 7. 푸시 직전 원격에 다른 커밋이 있는 경우 (rebase 충돌)

`gh repo create --push`로 첫 푸시가 끝난 뒤, **사용자가 GitHub 웹에서 README를 직접 편집**하는 일이 자주 있다. 그 상태에서 추가 커밋을 push하면 다음과 같이 거부된다.

```text
hint: Updates were rejected because the remote contains work that you do not
hint: have locally.
```

해결 패턴:

```bash
# 1. 원격 변경사항 가져오기
git fetch origin

# 2. rebase로 내 변경 위에 원격 변경을 얹기 (충돌 시 해결)
GIT_EDITOR=true git pull --rebase origin main
# 충돌 발생 시 <<<<<<< HEAD / ======= / >>>>>>> marker를 수동으로 정리한 뒤:
git add <fixed-files>
GIT_EDITOR=true git rebase --continue

# 3. 푸시
git push origin main
```

`GIT_EDITOR=true`는 rebase가 커밋 메시지 편집을 위해 vim/nano를 열려고 시도하면서 멈추는 것을 방지한다. 비대화형 환경에서는 필수.

### 8. README 이미지 임베드는 상대 경로 + 작업 사본에 이미지 파일 필요

사용자가 `file:///Users/mac/work/backup/...` 같은 **로컬 절대 경로**로 이미지를 첨부하라고 요청하는 경우가 있다. 그러나 GitHub README 마크다운 렌더러는 `file://` URI를 **렌더링하지 않는다** (CSP + 외부 차단).

해결: 이미지를 **작업 사본의 `docs/` 같은 폴더에 복사**한 뒤, README에서 상대 경로로 참조한다.

```bash
mkdir -p /Users/mac/work/github/<repo-slug>/docs
cp /Users/mac/work/backup/01-public/<Game>/some-image.jpg \
   /Users/mac/work/github/<repo-slug>/docs/<descriptive-name>.jpg
```

```markdown
<!-- README.md 안에서 -->
![설명](docs/<descriptive-name>.jpg)
```

이렇게 하면 `git add .` 시 이미지도 함께 커밋되고, GitHub에 푸시된 후 정상 렌더링된다. 원본 백업 폴더의 이미지는 손대지 않는다.

### 9. 시리즈 부록으로 다른 프로젝트 자료 첨부 시 명확한 구분

같은 개발자의 다른 콘솔/Windows 게임 시리즈(예: `Etc/CS.htm`, `Etc/BlueMB.htm`)를史料로 첨부할 때, **README 본문에서 "이 자료는 본 저장소와 다른 프로젝트"라는 점을 명시**해야 한다. 첨부하는 자료가 본 게임의 것이 아니라는 혼동을 주면 사용자가 다시 정정 요청을 보내게 된다.

## 작업 사본 디렉터리 규약

```text
/Users/mac/work/github/<repo-slug>/
```

`<repo-slug>`는 GitHub 저장소 슬러그와 동일. 예:

- `/Users/mac/work/backup/01-public/GP32/부루마블대왕/` → `/Users/mac/work/github/gp32-bluemarble-king/`
- `/Users/mac/work/backup/01-public/Win/DnB/` → `/Users/mac/work/github/dnb-action-rpg/`
- `/Users/mac/work/backup/01-public/Win/consol_shooting/` → `/Users/mac/work/github/win32-console-shooter/`

## 외부 SDK 라이선스 고지 패턴

공개 저장소 README의 라이선스 섹션에 다음을 명시한다.

```markdown
NOTE: This license covers the source code and game resources authored by the
copyright holder. <SDK 목록> are NOT included in this repository and remain
the property of their respective owners.
```

예:

- DirectX SDK → Microsoft
- ARM Developer Suite (ADS) → ARM
- GP32 SDK / GPMM / FxeMaker → GamePark
- Windows Multimedia (winmm) → Microsoft

## 참고 자료

- `references/vc6-build-patterns.md` — VC++ 6 빌드 산출물 정리 패턴 + 정리 Python 스크립트
- `references/gp32-ads-exclusion.md` — GP32 ADS SDK / 툴체인 제외 절차 + README SDK 고지 텍스트
- `references/elaborate-readme-template.md` — 화려한 README 템플릿 (15개 섹션, 15~25KB 분량 가이드)
- `templates/.gitignore` — 표준 .gitignore (VC++ 6 + GP32 + DirectX 통합)
- `templates/LICENSE` — MIT LICENSE (외부 SDK 제외 NOTE 포함)