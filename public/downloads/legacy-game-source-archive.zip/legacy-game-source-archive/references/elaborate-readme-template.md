# 화려한 README 템플릿 (15~25KB)

게임 백업 폴더를 GitHub 공개 저장소로 올릴 때 사용하는 표준 README 구조.

## 표준 구조

```markdown
# 🕹️ <게임명> — <부제>

> 한 줄 설명 (무엇을 위한 게임인지, 어떤 환경에서 동작하는지, 비영리 본인 코드임을 명시).

![platform](https://img.shields.io/badge/platform-Windows-0078d4?style=flat-square)
![lang](https://img.shields.io/badge/C%2B%2B-VC%2B%2B%206.0-00599c?style=flat-square)
![graphics](https://img.shields.io/badge/graphics-DirectDraw-red?style=flat-square)
![input](https://img.shields.io/badge/input-DirectInput-blue?style=flat-square)
![license](https://img.shields.io/badge/license-MIT-blue?style=flat-square)

---

## 📜 목차

- [개요](#-개요)
- [🎮 게임 컨셉](#-게임-컨셉)
- [🖼️ 게임 화면 미리보기](#️-게임-화면-미리보기)
- [✨ 주요 특징](#-주요-특징)
- [⌨️ 조작 / 커맨드](#️-조작--커맨드)
- [📂 폴더 구성](#-폴더-구성)
- [🧱 코드 모듈](#-코드-모듈)
- [🧬 시스템 아키텍처](#-시스템-아키텍처)
- [🎮 캐릭터 / 적](#-캐릭터--적)
- [🗺️ 스테이지](#️-스테이지)
- [🎨 그래픽 시스템](#-그래픽-시스템)
- [🎵 사운드 시스템](#-사운드-시스템)
- [⚙️ 빌드 환경](#️-빌드-환경)
- [🔨 빌드 방법](#-빌드-방법)
- [🐛 알려진 한계](#-알려진-한계)
- [📜 라이선스](#-라이선스)
- [📁 원본 출처](#-원본-출처)

---

## 개요

게임 정체 + 플랫폼 + 엔진 + 빌드 시점 + 기획 의도.

## 🎮 게임 컨셉

장르, 플랫폼, 엔진, 해상도, 스테이지 수, 보스 수 등 핵심 디자인 결정을 표로.

## 🖼️ 게임 화면 미리보기

```text
┌──────────────────────────────────────────────────┐
│ Game Play Area                UI                 │
│   🦸 Hero   Boss3                              │
│   ░░ Land                                       │
└──────────────────────────────────────────────────┘
```

ASCII 다이어그램은 실제 그래픽을 대신할 수 없지만 README의 시각적 분량에 크게 기여한다.

## ✨ 주요 특징

10개 이상 항목을 표로 정리. 각 항목은 1~2줄 설명.

## ⌨️ 조작 / 커맨드

키 매핑 표 + 상태 머신 enum (있으면).

## 📂 폴더 구성

emoji 포함 트리 구조:

```text
Game/
├── 📄 main.cpp
├── 📁 적 캐릭터
│   ├── 📄 Bear.cpp
│   └── 📄 Bat.cpp
└── 📁 Release/ (제외)
```

## 🧱 코드 모듈

각 모듈의 역할 + 라인 수 표.

## 🧬 시스템 아키텍처

게임 루프, 클래스 계층, 데이터 흐름 세 가지 다이어그램.

## 🎮 캐릭터 / 적

기획 메모(`0stage.txt`, `기획/`, `design/` 등)에서 발견한 캐릭터/적 정보를 코드와 매핑.

## 🗺️ 스테이지

맵/BGM 파일 매핑 표.

## 🎨 그래픽 시스템

DirectDraw / DIB / Color Key 등 사용한 그래픽 API 정리.

## 🎵 사운드 시스템

MCI MP3 / DirectSound 등 사운드 재생 방식.

## ⚙️ 빌드 환경

표 형식으로 정리.

## 🔨 빌드 방법

VC++ 6 + VS2005+ 두 가지 모두 안내.

## 🐛 알려진 한계

7~8개 항목. 예: 구형 SDK, 한글 주석 인코딩, 이름 오타, 전역 변수 사용, MP3 특허, EUC-KR 매뉴얼 등.

## 📜 라이선스

```markdown
MIT License

Copyright (c) sigco3111

<표준 MIT 본문>

NOTE: This license covers the source code and game resources authored by the
copyright holder. <SDK 목록> are NOT included in this repository and remain
the property of their respective owners.
```

## 📁 원본 출처

```markdown
이 저장소는 다음 경로의 사본입니다.

~/work/backup/01-public/<Game>/

원본 빌드 산출물(`Release/`, `*.sbr`, `*.obj`, `*.exe`, `*.pdb`, `*.idb`)과
Visual C++ 사용자 환경 파일(`*.opt`, `*.plg`, `*.ncb`, `*.positions`)은
공개 저장소에서 제외했습니다.
```

## 분량 가이드

| 항목 | 권장 크기 |
|---|---|
| 최소 | 8KB (간단한 게임) |
| 권장 | 15~25KB (대부분의 경우) |
| 최대 | 40KB (대형 RPG, 매뉴얼 포함) |

15KB 미만이면 "화려하지 않게" 느껴지므로, 위 구조를 모두 채우면 보통 15~25KB가 나온다.

## 작성 팁

1. **코드 발췌는 1~2개** — 클래스 헤더 + 게임 루프 정도만 발췌. 전체 코드는 발췌하지 않음
2. **상태 머신 enum은 거의 모든 게임에 있다** — 거의 항상 발견되는 핵심 정보
3. **기획 메모(`0stage.txt` 등)는 가장 중요한 정보원** — 코드만 봐서는 알 수 없는 캐릭터 의도·난이도·클리어 보상이 들어 있음
4. **알려진 한계 섹션은 절대 생략하지 말 것** — "구 SDK + 한글 주석 + 이름 오타"는 정직한 README의 핵심
5. **shields.io 배지는 4~5개** — 너무 많으면 산만해짐
6. **이모지는 의미 단위로 사용** — 🕹️(게임), ⚔️(액션), 📜(문서), 🧱(코드) 정도만