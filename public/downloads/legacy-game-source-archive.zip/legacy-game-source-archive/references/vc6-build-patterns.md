# VC++ 6 / Visual Studio 빌드 산출물 정리 패턴

VC++ 6 시점(1998~2003)의 Windows 게임 프로젝트에서 흔히 발견되는 빌드 산출물과 환경 파일 정리 패턴.

## 항상 제거해야 하는 파일

### Visual C++ 6 환경 파일

| 패턴 | 설명 |
|---|---|
| `*.opt` | VC++ 6 워크스페이스 옵션 (창 위치, 색상 테마) |
| `*.plg` | 빌드 로그 (HTML) |
| `*.ncb` | IntelliSense 데이터베이스 (수 MB~수십 MB) |
| `*.positions` | VC++ 6 작업 환경 정보 |
| `*.aps` | 리소스 미리보기 (바이너리) |
| `*.suo` | 사용자 솔루션 옵션 |

### 빌드 산출물

| 패턴 | 설명 |
|---|---|
| `Debug/` | 디버그 빌드 폴더 |
| `Release/` | 릴리스 빌드 폴더 |
| `*.obj` | 컴파일 중간 오브젝트 |
| `*.sbr` | 브라우저 데이터베이스 소스 |
| `*.exe` | 빌드된 실행 파일 (Releases로 분리 권장) |
| `*.pdb` | 프로그램 데이터베이스 (디버그 심볼) |
| `*.idb` | 증분 빌드 데이터베이스 |
| `*.ilk` | 증분 링커 파일 |
| `*.bsc` | 브라우저 정보 파일 |
| `*.pch` | 프리컴파일드 헤더 |
| `*.res` | 리소스 컴파일 출력 |
| `*.tlog` | MSBuild 추적 로그 |
| `BuildLog.htm` | VC++ 빌드 로그 HTML |

### Visual Studio 2005 이상

| 패턴 | 설명 |
|---|---|
| `*.user` | 사용자 프로젝트 옵션 |
| `*.userosscache` | 사용자 OSS 캐시 |
| `*.sdf` | SQL Server Compact 데이터베이스 (IntelliSense) |
| `*.opensdf` | SDF 잠금 파일 |
| `*.exp` / `*.lib` | 링커 출력 (배포 시 필요 없으면 제외) |

## 예외 (포함해야 하는 파일)

- `*.dsp`, `*.dsw` — VC++ 6 프로젝트 파일 (포함)
- `*.vcproj`, `*.sln` — VS2005+ 프로젝트 파일 (포함)
- `*.vbp`, `*.vbw` — VB6 프로젝트 파일 (포함)
- `*.aps` — 보통 제외지만, 리소스 정의를 보여주면 포함 검토
- `Debug/`, `Release/` 폴더 안의 `*.pdb` — 디버깅 심볼이 필요하면 Releases로 분리

## DirectDraw / DirectInput 추가 패턴

게임 프로젝트에서 자주 보이는 SDK 빌드 산출물도 함께 제거한다.

| 패턴 | 설명 |
|---|---|
| `*.dsw` (직접 만든 거) | VC++ 워크스페이스 |
| `ddraw.lib`, `dinput.lib` | SDK 라이브러리 (보통 시스템에 있음) |
| `ddraw.h`, `dinput.h` | SDK 헤더 (시스템 또는 Platform SDK) |

## Python 정리 스크립트

```python
from pathlib import Path
import fnmatch

# VC++ 6 환경 + 빌드 산출물 통합 패턴
PATTERNS = [
    # VC++ 6 환경
    '*.opt', '*.plg', '*.ncb', '*.positions', '*.aps', '*.suo',
    # VS2005+ 사용자 캐시
    '*.user', '*.userosscache', '*.sdf', '*.opensdf',
    # 빌드 출력
    '*.obj', '*.sbr', '*.exe', '*.pdb', '*.idb', '*.pch',
    '*.ilk', '*.bsc', '*.res', '*.tlog', '*.lastbuildstate',
    'BuildLog.htm',
    # 빌드 폴더
    'Debug/', 'Release/', 'debug/', 'release/',
    # 기타
    '.DS_Store', 'ALZ*.TMP',
]

def remove_build_artifacts(root: Path):
    for f in list(root.rglob('*')):
        if not f.is_file(): continue
        for pat in PATTERNS:
            if fnmatch.fnmatch(f.name, pat):
                f.unlink()
                break
    # 빈 빌드 폴더 정리
    for d in sorted(root.rglob('*'), key=lambda p: -len(p.parts)):
        if d.is_dir() and not any(d.iterdir()) and d.name in {'Debug','Release','debug','release'}:
            try: d.rmdir()
            except OSError: pass
```

## 검증 절차

제거 후 다음 명령으로 확인한다.

```bash
find <작업 사본> -name "*.opt" -o -name "*.ncb" -o -name "*.obj" -o -name "*.pdb" | wc -l
# → 0 이어야 함

find <작업 사본> -type d \( -name "Debug" -o -name "Release" \) | wc -l
# → 0 이어야 함
```

## 비고

- VC++ 6 프로젝트(`*.dsp`, `*.dsw`)는 VS2005 이상에서 직접 열리지 않으므로, GitHub Actions에서 빌드하려면 GitHub Actions에 VC++ 6 빌드 환경을 별도로 구성해야 한다.
- 보통의 경우 비공개 저장소도 README에 "빌드하려면 VC++ 6 + DirectX SDK 필요"라고 명시하고 빌드 검증은 생략한다.