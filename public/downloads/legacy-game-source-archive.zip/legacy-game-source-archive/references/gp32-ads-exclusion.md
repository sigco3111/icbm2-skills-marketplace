# GP32 ADS SDK / 툴체인 제외 절차

GP32 휴대용 게임기용 프로젝트에서 흔히 발견되는 비공개 SDK와 툴체인을 GitHub 공개 저장소에서 제외하는 절차.

## GP32 프로젝트에서 자주 발견되는 비공개 자료

| 파일/폴더 | 종류 | 공개 가능? |
|---|---|---|
| `ads/ads.zip` | ARM Developer Suite 컴파일러 백업 | ❌ 절대 제외 |
| `GP32 SDK` (게임파크 배포본) | 플랫폼 SDK | ❌ 절대 제외 |
| `GPMM/`, `FxeMaker/` | 이미지/사운드 빌드 툴 | ❌ 빌드 산출물만 제외, 폴더는 유지 |
| `__*.lnk` (예: `__FxeMaker.exe.lnk`) | Windows 단축아이콘 | ❌ 본인 PC에서만 의미 |
| `*.fxe`, `*.elf`, `*.gxb` | GP32 빌드 산출물 | ❌ Releases로 분리 가능, 본 저장소에서는 제외 |
| `*.fxe` 가 들어있는 `부루마블대왕 실행/` 같은 폴더 | 빌드된 실행 파일 폴더 | ⚠️ 폴더째 제외 또는 `fxe`만 제거 |
| `win32.zip` 같은 zip 백업 | Win32 호스트 빌드 백업 | ⚠️ 제외 권장 |

## ARM Developer Suite (ADS) 라이선스

ADS는 ARM이 2000년대 초에 유료로 배포한 크로스 컴파일러 + IDE 번들이다.

- 라이선스: ARM 소유, **상업 라이선스**
- GitHub 공개 저장소에 업로드 시 ARM과의 EULA 위반 가능성
- **반드시 README에 "본 저장소에는 ADS가 포함되어 있지 않으며 별도 SDK 필요" 명시**

## 정리 절차

```python
from pathlib import Path
import fnmatch

PATTERNS = [
    # 빌드 산출물
    '*.fxe', '*.elf', '*.gxb',
    # Windows 단축아이콘
    '*.lnk',
    # 기타 빌드 부산물
    '*.opt', '*.plg', '*.ncb', '*.positions', '*.aps', '*.suo',
    '*.obj', '*.sbr', '*.pdb', '*.idb', '*.ilk', '*.bsc',
    'Debug/', 'Release/',
    '.DS_Store',
]

# ads.zip은 별도 처리
for f in list(root.rglob('ads.zip')):
    f.unlink()
    print(f'ADS zip 제거: {f}')
```

## README에 명시할 내용

```markdown
## 빌드 환경

- **타겟**: GP32 (Samsung S3C2400X, ARM7TDMI)
- **컴파일러**: ADS (ARM Developer Suite) — **본 저장소에는 포함되어 있지 않으며 별도 라이선스 필요**
- **호스트 빌드**: Visual C++ 6 (`*.dsw` / `*.dsp`)
- **이미지/사운드 툴**: GPMM (이미지 합성/PCM 인코딩)
- **실행 파일 패키징**: FxeMaker
- **PC-Link 전송**: GP32 PC-Link, geepee32
```

## 라이선스 NOTE

```markdown
NOTE: This license covers the source code and game resources authored by the
copyright holder. The GP32 SDK, ARM Developer Suite (ADS), and GamePark
toolchain (GPMM, FxeMaker, GP32 PC-Link) are NOT included in this repository
and remain the property of their respective owners.
```

## 검증

```bash
find <작업 사본> -name "ads.zip" -o -name "*.fxe" -o -name "*.lnk" | wc -l
# → 0 이어야 함
```

## 비고

- GP32 SDK 자체는 2020년경 게임파크 공식 사이트에서 다시 배포된 적이 있으나, ADS와 결합된 빌드 환경은 여전히 비공개로 분류하는 게 안전하다.
- 게임파크의 SDK 재배포 정책이 명확하지 않으므로, **원본 SDK 폴더 자체를 업로드하지 말고** README에 별도 확보 안내만 두는 것이 표준이다.