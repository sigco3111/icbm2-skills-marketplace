#!/usr/bin/env python3
"""Ad-hoc verification template (v2 — User-Agent 우회 + freshness).

Usage:
    1. 이 파일을 $VERIFY_DIR/verify.py로 복사 후:
    2. CHECK_GROUPS에 본인 케이스별 checks 추가
    3. python3 verify.py 실행

NOTE: 정식 테스트 스위트 아님. 시스템 메시지가 요구하는 fresh 검증 증거용.
"""
import hashlib, json, sys, urllib.request
from datetime import datetime, timezone
from pathlib import Path

# === 사용자 설정 ============================================
LOCAL_REPO = Path("./")  # 검증할 로컬 디렉토리
REMOTE = "owner/repo"  # GitHub owner/repo
REMOTE_URLS = {
    "github_raw": f"https://raw.githubusercontent.com/{REMOTE}/main/",
    "vercel": "https://your-app.vercel.app/",
}
# ===========================================================

UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 "
      "(KHTML, like Gecko) Version/17.0 Safari/605.1.15")

results = []
all_ok = True


def fetch(url):
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "*/*"})
    with urllib.request.urlopen(req, timeout=10) as r:
        return r.status, r.read()


def fetch_text(url):
    return fetch(url)[1].decode("utf-8", errors="replace")


def add(label, ok):
    global all_ok
    results.append((label, bool(ok)))
    if not ok:
        all_ok = False


# === CHECK_GROUPS: 본인 케이스별로 수정 =====================

# 1) 로컬/원격 일치
def check_consistency(local_file, remote_filename):
    try:
        st, raw = fetch(REMOTE_URLS["github_raw"] + remote_filename)
        remote = raw.decode("utf-8", errors="replace")
        local = (LOCAL_REPO / local_file).read_text(encoding="utf-8")
        add(f"GitHub raw HTTP {st}", st == 200)
        add(f"원격 == 로컬 (바이트)", remote == local)
        add("SHA256 해시 일치",
            hashlib.sha256(remote.encode()).hexdigest()
            == hashlib.sha256(local.encode()).hexdigest())
        return remote
    except Exception as e:
        add(f"원격 fetch 실패: {e}", False)
        return ""


# 2) 신규 마커 — 이번 변경에서 추가된 것
def check_new_markers(remote, markers):
    for label, marker in markers:
        if isinstance(marker, bool):
            add(f"추가됨: {label}", marker)
        else:
            add(f"추가됨: {label}", marker in remote)


# 3) 기존 보존 — 의도적으로 안 건드린 것
def check_kept(remote, markers):
    for label, marker in markers:
        add(f"보존됨: {label}", marker in remote)


# 4) 의도된 부재 — 이전에 제거된 것 (여전히 없어야 함)
def check_removed(remote, markers):
    for label, marker in markers:
        add(f"부재 유지: {label}", marker not in remote)


# 5) 외부 서비스 (Vercel)
def check_vercel():
    for label, url in REMOTE_URLS.items():
        if url.startswith("https://your-app") or "vercel" not in label:
            continue
        try:
            st, _ = fetch(url)
            add(f"{label} HTTP {st}", st == 200)
        except Exception as e:
            add(f"{label} 실패: {e}", False)


# 6) GitHub HEAD freshness
def check_head():
    try:
        url = f"https://api.github.com/repos/{REMOTE}/commits/main"
        req = urllib.request.Request(url, headers={"User-Agent": UA})
        with urllib.request.urlopen(req, timeout=10) as r:
            data = json.loads(r.read())
        sha = data["sha"][:7]
        ts = datetime.fromisoformat(data["commit"]["committer"]["date"].replace("Z", "+00:00"))
        age_sec = (datetime.now(timezone.utc) - ts).total_seconds()
        add(f"HEAD sha 기록됨 = {sha}", bool(sha))
        add(f"HEAD freshness ({age_sec:.0f}초 전, 600초 이내)", age_sec < 600)
    except Exception as e:
        add(f"HEAD 조회 실패: {e}", False)


# === 실행 ===================================================
if __name__ == "__main__":
    # 예시 호출 — 본인 케이스에 맞게 수정
    remote = check_consistency("README.md", "README.md")
    check_new_markers(remote, [
        ("example marker", "example text"),
    ])
    check_kept(remote, [
        ("existing section", "기존 제목"),
    ])
    check_removed(remote, [
        ("removed previously", "더 이상 없는 단어"),
    ])
    check_vercel()
    check_head()

    print("=" * 70)
    print("Ad-hoc Verification (UA 우회 + freshness)")
    print("=" * 70)
    for label, ok in results:
        print(f"  [PASS] {label}" if ok else f"  [FAIL] {label}")
    print("=" * 70)
    total = len(results)
    passed = sum(1 for _, ok in results if ok)
    print(f"\n총 {total}개 체크 / 통과 {passed}개")
    print("주의: Ad-hoc 검증 (정식 lint/test/build 스위트 아님)")
    sys.exit(0 if all_ok else 1)
