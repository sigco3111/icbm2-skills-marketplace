# GitHub UI HTML 직접 Cross-Check (2026-06-29 정립)

raw.githubusercontent.com 캐시와 GitHub UI 렌더링은 **다른 시스템**임이 이번 세션에서 결정적으로 입증됨. raw가 옛 버전을 반환하는 동안에도 GitHub UI는 새 버전을 보여주고 있었음. **raw만 확인하고 "됐다"고 보고하면 사용자가 보는 화면과 불일치 가능.**

## 🚨 핵심 원칙

> **raw fetch가 옛 버전이어도 GitHub contents API가 새 버전이면 사용자에게는 영향 없음** — UI는 contents API를 직접 렌더링하지 raw를 안 봄. 따라서 raw 캐시 지연은 사용자 화면에 영향 없음.

> **사용자가 "안 보인다"고 부정했을 때 raw가 옛 버전이라 부정한다고 단정하지 말 것** — GitHub UI HTML을 직접 fetch해서 사용자가 보는 마크업이 박혀있는지 grep해야 함.

## 📋 트리거 시나리오

- raw fetch가 옛 버전 반환 (`x-cache: HIT` + 옛 etag)인데 사용자에게 보고
- 사용자가 "푸시 됐다고 했는데 내 화면에 안 보여"라고 부정
- README에 헤더 안에 링크를 박았고 그게 GitHub 마크다운 렌더러에서 어떻게 보이는지 확인하고 싶음
- 로컬 raw 텍스트에 `<h2><a>...</a></h2>` 같은 마크업이 박혀있는지 끝까지 입증하고 싶음

## 🔍 3중 Cross-Check 패턴

### 1단계: GitHub contents API (가장 결정적)

```bash
curl -s -H "User-Agent: Mozilla/5.0" \
  "https://api.github.com/repos/{owner}/{repo}/contents/README.md?ref=main" \
  -o api.json

# base64 디코드
python3 -c "
import json, base64
data = json.load(open('api.json'))
content = base64.b64decode(data['content']).decode('utf-8')
open('api-decoded.md', 'w').write(content)
print('api sha:', data['sha'])
print('api size:', data['size'])
"
```

- **장점**: raw보다 빨리 갱신됨 (보통 푸시 후 1~2초)
- **용도**: 진짜 main 브랜치 본문 + 로컬 SHA256 비교

### 2단계: GitHub UI HTML 직접 fetch

```bash
curl -s -H "User-Agent: Mozilla/5.0" \
  "https://github.com/{owner}/{repo}" -o gh.html
```

GitHub UI HTML은 일반적으로 다음 두 곳에 핵심 마크다운 렌더링이 박힘:

**(A) React-embedded JSON 데이터** (`<script type="application/json" data-target="react-app.embeddedData">...</script>` 안의 `overviewFiles[].richText`):

```json
"richText":"\u003cdiv class=\"markdown-heading\" dir=\"auto\"\u003e
\u003ch2 tabindex=\"-1\" class=\"heading-element\" dir=\"auto\"\u003e
🎬 \u003ca href=\"https://retro-synthwave-shooter.vercel.app/\" rel=\"nofollow\"\u003e
\u003cstrong\u003e라이브 데모 (Live Demo) — 지금 플레이\u003c/strong\u003e
\u003c/a\u003e\u003c/h2\u003e..."
```

- **escaped**: `\u003c` = `<`, `\u003e` = `>`, `\u0026amp;` = `&`
- **헤더 안 링크, 굵은 텍스트 모두 포함**

**(B) TOC (`headerInfo.toc[]` 배열)**:

```json
"toc":[{"level":1,"text":"🚀 Retro Synthwave Shooter — 80s Arcade Shmup","anchor":"..."},
       {"level":2,"text":"🎬 라이브 데모 (Live Demo) — 지금 플레이","anchor":"..."}]
```

- 헤더 텍스트가 plain string으로 노출 → grep으로 헤더 박힘 확인 가능

### 3단계: escaped decode + 패턴 grep

```python
import re
h = open('gh.html').read()
# escape decode
d = (h.replace('\\u003c', '<')
       .replace('\\u003e', '>')
       .replace('\\"', '"')
       .replace('&quot;', '"')
       .replace('&amp;', '&'))

# 패턴들
patterns = {
    'h2 안에 굵은 링크 (헤더 자체가 링크)':
        r'<h2[^>]*>\s*🎬\s*<a[^>]*vercel\.app[^>]*>\s*<strong>[^<]*지금 플레이[^<]*</strong>',
    '본문 굵은 링크 (➡️ 지금 플레이)':
        r'<p[^>]*>\s*<a[^>]*vercel\.app[^>]*>\s*<strong>[^<]*➡️ 지금 플레이[^<]*</strong>',
    'TOC 텍스트 (헤더 노출)':
        r'라이브 데모 \(Live Demo\) — 지금 플레이',
    '뱃지 5개 vercel.app 가리킴':
        r'\[!\[Live Demo\]\([^)]+\)\]\(https://retro-synthwave-shooter\.vercel\.app/',
}
for name, pat in patterns.items():
    print(f'{"YES" if re.search(pat, d) else "NO"}  {name}')
```

**모든 패턴이 YES면 "사용자 화면에 헤더 + 본문 링크 + 뱃지 모두 노출" 입증 완료.**

## 🔥 자주 발생하는 함정

### 1. raw 캐시 HIT은 정상

```bash
$ curl -sI https://raw.githubusercontent.com/owner/repo/main/README.md
etag: "f5965776ecaa162c9df7dc1d67aebd40a76d5eee7674c24af90e384da430e43c"
x-cache: HIT
x-cache-hits: 1
content-length: 7804  ← 옛 버전
```

- 이건 **raw CDN 캐시**. GitHub UI는 raw를 안 봄 → 사용자에게 영향 없음
- cache-bust `?nocache=$(date +%s)` 쿼리스트링도 raw가 무시함
- **5분~110초 후 자동 갱신**, 강제 갱신 트릭은 없음

### 2. GitHub UI HTML escape 패턴은 2가지

- **`\u003c` / `\u003e`** (대부분의 React-embedded JSON)
- **`<` / `>`** (일부 다른 마크업)

**둘 다 디코드해야 grep이 잡음.**

### 3. 사용자 브라우저 캐시 vs 서버 캐시

- 사용자 브라우저도 GitHub UI 캐시 가질 수 있음 → `Cmd+Shift+R` 강제 새로고침 권장
- 서버측 캐시 = 1단계에서 다룸. 사용자측 캐시는 사용자 책임.

### 4. 정규식 escape 함정

```python
# 이건 Python f-string에서 syntax error:
print(f'{"ok" if re.search(r"\[.+", content) else "no"}')  # OK
print(f'{"ok" if re.search(r"\[.+vercel\.app", content) else "no"}')  # OK
# but:
print(f'{"ok" if re.search(r"\[.+vercel\.app\]", content) else "no"}')  # OK (괄호 매칭)
# 위험: 큰 정규식 안에 backslash 섞으면 f-string 거부
```

**해결**: 정규식을 별도 변수로 빼고 f-string 밖에서 매칭:

```python
pat = r"\[[^]]*?지금 플레이[^]]*?\]\([^)]+vercel\.app[^)]*\)"
matched = bool(re.search(pat, content))
print(f'PATTERN [{"OK" if matched else "NO"}]  지금 플레이 링크')
```

### 5. validation 차원의 FAIL = 스크립트 한계 vs 실제 문제

검증 결과에서 FAIL이 나왔을 때:

| FAIL 패턴 | 실제 상태 |
|---|---|
| 헤더 정규식 NO (`\[` escape 실수) | 헤더 11번 라인 직접 출력으로 확인 가능 |
| UI 본문 regex NO (이스케이프 이슈) | UI의 toc_text=yes와 위 h2 링크=yes로 연쇄 입증 가능 |
| 뱃지 alt 2회 (이상한 매칭) | HTML 파싱 quirk. 정상 1개 |
| working tree dirty | 검증 스크립트 부산물. `rm -f` 후 재확인 |

**결정적 판별법**: 직접 print한 본문에 박혀있으면 실제는 OK.

## 📜 보고서 템플릿

```markdown
## ✅ v3 검증 결과 (사용자 가시 화면 입증)

| 차원 | 결과 |
|---|---|
| 로컬 SHA256 vs API 디코드 SHA256 (bit-perfect) | `a00f7ad7... == a00f7ad7...` ✓ |
| GitHub UI HTML grep `<h2><a><strong>...지금 플레이</strong></a></h2>` | ✓ |
| GitHub UI HTML grep `<p><a><strong>➡️ 지금 플레이...</strong></a></p>` | ✓ |
| TOC 텍스트 "라이브 데모 (Live Demo) — 지금 플레이" 노출 | ✓ |
| raw CDN 캐시 갱신 지연 (5분+) | ⓘ 정보성 — UI/API는 이미 새 버전 |
```

## 📅 실전 검증 이력

- 2026-06-29 15:xx: retro-synthwave-shooter README 라이브 데모 링크. raw가 옛 버전 반환했지만 GitHub UI HTML grep에서 `<h2><a><strong>...</strong></a></h2>` 박힘 확인. 사용자 시각 부정 → v3 검증으로 해결.
- 2026-06-29 (이전): 3개 README 동일 링크 추가 — raw fetch로 다중 저장소 일치 확인. UI HTML cross-check은 불필요했음 (사용자 부정 없었으므로).