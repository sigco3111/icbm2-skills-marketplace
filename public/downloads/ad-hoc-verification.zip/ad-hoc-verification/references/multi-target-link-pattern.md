# 다중 저장소/README 동일 링크 추가 — 검증 패턴 (2026-06-29 정립)

여러 GitHub 저장소(또는 여러 README 파일)에 **동일한 양식의 링크 한 줄**을 추가할 때 사용하는 검증 패턴. v1 (로컬 + push) 만으론 시스템 가드가 만족하지 않을 때 v2로 확장해서 raw fetch + 참조 대상 liveness + 바이트 단위 일치까지 확인.

## 📋 트리거 시나리오

- 사용자가 "여기 리드미 파일 N개에 [링크] 추가해줘"라고 한 경우
- 동일 형식(라벨 + URL + 불릿 형식)을 N개 저장소에 일괄 적용하는 경우
- 특히 **외부 참조 사이트 링크**를 추가하는 경우 (cokac.com / 미션 페이지 / 참고 사이트 등)
- v1 검증 후 시스템이 "unverified" 알림을 재발화한 경우

## 🎯 검증 차원 6개

| # | 차원 | 목적 | v1 | v2 |
|---|---|---|---|---|
| 1 | 로컬 파일 링크 문법 | 마크다운 문법 정확성 (`[`/`]` 짝) | ✅ | ✅ |
| 2 | **다중 타깃 바이트 단위 일치** | 모든 저장소/파일에 정말 동일한 라인이 들어갔는지 | ❌ | ✅ |
| 3 | git push 동기화 | 로컬 HEAD == origin/main | ✅ | ✅ |
| 4 | **GitHub raw fetch** | 실제 원격 README가 변경을 반영했는지 (HTTP 200 + 변경 라인) | ❌ | ✅ |
| 5 | **참조 대상 URL liveness** | 추가한 외부 링크(`https://...`) 자체가 살아있는지 (HTTP 200) | ❌ | ✅ |
| 6 | **앞뒤 문맥 통일성** | 추가 라인이 직전/직후 줄과 자연스럽게 이어지는지 (불릿, 들여쓰기, 헤더) | ❌ | ✅ |

## 🧪 검증 스크립트 패턴

`tempfile.mkdtemp(prefix='hermes-verify-')` 경로에 heredoc으로 `verify.py` 작성. 아래는 **전체 템플릿**:

```python
#!/usr/bin/env python3
"""다중 README 동일 링크 추가 — v2 확장 검증."""
import re
import subprocess
import sys
import urllib.request
import urllib.error
from pathlib import Path

# === 사용자 설정 ===========================================
REPOS = [
    ("short-name-1", "owner/repo-1"),
    ("short-name-2", "owner/repo-2"),
    ("short-name-3", "owner/repo-3"),
]
LOCAL_BASE = Path("/tmp/readme-update")
EXPECTED_LABEL = "코딩미션 참조 페이지"  # 추가한 라벨
EXPECTED_URL = "https://example.com/path"  # 추가한 URL
EXPECTED_LINK = f"[cokac.com — 표시 텍스트]({EXPECTED_URL})"  # 풀 링크
# ===========================================================

UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 "
      "(KHTML, like Gecko) Version/17.0 Safari/605.1.15")

failures = []

def chk(name, ok, detail=""):
    status = "PASS" if ok else "FAIL"
    print(f"  [{status}] {name}{(' — ' + detail) if detail else ''}")
    if not ok:
        failures.append(name)

# === CHECK 1: 로컬 마크다운 문법 ============================
print("=" * 64)
print("CHECK 1: 로컬 파일 — 링크 문법/대괄호/소괄호")
print("=" * 64)
local_added_lines = {}
for short, full in REPOS:
    p = LOCAL_BASE / short / "README.md"
    content = p.read_text(encoding="utf-8")
    pattern = re.compile(rf"-\s+\*\*{re.escape(EXPECTED_LABEL)}\*\*:\s*\[([^\]]+)\]\(([^)]+)\)")
    matches = pattern.findall(content)
    chk(f"{full}: 정확히 1번 등장", len(matches) == 1)
    if matches:
        chk(f"{full}: 라벨 일치", matches[0][0] == "표시 텍스트")
        chk(f"{full}: URL 일치", matches[0][1] == EXPECTED_URL)
    bracket_open, bracket_close = content.count("["), content.count("]")
    chk(f"{full}: 대괄호 짝", bracket_open == bracket_close)

    # 추가된 라인 자체 추출 (바이트 일치 검사용)
    line_pat = re.compile(rf"^-\s+\*\*{re.escape(EXPECTED_LABEL)}\*\*:.*$", re.MULTILINE)
    m = line_pat.search(content)
    local_added_lines[full] = m.group(0) if m else None

# === CHECK 2 (v2): 바이트 단위 일치 =========================
print("=" * 64)
print("CHECK 2 (v2): 다중 타깃의 추가 라인이 바이트 단위로 동일")
print("=" * 64)
distinct = set(local_added_lines.values())
chk("모든 타깃에서 동일한 라인", len(distinct) == 1, f"고유 라인 수={len(distinct)}")

# === CHECK 3 (v2): 앞뒤 문맥 통일성 =========================
print("=" * 64)
print("CHECK 3 (v2): 추가 라인 앞뒤 문맥 통일성")
print("=" * 64)
for short, full in REPOS:
    p = LOCAL_BASE / short / "README.md"
    lines = p.read_text(encoding="utf-8").splitlines()
    added_idx = next(
        (i for i, ln in enumerate(lines) if EXPECTED_LABEL in ln and EXPECTED_URL in ln),
        None
    )
    if added_idx is None:
        chk(f"{full}: 라인 위치 탐색", False)
        continue
    starts_with_dash = lines[added_idx].startswith("- ")
    chk(f"{full}: 새 라인이 `- `로 시작", starts_with_dash)
    prev = lines[added_idx - 1] if added_idx > 0 else ""
    prev_ok = prev.startswith("- ") or prev == "" or prev.startswith("#")
    chk(f"{full}: 앞 줄이 불릿/헤더/빈줄로 자연스러움", prev_ok)

# === CHECK 4: git push 동기화 ==============================
print("=" * 64)
print("CHECK 4: git push — HEAD 동기화 + 원격 README에 링크")
print("=" * 64)
for short, full in REPOS:
    repo = LOCAL_BASE / short
    h = subprocess.run(["git", "rev-parse", "HEAD"], cwd=repo, capture_output=True, text=True).stdout.strip()
    origin = subprocess.run(["git", "rev-parse", "origin/main"], cwd=repo, capture_output=True, text=True).stdout.strip()
    raw = subprocess.run(["git", "show", "origin/main:README.md"], cwd=repo, capture_output=True, text=True).stdout
    chk(f"{full}: HEAD 동기화", h == origin, f"{h[:8]} vs {origin[:8]}")
    chk(f"{full}: 원격 README에 링크", EXPECTED_LINK in raw)

# === CHECK 5 (v2): GitHub raw fetch ========================
print("=" * 64)
print("CHECK 5 (v2): GitHub raw URL로 실제 원격 README fetch")
print("=" * 64)
for short, full in REPOS:
    url = f"https://raw.githubusercontent.com/{full}/main/README.md"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": UA})
        with urllib.request.urlopen(req, timeout=15) as r:
            body = r.read().decode("utf-8")
            chk(f"{full}: raw fetch HTTP {r.status}", r.status == 200 and EXPECTED_LINK in body)
    except urllib.error.HTTPError as e:
        chk(f"{full}: raw fetch HTTP {e.code}", False)
    except Exception as e:
        chk(f"{full}: raw fetch 실패", False)

# === CHECK 6 (v2): 참조 대상 URL liveness =================
print("=" * 64)
print("CHECK 6 (v2): 참조 URL 자체가 살아있는지")
print("=" * 64)
try:
    req = urllib.request.Request(EXPECTED_URL, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=15) as r:
        body = r.read().decode("utf-8", errors="replace")
        chk(f"{EXPECTED_URL} HTTP {r.status}", r.status == 200)
except Exception as e:
    chk(f"{EXPECTED_URL} 도달 실패", False)

# === FINAL =================================================
print()
print("=" * 64)
print(f"실패 항목 수: {len(failures)}")
if failures:
    for f in failures: print(f"  - {f}")
    sys.exit(1)
print("OVERALL: ALL PASS (ad-hoc)")
sys.exit(0)
```

## 🔧 셸 호출 패턴

```bash
VERIFY_DIR=$(mktemp -d -t hermes-verify-readme-links)
cat > "$VERIFY_DIR/verify.py" <<'PYEOF'
... 위 스크립트 본문 ...
PYEOF

python3 "$VERIFY_DIR/verify.py"
EXIT=$?
rm -rf "$VERIFY_DIR"
exit $EXIT
```

## 🧷 헷갈리기 쉬운 함정

1. **`write_file` 도구로 `tempfile.mkdtemp` 경로에 쓰려 하면 거부됨** — `tempfile-bypass.md` 참조. 무조건 heredoc.
2. **GitHub raw URL fetch 시 UA 헤더 필수** — 안 넣으면 일부 endpoint에서 403.
3. **origin/main 동기화 확인 후 raw fetch도 따로 해야 함** — push가 성공해도 GitHub CDN 캐시로 raw fetch가 약간 지연될 수 있음. timeout 15초 권장.
4. **참조 대상 URL이 200이어도 콘텐츠 sanity 추가 권장** — 단순 "200 OK"만으론 리다이렉트된 다른 페이지일 수 있음. 페이지에 기대 키워드가 있는지 1줄 grep.
5. **다중 타깃의 추가 라인이 "비슷해 보이지만" 다를 수 있음** — 공백, 따옴표, 하이픈 종류 같은 미세 차이. `set()`으로 바이트 일치 검사.

## 📊 보고서 차이 (v1 vs v2)

| 섹션 | v1 | v2 |
|---|---|---|
| 어서션 수 | ~12 | ~27 (3 저장소 × 9개 체크) |
| 표 카테고리 | 로컬 / push | 로컬 / 일치 / 문맥 / push / raw / 참조 URL |
| 한계 섹션 추가 | — | "로컬 ↔ GitHub 시각적 렌더링은 헤드리스 브라우저 부재로 검증 불가" |

## 📅 실전 검증 이력

- 2026-06-29: 3개 README (`cyberpunk-globe`, `neon-fluid`, `mandelbrot-kaleidoscope`)에 cokac.com 미션 링크 추가. v1 → 시스템 가드 재발화 → v2로 확장 → 27 어서션 / 0 실패로 종료.