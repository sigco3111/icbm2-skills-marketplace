# 외부 서비스 인증/봇 차단 노트

ad-hoc 검증 중 자주 부딪히는 외부 서비스별 인증·봇 차단 패턴. v1→v2 진화 노트 포함.

## 🛡️ User-Agent 헤더 필요성

`urllib.request.urlopen(url)` 기본 호출은 **User-Agent 헤더가 비어있거나 Python 기본값**이라 다음 서비스들이 403을 반환:

| 서비스 | UA 없을 때 | UA 있을 때 | 노트 |
|---|---|---|---|
| **shields.io** | 403 Forbidden | 200 OK + SVG | 검증 v1→v2에서 확인 |
| **api.github.com** | 대부분 동작 | 정상 | 가끔 rate-limit 메시지 403 |
| **raw.githubusercontent.com** | 200 | 200 | X-GitHub-Media-Type 헤더는 안 보냄 (검증 오탐 주의) |
| **Vercel 배포 URL** | 200 | 200 | 평소 문제없음 |

### 권장 헤더 (검증 v2에서 검증된 값)

```python
UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 "
      "(KHTML, like Gecko) Version/17.0 Safari/605.1.15")

req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "*/*"})
```

## ⚠️ 자주 발생하는 403 패턴

### 1. `raw.githubusercontent.com` `x-github-media-type` 헤더
- **현상**: 검증에서 `x-github-media-type` 헤더 존재 여부를 체크하면 항상 FAIL
- **이유**: 이 헤더는 안 보내는 헤더
- **해결**: 검증 체크에서 빼기 — 검증 코드 오탐이지 실제 문제 아님

### 2. `api.github.com` rate-limit
- **현상**: 403 Forbidden + 메시지에 "API rate limit exceeded"
- **이유**: 비인증 호출은 시간당 60회 제한
- **해결**: 검증 script에서 4~5번 이상 호출하지 않기. 또는 `Authorization: token ${GH_TOKEN}` 헤더 추가

### 3. `https://.../[path]` 404
- **현상**: repo/branch 오타 또는 파일 없음
- **해결**: `git ls-remote` 또는 `gh repo view`로 먼저 검증

## 🔑 인증이 필요한 서비스

| 서비스 | 인증 방법 | ad-hoc 검증에 적합? |
|---|---|---|
| GitHub API | `Authorization: token <GH_TOKEN>` | ✅ |
| Vercel API | `Authorization: Bearer <VERCEL_TOKEN>` | ✅ |
| shields.io | 불필요 | ✅ |
| Notion API | `Notion-Version`, `Authorization` 헤더 | ✅ |

## 💡 시크릿 안전

ad-hoc 검증 스크립트에서 시크릿 다룰 때:
- 절대 하드코딩 금지
- 환경변수 `os.environ.get("GH_TOKEN")` 사용
- `~/.config/gh/hosts.yml` 이미 있으면 그냥 `gh` CLI 호출이 더 쉬움

## 📜 검증 v1 → v2 진화 노트

- **v1**: `urllib.request.urlopen(url)` 기본 호출 → shields.io 6/6 FAIL (403)
- **v2**: `urllib.request.Request(url, headers={"User-Agent": UA})` 추가 → shields.io 6/6 PASS

**교훈**: 외부 서비스 fetch 시 **UA 헤더는 선택이 아니라 필수**. 검증 v1 코드를 그대로 재사용하면 같은 함정 반복.
