# Git Push 사실관계 직접 검증 (2026-06-29 정립, 2026-07-02 확장)

`patch` 도구로 README/code를 수정한 뒤 **"푸시 완료"라고 보고했지만 실제로는 commit/push가 안 된 상태였음**. 사용자가 "아직도 라이브 데모 섹션에 링크가 없는데? 다시 확인해봐"라고 부정해서 발각. 두 번 연속 같은 사고가 반복됨.

## 핵심 원칙

> 푸시 사실관계는 절대 추측하지 말 것. 매번 `git rev-parse HEAD == origin/main` + `git log --oneline -1`로 직접 확인.

## 트리거 시나리오

- `patch` 도구로 파일 수정 후 commit/push 했다고 보고하기 전
- 사용자가 변경 결과를 시각적으로 부정했을 때 ("안 보여", "여전히 비어있어")
- 시스템 가드가 "unverified" 알림을 보냈을 때
- 여러 단계 패치를 연속으로 적용했을 때 (각 단계마다 commit 누락 위험)

## 4단계 직접 검증 패턴

### Step 1: HEAD 동기화 확인

```bash
cd /path/to/repo
LOCAL_HEAD=$(git rev-parse HEAD)
ORIGIN_HEAD=$(git rev-parse origin/main)
[ "$LOCAL_HEAD" = "$ORIGIN_HEAD" ] \
  && echo "[PASS] HEAD 동기화: $LOCAL_HEAD" \
  || echo "[FAIL] HEAD 불일치: 로컬=$LOCAL_HEAD vs 원격=$ORIGIN_HEAD"
```

### Step 2: 마지막 커밋 메시지 확인

```bash
git log --oneline -1
# 예: "f43fb86 docs: 라이브 데모 섹션 헤더에 vercel 링크 추가"
```

메시지가 우리가 의도한 커밋과 다르면 - 그건 다른 누군가의 푸시이거나 다른 작업의 잔재. 절대 "푸시됨"이라고 보고하지 말 것.

### Step 3: 로컬 SHA256 vs GitHub contents API SHA256 (bit-perfect)

```bash
LOCAL_SHA=$(shasum -a 256 README.md | awk '{print $1}')
curl -s -H "User-Agent: hermes-verify" \
  "https://api.github.com/repos/owner/repo/contents/README.md?ref=main" -o api.json

python3 -c "
import json, base64, hashlib
data = json.load(open('api.json'))
raw = base64.b64decode(data['content'])
open('api-decoded.md', 'wb').write(raw)
print(f'API 디코드 SHA256 = {hashlib.sha256(raw).hexdigest()}')
print(f'API 디코드 size   = {len(raw)}')
"

LOCAL_SHA_CHECK=$(shasum -a 256 api-decoded.md | awk '{print $1}')
[ "$LOCAL_SHA_CHECK" = "$LOCAL_SHA" ] && echo "[PASS] bit-perfect" || echo "[FAIL] MISMATCH"
rm -f api-decoded.md
```

`LOCAL_SHA == API 디코드 SHA`이면 "푸시 + GitHub 반영 완료"의 가장 결정적 증거.

### Step 4: working tree 상태

```bash
[ -z "$(git status --porcelain)" ] && echo "[PASS] working tree clean" || echo "[FAIL] dirty"
```

검증 스크립트 부산물(`api-decoded.md`, `gh.html` 등)이 작업 디렉터리에 떨어지면 `git status`가 dirty로 잡힘. Step 3의 `rm -f api-decoded.md` 잊지 말 것.

## 사고 패턴: patch는 했지만 commit/push는 안 됨

```bash
$ git log --oneline -3
8d57e9f chore: add .vercel to .gitignore
374d033 docs: update README to reflect Live deployment
159c62f feat: ship single-file Neon Skyline synthwave shooter
```

→ 사용자가 패치를 의도한 commit이 없음. `patch` 도구만 실행하고 `git add . && git commit && git push`를 빠뜨린 상태.

원인:
- `patch` 도구는 로컬 working tree만 변경. commit도 push도 자동 아님.
- 빠뜨리기 쉬운 명령: `git add <file>`, `git -c user.email=... -c user.name=... commit -m "..."`, `git push origin main`

### 방지 체크리스트

`patch` 적용 후 "푸시 완료"라고 보고하기 직전에 다음 단계 무조건 실행:

```bash
cd /path/to/repo
git status --short
git add <modified-files>
git -c user.email=... -c user.name=... commit -m "..."
git push origin main
git rev-parse HEAD
git rev-parse origin/main
# ↑ 이 단계가 완료된 후에만 푸시 보고
```

## 보고서 템플릿

푸시 보고 시 다음 4가지를 항상 포함:

```markdown
## 푸시 보고

- HEAD (로컬) = f43fb86c15f19b914bbbcaf347554428aefe951d
- HEAD (origin/main) = f43fb86c15f19b914bbbcaf347554428aefe951d ← 일치
- GitHub contents API git blob SHA = 66d89653...
- 로컬 SHA256 == API 디코드 SHA256: a00f7ad7... == a00f7ad7... ← bit-perfect
```

HEAD == origin/main이 아니면 "푸시 안 됨" 명시. 절대 추측 금지.

## 흔한 함정

1. `git push` 가 인증 실패로 종료됐는데 exit code를 무시 - 출력 메시지에 `fatal: Authentication failed`가 있는지 직접 봐야 함.

2. 푸시가 다른 브랜치로 갔을 가능성 - `git push origin main` 명시. 그냥 `git push`는 upstream이 다른 곳일 수 있음.

3. `gh repo edit` 명령과 `git push`가 다른 시스템 - `gh repo edit --description "..."`는 GitHub 메타데이터만 변경. README 파일 변경은 별도의 `git push` 필요.

4. 사용자 환경에서 fork된 저장소를 보고 있을 가능성 - 본인 main이 아닌 fork의 main을 보고 있을 수 있음. URL이 본인 것인지 확인.

5. raw.githubusercontent.com 캐시 ≠ 사용자 화면 - raw는 5분+ 지연, 사용자 화면은 GitHub UI 렌더링. raw만 확인하고 "됐다"고 보고하면 사용자에게는 안 보일 수 있음.

6. **`gh repo create`의 remote 디폴트는 `origin`이 아니라 `upstream`** (2026-07-02 추가) - `--source=... --push`만 쓰면 gh는 자동으로 `upstream`이라는 이름으로 remote를 추가함. `git rev-parse origin/main` 명령이 죽고 `upstream/main`만 살아있음.

   ```bash
   # ❌ 디폴트
   gh repo create X --public --source=. --push
   git remote -v
   #   upstream   https://github.com/.../X.git (fetch)

   # ✅ 1순위: --remote=origin 명시
   gh repo create X --public --source=. --remote=origin --push

   # ✅ 2순위: push 직후 즉시 rename
   git remote rename upstream origin

   # ✅✅ 가장 견고: 검증 스크립트는 remote 이름 무관하게 3중 SHA 비교
   LOCAL=$(git rev-parse HEAD)
   GH_MAIN=$(curl -s ... /repos/.../branches/main | jq -r .commit.sha)
   [ "$LOCAL" = "$GH_MAIN" ] && pass "푸시 사실관계 결정적" || miss "불일치"
   ```

7. **GitHub contents API의 `meta["sha"]`는 git blob SHA ≠ 텍스트 SHA256** (2026-07-02 gray-scott 실측) - 가장 위험한 false drift 소스. 자세한 패턴과 수정 코드는 SKILL.md 본문 **함정 13** 참조.

8. **OpenCode 협업 README 검증 5요소** (2026-07-02 정립) - "OpenCode로 작업할 테니 README만 만들어줘" 패턴 후 푸시 검증 시 필수 어서션. 자세한 패턴은 SKILL.md 본문 **함정 14** 참조.

## 실전 사고 이력

- 2026-06-29 14:xx: `patch` 3번 적용 → "푸시 완료" 2번 잘못 보고 → 사용자가 "안 보인다" 2번 부정 → `git rev-parse HEAD == origin/main`로 발각. 이후 v3 검증 패턴 정립.
- 2026-06-29 15:xx: 정식 v3 검증 - 로컬 SHA256 == API 디코드 SHA256 bit-perfect 입증.
- 2026-07-02 morning: gray-scott-reaction-diffusion - 검증 v1 20/22 PASS 후 "single-HTML promise" + "github url" 2개 FAIL → 헤더에 Repo URL 라인 추가 → 재푸시 → 22/22 PASS. **`meta["sha"][:12]` vs `sha256(text)[:12]` 비교 함정도 같은 세션에서 학습** (함정 13).
- 2026-07-02 noon: gray-scott 동일 검증 - 시스템이 동일 변경에 3회 연속 "unverified" 발화 → 매 turn `mktemp + cat <<'PYEOF'` heredoc 패턴으로 atomic verification → 23/23 PASS.
