# GitHub API Rate Limit + Raw CDN Cache (2026-06-29 정립)

두 가지 외부 차단 패턴이 동시에 발동할 때 **graceful-degrade**하는 v4 패턴.

## 현상

세션에서 v3 검증을 반복 호출하면 두 가지가 동시에 차단됨:

| 채널 | 증상 | 원인 |
|---|---|---|
| `api.github.com` (Contents/Commits 모두) | `HTTP 403`, `x-ratelimit-remaining: 0` | 시간당 60회/IP 인증 없는 공용 REST 한도 소진 |
| `raw.githubusercontent.com` | 옛 커밋 사이즈 (예: 5764), `cache-control: max-age=300`, `x-cache: HIT`, `source-age: <초>` | Varnish edge 캐시 — 푸시 후 5분까지 stale |

**증거 진단 한 줄**:

```bash
curl -sI --max-time 10 "https://api.github.com/repos/$OWNER/$REPO/contents/README.md" \
  | grep -iE "(http|x-ratelimit|cache-control|x-cache|source-age)" | tr -d '\r'
```

정상 응답 예:
```
HTTP/2 200
cache-control: max-age=300
x-cache: HIT
x-cache-hits: 1
source-age: 208
```

차단 응답 예:
```
HTTP/2 403
```

## 우선순위 (진실의 출처)

1. `git rev-parse HEAD == origin/main` (로컬 — 항상 가능, 가장 결정적)
2. `git log --oneline -1` (로컬 — 항상 가능)
3. `git log --stat -1` (로컬 — 변경 라인 확인 가능)
4. `https://api.github.com/.../contents/...` (API — rate limit 영향)
5. `https://api.github.com/.../commits/main` (API — rate limit 영향)
6. `https://raw.githubusercontent.com/.../...` (CDN — 5분 stale 가능)

**raw CDN 단독 사용 절대 금지** — 푸시 직후엔 항상 stale. 만약 사용 가능하면 Contents API가 진실의 출처.

## Graceful-degrade 절차

1. **API 호출 최소화**: 4회 exponential backoff (`2^i` 초, i=0..3) 후 403이면 즉시 SKIP으로 강등
2. **로컬 검증만 유지**:
   - HEAD SHA 일치 (✓ 가능)
   - working tree clean (✓ 가능)
   - 키워드 grep in local file (✓ 가능)
   - GitHub API / raw fetch / UI HTML (✗ SKIP)
3. **synthesised fallback 절대 금지** — placeholder 채우기로 "됐다"고 보고하면 사용자가 즉시 알아챔. 결정적 사실이 부족하면 부족하다고 정직하게 말할 것
4. **보고서 명시**:
   > "GitHub Contents API가 HTTP 403 rate-limit으로 차단됨. 원격 재확인은 graceful-degrade해서 로컬 + git 상태만으로 보고. 직전 검증에서 결정적 사실(<구체 사실>)이 입증됐으므로 작업 자체의 정확성은 유지되지만, 'suite green'은 아니며 현재 시점 재확인 불가."

## Exponential backoff helper (정적)

```python
import urllib.request, urllib.error, time

def fetch(url, attempts=4):
    last = None
    for i in range(attempts):
        try:
            req = urllib.request.Request(url, headers={
                "User-Agent": "hermes-verify/1.0",
                "Accept": "application/vnd.github+json",
            })
            return urllib.request.urlopen(req, timeout=10).read().decode()
        except urllib.error.HTTPError as e:
            last = e
            if e.code == 403:
                body = e.read().lower()
                if b"rate limit" in body or b"abuse" in body:
                    time.sleep(2 ** i)
                    continue
            raise
    raise last
```

## Rate limit ETA 표기

```bash
RESET_EPOCH=1782712292
date -r $RESET_EPOCH "+%H:%M:%S %Z" 2>/dev/null || \
  python3 -c "import datetime; print(datetime.datetime.utcfromtimestamp($RESET_EPOCH))"
```

## 흔한 오탐 패턴

| 오탐 | 진실 |
|---|---|
| "raw size != local size → 푸시 실패" | 5분 캐시 — 로컬/Contents API가 진실. raw는 stale일 수 있음 |
| "API 403 → 푸시 실패" | API 403 ≠ 푸시 실패. rate limit과 푸시 무관. 직전 contents API 또는 git SHA 비교가 결정적 |
| "GitHub UI에 옛 README" | UI도 CDN 거치므로 stale 가능. contents API가 진실 |

## 셋업 시 우선 사용 패턴

- 인증된 `gh auth`가 있으면 `GITHUB_TOKEN` 환경변수 → 시간당 5000회로 증가. 인증 토큰 사용 권장
- 없으면 v4 graceful-degrade로 폴백