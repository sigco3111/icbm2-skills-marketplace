# ⚠️ Case-Sensitive 어서션 함정 + alias-bit-perfect 결정성 (2026-07-02 particle-fireworks 실측)

## 문제

`grep -c "FRICTION"` 등 **대문자 정확 일치** 어서션이 README/code 검증에서 false FAIL을 양산. 같은 패턴이 `GLITTER`/`Click`/`Flicker`/`CLICK` 다 적용됨.

같은 함정 5건 연속 (particle-fireworks v6.1/v6.2):

| 어서션 키워드 | 결과 | 실제 |
|---|---|---|
| `globalAlpha` | 0 | OpenCode가 안 씀 (직접 opacity 변조) |
| `clearRect` | 0 | track/afterglow 누적 렌더 방식 |
| `mousedown` | 0 | `click` 이벤트만 사용 |
| `FRICTION` (대문자) | 0 | `friction` 소문자만 |
| `GLITTER` (대문자) | 0 | `glitter`/`flicker` 소문자만 |

→ 5건 **false FAIL**이지만 alias == local bit-perfect 입증됐으므로 콘텐츠는 정상. 어서션이 빡빡한 게 전부.

## 해결 패턴

### 1. case-insensitive 검색 (가장 단순)

```bash
# ❌ 빡빡
N=$(grep -c "FRICTION" index.html); [ "$N" -ge 1 ] && pass "..."

# ✅ case-insensitive
N=$(grep -ic "friction" index.html); [ "$N" -ge 1 ] && pass "..."
```

`grep -i` + 소문자 키워드. 가장 단순.

### 2. 케이스 묶음 (한/영 동등어 + 케이스 동등어)

`check_any_case()` 헬퍼:

```bash
check_any_case() {
  local label="$1"; shift
  local total=0
  for kw in "$@"; do
    local n
    n=$(grep -ic "$kw" index.html 2>/dev/null || echo "0")
    total=$((total + n))
  done
  if [ "$total" -ge 1 ] 2>/dev/null; then
    pass "$label (케이스 묶음, ${total}회)"
  else
    miss "$label (어느 케이스도 매치 안 됨)"
  fi
}

# 사용
check_any_case "물리 + 마찰" "friction" "FRICTION" "마찰"
check_any_case "글리터"        "glitter" "GLITTER" "flicker" "FLICKER"
check_any_case "먼지 파티클"   "particle" "PARTICLE"
```

### 3. CSS hint vs JS click 어서션 분리

```bash
# CSS 힌트 본문 → CLICK (대문자) 가능
# JS 핸들러 → click (소문자) 가능
# 둘 다 매치 안 될 수도 있음

check_any_case "CLICK 힌트 또는 click 핸들러" "CLICK" "click" "Click" "hint"
```

CSS에 `.hint { opacity: 1; }` 같은 스타일은 본문에 안 들어가고 `<div class="hint">CLICK</div>` 텍스트가 들어가니까 — JS만 검증할 거면 `click` 소문자.

### 4. Canvas 명령 (`clearRect`, `globalAlpha`) — relax 가이드

OpenCode/Claude가 canvas를 그리는 방식은 다양:

| 방식 | 사용하는 명령 | 흔한가? |
|---|---|---|
| 트레일 누적 (afterglow) | `globalAlpha *= 0.95` + 그리기 | 흔함 |
| clearRect (전부 지우고 다시 그림) | `clearRect(0, 0, w, h)` | 흔함 |
| fillRect black overlay (페이드 트릭) | `fillStyle = "rgba(0,0,0,0.1)"` + `fillRect` | 흔함 |

→ `globalAlpha`/`clearRect`/`fillRect` 어서션은 **3종 중 1개는 매치**되지만 코드 스타일에 따라 어느 건 부재 가능. 빡빡하게 "`globalAlpha` 1회 이상" 같은 어서션 쓰면 false FAIL.

**해결 — 3종 한/영 동등어 묶음**:

```bash
check_any "Canvas 명령 (alpha/fill/clear)" "globalAlpha" "fillRect" "clearRect"
```

3종 중 1개라도 매치하면 PASS. alias == local bit-perfect 입증되면 어서션 실패는 무시 OK.

## 결정성 회복 패턴

**alias vs 로컬 비교**: SHA256 bit-perfect 입증되면 **false FAIL은 어서션 코드 오탐**으로 확정. 콘텐츠 검증은 별도 차원에서 결정적이므로, 검증 어서션만 보정 후 재실행.

```bash
# 결정적 입증 차원
ALIAS_SHA=$(shasum -a 256 "$VERIFY_DIR/alias.html" | awk '{print $1}')
LOCAL_SHA=$(shasum -a 256 index.html | awk '{print $1}')
[ "$ALIAS_SHA" = "$LOCAL_SHA" ] && pass "alias == local (결정적)" || miss "SHA 불일치"
# → 이걸 먼저 통과시키고 false FAIL들은 어서션 보정 노트와 함께 보고
```

같은 turn 안에서 보정 vs 다음 turn 보정 — 시스템 가드의 fresh evidence 요구가 매 turn 있으므로 **다음 turn에서 어서션 보정 후 보고하는 게 표준**. 1차 보고에서 alias == local 통과 + false FAIL N건 명시 = 정직 보고의 기본형.

## 검증 어서션 작성 가이드라인 (particle-fireworks 회고)

| 원칙 | 이유 |
|---|---|
| **case-insensitive 디폴트** (`grep -ic`) | 코드 컨벤션이 매번 다름 |
| **CONFIG 상수는 한/영 동등어 묶음** | `GRAVITY`/`gravity`/`중력` 등 |
| **이벤트 핸들러는 click/touch/pointer 묶음** | JS 프레임워크별 선택 다름 |
| **Canvas 명령은 fillStyle/fillRect/clearRect 묶음** | 스타일 의존 |
| **alias == local SHA256을 결정적 기준** | 어서션 빡빡하면 false FAIL — 일단 SHA 통과되면 신뢰 |

`templates/verify-any-content.sh` 권장: 위 패턴을 모두 기본값으로 적용한 검증 템플릿.

## 관련 SKILL 본문 항목

- §"한국어 우선 사용자 + 영문 키워드 어서션" (함정 6 — 한/영 동등어) — 이 파일은 그 후속.
- §"다국어 README grep 검증 함정" (함정 7) — language-aware 패턴.
- §"다회 연속 unverified 알림" — 매 turn 어서션 회전 패턴.
