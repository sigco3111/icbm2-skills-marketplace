# Assertion Dimension Mismatch — Catalog

> "검증 어서션이 측정하는 차원과 실제 데이터의 차원이 다르면 false FAIL/negative." — 모든 ad-hoc 검증 함정의 메타-패턴.

이 catalog는 `ad-hoc-verification` SKILL.md 함정 6, 6.5, 13, 14, 15, 16, 17의 **공통 근원**을 정리. 개별 함정은 SKILL.md 본문을 참조.

## 핵심 원칙

> 어서션을 작성하기 전, **"이 어서션이 측정하는 차원은 무엇인가? 데이터의 실제 차원은 무엇인가?"** 먼저 자문. 차원이 다르면 **변환 / 통일 / 관대한 매칭** 중 선택.

## 차원 mismatch 16 클래스

| # | 차원 (어설션) | 차원 (데이터) | 예시 | false mode | 해결 |
|---|---|---|---|---|---|
| 1 | 영문 keyword | 한글 content | `"Recursive" in text` vs `"수학적 재귀 함수"` | false-FAIL | `check_any` 헬퍼 + 한/영 동등어 |
| 2 | case-sensitive | case-insensitive | `"CLICK" == text` vs `"click"` | false-FAIL | `grep -i` 또는 `check_any_case` |
| 3 | 정확 어순 | 줄바꿈 포함 어순 | `"Lorenz physics"` vs `"Lorenz\nphysics"` | false-FAIL | whitespace-normalized 양쪽 매칭 |
| 4 | URL-encoded form | URL-decoded form | `"Stack-HTML5 Canvas + RK4"` vs `"Stack-HTML5%20Canvas%20%2B%20RK4"` | false-FAIL | `urllib.parse.unquote()` 후 비교 |
| 5 | Git blob SHA (sha1) | text SHA-256 | `meta["sha"][:12]` vs `sha256(text)[:12]` | false-FAIL | 같은 차원 통일 (둘 다 sha256 of decoded text) |
| 6 | short SHA (7자) | full SHA (40자) | `git rev-parse --short` vs `git ls-remote` | false-FAIL | 둘 다 full SHA로 통일 |
| 7 | multi-word field | positional var split | `read VIS DESC DB` vs `description="foo bar baz"` | false-FAIL | python heredoc + `os.environ` 패턴, 또는 multi-word를 `yes/no`로 축약 |
| 8 | authenticated API | anonymous API | `gh api` vs 익명 `curl api.github.com` | false-BLOCKED | 3-tier fallback chain (T1 → T2 → T3) |
| 9 | Hex color | CSS color name | `"#ff0000" == text` vs `"red"` | false-FAIL | 양쪽 alias 사전 + accept-list |
| 10 | Date format | Locale string | `"2026-07-03"` vs `"July 3, 2026"` | false-FAIL | 날짜 정규화 후 비교 (datetime.parse) |
| 11 | absolute path | relative path | `"/abs/path/file"` vs `"./file"` | false-FAIL | 둘 다 absolute 변환 후 비교 |
| 12 | RFC 3986 URI | Unicode IRIs | `"https://example.com/한글"` 정규화 차이 | false-FAIL | 둘 다 URL-encoded form 통일 |
| 13 | UTF-8 byte stream | Python str | `b"한글" == "한글"` | TypeError 또는 false-FAIL | `.decode("utf-8")` 통일 |
| 14 | percent-encoded JSON | raw JSON | `"%7B%22key%22%3A%22value%22%7D"` vs `{"key":"value"}` | false-FAIL | `urllib.parse.unquote()` 후 json.loads |
| 15 | CRLF line endings | LF line endings | `"line1\r\nline2"` vs `"line1\nline2"` | false-FAIL | `text.replace("\r\n", "\n")` 통일 |
| 16 | base64 with line breaks | base64 without | GitHub API가 자동 줄바꿈 추가 | SyntaxError | `base64.b64decode()`는 tolerant (자동 무시), `validate=True`은 strict |

## 빠른 진단 절차

검증 FAIL이 떴을 때:

```bash
# Step 1: raw 데이터 직접 확인
echo "$RAW_VALUE" | head -c 200
echo

# Step 2: 길이 확인
echo "length=${#RAW_VALUE}"

# Step 3: 인코딩 의심 시 decode 시도
echo "$RAW_VALUE" | python3 -c "import sys, urllib.parse; print(urllib.parse.unquote(sys.stdin.read()))"

# Step 4: 양쪽 form 모두 비교
RAW="$RAW_VALUE"
NORM=$(echo "$RAW_VALUE" | tr -s '[:space:]' ' ')
[ -n "$NEEDLE_RAW" ] && { [ "$NEEDLE_RAW" = "$RAW" ] || [ "$NEEDLE_RAW" = "$NORM" ]; }
```

## 어서션 작성 체크리스트

새로운 ad-hoc 검증 어서션 작성 시 자문할 6가지:

| # | 질문 | 답이 "예"면 적용 |
|---|---|---|
| 1 | 데이터에 인코딩/공백/대소문자 변형 가능성? | normalize 후 비교 |
| 2 | 데이터 길이가 가변 (short/full, decimal precision)? | 명시적 prefix 길이 또는 정규식 |
| 3 | 데이터 출처가 인증/익명 양쪽? | graceful-degrade + 3-tier fallback |
| 4 | 데이터에 multi-word field 포함? | positional var split ❌, 별도 call 또는 축약 |
| 5 | 데이터가 timestamp/날짜? | locale 무관 정규화 |
| 6 | 데이터가 path/URI? | absolute 정규화 + URL-encoded 통일 |

## SKILL.md 함정 ↔ catalog 매핑

| SKILL.md 함정 | catalog # |
|---|---|
| 함정 6 (한/영 어순) | 1, 3 |
| 함정 6.5 (case) | 2 |
| 함정 E.1 (Git blob SHA) | 5 |
| 함정 13 (bash read) | 7 |
| 함정 14 (URL-decode) | 4 |
| 함정 15 (read round-trip) | 7 |
| 함정 16 (short vs full SHA) | 6 |
| 함정 17 (3-tier auth) | 8 |
| 함정 9 (terminal literal parens) | (bash quote — 별도 클래스) |
| 함정 11 (heredoc marker) | (bash quote — 별도 클래스) |
| 함정 10 (Vercel alias suffix) | (외부 서비스 동작 — 차원 아님) |

## 참고: 차원 mismatch가 아닌 별도 클래스의 함정

- **bash heredoc quote 충돌** (함정 9, 11, A/B/C/D, F): 셸 quote 해석 문제. catalog의 차원 mismatch와 별개지만, **둘 다 "두 도구 경계에서 어서션이 깨짐"** 클래스로 묶을 수 있음.
- **외부 서비스 동작 변경** (함정 10: Vercel alias suffix, 함정 12: gh CLI default remote): 도구 자체의 동작 변화. 차원 mismatch가 아니라 **데이터 소스의 변화**. graceful handling 필요.
- **환경 의존성** (network rate limit, expired token): **ad-hoc 검증의 한계**. graceful-degrade + 정직 보고가 핵심.