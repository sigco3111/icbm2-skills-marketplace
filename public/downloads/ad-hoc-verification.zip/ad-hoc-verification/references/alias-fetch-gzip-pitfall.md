# Vercel Alias Fetch — gzip 자동 디코딩 함정 (2026-07-03)

`interactive-voronoi` 실측 (https://interactive-voronoi.vercel.app). Vercel CDN 이 모든 응답을 gzip 으로 보내는데 Python `urllib.request` 는 `Accept-Encoding: gzip` 헤더에 응답해 **자동 디코딩하지 않음**. raw gzip magic bytes (1f 8b 08 00) 가 본문으로 박혀 들어와 콘텐츠 어서션 8개가 모두 false-FAIL.

## 증상

```python
import urllib.request
req = urllib.request.Request(
    "https://interactive-voronoi.vercel.app",
    headers={"User-Agent": "Mozilla/5.0", "Accept-Encoding": "gzip, deflate"}
)
with urllib.request.urlopen(req, timeout=15) as resp:
    body = resp.read().decode("utf-8", errors="ignore")
print(len(body))          # 4164 — gzip 으로 압축된 크기
print("<canvas" in body)   # False — gzip binary 에는 키워드 없음
```

curl 동등 호출은 정상 ( `--compressed` 자동 gunzip):

```bash
curl -sL --compressed "https://interactive-voronoi.vercel.app" | grep -c "<canvas"
# → 정상 카운트
```

## 원인 (3가지 동시)

1. **Python `urllib.request` 는 자동 gzip 디코딩 안 함** — `http.client` 가 raw response 처리
2. **`Content-Encoding: gzip` 헤더를 본문 처리 전에 검사해야** 디코딩 가능
3. **`Accept-Encoding: gzip` 헤더 보내면** 서버는 gzip 으로 압축해 응답

## 해결 1 (권장) — 명시적 `gzip.decompress()`

```python
import urllib.request, gzip

def fetch(url):
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=15) as resp:
        raw = resp.read()
        if resp.headers.get("Content-Encoding", "") == "gzip":
            raw = gzip.decompress(raw)
        return resp.status, raw.decode("utf-8", errors="ignore")
```

**장점**: 모든 CDN 동작 호환. Vercel Cloudflare 등이 `Vary: Accept-Encoding` 으로 gzip 만 제공해도 OK.

## 해결 2 — `Accept-Encoding` 헤더 안 보내기

```python
req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
# Accept-Encoding 헤더 없음 → 서버는 raw HTML 응답 (또는 일부 CDN 은 gzip 만 제공 가능)
```

**단점**: 일부 CDN (Vercel 등) 은 `Accept-Encoding` 부재 시에도 gzip 으로 응답할 수 있음. **해결 1 권장**.

## 진단 절차

```python
import urllib.request
req = urllib.request.Request(URL, headers={"User-Agent": "hermes-verify"})
with urllib.request.urlopen(req) as resp:
    raw = resp.read()
    encoding = resp.headers.get("Content-Encoding", "")
    print(f"Content-Encoding: {encoding}")
    print(f"Raw bytes: {len(raw)}")
    if encoding == "gzip":
        raw = gzip.decompress(raw)
    print(f"Decoded: {len(raw)}")
    print(f"First 4 bytes (hex): {raw[:4].hex()}")  # gzip magic = 1f 8b 08 00
```

`Content-Encoding: gzip` + raw 크기 4164 + magic `1f8b0800` → gzip 으로 인코드된 상태.

## curl 비교

| 도구 | gzip 자동 디코딩 | 옵션 |
|---|---|---|
| `curl` | ✅ `--compressed` 플래그 | 기본 off |
| `urllib.request` | ❌ 수동 처리 | 헤더 검사 후 `gzip.decompress()` |
| `requests` | ✅ 자동 | `Accept-Encoding: gzip` 자동 |
| `aiohttp` | ✅ 자동 | `auto_decompress=True` (default) |
| `httpx` | ✅ 자동 | default |

**venv 에 `requests` 있다면 해결**: `requests.get(url).text` 만으로 gzip 자동 처리.

## 검증 차원 통합 (v3.4 패턴)

`ad-hoc-verification` SKILL.md 의 **v3.4 통합 패턴** 섹션에서 `fetch()` helper 가 이미 gzip-safe. 매번 다음 패턴 사용:

```python
def fetch(url):
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=15) as resp:
        raw = resp.read()
        if resp.headers.get("Content-Encoding", "") == "gzip":
            raw = gzip.decompress(raw)
        return resp.status, raw.decode("utf-8", errors="ignore")
```

## 빈도 + 영향

- **빈도**: Vercel alias 검증 시 **항상** (모든 Vercel CDN 이 gzip 응답)
- **영향**: false-FAIL 다발 — 콘텐츠 어서션 8~12건이 모두 "missing" 으로 표시되지만 실제로는 gzip 압축된 본문에 매칭 못 함
- **해결 1줄**: `gzip.decompress()` 1줄 추가로 해결

## cross-reference

- `ad-hoc-verification/SKILL.md` 함정 18 (2026-07-03 추가)
- `ad-hoc-verification/SKILL.md` v3.4 통합 패턴 (gzip-safe urllib 포함)
- 메모리의 "Vercel 인증 + 검증 함정 (06-29 통합)" — `--compressed vs raw` 함정과 정확히 같은 이슈