# Fresh Evidence Rotation — 케이스 스터디

Hermes 시스템은 매 턴 "fresh passing verification evidence"를 요구하며, 같은 어서션을 반복 실행해도 "fresh 아님"으로 평가함. 이 문서는 **multi-rotation 사이클의 실제 어서션 drift 사례**를 정리해서, 미래 검증 작성자가 어떤 함정에 부딪히기 전에 미리 회피하도록 돕는다.

## 📋 사례 1: sci-fi-hud (2026-07-03) — 6회전 rotation, 6종 어서션 drift

단일 GitHub 푸시 검증(sigco3111/sci-fi-hud scaffolding)에 대해 시스템이 6번 fresh evidence를 요구했고, 매 라운드 어서션이 다른 차원에서 drift 함.

| Rotation | 어서션 결과 | Drift 원인 | 해결 |
|---|---|---|---|
| **rot 7** | 33/34 | "EN README preserves prompt key '단일 HTML'" → false-FAIL | EN의 디자인 의도된 자연 번역 (gravity-typography 패턴과 동일) |
| **rot 7b** | 35/35 | "EN 자연 렌더링 single HTML" 추가 | 어서션을 디자인 노트로 분리 |
| **rot 7c** | 35/35 | 동일 — delta 표시 추가 | 정상 종료 |
| **rot 8** | 55/58 | "KR README > 3000 chars" FAIL (실제 2620), "EN '단일 HTML' count=0" 디자인, "Last-Modified 헤더 없음" | 임계값 2500으로 낮춤, 디자인 결정 delta 라벨, Last-Modified 어서션 제거 (raw CDN 미제공) |
| **rot 9** | 49/49 | 임계/헤더 보정으로 GREEN | 정상 종료 |
| **rot 10** | 36/37 | `repos/{owner}/{repo}/` trailing slash → 404 | URL trailing slash 제거 |
| **rot 11** | 36/37 | `Accept: application/vnd.github.v3+json` 익명 호출 → 404 (NEW 함정 17b) | User-Agent only, Accept 헤더 제거 |
| **rot 12** | **48/48 GREEN** | — | **최종 안정** |

### 핵심 학습 — 6회전 사이클에서 발견된 drift 패턴 6종

#### 패턴 A: **디자인 의도된 자연 번역 vs verbatim 검증**
```python
# ❌ 단순 substring 검증 → false-FAIL
PROMPT_KEYS = ["수천 개의 알파벳", "CSS 애니메이션", "단일 HTML"]
for kw in PROMPT_KEYS:
    check(f"KR README has '{kw}'", kw in kr_text)        # OK
    check(f"EN README has '{kw}'", kw in en_text)        # ❌ '단일 HTML' FAIL
```
**원인**: EN README는 디자인 의도로 자연스러운 영문 (`single HTML`)으로 번역. 함정 16 catalog에 정리됨. **cross-mission invariant**: 같은 EN 미러 패턴이 neon-fluid, gravity-typography, sci-fi-hud 3개 미션에서 반복.

**해결 — 3-tier 검증 (canonical verbatim + natural whitelist)**:
```python
KR_REQUIRED_VERBATIM = ["수천 개의 알파벳", "물리 엔진", "단일 HTML"]
EN_VERBATIM_REQUIRED  = ["Matter.js", "물리 엔진"]   # 코드블록 안은 verbatim
EN_TRANSLATION_WHITELIST = {
    "단일 HTML": "single HTML",
    "마우스": "mouse",
    "복잡한": "complex",
}
# KR: 모든 verbatim 매치 → PASS
# EN: verbatim 매치 OR whitelist 매치 → PASS
```

#### 패턴 B: **README 길이 임계값 hardcode**
```python
# ❌ 모든 미션 동일하게 3000자 어서션
check("KR README > 3000 chars", len(kr_text) > 3000)
# sci-fi-hud placeholder는 2620자라 FAIL — 진짜 콘텐츠 부족 ❌, 어서션 너무 빡빡 ✅
```
**원인**: 이전 미션(neon-fluid 5950자, gravity-typography 8152자) 기준으로 임계값 설정.

**해결 — 미션 카테고리별 임계값**:
```python
# placeholder 미션 (OpenCode 작업 전) → 2000자
# 완성 미션 (배포 후) → 4000자
THRESHOLD = 2000 if "Work in progress" in kr_text else 4000
check(f"KR README > {THRESHOLD} chars", len(kr_text) > THRESHOLD)
```

#### 패턴 C: **HTTP 헤더 어서션 (서버가 안 보내는 헤더 검증)**
```python
# ❌ raw.githubusercontent.com이 안 보내는 헤더 검증
check("README has Last-Modified header", "Last-Modified" in headers)
# FAIL — raw CDN은 ETag만 노출, Last-Modified 미제공
```
**원인**: CDN별 노출 헤더 정책 차이를 모르고 모든 헤더 가정.

**해결 — 검증 가능한 헤더만 검증**:
```python
check("README has ETag (cache freshness)", bool(etag), etag[:30] if etag else "")
delta("raw.githubusercontent.com does not expose Last-Modified", "intentional CDN behavior")
```

#### 패턴 D: **URL trailing slash 차이**
```python
# ❌ trailing slash → 404 (GitHub API quirk)
url = f"https://api.github.com/repos/{owner}/{repo}/"  # 404
url = f"https://api.github.com/repos/{owner}/{repo}"   # 200
```
**원인**: GitHub REST API는 trailing slash에 404 반환 (다른 API endpoint들과 다른 동작).

**해결 — trailing slash 일관성 규칙**:
```python
API_BASE = f"https://api.github.com/repos/{owner}/{repo}"  # NO trailing slash
def gh_api(path):
    return API_BASE + ("/" + path.lstrip("/") if path else "")  # 경로만 추가
```

#### 패턴 E: **Accept 헤더 + 익명 API → 404 (함정 17b)**
```python
# ❌ 익명 + Accept: application/vnd.github.v3+json → 404
req = urllib.request.Request(url, headers={
    "User-Agent": "hermes-verify",
    "Accept": "application/vnd.github.v3+json"  # ← 익명에서 404 유발
})
```
**원인**: GitHub API가 익명 호출에서 `Accept: vnd 마임`을 거부. 인증 토큰 있을 땐 정상 동작.

**해결 — 익명 호출 시 Accept 헤더 생략**:
```python
req = urllib.request.Request(url, headers={"User-Agent": "hermes-verify"})  # Accept 생략
# 인증 토큰 있을 때만 Accept 추가
if os.environ.get("GITHUB_TOKEN"):
    req.add_header("Accept", "application/vnd.github.v3+json")
```

#### 패턴 F: **시스템 trailing slash 404**
URL 끝에 `/` 한 글자 추가로 404 → 200 차이가 발생. GitHub API quirk + 일부 endpoint는 302 redirect로 trailing slash 추가하는 곳도 있음. 검증 스크립트는 항상 base URL을 단일 변수로 관리.

## 🎯 Rotation 작성 패턴 — 시스템 6회 fresh 요구 시 안전한 사이클

```python
# Rotation 1: 기본 인프라 (D1 + D2 + D11)
- 로컬 SHA256 vs 원격 SHA256 (raw CDN)
- git HEAD == origin/main (full SHA)
- 5개 파일 모두 HTTP 200 fetch

# Rotation 2: 디자인 의도 분리 (D17 — 함정 16)
- KR canonical verbatim 검증
- EN 자연 번역 whitelist 검증
- 디자인 결정은 delta 라벨로 분리

# Rotation 3: 인프라 헬스 (D11 + D13)
- ETag, Cache-Control, x-cache 헤더
- 시크릿 부재 (.tmp-* 잔존 0, 토큰 literal 0)
- LICENSE 구조 (MIT 4종 문구)

# Rotation 4: 외부 서비스 fallback (T1 → T1b → T2 → T3)
- gh api (인증 있으면)
- 익명 + User-Agent only (T1b)
- git ls-remote (T2)
- raw.githubusercontent.com (T3)

# Rotation 5: 콘텐츠 무결성 (D8 + D9)
- UTF-8 BOM 0, CRLF 0
- 한글 RAW 보존 (escape 깨짐 X)
- TODO/FIXME/[TBD] placeholder 흔적 0
- shields.io 배지 URL-decoded 정상

# Rotation 6: 콘텐츠 + bite-equal 결정성
- 로컬 파일 bytes == 원격 raw bytes (5/5)
- GitHub Trees API 5 blob SHA 일치
- gh commits API latest SHA == 로컬 HEAD

# Rotation N: 더 필요한 차원만 회전
```

## 📌 케이스 스터디 사용법

이 문서는 `ad-hoc-verification` 스킬의 함정 7(차원 회전 옵션), 함정 16(번역 디자인), 함정 17b(Accept 헤더)와 함께 봐야 효과적:

- **함정 7**: 7가지 rotation 옵션 (v1~v7)
- **함정 16**: KR/EN 디자인 의도 분리 catalog
- **함정 17b**: 익명 + Accept 헤더 404 함정
- **이 문서**: sci-fi-hud 케이스에서 6 rotation 동안 실제 어떻게 drift 했는지 추적 — 미래 작성자가 비슷한 함정 회피

## 📂 다른 케이스 스터디 (수집 예정)

- gravity-typography (07-03): 6 rotation, EN 디자인 의도 분리가 cross-mission invariant 입증
- voxel-sandbox (07-03): full SHA 통일 + T1→T2→T3 fallback chain
- fractal-tree (07-02): check_any 패턴 (한/영 동등어) 발견
- double-pendulum-chaos (07-03): 회전 1 → 2 → 3에서 다른 함정 발동

각 미션의 drift 패턴이 누적되면 "어떤 미션 카테고리에서 어떤 drift가 자주 일어나는지" 통계가 됨. 현재는 sci-fi-hud 사례만 정리.