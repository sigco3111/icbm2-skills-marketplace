#!/usr/bin/env bash
# scripts/check-kr-en-mixed-headings.sh
#
# Detect GitHub anchor 깨짐 위험이 있는 KR README 한/영 혼합 헤딩.
# 🛠️ + 한/영 혼합 + 영문 괄호 패턴은 GitHub anchor 생성 안 됨 (함정 17 v6.2).
# regex match lines, exit 0 if any found (so caller can pipe-fix), exit 1 if none.
#
# Usage:
#   bash scripts/check-kr-en-mixed-headings.sh <README.md>
#   echo $?   # 0 = mixed headers found (need fix), 1 = clean
#
# Discovered 2026-07-06 in interactive-metaballs bootstrap verifier v3.

set -euo pipefail
README="${1:?Usage: $0 <README.md>}"

# 패턴: 이모지 + (한글 + 한글 괄호 안) + 영문 괄호
# 예: ## 🎬 라이브 데모 (Live Demo) — anchor 깨짐
# 예: ## 🎮 조작법 (예정 — Controls) — anchor 깨짐
# 예: ## 🎨 디자인 결정 (예정 — Design Choices) — anchor 깨짐

# Allow Korean / English / 한자 letters, numbers, spaces, and a few common punctuation.
# The trigger is: an emoji-containing heading that ALSO contains an English word in parentheses.
MIXED_PATTERN='^## .*[🎬🤖✨🚀🎮🛠️🎨📂].*\(.*[A-Z][a-z]+.*\)'

matches="$(grep -nE "$MIXED_PATTERN" "$README" || true)"

if [[ -n "$matches" ]]; then
  echo "⚠️  GitHub anchor 깨짐 위험 한/영 혼합 헤딩 발견 ($README):"
  echo ""
  echo "$matches" | sed 's/^/  /'
  echo ""
  echo "권장 fix: 이모지 + 한글 only로 단일 언어 통일 (예: '## 🎬 라이브 데모 (Live Demo)' → '## 🎬 라이브 데모')"
  echo "         또는 영문 only (이모지 제거) (예: '## Live Demo')"
  echo ""
  echo "Exit code: 0 (mixed found)"
  exit 0
else
  echo "✅ KR README 한/영 혼합 헤딩 부재 (anchor 깨짐 위험 0개) — $README"
  exit 1
fi
