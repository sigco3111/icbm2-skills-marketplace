#!/bin/bash
# hermes-verify-coding-mission.sh — coding-mission 4-step README verifier
#
# Implements the 12-axis checklist in references/coding-mission-readme-checklist.md.
# Edit the constants below for your mission, then `bash` this script.
#
# Usage:
#   REPO=sigco3111/<repo> ALIAS_URL=https://<project>-<adj>.vercel.app \
#     EXPECTED_HEAD=<commit-prefix> \
#     ALIAS_CONTENT_PRIMITIVES="canvas,requestAnimationFrame,RK4" \
#     bash hermes-verify-coding-mission.sh
#
# Output: PASS/FAIL per axis, final N/12 summary, explicit SCOPE line.
#
# Origin: 2026-07-03 double-pendulum-chaos — designed after 3 false-fail rounds.
# Updated 2026-07-03 round-3: ALIAS_CONTENT_PRIMITIVES parameter added so the
# same script works for WebGL shader sims (interactive-voronoi) and raycasting
# engines (raycasting-doom), not just RK4 simulations.

set -o pipefail    # NOT set -u (see ad-hoc-verification-bash-heredoc-pitfall 함정 C)
PASS=0; FAIL=0

# ── CONSTANTS — edit per mission ─────────────────────────────────────
REPO="${REPO:-sigco3111/double-pendulum-chaos}"
ALIAS_URL="${ALIAS_URL:-https://double-pendulum-chaos-henna.vercel.app}"
EXPECTED_HEAD="${EXPECTED_HEAD:-e6e3e5b}"   # 7+ char prefix of HEAD
STACK_DECODED="${STACK_DECODED:-HTML5 Canvas + RK4}"   # URL-decoded form of Stack badge
LIVE_BADGE="${LIVE_BADGE:-Status-Live-22C55E}"
PENDING_VERSION="${PENDING_VERSION:-v0.4}"
DONE_VERSIONS="${DONE_VERSIONS:-v0.0 v0.1 v0.2 v0.3}"
REPO_DIR="${REPO_DIR:-/Users/mac/work/$(echo "$REPO" | sed 's|sigco3111/||')}"

# Alias content primitives (Axis 11) — comma-separated tokens, OR-matched.
# At least 2 of these tokens must appear in the alias body (case-insensitive substring).
# Presets by domain (override via env var):
#   default (Canvas+animation sims): canvas,requestAnimationFrame,RK4
#   WebGL shader sims:               canvas,shader,getContext
#   raycasting engines:              canvas,fillRect,ArrowUp
#   particle sims (neon-fluid):      canvas,requestAnimationFrame,particle
ALIAS_CONTENT_PRIMITIVES="${ALIAS_CONTENT_PRIMITIVES:-canvas,requestAnimationFrame,RK4}"

# Original prompt canonical marker (Axis 7) — override per mission
PROMPT_MARKER="${PROMPT_MARKER:-물리학적으로 예측 불가능한 움직임을 보여주는 이중 진자(Double Pendulum) 50개를}"
# ─────────────────────────────────────────────────────────────────────

log() { echo "$@" | tee -a "$LOG"; }
check() {
    if [[ "$2" -eq 0 ]]; then log "PASS  $1 :: $3"; PASS=$((PASS+1))
    else log "FAIL  $1 :: $DETAIL_PLACEHOLDER_NEVER_USED$3"; FAIL=$((FAIL+1)); fi
}
# Override `check` to use $3 properly (avoid the legacy $DETAIL_PLACEHOLDER issue):
check() {
    if [[ "$2" -eq 0 ]]; then log "PASS  $1 :: $3"; PASS=$((PASS+1))
    else log "FAIL  $1 :: $3"; FAIL=$((FAIL+1)); fi
}

mkdir -p "$TMPDIR"
LOG=$(mktemp -t hermes-verify-XXXXXX.log)
KR_RAW_FILE=$(mktemp -t hermes-verify-kr-XXXXXX.md)
EN_RAW_FILE=$(mktemp -t hermes-verify-en-XXXXXX.md)
META_FILE=$(mktemp -t hermes-verify-meta-XXXXXX.json)
RESULTS_FILE=$(mktemp -t hermes-verify-results-XXXXXX.txt)

cleanup() {
    rm -f "$LOG" "$KR_RAW_FILE" "$EN_RAW_FILE" "$META_FILE" "$RESULTS_FILE"
}
trap cleanup EXIT

log "AD-HOC VERIFICATION (coding-mission 12-axis) — $REPO"
log "Alias: $ALIAS_URL @ $(date -u +%H:%M:%SZ)"
log "Alias primitives (Axis 11): $ALIAS_CONTENT_PRIMITIVES"

# ===== Axis 1-9: fetch KR/EN README + delegate URL-decode / substring matching to Python =====
curl -sL "https://raw.githubusercontent.com/$REPO/main/README.md" > "$KR_RAW_FILE"
curl -sL "https://raw.githubusercontent.com/$REPO/main/README.en.md" > "$EN_RAW_FILE"
[[ -s "$KR_RAW_FILE" ]] && [[ -s "$EN_RAW_FILE" ]] || {
    log "FATAL: cannot fetch README files"; exit 2
}

# Save REST repo metadata for axes 9
curl -s -H "User-Agent: hermes-verify" "https://api.github.com/repos/$REPO" > "$META_FILE"

# Python does ALL the URL-decode-aware matching (axes 1-8 + alias-content primitives)
TMPDIR_PATH="$TMPDIR" python3 << PYEOF > "$RESULTS_FILE"
import os, re, urllib.parse, json, urllib.request, gzip, time

TMPDIR_PATH = os.environ["TMPDIR_PATH"]
results = []
def chk(name, ok, detail=""):
    results.append((name, ok, detail))

# Resolve the basename of the temp files (env-passed by bash)
KR_FILE = os.path.join(TMPDIR_PATH, "hermes-verify-kr-XXXXXX.md")
EN_FILE = os.path.join(TMPDIR_PATH, "hermes-verify-en-XXXXXX.md")
META_FILE = os.path.join(TMPDIR_PATH, "hermes-verify-meta-XXXXXX.json")

ALIAS_URL = "${ALIAS_URL}"
LIVE_BADGE = "${LIVE_BADGE}"
STACK_DECODED = "${STACK_DECODED}"
PENDING_VERSION = "${PENDING_VERSION}"
DONE_VERSIONS = "${DONE_VERSIONS}".split()
PROMPT_MARKER = "${PROMPT_MARKER}"
ALIAS_CONTENT_PRIMITIVES = [t.strip().lower() for t in "${ALIAS_CONTENT_PRIMITIVES}".split(",") if t.strip()]

# Read both README files
kr_txt = open(KR_FILE, encoding="utf-8").read()
en_txt = open(EN_FILE, encoding="utf-8").read()

# Axis 1: Live Demo URL
ALIAS_HOST = ALIAS_URL.split("//", 1)[1].split("/", 1)[0]
chk("Axis 1: KR has Live URL", ALIAS_HOST in kr_txt, "found" if ALIAS_HOST in kr_txt else "missing")
chk("Axis 1: EN has Live URL", ALIAS_HOST in en_txt, "found" if ALIAS_HOST in en_txt else "missing")

# Axis 2: Status=Live badge
chk("Axis 2: KR Status=Live badge", LIVE_BADGE in kr_txt, "found" if LIVE_BADGE in kr_txt else "missing")
chk("Axis 2: EN Status=Live badge", LIVE_BADGE in en_txt, "found" if LIVE_BADGE in en_txt else "missing")

# Axis 3: Stack badge URL-decoded
def extract_stack_decoded(txt):
    m = re.search(r'Stack-([A-Za-z0-9%]+(?:%20|%2B)*[A-Za-z0-9%+]*)-', txt)
    return urllib.parse.unquote(m.group(1)) if m else None

for label, txt in [("KR", kr_txt), ("EN", en_txt)]:
    decoded = extract_stack_decoded(txt)
    chk(f"Axis 3: {label} Stack badge decoded", decoded == STACK_DECODED, f"decoded='{decoded}'")

# Axis 4: Roadmap v0.0~v0.3 checked (literal "- [x] **vX**", no backslash)
for v in DONE_VERSIONS:
    chk(f"Axis 4: KR {v} checked", f"- [x] **{v}**" in kr_txt, "found" if f"- [x] **{v}**" in kr_txt else "missing")
    chk(f"Axis 4: EN {v} checked", f"- [x] **{v}**" in en_txt, "found" if f"- [x] **v0.1**" in en_txt else "missing")

# Axis 5: PENDING_VERSION still pending
chk("Axis 5: KR pending version", f"- [x] **{PENDING_VERSION}**" not in kr_txt, "confirmed" if f"- [x] **{PENDING_VERSION}**" not in kr_txt else "SHOULD-BE-PENDING")
chk("Axis 5: EN pending version", f"- [x] **{PENDING_VERSION}**" not in en_txt, "confirmed" if f"- [x] **{PENDING_VERSION}**" not in en_txt else "SHOULD-BE-PENDING")

# Axis 6: Attribution intact
for label, txt in [("KR", kr_txt), ("EN", en_txt)]:
    ok = ("MiniMax-M3" in txt and "OpenCode CLI" in txt and "sigco3111/" in txt)
    chk(f"Axis 6: {label} attribution intact", ok, "found" if ok else "missing")

# Axis 7: Original prompt preserved verbatim (canonical KR substring)
for label, txt in [("KR", kr_txt), ("EN", en_txt)]:
    chk(f"Axis 7: {label} prompt verbatim", PROMPT_MARKER in txt, "found" if PROMPT_MARKER in txt else "missing")

# Axis 8: Bilingual cross-link
chk("Axis 8: KR cross-link to EN", "README.en.md" in kr_txt, "found" if "README.en.md" in kr_txt else "missing")
chk("Axis 8: EN cross-link to KR", "README.md" in en_txt, "found" if "README.md" in en_txt else "missing")

# Axis 9: Repo metadata (visibility / default_branch / description)
try:
    meta = json.loads(open(META_FILE, encoding="utf-8").read())
    chk("Axis 9: visibility=public", meta.get("visibility") == "public", meta.get("visibility", "?"))
    chk("Axis 9: default_branch=main", meta.get("default_branch") == "main", meta.get("default_branch", "?"))
    chk("Axis 9: description non-empty", bool(meta.get("description")), "yes" if meta.get("description") else "no")
except Exception as e:
    for n in ("visibility", "default_branch", "description"):
        chk(f"Axis 9: {n}", False, str(e))

# Axis 11: Vercel alias dual-fetch (A14 gzip fix — explicit gzip.decompress)
T0 = T1 = ""
try:
    def _fetch_gz_safe(url):
        # Do NOT send Accept-Encoding — server may still gzip; decompress explicitly
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=10) as r:
            raw = r.read()
            if r.headers.get("Content-Encoding", "") == "gzip":
                raw = gzip.decompress(raw)
            return raw.decode("utf-8", "replace")
    T0 = _fetch_gz_safe(ALIAS_URL)
    time.sleep(2)
    T1 = _fetch_gz_safe(ALIAS_URL)
    norm0 = " ".join(T0.split())
    norm1 = " ".join(T1.split())
    chk("Axis 11: alias T0==T1 (text_norm)", norm0 == norm1, "identical" if norm0 == norm1 else "DIFFER")

    # Alias content primitives — match at least 2 of N configured tokens (case-insensitive)
    t0_lower = T0.lower()
    hits = [tok for tok in ALIAS_CONTENT_PRIMITIVES if tok.lower() in t0_lower]
    need = max(2, len(ALIAS_CONTENT_PRIMITIVES) - 1)  # require N-1 of N tokens (most permissive)
    # Actually use simple rule: at least 2 tokens must hit
    need = 2 if len(ALIAS_CONTENT_PRIMITIVES) >= 2 else len(ALIAS_CONTENT_PRIMITIVES)
    primitives_summary = f"hit {len(hits)}/{len(ALIAS_CONTENT_PRIMITIVES)}: {hits}"
    chk(f"Axis 11: alias content primitives (>= {need} of {ALIAS_CONTENT_PRIMITIVES})",
        len(hits) >= need, primitives_summary)
except Exception as e:
    chk("Axis 11: alias reachable", False, str(e))

# Axis 12: README Status-Live consistent with deployed sim
chk("Axis 12: Status-Live ↔ alias consistent", LIVE_BADGE in kr_txt and any(t.lower() in t0_lower for t in ALIAS_CONTENT_PRIMITIVES),
    "consistent" if (LIVE_BADGE in kr_txt and any(t.lower() in t0_lower for t in ALIAS_CONTENT_PRIMITIVES)) else "inconsistent")

# Output
for name, ok, detail in results:
    print(f"{'PASS' if ok else 'FAIL'}\t{name}\t{detail}")
PYEOF

# Tally Python output
while IFS=$'\t' read -r STATUS NAME DETAIL; do
    if [[ "$STATUS" == "PASS" ]]; then log "PASS  $NAME :: $DETAIL"; PASS=$((PASS+1))
    else log "FAIL  $NAME :: $DETAIL"; FAIL=$((FAIL+1)); fi
done < "$RESULTS_FILE"

# ===== Axis 10: Local git state (bash) =====
if [[ -d "$REPO_DIR" ]]; then
    cd "$REPO_DIR"
    HEAD=$(git rev-parse --short HEAD 2>/dev/null)
    check "Axis 10: git HEAD exists" 0 "$HEAD"
    [[ "$HEAD" == "$EXPECTED_HEAD"* ]] && check "Axis 10: HEAD == $EXPECTED_HEAD" 0 ok || check "Axis 10: HEAD match" 1 "got=$HEAD expected=$EXPECTED_HEAD"
    [[ -z "$(git status --porcelain)" ]] && check "Axis 10: tree clean" 0 ok || check "Axis 10: tree clean" 1 dirty
    [[ "$(git rev-parse HEAD)" == "$(git rev-parse origin/main)" ]] && check "Axis 10: HEAD == origin/main" 0 ok || check "Axis 10: HEAD sync" 1 fail
else
    check "Axis 10: repo dir exists" 1 "not found: $REPO_DIR"
fi

# ===== Summary =====
TOT=$((PASS+FAIL))
log ""
log "============================================================"
log "AD-HOC VERIFICATION (12-axis coding-mission): $PASS/$TOT passed"
log "============================================================"
log ""
log "SCOPE: ad-hoc verification only. Does NOT verify:"
log "  - Runtime / browser / shader correctness"
log "  - Visual accuracy of the simulation"
log "  - Physics correctness of the underlying equations"
log "Log: $LOG"
echo ""
echo "DONE — $PASS/$TOT"
exit 0   # always 0 — ad-hoc never blocks the workflow