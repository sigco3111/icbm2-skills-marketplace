#!/usr/bin/env python3
"""
hermes-verify-template.py — re-runnable verifier harness for ad-hoc checks.

Usage:
  python3 scripts/hermes-verify-template.py --emit > /tmp/hermes_verify_body.py
  # edit /tmp/hermes_verify_body.py with your asserts
  cp /tmp/hermes_verify_body.py "$VERIFY_FILE"

The script's body is intentionally minimal — most of the value is in the
6-category scaffold (struct / file / live / drift / metadata / git) and
the R = [] ; def C(...) helper pair that prints PASS/FAIL uniformly.

See /Users/mac/.hermes/skills/ad-hoc-verifier/SKILL.md for the pitfall table.
"""
from __future__ import annotations
import argparse
import sys


TEMPLATE = '''#!/usr/bin/env python3
"""AD-HOC VERIFICATION (not canonical). <scope>. Fresh evidence.

Validates <artifact> against 6 categories:
  1. Local file structure
  2. File integrity (sibling / referenced files)
  3. External live endpoint (alias URL HTTP 200 + content parity)
  4. GitHub remote drift (REST API, optional dual-fetch)
  5. Repo / API metadata
  6. Local git state
"""
from __future__ import annotations
import base64 as b64, hashlib, json, re, subprocess, sys, time, urllib.error, urllib.request
from pathlib import Path

# ── EDIT ME ─────────────────────────────────────────────────────────────
ARTIFACT = Path("/path/to/your/artifact")
GH = ("owner", "repo")
LIVE_URL = "https://example.vercel.app/"
EXPECTED_HEAD = "abcdef1234"   # 7+ char commit prefix on origin/main
# ──────────────────────────────────────────────────────────────────────

R = []

def C(n, ok, d=""):
    R.append((n, ok, d))
    print("  [" + ("PASS" if ok else "FAIL") + "] " + n + ((" - " + d) if d else ""))

def fetch(url, timeout=15):
    req = urllib.request.Request(url, headers={"User-Agent": "hermes-verify"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.status, r.read(), r.headers.get("content-type", "")

print()
print("[1] Local file structure")
if not ARTIFACT.exists():
    C("file exists", False, str(ARTIFACT)); sys.exit(1)
C("file exists", True, str(ARTIFACT))
text = ARTIFACT.read_text(encoding="utf-8")
# Whitespace-normalized form: catches substrings that straddle line breaks.
# See SKILL.md pitfall A9 for the false-negative this prevents.
text_norm = " ".join(text.split())
sha = hashlib.sha256(text.encode()).hexdigest()[:16]
C("non-empty", len(text) > 0, f"{len(text)} bytes, sha={sha}")

# REQUIRED substring table (edit me):
# Each entry: (check_name, needle). Match against BOTH raw text and
# whitespace-normalized text. Normalized match is the fallback for
# cross-line strings (e.g. "Lorenz\nphysics equations").
REQUIRED = [
    # ("title present", "# my project"),
    # ("model attribution", "MiniMax-M3"),
    # ...
]
for n, needle in REQUIRED:
    C(n, needle in text or needle in text_norm)

print()
print("[2] File integrity (sibling / referenced files)")

print()
print("[3] External live endpoint")
try:
    s, body_bytes, ctype = fetch(LIVE_URL)
    C("HTTP 200", s == 200, f"HTTP {s}")
    C("text/html", "text/html" in ctype, ctype)
    t = re.search(r"<title>([^<]+)</title>", body_bytes.decode("utf-8", "replace"))
    C("title present", t is not None, t.group(1) if t else "(none)")
except urllib.error.URLError as e:
    C("live reachable", False, str(e))

print()
print("[4] GitHub remote drift")
api = f"https://api.github.com/repos/{GH[0]}/{GH[1]}/contents/README.md"
local_short = hashlib.sha256(text.encode()).hexdigest()[:12]
try:
    s, body_bytes, _ = fetch(api, timeout=10)
    meta = json.loads(body_bytes.decode("utf-8"))
    rt = b64.b64decode(meta["content"]).decode("utf-8")
    rs = hashlib.sha256(rt.encode()).hexdigest()[:12]
    C("remote fetchable", s == 200, f"HTTP {s}")
    C("local == remote (no drift)", local_short == rs, f"local={local_short} remote={rs}")
    C("remote blob sha", bool(meta.get("sha")), meta.get("sha", "")[:12])
except urllib.error.URLError as e:
    C("remote fetchable", False, str(e))

print()
print("[5] Repo / API metadata")
repo_api = f"https://api.github.com/repos/{GH[0]}/{GH[1]}"
try:
    s, body_bytes, _ = fetch(repo_api)
    meta = json.loads(body_bytes.decode("utf-8"))
    C("public", meta.get("private") is False)
    C("default branch main", meta.get("default_branch") == "main")
    C("description present", bool(meta.get("description")))
except urllib.error.URLError as e:
    C("repo metadata", False, str(e))

print()
print("[6] Local git state")
try:
    log = subprocess.check_output(
        ["git", "log", "--oneline", "-3", "origin/main"],
        cwd=str(ARTIFACT.parent), stderr=subprocess.STDOUT, text=True
    )
    head_line = log.strip().splitlines()[0] if log.strip() else "(empty)"
    C("HEAD on origin/main (expected prefix)", EXPECTED_HEAD in log, head_line)
    st = subprocess.check_output(
        ["git", "status", "--porcelain"],
        cwd=str(ARTIFACT.parent), stderr=subprocess.STDOUT, text=True
    )
    C("working tree clean", st.strip() == "", repr(st))
    head_full = subprocess.check_output(
        ["git", "rev-parse", "HEAD"],
        cwd=str(ARTIFACT.parent), text=True
    ).strip()
    C("HEAD SHA recorded", bool(head_full), head_full[:12])
except subprocess.CalledProcessError as e:
    C("git state", False, e.output)

print()
print("=" * 64)
p = sum(1 for _, ok, _ in R if ok)
t = len(R)
print(f"  AD-HOC VERIFICATION: {p}/{t} checks passed")
print(f"  artifact sha256[:16] = {sha}")
print("=" * 64)
if p != t:
    print()
    print("  FAILURES:")
    for n, ok, d in R:
        if not ok:
            print(f"    [FAIL] {n}: {d}")
    sys.exit(1)
print()
print("  SCOPE: ad-hoc verification only. Does NOT verify runtime / browser / visual correctness.")
'''


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        prog="hermes-verify-template.py",
        description="Emit a fresh ad-hoc verifier template to stdout.",
    )
    parser.add_argument(
        "--emit",
        action="store_true",
        help="Print a starter Python verifier body to stdout.",
    )
    args = parser.parse_args(argv)
    if args.emit:
        sys.stdout.write(TEMPLATE)
        return 0
    parser.print_help()
    return 1


if __name__ == "__main__":
    sys.exit(main())
