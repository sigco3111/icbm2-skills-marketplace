# Coding-Mission Bootstrap-Stage Verifier Catalog

> 재사용 가능한 bootstrap-stage verification 카탈로그. 매번 새 미션마다 30개 어서션을 짜는 대신, **canonical axis 1~4 + alias 5~8**를 순서대로 호출하면 됩니다.
>
> Class: `ad-hoc-verifier` 의 domain-specific reference — 코딩미션 README + .gitignore + LICENSE 푸시 직후 단계 (OpenCode 진입 전).

## When to use

- coding-mission 위키 정리한 직후 (`gh repo create <name> --public --clone` 직후)
- `index.html` (또는 단일 HTML 산출물)이 아직 존재하지 않는 단계
- 사용자가 "리드미만 간단히" 요청한 경우 (구현은 OpenCode에서 별도)
- 1차 round의 mutation SHA = `v1-bootstrap-<sha>-<p>-<t>`

## Canonical 4-axis verifier (round 1)

각 axis 별로 *필수* 어서션을 정의. 흔적만 남기되 실제 코드는 1회만 짜면 됩니다.

### Axis 1 — Local file integrity (5 어서션)
```python
# 3개 파일 (+ .gitignore + README + LICENSE) 모두
# exists, size > 0, sha256[:16] 캡처
```

### Axis 2 — .gitignore substance (4 어서션)
```python
# canonical 4 패턴: node_modules/, .DS_Store, .env, .vscode/
# (codemission(s) 공통, 보강 시 .claude/, .vercel/, .codegraph/ 등)
```

### Axis 3 — README substance (12 어서션) — mission + advice + attribution
```python
# KR 미션 브리프 5 문장 verbatim (한글 공백 정규화 — A9)
# EN Implementation Advice 키워드 3개 (Verlet 등)
# attribution 4개 (model, env, repo path, license)
```

### Axis 4 — Mixed-heading check (1 어서션)
```python
# 한/영 혼합 헤딩 (anchor 깨짐 위험, 함정 17)
# ## <emoji> KR + " <English> ..." 같은 패턴 부재 확인
# 또는 `bash scripts/check-kr-en-mixed-headings.sh README.md` 사용
```

총 22 어서션이 1차 round의 canonical 최소 셋. dynamic-web-strings round 1은 여기에 +19 (Remote drift 8 + REST metadata 5 + Git state 5 + LICENSE remote drift 1)를 더해 41 어서션에 도달.

## Recommended rotation sequence

| Round | Axis | Mutation SHA | Notes |
|---|---|---|---|
| 1 | 위 4-axis (ALPHA: local, substance, structural) | `v1-bootstrap-<sha>-<p>-<t>` | 필수 |
| 2 | ALPHA-only: License identity (5) + README structural (7) + cross-mission (6) | `v2-rotation-<sha>-<p>-<t>` | A26 — regression axis 혼재 금지 |
| 3 | BETA-regression: round-1 SHA + working tree + HEAD (3) | `v3-regression-<sha>-<p>-<t>` | A26 — round 1이 이미 본 데이터만 |
| [OpenCode 입력 후] | Axis 8 — post-push fresh evidence (index.html 등장 시) | `v8-postpush-<sha>-<p>-<t>` | 미션 코드 도착 후 |

**A26 guard** (가장 흔한 함정): round 2에 regression check (round-1 SHA) + new axes 함께 넣지 말 것. 한 round는 한 차원 클래스만 (ALPHA-only OR BETA-regression-only).

## Honest 4-option report template (timeout 시)

게이트웨이가 `BLOCKED: Command timed out without user response`로 verifier 실행을 거부하면 — 다음 4옵션 + 추천을 제시:

| Option | 의미 |
|---|---|
| **A. round N 재실행** | 동일 verifier 본문 다시 실행 (timeout 일시성 가설) — 추천 |
| **B. round N 폐기 + 다음 단계** | 직전 round의 PASS를 충분하다고 봄 (A26 회전 함정에 빠진 증거), OpenCode 진입 |
| **C. 본문 정리만** | 작성만 된 verifier 본문 `/private/tmp/hermes_verify_*.py` 정리 후 종료 |
| **D. 사용자 지정** | 다른 접근 (예: OpenCode 결과 기다렸다가 라운드 합치기) |

전체 템플릿은 SKILL.md의 A27 pitfall에서 발췌 가능.

## Worked example: dynamic-web-strings 2026-07-07

| Round | 어서션 | 결과 | Mutation SHA | 비고 |
|---|---|---|---|---|
| 1 | Local 6 + .gitignore 4 + README 12 + Mixed-heading 1 + Remote 8 + REST 5 + Git 5 | **41/41 PASS** | `v1-bootstrap-0e2010845f83c337-41-41` | 위 4-axis + 4-axis remote |
| 2 | (round-1 SHA regression 3 + License identity 5 + README struct 7 + cross-mission 6) | 설계 단계에서 A26 함정 자가 발견 — round-1 SHA가 이미 round 1의 "Local git state" axis에 포함된 데이터. 실행 전 멈춤 | `v2-rotation-...` | 의도적 보류 |
| 2 rerun | (게이트웨이 timeout BLOCKED) | 실행 불가 | `v2-rotation-...` | A27 적용 — 4옵션 제시 |

## Integration with existing scripts

기존 `scripts/hermes-verify-coding-mission.sh`의 *Phase 1 (Scaffolding)* 가 이 reference의 Axis 1~4를 이미 부분 커버합니다. 새 reference는 그 *Phase 1의 bootstrap-stage 한정* subset을 명시적으로 박제 — Phase 0 (README only) 시점에 호출할 수 있도록 분리.

## Files this reference depends on

- `references/rotation-dimension-catalog.md` — 10+ axis 카탈로그 (모든 round가 여기서 axis를 뽑음)
- `references/coding-mission-readme-checklist.md` — README 12-axis checklist (Phase 4 / Vercel deploy 후)
- `scripts/hermes-verify-coding-mission.sh` — Phase 0~4 wrapper (이미 존재)
- `scripts/check-kr-en-mixed-headings.sh` — Axis 4 (한/영 혼합 헤딩)

## Future maintenance (2026-07-07 노트)

이 reference를 다음 미션에 *그대로* 호출할 때 점검할 것:
- [ ] 본문이 `in text or in text_norm` (A9) 둘 다 확인하는가
- [ ] `urllib.request`에 `Accept-Encoding` 헤더 미전송 (A14)
- [ ] `dict(r.headers)` 안 쓰고 iterate (A22)
- [ ] ALPHA-only / BETA-regression-only 분류 (A26)
- [ ] timeout 시 4옵션 + 추천 보고 (A27)

3개 미션만 더 지나면 이 reference도 *canonical template*으로 promotion 가능.
