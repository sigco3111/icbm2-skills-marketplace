# Bootstrap-Stage Worked Example: pendulum-wave (2026-07-08)

> Live session log of a coding-mission bootstrap-stage verification cycle
> that exercised every axis in the canonical 4-axis catalog + multiple
> rotation rounds + A26 issue-detection-then-fix-then-reverify.
> Saved as a reference so future missions can compare their rotation
> shape against this baseline.

## Mission context

| Item | Value |
|---|---|
| Repo | `sigco3111/pendulum-wave` |
| Stage | bootstrap (README + .gitignore only; OpenCode to generate `index.html`) |
| Mission | Three.js Pendulum Wave — 15 pendulums, SHM, 3D visualization |
| Prompt verbatim | "각기 다른 줄 길이를 가진 15개의 추(Pendulum)가 일렬로 매달려 동시에 흔들리기 시작할 때, 주기 차이에 의해 처음에는 뱀처럼 움직이다가 점차 혼돈스러워지고 다시 질서를 찾아가는 '펜듈럼 웨이브' 현상을 물리적으로 정확한 주기 공식을 적용해 3D로 시각화해줘. Implementation Advice: Use Three.js. This is a pure math animation (Simple Harmonic Motion). No heavy physics engine needed; just calculate the angle θ(t) = θ_max · cos(√(g/L) · t) for each pendulum length L in the requestAnimationFrame loop. 모든 의존관계의 코드를 하나의 HTML에 담는 형태로 코드 작성." |
| Date | 2026-07-08 |
| Profile | default |

## Round-by-round log

| Round | Type | Scope tag | Result | Mutation SHA | What changed |
|---|---|---|---|---|---|
| 1 | bootstrap (canonical 4-axis) | `bootstrap-stage limited assertions` | **24/24 PASS** | `v1-bootstrap-652306b630566706-24-24` | initial verifier, established baseline |
| 2 | ALPHA-only rotation | `ad-hoc rotation round 2 (ALPHA-only)` | **17/20 PASS** | `v2-rotation-652306b630566706-17-20` | 3 FAILs surfaced (see below) |
| 2.5 | artifact fix | (no verifier run) | README attribution table gained `\| **라이선스** \| MIT \|` row | (no SHA yet — round 3 will capture) | A7.4 real-issue fix |
| 3 | post-fix regression + strict A6.1 | `ad-hoc rotation round 3 (post-fix regression)` | **19/20 PASS** | `v3-postfix-78c5adcec2e3179a-19-20` | A6.1 false-FAIL remained (python code-block comment matched strict regex) |
| 4 | code-fence-aware | `ad-hoc rotation round 4 (code-fence-aware H1 counter)` | **ABORTED — user pivot to an-unnamed-repo** | n/a | A31 protocol applied: body cleaned up, no execution |

## Round 2 FAIL classification (the A26/A9/A24 decision tree)

| Axis | Verdict | Cause | Fix path |
|---|---|---|---|
| **A6.1** "exactly one H1 heading" → h1=2 | **false-FAIL (A24 family + verifier bug)** | regex `^# [^#]` matched both real H1 (`# 🕰️ pendulum-wave`) and python code-block comment (`# → http://localhost:8000`) | Tighten to `^# [^\s#]` (round 3) → still matched `# →` because `→` is non-space non-# → escalate to **code-fence state machine** (round 4) |
| **A6.4** "at least 3 markdown links" → links=1 | **policy mismatch (bootstrap-stage intentionally minimal)** | README had 1 link (the `sigco3111/pendulum-wave` repo URL). Bootstrap READMEs before code is added legitimately have ≤ 2 links | Loosen to `≥ 1 markdown link AND references sigco3111/pendulum-wave` (round 3+4) |
| **A7.4** "'라이선스' line in attribution" → FAIL | **real-issue (README gap)** | attribution table had 모델/환경/저장소/상태 but no 라이선스 row. Round 1's A3.12 only checked "MIT somewhere in text" — weak assertion that didn't enforce table-row form | **patch README** to add `\| **라이선스** \| MIT \|` row in attribution table (round 2.5) |

## Round 3 → still 1 FAIL (A6.1)

Round 3 tightened regex to `^# [^\s#]` but `# → http://localhost:8000` still matches because `→` (U+2192) is non-whitespace non-#. **Lesson: text-class regex alone cannot distinguish real H1 from a python comment that happens to start with `# `.** Need to **walk lines with code-fence state machine** — only count headings OUTSIDE ``` ``` ``` blocks. Round 4 was designed to do exactly that.

## Round 4 — ABORTED by user pivot

The round-4 body was authored with the code-fence-aware walker:
```python
in_code = False
h1_outside_code = []
for ln in lines:
    if ln.strip().startswith("```"):
        in_code = not in_code
        continue
    if not in_code and re.match(r"^# [^\s#]", ln):
        h1_outside_code.append(ln)
```
but **before execution**, the user sent `"https://github.com/sigco3111/<anonymized-repo> 저장소 제거"` — pivoting to a new task. A31 interrupt protocol was applied:

1. `rm -f /tmp/hermes_v4_round4_pendulum_wave.py` — body cleaned up
2. The mktemp slot was never created (write_file flushed, but cp/run/rm didn't happen), so no slot to clean
3. Pivoted to anonymized-repo task; reported "round 4 verifier body cleaned up — round aborted by user pivot"

## Lessons saved to SKILL.md

- **A31** — Interrupt protocol when user pivots mid-verification (rm pending body, skip slot, note in response)
- **A32** — `clarify` choices invisible to user → fall back to plain-text 4-option table
- **A33** — macOS `/tmp` is a symlink to `/private/tmp`; always `rm` the exact path `write_file` reports in `resolved_path`

## Why this example is canonical

This mission exercised every dimension in the catalog:

| Catalog dimension | Where it appears |
|---|---|
| Round 1 basic fetch + 5-file integrity | round 1 axis A1.x |
| Round 1 .gitignore substance | round 1 axis A2.x |
| Round 1 README substance + cross-mission | round 1 axis A3.x |
| Round 1 mixed-heading check | round 1 axis A4.x |
| Round 1 git state regression baseline | round 1 axis B1.x |
| Round 2 ALPHA-only rotation (License identity) | round 2 axis A5.x |
| Round 2 markdown structural integrity | round 2 axis A6.x |
| Round 2 cross-mission consistency | round 2 axis A7.x |
| Round 2 cleanup verification | round 2 axis A8.x |
| Round 2→3 issue detection + artifact fix | round 2.5 README patch |
| Round 3 post-fix regression | round 3 axis A5-A8 |
| Round 4 code-fence-aware (designed but not executed) | round 4 design |
| Round 4 A31 interrupt protocol (executed) | round 4 cleanup |

A future pendulum-wave-like mission (other Three.js / WebGL / single-HTML bootstrap) can compare its round-by-round progression against this log and predict when rotation becomes necessary.