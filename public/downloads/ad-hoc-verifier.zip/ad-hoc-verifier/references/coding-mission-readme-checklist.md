# Coding-mission README Verification Checklist (12 axes)

> Trigger: any coding-mission repo (Scaffolding → OpenCode → Vercel → README 4-step workflow)
> where the changed paths include `README.md` / `README.en.md`.
>
> Origin: 2026-07-03 double-pendulum-chaos — observed 3 false-fail rounds, each caused
> by a different pitfall from the ad-hoc-verifier table. This checklist catches all three
> up-front so the next session goes straight to a clean PASS.

## When to apply

Apply when ALL of these are true:
1. The repo follows the 4-step coding-mission pattern (neon-fluid / lorenz-attractor / double-pendulum-chaos style)
2. The user just asked to update the README to match the neon-fluid format
3. Both `README.md` (KR, default) and `README.en.md` (EN) exist
4. A live Vercel deploy exists at `<project>-<adjective>.vercel.app` (the alias URL, NOT the team-scope production URL)

## The 12 axes

For each axis, the checklist gives: what to check, the most common false-fail, and the
correct matching approach.

### Axis 1 — Live Demo URL (the freshly-added piece after Vercel deploy)
- **Check**: Both README files contain `<project>-<adjective>.vercel.app` (the alias).
- **False-fail**: Verifier checks for the team-scope production URL (`<project>-<hash>-<owner>.vercel.app`) which redirects via SSO 302 in anon.
- **Correct**: Use the alias URL only; both READMEs should reference the same alias.

### Axis 2 — Status badge = Live (green)
- **Check**: Both files contain `Status-Live-22C55E` (green).
- **False-fail**: Pre-deploy badge was `Status-In%20Development-F59E0B` (amber); if README was updated before deploy, the amber color lingers.
- **Correct**: Search for `Status-Live-22C55E` directly (literal, no URL-decoding needed because there are no encoded chars).

### Axis 3 — Stack badge URL-decoded
- **Check**: Both files contain `Stack-HTML5%20Canvas%20%2B%20RK4-000000` (or equivalent), and URL-decoded equals the user-meaningful name (e.g. `HTML5 Canvas + RK4`).
- **False-fail**: Verifier regex `Stack-[A-Za-z0-9 _+]*` matches only `Stack-HTML5` because `%20` is not in the character class.
- **Correct**: Python `urllib.parse.unquote()` on the badge slug, then compare to the decoded form. See `scripts/hermes-verify-coding-mission.sh` for the pattern.

### Axis 4 — Roadmap v0.0~v0.3 checked
- **Check**: Both files contain `- [x] **v0.0**`, `- [x] **v0.1**`, `- [x] **v0.2**`, `- [x] **v0.3**`.
- **False-fail**: Verifier uses `\- \[x\] \*\*v0.1\*\*` (regex backslash escape). The README uses LITERAL `- [x] **v0.1**` — backslashes are not present.
- **Correct**: Match the literal string. When in doubt: `curl -sL <raw_url> | grep "v0.1"` to see exact bytes.

### Axis 5 — Roadmap v0.4+ still pending
- **Check**: Both files do NOT contain `- [x] **v0.4**` (negative check — confirms no premature completion).
- **Correct**: `[[ "$TXT" != *"- [x] **v0.4**"* ]] && check "v0.4 still pending" 0 ok || check "v0.4" 1 should-be-pending`.

### Axis 6 — Attribution intact
- **Check**: Both files contain all three: `MiniMax-M3` (model), `OpenCode CLI` (env), `sigco3111/<repo>` (link).
- **False-fail**: Pre-deploy README had a placeholder attribution. After the deploy+README update, the placeholder may not have been replaced.
- **Correct**: Single triple-substring check; if any of the three is missing, FAIL.

### Axis 7 — Original prompt preserved verbatim (KR + EN)
- **Check**: Both files contain the exact canonical Korean prompt (from the user's first message), WITHOUT translation or paraphrase.
- **Why**: The neon-fluid format mandates that the EN README also preserves the original KR prompt verbatim (so a reader can see what was given to the model), followed by an English translation.
- **Correct**: Use `text_norm` (whitespace-normalized) for the canonical comparison, since the prompt is multi-line and may wrap differently across files. Both files MUST contain the canonical prompt string verbatim.

### Axis 8 — Bilingual cross-link
- **Check**: KR README contains `README.en.md` (link to EN); EN README contains `README.md` (link to KR).
- **False-fail**: The cross-link line uses `[🇰🇷 한국어 (기본)](./README.md) · [🇺🇸 English](./README.en.md)` — verifier only checks for the flag emoji, not the link target.
- **Correct**: Search for the link target filename directly.

### Axis 9 — GitHub REST repo metadata (3 fields)
- **Check**: `visibility = public`, `default_branch = main`, `description` non-empty.
- **False-fail**: bash `read VIS DESC DB < <(python -c "print(v, d, b)")` puts the LAST WORD of `description` into `DB`, so `default_branch == "main"` test passes by coincidence on some inputs. See 함정 13 in ad-hoc-verification-bash-heredoc-pitfall.
- **Correct**: Save JSON to disk, then read with `TMPDIR_PATH="$TMPDIR" python3 << 'PYINNER'` heredoc. Reduce multi-word `description` to a single token (`"yes"` if present, else `"no"`).

### Axis 10 — Local git state
- **Check**: HEAD on origin/main; working tree clean; commit count >= 2 (scaffold + impl + docs).
- **Correct**: `git rev-parse HEAD == git rev-parse origin/main` (full SHA, not prefix), `git status --porcelain` empty.

### Axis 11 — Vercel alias dual-fetch
- **Check**: `curl -sL --compressed <alias>` twice with 2s gap; `text_norm` (whitespace-collapsed) of both responses are identical; HTTP 200; alias body contains the configured content primitives.
- **False-fail**: Verifier hits the team-scope production URL, which SSO-redirects to a signin page in anon environments.
- **Correct**: Use the alias URL ONLY. Use `--compressed` flag (matches browser). Use `tr -s '[:space:]' ' '` for cross-line text_norm. **In Python urllib, explicitly decompress gzip** (see ad-hoc-verifier pitfall A14) — never send `Accept-Encoding: gzip` header without a matching `gzip.decompress()` call.

### Axis 12 — README ↔ alias consistency
- **Check**: README claims Status-Live AND alias is reachable (200) AND alias body references at least one of the configured content primitives.
- **Correct**: All three sub-conditions in a single check. If any one fails, it's a real drift (not a verifier bug).

## Reusable verification script

`scripts/hermes-verify-coding-mission.sh` implements all 12 axes. Edit the top
constants (REPO, ALIAS_URL, EXPECTED_HEAD, ALIAS_CONTENT_PRIMITIVES, PROMPT_MARKER)
and run:

```bash
# Default (double-pendulum-chaos — Canvas2D + RK4 simulation)
REPO=sigco3111/<repo> ALIAS_URL=https://<alias>.vercel.app \
  EXPECTED_HEAD=<commit-prefix> \
  bash /Users/mac/.hermes/skills/ad-hoc-verifier/scripts/hermes-verify-coding-mission.sh
```

Output format: `PASS <axis> :: <detail>` lines + final `AD-HOC VERIFICATION: N/12 passed` summary
+ explicit `SCOPE: ad-hoc verification only` line.

### Axis 11 domain presets (ALIAS_CONTENT_PRIMITIVES)

The default axis 11 token list `canvas,requestAnimationFrame,RK4` is hardcoded
to the double-pendulum-chaos mission domain. **Other mission domains need
different primitives** because their alias body won't contain RK4 — they use
WebGL shaders, DDA raycasting, particle systems, etc.

Override the env var per mission domain (comma-separated tokens; at least 2
must hit the alias body):

| Domain | Preset | Example mission |
|---|---|---|
| Canvas2D + RK4 simulation (default) | `canvas,requestAnimationFrame,RK4` | double-pendulum-chaos |
| WebGL shader sim | `canvas,shader,getContext` | interactive-voronoi |
| Raycasting engine | `canvas,fillRect,ArrowUp` | raycasting-doom |
| Particle / fluid sim | `canvas,requestAnimationFrame,particle` | neon-fluid |
| Custom (any sim) | user-defined tokens | any |

Usage example for a WebGL shader mission:

```bash
REPO=sigco3111/interactive-voronoi \
ALIAS_URL=https://interactive-voronoi.vercel.app \
EXPECTED_HEAD=c7b91f9 \
STACK_DECODED="WebGL Shader" \
ALIAS_CONTENT_PRIMITIVES="canvas,shader,getContext" \
PROMPT_MARKER="화면을 무작위로 분할하는 보로노이 다이어그램(Voronoi Diagram)을 구현하되" \
bash /Users/mac/.hermes/skills/ad-hoc-verifier/scripts/hermes-verify-coding-mission.sh
```

**Why this matters**: the round-3 follow-up session (2026-07-03, 3 coding-mission
projects in sequence: double-pendulum-chaos, interactive-voronoi, raycasting-doom)
discovered that the hardcoded RK4 primitive would falsely FAIL on WebGL missions
(interactive-voronoi has no RK4 reference — it uses `gl_FragColor`/`smoothstep`)
and on raycasting missions (raycasting-doom has DDA / `deltaDist` instead of RK4).
Adding `ALIAS_CONTENT_PRIMITIVES` + `PROMPT_MARKER` env vars makes the same script
reusable across all three domains without forking.

## Why this is a checklist and not a script

Because every coding-mission repo has slightly different axis-3 (Stack badge text),
axis-7 (the canonical prompt varies per mission), and axis-11 (content primitives
vary per domain). The env vars at the top of `scripts/hermes-verify-coding-mission.sh`
make this parameterizable without forking the script per project.

## When the checklist evolves

Add new axes here when the same false-fail pattern recurs in 2+ coding-mission sessions.
Recent additions:
- 2026-07-03 — axes 1-12 (initial) from double-pendulum-chaos round-by-round learnings
- 2026-07-03 (round-3 follow-up) — **ALIAS_CONTENT_PRIMITIVES + PROMPT_MARKER env vars** added to `scripts/hermes-verify-coding-mission.sh` so the same verifier covers Canvas2D-RK4, WebGL shader, and raycasting domains without forking. Discovered after running the same 12-axis verifier against 3 different domain projects (double-pendulum-chaos / interactive-voronoi / raycasting-doom) in one session.