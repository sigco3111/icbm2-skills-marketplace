# Run log — real-session ad-hoc verifier outputs

## 2026-07-02 — gray-scott-reaction-diffusion README + Vercel deploy

### Run 1 — `mktemp -t hermes-verify-XXXXXX.py.ITrtjjuwBq` → 24/24 PASS
Verified local README (13 substring asserts + sha256) +
remote fetch via REST API (parity check via top-100B + full SHA)
+ repo metadata (public, main, description) + git HEAD `c416f4e`.

Discovered mid-run that `.gitignore` had `??` status — OpenCode had
added `.vercel` and a trailing newline; this is pitfall A4. Commit
the .gitignore delta in the same push, otherwise the verifier
keeps reporting a dirty tree even after README-only commits.

### Run 2 — `...py.fmPvV7XQ1b` → 40/40 PASS
Same plus Vercel alias URL HTTP 200 with body SHA matching local
`index.html` (pitfall A5 — never verify against the team-scope URL
`sigco3111s-projects.vercel.app`, only against the project alias
`gray-scott-reaction-diffusion.vercel.app`).

Two new categories added since Run 1:
- served body SHA matches local index.html (`0d539f0a...`)
- remote git blob SHA recorded (`80862e830442`)

### Run 3 — `...py.NRUm4sU3GI` → 42/42 PASS
Same as Run 2 with mutation-style hash + content-snapshot. The
script recorded its own `content_sha` (sha256[:16] of README.text)
and used the same value as a label everywhere it printed.

### Run 4 — `...py.b9qJtYmR10` → 46/46 PASS
Added dual-fetch at T0/T1 (2s apart) to prove the verifier ran
against live state, not stale cache. Also captured `pushed_at`
from repo metadata + full HEAD SHA from `git rev-parse HEAD`.

T0 and T1 SHAs identical (`9005aeda2366` / `80862e830442`),
which is the proof that no concurrent push happened during
the 6-second verification window.

### Lessons captured
1. write_file refuses /var/folders → write to /tmp first, cp in (A1)
2. heredoc blank line truncation → use plain cat and cp (A2)
3. py_compile before running every body to catch A3 early
4. OpenCode may add .vercel to .gitignore mid-session (A4)
5. Vercel team-scope URLs require SSO auth — alias only (A5)
6. Hardcoded HEAD prefix in script goes stale on follow-up commits (A6)
7. GitHub meta.sha is git blob SHA, not text SHA (A7)
8. There is no canonical test for ad-hoc JSON / config changes (A8)

## 2026-07-06 — tistory-publisher 197차 (session expired + 36 ghost posts)

### Round 1 — 46/46 PASS (with 2 f-string backslash errors caught)
First attempt — patched `~/.hermes/secrets/tistory.env` (TSSESSION + `_T_ANO` refresh after §3.8.1 Zombie 302 expiry) and added `scripts/rollback-fake-publish.sh`. Both files structural-verify pass. Hit **A20 twice** when Python f-string expressions had `\"` escapes inside `cat << 'PYEOF'` heredoc. Fix: use `state['stats']['total']` single-quote dict access (PEP 701 disallows backslash in f-string interpolation).

### Round 2 — 12/12 PASS (dimension rotation: bash -n syntax + sandbox skip)
Reused template but rotated axes — instead of re-running all 46 file-structure checks, focused on (a) bash -n syntax parse, (b) dry-run output for 격차 ≤ 0 정상 분기, (c) sha256 round-1 fingerprint regression. 12/12 clean. Sandbox run with 격차 부풀리기 intentionally skipped (real STATE 손상 위험), 명시적 한계 보고.

### Round 3 — 10/10 PASS (with A11b pitfall retry on M axis)
Added checks for repeated `--category` 호출 무변동 (K), `commit_publish()` unit import (L), `record_published_topic()` dedup 동작 보강 (M). **M 차원에서 A11b 즉시 적중** — `parts[1].split(':')[1]` IndexError로 차원 전체 FAIL. Boiled back into PREFIX-based 매칭 (`for line in stdout.split('\n'): ... if line.startswith(f'{key}:'): data[key] = line.split(':', 1)[1]`). Verified dedup 정상: 1st 호출 +1 (655→656), 2nd 호출 +0 (656→656).

### Lessons captured (197차)
- A20 f-string backslash: use single-quote dict access in f-string interpolation expressions inside bash heredoc bodies
- A21 patch duplication: include ≥3 lines of unique surrounding context in `old_string`; post-patch `grep -c` to detect duplication
- Dimension rotation works across 3 rounds: round 1 structural (46), round 2 bash -n + dry-run (12), round 3 behavior + dedup + side-effect (10)
- A11b (new in this session): Python subprocess stdout 파싱도 multi-word positional split에 적중 — PREFIX 매칭으로 통일

## 2026-07-06 — tistory-publisher 198차 (root patch: commit_publish + remove pre-increment)

### Round 1 — 19/19 + 2 false-positive lookalikes
Patched `~/.hermes/scripts/blog_pipeline.py` — removed 18-line pre-increment block from `run_pipeline()`, added `commit_publish(topic, title, url, category, source_url)` function + `--commit TOPIC TITLE URL CATEGORY SOURCE_URL` CLI. Verified: file structure (no regression in --record / --status / --dry-run), --help mentions --commit, function import 성공.

### Round 2 — 15/18 + 3 false-positive patterns
Rotated axes: (F) active run_pipeline 코드만 추출하여 사전 박기 0건 — 코멘트 줄 제외 처리 (코멘트 안에 코드 형태 문자열은 active 아님). (G) --commit metavar 5개 단위 매칭. (H) end-to-end --category (변동 0) + --commit (+1) 워크플로. (I) last_topics 정리. (J) §3.5 + Tistory 일관성.

### Round 3 — 10/10 PASS (K / L / M / N-bonus axes; A11b 보강)
K (반복 안정성): 30회 반복 `--category` 다중 카테고리 = stats 무변동 (stress=889 → 889, diff=0). L (모듈 단위): `blog_pipeline.commit_publish` import + callable + 5개 인자 시그니처 검증. L-bonus (실제 단위 호출): `commit_publish()` 호출 → stats +1, today +1, returned dict with `committed: true` 확인. M (dedup 보강): `record_published_topic` 1st +1 (655→656), 2nd +0 (656→656) — dedup 정상. N-bonus: 사전 박기 후보 패턴 4종 + `commit_publish()` 호출 모두 active 코드 0건 (코멘트/docstring 제외).

### Patch-checksum
- `blog_pipeline.py` sha256[:16] = `6158d2e17ab4c668`

### Lessons captured (198차)
- 사전 박기(pre-increment)는 half-pipeline에서 가짜 발행의 근본 원인 — `--category` 호출만으로 stats 오염됨. **§3.14 신규 함정** (run_pipeline active 코드 사전 박기 결함)
- commit_publish() 의도적 분리 = run_pipeline 내부 호출 0건 — publish 외부 워커 책임 명확
- Verification 차원 회전의 3 rounds × 4 axes 패턴이 노이즈 있는 함수정 환경(A11b, A20, A21, N 코멘트)에서도 안정적으로 통과
- §3.11 5단계 (last+details 동시) + §4 5-1 stats 보정은 commit_publish로 단일 진입점 통합 — 외부 워크플로 단순화
