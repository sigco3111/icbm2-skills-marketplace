# Integration points — which subsubskills should call ad-hoc-verifier

Each owning skill is responsible for *what* to verify; the verifier
umbrella owns the *how* (6-category scaffold, OS-safe tempfile, scope
language). Patch the owning skill's SKILL.md to embed a one-line rule
that delegates to this umbrella's `scripts/hermes-verify-template.py`.

## automation/notebooklm-youtube-automation

- **Insertion point:** Gold Pitfalls table (after #39)
- **Wording:** "fresh passing evidence rule (gold #40) — whenever a
  selection.json patch, --review, or --approved milestone lands and
  the system emits a fresh-evidence request, run ad-hoc-verifier
  with categories 1, 4, 5, 6 for the touched JSON and a live URL
  sniff for any Vercel deploy."

## automation/python-oss-bootstrap

- **Insertion point:** Phase 1 (right before `gh repo create`)
- **Wording:** "run ad-hoc-verifier against the scaffolded src-layout
  to confirm pyproject.toml + tests/ + README badges resolve before
  pushing — saves the round-trip when scaffolds have empty stubs."

## vercel (umbrella)

- **Insertion point:** Verification section
- **Wording:** "after deploy, run ad-hoc-verifier with category 3
  (alias URL HTTP 200 + content parity) and category 4 (GitHub
  repo description reflects the new project)."

## Manual trigger recipe

If a fresh-evidence message arrives and no owning skill has a
patched rule yet, you can still run ad-hoc-verifier directly:

```bash
VERIFY_FILE=$(mktemp -t hermes-verify-XXXXXX.py)
python3 /Users/mac/.hermes/skills/ad-hoc-verifier/scripts/hermes-verify-template.py --emit > /tmp/hermes_verify_body.py
# edit the EDIT-ME block, then add 23 substring asserts per the README section
cp /tmp/hermes_verify_body.py "$VERIFY_FILE"
python3 "$VERIFY_FILE"
rm -v "$VERIFY_FILE" /tmp/hermes_verify_body.py
```
