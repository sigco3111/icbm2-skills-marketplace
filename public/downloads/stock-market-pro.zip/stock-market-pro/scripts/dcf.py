#!/usr/bin/env python3
# /// script
# dependencies = [
#   "yfinance",
#   "rich",
#   "pandas"
# ]
# ///
"""
한국 주식 DCF(할인현금흐름) 밸류에이션 스크립트
사용법:
    python3 dcf.py 005930.KS
    python3 dcf.py 000660.KS --period 5y
    python3 dcf.py 005930.KS --rf 3.0 --erp 7.0 --growth 2.5
"""

import sys
import argparse
import warnings
from datetime import datetime

import pandas as pd
import yfinance as yf
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.text import Text
from rich import box

warnings.filterwarnings("ignore")

# ─── 기본 한국 시장 파라미터 ───────────────────────────────────────
DEFAULT_RF = 2.8       # 무위험수익률 (한국 10년 국채 수익률, %)
DEFAULT_ERP = 6.5      # 주식위험프리미엄 (%)
DEFAULT_TAX = 22.0     # 법인세율 (%)
DEFAULT_GROWTH = 2.0   # 영구성장률 (%)
DEFAULT_BETA = 1.0     # 기본 베타
KOSPI_TICKER = "^KS11" # 코스피 지수 티커
FORECAST_YEARS = 5     # 명시적 예측 기간


# ═══════════════════════════════════════════════════════════════════
#  유틸리티 함수
# ═══════════════════════════════════════════════════════════════════

def fmt_num(value: float, unit: str = "", decimals: int = 1) -> str:
    """숫자를 읽기 쉬운 형식으로 변환"""
    if pd.isna(value) or value == 0:
        return "N/A"
    abs_val = abs(value)
    sign = "-" if value < 0 else ""
    if unit == "원":
        if abs_val >= 1e12:
            return f"{sign}{value/1e12:,.{decimals}f}조"
        elif abs_val >= 1e8:
            return f"{sign}{value/1e8:,.{decimals}f}억"
        elif abs_val >= 1e4:
            return f"{sign}{value/1e4:,.{decimals}f}만"
        else:
            return f"{sign}{value:,.{decimals}f}{unit}"
    elif unit == "%":
        return f"{value:,.{decimals+1}f}%"
    else:
        if abs_val >= 1e12:
            return f"{sign}{value/1e12:,.{decimals}f}T"
        elif abs_val >= 1e9:
            return f"{sign}{value/1e9:,.{decimals}f}B"
        elif abs_val >= 1e6:
            return f"{sign}{value/1e6:,.{decimals}f}M"
        else:
            return f"{sign}{value:,.{decimals}f}"


def get_safe(df, key, col=0):
    """DataFrame에서 안전하게 값 추출"""
    try:
        if isinstance(df, pd.DataFrame) and key in df.index:
            val = df.loc[key].iloc[col] if hasattr(df.loc[key], 'iloc') else df.loc[key]
            if pd.notna(val):
                return float(val)
        return None
    except (KeyError, IndexError, TypeError):
        return None


def compute_beta(stock_ticker: str, period: str = "5y") -> float:
    """주식 vs 코스피 베타 자동 계산"""
    try:
        stock_data = yf.download(stock_ticker, period=period, progress=False)["Close"]
        kospi_data = yf.download(KOSPI_TICKER, period=period, progress=False)["Close"]

        # 공통 날짜 정렬
        df = pd.DataFrame({"stock": stock_data, "kospi": kospi_data}).dropna()
        if len(df) < 30:
            return DEFAULT_BETA

        returns = df.pct_change().dropna()
        cov = returns["stock"].cov(returns["kospi"])
        var = returns["kospi"].var()
        beta = cov / var if var != 0 else DEFAULT_BETA

        # 합리적 범위 제한
        return max(0.3, min(2.5, round(beta, 3)))
    except Exception:
        return DEFAULT_BETA


def get_yfinance_beta(ticker_obj) -> float:
    """yfinance에서 제공하는 베타 가져오기"""
    try:
        info = ticker_obj.info
        beta = info.get("beta")
        if beta and 0.2 <= beta <= 3.0:
            return round(beta, 3)
    except Exception:
        pass
    return None


def get_growth_rate(ebit_history: list) -> float:
    """과거 EBIT 데이터로 성장률 추정"""
    valid = [x for x in ebit_history if x is not None and x != 0]
    if len(valid) < 2:
        return DEFAULT_GROWTH / 100

    # 최근 3년 CAGR (가능한 경우)
    n = min(3, len(valid))
    recent = valid[:n]
    cagr = (abs(recent[0]) / abs(recent[-1])) ** (1 / (n - 1)) - 1
    # 합리적 범위: 0% ~ 15%
    return max(0.0, min(0.15, round(cagr, 4)))


def get_fcf_growth_rate(fcf_history: list) -> float:
    """과거 FCF 기반 성장률 추정"""
    valid = [x for x in fcf_history if x is not None and x > 0]
    if len(valid) < 2:
        return None
    n = min(3, len(valid))
    recent = valid[:n]
    cagr = (recent[0] / recent[-1]) ** (1 / (n - 1)) - 1
    return max(0.0, min(0.15, round(cagr, 4)))


# ═══════════════════════════════════════════════════════════════════
#  데이터 수집
# ═══════════════════════════════════════════════════════════════════

def fetch_financials(ticker: str, period: str = "5y", console: Console = None):
    """yfinance에서 재무제표 데이터 수집"""
    if console:
        console.print(f"[bold cyan]📊 [경로={ticker}] 재무 데이터 수집 중...[/]")

    stock = yf.Ticker(ticker)

    # 재무제표 (연간 기준, 최근 4년)
    income = stock.financials
    balance = stock.balance_sheet
    cashflow = stock.cashflow

    # 티커 정보
    info = stock.info
    current_price = info.get("currentPrice") or info.get("regularMarketPrice")
    shares_outstanding = info.get("sharesOutstanding")
    company_name = info.get("shortName") or info.get("longName") or ticker
    market_cap = info.get("marketCap")
    currency = info.get("currency", "KRW")

    # ─── EBIT 추출 ────────────────────────────────────────
    ebit_values = []
    ebit_keys = ["EBIT", "Operating Income", "Operating Revenue"]
    if income is not None and not income.empty:
        for key in ebit_keys:
            vals = []
            for col in income.columns:
                v = get_safe(income, key, list(income.columns).index(col))
                vals.append(v)
            if any(v is not None for v in vals):
                ebit_values = vals
                break
        # 대안: Revenue - Operating Expenses
        if not any(v is not None for v in ebit_values):
            revenue = []
            opex = []
            for col in income.columns:
                r = get_safe(income, "Total Revenue", list(income.columns).index(col))
                oe = get_safe(income, "Operating Expense", list(income.columns).index(col))
                revenue.append(r)
                opex.append(oe)
            ebit_values = [r - o if r and o else None for r, o in zip(revenue, opex)]

    # ─── D&A 추출 ────────────────────────────────────────
    da_values = []
    da_keys = ["Depreciation And Amortization", "Depreciation", "Reconciled Depreciation"]
    if cashflow is not None and not cashflow.empty:
        for key in da_keys:
            vals = []
            for col in cashflow.columns:
                v = get_safe(cashflow, key, list(cashflow.columns).index(col))
                vals.append(v)
            if any(v is not None for v in vals):
                da_values = vals
                break
        # 영업활동현금흐름에서 간접 추정
        if not any(v is not None for v in da_values):
            ocf = []
            ni = []
            for col in cashflow.columns:
                o = get_safe(cashflow, "Operating Cash Flow", list(cashflow.columns).index(col))
                n = get_safe(cashflow, "Net Income", list(cashflow.columns).index(col))
                ocf.append(o)
                ni.append(n)
            da_values = [o - n if o and n else None for o, n in zip(ocf, ni)]

    # ─── CapEx 추출 ────────────────────────────────────────
    capex_values = []
    capex_keys = ["Capital Expenditure", "Net Capital Expenditure", "Purchase Of Property Plant Equipment"]
    if cashflow is not None and not cashflow.empty:
        for key in capex_keys:
            vals = []
            for col in cashflow.columns:
                v = get_safe(cashflow, key, list(cashflow.columns).index(col))
                vals.append(v)
            if any(v is not None for v in vals):
                capex_values = vals
                break

    # ─── 순운전자본(NWC) 변화 추출 ─────────────────────────
    nwc_change_values = []
    if balance is not None and not balance.empty:
        years = list(balance.columns)
        for i in range(len(years) - 1):
            curr_assets_0 = get_safe(balance, "Current Assets", years.index(years[i]))
            curr_assets_1 = get_safe(balance, "Current Assets", years.index(years[i + 1]))
            curr_liab_0 = get_safe(balance, "Current Liabilities", years.index(years[i]))
            curr_liab_1 = get_safe(balance, "Current Liabilities", years.index(years[i + 1]))
            if all(v is not None for v in [curr_assets_0, curr_assets_1, curr_liab_0, curr_liab_1]):
                nwc_0 = curr_assets_0 - curr_liab_0
                nwc_1 = curr_assets_1 - curr_liab_1
                nwc_change_values.append(nwc_1 - nwc_0)
            else:
                nwc_change_values.append(None)
        nwc_change_values.append(None)  # 최근 연도는 변화 불가

    # ─── 순부채 (Net Debt) ────────────────────────────────
    total_debt = None
    cash_and_equiv = None
    if balance is not None and not balance.empty:
        debt_keys = ["Total Debt", "Long Term Debt", "Long Term Debt And Capital Lease Obligations"]
        for key in debt_keys:
            total_debt = get_safe(balance, key, 0)
            if total_debt is not None:
                break
        # 단기부채도 포함
        st_debt = get_safe(balance, "Short Term Debt", 0)
        if st_debt and total_debt:
            total_debt += st_debt
        elif st_debt:
            total_debt = st_debt

        cash_keys = ["Cash And Cash Equivalents", "Cash", "Cash Financial Assets"]
        for key in cash_keys:
            cash_and_equiv = get_safe(balance, key, 0)
            if cash_and_equiv is not None:
                break

    net_debt = (total_debt or 0) - (cash_and_equiv or 0)

    # ─── 시가총액 기반 자본구조 ─────────────────────────────
    equity_value = market_cap if market_cap else shares_outstanding * (current_price or 0)
    total_capital = equity_value + (total_debt or 0) if equity_value else None

    return {
        "info": info,
        "company_name": company_name,
        "current_price": current_price,
        "shares_outstanding": shares_outstanding,
        "market_cap": market_cap,
        "currency": currency,
        "ebit": ebit_values,
        "da": da_values,
        "capex": capex_values,
        "nwc_change": nwc_change_values,
        "total_debt": total_debt,
        "cash_and_equiv": cash_and_equiv,
        "net_debt": net_debt,
        "equity_value": equity_value,
        "total_capital": total_capital,
        "income": income,
        "balance": balance,
        "cashflow": cashflow,
    }


# ═══════════════════════════════════════════════════════════════════
#  DCF 계산
# ═══════════════════════════════════════════════════════════════════

def calculate_dcf(data: dict, rf: float, erp: float, tax_rate: float,
                  g: float, beta: float, forecast_years: int = FORECAST_YEARS) -> dict:
    """DCF 모델 계산"""

    # ─── 과거 FCF 계산 ─────────────────────────────────────
    historical_fcf = []
    max_years = min(
        len(data["ebit"]),
        len(data["da"]),
        len(data["capex"]),
        len(data["nwc_change"])
    )

    for i in range(max_years):
        ebit = data["ebit"][i]
        da = data["da"][i]
        capex = data["capex"][i]
        nwc_chg = data["nwc_change"][i] if i < len(data["nwc_change"]) else None

        if ebit is None:
            historical_fcf.append(None)
            continue

        # FCF = EBIT × (1 - tax) + D&A - CapEx - ΔNWC
        nopat = ebit * (1 - tax_rate / 100)
        fcf = nopat + (da or 0) - (capex or 0) - (nwc_chg or 0)
        historical_fcf.append(fcf)

    # ─── 성장률 추정 ───────────────────────────────────────
    fcf_growth = get_fcf_growth_rate(historical_fcf)
    if fcf_growth is None:
        fcf_growth = get_growth_rate(data["ebit"])
    # 보수적 보정
    fcf_growth = fcf_growth * 0.7

    # ─── WACC 계산 ─────────────────────────────────────────
    # 자본구조 가중치
    if data["total_capital"] and data["total_capital"] > 0:
        we = data["equity_value"] / data["total_capital"]  # 자본 비중
        wd = (data["total_debt"] or 0) / data["total_capital"]  # 부채 비중
    else:
        we = 0.7
        wd = 0.3

    we = max(0.1, min(0.95, we))
    wd = 1 - we

    # 자기자본비용
    cost_of_equity = rf / 100 + beta * (erp / 100)

    # 타인자본비용 (가정: 무위험률 + 1% 위험프리미엄)
    cost_of_debt = rf / 100 + 0.01

    # 세후 부채비용
    after_tax_cost_of_debt = cost_of_debt * (1 - tax_rate / 100)

    # WACC
    wacc = we * cost_of_equity + wd * after_tax_cost_of_debt

    # ─── 5년 FCF 예측 ──────────────────────────────────────
    base_fcf = None
    for f in historical_fcf:
        if f is not None and f > 0:
            base_fcf = f
            break

    if base_fcf is None:
        base_fcf = data["ebit"][0] * (1 - tax_rate / 100) * 0.6 if data["ebit"][0] else 0

    projected_fcf = []
    current_fcf = base_fcf
    for year in range(forecast_years):
        projected_fcf.append(current_fcf * (1 + fcf_growth))
        current_fcf = current_fcf * (1 + fcf_growth)

    # ─── 현재가치 할인 ──────────────────────────────────────
    discounted_fcf = []
    pv_fcf_sum = 0
    for i, fcf in enumerate(projected_fcf):
        pv = fcf / ((1 + wacc) ** (i + 1))
        discounted_fcf.append(pv)
        pv_fcf_sum += pv

    # ─── 터미널 밸류 (Gordon Growth Model) ────────────────
    terminal_fcf = projected_fcf[-1] * (1 + g / 100)
    terminal_value = terminal_fcf / (wacc - g / 100) if wacc > g / 100 else 0
    pv_terminal = terminal_value / ((1 + wacc) ** forecast_years)

    # ─── 기업가치 → 주주가치 ────────────────────────────────
    enterprise_value = pv_fcf_sum + pv_terminal
    equity_value = enterprise_value - data["net_debt"]

    # ─── 주당 가치 ─────────────────────────────────────────
    shares = data["shares_outstanding"]
    implied_price = equity_value / shares if shares and shares > 0 else 0
    current_price = data["current_price"] or 0

    # ─── 안전마진 ──────────────────────────────────────────
    if current_price > 0:
        margin_of_safety = (implied_price - current_price) / current_price * 100
    else:
        margin_of_safety = 0

    return {
        "beta": beta,
        "we": we,
        "wd": wd,
        "cost_of_equity": cost_of_equity,
        "cost_of_debt": cost_of_debt,
        "after_tax_cost_of_debt": after_tax_cost_of_debt,
        "wacc": wacc,
        "fcf_growth": fcf_growth,
        "historical_fcf": historical_fcf,
        "base_fcf": base_fcf,
        "projected_fcf": projected_fcf,
        "discounted_fcf": discounted_fcf,
        "pv_fcf_sum": pv_fcf_sum,
        "terminal_value": terminal_value,
        "pv_terminal": pv_terminal,
        "enterprise_value": enterprise_value,
        "net_debt": data["net_debt"],
        "equity_value": equity_value,
        "shares": shares,
        "implied_price": implied_price,
        "current_price": current_price,
        "margin_of_safety": margin_of_safety,
        "perpetual_growth": g / 100,
        "forecast_years": forecast_years,
    }


# ═══════════════════════════════════════════════════════════════════
#  민감도 분석
# ═══════════════════════════════════════════════════════════════════

def sensitivity_analysis(dcf_result: dict, data: dict, rf: float, erp: float,
                         tax_rate: float, beta: float) -> list:
    """WACC와 영구성장률을 변화시킨 5×5 민감도 테이블"""
    base_wacc = dcf_result["wacc"]
    base_g = dcf_result["perpetual_growth"]
    base_fcf = dcf_result["base_fcf"]
    fcf_growth = dcf_result["fcf_growth"]
    shares = dcf_result["shares"]
    net_debt = data["net_debt"]

    wacc_range = [base_wacc - 0.02, base_wacc - 0.01, base_wacc,
                  base_wacc + 0.01, base_wacc + 0.02]
    g_range = [base_g - 0.01, base_g - 0.005, base_g,
               base_g + 0.005, base_g + 0.01]

    matrix = []
    for g_val in g_range:
        row = []
        for wacc_val in wacc_range:
            if wacc_val <= g_val or base_fcf <= 0 or (not shares or shares <= 0):
                row.append(None)
                continue

            # FCF 예측
            pv_sum = 0
            current = base_fcf
            for yr in range(dcf_result["forecast_years"]):
                current *= (1 + fcf_growth)
                pv_sum += current / ((1 + wacc_val) ** (yr + 1))

            # 터미널 밸류
            term_fcf = current * (1 + g_val)
            tv = term_fcf / (wacc_val - g_val)
            pv_tv = tv / ((1 + wacc_val) ** dcf_result["forecast_years"])

            ev = pv_sum + pv_tv
            eq = ev - net_debt
            price = eq / shares if shares else 0
            row.append(price)
        matrix.append(row)

    return matrix, wacc_range, g_range


# ═══════════════════════════════════════════════════════════════════
#  출력 (Rich 포맷)
# ═══════════════════════════════════════════════════════════════════

def get_verdict(margin: float) -> tuple:
    """안전마진 기준 판정"""
    if margin > 25:
        return "🟢 과소평가 (Undervalued)", "green"
    elif margin > -10:
        return "🟡 적정평가 (Fairly Valued)", "yellow"
    else:
        return "🔴 고평가 (Overvalued)", "red"


def heatmap_cell(value: float, current_price: float) -> str:
    """민감도 테이블 셀 색상 결정"""
    if value is None or current_price <= 0:
        return "  N/A  "
    margin = (value - current_price) / current_price * 100
    if margin > 40:
        return f"[bold green]{value:>10,.0f}[/]"
    elif margin > 20:
        return f"[green]{value:>10,.0f}[/]"
    elif margin > 0:
        return f"[yellow]{value:>10,.0f}[/]"
    elif margin > -20:
        return f"[red]{value:>10,.0f}[/]"
    else:
        return f"[bold red]{value:>10,.0f}[/]"


def print_report(ticker: str, data: dict, dcf: dict, matrix: list,
                 wacc_range: list, g_range: list, console: Console,
                 rf: float = DEFAULT_RF):
    """DCF 분석 결과 리포트 출력"""

    current = dcf["current_price"]
    implied = dcf["implied_price"]
    mos = dcf["margin_of_safety"]
    verdict_text, verdict_color = get_verdict(mos)
    currency = data["currency"]
    rf_display = rf

    # ─── 헤더 ──────────────────────────────────────────────
    console.print()
    console.print(Panel(
        f"[bold white]{data['company_name']}[/] ([cyan]{ticker}[/])\n"
        f"[dim]분석 기준일: {datetime.now().strftime('%Y-%m-%d %H:%M')}[/]",
        title="📊 DCF 밸류에이션 분석",
        border_style="bright_blue",
        box=box.DOUBLE_EDGE
    ))

    # ─── 판정 요약 ──────────────────────────────────────────
    verdict_panel = Panel(
        f"[{verdict_color} bold]{verdict_text}[/]\n\n"
        f"현재가: [bold]{fmt_num(current, currency)}[/]    "
        f"목표가: [bold]{fmt_num(implied, currency)}[/]\n"
        f"안전마진: [bold {verdict_color}]{mos:+.1f}%[/]",
        title="🎯 밸류에이션 판정",
        border_style=verdict_color,
        box=box.ROUNDED
    )
    console.print(verdict_panel)

    # ─── WACC 구성 ──────────────────────────────────────────
    wacc_table = Table(
        title="📋 WACC (가중평균자본비용) 구성",
        box=box.SIMPLE,
        show_header=True,
        header_style="bold cyan"
    )
    wacc_table.add_column("항목", style="white")
    wacc_table.add_column("값", justify="right", style="white")
    wacc_table.add_row("무위험수익률 (rf)", f"{rf_display:.2f}%")
    wacc_table.add_row("베타 (β)", f"{dcf['beta']:.3f}")
    wacc_table.add_row("주식위험프리미엄 (ERP)", f"6.50%")
    wacc_table.add_row("자기자본비용 (Ke)", f"{dcf['cost_of_equity']*100:.2f}%")
    wacc_table.add_row("자본 비중 (We)", f"{dcf['we']*100:.1f}%")
    wacc_table.add_row("부채 비중 (Wd)", f"{dcf['wd']*100:.1f}%")
    wacc_table.add_row("세후 부채비용 (Kd)", f"{dcf['after_tax_cost_of_debt']*100:.2f}%")
    wacc_table.add_row("[bold]WACC[/]", f"[bold]{dcf['wacc']*100:.2f}%[/]")
    console.print(wacc_table)

    # ─── 5년 FCF 예측 ──────────────────────────────────────
    fcf_table = Table(
        title="📈 5년 자유현금흐름(FCF) 예측",
        box=box.SIMPLE,
        show_header=True,
        header_style="bold cyan"
    )
    fcf_table.add_column("연도", justify="center", style="white")
    fcf_table.add_column("FCF", justify="right", style="white")
    fcf_table.add_column("할인계수", justify="right", style="dim")
    fcf_table.add_column("현금흐름PV", justify="right", style="white")

    now_year = datetime.now().year
    for i in range(dcf["forecast_years"]):
        year = now_year + i + 1
        fcf = dcf["projected_fcf"][i]
        pv = dcf["discounted_fcf"][i]
        disc = 1 / ((1 + dcf["wacc"]) ** (i + 1))
        fcf_table.add_row(
            f"{year}E",
            fmt_num(fcf, currency),
            f"{disc:.4f}",
            fmt_num(pv, currency)
        )

    fcf_table.add_row(
        "[bold]PV 합계[/]",
        "",
        "",
        f"[bold]{fmt_num(dcf['pv_fcf_sum'], currency)}[/]"
    )
    console.print(fcf_table)

    # ─── 기업가치 → 주주가치 ────────────────────────────────
    val_table = Table(
        title="🏢 기업가치 → 주주가치 도출",
        box=box.SIMPLE,
        show_header=False
    )
    val_table.add_column("항목", style="white")
    val_table.add_column("금액", justify="right", style="white")
    val_table.add_row("FCF 현금흐름PV", fmt_num(dcf["pv_fcf_sum"], currency))
    val_table.add_row("터미널 밸류 PV", fmt_num(dcf["pv_terminal"], currency))
    val_table.add_row("[bold]기업가치 (EV)[/]", f"[bold]{fmt_num(dcf['enterprise_value'], currency)}[/]")
    val_table.add_row("(-) 순부채", fmt_num(-dcf["net_debt"], currency))
    val_table.add_row("[bold]주주가치 (Equity)[/]", f"[bold]{fmt_num(dcf['equity_value'], currency)}[/]")
    val_table.add_row("발행주식수", f"{dcf['shares']:,.0f}주" if dcf["shares"] else "N/A")
    val_table.add_row("[bold]주당 내재가치[/]",
                      f"[bold]{fmt_num(dcf['implied_price'], currency)}[/]")
    val_table.add_row("[bold]현재 주가[/]",
                      f"[bold]{fmt_num(dcf['current_price'], currency)}[/]")
    console.print(val_table)

    # ─── 민감도 분석 테이블 ──────────────────────────────────
    console.print()
    sens_title = f"🌡️ 민감도 분석 (WACC vs 영구성장률) — 단위: {currency}"
    console.print(Panel(sens_title, border_style="bright_cyan", box=box.SIMPLE))

    # 테이블 헤더
    label = "g\\WACC"
    header = f"{label:>10}"
    for w in wacc_range:
        header += f" | {w*100:.1f}%"
    console.print(f"[bold cyan]{header}[/]")
    console.print("─" * (len(header) + 20))

    # 테이블 행
    for i, g_val in enumerate(g_range):
        row_str = f"  {g_val*100:.1f}%  "
        for j in range(len(wacc_range)):
            val = matrix[i][j] if matrix else None
            cell = heatmap_cell(val, current)
            row_str += f" | {cell}"
        console.print(row_str)

    console.print()

    # ─── 범례 ──────────────────────────────────────────────
    console.print("[green]🟩 안전마진 > 40%[/]  [yellow]🟨 안전마진 0~40%[/]  "
                  "[red]🟥 안전마진 < 0%[/]")
    console.print()

    # ─── 과거 FCF 참고 ─────────────────────────────────────
    if any(f is not None for f in dcf["historical_fcf"]):
        hist_table = Table(
            title="📊 과거 FCF (참고용)",
            box=box.SIMPLE,
            show_header=True,
            header_style="bold cyan"
        )
        hist_table.add_column("기간", justify="center", style="white")
        hist_table.add_column("FCF", justify="right", style="white")
        years = list(data["income"].columns) if data["income"] is not None else []
        for i, fcf in enumerate(dcf["historical_fcf"]):
            yr_label = str(years[i].year) if i < len(years) and hasattr(years[i], 'year') else f"T-{len(dcf['historical_fcf'])-i}"
            hist_table.add_row(yr_label, fmt_num(fcf, currency) if fcf else "N/A")
        console.print(hist_table)

    # ─── 경고 ──────────────────────────────────────────────
    warnings_list = []
    if not data["current_price"]:
        warnings_list.append("⚠️ 현재 주가를 가져오지 못했습니다.")
    if dcf["base_fcf"] is None or dcf["base_fcf"] <= 0:
        warnings_list.append("⚠️ 기준 FCF가 0 이하입니다. 결과 신뢰도가 낮을 수 있습니다.")
    if not data["shares_outstanding"]:
        warnings_list.append("⚠️ 발행주식수를 가져오지 못했습니다.")
    if dcf["beta"] == DEFAULT_BETA:
        warnings_list.append("ℹ️ 기본 베타(1.0)를 사용했습니다. 실제 베타와 다를 수 있습니다.")

    missing_count = sum(1 for v in dcf["historical_fcf"] if v is None)
    if missing_count > 0:
        warnings_list.append(f"⚠️ 과거 재무데이터 중 {missing_count}개 항목이 누락되었습니다.")

    if warnings_list:
        console.print()
        for w in warnings_list:
            console.print(f"  {w}")

    console.print()
    console.print("[dim]※ 본 분석은 투자 참고용이며, 실제 투자 판단에 활용 시 추가 검증이 필요합니다.[/]")
    console.print()


# ═══════════════════════════════════════════════════════════════════
#  메인
# ═══════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(
        description="한국 주식 DCF (할인현금흐름) 밸류에이션",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
사용 예시:
  python3 dcf.py 005930.KS
  python3 dcf.py 000660.KS --period 5y
  python3 dcf.py 005930.KS --rf 3.0 --erp 7.0 --growth 2.5
        """
    )
    parser.add_argument("ticker", help="종목 티커 (예: 005930.KS, 000660.KS)")
    parser.add_argument("--period", default="5y", help="과거 데이터 기간 (기본: 5y)")
    parser.add_argument("--rf", type=float, default=DEFAULT_RF,
                        help=f"무위험수익률 (기본: {DEFAULT_RF}pct)")
    parser.add_argument("--erp", type=float, default=DEFAULT_ERP,
                        help=f"주식위험프리미엄 (기본: {DEFAULT_ERP}pct)")
    parser.add_argument("--tax", type=float, default=DEFAULT_TAX,
                        help=f"법인세율 (기본: {DEFAULT_TAX}pct)")
    parser.add_argument("--growth", type=float, default=DEFAULT_GROWTH,
                        help=f"영구성장률 (기본: {DEFAULT_GROWTH}pct)")
    parser.add_argument("--beta", type=float, default=None,
                        help="베타 수동 입력 (미입력 시 자동 계산)")

    args = parser.parse_args()

    console = Console()

    # ─── 데이터 수집 ────────────────────────────────────────
    try:
        data = fetch_financials(args.ticker, args.period, console)
    except Exception as e:
        console.print(f"[bold red]❌ 데이터 수집 실패: {e}[/]")
        sys.exit(1)

    if data["current_price"] is None:
        console.print("[yellow]⚠️ 현재 주가를 가져올 수 없습니다. yfinance 데이터를 확인하세요.[/]")

    # ─── 베타 계산 ──────────────────────────────────────────
    if args.beta is not None:
        beta = max(0.3, min(2.5, args.beta))
        console.print(f"[dim]ℹ️ 수동 입력 베타 사용: {beta:.3f}[/]")
    else:
        # yfinance 베타 시도 → 자동 계산 → 기본값
        yf_beta = get_yfinance_beta(yf.Ticker(args.ticker))
        if yf_beta:
            beta = yf_beta
            console.print(f"[dim]ℹ️ yfinance 베타 사용: {beta:.3f}[/]")
        else:
            calc_beta = compute_beta(args.ticker, args.period)
            if calc_beta != DEFAULT_BETA:
                beta = calc_beta
                console.print(f"[dim]ℹ️ 자동 계산 베타 (vs 코스피): {beta:.3f}[/]")
            else:
                beta = DEFAULT_BETA
                console.print(f"[yellow]⚠️ 베타 자동 계산 실패, 기본값 사용: {beta:.3f}[/]")

    # ─── DCF 계산 ──────────────────────────────────────────
    dcf = calculate_dcf(
        data=data,
        rf=args.rf,
        erp=args.erp,
        tax_rate=args.tax,
        g=args.growth,
        beta=beta,
    )

    # ─── 민감도 분석 ────────────────────────────────────────
    matrix, wacc_range, g_range = sensitivity_analysis(
        dcf, data, args.rf, args.erp, args.tax, beta
    )

    # ─── 결과 출력 ──────────────────────────────────────────
    print_report(args.ticker, data, dcf, matrix, wacc_range, g_range, console, rf=args.rf)


if __name__ == "__main__":
    main()
