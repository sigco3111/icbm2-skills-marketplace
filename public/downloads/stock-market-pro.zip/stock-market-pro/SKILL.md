---
name: stock-market-pro
description: >-
  Yahoo Finance (yfinance) powered stock analysis skill: quotes, fundamentals,
  ASCII trends, high-resolution charts (RSI/MACD/BB/VWAP/ATR), plus optional
  web add-ons (news + browser-first options/flow).
---

# Stock Market Pro

**Stock Market Pro** is a fast, local-first market research toolkit with 3-tier data fallback.
Get clean price + fundamentals, generate publication-ready charts with indicator panels (RSI/MACD/BB/VWAP/ATR), run DCF valuation (Korean parameters), and run a one-shot report that outputs both a summary and a high-res PNG.
Optional add-ons: quick news link sweep (DDG) + browser-first options/flow (Unusual Whales).

## Data Fallback Chain
모든 데이터 조회는 3단계 폴백 체인으로 안정성 확보:
1. **yfinance** (기본) — 가장 빠름
2. **pykrx** (한국 주식 .KS/.KQ 전용) — 한국 거래소 직접 조회
3. **Yahoo Finance v8 API** (직접 호출) — 최후 수단

폴백 발생 시 터미널에 `[dim]데이터 소스: pykrx[/dim]` 표시.

## What you can do
- Get **real-time quotes** (price + change)
- Summarize **fundamentals** (Market Cap, Forward PE, EPS, ROE)
- Print **ASCII trends** (terminal-friendly)
- Generate **high-resolution PNG charts** with overlays/panels:
  - RSI / MACD / Bollinger Bands / VWAP / ATR
- Run **DCF valuation** with Korean market parameters (rf=2.8%, ERP=6.5%, tax=22%, g=2.0%)
- Run a **one-shot report** that prints a compact summary and emits a chart path
- Search **news links** via DuckDuckGo (ddgs)
- Open **options / flow pages** (browser-first, Unusual Whales)

---

## Commands (Local)

> This skill uses `uv run --script` for dependency handling.
> If you don't have `uv`: install from https://github.com/astral-sh/uv

### 1) Quotes
```bash
uv run --script scripts/yf.py price TSLA
# shorthand
uv run --script scripts/yf.py TSLA
```

### 2) Fundamentals
```bash
uv run --script scripts/yf.py fundamentals NVDA
```

### 3) ASCII trend
```bash
uv run --script scripts/yf.py history AAPL 6mo
```

### 4) Pro chart (PNG)
```bash
# candlestick (default)
uv run --script scripts/yf.py pro 000660.KS 6mo

# line chart
uv run --script scripts/yf.py pro 000660.KS 6mo line
```

#### Indicators (optional)
```bash
uv run --script scripts/yf.py pro TSLA 6mo --rsi --macd --bb
uv run --script scripts/yf.py pro TSLA 6mo --vwap --atr
```

- `--rsi` : RSI(14)
- `--macd`: MACD(12,26,9)
- `--bb`  : Bollinger Bands(20,2)
- `--vwap`: VWAP (cumulative over the selected range)
- `--atr` : ATR(14)

### 5) DCF Valuation (Korean Market Parameters)
```bash
python3 scripts/dcf.py 005930.KS          # 삼성전자 DCF 분석
python3 scripts/dcf.py 000660.KS --period 5y  # SK하이닉스 (5년 데이터)
python3 scripts/dcf.py AAPL                # 미국 주식도 가능
```

Korean defaults: rf=2.8%, ERP=6.5%, tax=22%, g=2.0%. Custom override: `--rf 3.0 --beta 1.2 --growth 2.5`
출력: WACC 구성, 5년 FCF 예측, 기업가치→주주가치, 목표가 vs 현재가, 안전마진, 5×5 민감도 히트맵

### 6) One-shot report
Prints a compact text summary and generates a chart PNG.

```bash
uv run --script scripts/yf.py report 000660.KS 6mo
# output includes: CHART_PATH:/tmp/<...>.png
```

> Optional web add-ons (news/options) can be appended by the agent workflow.

---

## Web Add-ons (Optional)

### A) News search (DuckDuckGo via `ddgs`)
This skill vendors a helper script (`scripts/ddg_search.py`).

Dependency:
```bash
pip3 install -U ddgs
```

Run:
```bash
python3 scripts/news.py NVDA --max 8
# or
python3 scripts/ddg_search.py "NVDA earnings guidance" --kind news --max 8 --out md
```

### B) Options / Flow (browser-first)
Unusual Whales frequently blocks scraping/headless access.
So the recommended approach is: **open the pages in a browser and summarize what you can see**.

Quick link helper:
```bash
python3 scripts/options_links.py NVDA
```

Common URLs:
- `https://unusualwhales.com/stock/{TICKER}/overview`
- `https://unusualwhales.com/live-options-flow?ticker_symbol={TICKER}`
- `https://unusualwhales.com/stock/{TICKER}/options-flow-history`

---

## Subcommands (yf.py)
`yf.py` supports:
- `price`
- `fundamentals`
- `history`
- `pro`
- `chart` (alias)
- `report`
- `option` (best-effort; browser fallback recommended)

Check:
```bash
python3 scripts/yf.py --help
```

## Ticker examples
- US: `AAPL`, `NVDA`, `TSLA`
- KR: `005930.KS`, `000660.KS`
- Crypto: `BTC-USD`, `ETH-KRW`
- FX: `USDKRW=X`
