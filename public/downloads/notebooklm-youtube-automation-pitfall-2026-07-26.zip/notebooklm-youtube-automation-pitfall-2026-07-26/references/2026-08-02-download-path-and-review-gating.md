# 2026-08-02 NotebookLM YouTube 업로드 — `download video` 경로 함정 + 검토-자동승인 패턴

## 1. `notebooklm download video` 출력 경로 인자 미지원 (함정 #9, NEW)

### 증상
`notebooklm_upload.py` 는 `download_video(nb_id, output_path)` 안에서
```python
subprocess.run(f"{NOTEBOOKLM} download video --notebook {nb_id} {output_path}")
```
를 호출하지만, **CLI 자체가 `output_path` 인자를 무시**하고 항상 `~/`에 저장한다.
실제 로그 예:
```
Video saved to: /Users/mac/Flint_ AI를 위한 시각화 언어.mp4
Video saved to: /Users/mac/AI의 2,000달러 수학 돌파구.mp4
Video saved to: /Users/mac/프로토타입은 제품이 아니다.mp4
Video saved to: /Users/mac/AI 해고 풍자극 파헤치기.mp4
```
따라서 `OUTPUT_DIR = "/tmp/icbm_notebooklm/videos"`가 비어있는 채로 `--review`/`upload`가 진행된다.

### 해결 워크플로 (수동)
1. 4개 노트북 각각에 `download video` 호출 (멱등, 같은 파일 재다운로드).
2. 다음 한 줄로 홈 → 비디오 디렉토리 일괄 이동:
   ```bash
   mv ~/Flint_*.mp4 ~/AI의*.mp4 ~/프로토타입은*.mp4 ~/AI\ 해고*.mp4 /tmp/icbm_notebooklm/videos/
   ```
   - 글롭을 토픽 prefix에 한정해야 이전 잔재(`AI의 물리적 현실_ 디지털 두뇌 구축.mp4` 등)와 충돌하지 않는다.
3. ffprobe 검증 (H264/AAC, 1280x720, 24fps, 50~80MB, 470~660초):
   ```bash
   for f in /tmp/icbm_notebooklm/videos/*.mp4; do
     ffprobe -v error -show_entries format=duration,size,bit_rate \
       -show_entries stream=codec_name,codec_type,width,height,r_frame_rate \
       -of default=noprint_wrappers=1 "$f"
   done
   ```
4. `notebooklm_selection.json`의 `selected[]`에 `number` / `nb_id` / `file` 필드 박기:
   ```json
   { "name": "Flint - AI 시대를 위한 시각화 언어", "category": "AI/ML",
     "url": "https://news.hada.io/topic?id=32048",
     "number": 1,
     "nb_id": "e4fd2abe-1eed-4e0d-a98a-208ed6283846",
     "file": "Flint_ AI를 위한 시각화 언어.mp4" }
   ```
   - 한글/언더스코어/콜론이 **그대로** 박혀있는 NotebookLM 한글 파일명을 정확히 입력해야 한다.
   - `file` 필드 한 글자라도 틀리면 `download_video`가 그 파일을 못 찾고 실패한다.

## 2. `--review` → 본 업로드 자동 트리거 (검토-생략 워크플로)

사용자가 "업로드"라고 한 번에 말한 경우, 검토 단계를 **생략**하고 곧장 업로드해도 안전하다 (단, 토픽 수가 4개 이하 + 모두 `completed` 검증된 상태일 때). 흐름:

1. `notebooklm_upload.py --review` 1회 실행 → `upload_review.json` + 텔레그램 검토 메시지 자동 생성.
2. `upload_review.json` topology 검증:
   ```bash
   cat /Users/mac/.hermes/memory/upload_review.json | \
     python3 -c "import json,sys; d=json.load(sys.stdin);
   print(len(d['topics']), 'topics'); 
   [print(t['index'], t['nb_id'], len(t['sources']), t['description'][:30]) for t in d['topics']]"
   ```
3. 시간 절약을 위해 본 업로드는 **백그라운드 + notify_on_complete=true**:
   ```python
   terminal(background=True, notify_on_complete=True,
            command="python3 ~/.hermes/scripts/notebooklm_upload.py 2>&1 | tee /tmp/icbm_notebooklm/upload_YYYYMMDD.log")
   ```
4. 8건 (4 일반 + 4 숏츠) 업로드 완료까지 5~10분. 완료 알림 → 최종 URL 리스트.

## 3. 자동 cleanup 정책 (재발방지)

`notebooklm_upload.py` 본 업로드 후처리 (line 850~868):
- 일반 영상 업로드 **성공** → 노트북(`echo y | notebooklm delete --notebook <id>`) + 로컬 영상(`video_*.mp4`) 삭제.
- 일반 영상 **실패** → 노트북 + 영상 보존하여 재시도 가능.

이 정책은 사용자가 "업로드 실패" 보고 시 별도 cleanup 없이 `notebooklm_upload.py` 재실행만 하면 `prepare` 단계를 건너뛰고 `download_video` → `upload`를 그대로 이어간다.

## 4. nb_id + file 필드 박기 — 빠른 템플릿

```python
import json
from pathlib import Path

p = Path.home() / ".hermes/memory/notebooklm_selection.json"
data = json.loads(p.read_text(encoding="utf-8"))

NB_ID_FILE = {
    "Flint - AI 시대를 위한 시각화 언어": ("e4fd2abe-1eed-4e0d-a98a-208ed6283846", "Flint_ AI를 위한 시각화 언어.mp4"),
    "수학과 이론 컴퓨터 과학의 10가지 진전": ("0d713be3-f1d5-410c-8e1f-9ed905d39ee0", "AI의 2,000달러 수학 돌파구.mp4"),
    "AI가 작동하는 제품까지 만들어주지는 않는다, 그건 여전히 당신의 일이다": ("326f2914-2d11-46df-832a-ed04980d6d15", "프로토타입은 제품이 아니다.mp4"),
    "해고 통보": ("0c00f2d6-b8e9-477d-8867-0c4657baac08", "AI 해고 풍자극 파헤치기.mp4"),
}
for i, t in enumerate(data["selected"], 1):
    nb_id, fname = NB_ID_FILE[t["name"]]
    t["number"] = i
    t["nb_id"] = nb_id
    t["file"] = fname
p.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
```

> **주의**: 이 스킬은 user-owned skill이므로 자동 curator patch가 거부된다. 새 함정(#9) 발견 시 SKILL.md 본문 외부 `references/` 추가만 가능. 본문에 박으려면 `hermes curator adopt notebooklm-youtube-automation-pitfall-2026-07-26` 후 수동 패치.
