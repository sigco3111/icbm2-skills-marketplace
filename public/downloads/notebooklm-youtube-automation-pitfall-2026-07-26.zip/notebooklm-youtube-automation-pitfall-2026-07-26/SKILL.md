---
name: notebooklm-youtube-automation-pitfall-2026-07-26
description: "NotebookLM YouTube 자동화 SKILL 보완 — 어제 selected 키 잔재 + date mismatch 잠금 + '정정 사이클' 워크플로우. 2026-07-26 세션에서 발견."
version: 1.0.1
metadata:
  updated: 2026-08-02
references:
  - 2026-08-02-download-path-and-review-gating.md
---

# NotebookLM YouTube 자동화 — 2026-07-26 신규 함정

## 🚨 함정 11: 어제 `selected` 키가 selection.json에 남아있음

`notebooklm_prepare.py` L221: `selected = selection.get("selected", [])` — **`selected` 키가 있으면 `selection_numbers`를 무시**.

증상: 사용자가 오늘 [2,3,4,12] 선택 → `selection_numbers` 패치 → prepare 실행 → **어제 selected 4개 topic으로 노트북 만들어짐.**

원인: 어제 업로드 파이프라인이 `selected` 키에 어제 검토 4개 topic dict를 저장해뒀고, 오늘 `selection_numbers`만 패치하면 `selected`는 그대로.

**판별**: 
```bash
python3 -c "import json; d=json.load(open('/Users/mac/.hermes/memory/notebooklm_selection.json')); print('selected:', d.get('selected'), '\nselection_numbers:', d.get('selection_numbers'))"
```
- `selected` 있고 `selection_numbers` 다른 번호 → 위험
- `selected=[]` 비어있음 → 안전 (selection_numbers 사용)

**해결**: prepare 실행 전 `selected` 키를 사용자 의도대로 교체:
```python
import json
p = '/Users/mac/.hermes/memory/notebooklm_selection.json'
d = json.load(open(p))
nums = d.get('selection_numbers', [])
all_topics = d.get('topics', [])
d['selected'] = [all_topics[i-1] for i in nums if 0 < i <= len(all_topics)]
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
```

---

## 🚨 함정 12: date mismatch 잠금 (자정 넘김)

`notebooklm_upload.py` L668-680 (--approved)와 L521-524 (--review) 모두:

```python
today = datetime.now(KST).strftime("%Y-%m-%d")
if selection.get("date") != today:
    log(f"❌ 선택 파일 날짜가 오늘({today})이 아닙니다.")
    return
```

→ 어제 만들어진 검토/선택 데이터는 **자정만 넘기면 stale 처리**되어 자동화 fail.

**기존 메모**: mp4가 `/tmp/icbm_notebooklm/`에 남으면 nb_id로 **수동 보완 가능** (함정 10).

**신규 발견 (2026-07-26)**: 4번 주제 mp4가 어제 NotebookLM에 **status=completed** 상태로 보존됨 → `notebooklm download video -n <nb_id> --force` 로 재다운로드 후 `make_shorts()` + `upload_to_youtube()` 직접 호출해서 업로드 가능.

```python
# topic4 보완 패턴 (성공 케이스)
from notebooklm_upload import make_shorts, upload_to_youtube
video_path = "/tmp/icbm_notebooklm/<topic>.mp4"
shorts_path = "/tmp/icbm_notebooklm/shorts_4_<date>.mp4"
make_shorts(video_path, shorts_path)
upload_to_youtube(video_path, title, description, tags)
upload_to_youtube(shorts_path, shorts_title, description, tags)
```

또한 **date 패치**는 selection.json / upload_review.json 둘 다 동일하게:
```bash
# 07-25 → 07-26 패치 (백업 필수)
ts=$(date +%s)
cp ~/.hermes/memory/notebooklm_selection.json ~/.hermes/memory/notebooklm_selection.json.bak_pre_datepatch_$ts
cp ~/.hermes/memory/upload_review.json ~/.hermes/memory/upload_review.json.bak_pre_datepatch_$ts
# → sed/python으로 patch
```

---

## 🚨 함정 13: 같은 `topic_id`라도 어제/오늘 다른 nb_id

Cron 16:00 후보가 **Notion DB 갱신 시점에 따라** 매번 다른 12개. 어제 [2]번이 Claude 5 컨텍스트였어도 오늘 [2]번은 Claude Opus 5 지능 리더보드 (다른 topic).

→ 사용자가 어제 본 후보 번호[2,3,4,12]를 그대로 외워서 오늘 선택해도 **다른 topic**이 진행됨.

**대응**: cron 응답에 포함된 후보 **이름**을 사용자에게 직접 보여주고 확인 받는 게 안전. 또는 selection.json의 topics와 사용자가 본 cron 응답 텍스트와 비교 검증.

---

## 🚨 함정 14: "정정 사이클" 워크플로우 — 사용자가 "처음부터 다시" 요청할 때

이번 세션에서 사용자 피드백: "너 무슨 짓을 하는거지? 다시 오늘 16시 크론 실행부터 다시 시작해"

원인: 제가 잘못 분석해서 잘못된 nb_id 4개 만들고, 그걸 다시 분석하고, 다시 만들고, 사용자가 한 번 더 clarify 응답 받고... 시간 낭비.

**교훈**: 
1. **사용자의 "정정" 요청 받으면 즉시 멈추고 깨끗하게 리셋**
2. **`selection.json` 빈 `{}`로 만들고 cron `notebooklm_selection.py` 재실행** (드라이런 말고 실제)
3. **사용자 선택 다시 받기 (직전 선택 잊지 말 것)**
4. **Auth 풀렸는지 확인 후 진행**

```bash
# 깨끗한 리셋
ts=$(date +%s)
cp ~/.hermes/memory/notebooklm_selection.json ~/.hermes/memory/notebooklm_selection.json.bak_pre_cron_reset_$ts
cp ~/.hermes/memory/upload_review.json ~/.hermes/memory/upload_review.json.bak_pre_cron_reset_$ts
echo '{}' > ~/.hermes/memory/notebooklm_selection.json

# cron 재실행 (드라이런 X)
source ~/.hermes/venv-notebooklm/bin/activate
python3 ~/.hermes/scripts/notebooklm_selection.py
```

---

## 📋 함정 11-14 빠른 참조

| # | 증상 | 진단 | 해결 |
|---|------|------|------|
| 11 | prepare가 어제 topic으로 진행 | `selected` 키 체크 | `selected=[]` 비우고 selection_numbers만 사용 |
| 12 | --approved/--review date 락 | date 필드 비교 | date 패치 + mp4 nb_id 기반 수동 보완 |
| 13 | 같은 번호, 다른 topic | topics 이름 확인 | 사용자 응답 후보와 selection.json 대조 |
| 14 | "처음부터 다시" 요청 | 어지러운 상태 | cron reset 백업 + 빈 {} + cron 재실행 |

---

## 🔗 SKILL.md 본 함수정 보완

기존 `notebooklm-youtube-automation/SKILL.md`의 `## 트리거 키워드` 다음에 위 함정 11-14 추가 권장 (umbrella SKILL의 pitfalls.md가 remove-existing 다시 작성 필요 시 직접 패치).
