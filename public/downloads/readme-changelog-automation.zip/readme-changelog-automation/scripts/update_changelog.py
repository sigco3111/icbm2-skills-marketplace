#!/usr/bin/env python3
"""
README Changelog 자동화 스크립트
- CHANGELOG.md 에 오늘 날짜로 로그 추가
- Git 커밋 및 푸시 자동 실행
"""

import sys
import datetime
import subprocess
import os

def update_changelog(log_entry):
    changelog_path = "/Users/hjshin/hermes_bot/CHANGELOG.md"
    today = datetime.datetime.now().strftime("%Y-%m-%d")
    new_entry = f"- {today}: {log_entry}\n"

    # 파일이 없으면 생성
    if not os.path.exists(changelog_path):
        with open(changelog_path, 'w', encoding='utf-8') as f:
            f.write("# 📝 변경 이력\n\n")

    # 파일 읽기
    with open(changelog_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()

    # "## 📅 업데이트 로그" 또는 "# 📝 변경 이력" 섹션 찾기
    target_idx = -1
    for i, line in enumerate(lines):
        if "## 📅 업데이트 로그" in line or "# 📝 변경 이력" in line:
            target_idx = i + 1
            break

    if target_idx == -1:
        # 섹션이 없으면 맨 앞에 추가
        lines.insert(0, f"{new_entry}\n")
    else:
        # 섹션 다음 줄에 추가
        lines.insert(target_idx, new_entry)

    # 파일 쓰기
    with open(changelog_path, 'w', encoding='utf-8') as f:
        f.writelines(lines)

    print(f"✅ CHANGELOG.md 업데이트 완료: {new_entry.strip()}")

    # Git 커밋 및 푸시
    try:
        subprocess.run(["git", "add", "CHANGELOG.md"], check=True, cwd="/Users/hjshin/hermes_bot")
        commit_msg = f"{today}: 📝 {log_entry}"
        subprocess.run(["git", "commit", "-m", commit_msg], check=True, cwd="/Users/hjshin/hermes_bot")
        subprocess.run(["git", "push"], check=True, cwd="/Users/hjshin/hermes_bot")
        print(f"✅ Git 커밋 및 푸시 완료: {commit_msg}")
    except subprocess.CalledProcessError as e:
        print(f"❌ Git 작업 실패: {e}")
        sys.exit(1)

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python update_changelog.py '변경 내용'")
        sys.exit(1)
    update_changelog(sys.argv[1])
