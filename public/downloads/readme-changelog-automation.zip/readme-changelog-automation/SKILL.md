---
name: readme-changelog-automation
description: README 및 CHANGELOG 자동화 업데이트 스크립트 실행
---

# README & Changelog 자동화 업데이트

**트리거:** 문서 (README, CHANGELOG, AUTOMATION, SKILLS) 업데이트 요청 시.

## 1. 변경 내용 기록 (가장 중요)
사용자가 변경 내용을 말하면 (예: "Qwen3.5 모델로 교체 완료"), **AI 는 텍스트를 생성하지 않고 스크립트만 실행**합니다.

### 실행 명령어
```bash
python ~/.hermes/scripts/update_changelog.py "변경 내용"
```
- **자동 수행:**
  1. 오늘 날짜를 붙여 `CHANGELOG.md` 에 로그 추가.
  2. Git 커밋 (`git add . && git commit -m "2026-04-24: 📝 변경 내용"`).
  3. Git 푸시 (`git push`).
- **주의:** 스트리밍 중단 위험 제거 (AI 가 긴 텍스트 생성 안 함).

## 2. 파일 구조
- `README.md`: 개요 및 빠른 시작 (1~2 페이지).
- `CHANGELOG.md`: 모든 업데이트 로그.
- `AUTOMATION_SCHEDULE.md`: 크론 잡 및 스크립트 내역.
- `SKILLS_CATALOG.md`: 스킬 통계 및 설명.

## 3. 수동 업데이트 시 (스크립트 불가)
만약 스크립트가 없다면:
1. **찾는 문자열 최소화:** `patch` 도구 사용 시 `"- 2026-04-23: ..."` 대신 `"- 2026-04-24: ..."` 만 포함.
2. **커밋 메시지 분리:** `git commit -m "간단 요약"` 사용.
3. **파일 분리:** 긴 내용은 `CHANGELOG.md` 에 기록.

## 4. 검증
- `git log --oneline` 으로 커밋 확인.
- `CHANGELOG.md` 최신 줄 확인.