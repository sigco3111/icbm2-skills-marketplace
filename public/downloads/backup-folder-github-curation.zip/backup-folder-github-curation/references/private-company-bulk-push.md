# 대용량 비공개 자료 일괄 푸시 워크플로우 (Private Bulk Push)

> 2026-07-31 검증 — `/Users/mac/work/backup/02-private/01-회사-외주-자료/` (17GB) → 30개 비공개 저장소로 분할 후 푸시.

## 핵심 통찰

### GitHub 푸시 안정 한계 (실측)
- **pack 1GB 이하**: 5~15분 안정 푸시
- **pack 1~1.3GB**: 간헐적 HTTP 408 timeout (재시도 시에도 영구 실패 가능)
- **pack 1.3GB+**: 거의 항상 실패 — **분할이 유일한 해결**
- **pack 2GB+**: 절대 실패 (예: `private-company-tycoon` 초기 시도에서 timeout)

### 권장 저장소 상한
- 5GB 이하 / pack 1GB 이하 / 파일 50,000개 이하 / 단일 파일 50MB 이하
- PSD/원화/영상 zip은 `.large_files_excluded/`로 분리

## 작업 사본 폴더 분리

```text
/Users/mac/work/
├── github/                  ← 공개 저장소 작업 사본
├── github-private/          ← 비공개 저장소 작업 사본 (NEW, 2026-07-31)
└── backup/                  ← 원본 (절대 수정 금지)
```

이 분리 덕분에 `private-company-arcade`(공개 작업 중)와 `private-company-tycoon`(비공개 작업 중)을 같은 이름으로 작업해도 실수 방지.

## 검증된 분할 사례 (17GB → 30개 저장소 → 19개 푸시 성공)

### 초기 분할 (17GB → 30개 저장소)
- 원본 `/Users/mac/work/backup/02-private/01-회사-외주-자료/` 17GB
- 큰 폴더별 별도 저장소로 분할:
  - **RPG 건블레이드 3GB** → proto/planning/assets 3개
  - **NDS DS고스톱 2.7GB** → artwork/sound/misc/planning 4개
  - **마법상점DS 2.6GB** → screenshots/sound/planning 3개
  - **타이쿤 3GB** → magicstore1/2/3-images/3-sound + tractor + beauty + 메인 7개
- 50MB+ 단일 파일은 모두 `.large_files_excluded/`로 자동 이동

### 실제 푸시 결과 (2026-07-31)

| 단계 | 저장소 | 크기 | 결과 |
|---|---|---|---|
| **Phase 0 단독 테스트** | `private-company-arcade` | 1.2GB | ✅ 12분 소요, 푸시 성공 |
| **Phase 0 실패 사례** | `private-company-tycoon` (단일 1.3GB) | 1.3GB | ❌ HTTP 408 timeout, 영구 실패 |
| **Phase 0 → 분할 정복** | `private-company-tycoon` (분할 후 메인 + 6개) | 1.9GB + 6개 | ✅ 분할 후 모두 푸시 가능 |
| **Round 1: 9개 푸시** | (옵션 A: 작은 저장소) | 22MB~597MB | ✅ 9/9 성공, ~1.5시간 |
| **Round 2: 10개 푸시** | (옵션 A 계속: 중간 크기) | 7MB~887MB | 🔄 5/10 완료, 진행 중 |

### Round 1 (작은 저장소 9개) — 검증된 성공 사례
| 저장소 | 크기 | 푸시 시간 |
|---|---|---|
| private-company-tycoon-magicstore3-sound | 33MB | ~30초 |
| private-company-secrets-1 | 22MB | ~30초 |
| private-company-proposal | 32MB | ~30초 |
| private-company-tycoon-tractor | 95MB | ~1분 |
| private-company-nds-dsgostop-planning | 140MB | ~1분 |
| private-company-nds-dsgostop-misc | 285MB | ~3분 |
| private-company-rpg-gunblade-assets | 283MB | ~3분 |
| private-company-tycoon-magicstore3-images | 307MB | ~3분 |
| private-company-nds-magicstore-sound | 597MB | ~5분 |

## 검증된 Python 워크플로우

### 1. 작업 사본 분할

```python
import shutil
from pathlib import Path

SRC = Path('/Users/mac/work/backup/02-private/01-회사-외주-자료')
DST = Path('/Users/mac/work/github-private')

# 제외 패턴 (빌드 산출물)
exclude = ('*.opt','*.plg','*.ncb','*.positions','*.sbr','*.obj',
           '*.pdb','*.idb','*.ilk','*.bsc','*.res','*.tlog',
           '*.exe','*.aps','*.suo','MFC*.TMP','~VC*.TMP',
           'vc60.*','vc70.*','BuildLog.htm','*.bak','*.tmp','ALZ*.TMP','.DS_Store')

def copy_item(src, target):
    """파일/폴더 모두 지원 (공백/한글 파일명 안전)"""
    target.mkdir(parents=True, exist_ok=True)
    dst = target / src.name
    if src.is_file():
        shutil.copy2(src, dst)
    elif src.is_dir():
        if dst.exists(): shutil.rmtree(dst)
        shutil.copytree(src, dst, ignore=shutil.ignore_patterns(*exclude))

repos = [
    # (저장소명, [원본 폴더 경로들])
    ('private-company-rpg-gunblade-proto', [SRC/'기획/3. RPG/건블레이드/건블레이드 세컨드 임팩트']),
    ('private-company-rpg-gunblade-planning', [
        SRC/'기획/3. RPG/건블레이드/건블_세부기획',
        SRC/'기획/3. RPG/건블레이드/건블레이드 최종_신기보',
        SRC/'기획/3. RPG/건블레이드/건블레이드우수게임제안서',
        SRC/'기획/3. RPG/건블레이드/넥슨PT',
    ]),
    # ... 등등 30개
]
for name, sources in repos:
    target = DST / name
    if target.exists(): shutil.rmtree(target)
    target.mkdir(parents=True)
    for s in sources:
        if not s.exists(): continue
        copy_item(s, target)
    total = sum(f.stat().st_size for f in target.rglob('*') if f.is_file())
    print(f'  ✅ {name}: {total/1024/1024:.1f}MB')
```

### 2. 50MB+ 단일 파일 제외

```python
DST = Path('/Users/mac/work/github-private')
SIZE_LIMIT = 50 * 1024 * 1024

repos = [d for d in DST.iterdir() if d.is_dir() and d.name.startswith('private-company-')]

for repo in repos:
    excl = repo / '.large_files_excluded'
    excl.mkdir(exist_ok=True)
    gitignore = repo / '.gitignore'
    if gitignore.exists():
        content = gitignore.read_text()
        if '.large_files_excluded/' not in content:
            with gitignore.open('a') as f:
                f.write('\n# 50MB+ 파일 (GitHub 푸시 부담/거부 방지)\n.large_files_excluded/\n')

    big = []
    for f in repo.rglob('*'):
        if not f.is_file(): continue
        if '.git' in f.parts or '.large_files_excluded' in f.parts: continue
        try:
            if f.stat().st_size > SIZE_LIMIT:
                big.append(f)
        except (FileNotFoundError, PermissionError):
            continue

    for f in big:
        rel = f.relative_to(repo)
        target = excl / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        try:
            shutil.move(str(f), str(target))
        except FileNotFoundError:
            pass
```

### 3. README 11섹션 + .gitignore + LICENSE + git init/commit 일괄 (30개)

```python
import subprocess
from pathlib import Path

DST = Path('/Users/mac/work/github-private')

REPOS = [
    # (저장소명, 풀네임, 카테고리, 출처, 용도)
    ('private-company-rpg-gunblade-proto', '건블레이드 RPG 본 게임 자료', 'RPG 게임', '...', '...'),
    # ... 30개
]

GITIGNORE = """# macOS
.DS_Store

# Visual C++ 6 / Visual Studio
*.opt
*.plg
*.ncb
*.positions
*.aps
*.suo
*.user
*.userosscache
*.sdf
*.obj
*.sbr
*.exe
*.pdb
*.idb
*.pch
*.ilk
*.bsc
*.res
*.tlog
BuildLog.htm

# macOS XCode / iOS
*.dSYM
*.xcuserstate

# Android
*.apk
*.aab
*.dex
*.class
bin/
gen/
out/
release/
.gradle/
local.properties
*.iml
.idea/

# NDS/DSi
*.nds

# GP32
*.fxe
*.elf
*.gxb

# DirectX / Win32
*.bsc
*.idb

# 임시/백업 파일
*.bak
*.tmp
*.swp
*.orig
*.rej

# 50MB+ 파일
.large_files_excluded/
"""

LICENSE_MIT = """MIT License

Copyright (c) 2026 sigco3111

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

## ⚠️ 본 저장소의 콘텐츠에 대한 고지

본 저장소는 회사 외주/기획 자료입니다. 외부 공유/배포 시 NDA 위반 및 저작권 침해에 해당할 수 있습니다.
"""

def make_readme(repo_name, full_name, category, source, purpose, root):
    """11섹션 README 자동 생성"""
    files = list(root.rglob('*'))
    file_count = sum(1 for f in files if f.is_file())
    total_size = sum(f.stat().st_size for f in files if f.is_file())
    total_mb = total_size / 1024 / 1024
    
    # 폴더 트리 (최상위 5개)
    top_dirs = sorted({f.parts[1] for f in files if f.is_file() and len(f.parts) > 1})[:5]
    
    # 확장자 분포 (상위 10)
    from collections import Counter
    exts = Counter(f.suffix.lower() for f in files if f.is_file() and f.suffix)
    top_exts = exts.most_common(10)
    
    badges = (
        f'![visibility](https://img.shields.io/badge/visibility-PRIVATE-red?style=flat-square) '
        f'![category](https://img.shields.io/badge/category-{category.replace(" ", "_")}-blue?style=flat-square) '
        f'![files](https://img.shields.io/badge/files-{file_count:,}-green?style=flat-square) '
        f'![license](https://img.shields.io/badge/license-MIT-purple?style=flat-square)'
    )
    
    return f"""# 🔒 {full_name}

> ⚠️ **이 저장소는 비공개입니다.** 본인만 접근 가능. 회사 외주 자료.

{badges}

## 📋 개요

| 항목 | 값 |
|---|---|
| **저장소명** | `{repo_name}` |
| **풀네임** | {full_name} |
| **카테고리** | {category} |
| **용도** | {purpose} |
| **원본 위치** | `{source}` |
| **가시성** | 🔒 **PRIVATE** (비공개) |
| **파일 수** | {file_count:,}개 |
| **총 용량** | {total_mb:.1f}MB |
| **라이선스** | MIT (저장소 자체), 콘텐츠는 원저작자 |

## 📜 목차
1. [🎯 용도](#-용도)
2. [📂 폴더 구성](#-폴더-구성)
3. [📊 파일 분포](#-파일-분포)
4. [🔒 비공개 정책](#-비공개-정책)
5. [⚙️ 빌드 산출물 정리 안내](#-빌드-산출물-정리-안내)
6. [🐛 알려진 한계](#-알려진-한계)
7. [📜 라이선스](#-라이선스)
8. [📁 원본 출처](#-원본-출처)

## 🎯 용도

> {purpose}

본 자료는 다음 중 하나에 해당:
- 📋 **기획 문서** — 게임 시스템/맵/캐릭터/UI 설계
- 🎨 **그래픽 원본** — PSD/AI/스프라이트 시트
- 📊 **업무 자료** — 제안서/PT 자료/회의록
- 🔒 **비공개 문서** — NDA 대상 외부 공개 금지 자료
- 📱 **모바일 게임 소스** — Android/iOS 빌드 산출물
- 🎮 **게임 소스** — PC/모바일/NDS 빌드 산출물

## 📂 폴더 구성

{chr(10).join('- 📁 `' + d + '`' for d in top_dirs)}

## 📊 파일 분포

| 확장자 | 파일 수 |
|---|---|
{chr(10).join(f'| `{e or "(no ext)"}` | {c:,} |' for e, c in top_exts)}

## 🔒 비공개 정책

- ✅ **본인만 접근** — GitHub 비공개 저장소로만 운영
- ⚠️ **외부 공유 금지** — 회사 NDA/저작권 보호
- ⚠️ **NDA 책임** — 공개/유출 시 법적 책임 본인이 부담
- ⚠️ **로컬 백업 동기화** — 원본 폴더는 항상 동기화

## ⚙️ 빌드 산출물 정리 안내

다음 패턴은 의도적으로 제외되었습니다:
- `.DS_Store` (macOS)
- `*.opt`, `*.ncb`, `*.pdb`, `*.obj`, `*.exe`, `Debug/`, `Release/`
- `*.apk`, `*.aab`, `*.class`, `bin/`, `gen/`, `out/`
- `*.nds`, `*.fxe`, `*.elf`, `*.gxb`
- `.large_files_excluded/` (50MB+ 단일 파일)

## 🐛 알려진 한계

1. **빌드 시스템 부재** — Visual Studio/Android/NDS 프로젝트 파일이 없어 직접 빌드 불가
2. **외부 SDK 미포함** — DirectX/MFC/Android SDK는 라이선스 문제로 제외
3. **빌드 산출물 없음** — 컴파일된 실행 파일은 제외
4. **한글 인코딩** — 옛 한글 매뉴얼(`EUC-KR`)은 깨져 보일 수 있으나 복원 가능
5. **날짜 정확도** — 폴더/파일 mtime이 보존되지 않을 수 있음
6. **중복 자료** — 같은 자료가 다른 폴더에 중복 저장된 경우 가능
7. **NDA 콘텐츠** — 회사 비공개 자료로 외부 공유 금지
8. **개인정보 없음** — 정리 과정에서 식별 가능한 개인정보는 모두 제거 가정

## 📜 라이선스

본 저장소는 **MIT 라이선스**로 배포됩니다 (저장소 자체). 자세한 내용은 `LICENSE` 파일 참조.

단, **저장소에 포함된 콘텐츠(기획서/그래픽/소스)의 저작권은 원저작자(회사 또는 외주 업체)**에게 있으며, NDA에 의해 보호됩니다. 따라서 외부 공유/2차 배포/상업적 사용은 제한됩니다.

## 📁 원본 출처

> 🔒 **원본 위치**: `{source}`
> **원본 폴더**: 02-private/01-회사-외주-자료
> **백업 일시**: 2026-07-31

> 🔒 **Tip**: `gh repo view {repo_name} --json visibility`로 가시성 확인 가능.
"""

for repo_name, full_name, category, source, purpose in REPOS:
    target = DST / repo_name
    if not target.exists():
        print(f'⚠️ {repo_name} 없음, 건너뜀')
        continue
    
    git_dir = target / '.git'
    if git_dir.exists():
        import shutil
        shutil.rmtree(git_dir)
    
    (target / '.gitignore').write_text(GITIGNORE, encoding='utf-8')
    (target / 'LICENSE').write_text(LICENSE_MIT, encoding='utf-8')
    readme = make_readme(repo_name, full_name, category, source, purpose, target)
    (target / 'README.md').write_text(readme, encoding='utf-8')
    
    subprocess.run(['git', 'init', '-q', '-b', 'main'], cwd=str(target))
    subprocess.run(['git', 'config', 'user.email', '[email protected]'], cwd=str(target))
    subprocess.run(['git', 'config', 'user.name', 'sigco3111'], cwd=str(target))
    subprocess.run(['git', 'add', '.'], cwd=str(target))
    result = subprocess.run(['git', 'status', '--short'], cwd=str(target), capture_output=True, text=True)
    n_staged = len(result.stdout.strip().split('\n')) if result.stdout.strip() else 0
    subprocess.run(['git', 'commit', '-q', '-m',
                    f'{full_name} 비공개 저장소 푸시\n\n- 파일 수: {n_staged:,}개'],
                   cwd=str(target))
    print(f'  ✅ {repo_name}: {n_staged:,} 파일')
```

### 4. 푸시 (작은 것부터 백그라운드)

```python
import subprocess, time
from pathlib import Path

DST = Path('/Users/mac/work/github-private')

# 푸시 순서: 작은 저장소부터 (큰 저장소는 별도 분할 후)
REPOS_PUSH = [
    'private-company-tycoon-magicstore3-sound',  # 33MB
    'private-company-secrets-1',                 # 22MB
    'private-company-proposal',                  # 32MB
    'private-company-tycoon-tractor',            # 95MB
    'private-company-nds-dsgostop-planning',     # 140MB
    'private-company-nds-dsgostop-misc',         # 285MB
    'private-company-rpg-gunblade-assets',       # 283MB
    'private-company-tycoon-magicstore3-images', # 307MB
    'private-company-nds-magicstore-sound',      # 597MB
]

results = []
for name in REPOS_PUSH:
    target = DST / name
    if not target.exists():
        results.append((name, False, 'no dir'))
        continue

    result = subprocess.run(
        ['gh', 'repo', 'create', name, '--private',
         '--description', f'{name} (회사 외주 자료, 비공개)',
         '--source', '.', '--push'],
        cwd=str(target), capture_output=True, text=True
    )
    if result.returncode == 0:
        results.append((name, True, ''))
        print(f'  ✅ 푸시 성공: {name}')
    else:
        stderr = result.stderr[:500]
        if 'already exists' in stderr.lower():
            subprocess.run(['git', 'remote', 'remove', 'origin'], cwd=str(target), capture_output=True)
            subprocess.run(['git', 'remote', 'add', 'origin',
                           f'https://github.com/sigco3111/{name}.git'],
                          cwd=str(target), capture_output=True)
            r = subprocess.run(['git', 'push', '-u', 'origin', 'main'],
                              cwd=str(target), capture_output=True, text=True)
            if r.returncode == 0:
                results.append((name, True, ''))
                print(f'  ✅ push 성공: {name}')
            else:
                results.append((name, False, r.stderr[:200]))
                print(f'  ❌ push 실패: {name}')
        else:
            results.append((name, False, stderr[:200]))
            print(f'  ❌ 실패: {name}')
    time.sleep(2)  # GitHub API rate limit 회피

# 결과 출력
print('\n=== 최종 결과 ===')
success = sum(1 for _, ok, _ in results if ok)
print(f'성공: {success}/{len(results)}')
```

**백그라운드 실행**: `terminal(command="python3 push.py 2>&1", background=True, notify_on_complete=True)`

**진행 모니터링**:
- `process(action='poll')` 5분마다
- `gh repo view <name> --json visibility` 개별 확인
- netstat `:443.*ESTABLISHED` 카운트로 네트워크 활동 모니터링

## 검증 후크 (Post-Push Verification)

각 푸시 후 다음을 확인:
```bash
# 가시성 (반드시 PRIVATE이어야 함)
gh repo view <name> --json visibility

# 커밋 존재
gh api repos/sigco3111/<name>/commits/main | python3 -c "import sys,json; c=json.load(sys.stdin); print(c['sha'][:7])"

# README 푸시됨
gh api repos/sigco3111/<name>/readme | python3 -c "import sys,json; r=json.load(sys.stdin); print(r['size'], 'bytes')"
```

## 발견된 함정 (Captured in SKILL.md Pitfalls)

- **Pitfall 21** — 1.3GB pack HTTP 408 timeout (단일 저장소 영구 실패)
- **Pitfall 22** — 10개+ 저장소 백그라운드 통합 푸시 패턴
- **Pitfall 23** — `gh repo create --push` 출력 버퍼링 지연 (출력 무시하고 API로 확인)

이 문서는 `SKILL.md` 본문의 Pitfalls를 보완하며, 검증된 전체 코드와 단계별 검증을 포함합니다. 다음 세션에서 본 워크플로우를 재사용할 때 본 파일을 먼저 참조하세요.
