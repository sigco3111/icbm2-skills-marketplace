#!/usr/bin/env python3
"""
빈 폴더 재귀 제거 (백업 폴더 정리용)

백업 폴더에는 SVN 잔재 (.svn/text-base, .svn/props, ...), 빌드 캐시 빈 폴더
(Debug/Release/obj/classes), Windows .lnk 잔재 등이 누적되어 1000개가 넘는
빈 폴더가 생기는 경우가 흔합니다. 이 스크립트는 보호된 루트를 제외하고
모두 제거합니다.

사용 예:
    python3 scripts/remove_empty_folders.py /Users/mac/work/backup
    python3 scripts/remove_empty_folders.py /Users/mac/work/backup --dry-run
    python3 scripts/remove_empty_folders.py /Users/mac/work/backup \\
        --protected '01-public,02-private,00-inbox,99-archive,.omo,.codegraph'

검증 사례 (2026-07-31): 1349개 빈 폴더가 일괄 제거됨.
"""

from __future__ import annotations

import argparse
from pathlib import Path


# 보호할 루트 이름 (이름이 일치하면 비어도 절대 제거하지 않음)
DEFAULT_PROTECTED = {
    # 4-tier buckets
    "01-public",
    "02-private",
    "00-inbox",
    "99-archive",
    # Hermes runtime
    ".omo",
    ".codegraph",
    # macOS metadata at root
    ".DS_Store",
}


def remove_empty_folders(
    root: Path,
    protected: set[str],
    dry_run: bool = False,
) -> list[Path]:
    """
    root 하위의 빈 폴더를 모두 제거합니다. 깊은 단계부터 처리하여
    자식이 비워지면 부모도 같이 비워지도록 합니다.

    Returns: 제거된 폴더 경로 리스트 (dry_run이면 제거하지 않음)
    """
    removed: list[Path] = []
    # 깊은 단계 우선 (parts 길이 역순)
    for d in sorted(root.rglob("*"), key=lambda p: -len(p.parts)):
        if not d.is_dir():
            continue
        if any(d.iterdir()):
            continue
        # 보호된 루트는 비어도 건드리지 않음
        if d.parent == root and d.name in protected:
            continue
        if dry_run:
            print(f"[dry-run] would remove: {d}")
        else:
            try:
                d.rmdir()
                removed.append(d)
            except OSError as e:
                print(f"  failed to remove {d}: {e}")
    return removed


def main() -> None:
    parser = argparse.ArgumentParser(
        description="백업 폴더에서 빈 폴더를 재귀적으로 제거합니다."
    )
    parser.add_argument("root", type=Path, help="정리할 백업 루트 디렉터리")
    parser.add_argument(
        "--protected",
        type=str,
        default=",".join(sorted(DEFAULT_PROTECTED)),
        help="보존할 루트 이름 (쉼표 구분). 기본값은 4-tier + Hermes 런타임.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="실제 제거하지 않고 제거 대상만 출력",
    )
    args = parser.parse_args()

    root = args.root.resolve()
    if not root.exists():
        raise SystemExit(f"경로 없음: {root}")

    protected = {p.strip() for p in args.protected.split(",") if p.strip()}

    print(f"Root: {root}")
    print(f"Protected: {sorted(protected)}")
    print(f"Dry-run: {args.dry_run}")
    print()

    removed = remove_empty_folders(root, protected, dry_run=args.dry_run)

    print()
    print(f"제거된 빈 폴더 수: {len(removed)}")
    if removed and not args.dry_run:
        print("제거된 경로 (상위 10개):")
        for p in removed[:10]:
            print(f"  {p.relative_to(root)}")
        if len(removed) > 10:
            print(f"  ... 그 외 {len(removed) - 10}개")


if __name__ == "__main__":
    main()