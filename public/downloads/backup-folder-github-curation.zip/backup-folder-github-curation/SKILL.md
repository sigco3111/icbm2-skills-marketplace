---
name: backup-folder-github-curation
description: "로컬 백업 폴더를 GitHub 업로드용 형태로 분류·정리. 공개/비공개/보류 3-tier 구조 + 단일 프로젝트 단위 게시 워크플로우 포함."
trigger: "백업 폴더를 깃허브 업로드용으로 정리 / 로컬 백업을 공개 비공개로 분류 / 포트폴리오 폴더 분류 / 단일 프로젝트 README + GitHub 게시"
version: 1.2.0
last_updated: 2026-07-31
changelog:
  - 1.2.0 (2026-07-31): Pitfalls 21~23 추가. 1.3GB pack HTTP 408 영구 실패 실측 + 분할 정복 검증, 10개+ 저장소 백그라운드 통합 푸시 패턴, 출력 버퍼링 지연 함정. 30개 비공개 저장소 17GB 분할 실전 사례 포함.
  - 1.1.0 (2026-07-31): Phase 8 추가 (대용량 비공개 자료 분할 + 푸시). 9개 공개 프로젝트 README 화면 다이어그램/매뉴얼 HTM 임베드 패턴. Pitfalls 13~15.
  - 1.0.0 (2026-07-31): 최초 작성. 3-tier 분류 + Phase 7 단일 프로젝트 게시 워크플로우.
status: validated
metadata:
  hermes:
    tags: [backup, github, classification, archiving, file-organization, readme, gh-cli]
    related_skills: [github-portfolio-planner, automation-audit-ops, feedback-loop, legacy-code-github-private-archive, local-source-archive-prep]
---

# 백업 폴더 → GitHub 업로드용 분류·정리

## 클래스 정의

**트리거**: 사용자가 "백업 폴더를 깃허브에 올리려고 하는데 정리해줘"처럼 **로컬 백업 폴더 전체**를 GitHub 업로드용으로 분류/정리 요청.

**차이점 (유사 스킬과)**:
- `github-portfolio-planner`: 이미 GitHub에 있는 sigco3111의 134개 저장소를 네비게이션 사이트로 보여주는 Next.js 사이트 구축
- `automation-audit-ops`: ECC 자동화 시스템(cron/hook/MCP/connector)의 라이브 상태 감사
- 본 스킬: **로컬 파일 시스템의 백업 폴더**를 GitHub 업로드 가능 형태로 분류/정리

## 사용자 선호 (2026-07-31 검증)

| 옵션 | 사용자 선택 | 빈도 |
|---|---|---|
| **A. 원본 보존 + 정리본을 새 폴더에 복사** | ❌ 기각 | 0회 |
| **B. 원본 폴더를 실제로 이동/이름 변경** | ✅ 선택 | 1회 |

→ **다음 세션부터 기본값은 B안 (원본 폴더 직접 이동)**. A안(복사 보존)을 추천하지 말 것.

**예외**: 보류(00-inbox) 폴더로 이동할 때는 명시적으로 "임시 보류"임을 알리고, 사용자가 다음 단계에서 공개/비공개를 결정할 수 있도록 원본 구조를 유지.

## 3-tier 분류 폴더 구조

```text
backup-root/
├── 01-public/                  # 공개 후보
├── 02-private/                 # 비공개
├── 00-inbox/
│   └── review-required/        # 이름/내용상 비공개 의도지만 확정 보류
└── 99-archive/                 # 시스템 메타데이터 (.DS_Store 등)
```

### 각 tier의 의미

| Tier | 의미 | 사용 시점 |
|---|---|---|
| `01-public` | GitHub에 공개 저장소로 올릴 후보 | 폴더 위치, 사용자 명시 지시, 라이선스 확인 통과 |
| `02-private` | 비공개 저장소 또는 GitHub 외부 보관 | 회사/외주 자료, 모바일 게임 소스, 경력 문서 |
| `00-inbox/review-required` | **사용자 결정 보류** | 폴더명 자체가 비공개 의도(`Being_not_open_to_the_public`), 또는 공개/비공개 판정 불가 |
| `99-archive` | 시스템 메타데이터, 빌드 산출물 원본 | `.DS_Store`, Visual Studio `.ncb/.pdb/.obj` |

## 분류 결정 휴리스틱

### 1. 폴더 이름 휴리스틱
- `!개발/모바일/이스트빌_*` (느낌표 prefix) → 비공개 기본값
- `포트폴리오/` 안의 프로젝트 → 공개 후보 (사용자 명시)
- `Being_not_open_to_the_public` 같은 **자기-서술적 비공개 폴더** → `00-inbox/review-required/`로 격리

### 2. 사용자 명시 지시 최우선
"포트폴리오 폴더는 공개, 나머지 비공개" 같은 지시가 있으면 폴더 이름보다 사용자 지시를 우선.

### 3. 컨텐츠 휴리스틱
다음이 포함되면 공개 후보에서 제외:
- 회사/외주 프로젝트로 보이는 이름
- 타사 SDK (Facebook SDK, 라이선스 불명확한 폰트 등)
- 상용 게임 에셋, 캐릭터 이미지
- 개인정보, API 키, 서버 주소, 인증서
- 빌드 산출물 다량 (`.ncb`, `.pdb`, `.obj`, `.exe`, `Debug/`, `Release/`)

## 표준 워크플로

### Phase 0. 사전 확인
1. 전체 폴더 트리 + 크기 확인: `du -sh <root>/*`
2. 1단계 깊이의 하위 폴더 목록 + 분류 후보 메모
3. 시스템 런타임 폴더 (`.omo`, `.codegraph`) 식별 — **건드리지 않음**

### Phase 1. 사용자 결정 확인
- A안/B안: 위 사용자 선호 표 참조. B안이 기본값.
- 분류 정책: 공개/비공개/보류 3-tier 구조 합의

### Phase 2. 폴더 생성 + 이동
Python 스크립트로 한 번에 실행:

```python
from pathlib import Path
import shutil

root = Path('/Users/mac/work/backup')
public = root / '01-public'
private = root / '02-private'
review = root / '00-inbox' / 'review-required'
archive = root / '99-archive'
for d in (public, private, review, archive):
    d.mkdir(parents=True, exist_ok=True)

# 1) 공개 후보 이동
for name in ['오토런 예제', '인스톨']:
    src = root / '!개발관련자료' / '포트폴리오' / name
    if src.exists(): shutil.move(str(src), str(public / name))

# 2) 자기-서술적 비공개 폴더는 보류로 격리
src = root / '!개발관련자료' / '포트폴리오' / 'Being_not_open_to_the_public'
if src.exists(): shutil.move(str(src), str(review / 'portfolio-being-not-open'))

# 3) 비공개 이동
for name in ['!개발관련자료', '!모바일개발관련', '!이스트빌_작업']:
    src = root / name
    if src.exists(): shutil.move(str(src), str(private / name))

# 4) 시스템 메타데이터만 archive로 (런타임 폴더 제외)
for p in list(root.rglob('.DS_Store')):
    if any(part in {'.omo', '.codegraph'} for part in p.parts): continue
    rel = p.relative_to(root)
    dest = archive / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(p), str(dest))
```

### Phase 3. 결과 검증
1. 루트 디렉토리 트리 출력
2. 각 tier의 하위 폴더 목록 + 크기 확인
3. 빈 디렉터리 잔여물 확인 (남은 게 있으면 `d.rmdir()`)

### Phase 4. 빈 폴더 일괄 제거 (사용자 요청 시)

사용자가 "비어있는 폴더만 있는 것 같은데 제거해줘" / "비어있는지 확인하고 비었으면 지워줘"라고 명시하면 실행. 보호된 루트만 빼고 재귀적으로 빈 폴더를 모두 제거:

```python
from pathlib import Path

root = Path('/Users/mac/work/backup')
protected = {'01-public', '02-private', '00-inbox', '99-archive',
             '.omo', '.codegraph',
             '!개발관련자료', '!모바일개발관련', '!이스트빌_작업'}

removed = 0
# 깊은 단계 우선 정렬 → 자식이 먼저 비워지면 부모도 같이 비워짐
for d in sorted(root.rglob('*'), key=lambda p: -len(p.parts)):
    if d.is_dir() and not any(d.iterdir()):
        if d.parent == root and d.name in protected:
            continue
        d.rmdir()
        removed += 1
print(f'제거된 빈 폴더 수: {removed}')
```

검증 사례 (2026-07-31):
- 1349개 빈 폴더 제거 (대부분 SVN 메타데이터 + 빌드 캐시)
- SVN 빈 폴더 패턴: `.svn/text-base`, `.svn/tmp/prop-base`, `.svn/props`, `.svn/wcprops` — 프로젝트 파일 1개당 6개
- 빌드 캐시 빈 폴더: `Debug/`, `Release/`, `obj/`, `classes/`, `bin/`
- Windows `.lnk` 단축아이콘, `.DS_Store` 다중 잔재

**Pitfall (정렬 방향)**: `sort(depth-ascending)`으로 카운트하면 부모가 비어도 다시 카운트되지 않음 → 삭제 패스는 반드시 `key=lambda p: -len(p.parts)` (깊은 단계 우선).

**Pitfall (사용자 인용 폴더)**: 사용자가 직접 언급한 폴더(`@folder:` 인용)는 비어 보여도 `du -sh`로 실제 크기 확인. 비공개 회사 자료 폴더(`!`-prefix)는 사용자 명시 없이는 절대 삭제 X.

### Phase 5. 역할 종료 tier 삭제 (사용자 요청 시)

사용자가 "이 폴더는 역할이 끝났으니 삭제해줘" / "필요 없어서 지웠음"이라고 하면 즉시 진행. 예:

- `00-inbox/review-required/portfolio-being-not-open/` → 사용자 결정 완료 → `shutil.rmtree('00-inbox')`
- `99-archive/.DS_Store`만 남음 → `shutil.rmtree('99-archive')`
- `02-private/02-개인-문서-경력/` (이력서/경력사항) → 사용자 명시적 삭제 요청 → `shutil.rmtree(...)`

**Pitfall (경량 검증)**: 삭제 전 항상 `ls -la`로 내용 1회 확인 후 진행. 비어 있다는 사용자 말과 실제 내용 사이에 갭이 있을 수 있음 (특히 macOS `@` 확장속성, 숨김 파일).

### Phase 6. 일시 정지 신호 처리

사용자가 "다시 하나씩 해보자" / "일단 멈추고 다시 생각" / "다시 확인해" 같은 멈춤 신호를 보내면 다음을 중단:

- 추가 분류 결정 (open vs private)
- GitHub 푸시
- 새 README 작성

현재 작업 중인 sub-category만 마무리하고 사용자에게 다음 옵션 제시:
- 다음 폴더로 진행
- 지금까지 작업한 결과 검토
- 워크플로우 중단

**사용자 선호 (2026-07-31 검증)**: 한 번에 모든 프로젝트를 진행하지 않고, **하나씩 단계적으로** 진행하는 것이 기본값. 옵션 제시 시 추천을 항상 명시하고, 진행 일정이 길어지면 단계적으로 끊어서 검증.

---

# Phase 7. 단일 프로젝트 단위 GitHub 게시 워크플로우

triage가 끝난 후 `01-public/` 안의 각 프로젝트를 하나씩 GitHub에 게시하는 실전 절차. (2026-07-31 학습됨 — gp32-blaster-vertical, gp32-bluemarble-king, dnb-action-rpg, gp32-resource-archive 4건 검증)

## 트리거
사용자가 "이 폴더에 README 만들고 깃허브에 올리려고함" / "공개로 푸시" / "비공개로 푸시" 같은 단일 프로젝트 게시 요청.

## 7단계

### 1. 옵션 제시 (사용자 결정)
분량이 큰 경우(>300MB 또는 >1000 파일)는 푸시 전에 한 번 더 옵션 확인. 일반적으로 다음을 묶어서 제시:
- README만 원본에 만들고 푸시 보류 vs 푸시까지
- 공개 vs 비공개
- 매뉴얼 HTM/스크린샷 포함 여부
- .gitignore 제외 대상 (SDK zip, 빌드 산출물 등)

### 2. 작업 사본 생성 (원본 보존)
**원본은 절대 손대지 않는다.** 작업은 `/Users/mac/work/github/<repo-name>/`에서만.

```bash
mkdir -p /Users/mac/work/github
cp -a "<원본 경로>" /Users/mac/work/github/<repo-name>
```

매뉴얼 HTM/이미지도 작업 사본에 별도 복사 (예: `manual/DnB_manual/`).

### 3. 빌드 산출물 일괄 정리 (Python)
깊은 단계 우선 정렬 + fnmatch 패턴 매칭:

```python
from pathlib import Path
import fnmatch, shutil
root = Path('/Users/mac/work/github/<repo-name>')
patterns = ['*.opt','*.plg','*.ncb','*.positions','*.aps','*.suo',
            '*.obj','*.sbr','*.exe','*.pdb','*.idb','*.pch','*.ilk','*.bsc',
            'Debug/','Release/','debug/','release/']
removed = 0
for f in list(root.rglob('*')):
    if not f.is_file(): continue
    for pat in patterns:
        if fnmatch.fnmatch(f.name, pat):
            f.unlink(); removed += 1; break
# .lnk 단축아이콘 별도
for f in list(root.rglob('*.lnk')): f.unlink(); removed += 1
# 빈 빌드 디렉터리 정리
for d in sorted(root.rglob('*'), key=lambda p:-len(p.parts)):
    if d.is_dir() and not any(d.iterdir()) and d.name in {'Debug','Release'}:
        try: d.rmdir()
        except: pass
```

### 4. README.md 작성 (한국어 기본)
- 게임/프로젝트 분석 → 모듈 표
- 매뉴얼 HTM이 EUC-KR이면 `cat | head`로 깨진 바이트를 받아도 의미 복원 (Pitfall #7)
- 화면/스크린샷은 `![alt](path)` 임베드, 작업 사본 기준 상대경로
- 매뉴얼 HTM도 `[이름](path/Page.htm)` 링크로 추가 (공백은 `%20`으로 인코딩)
- MIT 라이선스 + 외부 SDK 소유권 명시

### 5. .gitignore + LICENSE
- 비공개 SDK zip은 .gitignore로 제외 또는 작업 사본에서 삭제
- 매 프로젝트 SDK에 맞게 패턴 갱신:
  - GP32: `*.fxe *.elf *.gxb`
  - Win32/DirectX: `*.obj *.pch *.ilk *.bsc`
  - VB6 런처: `GameStart.exe` (재생 가능)
- LICENSE: MIT + 외부 의존성 (DirectX SDK, GP32 SDK 등) 명시

### 6. git init → commit → push
```bash
cd /Users/mac/work/github/<repo-name>
git init -q -b main
git config user.email "[email protected]"
git config user.name "sigco3111"
git add .
git commit -q -m "<메시지 — 소스 + 리소스 + 매뉴얼/스크린샷 + 라이선스>"
gh repo create <repo-name> --public|--private \
  --description "<한국어 설명>" --source . --push
```

### 7. GitHub API 검증 (필수)
**푸시됐다고 외부 응답만으로 끝내지 않음.** gh api + Python json으로 4가지 확인:

```bash
gh repo view <repo-name> --json name,visibility,url,defaultBranchRef,description
gh api repos/sigco3111/<repo-name>/contents/ | python3 -c "import sys,json; r=json.load(sys.stdin); print(len(r), [e['name'] for e in r])"
gh api repos/sigco3111/<repo-name>/commits/main | python3 -c "import sys,json; c=json.load(sys.stdin); print(c['sha'][:7])"
gh api repos/sigco3111/<repo-name>/readme | python3 -c "import sys,json; r=json.load(sys.stdin); print(r['size'], 'bytes')"
```

모두 의도(가시성, 루트 파일 수, 커밋 해시, README 크기)와 일치해야 완료.

## Pitfalls (단일 게시)

### Pitfall 7. EUC-KR HTM 매뉴얼은 "깨진 것"이 아님
- 옛 한글 웹 매뉴얼은 `charset=euc-kr`로 작성되어 `cat`/`head` 시 한글이 `���� ����`처럼 보임
- 하지만 **내용은 복원 가능**: 글자가 깨진 위치에 한국어가 있음을 인식하고, 자주 등장하는 단어(`게임`, `설치`, `Rule`, `Player Select`, `메뉴`, `보스`, `스킬`, `마을`, `엔딩`)를 키워드로 의미 복원
- 2003년 전후 Namo WebEditor로 작성된 매뉴얼이 많음 → `<meta generator="Namo WebEditor v5.0">` 단서
- 복원할 때: `Setup.htm`의 파일명, 코드 모듈과 일치하는 화면 설명 등으로 **실제 게임명** 판정

### Pitfall 8. 폴더명 ≠ 게임명
- `Azmanga_manual`이 부루마블대왕 매뉴얼이었던 것처럼, 폴더명은 작업 중 임시 라벨일 수 있음
- 매뉴얼 내용(`Setup.htm`에서 `BlueMB.fxe` 언급, 코드 모듈과 일치하는 화면 설명)으로 실제 게임명 판정
- README에서 "폴더명 X는 임시 라벨이며 실제 게임은 Y"라고 명시

### Pitfall 9. README "안 보임" 환상
- **비공개 저장소**: GitHub 홈 화면의 README 미리보기 패널이 자동 렌더링되지 않음 → 코드 탭 → 파일 목록에서 직접 클릭 필요
- **공개 저장소**: 홈 화면에 자동 표시
- 두 경우 모두 README는 푸시된 상태이므로 `gh api .../readme`로 실제 존재 확인 가능
- 사용자가 "README 안 보임"이라고 하면 **URL 직접 제공**: `https://github.com/sigco3111/<repo>/blob/main/README.md`

### Pitfall 10. 사용자 인용 폴더 = "비어있다" 함정
- 사용자가 "@folder:`...` 비어있는데?"라고 물으면 비공개/보류 폴더일 가능성이 큼
- 그 폴더는 **비공개 보존**이 원칙이지만, 실제 비어 있는지 `du -sh`로 1회 확인 후 응답
- 비어 있으면 빈 디렉터리 정리 대상이지만, 보호 tier(`01-public`, `02-private`, `00-inbox`, `99-archive`, `.omo`, `.codegraph`, `!`-prefix 회사 폴더)는 보존

### Pitfall 11. README 직접 추가 요청
- 사용자가 "원본에 README 만들어줘"라고 하면 작업 사본이 아닌 **원본 폴더에 직접 추가**
- 단, 푸시 작업은 별개 (보통 푸시 보류로 진행, 사용자가 명시적으로 푸시 요청 시 1~6단계 수행)

### Pitfall 12. 스크린샷 임베드 누락
- 사용자가 "스크린샷도 여러장 추가해줘"라고 하면 README에 `![alt](path/Image/foo.jpg)` 마크다운 이미지 임베드 필수
- 작업 사본에 매뉴얼 이미지 폴더도 함께 복사 (`cp -a .../Image manual/<manual>/Image`)
- 이미지 경로는 **작업 사본 기준** 상대경로 (예: `manual/DnB_manual/image/PlayerSelect.jpg`)
- 공백 있는 HTM 파일명은 링크에 `%20` 인코딩 (`Top Menu.htm` → `Top%20Menu.htm`)

## Pitfalls (실전 검증)

### Pitfall 1. 평탄화 시 빈 디렉터리 잔여
**증상**: `shutil.move` 후 의도치 않게 빈 디렉터리가 남음 (`99-archive/00-inbox/` 등)
**원인**: 평탄화 스크립트가 자식 폴더만 옮기고 빈 부모를 정리 안 함
**해결**: 모든 이동 후 `for d in archive.iterdir(): if d.is_dir() and not any(d.iterdir()): d.rmdir()`

### Pitfall 2. mkdir 후 shutil.move 실패
**증상**: `FileNotFoundError: '/.../00-inbox/review-required'`
**원인**: `mkdir()`이 부모 디렉터리를 안 만듦 (Python 3 미만 또는 명시 옵션 누락)
**해결**: 항상 `mkdir(parents=True, exist_ok=True)`

### Pitfall 3. 시스템 런타임 폴더 손상
**증상**: `.omo`, `.codegraph` 같은 Hermes/에이전트 런타임 폴더를 같이 옮겨서 도구 깨짐
**해결**: 명시적 화이트리스트/블랙리스트. 런타임 폴더는 항상 보존.

### Pitfall 4. 평탄화 후 stray top-level 폴더 잔존
**증상**: 루트에 `review-required/` 같은 stray 폴더가 남음 (평탄화 중간 상태)
**해결**: 평탄화 후 `for x in sorted(root.iterdir())` 출력으로 검증, stray 발견 시 강제 이동

### Pitfall 5. mkdir 후 평탄화 시 루트와 archive 충돌
**증상**: `archive/00-inbox/`이 생기고 평탄화 후 다시 root로 옮기면 이름 충돌
**해결**: 평탄화 시 `counter` 변수로 `_2`, `_3` suffix 추가 (드물지만 가능)

### Pitfall 6. 자기-서술적 비공개 폴더를 공개 후보로 잘못 분류
**증상**: `Being_not_open_to_the_public` 같은 폴더를 `01-public`으로 옮김
**원인**: 폴더명 의미를 무시하고 위치만으로 판단
**해결**: 폴더명 휴리스틱 최우선 적용. 보류 폴더(`00-inbox/review-required`)로 격리하고 사용자 결정 대기.

## 검증 (Verification)

작업 완료 후 다음을 확인:
1. `ls /backup-root/` → `00-inbox`, `01-public`, `02-private`, `99-archive` 4개 tier만 보임
2. 각 tier 내부에 적절한 하위 폴더 존재
3. 시스템 런타임 폴더(`.omo`, `.codegraph`) 보존 확인
4. `du -sh /backup-root/*` 출력 → 비공개(02-private)가 대용량(수십 GB)이어도 정상
5. 루트에 stray 폴더 없음 (`review-required`, `00-inbox_2` 등)

## 검증 사례 (2026-07-31)
- `gp32-resource-archive` (비공개) — GP32 SDK 모음 사본
- `gp32-blaster-vertical` (공개) — GP32 수직 슈팅 + 스크린샷 10장, 170 파일
- `gp32-bluemarble-king` (공개) — GP32 부루마블대왕 + 매뉴얼 26 HTM + 스크린샷 10장, 129 파일
- `dnb-action-rpg` (공개) — Windows 2D 액션 RPG, 4,727 파일, 475MB
- 빈 폴더 정리: 1,138개 → 1,349개 (깊은 단계 우선 정렬 패스)

## 검증 사례 (2026-07-31 9건 추가, 시퀀스)
- `win32-console-shooter` (공개) — Windows 콘솔 슈팅 + CS史料 스크린샷
- `flamesword-action` (공개) — Windows 횡스크롤 액션 + BS史料 + 기획 메모(`0stage.txt`)
- `gateheavens-shmup` (공개) — Windows 그리스 신화 슈팅 RPG + GH史料 (직접적인 선행 프로토타입)
- `pleasuregate-shmup` (공개) — Windows 마우스+키보드 슈팅 + PG史料
- `dnb-map-editor` (공개) — MFC SDI 맵 에디터 + MT史料 (DnB의 24개 스테이지 맵 제작 도구)
- `dnb-sprite-tool` (공개) — MFC SDI 스프라이트 에디터 + ST史料 + 한글 문서(추가사항.txt, 파일헤더.txt)

## 검증 사례 (2026-07-31 비공개 30건 추가 — 대용량 회사 외주 자료)
- `/Users/mac/work/backup/02-private/01-회사-외주-자료/` (17GB) → 30개 비공개 저장소로 분할
- 큰 폴더별 별도 저장소로 분할 (RPG 건블레이드 3GB → proto/planning/assets 3개, NDS DS고스톱 2.7GB → artwork/sound/misc/planning 4개, 마법상점DS 2.6GB → screenshots/sound/planning 3개, 타이쿤 3GB → magicstore1/2/3-images/3-sound + tractor + beauty + 메인 7개)
- 18개 파일 100MB+ 자동 제외 (PSD/원화/영상 zip 등) → `.large_files_excluded/` 폴더로 이동
- 50MB+ 파일 단일 파일은 `.large_files_excluded/`로 자동 이동 (Phase 8 참조)

---

# Phase 8. 대용량 비공개 자료 분할 + 푸시 (NEW, 2026-07-31 검증)

## 트리거
사용자가 "용량이 너무 커서 더 작게 나눠서 올려야 할 것 같아" 또는 "비공개로 분할 푸시" 같은 요청 시. 또는 단일 폴더가 1GB+로 단일 푸시가 위험할 때 자동 발동.

## GitHub 푸시 한계 (실측, 2026-07-31)
- **단일 pack 1.3GB+** → 멀티파트 업로드 후 HTTP 408 timeout 빈번 → 푸시 실패
- **pack 2GB+** → 거의 항상 실패
- **pack 1GB 이하** → 5~15분 안정 푸시
- **권장 저장소 크기: 5GB 이하, pack 1GB 이하**

## 7단계

### 1. 폴더 구조 + 용량 분석
```bash
du -sh <root>/*  # 1단계 깊이
du -sh <root>/<sub>/*  # 2단계 깊이 (큰 폴더는 더 보기)
```
목표: 분할 후 각 저장소가 2GB 미만, 큰 폴더(500MB+)는 별도 저장소로 분리.

### 2. 사용자 결정 확인 (분할 단위)
옵션 4가지 (정직 매트릭스 + 추천):
- **A-1. 폴더 단위 분할** (가장 안전, 저장소 수 많음)
- **A-2. 프로젝트/회사별 분할** (3~5개, **추천**)
- **A-3. 5GB 단위 강제 분할** (단순, 의미 단위 무시)
- **B. 단일 비공개 저장소** (17GB, 위험)

**사용자 선호 (2026-07-31 검증)**: 큰 결정은 단계적으로. A-2 또는 A안 + 추가 분할 옵션이 자주 선택됨.

### 3. 작업 사본 폴더 결정
**공개 저장소**: `/Users/mac/work/github/<repo-name>/` (MEMORY.md 정책)
**비공개 저장소**: **`/Users/mac/work/github-private/<repo-name>/`** (별도 분리, 2026-07-31 신규)

이유: 공개/비공개 작업이 동시에 진행될 때 실수로 공개 저장소에 비공개 자료를 푸시하거나 그 반대를 방지.

### 4. Python 스크립트로 분할 + 정리 + README/commit 자동화
한 번의 백그라운드 실행으로 모든 저장소 처리. 핵심 코드:

```python
from pathlib import Path
import shutil, fnmatch, subprocess

SRC = Path('/Users/mac/work/backup/02-private/<category>')
DST = Path('/Users/mac/work/github-private')
SIZE_LIMIT = 50 * 1024 * 1024  # 50MB

# 제외 패턴 (빌드 산출물 + 대용량 파일)
exclude = ('*.opt','*.plg','*.ncb','*.positions','*.sbr','*.obj',
           '*.pdb','*.idb','*.ilk','*.bsc','*.res','*.tlog',
           '*.exe','*.aps','*.suo','MFC*.TMP','~VC*.TMP',
           'vc60.*','vc70.*','BuildLog.htm','*.bak','*.tmp','ALZ*.TMP','.DS_Store')

def copy_item(src, target):
    target.mkdir(parents=True, exist_ok=True)
    dst = target / src.name
    if src.is_file():
        shutil.copy2(src, dst)
    elif src.is_dir():
        if dst.exists(): shutil.rmtree(dst)
        shutil.copytree(src, dst, ignore=shutil.ignore_patterns(*exclude))

# (저장소명, [원본 상대경로]) 목록으로 분할
repos = [
    ('repo-1', ['subfolder/A', 'subfolder/B']),
    ('repo-2', ['subfolder/C']),
]
for name, sources in repos:
    target = DST / name
    if target.exists(): shutil.rmtree(target)
    target.mkdir(parents=True)
    for s in sources:
        src = SRC / s
        if src.exists(): copy_item(src, target)
```

### 5. 50MB+ 단일 파일 자동 제외
```python
# 각 저장소에 .large_files_excluded/ 폴더로 이동
excl = repo / '.large_files_excluded'
excl.mkdir(exist_ok=True)
gitignore = repo / '.gitignore'
with gitignore.open('a') as f:
    f.write('\n# 50MB+ 파일 (GitHub 푸시 부담/거부 방지)\n.large_files_excluded/\n')

for f in list(repo.rglob('*')):
    if not f.is_file(): continue
    if '.git' in f.parts or '.large_files_excluded' in f.parts: continue
    try:
        if f.stat().st_size > SIZE_LIMIT:
            target = excl / f.relative_to(repo)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(f), str(target))
    except (FileNotFoundError, PermissionError):
        continue
```

### 6. README 11섹션 템플릿 (비공개용, NEW)
공개용 README와 다른 11섹션 템플릿:

1. **상단 callout** — `> ⚠️ 이 저장소는 비공개입니다.`
2. **4개 shields.io 배지** — visibility PRIVATE + category + files + license
3. **개요 표** — 저장소명/풀네임/카테고리/용도/원본위치/가시성/파일수/총용량/라이선스 9개 항목
4. **이모지 풀 목차** — 11개 섹션 (개요/용도/폴더구성/파일분포/비공개정책/빌드산출물정리/알려진한계/라이선스/원본출처)
5. **용도 설명** — 게임 기획서/그래픽/제안서/모바일 게임 소스/비공개 문서 등 카테고리별 안내
6. **폴더 구성** — 최상위 폴더별 크기를 이모지 트리로 자동 측정
7. **파일 분포 표** — `count_files()` + 확장자별 카운트
8. **비공개 정책** — 본인만 접근/로컬 백업 동기화/외부 공유 금지/NDA/저작권
9. **빌드 산출물 정리 안내** — 제외된 패턴 목록
10. **알려진 한계** — 빌드 시스템 부재/NDA/외부 SDK 미포함/한글 인코딩/날짜 정확도/중복 자료 등 10개 항목
11. **라이선스 + 원본 출처 + Tip** — MIT (저장소 자체), 콘텐츠는 원저작자, NDA/계약서 적용 안내

### 7. 푸시 전략: 작은 저장소부터 시작
```python
# 백그라운드로 작은 저장소부터 푸시
for repo_name, ... in sorted(REPOS, key=lambda x: x.size):
    subprocess.run(['gh', 'repo', 'create', repo_name, '--private',
                    '--description', ..., '--source', '.', '--push'], cwd=target)
```

**푸시 옵션** (안정성 향상):
```bash
# HTTP timeout 방지
GIT_HTTP_LOW_SPEED_LIMIT=1000 GIT_HTTP_LOW_SPEED_TIME=600 git push -u origin main
```

**큰 저장소 푸시 실패 시 대안**:
- Git LFS 도입 (LFS 무료 1GB)
- 추가 분할 (큰 폴더를 별도 저장소로)
- `git filter-branch` 또는 `git filter-repo`로 큰 객체 제거 후 재시도

## 작업 사본 폴더 정책 (NEW, 2026-07-31)
| 폴더 | 용도 |
|---|---|
| `/Users/mac/work/github/` | **공개** 저장소 작업 사본 |
| `/Users/mac/work/github-private/` | **비공개** 저장소 작업 사본 |
| `/Users/mac/work/backup/` | **원본** (절대 수정 금지) |

이 분리는 공개/비공개 자료를 실수로 혼동하는 사고를 방지합니다. 매니페스트(레지스트리) 양쪽에 같은 이름의 `private-company-xxx`가 있어도 폴더 자체가 다르므로 안전.

## Pitfalls (Phase 8)

### Pitfall 16. gh repo create --push의 첫 커밋이 너무 크면 멈춤
**증상**: `gh repo create private-company-X --private --push` 후 push가 진행되지 않고 멈춤
**원인**: `--push` 옵션은 첫 커밋을 자동으로 푸시하지만, pack이 1GB+이면 HTTP 408 timeout
**해결**:
1. `gh repo create ...` (push 없이 저장소만 생성)
2. `git remote add origin https://github.com/sigco3111/X.git` (remote 수동 등록)
3. `GIT_HTTP_LOW_SPEED_LIMIT=1000 GIT_HTTP_LOW_SPEED_TIME=600 git push -u origin main` (백그라운드로 푸시)

### Pitfall 17. 분할 후 푸시 시 한글이 들어간 파일명에 의한 git error
**증상**: `fatal: Unable to process path ...` 또는 `UnicodeEncodeError`
**원인**: macOS shell이 EUC-KR 파일명을 처리하지 못할 때 (특히 `find` + `xargs` 조합)
**해결**: 항상 Python으로 처리. bash `find ... | xargs ...`는 한글/공백 파일명에서 실패 빈번.

### Pitfall 18. git add 후 pack이 예상보다 큼
**증상**: git gc + repack 후 pack이 1.3GB → 푸시 위험
**원인**: 이전 커밋에 큰 객체(zip/PSD)가 들어 있어 pack에 보존됨
**해결**:
1. `git verify-pack -v .git/objects/pack/*.idx | grep blob | sort -k3 -rn | head -5` 로 큰 객체 확인
2. `git filter-branch -f --tree-filter "find . -size +50M -delete" --prune-empty HEAD~3..HEAD` (최근 3 커밋만)
3. 첫 커밋부터 정리가 필요하면 **작업 사본 처음부터 다시 시작**이 더 빠름

### Pitfall 19. PSD 파일 200+개가 발견되어 .psd 추가 제외 필요
**증상**: 첫 푸시 시 1.3GB pack → 분할 후에도 PSD 때문에 여전히 큼
**원인**: .gitignore에 `*.psd`를 추가했지만 이미 인덱스에 들어간 객체는 그대로
**해결**:
```bash
git rm --cached -r -- "*.psd"
git add -A
git commit -m "PSD 추가 추적 해제"
git gc --prune=now --aggressive
git repack -ad
```

### Pitfall 20. 첫 번째 저장소만 푸시되고 나머지는 멈춤
**증상**: `gh repo create ... --push`가 첫 저장소 푸시 후 다음 저장소로 진행 안 됨
**원인**: gh CLI가 첫 푸시에 너무 오래 걸려서 다른 저장소들이 queue에 쌓임
**해결**: 
1. 첫 저장소는 별도 처리
2. 나머지는 `gh repo create ...` (push 없이) + `git push` 백그라운드로
3. 백그라운드 프로세스(`terminal(background=true, notify_on_complete=true)`)로 동시에 여러 푸시 진행

### Pitfall 21. 1.3GB pack 푸시는 HTTP 408 timeout으로 영구 실패 (NEW, 2026-07-31 실측)
**증상**: `git push -u origin main` 진행 → timeout → "Everything up-to-date" 또는 다음 메시지:
```
error: RPC failed; HTTP 408 curl 22 The requested URL returned error: 408
send-pack: unexpected disconnect while reading sideband packet
fatal: the remote end hung up unexpectedly
```
**근본 원인**:
- 1.3GB pack 단일 푸시는 GitHub 멀티파트 업로드가 **연결을 자주 끊김**
- "Everything up-to-date"는 **출력이 잘못 캐시된 것이 아니라 pack이 부분 업로드된 상태로 GitHub가 partial commit를 받음**
- 이후 `git push` 재시도는 "이미 받은 객체는 skip" 하면서도 새 객체를 받지 못해 무한 실패
**해결 — 즉시 분할 후 처음부터**:
1. **현재 작업 사본 버림** (부분 푸시된 잔재가 있어도 깨끗하게)
2. 큰 폴더를 별도 저장소로 분리 (Pitfall 16 패턴)
3. 50MB+ 파일 `.large_files_excluded/`로 이동
4. `git init` 처음부터, pack 1GB 이하 보장
5. 푸시 시도 → 성공

**검증 (2026-07-31)**: `private-company-tycoon` (1.3GB pack) HTTP 408 영구 실패. 분할 후 7개 (tycoon 본체 + magicstore1/2/3-images/sound + tractor + beauty) 모두 푸시 성공.

**경고 신호**: pack 1GB 이상 시 `gh repo create --push` 사용 금지. 수동 remote + 백그라운드 push (`Pitfall 16`) 사용.

### Pitfall 22. 10개+ 저장소 순차 푸시는 한 백그라운드 작업으로 통합 (NEW, 2026-07-31)
**증상**: 여러 저장소를 따로따로 푸시하면 각 푸시마다 5~15분씩 걸려 총 1~3시간 소요
**해결 패턴**:
```python
import subprocess, time
from pathlib import Path

REPOS = [...]  # 작은 것부터 정렬된 10개 리스트
results = []
for name in REPOS:
    target = Path(f'/Users/mac/work/github-private/{name}')
    if not target.exists():
        results.append((name, False, 'no dir'))
        continue
    
    result = subprocess.run(
        ['gh', 'repo', 'create', name, '--private',
         '--description', '회사 외주 자료, 비공개',
         '--source', '.', '--push'],
        cwd=str(target), capture_output=True, text=True
    )
    if result.returncode == 0:
        results.append((name, True, ''))
    else:
        stderr = result.stderr[:500]
        if 'already exists' in stderr.lower():
            subprocess.run(['git', 'remote', 'remove', 'origin'], cwd=str(target), capture_output=True)
            subprocess.run(['git', 'remote', 'add', 'origin',
                           f'https://github.com/sigco3111/{name}.git'],
                          cwd=str(target), capture_output=True)
            r = subprocess.run(['git', 'push', '-u', 'origin', 'main'],
                              cwd=str(target), capture_output=True, text=True)
            results.append((name, r.returncode == 0, r.stderr[:200]))
    time.sleep(2)  # GitHub API rate limit 회피
```

**백그라운드 실행**: `terminal(command="python3 push_script.py 2>&1", background=True, notify_on_complete=True)`

**검증 사례 (2026-07-31)**:
- 9개 저장소 (33MB~597MB) 한 Python 스크립트 → 1시간 30분 소요 → **9/9 성공**
- 10개 저장소 (7MB~887MB) 두 번째 스크립트 → 진행 중
- 성공률 100% (Pitfall 21 적용 후)

**진행 모니터링**:
- `process(action='poll', session_id=...)`로 5분마다 확인
- `gh repo view <name> --json visibility`로 개별 저장소 상태 검증 (백그라운드와 별개)
- netstat `:443.*ESTABLISHED` 카운트로 네트워크 활동 모니터링

### Pitfall 23. `gh repo create --push` 후 출력 버퍼링 지연 (NEW, 2026-07-31)
**증상**: `terminal background` 출력이 푸시 완료 후 1~3분 늦게 한꺼번에 표시됨
**원인**: pipe redirect(stdout=PTY가 아닌 경우)로 인한 flush 지연, GitHub 푸시 완료 후 print() 결과가 도착하기까지 시간 지연
**해결**:
1. **process 출력 보단 `gh repo view`로 진실 확인** (Pitfall 22 검증 패턴)
2. 출력 캡처 지연은 정상 동작으로 인식, GitHub API 응답을 신뢰
3. 큰 저장소 푸시 시 출력은 1~10분 늦게 도착 가능

## 비공개 푸시 시 GitHub API 검증 (NEW)
```bash
gh repo view <repo-name> --json name,visibility,url,defaultBranchRef,description
gh api repos/sigco3111/<repo-name>/contents/ | python3 -c "..."
gh api repos/sigco3111/<repo-name>/commits/main | python3 -c "..."
```
**추가 확인**: `visibility`가 `PRIVATE`인지 확인 (공개로 잘못 올리면 사고).

## 상세 참조 (references)
- **references/private-company-bulk-push.md** — 17GB → 30개 비공개 저장소 분할 실전 사례 + 검증된 Python 스크립트 4종 (분할/50MB+제외/README/commit/푸시) + 11섹션 README 템플릿 + 작업 사본 폴더 정책

이 9건 추가에서 다음 3가지 새 패턴이 검증되어 본 스킬에 반영.

### Pitfall 13. 푸시 시 "remote already has commits" — 깃허브 웹 편집이 끼어든 경우
**증상**: `git push` 후 `! [rejected] (non-fast-forward)` — 원격에 로컬에 없는 커밋이 있음.
**원인**: `gh repo create --source . --push` 직후 또는 푸시 직전에 깃허브 웹 인터페이스에서 README를 수정(Add a README, Update README.md 등)했기 때문. 자동화 봇/다른 세션의 잔재 커밋일 수도 있음.
**해결 — rebase로 통합**:
```bash
git fetch origin
git status -sb  # 추적 상태 확인
git log --oneline -5 origin/main  # 원격에 있는 커밋 확인

# 충돌 없으면 rebase
git pull --rebase origin main 2>&1 | tail -10

# 충돌 있으면 충돌 마커 제거 후
GIT_EDITOR=true git rebase --continue
```

**검증된 메시지 (2026-07-31 2회)**: `win32-console-shooter`, `flamesword-action`, `gateheavens-shmup` 모두 `b8fdee4 Update README.md` / `c6a2b77 Update README.md` 같은 잔재 커밋과 충돌. rebase + `GIT_EDITOR=true`로 해결.

**`GIT_EDITOR=true`가 필요한 이유**: `git rebase --continue`는 기본적으로 인터랙티브 에디터를 띄워 커밋 메시지를 입력받는데, Hermes의 `terminal` 도구가 dumb 터미널로 보고하면 `error: Terminal is dumb, but EDITOR unset`로 실패함. `GIT_EDITOR=true`로 환경 변수를 미리 설정하면 rebase가 자동 진행됨.

### Pitfall 14. README 섹션 위치는 사용자 요청에 따라 이동 가능
**증상**: 처음 푸시한 README에서 "📸 관련 자료" 섹션이 **파일 끝**에 있는데, 사용자가 "위치를 목차 위로 변경해줘"로 위치 변경 요청.
**해결 패턴**:
1. 사용자가 명시한 새 위치(예: "목차 바로 아래")를 정확히 파악
2. 기존 섹션의 마커 시작(`## 섹션명`)부터 끝(`---` 또는 다음 `## 섹션명` 직전)까지 식별
3. 새 위치에 삽입 + 목차 앵커 링크 `[📸 관련 자료](#-관련-자료)` 추가
4. 기존 위치에서 섹션 삭제
5. **상단 callout**: "본 섹션은 본 저장소와 다른 별도 프로젝트입니다" 같은 경고를 새 위치 첫 줄에 넣어 혼동 방지
6. 커밋 후 rebase 푸시 (Pitfall 13 참조)

**검증 사례 (2026-07-31)**: `win32-console-shooter`에서 📸 관련 자료가 `01-public`의 다른 시리즈와 혼동될 위험 → 상단 callout 명시. `gateheavens-shmup`에서 이전 추측("GateHeavens와 무관, 콘솔 시제품")을 "직접적인 선행 프로토타입"으로 정정하여 README에 반영.

### Pitfall 15. README 스타일은 사용자 명시 선호에 맞춰 화려하게 작성
**사용자 선호 (2026-07-31 9건 검증)**: "리드미를 화려하고 자세하게 만들어줘"
**README 구조 권장**:
1. **상단 callout** — `> ⚠️` 또는 `> 🎯`로 핵심 메시지 한 줄
2. **shields.io 배지 5~6개** — platform / lang / graphics / sound / input / license
3. **이모지 풀 목차** — 13~20개 섹션
4. **ASCII 아트 화면 다이어그램** — 1개 이상
5. **표(table) 활용** — 게임 특징, 모듈, 컨트롤, 조작법 등
6. **관련 자료 섹션 (상단)** — 시리즈 부록 + 선행 프로토타입史料 (Pitfall 14)
7. **상세 코드 스니펫** — 헤더 파일 발췌 (구조체, enum, 핵심 함수)
8. **시스템 아키텍처 다이어그램** — 데이터 흐름 / 클래스 계층
9. **알려진 한계 8~12개** — 한계/함정/오타 등 명시
10. **한국어 매뉴얼 HTM** 있으면 `manual/` 폴더에 복사 + README에서 링크

**README 크기 권장**: 30~40KB (대형 게임 9건 모두 이 범위). 20KB 이하는 빈약, 50KB 초과는 부담.

**반대 방향 (간단한 README)**: 사용자가 "간단히", "요약만", "최소한"으로 명시한 경우만 화려함 배제. 기본값은 화려함.

## 정리 노트 (curator에게)

`backup-folder-github-curation` ↔ `local-source-archive-prep` ↔ `legacy-code-github-private-archive` 세 스킬의 책임이 일부 겹친다:
- **이 스킬**: 폴더 분류 3-tier 구조 + 단일 프로젝트 GitHub 게시 (가장 두꺼움)
- `local-source-archive-prep`: 로컬 백업 → 깃허브 공개/비공개 버킷 재구성 (triage 단계)
- `legacy-code-github-private-archive`: 레거시 게임/SDK/툴체인 비공개 푸시 (단일 프로젝트 비공개 특화)

병합 후보: 이 스킬을 umbrella로 두고 `local-source-archive-prep`와 `legacy-code-github-private-archive`를 references로 링크하는 구조. 현 시점에서는 curator의 재량에 맡김.