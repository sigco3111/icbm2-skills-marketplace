---
name: hermes-control-room-office-fork
title: Convert hermes-control-room to Claude‑Office (browser‑only)
trigger: Convert hermes-control-room to a browser‑only Claude‑Office fork, OR fix sprite 404 after deploy, OR diagnose Playwright 404 report vs actual live state. Fires on "Claude-Office fork", "browser-only", "vite base path sprite 404", "sprite 깨짐", "phantom 404", "fresh clone push", "git push unpack failed b0bb8de7".
description: Browser‑only Claude‑Office fork of hermes-control-room with full sprite path / base URL / fresh-clone push handling.
---
## Steps
1. Clone `W17ant/Claude-Office` (shallow) into a temporary directory.
2. From the current `main` create a new branch `phase3-claude-office-fork`.
3. Delete all existing source files (keep `.git`) and copy the cloned repository contents into the repo root.
4. Remove Electron‑related folders (`electron/`, `server/`, `hooks/`) and large day/night PNGs if not needed.
5. Edit `package.json` – drop Electron dependencies and scripts, rename the project, keep minimal React/Vite dependencies.
6. Patch `src/App.tsx` to force simulation mode (`isSimMode = !params.has('live')`) and set default theme to `office`.
7. In `src/theme.ts` add `HERMES_DEPARTMENT_DISPLAY` mapping and adjust `themedDisplayName` to prioritize Hermes department names.
8. Run `npm install`; build with `npm run build`; verify the dev server runs; optionally capture a Playwright screenshot.
9. Deploy the `dist/` folder to a `gh-pages` branch (or a new branch) and push to GitHub.

## Sprite / Asset 경로 BASE_URL 통일 (CRITICAL — 78개 404 트랩)

라이브 (https://sigco3111.github.io/hermes-control-room/)에서 sprite 다 깨지면 90% 이 함정.

**원인**: `vite.config.ts`의 `base: '/hermes-control-room/'`가 vite 빌드 후 dist/index.html의 `<script src="/hermes-control-room/...">`에는 자동 prefix 되지만, **`src/**/*.ts(x)` 안에서 직접 작성한 절대경로 (`/sprites/...`, `/rooms/...`)는 prefix 없이 그대로 빌드에 박힘** → 라이브에서 `https://sigco3111.github.io/sprites/...` 로 요청 → 404.

**증상 확인법**:
```bash
# 라이브에서 200
curl -I https://sigco3111.github.io/hermes-control-room/sprites/characters/dev-1-front-left.png
# base 없이 404
curl -I https://sigco3111.github.io/sprites/characters/dev-1-front-left.png
```

**해법**: 모든 sprite/room 절대경로에 `import.meta.env.BASE_URL` prefix 적용.

**1단계: vite-env.d.ts + baseUrl.ts 추가**
```ts
// src/vite-env.d.ts
/// <reference types="vite/client" />

// src/baseUrl.ts
export const BASE_URL: string = import.meta.env.BASE_URL
export function withBase(path: string): string {
  if (!path) return BASE_URL
  if (path.startsWith('http://') || path.startsWith('https://') || path.startsWith('data:')) return path
  if (path.startsWith(BASE_URL)) return path
  const sep = path.startsWith('/') ? '' : '/'
  return `${BASE_URL}${sep}${path}`
}
```

**2단계: 모든 호출처에서 template literal로 변환**
```ts
import { BASE_URL } from './baseUrl'   // components/ 안이면 '../baseUrl'

// single-quoted → template literal
`/sprites/characters/dev-1-front-left.png`  →  `${BASE_URL}sprites/characters/dev-1-front-left.png`
`/rooms/office-day.png`                     →  `${BASE_URL}rooms/office-day.png`
```

**3단계: 검증 단계 — 빌드 후 Playwright로 404 count 측정 + 캡쳐**
```bash
npm run build
# dev 서버 (5182) 또는 라이브 URL을 Playwright로 띄워서:
# 1) console 비어있음
# 2) Network 탭 404 response 0개 (또는 5 미만)
# 3) 깨진 sprite 0개 (모든 `<img>`의 naturalWidth > 0)
```

**배경 rooms 이미지 처리**: 우리 `dist/rooms/`엔 `office-day-dm.png` + `office-night-dm.png`만 있음. `rooms.ts`의 day/night 배경 외 다른 rooms (ceo-/meeting-/kitchen-/server-/lobby-/nap-/rooftop-/gym-/parking-) PNG는 빌드에 없을 수 있음 — 실제 사용 안 하는 room이면 그대로 둬도 됨 (사용자가 그 room으로 navigate 하기 전엔 fetch 안 함).

## Pitfalls
- Large PNG assets (`office-day.png`, `office-night.png`) inflate repo size – delete them or keep the DM versions.
- Leaving Electron scripts in `package.json` will cause the dev server to attempt launching Electron and fail – ensure all references are removed.
- The TypeScript mapping in `themedDisplayName` must use plain ASCII keys to avoid syntax errors.
- After removing `electron/`, update the `main` field in `package.json` (remove `electron/main.cjs`).
- Run `npm install` after editing `package.json` to update the lockfile.
- **`config.ts` JSON import 트랩**: `await import('../office.config.json')`는 top-level await + ESM + 파일 부재 시 깨짐. **inline defaults로 단순화** (`const bossName = 'Hermes'`).
- **dist 빌드는 `tsconfig.json` 기반** (Claude-Office 원본): `npx tsc --noEmit -p tsconfig.json` (App.tsx만 `tsconfig.app.json` 단독 X).
- **74+ 절대 sprite/room 경로 일괄 변환 시 regex sweep 함정**: 일부 파일은 `/sprites/...` (base 없음), 일부는 `/hermes-control-room/sprites/...` (이미 prefix 일부 박힌 과거 코드) 두 형태로 섞여 있음. 단일 regex `'/sprites/...'`만 매치하면 prefix된 형태가 모두 누락되어 4~6개 파일에 12~24개 잔존. **전수 sweep regex**:
  ```python
  re.sub(r"'/sprites/([^']+)'", r"`\${BASE_URL}sprites/\1`", content)
  re.sub(r"'/room/([^']+)'",  r"`\${BASE_URL}rooms/\1`",  content)
  re.sub(r"'/hermes-control-room/sprites/([^']+)'", r"`\${BASE_URL}sprites/\1`", content)
  re.sub(r"'/hermes-control-room/rooms/([^']+)'",  r"`\${BASE_URL}rooms/\1`", content)
  ```
  또는 `grep -rn "'/sprites\|'/rooms\|/hermes-control-room/sprites\|/hermes-control-room/room" src/`로 한 번 더 잔존 확인 필수.
- **Theme pack의 `getSpriteDir()`, `getRoomImage()`, `getAngelaCat()`, `OFFICE_PROPS_BY_SLUG`, `OFFICE_GENERIC_PROPS`, `OFFICE_CATS_PATHS` 6군데** 모두 BASE_URL 적용 — 가장 자주 빠지는 곳. `theme.ts`만 grep -n "BASE_URL" 으로 검증.
- **`sed` 빌드 후 post-build 변환 — 이게 정답이었다 (2026-08-04 실측)**: TypeScript regex sweep가 모든 src 파일에 BASE_URL을 박아도, **vite가 빌드한 JS 번들에는 `"/sprites/..."` 가 그대로 박혀있다**. 이유: `theme.ts:133` 의 `` `${BASE_URL}sprites/office/characters` `` 가 빌드 시점에 inlining되어 `"/hermes-control-room/"` + `"/sprites/..."` 두 string으로 split — 런타임에 concat → `"/hermes-control-room//sprites/..."` (이중 슬래시). gh-pages는 이중 슬래시를 `/sprites/` 로 normalize해서 200 OK 하지만, **다른 sprite 경로 (assets.ts, agentManager.ts 등에서 `` `${BASE_URL}...png` `` 형식) 는 JS에 `"/sprites/...png"` 가 직접 박혀 라이브에서 404**.
  - **증상 확인법**:
    ```bash
    grep -oE '"/sprites/[a-zA-Z0-9_/-]+' /Users/mac/work/hermes-control-room/dist/assets/index-*.js | wc -l
    # → 84개 sprite + 6개 room = 90개가 /sprites/ 그대로 박혀있으면 실패
    ```
  - **해법 (post-build sed — 가장 확실)**: TypeScript 단계에서 `import.meta.env.BASE_URL`을 사용해도 vite는 BASE_URL 식별자를 inlining해서 string으로 풀어버린다. **빌드 후 JS를 직접 변환**이 유일한 확실한 해결:
    ```bash
    cd <our-repo>
    sed -i '' 's|"/sprites/|"/hermes-control-room/sprites/|g' dist/assets/index-*.js
    sed -i '' 's|"/rooms/|"/hermes-control-room/rooms/|g' dist/assets/index-*.js
    # 검증
    grep -oE '"/sprites/[a-zA-Z0-9_/-]+' dist/assets/index-*.js | wc -l
    # → 0개
    grep -oE '"/hermes-control-room/sprites/[a-zA-Z0-9_/-]+' dist/assets/index-*.js | wc -l
    # → 84개 (변환된 개수)
    ```
  - **자동화하려면 gh-pages push 직전에 sed를 항상 포함**:
    ```bash
    npm run build
    sed -i '' 's|"/sprites/|"/hermes-control-room/sprites/|g' dist/assets/index-*.js
    sed -i '' 's|"/rooms/|"/hermes-control-room/rooms/|g' dist/assets/index-*.js
    # fresh-clone으로 push
    cd /tmp/fresh-clone && cp -r <our-repo>/dist/. . && touch .nojekyll
    git add -A && git commit -m "deploy: BASE_URL post-build sed" && git push -u origin gh-pages --force
    ```
  - **TypeScript 단계 변환의 의미**: TypeScript 단계에서 `${BASE_URL}` 박는 건 **type safety + 의도 표현** 용도일 뿐, **런타임 빌드 결과에는 영향 없음**. 즉 두 단계 (TS regex sweep + post-build sed) 모두 필요. TS sweep은 코드 가독성/유지보수성, post-build sed는 실제 런타임 동작.
- **Playwright phantom 404 함정 (2026-08-04 실측)**: 첫 검증 시 **78개 404 보고 → 진단 → 진짜 5개**. 같은 페이지를 같은 브라우저 컨텍스트로 두 번째 network idle 후 검증하면 404 count가 정상으로 떨어짐. **반드시 `await ctx.newContext()`로 fresh context + networkidle 충분 wait 후 검증**, 첫 결과는 무시.
  - 진단: `const fails = []; page.on('response', r => { if (r.status() === 404) fails.push(r.url()) })` + `await page.waitForTimeout(5000)` 후 측정
  - 진짜 404와 `ERR_ABORTED` (취소된 요청) 구분 필수 — 후자는 정상
- **md5 일치 = push 성공 트랩 (2026-08-04 실측)**: `dist/index-*.js` md5와 라이브 md5가 같은데도 Playwright가 404 보고하는 경우 — 첫 30초 안에 깐 Playwright 캐시가 stale. md5가 일치하면 **푸시는 정상이고 Playwright만 늦음** → 1~2분 후 재검증.
- **Playwright 404 + 진짜 JS sprite 박힘의 구분법 (2026-08-04 실측)**: 78개 404 보고가 떴을 때, **`grep -oE '"/sprites/' dist/assets/index-*.js | wc -l` 로 JS 안에 실제로 박힌 unprefixed 경로 개수를 세야 함**. 0개면 진짜 Playwright phantom. 50개 이상이면 진짜로 빌드 안 됨 — sed 필요. **404 카운트만 믿지 말고 JS grep으로 교차 확인 필수**.
- **`requestfailed` 이벤트 함정 (2026-08-04)**: `requestfailed` 이벤트는 `ERR_ABORTED` (canceled by navigation) 또는 `ERR_CONNECTION_REFUSED` (백엔드 미가동, 예: WebSocket 서버) 등 다양한 network 오류를 포함. `status === 404` (response status) 와는 별개. **진짜 404 = `page.on('response')` 에서 status code 404** 만 신뢰. `requestfailed` 는 무시 (특히 페이지 unload 직전 시 cancel된 요청은 정상).
- **`.app-body` CSS 중복 선언 함정 (2026-08-04 실측)**: Twin Lab 톤 CSS를 office.css에 추가할 때, **기존 `.app-body` 블록이 그대로 남아있으면 cascade 충돌** (후행 선언 우선, 옛 정의가 이김). 자식 absolute/relative의 부모 relative 기준점이 사라져 룸 콘텐츠가 안 보임. **증상**: 헤더 + 사이드 + 티커는 보이는데 룸 영역만 검은색. **진단**: `grep -n "^\.app-body" src/styles/office.css` → 정의 1개만 있어야 함. **해결**: 옛 `.app-body` 블록 (Twin Lab 톤보다 아래에 있는 블록) 통째 삭제.
- **CSS 비례 — 룸이 viewport 가득 안 채우는 함정 (2026-08-04 실측)**: `.office-view` 정의 부재 시 block 렌더되어 `.room-container`가 viewport 안 채움. **증상**: 룸이 화면 가운데 작은 정사각형으로 표시, 검은 여백 큼. **해결** (CSS 3줄):
  ```css
  .office-view { flex: 1; position: relative; min-width: 0; min-height: 0; overflow: hidden; }
  .office-view::before { content: ''; display: block; padding-bottom: 74.6%; }  /* 3584/4800 */
  .office-view .room-container { position: absolute; inset: 0; width: 100%; height: 100%; }
  ```
  + App.tsx의 inline `aspectRatio/width/maxHeight/position` 모두 제거 (CSS가 sizing 전담).
- **위임이 만든 컴포넌트 잔존 import 함정 (2026-08-05 실측)**: 위임이 `RoomView`/`RoomSidebar` 컴포넌트를 만들고 사용 후 **파일만 삭제**하고 **import는 남기는** 경우. **증상**: `TS2307: Cannot find module './components/RoomView'`. 진단: `grep -rn "RoomView\|RoomSidebar" src/` 1번 더. 해결: import도 함께 삭제 또는 컴포넌트 파일 복원.
- **함수 중복 정의 함정 (2026-08-05 실측)**: 위임이 `HERMES_TO_ROOM` 같은 const/함수를 두 군데 추가하고 한쪽은 삭제 안 한 경우. **증상**: `TS2451: Cannot redeclare block-scoped variable`. 진단: `grep -n "HERMES_TO_ROOM\|export const HERMES" src/App.tsx` 또는 `npx tsc --noEmit -p tsconfig.json` 결과. 해결: 중복 정의 중 한쪽 삭제.
- **`/tmp/fresh-clone`의 fragility 함정 (2026-08-05 실측)**: 위임 작업 중에 fresh-clone이 다른 브랜치에 commit + push 시도 → main에 잘못된 deploy commit이 들어가거나, fresh-clone이 위임 사이에 삭제되거나 다른 branch로 잘못 reset. **해결**: 푸시 직전 항상 `git -C /tmp/fresh-clone status` + `git -C /tmp/fresh-clone branch` 확인. 위임이 gh-pages에 푸시하려 했는데 fresh-clone이 main에 있을 때 orphaned commit이 main에 들어감. **`git checkout --orphan gh-pages` 후 `rm -rf .` + 복사 + add + commit + push` 로 명시적으로 gh-pages에 푸시**.

## 🆕 함정 — `post-build.sh`의 bash glob + `set -e` (2026-08-05 실측, NEW)

post-build.sh 가 `JS_FILE=$(ls dist/assets/index-*.js | head -1)` 패턴으로 `JS_FILE` 을 잡을 때, **bash glob expansion 실패 시 literal 패턴 문자열이 stdout 으로 나가서 `[ -z "$JS_FILE" ]` 가 false 가 됨 → sed 가 빈 문자열 대신 에러 메시지를 파일 경로로 받아 silent failure**.

### 증상
```bash
JS_FILE=$(ls dist/assets/index-*.js | head -1)
if [ -z "$JS_FILE" ]; then
  echo "[post-build] no index-*.js found in dist/assets/"
  exit 1
fi
# glob 매칭 실패 시:
# → stdout: "ls: dist/assets/index-*.js: No such file or directory"
# → JS_FILE="ls: dist/assets/index-*.js: No such file or directory"
# → [ -z ] false → sed silent failure
```

### 해결 — `shopt -s nullglob` + 배열
```bash
#!/usr/bin/env bash
set -euo pipefail
shopt -s nullglob                   # glob 매칭 실패시 빈 배열
JS_FILE=(dist/assets/index-*.js)
if [ ${#JS_FILE[@]} -eq 0 ]; then
  echo "[post-build] no index-*.js found in dist/assets/"
  exit 1
fi
JS_FILE="${JS_FILE[0]}"
sed -i.bak 's|"/sprites/|"/hermes-control-room/sprites/|g; s|"/rooms/|"/hermes-control-room/rooms/|g' "$JS_FILE"
rm -f "$JS_FILE.bak"
```

**핵심 규칙**: bash `set -e` 환경에서 `$(ls glob)` + 빈 매칭은 거의 매번 함정. **항상 `shopt -s nullglob` + 배열 + 인덱스 접근 패턴** 권장.

**누적 인스턴스**: 2026-08-05 post-build.sh 가 첫 실행에서 `JS_FILE` 비어서 sed silent failure → 빌드된 dist/assets/index-*.js 가 prefix 없이 /sprites/ 그대로 박힘 → 라이브에서 404. 두 번째 실행은 수동으로 `JS_FILE=(dist/assets/index-*.js); JS_FILE="${JS_FILE[0]}"` 패턴으로 우회.

## 🆕 함정 — Playwright sandbox vs 시스템 python 분리 (2026-08-05 실측, NEW)

Hermes `execute_code` 도구의 sandbox 인터프리터에는 `playwright` 모듈이 없어서 import 시 `ModuleNotFoundError`. 그러나 macOS 시스템의 `python3` (`/Applications/Xcode.app/Contents/Developer/usr/bin/python3`) 에는 `playwright` 가 설치되어 있어 정상 import 가능.

### 진단
```bash
# execute_code 안에서 실행 시 → ModuleNotFoundError (sandbox 한계)
from playwright.sync_api import sync_playwright

# terminal 안에서 python3 직접 실행 시 → 정상
python3 -c "from playwright.sync_api import sync_playwright"
# /Users/mac/Library/Python/3.9/lib/python/site-packages/playwright 사용
```

### 해결 패턴 — terminal 에서 시스템 python 직접 실행
```bash
# 1) Playwright 캡쳐 스크립트는 write_file 로 /tmp/에 작성
write_file /tmp/hermes-capture.py "from playwright.sync_api import sync_playwright; ..."

# 2) terminal 에서 시스템 python 으로 실행
python3 /tmp/hermes-capture.py
# 또는 명시적으로
/Applications/Xcode.app/Contents/Developer/usr/bin/python3 /tmp/hermes-capture.py
```

**핵심 규칙**: `execute_code` 는 Python stdlib + LLM 필터링 작업용. **Playwright 같은 외부 의존성 검증은 항상 `terminal` + 시스템 python**.

## 🆕 패턴 — gh-pages 서브경로 로컬 검증용 symlink (2026-08-05 실측, NEW)

vite 가 `base: '/hermes-control-room/'` 로 빌드된 dist 를 **로컬에서 서브경로로** 띄우려면, `python -m http.server --directory` 가 서브경로를 자동 처리하지 않으므로 **symlink 로 서브경로 디렉토리 흉내**:

```bash
# 1) 임시 serve 루트 + 서브경로 심볼릭 링크
mkdir -p /tmp/hermes-serve
ln -sfn /Users/mac/work/hermes-control-room/dist /tmp/hermes-serve/hermes-control-room

# 2) 서브경로로 serve
python3 -m http.server 8765 --directory /tmp/hermes-serve --bind 127.0.0.1 &

# 3) Playwright 검증
# → http://127.0.0.1:8765/hermes-control-room/index.html
# → sprite 경로 /hermes-control-room/sprites/... 정상 200 OK
# → 라이브 (https://sigco3111.github.io/hermes-control-room/) 와 동일 prefix 검증
```

**왜 작동하는가**: `vite base` 가 박은 prefix 와 gh-pages URL 의 prefix 가 동일 → symlink 로 동일 prefix 의 로컬 URL 만들면 라이브와 픽셀 단위로 동일하게 동작.

**cleanup**: `rm -rf /tmp/hermes-serve` + `kill <http.server PID>`.
- **함수 중복 정의 함정 (2026-08-05 실측)**: 위임이 `HERMES_TO_ROOM` 같은 const/함수를 두 군데 추가하고 한쪽은 삭제 안 한 경우. **증상**: `TS2451: Cannot redeclare block-scoped variable`. 진단: `grep -n "HERMES_TO_ROOM\|export const HERMES" src/App.tsx` 또는 `npx tsc --noEmit -p tsconfig.json` 결과. 해결: 중복 정의 중 한쪽 삭제.
- **`/tmp/fresh-clone`의 fragility 함정 (2026-08-05 실측)**: 위임 작업 중에 fresh-clone이 다른 브랜치에 commit + push 시도 → main에 잘못된 deploy commit이 들어가거나, fresh-clone이 위임 사이에 삭제되거나 다른 branch로 잘못 reset. **해결**: 푸시 직전 항상 `git -C /tmp/fresh-clone status` + `git -C /tmp/fresh-clone branch` 확인. 위임이 gh-pages에 푸시하려 했는데 fresh-clone이 main에 있을 때 orphaned commit이 main에 들어감. **`git checkout --orphan gh-pages` 후 `rm -rf .` + 복사 + add + commit + push` 로 명시적으로 gh-pages에 푸시**.

## Push to GitHub (CRITICAL — 가장 자주 막히는 구간)

**1단계: remote URL 검증 (위임이 자주 틀림)**

```bash
git -C <repo> remote -v
# origin이 W17ant/Claude-Office.git로 잡혀있으면 → 403 denied
# 반드시 sigco3111/hermes-control-room.git로 재설정:
git remote set-url origin https://github.com/sigco3111/hermes-control-room.git
```

**위임이 Claude-Office를 clone할 때 default remote를 그대로 가져오는 함정** — 모든 push 명령 직전에 확인.

**2단계: force push에서 unpack failed (`b0bb8de7...` 같은 missing object) — fresh clone 우회 패턴**

증상: `git push --force`가 `remote: fatal: did not receive expected object ...` + `index-pack failed`로 반복 실패. 원인: remote repo의 어딘가에서 우리 로컬엔 없는 객체를 참조 → pack 검증 실패. 일반적인 `git pull --rebase`로는 안 풀림.

**해결**:
```bash
# 1) fresh clone 디렉토리 생성
rm -rf /tmp/fresh-clone
cd /tmp
git clone --depth 1 https://github.com/sigco3111/hermes-control-room.git fresh-clone

# 2) 우리 작업물을 fresh-clone에 복사 (.git 제외)
cd <our-repo>
for item in src public package.json package-lock.json tsconfig*.json vite.config.ts index.html README.md LICENSE docs; do
  cp -r "$item" /tmp/fresh-clone/ 2>/dev/null
done
cat >> /tmp/fresh-clone/.gitignore << 'EOF'
node_modules/
.verify/
EOF

# 3) commit + push from fresh-clone
cd /tmp/fresh-clone
git config user.email "sigco3111@users.noreply.github.com"
git config user.name "sigco3111"
git add -A
git commit -m "..."
git push -u origin main --force

# 4) gh-pages도 동일 패턴
git checkout --orphan gh-pages
git rm -rf . 2>&1 | head -5
cp -r <our-repo>/dist/* .
touch .nojekyll
git add -A
git commit -m "deploy: ..."
git push -u origin gh-pages --force
```

**왜 작동하는가**: fresh clone은 remote의 단일 `Initial commit`에서 시작 → 우리 로컬 작업물의 모든 객체를 새로 push하므로 remote corruption이 개입할 여지가 없어짐.

**3단계: 큰 dist 푸시 — `public/sprites/` 47MB 정도는 OK (GitHub 100MB 한도 내)**, 하지만 `office-day.png`/`office-night.png` 같은 19MB+ 단일 파일은 unpack 단계에서 stream 끊김 가능.

## Push Force-with-care

`--force-with-lease` 기본 권장. 단, remote corruption 우회 시엔 `--force` 필요.

## Twin Lab 톤 UI: Header + Side Panel + Ticker (2026-08-04 A-2)

Claude-Office 기본 UI를 Twin Lab 톤으로 polish할 때 쓰는 패턴. 기존 `.title-bar` 통째로 3요소 구조로 교체.

### 색 팔레트 (CSS 변수 한 세트로 통일)
- 헤더: `#0d0d12` → `#131622` → `#1a1f2e` (linear-gradient 90deg)
- 사이드 패널: `rgba(245, 249, 247, 0.96)` + `backdrop-filter: blur(14px) saturate(160%)` (glassmorphism)
- 티커: dark navy `#0d0d12` → `#131622` 그라데이션
- 액센트: `--lab-accent: #5b6cff`, `--lab-cyan: #6ce5e8` (시계/라벨 glow)

### 3요소 구조 (office.css + App.tsx 동시 수정)
- **헤더 (56px, `.lab-header`)**: 좌측 로고+타이틀, cyan 시계 (HH:MM monospace tabular-nums), 우측 4 메트릭 카드 (활성 크론 / 메모리 / Tistory 오늘 / 오늘 세션)
- **사이드 패널 (280px, `.lab-side-panel`)**: glassmorphism + 8개 부서 row + 선택 시 detail (status pill + last_run + next_run + scripts[] tag)
- **티커 (32px, `.lab-ticker`)**: dark navy + cyan 라벨 + 60s linear `translateX(-100%)` 흐름 + hover pause

### 8개 Hermes 부서 (cron skill prefix → room)
1. 📝 tistory — `tistory-publisher`, `periodic-data-pipeline`
2. 🌅 briefing — `morning-briefing`, `invest-memo`, `agentnews-monitor`
3. ⚙️ automation — `automation-healthcheck`, `cron-*`, `nightly-*`, `memory-error-tracker`
4. 🔍 research — `github-trending-monitor`, `ios-trend-digest`, `auto-researcher`
5. 📓 notion — `notion-*`, `knowledge-graph`, `llm-wiki`
6. 📈 trading — `stock-market-*`, `portfolio-rebalancer`, `trading-strategy`
7. 🎬 media — `notebooklm-youtube-automation`, `music-video-generator`, `ai-music`
8. 🔧 devops — `kanban-*`, `requesting-code-review`, `simplify-code`, `flywheel`

매칭 안 되면 `automation` fallback. rooms.ts의 11개 룸과 1:1 매칭 아님 (background image source로만 사용).

## State Snapshot Pipeline (5분 cron live 업데이트)

### 데이터 소스 (HERMES_HOME = ~/.hermes)
- `cron/jobs.json` → `data.jobs[].{id, name, skill, last_run_at, next_run_at, last_status, enabled, paused_at}`
- `state.db` (SQLite) → `SELECT COUNT(*) FROM sessions WHERE started_at >= ? AND started_at < ?` (**started_at은 REAL unix timestamp**, `created_at` 컬럼 없음)
- `MEMORY.md` → `wc -c` (메모리 사용량 bytes)
- `memory/blog_details.json` → `data.details[].date == today` (Tistory 오늘 발행)

### 출력 스키마 (public/state.json)
```json
{
  "generatedAt": "2026-08-04T08:14:00Z",
  "metrics": {
    "activeCrons": 19, "memoryUsed": 12001, "memoryCap": 2200,
    "tistoryToday": 0, "sessionCount": 40
  },
  "rooms": {
    "tistory": {
      "status": "active", "lastRun": "...", "nextRun": "...",
      "scripts": ["b1bca63a117a"]
    }
  },
  "ticker": ["📝 Tistory 발행 완료", "🔍 에러 감시 0건"]
}
```

### GitHub Actions workflow (5분마다 state.json 갱신)
```yaml
# .github/workflows/snapshot-state.yml
name: state snapshot
on:
  schedule: [{ cron: '*/5 * * * *' }]
  workflow_dispatch:
jobs:
  snapshot:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: '20' }
      - run: npm ci
      - run: node scripts/snapshot-state.mjs
      - uses: stefanzweifel/git-auto-commit-action@v5
        with: { commit_message: 'state: snapshot $(date +%Y-%m-%dT%H:%M)' }
```

### Deploy Workflow (빌드 + post-build sed + gh-pages push)
```yaml
# .github/workflows/deploy.yml
name: deploy
on:
  push: { branches: [main] }
jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: '20' }
      - run: npm ci
      - run: npm run build
      - run: |
          sed -i 's|"/sprites/|"/hermes-control-room/sprites/|g' dist/assets/index-*.js
          sed -i 's|"/rooms/|"/hermes-control-room/rooms/|g' dist/assets/index-*.js
      - uses: actions/cache@v4
        with:
          path: ~/.npm
          key: ${{ runner.os }}-npm-${{ hashFiles('**/package-lock.json') }}
      - uses: peaceiris/actions-gh-pages@v4
        with:
          github_token: ${{ secrets.GITHUB_TOKEN }}
          publish_dir: ./dist
```

## Pitfalls (Twin Lab 추가)
- **`.app-body` CSS 중복 선언**: Twin Lab 톤 추가 patch 시 기존 `.app-body` 블록이 2개로 나뉘면 후행 선언 우선. **`grep -c "^\.app-body"`로 1개만 남는지 검증 필수**.
- **타이틀바 → 헤더 JSX 교체**: 기존 `<div className="title-bar">...</div>` 통째를 `.lab-header` 구조로 교체. `.title-bar-*` CSS는 dead code로 남아있어도 컴파일 영향 없음 (다른 컴포넌트가 안 쓰면 OK).
- **메모리 표기 단위**: `MEMORY.md`는 bytes (`wc -c` = 12001), 사용자가 원하는 표시는 2189/2200 (line 단위 추정). snapshot-state.mjs에서 명시적으로 단위 결정 + 표시. cap은 환경 상수 (예: 2200 lines) 또는 env var.
- **state.db는 3.6GB+ SQLite, Actions 환경엔 그 절대경로 없음**: snapshot-state.mjs를 Actions에서 실행하면 `~/.hermes/state.db` 못 찾음. **client-side fetch('/state.json') 30s 폴링 + 메트릭 stale 허용** + "마지막 업데이트: X분 전" 라벨로 fallback. 또는 자체 호스팅 cron (희정님 Hermes 워크스테이션) 환경에서 state.json을 repo에 push.
- **부서 status 결정**: room의 assigned cron jobs majority vote (`last_status` 합산 → ok/error/idle/waiting). cron 없으면 idle.
- **`wc -c` vs `wc -l` 함정**: `MEMORY.md` 길이는 의미상 "사용량"이지만 12001 bytes vs 2200 라인 차이 큼. README/MEMORY.md 표준 라인 한도가 4000이라는데 `MEMORY.md`는 12001 bytes. **단위 표준화** (lines, chars, bytes) — Hermes 환경에서는 보통 **chars** (한글 1자 = 1 char) 사용.
- **`baseUrl.ts` 작성 후 `tsc` 0 에러 유지를 위해 `vite-env.d.ts` 동시 추가**: `import.meta.env`은 vite/client type 없으면 TS2339 에러. 잊지 말 것.
- **rooms.ts 11개 ↔ 8개 Hermes 부서**: 부서 ID와 룸 ID는 별도. 부서 ID는 도메인 (tistory/briefing/...), 룸 ID는 픽셀 (main-office/cto-office/...). 부서 → 룸은 `sourceRoom` 필드로만 매핑.
- **사용자 결정 (2026-08-05): 룸은 1개 + 부서 8개 chip은 사이드 패널 트리거만**: 부서 chip 클릭 시 **룸 전환 안 함**. 1개 큰 룸 (main-office)만 표시, 부서 chip은 헤더에 그대로 두되 사이드 패널 정보만 갱신. 즉 **RoomSidebar / RoomView 컴포넌트 만들지 마** (사용자 결정). **rooms.ts 11개 룸 정의 + rooms.css ROOM NAVIGATOR CSS는 그대로 둬도 OK** (사용 안 함).
- **Cache-bust `?v=` 쿼리 강제 갱신 패턴 (2026-08-05 실측)**: gh-pages CDN이 옛 build를 보여주는 경우 (사용자 강력 새로고침에도 404), `<script>`/`<link>` URL에 `?v=YYYYMMDD` 쿼리 추가:
  ```html
  <script src="/hermes-control-room/assets/index-XXXX.js?v=20260805d"></script>
  <link rel="stylesheet" href="/hermes-control-room/assets/index-XXXX.css?v=20260805d">
  ```
  빌드 해시가 바뀔 때마다 `?v=` 값을 새 해시 또는 새 날짜로 갱신. **메타 tag 강화**:
  ```html
  <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate, max-age=0">
  <meta http-equiv="Pragma" content="no-cache">
  ```
  - **`?v=` 쿼리만 추가하면 옛 JS 자산은 캐시 무력화, 새 JS 자동 로드.** 검증: `curl -I ...?v=20260805d` → 새 asset 200. **gh-pages CDN 전파 1~3분 소요** (5분 후 재검증).

## References
- `references/session-20230804-conversion.md` – command logs, file sizes, and notes from this session.
- `references/git-push-unpack-failed-fresh-clone.md` – fresh clone 우회 패턴의 풀 절차 + 진단.
- `references/sprite-baseurl-404-batch-fix.md` – BASE_URL 일괄 적용 8단계 + 검증 + push (2026-08-04 라이브 78개 404 사례).
