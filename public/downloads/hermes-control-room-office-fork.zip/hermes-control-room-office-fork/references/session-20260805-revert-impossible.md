---
title: Session 2026-08-05 — revert 불가능 케이스 + 위임 import 잔존
session_date: 2026-08-05
project: hermes-control-room
summary: >-
  "강력한 새로고침을 했지만 변화없음" 트랩. 사용자 만족 시점의 gh-pages commit이
  이전 push --force로 origin에서 사라진 상태에서 revert 시도, 실패, source 재구성
  + 위임이 만든 컴포넌트 잔존 import 정리.
related: SKILL.md §"Pitfalls", §"Push to GitHub", §"Twin Lab 톤 UI"
---

## 시나리오

사용자(희정님)가 8/4 17:00 시점 라이브(`4d08495`)에서 Twin Lab 톤 헤더 + 8개 부서 chip
+ Dunder Mifflin 룸 + 캐릭터 + 사이드 패널 + 티커 + 메트릭 화면을 "이게 내가 원한 거"
라며 만족.

8/5 0시 이후 우리 작업 (`7b8c86b` 등) push --force 로 gh-pages를 덮어써서
`4d08495` commit이 origin에서 사라짐.

8/5 18:00 사용자: "강력한 새로고침을 했지만 변화 없음. 롤백한 것으로 푸시하지 않아서 그런가?"

## 트랩 3가지 (실측)

### 트랩 1: `git reset --hard <commit>` 실패 (commit missing)

```bash
git reset --hard bc2f2f2
# fatal: ambiguous argument 'bc2f2f2': unknown revision or path not in the working tree.
```

**진단**:
```bash
git ls-remote origin | grep <commit>
# → 출력 없음 = origin에 그 commit 없음
git -C /tmp/fresh-clone log --oneline --all
# → `034fea6` + `abd8375` 만 (4d08495 없음)
```

**해결**: revert 불가능 → **source에서 재구성** (아래 §3).

### 트랩 2: 위임이 만든 컴포넌트 잔존 import / 함수 중복

위임이 `RoomView`/`RoomSidebar` 컴포넌트를 만들고 사용 후 **파일만 삭제**하고
**import는 남긴** 경우. 또 `HERMES_TO_ROOM` const를 두 군데 추가하고 한쪽만 삭제한
경우.

**증상**:
```
src/App.tsx(12,22): error TS2307: Cannot find module './components/RoomView'
src/App.tsx(67,7): error TS2451: Cannot redeclare block-scoped variable 'HERMES_TO_ROOM'
```

**진단** (위임 종료 후 10초):
```bash
# import되지만 파일 없는 컴포넌트
for f in $(find src -name '*.ts' -o -name '*.tsx'); do
  grep -oP "from ['\"][^'\"]*components/([A-Z][A-Za-z]+)['\"]" "$f" | while read m; do
    p=$(echo "$m" | grep -oP "/([A-Z][A-Za-z]+)['\"]" | tr -d "'\"/")
    [ ! -f "src/components/$p.tsx" ] && [ ! -f "src/components/$p.ts" ] && echo "❌ $f imports missing $p"
  done
done
# 중복 정의
grep -n "^const HERMES_TO_ROOM\|^function HERMES_TO_ROOM" src/*.ts src/*.tsx
# tsc
npx tsc --noEmit -p tsconfig.json 2>&1 | head -10
```

**해결**:
- import만 남음 → import 줄 삭제 또는 파일 복원
- 함수/const 중복 → `git show <이전-ok-commit>:src/App.tsx > src/App.tsx` 또는
  `git checkout HEAD -- src/App.tsx` 후 재작업

**위임 dispatch 컨텍스트에 명시**:
> "이전 위임이 만든 컴포넌트는 사용 안 하면 파일 + import 모두 정리"

### 트랩 3: `src/main.tsx` 누락 (build: 1)

dd5e521 시점의 source를 추출해서 우리 repo에 덮어쓸 때, `dd5e521` 커밋엔
`src/main.tsx` 가 없었음 (main.tsx는 다른 시점에서 추가된 듯). 우리 repo에서
`main.tsx` 없이 `npm run build` 시:

```
error during build: ... rollup-plugin-react/...
could not resolve ... src/main.tsx
```

**해결**: main.tsx 생성 후 빌드.
```tsx
// src/main.tsx
import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import App from './App'

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
)
```

## 진단 5단계 (사용자 "변화 없음" 보고 시)

```bash
# 1. 라이브와 우리 dist md5 비교
curl -s "https://sigco3111.github.io/hermes-control-room/assets/$(ls dist/assets/index-*.js | xargs basename)" | md5
md5 dist/assets/index-*.js
# → 다르면 푸시 자체가 안 됨
# → 같으면 사용자가 보던 거 ≠ 푸시된 거

# 2. 사용자가 보던 commit이 origin에 있는지
git ls-remote origin | grep <commit>
# → 없으면 revert 불가능

# 3. 우리 repo의 reflog에 있는지
git reflog | head -5
# → 있으면 우리 repo엔 있음 (fresh-clone에만 없는 거)

# 4. fresh-clone의 history 깊이
git -C /tmp/fresh-clone log --oneline --all
# → `--depth 1` clone은 옛 commit 안 가져옴 → `git fetch origin --unshallow` 필요

# 5. .app-body / .office-view 정의 개수 (CSS 비례)
grep -c "^\.app-body" src/styles/office.css   # 1 이어야 정상
grep -c "^\.office-view" src/styles/office.css # 1 이어야 정상
```

## 해결 — source 재구성 패턴

**revert 불가능 + 우리 repo엔 만족 시점 commit 있는 경우**:

```bash
# 1. 우리 repo의 만족 시점 (또는 직전) commit 찾기
git log --oneline --all | grep -i "twin\|tone\|header" | head -5
# → dd5e521 (Twin Lab tone header/side/ticker + Actions sed + data fetch)

# 2. 그 commit에서 source 추출
mkdir -p /tmp/source
git show dd5e521:src/App.tsx > /tmp/source/App.tsx
git show dd5e521:src/styles/office.css > /tmp/source/office.css
git show dd5e521:src/baseUrl.ts > /tmp/source/baseUrl.ts
# ... 나머지 파일

# 3. public 디렉토리 추출
mkdir -p /tmp/source/public
git ls-tree -r dd5e521:public | while read line; do
  hash=$(echo "$line" | awk '{print $3}')
  path=$(echo "$line" | awk '{$1=$2=$3=""; print}' | xargs)
  rel="${path#public/}"
  mkdir -p "/tmp/source/public/$(dirname "$rel")"
  git cat-file blob "$hash" > "/tmp/source/public/$rel"
done

# 4. 우리 repo에 적용
cp -r /tmp/source/* /Users/mac/work/hermes-control-room/

# 5. main.tsx 누락 시 생성 (위 §트랩 3)

# 6. npm install + build
cd /Users/mac/work/hermes-control-room
npm install --include=dev
npm run build

# 7. post-build + state.json + cache-bust + gh-pages 푸시
```

## 만족 시점 commit이 우리 repo에도 없는 경우

1. **GitHub history 어딘가에 있을 수 있음** (PR fork, branch, archive):
   ```bash
   gh api repos/sigco3111/hermes-control-room/commits?per_page=100 -q ".[].sha"
   ```
2. **GitHub Refs 탭**에서 옛 branch 확인
3. **GitHub Event log** (`https://github.com/sigco3111/hermes-control-room/activity`) — push --force 전 commit 이력

가장 안전: **사용자에게 만족 시점의 commit SHA 또는 스크린샷 + URL** 요청.
스크린샷이 있으면 우리 repo의 비슷한 시점 commit (Twin Lab 톤 키워드) 의 source로
거의 재현 가능.

## 교훈

- **push --force는 사용자 만족 상태를 영구 삭제할 수 있음** — 충분한 신중 필요
- **위임이 만든 컴포넌트는 파일 + import 양쪽 정리** (한쪽만 정리 시 다음 세션 함정)
- **source 재구성 패턴은 우리 repo의 만족 시점 commit이 살아있을 때만 작동** — 없으면 사용자 만족 상태 영영 복원 불가
- **md5 일치 = 푸시 성공이지만 사용자 만족은 보장 안 함** (사용자 만족 시점이 다를 수 있음)
- **"변화 없음" 보고 시 가장 먼저 라이브와 우리 dist md5 비교** — 푸시 자체 실패 vs 사용자가 다른 시점 기대 vs 진짜 캐시
