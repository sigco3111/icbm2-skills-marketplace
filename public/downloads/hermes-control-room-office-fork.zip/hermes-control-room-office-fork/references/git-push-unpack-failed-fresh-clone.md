# Git push `unpack failed` — fresh clone 우회 패턴

## 증상

```bash
$ git push -u origin main --force
remote: fatal: did not receive expected object b0bb8de7f6ed0dbb5f2d505b67dff79f0745aa01
error: remote unpack failed: index-pack failed
To https://github.com/sigco3111/hermes-control-room.git
 ! [remote rejected] main -> main (failed)
```

`--force-with-lease`도 같은 에러. `git pull --rebase` / `git fetch --prune`도 안 풀림. **remote repo의 어딘가에서 우리 로컬엔 없는 객체(`b0bb8de7...`)를 참조** → pack 검증 실패.

## 원인 진단

```bash
git -C <our-repo> cat-file -t b0bb8de7f6ed0dbb5f2d505b67dff79f0745aa01
# fatal: git cat-file: could not get object info
# → 로컬엔 없음

git -C <our-repo> rev-list --all --objects | grep b0bb8de7
# → (로컬에 없음)

git ls-remote origin
# dbc0cd552... refs/heads/main
# 7dd89eb75... refs/heads/gh-pages
# 746682cc0... refs/heads/phase2-pixijs
# → main은 1커밋 (Initial commit), 우리 main은 2커밋 ahead
```

즉 remote main 자체는 깨끗한데, **remote repo의 어딘가에서 (예: 이전 push 시도가 corrupt 객체를 저장하고 refs가 어긋남) `b0bb8de7` 객체를 요구** → unpack 실패.

## 해결: fresh clone 패턴

**핵심**: 우리 작업물을 **완전히 새로운 디렉토리에서 fresh clone 위에** 얹고 거기서 push → remote corruption이 개입할 여지 제거.

### 풀 절차 (hermes-control-room 사례, 2026-08-04)

```bash
# 1) fresh clone
rm -rf /tmp/fresh-clone
cd /tmp
git clone --depth 1 https://github.com/sigco3111/hermes-control-room.git fresh-clone
cd fresh-clone
ls -la
# .git + LICENSE만 있음 (Initial commit 한정)

# 2) 우리 작업물을 fresh-clone에 복사 (.git 제외)
cd <our-repo>   # /Users/mac/work/hermes-control-room
for item in src public package.json package-lock.json tsconfig.json tsconfig.app.json tsconfig.node.json vite.config.ts index.html README.md LICENSE TEST_PLAN.md docs; do
  cp -r "$item" /tmp/fresh-clone/ 2>/dev/null
done
# .claude 폴더 등 무시

# 3) .gitignore 보강
cat >> /tmp/fresh-clone/.gitignore << 'EOF'
node_modules/
.verify/
.gh-pages-temp/
EOF

# 4) commit + push from fresh-clone
cd /tmp/fresh-clone
git config user.email "sigco3111@users.noreply.github.com"
git config user.name "sigco3111"
git add -A
git commit -m "feat: Hermes Control Room — Claude-Office fork with Hermes department mapping

Forked from W17ant/Claude-Office (MIT)
브라우저 전용 변환: Electron/server/hooks 제거
Hermes 8개 부서 매핑: tistory/errors/graph/improve/trend/notebook/blog/infra"
git push -u origin main --force
# → dbc0cd5..ae7711d main -> main (성공)

# 5) gh-pages도 동일 패턴
cd /tmp/fresh-clone
git checkout --orphan gh-pages
git rm -rf . 2>&1 | head -5
cp -r <our-repo>/dist/* /tmp/fresh-clone/
touch /tmp/fresh-clone/.nojekyll
git add -A
git commit -m "deploy: Claude-Office fork + Hermes content (browser-only build)"
git push -u origin gh-pages --force
# → 7dd89eb...e979d93 gh-pages -> gh-pages (forced update, 성공)
```

### 왜 작동하는가

- fresh clone은 remote의 단일 `Initial commit`에서 시작 → 모든 객체가 우리 새 작업물에서 비롯됨
- 이전 push 시도가 remote에 저장했던 corrupt 객체는 **새 push 시 덮어쓰기**되거나 무관해짐
- remote refs graph가 깨끗한 `Initial commit`만 가리키므로 pack 검증이 통과

## 시간/크기 가이드

- fresh clone (shallow `--depth 1`): 5~10초
- 우리 작업물 50MB (47MB sprites 포함): `cp -r` 1~2초
- commit (50MB 한 번에): 3~10초
- push (50MB force): 10~30초

총 30~60초. 정상 `git push`보다 느리지만 unpack failed 대비 압도적으로 빠름.

## 한계

- fresh clone은 1커밋 `Initial commit`만 받음 → 우리 작업물이 거기에 부모로 쌓임
- 이전 히스토리(브랜치/태그) 손실 가능 — push 전 tag 백업 권장:
  ```bash
  git -C <our-repo> push origin --tags --force
  # 또는 사전에 gh-pages-new 같은 별도 브랜치에 저장
  ```
- GitHub 한도: 푸시 100MB/파일, repo 100GB