# Sprite / Room PATH BASE_URL 78개 404 일괄 해결 (2026-08-04)

## 증상

- 라이브 `https://sigco3111.github.io/hermes-control-room/` 에서 sprite 78개 404 (sprite가 깨진 사각형으로 표시).
- dev 서버 (localhost:5182)는 정상이었으나 라이브에서만 깨짐.
- `dist/index.html`은 정상 (`/hermes-control-room/assets/index-...js` 로 prefix 박혀있음).
- 하지만 `dist/sprites/...` 자체는 정상 (vite가 public/ 그대로 복사).

## 진단

```bash
# 200 — base 있음
curl -I https://sigco3111.github.io/hermes-control-room/sprites/characters/dev-1-front-left.png
# 404 — base 없음
curl -I https://sigco3111.github.io/sprites/characters/dev-1-front-left.png
```

`src/**/*.ts(x)` 안에서 vite base prefix 없이 작성된 절대경로 때문. vite는 `dist/index.html`의 `<script>`/`<link>` 경로에만 base prefix 자동 적용함. 직접 작성한 string은 그대로.

## 1단계: 호출처 8개 파일 inventory

| 파일 | 경로 수 | 변환 상태 |
|---|---|---|
| `src/theme.ts` | 21 | 완료 (SpriteDir, RoomImage, AngelaCat, PROPS_BY_SLUG, GENERIC_PROPS, CATS_PATHS 전부) |
| `src/assets.ts` | 37 | 완료 (ASSETS 37개 전부) |
| `src/agentManager.ts` | 12 | 완료 (effects sprite 12개) |
| `src/interactions.ts` | 15 | 완료 (effects sprite 15개) |
| `src/rooms.ts` | 12 | 완료 (rooms 12개) |
| `src/components/Character.tsx` | 1 | 완료 (typing.png) |
| `src/components/PlacementHelper.tsx` | 2 | 완료 (office-day/night + sprite path) |
| `src/components/EffectBubble.tsx` | 0 | 영향 없음 (코멘트만) |

총 100+ 절대경로. 전부 template literal `\`${BASE_URL}...\`` 로 변환.

## 2단계: 신규 파일

```ts
// src/vite-env.d.ts
/// <reference types="vite/client" />

// src/baseUrl.ts
export const BASE_URL: string = import.meta.env.BASE_URL
export function withBase(path: string): string {
  if (!path) return BASE_URL
  if (path.startsWith('http://') || path.startsWith('https://') || path.startsWith('data:')) return path
  if (path.startsWith(BASE_URL)) return path
  const sep = path.startsWith('/') ? '' : '/'
  return `${BASE_URL}${sep}${path}`
}
```

## 3단계: regex sweep (단일 패스 4-패턴)

```python
import re
for path in files:
    content = open(path).read()
    # Pattern 1: '/sprites/...' (base 없음)
    content = re.sub(r"'/sprites/([^']+)'", r"`\${BASE_URL}sprites/\1`", content)
    content = re.sub(r"'/rooms/([^']+)'",  r"`\${BASE_URL}rooms/\1`",  content)
    # Pattern 2: '/hermes-control-room/sprites/...' (이미 prefix 일부 박힘)
    content = re.sub(r"'/hermes-control-room/sprites/([^']+)'", r"`\${BASE_URL}sprites/\1`", content)
    content = re.sub(r"'/hermes-control-room/rooms/([^']+)'",  r"`\${BASE_URL}rooms/\1`",  content)
    # backtick
    content = re.sub(r"`/sprites/", '`${BASE_URL}sprites/', content)
    content = re.sub(r"`/rooms/", '`${BASE_URL}rooms/', content)
    open(path, 'w').write(content)
```

## 4단계: 잔존 검증 (필수)

```bash
grep -rn "'/sprites\|'/rooms\|/hermes-control-room/sprites\|/hermes-control-room/rooms" src/
# → 0 hit 이어야 통과
```

## 5단계: 검증 절차

1. `npx tsc --noEmit` → 0 에러
2. `npm run build` → 성공
3. Playwright로 라이브 + dev(5182) 둘 다 띄워서:
   - console 에러 0
   - Network 404 response 0 (또는 5 미만)
   - 모든 `<img>` 의 `naturalWidth > 0`
4. 캡쳐: 깨진 sprite 0개

## 6단계: push (fresh-clone 패턴)

```bash
# main
cd /tmp/fresh-clone
git checkout main
for item in src public package.json package-lock.json tsconfig*.json vite.config.ts index.html README.md LICENSE docs; do
  cp -r "$item" /tmp/fresh-clone/ 2>/dev/null
done
git add -A && git commit -m "fix: apply BASE_URL to all sprite/room absolute paths"
git push -u origin main --force

# gh-pages
git checkout --orphan gh-pages
git rm -rf . 2>/dev/null
cp -r <our-repo>/dist/* .
touch .nojekyll
git add -A && git commit -m "deploy: BASE_URL sprite fix"
git push -u origin gh-pages --force
```

## 7단계: 라이브 검증 (1~5분)

```bash
# 핵심 sprite 4개 + room 2개 (수동 eye check)
for url in \
  https://sigco3111.github.io/hermes-control-room/sprites/characters/dev-1-front-left.png \
  https://sigco3111.github.io/hermes-control-room/sprites/office/characters/michael-scott-front-left.png \
  https://sigco3111.github.io/hermes-control-room/sprites/office/props/worlds-best-boss-mug.png \
  https://sigco3111.github.io/hermes-control-room/sprites/office/cats/cat-princess-lady.png \
  https://sigco3111.github.io/hermes-control-room/rooms/office-day-dm.png \
  https://sigco3111.github.io/hermes-control-room/rooms/office-night-dm.png; do
  curl -s -o /dev/null -w "%{http_code} $url\n" "$url"
done
# 전부 200 OK
```

## 함정 (이번 세션에서 실측)

- **regex sweep 1차 후 4개 파일 잔존**: `assets.ts`, `agentManager.ts`, `interactions.ts`, `components/Character.tsx` 의 line 17~ 의 char-* path가 `/hermes-control-room/sprites/...` 으로 prefix 박힌 형태. 1차 regex `'/sprites/...'`만 매치하고 `/hermes-control-room/sprites/...` 는 통과 못함 → 2차 sweep regex로 제거.
  - 검증된 함정: **regex sweep는 한 번으로 끝내지 말 것 — 반드시 `grep -rn` 으로 잔존 확인**.
- **TS6133 unused import 사전 패치**: 변환 도중 `getAgentAvatar`, `getAvatars` 같은 함수가 사용처 사라지면서 unused warning 가능. `noUnusedLocals: false` 설정 (이 프로젝트는 OK) 아니라면 unused import 사전 제거.
- **Asset 경로 변환 도중 trailing quote + backtick 부호 깨짐**: regex 적용 시 `'.png'` → `\`${BASE_URL}...png\`` 로 변환 시 닫는 quote 처리에 주의. `re.sub(r"\.png',", ".png`,", content)` 후 추가 path 검증.
- **Theme pack 6개 spot 함수 동시 갱신**: `getSpriteDir`, `getRoomImage`, `getAngelaCat`, `OFFICE_PROPS_BY_SLUG`, `OFFICE_GENERIC_PROPS`, `OFFICE_CATS_PATHS` — 한 군데 빠뜨리면 page reload 시 부분만 깨짐. `grep -n "BASE_URL" src/theme.ts` 로 6곳 모두 hit 확인.

## 빌드 산출물 비교

빌드 전후 78개 404 → 0개 (또는 5 미만) 확인. Playwright로 시각 캡쳐 후 sprite 깨짐 0개.

## lessons (다음 세션에)

- **vite base prefix 누락은 빌드로는 절대 잡히지 않음** — ts 컴파일, vite build, dist/index.html 확인 모두 OK여도 런타임 fetch에서만 터짐. 즉 `dist/` 만 inspection하면 놓치는 버그. **반드시 라이브에서 1회 fetch 후 검증**.
- **theme.ts 같은 theme pack은 BASE_URL 적용 hot spot** — assets.ts (1개 매니페스트) 처럼 한 군데 모이면 알기 쉽지만, theme.ts 처럼 getter + 여러 const array 형태로 흩어져 있으면 누락 위험 큼.
- **regex sweep는 2-pass**: prefix 없는 거 먼저, prefix 박힌 거 나중에. 한 번에 합치면 매치 누락 + 이중 변환 둘 다 가능.
