---
name: lua-love-game-fork
description: "LÖVE 11.x (Lua 5.1/LuaJIT) 게임 fork + 한국어화 + Steam shim + macOS M4 Retina/DPI/state.txt 디버깅. SNKRX v0.1.5 + BYTEPATH v0.0.1~v0.2.1 검증. M-0~M-21 마이그레이션 + 셰이더 위 UI (M-14) + STALKER-X Camera (M-15) + addLine timer (M-16) + 셰이더+letterbox GUI 키보드만 (M-17) + scanlines 단일 게이트 (M-18) + 룸 :destroy (M-19) + 가설 5회 빗나가면 순차 진단 (L4) + cross-platform 빌드 (M-20) + GH release multipart (M-21). v0.22 토글 5단계 + v0.23 T()/dict/kr_8 부트스트랩 + v0.24 fonts.kr_8 wiring + v0.25 fonts.kr_16 0.75x 스케일 + v0.26 M-23 printT args + M-24 baseline + v0.27 M-25~M-28 (DeviceModule pop, shorten_utf8_last, Options 컬럼) + - M-29~M-33 + M-34~M-39: kr_NN 박스 vs viewport (M-34), printT 단순화 (M-35), baseline = font height (M-36), dict 키 중복 (M-37), UTF-8 byte substring (M-38), kr_16 fallback (M-39). 자세한 함정은 `references/bytepath-ex-m34-m39-cjk-rendering-pitfalls.md`."
version: 0.30.0
author: HyeRin (MiniMax)
license: MIT
metadata:
  hermes:
    tags: [lua, love2d, fork, steam, shim, cjk, korean, gatekeeper, snkrx, bytepath, headless-verify, type-guard, utf8-parsing, window-sizing, has-cjk, macos-sonoma, monolithic, love-graphics-font-wiring, love-10-to-11-migration, steamworks-ffi, state-txt-persistence, display-option-omit, window-sx-backup-key, viewport-letterbox-fix, auto-fit-graph-rooms, line-y-accumulation-cursor-drift, cross-platform-build, github-release-200mb-multipart, lang-toggle-bootstrap, marker-preservation, progressive-1st-2nd, font-kr8-draw-wiring, i18n-dict-consistency, gitignore-font-50mb, delegated-fullstack-timeout, font-resolution-vs-display-size, console-line-baseline-mixed-cjk, row-stride-sync-across-systems, viewport-safe-device-stats, font-size-decision-tree, printt-args-indexing-bug, per-glyph-baseline-correction, console-line-has-cjk-language-bucket]
    related_skills: [oss-fork-localization, godot-game-bootstrap, cpp-game-koreanization]
    version_history:
      "0.22.0": "한/영 토글 사전 점검 5단계 (마커 보존 + 명령어 영문 유지 + 점진 진행)"
      "0.23.0": "T()/dict/kr_8 폰트 부트스트랩 + addLine swap table 영문 잠금 + selection_widths 한글화 후 재계산"
      "0.24.0": "fonts.kr_8 draw 단계 wiring + 풀 풀스택 위임 600s 타임아웃 + en.lua/ko.lua 키 일관성 + gitignore 한글 폰트 50MB 가드"
      "0.25.0": "fonts.kr_8 → kr_16 + 0.75x display scale (M-22) + ConsoleLine character baseline 보정 + addLine advance 통일 + HelpModule highlight stride 동기화 + DeviceModule stat 위치 viewport 안쪽"
      "0.26.0": "M-23 printT args 인덱싱 버그 (한글 회전) + M-24 ConsoleLine per-glyph baseline + 한글 폰트 크기 결정 트리 + stride 동기화 체크리스트"
      "0.27.0": "M-25 per-glyph baseline 단순화 (font_baseline 헬퍼) + M-26 DeviceModule 회전 컨텍스트 pop + M-27 UTF-8 truncate 크래시 (shorten_utf8_last) + M-28 Options 라벨/값 컬럼 분리"
      "0.28.0": "M-29 LuaJIT 5.1 native '&' 비트 연산자 syntax error → bit.band + M-30 textWidth self-cleanup 금지 (정상 UTF-8 데이터 잘림 방지) + M-31 fonts.kr_16 nil 시 textWidth 0 반환 (Anonymous_8 fallback 금지) + M-32 한글 truncate '..' suffix 금지 (한 글자 잘림이 명확) + M-33 Options 컬럼 폭 가이드 (fonts.kr_16 14px → label_col 112~128px)"
---
# LÖVE 2D (Lua) 게임 fork + 한국어화 워크플로우

> 본 skill은 모듈형(SNKRX) / 모노리식(BYTEPATH) 양쪽 게임 구조에서 LÖVE 0.10.2 → 11.5 마이그레이션 + 한국어화를 진행하는 절차의 모음. 자세한 시나리오별 시간순 디버깅은 references/ 디렉토리에 위임.

## 🆕 v0.25 신규 — M-22: 한글 폰트 해상도↑/표시↓ + 다중 함수 baseline 보정 (BYTEPATH v0.2.1 1차/2차 사례)

v0.24에서 `fonts.kr_8` wiring으로 한글 □ 깨짐은 해결했지만, **8px 픽셀 한글은 알아보기 어렵고**, **14px로 키우면 480x270 viewport 셀에 안 들어가서 화면 밖으로 잘림** (BYTEPATH DeviceModule stat 풀 / Options row / HelpModule highlight 모두 viewport 밖 사례 검증: 2026-07-22).

**핵심 트릭 — 고해상도 폰트 로드 + 0.75x 표시 스케일**:
- `fonts.kr_16` (16px 폰트 데이터) 로드 → 글리프가 정밀
- `love.graphics.print(text, x, y, 0, 0.75, 0.75)` 로 그릴 때 화면에는 ~12px로 표시
- `fonts.kr_16:getWidth(text) * 0.75` 로 렌더링 폭 측정
- `fonts.kr_16:getHeight() * 0.75` 로 렌더링 높이 (= `kr_height()` 헬퍼)

이렇게 하면 **셀 안 fit + 알아볼 수 있는 글리프 품질** 둘 다 잡음. SNKRX의 Text/Text2 위젯 시스템이 없는 bytepath-ex 같은 legacy 게임에서 특히 효과적.

### 픽스 A — printT/textWidth/kr_height (globals.lua, v0.25)

```lua
function printT(font, text, ...)
    local prev = love.graphics.getFont()
    if has_cjk(text) and fonts and fonts.kr_16 then
        love.graphics.setFont(fonts.kr_16)
        -- print() 의 sx/sy 가 인자에 있으면 곱해서 보존, 없으면 0.75x 추가
        local args = {...}
        if #args >= 7 then
            args[6] = (args[6] or 1) * 0.75
            args[7] = (args[7] or 1) * 0.75
        else
            table.insert(args, 0.75)
            table.insert(args, 0.75)
        end
        love.graphics.print(text, unpack(args))
        love.graphics.setFont(prev)
        return
    end
    if font then love.graphics.setFont(font) end
    love.graphics.print(text, ...)
    love.graphics.setFont(prev)
end

function textWidth(font, text)
    if has_cjk(text) and fonts and fonts.kr_16 then
        return fonts.kr_16:getWidth(text) * 0.75
    end
    if font then return font:getWidth(text) end
    return 0
end

function kr_height()
    if fonts and fonts.kr_16 then
        return fonts.kr_16:getHeight() * 0.75
    end
    return 12
end
```

### 픽스 B — ConsoleLine character-by-character baseline (BYTEPATH/모노리식 게임 특유)

한/영 혼합 라인에서 한글 글리프가 폰트 박스 안에서 약간 위로 (ascent) 올라가 있어서 단순히 `font:getHeight()`로 baseline 잡으면 글리프 상단 클리핑됨. **`kr_height()`로 baseline anchor 보정**:

```lua
-- objects/ConsoleLine.lua setCharacters()
local kr_rendered = kr_height()
self.kr_rendered = kr_rendered
self.text_y_offset = math.max(normal_font:getHeight(), arch_font:getHeight(), kr_rendered)
for i = 1, #self.characters do
    local width = 0
    if i > 1 then
        for j = 1, i-1 do
            if self.characters[j] and not self.characters[j].marker then
                if self.characters[j].language == 'normal' then width = width + normal_font:getWidth(self.characters[j].c)
                elseif self.characters[j].language == 'arch' then width = width + arch_font:getWidth(self.characters[j].c)
                elseif self.characters[j].language == 'kr' then width = width + fonts.kr_16:getWidth(self.characters[j].c) * 0.75 end
                end
            end
        end
    end
    self.characters[i].width = width
end

-- ConsoleLine:draw()
local kr_font = fonts.kr_16 or fonts.kr_14 or fonts.kr_8 or normal_font
local baseline = self.text_y_offset or normal_font:getHeight()
-- background_colors 사각형: 한글은 kr_height() 기준, 라틴은 char_font:getHeight() 기준
local h = char_font:getHeight()
if self.characters[i].language == 'kr' then h = kr_height() end
love.graphics.rectangle('fill', self.x + self.characters[i].width, self.y + baseline - h,
    char_font:getWidth(self.characters[i].c) * (self.characters[i].language == 'kr' and 0.75 or 1), h)
-- print 좌표: baseline - kr_height() (한글) 또는 baseline - char_font:getHeight() (라틴)
printT(self.font, c, self.x + ..., self.y + baseline - (self.characters[i].language == 'kr' and kr_height() or char_font:getHeight()), 0, 1, 1, 0, 0)
```

### 픽스 C — addLine advance 통일 (한/영 동일 stride)

한글 라인 advance와 영문 라인 advance가 다르면 addLine 호출 순서대로 stack 시 한글↔영문 줄 사이가 어긋남 + HelpModule 같은 외부 모듈이 `selection_index * 12` 하드코딩으로 highlight 박스 위치 어긋남. **무조건 동일한 stride (14px) 사용**:

```lua
-- rooms/Console.lua Console:addLine()
self.line_y = self.line_y + 14  -- 한/영 무관 14px
if self.line_y > gh then camera:lookAt(camera.x, camera.y + 14) end
```

**stride 변경 시 같이 동기화해야 할 곳**:
- `Console:addInputLine` 의 `line_y` advance
- `Console:_drawMainMenu` 의 `text_y = cell_y + math.floor((row_h - label_baseline)/2)` — `label_baseline = max(self.font:getHeight(), kr_height())`
- `rooms/Options.lua` `row_h` (한글 들어가는 14px) + 선택 highlight 박스 height 9→11px
- `objects/modules/HelpModule.lua` highlight 박스 y 좌표 `selection_index * 14` (stride와 동일)

### 픽스 D — DeviceModule stat 블록 위치 (viewport 밖 → 안쪽)

모듈이 `self.y = y + 100` (ConsoleLine y 좌표 + 100)으로 그려질 때 viewport 270 안에 들어오지만, **stat 텍스트가 `self.y + self.h - 24` 위치 (다각형 아래)에 그려지면 viewport 밖으로 잘림**. 다각형 위쪽으로 stat 풀 옮김:

```lua
-- objects/modules/DeviceModule.lua DeviceModule:draw() 끝부분
local line_h = 13
local desc_x = self.x - self.w/2 - 70
local desc_y = self.y - self.h/2 - 14 - (line_h * #self.device_descriptions[device])
for i, line in ipairs(self.device_descriptions[device]) do
    printT(self.font, line, desc_x, desc_y + line_h*(i-1), 0, 1, 1, 0, self.font:getHeight()/2)
end
```

**판별 신호**: 디바이스 카드 다각형은 viewport 안에 보이는데 stat 풀(디바이스 이름 + UNLOCKED + TECH/ATK/DEF/SPD/LCK + 우하단 스탯)만 viewport 밖 / 잘림 → DeviceModule stat 위치 다이어트 패턴 적용.

### 검증 신호표 (v0.25 확장)

| 증상 | 원인 | 해결 |
|------|------|------|
| 한글 T() 출력은 되지만 알아보기 어려움 (8px) | fonts.kr_8 로드만 했고 화면에 8px 픽셀로 표시 | **fonts.kr_16 (16px) + 0.75x 표시 스케일** = 화면 ~12px + 글리프 정밀 |
| 한글 라인이 viewport 밖으로 잘림 | fonts.kr_14 (14px full) 한 줄이 viewport 270 안에 안 들어감 | **fonts.kr_16 + 0.75x** + `addLine` stride 통일 14px + HelpModule highlight stride 동기화 |
| ConsoleLine 한/영 혼합 라인에서 한글 글리프 상단 클리핑 | 단순히 `font:getHeight()`로 baseline 잡으면 ascent 위로 잘림 | **`kr_height()` baseline anchor** + `text_y_offset = max(normal, arch, kr_rendered)` |
| Options row 한글 라벨 겹침 | row 간격 12px에 한글 14px 라벨 들어가서 다음 row 침범 | `row_h = 14` + 선택 highlight 박스 height 9→11px |
| HelpModule highlight 박스 위치 어긋남 (한글 라인 위) | `selection_index * 12` 하드코딩, stride가 14로 바뀌면서 어긋남 | **`selection_index * 14`** 로 stride와 동기화 |
| DeviceModule stat 텍스트가 다각형 아래 viewport 밖으로 잘림 | `self.y + self.h - 24` 위치가 viewport 초과 | **stat 풀을 다각형 위쪽으로 이동** — `self.y - self.h/2 - 14 - line_h * n` |

판별 신호: 한글 T() 가 깨짐 없이 표시되지만 **알아보기 어렵거나 viewport 밖으로 잘리면** → v0.25 패턴 적용.

## 🆕 v0.26 신규 — M-23/M-24: printT args 인덱싱 + per-glyph baseline (가장 자주 빠지는 두 번째 함정)

v0.25의 fonts.kr_16 + 0.75x 스케일 (M-22) 적용 후 **두 가지 새로운 함정**이 등장했다. **둘 다 stderr로 못 잡고 GUI 검증만 가능** — BYTEPATH v0.2.1 후속 세션 (2026-07-22)에서 발견.

### M-23 — printT의 args 인덱싱 버그 (한글이 ~1 라디안으로 회전)

v0.25 printT는 `local args = {...}` 로 호출 인자를 받고, `#args >= 7` 분기에서 `args[6], args[7]` (sx, sy)에 `* 0.75` 를 곱하고, 그 외에는 `table.insert(args, 0.75); table.insert(args, 0.75)` 했다. **이 분기 로직이 잘못됨**:

```lua
-- 호출: printT(self.font, label, label_x, text_y)  →  args = {label_x, text_y}  (2개)
-- #args < 7 분기로 가서 table.insert 두 번
-- args = {label_x, text_y, 0.75, 0.75}
-- love.graphics.print(text, label_x, text_y, 0.75, 0.75)
--                                ^^^^      ^^^^
--                                rotation  sx
--                                0.75 라디안 = 43도 회전 + 0.75x 스케일
-- ⇒ 한글이 화면에서 ~43도 기울어진 채 표시됨 (사용자 스크린샷에서 확인)
```

**바른 픽스**: printT 시그니처를 **단순화해서 (font, text, x, y, rotation) 5 인자로 고정**하고, CJK면 무조건 `love.graphics.print(text, x, y, rotation or 0)` (sx/sy 인자 안 넘김). 폰트 자체가 kr_16 네이티브 16px이고 화면에는 충분히 잘 보이므로 0.75x 표시 스케일 트릭이 더 이상 필요 없음:

```lua
function printT(font, text, x, y, rotation)
    local prev = love.graphics.getFont()
    if has_cjk(text) and fonts and fonts.kr_16 then
        love.graphics.setFont(fonts.kr_16)
        love.graphics.print(text, x, y, rotation or 0)
        love.graphics.setFont(prev)
        return
    end
    if font then love.graphics.setFont(font) end
    love.graphics.print(text, x, y, rotation or 0)
    love.graphics.setFont(prev)
end
```

**판별 신호**: 메인 메뉴 셀에서 **한글 라벨이 ~40도 회전 / 기울어진 채로 표시**되거나, 한/영 혼합 라벨의 일부 글자만 회전. stderr는 비어있음.

### M-24 — ConsoleLine per-glyph baseline (한글 top 잘림)

v0.25의 `baseline = max(Anonymous_8, Arch_16, kr_rendered)` baseline 보정은 **모든 글리프가 같은 baseline에 정렬**되지만, **`baseline_y = kr_base - kr_font:getHeight()`** 식으로 self.y 위로 음수 offset이 가서 한글 글리프가 viewport 위로 잘림. 예를 들어 baseline=16, kr_font height=16 → baseline_y = 16 - 16 = **0**. self.y=0에서 baseline_y=0 → 폰트 박스 top=0, 한글 글리프는 self.y=0~16 영역에 그려지지만 **한글 ascent가 위쪽 ~4px 영역 차지** → 화면상 잘림 X.

**진짜 문제는**: `baseline_y = kr_base - kr_font:getHeight()` 식에서 kr_base = max(..., 12) = **16** (kr_16 height) 이고, kr_font:getHeight() = **16**이라 baseline_y = 0. self.y + 0 = 폰트 박스 top = self.y. 글리프 박스 self.y ~ self.y+16. **첫 줄에 self.y=0이면 박스 0~16 정상**. 그러나 `baseline = max(8, 16, 12) = 16` 일 때 **baseline 위치 = self.y + baseline = self.y + 16** (폰트 박스 *바깥*). 그리고 한글 baseline = self.y + baseline - kr_height = self.y + 16 - 12 = self.y + 4. 그려질 때 self.y + 4 부터 self.y + 16 + 4 = self.y + 20 영역. **line_y stride 18이면 다음 줄 self.y=18 → 한글 박스 22~38 영역. 이전 줄 글리프 4~20과 겹치진 않지만 첫 줄 self.y=0 + 4 = 4부터 그려서 화면상 글리프가 y=4~20 영역 → 위쪽 잘림은 아니지만 첫 줄에 다른 줄이 안 들어가 보임**.

**바른 픽스**: **각 글리프가 자기 폰트의 baseline을 self.y + font_baseline(font) 으로 직접 계산** (모든 글리프 박스 top = self.y):

```lua
-- objects/ConsoleLine.lua:draw()
local function font_baseline(font)
    return math.floor(font:getHeight() * 0.75)
end
local kr_base = font_baseline(kr_font)
local normal_base = font_baseline(normal_font)
local arch_base = 0
for i = 1, #self.characters do
    -- ...
    if self.characters[i].language == 'kr' then
        baseline_y = self.y + kr_base        -- self.y + 12 for kr_16
    elseif self.characters[i].language == 'arch' then
        baseline_y = self.y + arch_base      -- self.y + 0
    else
        baseline_y = self.y + normal_base   -- self.y + 6 for Anonymous_8
    end
    -- background 박스도 self.y 부터 자기 폰트 박스
    love.graphics.rectangle('fill', self.x + ..., self.y, char_font:getWidth(c), char_font:getHeight())
    love.graphics.print(c, self.x + ..., baseline_y, 0, 1, 1, 0, 0)
end
```

**핵심**: 각 글리프가 **자신의 폰트 박스를 self.y에 정렬**하고, baseline은 폰트 박스 안의 자연 위치 (보통 75%). 한글 / 영문 / 아치 폰트의 baseline이 서로 다르지만 **각 글리프 박스 안에서는 정렬**. line_y stride는 폰트 박스 height * 0.75 + padding.

**판별 신호**: 화면 top에 있는 한글 라인(예: 콘솔 부팅 첫 줄 "Welcome to {ArchType}!", AboutModule의 첫 줄)이 **위로 잘리거나 baseline이 안 맞는 느낌**. 또는 한/영 혼합 라인에서 영문 글자 baseline과 한글 글자 baseline이 어긋남.

### 한글 폰트 크기 결정 트리 (사용자 컨벤션 + 진동 사례 기반)

BYTEPATH v0.2.1 한글화에서 **5번의 폰트 크기 진동**이 있었습니다 (사용자가 매번 스크린샷 피드백):

```
1차 fonts.kr_8  (8px 픽셀) → "한글이 □ 로 깨져서 안 보임"
2차 fonts.kr_14 (14px 풀)  → "한글은 나오는데 폰트가 너무 작아서 알아볼수 없음"
3차 fonts.kr_16 + 0.75x   → "메뉴는 정상 / 터미널 UI는 알아보기 힘듦"
4차 kr_16 args 인덱싱 버그로 회전 (M-23)
5차 kr_12로 후퇴       → "메뉴는 정상 / 터미널 UI 엉망"
6차 (v0.26) kr_16 + per-glyph baseline (M-24)
```

**결론**: **`fonts.kr_16` 네이티브 16px가 정답** (16px 픽셀 = Anonymous 16px와 같은 baseline), 단 **line_y stride를 14~18px로 충분히 키우고 + ConsoleLine의 M-24 baseline 보정 필수**. 8px/12px/14px 어느 것도 viewport 480x270 안에서 한글 한 줄을 알아볼 수 있게 만들지 못함.

### stride 동기화 체크리스트 (v0.26 신규)

한글 폰트 16px + line_y stride 18px 채택 시 **5군데 동기화 필수** (v0.25 픽스 C + v0.26 추가):

| 위치 | 값 | 비고 |
|---|---|---|
| `rooms/Console.lua` `Console:addLine` | `self.line_y + 18` | **기본 stride** |
| `rooms/Console.lua` `Console:addInputLine` | `self.line_y + 18` | 프롬프트 라인 |
| `rooms/Console.lua` `_drawMainMenu` 셀 h | `h = 22` | 한글 한 줄 들어가는 cell |
| `rooms/Console.lua` `_drawMainMenu` `text_y` | `cell_y + math.floor((row_h - label_baseline)/2)` | `label_baseline = max(font:getHeight(), kr_height())` |
| `rooms/Options.lua` `row_h` | `18` + 선택 highlight `h = 14` | 라벨 + 값 행 |
| `objects/modules/HelpModule.lua` highlight 박스 y | `selection_index * 18 + 3*18 + 2 + y_offsets[i]` | 한 줄 stride 동기화 |

**stride 변경 시 한 군데만 바꾸면 HelpModule highlight가 한 줄 위/아래로 어긋남** — BYTEPATH 사례에서 12 → 14 → 18로 세 번 바꿀 때마다 HelpModule을 같이 수정했음. **여섯 군데 한꺼번에 변경**하거나, **stride를 상수로 정의** (`local LINE_H = 18`)해서 모든 곳에서 참조.

### 검증 신호표 (v0.26 확장)

| 증상 | 원인 | 해결 |
|------|------|------|
| **한글 라벨이 ~43도 회전 / 기울어져 표시 (v0.26)** | **M-23 printT의 args[6]/args[7] 인덱싱 버그 — print(text, x, y, 0.75, 0.75) 로 호출되어 r=0.75, sx=0.75 됨** | **printT 시그니처를 (font, text, x, y, rotation) 5 인자로 단순화 + sx/sy 인자 자체 제거**. fonts.kr_16 네이티브 표시 |
| **한/영 혼합 라벨의 일부만 회전 (v0.26)** | printT 호출 시 args 개수에 따라 분기 — 일부는 args[6]=0.75, 일부는 table.insert된 위치에 따라 다름 | 위와 동일 |
| **한글 라인이 viewport 위로 잘림 (v0.26)** | **M-24 `baseline_y = kr_base - kr_font:getHeight()` 식으로 self.y 위로 음수 offset** | **각 글리프가 `self.y + font_baseline(font)` 직접 사용**. 폰트 박스 top = self.y, baseline은 폰트 박스 안 자연 위치 |
| **한글 8px 픽셀이 알아보기 어려움 (v0.25)** | fonts.kr_8 (8px) 너무 작음 | **fonts.kr_16 (16px 네이티브)** + per-glyph baseline (M-24) |
| **한글 12px 폰트 후퇴 후 화면 엉망 (v0.26)** | kr_12 + kr_height() = 12 → stride 14 mismatch → 글리프 겹침 | **kr_16 + stride 18 (v0.26 권장)** |
| **HelpModule highlight 박스 위치 어긋남 (v0.26)** | **stride 14 → 18 변경 시 highlight 박스 y 좌표도 같이 안 바꿈** | **stride 동기화 체크리스트 6군데 한꺼번에 수정** 또는 `local LINE_H = 18` 상수로 참조 |
| **위임이 폰트 크기 결정에 5번 진동 (v0.26 패턴)** | 위임이 사용자 GUI 피드백 없이 폰트 크기 / stride / baseline 추측 | **위임이 폰트 크기 결정 금지 — 사용자 스크린샷 피드백 받은 후 결정**. v0.26 진입점: `fonts.kr_16` + stride 18 + per-glyph baseline |

### user-facing 컨벤션 (v0.26 사용자 피드백에서 도출)

> "터미널 형태의 한글텍스트는 전체적으로 알아보기 어려운데, (폰트 해상도는 올리고, 화면 출력 크기는 좀 줄여야될 것 같음)"

이 한 줄 피드백이 **fonts.kr_16 + 0.75x 트릭의 정당성**이지만, **0.75x 스케일이 printT args 인덱싱 버그로 회전**이 됨. v0.26 결론: **0.75x 트릭 제거 + kr_16 네이티브 + per-glyph baseline 보정**. **"고해상도 + 작은 표시"가 아니라 "고해상도 = 좋은 글리프" + line_y stride 키움**으로 방향 전환.

다음 v0.27 후보: 2차 (SkillTree stat 700+ / 이름 풀) 한글화 + 클래스/업적 룸 헤더 + selection_widths 박스 미세 조정. **위임 600s 타임아웃 회피를 위해 1차/2차 점진 진행 정책 그대로 유지** (v0.24 신규).

## 🆕 v0.27 신규 — M-25~M-28: per-glyph baseline 단순화 + DeviceModule 회전 + UTF-8 truncate + Options 컬럼 분리 (BYTEPATH v0.2.1 후속 세션, 2026-07-22)

v0.26의 per-glyph baseline (M-24)은 폰트 박스 top = self.y + 각 글리프 baseline_y 보정이 잘 동작했지만, **여전히 4가지 함정**이 남아있었음. BYTEPATH v0.2.1 4차 한글화 보정 세션에서 발견. **모두 stderr로 못 잡고 GUI 검증만 가능**.

### M-25 — Per-glyph baseline 단순화 (font_baseline 헬퍼 + shared baseline)

v0.26 M-24는 한/영 글리프별로 다른 baseline_y (`kr_base`, `normal_base`, `arch_base`)를 계산했지만, **같은 행에서 한/영 혼합 시 baseline이 6px씩 어긋남** (한글 self.y+12, 영문 self.y+6). **모든 글리프가 같은 baseline을 공유**하도록 단순화 — **한 줄에 있는 모든 글리프의 baseline이 동일 좌표**:

```lua
-- objects/ConsoleLine.lua draw() — v0.27 단순화 패턴
local function font_baseline(font)
    return math.floor(font:getHeight() * 0.75)
end
-- 한/영/arch 모든 글리프가 같은 baseline_y 사용 (글리프 박스 top은 각자 self.y)
local shared_baseline_y = self.y + math.floor((fonts.kr_16 or fonts.kr_14 or fonts.kr_8):getHeight() * 0.75)
for i = 1, #self.characters do
    if not self.characters[i].marker then
        local char_font = self.characters[i].language == 'kr' and (fonts.kr_16 or fonts.kr_14 or fonts.kr_8)
            or self.characters[i].language == 'arch' and arch_font
            or normal_font
        if self.background_colors[i] then
            love.graphics.rectangle('fill', self.x + self.characters[i].width, self.y,
                char_font:getWidth(self.characters[i].c), char_font:getHeight())
        end
        love.graphics.setColor(...)
        love.graphics.print(self.characters[i].c, self.x + self.characters[i].width, shared_baseline_y, 0, 1, 1, 0, 0)
    end
end
```

**핵심**: 각 글리프의 **폰트 박스 top은 항상 `self.y`**, baseline은 **`shared_baseline_y`** (한글 폰트 박스의 75% 위치). 한/영/arch 글리프의 baseline 좌표가 동일하므로 한 줄 정렬 정상. **글리프 박스 크기는 각 폰트마다 다르지만 박스 top만 같으면 baseline 정렬됨**.

같은 패턴을 `objects/ConsoleInputLine.lua`의 draw에도 적용 — `shared_baseline_y` 한 줄로 모든 글리프 정렬.

**판별 신호**: 한/영 혼합 라인에서 **영문 글자와 한글 글자가 baseline이 어긋나 보임** (예: 영문 'Q' baseline이 한글 baseline보다 위/아래). 또는 **한/영 폭 측정 + draw 호출이 분산되어 있어 한 줄에 baseline 계산이 5군데 흩어져 있을 때**.

### M-26 — DeviceModule 회전 컨텍스트 빠져나오기 (한글이 다각형 회전을 따라가는 버그)

DeviceModule:draw()의 시작에서 `pushRotateScale(self.x, self.y, 0, 1, 1)` 외부 회전 컨텍스트 안에서 다각형 그리기 → 그 후 **device_name_label, UNLOCKED/LOCKED, TECH/ATK/DEF/SPD/LCK 라벨** 모두 같은 컨텍스트 안에서 그려져서 **다각형의 회전(영향 없음이지만 translate/scale 영향)을 따라감**. 그리고 한글 라벨의 회전/위치 어긋남 + `pushRotate(self.x - self.w/2 + 10, self.y - 2, -math.pi/2)` (-90도 회전) 안에 한글 라벨이 들어가면 라벨도 -90도 회전되어 표시됨.

```lua
-- objects/modules/DeviceModule.lua draw() — v0.27 패턴
function DeviceModule:draw()
    love.graphics.setColor(default_color)
    pushRotateScale(self.x, self.y, 0, self.sx, self.sy)
    local w, h = self.w, self.h
    local x, y = self.x, self.y
    love.graphics.setFont(self.font)
    
    love.graphics.line(...)  -- 카드 박스
    BSGRectangle(...)        -- 좌/우 카드
    
    -- 디바이스 다각형 (회전 컨텍스트 안에서 그림)
    local device = self.devices[self.device_index]
    pushRotate(self.x - self.w/2 + 10, self.y - 2 + ..., -math.pi/2)
    for _, vertice_group in ipairs(self.device_vertices[device].vertice_groups) do
        love.graphics.polygon('line', points)
    end
    love.graphics.pop()  -- 다각형 회전 해제
    
    -- ★★★ 외부 pushRotateScale 컨텍스트도 pop (라벨은 viewport 좌표에 그림) ★★★
    love.graphics.pop()
    love.graphics.setFont(self.font)
    
    -- 라벨은 모두 viewport 좌표 (회전 없음)
    printT(self.font, device_name_label, self.x - self.w/2 + 10, self.y - 27, 0)
    if unlocked then printT(self.font, '해금됨', ...)
    else printT(self.font, '잠김 - X SP', ...) end
    
    -- TECH/ATK/DEF/SPD/LCK 차트 (오른쪽 카드)
    printT(self.font, '기술', px, py - 38, 0)
    -- ...
    
    -- Stat 풀 (다각형과 분리, viewport 하단 고정)
    local line_h = 18
    local desc_y = gh - line_h * #self.device_descriptions[device] - 4
    for i, line in ipairs(self.device_descriptions[device]) do
        printT(self.font, line, 8, desc_y + line_h*(i-1), 0)
    end
end
```

**핵심**: `pushRotateScale` 외부 컨텍스트는 다각형 그리기 직후 **pop()** 해제. 라벨 (device_name, UNLOCKED, TECH~LCK)은 viewport 좌표에 평범하게 그림. **Stat 풀(디바이스 description)은 다각형 회전 영역 밖**으로 빼서 viewport 하단 (gh - line_h * n)에 고정 — `self.y` 위치에 영향 받지 않음.

**판별 신호**: 디바이스 카드 안 한글 라벨이 **다각형 영역 안에 들어가 있거나 회전되어 보임**. 또는 한글 stat 텍스트(`디바이스: 파이터`, `모든 스탯 평균` 등)가 viewport 밖으로 잘림. DeviceModule뿐 아니라 **`pushRotate`/`pushRotateScale` 사용하면서 한글/비-영문 라벨을 그리는 모든 모듈**에 적용 가능 (BYTEPATH 사례: DeviceModule, SkillTree 그래프 노드).

### M-27 — UTF-8 truncate 크래시 (`s:sub(1, -2)` → `shorten_utf8_last`)

v0.27 진입 직전 **UI 검증 중 크래시**가 한 번 터졌음:

```
Error: rooms/Options.lua:237: UTF-8 decoding error: Invalid UTF-8
Traceback: ... in function 'textWidth' / rooms/Options.lua:237 / 'draw' / main.lua:181
```

**원인**: Options 라벨 truncate 로직이 다음 패턴 사용:

```lua
-- ❌ BUG (v0.27 이전): byte 단위 substring이 한글 1글자(3바이트) 중간에서 자름
while textWidth(font, label_text .. '..') > label_col_w do
    label_text = label_text:sub(1, -2)  -- ← 한글 중간 잘림!
end
```

예: `디스플레이 모드:` (26 bytes) truncate 시 `:sub(1, -2)` = 24 bytes → 마지막 2바이트 (한글의 일부)만 제거되어 잘못된 UTF-8 시퀀스 → `font:getWidth()`가 `'UTF-8 decoding error: Invalid UTF-8'` 크래시.

**Lua 5.1에서 `utf8` 표준 모듈 없음** (BYTEPATH는 자체 `libraries/utf8.lua` 사용하지만 `utf8.sub(s, 1, -2)`도 byte 단위라 같은 버그).

**수정**: continuation bytes (10xxxxxx)를 거꾸로 따라가서 lead byte를 찾고, 그 코드 포인트 전체를 한 번에 제거하는 헬퍼:

```lua
-- globals.lua — UTF-8 안전한 truncate 헬퍼
function shorten_utf8_last(s)
    if not s or #s == 0 then return s or '' end
    local last = #s
    while last > 1 and ((s:byte(last) or 0) & 0xC0) == 0x80 do
        last = last - 1
    end
    if last <= 1 then return '' end
    return s:sub(1, last - 1)
end

-- textWidth()도 방어적으로 trailing continuation bytes 정리
function textWidth(font, text)
    if text == nil or text == '' then return 0 end
    while #text > 0 do
        local b = text:byte(#text)
        if b and (b & 0xC0) == 0x80 then
            text = text:sub(1, -2)
        else
            break
        end
    end
    if has_cjk(text) and fonts and fonts.kr_16 then
        return fonts.kr_16:getWidth(text)
    end
    if font then return font:getWidth(text) end
    return 0
end
```

**사용 패턴**:

```lua
-- BEFORE (v0.27 이전):
while textWidth(font, label .. '..') > label_col_w and #label > 1 do
    label = label:sub(1, -2)  -- ❌ byte 단위 잘림
end

-- AFTER (v0.27):
while textWidth(font, label .. '..') > label_col_w and #label > 0 do
    local next_label = shorten_utf8_last(label)
    if #next_label == 0 or next_label == label then break end
    label = next_label
end
```

**판별 신호**: 부팅은 되는데 메뉴/옵션/콘솔 truncate 로직이 실행되는 경로 (라벨이 셀을 넘는 경로)에서 `'UTF-8 decoding error: Invalid UTF-8'` 크래시. **특히 모듈형 게임 SNKRX의 main menu truncate, BYTEPATH의 Console GUI 메뉴 desc truncate, Options row label truncate** 모두 영향. **한글화 truncate 코드 작성 시 `s:sub(1, -2)` 패턴은 절대 금지** — `shorten_utf8_last()` 사용.

**한글 환경에서 자주 만나는 같은 함정**: `s:gsub('(.)', ...)` callback 안에서 한글 처리, `string.find(s, '^...')` 에서 ASCII anchor 사용, `s:sub(1, j)` where j = 한글 글자 단위 (UTF-8 byte가 아닌 grapheme 단위 처리 필요). **한글 truncate/검색은 항상 continuation byte 추적**.

### M-28 — Options 라벨/값 컬럼 분리 (한글 overlap 방지)

Options 룸에서 라벨 (예: `디스플레이 모드:` 한글 6글자 ≈ 96px) + `:` (4px) = **100px**가 좌측 8px에서 시작 → 값 영역 시작 x=96과 **4px 겹침**. 값 (`창모드`, `끄기`, `한글`)도 한글이라 fonts.kr_16 16px 박스 안에서 그려야 하는데 printT의 setFont 복원으로 Anonymous_8 박스(8px)에 들어가려다 글리프가 박스 위로 삐져나와 위쪽 잘림.

**수정 — 라벨/값 컬럼 분리**:

```lua
-- rooms/Options.lua draw() — v0.27 패턴
local row_h = 18
local label_x = 8
local value_x = 96
local label_col_w = value_x - label_x - 8  -- 80px, 라벨이 이 너비 넘으면 '..' truncate

for i, row in ipairs(self.rows) do
    if row.kind == 'header' or row.kind == 'action' then
        printT(font, row.text or row.label, label_x, y)
    else
        -- Setting row: label (left col, ≤80px) + value (right col, ≥96px)
        local label_text = row.label .. ':'
        -- UTF-8 안전한 truncate (M-27)
        while #label_text > 0 and textWidth(font, label_text .. '..') > label_col_w do
            local next_text = shorten_utf8_last(label_text)
            if #next_text == 0 or next_text == label_text then break end
            label_text = next_text
        end
        if #label_text > 0 and textWidth(font, label_text .. '..') <= label_col_w then
            label_text = label_text .. '..'
        end
        printT(font, label_text, label_x, y)
        
        -- 값: 한글일 때 fonts.kr_16 직접 setFont + baseline_y_offset으로 그리기
        -- (printT의 setFont(prev) 복원으로 Anonymous_8 박스에 16px 글리프 잘리는 것 회피)
        if has_cjk(value) and fonts.kr_16 then
            love.graphics.setFont(fonts.kr_16)
            love.graphics.print(value, value_x, y + math.floor(fonts.kr_16:getHeight() * 0.75))
        else
            love.graphics.print(value, value_x, y)
        end
    end
end
love.graphics.setFont(font)  -- 라벨 그리기 후 영문 폰트 복원 (hint가 영문)
```

**핵심**:
1. **라벨 컬럼 = 0~88px (label_col_w=80)**, **값 컬럼 = 96~gw-16**. 라벨이 80px 초과 시 `..` truncate (M-27의 `shorten_utf8_last` 사용).
2. **값 영역에서만 한글일 때 fonts.kr_16 직접 setFont + baseline 보정** — printT가 prev 폰트로 자동 복원하면 Anonymous_8 박스에 16px 한글 글리프가 들어가려다 잘림. **수동 setFont + 명시적 복원**으로 안전.
3. **hint는 마지막에 영문 폰트로 복원 후 그리기** — hint가 영문이라 한글 baseline 보정 안 받아도 OK.

**판별 신호**: 라벨이 셀 너비 넘어서 값과 겹침. 또는 한글 값(`끄기`, `한글` 등)이 baseline 안 맞아 위/아래 잘림. 또는 같은 룸 패턴(`rooms/Settings.lua`, `rooms/Preferences.lua` 등)이 있는 게임에 그대로 적용 가능.

### 검증 신호표 (v0.27 확장)

| 증상 | 원인 | 해결 |
|------|------|------|
| **DeviceModule 다각형 안 한글 라벨이 회전되어 표시 (v0.27 M-26)** | `pushRotateScale` 외부 컨텍스트 안에서 한글 라벨 그림 | **다각형 그린 후 `love.graphics.pop()` 두 번** (내부 pushRotate + 외부 pushRotateScale) — 라벨은 viewport 좌표에 평범하게 그림. stat 풀은 viewport 하단 고정 (`gh - line_h * n`) |
| **DeviceModule stat 텍스트가 viewport 밖 (v0.27 M-26)** | `self.y + self.h - 24` 위치가 다각형 아래 viewport 초과 | **stat 풀을 다각형 회전 영역 밖 (viewport 하단 `gh - line_h * n`)으로 이동**. self.y 무관 |
| **한/영 혼합 라인 baseline 어긋남 (v0.27 M-25)** | 폰트별 다른 baseline_y (`kr_base`, `normal_base`) | **`shared_baseline_y = self.y + font_baseline(font)` (한 줄에 모든 글리프 동일 baseline)** |
| **`UTF-8 decoding error` 크래시 (v0.27 M-27)** | `s:sub(1, -2)` 가 한글 3바이트 중간에서 잘림 → 잘못된 UTF-8 시퀀스 | **`shorten_utf8_last(s)` 헬퍼 사용** — continuation bytes 거꾸로 따라가서 lead byte 찾고 코드 포인트 전체 제거 |
| **Options 라벨이 값과 겹침 (v0.27 M-28)** | 라벨이 한글 6글자 ≈ 96px → 값 시작 x=96과 겹침 | **라벨 컬럼 0~88px + 값 컬럼 96~gw-16 분리 + UTF-8 안전 truncate** |
| **한글 값이 baseline 안 맞아 잘림 (v0.27 M-28)** | `printT`가 prev 폰트 복원 → Anonymous_8 박스(8px)에 fonts.kr_16(16px) 글리프 들어가려다 잘림 | **값 영역만 fonts.kr_16 직접 setFont + `y + baseline_y_offset` + 마지막에 명시적 `setFont(font)` 복원** |
| **ConsoleLine 한/영 혼합 라인 baseline 6px 어긋남 (v0.27 M-25)** | v0.26 M-24의 per-glyph baseline이 폰트별로 다름 | **`shared_baseline_y` 통합** (M-25) |

### 패턴 종합 (v0.27 사용자 컨벤션 도출)

BYTEPATH v0.2.1 1차~4차 한글화에서 **사용자가 5번 GUI 피드백**:

| 피드백 | 원인 | v0.27 해결 |
|---|---|---|
| "한글이 □ 로 깨짐" | fonts.kr_8 draw wiring 누락 (v0.24) | printT/textWidth 자동 감지 |
| "한글은 나오는데 폰트 너무 작아서 알아보기 힘듦" | fonts.kr_8 8px 픽셀 (v0.25) | fonts.kr_16 (16px 네이티브) |
| "터미널 UI는 알아보기 힘듦" | ConsoleLine baseline 어긋남 (v0.24 M-24) | per-glyph baseline + font_baseline 헬퍼 (M-25) |
| "한글 회전" | printT args 인덱싱 버그 (v0.26 M-23) | printT 5 인자 단순화 |
| "한글 회전/잘림/엉망" | 디바이스 모듈 회전 컨텍스트 + 한글 라벨 혼합 (v0.27 M-26) | 다각형 그린 후 pop 두 번, 라벨은 viewport 좌표 |
| **`'UTF-8 decoding error'` 크래시** | `s:sub(1, -2)` 한글 truncate 버그 (v0.27 M-27) | **`shorten_utf8_last` 헬퍼** |
| **Options 라벨/값 겹침** | 컬럼 분리 안 됨, 한글 baseline printT prev 복원 (v0.27 M-28) | **컬럼 분리 + 값 영역만 직접 setFont** |

**결론 — 한글 truncate/substring 작업 시 절대 `s:sub(1, -2)` 패턴 사용 금지**. Lua 5.1 + 한글 조합에서는 **`shorten_utf8_last(s)` 또는 `utf8.charpos` + `utf8.sub` 사용**. 이 규칙은 SKILL.md에 박혀 있어야 다음 세션에서 같은 크래시 반복 안 함.

## 🆕 v0.28 신규 — M-29~M-33: LuaJIT 비트 연산자 + textWidth 자가 손상 + fonts.kr_16 fallback (BYTEPATH v0.2.1 후속 세션, 2026-07-22)

v0.27 진입 후 **3종 새로운 함정**이 발견됨. **모두 stderr로 즉시 검출 가능 (M-29/M-30)** 또는 **GUI 검증에서만 검출 가능 (M-31/M-32)**.

### M-29 — LuaJIT 5.1 native `&` 비트 연산자 syntax error (가장 먼저 부팅 차단)

v0.27의 `shorten_utf8_last` 헬퍼가 `bit.band` 호출 대신 native `&` 연산자를 사용했더니 **Love 11.5 부팅 단계에서 syntax error로 크래시**:

```
Error: Syntax error: globals.lua:86: ')' expected near '&'
Traceback:
        [love "boot.lua"]:352: in function <[love "boot.lua"]:348>
        [C]: at 0x0104eb6e9c
        [C]: in function 'require'
        main.lua:27: in main chunk
```

**원인**: Love 11.5는 **LuaJIT 2.1 (Lua 5.1 호환)** 사용. Lua 5.1 문법은 **native `&` `|` `~` 비트 연산자 없음**. Lua 5.2+ 표준 라이브러리 `bit32`, LuaJIT 내장 `bit` 라이브러리 사용 필요.

**수정**: 모든 비트 연산을 `bit.band(b, mask)` / `bit.bor(b, mask)` / `bit.lshift(b, n)` 로 교체:

```lua
-- ❌ LuaJIT 5.1 syntax error (Love 11.5 환경)
if b and (b & 0xC0) == 0x80 then  -- syntax error: ')' expected near '&'

-- ✅ LuaJIT 내장 bit 라이브러리
if b and bit.band(b, 0xC0) == 0x80 then  -- OK
```

**판별 신호**: 부팅 즉시 `boot.lua:352: in function <boot.lua>` + `globals.lua:NN: ')' expected near '&'`. **Love 11.5 + 한글 truncate 작업 시 무조건 만나게 되는 함정**. 다른 Lua 5.3+ 환경 (Lua 5.3의 native 비트 연산자 지원, 또는 5.4의 `bit32` 라이브러리)에서는 발생 안 함.

**판별 요령**: bytepath-ex / SNKRX / 일반 LÖVE 11.5 게임은 모두 LuaJIT 2.1 기반. **UTF-8 byte 검사 시 native `&` 금지**.

**다른 곳에서 같은 함정 만날 위험**:
- `textWidth` / `shorten_utf8_last` 외에 UTF-8 lead byte 검사 (`b & 0xE0`, `b & 0xC0` 등)
- 비트 마스크로 flag 검사 (`flags & 0x01`)
- `<<`, `>>` shift 연산자 (`(b << 4)` — Lua 5.1 syntax error)

전부 `bit.band` / `bit.lshift` / `bit.rshift` / `bit.bor` / `bit.bxor` 로 교체.

### M-30 — textWidth의 잘못된 trailing bytes cleanup (정상 UTF-8까지 잘라냄)

v0.27 직후 진입한 **textWidth의 trailing continuation bytes 정리 로직이 정상 한글 텍스트까지 잘라내는** 함정:

```lua
-- ❌ v0.27 텍스트: 정상 UTF-8 텍스트의 마지막 바이트는 continuation byte (10xxxxxx)
-- '시작' (한글 2글자) = EC 8B A0 EC 9E 91
-- 마지막 바이트 0x91 → 10xxxxxx → cleanup 로직이 잘라냄 → 1바이트만 남음 (잘못된 UTF-8)
while #text > 0 do
    local b = text:byte(#text)
    if b and bit.band(b, 0xC0) == 0x80 then
        text = text:sub(1, -2)  -- ← 정상 한글도 잘라냄!
    else
        break
    end
end
return fonts.kr_16:getWidth(text)  -- ← 잘못된 UTF-8 → "Not enough space" 에러
```

**에러 메시지**:

```
Error: rooms/Console.lua:517: UTF-8 decoding error: Not enough space
Traceback:
        [love "callbacks.lua"]:228: in function 'handler'
        [C]: in function 'textWidth'
        rooms/Console.lua:517: in function '_drawMainMenu'
```

**판별 요령**: 정상 한글 텍스트 `'시작'`을 `fonts.kr_16:getWidth()` 호출 시 "Not enough space" 에러. **`Not enough space`는 love2d font cache가 텍스트 디코딩 중 실패 시 던지는 표준 에러**. bytepath-ex console GUI 메뉴 진입 시 즉시 크래시.

**수정**: textWidth는 단순히 `font:getWidth`만 호출. 자체 cleanup 로직 없음. truncate는 `shorten_utf8_last`가 UTF-8 안전하게 처리 (이미 코드 포인트 단위로 자름). **caller 책임**:

```lua
-- ✅ v0.28
function textWidth(font, text)
    if text == nil or text == '' then return 0 end
    -- NO trailing bytes cleanup — 정상 한글 텍스트의 마지막 바이트도
    -- continuation byte (10xxxxxx)이고 cleanup 로직이 잘라내면 'Not
    -- enough space' 에러. truncate 책임은 shorten_utf8_last가 짐.
    if has_cjk(text) and fonts and fonts.kr_16 then
        return fonts.kr_16:getWidth(text)
    end
    if font then return font:getWidth(text) end
    return 0
end
```

**결론 — self-cleanup 로직은 거의 항상 잘못**. caller가 truncate 시 `shorten_utf8_last`로 이미 UTF-8 안전한 처리를 하므로, callee에서 다시 cleanup하면 정상 텍스트가 망가짐.

### M-31 — fonts.kr_16 fallback chain 안전성 (fonts.kr_8 fallback이 한글에서 'Not enough space' 유발)

`fonts.kr_16` 로드는 main.lua의 `loadFonts`에서 5개 사이즈 (14/16/12/10/8) 모두 등록. **하지만 만약 `.ttc`/`.ttf` 파일이 누락되면 `fonts.kr_*` 모두 nil**. textWidth 안의 `if fonts.kr_16 then ... else ... end` fallback이 `else` 분기로 가서 **Anonymous_8 같은 영문 폰트에서 한글 텍스트의 getWidth를 호출** → "Not enough space" 에러.

**수정 — main.lua의 kr_*_N 로드 검증 + 안전한 fallback 체인**:

```lua
-- main.lua: loadFonts 끝부분
local kr_candidates = {'NanumGothic', 'AppleSDGothicNeo', 'AppleGothic'}
for _, name in ipairs(kr_candidates) do
    for _, ext in ipairs({'.ttc', '.ttf'}) do
        local p = path .. '/' .. name .. ext
        local ok, _ = pcall(love.filesystem.getInfo, p)
        if ok then
            for _, size in ipairs({16, 14, 12, 10, 8}) do
                local f_ok, f = pcall(love.graphics.newFont, p, size)
                if f_ok and f then
                    f:setFilter('nearest', 'nearest')
                    fonts['kr_' .. size] = f
                end
            end
            if fonts['kr_16'] then goto kr_loaded end
        end
    end
end
::kr_loaded::
```

**판별 신호**: kr_*_N 폰트 로드 안 된 상태에서 `fonts.kr_16` 참조 시 nil. textWidth의 `if has_cjk and fonts and fonts.kr_16 then ... else ...` 분기에서 else로 가서 Anonymous_8 (또는 임의의 caller font)로 `font:getWidth('한글')` 호출 → "Not enough space".

**안전 fallback 패턴**:

```lua
-- globals.lua
function textWidth(font, text)
    if text == nil or text == '' then return 0 end
    if has_cjk(text) and fonts and fonts.kr_16 then
        return fonts.kr_16:getWidth(text)
    end
    if font then return font:getWidth(text) end
    return 0  -- ⚠️ fonts.kr_16 없는 환경 + 한글 텍스트 → 0 반환 (라벨 폭 0, 잘림)
end
```

**중요**: fonts.kr_16 없을 때 **Anonymous_8:getWidth('한글') 호출하지 말고 0 반환**. 그러면 truncate 로직이 폭 0 기준으로 동작해서 **모든 라벨이 truncate되지만 최소한 크래시는 안 남**. 사용자 GUI에서 한글 라벨이 잘려 보이지만 게임은 정상 작동.

**검증 명령**:

```bash
# love . 실행 후 stderr에서 'Not enough space' 또는 'UTF-8 decoding error' 없어야 함
(love . > /tmp/love_out.log 2>&1 &); sleep 6; kill $!; wait $!; cat /tmp/love_out.log
```

### M-32 — truncate 시 `..` suffix vs 한글 한 글자 잘림 가독성 비교

v0.27에서 `..` suffix를 한글 truncate 결과에 붙이려 했는데 (`디스플레이..` 같은), **사용자 스크린샷에서 `..` 가독성이 더 나쁘다고 판단**. 짧게 잘린 한글 한 글자 (`디스플레이 모드` → `디스플레이 모드`)가 `..` 붙은 것 (`디스플레이..`) 보다 명확.

**수정 패턴 — M-27 + M-32 결합**:

```lua
-- ❌ v0.27: '..' 붙임 (가독성 떨어짐)
while textWidth(font, label_text .. '..') > label_col_w do
    label_text = shorten_utf8_last(label_text)
end
if textWidth(font, label_text .. '..') <= label_col_w then
    label_text = label_text .. '..'
end

-- ✅ v0.28: '..' 안 붙임. 그냥 짧게 잘린 라벨 (M-32)
while #label_text > 0 and textWidth(font, label_text) > label_col_w do
    local next_text = shorten_utf8_last(label_text)
    if #next_text == 0 or next_text == label_text then break end
    label_text = next_text
end
```

**결론**: **Options / Console GUI 메뉴 / 모듈 라벨은 truncate 시 '..' suffix 안 붙임**. 마지막 한 글자 잘림이 더 명확.

### M-33 — Options 라벨/값 컬럼 폭 (한글 14~16px 컬럼 최소 96~112px)

한글 6글자 라벨 (`디스플레이 모드:`) 의 fonts.kr_16 14px 폭 측정:
- 한글 1글자 ≈ 14px
- 6글자 = 84px
- `:` 4px
- 총 ~88px

**라벨 컬럼 88px → 라벨이 항상 truncate됨** (`디스플레이..`). **라벨 컬럼 112px (value_x=128) 로 키우면** `디스플레이 모드:` 그대로 들어감. **너무 좁게 잡으면 항상 truncate, 너무 넓게 잡으면 값 영역 부족 — 96~128px가 sweet spot**.

```lua
-- rooms/Options.lua
local label_x = 8
local value_x = 128         -- 96 → 128 (한글 값 '데스크톱 (테두리없음)' 11글자 ≈ 154px 영역 확보)
local label_col_w = value_x - label_x - 8  -- 112px

-- 라벨 100px일 때: 100 < 112 → truncate 안 됨 (예: '디스플레이 모드:')
-- 라벨 120px일 때: 120 > 112 → shorten_utf8_last로 한 글자씩 제거 (예: '디스플레이 모드' → '디스플레이 모')
```

**판별 신호**: `디스플레이..` `창 크기:..` `언어:..` 처럼 `..` suffix가 모든 라벨에 붙으면 → 컬럼 폭 16~32px 더 키움 (value_x 96→112 또는 96→128). **영문/한글 폭 비율 약 2:1**. Anonymous_8 8px ≈ 6px/글자, fonts.kr_16 14px ≈ 14px/글자. 같은 셀 안에 들어가는 한글 글자 수는 영문 절반.

**공식 가이드 (한글화 컬럼 폭 결정)**:

| 한글 폰트 크기 | 라벨 컬럼 권장 폭 | 한글 한 줄 max 글자 |
|---|---|---|
| fonts.kr_8 (8px) | 48~56px | 3~4글자 |
| fonts.kr_12 (12px) | 72~80px | 5~6글자 |
| fonts.kr_14 (14px) | 96~112px | 6~7글자 |
| fonts.kr_16 (16px 네이티브) | 112~128px | 7~8글자 |

**viewport 480x270 기준**. 16:9 wider viewport (1280x720 등)에서는 비율로 키우면 됨.

### 검증 신호표 (v0.28 확장)

| 증상 | 원인 | 해결 |
|------|------|------|
| **`Syntax error: ')' expected near '&'` 부팅 즉시 크래시 (v0.28 M-29)** | Love 11.5 LuaJIT 5.1 환경 + native `&` 비트 연산자 | **모든 비트 연산을 `bit.band` / `bit.lshift` / `bit.rshift` / `bit.bor` / `bit.bxor` 로 교체** (Lua 5.2+ 비트 연산자 사용 금지) |
| **`UTF-8 decoding error: Not enough space` 콘솔 메뉴 진입 시 크래시 (v0.28 M-30)** | textWidth의 trailing continuation bytes cleanup 로직이 정상 한글 텍스트도 잘라냄 | **textWidth 자체 cleanup 제거 — caller 책임 (shorten_utf8_last로 truncate 시 UTF-8 안전 처리)** |
| **`Not enough space` fonts.kr_16 로드 실패 환경 (v0.28 M-31)** | fonts.kr_16 nil + Anonymous_8:getWidth('한글') 호출 | **fonts.kr_16 없을 때 caller font 호출 안하고 0 반환**. main.lua의 kr_*_N 로드 검증 + fallback 체인 |
| **`디스플레이..` `창 크기:..` 등 모든 라벨이 .. 으로 잘림 (v0.28 M-32)** | 라벨 컬럼 88px 너무 좁음 + `..` suffix 가독성 떨어짐 | **컬럼 112~128px로 키움 + '..' suffix 안 붙임 (M-32)** |
| **한글 라벨이 셀 밖으로 삐져남 (v0.28 M-33)** | 컬럼 폭 < 한글 폭 | **컬럼 112~128px 권장** (16:9 wider viewport는 비율 적용) |
| **fonts.kr_16 없는데 한글 모듈 진입 시 `Not enough space` 크래시 (v0.28 M-31)** | macOS Sonoma+에서 .ttc 경로 변경 / Linux에 fonts-nanum 미설치 | **main.lua의 kr_candidates에 AppleSDGothicNeo 우선 + AppleGothic fallback + 시스템 폰트 자동 감지** |
| release 직전 단일 OS(macOS)만 `.app` 빌드 | M-20 cross-platform 빌드 recipe (아래) |
| `gh release upload` 또는 `gh release create`가 200MB+ asset에서 `Bad Size` / `release not found` | M-21 GitHub release asset multipart 우회 (아래) |

### 종합 — v0.28 핵심 학습 (한/영 토글 + Lua 5.1 환경)

1. **M-29: Love 11.5 (LuaJIT 5.1) 환경에서 native `&` `|` `~` `<<` `>>` 비트/시프트 연산자 syntax error**. 항상 `bit.band` / `bit.lshift` 등 LuaJIT 내장 `bit` 라이브러리 사용.
2. **M-30: self-cleanup 로직은 거의 항상 정상 데이터를 망가뜨림**. caller가 truncate 시 UTF-8 안전 처리를 했다면 callee는 그냥 `font:getWidth`만 호출. double-cleanup 패턴 금지.
3. **M-31: fonts.kr_16 fallback chain 안전성**. main.lua의 kr_*_N 로드 실패 시 textWidth가 Anonymous_8로 잘못 fallback 안하고 0 반환. 폰트 미설치 환경에서도 크래시 없이 라벨이 잘려 보이는 정도.
4. **M-32: truncate 시 '..' suffix는 한글화에서 거의 항상 가독성 떨어뜨림**. 그냥 한글 한 글자 잘린 라벨이 더 명확. SNKRX 1차 컨벤션과 BYTEPATH 사용자 피드백 (2026-07-22) 둘 다 같은 결론.
5. **M-33: 한글 폰트 크기에 따른 컬럼 폭 결정**. fonts.kr_16(14px) 컬럼 112~128px, fonts.kr_8(8px) 48~56px. viewport 비율로 스케일.

**5개 패턴 모두 stderr로 즉시 검출 가능 (M-29, M-30) 또는 1줄 명령으로 사전 검출 가능 (M-31의 폰트 파일 존재 확인)**. **위임이 "검증 완료"라고 보고해도 fonts.kr_16이 없는 환경은 GUI 진입 전에 발견할 수 있음** — main.lua에서 kr_candidates 루프 후 `assert(fonts.kr_16, 'no Korean font found; install fonts-nanum')` 같은 가드 한 줄 추가하면 부팅 단계에서 즉시 발견.

### 검증 명령 추가 (v0.28)

```bash
# 1. 부팅 직후 stderr 확인 (M-29 syntax error + M-30 UTF-8 error 검출)
(love . > /tmp/love_out.log 2>&1 &); sleep 6; kill $!; wait $!
cat /tmp/love_out.log | head -20
# 기대: CapsLock LED 메시지만 출력 (macOS 시스템, 무관). 다른 에러 있으면 픽스 필요.

# 2. 폰트 파일 존재 확인 (M-31 사전 검출)
ls -la resources/fonts/*.ttc resources/fonts/*.ttf
# 기대: NanumGothic.ttc (12.8MB) 또는 AppleSDGothicNeo.ttc (55MB) 또는 둘 다

# 3. love .f 에서 fonts.kr_16 로드 확인 (대화형 love 콘솔)
love . --console
# > print(fonts.kr_16 and 'kr_16 OK' or 'kr_16 MISSING')
# 기대: 'kr_16 OK'
```

### 결론 — v0.28 작업 패턴 종합

1. **fonts.kr_*_N은 main.lua에서 5개 사이즈 (8/10/12/14/16) 모두 로드**. 가장 큰 사이즈 (16px) 가독성, 가장 작은 (8px) 폴백.
2. **모든 비트 연산은 `bit.band`** (LuaJIT 5.1).
3. **textWidth는 self-cleanup 없이 font:getWidth만 호출**. truncate는 caller가 `shorten_utf8_last`로 UTF-8 안전 처리.
4. **truncate 시 '..' suffix 안 붙임** (한글 가독성 우선).
5. **컬럼 폭은 한글 폰트 크기 × 8 (글자 수) + padding** = 한글 7글자면 fonts.kr_16(14px) 기준 112px.

**다음 세션 진입점**: fonts.kr_16 (16px 네이티브) + line_y stride 18 + per-glyph baseline + 컬럼 112~128px + `shorten_utf8_last` truncate + `bit.band` 만 사용.

## 🆕 v0.28 신규 — M-29~M-33: LuaJIT 비트 + textWidth 자가 손상 + fonts.kr_16 fallback + truncate 가독성 + 컬럼 폭 (BYTEPATH 4차 한글화 보정 세션, 2026-07-22)

v0.27의 M-25/M-26/M-27/M-28 픽스 (per-glyph baseline, DeviceModule pop, shorten_utf8_last, Options 컬럼) 적용 직후 **5가지 새로운 함정 + 사용자 발견**이 한 세션 안에서 연속으로 터졌음. **모두 stderr로 즉시 검출 가능** (M-29, M-30) 또는 **사용자 GUI 피드백으로만 검출** (M-31, M-32, M-33). 이 5개는 **Lua 5.1 + 한글 + LÖVE 11.5 환경에서 누구나 한 번씩 만나는 함정**이라 다음 세션 진입점에 박혀 있어야 함.

### M-29 — LuaJIT 5.1 native `&` 비트 연산자 syntax error (부팅 즉시 차단, 가장 빠름)

v0.27의 `shorten_utf8_last` 헬퍼가 native `&` 연산자를 사용했더니 **Love 11.5 부팅 단계에서 syntax error로 크래시**:

```
Error: Syntax error: globals.lua:86: ')' expected near '&'
Traceback:
        [love "boot.lua"]:352: in function <[love "boot.lua"]:348>
        [C]: at 0x0104eb6e9c
        [C]: in function 'require'
        main.lua:27: in main chunk
        [love "boot.lua"]:323: in function <[love "boot.lua"]:126>
```

**원인**: Love 11.5는 **LuaJIT 2.1 (Lua 5.1 호환)** 사용. Lua 5.1 문법은 **native `&` `|` `~` `<<` `>>` 비트/시프트 연산자 없음**. Lua 5.2+ 의 `bit32` 또는 LuaJIT 내장 `bit` 라이브러리 사용 필요.

**수정**: 모든 비트 연산을 `bit.band(b, mask)` / `bit.lshift(b, n)` / `bit.rshift(b, n)` / `bit.bor(b, mask)` / `bit.bxor(b, mask)` 로 교체:

```lua
-- ❌ LuaJIT 5.1 syntax error (Love 11.5 환경)
if b and (b & 0xC0) == 0x80 then  -- syntax error: ')' expected near '&'

-- ✅ LuaJIT 내장 bit 라이브러리
if b and bit.band(b, 0xC0) == 0x80 then  -- OK
```

**판별 신호**: 부팅 즉시 `boot.lua:352: in function <boot.lua>` + `globals.lua:NN: ')' expected near '&'`. **Love 11.5 + 한글 truncate 작업 시 무조건 만나게 되는 함정**. 다른 Lua 5.3+ 환경 (Lua 5.3의 native 비트 연산자 지원, 또는 5.4의 `bit32` 라이브러리)에서는 발생 안 함.

**판별 요령**: bytepath-ex / SNKRX / 일반 LÖVE 11.5 게임은 모두 LuaJIT 2.1 기반. **UTF-8 byte 검사 시 native `&` 금지**.

**다른 곳에서 같은 함정 만날 위험**:
- `textWidth` / `shorten_utf8_last` 외에 UTF-8 lead byte 검사 (`b & 0xE0`, `b & 0xC0` 등)
- 비트 마스크로 flag 검사 (`flags & 0x01`)
- `<<`, `>>` shift 연산자 (`(b << 4)` — Lua 5.1 syntax error)

전부 `bit.band` / `bit.lshift` / `bit.rshift` / `bit.bor` / `bit.bxor` 로 교체.

**위임 패턴 — M-29 빠르게 인지**: 위임이 UTF-8 truncate 코드 작성 후 보고하면 **먼저 stderr에 `Syntax error` 있는지만 grep**. 있으면 99% M-29 (또는 다른 Lua 5.1 환경 함정). **sed로 `s/ & / bit.band(`, `s/<<` / bit.lshift(` 등으로 일괄 교체 가능**하지만 `b & mask` 와 같은 패턴 매칭은 신중히 — Lua 5.1에서 `&` 가 bitwise 아닌 단순 변수(예: `flags & other`)로 사용된 경우 syntax error가 다름. **`&` 가 항상 bitwise라고 가정하고 변환 가능**한 케이스만 일괄.

### M-30 — textWidth의 잘못된 trailing bytes cleanup (정상 UTF-8까지 잘라냄)

v0.27 직후 textWidth에 추가한 **trailing continuation bytes cleanup 로직이 정상 한글 텍스트까지 잘라내는** 함정:

```lua
-- ❌ v0.27 텍스트: 정상 UTF-8 텍스트의 마지막 바이트는 continuation byte (10xxxxxx)
-- '시작' (한글 2글자) = EC 8B A0 EC 9E 91
-- 마지막 바이트 0x91 → 10xxxxxx → cleanup 로직이 잘라냄 → 1바이트만 남음 (잘못된 UTF-8)
while #text > 0 do
    local b = text:byte(#text)
    if b and bit.band(b, 0xC0) == 0x80 then
        text = text:sub(1, -2)  -- ← 정상 한글도 잘라냄!
    else
        break
    end
end
return fonts.kr_16:getWidth(text)  -- ← 잘못된 UTF-8 → "Not enough space" 에러
```

**에러 메시지**:

```
Error: rooms/Console.lua:517: UTF-8 decoding error: Not enough space
Traceback:
        [love "callbacks.lua"]:228: in function 'handler'
        [C]: in function 'textWidth'
        rooms/Console.lua:517: in function '_drawMainMenu'
```

**판별 요령**: 정상 한글 텍스트 `'시작'`을 `fonts.kr_16:getWidth()` 호출 시 `"Not enough space"` 에러. **`Not enough space`는 love2d font cache가 텍스트 디코딩 중 실패 시 던지는 표준 에러**. bytepath-ex console GUI 메뉴 진입 시 즉시 크래시. **`'시작'`처럼 자주 쓰이는 짧은 한글에서 100% 재현됨**.

**수정**: textWidth는 단순히 `font:getWidth`만 호출. 자체 cleanup 로직 없음. truncate는 `shorten_utf8_last`가 UTF-8 안전하게 처리 (이미 코드 포인트 단위로 자름). **caller 책임**:

```lua
-- ✅ v0.28
function textWidth(font, text)
    if text == nil or text == '' then return 0 end
    -- NO trailing bytes cleanup — 정상 한글 텍스트의 마지막 바이트도
    -- continuation byte (10xxxxxx)이고 cleanup 로직이 잘라내면 'Not
    -- enough space' 에러. truncate 책임은 shorten_utf8_last가 짐.
    if has_cjk(text) and fonts and fonts.kr_16 then
        return fonts.kr_16:getWidth(text)
    end
    if font then return font:getWidth(text) end
    return 0
end
```

**결론 — self-cleanup 로직은 거의 항상 정상 데이터를 망가뜨림**. caller가 truncate 시 `shorten_utf8_last`로 이미 UTF-8 안전 처리를 하므로, callee에서 다시 cleanup하면 정상 텍스트가 망가짐. **`printT` 도 같은 원칙**: prev 폰트 복원 시 cleanup 안 함, caller 책임.

**판별 패턴**: "trailing bytes cleanup" "remove trailing UTF-8 bytes" "fix broken UTF-8" 같은 로직이 코드에 보이면 즉시 의심. **cleanup은 입력 단계 (파싱/로드 시) 에서만**, 폭 측정/그리기 단계에서는 하지 않음.

### M-31 — fonts.kr_16 fallback chain 안전성 (fonts.kr_8 fallback이 한글에서 'Not enough space' 유발)

`fonts.kr_16` 로드는 main.lua의 `loadFonts`에서 5개 사이즈 (14/16/12/10/8) 모두 등록. **하지만 만약 `.ttc`/`.ttf` 파일이 누락되면 `fonts.kr_*` 모두 nil**. textWidth 안의 `if fonts.kr_16 then ... else ...` fallback이 `else` 분기로 가서 **Anonymous_8 같은 영문 폰트에서 한글 텍스트의 getWidth를 호출** → "Not enough space" 에러.

**판별 신호**: `fonts.kr_16`이 nil인 환경 (NanumGothic.ttc 누락, macOS Sonoma+ 시스템 폰트 변경, Linux에 fonts-nanum 미설치) 에서 한글 T() 호출 시 즉시 크래시.

**안전 fallback 패턴**:

```lua
-- globals.lua
function textWidth(font, text)
    if text == nil or text == '' then return 0 end
    if has_cjk(text) and fonts and fonts.kr_16 then
        return fonts.kr_16:getWidth(text)
    end
    if font then return font:getWidth(text) end
    return 0  -- ⚠️ fonts.kr_16 없는 환경 + 한글 텍스트 → 0 반환 (라벨 폭 0, 잘림)
end
```

**중요**: fonts.kr_16 없을 때 **Anonymous_8:getWidth('한글') 호출하지 말고 0 반환**. 그러면 truncate 로직이 폭 0 기준으로 동작해서 **모든 라벨이 truncate되지만 최소한 크래시는 안 남**. 사용자 GUI에서 한글 라벨이 잘려 보이지만 게임은 정상 작동.

**main.lua kr_loaded 가드 (강력한 검출)**:

```lua
::kr_loaded::
assert(fonts.kr_16, 'No Korean font found. Install Nanum Gothic (Linux: apt install fonts-nanum) or drop a NanumGothic.ttc/AppleSDGothicNeo.ttc into resources/fonts/.')
```

**검증 명령**:

```bash
# 1. 부팅 직후 stderr 확인 (M-29 + M-30 검출)
(love . > /tmp/love_out.log 2>&1 &); sleep 6; kill $!; wait $!
cat /tmp/love_out.log | head -20
# 기대: CapsLock LED 메시지만 출력 (macOS 시스템, 무관). 다른 에러 있으면 픽스 필요.

# 2. 폰트 파일 존재 확인 (M-31 사전 검출)
ls -la resources/fonts/*.ttc resources/fonts/*.ttf
# 기대: NanumGothic.ttc (12.8MB) 또는 AppleSDGothicNeo.ttc (55MB) 또는 둘 다

# 3. love .f 에서 fonts.kr_16 로드 확인 (대화형 love 콘솔)
love . --console
# > print(fonts.kr_16 and 'kr_16 OK' or 'kr_16 MISSING')
# 기대: 'kr_16 OK'
```

### M-32 — truncate 시 `..` suffix vs 한글 한 글자 잘림 가독성 비교 (사용자 피드백 도출)

v0.27에서 `..` suffix를 한글 truncate 결과에 붙이려 했는데 (`디스플레이..` `창 크기:..` `언어:..`), **사용자 스크린샷에서 `..` 가독성이 더 나쁘다고 판단**. 짧게 잘린 한글 한 글자 (`디스플레이 모드` → `디스플레이 모드`)가 `..` 붙은 것 (`디스플레이..`) 보다 명확.

**수정 패턴 — M-27 + M-32 결합**:

```lua
-- ❌ v0.27: '..' 붙임 (가독성 떨어짐)
while textWidth(font, label_text .. '..') > label_col_w do
    label_text = shorten_utf8_last(label_text)
end
if textWidth(font, label_text .. '..') <= label_col_w then
    label_text = label_text .. '..'
end

-- ✅ v0.28: '..' 안 붙임. 그냥 짧게 잘린 라벨 (M-32)
while #label_text > 0 and textWidth(font, label_text) > label_col_w do
    local next_text = shorten_utf8_last(label_text)
    if #next_text == 0 or next_text == label_text then break end
    label_text = next_text
end
```

**결론**: **Options / Console GUI 메뉴 / 모듈 라벨은 truncate 시 '..' suffix 안 붙임**. 마지막 한 글자 잘림이 더 명확.

**판별 신호**: 모든 라벨에 `..` suffix가 붙어서 가독성 떨어져 보임. 예: `디스플레이..` `창 크기:..` `언어:..`. 또는 `디스플레이 모드...` 같은 점 3개 패턴.

**예외**: 메뉴 desc 같이 텍스트가 아주 길 때는 의미 변경 없으므로 OK. SNKRX 1차 컨벤션과 BYTEPATH 사용자 피드백 (2026-07-22) 둘 다 같은 결론.

### M-33 — Options 라벨/값 컬럼 폭 (한글 14~16px 컬럼 최소 96~112px)

한글 6글자 라벨 (`디스플레이 모드:`) 의 fonts.kr_16 14px 폭 측정:
- 한글 1글자 ≈ 14px
- 6글자 = 84px
- `:` 4px
- 총 ~88px

**라벨 컬럼 88px → 라벨이 항상 truncate됨** (`디스플레이..`). **라벨 컬럼 112px (value_x=128) 로 키우면** `디스플레이 모드:` 그대로 들어감. **너무 좁게 잡으면 항상 truncate, 너무 넓게 잡으면 값 영역 부족 — 96~128px가 sweet spot**.

```lua
-- rooms/Options.lua
local label_x = 8
local value_x = 128         -- 96 → 128 (한글 값 '데스크톱 (테두리없음)' 11글자 ≈ 154px 영역 확보)
local label_col_w = value_x - label_x - 8  -- 112px

-- 라벨 100px일 때: 100 < 112 → truncate 안 됨 (예: '디스플레이 모드:')
-- 라벨 120px일 때: 120 > 112 → shorten_utf8_last로 한 글자씩 제거 (예: '디스플레이 모드' → '디스플레이 모')
```

**공식 가이드 (한글화 컬럼 폭 결정)**:

| 한글 폰트 크기 | 라벨 컬럼 권장 폭 | 한글 한 줄 max 글자 |
|---|---|---|
| fonts.kr_8 (8px) | 48~56px | 3~4글자 |
| fonts.kr_12 (12px) | 72~80px | 5~6글자 |
| fonts.kr_14 (14px) | 96~112px | 6~7글자 |
| fonts.kr_16 (16px 네이티브) | 112~128px | 7~8글자 |

**viewport 480x270 기준**. 16:9 wider viewport (1280x720 등)에서는 비율로 키우면 됨.

**영문/한글 폭 비율 약 2:1**: Anonymous_8 8px ≈ 6px/글자, fonts.kr_16 14px ≈ 14px/글자. 같은 셀 안에 들어가는 한글 글자 수는 영문 절반.

**판별 신호**: `디스플레이..` `창 크기:..` `언어:..` 처럼 `..` suffix가 모든 라벨에 붙으면 → 컬럼 폭 16~32px 더 키움 (value_x 96→112 또는 96→128). **truncate `..` 금지** (M-32) 와 결합해서 컬럼 폭만 늘리면 해결.

### 종합 — v0.28 핵심 학습 (한/영 토글 + Lua 5.1 환경)

1. **M-29: Love 11.5 (LuaJIT 5.1) 환경에서 native `&` `|` `~` `<<` `>>` 비트/시프트 연산자 syntax error**. 항상 `bit.band` / `bit.lshift` 등 LuaJIT 내장 `bit` 라이브러리 사용.
2. **M-30: self-cleanup 로직은 거의 항상 정상 데이터를 망가뜨림**. caller가 truncate 시 UTF-8 안전 처리를 했다면 callee는 그냥 `font:getWidth`만 호출. double-cleanup 패턴 금지.
3. **M-31: fonts.kr_16 fallback chain 안전성**. main.lua의 kr_*_N 로드 실패 시 textWidth가 Anonymous_8로 잘못 fallback 안하고 0 반환. 폰트 미설치 환경에서도 크래시 없이 라벨이 잘려 보이는 정도.
4. **M-32: truncate 시 '..' suffix는 한글화에서 거의 항상 가독성 떨어뜨림**. 그냥 한글 한 글자 잘린 라벨이 더 명확.
5. **M-33: 한글 폰트 크기에 따른 컬럼 폭 결정**. fonts.kr_16(14px) 컬럼 112~128px, fonts.kr_8(8px) 48~56px. viewport 비율로 스케일.

**5개 패턴 모두 stderr로 즉시 검출 가능 (M-29, M-30) 또는 1줄 명령으로 사전 검출 가능 (M-31의 폰트 파일 존재 확인)**. **위임이 "검증 완료"라고 보고해도 fonts.kr_16이 없는 환경은 GUI 진입 전에 발견할 수 있음** — main.lua에서 kr_candidates 루프 후 `assert(fonts.kr_16, 'no Korean font found; install fonts-nanum')` 같은 가드 한 줄 추가하면 부팅 단계에서 즉시 발견.

### 검증 명령 추가 (v0.28)

```bash
# 1. 부팅 직후 stderr 확인 (M-29 syntax error + M-30 UTF-8 error 검출)
(love . > /tmp/love_out.log 2>&1 &); sleep 6; kill $!; wait $!
cat /tmp/love_out.log | head -20
# 기대: CapsLock LED 메시지만 출력 (macOS 시스템, 무관). 다른 에러 있으면 픽스 필요.

# 2. 폰트 파일 존재 확인 (M-31 사전 검출)
ls -la resources/fonts/*.ttc resources/fonts/*.ttf
# 기대: NanumGothic.ttc (12.8MB) 또는 AppleSDGothicNeo.ttc (55MB) 또는 둘 다

# 3. love .f 에서 fonts.kr_16 로드 확인 (대화형 love 콘솔)
love . --console
# > print(fonts.kr_16 and 'kr_16 OK' or 'kr_16 MISSING')
# 기대: 'kr_16 OK'
```

### 결론 — v0.28 작업 패턴 종합 (v0.29 진입점)

1. **fonts.kr_*_N은 main.lua에서 5개 사이즈 (8/10/12/14/16) 모두 로드**. 가장 큰 사이즈 (16px) 가독성, 가장 작은 (8px) 폴백.
2. **모든 비트 연산은 `bit.band`** (LuaJIT 5.1).
3. **textWidth는 self-cleanup 없이 font:getWidth만 호출**. truncate는 caller가 `shorten_utf8_last`로 UTF-8 안전 처리.
4. **truncate 시 '..' suffix 안 붙임** (한글 가독성 우선).
5. **컬럼 폭은 한글 폰트 크기 × 8 (글자 수) + padding** = 한글 7글자면 fonts.kr_16(14px) 기준 112px.

**다음 세션 진입점**: fonts.kr_16 (16px 네이티브) + line_y stride 18 + per-glyph baseline + 컬럼 112~128px + `shorten_utf8_last` truncate + `bit.band` 만 사용.

## ⛔ 풀 풀스택 위임 600s 타임아웃 위험성 (v0.24 신규, 사용자 의도와 무관)

**사용자가 "A 풀 풀스택 한/영 토글" + "b 점진 (1차 → 검증 → 2차)"를 골라도**, 이 두 옵션을 결합해서 **위임 task 한 번에 풀스택 (메뉴 + 12개 모듈 + UI 헤더 + 콘솔 부팅 + 검증) 을 묶으면 600s 타임아웃으로 약 40%에서 끊긴다** (BYTEPATH 1차 사례 검증: 2026-07-22, deleg_525e20d8).

위임이 600s에 끊기는 이유:
- 모듈형/모노리식 게임의 한글화 풀은 (1) 영문 풀 스캔 + (2) dict 작성 + (3) 모듈별 T() patch + (4) 검증이 한 위임 안에 들어감.
- 모듈 9~12개 + 콘솔 부팅 50+ 라인 + UI 헤더 10+ 파일 = 패치 호출 40+ + 검증 = 50+ API call 소진. 600s 안에 안 끝남.
- 위임이 폰트 검색 (`find /`) 같은 60s 짜리 명령 한 번에 박살.

**위임 사용 정책 (수정)**:
1. **풀 풀스택 위임 금지** — 1차 풀스택은 위임 금지. **1차의 "메뉴 + 모듈 일부"까지만 위임** + 사용자에게 보고 + 사용자가 직접 마무리 OR 다음 위임.
2. **위임 task에 "끝나지 않으면 commit + master push까지만이라도 보고하라" 명시** — 위임이 끊겨도 작업물이 master에 남아야 함.
3. **위임이 50 API call 가까이 가면 자가 멈춤 + 현재 상태 보고** — 끊기면 솔직 보고 패턴 강제.
4. **사용자가 명시적으로 "위임할께 풀스택"을 골라도**: 위임은 "단일 화면 단위로 좁힘" 정책 우선 (기존 메모리 규칙) — 9개 모듈은 **한 세션 위임 X**, **두 위임 OR 위임 + 직접 마무리** 조합으로 분할.

판별 신호: 위임이 50 call 가까이 가는데 모듈 5개+ 남았으면 → 위임 task에 "지금 멈추고 현재까지 변경 파일 목록 + 잔여 모듈 보고만 해라" 메시지 보내고 자가 종료.

자세한 시간순 + 보고서 형태: `references/bytepath-ex-v0.x-koreanization-1st-timeout-recovery.md`.

## 🆕 v0.24 신규 — fonts.kr_8 draw 단계 wiring (가장 자주 빠지는 함정)

v0.23 부트스트랩은 `fonts.kr_8` 폰트 핸들을 등록했지만 **draw 단계에서 안 쓰면 한글 T() 출력이 Anonymous_8 영문 폰트로 떨어져서 □ 로 깨진다** (BYTEPATH 1차 사례 검증: `Paused.lua`, `ScoreScreen.lua`, `Stage.lua` HUD 모두 한글 T() 적용 후 GUI 띄우면 □ 표시).

**증상**: stderr 비어있고 부팅 정상인데, 화면의 한글 라벨이 전부 □ 또는 `?`로 표시. `fonts.kr_8` 핸들은 `fonts` 테이블에 있지만 `love.graphics.setFont(self.font)`로 영문 폰트가 활성.

### 픽스 A — 자동 감지 헬퍼 (globals.lua)

`has_cjk()` UTF-8 lead byte 감지 + `printT()` / `textWidth()` 헬퍼를 globals.lua에 두고 **모든 draw 호출을 printT로 변환**하면 손쉬움. BYTEPATH v0.2.1 1차 픽스 (commit `f84642e`)에서 검증됨.

```lua
-- globals.lua 선두 (ko.lua require 직후)
function has_cjk(str)
    if str == nil then return false end
    for i = 1, #str do
        local b = str:byte(i)
        -- CJK Unified Ideographs / Hangul Syllables (U+AC00..) → 0xEA..
        -- CJK Symbols / Hangul Jamo (U+3000..) / 한자 (U+4E00..) → 0xE3..
        if b == 0xEA or b == 0xEB or b == 0xEC or b == 0xED or b == 0xEE or b == 0xEF then
            return true  -- U+AC00..U+FFFF
        elseif b == 0xE3 then
            return true  -- U+3000..U+3FFF
        end
    end
    return false
end

function printT(font, text, ...)
    local prev = love.graphics.getFont()
    if has_cjk(text) and fonts and fonts.kr_8 then
        love.graphics.setFont(fonts.kr_8)
    elseif font then
        love.graphics.setFont(font)
    end
    love.graphics.print(text, ...)
    love.graphics.setFont(prev)
end

function textWidth(font, text)
    if has_cjk(text) and fonts and fonts.kr_8 then
        return fonts.kr_8:getWidth(text)
    end
    if font then return font:getWidth(text) end
    return 0
end
```

**한/영 혼합 라벨** (예: `'Apply 5 SP'`)도 kr_8로 출력 — Anonymous_8는 한글 글리프 없어서 한 글자도 못 그리고 fallback 0으로 출력. 한/영 폭 차이는 신경 쓰지 말고 통째로 kr_8.

### 픽스 B — sed로 일괄 변환

v0.24 1차 픽스에서 실제로 한 변환 (BYTEPATH v0.2.1 사례):

```bash
# modules + rooms/Console.lua 의 love.graphics.print 를 printT 로 일괄 변환
files="objects/modules/*.lua rooms/Console.lua"
for f in $files; do
  sed -i '' 's/love\.graphics\.print(/printT(self.font, /g' "$f"
done

# 주의: getWidth는 truncate 폭 측정이라 변환하면 안 됨.
# 정확한 폭 측정은 `font:getWidth` 그대로 두고 (영문 truncate 경로), 한글 라벨이 셀 안에 안 들어가면
# trunc logic을 textWidth(self.font, label)로 별도 교체.
```

`love.graphics.print`가 포함될 수 있는 곳을 빠짐없이 검색:

```bash
grep -n "love.graphics.print" rooms/*.lua objects/*.lua objects/modules/*.lua
```

대상 파일: rooms/Stage.lua / rooms/SkillTree.lua / rooms/Options.lua (각 row / 콘솔 버튼 / 헤더) + objects/Paused.lua / ScoreScreen.lua / Tutorial.lua / InfoText.lua + ConsoleLine.lua (character 단위 — 픽스 C 참조) + ConsoleInputLine.lua + Attack.lua + Item.lua + AchievementScreenshots.lua + Achievements.lua + Classes.lua.

### 픽스 C — ConsoleLine character-by-character 렌더 (BYTEPATH 특유)

BYTEPATH는 `ConsoleLine:draw()`가 `self.text`를 글자 단위로 utf8sub 해서 `love.graphics.print(c, ...)` 호출 — 한글 한 글자도 Anonymous_8에 들어가서 □ 깨짐. **language 버킷에 'kr' 추가**해서 kr_8로 그려야:

```lua
-- objects/ConsoleLine.lua setCharacters()
local is_cjk = has_cjk(c)
local char_lang = language
if is_cjk then char_lang = 'kr' end
table.insert(self.characters, {c = c, language = char_lang, visible = false, marker = marker})

-- 폭 계산도 kr_font:getWidth
local kr_font = fonts.kr_8 or normal_font
if self.characters[j].language == 'kr' then
    width = width + kr_font:getWidth(self.characters[j].c)
end

-- ConsoleLine:draw()
local kr_font = fonts.kr_8 or normal_font
if self.characters[i].language == 'kr' then love.graphics.setFont(kr_font) end
-- love.graphics.print(self.characters[i].c, ...)
```

이렇게 하면 콘솔 부팅 시퀀스(`':: running hook'`, `'@PATHING ERROR DETECTED#'` 등 한글 라인)가 정상 표시. **swap table 적용 라인(`'[  ;WAIT,  ] allocating ...'`)은 swap from/to가 영문이라 영문으로 swap되어 표시되는 게 정상** — 1차 정책.

### 픽스 D — 직접 페어링 (가장 직관적)

draw 단계에서 한글 라벨을 그리기 직전 `setFont(fonts.kr_8)`, 직후 `setFont(self.font)` 페어링:

```lua
function Paused:draw()
    love.graphics.setFont(self.font)
    -- ... 영문 라벨 출력
    love.graphics.setFont(fonts.kr_8)
    love.graphics.print(T('paused_resume'), cx + btn_w/2 - ..., cy + ...)
    love.graphics.setFont(self.font)
    -- ... 다시 영문
end
```

영문 라벨이 한글보다 많으면 페어링이 번거로움 → 픽스 A 헬퍼 권장.

**검증 방법 (GUI 검증 필수)**:
1. `love .` 실행
2. 콘솔 진입 → 메인 메뉴 8개 셀 한글 표시 확인
3. 옵션 → language 토글 → en/ko 즉시 전환 + 한글 라벨 □ 안 깨지는지
4. 모듈 12개 각각 진입 → 헤더 + 본문 한글 표시 확인
5. Paused 진입 → RESUME/MENU 한글 표시 확인
6. Stage 시작 → AMMO/BOOST/HP/CYCLE 라벨 한글 표시 확인
7. 콘솔 부팅 시퀀스 (Arch Linux 시뮬레이션) 한글 라인 확인

**판별 신호**: stderr 비어있고 love . 부팅 정상인데 사용자 GUI에서 한글 라벨이 □ → fonts.kr_8 draw 단계 wiring 누락. **위임이 "검증 완료"라고 보고해도 fonts.kr_8 사용 여부는 stderr로 못 잡음 — 반드시 GUI 검증 단계 필요.**

## 🆕 v0.24 신규 — i18n dict 위임 일관성 함정

**위임으로 ko.lua + en.lua를 동시에 작성하면 두 dict의 키 이름이 미묘하게 어긋난다** (BYTEPATH 1차 사례: ko.lua는 `intro_running_hook`/`intro_to`/`intro_dev_mounted` 같은 prefix 통일 키, en.lua는 `intro_hook_stre`/`intro_mount_devarch`/`intro_devarch_mounted` 같은 라벨별 키). 어차피 영문 fallback이라 화면 표시는 정상이라 안 보이지만, **2차에서 `swap to` 한글화하거나 키 검색할 때 혼란**.

**위임 정책**:
1. **dict 작성은 한 파일로 통합한 다음 복제** — `ko.lua` 먼저 작성 → `en.lua`는 `lang_ko_keys = sorted(keys of ko)` 추출 후 같은 키 dict에 영문 값 채움.
2. **또는 dict 작성 후 자동 검증**:
   ```bash
   # ko.lua vs en.lua 키 일치 검증 (둘 다 return { ... } dict)
   diff <(lua -e 'for k in pairs(dofile("lang/ko.lua")) do print(k) end' | sort) \
        <(lua -e 'for k in pairs(dofile("lang/en.lua")) do print(k) end' | sort)
   ```
3. **dict 변경 후 `T(key)` 호출이 nil 반환 안 하는지** — `T()` 함수에 `assert(v, 'missing key: ' .. key)` 디버그 모드 토글 추가 (릴리즈 빌드에선 silent fallback).

## 🆕 v0.24 신규 — gitignore 한글 폰트 50MB 가드

BYTEPATH 1차 사례: `resources/fonts/AppleSDGothicNeo.ttc` 55MB 추가 → `git push`에서 GitHub 50MB 경고 + LFS 권장. 한/영 dict + 한글 폰트는 게임에 필수지만 `.ttc` 50MB+는 git 추적 부적합.

**셋업 정책**:
1. **.gitignore에 게임 리소스 디렉터리 폰트 항목 추가**:
   ```
   # Korean fonts — large TTC files belong in release assets, not git
   resources/fonts/*.ttc
   resources/fonts/*.ttf
   ```
2. **Nanum Gothic 같은 작은 폰트 (12.8MB)만 git 추적** 가능 — AppleSDGothicNeo 55MB는 .love release asset으로 분리.
3. **CI/release 빌드에서 시스템 폰트 fallback**: macOS는 `/System/Library/AssetsV2/com_apple_MobileAsset_Font8/.../NanumGothic.ttc`, Linux는 `apt install fonts-nanum`, Windows는 Malgun Gothic. 셋업 시 시스템 폰트 경로 탐지 후 부트스트랩에서 자동 로드.
4. **폴백 체인 우선순위** (Nanum Gothic이 가장 가벼움):
   ```
   NanumGothic (12.8MB) → AppleSDGothicNeo (55MB) → AppleGothic (TTC) → 시스템 기본
   ```

판별 신호: `git push` 후 GitHub 경고 `Large files detected ... 50.00 MB`. .gitignore 정리 후 `git rm --cached` + 재 commit.

## 한/영 토글 사전 점검 — 코드베이스 진입 후 한 줄도 바꾸기 전 (v0.22/v0.23 신규)

한글화 의뢰가 들어왔을 때 **부팅 검증 직후, T() 함수/폰트 도입 전**에 반드시 거치는 5단계. 이걸 거치지 않으면 모듈 12개 중 한 군데서 마커 충돌/폭 깨짐으로 한 세션 다 까먹는다 (BYTEPATH 1차 매핑표 사례 검증).

### 0단계 — T() 함수 / 한/영 dict / 한글 폰트 부트스트랩 (한 줄도 바꾸기 전)

영문 풀 스캔하기 **전에** 다음 3종을 한 번에 깔아 둔다. 안 그러면 모듈 한글화 도중 `T(key)` 호출이 `nil`로 터지거나 픽셀 폰트가 깨진다.

**a) 한/영 dict** — `lang/` 디렉터리 + `ko.lua` + `en.lua`:

```lua
-- lang/ko.lua: ko = require 결과로 한글 dict 반환
return {
    menu_start       = '시작',
    menu_start_desc  = '시뮬레이션 시작',
    -- ... 매핑표 전체 키
}

-- lang/en.lua: 동일 키 + 영문 원문. fallback용 + 저장 안 한 상태에서의 원문 복원용.
```

**b) T() 전역 + language 디폴트** — `globals.lua` 선두 (한/영 dict require 포함):

```lua
language = 'ko'
ko = require 'lang/ko'
en = require 'lang/en'

-- Lookup: ko → en → key 자체 반환 (한글 dict에 키 없어도 영문 fallback, 영문 dict에 키 없으면 키 자체를 화면에).
function T(key)
    if language == 'en' then
        local v = en[key]; return v ~= nil and v or key
    end
    local v = ko[key]
    if v ~= nil then return v end
    v = en[key]
    return v ~= nil and v or key
end

-- setPermanentGlobals에서 디폴트 + 직렬화:
language = language or 'ko'
```

저장 포맷에 `language` 필드를 추가해서 save/load 사이클로 영구화. 옵션 메뉴에서 토글하면 `save()` 호출 → 다음 부팅에 유지.

**c) 한글 픽셀 폰트 로드** — `main.lua`의 `loadFonts` 끝에 kr_8 추가:

```lua
-- 우선순위: 나눔스퀘어라운드(시스템에 있으면) → NanumGothic → AppleSDGothicNeo → AppleGothic
-- macOS 시스템 폰트 경로:
--   /System/Library/AssetsV2/com_apple_MobileAsset_Font8/.../NanumGothic.ttc (12.8MB)
--   /System/Library/Fonts/AppleSDGothicNeo.ttc (55MB, 백업)
-- 한국어 macOS에서 fc-match -f "%{file}\\n" "Nanum Gothic"으로 경로 추출.
local kr_candidates = {'NanumGothic', 'AppleSDGothicNeo', 'AppleGothic'}
for _, name in ipairs(kr_candidates) do
    for _, ext in ipairs({'.ttc', '.ttf'}) do
        local ok, f = pcall(love.graphics.newFont, path .. '/' .. name .. ext, 8)
        if ok and f then
            f:setFilter('nearest', 'nearest')
            fonts['kr_8'] = f
            goto kr_loaded
        end
    end
end
::kr_loaded::
```

**폰트 크기 주의**: Nanum Gothic 계열은 한글 한 글자 약 8px 폭. 영문 픽셀 폰트 (Anonymous/m5x7) 6~7px 대비 2배 가까이. 셀 안 truncate는 필수.

**판별 신호**: 모듈 진입 시 `attempt to call a nil value (global 'T')` → 부트스트랩 누락. `\\xE0` 같은 깨진 문자 → kr_8 미로딩 **또는 draw 단계 setFont 누락 (v0.24 함정)**.

### 1단계 — 영문 풀 스캔

대상 풀을 6개 카테고리로 미리 분류해 둔다. 모듈형/모노리식 양쪽 모두 동일:

| 풀 | 위치 (BYTEPATH 사례) | 비고 |
|---|---|---|
| 메인 메뉴 셀 | `rooms/Console.lua` `bytepathMain` | 보통 6~10 셀, 라벨+desc |
| 모듈/서브메뉴 | `objects/modules/*.lua` 또는 `rooms/*Module.lua` | About/Help/Clear/Device/Display/Effects/Resolution/Sound/Shutdown/Escape/Credits/Fullscreen — 600줄+ 흔함 |
| 콘솔 부팅/시나리오 | `bytepathIntro` / `bytepathMain` 의 `addLine` 체인 | Arch Linux 부트 시뮬레이션처럼 시나리오가 길면 100+ 라인 |
| UI 헤더/HUD | `rooms/Stage.lua` HUD, `objects/Paused.lua`, `ScoreScreen.lua`, `SkillTree` 헤더 | 짧지만 박스 폭 재계산 필요 |
| 이름 풀 (스킬/유닛/디바이스) | `globals.lua` `attacks` / `class_colors` / `devices` / `achievement_descriptions`, `tree.lua` 노드 stat | **가장 큰 작업** — 스킬 stat 700+ 흔함 |
| InfoText/팝업 | `objects/Player.lua` `InfoText` 추가, `Director.lua` 한 줄 팝업 | 짧음, `+1 SP` 같은 단위 표기는 그대로 두는 게 일반적 |

스캔 도구: `search_files` 패턴으로 `addLine|InfoText|~ type|@help|@start|@passives|@classes|press |tutorial|skill point|score|level|game over` 등 게임별 키워드 변형.

### 2단계 — 컬러 마커 보존 규칙 (절대 변경 금지)

`$text%`, `@warning#`, `;system,`, `~command~` 같은 **포맷팅 마커**가 코드 어디서 string match/replace로 동작하는지 먼저 확인. **한글화 시 마커 문자열 자체는 절대 건드리면 안 됨** — 번역 대상은 마커 *사이*의 텍스트만:

```lua
-- ❌ 마커 안의 키 이름까지 바꾸면 line:replace 매칭 실패
'~ press @ESC# to exit' → '~ 나가려면 @ESC# 를 누르세요'  -- @ESC# 그대로 OK

-- ✅ 마커 보존 + 내부 텍스트만 한글화 (가장 흔한 패턴)
'$CURRENT DEVICE: FIGHTER%' → '$현재 디바이스: 파이터%'   -- $...% 마커는 그대로, 안의 텍스트만
```

**확인 절차**: `grep -n "string.replace\\|gsub\\|string.find" rooms/ objects/` → 마커 기반 매칭이 있는 모든 위치를 찾아서 키 이름이 보존되는지 검증. 마커 안의 키 이름(예: `FIGHTER`)이 `device_line:replace('FIGHTER', ...)` 로 사용되는지 반드시 확인.

### 2.5단계 — addLine swap table 정책 (BYTEPATH / 모노리식 게임에서 자주 빠지는 함정)

모노리식 게임 (BYTEPATH)은 `Console:bytepathIntro` 같은 부팅 시퀀스에서 `addLine`에 swap table을 같이 넘긴다:

```lua
self.console:addLine(delay + 4.80, '[  ;WAIT,  ] allocating user and session (...) [...]', 1, {{';WAIT,', ' <OK> '}, {'allocating', 'allocated'}})
```

`ConsoleLine:replace`가 이 swap table을 받아 `';WAIT,'` → `' <OK> '`, `'allocating'` → `'allocated'` 를 string match/replace로 동작시킨다. **`;WAIT,` 같은 마커 안의 단어는 컬러/스왑용 key이고, 한글화 시 절대 건드리면 안 됨.**

**1차 정책 — swap from / swap to 모두 영문 유지**:

```lua
-- ✅ 안전 (1차 권장): swap table의 from/to 모두 영문. 표시 텍스트만 한글화.
self.console:addLine(delay + 4.80,
    '[  ;대기,  ] 사용자 및 세션 할당 중 (...) [...]',  -- 마커 안의 ;대기,는 OK이지만
    1, {{';WAIT,', ' <OK> '}, {'allocating', 'allocated'}}  -- swap table은 그대로
)
-- 단, swap이 ;WAIT, → <OK>로 동작하므로 위 한글 라인은 swap 적용 후 그대로 '사용자...'로 남고
-- swap 동작이 '영동 단어를 매칭 → 다른 영문 단어로 교체'이기 때문에 추가 변경 없음.
```

**위험한 패턴 (하지 말 것)**:

```lua
-- ❌ swap from을 한글로 바꾸면 ConsoleLine의 string match가 영문 라인에서 못 찾음
self.console:addLine(0, '[ ... ] allocating ...', 1, {{'할당', '할당됨'}})

-- ❌ swap to를 한글로 바꾸면 swap 동작 후 화면에는 한글이 보이지만, 다른 swap 시점이나
-- 외부 코드가 ' <OK> ' 같은 영문 상태 마커를 매칭하려 할 때 깨짐
self.console:addLine(0, '[  ;WAIT,  ] allocating ...', 1, {{';WAIT,', ' <OK> '}, {'allocating', '할당됨'}})
```

**판별 신호**: 부팅 시퀀스에서 swap 적용 후 라인이 그대로 영문 swap to로 표시되거나 (`<OK>`, `could not start`) — 이건 **1차 정책상 정상 동작**. 한글화 2차에서 swap to 영문 status marker는 그대로 두고 swap from을 한글로 바꿔서 한/영 swap 결과를 동시 노출하는 패턴은 별도 session에서 신중히.

**작업 순서**: `addLine`의 표시 텍스트는 한글화 OK (마커 내부만 보존), `addLine`의 4번째 인자 swaps table의 swap from/to는 **모두 영문 그대로 두기**. dict에 `swap_allocated`, `swap_mounted` 같은 키를 등록만 해두고 값은 영문으로 두면, 2차에서 `swap from` 한글화 시 dict만 교체하면 됨.

### 3단계 — 명령어 영문 유지 + 1차 점진 진행

| 항목 | 1차 | 2차 (사용자 검증 후) |
|---|---|---|
| 메인 메뉴 라벨/desc | ✅ 한글화 | — |
| 모듈 12개 | ✅ 한글화 | — |
| 콘솔 부팅 시나리오 | ✅ 한글화 | — |
| UI 헤더/HUD | ✅ 한글화 | — |
| **콘솔 입력 명령어** (`escape`/`passives`/`help`/`device`/...) | ❌ 영문 그대로 | ✅ 한글 alias 확장 (`지우개` ↔ `clear`) |
| **스킬/유닛/디바이스 이름** | ❌ 영문 그대로 | ✅ 한/영 dual dict |
| **SkillTree stat 풀** (700+ 항목) | ❌ 영문 그대로 | ✅ stat dict 추가 |
| **Achievement 이름** | ❌ 영문 그대로 | ✅ dict |

이유: 사용자가 검증할 때 **시나리오의 첫 인상**은 메뉴/모듈 한글이고, 스킬 stat은 hover로 보고 결정. stat을 1차에 같이 작업하면 600+ 매핑 + GUI 검증 한 세션에 못 끝내고 의미가 어긋남. **점진 (1차 → 사용자 검증 → 2차) 패턴이 SNKRX v0.1.20+ 와 BYTEPATH 1차 매핑표 사례에서 검증됨**.

**위임 정책 보강 (v0.24)**: 사용자가 "위임할께 풀스택"을 골라도 1차 풀스택은 위임 금지 — 9개 모듈은 위임 한 번에 못 끝남. **위임 task 범위 = 메뉴 + 모듈 4~6개 + 검증** OR **직접 마무리 + 다음 위임**.

자세한 1차 풀 + 2차 풀 분류는 `references/bytepath-ex-v0.x-koreanization-mapping.md` 참조.

### 4단계 — 번역 매핑표 + 옵션 토글 row

번역 매핑표는 **`docs/koreanization-mapping.md`** 또는 `references/` 디렉터리에 마크다운으로 저장 (사용자가 검토할 수 있는 단일 진실 소스). 각 모듈/메뉴 풀의 원문 ↔ 한글 표 + 컬러 마커 + 영문 유지 항목 주석 포함.

옵션 메뉴에는 **`language` toggle row 추가** (SNKRX 컨벤션, BYTEPATH 1차 계획):
```lua
{ kind = 'toggle', key = 'language', label = 'language', value_ko = '한글', value_en = 'English' }
```
디폴트 `language = 'ko'` (영문 디폴트로 시작하려면 `'en'`).

### 5단계 — 폭 재계산 + 검증 (fonts.kr_8 wiring 포함)

한글 픽셀 폰트는 영문 픽셀 폰트 폭의 2~3배. 모듈의 `selection_widths = {font:getWidth('text')}` 로 raw 매칭하는 모든 위치를 찾아서 한글화 후 폭이 셀 안에 들어가는지 확인. 안 들어가면 `..` truncate (M-17 컬럼 분할 layout 활용).

**selection_widths 박스 폭 재계산 패턴 (한글화 후 필수)**:

```lua
-- BEFORE (영문):
self.selection_widths = {
    self.console.font:getWidth('clear CLASS data'),   -- ~91px (Anonymous 8px)
    self.console.font:getWidth('clear PASSIVE data'),
    self.console.font:getWidth('clear ALL data'),
}

-- AFTER (한글):
self.selection_widths = {
    self.console.font:getWidth(T('clear_class')),     -- T()가 '클래스 데이터 초기화' 반환 → ~95px (NanumGothic 8px)
    self.console.font:getWidth(T('clear_passive')),
    self.console.font:getWidth(T('clear_all')),
}
```

**박스 자체 위치는 그대로, 폭만 갱신**:
- `self.x_offset` 같은 prefix 너비 (`'    '` = 4칸 prefix의 너비)는 영문 폭이므로 그대로 둠. 셀 안 highlight 박스가 한글 라벨 폭보다 약간 좁아 보일 수 있으나 **x_offset이 어긋나는 것보다 폭이 어긋나는 게 시각적으로 덜 거슬림**.
- 더 정확하게 하려면 `font:getWidth(T(label))` 도 함께 갱신해서 한글 prefix로 교체 (예: `'    '` → `'    '`, 명령어 부분은 영문이라 폭 동일).
- 명령어 입력 폭 (`AboutModule:draw`의 `getWidth('escape')` 등)은 **명령어가 영문 1차 유지이므로 그대로 두는 게 맞다**. AboutModule의 hint가 T('about_escape_hint') 한글이지만 강조 단어가 'escape' 영문이라 getWidth('escape') 사용 OK.

**구분 마커 폭 (`'clear CLASS data'`처럼 $클래스% 마커 안에 영문 들어갈 때)**: 마커는 그대로 두고 `T()` 내부 텍스트만 교체하므로, **'clear CLASS data' 마커 안의 'CLASS'는 영어 그대로** + 외부 라벨만 한글로. selection_widths는 마커 안의 영문 기준 폭 측정 — 혼동 시 모듈에서 직접 `draw` 단계의 highlight 박스를 검증해야.

**검증 단계는 한글화 변경 직후 매 모듈마다**:
1. 모듈 진입 → highlight 박스가 셀 안에 정확히 들어가는지
2. 한글 라벨이 셀 밖으로 삐져나가는지 (truncate 로직이 박스 안에 들어가는지)

검증:
1. `love .` 부팅 → 콘솔 화면 정상
2. **8개 메인 메뉴 셀 모두 한글, 셀 안 □ 깨짐 없음 (fonts.kr_8 wiring 검증)** ← v0.24
3. 옵션 `language` 토글 → en/ko 즉시 전환 + 셀 안 □ 깨짐 없음
4. 모듈 12개 진입 가능 + 한글 텍스트가 셀 안에 들어감 + □ 없음
5. 콘솔 입력 명령어 (영문) 그대로 동작
6. 컬러 마커 `$@;~` 포맷팅 보존
7. **Paused/ScoreScreen/Stage HUD 한글 라벨 □ 안 깨지는지 (GUI 검증 필수)** ← v0.24

## 한/영 토글 사전 점검 시 함정 (7대, v0.24 확장)

1. **마커 기반 string 매칭을 깨뜨림** — `$CURRENT DEVICE: X%` 의 `X` 부분을 한글화할 때 `$...%` 마커가 사라지면 `device_line:replace(tostring(...), ...)` 매칭 실패. **마커는 항상 그대로, 내부 텍스트만 교체**.
2. **selection_widths 박스 위치 어긋남** — 모듈의 `selection_widths = {font:getWidth('class text')}` 폭이 한글화 후 2~3배 늘어나서 셀 밖에 박스 그려짐. **한글화 후 `selection_widths`도 `getWidth(T('key'))`로 재계산 필수** — 5단계 참조. 영문/한글 동시 dict는 `language`로 분기해서 같은 모듈 init에서 다시 측정하는 게 안전.
3. **콘솔 입력 검증을 깨뜨림** — 명령어 한글화 1차에서 시도하면 `ConsoleInputLine.lua`의 `self.commands = {'resolution', 'sound', ...}` 리스트도 같이 바꿔야 하고, 사용자가 영문으로 친 명령어가 안 먹힘. **1차에선 반드시 영문 유지**.
4. **ConsoleIntro addLine swap table 영문화 잠금** (모노리식 게임 한정) — 부팅 시퀀스 addLine이 `{{';WAIT,', ' <OK> '}, {'allocating', 'allocated'}}` 같은 swap table을 받아서 ConsoleLine 내부 string replace로 동작. swap from/to는 매핑표가 한글로 보여도 **1차에선 둘 다 영문 유지** — 2.5단계 참조. dict에 `swap_*` 키 등록만 해두고 영문 값으로 두면 2차에서 dict만 교체.
5. **setPermanentGlobals와 load() 호출 순서** — `T()`가 `setPermanentGlobals` 안에서 참조되면 그 시점엔 ko.lua가 로드 안 됐을 수 있다. `globals.lua`의 모듈 선두 (require 바로 다음) 라인에 `language = 'ko'` 디폴트를 둬서 setPermanentGlobals가 실행되기 전에 ko가 require 되도록 순서 보장.
6. **fonts.kr_8 부트스트랩만 하고 draw에서 안 씀 (v0.24)** — 한글 T() 출력이 Anonymous_8 폰트로 떨어져서 □로 깨짐. draw 단계 setFont(fonts.kr_8) 페어링 필수. **위임이 "검증 완료"라고 보고해도 stderr로 못 잡음 — GUI 검증 단계 필수**.
7. **풀 풀스택 위임 600s 타임아웃 (v0.24)** — 모듈 9~12개를 위임 한 번에 끝내려 하면 끊김. 모듈 4~6개 + 검증 위임 OR 직접 마무리 + 다음 위임.

## 핵심 마이그레이션 함정 (요약)

전체 21대 함정의 압축 표. 자세한 판별 + 수정 패턴은 references/ 의 케이스별 MD:

| ID | 한 줄 요약 | 해결 한 줄 |
|----|-----------|-----------|
| M-0 | 셰이더 `extern Image` / 0..255 색상 | `.frag` 8개 modern GLSL 변환 + setColor /255 정규화 |
| M-1 | Steamworks FFI dlopen 크래시 | steamworks_shim.lua + main.lua line 1 교체 |
| M-2 | setLooping(opts.loop) nil 거부 | `opts.loop == true` 명시 변환 |
| M-3 | Source:isStopped 제거 | nil-safe + isPlaying 폴백 |
| M-4 | custom love.run 검은 화면 | legacy_love_run_disabled로 보존 + M-6 의심 |
| M-5 | conf.lua releases 무시 | 무시 OK |
| M-7.5 | 룸 self.canvas_name 누락 (setCanvas nil) | `:new()`에서 모든 main_canvas 등 생성 확인 |
| M-7.6 | 셰이더 4-pass 파이프라인 검은/흰 saturate | camera:attach + 직접 line:draw 패턴 |
| M-7.7 | viewport가 윈도우 좌상단에만 그려짐 (검정) | `render_canvas = newCanvas(gw, gh)` + 끝에서 `drawGameCanvas(self.render_canvas)` |
| M-9 | 룸 전환 시 camera 잔재 (smooth.damped, scale 0.2) | 새 룸 :new()에서 camera:lookAt + scale=1 + smoother=nil |
| M-10 | Node 선택 강조 흐림 (bought/selected/idle 3-state) | Line:update에 3-state 분기 + Node:draw selected-fill+thick outline |
| M-11 | kb_enter가 마우스 클릭 후 무효 | SkillTree:update에서 single-source-of-truth (가장 가까운 화면 안 노드) |
| M-12 | 그래프 룸 viewport 자동 핏 실패 | 트리 median 좌표 + camera.scale = 2.0 + window_scale 자동 |
| M-13 | 누적 line_y로 메뉴 cursor 그려서 viewport 밖 | self.lines에서 `~ type @<target>#` 매칭 후 line.y 사용 |
| M-14 | multi-pass 셰이더(glitch/rgb_shift/distort) 위로 그린 UI는 누적 효과로 사라짐 | UI(cursor, highlight, 모달)는 `drawGameCanvas()` 호출 후 screen 좌표에 직접 그림 |
| M-15 | STALKER-X/Camera는 `getCameraCoords` 메서드 없음 (hump와 다름) → silent fail | viewport 좌표 직접 계산 (camera scale=1, position (0,0)이면 world.y == screen.y) |
| M-16 | `addLine`은 `self.timer:after` 큐 → 라인 객체가 `self.lines`에 즉시 push 안 됨, 외부에서 라인 캡처하려면 폴링 또는 sync 함수 분리 | `addLineSync` 분리 함수로 sync push, 또는 `_captureNextLine(key)` 1ms 후 `self.lines[#self.lines]` 폴링 후크 |
| M-17 | GUI 메뉴의 셰이더+letterbox 룸에서 mouse hover 좌표 변환 불안정 (getLetterboxOffset + 셰이더 누적 효과). 키보드만 안정적 | GUI 메뉴는 키보드만 (↑↓ + Enter + 1~N hotkey). 마우스 hover/click은 셰이더/letterbox 파이프라인 영향으로 셀 동기화 깨질 수 있어 비추천 |
| M-18 | `scanlines_enabled=false` 사용자 토글이 셰이더 4-pass 한꺼번에 OFF해야 함 (스캔라인 + 검은 플리커 + RGB 라인) | `scanlines_enabled and not disable_expensive_shaders` 단일 게이트로 glitch/rgb_shift/displacement/rgb_shift/distort 모든 setShader 호출 묶기. OFF면 canvas를 그대로 다음 캔버스로 blit (`love.graphics.draw(canvas)`) — 캔버스 텅 빈 상태 방지 |
| M-19 | 모듈 패턴 룸 (device/terminal/help/options) 진입 후 콘솔 복귀 시 모듈 body + input 옵션 잔상 | `Room:destroy()`에서 `self.modules`/timer/lines/camera/input_line 모두 reset. EnhancedTimer:clear()로 콜백 큐 비우기 |
| M-20 | release 직전 단일 OS(macOS)만 `.app` 빌드 — Windows/Linux 사용자가 동일 게임 못 받음 | LÖVE 11.5 공식 zip/AppImage 사용 + `game.love` 끼워넣기 (아래 cross-platform 빌드 recipe) |
| M-21 | `gh release upload` 또는 `gh release create`가 200MB+ asset에서 `Bad Size` / `release not found` 에러 | `git tag` 먼저 push + `Expect:` 빈 헤더 + multipart `?name=` query (아래 200MB+ multipart 우회) |

## 모노리식 게임 4-pass 셰이더 우회 통합 recipe (M-7.6)

Room:draw()를 셰이더/캔버스 통째 우회 + drawGameCanvas 패턴으로 다시 쓸 때:

1. `:new()`에서 `self.render_canvas = love.graphics.newCanvas(gw, gh)` 추가 — 모든 캔버스 누락 체크 (M-7.5)
2. `:draw()` 시작에서 `setCanvas(self.render_canvas)` + `clear(0,0,0,1)`
3. `camera:attach(0, 0, gw, gh)` 안에서 직접 그리기 (셀렉션 highlight 포함)
4. `camera:detach()` 후 HUD / 버튼 / cursor는 viewport 좌표로
5. 끝에서 `setCanvas()` + `drawGameCanvas(self.render_canvas)` (M-7.7 viewport letterbox)
6. 모든 setColor 0..255 → 0..1 정규화 (M-0 후속)
7. 글로벌 컬러 테이블 (`default_color = {r,g,b}` 0..255) 은 setColor 직전 `/255` 변환

## M-13 신규 (v0.16)

세션 (2026-07-22, BYTEPATH 콘솔) 발견:

```lua
-- BEFORE (버그): 누적이 화면 밖
self.bytepath_main_y = self.line_y + 13*12
-- ⇒ line_y=264 + 156 = 420 (viewport 270 밖). cursor 안 보임.

-- AFTER (픽스): self.lines에서 실제 메뉴 라인 y 찾기
camera:detach()
if self.bytepath_main_active then
    local idx = self.bytepath_main_selection_index
    local target = self.bytepath_main_texts[idx]
    local found_y
    for _, line in ipairs(self.lines) do
        if line.text and line.text:find(target, 1, true)
           and line.text:find('type @' .. target, 1, true) then
            found_y = line.y; break
        end
    end
    if found_y then
        local width = self.bytepath_main_selection_widths[idx]
        local r, g, b = unpack(hp_color)
        local x_offset = self.font:getWidth('~ type ')
        local cx, cy = camera:getCameraCoords(0, found_y, 0, 0, gw, gh)
        love.graphics.setColor(r, g, b, 128/255)
        love.graphics.rectangle('fill', 8 + x_offset - 2 + cx, cy - 7, width + 4, self.font:getHeight())
    end
end
```

자세한 시간순 + 판별 신호: `references/bytepath-v0.2.x-console-menu-cursor-drift.md`.

## M-14 신규 (v0.17) — 셰이더 위 UI는 drawGameCanvas *후* 직접 그리기

multi-pass 셰이더 (glitch + rgb_shift + distort)를 유지하는 룸 — Console, Options, Achievements — 에서 `main_canvas` 안에 그려진 UI(cursor, highlight, 모달, hover 박스)는 셰이더 4-pass를 통과하면서 다음 효과를 누적 받는다:

| Shader | 효과 |
|---|---|
| `glitch.frag` | `position.x += (glitch_pixel.r*2.0 - 1.0)` — 글자/사각형 가로 분리 |
| `rgb_shift.frag` | R, G, B 채널 분리 → 반투명 색 saturate |
| `distort.frag` | 수평 fuzz + 스캔라인 → 사각형 가장자리 분산 |

→ cursor가 사라지거나 / 1픽셀로 압축되거나 / 다른 위치로 transform되어 사용자 눈에 안 보임.

**픽스**: cursor / highlight / 모달 같은 UI overlay는 **`drawGameCanvas(self.final_canvas)` 호출 후**, screen 좌표에 직접 그리기 — 셰이더 패스 우회:

```lua
love.graphics.setColor(1, 1, 1, 1)
love.graphics.setBlendMode('alpha', 'premultiplied')
drawGameCanvas(self.final_canvas)

-- 셰이더 우회: screen 좌표에 직접 그리기
love.graphics.setBlendMode('alpha')
if self.bytepath_main_active and self.bytepath_main_menu_lines then
    local key = self.bytepath_main_texts[idx]
    local menu_line = self.bytepath_main_menu_lines[key]
    if menu_line then
        local half_h = self.font:getHeight()
        local y_top = menu_line.y + math.floor(half_h/2) - half_h + 2
        love.graphics.setColor(r, g, b, 128/255)
        love.graphics.rectangle('fill', 8 + x_offset - 2, y_top, width + 4, half_h)
    end
end
love.graphics.setShader()
```

판별 신호: cursor / highlight는 main_canvas 안에서 그렸는데 화면에서 안 보임 → `setShader()` 후 같은 코드로 다시 그려서 비교. 보이면 셰이더 누적 효과 확정.

**M-14 확장 — Paused / scorescreen overlay도 동일 함정**

`main_canvas` 안에서 그려진 일시정지 박스(`Paused`)도 glitch 셰이더가 사각형을 흩뜨리고, rgb_shift가 흰색을 saturate, distort의 horizontal_fuzz가 가장자리를 분산시켜 → 사용자가 보기엔 텍스트를 알수 없게 큰 흰 박스로 변형.

```lua
-- ❌ 버그: main_canvas 안에서 Paused 그리면 셰이더 누적 효과로 텍스트/박스 다 흰박스로 변형
-- Stage:draw, line ~298 (main_canvas 내부)
if self.paused then self.paused_object:draw() end

-- ✅ 픽스: drawGameCanvas 호출 *후* + setShader() *전*에 그리기 — screen 좌표 직접
if not disable_expensive_shaders then
    love.graphics.setShader(shaders.distort)
    -- send uniforms
end
love.graphics.setColor(1, 1, 1, 1)
love.graphics.setBlendMode('alpha', 'premultiplied')
drawGameCanvas(self.final_canvas)

-- Paused/scorescreen overlays after the shader pipeline
if self.scorescreen then self.scorescreen_object:draw() end
if self.paused then self.paused_object:draw() end

love.graphics.setBlendMode('alpha')
love.graphics.setShader()
```

**Paused 오버레이 디자인 가이드** (BYTEPATH 룸):

1. **반투명 검정 오버레이** — `rectangle('fill', 0, 0, gw, gh, 0, 0, 0, 0.65)`. 게임 화면 흐리게 만들어 메뉴가 시각적으로 분리됨.
2. **Pill-shaped 큰 버튼** — 64x16 (Paused 원본) 너무 작아서 letterbox 시 큰 화면에서 잘 안 보임. **96x22** 정도가 viewport 480x270 + letterbox 적당. 셀 위치: viewport 중앙 (gh/2 - 11, 159 부근). `cx + btn_w/2 - self.font:getWidth(label)/2`로 가운데 정렬.
3. **2-state pill 색상**:
   - 선택됨: `skill_point_color/255` RGB + 검은 텍스트 (대비 명확)
   - 비선택: 어두운 회색 `34/255, 34/255, 38/255` + dim 흰 텍스트 `(222/255, ..., 0.45)`
4. **힌트 텍스트** — `<- ->  switch    enter  confirm` 같은 입력 가이드. `0.75 alpha`로 dim. 버튼 아래 8px 간격.
5. **첫 진입 시 resume=true 디폴트** — Enter 한 번에 pause 해제.

```lua
function Paused:draw()
    love.graphics.setFont(self.font)
    -- 전체 viewport에 dim
    love.graphics.setColor(0, 0, 0, 0.65)
    love.graphics.rectangle('fill', 0, 0, gw, gh)

    local btn_w, btn_h = 96, 22
    local gap = 12
    local total_w = btn_w * 2 + gap
    local x0 = math.floor((gw - total_w) / 2)
    local y0 = math.floor((gh - btn_h) / 2)

    -- RESUME pill
    if self.resume then
        love.graphics.setColor(skill_point_color[1]/255, skill_point_color[2]/255, skill_point_color[3]/255, 0.95)
    else
        love.graphics.setColor(34/255, 34/255, 38/255, 1)
    end
    love.graphics.rectangle('fill', x0, y0, btn_w, btn_h)
    if self.resume then love.graphics.setColor(0, 0, 0, 1)
    else love.graphics.setColor(222/255, 222/255, 222/255, 0.45) end
    love.graphics.print('RESUME', x0 + btn_w/2 - self.font:getWidth('RESUME')/2,
        y0 + math.floor((btn_h - self.font:getHeight())/2))

    -- CONSOLE pill (cx = x0 + btn_w + gap) 동일한 패턴
    -- ...

    -- 힌트
    love.graphics.setColor(1, 1, 1, 0.75)
    local hint = '<- ->  switch    enter  confirm'
    love.graphics.print(hint, math.floor((gw - self.font:getWidth(hint)) / 2), y0 + btn_h + 8)
end
```

판별 신호: 사용자가 "스캔라인 제거는 확인했는데 RGB 라인 / 검은 플리커도 같이 꺼달라" 요청 → M-18 패턴 적용.

## M-19 신규 — `Console:destroy` 비어있음 → 모듈/timer/lines 잔상 (v0.20)

모듈 패턴(`self.modules = {}`에 EscapeModule / HelpModule / DeviceModule / ShutdownModule / ClearModule push) 룸에서 `:destroy()`가 빈 함수면 다음 잔상:

1. **모듈 인스턴스 잔존** — `self.modules` GC 안 됨, 다음 Console 인스턴스의 input 흐름 끊김.
2. **timer 큐 잔존** — `self.timer:after(...)` 콜백이 큐에 살아 다음 Console 인스턴스에서 발동 → `self.lines`에 ghost 라인 push (특히 DeviceModule은 5초간 여러 line push → 화면 절반 덮음).
3. **self.lines 잔존** — 모듈이 push한 line 안 비워져 다음 룸 복귀 후 그대로 그려짐.
4. **카메라 누수** — 모듈이 `camera:lookAt(...)`, `camera.smoother` 바꾸면 destroy에서 리셋 안 됨 → 다음 룸 카메라 시작 위치 이상 (SkillTree smoother leak).

### 픽스: `Room:destroy()` 보장은 룸 자체가 책임진다

`main.lua` `gotoRoom`은 `if current_room.destroy then current_room.destroy() end`만 호출 (cleanup 위임). 그러므로 **모든 `:destroy()`는 다음 4종 cleanup**:

```lua
function Console:destroy()
    self:_hideMainMenu()
    self.main_menu = nil

    if self.modules then
        for _, mod in ipairs(self.modules) do
            if mod.destroy then mod:destroy() end
        end
        self.modules = {}
    end

    if self.timer and self.timer.clear then self.timer:clear() end

    if camera and camera.lookAt then camera:lookAt(gw/2, gh/2) end
    if camera then camera.scale = 1 end
    if camera.smoother then
        camera.smoother = Camera.smooth.none and Camera.smooth.none() or nil
    end

    self.lines = {}
    self.line_y = 0
    self.input_line = nil
    self.scrolling_y = nil
end
```

`EnhancedTimer:clear()`은 `self.timer:clear()` 위임 — `clear()` 없으면 skip.

### 판별 신호

사용자가 특정 모듈 (device / terminal / help) 선택 후 콘솔로 `Esc` 복귀 시:
- 모듈 body text + input 옵션 라인 잔상
- 등록한 timer 콜백이 0.5~5초간 push되어 흐름
- 다음 frame의 cursor/메뉴 입력 어긋남

→ `Room:destroy()`가 cleanup 4종 안 함을 의심.

### user-facing 패턴

모듈 패턴을 가진 룸은 **반드시**:destroy에서 self에 속한 모든 인터널 상태 (timer, lines, modules, input line, 카메라 등) 초기화. 룸 작성 보일러플레이트 일부.

자세한 시간순: `references/bytepath-v0.2.x-console-module-ghost-residue.md`.

## M-18 신규 — scanlines 토글이 모든 셰이더 4-pass를 한꺼번에 OFF

`scanlines_enabled = false` 사용자 토글이 의도한 효과는 단순히 **스캔라인 끄기**이지만, BYTEPATH는 셰이더 4-pass 파이프라인 (glitch + rgb_shift + distortion + rgb + distort)이 묶여 있어 다음 누적 효과가 동시에 사라져야 함:

- 스캔라인 (distort.frag uniform `scanlines`)
- 검은색 플리커 (glitch.frag + GlitchDisplacement GameObject의 큰 흰 박스 흩뜨림)
- RGB 라인 (rgb_shift.frag 또는 distort의 `rgb_offset`)

각 셰이더 호출에 별도의 게이트를 두면 일관성 깨짐. **단일 게이트 변수**로 묶음:

```lua
-- ❌ 4개의 독립 게이트 → 일관성 깨질 위험, 조건 추가 누락 위험
if disable_expensive_shaders then ... end
if scanlines_enabled then shaders.distort:send('scanlines', 1) else ... end
if scanlines_enabled then shaders.glitch ... else ... end
...

-- ✅ 단일 게이트로 묶음 (모든 4-pass 일괄 OFF)
local use_shaders = scanlines_enabled and not disable_expensive_shaders

-- Pass 1: main_canvas → temp_canvas (rgb_shift + displacement)
if use_shaders then
    -- rgb_shift 셰이더 패스
    love.graphics.setShader(shaders.rgb_shift)
    -- ...
    -- displacement 셰이더 패스
    love.graphics.setShader(shaders.displacement)
    -- ...
else
    -- Effects OFF: 캔버스를 다음 캔버스로 blit (캔버스 텅 빈 상태 방지)
    love.graphics.draw(self.rgb_shift_canvas, 0, 0, 0, 1, 1)
    love.graphics.draw(self.main_canvas, 0, 0, 0, 1, 1)
end

-- Pass 2~3: glitch, rgb_shift 동일 패턴
if use_shaders then 셰이더 패스 else blit end

-- Pass 4: distort (scanlines uniform 포함)
if use_shaders then
    love.graphics.setShader(shaders.distort)
    shaders.distort:send('scanlines', scanlines_enabled and 1 or 0)
end
```

**OFF 시 blit의 의미**: 셰이더 패스를 통째 스킵해도 캔버스 객체는 자기 데이터를 유지. `love.graphics.draw(canvas, 0, 0, 0, 1, 1)`로 다음 캔버스로 그대로 복사. **캔버스에 빈 데이터가 들어가 drawGameCanvas가 검은 사각형을 출력하는 버그를 방지**.

**저장**: `scanlines_enabled`를 `permanent_save`에 추가 (다른 display 옵션처럼 save/load 사이클). `Options` 메뉴에 toggle row 추가 (`kind = 'toggle', key = 'scanlines'`).

**옵션 메뉴 toggle row 추가 패턴**:
```lua
self.rows = {
    {kind = 'header',   text = '~ OPTIONS'},
    {kind = 'mode',     key = 'display_mode', label = 'display mode'},
    {kind = 'scale',    key = 'window_scale', label = 'window size'},
    {kind = 'monitor',  key = 'display',      label = 'monitor'},
    {kind = 'toggle',   key = 'scanlines',    label = 'scanlines'},   -- ← 토글
    {kind = 'action',   action = 'back',       label = '~ back to console'},
}
```

`Options:update`의 left/right 분기 + `Options:_step` (마우스 left/right 버튼)에 `kind == 'toggle'` 처리. 토글 시 `save()` 자동 호출. `Options:draw`의 value 결정에 `scanlines_enabled and 'on' or 'off'` 추가.

판별 신호: 사용자가 "스캔라인 제거는 확인했는데 RGB 라인 / 검은 플리커도 같이 꺼달라" 요청 → M-18 패턴 적용.

## M-17 신규 — 셰이더+letterbox 룸 GUI 메뉴: 키보드만 신뢰 + 컬럼 분할 layout

BYTEPATH Console 룸 (다중 셰이더 패스 + drawGameCanvas letterbox)에서 마우스-기반 GUI 메뉴는 다음 누적 효과를 받아 부정확:

1. 셰이더 glitch/rgb_shift/distort — 사각형/텍스트 분산 (M-14)
2. `getLetterboxOffset` 윈도우→viewport 매핑 — 셰이더로 흐려진 화면에서 호버 좌표가 셰이더 누적 효과로 어긋남
3. STALKER-X Camera 없음 또는 다른 lib 사용 시 `getCameraCoords` 안 됨 (M-15)

**결론**: GUI 메뉴는 **키보드만** 구현 (↑↓ + Enter + 1~N hotkey). 사용자도 이 컨벤션을 선호 (mouse hover 동기화 불안정 → 키보드만으로 fallback 요청).

### GUI 메뉴 컬럼 분할 layout (v0.18 추가)

셰이더+letterbox 룸의 GUI 메뉴는 **컬럼 너비를 미리 박아** 넣지 않으면 라벨/설명/hotkey가 서로 겹치고 셀 밖으로 삐져나옴. 다음 명세대로 그릴 것:

| 컬럼 | 너비 | x 좌표 (셀 안에서) | 내용 |
|------|------|---------------------|------|
| accent bar | 3 px | `cell_x - 3` (셀 *바깥* 좌측, 선택 시만) | 노란 강조 (selected) |
| index 배지 | 16 px | `cell_x + index_w - idx_text_w - 4` | `"01"`~`"08"` |
| separator | 1 px | `cell_x + index_w` | 세로 구분선 |
| LABEL | 80 px (고정) | `cell_x + index_w + 6` | 라벨 (너무 길면 truncate + `..`) |
| DESCRIPTION | 잔여 (`desc_max_w`) | `label_x + label_w + 12` | 설명 (truncate) |
| HOTKEY hint | 22 px | `cell_x + cell_w - hotkey_w - 4` | `[1]`~`[N]` |
| chevron | 5 px | `cell_x + cell_w + 4` (셀 *바깥* 우측, 선택 시만) | `›` |

```
[ accent┃ 01 │ LABEL           description text here        [N] ›
```

**셀 너비 권장**: `gw - 96` (BYTEPATH viewport 480 → 메뉴 폭 384). 이 너비에서 label 80 + description + hotkey 22 다 들어가서 글자 겹침 X. `cell_h = 22px`, `spacing = 4px`.

**Truncate 헬퍼** (글자가 컬럼보다 길 때 `..`로 줄임):
```lua
if self.font:getWidth(label) > label_w - 8 then
    while self.font:getWidth(label .. '..') > label_w - 8 and #label > 1 do
        label = label:sub(1, -2)
    end
    label = label .. '..'
end
```
같은 패턴을 DESCRIPTION에도 적용 (`desc_max_w` 기준).

**3-state 색상** — 같은 row가 selected / hovered / idle 3가지 상태:
```lua
if is_selected then
    cell_fill = {skill_point_color[1]/255, ..., 0.30}   -- 반투명 노란
    text_color = skill_point_color
elseif is_hovered then
    cell_fill = {70/255, 70/255, 80/255, 1}             -- 중간 회색
    text_color = {222/255, 222/255, 222/255, 1}
else
    cell_fill = {22/255, 22/255, 28/255, 1}              -- 어두운 회색
    text_color = default_color (0..1 정규화)
end
```
모든 색은 `0..1` 정규화. setColor 뒤/255 잊으면 셰이더 saturate.

**Mouse 동기화가 안 되겠다고 판단되면 사용자가 명시적으로 "키보드만" 요청 →** `m.hovered_index` 검사 + `input:pressed('left_click')` 블록 통째 삭제. update에 keyboard-only 입력 핸들러만 남김:
```lua
if self.main_menu and self.main_menu.visible then
    if input:pressed('up') then m.selection_index = m.selection_index - 1; if m.selection_index < 1 then m.selection_index = n end; playMenuSwitch() end
    if input:pressed('down') then m.selection_index = m.selection_index + 1; if m.selection_index > n then m.selection_index = 1 end; playMenuSwitch() end
    if input:pressed('1') then self:_runMainMenu(1) end
    -- ... etc for 2..N
    if input:pressed('return') then self:_runMainMenu(m.selection_index) end
end
```

판별 + 시간순 사례: `references/bytepath-v0.2.x-gui-menu-column-layout.md` (컬럼 분할 layout 명세 포함), `references/bytepath-v0.2.x-console-gui-menu-refactor.md`, `references/bytepath-v0.2.x-paused-overlay-smeared-by-shader.md` (Paused 일시정지 박스가 셰이더 패스의 누적 효과를 받아 큰 흰색으로 saturate되는 디버깅 시간순).

```lua
-- ❌ 안 됨: 셰이더+letterbox 환경에서 마우스 hover 좌표 동기화
local ox, oy, s = getLetterboxOffset()
local mx, my = love.mouse.getPosition()
local gx, gy = (mx - ox) / s, (my - oy) / s
for i = 1, n do
    local cell_x, cell_y = self:_mainMenuCell(i)
    if gx >= cell_x and gx <= cell_x + m.w then
        m.selection_index = i  -- 셰이더 누적 효과로 화면상 위치 어긋남
    end
end

-- ✅ 안전: 키보드만
if input:pressed('up') then m.selection_index = m.selection_index - 1; if m.selection_index < 1 then m.selection_index = n end; playMenuSwitch() end
if input:pressed('down') then m.selection_index = m.selection_index + 1; if m.selection_index > n then m.selection_index = 1 end; playMenuSwitch() end
if input:pressed('return') then self:_runMainMenu(m.selection_index) end
if input:pressed('1') then self:_runMainMenu(1) end
-- ... etc for 2..N
```

판별 신호: 콘솔 룸 같은 셰이더+letterbox 환경에서 마우스 hover로 메뉴 선택 동기화가 깨짐 → 키보드 전용으로 단순화.

판별 + 시간순 사례: `references/bytepath-v0.2.x-gui-menu-column-layout.md` (컬럼 분할 layout 명세 포함), `references/bytepath-v0.2.x-console-gui-menu-refactor.md`, `references/bytepath-v0.2.x-paused-overlay-smeared-by-shader.md` (Paused 일시정지 박스가 셰이더 패스의 누적 효과를 받아 큰 흰색으로 saturate되는 디버깅 시간순).

## M-15 — STALKER-X Camera 메소드 nil 함정

BYTEPATH는 `Camera = require 'libraries/STALKER-X/Camera'` (hump 아님). STALKER-X/Camera는 `getCameraCoords`, `getWorldCoords` 메서드를 정의하지 않음 (hump와 다른 API). 호출 시 `nil` 반환 → silent fail.

```lua
-- ❌ silent fail (camera:getCameraCoords는 nil)
local cx, cy = camera:getCameraCoords(menu_line.x, menu_line.y, 0, 0, gw, gh)
if cy >= -16 and cy <= gh + 16 then ... end  -- cy=nil → 에러 없이 통과 못 함

-- ✅ 직접 계산 (camera scale=1, position (0,0)이면 world.y == screen.y)
local sx = menu_line.y + math.floor(self.font:getHeight()/2)
local cx = 8 + self.font:getWidth('~ type ')  -- 메뉴 텍스트 prefix 너비
```

다른 카메라 라이브러리 끼워 쓸 때(`hump`, `STALKER-X`, `Camera9`)는 항상 `getCameraCoords` 존재 여부 확인. 없으면 world 좌표 == screen 좌표 가정으로 직접 계산.

## L4 — 2회 이상 가설 빗나가면 순차 진단 (사용자 교정)

사용자 1차 보고 "1번 cursor 위치가 한 칸씩 밀려있다" → 가설 1 (텍스트 매칭) 적용 → 실패 → 가설 2 (screen 좌표 직접) → 실패 → 가설 3 (camera:getCameraCoords) → 실패 → 가설 4 (메뉴 line 객체 추적) → 실패 → 가설 5 (셰이더 누적) → ✅

**원칙** (5단계):
1. **증상의 객관적 사실 정리** — 무엇이 보이고, 어디에, 어떻게 다른가
2. **다른 룸과 비교** — Classes/SkillTree는 정상, Console만 비정상 → 차이점 = 원인 후보
3. **진짜 차이점 = 원인** — 셰이더 유지 vs 우회, 카메라 메서드 API 등
4. **단일 픽스 + 검증**
5. **2~3번 실패 후 사용자 멈추고 순차 진단 재요청 받기**

함정: 가설을 5번 연속 적용하면 **각 픽스가 새로운 가설의 진짜 진단을 가림** — 셰이더 우회 픽스는 cursor 위치 버그의 진짜 원인 (셰이더 누적)을 가렸을 수 있음. 픽스 적용 후 "그래도 안 됨"이면 **이전 픽스의 효과를 의심**해서 정상값과 비교.

## 검증 워크플로 (v0.7+ 확장)

1. **부팅 검증과 렌더링 검증을 분리** — `love .` 프로세스 생존 ≠ draw 호출 + 실제 픽셀 정상
2. **첫 화면 draw 로그** — `io.stderr:write('[DBG] draw ' .. tostring(current_room) .. '\\n')` 1줄 추가
3. **최소 화면 프로브** — Room:draw의 첫 줄을 `love.graphics.print('[draw OK]', 8, 8)`로 교체 → 텍스트 보이면 셰이더/Canvas 문제, 안 보이면 draw 자체 미호출 (M-7.6 진단)
4. **drawGameCanvas 호출 검증** — viewport를 윈도우에 fit시키는 룸이면 반드시 끝에서 호출. 누락 시 사용자가 윈도우 좌상단 일부만 보임 (M-7.7)
5. **GUI 검증 필수** — 헤드리스 stderr 비어있어도 셰이더 silent fail / viewport letterbox 누락 / fonts.kr_8 미사용 (v0.24) 절대 못 잡음

## 검증 신호표 (v0.24 확장)

| 증상 | 원인 | 해결 |
|------|------|------|
| stderr 비어있는데 검은 화면 | Canvas+Shader silent fail (M-4 + M-6) | M-7.6 통합 recipe |
| stderr 비어있는데 흰색 saturate | 셰이더 신택스 + 0..255 색상 (M-0) | .frag modern GLSL + setColor /255 |
| 룸 진입 시 윈도우 좌상단에 viewport만, 검정 여백 | M-7.7 viewport letterbox 누락 | drawGameCanvas(self.render_canvas) |
| 룸 진입 시 검은 화면 (draw 호출은 됨) | self.canvas 누락 (M-7.5) | :new() 모든 main_canvas 확인 |
| Classes 등 룸 진입 시 글자/배경 흰색 saturate | M-7.6 (setColor 0..255 + 셰이더) | M-7.6 recipe + M-0 setColor /255 |
| 노드 선택 강조가 흐림 | M-10 단일 색 | 3-state Line + Node draw 후 fill+thick outline |
| Enter 키가 마우스 후 무효 | M-11 race | SkillTree:update single-source kb_enter |
| 트리가 화면 비율 안 맞음 | M-12 viewport fit 실패 | median + scale=2.0 + window_scale 자동 |
| **메뉴 cursor가 한 칸씩 밀려서 안 맞음** | **M-13 누적 line_y** | **self.lines에서 target 라인 찾기** |
| setCanvas(nil) 호출인데 stderr 비어있음 | M-7.5 (canvas 누락) | requireFiles 전 캔버스 체크 |
| multi-pass 셰이더 룸(Console)에서 cursor / highlight 안 보임 | M-14 셰이더 누적 효과 | `drawGameCanvas()` 호출 후 screen 좌표에 직접 그리기 |
| `camera:getCameraCoords(x, y, ...)` 호출이 silent fail | M-15 STALKER-X는 이 메서드 없음 | viewport 좌표 직접 계산 (world.y == screen.y when scale=1) |
| 5번 가설 다 빗나간 후 "순차적으로 생각해봐" | L4 사용자가 가설 중단 요청 | 증상 → 다른 룸 비교 → 차이점 = 원인 → 단일 픽스 |
| `addLine` 호출 직후 `self.lines[N]`가 nil | M-16 timer 큐 (외부 즉시 캡처 불가) | `addLineSync` 또는 `_captureNextLine` 폴링 후크 |
| GUI 메뉴 mouse hover가 셀 동기화 깨짐 (셰이더+letterbox 룸) | M-17 셰이더/letterbox 좌표 누적 부정확 | 키보드만 (↑↓/Enter/1~N) — 마우스 hover/click 비추천 |
| 스캔라인 off인데 검은 플리커/RGB 라인이 그대로 | M-18 셰이더 4-pass 스캔라인만 끄고 glitch/rgb_shift는 활성 | 단일 게이트 (`scanlines_enabled and not disable_expensive_shaders`) 로 모든 셰이더 호출 묶음, OFF 시 canvas blit |
| 일시정지 (Esc) 화면 텍스트가 큰 흰 박스로 가려짐 | M-14 확장: 셰이더 패스가 Paused 박스까지 누적 효과 | Paused overlay도 `drawGameCanvas()` 호출 *후* + setShader() *전*에 그리기. 반투명 dim + pill button 디자인 |
| Console:bytepathMain에서 cursor 안 보임 / 위치 어긋남 | M-13/M-14/M-16 셰이더 누적 + line 캡처 실패 | GUI 메뉴로 전면 재작성 (M-17) — `main_menu` 상태 + `_showMainMenu` / `_runMainMenu` / `_drawMainMenu` 분리 |
| 모듈 선택 후 콘솔 복귀 시 모듈 body + input 옵션 잔상 | M-19 `:destroy()` 빈 함수 | `self.modules`/timer/lines/camera/input_line 모두 reset |
| **한글 라벨이 □ 또는 ?로 표시 (v0.24)** | **fonts.kr_8 부트스트랩만 하고 draw에서 안 씀** | **`globals.lua`에 `has_cjk` + `printT` + `textWidth` 헬퍼 추가 후 draw 단계 `love.graphics.print` → `printT(self.font, ...)` 일괄 변환. ConsoleLine character-by-character 렌더는 language 버킷에 `'kr'` 추가 + kr_font:getWidth/setFont** |
| **fonts.kr_8은 로드됐는데 일부 모듈 draw에서만 □ (v0.24)** | **ConsoleLine 같이 character 단위 렌더하는 객체가 language 버킷 'normal'/'arch' 만 가짐** | **`ConsoleLine:setCharacters`에서 `is_cjk = has_cjk(c)` 검사 → `char_lang = 'kr'`로 분류, `ConsoleLine:draw`에서 `language == 'kr'`이면 `setFont(kr_font)`**. `kr_font = fonts.kr_8 or normal_font` fallback |
| **한글 T() 가 깨짐 없이 표시되지만 알아보기 어려움 (v0.25)** | **fonts.kr_8 (8px 픽셀) 너무 작음** | **fonts.kr_16 (16px 데이터) 로드 + `love.graphics.print` sx/sy=0.75 표시 → 화면 ~12px + 글리프 정밀**. `kr_height() = fonts.kr_16:getHeight() * 0.75` 헬퍼 |
| **한글 14px (kr_14 full) 한 줄이 viewport 밖으로 잘림 (v0.25)** | **viewport 270 안에 한글 한 줄 안 들어감** | **fonts.kr_16 + 0.75x 스케일** (~12px 화면) + `addLine` stride 통일 14px + `Options` `row_h = 14` + 선택 highlight h 9→11 |
| **ConsoleLine 한/영 혼합 라인에서 한글 글리프 상단 클리핑 (v0.25)** | **단순 `font:getHeight()` baseline 잡으면 한글 ascent 위로 잘림** | **`kr_height()` baseline anchor** + `text_y_offset = max(normal, arch, kr_rendered)` + `printT` 좌표에 `baseline - (kr and kr_height() or char_font:getHeight())` |
| **한글 라벨이 ~43도 회전 / 기울어져 표시 (v0.26 M-23)** | **printT args 인덱싱 버그 — `table.insert(args, 0.75); table.insert(args, 0.75)` 호출에서 args가 4개가 되어 `print(text, x, y, 0.75, 0.75)` 로 해석 → r=0.75 (=43도 회전)** | **printT 시그니처를 `(font, text, x, y, rotation)` 5 인자로 단순화 + sx/sy 인자 자체 제거**. fonts.kr_16 네이티브 표시 |
| **한글 라인이 viewport 위로 잘림 (v0.26 M-24)** | **`baseline_y = kr_base - kr_font:getHeight()` 식으로 self.y 위로 음수 offset** | **각 글리프가 `self.y + font_baseline(font)` 직접 사용**. 폰트 박스 top = self.y, baseline은 폰트 박스 안 자연 위치 (75%) |
| **한글 12px 폰트 후퇴 후 화면 엉망 (v0.26)** | kr_12 + kr_height() = 12 → stride 14 mismatch → 글리프 겹침 | **fonts.kr_16 + line_y stride 18 + per-glyph baseline** (v0.26 권장 진입점) |
| **HelpModule highlight 박스 위치 어긋남 (v0.26)** | **stride 14 → 18 변경 시 highlight 박스 y 좌표도 같이 안 바꿈** | **stride 동기화 체크리스트 6군데 한꺼번에 수정** 또는 `local LINE_H = 18` 상수로 참조 |
| **HelpModule highlight 박스 위치 어긋남 (한글 라인 위, v0.25)** | **`selection_index * 12` 하드코딩**, addLine stride가 14로 바뀌면서 어긋남 | **`selection_index * 14`** 로 stride와 동기화 + `rectangle fill height` 도 stride와 일치 |
| **DeviceModule stat 텍스트가 다각형 아래 viewport 밖 (v0.25)** | **stat 위치 `self.y + self.h - 24` 가 viewport 초과** | **stat 풀을 다각형 위쪽으로 이동** — `desc_y = self.y - self.h/2 - 14 - line_h * n` |
| **위임이 모듈 4~5개만 끝내고 끊김 (v0.24)** | **풀 풀스택 위임 600s 타임아웃** | **위임 범위 = 메뉴 + 모듈 4~6개 + 검증. 9개 모듈은 두 위임 OR 위임 + 직접 마무리** |
| **en.lua와 ko.lua 키 이름 불일치 (v0.24)** | **dict 위임 시 두 파일을 따로 작성** | **ko.lua 먼저 작성 → en.lua는 같은 키 dict에 영문 값 채움. dict 작성 후 `diff <(lua -e 'for k in pairs(dofile(...)) do print(k) end')` 검증** |
| **git push에서 50MB+ 폰트 경고 (v0.24)** | **`.ttc` 50MB+ git 추적 부적합** | **`.gitignore`에 `resources/fonts/*.ttc` 추가 + Nanum Gothic 같은 작은 폰트만 추적 + release asset으로 분리** |
| **`Syntax error: ')' expected near '&'` 부팅 즉시 크래시 (v0.28 M-29)** | Love 11.5 LuaJIT 5.1 환경 + native `&` 비트 연산자 | **모든 비트 연산을 `bit.band` / `bit.lshift` / `bit.rshift` / `bit.bor` / `bit.bxor` 로 교체** (Lua 5.2+ 비트 연산자 사용 금지) |
| **`UTF-8 decoding error: Not enough space` 콘솔 메뉴 진입 시 크래시 (v0.28 M-30)** | textWidth의 trailing continuation bytes cleanup 로직이 정상 한글 텍스트도 잘라냄 | **textWidth 자체 cleanup 제거 — caller 책임 (shorten_utf8_last로 truncate 시 UTF-8 안전 처리)** |
| **`Not enough space` fonts.kr_16 로드 실패 환경 (v0.28 M-31)** | fonts.kr_16 nil + Anonymous_8:getWidth('한글') 호출 | **fonts.kr_16 없을 때 caller font 호출 안하고 0 반환**. main.lua의 kr_*_N 로드 검증 + fallback 체인 |
| **`디스플레이..` `창 크기:..` 등 모든 라벨이 .. 으로 잘림 (v0.28 M-32)** | 라벨 컬럼 88px 너무 좁음 + `..` suffix 가독성 떨어짐 | **컬럼 112~128px로 키움 + '..' suffix 안 붙임 (M-32)** |
| **한글 라벨이 셀 밖으로 삐져남 (v0.28 M-33)** | 컬럼 폭 < 한글 폭 | **컬럼 112~128px 권장** (16:9 wider viewport는 비율 적용) |
| **fonts.kr_16 없는데 한글 모듈 진입 시 `Not enough space` 크래시 (v0.28 M-31)** | macOS Sonoma+에서 .ttc 경로 변경 / Linux에 fonts-nanum 미설치 | **main.lua의 kr_candidates에 AppleSDGothicNeo 우선 + AppleGothic fallback + 시스템 폰트 자동 감지** |
| release 직전 단일 OS(macOS)만 `.app` 빌드 | M-20 cross-platform 빌드 recipe (아래) |
| `gh release upload` 또는 `gh release create`가 200MB+ asset에서 `Bad Size` / `release not found` | M-21 GitHub release asset multipart 우회 (아래) |

## M-20 신규 — cross-platform release 빌드 (macOS + Windows + Linux) (v0.21)

LÖVE 11.5 게임을 3개 OS에 동시 배포하는 검증된 recipe (BYTEPATH v0.2.1 사례).

**공통 base**: 게임 소스(`main.lua`, `rooms/`, `objects/`, `resources/`) + `bytepath-ex-0.2.1.love` (zip으로 묶은 것). love 바이너리는 OS별로 다른 묶음 사용.

### macOS `.app` + `.zip`

`brew install --cask love`로 설치된 `love.app` 통째 복사 + `game.love`만 교체 + Info.plist 편집:

```bash
unzip -q bytepath-ex-macos-0.2.0.zip  # 기존 .app 추출
cp bytepath-ex-0.2.1.love bytepath-ex.app/Contents/Resources/game.love
ditto -c -k --sequesterRsrc --keepParent bytepath-ex.app bytepath-ex-macos-0.2.1.zip
```

`.love` 파일은 `.gitignore`에 `bytepath-ex-*.love`로 등록 (release 자산이지 소스 아님).

### Windows `.zip` (LÖVE 공식 `love-11.5-win64.zip` 활용)

공식 release URL: `https://github.com/love2d/love/releases/download/11.5/love-11.5-win64.zip` (~4.5MB). 압축 해제 → `love-11.5-win64/` 폴더명을 `bytepath-ex-0.2.1-win64`로 변경 → `game.love` 추가 → 재압축.

```bash
mkdir win-stage && unzip -q love-11.5-win64.zip -d win-stage
mv win-stage/love-11.5-win64 win-stage/bytepath-ex-0.2.1-win64
cp bytepath-ex-0.2.1.love win-stage/bytepath-ex-0.2.1-win64/game.love
cd win-stage && zip -qr ../bytepath-ex-windows-0.2.1.zip bytepath-ex-0.2.1-win64
```

결과 zip: ~225MB (love.dll + game.love 모두 포함). `lovec.exe`(CLI 디버깅용)도 함께 들어있어 `readme.txt`에 안내 가능.

### Linux `.tar.gz` (LÖVE 공식 `love-11.5-x86_64.AppImage` 활용)

공식 release URL: `https://github.com/love2d/love/releases/download/11.5/love-11.5-x86_64.AppImage` (~5MB). FUSE-mount되지만, **사용자에게 game.love를 같은 폴더에 두고 `./AppImage game.love`로 직접 실행**도 가능 (FUSE 불필요).

```bash
mkdir linux-stage
cp love-11.5-x86_64.AppImage linux-stage/bytepath-ex-0.2.1-x86_64.AppImage
cp bytepath-ex-0.2.1.love linux-stage/game.love
cat > linux-stage/README.txt <<'EOF'
chmod +x bytepath-ex-0.2.1-x86_64.AppImage
./bytepath-ex-0.2.1-x86_64.AppImage game.love
# FUSE 미설치 시: --appimage-extract 후 ./squashfs-root/AppRun game.love
EOF
cd linux-stage && tar czf ../bytepath-ex-linux-0.2.1.tar.gz *
```


## M-40: 도움말 화면부터 고해상도 한글 렌더링 검증

480×270 콘솔에서 한글이 거칠면 전역 폰트 파이프라인을 바꾸지 말고 `ConsoleLine`별 `kr_font/kr_scale` 재정의를 추가해 **도움말 한 화면만 먼저** `kr_24 × 0.5`로 실험한다. 최종 표시 크기는 약 12px로 유지하되 폭·높이·기준선·선택/글리치 배경에 모두 배율을 적용한다. 헤드리스 무오류는 가독성 증명이 아니므로 사용자 GUI 승인 뒤에만 디바이스와 다른 터미널 화면으로 확장한다.

구현 상세와 회귀 함정: `references/bytepath-help-highres-korean-rendering.md`
LÖVE 엔진 단 동작의 1차 근거(글리프 래스터화·캐싱·dpiscale·setFilter min/mag 의미)는 `references/cjk-small-font-readability-research.md`.
love2d.org Cloudflare 챌린지 우회 패턴과 LÖVE 11.5/12.0 source raw URL은 `references/love2d-wiki-archive-lookup.md`.


### Checksum 표기

GitHub가 release page에 표시하는 digest는 **사용자가 업로드한 파일의 digest**. `zip`/`tar.gz` 인코딩 단계가 다르면 local `sha256sum` 값과 다를 수 있음. **release 업로드 직후 release의 `assets[].digest`를 GET으로 다시 읽어** notes의 표 업데이트 → PATCH release. 예: `e7a63c8bc2e234500a0b6520fdc87cd32575fbeb5ff1e11303a1f93f29dceaa0` (love), `e0683b6e54d049818d3fb8b291170134de747b8a7e99d692e598e1bfc07a4373` (mac zip), `5b76833cf6f2abce25867a0c0a2c3abf84b05d6d03d62bfab6ce29c9a23d2f53` (windows zip), `abcc4705d34c797b0fe2f97cd32575fbeb5ff1e11303a1f93f29dceaa0` (linux tar.gz).

판별 신호: 단일 OS에서만 release 빌드 → 사용자가 다른 OS 사용자 → 크로스플랫폼 recipe 필요.

## M-21 신규 — GitHub release asset 200MB+ multipart 우회 (v0.21)

`gh release create` / `gh release upload`가 200MB+ 파일에서 다음 에러를 자주 뱉음:

| 에러 | 원인 | 우회 |
|------|------|------|
| `Multipart form data required` | octet-stream 업로드 시 | `-F "file=@path"`로 multipart |
| `Bad Size` | curl `Content-Length` mismatch (multipart boundary가 사이즈 변경) | `-H "Expect:"` 빈 헤더 (100-continue handshake skip) + `?name=...` query string으로 name 명시 |
| `Invalid name for request` | `name` form field + `?name=` query 동시 사용 | 한 곳에만 명시 (form 또는 query) |
| `release not found` | tag가 GitHub에 아직 push 안 됨 | `git tag v0.2.1 && git push origin v0.2.1` 먼저 |
| `gh auth refresh -h github.com -s workflow` 60s timeout | 브라우저 인증 필요 | token 직접 사용 (`gh auth token`) |

**작동 recipe** (Windows zip 237MB 업로드 88초):

```bash
# 1. Tag push (release not found 회피)
git tag v0.2.1 && git push origin v0.2.1

# 2. gh CLI가 release 못 찾으면 직접 curl
TOKEN=$(gh auth token)
RESP=$(curl -s -X POST \\
    -H "Accept: application/vnd.github+json" \\
    -H "Authorization: token $TOKEN" \\
    -d "{\\"tag_name\\":\\"v0.2.1\\",\\"name\\":\\"v0.2.1 — ...\\",\\"body\\":$NOTES_BODY}" \\
    https://api.github.com/repos/owner/repo/releases)
UPLOAD_URL=$(echo "$RESP" | python3 -c 'import json,sys; print(json.load(sys.stdin)["upload_url"])')
RELEASE_ID=$(echo "$RESP" | python3 -c 'import json,sys; print(json.load(sys.stdin)["id"])')

# 3. Asset 업로드 (multipart, name in query, Expect 비움)
curl -s --max-time 1800 -X POST \\
    -H "Authorization: token $TOKEN" \\
    -H "Expect:" \\
    -F "file=@bytepath-ex-0.2.1.zip" \\
    "${UPLOAD_URL}?name=bytepath-ex-0.2.1.zip" \\
    -o /tmp/upload_resp.json
# 응답에서 digest 추출:
DIGEST=$(python3 -c 'import json; print(json.load(open("/tmp/upload_resp.json"))["digest"])')

# 4. Notes에 digest 갱신 (Bad Size 후 인코딩이 다를 수 있어 재계산)
TOKEN=$(gh auth token)
NOTES_BODY=$(python3 -c 'import json; print(json.dumps(open("/tmp/release-notes.md").read()))')
curl -s -X PATCH \\
    -H "Authorization: token $TOKEN" \\
    -H "Accept: application/vnd.github+json" \\
    -d "{\\"body\\":$NOTES_BODY}" \\
    https://api.github.com/repos/owner/repo/releases/$RELEASE_ID
```

**판별 신호**: `gh release create`가 "release not found" → tag가 GitHub에 없음. `gh auth refresh` timeout → token scope 충분 (`'repo', 'workflow'`), gh CLI 자체 한계. **직접 curl + GitHub API**가 우회.

**업로드 중 background 처리**: 200MB+ multipart는 60~180초 걸림. **timeout 1800s** + **백그라운드 spawn** + **poll** 패턴. main thread 60s timeout 회피.

판별 신호: `gh release upload <file>` 또는 `gh release create --target ...` 직후 "release not found" / "workflow scope required" → `git tag` 누락 또는 token scope. 이때 직접 API path.
