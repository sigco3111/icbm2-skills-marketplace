---
name: lua-love-game-fork
description: "LÖVE 11.x (Lua 5.1) 게임 fork + 한국어화 + Steam shim + macOS M4 Retina/DPI/state.txt 풀스크린 디버깅 워크플로우. SNKRX v0.1.4 사례 검증 — brew love + Gatekeeper 우회 + luasteam no-op shim + UTF-8 byte iteration 수정 + CJK Font fallback + state.txt 캐싱 가드 (분기 완전 제거) + usedpiscale=false + 비표준 사이즈 + 좌표계 분리 (sx 비례 확대) + T() 모듈 패턴 + hover info_text + 한글 string.lower 보호 + **함수 테이블 별도 ko.lua 분리 패턴 (character_descriptions / character_effect_descriptions)** + **Lua 5.5 and-or 파서 함정 (명시적 if-else)** + **클래스명 색상 태그 보존 sed 일괄 치환**. '이 LÖVE/Lua 게임 한글화/개선해줘' + Mac M4 디버깅 요청에 발동."
version: 0.4.0
author: HyeRin (MiniMax)
license: MIT
metadata:
  hermes:
    tags: [lua, love2d, fork, steam, shim, cjk, korean, gatekeeper, snkrx, headless-verify, type-guard, utf8-parsing, window-sizing, has-cjk, macos-sonoma]
    related_skills: [oss-fork-localization, godot-game-bootstrap, cpp-game-koreanization]
---

# LÖVE 2D (Lua) 게임 fork + 한국어화 워크플로우

> SNKRX (a327ex, MIT, 22K LOC) 한국어화 성공 사례 기반 (2026-07-21).
> C++ 게임 (Wesnoth 90분 낭비) 대비 🟢 즉시 성공: brew install 2분 + luac 검증 1분 + 헤드리스 실행 5분 = **총 10분 안에 GUI 실행 가능**.
> Wesnoth 교훈 — C++ 빌드 함정 회피 + 데이터 외부화 모드팩 패턴.

## 언제 사용하나

| 사용자 요청 | 트리거 |
|------------|--------|
| "이 LÖVE 게임 fork해서 한국어로 만들어줘" | ✓ |
| "SNKRX / NecroBarista /等其他 LÖVE 게임 한글화" | ✓ |
| "Lua 게임 빌드 + 실행까지 해줘" | ✓ |
| "Steam 의존성 빼고 게임만 실행하고 싶어" | ✓ |
| "게임 윈도우 작게 띄우는 법" | ✓ |
| "brew로 love 깔았는데 앱이 안 열려" | ✓ |

## 빌드 환경 분류 (LÖVE는 🟢 즉시 성공)

| 분류 | 빌드 도구 | 시간 | macOS 호환 | 사례 |
|------|----------|------|------------|------|
| 🟢 **LÖVE/Lua** | `brew install --cask love` | 2분 | ✅ 네이티브 | SNKRX (TypeScript 아님, Lua) |
| 🟢 TypeScript/Vite | `npm install` | 2초 | ✅ | sango-rising-dragons |
| 🟡 Java/Gradle | `./gradlew` | 30초~5분 | ✅ | triplea, FreeCol |
| 🟠 Rust/cargo | `cargo build` | 1~5분 | ✅ | zemeroth, veloren |
| 🔴 C++ scons/CMake | `scons`/`make` | 30분~1시간 | ⚠️ Boost/SDL 함정 | Wesnoth |
| ⚫ C# | `dotnet`/`mono` | 1~5분 | ⚠️ | RTK2020-CORE |

→ LÖVE는 🟢 카테고리 — **빌드 부담 0, 게임플레이 검증이 주된 시간 투자**.

## 1단계: LÖVE 설치 + Gatekeeper 우회 (5분)

```bash
brew install --cask love
# Gatekeeper 우회 (안 하면 love.app 첫 실행 시 팝업 — "확인되지 않은 개발자")
xattr -dr com.apple.quarantine /Applications/love.app
```

**확인**:
```bash
love --version
# → LÖVE 11.x (LuaJIT 2.1)
```

## 2단계: 헤드리스 syntax + 메인 루프 검증 (5분)

**luac syntax 검증**:
```bash
cd /Users/mac/work/<project>
for f in $(find . -name '*.lua' -not -path './.git/*'); do
  luac -p "$f" 2>&1 | grep -v '^$' && echo "FAIL: $f"
done
# → 전부 통과해야 다음 단계
```

**헤드리스 메인 루프 진입 확인** (GUI 검증은 사용자 Mac에서):
```bash
love . > /tmp/love_run.log 2>&1 &
LOVE_PID=$!
sleep 5
ps -p $LOVE_PID -o pid,stat,command  # Ss = 정상 sleep (메인 루프 진입)
kill -9 $LOVE_PID 2>/dev/null
cat /tmp/love_run.log  # stderr 비어있으면 = 코드 로딩 성공
```

**왜 헤드리스 검증이 가능한가**: love는 코드를 require만으로 검증 — 메인 루프 진입 시점까지 가면 모든 모듈이 정상 로드됨.

**완전 검증은 GUI 필수**: stderr 비어있어도 첫 프레임 draw() 에러는 못 잡음. 사용자 Mac에서 한 번 실행 필수.

## 3단계: Steam shim (필수, SNKRX 사례)

원본이 `require 'luasteam'` (Steamworks SDK 바인딩) 가정. brew love엔 없음 → 게임이 require 단계에서 죽음.

**파일**: `<project>/engine/external/luasteam.lua` (init.lua와 같은 디렉토리)
```lua
-- engine/external/luasteam.lua — SNKRX 한국어화 fork용 Steam shim
-- 원본은 Steamworks SDK와 연동되지만, 우리는 Steam 클라이언트 없이 게임플레이만 사용.
-- 모든 Steam API 호출을 no-op으로 만들어 호환성 유지.
local M = {}

function M.init() return true end
function M.shutdown() end
-- ⭐ engine/init.lua:149에서 매 프레임 호출. 빠뜨리면 "attempt to call field 'runCallbacks' (a nil value)"
function M.runCallbacks() end

M.userStats = {
  requestCurrentStats = function() return true end,
  setAchievement = function() end,
  storeStats = function() end,
  getStatInt = function() return 0 end,
  setStatInt = function() end,
}

M.friends = {
  setRichPresence = function() end,
  activateGameOverlay = function() end,
}

M.utils = {
  getAppID = function() return 915310 end,
}

return M
```

**init.lua 수정**:
```lua
-- 원본: steam = require 'luasteam'
-- 변경: 같은 디렉토리의 shim 사용
steam = require(path .. ".luasteam")
```

**검증할 함수 검색**:
```bash
grep -rn "steam\." *.lua | grep -oP "steam\.\w+\.\w+" | sort -u
# 예: steam.userStats.setAchievement, steam.friends.setRichPresence, steam.runCallbacks
# shim에 빠진 함수 없는지 확인
```

## 4단계: 한국어화 (CJK text.lua + lang/ko.lua + Font fallback)

### 4-1. UTF-8 character parsing fix (⭐ CRITICAL)

**버그**: 원본 `Text:parse()`는 `text:sub(i, i)`로 바이트 1개 추출. 한글(3바이트)이 깨짐 → `getWidth()`에서 **"UTF-8 decoding error: Not enough space"** 크래시.

**파일**: `engine/graphics/text.lua` — `Text:parse()` 내부
```lua
-- WRONG (원본):
for i = 1, #line.text do
  local c = line.text:sub(i, i)  -- 1바이트, 한글은 3바이트 필요
  ...

-- CORRECT (UTF-8 character 단위):
local i = 1
while i <= #line.text do
  local b = line.text:byte(i)
  -- lead byte로 continuation 바이트 수 계산
  local cont = 1
  if b >= 0xF0 then cont = 4      -- 4-byte (CJK Extension B+, Emoji)
  elseif b >= 0xE0 then cont = 3  -- 3-byte (한글, CJK, 일본어)
  elseif b >= 0xC0 then cont = 2  -- 2-byte (Latin extended)
  end
  local c = line.text:sub(i, i + cont - 1)  -- 전체 character
  -- ... 기존 태그 검사 + characters 삽입
  i = i + cont
end
```

**태그 경계 주의**: 태그(`[bg10]`, `[yellow]` 등)는 ASCII라서 byte position = char position. 한글 안에 태그가 끼는 경우는 거의 없음 (현재 SNKRX에선 무관).

### 4-2. Font CJK fallback (Noto Sans KR)

**폰트 받기**:
```bash
curl -L -o assets/fonts/NotoSansKR-Regular.ttf \
  "https://github.com/notofonts/noto-cjk/raw/main/Sans/SubsetOTF/KR/NotoSansKR-Regular.otf"
# 4.6MB, 한글 glyph 포함
```

**파일**: `engine/graphics/font.lua`
```lua
Font = Object:extend()
function Font:init(asset_name, font_size)
  self.font = love.graphics.newFont("assets/fonts/" .. asset_name .. ".ttf", font_size)
  self.h = self.font:getHeight()
  self.size = font_size
  self.ko_font = nil  -- lazy init
end

-- ⭐ 숫자 가드 (버그 함정 — 가격(0)이 들어오면 #0 시도 → 크래시)
function Font:get_text_width(text)
  if text == nil or type(text) ~= "string" then return 0 end
  if self.ko_font and self:has_cjk(text) then
    return self.ko_font:getWidth(text)
  end
  return self.font:getWidth(text)
end

function Font:_ensure_ko_font()
  if self.ko_font then return self.ko_font end
  self.ko_font = love.graphics.newFont("assets/fonts/NotoSansKR-Regular.ttf", self.size)
  return self.ko_font
end

-- ⭐ has_cjk false-positive 방지: byte-by-byte는 Latin extended(é, ñ)에도 trigger
-- 한글/CJK는 3-byte 또는 4-byte이므로 0xE0+ lead byte만 검사
function Font:has_cjk(text)
  if text == nil or type(text) ~= "string" then return false end
  for i = 1, #text do
    if text:byte(i) >= 0xE0 then return true end
  end
  return false
end

function Font:get_font_for_text(text)
  if self:has_cjk(text) then return self:_ensure_ko_font() end
  return self.font
end
```

### 4-3. text.lua + graphics.lua — 폰트 선택 적용

**파일**: `engine/graphics/text.lua` — `format_text` + `Text:draw`
```lua
-- format_text (line ~113-135)
for _, line in ipairs(self.lines) do
  local cf
  if line.font.get_font_for_text then
    cf = line.font:get_font_for_text(c.character)
  else
    cf = line.font.font
  end
  c.w = cf:getWidth(c.character)
  ...
end

-- Text:draw (line ~96)
local active_font
if line.font.get_font_for_text then
  active_font = line.font:get_font_for_text(c.character)
else
  active_font = line.font.font
end
love.graphics.print(c.character, active_font, ...)
```

**파일**: `engine/graphics/graphics.lua` — `print` + `print_centered`
```lua
function graphics.print(text, font, x, y, r, sx, sy, ox, oy, color)
  local active_font
  if font.get_font_for_text then
    active_font = font:get_font_for_text(text)
  else
    active_font = font.font
  end
  love.graphics.print(text, active_font, x, y, r or 0, sx or 1, sy or 1, ox or 0, oy or 0)
end

function graphics.print_centered(text, font, x, y, r, sx, sy, ox, oy, color)
  local active_font
  if font.get_font_for_text then
    active_font = font:get_font_for_text(text)
  else
    active_font = font.font
  end
  local active_w = active_font:getWidth(text)
  local active_h = active_font:getHeight()
  love.graphics.print(text, active_font, x, y, r or 0, sx or 1, sy or 1, (ox or 0) + active_w/2, (oy or 0) + active_h/2)
end
```

### 4-4. 한국어 사전 + T() 함수

**파일**: `lang/ko.lua`
```lua
return {
  arena_run = '아레나 런',
  options = '옵션',
  quit = '종료',
  -- ... ~100개 키
}
```

**파일**: `shared.lua` (shared_init 내부)
```lua
-- 한국어화 모듈 (v0.1)
lang = lang or {}
lang.current = 'ko'
lang.dicts = {}
lang.dicts.ko = require('lang.ko')
lang.dicts.en = {}  -- default 폴백
lang.fallback = 'en'

function T(key, default)
  local dict = lang.dicts[lang.current] or {}
  local fb = lang.dicts[lang.fallback] or {}
  if dict[key] ~= nil then return dict[key] end
  if fb[key] ~= nil then return fb[key] end
  return default or key
end
```

### 4-5. UI 텍스트 교체 패턴
```lua
-- 예: mainmenu.lua
button_text = T('arena_run', 'arena run')
title = '[wavy_mid, fg]' .. T('snkrx_title', 'SNKRX')
```

**T()의 장점**:
- 영어 원본이 default → 누락 시 자동으로 영어 표시 (안전 폴백)
- `lang.current = 'en'` 한 줄으로 전체 영어로 전환
- 새 언어 추가: `lang/ja.lua` + `lang.dicts.ja` 등록만

### 4-6. ⭐ Hover/Info 텍스트 (아이콘 마우스 오버) — 자주 빠뜨리는 영역

상점의 `CharacterIcon:on_mouse_enter()`에서 표시되는 **info_text**(영웅 이름, 클래스, 능력치, Lv.3 효과)는 사용자 눈에 가장 많이 띄는 텍스트인데 한국어화 1차에서 빠짐.

**파일**: `buy_screen.lua` `CharacterIcon:on_mouse_enter`
```lua
-- 원본 (영어):
self.info_text:activate({
  {text = '[' .. character_color_strings[self.character] .. ']' .. self.character:capitalize() .. '[fg] - cost: [yellow]' .. self.parent.cost, ...},
  {text = '[fg]Classes: ' .. character_class_strings[self.character], ...},
  {text = character_descriptions[self.character](1), ...},  -- 함수
  {text = '[' .. ... .. ']Lv.3 Effect - ' .. character_effect_names[self.character], ...},
  {text = character_effect_descriptions[self.character](), ...},  -- 함수
}, ...)

-- 한국어화:
local char_name = T('char_' .. self.character, self.character)
if lang.current == 'en' then char_name = self.character:capitalize() end  -- ⭐ 한글 보호
self.info_text:activate({
  {text = '[' .. character_color_strings[self.character] .. ']' .. char_name .. '[fg] - ' .. T('cost_label', 'cost: ') .. '[yellow]' .. self.parent.cost, ...},
  {text = '[fg]' .. T('class_label_hover', 'Classes: ') .. character_class_strings[self.character], ...},
  {text = character_descriptions[self.character](1), ...},  -- 본문은 별도 작업
  {text = '[' .. ... .. ']Lv.3 [' .. ... .. ']' .. T('lv3_effect_label', 'Effect - ') .. character_effect_names[self.character], ...},
  {text = character_effect_descriptions[self.character](), ...},  -- 본문은 별도 작업
}, ...)
```

**⭐ string.lower() / capitalize() 한글 보호** (CRITICAL):
```lua
-- 원본: string.lower(character_names[self.character])
-- → 한글에 적용되면 "부랑자"가 변형됨 (실제로는 영향 없지만 안전 가드)
-- 변경: lang.current == 'en'일 때만 lowercase
local char_name = T('char_' .. self.character, character_names[self.character])
if lang.current == 'en' then char_name = string.lower(char_name) end
```

### 4-7. 점진적 한국어화 (함수 테이블, 중첩 dict 처리 전략)

**어려운 케이스**: `character_descriptions[char](lvl) = function() return '영문 본문' end` 처럼 함수가 들어있는 테이블. 단순 key-value 매핑 불가.

**전략 4단계 (점진적)**:
1. **v0.1.x**: 이름 + 라벨만 (`T('cost_label', '비용: ')`). 설명 본문은 영어 그대로.
2. **v0.2**: 클래스명 (Warrior/Mage) 색상 태그 보존 일괄 sed 치환 — `references/class-name-batch-translation.md` 참조
3. **v0.3**: 별도 ko.lua 함수 테이블 + 조건부 치환 (`lang.current == 'ko'` 분기)
   ```lua
   -- lang/character_descriptions_ko.lua (신규 파일)
   return {
     ['vagrant'] = function(lvl) return '[fg]투사체로 [yellow]' .. get_character_stat('vagrant', lvl, 'dmg') .. '[fg] 데미지' end,
     ['swordsman'] = function(lvl) return '[fg]광역으로 [yellow]' .. get_character_stat('swordsman', lvl, 'dmg') .. '[fg] 데미지' end,
     -- ...
   }
   -- shared.lua
   lang.character_descriptions_ko = require('lang.character_descriptions_ko')
   -- buy_screen.lua
   local desc_func = (lang.current == 'ko' and lang.character_descriptions_ko and lang.character_descriptions_ko[self.character]) or character_descriptions[self.character]
   ```
4. **v0.4+** (선택): 정적 dict 변환 + `T('desc_vagrant_1', default)`

**자동화 도구 (Python, 50+ 함수를 1초에 변환)**:
```python
import re
# 1. 원본 함수의 return 문자열을 한글 번역으로 매핑
translations = {
  'vagrant': '[fg]투사체로 [yellow]{dmg}[fg] 데미지',
  # ...
}
# 2. {dmg} placeholders로 split → math.round(...) 보존하며 concatenation으로 재구성
# 예: "return '[fg]deal [yellow]' .. math.round(get_character_stat('blade', 3, 'dmg')/3, 2) .. '[fg] damage per enemy hit' end"
# → "function() return '[fg]타격 적마다 추가 [yellow]' .. math.round(get_character_stat('blade', 3, 'dmg')/3, 2) .. '[fg] 데미지' end"
```

**원칙**: **본문은 천천히, 라벨/이름부터**. 사용자가 "어디 안 됐어?" 시그널 = 실제로 자주 보는 영역. `CharacterIcon:on_mouse_enter` hover가 가장 자주 노출되는데 1차에서 빠지기 쉬움.

## 5단계: Window 크기 + macOS 풀스크린/DPI 디버깅 (CRITICAL)

M4 Mac에서 LÖVE 게임은 **3가지 함정이 동시 발생**합니다. 각각 별도 처리 필요.

### 5-1. conf.lua — 초기 윈도우 + DPI 설정

**파일**: `conf.lua`
```lua
function love.conf(t)
  t.version = "11.3"
  t.window.width = 1280
  t.window.height = 720
  t.window.vsync = 1
  t.window.msaa = 0
  t.window.resizable = true
  -- ⭐ M4 Retina에서 DPI 자동 축소 비활성화 (안 하면 1280x720 윈도우가 640x360으로 보임)
  t.window.usedpiscale = false
end
```

**왜 `usedpiscale = false`?** M4 Retina 디스플레이는 기본 `true`라서 `setMode(1280, 720)` 호출해도 love가 내부 좌표계를 DPI 비례로 자동 축소 → 결과적으로 640x360처럼 작게 보임.

### 5-2. ⭐⭐ state.txt 캐싱 → 풀스크린화 (자주 빠뜨리는 함정)

LÖVE 게임은 `~/Library/Application Support/LOVE/<game>/state.txt`에 `sx`, `sy` 같은 스케일 값을 저장. **이전 세션의 비정상 값(sx=4 등)이 박혀있으면 다음 실행 시 `setMode(state.sx * gw, state.sy * gh) = setMode(1920, 1920)` → macOS가 자동 풀스크린화.**

**증상**: "창 크기 안 맞아요" / "전체화면으로 변환돼요" / "config 바꿨는데 안 바뀌어요"

**진단**:
```bash
cat ~/Library/Application\ Support/LOVE/<game>/state.txt
# 예: return {["sx"] = 4, ["sy"] = 4, ...}
```

**해결 1단계**: state.txt 삭제
```bash
rm ~/Library/Application\ Support/LOVE/<game>/state.txt
```

**해결 2단계 (영구)**: `engine/init.lua`에서 `state.sx/sy` 범위 가드
```lua
if state.sx and state.sy then
  -- 비정상 범위 (0.5~3 밖)면 무시
  if state.sx >= 0.5 and state.sx <= 3 and state.sy >= 0.5 and state.sy <= 3 then
    sx, sy = state.sx, state.sy
    love.window.setMode(state.sx*gw, state.sy*gh, {fullscreen=false, ...})
  else
    state.sx, state.sy = nil, nil
    love.window.setMode(window_width, window_height, {fullscreen=false, ...})
  end
else
  state.sx, state.sy = sx, sy
  love.window.setMode(window_width, window_height, {fullscreen=false, ...})
end
```

**해결 3단계 (더 단순)**: state 분기 제거하고 매번 config 기반 직접 계산
```lua
-- ⭐ v0.1.1+ 권장 — state.sx 의존성 제거
gw, gh = config.game_width or 480, config.game_height or 270
sx, sy = window_width/(config.game_width or 480), window_height/(config.game_height or 270)
state.sx, state.sy = sx, sy  -- 강제 덮어쓰기
love.window.setMode(window_width, window_height, {fullscreen=false, ...})
```

### 5-3. ⭐ 비표준 사이즈로 풀스크린 회피

**M4 디스플레이 = 1920x1080 (Retina)** 또는 **2560x1600**. 정확히 일치하는 사이즈로 `setMode` 호출하면 macOS가 풀스크린화.

**함정 사이즈 (피할 것)**:
- ❌ 1920x1080
- ❌ 2560x1440
- ❌ 화면 전체 크기 (`'max'`)

**안전 사이즈 (비표준)**:
- ✅ **1280x720**
- ✅ **1440x810**
- ✅ **1366x768**

### 5-4. setMode 풀옵션 (모든 함정 한 번에 차단)

**파일**: `engine/init.lua`의 `setMode` 호출
```lua
love.window.setMode(window_width, window_height, {
  vsync = config.vsync,
  msaa = msaa or 0,
  display = 1,           -- ⭐ 멀티 디스플레이에서 메인 디스플레이 강제
  fullscreen = false,    -- ⭐ 풀스크린화 차단
  borderless = false,    -- ⭐ 보더리스 모드 차단 (풀스크린과 유사하게 동작)
  resizable = true,
})
```

### 5-5. ⭐ 좌표계 분리 패턴 — SNKRX 하드코딩 480x270 대응

SNKRX는 코드 전체가 `gw=480, gh=270` 좌표계 하드코딩 가정 (`setMode(480*sx, 270*sy)` 등). **`game_width/height`를 480x270으로 유지**하고 `window_width/height`만 키워서 sx 비율로 비례 확대.

```lua
-- main.lua love.run
return engine_run({
  game_name = 'SNKRX',
  window_width = 1280,   -- 큰 윈도우
  window_height = 720,
  game_width = 480,      -- ⭐ 좌표계는 SNKRX 기본값 유지
  game_height = 270,
})
-- 결과: sx = 1280/480 ≈ 2.67 → 모든 오브젝트 비례 확대
```

**크기 옵션**:
- 절대 숫자 (1280, 720) — 가장 확실, 풀스크린 회피
- `'max'` — 화면 전체 (원본 동작, 풀스크린 위험)
- `'half'` — 화면 절반 (engine/init.lua 수정 필요)

### 5-6. macOS 풀스크린 / 창 크기 디버깅 순서 (⭐ 4번 반복 시도 회수)

사용자가 "창 크기 안 맞아 / 풀스크린 됨" 신고 시 **반드시 이 순서로**:

```
1. state.txt 확인/삭제           (~30초)
   $ cat ~/Library/Application\ Support/LOVE/<game>/state.txt
   $ rm ~/Library/Application\ Support/LOVE/<game>/state.txt

2. conf.lua usedpiscale=false 확인 (~10초)

3. main.lua window_width 절대 숫자 확인 (1280, 720)
   'max' 사용 금지, 비표준 사이즈 사용

4. engine/init.lua setMode 풀옵션 확인
   {fullscreen=false, borderless=false, display=1, resizable=true}

5. 비표준 사이즈 사용 (1280x720)
   M4 디스플레이(1920x1080)와 정확히 일치하면 풀스크린화

6. 사랑하는 사용자에게 "다시 시도 + 스크린샷" 요청 (~30초~1분)
```

**4단계 진단 루프 회수**: state.txt → usedpiscale → 비표준 사이즈 → setMode 옵션. 이 4개 중 하나씩 적용하며 매번 사용자에게 "됐나?" 물어보면 시간 낭비. **한꺼번에 4개 다 적용 + 검증 스크린샷 1회 요청**이 효율적.

## 6단계: 빌드 환경 순서 함정

**'half' 비교 순서 함정** (engine/init.lua:54):
```lua
-- WRONG: 'max' 체크가 먼저면 'half' 문자열이 박힘
if config.window_width ~= 'max' then window_width = config.window_width end  -- 'half' 대입됨
if config.window_width == 'half' then window_width = window_width / 2 end  -- 'half' / 2 → 크래시

-- CORRECT: 'half' 먼저 처리
if config.window_width == 'half' then window_width = math.floor(window_width / 2) end
if config.window_width ~= 'max' and config.window_width ~= 'half' then window_width = config.window_width end
```

## 흔한 함정 정리

### 1. `if not text then` 가드 함정 ⭐
- Lua에서 0은 truthy. `if not 0 then` → false (가드 통과)
- 가격(숫자)이 `print_centered()`로 전달되면 `has_cjk(0)` → `#0` 시도 → **"attempt to get length of local 'text' (a number value)"**
- **해결**: `type(text) ~= "string"` 명시적 타입 체크

### 2. `Font:has_cjk` false-positive
- byte-by-byte로 0x80+ 검사하면 Latin extended (é = 0xC3 0xA9)도 false-positive
- **해결**: 0xE0+ lead byte만 체크 (한글/CJK/일본어/Emoji)

### 3. UTF-8 `sub(i, i)` byte split
- 한글 1글자 = 3 bytes. `sub(i, i)`는 1 byte → 깨진 byte
- `getWidth()`에서 **"UTF-8 decoding error: Not enough space"**
- **해결**: lead byte 분석으로 continuation 수 계산

### 4. `runCallbacks` 누락
- `engine/init.lua:149`에서 매 프레임 호출
- shim에 빠뜨리면 "attempt to call field 'runCallbacks' (a nil value)"
- **해결**: shim에 `function M.runCallbacks() end` 명시

### 5. `love.window.setMode` 풀스크린 함정
- 'max' 또는 화면 전체 크기 사용 시 macOS에서 강제 풀스크린화
- **해결**: 절대 픽셀 + conf.lua 일치 + `usedpiscale = false`

### 6. ⭐⭐ state.txt 캐싱 → 풀스크린화 (가장 자주 빠뜨림)
- `~/Library/Application Support/LOVE/<game>/state.txt`에 sx/sy 저장
- 이전 비정상 값 (sx=4)이 박혀있으면 다음 실행 시 `setMode(4*480, 4*270) = 1920x1920` → macOS가 자동 풀스크린
- **증상**: config 바꿨는데 풀스크린 그대로 / `state.txt` 삭제해도 다시 풀스크린 (state.sx 분기가 다시 채워서)
- **해결**: state.txt 삭제 + engine/init.lua에 state.sx 범위 가드 OR state 분기 완전 제거
- **자주 반복되는 함정**: 사용자가 "config는 바꿨는데 풀스크린 됨" → 1번이 아니라 4번 반복 시도하게 됨. 한 번에 4개 다 적용 권장.

### 7. ⭐⭐ DPI 자동 축소 (M4 Retina)
- `usedpiscale` 기본값이 `true` → `setMode(1280, 720)` 호출해도 좌표계가 DPI 비례로 축소 → 640x360처럼 작게 보임
- **증상**: "창은 큰데 오브젝트가 작아 보여요" / "창 크기는 안 맞아요"
- **해결**: `conf.lua`에 `t.window.usedpiscale = false`

### 8. ⭐ 비표준 사이즈 (M4 디스플레이 일치 회피)
- M4 디스플레이 = 1920x1080 (Retina) 또는 2560x1600
- 정확히 일치하는 사이즈로 setMode 호출 시 macOS가 풀스크린화
- **안전 사이즈**: 1280x720, 1440x810, 1366x768

### 9. ⭐ string.lower() / capitalize() 한글 보호
- 원본 코드 `string.lower(character_names[char])` 같은 호출이 한글에 적용되면 의도치 않은 변환
- **해결**: `lang.current == 'en'` 가드
```lua
local char_name = T('char_' .. self.character, character_names[self.character])
if lang.current == 'en' then char_name = string.lower(char_name) end
```

### 10. Hover/info_text 한국어화 빠뜨림
- 가장 자주 보이는 영역 (영웅 아이콘 마우스 오버)인데 1차에서 빠짐
- **증상**: "클래스만 한글화된 것 같아요" / "호버했을 때 영어"
- **해결**: `CharacterIcon:on_mouse_enter`에서 `T()` 패턴 적용 + 한글 보호 가드

### 11. Gatekeeper 첫 실행 팝업
- brew cask `love`가 Apple 개발자 인증서 없음 → 팝업
- **해결**: `xattr -dr com.apple.quarantine /Applications/love.app`

### 12. 헤드리스 SIGKILL ≠ 실패
- `love .` 명령을 헤드리스 터미널에서 실행하면 SIGKILL — 정상
- love는 GUI 앱이라 디스플레이 없으면 죽음
- **검증**: `love . &` + `ps -p $PID` → Ss 상태면 메인 루프 진입 OK
- **완전 검증**: 사용자 Mac에서 한 번 실행 (draw() 에러는 stderr 안 잡힘)

### 13. ⭐ Lua 5.5 and-or 패턴 함정 (CRITICAL)
`luac -p`로 검증 시 다음 패턴이 파싱 실패:
```lua
-- WRONG: luac -p가 "function arguments expected near 'and'" 에러
local active_font = font:get_font_for_text and font:get_font_for_text(text) or font.font

-- CORRECT: 명시적 if-else
local active_font
if font.get_font_for_text then
  active_font = font:get_font_for_text(text)
else
  active_font = font.font
end
```
**왜**: Lua 파서가 `font.font`를 메서드 호출로 잘못 해석하면서 `or` 다음 토큰을 함수 인자로 기대. **luac 5.5에서 발생, luac 5.1/LuaJIT은 통과**. SNKRX 작업 중 2회 발생 → 명시적 if-else로 회피.

### 14. ⭐⭐ 함수 테이블 (descriptions, effects) 한국어화 — 동적 값 보존 패턴
영웅 설명 (`character_descriptions[char] = function(lvl) return '...' end`)처럼 **함수가 들어있는 테이블**은 단순 key-value 치환 불가. 동적 값 (`get_character_stat()`)은 유지하고 정적 본문만 번역 필요.

**전략 3단계**:
1. **v0.1.x**: 라벨/이름만 (`T('cost_label', '비용: ')`). 설명 본문은 영어 그대로.
2. **v0.2**: 별도 ko 테이블 + 조건부 치환
   ```lua
   -- lang/character_descriptions_ko.lua (신규)
   return {
     ['vagrant'] = function(lvl) return '[fg]투사체로 [yellow]' .. get_character_stat('vagrant', lvl, 'dmg') .. '[fg] 데미지' end,
     ['swordsman'] = function(lvl) return '[fg]광역으로 [yellow]' .. get_character_stat('swordsman', lvl, 'dmg') .. '[fg] 데미지' end,
     -- ... 50+ 항목
   }
   ```
   ```lua
   -- shared.lua
   lang.character_descriptions_ko = require('lang.character_descriptions_ko')
   ```
   ```lua
   -- buy_screen.lua CharacterIcon:on_mouse_enter
   local desc_func = (lang.current == 'ko' and lang.character_descriptions_ko and lang.character_descriptions_ko[self.character]) or character_descriptions[self.character]
   ```
3. **v0.3+** (선택): 정적 dict 변환 + `T('desc_vagrant_1', default)`

**자동화 도구 (Python, 50+ 함수를 1초에 변환)**:
```python
import re
# 원본 함수의 return 문자열을 한글 번역으로 치환
# 동적 표현 (' .. math.round(...) .. ')은 그대로 보존
translations = {
  'vagrant': '[fg]투사체로 [yellow]{dmg}[fg] 데미지',
  # ...
}
# {dmg} placeholders로 split → concatenation으로 재구성
```

### 15. ⭐⭐ `state.sx/sy` 분기 완전 제거 — 가장 안정적인 해법
v0.1.x 가드 패턴은 작동하지만, **state.sx 분기 자체를 없애는 게 가장 안정적**:
```lua
-- v0.1.4+ 권장 — state 분기 완전 제거
gw, gh = config.game_width or 480, config.game_height or 270
sx, sy = window_width/(config.game_width or 480), window_height/(config.game_height or 270)
state.sx, state.sy = sx, sy  -- 강제 덮어쓰기 (다음 세션 보호)
love.window.setMode(window_width, window_height, {
  fullscreen = false, borderless = false, display = 1, resizable = true,
})
```
**장점**: state.txt 캐싱 문제가 원천 봉쇄. 매번 config 기준으로 결정. **단점**: 옵션 메뉴의 K/L 키 핸들러(`setMode(480*sx, 270*sy)`)와 충돌 가능 → main.lua 옵션 분기 단순화 동반 권장.

### 16. ⭐ 캐릭터 클래스명 (Warrior/Mage/Nuker 등) 한글화 — 색상 태그 보존 패턴
`character_class_strings = { ['vagrant'] = '[fg]Explorer, Psyker', ... }` 같은 **색상 태그 + 클래스명** 조합은 단순 sed 치환 OK:
```python
# Python one-liner: 색상 태그 (']') 다음의 클래스명만 치환
translations = {
  'Warrior': '전사', 'Mage': '마법사', 'Nuker': '누커',
  'Ranger': '레인저', 'Rogue': '도적', 'Healer': '힐러',
  'Enchanter': '인챈터', 'Psyker': '사이커', 'Builder': '빌더',
  'Voider': '보이드', 'Curser': '커서', 'Swarmer': '스워머',
  'Forcer': '포서', 'Conjurer': '컨저러', 'Sorcerer': '소서러',
  'Mercenary': '머서너리', 'Explorer': '탐험가',
}
for i in range(start, end):
  for en, ko in translations.items():
    line = re.sub(r'\]\s*' + en + r'\b', ']' + ko, line)
```
**경계 케이스**: `'[blue]Mage, Enchanter'` (두 번째 클래스에 색상 없음) → sed로 안 잡힘 → 수동 패치 1~2개.

**Python 일괄 치환 워크플로 (실전)**:
```python
with open('main.lua', 'r', encoding='utf-8') as f:
    content = f.read()
# character_class_strings 영역만 찾아서 sed (영향 최소화)
# 1) 클래스명만 (sed)
import re
trans = {'Warrior': '전사', ...}
# 줄 단위로 split, character_class_strings 섹션만 처리
lines = content.split('\n')
start, end = None, None
for i, l in enumerate(lines):
    if 'character_class_strings = {' in l: start = i
    elif start and l.strip() == '}': end = i; break
for i in range(start, end + 1):
    for en, ko in trans.items():
        lines[i] = re.sub(r'\]\s*' + en + r'\b', ']' + ko, lines[i])
content = '\n'.join(lines)
with open('main.lua', 'w', encoding='utf-8') as f: f.write(content)
```

**같은 키가 여러 파일에 등장** (v0.1.5 실측):
- `buy_soundtrack` 키 → mainmenu.lua와 arena.lua 양쪽에 존재 → grep으로 모든 위치 파악 후 일괄 패치
- `credits`, `loop`, `new_run_diff_max` 등도 동일 패턴
- **해결**: `grep -rn "button_text = 'X'" --include="*.lua"` 먼저 → 모든 위치 패치

### 17. ⭐ 옵션 메뉴 토글 라벨 (cooldown_snake / arrow_snake / screen_movement) 일괄 T() 패턴 (v0.1.5)

옵션 화면의 4개 토글 버튼 (screen_shake / cooldown_snake / arrow_snake / screen_movement)은 **각각 2~3줄** 안에서 정의되고, **action 안에서 `b:set_text(...)`로 라벨 업데이트**:
```lua
self.cooldown_snake_button = Button{group = self.ui, x = gw/2 + 75, y = gh - 100, w = 145, force_update = true,
    button_text = '[bg10]' .. T('option_cooldown_snake', 'cooldowns on snake: ') .. tostring(state.cooldown_snake and T('yes', 'yes') or T('no', 'no')),
    fg_color = 'bg10', bg_color = 'bg', action = function(b)
      ui_switch1:play{pitch = random:float(0.95, 1.05), volume = 0.5}
      state.cooldown_snake = not state.cooldown_snake
      b:set_text('[bg10]' .. T('option_cooldown_snake', 'cooldowns on snake: ') .. tostring(state.cooldown_snake and T('yes', 'yes') or T('no', 'no')))
    end}
```

**주의 3가지**:
1. `button_text` (초기값) 와 `b:set_text(...)` (action 안) **둘 다 T() 적용** — 빠뜨리면 클릭 후 영어로 돌아옴
2. `tostring(state.x and T('yes', 'yes') or T('no', 'no'))` — `T('yes', 'yes')`처럼 한글 키도 정의해서 `lang.current == 'ko'`면 '예'/'아니오'로 표시
3. 토글 라벨에는 `: ` (콜론+공백) 같은 suffix를 default에 포함 → `T('option_screen_shake', 'screen shake: ')` — 한글도 같은 suffix 사용 (`'화면 흔들림: '`)

**자동화 (Python 일괄)**:
```python
content = open('main.lua').read()
content = content.replace(
    "button_text = 'sfx volume: ' .. tostring",
    "button_text = T('option_sfx_volume', 'sfx volume: ') .. tostring"
)
content = content.replace(
    "b:set_text('sfx volume: ' .. tostring",
    "b:set_text(T('option_sfx_volume', 'sfx volume: ') .. tostring"
)
```

### 18. ⭐ Fork 표기 — origin/upstream remote rename (v0.1.5)

GitHub fork 푸시 시 `origin`이 원본을 가리키는 상태로 시작. **origin과 upstream을 명시적으로 분리**:
```bash
# clone 직후
git remote rename origin upstream
git remote add origin https://github.com/sigco3111/snkrx-clone.git

# 검증
git remote -v
# origin    https://github.com/sigco3111/snkrx-clone.git (fetch/push)
# upstream  https://github.com/a327ex/SNKRX.git (fetch/push)
```

**왜 명시적으로 분리하나**:
- `git pull` → origin에서 받음 (내 fork의 최신)
- `git fetch upstream && git merge upstream/master` → 원본 동기화
- `git push` → origin으로 (내 fork 푸시)
- 미래에 `gh repo create --remote=origin`이 자동으로 망가지는 것 방지

**모범 사례**: `gh repo create sigco3111/<name> --source=.` 후 **반드시 `curl` HTTP 200 검증** (oss-fork-localization §gh repo create 원격 origin 실패 함정 참조)

## 작업 흐름 (총 1시간 워크플로우)

```
[5분] brew install + quarantine + luac verify
[10분] Steam shim (init/shutdown/runCallbacks + subtables)
[15분] UTF-8 text.lua parse fix (lead byte iteration)
[10분] Font CJK fallback (has_cjk + get_text_width + get_font_for_text)
[5분] lang/ko.lua + T() 함수 (shared.lua)
[10분] UI 텍스트 교체 (mainmenu.lua + buy_screen.lua)
[5분] Window 크기 (절대 픽셀 + conf.lua)
[5분] 헤드리스 + GUI 검증
```

## 검증 워크플로

1. **luac -p** → syntax 100%
2. **love . & + ps -p $PID** → Ss = 메인 루프 진입
3. **GUI 실행 (사용자 Mac)** → stderr 캡처
4. **한국어 □ (tofu) 보이면** → 폰트 사이즈/렌더링 조정
5. **크래시 시** → stderr 캡처 (`/tmp/love_run.log`)

## 검증 신호

| 증상 | 원인 | 해결 |
|------|------|------|
| `no field package.preload['luasteam']` | shim 없음 | `engine/external/luasteam.lua` 생성 |
| `attempt to call field 'runCallbacks' (a nil value)` | shim에 runCallbacks 없음 | shim에 추가 |
| `UTF-8 decoding error: Not enough space` | `sub(i, i)` byte split | UTF-8 character 단위로 |
| `attempt to get length of local 'text' (a number value)` | `if not text` 0 통과 | `type(text) ~= "string"` |
| `attempt to perform arithmetic on local 'window_width' (a string value)` | 'half' 처리 순서 | 'half' 먼저 |
| `function arguments expected near 'and'` (luac) | `font:get_font_for_text and ... or font.font` 패턴 | 명시적 if-else |
| 캐릭터 클래스명 (Warrior/Mage) 한글 미적용 | 색상 태그 + 클래스명 조합 | sed `]\bClassName\b` → `]한글` |
| 설명 본문이 영어 그대로 (라벨만 한글) | 함수 테이블 (`description[char] = function`) | 별도 ko 함수 테이블 + `lang.current == 'ko'` 분기 |
| 게임이 풀스크린으로 뜸 (config 바꿨는데) | state.txt sx/sy 캐싱 | state.txt 삭제 + state.sx 범위 가드 OR 분기 완전 제거 |
| 게임이 풀스크린으로 뜸 (첫 실행) | 'max' 사용 / 디스플레이 일치 | 절대 픽셀 (1280x720) |
| 창은 큰데 오브젝트가 작게 보임 | DPI 자동 축소 | `t.window.usedpiscale = false` |
| "창 크기는 안 맞아요" (여러 번 반복) | state.txt + DPI + 풀스크린 + 사이즈 4중 함정 | 4개 한꺼번에 적용 |
| "클래스만 한글화된 것 같아요" | hover info_text 빠뜨림 | CharacterIcon:on_mouse_enter T() 적용 |
| "한글 이름이 깨져 보여요" | `string.lower()`가 한글에 적용 | `lang.current == 'en'` 가드 |
| Gatekeeper "'love' 앱을 열 수 없습니다" | quarantine 미해제 | `xattr -dr com.apple.quarantine /Applications/love.app` |

## 사례

### SNKRX (a327ex, MIT, 22K LOC) — 2026-07-21 v0.1.4

| 항목 | 결과 |
|------|------|
| 한국어화 | 메뉴 5버튼 + 상점 탭 5개 + 튜토리얼 9줄 + **hover 영웅 이름/클래스/설명/Lv.3효과 + 옵션 메뉴 4 토글 + 옵션 볼륨/음악 + arena 승리/패배/continue/new run/credits/loop** |
| Steam shim | `engine/external/luasteam.lua` (runCallbacks 포함) |
| 창 | 1280x720 + sx=2.67 비례 확대 (game_width 480 유지) |
| DPI | usedpiscale=false |
| state.txt 캐싱 가드 | engine/init.lua 분기 단순화 (config 기반 매번 재계산) |
| GitHub | https://github.com/sigco3111/snkrx-clone (MIT 자동 인식) |
| 커밋 | master 688171c (v0.1.5) |
| 소요 | 약 3시간, 17+ 파일 변경 (6개 v0.1.x 푸시) |

**한국어화 v0.1.x 누적 작업**:
- v0.1: 메인 메뉴 + 상점 + 튜토리얼 (라벨)
- v0.1.1: 영웅 이름 70+ + 적 + 옵션 메뉴 라벨
- v0.1.2: hover 영웅 이름 + 클래스 라벨 (cost/Classes/Effect)
- v0.1.3: 클래스명 (Warrior/Mage 등 16종) + Lv.3 효과 이름 (60+) + 영웅 설명 본문 (57개 함수) — `lang/character_descriptions_ko.lua` 분리
- v0.1.4: Lv.3 효과 설명 본문 (57개 함수) — `lang/character_effect_descriptions_ko.lua` 분리 + 옵션 토글 4개
- v0.1.5: arena 승리/패배 + 일시정지 + 옵션 음악/효과음 볼륨 — main.lua, arena.lua, options button 일괄 T()

**교훈 시퀀스 (시간순)**:
1. brew love → Gatekeeper → quarantine 해제
2. luasteam 모듈 없음 → shim 생성
3. UTF-8 decoding error → byte iteration → UTF-8 character iteration
4. **Lua 5.5 and-or 패턴 함정** → luac 5.5가 `font:get_font_for_text and ... or font.font` 파싱 실패 → 명시적 if-else
5. runCallbacks nil → shim에 추가
6. has_cjk에 숫자(가격) → type 가드 (`type(text) ~= "string"`)
7. 한글 표시 OK → "어디 안 됐어?" 반복 시도
8. **state.txt 풀스크린 4번 반복 시도** → state.sx=4 캐싱 발견 → state.txt 삭제 + 가드 → v0.1.4에 분기 완전 제거
9. **DPI 축소** → usedpiscale=false
10. **비표준 사이즈** → 1280x720 사용
11. **hover info_text** → "클래스만 한글화" 사용자 정정 → CharacterIcon:on_mouse_enter T() 적용
12. **설명 본문 영어** → 별도 ko 함수 테이블 + 조건부 치환 (`lang.character_descriptions_ko`)
13. **클래스명 한글** → 색상 태그 보존 sed 일괄 치환
14. **Lv.3 효과 설명 본문** → 동일 패턴 (`lang.character_effect_descriptions_ko`)
15. **arena/일시정지/옵션 볼륨** (v0.1.5) → buy_soundtrack/credits/loop/congratulations 등 양쪽 파일 중복 키 처리 + 옵션 볼륨(action_2도 T())

**상세 시간순 디버깅 로그**: → `references/snkrx-clone-case-study.md`

**v0.1.5 최종 누적 통계**:
- lang/ 디렉토리: 3개 모듈 (ko.lua, character_descriptions_ko.lua, character_effect_descriptions_ko.lua)
- 한국어 번역 키 130+ 개
- 영웅 70+ / 적 / 효과 / 클래스 16개 모두 한글화
- 푸시 6회 (v0.1, v0.1.1, v0.1.2, v0.1.3, v0.1.4, v0.1.5)
- origin/upstream remote 분리 (origin=sigco3111, upstream=a327ex)

## 관련 스킬
- `oss-fork-localization`: 일반 OSS fork + LLM 백엔드 교체 + MODIFIED.md
- `cpp-game-koreanization`: C++ 게임 gettext PO 워크플로우 (Wesnoth 90분 낭비 교훈)
- `godot-game-bootstrap`: Godot 게임 부트스트랩