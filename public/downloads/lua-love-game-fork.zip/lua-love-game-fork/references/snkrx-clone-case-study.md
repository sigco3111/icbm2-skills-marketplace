# SNKRX 사례 연구 — 시간순 디버깅 시퀀스

> sigco3111/snkrx-clone v0.1 → v0.1.5 (2026-07-21)
> SNKRX (a327ex/SNKRX, MIT) 한국어화 fork의 전체 작업 로그
> → 다음 세션에서 "LÖVE 게임 한글화 + Mac 풀스크린 함정" 디버깅 시 참고.

## 환경

| 항목 | 값 |
|---|---|
| M4 Mac mini 16GB | macOS 26.5.2 |
| LÖVE | 11.5 (brew cask) |
| Lua | 5.1 (LuaJIT 2.1) |
| 원본 | https://github.com/a327ex/SNKRX (MIT, 22K LOC) |
| Fork | https://github.com/sigco3111/snkrx-clone |

## 디버깅 시퀀스 (사용자 정정 17번)

| # | 사용자 신고 | 시도 | 결과 | 진짜 원인 |
|---|---|---|---|---|
| 1 | (실행 안 됨) | `brew install love` | Gatekeeper 팝업 | `xattr -dr com.apple.quarantine` 필요 |
| 2 | "실행 안 됨" | `love .` | `module 'luasteam' not found` | Steam shim 필요 |
| 3 | "한글 깨짐" | love 실행 | `UTF-8 decoding error: Not enough space` | `text:sub(i,i)` byte split |
| 4 | "여전히 안 됨" | love 실행 | `runCallbacks (a nil value)` | shim에 runCallbacks 누락 |
| 5 | (실행 OK) | love 실행 | `attempt to get length of local 'text' (a number value)` | `has_cjk(숫자)` type guard 누락 |
| 6 | "한글 보임!" | (작동) | - | v0.1 한국어화 완료 |
| 7 | "창 너무 작음" | `window_width = 480` | 작은 창 480x270 OK | OK |
| 8 | "두 배로 키워줘" | `window_width = 960` | OK | OK |
| 9 | "같은 비율로 확대" | `window_width = 1920` | **풀스크린 변환됨** | 첫 풀스크린 함정 |
| 10 | "오브젝트는 작은 채" | game_width=1920 | UI 작음 | 좌표계 분리 필요 |
| 11 | "다시 두 배로" | game_width=480 + window=1280 | **풀스크린 + 작은 UI** | **state.txt 캐싱 + DPI** |
| 12 | "작은 사이즈로 출력" | usedpiscale=false | 작은 UI | DPI 수정 OK |
| 13 | "여전히 작음" | state.txt 삭제 | **풀스크린 + 작은 UI** | state.sx=1 캐싱 |
| 14 | "변화 없음" | state 분기 제거 | OK! | sx=1280/480=2.67 비례 확대 |
| 15 | "클래스만 한글화" | hover info_text | - | CharacterIcon:on_mouse_enter 빠뜨림 |
| 16 | "토글시" | 옵션 메뉴 | - | screen_shake/option 버튼 T() 적용 |
| 17 | "마우스 위에 있을 때" | hover | - | 영웅 이름 + 라벨 T() 적용 |

## state.txt 함정 — 4번 반복의 교훈 (11~14번)

**사용자 정정 시그널**: "여전히 작은 사이즈로 출력됨" (4번 반복)

| 시도 | 변경 | 결과 |
|---|---|---|
| 1 | `window_width = 1920` | 풀스크린 (1920=Retina 일치) |
| 2 | `window_width = 1280` (비표준) | 풀스크린 여전히 (state.txt에 sx=4 캐싱) |
| 3 | `state.txt` 삭제 + state 분기 단순화 | 작은 윈도우 480x270 (state.sx=1 캐싱) |
| 4 | `state.sx` 분기 완전 제거 + 매번 config 계산 | **OK! 1280x720 큰 윈도우** |

**교훈**: 4개 함정이 동시에 작용할 때 하나씩 시도하면 시간 낭비. **state.txt + usedpiscale + 비표준 사이즈 + setMode 풀옵션을 한꺼번에 적용**하는 게 효율적.

## 한 줄로 끝내는 macOS 풀스크린 디버깅

```bash
# 1단계: state.txt 삭제
rm ~/Library/Application\ Support/LOVE/<game>/state.txt

# 2단계: conf.lua
t.window.usedpiscale = false
t.window.width = 1280
t.window.height = 720
t.window.resizable = true

# 3단계: main.lua
window_width = 1280, window_height = 720,
game_width = 480, game_height = 270  -- 좌표계 분리

# 4단계: engine/init.lua setMode 풀옵션
love.window.setMode(window_width, window_height, {
  display=1, fullscreen=false, borderless=false, resizable=true
})

# 5단계: state.sx 분기 제거 (또는 0.5~3 범위 가드)
```

## 점진적 한국어화 단계 (v0.1.x 누적)

| 버전 | 작업 | 누적 키 수 |
|---|---|---|
| v0.1 | 메인 메뉴 5버튼 + 상점 탭 5개 + 튜토리얼 9줄 (라벨만) | 25 |
| v0.1.1 | 영웅 이름 70+ (ko.lua `char_<key>` 패턴) + 적 + 옵션 메뉴 라벨 | 100 |
| v0.1.2 | hover 영웅 이름 + 클래스 라벨 (cost/Classes/Effect) — CharacterIcon:on_mouse_enter T() | 110 |
| v0.1.3 | 클래스명 16종 (Warrior/Mage 등) + Lv.3 효과 이름 60+ + **영웅 설명 본문 57개** (`lang/character_descriptions_ko.lua` 신규) | 130 |
| v0.1.4 | **Lv.3 효과 설명 본문 57개** (`lang/character_effect_descriptions_ko.lua` 신규) + 옵션 토글 4개 | 145 |
| v0.1.5 | arena 승리/패배/continue/new run + 옵션 음악/효과음 볼륨 + 일시정지 화면 | 165 |

## 향후 작업 (다음 세션)

- [ ] enemies.lua 적 이름 표시 위치 처리 (현재 enemy 키만 번역, 표시 위치 미처리)
- [ ] 옵션 메뉴의 일부 토글 라벨 (옵션 화면 안 세부 설명 등)
- [ ] 패시브/스킬 이름 (`character_names` 다음 테이블, main.lua line 1198~)
- [ ] **콘텐츠 확장** (v0.3+): 새 영웅/클래스/시너지
- [ ] **신 게임 모드** (v0.3+): 보스 레이드, 데일리 챌린지
- [ ] **자동위임** (v0.4+): sango 결정 큐 패턴

## 핵심 파일 위치 (sigco3111/snkrx-clone 기준)

| 파일 | 역할 |
|---|---|
| `conf.lua` | love.conf 콜백, DPI/resizable 설정 |
| `main.lua` line 2138 | `love.run` → engine_run 호출 (창 크기 결정) |
| `main.lua` line 275-333 | `character_names` 영웅 이름 dict |
| `main.lua` line 515-573 | `character_class_strings` 클래스 라벨 |
| `main.lua` line 590-... | `character_descriptions` 함수 테이블 |
| `main.lua` line 652-769 | `character_effect_names` + `_gray` Lv3 효과 이름 |
| `main.lua` line 772-829 | `character_effect_descriptions` + `_gray` Lv3 효과 본문 |
| `main.lua` line 1198-... | 패시브/스킬 이름 dict |
| `shared.lua` line 42-... | `fat_font`, `pixul_font` + `T()`, `lang` 모듈 |
| `lang/ko.lua` | 한국어 사전 (~130+개 키, 8.7KB) |
| `lang/character_descriptions_ko.lua` | 57개 영웅 설명 함수 한국어 |
| `lang/character_effect_descriptions_ko.lua` | 57개 Lv3 효과 설명 함수 한국어 |
| `engine/external/init.lua` | `require(path .. ".luasteam")` |
| `engine/external/luasteam.lua` | Steam shim (no-op, runCallbacks 포함) |
| `engine/graphics/font.lua` | Font CJK fallback + type guard |
| `engine/graphics/text.lua` | UTF-8 character iteration |
| `engine/graphics/graphics.lua` | CJK 폰트 자동 선택 |
| `engine/init.lua` line 46-86 | `engine_run`, setMode, state.sx 분기 (v0.1.4에 완전 제거) |
| `buy_screen.lua` line 1731-... | `CharacterIcon` (영웅 카드) |
| `buy_screen.lua` line 1758 | `on_mouse_enter` (hover info_text) |
| `arena.lua` line 445, 486, 513, 841, 843 | 게임 오버/축하/continue/new run/restart 버튼 |
| `mainmenu.lua` | 메인 메뉴 |
| `MODIFIED.md` | 변경 이력 (라이선스 의무) |
| `README.md` | 한국어 사용 설명 |
| `~/Library/Application Support/LOVE/SNKRX/state.txt` | 상태 캐시 (삭제 가능) |