# Console cursor after drawGameCanvas + 3 sequential diagnosis lessons

원본 패턴은 `references/bytepath-v0.2.x-console-menu-cursor-drift.md`에 누적 line_y 버그로 기록되어 있음. 이 reference는 **그 이후 5+ 패치 사이클**에서 발견된 두 번째-레벨 함정을 기록:

1. **카메라 메서드 nil 함정** (STALKER-X Camera에 getCameraCoords 없음)
2. **셰이더 위에서 그려진 UI는 누적 셰이더 효과를 받아 사라짐**
3. **순차 진단 워크플로** — 5번 가설 빗나간 후 "순차적으로 생각해보고" 사용자 교정

## 시퀀스 (2026-07-22)

### 가설 1: 텍스트 매칭 (`line.text:find('escape') + 'type @'`)
`self.lines`를 순회하며 target 텍스트 매칭. → "Your objective is to escape this terminal..."도 'escape' 매칭. AND 조건으로 'type @' 함께 매칭했지만 `Your` 줄엔 `@` 없음. 첫 매칭은 menu '~ type @escape# to escape' 줄 → 그 `line.y` 사용.

문제: 화면에 보이는 cursor가 'Your objective' 줄 위에 그려짐 (사용자 캡쳐). 메뉴 줄은 그 다음 줄 (12 px 아래). 즉 1줄 차이 발생.

### 가설 2: 직접 화면 좌표 계산
`menu_line.y` 그대로 사용해 `rectangle('fill', ... menu_line.y + offset ...)`. → 검증 사용자 "커서가 안 보임".

### 가설 3: `camera:getCameraCoords` 호출
`camera.getCameraCoords(menu_line.x, menu_line.y, 0, 0, gw, gh)` → **`nil` 반환**.

원인:
- `Camera = require 'libraries/STALKER-X/Camera'` (main.lua line 16)
- `camera = Camera()` (STALKER-X 인스턴스)
- STALKER-X/Camera는 `getCameraCoords`, `getWorldCoords`, `getMousePosition` 메서드를 정의하지 않음 (`libraries/STALKER-X/Camera.lua`에 `function Camera:getMousePosition()` 1줄만 정의).
- hump/camera를 가져왔다가 안 섞였는지 확인 필요 (실제 BYTEPATH는 STALKER-X만 사용).

→ `cx, cy = nil, nil` 반환 후 `if cy >= -16` 평가에서 silent fail. cursor 안 그려짐.

### 가설 4: 메뉴 line 객체를 직접 추적
`bytepathMain`에서 addLine 직후 `self.lines[#self.lines]` 캡처 → `self.bytepath_main_menu_lines = {key = ConsoleLine}`. cursor 그릴 때 `self.bytepath_main_menu_lines[key].y`로 직접 그리기.

검증 사용자: 여전히 cursor 안 보임.

### 가설 5 (진짜 원인): 셰이더 파이프라인 통과 후 cursor 사라짐
Console 룸은 Classes/SkillTree와 달리 **multi-pass 셰이더 (glitch + rgb_shift + distort) 유지**. cursor를 `main_canvas` 안 (=line 137, 셰이더 패스 진입 직전)에서 그리면:

1. `glitch.frag` 통과: `position.x += (glitch_pixel.r*2.0 - 1.0)` — GlitchDisplacement에 의해 가로 분리
2. `rgb_shift.frag` 통과: R, G, B 채널 분리 → 1.0 alpha saturate
3. `distort.frag` 통과: `+ x_offset + rgb_offset*0.003` 수평 분리 + scanline

→ 누적 셰이더 효과로 cursor 사각형이 사라지거나 transform되어 보이지 않게 됨.

### 진짜 픽스: drawGameCanvas 후에 직접 그리기
```lua
love.graphics.setColor(1, 1, 1, 1)
love.graphics.setBlendMode('alpha', 'premultiplied')
drawGameCanvas(self.final_canvas)

-- AFTER the shader pass, in screen space:
if self.bytepath_main_active and self.bytepath_main_menu_lines then
    local idx = self.bytepath_main_selection_index
    local key = self.bytepath_main_texts[idx]
    local menu_line = self.bytepath_main_menu_lines[key]
    if menu_line then
        local half_h = self.font:getHeight()
        local y_top = menu_line.y + math.floor(half_h/2) - half_h + 2
        love.graphics.setBlendMode('alpha')
        love.graphics.setColor(r, g, b, 128/255)
        love.graphics.rectangle('fill', 8 + x_offset - 2, y_top, width + 4, half_h)
        love.graphics.setColor(1, 1, 1, 1)
    end
end
```

→ 셰이더 효과 없이 깨끗한 화면 좌표에 cursor 그려짐.

## 교훈 (다음 세션이 즉시 알았으면 좋을 것)

### L1. 누적 좌표 추적 vs 객체 레퍼런스 추적
- ❌ `self.bytepath_main_y = self.line_y + N*12` — line_y 누적에 따라 viewport 밖으로 밀려남
- ✅ `self.bytepath_main_menu_lines = {key = ConsoleLine_obj}` — addLine 반환 객체 직접 보관

`addLine`은 `table.insert(self.lines, ...)`만 하고 **nil을 반환**한다는 점 주의:
```lua
self.bytepath_main_menu_lines[spec.key] = self.lines[#self.lines]
-- (not: self.bytepath_main_menu_lines[spec.key] = self:addLine(...))
```

### L2. 셰이더 위 UI는 drawGameCanvas *후*
multi-pass 셰이더를 유지하는 룸(Console, Options, Achievements 등)에서 UI 반투명 오버레이(cursor, highlight, 모달)는 `drawGameCanvas()` 호출 후 screen 좌표에 그릴 것:
- ✅ drawGameCanvas 후: 셰이더 없음, 정확히 위치에 표시
- ❌ main_canvas 안 (셰이더 패스 진입 전): glitch + rgb_shift + distort 모두 통과
- ❌ final_canvas 안 (distort 셰이더 적용 중): distort 셰이더 통과

### L3. STALKER-X Camera는 getCameraCoords 없음
BYTEPATH는 `Camera = require 'libraries/STALKER-X/Camera'` (hump/camera 아님). 카메라 좌표 변환 메서드가 정의돼 있지 않음 → `nil` 반환.

대안:
- screen 좌표 직접 계산 (camera가 viewport (0,0)~(gw,gh)에 있고 위치 (0,0)일 때)
- `world.x = screen.x`, `world.y = screen.y` 사용

### L4. 순차 진단 워크플로 (사용자 교정)
5번의 가설이 빗나간 후 사용자 요청: **"순차적으로 생각해보고 다시 처리해봐"**.

원칙: **2번 이상 가설 빗나가면 가설 중단 + 순차 진단**:
1. 증상의 객관적 사실 정리 (화면 어디에 무엇이 보이는가)
2. 다른 룸과 동작 비교 (Classes/SkillTree는 정상, Console만 비정상)
3. 진짜 차이점 = 원인 (shaders 있음 vs 없음)
4. 한 가지 픽스 + 검증

## 진짜 픽스 적용

**rooms/Console.lua**:
- `bytepathMain` (line 273~): menu_specs 8개 → `self.bytepath_main_menu_lines[key] = self.lines[#self.lines]`
- `bytepathMain2` (line 340~): 동일 패턴
- `Console:draw` (line 170~): cursor는 `drawGameCanvas(self.final_canvas)` *후* screen 좌표 직접 그림
- `_menu_suffix(key)` 헬퍼로 menu 텍스트 재구성

## 검증

- 헤드리스: stderr 비어있음, 프로세스 정상 — 셰이더 silently fail은 헤드리스로 절대 못 잡으므로 GUI 검증 필수
- GUI: 8개 menu line 정확히 그려지고 cursor가 선택된 줄 위에 정확히 표시. 셰이더 효과 무관.
