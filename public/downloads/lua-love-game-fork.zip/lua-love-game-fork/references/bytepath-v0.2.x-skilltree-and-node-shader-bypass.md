# BYTEPATH-ex SkillTree/Node 셰이더 우회 + 선택 강조 recipe (v0.12)

작성: 2026-07-22 (bytepath-ex SkillTree = Passives 룸 디버깅 세션)

## 배경

`rooms/SkillTree.lua` + `objects/Node.lua` + `objects/Line.lua`에서 6단계 진화:

1. v0.10 — 셰이더 우회 + 0..1 색상 정규화로 글자 saturate 해소
2. v0.11 — `kb_enter`(fleft/return) 키 핸들러 부재 발견 → SkillTree:update에 single-source-of-truth 추가
3. v0.11 — 카메라 자동 핏 (트리 노드 좌표 min/max → 카메라 lookAt + 0.9× 스케일)
4. v0.12 — `Node:draw`에 `is_selected` 분기 (노란 채움 + 두꺼운 외곽선), 모든 setColor 0..1 정규화
5. v0.12 — `Line:update/draw` 3-state (idle/linked-to-selection/bought) + `setLineWidth` 캐싱
6. v0.12 — `Node:update`의 color 분기에 `is_kb_selected` 분기 (skill_point_color 적용)

이 6단계는 "원본 BYTEPATH 룸 룸 하나를 셰이더 우회 + 카메라 핏 + 노드/라인 강조 + 키보드 모드 안정화로 통째 옮긴 recipe"로 승격할 가치가 있다. 다음 LÖVE 게임 룸 마이그레이션에서 그대로 복제.

## M-7.6 (v0.12 신규) — 셰이더 우회 + 선택 강조 통합 패턴

BYTEPATH `SkillTree:draw` 원본은 5-cavas 셰이더 파이프라인 (`glitch_canvas`, `main_canvas`, `temp_canvas`, `final_canvas` + 4-pass: glitch → rgb_shift → distort → 화면). 셰이더가 글자/UI를 saturate해서 검은 화면 패턴. **v0.6 M-6 패턴은 `camera:attach + 직접 line:draw` 한 단계** 였지만, SkillTree에서는 다음이 모두 필요했다:

```lua
function SkillTree:draw()
    -- 셰이더 파이프라인 우회
    love.graphics.setFont(self.font)
    camera:attach(0, 0, gw, gh)

    -- 그리드 (셰이더 안 거치고 직접 그리기)
    love.graphics.setColor(1, 1, 1, 4/255)        -- 0..1 알파
    love.graphics.line(0, -grid_h/2, 0, grid_h/2)
    -- ...

    -- 노드와 라인 직접 그리기
    love.graphics.setLineWidth(1/camera.scale)
    for _, line in pairs(self.lines) do line:draw() end
    for _, node in pairs(self.nodes) do node:draw() end
    love.graphics.setLineWidth(1)
    camera:detach()

    -- HUD 직접 그리기 (skill points, nodes count, keys legend)
    -- ...

    -- Stats rectangle (per-node hover tooltip) — pushRotateScale/pop 짝 유지
    -- ...
end
```

**핵심 결정**:

| 항목 | 우회 전 | 우회 후 |
|------|---------|---------|
| 색상 | `{r, g, b}` 0..255 (셰이더 입력 시 saturate) | `{r/255, g/255, b/255}` 0..1 |
| 셰이더 | glitch + rgb_shift + distort 4-pass | 없음 (직접 draw) |
| 카메라 attach/detach | 글자 가림 + 셰이더 한 번 더 적용 | attach/detach 한 번만 |
| `stats_rectangle_sx` 보간 | 셰이더 효과 가림 | 그대로 작동 |
| glitch 효과 | 분위기 | 잃음 (받지만) |

**트레이드오프**: 룸 분위기 (CRT glitch) 잃음. 받지만 글자가 흩뜨리면 사용자가 무엇을 선택했는지 모름 → 가독성 우선.

## M-10 (v0.12 신규) — Node 선택 강조 + 라인 3-state 패턴

원본 `Node:draw`는 `self.color`만 외곽선에 그렸고 (rgb `{default_color[1]/2, ...}` 50% 어두운 회색), 선택 시에도 색상 변화 없음 → 사용자가 "선이 두꺼워졌을 뿐 색상이 안 바뀌었다"고 보고. `Line:draw`는 양쪽 노드 모두 `bought=true`일 때만 흰색 두꺼운 선 → 키보드 선택한 노드와 연결된 라인은 강조 안 됨.

**3-state Line + Node 강조 패턴**:

```lua
-- Line:update — 3-state
local kb_id = current_room and current_room.selected_kb_node_id
local linked_to_selection = (self.node_1.id == kb_id) or (self.node_2.id == kb_id)
local both_bought = self.node_1.bought and self.node_2.bought

if both_bought then
    self.selected = true
    self.color = {1, 1, 1, 1}                                       -- 흰색 두꺼운 (bought path)
    self.line_width = 2.5/camera.scale
elseif linked_to_selection then
    self.selected = true
    self.color = {skill_point_color[1]/255, skill_point_color[2]/255, skill_point_color[3]/255, 1}
    self.line_width = 2/camera.scale                                  -- 노란색 중간 (선택 연결)
else
    self.selected = false
    self.color = {128/255, 128/255, 128/255, 64/255}                -- 디밍 회색 (idle)
    self.line_width = 1/camera.scale
end

-- Line:draw — 캐싱된 line_width 사용
love.graphics.setLineWidth(self.line_width or (1/camera.scale))
love.graphics.setColor(self.color)
for i = 1, #self.points do
    local point = self.points[i]
    local next_point = self.points[i+1]
    if next_point then love.graphics.line(point.x, point.y, next_point.x, next_point.y) end
end
```

```lua
-- Node:draw — is_selected 분기 + size별 강조
local is_selected = current_room and current_room.selected_kb_node_id == self.id
    and (current_room.moving_with_kb or self.hot or self.enter_hot)

if self.size == 1 then
    love.graphics.setColor(background_color[1]/255, background_color[2]/255, background_color[3]/255)
    love.graphics.rectangle('fill', self.x - 8, self.y - 8, 16, 16)
    if is_selected then
        local r, g, b = skill_point_color[1]/255, skill_point_color[2]/255, skill_point_color[3]/255
        love.graphics.setColor(r, g, b, 0.45)                              -- 내부 45% 투명 노랑
        love.graphics.rectangle('fill', self.x - 7, self.y - 7, 14, 14)    -- 내부 강조
        love.graphics.setLineWidth(2/camera.scale)                         -- 외곽 2×
        love.graphics.setColor(r, g, b, 1)
        love.graphics.rectangle('line', self.x - 8, self.y - 8, 16, 16)
    else
        -- 원본 외곽선 그리기
    end
    -- ...
end
```

```lua
-- Node:update — is_kb_selected에 따른 color 선택
local r, g, b = default_color[1], default_color[2], default_color[3]
local is_kb_selected = current_room and current_room.selected_kb_node_id == self.id
                          and (current_room.moving_with_kb or self.hot or self.enter_hot)
if self.bought then
    self.color = {r, g, b, 1}
elseif is_kb_selected then
    local sr, sg, sb = skill_point_color[1], skill_point_color[2], skill_point_color[3]
    self.color = {sr, sg, sb, 1}                                          -- 노란 외곽선
elseif self.selected then
    self.color = {r/1.5, g/1.5, b/1.5, 1}
else
    self.color = {r/2, g/2, b/2, 1}
end
```

**판별 신호**: "선택은 되는데 표시가 안 보인다 / 색상이 그대로다 / 두꺼워진 것만 다르다" → **M-10 의심**.

## M-11 (v0.12 신규) — `kb_enter` 키보드 모드 single-source-of-truth

BYTEPATH는 `kb_enter` 액션을 fleft/return 키에 바인딩했지만 (SkillTree.lua line 91-92), **`SkillTree:update`는 이 액션을 직접 잡지 않았다**. `Node:update` line 61에서 `self.id == current_room.selected_kb_node_id and input:pressed('kb_enter')`가 발동해야 buy가 시작됐는데, **`moving_with_kb`가 false인 상태에서 (예: 사용자가 마우스 클릭 한 번이라도 한 경우) `selected_kb_node_id`가 screen 안 노드와 안 맞아서 작동 안 함**.

**더 큰 문제**: Node:update를 `self.id == current_room.selected_kb_node_id and input:pressed('kb_enter')`로 두면, **모든 노드가 매 프레임 자기 자신이 selected인지 검사** → `input:pressed('kb_enter')`이 1프레임당 1번 true인데 매 노드 update line에서 동시에 처리 가능. Race condition.

**해결 패턴 — SkillTree:update에 single-source-of-truth**:

```lua
function SkillTree:update(dt)
    self.timer:update(dt)
    self.area:update(dt)
    camera.smoother = Camera.smooth.damped(10)

    -- ⭐ 모든 kb_enter 처리를 여기서 단일 처리. 가장 가까운 화면 안 노드만 selected로.
    if input:pressed('kb_enter') and not self.buying then
        local best_id, best_dist = nil, math.huge
        for id, node in pairs(self.nodes) do
            local cx, cy = camera:getCameraCoords(node.x, node.y, 0, 0, gw, gh)
            if cx >= -16 and cx <= gw + 16 and cy >= -16 and cy <= gh + 16 then
                local d = (cx - gw/2)^2 + (cy - gh/2)^2
                if d < best_dist then best_id, best_dist = id, d end
            end
        end
        if best_id then
            self.moving_with_kb = true
            self.selected_kb_node_id = best_id
            self.nodes[best_id]:enterHot()
        end
    end

    -- (나머지 키보드 처리 — direction, zoom, escape, apply/cancel ...)
end

-- Node:update line 61 — 단순화. 더 이상 self.id == selected_kb_node_id를 스스로 갱신하지 않음.
if ((self.hot and input:pressed('left_click')) or
    (self.id == current_room.selected_kb_node_id and input:pressed('kb_enter'))) and not current_room.bought_nodes_this_frame then
    -- buy 처리
end
```

**판별 신호**: "Enter를 누르는데 패시브가 선택 안 됨 / 키보드로 조작이 안 됨" → M-11 의심.

**원칙**: 액션이 1프레임에 1번만 true라면 핸들러가 **룸 update의 한 곳에만** 존재해야 한다. 노드별 update에서 분산 처리하면 race + 첫 노드/마지막 노드/모든 노드 중 누구 last가 selected가 되는지 비결정.

## M-12 (v0.12 신규) — 트리/그래프 룸 자동 핏

원본 `SkillTree:new()`는 `camera:lookAt(32, 96)` 한 줄 + `camera.scale` 디폴트 1.0 → 480x270 캔버스에서 트리가 화면 좌상단에 쏠려서 절반 이상이 빈 공간.

**자동 핏 recipe**:

```lua
function SkillTree:new()
    -- ... 캔버스, 노드 준비 ...

    -- 트리 노드 좌표 min/max → 중앙 lookAt + 90% 자동 스케일
    local min_x, min_y, max_x, max_y = math.huge, math.huge, -math.huge, -math.huge
    for _, t in pairs(self.tree) do
        if t.x < min_x then min_x = t.x end
        if t.y < min_y then min_y = t.y end
        if t.x > max_x then max_x = t.x end
        if t.y > max_y then max_y = t.y end
    end
    local tree_w = math.max(1, max_x - min_x)
    local tree_h = math.max(1, max_y - min_y)
    local cx = (min_x + max_x) / 2
    local cy = (min_y + max_y) / 2
    camera:lookAt(cx, cy)
    local scale_x = (gw * 0.9) / tree_w
    local scale_y = (gh * 0.9) / tree_h
    camera.scale = math.min(scale_x, scale_y)
    self.tree_center_x, self.tree_center_y = cx, cy

    -- ... 노드 + 라인 생성 ...
end
```

**판별 신호**: "큰 룸에 진입했는데 화면 절반이 검은색 / 노드가 한쪽에 쏠림 / 줌을 끝까지 줄여야 보임" → M-12 의심.

## 검증 명령 모음 (M-7.6~M-12 종합)

```bash
# A. 룸별 셰이더/캔버스 사용 매트릭스 (M-7.5)
for name in rgb_canvas glitch_canvas main_canvas temp_canvas final_canvas; do
  for f in rooms/*.lua; do
    uses=$(grep -c "self.$name" "$f")
    creates=$(grep -c "self.$name = love.graphics.newCanvas" "$f")
    if [ "$uses" -gt "$creates" ]; then
      echo "⚠ $f: $name uses=$uses creates=$creates"
    fi
  done
done

# B. 룸별 0..255 색상 잔재 (M-0)
for f in rooms/*.lua; do
  residue=$(grep -nE 'setColor\((127|222|255)(,| )' "$f" | wc -l)
  if [ "$residue" -gt 0 ]; then
    echo "⚠ $f: $residue 0..255 색상 잔재"
  fi
done

# C. 룸별 카메라 리셋 호출 (M-9)
for f in rooms/*.lua; do
  room=$(basename "$f" .lua)
  lookat=$(grep -c "camera:lookAt" "$f" | head -1)
  if [ "$lookat" -lt 1 ]; then
    echo "⚠ $room: :new()에서 카메라 리셋 호출 없음"
  fi
done

# D. 액션 핸들러 single-source-of-truth (M-11)
# 룸 update 안에 input:pressed('X')가 있되, 노드/라인 update 안에 같은 액션이 있으면 race 위험
grep -n "input:pressed('left_click')\|input:pressed('kb_enter')" rooms/*.lua objects/*.lua
# → 룸 update 1곳 + 노드 update 1곳이면 OK. 만약 노드 update 안에 여러 군데가 있으면 race.

# E. 트리/그래프 룸 자동 핏 (M-12) — camera.scale = ? (자동 핏 호출 있으면 OK)
grep -n "camera.scale = math.min" rooms/*.lua
```

## SKILL.md 본문와의 연결

- M-7.6 = M-6 (검은 화면) / M-7.5 (캔버스 누락) / M-0 (셰이더) 의 후속 — 원본 룸 draw()를 통째 우회하는 recipe로 확장
- M-10 = §5 카메라 + M-7.5 색상 강조의 룸 draw 단계로 편입
- M-11 = M-3-bis (boipushy pressed nil-safe) 의 후속 — 액션 핸들러 multiple-source race 회피의 원리 적용을 룸 단위로 확장
- M-12 = §5 카메라 + §5-3 비표준 사이즈 + §5-5 좌표계 분리의 룸 진입 default recipe
