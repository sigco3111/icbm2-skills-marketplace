# BYTEPATH 계열 고정 저해상도 콘솔의 한글 고해상도 레이어 패턴

## 적용 조건

- LÖVE 게임이 480×270 같은 낮은 내부 캔버스에 UI를 그린 뒤 창 크기로 확대한다.
- 영문 픽셀 글꼴은 괜찮지만 한글 TrueType 글꼴은 깨지거나, 줄 간격을 확보하려고 축소하면 판독 불가가 된다.
- 도움말·디바이스·정보·초기화·크레딧·명령 입력 등 여러 터미널 화면이 `ConsoleLine`/`ConsoleInputLine`을 공유한다.

## 실패했던 접근

1. **12px 한글을 0.5배 출력**
   - 실제 글리프 높이가 약 6px가 되어 한글 획이 소실된다.
2. **고해상도 폰트와 배율을 공용 렌더러에 바로 끼워 넣기**
   - 기준선, 폭, 배경 박스 계산이 기존 480×270 좌표와 섞여 잘림과 겹침이 발생했다.
3. **도움말에 기존 한글 위로 새 글자를 덮어쓰기**
   - 원래 `ConsoleLine`과 새 텍스트가 동시에 살아 있어 겹치기 쉽다.
4. **헤드리스 무오류를 시각 성공으로 간주**
   - 문법과 실행 로그가 정상이어도 가독성은 실패할 수 있다.

## 검증된 구조

### 1. 고해상도 레이어를 분리한다

- 기존 콘솔: 480×270, 영문 픽셀 글꼴과 셰이더 유지.
- 한글 레이어: 960×540 투명 캔버스.
- 기존 콘솔 셰이더 합성이 끝난 뒤 고해상도 한글 레이어를 창 좌표에 합성한다.
- 한글은 저해상도 패스에서 생략해 이중 출력을 방지한다.

```lua
self.highres_console_canvas = love.graphics.newCanvas(gw*2, gh*2)
self.highres_console_canvas:setFilter('linear', 'linear')
```

최종 합성:

```lua
local ox, oy, scale = getLetterboxOffset()
love.graphics.draw(self.highres_console_canvas, ox, oy, 0, scale/2, scale/2)
```

### 2. 한글 폰트 래스터와 표시 크기를 분리한다

- 원본 글리프: `fonts.kr_24`
- 한글 폰트만 `linear, linear`
- 표시 배율: 사용자가 확인한 기본값 `0.7`
- 기존 12px 폰트를 50%로 줄이지 않는다.

```lua
local korean_font = fonts.kr_24
local korean_scale = 0.7
love.graphics.setFont(korean_font)
love.graphics.print(text, x, y, 0, korean_scale, korean_scale)
```

영문 픽셀 글꼴에는 기존 `nearest`를 유지한다. 한글 TrueType에만 linear를 적용한다.

### 3. 도움말에서 공용 터미널로 확장하는 순서

1. 도움말 하나를 독립 `drawHighResolution()` 화면으로 먼저 구현한다.
2. 사용자가 가독성·크기·행간을 육안 승인할 때까지 공용화하지 않는다.
3. 승인된 해상도와 배율을 `ConsoleLine:drawHighResolution()`과 `ConsoleInputLine:drawHighResolution()`으로 승격한다.
4. 디바이스 등 모든 터미널 모듈이 공용 라인 버퍼를 사용하면 모듈별 복사 패치를 피한다.
5. 모듈 자체가 도형/직접 `printT`를 그리는 부분은 별도 좌표 검증이 필요하다.

## 폭·기준선·행간 규칙

- 고해상도 캔버스 좌표는 기존 좌표의 2배다.
- 한글 표시 폭은 `font:getWidth(text) * korean_scale`이다.
- 문자 단위 혼합 출력이면 다음 글자의 x 누적에도 같은 배율을 반영한다.
- 행간은 글자 축소로 해결하지 않는다. 고해상도 좌표계에서 별도 `row_h`를 둔다.
- 선택 배경과 커서는 같은 고해상도 좌표계에서 계산한다.
- 화면별 미세 보정은 배율이 아니라 `y`와 `row_h`만 조정한다.

## 사용자 교정에서 나온 작업 원칙

- 한글 가독성이 떨어지면 폰트 크기만 반복 조정하지 말고 먼저 옵션·패시브처럼 정상인 화면의 렌더 경로를 비교한다.
- 연속 패치가 악화되면 즉시 마지막 정상 상태로 원복하고 구조를 다시 분석한다.
- 한 화면에서 승인받기 전에 전체 터미널로 확대하지 않는다.
- 승인 후에는 그 화면의 **해상도와 폰트 배율을 그대로 공용화**한다.

## 자동 검증

구조 검증 항목:

- 2배 콘솔 캔버스 존재
- `fonts.kr_24` 사용
- `korean_scale = 0.7`
- 한글 저해상도 패스 생략
- 셰이더 이후 고해상도 레이어 합성
- `ConsoleLine`과 `ConsoleInputLine` 모두 고해상도 경로 존재

실행 검증:

```bash
luac -p main.lua rooms/Console.lua objects/ConsoleLine.lua objects/ConsoleInputLine.lua objects/modules/*.lua
love .
```

마지막 검증은 반드시 사용자 스크린샷으로 한다. `love .` 로그가 비어 있는 것만으로 가독성을 통과 처리하지 않는다.
