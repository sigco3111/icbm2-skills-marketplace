# BYTEPATH 룸 4-pass 셰이더 → 직접 draw 패턴 (Room 재작성 reference)

> sigco3111/bytepath-ex v0.2.0+ 작업 (2026-07-22). **이 reference는 모노리식 게임의 룸 (`Class:draw()` / `SkillTree:draw()` 같은)이 셰이더 파이프라인으로 글자가 가려질 때** 적용하는 표준 픽스 패턴을 정리한다.

## 왜 룸을 다시 쓰는가

BYTEPATH의 모든 룸 (Console, Stage, SkillTree, Classes, Achievements, AchievementScreenshots, Options)은 같은 4-pass 셰이더 파이프라인을 사용한다:

```
glitch_canvas  → drawOnly({'glitch'})    ← GlitchDisplacement GameObject 이펙트
main_canvas    → 메인 UI 그리기
temp_canvas    → main_canvas + glitch shader (rgb shift 입력)
final_canvas   → temp_canvas + rgb_shift shader
screen         → final_canvas + distort shader (scaled by sx,sy)
```

LÖVE 0.10.2 → 11.5 마이그레이션 v0.6-v0.8에서:
- `v0.6`: 셰이더 uniform 타입 자동 변환 변경으로 검은 화면 silent fail
- `v0.8`: 셰이더 신택스 (`Image`, `extern`) 미지원 + 0..255 색상 saturate → 흰색

Console과 Stage는 v0.8 작업에서 색상 정규화 완료. **Classes와 SkillTree는 마이그레이션 당시 다른 작업 중이었고 정규화 누락**. 작업자가 두 룸을 켜자마자 흰 사각형/줄무늬만 보임.

## 룸 재작성 표준 패턴

### 시그니처

```lua
function <Room>:draw()
    love.graphics.setFont(self.font)
    camera:attach(0, 0, gw, gh)
    -- 메인 UI를 여기 직접 그린다 (4-pass 셰이더 우회)
    -- ...
    camera:detach()
    -- HUD/오버레이는 camera:detach 후 그린다 (letterbox 공간)
    love.graphics.setColor(1, 1, 1, 1)
end
```

### 4-pass → 직격 변환 규칙

| 4-pass 원본 | 직격 변환 |
|------------|----------|
| `love.graphics.setCanvas(self.X_canvas); ...; love.graphics.setCanvas()` | 빼고 `camera:attach(0, 0, gw, gh)` 안에서 직접 호출 |
| `setShader(shaders.X); X:send(...)` | 빼기 (셰이더 손실) |
| `love.graphics.setColor(255, 255, 255)` | `love.graphics.setColor(1, 1, 1)` |
| `love.graphics.setColor(127, 127, 127)` | `love.graphics.setColor(127/255, 127/255, 127/255)` |
| `love.graphics.setColor(255, 255, 255, 4)` | `love.graphics.setColor(1, 1, 1, 4/255)` |
| `unpack(default_color)` 같은 글로벌 | `default_color[1]/255, default_color[2]/255, default_color[3]/255` |
| 글로벌 컬러 `{r,g,b}` (0..255) | `setColor` 직전에 매번 `/255` 정규화 |

### main_canvas도 빼기

`setCanvas(self.main_canvas); love.graphics.clear()` 로 시작하던 마무리는 `camera:attach(0, 0, gw, gh)` 만으로 충분. main_canvas가 미리 할당되었으면 GC에 맡기고 (room:destroy에서 nil 처리하면 더 깨끗하지만 v0.2에선 draw만 교체).

### push/pop stack 함정

원본에 `pushRotate/Scale` + `love.graphics.pop()` 짝이 있으면 **camera:detach 후 그리지 말 것** — push/pop stack이 camera transform과 같이 뽑힐 수 있어 transform 깨짐. SkillTree stats 박스처럼 push/pop이 있으면 camera:attach 안에서 호출하고 pop까지 닫을 것.

### 예시 — SkillTree:draw 재작성 전/후

```lua
-- BEFORE (4-pass 셰이더)
function SkillTree:draw()
    love.graphics.setCanvas(self.glitch_canvas)
    love.graphics.clear()
        love.graphics.setColor(127, 127, 127)  -- 0..255 saturate
        -- ...
    love.graphics.setCanvas()
    love.graphics.setCanvas(self.main_canvas)
        camera:attach(0, 0, gw, gh)
        -- 메인 그리기 (안에서도 0..255 색상 잔재)
        camera:detach()
    love.graphics.setCanvas()
    -- 3-pass 셰이더: glitch → rgb_shift → distort
    if not disable_expensive_shaders then
        love.graphics.setShader(shaders.distort)
        -- ...
    end
    love.graphics.draw(self.final_canvas, 0, 0, 0, sx, sy)
end
```

```lua
-- AFTER (직격 draw, 셰이더 우회)
function SkillTree:draw()
    love.graphics.setFont(self.font)
    camera:attach(0, 0, gw, gh)
    -- 모든 setColor는 0..1 정규화
    love.graphics.setColor(1, 1, 1, 4/255)
    -- 그리드 라인 그리기
    -- ...
    -- 노드와 라인 그리기
    -- ...
    camera:detach()
    -- HUD/SP 표시 등 letterbox 공간 그리기
    -- ...
    love.graphics.setColor(1, 1, 1, 1)
end
```

## 룸 진입 시 카메라 상태 잔재 함정

Console → SkillTree 같이 룸 전환 시 Console은 `camera:lookAt(gw/2, gh/2)` + `camera.scale = 1`을 호출하지만 콘솔 줄이 길어지면 `line_y > gh`에서 카메라가 y로 누적됨. **Console → SkillTree** 진입 시 카메라 y가 화면 밖으로 밀려 스킬 트리가 안 보임.

각 룸:new()에서 카메라를 명시적으로 리셋:

```lua
function <Room>:new()
    -- ...
    camera:lookAt(gw/2, gh/2)
    camera.scale = 1
    -- SkillTree 같이 줌/패닝이 필요하면 room:new()에서 별도 설정
end
```

SkillTree 자체는 화면 핏을 위해 별도 시점이지만 **기본 룸 전환 시점 안전망**으로 둘 다 호출하는 게 안정.

## 검증 — 헤드리스 검증만으로는 부족

LÖVE 11.5의 4-pass 셰이더 파이프라인은 **헤드리스 실행으로는 절대 silent fail을 못 잡는다**. stderr에 에러도 안 찍히고 process는 정상. 다음 단계:

1. **`love . --test` 또는 `(love . &)` 형태로 헤드리스 부팅** → stderr 비어있으면 require + 메인 루프 진입 OK만 확인 (드라이런 1단계)
2. **반드시 사용자 Mac GUI에서 띄워서 픽셀 확인** → 흰 사각형/검은 화면은 헤드리스로는 못 잡음

보고 원칙: 헤드리스 stderr가 비어있다고 "정상"이라고 결론 내리지 말 것. GUI 검증 OK 후에만 사용자에게 "픽스 완료" 보고.

## canvas 누락 함정 (M-0bis)

`<Room>:draw()`에서 `setCanvas(self.X_canvas)` 호출하는데 **`<Room>:new()`에서 `self.X_canvas = love.graphics.newCanvas(gw, gh)` 안 만들었을 때** silent nil. LÖVE가 `setCanvas(nil)`을 default 캔버스로 폴백해서 다음 셰이더 패스가 빈 캔버스를 그려 흰 saturate.

검색:

```bash
grep -nE 'setCanvas\(self\.' /Users/mac/work/bytepath-ex/rooms/<Room>.lua
grep -nE 'newCanvas' /Users/mac/work/bytepath-ex/rooms/<Room>.lua
```

이 둘의 셀렉터를 비교해서 setCanvas에 있는데 newCanvas에 없는 게 있으면 즉시 추가. Classes 룸에서 `rgb_canvas`가 1개 누락된 게 흰 사각형의 진짜 원인이었음 (v0.2.0 실측).

## 흔한 함정 정리

### 1. v0.8 색상 정규화 일부 누락

원본 작업 시 (a) Console, (b) Stage, (c) Options는 v0.8에서 0..1 정규화 완료. **마이그레이션 시점에 다른 룸을 건드리면 정규화가 안 돼있을 수 있다**. 룸을 새로 픽스할 때마다 grep으로 확인:

```bash
grep -nE 'setColor\((255|127|222)' rooms/<Room>.lua
```

결과가 있으면 0..1로 정규화.

### 2. cancel/error 메시지 박스도 정규화 누락

`drawCenteredRectangle('fill', x, y, w, h, {16, 16, 16})` 같은 헬퍼 호출 — `utils.lua`의 헬퍼는 그대로 0..255 인자 받지만 love.graphics.setColor는 0..1이 필요. **헬퍼 호출 측의 인자를 정규화**하거나, 헬퍼 자체를 0..1로 마이그레이션하는 두 가지 선택. 전자가 룸 단위 작업 시 더 빠름.

### 3. 입력 핸들러는 셰이더와 무관

룸을 직접 draw로 재작성해도 **update/keypressed/mousepressed는 그대로 작동**. 셰이더 silent fail이 draw에만 영향. 입력 정상 작동 + 화면 가리면 = 거의 항상 M-0/M-6 셰이더 문제.

### 4. Node:update의 race condition (SkillTree enter key)

Node:update가 모든 노드에서 매 프레임 호출되므로 그 안에서 kb_enter 처리하면 한 프레임에 여러 노드가 selected_kb_node_id를 변경하는 race.

해결: `Room:update`에서 한 번만 kb_enter 처리하고 화면 중앙에 가장 가까운 노드만 골라서 `selected_kb_node_id`에 할당. 그 후 Node:update가 line 61에서 `(self.id == current_room.selected_kb_node_id and input:pressed('kb_enter'))`로 buy 처리.

원본 SkillTree의 `moving_with_kb` 의존은 **사용자가 한 번이라도 마우스를 클릭하면 false가 되어 키보드 모드 해제**됨. Race를 막으려면 `Room:update`에서 `selected_kb_node_id` 강제 갱신 + `moving_with_kb = true` 유지.

### 5. 트리 자동 핏은 outlier 좌표에 영향받음

BYTEPATH 같은 큰 트리에서 min/max로 자동 핏하면 1~2개 외각 노드가 box 부풀림. 해결:

- **P10-P90 (또는 P5-P95) percentile로 fit** — outlier 10-20% 무시
- 1.0 ~ 2.5 사이 scale로 클램프 (트리 정사각형일 때 2.0 줌이 적당)

```lua
table.sort(raw_xs); table.sort(raw_ys)
local pick = function(arr, q)
    local i = math.max(1, math.min(#arr, math.floor(q * (#arr + 1))))
    return arr[i]
end
local p10_x, p90_x = pick(raw_xs, 0.10), pick(raw_xs, 0.90)
local p10_y, p90_y = pick(raw_ys, 0.10), pick(raw_ys, 0.90)
-- ...
camera.scale = math.max(1.0, math.min(2.5, math.max(fit_scale_x, fit_scale_y) * 2))
camera:lookAt(cx, cy)
```

### 6. line/노드 색상 통일

bought 노드 + 선택 노드 + 연결 라인을 **하나의 accent color (예: `skill_point_color`)** 로 통일하면 시각적으로 한 path로 보임. 상태별 다른 색을 쓰면 화면이 noisy 해짐.

### 7. clamp scale 보존

zoom in/out 핸들러가 `self.min_zoom`/`self.max_zoom` 한계 안에서만 작동하도록:

```lua
if input:pressed('zoom_in') or input:pressed('kb_zoom_in') then
    self.timer:tween('zoom', 0.2, camera,
        {scale = math.min(self.max_zoom or 2.5, camera.scale + 0.1)},
        'in-out-cubic')
end
if input:pressed('zoom_out') or input:pressed('kb_zoom_out') then
    self.timer:tween('zoom', 0.2, camera,
        {scale = math.max(self.min_zoom or 0.2, camera.scale - 0.1)},
        'in-out-cubic')
end
```

룸 :new()에서 `self.min_zoom = ...; self.max_zoom = ...` 저장. 한계 없으면 사용자가 너무 멀리 줌아웃해서 노드들이 1px로 보임.

## SkillTree 색상 상태 머신 패턴 (선택/연결/bought/idle 4-state)

```lua
function Line:update(dt)
    local kb_id = current_room and current_room.selected_kb_node_id
    local linked_to_selection = (self.node_1.id == kb_id) or (self.node_2.id == kb_id)
    local both_bought = self.node_1.bought and self.node_2.bought
    local r, g, b = skill_point_color[1], skill_point_color[2], skill_point_color[3]
    if both_bought then
        self.color = {r/255, g/255, b/255, 1}  -- purchased
        self.line_width = 2.5/camera.scale
    elseif linked_to_selection then
        self.color = {r/255, g/255, b/255, 1}  -- connecting
        self.line_width = 2/camera.scale
    else
        self.color = {128/255, 128/255, 128/255, 64/255}  -- idle
        self.line_width = 1/camera.scale
    end
end
```

Node 도 동일 패턴. **bought + selected + 연결** 3개 상태가 같은 accent color → 사용자가 한 path로 인식 가능.

## 룸 재작성의 트레이드오프

**잃는 것**:
- glitch 효과 (글자 흩뜨림)
- rgb_shift 효과 (RGB 채널 분리)
- distort 효과 (스캔라인 + 수평 fuzz)

**얻는 것**:
- 작은 UI 요소의 가독성 회복 (8px 글자 readable)
- 셰이더 호환성 함정 (M-0/M-6) 제거
- 다음 마이그레이션 시 또 깨질 위험 낮춤
- 헤드리스 검증만으로도 픽셀 결과 예측 가능

원래 셰이더 효과를 살리고 싶으면 v0.2+ 작업 시 한 셰이더씩 다시 켜면서 uniform 호환 작업. 다만 작은 버튼 글자에 셰이더 효과가 가독성을 해친다는 정량적 결론이 BYTEPATH 룸에서 나왔으므로 우선순위 낮음.
