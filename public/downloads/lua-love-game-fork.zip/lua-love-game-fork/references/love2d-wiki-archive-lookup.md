# LÖVE 2D 공식 wiki 미러 조회 패턴 (2026-07 검증)

## 문제

`love2d.org` (서브 경로 `/wiki/...`, `/forums/...` 포함)는 **Cloudflare 챌린지**(`cf_chl_opt` 쿠키 게이트)를 적용한다. curl 도 JS 실행 없이 곧장 HTTP 403 + 챌린지 HTML 로 떨어진다. fetch / browser 도 마찬가지.

## 해결: web.archive.org 미러

Wayback Machine 의 스냅샷이 거의 모든 페이지를 보관한다. 다음 URL 형식으로 사용한다.

```
https://web.archive.org/web/<YYYY>/https://love2d.org/wiki/<PAGE>
```

- `<YYYY>` 자리에는 **연도만** (예: `2024`, `2023`, `2022`) 또는 **YYYYMMDDhhmmss** (특정 스냅샷) 가능. 연도만 쓰면 가장 가까운 스냅샷을 자동 선택.
- 최신 자료는 `2024` 또는 `2025` 로 충분. 너무 오래된 것은 LÖVE 11.0 이후 API 변경을 놓칠 수 있으므로 `2022` 이후 권장.
- 최근 LÖVE 11.5 / 11.6 변경 반영은 `2025` 가 좋다 (예: `Font:setFilter` `Font:getDPIScale`).

신뢰 가능한 스냅샷 일자 (직접 검증):

| 페이지 | 사용한 미러 |
|---|---|
| `love.graphics.newFont` | `web.archive.org/web/20241215180439/https://love2d.org/wiki/love.graphics.newFont` |
| `Font:setFilter` | `web.archive.org/web/20220518171210/https://love2d.org/wiki/Font:setFilter` |
| `love.graphics.getDPIScale` | `web.archive.org/web/20250424104600/https://love2d.org/wiki/love.graphics.getDPIScale` |
| `love.window.fromPixels` | `web.archive.org/web/2024/https://love2d.org/wiki/love.window.fromPixels` |
| `love.graphics.newCanvas` | `web.archive.org/web/2024/https://love2d.org/wiki/love.graphics.newCanvas` |
| `love.graphics.newImage` | `web.archive.org/web/2024/https://love2d.org/wiki/love.graphics.newImage` |
| `love.graphics.print` | `web.archive.org/web/2023/https://love2d.org/wiki/love.graphics.print` |
| `love.graphics.draw` | `web.archive.org/web/2023/https://love2d.org/wiki/love.graphics.draw` |
| `HintingMode` | `web.archive.org/web/2024/https://love2d.org/wiki/HintingMode` |
| `Tutorial:Fonts and Text` | `web.archive.org/web/2024/https://love2d.org/wiki/Tutorial:Fonts_and_Text` |
| `Configuration` | `web.archive.org/web/2024/https://love2d.org/wiki/Configuration` |

## 차이점

- 미러 출력은 약간의 wombat wrapper (JS variable, archive 도구 모음) 가 앞에 붙는다. grep 가능한 텍스트는 본문 p/h2/pre 태그 안에 그대로 있다.
- 예제/코드 블록은 `<span class="n">...` 와 같은 syntax-highlight span 안에 들어가 있다. `sed 's/<[^>]*>//g'` 로 태그만 벗기면 본문이 깔끔하게 나온다.

## LÖVE 11.5 / 12.0 소스 코드 (1차 근거)

wiki 만으로 부족할 땐 GitHub 의 `love2d/love` 레포의 **`11.5` 태그 raw URL** 을 직접 본다. Cloudflare 챌린지 없음.

- `Font.cpp` 11.5 — `https://raw.githubusercontent.com/love2d/love/11.5/src/modules/graphics/Font.cpp`
  - 핵심 라인: `g.spacing = floorf(gd->getAdvance() / glyphdpiscale + 0.5f);`
  - 핵심 라인: `filter.mipmap = Texture::FILTER_NONE;` (폰트 텍스처는 mipmap 없음)
  - 핵심 라인: `image->setFilter(filter);` (Font 생성 시 받은 Filter 적용)
- `Font.h` 11.5 — `https://raw.githubusercontent.com/love2d/love/11.5/src/modules/graphics/Font.h`
- `TrueTypeRasterizer.cpp` 11.5 — `https://raw.githubusercontent.com/love2d/love/11.5/src/modules/font/TrueTypeRasterizer.cpp`
- `changes.txt` 11.5 — `https://raw.githubusercontent.com/love2d/love/11.5/changes.txt`

`12.0` (현재 latest) 의 경우 raw URL 의 `11.5` 를 `main` 으로 교체. 두 URL 중 11.5 가 안정적 (master 는 변경 중).

## 우회 실패 시 fallback 순서

1. **GitHub 소스 raw** — 가장 빠른 1차 근거. wiki 없이도 `Font::Font`, `setFilter`, `getDPIScale` 의 시그니처·동작은 확인 가능.
2. **DuckDuckGo HTML 검색** (`https://duckduckgo.com/html/?q=...`) — `love2d.org` 자체는 결과에 뜨지만 클릭하면 챌린지에 막힌다. 대신 결과의 **snippet** 만 읽어 URL list 확인 → 각 URL 을 미러로 다시 fetch.
3. (다른 옵션) LÖVE 포럼 글은 미러가 잘 없으므로 **DuckDuckGo snippet** 만으로 패턴 확인하는 데 그친다.

## 함정

- `https://love2d.org/wiki/...` 직접 fetch → "Just a moment...*{box-sizing:border-box;...}" 챌린지 페이지가 통째로 떨어진다. 텍스트로 grep 해도 안에 단어 하나 없어서 무의미하다. **챌린지 페이지가 5KB 이상이면 무조건 우회.**
- web.archive.org 미러도 일부는 챌린지 응답을 스냅샷한 것일 수 있다 (특히 2025-08 일부). 본문 안에 `content="cf"` 같은 마커가 보이면 다른 연도로 다시 시도.
- DuckDuckGo HTML 페이지 내 결과 URL 은 `//duckduckgo.com/l/?uddg=...&rut=...` 으로 한 번 더 redirect 된다. **redirect URL 보낸다 — 직접 응답 본문만 읽어서는 진짜 링크 추출이 어렵다**.
- GitHub raw API 는 `--max-time 15` 정도면 충분. 60초 기다릴 필요 없음.
