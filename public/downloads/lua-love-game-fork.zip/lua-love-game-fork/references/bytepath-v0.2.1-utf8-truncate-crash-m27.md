# M-27 — UTF-8 truncate 크래시 + shorten_utf8_last (BYEpath v0.2.1 4차 후속 세션, 2026-07-22)

> `s:sub(1, -2)` 패턴이 한글 1글자(3바이트) 중간에서 잘라 `'UTF-8 decoding error: Invalid UTF-8'` 크래시를 일으킴. **한글화 작업 시 substring/truncate에 byte 단위 절단 절대 금지**.

## 증상

```
Error: rooms/Options.lua:237: UTF-8 decoding error: Invalid UTF-8
Traceback:
  [love "callbacks.lua"]:228: in function 'handler'
  [C]: in function 'textWidth'
  rooms/Options.lua:237: in function 'draw'
  main.lua:181: in function 'draw'
  [love "callbacks.lua"]:168: in function <[love "callbacks.lua"]:144>
  [C]: in function 'xpcall'
```

부팅은 정상인데, 메뉴/옵션에서 라벨이 셀 너비 초과해서 truncate 로직이 도는 순간 크래시.

## 원인

```lua
-- rooms/Options.lua draw() (v0.27 이전, v0.28 commit 7ce55a8)
local label_text = row.label .. ':'
if textWidth(font, label_text) > label_col_w then
    while textWidth(font, label_text .. '..') > label_col_w and #label_text > 1 do
        label_text = label_text:sub(1, -2)  -- ❌ byte 단위 substring
    end
    label_text = label_text .. '..'
end
```

`디스플레이 모드:` = 26 바이트. `s:sub(1, -2)` = 24 바이트 → 마지막 2바이트 (한글 `:` 직전 글자의 일부)만 제거되어 **잘못된 UTF-8 시퀀스** 생성 → `textWidth(font, ...)` → `font:getWidth(text)` 호출 시 love2d가 **UTF-8 decode error** 크래시.

같은 버그가 Console GUI 메뉴 (`rooms/Console.lua:517`, `:538`)에도 있었음 — `label = label:sub(1, -2)` / `desc = desc:sub(1, -2)`. 한글 라벨은 짧아서 평소엔 잘 작동하지만 truncate 경로 타면 크래시.

## Lua 5.1 + 한글 환경의 UTF-8 byte/jchar 함정

| 메서드 | 단위 | 한글 환경 동작 |
|---|---|---|
| `s:sub(i, j)` | **byte** | 한글 1글자 = 3 byte. `s:sub(1, -2)` = 마지막 **2 byte** 잘림 → 한글 글자 깨짐 |
| `s:byte(i)` | byte | 한 글자 = 3번 호출 (각 byte 반환) |
| `s:len()` | byte | 한글 1글자 = 3 |
| `#s` | byte | 한글 1글자 = 3 |
| `s:gsub(...)` callback | byte | callback 인자도 byte 단위 |
| `string.find(s, pattern)` | byte | anchor `^/$` 사용 시 한글 중간에 매칭 가능 |
| `utf8.sub(s, i, j)` (libraries/utf8.lua) | **jchar** (한글 1글자 = 1) | ✓ 안전 |
| `utf8.charpos(s, i)` | byte → jchar 변환 | ✓ 안전 |

**Lua 5.3+는 `utf8` 표준 모듈이 있지만 Lua 5.1/JIT(LÖVE 11.5 기본)에는 없음**. BYTEPATH는 자체 `libraries/utf8.lua` 사용하지만 `utf8.sub`도 internal에서 byte 단위 인덱싱이라 `utf8.sub(s, 1, -2)`는 같은 버그.

## 수정 — `shorten_utf8_last` 헬퍼

```lua
-- globals.lua (BYTEPATH v0.2.1 commit 3bde384)
function shorten_utf8_last(s)
    if not s or #s == 0 then return s or '' end
    local last = #s
    -- Continuation bytes (10xxxxxx) 를 거꾸로 따라가서 lead byte 찾기
    while last > 1 and ((s:byte(last) or 0) & 0xC0) == 0x80 do
        last = last - 1
    end
    if last <= 1 then return '' end
    return s:sub(1, last - 1)
end
```

UTF-8 lead byte 식별:
- `0xxxxxxx` (7-bit ASCII): 1 byte
- `110xxxxx` (2-byte seq lead): 2 bytes total (lead + 1 continuation)
- `1110xxxx` (3-byte seq lead, 한글이나 한자): 3 bytes total
- `11110xxx` (4-byte seq lead, emoji): 4 bytes total
- `10xxxxxx` (continuation byte): never a lead

`shorten_utf8_last`는 `last` 위치의 byte가 lead가 될 때까지 거꾸로 이동 후, 그 lead까지 잘라서 **완전한 1 code point만 제거**.

### 사용 패턴

```lua
-- ❌ BUG (v0.27 이전):
while textWidth(font, label .. '..') > label_col_w and #label > 1 do
    label = label:sub(1, -2)  -- ❌ 한글 글자 깨짐
end
label = label .. '..'

-- ✅ FIX (v0.27 이후):
while #label > 0 and textWidth(font, label .. '..') > label_col_w do
    local next_label = shorten_utf8_last(label)
    if #next_label == 0 or next_label == label then break end  -- 무한 루프 방지
    label = next_label
end
if #label > 0 and textWidth(font, label .. '..') <= label_col_w then
    label = label .. '..'
end
```

### textWidth() 방어적 패치

잘못된 UTF-8 시퀀스가 들어왔을 때 `font:getWidth`가 크래시하지 않도록 **trailing continuation bytes 정리** 후 호출:

```lua
function textWidth(font, text)
    if text == nil or text == '' then return 0 end
    -- 잘못된 trailing continuation bytes 정리 (sub(1, -n) 버그 후 자투리)
    while #text > 0 do
        local b = text:byte(#text)
        if b and (b & 0xC0) == 0x80 then
            text = text:sub(1, -2)
        else
            break
        end
    end
    if has_cjk(text) and fonts and fonts.kr_16 then
        return fonts.kr_16:getWidth(text)
    end
    if font then return font:getWidth(text) end
    return 0
end
```

## 비슷한 함정: 다른 byte 단위 패턴들

| 패턴 | 위험 | 안전한 대안 |
|---|---|---|
| `s:sub(1, -2)` 한글 truncate | ✗ 한글 깨짐 → 크래시 | `shorten_utf8_last(s)` |
| `s:gsub('(.)', cb)` callback | ✗ callback이 한글 1byte씩 호출 (3번) | `utf8.gsub(s, '(.+)', cb)` 또는 `s:utf8sub()` |
| `for i=1, #s do` | ✗ #s는 byte → 한글 글자당 3번 iteration | `for _, c in utf8.codes(s)` |
| `string.find(s, '^...')` anchor | ✗ 한글 코드 포인트 중간에 매칭 가능 | `s:match('^%w+')` 같은 Lua 패턴 + `utf8.offset` 변환 |
| `s:sub(i*3-2, i*3)` 한글 1글자 | ✓ 의도 명확 (i는 jchar 인덱스) | 그대로 OK |
| `utf8.sub(s, i, j)` | ✓ jchar 단위 | 그대로 OK |

## 검증

```bash
# 1. 헤드리스 부팅 — stderr 비어있음 (UTF-8 crash 없음)
(love . > /tmp/love.log 2>&1 &); PID=$!; sleep 6; kill $PID; cat /tmp/love.log

# 2. GUI 메뉴 truncate 경로 진입 — Options / HelpModule / Console GUI 메뉴에서
#    라벨이 셀 너비 넘는 row 위/아래로 이동 시 크래시 안 나는지 확인

# 3. ConsoleLine truncated swap 결과가 잘못된 UTF-8 안 만드는지
#    (ConsoleLine의 replace는 마커 swap이라 영향 없음, 하지만 text 추출 시 주의)
```

## 판별 신호 요약

- 부팅 정상, 헤드리스 stderr 비어있음
- GUI에서 메뉴 진입 / 옵션 row 위아래 이동 / 콘솔 부팅 시퀀스 스크롤 시 **갑자기 크래시 + `'UTF-8 decoding error'`**
- 코드 검색: `grep -n 's:sub.*-' rooms/ objects/ | grep -v -- '--'` → `s:sub(1, -` 패턴 발견 시 모두 `shorten_utf8_last`로 교체

## 시간순 디버깅 (2026-07-22 BYEpath v0.2.1 4차 후속)

1. **증상**: 사용자가 Options 화면 진입 후 1초 후 크래시. stderr `'UTF-8 decoding error: Invalid UTF-8'`.
2. **스택 추적**: `textWidth` → `rooms/Options.lua:237` (truncate while 루프 안).
3. **1차 가설**: `font:getWidth`가 한글 입력에 약하다? → 한글 아닌 다른 메뉴 진입 OK. 한글 truncate 경로에서만 크래시.
4. **2차 가설**: ko.lua의 dict 키/값에 잘못된 UTF-8? → hexdump 확인. dict 값들은 정상 UTF-8.
5. **3차 가설 (정확)**: `s:sub(1, -2)` 가 한글 코드 포인트 중간에서 자름. Lua 5.1에서 `utf8` 표준 모듈 없음 + BYTEPATH 자체 libraries/utf8.lua는 `utf8.sub(s, i, j)`만 있고 negative 인덱스 미지원. **byte 단위 substring이 한글 깨뜨림**.
6. **수정**: `shorten_utf8_last(s)` 헬퍼 작성 — continuation bytes 거꾸로 따라가서 lead byte 찾고 코드 포인트 전체 제거. Options/Console/ConsoleLine/`printT` 내부에 적용.
7. **검증**: Options 라벨 truncate 정상, 다른 메뉴도 truncate 경로 안전.

## 다른 LÖVE 11.x 한글화 작업 시 적용 체크리스트

- [ ] `grep -rn 'sub(1, -' rooms/ objects/ | grep -v -- '--'` — 모든 byte-truncate 패턴 찾기
- [ ] `grep -rn '#s' rooms/ objects/ | grep -E 'for|while'` — `#s`로 한글 글자 수 세는 패턴 (잘못)
- [ ] `grep -rn 'gsub.*function' rooms/ objects/` — gsub callback에서 한글 처리
- [ ] `globals.lua` 에 `shorten_utf8_last(s)` + 방어적 `textWidth` 등록
- [ ] 모든 truncate 호출이 `shorten_utf8_last` 사용하는지 검증

## 디버깅 명령

```bash
# UTF-8 깨진 패턴 검색 — 모든 substring(1, -N) 호출을 찾음
grep -rn ':sub(1, -' /Users/mac/work/bytepath-ex/rooms /Users/mac/work/bytepath-ex/objects 2>/dev/null

# 한 줄에 잘못된 UTF-8 시퀀스가 있는지 (textdump 후 grep)
python3 -c "
import sys
with open('lang/ko.lua','rb') as f:
    data = f.read()
i = 0
while i < len(data):
    b = data[i]
    if b < 0x80: i += 1
    elif 0xC2 <= b <= 0xDF: i += 2  # 2-byte
    elif 0xE0 <= b <= 0xEF: i += 3  # 3-byte (한글)
    elif 0xF0 <= b <= 0xF4: i += 4  # 4-byte
    else:
        print(f'Invalid UTF-8 at byte {i}: 0x{b:02x}')
        break
print('UTF-8 OK' if i == len(data) else 'UTF-8 BROKEN')
"

# 런타임 크래시 후 traceback의 textWidth 호출 위치가 한글 컨텍스트인지 확인
grep -rn 'textWidth(self.font' rooms/ objects/ 2>/dev/null | head -20
```

## 다른 게임에 적용 시

LÖVE 11.x + Lua 5.1 + 한글 truncate/substring 작업 시 거의 보편적으로 발생. **다른 게임 fork 시 가장 먼저 grep할 패턴**:
1. `:sub(1, -` (byte truncate)
2. `gsub(.*function` (gsub callback)
3. `for i=1, #s do` (byte iteration)

세 가지 모두 발견되면 **shorten_utf8_last + utf8.codes 패턴으로 일괄 교체** 필요.
