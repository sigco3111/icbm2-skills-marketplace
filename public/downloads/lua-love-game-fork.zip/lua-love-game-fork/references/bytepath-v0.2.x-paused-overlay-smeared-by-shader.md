# BYTEPATH v0.2.x — Paused overlay swept by shader pipeline

사례: bytepath-ex v0.2.0 → v0.2.1 사이, 콘솔 ↔ 게임 도중 ESC 일시정지 시
화면 정중앙에 큰 흰 박스가 떠서 HUD 라벨(체력, 자원 등)을 가리는 버그.
사용자 보고: "게임 중 esc를 누르면 텍스트를 알 수 없게 흰색 박스로만 표시됨".

## 시간순 진단

### 1단계 — 증상 정리
- 사용자 화면에 화면 정중앙(gh/2 ≈ 135) 근처에 큰 흰색 사각형 2개
- 좌측 상단 difficulty/resource/attack/item 등 progress bar 가려짐
- 우측 상단 2150/7SP 같은 점수/스킬포인트 텍스트가 흰 박스로 덮임
- 우측 하단 HP/CYCLE 라벨도 비슷한 패턴

### 2단계 — Paused 객체 점검 (objects/Paused.lua)
원본 Paused:draw()는 화면 중앙에 64x16 박스 2개만 그림.
- dark 회색 (8, 8, 8) fill + 흰색 line
- 매우 작은 박스이므로 letterbox으로 윈도우에 fit해도 화면 일부만 가림

문제는 Paused가 그려진 **캔버스 단계**:
```lua
-- Stage:draw line 297-299 (main_canvas 안)
if self.scorescreen then self.scorescreen_object:draw() end
if self.paused then self.paused_object:draw() end
```

### 3단계 — 셰이더 패스 추적
`main_canvas` → `temp_canvas` (rgb_shift + distortion) → `temp_canvas_2` (glitch) → `temp_canvas_3` (rgb_shift 2nd) → `final_canvas` (rgb.glsl) → 윈도우 (distort).

즉 Paused 박스는 5-pass 셰이더를 모두 통과:
| 패스 | 효과 |
|------|------|
| rgb_shift | R/G/B 채널 분리로 Paused의 흰 박스가 saturate → 더 큰 흰색 띠로 표시 |
| distortion | shockwave에 따라 Paused 영역 가로 흔들림 → 더 큰 흰 박스로 분산 |
| glitch | glitch_canvas의 흰박스 따라 displacement (글리치 displacement GameObject는 paused 후에도 남음) |
| rgb (final) | rgb_canvas 매핑 → 추가 saturate |
| distort | horizontal_fuzz + scanlines + rgb_offset → 마지막 흩뜨림/분산 |

**Paused 박스 (64x16)이 5-pass를 거치며 saturate + 확산되어 사용자 눈에 가시적으로 흰색 큰 박스로 보임**.

### 4단계 — 진짜 픽스
**Paused overlay를 셰이더 패스 *후*에 그리기** — `drawGameCanvas(self.final_canvas)` 호출 직후, `setShader()` 호출 전:

```lua
-- rooms/Stage.lua의 Stage:draw()
if scanlines_enabled and not disable_expensive_shaders then
    love.graphics.setShader(shaders.distort)
    shaders.distort:send('time', time)
    shaders.distort:send('horizontal_fuzz', 0.6*(distortion/10))
    shaders.distort:send('rgb_offset', 0.4*(distortion/10))
    shaders.distort:send('scanlines', scanlines_enabled and 1 or 0)
end
love.graphics.setColor(1, 1, 1, 1)
love.graphics.setBlendMode('alpha', 'premultiplied')
drawGameCanvas(self.final_canvas)

-- Paused/scorescreen overlays after the shader pipeline
if self.scorescreen then self.scorescreen_object:draw() end
if self.paused then self.paused_object:draw() end

love.graphics.setBlendMode('alpha')
love.graphics.setShader()
```

그리고 `main_canvas` 안의 Paused/scorescreen 호출은 **제거** (중복 + 셰이더 누적):
```lua
-- ✅ 제거
-- if self.scorescreen then self.scorescreen_object:draw() end
-- if self.paused then self.paused_object:draw() end
```

### 5단계 — Paused 자체 디자인 개선
원본 Paused 박스가 작고 어두워서 letterbox scaling된 큰 화면에서 잘 안 보임. 디자인 가이드 (objects/Paused.lua):

```lua
function Paused:new(stage)
    self.stage = stage
    self.font = fonts.Anonymous_8
    self.resume = true
    fadeVolume('music', 1, 0.05)
end

function Paused:draw()
    love.graphics.setFont(self.font)
    -- 1) 반투명 dim: 전체 viewport 0.65 alpha 검정
    love.graphics.setColor(0, 0, 0, 0.65)
    love.graphics.rectangle('fill', 0, 0, gw, gh)

    -- 2) Pill-shaped 버튼: 96x22 (letterbox 후에도 잘 보이는 크기)
    local btn_w, btn_h = 96, 22
    local gap = 12
    local total_w = btn_w * 2 + gap
    local x0 = math.floor((gw - total_w) / 2)
    local y0 = math.floor((gh - btn_h) / 2)

    -- RESUME (선택시 노란 fill + 검은 텍스트)
    if self.resume then
        love.graphics.setColor(skill_point_color[1]/255, skill_point_color[2]/255, skill_point_color[3]/255, 0.95)
    else
        love.graphics.setColor(34/255, 34/255, 38/255, 1)
    end
    love.graphics.rectangle('fill', x0, y0, btn_w, btn_h)
    if self.resume then
        love.graphics.setColor(0, 0, 0, 1)
    else
        love.graphics.setColor(222/255, 222/255, 222/255, 0.45)
    end
    love.graphics.print('RESUME',
        x0 + btn_w/2 - self.font:getWidth('RESUME')/2,
        y0 + math.floor((btn_h - self.font:getHeight())/2))

    -- CONSOLE (cx = x0 + btn_w + gap, 동일 패턴)
    love.graphics.rectangle('fill', x0 + btn_w + gap, y0, btn_w, btn_h)
    -- ... (대칭 색상 + 텍스트)

    -- 3) 입력 가이드 힌트
    love.graphics.setColor(1, 1, 1, 0.75)
    local hint = '<- ->  switch    enter  confirm'
    love.graphics.print(hint,
        math.floor((gw - self.font:getWidth(hint)) / 2),
        y0 + btn_h + 8)
end
```

**디자인 결정 근거**:
- 64x16 (원본) → 96x22 (letterbox 사이즈 후에도 식별 가능)
- dark rect (8,8,8,255) → 투명 검정 디머 (선택 비주류 영역)
- 2-state pill 색상: skill_point_color (선택) + dark-gray (비선택) — 명확한 시각적 위계
- 힌트 텍스트: 입력 안 되는 키 표시하면 혼란 → 표시 가능한 것만

### 결과
- 일시정지 시 게임 화면 흐려지지만 보임 (디머), 가운데 RESUME/CONSOLE pill 두 개
- 셰이더 효과 통과 X → 텍스트 또렷, 박스 깨끗
- `<- ->  switch    enter  confirm` 한 줄로 입력 가이드

## 교훈 (skill에 추가됨: M-14 확장)

Paused / scorescreen 같은 **일시적 overlay UI**도 cursor와 동일하게 셰이더 패스의 누적 효과를 받음. 모든 overlay는 `drawGameCanvas()` *후*에 그려야 안전.

오버레이가 큰 영역 (dim, 검은 배경 박스 등)을 가리거나, 사각형 글리프 또는 작은 텍스트가 saturate되면 의심할 것.
