# BYTEPATH v0.0.2 — 흰 화면 디버깅 + GitHub 이력 1차 진단 교훈

> sigco3111/BYTEPATH v0.0.2 (2026-07-22)
> 셰이더 silent fail이 만든 흰 saturate + 사용자가 명시적으로 정정한 워크플로우
> → "저장소 이력을 먼저 확인하라" (사용자 정정)

## 환경

| 항목 | 값 |
|---|---|
| M4 Mac mini 16GB | macOS 26.5.2 |
| LÖVE | 11.5 (brew) |
| Lua | LuaJIT 2.1 (love 11.5) |
| 원본 | https://github.com/a327ex/BYTEPATH (MIT, ~7.4K LOC) |
| Fork | https://github.com/sigco3111/BYTEPATH |

## 시간순 시퀀스 — 가설 3개를 차례로 틀리게 잡은 로그

| # | 가설 | 시도 | 결과 | 교훈 |
|---|------|------|------|------|
| 1 | (사용자 최초) 콘솔 입력 안 됨 | `love.textinput` 추가 | 글자 두 번씩 입력 (IME) | **CJK 사용자에게 `love.textinput` 추가 금지** (§M-8) |
| 2 | start 후 검은 화면 | `love.run` 비활성화 + `gotoRoom` 즉시 호출 | 검은 화면 유지 | M-4 (love.run) 가설 틀림. 1차 원인이 아님. |
| 3 | 검은 화면 = Canvas+Shader silent fail | `Console:draw()`를 `camera:attach + line:draw()`로 우회 | ⚠️ **흰 화면으로 변함** | M-6 가설 부분 맞음. **근데 우회만으로는 부족** — 셰이더 자체가 컴파일 안 됨 |
| 4 | (사용자 정정) "저장소 이력을 확인하라" | GitHub `issues?q=love+11.5` 검색 | **Issue #13 "Migrate LÖVE 0.10.2 to 11.5"** 발견. PR #13 closed. `scillidan/BYTEPATH-fork` dev branch 존재. | **이력 1차 조회가 진단의 출발점** |
| 5 | PR #13의 fork dev branch와 diff | scillidan fork의 `.frag` 셰이더와 `Stage:draw()` 비교 | **셰이더가 legacy GLSL 신택스** (`extern Image`, `Image` 타입). `setColor(255, 255, 255)`가 0.0~1.0 정규화 안 됨 | v0.7 §M-6, §M-7과 정확히 일치 |
| 6 | 셰이더 8개 modern GLSL로 변환 + 색상 정규화 + `drawGameCanvas` letterbox + `Steam = nil` | 한 번에 다 적용 | ✅ **콘솔 정상 표시, `start` 입력 시 게임 화면 정상** | BYTEPATH v0.0.2 완성 |

## ⭐ 사용자 정정: "저장소 이력을 먼저 확인하라"

> "별을 많이 받은 프로젝트가 실행도 제대로 안될리 없음. 저장소의 이력을 확인하고 해결책을 찾아봐."

**이 워크플로우 원칙은 SKILL.md 본문 §M-4~M-9 진단 시퀀스보다 우선한다.**

- `love .`가 검은/흰/이상한 화면을 보일 때 **가장 먼저 GitHub에서 `love 11.5`/`modernize`/`migration` 이슈/PR/포크 검색**
- 원작자가 같은 작업을 이미 했거나 fork가 존재할 확률이 높음 (특히 1k+ stars 프로젝트)
- fork의 branch와 diff가 정답 패턴을 제공 — 셰이더 신택스, 색상 정규화, letterbox 헬퍼 등

**검색 패턴**:
```bash
# GitHub UI: repo > Issues > "love 11.5" 또는 "love 11" 또는 "LÖVE 0.10"
# API:
curl -sS 'https://api.github.com/search/issues?q=repo:OWNER/REPO+love+11.5'
# Forks 목록:
curl -sS 'https://api.github.com/repos/OWNER/REPO/forks?per_page=100' | grep -A1 pushed_at
# PR의 dev branch:
git clone --depth 1 --branch dev https://github.com/CONTRIBUTOR/REPO-fork.git /tmp/repo
diff -u /tmp/repo/main.lua /Users/mac/work/REPO/main.lua
```

## 핵심 발견 3가지 (v0.0.2)

### 1. 검은 화면 → 흰 화면 가설의 절반만 맞았던 이유

v0.0.1에서 "M-6 (Canvas+Shader silent fail) 가설로 Console:draw를 우회"한 후 화면이 검은색에서 흰색으로 바뀌었다. 이건:

- 검은 화면 = **Console:draw 셰이더 파이프라인이 검은 픽셀 출력**
- 흰 화면 = **셰이더가 silent하게 컴파일 실패한 후, 후속 패스에서 saturate 흰색** 또는 `setColor(255, 255, 255)`이 11.5 셰이더에서 1.0으로 인식돼 saturate

→ M-6 (셰이더 우회) **만으로는 부족**. 셰이더 자체를 modern GLSL로 변환 + 색상 0.0~1.0 정규화가 필수.

### 2. ⭐ Steam nil 직접 할당이 shim 우회보다 단순

scillidan fork는 Steam 호출부를 `if Steam then` 가드로 두는 선에서 끝냈다. FFI require 자체를 throw하므로 shim을 require해도 `libraries/steamworks_shim.lua` 안의 `ffi.cdef`/`dlopen` 호출에서 throw됨. shim을 만드는 건 시간 낭비.

**가장 단순한 처리**:
```lua
-- main.lua line 1-2
Steam = nil
```

`if Steam then ... end` 가드는 원본 코드가 이미 대부분 가지고 있어 추가 작업 없음.

### 3. ⭐ letterbox 헬퍼가 sx/sy 비례 확대보다 우수

원본 BYTEPATH는 `sx=2.67, sy=2.67` 같은 비례 확대를 직접 계산해서 `draw(canvas, 0, 0, 0, sx, sy)`로 화면에 그렸다. 이건 윈도우 크기 변경에 자동 대응 안 되고 부동소수점 누적 오차로 검게 보일 수 있다.

`scillidan` fork의 `drawGameCanvas(canvas)`는 윈도우 크기에서 letterbox 오프셋을 계산해 자동 매핑:
```lua
function getLetterboxOffset()
    local win_w, win_h = love.graphics.getDimensions()
    local scale = math.min(win_w / gw, win_h / gh)
    return (win_w - gw*scale) / 2, (win_h - gh*scale) / 2, scale
end
function drawGameCanvas(canvas)
    local ox, oy, s = getLetterboxOffset()
    love.graphics.draw(canvas, ox, oy, 0, s, s)
end
```

**장점**: 윈도우 resize에 자동 대응, 종횡비 항상 유지, HUD 절대 좌표는 캔버스 안에서 그리면 자동 정렬.

## 작업 요약 (v0.0.2)

| 파일 | 변경 |
|------|------|
| `main.lua` line 1-2 | `Steam = nil` (shim 불필요) |
| `main.lua` line ~485 | `love.run` → `legacy_love_run_disabled` (LÖVE 11.5 기본 루프 사용) |
| `main.lua` | `drawGameCanvas()`, `getLetterboxOffset()` 헬퍼 추가 |
| `main.lua` line 39 | `setBackgroundColor(background_color)` → `setBackgroundColor(background_color[1]/255, ...)` |
| `conf.lua` | `loveVersion = '11.5'`, `t.version = "11.5"`, `vsync = 1`, `fsaa → msaa`, `fullscreentype = "desktop"`, `t.window.srgb` 제거 |
| `libraries/sound.lua` | `setLooping(opts.loop == true)`, `isStopped → isPlaying` 폴백 |
| `libraries/boipushy/Input.lua` | `Input.keyboard_keys` 화이트리스트 + `down()` 가드 |
| `rooms/Console.lua`, `rooms/Stage.lua` | 모든 `setColor(255, 255, 255)` → `setColor(1, 1, 1)`, `127 → 127/255`, `r - 32 → r - 32/255` |
| `resources/shaders/*.frag` (8개) | `extern Image` → `uniform sampler2D`, `Image` 타입 → `sampler2D` |

**소요 시간**: 1차 검은 화면 4번 재시도 (v0.0.1) + 1차 흰 화면 + 사용자 정정 후 GitHub 이력 조회 + 셰이더/색상 한 번에 적용 = **총 90분**

## 핵심 교훈 (v0.0.2 추가)

### A. **저장소 이력 조회는 M-4~M-9 진단 시퀀스보다 우선**

흰/검은/이상 화면 가설을 자체적으로 세우기 전에 GitHub issues/PR/forks를 검색. 1k+ stars 프로젝트는 동일 마이그레이션 PR이 거의 존재한다.

### B. **M-4 (love.run) + M-6 (Canvas+Shader) + M-7 (색상 정규화) = 한 묶음**

BYTEPATH 0.10.2 → 11.5 마이그레이션의 핵심 3축:
1. custom `love.run` 비활성화
2. 셰이더를 modern GLSL로 변환
3. 색상을 0.0~1.0으로 정규화

이 셋 중 하나라도 빠지면 saturate 흰색/검은색이 다시 나타난다. **반드시 한 번에 다 적용하고 검증할 것.**

### C. **"stderr 비어있음 = OK" 판정은 신뢰할 수 없다 (v0.6+v0.0.2 재확인)**

- v0.0.1: 검은 화면인데 stderr 비어있음 → "OK"라고 보고 → 사용자 GUI에서 검은 화면
- v0.0.2: 흰 화면인데 stderr 비어있음 → "OK"라고 보고했다가 사용자 정정

→ **헤드리스 검증은 require + 메인 루프 진입까지만 보장**. 셰이더 컴파일/첫 프레임 draw는 보장 안 함. GUI 검증 전엔 "정상"이라고 단정 금지.

## 진단 분기표 (v0.0.2 추가)

| 증상 | 1차 의심 | 2차 의심 | 해결 |
|------|----------|----------|------|
| 검은 화면 + stderr 비어있음 | M-6 (Canvas+Shader silent fail) | M-4 (love.run) | 셰이더 modern GLSL 변환 + custom love.run 비활성화 |
| 흰 화면 + stderr 비어있음 | M-7 (색상 0~255 saturate) + M-6 (셰이더 fail) | M-8 (love.textinput 중복) | 색상 0.0~1.0 정규화 + 셰이더 변환 + love.textinput 제거 |
| 0~10 FPS 자동 fallback | 셰이더가 invalid uniform 받음 | 셰이더 컴파일 자체 실패 | `disable_expensive_shaders = true`로 일시 우회 후 셰이더 점검 |
| 글자 두 번씩 입력 | love.textinput IME 중복 | key repeat | love.textinput 제거 후 `setKeyRepeat(false)` 확인 |

## 다음 세션 작업 (한글화)

v0.0.2는 게임 플레이 가능. 한글화는 v0.1.x부터:
- `lang/init.lua` + `lang/ko.lua` (~160개 키)
- `love.graphics.print` 오버라이드 (모노리식 패턴)
- `NotoSansKR-Regular.otf` 추가
- Console:draw / Stage:draw의 영문 라벨을 `T('key', 'default')`로 교체
