# BYTEPATH v0.1.x — 검은 화면 재발 + love.textinput IME 중복 (v0.7)

> sigco3111/BYTEPATH v0.1.x 후속 (2026-07-22, 2차 검은 화면 디버깅)
> v0.0.1 첫 디버깅에서는 M-4 (custom love.run) 비활성화로 "해결"이라고 판단했으나,
> 실제 사용자 GUI 검증 단계에서 **여전히 검은 화면**이 재발함.
> 5단계 진단 (M-4 → M-7 → M-6 → 입력 → M-8)을 거쳐 **Canvas+Shader 파이프라인**이
> 진짜 원인임을 확인. 이후 love.textinput IME 중복 함정도 발견.
> → SKILL.md의 M-4 권고는 "1차 진단 후보"로 강등, M-6 (Canvas+Shader)을 1차 의심으로 격상.

## 시간순 디버깅 시퀀스 (6단계, 5번 재시도)

| # | 사용자 신고 | 시도 | 결과 | 진짜 원인 |
|---|---|---|---|---|
| 1 | "검은 화면" | `love .` (Steam shim + setLooping + isStopped 모두 적용된 상태) | stderr 비어있음, 프로세스 S 상태, **그러나 검은 화면** | M-6 (Canvas+Shader) — v0.0.1에서는 M-4로 잘못 진단 |
| 2 | "여전히 검은 화면" | M-4: custom `love.run`을 `legacy_love_run_disabled`로 이름 변경 (love 11.5 기본 루프 사용) | **여전히 검은 화면** | M-4는 1차 원인이 아니었음 |
| 3 | "여전히 검은 화면" | M-7: `timer:after(0.5, ...)` → `gotoRoom('Console')` 즉시 호출 | **여전히 검은 화면** | M-7은 1차 원인이 아니었음 (Console 객체는 생성됨) |
| 4 | "여전히 검은 화면" | M-6: `Console:draw`를 `camera:attach + 직접 line:draw`로 교체 (Canvas/Shader 우회) | ✅ **콘솔 텍스트 출력 확인** | M-6 확정 — 셰이더 파이프라인이 silent fail |
| 5 | "입력 안 됨" | `love.textinput` 추가 → 사용자가 "한글 입력키가 눌려서 그랬음" 정정 | ❌ **글자가 두 번씩 눌림** | M-8: `love.textinput` + IME 조합형 입력기 충돌 |
| 6 | "글자 중복" | `love.textinput` 제거, `love.keypressed`만 사용 | ✅ **정상 입력** | M-8 해결 |

## 핵심 교훈 (v0.7)

### 1. v0.0.1 진단은 절반만 맞았다

v0.0.1 시점의 `references/bytepath-v0.0.1-silent-fail-debug.md`는:
- "custom love.run 비활성화로 검은 화면 해결"이라고 결론
- "Console:draw 셰이더 파이프라인 점검은 향후 작업"이라고 분류

**v0.7 실측**: custom love.run 비활성화는 검은 화면을 해결하지 못함. 실제 원인은 v0.0.1에서도 Canvas+Shader였고, custom love.run은 **우연히 같은 검은 화면을 유발하는 별개 버그**였음. 두 버그가 겹쳐 있어서 M-4를 고쳐도 검은 화면이 유지됐던 것.

### 2. 진단 우선순위 재배치 (SKILL.md 본문 §M-4, M-6, M-7에 반영됨)

**v0.0.1 권고 (잘못됨)**:
```
custom love.run 비활성화 → (해결 안 됨) → Console:draw Canvas+Shader 우회
```

**v0.7 권고 (정정)**:
```
M-1 (Steam dlopen) → M-2 (setLooping) → M-3 (isStopped) → M-7 (timer:after 즉시 호출) → M-6 (Canvas+Shader 우회) → M-8 (love.textinput 제거)
```

- M-4 (custom love.run)는 "원인일 수도 있는 후보"이지 "검은 화면의 단일 원인"이 **아님**
- M-6 (Canvas+Shader)이 검은 화면의 가장 흔한 진짜 원인
- M-7 (timer:after)은 M-6 적용 후에도 첫 화면이 안 보일 때 의심

### 3. ⭐ "stderr 비어있음 = OK" 판정 강화 (SKILL.md §2)

```bash
# v0.7 권장 헤드리스 검증
rm -f /tmp/love_run.log
(love . > /tmp/love_run.log 2>&1 &)
sleep 8
PID=$(pgrep -f "love \." | head -1)
[ -n "$PID" ] && ps -p "$PID" -o pid,stat,command && kill "$PID" 2>/dev/null
cat /tmp/love_run.log
```

- `STAT=S/R` + stderr 비어있음 → ⚠️ **require와 메인 루프 진입까지만 OK**
- draw 호출과 첫 화면 렌더링은 **이 판정으로 보장 안 됨**
- **사용자에게 "정상 작동" 보고는 GUI 검증 후에만 가능**
- 헤드리스 검증은 보조 검사일 뿐

### 4. ⭐ love.textinput IME 중복 (SKILL.md §M-8)

```lua
-- WRONG (v0.6에서 시도했다가 사용자 정정 받음)
function love.textinput(t)
    if current_room and current_room.keypressed then current_room:keypressed(t) end
end

-- CORRECT: 표준 love.keypressed만 사용
function love.keypressed(key)
    if current_room and current_room.keypressed then current_room:keypressed(key) end
end
-- love.textinput 정의하지 않음
```

**증상**: "글자가 두 번씩 눌림" + 사용자가 한글/일본어/중국어 IME 사용 중

**원인**: 조합형 입력기는 한 글자를 여러 `textinput` 이벤트로 쪼개 보냄. ASCII 전용 콘솔에 그대로 전달하면 한 글자가 두 번 처리됨.

**판별법**: 사용자가 "글자가 두 번씩" 또는 "한글 입력하면 이상하게"라고 보고하면 즉시 `love.textinput` 핸들러 의심.

**예외**: 한글/일본어/중국어 게임 입력을 **명시적으로** 받아야 할 때만 `love.textinput` 추가. 그 안에서 `lang.current == 'ko'` 같은 가드로 CJK일 때만 처리.

## v0.7 시점 BYTEPATH 작업 흔적

```bash
# 시점: 2026-07-22, /Users/mac/work/BYTEPATH

# 1. M-1 ~ M-3 (v0.0.1에서 해결)
# - libraries/steamworks.lua → require 제거 (Steam = nil)
# - libraries/sound.lua line 108, 119: setLooping(opts.loop == true)
# - libraries/sound.lua line 56-62: isStopped → isPlaying 폴백

# 2. M-4 (v0.7에서 적용, 효과가 없었음)
# - main.lua line 487: function love.run() → function legacy_love_run_disabled()
# - LÖVE 11.5 기본 love.run 사용

# 3. M-7 (v0.7에서 적용, 효과가 없었음)
# - main.lua line 109: timer:after(0.5, ...) → gotoRoom('Console')

# 4. M-6 (v0.7에서 적용, 효과 있었음)
# - rooms/Console.lua line 121: Canvas+Shader 파이프라인을 camera:attach + 직접 line:draw()로 교체
# - black → 콘솔 텍스트 표시 ✅

# 5. love.textinput 실험 (v0.7에서 시도, 사용자 정정으로 제거)
# - main.lua: love.textinput 추가 → 글자 중복 발생
# - main.lua: love.textinput 제거 → 정상

# 6. 최종 상태
# - main.lua: Steam 비활성화, legacy_love_run_disabled, 즉시 gotoRoom
# - libraries/sound.lua: setLooping + isStopped 패치
# - rooms/Console.lua: Canvas+Shader 우회 (셰이더 효과는 잃음)
# - love.textinput: 미정의
```

## 향후 작업 (v0.2+ 예정)

- [ ] **M-6 복구**: 셰이더 파이프라인을 love 11.5 호환으로 재작동
  - 셰이더 uniform 타입 (`table` → 명시적 `vec2/3/4`) 점검
  - `setShader(nil)` + `setBlendMode('alpha')` 명시 복원
  - 셰이더를 한 개씩 다시 켜면서 검증
- [ ] Stage:draw 등 다른 Room의 Canvas+Shader 점검 (M-6 패턴이 다수 Room에 있음)
- [ ] CJK 4/4 (UI 라벨 T() 적용)
- [ ] macOS 빌드 스크립트 (build_love.sh, build_all.sh)
- [ ] v0.2 커밋 + git push + gh release

## SKILL.md 본문과의 관계

이 reference 문서는 **v0.7 시점의 실제 디버깅 시간순 로그**를 보존한다.
SKILL.md 본문 §M-1~M-8은 이 로그를 일반화한 **재사용 가능한 진단 패턴**이다.
다음에 비슷한 LÖVE 0.10.x → 11.5 마이그레이션을 할 때는 본문의 8대 함정 순서대로 적용하면
한 번에 클리어 가능 (snkrx-clone의 state.txt 4번 반복 교훈과 동일).
