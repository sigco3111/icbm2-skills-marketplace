# BYTEPATH-ex Classes 룸 흰색 saturate/줄무늬 함정 (v0.10)

**날짜**: 2026-07-22
**작업**: bytepath-ex Classes/Passives 룸 진입 시 흰색 사각형 + 검은 가로 줄무늬 → Classes 룸만 동일 패턴임에도 셰이더 파이프라인이 깨져 보임.

## 증상 (사용자 캡쳐)

- **Classes 룸 진입 직후**: 좌상단에 흰색 사각형 + 화면 전체 검은 배경 + 검은 가로 줄무늬
- **Passives(SkillTree) 룸 진입 직후**: 동일 증상
- **Console/Stage**: 정상 (v0.8 정규화 완료)
- **Achievements**: 미확인 (정규화 잔재 있음)

## 진단 시퀀스

### 1) 룸별 셰이더 파이프라인 식별

```bash
grep -l 'setShader\|setCanvas' rooms/*.lua
```

Classes와 SkillTree가 동일 5-canvas 셰이더 파이프라인 사용. **둘 다 동일 증상 → 둘 중 한 쪽에 원인**.

### 2) 캔버스 생성 매트릭스

```bash
for name in rgb_canvas glitch_canvas main_canvas temp_canvas final_canvas; do
  for f in rooms/*.lua; do
    uses=$(grep -c "self.$name" "$f")
    creates=$(grep -c "self.$name = love.graphics.newCanvas" "$f")
    [ "$uses" -gt "$creates" ] && echo "$f $name uses=$uses creates=$creates"
  done
done
```

**결과**:
```
rooms/Classes.lua rgb_canvas uses=1 creates=0   # 빠뜨림
```

### 3) 색상 정규화 잔재 점검

```bash
grep -nE 'setColor\((127|222|255)(, (127|222|255))' rooms/*.lua
```

**결과** (`rooms/Classes.lua`만 9곳):
- line 478, 487: `(127, 127, 127)` — glitch/rgb 캔버스 배경
- line 480, 489, 555, 582, 593, 608: `(255, 255, 255[, 255])` — 흰색 텍스트
- line 553: `(0, 0, 0, 222)` — 반투명 검정 버튼

다른 룸(Console/Stage)은 v0.8 작업에서 이미 정규화 완료.

## 픽스 적용

### 픽스 1: `rooms/Classes.lua` :new()에 `rgb_canvas` 추가

```lua
self.main_canvas = love.graphics.newCanvas(gw, gh)
self.final_canvas = love.graphics.newCanvas(gw, gh)
self.temp_canvas = love.graphics.newCanvas(gw, gh)
self.glitch_canvas = love.graphics.newCanvas(gw, gh)
self.rgb_canvas = love.graphics.newCanvas(gw, gh)   -- 추가
```

### 픽스 2: 전체 setColor 정규화 (9곳)

| 위치 | before | after |
|------|--------|-------|
| 478, 487 | `(127, 127, 127)` | `(127/255, 127/255, 127/255)` |
| 480, 489, 555, 582, 593, 608 | `(255, 255, 255[, 255])` | `(1, 1, 1[, 1])` |
| 553 | `(0, 0, 0, 222)` | `(0, 0, 0, 222/255)` |

## 검증

```bash
# 헤드리스 — 정상이어도 OK 아님 (v0.6 교훈)
rm -f /tmp/love_run.log && (love . > /tmp/love_run.log 2>&1 &) ; sleep 8 ; \
  PID=$(pgrep -f "love \." | head -1) ; kill -9 "$PID" 2>/dev/null ; \
  cat /tmp/love_run.log

# 사용자 Mac에서 `love .` 또는 `open bytepath-ex.app` 직접 띄워 픽셀 검증 필수
```

## 후속 작업 권장

`rooms/Achievements.lua` line 256–302에 동일 패턴 잔재 — Awards 룸 진입 시 같은 saturate 증상 보일 가능성 높음.

```bash
grep -nE 'setColor\((127|222|255)' rooms/Achievements.lua
# 256: setColor(127, 127, 127)
# 258: setColor(255, 255, 255)
# 274: setColor(255, 255, 255, 255)
# 287: setColor(255, 255, 255)
# 302: setColor(255, 255, 255, 255)
```

## SKILL.md M-7.5 단서와의 연결

> "다른 룸은 잘 되는 게 확실한데 한 룸만 셰이더 효과 saturate/줄무늬" → **룸별 정규화/캔버스 누락 의심 (M-7.5)**

이 사례가 정확히 그 신호. SkillTree는 `rgb_canvas` 만들었지만 Classes는 빠뜨림 → 같은 셰이더 파이프라인인데 Classes만 nil → silent saturate → LÖVE 11.5가 nil 인자를 default canvas로 폴백 → 셰이더가 미정의 입력에 1.0 출력.
