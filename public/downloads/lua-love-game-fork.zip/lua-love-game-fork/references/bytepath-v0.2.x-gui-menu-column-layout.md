# BYTEPATH v0.2.1 — GUI menu layout / cursor / dropdown decisions

세션 (2026-07-22): BYTEPATH 콘솔의 bytepathMain 메뉴를 텍스트 라인 + 직접 셰이더 pipeline 위 cursor 박스 → 단일 GUI panel (`main_menu` 상태) 으로 전면 재작성.
M-13/M-14/M-16/M-17 동시 발현 케이스.

## 시간순

1. **초기 문제** — `Classes` 룸 진입 시 흰 사각형 + 줄무늬. 진단:
   - `setColor(127, 127, 127)` / `setColor(255, 255, 255)` 이 modern GLSL 셰이더에서 1.0 으로 saturate (M-0)
   - `self.rgb_canvas` 가 `:new()` 에서 생성되지 않아 `setCanvas(self.rgb_canvas)` 호출 시 silent fail → 셰이더 glitch/distort 가 흰색 캔버스로 (M-7.5)
   **픽스**: `setColor(127/255,...)` 등 0..1 정규화 + `self.rgb_canvas = love.graphics.newCanvas(gw, gh)` `:new()` 에 추가.

2. **`SkillTree`, `Classes`, `Console` 룸 모두 viewport 안에서만 그림**:
   - 셰이더 4-pass 후 최종 `final_canvas` 가 (0,0) ~ (gw*sx, gh*sy) 영역에 그려짐. 윈도우가 더 크면 검정 여백.
   **픽스 (M-7.7)**: 모든 룸에서:
   ```lua
   self.render_canvas = love.graphics.newCanvas(gw, gh)   -- :new()
   function :draw()
       love.graphics.setCanvas(self.render_canvas)
       love.graphics.clear(0, 0, 0, 1)
       -- 모든 viewport 그리기를 render_canvas 안에
       camera:attach(0, 0, gw, gh)
       ... 직접 그리기 ...
       camera:detach()
       love.graphics.setCanvas()
       drawGameCanvas(self.render_canvas)   -- 윈도우 letterbox 으로 fit
   end
   ```
   - viewport 가 윈도우 안에서 letterbox 으로 fit (검정 여백은 윈도우 비율과 viewport 비율 차이만큼만 남음)
   - 모든 룸에서 동일 recipe 적용. 모노리식 게임 공통 패턴.

3. **콘솔 메뉴 cursor 문제** — 메뉴 첫 진입 시 첫 항목 위에 cursor 가 그려져야 하는데 안 그려지거나 한 칸 밀려 있음.
   - `self.bytepath_main_y = self.line_y + 13*12` 누적 → line_y 가 화면 height 초과 시 +156 = 화면 밖
   - 텍스트 매칭 후 line.y 시도 → `addLine` 이 timer 큐이므로 캡처 시점 race (M-16)
   **진단 정렬** (사용자가 "순차적으로 생각해보고 다시 분석" 요청 직전까지 적용된 5번 가설):
   1. `bytepath_main_y` 를 line_y 누적 → viewport 밖 (M-13)
   2. `self.lines` 에서 메뉴 라인 텍스트 매칭 → 매칭 의도는 맞으나 `addLine` 이 timer.after 큐 (M-16)
   3. `camera:getCameraCoords` (M-15) → STALKER-X/Camera 는 메서드 없음 → silent nil
   4. `drawGameCanvas()` 호출 후 그리기 (M-14) → 셰이더 우회
   5. menu_lines 직접 추적 + sync 캡처 → 그래도 안 됨

4. **해결 — GUI 메뉴 전면 재설계** (`main_menu` 상태):
   ```lua
   -- :new() 또는 showMainMenu()
   self.main_menu = {
       x = 12, y = 84,
       w = gw - 96,   -- viewport 480 → 메뉴 폭 384
       h = 22,
       spacing = 4,
       titles = {
           {key = 'terminal',  label = 'terminal',  desc = '...'},
           {key = 'start',     label = 'start',     desc = '...'},
           -- ...
       },
       selection_index = 1,
       hovered_index = nil,
   }
   self.main_menu_actions = {
       terminal = function() EscapeModule(...) end,
       start = function() gotoRoom('Stage') end,
       -- ...
   }
   ```
   - **모든 column 위치를 미리 박음** (overlap 방지):
   ```
   [ accent┃ 01 │ LABEL           description text here        [N] ›
   ```
   - `accent_w=3`, `index_w=16`, `label_w=80`, `hotkey_w=22`, `cell_w = gw-96=384`
   - description 영역은 잔여 width (`desc_max_w = cell_w - index_w - label_w - 12 - hotkey_w - 8`)
   - **truncate with `..`** — 글자가 column 너비 초과 시 잘라서 `..` 붙임
   - **3-state 색상** — selected (skill_point_color 반투명), hovered (중간 회색), idle (어두운 회색) — 모두 0..1 정규화
   - **setShader() / setBlendMode('alpha')** 명시 후 그리기 → 셰이더 우회

5. **마우스 vs 키보드 문제**:
   - 1차: mouse hover/click 둘 다 구현 → 마우스 옵션 근처에 있어도 메뉴는 start 에 — 동기화 깨짐
   - 2차: mouse hover 만 selection_index 동기화 → 클릭만 실행 → 옵션에 가도 start
   - 3차: 사용자가 "**마우스 빼고 키보드로만**" 명시 요청 → mouse 블록 통째 삭제
   ```lua
   if self.main_menu and self.main_menu.visible then
       if input:pressed('up') then ... end
       if input:pressed('down') then ... end
       if input:pressed('return') then self:_runMainMenu(m.selection_index) end
       if input:pressed('1') then self:_runMainMenu(1) end
       -- 2..N
   end
   ```
   - 사용자 결단 기준: 셰이더+letterbox 룸에서 마우스 hover 좌표는 누적 효과로 부정확 (M-17) — **사용자가 명시적으로 "키보드만" 요청하면 통째 단순화**

## 컬럼 분할 명세 (재사용용)

GUI 메뉴 그릴 때 매번 적용할 layout:

```lua
local accent_w = 3
local index_w = 16
local label_w = 80
local hotkey_w = 22
local row_h = m.h

local idx_col  = m.x + 4
local sep_x    = m.x + index_w
local label_x  = m.x + index_w + 6
local desc_x   = label_x + label_w + 12
local desc_max_w = (m.w - (desc_x - m.x)) - hotkey_w - 8
local hk_x     = m.x + m.w - hotkey_w - 4

-- 셀 그리기:
love.graphics.setColor(cell_fill[1], cell_fill[2], cell_fill[3], cell_fill[4])
love.graphics.rectangle('fill', cell_x, cell_y, m.w, row_h)

-- 좌측 accent bar (selected 만)
if is_selected then
    love.graphics.setColor(skill_point_color[1]/255, skill_point_color[2]/255, skill_point_color[3]/255, 1)
    love.graphics.rectangle('fill', cell_x - accent_w, cell_y, accent_w, row_h)
end

-- LABEL (column clamp)
local label = title.label
if self.font:getWidth(label) > label_w - 8 then
    while self.font:getWidth(label .. '..') > label_w - 8 and #label > 1 do
        label = label:sub(1, -2)
    end
    label = label .. '..'
end
love.graphics.print(label, label_x, text_y)

-- DESCRIPTION (column clamp, alpha)
local desc = title.desc
if self.font:getWidth(desc) > desc_max_w then
    while self.font:getWidth(desc .. '..') > desc_max_w and #desc > 1 do
        desc = desc:sub(1, -2)
    end
    desc = desc .. '..'
end
love.graphics.setColor(label_r, label_g, label_b, desc_alpha)
love.graphics.print(desc, desc_x, text_y)

-- HOTKEY (우측 고정)
local hk = '[' .. i .. ']'
love.graphics.print(hk, hk_x, text_y)

-- chevron (셀 *바깥* 우측, selected 만)
if is_selected then
    love.graphics.print('›', cell_x + m.w + 4, text_y)
end
```

## 키보드-only update 패턴

```lua
if self.main_menu and self.main_menu.visible then
    local m = self.main_menu
    local n = #m.titles
    if input:pressed('up') then
        m.selection_index = m.selection_index - 1
        if m.selection_index < 1 then m.selection_index = n end
        playMenuSwitch()
    end
    if input:pressed('down') then
        m.selection_index = m.selection_index + 1
        if m.selection_index > n then m.selection_index = 1 end
        playMenuSwitch()
    end
    for i = 1, n do
        if input:pressed(tostring(i)) then
            self:_runMainMenu(i)
            return
        end
    end
    if input:pressed('return') then
        self:_runMainMenu(m.selection_index)
    end
end
```

## drawGameCanvas 후 GUI 그리기 (M-14 + M-7.7)

`Console:draw` 마지막:
```lua
drawGameCanvas(self.final_canvas)

-- 셰이더/letterbox 우회: screen 좌표에 직접 그리기
self:_drawMainMenu()

love.graphics.setBlendMode('alpha')
love.graphics.setShader()
```

`setShader()` 와 `setBlendMode('alpha')` 명시 후 다음 GUI 단계 진입. 다음 frame 의 `update` 가 `setShader()` 까지 호출하므로 안전.

## 사용자가 명시적으로 요청한 두 가지

1. **"마우스는 빼자 키보드로만 선택되도록 수정"** — 마우스 블록 통째 삭제. M-17 결론 강화.
2. **메뉴 순서**: `1 start  2 classes  3 device  4 passives  5 terminal  6 options  7 help  8 shutdown`

## 캔버스 / render 캔버스 검증 체크리스트

BYTEPATH 룸 작업 시 매번 확인:
- [ ] `:new()` 에서 `self.main_canvas`, `self.final_canvas`, `self.temp_canvas`, `self.glitch_canvas`, `self.rgb_canvas` 모두 생성? (M-7.5)
- [ ] `self.render_canvas = newCanvas(gw, gh)` 로 viewport fit? (M-7.7)
- [ ] 모든 `setColor(255,...)` → `setColor(1,...)` 정규화? (M-0 / 0..255 setColor 셰이더 saturate 방지)
- [ ] 글로벌 컬러 테이블 (`default_color`, `hp_color`, `skill_point_color`, `background_color`, `ammo_color`, `boost_color`) 을 setColor 직전에 `/255`?
- [ ] `:draw()` 마지막에 `drawGameCanvas(self.render_canvas)` 호출?
- [ ] UI (cursor / highlight / 모달) 은 `drawGameCanvas` 후 screen 좌표에 그림? (M-14)
- [ ] game_pad / 셰이더 다음 frame 상태 reset (`setShader()`, `setBlendMode('alpha')`) 명시?

## Sessions history

- **v0.2.1** (2026-07-22) — 이 세션. M-13/M-14/M-16/M-17 동시 발현 → GUI 메뉴 + 컬럼 분할 + 키보드-only.
  - commit 2bd4beb "v0.2.1: fix shader-free UI for Class/Passive screens; rebuild main menu"
  - push origin/master (31c532e → 2bd4beb)
  - 정책: `.love` 릴리즈 자산은 release 시 별도 작업, 본 commit/push 에서 제외
