# snkrx-clone 패턴 — source-tree `engine/love/` 실행

**발견 위치**: bytepath-ex release 후 snkrx-clone (https://github.com/sigco3111/snkrx-clone) 저장소 구조를 조사.

**패턴 요약**: LÖVE 게임 fork에서 LÖVE 바이너리 + 소스 + entry script를 같은 저장소에 두어, 사용자가 clone만 받아도 별도 설치 없이 바로 실행 가능.

## 폴더 구조

```
bytepath-ex/
├── engine/love/         # ← LÖVE 11.5 바이너리 (love.exe, dlls, AppImage 등)
│   └── game.love        #   build script가 game.love를 여기로 복사
├── run.bat               # ← Windows 진입점
├── run.sh                # ← macOS/Linux 진입점
├── builds/windows/       # ← snkrx-clone 호환 마커 (placeholder 디렉토리)
├── main.lua              # 소스
├── rooms/, objects/, libraries/ ...
```

핵심: `engine/love/` 안에 OS별 LÖVE 바이너리를 두고, `run.bat`/`run.sh`가 그 바이너리를 호출. `.gitignore`로 `engine/love/`를 제외 → 사용자가 release zip 풀면 `engine/love/love.exe` + 소스 + `run.bat`/`run.sh`가 한 트리에.

## 진입점 스크립트

### Windows — `run.bat`

```batch
@echo off
REM Launch bytepath-ex in a console window so stderr from LÖVE is visible.
REM Use `start ""` (without the .bat) to detach from the console.
cd /d %~dp0
start "" engine\love\love.exe --console .
```

핵심:
- `cd /d %~dp0` — 스크립트의 디렉토리로 이동 (사용자 더블클릭 어느 위치든 동작)
- `start ""` — 콘솔 창을 띄우지 않고 백그라운드로 실행 (또는 `start "" /WAIT`으로 동기)
- `engine\love\love.exe --console .` — LÖVE 공식 exe + `--console` flag로 stderr 가시화 + `.` = 현재 디렉토리 = 게임 디렉토리

### macOS/Linux — `run.sh`

```bash
#!/bin/bash
# Run bytepath-ex from source on macOS / Linux.
# `love` is expected on PATH (install with `brew install --cask love` on
# macOS, or your distro's package manager on Linux).
set -e
cd "$(dirname "$0")"
love .
```

핵심:
- `cd "$(dirname "$0")"` — 스크립트 위치로 이동 (snkrx-clone의 `run.sh`와 동일하게 `cd D:/code/SNKRX; engine/love/love.exe --console .` 형태. bytepath-ex는 brew love 의존이라 더 단순)
- `set -e` — 실패 시 즉시 중단
- `chmod +x run.sh` — 실행 권한 (git에 권한 보존됨, .gitignore 아님)

## .gitignore

```
# Build artifacts
bytepath-ex.app/
bytepath-ex-macos-*.zip
bytepath-ex-*.love
# LÖVE 11.5 binaries bundled for source-tree execution (see run.bat / run.sh).
# Each platform's love.exe/dll lives in engine/love/ at the matching release.
engine/love/
```

핵심: `engine/love/`는 tracked 안 됨 → 사용자가 release zip 풀면 `engine/love/` 채워짐 → clone만 받은 사람은 직접 `run.sh`(brew) 또는 `brew install --cask love` 후 실행.

## 적용 recipe (snkrx-clone 패턴을 bytepath-ex에 적용)

1. **Windows release zip**: `engine/love/love.exe + dll + .ico` + `run.bat` + 게임 소스 (`main.lua`, `rooms/`, `objects/`, `libraries/`, `tutorial/`, `resources/`, `conf.lua`, `globals.lua`, `tree.lua`, `utils.lua`, `CHANGELOG.md`, `README.md`, `LICENSE`). `game.love`는 포함 안 함 (사용자가 직접 build script로 묶음).
2. **Linux release tar.gz**: `bytepath-ex-0.2.1-x86_64.AppImage` + `game.love` + `README.txt` (chmod +x 안내). LÖVE 공식 AppImage가 FUSE 미설치 환경에서 --appimage-extract fallback 제공.
3. **macOS release zip**: 기존 `bytepath-ex.app/Contents/Resources/game.love` (수동 교체) + ditto로 zip 묶음.
4. **공통**: `run.bat` / `run.sh`를 zip에 포함 → 사용자 zip 풀고 더블클릭으로 실행.

## snkrx-clone run.sh과의 차이

snkrx-clone: `cd D:/code/SNKRX; engine/love/love.exe --console .` — 절대 경로 하드코딩.

bytepath-ex: `cd "$(dirname "$0")"; love .` — 상대 + brew love 의존.

→ snkrx-clone는 `engine/love/` 안 바이너리 사용, bytepath-ex는 시스템 love 사용. **시스템 love 있으면 더 단순**. **시스템 love 없으면 snkrx-clone 패턴(`engine/love/love.exe`) 채택** — 두 패턴 모두 지원 가능 (예: `engine/love/love.exe`가 있으면 그걸 우선, 없으면 시스템 love).

```bash
#!/bin/bash
# Snkrx-clone style: prefer engine/love/love.exe if present.
if [ -x ./engine/love/love.exe ]; then
    cd "$(dirname "$0")"
    ./engine/love/love.exe .
else
    cd "$(dirname "$0")"
    love .
fi
```

판별 신호: LÖVE 게임 fork 저장소에서 사용자가 별도 LÖVE 설치 없이 clone 후 실행 가능하도록 만들고 싶음 → snkrx-clone 패턴 채택.
