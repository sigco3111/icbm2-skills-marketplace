# LÖVE2D 작은 한글 텍스트 가독성 — LÖVE 엔진 단 동작의 1차 근거와 권고 (2026-07-23)

> **용도**: 이 reference 는 "어떻게 적용하나"(`bytepath-help-highres-korean-rendering.md` 가 담당) 가 아니라 **"왜 LÖVE 단에서 그렇게 동작하는가"** 의 1차 근거를 짧게 정리한다. 새로운 한글 가독성 함정에 부딪혔을 때 본문이 알려주는 적용안이 통째로 잘못된 경우, 여기서 LÖVE 11.5 내부 동작을 다시 확인하라.

## LÖVE 11.5 `Font.cpp` 가 글리프를 만드는 순서

1. `love.graphics.newFont(filename, size, hinting, dpiscale)`
   - `size` = 래스터화할 글리프의 픽셀 크기.
   - `hinting` (기본 `"normal"`) = FreeType `FT_LOAD_TARGET_*` 매핑.
   - `dpiscale` (기본 = `love.graphics.getDPIScale()`) = 글리프 비트맵 안의 1단위 = 화면의 1/dpiscale 단위.
2. rasterizer 가 각 글리프마다 비트맵 (`GlyphData`) 생성. **한 번 캐싱**되면 다시 만들지 않는다.
3. `Font.cpp` 안에서:
   - `g.spacing = floorf(gd->getAdvance() / glyphdpiscale + 0.5f)` — advance(글리프 내부 좌표) 를 dpiscale 로 나누고 반올림해 화면 픽셀 advance 로 환산.
   - `getWidth(glyph)` 같은 측정 API 도 같은 환산 경로를 탄다.
4. 글리프는 glyph atlas 텍스처에 저장되고 `Font:setFilter(min, mag, anisotropy)` 가 화면에 그릴 때 적용된다. **mipmap 은 자동 비활성** (`filter.mipmap = Texture::FILTER_NONE`).

이 순서가 핵심 시사점 두 개를 만든다:

### 시사점 1 — `size=12` 로 로드한 뒤 출력 시 0.5배로 그려도 디테일은 복구되지 않는다

`size=12` 호출 시점에 12×12 비트맵으로 한 번 만들어진 글리프는 영구 캐싱. sx, sy 로 0.5배 출력은 텍스처 샘플링에서 다운샘플하는 거지 **없는 픽셀 정보를 복원하지 않는다**. 따라서 가독성을 올리려면 `size` 인자 자체를 키워야 한다 (예: `size=24`, sx=0.5 → 화면상 12px 이지만 내부 비트맵은 24×24).

### 시사점 2 — `Font:setFilter` 의 `min`/`mag` 는 별개의 의미다

- `min`: **축소** 시 (텍스처 좌표가 화면 픽셀보다 클 때). sx<1 인 down-sample 에서 결정적.
- `mag`: **확대** 시. sx>1 인 up-sample.
- 픽셀 폰트(8px bitmap)에 `nearest` 가 정답인 이유: 1:1 매핑에서만 픽셀이 잘리지 않기 때문. 같은 폰트를 확대하면 `nearest` 로 갈라진 픽셀이 보이고 `linear` 는 부드럽게 보간.
- 한글 TrueType AA 글리프를 `nearest, nearest` 로 두면: 안티에일리어싱된 부드러운 경계가 nearest 로 한 번 더 양자화된 뒤 사용자가 원하는 sx, sy 스케일로 다운샘플. 이중 손실. **반드시 `linear, linear` (또는 적어도 `linear, nearest`).**

## 검증된 권고 (우선순위)

### A. `newFont(path, size)` 의 size 를 키우고 sx, sy 로 줄여 그린다

```lua
fonts.kr_24 = love.graphics.newFont(kr_path, 24, 'normal', 1)
fonts.kr_24:setFilter('linear', 'linear')

-- 출력
love.graphics.setFont(fonts.kr_24)
love.graphics.print(glyph, x, y, 0, 0.5, 0.5)  -- 24×24 bitmap → 화면상 ~12px
```

- 폭·높이·기준선·배경 박스 계산에는 `* 0.5` 를 모두 곱한다.
- 영문 픽셀 폰트는 그대로 (별도 폰트 객체, `nearest, nearest`).

### B. `dpiscale` 인자를 명시 (보조)

```lua
fonts.kr_24_retina = love.graphics.newFont(kr_path, 12, 'normal', 2)
-- 글리프 비트맵은 사실상 24×24. 단 sx,sy 도 0.5 로 화면 픽셀 보정.
```

- `t.window.highdpi = false` 인 bytepath-ex 같은 프로젝트에서는 효과적으로 권고 A 와 중복.
- LÖVE 11.0+ 부터 per-object dpiscale 지원 (`changes.txt` 11.5 의 "Added the ability to specify a per-object pixel density scale factor when creating Images, Canvases, Fonts").

### C. `Font:setFilter('linear','linear')` — A 의 필수 동반

`nearest` 를 그대로 두면 권고 A 의 이점이 사라진다. C 는 A 와 분리할 수 없다.

### D. HiDPI 윈도우 / 2× Canvas 다운스케일 (구조 변경)

- `t.window.highdpi = true` + `love.window.fromPixels/toPixels` 로 좌표 변환.
- 또는 2× 해상도 Canvas 에 그린 뒤 `love.graphics.draw(canvas, 0, 0, 0, 0.5, 0.5)`.
- bytepath-ex 같이 480×270 좌표 체계가 전체 코드에 박혀 있으면 위험. 가독성이 다른 화면에도 검증된 다음에 검토.

## HintingMode 요약

| 값 | 동작 |
|---|---|
| `normal` | 기본. AA 글꼴에 권장. 한자/한글에는 보통 이게 가장 균형. |
| `light` | 약간 더 흐릿. 작은 글리프 원형 보존 시 검토 대상이지만 일상적이지 않음. |
| `mono` | 완전 양자화. 안티에일리어싱 끔. 픽셀 폰트 흉내. |
| `none` | 힌팅 끔. 가장 흐릿. |

한글/한자에 `mono` 사용 금지 — 권고 A/C 의 이점 상쇄.

## 작은 CJK 글꼴 관행적 최소 가독 사이즈

- 10px 이하: 사실상 판독 불가.
- 12px: 가독 한계선. bytepath-ex 의 m5x7 8px 옆에 있으면 한글이 1.5× 커 보임.
- 14~16px: 게임 UI sweet spot.
- 18px+: 메뉴/타이틀용.

`kr_24 × 0.5` (≈ 12px) 가 m5x7 8px 와 함께 보일 때 비율이 1.5× — 영문과 어색하면 `kr_20 × 0.6` 또는 `kr_24 × 0.6` 도 후보.

## 함정 (조사에서 확인된 위험)

- **`nearest` 를 모든 폰트에 일괄 적용하지 않는다** — 픽셀 폰트에는 OK, TrueType AA 글리프에는 손실.
- **`size=12` 후 출력만 축소** — 비트맵이 이미 작아져 영구 손실.
- **`HintingMode 'mono'` + `setFilter 'nearest'`** — AA 정보 모두 소실.
- **폭 계산 누락** — `font:getWidth(glyph) * sx` 안 하면 문자열 겹침.
- **헤드리스 무오류 ≠ 가독성** — `love .` 가 에러 없이 돌아도 시각 판정은 사용자 육안 확인 필수.

## 출처 / wiki 미러 조회

모든 출처 URL 과 작동하는 web.archive.org 형식은 `references/love2d-wiki-archive-lookup.md` 참조.
