# SNKRX 옵션 영구 저장 디버깅 (v0.1.20~23)

> **요약**: SNKRX fork의 옵션 (창 크기, 전체화면) 이 재시작 후 저장되지 않는 버그.
> 근본 원인은 v0.1.18 수정에서 도입된 `state.sx/sy` 가드 로직 + `engine_run`이 `config.window_width/height`를 항상 number로 보내는 충돌 + `state` 모듈 스코프 + main.lua에 `state` 전역 초기화 누락.

## 시계순 디버깅 로그

### 사용자 보고

```
"창크기 저장은 해결되었음"     ← v0.1.22 수정으로 sx/sy 보존
"전체화면도 해결되었는데, 이슈가 하나 있네.
 전체화면 상태에서 한번더 전체화면을 누르면
 창크기-를 두번 클릭했을 때의 사이즈로 변경되게 개선해줘."
```

### v0.1.18 도입 — `state.sx/sy` 무시 로직 (버그의 시작점)

원본 SNKRX: `state.sx` 사용해서 창 크기 기억. 우리 fork v0.1.18에서:

```lua
-- engine/init.lua
sx, sy = window_width/(config.game_width or 480), window_height/(config.game_height or 270)
state.sx, state.sy = sx, sy   -- ⭐ 무조건 덮어씀
```

**의도**: 풀스크린 회피를 위해 데스크톱 크기 사용.
**결과**: `state.sx/sy`에 사용자 설정 (예: 1.666) 있어도 `state.sx = 4` (1920/480)로 덮어써짐 → 다음 시작 시 또 4로 시작.

### v0.1.20 수정 — `use_state_sx` 가드 추가 (불충분)

```lua
local use_state_sx = false
if state.sx and state.sy and state.sx >= 0.5 and state.sx <= 3 and state.sy >= 0.5 and state.sy <= 3 then
  sx, sy = state.sx, state.sy
  use_state_sx = true
end
if not use_state_sx then
  state.sx, state.sy = sx, sy
end
```

**문제**: `state.sx`가 가드 (0.5~3) 밖이면 (예: 풀스크린 = 4) `use_state_sx = false` → `state.sx` 덮어씀. **무한 루프**.

### v0.1.21 — 풀스크린 분기 추가 + setMode 옵션 추가

```lua
if state.fullscreen == true then
  use_state_sx = true
elseif ... then ...
love.window.setMode(window_width, window_height, {
  fullscreen = fullscreen_mode,
  ...
})
```

### v0.1.22 — 사용자가 "창크기 저장 안 됨" 다시 보고

디버깅 결과 **다섯 가지 동시 버그** 발견:

#### 버그 A: `main.lua` engine_run이 config에 window_width/height 강제

```lua
-- main.lua line 2158
return engine_run({
  game_name = 'SNKRX',
  window_width = 1280,    -- ⭐ 항상 1280 (config 우선)
  window_height = 720,
  game_width = 480,
  ...
})
```

→ `engine/init.lua`에서 `config.window_width = 1280` (number) → 가드 `type(config.window_width) == 'number'` → **참** → config 우선 → `state.sx` 무시.

#### 버그 B: `state`가 main.lua에 정의 안 됨

`system.lua`가 `state`를 모듈 로컬로 사용. `main.lua`에 `state = {}` 없음 → `load_state`가 system.lua 안에서만 할당 → main.lua의 `state`는 **nil** → `state.sx` 비교에서 **nil >= 0.5** → 에러.

#### 버그 C: `setMode` 직후 `system.save_state()` 안 호출

`save_state`는 `quit` 이벤트에서만 호출 → **첫 사용자의 state.txt가 안 만들어짐**.

#### 버그 D: `display = 1`이 macOS에서 실패

`flags.display`가 nil이면 `getDesktopDimensions(nil)`이 외부 디스플레이 인덱스 → 모니터 0만 있으면 실패.

#### 버그 E: `config.window_width`가 nil일 때 `window_width = nil` (산술 에러)

```lua
if config.window_width ~= 'max' and config.window_width ~= 'half' then
  window_width = config.window_width  -- nil → window_width = nil
end
-- 다음 줄: window_width / 480 → CRASH
```

### v0.1.22 해결 — 5가지 동시 패치

```lua
-- 1. main.lua: engine_run에서 window_width/height 제거
return engine_run({
  game_name = 'SNKRX',
  game_width = 480,
  game_height = 270,
})

-- 2. main.lua: init()에서 state 초기화
function init()
  state = state or {}  -- 시스템 로컬 state와 main.lua의 글로벌 동기화
  shared_init()
  ...
end

-- 3. engine/init.lua: nil 가드
if config.window_width ~= 'max' and config.window_width ~= 'half' and config.window_width ~= nil then
  window_width = config.window_width
end

-- 4. engine/init.lua: setMode 직후 system.save_state()
love.window.setMode(...)
system.save_state()  -- ⭐ 첫 실행부터 state.txt 존재

-- 5. engine/init.lua: use_state_sx 가드 + display=0
local use_state_sx = false
if state.fullscreen == true then
  sx, sy = window_width/480, window_height/270
  use_state_sx = true
elseif state.sx and state.sy and state.sx >= 0.5 and state.sx <= 3 then
  sx, sy = state.sx, state.sy
  use_state_sx = true
end
love.window.setMode(window_width, window_height, {
  display = 0,
  fullscreen = fullscreen_mode,
  ...
})
```

### v0.1.23 — 전체화면 토글 (사용자 요청)

```lua
-- main.lua video_button_3 (fullscreen 버튼)
self.video_button_3 = Button{... action = function()
  if state.fullscreen then
    -- OFF: state.sx/sy 크기로 복귀
    local restore_sx = (state.sx and state.sx >= 0.5 and state.sx <= 3) and state.sx or 1.666
    local restore_sy = (state.sy and state.sy >= 0.5 and state.sy <= 3) and state.sy or 1.666
    window_width = math.floor(restore_sx * 480)
    window_height = math.floor(restore_sy * 270)
    state.fullscreen = false
    love.window.setMode(window_width, window_height, {fullscreen = false})
  else
    -- ON: 데스크톱 크기
    local _, _, flags = love.window.getMode()
    window_width, window_height = love.window.getDesktopDimensions(flags.display)
    state.sx, state.sy = window_width/480, window_height/270
    state.fullscreen = true
    love.window.setMode(window_width, window_height, {fullscreen = true})
  end
  system.save_state()
end}
```

## 핵심 교훈 (이 클래스의 일반 패턴)

### 1. main.lua와 engine/init.lua의 책임 분리

- **main.lua**는 사용자 진입점. config로 game_width/height, input 바인딩 등 **게임별 설정**만 전달. window_width/height처럼 **상태에 의존하는 값**은 보내지 말 것.
- **engine/init.lua**는 라이브러리 초기화. state.txt 로드 → setMode → save_state.

### 2. `state`는 글로벌이어야 함

Lua 모듈은 자체 스코프. `engine/system.lua`에서 `state = ...`는 **모듈 로컬**. main.lua의 `state`와 다름. `_G.state` 또는 main.lua의 글로벌 `state`로 명시적 동기화 필요.

```lua
function system.save_state()
  local str = "return " .. table.tostring(_G.state or state or {})
  love.filesystem.write("state.txt", str)
end
```

또는 main.lua의 `init()`에서 `state = state or {}` 명시.

### 3. `save_state`는 `quit` 이벤트가 아니라 setMode 직후에도 호출

첫 사용자가 메뉴 진입 전에 종료해도 state.txt가 만들어져야 다음 시작에 적용. **setMode 직후 save_state 추가 필수**.

### 4. `state.sx` 가드 범위 (0.5~3)는 신중히

`use_state_sx = true`일 때만 `state.sx` 덮어쓰지 않음. **풀스크린 (4)이나 4K (8) 같이 가드 밖**은 항상 새 계산. **풀스크린이 ON이면 sx/sy 의미 없으므로 (전체 화면) 가드 외 OK**.

### 5. config.window_width nil 가드 필수

`~= 'max' and ~= 'half'`만 검사하면 **nil도 통과** → `window_width = nil` → 다음 줄 산술 에러. **`~= nil` 가드 추가 필수**.

### 6. `display = 0` (not 1) for macOS 단일 디스플레이

`flags.display = 1`은 외부 디스플레이 가정. macOS 단일 디스플레이면 `1` 인덱스 없음 → `getDesktopDimensions(1)` 실패. **`display = 0` (메인 디스플레이) 가 기본**.

## 사용자 워크플로우 교훈 (2026-07-22)

> **"앞으로 내가 확인 할 때 까지 릴리즈는 하지말도록해"**

→ Release 발행은 사용자가 명시적으로 확인하기 전까지 자동 발행 금지. 빌드 + `dist/` 생성까지만, GitHub Release는 수동 명령 (`"릴리즈 해줘"`) 시에만.

이 워크플로 규칙은 fork 프로젝트의 release 발행에도 동일하게 적용. oss-fork-localization 패턴(`./build_all.sh && curl ...`)만으로는 부족, **`gh release create`/`gh release upload`는 사용자 확인 후**.

## 검증 체크리스트 (수정 후)

```bash
# 1. state.txt 삭제 후 첫 실행
rm ~/Library/Application\ Support/LOVE/SNKRX/state.txt
(love . > /tmp/love_test.log 2>&1 &)
sleep 5
kill -9 $!
cat ~/Library/Application\ Support/LOVE/SNKRX/state.txt
# → "sx=..., sy=..., fullscreen=..." 자동 생성

# 2. 옵션에서 창 크기 1280x720로 변경
# 3. 게임 종료 (love.quit 또는 Cmd+Q)
# 4. state.txt 확인: sx ≈ 2.666
# 5. 재시작: 1280x720 유지

# 6. 전체화면 → 1920x1080 풀스크린
# 7. 전체화면 → 1280x720 복귀
# 8. setMode 호출 후 save_state 확인
cat ~/Library/Application\ Support/LOVE/SNKRX/state.txt
# → "sx=2.666, fullscreen=false"
```

## 적용 대상

이 패턴은 다른 LÖVE 게임 fork에도 적용 가능:
- state.txt 기반 옵션 저장 (모든 LÖVE 게임)
- state 모듈 스코프 (lua 모든 require 패턴)
- setMode 옵션 호환성 (모든 LÖVE 게임)
- config vs state 우선순위 (모든 LÖVE 게임)

## 관련

- `oss-fork-localization`: MODIFIED.md 패턴 + git push (window_size = 1.666가 state에 들어있는지 매 빌드마다 확인)
- `cpp-game-koreanization`: gettext PO 워크플로와 다른 state.txt 직접 직렬화
