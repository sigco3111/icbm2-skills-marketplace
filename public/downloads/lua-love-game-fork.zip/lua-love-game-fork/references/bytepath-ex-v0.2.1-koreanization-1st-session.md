# bytepath-ex v0.2.1 한글화 1차 세션 시간순 (2026-07-22)

> 이 레퍼런스는 위임 + 직접 마무리 사이클로 풀 풀스택 한글화를 진행한 시간순 기록.
> 같은 LÖVE 게임에 한글화 작업할 때 **위임 범위 + fonts.kr_8 wiring + ConsoleLine character 단위 처리** 패턴을 참조용으로 보라.

## 세션 타임라인

### Phase 1 — 위임 (deleg_525e20d8, 600s 타임아웃)

**위임 task 입력**: 메뉴 + 12개 모듈 + UI 헤더 + 콘솔 부팅 + Options 언어 토글, 한/영 토글, NanumGothic 8px 픽셀, 단일 세션 풀스택.

**위임이 600s에 끊김**:
- 50 API call 소진 (폰트 검색 `find /` 60s 한 방 + 모듈별 dict 빌드 + sed 패치)
- 40% 완료: globals.lua T(), lang/ko.lua (15.6KB), lang/en.lua (14.4KB), fonts.kr_8, Options language 토글, Console 메인 메뉴 8개, AboutModule/HelpModule/ClearModule 한글화
- DeviceModule 진입 직후 끊김 (DeviceModule stat 풀 dict 작성 중)
- **위임이 "끝나면 검증한다"고 했지만 GUI 검증 단계까지 도달 못 함** → 잔여 작업 다수

**뿌리**:
- 모듈 12개 + 콘솔 부팅 ~50 라인 + UI 헤더 10+ 파일 = 패치 호출 40+ + 검증 = 50+ API call
- 폰트 검색 + 시스템 폰트 위치 탐색 (`find /`, `fc-list`) 단일 명령으로 60s 잡아먹음

**lesson**: 풀 풀스택 한글화는 위임 한 번에 안 끝남. 모듈 4~6개 + 검증이 한 위임 세션의 상한.

### Phase 2 — 직접 마무리 (제가 직접)

위임이 만든 ko.lua/en.lua에 누락된 dict 키 채우고, 모듈 9개 + UI 헤더 + 콘솔 부팅 T() 패치 진행:

1. DeviceModule: stat 풀 dict 통째로 device_<name>_lines = {line1, line2, ...} 형태로 미리 dict 안에 line list 정의. dict 인덱싱(`desc_lines(name)`)으로 동적 디스패치. T() 분기 회피.
2. DisplayModule/EffectsModule/ResolutionModule/SoundModule/ShutdownModule/FullscreenModule/CreditsModule/EscapeModule/HelpModule: 모든 addLine/print 라벨 → T('key')
3. UI 헤더: Paused/ScoreScreen/Tutorial/Stage HUD/SkillTree 헤더(Apply/Cancel/NODES BOUGHT/에러)/Console GUI 메뉴 8개
4. Console 부팅 시퀀스 bytepathIntro: T() 적용하되 swap table은 swap from/to 모두 영문 유지
5. ko.lua/en.lua에 누락 키(Display/Effects/Resolution/Sound/Shutdown/Escape/UI 헤더) dict 추가
6. 검증: `love .` 6초 부팅 stderr 비어있음 → 검은/흰 saturate 없음
7. commit + master push: `97274af 1차 한글화`

**위임이 만든 ko.lua에 발견된 함정 (직접 마무리 중 발견)**:
- DeviceModule stat 풀 dict가 한 줄 string으로 잘못 저장 (`device_fighter_stats = '++  HP / --- 기동성 / --- 공격 속도'`). 매핑표 원본은 여러 줄 — 통째로 `device_<name>_lines = {...}` dict로 교체.
- `intro_reached_target = '[   <OK>   ] 타겟 도달 (XYZ)'` 처럼 dict 안에 `[XYZ]` placeholder 박혀있는데, 코드에서 `.. random_word ..` 로 합쳐서 `(XYZ)(xyzword)` 중복. dict 안의 placeholder 제거 + 코드 합치기.

### Phase 3 — 한글 깨짐 픽스 (commit `f84642e`)

**문제**: GUI 띄우니 한글 라벨이 전부 □ 표시. stderr 비어있고 부팅 정상이라 stderr로는 한글 깨짐을 못 잡음.

**원인**:
- `love.graphics.print(T('계속하기'))` 호출 시 `self.font = fonts.Anonymous_8` (영문 픽셀 폰트)이 활성. Anonymous_8는 한글 glyph가 없어서 fallback 0으로 □ 출력.
- `fonts.kr_8`은 등록돼있지만 draw 단계에서 `setFont` 안 함.

**해결 — 헬퍼 + 일괄 변환**:

`globals.lua`에 `has_cjk()` + `printT()` + `textWidth()` 헬퍼 추가:

```lua
function has_cjk(str)
    if str == nil then return false end
    for i = 1, #str do
        local b = str:byte(i)
        if b == 0xEA or b == 0xEB or b == 0xEC or b == 0xED or b == 0xEE or b == 0xEF then
            return true  -- U+AC00..U+FFFF
        elseif b == 0xE3 then
            return true  -- U+3000..U+3FFF
        end
    end
    return false
end

function printT(font, text, ...)
    local prev = love.graphics.getFont()
    if has_cjk(text) and fonts and fonts.kr_8 then
        love.graphics.setFont(fonts.kr_8)
    elseif font then
        love.graphics.setFont(font)
    end
    love.graphics.print(text, ...)
    love.graphics.setFont(prev)
end

function textWidth(font, text)
    if has_cjk(text) and fonts and fonts.kr_8 then
        return fonts.kr_8:getWidth(text)
    end
    if font then return font:getWidth(text) end
    return 0
end
```

sed로 modules + Console.lua `love.graphics.print` → `printT(self.font, ...)` 일괄 변환:

```bash
files="objects/modules/*.lua rooms/Console.lua"
for f in $files; do
  sed -i '' 's/love\.graphics\.print(/printT(self.font, /g' "$f"
done
```

남은 `love.graphics.print` 검색해서 (rooms/Stage, SkillTree, Options + objects/Paused, ScoreScreen, Tutorial 등) 직접 patch.

**ConsoleLine character 단위 한글 처리**: ConsoleLine은 `self.text`를 글자 단위로 utf8sub 해서 Anonymous_8/m5x7/Arch로 그리는데, language 버킷에 `'kr'` 추가:

```lua
-- setCharacters
local is_cjk = has_cjk(c)
local char_lang = language
if is_cjk then char_lang = 'kr' end
table.insert(self.characters, {c = c, language = char_lang, visible = false, marker = marker})

-- 폭 계산
local kr_font = fonts.kr_8 or normal_font
if self.characters[j].language == 'kr' then
    width = width + kr_font:getWidth(self.characters[j].c)
end

-- draw
if self.characters[i].language == 'kr' then love.graphics.setFont(kr_font) end
```

### Phase 4 — 검증 + commit

- `love .` 부팅 stderr 비어있음 (검은/흰 saturate 없음)
- GUI 검증: 사용자가 화면 띄워서 한글 라벨 □ 안 깨지는지 확인 (위임 검증 단계 도달 못 했으므로 사용자가 직접 확인 필수)
- `.gitignore`에 `.ttc / *.love / *.bak / bytepath-ex.app/` 추가
- `git rm --cached resources/fonts/AppleSDGothicNeo.ttc` (55MB → GitHub 50MB 경고)
- commit `f84642e fix(kr): 한글 깨짐 픽스` + master push

## 위임 task 한계 + 직접 마무리 분할 패턴

**사용자 선택**: "A 풀 풀스택 한/영 토글" + "b 점진 (1차 → 검증 → 2차)"

**위임 한 번**: 모듈 4~6개 + 검증 (1차의 절반만 위임 가능) OR 12개 모두 직접 마무리.

**위임 두 번**: 모듈 6개 + 6개 분할. 각 위임 끝에 commit + master push. 사용자가 각 단계 사이 검증.

**위임 + 직접 마무리**: 위임이 모듈 4~6개 끝내고 commit 후 끊기면, 사용자가 보고 받고 다음 모듈 6개는 직접 마무리. 위임이 작업물을 commit 안 한 채 끊기면 작업물 날아감 — 위임 task에 "끝나지 않아도 commit + master push까지만이라도 보고하라" 명시 필요.

## 디바이스 stat 풀 dict 디자인 (참고용)

BYTEPATH v0.2.1 1차에서 `device_<name>_lines = {line1, line2, ...}` 패턴을 쓴 이유:

```lua
-- 모듈 코드 (DeviceModule:new)
local function desc_lines(name)
    local key = 'device_' .. name:gsub(' ', '_'):lower() .. '_lines'
    return ko[key] or en[key] or {}
end

self.device_descriptions = {
    ['Fighter']   = desc_lines('fighter'),
    ['Crusader']  = desc_lines('crusader'),
    ['Bit Hunter']= desc_lines('bit_hunter'),
    -- ... 9 디바이스
}

-- ko.lua
device_fighter_lines    = {'디바이스: 파이터',   '', '       모든 스탯 평균'},
device_crusader_lines   = {'디바이스: 크루세이더', '', '   ++  HP',           '   --- 기동성',     '   --- 공격 속도'},
-- ... 9 entries × 3~5 lines
```

**이점**: 모듈 코드 안에서 `for chunk in s:gmatch('/') do` 같은 split 로직 안 짜도 됨. dict 안의 line list가 곧 draw에 들어가는 line list.

**T() 패턴 회피한 이유**: T('device_fighter')는 헤더 한 줄만 반환. stat 풀은 여러 줄인데 T()가 string 한 개만 반환하면 `description = T('device_fighter') .. '\n' .. T('device_fighter_stats')` 식으로 코드 안에서 합쳐야. dict에 통째 line list로 두면 코드 안의 split/join 코드 X.

## selection_widths 한글화 후 폭 재계산 (참고)

모듈의 selection_widths (highlight 박스 폭) 측정 패턴:

```lua
-- BEFORE (영문):
self.selection_widths = {
    self.console.font:getWidth('clear CLASS data'),
    self.console.font:getWidth('clear PASSIVE data'),
    self.console.font:getWidth('clear ALL data'),
}

-- AFTER (한글 T() 결과로 폭 측정):
self.selection_widths = {
    self.console.font:getWidth(T('clear_class')),
    self.console.font:getWidth(T('clear_passive')),
    self.console.font:getWidth(T('clear_all')),
}
```

`self.console.font`는 Anonymous_8 (영문 폰트)이지만 한글 텍스트의 폭은 0으로 측정됨 → highlight 박스가 한글 라벨보다 좁아짐. **더 정확한 방법은 textWidth() 헬퍼**:

```lua
self.selection_widths = {
    textWidth(self.console.font, T('clear_class')),  -- 한글 → kr_8:getWidth
    textWidth(self.console.font, T('clear_passive')),
    textWidth(self.console.font, T('clear_all')),
}
```

1차에선 `font:getWidth` 그대로 두고 (highlight 박스가 좁아 보일 수 있음), 시각 검증 후 2차에서 textWidth로 재계산 가능.

## 콘솔 부팅 시퀀스 swap table 영문 유지 (참고)

BYTEPATH `bytepathIntro` swap table 1차 정책:

```lua
-- ✅ 안전 (1차): swap from / swap to 모두 영문. 표시 텍스트만 한글화.
self.console:addLine(delay + 4.80,
    '[  ;대기,  ] 사용자 및 세션 할당 중 (...) [...]',  -- 표시 텍스트는 한글
    1, {{';WAIT,', ' <OK> '}, {'allocating', 'allocated'}}  -- swap from/to 영문
)
-- 결과: swap 적용 후 화면에는 '[  <OK>  ] 사용자 및 세션 할당 중 (...) [...]' 로 표시
-- (swap from ';WAIT,' → '<OK>' 가 동작해서 ;WAIT, 자리가 <OK>로 바뀜.
-- 'allocating' → 'allocated' swap은 영문 단어 매칭이라 한글로 쓴 '할당' 이 아니라
-- 매칭 안 됨 → 화면에 '할당 중' 그대로 남음.)
```

**위험한 패턴**:

```lua
-- ❌ swap from을 한글로 바꾸면 ConsoleLine의 string match가 영문 라인의 swap from도 못 찾음
self.console:addLine(0, '[ ... ] 사용자 및 세션 할당 중 ...', 1, {{'할당', '할당됨'}})
-- 결과: '할당 중' → '할당됨 중' 으로 swap 동작 (모든 '할당' 인스턴스 매칭 → 의도 외)

-- ❌ swap to를 한글로 바꾸면 외부 코드가 ' <OK> ' 영문 status 마커 매칭 안 됨
self.console:addLine(0, '[  ;WAIT,  ] allocating ...', 1, {{';WAIT,', ' <OK> '}, {'allocating', '할당됨'}})
-- 결과: 화면엔 한글 swap to 표시되지만, 다른 swap 시점이나 모듈에서 '<OK>' 영어 매칭 안 됨
```

1차 권장: swap from/to 모두 영문 그대로. dict에 `swap_ok`, `swap_fail`, `swap_allocated` 등 키 등록만 해두고 값은 영문으로 두면 2차에서 swap to 한글로 바꿀 때 dict만 교체.

## 한/영 토글 정책 (사용자 컨벤션)

사용자 memory에 명시된 컨벤션 (2026-07-22 시점):
- **컬러 마커 보존** `$text%`, `@warning#`, `;system,`, `~command~` 절대 변경 금지 (string match/replace로 동작)
- **명령어 입력 영문 유지**: 'escape', 'passives', 'help', 'device', 'clear' 등. 1차에선 한글 alias 없음.
- **release 자산 보류**: commit + master push만. release/tag/zip은 사용자 GUI 검증 후.
- **솔직한 보고**: 막히면 fabricate 금지, 시간순 시도+결과 + 대안 3개.
- **점진 한글화**: 1차 (메뉴/모듈/UI 헤더/콘솔 부팅 + Options 토글) → 사용자 검증 → 2차 (stat 풀 700+ / 이름 풀 / 한글 alias).

## Bytepath-ex 잔여 작업 (2차)

1. `rooms/Classes.lua` 한글 헤더 (`~ CLASSES:`, `~ SP:`)
2. `rooms/Achievements.lua` 한글 헤더 + 40+ achievement description dict
3. `tree.lua` stat 풀 700+ 한글화 (가장 큰 작업)
4. `globals.lua` 이름 풀 (attack 16 / enemy 13 / device 9 / class 40+ / achievement 40+) 한/영 dual dict
5. `achievement_descriptions` 한글화 완성 (40+ 항목)
6. selection_widths 폭 textWidth() 마이그레이션 (한글 highlight 박스 정확히)
7. `devices` 한/영 alias (한글 명령어로 디바이스 토글)

## 위임 정책 권고 (BYTEPATH / SNKRX 둘 다 적용)

**위임 task 입력에 명시할 6가지**:
1. **범위**: 모듈 4~6개 OR 풀 풀스택 (1차의 절반만 위임 OR 직접 마무리 + 다음 위임)
2. **끝나지 않아도 commit + master push**: 작업물 보존을 위해 위임이 끊기기 직전이라도 현재까지 변경분 commit + push
3. **50 call 가까이 가면 자가 멈춤 + 현재 상태 보고**: 끊기면 솔직한 보고 패턴 강제
4. **검증 단계 명시**: 헤드리스 stderr (검은/흰 saturate) + GUI 검증 (fonts.kr_8 wiring, 셀 안 □ 깨짐, 한/영 폭 어긋남) 둘 다 필수
5. **컬러 마커 / 명령어 영문 유지**: 절대 변경 금지
6. **swap table from/to 영문 유지**: 1차에선 표시 텍스트만 한글화, swap 동작 자체는 건드리지 않음
