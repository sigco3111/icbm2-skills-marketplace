# BYTEPATH v0.0.1 — 검은 화면 + stderr 비어있음 Silent Fail 디버깅

> sigco3111/BYTEPATH v0.0.1 (2026-07-22)
> love 0.10.2 → 11.5 마이그레이션 중 발생한 **silent fail 시퀀스**의 시간순 로그
> → "stderr 비어있음 = OK" 판정의 함정 + 4단계 진단 루프 교훈

## 환경

| 항목 | 값 |
|---|---|
| M4 Mac mini 16GB | macOS 26.5.2 |
| LÖVE | 0.10.2 (원본) → 11.5 (brew, 검증용) |
| Lua | LuaJIT 2.1 (love 11.5) |
| brew lua | 5.5.0 (luac 검증 시 사용 안 함) |
| 원본 | https://github.com/a327ex/BYTEPATH (MIT, ~7.4K LOC) |
| Fork | https://github.com/sigco3111/BYTEPATH |

## 시간순 디버깅 시퀀스

| # | 사용자 신고 | 시도 | 결과 | 진짜 원인 |
|---|---|---|---|---|
| 1 | (실행 안 됨) | `brew install love` | Gatekeeper 팝업 | `xattr -dr com.apple.quarantine` (snkrx-clone과 동일) |
| 2 | "dlopen 크래시" | `love .` | `libraries/steamworks.lua:2864: dlopen(libsteam_api.dylib, 0x0005)` | Steamworks FFI가 require 단계에서 동적 lib 로드 (shim 필수) |
| 3 | "여전히 안 됨" | steamworks_shim.lua 적용 | `setLooping(nil)` 크래시 | love 11.5 strict type — opts.loop == true 변환 필요 |
| 4 | "setLooping 해결됨" | opts.loop == true | `isStopped (a nil value)` | love 11.5에서 Source:isStopped() 제거됨 |
| 5 | "isStopped 해결됨" | isPlaying 폴백 | **GUI 첫 화면 진입 ✅ 그러나 검은 화면** | silent fail — stderr 비어있음, love.draw 미호출 |
| 6 | "검은 화면" | `_dbg_drawn_once` stderr print | stderr에 아무것도 안 나옴 | love.draw 자체가 호출 안 됨 |
| 7 | (가설) custom love.run 문제 | `gotoRoom` pcall로 감싸기 | `[DBG] gotoRoom(Console) OK` 출력됨 | Console 객체 생성은 성공, draw 호출이 안 됨 |
| 8 | (가설 확인) `love.handlers` | love.handlers nil-safe 디스패치 | love.draw 호출되지만 Console:draw 캔버스 파이프라인이 silent fail | **custom love.run + love.handlers[name] 라인** |
| 9 | (최종 해결) custom love.run 통째로 비활성화 | 주석 처리 | 검은 화면 — 그러나 다른 원인 | Console:draw() 셰이더 호출이 silent fail |
| 10 | (진단) Console:draw를 임시 단순 print로 교체 | `love.graphics.print('[OK]')` | (사용자 GUI 검증 대기) | — |

## 핵심 교훈 4가지

### 1. "stderr 비어있음 = OK" 판정의 함정

snkrx-clone과 lua-love-game-fork SKILL.md §2에서 "stderr 비어있음 = 메인 루프 진입 OK"로 검증. **이 판정은 love.draw 호출 여부를 보장하지 않음**.

- M-4 (custom love.run + `love.handlers[name]`)의 경우: 메인 루프 진입 OK, love.load 호출 OK, 그러나 love.update/love.draw 호출 안 됨
- M-5 (Console:draw 캔버스 파이프라인)의 경우: love.draw 호출 OK, current_room:draw() 호출 OK, 그러나 draw 안의 셰이더/캔버스 호출이 silent fail

**새로운 판정 기준**:
```bash
# 헤드리스 검증 시 stderr 캡처 (30초 권장)
rm -f /tmp/love_run.log && (love . > /tmp/love_run.log 2>&1 &)
sleep 30
PID=$(pgrep -f "love \." | head -1)
[ -n "$PID" ] && kill -9 "$PID" 2>/dev/null
cat /tmp/love_run.log
```

→ stderr 비어있음 = **require는 OK**. 그 이상은 보장 안 함. **사용자 Mac GUI 검증 필수**.

### 2. ⭐ Custom love.run 비활성화는 love 11.5 마이그레이션의 안전판

원본이 자체 `love.run`을 가진 게임 (대부분의 love 0.10.2 게임):
- 자체 루프 + fixed_dt accumulator = 0.10.2에서는 잘 작동
- love 11.5에서 `love.handlers` 호출 시 silent fail → 검은 화면
- **가장 안전한 마이그레이션**: 자체 `love.run` 통째로 비활성화 → love 11.5의 default love.run 사용
- 영향: fixed_dt accumulator 사라짐 (60Hz → 가변 dt) — 게임플레이 영향 미미

```lua
-- 주석 처리 (삭제보다 보존이 안전 — 되돌릴 때 필요)
-- function love.run()
--     ... (원본 코드 그대로)
-- end
```

### 3. ⭐ timer:after(0.5, function() gotoRoom(...) end) silent fail 패턴

원본 BYTEPATH `main.lua` line 109:
```lua
timer:after(0.5, function() gotoRoom('Console') end)
```

- 0.10.2: Timer = `libraries/enhanced_timer/EnhancedTimer`, after() 잘 작동
- 11.5: EnhancedTimer가 love 11.5와 부분 호환 — `timer:after()`가 silent하게 호출 안 될 수 있음

**증상**: love.load 끝까지 실행되지만 Console이 안 뜨고 검은 화면.

**해결**: 즉시 호출로 교체
```lua
-- timer:after(0.5, function() gotoRoom('Console') end)
gotoRoom('Console')
```

→ love.load 끝에서 Console 진입, 0.5초 페이드인 효과는 잃지만 호환성 확보.

### 4. ⭐ Canvas + Shader 파이프라인 silent fail

게임의 첫 화면 (Console:draw)이 multi-pass 캔버스 + 셰이더로 구성:
```lua
function Console:draw()
    setCanvas(glitch_canvas) → setCanvas(main_canvas) → setCanvas(temp_canvas) → setCanvas(final_canvas)
    → draw(final_canvas, 0, 0, sx, sy)  -- ⭐ 셰이더 distort 적용
end
```

각 단계의 셰이더 uniform(`shaders.glitch:send('glitch_map', ...)`, `shaders.distort:send('time', ...)`)이 love 11.5에서 silent fail 가능.

**진단 패턴**: Room:draw()를 임시 단순 print로 교체
```lua
function Console:draw()
    love.graphics.setColor(255, 255, 255)
    love.graphics.print('[Console.draw OK]', 8, 8)
    love.graphics.print('lines=' .. #self.lines, 8, 24)
    return
end
```

→ 화면에 텍스트 보이면: draw 호출 OK, 캔버스/셰이더가 문제. 보이지 않으면: draw 자체 미호출.

**다음 단계 (해결 예정)**: 셰이더 uniform 이름/타입 점검 + `setShader()` 명시 호출 + `setBlendMode` 호출 순서 검증.

## 진단 pcall 패턴 (다음 세션에 재사용)

```lua
-- main.lua gotoRoom 함수에 적용
function gotoRoom(room_type, ...)
    if current_room and current_room.destroy then current_room:destroy() end
    local ok, room = pcall(_G[room_type], ...)
    if not ok then
        io.stderr:write('[DBG] gotoRoom(' .. tostring(room_type) .. ') FAILED: ' .. tostring(room) .. '\n')
        io.stderr:write(debug.traceback() .. '\n')
        current_room = nil
        return
    end
    current_room = room
end

-- love.draw 첫 줄에 적용 (현재는 진단용으로만 남겨둘 것)
function love.draw()
    if not _dbg_drawn_once then
        _dbg_drawn_once = true
        io.stderr:write('[DBG] love.draw() entered\n')
        if current_room then
            io.stderr:write('[DBG] current_room type=' .. type(current_room) .. '\n')
        end
    end
    if current_room then current_room:draw() end
end
```

**주의**: `io.stderr:debug`는 없는 메서드. `io.stderr:write`만 사용.

## conf.lua BYTEPATH 고유 패턴

원본 BYTEPATH는 `t.releases` 테이블과 `t.version = "0.10.2"`를 가짐:
- `t.releases`: love 0.10.2 시대 release 빌드 도구용 → love 11.5에서 무시됨, 영향 없음
- `t.version = "0.10.2"`: 첫 실행 시 "Compatibility Warning" 팝업 표시 → OK 누르면 진행

love 11.5 호환 패치 시 핵심만:
```lua
t.window.width = 1280
t.window.height = 720
t.window.usedpiscale = false  -- M4 Retina에서 DPI 자동 축소 비활성화
t.window.minwidth = 480
t.window.minheight = 270
```

`t.version`은 수정 불필요 (호환성 경고는 무해). `t.releases`도 무해.

## 향후 작업 (다음 세션)

- [ ] **Console:draw() 셰이더 파이프라인 love 11.5 호환화** — `shaders.glitch:send('glitch_map', ...)`, `shaders.distort:send(...)` 점검
- [ ] 셰이더 uniform 타입 확인 (love 11.5에서 `table` → `vec2/vec3` 자동 변환 변경 가능성)
- [ ] `love.graphics.setShader()` 명시적 nil 호출 + `setBlendMode('alpha')` 복원 순서 검증
- [ ] CJK 4/4 (UI 라벨 T() 적용) — Console 모듈 12개 + Stage + SkillTree + Classes
- [ ] build_love.sh + build_all.sh 작성 (snkrx-clone 패턴 베이스)
- [ ] v0.1 커밋 + git push + gh release

## 핵심 파일 위치 (sigco3111/BYTEPATH 기준)

| 파일 | 역할 |
|---|---|
| `conf.lua` | t.window.width/height, usedpiscale (v0.1 fork에서 수정) |
| `main.lua` line 1-2 | Steam shim 교체 (v0.1 fork에서 수정) |
| `main.lua` line 105-110 | resize + gotoRoom('Console') 즉시 호출 (v0.1 fork에서 수정) |
| `main.lua` line 500-542 | custom love.run 비활성화 (v0.1 fork에서 수정) |
| `libraries/steamworks_shim.lua` | Steam shim (v0.1 fork에서 신규) |
| `libraries/sound.lua` line 108, 119 | setLooping(opts.loop == true) (v0.1 fork에서 수정) |
| `libraries/sound.lua` line 56-62 | isStopped → isPlaying 폴백 (v0.1 fork에서 수정) |
| `lang/init.lua` | T() + CJK 헬퍼 + love.graphics.print 오버라이드 (v0.1 fork에서 신규) |
| `lang/ko.lua` | ~160개 한국어 사전 (v0.1 fork에서 신규) |
| `rooms/Console.lua` line 121 | Console:draw() 임시 디버그 (현재 상태 — 미해결) |
