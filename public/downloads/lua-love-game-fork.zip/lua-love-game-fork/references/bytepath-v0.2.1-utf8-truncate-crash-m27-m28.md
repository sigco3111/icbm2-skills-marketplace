# BYTEPATH v0.2.1 후속 세션 (2026-07-22) — UTF-8 truncate / LuaJIT 비트 / textWidth 자가 손상 시간순

이 문서는 SKILL.md 본문의 압축 요약 + 1차원적 시간순 + 5가지 함정 디버깅 흐름을 보존한다. SKILL.md 본문을 가볍게 유지하기 위해 케이스별 시간순을 별도 파일로 분리.

## 세션 컨텍스트

- 프로젝트: bytepath-ex (LÖVE 11.5 LuaJIT 2.1 게임, BYTEPATH 한글화 1차~4차)
- 세션 시작: 사용자가 "메뉴는 정상화 되었음. 하지만 터미널 형태의 UI는 아직 한글가독성이 많이 떨어지고, UI도 엉망임" + 화면 3장 (Device / Escape / Options)
- 이전 세션 (v0.27 진입 직전): fonts.kr_16 (16px) + printT 5 인자 + per-glyph baseline + line_y stride 18 까지 픽스 완료. **두 가지 새 함정 (M-29 / M-30) + 두 가지 가독성 발견 (M-32 / M-33)** 이 본 세션에서 발견.
- 사용자 컨벤션: 한글화는 점진 (1차 풀 → 사용자 검증 → 2차 풀). 1차 풀 검증은 사용자 GUI 스크린샷으로만 가능 (헤드리스 stderr로는 검출 불가).

## 시간순 (4차 한글화 보정)

### 1. 사용자 보고 — UI 엉망

사용자가 세 종류의 화면을 첨부:
- **Device 모듈**: 다각형 안에 한글 라벨이 다각형 회전(-90도)을 따라 회전되어 보임
- **EscapeModule**: 8개 key 항목 (`key:XXXXXX  난이도  XX+`) — 한글 `난이도` 가 글리프가 잘림
- **Options**: `디스플레이 모드:` `창 크기:` `모니터:` 등 라벨이 baseline 안 맞고 한글 글리프가 위쪽 잘림

### 2. 솔직한 진단 — DeviceModule 회전 컨텍스트 함정 (M-26)

`DeviceModule:draw()` 시작에서 `pushRotateScale(self.x, self.y, 0, 1, 1)` 외부 회전 컨텍스트 안에서 다각형 그림 → 그 후 **device_name_label, UNLOCKED/LOCKED, TECH/ATK/DEF/SPD/LCK 라벨이 같은 컨텍스트 안에서 그려져서 다각형의 translate/scale 영향을 받음**. 다각형이 `pushRotate(self.x - self.w/2 + 10, ..., -math.pi/2)` (-90도 회전) 안에 들어가고, 한글 라벨이 다각형 영역 안에 들어가면 라벨도 -90도 회전.

**수정**: 다각형 그린 후 외부 `pushRotateScale` 컨텍스트도 `pop()` 해제. 라벨은 viewport 좌표에 평범하게 그림. stat 풀 (`디바이스: 파이터` 등)은 viewport 하단 (`gh - line_h * n`)에 고정.

### 3. 솔직한 진단 — ConsoleLine / InputLine baseline 어긋남 (M-24, M-25)

`shared_baseline_y = self.y + kr_font:getHeight() * 0.75` 패턴으로 한 줄 baseline 통일. **문제**: `kr_font:getHeight() * 0.75` 가 `16 * 0.75 = 12`. self.y=0 일 때 baseline_y = 12. 폰트 박스 0~16 안에 baseline 12 위치 → 정상. **그런데 line_y stride 18인데 한글 한 줄 그릴 때 self.y=18, baseline_y=30 → 폰트 박스 18~34**. 이전 줄 self.y=0, baseline_y=12 → 박스 0~16. **이전 줄 박스 0~16과 다음 줄 박스 18~34 사이 2px 여백 OK**.

### 4. Options 라벨 baseline 안 맞음 + 잘림

Options의 라벨 (`디스플레이 모드:`) 이 Anonymous_8 박스(8px)에 들어가는데 한글 fonts.kr_16(16px) 박스는 8px 안에 안 들어가려다 위쪽 잘림. **근본 원인**: printT 안에서 fonts.kr_16 setFont + `love.graphics.print(text, x, y, 0, 1, 1, 0, 0)` 호출. prev 폰트 (Anonymous_8) 복원. **그러나 한글 baseline은 prev 폰트의 박스에 의존하지 않으므로 OK**. 그런데 **값 영역 (`창모드`, `끄기`, `한글`) 도 printT 호출하는데, 값 영역은 Anonymous_8 박스(8px) 안에 fonts.kr_16 박스(16px)를 그리려다 글리프가 박스 위로 삐져남**.

**수정**: 값 영역은 `printT` 호출 대신 **직접 fonts.kr_16 setFont + `y + baseline_y_offset`으로 그리기**. 끝에서 명시적 `setFont(font)` 복원.

### 5. `..` suffix truncate 가독성 — M-32 발견

`..` truncate suffix를 붙이려 했더니 (`디스플레이..` `창 크기:..` `언어:..`), 사용자 스크린샷에서 **모두 `..` 잘림이 가독성 떨어짐** 판단. **짧게 잘린 한글 한 글자 (`디스플레이 모드`) 가 `..` 붙은 것 (`디스플레이..`) 보다 명확**.

**수정**: truncate 시 `..` suffix 안 붙임. 그냥 shorten_utf8_last로 한글 한 글자 잘림. Console GUI 메뉴 desc truncate도 같은 패턴.

### 6. 컬럼 폭 — M-33 발견

라벨 컬럼 80~88px에 한글 6글자 라벨 (`디스플레이 모드:` = ~88px) 들어가려다 항상 잘림. **`디스플레이..` `창 크기:..` `언어:..` `~ 콘솔로 돌아가..` 처럼 모든 라벨이 잘림**.

**수정**: label_x=8, value_x=128, label_col_w=112px. 한글 7글자 (`디스플레이 모드:` ≈ 100px) 들어감.

### 7. `UTF-8 decoding error: Invalid UTF-8` 크래시 (M-27)

Options 라벨 truncate 시 `s:sub(1, -2)` 사용 → byte 단위 substring이 한글 3바이트 중간에서 잘라서 잘못된 UTF-8 시퀀스 → `font:getWidth()` 호출 시 `'UTF-8 decoding error: Invalid UTF-8'` 크래시.

**수정**: `shorten_utf8_last(s)` 헬퍼 — continuation bytes (10xxxxxx) 거꾸로 따라가서 lead byte 찾고 코드 포인트 전체를 한 번에 제거.

### 8. `Syntax error: ')' expected near '&'` 크래시 (M-29)

shorten_utf8_last 안에서 native `&` 비트 연산자 사용 → LuaJIT 5.1 syntax error로 부팅 단계 크래시.

**수정**: `bit.band(b, 0xC0)` 로 교체.

### 9. `UTF-8 decoding error: Not enough space` 크래시 (M-30)

M-27 픽스 후 textWidth 안에 trailing bytes cleanup 로직 추가 → **정상 한글 텍스트 ('시작') 의 마지막 바이트(0x91 = continuation byte) 를 잘못 잘라냄** → 잘못된 UTF-8 → `fonts.kr_16:getWidth('시')` → "Not enough space".

**수정**: textWidth의 cleanup 로직 제거. caller 책임 (`shorten_utf8_last` 가 UTF-8 안전 처리).

### 10. fonts.kr_16 fallback 안전성 — M-31

`fonts.kr_16`이 nil인 환경 (NanumGothic.ttc 누락) 에서 `fonts.kr_16:getWidth('한글')` 호출 시 "Not enough space". main.lua의 kr_*_N 로드 검증 + `fonts.kr_16` 없을 때 0 반환하도록 fallback 안전화.

## v0.28 결정 사항 종합

| 항목 | 결정 |
|---|---|
| 한글 폰트 | fonts.kr_16 (16px 네이티브) |
| line_y stride | 18 |
| per-glyph baseline | `shared_baseline_y = self.y + kr_font:getHeight() * 0.75` |
| printT 시그니처 | `(font, text, x, y, rotation)` 5 인자 (v0.26 단순화) |
| textWidth | 자체 cleanup 없이 `font:getWidth`만 호출 (v0.28 self-cleanup 금지) |
| truncate | `shorten_utf8_last(s)` UTF-8 안전 (M-27) |
| truncate suffix | `'..'` 안 붙임 (M-32 가독성) |
| 비트 연산 | `bit.band` / `bit.lshift` 등 LuaJIT 내장 bit 라이브러리 (M-29) |
| Options 컬럼 | label_x=8, value_x=128, label_col_w=112 (M-33) |
| DeviceModule 라벨 | 다각형 그린 후 pushRotateScale 외부 컨텍스트 pop (M-26) |
| fonts.kr_16 없을 때 | textWidth가 0 반환 (M-31 — Anonymous_8 fallback 안 함) |

## 사용자가 본 결과 (스크린샷 3장 기준)

| 화면 | v0.27 진입 직전 | v0.28 적용 후 |
|---|---|---|
| Device 모듈 | 다각형 안 한글 라벨 회전, stat 풀 viewport 밖 | 라벨 viewport 정렬, stat 풀 viewport 하단 고정 |
| EscapeModule | key 항목 `난이도` 글리프 잘림 | 한/영 baseline 정렬 |
| Options | `디스플레이..` `창 크기:..` 모두 잘림, 한글 값 baseline 안 맞음 | 라벨 잘림 없이, 값 baseline 정렬 |

## 사용자가 받은 후 추가 피드백

```
1. 메뉴의 폰트 사이즈는 적당함.
2. 디바이스는 화면을 벗어남(폰트도 잘 안보임).
3. 터미널도 폰트를 알아보기 힘듦
4. 옵션 텍스트가 겹침
5. 도움말도 텍스트를 알아보기 힘듦

터미널 형태의 한글텍스트는 전체적으로 알아보기 어려운데, (폰트 해상도는 올리고, 화면 출력 크기는 좀 줄여야될 것 같음)
```

이 피드백이 **fonts.kr_16 (16px 데이터) + 0.75x 표시 스케일 (v0.25~v0.26 의 정당성)** 임. v0.26 M-23/M-24 픽스 후 **v0.27~v0.28 미세 보정으로 안정화**.

## v0.28 작업이 후속 세션에 주는 진입점

1. **fonts.kr_16 + 0.75x 스케일 + line_y stride 18 + per-glyph baseline** 조합이 bytepath-ex 한글화의 **stable 진입점**.
2. **LuaJIT 5.1 환경 제약**: 모든 비트 연산은 `bit.band` / `bit.lshift` (native `&` `|` `<<` `>>` 금지).
3. **textWidth는 self-cleanup 금지** (정상 데이터 손상 방지).
4. **truncate는 `shorten_utf8_last`** + `'..'` suffix 금지.
5. **Options 컬럼 112~128px** (한글 14~16px 폰트 기준).
6. **DeviceModule 같은 pushRotateScale 컨텍스트 pop 2번** (내부 pushRotate + 외부 pushRotateScale).
7. **fonts.kr_16 없을 때 textWidth가 0 반환** — Anonymous_8로 잘못 fallback 안 함.

## 후속 작업 (2차)

- SkillTree stat 풀 700+ 한글화
- globals.lua 이름 풀 (attack 16 / enemy 13 / device 9 / class 40+ / achievement 40+) 한글화
- classes 룸 / achievements 룸 헤더 한글화
- selection_widths 박스 미세 조정
- 2차 풀 위임 시점 결정 (사용자 검증 OK 후)
