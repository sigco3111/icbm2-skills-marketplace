# BYTEPATH Classes 룸 / 룸→룸 카메라 누수 (v0.10–v0.11)

작성: 2026-07-22 (bytepath-ex, Classes 룸 + Passives = SkillTree 룸 디버깅 세션)

## 배경

`/Users/mac/work/bytepath-ex/rooms/Classes.lua`에서 두 번의 반복 디버깅이 발생했다:

1. **첫 시도** — 셰이더/캔버스 4-pass 파이프라인 우회 후 (v0.6 패턴: `camera:attach + 직접 그리기`), 글자 saturate는 사라졌지만 사용자가 "Classes/Passives 화면에 진입하면 검은 화면"을 보고.
2. **두 번째 시도** — `Classes:new()`에 카메라 상태 리셋 라인 추가 (`camera:lookAt(gw/2, gh/2)` + `camera.scale = 1` + smoother clear). 헤드리스로는 정상 부팅 확인됐지만 사용자 GUI 검증은 다음 세션에 넘겼다.

이 두 문제의 교훈:

## 룸→룸 카메라 누수 (M-9 — v0.11 신규)

BYTEPATH는 모든 룸이 같은 전역 `camera` 객체를 공유한다. 룸 A에서 `camera:lookAt(x, y)`, `camera.scale = 0.5`, `Camera.smooth.damped(10)` 같은 호출을 한 뒤 룸 A→B로 전환되면 카메라 상태가 그대로 남는다. 룸 B의 `:new()`에서 카메라를 리셋하지 않으면 모든 UI가 화면 밖으로 밀려나거나 검은 화면이 된다.

**판별 신호**:
- "이전에는 작동했던 룸이 갑자기 검은 화면/빈 사각형/잘림을 보인다"
- 화면 비율 변화나 비정상적인 빈 캔버스
- `headless 검증`에서는 stderr 비어있고 process S 상태 (silent fail 패턴)

**판별 명령**:
```bash
# 어떤 룸이 카메라를 만지는지
grep -n "camera:lookAt\|camera.scale\|camera.smoother\|camera:attach" rooms/*.lua
# 각 룸의 :new()가 카메라 리셋을 호출하는지 — 매트릭스가 비어 있으면 (ROOM:leak) 표시
```

**해결 패턴 — 모든 룸의 `:new()` 첫 줄에 카메라 상태 리셋 추가**:

```lua
function <Room>:new()
    -- 항상 다른 룸에서 남긴 카메라 잔재를 깨끗이 청소
    camera:lookAt(gw/2, gh/2)
    camera.scale = 1
    if Camera.smooth and Camera.smooth.damped then
        -- 다른 룸이 damped smoother를 켜놓았으면 끄기 (Camera.smooth 모듈이 존재할 때만)
        camera.smoother = Camera.smooth.none and Camera.smooth.none() or nil
    end
    -- (캔버스, 영역, 폰트 초기화 등)
end
```

**이유**:
- `camera:lookAt(gw/2, gh/2)` — 화면 중앙으로 강제
- `camera.scale = 1` — 줌 1배 (다른 룸이 SkillTree처럼 0.2까지 줄였을 수 있음)
- `camera.smoother` 정리 — SkillTree처럼 `Camera.smooth.damped(10)`을 켜놓으면 카메라가 lerp 따라가서 룸 전환 직후 첫 프레임 위치가 화면 밖

**판별 패턴 (실측, v0.10)**:

| 룸 | `camera:lookAt` 호출이 `:new()`에 있는가 | 누수 위험 |
|------|------|------|
| Console | 있음 (`gw/2, gh/2`, `scale = 1`) | 없음 |
| Stage | 있음 (`gw/2, gh/2`, `scale = 1`) | 없음 |
| SkillTree | 있음 (`32, 96`, scale은 tween으로 변경) | 다른 룸은 SkillTree 잔재 위험 |
| Options | 있음 (`gw/2, gh/2`, `scale = 1`) | 없음 |
| **Classes** | **없음** | **있음** — 사용자가 보고한 검은 화면의 진짜 원인 후보 |

BYTEPATH `Console:update`는 `camera:lookAt(camera.x, camera.y + 12)` 호출로 콘솔이 길어지면 카메라 y가 gh 초과로 누적 이동 → Console→Classes 시 카메라가 화면 아래로 밀린 상태 잔존.

**응급 진단 단계 (다음 검은 화면 보고 시)**:
1. `headless stderr` 확인 → 비어있으면 silent fail 패턴
2. `io.stderr:write('[DBG] <Room>:draw entered, camera.x=' .. tostring(camera.x) .. ' camera.scale=' .. tostring(camera.scale) .. '\n')` 임시 로그 추가
3. love 재실행, `tail -n 50 /tmp/love_run.log` — 카메라 좌표/스케일이 화면 중심에서 멀어져 보이면 M-9 확정
4. `:new()`에 카메라 리셋 블록 추가하고 재검증

## 셰이더 우회 시 트레이드오프 (v0.6 패턴 적용 시 명시)

v0.6 패턴을 적용해서 셰이더 4-pass 파이프라인(letterbox effect)을 우회하면:

**얻는 것**:
- 셰이더 saturate → 0..1 색상이 그대로 보임 (검은/흰색 사각형 사라짐)
- 0..255 색상 정규화 한쪽만 적용해도 다른 쪽 (직접 print) 정상 출력
- 캔버스 객체 4~5개 안 만들어도 됨

**잃는 것**:
- 글자 흩뜨림 (GlitchDisplacement 게임오브젝트의 RGB 채널 분리 효과)
- 콘솔/Stage 사운드 +5dB 같은 셰이더로 인한 bass boost
- 룸 분위기 (CRT monitor effect)

**사용자 안내**: 셰이더 우회 적용 후에는 룸이 시각적으로 좀 더 평평해 보인다는 점 + 모든 `setColor(X, Y, Z)` (X/Y/Z ≤ 255 정수)는 셰이더 단계 saturate 1.0 되니까 **반드시 0..1 정규화 동반 필요** 라는 점을 사용자에게 알려야 함. 둘 다 처리 안 하면 "글자 saturate → 잘못된 듯 보이는 문제" 재발.

## 두 룸 짝 비교 (Classes vs SkillTree, bytepath-ex v0.10)

같은 셰이더 패턴(5-cavas, glitch/rgb_shift/distort)인데 **SkillTree는 정상, Classes는 깨짐**이었음. 깨진 차이는:

1. `Classes:new()`는 `rgb_canvas` 생성 누락 + 색상 6곳 미정규화 (M-7.5 룸별 누락)
2. `Classes:new()`는 카메라 리셋 호출 없음 (M-9)

같은 두 함정이 **다른 룸**에서도 동시에 나타날 수 있으므로, 룸 단위 정규화/캔버스 매트릭스와 카메라 잔재 점검을 항상 같이 한다:

```bash
# 1) 룸별 정규화 잔재
for f in rooms/*.lua; do
  residue=$(grep -nE 'setColor\((127|222|255)(,| )' "$f" | wc -l)
  if [ "$residue" -gt 0 ]; then
    echo "⚠ $f: $residue 0..255 색상 잔재"
4  fi
done

# 2) 룸별 newCanvas 누락
for name in rgb_canvas glitch_canvas main_canvas temp_canvas final_canvas; do
  for f in rooms/*.lua; do
    uses=$(grep -c "self.$name" "$f")
    creates=$(grep -c "self.$name = love.graphics.newCanvas" "$f")
    if [ "$uses" -gt "$creates" ]; then
      echo "⚠ $f: $name uses=$uses creates=$creates"
    fi
  done
done

# 3) 룸별 카메라 잔재 점검
for f in rooms/*.lua; do
  room=$(basename "$f" .lua)
  lookat=$(grep -c "camera:lookAt" "$f" | head -1)
  scale_reset=$(grep -c "camera.scale = " "$f")
  if [ "$lookat" -lt 1 ] && [ "$scale_reset" -lt 1 ]; then
    echo "⚠ $room: 카메라 리셋 호출 없음 (room→room leak 위험)"
  fi
done
```

이 매트릭스 3종을 정기적으로 돌려서 룸 추가 시 누락을 잡아낸다.
