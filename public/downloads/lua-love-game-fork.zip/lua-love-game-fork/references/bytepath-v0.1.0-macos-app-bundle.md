# BYTEPATH v0.1.0 — macOS standalone .app 번들 빌드

> sigco3111/bytepath-ex v0.1.0 release (2026-07-22)
> LÖVE 11.5 게임을 외부 의존성 없는 standalone .app으로 만들어 GitHub release에 첨부

## 왜 .app 번들이 필요한가

`brew install --cask love`로 설치한 love.app 안에서 `love .`로 게임을 실행하면 brew love + 게임이 함께 동작하지만, **사용자가 brew love를 설치하지 않은 경우** 게임을 단독 실행할 수 없다. Steam/itch.io/그냥 DM으로 배포할 때는 .app 또는 .exe가 필수.

## 핵심 발견: brew love.app 구조

brew cask의 `love.app`은 단순한 단일 바이너리가 아니라:

```
/Applications/love.app/
├── Contents/
│   ├── MacOS/love             -- 117KB launcher (메인 진입점)
│   ├── Frameworks/            -- ⭐ 10개 framework 통째로 들어있음
│   │   ├── love.framework/love       -- 실제 love 엔진
│   │   ├── Lua.framework/
│   │   ├── SDL2.framework/
│   │   ├── OpenAL-Soft.framework/
│   │   ├── freetype.framework/
│   │   ├── libmodplug.framework/
│   │   ├── mpg123.framework/
│   │   ├── ogg.framework/
│   │   ├── theora.framework/
│   │   └── vorbis.framework/
│   ├── Info.plist
│   ├── PkgInfo
│   └── Resources/
│       └── game.love          -- ⭐ 실제 게임 (zip → .love 리네임)
```

**이 구조를 그대로 복제 + game.love만 교체 + Info.plist만 손보면 standalone .app이 된다**.

MacOS/love launcher (117KB)는 `Contents/Frameworks/love.framework/Versions/A/love` (실제 엔진, 수 MB)를 dlopen한다. Frameworks 통째 복사가 안 되면 게임이 launch하자마자 즉시 죽음.

## 빌드 스크립트 (검증된 버전)

```bash
#!/bin/bash
# build_love.sh - LÖVE 게임 standalone .app 빌드
set -e

PROJECT="${1:-$(basename "$PWD")}"  # 현재 디렉터리명 또는 인자
VERSION="${2:-0.1.0}"
BUNDLE="${PROJECT}.app"
LOVE_APP="/Applications/love.app"

[ -d "$LOVE_APP" ] || { echo "ERROR: $LOVE_APP not found. brew install --cask love"; exit 1; }

# 1) .love (zip) 생성
TMP_LOVE="/tmp/${PROJECT}.love"
rm -f "$TMP_LOVE"
zip -qr "$TMP_LOVE" . \
  -x "*.DS_Store" ".git/*" "*.app/*" "*.zip" "build*.sh" "docs/*"

# 2) love.app 통째 복사 → 우리 .app
rm -rf "$BUNDLE"
cp -R "$LOVE_APP" "$BUNDLE"

# 3) game.love 교체
cp "$TMP_LOVE" "$BUNDLE/Contents/Resources/game.love"

# 4) Info.plist만 우리 프로젝트에 맞게 교체
cat > "$BUNDLE/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleName</key><string>${PROJECT}</string>
    <key>CFBundleDisplayName</key><string>${PROJECT}</string>
    <key>CFBundleIdentifier</key><string>dev.local.${PROJECT}</string>
    <key>CFBundleVersion</key><string>${VERSION}</string>
    <key>CFBundleShortVersionString</key><string>${VERSION}</string>
    <key>CFBundleExecutable</key><string>love</string>
    <key>CFBundlePackageType</key><string>APPL</string>
    <key>LSMinimumSystemVersion</key><string>11.0</string>
    <key>NSHighResolutionCapable</key><true/>
</dict>
</plist>
PLIST

# 5) zip (Resources의 메타데이터 보존)
ZIP="${PROJECT}-macos-${VERSION}.zip"
rm -f "$ZIP"
ditto -c -k --sequesterRsrc --keepParent "$BUNDLE" "$ZIP"

ls -lh "$BUNDLE/Contents/Resources/game.love" "$BUNDLE/Contents/MacOS/love" "$ZIP"
```

## 검증 단계

```bash
# 1) 실행되는지 확인
"$BUNDLE/Contents/MacOS/love" &
sleep 3
ps -p $! -o pid=,stat=  # Ss = 정상
# 2) 압축 풀어도 동일하게 동작하는지
mkdir -p /tmp/test-app && rm -rf /tmp/test-app/*
ditto -x -k "$ZIP" /tmp/test-app
"/tmp/test-app/${BUNDLE}/Contents/MacOS/love" &
sleep 3
ps -p $! -o pid=,stat=
kill %1 %2 2>/dev/null
```

## 함정 4가지

### 1. Frameworks 통째 복사 안 함 (가장 흔한 실수)

`cp love.app/Contents/MacOS/love game.app/Contents/MacOS/love`처럼 launcher만 복사하면 → 사용자가 앱 실행 시 "love quit unexpectedly" 또는 즉시 종료. love.framework/love를 dlopen하지 못해서.

**해결**: `cp -R love.app game.app`로 통째 복사 후 game.love와 Info.plist만 교체.

### 2. PkgInfo 안 지움

brew love.app의 `Contents/PkgInfo`는 `APPL????` 바이트. 우리 bundle에 그대로 두면 Finder가 love로 인식. 사실 그대로 둬도 무방하지만, 깨끗하게 하려면 Info.plist만 신뢰.

### 3. Info.plist의 CFBundleName 공백

CFBundleName에 공백/한글이 들어가면 macOS가 Finder 표기에서 깨질 수 있음. 영숫자/하이픈만 사용.

### 4. Gatekeeper 격리

빌드한 .app은 quarantine 속성이 없음 (로컬 빌드). DM/웹 배포 시 사용자가 처음 열 때 Gatekeeper 경고:

```bash
# 사용자 측 해결
xattr -dr com.apple.quarantine /Applications/bytepath-ex.app
# 또는 우클릭 → 열기 → 경고 → 열기
```

## GitHub release 첨부

```bash
gh release create v0.1.0 \
  --title "v0.1.0" \
  --notes-file CHANGELOG.md \
  bytepath-ex-macos-0.1.0.zip

# 결과물
# 73.6MB zip (love.framework 10개 + game.love 64MB)
```

`gh release create`는 `tag_name`이 push된 상태여야 함. 순서:
1. `git tag -a v0.1.0 -m 'v0.1.0' && git push origin v0.1.0`
2. `gh release create v0.1.0 ...` (push된 tag 사용)
3. 또는 `--target master` 옵션으로 tag 자동 생성 + release 동시에

## snkrx-clone과의 비교

SNKRX v0.1.5에서도 동일 패턴이 검증됨. 차이점:
- SNKRX: 디버깅용 symbols 포함된 love.app 사용 (liblove.dylib) — brew cask는 stripped 버전이지만 동작은 동일
- BYTEPATH: love 11.5의 모든 framework (SDL2, OpenAL, mpg123 등) 통째 복사 — 사운드/입력 정상 동작 확인

## 활용 가능 다른 게임

- 모든 LÖVE 게임에 그대로 적용 가능 (어떤 LÖVE 게임이든 .love로 묶이면 standalone .app 빌드 가능)
- 단, LÖVE 0.10.x 게임을 11.x brew love로 빌드하면 호환성 문제 (M-0~M-8) 발생 가능
- 권장: LÖVE 11.x에 마이그레이션한 후 .app 빌드

## 한계

- **macOS 전용** — Windows .exe는 `love.exe + .love zip` 패턴이 다름 (별도 reference 필요)
- **74MB** — love.framework 통째 복사 때문. 줄이려면 love에서 불필요한 framework 제거 (예: theora 비디오 디코딩 안 쓰면 제외) 가능하지만 호환성 리스크 있음
- **코드 사이닝 없음** — Gatekeeper 경고는 그대로. 공인 인증서로 사이닝하면 경고 제거 가능
- **공유 프레임워크 가정 안 함** — 매 앱이 74MB. 사용자가 love 10개 게임 설치해도 740MB. 시스템 love를 shared library로 사용하려면 다른 빌드 패턴 필요
