# BYTEPATH / love2d: 셰이더 색상 정규화 + 룸 viewport letterbox 출력 패턴

> 실측 기반 — sigco3111/bytepath-ex v0.2.x 작업 (2026-07-22)
> 새 룸 만들 때마다 반복 등장하는 두 가지 함정.

## 함정 1 — `setColor(255,255,255)` saturate 흰색

**증상**: 룸 그리기가 셰이더 파이프라인(`glitch` / `rgb_shift` / `distort`)을 거치면 0..255 정수 색이 modern GLSL에 들어가 saturate → (1, 1, 1) = 흰색. 텍스트가 안 보임, 선택 메뉴 cursor 안 보임, 노드 외곽선이 흰 saturate.

**판별**:
```bash
grep -nE 'setColor\((255|127|222|4)(, 255)?\)' rooms/MyRoom.lua | head
```

**해결 — 모든 `setColor`를 즉시 0..1로 정규화**:
```lua
-- ❌ WRONG: 흰 saturate
love.graphics.setColor(255, 255, 255)
love.graphics.setColor(127, 127, 127)            -- 회색 어두움으로 saturate
love.graphics.setColor(r, g, b, 128)            -- 8-bit alpha → 1.0으로 saturate

-- ✅ CORRECT: 0..1 float
love.graphics.setColor(1, 1, 1)
love.graphics.setColor(127/255, 127/255, 127/255)
love.graphics.setColor(r/255, g/255, b/255, 128/255)

-- ✅ 글로벌 컬러 테이블 helper:
local function to01(c) return {c[1]/255, c[2]/255, c[3]/255} end
printCenteredText(text, x, y, font, to01(color))
```

**룰**:
- 룸을 새로 만들면 그 룸 안의 **모든 setColor 호출을 처음에 한 번에** grep해 정규화
- 글로벌 컬러 (default_color, hp_color, ammo_color 등)는 0..255 테이블 → `setColor` 직전 항상 `/255`
- `rectangle('fill', x, y, w, h)` 자체는 영향 없음 — `setColor`만 문제

## 함정 2 — `drawGameCanvas` letterbox 출력 누락 → viewport 검은 여백

**증상**: 룸 진입 시 화면 일부만 보이고 우하단(또는 우상단)이 검정. 룸 안의 모든 그리기는 정상.

**진단**:
```bash
grep -n 'drawGameCanvas\|love.graphics.setCanvas\|camera:attach' rooms/MyRoom.lua | head
```

`drawGameCanvas(canvas)` 호출이 없으면 **viewport (480x270)가 윈도우의 좌상단 일부만 차지**하고 나머지 영역이 검정. BYTEPATH는 `applyDisplayMode()`로 윈도우 사이즈 = `gw*window_scale × gh*window_scale`이라 viewport는 그 안에 들어감. 그러나 viewport *이외의* 윈도우 영역이 검정.

**Console.lua / Stage.lua는 multi-pass 캔버스 → `drawGameCanvas(self.final_canvas)`** 로 윈도우 매핑.

**SkillTree.lua / Classes.lua** 는 셰이더 우회 + 직접 그리기를 하며 **`drawGameCanvas`를 호출하지 않음**. 그 결과 윈도우 일부만 차지.

**해결 — 룸에 offscreen canvas 1개 + 마지막에 `drawGameCanvas`**:

```lua
function MyRoom:new()
    self.render_canvas = love.graphics.newCanvas(gw, gh)  -- ⭐ viewport를 그릴 캔버스
end

function MyRoom:draw()
    love.graphics.setCanvas(self.render_canvas)
    love.graphics.clear(0, 0, 0, 1)
    camera:attach(0, 0, gw, gh)
    -- (여기에 viewport 그리드/노드/UI 모두)
    camera:detach()

    love.graphics.setCanvas()        -- default (back buffer)
    drawGameCanvas(self.render_canvas)  -- ⭐ letterbox 출력
end
```

**흐름**:
1. `setCanvas(render_canvas)` + `clear` → viewport 좌표 (0,0)~(gw,gh)에 그림
2. `camera:attach(0, 0, gw, gh)` 안에서 화면 픽셀 = world 좌표 (BYTEPATH/STALKER-X의 경우 1:1)
3. `camera:detach()`
4. `setCanvas()` → back buffer
5. `drawGameCanvas(render_canvas)` → `getLetterboxOffset()`로 윈도우에 fit
   - 윈도우 1280x720, viewport 480x270이면 `scale = 1280/480 = 2.67`. viewport가 윈도우 중앙에 (520, 90) 위치로 2.67배 확대되어 그려짐.

**셰이더 우회 path와 결합**:
- 룸에서 셰이더를 안 쓰는 경우 (Skills tree 류) → 위 패턴 그대로
- 룸에서 셰이더를 쓰는 경우 (Console / Stage 류) → 기존 4-pass 유지, 마지막에 `drawGameCanvas(final_canvas)`

**Stage / Console 룸이 검정으로 보이는 함정**:
- 셰이더 파이프라인의 `temp_canvas` / `final_canvas`가 `gw × gh` 사이즈가 아닌 `wx × wy`로 만들어지면 viewport와 어긋남. 항상 `gw × gh`로.

## 함정 3 — `bytepath_main_y` 누적이 menu cursor 어긋남

**증상**: 콘솔의 "main menu" 항목 (escape/start/help/...) 화면에 보이지만 cursor 박스가 다른 줄 (예: 'Your objective' 줄) 위에 그려짐.

**진짜 원인 (3가지 동시 작용)**:
1. **원본 `bytepath_main_y = self.line_y + 13*12`** — `self.line_y`가 addLine마다 12씩 누적, 22줄 후에는 264+. 메뉴 그릴 때 화면 밖 408 픽셀 → cursor가 화면 밖에서 그려짐
2. **`addLine`은 `timer:after`라서 비동기** — `self.bytepath_main_menu_lines[key] = self.lines[#self.lines]`는 **즉시 실행 시점에 self.lines에 아직 line이 추가 안 됐음 → nil 저장**
3. **STALKER-X/Camera는 `getCameraCoords` 메서드가 없음** — `camera:getCameraCoords(...)`는 nil 반환 → 가드 `if cy >= -16`에서 silent fail

**가장 단순한 해결 — GUI 메뉴로 전환**: 위치 버그 자체를 우회. 텍스트 menu 대신 박스 단위로 그리기.

## 함정 4 — GUI 메뉴 구현 패턴 (GUI 메뉴로 전환 시)

원본 `bytepathMain` / `bytepathMain2`의 addLine + cursor 매칭 로직을 **단일 `self.main_menu` 박스**로 교체:

```lua
function Console:_showMainMenu(opts)
    self.main_menu = {
        x = opts.x, y = opts.y,
        w = opts.w, h = opts.h,
        spacing = 4,
        titles = opts.titles,
        selection_index = 1,
        hovered_index = nil,
        visible = true,
    }
    self.main_menu_actions = {escape = function() ... end, ...}
end

function Console:_mainMenuCell(i)
    return m.x, m.y + (i - 1) * (m.h + m.spacing)
end

function Console:_runMainMenu(i)
    local key = m.titles[i].key
    self:rgbShift()
    self:_hideMainMenu()    -- ⭐ 실행 전에 menu 가리기 (다음 screen에 겹치지 않음)
    if self.main_menu_actions[key] then self.main_menu_actions[key]() end
end

function Console:update(dt)
    if self.main_menu and self.main_menu.visible then
        local m, n = self.main_menu, #self.main_menu.titles
        if input:pressed('up')   then m.selection_index = m.selection_index > 1 and m.selection_index - 1 or n end
        if input:pressed('down') then m.selection_index = m.selection_index < n and m.selection_index + 1 or 1 end
        if input:pressed('return') then self:_runMainMenu(m.selection_index) end

        -- 숫자 키 1..n hotkeys
        for i = 1, 8 do
            if input:pressed(tostring(i)) then self:_runMainMenu(i) end
        end

        -- 마우스 hover/click (letterbox 변환)
        local ox, oy, s = getLetterboxOffset()
        local mx, my = love.mouse.getPosition()
        local gx, gy = (mx - ox) / s, (my - oy) / s
        m.hovered_index = nil
        for i = 1, n do
            local cx, cy = self:_mainMenuCell(i)
            if gx >= cx and gx <= cx + m.w and gy >= cy and gy <= cy + m.h then
                m.hovered_index = i; break
            end
        end
        if m.hovered_index then
            if m.hovered_index ~= m.selection_index then
                m.selection_index = m.hovered_index
                playMenuSwitch()
            end
            if input:pressed('left_click') then self:_runMainMenu(m.hovered_index) end
        end
    end
end

function Console:_drawMainMenu()
    local m = self.main_menu
    if not m or not m.visible then return end

    -- Background plate
    local total_h = #m.titles * (m.h + m.spacing) - m.spacing + 6
    love.graphics.setColor(0, 0, 0, 0.75)
    love.graphics.rectangle('fill', m.x - 4, m.y - 4, m.w + 8, total_h)

    for i, title in ipairs(m.titles) do
        local cx, cy = self:_mainMenuCell(i)
        local is_sel = i == m.selection_index

        -- 선택: 노란 채움 + 흰 외곽선 + 검은 글자 + > 화살표
        -- hover: 어두운 보라 채움 + 흰 외곽선 + 흰 글자
        -- 일반: 어두운 채움 + 회색 외곽선 + 흰 글자

        -- (setColor / rectangle / print 한 줄씩)
    end
end

function Console:draw()
    -- (기존 4-pass 셰이더 파이프라인)
    drawGameCanvas(self.final_canvas)
    self:_drawMainMenu()  -- ⭐ 셰이더 패스 후 (셰이더에 안 걸리게)
end
```

**왜 GUI 메뉴가 text 메뉴보다 안전한가**:
- `selection_index`로 정수 하나만 관리 — 좌표 누적 버그 X
- `drawn viewport에서 직접 그리기`(셰이더 패스 후) — camera/coordinate 계산 안 함 → silent fail 없음
- hover/click 검출은 cell 좌표만 비교 → 매칭 race condition 없음
- 키보드/마우스 둘 다 자연스럽게 통합

**셰이더 패스 순서 (Console:draw)**:
```
1. glitch_canvas ← glitch 셰이더
2. main_canvas ← lines + modules + bytepath_main cursor (legacy text menu)
3. temp_canvas ← rgb_shift 셰이더
4. final_canvas ← distort 셰이더
5. drawGameCanvas(final_canvas)   -- 백버퍼로 letterbox 출력
6. _drawMainMenu()                -- ⭐ 백버퍼에 직접 그리기 (셰이더 무관)
```
GUI menu는 step 6에서 백버퍼에 그려져 glitch/rgb_shift/distort 모두 회피.

## 함정 5 — STALKER-X/Camera API와 hump camera의 차이

BYTEPATH는 `Camera = require 'libraries/STALKER-X/Camera'`. hump의 `libraries/hump/camera.lua`와 다른 구현:

| 메서드 | hump Camera | STALKER-X Camera |
|---|---|---|
| `attach(x,y,w,h)` | ✓ | `attach()` (인자 없음, viewport 그대로) |
| `detach()` | ✓ | ✓ |
| `getCameraCoords(x, y)` | ✓ | ❌ **없음** |
| `getMousePosition()` | ✓ | ✓ |
| `lookAt(x, y)` | ✓ | ✓ |
| `move(dx, dy)` | ✓ | ✓ |
| `scale` / `rot` | ✓ | ✓ |
| `smoother` | ✓ (`camera.smooth.damped`, etc.) | 없음 (custom `damp_x`/`damp_y` 멤버) |

**`getCameraCoords` 호출 시 silent fail**: STALKER-X/Camera는 함수가 없으므로 호출이 nil 반환. `if cy >= -16 then` 같은 가드에서 즉시 silent fail → cursor 안 그려짐.

**해결**: `getCameraCoords` 대신 viewport 좌표를 **직접 계산** (BYTEPATH는 camera가 (0,0)에 있고 scale=1이라 `world.y == screen.y`):
```lua
-- ❌ WRONG (STALKER-X에 없는 메서드)
local cx, cy = camera:getCameraCoords(x, y)

-- ✅ CORRECT: viewport 좌표 직접 사용
local screen_y = menu_line.y + math.floor(self.font:getHeight()/2) - self.font:getHeight() + 2
love.graphics.rectangle('fill', screen_x, screen_y, w, h)
```

BYTEPATH 콘솔처럼 camera scale이 1.0이면 world 좌표 = screen 좌표. zoom이 들어가는 룸 (SkillTree)에서는 별도 처리 필요.

## 요약 — 룸 신규 작업 시 체크리스트

1. **모든 setColor 호출 정규화** (`/255`)
2. **drawGameCanvas 우회** — `render_canvas` setCanvas + clear + 그리고 `drawGameCanvas(self.render_canvas)`
3. **메뉴는 GUI 박스**, text-based menu 사용 안 함
4. **camera:getCameraCoords 사용 안 함** (STALKER-X)
5. 셰이더 패스 후 그리기는 drawGameCanvas 호출 이후에
