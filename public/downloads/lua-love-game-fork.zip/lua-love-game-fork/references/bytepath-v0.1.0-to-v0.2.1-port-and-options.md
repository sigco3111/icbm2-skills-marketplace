# BYTEPATH v0.1.0 → v0.2.1 — 셰이더 + 옵션 화면 + isStopped 핫픽스

> sigco3111/bytepath-ex — 2026-07-22, ~6시간 세션
> BYTEPATH를 LÖVE 0.10.2 → 11.5로 포팅 + 디스플레이 옵션 화면 추가
> → 1k+ stars OSS 마이그레이션 + "사용자 OK 전까지 release 안 만든다" 정책의 사례

## 0. 이 세션이 다른 점

v0.0.1 case study는 **인프라 셋업** (한국어화 골격, Steam shim, 셰이더는 모름)이었다.
v0.1.0 세션은 **실제 부팅 + 실제 게임플레이** 까지 가는 마이그레이션이었다. 검은 화면 5번 → 흰 화면 1번 → 정상까지 가는 디버깅 시퀀스가 핵심.

## 1. 시간순 실패 시퀀스 (사용자 정정까지)

| # | 가설 | 시도 | 결과 | 진짜 원인 |
|---|---|---|---|---|
| 1 | Steamworks FFI가 require 단계 크래시 | steamworks require 제거 | `setLooping(nil)` 크래시 | love 11.5 strict type |
| 2 | setLooping / isStopped 2곳만 수정 | opts.loop==true + isPlaying 폴백 | 화면 검정 | custom love.run이 love.handlers[name] 호출 → silent fail |
| 3 | custom love.run + love.handlers 비활성화 | love.run 통째 비활성화 | 콘솔 진입 성공, Stage 진입 시 검정 | Canvas/Shader 파이프라인 가설로 한참 우회 |
| 4 | Console:draw() 다중 Canvas 우회 | main_canvas에 직접 draw | 콘솔은 OK, Stage에서 다시 검정 | 동일 원인 (Stage:draw()도 같은 파이프라인) |
| 5 | Stage:draw()도 동일하게 우회 | main_canvas에 직접 draw | **흰색 saturate** | 셰이더 컴파일 fail인데 silent하게 white fallback |
| 6 | "별 많은 프로젝트가 이럴 리가 없다" | (사용자 정정) | GitHub 이력 조사로 전환 | — |
| 7 | scillidan/BYTEPATH-fork PR #13 발견 | dev branch clone + diff | `extern Image` → `uniform sampler2D` 8개 + 색상 0..1 정규화 | 진짜 원인 |

**가설 1~5는 5번 연속 빗나감**. 사용자 정정이 결정적이었다.

## 2. ⭐ 진짜 원인: LÖVE 0.10.2 → 11.5 셰이더 신택스 차이

**원본 BYTEPATH 셰이더 (legacy GLSL)**:
```glsl
extern Image glitch_map;
vec4 effect(vec4 color, Image texture, vec2 tc, vec2 pc) {
    vec4 glitch_pixel = Texel(glitch_map, tc);
    ...
}
```

**LÖVE 11.5 셰이더 (modern GLSL 3.00 ES)**:
```glsl
uniform sampler2D glitch_map;
vec4 effect(vec4 color, sampler2D texture, vec2 tc, vec2 pc) {
    vec4 glitch_pixel = Texel(glitch_map, tc);
    ...
}
```

**love 11.5의 silent fail**: 셰이더 로드는 성공, 컴파일은 fail, 단 셰이더 단계의 모든 픽셀이 흰색으로 saturate됨. stderr에 에러도 안 뜸.

**8개 셰이더 전부 변환 필요**:
- combine.frag, displacement.frag, distort.frag, flat_color.frag, glitch.frag, grayscale.frag, rgb.frag, rgb_shift.frag
- `extern Image` → `uniform sampler2D`
- `extern number` → `uniform float`
- `extern vec2` → `uniform vec2`
- `Image` 파라미터 타입 → `sampler2D`

## 3. ⭐ 색상 0~255 → 0.0~1.0 정규화

LÖVE 0.10.2는 `setColor(255, 255, 255)`를 셰이더 uniform에 넘길 때 자동 정규화. 11.5는 변환 없이 그대로 전달 → 셰이더가 1.0 초과값을 받으면 saturate.

**함정**: 셰이더가 없는 fill/print도 같은 0~1 통일 필요. 원본은 모든 `setColor`가 0~255 정수였음.

```lua
-- WRONG (love 11.5에서 흰색 saturate)
love.graphics.setColor(127, 127, 127)
love.graphics.setColor(255, 255, 255)
local r - 32, g - 32, b - 32  -- 0~255 연산

-- CORRECT
love.graphics.setColor(127/255, 127/255, 127/255)
love.graphics.setColor(1, 1, 1)
local r/255, g/255, b/255
```

**스코프**: `Stage:draw()`, `Console:draw()`, `love.graphics.setBackgroundColor(background_color)`, `love.draw`의 flash_frames 사각형 전부. `globals.lua`의 색상 테이블은 `{r, g, b}` 0~255로 유지하고 사용 시점에 `/255`.

## 4. ⭐ drawGameCanvas() letterbox 헬퍼

원본은 `love.graphics.draw(canvas, 0, 0, 0, sx, sy)`로 480x270 캔버스를 sx배 확대. 1280x720 윈도우에서 4배 확대하면 종횡비 유지 OK이지만, 비표준 사이즈나 풀스크린에서 종횡비 깨짐.

**해결**: 윈도우 크기 기준 letterbox.

```lua
function getLetterboxOffset()
    local win_w, win_h = love.graphics.getDimensions()
    local scale = math.min(win_w / gw, win_h / gh)  -- 종횡비 유지
    local draw_w, draw_h = gw * scale, gh * scale
    return (win_w - draw_w) / 2, (win_h - draw_h) / 2, scale
end

function drawGameCanvas(canvas)
    local ox, oy, scale = getLetterboxOffset()
    love.graphics.draw(canvas, ox, oy, 0, scale, scale)
end
```

**중요**: Options 방의 마우스 클릭 hit-test도 letterbox 좌표 변환 필수.

```lua
local mx, my = love.mouse.getPosition()
local ox, oy, s = getLetterboxOffset()
local gx, gy = (mx - ox) / s, (my - oy) / s
```

## 5. ⭐ v0.1.0 마이그레이션 시 빠뜨린 부분: isStopped 6번째 라인

**v0.1.0에서 잡은 곳** (3곳):
- `sound.lua:58` `playing_sources[i].source:isStopped()` in `soundUpdate`
- `sound.lua:108` `cloned_source:setLooping(opts.loop)` in `play`
- `sound.lua:119` `source:setLooping(opts.loop)` in `play`

**v0.1.0에서 놓친 곳** (1곳):
- `sound.lua:156` `source.source:isStopped()` in `playRandomSong`

**증상**: 게임 시작 5~10초 후 BGM 큐가 다음 곡으로 넘어갈 때 `playRandomSong()` 호출 → 즉시 크래시.

**교훈**: deprecated API 제거 시 `git grep :<methodName>` (콜론 포함)으로 전수 검색 필수. **3/4만 잡고 1/4를 놓치면 hotfix가 필요하다**.

**검증 명령**:
```bash
git grep -n 'isStopped\|setLooping\|isPlaying' -- '*.lua'
# → 0건이어야 통과
```

**수정 패턴** (nil-safe 가드 + 역순 순회):
```lua
for i = #playing_sources, 1, -1 do
    local source = playing_sources[i].source
    local stopped = source.isStopped and source:isStopped() or not source:isPlaying()
    if stopped then table.remove(playing_sources, i) end
end
```

**역순 순회 이유**: `table.remove`로 인덱스가 바뀌는 와중에 정방향 순회하면 다음 항목 건너뜀.

## 5-bis. ⭐ v0.2.0 Options 작업에서 발견: `Input:pressed` nil-safe 부재 (2026-07-22)

**시점**: v0.1.0 → v0.2.0 작업으로 Options 방을 만들고 `input:bind('mouse1', 'click')`로 click 액션을 등록한 직후, Options 진입 시 크래시:

```
Error: libraries/boipushy/Input.lua:97: bad argument #1 to 'ipairs'
(table expected, got nil)
```

**원인**: boipushy의 원본 `Input:pressed(action)`은 단순히 `for _, key in ipairs(self.binds[action])` 호출. action이 nil이거나 `self.binds[action]`이 비어 있으면 즉시 크래시. Options에서 `input:unbindAll()` → `input:bind('mouse1', 'click')` 사이에 race가 발생했거나, 어딘가에서 click 액션이 비어 있는 상태로 `pressed`가 호출됨.

**수정 (boipushy/Input.lua 본체)**:

```lua
function Input:pressed(action)
    if not action or not self.binds[action] then
        -- No binding registered for this action: nothing pressed, no error.
    else
        for _, key in ipairs(self.binds[action]) do
            if self.state[key] and not self.prev_state[key] then
                return true
            end
        end
    else
        for _, key in ipairs(Input.all_keys) do
            -- ... all_keys scan (기존 else 블록)
        end
    end
end

function Input:released(action)
    if not action or not self.binds[action] then return end
    for _, key in ipairs(self.binds[action]) do
        if self.prev_state[key] and not self.state[key] then
            return true
        end
    end
end

function Input:down(action, interval, delay)
    if not action or not self.binds[action] then return end
    -- ... 기존 분기
end
```

**검증 명령**:
```bash
git grep -n 'input:pressed\|input:released\|input:down' -- '*.lua' | grep -v '^libraries/boipushy/'
# → 모든 호출처가 대응하는 input:bind를 가지는지 확인
```

**왜 중요**: `input:pressed`는 게임 내 거의 모든 update 콜백에서 호출되므로, 한 곳이라도 미정의 action이 들어오면 즉시 게임 멈춤. Options 방만이 아니라 일반적 안전망.

**SKILL.md 본문 위치**: §M-3-bis.

## 6. ⭐ display_mode + window_scale 옵션 시스템

원본은 `fullscreen` boolean + `display` number + `sx, sy` 정수 3개로 표현. 멀티모니터 + 비표준 윈도우 사이즈 + letterbox 조합에는 부족.

**새 모델**:
```lua
display_mode = 'windowed' | 'fullscreen' | 'desktop'  -- string
window_scale = 1..6  -- 480x270 타일 개수
display = 1..N  -- 모니터 인덱스
sx, sy = window_scale, window_scale  -- legacy alias
```

**핵심**: `applyDisplayMode()` 단일 진입점 + 모든 변경 후 `save()` 자동 호출.

```lua
function applyDisplayMode()
    local mode = display_mode or 'windowed'
    display = display or 1
    window_scale = clampWindowScale(window_scale or 2)
    sx, sy = window_scale, window_scale

    if mode == 'windowed' then
        fullscreen = false
        love.window.setMode(gw * window_scale, gh * window_scale, {
            display = display, fullscreen = false, borderless = false,
            resizable = true, minwidth = gw, minheight = gh,
        })
    elseif mode == 'fullscreen' then
        fullscreen = true
        local w, h = love.window.getDesktopDimensions(display)
        love.window.setMode(w, h, {
            display = display, fullscreen = true,
            fullscreentype = 'exclusive', borderless = false,
        })
        sx, sy = math.floor(w / gw), math.floor(h / gh)
        window_scale = sx
    else  -- 'desktop'
        fullscreen = true
        local w, h = love.window.getDesktopDimensions(display)
        love.window.setMode(w, h, {
            display = display, fullscreen = true,
            fullscreentype = 'desktop', borderless = true,
        })
        sx, sy = math.floor(w / gw), math.floor(h / gh)
        window_scale = sx
    end

    if save then pcall(save) end  -- ⭐ 항상 자동 저장
end
```

**`love.resize` 핸들러**: 창 가장자리 드래그로 window_scale 자동 갱신 + 저장.

```lua
function love.resize(w, h)
    if (display_mode or 'windowed') ~= 'windowed' then return end
    local s = math.min(math.floor(w / gw + 0.5), math.floor(h / gh + 0.5))
    if s ~= window_scale then
        window_scale = clampWindowScale(s)
        sx, sy = window_scale, window_scale
        if save then pcall(save) end
    end
end
```

## 7. ⭐ Options 방 (rooms/Options.lua) 구현 노트

모노리식 게임 + `gotoRoom(name)` 글로벌 호출 패턴이라 require만 main.lua에 추가하면 됨.

```lua
-- main.lua
require 'rooms/Options'

-- ConsoleInputLine.lua
self.commands = {..., 'options'}
elseif command == 'options' then gotoRoom('Options') end
```

**UI**: 5줄 (header / 3개 setting / back). 키보드 + 마우스 듀얼 입력.

**letterbox 좌표 hit-test** (4번 참조).

**Console 메인 메뉴 확장**: 7번째 항목으로 `options` 추가, `bytepath_main_texts` / `selection_widths` 도 7개로, down-arrow wrap `== 7` → `== 8`로.

## 8. release 정책 (사용자 결정)

> "앞으로 내가 확인할 때까지 릴리즈는 하지말도록해."

**적용**:
- .app, .zip, .love 파일 생성 보류
- `gh release create`, `git tag -a v*` 보류
- `git commit`, `git push origin master` 는 가능
- 다른 프로젝트에는 적용 안 됨 (snkrx-clone, sango 등)

**트리거**: 사용자 OK 신호 받기 전까지. (메모리에 영구 저장됨.)

**이유**: 헤드리스 검증 = require + 메인 루프 진입만 확인. 셰이더 컴파일, 디스플레이 모드 전환, 마우스 hit-test, 풀스크린 토글 등은 사용자 GUI 검증이 필수. (특히 love 11.5의 셰이더 silent fail이 우리를 5번 속인 전례가 있다.)

## 9. v0.1.0 ~ v0.2.0 ~ v0.2.1 커밋 구조

```
78cf371 globals: introduce display_mode and window_scale options
6ea5dae core: unified applyDisplayMode() with auto-save and live resize
9859a6e docs: v0.2.0 옵션 화면 (창/풀/데스크탑 + 스케일) 섹션 추가
d789ee9 sound: also patch playRandomSong() for the isStopped() removal
```

총 4개 의미 있는 커밋. release는 보류 상태 (v0.2.0 tag만 로컬에 push 안 됨, 사용자가 GUI 검증 후 OK 사인 받으면 그때 tag + release).

## 10. 핵심 교훈 4가지 (다음 세션이 가져갈 것)

### 교훈 1: 1k+ stars OSS 마이그레이션 = GitHub 이력 우선

가설 5번 빗나간 후 사용자가 "별 많은 프로젝트가 이럴 리가 없다. 이력 확인하고 해결책 찾아봐"로 정정. **시퀀스**:
1. `gh search issues '<원본 LÖVE 버전> 11.5'` — 동일 migration PR 거의 항상 존재
2. fork 목록 조회 (`gh api repos/<owner>/<repo>/forks`) — `pushed_at` 최신 fork의 dev branch clone
3. 그 fork의 diff를 우리 작업물과 비교 → 진짜 원인 발견

**트리거**: 가설 2번 이상 빗나감 + "별 많은데?" 느낌. 즉시 이력 조사로 전환.

### 교훈 2: 셰이더 silent fail = 흰색 saturate

LÖVE 11.5의 셰이더 컴파일 실패는 stderr에 안 뜸. 셰이더 단계의 모든 픽셀을 흰색으로 saturate. 디버깅 신호:
- "흰 화면" 또는 "콘솔만 정상, 게임 화면이 흰색"
- 원본 셰이더에 `extern` 또는 `Image` 시그니처 보임 → 즉시 modern GLSL 변환

### 교훈 3: deprecated API는 `git grep :method` 전수 검색

3곳만 고치고 4번째를 놓치면 hotfix가 필요하다. 변경 후 `git grep -n 'methodName' -- '*.lua'`로 0건 확인.

### 교훈 4: release는 사용자 GUI 검증 OK 전까지 보류

헤드리스 검증 = require + main loop 진입만. 셰이더 / 디스플레이 / 마우스 / 풀스크린은 사용자 검증 필수. 이 정책은 snkrx-clone, sango 등 다른 프로젝트에는 적용 안 됨.

## 11. ⭐ "별 많은데?" 사용자 정정

> "이렇게 별을 많이 받은 프로젝트가 실행도 제대로 안될리 없음. 저장소의 이력을 확인하고 해결책을 찾아봐."

이 한 마디가 v0.1.0 5번 가설 실패 → v0.1.0 완료의 전환점이었다. **다음 세션의 1k+ stars OSS 마이그레이션 작업 시 이 정정을 명심**.
