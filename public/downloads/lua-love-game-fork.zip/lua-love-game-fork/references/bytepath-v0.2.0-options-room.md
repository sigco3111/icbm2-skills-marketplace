# BYTEPATH v0.2.0 — 옵션 화면 + 자동저장 패턴

> sigco3111/bytepath-ex v0.2.0 release (2026-07-22)
> LÖVE 게임 fork에 창모드/풀스크린/데스크탑 + window_scale + monitor 선택 옵션 화면을 추가하고 모든 변경을 자동 저장하는 패턴

## 왜 이 패턴이 필요한가

대부분의 LÖVE 게임은 옵션 화면이 없거나, `conf.lua`의 `t.window.*`만으로 윈도우를 설정합니다. 그러나:

- **창모드/풀스크린/테두리 없는 데스크탑**을 사용자가 게임 안에서 전환하고 싶음
- **창 크기**를 픽셀 단위가 아닌 "스케일(1배율~6배율)"로 다루고 싶음 (픽셀 아트 게임의 480x270 베이스 캔버스 등)
- **멀티 디스플레이**에서 어느 모니터에 띄울지 선택하고 싶음
- 모든 변경은 **즉시 자동 저장**되어 다음 실행에서도 유지되어야 함

LÖVE `conf.lua`는 게임 시작 전 1회만 평가되므로, 게임 안에서 윈도우를 바꾸려면 `love.window.setMode()`를 코드에서 호출하고 그 상태를 save 파일에 보관해야 합니다.

## 핵심 구현

### 1) 상태 변수 (globals.lua)

```lua
-- 영구 옵션 (save/load 대상)
display_mode = 'windowed'   -- 'windowed' | 'fullscreen' | 'desktop'
window_scale = 2            -- 1..6 (창모드에서만 사용)
display = 1                 -- 1..monitor_count
fullscreen = false          -- legacy alias, save 호환용

-- 게터/세터
function clampWindowScale(s)
    if type(s) ~= 'number' then return 2 end
    if s < 1 then return 1 end
    if s > 6 then return 6 end
    return math.floor(s)
end
```

### 2) 통합 applyDisplayMode() (main.lua)

`resize()` / `resizeFullscreen()` 두 함수를 `applyDisplayMode()` 한 함수로 통합:

```lua
function applyDisplayMode()
    local mode = display_mode or 'windowed'
    display = display or 1
    window_scale = clampWindowScale(window_scale or 2)
    sx, sy = window_scale, window_scale

    if mode == 'windowed' then
        fullscreen = false
        local w, h = gw * window_scale, gh * window_scale
        love.window.setMode(w, h, {
            display = display,
            fullscreen = false,
            borderless = false,
            resizable = true,
            minwidth = gw, minheight = gh,
        })
    elseif mode == 'fullscreen' then
        fullscreen = true
        local w, h = love.window.getDesktopDimensions(display)
        love.window.setMode(w, h, {
            display = display,
            fullscreen = true,
            fullscreentype = 'exclusive',
            borderless = false,
        })
        sx, sy = math.floor(w / gw), math.floor(h / gh)
        window_scale = sx
    else -- 'desktop' (borderless fullscreen)
        fullscreen = true
        local w, h = love.window.getDesktopDimensions(display)
        love.window.setMode(w, h, {
            display = display,
            fullscreen = true,
            fullscreentype = 'desktop',
            borderless = true,
        })
        sx, sy = math.floor(w / gw), math.floor(h / gh)
        window_scale = sx
    end

    if save then pcall(save) end  -- ⭐ 자동 저장
end
```

**함정 회피**:
- `pcall(save)` — 첫 실행 시 `save`가 아직 정의 안 된 경우를 안전하게 처리. 두 번째 실행부터는 정상 저장.
- `minwidth = gw, minheight = gh` — 480x270 캔버스 기준 게임은 최소 크기를 한 칸으로 제한.
- `fullscreen` 별칭 유지 — 옛 save 파일과의 호환성. 새 코드는 `display_mode`로 분기.
- `sx, sy`를 `window_scale`과 동기화 — 게임의 캔버스 스케일링 변수와 일치시켜 draw 시 letterbox 계산이 깨지지 않도록.

### 3) love.resize 핸들러 (실시간 창 크기 변경)

사용자가 창 가장자리를 드래그해서 크기를 바꾸면 자동 반영:

```lua
function love.resize(w, h)
    if (display_mode or 'windowed') ~= 'windowed' then return end
    local sx_new = math.max(1, math.floor(w / gw + 0.5))
    local sy_new = math.max(1, math.floor(h / gh + 0.5))
    local s = math.min(sx_new, sy_new)
    if s ~= window_scale then
        window_scale = clampWindowScale(s)
        sx, sy = window_scale, window_scale
        if save then pcall(save) end
    end
end
```

**판별**: `display_mode == 'windowed'` 일 때만 처리. 풀스크린/데스크탑은 무시.
**저장**: 사용자가 드래그로 크기를 바꾸는 즉시 디스크에 기록. 게임 종료 시 별도 저장 없음.

### 4) 첫 실행 시 적용 (love.load 안)

```lua
if first_run_ever then
    display_mode = 'windowed'
    window_scale = 2
    applyDisplayMode()
else applyDisplayMode() end
```

`first_run_ever`일 때 디폴트로 창모드 2배율을 강제하고, 그 외에는 save에서 로드된 값 적용.

### 5) save/load 통합

```lua
-- save()
permanent_save_data.display_mode = display_mode
permanent_save_data.display = display
permanent_save_data.window_scale = window_scale

-- load()
display_mode = save_data.display_mode or (save_data.fullscreen and 'desktop' or 'windowed')
display = save_data.display
window_scale = save_data.window_scale or sx or 2
```

옛 save 파일은 `fullscreen` boolean만 가지고 `display_mode`가 없을 수 있음 → 폴백 처리.

## 옵션 방 (rooms/Options.lua)

전형적인 Room 구조. `gotoRoom('Options')`로 진입:

```lua
Options = Object:extend()

function Options:new()
    self.timer = Tim()
    self.area = Area(self)
    self.font = fonts.Anonymous_8 or fonts.m5x7_16

    self.rows = {
        {kind = 'header',   text = '~ OPTIONS'},
        {kind = 'mode',     key = 'display_mode', label = 'display mode'},
        {kind = 'scale',    key = 'window_scale', label = 'window size'},
        {kind = 'monitor',  key = 'display',      label = 'monitor'},
        {kind = 'action',   action = 'back',       label = '~ back to console'},
    }
    self.index = 2

    input:unbindAll()
    input:bind('left', 'left')
    input:bind('right', 'right')
    input:bind('up', 'up')
    input:bind('down', 'down')
    input:bind('return', 'enter')
    input:bind('escape', 'back')
    input:bind('mouse1', 'click')
end

function Options:update(dt)
    self.timer:update(dt)
    self.area:update(dt)

    if input:pressed('up') then
        self.index = self.index - 1
        if self.index < 2 then self.index = #self.rows end
        playMenuSwitch()
    elseif input:pressed('down') then
        self.index = self.index + 1
        if self.index > #self.rows then self.index = 2 end
        playMenuSwitch()
    elseif input:pressed('left') or input:pressed('right') then
        self:_step(input:pressed('right') and 1 or -1)
    elseif input:pressed('enter') then
        local row = self.rows[self.index]
        if row and row.kind == 'action' and row.action == 'back' then
            playKeystroke()
            gotoRoom('Console')
        end
    end
end

function Options:_step(dir)
    local row = self.rows[self.index]
    if not row or row.kind == 'header' or row.kind == 'action' then return end
    if row.kind == 'mode' then
        local i = 1
        for k, v in ipairs(display_mode_list) do
            if v == display_mode then i = k; break end
        end
        i = ((i - 1 + dir) % #display_mode_list) + 1
        display_mode = display_mode_list[i]
    elseif row.kind == 'scale' and display_mode == 'windowed' then
        window_scale = clampWindowScale(window_scale + dir)
    elseif row.kind == 'monitor' then
        local n = love.window.getDisplayCount()
        if n > 1 then display = ((display - 1 + dir) % n) + 1 end
    end
    applyDisplayMode()  -- ⭐ 즉시 setMode + save
    playMenuSwitch()
end

function Options:draw()
    love.graphics.setCanvas()
    love.graphics.setShader()
    love.graphics.setBlendMode('alpha')
    love.graphics.setColor(0, 0, 0, 1)
    love.graphics.rectangle('fill', 0, 0, love.graphics.getWidth(), love.graphics.getHeight())

    local font = self.font
    love.graphics.setFont(font)
    love.graphics.setColor(1, 1, 1, 1)
    love.graphics.print('OPTIONS', gw/2 - 28, 8)

    local y = 32
    for i, row in ipairs(self.rows) do
        if row.kind == 'header' then
            love.graphics.setColor(default_color[1]/255, default_color[2]/255, default_color[3]/255, 1)
            love.graphics.print(row.text, 8, y)
        elseif row.kind == 'action' then
            local r, g, b = default_color[1]/255, default_color[2]/255, default_color[3]/255
            if i == self.index then
                love.graphics.setColor(0, 0, 0, 1)
                love.graphics.rectangle('fill', 8, y - 1, gw - 16, 9)
                love.graphics.setColor(r, g, b, 1)
            else
                love.graphics.setColor(r, g, b, 0.6)
            end
            love.graphics.print(row.label, 8, y)
        else
            local value
            if row.key == 'display_mode' then
                if display_mode == 'windowed' then value = 'windowed'
                elseif display_mode == 'fullscreen' then value = 'fullscreen (exclusive)'
                else value = 'desktop (borderless)' end
            elseif row.key == 'window_scale' then
                if display_mode == 'windowed' then
                    value = window_scale .. 'x  (' .. gw*window_scale .. 'x' .. gh*window_scale .. ')'
                else
                    value = '- (windowed mode only)'
                end
            elseif row.key == 'display' then
                value = 'monitor ' .. display .. ' / ' .. love.window.getDisplayCount()
            end

            local r, g, b = default_color[1]/255, default_color[2]/255, default_color[3]/255
            if i == self.index then
                love.graphics.setColor(0, 0, 0, 1)
                love.graphics.rectangle('fill', 8, y - 1, gw - 16, 9)
                love.graphics.setColor(r, g, b, 1)
            else
                love.graphics.setColor(r, g, b, 0.6)
            end
            love.graphics.print(row.label .. ':', 8, y)
            love.graphics.print(value, 96, y)
        end
        y = y + 12
    end

    love.graphics.setColor(0.5, 0.5, 0.5, 1)
    love.graphics.print('up/down = select   left/right = change   enter/click = back', 8, gh - 12)
end
```

**핵심 디테일**:
- `input:unbindAll()` 후 옵션 화면에서만 쓸 키만 다시 bind — 다른 Room의 키가 새지 않도록
- `_step()`을 `update()` (키보드) 와 mouse click (드래그) 양쪽에서 공통 호출
- `setCanvas()` + `setShader()` 명시 + `setBlendMode('alpha')` — LÖVE 11.5 호환 (M-0/M-6 함정 회피)
- 선택된 행은 검은 배경 + 흰 글씨, 비선택은 흐린 글씨
- `display_mode == 'windowed'`가 아니면 `window_scale`은 `- (windowed mode only)` 표시

## 콘솔 통합

`ConsoleInputLine.commands`에 `options` 추가, `enter()` 핸들러에 `gotoRoom('Options')` 디스패치, `Console:bytepathMain` 메뉴에 7번째 항목으로 추가:

```lua
-- ConsoleInputLine.lua
self.commands = {'resolution', ..., 'credits', 'options'}

elseif command == 'options' then
    gotoRoom('Options')
```

```lua
-- Console.lua
self.bytepath_main_texts = {'escape', 'start', 'help', 'classes', 'device', 'passives', 'options'}
-- 메뉴 한 줄 추가
self:addLine(delay + 0.42, '~ type @options# to view display / window options')
-- 7번째 항목 순환 처리
if self.bytepath_main_selection_index == 8 then self.bytepath_main_selection_index = 1 end
```

## main.lua에 등록

```lua
require 'rooms/Options'  -- ⭐ gotoRoom('Options')가 작동하려면 전역 Options이 정의돼야 함
```

LÖVE에서 `require 'rooms/Console'`, `require 'rooms/Stage'` 는 어디서도 안 하지만, `Options`처럼 **신규로 추가한 Room은 명시적으로 require해야 전역이 등록됨**.

## 흔한 함정

### 1. `display_mode` 필드를 옛 save에 추가 안 함

`load()`에서 `display_mode = save_data.display_mode or (save_data.fullscreen and 'desktop' or 'windowed')` 폴백. 옛 `fullscreen` boolean만 있던 save 파일도 안전하게 로드.

### 2. applyDisplayMode가 love.load 중 너무 일찍 호출됨

`first_run_ever` 체크 직후 호출하면 `save` 함수가 아직 정의 안 됐을 수 있음 → `if save then pcall(save) end` 가드. 두 번째 실행부터는 정상.

### 3. 모니터 인덱스 범위 초과

`display = 1`로 저장했는데 두 번째 실행 때 모니터 1개를 뽑아버린 경우 (외부 모니터 분리 등). `if n > 1 then display = ((display - 1 + dir) % n) + 1 end`로 단일 모니터면 변경 안 함. 범위 안전: `(display - 1) % n + 1`.

### 4. window_scale이 풀스크린에서 의미 없음

풀스크린은 `love.window.getDesktopDimensions()`로 강제 설정되므로 `window_scale`이 사용자 의도와 안 맞을 수 있음. 풀스크린 진입 시 `sx, sy = math.floor(w / gw), math.floor(h / gh); window_scale = sx`로 자동 동기화. 사용자가 옵션 화면에서 `window_scale`을 보려고 하면 `(windowed mode only)` 표시.

### 5. love.resize가 풀스크린 전환 직후 잘못된 값으로 호출

`setMode()` 직후 macOS가 `love.resize`를 이전 윈도우 크기로 한 번 더 호출할 수 있음. 이 경우 `display_mode ~= 'windowed'`라 early return. 안전.

### 6. ⭐ mouse click hit-test 좌표가 letterbox와 안 맞음

마우스 좌표 `love.mouse.getPosition()`은 윈도우 좌표인데 게임 캔버스는 480x270 letterbox로 그려짐. 클릭 hit-test는 반드시 letterbox 오프셋/스케일로 변환:

```lua
local ox, oy, s = getLetterboxOffset()  -- (window_w - gw*s)/2, (window_h - gh*s)/2, s
local gx, gy = (mx - ox) / s, (my - oy) / s
-- 이제 gx, gy가 480x270 캔버스 좌표
```

이걸 빠뜨리면 풀스크린/letterbox 상태에서 버튼이 어긋난 위치에 클릭됨.

## 다른 LÖVE 게임에 적용할 때

이 패턴은 거의 모든 LÖVE 게임에 그대로 적용 가능합니다:

1. `globals.lua`에 `display_mode` / `window_scale` / `display` 추가
2. `applyDisplayMode()` (또는 `applyWindowMode()`) 함수 정의
3. `save()` / `load()`에 옵션 추가
4. `love.resize` 핸들러 추가
5. `applyDisplayMode()` 끝에 `pcall(save)`
6. `Options.lua` Room 생성 + `input:unbindAll()` 후 옵션용 키만 rebind
7. 기존 진입점 (보통 콘솔/메인 메뉴) 에서 `gotoRoom('Options')` 연결
8. `require 'rooms/Options'` 또는 다른 require 경로로 전역 등록

**유일한 차이점**: `gw` / `gh` 값이 게임마다 다름 (스네이크: 256x224, BYTEPATH: 480x270, SNKRX: 320x180, ...) — 이 값에 맞춰 `gw * window_scale` 계산.

## 한계 / 향후 개선

- **다중 모니터 개별 디스플레이 인덱스**: macOS는 `love.window.getDisplayCount()`만 제공하고 모니터별 해상도/이름은 안 줌. 모니터 식별 정보가 필요하면 외부 도구 (displayplacer 등) 필요.
- **colorblind mode / vsync / max_fps**: 현재 BYTEPATH fork에는 미포함. 동일 패턴으로 추가 가능 (전역 bool/int 변수 + `applyDisplayMode`와 같은 setter).
- **첫 실행 강제 dialog**: `first_run_ever`일 때 옵션 화면을 자동 띄워 사용자에게 인지시킴. 현재는 그냥 디폴트 (창모드 2x) 적용. UX 개선 여지.
