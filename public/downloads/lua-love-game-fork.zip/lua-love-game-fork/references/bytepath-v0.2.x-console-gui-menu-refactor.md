# BYTEPATH Console GUI 메뉴 리팩토링 (2026-07-22, v0.2.x)

사용자 보고 흐름 (한 함수에 M-13, M-14, M-15, M-16, M-17 5대 함정이 한꺼번에 폭발):

## 1단계: M-13 (누적 line_y cursor)

사용자: "커서가 한 칸씩 밀려서 출력". 기존 BYTEPATH Console:bytepathMain은 `self.bytepath_main_y = self.line_y + 13*12` 식으로 line_y 누적을 사용해 cursor 위치 계산. 20초 후 bytepathMain 진입 시 line_y≈264 → cursor 화면 밖 (270).

가설 1 (텍스트 매칭): `self.lines` 안에서 `'type @' .. target` 패턴으로 메뉴 라인을 찾아 cursor 위치 추정 → 실패 (찾긴 했지만 다른 행 매칭).

## 2단계: M-15 (STALKER-X Camera 메소드 없음)

가설 2 (camera:getCameraCoords): humps 라서 있다고 가정했는데, **STALKER-X/Camera는 getCameraCoords 메서드를 정의하지 않음** → nil 반환. `if cy >= -16` 가드가 nil-cy에서 silent fail → cursor 안 그려짐.

## 3단계: M-16 (addLine 타이밍 함정)

가설 3 (메뉴 line 객체 직접 캡처): `self.bytepath_main_menu_lines[spec.key] = self.lines[#self.lines]` 호출 시 addLine의 timer.after 콜백이 아직 발동 안 됨 → **nil 저장**. bytepathMain 진입 후 0.38초 지나서 bytepath_main_active=true 됐을 때 menu_lines 모두 nil → cursor 안 그려짐.

수정:
- `addLineSync` 분리 함수: 즉시 `table.insert(self.lines, line); return line` 가능
- 또는 `_captureNextLine(key)`: 1ms 후 timer 콜백에서 `#self.lines` 증가 시 마지막 라인 캡처

→ 둘 다 fragile 한 면이 있어 `addLineSync`로 통일하려 했으나, 기존 addLine 호출이 timer-기반 cascade effect (line_y 누적)에 의존 → addLineSync으로 바꾸면 timing 어긋남.

## 4단계: L4 — 사용자가 멈춤

사용자: "여전히 안나오는 데? 일단 커서부분은 수정전으로 코드를 돌려놓고, 원인을 다시 분석해보자."

패치-적 패치 누적의 끝. **GUI 메뉴를 전면 재작성하는 게 옳다** 결론.

## 5단계: M-17 — GUI 메뉴로 재작성

`Console.main_menu` 상태 + `_showMainMenu(opts)` / `_runMainMenu(i)` / `_drawMainMenu()` / `_hideMainMenu()` 헬퍼로 분리.

```lua
self.main_menu = {
    x = opts.x, y = opts.y,
    w = opts.w, h = opts.h,
    spacing = opts.spacing or 4,
    titles = opts.titles,
    selection_index = 1,
    visible = true,
}
self.main_menu_texts = {t.key for each}
self.main_menu_actions = {
    terminal = function() EscapeModule(...) end,
    start    = function() gotoRoom('Stage') end,
    -- ...
}

-- _drawMainMenu()는 drawGameCanvas() 호출 후 screen 좌표에 그려서
-- 셰이더 누적 효과 우회 (M-14 해결)
```

## 6단계: GUI menu 모던 디자인

- 좌측 3px accent bar (선택 시)
- 인덱스 배지 `01 ~ 08`
- 라벨 + 설명 + hotkey `[N]` + 우측 chevron `›`
- 컬럼 폭 분리 (index 16px | label 80px | desc 가변 | hotkey 22px)

너무 좁은 메뉴 폭 (168px) → `gw - 96 = 384px`로 확장. 라벨/설명/hotkey가 서로 안 침범하도록 컬럼 분리 + 너무 길면 truncate + `..`.

## 7단계: M-17 — 마우스 → 키보드 전용으로 fallback

사용자: "마우스 동기화는 여전히 안됨. 그냥 마우스는 빼자 키보드로만 선택되도록 수정해줘."

GUI 메뉴 **키보드만**:
- ↑/↓ — 선택 이동 (wrap)
- Enter — 실행
- 1~N — hotkey 직접 실행

## 시간순 교훈 — multi-failure 패턴

5대 함정이 한 룸에서 동시에 발현:
- M-13 (누적 line_y) — 좌표 계산 자체
- M-14 (셰이더 누적) — UI 그릴 때 사각형 분산
- M-15 (Camera API 차이) — 좌표 변환 실패
- M-16 (timer-async) — 라인 객체 캡처
- M-17 (셔더+letterbox 환경) — 마우스 좌표 불안정

이 패턴이 재현되면 **GUI 메뉴로 전면 재작성 + 키보드만**이 가장 깨끗한 답. 패치-적 누적은 검증 비용이 계속 증가.

## 최종 설계 — `Console:_showMainMenu`

```lua
function Console:_showMainMenu(opts)
    self.main_menu = { x, y, w, h, spacing, titles, selection_index=1, visible=true }
    self.main_menu_texts = {key list}
    self.main_menu_actions = {key → action}
end

function Console:_runMainMenu(i)
    local key = m.titles[i].key
    local act = self.main_menu_actions[key]
    self:rgbShift()
    self:_hideMainMenu()  -- 액션 시작 전 메뉴 닫기 (e.g. Options 진입 시 1프레임 잔상 방지)
    if act then act() end
end

function Console:_drawMainMenu()
    -- drawGameCanvas(final_canvas) 호출 이후에 그리므로 셰이더 우회
    -- viewport 좌표 (gw × gh) 직접 사용
    local cell_fill = is_selected → skill_point_color alpha .30
                   | is_hovered  → 회색
                   | idle        → 어두운 회색
    -- 좌측 accent bar, 세로 구분선, 인덱스 배지, 라벨, 설명, hotkey, chevron
end

function Console:update()
    -- 키보드만
    if self.main_menu then
        if input:pressed('up') then m.selection_index = wrap(m.selection_index - 1) end
        if input:pressed('down') then m.selection_index = wrap(m.selection_index + 1) end
        if input:pressed('return') then self:_runMainMenu(m.selection_index) end
        if input:pressed('1') then self:_runMainMenu(1) end  -- ... 8까지
    end
end
```

## 메모리/스킬에 남긴 패턴

- **lua-love-game-fork §M-13, M-14, M-15, M-16, M-17** — 5대 함정 모두 본 사례에서 정립
- **memory: bytepath-ex GUI 메뉴 + 워크어라운드 (2026-07-22)** — 키보드만 선호 + 워크어라운드 캡슐화
- **memory: 디버깅 선호 (2026-07-22)** — "수정전으로 코드를 돌려놓고, 원인을 다시 분석해보자" 사용자 교정
