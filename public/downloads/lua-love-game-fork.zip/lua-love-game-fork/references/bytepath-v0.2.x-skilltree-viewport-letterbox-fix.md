# BYTEPATH-ex SkillTree viewport letterbox 누락 픽스 (v0.15)

작성: 2026-07-22 — Passives(SkillTree) 룸에서 자동 핏 적용 후에도 "화면의 3/4이 검정"이었던 8단계 디버깅 세션.

## 배경

이미 적용된 픽스:

- v0.12 — M-7.6 셰이더 우회 + 0..1 색상 정규화
- v0.12 — M-12 자동 핏 (트리의 P5~P95 / P10~P90 / P25~P75 percentile로 camera.scale)
- v0.12 — viewport letterbox_off + scale 2.0 고정 + median lookAt
- v0.13 — P10~P90 + 2배 zoomed + setMode로 window_scale 동적 조정
- v0.14 — fit_scale_x/y * 2 + median lookAt + max(1.0, 2.5)

→ **모두 적용했지만 사용자가 "화면 3/4이 검정"을 5번 반복해서 보고**. 진짜 원인은 따로 있었음.

## 진짜 진단 — 순차 추적

1. `SkillTree:draw`는 `camera:attach(0, 0, gw, gh)` + 직접 그리기로 viewport (480×270)에 그림.
2. `main.lua:love.draw()` 끝에서 `drawGameCanvas(canvas)` 호출은 **콘솔/스테이지 룸만** 함. SkillTree는 호출 안 함.
3. 그러면 SkillTree의 viewport가 **윈도우 (0,0)부터 그대로 그려짐** → 윈도우가 viewport보다 크면 우측/하단이 검정.
4. Console/Stage는 `drawGameCanvas(self.final_canvas)`로 viewport offscreen 캔버스를 letterbox으로 윈도우에 fit. SkillTree는 그것이 없음.

## 수정 패턴 — render_canvas + drawGameCanvas

```lua
function SkillTree:new()
    -- ... 기존 self.main_canvas, final_canvas, temp_canvas, glitch_canvas, rgb_canvas ...
    -- ⭐ viewport offscreen — 매 frame viewport 좌표로 다 그린 후 letterbox으로 출력
    self.render_canvas = love.graphics.newCanvas(gw, gh)
end

function SkillTree:draw()
    love.graphics.setFont(self.font)

    -- 1. viewport offscreen 캔버스에 바인딩
    love.graphics.setCanvas(self.render_canvas)
    love.graphics.clear(0, 0, 0, 1)

    -- 2. camera:attach + 직접 그리기 (기존 셰이더 우회 코드 그대로)
    camera:attach(0, 0, gw, gh)
    -- ... grid + nodes + lines + HUD ...
    camera:detach()

    -- 3. ⭐ 마지막에 letterbox으로 윈도우에 fit
    love.graphics.setCanvas()
    drawGameCanvas(self.render_canvas)
end
```

## 사용자 보고 패턴 (신호)

다음 사용자 보고가 나오면 즉시 **M-7.7 (viewport letterbox 누락)** 검사:

- "표시한 표를 화면에 채워야지 표 안의 내용만 확대하면 어떻게함!"
- "화면의 3/4이 검은색이잖아. 화면에 맞게 처리해줘."
- "비율에 맞게 나오기만 하면 되겠어"
- "크기도 정렬도 안되어 있음"
- "변화없음. 순차적으로 생각해보고 다시 처리해봐"

## 이전 분기가 다 실패한 이유

| 시도 | 결과 | 실패 이유 |
|------|------|-----------|
| `camera:lookAt(0, 0)` + `camera.scale = 2.0` | 트리 일부만 보임 | viewport는 그대로 480×270, 윈도우 일부만 차지 |
| P10~P90 percentile 핏 | 트리 일부분만 fit | viewport 자체 작아서 자동 핏은 부수적 효과 |
| fit_scale * 2 + max(1.0, 2.5) 클램프 | 화면 가운데 작은 영역 | viewport가 윈도우 일부만 차지 |
| `applyDisplayMode` + `setMode` 호출 | 화면 비율 변경 | viewport가 (0,0)에 그려져서 여백 안 줄어듦 |
| viewport (480×270)만 수정 | 사용자가 개선 못 느낌 | letterbox 자체가 없음 |

viewport의 위치/크기 = 윈도우에서 viewport가 차지하는 영역 자체를 **letterbox transform**으로 키워야 함. `setMode`나 `camera.scale`은 viewport 내부를 조정하는 거지 viewport 자체의 화면 점유를 바꾸지 않음.

## 검증 명령

```bash
# 룸별 drawGameCanvas 호출 여부
grep "drawGameCanvas" rooms/*.lua
# → 빠진 룸이 viewport letterbox 누락 가능성
```

## SKILL.md 본문 위치

이 reference 파일은 M-7.6 셰이더 우회 섹션과 짝을 이루는 **M-7.7 viewport letterbox** 함정의 session-specific detail입니다. SKILL.md 본문의 M-7.7 단락에서 본 recipe를 한 곳에 묶어 인용.

## 다른 룸/게임에 적용할 때

BYTEPATH 룸 (`rooms/*.lua`)에 `drawGameCanvas` 호출이 있고 셰이더 우회 룸만 빠져 있는지 매트릭스 검사:

```bash
for f in rooms/*.lua; do
  room=$(basename "$f" .lua)
  shader=$(grep -l "setShader(shaders\." "$f" >/dev/null && echo "shader")
  drawgame=$(grep -l "drawGameCanvas" "$f" >/dev/null && echo "drawgame")
  if [ -n "$shader" ] && [ -z "$drawgame" ]; then
    echo "⚠ $room: shader 사용하지만 drawGameCanvas 호출 없음 → M-7.7 의심"
  fi
done
```
