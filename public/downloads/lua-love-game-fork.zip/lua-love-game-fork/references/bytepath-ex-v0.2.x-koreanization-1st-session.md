# bytepath-ex 한글화 1차 풀스택 세션 — 시간순 노트

> 일자: 2026-07-22. 작업 디렉터리: `/Users/mac/work/bytepath-ex`. 매핑표: `docs/koreanization-1st-mapping.md`.

## 세션 흐름 요약

| 단계 | 작업 | 산출물 |
|---|---|---|
| 1-1 | 폰트 + lang 모듈 + globals.lua T() | `lang/ko.lua`, `lang/en.lua`, `globals.lua` (T 함수), `main.lua` (loadFonts 확장) |
| 1-3 | Options 룸 language 토글 row | `rooms/Options.lua` (6번 행 추가 + update/_step/draw 처리) |
| 1-4 | Console 메인 메뉴 한글화 | `rooms/Console.lua` bytepathMain/Main2 titles |
| 1-5 | 모듈 5개 한글화 | AboutModule, HelpModule, ClearModule (selection_widths 재계산 포함), DeviceModule 일부까지 진행 |
| 1-6~1-8 | UI 헤더 + 부팅 + 검증 | **미완료** — 다음 세션에서 계속 |

세션 마지막에 tool call limit 도달로 종료됨. 모듈 9개, UI 헤더, 부팅 시퀀스, love 부팅 검증이 잔여.

## 핵심 의사결정 (다음 세션에 전달)

### 1. addLine swap table = 양쪽 영문 유지 (1차 정책 확정)

매핑표의 `intro_*` + swap 섹션 (swap from을 한글로, swap to도 한글로)이 있지만, **1차에선 addLine의 swap table 인자 자체를 영문 그대로 두는 게 안전**. 이유:

- `ConsoleLine:replace`가 string match/replace로 swap 동작 → swap from이 영문 라인에서 매칭되어야 swap to로 replace됨
- swap from을 한글로 바꾸면 영문 라인에서 매칭 실패 → swap 동작 안 됨
- swap to를 한글로 바꾸면 swap 적용 후 화면엔 한글이 보이지만, 외부 코드가 status marker (`' <OK> '`, `'@FAIL#'`)를 매칭하는 경우 깨짐

**dict 등록 패턴**:
```lua
-- ko.lua: swap key 값도 영문으로
swap_ok = ' <OK> ',
swap_allocated = 'allocated',
-- ...
```

**2차 확장 가능성**: swap from을 한글화하면서 매칭도 한글 패턴으로 같이 바꾸는 패턴. 별도 session에서 신중히.

### 2. 콘솔 명령어 입력 = 영문 1차 유지 (확정)

`ConsoleInputLine`의 `self.commands = {'resolution', 'sound', ...}` 리스트와 프롬프트 `[;root,]arch~ `은 영문. 매핑표 7섹션이 영문 유지를 명시하므로 변경 안 함. AboutModule의 명령어폭 측정 (`getWidth('escape')`)도 그대로.

### 3. selection_widths 재계산 패턴 (ClearModule에서 검증됨)

```lua
-- BEFORE
self.selection_widths = {
    self.console.font:getWidth('clear CLASS data'),
    ...
}
-- AFTER
self.selection_widths = {
    self.console.font:getWidth(T('clear_class')),
    ...
}
```

**원칙**: 셀 안의 highlight 박스 폭은 측정 시점에 같은 폰트 / 같은 dict 사용해서 정확히 측정. 영문/한글 혼용 시 `language` 분기 후 따로 측정:
```lua
local function width(text)
    return (language == 'ko' and fonts.kr_8 or self.console.font):getWidth(text)
end
```

### 4. 한국어 폰트 fallback 체인 (확정)

`main.lua` `loadFonts` 끝에 추가:
```lua
local kr_candidates = {'NanumGothic', 'AppleSDGothicNeo', 'AppleGothic'}
-- Apple SD Gothic Neo는 55MB로 .love 사이즈 부담. Nanum Gothic (12.8MB)이 1순위.
-- AppleGothic은 .ttf 직접 파일이 /Library/Fonts에 없을 수 있어 주의.
-- 실제로는 /Library/Fonts에 AppleGothic.ttf가 없는 macOS가 있어 fallback 실패 가능.
```

**macOS Sonoma에서 확인된 경로**:
- NanumGothic.ttc: `/System/Library/AssetsV2/com_apple_MobileAsset_Font8/7a0b5c0f.../AssetData/NanumGothic.ttc`
- AppleSDGothicNeo.ttc: `/System/Library/Fonts/AppleSDGothicNeo.ttc`

`fc-match -f "%{file}\n" "Nanum Gothic"`으로 사용자 환경 경로 추출 가능.

## 발견한 함정 (SKILL.md v0.23에 반영됨)

1. **`globals.lua` 모듈 선두에 `language = 'ko'` 디폴트 + ko/en require** — `setPermanentGlobals`가 이들을 참조할 수 있어 순서 보장 필수. 안 그러면 `T()` 호출이 `nil` 또는 `attempt to index a nil value`로 죽음.

2. **T() 함수의 `ko_lookup → en_lookup → key itself` 3단 fallback** — 매핑표에 없는 키는 그대로 영문 dict에 등록된 키 값 반환, 그것도 없으면 키 자체를 화면에. 이게 사용자 검증 단계에서 "이건 왜 안 바뀌었지?" 추적 도구가 됨.

3. **ClearModule의 클래스/노드 라인 한글화 시 gsub 패턴** — `T('clear_removed_class')`이 `'클래스 @X# 제거됨'`인데, 원본은 `[   <OK>   ] removed class @<classname>#` 형식이라서:
   ```lua
   '[   <OK>   ] ' .. T('clear_removed_class'):gsub('@X#', '@' .. class .. '#')
   -- 결과: '[   <OK>   ] 클래스 @Gunner# 제거됨'
   ```
   `@X#` 마커는 그대로, 안의 `<class>` 만 교체. 1차 정책상 OK.

4. **매핑표 자체의 모순** — 매핑표 swap 섹션은 2차 보류로 적혀있으면서도 한글로 swap을 보여줌. 향후 매핑표 작성 시 swap 섹션은 명시적으로 2차 항목으로 분리하거나 "1차 영문 유지" 주석 추가 필요.

## 잔여 작업 (다음 세션 진입점)

다음 세션에서 즉시 이어서 진행할 작업:

1. **모듈 9개 더** (DeviceModule 일부 진행 후 잔여):
   - DeviceModule — 9개 디바이스 이름 + stat 풀. 매핑표에 `Average All Stats` → `모든 스탯 평균` 등. `LOCKED - XSP` → `잠김 - X SP` (공백 차이 주의). selection_widths는 draw 측정에 영향 없음 (별도 rect draw).
   - DisplayModule, EffectsModule, ResolutionModule, SoundModule — hint만 한글화 (짧음, 단순 패치).
   - ShutdownModule — wait/goodbye 두 줄 (3줄 정도).
   - EscapeModule — 엔딩 텍스트 8개 + 키 8개 (find_keys 라인). **Arch Linux 로그 일부**가 매핑표 3-5에 빠짐 — EscapeModule.lua 내용 직접 보고 추가 필요.
   - CreditsModule — 5개 라벨만 (이름은 영문 유지).
   - FullscreenModule — hint + state 한 줄.

2. **UI 헤더** (rooms/Paused.lua, ScoreScreen.lua, Stage.lua HUD, SkillTree.lua 헤더, objects/Tutorial.lua).

3. **Console 부팅 시퀀스** (`Console:bytepathIntro`) — 60+ addLine. T('intro_*')로 교체 + swap table은 영문 유지.

4. **`love .` 헤드리스 부팅 검증 + GUI 메뉴 8셀 확인** — stderr 비어있는지, 메뉴 라벨 한글 표시되는지. 부팅 직후 `quit()` 1초 후 종료하는 health check 스크립트 패턴이 필요할 수 있음.

5. **셀렉션 highlight 박스 셀 안 fit 검증** — ClearModule 외에 HelpModule, AboutModule의 highlight 박스도 한글화 후 셀 안에 들어가는지.

6. **명령어 입력 검증** — `love .` 부팅 → 콘솔에서 `escape` 입력 → addLine `'Your objective is to escape this terminal.'` (T('about_body_3') = 한글) 표시되는지. 영문 명령어 → 한글 결과 시연.

## 검증 헬퍼 (다음 세션에서 활용)

```bash
# 10초 후 강제 종료하는 headless 검증
(cd /Users/mac/work/bytepath-ex && timeout 10 love . 2>&1 | head -100)

# stderr 비어있으면 정상 (단, 셰이더 silent fail은 stderr로 안 잡힘 — love.graphics 오류만)
# 1초 후 love.event.quit() 호출하는 health check love 프로젝트 구조는 별도 작업 필요

# fc-match로 폰트 경로 추출
fc-match -f "%{file}\n" "Nanum Gothic"
```

## 변경된 파일 (이 세션에서)

- 신규: `lang/ko.lua`, `lang/en.lua`, `resources/fonts/NanumGothic.ttc` (12.8MB), `resources/fonts/AppleSDGothicNeo.ttc` (55MB)
- 수정: `globals.lua` (T() + language), `main.lua` (loadFonts kr_8), `rooms/Options.lua` (language toggle + 라벨 T화), `rooms/Console.lua` (bytepathMain/Main2 한글 메뉴), `objects/modules/AboutModule.lua`, `objects/modules/HelpModule.lua`, `objects/modules/ClearModule.lua`

## 다음 세션 시작 지점 (사용자에게 보고용)

"bytepath-ex 한글화 1차 풀스택 작업 재개. globals.lua / lang/{ko,en}.lua / main.lua loadFonts / Options 룸 language 토글 / Console 메인 메뉴 / AboutModule / HelpModule / ClearModule 까지 완료. 모듈 9개 + UI 헤더 + 부팅 시퀀스 + love 부팅 검증이 잔여. 매핑표의 swap 섹션은 1차 정책상 영문 유지 (ConsoleLine string match/replace 보존). 다음: DeviceModule → 나머지 모듈 → UI 헤더 → 부팅 시퀀스 → headless 검증."
