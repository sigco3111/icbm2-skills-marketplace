# BYTEPATH Console Menu Cursor Drift — M-13

## 증상

사용자 보고 (2026-07-22, bytepath-ex v0.2.x):
- 콘솔 첫 진입 시 메뉴(`escape`, `start`, `help`, ...)가 `~ type @escape# to escape` 부터 그려지지만 **cursor가 한 칸씩 밀려**서 실제 선택 항목과 다르게 보임
- 화면 이미지: `Welcome to BYTEPATH v1.0` → `SP: 5` → ... → 첫 메뉴 항목이 화면 중간쯤부터 잘려 보임 → cursor가 그 항목 위에 있어야 하는데 안 보임 → 결국 사용자가 `start` 위치를 클릭한 것 같은데 실제로는 `escape`가 실행됨 (또는 그 반대)
- *최초 실행시*에만 가끔 보임 (재현 어렵지만, 첫 진입 후 bytepathMain2 (Stage → 콘솔 복귀)에서도 동일 패턴)

## 진짜 원인

`Console.lua`의 `bytepathMain` / `bytepathMain2`가 `self.bytepath_main_y`를 `self.line_y` 기반으로 계산:

```lua
-- bytepathMain (line 285-286, 원본)
if loop > 0 then self.bytepath_main_y = self.line_y + 13*12
else self.bytepath_main_y = self.line_y + 13*12 - 12 end

-- bytepathMain2 (line 333, 원본)
self.bytepath_main_y = self.line_y + 9*12 - 12
```

`self.line_y`는 `addLine`마다 12씩 누적. 첫 진입 시 `bytepathMain`은 `bytepathIntro`의 7.5초 + 20초 delay 후 발동. 그 시점에 `addLine`이 ~22줄 + 빈 줄 + input_line까지 실행돼서 `line_y ≈ 264`. 거기에 `+13*12 = +156`을 더하면 **`bytepath_main_y ≈ 420`**. 화면 height = **270**. 

**`Console:draw` line 141**:
```lua
love.graphics.rectangle('fill', 8 + x_offset - 2,
    self.bytepath_main_y + self.bytepath_main_selection_index*12 - 7, ...)
```
⇒ cursor 위치 = `420 + 12 - 7 = 425` (index=1) ~ `420 + 96 - 7 = 509` (index=8). **모두 화면 밖.**

그래서 사용자에게는 cursor가 안 보이거나, 화면 상단의 다른 텍스트 줄 위에 그려져서 "한 칸 위로 밀려 있다" 또는 "엉뚱한 위치에 있다"로 보이는 것. `bytepath_main_selection_index` 자체는 **정상**이라 return 누르면 정확한 명령이 실행됨 (시각 cursor와 실제 selection 불일치 — 사용자가 본 "메뉴 선택 결과가 다른 항목 실행").

## 결론

`self.bytepath_main_y`를 **누적 line_y 기준으로 잡으면 안 됨**. 메뉴 항목 텍스트는 `self.lines`의 ConsoleLine의 `line.y` (world y) 좌표에 이미 그려져 있음. cursor는 **그 실제 menu line.y**와 같은 위치에 그려야 함.

## 픽스 (rooms/Console.lua, Console:draw)

`bytepath_main_y` 누적 버리기 + **메뉴 항목의 실제 world-y를 self.lines에서 찾아서 거기에 cursor 그리기**:

1. `camera:detach()` 후 cursor 그림 (camera attach 안에서 그리지 말고)
2. `self.bytepath_main_texts[idx]` (e.g. `'escape'`)를 `self.lines`를 순회하며 찾음 — 매칭 조건: `line.text:find(target, 1, true) and line.text:find('type @' .. target, 1, true)` (`~ type @escape# to escape` 줄만 매칭되도록)
3. 찾은 `line.y` (world coord)를 `camera:getCameraCoords(0, found_y, 0, 0, gw, gh)`로 screen 픽셀 좌표 변환
4. 거기에 cursor 사각형 그림 (`x = 8 + x_offset - 2 + cx, y = cy - 7`)

```lua
camera:detach()

if self.bytepath_main_active then
    local idx = self.bytepath_main_selection_index
    local target = self.bytepath_main_texts[idx]
    local found_y = nil
    for _, line in ipairs(self.lines) do
        if line.text
           and line.text:find(target, 1, true)
           and line.text:find('type @' .. target, 1, true) then
            found_y = line.y
            break
        end
    end
    if found_y ~= nil then
        local width = self.bytepath_main_selection_widths[idx]
        local r, g, b = unpack(hp_color)
        local x_offset = self.font:getWidth('~ type ')
        local cx, cy = camera:getCameraCoords(0, found_y, 0, 0, gw, gh)
        love.graphics.setColor(r, g, b, 128/255)
        love.graphics.rectangle('fill', 8 + x_offset - 2 + cx, cy - 7, width + 4, self.font:getHeight())
        love.graphics.setColor(1, 1, 1, 1)
    end
end
```

## 부수효과
- cursor가 화면 밖이면 자동으로 안 그려짐 (found_y = nil) → 대신 스크롤해서 메뉴가 화면에 들어온 후 표시
- viewport scroll 되어도 cursor가 메뉴 항목 따라 자동으로 이동 (`getCameraCoords`가 카메라 view 따라감)
- bytepathMain2도 동일 코드 (self.bytepath_main_texts/index 동일 구조) → 한 곳 패치로 둘 다 픽스

## 일반화 교훈 (M-13: 누적 라인 y 좌표 함정)

**룸이 콘솔처럼 line_y를 누적하면서 그리는 구조일 때, 메뉴/선택 박스 같은 요소를 line_y 누적값으로 그리지 말 것.** 반드시 **실제 그려진 텍스트/객체의 world y를 다시 조회**해서 거기 그릴 것.

증상 패턴:
- 룸 진입 후 시간이 지날수록 (addLine이 누적될수록) 메뉴 박스가 화면 밖으로 밀려남
- text_y가 화면 viewport(270) 너머로 가도 box는 계속 더 아래에 그려짐 (no clamping)
- 사용자 cursor가 잘못된 위치에 보이거나 안 보임

판별 신호: 룸에 `addLine` + line_y 누적 + 메뉴/박스 draw가 동시에 있으면 무조건 의심.
