# BYTEPATH v0.0.1 사례 연구 — 시간순 작업 메모

> sigco3111/BYTEPATH (a327ex/BYTEPATH fork) — 2026-07-22
> BYTEPATH (a327ex, MIT, ~7.4K LOC) 한국어화 fork v0.0.1 인프라 구축 + 분석
> → 다음 세션에서 "모노리식 LÖVE 게임 한글화 / luac 5.5 검증 함정 / Steamworks FFI" 작업 시 참고.

## 환경

| 항목 | 값 |
|---|---|
| M4 Mac mini 16GB | macOS 26.5.2 |
| LÖVE | 11.5 (brew cask, LuaJIT 2.1) |
| Lua (luac) | brew = 5.5.0 — **검증용으로 사용 불가** |
| 원본 | https://github.com/a327ex/BYTEPATH (MIT) |
| Fork | https://github.com/sigco3111/BYTEPATH |
| 작업 디렉토리 | /Users/mac/work/BYTEPATH |

## 게임 프로파일

| 항목 | 값 |
|---|---|
| 구조 | 모노리식 (top-level, 디렉터리 깊이 2) |
| 메인 파일 | main.lua (528줄) |
| 총 LOC | ~7,400 |
| 스킬 트리 | tree.lua (930줄, ~400 노드) |
| 적 14종 / 공격 17종 / 클래스 41종 / 디바이스 9종 | globals.lua 데이터 테이블 |
| 한글화 진입점 | T() 패턴 없음, lang/ 폴더 없음, 그래픽 자산 0개 |
| Steam | libraries/steamworks.lua (3731줄, FFI 자동 생성) |
| LÖVE 버전 (원본) | 0.10.2 — love 11.5에서 custom love.run 덕분에 정상 부팅 |

## SNKRX vs BYTEPATH 구조 비교

| 항목 | SNKRX | BYTEPATH |
|---|---|---|
| 디렉터리 구조 | engine/, engine/graphics/, engine/external/ 등 깊이 3 | 최상위 평탄 (libraries/, objects/, rooms/, resources/) |
| 텍스트 렌더링 | Font wrapper class + engine/graphics/text.lua | love.graphics.print 직접 호출 (171곳) |
| State 관리 | engine/init.lua가 love.filesystem.load 자동 사용 | main.lua의 bitser.dumpLoveFile (직접 bitser 호출) |
| Steam | luasteam (단순 모듈) | libraries/steamworks.lua (FFI 3731줄) |
| 한글화 진입점 | Font:get_font_for_text 메서드 추가 + engine/graphics/graphics.lua print 분기 | love.graphics.print 자체 오버라이드 |
| 해상도 | 480x270 좌표계 유지, window 1280x720 | 동일 (gw=480, gh=270, sx, sy) |
| 그래픽 자산 | assets/graphics/ PNG 풍부 | resources/graphics/ 비어있음 (0개) |
| LÖVE 버전 | 11.3+ | 0.10.2 (원본) |

## ⭐ 핵심 발견 5가지 (SKILL.md 본문에 반영)

### 1. luac 5.5 검증 함정 (CRITICAL)

brew의 기본 luac = Lua 5.5. LÖVE 11.5는 LuaJIT 2.1 (= Lua 5.1 호환).

**luac 5.5가 거부하는 코드 (love에서는 정상)**:
```
luac: ./libraries/HC/polygon.lua:352: attempt to assign to const variable 'i'
luac: ./libraries/hump/class.lua:38: attempt to assign to const variable 'k'
luac: ./libraries/mlib/mlib.lua:114: attempt to assign to const variable 'i'
```

Lua 5.4+ 부터 `for i = 1, N do ... end`에서 `i`가 상수. **LuaJIT 5.1은 상수 아님**.

**해결**: luac 검증 단계 제거. `love .` 실행으로만 검증.

```bash
# WRONG (전부 false-positive)
for f in $(find . -name '*.lua' -not -path './.git/*'); do
  luac -p "$f" 2>&1 | grep -v '^$' && echo "FAIL: $f"
done

# CORRECT
(love . > /tmp/love_run.log 2>&1 &)
sleep 8
PID=$(pgrep -f "love \." | head -1)
ps -p "$PID" -o pid,stat,command  # S = sleeping = OK
kill -9 "$PID"
cat /tmp/love_run.log  # 비어있으면 OK
```

### 2. ⭐ 모노리식 게임: love.graphics.print 오버라이드

SNKRX는 Font wrapper class를 추가해서 `font:get_font_for_text(text)` 메서드로 폰트 선택. **BYTEPATH는 wrapper class가 없고 love.graphics.print가 100+ 곳에서 직접 호출** → wrapper class 추가 불가능.

**해결**: `love.graphics.print` 자체를 오버라이드해서 CJK 감지 시 ko 폰트로 자동 교체.

```lua
-- lang/init.lua
love.graphics.print = function(text, ...)
    if not M._enabled then return M._original_print(text, ...) end
    local args = {...}
    local n = select('#', ...)
    -- (text, font, x, y, ...) 시그니처: 2번째 인자가 userdata/table이면 font
    if n >= 1 and (type(args[1]) == 'userdata' or type(args[1]) == 'table') then
        local actual = pick_font(args[1], text)
        if actual ~= args[1] then
            local rest = {}
            for i = 2, n do rest[i-1] = args[i] end
            return M._original_print(text, actual, table.unpack(rest))
        end
    end
    return M._original_print(text, ...)
end
```

**핵심 디테일**:
- `select('#', ...)`로 nil-trimmed 인자 개수 카운트 (가변 인자에서 필수)
- `table.unpack(rest)`는 LuaJIT 5.1에서 OK (Lua 5.2+ 표준 이름, Lua 5.1 raw는 `unpack`)
- `pick_font`은 font 객체의 `getHeight()`로 사이즈 추정 후 `fonts['NotoSansKR-Regular_<size>']` 매핑
- `fonts` 글로벌이 nil일 수 있으므로 `fonts and fonts[...]` 가드

### 3. Steamworks FFI require 결과는 boolean false

```lua
-- BYTEPATH main.lua line 1-2 (원본)
Steam = require 'libraries/steamworks'
if type(Steam) == 'boolean' then Steam = nil end  -- ⭐ boolean → nil 변환
```

**왜 false**: brew love는 `steam_api64.dll` 없어서 `libraries/steamworks.lua`의 FFI 초기화 실패 → boolean false 반환.

**luasteam과 다른 점**: luasteam은 항상 table 반환 (init/shutdown/runCallbacks 함수 보유). steamworks는 실패 시 false.

**확인**: `if type(Steam) == 'boolean' then Steam = nil end` 한 줄로 처리. 이후 모든 호출이 `if Steam then ... end` 가드 안이면 shim 작업 불필요.

검증 명령:
```bash
grep -rn "Steam\." --include="*.lua" --exclude-dir=libraries | grep -v "if Steam" | head
# → 모든 호출이 가드 안이어야 함. 빠져 있으면 가드 추가.
```

BYTEPATH는 8개 호출 모두 `if Steam then` 또는 주석 안에 있어 추가 작업 불필요.

### 4. loadFonts() 동적 사이즈 자동 생성 패턴

BYTEPATH는 main.lua의 loadFonts()가 8~16px 전부 자동 로드:
```lua
function loadFonts(path)
    fonts = {}
    local font_paths = {}
    recursiveEnumerate(path, font_paths)
    for i = 8, 16, 1 do
        for _, font_path in pairs(font_paths) do
            local font_name = font_path:sub(font_path:find("/[^/]*$")+1, -5)  -- .otf/.ttf 제거
            local font = love.graphics.newFont(font_path, i)
            font:setFilter('nearest', 'nearest')
            fonts[font_name .. '_' .. i] = font
        end
    end
end
```

**NotoSansKR-Regular.otf 추가만으로 `fonts['NotoSansKR-Regular_8/9/.../16']` 9개 자동 등록**. 추가 코드 불필요.

**SNKRX와 다른 점**: SNKRX는 engine/init.lua가 명시 사이즈만 로드 (`for _, size in ipairs({8, 10, 12, 14, 16, 20})`). 새 폰트 추가 시 별도 등록 필요.

**OtF 직접 로드 호환**: love 11.5 (LuaJIT 5.1)는 `.otf` 직접 로드 OK. SNKRX는 `.ttf` 받았는데 `.otf`가 더 가벼움 (4.6MB vs 6MB).

### 5. 동적 default 함정 (T() 패턴)

ko.lua의 value에 동적 표현식이 있으면 require 시점 1회 평가:

```lua
-- WRONG (한 번만 평가, id는 고정값)
console_welcome = '$BYTEPATH v1.0에 오신 걸 환영합니다 - <' .. string.sub(id or '', 1, 8) .. '>!'
-- ko.lua require 시점에 id가 nil → 빈 문자열 박힘
```

**해결**: ko.lua엔 정적 default만, 동적 부분은 호출 측:
```lua
-- ko.lua
console_welcome = '$BYTEPATH v1.0에 오신 걸 환영합니다',

-- 호출 측 (Console.lua)
self:addLine(delay, T('console_welcome') .. ' - <' .. string.sub(id or '', 1, 8) .. '>!')
```

또는 placeholder 패턴:
```lua
console_welcome_fmt = '%s v1.0에 오신 걸 환영합니다 - <%s>!',
-- 호출: string.format(T('console_welcome_fmt'), '$BYTEPATH', id_substr)
```

BYTEPATH v0.0.1에선 단순화해서 ko.lua의 동적 키는 모두 정적 fallback으로 변경. v0.1에서 placeholder 패턴 적용 예정.

## 디버깅 시퀀스 (실측 시간순)

| # | 단계 | 시도 | 결과 |
|---|---|---|---|
| 1 | 클론 + fork | `git clone + gh repo fork` | origin/upstream 분리 완료 |
| 2 | 헤드리스 검증 (1차) | `love . &` | PID=S, stderr 비어있음 ✅ |
| 3 | luac 5.5 검증 시도 | `for f in $(find ...); do luac -p $f` | 4개 외부 라이브러리 false-positive → SKILL 교훈 도출 |
| 4 | 구조 파악 | 디렉터리 맵 + 핵심 파일 read | 모노리식 + top-level + 171 print 호출 식별 |
| 5 | lang/init.lua 작성 | T() + has_cjk + love.graphics.print 오버라이드 | 신규 패턴 도출 |
| 6 | NotoSansKR 받기 | curl + .otf 저장 | 4.6MB |
| 7 | ko.lua 작성 | ~160개 키 (디바이스/공격/적/클래스/메뉴) | 10KB |
| 8 | 헤드리스 재검증 | `love . &` (lang/init.lua + ko.lua 추가 후) | PID=S, stderr 비어있음 ✅ |

**소요 시간**: ~40분 (분석 25분 + 인프라 15분). UI 라벨 적용은 v0.1.0부터 본격.

## 미완 작업 (다음 세션)

- [ ] Console/Sound/Display/Help/Credits/About/Escape/Shutdown/Effects/DeviceModule의 하드코딩 라벨을 `T()`로 교체 (~30분)
- [ ] 디바이스/공격/적/클래스 표시 위치 처리 (현재 키만 정의, callsite 미처리)
- [ ] Stage.lua의 일시정지/게임오버 화면 라벨
- [ ] SkillTree의 노드 400개 텍스트 (트리 stats 첫 번째 인자 표시용) — 데이터 테이블이라 직접 수정
- [ ] macOS 빌드 스크립트 (build_love.sh + build_all.sh, snkrx-clone 패턴 베이스)
- [ ] v0.1 커밋 → push → gh release create

## v0.0.1 누적 통계

- 변경 파일: main.lua (1줄 추가), lang/init.lua (신규 4.4KB), lang/ko.lua (신규 10KB), resources/fonts/NotoSansKR-Regular.otf (신규 4.6MB)
- 한국어 키: ~160개 (디바이스 9, 공격 17, 적 13, 클래스 38, 트리 타입 25, 콘솔 명령어 12, 모듈 12, 기타 34)
- 헤드리스 검증: 2회 성공
- Steam shim: 불필요 (nil-safe 기존 코드)

## 핵심 파일 위치 (sigco3111/BYTEPATH)

| 파일 | 역할 |
|---|---|
| `main.lua` line 1-2 | Steam require + boolean→nil 변환 |
| `main.lua` line 24-28 | require 추가 (lang 추가) |
| `main.lua` line 404-417 | loadFonts (8~16px 자동 생성) |
| `globals.lua` line 36-53 | attacks 데이터 (17종) |
| `globals.lua` line 100-101 | enemies (14종) |
| `globals.lua` line 104-114 | class_colors (41종) |
| `globals.lua` line 117-126 | unlockAchievement (Steam nil-safe) |
| `globals.lua` line 128-181 | achievement_names/descriptions (43종) |
| `globals.lua` line 183 | devices (9종) |
| `tree.lua` line 1-44 | treeToPlayer (bought_node_indexes → player 속성 누적) |
| `tree.lua` line 46-930 | 트리 노드 400개 (stats 텍스트는 표시용, attr 이름이 코드와 매핑) |
| `rooms/Console.lua` line 240-275 | 메인 메뉴 addLine (한글화 대상) |
| `rooms/SkillTree.lua` line 199, 231, 367, 378 | "Apply / Cancel" 버튼 라벨 |
| `objects/modules/*.lua` | 각 설정 모달 (한글화 대상) |
| `lang/init.lua` | T() + has_cjk + love.graphics.print 오버라이드 |
| `lang/ko.lua` | ~160개 한국어 키 |
| `resources/fonts/NotoSansKR-Regular.otf` | 4.6MB 한글 폰트 |
