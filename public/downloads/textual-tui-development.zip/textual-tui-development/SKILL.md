---
name: textual-tui-development
description: Textual 기반 Python TUI 개발 전체 워크플로 — 앱 설계(Grid/Footer/Header), 위젯 3종(SummaryPanel + DataTable + RichLog), 멀티 백엔드 ABC 패턴(FileSystem + Mock), Pilot 헤드리스 테스트, SVG/PNG 스크린샷, pytest 17개 통합. fireToken TUI 실전 검증 (textual 0.89, rich 15). "Textual TUI 만들어줘", "터미널 모니터링 대시보드", "Python CUI 앱", "실시간 상태 뷰어 + 키바인딩 제어" 같은 요청에 발동. python-oss-bootstrap이 단일 OSS 부트스트랩이라면, 이 스킬은 TUI 클래스 전체의 설계/구현/검증/푸시 통합.
---
# Textual TUI 개발 워크플로

> **호칭:** "희정님" (한글 통일, 한자 사용 금지) — 모든 산출물/로그/크론 출력에 한글 호칭만 사용

## 핵심 결정 포인트 (4가지)

TUI 작업 받으면 브레인스토밍으로 먼저 정리. python-oss-bootstrap / canvas-static-site-pipeline의 결정 패턴과 동일.

| # | 결정 | 옵션 | 추천 |
|---|---|---|---|
| 1 | **TUI 범위** | A 뷰어(모니터링) / B 컨트롤러(제어+뷰) / C 풀 리팩터 | **B** — 기존 자산 보존, IPC로 제어 |
| 2 | **라이브러리** | ① Rich+prompt_toolkit / ② Textual / ③ curses | **②** — async+위젯+CSS에 최적 |
| 3 | **백엔드 연동** | ① JSON 폴링 / ② JSONL tail / ③ subprocess / **①+② 하이브리드** | **하이브리드** |
| 4 | **배포 형태** | α CLI 단독 / β repo 서브폴더 / γ 별도 repo | **β** — 기존 repo에 tui/ |

→ "그대로 진행" 받으면 추천안으로 즉시 실행.

## 8단계 워크플로

### 1단계: 기존 워커 분석
- PS1/Go/Rust/어떤 백엔드든 IPC 계약이 어떻게 되는지 파악
- 핵심 인터페이스: 시작/정지 명령, 상태 출력 위치, 이벤트 스트림 위치
- 예: fireToken → `burn.ps1`(오케스트레이터) + `burn-session.ps1`(워커) + `.stop` 파일

### 2단계: IPC 모듈 작성 (백엔드 측)
원자적 파일 쓰기 + 명시적 ACK 패턴:

```python
# PowerShell 측
$tmpFile = "$StateFile.tmp"
Set-Content -Path $tmpFile -Value $json -Encoding UTF8 -NoNewline
Move-Item -Path $tmpFile -Destination $StateFile -Force  # atomic rename
```

```python
# Python 측 (FileSystemBackend.send_command)
with tempfile.NamedTemporaryFile(mode="w", delete=False, dir=str(self._dir), prefix="cmd.", suffix=".tmp") as tmp:
    json.dump(cmd, tmp)
    tmp_path = tmp.name
os.replace(tmp_path, cmd_path)  # atomic
```

### 3단계: Python 패키지 구조
```
tui/
├── pyproject.toml          # textual/rich, console_scripts=[ftui=...:main]
├── README.md               # 한/영 병기 + 다층 옵션
├── firetoken_tui/
│   ├── __init__.py
│   ├── app.py              # Textual App + main() CLI entry
│   ├── ipc/
│   │   ├── __init__.py
│   │   ├── backend.py      # Backend ABC, SessionState, Event, CommandResult
│   │   ├── fs_backend.py   # 실제 파일 IPC
│   │   └── mock_backend.py # 시뮬레이션 (macOS/Linux 개발용)
│   └── widgets/
│       ├── __init__.py
│       ├── summary_panel.py
│       ├── session_table.py
│       └── event_log.py
└── tests/
    ├── test_backend.py
    └── test_app.py
```

### 4단계: Backend ABC + Mock 패턴
- **FileSystemBackend**: 실제 PS1 IPC (Windows 운영용)
- **MockBackend**: macOS/Linux 개발 + 데모용 (5세션 시뮬레이션, RLock 워커)
- **자동 디텍션**: 환경변수 → 표준 경로 → 폴백(Mock)

```python
class Backend(abc.ABC):
    @abc.abstractmethod
    def get_session(self, session_id: int) -> SessionState | None: ...
    @abc.abstractmethod
    def list_sessions(self) -> dict[int, SessionState]: ...
    @abc.abstractmethod
    def tail_events(self, since_byte: int = 0) -> tuple[list[Event], int]: ...
    @abc.abstractmethod
    def send_command(self, action: str, value: str | None = None) -> CommandResult: ...
    @abc.abstractmethod
    def is_connected(self) -> bool: ...
    @abc.abstractmethod
    def ipc_dir(self) -> str: ...
```

### 5단계: Textual App (Grid + Footer + 1초 폴링)
```python
class FireTokenApp(App):
    CSS = """
    Screen { layout: vertical; }
    #summary { height: 4; padding: 0 1; background: $boost; border-bottom: solid $primary; }
    #main { height: 1fr; layout: vertical; }
    #sessions { height: 40%; min-height: 8; border-bottom: solid $primary; }
    #events { height: 60%; min-height: 10; }
    """
    BINDINGS = [
        Binding("q", "quit", "Quit", priority=True),
        Binding("s", "stop_all", "Stop"),
        Binding("r", "cycle_reasoning", "Reasoning"),
        # ...
    ]
    
    def on_mount(self) -> None:
        self.set_interval(1.0, self._tick)  # 1초마다 폴링
    
    def _tick(self) -> None:
        sessions = self.backend.list_sessions()
        events, new_offset = self.backend.tail_events(self._event_byte_offset)
        # ...
```

### 6단계: 3대 위젯

**SummaryPanel** (헤더 KPI):
- reactive: total_tokens, total_rounds, sessions_active, tps
- render(): Text 한 줄에 KPI 6개 색상화

**SessionTable** (DataTable):
- 12컬럼: ID, PID, Status, Round, Last, Total, Reason, Output, Err, Ctx, Msgs, Updated
- Status 색상 (running=green, retrying=yellow, error=red)
- Updated 신선도 (0~3s=green, 3~10s=yellow, 10s+=red)
- ⚠️ **DataTable DuplicateKey race 함정** — 아래 Pitfalls 참조

**EventLog** (RichLog):
- append-only, wrap=False (줄바꿈 금지)
- truncate 길이 80자 (긴 kv는 `...` 처리)
- _STYLE_BY_TYPE로 이벤트 타입별 색상

### 7단계: pytest 통합
- 백엔드 15개 (SessionState, Event, MockBackend, FileSystemBackend, edge cases)
- Textual 앱 2개 (Pilot 헤드리스 smoke test, 키바인딩 cycle)
- **RLock 데드락 함정** — 아래 Pitfalls 참조

```python
@pytest.mark.asyncio
async def test_textual_app_renders_with_mock() -> None:
    backend = MockBackend(n_sessions=3, tick_seconds=0.3, seed=1)
    app = FireTokenApp(backend)
    async with app.run_test(size=(120, 40)) as pilot:
        await pilot.pause(0.3)
        assert app.is_running
        assert app.query("SummaryPanel")
        # ...
```

### 8단계: 헤드리스 스크린샷 + 시각 검증
- `app.export_screenshot()` → SVG → `cairosvg.svg2png` → vision_analyze
- 8초+ 누적 후 캡처 (round ≥ 20, total ≥ 100K)
- vision이 8/10+ 나올 때까지 헤더/테이블/로그 비율 조정

## ⚠️ Pitfalls (실전 검증, 2026-06-20 fireToken TUI)

### P1. MockBackend RLock 데드락 (최우선)
- `MockBackend._run`이 `with self._lock:` 잡은 채로 `self._emit_event(...)` 호출
- `_emit_event`도 `with self._lock:` → 일반 `Lock`이면 데드락
- **해결**: `threading.RLock()` (재진입 가능) 사용
- **증상**: `MockBackend()` 생성은 OK, `send_command` 호출 시 영원히 hang
- **진단**: `python -u -c "...send_command('stop')..."` 후 `faulthandler.dump_traceback_later(timeout=3)`로 스레드 덤프

### P2. DataTable DuplicateKey race
- `update_cell`로 기존 row 업데이트 시도 → `KeyError` (row 없음) → except에서 `add_row` → 이미 다른 tick에서 추가됐으면 `DuplicateKey`
- **해결**: `if row_key not in self._last_states: try add_row except DuplicateKey: pass else: update_cell` 패턴
- **왜 `_last_states`로 판단하나**: `self._row_keys()` 같은 메서드는 textual 버전마다 다름. dict 기반 체크가 안정적.

### P3. 원자적 파일 쓰기 필수
- PowerShell과 Python 양쪽 다 같은 디렉토리에 쓸 때 `Set-Content` + `Move-Item` 또는 `tempfile.NamedTemporaryFile` + `os.replace` 패턴
- 일반 `open(path, 'w')`는 Windows에서 부분 쓰기 노출

### P4. venv 분리 (PEP 668 회피)
- macOS 시스템 Python은 PEP 668이라 `pip install` 불가
- `uv venv .venv --python 3.11` → `source .venv/bin/activate` → `uv pip install -e ".[dev]"`
- `console_scripts` 등록으로 `ftui` 한 방 실행

### P5. f-string 마스킹 (Bearer 외)
- TUI 코드에 secret 직접 삽입 시 `***` 마스킹이 문자열 깨뜨려 SyntaxError 가능
- `os.path.expanduser("~/.hermes/secrets/...")` + `open().read().strip()` 패턴

### P6. RichLog wrap=False
- 기본 wrap=True면 한 이벤트가 2줄로 깨져서 가독성↓
- `wrap=False` + `kv[:80] + "..."` truncate 조합이 한 줄 = 한 이벤트

### P7. `_default_ipc_dir()` 디텍션 우선순위
- `$FIRETOKEN_IPC_DIR` 환경변수 → Windows `$TEMP/fireToken-ipc` → Linux `/tmp/fireToken-ipc` → Mock 폴백
- 환경변수 체크를 첫 번째에 두면 사용자가 명시 제어 가능

### P8. `_format_age` 색상 임계치
- 단순 숫자 표시 대신 색상으로 신선도 전달
- 0~3s=green / 3~10s=yellow / 10s+=red bold
- Mock에서 1초 tick이면 0s만 보이지만 운영에서 5+ 초 stall 감지에 유용

### P9. Pilot `size=(W, H)` 명시
- 기본 80x24는 너무 작아서 스크린샷이 잘림
- `size=(140, 40)` 또는 `(120, 40)` 권장 — vision_analyze용

### P10. `--mock --seed` 결정론
- 회귀 테스트 시 `--seed 42`로 시드 고정
- 안 그러면 mock 데이터가 매번 달라져서 스크린샷 비교 불가

### P11. Python env mismatch (system vs conda vs venv)
- 시스템 Python (`/Library/Frameworks/Python.framework/Versions/3.8/bin/python3`)에 `--user`로 `textual`을 설치했는데, 사용자 터미널의 `python3`이 conda base env나 다른 venv을 가리키면 `ModuleNotFoundError`.
- **증상**: 같은 path인데 한 터널에선 import OK, 다른 터널에선 `No module named 'textual'`.
- **해결 A — 래퍼 스크립트 (가장 확실)**:
  ```bash
  cat > ~/bin/run-dashboard.sh << 'EOF'
  #!/bin/bash
  exec /Library/Frameworks/Python.framework/Versions/3.8/bin/python3 ~/dashboard.py
  EOF
  chmod +x ~/bin/run-dashboard.sh
  ```
  절대경로 Python을 강제 사용.
- **해결 B — alias 영구 등록**:
  ```bash
  echo "alias mineboard='/Library/Frameworks/Python.framework/Versions/3.8/bin/python3 ~/dashboard.py'" >> ~/.zshrc
  source ~/.zshrc
  ```
- **해결 C — shebang 변경**: dashboard.py 첫 줄을 `#!/Library/Frameworks/Python.framework/Versions/3.8/bin/python3`로. `chmod +x` 후 직접 실행. 단 crontab/LaunchAgent에선 shebang이 우선이라 가장 견고.
- **진단**: `which python3` + `python3 -c "import sys; print(sys.executable, sys.prefix)"` 두 결과 비교. prefix가 conda env path면 venv 다름.

### P12. 실시간 로그 파일 tailing 패턴 (fireToken IPC와 다른 케이스)
- fireToken은 **원자적 IPC 파일**을 폴링해서 읽음 (프로세스가 JSON을 통째로 덤프).
- 채굴/장기 daemon 모니터링은 **append-only 로그 파일을 tail**해서 incremental 파싱.
- 차이점:
  - IPC 파일: 매 tick마다 새 JSON → `dict` 통째로 갱신
  - 로그 tail: append만 → 마지막 N줄만 파싱 → **deque(maxlen=N)**로 메모리 고정
  - 50KB tail → `f.seek(max(0, size - 50_000))` + `f.read().decode('utf-8', errors='ignore')`로 안전
- **regex 파싱 시**:
  - 한 줄에 여러 정보 (예: XMRig `speed 10s/60s/15m 1313.3 1173.6 n/a H/s max 1320.9 H/s`) → 단일 regex로 4 그룹
  - 같은 패턴이 로그에 여러 번 → **마지막 매치만 유효** (덮어쓰기, 누적 X)
  - timestamp prefix는 `[2026-06-24 09:21:26.337]` 형식 → `line[:19]` 또는 `line.split(']')[0]`
- **share accepted 추적**: regex `r"accepted\s+\((\d+)/(\d+)\)"` → `(accepted, rejected)` 카운트. 단 XMRig은 *전체* accepted만 카운트, 새로 N번째일 때만 출력. 모니터링에선 N-1 차이로 증분 계산.
- **dataset ready 신호**: `randomx dataset ready (\d+ ms)` → 초기화 완료 마커. TUI 첫 5~10초 "Loading..." 표시 후 전환.
- **pool latency**: XMRig 로그엔 직접 안 보임. SupportXMR API (`https://supportxmr.com/api/miner/<addr>/stats`)로 외부 조회. 5분 캐시 권장 (rate limit).
- **전체 템플릿**: `templates/live-log-dashboard.py` 참조 (XMRig Mining Dashboard 실전 검증 코드).

### P13. TUI 비대화형 검증 (Pilot 없이)
- 비대화형 환경 (`background: true` + `sleep` 패턴)에서 TUI를 띄우면 화면 refresh 루프에 빠져 timeout.
- 비대화형 검증법: **Pilot 테스트 + 데이터 파싱 함수 단독 테스트** 분리.
  - 데이터 파싱은 `importlib`로 import해서 함수만 호출 (TUI 진입 X).
  - Pilot 테스트는 `pytest-asyncio`로 헤드리스 (`async with app.run_test(size=(W, H))`).
  - 비대화형 터미널에서 실제 TUI 실행은 비추 (timeout).
- **이게 작동한다는 신호**: 비대화형에서 timeout나면서도 Textual이 만든 예쁜 traceback 박스가 출력되면 TUI 로드는 성공. 실제 TTY 터미널에서 다시 실행.

### P15. 빈 dict state → KeyError (최우선, 이번 세션 4번의 디버깅 원인)
- `App.__init__`에서 `self.state = {"log": {}}`처럼 비어두면, **첫 render**가 `__init__` 직후 즉시 호출됨 → 위젯의 `self.app.state["log"]["metric_a"]` 같은 접근이 `KeyError`로 폭발.
- **증상**: import는 OK, parse 함수도 OK, Pilot에서도 OK인데 **TUI 첫 화면에 traceback 폭발**.
- **해결 패턴 3가지 (모두 적용 권장)**:
  ```python
  # 1) _DEFAULT_STATE 모듈 상수 — parse 함수 + render 양쪽 공유
  _DEFAULT_STATE = {
      "metric_a": 0.0,
      "metric_b": 0.0,
      "ready": False,
      "connected": False,
      "block_height": 0,
      "recent_log": deque(maxlen=8),
  }

  def parse_log_file(path: Path) -> dict:
      # deep copy (특히 deque는 copy 필수)
      state = {k: (v.copy() if isinstance(v, deque) else v) for k, v in _DEFAULT_STATE.items()}
      if not path.exists():
          return state
      # ... 파싱 ...

  # 2) App.__init__에서 즉시 채워넣기 (refresh 전 안전)
  def __init__(self):
      super().__init__()
      self.state = {
          "log": {k: (v.copy() if isinstance(v, deque) else v) for k, v in _DEFAULT_STATE.items()},
          "system": {"cpu_pct": 0.0, "mem_pct": 0.0, ...},
          "external": {"price": FALLBACK_PRICE},
      }

  # 3) render 안에서 .get() 안전 접근 (defense in depth)
  def render(self) -> str:
      s = self.app.state.get("log", _DEFAULT_STATE)
      v = s.get("metric_a", 0.0)  # .get() + 기본값
      # ...
  ```
- **왜 3중 방어?** — `__init__`이 `parse_log_file`을 호출해도 파일이 아직 없으면 `{}` 비슷한 빈 dict 반환 가능. `on_mount`의 `set_interval`이 첫 refresh 돌기 전 위젯 render가 먼저 호출될 수 있음. **defense in depth**.
- **진단**: importlib 단독 import는 OK인데 TUI 첫 화면에서만 traceback → 이 패턴 99%.

### P16. Header/Footer 자체 markup 충돌 — `MarkupError: closing tag '[/dim]'`
- **증상**: EarningsPanel의 `[dim]Power cost: ...[/dim]` 처럼 **짝이 맞는 markup**을 썼는데도 `MarkupError: closing tag '[/dim]' does not match any open tag`.
- **원인**: Textual 0.89+의 `Footer` 위젯이 **자체적으로 색상 markup** (예: `[/dim]`)을 키바인딩 표시용으로 만들어냄. 사용자 widget의 markup과 **무관한 컨텍스트**에서 짝 없는 닫는 태그가 나타남. `Footer(markup=False)` 같은 옵션도 **Footer 시그니처에 없음** (TypeError).
- **해결**: `Header`/`Footer` 둘 다 빼고 직접 만든 `Static`으로 키바인딩 안내 표시.
  ```python
  def compose(self) -> ComposeResult:
      yield StatusBar()
      with Container(id="main"):
          # ... 위젯들 ...
          yield Static("Press q to quit  |  p pause  |  r resume", id="hint")
      # Header() / Footer() 절대 넣지 말 것
  ```
- **CSS로 hint 위치 잡기**:
  ```css
  #hint { height: 1; color: #888; text-align: center; }
  ```
- **추가 함정**: 다른 사용자 위젯의 markup에 `[dim]...[/dim]`, `[bold]...[/bold]` 같은 짝이 **무조건 안전하지 않음**. 가능하면 plain text + `Rich` color만 사용하고 Rich markup은 `bold/color` 같은 단순한 것 위주로.
- **대안**: `Static(markup=False)`로 개별 위젯 markup 끄기 (`textual.widgets.Static`에 `markup` 인자 있음). 단 그러면 색상 다 잃음.
- **Textual의 `[/` 인접 태그 함정 (P19 강화)**: `>[/[#1f8033]`처럼 **닫는 태그 + 새 여는 태그가 인접**하면 Textual의 `from_markup` parser가 `[/[#1f8033]`을 통째로 잘못된 닫는 태그로 해석. `>[/` standalone이든, `MarkupError: closing tag '[/[#1f8033]' does not match any open tag` 발생. **해결**: 출력 글자(`>`, `(`, `*` 등)는 **markup 바깥에 두거나** 단순한 `  ` (indent)로 대체. **Rich는 `[/`를 닫는 태그로 해석하지만, Textual은 인접한 `[#xxx]`까지 묶어서 잘못 파싱** — 두 라이브러리 간 마이크로 차이.

### P14. CoinGecko 등 외부 API + 5분 캐시
- 채굴 수익 계산엔 XMR/USD 가격이 필요.
- `https://api.coingecko.com/api/v3/simple/price?ids=monero&vs_currencies=usd` 무료, rate limit 넉넉.
- 매초 호출 ❌ → 5분 캐시 (`_last_price_fetch` + `time.time()` diff 체크).
- 실패 시 fallback 가격 (hardcoded $318) — TUI가 절대 안 떠야 하는 경우 방지.

### P17. Path resolution fallback chain (env var → candidates → placeholder)
- **증상**: TUI 첫 화면에서 XMRig 메트릭 패널만 비어 있음 (SYSTEM/CPU는 채워짐). 파서 함수 단독 호출은 데이터 잘 나옴.
- **원인**: 코드의 기본 경로 (`~/.xmrig/xmrig.log`)가 실제 환경의 경로 (`~/xmrig.log`)와 다름. `Path.exists()` False → 파서가 빈 dict 반환 → 위젯은 0/IDLE 표시.
- **진단**: `parse_xxx()` 함수를 단독 호출해서 빈 dict 나오면 100% 경로 문제. TUI에서 stdout/stderr이 안 보일 수 있어 **main() 시작 시 경로 + [OK]/[NOT FOUND] 한 줄 출력** 필수.
- **해결 패턴 — 후보 리스트 + env var 우선**:
  ```python
  _DEFAULT_LOG_CANDIDATES = [
      Path.home() / ".xmrig" / "log.txt",    # 표준 (FHS-style)
      Path.home() / "log.txt",                # 흔한 변형
      Path("/tmp/log.txt"),                   # 임시
  ]

  def _resolve_path(env_var: str, candidates: list) -> Path:
      env_val = os.environ.get(env_var)
      if env_val:
          return Path(env_val)
      for c in candidates:
          if c.exists():
              return c
      return candidates[0]  # 그래도 fallback — 사용자에게 "어디 봤는지" 알림

  XMRIG_LOG = _resolve_path("XMRIG_LOG", _DEFAULT_LOG_CANDIDATES)
  ```
- **main()에서 진단 출력**:
  ```python
  def main() -> None:
      print(f"XMRig log:    {XMRIG_LOG}  {'[OK]' if XMRIG_LOG.exists() else '[NOT FOUND]'}")
      print(f"XMRig config: {XMRIG_CONFIG}  {'[OK]' if XMRIG_CONFIG.exists() else '[NOT FOUND]'}")
  ```
  TUI가 풀스크린으로 뜨기 전 stderr로 출력되니 사용자가 즉시 경로 확인 가능.
- **왜 TUI에서 "이게 진짜 원인"인지 모르기 쉬운가**: stderr의 sanity warning이 풀스크린 TUI 진입 후엔 화면에 안 보임. **main() 첫 줄에 stdout으로 박는 게 유일한 안전망**.
- **선호순서**: env var 명시 > 첫 번째 존재하는 후보 > 첫 번째 후보 (NOT FOUND 표시). 절대 빈 Path 반환 ❌.
- **XDG 호환성**: Linux에서는 `$XDG_DATA_HOME` / `$XDG_CONFIG_HOME`도 후보에 추가 고려. macOS/Windows는 `Path.home()` 기반이 충분.

### P18. TUI 개발 중 프로세스 정리 패턴
- TUI를 background로 띄워 디버깅하다 보면 zombie 프로세스가 쌓임. `pkill -f "miner-dashboard"` 한 방에 정리.
- **검증용 짧은 실행 패턴** (TUI가 진짜 잘 뜨는지 확인):
  ```bash
  # 비대화형 환경에서 TUI를 8~15초 띄웠다 죽이기
  /Library/.../python3 dashboard.py > /tmp/dash.log 2>&1 &
  sleep 12
  pkill -9 -f dashboard.py
  head -30 /tmp/dash.log  # 첫 화면 확인
  ```
- **shell의 `&` vs `terminal(background=true)` 헷갈림**: 이 환경(Hermes)에서는 `nohup ... &` / `disown` 같은 shell-level backgrounding이 **막혀있음**. `terminal(background=true)`만 사용 가능. 둘 다 섞으면 runtime error.
- **TUI가 background에서 timeout 나는 게 정상**: 비대화형 터미널엔 TTY가 없어 화면 refresh 루프가 무한 → timeout. 그래도 Textual이 만든 예쁜 traceback 박스가 stdout에 찍히면 "TUI 로드 성공" 신호. 실제 TTY에서 다시 실행.
- **TUI 프로세스 죽이기**:
  ```bash
  pkill -9 -f "miner-dashboard"  # 강한 종료
  pgrep -fl "miner-dashboard" | grep -v "bash -lic"  # 살아있는지 확인
  ```
- **여러 TUI 테스트할 때 매번 정리**: 각 테스트 사이에 `pkill -9` 안 하면 port 충돌 / display 점유 / 로그 파일 lock 가능.

### P30. 모든 panel에 auto-adapt density mode 적용 (2026-06-24)
- **시그널**: "화면 잘림" 또는 "작은 창에서도 모든 정보 보여야 해" — 한 panel만 압축하면 다른 panel이 잘려서 무의미. **6개 panel 모두 일괄 압축 필수**.
- **잘못된 패턴**: 첫 panel(EarningsPanel)에만 `_compact_mode` 체크 추가. **다른 panel들은 그대로** → 작은 창에서 여전히 잘림. 사용자가 또다시 "다른 panel도 잘림" 리포트 → 5번 반복 디버깅.
- **올바른 패턴 — 모든 panel에 일괄 적용**:
  ```python
  def render(self) -> str:
      try:
          screen_h = self.app.size.height
      except Exception:
          screen_h = 80
      if self.app._compact_mode or screen_h < 36:
          # compact 4-6 lines
          return (
              f"[bold #33ff66] SYSTEM [/bold #33ff66]\n"
              f"  CPU [#ccffdd]{cpu_pct:5.1f}%[/#ccffdd]  [#1f8033]Cores {cores}[/#1f8033]\n"
              f"  RAM [#ccffdd]{mem_pct:5.1f}%[/#ccffdd]  [#1f8033]{mem_used:.1f}/{mem_total:.1f} GB[/#1f8033]\n"
              f"  PWR [#ccffdd]~{power:.0f}W[/#ccffdd]  UPTIME [#ccffdd]{int(uptime//3600)}h {int((uptime%3600)//60)}m[/#ccffdd]\n"
          )
      # else: full mode (existing code)
  ```
- **임계값 권장**:
  - `< 36` lines → compact (4-6 lines per panel)
  - `36-50` lines → standard (8-10 lines per panel)
  - `> 50` lines → full (12-16 lines per panel)
- **`self.app.size.height` 접근은 반드시 `try/except`로 감싸기** (P31) — 앱 컨텍스트 외부 또는 render() 호출 시점 컨텍스트 없으면 AttributeError 가능.
- **CSS padding 줄이기** (작은 컨텐츠가 panel 안에 들어가도록):
  ```css
  HashratePanel, SystemPanel, ... { padding: 0 2; }  /* was padding: 1 2 */
  ```
  상하 padding을 0으로 줄여서 panel 안의 컨텐츠에 1~2줄 더 들어감.
- **이게 작동하는 이유**: 6개 panel × 평균 6줄 = 36줄 본문 + status bar 1줄 + hint 1줄 = 38줄. 24줄 창이면 `compact_mode=True` 강제 또는 화면 키우기 안내. 36~50줄 창이면 auto-compact로 6 panel 다 보임.
- **HashratePanel은 자꾸 빠짐**: `self.app._compact_mode` 체크가 EarningsPanel/SystemPanel에는 있는데 HashratePanel에는 없었던 함정. **검증할 때 모든 panel grep**:
  ```bash
  grep -L "self.app._compact_mode\|screen_h" panel_files/*.py
  # → 빠진 파일 나열 (HashratePanel이 자주 빠짐)
  ```

### P31. `self.app.size.height` 안전한 접근 패턴
- **시그널**: TUI는 잘 뜨는데 panel render() 호출 시점에 `AttributeError: 'NoneType' object has no attribute 'height'` 같은 에러.
- **원인 1**: Textual이 `app.size`를 `None`으로 두는 시점 존재 (mount 전, focus 없을 때, headless Pilot 모드).
- **원인 2**: `self.app`이 `None`인 케이스 — LogPanel.render()가 `Container.__init__`에서 너무 빨리 호출되면 app context 없음.
- **올바른 패턴 — try/except로 방어**:
  ```python
  def render(self) -> str:
      try:
          screen_h = self.app.size.height
      except Exception:
          screen_h = 80  # conservative default
      # ... use screen_h
  ```
- **왜 try/except 가 안전한가**:
  - `screen_h = 80` fallback은 **항상 full 모드 선택** → 컨텐츠 다 보임. 잘못된 threshold 선택보다 **안전**.
  - 에러는 다음 refresh tick에서 (app.size가 채워진 후) 자동 해결.
  - `self.app._compact_mode` 같은 다른 상태는 try/except 없이 안전 (단순 bool).
- **anti-패턴**: `screen_h = self.app.size.height` (raw) — AttributeError 시 panel crash. try/except는 **defense in depth**.
- **테스트 시**:
  ```python
  # app.run_test(size=(W, H)) — size 명시 필수, app.size 채워짐
  async with app.run_test(size=(80, 24)) as pilot:
      # panel.render() — app.size 정상
  # 비 run_test 환경 — try/except 없으면 crash
  ```

### P19. Rich markup 짝 디버깅 — 태그 카운팅으로 일괄 찾기
- **증상**: `MarkupError: closing tag '[/#1f8033]' does not match any open tag` — 짝이 **맞아 보이는** markup인데도 에러.
- **흔한 원인 1 — `[dim X]` vs `[/X]` 비일관**: 파일 안에 `[dim #1f8033]...[/#1f8033]` (일관)과 `[#1f8033]...[/]` (불일치)이 섞여 있을 때 Rich parser가 헷갈림. **`[dim X]`는 `[/dim X]`로 닫거나, plain `[/]`만 쓰는 두 가지 중 하나로 통일**해야 함.
- **흔한 원인 2 — 동적 색상 주입**: f-string 안에 `[{rej_color}]{rejected}[/{rej_color}]`처럼 변수로 색을 만들면, 직전/직후 다른 색이 닫힐 때 Rich 파서가 컨텍스트를 잃음. **조건문으로 분기해서 닫는 태그 짝을 명시적으로**:
  ```python
  if rejected > 0:
      h += f"[bold #ff3355]{rejected}[/bold #ff3355] bad  "
  else:
      h += f"[#1f8033]{rejected}[/#1f8033] bad  "
  ```
- **흔한 원인 3 — `[/]` 단축 닫기**: `[/]`는 가장 가까운 열린 태그를 닫지만, 그게 어떤 색인지 Rich가 추적 못할 때 `closing tag does not match` 발생. **명시적인 `[/color]`로 닫는 게 안전**.
- **디버깅 워크플로 (한 번에 모든 짝 검사)** — `MarkupError` 한 번 떴다면 **반복 패치 ❌, grep 한 방 ✅**:
  ```bash
  # 모든 색상 토큰의 open/close 카운트
  for color in 1f8033 33ff66 ccffdd 00ff9c ffaa00 ff3355 0e4019; do
      open=$(grep -c "\[#$color\]" file.py)
      close=$(grep -c "\[/#$color\]" file.py)
      echo "#$color open=$open close=$close delta=$((open - close))"
  done
  # dim 변형도 확인
  for color in 1f8033 33ff66; do
      open=$(grep -c "\[dim #$color\]" file.py)
      close=$(grep -c "\[/dim #$color\]" file.py)
      echo "dim #$color open=$open close=$close delta=$((open - close))"
  done
  ```
  **delta가 0이 아닌 색이 문제**. 한 줄 패치 → 재테스트 반복 ❌ — **이 grep을 한 번 돌리고 모든 어긋난 색을 한꺼번에 수정**한 다음 다시 테스트. (4번의 MarkupError 사이클은 거의 항상 이걸 안 돌린 결과.)
- **추가 함정**: `[bold #ccffdd]EARNINGS ESTIMATE[/bold #ccffdd]`처럼 **bold** 안에 다른 색이 인라인으로 들어오면 `bold` 자체가 복잡한 parser state가 됨. bold 바깥에서 색을 닫고 안에서 다시 여는 게 안전:
  ```python
  # 위험
  f"[bold #ccffdd]EARNINGS ESTIMATE[/bold #ccffdd] [#33ff66]..."
  # 안전
  f"[bold #ccffdd]EARNINGS ESTIMATE[/bold #ccffdd] [#33ff66]...[/]"
  ```
- **방어 패턴** (모든 panel render()에): 5개 이상 inline 색이 들어가면 코드를 다시 보고, **plain text + 부분 bold**로 단순화하는 게 안전. Markup 화려함보다 한 줄이라도 안 깨지는 게 우선.

### P20. Textual CSS는 `animation` 미지원 — 펄스는 class 토글로
- **증상**: CSS에 `animation: pulse 2s ease-in-out infinite;`를 쓰면 TUI 시작 시 `Invalid CSS property 'animation'. Did you mean 'transition'?` 에러. **Textual은 `animation` CSS 속성을 지원 안 함** (textual 0.89/6.x 모두). `transition`은 가능.
- **대안 — class toggle로 수동 펄스**: refresh tick에서 panel의 CSS 클래스를 번갈아 토글:
  ```python
  # CSS
  HashratePanel.-mining-active { border: solid #00ff9c; }
  HashratePanel.-mining-active.-pulse-bright { border: solid #ccffdd; }

  # Python (refresh_metrics에서)
  self._tick_count += 1
  if self._tick_count % 4 == 0:
      panel.add_class("-pulse-bright")
  else:
      panel.remove_class("-pulse-bright")
  ```
  `-pulse-bright`가 4 tick마다 1초(2Hz × 4) 동안 켜졌다 꺼지면서 "breathing" 효과.
- **전체 tick이 아닌 4의 배수에서만 토글하는 이유**: 매 tick마다 토글하면 너무 빠름 (2Hz = 0.5초마다 색 바뀜 → 산만). 2초 주기가 호흡 리듬에 맞아 보임.
- **`hasattr(panel, "has_class")` 안 됨**: `has_class`는 항상 있음 (Static 부모). `panel.has_class(...)`가 표준. 없으면 `add_class`/`remove_class` 둘 다 실패 → `try/except`로 감싸기.
- **CSS의 `transition`은 단일 속성 변화에 한정**: e.g. `transition: color 500ms;`는 가능하지만 여러 속성 동시 변화나 키프레임 시퀀스에는 한계. 펄스 같은 정적 토글이 더 안정적.
- **TUI는 24Hz~60Hz refresh가 흔하지만, 펄스 같은 시각 효과는 2~4 tick마다** 토글해야 눈에 거슬리지 않음. 1초 = 4 ticks at 4Hz가 sweet spot.

### P21. NMMiner 사이버펑크 그린 + PALETTE dict 일원화 (2026-06-24 xmrig-dashboard)
- **시그널**: "NMMiner 스타일 사이버펑크 그린" 또는 "매트릭스 톤" 같은 요청 → 단일 색상이 아니라 **6~9색 팔레트**로 계층화 필요.
- **반대 패턴 (안티)**: 각 panel render()에서 `f"[bold cyan]..."`, `f"[bold magenta]..."` 처럼 인라인 색상 박기 → 한 곳 바꾸려면 grep으로 다 찾아야 함.
- **해결 — 모듈 상수 PALETTE dict + f-string 보간**:
  ```python
  PALETTE = {
      "bg":          "#001100",  # deep terminal green-black
      "bg_dark":     "#000800",  # status bar
      "fg":          "#33ff66",  # primary text
      "fg_dim":      "#1f8033",  # dim text (labels)
      "fg_faint":    "#0e4019",  # very dim (axis hints)
      "accent":      "#00ff9c",  # bright accent (active)
      "warning":     "#ffaa00",  # amber
      "error":       "#ff3355",  # red
      "highlight":   "#ccffdd",  # near-white (current values)
  }

  # CSS도 보간 (f-string)
  class App:
      CSS = f"""
      Screen {{ background: {PALETTE['bg']}; color: {PALETTE['fg']}; }}
      HashratePanel {{ border: solid {PALETTE['accent']}; }}
      """
  ```
- **시각 계층 권장 매핑**:
  - `accent` (bright) — active state, ">>> MINING <<<"
  - `fg` (standard) — primary text, numbers
  - `highlight` (near-white) — current values, sparklines (눈에 띄어야)
  - `fg_dim` — labels, separator pipes
  - `fg_faint` — background hints
  - `warning` (amber) — idle state, mid temperature, 1-5% reject
  - `error` (red) — high temperature, >5% reject
- **임계값에 따른 색상 자동 전환** (수동 박지 말고):
  ```python
  # CPU 온도
  if temp is None:    s = f"[{PALETTE['fg_dim']}]n/a[/{PALETTE['fg_dim']}]"
  elif temp >= 85:    s = f"[bold {PALETTE['error']}]{temp:.0f}C[/bold {PALETTE['error']}]"
  elif temp >= 70:    s = f"[bold {PALETTE['warning']}]{temp:.0f}C[/bold {PALETTE['warning']}]"
  else:               s = f"[{PALETTE['highlight']}]{temp:.0f}C[/{PALETTE['highlight']}]"
  ```
- **상태바의 색상 토큰별 의미**: `>>> MINING <<<` vs `--- IDLE ---` 같은 ASCII art 마커 + 색상 조합 → 1글자 TTY에서도 의미 전달.
- **이게 좋은 이유**: 한 색상 변경(예: `fg_dim`을 더 어둡게) → 모든 panel 자동 반영. grep 불필요. Light/Dark 모드도 PALETTE dict swap으로 가능.

### P22. TUI sparkline — Unicode 블록 + deque history
- **시그널**: 시계열 데이터를 TUI에 보여주고 싶음 (hasrate, latency, queue depth 등). 그래프 라이브러리 없이.
- **패턴**:
  ```python
  from collections import deque
  SPARKLINE_SAMPLES = 60  # 30s @ 2Hz
  self._history: deque = deque(maxlen=SPARKLINE_SAMPLES)

  # refresh에서
  self._history.append(current_value)

  # render에서 (Unicode 블록 8단계: ▁▂▃▄▅▆▇█)
  history = list(self.app._history)
  if history:
      blocks = "▁▂▃▄▅▆▇█"
      mn, mx = min(history), max(history)
      rng = max(mx - mn, 1.0)
      spark = "".join(blocks[min(7, int((v - mn) / rng * 7))] for v in history)
  ```
- **왜 좋은가**:
  - 60개 char = 약 30자 폭 패널에 딱 맞음 (절반 패널은 30자)
  - `deque(maxlen=N)` — 메모리 자동 제한, append만 하면 됨
  - auto-scaling (min/max 기준) — 절대값 몰라도 패턴 보임
  - 외부 의존 없음 (numpy, plotext 등)
- **제한**:
  - 8단계 양자화 = "정밀도" 부족. sudden spike/drop이 한 칸으로 표현됨
  - 음수/0 근처 변동은 `rng = max(mx - mn, 1.0)`로 division by zero 방지
  - 60자 너비 가정 — 더 좁은 패널이면 sample 30개로 줄여야 함
- **장점인 부수효과**: TUI가 **이전 값**을 보존하므로 "예전엔 잘 됐는데 지금 갑자기 떨어짐" 같은 회귀 감지에 탁월. 즉시는 못 봐도 scrolling history 느낌.

### P23. COMPACT mode — `c` 키로 FULL ↔ COMPACT 토글
- **시그널**: "한 화면에 더 많은 정보" 또는 "작은 터미널에서도 잘 보여야"라는 요구.
- **패턴**:
  ```python
  def __init__(self):
      super().__init__()
      self._compact_mode: bool = False

  def action_compact(self) -> None:
      self._compact_mode = not self._compact_mode
      self.notify(f"Mode: {'COMPACT' if self._compact_mode else 'FULL'}")
      for w in self.query(Static):
          if w.id != "hint":
              w.refresh()  # 즉시 re-render

  # 각 panel의 render()에서
  if self.app._compact_mode:
      h = (  # 한 줄 압축
          f"  CPU [#ccffdd]{cpu_pct}%[/#ccffdd]  RAM [#ccffdd]{mem_pct}%[/#ccffdd]  "
          f"PWR [#ccffdd]~{power:.0f}W[/#ccffdd]\n"
      )
      return h
  # else: full 모드 (현재 h)
  ```
- **무엇을 압축하나** (xmrig-dashboard 검증):
  - **SystemPanel**: CPU/RAM bar 제거, 3줄로 압축
  - **EarningsPanel**: daily/monthly/yearly 3줄 → 1줄
  - **LogPanel**: 8줄 → 3줄
  - **HASHRATE/POOL**: 그대로 (핵심 정보)
- **상태 표시**: 상태바에 `mode FULL` / `mode COMPACT` 박기. 사용자가 어느 모드인지 즉시 알 수 있음.
- **toggle 구현 시 주의**:
  - `self.notify()`로 토스트 알림도 같이
  - `for w in self.query(Static): w.refresh()` — 모든 panel 강제 re-render
  - modal이 열려있으면 닫기 (compact는 modal과 안 어울림)
- **확장**: `?` 키로 compact/normal/wide/extra-wide 4단계 모드도 가능. 그러나 2단계(FULL/COMPACT)가 95% 사용 케이스 커버.

### P24. Snapshot — `s` 키로 JSON dump + 진단용
- **시그널**: "지금 상태 저장해두고 나중에 비교하고 싶어" 또는 "버그 리포트에 첨부할 데이터".
- **패턴**:
  ```python
  def action_screenshot(self) -> None:
      import json
      from pathlib import Path
      snap_dir = Path.home() / ".myapp" / "snapshots"
      snap_dir.mkdir(parents=True, exist_ok=True)
      ts = datetime.now().strftime("%Y%m%d-%H%M%S")
      snap_path = snap_dir / f"snapshot-{ts}.json"
      snapshot = {
          "timestamp": ts,
          "data": dict(self.state.get("data", {})),
          "system": dict(self.state.get("system", {})),
          "history": list(self._history),  # deque → list
      }
      with snap_path.open("w") as f:
          json.dump(snapshot, f, indent=2, default=str)
      self.notify(f"Saved: {snap_path.name}")
  ```
- **장점**:
  - 사용자 이슈 보고 → "s 누르고 파일 보내주세요" 워크플로우 단순화
  - 회귀 디버깅: "어제 vs 오늘" 비교
  - 회귀 테스트: snapshot.json을 golden file로
- **파일 위치 표준화**: `~/.<appname>/snapshots/snapshot-YYYYMMDD-HHMMSS.json` → 사용자가 항상 찾을 수 있는 위치.
- **deque → list 변환 필수**: JSON은 deque 직렬화 못 함. `list(self._history)`로 변환.
- **보안**: snapshot에 PII (지갑 주소, 워커명) 들어가도 GitHub 푸시 ❌. `.gitignore`로 `snapshots/` 제외 + 사용자에게 "공유 전 PII 확인" 안내.

### P18. TUI 개발 중 프로세스 정리 패턴
- TUI를 background로 띄워 디버깅하다 보면 zombie 프로세스가 쌓임. `pkill -f "miner-dashboard"` 한 방에 정리.
- **검증용 짧은 실행 패턴** (TUI가 진짜 잘 뜨는지 확인):
  ```bash
  # 비대화형 환경에서 TUI를 8~15초 띄웠다 죽이기
  /Library/.../python3 dashboard.py > /tmp/dash.log 2>&1 &
  sleep 12
  pkill -9 -f dashboard.py
  head -30 /tmp/dash.log  # 첫 화면 확인
  ```
- **shell의 `&` vs `terminal(background=true)` 헷갈림**: 이 환경(Hermes)에서는 `nohup ... &` / `disown` 같은 shell-level backgrounding이 **막혀있음**. `terminal(background=true)`만 사용 가능. 둘 다 섞으면 runtime error.
- **TUI가 background에서 timeout 나는 게 정상**: 비대화형 터미널엔 TTY가 없어 화면 refresh 루프가 무한 → timeout. 그래도 Textual이 만든 예쁜 traceback 박스가 stdout에 찍히면 "TUI 로드 성공" 신호. 실제 TTY에서 다시 실행.
- **TUI 프로세스 죽이기**:
  ```bash
  pkill -9 -f "miner-dashboard"  # 강한 종료
  pgrep -fl "miner-dashboard" | grep -v "bash -lic"  # 살아있는지 확인
  ```
- **여러 TUI 테스트할 때 매번 정리**: 각 테스트 사이에 `pkill -9` 안 하면 port 충돌 / display 점유 / 로그 파일 lock 가능.

### P25. TUI 패딩/마진으로 답답함 해소 (2026-06-24 xmrig-dashboard 후속)
- **시그널**: "TUI 상단이 너무 딱 붙어서 답답해 보임" 같은 시각 답답함. Border는 있어도 컨텐츠가 화면 끝에 붙으면 답답해 보임.
- **최소 패딩 세트 (대부분의 TUI에 적용)**:
  ```css
  Screen { padding: 1 2; }                    /* 화면 가장자리 1행, 2칸 */
  #main { padding: 1 2; }                     /* 그리드 컨테이너 */
  StatusBar { margin: 0 2 1 2; }              /* 상태바: 좌우 2칸, 아래 1줄 (다음과 분리) */
  #hint { margin: 0 2; }                      /* 키 안내: 좌우만 */
  HashratePanel, SystemPanel, ... { padding: 1 2; }  /* panel 내부 좌우 */
  ```
- **왜 `margin: 0 2 1 2` (StatusBar)**:
  - `0` (top) — 화면 상단에 붙여서 첫 줄 강조
  - `2` (right) — 패널 그리드와 정렬
  - `1` (bottom) — **다음 줄(패널 그리드)과 시각적 분리** (이게 핵심)
  - `2` (left) — 패널 그리드와 정렬
  - StatusBar와 패널이 **딱 붙으면 답답함** → 1줄 띄우면 숨 쉴 공간 생김.
- **왜 panel `padding: 1` → `1 2`**: 상하는 1(작게), 좌우는 2(폭). 텍스트가 border에서 약간 떨어져서 가독성 ↑.
- **이게 모든 패널에 적용되는 이유**: PALETTE dict (P21)처럼 **한 CSS 블록에 정의** → 한 곳 변경으로 전체 반영. grep 불필요.
- **Screen padding 1 2의 부수 효과**: 화면 **가장자리**에 1줄 여백 → 작은 터미널(80x24)에서 컨텐츠가 화면에 다 안 들어갈 때 안전 마진. 
- **테스트는 header 잘림으로 확인**: `head -50 /tmp/dash.log`로 StatusBar와 첫 패널 사이에 빈 줄(마진) 보이는지 grep.
- **anti-패턴 — `padding: 0`**: 일부 TUI는 "최대한 많은 정보" 목적으로 `padding: 0` 쓰는데, 시각 답답함이 심함. `padding: 1 2`가 무난한 기본값.

### P26. 듀얼 sparkline — hashrate + reject 오버레이 (2026-06-24)
- **시그널**: sparkline이 "트렌드"는 잘 보여주지만 "특정 시점에 reject가 있었나"는 못 보여줌. 두 신호를 한 줄에 겹쳐서 표시.
- **패턴**: 두 개의 동기화된 deque (해상도 동일)로 한 문자열 슬롯에 **조건부 대체**:
  ```python
  history = [1200, 1180, 1190, ...]   # hashrate
  rejected = [0, 0, 0, 1, 0, 0, ...]  # reject flags (1 if rejected)

  blocks = "▁▂▃▄▅▆▇█"
  mn, mx = min(history), max(history)
  rng = max(mx - mn, 1.0)

  spark_parts = []
  for i, v in enumerate(history):
      block = blocks[min(7, int((v - mn) / rng * 7))]
      has_reject = i < len(rejected) and rejected[i] > 0
      if has_reject:
          spark_parts.append(f"[bold #ff3355]●[/bold #ff3355]")  # 빨간 dot
      else:
          spark_parts.append(f"[bold #33ff66]{block}[/bold #33ff66]")  # 녹색 block
  spark = "".join(spark_parts)
  ```
- **핵심 통찰**: 두 history는 **시간 인덱스 정렬** — `history[i]`와 `rejected[i]`가 같은 시각 샘플. 동기화만 보장하면 나머지는 단순한 `for` loop.
- **시각 의미**:
  - 클러스터링된 빨간 점 = hashrate dip과 reject가 **상관관계** (네트워크 문제 가능)
  - 산발적 빨간 점 = reject가 **독립적** (단순 운)
  - 막대 자체가 흔들리면 = hashrate 변동 큼
- **데이터 수집** (refresh_metrics에서):
  ```python
  new_accepted = new_state.get("accepted", 0)
  new_rejected = new_state.get("rejected", 0)
  old_accepted = old_xmrig.get("accepted", 0)
  old_rejected = old_xmrig.get("rejected", 0)
  accepted_delta = max(0, new_accepted - old_accepted)
  rejected_delta = max(0, new_rejected - old_rejected)
  self._accepted_history.append(accepted_delta)
  self._rejected_history.append(rejected_delta)
  ```
  **delta**만 기록 (XMRig이 cumulative count만 보여주므로). diff로 증분 계산.
- **legend**: sparkline 우측에 `(60s · reject: X.X%)` 박기. 60s는 window 길이, reject %는 같은 window의 ratio.
- **확장**: 3중 (hasrate + accept + reject dot)도 같은 패턴. 더 복잡한 차트는 TUI 너비 한계로 비추.
- **PALETTE 통합**: `error` 색 (`#ff3355`)이 reject dot, `fg` (`#33ff66`)가 hashrate block. P21 PALETTE dict가 이미 정의돼 있어 import만 하면 됨.

### P27. 고정값 + "approximate" 라벨로 외부 API 우회 (2026-06-24)
- **시그널**: 채굴/모니터링에서 "네트워크 전체 hashrate" 같은 메타데이터가 필요한데 **공식 API가 없거나 rate limit 빡빡**.
- **대안 패턴 — 모듈 상수 + "approx" 라벨**:
  ```python
  # Approximate Monero network hashrate (in H/s, used for "share of network" calc)
  # Updated manually; accurate to ~+/-15% over months. The actual value is on
  # the order of 5-6 GH/s (mid-2026). Sources: miningpoolstats.stream, coinwarz.com
  MONERO_NETWORK_HASHRATE_HPS = 5.5e9  # 5.5 GH/s — adjust quarterly

  # In panel render:
  network_share = hr_avg / MONERO_NETWORK_HASHRATE_HPS * 100
  ```
- **왜 이게 작동하나**:
  - 채굴 모니터링은 **"내 1 KH/s가 네트워크 5.5 GH/s의 몇 %?"** 같은 **컨텍스트**가 핵심
  - 정확한 숫자 (5.51 vs 5.49 GH/s)는 의미 없음 — 둘 다 "당신은 0.00002%"라는 결론
  - **사용자가 보기엔 5.5 ≈ 5.51**. CPU mining에서 점유율은 어차피 0.0001% 이하
- **표시 라벨**:
  ```
  NETWORK (5.5 GH/s approx)
  my share  0.00002%
  ```
  "approx" 라벨만 박아도 사용자가 "이건 정확도 ±15%구나" 인지. 거짓 정밀도 안 줌.
- **언제 갱신하나**:
  - **분기 1회** (3개월) — 큰 변동은 거의 없음
  - miningpoolstats.stream / coinwarz.com에서 수동 확인
  - 코드에 갱신일 주석 박기:
  ```python
  # 2026-06: 5.5 GH/s. Sources: miningpoolstats.stream
  ```
- **rate limit 있는 API로 가면**: 5분 캐시 + 24h fallback 캐시. 이 TUI는 2Hz refresh라서 5분 캐시만으로 600배 부하 감소.
- **API 있을 때 우선순위**: (1) 무료 no-auth API (있으면), (2) 고정값 + approx (없으면). 정확도보다 **안정성** 우선.

### P28. 손익분기 분석 — 전기요금 vs 채굴량 (2026-06-24)
- **시그널**: 채굴 대시보드의 진짜 질문은 "얼마 벌었나"가 아니라 **"돈이 더 들지 않나?"** — 전기요금 계산.
- **패턴 — 3개 상수로 즉시 계산**:
  ```python
  ESTIMATED_MINING_WATTS = 45          # 이 머신의 채굴 시 전력 (와트)
  POWER_COST_PER_KWH = 0.13           # 내 지역 전기요금 ($/kWh, 한국 ~$0.10, 미국 ~$0.13)
  # 24시간 동안: 45W × 24h = 1.08 kWh × $0.13 = $0.14/day

  daily_kwh = ESTIMATED_MINING_WATTS * 24 / 1000
  daily_power_cost = daily_kwh * POWER_COST_PER_KWH
  daily_net = usd_per_day - daily_power_cost

  # 색상 임계값
  if daily_net < 0:    net_str = f"[bold #ff3355]${daily_net:.4f}/day (loss)[/bold #ff3355]"
  elif daily_net < 0.01: net_str = f"[bold #ffaa00]${daily_net:.4f}/day (break-even)[/bold #ffaa00]"
  else:                net_str = f"[#33ff66]${daily_net:.4f}/day profit[/#33ff66]"
  ```
- **가치**: 채굴량만 보면 "1 KH/s = $0.04/day"로 들뜨는데, **전력 빼면 -$0.10/day**라는 사실을 즉시 확인. "이거 왜 돌리고 있지?" 자기 검증.
- **출력 형태**:
  ```
  BREAK-EVEN (45W · $0.13/kWh)
  power cost  $0.1404/day (1.08 kWh)
  net result  $0.1585/day (loss)   ← 빨강
  ```
- **임계값 가이드**:
  - 빨강: 손실 (CPU 채굴은 거의 항상 여기)
  - 앰버: 손익분기 (break-even)
  - 녹색: 수익 (전력 무료 — solar, 학교 등) — 매우 드묾
- **상수 문서화**: "한국 ~$0.10, 미국 ~$0.13" 같이 README에 박기. 사용자가 자기 값으로 조정.
- **확장**: GPU 채굴은 watts 100~300, ASIC은 1000+ — 같은 패턴에 watts만 바꾸면 됨.

### P29. 결정-포인트 brainstorm 패턴 — "둘 다 균형있게" 선호 (2026-06-24, 메모리 user 프로필 강화)
- **시그널**: "더 많은 데이터와 그래프가 추가되었으면 하는데" 같은 **방향 요청** → 사용자는 보통 **아이디어 1~2개가 아니라 메뉴**를 원함.
- **잘못된 패턴**: 10개 아이디어 한꺼번에 구현, 사용자가 "그 중 뭐 할래?" → 시간 낭비
- **올바른 패턴** (3단계):
  1. **카테고리화**: "데이터 5개 / 그래프 5개 / 특별 아이디어 5개" — 단순 목록이 아니라 **분류**
  2. **추천 5개 발췌**: 구현 우선순위 표 (가치 × 난이도) + 추천 명시
  3. **사용자 선택 받음**: `clarify` 도구로 4개 옵션 + 추천 표시
  4. **"그대로 진행" 받으면** 추천 5개로 즉시 시작
- **사용자 선호 (확인)**: "둘 다 균형있게 (추천)" 선택 + "제 추천 5개" 선택 → **밸런스 + 우선순위 큐레이션** 선호
- **anti-패턴**: "C. 2단계 건너뛰기 - 다음으로" 같은 회피 옵션을 사용자가 명시적으로 거부하지 않아도 추천 5개로 가는 게 안전
- **메모리 user 프로필에 추가된 항목**:
  - "방향 요청 받으면 brainstorm 메뉴 → 추천 N개 큐레이션 → clarify로 선택 → 즉시 실행" 4단계
  - "1개 vs 5개 vs 10개" — 기본은 5개 (너무 적으면 옵션 부족, 너무 많으면 분석 패럴리스)
- **언제 다른 패턴 쓰나**:
  - 사용자가 "X 하나만 해줘" 명시 → 추천 1개, 바로 실행
  - 사용자가 "전부 다" 명시 → 10개 다 구현, 시간 추정 먼저
  - 사용자가 "너만 결정해" → 추천안 + "바로 진행" 1-step

## 🛠️ 핵심 명령어

```bash
# venv 셋업
cd tui
uv venv .venv --python 3.11
source .venv/bin/activate
uv pip install -e ".[dev]"

# 헤드리스 스크린샷 (vision_analyze용)
python -c "
import asyncio, cairosvg
from firetoken_tui.app import FireTokenApp
from firetoken_tui.ipc import MockBackend

async def main():
    backend = MockBackend(n_sessions=5, tick_seconds=0.3, seed=42)
    app = FireTokenApp(backend)
    async with app.run_test(size=(140, 42)) as pilot:
        await pilot.pause(8.0)  # 데이터 누적
        svg = app.export_screenshot(title='fireToken TUI')
        with open('/tmp/ftui.svg', 'w') as f:
            f.write(svg)
        cairosvg.svg2png(url='/tmp/ftui.svg', write_to='/tmp/ftui.png', output_width=1400)
asyncio.run(main())
"

# 테스트
pytest -v --tb=short
```

## 📦 README 다층 옵션 (fireToken TUI 실전, 사용자 선호)

**사용자 선호 패턴** (2026-06-12 확인, 06-16 OSS/README 재확인):
- 단순 시드 1개 ❌
- **다층 옵션** ✅: 결정 4가지 + 샘플 옵션 + 직접 작성(고급) + 다단계 로드맵
- 한/영 병기 + 스크린샷 + IPC 다이어그램 + Mock 모드 설명

**README 구조 (TUI 섹션)**:
1. **빠른 시작** — `uv venv` → `pip install -e .` → `ftui --mock` 4가지 모드
2. **키바인딩** — 표 (q/s/r/p/a/c/f/?)
3. **IPC 아키텍처** — ASCII 다이어그램 (워커들 → ipc_dir → TUI)
4. **Mock 모드** — `--mock --seed 42` 시드 기반 재현
5. **스크린샷** — `![TUI](./docs/xxx.png)`

## 🔗 자매 스킬

- `python-oss-bootstrap` — 단일 OSS 부트스트랩 (이건 그 TUI + IPC + Mock 패턴의 더 큰 맥락)
- `canvas-static-site-pipeline` — 외부 플랫폼 SDK + 서버 0/API 키 0 원칙
- `agent-benchmark-tracker` — 동기화 비주얼라이제이션 (다른 시각화 도구)
- `direct-device-execution` — "직접 처리해줘" 패턴 + LaunchAgent 영구화 + Python env mismatch (P11)

## 📂 지원 파일

- `templates/live-log-dashboard.py` — 라이브 로그 파일 tailing 패턴 (XMRig 채굴 모니터링 2026-06-24 실전 검증). IPC 파일 대신 append-only 로그를 tail해서 메트릭 추출. P12 참조.
- `scripts/validate-rich-markup.py` — Rich markup 태그 짝 검증. `MarkupError: closing tag '[/X]' does not match any open tag` 디버깅할 때 한 번에 모든 색의 open/close 카운트 비교. P19 참조. `python3 scripts/validate-rich-markup.py path/to/your_tui.py [--strict]`로 실행.

## 📝 변경 이력

| 날짜 | 내용 |
|---|---|
| 2026-06-20 | v0.1.0 — fireToken TUI 실전 검증. Textual 0.89.1, Rich 15.0, 17 pytest, GitHub 푸시 완료. RLock + DataTable race + 원자적 파일 쓰기 3대 함정 문서화. |
| 2026-06-24 | v0.2.0 — XMRig 채굴 대시보드 실전. P11 (env mismatch), P12 (live log tail), P13 (비대화형 검증), P14 (CoinGecko 캐시) 추가. **P15 (빈 dict KeyError defense-in-depth) + P16 (Header/Footer markup 충돌 회피) 추가 — 4번의 디버깅 반복 끝에 도출된 핵심 학습.** `templates/live-log-dashboard.py` 전면 갱신. |
| 2026-06-24 | v0.2.1 — xmrig-dashboard 디버깅 세션 후속. **P17 (path resolution fallback chain — env var > 후보 리스트 > placeholder; main() 첫 줄에 [OK]/[NOT FOUND] stdout 출력)** + **P18 (TUI 개발 중 프로세스 정리 — `terminal(background=true)`만 허용, `nohup`/`&` shell backgrounding은 Hermes 환경에서 막힘; 비대화형 timeout이 정상)** 추가. P15/P16은 첫 디버깅 4회 반복에서 도출. |
| 2026-06-24 | v0.2.2 — xmrig-dashboard UI 개선 (NMMiner 사이버펑크 그린) 세션. **P19 (Rich markup 짝 디버깅 — `grep -c [color]` vs `[/color]` 한 번에 모든 색 카운팅, `[dim X]` vs `[/X]` 비일관성 + 동적 색상 주입 + `bold` 인라인 함정; 패치 반복 ❌, grep 한 방 ✅)** + **P20 (Textual CSS는 `animation` 미지원 — class toggle로 2초 주기 펄스 구현; `has_class`/`add_class`/`remove_class` 표준 API)** 추가. UI 6가지 요구사항 (테마/그래프/인터랙티브/시각효과/정보밀도) 모두 적용. **부수 효과: `scripts/validate-rich-markup.py` 신규 — 한 번에 모든 색의 open/close 카운트 비교 + dim 변형 별도 추적. `python3 scripts/validate-rich-markup.py your_tui.py [--strict]`.** 사용자 교정 1건: `clarify` 호출 시 4개 옵션 제시만 하고 "어떻게 갈래요?"로 끝내지 말 것, **각 옵션에 추천 박고 "그대로 진행하면 추천으로" 패턴** — 메모리 user 프로필에 기록. |
| 2026-06-24 | v0.2.3 — xmrig-dashboard UI 6가지 추가 개선 (NMMiner 사이버펑크 그린 + sparkline + compact + snapshot + 펄스 + 다국어 docs). **P21 (PALETTE dict 일원화 — 모듈 상수 + f-string 보간으로 CSS/markup 양쪽에 단일 소스, 시각 계층 6~9색 권장 매핑, 임계값별 자동 색상 전환)** + **P22 (TUI sparkline — Unicode 블록 ▁▂▃▄▅▆▇█ + `deque(maxlen=N)`로 auto-scaling 60자 폭)** + **P23 (COMPACT mode — `c` 키 toggle, render() 분기, SystemPanel/EarningsPanel/LogPanel 압축, 상태바에 `mode FULL/COMPACT` 박기)** + **P24 (Snapshot — `s` 키로 `~/.<app>/snapshots/snapshot-YYYYMMDD-HHMMSS.json` 저장, `deque → list` 변환 필수, `.gitignore`로 snapshots/ 제외)** 추가. **xmrig-dashboard 6가지 UI 요구사항 (테마 ✓ / 그래프 ✓ / 인터랙티브 ✓ / 시각효과 ✓ / 정보밀도 ✓ / sparkline ✓) 모두 적용 완료. GitHub 4 commit (88c0fb2 → cfafa45).** TUI가 단순 viewer에서 **제어 + 분석 + 진단 가능한 도구**로 진화. |
| 2026-06-24 | v0.2.4 — xmrig-dashboard 후속 (마지막 세션). **P25 (TUI 패딩/마진 답답함 해소 — `Screen padding: 1 2`, `StatusBar margin: 0 2 1 2`, `panel padding: 1 2`; StatusBar 아래 1줄 마진이 핵심)** + **P26 (듀얼 sparkline — hashrate + reject 오버레이; 두 deque 동기화, `for` loop에서 조건부 `●` 대체; 데이터 수집은 diff로 delta 계산)** + **P27 (고정값 + "approx" 라벨로 API 우회 — `MONERO_NETWORK_HASHRATE_HPS = 5.5e9`, "approx" 라벨로 거짓 정밀도 회피, 분기 1회 갱신)** + **P28 (손익분기 분석 — `ESTIMATED_MINING_WATTS` × 24h × `POWER_COST_PER_KWH`로 일일 비용; 임계값별 색상 (빨강=loss / 앰버=break-even / 녹색=profit))** + **P29 (brainstorm 4단계 패턴 — 카테고리화 → 추천 5개 큐레이션 → clarify → 즉시 실행; 사용자 선호 = 밸런스 + 우선순위 큐레이션)** 추가. 5개 추천 모두 구현 완료 (듀얼 sparkline + 네트워크 점유율 + 세션 통계 + 손익분기 — 4번은 SupportXMR API 부정확로 skip, 5번으로 대체). GitHub 3 commit 추가 (bafb33f, db1ab9e, 0947779). |
| 2026-06-24 | v0.2.5 — xmrig-dashboard TUI 화면 잘림 + c 키 크래시 디버깅. **P30 (모든 panel에 auto-adapt density mode — `try/except`로 `self.app.size.height` 체크, `< 36` 줄이면 compact 모드 자동; HashratePanel은 `self.app._compact_mode` 체크가 아예 없어서 작게 안 줄었음, 5개 panel 전부 일괄 적용; `panel padding: 0 2` (CSS)로 작은 패널이라도 컨텐츠 보임)** + **P31 (c 키 후 LogPanel crash root cause — `>[/[#1f8033]`이 Textual `from_markup`에서 `[/[#1f8033]` 통째로 잘못된 닫는 태그로 파싱, `>` 문자를 markup 바깥으로 빼서 단순 indent `  `로 대체)** + **P19 보강 (Textual의 `[/` 인접 태그 함정 — Rich는 `[/`를 닫는 태그로 해석하지만 Textual은 인접한 `[#xxx]`까지 묶어서 잘못 파싱; 두 라이브러리 간 마이크로 차이; 출력 글자 `>`, `(`, `*`는 markup 바깥에 두거나 단순 indent로 대체)** 추가. **TUI 개발 시 1 panel에서 검증된 패턴은 다른 panel에 그대로 복제 (한 panel만 짝 어긋남이 있어도 다른 panel까지 폭발)** + **P15 보강 (`/bold #XXX` 닫는 태그 + `[/XXX]` 짝 — grep 카운팅으로 한 번에 찾기 — `[/[/#1f8033]`는 명백히 1 line에 1 open / 1 close 짝이지만 2:1로 어긋남 → 1 byte 닫기 누락)** 강조. TUI 검증: `app.run_test(size=(80, 24))`로 5 panel 모두 compact 모드 22줄 안에 들어감 (HashratePanel 5 / SystemPanel 4 / PoolPanel 3 / EarningsPanel 6 / LogPanel 4). 7478be3 GitHub 커밋. |
| 2026-06-24 | v0.2.6 — xmrig-dashboard v0.2.0 "vivid visuals" 세션. **P32 (하이픈 들어간 파일명 importlib 우회 — `miner-dashboard.py`처럼 하이픈이 있으면 `import miner_dashboard` ❌; `importlib.util.spec_from_file_location("miner_dashboard", SCRIPT)` + `assert spec is not None and spec.loader is not None` + `spec.loader.exec_module(mod)`로 load; `assert`가 Pyright type narrowing을 만족시켜서 `[reportArgumentType]`/`[reportOptionalMemberAccess]` 경고 제거)** + **P33 (Pure function helper 분리 → 단위 테스트 가능 — `render_donut/heatmap/bars/forecast/logo` 모두 `self`/state 없이 입력만 받아 Rich markup 문자열 반환; widget은 helper 호출만, 테스트는 widget 없이 helper만 검증; 회귀 보호 + 재사용성 ↑)** + **P34 (시간 기반 accumulator + 24h rollover — `if now - self._last_accrual > 60: append_slice`; 마지막 entry가 "오늘", 24h 지나면 새 entry push + cap N개; 첫 1-2주는 비어있어 "데이터 아직 없음" placeholder 필수 — Sun 함정 학습과 동일 원칙: 데이터 ≠ 표시)** + **P35 (Textual widget render() 단독 검증 — `app`은 read-only property (`AttributeError: property 'app' of 'X' object has no setter`); `class MockSB(StatusBar): @property def app(self): return fake_app`로 subclass 후 `sb.render()` 직접 호출; Rich markup 결과 단독 검증 — 비대화형에서도 OK, `app.run_test()` 없이 빠르게)** + **P36 (ASCII 도넛 4행 + 라벨 인라인 — 4×4 셀 패턴 (top/upper-mid/lower-mid/bottom), `▄██▀` / `█░░█` / `█░░█` / `▀██▄ 95% acc`; 라벨을 4번째 행 끝에 inline으로 붙여 `lines.split("\n")`이 항상 4; 임계치별 색상 전환 95% green / 90% amber / 중립 fg)** + **P37 (viz threshold 자동 색상 — `accepted/total` 95%↑=green / 90%↓=amber / 중립=fg; 단순 bool이 아닌 threshold 기반 그라데이션 — 사용자가 "대부분 OK vs 가끔 reject"를 한눈에 구분)** 추가. **v0.2.0 통합 효과: 5개 viz helper + 새 HEATMAP panel + 6 panel 그리드 + g 토글 + ASCII 로고 헤더 + 20 pytest 추가 → 한 PR에 다 묶어 푸시 (commit 384137a, tag v0.2.0)**. TUI가 단순 viewer에서 **시각화/제어/분석/회귀보호** 가능한 도구로 진화. **`templates/vivid-viz-helpers.py` 신규 — 5개 helper (donut/heatmap/bars/forecast/logo) 복붙용 템플릿, 다른 TUI에 그대로 이식 가능**. |