---
name: textual-tui-development
description: Textual 기반 Python TUI 개발 전체 워크플로 — 앱 설계(Grid/Footer/Header), 위젯 3종(SummaryPanel + DataTable + RichLog), 멀티 백엔드 ABC 패턴(FileSystem + Mock), Pilot 헤드리스 테스트, SVG/PNG 스크린샷, pytest 17개 통합. fireToken TUI 실전 검증 (textual 0.89, rich 15). "Textual TUI 만들어줘", "터미널 모니터링 대시보드", "Python CUI 앱", "실시간 상태 뷰어 + 키바인딩 제어" 같은 요청에 발동. python-oss-bootstrap이 단일 OSS 부트스트랩이라면, 이 스킬은 TUI 클래스 전체의 설계/구현/검증/푸시 통합.
---

# Textual TUI 개발 워크플로

> **호칭:** "희정님" (한글 통일, 한자 사용 금지) — 모든 산출물/로그/크론 출력에 한글 호칭만 사용

## 핵심 결정 포인트 (4가지)

TUI 작업 받으면 브레인스토밍으로 먼저 정리. python-oss-bootstrap / canvas-static-site-pipeline의 결정 패턴과 동일.

| # | 결정 | 옵션 | 추천 |
|---|---|---|---|
| 1 | **TUI 범위** | A 뷰어(모니터링) / B 컨트롤러(제어+뷰) / C 풀 리팩터 | **B** — 기존 자산 보존, IPC로 제어 |
| 2 | **라이브러리** | ① Rich+prompt_toolkit / ② Textual / ③ curses | **②** — async+위젯+CSS에 최적 |
| 3 | **백엔드 연동** | ① JSON 폴링 / ② JSONL tail / ③ subprocess / **①+② 하이브리드** | **하이브리드** |
| 4 | **배포 형태** | α CLI 단독 / β repo 서브폴더 / γ 별도 repo | **β** — 기존 repo에 tui/ |

→ "그대로 진행" 받으면 추천안으로 즉시 실행.

## 8단계 워크플로

### 1단계: 기존 워커 분석
- PS1/Go/Rust/어떤 백엔드든 IPC 계약이 어떻게 되는지 파악
- 핵심 인터페이스: 시작/정지 명령, 상태 출력 위치, 이벤트 스트림 위치
- 예: fireToken → `burn.ps1`(오케스트레이터) + `burn-session.ps1`(워커) + `.stop` 파일

### 2단계: IPC 모듈 작성 (백엔드 측)
원자적 파일 쓰기 + 명시적 ACK 패턴:

```python
# PowerShell 측
$tmpFile = "$StateFile.tmp"
Set-Content -Path $tmpFile -Value $json -Encoding UTF8 -NoNewline
Move-Item -Path $tmpFile -Destination $StateFile -Force  # atomic rename
```

```python
# Python 측 (FileSystemBackend.send_command)
with tempfile.NamedTemporaryFile(mode="w", delete=False, dir=str(self._dir), prefix="cmd.", suffix=".tmp") as tmp:
    json.dump(cmd, tmp)
    tmp_path = tmp.name
os.replace(tmp_path, cmd_path)  # atomic
```

### 3단계: Python 패키지 구조
```
tui/
├── pyproject.toml          # textual/rich, console_scripts=[ftui=...:main]
├── README.md               # 한/영 병기 + 다층 옵션
├── firetoken_tui/
│   ├── __init__.py
│   ├── app.py              # Textual App + main() CLI entry
│   ├── ipc/
│   │   ├── __init__.py
│   │   ├── backend.py      # Backend ABC, SessionState, Event, CommandResult
│   │   ├── fs_backend.py   # 실제 파일 IPC
│   │   └── mock_backend.py # 시뮬레이션 (macOS/Linux 개발용)
│   └── widgets/
│       ├── __init__.py
│       ├── summary_panel.py
│       ├── session_table.py
│       └── event_log.py
└── tests/
    ├── test_backend.py
    └── test_app.py
```

### 4단계: Backend ABC + Mock 패턴
- **FileSystemBackend**: 실제 PS1 IPC (Windows 운영용)
- **MockBackend**: macOS/Linux 개발 + 데모용 (5세션 시뮬레이션, RLock 워커)
- **자동 디텍션**: 환경변수 → 표준 경로 → 폴백(Mock)

```python
class Backend(abc.ABC):
    @abc.abstractmethod
    def get_session(self, session_id: int) -> SessionState | None: ...
    @abc.abstractmethod
    def list_sessions(self) -> dict[int, SessionState]: ...
    @abc.abstractmethod
    def tail_events(self, since_byte: int = 0) -> tuple[list[Event], int]: ...
    @abc.abstractmethod
    def send_command(self, action: str, value: str | None = None) -> CommandResult: ...
    @abc.abstractmethod
    def is_connected(self) -> bool: ...
    @abc.abstractmethod
    def ipc_dir(self) -> str: ...
```

### 5단계: Textual App (Grid + Footer + 1초 폴링)
```python
class FireTokenApp(App):
    CSS = """
    Screen { layout: vertical; }
    #summary { height: 4; padding: 0 1; background: $boost; border-bottom: solid $primary; }
    #main { height: 1fr; layout: vertical; }
    #sessions { height: 40%; min-height: 8; border-bottom: solid $primary; }
    #events { height: 60%; min-height: 10; }
    """
    BINDINGS = [
        Binding("q", "quit", "Quit", priority=True),
        Binding("s", "stop_all", "Stop"),
        Binding("r", "cycle_reasoning", "Reasoning"),
        # ...
    ]
    
    def on_mount(self) -> None:
        self.set_interval(1.0, self._tick)  # 1초마다 폴링
    
    def _tick(self) -> None:
        sessions = self.backend.list_sessions()
        events, new_offset = self.backend.tail_events(self._event_byte_offset)
        # ...
```

### 6단계: 3대 위젯

**SummaryPanel** (헤더 KPI):
- reactive: total_tokens, total_rounds, sessions_active, tps
- render(): Text 한 줄에 KPI 6개 색상화

**SessionTable** (DataTable):
- 12컬럼: ID, PID, Status, Round, Last, Total, Reason, Output, Err, Ctx, Msgs, Updated
- Status 색상 (running=green, retrying=yellow, error=red)
- Updated 신선도 (0~3s=green, 3~10s=yellow, 10s+=red)
- ⚠️ **DataTable DuplicateKey race 함정** — 아래 Pitfalls 참조

**EventLog** (RichLog):
- append-only, wrap=False (줄바꿈 방지)
- truncate 길이 80자 (긴 kv는 `...` 처리)
- _STYLE_BY_TYPE로 이벤트 타입별 색상

### 7단계: pytest 통합
- 백엔드 15개 (SessionState, Event, MockBackend, FileSystemBackend, edge cases)
- Textual 앱 2개 (Pilot 헤드리스 smoke test, 키바인딩 cycle)
- **RLock 데드락 함정** — 아래 Pitfalls 참조

```python
@pytest.mark.asyncio
async def test_textual_app_renders_with_mock() -> None:
    backend = MockBackend(n_sessions=3, tick_seconds=0.3, seed=1)
    app = FireTokenApp(backend)
    async with app.run_test(size=(120, 40)) as pilot:
        await pilot.pause(0.3)
        assert app.is_running
        assert app.query("SummaryPanel")
        # ...
```

### 8단계: 헤드리스 스크린샷 + 시각 검증
- `app.export_screenshot()` → SVG → `cairosvg.svg2png` → vision_analyze
- 8초+ 누적 후 캡처 (round ≥ 20, total ≥ 100K)
- vision이 8/10+ 나올 때까지 헤더/테이블/로그 비율 조정

## ⚠️ Pitfalls (실전 검증, 2026-06-20 fireToken TUI)

### P1. MockBackend RLock 데드락 (최우선)
- `MockBackend._run`이 `with self._lock:` 잡은 채로 `self._emit_event(...)` 호출
- `_emit_event`도 `with self._lock:` → 일반 `Lock`이면 데드락
- **해결**: `threading.RLock()` (재진입 가능) 사용
- **증상**: `MockBackend()` 생성은 OK, `send_command` 호출 시 영원히 hang
- **진단**: `python -u -c "...send_command('stop')..."` 후 `faulthandler.dump_traceback_later(timeout=3)`로 스레드 덤프

### P2. DataTable DuplicateKey race
- `update_cell`로 기존 row 업데이트 시도 → `KeyError` (row 없음) → except에서 `add_row` → 이미 다른 tick에서 추가됐으면 `DuplicateKey`
- **해결**: `if row_key not in self._last_states: try add_row except DuplicateKey: pass else: update_cell` 패턴
- **왜 `_last_states`로 판단하나**: `self._row_keys()` 같은 메서드는 textual 버전마다 다름. dict 기반 체크가 안정적.

### P3. 원자적 파일 쓰기 필수
- PowerShell과 Python 양쪽 다 같은 디렉토리에 쓸 때 `Set-Content` + `Move-Item` 또는 `tempfile.NamedTemporaryFile` + `os.replace` 패턴
- 일반 `open(path, 'w')`는 Windows에서 부분 쓰기 노출

### P4. venv 분리 (PEP 668 회피)
- macOS 시스템 Python은 PEP 668이라 `pip install` 불가
- `uv venv .venv --python 3.11` → `source .venv/bin/activate` → `uv pip install -e ".[dev]"`
- `console_scripts` 등록으로 `ftui` 한 방 실행

### P5. f-string 마스킹 (Bearer 외)
- TUI 코드에 secret 직접 삽입 시 `***` 마스킹이 문자열 깨뜨려 SyntaxError 가능
- `os.path.expanduser("~/.hermes/secrets/...")` + `open().read().strip()` 패턴

### P6. RichLog wrap=False
- 기본 wrap=True면 한 이벤트가 2줄로 깨져서 가독성↓
- `wrap=False` + `kv[:80] + "..."` truncate 조합이 한 줄 = 한 이벤트

### P7. `_default_ipc_dir()` 디텍션 우선순위
- `$FIRETOKEN_IPC_DIR` 환경변수 → Windows `$TEMP/fireToken-ipc` → Linux `/tmp/fireToken-ipc` → Mock 폴백
- 환경변수 체크를 첫 번째에 두면 사용자가 명시 제어 가능

### P8. `_format_age` 색상 임계치
- 단순 숫자 표시 대신 색상으로 신선도 전달
- 0~3s=green / 3~10s=yellow / 10s+=red bold
- Mock에서 1초 tick이면 0s만 보이지만 운영에서 5+ 초 stall 감지에 유용

### P9. Pilot `size=(W, H)` 명시
- 기본 80x24는 너무 작아서 스크린샷이 잘림
- `size=(140, 40)` 또는 `(120, 40)` 권장 — vision_analyze용

### P10. `--mock --seed` 결정론
- 회귀 테스트 시 `--seed 42`로 시드 고정
- 안 그러면 mock 데이터가 매번 달라져서 스크린샷 비교 불가

## 🛠️ 핵심 명령어

```bash
# venv 셋업
cd tui
uv venv .venv --python 3.11
source .venv/bin/activate
uv pip install -e ".[dev]"

# 헤드리스 스크린샷 (vision_analyze용)
python -c "
import asyncio, cairosvg
from firetoken_tui.app import FireTokenApp
from firetoken_tui.ipc import MockBackend

async def main():
    backend = MockBackend(n_sessions=5, tick_seconds=0.3, seed=42)
    app = FireTokenApp(backend)
    async with app.run_test(size=(140, 42)) as pilot:
        await pilot.pause(8.0)  # 데이터 누적
        svg = app.export_screenshot(title='fireToken TUI')
        with open('/tmp/ftui.svg', 'w') as f:
            f.write(svg)
        cairosvg.svg2png(url='/tmp/ftui.svg', write_to='/tmp/ftui.png', output_width=1400)
asyncio.run(main())
"

# 테스트
pytest -v --tb=short
```

## 📦 README 다층 옵션 (fireToken TUI 실전, 사용자 선호)

**사용자 선호 패턴** (2026-06-12 확인, 06-16 OSS/README 재확인):
- 단순 시드 1개 ❌
- **다층 옵션** ✅: 결정 4가지 + 샘플 옵션 + 직접 작성(고급) + 다단계 로드맵
- 한/영 병기 + 스크린샷 + IPC 다이어그램 + Mock 모드 설명

**README 구조 (TUI 섹션)**:
1. **빠른 시작** — `uv venv` → `pip install -e .` → `ftui --mock` 4가지 모드
2. **키바인딩** — 표 (q/s/r/p/a/c/f/?)
3. **IPC 아키텍처** — ASCII 다이어그램 (워커들 → ipc_dir → TUI)
4. **Mock 모드** — `--mock --seed 42` 시드 기반 재현
5. **스크린샷** — `![TUI](./docs/xxx.png)`

## 🔗 자매 스킬

- `python-oss-bootstrap` — 단일 OSS 부트스트랩 (이건 그 TUI + IPC + Mock 패턴의 더 큰 맥락)
- `canvas-static-site-pipeline` — 외부 플랫폼 SDK + 서버 0/API 키 0 원칙
- `agent-benchmark-tracker` — 동기화 비주얼라이제이션 (다른 시각화 도구)

## 📝 변경 이력

| 날짜 | 내용 |
|---|---|
| 2026-06-20 | v0.1.0 — fireToken TUI 실전 검증. Textual 0.89.1, Rich 15.0, 17 pytest, GitHub 푸시 완료. RLock + DataTable race + 원자적 파일 쓰기 3대 함정 문서화. |
