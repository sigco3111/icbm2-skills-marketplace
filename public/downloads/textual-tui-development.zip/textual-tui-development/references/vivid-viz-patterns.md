# v0.2.0 "Vivid Visuals" 학습 노트 (xmrig-dashboard 2026-06-24)

xmrig-dashboard v0.2.0 풀세트 작업에서 도출된 **시각화 + 회귀 보호** 패턴.
SKILL.md 본문의 P32–P37 (다음 패치에서 추가 예정)의 풀 버전 + 실제 코드 예시.

## P32. 하이픈 들어간 파일명 importlib 우회

xmrig-dashboard는 `miner-dashboard.py` (하이픈) 단일 파일. 기존 사용자가
`python3 miner-dashboard.py`로 직접 실행하지만, helper를 단위 테스트하려면
import 필요. `import miner_dashboard`는 `ModuleNotFoundError` → importlib 우회.

```python
# tests/test_visual.py
import importlib.util
import pathlib

ROOT = pathlib.Path(__file__).resolve().parent.parent
SCRIPT = ROOT / "miner-dashboard.py"
spec = importlib.util.spec_from_file_location("miner_dashboard", SCRIPT)
assert spec is not None and spec.loader is not None
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
```

**핵심 트릭 — `assert spec is not None and spec.loader is not None`**:
- Pyright는 `spec`을 `ModuleSpec | None`으로 추론
- `mod = module_from_spec(spec)`이 `[reportArgumentType]` 경고
- `spec.loader.exec_module(mod)`이 `[reportOptionalMemberAccess]` 경고
- `assert`가 narrowing을 만족시켜서 경고 제거 + 실제 None이면 즉시 fail

**대안 비교**:
| 방법 | 단점 |
|---|---|
| `runpy.run_path("script.py")` | `__name__ == "__main__"` 가드 실행 → TUI 진입 시도 |
| `subprocess` + JSON | helper 직렬화/역직렬화 overhead |
| 파일 rename `miner_dashboard.py` | backward compat 깨짐 (`python3 miner-dashboard.py` 명령 망가짐) |
| **importlib.spec_from_file_location** ✅ | 위 트릭으로 깔끔, 0.01초 로드 |

## P33. Pure function helper 분리 (architecture 핵심)

**문제**: widget 안에 인라인으로 viz 로직 박으면 단위 테스트 어려움.

**해결 — helper는 순수, widget은 호출만**:

```python
# ---------- Visualization helpers (v0.2.0) ----------
# All helpers are pure functions: they take primitive inputs and return
# Rich-markup strings. This keeps them unit-testable without spinning up
# the Textual app.

def render_donut(accepted: int, rejected: int) -> str:
    """Returns Rich markup. No self, no app state, no side effects."""
    total = accepted + rejected
    if total == 0:
        return f"[{PALETTE['fg_dim']}](no shares yet)[/{PALETTE['fg_dim']}]"
    # ... 계산 + markup 반환 ...


def render_core_heatmap(per_core_now: list, history: list, width: int = 12) -> str:
    """Heatmap, returns Rich markup. history is list of per-core snapshots."""
    if not history or not per_core_now:
        return f"[{PALETTE['fg_dim']}](no core samples yet)[/{PALETTE['fg_dim']}]"
    # ...


# ---------- TUI Widgets ----------
class CoreHeatmapPanel(Static):
    def render(self) -> str:
        history = list(self.app._core_history)  # widget state
        per_core_now = history[-1] if history else []
        return render_core_heatmap(per_core_now, history, width=12)  # helper 호출만
```

**이게 작동하는 이유**:
- **테스트 가능**: importlib (P32) + 5 helper × 4-5 test = 20 pytest, 0.5초 안에 100% 통과
- **위젯 단순화**: render()는 `self.app._state` + `render_X(...)` 호출만
- **이식 가능**: helper는 widget에 의존 안 함 → 다른 TUI에 그대로 복붙
- **회귀 안전**: helper 깨지면 widget 자동 깨짐 → 테스트가 빨리 잡음

**helper 시그니처 규약**:
- 입력: `int`, `float`, `list`, `str` (primitive + Path 정도)
- 출력: `str` (Rich markup) 또는 `list[str]` (multi-line)
- 부수효과: ❌ (print, file write, network 절대 ❌)
- 예외: `ValueError`만 (silent fallback ❌)

## P34. 시간 기반 accumulator + 24h rollover

"지난 7일 일별 수익 막대그래프" — 시간 누적 데이터. 첫 실행 시엔 비어있음 (Sun 함정 학습).

```python
self._daily_earnings: list = []  # oldest first
self._last_accrual: float = time.time()

def refresh_metrics(self):
    now = time.time()
    if now - self._last_accrual > 60:  # 1분마다
        usd_per_hour = hr_avg / 1000 * 0.0008 * price
        if usd_per_hour > 0:
            usd_per_minute = usd_per_hour / 60
            if self._daily_earnings:
                self._daily_earnings[-1] += usd_per_minute  # 오늘 누적
            else:
                self._daily_earnings.append(usd_per_minute)
            # 24h rollover
            if now - self._last_accrual > 86400:
                self._daily_earnings.append(0.0)
                if len(self._daily_earnings) > 14:
                    self._daily_earnings = self._daily_earnings[-14:]  # cap
        self._last_accrual = now
```

**디자인 결정 4가지**:
1. **누적 주기 60초** — 너무 짧으면 노이즈, 너무 길면 1분 단위 손실
2. **마지막 entry = "오늘"** — 새 entry 안 만들고 기존 entry에 += (1시간 = 1 entry)
3. **24h rollover** — `now - last_accrual > 86400`은 정확히 24h는 아님 (실제 ~24h + 60s) — OK
4. **cap 14** — `[-14:]` 슬라이스. 메모리 무한 증가 방지

**Placeholder 필수 (Sun 함정 재확인)**:

```python
if not daily_usd or all(v <= 0 for v in daily_usd):
    return (
        f"[{PALETTE['fg_dim']}]no data yet — chart fills in as the"
        f"[/{PALETTE['fg_dim']}]\n"
        f"[{PALETTE['fg_dim']}]dashboard runs each day[/{PALETTE['fg_dim']}]"
    )
```

"데이터가 있으니 다 보여주자" ❌. 첫 1-2주는 비어있어 → placeholder 텍스트 필수.

**확장 가능한 사용 케이스**:
- 세션 통계 (current session shares) — 60s 누적 + 24h rollover
- 코어 평균 로드 (last hour) — 60s 누적 + 60 슬라이딩 윈도우
- 네트워크 latency (last 24h) — 5분 누적 + 288 entry cap

## P35. Textual widget render() 단독 검증 (subclass @property)

Helper는 P33로 단위 테스트 가능. 하지만 **widget의 `render()`는 `self.app` 필요** —
비대화형에서 어떻게 검증?

```python
# test
app = m.MinerDashboard()
app.state['xmrig'] = {'pool_connected': True, 'hashrate_10s': 1234.0, ...}

class MockSB(m.StatusBar):
    @property
    def app(self):
        return app  # 가짜 app 주입

sb = MockSB()
out = sb.render()  # Rich markup 반환
assert "MINING" in out
```

**왜 `app`을 setattr로 못 바꾸나**: Textual의 `app`은 metaclass에서 `App.COMPOSED_APP`으로
property 정의 — `AttributeError: property 'app' of 'X' object has no setter`.
`monkey-patch.setattr`도 안 먹힘. **subclass `@property`가 유일한 우회**.

**검증 범위**:
- `app.state["xmrig"]["pool_connected"]` → widget이 어떤 색/문자열 쓰는지
- helper 호출 결과 (donut, heatmap)가 widget에 잘 wrap되는지
- compact 모드 분기 (`app._compact_mode = True`로 toggle)
- `g` 토글 후 (`app._show_graphs = False`로 widget "hidden" 출력)

**vs `app.run_test()`**:
| 방법 | 속도 | 의존성 | 검증 범위 |
|---|---|---|---|
| `app.run_test(size=(80,24))` + `await pilot.pause(0.3)` | 2초+ | pytest-asyncio | 위젯 layout / 키바인딩 |
| **subclass @property mock** ✅ | 0.01초 | 없음 | render() 결과 (markup) |

**fallback — strip markup**:
```python
out = sb.render()
out = re.sub(r'\[/?[^]]+\]', '', out)  # 색상 토큰 제거
assert "MINING" in out  # plain text 비교
```
TUI 시각 효과 (색상, 펄스)는 unit test로 검증 어려우므로 plain text만 확인.

## P36. ASCII 도넛 — 4행 인라인 라벨

그래프 라이브러리 없이 수락/거부 비율 도넛.

```python
def render_donut(accepted: int, rejected: int) -> str:
    total = accepted + rejected
    if total == 0:
        return f"[{PALETTE['fg_dim']}](no shares yet)[/{PALETTE['fg_dim']}]"
    pct = accepted / total
    # 3-tier threshold (P37)
    if pct > 0.95:
        ring_color, hole_color = PALETTE["fg"], PALETTE["fg_faint"]
        label = f"[bold {PALETTE['highlight']}]{pct*100:.0f}%[/bold {PALETTE['highlight']}] acc"
    elif pct < 0.90:
        ring_color, hole_color = PALETTE["warning"], PALETTE["fg_faint"]
        label = f"[bold {PALETTE['warning']}]{pct*100:.1f}%[/bold {PALETTE['warning']}] acc"
    else:
        ring_color, hole_color = PALETTE["fg"], PALETTE["fg_faint"]
        label = f"[bold {PALETTE['highlight']}]{pct*100:.1f}%[/bold {PALETTE['highlight']}] acc"
    # 4×4 셀 + 라벨 inline
    rows = [
        f"[{ring_color}]▄[/{ring_color}][{hole_color}]██[/{hole_color}][{ring_color}]▀[/{ring_color}]",
        f"[{ring_color}]█[/{ring_color}][{hole_color}]░░[/{hole_color}][{ring_color}]█[/{ring_color}]",
        f"[{ring_color}]█[/{ring_color}][{hole_color}]░░[/{hole_color}][{ring_color}]█[/{ring_color}]",
        f"[{ring_color}]▀[/{ring_color}][{hole_color}]██[/{hole_color}][{ring_color}]▄[/{ring_color}] {label}",
    ]
    return "\n".join(rows)  # 정확히 4행
```

**디자인 결정 3가지**:
1. **4행 구조 고정** — widget panel 안에 4행 + 라벨 = 5행. compact 모드 충돌 없음
2. **라벨을 4번째 행 끝에 inline** — 별도 5행 ❌. `lines.split("\n")`이 항상 4 (테스트하기 쉬움)
3. **hole 2×2** — 가운데 2x2는 `░░` + `██` (fg_faint). ring은 `▄█▀`로 top/bottom arc 표현

**시각 의미**:
- 100% (pct=1.0) → "100% acc" bold highlight
- 90-95% → "92.3% acc" highlight (정상)
- < 90% → amber "87.5% acc" (reject 좀 있음)

**다른 viz로 확장**:
- **파이 4-segment** — donut을 4분할로
- **반원** — 4행 중 2행만 ring
- **게이지** — donut 4행 + 우측에 큰 숫자

## P37. 임계치 기반 viz 색상 그라데이션

**3-tier threshold** 패턴 — 단순 on/off (2-tier)보다 정보량 ↑, 4+ tier는 너무 산만.

```python
pct = accepted / total
if pct > 0.95:           # 거의 완벽
    color = PALETTE["fg"]  # green
elif pct < 0.90:         # reject 좀 있음
    color = PALETTE["warning"]  # amber
else:                   # 정상 범위
    color = PALETTE["fg"]
```

**threshold 값 가이드** (도메인별):

| 메트릭 | green | amber | red |
|---|---|---|---|
| 채굴 수락률 | 95%+ | 90-95% | <90% |
| CPU 온도 | <70°C | 70-85°C | 85°C+ |
| 메모리 사용률 | <50% | 50-80% | 80%+ |
| staleness | <10분 | 10-30분 | 30분+ |
| 코어 부하 | <70% | 70-90% | 90%+ |

**연속값 그라데이션 (heatmap)**:
```python
if pct < 5:    ch, color = " ", PALETTE["fg_faint"]
elif pct < 40: ch, color = "░", PALETTE["fg_dim"]
elif pct < 75: ch, color = "▒", PALETTE["fg"]
else:          ch, color = "▓", PALETTE["accent"]
```
4단계: cold / dim / medium / hot. 셀 강도 + 색상 둘 다 변화.

**anti-패턴**:
- ❌ `random.choice([PALETTE["fg"], PALETTE["warning"]])` — 같은 입력에 다른 출력 (비결정론)
- ❌ 5+ tier — 신호 vs 노이즈 경계 모호

## v0.2.0 통합 워크플로 (한 PR에 묶기)

xmrig-dashboard v0.2.0 = `vivid visuals` 풀세트, 단일 commit 384137a + tag v0.2.0:

| # | 작업 | 함정 |
|---|---|---|
| 1 | 5개 helper 추가 (P33) | pure function 시그니처 규약 |
| 2 | `CoreHeatmapPanel` 신규 (6번째 panel) | grid 2x3 = 6, hint Static을 Container 밖으로 |
| 3 | `SystemPanel`에 per-core bars | `psutil.cpu_percent(percpu=True, interval=None)`로 deltas |
| 4 | `EarningsPanel`에 donut + forecast | placeholder (P34) |
| 5 | `StatusBar`에 ASCII logo + badge | `render_header_logo` helper |
| 6 | `g` 토글 binding + `action_toggle_graphs` | hidden 상태 session 동안 유지 |
| 7 | `tests/test_visual.py` (P32 + P33 + P35) | importlib + helper 단독 + widget subclass |
| 8 | README "What's new in v0.2.0" 섹션 | 다층 옵션 (사용자 선호) |
| 9 | commit + push + tag v0.2.0 | 단일 commit, 모든 변경 한 번에 |

**작업 시간**: 30~50분 (P33 helper + P32 importlib + P35 widget mock이 시간을 단축시킴 — 다른 viz도 helper 패턴이라 1시간 안에 6개 viz 추가 가능).

## v0.2.0 호환성 체크리스트

v0.1.0 자산이 v0.2.0에서도 깨지지 않음을 보장:

- [x] BINDINGS: `p/r/q/?/c/s` + 추가 `g` (7개)
- [x] CSS: 펄스 effect (`-pulse-bright`) 보존
- [x] v0.1.0 panels: HashratePanel/SystemPanel/PoolPanel/EarningsPanel/LogPanel 그대로 + 확장
- [x] v0.1.0 key: `g`만 신규, 나머지 동일
- [x] Python 3.8+ 호환 (walrus/match 없음, `assert` 사용 OK)
- [x] PALETTE dict (P21) 그대로 — 새 viz도 PALETTE lookup

**v0.2.0 회귀 보호**: 20 pytest 통과 + 1 importlib + 5 helper + 6 widget subclass mock = 12+ 케이스.

## 다른 TUI에 이식 시 체크리스트

새 TUI에 vivid visuals 추가할 때:

- [ ] PALETTE dict 정의 (P21) — 없으면 viz 색상이 일관성 없음
- [ ] 5개 helper 복붙 (P33) — `templates/vivid-viz-helpers.py`
- [ ] `importlib` 테스트 패턴 (P32) — 파일명에 하이픈 있으면
- [ ] 24h accumulator (P34) — 시계열 막대그래프
- [ ] 3-tier threshold (P37) — 단순 on/off 대신
- [ ] `g` 토글 (이식 시) — viz on/off 키
- [ ] placeholder (P34 + Sun 함정) — 데이터 없을 때 빈 viz ❌
- [ ] README "What's new" 섹션 (다층 옵션) — 사용자 선호
