#!/usr/bin/env python3
"""
Validate Rich markup tag balance in a Python file.

Use this when you get a MarkupError like "closing tag '[/X]' does not
match any open tag" in a Textual TUI. It counts open/close pairs for
all colors and dim/bold variants in one pass, and reports imbalances.

P19 reference: textual-tui-development skill (P19 = markup 짝 디버깅 워크플로).

Usage:
    python3 scripts/validate-rich-markup.py path/to/your_tui.py
    python3 scripts/validate-rich-markup.py path/to/your_tui.py --strict
        # --strict: also checks [dim X] is closed with [/dim X] (not [/X])
"""
from __future__ import annotations

import re
import sys
from collections import Counter
from pathlib import Path


def _extract_colors(line: str) -> tuple[Counter, Counter, Counter, Counter]:
    """Return (bold_opens, dim_opens, plain_opens, plain_closes) for one line."""
    bold_opens = Counter()
    dim_opens = Counter()
    plain_opens = Counter()
    plain_closes = Counter()

    # [bold #XXXXXX]  -> bold
    # [dim #XXXXXX]   -> dim
    # [#XXXXXX]       -> plain
    # [/#XXXXXX]      -> plain close
    # [/bold #XXXXXX] -> bold close (rare)
    # [/dim #XXXXXX]  -> dim close

    for m in re.finditer(r"\[bold #([0-9a-fA-F]{6})\]", line):
        bold_opens[m.group(1).lower()] += 1
    for m in re.finditer(r"\[dim #([0-9a-fA-F]{6})\]", line):
        dim_opens[m.group(1).lower()] += 1
    for m in re.finditer(r"\[#([0-9a-fA-F]{6})\]", line):
        plain_opens[m.group(1).lower()] += 1
    for m in re.finditer(r"\[/#([0-9a-fA-F]{6})\]", line):
        plain_closes[m.group(1).lower()] += 1
    return bold_opens, dim_opens, plain_opens, plain_closes


def main() -> int:
    if len(sys.argv) < 2:
        print(__doc__)
        return 2

    target = Path(sys.argv[1])
    strict = "--strict" in sys.argv
    if not target.exists():
        print(f"ERROR: {target} not found", file=sys.stderr)
        return 2

    print(f"Validating Rich markup in {target}...")
    print(f"Strict mode: {strict}")
    print()

    total_bold_opens: Counter = Counter()
    total_dim_opens: Counter = Counter()
    total_plain_opens: Counter = Counter()
    total_plain_closes: Counter = Counter()

    with target.open("r", encoding="utf-8") as f:
        for line_no, line in enumerate(f, start=1):
            b, d, po, pc = _extract_colors(line)
            total_bold_opens += b
            total_dim_opens += d
            total_plain_opens += po
            total_plain_closes += pc

    print(f"{'color':<10} {'plain_open':>10} {'plain_close':>12} {'dim_open':>10} {'bold_open':>10} {'delta':>8}")
    print("-" * 60)
    all_colors = set(total_plain_opens) | set(total_plain_closes) | set(total_dim_opens) | set(total_bold_opens)
    issues_found = False

    for color in sorted(all_colors):
        plain_open = total_plain_opens[color]
        plain_close = total_plain_closes[color]
        dim_open = total_dim_opens[color]
        bold_open = total_bold_opens[color]
        # Treat [bold X] as also opening a plain tag chain
        # Treat [dim X] as opening a tag that should be closed with [/dim X]
        # In strict mode, dim_close = plain_close; in lax mode, dim_close = 0
        if strict:
            # [dim X] requires [/dim X] specifically — but we didn't count dim closes
            # So in strict mode, dim_open must equal 0 (no dim usage without matching close)
            dim_close = 0
        else:
            dim_close = 0
        # Total opens: plain + bold + dim
        # Total closes: plain + dim_close
        total_opens = plain_open + bold_open + dim_open
        total_closes = plain_close + dim_close
        delta = total_opens - total_closes
        marker = " OK" if delta == 0 else " ❌"
        if delta != 0:
            issues_found = True
        print(f"#{color:<9} {plain_open:>10} {plain_close:>12} {dim_open:>10} {bold_open:>10} {delta:>+8}{marker}")

    print()
    if strict:
        dim_total = sum(total_dim_opens.values())
        if dim_total > 0:
            print(f"NOTE: strict mode — {dim_total} [dim X] tags found.")
            print("  Make sure each is closed with [/dim X], not [/X] or [/#X].")

    if issues_found:
        print("❌ Some color tags are unbalanced. Run a search for:")
        print('   grep -n "\\\\[color" file.py')
        print("Then look for inconsistent close forms (e.g. [/X] vs [/dim X]).")
        return 1
    else:
        print("✅ All color tags balance.")
        return 0


if __name__ == "__main__":
    sys.exit(main())
