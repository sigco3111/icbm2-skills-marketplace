#!/usr/bin/env python3
"""Vivid visualization helpers (boilerplate for any Textual TUI).

Drop these 5 pure functions into your TUI file (or a `viz.py` module)
to get:

  - render_donut(...)        — accepted/rejected ratio, color-graded
  - render_core_bars(...)    — per-core load, vertical mini-bars
  - render_forecast_bars(...) — daily earnings bar chart (auto-scales)
  - render_core_heatmap(...) — time-series heatmap of core activity
  - render_header_logo(...)  — ASCII wordmark + status dot

All helpers are pure (no `self`, no app state, no side effects) — they
take primitives and return Rich-markup strings. This makes them:

  1. Unit-testable without a live Textual app
  2. Reusable across TUI projects (just copy this file)
  3. Decoupled from widget logic — widget just calls and wraps

PALETTE is the standard NMMiner cyberpunk green (6-9 tier hierarchy
from xmrig-dashboard v0.2.0). Tweak in one place.

Usage in a widget:

    from vivid_viz import render_donut, render_core_heatmap, PALETTE

    class MyPanel(Static):
        def render(self) -> str:
            return render_donut(accepted=100, rejected=3)

Test pattern (with importlib, see SKILL.md P32):

    import importlib.util, pathlib
    spec = importlib.util.spec_from_file_location(
        "vivid_viz", pathlib.Path("vivid_viz.py")
    )
    assert spec is not None and spec.loader is not None
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    assert "95" in mod.render_donut(95, 5)
"""
from __future__ import annotations


# ---------- PALETTE dict (single source of truth) ----------
PALETTE = {
    "bg":         "#001100",  # deep terminal green-black
    "bg_dark":    "#000800",  # status bar background
    "fg":         "#33ff66",  # primary text
    "fg_dim":     "#1f8033",  # dim text (labels, separators)
    "fg_faint":   "#0e4019",  # very dim (axis hints, empty cells)
    "accent":     "#00ff9c",  # bright accent (active state, hot cells)
    "warning":    "#ffaa00",  # amber (mid thresholds)
    "error":      "#ff3355",  # red (errors, high reject)
    "highlight":  "#ccffdd",  # near-white (current values)
}


# ---------- Donut chart (4-row + inline label) ----------
def render_donut(accepted: int, rejected: int) -> str:
    """ASCII donut chart of accepted vs rejected shares.

    Returns Rich markup. 4 rows total — the 4th row has the percent
    label inline (e.g. `▀██▄ 95.2% acc`), so `output.split("\\n")`
    is always length 4. 3-tier threshold (P37):
      pct > 0.95  → green ring
      pct < 0.90  → amber ring
      else        → neutral ring
    """
    total = accepted + rejected
    if total == 0:
        return f"[{PALETTE['fg_dim']}](no shares yet)[/{PALETTE['fg_dim']}]"

    pct = accepted / total
    if pct > 0.95:
        ring_color, hole_color = PALETTE["fg"], PALETTE["fg_faint"]
        label = f"[bold {PALETTE['highlight']}]{pct*100:.0f}%[/bold {PALETTE['highlight']}] acc"
    elif pct < 0.90:
        ring_color, hole_color = PALETTE["warning"], PALETTE["fg_faint"]
        label = f"[bold {PALETTE['warning']}]{pct*100:.1f}%[/bold {PALETTE['warning']}] acc"
    else:
        ring_color, hole_color = PALETTE["fg"], PALETTE["fg_faint"]
        label = f"[bold {PALETTE['highlight']}]{pct*100:.1f}%[/bold {PALETTE['highlight']}] acc"

    rows = [
        f"[{ring_color}]▄[/{ring_color}][{hole_color}]██[/{hole_color}][{ring_color}]▀[/{ring_color}]",
        f"[{ring_color}]█[/{ring_color}][{hole_color}]░░[/{hole_color}][{ring_color}]█[/{ring_color}]",
        f"[{ring_color}]█[/{ring_color}][{hole_color}]░░[/{hole_color}][{ring_color}]█[/{ring_color}]",
        f"[{ring_color}]▀[/{ring_color}][{hole_color}]██[/{hole_color}][{ring_color}]▄[/{ring_color}] {label}",
    ]
    return "\n".join(rows)


# ---------- Per-core vertical bars ----------
def render_core_bars(per_core: list, width: int = 6) -> str:
    """Per-CPU-core load as a row of vertical mini-bars.

    per_core is a list of floats (0-100) — one per core.
    width is the height of each bar in cells (4-6 recommended).
    Caps at 32 visible cores; shows "+N more" if more.

    Color gradient: <30% = faint / 30-70% = dim / 70%+ = fg.
    """
    if not per_core:
        return f"[{PALETTE['fg_dim']}](no core data)[/{PALETTE['fg_dim']}]"

    def cell_color(pct: float) -> str:
        if pct < 30:
            return PALETTE["fg_faint"]
        if pct < 70:
            return PALETTE["fg_dim"]
        return PALETTE["fg"]

    visible = per_core[:32]
    more = len(per_core) - len(visible)

    columns = []
    for v in visible:
        pct = max(0.0, min(100.0, v))
        filled = int(round(pct / 100 * width))
        col = []
        for i in range(width):
            if i < (width - filled):
                col.append((chr(0x2581), PALETTE["fg_faint"]))  # ▁
            else:
                col.append((chr(0x2588), cell_color(pct)))      # █
        columns.append(col)

    lines = []
    for row in range(width):
        line = " "
        for ch, col_color in (c[row] for c in columns):
            line += f"[{col_color}]{ch}[/{col_color}] "
        lines.append(line)

    cap = ""
    if visible:
        avg = sum(visible) / len(visible)
        cap = f" avg [{PALETTE['fg']}]{avg:5.1f}%[/{PALETTE['fg']}]"
    if more > 0:
        cap += f"  [{PALETTE['fg_dim']}]+{more} more[/{PALETTE['fg_dim']}]"
    lines.append(cap)
    return "\n".join(lines)


# ---------- Daily forecast bar chart ----------
def render_forecast_bars(daily_values: list) -> str:
    """Horizontal bar chart of daily values (oldest first).

    daily_values is a list of floats (e.g. daily USD earnings).
    Uses 7-step Unicode ramp: ▁▂▃▄▅▆▇. Auto-scales to max value.
    Caps at 14 days visible. Empty / all-zero → placeholder.
    """
    if not daily_values or all(v <= 0 for v in daily_values):
        return (
            f"[{PALETTE['fg_dim']}]no data yet — chart fills in as the"
            f"[/{PALETTE['fg_dim']}]\n"
            f"[{PALETTE['fg_dim']}]dashboard runs each day[/{PALETTE['fg_dim']}]"
        )

    blocks = "▁▂▃▄▅▆▇"
    mx = max(daily_values) or 1.0
    visible = daily_values[-14:]

    line = " "
    for v in visible:
        ratio = v / mx
        idx = min(len(blocks) - 1, int(ratio * len(blocks)))
        ch = blocks[idx]
        if v > 0:
            line += f"[{PALETTE['fg']}]{ch}[/{PALETTE['fg']}]"
        else:
            line += f"[{PALETTE['fg_faint']}]{ch}[/{PALETTE['fg_faint']}]"
    line += f"  [{PALETTE['fg_dim']}]max ${mx:.4f}/d[/{PALETTE['fg_dim']}]"
    return line


# ---------- Core activity heatmap ----------
def render_core_heatmap(per_core_now: list, history: list, width: int = 12) -> str:
    """Time-series heatmap of CPU core activity.

    history is a list of per-core-snapshot lists, oldest first.
    Each snapshot is a list of floats (0-100), one per core.
    Newest sample on the right; older samples scroll off the left.
    Pads to `width` columns if history is shorter.
    4-tier cells: ' ' (cold) / ░ / ▒ / ▓ (hot).
    """
    if not history or not per_core_now:
        return f"[{PALETTE['fg_dim']}](no core samples yet)[/{PALETTE['fg_dim']}]"

    n_cores = len(per_core_now)
    cells = " ░▒▓"

    snapshots = history[-width:] if len(history) > width else list(history)
    while len(snapshots) < width:
        snapshots.insert(0, [0.0] * n_cores)

    lines = []
    for core_idx in range(n_cores):
        row = " "
        for snap in snapshots:
            if core_idx < len(snap):
                pct = snap[core_idx]
                if pct < 5:
                    ch, color = " ", PALETTE["fg_faint"]
                elif pct < 40:
                    ch, color = cells[1], PALETTE["fg_dim"]
                elif pct < 75:
                    ch, color = cells[2], PALETTE["fg"]
                else:
                    ch, color = cells[3], PALETTE["accent"]
            else:
                ch, color = "?", PALETTE["warning"]
            row += f"[{color}]{ch}[/{color}]"
        # Per-core label
        now_pct = per_core_now[core_idx] if core_idx < len(per_core_now) else 0
        if now_pct >= 70:
            row += f"  [{PALETTE['fg']}]{now_pct:3.0f}[/{PALETTE['fg']}]"
        elif now_pct >= 30:
            row += f"  [{PALETTE['fg_dim']}]{now_pct:3.0f}[/{PALETTE['fg_dim']}]"
        else:
            row += f"  [{PALETTE['fg_faint']}]{now_pct:3.0f}[/{PALETTE['fg_faint']}]"
        lines.append(row)

    # Footer: time axis
    inner = max(0, width - 3 - 3)  # 3 = len("old"), 3 = len("now")
    footer = (
        f"  [{PALETTE['fg_faint']}]"
        + "old" + " " * inner + "now"
        + f"[/{PALETTE['fg_faint']}]"
    )
    lines.append(footer)
    return "\n".join(lines)


# ---------- ASCII header logo + status badge ----------
def render_header_logo(width: int = 60) -> str:
    """ASCII wordmark + status badge (single line).

    Returns the wordmark (e.g. `█▀█ █▀▀ █▀█ █▀▀ █▀▀`); the caller
    appends the status dot and state text:

        out = (
            f" {render_header_logo()} "
            f"[bold {PALETTE['accent']}]●[/bold {PALETTE['accent']}] "
            f"[bold {PALETTE['accent']}]MINING[/bold {PALETTE['accent']}]"
        )
    """
    return (
        f"[bold {PALETTE['accent']}]"
        f"█▀█ █▀▀ █▀█ █▀▀ █▀▀"
        f"[/bold {PALETTE['accent']}]"
    )


# ---------- Self-test (run this file directly) ----------
if __name__ == "__main__":
    print("=== render_donut(0, 0) ===")
    print(render_donut(0, 0))
    print()
    print("=== render_donut(100, 5) ===")
    print(render_donut(100, 5))
    print()
    print("=== render_core_bars (8 cores, width=4) ===")
    print(render_core_bars([10, 25, 50, 75, 90, 100, 5, 30], width=4))
    print()
    print("=== render_forecast_bars([]) ===")
    print(render_forecast_bars([]))
    print()
    print("=== render_forecast_bars (7 days) ===")
    print(render_forecast_bars([0.001, 0.002, 0.003, 0.0025, 0.004, 0.0035, 0.005]))
    print()
    print("=== render_core_heatmap (4 cores, 6 snapshots) ===")
    print(render_core_heatmap(
        [50, 80, 20, 95],
        [[10, 20, 30, 40], [50, 60, 70, 80], [30, 40, 50, 60],
         [70, 80, 90, 10], [20, 30, 40, 50], [50, 80, 20, 95]],
        width=6,
    ))
    print()
    print("=== render_header_logo ===")
    print(render_header_logo())
