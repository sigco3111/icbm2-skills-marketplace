# Live Log-Tailing TUI Template
# =============================
# Real-time Textual dashboard that tails a running process's log file.
#
# Class pattern: "monitor a long-running daemon by parsing its
# stdout/stderr as it streams." Different from fireToken IPC (which
# polls atomic JSON files); here we tail an append-only log and
# incrementally extract metrics.
#
# Proven in production: XMRig Monero miner dashboard (2026-06-24) —
# 7 widgets, 2Hz refresh, pause/resume/quit bindings, no IPC needed
# (the daemon is already running and writing logs).
#
# CRITICAL pitfalls baked into this template:
#   - P15: _DEFAULT_STATE + .get() defense-in-depth (avoids KeyError on first render)
#   - P16: NO Header/Footer (causes MarkupError in textual 0.89+)
#   - P12: log tail pattern (50KB, deque, regex overwrite-not-accumulate)
#   - P14: 5-min price cache + fallback

import re
import time
import json
import urllib.request
from collections import deque
from datetime import datetime
from pathlib import Path

import psutil
from textual.app import App, ComposeResult
from textual.containers import Container
from textual.widgets import Static


# ---------- Configuration (replace per use case) ----------
LOG_FILE = Path("/path/to/daemon.log")
DAEMON_BIN = "/usr/local/bin/daemon"
DAEMON_CONFIG = "/path/to/config"
EXTERNAL_PRICE_API = "https://api.example.com/price"
REFRESH_HZ = 2
LOG_TAIL_BYTES = 50_000  # last 50KB ~= 10-15 min of typical daemon log
LOG_LINES_DISPLAY = 8
PRICE_CACHE_SECONDS = 300
FALLBACK_PRICE = 100.0


# ---------- DEFAULT STATE (P15: prevents KeyError on first render) ----------
# All widgets share this. Parse function deep-copies it, App.__init__ deep-copies it,
# and render() uses .get() for defense in depth.

_DEFAULT_STATE = {
    # Latest hashrate-style metrics (overwritten on each match)
    "metric_a": 0.0,
    "metric_b": 0.0,
    "metric_c": 0.0,
    # Counters (cumulative, daemon may print same N repeatedly)
    "counter_ok": 0,
    "counter_err": 0,
    # State markers
    "ready": False,
    "connected": False,
    "block_height": 0,
    "last_event_time": None,
    # Recent log lines for display
    "recent_log": deque(maxlen=LOG_LINES_DISPLAY),
}

_DEFAULT_SYSTEM = {
    "cpu_pct": 0.0,
    "mem_used_gb": 0.0,
    "mem_total_gb": 0.0,
    "mem_pct": 0.0,
    "cpu_temp_c": None,
    "uptime_s": 0.0,
}


# ---------- Metrics collectors ----------

def parse_log_file(path: Path) -> dict:
    """Tail LOG_FILE and extract latest metrics.

    KEY PATTERN: regex matches overwrite (last match wins) because daemon
    logs repeat the same pattern (e.g. "speed X Y Z H/s" appears every
    refresh interval). Counters (accepted/rejected) may be cumulative
    in your daemon — keep last value, not max.

    P15: Always returns a fully-populated dict (never empty).
    """
    # P15: deep copy from _DEFAULT_STATE (deque needs .copy())
    state = {k: (v.copy() if isinstance(v, deque) else v) for k, v in _DEFAULT_STATE.items()}

    if not path.exists():
        return state

    try:
        # Safe tail: read last 50KB only
        with path.open("rb") as f:
            f.seek(0, 2)
            size = f.tell()
            f.seek(max(0, size - LOG_TAIL_BYTES))
            tail = f.read().decode("utf-8", errors="ignore")

        for line in tail.splitlines():
            # Strip markup-like characters from log lines to avoid Rich conflicts
            safe_line = line.replace("[", "(").replace("]", ")")
            # Show last 90 chars (avoid long stack traces dominating)
            state["recent_log"].append(safe_line[-90:] if len(safe_line) > 90 else safe_line)

            # EXAMPLE: hashrate triple (overwrite, not accumulate)
            m = re.search(r"speed\s+10s/60s/15m\s+([\d.]+)\s+([\d.]+)\s+([\d.n/a]+)\s*H/s", line)
            if m:
                state["metric_a"] = float(m.group(1))
                state["metric_b"] = float(m.group(2))
                v = m.group(3)
                state["metric_c"] = float(v) if v not in ("n/a", "") else 0.0

            # EXAMPLE: counter pair (X/Y format)
            m = re.search(r"accepted\s+\((\d+)/(\d+)\)", line)
            if m:
                state["counter_ok"] = int(m.group(1))
                state["counter_err"] = int(m.group(2))
                # Daemon timestamp prefix: [2026-06-24 09:21:26.337]
                if line.startswith("["):
                    state["last_event_time"] = line[1:20]

            # EXAMPLE: connection state
            m = re.search(r"new job from\s+(\S+)\s+.*height\s+(\d+)", line)
            if m:
                state["connected"] = True
                state["block_height"] = int(m.group(2))

            # EXAMPLE: ready signal
            if "READY" in line:
                state["ready"] = True

    except Exception as e:
        state["recent_log"].append(f"(parse error) {e}")

    return state


def get_system_metrics() -> dict:
    """psutil-based system metrics. Cross-platform."""
    cpu_pct = psutil.cpu_percent(interval=0.1)
    mem = psutil.virtual_memory()
    # macOS temperature (best-effort, often None on Intel)
    temp = None
    try:
        temps = psutil.sensors_temperatures()
        for entries in temps.values():
            for e in entries:
                if e.current and 30 < e.current < 110:
                    temp = e.current
                    break
            if temp:
                break
    except Exception:
        pass
    return {
        "cpu_pct": cpu_pct,
        "mem_used_gb": mem.used / 1024**3,
        "mem_total_gb": mem.total / 1024**3,
        "mem_pct": mem.percent,
        "cpu_temp_c": temp,
        "uptime_s": time.time() - psutil.boot_time(),
    }


def fetch_external_price() -> float:
    """External API with caching + fallback.

    PATTERN: 5-min cache, fallback to hardcoded if API fails.
    Prevents TUI from ever failing due to network blip.
    """
    global _price_cache, _price_cache_time
    try:
        now = time.time()
        if "_price_cache" in globals() and now - _price_cache_time < PRICE_CACHE_SECONDS:
            return _price_cache
        req = urllib.request.Request(
            EXTERNAL_PRICE_API,
            headers={"User-Agent": "live-log-tui/1.0"},
        )
        with urllib.request.urlopen(req, timeout=5) as r:
            data = json.loads(r.read())
        # Adapt to your API's response shape
        price = float(data["result"]["price"])
        _price_cache = price
        _price_cache_time = now
        return price
    except Exception:
        return FALLBACK_PRICE


# ---------- TUI Widgets (one per metric panel) ----------
# P15: All render() methods use .get() for defense in depth
# P16: Avoid complex Rich markup like [dim]...[/dim] — Header/Footer may inject

class MetricPanel1(Static):
    """Live hashrate-style metrics with bar viz."""
    def render(self) -> str:
        s = self.app.state.get("log", _DEFAULT_STATE)
        a = s.get("metric_a", 0.0)
        b = s.get("metric_b", 0.0)
        c = s.get("metric_c", 0.0)
        max_v = max(a, b, 1500)
        def bar(v: float) -> str:
            pct = min(100, int(v / max_v * 100))
            return f"▓" * (pct // 5) + f"░" * (20 - pct // 5) + f" {pct:3d}%"
        return (
            f"[bold cyan]METRIC 1[/bold cyan]\n\n"
            f"  10s:  {a:>8,.1f}   {bar(a)}\n"
            f"  60s:  {b:>8,.1f}   {bar(b)}\n"
            f"  15m:  {c:>8,.1f}   {bar(c)}\n"
        )


class SystemPanel(Static):
    """System metrics panel."""
    def render(self) -> str:
        s = self.app.state.get("system", _DEFAULT_SYSTEM)
        cpu_pct = s.get("cpu_pct", 0.0)
        mem_pct = s.get("mem_pct", 0.0)
        mem_used = s.get("mem_used_gb", 0.0)
        mem_total = s.get("mem_total_gb", 0.0)
        temp = s.get("cpu_temp_c")
        cpu_bar = "▓" * (int(cpu_pct) // 5) + "░" * (20 - int(cpu_pct) // 5)
        mem_bar = "▓" * (int(mem_pct) // 5) + "░" * (20 - int(mem_pct) // 5)
        temp_str = f"{temp:.0f}°C" if temp else "n/a"
        return (
            f"[bold magenta]SYSTEM[/bold magenta]\n\n"
            f"  CPU   {cpu_bar} {cpu_pct:5.1f}%  {temp_str}\n"
            f"  RAM   {mem_bar} {mem_pct:5.1f}%\n"
            f"       {mem_used:.1f}/{mem_total:.1f} GB\n"
        )


class StatusPanel(Static):
    """Connection/state panel."""
    def render(self) -> str:
        s = self.app.state.get("log", _DEFAULT_STATE)
        connected = s.get("connected", False)
        status = "OK connected" if connected else "OFFLINE"
        return (
            f"[bold yellow]STATUS[/bold yellow]\n\n"
            f"  {status}\n"
            f"  Block: {s.get('block_height', 0):,}\n"
            f"  Last:  {s.get('last_event_time') or 'n/a'}\n"
        )


class EarningsPanel(Static):
    """Earnings estimate panel (uses external price)."""
    def render(self) -> str:
        s = self.app.state.get("log", _DEFAULT_STATE)
        e = self.app.state.get("external", {"price": FALLBACK_PRICE})
        a = s.get("metric_a", 0.0)
        b = s.get("metric_b", 0.0)
        avg = (a + b) / 2
        per_day = avg / 1000 * 0.0008  # example ratio
        price = e.get("price", FALLBACK_PRICE)
        usd = per_day * price
        # P16: Avoid [dim]...[/dim] markup — use plain text or [bold]
        return (
            f"[bold green]EARNINGS[/bold green]\n\n"
            f"  Price:    ${price:.2f}\n"
            f"  Daily:    {per_day:.6f}  (${usd:.4f})\n"
            f"  Monthly:  {per_day*30:.4f}  (${usd*30:.2f})\n"
            f"  Yearly:   {per_day*365:.4f}  (${usd*365:.2f})\n"
        )


class LogPanel(Static):
    """Recent log lines."""
    def render(self) -> str:
        s = self.app.state.get("log", _DEFAULT_STATE)
        recent = s.get("recent_log", deque(maxlen=LOG_LINES_DISPLAY))
        lines = list(recent)[-LOG_LINES_DISPLAY:]
        if not lines:
            lines = ["(waiting for log data...)"]
        return (
            f"[bold white]LOG[/bold white]\n\n"
            + "\n".join(f"  {l}" for l in lines)
        )


class StatusBar(Static):
    """Top status bar (one-line summary)."""
    def render(self) -> str:
        s = self.app.state.get("log", _DEFAULT_STATE)
        sys_m = self.app.state.get("system", _DEFAULT_SYSTEM)
        active = "OK ACTIVE" if s.get("connected") else "IDLE"
        return (
            f"  [bold green]{active}[/bold green]  |  "
            f"CPU: {sys_m.get('cpu_pct', 0):5.1f}%  |  "
            f"Hash: {s.get('metric_a', 0):,.0f}  |  "
            f"{datetime.now().strftime('%H:%M:%S')}"
        )


# ---------- Main App ----------

class LiveLogDashboard(App):
    """Reusable live-log TUI. Replace widget panel content per use case.

    P15: __init__ populates state from _DEFAULT_STATE (first render safe).
    P16: NO Header/Footer (causes MarkupError in textual 0.89+).
    """

    CSS = """
    Screen { background: #0a0a0a; }
    #main { layout: grid; grid-size: 2 3; grid-gutter: 1; padding: 1; }
    MetricPanel1, SystemPanel, StatusPanel, EarningsPanel, LogPanel {
        border: solid #444; padding: 1;
    }
    MetricPanel1 { border: solid cyan; }
    SystemPanel { border: solid magenta; }
    StatusPanel { border: solid yellow; }
    EarningsPanel { border: solid green; }
    LogPanel { border: solid white; }
    StatusBar { dock: top; height: 1; background: #1a1a1a; color: #ccc; }
    #hint { height: 1; color: #888; text-align: center; }
    """

    BINDINGS = [
        ("p", "pause_daemon", "Pause"),
        ("r", "resume_daemon", "Resume"),
        ("q", "quit_app", "Quit"),
    ]

    state = {}

    def __init__(self):
        super().__init__()
        # P15: Populate state from defaults (first render will not KeyError)
        self.state = {
            "log": {k: (v.copy() if isinstance(v, deque) else v) for k, v in _DEFAULT_STATE.items()},
            "system": dict(_DEFAULT_SYSTEM),
            "external": {"price": FALLBACK_PRICE},
        }
        self._last_price_fetch = 0

    def compose(self) -> ComposeResult:
        # P16: NO Header(), NO Footer() — use Static hint instead
        yield StatusBar()
        with Container(id="main"):
            yield MetricPanel1()
            yield SystemPanel()
            yield StatusPanel()
            yield EarningsPanel()
            yield LogPanel()
            yield Static("Press q to quit  |  p pause  |  r resume", id="hint")

    def on_mount(self) -> None:
        self.title = "Live Log Dashboard"
        self.set_interval(1.0 / REFRESH_HZ, self.refresh_state)
        self.set_interval(float(PRICE_CACHE_SECONDS), self._refresh_price)

    def _refresh_price(self) -> None:
        self.state["external"]["price"] = fetch_external_price()

    def refresh_state(self) -> None:
        now = time.time()
        if now - self._last_price_fetch > PRICE_CACHE_SECONDS:
            self._refresh_price()
            self._last_price_fetch = now
        self.state["log"] = parse_log_file(LOG_FILE)
        self.state["system"] = get_system_metrics()
        for w in self.query(Static):
            try:
                w.refresh()
            except Exception:
                pass

    def action_pause_daemon(self) -> None:
        import subprocess
        subprocess.run(["pkill", "-STOP", "-f", DAEMON_BIN], check=False)
        self.notify("Paused", severity="information")

    def action_resume_daemon(self) -> None:
        import subprocess
        subprocess.run(["pkill", "-CONT", "-f", DAEMON_BIN], check=False)
        self.notify("Resumed", severity="information")

    def action_quit_app(self) -> None:
        self.notify("Goodbye!", severity="information")
        self.exit()


if __name__ == "__main__":
    app = LiveLogDashboard()
    app.run()


# ---------- Headless validation (non-TTY env) ----------
#
# Use this pattern when you can't open a real TTY to test the TUI:
#
#   python3 -c "
#   import importlib.util
#   spec = importlib.util.spec_from_file_location('m', 'live_log_dashboard.py')
#   mod = importlib.util.module_from_spec(spec)
#   spec.loader.exec_module(mod)
#
#   s = mod.parse_log_file(mod.LOG_FILE)
#   print('log ready:', s['ready'], 'metric_a:', s['metric_a'])
#
#   m = mod.get_system_metrics()
#   print('cpu:', m['cpu_pct'], 'mem:', m['mem_pct'])
#
#   p = mod.fetch_external_price()
#   print('price:', p)
#   "
#
# If this prints numbers, the data layer works. The TUI itself
# only needs a real TTY to render — don't try to run it non-interactively.
#
# ---------- P15 quick test (verifies first-render safety) ----------
#
#   python3 -c "
#   import importlib.util
#   spec = importlib.util.spec_from_file_location('m', 'live_log_dashboard.py')
#   mod = importlib.util.module_from_spec(spec)
#   spec.loader.exec_module(mod)
#
#   # Simulate first render with EMPTY state (what __init__ would have)
#   app = mod.LiveLogDashboard.__new__(mod.LiveLogDashboard)
#   app.state = {'log': {}, 'system': {}, 'external': {}}  # intentionally empty
#   # Now call render() on every panel — should NOT KeyError
#   for cls in [mod.MetricPanel1, mod.SystemPanel, mod.StatusPanel,
#               mod.EarningsPanel, mod.LogPanel, mod.StatusBar]:
#       w = cls()
#       w.app = app
#       print(cls.__name__, 'OK:', w.render()[:30])
#   "
#   # If P15 defense-in-depth works, this prints without KeyError.
