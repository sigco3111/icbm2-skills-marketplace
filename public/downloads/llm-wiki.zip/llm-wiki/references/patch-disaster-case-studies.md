# Patch-Disaster Case Studies

Real examples of structural patches going wrong in the LLM Wiki, with the
exact `old_string` / `new_string` that caused the failure and the recovery
pattern. Read this once after encountering the "Patching a file to insert
section N+1" pitfall.

## Case 1: Inserting a new numbered section wipes the next section's header (2026-06-05)

**File**: `concepts/ai-agents-trends-2026.md` (had sections ### 1 through ### 15)

**Intent**: Add a new `### 16. 구글 드림빈즈 (Dreambeans)` section after section 15.

**Disaster patch**:

```python
# WRONG — collapsed structure
patch(
    old_string = "### 15. OpenAI Codex 비개발자 확장 + Microsoft 자체 MAI 모델 (2026-06-04)",
    new_string = """### 16. 구글 드림빈즈 (Dreambeans) — Personal Intelligence 공개 (2026-06-05)
- [[dreambeans]] — 구글 랩스 일일 AI 브리핑 앱 ...
- ...
- [[codex]] — 500만 사용자, 비개발자 20%·3배 빠른 성장 ...
- [[mai-code-1-flash]] — Microsoft 첫 자체 코딩 모델 ...
- 의미: Anthropic Skills/Cowork vs OpenAI Codex Plugins/Sites ...
- [[claude-cowork]]와 직접 경쟁 ...
- [[context-mode]]와 맞물림 ...
"""
)
```

The patch tool did the string replacement cleanly — but section 15's body
content (5 bullet lines, including the `### 15.` header line) was inside
the matched `old_string` neighborhood, and the `new_string` only had the
new `### 16.` section + the original section 15 body. Result: section 15
header disappeared, section 16 was created, and section 15's bullets
became part of section 16's body. Structurally broken.

**Recovery**: Second patch that re-introduced the `### 15. ...` header
between section 14 and section 16, restoring the original structure.

**Safe pattern for "insert section N+1 before existing section N"**:

```python
patch(
    old_string = """### 15. OpenAI Codex 비개발자 확장 + Microsoft 자체 MAI 모델 (2026-06-04)
- [[codex]] — 500만 사용자, 비개발자 20%·3배 빠른 성장 ...
""",
    new_string = """### 16. 구글 드림빈즈 (Dreambeans) — Personal Intelligence 공개 (2026-06-05)
- [[dreambeans]] — 구글 랩스 일일 AI 브리핑 앱 ...
- 의미: ...
- [[openai-smartphone-2028]]·[[gemini-intelligence]] ...

### 15. OpenAI Codex 비개발자 확장 + Microsoft 자체 MAI 모델 (2026-06-04)
- [[codex]] — 500만 사용자, 비개발자 20%·3배 빠른 성장 ...
"""
)
```

The `old_string` ends at section 15's first line, and `new_string` puts
section 16 ABOVE the verbatim section 15 header. Both sections survive.

**Alternative safe pattern — append at end of file**:

```python
# Read the file, find the last bullet of section 15. Patch by
# replacing the last bullet with "last bullet + blank + section 16".
patch(
    old_string = "- [[context-mode]]와 맞물림 — 적응형 응답 길이 = 토큰 효율 트렌드 공통 화두\n",
    new_string = "- [[context-mode]]와 맞물림 — 적응형 응답 길이 = 토큰 효율 트렌드 공주 화두\n\n### 16. 구글 드림빈즈 ...\n- ...\n"
)
```

This works because the last line of section 15 is a unique anchor
(appears exactly once in the file) and we append the new section AFTER
it. No section header is at risk.

**Always**: re-read the patched file end-to-end to confirm section count
and headers survived before moving on.

## Case 2: Wikilink to non-existent page written into a new entity (2026-06-05)

**File**: `entities/dreambeans.md`

**Drafted wikilinks**:
- `[[google-labs]]` — no page exists (it's the developer org name, never got its own entity)
- `[[nano-banana-2]]` — no page exists (the model is only mentioned in `[[vision-banana]]`)

**Detection**: ran `ls ~/wiki/entities/ | grep -iE "vision|nano|google"` after
drafting the page, before writing. Saw neither slug existed.

**Fix**: patched the file to convert those wikilinks to plain text:

```diff
-- [[google-labs]] — 드림빈즈 개발 조직
+- **구글 랩스(Google Labs)** — 드림빈즈 개발 조직. 별도 페이지 미존재
-- [[nano-banana-2]] / [[vision-banana]] — 드림빈즈의 일러스트 생성 기반
+- [[vision-banana]] — 드림빈즈의 일러스트 생성 기반(추정)
```

If undetected, both links would have been broken wikilinks in the index
and Obsidian graph view until the next lint caught them.

**Lesson**: the `ls`-based pre-write verification is cheap (one command
listing the relevant directory) and prevents the entire class of broken
wikilinks. Do it before `write_file`, not after.

## Case 3: No-op detection correctly skipped a re-run item (2026-06-05)

**Context**: The Notion collector script returned 2 items:
1. Dreambeans — new, processed normally
2. Codex 역할별 플러그인 — already processed in 2026-06-04 sync

**Detection**: searched `log.md` for the most recent sync entry
(`## [2026-06-04] ingest | Notion Dev News → LLM Wiki 동기화`) and
confirmed both items appeared in that single entry. The Codex article
was registered, the raw source file existed, the entity page existed,
the concept section existed.

**Action**: did not re-fetch content, did not re-create pages. Logged
the no-op note in this session's log entry under "Already registered"
and "Idempotency note" sections. The Codex article's continued
re-appearance in the Notion digest is a known script bug — the script
doesn't mark processed items in Notion. This is the third occurrence
of this issue (logged on 2026-04-12 and 2026-06-02 as well).

**Lesson**: the no-op detection pattern works. The recurring underlying
bug is the collector script's lack of marking. File this as a follow-up
recommendation each time it occurs, so the eventual fix to
`notion_news_to_wiki.py` accumulates enough signal to be prioritized.

## Case 4: Backlink patch duplicated a section header (2026-06-11)

**File**: `entities/oh-my-harness.md`

**Intent**: Add `[[loop-engineering]]` to the "관련/유사 도구" section's bullet list.

**Disaster patch**:

```python
# WRONG — old_string was a header+blank line, not a unique bullet
patch(
    old_string = "## 관련/유사 도구\n\n",
    new_string = "## 관련/유사 도구\n## 관련/유사 도구\n- [[loop-engineering]] — ...\n"
  # ↑ patch tool matched the blank line between header and bullets,
  #   and replaced it with TWO copies of the header.
)
```

Result: `## 관련/유사 도구` appeared twice in the file. The bullet list
was preserved, but a phantom header sat between the real header and the
first bullet.

**Detection**: re-read the file end-to-end after the patch (per the
"re-read patched file" rule) and noticed two consecutive `## 관련/유사 도구` lines.

**Recovery**: Second patch that matched the duplicated header line and
removed the duplicate.

**Safe pattern — anchor on the LAST bullet, not the header+blank-line**:

```python
patch(
    old_string = "- [[opencode-contexty]] — OpenCode에 컨텍스트 엔지니어링 추가 (다른 방향의 강화)\n",
    new_string = "- [[opencode-contexty]] — OpenCode에 컨텍스트 엔지니어링 추가 (다른 방향의 강화)\n- [[loop-engineering]] — 2026-06 등장. 직교 관계.\n"
)
```

**General lesson**: when adding a single bullet to a list, **anchor on
the last existing bullet**, not on the section header + blank line.
Section headers are not unique enough (many pages share them), and a
trailing blank line is the patch tool's easiest target for accidental
header duplication.

## Case 5: Notion JS-only page still yields a Wiki entry via concept synthesis (2026-06-11)

**Problem**: `mcp_ddg_search_fetch_content` returned exactly:

> "Notion — JavaScript must be enabled in order to use Notion. Please enable JavaScript to continue."

— 93 characters total. The page content is rendered client-side.

**Naive response**: skip the item entirely with reason "content not extractable".

**Better response**: the *title itself* is often enough signal to register a concept page when:
1. The concept name is a recognized industry term, not a one-off phrase.
2. The concept is already *distributed* across multiple existing wiki pages in fragmentary form.
3. A consolidated page would surface the pattern instead of leaving it scattered.

**Pattern applied**:
1. Save a `raw/articles/<concept>-YYYY-MM-DD.md` with **metadata only** (title, source URL, fetched date, `fetch_status: not_extracted (Notion JS-only)`, concept definition inferred from title, Wiki registration rationale).
2. Create a `concepts/<concept>.md` page that **synthesizes the scattered mentions from existing wiki pages** into a single definition, evolution table, open questions, and cross-references.
3. Mark the source as metadata-only pending richer extraction.
4. **Do NOT skip silently** — silent skips lose the concept. The concept still gets registered; the raw source just stays thin.

**Result**: `concepts/production-prompt.md` was created with 8 cross-references to existing pages ([[gpt-5-5]], [[subq-1m-preview]], [[ai-agents-trends-2026]] etc.), and the existing pages got backlinks back. The graph got denser without inventing content.

**Lesson**: "I can't read the source" is not the same as "the concept doesn't exist." When the title is an industry-recognized term AND the concept is already scattered across the wiki, **consolidate** — write a concept page from existing wiki mentions and flag the raw source as metadata-only.

## Case 6: Alphabetical insertion order in index.md must be checked twice (2026-06-11)

**Context**: inserted two new concept pages — `loop-engineering` and `production-prompt`.

**The bug**: `loop-engineering` was placed at position `homebrew-ram` → `loop-engineering` → `ios-trends-2026`. **Alphabetically wrong**: `ios-trends-2026` starts with `i`, which comes BEFORE `l`. Correct order is `homebrew-ram` → `ios-trends-2026` → `interaction-model` → `local-ai-apple-silicon` → `loop-engineering`.

**Detection**: re-read patched `index.md` and noticed the ordering violation.

**Recovery**: second patch that moved `loop-engineering` to between `local-ai-apple-silicon` and `managed-agents`.

**Lesson**: when inserting into `index.md`, **simulate the full alphabetical position BEFORE patching**, not just the immediate neighbors. Read the surrounding 3-4 lines on each side. Watch for:
- `loop-` after `local-` (both start with `l`, sort by full string)
- `production-` after `project-` (`pr` matches, sort by `o` vs `r`)
- `gpt-5-5` (`g-5`) before `gemini-*` (numeric vs alpha)
- Hyphens sort with their character (per SCHEMA.md convention)

## Case 7: Lint script with broken slug resolution wrote 733 broken / 117 orphan counts to log.md (2026-06-14)

**File**: `wiki/log.md` (the lint entry appended on 2026-06-14)

**Intent**: A programmatic lint pass that scans every wiki page, extracts
`[[wikilinks]]`, resolves each link to a target page, and tallies broken
links + orphan pages.

**Bug in the first pass**: the slug-resolution function required
`f"{sec}/{link}"` to match a page literally. It correctly resolved
`[[claude-code]]` → no match. It FAILED to resolve `[[anthropic]]` even
though `entities/anthropic.md` clearly exists, because the literal-string
match required the section prefix to be in the link text, not the slug
alone. The result:

- True broken count: **40** (across 15 pages)
- Reported broken count: **733** (across 113 pages)
- True orphan count: **25**
- Reported orphan count: **117**

**Disaster pattern**: the inflated numbers were written into `log.md`
before double-checking, then required a truncate-and-rewrite of the
whole entry on the same session. `log.md` is append-only per
SCHEMA.md, and the broken entry was a real append — overwritten only
by manual find-and-replace, not by the normal log rules.

**Lesson (count-then-commit)**:

1. **Compute counts in Python, print them, READ them, verify sanity, THEN
   write to log.** A 733 broken count on a 125-page wiki ≈ 5.86 broken
   per page, which is implausible. A 40 broken count ≈ 0.32 per page,
   which is plausible. Sanity-check the order of magnitude.
2. **The slug-resolution function** must accept three shapes:
   - `[[entity-name]]` → try `entities/<name>`, then `concepts/<name>`, etc.
   - `[[concepts/entity-name]]` → use as-is if it matches.
   - `[[entity-name]]` with ambiguous prefix → pick the section that
     actually has a matching file (don't require exact `sec/slug` match).
3. **Always re-run the resolution with sample links** before logging.
   Pick 5 known-existing slugs (e.g. `anthropic`, `gemini`, `qwen`,
   `claude-code`, `hermes-agent`), verify the resolver returns the
   right target for each. If any returns `None`, the resolver is wrong
   and every count downstream is wrong.
4. **log.md is append-only per the wiki SCHEMA.md**. Recovering from a
   bad append requires a find-and-replace patch on the *file*, not on
   the *entry*. The clean recovery pattern:
   - Find the start of the bad entry (`content.find("## [YYYY-MM-DD] lint")`)
   - Truncate everything from that offset onwards: `new_content = content[:start].rstrip() + "\n"`
   - Append the corrected entry
   - Write the whole file back
   This is the only safe way to "edit" an append-only log without
   leaving a torn entry visible.

**Test snippet** to validate a resolver before using its counts:

```python
KNOWN = ["anthropic", "gemini", "qwen", "claude-code", "hermes-agent",
         "ai-agents-trends-2026", "mcp-vs-skills"]
for slug in KNOWN:
    target = resolve(slug)
    assert target is not None, f"resolver failed on KNOWN slug {slug}"
    assert os.path.exists(os.path.join(WIKI, target + ".md")), \
        f"resolver returned {target} but file does not exist"
print("resolver OK")
```
