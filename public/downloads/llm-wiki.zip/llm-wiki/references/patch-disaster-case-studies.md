# Patch-Disaster Case Studies

Real examples of structural patches going wrong in the LLM Wiki, with the
exact `old_string` / `new_string` that caused the failure and the recovery
pattern. Read this once after encountering the "Patching a file to insert
section N+1" pitfall.

## Case 1: Inserting a new numbered section wipes the next section's header (2026-06-05)

**File**: `concepts/ai-agents-trends-2026.md` (had sections ### 1 through ### 15)

**Intent**: Add a new `### 16. 구글 드림빈즈 (Dreambeans)` section after section 15.

**Disaster patch**:

```python
# WRONG — collapsed structure
patch(
    old_string = "### 15. OpenAI Codex 비개발자 확장 + Microsoft 자체 MAI 모델 (2026-06-04)",
    new_string = """### 16. 구글 드림빈즈 (Dreambeans) — Personal Intelligence 공개 (2026-06-05)
- [[dreambeans]] — 구글 랩스 일일 AI 브리핑 앱 ...
- ...
- [[codex]] — 500만 사용자, 비개발자 20%·3배 빠른 성장 ...
- [[mai-code-1-flash]] — Microsoft 첫 자체 코딩 모델 ...
- 의미: Anthropic Skills/Cowork vs OpenAI Codex Plugins/Sites ...
- [[claude-cowork]]와 직접 경쟁 ...
- [[context-mode]]와 맞물림 ...
"""
)
```

The patch tool did the string replacement cleanly — but section 15's body
content (5 bullet lines, including the `### 15.` header line) was inside
the matched `old_string` neighborhood, and the `new_string` only had the
new `### 16.` section + the original section 15 body. Result: section 15
header disappeared, section 16 was created, and section 15's bullets
became part of section 16's body. Structurally broken.

**Recovery**: Second patch that re-introduced the `### 15. ...` header
between section 14 and section 16, restoring the original structure.

**Safe pattern for "insert section N+1 before existing section N"**:

```python
patch(
    old_string = """### 15. OpenAI Codex 비개발자 확장 + Microsoft 자체 MAI 모델 (2026-06-04)
- [[codex]] — 500만 사용자, 비개발자 20%·3배 빠른 성장 ...
""",
    new_string = """### 16. 구글 드림빈즈 (Dreambeans) — Personal Intelligence 공개 (2026-06-05)
- [[dreambeans]] — 구글 랩스 일일 AI 브리핑 앱 ...
- 의미: ...
- [[openai-smartphone-2028]]·[[gemini-intelligence]] ...

### 15. OpenAI Codex 비개발자 확장 + Microsoft 자체 MAI 모델 (2026-06-04)
- [[codex]] — 500만 사용자, 비개발자 20%·3배 빠른 성장 ...
"""
)
```

The `old_string` ends at section 15's first line, and `new_string` puts
section 16 ABOVE the verbatim section 15 header. Both sections survive.

**Alternative safe pattern — append at end of file**:

```python
# Read the file, find the last bullet of section 15. Patch by
# replacing the last bullet with "last bullet + blank + section 16".
patch(
    old_string = "- [[context-mode]]와 맞물림 — 적응형 응답 길이 = 토큰 효율 트렌드 공통 화두\n",
    new_string = "- [[context-mode]]와 맞물림 — 적응형 응답 길이 = 토큰 효율 트렌드 공통 화두\n\n### 16. 구글 드림빈즈 ...\n- ...\n"
)
```

This works because the last line of section 15 is a unique anchor
(appears exactly once in the file) and we append the new section AFTER
it. No section header is at risk.

**Always**: re-read the patched file end-to-end to confirm section count
and headers survived before moving on.

## Case 2: Wikilink to non-existent page written into a new entity (2026-06-05)

**File**: `entities/dreambeans.md`

**Drafted wikilinks**:
- `[[google-labs]]` — no page exists (it's the developer org name, never got its own entity)
- `[[nano-banana-2]]` — no page exists (the model is only mentioned in `[[vision-banana]]`)

**Detection**: ran `ls ~/wiki/entities/ | grep -iE "vision|nano|google"` after
drafting the page, before writing. Saw neither slug existed.

**Fix**: patched the file to convert those wikilinks to plain text:

```diff
-- [[google-labs]] — 드림빈즈 개발 조직
+- **구글 랩스(Google Labs)** — 드림빈즈 개발 조직. 별도 페이지 미존재
-- [[nano-banana-2]] / [[vision-banana]] — 드림빈즈의 일러스트 생성 기반
+- [[vision-banana]] — 드림빈즈의 일러스트 생성 기반(추정)
```

If undetected, both links would have been broken wikilinks in the index
and Obsidian graph view until the next lint caught them.

**Lesson**: the `ls`-based pre-write verification is cheap (one command
listing the relevant directory) and prevents the entire class of broken
wikilinks. Do it before `write_file`, not after.

## Case 3: No-op detection correctly skipped a re-run item (2026-06-05)

**Context**: The Notion collector script returned 2 items:
1. Dreambeans — new, processed normally
2. Codex 역할별 플러그인 — already processed in 2026-06-04 sync

**Detection**: searched `log.md` for the most recent sync entry
(`## [2026-06-04] ingest | Notion Dev News → LLM Wiki 동기화`) and
confirmed both items appeared in that single entry. The Codex article
was registered, the raw source file existed, the entity page existed,
the concept section existed.

**Action**: did not re-fetch content, did not re-create pages. Logged
the no-op note in this session's log entry under "Already registered"
and "Idempotency note" sections. The Codex article's continued
re-appearance in the Notion digest is a known script bug — the script
doesn't mark processed items in Notion. This is the third occurrence
of this issue (logged on 2026-04-12 and 2026-06-02 as well).

**Lesson**: the no-op detection pattern works. The recurring underlying
bug is the collector script's lack of marking. File this as a follow-up
recommendation each time it occurs, so the eventual fix to
`notion_news_to_wiki.py` accumulates enough signal to be prioritized.

## Case 4: Backlink patch duplicated a section header (2026-06-11)

**File**: `entities/oh-my-harness.md`

**Intent**: Add `[[loop-engineering]]` to the "관련/유사 도구" section's bullet list.

**Disaster patch**:

```python
# WRONG — old_string was a header+blank line, not a unique bullet
patch(
    old_string = "## 관련/유사 도구\n\n",
    new_string = "## 관련/유사 도구\n## 관련/유사 도구\n- [[loop-engineering]] — ...\n"
  # ↑ patch tool matched the blank line between header and bullets,
  #   and replaced it with TWO copies of the header.
)
```

Result: `## 관련/유사 도구` appeared twice in the file. The bullet list
was preserved, but a phantom header sat between the real header and the
first bullet.

**Detection**: re-read the file end-to-end after the patch (per the
"re-read patched file" rule) and noticed two consecutive `## 관련/유사 도구` lines.

**Recovery**: Second patch that matched the duplicated header line and
removed the duplicate.

**Safe pattern — anchor on the LAST bullet, not the header+blank-line**:

```python
patch(
    old_string = "- [[opencode-contexty]] — OpenCode에 컨텍스트 엔지니어링 추가 (다른 방향의 강화)\n",
    new_string = "- [[opencode-contexty]] — OpenCode에 컨텍스트 엔지니어링 추가 (다른 방향의 강화)\n- [[loop-engineering]] — 2026-06 등장. 직교 관계.\n"
)
```

**General lesson**: when adding a single bullet to a list, **anchor on
the last existing bullet**, not on the section header + blank line.
Section headers are not unique enough (many pages share them), and a
trailing blank line is the patch tool's easiest target for accidental
header duplication.

## Case 5: Notion JS-only page still yields a Wiki entry via concept synthesis (2026-06-11)

**Problem**: `mcp_ddg_search_fetch_content` returned exactly:

> "Notion — JavaScript must be enabled in order to use Notion. Please enable JavaScript to continue."

— 93 characters total. The page content is rendered client-side.

**Naive response**: skip the item entirely with reason "content not extractable".

**Better response**: the *title itself* is often enough signal to register a concept page when:
1. The concept name is a recognized industry term, not a one-off phrase.
2. The concept is already *distributed* across multiple existing wiki pages in fragmentary form.
3. A consolidated page would surface the pattern instead of leaving it scattered.

**Pattern applied**:
1. Save a `raw/articles/<concept>-YYYY-MM-DD.md` with **metadata only** (title, source URL, fetched date, `fetch_status: not_extracted (Notion JS-only)`, concept definition inferred from title, Wiki registration rationale).
2. Create a `concepts/<concept>.md` page that **synthesizes the scattered mentions from existing wiki pages** into a single definition, evolution table, open questions, and cross-references.
3. Mark the source as metadata-only pending richer extraction.
4. **Do NOT skip silently** — silent skips lose the concept. The concept still gets registered; the raw source just stays thin.

**Result**: `concepts/production-prompt.md` was created with 8 cross-references to existing pages ([[gpt-5-5]], [[subq-1m-preview]], [[ai-agents-trends-2026]] etc.), and the existing pages got backlinks back. The graph got denser without inventing content.

**Lesson**: "I can't read the source" is not the same as "the concept doesn't exist." When the title is an industry-recognized term AND the concept is already scattered across the wiki, **consolidate** — write a concept page from existing wiki mentions and flag the raw source as metadata-only.

## Case 6: Alphabetical insertion order in index.md must be checked twice (2026-06-11)

**Context**: inserted two new concept pages — `loop-engineering` and `production-prompt`.

**The bug**: `loop-engineering` was placed at position `homebrew-ram` → `loop-engineering` → `ios-trends-2026`. **Alphabetically wrong**: `ios-trends-2026` starts with `i`, which comes BEFORE `l`. Correct order is `homebrew-ram` → `ios-trends-2026` → `interaction-model` → `local-ai-apple-silicon` → `loop-engineering`.

**Detection**: re-read patched `index.md` and noticed the ordering violation.

**Recovery**: second patch that moved `loop-engineering` to between `local-ai-apple-silicon` and `managed-agents`.

**Lesson**: when inserting into `index.md`, **simulate the full alphabetical position BEFORE patching**, not just the immediate neighbors. Read the surrounding 3-4 lines on each side. Watch for:
- `loop-` after `local-` (both start with `l`, sort by full string)
- `production-` after `project-` (`pr` matches, sort by `o` vs `r`)
- `gpt-5-5` (`g-5`) before `gemini-*` (numeric vs alpha)
- Hyphens sort with their character (per SCHEMA.md convention)

## Case 7: Lint script with broken slug resolution wrote 733 broken / 117 orphan counts to log.md (2026-06-14)

**File**: `wiki/log.md` (the lint entry appended on 2026-06-14)

**Intent**: A programmatic lint pass that scans every wiki page, extracts
`[[wikilinks]]`, resolves each link to a target page, and tallies broken
links + orphan pages.

**Bug in the first pass**: the slug-resolution function required
`f"{sec}/{link}"` to match a page literally. It correctly resolved
`[[claude-code]]` → no match. It FAILED to resolve `[[anthropic]]` even
though `entities/anthropic.md` clearly exists, because the literal-string
match required the section prefix to be in the link text, not the slug
alone. The result:

- True broken count: **40** (across 15 pages)
- Reported broken count: **733** (across 113 pages)
- True orphan count: **25**
- Reported orphan count: **117**

**Disaster pattern**: the inflated numbers were written into `log.md`
before double-checking, then required a truncate-and-rewrite of the
whole entry on the same session. `log.md` is append-only per
SCHEMA.md, and the broken entry was a real append — overwritten only
by manual find-and-replace, not by the normal log rules.

**Lesson (count-then-commit)**:

1. **Compute counts in Python, print them, READ them, verify sanity, THEN
   write to log.** A 733 broken count on a 125-page wiki ≈ 5.86 broken
   per page, which is implausible. A 40 broken count ≈ 0.32 per page,
   which is plausible. Sanity-check the order of magnitude.
2. **The slug-resolution function** must accept three shapes:
   - `[[entity-name]]` → try `entities/<name>`, then `concepts/<name>`, etc.
   - `[[concepts/entity-name]]` → use as-is if it matches.
   - `[[entity-name]]` with ambiguous prefix → pick the section that
     actually has a matching file (don't require exact `sec/slug` match).
3. **Always re-run the resolution with sample links** before logging.
   Pick 5 known-existing slugs (e.g. `anthropic`, `gemini`, `qwen`,
   `claude-code`, `hermes-agent`), verify the resolver returns the
   right target for each. If any returns `None`, the resolver is wrong
   and every count downstream is wrong.
3. **log.md is append-only per the wiki SCHEMA.md**. Recovering from a
   bad append requires a find-and-replace patch on the *file*, not on
   the *entry*. The clean recovery pattern:
   - Find the start of the bad entry (`content.find("## [YYYY-MM-DD] lint")`)
   - Truncate everything from that offset onwards: `new_content = content[:start].rstrip() + "\n"`
   - Append the corrected entry
   - Write the whole file back
   This is the only safe way to "edit" an append-only log without
   leaving a torn entry visible.

4. **Per-source-type HTML extraction patterns** (Discourse JSON, GeekNews
   댓글, Medium 403, GitHub raw, YouTube skip) and the macOS shell
   gotchas that burn tool calls (`grep -P` unsupported, etc.) — see
   `references/notion-source-extraction.md` in this skill.

**Test snippet** to validate a resolver before using its counts:

```python
KNOWN = ["anthropic", "gemini", "qwen", "claude-code", "hermes-agent",
         "ai-agents-trends-2026", "mcp-vs-skills"]
for slug in KNOWN:
    target = resolve(slug)
    assert target is not None, f"resolver failed on KNOWN slug {slug}"
    assert os.path.exists(os.path.join(WIKI, target + ".md")), \
        f"resolver returned {target} but file does not exist"
print("resolver OK")
```

---

## Case 8: "Same-week sibling tool pair" — acp-ui vs Cate (2026-06-15)

**Context**: The Notion digest on 2026-06-12 included `formulahendry/acp-ui` (ACP reference client) and the 2026-06-13 digest included `0-AI-UG/Cate` (infinite-canvas IDE). Both are "agent IDE integration" tools that landed within 24 hours of each other. They look unrelated on the surface.

**Pattern recognized**: two tools targeting the same user problem (running multiple agents in one IDE) from **opposite UI directions**:
- `acp-ui` = **list-style unified client** (one entry per agent, switch between them, standardized ACP wrappers)
- `Cate` = **infinite-canvas freeform IDE** (spatial layout, panels float and dock, no fixed structure)

**Wiki treatment**:
- Each got its own entity page (`entities/acp-ui.md`, `entities/cate-canvas-ide.md`) — they are independent products, not a standard+implementation.
- The entity pages cross-link in the "관련" section with a one-line contrast:
  ```
  - [[cate-canvas-ide]] — 2026-06-13 공개. **정반대 UI 방향**: [[acp-ui]] (리스트, 통합 진입점) vs Cate (캔버스, 공간 자유)
  ```
- This contrast is what the user (or future agent) actually wants: "which one fits my workflow?"

**Lesson**: when two same-week tools show up in adjacent Notion digests and look unrelated, **scan for shared category and contrast direction** before creating pages. If both target the same user problem, the contrast is the value. The "list vs canvas" dichotomy is the kind of pattern the wiki should surface — it's the kind of insight a user would want to retrieve later, and it's hard to re-derive from the raw source files alone.

**Miss-able signals**:
- Same week / same digest cluster in `log.md`
- Both have a "default agents" / "supported agents" section
- Both mention the same concept (e.g. agent-IDE integration) in different vocabulary
- UI keywords that are opposites: "list" vs "canvas", "structured" vs "freeform", "centralized" vs "distributed"

## Case 9: Frontmatter split-patch disaster — qwen.md and kimi-k2-6.md (2026-06-15)

**Files**: `entities/qwen.md`, `entities/kimi-k2-6.md`, `entities/ollama.md`, `entities/notebooklm-canvas.md`

**Intent**: update frontmatter `updated:`, add new entries to `sources:`, sometimes revise `tags:` and `title:`.

**Disaster pattern** (qwen.md):
```python
# Step 1: patch to update sources: (works)
patch(old_string="sources: [https://www.aitimes.com/...209163, ...29716]",
      new_string="sources: [...209163, ...29716, raw/articles/local-llm-...]")

# Step 2: patch to update updated: and tags: (DISASTER)
patch(old_string="""
---
title: Qwen (큐원)
created: 2026-04-14
updated: 2026-04-14
type: entity
tags: [model, open-source, company]
sources: [https://...209163, ...29716]
---""",
      new_string="""
---
title: Qwen
created: 2026-04-14
updated: 2026-06-15
type: entity
tags: [alibaba, model, open-source, agent]
sources: [https://...27643, raw/articles/local-llm-...]""")
```

**What went wrong**:
- Step 1 changed `sources:` to include new raw/ entries.
- Step 2's `old_string` had the *old* `sources:` list, but the file now had the *new* one. The `old_string` failed to match → patch returned an error.
- The recovery attempt used a smaller `old_string` (the new frontmatter in full) and a `new_string` that had the right new frontmatter. BUT the recovery's `new_string` had a wrong `title:` ("Qwen" without the "(큐원)" parenthetical) and a different `tags:` list ("alibaba, model, open-source, agent" replacing "model, open-source, company"). These were not what the wiki wanted.
- A second recovery patch was needed to restore the title and tags.

**Realized damage** (before recovery):
- `qwen.md` briefly had `title: Qwen` instead of `title: Qwen (큐원)` and a different `tags:` list.
- `kimi-k2-6.md` had `title: Kimi K2.6 / K2.7-Code` while the index was still linking via `[[kimi-k2-6]]` (slug-based, not title-based — so the index still worked, but Obsidian graph view would show the new title).
- `ollama.md` had a duplicated "## 2026년 경쟁 구도" header from a different recovery patch.

**Safe pattern (single atomic frontmatter patch)**:
```python
patch(
    old_string="""---
title: Qwen (큐원)
created: 2026-04-14
updated: 2026-04-14
type: entity
tags: [model, open-source, company]
sources: [https://www.aitimes.com/news/articleView.html?idxno=209163, https://news.hada.io/topic?id=28609, https://news.hada.io/topic?id=28738, https://news.hada.io/topic?id=28797, https://news.hada.io/topic?id=29716]
---""",
    new_string="""---
title: Qwen (큐원)
created: 2026-04-14
updated: 2026-06-15
type: entity
tags: [model, open-source, company]
sources: [https://www.aitimes.com/news/articleView.html?idxno=209163, https://news.hada.io/topic?id=28609, https://news.hada.io/topic?id=28738, https://news.hada.io/topic?id=28797, https://news.hada.io/topic?id=29716, raw/articles/local-llm-agentic-coding-2026-06-15.md, raw/articles/kimi-k2-7-code-2026-06-15.md, raw/articles/glm-5-2-2026-06-15.md]
---"""
)
```

**General lessons**:
1. **Frontmatter updates must be atomic** — one patch, full frontmatter block. Never split across patches.
2. **Preserve every frontmatter field verbatim** that you didn't intend to change. Title with parenthetical, tag list order, exact source URLs — all need to round-trip.
3. **After ANY frontmatter patch, re-read the file's first 10 lines and verify the entire frontmatter is correct** — title, created, updated, type, tags, sources. One re-read is cheap insurance.
4. **If a patch fails partway** (e.g. step 2's `old_string` doesn't match), the recovery patch must include the *current* state of the file, not the state you *thought* it was in. `read_file` to confirm before re-patching.
5. **Wikilinks are slug-based, not title-based** — the index still resolves `[[kimi-k2-6]]` even if the title changed to "Kimi K2.6 / K2.7-Code". This is fortunate (didn't break the index) but misleading (Obsidian graph view shows the new title while the link still works). If you want to change the displayed title without breaking Obsidian, just change the title; the slug (file name) is what matters for the wikilink resolution.

**Case 11 verified clean (2026-06-15 sync, 7 pages updated)**: The atomic-frontmatter rule was applied to 7 existing pages in a single sync session — each page's `title` + `created` + `updated` + `type` + `tags` + `sources` was patched in a single old_string/new_string pair, no splits. Files touched: `ai-agents-trends-2026.md`, `mcp-vs-skills.md`, `local-llm-agentic-coding.md`, `china-ai-lab-culture.md`, `vibe-coding.md`, `oh-my-harness.md`, `agent-client-protocol.md`. Post-patch re-read confirmed: (a) every `updated:` field bumped to 2026-06-23, (b) titles round-tripped verbatim (including Korean parentheticals like "결정론적 하니스 — 로컬 LLM 코딩 6배 품질 패턴"), (c) no orphaned section headers, (d) no shrunk tag lists. The lesson in this case study is operational, not theoretical — apply it on every sync that touches frontmatter.

## Case 14: Frontmatter rewrite via patch-derive loses `created:` and `tags:` (2026-06-29)

**Files affected**: `siri-ai-agent.md`, `verification-tax.md`, `gpt-5-5.md` (all in this single sync).

**Intent**: Update `updated:` to today and add new entries to `sources:` after a content patch already ran.

**Disaster pattern** (the shape is different from Case 9 — this one is a *derived* frontmatter rather than a planned multi-step sequence):

```python
# Step 1 (works): update content section
patch(
    old_string="## 배포\n\n- **GitHub Copilot 개인 사용자 VS Code**에서 사용 가능\n...",
    new_string="## 배포\n\n- **GitHub Copilot 개인 사용자 VS Code**에서 사용 가능\n...\n\n## 2026-06-26 동향 — ...\n..."
)

# Step 2 (DISASTER): patch frontmatter — old_string is the CURRENT state,
# but new_string is a RE-DERIVED version typed from memory, not from read_file.
patch(
    old_string="""---
title: Siri AI Agent
created: 2026-05-14
updated: 2026-06-09
type: entity
tags: [ios, apple, ai-agent, voice-assistant]
sources: [https://www.aitimes.com/..., https://www.aitimes.com/...]
---""",
    new_string="""---
title: Siri AI Agent
created: 2026-04-09      # ← WRONG, was 2026-05-14
updated: 2026-06-29
type: entity
tags: [apple, ios, agent, voice, siri]  # ← WRONG, was [ios, apple, ai-agent, voice-assistant]
sources: [https://www.aitimes.com/..., ..., raw/articles/apple-m7-2026-06-29.md]
---"""
)
```

**What went wrong**:
- The agent *knew* the original frontmatter from earlier in the session, but re-typed it from memory in the `new_string`. The re-typed version had wrong `created:` (used a date from a different file), wrong `tags:` (re-ordered and partially replaced), and lost the original tag list shape.
- This is **not** a multi-step split-patch problem (that's Case 9). It's a **single patch that silently re-derives frontmatter from a faulty memory** rather than from a `read_file` of the current state.

**Damage in this session** (all three files):
- `siri-ai-agent.md`: `created: 2026-05-14` → `2026-04-09` (wrong by 35 days), `tags: [ios, apple, ai-agent, voice-assistant]` → `[apple, ios, agent, voice, siri]` (lost `ai-agent` tag, gained `agent`/`siri` redundantly)
- `verification-tax.md`: lost the long-form title `"Verification Tax (검증 세금) — AI J-Curve Trap과 3대 부채"` → shrunk to `"Verification Tax"`, `tags:` lost `market-trend, alignment` and gained unrelated `ai, verification, meta`
- `gpt-5-5.md`: lost the parenthesized form `"GPT-5.5 (Spud)"` → `"GPT-5.5"`, `tags:` lost `benchmark, multimodal` and gained a bare `comparison`

**Detection**: After the patch sequence, ran a verify pass and noticed the SCHEMA.md title (Korean parenthetical) was missing from the page. Re-read the file's first 10 lines.

**Recovery**: three more patches, one per file, restoring the original frontmatter fields verbatim.

**Why this differs from Case 9** (which was about *splitting* the frontmatter update across multiple patches):
- Case 9 = multiple patches, each touching one frontmatter field, where step 2's `old_string` doesn't match the post-step-1 state.
- Case 14 = single patch, but the agent re-derives the `new_string` from memory instead of from a `read_file` of the current state. The patch is "atomic" but the *derivation* is lossy.

**Safe pattern — read_file before every frontmatter patch**:
```python
# Step 1: read the CURRENT frontmatter, not what you remember it as
with open(fp) as fh:
    head = "".join([next(fh) for _ in range(8)])  # first 8 lines
# Now you see the EXACT current `created:`, `tags:`, `title:`, `sources:`.

# Step 2: patch using the current frontmatter as old_string, full block in new_string
patch(
    old_string=head,  # actual current state
    new_string="""---
title: Siri AI Agent
created: 2026-05-14      # ← COPIED from the read_file, not from memory
updated: 2026-06-29
type: entity
tags: [ios, apple, ai-agent, voice-assistant]  # ← COPIED, not re-derived
sources: [https://www.aitimes.com/..., ..., raw/articles/apple-m7-2026-06-29.md]
---"""
)
```

**Three sub-rules**:
1. **Never type frontmatter values from memory in a patch.** Always `read_file` first, even if you "just looked at it 5 minutes ago." Memory of frontmatter is lossy — dates blur, tag orders shuffle, parentheticals drop.
2. **If the frontmatter has a long-form `title:`** (e.g. `"Verification Tax (검증 세금) — AI J-Curve Trap과 3대 부채"`), copy it byte-for-byte. Don't "shorten it for cleanliness" during a date-bump patch — that's a different edit, do it separately and intentionally.
3. **Re-read the file's first 10 lines after EVERY frontmatter patch**, not just after multi-step ones. The patch may have succeeded but the content may be wrong. This is the cheapest insurance in the patch toolkit.

**Generalization**: the rule is "treat frontmatter as immutable, not as something you can rephrase in passing." Any time a patch touches frontmatter — even just `updated:` — the *other* fields are at risk of silent corruption. The "atomic frontmatter patch" rule (Case 9) only protects against ordering bugs; Case 14's rule protects against memory-loss bugs. Both are needed.

**Verified clean (2026-06-29 sync recovery)**: After hitting this on `siri-ai-agent.md` first, the agent read each subsequent file's current frontmatter before patching. Files patched cleanly on retry: `verification-tax.md` (recovery), `gpt-5-5.md` (recovery), `siri-ai-agent.md` (recovery). The lesson: treat `read_file` of the current frontmatter as a *mandatory precursor* to any frontmatter patch, regardless of how confident you are in your memory of the file.

## Case 15: `write_file` after partial read + "Found N matches" cascade → file clobbered (2026-06-30)

**File**: `concepts/qwen3-6-27b.md` (an existing ~113-line concept page).

**Intent**: Update the frontmatter (`updated:`, `sources:`), then add a "## Quesma 3rd-party 실전 평가 (2026-06-30 추가)" section near the bottom, then update the "## 관련 엔티티" list and "## 출처" list.

**Disaster sequence (4-step cascade)**:

### Step 1: Frontmatter patch worked cleanly
```python
patch(old_string="""---
title: Qwen3.6-27B
created: 2026-04-24
updated: 2026-04-24
type: concept
tags: [model, qwen, dense, agentic-coding, open-source, multimodal]
sources: [raw/articles/qwen3-6-27b-2026-04-24.md]
---""", new_string="""---
title: Qwen3.6-27B
created: 2026-04-24
updated: 2026-06-30
type: concept
tags: [model, qwen, dense, agentic-coding, open-source, multimodal]
sources:
  - raw/articles/qwen3-6-27b-2026-04-24.md
  - raw/articles/qwen3-6-local-dev-2026-06-30.md
---""")
```
✓ Worked.

### Step 2: "Found 2 matches" — body patch with a non-unique anchor
```python
# WRONG — `## 출처` section header appeared once as the actual section,
# but a later `## 출처` had a multi-line list with similar pattern, creating
# ambiguity when only one line was used as old_string.
patch(old_string="## 출처\n- GeekNews: [Qwen3.6-27B: 270억 dense 모델...]...",
      new_string="## Quesma 3rd-party 실전 평가...\n## 출처\n...")
```
**Error**: `Found 2 matches for old_string. Provide more context to make it unique, or use replace_all=True.`

### Step 3: Wider patch succeeded but **mislocated** the new section
```python
# Wider old_string (added the unique "## 관련 엔티티" section above as anchor)
patch(old_string="""## 관련 엔티티
- [[qwen]] — 개발사 및 모델 시리즈
- [[alibaba]] — 모회사
- [[openclaw]] — 통합 코딩 에이전트
- [[qwen-code]] — 터미널 에이전트
- [[claude-code]] — 통합 지원 도구

## 출처
- GeekNews: [Qwen3.6-27B: 270 억 dense 모델..."",
      new_string="""## Quesma 3rd-party 실전 평가 (2026-06-30 추가)

... [new section content]

→ [[local-llm-agentic-coding]] 의 권위 있는 사례로 인용 가능

## 관련 엔티티
- [[qwen]] — 개발사 및 모델 시리즈
- ... (rest unchanged)

## 출처
- GeekNews: [Qwen3.6-27B: 270 억 dense 모델...""")
```
✓ Worked, **but the new "## Quesma 3rd-party 실전 평가" section landed BEFORE "## 관련 엔티티"**, breaking the logical flow. The file was now:
```
[frontmatter]
# Qwen3.6-27B
## 핵심 특징
## 성능 벤치마크
## 주요 성과
## 활용 방법
## 환경 변수 예시
## Quesma 3rd-party 실전 평가 (NEW — but in the middle!)  ← wrong position
[no separator here]
## 관련 엔티티
## 출처
```

### Step 4: `write_file` to fully rewrite the file — **clobbered it**
The agent decided the partial patch result was too messy and tried a full `write_file` rewrite. The agent had only seen lines 100+ via `read_file(..., offset=100, limit=200)` and **did not re-read the whole file** before rewriting. The `write_file` tool warning explicitly said:
> "was last read with offset/limit pagination (partial view). Re-read the whole file before overwriting it."

The agent overwrote anyway. **The new file was missing the lines that lived in offsets 1-99** (which were the frontmatter + the entire body of sections up to "## 환경 변수 예시"). The new content was also truncated mid-string (`<your_...` instead of `<your_key>`) — a copy-paste artifact from the partial view.

**Final damage**:
- File structure had the Quesma section inserted between 환경 변수 예시 and 관련 엔티티, breaking logical flow
- "## 관련 엔티티" header appeared twice (the new section came BEFORE it, and the original section still existed)
- "## 출처" list ended up with a duplicated final entry
- The "## 환경 변수 예시" code block was truncated (`<your_...` instead of `<your_key>`)

### Recovery (3-step)
1. **Re-read the whole file** with `read_file(..., limit=2000)` to see the actual broken state.
2. Three more patches: (a) remove the duplicated "## 관련 엔티티" header, (b) move the Quesma section to its correct position AFTER "## 환경 변수 예시", (c) restore the truncated code block.
3. Final `read_file` end-to-end to verify section count and headers.

**General lessons (5)**:

1. **"Found N matches" usually means you need MORE context in `old_string`, not LESS**. Don't fall back to `write_file` after a match failure — extend the `old_string` to include the unique section above or below the intended insertion point. The partial read+rewrite path is strictly worse than the wider-patch path.

2. **When `write_file` warns "last read with offset/limit pagination" — STOP and re-read the whole file**. The warning is not optional. The first ~99 lines of a 113-line file were invisible to the agent, and the rewrite silently dropped them.

3. **Never use `write_file` to "clean up" a partial-patch result unless you have read the ENTIRE file end-to-end**. The cost of full re-read (one tool call) is much less than the cost of detecting and repairing dropped sections.

4. **Section ordering matters for readability**. A patch that puts the new section BEFORE an existing section that's logically "before" creates a non-linear file. Even if the patch succeeds, **re-read the file** to verify section order is logical.

5. **The "patch → patch → patch → write_file" cascade is a red flag**. If you find yourself making 3+ patches and then a full rewrite on the same file in one session, STOP and re-read the file. Either the file needs its own session, or you should have rewritten from the start with full context.

**Safe pattern for "Found N matches" recovery**:
```python
# Don't: try a smaller old_string or switch to write_file
# Do: extend old_string upward OR downward by 1-2 unique lines

# Read the file at the match location
content = read_file(WIKI + "/concepts/qwen3-6-27b.md")
lines = content.split("\n")
# Find both occurrences of the ambiguous header
for i, line in enumerate(lines):
    if "## 출처" in line:
        print(f"line {i+1}: {lines[i]!r}")
        print(f"  context above: {lines[i-2:i]}")
        print(f"  context below: {lines[i+1:i+3]}")
# Then patch with the one whose surrounding context matches your intent.
```

**Safe pattern for full-rewrite after a patch cascade**:
```python
# Step 1: read the WHOLE file, no offset/limit
full_content = read_file(WIKI + "/concepts/qwen3-6-27b.md", limit=2000)
# Step 2: write_file with the full_content as the base, not a partial view
write_file(WIKI + "/concepts/qwen3-6-27b.md",
           content=full_content + "\n\n## Quesma 3rd-party 실전 평가...\n- ...\n")
# Step 3: read_file end-to-end to verify
```

**Verified recovery (2026-06-30 sync)**: After hitting this on `qwen3-6-27b.md` first, the agent applied the safe pattern to the remaining 3 updates (`glm-5-2.md`, `github-copilot.md`, `loop-engineering.md` backlink). All three were patched cleanly without any "Found N matches" or `write_file` clobber. The lesson transferred directly: use single atomic frontmatter patches, anchor body patches on unique content, and re-read files after every structural patch.

## Case 10: "## 관련" / shared section header → patch ambiguity (2026-06-15)

**Files affected this session**: `anthropic.md`, `notebooklm-canvas.md`, `gemma-4.md`, `ollama.md`, `opencode-contexty.md`, `qwen3-7-max.md`, `local-ai-apple-silicon.md`.

**The pattern**: When the patch's `old_string` ends at a shared section header like `## 관련\n` (header + newline), the patch tool may match *before* the body content of the section, and the `new_string`'s section header + new bullets land either (a) before the existing bullets, or (b) duplicated if the `new_string` also includes `## 관련`.

**Example disaster**:
```python
# WRONG — old_string is just the header + blank line
patch(
    old_string="## 관련\n\n",
    new_string="## 관련\n- [[new-thing]] — ...\n"
)
```

This either:
- Replaces the blank line after `## 관련` with `## 관련\n- [[new-thing]]...\n`, leaving the original bullets below and the new one above (two `## 관련` lines if the new_string has it).
- Or matches an ambiguous position and produces a duplicated header.

**Same shape happened 5+ times this session** with headers like `## 관련`, `## 기반 모델`, `## 2026년 경쟁 구도`, `## Links`, `## Related`. The recovery was always a follow-up patch to remove the duplicated header or restore the missing body.

**Safe pattern — anchor on a unique last bullet or distinctive body line**:
```python
# RIGHT — old_string includes the last existing bullet (unique enough)
patch(
    old_string="- [[claude-cowork]] — 자율 업무 에이전트\n",
    new_string="- [[claude-cowork]] — 자율 업무 에이전트\n- [[new-thing]] — 새 백링크\n"
)
```

This appends a new bullet AFTER the unique anchor bullet. The `## 관련` header is preserved (not in the matched range at all), and the new bullet lands in the right place.

**If you must reference the section header in `old_string`** (e.g. you want to add a new section, not just a bullet), include at least 1-2 unique body lines after the header so the match is unambiguous. See Case 4 for the canonical version of this pattern.

**Generalization**: any section header that appears in multiple files is a "non-unique anchor". Always include distinctive body content. The patch tool's fuzzy matching can save you in some cases, but explicit uniqueness is far safer.

## Case 12: Partial-overlap mixed batch with ✅신규 / ⏭️이미처리 split (2026-06-17)

**Context**: Notion digest returned 5 items. The previous sync (2026-06-16) had already processed 3 of them — those items reappeared because `notion_news_to_wiki.py` doesn't mark processed items in Notion (a known issue, Case 3). A 4th item was a Korean startup-insight article outside the owner's interest domain. Only 1 item was truly new.

**Detection procedure**:

```python
import re
log = open(WIKI + "/log.md").read()
recent_entries = re.findall(
    r"## \[(\d{4}-\d{2}-\d{2})\] ingest[^\n]*\n(.*?)(?=\n## |\Z)",
    log, re.DOTALL,
)
most_recent_date, most_recent_body = recent_entries[0]
already_processed_slugs = set(re.findall(
    r"raw/articles/([\w-]+)-\d{4}-\d{2}-\d{2}\.md", most_recent_body
))

for item in digest:
    item_slug = slugify(item.title)
    if item_slug in already_processed_slugs:
        classify_as = "⏭️ 이미 처리됨"
    elif outside_domain(item):
        classify_as = "Skipped (관심사 범위 외)"
    else:
        classify_as = "✅ 신규"
```

**Log entry structure** — the user reads this entry directly, so the split must be visually explicit:

```markdown
## [2026-06-17] ingest | Notion Dev News → LLM Wiki 동기화
- Source: Notion 뉴스 클리핑 DB (5건, 2026-06-16/17 추가분)
- **처리**: 5건 중 **1건만 신규**, 4건은 이전 동기화에서 이미 처리됨
  - ✅ **신규**: `vectorize-io/hindsight` — biomimetic 에이전트 메모리 (SOTA, MIT 16.5k stars)
  - ⏭️ **이미 처리됨** (2026-06-16 동기화에서 등록):
    `hera-agent-unity` (entities/hera-agent-unity.md),
    `perfectpixel-studio` (entities/perfectpixel-studio.md),
    AI/ML 논문 주간 다이제스트 (concepts/ai-ml-papers-weekly.md)
  - ⏭️ **Skipped (관심사 범위 외)**: 창업지원사업 검색 서비스 (한국 스타트업 인사이트)
```

**Why the explicit split matters** (silent skipping is a black box):
- The user reads the log to understand "what got registered TODAY" — a digest of 5 items with 1 ✅신규 + 4 ⏭️ in plain text makes this instantly readable.
- The previous sync date and the existing raw/ file path must be cited for each ⏭️ entry, so the user can verify by `ls raw/articles/`.
- "Skipped (관심사 범위 외)" with a one-line reason is better than silent exclusion — the user might disagree with the skip and want to override.

**When to log "no-op" vs "partial-overlap"**:
- **All N items are duplicates** → log `## [YYYY-MM-DD] ingest | no-op — N items already processed on <date>` and stop (Case 3 pattern).
- **Some items are duplicates** → log the full mixed-batch entry above. **Do NOT collapse to no-op just because "most items are duplicates"** — the collector script's "신규 항목: N건" count is the *digest size*, not the *work size*. The agent's ✅신규 count is the actual work done and is the number that should go in the user report's lead paragraph.

**Companion pattern — comparison page evolution (extend, don't rewrite)**:

When a major new entry arrives and an existing 3-way comparison page becomes a 4-way (e.g. `comparisons/agent-memory-comparison.md` had RAG / LLM Wiki / Agent Memory, now needs Hindsight), the right move is:
1. Keep the original 3-way table intact (don't rewrite — the historical framing has value).
2. APPEND a new section titled "## 2026-06 추가: 제4의 축 — <New paradigm>".
3. In the new section, present a fresh 4-way table + extended selection framework.
4. Add the new entity to the "관련 개념" list at the bottom with `frontmatter.updated` bumped and `sources` extended.

This way readers see both the original framing (RAG vs LLM Wiki vs Agent Memory) and the new framing (4-way) — the wiki captures the **evolution** of the comparison, not just the latest snapshot.

**Don't**: replace the 3-way table with a 4-way table. The original table documents how the field looked before Hindsight arrived. Erasing it loses the temporal context that makes the wiki a knowledge base rather than a snapshot.

## Case 13: Case 4 / Case 10 hazard re-tripped — duplicate header in body update (2026-06-17)

**File**: `entities/agentmemory.md`

**Intent**: Add a backlink to the new `[[hindsight]]` entity in the existing "관련 개념/도구" section.

**The mistake**: First patch correctly updated the frontmatter (`updated:` and `sources:`). Second patch added the backlink to the body. **But the second patch's `old_string` was `"## 관련 개념/도구\n\n"` (just the header + blank line)** — Case 4's exact anti-pattern.

**Result**: the patch tool matched the blank line after `## 관련 개념/도구`, producing a **partial duplication** — the file looked like:

```markdown
## 관련 개념/도구
## 관련 개념/도구
- [[hindsight]] — biomimetic 메모리 (World/Experiences/Mental Models, LongMemEval SOTA)
- [[context-mode]] — 컨텍스트 윈도우를 98% 절감하는 MCP 서버
- [[agent-memory-comparison]] — RAG vs LLM Wiki vs Agent Memory 비교
```

**Detection**: re-read the patched file end-to-end after the body patch (per Case 1's "re-read patched file" rule). Noticed the duplicated `## 관련 개념/도구`.

**Recovery**: third patch that matched the duplicated header pair and removed one. Two extra tool calls than necessary.

**Why I re-tripped Case 4** despite having read the case study moments before:
- The section header `## 관련 개념/도구` is not as generic as `## 관련` (Case 10's example), so the mental model "this header is unique to this file" was tempting but wrong — I was conflating *uniqueness-in-this-file* with *uniqueness-as-anchor-for-a-patch-tool*.
- The body bullets in this file were short Korean lines I didn't have memorized, so anchoring on the last bullet felt riskier than anchoring on the header. That reasoning is backwards: **a unique last bullet is the safest anchor, period**.

**Updated safe pattern** (Case 4 + Case 10 reinforced):

```python
# WRONG (what I did):
patch(old_string="## 관련 개념/도구\n\n",
      new_string="## 관련 개념/도구\n- [[hindsight]] — biomimetic 메모리 ...\n")

# RIGHT (anchor on the LAST bullet, not the header):
patch(old_string="- [[tri-attention]] — KV 캐시 메모리 최적화 아키텍처\n",
      new_string="- [[tri-attention]] — KV 캐시 메모리 최적화 아키텍처\n- [[hindsight]] — biomimetic 메모리 ...\n")
```

**Generalization**: the last bullet of a section is almost always unique within the file (each bullet has distinct content). The section header is unique within the file but **not unique as a patch anchor** because the patch tool's match can land on the blank line after the header rather than the body content. Always anchor on the LAST EXISTING BULLET when adding to a list. This is non-negotiable.

**Cross-reference**: Case 4 (backlink bullet insertion), Case 10 (shared section header). This case is the **compound form** — header that's *unique to the file* but still wrong as a patch anchor. The lesson generalizes to all "append to a list" patches.

## Case 11: Deferred `index.md` / `log.md` updates from tool-call budget exhaustion (2026-06-15)

**Context**: A 6-item Notion digest was processed in a single session. 5 new entity/concept pages were created and 11 existing pages were updated, but the session ran out of tool-call budget before `index.md` and `log.md` could be updated.

**Damage**:
- `index.md` header still says "Last updated: 2026-06-12" and "Total pages: 123" even though 5 new pages exist and the true count is 128.
- The 5 new pages (`glm-5-2`, `cate-canvas-ide`, `local-llm-agentic-coding`, `fable-incident`, `notebooklm-mcp-server`) are not listed in `index.md` under any section. **They are functionally undiscoverable** via the index, even though they exist on disk with full content and cross-links.
- `log.md` has no entry for 2026-06-15. The audit trail is broken — a future lint run cannot tell which pages were last touched and when.

**Mitigations attempted**:
- Final report explicitly listed "미완료 항목" (unfinished items) and surfaced "log.md 갱신" and "index.md 갱신" as high-priority follow-ups.
- This is necessary but not sufficient — the user has to notice and act on it.

**Lesson (call budget planning)**:
1. **Budget the last 2-3 tool calls for navigation updates** (`index.md` and `log.md`). They are not optional; they are the navigational backbone. A wiki with rich content but no index is not a wiki, it's a pile of files.
2. **If you realize mid-session that budget is running out, drop the lowest-value content updates first** — e.g. drop optional "Related" backlink additions, keep the new page creation and the mandatory index/log updates. The backlinks can be filled in by next session's lint; missing index entries are a navigational blackout.
3. **NEVER defer index/log updates silently.** If you must defer, mark the wiki with a visible flag (top of `index.md` saying `<!-- PARTIAL SYNC: index/log NOT updated for 2026-06-15 -->`) and surface this prominently in the report. A torn state with a clear flag is recoverable; a torn state without one is not.
4. **In cron contexts specifically**, an incomplete sync that doesn't update the log is *worse* than a no-op — the next run will see the same items in the Notion digest (collector script doesn't mark processed), and the idempotency check in the skill will not detect the duplicates because the log entry never landed. The cron will spin forever re-processing the same items. Always update `log.md` even if you have to skip `index.md` (and add a "INDEX NOT UPDATED" note in the log entry).
