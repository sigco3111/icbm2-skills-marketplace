# Notion Dev News Sync — Patterns & Templates

Operational patterns that emerged from repeated Notion-collector → LLM-Wiki
sync runs (2026-04-09 through 2026-06-24, ~20 sync sessions). The
`patch-disaster-case-studies.md` companion file documents patch-tool
disasters; this file documents the **end-to-end sync workflow patterns**
that the patch disasters taught us to use.

## 1. 3-Way Split Log Entry Format

Every sync entry should split work into three explicit buckets so the
user can see at a glance what actually happened:

| Bucket | Symbol | Meaning | Action taken |
|---|---|---|---|
| **신규** | ✅ | Genuinely new content, not seen before | Full fetch + page create/update + index/log |
| **이미 처리됨** | ⏭️ | Appears in current digest but was registered in a previous sync | Cite the previous sync date + the existing raw file path. No re-work. |
| **등록 기준 미달** | 🚫 | Evaluated and intentionally skipped | Cite the rule from `SKILL.md` "Common skipping rules". Write a `raw/articles/<slug>-skip-YYYY-MM-DD.md` with the reason. |

**Why 3-way, not 2-way**: Case 12 (2026-06-17) introduced the 2-way ✅/⏭️
split. The 🚫 bucket was added on 2026-06-24 when a single-YouTube-heavy
digest (3 out of 9 items were unwatchable single videos) showed that
conflating "already registered" with "deliberately skipped" hides the
decision. The user reading the log needs to see both buckets separately
because the actions are different (no work for ⏭️, evaluated decision for
🚫) and the user might disagree with the 🚫 decision and want to override.

**Verified working template (2026-06-24, 9 items → 2 신규 + 4 ⏭️ + 3 🚫)**:

```markdown
## [2026-06-24] ingest | Notion Dev News → LLM Wiki 동기화
- Source: Notion 뉴스 클리핑 DB (9건, 2026-06-24)
- **처리**: 9건 중 **2건 신규**, 4건은 2026-06-23 동기화에서 이미 처리됨, 3건은 Wiki 등록 기준 미달
  - ✅ **신규**: `moebius`, `nvidia-nim-80-models-free` (nvidia-nim 페이지에 통합)
  - ⏭️ **이미 처리됨 (2026-06-23)**: `bigset` → [[bigset]], `agent-connector` → [[agent-connector]],
    `repolis` → [[repolis]], `agent-blackbox` → [[agent-blackbox]] (2026-06-23 동기화에서 이미 반영)
  - 🚫 **등록 기준 미달**: `Gajae-Code` (단일 YouTube 영상, 스크립트 미공개),
    `Ponytail 스킬` (단일 YouTube 영상, 5만 스타 언급만),
    `하네스 LazyCodex` (단일 YouTube 영상, 스크립트 미공개)
- **Raw sources added**: ...
- **Entity pages created**: ...
- **Entity pages updated**: ...
- **Concept/Comparison pages updated**: ...
- **Index.md 갱신**: Last updated ... → ..., Total pages ... → ...
- **Total pages**: ...
- **의미**: ...  (synthesis)
- **권고**: ...  (actionable follow-ups)
```

## 2. Skip-With-Raw-File Pattern

The skill's `SKILL.md` "Common skipping rules" lists 6 categories of items
to skip. The `SKILL.md` previously did NOT specify what to do with the
URL/source afterward. The verified pattern (2026-06-24) is:

**When skipping, ALWAYS write a `raw/articles/<slug>-skip-YYYY-MM-DD.md`**
with `fetch_status: not_extracted` and `skip_reason: <rule>`.

### Skip-file template

```markdown
---
title: <Item Title> (skip)
date: YYYY-MM-DD
source: <original URL>
fetch_status: not_extracted
skip_reason: <one-line rule citation from Common skipping rules>
---

# <Item Title> (Wiki 등록 보류)

## 등록 보류 사유
- <exact rule from SKILL.md that triggered the skip, e.g. "Single video tutorial - YouTube 스크립트 추출 불가">

## 인덱스 메모
- <optional: any forward-looking note, e.g. "Ponytail 5만 스타 스킬은 [[oh-my-harness]] 생태계의 한 축으로 추적할 가치는 있으나, 스크립트 미공개로 구체적 기능 확인 불가">
- <optional: re-evaluation trigger, e.g. "후속 영상 스크립트나 GitHub README가 공개되면 재검토">

## 출처
- <original URL(s)>
```

### Why this matters

1. **Audit trail**: `ls raw/articles/` shows the URL was at least captured
2. **Re-evaluation trigger**: if the source later becomes extractable
   (YouTube adds captions, blog updates, follow-up article), the agent has
   the URL to re-fetch from — no need for the user to re-paste it
3. **Decision visibility**: the user reading the log can see WHY each
   item was skipped and override the decision if they disagree
4. **No silent skips**: silent skips become a black box — the URL is
   forgotten, the decision rationale is lost, and the item reappears
   in the next Notion digest with no way to recall "we already considered
   this on YYYY-MM-DD and decided 🚫"

### Verified skip-file

`raw/articles/gajae-ponytail-lazycodex-skip-2026-06-24.md` — bundled 3
single-YouTube skips into one file with shared `skip_reason` and
per-item notes. This is a valid compression: when N items share the
same skip reason, one skip-file with N sub-sections is cleaner than N
separate skip-files.

### Cross-digest skip-file reuse (verified 2026-06-25)

When the Notion collector script re-emits the same skip-worthy items in
a subsequent digest (because Notion doesn't mark processed), the
3-way split's ⏭️ bucket should **reference the existing skip-file path**
rather than re-write the same content. Verified pattern (2026-06-24
sync created the skip file → 2026-06-25 sync reused it):

```
- 🚫 **등록 기준 미달** (단일 YouTube 영상, 스크립트 미공개):
  - `Gajae-Code` → 기존 skip 파일 `raw/articles/gajae-ponytail-lazycodex-skip-2026-06-24.md`
    에 이미 skip 사유 기록됨
  - `LazyCodex 하네스 사용법` → 동일 skip 파일
  - `Ponytail 5만 스타 스킬` → 동일 skip 파일
```

This compression keeps the log readable: the user sees 3 items were
skipped with one click-back to the rationale, instead of 3 repeated
"단일 YouTube 영상, 스크립트 미공개" bullet blocks. The skip-file is
the durable record; the log entry is a pointer.

**Important distinction** — ⏭️ (already registered) and 🚫 (skip-file
reuse) are *different* buckets even though both involve "no work this
sync":
- ⏭️ = full entity/concept page exists, may have additional context worth a re-check
- 🚫 (skip-file reuse) = URL is recorded with rationale, no page will ever exist
Don't merge them — the user's review decision is different for each.

## 3. Consolidation Pattern — "Recognized Industry Concept + Scattered Mentions" (added 2026-06-25)

When a single source article uses a named, industry-recognized concept
(e.g. "Verification Tax", "AI J-curve Trap", "3대 부채") AND the
concept is already mentioned in passing across 2+ existing wiki pages
(e.g. `[[production-prompt]]`, `[[ai-agents-trends-2026]]`), the
correct response is **consolidate, don't fragment**.

### Procedure

1. **Create one dedicated concept page** (`concepts/<concept>.md`)
   even though the source is a single article. The Page Thresholds
   "central to one source" criterion is satisfied: the central named
   concept of that single source IS the page.
2. **Add backlinks from each scattered page** (1-2 line additions
   pointing to the new concept page). This converges the wiki's
   knowledge graph on the new page.
3. **Add a "Related Concepts" section in the new page** listing each
   scattered page that referenced the concept. This gives future
   readers a navigation trail.
4. **Save the raw source** with `fetch_status: ok` (it's a normal
   fetchable URL, not a Notion JS-only edge case).

### Verified example (2026-06-25)

- Source: GeekNews slide-deck article "AI시대, 나의 전문성을 재설계하는 법" (165P)
- Named concept: **Verification Tax** (AI J-Curve Trap + 3대 부채 + AI Native Company 3조건)
- Pre-existing scattered mentions: `[[production-prompt]]` (프롬프트 엔지니어링 의존도 감소),
  `[[ai-agents-trends-2026]]` (프롬프트 엔지니어링 진화 4단계)
- Action: created `concepts/verification-tax.md` (3대 부채 + 3대 검증 레이어 + 3대 강점 종합)
- Backlinks added: `production-prompt.md` gained "인접 컨셉: Verification Tax" section;
  `ai-agents-trends-2026.md` gained section 24 in the timeline
- Result: future syncs citing "Verification Tax" can wikilink the new
  page instead of fragmenting across the older ones

### When NOT to consolidate

- The named concept appears only once in the wiki → just add to that page
- The source itself is borderline for inclusion (single YouTube,
  vague description) → skip per Common skipping rules
- The existing pages already have a section titled with the concept
  → consolidation would create duplicates; just add the new info to
  the existing section

## 4. Update-Existing-Entity vs. Create-New-Page Decision Rule

When a new source provides supplementary context to an existing entity,
the default is to **update the existing page** with a new section, not
to create `<entity>-<subtopic>.md`.

### Decision rule

- ❌ **Create new page** when: (a) the subtopic is its own coherent
  product/concept with a distinct identity (different product, different
  concept, different team), OR (b) the existing page would grow past
  200 lines (the `Page Thresholds` split threshold)
- ✅ **Update existing page** when: new article about the same product
  with new context. Bump `updated:`, extend `sources:`, add a new
  section to body.

### Examples from 2026-06-24

- `nvidia-nim.md` + new article "NIM now offers 80+ models for free"
  → **Updated** `nvidia-nim.md` (38 → 44 lines, well under 200)
  - Added a "80+ 모델 무료 API" bullet to "주요 특징"
  - Added a "무료 프로덕션급 모델" row to "2026년 경쟁 구도"
  - Added 2 backlinks ([[minimax-m2]], [[deepseek-v4]]) to "관련_concept"
  - Extended `sources:` in frontmatter
- A new NIM sub-product (hypothetical "NIM Edge" device) would be a
  **new page** → `entities/nvidia-nim-edge.md`

### Why this matters

Creating a sub-slug page (e.g. `nvidia-nim-80-free.md`) for what is
really the same product pollutes the index, splits the "what is NIM"
narrative across 2+ pages, and confuses Obsidian graph view (one node
per page, when conceptually it's one product). The wiki should reflect
the model, not the news cycle.

## 5. Idempotency Check — Most-Recent Sync

Before processing any digest, do this:

```python
import re
log = open(WIKI + "/log.md").read()
# Find the most recent ingest entry (not lint/update)
entries = re.findall(
    r"## \[(\d{4}-\d{2}-\d{2})\] ingest \| ([^\n]+)\n(.*?)(?=\n## |\Z)",
    log, re.DOTALL,
)
if not entries:
    # No prior sync — proceed
    pass
else:
    most_recent_date, most_recent_title, most_recent_body = entries[-1]
    # Check if every item in the current digest appears in most_recent_body
    ...
```

Case 3 (2026-06-05) and Case 12 (2026-06-17) document the no-op and
partial-overlap variants. The hard rule from Case 12:

> The collector script's "신규 항목: N건" count is the *digest size*, not
> the *work size*. The agent's ✅신규 count is the actual work done and
> is the number that should go in the user report's lead paragraph.

Don't conflate digest size with work size. A 9-item digest with 2 ✅신규
is a 2-item work session, not a 9-item one.

## 6. Per-Session Tool-Call Budget

The skill's Case 11 (2026-06-15) is the canonical reference. The
operational rule:

**Reserve the LAST 2-3 tool calls of every session for `index.md` and
`log.md` updates.** If you realize mid-session that budget is running
out, drop the lowest-value content updates first (optional backlinks,
optional "의미" sections), keep the new page creation and the mandatory
index/log updates. The backlinks can be filled in by the next session's
lint; missing index entries are a navigational blackout.

A 9-item digest producing 1 new entity + 3 updated pages + 1 skip-file
fits comfortably in ~20-25 tool calls:
- 3-4 calls: orientation (read SCHEMA, index, log tail, search existing pages)
- 1 call per fetch: ~3-4 fetches (DDG or similar)
- 1 call per write: 1 new entity + 3 page updates + 1 skip-file = 5 writes
- 2-3 calls: index.md + log.md updates + verification re-reads
- Buffer: 3-5 calls for retries or unexpected patches

If a session exceeds 30 calls without `log.md` updated, **stop and
update the log NOW** before doing anything else. An incomplete sync
with a log entry is recoverable; an incomplete sync without a log
entry is the cron-spin trap.

## 7. Pre-Write `ls` Wikilink Verification

The skill's main `SKILL.md` mandates this. Companion pattern for
single-file verification:

```bash
# For each [[wikilink]] in your draft, check the slug exists
ls ~/wiki/entities/ | grep -F "<slug>"
ls ~/wiki/concepts/ | grep -F "<slug>"
ls ~/wiki/comparisons/ | grep -F "<slug>"
```

If any `[[link]]` slug returns no match, either:
- **CREATE the target page first** (if the concept is real and central)
- **Convert to plain text** (if the link is incidental)

**Never** write `[[categories/<x>]]` because "it would be a nice
organizational page" — broken wikilinks are noise the next lint run
has to clean up, and they pollute Obsidian graph view with phantom
nodes.

## 8. Backlink Verification After Creating a New Entity

The skill's main `SKILL.md` lists this as a pitfall. The operational
rule:

**When you create a new entity, immediately patch the top 2-3 most-related
existing pages to add a backlink.** Otherwise the new page is a dead-end
(orphan) until the next lint catches it. This is a 1-patch-per-page
effort that keeps the graph dense and the next lint clean.

Examples from 2026-06-24:
- New entity `moebius` → patched `moe-local-comparison.md` (related
  comparison) to add `[[moebius]]` backlink
- Updated `nvidia-nim.md` → added 2 new backlinks ([[minimax-m2]],
  [[deepseek-v4]]) to "관련_concept"

The backlink pass is **mandatory for new entities**, optional for
purely-updated entities (the existing backlinks already point back).

## 9. Fast-Path Idempotency — Title Grep (added 2026-07-03)

The skill's `SKILL.md` "Idempotency" section and section 5 above both
discuss checking the most-recent log entry for re-runs. That's the
strict "all items duplicate" check. The **fast-path triage** for the
common mixed case (M new items + (N-M) duplicates + 1-2 skips) is much
lighter and saves ~5 tool calls per sync.

### Procedure

1. **Search `log.md` for entity-name tokens from each digest item title**
   (and any obvious model/tool names). Don't parse the whole log entry
   body — just `grep` for the slug candidates.

2. **Search the wiki filesystem** for the slug candidates. A file may
   exist that the most-recent log entry doesn't mention (e.g. a
   2026-07-02 sync registered `meituan-longcat-2.md`, but a
   2026-07-03 re-digest wouldn't surface it in the most-recent log).

3. **Classify each digest item** using the intersection:
   - Title match in log.md AND file exists in entities/concepts → ⏭️
   - Title matches `medium.com/` URL → 🚫 skip (Medium 403)
   - Title matches GitHub repo with existing `raw/articles/<slug>-*.md`
     → likely ⏭️ (verify with `ls raw/articles/`)
   - Title matches YouTube URL with no existing entity → 🚫 skip
     (single-video rule)
   - Else (no match anywhere) → ✅ fetch + create/update

### Verified saving (2026-07-03, 3-item digest)

Without the grep fast-path, the 3-item digest would have required
~3 individual fetches just to confirm "new" status. With the grep
fast-path:

- 1 `grep` against log.md (located the `meituan-longcat-2.md` reference
  for the LongCat item)
- 1 `ls ~/wiki/entities/` (confirmed `glm-5-2.md` exists, identified
  ZCode as the missing-by-name new entity)
- 1 `curl` to GeekNews for the ZCode body (only the genuinely new item)
- 1 `curl` to Medium → HTTP 403 (fast-fail confirmed the 🚫 skip)

Total: ~6 calls saved in the triage phase. The grep pattern was the
exact one referenced in the skill's "Notion digest idempotency without
fetching" pitfall — but the practical refinement here is to grep
**both** log.md AND the filesystem, because file existence is the
canonical "registered" signal and the log only reflects the most
recent sync's coverage of that file.

## 10. "Model-Official Harness" Pair (added 2026-07-03)

Distinct from the "Protocol/standard + reference implementation pair"
pattern in the skill's `SKILL.md` Pitfalls section, AND distinct from
the "Same-week sibling tool pair" pattern in the references above.

### When it triggers

A news item about a **model vendor** that ships **its own coding
harness with explicit official endorsement of its own model**. Examples:
- Z.ai's **ZCode** for **GLM-5.2** (Lite $16.2 / Pro $64.8 / Max $144/월)
  — extracted from GeekNews topic 31047, 2026-07-02
- Future predicted: Moonshot K2 공식 클라이언트 for K2.7-Code,
  Alibaba Qwen Code for Qwen3.7-Max

The key distinction from other patterns:

| Pattern | Standard vs Implementation | Page split |
|---|---|---|
| Protocol + implementation | A standard/spec + a reference impl (MCP server, ACP client) | `concepts/<standard>.md` + `entities/<impl>.md` |
| Same-week sibling tools | Two independent tools targeting the same problem from opposite directions | Two `entities/*.md`, cross-linked |
| **Model-Official Harness** | A model vendor ships its own harness for its own model | One `entities/<harness>.md` **plus** add a backlink from the **model's** entity page (e.g., `glm-5-2.md`) |
| Generic single tool | Vendor X ships tool Y, no model implied | One `entities/<tool>.md` |

### Wiki procedure

1. Create `entities/<harness>.md` as a normal entity (frontmatter,
   Overview / 핵심 기능 / 요금제 / 플랫폼 / 의의 sections).
2. Add backlink to the **model entity's "## 관련"** section
   (e.g., `glm-5-2.md` gained a `[[zcode]]` line in its "## 관련"
   section).
3. Add a new timeline section to `concepts/ai-agents-trends-2026.md`
   for the "에이전트 도구 진화" progression — this is now a 4-stage
   arc (model-only → model+tool → MCP/ACP standardization →
   **model-official harness certification**).
4. Compare pricing against `claude-code-pro-max` and `codex` in the
   timeline section — model-official harnesses typically price
   1/5–1/12 of US competitors, both as a market-entry signal and a
   "자국 종량제 선호" marker from `china-ai-lab-culture`.

### Why this is a separate pattern, not a sub-pattern of the others

- **Not Protocol+implementation** — there is no independent protocol
  or reference implementation; the vendor controls both sides.
- **Not Same-week sibling** — there is no second tool released in
  parallel; it's a single product announcement.
- **Distinct wiki page treatment** — the harness page needs the
  pricing-tier analysis and the "model-vendor-control" framing,
  neither of which fits the other two patterns' pages.

### Verified call-out (2026-07-03, ZCode)

- Source: GeekNews topic 31047 → `raw/articles/zcode-glm-harness-2026-07-03.md`
- New entity: `entities/zcode.md`
- Backlink added: `entities/glm-5-2.md` "## 관련" section + 1 line
- Timeline section: `concepts/ai-agents-trends-2026.md` section 28
- Pricing tier analysis embedded in ZCode page's "요금제" table AND
  in the timeline section's "## 의미" list.

### Forward-looking check

When the next digest arrives containing **Moonshot 공식 K2 클라이언트**
or **Qwen Code** (model-official harness for Kimi K2 / Qwen3.7-Max),
apply this pattern directly. The competitive picture becomes a
**6-way coding agent market** ([[claude-code-pro-max]] / [[codex]] /
[[hermes-agent]] / [[zcode]] / K2 클라이언트 / Qwen Code) — worth
capturing as a `comparisons/coding-agent-pricing-2026.md` when the
3rd+ such harness arrives.
