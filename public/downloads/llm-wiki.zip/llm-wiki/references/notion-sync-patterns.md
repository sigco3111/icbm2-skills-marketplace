# Notion Dev News Sync — Patterns & Templates

Operational patterns that emerged from repeated Notion-collector → LLM-Wiki
sync runs (2026-04-09 through 2026-06-24, ~20 sync sessions). The
`patch-disaster-case-studies.md` companion file documents patch-tool
disasters; this file documents the **end-to-end sync workflow patterns**
that the patch disasters taught us to use.

## 1. 3-Way Split Log Entry Format

Every sync entry should split work into three explicit buckets so the
user can see at a glance what actually happened:

| Bucket | Symbol | Meaning | Action taken |
|---|---|---|---|
| **신규** | ✅ | Genuinely new content, not seen before | Full fetch + page create/update + index/log |
| **이미 처리됨** | ⏭️ | Appears in current digest but was registered in a previous sync | Cite the previous sync date + the existing raw file path. No re-work. |
| **등록 기준 미달** | 🚫 | Evaluated and intentionally skipped | Cite the rule from `SKILL.md` "Common skipping rules". Write a `raw/articles/<slug>-skip-YYYY-MM-DD.md` with the reason. |

**Why 3-way, not 2-way**: Case 12 (2026-06-17) introduced the 2-way ✅/⏭️
split. The 🚫 bucket was added on 2026-06-24 when a single-YouTube-heavy
digest (3 out of 9 items were unwatchable single videos) showed that
conflating "already registered" with "deliberately skipped" hides the
decision. The user reading the log needs to see both buckets separately
because the actions are different (no work for ⏭️, evaluated decision for
🚫) and the user might disagree with the 🚫 decision and want to override.

**Verified working template (2026-06-24, 9 items → 2 신규 + 4 ⏭️ + 3 🚫)**:

```markdown
## [2026-06-24] ingest | Notion Dev News → LLM Wiki 동기화
- Source: Notion 뉴스 클리핑 DB (9건, 2026-06-24)
- **처리**: 9건 중 **2건 신규**, 4건은 2026-06-23 동기화에서 이미 처리됨, 3건은 Wiki 등록 기준 미달
  - ✅ **신규**: `moebius`, `nvidia-nim-80-models-free` (nvidia-nim 페이지에 통합)
  - ⏭️ **이미 처리됨 (2026-06-23)**: `bigset` → [[bigset]], `agent-connector` → [[agent-connector]],
    `repolis` → [[repolis]], `agent-blackbox` → [[agent-blackbox]] (2026-06-23 동기화에서 이미 반영)
  - 🚫 **등록 기준 미달**: `Gajae-Code` (단일 YouTube 영상, 스크립트 미공개),
    `Ponytail 스킬` (단일 YouTube 영상, 5만 스타 언급만),
    `하네스 LazyCodex` (단일 YouTube 영상, 스크립트 미공개)
- **Raw sources added**: ...
- **Entity pages created**: ...
- **Entity pages updated**: ...
- **Concept/Comparison pages updated**: ...
- **Index.md 갱신**: Last updated ... → ..., Total pages ... → ...
- **Total pages**: ...
- **의미**: ...  (synthesis)
- **권고**: ...  (actionable follow-ups)
```

## 2. Skip-With-Raw-File Pattern

The skill's `SKILL.md` "Common skipping rules" lists 6 categories of items
to skip. The `SKILL.md` previously did NOT specify what to do with the
URL/source afterward. The verified pattern (2026-06-24) is:

**When skipping, ALWAYS write a `raw/articles/<slug>-skip-YYYY-MM-DD.md`**
with `fetch_status: not_extracted` and `skip_reason: <rule>`.

### Skip-file template

```markdown
---
title: <Item Title> (skip)
date: YYYY-MM-DD
source: <original URL>
fetch_status: not_extracted
skip_reason: <one-line rule citation from Common skipping rules>
---

# <Item Title> (Wiki 등록 보류)

## 등록 보류 사유
- <exact rule from SKILL.md that triggered the skip, e.g. "Single video tutorial - YouTube 스크립트 추출 불가">

## 인덱스 메모
- <optional: any forward-looking note, e.g. "Ponytail 5만 스타 스킬은 [[oh-my-harness]] 생태계의 한 축으로 추적할 가치는 있으나, 스크립트 미공개로 구체적 기능 확인 불가">
- <optional: re-evaluation trigger, e.g. "후속 영상 스크립트나 GitHub README가 공개되면 재검토">

## 출처
- <original URL(s)>
```

### Why this matters

1. **Audit trail**: `ls raw/articles/` shows the URL was at least captured
2. **Re-evaluation trigger**: if the source later becomes extractable
   (YouTube adds captions, blog updates, follow-up article), the agent has
   the URL to re-fetch from — no need for the user to re-paste it
3. **Decision visibility**: the user reading the log can see WHY each
   item was skipped and override the decision if they disagree
4. **No silent skips**: silent skips become a black box — the URL is
   forgotten, the decision rationale is lost, and the item reappears
   in the next Notion digest with no way to recall "we already considered
   this on YYYY-MM-DD and decided 🚫"

### Verified skip-file

`raw/articles/gajae-ponytail-lazycodex-skip-2026-06-24.md` — bundled 3
single-YouTube skips into one file with shared `skip_reason` and
per-item notes. This is a valid compression: when N items share the
same skip reason, one skip-file with N sub-sections is cleaner than N
separate skip-files.

## 3. Update-Existing-Entity vs. Create-New-Page Decision Rule

When a new source provides supplementary context to an existing entity,
the default is to **update the existing page** with a new section, not
to create `<entity>-<subtopic>.md`.

### Decision rule

- ❌ **Create new page** when: (a) the subtopic is its own coherent
  product/concept with a distinct identity (different product, different
  concept, different team), OR (b) the existing page would grow past
  200 lines (the `Page Thresholds` split threshold)
- ✅ **Update existing page** when: new article about the same product
  with new context. Bump `updated:`, extend `sources:`, add a new
  section to body.

### Examples from 2026-06-24

- `nvidia-nim.md` + new article "NIM now offers 80+ models for free"
  → **Updated** `nvidia-nim.md` (38 → 44 lines, well under 200)
  - Added a "80+ 모델 무료 API" bullet to "주요 특징"
  - Added a "무료 프로덕션급 모델" row to "2026년 경쟁 구도"
  - Added 2 backlinks ([[minimax-m2]], [[deepseek-v4]]) to "관련_concept"
  - Extended `sources:` in frontmatter
- A new NIM sub-product (hypothetical "NIM Edge" device) would be a
  **new page** → `entities/nvidia-nim-edge.md`

### Why this matters

Creating a sub-slug page (e.g. `nvidia-nim-80-free.md`) for what is
really the same product pollutes the index, splits the "what is NIM"
narrative across 2+ pages, and confuses Obsidian graph view (one node
per page, when conceptually it's one product). The wiki should reflect
the model, not the news cycle.

## 4. Idempotency Check — Most-Recent Sync

Before processing any digest, do this:

```python
import re
log = open(WIKI + "/log.md").read()
# Find the most recent ingest entry (not lint/update)
entries = re.findall(
    r"## \[(\d{4}-\d{2}-\d{2})\] ingest \| ([^\n]+)\n(.*?)(?=\n## |\Z)",
    log, re.DOTALL,
)
if not entries:
    # No prior sync — proceed
    pass
else:
    most_recent_date, most_recent_title, most_recent_body = entries[-1]
    # Check if every item in the current digest appears in most_recent_body
    ...
```

Case 3 (2026-06-05) and Case 12 (2026-06-17) document the no-op and
partial-overlap variants. The hard rule from Case 12:

> The collector script's "신규 항목: N건" count is the *digest size*, not
> the *work size*. The agent's ✅신규 count is the actual work done and
> is the number that should go in the user report's lead paragraph.

Don't conflate digest size with work size. A 9-item digest with 2 ✅신규
is a 2-item work session, not a 9-item one.

## 5. Per-Session Tool-Call Budget

The skill's Case 11 (2026-06-15) is the canonical reference. The
operational rule:

**Reserve the LAST 2-3 tool calls of every session for `index.md` and
`log.md` updates.** If you realize mid-session that budget is running
out, drop the lowest-value content updates first (optional backlinks,
optional "의미" sections), keep the new page creation and the mandatory
index/log updates. The backlinks can be filled in by the next session's
lint; missing index entries are a navigational blackout.

A 9-item digest producing 1 new entity + 3 updated pages + 1 skip-file
fits comfortably in ~20-25 tool calls:
- 3-4 calls: orientation (read SCHEMA, index, log tail, search existing pages)
- 1 call per fetch: ~3-4 fetches (DDG or similar)
- 1 call per write: 1 new entity + 3 page updates + 1 skip-file = 5 writes
- 2-3 calls: index.md + log.md updates + verification re-reads
- Buffer: 3-5 calls for retries or unexpected patches

If a session exceeds 30 calls without `log.md` updated, **stop and
update the log NOW** before doing anything else. An incomplete sync
with a log entry is recoverable; an incomplete sync without a log
entry is the cron-spin trap.

## 6. Pre-Write `ls` Wikilink Verification

The skill's main `SKILL.md` mandates this. Companion pattern for
single-file verification:

```bash
# For each [[wikilink]] in your draft, check the slug exists
ls ~/wiki/entities/ | grep -F "<slug>"
ls ~/wiki/concepts/ | grep -F "<slug>"
ls ~/wiki/comparisons/ | grep -F "<slug>"
```

If any `[[link]]` slug returns no match, either:
- **CREATE the target page first** (if the concept is real and central)
- **Convert to plain text** (if the link is incidental)

**Never** write `[[categories/<x>]]` because "it would be a nice
organizational page" — broken wikilinks are noise the next lint run
has to clean up, and they pollute Obsidian graph view with phantom
nodes.

## 7. Backlink Verification After Creating a New Entity

The skill's main `SKILL.md` lists this as a pitfall. The operational
rule:

**When you create a new entity, immediately patch the top 2-3 most-related
existing pages to add a backlink.** Otherwise the new page is a dead-end
(orphan) until the next lint catches it. This is a 1-patch-per-page
effort that keeps the graph dense and the next lint clean.

Examples from 2026-06-24:
- New entity `moebius` → patched `moe-local-comparison.md` (related
  comparison) to add `[[moebius]]` backlink
- Updated `nvidia-nim.md` → added 2 new backlinks ([[minimax-m2]],
  [[deepseek-v4]]) to "관련_concept"

The backlink pass is **mandatory for new entities**, optional for
purely-updated entities (the existing backlinks already point back).
