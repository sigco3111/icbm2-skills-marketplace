# Section 16: Patch + log integrity patterns (2026-07-02)

Three findings from the 2026-07-02 Notion sync that should be inherited by
future runs.

## 16.1 "Section-trailing-bullet loss" — patch that silently drops the last bullet

**File**: `concepts/ai-agents-trends-2026.md` (had 26 numbered sections, section 26 had 7 "의미" bullets)

**Intent**: Add a new `### 27. Meituan LongCat-2.0 — 엔비디아 프리 1.6T MoE (2026-07-02)` section after section 26.

**Disaster patch** (anchored on the FIRST bullet of the "의미" sub-list):

```python
# WRONG — old_string was anchored on the first bullet of the 7-bullet "의미" list,
# new_string was the same first bullet + new section 27. The patch succeeded but
# silently DELETED the last bullet ("에이전트 단축키 패드" = 신규 디바이스 카테고리).
patch(
    old_string='  - **"가격 = 무료화 무기"** — Sonnet 5 인트로 $2/$10 + Gemini 무료 확대 = ...\n',
    new_string='  - **"가격 = 무료화 무기"** — Sonnet 5 인트로 $2/$10 + Gemini 무료 확대 = ...\n### 27. Meituan LongCat-2.0 — ...\n- ...\n'
)
```

The diff output looked clean. Only a tail re-read revealed the loss: the
"에이전트 단축키 패드" bullet (the 7th and last bullet of section 26) had
been replaced by the `### 27` section header.

**Recovery**: second patch that re-inserted the missing bullet:

```python
patch(
    old_string='  - **"가격 = 무료화 무기"** — Sonnet 5 인트로 $2/$10 + Gemini 무료 확대 = ...\n### 27. ',
    new_string='  - **"가격 = 무료화 무기"** — Sonnet 5 인트로 $2/$10 + Gemini 무료 확대 = ...\n  - **"에이전트 단축키 패드" = 신규 디바이스 카테고리** — 피그마 → Codex 매크로 패드...\n### 27. '
)
```

**Root cause**: when a "의미" sub-list has 5+ bullets, anchoring on the
FIRST bullet and inserting a new section header in the `new_string` is
structurally dangerous. The patch tool's match range behavior on long
sub-bullet blocks is not always "insert after my last match line" — it
can land the new content IN PLACE of the last bullet.

**Mandatory safe pattern (Case 1's "append at end of file", re-stated for
long sections)**:

```python
# Step 1: read the file TAIL, not the head
total_lines = 260  # from earlier read_file
content = read_file(WIKI + "/concepts/ai-agents-trends-2026.md",
                    offset=total_lines - 15, limit=15)
# Now you see the actual last 15 lines including the real last bullet.

# Step 2: anchor on the LAST bullet (which is unique by content)
patch(
    old_string='  - **"에이전트 단축키 패드" = 신규 디바이스 카테고리** — 피그마 → Codex 매크로 패드. 향후 [[claude-code]], [[cursor]], [[github-copilot]] 등도 매크로 패드 채택 가능성. **[[cat-emoji-canvas-ide]] 와 대비** — list-style IDE vs 매크로 패드 = 같은 "에이전트 워크플로우 가속" 의 두 표현\n',
    new_string='  - **"에이전트 단축키 패드" = 신규 디바이스 카테고리** — 피그마 → Codex 매크로 패드. 향후 [[claude-code]], [[cursor]], [[github-copilot]] 등도 매크로 패드 채택 가능성. **[[cat-emoji-canvas-ide]] 와 대비** — list-style IDE vs 매크로 패드 = 같은 "에이전트 워크플로우 가속" 의 두 표현\n\n### 27. Meituan LongCat-2.0 — 엔비디아 프리 1.6T MoE (2026-07-02)\n- **[[meituan-longcat-2]]** — 메이투안 공개 1.6T MoE 코딩·에이전트 특화 LLM...\n- ...\n'
)

# Step 3: read_file the tail again to confirm the last bullet survived AND
# the new section header landed below it (not replacing it).
```

**Detection rule**: after any structural patch on a page with 5+ bullets
in the last section, `read_file` the tail (last 15 lines) and confirm:
1. The last bullet of the prior section is still present
2. The new section header is on the line immediately after the last bullet
3. There's a blank line between the last bullet and the new section header

**Generalization**: Case 1 says "find the last `### N.` header + its
first line." For pages with long sections (5+ bullets), the last `### N.`
header is often 30+ lines above the file end, and the section's first
line is even further. You need the actual LAST BULLET, not the section
header. Read the tail of the file before patching.

## 16.2 "Raw files exist but log entry missing" — torn state from partial cron sync

**Context**: On 2026-07-01, raw files were created and entity pages were
updated, but NO `[2026-07-01]` log entry was appended. On 2026-07-02, the
next cron run discovered the torn state. The collector script
re-emitted the same items (Notion DB still had them un-marked), but the
agent's idempotency check (Case 3 pattern) failed because the log entry
didn't exist.

**How the torn state was detected** in this session:
```bash
$ grep -n "2026-07" log.md
# (no matches — no log entry for 7/1)

$ ls raw/articles/ | grep "2026-07-01"
claude-sonnet-5-anthropic-2026-07-01.md
gemini-personalization-free-2026-07-01.md
iphone-12-data-unlimited-skip-2026-07-01.md
loop-engineering-medium-skip-2026-07-01.md
openai-codex-hardware-macropad-2026-07-01.md
ornith-1-0-geeknews-30979-skip-2026-07-01.md
# 6 raw files, 0 log entries — TORN STATE
```

**Recovery procedure** (used in this session):

1. **List raw/articles/ for the missing date** to enumerate all items
   that were "touched but not logged": `ls raw/articles/ | grep "2026-07-01"`
2. **For each raw file, check whether the linked entity/concept page
   was updated** (search the entity for the new sources) and whether
   `index.md` was updated.
3. **Compose a "log backfill" entry** with the
   `## [YYYY-MM-DD] ingest | ... (log 보강)` header. Explicitly mark it
   as a backfill: "raw 파일은 7/1에 생성되었으나 정식 log 엔트리 누락분
   일괄 보강".
4. **Use the same ✅/⏭️/🚫 3-way split** as a normal sync entry, citing
   the existing raw/ file paths for each ⏭️ entry.
5. **Append a "권고" note to the backfill entry**: "notion_news_to_wiki.py
   should mark processed items in Notion to prevent this torn state" —
   accumulate signal each time it occurs.

**Prevention — "raw ↔ log consistency" check at session start** (for cron
sync specifically, add to Phase 1 of the orient workflow):

```bash
# After running the collector script and getting the date N, before
# orienting on the wiki:
for offset in 1 2 3 4 5 6 7; do
    target_date=$(date -d "$offset days ago" +%Y-%m-%d 2>/dev/null || date -v -${offset}d +%Y-%m-%d)
    raw_count=$(ls raw/articles/ 2>/dev/null | grep -c "$target_date" || echo 0)
    log_count=$(grep -c "## \[$target_date\]" log.md 2>/dev/null || echo 0)
    if [ "$raw_count" -gt 0 ] && [ "$log_count" -eq 0 ]; then
        echo "TORN STATE: $target_date has $raw_count raw files but no log entry"
    fi
done
```

Add this check to the orient phase. If a torn state is detected, the
FIRST log entry written should be the backfill, not the new sync.

**Distinction from Case 11**: Case 11 is "tool-call budget exhaustion,
both raw AND log missing" — recovery is to finish the work. Case 16 is
"raw present, log missing, likely a process bug not a budget issue" —
recovery is to BACKFILL the audit trail for work that already happened.
Different recovery actions; same severity.

## 16.3 og:description-based pre-classification of Notion digest items

**Context**: The 2026-07-02 Notion digest included "Ornith-1.0 - 에이전트형
코딩을 위한 자기 개선 오픈소스 모델" (GeekNews topic 30979). The 6/29 sync
had already registered `[[ornith-1-0]]` from a different source
(Discuss.pytorch.kr). The question: is the GeekNews article a duplicate
or does it contain new information?

**Cheap pre-classification**: fetch only the og:description meta tag
(1-2 KB), not the full body.

```bash
curl -sL -A "Mozilla/5.0 ..." "https://news.hada.io/topic?id=30979" | \
    python3 -c "import sys, re; html = sys.stdin.read(); m = re.search(r'<meta[^>]*property=\"og:description\"[^>]*content=\"([^\"]+)\"', html); print(m.group(1) if m else 'NO MATCH')"
```

Output for topic 30979:
```
Ornith-1.0은 에이전트형 코딩용 자기 개선 오픈소스 모델로, 9B Dense, 31B Dense, 35B MoE, 397B MoE 구성을 제공하며 Gemma 4와 Qwen 3.5 위에서 후훈련됨 훈련 프레임워크는 강화학습으로 솔루션 rollout뿐 아니라 rollout을 이끄는…
```

The og:description confirms:
- Same product (Ornith-1.0)
- Same architecture (9B/31B/35B/397B)
- Same training approach (RL on scaffold + solution)
- Same foundation (Gemma 4, Qwen 3.5)
- No mention of new benchmark, new model variant, or new deployment

**Decision**: mark as `skip_reason: already-registered-as-ornith-1-0`
without full body fetch. Save a thin skip raw file with the og:description
embedded so a future agent/lint can see WHY this raw file exists with no
real content.

**Decision tree for the pre-classification step**:

| og:description signal | Action |
|----------------------|--------|
| "new features / new benchmark / new model variant" | Fetch full body |
| "기존 모델 재보도 / 보도자료 / PR" | Mark as `already-registered-as-<slug>` skip |
| Absent (Notion JS-only) | Use title only; if title matches existing entity, treat as `notion-js-only-or-og-missing` skip |
| Fresh concept not in wiki | Proceed with full body fetch |

**Cost reduction**: Verified on this session — 1 GeekNews item was
classified as already-registered via og:description alone, saving a
full-page curl + Python parse pass (~5-10 seconds and 1 tool call).
For digests with 5+ GeekNews items, this can save 1-3 tool calls per
sync and reduce the rate of accidental re-ingestion of the same product.
