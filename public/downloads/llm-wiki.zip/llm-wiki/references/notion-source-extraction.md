# Notion Source Extraction — Patterns & Gotchas

How to fetch content from the URLs the Notion digest hands over, with the
gotchas that waste tool calls. Companion to the 3-way split in
`notion-sync-patterns.md` — this file is the **content extraction** step
that runs before you decide whether a digest item is ✅신규 / 🔄기존 / 🚫skip.

## macOS shell gotchas (apply before any HTML extraction)

- `grep -P` (PCRE) is **not supported** on macOS BSD grep. Don't burn
  tool calls on `grep -oP 'pattern'` — use Python's `re` module via
  `python3 -c '...'` or `terminal()` heredoc instead. Verified waste:
  8 failed `grep -P` invocations in 2026-06-29 sync before switching
  to Python.

- Default `curl` on macOS is fine for most targets. Use a real
  `User-Agent` header — many sites (Medium especially) return 403 to
  default `curl`/`python-urllib` agents.

  ```bash
  curl -sL -A "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36" \
       "https://example.com/article"
  ```

- Don't `cat` HTML into Python — pipe via `subprocess` or use
  `urllib.request` directly. `subprocess` calls are blocked in cron
  mode (use the `terminal` tool with python heredoc instead).

## Per-site patterns

### Discourse (PyTorchKR, forum.pytorch.kr, etc.)

Topic URLs like `https://discuss.pytorch.kr/t/<slug>/<id>` render
content server-side. The cleanest extraction is the **JSON API** —
append `.json` to the topic URL:

```bash
python3 -c "
import urllib.request, json, re, html
req = urllib.request.Request('https://discuss.pytorch.kr/t/ornith-1-0-.../10951.json',
    headers={'User-Agent': 'Mozilla/5.0 ...'})
j = json.loads(urllib.request.urlopen(req, timeout=20).read())
body = j['post_stream']['posts'][0]['cooked']  # HTML
text = re.sub(r'<[^>]+>', ' ', html.unescape(body))
text = re.sub(r'\s+', ' ', text)
print(text[:5000])
"
```

The `cooked` field is rendered HTML — strip tags with regex. The
`raw` field is original markdown (alternative if you want to preserve
formatting).

### GeekNews (news.hada.io/topic?id=XXXX)

The article body lives in `<div class="topic-text">` (or `topic_text`
— both spellings appear across the site). Comments are below in
loose `<p>` blocks.

```python
import urllib.request, re, html
raw = urllib.request.urlopen(req, timeout=20).read().decode('utf-8', errors='ignore')

# Article body
m = re.search(r'class="topic-text"[^>]*>(.*?)</div>', raw, re.DOTALL)
body = re.sub(r'<[^>]+>', ' ', m.group(1)) if m else ''

# Comments (long paragraphs only, to skip UI noise)
paras = re.findall(r'<p>(.*?)</p>', raw, re.DOTALL)
comments = [re.sub(r'<[^>]+>', ' ', html.unescape(p)).strip()
            for p in paras if len(p) > 100]
```

**Important**: GeekNews topic pages often don't include the original
article body — just the linker's summary. The real content is on the
**external link** the topic points to. Extract the external URL:

```python
ext = [h for h in re.findall(r'href="(https?://[^"]+)"', raw)
       if 'hada.io' not in h and (
           'github.com' in h or 'medium.com' in h or 'youtube' in h or
           'openai.com' in h or 'apple' in h or 'microsoft' in h or
           'reuters' in h or 'bloomberg' in h)]
```

Then fetch the external link separately.

**GeekNews 댓글 are a primary source.** When the original article is
paywalled (Stackademic, Medium), the comments often contain the
substantive insight. Don't skip the article just because the
"official" body is thin — the comments section is part of the source.

### GitHub repository README

```python
# README is in the repo page HTML, but the *file* lives at
# https://raw.githubusercontent.com/<user>/<repo>/<branch>/README.md
# Raw GitHub works without auth and renders pure markdown.
req = urllib.request.Request('https://raw.githubusercontent.com/tjdrhs90/flutter-flame-harness/main/README.md',
    headers={'User-Agent': 'Mozilla/5.0 ...'})
```

If `main` branch returns 404, try `master`. Some repos use neither
(rare in 2026) — in that case parse the GitHub HTML page's
`<article class="markdown-body">` block.

### Medium (medium.com / blog.stackademic.com)

**Medium returns HTTP 403 to non-browser user agents.** Don't waste
retries. Save the page as `fetch_status: not_extracted` and
`skip_reason: medium-403-no-content-no-page` and move on.

```python
# If you must try: use a real browser User-Agent AND a Referer header
req = urllib.request.Request(url, headers={
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml',
    'Accept-Language': 'en-US,en;q=0.9',
})
# Still likely 403. Move on.
```

For Medium paywalled content, the article's first ~500 chars are
usually public (the byline, lead, and "Listen Share" buttons). Use
the title + first paragraph as the basis for a Wiki summary, with
a `fetch_status: not_extracted` marker.

### AI Times (aitimes.com) / 한국 매체

Korean news sites generally render server-side. AI Times specifically
has the article body in `<article>` blocks or as raw text inside the
main column. The site has heavy nav/ad chrome — use Python to filter
long paragraphs:

```python
paras = re.findall(r'<p[^>]*>(.*?)</p>', raw, re.DOTALL)
body = [re.sub(r'<[^>]+>', ' ', html.unescape(p)).strip()
        for p in paras if len(p) > 50]
# First 1-2 paragraphs are the actual article
```

### BonTech Labs / general tech news

These are usually WordPress-style blogs. The article body lives in
`<article ...>...</article>` or `<div class="entry-content">`.
Same Python regex approach.

### YouTube (single-video source — usually skip)

The Notion digest occasionally includes YouTube URLs. **The 3-way
split rule**: single YouTube video with no transcript = 🚫skip,
not ✅신규. Wiki registration requires substantive text content.

**Always write a skip file** at
`raw/articles/<slug>-skip-YYYY-MM-DD.md` with:
- `source:` (the URL)
- `fetched:` (today)
- `fetch_status: not_extracted`
- `skip_reason: single-YouTube-video-no-script`
- `category: skip-single-YouTube`
- 1-2 line summary of what the video is, so the next agent/lint
  doesn't re-investigate

**Re-extraction condition**: if the video's creator later adds
auto-generated captions OR a separate blog post with the script,
the skip file can be re-opened. Document this in the skip file's
"재방문 조건" section so the next agent has the URL to retry.

## Generic HTML→text helper

Keep this in a `terminal()` heredoc — adjust `url` and `selector`:

```python
python3 << 'PYEOF'
import urllib.request, re, html
url = "https://example.com/article"
req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0 ...'})
raw = urllib.request.urlopen(req, timeout=20).read().decode('utf-8', errors='ignore')

# Strip script/style blocks first
raw = re.sub(r'<script.*?</script>', ' ', raw, flags=re.DOTALL|re.IGNORECASE)
raw = re.sub(r'<style.*?</style>', ' ', raw, flags=re.DOTALL|re.IGNORECASE)

# Try common article-body selectors in order
for sel in [
    r'<article[^>]*>(.*?)</article>',
    r'<div[^>]+class="[^"]*topic-text[^"]*"[^>]*>(.*?)</div>',
    r'<div[^>]+class="[^"]*entry-content[^"]*"[^>]*>(.*?)</div>',
    r'<div[^>]+class="[^"]*post-content[^"]*"[^>]*>(.*?)</div>',
    r'<main[^>]*>(.*?)</main>',
]:
    m = re.search(sel, raw, re.DOTALL)
    if m and len(m.group(1)) > 500:  # body should be substantial
        body = m.group(1)
        break
else:
    body = raw  # fallback: use everything

text = re.sub(r'<[^>]+>', ' ', body)
text = re.sub(r'\s+', ' ', html.unescape(text)).strip()
print(text[:5000])
PYEOF
```

## When to give up and write a skip file

Trigger conditions for `fetch_status: not_extracted`:

| Condition | Action |
|---|---|
| HTTP 403 (Medium) | `skip_reason: medium-403-no-content-no-page` |
| HTTP 404 / 410 | `skip_reason: source-dead` (404/410) |
| Single YouTube, no captions | `skip_reason: single-YouTube-video-no-script` |
| JS-only render (Notion pages) | `skip_reason: js-only-render` (but consider synthesis per Case 5 in patch-disaster-case-studies.md) |
| Article behind paywall, only title visible | Save title + lead paragraph; consider concept-synthesis from scattered mentions |
| 3+ retries failed with different errors | `skip_reason: extraction-failed-after-retries` |

**Always** write the skip file with the URL preserved and a one-line
description, so the next agent has the trail.

## Companion references

- `notion-sync-patterns.md` — the 3-way split log format and
  skip-file template
- `patch-disaster-case-studies.md` — Case 5 covers Notion JS-only
  concept synthesis
