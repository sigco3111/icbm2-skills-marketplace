---
name: patch-line-context-safety
description: "patch tool 호출 시 인접 라인 중복·누락 / import 누락 / 매치 오판을 막는 실전 규칙."
version: 1.0.0
license: MIT
category: software-development
metadata:
  hermes:
    tags: [patch, debugging, refactor, workflow]
    related_skills: [systematic-debugging, test-driven-development]
---

# Patch Line Context Safety

`patch` 도구(`mode: 'replace'`)는 `old_string`을 fuzzy match해서 찾아내고, 매치된 라인은 그대로 두고 새 라인을 끼워넣는다. 이게 강력하지만 **인접 라인이 같아 보이는 경우 중복으로 박힐 수 있음**. 본 스킬은 그 함정의 한 단계 위, **호출 습관과 검증 워크플로**로 막는다.

## 핵심 규칙

### 1. `old_string`은 인접 라인 ±2줄은 항상 포함시켜라

```js
// ❌ 위험: 인접 라인이 거의 동일한 키-값 패턴이면 매치 후보가 둘
old_string: "viewKeyScale: 0.42,"
new_string: "viewKeyScale: 0.55,"

// ✅ 안전: 위 + 아래 2줄 컨텍스트 포함
old_string: "      viewFillOcclusion: 0.45,\n      // ---- viewmodel 3-point rig ----\n      // The key is scaled off the scene's own light level\n      viewKeyScale: 0.42,\n      viewKeyMax: 2.6,"
new_string: "      viewFillOcclusion: 0.45,\n      // ---- viewmodel 3-point rig ----\n      // The key is scaled off the scene's own light level\n      viewKeyScale: 0.55,\n      viewKeyMax: 2.6,"
```

3개 라인이 같은 패턴이면 (예: `viewFillOcclusion: 0.45`, `viewKeyScale: 0.42`, `viewHemiRatio: 0.16`이 모두 `key: number,` 한 줄짜리) **fuzzy match가 잘못된 위치를 잡을 가능성**이 있다. 컨텍스트 라인이 없으면 매치 후 결과는 "원래 라인은 두고 새 라인이 박힘" 또는 "잘못된 위치에 새 라인이 박힘".

### 2. patch 호출 직후, 같은 파일에 다른 patch를 보낼 거면 **반드시 read_file로 매치 영역을 다시 본다**

특히 **같은 파일에 N개 patch를 보내는 경우**, 첫 patch가 변경한 후의 라인 번호는 두 번째 patch의 매치 영역과 안 맞을 수 있다.

```python
# ❌ 흔한 실수
patch("weapons.js", "a: 1,", "a: 2,")
patch("weapons.js", "b: 1,", "b: 2,")   # 첫 patch가 주변 라인을 바꿔서 매치 위치 미스매치 가능

# ✅ 안전 패턴
patch("weapons.js", "context_a\n  a: 1,\ncontext_a2", "context_a\n  a: 2,\ncontext_a2")
read_file(path, offset=<첫 patch 라인-2>, limit=10)  # 매치 영역 확인
patch("weapons.js", "...", "...")                    # 두 번째 patch는 갱신된 라인 번호로
```

### 3. patch에 새 식별자·함수 호출이 들어간다면, **import 라인을 먼저 patch하라**

```js
// ❌ 위험 순서: t()를 4군데 patch → 마지막에 import 한 번. 중간에 파일을 보면 lint가 통과해도,
// 런타임에서 t is not defined가 나옴
patch("ui/demo.js", "banner.show('Enemy Eliminated', ...)",
                  "banner.show(t('feed.enemyEliminated'), ...)")  // t가 import 안 됨
patch("ui/demo.js", ...) // 또 다른 곳
// ... 중간에 import 패치 누락
```

**왜 위험한가**: patch는 lint를 통과해도 런타임에 부서지면 dev 서버 콘솔에 늦게 발견됨. imagediff는 게임 화면 캡처라 게임이 부서졌어도 검은 화면으로 검출됨. 즉 **빌드 PASS + 시각 PASS가 t 누락을 가려줌**.

**안전 패턴**:
- 새 symbol을 도입하는 patch는 **해당 파일의 첫 patch 이전에 import 라일을 patch**
- 또는 symbol이 한 군데만 쓰이고 import가 명확하면 그 patch에 import 추가를 새 줄로 함께 박기 (둘이 인접 영역이면)

### 4. patch 직후 `git diff -- <파일>` 또는 `read_file`로 매치 결과 검증

```bash
git diff path/to/file.js | head -40
```

이 한 줄로 다음이 잡힘:
- **중복 박힘** (예: `viewFillOcclusion: 0.45,` 두 번)
- **인접 라인 손상** (예: `viewKeyScale: 0.55,` 라인이 사라짐)
- **들여쓰기 / 괄호 / 콤마 누락** (TS/JS Lint가 잡지만 Python은 못 잡는 경우 多)

**30초짜리 검증이 30분짜리 디버깅을 막음**. 단발 patch라도 항상 함.

### 5. 인접 라인이 동일할 때 — patch 안 쓰고 write_file로 통째 교체

만약 5줄 블록 안에 바꿀 게 3줄이고 그중 둘이 매우 비슷한 라인이면 **patch를 3번 보내지 말고 read_file로 영역 본 다음 write_file로 통째 교체**.

```python
# read_file로 영향 영역 통째 읽기 (offset/limit)
# 새 내용 write_file
# → 중복/누락 0
```

이건 patch의 "fuzzy match가 위험한 경우"의 escape valve.

## 흔한 함정 패턴 4가지

### 함정 A: "두 줄의 차이가 비슷한 라인을 사이에 두고 있다"

```
원본:
  A: 1,
  B: 1,
  C: 1,

목표:
  A: 2,
  B: 1,
  C: 1,
```

`old_string: "A: 1,\nB: 1,\nC: 1,"`로 A:B:C 셋 다 잡아서 A만 바꾸면 됨. 하지만 **fuzzy match가 sparse한쪽 한 줄만** 잡으면 무관한 라인에 새 라인이 박힘.

**교훈**: 인접 컨텍스트는 항상 2줄 이상 포함.

### 함정 B: "위 라인이 사라질 때 아래 라인이 올라온다"

```
원본:
  X: old,
  Y: 1,

  Z: 1,
```

X를 지우려면 `old_string: "  X: old,\n  Y: 1,\n\n  Z: 1,"`로 컨텍스트 잡고, new는 Y부터 시작. **빈 줄 처리** 잊으면 항상 어긋남.

### 함정 C: "patch가 두 군데를 동시에 바꿨다 (replace_all 없이)"

`old_string`이 파일 안에 두 곳에서 발견되면 patch는 **"Could not find a match"** 에러로 거부된다 — 그래서 발견은 쉽다. 다만 **에러가 안 나는 케이스**: `old_string`이 한 곳에서만 발견됐는데 의도와 다른 위치에 있을 때.

**교훈**: 매치가 의도한 위치의 코드를 **실제로 가리키는지** read_file 한 번으로 확인.

### 함정 D: "patch가 성공했지만 매치 위치가 절반만 맞았다"

가장 잔인한 함정. `old_string`이 fuzzy로 절반 매치되면 의도 위치에 patch가 박히지만 **옛 라인이 남고 새 라인이 위에 박힘**. 코드 동작은 깨짐. lint/typescript는 발견 못할 수 있음.

**교훈**: 다시 한 번 — **patch 후 `git diff` 또는 read_file로 결과 영역 재검증**.

### 함정 F: "옆줄 들여쓰기로 if-블록이 사라지는 현상" (NEW, TripleA i18n A2 2026-07-28)

`patch` 의 fuzzy match는 **가장 들여쓰기가 비슷한 위치를 우선** 잡는다. 인접 컨텍스트에 **같이 호출되는 메서드 안의 코드**(try-with-resources, if/final-return 등, 들여쓰기가 16~18칸)가 있고, 다른 위치에 **함수 본문 끝의 if 블록**(들여쓰기 14~16칸)이 있다면, 매치가 다른 위치를 잡을 가능성. 그 결과 의도하지 않은 라인(예: `if (result != 0) {`)이 사라지고 옆의 `return;`만 남는 경우가 발생.

실측 (TripleA i18n A2 ViewMenu 2026-07-28) — `getZoomMenu`의 JOptionPane.showOptionDialog 블록을 patch 했을 때:

```diff
   JOptionPane.showOptionDialog(
       frame,
       panel,
-      "Choose Map Zoom",
+      I18nEngineFramework.get().getText("menubar.ViewMenu.ChooseMapZoomTitle"),
       JOptionPane.OK_CANCEL_OPTION,
       ...
-      new String[] {"OK", "Cancel"},
+      new String[] {"OK", I18nEngineFramework.get().getText("menubar.ViewMenu.Cancel")},
       0);
-  if (result != 0) {
-    return;
-  }
+  return;   // <- 들여쓰기 어긋나서 if 블록 통째로 사라짐
 }
```

원본의 `if (result != 0) {` 라인은 의도한 위치가 맞았지만, patch의 `new_string`에서 해당 두 줄을 빠뜨렸고 fuzzy 매치는 다른 들여쓰기 매치를 우선시하다 보니 `}` 만 남고 `if (result != 0) {` 라인이 통째로 누락됨. 컴파일러는 즉시 에러 (unbalanced brace), Java lint가 잡음. 그러나 **여러 단계 patch + 다른 파일 patch와 섞이면 발견이 늦어짐**.

**교훈 (3가지)**:
1. **대형 patch를 보낸 직후 `git diff` 또는 read_file로 결과 영역의 brace/들여쓰기 정합성을 반드시 본다** — `python3 -c`로 brace 카운트 자동 검증도 가능.
2. **`if (cond) { return; }` 같은 짧은 블록이 매치 영역 끝에 있을 때** `old_string`에 그 if-블록 전체를 포함시켜라. patch `new_string`에 빠뜨려도 fuzzy가 무관한 위치를 잡으면 컴파일러가 잡지만, 같은 파일의 다른 위치에 그게 발견되면 더 위험.
3. **이런 사고는 i18n patch처럼 `JMenuBuilder`/`JOptionPane.showOptionDialog` 같은 boilerplate 호출에 같은 패턴이 함수 여러 곳에 있을 때 잘 일어난다.** ViewMenu처럼 메서드가 10개 이상이면 두 메서드 안에 `JOptionPane.showOptionDialog(...,"XYZ",...)`가 둘 다 있을 수 있고 fuzzy가 의도와 다른 쪽을 잡을 확률이 올라간다.

### 함정 E: "V4A multi-file patch 모드에서 라인 글루(glued-line) 발생" (NEW, 2026-07-28)

`patch(mode='patch')` 로 여러 파일을 한 patch 블록에 묶어 보낼 때, 각 파일의 **`old_string`이 한 줄짜리 패턴 + 매치 위치가 파일의 마지막 라인일 때** 새 라인이 기존 마지막 라인에 **줄바꿈 없이 이어붙음**. lint는 통과(파서가 들여쓰기/괄호/구문만 봄)하지만 실제 properties 파일은 한 줄이 두 항목을 담게 됨.

**실측 (TripleA i18n A2 2026-07-28)** — `ui.properties`의 마지막 줄 한 줄만 잡고 새 키를 추가했을 때:

```diff
-menubar.FileMenu.ManualGamesavePost=Manual Gamesave Post+menubar.FileMenu.ManualGamesavePost=Manual Gamesave Post
+menubar.DebugMenu.Debug=Debug
+menubar.DebugMenu.HardAi=Hard AI
```

→ 첫 번째 줄의 `-` 라인에 `+menubar.DebugMenu.ManualGamesavePost=Manual Gamesave Post`가 글루되어 박힘. properties는 라인 단위 키-값이라 이 한 줄은 두 항목을 동시에 담게 되어 런타임에 키 매핑이 깨짐. 같은 글루가 `ui_de.properties`, `ui_ko.properties`에서도 동시에 발생.

**원인**: V4A multi-file patch는 각 파일의 `old_string`을 fuzzy match하는데, **파일의 EOF에 가까운 한 줄짜리 패턴**은 매치 위치가 좁아 컨텍스트 부족으로 매치 후 줄바꿈 보존이 깨짐. `@@` context hint가 한 줄 위 컨텍스트만 가리키면 새 라인이 그 한 줄에 붙음.

**교훈 (4가지)**:
1. **multi-file V4A patch에서 마지막 줄 한 줄만 잡지 말 것** — 항상 앞 2줄 + `old_string` + 뒤 1줄 컨텍스트를 포함시켜라.
2. **patch 직후 `git diff --stat` + `head -2 $(파일) ; tail -3 $(파일)`** 로 마지막 라인에 글루 발생 여부 즉시 확인.
3. **`@@ context hint`는 항상 `old_string`이 위치하는 줄 위 2~3줄까지 잡아라** — 한 줄 위 컨텍스트는 V4A 모드에서 부족.
4. **글루 발생 시 즉시 `patch(mode='replace')`로 한 줄 정확히 두 줄로 분리** — `old_string`에 줄바꿈을 명시적으로 박아 단일 라인 글루를 깨뜨림.

## Workflow 5단계

소규모 patch(1~3개)도 같은 흐름:

```
1. read_file로 영역을 본다 (offset/limit 정확하게)
2. patch의 old_string에 ±2줄 컨텍스트를 박는다
3. patch를 호출한다
4. 즉시 `git diff path/to/file` 또는 read_file로 검증
5. 검증 실패 → 즉시 patch 취소 (write_file로 통째 재작성)
```

중규모 patch(같은 파일에 4개 이상)면:

```
1. read_file로 전체 파일 본 다음 백업 (메모리 또는 .bak)
2. patch를 한 개씩 부르며 매번 read_file로 매치 영역 확인
3. 모든 patch 끝나면 전체 파일 read_file로 끝-끝 점검
4. lint, build, runtime smoke
```

**Multi-file V4A patch (`mode='patch')` 워크플로** (NEW, 2026-07-28) — properties 파일처럼 "한 줄 = 한 항목" 구조에 여러 파일을 한 번에 박을 때:

```
1. 각 파일의 `@@ context hint` 줄을 **파일의 마지막 2~3줄 + 새 라인 + 파일의 첫 1줄**로 구성
2. 한 patch 블록에 모든 파일을 묶어 보냄 (V4A는 multi-file을 한 번에 처리)
3. 직후 `for f in <files>; do echo "--- $f ---"; tail -5 "$f"; done` — 글루(glued-line) 발생 여부 확인
4. 글루 발견 시 해당 파일만 `patch(mode='replace')` 로 단일 라인으로 분리
5. 빌드/검증
```

## Anti-patterns

### ❌ 같은 파일에 N개 patch를 보내면서 line number를 머릿속으로 추적

patch는 line number를 노출하지 않는다. N개 보내면 매번 영역이 바뀌어서 마지막 patch는 거의 항상 어긋남. **반드시 매 patch 후 read_file**.

### ❌ patch를 너무 자주 보내고, 그 사이빌드를 안 돌림

빌드는 1~5초. 빌드가 잡아주는 회귀가 많다 (들여쓰기, 콤마, 괄호). "큰 patch 단위로 빌드 검증"이 "patch마다 빌드 검증"보다 약함.

### ❌ patch에서 "보너스" 변경

"You know what, while I'm here, let me also..." — patch에 의도 외 변경을 섞으면 **회귀 발생 시 어느 patch가 원인인지 못 찾음**. 디버깅 시간이 5배가 됨.

## 검증 도구

- `patch` 도구 자체의 `lint` 출력 — syntax-level 검증. import 누락은 못 잡음.
- `npm run build` 등 빌드 명령 — ESM 트랜스폼, 큰 syntax miss는 잡힘.
- `git diff <file>` — patch 결과 검증의 가장 빠른 신호. **30초짜리 명령**.
- 런타임 smoke (dev 서버 띄워서 콘솔 보기) — 빌드는 통과했지만 런타임에서 깨지는 케이스. import 누락은 여기서만 잡힘. **자동화 어려움**.

## 관련 스킬

- `systematic-debugging` — 패치 후 발생한 버그를 디버깅할 때
- `ad-hoc-verification` — 시각/문서 변경에 대한 ad-hoc 검증
- `test-driven-development` — patch에 회귀 테스트 동반 패턴

## 실측: minimax-of-duty viewmodel 패치 (2026-07-27)

| # | patch 호출 | 결과 | 후속 |
|---|---|---|---|
| 1 | viewKeyScale 0.55→0.42, 컨텍스트 포함 OK | ✅ 정확 | - |
| 2 | 코멘트 추가 + viewKeyScale 0.42 유지 | ⚠️ viewFillOcclusion 0.45 중복 박힘 | 즉시 발견 못함 |
| 3 | 중복 제거 patch | ✅ 한 번에 정리 | search_files로 확인 |
| 4 | 코멘트 단어 정리 patch | ⚠️ viewFillOcclusion 다시 중복 | 3번 patch 무효화 |
| 5 | 다시 중복 제거 | ✅ 완료 | search_files로 확인 |

**원인**: 2번 patch는 new_string에 코멘트만 바꾸고 기존 코드 라인을 다시 박았는데, 인접 라인 매치가 가장 일치하는 라인을 잡아서 viewFillOcclusion이 새로 박힘. **컨텍스트 ±1줄은 충분했어야 하지만 다른 patch로 라인 번호가 한 줄씩 밀려 있어 다른 위치를 잡음**.

**교훈**: read_file로 매치 직전+직후 확인했다면 1~2개 patch 안에 잡혔을 것. 이 워크플로의 비용은 30초, 디버깅 5개 patch가 들인 비용은 5분.

## 실측: i18n import 누락 (2026-07-27)

| # | 호출 | 결과 |
|---|---|---|
| 1 | `ui/index.js`에 `import { t }` patch | ✅ |
| 2 | `ui/index.js` `t('feed.enemyEliminated', ...)` 사용 patch | ✅ 빌드 PASS |
| 3 | `ui/demo.js`에 `t(...)` 두 군데 patch (banner.show) | ✅ 빌드 PASS, 하지만 **import 누락** |
| 4 | 그 다음 patch에서 `import { t } from '../i18n/index.js'` 추가 | 드디어 정상 |

**왜 발견 못했나**: vite build는 ESM 트랜스폼이라 `t is not defined` 에러를 **lazy module load 시점**에 발생시킴. 빌드 자체는 PASS. dev 서버 띄우고 한참 뒤에야 콘솔에 빨간 에러.

**교훈**: 새 symbol을 도입하는 patch는 **첫 patch 이전**에 import patch를 먼저 두는 규칙이 효과적. 코드 압축/최적화 환경에서 lazy load되는 함수의 import 누락은 빌드 + 정적 분석 둘 다 못 잡음.

## 실측: TripleA i18n A2 properties multi-file V4A 글루 (2026-07-28)

`patch(mode='patch')`로 `ui.properties` / `ui_de.properties` / `ui_ko.properties` + `DebugMenu.java`를 한 블록에 묶어 보냄. 각 properties 파일의 `old_string`은 **파일의 마지막 한 줄 + 새 두 줄** 패턴이었는데:

```diff
[ui.properties]
-menubar.FileMenu.ManualGamesavePost=Manual Gamesave Post+menubar.FileMenu.ManualGamesavePost=Manual Gamesave Post
+menubar.DebugMenu.Debug=Debug
+menubar.DebugMenu.HardAi=Hard AI
```

세 properties 파일이 동일하게 글루. `@@ context hint`는 직전 한 줄만 잡았고 V4A 매처가 마지막 EOF 라인에 새 라인을 줄바꿈 없이 이어붙임.

**수정**: `patch(mode='replace')`로 글루된 라인 한 곳씩 잡아 두 줄로 분리. 모두 통과.

**교훈**: properties 파일은 라인 단위 포맷이라 글루가 곧 키 매핑 깨짐. **`patch(mode='patch')`로 multi-file 박을 때 `@@ context hint`는 항상 위 2~3줄 + 아래 1줄**. multi-file 컨텍스트 부족은 single-file에서는 잘 드러나지 않음.

## 실측: TripleA i18n A2 ViewMenu patch 다중 들여쓰기 오판 (2026-07-28)

| # | patch 호출 | 결과 | 후속 |
|---|---|---|---|
| 1 | `JMenuBuilder("View",...)` → `I18n...getText("menubar.ViewMenu.View",...)` | ✅ 정확 | - |
| 2 | `getZoomMenu` JOptionPane.showOptionDialog ~ `new String[] {"OK", "Cancel"}` 다중 literal 치환 | ⚠️ **`if (result != 0) {` 줄 누락** — `}` 만 남고 `return;` 단독 | 즉시 patch로 복구 |
| 3 | 복구 patch: `if (result != 0) {` 라인 복원 | ✅ 의도 자리 복귀 | 그러나 다음 session에 같은 사고 위험 |

**원인 분석**: 패치 #2의 `new_string`이 `if (result != 0) { return; }` 두 줄을 빠뜨리고 작성됨. fuzzy 매치는 의도 위치(들여쓰기 14칸)가 아니라 **다른 들여쓰기의 매치 후보**(보일러플레이트 16~18칸 영역)를 우선시하지는 않았지만, 패치가 적용된 후 read_file 검증이 패치 직후 즉시 일어나지 않아 발견이 늦어짐.

**교훈 (3가지)**:
1. **본문이 30줄 이상인 메서드(예: ViewMenu.getZoomMenu, getMapFontAndColorEditorMenu)에 다중 literal patch를 한 번에 보낼 때 가장 위험** — patch 내부의 if/final-return이 매치 영역 경계에 있으면 빠지기 쉽다.
2. **patch 직후 read_file로 결과 영역의 brace 정합성을 즉시 확인** — 본 세션에서 함정이 발생했음에도 후속 patch를 보내기 전 검증을 못 함. **patch #1 → patch #2 사이에 read_file 또는 build (:game-headed:compileJava) 1회**가 본 세션에서 부족했다.
3. **i18n 패턴이 동일한 메서드가 ViewMenu 안에 10+ 개** — boilerplate (`JMenuBuilder`, `JOptionPane.showOptionDialog`) 호출 패턴이 같아 fuzz 매치가 조용히 옆으로 새는 확률이 단일 메서드 클래스보다 훨씬 높다.

**즉시 실행 가능한 운영 규칙** (A2 작업 도출):
- 같은 파일에 다중 literal patch를 보낸 경우, **다음 patch 직전에 `./gradlew :game-headed:compileJava` 30초 빌드** — Java는 brace/import 누락을 컴파일 시점에 잡는다.
- patch의 매치 영역이 함수 본문 끝의 if-return 블록을 가로질을 땐, **함수 전체를 read_file**로 본 뒤 write_file로 통째 교체도 검토.

### 함정 G: "직전 세션의 patch 결과에 `+` literal이 본문에 남아있으면 다음 patch가 폭주한다" (NEW, asciirogue v0.5.10 2026-07-29)

이전 세션의 patch 결과가 **잘못 보존되어** `+` prefix literal이 그대로 파일 본문에 남아있는 경우, 다음 세션의 patch 호출이 **그 `+` 줄을 old_string의 첫 줄로 잘못 인식**하고, 다시 그 위에 V4A diff 형식의 새 라인(`+ new content`)을 쌓으려 시도. 결과: **들여쓰기 + 라인 폭주** + 컴파일러는 `expected expression, found '+'` 에러로 즉시 발견하지만, **patch가 5~6번 누적된 후 발견**되어 그 사이의 patch들을 모두 재실행해야 함.

실측 (asciirogue v0.5.10 시작 시점, lib.rs:312):

```rust
KeyCode::Char('>') => {
    let can_descend = if let Ok(pos) = self.world.get::<&Position>(self.player) {
+                            matches!(self.dungeon.at(pos.0 .0, pos.0 .1), Tile::StairsDown)
+                        } else {
+                            false
+                        };   // ← 첫 번째 `+`는 patch 도구가 만든 literal이 본문에 박힌 것
```

→ 새 patch가 그 `+` 줄을 `old_string`으로 매치하려고 시도. V4A diff 형식(`+` line content)을 또 박으려고 시도. 들여쓰기가 4중으로 누적되어 `line.push(match ... { line.push(match ... { line.push(...)...` 같은 패턴.

**탐지 신호**:
- `git diff`가 uncommitted 상태로 **비정상적으로 큰 delta** (특히 `+` / `-` literal이 본문에 보일 때)
- `cargo build`에서 `expected expression, found '+'` (Rust) / `SyntaxError: invalid syntax` (Python) / `Unterminated string literal`
- 같은 파일에 같은 영역에 대해 patch가 5번 이상 누적된 경우

**수정 패턴**:
1. **첫 번째 액션**: `read_file`로 매치 영역을 **읽기**. `+` literal이 있는지 시각 확인.
2. 매치 영역이 깨끗해질 때까지 패치를 **보내지 말 것**.
3. 깨끗해진 후 **단일 `patch(mode='replace')`로 통째 교체** — multiple small patches는 절대 chain하면 안 됨. 이전 patch 결과가 그 다음 patch의 old_string을 오염시키는 가장 빠른 길.

**Carry-forward** (session start preflight):
```bash
# 1. 모든 uncommitted delta에서 `+` / `-` literal이 본문에 있는지 grep
git diff | head -100 | grep -E "^\+[+]" | head -5
# 2. 의심 파일은 read_file로 직접 확인
read_file path/to/file offset=LIMIT-10 limit=20
# 3. 깨끗하면 patch 시작, 깨끗하지 않으면 write_file로 통째 재작성
```

**가장 잔인한 변형**: main.rs L1500 부근에서 **13번 연속 patch**가 들여쓰기 4중 중첩을 만든 사례 — patch 도구가 `new_string`을 만들 때마다 들여쓰기를 4칸씩 더 들여서 합성. `git diff` 단 한번으로 즉시 발견됐어야 했음.

### 함정 H: "patch 호출 시 mode='replace' + V4A patch 형식 동시 전송" (NEW, 2026-07-29)

patch 도구는 두 가지 모드:
- `mode='replace'` (default): `path` + `old_string` + `new_string` 단일-파일 치환
- `mode='patch'`: V4A 형식(`*** Begin Patch\n*** Update File: ...`) multi-file 패치

**이 둘을 섞어서 호출하면 path 누락 + malformed request**가 4번 반복됨. 매번 "path required" 에러가 나는데, 같은 패턴을 반복하는 가장 흔한 원인:

```json
// ❌ mode='replace'인데 V4A 형식 + path 누락
{"mode": "replace", "new_string": "*** Begin Patch\n*** Update File: ...", "patch": "..."}
```

**교훈**: 호출 직전에 **schema 확인** (1초). mode='replace'면 `path` + `old_string` + `new_string` 3개. mode='patch'면 `patch` 1개. 둘 다 동시에 보내지 말 것.

**가장 잔인한 변형 — 한 세션 안에서 5번 연속 같은 루프**: schema 실수가 반복되면 "다시 한 번 같은 호출" instinct이 작동하지만 실제로는 같은 실패를 5번 연속 만드는 패턴이 자주 나옴. 실측 (asciirogue v0.5.11, 2026-07-29) — read_file로 매치 영역을 정확히 확인한 직후에도 같은 path-누락 호출을 5번 반복. **루프에 빠졌다면 다른 도구로 우회** (예: `terminal` + `python3 << EOF` + `f.write(...)` 또는 `execute_code`의 `write_file`/`patch` 호출). **`same_tool_failure_warning: count=N`이 3을 넘는 순간 다른 도구로 우회하라** — 4번째 같은 시도는 시간 낭비.

### 패턴: "BFS 거리 상수 두 종류 — abundant vs exactly-one" (NEW, asciirogue v0.5.10)

한 종류 상수를 **두 BFS 함수가 공유**하면, 한쪽 UI 목표가 다른 쪽을 망가뜨림. 실측:

```rust
// BROKEN: pickup 윈도우(24)를 stairs에도 적용
const MAX_PICKUP_SEARCH: usize = 24;
if d >= MAX_PICKUP_SEARCH { break; }   // stairs도 24에서 cut
```

1층 first-room center(7,4) → last-room center(54,20) Manhattan ~31. 첫 번째 probe가 즉시 잡음:

```
thread 'returns_some_when_stairs_within_radius' panicked
```

**수정**: 두 개의 상수, 각자 use case.

```rust
const MAX_PICKUP_SEARCH: usize = 24;   // abundant → hide far away
const MAX_STAIRS_SEARCH: usize = 999;  // exactly-one → always show
```

**판별 질문**: 새 BFS-distance hint를 추가할 때, "X가 abundant인가 exactly-one-per-floor 인가?" — abundant는 tight cap, exactly-one은 generous cap. 같은 상수 공유 금지.

### 패턴: "headless `--dump` 는 VIEW_RADIUS 캡 — floor-wide 검증 부족" (NEW, asciirogue v0.5.10)

TUI headless dump는 VIEW_RADIUS (= 5)만 그려서 **floor 전체 검증이 안 됨**. 새 타일/적/아이템이 시야 밖에 있으면 dump에 안 나옴.

실측: `cargo run --dump --seed 0xCAFE --count 1` 으로는 StairsDown ▼ 가 안 보임 — last room center (54,20)는 player spawn (7,4)에서 63 타일 거리.

**수정**:
1. **단기**: 별도 example script로 location 검증 (one-shot, 검증 후 삭제).
   ```rust
   // crates/procgen/examples/stairs_check.rs
   let d = bsp::generate(60, 24, seed, bsp::Config::default());
   let last = d.rooms.last().unwrap();
   let (cx, cy) = last.center();
   assert!(matches!(d.at(cx, cy), Tile::StairsDown));
   ```
2. **장기**: `dump`에 `--reveal` 플래그 추가 — VIEW_RADIUS 우회. 아직 미구현.

**Carry-forward**: 새 floor-wide placement 로직 검증할 때 `cargo run --dump`만으로는 부족. 단일 example script + 위치 직접 확인.
