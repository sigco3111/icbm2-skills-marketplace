---
name: patch-line-context-safety
description: "patch tool 호출 시 인접 라인 중복·누락 / import 누락 / 매치 오판을 막는 실전 규칙."
version: 1.0.0
license: MIT
category: software-development
metadata:
  hermes:
    tags: [patch, debugging, refactor, workflow]
    related_skills: [systematic-debugging, test-driven-development]
---

# Patch Line Context Safety

`patch` 도구(`mode: 'replace'`)는 `old_string`을 fuzzy match해서 찾아내고, 매치된 라인은 그대로 두고 새 라인을 끼워넣는다. 이게 강력하지만 **인접 라인이 같아 보이는 경우 중복으로 박힐 수 있음**. 본 스킬은 그 함정의 한 단계 위, **호출 습관과 검증 워크플로**로 막는다.

## 핵심 규칙

### 1. `old_string`은 인접 라인 ±2줄은 항상 포함시켜라

```js
// ❌ 위험: 인접 라인이 거의 동일한 키-값 패턴이면 매치 후보가 둘
old_string: "viewKeyScale: 0.42,"
new_string: "viewKeyScale: 0.55,"

// ✅ 안전: 위 + 아래 2줄 컨텍스트 포함
old_string: "      viewFillOcclusion: 0.45,\n      // ---- viewmodel 3-point rig ----\n      // The key is scaled off the scene's own light level\n      viewKeyScale: 0.42,\n      viewKeyMax: 2.6,"
new_string: "      viewFillOcclusion: 0.45,\n      // ---- viewmodel 3-point rig ----\n      // The key is scaled off the scene's own light level\n      viewKeyScale: 0.55,\n      viewKeyMax: 2.6,"
```

3개 라인이 같은 패턴이면 (예: `viewFillOcclusion: 0.45`, `viewKeyScale: 0.42`, `viewHemiRatio: 0.16`이 모두 `key: number,` 한 줄짜리) **fuzzy match가 잘못된 위치를 잡을 가능성**이 있다. 컨텍스트 라인이 없으면 매치 후 결과는 "원래 라인은 두고 새 라인이 박힘" 또는 "잘못된 위치에 새 라인이 박힘".

### 2. patch 호출 직후, 같은 파일에 다른 patch를 보낼 거면 **반드시 read_file로 매치 영역을 다시 본다**

특히 **같은 파일에 N개 patch를 보내는 경우**, 첫 patch가 변경한 후의 라인 번호는 두 번째 patch의 매치 영역과 안 맞을 수 있다.

```python
# ❌ 흔한 실수
patch("weapons.js", "a: 1,", "a: 2,")
patch("weapons.js", "b: 1,", "b: 2,")   # 첫 patch가 주변 라인을 바꿔서 매치 위치 미스매치 가능

# ✅ 안전 패턴
patch("weapons.js", "context_a\n  a: 1,\ncontext_a2", "context_a\n  a: 2,\ncontext_a2")
read_file(path, offset=<첫 patch 라인-2>, limit=10)  # 매치 영역 확인
patch("weapons.js", "...", "...")                    # 두 번째 patch는 갱신된 라인 번호로
```

### 3. patch에 새 식별자·함수 호출이 들어간다면, **import 라인을 먼저 patch하라**

```js
// ❌ 위험 순서: t()를 4군데 patch → 마지막에 import 한 번. 중간에 파일을 보면 lint가 통과해도,
// 런타임에서 t is not defined가 나옴
patch("ui/demo.js", "banner.show('Enemy Eliminated', ...)",
                  "banner.show(t('feed.enemyEliminated'), ...)")  // t가 import 안 됨
patch("ui/demo.js", ...) // 또 다른 곳
// ... 중간에 import 패치 누락
```

**왜 위험한가**: patch는 lint를 통과해도 런타임에 부서지면 dev 서버 콘솔에 늦게 발견됨. imagediff는 게임 화면 캡처라 게임이 부서졌어도 검은 화면으로 검출됨. 즉 **빌드 PASS + 시각 PASS가 t 누락을 가려줌**.

**안전 패턴**:
- 새 symbol을 도입하는 patch는 **해당 파일의 첫 patch 이전에 import 라일을 patch**
- 또는 symbol이 한 군데만 쓰이고 import가 명확하면 그 patch에 import 추가를 새 줄로 함께 박기 (둘이 인접 영역이면)

### 4. patch 직후 `git diff -- <파일>` 또는 `read_file`로 매치 결과 검증

```bash
git diff path/to/file.js | head -40
```

이 한 줄로 다음이 잡힘:
- **중복 박힘** (예: `viewFillOcclusion: 0.45,` 두 번)
- **인접 라인 손상** (예: `viewKeyScale: 0.55,` 라인이 사라짐)
- **들여쓰기 / 괄호 / 콤마 누락** (TS/JS Lint가 잡지만 Python은 못 잡는 경우 多)

**30초짜리 검증이 30분짜리 디버깅을 막음**. 단발 patch라도 항상 함.

### 5. 인접 라인이 동일할 때 — patch 안 쓰고 write_file로 통째 교체

만약 5줄 블록 안에 바꿀 게 3줄이고 그중 둘이 매우 비슷한 라인이면 **patch를 3번 보내지 말고 read_file로 영역 본 다음 write_file로 통째 교체**.

```python
# read_file로 영향 영역 통째 읽기 (offset/limit)
# 새 내용 write_file
# → 중복/누락 0
```

이건 patch의 "fuzzy match가 위험한 경우"의 escape valve.

## 흔한 함정 패턴 4가지

### 함정 A: "두 줄의 차이가 비슷한 라인을 사이에 두고 있다"

```
원본:
  A: 1,
  B: 1,
  C: 1,

목표:
  A: 2,
  B: 1,
  C: 1,
```

`old_string: "A: 1,\nB: 1,\nC: 1,"`로 A:B:C 셋 다 잡아서 A만 바꾸면 됨. 하지만 **fuzzy match가 sparse한쪽 한 줄만** 잡으면 무관한 라인에 새 라인이 박힘.

**교훈**: 인접 컨텍스트는 항상 2줄 이상 포함.

### 함정 B: "위 라인이 사라질 때 아래 라인이 올라온다"

```
원본:
  X: old,
  Y: 1,

  Z: 1,
```

X를 지우려면 `old_string: "  X: old,\n  Y: 1,\n\n  Z: 1,"`로 컨텍스트 잡고, new는 Y부터 시작. **빈 줄 처리** 잊으면 항상 어긋남.

### 함정 C: "patch가 두 군데를 동시에 바꿨다 (replace_all 없이)"

`old_string`이 파일 안에 두 곳에서 발견되면 patch는 **"Could not find a match"** 에러로 거부된다 — 그래서 발견은 쉽다. 다만 **에러가 안 나는 케이스**: `old_string`이 한 곳에서만 발견됐는데 의도와 다른 위치에 있을 때.

**교훈**: 매치가 의도한 위치의 코드를 **실제로 가리키는지** read_file 한 번으로 확인.

### 함정 D: "patch가 성공했지만 매치 위치가 절반만 맞았다"

가장 잔인한 함정. `old_string`이 fuzzy로 절반 매치되면 의도 위치에 patch가 박히지만 **옛 라인이 남고 새 라인이 위에 박힘**. 코드 동작은 깨짐. lint/typescript는 발견 못할 수 있음.

**교훈**: 다시 한 번 — **patch 후 `git diff` 또는 read_file로 결과 영역 재검증**.

## Workflow 5단계

소규모 patch(1~3개)도 같은 흐름:

```
1. read_file로 영역을 본다 (offset/limit 정확하게)
2. patch의 old_string에 ±2줄 컨텍스트를 박는다
3. patch를 호출한다
4. 즉시 `git diff path/to/file` 또는 read_file로 검증
5. 검증 실패 → 즉시 patch 취소 (write_file로 통째 재작성)
```

중규모 patch(같은 파일에 4개 이상)면:

```
1. read_file로 전체 파일 본 다음 백업 (메모리 또는 .bak)
2. patch를 한 개씩 부르며 매번 read_file로 매치 영역 확인
3. 모든 patch 끝나면 전체 파일 read_file로 끝-끝 점검
4. lint, build, runtime smoke
```

## Anti-patterns

### ❌ 같은 파일에 N개 patch를 보내면서 line number를 머릿속으로 추적

patch는 line number를 노출하지 않는다. N개 보내면 매번 영역이 바뀌어서 마지막 patch는 거의 항상 어긋남. **반드시 매 patch 후 read_file**.

### ❌ patch를 너무 자주 보내고, 그 사이빌드를 안 돌림

빌드는 1~5초. 빌드가 잡아주는 회귀가 많다 (들여쓰기, 콤마, 괄호). "큰 patch 단위로 빌드 검증"이 "patch마다 빌드 검증"보다 약함.

### ❌ patch에서 "보너스" 변경

"You know what, while I'm here, let me also..." — patch에 의도 외 변경을 섞으면 **회귀 발생 시 어느 patch가 원인인지 못 찾음**. 디버깅 시간이 5배가 됨.

## 검증 도구

- `patch` 도구 자체의 `lint` 출력 — syntax-level 검증. import 누락은 못 잡음.
- `npm run build` 등 빌드 명령 — ESM 트랜스폼, 큰 syntax miss는 잡힘.
- `git diff <file>` — patch 결과 검증의 가장 빠른 신호. **30초짜리 명령**.
- 런타임 smoke (dev 서버 띄워서 콘솔 보기) — 빌드는 통과했지만 런타임에서 깨지는 케이스. import 누락은 여기서만 잡힘. **자동화 어려움**.

## 관련 스킬

- `systematic-debugging` — 패치 후 발생한 버그를 디버깅할 때
- `ad-hoc-verification` — 시각/문서 변경에 대한 ad-hoc 검증
- `test-driven-development` — patch에 회귀 테스트 동반 패턴

## 실측: minimax-of-duty viewmodel 패치 (2026-07-27)

| # | patch 호출 | 결과 | 후속 |
|---|---|---|---|
| 1 | viewKeyScale 0.55→0.42, 컨텍스트 포함 OK | ✅ 정확 | - |
| 2 | 코멘트 추가 + viewKeyScale 0.42 유지 | ⚠️ viewFillOcclusion 0.45 중복 박힘 | 즉시 발견 못함 |
| 3 | 중복 제거 patch | ✅ 한 번에 정리 | search_files로 확인 |
| 4 | 코멘트 단어 정리 patch | ⚠️ viewFillOcclusion 다시 중복 | 3번 patch 무효화 |
| 5 | 다시 중복 제거 | ✅ 완료 | search_files로 확인 |

**원인**: 2번 patch는 new_string에 코멘트만 바꾸고 기존 코드 라인을 다시 박았는데, 인접 라인 매치가 가장 일치하는 라인을 잡아서 viewFillOcclusion이 새로 박힘. **컨텍스트 ±1줄은 충분했어야 하지만 다른 patch로 라인 번호가 한 줄씩 밀려 있어 다른 위치를 잡음**.

**교훈**: read_file로 매치 직전+직후 확인했다면 1~2개 patch 안에 잡혔을 것. 이 워크플로의 비용은 30초, 디버깅 5개 patch가 들인 비용은 5분.

## 실측: i18n import 누락 (2026-07-27)

| # | 호출 | 결과 |
|---|---|---|
| 1 | `ui/index.js`에 `import { t }` patch | ✅ |
| 2 | `ui/index.js` `t('feed.enemyEliminated', ...)` 사용 patch | ✅ 빌드 PASS |
| 3 | `ui/demo.js`에 `t(...)` 두 군데 patch (banner.show) | ✅ 빌드 PASS, 하지만 **import 누락** |
| 4 | 그 다음 patch에서 `import { t } from '../i18n/index.js'` 추가 | 드디어 정상 |

**왜 발견 못했나**: vite build는 ESM 트랜스폼이라 `t is not defined` 에러를 **lazy module load 시점**에 발생시킴. 빌드 자체는 PASS. dev 서버 띄우고 한참 뒤에야 콘솔에 빨간 에러.

**교훈**: 새 symbol을 도입하는 patch는 **첫 patch 이전**에 import patch를 먼저 두는 규칙이 효과적. 코드 압축/최적화 환경에서 lazy load되는 함수의 import 누락은 빌드 + 정적 분석 둘 다 못 잡음.
