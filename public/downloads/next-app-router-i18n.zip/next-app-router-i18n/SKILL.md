---
name: next-app-router-i18n
description: "Adding multilingual UI to a Next.js App Router project."
tags: [nextjs, app-router, i18n, localization, dictionary, cookie-locale, en-ko, evolve]
metadata:
  hermes:
    related_skills: [cross-fork-pr-submission]
---

# Next.js App Router i18n — cookie-driven + dictionary-driven

**트리거**:
- "다국어 추가", "i18n 추가", "한국어/일본어 지원", "번역 인프라", "locale 토글"
- 기존 영어 단일-로케일 Next.js 프로젝트에 다국어 입힐 때
- 점진적으로 카피/스코어링/페이지에 locale 적용할 때

**핵심 원칙**: lib/i18n dict + cookie + provider + server resolver = 4-layer 분리. 의존성은 server → client 로 한 방향만 흐르게.

## 🏗️ 4-layer 아키텍처 (검증됨 — gitfut PR #104)

```
server-side request
   ↓
[1] lib/i18n/server.ts        resolveServerLocale() = cookie > Accept-Language > default
                              resolveEnglishLocale() = "en" hard-pinned (for OG)
   ↓
[2] app/layout.tsx           <html lang={locale}> + <LocaleProvider initialLocale={locale}>
                              children = React tree
   ↓
[3] lib/i18n/t.ts            t(key, locale, params), t.archetype/playstyle/metric/duelStatRow/
                              countryName/localeName (typed helper API)
   ↓
[4] lib/i18n/dict/{en,ko}.ts 두 dict가 동일 키 셋을 강제 (drift 테스트가 깨지면 build fail)
```

4개 레이어가 서로를 모르게 함:
- server는 locale만 알지 dict 구조는 모름
- client는 `useLocale()`로 cookie 변경 구독만
- `t()`는 dict를 모르며 키 path만 앎
- dict는 어떤 컴포넌트가 읽는지 모름

## 🧾 dictionary-as-data 패턴 (의존성 주입)

```ts
// lib/i18n/index.ts
export const SUPPORTED_LOCALES = ["en", "ko"] as const;
export type Locale = (typeof SUPPORTED_LOCALES)[number];
export const DEFAULT_LOCALE: Locale = "en";

// lib/i18n/dictionaries.ts
import { en } from "./dict/en";
import { ko } from "./dict/ko";
const DICT: Record<Locale, Dictionary> = { en, ko };
export function getDict(locale: Locale): Dictionary {
  return DICT[locale] ?? DICT[DEFAULT_LOCALE];
}
```

**왜 dict-as-data가 옳은가**:
- 새 locale 추가 = 2줄 변경 (SUPPORTED_LOCALES + import)
- 컴포넌트는 enum key만 알면 됨
- 키 누락 → `tests/i18n.test.ts`의 drift 검사가 CI에서 잡음
- 런타임 i18n 라이브러리 의존성 0 (next-intl, react-i18next 등 X)

## 🍪 cookie-driven + `@`-locked escape hatch

```ts
// lib/i18n/index.ts
export const LOCALE_COOKIE_NAME = "gitfut_locale";
export const LOCALE_COOKIE_MAX_AGE = 60 * 60 * 24 * 365; // 1년

// Negotiation: "ko-KR,ko;q=0.9,en;q=0.8" → "ko"
export function negotiateLocale(header: string | null | undefined): Locale {
  if (!header) return DEFAULT_LOCALE;
  // quality factor + region tag 분리, 매칭 우선순위로 정렬
  // ...
}
```

### `@` locked key — OG/카드 카피 안전 잠금

```ts
// lib/i18n/t.ts
function stripLockPrefix(k: string): { locked: boolean; path: string } {
  if (k.startsWith("@")) return { locked: true, path: k.slice(1) };
  return { locked: false, path: k };
}

function translateFlat(key, locale, params) {
  const { locked, path } = stripLockPrefix(key);
  const effectiveLocale = locked ? DEFAULT_LOCALE : locale;  // 항상 EN
  // ...
}

// 사용:
t("@ui.scoutForm.headline", "ko");  // "GET SCOUTED." (KO 무시)
```

**왜 `@`?** 카드 아트, OG 이미지, JSON API는 **브랜드 카드**라 viewer locale 따라가지 않고 **항상 EN 고정**. `@` prefix가 이 의도를 코드에서 1글자로 표현.

## 🖥️ server + client provider 분리

```ts
// lib/i18n/server.ts (서버 전용)
import { cookies, headers } from "next/headers";

export async function resolveServerLocale(): Promise<Locale> {
  try {
    const ck = (await cookies()).get(LOCALE_COOKIE_NAME)?.value;
    if (localeFromCookie(ck) !== DEFAULT_LOCALE) return localeFromCookie(ck);
  } catch { /* cookies() throws in non-request scope */ }
  try {
    return negotiateLocale((await headers()).get("accept-language"));
  } catch {
    return DEFAULT_LOCALE;
  }
}

export async function resolveEnglishLocale(): Promise<Locale> {
  return "en";  // OG/JSON 라우트에서 explicit pin
}
```

```ts
// lib/i18n/LocaleProvider.tsx (클라이언트)
"use client";
export function LocaleProvider({ children, initialLocale }: ...) {
  const [locale, setLocale] = useState<Locale>(initialLocale ?? DEFAULT_LOCALE);
  // cookie 쓰면 "gitfut:localechange" 커스텀 이벤트 fire → useSyncExternalStore 구독자들 re-render
}
```

```ts
// lib/i18n/useLocale.ts (subscriber hook)
"use client";
export function useLocale(): Locale {
  return useSyncExternalStore(
    (cb) => { window.addEventListener("gitfut:localechange", cb); ... },
    () => getCookieLocale(),
    () => DEFAULT_LOCALE,
  );
}
```

## ✅ 검증 (1차 정렬)

```bash
npx tsc --noEmit          # 0 errors
npm test                 # 296/296 PASS (기본 276 + 신규 i18n 19 + 영향 1)
gh auth status           # sigco3111 (keyring)
```

## 🪤 함정 — **이번 세션이 12번 걸린 실수 모음**

| 함정 | 해결 |
|---|---|
| LSP가 컴포넌트 첫 줄 변수 정의 위치 추적 못함 → patch가 한참 뒤 위치 수정 | lint 진단부터 보고, 정확히 그 줄의 full context block을 old에 둠 |
| `t.attribute.skillMoves`처럼 함수 슬롯에 default 함수 추가 → Translator 인터페이스에 동일 signature 메서드 추가 안 함 → 다른 곳에서 호출하면 "Expected 1 arguments" | Translator에 새 메서드 추가 시 `interface Translator` 확장도 같이 |
| dict/ko.ts에서 함수여야 할 키를 string으로 추론 → 빌드 fail (TS2322) | `(vars) => string` 명시 arrow function 시그니처 |
| `lib/format.ts` (옛 `(n) => string`)를 `lib/i18n/format.ts` (`(n, locale)`)로 import 경로 변경 안 함 | `npm test`에서 옛 import가 살아있으면 silent fail. scoring 코드는 옛 경로를 그대로 쥐고 있을 가능성 큼 |
| `useUIDict()`처럼 client hooks가 server 컴포넌트 안에서 호출됨 | server 컴포넌트에서는 `getDict(locale).ui.foo` 직접 접근, client에서만 hooks |
| drift 테스트가 250-country dict를 강제 → en과 ko 둘 다 253 entry 모두 가져야 함 | 빈 dict 우선 + EN 위임, KO는 priority subset만 override |
| `deriveSkillMoves` 기본값은 langs>=4=3이지만 한참 수정 중 langs>=3=3으로 바꿈 → test "at(3)===2" fail | scoring 동작 변경 금지. **dict만 바꾸고 logic 보존** |
| LocaleProvider가 `<html>`을 layout 단에서 한 번 감싸야 hydration mismatch 없음 | `<html lang={locale}>` + LocaleProvider children을 layout에서 wrap |
| `computeDuel(card1, card2)` 호출 site 모두에 locale 인자 추가 안 함 → 듀얼 페이지 영문 잔재 | `grep` 후 모든 호출 site 찾아 3번째 인자 전달 |
| dict의 `workRate.reason`, `ui.share.scoutTitle` 같은 string-interpolation 자리는 **함수**: `(vars) => interpolate(vars)`로 타입 정확 | UIDict 타입에 `(vars: { attack; defense }) => string` 명시 |
| score function에서 `t.attribute.skillMoves(value, s.languages, bonus, formatCount(...))` — `formatCount(s.public_repos, locale)`의 두 번째 인자 누락 | 옛 `formatCount(n)` 단일 인자 함수를 새 `(n, locale)`로 import 갱신했는지 확인 |
| patch의 `new_string`를 정확히 들여쓰기 안 맞추면 JSX closing brace가 어긋남 | 들여쓰기 불확실하면 patch보다 **파일 전체 write_file**로 갈아엎음 |

## 🎯 일반화 recipe

```bash
# 1) 데이터 모델
mkdir lib/i18n/
# index.ts, server.ts, dictionaries.ts, useLocale.ts, LocaleProvider.tsx,
# hooks.ts, t.ts, format.ts
# dict/{types,en,ko,...}.ts

# 2) provider 통합
# app/layout.tsx: cookies() + LocaleProvider + <html lang={locale}>

# 3) 컴포넌트 점진 교체
# 기존 "영문 literal" → t("ui.section.key", locale) → const { locale } = useLocale();
# 1개 컴포넌트씩 옮기며 npm test + 시각 확인

# 4) scoring/도메인 코드
# buildCard(s, locale="en")  # default en
# derivePlaystyles(s, locale)
# deriveMetrics(s, locale)
# deriveStyle/WeakFoot/WorkRate/SkillMoves(s, locale)

# 5) OG 라우트
# app/api/card-image/[username]/route.tsx → buildCard(s, "en") explicit
# buildFresh() in lib/scout.ts → buildCard(s, "en")

# 6) 테스트
# tests/i18n.test.ts
# - enum dict parity (en vs ko 키 셋 동일)
# - negotiate locale
# - locked key (@) returns EN
# - format helper accept locale
```

## 💡 Lesson learned

1. **점진 적용** — 1차에 전부 dict로 바꾸려 하지 말고, 레이아웃 + 핵심 컴포넌트 (ScoutForm, LoadingScreen) → 모달 → 듀얼/리포트 → 도메인 scoring → 국가 데이터 순서로
2. **drift 테스트가 진짜로 동작함** — 새 키 한쪽 dict에만 추가하면 `npm test`가 즉시 깨짐. 이게 가장 중요한 guard
3. **데이터 dict가 scoring core를 깨지 않게** — locale 인자 default `="en"`이라 기존 호출 site는 변경 불필요. 새 호출 site만 `locale` 전달
4. **`@` prefix는 1글자 디자인 결정** — 카드/OG는 항상 EN이라는 의도를 코드에서 자기-문서화

## 사용법 / 결정 트리

```
"i18n 추가해줘" 수신
├─ 클래스 작업? → 이 스킬
│  ├─ 기존 dict + token 네임스페이스가 있나?
│  │  ├─ 예 → 새 키 추가 + drift 테스트 + (필요시) 새 dict/en.ts 행
│  │  └─ 아니오 → 새 dict/en.ts 파일 1개 만들고 en→ko 변환은 별도 작업
│  ├─ OG/카드 카피는 항상 EN인가?
│  │  └─ `t("@...", locale)` 또는 OG 라우트에서 `locale="en"` 명시
│  └─ 우선순위: 나라 데이터 > scoring > UI > meta
```

## 📂 references/

세부 구현 / 함수 시그니처 / 드리프트 테스트 패턴은:
- `references/dict-drift-test.md` — en/ko 키 셋 강제 검사 패턴
- `references/cookie-vs-accept-language.md` — locale 협상 우선순위
- `references/locked-key-pattern.md` — `@` prefix OG/카드 영문 잠금
- `references/server-client-provider-split.md` — server resolver vs client cookie hooks
