# `@`-prefix locked key — OG/카드 안전 잠금

**문제**: 카드 아트, OG 이미지, JSON API 응답은 **브랜드 카드**라 viewer locale 따라가지 않고 항상 EN으로 고정해야 함. 그런데 일반 dict lookup은 자연히 locale을 따라가서 KO 카피가 카드에 새어들 수 있음.

## 1글자 디자인 결정: `@` prefix

```ts
// lib/i18n/t.ts
function stripLockPrefix(k: string): { locked: boolean; path: string } {
  if (k.startsWith("@")) return { locked: true, path: k.slice(1) };
  return { locked: false, path: k };
}

function translateFlat(key, locale, params) {
  const { locked, path } = stripLockPrefix(key);
  const effectiveLocale = locked ? DEFAULT_LOCALE : locale;
  // lookup with effectiveLocale
}
```

## 사용

```tsx
// 클라이언트 컴포넌트가 카드에 들어갈 카피를 KO 모드에서도 가져올 때
import { t } from "@/lib/i18n/t";

export function ScoutingBadge() {
  return <span>{t("@ui.scoutForm.submitting", useLocale())}</span>;
  // 항상 "SCOUTING…" (KO locale에서도)
}
```

## 더 엄격한 대안: explicit EN pin

```ts
// buildCard(s, "en") — 호출 site에서 직접 EN 강제
const card = buildCard(signals, "en");
```

**`buildCard`가 locale 인자를 받는 함수면 호출 site에서 명시**하는 게 더 명시적. OG 라우트와 JSON API는 이 패턴.

```ts
// lib/scout.ts (OG/JSON 카드 buildFresh)
const card = buildCard(signalsFromPayload(await fetchProfile(username)), "en");
```

## 어느 쪽 선택?

| 상황 | 패턴 |
|---|---|
| 카드 아트 픽셀 좌표 옆 문자열 (그라바타 fallback "AI didn't return one" 등) | `@`-prefix — 디자인 의도가 "브랜드" |
| OG 이미지 빌더 / JSON API 응답 | `buildCard(s, "en")` — 함수 호출 site에서 명시 |
| 카드 외부 (scout report 본문, 숫자 포매팅, "X wins on PAC" 같은 비교 결과) | locale 따라가기 (그냥 `t()`) |
| 라이브러리 카피 (lucide aria-label = "") | 항상 영문 또는 @-prefix |

## Session insight (2026-08-30)

gitfut PR #104 처음에는 `@`-prefix 없이 모두 locale 따라가게 했음 → 카드 아트 안의 "ICON", "GOLDBRONZE" 등 영어 단어가 KO 모드에서도 유지되어야 했는데 잠깐 혼란. 

해결: `@` prefix는 카드 아트 안의 **단일 단어 branding string**만 (예: "@finish.icon"), 그리고 OG/JSON 응답은 **buildCard 호출 시 locale="en" 명시**. 둘이 같은 의도(EN 잠금)지만 표면이 다름.
