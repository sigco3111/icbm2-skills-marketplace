# Drift-detection test — en/ko key parity guard

**왜 필수**: 한쪽 dict에만 키를 추가하는 가장 흔한 버그를 빌드 단계에서 잡음.
dictionary 타입을 TypeScript로 잡았어도, `Record<string, string>`처럼 느슨한 타입을 쓸 때는 키 누락이 통과함.

## 패턴: walk-based key set 비교

```ts
// tests/i18n.test.ts

// 모든 leaf 키 path를 dotted string으로 추출 (배열/객체 재귀)
const walk = (obj: unknown, path: string[] = []): string[] => {
  if (obj == null) return [];
  if (typeof obj === "string") return path.length ? [path.join(".")] : [];
  if (typeof obj === "function") return path.length ? [path.join(".")] : [];
  if (Array.isArray(obj)) return obj.flatMap((v, i) => walk(v, [...path, String(i)]));
  if (typeof obj === "object") {
    return Object.entries(obj).flatMap(([k, v]) => walk(v, [...path, k]));
  }
  return [];
};

it("en + ko have the same key set (drift detector)", () => {
  const enKeys = new Set(walk(getDict("en")));
  const koKeys = new Set(walk(getDict("ko")));
  const missingInKo = [...enKeys].filter((k) => !koKeys.has(k));
  const missingInEn = [...koKeys].filter((k) => !enKeys.has(k));
  expect(missingInKo, `keys missing in KO: ${missingInKo.join(", ")}`).toEqual([]);
  expect(missingInEn, `keys missing in EN: ${missingInEn.join(", ")}`).toEqual([]);
});
```

## 진짜로 잡힌 사례

세션에서 발견한 실제 drift:
- DuelView의 `kicker`, `status`, `dominance`, `backHome`, `howWin`, `drawHeadline`, `skipHint`, `receiptsHeader`, `share.shareDuel`, `statRows`, `metricReceipts` — 처음 en.ts에는 다 있었지만 **ko.ts의 `DuelDict` 타입이 좁아서** 키를 추가해도 빨간 줄 그어지지 않음 → tests/i18n.test.ts이 잡아냄
- ResultView의 `result.back`, `result.backHome`, `result.shareOnX` — ko.ts에 추가 안 했을 때 drift이 fail

## 보조 가드: locale discovery

```ts
it("loads every supported locale", () => {
  for (const locale of SUPPORTED_LOCALES) {
    const dict = getDict(locale);
    expect(dict).toBeTruthy();
    expect(dict.meta.brand).toBe("GITFUT");  // 메타에 sanity check
  }
});
```

## 보조 가드: locked key

```ts
it("locked keys (`@…`) always return EN", () => {
  expect(t("@ui.scoutForm.headline", "ko")).toBe("GET SCOUTED.");
});
```

이 셋 (drift parity + locale load + locked key)이 3대 가드. i18n 추가할 때 3개 다 항상 작성.
