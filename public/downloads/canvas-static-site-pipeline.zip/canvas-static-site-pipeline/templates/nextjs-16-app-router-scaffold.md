# Next.js 16 App Router 보일러플레이트

> 2026-07-10 sigco3111/toss-trader 1단계 실측. Next.js 16 + React 19 + TypeScript 5 + Tailwind v4 + ESLint 9 보일러플레이트.

## 🚀 Quick start

```bash
# 1) /tmp에 보일러플레이트 생성 (직접 프로젝트 디렉토리에 ❌)
rm -rf /tmp/{name}-scaffold
npx --yes create-next-app@latest /tmp/{name}-scaffold \
  --typescript --tailwind --app --eslint \
  --no-src-dir \
  --use-npm \
  --disable-git \
  --import-alias "@/*" \
  --yes 2>&1 | tail -5

# 2) 파일 선택 복사 (app/ public/ package.json tsconfig.json next.config.ts
#    next-env.d.ts eslint.config.mjs postcss.config.mjs)
cp -R /tmp/{name}-scaffold/{app,public,package.json,tsconfig.json,next.config.ts,next-env.d.ts,eslint.config.mjs,postcss.config.mjs,package-lock.json} \
      /Users/mac/work/{name}/

# 3) AGENTS.md v0.3가 보존됨 + Next.js 파일들 추가됨. 기존 toss-trader AGENTS.md는 10310B 유지.
```

## ⚠️ 핵심 함정 5종

### 1. `--agents-md` default가 켜져있음 (직접 실행 함정)

`create-next-app@latest`는 기본적으로 `AGENTS.md` (327B, Next.js 16 breaking change 경고)를 자동 생성. **toss-trader처럼 자체 AGENTS.md가 10310B 박혀있는 프로젝트는 덮어쓰기 위험**.

**해결**: `/tmp/{name}-scaffold`에 생성 후 파일 선택 복사. 본 프로젝트의 AGENTS.md / README.md / LICENSE / docs/는 **복사 대상에서 제외**.

```bash
# 잘못된 예 — 직접 실행 (기존 AGENTS.md 덮어쓰기)
npx create-next-app@latest /Users/mac/work/{name} --typescript ...   # ❌

# 올바른 예 — /tmp에 생성 후 선택 복사
npx create-next-app@latest /tmp/{name}-scaffold ...                  # ✅
cp -R /tmp/{name}-scaffold/{app,public,package.json,...} /Users/mac/work/{name}/
```

### 2. Next.js 15+/16 dynamic route params = `Promise<{...}>`

```typescript
// ❌ 옛 시그니처 (TS 에러)
interface RouteContext {
  params: { path: string[] };
}

// ✅ Next 15+/16 시그니처
interface RouteContext {
  params: Promise<{ path: string[] }>;
}

export async function GET(req: NextRequest, ctx: RouteContext) {
  const { path } = await ctx.params;  // await 필수
  // ...
}
```

### 3. package.json의 name은 직접 정정

`create-next-app`은 `name: "{name}-scaffold"` 박고 끝남. 반드시 toss-trader 이름으로 정정:

```json
{
  "name": "toss-trader",  // ← 정정
  "version": "0.1.0",
  "private": true,
  ...
}
```

### 4. .gitignore는 직접 병합

Next.js 표준 `.gitignore`는 시크릿 격리 규칙이 없음. **기존 프로젝트의 시크릿 격리 규칙을 추가** (toss-trader의 경우):

```gitignore
# === Next.js 표준 ===
/node_modules
/.next/
/out/
*.pem
.env*
.vercel
*.tsbuildinfo
next-env.d.ts

# === toss-trader 추가 (v0.3 시크릿 격리) ===
# Secrets — 절대 추적 금지
*.key
tossinvest.env

# Telegram/Notion
TELEGRAM_BOT_TOKEN
NOTION_API_KEY

# Build (Python)
build/
dist/
*.egg-info/

# CLAUDE.md (oh-my-opencode 미사용)
CLAUDE.md
```

### 5. 빈 디렉토리는 .gitkeep으로

`schemas/`, `lib/`, `components/`는 AGENTS.md v0.3에 명시되어 있지만 비어있으면 git이 추적 안 함:

```bash
mkdir -p schemas lib components
for d in schemas lib components; do
  cat > "$d/.gitkeep" <<EOF
# 빈 디렉토리 유지용. {단계}에서 {파일}.ts 추가 예정.
EOF
done
# 실제 파일이 생기면 .gitkeep은 `rm` (auto).
```

## 📦 package.json 표준 (2026-07-10 시점)

```json
{
  "name": "{name}",
  "version": "0.1.0",
  "private": true,
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start",
    "lint": "eslint",
    "test": "vitest run",
    "test:watch": "vitest"
  },
  "dependencies": {
    "next": "^16",
    "react": "^19",
    "react-dom": "^19"
  },
  "devDependencies": {
    "@tailwindcss/postcss": "^4",
    "@types/node": "^20",
    "@types/react": "^19",
    "@types/react-dom": "^19",
    "eslint": "^9",
    "eslint-config-next": "^16",
    "tailwindcss": "^4",
    "typescript": "^5",
    "vitest": "^4"
  }
}
```

## 🔧 tsconfig.json 표준

```json
{
  "compilerOptions": {
    "target": "ES2017",
    "lib": ["dom", "dom.iterable", "esnext"],
    "allowJs": true,
    "skipLibCheck": true,
    "strict": true,
    "noEmit": true,
    "esModuleInterop": true,
    "module": "esnext",
    "moduleResolution": "bundler",
    "resolveJsonModule": true,
    "isolatedModules": true,
    "jsx": "react-jsx",
    "incremental": true,
    "plugins": [{ "name": "next" }],
    "paths": { "@/*": ["./*"] }
  },
  "include": [
    "next-env.d.ts",
    "**/*.ts",
    "**/*.tsx",
    ".next/types/**/*.ts",
    ".next/dev/types/**/*.ts",
    "**/*.mts"
  ],
  "exclude": ["node_modules"]
}
```

## ✅ 검증 체크리스트 (1단계 끝 시점)

- [ ] `npm run build` 0 에러 (Turbopack, 1387ms 목표)
- [ ] `npm run lint` 0 에러
- [ ] `npm run test` 0 실패 (테스트 파일 없을 시 0 passed도 OK)
- [ ] `git status` 의도된 파일만 추가됨 (AGENTS.md / README.md / docs/ / LICENSE 미변경)
- [ ] v0.3 자기 검증: `grep -rEn "openai|nim|anthropic|apiKey|BYOK|SettingsForm|ChatPanel" app/ components/ lib/` 0건
- [ ] 헤딩 정규화 0/0 깨짐 (bash + python 2중, README.md + AGENTS.md + docs/ARCHITECTURE.md)

## 다음 단계

- **2단계**: OAuth API relay (catch-all dynamic route + `lib/{api}.ts` 클라이언트) — `references/nextjs-fullstack-pipeline.md` §2 참조
- **3단계**: 안전 가드 + TDD (`lib/safety.ts` + `test/safety.test.ts`) — §3 참조
- **4단계**: Telegram confirm + OrderButton — §4 참조
