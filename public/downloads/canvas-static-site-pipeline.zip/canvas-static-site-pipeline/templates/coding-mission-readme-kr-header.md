# Coding Mission README Korean Header Templates (2026-07-09)

> `canvas-static-site-pipeline` 스킬의 §7.5.3.1.1 (헤딩 처음부터 정규화) 보강. 9번째 풀사이클(ant-colony-optimization)까지 검증된 헤딩 셋을 그대로 베껴 쓸 수 있는 템플릿. **두 어서션 0 + patch 0회** default.

## 📋 사용 시점

신규 sigco3111 코딩미션 부트스트랩 (`mkdir → git init -b main → gh repo create → README 작성`)의 README 1차 작성 단계. **이 파일을 그대로 복사해서 사용자가 주는 한국어 프로젝트 부제 + Implementation Advice만 채우면 끝.**

---

## A. 풀사이클 v1.0 다층 README (11종 정규화 헤딩)

`사용자가 OpenCode 작업 후 "vercel로 배포하고 README 갱신해줘"라고 요청한 시점`. 헤딩 11종 + Live Demo URL + Vercel alias 박힌 완성본.

```markdown
# 🔥 {프로젝트 제목}

> {HTML5 Canvas / Matter.js / etc.} 기반 {한 줄 콘셉}
> {English subtitle}

{프로젝트 부제 — 한 단락짜리 핵심 설명: "OO 판에 XX를 배치하면 YY에 따라 ZZ가 시각화되는 N차원 시뮬레이터."}

[🇰🇷 한국어 (기본)](#) · [🇺🇸 English](./README.en.md)

---

## 🔥 라이브 데모

> **👉 [https://{project}.vercel.app/](https://{project}.vercel.app/)** — 브라우저에서 바로 실행 ({핵심 기술 2~3 단어})

| | |
|---|---|
| ![Demo](https://img.shields.io/badge/Live-Demo-7C3AED?style=for-the-badge&logo=vercel&logoColor=white) | [![Repo](https://img.shields.io/badge/GitHub-sigco3111%2F{repo}-181717?style=for-the-badge&logo=github&logoColor=white)](https://github.com/sigco3111/{repo}) |
| ![Status](https://img.shields.io/badge/Status-Live-22C55E?style=flat-square) | ![Stack](https://img.shields.io/badge/Stack-Vanilla_JS-F7DF1E?style=flat-square&logo=javascript&logoColor=black) |
| ![License](https://img.shields.io/badge/License-MIT-F1C40F?style=flat-square) | ![Deps](https://img.shields.io/badge/Dependencies-0-9CA3AF?style=flat-square) |

### 🎮 빠른 사용법
1. 위 데모 링크 클릭 → 브라우저에서 페이지 열기
2. {입력 1} — {설명}
3. {입력 2} — {설명}
4. {키} — {동작}
5. {키} — {동작}
6. {키} — {동작}

---

## 🤖 생성 정보

이 프로젝트의 코드는 아래 모델과 프롬프트를 이용해 **자동으로 생성**되었습니다.

| 항목 | 값 |
|---|---|
| **모델** | MiniMax-M3 |
| **실행 환경** | OpenCode CLI |
| **저장소** | [`sigco3111/{repo}`](https://github.com/sigco3111/{repo}) |
| **라이선스** | MIT |
| **의존성** | {없음 / N개 (CDN: jsdelivr ...)} |

### 📝 사용된 프롬프트 (원문)

\`\`\`
{사용자가 준 한국어 프롬프트 verbatim — Implementation Advice 줄바꿈 포함 그대로}
\`\`\`

---

## ✨ 주요 특징

- {이모지} **{핵심 기능 1}** — {한 줄 설명}
- {이모지} **{핵심 기능 2}** — {한 줄 설명}
- {이모지} **{핵심 기능 3}** — {한 줄 설명}
- {이모지} **{핵심 기능 4}** — {한 줄 설명}
- {이모지} **{핵심 기능 5}** — {한 줄 설명}
- {이모지} **{핵심 기능 6}** — {한 줄 설명}
- {이모지} **{핵심 기능 7}** — {한 줄 설명}
- 💻 **단일 HTML** — 외부 의존성 {N}, 파일 하나만 열면 실행
- 🔒 **온디바이스** — 모든 물리 계산과 렌더링이 브라우저 안에서 처리됨 (서버 0)

---

## 🚀 실행 방법

### 방법 1: 라이브 데모
위 "라이브 데모" 섹션의 URL을 브라우저에서 열기.

### 방법 2: 브라우저로 직접 열기
\`\`\`bash
open index.html        # macOS
xdg-open index.html    # Linux
start index.html       # Windows
\`\`\`

### 방법 3: 로컬 정적 서버
\`\`\`bash
python3 -m http.server 8000
# → http://localhost:8000
\`\`\`

> **참고**: 외부 의존성 {N}개 — `<script src>`, `<link href>` 패턴 사용 명시. CDN은 정적 호스팅에서 자동 허용됨.

---

## 🎮 조작법

{마우스 / 키보드 / 슬라이더 표 3개. 한글로만.}

---

## 🛠️ 기술 스택

| 영역 | 사용 기술 |
|---|---|
| **물리/렌더링** | {Canvas 2D / Matter.js 0.20.0 + poly-decomp 0.3.0 / Three.js} |
| **데이터 구조** | {Float32Array / Typed Arrays} |
| **경계 조건** | {Dirichlet / Neumann mirror} |
| **컬러맵** | {Inferno LUT 256 / Cold-Hot interpolator} |
| **입력** | {마우스 + 키보드 + 슬라이더} |
| **번들링** | {없음 (단일 HTML) / Vite build} |
| **언어** | Vanilla JavaScript (ES6+) |

---

## 📂 프로젝트 구조

\`\`\`
{repo}/
├── index.html      # 단일 HTML ({모든 코드 / 14섹션 구조})
├── README.md       # 한국어 (기본)
├── README.en.md    # English (옵션)
└── LICENSE         # MIT
\`\`\`

---

## 🎨 디자인 결정

브레인스토밍 단계에서 내린 결정 {N}가지:

| 결정 포인트 | 선택 | 이유 |
|---|---|---|
| **{차원 1}** | {선택} | {이유 1줄} |
| **{차원 2}** | {선택} | {이유 1줄} |
| **{차원 3}** | {선택} | {이유 1줄} |
| **{차원 4}** | {선택} | {이유 1줄} |
| **{차원 5}** | {선택} | {이유 1줄} |
| **{차원 6}** | {선택} | {이유 1줄} |
| **{차원 7}** | {선택} | {이유 1줄} |

### 직접 커스터마이즈하고 싶다면

`index.html` 상단에서 다음 상수를 조정하면 {물리/모습}을 바꿀 수 있어요:

\`\`\`js
const DEFAULTS = Object.freeze({
  // OpenCode가 만든 CONFIG를 grep으로 추출
});
\`\`\`

---

## 🧠 동작 원리

\`\`\`
{ASCII art 또는 flow chart}
\`\`\`

핵심은 **{수식 또는 알고리즘 이름}**.

### {원본 Implementation Advice와 다른 결로 갈 때 — 결정 노트}

{사용자가 준 Advice 그대로 안 가고 왜 다른 결로 갔는지 1단락. 향후 동일 미션에서 advisor 함정 회피용.}

---

## 🔬 검증

| 항목 | 값 |
|---|---|
| **로컬 index.html** | {N,NNN} B |
| **Vercel alias 응답** | HTTP 200 · {N,NNN} B (bit-perfect match) |
| **의존성** | {없음 / N개 CDN} |
| **물리 step** | {60Hz} |
| **앵커 깨짐** | 0개 (KR/EN 혼합 헤딩 0) |

---

## 📝 프롬프트 이력

| 차수 | 시점 | 작업 |
|---|---|---|
| 1차 | {YYYY-MM-DD HH:MM} | 코딩미션 scaffolding — README + placeholder index.html |
| 2차 | {YYYY-MM-DD HH:MM} | OpenCode가 본체 구현 ({핵심 알고리즘 1줄}) |
| 3차 | {YYYY-MM-DD HH:MM} | {self-test / 검증} |
| 4차 | {YYYY-MM-DD HH:MM} | Vercel 배포 + README 다층 v1.0 (현재) |

---

## 📜 License

MIT © 2026 sigco3111

---

## 🙏 Acknowledgments

이 프로젝트는 [MiniMax-M3](https://example.com) 모델과 OpenCode CLI 환경에서 생성되었습니다. 프롬프트 엔지니어링과 디자인 결정은 저장소 소유자가 직접 수행했습니다.

- **참고 자료**: {수학/물리/렌더링 출처}
- **컬러맵**: {matplotlib inferno 출처}
- **코딩미션 참조 페이지**: [cokac.com — 코드깎는노인](https://cokac.com/list/announcement/24)
```

---

## B. Bootstrap 1차 README (7종 compressed 헤딩)

`사용자가 "{코딩미션}" 작업 진행 → "저장소 생성하고 OpenCode에서 작업할게, 리드미만 간단히 만들어줘"` 같은 흐름의 1차 README. 헤딩 7종 + Status 체크박스 4개로 압축.

```markdown
# 🔥 {프로젝트 제목}

> {한 줄 부제}

{한 단락짜리 핵심 설명}

[🇰🇷 한국어 (기본)](#) · [🇺🇸 English](./README.en.md)

---

## 🔥 라이브 데모

> 🚧 **배포 후 활성화 예정** — Vercel alias URL이 발급되면 이 줄이 라이브 데모로 교체됩니다.

---

## 🤖 생성 정보

이 프로젝트의 코드는 아래 모델과 프롬프트를 이용해 **자동으로 생성**됩니다.

| 항목 | 값 |
|---|---|
| **모델** | MiniMax-M3 |
| **실행 환경** | OpenCode CLI |
| **저장소** | [`sigco3111/{repo}`](https://github.com/sigco3111/{repo}) |
| **라이선스** | MIT |
| **의존성** | {없음 / N개 (Matter.js + poly-decomp CDN 가능)} |

### 📝 사용된 프롬프트 (원문)

\`\`\`
{사용자가 준 한국어 프롬프트 verbatim}
\`\`\`

---

## 🚧 Status

코딩미션 진행 단계 — 1차 작업은 저장소 bootstrap + OpenCode에게 작업 자리 인계까지.

- [x] 저장소 생성 + README 1차 커밋 (현재 단계)
- [ ] OpenCode가 `index.html` 본체 구현 ({핵심 1줄 요약})
- [ ] Vercel 배포 + 라이브 데모 URL 발급
- [ ] README 다층화 v1.0 (Live Demo URL + Design Choices + Config 표)

---

## 🚀 실행 방법

\`\`\`bash
# 옵션 A: 브라우저에서 직접 열기
open index.html

# 옵션 B: 로컬 정적 서버 (권장)
python3 -m http.server 8000
# → http://localhost:8000 접속

# 옵션 C: Vercel 라이브 데모 (배포 후 활성화)
# 위 "라이브 데모" 섹션의 URL을 브라우저에서 열기
\`\`\`

> **참고**: 모든 의존관계가 `index.html` 하나에 인라인됩니다. {CDN 의존성 패턴 언급 / "단일 HTML 인라인" 강조}.

---

## 🧠 구현 힌트

Implementation Advice가 권장하는 핵심 설계:

- {핵심 설계 1 — 데이터 구조 / 알고리즘 / 라이브러리}
- {핵심 설계 2 — 성능 / 안정성 / 인터랙션}
- {핵심 설계 3 — 시각화 / 디버깅}

{Implementation Advice가 원본 의도와 다른 결로 갈 때 결정 노트 1단락 — 분광/분산 "R/G/B → 7-band" 확장 등}

---

## 🤖 생성 워크플로

이 저장소는 동일한 sigco3111 코딩미션 패턴으로 작업됩니다:

1. **1차 (현재)** — README + placeholder `index.html` + `.gitignore` 생성, OpenCode 인계
2. **OpenCode가 본체 구현** — `index.html`에 {핵심} 모두 인라인
3. **Vercel 배포 + README 다층화** — 이전 미션 다층 README 형식으로 v1.0 완성

다른 미션 사례: [{repo-1}](https://github.com/sigco3111/{repo-1}) · [{repo-2}](https://github.com/sigco3111/{repo-2}) · [{repo-3}](https://github.com/sigco3111/{repo-3})

---

## 📜 License

MIT © 2026 sigco3111

---

## 🙏 Acknowledgments

이 프로젝트는 [MiniMax-M3](https://example.com) 모델과 OpenCode CLI 환경에서 생성됩니다. 프롬프트 엔지니어링과 디자인 결정은 저장소 소유자가 직접 수행합니다.

- **코딩미션 참조 페이지**: [cokac.com — 코드깎는노인](https://cokac.com/list/announcement/24)
```

---

## C. 검증 oneliner (두 어서션 동시 통과 확인)

```bash
# 어서션 1 — 스크립트 (대부분의 케이스)
bash ~/.hermes/skills/ad-hoc-verifier/scripts/check-kr-en-mixed-headings.sh README.md

# 어서션 2 — 정밀 (괄호 안 영문 token까지)
python3 -c "
import re
t = open('README.md').read()
mixed = re.findall(r'^## .*\\([^\\n]*[A-Z][^\\n]*\\)\\s*\$', t, flags=re.MULTILINE)
print('mixed:', len(mixed), '/ 0')
"

# 둘 다 0이어야 헤딩 정규화 통과 — patch 0회 보장
```

---

## D. 부록 A — 영문 혼합 괄호 헤딩 패턴 회피 리스트

**(영문 혼합 괄호 헤딩 = 절대 ❌) 패턴들**. 이 템플릿의 어느 단계에서든 절대 안 쓰는 단어:

| ❌ 잘못 | ✅ 옳음 |
|---|---|
| `## 🧠 구현 힌트 (OpenCode 참고용)` | `## 🧠 구현 힌트` |
| `## 🚀 실행 방법 (Quick Start)` | `## 🚀 실행 방법` |
| `## 🎮 조작법 (Controls)` | `## 🎮 조작법` |
| `## 🛠️ 기술 스택 (Tech Stack)` | `## 🛠️ 기술 스택` |
| `## 📝 프롬프트 이력 (Prompt Log)` | `## 📝 프롬프트 이력` |
| `## 🔬 검증 (Verification)` | `## 🔬 검증` |
| `## ✨ 주요 특징 (NEW)` | `## ✨ 주요 특징` |
| `## 📂 프로젝트 구조 (v0)` | `## 📂 프로젝트 구조` |

**한글 괄호(`(예정)`, `(구현 예정)`)는 anchor 정상 — 영문 token이 섞여야만 한/영 혼합 헤딩으로 인식.** 패턴 확인:
- `[^\\n]*[A-Z][^\\n]*\\)` — 괄호 안에 영문 대문자 token이 있으면 anchor 깨짐 위험

---

## E. 적용 사례 (2026-07-09 9번째 풀사이클까지 검증)

이 템플릿을 베껴서 만든 README가 깨짐 0 + patch 0회로 통과한 미션:

| # | 미션 | 단계 | 결과 |
|---|---|---|---|
| 1 | offroad-suspension | v1.0 (A 본문 사용) | 11종 정규화, patch 0회 |
| 2 | optics-prism-lab | v1.0 (A 본문 사용) | 11종 정규화, patch 0회 |
| 3 | heat-conduction-heatmap | v1.0 (A 본문 사용) | 11종 정규화, patch 0회 |
| 4 | genetic-walking | bootstrap (B 본문 사용) | 7종 compressed + 결정 노트 + (OpenCode 참고용) 1 patch — §7.5.3.1.1 학습 트리거 |
| 5 | **ant-colony-optimization** | bootstrap (B 본문 사용) | 7종 compressed, **patch 0회** — 본 절 패턴 정식 검증 |

다음 미션(10번째)부터는 본 템플릿을 베끼면 두 어서션 0 + patch 0회 default.
