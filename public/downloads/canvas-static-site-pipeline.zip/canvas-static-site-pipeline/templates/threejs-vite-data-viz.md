# Three.js + Vite + 임베드 데이터 시각화 — 검증된 스타터

> Artemis II Mission Trail(2026-06-11) 프로젝트에서 검증된
> Vite + Three.js 단일 페이지 데이터 시각화 보일러플레이트.
> NASA JPL Horizons ephemeris, 주가, 날씨, 지진 등 정적 시계열 3D 시각화에 재사용.

## 디렉토리 구조

```
project-name/
├── app.js              # Three.js main scene + animation
├── index.html          # HUD layout
├── styles.css          # Dark space UI (AI keynote 스타일)
├── data.json           # 정적 임베드 데이터 (가공 완료된 형태)
├── package.json        # Vite + Three.js dependencies
├── vite.config.js
├── vercel.json
├── .gitignore
├── README.md
└── HANDOFF.md          # 다른 PC 작업용 가이드
```

## package.json

```json
{
  "name": "project-name",
  "private": true,
  "version": "0.1.0",
  "type": "module",
  "description": "...",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview"
  },
  "dependencies": {
    "three": "^0.171.0"
  },
  "devDependencies": {
    "vite": "^5.4.10"
  }
}
```

## vite.config.js

```js
import { defineConfig } from "vite";

export default defineConfig({
  root: ".",
  publicDir: "public",
  build: {
    outDir: "dist",
    emptyOutDir: true,
    target: "es2020",
  },
  server: {
    host: "0.0.0.0",
    port: 5173,
  },
});
```

## vercel.json (Vite 사용 시 — 일반 정적 사이트 템플릿과 다름!)

```json
{
  "buildCommand": "npm run build",
  "outputDirectory": "dist",
  "installCommand": "npm install",
  "framework": "vite",
  "rewrites": [
    { "source": "/(.*)", "destination": "/index.html" }
  ]
}
```

**함정:** `canvas-static-site-pipeline` 기본 템플릿은 빌드 명령 없는 plain HTML용.
Vite 프로젝트는 위처럼 buildCommand + outputDirectory를 명시해야 함.

## app.js (핵심 구조)

```js
import * as THREE from "three";
import trajectory from "./data.json";

const SCALE = 1e-6; // km → scene unit
const COLORS = { /* ... */ };

// 1. Renderer + Scene + Camera
const canvas = document.getElementById("scene");
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
const scene = new THREE.Scene();
scene.fog = new THREE.FogExp2(0x05060a, 0.0014);
const camera = new THREE.PerspectiveCamera(45, w/h, 0.1, 10000);

// 2. Star field (AI keynote 데모의 "우주적" 인상)
function makeStars(count = 4000, radius = 2000) { /* ... */ }
scene.add(makeStars());

// 3. Body meshes
function makeBody(color, radius) { /* MeshStandardMaterial */ }
scene.add(earth, moon, sun, orion);

// 4. Pre-compute scaled positions
const positions = { orion: [], moon: [], sun: [] };
for (const key of Object.keys(positions)) {
  for (const point of trajectory.bodies[key]) {
    const [x, y, z] = point.pos;
    positions[key].push(new THREE.Vector3(x * SCALE, y * SCALE, z * SCALE));
  }
}

// 5. Trail lines
function makeTrail(color) { /* Line + BufferGeometry */ }
const orionTrail = makeTrail(0xff8a4c);
scene.add(orionTrail);

// 6. Time controls
let frame = 0, playing = false, speed = 1;
timeline.addEventListener("input", () => { frame = +timeline.value; updateScene(); });

// 7. Telemetry / HUD
function updateTelemetry() { /* DOM updates */ }

// 8. Per-frame update
function updateScene() {
  moon.position.copy(positions.moon[frame]);
  sun.position.copy(positions.sun[frame]);
  orion.position.copy(positions.orion[frame]);
  orionTrail.geometry.setDrawRange(0, frame + 1); // trail grows over time
  updateTelemetry();
}

// 9. Animation loop
function loop(now) {
  const dt = (now - lastT) / 1000; lastT = now;
  if (playing) { frame += speed * dt * 4; /* ... */ }
  updateScene();
  renderer.render(scene, camera);
  requestAnimationFrame(loop);
}
```

## index.html (HUD 패턴)

```html
<canvas id="scene"></canvas>
<header class="hud-top"><!-- 브랜드/타이틀 --></header>
<aside class="hud-left"><!-- 미션 정보 카드들 --></aside>
<aside class="hud-right"><!-- 라이브 텔레메트리 --></aside>
<footer class="hud-bottom"><!-- 타임라인 슬라이더 + Play/Pause --></footer>
<script type="module" src="/app.js"></script>
```

CSS는 `styles.css`에 `--bg: #05060a`, `--accent: #7cc4ff` 등의 토큰 + `.card`, `.hud-*`,
`backdrop-filter: blur(8px)` 패턴 (AI keynote 데모 미학).

## 배포 워크플로

```bash
# 1. GitHub repo 생성
gh repo create <name> --public --description "..."  # push 없이
cd ~/Desktop/project/work/ai/<name> && git init -b main
git remote add origin https://github.com/sigco3111/<name>.git

# 2. 로컬 빌드 검증
npm install
npm run build        # → dist/
# ⚠️ JSON import가 inline 됐는지 검증:
grep -c "<data-unique-keyword>" dist/assets/*.js

# 3. Push + Vercel 배포
git add -A && git commit -m "..."
git push -u origin main
export VERCEL_TOKEN=$(cat ~/.hermes/secrets/vercel_token.txt)
vercel link --yes --token $VERCEL_TOKEN
vercel deploy --prod --yes --token $VERCEL_TOKEN
```

## 검증 단계 (이 세션에서 발견한 핵심 학습)

### JSON import가 prod build에 inline 됐는지 확인

Vite는 큰 JSON을 inline하지만 **minify로 모든 키가 한 글자로 단축됨** → grep이 안 됨.
**데이터 패턴** (날짜, 숫자)으로 검색:

```bash
# ❌ 키 이름으로 검색하면 0 (minify됨)
grep -c "mission" dist/assets/*.js    # 0
grep -c "JDTDB" dist/assets/*.js     # 0

# ✅ 데이터 패턴으로 검색
grep -c "2026-04-" dist/assets/*.js  # 644+ (inline 됐다는 증거)
grep -c "214" dist/assets/*.js       # 45+ (point_count 등)
```

만약 0이면 → JSON이 URL로 external 됐다는 뜻 → fetch로 변경 필요.

### Vercel prod에서 데이터 로드 확인

```bash
curl -sI https://<project>.vercel.app/ | head -3   # 200 OK
curl -s https://<project>.vercel.app/assets/index-*.js | grep -c "<date-pattern>"
```

## 다음 PC 핸드오프 (HANDOFF.md 패턴)

```markdown
# Handoff — 다른 PC에서 이어서 작업하기

## 🌐 라이브 URL
- **Vercel**: https://<project>.vercel.app
- **GitHub**: https://github.com/sigco3111/<project>

## 시작
git clone https://github.com/sigco3111/<project>.git
cd <project> && npm install && npm run dev

## 디렉토리
- app.js: Three.js scene
- data.json: 정적 데이터
- styles.css: HUD 스타일

## 다음 단계 (우선순위)
1. OrbitControls (마우스 인터랙션)
2. ...
```
