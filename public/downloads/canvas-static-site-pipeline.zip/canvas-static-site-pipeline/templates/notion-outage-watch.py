#!/usr/bin/env python3
"""
{service_name} 장애 감시 워치독 스크립트 (cron no_agent 모드용)

{cron_name} 잡에서 30분 간격으로 실행됨.
정상 복구 감지 시에만 stdout에 메시지 출력 → 텔레그램 자동 발송.
그 외 (인증키 없음, 네트워크 오류, HTTP 에러) 는 silent.

사용법:
1. 이 파일을 ~/.hermes/scripts/{service}_outage_watch.py 로 복사
2. SERVICE_NAME, SERVICE_API_KEY_ENV, HEALTH_URL, NOTION_VERSION 4개만 수정
3. cron 잡 등록:
   cronjob(
       action="create",
       name="{service}-outage-watch-3h",
       schedule="30m",
       repeat=6,
       script="{service}_outage_watch.py",  # 절대경로 X, 파일명만
       no_agent=True,
   )

검증:
   source ~/.hermes/.env
   python3 ~/.hermes/scripts/{service}_outage_watch.py
   # 정상 → "✅ ... 복구 감지" 출력
   # 장애 → 아무것도 출력 안 함
"""

import os
import sys
import json
from datetime import datetime, timezone, timedelta
from urllib import request as urlrequest
from urllib.error import URLError, HTTPError

# ─── 설정 (여기만 수정) ─────────────────────────────────────────
SERVICE_NAME = "Notion"
SERVICE_API_KEY_ENV = "NOTION_API_KEY"
HEALTH_URL = "https://api.notion.com/v1/users/me"
NOTION_VERSION = "2025-09-03"  # Notion만 필요, 다른 서비스면 None
TIMEOUT_SEC = 10
# ────────────────────────────────────────────────────────────────

KST = timezone(timedelta(hours=9))


def kst_now():
    return datetime.now(KST).strftime("%Y-%m-%d %H:%M:%S KST")


def check_service():
    """
    Returns: (is_healthy, detail)
      - (True, "...")  → 메시지 출력 (= 텔레그램 알림)
      - (False, "...") → silent
    """
    api_key = os.environ.get(SERVICE_API_KEY_ENV, "").strip()
    if not api_key:
        return (False, f"{SERVICE_API_KEY_ENV} 미설정")

    headers = {"Authorization": f"Bearer {api_key}"}
    if NOTION_VERSION:
        headers["Notion-Version"] = NOTION_VERSION

    req = urlrequest.Request(HEALTH_URL, headers=headers)
    try:
        with urlrequest.urlopen(req, timeout=TIMEOUT_SEC) as resp:
            if resp.status == 200:
                try:
                    body = json.loads(resp.read().decode("utf-8", errors="replace"))
                    detail = f"정상 (status {resp.status}, keys: {list(body.keys())[:3]})"
                except Exception:
                    detail = f"정상 (status {resp.status})"
                return (True, detail)
            return (False, f"HTTP {resp.status}")
    except HTTPError as e:
        return (False, f"HTTP {e.code} {e.reason}")
    except (URLError, TimeoutError, OSError) as e:
        return (False, f"네트워크 오류: {type(e).__name__}")


def main():
    is_healthy, detail = check_service()
    if is_healthy:
        print(f"✅ {SERVICE_NAME} 복구 감지 — {kst_now()}")
        print(f"   상세: {detail}")
        print()
        print("관련 자동화 작업이 다시 정상 동작할 거예요.")
    return 0


if __name__ == "__main__":
    sys.exit(main())