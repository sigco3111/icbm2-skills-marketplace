---
name: canvas-static-site-pipeline
description: 플랫폼 SDK 제약 하의 미니앱/마이크로 프로젝트 End-to-End 파이프라인 — 컨셉 → GitHub 저장소 생성 → 구현 → 배포. 토스 앱인토스·스팀 워크샵·iOS/Android 등 외부 플랫폼 SDK 의존 미니앱 + 단일 페이지 정적 웹 프로젝트(Canvas API, D3.js, Three.js, p5.js 시각화) + **데스크탑 인터랙티브 미니앱 (pygame + LLM/TTS 결합 키위/스택챈/마스코트 동반자 등) — macOS/Windows/Linux에서 GUI 윈도우 + LLM 대화 + 음성 합성으로 동작하는 단일 사용자 데스크탑 동반자 시뮬레이터** 모두 포함. **brainstorming 전 플랫폼 SDK 가능 범위 검증 + 서버 0/API 키 0 원칙**이 강하게 작용하는 클래스.
category: devops
tags:
  - static-site
  - canvas
  - vercel
  - github
  - simulation
  - visualization
  - educational
  - platform-sdk
  - mini-app
  - toss-apps-in-toss
  - serverless
  - pygame
  - desktop
  - voice-tts
  - llm-companion
when to use: >
  사용자가 새로운 웹 앱/시뮬레이터/시각화 프로젝트 요청 시.
  "저장소 생성하고 Vercel로 배포해줘" 계열의 요청.
  Canvas API, 순수 JavaScript 기반 인터랙티브 앱 제작.
  **외부 플랫폼 SDK (앱인토스 Granite, 스팀 워크샵, iOS App Clip, Android Instant App 등) 기반 미니앱/챌린지 출품작**.
  **데스크탑 인터랙티브 미니앱 (pygame 얼굴 윈도우 + LLM 대화 + TTS 음성 출력 키위/스택챈/마스코트 동반자 시뮬레이터)**.
  단, **백엔드/DB/API 키 발급이 강하게 회피되는 상황**에서 아이디어 → 검증 → 구현으로 이어질 때.
---

# canvas-static-site-pipeline (확장: 플랫폼 SDK 미니앱 + 정적 웹 + 데스크탑 미니앱)

이 스킬은 처음에 "단일 페이지 정적 웹 프로젝트"용으로 시작했지만, 2026-06-18 토스 앱인토스 바이브코딩 챌린지 세션에서 **외부 플랫폼 SDK 제약 하의 미니앱** 클래스도 다루게 됐다. 2026-06-23 kiwi 시뮬레이터 세션에서 **데스크탑 pygame + LLM/TTS 결합 미니앱** 클래스도 추가됐다. 2026-07-10 sigco3111/toss-trader 세션에서 **Next.js 풀스택 (Vercel Edge Function + OAuth relay + 안전 가드 + Telegram confirm + TDD)** 클래스도 추가됐다. 챌린지 마감 + 서버 0 + API 키 0 + 다른 PC 핸드오프 + 크래시 3종(SDL 타이머/mixer/NSWindow) 같은 패턴이 동일하게 적용된다.

## variants

이 스킬은 네 가지 변형을 가진다. brainstorming 0단계에서 어느 변형인지 먼저 확정:

1. **웹 변형 (정적 사이트/Canvas/Three.js)** — Vercel + GitHub Pages 배포. `templates/threejs-vite-data-viz.md`.
2. **플랫폼 SDK 미니앱 변형 (앱인토스, 스팀, iOS App Clip 등)** — Granite SDK + TDS 디자인 + 마켓플레이스 업로드.
3. **데스크탑 pygame 미니앱 변형 (2026-06-23 추가)** — pygame + LLM + TTS + 얼굴 윈도우. `templates/pygame-desktop-miniapp.md` + `references/pygame-desktop-simulator.md`.
4. **Next.js 풀스택 변형 (2026-07-10 추가, sigco3111/toss-trader 실측)** — Next.js 16 App Router + React 19 + TypeScript + Tailwind v4 + Vercel Edge Function. 외부 OAuth API relay + 안전 가드 + 동적 라우트 + TDD vitest. **OAuth 토큰 캐시 + paper-trading 기본 + Telegram inline button confirm + 6대 안전 가드** 4대 핵심 패턴. **`references/nextjs-fullstack-pipeline.md` + `templates/nextjs-16-app-router-scaffold.md` 참조**.

steps는 변형 1(웹)을 기본으로 서술하지만, 변형 2/3/4는 각자의 추가 체크리스트가 있다. 변형 4는 본 스킬에 새로 추가된 클래스로, **OAuth API relay + 안전 가드 + Telegram confirm + TDD** 4대 핵심 패턴이 변형 1과 다른 분기점.

## steps

### 0. 컨셉/스코프 정리 (구현 전 필수)

**반드시 구현 전에 한다.** 사용자가 처음에 LLM/agent/AI benchmark를 언급해도 실제 deliverable이 **(a) 정적 시각화, (b) LLM 평가/벤치마크, (c) 외부 플랫폼 SDK 미니앱, (d) 데스크탑 미니앱, (e) 그 외** 중 어디에 속하는지 먼저 분류한다 — 다른 워크플로로 빠지는 함정. (2026-06-11 세션: "Artemis Mission Control Challenge"가 LLM 에이전트 평가로 보였지만 실제 목표는 GPT-5.5 키노트 스타일 정적 궤적 시각화였음. 2026-06-23: "stackchan 시뮬레이터"가 데스크탑 변형이었지만 처음에 App Store 변형으로 잘못 추정해서 시간 낭비.)

**0.0 변형 확정 (2026-06-23 학습, 2026-07-10 변형 4 추가)**
- "시뮬레이터 만들어줘" 같은 모호한 요청은 1차로 **웹 변형**(브라우저 내 시뮬레이션)으로 가정
- "내 PC에서 실행", "얼굴이 떠야 해", "macOS에서 동작" 등 명시적이면 **데스크탑 변형** (pygame)
- "iOS/Android 앱으로", "M5Stack 디바이스" 등은 **플랫폼 SDK 변형**
- **"OAuth API 호출이 필요해", "매수/매도 버튼", "토큰 인증", "Telegram 알림"** 등 명시적이면 **Next.js 풀스택 변형** (2026-07-10 sigco3111/toss-trader 실측) — Vercel Edge Function + 외부 OAuth + 안전 가드 + TDD vitest

**0.0.1 데스크탑 변형 사전 결정 포인트 (2026-06-23 학습)**

데스크탑 pygame 미니앱은 다음 결정이 brainstorming 직후에 확정돼야 함:

1. **타겟 플랫폼** — Intel Mac / Apple Silicon Mac / Windows / Linux. 각 플랫폼마다 pygame + TTS 백엔드 다름. Intel Mac은 App Store (Apple Silicon 전용) 불가, pygame 직접 설치 필요.
2. **LLM 호출 방식** — API 키 필요 시 사용자 환경에서 export. Hermes 환경에선 `~/.hermes/secrets/{provider}.env`에 저장돼 있고 `source`로 로드.
3. **TTS 음성 선택** — macOS는 NSSpeechSynthesizer (Yuna 한국어). Windows는 SAPI. Linux는 espeak/festival. **pyttsx3가 가장 크로스플랫폼**.
4. **얼굴 표현** — pygame primitive 원/사각형 (저퀄, 30분) vs PNG 일러스트 (고퀄, 1~2시간). 사용자가 "stackchan처럼", "귀여운 외형" 거론하면 PNG 일러스트 또는 상세 pygame primitive.
5. **창 종류** — 단일 윈도우(얼굴만) vs 메인 윈도우 + 텍스트 입력(별도 터미널) vs 풀 GUI. macOS NSWindow 제약 때문에 pygame은 **반드시 메인 스레드**에서만 호출.

**0.1 플랫폼 가능 범위 사전 검증 (조건부 필수)**

대상 플랫폼(앱인토스, 스팀, iOS 등)이 정해져 있고 그 플랫폼의 SDK/API가 필요한 아이디어면 **brainstorming 전에** "이 플랫폼 SDK가 실제로 그 데이터를 노출하는가"를 검증한다. 아이디어가 참신해도 SDK가 닫혀있으면 구현 불가.

검증 절차 (2026-06-18 앱인토스 챌린지 세션에서 확립):
1. **공식 SDK 패키지 확인** — NPM/Pub.dev/CocoaPods 등에서 플랫폼 SDK 검색 (예: `registry.npmjs.org/-/v1/search?text=@apps-in-toss`)
2. **패키지 tarball 직접 추출** — `curl -sL registry.npmjs.org/{pkg}/-/{pkg}-{ver}.tgz | tar -xz` → `src/` 트리에서 함수명/타입 추출
3. **각 함수의 시그니처 + 반환 타입 확인** — 특히 `Promise<X>`의 X가 string 한 개인지 객체/배열인지가 핵심
4. **공식 예제 repo** (예: `toss/apps-in-toss-examples`)에서 examples 디렉토리 목록 추출 — 어떤 use case가 공식 지원되는지 100% 판단 가능
5. **부재한 기능 보고** — 아이디어가 그 기능에 의존하면 **솔직하게 "기술적으로 불가능" 보고**. "노력하면 됩니다" 거짓말 금지.

참고: 앱인토스 Granite SDK 2.9.1 (2026-06 기준) 가능 범위는 `references/platform-sdk-capability-check.md` 참조. 외부 GitHub 저장소 (Three.js 시각화/포트폴리오 류) 분석·포크 프레임은 `references/github-3d-visualization-fork-analysis.md` 참조. 핵심 요약:
- ✅ `getConsentedUserData` → 이름/성별/생년/전화/주소/이메일/USER_CONSUMPTION_HISTORY(string 1개)
- ✅ `storage` (단순 KV), `appLogin`, `fetchContacts`, `getCurrentLocation`, `getClipboardText`, `share` 등 디바이스 권한 SDK
- ❌ 결제/카드/송금/자산/친구 목록 내역 조회 API **전혀 없음**

확정 후 **brainstorming-first** 패턴으로 3~4개 결정 포인트를 A/B/C 옵션으로 제시하고 **추천 1개를 굵게** 표시한다.

**흔한 앱 함정 회피** (2026-06-18 학습): brainstorming의 1차 아이디어가 "정산/N빵", "날씨 코디", "약 알림", "계산기" 같은 일반적 카테고리면 **사용자가 "전부 있는 앱인데..." 거절할 가능성 ↑**. brainstorming 직전에 항상 다음 체크:
- 마켓플레이스/스토어에 이미 비슷한 앱 다수? → 컨셉 자체를 뒤집어야
- 누구나 생각할 수 있는 자명한 카테고리? → 사용자 차별화 어필 불가
- 차별화 포인트를 1차 옵션이 아니라 2~3개 합쳐서 만들어야

**0.2 데이터 소스 — 무키(API Key 불필요) 우선 검토 (2026-06-18 학습)**

챌린지/사이드 프로젝트에서 사용자가 "유지비 0"을 명시하면 **외부 공개 API도 키 발급 없이 쓸 수 있는 것만 골라야** 한다. 키 발급 + 만료 관리가 필요한 API는 6개월 후 앱이 망가질 수 있음.

검증 절차: `references/keyless-public-apis.md` 참조. 검증된 무키 API 예시:
- Open-Meteo (날씨/미세먼지/지오코딩) — CORS OK, 영구 무료
- 서울 열린데이터 sample 키 (따릉이) — quota 작지만 작동
- Nager Date (공휴일) — 100+ 국가, 무제한
- Nominatim Reverse (좌표→주소) — 1 req/sec rate limit
- Wikipedia REST API
- → 풀 카탈로그: <https://github.com/public-apis/public-apis> (Auth=No 인 것 우선)

**판단 기준**: 챌린지/사이드 프로젝트는 "발표일 작동 + 마감 후 6개월 안 깨짐"만 충족하면 OK. 키 만료 관리는 사용자가 원하지 않는 부채.

**0.3 결정 포인트 5가지** (상황에 따라 4개로 축약)

- **변형 확정** (웹 vs 플랫폼 SDK vs 데스크탑 pygame) — 0.0 참조.
- **데이터 소스** (live API vs precomputed JSON vs runtime fetch — 아래 섹션). **무키 가능 여부**가 우선 필터.
- **렌더링 라이브러리** (Three.js vs regl vs r3f vs raw WebGL vs pygame primitive vs PNG 일러스트). **플랫폼 SDK 미니앱**이면 Granite(React Native) + TDS 디자인 시스템 강제. **데스크탑 변형**이면 pygame primitive(빠른 프로토타입) vs PNG(고퀄).
- **비주얼 컨셉 범위** (2D / 3D / 토글 / 텔레메트리 오버레이 / 표정 시스템)
- **작업 흐름 분할** (이 PC에서 끝 / 다른 PC 위주 / 협업) — 챌린지 마감 압박 시 "다른 PC로 핸드오프" 빈번
- **유지비 구조** (정적 호스팅 vs 서버 필요 vs 무료 티어 vs 사용자 PC 로컬) — 데스크탑 변형은 사용자 PC 로컬이라 유지비 0 자동.

### 1. 저장소 생성

> **cold-start 워크플로 (2026-07-08 heavy-chain-ik 실측)** — `gh repo create --source=.` + Pages REST API + 첫 빌드 대기는 별도 reference 분리. **`references/coding-mission-bootstrap-cold-start.md` 참조** (함정 4종: empty repo + SSH host key + `gh repo edit` Pages 옵션 부재 + 첫 빌드 30~60초 지연). 코딩미션 첫 세션에선 항상 그 reference부터.

```bash
gh repo create {project-name} --public --clone
mkdir -p ~/Desktop/project/work/ai/{project-name}
```

**플랫폼 SDK 미니앱 변형 (2026-06-18 dongne-today)**: 챌린지 마감 압박 + 사용자가 다른 PC에서 작업 예정이라고 하면, **로컬 디렉토리만 생성 + 첫 commit만** 하고 사용자에게 GitHub push는 위임. README + AGENTS.md + docs/ 만 채운 상태로 핸드오프.

```bash
mkdir -p ~/workspace/{project-name}/docs
cd ~/workspace/{project-name}
git init -b main
# README/AGENTS.md/docs/LICENSE/.gitignore/package.json/granite.config.ts 작성
git add . && git commit -m "docs: initial docs-only scaffold for {project-name}"
# 사용자에게 push 위임: gh repo create sigco3111/{project-name} --public --source=. --push
```

상세 핸드오프 패턴은 step 7 참조.

**데스크탑 pygame 변형 (2026-06-23 kiwi)**: GitHub push는 **선택**. 개인 로컬 프로젝트면 push 안 해도 됨. conda 환경 분리 + `run.sh` 래퍼 + README로 종료. `git init` + 로컬 commit만. push 원하면 `gh repo create {name} --public --source=. --push`.

### 2. 프로젝트 구현

**정적 웹 변형**:
```
/index.html    - 메인 HTML
/styles.css    - 스타일시트
/app.js        - Canvas/애니메이션 로직
/vercel.json   - Vercel 설정 (정적 사이트)
/README.md     - 한국어 프로젝트 설명
```

**플랫폼 SDK 미니앱 변형 (토스 앱인토스 등)**:
```
/README.md                  # 한/영 병기 다층 옵션
/AGENTS.md                  # 다른 PC 에이전트용 가이드 (필독)
/package.json               # 의존성 + scripts
/tsconfig.json              # TypeScript 설정
/granite.config.ts          # (앱인토스) 권한 + services 등록
/app.json                   # 앱 메타 + 챌린지 정보
/LICENSE                    # MIT + 3rd-party API attribution
/.gitignore                 # Granite + Node + Yarn
/docs/
  ├── ARCHITECTURE.md       # 앱 구조 + 데이터 흐름 + 컴포넌트 트리
  ├── DATA_SOURCES.md       # 6종 API 검증 결과 (응답 예시 포함)
  ├── DESIGN_SYSTEM.md      # 캐릭터 + 디자인 토큰
  ├── SETUP.md              # 플랫폼 SDK 환경 세팅 가이드
  ├── CHECKLIST.md          # 마감 일정표 + 위험 요소
  └── AI_VIBE_CODING.md     # AI 도구 (AX MCP 등) 워크플로
/src/                       # 구현 시작 시 채움 (assets/, components/, screens/, services/, utils/)
```

**데스크탑 pygame 미니앱 변형 (2026-06-23 kiwi)**:
```
/llm.py          # LLM API 호출 + 감정 태그 파싱
/tts.py          # pyttsx3 wrapper + 한국어 음성 우선 + 폴백
/face.py         # pygame 얼굴 윈도우 (메인 스레드 init/tick/shutdown)
/kiwi.py         # 메인 루프 + LLM/TTS 워커 스레드
/run.sh          # conda 환경 자동 활성화 + 키 로드 + 실행 래퍼
/README.md       # 한국어 사용 가이드
```

`vercel.json` 템플릿 (정적 웹):
```json
{
  "buildCommand": null,
  "outputDirectory": ".",
  "installCommand": null,
  "framework": null,
  "rewrites": [{ "source": "/(.*)", "destination": "/index.html" }]
}
```

### 3. GitHub 푸시
```bash
cd ~/Desktop/project/work/ai/{project-name}
git init
git remote add origin https://github.com/sigco3111/{project-name}.git
git add -A
git commit -m "{이모지} {프로젝트명} - {한 줄 설명}"
git branch -M main
git push -u origin main
```

### 4. Vercel 배포 (정적 웹만)

```bash
vercel deploy --prod --yes --token $(cat ~/.hermes/secrets/vercel_token.txt)
```

**플래그 순서**: `--prod --yes --token` (또는 `--yes --prod --token`). `--prod` 없으면 preview URL만 발급됨. `--yes`는 interactive prompt 자동 수락. `--token`은 인증 우회 (login 세션 없이).

**alias URL 패턴 (★★★ 2026-07-08 ripple-tank 실측 확정)**:
```
Vercel CLI 54.18.2 (Node.js 22.23.1)

  Directory       ~/work/ripple-tank
...
✓ Created         sigco3111s-projects/ripple-tank
> Connecting GitHub repository: https://github.com/sigco3111/ripple-tank
> Connected
...
  Production      https://ripple-tank-35wnug7sy-sigco3111s-projects.vercel.app
https://ripple-tank-35wnug7sy-sigco3111s-projects.vercel.appBuilding…
Building…
  Production      https://ripple-tank-35wnug7sy-sigco3111s-projects.vercel.app
Completing…
▲ Aliased         https://ripple-tank.vercel.app      ← ★★★ 이 줄이 라이브 데모 URL

✓ Ready in 8s
```

**`▲ Aliased` 라인이 곧 라이브 데모 URL**. 출력에서 grep으로 추출:
```bash
ALIAS=$(vercel deploy --prod --yes --token $TOKEN 2>&1 | grep -E "▲ Aliased" | awk '{print $NF}')
# 또는 post-hoc 검증
vercel alias ls --token $TOKEN 2>&1 | grep -E "^[│|].*vercel.app" | awk '{print $2}'
```

**alias suffix 점유 상태 (메모리 §Vercel alias suffix 맵 참조)**:
- `ripple-tank.vercel.app` (raw, 미점유 슬롯)
- `neon-fluid-one.vercel.app` (neon-fluid)
- `boids-flocking-two.vercel.app` (boids-flocking)
- `bridge-constructor-three.vercel.app` (bridge-constructor)
- 미점유 → raw 시도, 점유 → `-one/-two/-three/...` suffix (boids-flocking 같은 -two 슬롯 규칙)

**sigco3111s-projects team-scope URL은 anon에서 SSO 302** — 메모리 §Vercel 함정 일치. 검증은 alias URL만 (`<project-name>.vercel.app`). team-scope prod URL은 검증하지 않음.

**플랫폼 SDK 미니앱**: 토스 앱인토스 콘솔(`apps-in-toss.toss.im`)에서 ZIP 업로드. Vercel 미사용.

**데스크탑 pygame 미니앱**: 배포 없음. 사용자 PC 로컬 실행. `bash run.sh`로 실행.

### 5. 결과 보고
- GitHub 저장소 URL
- 라이브 Vercel URL (또는 플랫폼 마켓플레이스 URL)
- 구현된 기능 목록
- **데스크탑 변형**: 로컬 실행 명령어 + PNG 미리보기 경로

### 5.5 Self-check (보고 전, "실망" 방지)

**사용자 보고 전 한 번 더 점검.** 결과물이 "발표 데모"급이려면:

- [ ] **브라우저에서 직접 확인** — Vercel URL 열어서 (a) 첫 프레임에 모든 body 보임, (b) trail이 끊김 없이 부드럽게 그려짐, (c) timeline/play 정상 작동, (d) 콘솔 에러 없음. curl HEAD 200 + grep 데이터 본문만으로는 부족.
- [ ] **bit-perfect 사이즈 검증 (★★ 2026-07-08 ripple-tank + voronoi-glass-fracture 2회 실측 권장)** — `curl -sS -o /dev/null -w "%{size_download}B"` 출력과 로컬 `index.html` 바이트 수(`wc -c < index.html`)가 **정확히 일치**해야 배포가 손실 없이 반영된 것. ripple-tank 실측: 로컬 52,614B ≡ alias 52,614B (PASS). voronoi-glass-fracture 실측: 로컬 130,094B ≡ alias 130,094B (PASS). 다르면 Vercel 캐시/edge 이슈 또는 push 누락 의심. 단일 HTML 미션은 이게 4축 검증(ad-hoc-verifier rotation-dimension-catalog)보다 가볍고 효과적.
- [ ] **시각적 임팩트** — 단순 Three.js sphere + line은 "키노트 데모"가 아님. 발광(emissive), halo, particle star field, 단일 액센트 색, 텔레메트리 HUD 같은 요소가 최소 1~2개.
- [ ] **인터랙션** — 자동 orbit만으로는 부족. OrbitControls 또는 hover/click 인터랙션 1개 이상.
- [ ] **README의 "구현된 기능"** — phase table / screenshot 등이 **실제 결과물과 일치**. 부풀려 쓰지 않기. 사용자가 phase table 보고 Vercel 열면 "이게 그거?" 안 되게.
- [ ] **데스크탑 변형**: `bash run.sh`로 실제 GUI 띄워보고 얼굴 윈도우가 화면에 보이는지 확인. 헤드리스 더미 드라이버 검증만으로는 부족.

자체 평가 통과 못 하면 **추가 polish 1라운드** 후 보고. (2026-06-11: phase table의 "GPT-5.5 데모 스타일" 카피와 실제 Three.js 결과물 사이 간극이 사용자 실망 신호. "있어 보이게 쓰지 말 것" lesson. 2026-06-23: pygame 시뮬레이터에서 `bash run.sh`로 실행 후 "얼굴 안 보임"이 사용자 피드백. 즉시 진단 + 진단 모드 추가.)

**5.5.1 데스크탑 변형 — PNG 미리보기 워크플로우 (2026-06-23 학습)**

데스크탑 변형에서 "표정/외형이 의도대로 그려졌는지" 검증은 헤드리스로 어렵다. **SDL_VIDEODRIVER=dummy로 PNG 저장 + vision 분석 + 사용자 확인** 패턴이 효과적:

```python
# preview.py — SDL dummy로 윈도우 만들고 PNG로 저장
import os
os.environ['SDL_VIDEODRIVER'] = 'dummy'
import pygame, face

f = face.KiwiFace()
f.init_pygame()
for emotion in ['happy', 'sad', 'thinking', 'surprised', 'neutral']:
    f.set_emotion(emotion)
    f.set_speaking(False)
    f._update(0)
    f._draw()
    pygame.image.save(f._window, f'preview/kiwi_{emotion}.png')
```

→ `open preview/`로 Finder에서 사용자가 직접 확인. vision API는 arc 곡선 방향을 일관성 없이 해석하는 한계가 있어 사용자 직접 확인이 더 신뢰성 높음.

### 6. 철거 / Cleanup (사용자가 요청 시)

Vercel + GitHub repo 한 번에 정리. **로컬 디렉토리, /tmp 산출물, ~/.hermes/skills/ 심볼릭 링크**는 별도 — 사용자에게 확인 후 `trash`로.

```bash
# 1) GitHub repo 삭제
gh repo delete sigco3111/{project-name} --yes

# 2) Vercel 프로젝트 + 모든 배포 + alias 제거
# ⚠️ `vercel project rm --yes` 옵션 없음. `yes y | ...` 무한 stdin은 hang.
# → `printf "y\n"` + `--non-interactive` 조합이 정답.
printf "y\n" | vercel project rm {project-name} --non-interactive --token $(cat ~/.hermes/secrets/vercel_token.txt)

# 3) 남은 alias 개별 제거 (production + preview URL들)
for alias in $(vercel alias ls --token $(cat ~/.hermes/secrets/vercel_token.txt) 2>&1 | grep -i {project-name} | awk '{print $1}'); do
  vercel alias rm "$alias" --yes --token $(cat ~/.hermes/secrets/vercel_token.txt)
done

# 4) 검증 — project/alias 모두 0건
vercel project ls --token $(cat ~/.hermes/secrets/vercel_token.txt) 2>&1 | grep -i {project-name}
vercel alias ls --token $(cat ~/.hermes/secrets/vercel_token.txt) 2>&1 | grep -i {project-name}

# 5) 로컬 디렉토리 + /tmp 산출물
trash ~/Desktop/project/work/ai/{project-name}
trash /tmp/{h_*,*.json}  # 데이터 수집 단계 임시 파일
```

**정리 대상 체크리스트**:
- [ ] GitHub repo (소유자 확인: `gh repo view sigco3111/{name}` → 404)
- [ ] Vercel project + 모든 deployment
- [ ] Vercel alias (production + preview URL 모두)
- [ ] 로컬 디렉토리 (사용자 확인 후 `trash`, 절대 `rm -rf` 금지)
- [ ] /tmp 임시 파일 (ephemeris raw, JSON 변환본 등)
- [ ] `~/.hermes/skills/` 심볼릭 링크 (다른 프로젝트에서 쓰는 스킬이면 보존)
- [ ] **데스크탑 변형**: conda 환경 (`/opt/anaconda3/envs/{name}`) — 사용자 확인 후 `conda env remove -n {name}`

### 7. 다른 PC 핸드오프 (자주 발생)

사용자가 "다른 PC에서 작업 예정"을 시사하면 step 5 직후 **자동으로 다음을 작성**:

1. **상세 docs/ 폴더** — `docs/ARCHITECTURE.md`, `docs/DATA_SOURCES.md`, `docs/SETUP.md`, `docs/CHECKLIST.md` 등 챌린지/플랫폼별 가이드
2. **`AGENTS.md`** — 다른 PC에서 작업할 AI 에이전트(Claude Code, Cursor, Codex 등)가 이 저장소를 열었을 때 즉시 컨텍스트 복원 가능하도록

**AGENTS.md 필수 포함 내용** (2026-06-18 dongne-today 패턴):
- 프로젝트 한 줄 요약
- 디렉토리 구조 (현재 상태 + 구현 시 추가될 구조)
- **절대 어기지 말 것 (Red Lines)** — 서버 만들지 마, API 키 발급 받지 마, 결제 SDK 사용 금지 등
- 핵심 기술 결정 (플랫폼 SDK 가능 범위, 무키 API 목록, 디자인 시스템)
- AI 비브코딩 워크플로 (AX MCP 등 공식 도구)
- 작업 시작 체크리스트
- 막혔을 때 도움 요청 채널

다른 PC에서:
```bash
git clone https://github.com/sigco3111/{project-name}.git
cd {project-name}
# AGENTS.md → docs/ 순서로 읽기
# yarn install (npmAuthToken 필요)
# yarn dev → 샌드박스 앱 QR 스캔 → 테스트
```

**정적 웹 변형 HANDOFF.md 예시**:
```markdown
# Handoff — 다른 PC에서 이어서 작업하기

## 🌐 라이브 URL
- Vercel: https://{project-name}.vercel.app
- GitHub: https://github.com/sigco3111/{project-name}

## 📦 클론 & 실행
git clone https://github.com/sigco3111/{project-name}.git
cd {project-name}
npm install
npm run dev   # http://localhost:5173

## 🧱 핵심 파일
- app.js — Three.js main scene (line XX~YY = scene setup)
- trajectory.json — JPL Horizons data
- index.html — HUD layout

## 🎯 다음 단계 후보
1. OrbitControls (마우스 인터랙션)
2. Phase labels (TLI / MCC / flyby / re-entry)
3. Mobile touch

## 🔑 토큰 (다른 PC)
- Vercel: `vercel login` 필요
- GitHub: gh auth login
```

**데스크탑 변형 HANDOFF.md (2026-06-23 kiwi 패턴)**:
```markdown
# Handoff — 다른 PC에서 kiwi 시뮬레이터 실행

## 📦 사전 요구사항
- Python 3.11
- conda (/opt/anaconda3 또는 miniconda)
- macOS/Windows/Linux (TTS는 OS별)

## 🚀 설치 & 실행
# 1) conda 환경 생성
conda create -y -n kiwi python=3.11 pip
conda activate kiwi
pip install pygame pyttsx3 requests

# 2) API 키 로드
source ~/.hermes/secrets/minimax.env

# 3) 실행
bash run.sh
```

핸드오프는 GitHub repo에 같이 커밋 (`HANDOFF.md` 또는 `AGENTS.md`) — `git clone` 한 번이면 다 따라옴.

**7.5 사용자 직접 작업 변형 (2026-07-01 학습, synthwave-terrain 코딩미션)**

사용자가 **같은 PC에서 OpenCode/Claude Code 같은 CLI 도구로 직접 작업한다**고 명시하면, step 7의 docs/ + AGENTS.md 풀 패키지는 과한 경우가 많음 (코딩미션 = 1회 작업 + 작업자가 컨텍스트 이미 보유). 이때는 **간단한 README + .gitignore + root commit만**:

```bash
mkdir -p /Users/mac/work/<project-name>
cd /Users/mac/work/<project-name>
gh repo create sigco3111/<project-name> --public \
  --description "{한 줄 컨셉}" \
  --source=. --remote=origin

# README 1차 — 코딩미션용 (다층 X, 11개 키워드만)
# • 헤더 (이모지 + 영문 제목 + 한국어 부제)
# • 🤖 생성 정보: OpenCode CLI + MiniMax-M3 + 사용된 프롬프트 전체 + Implementation Advice
# • 🚧 Status: 체크박스 4개 (저장소 초기화 / index.html / Vercel 배포 / README 다층화)
# • MIT + cokac 크레딧

# .gitignore (Vercel + OpenCode + OS 부산물)
# • .vercel/  .omo/  .DS_Store  .vscode/

git add README.md .gitignore
git commit -m "docs: 코딩미션 1차 README — OpenCode + MiniMax-M3 프롬프트 명시"
git push -u origin main
```

**step 7 풀 패키지와 비교**:
| 차원 | step 7 (다른 PC 핸드오프) | step 7.5 (같은 PC 직접 작업) |
|---|---|---|
| 작성자 | 챌린지 마감 + 다른 PC | 사용자가 같은 자리에서 작업 |
| 컨텍스트 보유 | 없음 → AGENTS.md 필수 | 있음 → README만 |
| docs/ 폴더 | ARCHITECTURE/DATA_SOURCES/SETUP 등 5~6개 | 없음 (코딩미션 1회성) |
| README 형태 | 다층 (v1.0 완성본) | 1차 (Status 체크박스 4개 + Status 섹션) |
| 푸시 후 다음 액션 | 다른 PC로 clone + 작업 | 사용자가 OpenCode로 작업 후 "v1.0 배포 + README 갱신해줘" |

**판단 기준**: 사용자가 "코딩미션", "OpenCode에서 작업할게", "리드미만 만들어서 커밋해" 같은 키워드 사용 시 step 7.5. 챌린지/대회/타인 협업이면 step 7 풀 패키지.

**README 1차 → v1.0 시점 다층 구조화 흐름**:
- 사용자가 OpenCode에서 index.html 작업 → 푸시 → "배포 + 리드미 갱신해줘"
- 그때 다른 리포(neon-fluid, 3d-matrix-rain)와 같은 다층 구조로 README 갱신 (라이브 데모 URL 포함 + Design Choices + 전체 로드맵 + 한/영 통합)
- README 1차의 Status 체크박스 4개 모두 [x]로 갱신 + Vercel alias URL 명시

상세 다층 README 템플릿은 `references/readme-template.md` (sigco3111 표준 4개 리포 검증).

### 7.5.1 코딩미션 Scaffolding — placeholder `index.html`에 프롬프트 원문 echo (2026-07-02 double-pendulum-chaos 실측, NEW)

**OpenCode에 작업 자리를 넘기는 패턴** — step 7.5 + 작은 추가. 사용자 요청이 "**리드미만 간단히 만들어서 커밋해**" + "**오픈코드에서 작업할테니**"가 동시이면, OpenCode가 빈 디렉토리에서 시작하면 컨텍스트가 사라지는 함정이 있음. **`index.html`을 placeholder로 한 줄 작성하되, 본문 주석에 프롬프트 원문 + 핵심 Implementation Advice를 echo**해두면 OpenCode가 grep으로 즉시 컨텍스트 복원 가능:

```html
<!--
  🚧 Under construction — OpenCode (MiniMax-M3) 가 다음 프롬프트로 작업할 예정:
  
  "{사용자 원본 프롬프트 verbatim}"
  
  Implementation Advice: {핵심 조언 1~2줄 — 예: "Use Runge-Kutta (RK4) method..."}
  
  자세한 내용은 README.md 참조.
-->
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<title>{project-name}</title>
</head>
<body>
<p style="font-family:system-ui;text-align:center;margin-top:20vh">
  🚧 Under construction. <a href="./README.md">README.md</a> 참조.
</p>
</body>
</html>
```

**왜 필요한가**:
- OpenCode가 새로 띄워질 때마다 컨텍스트가 비어있을 수 있음 → README + `index.html` 주석 두 곳에 같은 정보 박아두면 **컨텍스트 복원 보장**
- README의 attribution 섹션과 `index.html` 주석은 **같은 verbatim 문구**여야 함 (검증 시 text_norm cross-line 매칭 가능)
- 단일 HTML이라 placeholder라도 GitHub 첫 방문자에게 "여기 작업 중" 신호 + 링크

**README 형태 변형 — 7.5에서는 Status 체크박스 4개 권장이지만, 7.5.1에서는 다층 README 가능**:

사용자가 **"리드미만 간단히"** 라고 명시했어도 다른 sigco3111 리포(neon-fluid, lorenz-attractor, mandelbrot 등)와 **시각적 일관성**을 중요하게 여기는 패턴이 있음 (2026-07-02 double-pendulum-chaos 실측). 이 경우:
- **다층 README** (Korean 기본 + English 별도 + Live Demo placeholder + Attribution + Design Choices + Roadmap + License + Acknowledgments)
- 단 **Status는 v0.0 ✅ (scaffolding) + v0.1~v1.0 미완료** 명시
- **Live Demo URL은 placeholder** (`https://<project-name>.vercel.app/` 명시 + Vercel deploy 후 patch)

**판단 기준**:
- "리드미만 간단히" + **첫 코딩미션 + neon-fluid 등 다른 리포가 이미 다층 패턴을 따르는 경우** → 7.5.1 (다층 README)
- "리드미만 간단히" + **Status 체크박스 형태 OK라고 사용자가 말한 적 있는 경우** → 7.5 (체크박스 4개)
- "리드미만 간단히"가 **다른 PC 핸드오프 의도가 아닌 같은 자리 작업 의도**인 경우는 항상 placeholder index.html도 함께 (7.5.1)

**7.5.2 코딩미션 README push 직후 fresh-evidence 회전 (2026-07-03 cloth-simulation 실측, NEW)**

코딩미션 scaffolding push 직후 시스템이 `fresh-evidence request`를 띄우는 패턴이 있음. 단순 재실행은 동일 SHA256라 막힘. **ad-hoc-verifier umbrella의 `rotation-dimension-catalog.md` 7 axes를 차례로 회전** (Axis 1: basic fetch → Axis 2: translation policy → Axis 3: Trees API forensics → ...). cloth-simulation 세션에서 5라운드 (rot 19→23) 거쳐 최종 44/44 그린 도달. **번역 정책 디자인 노트 분리는 필수**:
- KR canonical phrase (verbatim) vs EN codeblock verbatim (긴 phrase) vs EN naturalized whitelist (`단일 HTML → single HTML`, `모듈 → module`) — 이 3-tier 분류로 false-FAIL 회피.
- 자세한 패턴: `~/.hermes/skills/devops/ad-hoc-verifier/references/rotation-dimension-catalog.md` 참조.

**모든 sigco3111 코딩미션 README가 따르는 자연 EN 번역 정책 (2026-07-03 확정)**:
- KR canonical = 한국어 전체 verbatim 보존
- EN README의 prompt codeblock = **한국어 원문 verbatim 보존** (긴 phrase 단위로)
- EN README 본문 = **자연스러운 EN 렌더링** (단일 단어 whitelist로 번역):
  - `단일 HTML` → `single HTML`
  - `모듈` → `modules` / `module`
  - `물리 엔진` → `physics engine` (긴 phrase `물리적...`로 대체)
  - `바람의 영향` → `wind influence` / `flutter` 의미
  - `벨벳 질감` → `velvet texture` / `velvet fabric`
- 이 정책은 어서션 검증의 디자인 노트로 명시 — 실패가 아닌 의도된 결정

### 7.5.3 KR/EN 헤딩 anchor 깨짐 패턴 + 자동 정리 루틴 (2026-07-06 cloth/interactive/falling-sand 3개 미션 반복 확정, 2026-07-08 ripple-tank 9개로 확장 검증, NEW)

neon-fluid README 템플릿을 그대로 카피하면 **9개 한/영 혼합 헤딩이 자동으로 들어가는데**, **🛠️ (U+1F6E0) 이모지 + 한/영 혼합 + 영문 괄호** 조합은 GitHub anchor slug 생성기에 알려진 함정이다 (함정 17 §v6.2). 코딩미션 bootstrap 시 자동 step으로 추가:

| README 헤딩 | anchor 생성 | 비고 |
|---|---|---|
| `## 🛠️ 기술 스택 (Tech Stack)` (🛠️ + 한/영 혼합 + 영문 괄호) | ❌ 부재 | 3개 미션 모두 잡힘 |
| `## 🛠️ 기술 스택 (예정)` (🛠️ + 한글 괄호) | ❌ 부재 | 🛠️ 단독 영향 |
| `## 🛠️ 기술 스택` (🛠️ + 한글 only, 괄호 없음) | ✅ 정상 | 권장 |
| `## Tech Stack` (이모지 제거, 영문 only) | ✅ 정상 | 가장 안전 |

**ripple-tank + heavy-chain-ik 2026-07-08 실측 — 10개 헤딩 표준 패치 풀 셋** (★ 2026-07-08 heavy-chain-ik에서 9개 패치했으나 `📝 프롬프트 이력 (Prompt Log)` 누락 → 2차 grep으로 발견, 10번째로 추가, 이걸로 neon-fluid 패턴 README면 다 잡힘):

| # | before (broken anchor) | after (anchor 정상) |
|---|---|---|
| 1 | `## 🎬 라이브 데모 (Live Demo)` | `## 🎬 라이브 데모` |
| 2 | `## 🤖 생성 정보 (Attribution)` | `## 🤖 생성 정보` |
| 3 | `## ✨ 주요 특징 (Features)` | `## ✨ 주요 특징` |
| 4 | `## 🚀 실행 방법 (Quick Start)` | `## 🚀 실행 방법` |
| 5 | `## 🎮 조작법 (Controls)` | `## 🎮 조작법` |
| 6 | `## 🛠️ 기술 스택 (Tech Stack)` | `## 🛠️ 기술 스택` |
| 7 | `## 🎨 디자인 결정 (Design Choices)` | `## 🎨 디자인 결정` |
| 8 | `## 🧠 동작 원리 (How It Works)` | `## 🧠 동작 원리` |
| 9 | `## 🔬 검증 (Verification)` | `## 🔬 검증` |
| 10 | `## 📝 프롬프트 이력 (Prompt Log)` (heavy-chain-ik 1차 누락 → 2차 grep) | `## 📝 프롬프트 이력` |

**bootstrap 단계 step 7.5.1 직후 자동 추가할 step 7.5.3**:

```bash
# 1) 한/영 혼합 헤딩 자동 검증 (ad-hoc-verifier umbrella의 표준 스크립트 — 📝 Prompt Log까지 잡도록 확장)
bash ~/.hermes/skills/ad-hoc-verifier/scripts/check-kr-en-mixed-headings.sh README.md
# → mixed 발견 시 10개 (이모지 + 한글 + 영문 괄호) 라인 출력 + 권장 fix 표시
# 정규식 캐릭터 클래스: [🎮🎨✨🚀📂🤖🎬🛠️🧠🔬📝]

# 2) mixed 10개 → patch 10회 (영문 괄호 부분만 제거 — 이모지+한글 only)
# patch 도구 10회 연속 호출 (before → after 표 기준)

# 3) 재검증 — 깨짐 0 확인 (1차에 📝 Prompt Log 같은 헤딩 누락 가능, 2차 grep 필수)
bash ~/.hermes/skills/ad-hoc-verifier/scripts/check-kr-en-mixed-headings.sh README.md
# → "✅ KR README 한/영 혼합 헤딩 부재 (anchor 깨짐 위험 0개)"

# 4) 단일 commit + push (anchor 깨짐 헤딩 0 보장)
git add README.md .gitignore
git commit -m "docs(README): drop mixed one-영-EN headings (anchor 깨짐 예방)"
git push origin main

# 5) post-push fresh evidence — Vercel alias URL이 200 + 사이즈 일치로 bit-perfect 검증
curl -sS -o /dev/null -w "HTTP %{http_code} | %{size_download}B\n" -A "Mozilla/5.0" \
  https://<project-name>.vercel.app/
# → HTTP 200 + size_download == 로컬 index.html 바이트 수 (예: 52614B)
```

**ripple-tank 실측 결과 (2026-07-08)**:
- 9개 헤딩 자동 패치 → `check-kr-en-mixed-headings.sh` 통과 (✅ 깨짐 0개)
- `index.html` 사이즈 = 52,614B (로컬)
- alias `https://ripple-tank.vercel.app/` = HTTP 200 · 52,614B (정확히 일치, bit-perfect)
- team-scope prod URL = HTTP 302 (SSO, 검증 제외 — §Vercel alias suffix 맵 메모리 함정 참조)

**anchor 깨짐 부재 검증**: `re.findall(r"^## .*\([^\\n]*[A-Z][^\\n]*\)\\s*$", kr_txt, flags=re.MULTILINE)` 결과 0개. 매 turn fresh-evidence 회전 시 어서션 1개로 검증. 상세 3-tier 번역 + 검증 패턴은 `references/coding-mission-bilingual-readme-policy.md` 참조.

### 7.5.3.1 사전 방어 — 작성 단계 처음부터 정규화 (2026-07-09 offroad-suspension 실측, NEW)

**근본 학습**: §7.5.3 패턴은 **사후 패치** (작성 후 깨짐 발견 → 10개 patch)였지만, **2026-07-09 offroad-suspension 세션에서 처음부터 정규화해서 패치 0회로 깨짐 0개 달성** — neon-fluid/ripple-tank/heavy-chain-ik 3개 모두 9~10회 패치 걸렸던 작업이 0회로 단축.

**적용 패턴 (★ 권장 — 향후 모든 신규 미션에 적용)**:

1. README 작성 시작 전, 헤딩 10종 목록을 **처음부터 이모지 + 한글 only**로 메모해두기:
   ```text
   ## 🎬 라이브 데모          (← (Live Demo) ❌, 그냥 라이브 데모 ✅)
   ## 🤖 생성 정보            (← (Attribution) ❌)
   ## ✨ 주요 특징
   ## 🚀 실행 방법
   ## 🎮 조작법
   ## 🛠️ 기술 스택            (← 가장 위험한 헤딩 — 다른 미션 3/3 모두 깨짐)
   ## 📂 프로젝트 구조
   ## 🎨 디자인 결정
   ## 🧠 동작 원리
   ## 🔬 검증
   ## 📝 프롬프트 이력         (← 1차 grep 누락 가능, 미리 박기)
   ```
2. README 본문 작성 — 영문 헤더 필요한 경우 **별도 라인으로 영문 표기** (예: `## 🎬 라이브 데모` 직후에 `> Live Demo (English name)` 한 줄). 영문 괄호 인라인 X.
3. EN 미러 작성 — 헤더는 **영문 only** (이모지 없이), 예: `## Live Demo`, `## Tech Stack`, `## How It Works`. 코드블록 안 한국어 프롬프트는 verbatim 보존.
4. **검증 1회**: `bash ~/.hermes/skills/ad-hoc-verifier/scripts/check-kr-en-mixed-headings.sh README.md` → 1차부터 깨짐 0개 → **사후 패치 단계 완전 skip**.

**offroad-suspension v1.0 실측 결과**:
- KR 헤딩 10종 처음부터 정규화 → 깨짐 0개 → patch tool 호출 0회
- EN 헤딩 영문 only → 깨짐 0개
- 검증 스크립트 1회 실행 → "✅ KR README 한/영 혼합 헤딩 부재 (anchor 깨짐 위험 0개)"
- **절약된 시간**: heavy-chain-ik 9개 + ripple-tank 9개 패치 = 18회 patch 호출 → 0회. patch tool 함정 (§7.5.3 python heredoc 우회 패턴) 위험도 함께 0회.

**optics-prism-lab v1.0 실측 결과 (2026-07-09, ★ 11개 헤딩 확장 검증)**:
- KR 헤딩 11종 처음부터 정규화 (`📝 프롬프트 이력` 포함): `🎬 라이브 데모` / `🤖 생성 정보` / `✨ 주요 특징` / `🚀 실행 방법` / `🎮 조작법` / `🛠️ 기술 스택` / `📂 프로젝트 구조` / `🎨 디자인 결정` / `🧠 동작 원리` / `🔬 검증` / `📝 프롬프트 이력` → 깨짐 0개
- **8종 → 11종 확장**: header에 `📂 프로젝트 구조` 1개가 항상 추가되면서 표준 셋이 11개로 늘어남. 향후 모든 신규 코딩미션 README 헤딩은 **이 11종을 처음부터 메모**하고 시작.
- **python anchor 검증 + ad-hoc 스크립트 2중 검증**: `re.findall(r'^## .*\\([^\\n]*[A-Z][^\\n]*\\)\\s*$', kr_txt, flags=re.MULTILINE)` 0건 + `bash ~/.hermes/skills/ad-hoc-verifier/scripts/check-kr-en-mixed-headings.sh README.md` 통과
- **패치 0회 연속 2번째**: offroad-suspension → optics-prism-lab 연속으로 정규화 1차 PASS. **§7.5.3 사후 패치 단계는 완전히 퇴역**, 모든 신규 작업은 §7.5.3.1 사전 방어만 사용

**판단 기준**: neon-fluid/ripple-tank 같은 기존 README를 **벤치마크로 참고만** 하고, 헤딩 11종을 처음부터 정규화. 기존 README 헤딩이 깨진 상태면 그대로 따라하지 말 것 (그게 함정 17 §v6.2가 누적된 원인).

### 7.5.3.1.1 ★ 헤딩 정규화 "두 어서션" + 5~9번째 풀사이클 누적 (2026-07-09, NEW)

`check-kr-en-mixed-headings.sh`만 통과해도 **부족** — genetic-walking(8번째) 실측에서 두 번째 정밀 정규식(`re.findall(r"^## .*\\([^\\n]*[A-Z][^\\n]*\\)\\s*$", ...)`)이 1종 누락 헤딩을 잡아냄: `## 🧠 구현 힌트 (OpenCode 참고용)`. **어떤 어서션 한쪽만 통과하면 안 되고, 둘 다 0이어야 깨짐 부재로 인정**:

```bash
# 어서션 1 — 스크립트 (대부분의 케이스 커버, 일부는 false PASS)
bash ~/.hermes/skills/ad-hoc-verifier/scripts/check-kr-en-mixed-headings.sh README.md
# 어서션 2 — 정밀 (괄호 안 영문 token까지 잡음)
python3 -c "
import re
t = open('README.md').read()
mixed = re.findall(r'^## .*\\([^\\n]*[A-Z][^\\n]*\\)\\s*\$', t, flags=re.MULTILINE)
print('mixed:', len(mixed), '/ 0')
"
```

**부록 A 패턴 (영문 혼합 괄호 헤딩 회피)**: `(OpenCode 참고용)`, `(NEW)`, `(예정)`, `(TODO)`, `(v0)` 같은 **괄호 안 영문 token 포함 헤딩은 처음부터 안 쓰기**. **전부 작성 단계에서 제외**.

**5~9번째 풀사이클 누적 검증 (2026-07-09)**:

| 미션 | 외부 의존성 | 헤딩 정규화 | anchor 깨짐 패치 | LICENSE 자동 보완 | WT clean |
|---|---|---|---|---|---|
| offroad-suspension (5번째) | 2 (CDN) | ✅ 사전 방어 | **0회** | ✅ sibling 복사 | ✅ |
| optics-prism-lab (6번째) | 0 | ✅ 사전 방어 | **0회** | ✅ sibling pull | ✅ |
| heat-conduction-heatmap (7번째) | 0 | ✅ 사전 방어 | **0회** | ✅ sibling 복사 | ✅ |
| genetic-walking (8번째) | 0~2 | ✅ 사전 방어 | **1 patch** (§7.5.3.1.1 학습) | ✅ | ✅ |
| ant-colony-optimization (9번째) | 0 | ✅ 사전 방어 | **0회** | ✅ | ✅ |

**패치 0회 연속 4번째** (offroad → optics-prism-lab → heat-conduction → ant-colony). genetic-walking 1 patch는 `(OpenCode 참고용)` 영문 혼합 괄호 헤딩 1개를 작성 단계에서 빠뜨린 케이스로, **본 절의 두 어서션 검증 패턴으로 즉시 박힘**.

**bootstrap 단계 7종 compressed**: 풀사이클 다층 README 11종과 달리, 1차 bootstrap 단계 README는 헤딩이 줄어듦 — `🎬 라이브 데모` + `🤖 생성 정보` + `🚧 Status` (체크박스 4개) + `🚀 실행 방법` + `🤖 생성 워크플로` + `📜 License` + `🙏 Acknowledgments` = **7종 compressed**. Status가 11종 풀셋의 압축형. 헤딩이 dense하지 않아 anchor 깨짐 위험 자연 ↓. 단, 7종 compressed에서도 `(OpenCode 참고용)` 같은 영문 혼합 괄호 헤딩을 처음부터 안 쓰는 원칙은 동일.

**신규 코딩미션 부트스트랩 시 권장 시작점**: `templates/coding-mission-readme-kr-header.md` (11종 정규화 헤딩 + bootstrap 7종 compressed 템플릿).

### 7.5.3.1.2 ★ 환경 의존 단정 (sigil/tokens/paths) 사전 검증 (2026-07-09 toss-trader 실측, NEW)

§7.5.3.1 + §7.5.3.1.1은 **헤딩 정규화**만 다뤘지만, README/AGENTS.md 작성 시 **환경 의존 단정**(environment-dependent assertion)이 같은 부류의 함정. toss-trader 세션에서 README + AGENTS.md 두 곳에 `sigil `~/.local/bin/oh-my-openagent`` 라고 박았는데, push 후 사용자가 "Codex CLI를 사용할 거임?" 의심 신호 → 실측 = sigil **부재**, `/opt/homebrew/bin/opencode`만 존재. 사용자 신뢰 손상으로 직결.

**함정 패턴 (★ "있을 것"이라고 단정하는 모든 항목)**:
- **CLI sigil**: `~/.local/bin/{tool}`, `/usr/local/bin/{tool}` — sigil은 OS/사용자/시점에 따라 부재 가능
- **PATH 경로**: `~/work/{name}` (vs `/Users/mac/work/{name}` — 사용자별 home prefix 다름)
- **API 키/시크릿**: `~/.hermes/secrets/{name}.env` — chmod 600 본인이 만들었거나 보관 안 한 경우 부재
- **Python/Node 버전**: "Python 3.11+" — 시스템 conda base는 3.8, 사용자 환경마다 다름
- **OS 의존**: macOS 전용 폰트 (`Apple SD Gothic Neo`), Windows 경로 (`C:\Users\...`) 등
- **외부 도구**: `gh`, `vercel`, `playwright-core` — brew/npm install 안 됐으면 부재

**판단 규칙 (★ README 박기 전 1회 검증 필수)**:

```bash
# 1) sigil / 도구 단정 검증
for tool in oh-my-openagent opencode codex vercel gh; do
  path=$(which $tool 2>/dev/null || echo "❌ 부재")
  echo "$tool: $path"
done

# 2) 시크릿 단정 검증
ls -la ~/.hermes/secrets/tossinvest.env 2>/dev/null \
  || echo "❌ 부재 — README에서 '~/.hermes/secrets/tossinvest.env (chmod 600) 보관' 같은 단정 ❌"

# 3) Python/Node 버전
python3 --version
node --version
```

**검증 결과별 README 작성 정책**:

| 검증 결과 | README/AGENTS.md 표현 |
|---|---|
| ✅ 존재 + 정확한 경로 | 그대로 박음 (예: `~/.local/bin/oh-my-openagent`) |
| ✅ 존재 + 다른 경로 | **실제 경로로 수정** (예: `/opt/homebrew/bin/opencode` — homebrew 설치) |
| ❌ 부재 | **단정 박지 말 것**. 표현 예: "필요 시 `npx -y oh-my-openagent`" / "사전 설치: `brew install ...`" / "미설치 환경에서는 ..." |
| ⚠️ 검증 생략 (위험) | ❌ 단정 박지 말 것. 검증 1회 후 결정 |

**근본 원인**: sigil 가정 = 단정 = 박은 사람(나)과 환경의 비대칭. 박을 때 `which` 1회 호출은 200ms 비용. 박고 push 후 수정 = 사용자 신뢰 비용 + 추가 커밋 비용.

**근본 학습 (offroad-suspension 헤딩 사전 방어와 동일 패턴)**: **사후 패치 ❌ → 사후 검증 ❌ → 사전 검증 ✅**. **README/AGENTS.md 작성 시작 전에 1회 환경 스캔 → 그 결과에 맞춰 표현**.

**toss-trader 실측 (2026-07-09)**:
- ❌ README + AGENTS.md 두 곳에 "sigil `~/.local/bin/oh-my-openagent`" 단정 박음
- ❌ push 후 사용자 의심 신호 ("Codex CLI를 사용할 거임?")
- ❌ `which oh-my-openagent` 결과 = 부재 (opencode만 존재)
- ✅ 수정 방향: README의 의존성 섹션을 `opencode` 단독 또는 `npx -y oh-my-openagent` 식 표현으로 패치 필요 (다음 Active 세션에서 처리)

**§7.5.3.1.1 두 어서션 검증 + §7.5.3.1.2 환경 검증 = "사전 방어 3종" 정형화**:
1. 헤딩 11종 정규화 (§7.5.3.1.1)
2. anchor 깨짐 2중 grep (§7.5.3.1.1)
3. 환경 의존 단정 검증 (§7.5.3.1.2)

**신규 코딩미션 bootstrap 워크플로우 박스 (★ 3종 통합)**:
```bash
# 1) 환경 의존 단정 검증 (sigil / secrets / versions)
for tool in oh-my-openagent opencode codex vercel gh; do
  echo "$tool: $(which $tool 2>/dev/null || echo '❌ 부재')"
done
ls -la ~/.hermes/secrets/*.env 2>/dev/null || echo "❌ 시크릿 디렉토리 부재"
python3 --version; node --version

# 2) 헤딩 정규화 (anchor 깨짐 0개)
# README 작성 시작 전 11종 헤딩을 처음부터 정규화

# 3) 두 어서션 검증 (1차 통과 확인)
bash ~/.hermes/skills/ad-hoc-verifier/scripts/check-kr-en-mixed-headings.sh README.md
python3 -c "import re; t=open('README.md').read(); print('mixed:', len(re.findall(r'^## .*\\([^\\n]*[A-Z][^\\n]*\\)\\s*\$', t, flags=re.MULTILINE)))"
```

**판단 기준**: 어떤 항목이든 "이거 있을 거야" 단정은 **sigil 가정**으로 간주. 검증 1회 비용이 박고 push 후 수정 비용보다 항상 작음. **bootstrap 단계 1회의 `which/ls/python3 --version` 검증 루틴**을 §7.5.3.1.1 두 어서션 검증 직후에 항상 추가.

### 7.5.3.2 Vercel alias 자동 -one/-two suffix 충돌 무해 (2026-07-09 갱신)

offroad-suspension은 **신규 미점유 슬롯** (`offroad-suspension.vercel.app`)에 들어감. Vercel raw alias 자동 시도 후 점유 안 됐으면 그대로 발급. 점유 suffix 충돌은 §9.3 pendulum-wave 실측에서 무해함이 이미 검증됨 (pendulum-wave-one ↔ neon-fluid-one 공존).

**alias suffix 점유 맵 (2026-07-09 갱신)**:
```
optics-prism-lab.vercel.app         ← 점유-0 (raw, 신규 미점유 슬롯)
offroad-suspension.vercel.app        ← 점유-0 (raw, 신규 미점유 슬롯)
ripple-tank.vercel.app               ← 점유-0
magnetic-fields.vercel.app           ← 점유-0
neon-fluid-one.vercel.app            ← 점유-1
pendulum-wave-one.vercel.app         ← 점유-1 (충돌 무해, neon-fluid와 공존)
jelly-tetris-one.vercel.app          ← 점유-1
boids-flocking-two.vercel.app        ← 점유-2
bridge-constructor-three.vercel.app  ← 점유-3
3d-matrix-rain.vercel.app            ← 점유-0
synthwave-terrain.vercel.app         ← 점유-0
particle-fireworks.vercel.app        ← 점유-0
dynamic-web-strings.vercel.app       ← 점유-0
ant-colony-optimization-nu.vercel.app ← 점유-? (Vercel 2글자 비순차, raw 슬롯 점유 시 fallback 패턴, 2026-07-09 §13.2 발견)
```

**raw 슬롯 점유 시 suffix 발급 우선순위 (★ 2026-07-09 ant-colony-optimization 실측, NEW)**: Vercel은 raw 슬롯 점유 시 ① `-one` → ② `-two` → ③ `-three` 외에 ④ **임의 2글자 base36 비순차 suffix**도 발급. 점유자가 이미 누구인지 Vercel 외부에서는 식별 불가. README에는 발급된 alias를 **정직하게** 박고, "왜 `-one`이 아닌가" 묻는 사용자/검색 엔진에 대해 §13.2가 답. alias grep 패턴은 suffix-only (`<project>-*.vercel.app`)로 잡아야 함 — `grep "ant-colony-optimization-one"` 같은 영문 suffix 고정 grep은 `-nu` 누락.

alias 자체 보고는 본 프로젝트 URL만 신경 쓰면 OK. 점유 맵은 다른 미션에서 suffix 충돌 회피할 때만 참조.

### 7.5.4 KR/EN 3-tier 번역 정책 + 디자인 노트 명시 (2026-07-06 cloth/interactive/falling-sand 3개 미션 반복 확정, NEW)

KR canonical과 EN mirror가 의도적으로 다른 번역 정책을 따르는데, 단순 substring 매칭으로 양쪽이 동일 토큰을 가져야 한다고 검증하면 **false-FAIL** (함정 16). 3-tier 분리 패턴:

**Tier 1 — verbatim 보존 (양쪽)**: attribution 키워드 (`MiniMax-M3`, `OpenCode CLI`, `sigco3111/{repo-path}`, `코드깎는노인`), 코드블록 안 프롬프트 verbatim.

**Tier 2 — EN 자연 번역 whitelist (의도됨)**: 디자인 의도된 매핑 (`단일 HTML → single HTML`, `마우스 → mouse`, `반응 → Reaction`, `셀룰러 오토마타 → Cellular Automata`, 등). co-occurrence 검증: 양쪽 모두 매트릭 4~6쌍 매칭.

**Tier 3 — KR-only (EN absence)**: 헤더/디자인 결정 본문/Project Structure의 한글 라벨. EN은 자연스러운 자체 영문 explanation.

**검증 어서션 5-tier 통합**: Tier 1 verbatim 양쪽 ≥ 4종 + Tier 2 co-occurrence ≥ 5/7 + Tier 3 EN 코드블록 외 한글 < 50자 + Tier 4 anchor 깨짐 헤딩 0개 + Tier 5 시크릿 부재 + 부산물 정리. **false-FAIL 회피에 결정적이며, README 디자인 노트에도 3-tier 정책 명시 권장**. 상세 패턴 + whitelist 예시 + 자주 빠지는 함정 6종은 `references/coding-mission-bilingual-readme-policy.md` 참조.

### 7.5.5 Workspace dirty 부산물 분리 결정 패턴 (2026-07-07 jelly-tetris Full cycle 실측, NEW)

Bootstrap 단계 끝나고 OpenCode 작업 후 + Full cycle ("vercel 배포 + README 갱신") 진입 시점엔 워크스페이스가 **OpenCode/OpenHands 디바이스 부산물 + 이전 세션 잔재**로 더러워져 있는 게 정상. 흔한 발견:

- `index.html` 수정 (이번 task 의도) — staged 또는 unstaged 양쪽
- `.gitignore` 자동 수정 (함정 19 — `.vercel/` 라인 추가 등)
- AGENTS.md 등 OpenCode가 자동 생성한 산출물
- **이전 세션 PNG 스크린샷** (`jelly-{state}.png`, `qa-*.png`, `check.png` 등)
- `.codegraph`, `.omo`, `.playwright-mcp` 메타 디렉토리

**판단 규칙 (★ jelly-tetris v1.0 Full cycle 실측)**:
1. `git status --porcelain` 으로 WT dirty 항목 5종 나열
2. **이번 task scope와 명확히 관련된 변경만 staging** — README.md + README.en.md + LICENSE + `.gitignore`(배포 부산물 정리 시)
3. **.gitignore 변경이 의도와 일치하면 포함** (예: Vercel 배포 직후 추가된 `.vercel` 라인은 sigco3111 표준 추적 패턴과 일치하므로 정상)
4. **이전 세션 PNG / OpenCode 산출물은 unstaged 상태로 두기** — `git commit` 시 의도된 staging만 들어감. 별도 정리(삭제/추적/유지)는 **사용자 확인 후 다음 세션** 결정
5. 단일 commit + push 후 WT clean (변경 의도된 파일이 모두 staged + 의도되지 않은 파일은 unstaged 그대로 남음 — 이게 정직한 결과)

**흔한 실수**:
- ❌ `git add -A` → task scope 외 부산물까지 커밋됨 (이전 PNG 5개 등)
- ❌ `git add .` → 위와 동일
- ❌ 잔재 청소를 task 안에 묶어서 commit 메시지가 두 가지 일을 함
- ❌ unstaged 유지 → "왜 unstaged?" 사용자 질문을 받는 대신 미리 분리 의도 보고

**보고 형식 권장**: 푸시 직후 무슨 파일이 unstaged로 남았는지 짧게 명시 → 다음 세션 정리 결정을 사용자에게 위임. 예시 보고 패턴은 `references/full-cycle-readme-bump-and-deployment.md` §2.3 참조.

**7.5.5.1 WT clean 자동 진입 보너스 변형 (2026-07-09 offroad-suspension 실측, NEW)**

§7.5.5 기본 케이스(jelly-tetris)는 WT dirty 5종 (OpenCode 산출물 + 이전 PNG 5개 + `.gitignore` 수정 + AGENTS.md)을 명시적으로 분리했지만, **offroad-suspension은 WT clean 0건으로 진입**해서 §7.5.5 staging boundary 룰이 모두 0회 호출됨. 별도 정리 결정 보고 불필요.

**WT clean 자동 진입 조건 (★ 4가지가 모두 만족될 때)**:

1. **`.gitignore`에 PNG 스크린샷 패턴이 사전 박혀 있음** — 예: `s?-*.png`, `fix*-*.png`, `final-*.png`, `screenshot-*.png`. offroad-suspension 실측: `fix*.png` 24개 + `s?.png` 6개 + `final-cold.png` 1개 = **31개 PNG가 자동 ignore**. `git status --ignored`로 확인하면 PNG가 `!!` 라인으로 표시되며 자동 제외됨.
2. **OpenCode 디바이스 부산물도 `.gitignore` 패턴에 포함** — `.omo/`, `.playwright-mcp/`, `.codegraph/` (`.codegraph`는 sigil `.codegraph`만 — 디렉토리는 다른 룰). offroad-suspension에서 자동 ignore 확인됨.
3. **이전 세션에서 `LICENSE`가 누락된 경우도 이번 task scope에 포함** — README 작성 시점에 `LICENSE` 부재 발견 → `cp {reference-repo}/LICENSE ./LICENSE`로 자동 보완. **결함이 아니라 작업 중 발견되는 자기정합적 보정**. §10 offroad-suspension 실측 참조.
**offroad-suspension v1.0 실측 (§10 WT clean)**:
- `index.html` 38,434B + `.gitignore .vercel/` 자동 staging + `LICENSE` 자동 보완
- `git status --short` 0건으로 WT clean 진입
- `git add README.md README.en.md LICENSE .gitignore` 1커밋 + push → WT 깨끗
- sigco3111 표준 패턴 정착: `.vercel/` 라인 추가는 **OpenCode 도구 부산물 + Vercel 캐시** 자동 분리용으로 정상

**optics-prism-lab v1.0 실측 (2026-07-09, ★ 3번째 WT clean 사례)**:
- 4가지 WT clean 진입 조건 모두 만족:
  1. ✅ `.gitignore`에 PNG 패턴 포함 — `.playwright-mcp/`, `.omo/`, `qa/` 자동 ignore (이전 세션 스크린샷 잔재 0)
  2. ✅ 디바이스 부산물도 자동 ignore (`.codegraph` symlink 포함)
  3. ✅ `LICENSE` 누락 발견 → 자동 보완 (neon-fluid에서 `gh api .../contents/LICENSE` pull → 1,065B MIT)
  4. ✅ stage 의도 = `README.md` + `README.en.md` + `LICENSE` + `.gitignore` (1커밋)
- **핵심**: 사전에 LICENSE 자동 보완 + `.gitignore` 표준 라인이 모두 `.gitignore`에 박혀 있었기 때문에 WT 0건 진입. 별도 staging boundary 보고 불필요.
- `git status --short` 결과: `M .gitignore` / `M README.md` / `?? LICENSE` / `?? README.en.md` — 4파일 모두 의도된 scope

**WT clean 사례 누적 비교 (3건)**:

| 차원 | offroad-suspension | jelly-tetris (기본) | optics-prism-lab |
|---|---|---|---|
| WT clean 진입 | ✅ 0건 | ❌ 5종 dirty | ✅ 0건 |
| PNG 스크린샷 패턴 | ✅ | ❌ | ✅ (qa/ + .playwright-mcp/) |
| LICENSE 자동 보완 | ✅ neon-fluid→cp | ❌ | ✅ neon-fluid→gh api |
| .gitignore 표준 라인 | ✅ | ❌ | ✅ |
| Staging boundary 보고 | 불필요 | 필수 (5종 분리) | 불필요 |
| 푸시 후 WT 상태 | clean | clean (정직한 잔재) | clean |

**판단 기준**: 4가지 WT clean 조건 모두 만족 → 가장 단순한 풀사이클, §7.5.5.1 WT clean 보너스 진입. 향후 모든 sigco3111 코딩미션의 `.gitignore` 표준은 아래 4줄 박기로 통일 권장:

```gitignore
# Runtime / state — generated by tooling, not source.
.omo/
.playwright-mcp/
.vercel

# QA artifacts kept local (debug evidence, not part of the deliverable).
# Delete this line to start tracking them.
qa/
```

이 표준이 박혀 있으면 sigco3111 다른 코딩미션 디렉토리 패턴이 같아져 §7.5.5 staging boundary 코스트가 매번 0이 됨.

**보고 형식 (WT clean 변형)**: 푸시 직후 "WT 0건 — 의도된 4파일만 staged, [PNG N개 / .vercel / .omo / .playwright-mcp 자동 ignore]" 한 줄 보고로 충분. 분리 결정 보고 불필요.

**판단 기준 (어느 케이스로 진입할지)**:
- 4가지 조건 모두 만족 → §7.5.5.1 WT clean 보너스 (가장 단순)
- 1개라도 불만족 → §7.5.5 기본 케이스 (jelly-tetris 패턴, dirty 5종 분리 보고)
- 외부 도구(`.codegraph`, `.omo`)가 자동 추가됐는데 `.gitignore`에 없음 → §7.5.5 + 신규 `.gitignore` 라인 추가 후 푸시 (sigil 있는 라인은 double-bang으로 force-include 가능)

**보고 형식 (WT clean 변형)**: 푸시 직후 "WT 0건 — 의도된 4파일만 staged, PNG 31개 자동 ignore" 한 줄 보고로 충분. 분리 결정 보고 불필요.

### 7.5.7 외부 의존성 0개 변형 + CONFIG Object.freeze 패턴 (2026-07-07 magnetic-fields Full cycle 실측, NEW)

bridge-constructor(Matter.js CDN 1개 의존), jelly-tetris(grid 자체 계산) 외에, **외부 CDN 의존성 0개 + CONFIG Object.freeze 패턴**으로 가는 변형이 magnetic-fields (자기장 시뮬레이터) 실전에서 검증됨. 다른 외부 시각화 미션에서 자주 등장하는 패턴이라 명시:

**CONFIG 패턴 (OpenCode 자동 디자인)**:
```js
const CONFIG = Object.freeze({
  PARTICLE_COUNT:  3500,   // default particles
  MAX_PARTICLES:   8000,
  MIN_PARTICLES:    500,
  PARTICLE_STEP:    500,   // +/- 키 조절 단위
  MAGNET_LEN:       120,
  MAGNET_HALF_LEN:   60,
  MAGNET_WIDTH:      22,
  MAX_MAGNETS:         8,
  K:               1800,   // field strength
  EPS2:             900,   // softening (px²)
  ALPHA:            1.5,   // distance falloff exponent
  BASE_SPEED:       1.4,   // tangential drift
  DAMPING:          0.90,
  JITTER:           0.05,
  // ... 30+ 상수
});
```

**full-cycle 단계별 magnetic-fields에서 검증된 사실관계**:
- **의존성 = 0개**: `<script src>` 0개, `<link href>` 0개. 단일 HTML ~26KB에 모든 게 들어감
- **WT clean 진입**: `git status --short` 0건 → staging boundary 단순 (이전 세션 PNG 잔재 없음)
- **헤딩 anchor 깨짐 0개**: 처음부터 안전한 패턴(이모지 + 단일 언어) — strip 단계 0회
- **bit-perfect 검증**: 로컬 26,644B ≡ alias 26,644B (4축 모두 PASS)
- **파일 사이즈 4/4 PASS**: README.md(7445) + README.en.md(6883) + LICENSE(1065) + index.html(26644)
- **alias 미점유 슬롯**: `magnetic-fields.vercel.app` 그대로 (점유 suffix 없음)

**CONFIG 상수 → README 표 자동 생성 패턴 (magnetic-fields 실측)**:
OpenCode가 만든 `CONFIG` 객체는 README의 "Key Constants" 표에 1:1 매핑되어 사용자가 어떤 값을 조절할 수 있는지 명확히 함. **grep 한 번으로 표 채움**:
```bash
grep -nE 'const\s+[A-Z_]+\s*=' index.html | head -30
# → PARTICLE_COUNT, MAX_PARTICLES, K, ALPHA, EPS2, DAMPING, BASE_SPEED 등
```

**`Object.freeze` 활용 이점**:
- 사양 변조 방지 — OpenCode가 만든 코드를 사용자가 튜닝할 때 안전한 표면만 노출
- README 표와 1:1 매핑 → documentation drift 최소화
- mutation X → frozen 체크를 추가하면 디버깅 시 명확한 에러

**L 키 다국어 토글 (자기장 시뮬레이터 자체 디자인)**:
magnetic-fields는 앱 내부에 L 키 토글이 빌트인 — `toggleLanguage()` 함수로 UI 라벨을 한국어 ↔ English 즉시 전환. README.en.md는 **fallback / 검색 엔진용 보조 자료**로 의미가 약해짐. L 키가 없으면 README.en.md는 필수, 있으면 보조.

**vs bridge-constructor vs jelly-tetris 비교**:

| 차원 | bridge-constructor | jelly-tetris | magnetic-fields |
|---|---|---|---|
| 외부 의존성 | 1개 (Matter.js CDN) | 0개 (자체 grid) | **0개 (자체 vector field)** |
| 사양 노출 패턴 | inline `const STRESS_THRESHOLD = 0.20` | inline `const GRID_W = 10` | **`const CONFIG = Object.freeze({...})`** |
| 다국어 토글 | ❌ | ❌ | **✅ L 키 빌트인** |
| alias 점유 | `-three.vercel.app` (점유-3) | `-one.vercel.app` (점유-1) | **`magnetic-fields.vercel.app` (미점유)** |
| WT dirty 진입 | 42 PNG 스크린샷 | 5종 부산물 | **0건 (clean)** |
| 풀사이클 학습 가치 | 첫 실전 검증 | 4축 fresh evidence | **CONFIG 패턴 + L 키 토글** |

**판단 기준 (외부 의존성 0개 변형 결정)**:
- OpenCode가 `import` / `<script src="cdn.*">` 0개로 만들었거나, 사용자가 "외부 라이브러리 없이"라고 명시
- 모든 물리/렌더링을 자체 구현한 경우 (벡터장, 충돌, 입자 시스템 등)
- `Object.freeze({...})` 형태로 사양 노출하면 README의 "Customization" 섹션이 자연스러워짐

**shell `[ "$a" = "$b" ]` 비교 false negative 함정 — `wc -c <` multi-file suffix (magnetic-fields → offroad-suspension → optics-prism-lab 3세션 누적, NEW)**:

파일 사이즈가 명확히 같은데 shell 비교가 ✗ 보고하는 함정. **근본 원인**: `wc -c < index.html` 명령이 단일 파일이어도 stdout에 `"<size>  index.html\n     <size> total\n"` 2줄 suffix를 출력함 → shell `$(wc -c < file)` capture가 trailing 라인까지 가져옴. `[ "$remote_size" = "$local_size" ]` 직접 비교 시 자동으로 false.

3세션 모두 동일 패턴 재발:

```bash
# ❌ 함정 1 — wc 단일 redirection
LOCAL=$(wc -c < index.html)        # → "38434 index.html\n   38434 total\n"
[ "$LOCAL" = "38434" ] && echo OK  # → false (trailing lines 포함)

# ❌ 함정 2 — wc 옵션형
LOCAL=$(wc -c index.html)          # → 동일 suffix

# ❌ 함정 3 — [ ] 비교 — leading whitespace / trailing newline
[ "    7445" = "7445" ]           # → false

# ❌ 함정 4 — curl -w trailing newline
REMOTE=$(curl -sS -o /dev/null -w "%{size_download}" URL)
[ -z "$REMOTE" ]                   # → false (정상)

# ✅ 정답 1 — python byte-length 명시 변환 (★★ 권장, 모든 bit-perfect 검증 통일)
python3 -c "
import os, urllib.request
local = os.path.getsize('index.html')
req = urllib.request.Request('URL', headers={'User-Agent':'Mozilla/5.0'})
remote = len(urllib.request.urlopen(req).read())
print(f'local={local} remote={remote} {\"PASS\" if local==remote else \"FAIL\"}')"

# ✅ 정답 2 — awk로 첫 토큰만 추출 (shell-only fallback)
LOCAL=$(wc -c < index.html | awk '{print $1}')
REMOTE=$(curl -sS -o /dev/null -w "%{size_download}" URL)
[[ "$LOCAL" == "$REMOTE" ]] && echo "OK" || echo "FAIL"

# ✅ 정답 3 — strip + 명시 비교 (offroad-suspension 이전 노트)
LOCAL=$(echo "$LOCAL" | tr -d '[:space:]')
REMOTE=$(echo "$REMOTE" | tr -d '[:space:]')
[[ "$LOCAL" == "$REMOTE" ]] && echo "OK"
```

**판단 기준**:
- **모든 bit-perfect 검증은 python `os.path.getsize()` + `urllib` `len(read())` 통일 권장** — shell 변형 함정 4종을 한 번에 우회
- shell-only 제약 시 `awk '{print $1}'` 또는 `tr -d '[:space:]'` 둘 중 하나 (둘 다 적용하면 안전)
- ad-hoc 검증 스크립트 + Phase 7 4축 + post-push fresh evidence **3단 검증** 모두 동일 패턴 사용
- `optics-prism-lab` 3번째 실측 시 `wc -c <` 의 trailing 2줄 suffix가 즉시 원인으로 식별 — **현실적으로 한 번 더 실수할 가능성 100%**. python 권장을 기본값으로 고정

### 7.5.6 cold-start 워크플로 (2026-07-08 heavy-chain-ik 실측, NEW)

코딩미션 부트스트랩에서 가장 자주 막히는 함정 4종은 §1만으론 부족. 다음 cold-start 단계를 항상 차례로 거칠 것:

1. `mkdir -p /Users/mac/work/<project-name>` + `git init -b main` (★ `gh repo create --source=.` 만 실행하면 "current directory is not a git repository" 에러)
2. **HTTPS remote로 시작** (`git remote add origin https://...`) — SSH `git@github.com`은 OpenCode/Hermes 세션에서 known_hosts 자동 로드 안 됨
3. `gh repo create sigco3111/<name> --public --description "..."` (remote URL은 변경하지 않음)
4. README + .gitignore 작성 + `git add ... && git commit && git push -u origin main`
5. **Pages 활성화는 `gh api -X POST repos/{owner}/{repo}/pages -f "source[branch]=main" -f "source[path]=/"`** — `gh repo edit --enable-pages` 옵션은 존재하지 않음
6. **첫 빌드 30~60초 대기** + `sleep 25 → curl → sleep 40 → curl` 재시도. 즉시 curl 시 404
7. 검증: HTTP 200 + `gh api .../pages/builds` → `status: built`

전체 커맨드셋 + 실측 시간표 + HTTPS first 권장 이유 + legacy vs workflow 빌더 비교 + 자주 빠지는 실수 5종은 **`references/coding-mission-bootstrap-cold-start.md` 참조**. 코딩미션 첫 세션에선 이 reference + `coding-mission-bilingual-readme-policy.md` 두 개를 항상 같이 로드.

### 7.5.7 Next.js 풀스택 변형 — OAuth + 안전 가드 + TDD 4대 핵심 패턴 (2026-07-10 sigco3111/toss-trader 4단계 실측, NEW)

변형 4 (Next.js 풀스택)는 변형 1(정적 웹)과 분기점이 명확. **OAuth API relay + 안전 가드 + Telegram confirm + TDD** 4대 핵심 패턴이 변형 1엔 없음. brainstorming에서 "OAuth API 호출", "사용자 인증 토큰", "매수/매도 시뮬레이션", "Telegram 알림"이 등장하면 변형 4.

**4단계 표준 워크플로** (toss-trader에서 검증):

| 단계 | 산출물 | 핵심 패턴 |
|---|---|---|
| 1. 보일러플레이트 | `app/`, `lib/`, `components/`, `package.json`, `tsconfig.json` | Next.js 16 App Router + React 19 + TypeScript + Tailwind v4 + ESLint 9. **`/tmp/scaffold`에 생성 → 파일 선택 복사** (직접 `create-next-app`을 toss-trader에 실행 시 AGENTS.md 등 기존 파일과 충돌) |
| 2. OAuth API relay | `app/api/{api}/[...path]/route.ts` + `lib/{api}.ts` | **catch-all dynamic route** (Next 15+/16에서 `params: Promise<{...}>` async) + `tossFetch<T>()` wrapper (OAuth 토큰 캐시 + 자동 재시도) |
| 3. 안전 가드 + TDD | `lib/safety.ts` + `test/safety.test.ts` | 6대 가드 (TRADING_MODE/AMOUNT/HOURS/ACCOUNT/TELEGRAM/AUDIT) + vitest@4. **`grep`로 결정론적 시간 의존(가드 3 MARKET_HOURS) + in-memory store 격리(`_resetPendingStore()` export)** |
| 4. Telegram confirm + OrderButton | `lib/telegram.ts` + `app/api/telegram/{send,callback}/route.ts` + `components/OrderButton.tsx` | inline button + dev fallback(봇 미설정 시 자동 confirm) + in-memory 콜백 매칭 (Vercel serverless cold start 대응) |

**변형 1 vs 변형 4 결정적 차이 4종**:
- **catch-all dynamic route 필수** — 토스 28개 endpoint를 28개 route.ts로 만들면 ❌. `[...path]` 1개로 모두 relay. 단 Next 15+/16에서 `ctx.params`는 **Promise** (await 필수).
- **OAuth 토큰 캐시 = 모듈 스코프 변수** — Vercel serverless는 cold start마다 모듈 re-eval되지만 같은 warm instance 안에서는 유지. 1시간 TTL 모듈 스코프 `Map`이 정답.
- **DRY_RUN 가드는 2개 레이어** — `lib/toss.ts` (HTTP/422/429 자동 처리) + `lib/safety.ts` (의도/맥락/시간/금액). 변형 1엔 1개 레이어만 있어도 충분.
- **TDD + TOSS 환경변수** — `DRY_RUN=true` 기본값, `telegramConfirmed: true`는 live 모드 + 주문 endpoint에서만 필요. test 셋업에서 env 박지 않으면 paper 모드 = 423 자동 차단 → 통과 검증 시 `telegramConfirmed: true` 추가 필요.

**참조**:
- **`references/nextjs-fullstack-pipeline.md`** — 2026-07-10 sigco3111/toss-trader 4단계 실측. Next.js 16 catch-all dynamic route + OAuth + 안전 가드 + Telegram confirm 통합 패턴.
- **`templates/nextjs-16-app-router-scaffold.md`** — Next.js 16 + React 19 + TypeScript + Tailwind v4 보일러플레이트 (create-next-app@latest @next 16.x / @react 19.x 결과, package.json + tsconfig.json + .gitignore 표준).
- **`references/tossinvest-api-facts.md`** — 토스증권 Open API 사실관계 (28개 endpoint + 5개 카테고리 + 16 rate limit 그룹 + 422 가드 10종 + OAuth Client Credentials). 변형 4 외부 OAuth API의 정식 reference.
- 기존 `references/api-endpoint-verification.md` + `references/tool-name-verification.md` — OAuth API endpoint URL 검증 4단계 + 도구명/패키지명 검증.

**핵심 함정 5종 (변형 4 전용)**:

1. **create-next-app이 toss-trader에 직접 실행 ❌** — `--agents-md` default가 켜져있어 기존 AGENTS.md v0.3 (10310B) 덮어쓸 위험. **`/tmp/scaffold`에 생성 → 파일 선택 복사** 패턴이 안전.
2. **Next.js 15+/16 dynamic route params = `Promise<{...}>`** — 옛 `params: { path: string[] }` 시그니처는 TS 에러. `await ctx.params` 필수.
3. **OAuth 토큰 race (401)** — 캐시 만료 + 401 동시 발생 시 `cachedToken = null; continue;` 1회 재시도 패턴. 2회 이상 재시도는 무한 루프 위험.
4. **DRY_RUN 가드 = toss-trader 코드 내장** — 가드 1~5는 `lib/safety.ts`에 명시. 가드 6(AUDIT log)는 stdout JSON → Vercel log 자동 수집.
5. **Telegram 봇 미설정 = dev fallback** — `TELEGRAM_BOT_TOKEN` 또는 `TELEGRAM_CHAT_ID` 미설정 시 자동 confirm 응답. UI/플로우 검증 가능.

**판단 기준**:
- OAuth API 호출 필요 + 안전 가드 + 사용자 confirm 게이트 + TDD = **변형 4 (Next.js 풀스택)**
- 단순 데이터 시각화 + Vercel 정적 호스팅 = **변형 1 (웹)**
- 키보드/마우스 인터랙티브 시뮬레이션 + macOS GUI = **변형 3 (데스크탑)**
- 외부 플랫폼 SDK (앱인토스/스팀/iOS) = **변형 2 (플랫폼 SDK)**

### 7.5.7 사용자 위임 모드 ("위임할께" 응답 시, 2026-07-07 jelly-tetris Full cycle 실측, NEW)

`clarify`로 사용자에게 "KR README 한/영 혼합 헤딩 어떻게 처리?" 등 batch 결정 어서션을 던질 때, 사용자가 **"위임할께" / "네 마음대로" / "그냥 해"** 식으로 응답하는 패턴이 정형화됨 (코딩미션 2026-07-07 jelly-tetris v1.0 실측).

**위임 모드 워크플로**:
1. **in-page anchor 부재 확인** — `grep -nE '\(#[a-z0-9_-]+\)' README.md README.en.md` 0개면 안전. in-page 링크 안 쓰는 경우 영문 괄호 유지해도 anchor 깨짐이 **외부 영향 0**.
2. **가장 안전한 패턴 1개 추천** — 일반적으로 **(이모지 + 한글 only)** 자동 정규화 (함정 17 §v6.2에서 anchor 깨짐 위험 0). `Tech Stack` (영문 only) 도 안전하지만 sigco3111 표준은 KR 기본 + 이모지 패턴.
3. **자동 batch patch** — `python3` heredoc 또는 patch 도구로 한 번에 처리. README 작성 단계에서 미리 정규화했으면 patch 0회.
4. **단일 commit + push** — README + LICENSE (+ 의도된 `.gitignore`) 묶어서 1커밋. multi-purpose 커밋이 되지만 PR 작은 미션에선 정상.

**보고 의무 (위임 모드에서도)**: 무엇을 자동 결정했는지 짧은 diff 표 (before → after)로 사용자 보고. "KR README 헤딩 7개 patch → 0개 혼합" 식이면 사용자도 동의 가능.

**위임하지 말 것**: GitHub 푸시, Vercel 프로덕션 배포, secret이 노출될 수 있는 액션. **patch + commit 안**의 자동 결정만 위임 가능. 푸시는 명시적 사용자 신호 후.

**다음 Full cycle의 자세한 4-phase 패턴 + anchor slug 안전성 검증 + commit 메시지 형식 + 부록**은 `references/full-cycle-readme-bump-and-deployment.md` 참조 (2026-07-07 jelly-tetris v1.0 실측).

## implementation notes

**GitHub Pages 배포 후 검증:**
- 롤백 감지: `curl -sI "https://{user}.github.io/{repo}/" | grep last-modified` — 날짜가 예상과 다르면 롤백 의심
- 컨텐츠 검증: `curl -s "URL" | grep -c "unique-string"` — 핵심 문자열 존재 확인
- 실패 시: `git log --oneline -5` → 최종 커밋 확인 → 강제 푸시로 복구

**OpenCode 위임 시:**
- `delegate_task` 사용 시 `toolsets: ["terminal", "file"]` 필수
- OpenCode 404/연결 오류 시 직접 구현으로 폴백
- ⚠️ **2026-06-18 검증**: `delegate_task`로 보낸 서브에이전트는 **환경 점검만 하고 종료되는 패턴**이 자주 발생 (web fetch + browser 자동화 미작동, 환경에서 즉시 실패). 직접 `terminal` + `web` toolsets로 직접 작업이 더 빠를 때 많음. **웹 조사/스크래핑 위임은 실패 가능성 높음** — 직접 fetch 권장.

**Canvas 구현 (정적 웹):**
- DPI 대응: `canvas.width = rect.width * 2; ctx.scale(2, 2)`
- 애니메이션: `requestAnimationFrame` + deltaTime
- 반응형: `window.addEventListener('resize', resizeCanvas)`

**데스크탑 pygame 미니앱 구현 (2026-06-23 kiwi — 3대 크래시 + 4대 패턴):**

세 가지 **절대 어기지 말 크래시 함정** (2026-06-23 검증, macOS 15.5 + Python 3.11 + pygame 2.6.1):

1. **NSWindow 메인 스레드 강제 (cocoa 백엔드)** — `pygame.display.set_mode()`는 **메인 스레드**에서만 호출 가능. 별도 스레드에서 호출 시 `pygame.error: NSWindow should only be instantiated on the main thread!` 크래시. 해결: face.py에서 `init_pygame()` + `tick()` + `shutdown()` 메서드만 정의하고 메인 스레드(kiwi.py)에서 호출. LLM/TTS 같은 blocking I/O는 별도 워커 스레드.

2. **`pygame.init()` 전체 init 금지** — 이 함수는 `SDL_INIT_AUDIO`까지 자동 활성화하여 비동기 스레드(AudioQueue, AQConverter, IOThread)를 띄움. pyttsx3(macOS NSSpeechSynthesizer)와 같은 오디오 디바이스를 두고 race condition 일으켜 `EXC_BAD_ACCESS (SIGSEGV)` 크래시. 해결: `pygame.display.init() + pygame.font.init()` 만 명시 호출. `pygame.mixer.init()` 절대 호출 금지.

3. **`pygame.time.Clock()` 사용 금지** — Clock 객체 생성 시 `SDL_TimerThread`가 백그라운드에서 활성화되어 메인 스레드와 race condition 일으킴. 크래시 위치: `event.cpython-311-darwin.so`의 `pg_event_get` → `pgEvent_New` → `PyDict_SetItemString` → `PyDict_SetItem` (offset 3388)에서 NULL+15 포인터 역참조. 해결: 메인 루프에서 `time.sleep(0.005)`로 직접 throttle.

**올바른 pygame 데스크탑 미니앱 패턴 (4대 요소)**:

```python
# face.py — 메인 스레드에서만 호출
class KiwiFace:
    def init_pygame(self) -> bool:
        # mixer/audio/time 명시 init 안 함
        pygame.display.init()
        pygame.font.init()
        self._window = pygame.display.set_mode((W, H))
        # pygame.time.Clock() 안 씀
        return True

    def tick(self) -> bool:
        # 이벤트 + 업데이트 + 그리기
        for event in pygame.event.get():
            if event.type == pygame.QUIT: return False
        self._draw()
        pygame.display.flip()
        return True  # pygame.time.Clock.tick(60) 안 씀

# kiwi.py — 메인 스레드 = pygame 루프
face = KiwiFace()
face.init_pygame()
worker_thread.start()  # LLM/TTS 워커
while face.tick():  # 메인 스레드에서 호출
    time.sleep(0.005)
```

```python
# LLM/TTS는 별도 워커 스레드
import threading, queue
event_queue = queue.Queue()

def llm_worker(user_text):
    result = llm.call(user_text)  # blocking OK
    event_queue.put({"emotion": "happy", "text": result})
    # main thread가 face.set_emotion() 호출

# 메인 루프에서
while face.tick():
    try:
        ev = event_queue.get_nowait()
        if ev["type"] == "emotion":
            face.set_emotion(ev["emotion"])
    except queue.Empty:
        pass
```

**pyttsx3 한국어 음성 선택 (2026-06-23 검증, macOS 15.5)**:
- `pyttsx3` + `pyobjc` (Cocoa 바인딩) 자동 설치
- 177개 음성 중 한국어: `Yuna` (compact, ko-KR, 자연스러움), `Kyung`, `Eloquence` (ko-KR) 계열
- 매칭 우선순위 함수로 Yuna 정확히 매칭 (그냥 `'ko' in voice.id` 같은 단순 substring 매칭은 Eddy 등 다른 음성이 먼저 잡힘)

```python
_KOREAN_KEYS = ("yuna", "kyung", "ko-kr.yuna", "ko_kr.yuna")
def find_korean_voice(engine):
    for keyword in _KOREAN_KEYS:
        for v in engine.getProperty("voices"):
            if keyword == "yuna":
                if v.name == "Yuna" or v.id.endswith(".Yuna") or "ko-kr.yuna" in v.id:
                    return v
            elif keyword in v.name.lower() or keyword in v.id.lower():
                return v
```

**pygame.arc 좌표계 함정 (2026-06-23 학습)**:
- pygame 좌표: 원점 좌상단, y는 아래로 증가, 0=3시, 0.5π=6시(아래), π=9시, 1.5π=12시(위)
- `arc(rect, start, end)`: rect 외접 타원 위의 호를 그림
- **vision이 arc 방향을 일관성 없이 해석** — 같은 `0.15π → 0.85π` 호를 vision이 "위로 볼록"이라고도, "아래로 볼록"이라고도 평가. vision API는 arc 곡선 방향 신뢰도 낮음
- **해결책**: 호 대신 **픽셀 점 직접 그리기** (sin 곡선 따라 21개 점 찍기). vision이 명확하게 인식하고 사용자도 직관적으로 확인 가능

```python
# 호 대신 픽셀 점 (위로 볼록 ∪)
smile_points = []
for i in range(21):
    t = i / 20.0
    x = cx - 55 + int(110 * t)
    y_offset = int(-25 * math.sin(math.pi * t))  # ∪ 모양
    smile_points.append((x, cy + y_offset))
for x, y in smile_points:
    pygame.draw.circle(screen, color, (x, y), 3)
```

**macOS 한자/한글 폰트 깨짐 회피 (2026-06-23 학습)**:
- `pygame.font.SysFont("Apple SD Gothic Neo", 22)` 같은 한글 폰트 이름이 폰트 객체는 로드되지만 실제 glyph가 깨질 수 있음
- **이모지(🥝 😊) 절대 금지** — pygame은 컬러 이모지 글리프 미지원, `□`로 표시
- **해결책**: macOS 폰트 후보 6개 순차 시도 + 실제 한글 glyph 렌더링 테스트
- **라벨 텍스트는 영문만**: `HAPPY`, `SAD`, `THINKING`, `SURPRISED`, `NEUTRAL` (이모지/한글 혼용 X)

```python
for font_name in ["Apple SD Gothic Neo", "AppleGothic", "Helvetica"]:
    f = pygame.font.SysFont(font_name, 20, bold=True)
    test = f.render("HI", True, (0,0,0))
    if test.get_width() > 10:
        font = f
        break
```

**Python 3.8 호환성 (2026-06-23 학습)**:
- 시스템 Python 3.8에서 `int | None`, `list | None`, `dict | None` 같은 PEP 604 union 문법은 `TypeError`
- 해결: `from typing import Optional, List, Dict` 후 `Optional[int]`, `List[Dict]`
- `pygame.Rect`는 `copy()` 메서드 있음, `pygame.Rect.inflate()`로 안쪽 rect 생성 가능
- `pathlib.Path`로 파일 경로 다루면 크로스플랫폼 OK

**conda 환경 분리 (2026-06-23 학습, base pip 깨짐 함정)**:
- 시스템 conda base의 pip이 너무 구버전이라 `pkg_resources` 파싱 실패 (예: `InvalidVersion: '4.0.0-unsupported'`)
- 해결: `conda create -n {env_name} python=3.11` 후 새 환경에 `pip install ...`
- `bash run.sh` 래퍼로 사용자가 conda activate 안 해도 자동 활성화

**platform-sdk 미니앱 구현 (앱인토스 Granite 등):**
- Granite = React Native 기반 (`@granite-js/react-native`)
- 디자인 시스템 = 토스 TDS (Toss Design System) **검수 필수**
- 빌드: `yarn granite build` → `dist/` 폴더에 번들
- 배포: `apps-in-toss.toss.im` 콘솔에서 ZIP 업로드
- AI 도구: `ax mcp start` (AppsInToss eXperience MCP) — Cursor/Claude에서 토스 공식 문서/예제 실시간 조회
  - `search_docs`, `get_doc`, `search_tds_rn_docs`, `get_tds_rn_doc`, `list_examples`, `get_example` 6종 도구
  - 설치: `brew tap toss/tap && brew install ax` 또는 `npm i -g @apps-in-toss/ax`

**7-band / 그 외 분광 확장 패턴 — Implementation Advice로 "R, G, B" 받았을 때 (2026-07-09 optics-prism-lab 실측, NEW)**:

분광/분산/프리즘/무지개 류 미션에서 사용자 Implementation Advice가 **"R, G, B 3색"** 처럼 단순 키 모음을 주면, OpenCode가 그대로 구현해서 "무지개가 아니라 RGB 3색 줄"이 되는 함정이 있음. **3→7 확장 권장**:

```js
// ❌ 3-band (advice 그대로) — 풀 무지개 효과 부족
const RAYS = [
  { name: 'Red',   color: '#ff0000' },
  { name: 'Green', color: '#00ff00' },
  { name: 'Blue',  color: '#0000ff' },
];

// ✅ 7-band ROYGBIV (★ 권장) — optics-prism-lab 실측 검증
const WAVELENGTHS = [
  { name:'Violet',   nm:380, color:'#a17cff' },  // RG 사이 간극 메꿈
  { name:'Indigo',   nm:440, color:'#5b8cff' },
  { name:'Blue',     nm:490, color:'#3ec0ff' },
  { name:'Green',    nm:540, color:'#5dff8a' },
  { name:'Yellow',   nm:580, color:'#ffe25a' },
  { name:'Orange',   nm:610, color:'#ffa658' },
  { name:'Red',      nm:660, color:'#ff5d6c' },
];

// Cauchy 분산 식 (같은 계산 비용으로 임의 N band 지원)
function iorForWavelength(baseN, dispStrength, nm){
  const ref = 660;
  const refSq = ref*ref;
  const delta = (refSq/(nm*nm) - 1);
  const norm = delta / 2.015;  // 0..1 (max at 380nm)
  const MAX_SPREAD = 0.12;     // 4× real glass exaggeration
  return baseN + MAX_SPREAD * dispStrength * norm;
}
```

**판단 기준**:
- Implementation Advice로 "R/G/B" 등 임의 N 색상이 들어오면 → **N+ 4~8 (ROYGBIV 또는 자연 분광) 확장** 기본값
- **이유**: 무지개/분산 시각화에서 RG/Indigo/B/Violet 영역이 비면 "무지개"가 아니라 "RGB 3색 라인"이 됨. ROYGBIV가 광학 교과서 표준이며 시각적 분광 효과 명확
- **성능 영향 0**: Cauchy/Abbe 같은 분산 모델은 한 번의 함수 호출이고 band 수와 무관. 3→7 늘려도 60fps 동일
- **README에 명시 권장**: "왜 7-band 인가" 절을 디자인 결정에 박아 향후 동일 미션에서 advisor가 3-band로 자르는 함정 회피

**optics-prism-lab 실측 결과**:
- 7-band + Cauchy 모델 → 풀 무지개 효과 + README "🧠 동작 원리 — 왜 7-band 인가" 절 명시
- hint 슬라이더(드래그 시 무지개 폭 실시간 변화) — `disp_x100` 50~200 슬라이더로 실제 유리 분산 ↔ 극적 무지개 즉시 전환

**데이터 소스 결정 (정적 시각화 / 미니앱 공통)**:
실세계 데이터 시각화 프로젝트(궤적, 날씨, 주가, 지진 등)는 거의 항상 이 결정이 먼저다. 세 가지 패턴:

| 패턴 | 장점 | 단점 | 적합 시점 |
|---|---|---|---|
| **A. 빌드 시 precompute** — Python/Node로 API 호출 → JSON 커밋 | 정적 호스팅 OK, 클라이언트 부담 0, 결정적 | 데이터 갱신 시 재빌드 필요 | 임의 시점 스냅샷 (NASA JPL Horizons, 과거 주가) |
| **B. 런타임 fetch** — 클라이언트가 공개 API 직접 호출 | 항상 최신, 빌드 단순 | CORS·API 키·rate limit 이슈 | 날씨, 라이브 주가 (API 키 클라이언트 노출 시 B는 부적합) |
| **C. 사전 임베드 + 시뮬레이션** — 임의 시점 데이터 + 클라이언트 보간 | 1개 데이터셋으로 임의 시점 표시 | 계산량·정확도 트레이드오프 | "Artemis II 발사 10일 trajectory" 같이 고정 임무 표시 |

2026-06-11 Artemis 시각화 세션에서는 **A 패턴 채택** — Horizons API에서 발사±10일 ephemeris를 시간 스텝으로 sampling해 `data/trajectory.json` 커밋, Vite 정적 호스팅. 가장 안전·가볍고 결정적.

2026-06-18 앱인토스 챌린지 dongne-today는 **B 패턴 + 무키 API 6종 채택** — Open-Meteo/따릉이/Nager Date를 클라이언트에서 직접 fetch. 챌린지 마감이므로 빌드 시간 줄이는 게 우선.

2026-06-23 kiwi 시뮬레이터는 **B 패턴** (런타임 LLM 호출) + 사용자 PC 로컬 처리 (서버 0).

**WebGL 라이브러리 선택 (정적 웹):**
사용자가 "WebGL + Vite"를 지정하면 후보:
- **Three.js** — 가장 보편적. 광원·카메라 컨트롤·로드러 즉시 사용. AI 키노트 데모 느낌에 가장 가까움. (추천 기본값)
- **regl** — functional WebGL, 더 가벼움, 코드 명시적. 단순 도형·궤적선에 적합.
- **react-three-fiber + drei** — React 선호 시. 컴포넌트 구조.
- **raw WebGL2** — 가장 가벼우면 작업량 多. 특수한 셰이더 효과 필요 시.

Vite + Three.js 보일러플레이트는 `templates/threejs-vite-data-viz.md` 참조 (전체 프로젝트 구조 + 코드 스니펫 + 배포 워크플로 + JSON inline 검증법).

NASA JPL Horizons(실측 천체역학) API로 우주선/행성 ephemeris를 가져오는 절차는 `references/jpl-horizons-api-guide.md` 참조 — `curl -k` SSL 우회, spacecraft ID 검색, 발사/임무 cutoff 시간 처리, km→scene unit 스케일링.

**AI 키노트 데모 미학 (GPT-5.5/Gemini/Claude 발표 페이지 스타일):**
- **배경**: 완전 검정 `#000` 또는 매우 어두운 그라데이션 (`#0a0a14` → `#000`). 별 입자(particle field) 추가하면 "우주적" 인상 ↑.
- **색상 팔레트**: 단일 액센트 (시안 `#00d4ff` 또는 오렌지 `#ff6b35`) + 흰색 텍스트. 무지개 그라데이션 금지.
- **타이포그래피**: 모노스페이스 또는 Inter/Geist Sans. 텍스트는 화면 모서리에 floating, 중앙은 시각화 전용.
- **텔레메트리 오버레이**: 좌상단 = 미션명·시작 시각, 우상단 = 현재 속도/거리/단계. 폰트 작게(12~14px), 반투명.
- **카메라**: 자동 회전 (0.1 rad/s) + 마우스 드래그로 manual override. 너무 빠르지 않게.
- **궤적선**: TubeGeometry 또는 Line2 (fat line), 발광(`emissive` + `emissiveIntensity`)로 빛나는 느낌.
- **포인트 라이트**: 궤적 따라가는 광원 1~2개, 거리 따라 intensity 변동.
상세 노트는 `references/ai-keynote-demo-aesthetics.md`.

**데스크탑 키위/스택챈 스타일 가이드 (2026-06-23 학습):**
- **Stackchan 진짜 외형**: 흰 박스 본체 + 검은 정사각형 디스플레이 + 흰 픽셀 아트 얼굴 + 하단 감정 라벨
- **pygame primitive로 충분히 재현 가능** (PNG 일러스트 안 그려도 됨):
  - 본체: `pygame.draw.rect(screen, white, body_rect, border_radius=20)`
  - 디스플레이: `pygame.draw.rect(screen, black, display_rect, border_radius=12)`
  - 얼굴: 흰색 `pygame.draw.line`/`circle`/픽셀 점
- **감정 5종 픽셀 매핑** (vision 검증 완료):
  - happy: `^ ^` (눈웃음) + `∩` 활짝 웃는 입
  - sad: `; ;` (가로선 + 눈물 점) + `∪` 내려간 입
  - thinking: `--` + `.` (한쪽만 동그라미) + 작은 `—`
  - surprised: `O O` 큰 동그라미 + `O` O자 입
  - neutral: `● ●` 단순 동그라미 + 살짝 미소

**Pitfalls:**
- **정적 시각화 vs LLM 평가 혼동**: "Artemis Challenge", "GPT-X benchmark" 같은 키워드가 나와도 deliverable이 agent 평가 환경이 아닐 수 있음. `clarify`로 1차 분류 후 진행.
- **데스크탑 vs 웹 변형 혼동** (2026-06-23 학습): "시뮬레이터 만들어줘"가 웹 변형 시뮬레이션(브라우저 내)인지 데스크탑 미니앱(pygame)인지 모호하면 **웹 변형으로 가정**하고 시작. "내 PC에서 실행" 등 명시적이면 데스크탑. **데스크탑 의도인데 웹 변형으로 시작하면 시간 낭비 큼**. Stackchan 시뮬레이터는 처음에 App Store(Apple Silicon 전용)로 잘못 추정했다가 Intel Mac 불가능 확인 후 데스크탑 pygame으로 변경 — 이 과정에서 30분+ 낭비.
- **Apple Silicon 전용 App Store 앱 함정** (2026-06-23 학습): M5Stack StackChan World 등 일부 macOS 앱은 App Store에서 Apple Silicon (M1+) 전용. Intel Mac은 설치 자체 불가. `mcp__minimax__web_search`로 "Intel Mac 지원" 명시 확인 후 진행.
- **conda base pip 깨짐 함정** (2026-06-23 학습): 시스템 conda base의 pip이 너무 구버전(`pkg_resources`의 `4.0.0-unsupported` 파싱 실패)이라 신규 패키지 설치 불가. 해결: `conda create -n {env_name} python=3.11` 후 새 환경에 설치. `conda env remove -n {env_name}`로 정리.
- **아이디어 1차 카테고리 함정** (2026-06-18 학습): N빵/정산, 날씨 코디, 약 알림, 계산기 같은 자명한 카테고리는 brainstorming 직후 사용자가 "전부 있는 앱인데..." 거절함. 마켓플레이스/스토어에 이미 포화된 카테고리는 컨셉 자체를 뒤집어야. **SDK 검증 + 흔한 앱 회피**를 step 0의 brainstorming 직전에 항상 거치기.
- **SDK 가능 범위 미검증 아이디어 함정** (2026-06-18 학습): "내 토스 사용 패턴 리포트" 같은 아이디어는 1차적으로 그럴듯해 보이지만 SDK가 결제/송금/자산 내역을 노출하지 않으면 구현 불가. **brainstorming 전에 항상 `0.1 플랫폼 가능 범위 사전 검증` 절차 거치기**. 솔직하게 "기술적으로 불가능" 보고가 거짓 "노력하면 됩니다"보다 낫다.
- **서버 유지비 사용자 거절** (2026-06-18 학습): 사용자가 챌린지/사이드 프로젝트 아이디어에서 서버 의존성을 거절하는 패턴 확인. brainstorming 결정 포인트에 "유지비 구조" 추가하고 **정적 호스팅/클라이언트 처리/무료 티어** 우선 검토.
- **API 키 발급 사용자 거절** (2026-06-18 학습): "서버 0" 다음 단계로 "API 키 0"도 강하게 작용. 사용자가 "키 발급이 필요한 경우 키만료일에 따른 유지보수가 걱정됨"이라고 명시적으로 거절. **무키 공개 API만 사용**하는 게 챌린지/사이드 프로젝트 기본. 검증 절차는 `0.2 데이터 소스 — 무키 우선 검토` + `references/keyless-public-apis.md`.
- **⚠️ BYOK 패턴은 "API 키 0 원칙"의 예외 (2026-07-07 학습, BYOK 게임 세션)**: 모든 BYOK(Bring Your Own Key) 게임/시뮬레이터/AI 통합 앱은 본 원칙에서 제외됩니다. 사용자가 **본인 키를 들고오는 패턴**은 (a) 서버 비용 0, (b) 서버 측 API 키 관리/만료 부담 0, (c) 사용자별 모델 선택 자유라는 3가지 장점이 있어 `canvas-static-site-pipeline`이 다루는 미니앱/시각화 클래스의 강력한 변형입니다. **대표 사례**: BYOK 기반 1인용 AI 통합 게임 — `https://build.nvidia.com/settings/api-keys`에서 사용자가 NIM 키 발급 → 게임 내 BYOK 입력 필드 → 본인이 부담. **판단 기준**: 사용자가 "AI 대체 역사", "LLM NPC", "AI 시뮬레이터" 류 요청을 하면 1차로 BYOK 변형을 검토. 무키로 못 만들겠다는 결정 후에만 "API 키 0" 기본 원칙 적용. **BYOK 구현 시 필수 README 가이드**는 `api-key-manager` 스킬의 "NVIDIA NIM API 키 발급/검증" 섹션 참조 (직행 URL + 핸드폰 인증 + 분당 40회 한도).
- **Vercel 스킬 이름 충돌**: `skill_view(name='vercel')`은 **ambiguous 에러**를 던진다 (devops 본 스킬 + archive 템플릿이 충돌). `skill_view(name='devops/vercel')` 처럼 카테고리 경로 명시. 이 skill 본문에서 `vercel`을 related-skill로 언급할 때도 `'devops/vercel'`로 표기.
- **빌드 명령 누락**: Vite 프로젝트는 `vercel.json`에 `buildCommand: "npm run build"`, `outputDirectory: "dist"` 필수. `canvas-static-site-pipeline` 기본 템플릿(plain HTML)은 빌드 명령 없음 — Vite로 가면 템플릿을 덮어쓴다.
- **CORS 우회 안 됨**: 런타임 fetch 패턴(B)에서 API가 CORS 막으면 백엔드 프록시 필요 → 정적 호스팅 불가. 가능하면 A 패턴 권장.
- **Vite prod JSON import는 minify된 채 inline됨** (2026-06-11 학습): `grep "mission" dist/assets/*.js` 같은 키 검색은 0. 대신 **데이터 패턴**(날짜, 숫자)으로 검증: `grep -c "2026-04-" dist/*.js` → inline 됐다면 644+ 같은 큰 숫자. 0이면 JSON이 external URL fetch로 빠진 것 → 코드에서 `fetch()`로 변경 필요.
- **Vercel 토큰 export 형태** (2026-06-11 학습): `vercel --token $(cat ~/.hermes/secrets/vercel_token.txt)` 한 줄이 가장 짧지만 subshell 안에선 변수 export가 필요. `export VERCEL_TOKEN=*** vercel --token $VERCEL_TOKEN` 패턴. 첫 배포 시 `vercel link --yes`로 프로젝트 연결 후 `vercel deploy --prod`가 안전.
- **`vercel project rm` 옵션 함정** (2026-06-11 학습): `--yes`, `--force`, `-f` 전부 **unknown option** 에러. 정답: `--non-interactive` + `printf "y\n" |` (single stdin). `yes y |`는 무한 stdin으로 60초+ hang. 옵션 확인은 `vercel project rm --help`로 (Global Options: `--non-interactive` 명시). cleanup script는 항상 timeout 또는 single-y stdin으로.
- **Vercel cleanup 후 alias 잔존**: project 삭제해도 alias (production 도메인)는 **자동 삭제되지 않음**. `vercel alias ls`로 잔존 확인 후 `vercel alias rm` 개별 처리. preview alias (UUID 포함된 `xxx-username.vercel.app`)는 보통 deploy와 함께 사라지지만 production alias는 명시적 제거 필요.
- **shell 명령에 `$()` + secret 환경변수 섞으면 break** (2026-06-11 학습): `export VERCEL_TOKEN=*** ~/.hermes/secrets/vercel_token.txt)` 같은 한 줄을 `terminal`/`patch`로 직접 실행하면 `(...)` 부분이 tool output 마스킹 단계에서 깨져서 `syntax error near unexpected token ')'` 에러. 해결: `write_file`로 `.sh` 스크립트 본문 전체를 먼저 쓰고 `chmod +x` → 실행. heredoc 안에서도 동일 문제 발생 — `.sh` 파일이 정답. `HOM...` 같은 환경변수는 write_file 결과도 마스킹되니 주의.
- **`delegate_task` 서브에이전트 환경 점검 실패 패턴** (2026-06-18 학습): web fetch / browser 자동화 미작동으로 서브에이전트가 환경 점검만 하고 즉시 종료하는 패턴 자주 발생. **웹 조사/스크래핑/리서치는 delegate_task 대신 직접 `terminal` + `web` toolsets로 작업**이 더 빠르고 안정적.
- **`index.html` 로컬에만 존재 + GitHub엔 미푸시 함정** (2026-06-29 학습): OpenCode/외부 코딩 에이전트가 워크스페이스에 `index.html`을 생성했지만 `git add` 안 된 상태로 Vercel 배포하면 GitHub엔 README만, Vercel은 빈 페이지가 됨. **반드시 `vercel deploy` 직전에 `git ls-files`로 핵심 자산 추적 확인 + 누락분 사용자 명시 확인 후 푸시**. 외주 도구 산출물(`.codegraph`/`.omo`/`.playwright-mcp`/`.DS_Store`)은 `.gitignore` 등록 필수. 상세 패턴은 `references/opencode-generated-files-pitfalls.md` 참조.
- **패키지 러너는 `npx -y`로 통일 — cron/shell script에서 `bunx` 함정** (2026-06-18 학습): npm CLI 도구를 다른 PC로 핸드오프하는 패키지(`tokscale-setup/scripts/install.sh`, `daily-submit.sh` 등)에 처음에는 `bunx {pkg}@latest ...`로 작성했지만, 사용자가 "크론잡에서 bunx가 동작 안할 수 있다. bunx가 npx 호환이라 npx로 작성해줘. `bunx → npx -y`로 일괄 교체" 라고 명시적으로 거절. Bun 미설치 환경에서는 `bunx` 자체가 PATH에 없어서 `command -v bunx`가 실패하고, Bun이 있어도 cron 환경(매우 제한된 PATH)에서는 `bunx`가 PATH에 잡히지 않을 수 있음. **결론**: 셸 alias/cron script/다른 PC 핸드오프 패키지에서는 **`npx -y`로 통일**이 정답. Bun 설치는 사용자가 명시적으로 선택한 환경일 때만 `bunx` 우선. install 스크립트는 두 runner를 모두 감지해서 fallback 구현: `command -v bunx &> /dev/null && RUNNER=bunx || RUNNER="npx -y"`. 적용 대상: 다른 PC로 전달할 셸 스크립트, `~/.zshrc` alias, crontab 등록 스크립트, AGENTS.md/HANDOFF.md의 모든 예제 명령어.
- **pygame.arc 방향 함정** (2026-06-23 학습): pygame.arc는 좌표계 따라 `0~π`이 위로 호, `π~2π`이 아래 호. vision API가 arc 호 방향을 일관성 없이 해석하는 한계 — 같은 각도 다른 평가. 해결: 호 대신 **픽셀 점을 sin 곡선 따라 직접 그리기**. vision이 명확하게 인식하고 사용자도 직관적.
- **vision이 한글/이모지/특수문자 못 읽음** (2026-06-23 학습): pygame 라벨에 이모지(`🥝 😊`) 넣으면 pygame이 컬러 glyph 미지원으로 `□` 깨짐. vision이 한글이나 한자가 포함된 PNG 분석 시 일부 글자를 `□`로 잘못 인식. **해결**: 라벨은 영문 대문자만 (`HAPPY` 등). 한글이 꼭 필요하면 별도 한국어 폰트 렌더링 검증 후 사용.
- **pygame + pyttsx3 + macOS 오디오 디바이스 race** (2026-06-23 학습): `pygame.init()`은 `SDL_INIT_AUDIO` 자동 활성화 → `AudioQueue`/`AQConverter`/`IOThread` 등 비동기 스레드. pyttsx3 (NSSpeechSynthesizer)와 같은 오디오 디바이스 사용 시 race condition → EXC_BAD_ACCESS 크래시. mixer 사용 안 하더라도 `pygame.init()`만 호출하면 영향. **해결**: `pygame.display.init() + font.init()`만 명시 호출.
- **pygame.time.Clock()의 SDLTimer race** (2026-06-23 학습): Clock 객체 생성 시 `SDL_TimerThread` 활성화. 메인 스레드 Python 인터프리터와 race condition → `event.cpython-311-darwin.so`의 `pg_event_get` → `pgEvent_New` → `PyDict_SetItemString`에서 NULL+15 포인터 역참조로 크래시. **해결**: Clock 안 쓰고 `time.sleep()`으로 throttle.
- **NSWindow 메인 스레드 강제** (2026-06-23 학습): macOS cocoa 백엔드에서 `pygame.display.set_mode()`는 메인 스레드에서만 호출 가능. 별도 스레드에서 호출 시 `pygame.error: NSWindow should only be instantiated on the main thread!` 크래시. **해결**: pygame init/tick은 메인 스레드, LLM/TTS blocking I/O는 워커 스레드.
- **Ad-hoc 검증 스크립트 5대 false positive/negative 함정** (2026-06-29 cyberpunk-globe README 재검증 세션 학습):
  1. **`grep -c`의 false negative** — 카운트가 0일 때 `grep -c`가 `0\n` 형태로 빈 줄 1개를 더 출력 → `[ "$v" = "0" ]` 비교 실패. 해결: `v=$(grep -c PATTERN file || true)` 후 비교.
  2. **SHA 길이 불일치** — `git rev-parse HEAD`는 40자 full, `api.github.com/repos/.../commits/main`의 `sha` 필드는 7자(또는 10자). 비교 시 반드시 `[:10]` 슬라이스 또는 `git rev-parse --short=10` 사용.
  3. **Vercel team-scope URL SSO 302** — `<project>-ndvupa3at-sigco3111s-projects.vercel.app`은 SSO redirect로 정상 302. 검증 스크립트는 production alias (`-pink.vercel.app`)에서만 HTTP 200을 기대하고 team-scope는 200/302 둘 다 PASS 처리.
  4. **함수 패턴 일관성** — 첫 실행에 inline `if [ "$v" = "0" ]` 식으로 5종 섞으면 4~5개 false positive. **두 번째 실행부터 `assert_zero/assert_eq/assert_ge` 3개 함수로 분리**하면 17~20개 모두 PASS.
  5. **GitHub raw 캐시 지연** — `raw.githubusercontent.com` 변경 후 즉시 반영 안 될 수 있음. 검증은 항상 `api.github.com/repos/.../readme` + `base64.b64decode(d['content']).decode()` 패턴으로 직접 가져오기.
  6. **전체 reference**: `references/ad-hoc-verification-self-false-positive.md` (3개 false positive 회피 패턴 A/B/C 권장) + `references/single-html-static-hosting-pitfalls.md` §임시 파일 / 디렉토리 정리 패턴.
- **cronjob script 절대경로 거부 함정** (2026-06-23 학습): `cronjob(action='create', script='...')`는 절대경로(`/Users/...`)와 홈 상대경로(`~/.hermes/scripts/x.py`)를 모두 거부하고 **반드시 `~/.hermes/scripts/` 기준 파일명만** 허용. 에러 메시지: "Script path must be relative to ~/.hermes/scripts/. Got absolute or home-relative path". **해결**: `script='notion_outage_watch.py'` (파일명만). 스킬은 `~/.hermes/scripts/`에 둔다. 다른 위치 스크립트는 symlink 또는 그 위치에 복사. 전체 워치독 패턴은 `references/service-outage-watchdog-pattern.md` 참조.
- **Python 3.8 `tuple[bool, str]` / `int | None` 미지원** (2026-06-23 학습): 시스템 base conda의 Python 3.8은 PEP 604 union 문법(`X | Y`)과 PEP 585 built-in generics(`tuple[...]`, `list[...]`) 미지원 → `TypeError: 'type' object is not subscriptable`. 작업 디렉토리(`/Users/hjshin/.openclaw/workspace`)의 디폴트 인터프리터가 3.8이라 자주 만남. **해결**: `from typing import Tuple, Optional` 후 `Tuple[bool, str]`, `Optional[int]`. 또는 새 conda env (`conda create -n foo python=3.11`)에서 작업. Type hints만 영향 — 일반 `dict`/`list` 사용은 3.8에서도 OK.
- **patch tool mode 인자 누락 → 6회 silent failure (2026-07-09 toss-trader v0.2 실측, NEW)**: 같은 assistant turn에서 `patch` tool을 N>1회 호출할 때, **일부는 silent하게 `mode` 인자를 빠뜨려** `path required` 또는 `old_string and new_string required` 에러를 던짐. 시스템은 `same_tool_failure_warning` count=N으로 신호하지만 **어떤 patch가 빠졌는지 명시 안 함**. toss-trader v0.2 정정에서 6개 patch 1개만 성공 후 5개 fail → 같은 호출에서 silent하게 인자 누락. **해결**: (a) **1 turn = 1 patch**만 호출하거나, (b) N>1 필요 시 `python3 << 'PY'` heredoc으로 한 번에 (`text = p.read_text(); for old,new in mapping: text = text.replace(old,new,1); p.write_text(text)`). (c) 같은 호출에서 1개라도 fail 나면 **즉시 abort + 다른 도구로 우회** (절대 retry 금지). patch tool batch 의존도가 가장 높은 단계 = §7.5.3 헤딩 anchor 깨짐 패치 (10종). pre-defense 11종 패턴 + write_file 통째로 갱신이 더 안정적.
- **변형 4 (Next.js 풀스택) 5대 전용 함정 (2026-07-10 sigco3111/toss-trader 4단계 실측, NEW)**:
  1. **`create-next-app@latest --agents-md` default가 기존 AGENTS.md 덮어쓰기** — Next 16부터 자동 생성. toss-trader처럼 자체 AGENTS.md (10KB+) 있는 프로젝트는 `/tmp/scaffold`에 생성 후 파일 선택 복사. 자세한 패턴은 `templates/nextjs-16-app-router-scaffold.md` §1 참조.
  2. **Next.js 15+/16 dynamic route params = `Promise<{...}>`** — `app/api/{api}/[...path]/route.ts`에서 `ctx.params`는 `await` 필수. 옛 `params: { path: string[] }` 시그니처는 TS 에러.
  3. **OAuth 토큰 race (401) + 무한 재시도 함정** — 캐시 만료 + 401 동시 발생 시 1회 재시도 (`cachedToken = null; continue;`)는 OK. 2회 이상은 무한 루프 위험. `MAX_RETRIES = 3` 상한 명시.
  4. **DRY_RUN + 안전 가드 이중 검사 누락** — `lib/toss.ts`의 5대 HTTP 가드(DRY_RUN/422/429/401/토큰길이)와 `lib/safety.ts`의 6대 의도 가드(TRADING_MODE/AMOUNT/HOURS/ACCOUNT/TELEGRAM/AUDIT)는 **분리 책임**. route 진입점에서 guardRequest() 호출 + 그 다음 tossFetch() 호출. 두 가드 다 통과해야 토스 도달.
  5. **TDD live 모드 테스트 telegramConfirmed 누락** — 가드 5가 order endpoint에 적용되므로 live 모드 통과 검증 시 항상 `telegramConfirmed: true` 박아야 함. 누락 시 자동 차단되어 테스트 fail → 의도와 다름. `references/nextjs-fullstack-pipeline.md` §3.2 참조.

**갤러리 카드 구현 패턴 (정적 HTML):**
- 이미지 3개 고정 너비: `width: 33.33%` flex 레이아웃, 카드마다 이미지 수 동적 대응 필요 시 class based (`one/two/three`)
- **모달 이미지 뷰어**: 클릭 → `openModal(img)` → 카드 내 `.card-img-wrap`에서 전체 이미지 배열 추출 → 좌우 화살표(`navModal`), ESC 키 지원. `data-search` 속성에 검색 키워드 저장
- **접기/펼침 기능**: preview 텍스트만 HTML에 있으면 의미 없음 → 전체 텍스트를 `data-fulllyrics` 속성에 분리 저장 → 클릭 시 모달(`showLyrics`)로 표시. `data-fulllyrics` 없는 카드(가사 없음)는 토글 의미 없음

## related skills
- `devops/vercel` — Vercel 특화 작업 (환경변수, 로그, 프로젝트 관리). **반드시 카테고리 경로 명시** — bare name `'vercel'`은 ambiguous 에러 발생.
- **`references/coding-mission-bilingual-readme-policy.md`** — 2026-07-06 cloth/interactive/falling-sand 3개 미션 누적 학습. Bilingual 3-tier 번역 정책 (verbatim 보존 + 자연 번역 whitelist + KR-only 영역) + 한/영 혼합 헤딩 → anchor 깨짐 정리 6-패치 표준 + bootstrap 5-파일 트리 + 5-tier 검증 어서션 + 자주 빠지는 함정 6종. 코딩미션 README 작성 + bootstrap 검증 시 **반드시 참고**.
- **`references/coding-mission-bootstrap-cold-start.md`** — ★ 2026-07-08 heavy-chain-ik 실측. GitHub 저장소 생성 → README push → GitHub Pages REST API 활성화 → 첫 빌드 30~60초 대기 → HTTP 200 검증까지의 cold-start 워크플로. 함정 4종: (1) `gh repo create --source=.` 는 git repo 아닌 cwd에서 실패, (2) SSH host key 인증 실패 → HTTPS 리모트 전환, (3) `gh repo edit --enable-pages` 옵션 부재 → REST API 직접, (4) 첫 빌드 지연으로 즉시 curl 시 404. 코딩미션 첫 세션에서 §1 보강 + cold-start 워크플로 표준 커맨드셋 + Pages legacy/workflow 빌더 비교.
- `references/full-cycle-readme-bump-and-deployment.md` — ★ 2026-07-07 jelly-tetris Full cycle 실측. **§13 (2026-07-09 추가) ant-colony-optimization 7번째 사례 + push 직전 사용자 BLOCKED 학습 (§13.1) + 2글자 비순차 alias suffix `-nu` 발견 (§13.2) + §11.5 누적 비교표 7번째 행 갱신**. Bootstrap 단계 끝난 프로젝트의 vercel 배포 + README v1.0 bump + workspace dirty 부산물 분리 + 사용자 위임 모드 4-phase. commit + push는 사용자 명시 신호 후 (★ irreversible 단계), deploy + README patch + 검증은 자동 진행.
- `references/single-html-static-hosting-pitfalls.md` — **2026-06-29 cyberpunk-globe 세션 학습** — 단일 HTML + Vercel 정적 호스팅 + CDN ES module 패턴의 5대 함정 (boot veil 무한 로딩, dynamic import+es-module-shims 충돌, Google Fonts 동기 로드, visibility 미변경, OpenCode 풀 자동 위임 silent 실패). 다음 단일 HTML 시각화 작업 시 반드시 참고.
- **`references/build-tmp-inlined-pitfall.md`** — ★ 2026-07-08 voronoi-glass-fracture 5번째 실측. `index.html`은 self-contained 인라인 단일 HTML로 보이지만, 같은 프로젝트의 `build.js`가 `/tmp/<name>-deps/` 같은 휘발성 디렉토리에서 의존성을 합치는 구조의 함정. Vercel 배포 전 grep 5종으로 self-contained 검증.
- **`references/tool-name-verification.md`** — ★ 2026-07-09 sigco3111/toss-trader 실측 (`oh-my-openagent` ≠ `oh-my-opencode`). 도구명/패키지명을 README/AGENTS.md/SKILL.md에 박기 전 `bunx <pkg> --version` + `npm view` + 사용자 확인 신호 1회 필수. 16곳 잘못 박고 14 patch로 복구한 사고 회피.
- **`references/api-endpoint-verification.md`** — ★ 2026-07-09 sigco3111/toss-trader 실측 (kstost/stock의 `openapi.tossinvest.com` 404). 외부 API endpoint URL 검증 4단계: ①도메인 200 OK 확인 ②`/llms.txt` 시도 (LLM 친화 마크다운) ③OpenAPI spec 직접 fetch (`/openapi-docs/latest/openapi.json`) ④OAuth `scopes: {}` 정밀 확인. SPA 기반 현대 docs는 `/llms.txt`가 source of truth인 경우 많음.
- **`references/tossinvest-api-facts.md`** — ★ 2026-07-09 sigco3111/toss-trader. 토스증권 Open API 사실관계 뱅크 (endpoint, OAuth, 발급 자격, 422 가드, rate limit, 21개 endpoint 분류). sigco3111 동일 카테고리 작업 시 단일 권위 출처. kstost/stock + BEOKS/tossinvest-skill + JungHoonGhae/tossinvest-cli + 공식 overview.md 4중 교차 검증.
- **`references/nextjs-fullstack-pipeline.md`** — ★ 2026-07-10 sigco3111/toss-trader 4단계 실측 추가. Next.js 풀스택 변형 4대 패턴 (catch-all dynamic route + OAuth 토큰 캐시 + 6대 안전 가드 + Telegram inline button confirm) + vitest TDD 결정론적 시간 주입 + module-scope store 격리 (`_resetPendingStore()` export 패턴) + dev fallback 자동 confirm. 변형 4 진입 시 첫 번째 reference.
- **`templates/nextjs-16-app-router-scaffold.md`** — ★ 2026-07-10 추가. Next.js 16.2.10 + React 19.2.4 + TypeScript 5 + Tailwind v4 + ESLint 9 보일러플레이트. `create-next-app@latest` 비대화형 명령 + `/tmp/scaffold`에 생성 후 파일 선택 복사 패턴 (직접 실행 시 기존 AGENTS.md 덮어쓰기 함정 회피) + `.gitignore` 표준 (Next.js + toss-trader 시크릿 격리 병합).
- `references/opencode-generated-files-pitfalls.md` — **2026-06-29 neon-fluid 세션 학습** — OpenCode/외주 도구가 워크스페이스에 만든 `index.html`이 Git에 추적 안 된 채 Vercel 배포되는 함정, 외부 도구 산출물(`.codegraph`/`.omo`/`.playwright-mcp`/`.DS_Store`)의 `.gitignore` 처리 패턴, `vercel deploy --yes`의 자동 GitHub 연결 동작, workspace ≠ Git 디렉토리 불일치. Vercel 배포 전 체크리스트 포함.
- `references/repolis-fork-pages-workflow.md` — **Repolis fork 실전 워크플로** (2026-06-23): Phase 0 스캔 → 결정 4개 → 백엔드 OSS 부트스트랩 → 빌더 단순화 → GitHub Pages REST API 직접 활성화 → 6시간 cron + workflow_dispatch 듀얼 → 검증 6항목. 빌더 단순화 vs 어댑터 결정 프레임 + 잘라낸 기능 큐 포함.
- `github/github-cli` — GitHub 저장소 관리
- `autonomous-ai-agents/opencode` — 코딩 에이전트 위임 (실패 시 이 파이프라인으로 폴백)
- `automation/python-oss-bootstrap` — Python OSS 부트스트랩 패턴 (Phase 0 "다른 PC 변형"은 범용, 그 외는 Python 전용이지만 디렉토리 구조/문서 패턴 차용 가능)
- `creative/manim-video-with-narration` — 비주얼 데모 영상 제작 (stackchan 시뮬레이터 데모 영상 만들 때 활용 가능)
- `apple` — macOS 특화 작업 (TTS, AppleScript, 등)
- `templates/coding-mission-readme-kr-header.md` — **신규 sigco3111 코딩미션 부트스트랩 시 베껴 쓸 한국어 README 템플릿** (11종 정규화 헤딩 풀사이클판 A + 7종 compressed bootstrap판 B + 두 어서션 검증 oneliner C + 영문 혼합 괄호 회피 리스트 D + 적용 사례 E). 본 스킬 §7.5.3.1.1의 "사전 방어 + 두 어서션 검증" 패턴을 코딩미션 1차 단계에서 자동 적용. 다음 미션에서 README 작성 전 read_file로 베껴서 시작하면 patch 0회 default.
