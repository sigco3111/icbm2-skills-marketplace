---
name: canvas-static-site-pipeline
description: 단일 페이지 정적 웹 프로젝트 End-to-End 파이프라인 — 컨셉 → GitHub 저장소 생성 → HTML/CSS/JS 구현 → Vercel 배포. Canvas API, D3.js, Three.js, p5.js 등 브라우저 기반 시각화/시뮬레이터에 최적화.
category: devops
tags:
  - static-site
  - canvas
  - vercel
  - github
  - simulation
  - visualization
  - educational
when to use: >
  사용자가 새로운 웹 앱/시뮬레이터/시각화 프로젝트 요청 시.
  "저장소 생성하고 Vercel로 배포해줘" 계열의 요청.
  Canvas API, 순수 JavaScript 기반 인터랙티브 앱 제작.
---

# canvas-static-site-pipeline

## steps

### 1. 저장소 생성
```bash
gh repo create {project-name} --public --clone
mkdir -p ~/Desktop/project/work/ai/{project-name}
```

### 2. 프로젝트 구현
파일 구성:
```
/index.html    - 메인 HTML
/styles.css    - 스타일시트
/app.js        - Canvas/애니메이션 로직
/vercel.json   - Vercel 설정 (정적 사이트)
/README.md     - 한국어 프로젝트 설명
```

`vercel.json` 템플릿:
```json
{
  "buildCommand": null,
  "outputDirectory": ".",
  "installCommand": null,
  "framework": null,
  "rewrites": [{ "source": "/(.*)", "destination": "/index.html" }]
}
```

### 3. GitHub 푸시
```bash
cd ~/Desktop/project/work/ai/{project-name}
git init
git remote add origin https://github.com/sigco3111/{project-name}.git
git add -A
git commit -m "{이모지} {프로젝트명} - {한 줄 설명}"
git branch -M main
git push -u origin main
```

### 4. Vercel 배포
```bash
vercel --yes --prod --token $(cat ~/.hermes/secrets/vercel_token.txt)
```

### 5. 결과 보고
- GitHub 저장소 URL
- 라이브 Vercel URL
- 구현된 기능 목록

## implementation notes

**OpenCode 위임 시:**
- `delegate_task` 사용 시 `toolsets: ["terminal", "file"]` 필수
- OpenCode 404/연결 오류 시 직접 구현으로 폴백

**Canvas 구현:**
- DPI 대응: `canvas.width = rect.width * 2; ctx.scale(2, 2)`
- 애니메이션: `requestAnimationFrame` + deltaTime
- 반응형: `window.addEventListener('resize', resizeCanvas)`

## related skills
- `vercel` — Vercel 특화 작업 (환경변수, 로그, 프로젝트 관리)
- `github-repo-management` — GitHub 저장소 관리
- `opencode` — 코딩 에이전트 위임 (실패 시 이 파이프라인으로 폴백)
