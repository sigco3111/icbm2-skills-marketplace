# JPL Horizons API 가이드 — NASA 우주선/행성 ephemeris

> 2026-06-11 Artemis II 시각화 세션에서 검증된 실전 절차. 비공개 API 키 불필요, 무료, NASA JPL Solar System Dynamics 그룹 운영.

## 언제 쓰나

- NASA 우주선 trajectory 시각화 (Artemis, Voyager, ISS 등)
- 행성·달·태양 ephemeris 데이터 (DE441 ephemeris 기반)
- 임무 시뮬레이션용 위치/속도 벡터
- "발표 데모"급 우주 미션 시각화

## API 기본

**Base URL**: `https://ssd.jpl.nasa.gov/api/horizons.api`
**Method**: GET (text 또는 JSON 응답)
**Auth**: 없음
**SSL**: 자체서명 인증서 → Python `urlopen` 실패, **`curl -k` 필수**

## 🚨 Critical Pitfall 1: 자체서명 SSL

```bash
# Python은 cert chain 검증 실패로 hang
python3 -c "import urllib.request; urllib.request.urlopen('https://ssd.jpl.nasa.gov/api/horizons.api?...')"
# → SSL: CERTIFICATE_VERIFY_FAILED

# 해결: curl -k
curl -sk "https://ssd.jpl.nasa.gov/api/horizons.api?..." -o out.txt
```

macOS 시스템 Python 3.8도 영향 있음. `astroquery` 미설치 환경에선 curl 직접이 정답.

## Spacecraft / 천체 ID 검색

Horizons ID는 직관적이지 않음. `"Orion"` 같은 이름으로 검색하면 매칭 리스트가 먼저 나옴:

```bash
curl -sk "https://ssd.jpl.nasa.gov/api/horizons.api?format=text&COMMAND=%27Orion%27&OBJ_DATA=%27NO%27&MAKE_EPHEM=%27YES%27" -o /tmp/h_orion.txt
head -40 /tmp/h_orion.txt
```

**Artemis II 실제 응답 (2026-06-11)**:
```
Multiple major-bodies match string "ORION*"
  ID#      Name                               Designation  IAU/aliases/other
  -------  ---------------------------------- -----------  -------------------
    -1023  Artemis 1 (spacecraft)             2022-156A    Orion EM-1
    -1024  Artemis II (spacecraft)            2026-069A    Integrity Orion EM-2
```

→ **Artemis II = `-1024`**, **Artemis I = `-1023`**

다른 자주 쓰는 ID:
- Moon: `301`
- Sun: `10`
- Mars: `499`
- ISS: `-125244` (NORAD ID 25544의 음수)

## 핵심 파라미터 (실전 세트)

```bash
curl -sk "https://ssd.jpl.nasa.gov/api/horizons.api?format=text&\
COMMAND=%27-1024%27&\
OBJ_DATA=%27NO%27&\
MAKE_EPHEM=%27YES%27&\
EPHEM_TYPE=%27VECTORS%27&\
CENTER=%27500%27&\
START_TIME=%272026-04-02%2002:00%27&\
STOP_TIME=%272026-04-10%2023:54%27&\
STEP_SIZE=%271%20h%27&\
CSV_FORMAT=%27YES%27&\
VEC_TABLE=%272%27&\
VEC_CORR=%27NONE%27&\
OUT_UNITS=%27KM-S%27" -o /tmp/orion.txt
```

| 파라미터 | 의미 | 실전 값 |
|---|---|---|
| `COMMAND` | 우주선/천체 ID | `'-1024'` (Artemis II) |
| `EPHEM_TYPE` | 출력 형식 | `'VECTORS'` (xyz+vxvyvz) / `'OBSERVER'` (지상 관측자) / `'ELEMENTS'` (궤도 요소) |
| `CENTER` | 좌표 원점 | `'500'` (태양) / `'399'` (지구) / `'@399'` (지구 표면 site) / `'-1024'` (spacecraft-relative) |
| `START_TIME` / `STOP_TIME` | ISO 8601-ish | `'2026-04-02 02:00'` |
| `STEP_SIZE` | 샘플 간격 | `'1 h'`, `'30 m'`, `'1 d'` |
| `CSV_FORMAT` | CSV 출력 | `'YES'` (파싱 쉬움) |
| `VEC_TABLE` | 벡터 형식 | `'2'` (state vector x,y,z, vx,vy,vz) / `'1'` (position only) |
| `VEC_CORR` | 보정 | `'NONE'`, `'LT'` (light-time), `'LT+S'` (lt + stellar aberration) |
| `OUT_UNITS` | 단위 | `'KM-S'`, `'AU-D'` (천문단위/일) |

## 🚨 Critical Pitfall 2: 발사/임무 cutoff

**Spacecraft는 발사 전 ephemeris가 없음.** 잘못된 시간 범위 → 빈 응답 (HTTP 200, 5 lines, "No ephemeris..."):

```bash
# Artems II는 2026-04-01 발사, 2026-04-02 01:58 UT까지 cutoff 메시지
# "No ephemeris for target ... prior to A.D. 2026-APR-02 01:58:32.3050 TDB"
# → START_TIME을 01:59 이후로 조정

# 동시에 임무 끝 cutoff도 있음 (재진입 시점)
# "No ephemeris for target ... after A.D. 2026-APR-10 23:54:22.8576 TDB"
# → STOP_TIME을 그 이전으로
```

**절차**:
1. Wide range로 호출
2. 응답에서 cutoff 시각 추출
3. START_TIME/STOP_TIME을 cutoff 내로 좁힘
4. 다시 호출 → 200+ lines, `$$SOE` ~ `$$EOE` 블록

## 응답 파싱

CSV 모드 응답 구조:

```
API VERSION: 1.2
API SOURCE: NASA/JPL Horizons API
...
$$SOE
2461132.583333333, A.D. 2026-Apr-02 02:00:00.0000, -2.460259791031141E+04, -1.466164717271550E+04, ..., 1.807002964285140E+00, -3.851912040453985E+00, -3.344134326180390E-01,
2461132.625000000, A.D. 2026-Apr-02 03:00:00.0000, ...
$$EOE
```

**Python 파서** (실전 검증됨):

```python
import re, json
from datetime import datetime

def parse_horizons(path):
    with open(path) as f:
        text = f.read()
    m = re.search(r'\$\$SOE\n(.*?)\n\$\$EOE', text, re.DOTALL)
    body = m.group(1)
    rows = []
    for line in body.strip().split('\n'):
        parts = [p.strip() for p in line.split(',')]
        jd = float(parts[0])
        cal = parts[1].strip()
        x, y, z = float(parts[2]), float(parts[3]), float(parts[4])
        vx, vy, vz = float(parts[5]), float(parts[6]), float(parts[7])
        date_str = cal.replace('A.D. ', '').strip()
        dt = datetime.strptime(date_str, '%Y-%b-%d %H:%M:%S.%f')
        iso = dt.strftime('%Y-%m-%dT%H:%M:%SZ')
        rows.append({"jd": jd, "iso": iso, "pos": [x, y, z], "vel": [vx, vy, vz]})
    return rows
```

## 시각화 스케일링 (Three.js)

문제: Sun은 1.496e8 km, Orion은 발사 직후 2.4e4 km, Moon은 3.8e5 km. **4~5 자릿수 스케일 차이**.

**실전 패턴 (2026-06-11 Artemis II 세션)**:

```js
// 1 scene unit = 1e-6 km (전체 1e-6 압축)
const SCALE = 1e-6;
// Sun만 추가로 1e-4 더 압축 (150 unit 안쪽으로)
const SUN_SCALE = 1e-4;

// 시각적 body sizes는 schematic (비례 X)
const EARTH_R = 1.2;
const MOON_R = 0.45;
const SUN_R = 4.0;
const ORION_R = 0.18;
```

```js
for (const key of ["orion", "moon", "sun"]) {
  for (const p of trajectory.bodies[key]) {
    const sx = p.pos[0] * SCALE;
    const sy = p.pos[1] * SCALE;
    const sz = p.pos[2] * SCALE * SUN_SCALE; // Sun만 추가 압축
    // ...
  }
}
```

**Tradeoff**: 궤적 비율이 정확하지는 않지만, 한 화면에 모든 body가 보이고 "발표 데모" 가독성 확보. **시각화 우선 / 정확도 후순위**일 때만.

더 정확하게 하려면: 카메라를 3개 (전체 / 지구-달 / spacecraft)로 토글.

## 다른 접근: Skyfield (Python)

`pip install skyfield` 후 JPL ephemeris 직접 사용 (네트워크 호출 1회 후 로컬 계산):

```python
from skyfield.api import load
ts = load.timescale()
t = ts.utc(2026, 4, 2, 2, 0, 0)
eph = load('de421.bsp')  # 17MB, 1회 다운로드
earth = eph['earth']
moon = eph['moon']
astrometric = earth.at(t).observe(moon)
ra, dec, dist = astrometric.radec()
print(dist.km)
```

장점: API rate limit 없음, 임의 시점 계산, sub-second step 가능.
단점: spacecraft는 SPK 파일 별도 (NAIF에서 수동 다운로드), 초기 설정 1~2분.

## 비용 / rate limit

- **무료**, 인증 없음
- Implicit rate limit: 연속 호출 시 throttle 가능 (정확한 수치 모름, 1 req/sec 정도는 안전)
- **Best practice**: cutoff 범위 정확히 알아낸 후 단일 큰 요청

## 실전 체크리스트

```markdown
- [ ] curl -k 옵션 사용
- [ ] COMMAND ID 검색으로 정확한 값 확인
- [ ] Wide range → cutoff 시각 추출 → 좁힌 range로 재요청
- [ ] CSV_FORMAT=YES, VEC_TABLE=2, VEC_CORR=NONE, OUT_UNITS=KM-S
- [ ] $$SOE ~ $$EOE 블록 검증 (200+ lines)
- [ ] JSON 변환 시 iso 날짜 형식 통일 (UTC 'Z' suffix)
- [ ] Three.js에서 SCALE + SUN_SCALE 2단 압축
- [ ] 빌드 시 JSON이 inline 됐는지 grep -c "YYYY-MM-" dist/*.js로 검증
```

## 참고 자료

- API 공식 문서: https://ssd-api.jpl.nasa.gov/doc/horizons.html
- Telnet 인터페이스 (legacy): `telnet ssd.jpl.nasa.gov 6775`
- Web UI: https://ssd.jpl.nasa.gov/horizons/app.html#/
- JPL SSD email list: https://ssd.jpl.nasa.gov/email_list.html
