# 도구명/패키지명 1차 실측 원칙 (2026-07-09 oh-my-openagent ↔ oh-my-opencode 실측 학습)

> README/AGENTS.md/SKILL.md 같은 문서에 도구명(`bunx <pkg>`, `npm i <pkg>`, `pip install <pkg>`, CLI sigil path 등)을 박기 전에 **반드시 1차 실측으로 검증**해야 한다는 2026-07-09 학습. sigco3111/toss-trader 1차 스캐폴드에서 `oh-my-openagent` (제가 추측) vs 실제 `oh-my-opencode` (bunx v4.16.0, OpenCode 플러그인) — 16곳을 한꺼번에 잘못 박음.

## 1. 함정 — 이름 추측으로 박으면 어떻게 되는가

**실측 사례 (2026-07-09, sigco3111/toss-trader)**:

| 내가 박은 것 | 실제 | 결과 |
|---|---|---|
| `oh-my-openagent` (agent) | `oh-my-opencode` (opencode) | 한 글자 차이. 16곳 잘못 박음 |
| "sigil `~/.local/bin/oh-my-openagent`" | `bunx oh-my-opencode` (v4.16.0+, OpenCode 플러그인) | sigil 존재하지 않음. 호출 방식 자체 틀림 |
| "`oh-my-openagent` v4.16.0+" | "`bunx oh-my-opencode` v4.16.0+" | 사용자분이 "Codex CLI 쓸 거임?" 이라고 물어봐서 발견 |

**원인 3가지**:

| 원인 | 본 세션 사례 |
|---|---|
| 단어 자체가 흔해서 그럴듯한 이름으로 착각 | "openagent" vs "opencode" |
| sigil vs 패키지 혼동 | sigco3111 다른 환경엔 sigil이 있을 수 있지만 이 환경엔 `bunx`만 |
| plugin vs standalone binary 혼동 | `oh-my-opencode`는 OpenCode 플러그인이지 standalone 아님 |

## 2. 검증 5단계 (30초 이내)

### 2.1 패키지 후보 둘 다 검색 (sub-string vs full match)

```bash
# 1) bunx로 직접 호출 — 가장 권위 있는 검증
bunx <pkg> --version
# → vX.Y.Z (성공) 또는 "command not found" (실패)

# 2) npm registry로 정확한 이름 확인
npm view <pkg> name version description 2>&1
# → name: "<exact-name>" version: "X.Y.Z"

# 3) 사용자 환경에 이미 설치된 게 있는가
ls ~/.local/bin/<pkg> 2>&1 || echo "❌ sigil 없음"
which <pkg> 2>&1 || echo "❌ PATH에 없음"

# 4) 글로벌 npm 패키지 확인
npm ls -g --depth=0 2>&1 | grep -i <pkg>

# 5) bun 글로벌 패키지 확인
bun pm ls -g 2>&1 | grep -i <pkg>
```

### 2.2 호출 방식 결정

| 사용자 보고 | 의미 | 박아야 할 것 |
|---|---|---|
| "`bun install <pkg>@latest` 했음" | `bun` 패키지 매니저 사용. 호출은 `bunx <pkg>` | `bunx <pkg> --help` |
| "`npm i -g <pkg>` 했음" | npm 글로벌. 호출은 sigil 또는 `npx <pkg>` | `npx <pkg>` 또는 `~/.npm-global/bin/<pkg>` |
| "Homebrew로 설치했음" | `/opt/homebrew/bin/<pkg>` | `which <pkg>` 결과 그대로 |
| "직접 빌드했음" | `~/path/to/<pkg>` | 절대경로 |

### 2.3 README/AGENTS.md 박기 전 체크리스트

```text
□ bunx/npm view로 정확한 패키지명 확인
□ bunx <pkg> --version 으로 실제 설치 + 버전 확인
□ bunx <pkg> --help 로 서브커맨드 5종 이상 확인
□ 호출 방식 (sigil/bunx/npx/절대경로) 결정
□ README에 박을 명령어 1개 직접 실행 (3초 안에 정상 응답하는지)
```

### 2.4 사용자 확인 신호

**도구명이 흔한 단어(openagent, opencode, agent, codex, claude, copilot, gemini, gpt 등)인 경우** — 사용자분에게 한 번 더 확인:

> "실제 설치하신 게 `oh-my-openagent` 맞아요? 아니면 `oh-my-opencode`나 다른 이름인가요? `bun pm ls -g` 결과를 알려주시면 README에 정확히 박을게요."

이 확인 신호 1번이면 **16곳 잘못 박고 다시 패치하는 사고를 100% 방지** 가능.

## 3. SKILL.md / README에 박을 때 형식

정확한 패키지명 + 정확한 호출 방식 + 검증된 버전 — **세 가지 모두 박기**:

```markdown
- **분석 엔진**: `oh-my-opencode` (`bunx oh-my-opencode` v4.16.0+, OpenCode 플러그인)
```

❌ 잘못된 형식:
```markdown
- **분석 엔진**: `oh-my-openagent` CLI (sigil `~/.local/bin/oh-my-openagent`)
```

차이점: 정확한 박기는 **호출 방식 + 버전 + 정체** 세 가지가 한 줄에 들어감. 사용자분이 한 번에 검증 가능.

## 4. 자주 빠지는 실수 4가지

| 실수 | 결과 | 해결 |
|---|---|---|
| 사용자분 말을 추측으로 보정 ("OpenCode니까 ~") | 다른 단어로 잘못 박음 | §2.4 사용자 확인 신호 |
| sigil 있다고 단정 ("~/.local/bin/X") | 실제론 bunx/npx | §2.2 호출 방식 결정 |
| 패키지명 vs sigil 이름 혼동 | 사용자 환경엔 둘 중 하나만 있을 수 있음 | 둘 다 검색 |
| "v4.16.0+" 같은 버전 박기 (정확한 버전 모를 때) | 사용자 환경이 다른 버전이면 명령어 안 맞음 | §2.1 `bunx <pkg> --version`으로 실측 |

## 5. 검증 oneliner (도구명 박기 직전 자동 실행)

```bash
# 박으려는 도구 1개당 이 oneliner 1회 실행
PKG="<pkg>"
echo "=== bunx ===" && bunx "$PKG" --version 2>&1 | head -3
echo "=== npm view ===" && npm view "$PKG" name version 2>&1 | head -3
echo "=== bun pm ls -g ===" && bun pm ls -g 2>&1 | grep -i "$PKG" | head -3
```

세 출력 비교:
- bunx 정상 → bunx로 박기
- npm view 정상 → npx/npm install 가이드 박기
- 둘 다 실패 → ❌ 그 도구는 사용 불가. 다른 후보 제시

## 6. 적용 시점

- **새 외부 도구를 우리 프로젝트에 통합할 때** — README에 박기 직전 §2 5단계 필수
- **다른 리포를 fork/reference할 때** — 그 리포의 의존성 명령어가 우리 환경에서 작동하는지 확인
- **사용자가 "X 설치했음 / Y 쓸 거임" 보고할 때** — 추측 박지 말고 §5 oneliner 1회
- **메모리에 도구명 박을 때** — 정확성 검증 안 된 단어는 박지 말 것. 차라리 "bunx로 실측 후 박기" 원칙만 박기

## 7. 한 줄 원칙

> **"도구명은 README 박기 전 `bunx <pkg> --version` 한 번, 아니면 사용자 확인 한 번."**