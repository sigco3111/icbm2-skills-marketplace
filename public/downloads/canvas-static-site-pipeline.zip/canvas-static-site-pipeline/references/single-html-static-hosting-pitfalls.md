# Single-HTML Static Hosting Deployment Pitfalls

> 2026-06-29 cyberpunk-globe 세션에서 학습한 함정 모음. 단일 HTML + Vercel/GitHub Pages 정적 호스팅 + CDN ES module 패턴 사용 시 반드시 고려.

## 🚨 가장 치명적인 함정 6가지

### 1. ES module 정적 import 실패 → boot veil 무한 로딩

ES module `<script type="module">` 안에서 `import * as THREE from 'three'` 같은 정적 import가 실패하면:
- 브라우저는 콘솔에 에러만 찍고 page는 멈춤
- boot veil이 절대 hide되지 않음 (사용자 입장에선 "무한 로딩")
- `<script>` 외부에서 `window.onerror`로도 잡힘

**해결 패턴 (3가지 안전망 누적)**:
```html
<head>
  <script type="importmap">{ "imports": { "three": "https://unpkg.com/three@0.160.0/build/three.module.js" } }</script>

  <!-- 1) 5초 safety: JS가 어떤 이유로든 tick()을 못 불러도 boot veil 강제 제거 -->
  <script>
    function killBoot(reason, msg) {
      var b = document.getElementById('boot');
      if (!b || b.classList.contains('hidden')) return;
      if (msg) {
        var e = document.getElementById('boot-err');
        if (e) { e.style.display = 'block'; e.textContent = '[ERROR] ' + msg; }
      }
      b.classList.add('hidden');
    }
    window.__bootSafetyTimer = setTimeout(function () {
      killBoot('5s safety', 'Loading timeout — 모듈 로드 실패 가능성 (CDN/네트워크 확인)');
    }, 5000);

    // 2) window.error 핸들러 — 어떤 에러가 발생해도 boot은 반드시 제거
    window.addEventListener('error', function (e) {
      killBoot('window.error', e.message);
    });
    window.addEventListener('unhandledrejection', function (e) {
      var msg = (e.reason && (e.reason.message || e.reason.toString())) || 'Promise rejection';
      killBoot('unhandledrejection', msg);
    });
  </script>
</head>
<body>
  <div id="boot">
    <div class="ring"></div>
    <p>BOOTING · NEON GRID</p>
    <pre id="boot-err" style="display:none"></pre>  <!-- 에러 표시 영역 -->
  </div>

  <script type="module">
    import * as THREE from 'three';
    // import 성공 → safety timer cancel
    console.log('[globe] modules loaded, version:', THREE.REVISION);

    try {
      tick();
      requestAnimationFrame(() => hideBoot());
    } catch (err) {
      hideBoot();
      document.getElementById('boot-err').textContent = err.message;
    }
  </script>
</body>
```

### 2. dynamic import + es-module-shims 폴리필 충돌

`<script type="module">` 내부에서 `await import('three')` 같은 dynamic import를 쓰면서 **동시에** `<script src="es-module-shims.js">` 폴리필을 추가하면:
- es-module-shims가 dynamic import를 가로채면서 일부 환경에서 namespace 누락
- 결과: `THREE.Scene` 같은 접근은 가능하지만 addon의 enum 값이 undefined
- **더 큰 문제**: dynamic import를 `async function bootGlobe()` 안에 넣고 `bootGlobe()`를 await 없이 호출하면 silent throw 가능

**최선 해결**: dynamic import + es-module-shims 폴리필 **둘 다 제거**. 정적 import + 네이티브 importmap만 사용.

**왜 정적 import가 더 안정적인가**:
- 모듈 평가 시점에 모든 의존성이 해결됨 → 후속 코드에서 enum 누락 가능성 0
- es-module-shims는 2026년 모던 브라우저에서 **불필요**:
  - Chrome 89+ (2021)
  - Safari 16.4+ (2023)
  - Firefox 108+ (2022)
- bootGlobe() async 래퍼가 불필요해지면서 silent throw 가능성도 사라짐

### 3. async bootGlobe() 래퍼가 만드는 silent throw 가능성

모든 코드를 `async function bootGlobe() { ... }` 안에 넣고 `bootGlobe()` 호출은 await 없이 하면:
- 함수 안에서 throw 발생 시 호출자는 promise rejection을 받지만 throw 위치 추적 어려움
- 일부 브라우저에서 importmap namespace와 dynamic import의 매핑이 비동기 컨텍스트에서 깨질 수 있음

**해결**: 코드를 평탄하게 module body에 직접 작성. try/catch는 tick() 호출에만:
```js
// ❌ 이렇게 하지 말 것
async function bootGlobe() {
  let THREE, OrbitControls;
  try {
    THREE = await import('three');
  } catch (err) { ... }
  // 모든 코드가 여기 안에
}
bootGlobe();

// ✅ 이렇게
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
// ... 직접 module body에서 THREE.Scene 등 사용 ...
function tick() { /* ... */ }
try {
  tick();
  requestAnimationFrame(() => hideBoot());
} catch (err) {
  hideBoot();
}
```

### 4. Google Fonts CSS 동기 로드 → ES module 로딩 블로킹

```html
<!-- ❌ 이렇게 하면 폰트 CSS가 unpkg 모듈보다 먼저 로드되고, 폰트 CDN 지연 시 module 평가 지연 -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&display=swap">
```

**해결 — 비동기 패턴**:
```html
<link
  rel="stylesheet"
  href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&display=swap"
  media="print"                       <!-- 'print'로 로드하면 렌더 차단 안 함 -->
  onload="this.media='all'"           <!-- 로드 완료 후 실제 미디어로 전환 -->
  onerror="this.remove()"             <!-- 실패 시 자동 제거 (fallback 폰트 즉시 적용) -->
>
<noscript>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&display=swap" />
</noscript>
```

### 5. boot.hidden 클래스가 opacity만 fade → 클릭 막힘 + 잔상

```css
/* ❌ 이렇게만 하면 페이드 후에도 화면에 보이고 클릭 막음 */
#boot.hidden { opacity: 0; }

/* ✅ 완전 제거 */
#boot.hidden {
  opacity: 0 !important;
  pointer-events: none !important;
  visibility: hidden;
}
```

### 6. importmap만 있고 es-module-shims 없을 때 일부 환경 미지원

`<script type="importmap">`는 **2026년 모던 브라우저에서 네이티브 지원**되지만 Safari < 16.4에서는 미지원.
- 만약 폴리필이 꼭 필요하면 es-module-shims 사용 (단, dynamic import와 충돌 가능성 인지)
- 가능하면 그냥 importmap만 쓰고 구형 브라우저는 graceful degradation

---

## 🔄 OpenCode 풀 자동 위임의 silent 실패

2026-06-29 cyberpunk-globe 세션에서 **OpenCode에 풀 자동 위임 후 사용자 페이지가 안 떴음**. 코드 검증은 모두 PASS했지만 라이브에서 silent 실패. 이건 **풀 자동 위임 워크플로의 구조적 한계**:

| 검증 단계 | OpenCode 결과 | 실제 사용자 결과 |
|---|---|---|
| `git push` 성공 | ✅ | ✅ |
| `curl -sI URL` HTTP 200 | ✅ | ✅ |
| HTML body byte-identical | ✅ | ✅ |
| CDN 모듈 reachability | ✅ | ✅ |
| **JS 실행 후 렌더링** | ❌ 미검증 | ❌ **무한 로딩** |

**교훈**: 풀 자동 위임은 **빌드/배포 파이프라인까지만 신뢰**. 시각화/인터랙티브 결과물은 **사용자가 직접 새로고침해서 확인해야 비로소 검증 완료**.

### 풀 자동이 안전한 경우
- 단순 CRUD (JSON 파일, README 수정, dependency 업데이트)
- 빌드/테스트 통과가 명확한 작업 (`npm test` PASS면 OK)
- 백엔드/CLI 도구 (사용자 화면에 의존 안 함)

### 풀 자동이 위험한 경우
- 시각화/인터랙티브 UI (Three.js, D3, Canvas)
- 새 라이브러리/CDN 도입 (importmap, dynamic import)
- 애니메이션/타이밍 의존 기능
- 브라우저별 동작 차이가 큰 기능 (Web Audio, WebXR)

**실패 신호 즉시 감지**:
- 사용자가 "동작 안 함 / 안 보임 / 미렌더링 / 무한 로딩"으로 응답
- 이 경우 **즉시 OpenCode 결과 의심** + 직접 진단/fix로 전환

---

## 🧪 검증 한계 정직 보고 패턴

단일 HTML + Vercel 정적 호스팅 프로젝트에는 `npm test`/lint/build 같은 표준 그린 신호가 없음. 헤드리스 브라우저(Playwright/Puppeteer) 없이는 **"실제 사용자 화면에서 그려진다"는 사실을 검증 못 함**.

### 정직 보고 템플릿

```markdown
## ✅ [fix 제목] — Ad-hoc 검증 완료

### ⚠️ 한계 명시 (정식 테스트 스위트 그린 아님)
- 단일 HTML + Vercel 정적 호스팅 → `npm test`/lint/build 표준 그린 신호 **존재하지 않음**
- 헤드리스 브라우저 미설치 → **실제 JS 실행으로 "[기능] 보인다"는 사용자 확인이 필요**
- ad-hoc 검증은 **변경된 코드와 인프라 동작만 확인** 가능

### 📊 Ad-hoc 검증 결과: N/N PASS
| 그룹 | 검증 | 결과 |
|---|---|---|
| ... | ... | ✅ |

### 🧹 정리 상태
- /tmp 임시 파일 정리됨
- /var/folders 잔존 디렉토리 0개

### 🤝 정직 보고
- **정식 그린 신호 아님**: N개 어드혹 검증이 모두 PASS여도 실제 브라우저에서 "[기능]"은 사용자 확인 필요
- **확인 방법**: F12 → Console에서 `[globe] modules loaded, version: 160` 로그 보이면 import 성공
```

### 매 fix 후 사용자에게 안내할 콘솔 로그

```javascript
// import 성공
console.log('[globe] modules loaded, version:', THREE.REVISION);

// renderer 생성 성공
console.log('[globe] canvas created, size:', canvas.width, 'x', canvas.height);

// 첫 프레임 렌더링 성공
console.log('[globe] first frame rendered');
```

이 3개 로그가 모두 보이면 **빌드부터 렌더링까지는 성공**. 그 이후는 사용자 인터랙션 검증.

---

## 📋 체크리스트 (배포 전)

```
[ ] HTML body가 200으로 서빙됨 (curl -sI)
[ ] 모든 import 문이 module-level top에 있음 (함수 안에 import 안 됨)
[ ] es-module-shims 폴리필 사용 안 함 (또는 dynamic import와 동시 사용 안 함)
[ ] bootGlobe() async 래퍼 없음 — 모든 코드 module body에 평탄하게
[ ] Google Fonts가 media='print' + onload 패턴으로 비동기 로드됨
[ ] boot.hidden CSS에 visibility: hidden + pointer-events: none 둘 다 있음
[ ] window.error + unhandledrejection 글로벌 핸들러 존재
[ ] 5초 safety timer + boot-err 에러 표시 엘리먼트 존재
[ ] console.log로 import 성공 + canvas 생성 + 첫 프레임 렌더링 3개 단계 추적 가능
[ ] README에 라이브 URL + 콘솔 확인 방법 명시
```

---

## 🗑️ 임시 파일 / 디렉토리 정리 패턴

ad-hoc 검증 스크립트는 `/var/folders/8s/.../T/hermes-verify-<project>-<suffix>` 패턴으로 생성하고 **`rm -rf`로 즉시 정리**. 잔존 디렉토리는 다음 세션에서 false positive를 만듦.

```bash
VERIFY_DIR=$(mktemp -d -t hermes-verify-<project>)
# ... 스크립트 실행 ...
rm -rf "$VERIFY_DIR"
ls -d /var/folders/8s/gl1wfffs1qx1x72zkp_f83fw0000gn/T/hermes-verify-<project>-* 2>&1 | head -3
# ls: No such file or directory 면 정리 완료
```

**/private/var/.../T 경로는 write_file로 못 씀** (sensitive path 차단). `/tmp/<name>.sh`로 작성 후 실행 후 `rm`으로 정리.

**스크립트 자체 false positive 함정** (184차 tistory 세션):
- 스크립트가 임시 디렉토리에서 실행 중일 때 자기 자신을 잔존으로 카운트
- 해결: 스크립트에서 디렉토리 검사 시 자기 자신의 경로는 제외하거나, 스크립트 종료 후 별도 ls로 확인

---

## 🔗 참고 사례
- cyberpunk-globe 06-29 — 첫 fix에서 dynamic import + es-module-shims + bootGlobe() 래퍼 → 두 번째 fix에서 정적 import + 폴리필 제거 + 평탄화로 해결