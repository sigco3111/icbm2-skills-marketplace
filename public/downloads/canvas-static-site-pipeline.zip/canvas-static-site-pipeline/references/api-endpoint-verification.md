# 외부 API Endpoint + URL 검증 절차 (2026-07-09 sigco3111/toss-trader 실측)

> 다른 프로젝트/라이브러리의 README나 kstost 같은 reference repo에서 endpoint URL을 박아둘 때, **그 URL이 진짜로 살아있는지** 확인하는 절차. kstost/stock의 `openapi.tossinvest.com` (404) → 실제 작동 URL은 `openapi.tossinvest.com/openapi-docs/overview.md` / `developers.tossinvest.com/docs`였다는 2026-07-09 실측 학습.

## 1. 함정 — README 박힌 URL이 404일 수 있음

**증상**: 다른 리포의 README를 베끼면서 endpoint URL을 박았는데, 실제 우리 환경에서 호출하면 404 또는 빈 응답. 코드/스펙은 진짜인데 **박힌 경로가 죽었을 가능성**.

**원인 3가지**:

| 원인 | 예시 |
|---|---|
| 도메인 자체가 변경됨 | `api.foo.com` → `api.bar.com` (회사가 리브랜딩) |
| 박힌 URL은 docs landing인데 실제 endpoint는 `/v1/...` 같은 path | `https://api.foo.com` → `https://api.foo.com/openapi-docs/overview.md` |
| rate limit / IP / geo block으로 anon에서 403/404 | curl `403 Forbidden` + `X-RateLimit-Remaining: 0` |

## 2. 검증 4단계 (1분 이내 완료)

### 2.1 도메인 자체가 살아있는가

```bash
for url in "https://api.foo.com" "https://docs.foo.com" "https://foo.com"; do
  code=$(curl -sS -o /dev/null -w "%{http_code}" "$url" -A "Mozilla/5.0" -L --max-time 10)
  echo "$code  $url"
done
```

`200` = 살아있음. `404` = 도메인은 응답하지만 landing path 없음 → `/llms.txt`나 `/docs` 같은 sub-path 시도. `000` (curl exit 6) = DNS 실패 → 도메인 부재.

### 2.2 LLM 친화 인덱스 파일이 있는가 (가장 빠른 방법)

현대 SPA 기반 개발자 문서는 종종 `/llms.txt` (또는 `/llms-full.txt`) 를 별도 마크다운으로 제공. **SPA 본문은 curl로 못 읽지만 llms.txt는 가능**.

```bash
curl -sS "https://example.com/llms.txt" -A "Mozilla/5.0" -L --max-time 10 | head -100
```

| 응답 | 의미 |
|---|---|
| `200` + 마크다운 | ✅ source of truth로 사용. 모든 endpoint URL + 인증 방법이 거기 박혀있음 |
| `404` | llms.txt 없음. 다음 단계로 |
| `200` + HTML | SPA shell. 무의미, 다음 단계로 |

**tossinvest 실측 (2026-07-09)**: `https://developers.tossinvest.com/llms.txt` → 200 OK + 명확한 마크다운 인덱스. `openapi.tossinvest.com`은 404였지만 `/openapi-docs/overview.md`는 200 OK — llms.txt가 정답 경로 가리킴.

### 2.3 OpenAPI spec 직접 가져오기

대부분의 modern API는 OpenAPI 3.x spec을 자체 호스팅:

```bash
for path in "/openapi.json" "/v1/openapi.json" "/api/openapi.json" "/openapi-docs/latest/openapi.json"; do
  url="https://api.foo.com$path"
  code=$(curl -sS -o /dev/null -w "%{http_code}" "$url" -A "Mozilla/5.0" -L --max-time 10)
  [ "$code" = "200" ] && echo "✅ $url" || echo "$code  $url"
done
```

spec을 받으면 거기서 `servers` (base URL), `paths`, `securitySchemes` (인증 방식), `components.securitySchemes.*.flows.clientCredentials.tokenUrl` 모두 확인 가능.

**tossinvest 실측**: `openapi-docs/overview.md`가 human-readable이고 `openapi-docs/latest/openapi.json`이 machine-readable source of truth. 두 파일 다 같은 서버가 호스팅.

### 2.4 OAuth / 인증 방식 정밀 분석

```python
import json, urllib.request

spec = json.loads(urllib.request.urlopen("https://api.foo.com/openapi.json").read())
for name, scheme in spec.get("components", {}).get("securitySchemes", {}).items():
    print(name, "→", json.dumps(scheme, ensure_ascii=False, indent=2))
```

특히 확인할 4가지:

| 필드 | 의미 |
|---|---|
| `type` | `oauth2`, `apiKey`, `http` 등 |
| `flows.clientCredentials.tokenUrl` | OAuth Client Credentials 토큰 발급 endpoint |
| `flows.clientCredentials.scopes` | `{}` = scope 구분 없음 (키 1회 = 모든 권한) |
| `security` (top-level) | spec 전체에 적용되는 기본 보안 스킴 |

**scope 0개의 의미** (tossinvest 실측): 한 번 키 발급받으면 시세/잔고/주문/체결 모두 가능. **권한 분리 0**. paper trading 같은 안전장치는 사용자 측에서 구현해야 함 (API 자체에 없음).

## 3. 한국어 공식 개발자 문서 찾는 패턴

한국어 API 문서는 다음 후보들을 차례대로:

```bash
for url in \
  "https://example.com/docs" \
  "https://developers.example.com/docs" \
  "https://example.com/llms.txt" \
  "https://api.example.com/openapi-docs/overview.md" \
  "https://api.example.com/openapi-docs/latest/openapi.json" \
  "https://help.example.com" \
  "https://cs.example.com"; do
  code=$(curl -sS -o /dev/null -w "%{http_code}" "$url" -A "Mozilla/5.0" -L --max-time 10)
  echo "$code  $url"
done
```

| 흔한 패턴 | 의미 |
|---|---|
| `/docs` (SPA) | interactive docs. curl로는 본문 못 읽음 |
| `/llms.txt` (마크다운) | LLM 친화. **source of truth로 가장 신뢰** |
| `/openapi-docs/...` | 동일 서버가 OpenAPI spec 호스팅 |
| `/developers.{도메인}` | 별도 개발자 포털 (예: `developers.tossinvest.com`) |
| `/help` / `/cs` | 고객센터용. 기술 문서 아님 |

## 4. 자주 빠지는 실수 4가지

| 실수 | 결과 | 해결 |
|---|---|---|
| 다른 리포 README의 URL 그대로 박기 | 404 + 통합 테스트 실패 | §2의 4단계 검증 후 박기 |
| `curl -s ... \| jq` 으로 SPA 본문 파싱 | `null` 또는 shell 에러 | llms.txt 또는 OpenAPI spec 우선 |
| 도메인 200 OK만 확인하고 path는 안 봄 | landing만 200, 실제 endpoint 404 | §2.3 path 후보 4~5개 시도 |
| OAuth `flows` 필드 안 읽고 scope 분리 가정 | 키 1회 발급 = 모든 권한임을 모르고 paper trading 같은 안전장치 미구현 | §2.4의 `scopes: {}` 정밀 확인 |

## 5. 보고 형식

다른 세션/사용자에게 endpoint 검증 결과를 보고할 때:

```
✅ endpoint: https://api.foo.com/v1
✅ auth: OAuth 2.0 Client Credentials (tokenUrl=/oauth2/token, scopes={})
✅ source of truth: https://example.com/llms.txt
⚠️ README에 박힌 https://api.foo.com URL은 404 → /v1 path 추가
```

각 항목 한 줄. ⚠️ 항목은 우리 코드가 알아야 할 함정/주의사항.

## 6. 적용 시점

- **다른 프로젝트 reference할 때** (kstost/stock 같은 외부 리포 참고) — 그 리포의 endpoint URL을 무조건 베끼지 말고 §2의 4단계로 검증
- **우리 toss-trader / API 통합 작업 시작 시** — 발급 자격, OAuth 방식, scope 구조 모두 이 절차로 1차 파악
- **memory 한계 도달 시** — 사실관계를 이 reference로 이전 (memory는 4,000자 한도, skill은 무제한)