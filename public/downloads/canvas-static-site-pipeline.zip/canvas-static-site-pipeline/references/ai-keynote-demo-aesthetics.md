# AI Keynote Demo Aesthetics

GPT-5.5 / Gemini / Claude 발표 페이지의 시연 데모가 갖는 시각적 공통점. "AI 키노트 데모처럼 만들어줘" 요청 시 참조.

## Color & Background

- **배경: 완전 검정 `#000` 또는 매우 어두운 그라데이션** (`#0a0a14` → `#000`).
- **별 입자(particle field)** 추가하면 "우주적" 인상 ↑. `THREE.Points` + 작은 흰색 sprite 2000~5000개, 천천히 회전.
- **단일 액센트 컬러**: 시안 `#00d4ff`, 오렌지 `#ff6b35`, 일렉트릭 블루 `#0066ff` 중 1개. **무지개 그라데이션 절대 금지**.
- 흰색 텍스트 (`#ffffff` 또는 약간 off-white `#f0f0f0`).

## Typography

- **모노스페이스** (`JetBrains Mono`, `IBM Plex Mono`, `SF Mono`) — 텔레메트리/코드 느낌.
- 또는 **Geist Sans / Inter** — 깔끔한 산세리프.
- **절대 serif 폰트 금지** (시대착오적).
- 텍스트 크기: 본문 14~16px, 메트릭 12~13px. 화면 중앙 비우기.

## Layout 원칙

- **중앙 = 시각화 전용**. 텍스트는 4개 모서리 중 1~2개에만 floating.
- 좌상단 = 미션명/시작 시각. 우상단 = 현재 메트릭 (속도, 거리, 경과 시간). 좌하단 = 컨트롤. 우하단 = 상태.
- 텍스트는 `position: fixed`, `backdrop-filter: blur(10px)` 반투명 패널.

## 카메라 & 모션

- **자동 회전 0.05~0.15 rad/s**. 너무 빠르면 멀미, 너무 느리면 정적.
- 마우스 드래그로 manual override. OrbitControls의 `autoRotate` + `autoRotateSpeed` 사용.
- **easing**: `THREE.MathUtils.damp(current, target, lambda, dt)` — 부드러운 감속.
- 카메라 distance 변화: 0.5~1.0 사이 sine wave (호흡감).

## 궤적선 (Trajectory)

- **TubeGeometry** 또는 **Line2 (three/examples/jsm/lines)**. `LineBasicMaterial`은 항상 1px → fat line 필요.
- **발광 (glow)**: `emissive` + `emissiveIntensity` + Bloom 후처리로 빛나는 느낌.
- 색상: 본체 흰색 + 액센트 컬러로 fade-in (시작점 흐림, 끝점 진함).
- 두께: 2~4px. 너무 얇으면 안 보임.

## 포인트 라이트

- **궤적 따라가는 광원 1~2개**. `PointLight` + 거리 기반 `intensity`.
- 중앙(태양) 1개 = `DirectionalLight` + bloom.
- 전체 ambient light 매우 약하게 (`0.1~0.2`) — 완전 어두운 부분도 약간 보이게.

## 텔레메트리 텍스트 예시 (Artemis II)

```
MISSION          ARTEMIS II
LAUNCH           2026-04-01 18:35 EDT
ELAPSED          T+ 04:12:37
VELOCITY         12,847 km/h
DISTANCE FROM EARTH  348,221 km
PHASE            LUNAR FLYBY
NEXT BURN        TCM-2 in 02:14:00
```

- 우상단 또는 좌하단 패널.
- 숫자는 카운트업 애니메이션 (천천히 현재 값으로 수렴).

## Post-processing (선택)

- **UnrealBloomPass** — 발광 효과 강조. strength 0.5~1.0, radius 0.4, threshold 0.0.
- **FilmPass** — grain 추가하면 "실사적" 인상.
- 너무 많이 끼우면 60fps 유지 어려움. 모바일 타겟이면 post-processing 생략.

## 보일러플레이트

`templates/threejs-vite-starter.html`에 위 요소 모두 포함한 minimal starter 있음. 거기서 시작해서 데이터만 바꾸면 가장 빠름.

## 안티패턴

- ❌ 밝은 배경 + 어두운 텍스트 → 키노트 데모 아님, 그냥 일반 웹앱.
- ❌ 무지개 그라데이션 + neon 색상 남발 → 2010년대 crypto 웹사이트 느낌.
- ❌ 카메라 너무 빠름 → 시연용으로 부적합.
- ❌ 텍스트가 중앙 시각화 위에 덮임 → 가독성 0.
- ❌ 음악/효과음 자동재생 → 사용자 짜증. 기본은 무음, 토글.
