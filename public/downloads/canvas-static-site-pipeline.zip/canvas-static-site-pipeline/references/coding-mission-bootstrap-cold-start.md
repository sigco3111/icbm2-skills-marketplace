# 코딩미션 Cold-Start 부트스트랩 워크플로 (Repo 생성 → 첫 Pages 배포)

> 2026-07-08 heavy-chain-ik 세션에서 실측한 "GitHub 저장소 생성 → README 1차 푸시 → GitHub Pages 활성화 → 라이브 URL 200 도달" 까지의 cold-start 워크플로. step 7.5 (코딩미션 scaffolding) 직후 + Full cycle 진입 직전에 항상 거치는 단계.

이 reference는 `canvas-static-site-pipeline`의 step 1 (저장소 생성) + step 4 (배포) 사이의 **cold-start 구간**에 특화되어 있다. README 정책 / 한/영 anchor 깨짐 / fresh-evidence 회전은 별도 reference가 다루므로 이 문서와 혼동하지 말 것:

- `references/coding-mission-bilingual-readme-policy.md` — README 정책 + 한/영 anchor
- `references/opencode-generated-files-pitfalls.md` — OpenCode 산출물 Git 추적
- `references/full-cycle-readme-bump-and-deployment.md` — Full cycle 후반부 (Vercel + README 갱신)

## 1. 워크플로 개요 (5단계, ~5분)

```
mkdir + git init
  ↓
gh repo create (HTTPS remote 설정됨)
  ↓
README 1차 작성 + commit + push
  ↓
gh api -X POST repos/{owner}/{repo}/pages (Pages 활성화)
  ↓
sleep 30~60s + curl 검증 (HTTP 200)
```

## 2. 함정 4가지 (실측)

### 2.1 `gh repo create --source=.` 는 cwd가 git repo여야 동작

`gh repo create {name} --source=. --remote=origin` 는 **현재 디렉토리가 이미 git repository**여야 한다. 비어있는 디렉토리에서 실행하면:

```
current directory is not a git repository. Run `git init` to initialize it
```

**해결 — 명시적 분리 실행**:
```bash
mkdir -p /Users/mac/work/{project-name}
cd /Users/mac/work/{project-name}
git init -b main
git remote add origin git@github.com:sigco3111/{project-name}.git  # 또는 https://
gh repo create sigco3111/{project-name} --public --description "{한 줄 컨셉}"
```

`gh repo create ... --source=. --push` 한 방 패턴은 **`git init`이 이미 완료된 디렉토리에서만** 동작. cold-start 단계에선 위 4줄 분리가 정답.

### 2.2 SSH host key 인증 실패 → HTTPS 리모트 전환 (Hermes/OpenCode 세션 함정)

`git remote add origin git@github.com:...` 로 SSH를 잡고 `git push -u origin main` 하면 **Hermes/OpenCode 세션에서는 SSH agent/known_hosts가 자동으로 로드되지 않는** 경우가 많다. 증상:

```
Host key verification failed.
fatal: Could not read from remote repository.
```

이건 키 자체가 없는 게 아니라 **세션이 SSH known_hosts를 신뢰하지 않는** 상태. 해결은 두 가지:

**A) HTTPS 리모트로 전환 + OAuth 토큰 사용 (권장, cold-start 가장 빠름)**:
```bash
git remote set-url origin https://github.com/sigco3111/{repo}.git
GIT_TERMINAL_PROMPT=0 git push -u origin main
```

`GIT_TERMINAL_PROMPT=0`은 자격 미입력 시 hang 방지. 인증은 `gh auth login`에서 만든 토큰이 keyring에 저장돼 있으므로 자동 통과 (Hermes 표준 환경).

**B) SSH host key 명시적 trust + keychain 등록**:
```bash
ssh-keyscan github.com >> ~/.ssh/known_hosts
ssh-add --apple-use-keychain ~/.ssh/id_ed25519  # macOS
```
느리고 OS 의존적이라 A가 정답.

### 2.3 `gh repo edit --enable-pages` 옵션 미지원 → REST API 직접 호출

`gh repo edit --enable-pages --pages-branch main --pages-path /` 는 **CLI 옵션 자체가 존재하지 않음**:

```
--template                                 Make the repository available as a template repository
      --visibility string                        Change the visibility of the repository to {public,private,internal}
```

`gh repo edit`는 Pages를 다루지 않는다. **REST API 직접 호출이 정답**:

```bash
gh api -X POST repos/sigco3111/{repo}/pages \
  -H "Accept: application/vnd.github+json" \
  -f "source[branch]=main" \
  -f "source[path]=/"
```

응답 예시 (pages build_type = legacy):
```json
{
  "url": "https://api.github.com/repos/sigco3111/{repo}/pages",
  "status": null,
  "cname": null,
  "custom_404": false,
  "html_url": "https://sigco3111.github.io/{repo}/",
  "build_type": "legacy",
  "source": {"branch": "main", "path": "/"},
  "public": true,
  "protected_domain_state": null,
  "pending_domain_unverified_at": null,
  "https_enforced": true
}
```

`html_url`이 라이브 URL 후보. **legacy 빌더**가 default로 잡힘 (root 경로 + main 브랜치). workflow 빌더(`build_type: workflow`)로 가려면 `.github/workflows/pages.yml`이 필요하고 별도 단계.

### 2.4 첫 Pages 빌드 30초~1분 지연 — 즉시 curl 시 404

REST API로 Pages 활성화 직후 `curl -sI https://{user}.github.io/{repo}/` 하면 **즉시 404**를 반환한다. 첫 GitHub Actions/Pages 빌드가 백그라운드에서 도는 중이기 때문. 빌드 상태 확인:

```bash
gh api repos/sigco3111/{repo}/pages/builds --jq '.[0] | {status, created_at}'
# → {"created_at":"2026-07-08T07:15:39Z","status":"built"}
```

`status` 가 `"built"` 면 라이브 URL이 200을 반환한다. 실측 cold-start 시간표:

| 시점 | 상태 |
|---|---|
| REST API 호출 직후 | `status: null` |
| +5초 | `status: queued` / `building` |
| +30~40초 | `status: built` + URL 200 |
| 5분+ | 응답 변화 없음 (이미 stable) |

**검증 루틴** (cold-start 단계의 5.5 self-check 변형):
```bash
# 1) POST 호출
gh api -X POST repos/sigco3111/{repo}/pages \
  -H "Accept: application/vnd.github+json" \
  -f "source[branch]=main" -f "source[path]=/"

# 2) 첫 빌드 완료 대기 (최소 25~30초 + 점진 재시도)
sleep 25
curl -sS -o /dev/null -w "HTTP %{http_code} | %{size_download}B\n" \
  https://sigco3111.github.io/{repo}/

# 3) 아직 404면 한 번 더 대기
sleep 40
curl -sS -o /dev/null -w "HTTP %{http_code} | %{size_download}B\n" \
  https://sigco3111.github.io/{repo}/
```

heavy-chain-ik 실측:
- `sleep 25` 후 첫 curl → **404 (9115B)**
- `sleep 40` 후 → **200 (10973B)** ✓

## 3. Cold-Start 표준 커맨드셋 (재사용 가능)

```bash
PROJECT="{project-name}"
WORKDIR="/Users/mac/work/$PROJECT"

# 1) 디렉토리 + git init
mkdir -p "$WORKDIR" && cd "$WORKDIR"
git init -b main

# 2) GitHub repo 생성 (HTTPS remote 자동 설정)
gh repo create "sigco3111/$PROJECT" --public \
  --description "{한 줄 컨셉}"

# 3) README + .gitignore 작성 후 commit + push
#    (README 정책은 coding-mission-bilingual-readme-policy.md 참조)
git add README.md .gitignore
git commit -m "docs: scaffold README for $PROJECT"
git push -u origin main  # SSH 실패 시 자동으로 https fallback (아래 §4)

# 4) Pages REST API 활성화
gh api -X POST "repos/sigco3111/$PROJECT/pages" \
  -H "Accept: application/vnd.github+json" \
  -f "source[branch]=main" -f "source[path]=/"

# 5) 빌드 대기 + 검증 (재시도 2회)
sleep 25
for i in 1 2; do
  STATUS=$(curl -sS -o /dev/null -w "%{http_code}" \
    "https://sigco3111.github.io/$PROJECT/")
  echo "Attempt $i: HTTP $STATUS"
  [ "$STATUS" = "200" ] && break
  sleep 30
done

# 6) 빌드 상태 확인
gh api "repos/sigco3111/$PROJECT/pages/builds" \
  --jq '.[0] | {status, created_at}'
```

## 4. SSH 실패 → HTTPS 폴백 (자동화 가능)

`gh repo create`가 만든 default remote는 SSH (`git@github.com:...`). push 실패를 자동 감지해서 HTTPS로 전환하는 패턴:

```bash
if ! git push -u origin main 2>&1 | grep -q "Host key verification"; then
  echo "✅ SSH push OK"
else
  echo "⚠️ SSH host key verification failed, switching to HTTPS"
  git remote set-url origin "https://github.com/sigco3111/$PROJECT.git"
  GIT_TERMINAL_PROMPT=0 git push -u origin main
fi
```

근데 `grep -q`로 잡으면 exit code가 1이 되어도 `$?` 보정이 필요. **더 단순한 패턴은 그냥 HTTPS remote로 시작**:

```bash
git init -b main
git remote add origin "https://github.com/sigco3111/$PROJECT.git"
gh repo create "sigco3111/$PROJECT" --public \
  --description "{한 줄 컨셉}"  # remote URL은 그대로 (HTTPS)
git push -u origin main
```

HTTPS first가 cold-start 단계에선 가장 안전. SSH 전환은 사용자가 명시적으로 요청할 때만 (다른 PC 핸드오프 등).

## 5. Pages 빌드 트리거 옵션 2종

GitHub Pages 빌드는 두 가지 모드가 있다:

| 모드 | 트리거 | 빌드 환경 | cold-start 적합도 |
|---|---|---|---|
| **legacy** (default) | POST `/pages` API | GitHub managed | ✅ 즉시 가능, 단계 0개 |
| **workflow** | `.github/workflows/pages.yml` push | GitHub Actions | ❌ workflow 파일 작성 + push 추가 필요 |

cold-start 단계에선 **legacy가 정답**. workflow 모드로 가야 하는 경우는 (a) 커스텀 Jekyll 플러그인, (b) 빌드 시 환경변수 주입, (c) private runner 필요 등. 단일 HTML 미션엔 모두 해당 없음.

**legacy → workflow 전환**이 필요해지면:
```bash
gh api -X PUT "repos/sigco3111/$PROJECT/pages" \
  -f "build_type=workflow" \
  -f "source[branch]=main" \
  -f "source[path]=/"
```

→ `.github/workflows/pages.yml` 작성 + push 필수. 상세는 Repolis 패턴 (`references/repolis-fork-pages-workflow.md`) 참조.

## 6. 자주 빠지는 실수 5가지

| 실수 | 증상 | 해결 |
|---|---|---|
| `gh repo create ... --source=.` 만 실행 | "current directory is not a git repository" | `git init -b main` 먼저 |
| SSH remote로 시작 + OpenCode/Hermes 세션 | "Host key verification failed" | HTTPS remote로 시작 (§4) |
| `gh repo edit --enable-pages` 시도 | 옵션 자체 부재, help 출력 | `gh api -X POST .../pages` 직접 |
| REST API 호출 직후 즉시 curl | 404 + 빌드 안 됨 | sleep 25~60 + 재시도 |
| Pages 첫 빌드 URL을 team-scope로 검증 | SSO 302 (Vercel team-scope와 다른 이유지만 같은 함정) | `https://{user}.github.io/{repo}/` 만 검증 (anon 가능) |

## 7. 보고 형식 (사용자에게)

cold-start 단계 끝났을 때 다음 4개 항목을 짧게 보고:

```
저장소: https://github.com/sigco3111/{project-name}
리드미: {n}개 섹션 (한/영 통합), {attribution} 명시
Pages: https://{user}.github.io/{project-name}/ (HTTP 200, {n}B)
커밋: {hash} docs: scaffold README for {project-name}
```

각 항목 한 줄. size_download는 `wc -c < index.html` 와 비교하지 말 것 (cold-start에선 README만 push 상태). bit-perfect 검증은 Full cycle 단계 (§5.5 self-check)에서.

## 8. 적용 시점

- **cold-start 단계 (코딩미션 첫 세션)** — `gh repo create` + Pages REST API + 빌드 대기는 항상 이 reference의 절차
- **다른 PC 핸드오프** — `git clone https://...` 후 별도 Pages 활성화 불필요 (이미 활성화됨)
- **Full cycle 진입** — 이 reference의 검증 단계는 cold-start 확인용. Full cycle의 Vercel 검증 + bit-perfect 비교는 `references/full-cycle-readme-bump-and-deployment.md`

## 9. 관련 SKILL.md 본문 위치

- `canvas-static-site-pipeline/SKILL.md` §1 (저장소 생성) — 본 reference의 §3이 보강
- §7.5 (코딩미션 scaffolding) — step 1~3이 cold-start 직전
- §7.5.1 (placeholder index.html echo) — README push 직후 OpenCode 핸드오프