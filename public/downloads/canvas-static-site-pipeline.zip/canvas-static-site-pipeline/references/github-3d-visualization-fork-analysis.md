# GitHub 3D 시각화 저장소 분석·포크 프레임

> 사용자가 "X 저장소처럼 우리도 할 수 있을까?", "X 패턴 우리한테 적용해줘" 식의 요청을 할 때 적용. 2026-06-23 Repolis 분석 세션에서 확립.

## 적용 시점

- "Three.js + GitHub Pages + 빌더 스크립트" 구조의 외부 repo를 발견했을 때
- 사용자가 "포트폴리오/대시보드/시각화" 류 작업을 요청하면서 모티브를 찾고 있을 때
- 단일 HTML + 데이터 JSON + Python/Node 빌더 패턴을 가진 스타 repo를 fork 전 검토할 때

## 5단계 분석 프레임

### 1단계: 구조 진단 (3분)

```bash
gh repo view {owner}/{repo} --json name,description,createdAt,pushedAt,isPrivate,primaryLanguage,languages,repositoryTopics,stargazerCount,forkCount
```

체크: 주 언어 + 언어별 KB 크기 (HTML 185KB면 단일 파일 = Three.js 패턴), 토픽, ⭐/Fork 수 (너무 적으면 미검증, 너무 많으면 과한 의존성), `pushedAt` (1년 안이면 유지보수 양호).

### 2단계: 데이터 플로우 다이어그램 (5분)

README의 "How it works" / "Data flow" / "Architecture" 섹션을 텍스트로 정리:

```
[Input data source]  →  [Builder/Generator]  →  [Static output]  →  [Visualization layer]
```

4단계 레이어로 분해:
- (a) 입력 데이터 소스 — API 호출? CSV 누적? 외부 비공개 repo?
- (b) 빌더/생성기 — Python 스크립트? Node CLI? GitHub Actions 워크플로?
- (c) 정적 결과물 — `repos.json`, `data.json` 같은 JSON? HTML 단일 파일?
- (d) 시각화 레이어 — Three.js 단일 index.html? Vite 빌드 결과물?

흔한 데이터 소스 패턴:
- GitHub traffic API (14일 롤링 → 누적하려면 매일 collector 필요)
- 공개 REST API (날씨, 주가, 공휴일 등 — 무키 가능)
- JPL/NASA 같은 공식 ephemeris (SSL 우회 필요)
- 사용자 수동 입력 (CSV/JSON 커밋)

### 3단계: 전제조건 의존성 체크 (3분)

README를 다음 키워드로 grep:
- `private`, `비공개`, `private repo`
- `requires a separate`, `depends on`
- `you also need`, `prerequisite`, `전제조건`
- `API key`, `token`, `PAT`
- `daily`, `cron`, `workflow`

체크리스트:
- [ ] 별도 비공개 repo에 의존? (예: Repolis → `github-traffic-monitor`)
- [ ] 외부 API 키 필요? (예: GitHub PAT, Mapbox token)
- [ ] 매일 데이터 collector 동작 필요? (cron / GitHub Actions)
- [ ] 유료 호스팅 필요?
- [ ] LLM API 키 필요?

**전제조건 있는 repo는 "그대로 fork 불가"** — 사용자에게 먼저 알리고 셋업 옵션 1~3개 제시.

### 4단계: 우리 환경 블로커 식별 (3분)

3단계 + 사용자 환경 점검:

| 블로커 카테고리 | 확인 방법 |
|---|---|
| GH 토큰/스코프 | `gh auth status` + PAT 보유 여부 |
| 외부 CLI 도구 | `which vercel gh curl python3` |
| 도메인/호스팅 | Vercel/Cloudflare 계정 |
| cron 인프라 | `~/.hermes/scripts/` 디렉토리 + 등록 가능 여부 |
| 데이터 소스 가용성 | GitHub Traffic API 본인 repo 접근 권한 |

**블로커 N개로 정리** — 각 블로커마다 해결 옵션 1줄. 사용자한테 "블로커 N개, 해결 옵션은 A/B/C" 식으로 보고.

### 5단계: 결정 포인트 5개 + 추천 (5분)

거의 모든 "X처럼 해줘" 요청에 다음 5개 결정이 따라옴. **A/B/C 옵션 + 굵은 추천 1개 + 트레이드오프 1줄**:

1. **스코프** — 풀 복제 / 핵심만 / MVP만
2. **repo 필터링** (시각화 repo라면) — 전부 / 내가 만든 것만 / 내가 커밋한 것만
3. **데이터 소스** — 기존 패턴 따라가기 / 우리 환경에 맞게 변경 / 단순화
4. **톤/미학** — 원본 유지 / 사용자 톤 매치 / 별도 스타일
5. **호스팅** — GitHub Pages / Vercel / Cloudflare

## 분석 보고 템플릿

```markdown
# {저장소명} 분석

## 📊 한 줄 요약
{description}

## 🏗️ 데이터 플로우
[Input] → [Builder] → [Static] → [Visualization]

## ⚠️ 우리 환경 블로커
1. {블로커} → 해결 옵션 A/B/C
2. ...

## 🎯 결정 포인트 5개
1. {옵션 A / B / C} — 추천: **B**
2. ...

## 🚀 추천 진행 순서
1. 결정 확정
2. ...
```

## 적용 사례

### Repolis (2026-06-23)

- **구조**: HTML(185KB) + Python 빌더(12KB) + JS + GitHub Actions workflow
- **데이터 플로우**: 비공개 `github-traffic-monitor` CSV → `refresh.yml` 매일 cron → `build_repos.py` → `repos.json` → Three.js index.html
- **블로커 3개**: `github-traffic-monitor` 없음 / 134개 repo 중 fork 많음 / GH_PAT 없음
- **결정**: 스코프 C (도시 + 로컬 택시), repo 필터 "내가 커밋한 것만", Ghibli 톤 유지, GitHub Pages

## 흔한 함정

- **분석 단계를 건너뛰고 바로 fork** — 의존성/전제조건 놓쳐서 시간 낭비. 5단계 20분이 fork/commit/debug 시간보다 가치 있음
- **사용자에게 "가능/불가능" 결정 강요** — 우리는 블로커 + 옵션을 제시하고 사용자 결정 받기
- **원본 그대로 fork** — 우리 환경에 맞게 조정 안 하면 결국 다시 갈아엎음
- **호스팅 결정 누락** — GitHub Pages vs Vercel vs Cloudflare는 비용/도메인/CI 차이가 크므로 미리 확정