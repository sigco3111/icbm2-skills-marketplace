# Next.js 풀스택 변형 — TDD + patch tool 사고 + unknown type 함정

sigco3111/toss-trader 6단계(2026-07-10) 실측에서 추가로 잡힌 4종 함정. 본 문서는 §7.5.7 (Next.js 풀스택 변형) **5대 전용 함정**에 보충으로 함께 참조.

## A. `patch` tool fuzzy match가 함수 시그니처를 통째로 잡아먹는 사고 (2026-07-10 Portfolio.tsx 실측)

**현상**: 같은 turn에서 `patch`를 N회 연속 호출할 때 (특히 §7.5.3 헤딩 anchor 깨짐 10종 패치처럼 multi-patch 루프), **fuzzy match가 의도와 다른 영역까지 잡아먹는 사고**가 발생. 실측 케이스: `components/Portfolio.tsx`를 patch로 재작성 시도 → `export function Portfolio(...)` 시그니처 + useState 5개가 통째로 사라지고 `const fetchData = useCallback(...)`가 모듈 스코프로 빠짐 → TS 파싱 에러 (`Declaration or statement expected`).

**근본 원인**:
- patch는 old_string + new_string 단순 텍스트 매치. **context hint 줄(@@ … @@) 미사용 시 가장 가까운 매치를 찾음** — 함수 본문이 길면 시그니처를 제외한 본문 일부만 매치되고 new_string이 그걸 대체하면서 시그니처가 고아(orphan)가 됨.
- 또는 patch가 L1~L2 매치로 시작해서 L200까지 덮어쓰면서 중간 코드를 날림.
- `same_tool_failure_warning` count=N 신호가 와도 "어떤 patch가 실패했는지" 명시 안 됨.

**해결 패턴 (3가지, 우선순위 순)**:

1. **`write_file` 통째로 다시 쓰기** (★★ 가장 안전, 0.5~2초 비용)
   - multi-patch 위험이 있는 모든 케이스에 기본값
   - lint/format 일관성도 함께 챙김
   - 패치 매칭 함정 자체가 사라짐
2. **context hint 줄 추가** — V4A patch mode(`mode='patch'`)에서만 가능:
   ```
   *** Begin Patch
   *** Update File: lib/foo.ts
   @@ function bar @@
   <context lines>
   -<removed>
   +<added>
   *** End Patch
   ```
   - 단, 이 skill은 `patch` (mode='replace') 위주. V4A는 multi-file patch에 강점.
3. **python heredoc 우회** (3종 이상 일괄 변경 시):
   ```bash
   python3 - <<'PY'
   from pathlib import Path
   p = Path('lib/foo.ts')
   text = p.read_text()
   mapping = [
       ('old1', 'new1'),
       ('old2', 'new2'),
   ]
   for old, new in mapping:
       text = text.replace(old, new, 1)
   p.write_text(text)
   PY
   ```
   - 3종 이상 일괄 변경 시 patch tool N회 호출 < python heredoc 1회

**판단 기준**:
- 변경 범위 = 함수/컴포넌트 본문 전체 → `write_file` 통째로
- 변경 범위 = 한 함수 내 1~3개 라인 → `patch` (replace mode, 충분한 surrounding context)
- 변경 범위 = 3+개 파일 동시 또는 V4A 패턴 필요 → `patch` (patch mode) + context hint
- 어떤 patch든 fail 나면 즉시 abort + 다른 도구로 우회 (retry 금지)

## B. JS 숫자 separator 8 vs 9 자리수 함정 (5단계 formatKrwShort 실측, NEW)

**현상**: `_0000_0000` (8자리) = 1,0000,0000 = 1억, `_000_000_000` (9자리) = 1,000,000,000 = 10억. **JS underscore는 무시되고 자리수만 카운트** — 1글자 차이로 1억 vs 10억.

**함정 실측** (5단계):
```js
// ❌ 1억으로 의도했는데 10억 (= 9자리) — 1_0000_0000 = 1,000,000,000
const ONE_HUNDRED_MILLION = 1_0000_0000;
console.log(ONE_HUNDRED_MILLION / 1_0000_0000);  // → 10 (10억 / 1억)
// → "1.0억"이 출력되어야 하는데 "10.0억" 출력

// ✅ 의도가 1억이라면 1,000,000_000 (10억)이 아니라 100,000,000 (1억) 명시
const ONE_HUNDRED_MILLION = 100_000_000;
const TEN_BILLION = 1_000_000_000;
const ONE_TRILLION_KRW = 1_000_000_000_000;
```

**해결 패턴**:
- 1000 단위마다 underscore로 가독성 ↑ 가능 (`100_000_000` = 1억) — **자리수 헷갈림 방지 차원**
- 큰 숫자 (1조, 1000억, 1억) 매핑 혼동 시 **명시적 주석 + 천 단위 comma**:
  ```js
  // 단위: 원 (KRW). _ = 천 단위 separator (자리수 무관).
  const ONE_HUNDRED_MILLION = 100_000_000;   // 1억
  const ONE_BILLION = 1_000_000_000;          // 10억
  const ONE_TRILLION = 1_000_000_000_000;     // 1조
  ```
- 테스트 어서션 작성 시 **반드시 자리수 + 단위 주석 함께 박기** (5단계 `formatKrwShort` 테스트가 1차에 2건 fail, 2차에 1건 fail, 3차에 PASS한 이유가 전부 `_0000_0000` 1글자 오기)

**판단 기준**:
- 테스트 케이스의 숫자 리터럴에 `_` 있을 때 = **1글자 차이로 10배 차이 가능성** → 명시적 단위 주석 필수
- 큰 단위 (억/조) 다룰 때 9자리 vs 12자리 혼동 위험 → **3자리씩 끊어서** (`1_000_000_000` for 10억)

## C. `<pre>{JSON.stringify(data, null, 2)}</pre>` + `unknown` type 함정 (OrderButton.tsx 실측)

**현상**: `tossFetch<T>()` wrapper가 `unknown`을 반환 + UI에서 `JSON.stringify(result.data, null, 2)`를 `<pre>`에 렌더링 → TS error: `Type 'unknown' is not assignable to type 'ReactNode'`.

**원인**: `JSON.stringify`의 인자는 `any`라 string을 반환하지만, `{result.data && <pre>...}` 식으로 **JSX의 자식 평가 시점**에 `result.data` 자체가 `<pre>`의 prop으로 추론됨. `unknown`을 ReactNode로 narrow 없이 직접 매치하면 error.

**해결 패턴**:
```tsx
// ❌ 실패
{result.data && (
  <pre>{JSON.stringify(result.data, null, 2)}</pre>
)}

// ✅ narrow 후 매치
{result.data !== undefined && result.data !== null && (
  <pre>{JSON.stringify(result.data, null, 2)}</pre>
)}
```

**판단 기준**:
- API 응답 / 외부 입력 = 항상 `unknown`으로 추론 (안전)
- JSX 자식 평가 시점 = `unknown` → ReactNode 자동 변환 안 됨
- narrow = `!== undefined && !== null` (truthy 체크만으론 부족, `0`/`""` 값이 의도된 데이터일 수 있음)

## D. 모듈 스코프 store 격리 — `_resetPendingStore()` export 패턴 (telegram 4단계 실측)

**현상**: vitest 테스트가 모듈 스코프 `Map` (in-memory store)을 공유해서 테스트 간 격리 안 됨. `@vitest/spy`나 `vi.resetModules`로도 외부에서 store를 비우기 어려움 (모듈 export에 없음).

**해결 패턴 (3종 컴포넌트)**:

1. **store reset 함수 export**:
   ```ts
   const pendingStore = new Map<string, PendingOrder>();
   
   // ✅ 테스트 격리용 (lint 경고 가능하므로 _ prefix 권장)
   export function _resetPendingStore(): void {
     pendingStore.clear();
   }
   ```

2. **beforeEach에서 호출**:
   ```ts
   beforeEach(() => {
     _resetPendingStore();
     vi.spyOn(console, "log").mockImplementation(() => {});
   });
   ```

3. **테스트 함수 export에 _ prefix** — 일반 사용처에서 import 못 하게 type-level signal.

**판단 기준**:
- in-memory store / 캐시 / 토큰 / nonce 등 모듈 스코프 가변 상태 = **반드시 reset 함수 export**
- vitest worker 격리 한계 명시 (모듈이 worker 단위로 캐시됨, 같은 describe 내 순서 의존 가능)
- `vi.resetModules()`는 dynamic import 시에만 작동, top-level `import { x }`는 캐시됨
- `beforeEach`는 **무조건 호출** (테스트가 1개여도 — 2개째 추가될 때 격리 안 된 채로 fail)

## E. 시크릿 격리 정책 — lib/history.ts는 호출자 책임 (6단계 v0.4 단순화 실측)

**v0.3 단순화 결정**: `lib/history.ts`는 `JSON.stringify(record)` 그대로 저장. **시크릿이 record에 들어있으면 저장됨**. deep-clone + strip은 호출자(API route/UI) 책임.

**함정 실측**: OrderButton의 `executeOrder`가 `request` body에 Toss client_id/secret 안 넣음 → 안전. 만약 누군가 `body: { client_id: process.env.TOSS_CLIENT_ID }` 식으로 박으면 history JSON에 평문 저장됨.

**강화 패턴 (v0.5+ TODO)**:
```ts
function stripSecrets(obj: unknown): unknown {
  if (obj === null || typeof obj !== "object") return obj;
  if (Array.isArray(obj)) return obj.map(stripSecrets);
  const result: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(obj)) {
    if (/^(api_?key|secret|token|password|credential)/i.test(k)) continue;
    result[k] = stripSecrets(v);
  }
  return result;
}
```

**판단 기준 (★ 즉시 적용)**:
- v0.3 단순화 유지: 호출자 책임 (저장소 단순성)
- 호출자가 실수할 가능성 높으면 stripSecrets() 같은 헬퍼를 lib/history.ts에 추가 (v0.5+)
- 안전을 위해 record.kind === "order"일 때 `request`에서 apiKey/secretKey 패턴 자동 제거 (방어적)

## F. 다중 어서션 비교 — bash + python 2중 검증 (6단계 헤딩 정규화 실측, ALREADY §7.5.3.1.1)

**§7.5.3.1.1에서 정형화됨** — 본 문서에서 재언급 불필요. `check-kr-en-mixed-headings.sh` + python 정밀 정규식 2개 모두 0이어야 깨짐 부재 인정.

---

## 부록 — 4종 함정 실측 시퀀스

| 단계 | 함정 | 회복 시간 | 비용 |
|---|---|---|---|
| 5단계 (Portfolio) | `patch` fuzzy match 사고 (함수 시그니처 삭제) | write_file 통째로 = 30초 | 1회 |
| 5단계 (formatKrwShort) | JS 숫자 separator 8 vs 9 자리수 | 3 round TDD = 1분 | 어서션 정정 2회 |
| 4단계 (OrderButton) | `<pre>{JSON.stringify(data)}` unknown type | 1 patch = 5초 | 1회 |
| 4단계 (telegram) | in-memory store 격리 안 됨 | _resetPendingStore() export + beforeEach | 1회 |

총 4회 함정, 회복 합계 = 3분 이내. **모두 정형화 가능 + 다음 Next.js 풀스택 변형에서 예방 가능**.

## §7.5.7 (Next.js 풀스택 변형) 5대 전용 함정 업데이트 권장

**현재 SKILL.md §7.5.7 "5대 전용 함정" 섹션**에 본 문서 A~D 4종을 "6~9. 새 4종"으로 추가:

6. **`patch` tool fuzzy match가 함수 시그니처를 통째로 잡아먹는 사고** — `write_file` 통째로 권장.
7. **JS 숫자 separator 8 vs 9 자리수** — 큰 단위 (억/조) 매핑 시 명시적 단위 주석 + 천 단위 underscore.
8. **`<pre>{JSON.stringify(unknown)}` TS error** — `!== undefined && !== null` narrow.
9. **모듈 스코프 store 격리** — `_resetPendingStore()` export + beforeEach.

E (시크릿 격리)는 §7.5.7 5대 함정 "DRY_RUN 가드 = toss-trader 코드 내장"에 흡수. F (2중 어서션)는 §7.5.3.1.1에 이미 박혀 있음.

**판단 기준**: Next.js 풀스택 변형 진입 시 본 reference + §7.5.3.1.1 + §7.5.5 WT dirty 분리 모두 같이 로드.
