# Next.js 풀스택 파이프라인 — OAuth + 안전 가드 + TDD 4대 패턴

> 2026-07-10 sigco3111/toss-trader 4단계 실측. 변형 4 (Next.js 풀스택 변형)의 4대 핵심 패턴 + 함정 + 검증.

## 0. 변형 4 진입 기준

**brainstorming에서 다음이 등장하면 변형 4**:
- OAuth API 호출 (외부 서비스 인증)
- 사용자 인증 토큰 (BYOK 또는 서버 측 보관)
- 매수/매도/주문 같은 **비가역 작업 confirm 게이트**
- Telegram/Slack/Discord 알림
- TDD 강제 (vitest + 결정론적 시간 주입)

단순 데이터 시각화 + 정적 호스팅이면 **변형 1 (웹)**. GUI 윈도우 + macOS에서 동작이면 **변형 3 (데스크탑)**.

## 1. 4단계 표준 워크플로

```
[1단계 보일러플레이트]                [2단계 OAuth API relay]
  Next.js 16 + React 19                 catch-all dynamic route
  + TypeScript + Tailwind v4            + OAuth Client Credentials
  + ESLint 9                            + 토큰 캐시 (모듈 스코프, 1h TTL)
                                        + 401 재시도 + 429 backoff
  산출물: package.json, app/, lib/,      + 422 사용자 친화 메시지
         components/, .gitignore         + 5대 HTTP 가드 내장

                    ↓

[3단계 안전 가드 + TDD]                [4단계 Telegram confirm + UI]
  lib/safety.ts                          lib/telegram.ts
  + 6대 가드 (의도/맥락/시간/금액)         + sendOrderConfirm()
  + 4 method (GET/POST/PUT/DELETE)        + handleCallback()
  + test/safety.test.ts (25/25 PASS)      + dev fallback
  + vitest@4 (Next 16 호환)               + 13 tests PASS
                                        + components/OrderButton.tsx
                                        + app/page.tsx (dashboard)
```

## 2. OAuth API relay 패턴 (2단계 핵심)

### catch-all dynamic route

```typescript
// app/api/{api}/[...path]/route.ts
import { NextRequest, NextResponse } from "next/server";
import { tossFetch, TossError } from "@/lib/{api}";

interface RouteContext {
  params: Promise<{ path: string[] }>;  // ★ Next 15+/16: Promise
}

function joinPath(path: string[]): string {
  return "/" + path.join("/");
}

export async function GET(req: NextRequest, ctx: RouteContext) {
  const { path } = await ctx.params;
  try {
    const result = await tossFetch({
      method: "GET",
      path: joinPath(path),
      query: flattenQuery(new URL(req.url)),
    });
    return NextResponse.json(result, {
      headers: {
        "X-DRY-RUN": String(result.dryRun),
        "X-Served-At": result.servedAt,
      },
    });
  } catch (e) {
    if (e instanceof TossError) {
      return NextResponse.json(e.body, { status: e.body.httpStatus });
    }
    return NextResponse.json({ code: "internal-error", message: (e as Error).message }, { status: 500 });
  }
}
// POST/PUT/DELETE 동일 패턴
```

### lib/{api}.ts — OAuth Client Credentials + 토큰 캐시

```typescript
// lib/toss.ts (또는 다른 API)
const TOSS_API_BASE = "https://api.example.com";
const TOSS_TOKEN_ENDPOINT = `${TOSS_API_BASE}/oauth2/token`;

let cachedToken: { token: string; expiresAt: number } | null = null;
const TOKEN_TTL_MS = 55 * 60 * 1000; // 55분 (1시간 미만 보수적)

async function fetchAccessToken(): Promise<string> {
  const now = Date.now();
  if (cachedToken && cachedToken.expiresAt > now) return cachedToken.token;

  const body = new URLSearchParams({
    grant_type: "client_credentials",
    client_id: getClientId(),
    client_secret: getClientSecret(),
  });

  const res = await fetch(TOSS_TOKEN_ENDPOINT, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body,
    cache: "no-store",
  });
  if (!res.ok) throw new TossError({ code: `token-${res.status}`, message: "OAuth 실패", httpStatus: res.status });

  const data = await res.json();
  cachedToken = { token: data.access_token, expiresAt: now + TOKEN_TTL_MS };
  return data.access_token;
}

export async function apiFetch<T>(opts: { method, path, query, body, ... }): Promise<TossFetchResult<T>> {
  const token = await fetchAccessToken();
  // ... fetch + 401 재시도 + 429 backoff + 422 메시지 매핑
}
```

**5대 HTTP 가드 내장 (apiFetch 안에서)**:
1. `DRY_RUN=true` + POST/PUT/DELETE → `/api/v1/orders` 즉시 423 차단
2. 422 코드 10종 → 사용자 친화 메시지 매핑
3. 429 → `Retry-After` 헤더 우선 + 지수 백오프 (1s→2s→4s, max 3회)
4. 401 → 토큰 캐시 무효화 + 1회 재시도
5. 토큰 길이 검증 (TOSS_CLIENT_ID < 8자, TOSS_CLIENT_SECRET < 16자 throw)

## 3. 안전 가드 + TDD (3단계 핵심)

### lib/safety.ts — 6대 의도/맥락 가드

tossFetch() 안의 5대 HTTP 가드와 **분리된** 의도/맥락 가드. route 진입점에서 호출.

```typescript
export function guardRequest(input: {
  method: "GET" | "POST" | "PUT" | "DELETE",
  path: string,
  body?: unknown,
  headers?: Record<string, string | undefined>,
  now?: Date,  // ★ 테스트 결정론적 시간 주입
}): GuardResult {
  const mode = getTradingMode();
  // 1) TRADING_MODE (paper/live/simulation, HTTP 423)
  // 2) TRADE_AMOUNT_LIMIT (단일 주문 금액 상한, HTTP 422)
  // 3) MARKET_HOURS (KST 09:00~15:30 + lunch, HTTP 422)
  // 4) ACCOUNT_TYPE (연금/RIA/综合매매 = paper fallback, HTTP 423)
  // 5) TELEGRAM_CONFIRM (live 모드 = body.telegramConfirmed=true 필수, HTTP 425)
  // 6) AUDIT (모든 통과/차단 → stdout JSON, side effect)
}
```

### TDD vitest 4대 결정론 패턴

```typescript
// test/safety.test.ts

// 1) 시간 주입 (가드 3 MARKET_HOURS)
function kstDate(y, m, d, h, min): Date {
  const utc = Date.UTC(y, m-1, d, h-9, min, 0);  // KST = UTC+9
  return new Date(utc);
}
const r = guardRequest({ ..., now: kstDate(2026, 7, 10, 10, 0) });

// 2) 환경변수 격리 (beforeEach)
beforeEach(() => {
  delete process.env.TOSS_TRADING_MODE;
  delete process.env.TOSS_MAX_TRADE_AMOUNT;
  ...
});
afterEach(() => { process.env = { ...ENV_BACKUP }; });

// 3) 모듈 스코프 store 격리 — _resetPendingStore() export
export function _resetPendingStore(): void { pendingStore.clear(); }
// test: beforeEach(() => _resetPendingStore());

// 4) fetch mock + vi.fn().mockResolvedValue({ ok, status, text })
global.fetch = vi.fn().mockResolvedValue({ ok: true, status: 200 }) as unknown as typeof fetch;
```

### TDD 사이클 3단계 메타패턴 (2026-07-10 sigco3111/toss-trader 5단계 실측, NEW)

TDD 사이클은 보통 **3번의 같은 실패 → 3번의 다른 원인 정정**으로 그린 도달. 매 라운드 다른 차원의 결함이라 **패턴 인식이 핵심**:

| 라운드 | 흔한 fail 원인 | 정정 |
|---|---|---|
| **1차** | **Input 실수** — 테스트 입력 path/method/body가 의도와 다름 (예: route URL `/api/toss/api/v1/orders` vs tossPath `/api/v1/orders`) | 테스트 의도 명확화 + path는 lib 함수에 맞는 raw path 사용 |
| **2차** | **Env 누락** — live 모드 테스트가 telegramConfirmed 미포함, paper 모드 테스트가 DRY_RUN env 미설정, TTL=0 + 즉시 getOrder = 동일 ms race | 테스트 셋업에 의도된 env 또는 옵션 명시 (`{...sampleBuyOrder, telegramConfirmed: true}`) |
| **3차** | **경계값** — `expiresAt < now` vs `<=` (TTL=0이 만료 안 됨), `null` vs `undefined` narrow, `Number.isFinite(0) && 0 > 0` (false) vs `>= 0` (true) | 정책 명확화 (TTL=0 허용) + 비교 연산자 정밀화 |

**판단 기준**:
- **1차 fail = 1개**: 입력 의도 점검
- **2차 fail = N>1개 (동일 패턴)**: env / 셋업 누락 — beforeEach 박기
- **3차 fail = N개 (다양)**: 경계값 / 정책 — 코드 정책 명확화 + 비교 연산자 통일
- **4차 이후**: 패치 자체에 결함. abort + `python3 << 'PY'` heredoc 우회 (함정 §7.5.3.1.1 A36)

**toss-trader 실측**:
- 3단계 (safety.ts, 25 tests): 5/25 → 3/25 → 25/25 (input/env/경계값 동일 패턴)
- 4단계 (telegram.ts, 13 tests): 3/13 → 1/13 → 13/13 (store 격리 + TTL=0 + opts undefined)
- 5단계 (format.ts, 31 tests): 2/31 → 1/31 → 31/31 (JS numeric separator 자릿수 착각, 아래 §참조)

### JS numeric separator `_` 자릿수 함정 (★ 2026-07-10 format.ts 실측, NEW)

**테스트 어서션 작성 시 `_` separator 자릿수 계산 함정**. 한 글자 차이로 자릿수가 1 줄어들어 단위 변환이 어긋남:

| 표기 | 자릿수 | 값 | `formatKrwShort` 결과 |
|---|---|---|---|
| `1_0000_0000` | 9 | 1,000,000,000 (10억) | "1.0억" |
| `1_0000_0000_0000` | 13 | 100,000,000,000,000 (100조) | "100.0조" |
| `100_000_000_000` | 12 | 100,000,000,000 (1000억) | "1000.0억" |

**근본 원인**: JS에서 `_`는 숫자 리터럴 separator로 무시됨. `1_0000_0000` = `1` + 8자리 = 9자리 = 10^9 (10억). 흔한 착각 "1억 = 1,000,000,000 = 10^9"이 사실이 아님 (1억 = 10^8).

**해결 (★ 테스트 어서션 작성 규칙)**:
1. **자릿수 직접 주석 박기** — `expect(formatKrwShort(1_0000_0000)).toBe("1.0억"); // 9자리 = 10억 / 10억 = 1`
2. **10^n 표기 병기** — `1_0000_0000 // 1e8 = 1억` 또는 `1_0000_0000 // 1e9 = 10억` 명시
3. **의심스러우면 `console.log()`로 자릿수 확인** — `console.log(1_0000_0000, 1_0000_0000.toString().length)` → 1000000000 9
4. **테스트 describe 시작에 박스 코멘트** — "1억 = 100,000,000 (8자리, 10^8). 10억 = 1,000,000,000 (9자리, 10^9). 테스트 입력 자릿수 착각 주의"

**판단 기준**: 자릿수가 5 초과인 숫자 리터럴을 테스트에 쓸 때는 **반드시 자릿수 + 단위 주석** 박기. 어서션 실패 → 1차 정정 전에 자릿수 재확인.

### README 비개발자용 가이드 5단계 + 토스 Open API 키 발급 패턴 (2026-07-10 sigco3111/toss-trader README v0.6 실측, NEW)

**brainstorming에서 "비개발자도 따라할 수 있는 README"가 등장하면** README 1차 작업에서 **5단계 가이드 + 키 발급 절차 + 자주 막히는 곳** 3종 세트 박기. toss-trader README v0.6에서 10,906B → 18,398B (2배 확장).

**5단계 표준 구조 (README 최상단)**:
1. **키 발급 (5분)** — 로그인 → 설정(⚙️ 좌하단) → Open API 메뉴 → `client_id`/`secret` 즉시 저장. ⚠️ 3가지 주의 (재확인 불가/공유 금지/메뉴 신청).
2. **PC 저장 (1분)** — `~/.hermes/secrets/{name}.env` (chmod 600). ✅ 허용 vs ❌ 금지 위치 표.
3. **계정 + Fork (3분)** — sigco3111/{repo} Fork → Vercel Sign Up with GitHub.
4. **자동 배포 (3분)** — Import repo → env 2개 (서버 측 도구만) → Deploy. ⏱️ 1~2분 후 URL 생성.
5. **대시보드 (1분)** — paper 기본값, 실계좌 = 별도 confirm.

**🆘 자주 막히는 곳 (7개 증상 표)**: 메뉴 안 보임 / 토큰 못 봄 / Deploy 실패 / 401 / chmod 안 먹음 / Windows 경로 / 데이터 안 보임. 각 증상에 원인 + 해결 1줄.

**판단 기준**:
- 사용자가 "비개발자도 쓸 수 있게" 또는 "코딩 모르는 사람도" 명시 → 5단계 + 키 발급 + 자주 막히는 곳 3종 세트
- 사용자가 "개발자용" 또는 "내 사용"만 명시 → 기존 다층 README 그대로
- **README의 "🛠️ 개발자 섹션"은 5단계 아래에 보존** — 비개발자가 위쪽만 읽고, 개발자는 아래 섹션까지 읽는 2-tier 구조
- 최상단 분기: "비개발자 → 5단계 / 개발자 → 🛠️ 개발자 섹션으로 스크롤" 한 줄 안내

**env 키 이름 통일 (★ README/AGENTS/OPENAPI 3-way sync)**:
- README/AGENTS.md = `TOSS_CLIENT_ID` / `TOSS_CLIENT_SECRET` (정식, 가장 빈번한 컨텍스트)
- OPENAPI_REFERENCE.md = 처음에 `TOSSINVEST_API_KEY` / `TOSSINVEST_SECRET_KEY`로 적혀있어 통일 안 됨
- **해결**: README/AGENTS.md를 SSOT로 두고, OPENAPI_REFERENCE.md의 L27-28 + L51-52 curl 예제 박스를 README/AGENTS와 통일. `tossinvest.env` 파일명은 그대로 유지 (정식 환경 파일 이름)
- **3-way sync 결정 프레임**: (1) 정식 = 가장 최근 + 가장 빈번한 컨텍스트. (2) 정식 변경 시 다른 모든 곳 grep + patch. (3) docs/는 README보다 후순위. (4) curl 예제 박스의 변수명(`$TOSSINVEST_API_KEY`)도 모두 grep으로 잡아야 빠짐 없음

**TDD 사이클 실측 (toss-trader 25 → 38 tests)**:
- 1차 실행: 5/25 fail (path prefix 실수 + telegramConfirmed 미포함 + opts undefined)
- 2차: 3/25 fail (live 모드 케이스 telegramConfirmed 미포함)
- 3차: 25/25 PASS (테스트 셋업 정정)
- 4단계 TDD: 3/38 fail (store 격리 + TTL=0 + opts undefined)
- 5차: 1/38 fail (cleanupExpired TTL 경계)
- 6차: 38/38 PASS

## 4. Telegram confirm + OrderButton (4단계 핵심)

### lib/telegram.ts — inline button + in-memory 매칭

```typescript
const pendingStore = new Map<string, PendingOrder>();  // 모듈 스코프

export async function sendOrderConfirm(req: OrderRequest): Promise<SendResult> {
  const orderId = `order_${randomUUID().replace(/-/g, "").slice(0, 12)}`;
  const now = Date.now();
  const expiresAt = now + getConfirmTtlSec() * 1000;

  pendingStore.set(orderId, {
    orderId, symbol: req.symbol, side: req.side, ...,
    createdAt: now, expiresAt, status: "pending",
  });

  if (isDevFallback()) {
    return { ok: true, orderId, devFallback: true, ... };
  }

  // Telegram Bot API 호출
  const res = await fetch(`${TELEGRAM_API_BASE}/bot${getBotToken()}/sendMessage`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      chat_id: getChatId(),
      text: `📊 토스 주문 confirm 요청\n종목: ${req.symbol}...`,
      reply_markup: {
        inline_keyboard: [[
          { text: "✅ 확인 (주문 실행)", callback_data: `confirm:${orderId}` },
          { text: "❌ 취소", callback_data: `cancel:${orderId}` },
        ]],
      },
    }),
    cache: "no-store",
  });
}

export async function handleCallback(callbackData: string, callbackQueryId?: string): Promise<CallbackResult> {
  cleanupExpired();
  const [actionRaw, orderId] = callbackData.split(":", 2);
  const pending = pendingStore.get(orderId);
  if (!pending) return { action, orderId, reason: "not found" };
  if (pending.status === "expired" || pending.expiresAt <= Date.now()) {
    pending.status = "expired";
    return { action, orderId, order: pending, reason: "만료됨" };
  }
  pending.status = actionRaw === "confirm" ? "confirmed" : "canceled";
  return { action, orderId, order: pending, callbackQueryId };
}

export function _resetPendingStore(): void { pendingStore.clear(); }
```

### components/OrderButton.tsx — 매수/매도 UI

```typescript
"use client";

export function OrderButton({ symbol, symbolName, currentPrice }: OrderButtonProps) {
  const [side, setSide] = useState<Side>("BUY");
  const [price, setPrice] = useState<number>(currentPrice);
  const [quantity, setQuantity] = useState<number>(10);
  const [pending, setPending] = useState<PendingOrder | null>(null);
  const [result, setResult] = useState<OrderResult | null>(null);
  const [sending, setSending] = useState<boolean>(false);
  const [polling, setPolling] = useState<boolean>(false);

  // 1) 모달 confirm → 2) /api/telegram/send → 3) dev fallback 자동 confirm OR 실제 봇 click
  // 4) 폴링 1초 → 5) /api/toss/api/v1/orders + body.telegramConfirmed=true
  //    (가드 5 통과 → tossFetch() → 토스 Open API)

  return (
    <div>
      <div className="flex gap-2 mb-3">
        <button onClick={() => setSide("BUY")} className={side === "BUY" ? "bg-red-500 text-white" : "bg-zinc-100"}>매수</button>
        <button onClick={() => setSide("SELL")} className={side === "SELL" ? "bg-blue-500 text-white" : "bg-zinc-100"}>매도</button>
      </div>
      {/* 입력 + 모달 + pending/result 표시 */}
    </div>
  );
}
```

**React lint 함정 (OrderButton 박을 때 자주 잡힘)**:
- `react/no-unescaped-entities` — `"` 인라인은 `&quot;` escape 필수
- `react-hooks/purity` — `Date.now()` 같은 impure 함수는 render path 밖에서만 호출 (이벤트 핸들러 OK, render 중 ❌)
- `react-hooks/exhaustive-deps` — useEffect 의존성 명시
- `<pre>` 안 `JSON.stringify(data)` — `data: unknown` type 좁히기 (`!== undefined && !== null`)

## 5. 결정적 함정 정리 (변형 4 전용)

| 함정 | 원인 | 해결 |
|---|---|---|
| `--agents-md` default가 기존 AGENTS.md 덮어쓰기 | `create-next-app@latest`의 default | `/tmp/scaffold`에 생성 후 파일 선택 복사 |
| Next 15+/16 dynamic route `ctx.params` not await | `Promise<{...}>` 시그니처 변경 | `await ctx.params` |
| OAuth 토큰 race (401) | 캐시 만료 + 401 동시 | `cachedToken = null; continue;` 1회 재시도 |
| 422 메시지 매핑 누락 | toss 응답 envelope | `CODE_422_MESSAGES` dict 10종 매핑 |
| 429 backoff 무한 루프 | retry 카운트 미한정 | `MAX_RETRIES = 3` 상한 |
| DRY_RUN + 가드 1~6 이중 검사 누락 | tossFetch()와 safety.ts 책임 분리 모호 | **가드 1~5 = safety.ts (의도/맥락) + 가드 6 = tossFetch (HTTP/응답)** 명확 분리 |
| live 모드 테스트 telegramConfirmed 미포함 | 가드 5가 order endpoint에 적용 | 테스트 셋업에 `telegramConfirmed: true` 명시 |
| 모듈 스코프 store 격리 실패 | vitest worker 공유 | `_resetPendingStore()` export + beforeEach |
| TTL=0 만료 race | `Date.now()` ms 정밀도 | `expiresAt <= now` (동일 ms 인정) + 필요 시 `setTimeout(1ms)` |
| dev fallback vs 실제 봇 분기 | `TELEGRAM_BOT_TOKEN` 미설정 시 자동 confirm | dev fallback 명시 + README에 둘 다 설명 |
| React `react-hooks/purity` | `Date.now()` in render | `useEffect` 또는 이벤트 핸들러 안 |
| `react/no-unescaped-entities` | `"` 인라인 | `&quot;` escape |
| `<pre>` 안 `unknown` data | TypeScript narrow 필요 | `!== undefined && !== null` 가드 |
| TOSS_CLIENT_ID vs TOSSINVEST_API_KEY env 이름 충돌 | OPENAPI_REFERENCE.md vs README | **정식 = README (TOSS_CLIENT_ID)**, OPENAPI_REFERENCE.md 통일 |

## 6. 검증 체크리스트 (4단계 끝 시점)

- [ ] `npm run build` 0 에러
- [ ] `npm run lint` 0 errors, 0 warnings
- [ ] `npm run test` 38/38 PASS (telegram 13 + safety 25) — 또는 현재 구현 범위에 맞게
- [ ] 헤딩 정규화 0/0 깨짐 (bash + python 2중, 4파일)
- [ ] v0.3 자기 검증: `grep -rEn "openai|nim|anthropic|apiKey|BYOK|SettingsForm|ChatPanel" app/ components/ lib/` 0건
- [ ] 5 routes (정적 페이지 + 4 dynamic): `○ /`, `○ /_not-found`, `ƒ /api/telegram/callback`, `ƒ /api/telegram/send`, `ƒ /api/toss/[...path]`
- [ ] env 키 이름 통일 (TOSS_CLIENT_ID / TOSS_CLIENT_SECRET, TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID)

## 7. 다음 단계 후보

- 5단계: `components/Portfolio.tsx` (잔고 + 손익) + `app/page.tsx` 실시간 시세 fetch
- 6단계: `lib/notion.ts` + `app/api/notion/route.ts` + Notion DB 이력 기록
- 7단계: `vercel.json` + Vercel 배포 + env 등록
- 8단계: e2e 테스트 (Playwright 또는 실 toss API 통합 테스트)
