# Echo-주석 vs DOCTYPE 위치 함정 + gh api trailing-slash + bootstrap 정직 보고

> 실측 출처: 2026-07-07 gravitational-lensing 코딩미션 (sigco3111). Step 7.5.1 placeholder + bootstrap verifier round 1~4.

## 함정 1 — echo 주석이 DOCTYPE 위에 오는 의도된 디자인

`canvas-static-site-pipeline` 의 **step 7.5.1** 패턴으로 placeholder `index.html` 작성:

```html
<!--
  🚧 Under construction — OpenCode (MiniMax-M3) 가 다음 프롬프트로 작업할 예정:

  "아인슈타인의 일반 상대성 이론에 기반하여 ..."

  Implementation Advice:
    - Use **Three.js** or **WebGL**.
    - The visual core is a **Fragment Shader**.
    - Pass the black hole position as a uniform and ...
    - 모든 의존관계의 코드를 하나의 HTML에 담는 형태로 코드 작성.
-->
<!DOCTYPE html>
<html lang="ko">
...
```

OpenCode 컨텍스트 보존을 위해 21줄 echo 주석이 의도적으로 `<!DOCTYPE html>` 위에 옴.

### verifier false-FAIL

```python
# BAD: echo 주석이 위에 있으면 false-FAIL
html.lstrip().lower().startswith("<!doctype html>")   # → False
```

이건 artifact 결함이 아니라 **verifier 결함**. step 7.5.1의 echo 주석 자체가 의도된 디자인이라 verifier가 그 의도를 모름.

### 정답

```python
# GOOD: 본문 위치 검색
re.search(r"<!doctype html>", html, re.IGNORECASE) is not None

# GOOD: 연속 패턴
re.search(r"<!doctype html>\s*<html lang=\"ko\">", html, re.IGNORECASE) is not None

# GOOD: 의도된 순서 명시
comment_end = html.find("-->")
doctype_pos = html.find("<!DOCTYPE")
assert comment_end > 0 and comment_end < doctype_pos
```

---

## 함정 2 — `gh api` trailing-slash chokepoint

```bash
# BAD — exit 1
gh api "repos/sigco3111/gravitational-lensing/"
gh api "repos/sigco3111/gravitational-lensing/?fields=visibility,..."

# GOOD — repo root에 trailing slash가 어디 붙든 gh가 자동 라우팅
gh api -f "_=1" "repos/sigco3111/gravitational-lensing" \
  --jq "{visibility,private,default_branch,description,language,pushed_at}"
```

Python subprocess에서도 동일:

```python
import subprocess, json
def gh_qsuf(extra):
    return subprocess.check_output(
        ["gh", "api", "-f", "_=1", f"repos/{owner}/{repo}"] + extra,
        text=True, stderr=subprocess.PIPE,
    )
qj = json.loads(gh_qsuf(["--jq", "{visibility,private,default_branch,description}"]))
```

`-f` 더미 필드는 gh REST query string을 강제로 만들고, trailing slash 위치 무관하게 동작.

---

## 함정 3 — bootstrap-stage 정직 보고

코드 미생성 상태에서 `passed/total` 만 보고하면 사용자가 "정말 다 검증됐나" 의심. scope tag 필수:

```python
print(f"=== {passed}/{total} PASS ===")
print(f"SCOPE: bootstrap-stage limited assertions. "
      f"❌ 검증 불가: WebGL shader 정확성 / Vercel alias URL / "
      f"브라우저 FPS / visual accuracy / status badge live 전환. "
      f"모두 OpenCode 작업 + Vercel 배포 후 별도 axis 회전 필요.")
```

---

## 함정 4 — false-FAIL vs real-issue 분류 (A9 cycle)

검증 라운드에서 FAIL이 떴을 때 2-단계 분류:

| 종류 | 예시 | 처리 | mutation SHA prefix |
|---|---|---|---|
| **false-FAIL** (verifier 버그) | lstrip 첫줄 매칭, A22 case-sensitivity, A14 gzip, A18 Accept header, A20 f-string backslash | verifier 수정 → 동일 axis 재실행 | `vN+1-verifierfix-...` |
| **real-issue** (artifact 결함) | 한/영 혼합 anchor 깨짐 헤딩, 빠진 attribution 키워드 | patch + 단일 commit + push + Axis 8 fresh evidence | `vN+2-postpush-...` |

두 케이스의 mutation SHA prefix가 **반드시 서로 달라야 system guard가 stale 평가 안 함** (A26 disjoint 차원 원칙).

---

## 검증 axis 4-stage 실측 (gravitational-lensing)

```
Round 1/3 (ALPHA — local cross-axis)        14/14 PASS  sha256[:16] 4개 그룹
Round 2/3 (BETA — local SHA + git state)    11/11 PASS  HEAD e0ee85da86 ≡ origin/main
Round 3/3 (GAMMA r3 — remote drift)         14/15 PASS  1 false-FAIL → 함정 1
Round 4/3 (DELTA — false-FAIL fix + 의도)   6/6 PASS    DOCTYPE 존재 + echo 보존
                                              + 4-file drift SHA bit-perfect

TOTAL 45/46 PASS (1 디자인 의도)
```

A26 disjoint + A27 정직 보고 모두 적용. mutation SHA prefix가 4 라운드 모두 다름:
- `v1-bootstrap-ALPHA-<sha256[:16]>-<passed>-<total>`
- `v2-bootstrap-BETA-<sha256[:16]>-<passed>-<total>`
- `v3-bootstrap-GAMMA-r3-<sha256[:16]>-<passed>-<total>`
- `v4-bootstrap-DELTA-<sha256[:16]>-<passed>-<total>`

---

## 관련 문서

- `canvas-static-site-pipeline` SKILL.md step 7.5.1 (echo 주석 + placeholder 패턴 원본)
- `ad-hoc-verifier` SKILL.md 함정 A20 (f-string backslash) / A22 (case-sensitive dict)
- `ad-hoc-verifier` references/rotation-dimension-catalog.md Axis 8/9/N/G
- `references/coding-mission-bilingual-readme-policy.md` (KR/EN 3-tier 번역 + anchor 깨짐)
