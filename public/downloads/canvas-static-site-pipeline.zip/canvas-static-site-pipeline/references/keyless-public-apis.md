# Keyless Public APIs — 서버 없이 키 발급 없이 쓸 수 있는 공개 API 카탈로그

> 챌린지/사이드 프로젝트에서 **서버 0 + API 키 0** 원칙이 강하게 작용할 때 (2026-06-18 앱인토스 세션 학습), 대안으로 쓸 수 있는 무키 공개 API 모음.
> "이 데이터 필요해" → "이 API 무키로 쓸 수 있나?" 검증할 때 참조.

## 검증 원칙 (모든 API 공통)

무키 API라 해도 다음 4가지를 **curl로 직접 확인**해야 함 (브라우저/WebView에서 fetch 가능 여부 결정):

1. **키 없이 호출 가능** — `curl -sL <URL>` 응답 200 OK 확인
2. **CORS 허용** — `curl -sI -H "Origin: https://example.com" <URL>` → `access-control-allow-origin: *` 헤더 존재
3. **영구 무료 + 사용량 한도 합리적** — 1 사용자 1 세션에 5~10 호출 수준
4. **안정성** — 응답 시간 일관성 + 공식 문서 존재

## ✅ 검증 완료 무키 API (앱인토스 챌린지 dongne-today, 2026-06-18)

### 날씨 / 미세먼지 — Open-Meteo
| API | 엔드포인트 | 응답 |
|---|---|---|
| Forecast | `https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}&current={fields}&hourly={fields}&timezone=Asia%2FSeoul` | 현재+24~16일 hourly |
| Air Quality | `https://air-quality-api.open-meteo.com/v1/air-quality?latitude={lat}&longitude={lon}&current=pm10,pm2_5,european_aqi&hourly=pm10,pm2_5` | PM10/PM2.5 5일 hourly |
| Geocoding | `https://geocoding-api.open-meteo.com/v1/search?name={name}&count={n}&language=en` | 영문 주소→좌표 |

**특징**: 전세계, 한국 데이터 정확, hourly 시간당 갱신. 무료 한도 분당 600 req.

**CORS 검증 결과**:
```
$ curl -sI -H "Origin: https://apps-in-toss.toss.im" \
    "https://api.open-meteo.com/v1/forecast?latitude=37.5&longitude=127&current=temperature_2m"
access-control-allow-origin: *
access-control-allow-headers: accept, authorization, content-type, origin, ...
access-control-allow-methods: GET, POST, OPTIONS
```

**한국 좌표→주소(역지오코딩) 대안**:
| API | 비고 |
|---|---|
| Nominatim Reverse | `https://nominatim.openstreetmap.org/reverse?lat={lat}&lon={lon}&format=json` — CORS OK, **rate limit 1 req/sec** |

### 따릉이 (서울 자전거 공유)
```
http://openapi.seoul.go.kr:8088/{KEY}/json/bikeList/{start}/{end}/
```
**무키 호출**: `{KEY}=sample` (정상 동작, 영구). 정식 키 발급 시 quota ↑. 일일 quota 작음 (~500/day) → 사용자 늘면 정식 키 필요.

**CORS**: `Access-Control-Allow-Origin: *` ✅ (HTTP만, HTTPS 미지원이지만 OK)

### 공휴일 — Nager Date
```
https://date.nager.at/api/v3/PublicHolidays/{year}/KR
```
- 100+ 국가 공휴일 무료 조회
- 한국 공휴일 정확 (설날/추석/부처님 오신 날 등 음력 포함)
- 1년에 1번 fetch로 충분 (캐시 가능)

### 검증 명령어 모음 (복사해서 사용)
```bash
# 1. 무키 호출 가능 여부
curl -sL "https://api.open-meteo.com/v1/forecast?latitude=37.5665&longitude=126.9780&current=temperature_2m"

# 2. CORS 검증 (Origin 헤더 포함)
curl -sI -H "Origin: https://apps-in-toss.toss.im" \
    "https://api.open-meteo.com/v1/forecast?latitude=37.5&longitude=127&current=temperature_2m"

# 3. 따릉이 sample 키
curl -s "http://openapi.seoul.go.kr:8088/sample/json/bikeList/1/5/"

# 4. 공휴일
curl -s "https://date.nager.at/api/v3/PublicHolidays/2026/KR"
```

## ❌ 피해야 할 패턴 (2026-06-18 학습)

| 안티패턴 | 이유 |
|---|---|
| 기상청 단기예보 (data.go.kr) | `serviceKey` 필수 + 만료 관리 부담 |
| 에어코리아 (data.go.kr) | 키 발급 + quota 작음 |
| data.go.kr 문화행사 | 키 발급 필요 |
| 서울시 지하철/인구 sample | quota 작음 → 정식 키 필요 (만료 위험) |

**판단 기준**: 키 발급 + 만료 관리가 필요한 API는 **사이드 프로젝트/챌린지에서 회피**. 사용자가 챌린지 마감 후 6개월 이상 앱을 유지할 가능성이 있다면 특히.

## 일반화 — 어떤 무키 API를 우선 검토하나?

| 데이터 카테고리 | 무키 대안 |
|---|---|
| 날씨 | Open-Meteo, OpenWeatherMap (free tier), 7timer! |
| 미세먼지 | Open-Meteo Air Quality, aqicn.org (token 무필요 일부) |
| 공휴일 | Nager Date, date-holidays (npm) |
| 지오코딩 | Open-Meteo Geocoding, Nominatim, Mapbox (free tier) |
| 환율 | exchangerate.host (무키), Frankfurter (무키, ECB 기반) |
| 주식 (실시간 아님) | Yahoo Finance (yfinance, scraping), Alpha Vantage (free tier 25 req/day) |
| 뉴스 | NewsAPI (free tier), GDELT Project (무키) |
| 위키 | Wikipedia REST API (무키) |
| 공통 | public-apis/public-apis GitHub repo (4.7k+ API 목록) |

**핵심**: Public-APIs repo (`https://github.com/public-apis/public-apis`) 가 마스터 카탈로그. Auth 필드가 `No` 또는 `apiKey` 인 것 위주로 스크리닝.

## 참고 자료

- Public-APIs 카탈로그: <https://github.com/public-apis/public-apis> (Auth 필드로 무키/API 키 구분)
- Open-Meteo: <https://open-meteo.com/> (CC BY 4.0)
- Seoul Open Data: <https://data.seoul.go.kr/>
- Nager.Date: <https://date.nager.at/>
- OSM Nominatim 정책: <https://operations.osmfoundation.org/policies/nominatim/> (1 req/sec)