# Repolis fork + GitHub Pages 자동 활성화 워크플로

> 2026-06-23 sigco3111/Repolis 세션 검증. `hyeonsangjeon/Repolis` (Three.js + GitHub Pages 정적 사이트)를 fork하면서 **빌더 데이터 형식 단순화 + GitHub Pages 자동 활성화 + 6시간 cron 듀얼 트리거**까지 통합한 실전 케이스.

## 트리거 조건

다음이 모두 해당되면 본 워크플로 적용:
- "X 저장소처럼 우리도 할 수 있을까?" 류 fork 요청
- 원본 repo가 **단일 HTML + 빌더 + GitHub Pages** 구조 (Three.js, D3.js 등)
- 사용자 환경에 `gh auth` + repo scope 보유 (별도 PAT 불필요)
- 새로 만드는 데이터 수집 OSS가 있어, 원본 빌더 입력과 형식이 다름 (단순화 vs 어댑터 결정)

## 6단계 워크플로

### 1단계: Phase 0 스캔 (사용자 환경 + 원본 repo + 데이터 소스)
- 사용자 repo 카운트 + fork 분류 + 공개/비공개 + 언어 분포 (`gh repo list`)
- `gh auth status` → scope 확인 (`repo` 보유 시 PAT 불필요)
- 원본 빌더 입력 형식 vs 우리 신규 OSS 출력 형식 비교

### 2단계: 결정 포인트 4개 + 사용자 확인 (브레인스토밍)
- **스코프** (풀/핵심/MVP)
- **repo 필터** (전부/내가 만든 것만/내가 커밋한 것만)
- **빌더 단순화 vs 어댑터** (원본 빌더를 우리 출력에 맞게 단순화 OR 어댑터 계층 추가)
- **호스팅 + 트리거** (GitHub Pages + 6시간 cron + workflow_dispatch 듀얼)

**⚠️ 솔직 한마디 원칙**: 사용자가 "전부 다 표시" 같은 선택을 하면 시각화 미학 함정 경고. "데이터는 다 있지만, 사용자에게 보여줄 건지의 결정은 별개" (Articulation II 학습). 안전장치 (트래픽 기반 그라데이션) 옵션 함께 제시.

### 3단계: 데이터 백엔드 OSS 부트스트랩 (Phase 1 변형)
- `python-oss-bootstrap` 10단계 레시피 그대로
- **이름 결정 신중** (옵션 3개 + 추천). 예: `github-traffic-monitor` vs `gh-traffic-monitor` vs `repo-traffic-csv` → **B (짧고 호환성 높음)** 채택
- **데이터 소스 단일화** — 원본 빌더가 3-layer (logs/ + clones/ + metadata/)였으면 우리 신규 OSS는 1-layer (일별 CSV + 누적 CSV)로 단순화

### 4단계: 원본 fork + 빌더 단순화
```bash
# 1) 원본에서 빌더 + index.html + 핵심 자산만
gh api repos/{owner}/{repo}/contents/{path} | python3 -c "import json,sys,base64; print(base64.b64decode(json.load(sys.stdin)['content']).decode())" > {path}

# 2) .dotfile (.nojekyll, .gitignore 등) 은 f-string syntax error 회피
curl -sL https://raw.githubusercontent.com/{owner}/{repo}/main/{path} -o {path}

# 3) OWNER + meta tag + LIBREPO 일괄 교체
sed -i '' "s/const OWNER = 'X'/const OWNER = '{our_name}'/" index.html
sed -i '' "s|{owner}.github.io/X|{our_name}.github.io/{our_repo}|g" index.html

# 4) 빌더를 1-layer에 맞게 단순화
#    원본: sum_col() × 3 (logs + clones + metadata)
#    fork: load_cumulative_csv() 한 번 + gh API metadata
```

### 5단계: GitHub Pages 자동 활성화
**⚠️ 함정**: `gh repo edit --enable-pages` 옵션은 도움말만 출력하고 실제 활성화 안 됨.

**정답 (REST API 직접)**:
```bash
gh api repos/{owner}/{repo}/pages -X POST \
  -f build_type=legacy \
  -F 'source[branch]=main' \
  -F 'source[path]=/'
```
→ 응답 `html_url: https://{owner}.github.io/{repo}/`. 첫 빌드 1~2분 대기 후 `curl -sI ... | head -3` → `HTTP/2 200`.

### 6단계: 6시간 cron + workflow_dispatch 듀얼 워크플로
```yaml
# .github/workflows/refresh.yml
on:
  schedule:
    - cron: "0 */6 * * *"  # 6시간마다 (저장소 추가/삭제 6h 내 반영)
  workflow_dispatch:        # 수동 트리거 (`gh workflow run refresh.yml`)
  push:
    branches: [main]
    paths: ["scripts/build_repos.py", ".github/workflows/refresh.yml"]
```

## 검증 체크리스트 (보고 전 필수)

1. **Pages 라이브**: `curl -sI https://{owner}.github.io/{repo}/ | head -3` → `HTTP/2 200`
2. **OWNER 마커**: `curl -sL ... | grep "const OWNER"` → 우리 이름
3. **repos.json 통계**: `curl -sL .../repos.json | python3 -c "import json,sys; print(len(json.load(sys.stdin)))"` → 0 아니어야 함
4. **빌드 상태**: `gh api repos/{owner}/{repo}/pages` → `"status": "built"`
5. **repo 수 일치**: 빌더 출력 (로컬) vs Pages 응답 (curl) repo 수 동일
6. **언어 분포 일치**: 빌더 출력 언어 카운트 vs 사용자 환경 repo 언어 분포 (`gh repo list --json primaryLanguage`)

## 잘라낸 기능 큐 (Phase 6, 정직 보고)

| 기능 | 의도 | 시기 |
|---|---|---|
| WebLLM 택시 (WebGPU, ~1GB 다운로드) | 더 똑똑한 택시 | v0.2.0 |
| AI proxy 택시 (Vercel → Azure OpenAI) | 최고 품질 | v0.2.0 |
| Contribution Library 큐레이션 | sigco3111의 대표 repo (논문/강의/OSS) → 택시 "library" 안내 | v0.2.0 |
| Social preview 자동 생성 | 도시 썸네일 | v0.2.0 |

## ⚠️ 정직 한계 (보고 시 명시)

1. **첫 24~48h**: GitHub Traffic API가 visitor 데이터 노출에 시간 걸림. uniques=0 정상
2. **14일 룰**: GitHub이 14일 넘은 traffic 자체 삭제. 매일 실행 필수
3. **첫 날 트래픽 균등**: 156개 repo 도시 균일함 → 며칠 지나면 다운타운 입체화
4. **라이브러리/프록시 택시 생략**: 의존성 0 + 키 0 원칙

## 검증된 사례: sigco3111/Repolis (2026-06-23)

| 항목 | 값 |
|---|---|
| 원본 | hyeonsangjeon/Repolis (196 파일) |
| fork | sigco3111/Repolis (22 파일) |
| 신규 백엔드 OSS | sigco3111/gh-traffic-monitor v0.1.0 (23 tests, 23 파일) |
| 빌더 단순화 | 3-layer → 1-layer (`_cumulative.csv` 직접 read) |
| 첫 빌드 결과 | 155개 repo × 30 필드, 다운타운 14 + 동네 141 |
| 라이브 URL | https://sigco3111.github.io/Repolis/ (HTTP 200) |
| 자동 갱신 | 6시간마다 cron + workflow_dispatch 듀얼 |
| 소요 시간 | 약 1시간 (gh-traffic-monitor 30분 + Repolis fork 30분) |

## 재사용 체크리스트

다음 "X처럼 우리도 할 수 있을까?" 요청 시:

- [ ] `references/github-3d-visualization-fork-analysis.md` 5단계 분석 먼저
- [ ] 본 워크플로 6단계 적용
- [ ] 빌더 단순화 vs 어댑터 결정은 **단순화 우선** (유지보수 비용)
- [ ] GitHub Pages는 REST API 직접 (`gh api .../pages -X POST`)
- [ ] 6시간 cron + workflow_dispatch 듀얼 트리거
- [ ] 검증 체크리스트 6항목 모두 통과 후 보고