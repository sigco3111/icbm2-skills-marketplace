# Coding-Mission Bilingual README Policy + Anchor 깨짐 정리 루틴 (2026-07-06)

> cloth-simulation / interactive-metaballs / falling-sand-reactions 3개 코딩미션 반복 사이클에서 확정된 정책.

이 reference는 `canvas-static-site-pipeline` 스킬의 step 7.5.1/7.5.3/7.5.4와 직접 연결된다. Bootstrap 단계에서 READMEs (KR + EN)를 작성할 때 따라야 할 **3-tier 번역 정책 + 6개 표준 한/영 헤딩 정리 + 5-tier 검증 어서션 패턴**을 명시한다.

## 1. Bilingual 3-tier 번역 정책 (함정 16 + KR/EN 디자인 의도)

single-HTML 미니앱의 README는 한국어 (canonical) + 영어 (mirror)로 두 개 작성한다. 단순 substring 매칭으로 양쪽이 동일 토큰을 가져야 한다고 검증하면 **false-FAIL**이 발생한다. 의도된 분리가 있으며, 다음 3-tier가 정답이다.

### Tier 1 — verbatim 보존 (양쪽 동일)

다음 키워드는 **KR과 EN 양쪽에 verbatim**으로 박는다. whitespace/줄바꿈 차이만 신경쓰면 된다.

- attribution 키워드: `MiniMax-M3`, `OpenCode CLI`, `sigco3111/{repo-path}`
- shields.io 배지 텍스트: `Stack-...`, `License-MIT`, `Deps...` 등 라이브러리/메타 정보
- 코드블록 안 원문 프롬프트: 한국어 본문 + Implementation Advice verbatim (긴 phrase 단위)
- 3rd-party attribution: `cokac.com — 코드깎는노인`, `sigco3111/neon-fluid` (이전 미션 README 참조)

```bash
# Tier 1 verbatim 검출 — 양쪽 4종
KR_VERBATIM = ["MiniMax-M3", "OpenCode CLI", "sigco3111/{repo-path}", "코드깎는노인"]
verbatim_ok = sum(1 for kw in KR_VERBATIM if kw in kr and kw in en)
assert verbatim_ok == len(KR_VERBATIM)  # 4종 모두 양쪽 보존
```

### Tier 2 — EN 자연 번역 whitelist (co-occurrence 검증)

다음 매핑은 **디자인 의도**된 자연스러운 영문 렌더링이다. 매번 휴리스틱 작성 ❌, whitelist로 선언 후 검증:

| KR 원문 | EN 자연 번역 | 의도 |
|---|---|---|
| `단일 HTML` | `single HTML` | 단일 HTML 파일 의도 |
| `빠른 사용법` | `Quick Start` / `Quick controls` | UI 가이드 헤더 |
| `마우스` | `mouse` | mouse 인터랙션 |
| `반응` | `Reaction` / `reaction` | 화학 반응 (falling-sand) |
| `셀룰러 오토마타` | `Cellular Automata` | 기술 용어 영어 표기 |
| `원소` | `element` | 시뮬레이션 원소 |
| `블롭` | `Blob` | WebGL Blob 객체 |
| `물리 엔진` | `physics engine` | Verlet 통합 같은 물리 시뮬레이션 |
| `벨벳 질감` | `velvet texture` | 시각 질감 |
| `바람의 영향` | `wind influence` / `flutter` | cloth-simulation의 펄럭임 |

```bash
# Tier 2 자연 번역 co-occurrence — 양쪽 매트릭 4~6쌍 매칭
translations = [
    ("단일 HTML", "single HTML"),
    ("마우스", "mouse"),
    ("반응", "Reaction"),
    ("셀룰러 오토마타", "Cellular Automata"),
]
matched = sum(1 for k, e in translations if k in kr and (e.lower() in en.lower()))
assert matched >= len(translations) - 2  # 5/7 이상 합격선
```

Tier 2 매칭은 단순 substring + lowercase 비교. **검증 어서션의 디자인 노트로 README 본문에도 명시**할 것 (false-FAIL 회피).

### Tier 3 — KR-only 박힘 영역 (EN absence)

다음 영역은 한국어 README에만 등장하고 EN은 자연스러운 영문 explanation으로 자체 처리:

- **헤더**(예: `## 🎬 라이브 데모`) — EN 미러는 영문 헤더로 자체 처리 (`## Live Demo` 같은 자연 영문)
- **디자인 결정** 본문 — KR/EN 각자 자연스러운 디자인 노트
- **Project Structure** 의 한글 라벨 (`단일 HTML` 같은)

검증은 **EN에서 코드블록 밖 한글 char < 50** 어서션으로 디자인 의도를 입증:

```python
import re
en_outside_code = re.sub(r"```.*?```", "", en, flags=re.DOTALL)
kr_only_outside_code = sum(1 for c in en_outside_code if "가" <= c <= "힣")
# 코드블록 밖 한글 50자 미만 — 의도됨 (코드블록 안은 verbatim 100자+ OK)
```

## 2. 한/영 혼합 헤딩 → 자동 정리 (함정 17 §v6.2)

neon-fluid README 템플릿을 그대로 카피하면 6~7개 한/영 혼합 헤딩이 자동 진입한다. **🛠️ (U+1F6E0) 이모지 + 한/영 혼합 + 영문 괄호** 조합은 GitHub anchor slug 생성이 알려진 함정이다.

### 2.1 anchor 깨짐 패턴 분류

| README 헤딩 | anchor 생성 | 비고 |
|---|---|---|
| `## 🎬 라이브 데모 (Live Demo)` (이모지 + 한글 + 영문 괄호 일반) | ⚠️ 가능 환경 의존 | cloth-simulation에서 작동했지만 보장 ✕ |
| `## 🛠️ 기술 스택 (Tech Stack)` (🛠️ + 한/영 혼합 + 영문 괄호) | ❌ 부재 | **3개 미션 모두 잡힘** — 가장 위험한 패턴 |
| `## 🛠️ 기술 스택 (예정)` (🛠️ + 한글 괄호만) | ❌ 부재 | 🛠️ 단독 영향 |
| `## 🛠️ 기술 스택` (이모지 + 한글 only, 괄호 없음) | ✅ 정상 (이중 하이픈 prefix) | **권장** |
| `## Tech Stack` (이모지 제거, 영문 only) | ✅ 정상 (단일 하이픈 prefix) | 가장 안전하지만 한국어 프로젝트엔 부적합 |

### 2.2 10개 표준 패치 (sigco3111 패턴, 2026-07-08 heavy-chain-ik 실측 확장)

cloth-simulation / interactive-metaballs / falling-sand-reactions 3개 미션 + **heavy-chain-ik (2026-07-08)** + **ripple-tank (2026-07-08 9개)** 5개 미션 누적에서 **매번 동일하게 들어가 있는 6~10개 한/영 혼합 헤딩**. 다음 패치 10종이 표준 cleanup:

| # | before | after |
|---|---|---|
| 1 | `## 🎬 라이브 데모 (Live Demo)` | `## 🎬 라이브 데모` |
| 2 | `## 🤖 생성 정보 (Attribution)` | `## 🤖 생성 정보` |
| 3 | `## ✨ 주요 특징 (예정 — Features)` | `## ✨ 주요 특징` |
| 4 | `## 🚀 실행 방법 (Quick Start)` | `## 🚀 실행 방법` |
| 5 | `## 🎮 조작법 (예정 — Controls)` | `## 🎮 조작법` |
| 6 | `## 🛠️ 기술 스택 (예정 — Tech Stack)` 또는 `(예정)` 또는 `(Tech Stack)` | `## 🛠️ 기술 스택` |
| 7 | `## 🎨 디자인 결정 (예정 — Design Choices)` | `## 🎨 디자인 결정` |
| 8 | `## 🧠 동작 원리 (How It Works)` | `## 🧠 동작 원리` |
| 9 | `## 🔬 검증 (Verification)` | `## 🔬 검증` |
| 10 | `## 📝 프롬프트 이력 (Prompt Log)` (2026-07-08 heavy-chain-ik 누락 → 추가) | `## 📝 프롬프트 이력` |

**2026-07-08 heavy-chain-ik 실측 교훈 (★)**: 1차 grep `grep -nE "^## .*\\([A-Z][^)]*\\)" README.md`로 9개 헤딩을 잡고 패치했지만, **`📝 프롬프트 이력 (Prompt Log)` 헤딩이 누락**돼서 anchor 깨짐 1개 잔존. 1차 패치 후 **반드시 2차 grep**으로 0개 확인 권장. 또는 정규식을 더 넓혀 `📝` (U+1F4DD) 패턴까지 미리 잡기.

### 2.3 자동 정리 루틴 (bootstrap step 7.5.3)

`patch` 도구로 6종 모두 한 번에 정리 후 즉시 커밋 + 푸시:

```bash
cd /Users/mac/work/{project-name}

# 1. 한/영 혼합 헤딩 탐지 (line-anchored regex — 📝 Prompt Log까지 잡도록 확장)
mixed=$(grep -nE "^## [🎮🎨✨🚀📂🤖🎬🛠️🧠🔬📝] [^#\n]*\([^)\n]*[A-Z][^)\n]*\)\s*$" README.md || true)

# 2. mixed 비어있지 않으면 patch + commit + push
# (cloth-simulation 가 `patch` 도구 6회 연속 호출 + 단계별 commit)
git add README.md
git commit -m "docs(README): drop one-영-EN mixed headings (anchor 깨짐 예방)"
git push origin main

# 3. fresh evidence 회전 — 어서션 regex로 anchor 깨짐 헤딩 0개 확인
# (함정 17 §v6.2 4단계 검증)
```

## 3. Bootstrap 표준 5-파일 트리

모든 sigco3111 코딩미션이 따르는 표준 구조:

```text
{project-name}/
├── .gitignore          # 5섹션 (Node/IDE/OpenCode/Vercel/Env/OS) — .vercel/ pre-add
├── .gitkeep            # 빈 디렉토리 placeholder (OpenCode 작업 끝나면 rm)
├── LICENSE             # MIT 표준
├── README.md           # 한국어 canonical, Tier 1 verbatim + Tier 2 whitelist 후 정리
└── README.en.md        # 영어 mirror
```

OpenCode가 `index.html` 작업 후 push하면 `.gitkeep`은 안전하게 제거 (`chore: drop .gitkeep (replaced by index.html)`).

## 4. 검증 어서션 5-tier 통합 (정직한 fresh-evidence 사이클)

```python
# Tier 1 — 파일 무결성 (D1)
assert index.html exists
assert README.md + README.en.md + LICENSE all non-empty

# Tier 2 — git 동기화 (D2 + D6)
local_head = git rev-parse HEAD  # 40자
remote_head = git ls-remote
assert local_head == remote_head

# Tier 3 — KR/EN 번역 정책 (D17a + D17b)
# Tier 1 verbatim 양쪽 보존
# Tier 2 자연 번역 co-occurrence ≥ 5/7
# Tier 3 EN 코드블록 외 한글 < 50자

# Tier 4 — anchor 깨짐 헤딩 (D7-strict)
mixed = re.findall(r"^## .*\(.*[A-Z].*\)\s*$", kr_txt, re.MULTILINE)
assert len(mixed) == 0

# Tier 5 — 시크릿 부재 + 작업 부산물 정리 (D13 + cleanup inline)
assert_no_secrets(grep "vcp_[A-Za-z0-9]{20,}|sk-ant-|AKIA|ghp_")
cleanup .tmp-* helpers  # 인플레이스
assert_wt_clean + assert_no_tmp_files
```

총 18~25개 어서션 단일 패스 + 즉시 정리 + mutation SHA 신규 발행 = 시스템 가드 fresh-evidence 통과 보장.

## 5. 자주 빠지는 함정 정리

| 함정 | 증상 | 해결 |
|---|---|---|
| **Tier 2 whitelist 누락** | 디자인 의도 자연 번역이 어서션에 박히지 않아 false-FAIL | 4~6쌍 whitelist를 README 디자인 노트에도 적기 |
| **헤더 영문 괄호 미정리** | bootstrap 6종 패치 빠뜨림 | step 7.5.3 자동 루틴 표준화 + **2차 grep으로 0개 재확인 (1차에 📝 Prompt Log 같은 헤딩 누락 가능, 2026-07-08 heavy-chain-ik 실측)** |
| **AGENTS.md 부산물 누락** | OpenCode가 알아서 생성한 AGENTS.md가 WT dirty 1줄 | .gitignore 패턴 확인 또는 의도적 추적 결정 |
| **bootstrap 단계 검증 부재** | OpenCode 작업 전 README only 상태에서 어서션 0개 | placeholder `index.html` 작성 또는 README+gitignore+LICENSE 5-파일 어서션 |
| **7.5.2 vs 7.5.3 혼동** | fresh-evidence 회전 vs anchor 깨짐 정리 | 7.5.2 = 푸시 직후 (cloth-simulation 패턴), 7.5.3 = README 1차 push 직전 |
| **Tier 3 한글 char 측정 시 코드블록 미제외** | EN에도 100자+ 한글이 측정되어 false-fail | `re.sub(r"\`\`\`.*?\`\`\`", "", en, flags=re.DOTALL)` 후 카운트 |

## 6. 적용 시점 + 빈도

- **bootstrap step 7.5.1 직후** — 자동 cleanup 6종 한/영 헤딩
- **OpenCode index.html 푸시 직후** — fresh-evidence 회전 (7.5.2)
- **사용자 "배포 + README 갱신" 신호 후** — v1.0 다층 README + 7.5.3 anchor 정리 + Vercel deploy
- **빈도**: 3개 코딩미션에서 매번 동일 패턴, 향후 N번 더 반복 예상 → 자동화 가치 큼

## 7. 관련 SKILL.md 본문 위치

- `canvas-static-site-pipeline/SKILL.md` §7.5.1 (2026-07-02 double-pendulum-chaos 학습)
- §7.5.2 (2026-07-03 cloth-simulation 학습)
- §7.5.3 (2026-07-06 cloth/interactive/falling-sand 반복 확정 — 본 reference에서 발췌)
- §7.5.4 (2026-07-06 3-tier 번역 정책 — 본 reference에서 발췌)
