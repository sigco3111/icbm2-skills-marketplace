# 토스증권 Open API 사실관계 뱅크 (2026-07-09 sigco3111/toss-trader 실측 확정)

> 미래 세션에서 sigco3111이 토스증권 관련 작업 (toss-trader / 새 분석 도구 / 자동화 / MCP 서버) 을 시작할 때 **즉시 인용할 수 있는 단일 권위 사실관계**. kstost/stock + BEOKS/tossinvest-skill + JungHoonGhae/tossinvest-cli + 공식 overview.md 4중 교차 검증으로 확정.

## 1. 기본 정보

| 항목 | 값 | 출처 |
|---|---|---|
| 공식 endpoint | `https://openapi.tossinvest.com` | overview.md `servers` |
| 공식 문서 (SPA) | `https://developers.tossinvest.com/docs` | 200 OK |
| LLM 친화 인덱스 | `https://developers.tossinvest.com/llms.txt` | 200 OK, 마크다운 |
| Overview (마크다운) | `https://openapi.tossinvest.com/openapi-docs/overview.md` | 200 OK, source of truth |
| OpenAPI JSON | `https://openapi.tossinvest.com/openapi-docs/latest/openapi.json` | 200 OK |
| 인증 방식 | OAuth 2.0 Client Credentials Grant | overview.md |
| Token URL | `POST /oauth2/token` | overview.md |
| HTTP 클라이언트 ID/Secret 발급처 | 토스증권 WTS 로그인 → 설정 > Open API 메뉴 | overview.md "시작하기" |

## 2. 발급 자격 (자주 묻는 질문)

| 질문 | 답 | 비고 |
|---|---|---|
| 개인(사업자 아님)도 발급 가능한가? | ✅ **예** | WTS 로그인 + Open API 메뉴. 사업자등록증 불필요 |
| 모의투자/테스트 키 별도 존재? | ❌ **키 1종만** | `scopes: {}` 빈 객체. paper trading은 사용자 측 시뮬레이션 필수 |
| 키 1회 발급으로 모든 endpoint 접근? | ✅ **예** | OAuth scope 0개 = 시세/잔고/주문/체결 전부 가능 |
| 토큰 만료 시? | 동일 endpoint로 재발급 | refresh token 없음. 1 client당 유효 token 1개. 재발급 시 이전 token 즉시 무효화 |

## 3. 계좌 종류별 제약 (422 가드)

| 에러 코드 | HTTP | 의미 | 일반 개인 종합매매 계좌 |
|---|---|---|---|
| `account-restricted` | 422 | RIA/연금/종합매매 등 특수 계좌는 주문 ❌ | ✅ 영향 없음 (조회는 가능) |
| `prerequisite-required` | 422 | 약관 동의 + 위험 고지 미완료 시 주문 ❌ | 약관 동의 후 자동 통과 |
| `confirm-high-value-required` | 400 | **1억 원 이상 주문은 `confirmHighValueOrder: true` 필수** | 자동 가드 필요 |
| `edge-blocked` | 403/404 | 허용되지 않은 요청 | 보통 IP/geo 차단 |
| `forbidden` | 403 | 권한 부족 | 키 종류/스코프 문제 |

## 4. Rate Limits (overview.md 기준)

| Group | 요청 한도 | 비고 |
|---|---|---|
| `AUTH` | 5/s | 토큰 발급 |
| `ACCOUNT` | **1/s** | 가장 빡빡 |
| `ASSET` | 5/s | 보유 자산 조회 |
| `STOCK` | 5/s | 종목 마스터 |
| `MARKET_INFO` | 3/s | 환율/캘린더 |
| `MARKET_DATA` | 10/s | 호가/현재가/체결/상하한가 |
| `MARKET_DATA_CHART` | 5/s | 캔들 |
| `RANKING` | 5/s | 랭킹 |
| `MARKET_INDICATOR_PRICE` | 10/s | 지수 현재가 |
| `MARKET_INDICATOR` | 10/s | 지수 |
| `MARKET_INDICATOR_CHART` | 5/s | 지수 캔들 |
| `ORDER` | 6/s | **09:00~09:10 KST: 3/s** |
| `ORDER_HISTORY` | 5/s | 주문 조회 |
| `ORDER_INFO` | 6/s | 매수 가능 금액 등. **09:00~09:10 KST: 3/s** |
| `CONDITIONAL_ORDER` | 5/s | 조건주문 |
| `CONDITIONAL_ORDER_HISTORY` | 10/s | 조건주문 조회 |

응답 헤더 4종: `X-RateLimit-Limit` / `X-RateLimit-Remaining` / `X-RateLimit-Reset` / `Retry-After` (429만).

## 5. 주요 endpoint 카테고리

### 5.1 인증 (토큰만)

- `POST /oauth2/token` — OAuth2 액세스 토큰 발급 (Client Credentials Grant)

### 5.2 시세·종목·시장 (토큰만)

- `GET /api/v1/orderbook` — 호가 조회
- `GET /api/v1/prices` — 현재가
- `GET /api/v1/trades` — 최근 체결
- `GET /api/v1/price-limits` — 상/하한가
- `GET /api/v1/candles` — 캔들 (1분봉/일봉)
- `GET /api/v1/stocks` — 종목 기본 정보
- `GET /api/v1/stocks/{symbol}/warnings` — 매수 유의사항
- `GET /api/v1/exchange-rate` — KRW↔USD 환율
- `GET /api/v1/market-calendar/{KR|US}` — 장 운영 캘린더
- `GET /api/v1/rankings` — 거래대금/거래량/등락률 랭킹
- `GET /api/v1/market-indicators/prices` — 지수 현재가
- `GET /api/v1/market-indicators/{symbol}/candles` — 지수 캔들
- `GET /api/v1/market-indicators/{symbol}/investor-trading` — 투자자별 매매대금

### 5.3 계좌·자산 (토큰 + `X-Tossinvest-Account` 헤더)

- `GET /api/v1/accounts` — 계좌 목록
- `GET /api/v1/holdings` — 보유 주식 (상세 + 평가 합산)

### 5.4 주문 (토큰 + `X-Tossinvest-Account` 헤더)

- `POST /api/v1/orders` — 주문 생성 (지정가/시장가, KR/US)
- `POST /api/v1/orders/{orderId}/modify` — 정정 (가격/수량)
- `POST /api/v1/orders/{orderId}/cancel` — 취소
- `GET /api/v1/orders` — 주문 목록 (대기중/종료)
- `GET /api/v1/orders/{orderId}` — 주문 상세
- `GET /api/v1/buying-power` — 매수 가능 금액
- `GET /api/v1/sellable-quantity` — 판매 가능 수량
- `GET /api/v1/commissions` — 매매 수수료

### 5.5 조건주문 (토큰 + `X-Tossinvest-Account` 헤더)

- `POST /api/v1/conditional-orders` — SINGLE/OCO/OTO 등록
- `POST /api/v1/conditional-orders/{id}/modify` — 수정
- `DELETE /api/v1/conditional-orders/{id}` — 취소
- `GET /api/v1/conditional-orders` — 목록 (진행중/종료)
- `GET /api/v1/conditional-orders/{id}` — 상세

## 6. sigco3111 동일 카테고리 경쟁자 (벤치마크)

| 리포 | stars | 언어 | 특징 |
|---|---|---|---|
| `BEOKS/tossinvest-skill` | 40⭐ | Python | Agent skill. OAuth + dry-run CLI + 자율 매수/매도 루프 |
| `JungHoonGhae/tossinvest-cli` | 440⭐ | Go | CLI + MCP 서버 (`tossctl mcp`). 21개 WTS 전용 기능 + 공식 100% |
| `dd3ok/tossinvest-api-skill` | 3⭐ | ? | 로그인 없이 시장 데이터 (비공식) |
| `scjang01/tossinvest-mcp` | 1⭐ | ? | MCP 서버 |

`toss-trader`는 이 카테고리 4번째. 차별화 포인트: **oh-my-opencode 분석 + paper-trading-first 안전장치 + Telegram inline confirm**.

## 7. 자주 빠지는 함정 4가지

| 함정 | 증상 | 해결 |
|---|---|---|
| `openapi.tossinvest.com` 직접 호출 | 404 (kstost/stock의 README URL 패턴) | `/openapi-docs/overview.md` 또는 `/oauth2/token` 직접 |
| SPA docs를 curl로 읽으려 함 | shell HTML (JS-rendered, 본문 0) | `/llms.txt` 우선 |
| 모의투자 endpoint 존재 가정 | 없음. 키 1종 = 실계좌 | paper trading은 사용자 측 시뮬 (`broker/paper.py`) |
| 사업자 등록증 요구 가정 | 일반 개인 종합매매 계좌면 OK | WTS 로그인 → 설정 > Open API 메뉴 |

## 8. 우리 toss-trader 설계에 미치는 함정 영향

| 영역 | 영향 |
|---|---|
| 사용자 자격 검증 | ❌ 사업자 등록증 요구 코드 작성 ❌. WTS 계좌 보유자면 OK |
| Dry-run 가드 | `safety.py`에 `DRY_RUN=true` 환경변수 + `confirmHighValueOrder` 자동 가드 + Telegram inline confirm 3중 |
| Rate limit 대응 | ACCOUNT 1/s 빡빡. 30초 간격 watch 모드면 OK. ORDER 6/s는 빠른 주문 루프 시 throttle |
| Paper trading | `broker/paper.py` 자체 구현 필수. 토스 API는 paper 모드 0 |

## 9. 출처 추적

| 사실 | 출처 URL |
|---|---|
| endpoint URL | `openapi.tossinvest.com/openapi-docs/overview.md` (`servers` 섹션) |
| OAuth Client Credentials | overview.md `### 인증` |
| Token URL `/oauth2/token` | overview.md + openapi.json `/paths/~1oauth2~1token/post` |
| scope 0개 | openapi.json `components.securitySchemes.oauth2ClientCredentials.flows.clientCredentials.scopes = {}` |
| Rate limit 표 | overview.md `## Rate Limits` |
| 422 에러 코드 표 | overview.md `## 에러 응답` (HTML table) |
| WTS 로그인 → Open API 메뉴 | overview.md `## 시작하기` "1. 클라이언트 등록" |
| 신청자 롤아웃 중 | `JungHoonGhae/tossinvest-cli` README "공식 Open API 는 사전 신청자 대상으로 단계적 롤아웃 중" |

## 10. 적용 시점

- **sigco3111이 토스증권 관련 새 프로젝트 시작 시** — 본 reference 박은 후 toss-trader의 `references/official-overview.md` 사본 박기
- **sigco3111/toss-trader README/AGENTS.md 정정 시** — §2(발급 자격), §3(422 가드), §4(rate limit), §8(우리 설계 영향) 섹션 인용
- **다른 사용자가 토스 Open API 물어볼 때** — 본 reference가 단일 권위 답. 추측 금지