# OpenCode / 외주 도구 산출물 vs Git 추적 함정

> 2026-06-29 neon-fluid README+Vercel 배포 세션에서 학습한 함정 모음. OpenCode, oh-my-openagent, Playwright MCP 등 외부 도구가 워크스페이스에 남기는 산출물을 Git에 추적하지 못해 발생하는 배포/보안 문제.

## 🚨 핵심 함정 4가지

### 1. `index.html`이 로컬에만 존재 + GitHub엔 부재

OpenCode/Claude Code 같은 코딩 에이전트가 워크스페이스에 `index.html`을 생성했지만 `git add` 안 된 상태에서 Vercel 배포가 진행되면:

- 로컬 파일 시스템: `~/work/neon-fluid/index.html` 존재
- GitHub: 커밋 안 됨
- Vercel: `vercel deploy --prod --yes` → Vercel이 **GitHub에 푸시된 것만 배포** (Git 연결 자동 모드일 때) → README만 배포 → 라이브 페이지가 사실상 빈 페이지

**증상**: Vercel URL은 200이지만 body에 시뮬레이션 코드 없음. 사용자가 "왜 화면이 안 뜨지?"

**해결 — 배포 전 필수 확인**:
```bash
# GitHub에 푸시된 파일 목록 확인
cd ~/work/{project}
git ls-files

# 결과에 index.html 있는지 확인
# 없으면 → `git add index.html && git commit && git push` 선행 후 `vercel deploy`
```

**확정 절차** — `vercel deploy` 실행 직전:
1. `git status -s` — untracked 파일 있는지 확인
2. `git ls-files | grep -E "(index\.html|app\.js)$"` — 핵심 자산이 추적 중인지 확인
3. 없으면 사용자에게 **명시적 확인** 후 커밋/푸시
4. 그래도 Vercel만 믿고 진행하면 라이브 페이지가 비어있음

---

### 2. 외부 도구 산출물 디렉토리 무심코 커밋

OpenCode + oh-my-openagent를 워크플로에서 쓰면 워크스페이스에 다음 산출물들이 자동 생성됨:

| 디렉토리/파일 | 생성 도구 | 위험 |
|---|---|---|
| `.codegraph/` | oh-my-openagent의 코드 그래프 분석 | 내부 분석 데이터, 사이즈 큼 (~수 MB) |
| `.omo/` | oh-my-openagent 설정/캐시 | 사용자별 캐시, 다른 사람과 공유 시 혼란 |
| `.playwright-mcp/` | Playwright MCP 세션 캐시 | 브라우저 세션 스냅샷 |
| `.DS_Store` | macOS Finder | 메타데이터만, 의미 없음 |

**모두 `.gitignore`에 추가 권장**.

**표준 `.gitignore` (Canvas/정적 웹 프로젝트)**:
```gitignore
# macOS
.DS_Store

# 외부 AI 도구 산출물
.codegraph/
.omo/
.playwright-mcp/

# IDE/에디터
.vscode/
.idea/
*.swp

# Node (만약 Vite 등 도입 시)
node_modules/
dist/

# Python (스크립트 도구 있을 때만)
__pycache__/
*.pyc
.venv/

# 환경
.env
.env.local

# 임시 산출물
*.tmp
*.bak
```

**주의**: `.gitignore` 추가는 이번 세션 작업과 별도 단계로 사용자에게 확인 후 진행. **무심코 커밋하면 안 됨**.

---

### 3. `vercel deploy --yes` 의 GitHub 자동 연결

Vercel CLI는 `vercel deploy --prod --yes` 한 방으로 다음을 자동으로 처리:

1. 현재 디렉토리의 Git remote 감지
2. `origin` 원격이 있으면 자동으로 GitHub repo 연결
3. `package.json`/`vercel.json`/`index.html` 등 자산 스캔
4. 빌드 명령 자동 추론 (없으면 skip)
5. 프로덕션 도메인 할당 (`<project>-<hash>-<username>.vercel.app`)
6. 팀 alias 자동 생성 (`<project>-<color>.vercel.app`)

**한 방으로 끝나서 GitHub Actions/Vercel 대시보드 Git 통합 같은 별도 설정이 불필요**. 하지만 그만큼 **GitHub에 푸시 안 된 자산은 배포 안 됨** (함정 1과 연결).

**확인 절차**:
```bash
cd ~/work/{project}
vercel deploy --prod --yes 2>&1 | tail -30
# 출력의 핵심 라인:
# > Connecting GitHub repository: https://github.com/{user}/{repo}
# > Connected
# > Uploading [...] (X.XkB/X.XkB)
#   Production      https://{project}-{hash}-{user}s-projects.vercel.app
# ▲ Aliased         https://{project}-{color}.vercel.app
# ✓ Ready in Ns
```

**GitHub 연결 안 됐을 때**:
- `vercel link --yes` 먼저 실행 후 `vercel deploy --prod`
- 또는 Vercel 대시보드에서 수동으로 GitHub repo 연결

---

### 4. workspace 디렉토리 ≠ Git 디렉토리 불일치

같은 프로젝트라도 작업 위치가 두 군데일 수 있음:

| 위치 | 예시 | 비고 |
|---|---|---|
| `~/Desktop/project/work/ai/{name}` | 06-11 Artemis 표준 경로 | GitHub push의 단일 진실 소스 |
| `~/work/{name}` | sigco3111의 작업 표준 | `neon-fluid`도 여기에 있었음 |
| `/tmp/{name}` | 임시 작업 | push 안 함 |

**시작 단계에서 디렉토리 위치를 한 번에 확정**:
```bash
# 세션 시작 시 "어디에 있어?" 빠르게 확인
pwd && git -C "$(pwd)" remote -v 2>&1 | head -3
# 또는
ls ~/work/{name}/.git 2>&1
```

**Git 디렉토리 ≠ 작업 디렉토리 함정**: `cd /tmp/foo`에서 작업하다가 다른 디렉토리에 push하는 경우. **항상 `git rev-parse --show-toplevel`로 Git 루트 확인**.

---

## 📋 체크리스트 (Vercel 배포 전)

```
[ ] 작업 디렉토리가 Git 루트인지 확인 (git rev-parse --show-toplevel)
[ ] git remote -v 에 origin이 올바른 GitHub repo 가리키는지
[ ] git status -s 로 untracked 자산 (특히 index.html) 모두 식별
[ ] .gitignore에 외부 도구 산출물 (.codegraph, .omo, .playwright-mcp, .DS_Store) 등록
[ ] git ls-files | grep -E "(index\.html|app\.js)$" 핵심 자산 추적 중 확인
[ ] git push origin main 으로 GitHub 최신화
[ ] vercel deploy --prod --yes
[ ] curl -sI https://{project}-{color}.vercel.app HTTP 200 확인
[ ] curl -s {URL} | grep -E "{고유키워드}" 라이브 body에 코드 포함 확인
[ ] GitHub raw + Vercel 둘 다 핵심 키워드 포함 여부 검증
```

---

## 🤝 사용자 확인이 필요한 결정 3가지

다음과 같은 결정 포인트는 **clarify로 사용자에게 묻고 진행** (그냥 추측하지 말 것):

| 결정 | 옵션 A | 옵션 B | 옵션 C |
|---|---|---|---|
| **.gitignore 추가 시점** | 이번 배포 전 같이 | 다음 세션 별도 작업 | 추가 안 함 |
| **외부 산출물 폴더 보관** | .gitignore만 (커밋 X) | 추적 O (재현 가능) | 삭제 (trash) |
| **GitHub 푸시 누락 자산** | 푸시 O (지금) | 푸시 X (다음에) | Vercel만 (GitHub 빈 상태) |

---

## 🔗 참고 사례
- **neon-fluid 06-29** — OpenCode로 생성된 `index.html`이 GitHub에 미푸시 상태로 Vercel 배포 직전 발견. 사용자 명시 확인 후 `index.html`도 푸시 → 정상 배포.
