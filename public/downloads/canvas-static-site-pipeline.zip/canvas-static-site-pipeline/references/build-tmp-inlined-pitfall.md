# Build.js /tmp/ Inlined Single-HTML Pitfall (2026-07-08 voronoi-glass-fracture 실측)

> Vercel 배포 1회 전에 발견된 함정: `index.html`은 인라인 단일 HTML로 보이지만, 같은 워크스페이스의 `build.js`가 `/tmp/<name>-deps/`에서 의존성을 합치는 구조. 직접 Vercel에 push하면 `/tmp/`가 Vercel 빌드 컨테이너에 없으므로 **자동으로 깨짐**.

## 🚨 함정 시나리오

1. OpenCode/Claude Code 같은 외부 도구가 워크스페이스에 `index.html`을 생성
2. 함께 `build.js`도 생성 — `fs.readFileSync('/tmp/<name>-deps/matter.min.js', ...)` 같은 식으로 `/tmp/` 디렉토리에서 라이브러리를 읽어 concat
3. 결과물 `index.html`은 self-contained (모두 인라인)
4. Vercel deploy 시: `git push` → Vercel 빌드 컨테이너 → `/tmp/<name>-deps/` 없음 → ❌ 의존성 누락 또는 빌드 실패

이 시나리오에서 **로컬에서는 정상 작동하지만 Vercel에서는 깨짐**. ripgrep으로 `Matter.js failed to load` 같은 메시지 떨어지면 시작이 안 됨.

## voronoi-glass-fracture 실측 (2026-07-08)

```bash
$ ls /Users/mac/work/voronoi-glass-fracture/
.codegraph/         # OpenCode 메타 (심볼릭)
.omo/               # OpenHands 디바이스 부산물
.DS_Store
.git/
.gitignore
README.md
build.js            # ← /tmp/voronoi-deps/에서 읽음
index.html          # 130,094B, self-contained 확인됨
$ head -10 build.js
// One-shot build for index.html — uses concatenation (not template literal)
// so the inlined d3-delaunay backticks don't break parsing.
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname);
const MATTER_SRC = fs.readFileSync('/tmp/voronoi-deps/matter.min.js', 'utf8');
const D3_SRC    = fs.readFileSync('/tmp/voronoi-deps/d3-delaunay.min.js', 'utf8');
```

**결과**: `index.html` 자체는 외부 `<script src>` 0개, 모두 인라인 → Vercel 배포 **정상 동작** (HTTP 200 + 130,094B bit-perfect). `build.js`는 로컬 재현 스크립트일 뿐 배포에 영향 없음.

**그래도 위험**: OpenCode가 다음 미션에서 `/tmp/` 외부 의존성을 인라인하지 못하면 `index.html`이 자동으로 깨질 수 있음.

## ✅ Vercel 배포 전 self-contained 검증 5종 grep

```bash
cd /Users/mac/work/<project>

# 1) 외부 CDN script src 0개 확인 (가장 흔한 함정)
grep -oE '<script[^>]*src=[^>]*>' index.html | grep -vE 'data:|inline' | head -10
# → 출력 0줄이어야 OK. 있으면 jsdelivr/unpkg/CDN 의존성

# 2) 절대경로 / 파일 시스템 참조 부재 확인 (/tmp/, /var/, /Users/mac/...)
grep -nE '/tmp/|/var/folders|/Users/[^"'\'' ]+\.(js|min\.js|css)' index.html | head -10
# → 출력 0줄이어야 OK. 있으면 빌드 의존

# 3) localStorage / Worker / 동적 import 부재 확인
grep -cE 'localStorage|Worker\(|import\(|fetch\(' index.html
# → 큰 수치 (예: 5+) 발견되어도 정상이지만, 외부 URL은 점검

# 4) import / require 부재 확인 (Node.js 빌드 산출물 흔적)
grep -cE 'require\(|import .* from ' index.html
# → ES module `import`는 정상이지만 `require(`는 빌드 산출물 잔재

# 5) build.js 외 의존성 산출물 부재 확인
ls -la build*.js bundle*.js concat*.js 2>&1 | head -5
# → 0줄 OK. 있으면 인라인 의존성 점검 필요
```

5종 모두 0 또는 정상이면 self-contained로 간주. `index.html`을 그대로 `vercel deploy` 가능.

## 🛠️ 안전한 패턴: build.js를 빌드 디렉토리로 격리

`/tmp/`가 위험하다면, 빌드 산출물을 **`./.build-cache/` 같이 워크스페이스 내** 디렉토리에 두기:

```bash
# build.js — /tmp 대신 ./.build-cache/ 사용
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname);
const CACHE = path.join(ROOT, '.build-cache');

const MATTER_SRC = fs.readFileSync(path.join(CACHE, 'matter.min.js'), 'utf8');
const D3_SRC     = fs.readFileSync(path.join(CACHE, 'd3-delaunay.min.js'), 'utf8');
```

```bash
# .gitignore에 .build-cache/ 추가
echo '.build-cache/' >> .gitignore

# 빌드 산출물 캐시는 git 추적 안 됨, 워크스페이스에 영구 보존
```

이 패턴의 장점:
- `/tmp/` 휘발성 함정 회피 (macOS 재부팅 후 사라지지 않음)
- `.gitignore`로 git 추적 제외, 디스크는 유지
- 팀원이 클론 후 `npm run build` 한 번이면 캐시 재생성

## 📋 배포 전 체크리스트 (3종)

```
[ ] grep으로 외부 script src 0개 확인
[ ] grep으로 /tmp /Users 의존성 부재 확인
[ ] build.js가 .build-cache/ 같은 워크스페이스 내 경로 사용
```

## 🔗 관련 reference

- `references/single-html-static-hosting-pitfalls.md` §5 (visibility + pointer-events 부재 패턴)
- `references/opencode-generated-files-pitfalls.md` §OpenCode 도구 산출물 .gitignore 처리
- SKILL 본문 step 5.5 self-check — bit-perfect 사이즈 검증과 함께 사용

## ⚡ 빠른 진단 명령어 (bit-perfect)

```bash
LOCAL=$(wc -c < index.html | tr -d ' ')
REMOTE=$(curl -sS -o /dev/null -w "%{size_download}" -A "Mozilla/5.0" \
  https://<project-name>.vercel.app/)
HTTP=$(curl -sS -o /dev/null -w "%{http_code}" -A "Mozilla/5.0" \
  https://<project-name>.vercel.app/)
echo "Local: $LOCAL bytes | Remote: $REMOTE bytes | HTTP: $HTTP"
# ✓ 130094 ≡ 130094 + HTTP 200 = PASS
# ✗ size mismatch = Vercel 캐시 or push 누락
# ✗ HTTP 5xx = 빌드 실패 (이 reference의 함정일 가능성 ↑)
```
