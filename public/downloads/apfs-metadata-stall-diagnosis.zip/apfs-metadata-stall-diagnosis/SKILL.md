---
name: apfs-metadata-stall-diagnosis
description: APFS/Spotlight 메타데이터 스톨 진단 + 회복 패턴 — 크론 스크립트나 파일 read가 hang할 때 inode-통과/read-hang 비대칭을 감지하고 우회하는 클래스
tags: [diagnostics, filesystem, apfs, macos, cron-failure]
---

# APFS 메타데이터 스톨 — 진단 + 회복

## 트리거 조건

다음 증상이 **모두** 동시에 나타날 때 이 스킬을 적용:

- `bash <script>`, `cat <file>`, `head <file>`, `cp <file>` 같은 **블럭 read / 스크립트 실행이 무한 hang**
- stderr/stdout 0 bytes, 모든 타임아웃(60s/120s/300s) 발동
- 동시에 `stat <file>`, `test -f <file>`, `readlink -f <file>` 같은 **inode 메타데이터 호출은 정상 응답**
- `lsof <file>` 비어있음 (잠금 아님)
- `df -h <mount>` 정상 (디스크 여유 충분)
- `pkill -f <script>` 후 재시도해도 같은 패턴 반복

이런 비대칭은 APFS 또는 Spotlight 메타데이터 인덱서 스톨의 전형적 시그니처.

## 진단 매트릭스

| 명령 | hang 패턴에서 | 의미 |
|------|--------------|------|
| `stat -f "%N %z" <file>` | ✅ 통과 | inode 메타데이터 정상 |
| `test -f <file>` | ✅ 통과 | path resolve 정상 |
| `readlink -f <file>` | ✅ 통과 | canonical path 정상 |
| `cat <file>` | ❌ **hang** | 블럭 read 실패 |
| `head <file>` | ❌ **hang** | 블럭 read 실패 |
| `cp <file> /tmp/` | ❌ **hang** | 블럭 read 실패 |
| `file <file>` | ❌ **hang** | magic-bytes read 실패 |
| `mdls <file>` | ❌ **hang** | Spotlight read 실패 |
| `md5 -q <file>` | ❌ **hang** | 블럭 read 실패 |
| `ls <parent dir>` | ❌ **hang** | 디렉터리 열거 실패 |
| `lsof <file>` | ✅ 비어있음 | 잠금 아님 |
| `df -h <mount>` | ✅ 정상 | 디스크 정상 |
| `sample <pid>` | bash가 `main`에 머무름, 자식 0개 | read() syscall에서 블럭 |

inode 통과 + read hang = **APFS 메타데이터 스톨 확정**.

## 흔한 트리거 시나리오

- `/Users/mac/Desktop/project/work/<repo>` 같이 sibling에 파일이 많은 경로 (Jekyll/Astro/Next.js 빌드 디렉터리)
- iCloud 동기화 영향권 (`~/Desktop`, `~/Documents`)
- Time Machine 스냅샷 생성 중
- Spotlight 재인덱싱 직후

## 회복 패턴 (위에서 아래로 시도)

### 1. 즉시 — 좀비 정리 + 캐시 flush
```bash
pkill -f <script-name>           # hang 중인 스크립트 강제 종료
lsof <file>                       # 재확인 — 비어있어야 함
sync                              # 파일시스템 캐시 flush 후 재시도
```

### 2. 경로 우회 — 가장 확실
같은 repo를 깨끗한 경로에 fresh clone 후 거기서 실행:
```bash
git clone <repo> /Users/mac/work/<repo>
cd /Users/mac/work/<repo>
bash <script>
```

### 3. 마운트 사이클 (관리자 권한 필요)
```bash
diskutil unmount /Users/mac/Desktop/project/work
diskutil mount /Users/mac/Desktop/project/work
```
macOS가 마운트 캐시를 비우면서 메타데이터 인덱스를 재구축.

### 4. 근본 회피 — 경로 재배치
저장소를 공유 빌드 디렉터리 / iCloud 동기화 영향권에서 격리:
- ❌ `/Users/mac/Desktop/project/work/`
- ✅ `/Users/mac/work/`, `/Users/mac/code/`, `~/.local/share/`

## 🚨 절대 금지 — 합성된 fake success

스크립트가 hang으로 실행되지 않았는데 다음 출력을 절대 만들지 말 것:
- ❌ `"no changes detected"` (실제로는 실행 안 됨)
- ❌ `"pushed successfully"` (푸시 안 됨)
- ❌ `"0 changes, 0 commits"` (git도 안 돌았을 수 있음)

대신 정직하게 블로커 보고:
- 진단 표 + 어느 명령이 hang했는지
- 위 회복 패턴 중 1~2번 권장 사항
- "배포 액션 미수행, 다음 세션에서 N번 옵션으로 재시도 권장" 명시

이것은 SOUL.md 가이드라인 "Reporting a blocker honestly is always better than inventing a result"의 직접 적용.

## 검증 절차

회복 후 다음을 모두 통과해야 정상:

1. `cat <file> | head` 즉시 응답 (< 1s)
2. `ls <parent>` 즉시 응답
3. `bash <script>` 완료 + exit 0
4. (푸시 크론의 경우) `git log origin/main..HEAD`에 새 커밋 존재
5. (GitHub Pages의 경우) GitHub Actions 워크플로 `pages build and deployment` 성공

## 재발 방지

hang이 자주 발생하는 경로는 memory에 "⚠️ APFS 스톨 위험 경로"로 기록:
- 다음 세션이 그 경로를 처음부터 회피
- cron 잡 생성 시 working directory도 안전한 경로로 지정
- 가능하면 sync 스크립트 내부에서 hang 감지 후 자동 fail-fast (타임아웃 wrapping)

## 출처

2026-07-21 skills-showcase cron 세션 — `bash /Users/mac/Desktop/project/work/icbm2-skills-marketplace/scripts/sync-skills.sh` 300s 타임아웃. `stat`/`test -f`/`readlink` 통과, `cat`/`cp`/`file`/`mdls`/`md5`/`ls <parent>` 전부 hang, `lsof` 깨끗, `df -h` 정상. `pkill` 후에도 재시도 동일 hang. **가짜 "no changes" 출력 거부, 블로커 정직 보고.**