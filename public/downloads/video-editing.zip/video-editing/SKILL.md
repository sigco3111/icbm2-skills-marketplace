---
name: video-editing
description: FFmpeg 기반 비디오 편집 자동화 — 자르기, 병합, 포맷 변환, 자막, 워터마크, 속도 조절, 압축, 컬러 보정, 오디오 싱크 등
allowed-tools: ["terminal", "read_file", "write_file", "search_files", "execute_code"]
---

# Video Editing — FFmpeg Automation

FFmpeg 기반 비디오/오디오 편집 자동화 스킬. 자연어 요청을 FFmpeg 명령어로 변환하여 실행.

## 언제 사용

- ✅ 영상 자르기/trim, 병합/concat
- ✅ 포맷 변환 (mp4, mkv, webm, mov, avi)
- ✅ 해상도/비율 변경 (16:9, 9:16, 1:1, 21:9)
- ✅ 압축/품질 조절 (CRF)
- ✅ 오디오 추출/제거/교체/믹싱
- ✅ 속도 조절 (슬로모션, 타임랩스)
- ✅ 자막 입히기, 워터마크
- ✅ 회전/플립, GIF 변환
- ✅ 썸네일/스크린샷 추출
- ✅ 컬러 스페이스 정규화, 색보정
- ✅ 오디오-비디오 싱크
- ✅ 배치 처리

## ❌ 사용하지 않음

- 실시간 비디오 편집 UI → DaVinci Resolve/Premiere
- 3D 합성 → After Effects/Blender
- 모션 그래픽 → After Effects
- 화면 녹화 → OBS

## 도구 선택

| 도구 | 속도 | 용도 |
|------|------|------|
| FFmpeg | 매우 빠름 | CLI 자동화, 프로덕션 파이프라인 |
| MoviePy | 중간 | Python API, 프로그래밍 편집 |
| DaVinci Resolve | 느림 | 수동 정밀 편집 |

## ⚠️ 핵심 주의사항 (Anti-Patterns)

### 1. 키프레임 정렬 없이 자르기
```bash
# ❌ 잘못됨 — 키프레임 없이 stream copy하면 블랙프레임/깨짐
ffmpeg -i input.mp4 -ss 00:01:23.456 -to 00:02:45.678 -c copy output.mp4

# ✅ 프레임 정밀 컷 (리인코딩)
ffmpeg -i input.mp4 -ss 00:01:23.456 -to 00:02:45.678 \
  -c:v libx264 -crf 18 -preset medium -c:a aac -b:a 192k output.mp4

# ✅ 키프레임 정렬 스트림 카피 (빠름, 무손실)
# 먼저 키프레임 찾기:
ffprobe -select_streams v -show_frames -show_entries frame=pkt_pts_time,key_frame \
  -of csv input.mp4 | grep ",1$" | awk -F',' '{print $2}'
# 가장 가까운 키프레임에서 자르기:
ffmpeg -i input.mp4 -ss 00:01:22.000 -to 00:02:46.000 -c copy output.mp4

# ✅ 최적: Two-pass (빠른 시크 + 정밀 컷)
ffmpeg -ss 00:01:20.000 -i input.mp4 \
  -ss 00:00:03.456 -to 00:01:25.678 \
  -c:v libx264 -crf 18 -preset medium -c:a aac -b:a 192k output.mp4
```

### 2. 불필요한 재인코딩 (품질 손실 누적)
```bash
# ❌ 각 작업마다 재인코딩 → 품질 누적 손실

# ✅ 단일 패스에 모든 작업 체인
ffmpeg -ss 00:01:00 -i input.mp4 -i audio.mp3 \
  -to 00:04:00 \
  -vf "subtitles=subs.srt" \
  -map 0:v -map 1:a \
  -c:v libx264 -crf 18 -preset medium \
  -c:a aac -b:a 192k output.mp4

# ✅ 스트림 카피 활용 — 무손실 작업은 -c copy
ffmpeg -i input.mp4 -ss 00:01:00 -to 00:05:00 -c copy temp.mp4
ffmpeg -i temp.mp4 -i audio.mp3 -map 0:v -map 1:a \
  -c:v copy -c:a aac -b:a 192k temp2.mp4
ffmpeg -i temp2.mp4 -vf subtitles=subs.srt \
  -c:v libx264 -crf 18 -preset medium -c:a copy output.mp4
```

### 3. 컬러 스페이스 무시
```bash
# ❌ 다른 컬러 스페이스 영상을 무작정 병합

# ✅ 컬러 분석 후 정규화
ffprobe -v error -select_streams v:0 \
  -show_entries stream=color_space,color_transfer,color_primaries,pix_fmt \
  -of default=noprint_wrappers=1 clip.mp4

# BT.601 → BT.709 변환
ffmpeg -i clip.mp4 \
  -vf "scale=in_range=full:out_range=limited,colorspace=bt709:iall=bt601:fast=1" \
  -color_primaries bt709 -color_trc bt709 -colorspace bt709 \
  -c:v libx264 -crf 18 -preset medium -c:a copy clip_normalized.mp4
```

### 4. 오디오 싱크 문제
```bash
# ❌ 오디오 길이 ≠ 비디오 길이 무시

# ✅ 오디오를 비디오 길이에 맞춤
VIDEO_DUR=$(ffprobe -v error -show_entries format=duration \
  -of default=noprint_wrappers=1:nokey=1 video.mp4)
AUDIO_DUR=$(ffprobe -v error -show_entries format=duration \
  -of default=noprint_wrappers=1:nokey=1 audio.mp3)
TEMPO=$(echo "scale=4; $VIDEO_DUR / $AUDIO_DUR" | bc)
ffmpeg -i video.mp4 -i audio.mp3 \
  -filter_complex "[1:a]atempo=$TEMPO[a]" \
  -map 0:v -map "[a]" -c:v copy -c:a aac output.mp4
```

## ⚠️ 9:16 세로 영상 — Letterbox Blur 방식 (YouTube Shorts용)

**핵심 교훈 (2026-04-30):** YouTube Shorts에Letterbox Blur 방식을 사용해야 함.
Crop-Fill은 콘텐츠가 프레임의 ~32%만 보여서 YouTube가 일반 영상으로 분류함.

### YouTube Shorts용 — Letterbox Blur 방식 (✅ 검증 완료)
원본 콘텐츠를 9:16 프레임 안에 비율 유지로插入하고, 남는 위아래 공간을 블러 배경으로 채움.
**SAR/DAR 메타데이터를 반드시 설정**해야 YouTube가 9:16으로 인식함.

```bash
ffmpeg -y -i input.mp4 -t 60 \
  -filter_complex "
    [0:v]split=2[bg][fg];
    [bg]scale=1080:1920,boxblur=20,setsar=1:1,setdar=9/16[bg2];
    [fg]scale=1080:-1,setsar=1:1,setdar=9/16[fg2];
    [bg2][fg2]overlay=(W-w)/2:(H-h)/2[vout];
    [0:a]atrim=0:60,afade=t=out:st=57:d=3[aout]
  " \
  -map "[vout]" -map "[aout]" \
  -c:v libx264 -preset ultrafast -crf 26 \
  -c:a aac -b:a 128k \
  -pix_fmt yuv420p -movflags +faststart \
  output.mp4
```

**검증 결과:** 1280x720 원본 → 1080x1920, SAR=1:1, DAR=9:16 ✅ → YouTube Shorts 분류 정상 ✅
**핵심:** `setsar=1:1, setdar=9/16` — 이 메타데이터 없으면 9:16 해상도라도 YouTube가 일반 영상으로 분류함.

### Center Crop-Fill 방식 (콘텐츠 전체 보존 필요 없을 때)
원본을 확대하여 9:16 프레임에 가득 채움 (양쪽 또는 위아래 자름).
**주의:** 콘텐츠가 작아보일 수 있으므로 YouTube Shorts에는 Letterbox Blur 방식 권장.

```bash
ffmpeg -y -i input.mp4 -t 60 \
  -filter_complex "
    [0:v]crop=ih*9/16:ih:(iw-ih*9/16)/2:0,scale=1080:1920,setsar=1[fg];
    [0:a]atrim=0:60,afade=t=out:st=57:d=3[aout];
    [fg][aout]concat=n=1:v=1:a=1[vout]
  " \
  -map "[vout]" \
  -c:v libx264 -preset ultrafast -crf 26 \
  -c:a aac -b:a 128k \
  -pix_fmt yuv420p -movflags +faststart \
  output.mp4
```

**FFmpeg crop 수식 주의:** `min(1920/iw, 1080/ih)` 형태의 공식은 16:9에서 항상 1.0이 되어 크롭이 안 됨.
정답: `crop=ih*9/16:ih:(iw-ih*9/16)/2:0` ( landscape 16:9 →中心 crop, 검증: 1920x1080 → 608x1080)

```bash
# ✅ 올바른 방식: split → bg에 scale/crop/blur → fg에 scale/pad → overlay
ffmpeg -y -ss 30 -i input.mp4 -t 60 \
  -filter_complex "
    [0:v]split=2[bg][fg];
    [bg]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,boxblur=20[blurred];
    [fg]scale=1080:-1,pad=1080:1920:(1080-iw)/2:(1920-ih)/2:black@0[foreground];
    [blurred][foreground]overlay=0:0[out]
  " \
  -map "[out]" \
  -c:v libx264 -preset fast -crf 23 \
  -c:a aac -b:a 128k \
  -movflags +faststart \
  output_9x16.mp4

# 원리:
# - bg: 원본 → 9:16으로 scale+crop → 블러 (배경)
# - fg: 원본 → 세로에 fit하도록 scale → 좌우 padding (내용물)
# - overlay: 블러 배경 위에 내용물 overlay
```

**❌ 잘못된 방식 (에러 발생):**
```bash
# scale + crop만 하면 crop 범위가 원본보다 클 수 있음
-vf "scale=-2:1920,pad=1920:1920:(1920-iw)/2:(1920-ih)/2"
```

## 명령어 패턴

## ⚠️ 절대 금지 패턴

### ❌ `pad=...:black` 검은 패드 (Chronic Bug — 반복 재발)
YouTube Shorts/릴스용으로 `pad=...:black` 사용 금지. 이 패턴이 스크립트에 있으면 **무조건 블러 letterbox로 교체**해야 함.

**재발 패턴:**
```
스크립트에 pad=...:black 작성 → 다음 날 숏츠 = 검은 패드
→ 주인이 블러로 수정 요청 → 다음 날 또 검은 패드
→ 반복 (MEMORY.md에 경고 등록済み)
```

**금지:**
```bash
# ❌ 이 패턴 절대 사용 금지
-vf "scale=1080:-1:force_original_aspect_ratio=decrease,pad=1080:1920:(ow-iw)/2:(oh-ih)/2:black"
```

**대체 — Blur Letterbox (filter_complex 방식):**
```bash
ffmpeg -y -i input.mp4 -t 60 \
  -filter_complex "
    [0:v]scale=1080:-1:force_original_aspect_ratio=decrease,setsar=1,
    split[main][bg];
    [bg]scale=1080:1920:force_original_aspect_ratio=increase,
    boxblur=20:5,
    format=yuv420p[bgBlurred];
    [bgBlurred][main]overlay=(W-w)/2:(H-h)/2[out];
    [0:a]atrim=0:60,afade=t=out:st=57:d=3[aout]
  " \
  -map "[out]" -map "[aout]" \
  -c:v libx264 -preset ultrafast -crf 26 \
  -c:a aac -b:a 128k \
  -pix_fmt yuv420p -movflags +faststart \
  output_9x16.mp4
```

**FFmpeg boxblur 구문:** `boxblur=lr:lp` 형태만 지원. `cr=`, `cs=`, `cp=` 옵션 없음.
`boxblur=20:5` = luma_radius=20, luma_power=5. FFmpeg 4.3+ 모두 지원 ✅

### ⚠️ FFmpeg 9:16 변환 — "width not divisible by 2" 에러 (2026-05-07)

**발생:** `filter_complex` blur-letterbox 방식에서 `scale=...:force_original_aspect_ratio=increase`로 생성한 배경의 가로 or 세로 픽셀이 홀수가 되면 libx264가 크래시함.

**예시 에러:**
```
[libx264 @ 0x...] width not divisible by 2 (3411x1920)
Error initializing output stream 0:0
```

**원인:** 1280x720(16:9) 원본을 `scale=1080:1920:force_original_aspect_ratio=increase`하면
너비 = 1080, 높이 = 1920인데 `increase`는 짧은 쪽을 늘리므로 → 너비 3411px (홀수) → 크래시.

**대응:**
1. `force_original_aspect_ratio=increase` 쓰지 않기
2. 홀수 차원 방지를 위해 `-2` 옵션 사용: `scale=1080:-2`
3. 그래도 실패 시 → **Simple Pad 방식** 사용:

```bash
# ✅ 안정 방식 — scale로 -2 강제 후 pad로 정직하게 9:16 구성
ffmpeg -y -i input.mp4 -t 59 \
  -vf "scale=1080:-2,pad=1080:1920:0:(1920-ih)/2:black,setsar=1,setdar=9/16" \
  -c:v libx264 -preset ultrafast -crf 26 \
  -c:a aac -b:a 128k \
  -af "atrim=0:59,afade=t=out:st=56:d=3" \
  -pix_fmt yuv420p -movflags +faststart \
  output_9x16.mp4
```

**원리:** `scale=1080:-2`로 너비를 2의 배수로強制 (-2 = 2의 배수中最接近) → pad로 세로 공간 추가 → `setdar=9/16`으로 메타데이터 설정.

**검증:** `ffprobe -v error -show_entries stream=width,height,duration -of csv=p=0 output_9x16.mp4` → 1080,1920,59 확인.

---

## 비율/해상도 변경

### ✅ 16:9 → 9:16 세로 변환 (Shorts/릴스용)
**반드시 Blur Letterbox 방식 사용** — pad=black 절대 금지.

```bash
# ✅ 영상만 — 위아래 블러 배경
ffmpeg -y -i input.mp4 -t 60 \
  -filter_complex "
    [0:v]scale=1080:-1:force_original_aspect_ratio=decrease,setsar=1,
    split[main][bg];
    [bg]scale=1080:1920:force_original_aspect_ratio=increase,
    boxblur=20:5,
    format=yuv420p[bgBlurred];
    [bgBlurred][main]overlay=(W-w)/2:(H-h)/2[out]
  " \
  -map "[out]" -map "0:a?" \
  -c:v libx264 -preset ultrafast -crf 26 \
  -c:a aac -b:a 128k \
  -af "atrim=0:60,afade=t=out:st=57:d=3" \
  -pix_fmt yuv420p -movflags +faststart \
  output_9x16.mp4
```

**검증:**
```bash
ffprobe -v error -show_entries stream=width,height,duration -of csv=p=0 output_9x16.mp4
# → 1080,1920,60 확인
```

### 포맷 변환
```bash
ffmpeg -y -hide_banner -i "INPUT" -c:v libx264 -c:a aac "OUTPUT.mp4"
ffmpeg -y -hide_banner -i "INPUT" -c copy "OUTPUT.mkv"
ffmpeg -y -hide_banner -i "INPUT" -c:v libvpx-vp9 -c:a libopus "OUTPUT.webm"
ffmpeg -y -hide_banner -i "INPUT" -c:v libx264 -c:a aac "OUTPUT.mov"
```

### 비율/해상도 변경
```bash
# 16:9 YouTube
ffmpeg -y -hide_banner -i input.mp4 \
  -vf "scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2:black" \
  -c:a copy output_16x9.mp4
# 9:16 틱톡/릴스
ffmpeg -y -hide_banner -i input.mp4 \
  -vf "scale=1080:1920:force_original_aspect_ratio=decrease,pad=1080:1920:(ow-iw)/2:(oh-ih)/2:black" \
  -c:a copy output_vertical.mp4
# 1:1 인스타그램
ffmpeg -y -hide_banner -i input.mp4 \
  -vf "scale=1080:1080:force_original_aspect_ratio=decrease,pad=1080:1080:(ow-iw)/2:(oh-ih)/2:black" \
  -c:a copy output_square.mp4
# 해상도 변경
ffmpeg -y -hide_banner -i input.mp4 -vf "scale=1280:720" -c:a copy output_720p.mp4
```

### 압축 (CRF: 18 고품질 ~ 28 작은파일, 23 밸런스)
```bash
ffmpeg -y -hide_banner -i input.mp4 \
  -c:v libx264 -crf 23 -preset medium -c:a aac -b:a 128k output_compressed.mp4
```

### 오디오
```bash
ffmpeg -y -hide_banner -i input.mp4 -vn -acodec libmp3lame output.mp3
ffmpeg -y -hide_banner -i input.mp4 -vn -acodec pcm_s16le output.wav
ffmpeg -y -hide_banner -i input.mp4 -an -c:v copy output_silent.mp4
```

### 속도 조절 (setpts = 1/speed, atempo = speed)
```bash
# 2배속
ffmpeg -y -hide_banner -i input.mp4 \
  -filter_complex "[0:v]setpts=0.5PTS[v];[0:a]atempo=2.0[a]" \
  -map "[v]" -map "[a]" output_2x.mp4
# 슬로모션 (0.5배속)
ffmpeg -y -hide_banner -i input.mp4 \
  -filter_complex "[0:v]setpts=2.0PTS[v];[0:a]atempo=0.5[a]" \
  -map "[v]" -map "[a]" output_slow.mp4
```

### Ken Burns 효과 — Slow Zoom/Pan (정지영상 방지)

Ken Burns 효과는 이미지 기반 뮤직비디오/슬라이드쇼에 "정지영상이 아닌 느낌"을 주는 가장 간단한 방법.

### FFmpeg zoompan (주의: 4K 입력에서 문제 가능)

```bash
# zoom in 효과
ffmpeg -y -loop 1 -i image.png -i audio.mp3 \
  -vf "zoompan=z='min(zoom+0.003,1.2)':d=1:x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)',scale=1280:720" \
  -c:v libx264 -preset ultrafast -crf 28 \
  -c:a aac -b:a 192k \
  output.mp4
```

**⚠️ 문제:** macOS FFmpeg 4.3.2에서 4K(3840x2160) 입력 시 `Invalid argument` 에러 발생.
대안: Python PIL로 Ken Burns 프레임 생성 → FFmpeg 조립.

### Python PIL Ken Burns 방식 (FFmpeg zoompan 대안)

```python
from PIL import Image
import os

def create_ken_burns_video(src_path, audio_path, output_path,
                           fps=25, start_scale=1.0, end_scale=1.15):
    """이미지 + Ken Burns 효과 → 영상"""
    src = Image.open(src_path)
    orig_w, orig_h = src.size
    
    # 프레임 생성 (프레임 번호 = 시간×fps)
    import subprocess
    temp_dir = "/tmp/ken_burns_frames"
    os.makedirs(temp_dir, exist_ok=True)
    
    # 오디오 길이 확인
    result = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "default=noprint_wrappers=1:nokey=1", audio_path],
        capture_output=True, text=True
    )
    dur = float(result.stdout.strip())
    total = int(dur * fps)
    
    for frame in range(total):
        t = frame / fps
        scale = start_scale + (end_scale - start_scale) * (t / dur)
        
        crop_w = int(1280 * scale)
        crop_h = int(720 * scale)
        left = (orig_w - crop_w) // 2
        top = (orig_h - crop_h) // 2
        
        cropped = src.crop((left, top, left + crop_w, top + crop_h))
        resized = cropped.resize((1280, 720), Image.LANCZOS)
        resized.save(f"{temp_dir}/frame_{frame:05d}.png")
        cropped.close()
        resized.close()
    
    src.close()
    
    # FFmpeg로 영상 조립
    subprocess.run([
        "ffmpeg", "-y", "-framerate", str(fps), "-i", f"{temp_dir}/frame_%05d.png",
        "-i", audio_path, "-c:v", "libx264", "-preset", "ultrafast", "-crf", "23",
        "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", output_path
    ], check=True)
    
    # 정리
    for f in os.listdir(temp_dir):
        os.remove(os.path.join(temp_dir, f))
    os.rmdir(temp_dir)
```

**권장 설정:**
- zoom-in만: `start_scale=1.0, end_scale=1.15`
- zoom-in then out: `start_scale=1.0, end_scale=1.2` → 다음 세그먼트에서 `1.2→1.0`
- pan 추가: crop left/top을 시간에 따라 이동 (위 공식에서 `left = (orig_w - crop_w)//2 + int(pan_offset*t)`)

**musicl_video_producer.py 연동:** 3개 이미지 × 각 Ken Burns 적용 → concat으로 연결.

## 회전/플립
```bash
ffmpeg -y -hide_banner -i input.mp4 -vf "transpose=1" -c:a copy output_90cw.mp4
ffmpeg -y -hide_banner -i input.mp4 -vf "transpose=2" -c:a copy output_90ccw.mp4
ffmpeg -y -hide_banner -i input.mp4 -vf "hflip" -c:a copy output_mirror.mp4
ffmpeg -y -hide_banner -i input.mp4 -vf "vflip" -c:a copy output_flip.mp4
```

### 워터마크
```bash
ffmpeg -y -hide_banner -i video.mp4 -i logo.png \
  -filter_complex "overlay=W-w-10:10" output_watermarked.mp4
```

### 자막
```bash
ffmpeg -y -hide_banner -i input.mp4 -vf "subtitles='subs.srt'" output_subtitled.mp4
```

### GIF 변환
```bash
ffmpeg -y -hide_banner -i input.mp4 -ss 00:00:10 -t 5 \
  -vf "fps=15,scale=480:-1:flags=lanczos" -loop 0 output.gif
```

### 썸네일/스크린샷
```bash
ffmpeg -y -hide_banner -i input.mp4 -ss 00:01:30 -frames:v 1 screenshot.jpg
```

### 병합
```bash
# files.txt: file 'v1.mp4'\nfile 'v2.mp4'
ffmpeg -y -hide_banner -f concat -safe 0 -i files.txt -c copy merged.mp4
```

## 컬러 스페이스 가이드

| 표준 | 용도 |
|------|------|
| BT.601 | SD 구형 콘텐츠 |
| BT.709 | HD 현대 HD/FHD |
| BT.2020 | UHD/HDR 4K |
| sRGB | Web 웹 배포 |

## 워크플로우

1. **입력 분석** — ffprobe로 비디오 정보 확인
2. **작업 계획** — 여러 작업을 단일 패스로 체인할 수 있는지 확인
3. **실행** — 스트림 카피 우선, 필요시에만 재인코딩
4. **검증** — 출력 파일 확인 (재생, 품질, 길이)

## 배치 처리 예시

```python
import subprocess, glob
for video in glob.glob("*.mp4"):
    output = video.replace(".mp4", "_720p.mp4")
    subprocess.run([
        "ffmpeg", "-y", "-hide_banner", "-i", video,
        "-vf", "scale=1280:720",
        "-c:v", "libx264", "-crf", "23", "-preset", "fast",
        "-c:a", "copy", output
    ])
```
