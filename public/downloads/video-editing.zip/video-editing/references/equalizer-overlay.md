# Transparent GIF Overlay for Equalizer Animation (2026-05-23)

## Problem
YouTube music video needs an animated equalizer visual in the corner, but:
- GIF with black background looks bad
- MP4 with black background also looks bad
- Only transparent overlay works

## Solution: Transparent GIF + FFmpeg overlay

### Step 1: Generate transparent GIF with PIL

```python
from PIL import Image, ImageDraw
import math, os

w, h = 360, 120
num_bars = 20
bar_w = 12
bar_spacing = 6

colors = [
    (255, 80, 120),   # 핑크
    (200, 80, 180),   # 보라
    (120, 80, 255),   # 블루
    (80, 150, 255),   # 스카이
]

import random
random.seed(42)
base_heights = [random.randint(30, 80) for _ in range(num_bars)]

frames = []
for frame in range(30):  # 1초 루프 @30fps
    img = Image.new('RGBA', (w, h), (0, 0, 0, 0))  # 완전 투명
    draw = ImageDraw.Draw(img)
    phase = frame * 0.3
    
    for i in range(num_bars):
        wave = math.sin(phase + i * 0.4) * 0.4 + 0.6
        bar_h = int(base_heights[i] * wave)
        bar_h = max(10, min(bar_h, h - 25))
        
        x = i * (bar_w + bar_spacing)
        y = h - 25 - bar_h
        
        color_idx = int((i / num_bars) * (len(colors) - 1))
        color = colors[min(color_idx, len(colors) - 1)]
        
        draw.rounded_rectangle([x, y, x + bar_w, h - 25],
                              radius=4, fill=color + (220,))
    frames.append(img)

frames[0].save(
    f'{WAVE_DIR}/wave.gif',
    save_all=True,
    append_images=frames[1:],
    duration=int(1000/30),
    loop=0,
    optimize=False
)
```

### Step 2: Overlay on main video

```bash
# Position: bottom-right (x=920, y=600 for 1280x720 video)
ffmpeg -y \
  -i main_video.mp4 \
  -stream_loop -1 -i wave.gif \
  -filter_complex "[0:v][1:v] overlay=920:600:shortest=1" \
  -c:v libx264 -preset ultrafast -crf 23 \
  -c:a copy \
  output_with_eq.mp4
```

## Key Points

1. **GIF vs MP4:** GIF preserves transparency better; MP4 may compress alpha
2. **`-stream_loop -1`:** Loops GIF indefinitely (matches video length)
3. **`shortest=1`:** Video ends when main video ends (not when GIF loops)
4. **Position calculation:** For 1280x720, wave width 360 → x=1280-360=920, height 120 → y=720-120=600
5. **RGBA not RGB:** Must use `Image.new('RGBA', ...)` with 4th channel for transparency

## Verification
```bash
# Check output has correct duration and overlay
ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1 output_with_eq.mp4

# Upload and verify in YouTube studio that background is transparent
```