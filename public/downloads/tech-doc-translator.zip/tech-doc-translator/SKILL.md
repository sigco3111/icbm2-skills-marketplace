---
name: tech-doc-translator
description: 영문 기술 문서를 한국어로 요약 번역 — Hacker News, Arxiv, Reddit 기술 글을 수집하여 Notion에 기록
version: 1.0.0
author: icbm2
metadata:
  hermes:
    tags: [Translation, Tech, HN, Arxiv, Notion, Daily]
prerequisites:
  secret_files: [notion_token.txt]
---

# 영문 기술 문서 번역기

Hacker News, Arxiv, Reddit 등 영문 기술 콘텐츠를 수집하여 한국어로 고품질 요약 번역하여 Notion DB에 기록합니다.

## Notion DB

- **DB ID:** `31afa83b-8e35-447b-8e9d-8d21e8917ade`
- **DB명:** Tech Doc Translator
- **속성:**
  - Name(title): 한국어 번역 제목
  - Date(date): 수집 날짜
  - Source(select): 출처
  - Category(select): 카테고리
  - Original URL(url): 원문 링크
  - Original Title(rich_text): 원문 제목 (영문)
- **Source 옵션:** Hacker News, Arxiv, Reddit, Blog, Official, Other
- **Category 옵션:** AI/ML, LLM, Coding, DevOps, Security, System, Mobile, Web, Data, Research, Other

## 번역 품질 기준

### 반드시 지킬 것
1. **의역 우선** — 직역이 아닌 자연스러운 한국어로
2. **기술 용어** — 처음 등장 시 괄호 안에 영문 표기, 이후 한국어만 사용
   - 예: "전체 어텐션(Full Attention) 메커니즘이 도입되었다. 이 어텐션 방식은..."
   - 예외: API, GPU, CLI, SDK 등 보편적 약어는 그대로
3. **문맥 보존** — 저자의 의도, 논조, 뉘앙스 유지
4. **구조 유지** — 원문의 섹션 구조, 글의 흐름 따르기
5. **핵심 메시지** — "이 글이 전하고자 하는 핵심은 무엇인가"를 잃지 않기

### 피할 것
1. 기계 번역투 (주어-동사 구조 강제 번역)
2. 불필요한 수동태
3. 원문에 없는 정보 추가 (요약은 가능, 의견은 분리)
4. 과도한 honorific (기술 문서체로 작성)

## 실행 단계

### 1. 대상 선정

매일 다음 소스에서 주요 기술 글을 선정:

```bash
# Hacker News 프론트페이지 (상위 30개)
# https://hacker-news.firebaseio.com/v0/topstories.json
# 개별 글: https://hacker-news.firebaseio.com/v0/item/{id}.json

# Arxiv AI/ML/SE 최신 논문 (상위 10개)
# https://arxiv.org/list/cs.AI/recent
# https://arxiv.org/list/cs.CL/recent
# https://arxiv.org/list/cs.SE/recent

# Reddit 기술 서브레딧
# r/MachineLearning (hot 10)
# r/LocalLLaMA (hot 10)
# r/programming (hot 10)
# r/coding (hot 10)
```

### 2. 선정 기준

- **AI/ML 관련:** LLM, 에이전트, 멀티모달, 학습 기법 — 최우선
- **코딩/개발:** 새로운 프레임워크, 언어 기능, 개발 도구 — 우선
- **인프라/보안:** 클라우드, DevOps, 보안 취약점 — 보통
- **일반:** 대중적 관심사, 바이럴 기술 글 — 낮음
- **제외:** 순수 홍보글, 낮은 품질, 중복 내용

### 3. 번역 및 요약

각 글에 대해:

1. **원문 읽기** — 제목, 본문/초록, 댓글(중요 인사이트)
2. **핵심 요약 작성** (3-5문장):
   - 무엇을 다루는 글인지
   - 핵심 기술/아이디어
   - 왜 중요한지 (임팩트)
3. **상세 번역** (핵심 섹션):
   - Arxiv: 초록(Abstract) 전체 번역 + 핵심 방법론/결과
   - HN/Reddit: 글 본문 요약 + 주요 댓글 인사이트
   - 블로그: 핵심 섹션 번역 + 코드 예시 설명
4. **ICBM2 코멘트** (1-2문장):
   - 주인님 관점에서 왜 흥미로운지
   - 관련 트렌드/다른 글과의 연결

### 4. Notion에 기록

```python
import os, json, subprocess
from datetime import datetime, timezone, timedelta

TK_PATH = os.environ["NOTION_TOKEN_PATH"]
DB_ID = "31afa83b-8e35-447b-8e9d-8d21e8917ade"
today = datetime.now(timezone(timedelta(hours=9))).strftime("%Y-%m-%d")

with open(TK_PATH) as f:
    tk = f.read().strip()

def add_translated_entry(ko_title, en_title, source, category, url, summary_blocks):
    """
    summary_blocks: Notion block objects 배열
    """
    payload = {
        "parent": {"database_id": DB_ID},
        "properties": {
            "Name": {"title": [{"text": {"content": ko_title}}]},
            "Date": {"date": {"start": today}},
            "Source": {"select": {"name": source}},
            "Category": {"select": {"name": category}},
            "Original URL": {"url": url},
            "Original Title": {"rich_text": [{"text": {"content": en_title}}]}
        },
        "children": summary_blocks
    }
    with open("/tmp/notion_entry.json", "w") as f:
        json.dump(payload, f, ensure_ascii=False)
    env = dict(os.environ)
    env["NTK"] = tk
    r = subprocess.run(
        f'curl -s -X POST --max-time 15 https://api.notion.com/v1/pages -H "Authorization: Bearer $NTK" -H "Notion-Version: 2022-06-28" -H "Content-Type: application/json" -d @/tmp/notion_entry.json',
        shell=True, capture_output=True, text=True, env=env
    )
    return r.stdout

# 본문 블록 구성 예시
summary_blocks = [
    # 핵심 요약
    {
        "object": "block",
        "type": "heading_2",
        "heading_2": {
            "rich_text": [{"text": {"content": "📋 핵심 요약"}}]
        }
    },
    {
        "object": "block",
        "type": "paragraph",
        "paragraph": {
            "rich_text": [{"text": {"content": "이 논문은 새로운 어텐션 메커니즘을 제안한다..."}}]
        }
    },
    # 상세 번역
    {
        "object": "block",
        "type": "heading_2",
        "heading_2": {
            "rich_text": [{"text": {"content": "📝 상세 내용"}}]
        }
    },
    {
        "object": "block",
        "type": "paragraph",
        "paragraph": {
            "rich_text": [{"text": {"content": "상세 번역 내용..."}}]
        }
    },
    # ICBM2 코멘트
    {
        "object": "block",
        "type": "divider",
        "divider": {}
    },
    {
        "object": "block",
        "type": "callout",
        "callout": {
            "icon": {"emoji": "🤖"},
            "rich_text": [{"text": {"content": "ICBM2: 이 기술은 현재 에이전트 아키텍처 트렌드와 연결된다..."}}]
        }
    }
]

add_translated_entry(
    ko_title="새로운 어텐션 메커니즘으로 LLM 성능 향상",
    en_title="New Attention Mechanism Improves LLM Performance",
    source="Arxiv",
    category="AI/ML",
    url="https://arxiv.org/abs/...",
    summary_blocks=summary_blocks
)
```

### 5. 품질 기준

- **최소 3개, 최대 7개** 항목 기록
- AI/ML 관련 글의 비중을 높게 (50%+)
- 번역 품질은 "기술 블로그 수준" 목표
- 각 항목에 핵심 요약 + 상세 번역 + ICBM2 코멘트 포함
- **Original URL 속성은 항상 기록**
- 한국어로 작성

### 6. 중복 방지

- 같은 원문 URL이 이미 DB에 있는지 확인 후 기록
- 동일 주제의 여러 글은 가장 포괄적인 것 하나만 선택

## 스케줄

- **크론:** 매일 10:00 KST
- **delivery:** origin (Telegram)

## 활용 팁

- 아침 브리핑(morning-briefing)과 연동하여 당일 번역된 글을 요약 포함 가능
- 주간 기술 요약(weekly-tech-digest)의 소스로 활용
- Tistory 발행 시 참고 자료로 활용

## 참고

- ios-trend-digest, ai-model-tracker와 보완 관계
- ios-trend-digest는 iOS/Swift 전용, 본 스킬은 전체 기술 영역 대상
