#!/usr/bin/env bash
# opencode run hang 진단 스크립트
# 사용: bash diagnose-hang.sh
# 효과: 죽은 구독/플러그인 misconfig 즉시 진단

set -e

echo "=== OpenCode hang 진단 ==="
echo ""

echo "1) 설치 확인"
which opencode && opencode --version || { echo "opencode 미설치"; exit 1; }
echo ""

echo "2) 활성 플러그인"
if [ -f ~/.config/opencode/opencode.json ]; then
    cat ~/.config/opencode/opencode.json
else
    echo "~/.config/opencode/opencode.json 없음"
fi
echo ""

echo "3) oh-my-openagent 설정의 sisyphus.model"
if [ -f ~/.config/opencode/oh-my-openagent.json ]; then
    python3 -c "
import json
with open('$HOME/.config/opencode/oh-my-openagent.json') as f:
    d = json.load(f)
model = d.get('agents', {}).get('sisyphus', {}).get('model', 'NONE')
print(f'  sisyphus.model = {model}')
"
else
    echo "  oh-my-openagent.json 없음"
fi
echo ""

echo "4) 무료 모델 목록 (opencode/* prefix)"
opencode models 2>/dev/null | grep "^opencode/" || echo "  (조회 실패)"
echo ""

echo "=== 진단 결과 ==="
echo "만약 sisyphus.model이 죽은 구독 (zai-coding-plan 등) 가리키면:"
echo "  해결 1: opencode run --pure \"프롬프트\"  (즉시 우회)"
echo "  해결 2: opencode.json 에서 plugin 라인 제거  (영구 zero-config)"
echo "  해결 3: oh-my-openagent.json의 sisyphus.model을 opencode/big-pickle로 교체"