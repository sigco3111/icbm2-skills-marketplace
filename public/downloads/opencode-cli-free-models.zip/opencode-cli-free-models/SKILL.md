---
name: opencode-cli-free-models
description: OpenCode CLI를 무료 모델(zero-config)로 비대화형 실행하는 워크플로 — OpenCode 내장 무료 라우터(opencode/big-pickle 등) 활용, oh-my-openagent 플러그인 hang 우회, Windows/맥/Linux 공통. "오픈코드 무료 모델", "opencode CLI 비대화형", "opencode run 기본 모델", "오픈코드 zero-config 설정" 같은 요청에 발동. (NVIDIA NIM 풀 스쿼드 구성이 필요하면 opencode-nvidia-setup 스킬을 대신 로드.)
---

# OpenCode CLI — 무료 모델 Zero-Config 워크플로

## 목적
OpenCode를 **무료 모델 + 비대화형(`opencode run`) + 설정 부담 최소**로 쓰는 클래스. 자주 갱신되는 무료 모델을 매번 설정 파일에 묶어둘 필요 없이, OpenCode의 내장 무료 라우터로 자동 위임.

## 핵심 발견 (2026-06-19 실전 검증)

### OpenCode 내장 무료 모델
`opencode models` 명령으로 노출되는 무료 모델 prefix `opencode/`:
```
opencode/big-pickle              ← 메인 무료 라우터 (1차 디폴트)
opencode/deepseek-v4-flash-free  ← DeepSeek 변형
opencode/mimo-v2.5-free          ← Xiaomi Mimo
opencode/nemotron-3-ultra-free   ← NVIDIA Nemotron
opencode/north-mini-code-free    ← 코딩 특화
```

이 모델들은 OpenCode가 자체적으로 운영/라우팅하며, OpenRouter의 big-pickle과 동명이지만 별개.

### `--pure` 플래그 (가장 중요한 함정 해결)
oh-my-openagent 플러그인이 켜져 있을 때 `oh-my-openagent.json`의 `sisyphus.model`이 디폴트로 잡힘. **죽은 구독(zai-coding-plan 등)이 설정에 남아있으면 `opencode run`이 무한 hang.**

해결:
```bash
opencode run --pure "프롬프트"
```
- `--pure`: 외부 플러그인 로딩 스킵
- 디폴트가 `opencode/big-pickle`로 자동 결정됨 (실전 검증 완료, 응답 < 1초)
- TUI의 `/models` 선택 기억도 `--pure`에서는 안 쓰이고 깨끗하게 OpenCode 디폴트로 폴백

### 모델 미지정 시 결정 우선순위
```
1. CLI 플래그 (-m/--model)
2. 환경변수 (OPENCODE_MODEL)
3. oh-my-openagent의 agents.sisyphus.model  ← 죽은 구독 hang 원인
4. OpenCode 내장 디폴트 (opencode/big-pickle)
```

## 실행 패턴

### 즉시 사용 (설정 변경 0)
```bash
# 비대화형, 무료 모델 자동
opencode run --pure "프롬프트"

# 특정 무료 모델 지정
opencode run --pure -m opencode/deepseek-v4-flash-free "프롬프트"

# TUI 진입 + 무료 모델 자동 (oh-my-openagent 우회 불가, TUI는 플러그인 로딩)
# → TUI에서는 /models에서 opencode/* 수동 선택
```

### 영구 zero-config (oh-my-openagent 비활성화)
`~/.config/opencode/opencode.json`:
```json
{
  "$schema": "https://opencode.ai/config.json",
  "plugin": []
}
```
- 효과: `opencode run`만 쳐도 `--pure`와 동일 (디폴트 `big-pickle`)
- 트레이드오프: oh-my-openagent의 10개 에이전트 스쿼드(sisyphus/oracle 등) 못 씀
- **무료 모델 zero-config 우선이면 이 옵션이 답**

### 헬퍼 스크립트 (Windows PowerShell)
```powershell
# PowerShell 프로필 (~/.Microsoft.PowerShell_profile.ps1 또는 $PROFILE)
Set-Alias oc opencode

# 또는 함수형 (백그라운드 실행에 유리)
function oc { opencode run --pure @args }
```
사용: `oc "프롬프트"` (한 단어)

### 헬퍼 스크립트 (macOS/Linux bash)
```bash
# ~/.bashrc 또는 ~/.zshrc
alias oc='opencode run --pure'
```

## 진단 절차 (무한 hang 시)

1. **즉시 우회**: `Ctrl+C` 후 `opencode run --pure "프롬프트"`
2. **근본 원인 확인**: `cat ~/.config/opencode/oh-my-openagent.json | head -20`
   - `agents.sisyphus.model`이 죽은 구독 가리키는지 확인
3. **영구 해결**:
   - 옵션 A: `oh-my-openagent.json`의 sisyphus.model을 `opencode/big-pickle`로 교체
   - 옵션 B: `opencode.json`에서 plugin 라인 제거 (zero-config)

## Windows 설치

```powershell
# winget (권장)
winget install sst.opencode

# 또는 npm
npm install -g opencode-ai@latest

# 확인
opencode --version
```

## 주의사항

- **`--pure`는 비대화형에서만 실용적**: TUI는 플러그인 로딩이 핵심이라 `--pure`로 TUI 진입하면 에이전트 스쿼드 못 씀
- **무료 모델은 자주 변경됨**: `opencode models` 주기적 재확인 권장 (Big Pickle 자체도 업그레이드됨)
- **죽은 구독 정리 필수**: sisyphus.model이 죽은 구독 가리키면 비대화형 hang. 06-19 메모리 기준 zai-coding-plan/GLM은 종료 — `opencode run`만 치면 hang, 반드시 `--pure` 또는 설정 변경 동반
- **모델 ID 정확성**: OpenCode TUI/CLI에서 노출되는 이름과 정확히 일치 (대소문자, 슬래시, hyphen)
- **백업 권장**: `opencode.json` 수정 전 `cp opencode.json opencode.json.bak-$(date +%Y%m%d)`

## 다른 스킬과의 관계

- **NVIDIA NIM 풀 스쿼드 필요 시**: `opencode-nvidia-setup` 스킬 (sisyphus/oracle/librarian 등 10개 에이전트, NIM 키 로테이션)
- **OpenCode에 다른 작업 위임**: `autonomous-coding-agents` 스킬
- **죽은 구독/자동화 흔적 제거**: `automation-decommission` 스킬