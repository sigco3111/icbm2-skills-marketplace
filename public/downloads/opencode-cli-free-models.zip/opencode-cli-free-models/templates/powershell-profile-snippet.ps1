# OpenCode 무료 모델 헬퍼 — Windows PowerShell 프로필 스니펫
# 위치: $PROFILE (예: C:\Users\<USER>\Documents\PowerShell\Microsoft.PowerShell_profile.ps1)
# 추가 방법: notepad $PROFILE → 아래 붙여넣기 → 저장 → . $PROFILE

# ────────────────────────────────────────────────────────
# 기본 별칭: opencode run --pure "프롬프트"
# ────────────────────────────────────────────────────────
Set-Alias oc opencode

# ────────────────────────────────────────────────────────
# 함수형 (백그라운드 실행 / 파이프에 유리)
# 사용: oc "프롬프트"
# ────────────────────────────────────────────────────────
function oc {
    opencode run --pure @args
}

# ────────────────────────────────────────────────────────
# 모델 지정 실행 (필요할 때만)
# 사용: ocm opencode/deepseek-v4-flash-free "프롬프트"
# ────────────────────────────────────────────────────────
function ocm {
    param(
        [Parameter(Mandatory=$true, Position=0)][string]$Model,
        [Parameter(Mandatory=$true, Position=1, ValueFromRemainingArguments=$true)][string[]]$Prompt
    )
    opencode run --pure -m $Model @Prompt
}

# ────────────────────────────────────────────────────────
# 설치 확인
# ────────────────────────────────────────────────────────
# winget install sst.opencode
# npm install -g opencode-ai@latest
# opencode --version