# OpenCode 내장 무료 모델 목록 (2026-06-19 캡처)

`opencode models` 명령으로 확인. 자주 갱신되므로 매월 재확인 권장.

## opencode/* prefix (OpenCode 자체 무료 라우터)
| 모델 ID | 비고 |
|---|---|
| `opencode/big-pickle` | 메인 무료 라우터. `--pure` 디폴트. 1초 내 응답 |
| `opencode/deepseek-v4-flash-free` | DeepSeek 변형 |
| `opencode/mimo-v2.5-free` | Xiaomi Mimo |
| `opencode/nemotron-3-ultra-free` | NVIDIA Nemotron 변형 |
| `opencode/north-mini-code-free` | 코딩 특화 |

## 사용 예
```bash
# 디폴트 (big-pickle)
opencode run --pure "프롬프트"

# 명시적 지정
opencode run --pure -m opencode/deepseek-v4-flash-free "프롬프트"

# 모델 목록 확인
opencode models | grep "^opencode/"
```

## 변경 감지
cron 또는 heart-beat로 `opencode models | grep "^opencode/"` 결과를
`~/.hermes/cache/opencode-free-models.txt`에 덮어쓰기 → diff 비교하면
신규 무료 모델 등장 알림 가능.