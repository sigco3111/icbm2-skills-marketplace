---
name: automation-decommission
description: 사용하지 않는 자동화 컴포넌트를 체계적으로 제거 — 크론잡/스킬/스크립트/시크릿/메모리 참조를 완전히 폐기. 제거 전 반드시 제거목록을 사용자에게 보여주고 승인을 받아야 한다.
version: 1.0.0
author: ICBM2
metadata:
  hermes:
    tags: [Automation, Cleanup, Removal, Maintenance]
---

# 자동화 컴포넌트 폐기(Decommissioning) 스킬

## 언제 사용

- 사용자: "더 이상 사용하지 않겠다", "제거해", "삭제해"
- 스킬/플랫폼이 비활성 상태이고 재활성화 계획이 없을 때
- 크론잡이나 스킬을 실제로 찾아보니 존재하지 않을 때 (메모리에만 존재)
- 자동화 감사에서 "cut" 판결이 내려졌을 때

## 클래스 트리거 (이 조건들이 ANY로 충족되면 실행)

```
사용자가 특정 플랫폼(마당봇, SoS, 아이디어노트 등)을 "사용 안 함"으로 지정
자동화 컴포넌트 정리 요청
미사용 스킬/크론잡/스크립트 폐기
```

## 1단계: 전수 조사 (READ-ONLY)

### 대상 탐색 순서

```bash
# 1. 스킬 디렉토리
ls ~/.hermes/skills/automation/

# 2. 크론잡 목록 (job ID, name, skills 확인)
hermes cron list

# 3. 스크립트 디렉토리
ls ~/.hermes/scripts/

# 4. 시크릿 디렉토리
ls ~/.hermes/secrets/

# 5. 메모리 파일
ls ~/.hermes/memories/

# 6. Git repo (백업 파일)
ls ~/hermes_bot/memory/
```

### 키워드 기반 탐색

제거 대상이 "마당봇"이라면 `botmadang`, "shiporslop"이라면 `shiporslop`, `ShipOrSlop`, `Ship or Slop`, `SoS` 등 모든 변형으로 검색:

```bash
# 파일명 검색
find ~/.hermes -iname "*botmadang*" -o -iname "*shiporslop*" 2>/dev/null
find ~/hermes_bot -iname "*botmadang*" -o -iname "*shiporslop*" 2>/dev/null

# 내용 검색
grep -rli "botmadang" ~/.hermes/
grep -rli "shiporslop" ~/.hermes/
```

### Python으로 Cron Jobs.json 파싱

```python
import json
with open("/Users/hjshin/.hermes/cron/jobs.json") as f:
    data = json.load(f)
jobs = data.get("jobs", [])

for job in jobs:
    prompt = job.get("prompt", "")
    skills = job.get("skills", [])
    if any_kw in prompt.lower() or any_kw in " ".join(skills).lower():
        print(f"ID: {job['id']}, Name: {job['name']}, Skills: {skills}")
```

## 2단계: 제거 목록 작성

### 제거 범주 5가지

| 카테고리 | 설명 | 제거 방법 |
|----------|------|----------|
| **Skills** | `~/.hermes/skills/automation/<name>/` 디렉토리 | `rm -rf` (디렉토리 전체) |
| **Cron Jobs** | jobs.json에서 참조된 job | `hermes cron remove <job_id>` |
| **Scripts** | `.py` 파일 내 키워드 참조 | 소스에서 키워드 라인 제거 (완전 삭제 X) |
| **Secrets** | `~/.hermes/secrets/<name>*.txt` | `rm` (파일 삭제) |
| **Memory** | `~/.hermes/memories/MEMORY.md` 등 | 해당 참조 제거 |

### 제거 목록 포맷

```
## 🗑️ 제거 목록 (제거 전 확인)

### 1. 🔧 Skills (N개 디렉토리)
| 경로 | 설명 |
|------|------|
| `~/.hermes/skills/automation/botmadang/` | 봇마당 스킬 |

### 2. ⏰ 크론 잡 수정 (N개 — 참조 제거)
| Job ID | 이름 | 조치 |
|--------|------|------|
| `abc123` | 📋 주간 리포트 | 프롬프트에서 키워드 참조 제거 |

### 3. 📜 스크립트 수정 (N개 — 참조 제거)
| 스크립트 | 키워드 |
|----------|--------|
| `scripts/weekly_report.py` | 봇마당, shiporslop |

### 4. 🔑 Secrets (N개 파일)
| 경로 | 설명 |
|------|------|
| `~/.hermes/secrets/shiporslop_auth.txt` | 인증 파일 |

### 5. 📁 GitHub repo 파일 (백업)
| 경로 | 설명 |
|------|------|
| `hermes_bot/memory/botmadang.md` | 백업 메모리 |

### 6. 📝 메모리 파일 수정
| 파일 | 조치 |
|------|------|
| `~/.hermes/memories/MEMORY.md` | 관련 내용 제거 |
```

### ⚠️ 제거하지 말 것

- **활성 크론의 output 로그** — 현재 운영 중인 크론의 출력 디렉토리는 삭제 대상 아님
- **Archive 폴더의 백업** — repo history에 이미 있음

### ✅ 제거 대상

- **고아 크론 출력 디렉토리** — jobs.json에 없는 크론의 출력 디렉토리. error tracker가 false positive를 생성하므로 반드시 정리

## 3단계: 사용자 승인

**반드시 제거목록을 먼저 보여주고 승인을 받아야 실행**

```
제거 목록을 정리했습니다. 이 내용으로 제거 진행할까요?
```

## 4단계: 실행 (승인 후)

### 순서 (이 순서 지켜야 함)

```bash
# 1. Skills 삭제
rm -rf ~/.hermes/skills/automation/<name>/

# 2. Cron Jobs 수정 (jobs.json에서 프롬프트 참조 제거 — patch 후 compile 검증)

# 3. Secrets 삭제 (양쪽 디렉토리 동시)
rm ~/.hermes/secrets/<name>*.txt
# 서브디렉토리도 확인
rm ~/.hermes/hermes_bot/secrets/<name>*.txt 2>/dev/null

# 4. 스크립트에서 참조 제거 (patch + compile 검증 반복)
# → 각 패치 후: python3 -c "compile(open('file.py').read(), 'file.py', 'exec')" 로 검증

# 5. 메모리 파일 수정 (양쪽 모두)
# ~/.hermes/MEMORY.md + ~/.hermes/memories/MEMORY.md

# 6. Git repo 백업 파일 삭제 + commit + push
cd ~/hermes_bot && git add -A && git commit -m "🔧 제거: <name> 관련 파일" && git push
```

### 크론잡 프롬프트 수정

jobs.json에서 직접 프롬프트를 수정하지 않고, `hermes cron update <job_id>` 또는 jobs.json을 patch:

```python
# jobs.json에서 프롬프트의 키워드 라인 제거
import json

with open("/Users/hjshin/.hermes/cron/jobs.json") as f:
    data = json.load(f)

jobs = data["jobs"]
for job in jobs:
    if job["id"] == target_id:
        # 프롬프트에서 특정 라인 제거
        lines = job["prompt"].split("\n")
        cleaned = [l for l in lines if "target_keyword" not in l.lower()]
        job["prompt"] = "\n".join(cleaned)

with open("/Users/hjshin/.hermes/cron/jobs.json", "w") as f:
    json.dump(data, f, ensure_ascii=False, indent=2)
```

## 5단계: 검증

실행 후 반드시 확인:

```bash
# 1. 스킬 디렉토리에서 사라졌는지
ls ~/.hermes/skills/automation/

# 2. 크론잡 목록에서 사라졌는지
hermes cron list

# 3. 키워드 검색 — 더 이상 안 나와야 함
grep -ri "botmadang" ~/.hermes/ --include="*.py" --include="*.md" 2>/dev/null
```

## Known Patterns

- **Notion DB ID가 메모리에만 있고 API에서 404**: 해당 ID를 메모리에서 제거 (DB 자체는 이미 삭제됨)
- **크론잡이 참조하는 스크립트가 실제 존재하지 않음**: 크론잡의 skill 참조를 제거하거나 스크립트 경로 참조 제거
- **Secrets 파일만 있고 어디서도 참조 안 함**: 사용 안 하는 시크릿은 제거
- **🧹 고아 크론 출력 디렉토리 (Orphan Output Cleanup)**: jobs.json에 없는 크론의 출력 디렉토리가 `cron/output/`에 남아 있으면 error tracker가 false positive를 생성함. 제거 대상임 — 아래 참조.

### 고아 크론 출력 디렉토리 정리 절차

```python
# jobs.json의 활성 크론 ID vs cron/output/ 디렉토리 비교
import json, os
from pathlib import Path

data = json.load(open("~/.hermes/cron/jobs.json"))
jobs = data.get("jobs", data) if isinstance(data, dict) else data
active_ids = {j["id"] for j in jobs if j.get("enabled", True)}

output_dir = Path("~/.hermes/cron/output")
orphan = [d for d in output_dir.iterdir() if d.is_dir() and d.name not in active_ids]

print(f"활성 크론: {len(active_ids)}, 고아 디렉토리: {len(orphan)}")
for d in orphan:
    print(f"  {d.name} ({datetime.fromtimestamp(d.stat().st_mtime).date()})")
```

경고 기준: 활성 크론 수(<b>18</b>) vs 출력 디렉토리 수 불일치 시 즉시 조사.

## ⚠️ pitfalls (실행 시 반드시 주의)

### 1. stub 함수 교체 후 orphan 본문이 남는다
함수를 `return {}` 스텁으로 교체해도, 기존 본문 코드가 파일 뒤에 그대로 남아 **중복 정의 + SyntaxError** 발생.

→ **해결**: `def funcname():` 줄부터 `return {...}` 까지 기존 본문과 **한 번에**替换. 절대 스텁만先把 두고 기존 본문을 나중에 제거하지 말 것.

```python
# ❌ 이렇게 하면 안 됨 — 기존 본문이 뒤에 그대로 남음
def collect_botmadang():
    """Deprecated."""
    return {}

# 기존 본문이 여기 그대로 남아 중복 정의 에러!

# ✅ 이렇게 한 번에 처리
def collect_botmadang():
### 1. stub 함수 교체 후 orphan 본문이 남는다
함수를 `return {}` 스텁으로 교체해도, 기존 본문 코드가 파일 뒤에 그대로 남아 **중복 정의 + SyntaxError** 발생.

→ **해결**: `def funcname():` 줄부터 `return {...}` 까지 기존 본문과 **한 번에** 교체. 절대 스텁만先把 두고 기존 본문을 나중에 제거하지 말 것.

### 2. 정규식 대량 제거는 문법을 깨뜨린다
`re.sub(r'\bKEYWORD\b', '')`로 수십 개 키워드를 한꺼번에 처리하면, `None = analyze_xxx()` (함수 호출 결과를 None에 할당), `if condition:`/`elif`/`else` 구조, 빈 함수 정의 등이 발생.

→ **해결**: 정규식은 **참조 횟수 파악 + 라인 단위**에만 사용. 실제 제거는 **patch로 소량씩 분할**하고, 각 패치 후 `compile(content, file, 'exec')`로 **파싱 검증**을 매번 실행.

### 3. stub 반환값이 호출부 호환되는지 확인
`return {}`로 교체하면, 호출부에서 `data["shiporslop"]["ideas"]`처럼 키 접근 시 `KeyError` 발생. 이 경우 `return {"ideas": 0, "failed": 0, "votes": 0, ...}` 처럼 **모든 키를 포함하는 완전한 stub** 반환 필요.

### 4. patch 연속 적용 시 else: / 구조 주의
초기 패치에서 `if 0 == 0:\n    if 0 == 0:` 같은孤儿 if 블록이 생기고, 이후 패치에서 이 블록을 제거할 때 인접한 `else:`까지 한 줄로 병합되어 구조가 깨질 수 있음.

→ **해결**: 각 패치 후 반드시 `compile(content, file, 'exec')`로 검증. 구조가 깨지면 patch로 인접 줄을 정확히 지정하여 교정.

### 5.孤儿된 코드 섹션 감지법
함수 본문 일부만 제거하면 남은 코드가 `state_file.read_text()`처럼 정의되지 않은 변수에 접근하려고 시도. 이런 코드가 남아 있으면 compile 검증에서 NameError나 다른 예외가 발생할 수 있음. **compile 통과 + grep으로 잔여 키워드 확인**을 모두 실행할 것.

### 5. Secrets 양쪽 디렉토리 동시 조사
`~/.hermes/secrets/` **및** `~/.hermes/hermes_bot/secrets/` 양쪽 모두 확인. 특히 토큰 파일(예: `notion_token.txt`)이 secrets에 있을 수 있음.

### 6. MEMORY.md 양쪽 모두 정리
`~/.hermes/MEMORY.md` (root) **및** `~/.hermes/memories/MEMORY.md` 두 파일 모두에서 제거 대상 관련 참조를 정리할 것.

## Known Patterns

- **Notion DB ID가 메모리에만 있고 API에서 404**: 해당 ID를 메모리에서 제거 (DB 자체는 이미 삭제됨)
- **크론잡이 참조하는 스크립트가 실제不存在**: 크론잡의 skill 참조를 제거하거나 스크립트 경로 참조 제거
- **Secrets 파일만 있고 어디서도 참조 안 함**: 사용 안 하는 시크릿은 제거

## 분리된 스킬과 겹침

- `automation-audit-ops`: "무엇이 살아있는지/깨졌는지/중복인지"까지 inventory-first로 진단
- `automation-decommission`: audit 이후 "사용 안 하는 것을 제거"하는 실행 단계
- `automation-healthcheck`: health monitoring에 집중, decommissioning 워크플로우는 없음

→ audit 결과가 "cut"이면 → automation-decommission으로 연결하는 것이 이상적
