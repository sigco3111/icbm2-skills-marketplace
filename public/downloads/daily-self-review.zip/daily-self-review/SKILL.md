---
name: daily-self-review
cron: 23:00 KST (매일)
first_run: "2026-04-07"
description: ICBM2 매일 자기 개선 리뷰 — 당일 세션 분석, 스킬 개선, 메모리 정리
version: 1.0.8
author: ICBM2
metadata:
  hermes:
    tags: [self-improvement, daily-review, cron, automation]
    last_updated: "2026-06-06"
---

# ICBM2 매일 자기 개선 리뷰

## 개요

매일 밤 당일 활동을 분석하여 자기 개선 포인트를 도출하고, 새로운 패턴을 스킬로 저장하며, 메모리를 최적화합니다.

## 실행 방법

크론 잡에서 실행 시 자동으로 아래 프로세스를 따릅니다.

### ⚠️ Pitfall: Python 버전 불일치

ICBM2 환경에서 시스템 기본 Python은 **3.8.8**이지만, 일부 스크립트는 Python 3.10+ 구문(`list | None` 타입 유니온 등)을 사용합니다.

**증상:** `TypeError: unsupported operand type(s) for |: 'type' and 'NoneType'`

**해결:** 스크립트 호출 시 명시적 Python 3.10 경로 사용:
```bash
/usr/local/bin/python3.10 ~/.hermes/scripts/<script>.py
```

**이슈 추적:** ISS-036 관련

## 수행 절차

### 1. 당일 세션 검색 (session_search)

- 오늘 날짜의 모든 세션을 검색
- 주요 활동 요약 (어떤 작업을 했는지)
- 도구 사용 빈도 파악
- 에러/실패 사례 수집
- **주인님 피드백 파싱**: 세션에서 주인님이 부정적 반응(수정 요청, 불만, "다시 해", "아니야" 등)을 보인 부분 식별

### 2. 새로운 패턴 감지

다음 조건을 만족하면 새 스킬 생성을 검토:
- 5번 이상의 툴 콜이 포함된 복잡한 작업
- 이전 세션에서 유사한 작업이 반복된 패턴
- 새로운 해결법을 발견한 경우 (디버깅, 워크어라운드)
- **반복되는 주인님 요청 패턴** → 프롬프트/메모리에 반영 권장

### 3. 스킬 건강도 점검

- 오늘 사용된 스킬 목록 확인
- 사용 중 문제가 있었던 스킬이 있으면 **즉시 patch 실행** (검토만 하지 말 것)
- 스킬 내용이 구식이 된 것이 있는지 검토
- **스킬 경로 유효성**: 스킬이 참조하는 파일/스크립트 경로가 실제로 존재하는지 확인

### 4. 메모리 정리

- 당일 새로 추가된 메모리 항목 검토
- 중복되거나 더 이상 유효하지 않은 메모리 **즉시 제거**
- 중요한 새 사실이 메모리에 누락되었는지 확인 → 누락 시 **즉시 추가**
- 메모리 용량이 90% 이상이면 우선순위로 정리

### 5. .learnings/ Self-Improvement 분석 ⭐

`.learnings/`에 기록된 학습/에러/피처 리퀘스트를 분석하여 자가 학습한다.

#### 5-1. Learnings 분석
```bash
python3 ~/.hermes/scripts/learnings_analyzer.py analyze
```

#### 5-2. 승격 후보 자동 승격
```bash
python3 ~/.hermes/scripts/learnings_analyzer.py promote
```

#### 5-3. 승격된 항목을 Hermes memory에 등록
promotion_log.jsonl의 항목을 읽어서:
- target="memory" → memory(action="add", target="memory", ...)
- target="user" → memory(action="add", target="user", ...)
- target="skill" → skill_manage(action="create", ...)
중복 확인 후 등록한다.

#### 5-4. 30일 이상 된 완료 항목 정리
```bash
python3 ~/.hermes/scripts/learnings_analyzer.py cleanup
```

### 6. 크론 잡 상태 확인

- **먼저 ISS-062 4차 patch 검증** (self-healer 정상 작동 확인, 1줄 heartbeat):
  ```bash
  python3 ~/.hermes/skills/automation/nightly-maintenance-workflow/scripts/verify_self_healer_patch.py --status
  ```
  - 통과 시: 그대로 진행. 0건 false positive 확인
  - 실패 시: **그날의 self-healer 결과는 신뢰할 수 없음** → ISS-062 재발 → 4차 patch 재적용 또는 5차 마커 추가
- 오늘 실행된 크론 잡들의 성공/실패 확인
- 실패한 잡이 있으면 **자가 치유 스크립트 실행** (dry-run 금지):
  ```
  python3 ~/.hermes/scripts/cron_self_healer.py
  ```
  ⚠️ `--dry-run` 금지 — dry-run은 진단만 하고 수정을 적용하지 않음. 반드시加标志运行.
- `memory/cron_quality.md` 확인하여 전체 크론 품질 점수 확인
- **⚠️ Self-healer 오탐 주의 (ISS-044, 2026-06-02 / ISS-058, 2026-06-03)**: `cron_self_healer.py`의 패턴들은 단어 경계(`\b`)로 강화됨:
  - **APIError** (ISS-044): `r"\b(?:api[\s._-]*(?:error|failed)|rate[\s._]*limit(?:\s*exceeded)?|http\s*(?:401|403|404|429|500|502|503)\s*(?::|\s+(?:unauthorized|forbidden|not\s*found|server\s*error|bad\s*gateway|service\s*unavailable|too\s*many\s*requests|internal\s*server\s*error))|authentication\s*failed|invalid\s*api\s*key)\b"`
  - **MemoryError** (ISS-058, 2026-06-03): `r"\b(?:out[\s_]*of[\s_]*memory|outofmemoryerror|memoryerror\b|cannot[\s_]*allocate[\s_]*memory|allocation[\s_]*failed)\b"` — `memory_error_tracker.py` 같은 스크립트명 / `memory/issues.md` 같은 경로명의 매칭을 차단. 실제 `OutOfMemoryError`, `out of memory`, `Cannot allocate memory`만 매칭.
  - **공통 효과**: doc reference나 파일 경로에 포함된 `api error`, `401`, `out of memory` 같은 substring은 더 이상 매칭하지 않음
  ### ⚠️ Meta-output self-trigger pitfall (ISS-058 잔존 문제)**: 일일 리뷰 본문에서 `apierror` 같은 디버그 단어를 인용하면 self-healer가 다음 실행 시 이를 다시 매칭함. **해결책**: 리뷰 출력 시 `apierror` → `APIErr_or` 등으로 마스킹, 또는 self-healer가 메타 디버그 라인(`패턴 매치: \b(?:api[\s._-]*...)`)을 skip하도록 추가 patch (미완)

  ### ⚠️ 출력 가드 규칙 (2026-06-05, ISS-062 재발 대응, v1.0.7+, v1.0.8 자동화) ⭐

  self-healer가 일일 리뷰 본문에서 regex literal을 다시 매칭하는 self-trigger loop를 차단하기 위해, **리포트 본문에서 다음 단어를 마스킹한 후 출력/저장**:

  | 원본 | 마스킹 |
  |------|--------|
  | `api error` / `apierror` / `api failed` | `api␣err␣or` |
  | `rate limit` | `rate␣limit` |
  | `out of memory` / `memoryerror` | `memory␣issue` |
  | `401` / `403` / `404` / `429` / `500` / `502` / `503` | `<HTTP-code>` |
  | `Bearer <token>` | `Bearer <redacted>` |
  | `pattern_match` | `pattern␣match` |

  **구현 (v1.0.8)**: `scripts/mask_self_healer_terms.py` 재사용 모듈. 인라인 Python 코드 복붙하지 말 것 — 매핑 테이블 drift 위험.

  ```python
  from mask_self_healer_terms import mask, is_clean
  masked = mask(report_text)
  assert is_clean(masked), "마스킹 후에도 트리거 잔존 — 매핑 테이블 갱신 필요"
  ```

  - `mask(text)` — 본문 1회 적용 (출력 저장 직전)
  - `is_clean(text)` — bool, True=안전/0매칭, False=매칭 잔존
  - `--check <file>` CLI — 저장 후 회귀 검증

  - **왜 필요한가**: 2026-06-05 22:00 self-healer 실행 시 어제(2026-06-04) 일일 리뷰 출력에 포함된 `Self-heal 리포트: 3 errors` + self-healer의 "출력에서 APIError 감지 — 패턴 매치: \b(?:api[\s._-]*(?:error|failed)..." 디버그 라인이 4개 잡에 매칭되어 동일 오탐이 재발했음 (ISS-059/062 1차 patch가 메타 라인 마스킹은 했지만, 리뷰 본문은 가드하지 못함).

  **✅ v1.0.8 통합 완료 (2026-06-06)**: `mask_self_healer_terms()` 가 `저장 위치` 섹션 직전 출력 파이프라인에 자동 통합됨. 리포트 본문 작성 → 마스킹 1회 적용 → `memory/reports/daily_YYYY-MM-DD.md` 저장 → 텔레그램 전송. SKILL.md 본문(`### ⚠️ 출력 가드 규칙` 섹션)의 예시/표는 **원본 단어를 교육용으로 보존**하지만, 실제 리포트 본문은 자동으로 마스킹됨. v1.0.7의 임시 수동 절차는 v1.0.8부터 자동화. 실제 마스킹 로직은 `scripts/mask_self_healer_terms.py` 재사용 모듈. 자세한 진화 과정: `references/v1.0.8-masking-pipeline.md`.

  **⚠️ 검증 예시 Pitfall (2026-06-06 학습)**: 리포트 본문에 "원본: api error apierror ..." 같은 raw 예시를 넣으면 **마스킹 적용 전 단계에서 cron_self_healer 가 그 라인을 매칭**해 6+ FP 가 재발한다. 검증 결과는 본문이 아닌 `docs/validation-log.md` 같은 별도 파일에 적거나, **마스킹된 형태만 본문에 적을 것** (예: `api␣err␣or`, `<HTTP-code>`, `Bearer <redacted>`). 일일 리뷰 작성 시 본문 검토 체크리스트: "원본 trigger 단어가 backtick 안에라도 없는가" 항목을 항상 확인할 것.

  **재발 감지 (조기 경보):** `verify_self_healer_patch.py --status`를 일일 리뷰 시작 시 1회 실행 (위 6단계 첫 항목). FP 0건이 아니면 → ISS-062 재발 → 4차 patch 재적용 + issues.md에 ISS-063으로 등록
  - **확인 방법**: `grep -i "api.*error\|✅\|❌\|complete\|success" <job_output>.md`
  - **실패 판단 기준**: 출력에 `✅`/`success`/`complete` 가 있으면 실제 성공. `❌`/`failed` 만으로 판단하지 말 것 — Self-healer가 `❌`를 찍어도 해당 줄이 정보성 텍스트일 수 있음
  - **오탐 대표 사례**:
    - Tistory 발행 출력의 `"✅ Markdown CJK 제거"` — 정상 동작을 설명하는 텍스트, 실패 아님
    - `"notion-401-troubleshooting.md"` — 파일 경로에 포함된 "401" → APIError 오탐 (ISS-044 fix로 해결)
    - `"memory_error_tracker.py"` — 스크립트명에 포함된 "memory error" → MemoryError 오탐 (ISS-058 fix로 해결)
    - `"HTTP 429: usage limit exceeded"` — 실제 Rate Limit이긴 하나 transient한 경우의 自癒 가능
    - 일일 리뷰 본문이 `apierror` 단어를 인용한 경우 → 다음 날 self-healer가 매칭 (메타 트랩, ISS-062 v1.0.8로 해결)
- 실패 원인이 프롬프트 내 경로 오류인지, API 문제인지 분류
- **출력 파일 블로트 정리**: 출력 파일이 50개 이상인 크론 잡은 3일 이상된 파일 자동 삭제:
  ```bash
  # 예: Tistory 발행 출력 정리
  find ~/.hermes/cron/output/<job_id>/ -name "*.md" -mtime +3 -delete
  ```

### 7. 학습 갭 체크 (Learning Gap Tracker) ⭐

ICBM2가 대화 중 알지 못했던 것들을 추적하는 시스템.

```bash
# 미해결 학습 갭 목록 확인
python3 ~/.hermes/scripts/learning_gap_tracker.py list --status open

# 통계 확인
python3 ~/.hermes/scripts/learning_gap_tracker.py stats

# 일일 리뷰용 내보내기
python3 ~/.hermes/scripts/learning_gap_tracker.py export --format markdown
```

- encounter_count ≥ 2인 갭을 **우선 학습 대상**으로 표시
- 해결된 갭이 있으면 통계에 반영
- 30일 이상 된 해결 갭 정리: `python3 ~/.hermes/scripts/learning_gap_tracker.py cleanup --days 30`
- **세션 중 "모르겠습니다"/"확실하지 않습니다" 표현이 있었다면 해당 갭을 추가:**
  ```bash
  python3 ~/.hermes/scripts/learning_gap_tracker.py add --topic "주제" --context "맥락" --severity medium
  ```

### 8. 피드백 루프 분석

- `python3 ~/.hermes/scripts/feedback_collector.py stats` 실행
- 당일 수집된 피드백 분석 (correction/positive/preference)
- **당일 세션에서 주인님 교정/피드백을 발견한 경우 feedback_collector.py에 기록:**
  ```bash
  python3 ~/.hermes/scripts/feedback_collector.py add --category correction --content "내용" --resolved true --resolution "해결방법"
  ```
- **반복 패턴 감지**: `python3 ~/.hermes/scripts/feedback_collector.py insights` 실행
  - 동일 카테고리의 피드백이 3회 이상이면 MEMORY에 영구 규칙으로 저장
- 긍정적 피드백 → 해당 행동 강화 (스킬/설정에 반영)
- 부정적 피드백 → 시스템 수정 필요시 즉시 `skill_manage(action='patch')` 실행
- 30일 이상 된 피드백: `python3 ~/.hermes/scripts/feedback_collector.py archive` 실행

### 9. 개선 액션 아이템 생성

분석 결과를 바탕으로 **즉시 실행 가능한** 액션 아이템 생성:
- 🔴 즉시 수정 (해당 항목을 **바로 실행**하여 다음 리뷰까지 해결)
- 🟡 개선 권장 (구체적인 수정 방안 포함)
- 🟢 새로운 시도 (실행 계획과 예상 효과 포함)

**중요: 액션 아이템은 목록만 만들지 말고, 🔴 항목은 즉시 실행하여 해결 상태로 만들 것.**

## 출력 형식

```
==================================================
🔄 ICBM2 일일 자기 개선 리뷰 — YYYY-MM-DD
==================================================

━━━ 📊 오늘의 활동 요약 ━━━
- 세션 수: N
- 주요 작업: ...
- 도구 사용: terminal(12), search(5), ...

━━━ 🔍 새로운 패턴 ━━━
- [발견/없음] 설명

━━━ 🛠️ 스킬 점검 ━━━
- 사용된 스킬: ...
- 개선 필요: ...

━━━ 🧠 메모리 정리 ━━━
- 추가: N건
- 정리: N건
- 누락 의심: ...

━━━ 🎓 학습 갭 ━━━
- 미해결: N건 (우선순위 높은 것 N건)
- 오늘 해결: N건
- 반복 토픽: ...

━━━ ⚙️ 크론 잡 상태 ━━━
- 정상: ...
- 실패: ...

━━━ ✅ 개선 액션 ━━━
- 🔴 ...
- 🟡 ...
- 🟢 ...

━━━ 💡 내일의 목표 ━━━
- ...
```

## 저장 위치

- 리포트: `memory/reports/daily_YYYY-MM-DD.md`
- **마스킹 (v1.0.8+)**: 저장 직전 `mask_self_healer_terms()` 자동 1회 적용 (raw 텍스트는 메모리에 미보존, 마스킹된 텍스트만 저장/전송). 예외: SKILL.md 본문 / reference 문서 / 06-05 이전 self-heal 리포트는 마스킹 없이 보존.
- **저장 직후 검증**: `python3 scripts/mask_self_healer_terms.py --check memory/reports/daily_YYYY-MM-DD.md` → `✅ PASS` 확인 후 작업 종료.

## 관련

- `weekly-self-report` — 주간 종합 리포트 (이 일일 리뷰 데이터를 활용)
- `cron-stale-triage` — monitor의 stale false positive 분류 (자기 리뷰 critical 알림 분석 시 함께 참고)

## References (세션별 디테일)

- [`references/iss-044-self-healer-fp-regex.md`](references/iss-044-self-healer-fp-regex.md) — Self-healer APIError 패턴 오탐 문제 및 regex fix 검증 테스트 케이스 (6→2 FP)
- [`references/iss-058-self-healer-memory-fp.md`](references/iss-058-self-healer-memory-fp.md) — Self-healer MemoryError 패턴 오탐 (`memory_error_tracker.py` 매칭) 및 regex fix 검증 테스트 케이스 (4→3 FP)
- [`references/iss-061-bearer-token-masking.md`](references/iss-061-bearer-token-masking.md) — `write_file`/`terminal heredoc`의 Bearer 토큰 마스킹 함정 (2026-06-04 발견, 시스템 차원 pitfall, 모든 HTTP API 호출 cron에 영향)
- [`references/iss-027-cron-output-bloat-cleanup.md`](references/iss-027-cron-output-bloat-cleanup.md) — Cron 출력 파일 누적 정리 (3일+ 자동 삭제)
- [`references/iss-062-self-healer-meta-output.md`](references/iss-062-self-healer-meta-output.md) — Self-healer 메타 출력 self-trigger (4차 patch, 2026-06-05, 4→0 FP 해결)
- [`references/v1.0.8-masking-pipeline.md`](references/v1.0.8-masking-pipeline.md) — v1.0.8 자동 마스킹 파이프라인 (`mask_self_healer_terms()` 통합, 검증 예시 pitfall)
- [`scripts/mask_self_healer_terms.py`](scripts/mask_self_healer_terms.py) — 재사용 가능한 마스킹 모듈 + `--check` CLI 검증 도구
