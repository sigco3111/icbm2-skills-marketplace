---
name: daily-self-review
description: "ICBM2 매일 자기 개선 리뷰 — 당일 세션 분석, 패턴 감지, 스킬 점검, 메모리 정리, learnings 승격, 크론 상태 확인, 피드백 루프 분석. 매일 22:00 크론으로 자동 실행."
---

# daily-self-review — ICBM2 매일 자기 개선 리뷰

## 개요

매일 22:00에 실행되는 자기 개선 리뷰 크론 잡용 스킬입니다.

**실행 스크립트:** `~/.hermes/scripts/daily_self_review.py` (또는 직접 프로시저 실행)

## 프로시저

### 1. 당일 세션 검색

```bash
session_search(query="YYYY-MM-DD", limit=5)
```

오늘 날짜 세션을 검색하여 주요 활동, 에러, 주인님 피드백을 수집.

### 2. 새로운 패턴 감지

다음 조건을 만족하면 패턴으로 기록:
- 5+ 툴콜 작업
- 반복 패턴 (3회 이상)
- 새로운 해결법 발견
- 반복 주인님 요청

### 3. 스킬 건강도 점검

오늘 사용된 스킬의 문제점을 즉시 patch.
구식 스킬 검토 및 업데이트.

### 4. 메모리 정리

- 당일 추가/중복 메모리 정리
- 누락 의심 항목 즉시 추가
- 90%+ 용량이면 우선 정리

### 5. .learnings/ Self-Improvement 분석

```bash
python3 ~/.hermes/scripts/learnings_analyzer.py analyze
python3 ~/.hermes/scripts/learnings_analyzer.py promote
```

승격된 항목을 promotion_log.jsonl에서 읽어 memory/skill에 등록. 중복 확인 필수.

```bash
python3 ~/.hermes/scripts/learnings_analyzer.py cleanup
```

### 6. 크론 잡 상태 확인

```bash
python3 ~/.hermes/scripts/cron_self_healer.py
```

실패한 잡 → cron_self_healer.py 실행. cron_quality.md 점수 확인.

### 7. 피드백 루프 분석

```bash
python3 ~/.hermes/scripts/feedback_collector.py stats
python3 ~/.hermes/scripts/feedback_collector.py insights
```

반복 패턴(3회+) → MEMORY에 영구 규칙 저장.
긍정 → 강화, 부정 → 즉시 수정.

### 8. 개선 액션 아이템 생성

| 우선순위 | 의미 |
|---------|------|
| 🔴 즉시 실행 | 오늘 내 처리 필요 |
| 🟡 개선 권장 | 이번 주 내 처리 |
| 🟢 새 시도 | 실험적 시도 |

🔴 항목은 바로 해결.

## 출력

리포트 저장: `~/.hermes/memory/reports/daily_YYYY-MM-DD.md`

## 주의사항

- **자기 호출 방지**: 일일 리뷰 크론이 자기 자신을 실행하지 않도록 설계
- **TimeoutError 주의**: 1800s 이상 실행 시 스크립트 분리 검토
- **스킬 파일 존재 확인**: 로드 전 skill_view로 파일 유무 확인
