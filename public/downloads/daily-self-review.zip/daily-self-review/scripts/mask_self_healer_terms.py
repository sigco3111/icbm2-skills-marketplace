#!/usr/bin/env python3
"""
mask_self_healer_terms — ICBM2 v1.0.8 일일 리뷰 출력 가드

WHY THIS SCRIPT EXISTS
======================
cron_self_healer.py 는 ISS-044/058/059/062 에서 강화된 regex 로 다음 4개 카테고리를
매칭한다 (self-trigger 루프 차단용):

  1. APIError  — \b(?:api[\s._-]*(?:error|failed)|rate[\s._]*limit|http\s*(?:401|403|404|429|500|502|503)...)
  2. MemoryError — \b(?:out[\s_]*of[\s_]*memory|memoryerror\b|cannot[\s_]*allocate[\s_]*memory|...)
  3. HTTP 코드 단독 (401~503)
  4. Bearer <token> / pattern_match

daily-self-review 가 본문에 위 단어를 그대로 남기면, 다음 자가치유 실행 시
self-healer 가 자기 출력을 매칭해 오탐을 만든다 (ISS-062 4차 patch 이전 사고).

이 스크립트는 daily-self-review 출력 직전에 1회 호출돼 매칭 단어를 안전한
문자열로 치환한다 (raw 텍스트는 메모리에 미보존, 마스킹된 텍스트만 저장/전송).

USAGE
=====
    from mask_self_healer_terms import mask, is_clean
    masked = mask(report_text)
    assert is_clean(masked), "마스킹 후에도 트리거 잔존"

또는 CLI:
    python3 mask_self_healer_terms.py < daily_review.md > masked_review.md
    python3 mask_self_healer_terms.py --check daily_review.md           # 단일 파일 매칭 검증
    # ISS-070 (2026-06-12) 추가: 디렉토리 일괄 점검 + retro-masking
    python3 mask_self_healer_terms.py --check-dir ~/.hermes/cron/output # 재귀 dirty 파일 N개 식별
    python3 mask_self_healer_terms.py --mask-dir ~/.hermes/cron/output  # 재귀 일괄 retro-masking

PITFALL: 예시/검증 섹션에 raw 단어를 넣지 말 것
================================================
이 함수를 검증하기 위해 "원본: api error apierror ..." 같은 예시 라인을
리포트 본문에 넣으면, **마스킹 적용 전 단계에서 cron_self_healer 가 그 라인을
매칭**해 6+ false positive 가 다시 발생한다. 검증 결과는 본문이 아닌
docs/validation-log.md 같은 별도 파일에 적을 것.

SKILL.md 본문 / reference 문서 / 06-05 이전 self-heal 리포트는 마스킹 대상이
아니다 (교육·기록 보존). 이 스크립트는 일일 리뷰 *출력*에만 적용.
"""

# ISS-065 fix: Python 3.8 (시스템 기본) 호환을 위해 PEP 563 __future__ import
# 추가. 이로 인해 `def main(argv: list[str])` 같은 PEP 585 어노테이션이
# lazy string으로 평가되어 3.8에서 TypeError 발생하지 않음.
from __future__ import annotations

import re
import sys

# 매핑 테이블 — 안전 문자 (U+2423 Symbol for Space) 사용.
# self-healer regex 의 일부가 [\s._-]* 매처를 갖고 있어 실제 공백/하이픈을 쓰면
# 다시 매칭될 수 있으므로 일반 ASCII 공백 대신 U+2423 (␣) 사용.
_MASK_TABLE = [
    (r'\bapi[\s._-]*(?:error|failed)\b', 'api\u2423err\u2423or'),
    (r'\brate[\s._]*limit\b', 'rate\u2423limit'),
    (r'\b(?:out[\s_]*of[\s_]*memory|memoryerror)\b', 'memory\u2423issue'),
    (r'\b(?:401|403|404|429|500|502|503)\b', '<HTTP-code>'),
    (r'Bearer\s+\S+', 'Bearer <redacted>'),
    (r'pattern_match', 'pattern\u2423match'),
    # ISS-067 (2026-06-09): self-healer `(?:file|path|directory).*(?:not found|does not exi)`
    # 패턴이 meta-output("FileNotFoundError 매칭 0건")을 재매칭. FileNotFoundError /
    # PathNotFoundError 같은 Python 예외 클래스명 + 자유 텍스트 "file ... not found"를
    # 안전한 문자열로 치환.
    (r'\bFileNotFoundError\b', 'file\u2423not\u2423found\u2423issue'),
    (r'\bPathNotFoundError\b', 'file\u2423not\u2423found\u2423issue'),
    (r'\bNo such file or directory\b', 'file\u2423not\u2423found\u2423issue'),
    # Note: `(?:file|path|directory).*(?:not found|does not exi)` — 멀티라인에서
    # 라인 안에 'directory' + 'no such file or directory' 또는 'not found' 형태가
    # 있으면 매칭. 단어 단위로 매칭하되 'current working directory: ... No such file' 같은
    # 표현도 모두 catch. 단어 경계 + greedy '.*' (newline 제외) 매칭.
    (r'\b(?:file|path|directory)\b[^.\n]{0,200}\b(?:not\s+found|does\s+not\s+exist|no\s+such\s+file)\b', 'file\u2423not\u2423found\u2423issue'),
    # ISS-076 (2026-06-19): cron_self_healer의 TimeoutError 패턴
    # `r"\b(?:timeout|timed\s*out|deadline\s*exceeded)\b"` 가 meta-output
    # "[output_error] 출력에서 TimeoutError 감지" 라인을 재매칭. 2026-06-19
    # self-heal_2026-06-19.md에서 1건 raw trigger 잔존 → 매핑 추가.
    (r'\bTimeoutError\b', 'timeout\u2423issue'),
    (r'\b(?:timed\s*out|deadline\s*exceeded)\b', 'timeout\u2423issue'),
    (r'\bconnection\s+timeout\b', 'timeout\u2423issue'),
]  # noqa: E501


def mask(text: str) -> str:
    """리포트 본문에서 self-healer 매칭 단어를 안전한 마스킹 문자열로 치환.

    Returns:
        마스킹된 텍스트. 입력 텍스트는 변경되지 않는다 (string 은 immutable).
    """
    if not isinstance(text, str):
        raise TypeError(f"mask() expects str, got {type(text).__name__}")

    out = text
    for pat, repl in _MASK_TABLE:
        out = re.sub(pat, repl, out, flags=re.IGNORECASE)
    return out


def is_clean(text: str) -> bool:
    """self-healer 가 매칭할 수 있는 단어가 *없으면* True.

    True means: 0 매칭 (안전).
    False means: 1건+ 매칭 (mask() 가 제대로 안 됐거나 새 트리거 카테고리 추가됨).

    bool 의미가 직관적 (is_clean == True ↔ 안전). 매칭 검출은 _has_trigger() 사용.
    """
    if not isinstance(text, str):
        raise TypeError(f"is_clean() expects str, got {type(text).__name__}")

    return not _has_trigger(text)


def _has_trigger(text: str) -> bool:
    """내부: 마스킹된 텍스트에 self-healer 트리거 단어가 남아있는지 검사.

    Returns:
        True if 매칭 1건+ 발견, False if 0건.
        (boolean 의미가 직관적 — "trigger 가 있다/없다")
    """
    # 5개 카테고리 패턴 (실제 self-healer 의 regex 와 동기화, ISS-067)
    test_patterns = [
        r'\bapi[\s._-]*error\b',
        r'\bapierror\b',
        r'\brate[\s._]*limit(?:\s+exceeded)?\b',
        r'\b(?:out[\s_]*of[\s_]*memory|memoryerror)\b',
        r'\b(?:401|403|404|429|500|502|503)\b',
        r'Bearer\s+[A-Za-z0-9_.-]+',
        r'pattern_match',
        # ISS-067 (2026-06-09): FileNotFoundError meta-output
        r'\bFileNotFoundError\b',
        r'\bPathNotFoundError\b',
        r'\bNo such file or directory\b',
        r'\b(?:file|path|directory)\b[^.\n]{0,200}\b(?:not\s+found|does\s+not\s+exist|no\s+such\s+file)\b',
        # ISS-076 (2026-06-19): TimeoutError 패턴 동기화
        r'\bTimeoutError\b',
        r'\b(?:timed\s*out|deadline\s*exceeded)\b',
        r'\bconnection\s+timeout\b',
    ]  # noqa: E501
    for pat in test_patterns:
        if re.search(pat, text, re.IGNORECASE):
            return True
    return False


def _cli_check(path: str) -> int:
    """--check 모드: 파일에서 매칭 0건인지 검사하고 결과 출력."""
    with open(path, encoding='utf-8') as f:
        text = f.read()
    if is_clean(text):
        print(f"✅ PASS: {path} is clean (0 self-healer triggers)")
        return 0
    # 어느 패턴이 매칭됐는지 디버깅 힌트
    test_patterns = {
        'APIError': r'\b(?:api[\s._-]*(?:error|failed)|rate[\s._]*limit(?:\s*exceeded)?|http\s*(?:401|403|404|429|500|502|503))',
        'MemoryError': r'\b(?:out[\s_]*of[\s_]*memory|memoryerror\b)',
        'HTTP code': r'\b(?:401|403|404|429|500|502|503)\b',
        'Bearer': r'Bearer\s+\S+',
        'pattern_match': r'pattern_match',
    }
    print(f"❌ FAIL: {path} still contains self-healer trigger words", file=sys.stderr)
    for name, pat in test_patterns.items():
        for m in re.finditer(pat, text, re.IGNORECASE):
            s = max(0, m.start() - 20)
            e = min(len(text), m.end() + 20)
            print(f"  [{name}] ...{text[s:e]!r}...", file=sys.stderr)
    return 1


def _cli_check_dir(dir_path: str, recursive: bool = True) -> int:
    """--check-dir 모드: 디렉토리 전체의 *.md 파일을 재귀로 검사.

    ISS-070 (2026-06-12) 추가. 자기 가드 시스템이 자기 산출물 누적을 catch
    못했던 한계 보완. v1.0.13 step 11 (자기 cron output 사후 masking) 은
    "신규 발생분"만 처리, 7일치 누적된 81개 dirty 파일은 일괄 catch 못했음.
    이 CLI는 cron prompt 첫 step에서 호출되어 dirty 파일 N개를 즉시 식별.

    Returns:
        0 if 모든 파일 clean, 1 if 1건+ dirty 발견.
    """
    from pathlib import Path
    root = Path(dir_path)
    if not root.exists():
        print(f"⚠️  {dir_path} 디렉토리 없음 (첫 실행?)")
        return 0
    if not root.is_dir():
        print(f"❌ {dir_path} 는 디렉토리가 아닙니다", file=sys.stderr)
        return 2

    glob_pattern = "**/*.md" if recursive else "*.md"
    files = sorted(root.glob(glob_pattern))
    if not files:
        print(f"ℹ️  {dir_path} 에 .md 파일 없음")
        return 0

    clean_count = 0
    dirty_list = []
    for f in files:
        text = f.read_text(encoding='utf-8', errors='replace')
        if is_clean(text):
            clean_count += 1
        else:
            dirty_list.append(f)

    total = clean_count + len(dirty_list)
    if not dirty_list:
        print(f"✅ PASS: {dir_path} 전체 {total}개 .md clean (0 self-healer triggers)")
        return 0
    print(f"❌ DIRTY: {dir_path} 의 {total}개 중 {len(dirty_list)}개 trigger 잔존", file=sys.stderr)
    for f in dirty_list[:20]:  # 처음 20개만 (출력 폭발 방지)
        try:
            rel = f.relative_to(root)
        except ValueError:
            rel = f
        print(f"  - {rel}", file=sys.stderr)
    if len(dirty_list) > 20:
        print(f"  ... 외 {len(dirty_list) - 20}개", file=sys.stderr)
    print(f"\n💡 일괄 retro-masking:", file=sys.stderr)
    print(f"   python3 .../mask_self_healer_terms.py --mask-dir {dir_path}", file=sys.stderr)
    return 1


def _cli_mask_dir(dir_path: str, recursive: bool = True) -> int:
    """--mask-dir 모드: 디렉토리 전체의 *.md 파일에 일괄 masking 적용.

    ISS-070 fix 핵심. dirty 파일 N개를 식별한 후 일괄 retro-masking.
    is_clean() FAIL이 0건이면 exit 0, 1건+이면 exit 1 (매핑 테이블 점검).

    Returns:
        0 if 모든 dirty 파일이 is_clean 통과, 1 if 매핑 테이블 추가 필요.
    """
    from pathlib import Path
    root = Path(dir_path)
    if not root.exists():
        print(f"⚠️  {dir_path} 디렉토리 없음 (첫 실행?)")
        return 0
    if not root.is_dir():
        print(f"❌ {dir_path} 는 디렉토리가 아닙니다", file=sys.stderr)
        return 2

    glob_pattern = "**/*.md" if recursive else "*.md"
    files = sorted(root.glob(glob_pattern))
    if not files:
        print(f"ℹ️  {dir_path} 에 .md 파일 없음")
        return 0

    masked_count = 0
    no_change_count = 0
    fail_list = []
    for f in files:
        content = f.read_text(encoding='utf-8', errors='replace')
        if is_clean(content):
            no_change_count += 1
            continue
        masked = mask(content)
        if is_clean(masked):
            f.write_text(masked)
            masked_count += 1
        else:
            fail_list.append(f)

    total = len(files)
    print(f"✅ {dir_path} 일괄 masking 완료:")
    print(f"   - 전체: {total}개 .md")
    print(f"   - 변경 (raw → masked): {masked_count}개")
    print(f"   - 변경 없음 (이미 clean): {no_change_count}개")
    if fail_list:
        print(f"   ❌ is_clean FAIL: {len(fail_list)}개 — 매핑 테이블 점검 필요", file=sys.stderr)
        for f in fail_list[:10]:
            try:
                rel = f.relative_to(root)
            except ValueError:
                rel = f
            print(f"     - {rel}", file=sys.stderr)
        return 1
    return 0


def _cli_mask(path: str) -> int:
    """stdin/파일 → stdout 마스크."""
    if path == '-':
        text = sys.stdin.read()
    else:
        with open(path, encoding='utf-8') as f:
            text = f.read()
    sys.stdout.write(mask(text))
    return 0


def main(argv: list[str]) -> int:
    if len(argv) < 2:
        # stdin → stdout
        return _cli_mask('-')

    cmd = argv[1]
    if cmd == '--check':
        if len(argv) < 3:
            print("Usage: mask_self_healer_terms.py --check <file>", file=sys.stderr)
            return 2
        return _cli_check(argv[2])
    elif cmd in ('--check-dir', '--mask-dir'):
        if len(argv) < 3:
            print(f"Usage: mask_self_healer_terms.py {cmd} <dir> [--no-recursive]", file=sys.stderr)
            return 2
        recursive = '--no-recursive' not in argv[3:]
        if cmd == '--check-dir':
            return _cli_check_dir(argv[2], recursive=recursive)
        else:  # --mask-dir
            return _cli_mask_dir(argv[2], recursive=recursive)
    elif cmd in ('--help', '-h'):
        print(__doc__)
        return 0
    else:
        return _cli_mask(argv[1])


if __name__ == '__main__':
    sys.exit(main(sys.argv))
