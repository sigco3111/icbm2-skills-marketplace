#!/usr/bin/env python3
"""
mask_self_healer_terms — ICBM2 v1.0.8 일일 리뷰 출력 가드

WHY THIS SCRIPT EXISTS
======================
cron_self_healer.py 는 ISS-044/058/059/062 에서 강화된 regex 로 다음 4개 카테고리를
매칭한다 (self-trigger 루프 차단용):

  1. APIError  — \b(?:api[\s._-]*(?:error|failed)|rate[\s._]*limit|http\s*(?:401|403|404|429|500|502|503)...)
  2. MemoryError — \b(?:out[\s_]*of[\s_]*memory|memoryerror\b|cannot[\s_]*allocate[\s_]*memory|...)
  3. HTTP 코드 단독 (401~503)
  4. Bearer <token> / pattern_match

daily-self-review 가 본문에 위 단어를 그대로 남기면, 다음 자가치유 실행 시
self-healer 가 자기 출력을 매칭해 오탐을 만든다 (ISS-062 4차 patch 이전 사고).

이 스크립트는 daily-self-review 출력 직전에 1회 호출돼 매칭 단어를 안전한
문자열로 치환한다 (raw 텍스트는 메모리에 미보존, 마스킹된 텍스트만 저장/전송).

USAGE
=====
    from mask_self_healer_terms import mask, is_clean
    masked = mask(report_text)
    assert is_clean(masked), "마스킹 후에도 트리거 잔존"

또는 CLI:
    python3 mask_self_healer_terms.py < daily_review.md > masked_review.md
    python3 mask_self_healer_terms.py --check daily_review.md   # 매칭 0건 검증

PITFALL: 예시/검증 섹션에 raw 단어를 넣지 말 것
================================================
이 함수를 검증하기 위해 "원본: api error apierror ..." 같은 예시 라인을
리포트 본문에 넣으면, **마스킹 적용 전 단계에서 cron_self_healer 가 그 라인을
매칭**해 6+ false positive 가 다시 발생한다. 검증 결과는 본문이 아닌
docs/validation-log.md 같은 별도 파일에 적을 것.

SKILL.md 본문 / reference 문서 / 06-05 이전 self-heal 리포트는 마스킹 대상이
아니다 (교육·기록 보존). 이 스크립트는 일일 리뷰 *출력*에만 적용.
"""

import re
import sys

# 매핑 테이블 — 안전 문자 (U+2423 Symbol for Space) 사용.
# self-healer regex 의 일부가 [\s._-]* 매처를 갖고 있어 실제 공백/하이픈을 쓰면
# 다시 매칭될 수 있으므로 일반 ASCII 공백 대신 U+2423 (␣) 사용.
_MASK_TABLE = [
    (r'\bapi[\s._-]*(?:error|failed)\b', 'api\u2423err\u2423or'),
    (r'\brate[\s._]*limit\b', 'rate\u2423limit'),
    (r'\b(?:out[\s_]*of[\s_]*memory|memoryerror)\b', 'memory\u2423issue'),
    (r'\b(?:401|403|404|429|500|502|503)\b', '<HTTP-code>'),
    (r'Bearer\s+\S+', 'Bearer <redacted>'),
    (r'pattern_match', 'pattern\u2423match'),
]


def mask(text: str) -> str:
    """리포트 본문에서 self-healer 매칭 단어를 안전한 마스킹 문자열로 치환.

    Returns:
        마스킹된 텍스트. 입력 텍스트는 변경되지 않는다 (string 은 immutable).
    """
    if not isinstance(text, str):
        raise TypeError(f"mask() expects str, got {type(text).__name__}")

    out = text
    for pat, repl in _MASK_TABLE:
        out = re.sub(pat, repl, out, flags=re.IGNORECASE)
    return out


def is_clean(text: str) -> bool:
    """self-healer 가 매칭할 수 있는 단어가 *없으면* True.

    True means: 0 매칭 (안전).
    False means: 1건+ 매칭 (mask() 가 제대로 안 됐거나 새 트리거 카테고리 추가됨).

    bool 의미가 직관적 (is_clean == True ↔ 안전). 매칭 검출은 _has_trigger() 사용.
    """
    if not isinstance(text, str):
        raise TypeError(f"is_clean() expects str, got {type(text).__name__}")

    return not _has_trigger(text)


def _has_trigger(text: str) -> bool:
    """내부: 마스킹된 텍스트에 self-healer 트리거 단어가 남아있는지 검사.

    Returns:
        True if 매칭 1건+ 발견, False if 0건.
        (boolean 의미가 직관적 — "trigger 가 있다/없다")
    """
    # 4개 카테고리 패턴 (실제 self-healer 의 regex 와 동기화)
    test_patterns = [
        r'\bapi[\s._-]*error\b',
        r'\bapierror\b',
        r'\brate[\s._]*limit(?:\s+exceeded)?\b',
        r'\b(?:out[\s_]*of[\s_]*memory|memoryerror)\b',
        r'\b(?:401|403|404|429|500|502|503)\b',
        r'Bearer\s+[A-Za-z0-9_.-]+',
        r'pattern_match',
    ]
    for pat in test_patterns:
        if re.search(pat, text, re.IGNORECASE):
            return True
    return False


def _cli_check(path: str) -> int:
    """--check 모드: 파일에서 매칭 0건인지 검사하고 결과 출력."""
    with open(path, encoding='utf-8') as f:
        text = f.read()
    if is_clean(text):
        print(f"✅ PASS: {path} is clean (0 self-healer triggers)")
        return 0
    # 어느 패턴이 매칭됐는지 디버깅 힌트
    test_patterns = {
        'APIError': r'\b(?:api[\s._-]*(?:error|failed)|rate[\s._]*limit(?:\s*exceeded)?|http\s*(?:401|403|404|429|500|502|503))',
        'MemoryError': r'\b(?:out[\s_]*of[\s_]*memory|memoryerror\b)',
        'HTTP code': r'\b(?:401|403|404|429|500|502|503)\b',
        'Bearer': r'Bearer\s+\S+',
        'pattern_match': r'pattern_match',
    }
    print(f"❌ FAIL: {path} still contains self-healer trigger words", file=sys.stderr)
    for name, pat in test_patterns.items():
        for m in re.finditer(pat, text, re.IGNORECASE):
            s = max(0, m.start() - 20)
            e = min(len(text), m.end() + 20)
            print(f"  [{name}] ...{text[s:e]!r}...", file=sys.stderr)
    return 1


def _cli_mask(path: str) -> int:
    """stdin/파일 → stdout 마스크."""
    if path == '-':
        text = sys.stdin.read()
    else:
        with open(path, encoding='utf-8') as f:
            text = f.read()
    sys.stdout.write(mask(text))
    return 0


def main(argv: list[str]) -> int:
    if len(argv) < 2:
        # stdin → stdout
        return _cli_mask('-')

    if argv[1] == '--check':
        if len(argv) < 3:
            print("Usage: mask_self_healer_terms.py --check <file>", file=sys.stderr)
            return 2
        return _cli_check(argv[2])
    elif argv[1] in ('--help', '-h'):
        print(__doc__)
        return 0
    else:
        return _cli_mask(argv[1])


if __name__ == '__main__':
    sys.exit(main(sys.argv))
