"""Hermes ad-hoc verification for daily-self-review changes (2026-06-29+).

Reusable verification script for step 14 of the daily-self-review workflow.
Validates the 4/4 self-cleanup state at end-of-review.

Verifies:
  1. MEMORY.md under 4000-byte limit (v1.0.16 exit criterion: < 90% = 3600 bytes)
  2. daily report has no self-healer trigger words
  3. All cron output .md files are clean
  4. Today's self_heal_*.md is clean
  5. verify_self_healer_patch.py returns PASS

Usage:
    python3 verify_daily_review.py
    python3 verify_daily_review.py 2026-06-29  # specify date

Pitfall — write to /var/folders/.../T/ directly is blocked by security policy.
Use this script via skill_manage or copy to a working directory before run.

Cron mode safe: no execute_code or cat|python3 usage.
"""
from __future__ import annotations
import os
import subprocess
import sys
import importlib.util
from pathlib import Path

HOME = Path(os.path.expanduser("~"))
SKILL_DIR = HOME / ".hermes/skills/automation/daily-self-review"
MASK = SKILL_DIR / "scripts" / "mask_self_healer_terms.py"
VERIFY = HOME / ".hermes/skills/automation/nightly-maintenance-workflow/scripts/verify_self_healer_patch.py"

LIMIT = 4000
EXIT_GREEN = int(LIMIT * 0.90)  # 3600 bytes — v1.0.16 exit criterion

# Parse date argument (default: today)
if len(sys.argv) > 1:
    date_str = sys.argv[1]
else:
    from datetime import date
    date_str = date.today().isoformat()

MEMORY = HOME / ".hermes" / "memory" / "MEMORY.md"
DAILY = HOME / ".hermes" / "memory" / "reports" / f"daily_{date_str}.md"
SELF_HEAL = HOME / ".hermes" / "memory" / f"self_heal_{date_str}.md"
CRON_DIR = HOME / ".hermes" / "cron" / "output"

results = []


def check(name: str, ok: bool, detail: str = "") -> None:
    status = "PASS" if ok else "FAIL"
    results.append((name, ok, detail))
    print(f"[{status}] {name} -- {detail}")


# 1. MEMORY.md size
if MEMORY.exists():
    mem_size = MEMORY.stat().st_size
    mem_pct = mem_size / LIMIT * 100
    check(
        f"MEMORY.md under 90% of {LIMIT}-byte limit (v1.0.16 exit criterion)",
        mem_size < EXIT_GREEN,
        f"{mem_size} bytes / {LIMIT} ({mem_pct:.1f}%)",
    )
else:
    check("MEMORY.md exists", False, "file missing")

# 2. daily report masking
if DAILY.exists():
    spec = importlib.util.spec_from_file_location("masker", MASK)
    masker = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(masker)
    daily_text = DAILY.read_text()
    check(
        f"daily_{date_str}.md is clean (0 self-healer triggers)",
        masker.is_clean(daily_text),
        f"{len(daily_text)} bytes",
    )
else:
    check(f"daily_{date_str}.md exists", False, "file missing")

# 3. cron output all clean (uses masker from step 2 if available)
if 'masker' in dir():
    cron_total = 0
    cron_dirty = 0
    for f in CRON_DIR.glob("*/*.md"):
        cron_total += 1
        if not masker.is_clean(f.read_text()):
            cron_dirty += 1
    check(
        "All cron output .md files clean",
        cron_dirty == 0,
        f"{cron_total} files scanned, {cron_dirty} dirty",
    )
else:
    check("cron output clean (skipped — no masker)", False, "step 2 failed")

# 4. self_heal today
if SELF_HEAL.exists():
    sh_text = SELF_HEAL.read_text()
    check(
        f"self_heal_{date_str}.md is clean",
        masker.is_clean(sh_text),
        f"{len(sh_text)} bytes",
    )
else:
    check(f"self_heal_{date_str}.md exists", False, "file missing (may be normal)")

# 5. verify_self_healer_patch.py
if VERIFY.exists():
    out = subprocess.run(
        [sys.executable, str(VERIFY), "--status"],
        capture_output=True, text=True,
    )
    verify_pass = out.returncode == 0
    last_line = out.stdout.strip().splitlines()[-1] if out.stdout else "(empty)"
    check(
        "verify_self_healer_patch.py --status returns PASS",
        verify_pass,
        f"exit={out.returncode} stdout='{last_line}'",
    )
else:
    check("verify_self_healer_patch.py exists", False, "script missing")

# Summary
total = len(results)
passed = sum(1 for _, ok, _ in results if ok)
print()
print(f"=== {passed}/{total} checks passed ===")
sys.exit(0 if passed == total else 1)
