# ISS-063 — SKILL.md doc vs cron job prompt drift (v1.0.9 root cause)

**Issue ID**: ISS-063
**Discovered**: 2026-06-07 22:00 KST (verify_self_healer_patch.py heartbeat)
**Resolved**: 2026-06-07 22:08 KST (cron job prompt 9단계 patch + retro-masking)
**Related**: ISS-044, ISS-058, ISS-059, ISS-062 (self-healer FP lineage)

## 증상

`verify_self_healer_patch.py --status` 실행 시 4 jobs 중 1 FAIL:
```
❌ 5d0f14aef84c 일일 자기 개선 리뷰: FAIL — 2 FP in 2026-06-06_22-07-21.md
✅ 388898171a79 지식 그래프 자동 구축: PASS
✅ 075bec58df7b 오전 통합 인사이트: PASS
✅ ed5f37705e68 심야 통합 점검: PASS
```

매칭 위치 (실제 grep, 2026-06-06 22:07 출력):
- 라인 132-133: `api error` / `apierror` / `api failed` — raw 단어 그대로 인용
- 라인 168: `apierror` — 검증 예시로 적힘
- self-healer regex `\b(?:api[\s._-]*(?:error|failed)|...`가 그대로 매칭

## Root cause: SKILL.md doc vs cron job prompt drift

v1.0.8 패치 (2026-06-06) 는:
- ✅ `scripts/mask_self_healer_terms.py` 모듈 작성
- ✅ SKILL.md 본문에 `from mask_self_healer_terms import mask` Python import 예시 추가
- ✅ `references/v1.0.8-masking-pipeline.md`에 "자동 통합 완료"라고 문서화
- ❌ **`~/.hermes/cron/jobs.json`의 `5d0f14aef84c` prompt에는 masking step 추가 안 됨**

**결과:** LLM이 SKILL.md 본문까지 매번 끝까지 읽고 모든 가이드를 따르지 않음. 특히 "자동"이라는 단어가 있어도 **cron job prompt(`jobs.json`)에 명시적 step이 없으면 적용되지 않음**.

## 해결 (v1.0.9)

1. **cron job prompt 9단계 추가** — `5d0f14aef84c`의 `prompt` 필드 끝에:
   ```bash
   ## 9. 출력 가드 (필수, v1.0.8+)
   저장 직전 반드시 `mask_self_healer_terms()`로 본문 1회 마스킹:
   python3 ~/.hermes/skills/automation/daily-self-review/scripts/mask_self_healer_terms.py ~/.hermes/memory/reports/daily_2026-06-07.md
   - `api error` → `api␣err␣or`, `Bearer <token>` → `Bearer <redacted>` 등
   - 마스킹된 텍스트만 저장/전송. raw 본문은 메모리에 미보존.
   - **Pitfall**: 본문에 trigger 단어를 backtick 안에라도 적지 말 것.
   - 저장 직후 `--check` → `✅ PASS` 확인 필수.
   ```

2. **어제 파일 retro-masking**:
   ```bash
   python3 mask_self_healer_terms.py ~/.hermes/cron/output/5d0f14aef84c/2026-06-06_22-07-21.md > /tmp/masked.md
   cp /tmp/masked.md ~/.hermes/cron/output/5d0f14aef84c/2026-06-06_22-07-21.md
   python3 mask_self_healer_terms.py --check ~/.hermes/cron/output/5d0f14aef84c/2026-06-06_22-07-21.md
   # → ✅ PASS
   ```

3. **verify 스크립트 재실행**:
   ```bash
   python3 verify_self_healer_patch.py
   # → ✅ 4/4 PASS
   ```

## 핵심 교훈 (v1.0.9 + v1.1.0+)

### 1. SKILL.md ≠ cron job prompt

| 위치 | 강제력 | 비고 |
|------|--------|------|
| SKILL.md 본문 | 🟡 약함 — LLM이 매번 따르지 않음 | "참고용 가이드" |
| `~/.hermes/cron/jobs.json`의 `prompt` | 🟢 강함 — LLM이 매번 받음 | "진짜 실행 지시" |
| 스킬의 references/ | 🟡 약함 — 필요시만 읽음 | "보조 문서" |

새 기능을 추가할 때는 **반드시 cron job prompt의 해당 step까지 patch**해야 함. SKILL.md만 patch하면 doc drift 발생.

### 2. verify 스크립트는 "정직한 보고자"

`verify_self_healer_patch.py`는 매 실행마다 cron output의 실제 trigger 매칭을 검사. SKILL.md가 "자동 통합"이라고 주장해도 verify가 FAIL이면 doc drift. **verify = doc-drift detector** 역할.

### 3. 5차 patch를 안 한 이유

ISS-062 4차 patch의 informational 마커 13개로도 ISS-063 케이스를 못 잡음. 5차 마커 추가는 **역효과 (정상 운영 텍스트를 막을 위험)**. 진짜 해결은 입력 측(self-healer)이 아니라 **출력 측(daily-self-review)에서 마스킹**하는 것. 양방향 의존성에서 출력 측 가드가 정답.

### 4. 재발 방지 체크리스트 (daily review 시작 시)

- [ ] `verify_self_healer_patch.py --status` 1줄 확인 (heartbeat)
- [ ] FAIL이면 → ISS-063 의심 → cron job prompt 9단계 + retro-masking
- [ ] SKILL.md 새 기능 추가 시 → cron job prompt도 동시 patch
- [ ] "자동"이라는 단어를 SKILL.md에 쓸 때 → cron job prompt에 step이 있는지 재확인

## 시간순 정리

| 시각 | 이벤트 |
|------|--------|
| 2026-06-05 22:00 | ISS-059/062 1차 patch (4차 patch) — self-healer 측 regex 강화 |
| 2026-06-06 22:00 | v1.0.8 daily review — SKILL.md에 mask 가이드 추가, cron prompt는 미변경 |
| 2026-06-07 03:30 | 심야 점검 — self-healer 정상 (0 errors) |
| 2026-06-07 15:32 | weekly report — Notion 토큰 401 (ISS-064, 별도) |
| 2026-06-07 22:00 | 일일 리뷰 22:00 verify → 1건 FP 감지 (ISS-063) |
| 2026-06-07 22:05 | 어제 파일 retro-masking → verify 4/4 PASS |
| 2026-06-07 22:08 | cron job prompt 9단계 추가 (v1.0.9) + SKILL.md patch + reference 작성 |
