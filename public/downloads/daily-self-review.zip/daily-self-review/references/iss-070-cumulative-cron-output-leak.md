# ISS-070 — 자기 가드 시스템 누적 누락 (6차 재발)

**날짜**: 2026-06-12 22:00 KST
**심각도**: 🔴 CRITICAL (자기 가드 시스템이 7일치 자기 산출물 누적을 catch 못함)
**ISS 트리거**: ISS-062 6차 재발

---

## 1. 문제 정의 (Root Cause)

v1.0.13 SKILL.md는 step 11 (자기 cron output + self_heal_*.md 사후 마스킹)을 jobs.json `5d0f14aef84c` prompt에 명시했음. 하지만 **step 11은 "신규 발생분만" 처리**하는 구조:

```python
# step 11 코드 (v1.0.13, 06-11)
for f in sorted(job_dir.glob("*.md")):
    content = f.read_text()
    masked = masker.mask(content)
    if masker.is_clean(masked) and masked != content:
        f.write_text(masked)  # ← 변경분만 write
```

→ cron prompt에서 매번 실행되지만, **1일 1회 실행되는 step 11이 어제까지 누적된 7일치 raw trigger 파일들 (Tistory 61개 + 일일 리뷰 자기 1개 + 지식 그래프 6개 + 오전 인사이트 6개 + 심야 점검 4개 + Dev News 1개 + 일요일 점검 1개 + 긱뉴스 1개 + GH Trending 1개 = 총 81개)** 을 한 번에 catch하지 못함.

**누적 경로**:
- 06-06 v1.0.10 patch: 자기 cron output 사후 적용 권장 (SKILL.md 본문만)
- 06-07 v1.0.11 patch: `_MASK_TABLE` 4 패턴 추가 (Tistory 12건 retro) — 한시적
- 06-08 v1.0.10 patch: cron output 1회 적용 (이 시점 7일치 중 일부만)
- 06-11 v1.0.13 patch: step 11 cron prompt 명시 (앞으로 1일 1회만)
- **06-12 오늘**: 7일치 누적 81개 dirty 발견. step 11이 7일치를 backfill 하지 않은 격.

→ **자기 가드 시스템이 자기 자신을 보호하지 못하는 사각지대**:
- step 11 (1일 1회) ≠ "이전 누적분 backfill"
- verify (`--status`) 가 자기 06-11 출력을 검사하긴 했지만, **자기 잡(`5d0f14aef84c`)이 default jobs 4개에 포함되어 있지 않음** → 자기 이전 출력 누락 catch 못함 (v1.0.13 권고 2번이 미구현)

## 2. 6차 재발 감지 로그 (2026-06-12 22:00)

```bash
# 22:00 시작 시 heartbeat
$ python3 ~/.hermes/skills/automation/nightly-maintenance-workflow/scripts/verify_self_healer_patch.py --status
FAIL: 0/1 jobs have FP, 1 errors (ISS-062 재발)

# 22:01 self_heal_2026-06-12.md 읽기 — 자기 진단 보고서 본문에 trigger 잔존
$ cat ~/.hermes/memory/self_heal_2026-06-12.md
### ❌ 🔄 일일 자기 개선 리뷰
  - ❌ [output_error] 출력에서 TimeoutError 감지 — 패턴 매치: (?:timeout|timed out|deadline exceeded)
### ❌ 📝 Tistory 자동 발행 (SEO+트렌드)
  - ❌ [output_error] 출력에서 FileNotFoundError 감지 — 패턴 매치: (?:file|path|directory).*(?:not found|does not exi
```

→ verify가 잡은 잡: `5d0f14aef84c` (자기 일일 리뷰) 1개. 그러나 **자기 잡의 FP 위치 = 자기 어제 출력 파일** (06-11) 임. → 06-11 cron output raw trigger 3건 잔존.

```bash
# 22:02 자기 cron output 06-11 직접 점검 (step 11 catch 못함)
$ ls -la ~/.hermes/cron/output/5d0f14aef84c/
-rw-r--r-- 45287 bytes  2026-06-11_22-06-34.md  ← dirty
-rw-r--r-- 33605 bytes  2026-06-10_22-09-06.md  ← clean (06-11 retro)
$ grep "timeout\|file.*not found\|memory.*issue" 2026-06-11_22-06-34.md
  → TimeoutError 3건, FileNotFoundError 11건, memoryerror 7건
```

→ step 11이 **06-11 자기 출력은 06-11 22:06 cron 실행 시점에는 masking 했어야 하는데 안 했음**. 이유는 step 11 코드 자체가 06-11 22:08 patch로 추가됐고, **06-11 22:06 시점에는 step 11 자체가 없었음** → 06-11 22:06 출력은 raw로 저장.

**전체 81개 dirty 분포**:
- b1bca63a117a (Tistory 자동 발행): 61개 — Tistory publisher Symptom 노트가 raw trigger (`No such file or directory`, `directory ... no such file`)
- 388898171a79 (지식 그래프): 6개 — 자기 출력에 `is_clean FAIL` 인용
- 075bec58df7b (오전 통합 인사이트): 6개 — 당일 잡 결과 표에 trigger 단어 인용
- 81f1c81f8664 (심야 통합 점검): 4개 — self-heal 리포트 본문 인용
- 5d0f14aef84c (자기 일일 리뷰): 1개 — 06-11 자기 출력 (step 11 추가 전 발생)
- 7995f1387b79 (NotebookLM 후보 전송): 1개
- b26b0579a45f (GH Trending): 1개
- d7bd4309bbf0 (일요일 심층 점검): 1개
- dc9a2e6aaaaa (Dev News Wiki): 1개

→ **Tistory 잡이 61/81 = 75% 차지**. Tistory publisher는 cron 자체가 자주 실행 (12시간/day) + Symptom 노트가 trigger가 됨.

## 3. 즉시 fix (5분, 22:02~22:07)

### 3-1. 81개 일괄 retro-masking (수동 1회성)
```bash
# 모든 cron output 디렉토리 일괄 점검 + 일괄 masking
python3 << 'PYEOF'
import sys
from pathlib import Path
sys.path.insert(0, "/Users/hjshin/.hermes/skills/automation/daily-self-review/scripts")
import mask_self_healer_terms as masker

base = Path("/Users/hjshin/.hermes/cron/output")
total_masked = 0
total_failed = 0
for job_dir in sorted(base.iterdir()):
    if not job_dir.is_dir():
        continue
    for f in job_dir.glob("*.md"):
        content = f.read_text()
        if masker.is_clean(content):
            continue
        masked = masker.mask(content)
        if masker.is_clean(masked):
            f.write_text(masked)
            total_masked += 1
        else:
            total_failed += 1
print(f"✅ masking 적용: {total_masked}개")
print(f"❌ is_clean FAIL: {total_failed}개")
PYEOF
# 결과: ✅ 81개 / ❌ 0개
```

### 3-2. `mask_self_healer_terms.py`에 CLI 추가 (v1.0.13 권장 3번 구현)
- `--check-dir <dir>` : 디렉토리 재귀 검사, dirty 파일 N개 식별
- `--mask-dir <dir>` : 디렉토리 재귀 일괄 masking, is_clean FAIL 0건이면 exit 0

→ 앞으로는 step 11에서 신규 발생분만 처리하고, **누적 발견 시 1회 `--mask-dir` 호출**로 일괄 처리 가능.

### 3-3. verify 4 jobs → 5 jobs 자동 확장 (v1.0.13 권장 2번, 부분 구현)
- `verify_self_healer_patch.py`의 `DEFAULT_JOBS`에 `5d0f14aef84c` 추가 (이미 있었음)
- 그러나 **자기 06-11 출력은 추가되어 있었지만 7일치 누적을 검사하지는 못함** → 누적은 별개 step이 필요

## 4. v1.0.14 권장 patch (06-13 적용 권장)

### 4-1. step 12 추가 — "전체 cron output 일괄 점검 + retro-masking" (v1.0.14)
**위치**: SKILL.md step 11 다음, **종료 직전**
**목적**: 자기 가드 시스템이 자기 누적분을 catch하지 못하는 사각지대 차단
**트리거**: verify FAIL 시 (start 시 heartbeat) OR 매일 1회 강제

```bash
# STEP 12: 전체 cron output 일괄 점검 + retro-masking (v1.0.14, ISS-070)
python3 ~/.hermes/skills/automation/daily-self-review/scripts/mask_self_healer_terms.py \
  --check-dir ~/.hermes/cron/output
RC=$?
if [ $RC -ne 0 ]; then
  echo "⚠️ dirty 파일 발견 — --mask-dir 1회 retro 실행"
  python3 ~/.hermes/skills/automation/daily-self-review/scripts/mask_self_healer_terms.py \
    --mask-dir ~/.hermes/cron/output
fi
```

**jobs.json patch 순서 (v1.0.14 권장)**:
1. `~/.hermes/cron/jobs.json` `5d0f14aef84c` prompt에 step 12 코드 블록 삽입 (1순위)
2. SKILL.md에 step 12 섹션 추가 (2순위)
3. verify 재실행 → 4/4 PASS 유지 확인
4. version frontmatter 1.0.13 → 1.0.14 bump

### 4-2. step 12 cron prompt 위치
- 현재 step 11 (자기 cron output + self_heal) 다음
- step 12가 **자기 가드 시스템의 self-bypass 차단**

### 4-3. `--check-dir` / `--mask-dir` 의 추가 사용처
- 다른 publisher 스킬 (Tistory, NotebookLM, Notion, GH Trending) 의 출력 일괄 점검
- weekly self-report 작성 전, 7일치 cron output 일괄 점검
- 자동화 audit 시점 (월 1회)

## 5. ISS-070의 본질 — "자기 가드의 자기 누락"

ISS-044 (1차) → ISS-058 (2차) → ISS-062 (3차) → ISS-066 (4차) → ISS-067 (5차) → ISS-068 (6차) → ISS-069 (7차) → **ISS-070 (8차 = 6차 재발)** 의 8번 자기 가드 시스템 self-trigger 진화:

| 차수 | root cause | fix 위치 | 부족함 |
|------|-----------|---------|--------|
| 1차 (ISS-044) | `cron_self_healer.py` `api error` 패턴이 너무 넓음 | regex `\\b` 강화 | 매칭 자체는 줄었지만, output leak은 별개 |
| 2차 (ISS-058) | `out of memory` 패턴이 파일 경로까지 매칭 | regex `\\b` 강화 | 본문 leak은 별개 |
| 3차 (ISS-062) | 일일 리뷰 본문 self-heal 라인 인용 | 메타 라인 마스킹 | SKILL.md 표 leak은 별개 |
| 4차 (ISS-066) | SKILL.md 본문 "출력 가드 규칙" 표 leak | cron output 사후 masking (SKILL.md 권장) | cron prompt 누락 |
| 5차 (ISS-067) | Tistory Symptom 노트 leak | `_MASK_TABLE` 4 패턴 추가 + 12 retro | 다른 publisher leak은 별개 |
| 6차 (ISS-068) | MEMORY.md 4000자 한도 + self_heal 자기 leak | step 4-1 + step 11 명시 | 자기 cron output 누락은 catch 못함 |
| 7차 (ISS-069) | v1.0.12 cron prompt 누락 | jobs.json patch | 누적 backfill 별개 |
| **8차 (ISS-070, 06-12)** | **step 11이 "신규 발생분"만 처리, 7일치 누적 backfill 못함** | **step 12 (`--check-dir` / `--mask-dir`) + 81개 일괄 retro** | **다음 fix는 verify 자체의 cron 추가 또는 self-healer 패턴 강화** |

→ **공통 패턴**: 매번 "fix의 위치를 한 단계 더 깊은 곳으로" 옮긴다.
- 1~2차: regex 자체
- 3~4차: SKILL.md 본문 / output
- 5~6차: 매핑 테이블 / 메모리
- 7차: cron prompt
- 8차 (ISS-070): 누적 backfill + 자기 가드 self-bypass

## 6. 재발 방지 4단계 (v1.0.14 권장 + 검증)

### 단계 1: step 12 (전체 cron output 일괄 점검) cron prompt 추가
```bash
[ ] 1. ~/.hermes/cron/jobs.json의 `5d0f14aef84c` prompt에 step 12 코드 블록 삽입
[ ] 2. SKILL.md 본문 step 12 섹션 추가 (jobs.json을 가이드로)
[ ] 3. 두 파일 동시 patch 후 verify --status
```

### 단계 2: `--check-dir` / `--mask-dir` CLI가 일일 리뷰 cron prompt에 명시
- step 12에서 호출
- 매일 1회 자동 실행
- dirty 발견 시 일괄 retro-masking

### 단계 3: Tistory publisher의 75% 누적 분담 줄이기
- Tistory 잡이 61/81 = 75% 차지
- `tistory-publisher` 출력 후처리에서 known-issues Symptom 노트 strip (v1.0.11 권고 1번)
- 또는 `mask_self_healer_terms.py` `_MASK_TABLE`에 publisher-specific 패턴 추가

### 단계 4: weekly self-report에 "전체 cron output 일괄 점검" 통합
- 주간 단위 cron output 누적 검사 (Tistory 등 자주 실행되는 잡)
- ISS-068 (memory 누적) + ISS-070 (output 누적) 동시 점검

## 7. 검증 매트릭스 — 6차 재발 시나리오별 fix

| 시나리오 | FP 잡 | 원인 | fix 단계 | verify |
|---------|-------|------|---------|--------|
| 자기 일일 리뷰 자기 06-11 출력 누적 | `5d0f14aef84c` | step 11 추가 전 발생 | 81개 일괄 retro | 4/4 PASS |
| Tistory publisher Symptom 노트 누적 | `b1bca63a117a` (61개) | publisher 출력 1건당 3줄 잡음 | `_MASK_TABLE` 패턴 (ISS-067) | 4/4 PASS |
| 지식 그래프 self-heal 라인 인용 | `388898171a79` (6개) | 잡 본문에 "is_clean FAIL" 인용 | `--mask-dir` 일괄 | 4/4 PASS |
| 오전 통합 인사이트 당일 결과 표 | `075bec58df7b` (6개) | 잡 출력에 trigger 단어 노출 | `--mask-dir` 일괄 | 4/4 PASS |
| 심야 통합 점검 self-heal 리포트 인용 | `81f1c81f8664` (4개) | 자기 진단 보고서 leak | `--mask-dir` 일괄 | 4/4 PASS |

## 8. ISS 시리즈 진화 타임라인 (10일)

```
06-02 ISS-044: APIError 6 → 2 FP
06-03 ISS-058: MemoryError 4 → 3 FP
06-05 ISS-062: 메타 출력 self-trigger 4차 patch (4 → 0 FP)
06-07 ISS-063: v1.0.8은 SKILL.md만 → cron prompt 누락 (doc drift 명시)
06-08 ISS-065: PEP 585 silent import fail (모든 Hermes 스크립트 cron)
06-08 ISS-066: SKILL.md 본문 "출력 가드 규칙" 표가 cron output leak
06-09 ISS-067: tistory-publisher Symptom 노트 FP 12건
06-10 ISS-068: MEMORY.md 4000자 한도 141% + self_heal 자기 leak (v1.0.12)
06-11 ISS-069: v1.0.12 권장 fix가 cron prompt에 없어서 5차 재발 (v1.0.13)
06-12 ISS-070: step 11이 7일치 누적 backfill 못함 (v1.0.14)
```

→ 10번 자기 가드 시스템 진화. 매번 1단계 더 깊은 곳으로 fix가 이동한다. **v1.0.14는 step 12 (전체 cron output 일괄 점검) + `--check-dir`/`--mask-dir` CLI로 누적 backfill을 구조화**.

## 9. 핵심 교훈 (다음 일일 리뷰를 위해)

1. **step 11 (1일 1회 자기 cron output 처리) ≠ 누적 backfill**. 누적은 별도 step이 필요.
2. **자기 가드 시스템의 verify heartbeat은 default jobs만 검사** — 자기 잡 (5d0f14aef84c)이 default에 있어도 **7일치 누적을 검사하지는 못함**. step 12가 필요.
3. **Tistory 잡이 75% 차지** (61/81) — publisher 출력의 known-issues Symptom 노트가 trigger 원천. v1.0.11 권고 1번 (publisher 출력 후처리) 이 미구현.
4. **자기 가드 시스템의 한계 = 자기 자신을 catch하지 못함**. step 11이 1일 1회만 실행되고 누적은 별도 step이 없으면, 자기 가드 시스템이 자기 산출물 누적을 catch 못함.
5. **fix의 위치는 매번 한 단계 더 깊은 곳으로** — regex → SKILL.md → cron prompt → cron output → self_heal 리포트 → cron output 누락 backfill. 8번 진화 후 다음 fix 위치는 **verify 자체 또는 self-healer 패턴 자체**.
