# Cron Output File Bloat 정리 (ISS-027)

## 문제

`~/.hermes/cron/output/<job_id>/` 디렉토리에 .md 출력 파일이 무한히 누적되어 디스크 블로트 발생.
Tistory 자동 발행 잡(b1bca63a117a)의 경우 72~106개까지 도달.

## 해결

매 daily self-review 또는 nightly maintenance에서 3일 이상 된 파일 자동 삭제.

```bash
# Tistory 발행 출력 정리 (가장 bloat 심함)
find ~/.hermes/cron/output/b1bca63a117a/ -name "*.md" -mtime +3 -delete

# 전체 cron output 통합 정리
find ~/.hermes/cron/output -name "*.md" -mtime +3 -delete
```

## 자동화 권장

nightly maintenance 크론 잡의 정리 단계에 통합:
```bash
# ~/.hermes/scripts/nightly_maintenance.py (또는 cron 자체에 추가)
find ~/.hermes/cron/output -name "*.md" -mtime +3 -delete
echo "Cleaned old cron outputs (3+ days)"
```

## 검증

- 정리 전: `ls ~/.hermes/cron/output/<job_id>/ | wc -l` 로 카운트
- 정리 후: 동일 명령으로 감소 확인
- 효과: Tistory 72→49, 106→48 사례 검증됨

## 주의

- `-mtime +3`은 3일 **이전** 파일 (즉, 4일 이상 된 파일). `-mtime +2`는 더 공격적.
- `*.md` 외 다른 확장자 (.log, .json 등) 도 bloat 가능 — 필요시 확장.
- active 세션이 출력 파일에 쓰는 중일 수 있으므로 daily review 22:00 KST에 실행 권장 (cron traffic 적은 시간).
