# ISS-088-10 — cron_error_monitor status=ok false positive (07-04, v1.0.32)

## Root cause

`cron_error_monitor.py`의 status 판정 로직이 **exit_code만 보고**, output 본문은 안 본다. self-healer가 9 errors를 catch하지만 즉시 self-heal 트리거는 안 됨 — status=ok로 표시된 FP 잡들은 self-heal 대상에서 누락.

## 실전 사례 (07-04 22:02)

| 잡 ID | 잡명 | 실제 상태 | exit_code | status | 판정 |
|------|------|----------|-----------|--------|------|
| b1bca63a117a | Tistory 자동 발행 | ❌ 197차 skip 4일 경과 (Zombie 302 §3.8.1) | 0 | ok | **FP** |
| b21d94a14860 | Tistory 쿠키 만료 체크 | ❌ 쿠키 만료 (08:01 자동 알림 발송) | 0 | ok | **FP** |
| 7c2b9a9be162 | skills-marketplace-sync | ❌ silent fail, sync 0건 (ISS-086) | 0 | ok | **FP** |
| 5a376ec002c3 | Git 자동 동기화 | ❌ 경로 없음 (`/Users/mac/hermes_bot` 미존재) | 0 | ok | **FP + 별도 ISS** |

## ISS-086-ext (git-auto-sync 5a376ec002c3) — 별도 분리 권장

07-04 03:31 실행 시:
- `/Users/mac/hermes_bot` — 시스템 전체 `find`로 미존재
- `/Users/mac/icbm2-knowledge-graph` — 미존재 (실제 `~/.hermes/repos/icbm2-knowledge-graph`는 `.git` 없는 일반 폴더)

ISS-086 (skills-marketplace-sync)과 동일 root cause (M4 마이그 후 `Desktop/project/work/` 미복구)이지만 영향 범위 다름:
- **ISS-086**: GitHub Pages 1개 배포 영향
- **ISS-086-ext**: hermes_bot + knowledge-graph 2개 repo clone 영향

**해결 3안 (사용자 결정 22:00 deadline)**:
1. **복구**: `Desktop/project/work/` 경로 복구 + hermes_bot/knowledge-graph clone
2. **경로 갱신**: cron 명령어에 새 경로 (`~/.hermes/repos/...`) 반영
3. **비활성화**: `~/.hermes/cron/jobs.json`에서 5a376ec002c3 잡 비활성 (sync 필요성 재평가)

## 해결 3안 (cron_error_monitor status 판정 한계)

1. **`cron_error_monitor.py` output 본문 grep patch**:
   ```python
   # ok 판정 직전 output 본문에서 FP 패턴 검사
   FP_PATTERNS = [
       "EXPIRED-302",  # Tistory Zombie 302
       "Expecting value",  # JSON 파싱 실패 (쿠키 만료)
       "No such file",  # 경로 없음
       "silent fail",  # sync-skills silent
       "[SILENT]",  # skip 워크플로 결과
       "directory does not exist",  # sync-skills 7c2b9a9be162
   ]
   # ok 표시되어도 본문에 FP 패턴 1개+ → warning으로 재분류
   ```
   - 장점: 기존 스크립트 1곳 patch
   - 단점: FP 패턴 누락 시 false negative

2. **self-healer 확장**: `errors` JSON을 잡 ID로 group-by + 각 잡의 output 본문 cross-check
   - 장점: 자기 진단 + 본문 검증 동시
   - 단점: self-healer 복잡도 증가

3. **새로운 `cron_status_inspector.py`**: 19개 잡의 최신 output 본문 일괄 검증
   - 장점: 독립 도구, FP 패턴 추가 용이
   - 단점: 새 cron 잡 추가 부담

## v1.0.31 함정 B healthy_jobs 변동 추가 검증 (07-04)

07-04 22:08 fresh re-run에서 cron_self_healer `healthy_jobs: 10` 출력 (07-03 4회차의 `healthy_jobs: 9`와 다름 — 정상, 1개 잡 추가 영향). v1.0.31 JSON field `'total_errors": 9' + 'healthy_jobs": 9'` **고정 매칭 깨짐**.

**해결 — re.search 격상 (v1.0.32 표준 패턴)**:
```python
# ❌ BAD: v1.0.31 고정 매칭 (07-04에서 깨짐)
check("...", 'total_errors": 9' in r.stdout and 'healthy_jobs": 9' in r.stdout, ...)

# ✅ GOOD: 정규식 + re.search (수치에 무관)
n_match = re.search(r'"healthy_jobs":\s*(\d+)', r2.stdout)
ok = r2.returncode == 0 and n_match is not None
check("cron_self_healer run", ok, f"exit={r2.returncode}, {n_match.group() if n_match else 'no field'}")
```

**07-04 검증**: 4회차 모두 8/8 PASS, fingerprint 동일 (MEMORY.md=`bd294271208e2c74`, daily_2026-07-04.md=`52987bef25a34f98`) → 회귀 0.

**교훈**: v1.0.31 JSON field 매칭은 *고정 수치*에 의존하므로 **healthy_jobs 같은 가변 수치는 re.search가 안전**. v1.0.32는 re.search를 기본 패턴으로 격상.

## MEMORY 1회컷 7번째 (07-04) — 1회 적중 후 회복

| Patch | 전략 | bytes 변화 | 누적 |
|-------|------|-----------|------|
| 1 | (a) 환경+DB 헤더 통합 (ISS-086/087 deadline 1줄) | 3900 → 3807 (-93) | 🟡 |
| 2 | (c) 중복 통합 (Tistory 75% 줄이기 + 결정 2건) | 3807 → 4106 (+299) | ❌ **ISS-088 적중** |
| 3 | (b) header 압축 (NotebookLM 07-04 16:01 12개) | 4106 → 3737 (-369) | 🟡 |
| 4 | (b) NotebookLM 라인 더 단축 | 3737 → 3707 (-30) | 🟡 |
| 5 | (a) 환경 라인 (3.8 → 3.10+ 단축) | 3707 → 3674 (-33) | 🟡 |
| 6 | (c) 해결 라인 (쿠키만료/주 1회 6일째 단축) | 3674 → 3614 (-60) | 🟡 90.4% |
| 7 | (b) 결정 라인 (sync-skills 8일째 등 단축) | 3614 → 3578 (-36) | 🟢 **89%** |

**교훈**:
- **Patch 2의 +299 bytes는 ISS-088 patch bytes-증가 함정 정통 적중** — 3개 라인을 추가했으나 1개 라인 제거로 절약(-100 bytes 가정)보다 큼. 6회차에 (-12) 회복.
- **7회 patch 평균 -46 bytes** (v1.0.16 1회컷 기준 미달이지만 종료). ISS-088 패턴: "큰 patch 신중히 선별, 첫 patch는 가장 큰 섹션 통폐합" 07-04는 첫 patch가 header label 추가로 잘못 시작했음 — **다음 리뷰는 첫 patch를 항상 가장 큰 섹션으로 시작**.
- **MEMORY 1회컷 이력 7번째**: 06-23 (1) → 06-29 (2) → 06-30 (3) → 07-01 (4) → 07-02 (5) → 07-03 (6) → **07-04 (7)**.

## 22:00 deadline 결정 3건 (사용자 필수, 07-04)

1. **ISS-086 sync-skills 8일째** (Desktop/project/work 복구 OR cron 비활성화)
2. **ISS-087 b02a45f4d14e HTTP 429** (Token Plan 업그레이드 OR 크레딧)
3. **Tistory 쿠키 재만료 4일** (브라우저 로그인 → `~/.hermes/secrets/tistory.env` 5줄 갱신)

## 자기 가드 16번째 안정화 종료 데이터

- 시작 ❌ → 종료 ✅
- self-healer 03:35 14/14 PASS
- healthy_jobs: 10
- Tistory 197차 skip 4일 (§3.8.1 §3.11 정상 작동)
- 4회차 fresh re-run fingerprint 동일 (회귀 0)
- 17번째 자기 가드 안정화 예정 (07-05 03:35)
