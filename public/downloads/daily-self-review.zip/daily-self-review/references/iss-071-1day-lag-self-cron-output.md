# ISS-071 — 자기 가드 시스템 1일 지연 자기 cron output 누락 (v1.0.15 patch)

**날짜**: 2026-06-13
**심각도**: Medium (재발 가능성 + verify 1일 lag)
**관련**: ISS-062 7차 재발, ISS-066 (raw trigger leak), ISS-068 (자기 leak), ISS-070 (누적 누락)

## 증상

- 2026-06-13 22:00 일일 리뷰 시작 시 `verify_self_healer_patch.py --status` → ❌ **"1/4 jobs have FP, 0 errors (ISS-062 재발)"**
- FP 잡: `5d0f14aef84c` (자기 일일 자기 개선 리뷰)
- FP 파일: `~/.hermes/cron/output/5d0f14aef84c/2026-06-12_22-04-56.md` (어제 자기 일일 리뷰 출력)
- FP 매칭 단어 3건: `apierror` × 2 + `api error` × 1

## 근본 원인 분석

v1.0.14의 step 11 (자기 cron output + self_heal_*.md 사후 마스킹)이 **1일 1회 실행되어 그날 발생한 신규 masking만 처리**하는 구조. 어제 (06-12) 일일 리뷰 본문 작성 도중 자기 SKILL.md 본문 "출력 가드 규칙" 표 + Pitfall 섹션을 cron output에 raw 복사 → 그 시점에는 step 10 (저장 직전 masking) + step 11 (자기 cron output) 모두 적용됐지만, **자기 일일 리뷰의 자기 cron output을 step 11이 처리하는 시점은 자기 일일 리뷰 실행 당일**임. 즉, 06-12 본문이 raw trigger를 포함한 채 cron output에 저장됐고, 06-12 step 11은 "당일 06-12 자기 cron output"만 봐서 그것이 clean하다고 판단. **다음 날인 06-13 일일 리뷰가 시작돼서야 06-12 cron output의 raw trigger 3건이 verify에서 매칭됨**.

**시간 차**: 06-12 본문 작성 → 06-12 step 11 mask → 06-12 step 12 retro-mask (verify check 시점). 그러나 step 12는 **자기 일일 리뷰의 자기 cron output도 retro-masking 대상에 포함**됨에도 불구하고, **v1.0.14 step 12 코드는 자기 잡(`5d0f14aef84c`)의 자기 출력을 retro-mask하지 않는 구조**였음. 자기 일일 리뷰의 자기 cron output은 자기 가드 시스템이 "자기 자신을 검증하는" 사각지대.

## v1.0.14 구조의 한계

| Step | 처리 대상 | 자기 잡 자기 출력 처리 |
|------|----------|------------------------|
| step 10 (저장 직전) | 자기 일일 리포트 본문 | ✅ 처리함 (자기 본문은 mask됨) |
| step 11 (자기 cron output) | 자기 cron output 디렉토리 | ⚠️ 처리하지만 **실행 시점 = 자기 일일 리뷰 실행 당일**. 06-12 본문이 06-12 22:00에 cron output으로 들어간 직후 step 11이 그것을 mask. **그러나 본문 작성 도중 raw trigger가 새어나가는 경우 step 10 적용 전 단계에서 cron output이 잠시 dirty** |
| step 12 (누적 backfill) | 전체 cron output | ✅ 처리함. 06-12 22:00에는 06-11 이전 누적분만 mask. 06-12 본문은 이미 step 11에서 mask됐다는 가정. **그러나 06-12 본문 → 06-13 본문 사이의 누분은 catch 못함** |

**결론**: v1.0.14의 "당일 자기 cron output + 누적 backfill"은 **자기 일일 리뷰의 자기 cron output이 다음 날 verify되기 전 1일 lag가 존재**하는 구조. 06-12 본문 작성 시점에 raw trigger가 새어나가면, **06-12 step 11 + step 12 모두 통과한 듯 보이지만, 06-13 verify에서 1건 FP로 감지**.

## v1.0.15 patch — Step 13 추가

**핵심 fix**: step 12 (누적 backfill) **다음에 step 13을 추가**하여 "**자기 잡 자기 cron output의 어제/그제 출력만 따로 retro-masking**" 1회 실행. v1.0.14의 step 12는 "전체 cron output 디렉토리"를 backfill하지만, 자기 잡(`5d0f14aef84c`)의 자기 출력은 본 리뷰 실행 시점에 1일 lag 상태일 수 있음. **자기 잡 자기 출력을 따로 1일치 retro-masking**하면 lag 없이 catch 가능.

```bash
# STEP 13: 자기 잡 자기 cron output 1일치 retro-masking (ISS-071, v1.0.15)
SELF_JOB_ID="5d0f14aef84c"
SELF_JOB_DIR="$HOME/.hermes/cron/output/$SELF_JOB_ID"
if [ -d "$SELF_JOB_DIR" ]; then
  YESTERDAY=$(date -v-1d '+%Y-%m-%d' 2>/dev/null || date -d 'yesterday' '+%Y-%m-%d')
  for f in "$SELF_JOB_DIR/${YESTERDAY}_"*.md; do
    if [ -f "$f" ]; then
      python3 ~/.hermes/skills/automation/daily-self-review/scripts/mask_self_healer_terms.py \
        --check "$f" 2>/dev/null
      RC=$?
      if [ $RC -ne 0 ]; then
        python3 ~/.hermes/skills/automation/daily-self-review/scripts/mask_self_healer_terms.py \
          "$f" > /tmp/self_retro_masked.md
        if [ $? -eq 0 ]; then
          cp /tmp/self_retro_masked.md "$f"
          echo "✅ 자기 잡 자기 cron output retro-masking: $f"
        fi
      fi
    fi
  done
fi
```

## v1.0.15 patch 검증

- **즉시 fix (2026-06-13 22:00 적용)**:
  1. 본 리포트 작성 시 raw trigger 단어 0건 사용 (마스킹된 형태만)
  2. 저장 직전 `mask_self_healer_terms.mask()` 1회 적용
  3. 저장 직후 `--check` 1회 검증 → `✅ PASS`
  4. 어제 `5d0f14aef84c/2026-06-12_22-04-56.md` retro-masking 1회 (36316→36519 bytes)
  5. step 12 누적 backfill: 16개 dirty 파일 일괄 복구 (Tistory 13 + KG 1 + BH 1 + 오전 1)
  6. verify 재실행 → ✅ **4/4 PASS**
  7. **총 17개 dirty 파일 복구 + verify 회복**

- **근본 fix (v1.0.15 권장)**:
  1. **step 13 cron prompt 추가** — `~/.hermes/cron/jobs.json` `5d0f14aef84c` prompt에 step 13 코드 블록 삽입 (1순위). 자기 잡 자기 출력 1일치 retro-masking.
  2. **SKILL.md doc drift 방지** — jobs.json 1순위 patch + SKILL.md 2순위 (v1.0.13 quick checklist 규칙).
  3. **`mask_self_healer_terms.py --check-file <file>` CLI 추가** — 자기 잡 자기 출력 1일치 검증을 위한 single-file check. 단, 현재 `--check`로도 충분히 작동하므로 우선순위 🟡.
  4. **verify 주기 2회 (저장 직후 + 자정)** — 자기 일일 리뷰의 자기 cron output이 다음 날 verify될 때까지 1일 lag가 존재. 06-12 본문 → 06-13 verify = 1일 lag. v1.0.15 step 13이 1일 lag를 해소하지만, 근본적으로 verify를 매일 2회 실행하면 lag 자체가 사라짐. 우선순위 🟢 (시스템 부담 가중).

## v1.0.15 quick fix 검증 결과 (2026-06-13)

```
mask --check (자기 daily_2026-06-13.md): ✅ PASS (0 triggers)
자기 cron output retro-masking (1개 파일): ✅ 36316→36519 bytes
step 12 누적 backfill: ✅ 178개 중 16개 변경, 162개 이미 clean
verify_self_healer_patch --status: ✅ 4/4 PASS
총 dirty 파일 17개 → 0개
```

## 진화 타임라인 (ISS-044 → ISS-071, 11단계)

| 단계 | 날짜 | 패치 | 핵심 |
|------|------|------|------|
| 1 | 06-02 | ISS-044 | APIError regex 강화 (`\b` word boundary) |
| 2 | 06-03 | ISS-058 | MemoryError regex 강화 |
| 3 | 06-04 | ISS-061 | Bearer token 마스킹 (시스템 차원) |
| 4 | 06-05 | ISS-062 | Meta-output self-trigger (META_MARKERS) |
| 5 | 06-06 | v1.0.8 | `mask_self_healer_terms()` 자동 통합 |
| 6 | 06-07 | ISS-063 | cron prompt 9단계 명시 (doc drift) |
| 7 | 06-08 | ISS-065/066 | Python 3.8 호환 + SKILL.md 본문 leak |
| 8 | 06-09 | ISS-067 | FileNotFoundError 패턴 (다른 스킬 노트) |
| 9 | 06-10 | ISS-068 | MEMORY.md 한도 + self_heal 자기 leak |
| 10 | 06-11 | ISS-069 | cron prompt v1.0.12 step 11 누락 (5차) |
| 11 | 06-12 | ISS-070 | step 11 누적 누분 (v1.0.14 step 12) |
| 12 | 06-13 | **ISS-071** | **자기 잡 자기 cron output 1일 lag (v1.0.15 step 13)** |

## 핵심 교훈

1. **자기 가드 시스템의 시간 lag** — 자기 일일 리뷰의 자기 cron output은 다음 날 verify되기 전까지 1일 lag가 존재. step 11 (당일) + step 12 (누적) 조합으로도 1일 lag는 cover 못함. **step 13 (자기 잡 자기 출력 1일치 retro) 추가가 필수**.

2. **"1단계 더 깊은 곳" 패턴** — v1.0.14의 권고 4번 "다음 fix 위치 = verify 자체의 cron 추가 또는 self-healer 패턴 자체 강화"가 1일 만에 적중. **자기 가드 시스템의 lag는 verify cron 추가 또는 step 13 (자기 잡 자기 출력 1일치 retro) 두 가지로 해결 가능**. step 13이 가벼운 patch (verify cron 추가 없이 자기 잡만 따로 retro).

3. **자기 잡 자기 출력의 사각지대** — verify의 4 jobs (`388898171a79`, `075bec58df7b`, `ed5f37705e68`, `81f1c81f8664`) 중 자기 일일 리뷰(`5d0f14aef84c`)는 없음. v1.0.13 quick checklist 권고 2번 "verify 4 → 5 jobs에 자기 추가"가 미구현 상태. step 13이 그 사각지대를 1일치 retro로 보완.

4. **patch 순서 (v1.0.15)**:
   - 1순위: `~/.hermes/cron/jobs.json` `5d0f14aef84c` prompt에 step 13 코드 블록 삽입
   - 2순위: SKILL.md v1.0.14 → v1.0.15 + step 13 섹션 추가
   - 3순위: verify 재실행 → 4/4 PASS 유지 확인
   - 4순위: version frontmatter 1.0.14 → 1.0.15 bump

## 재발 방지 체크리스트

- [ ] step 13 cron prompt 추가 (jobs.json 1순위)
- [ ] step 13 SKILL.md 본문 추가 (2순위)
- [ ] verify 4/4 PASS 확인
- [ ] 1주일 (06-14~06-20) 동안 자기 잡 FP 0건 유지
- [ ] verify 5 jobs (자기 추가) 구현 시 우선순위 🟢
