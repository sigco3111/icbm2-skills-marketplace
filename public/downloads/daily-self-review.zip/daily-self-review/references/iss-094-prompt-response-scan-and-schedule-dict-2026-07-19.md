# ISS-094 — cron output Prompt/Response 혼합 스캔과 schedule dict 파싱 (2026-07-19)

## 증상

일일 리뷰 시작 시 최신 실측은 정상인데 진단 도구가 서로 다른 오탐을 냈다.

- `cron_self_healer.py`: `output_error` 9건까지 증가
- `cron_error_monitor.py`: 일일 리뷰 24.0시간, 평일 Dev News 50.1시간 미실행 경고
- `hermes cron list`와 최신 각 잡의 최종 응답은 모두 정상

## 근본 원인

### 1. Prompt와 Response를 한꺼번에 regex 스캔

Hermes cron output 마크다운은 다음 구조다.

```markdown
## Prompt
... requests.get(..., timeout=10) ...

## Response
정상 완료
```

Self-Healer가 전체 파일을 읽어 Prompt의 명령 예시와 주간 리포트의 역사 요약 문장까지 현재 잡의 런타임 실패로 오인했다.

### 2. 구조화된 schedule을 문자열로 추정

`jobs.json`의 schedule은 다음 dict다.

```json
{"kind":"cron","expr":"0 22 * * *","display":"0 22 * * *"}
```

기존 코드는 `str(schedule)` 후 공백 split을 수행했다. dict 문자열은 5필드 cron 표현식이 아니므로 default 48시간 규칙으로 빠지고, `hours_since > expected_hours * 2` 경계에서 잘못된 경고를 냈다.

### 3. 고정 날짜 산출물 경로

일일 리뷰 cron prompt가 과거 예시 `daily_2026-06-07.md`를 실제 참조 파일로 포함해, 2주 아카이빙 후 missing_file로 오인했다.

## 수정

### `cron_self_healer.py`

1. 마지막 top-level `## Response` 뒤만 스캔하는 `_extract_response_section()` 추가.
2. delimiter 없는 옛 출력은 기존 전체 스캔 fallback 유지.
3. 시간초과는 직접 실패 모양만 탐지:
   - 예외명
   - 줄 시작 실패 마커
   - runtime subject + `timed out`/`deadline exceeded`/`timeout error`
4. shell substitution 경로는 실행 전 미존재가 정상이므로 path validator에서 skip.

### `cron_error_monitor.py`

schedule이 dict면 `expr`, 없으면 `display`를 진짜 cron 문자열로 사용.

### cron prompt

고정 날짜 2곳을 `daily_$(date +%Y-%m-%d).md`로 변경.

## 검증

- `py_compile` 2개 스크립트 통과
- 단위 harness:
  - Prompt의 `timeout=10` → 미검출
  - 역사 요약 `timeout/truncated` → 미검출
  - `request timed out`, 예외명, 실패 마커 → 검출
  - self-meta 출력 → 미검출
- 실데이터 dry-run: `output_error` 9 → 0
- 잔여 errors 2건은 같은 `github_token.txt` 부재를 secret/path로 중복 집계한 ISS-091
- 최신 monitor: 19 ok / warning 0 / critical 0
- 품질 리포트: 최근 24시간 28/28 성공

## 교훈

자동화 모니터의 진짜 소스는 **Prompt가 아니라 Response**, schedule의 진짜 소스는 표시용 추정 문자열이 아니라 **구조화된 expr**다. 생성 예정 산출물은 실행 전 존재 검사 대상에서 제외해야 한다.
