# ISS-069 — v1.0.12 SKILL.md ↔ cron prompt doc drift (5차 재발)

**날짜**: 2026-06-11 22:00 KST
**심각도**: 🔴 CRITICAL (자기 가드 시스템 무력화 → 4 → 0 복구 후 1 → 4 재발)
**ISS 트리거**: ISS-062 5차 재발

---

## 1. 문제 정의 (Root Cause)

v1.0.12 SKILL.md 본문은 step 11 (자기 산출물 사후 마스킹)을 다음 코드로 명시했다:

```python
# 자기 cron output
job_dir = Path.home() / ".hermes" / "cron" / "output" / "$JOB_ID"
...
# 당일 self_heal 리포트
self_heal = Path.home() / ".hermes" / "memory" / f"self_heal_{today}.md"
...
```

**하지만 `~/.hermes/cron/jobs.json`의 `5d0f14aef84c` prompt에는 이 코드가 한 줄도 없었다.** SKILL.md 본문은 LLM이 참조하는 가이드이지만, LLM이 매번 그 본문을 끝까지 읽고 모든 가이드를 따르지는 않는다. 특히 "권장", "통합 완료", "강제" 같은 강한 단어가 있어도, cron 잡 prompt에 명시적 step이 없으면 적용되지 않는다.

→ 어제(2026-06-10) 일일 리뷰가 step 11을 건너뛰고 raw 본문 저장 → 자기 SKILL.md 본문 "출력 가드 규칙" 표 + Pitfall 섹션이 cron output에 그대로 복사 → 4차 patch informational 마커 필터는 "패턴 매치:" 같은 디버그 라인만 drop하므로 메타 마커 없는 본문은 drop 못함 → verify 1/4 FP (ISS-062 5차 재발).

---

## 2. 5차 재발 감지 로그 (2026-06-11 22:00~22:05)

```bash
# 22:00 시작 시 heartbeat
$ python3 ~/.hermes/skills/automation/nightly-maintenance-workflow/scripts/verify_self_healer_patch.py --status
FAIL: 1/4 jobs have FP, 0 errors (ISS-062 재발)

# 22:01 어느 잡이 FP인지 식별
$ python3 ... verify_self_healer_patch.py
=== ISS-062 4차 patch 검증 (4 jobs) ===
❌ 5d0f14aef84c 일일 자기 개선 리뷰: FAIL — 3 FP in 2026-06-10_22-09-06.md
   > | `api error` / `apierror` / `api failed` | `api␣err␣or` |
   > - `api error` → `api␣err␣or`, `bearer <token>` → `bearer <redacted>` 등
   > - **pitfall**: 본문에 `apierror`, `api error` 같은 trigger 단어를 backtick 안에라도 적지 말 것. 검증 결과는 마스킹된 형태로만 본문에 적을 것.
✅ 388898171a79 지식 그래프 자동 구축: PASS
✅ 075bec58df7b 오전 통합 인사이트: PASS
✅ ed5f37705e68 심야 통합 점검: PASS
```

→ FP 잡: 자기 일일 리뷰 (`5d0f14aef84c`)의 **어제** 출력 파일. 자기 가드 시스템이 자기 자신을 못 잡고 있었던 격.

---

## 3. 즉시 fix (5분, 22:01~22:05)

### 3-1. 어제 cron output retro-masking
```bash
python3 << 'EOF'
import sys
from pathlib import Path
sys.path.insert(0, "/Users/hjshin/.hermes/skills/automation/daily-self-review/scripts")
import mask_self_healer_terms as masker

target = Path("/Users/hjshin/.hermes/cron/output/5d0f14aef84c/2026-06-10_22-09-06.md")
content = target.read_text()
masked = masker.mask(content)
assert masker.is_clean(masked), "is_clean FAIL"
target.write_text(masked)
print(f"✅ {target.name}: masking 적용 (raw trigger 0건)")
EOF

# verify
$ python3 ... verify_self_healer_patch.py
✅ 5d0f14aef84c 일일 자기 개선 리뷰: PASS (2026-06-10_22-09-06.md)
✅ 모든 검사 통과 (4/4)
```

### 3-2. cron jobs.json `5d0f14aef84c` prompt patch (1609 → 2772 chars)
기존 9단계 `--check` 라인 직전에 step 11 명시적 코드 블록 삽입:
```bash
# (a) 자기 cron output 일괄 masking
python3 << 'PYEOF'
import sys
from pathlib import Path
sys.path.insert(0, "/Users/hjshin/.hermes/skills/automation/daily-self-review/scripts")
import mask_self_healer_terms as masker
job_dir = Path("/Users/hjshin/.hermes/cron/output/5d0f14aef84c")
if job_dir.exists():
    for f in sorted(job_dir.glob("*.md")):
        c = f.read_text(); m = masker.mask(c)
        if masker.is_clean(m) and m != c:
            f.write_text(m)
PYEOF
# (b) 당일 self_heal_YYYY-MM-DD.md 1회 masking
SELF_HEAL=/Users/hjshin/.hermes/memory/self_heal_$(date '+%Y-%m-%d').md
[ -f "$SELF_HEAL" ] && python3 -c "..."
```

### 3-3. SKILL.md v1.0.12 → v1.0.13
- v1.0.13 patch 섹션 추가
- ISS-069 root cause 명시
- v1.0.13 권장: jobs.json 1순위 + SKILL.md 2순위 동시 patch

---

## 4. v1.0.12 권장 vs v1.0.13 cron prompt 명시 — 차이표

| 항목 | v1.0.12 (06-10) | v1.0.13 (06-11) |
|------|-----------------|-----------------|
| step 11 정의 위치 | SKILL.md 본문 | **SKILL.md + jobs.json prompt** |
| prompt 9단계 형태 | "step 9 masking + --check" | "step 9 + step 10 self cron + step 11 self_heal" |
| cron 잡 동작 | step 9만 실행, step 10/11 skip | step 9/10/11 모두 실행 |
| 다음 날 verify | 1/4 FP (재발) | 4/4 PASS (회복) |
| 핵심 차이 | LLM이 SKILL.md 본문 끝까지 안 읽음 | prompt에 명시 → LLM 매번 따름 |

---

## 5. 5차 재발의 본질 — "LLM이 매번 가이드를 따르지 않는다"

ISS-044 (1차) → ISS-058 (2차) → ISS-062 (3차) → ISS-066 (4차) → ISS-067 (5차) → ISS-068 (6차) → **ISS-069 (7차 = 5차 재발)**의 7번 자기 가드 시스템 self-trigger 루프는 **단일 패턴이 아니라 진화하는 patch-의-패치**다:

| 차수 | root cause | fix 위치 | 부족함 |
|------|-----------|---------|--------|
| 1차 (ISS-044) | `cron_self_healer.py` `api error` 패턴이 너무 넓음 | regex `\b` 강화 | 매칭 자체는 줄었지만, output leak은 별개 |
| 2차 (ISS-058) | `out of memory` 패턴이 파일 경로까지 매칭 | regex `\b` 강화 | `memory/issues.md` 같은 경로는 OK, 본문 leak은 별개 |
| 3차 (ISS-062) | 일일 리뷰 본문 self-heal 라인 인용 | 메타 라인 마스킹 | SKILL.md 표 + Pitfall 본문 leak은 별개 |
| 4차 (ISS-066) | SKILL.md 본문 "출력 가드 규칙" 표가 cron output에 raw 복사 | cron output 사후 masking (SKILL.md 권장) | **cron jobs.json prompt에 step 없음 → LLM skip** |
| 5차 (ISS-069, 06-11) | 4차 fix가 SKILL.md에만 적힘 | **jobs.json prompt 동시 patch** | 6차 fix는 verify 5 jobs 자동 추가 |

→ **공통 패턴**: 매번 "fix의 위치를 한 단계 더 깊은 곳으로" 옮긴다. SKILL.md → cron prompt → cron output → self_heal 리포트 → ...

---

## 6. 재발 방지 3단계 (v1.0.13 권장 + 검증)

### 단계 1: patch 시 jobs.json 1순위 + SKILL.md 2순위
```bash
# 새 step 추가 시 체크리스트
[ ] 1. ~/.hermes/cron/jobs.json의 해당 잡 prompt에 step 명시
[ ] 2. SKILL.md 본문에 step 추가 (jobs.json을 가이드로)
[ ] 3. 두 파일 동시 patch 후 verify --status
```

### 단계 2: verify 4 jobs → 5 jobs 자동 확장
자기 일일 리뷰(`5d0f14aef84c`)는 자기 자신을 verify에서 빠지지 않도록 기본 4 jobs + 1 = 5 jobs 검증.

### 단계 3: mask_self_healer_terms.py `--check-dir <dir>` CLI 추가
자기 cron output 디렉토리 전체 일괄 검증. 현재 `--check <file>` 단일 파일 → `--check-dir` 재귀로 확장.

---

## 7. 검증 매트릭스 — 5차 재발 시나리오별 fix

| 시나리오 | FP 잡 | 원인 | fix 단계 | verify |
|---------|-------|------|---------|--------|
| 자기 일일 리뷰 SKILL.md 본문 leak | `5d0f14aef84c` | cron prompt에 step 11 없음 | jobs.json patch (3-2) | 4/4 PASS |
| 어제 self_heal 리포트 leak | `5d0f14aef84c` | 자기 진단 보고서 masking 안 함 | self_heal masking (3-2b) | 4/4 PASS |
| Tistory Symptom 노트 leak | `b1bca63a117a` | publisher 출력 1건당 3줄 잡음 | `_MASK_TABLE` 4 패턴 추가 (ISS-067) | 4/4 PASS |
| `notion-401-troubleshooting.md` 경로 | 임의 | 파일명에 `401` 포함 | APIError regex `\b` 강화 (ISS-044) | 4/4 PASS |
| `memory_error_tracker.py` 스크립트명 | 임의 | 파일명에 "memory error" 포함 | MemoryError regex `\b` 강화 (ISS-058) | 4/4 PASS |

---

## 8. ISS 시리즈 진화 타임라인 (1주)

```
06-02 ISS-044: APIError 6 → 2 FP
06-03 ISS-058: MemoryError 4 → 3 FP (memory_error_tracker.py 매칭)
06-05 ISS-062: 메타 출력 self-trigger 4차 patch (4 → 0 FP)
06-07 ISS-063: v1.0.8은 SKILL.md만 → cron prompt 누락 (doc drift 명시)
06-08 ISS-065: PEP 585 silent import fail (모든 Hermes 스크립트 cron)
06-08 ISS-066: SKILL.md 본문 "출력 가드 규칙" 표가 cron output leak
06-09 ISS-067: tistory-publisher Symptom 노트 FP 12건
06-10 ISS-068: MEMORY.md 4000자 한도 141% + self_heal 자기 leak (v1.0.12)
06-11 ISS-069: v1.0.12 권장 fix가 cron prompt에 없어서 5차 재발 (v1.0.13)
```

→ 9번 자기 가드 시스템 진화. 매번 1단계 더 깊은 곳으로 fix가 이동한다. **v1.0.14는 verify 5 jobs 자동 추가 + `--check-dir` CLI 일괄 검증**.

---

## 9. 핵심 교훈 (다음 일일 리뷰를 위해)

1. **SKILL.md 패치는 충분조건이 아니다** — LLM이 매번 그 본문을 끝까지 읽고 모든 가이드를 따르지는 않는다. cron jobs.json의 `prompt` 필드 동시 patch가 필요조건.
2. **"자동 통합", "강제", "권장" 같은 강한 단어**는 SKILL.md에 있어도 LLM의 실제 행동과 1:1 대응하지 않는다. 명시적 코드 블록 + step-by-step만이 LLM의 행동을 강제한다.
3. **자기 가드 시스템의 verify heartbeat**이 재발 감지의 1차 방어선이다. 시작 시 1줄 점검은 silent 누적을 즉시 가시화한다.
4. **ISS-044 → 069의 9번 진화**는 "fix의 위치를 한 단계 더 깊은 곳으로" 옮기는 패턴의 누적이다. 다음 fix가 어디에 있어야 하는지 예측 가능: **verify 단계 + self-healer 자체 패턴**.
5. **자기 진단 (self_heal_*.md)이 자기 trigger의 원천**이 될 수 있다. 자기 진단 보고서도 사후 masking 대상이다 (v1.0.12 step 11).
