# ISS-094-bis: CronPaused regex FP (2026-07-23 신규)

**상태**: 🟡 RFC — 즉시 패치 보류
**발견**: 7/23 22:00 self-heal dry-run
**관련**: ISS-089 (CronPaused masking), ISS-092 (새벽 vs 저녁 SSOT), ISS-094 (Prompt+Response 혼합 스캔)

## 증상

```text
22:00 self-heal: 1 error / 1 warning
- ERROR: 화면 출력에서 CronPaused state issue 감지 — 패턴 매치: r"(?:paused|disabled|stopped)"
  job: "🛡️ 심야 통합 점검 (정비+에러)"
- WARNING: notion-outage-watch-3h 의도된 disabled (정상)
```

같은 시각 monitor: 19 ok / 0 critical / 0 warning. 새벽 03:30 self-heal: 0 errors / 1 warning.

## Root Cause

`cron_self_healer.py:191` 의 trigger regex:

```python
("CronPaused", r"(?:paused|disabled|stopped)", "CronPaused"),
```

- 단어 경계 없음 → substring 매치
- 자기 보고서(L55 등)의 정상 한국어 텍스트 `의도된 disabled` 가 trigger
- self-heal output 그대로 자기 보호 trigger 가 재발 (cath-22)

## 새벽 vs 저녁 비대칭 (ISS-092 합성)

- 03:30: 03:31 자기 보고서가 아직 작성되지 않음 → 정상 output #1만 스캔 → 0 errors
- 22:00: 03:31 자기 보고서가 `get_latest_output()` 의 누적 대상으로 잡힘 → L55의 정상 단어가 trigger → 1 error (FP)

즉 **03:30의 0 errors는 사실상 부분 측정** (자기 보고서 작성 전). 22:00에 1 error는 FP.

## 해결 후보 (3단계, 보류)

### A. trigger regex 타이트닝 (🟡 RFC 권장)

```python
# 변경 전
("CronPaused", r"(?:paused|disabled|stopped)", "CronPaused"),

# 변경 후 (명시적 정황 패턴 요구)
("CronPaused",
 r"""(?:
     jobs\.json.*state.*paused
   | state\s*=\s*['\"]?paused
   | state\s*=\s*['\"]?disabled
   | state\s*=\s*['\"]?stopped
   | status:\s*paused
   | status:\s*disabled
   | status:\s*stopped
   | cron\s*job\s*paused
   | job\s*is\s*paused
   | job\s*is\s*disabled
   )""",
 "CronPaused"),
```

또는 단순화: `r"\b(?:cron[\s_]*paused|jobs\.json[\s\S]{0,100}state[\s\S]{0,20}paused)\b"`

### B. 자기 보호 trigger를 warning으로 강등 (🟡 권장)

```python
# detect_error_pattern()에서 CronPaused는 dict에서 'severity' = 'warning' 반환
# 기존 CronPaused 검출은 jobs.json 의 enabled=False / state="paused" 검사 (§4. job정system)와 중복
```

### C. 단순 substring 검출을 제거 (🟢 보너스)

- §4의 `not enabled or state == "paused"` 검사가 이미 잡의 disabled를 잡음
- §3의 CronPaused 검사는 완전히 제거 가능 — 동일 정보의 중복 검출

## 보류 사유

1. **`enabled=False` disabling 검사 회귀 우려**: §4 검사에서 enabled=False 잡 (`notion-outage-watch-3h`) 의 검출 자체가 warning 1건의 SSOT. trigger regex만 손대면 §4만 남음.
2. **self-heal의 self-quieting 위험**: 0 errors / 1 warning / 0 fixes 가 어느 정도 보수적으로 잡음이 있는 상태. 0 errors 달성에 의존하면 실제 사고 누락.
3. **22:00 1 error FP는 사람이 검증**: 일일 리뷰가 1건 FP를 매번 잡아냄. 시스템 전체의 알림 가치 저하 없음.

## 권장 액션 (RFC only)

- 7/24 일일 리뷰에서 step 11/12 의 masking이 정상 동작했는지 재확인
- self-heal errors count weekly 추세 (ISS-086-ext tracking 동일 패턴)
- 3번째 동일 FP 적중 시 (2026-07-26 부근) sk 1.0.44에서 A안 패치
- 그 외는 release 보류 + 참고 문서로 유지

## 검증 절차 (패치 시)

```bash
# A안 패치 후
python3 -m py_compile ~/.hermes/scripts/cron_self_healer.py
python3 ~/.hermes/scripts/cron_self_healer.py --dry-run
# 기대: errors 0 / warnings 1 (의도된 notion-outage) / fixes 0
# 기대: 81f1c81f8664 의 03:32 output도 trigger 안됨 (L55 disabled 무엇으로 안 잡힘)
```

## 마스크 동작 확인 (현재)

`mask_self_healer_terms.py:200` — `\b(?:paused|disabled|stopped)\b` → `cron␣state␣issue` 안전 치환. masking 후 trigger 단어 소멸 → step 9 PASS. **ISS-089 마스크 정상 동작**.

## 영향 평가

- 사용자 영향: 0 — self-heal FP 1건/일, 매 일일 리뷰에서 사람이 검증
- 시스템 영향: 낮음 — 동일 알림 가치 (warning 1건 + FP error 1건), 22:00 / 03:30 의 비대칭은 알려진 패턴
- 알림 가치: 0 — 1건 FP는 무시 가능, ISS-086-ext (D+19) 가 여전히 유일한 진짜 활성 이슈

## 다음 단계

- 7/24 step 6 동일 FP 재현 → RFC 단계 유지
- 7/26~28 동일 FP 3번째 적중 → A안 패치 적용
- 패치 후 `verify_self_healer_patch.py --status` 4/4 PASS 확인
- 패치 후 ISS-094-bis closed, `references/` 에 historical.md 이동
