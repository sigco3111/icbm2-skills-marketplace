# ISS-092 — 당일 새벽 실패 vs 저녁 실측 stale SSOT (2026-07-16)

## TL;DR

심야 self-heal (03:31 KST)이 검출한 "errors=N" 표기는 같은 날 자정(22:00 KST) 일일 리뷰 시점에는 이미 복구됐을 수 있다. **MEMORY.md/issues.md가 새벽 표기를 SSOT로 받아쓰면 영구 stale**이 된다. 일일 리뷰는 **최신 monitor + 최신 cron output + jobs.json** 3축을 다시 검증해서 새벽 이슈의 현재 상태를 결정해야 한다.

## 발생 재현 (2026-07-16, 어제)

| 시각 (KST) | 주체 | 검출 | 표기 |
|------------|------|------|------|
| 03:30 | self-heal (심야) | 지식 그래프 2연패 | "errors=7, ISS-092 진행중" |
| 15:33 | 일요일 심층 점검 (cron) | 정상 복구 (1,065 nodes / 9,476 edges) | status=ok |
| 21:01 | 지식 그래프 (cron) | 정상 수집 | status=ok |
| 22:00 | 일일 리뷰 (cron, 본 세션 직전) | MEMORY 적기 | "ISS-092 해결 재분류" |

같은 날 안에 **3-state transition (감지 → 자동복구 → 재분류)** 완료. v1.0.41 격상.

## 2번째 적중 (2026-07-17, 오늘)

| 시각 (KST) | 주체 | 검출 | 표기 |
|------------|------|------|------|
| 03:31 | self-heal (심야) | 7 errors + 1 warning (output residual 스캔) | 새벽 raw output 기반 |
| 22:00 | cron_error_monitor (재실행) | 15 ok / 4 warning / **0 critical** | SSOT |
| 22:00 | git-auto-sync 5a376ec0 output 직접 확인 | "/Users/mac/hermes_bot 부재" — **status=ok로 은폐된 결함** | 실측 결함은 실측, monitor 표기는 정상 |

**교훈**: monitor의 critical=0과 cron output의 결함 표기는 다른 차원. ISS-086-ext(경로 부재)는 status=ok로 은폐되지만 ISS-092(output residual)은 새벽 표기 → 저녁 정상으로 시간에 따라 변화. **두 패턴 모두 cron output 직접 검증이 필수**.

## 해결 — 3축 교차검증 (SKILL.md pitfall과 동일)

1. `cron_error_monitor.py --status` 재실행 → current critical 확인 (now-cast)
2. 해당 잡의 오늘 최신 cron output 직접 읽기 → 실제 응답 본문/산출물 검증
3. `jobs.json last_status` + 최신 output의 산출물 모두 정상 → 새벽 이슈를 해결로 재분류

**우선순위**: 최신 원본 output > 최신 monitor > MEMORY/issues 요약

## 판별 신호 (cron)

```bash
# 새벽 self-heal의 errors 카운트가 어제보다 늘었는데
# 22:00 monitor의 critical은 0이면 → 새벽 stale
python3 ~/.hermes/scripts/cron_error_monitor.py --status
# → "critical": 0, "warning": 4

# 이때 self-heal 리포트의 errors=7은 03:31 잔재.
# "errors diff = +0 vs 어제 실질적 운영 영향"으로 해석.

# 실제 결함이 잡혔는지 확인하려면 cron output 직접 검증
LATEST=$(ls -t ~/.hermes/cron/output/${JOB_ID_SHORT}/ 2>/dev/null | head -1)
tail -25 ~/.hermes/cron/output/${JOB_ID_SHORT}/$LATEST
```

## ISS-086-ext와의 관계 — 양대 SSOT 충돌 패러다임

| | ISS-086-ext (은폐된 결함) | ISS-092 (시간차 stale) |
|---|---|---|
| 표면 | status=ok인데 실제 결함 | 새벽 errors=N인데 저녁 정상 |
| 원인 | 잡 자체가 status=ok로 자체 은폐 (silent fail) | self-heal의 output residual이 시간 따라 normal화 |
| 해결 | cron output 직접 읽기 (결함 발견 시 ISS 격상) | monitor 재실행 + 최신 output + MEMORY 재분류 |
| 우선순위 | 🔴 Critical (결함이 은폐됨) | 🟡 Self-heal policy 개선 (오탐 줄이기) |

둘 다 공통 root: **"최신 raw 출력을 다시 본다"는 동일한 원칙**으로 잡힌다.

## 자기 개선 (v1.0.41 격상 효과)

- **이전**: 단순히 MEMORY/issues 새벽 표기 SSOT → stale 일일 리뷰 반복
- **이후**: 리뷰 중 monitor 재실행 + output 직접 읽기 → 실제 운영 상태 반영
- **다음 격상 후보 (v1.0.42)**: self-heal에 "당일 22:00 재실행 idempotent → 새벽 errors는 시간 표시와 함께" 도입. 3번째 적중 시 본 격상 결정.

## 검증 절차 (자기 가드에서 재사용 가능)

```bash
# 1. monitor 재실행
python3 ~/.hermes/scripts/cron_error_monitor.py --status | grep -E '"critical"|"warning"|"ok"'

# 2. 각 "에러" 잡의 최신 output 5줄
for jid in <error job ids>; do
  LATEST=$(ls -t ~/.hermes/cron/output/$jid/ 2>/dev/null | head -1)
  echo "=== $jid / $LATEST ==="
  tail -5 ~/.hermes/cron/output/$jid/$LATEST
done

# 3. status=ok인데 output에 결함 → ISS-086-ext family (은폐 결함)
# 3. status=erro인데 output 정상 → ISS-092 (시간차 stale, 해결로 재분류)
```
