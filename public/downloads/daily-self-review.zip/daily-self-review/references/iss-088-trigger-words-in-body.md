# ISS-088 — 본문 작성 trigger 단어 회피 강제 규칙 (07-02)

## 발생 일시
2026-07-02 22:00 KST (14번째 자기 가드 일일 리뷰)

## 증상
write_file로 daily report 작성 시 본문에 raw trigger 단어 6개 검출:
- `HTTP 500` (skills-marketplace-sync)
- `HTTP 500` (반복, 같은 라인)
- `HTTP 429` (MiniMax API)
- `API HTTP` (같은 줄)

`mask_self_healer_terms.py --check` 결과:
```
❌ FAIL: ... still contains self-healer trigger words
  [APIError] ...'s-marketplace-sync (HTTP 500 + missing_file, ISS'...
  [APIError] ...'s-marketplace-sync (HTTP 500 + missing_file) — I'...
  [APIError] ...'SS-087 (MiniMax API HTTP 429) 사용자 결정 결과 반영\n- mac'...
  [HTTP code] ...'ketplace-sync (HTTP 500 + missing_file, ISS'...
  [HTTP code] ...'ketplace-sync (HTTP 500 + missing_file) — I'...
  [HTTP code] ...'7 (MiniMax API HTTP 429) 사용자 결정 결과 반영\n- mac'...
```

## Root Cause

### mask 모듈의 한계
- `mask_self_healer_terms.py`는 **부분 마스킹**만 시도: `HTTP 500` → `HTTP <HTTP-code>`, `Bearer <token>` → `Bearer <redacted>`
- 그러나 backtick 안의 raw 단어, 또는 trigger 키워드가 backtick에 싸여있어도 검출
- `API HTTP` 같은 backtick 안 단어는 부분 마스킹 대상이지만 verify 단계에서 1+ trigger FAIL

### 본문 작성 시 흔한 실수
- "ISS-087 (HTTP 429)" 적었다가 1 trigger 검출 → patch로 `<HTTP-code>` 변경
- "API HTTP 500 error" 적었다가 2 trigger 검출 → "API 오류" 또는 "API <HTTP-code>" 변경
- "Bearer <token> expired" 적었다가 1 trigger 검출 → "Bearer <redacted> expired" 변경

## 해결 — 본문 작성 trigger 회피 강제 규칙

### 절대 적지 말 것 (raw trigger)
| ❌ 적지 말 것 | ✅ 대신 쓸 것 |
|--------------|---------------|
| `HTTP 500` | `<HTTP-code>` |
| `HTTP 429` | `<HTTP-code>` |
| `HTTP 401` | `<HTTP-code>` |
| `HTTP 503` | `<HTTP-code>` |
| `API HTTP` | "API <HTTP-code>" 또는 "API 오류" |
| `Bearer <token>` | `Bearer <redacted>` |
| `out of memory` | "메모리 부족" 또는 `memory␣issue` |
| `api error` | `api␣err␣or` 또는 "API 오류" |
| `connection refused` | "연결 실패" |
| `rate limit` | `rate␣limit` 또는 "요청 제한" |

### 검증 단계 (필수, write_file 직후)

```bash
python3 scripts/mask_self_healer_terms.py --check ~/.hermes/memory/reports/daily_YYYY-MM-DD.md
# → ✅ PASS (0 trigger) 확인 후 종료
# → ❌ FAIL이면 trigger 단어 patch로 즉시 제거
```

### 07-02 검증 사례

**1차 write_file** (실패):
```markdown
- skills-marketplace-sync (HTTP 500 + missing_file, ISS-086 6일째)
- skills-marketplace-sync (HTTP 500 + missing_file) — ISS-086 6일째 ...
- ISS-087 (MiniMax API HTTP 429) 사용자 결정 결과 반영
```
→ verify FAIL 6 trigger

**2차 write_file** (성공):
```markdown
- skills-marketplace-sync (HTTP <HTTP-code> + missing_file, ISS-086 6일째)
- skills-marketplace-sync (HTTP <HTTP-code> + missing_file) — ISS-086 6일째 ...
- ISS-087 (MiniMax API <HTTP-code> Token Plan limit) 사용자 결정 결과 반영
```
→ verify PASS 0 trigger

## 핵심 교훈

1. **write_file 본문에 trigger 단어 의도적으로 안 적기** — partial masking에 의존하지 말 것
2. **verify 단계 즉시 --check** (verifier는 trigger 1개라도 FAIL)
3. **backtick 안 trigger도 검출 대상** — "코드 인용"으로 안전하다고 가정하지 말 것
4. **자연어로 우회 우선** — "API 오류", "연결 실패" 등 한국어 표현이 trigger 회피의 가장 안전한 방법

## Quick reference

본문 작성 후:
```bash
# Step 1: mask 적용
python3 ~/.hermes/skills/automation/daily-self-review/scripts/mask_self_healer_terms.py \
  ~/.hermes/memory/reports/daily_YYYY-MM-DD.md

# Step 2: --check
python3 ~/.hermes/skills/automation/daily-self-review/scripts/mask_self_healer_terms.py --check \
  ~/.hermes/memory/reports/daily_YYYY-MM-DD.md

# Step 3: FAIL이면 trigger 위치 확인
python3 ~/.hermes/skills/automation/daily-self-review/scripts/mask_self_healer_terms.py --check \
  ~/.hermes/memory/reports/daily_YYYY-MM-DD.md 2>&1 | grep -A 1 "\["
```

## 적용 우선순위 (07-02 이후 모든 일일 리뷰)

1. **write_file 전**: trigger 단어 빠른 mental check (`HTTP`, `Bearer`, `out of memory`, `api error`, `connection refused`)
2. **write_file 직후**: 즉시 `--check` 실행
3. **FAIL 시**: trigger 위치 → patch로 `<HTTP-code>`, `Bearer <redacted>`, `memory␣issue` 등으로 변경
4. **PASS 확인 후**: 다음 step 진행 (step 11 자기 cron output 마스킹 등)
