# ISS-090 — mask_self_healer_terms.py CLI 함정 2종 (07-12 신규)

## 7/12 일일 리뷰 실전 적중 2건

07-12 self-review의 step 9 (저장 직전 report 1회 마스킹) + step 12 (`--check-dir` + retro-masking)에서 **masking 스크립트의 CLI semantics에 대한 2가지 trap**이 동시에 노출됨. 둘 다 root cause가 다르지만 같은 "FAIL이 silent 통과되는" 표면을 만들어 step 검증을 무력화.

---

## 함정 1 — `<file>` CLI 호출은 **stdout으로 write, 파일은 변경 안 됨**

### 증상 (07-12 step 9 실측)
```bash
$ python3 ~/.hermes/skills/automation/daily-self-review/scripts/mask_self_healer_terms.py /Users/mac/.hermes/memory/reports/daily_2026-07-12.md
# ICBM2 일일 자기 개선 리뷰 — 2026-07-12
# ... (masked 본문이 stdout에 출력)

$ python3 .../mask_self_healer_terms.py --check /Users/mac/.hermes/memory/reports/daily_2026-07-12.md
❌ FAIL: ... still contains self-healer trigger words
   [APIError] ...' 10일째, b26b0579a45f HTTP 401 4일째.\n- 메모리 2623 byt'...
```

stdout에는 masked 본문이 흘렀지만 **파일 자체는 unchanged**. 다음 사이클 step 11/12/13이 그 파일을 다시 읽으면 **raw trigger가 그대로** 다음 mask 검증으로 새는 자기 leak.

### Root cause
스크립트의 CLI main 함수가 `sys.stdin.read()` 또는 직접 `file.read_text()` 결과를 `mask()` 후 **`sys.stdout.write()`만 하고 파일에 write하지 않음**. 사용자가 shell redirect 없이 호출하면 stdout이 출력되고 파일은 그대로 — 의도와 정반대.

### 해결 패턴 (A: in-place Python)
```bash
# 권장 — Python module로 import하여 명시적 in-place write
python3 -c "
import sys
from pathlib import Path
sys.path.insert(0, '/Users/mac/.hermes/skills/automation/daily-self-review/scripts')
import mask_self_healer_terms as masker
p = Path('/Users/mac/.hermes/memory/reports/daily_2026-07-12.md')
c = p.read_text()
mc = masker.mask(c)
if masker.is_clean(mc):
    p.write_text(mc)
    print('OK in-place masked + clean')
else:
    print('FAIL still dirty after mask()')
    sys.exit(1)
"
```

### 해결 패턴 (B: shell redirect)
```bash
# 차선 — <file> > 같은file로 stdout redirect (덮어쓰기)
python3 .../mask_self_healer_terms.py /path/to/daily_2026-07-12.md > /path/to/daily_2026-07-12.md
# ⚠️ 위험: 동일 파일로 redirect하면 0바이트 truncation 후 write — 안전하려면 tmp 사용
python3 .../mask_self_healer_terms.py /path/in.md > /tmp/masked.md && mv /tmp/masked.md /path/in.md
```

### 판별 신호
- `--check` 직후 FAIL인데 이전 CLI 호출의 stdout에는 masked 텍스트가 보였다 → 함정 1 적중.
- 파일 mtime이 호출 시각으로 갱신되지 않았는데 stdout만 변경 → 함정 1 적중.

---

## 함정 2 — `--check-dir`/`--mask-dir` RC=0 (디렉토리 dirty도 exit 0)

### 증상 (07-12 step 12 실측)
```bash
$ python3 .../mask_self_healer_terms.py --check-dir ~/.hermes/cron/output
... 
  - 388898171a79/2026-07-12_21-01-21.md
  - 582ecc59aaee/2026-07-12_10-04-00.md
  ... 외 12개
RC=0

# step 12 SKILL.md는 [ $RC -ne 0 ] 가드를 제공하지만:
if [ $RC -ne 0 ]; then
  echo "dirty files found - retro masking"
  python3 .../mask_self_healer_terms.py --mask-dir ~/.hermes/cron/output
fi
# → RC=0이므로 retro-masking **자동 실행 안 됨**. 27 DIRTY 파일이 그대로 누적.
```

### Root cause
스크립트의 `--check-dir` / `--mask-dir` 핸들러가 DIRTY 파일을 stderr/stdout으로 report만 하고 `sys.exit(1)`로 non-zero를 반환하지 않음. CLI invocation의 의미상 "informational, not gating"으로 디자인됨. 그러나 SKILL.md step 12 코드는 RC gating을 전제로 적혀 있어 **서로 어긋남**.

### 해결 패턴 (A: stdout grep)
```bash
# RC 대신 stdout 패턴 grep
OUTPUT=$(python3 .../mask_self_healer_terms.py --check-dir ~/.hermes/cron/output 2>&1)
if echo "$OUTPUT" | grep -q "DIRTY\|trigger 잔존\|FAIL"; then
  echo "dirty files found - retro masking"
  python3 .../mask_self_healer_terms.py --mask-dir ~/.hermes/cron/output
fi
```

### 해결 패턴 (B: 출력 파일 직접 비교)
```bash
python3 .../mask_self_healer_terms.py --check-dir ~/.hermes/cron/output 2>&1 | tee /tmp/dir_check.log
if [ -s /tmp/dir_check.log ] && grep -qE "DIRTY|잔존" /tmp/dir_check.log; then
  python3 .../mask_self_healer_terms.py --mask-dir ~/.hermes/cron/output
fi
```

### 판별 신호
- step 12가 `[ $RC -ne 0 ]` 패턴인데 DIRTY가 명시적으로 출력됐음에도 retro-masking이 호출 안 됨 → 함정 2 적중.

---

## 7/12 실전 타임라인

| 단계 | 호출 | 결과 |
|------|------|------|
| step 9 CLI 1차 | `<file>` (no redirect) | stdout masked, **파일 그대로** |
| step 9 --check | `--check <file>` | ❌ FAIL (8 trigger) |
| step 9 Python in-place | `masker.mask() + write_text()` | ✅ in-place 적용 |
| step 9 --check (재) | `--check <file>` | ✅ PASS |
| step 10 cron/output | `masker.mask() + write_text()` 루프 | ✅ 16 files self-cron-output masked |
| step 10 self_heal today | `masker.mask() + write_text()` | ✅ OK |
| step 12 --check-dir | DIRTY 27 listed, **RC=0** | ⚠️ 함정 2 적중 — `[ $RC -ne 0 ]` no-op |
| step 12 (manual retry) | stdout 보고 직접 호출 | ✅ `--mask-dir` 32 files masked |
| step 13 yesterday retro | `--check` yesterday file | ✅ PASS (이미 step 10에서 처리) |
| step 14 verify_self_healer_patch | `--status` | ✅ 4/4 jobs clean |

---

## 권장 수정 (다음 v1.0.39에서)

1. **SKILL.md step 9**: `<file>` 호출을 **in-place Python 표준 패턴**으로 전면 교체. shell redirect 보조 패턴 한 줄.
2. **SKILL.md step 12**: `[ $RC -ne 0 ]` 가드를 **stdout grep 기반**으로 교체. RC 의존성 제거.
3. **mask_self_healer_terms.py 자체**: `--check-dir` / `--mask-dir`가 DIRTY 발견 시 `sys.exit(1)`을 반환하도록 수정 (스크립트 패치).
4. **신고 라인**: 2개 함정을 step 9/12 SSOT에 항상 명시하고, 첫 patch의 우선순위 (a) 항목으로 승격.

---

## 교훈 — 자기 보수 도구의 self-validation 함정

masking 스크립트는 **자기 자신의 산출물을 검증하는 도구**다. 이 클래스의 도구는 (a) in-place write의 default 기대와 (b) gating RC의 exit code 의미가 **POSIX shell의 통념과 어긋남** — 사용자가 `<file> | redirect` 또는 `[ $RC -ne 0 ]` 패턴을 의식적으로 회피하거나, 스크립트 측에서 POSIX 관습을 따라가야 함. 7/12 실전은 양쪽 모두 어긋난 상태에서 발견됨.

상세: SKILL.md `### ⚠️ Pitfall: mask CLI stdout-vs-inplace + --check-dir RC=0 (ISS-090, 07-12 신규)`
