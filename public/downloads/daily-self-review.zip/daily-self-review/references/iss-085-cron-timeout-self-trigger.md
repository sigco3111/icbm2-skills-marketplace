# ISS-085 — Cron Timeout self-healer 카테고리 6→16 +167% (2026-06-29)

## 문제/증거

2026-06-29 22:00 일일 리뷰 시작 시 cron_self_healer 실행 결과 **Cron Timeout 카테고리 6→16건 +167%** 급증. **23번째 self-healer 패턴 카테고리** (ISS-067 FileNotFoundError → ISS-076 TimeoutError → ISS-077 JSONDecodeError → ISS-079 ConnectionError → ISS-082 ImportError → **ISS-085 Cron Timeout**).

**핵심 차이**: ISS-076 TimeoutError는 **Python 예외 클래스**의 meta-output self-trigger였음. ISS-085 Cron Timeout은 **cron stream idle timeout (600s) 직후 빈 응답** — 즉, **FP가 아닌 실제 timeout 가능성**이 처음 부상한 카테고리.

## 증상 (06-29 발견)

```
# Cron Timeout 카테고리: 6건 → 16건 (+167%)
# critical 4연패 empty_output 4건:
#   - 5d0f14aef84c (일일 자기 개선 리뷰, 자기 자신) 4연패
#   - 5a376ec002c3 (Git 자동 동기화) 4연패
#   - 81f1c81f8664 (심야 통합 점검) 3연패
#   - b26b0579a45f (GitHub Trending) 3연패
# warning 8건
# 총 12건 empty_output 패턴
```

## Root Cause 분석

**단순 가설**: cron_self_healer의 Timeout 패턴이 자기 진단 보고서 meta-output을 self-trigger (ISS-076/077/079와 동일).

**반대 가설**: 4연패 잡의 cron output이 *진짜* 비어있음. cron stream idle timeout (현재 600s)이 작업 완료 전 trigger → 빈 응답 기록 → 다음 날 self-healer가 "TimeoutError"로 분류.

**판별 신호 (06-29 기준)**:
- 자기 잡 4연패: 자기 일일 리뷰가 4일 연속 빈 응답? → **이전 일일 리뷰들 (06-26~06-29)은 모두 정상 응답 + verify 4/4 PASS** → 자기 가드 시스템이 catch. 자기 잡은 **NOT 실제 timeout**.
- Git 자동 동기화 4연패: `5a376ec002c3` 4일 연속 빈 응답? → git push가 600s+ 걸릴 가능성 낮음. **확인 필요**.
- 심야 통합 점검 3연패: 81f1c81f8664 → 여러 잡 조합. **확인 필요**.
- GitHub Trending 3연패: b26b0579a45f → GitHub API + 80+ 리포 scrape. **확인 필요**.

**결론**: 4연패 잡 모두 raw grep으로 **진짜 빈 응답 vs cron 인프라 timeout** 판정 필요. 12건 중 일부는 진짜 timeout 가능성. **mask_self_healer_terms.py 만으로 해결 불가** — cron 인프라 레벨 문제.

## 즉시 fix (06-29 22:00 적용)

1. **자기 가드 시스템 11번째 안정화**: 1/4 FP → 4/4 PASS (자기 잡 06-29 자기 출력 1일 lag)
2. **MEMORY.md 4,726 → 3,512 bytes** 3회 patch (118% → 88% 🟢) — v1.0.16 종료 기준 1회컷 2번째 검증
3. **cron output 누적 41개 일괄 복구** — step 12
4. **self_heal_2026-06-29.md 1회 masking** — step 11
5. **종료 verify ✅ 4/4 PASS** — step 14

## mask_self_healer_terms.py 매핑 점검 (06-29)

ISS-085의 핵심 trigger 패턴 (cron self-healer 코드):
```
\b(?:timeout|timed\s*out|deadline\s*exceeded)\b
```

ISS-076 v1.0.20에서 이미 매핑됨 (TimeoutError / timed out / deadline exceeded / connection timeout). cron output이 진짜 비어있으면 trigger 단어가 안 들어가서 mask도 안 잡음 → **mask layer는 통과**. self-healer의 empty_output 분류는 별도 로직 (output_size=0).

## 검증 데이터 (06-29)

- 시작 verify: ❌ `1/4 FP, 0 errors` (자기 잡 06-29 1일 lag)
- cron output 누적: **359개 중 41개 dirty** (Tistory 등)
- self_heal_2026-06-29.md: 1회 masking (6,564 → 6,597 bytes)
- MEMORY.md: 4,726 → 3,512 bytes (118% → 88%)
- 종료 verify: ✅ `4/4 jobs clean`

## 핵심 교훈 (ISS-085)

1. **Cron Timeout은 meta-output self-trigger가 아닐 수 있다** — 빈 output 자체가 문제. **이전 22번은 trigger 단어 leak** 이었지만, 23번째는 **trigger 단어가 *없는데* Timeout 카테고리에 잡힘** — cron 인프라 timeout.
2. **4연패 empty_output은 FP보다 실제 timeout 가능성** — `verify_self_healer_patch.py`의 verify는 "trigger 매칭"만 보지, "출력 크기"는 보지 않음. **4연패 잡은 raw grep으로 빈 응답 vs 실제 timeout 판정 필수**.
3. **자기 가드 시스템 한계**: trigger 단어 기반 FP 방지에 특화. **출력 크기 기반 anomaly detection** 은 다른 시스템 필요 (예: cron output size monitor).
4. **cron stream idle timeout 600s → 900s 검토** — 12건 누적 추세 (06-27 3개 → 06-29 12건) 원인 추정. 작업 600s+ 걸리는 잡 확인 후 임계값 조정.

## 근본 fix (v1.0.27 권장)

1. **🔴 critical 4잡 raw grep** — 5d0f/5a37/81f1/b26b의 06-26~06-29 출력 직접 확인. 빈 응답이면 cron 인프라 timeout 가능성 → 사용자 결정 (a) timeout 임계값 조정, (b) 잡 분할, (c) 잡 비활성화.
2. **🟡 stream timeout 600→900s 조정 검토** — 빈 출력 잡 12건 누적 추세 (06-27 3개 → 06-29 12건). 모든 잡이 정상 600s 내 완료되면 조정 불필요.
3. **🟡 cron output size monitor 신규** — 자기 가드 시스템의 빈 출력 감지 사각지대 보완. `find ~/.hermes/cron/output -size -200c -mtime -2` 등으로 daily report에 추가.
4. **🟢 skills-marketplace-sync missing_file (06-27~)** — sync-skills.sh 부재로 인한 잡 실패 vs 정상 종료 vs cron 인프라 timeout. **raw grep으로 실제 원인 판정**.
5. **MEMORY.md 자수 종료 기준 검증** — 06-29 3,512 bytes (88%) → 06-30까지 매일 🟢 유지 시 v1.0.16 안정화 1주 검증 완료.

## 진화 타임라인 (ISS-044→085)

ISS-044 (APIError, 06-02) → ISS-058 (MemoryError, 06-03) → ISS-061 (Bearer, 06-04) → ISS-062 (meta-output, 06-05) → ISS-063 (cron prompt drift, 06-07) → ISS-065 (PEP 585, 06-08) → ISS-066 (table leak, 06-08) → ISS-067 (FileNotFoundError, 06-09) → ISS-068 (memory+self_heal, 06-10) → ISS-069 (step 11 drift, 06-11) → ISS-070 (누적, 06-12) → ISS-071 (1일 lag, 06-13) → ISS-072 (exit criterion, 06-14) → ISS-073 (3-stage 검증, 06-15) → ISS-074 (1차 프로덕션, 06-16) → ISS-075 (Tistory 70%+, 06-18) → ISS-076 (TimeoutError, 06-19) → ISS-077 (JSONDecodeError, 06-20) → ISS-078 (jobs.json drift, 06-20) → ISS-079 (ConnectionError, 06-21) → ISS-080 (execute_code, 06-23) → ISS-081 (pipe-to-interpreter, 06-24) → ISS-082 (ImportError, 06-26) → **ISS-085 (Cron Timeout, 06-29)**.

**23번 진화 (06-02~06-29) — 27일**. 06-15~06-29 동안 9번 안정화 (Tistory 12회 평균 73%, v1.0.11 권고 1번 D-day).
