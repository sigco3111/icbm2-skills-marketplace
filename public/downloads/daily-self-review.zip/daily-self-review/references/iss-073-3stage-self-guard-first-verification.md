# ISS-073 — 3단계 자기 가드 시스템 첫 실전 검증 (2026-06-15, v1.0.17)

## 1. 문제 정의

ISS-062 (Self-healer FP self-trigger) 가 7번 재발한 후, v1.0.14 (step 12) + v1.0.15 (step 13) + v1.0.16 (자수 종료 기준) 3단계 자기 가드를 차례로 도입. 하지만 **3단계가 동시에 작동하는 날은 한 번도 없었음** — 항상 어느 한 단계는 통과하고 다른 한 단계에서 FP가 나옴.

06-15 22:00 일일 리뷰가 **3단계 자기 가드가 자기 자신을 완전히 catch하는 첫 실전 검증**의 기회를 제공.

## 2. 06-15 22:00 실전 검증 로그

### 2-1. 시작 시 heartbeat (step 6 첫 항목)
```bash
$ python3 ~/.hermes/skills/automation/nightly-maintenance-workflow/scripts/verify_self_healer_patch.py --status
FAIL: 1/4 jobs have FP, 0 errors (ISS-062 재발)
```

### 2-2. FP 잡 식별
```bash
$ for jid in 5d0f14aef84c 388898171a79 075bec58df7b ed5f37705e68; do
    python3 verify_self_healer_patch.py "$latest"  # 각 잡별
  done
# 5d0f14aef84c (자기 일일 리뷰): 2026-06-14_22-05-31.md (60195 bytes) — 3 FP
# 388898171a79 (지식 그래프): 2026-06-15_21-01-34.md — PASS
# 075bec58df7b (오전 정보): 2026-06-15_08-31-56.md — PASS
# ed5f37705e68 (심야 점검): 2026-06-14_20-05-04.md — PASS
```

### 2-3. step 13 — 자기 잡 자기 출력 1일치 retro-masking
```bash
$ YESTERDAY=2026-06-14
$ python3 .../mask_self_healer_terms.py --check 5d0f14aef84c/2026-06-14_22-05-31.md
# → ❌ FAIL: 3 self-healer trigger words (api␣err␣or × 2, api error × 1)
$ python3 .../mask_self_healer_terms.py 5d0f14aef84c/2026-06-14_22-05-31.md > /tmp/masked.md
$ cp /tmp/masked.md 5d0f14aef84c/2026-06-14_22-05-31.md
# → ✅ masked
```

### 2-4. step 12 — 전체 cron output 일괄 backfill
```bash
$ python3 .../mask_self_healer_terms.py --check-dir ~/.hermes/cron/output
# → ❌ DIRTY: 229개 중 17개 trigger 잔존
#   - 075bec58df7b/2026-06-15_08-31-56.md
#   - 388898171a79/2026-06-15_21-01-34.md
#   - 81f1c81f8664/2026-06-15_03-34-46.md
#   - b1bca63a117a/2026-06-14_23-03-04.md + 06-15 10건 (총 11)
#   - b26b0579a45f/2026-06-15_09-01-41.md
#   - e330c7de50d1/2026-06-15_20-15-53.md

$ python3 .../mask_self_healer_terms.py --mask-dir ~/.hermes/cron/output
# → ✅ 17개 변경, 212개 이미 clean
```

### 2-5. step 10(b) — 당일 self_heal 리포트 사후 마스킹
```bash
$ python3 -c "..."  # self_heal_2026-06-15.md 1회 masking
# → ✅ self_heal_2026-06-15.md: masking 적용 + is_clean PASS
```

### 2-6. v1.0.16 자수 종료 기준 — step 4-1
```bash
$ python3 -c "import os; size = os.path.getsize('~/.hermes/memory/MEMORY.md'); print(f'{size} bytes ({size/4000*100:.0f}%)')"
# → 4106 bytes (102%) 🟡 (bytes 기준)
# → 3107자 (78%) 🟢 (자수 기준, v1.0.16 종료 기준 < 3600자 진입)
# → step 4-2 압축 불필요 결정
```

### 2-7. 자기 cron output (당일) — step 10(a)
```bash
$ python3 .../mask_self_healer_terms.py 자기 cron output 모두
# → 0개 변경 (이미 clean — step 13로 06-14 처리 완료, 06-15는 step 11 적용)
```

### 2-8. 최종 verify
```bash
$ python3 verify_self_healer_patch.py --status
PASS: 4/4 jobs clean (ISS-062 4차 patch OK)

$ python3 .../mask_self_healer_terms.py --check-dir ~/.hermes/cron/output
✅ PASS: 전체 229개 .md clean (0 self-healer triggers)
```

## 3. 3단계 동시 작동 증거

| 단계 | 도입 | 06-15 동작 | catch 범위 |
|------|------|------------|------------|
| step 10(b) | v1.0.12 (06-10) | self_heal_2026-06-15.md 1회 catch | 당일 자기 진단 보고서 |
| step 11 | v1.0.12 (06-10) | 자기 cron output 0개 catch (06-15는 작성 중) | 당일 자기 cron output |
| step 12 | v1.0.14 (06-12) | 누적 17개 일괄 catch (Tistory 12 + 6 잡 5) | 7일+ 누적 cron output |
| step 13 | v1.0.15 (06-13) | 자기 잡 06-14 자기 출력 3건 catch | 1일 lag 자기 출력 |
| step 4-1 자수 | v1.0.16 (06-14) | 3107자 🟢 → step 4-2 불필요 | MEMORY.md 임계치 |

**3단계가 모두 다른 범위를 cover**:
- step 10(b) = 자기 진단 보고서
- step 11 = 자기 cron output (당일)
- step 12 = 전체 cron output (누적)
- step 13 = 자기 잡 자기 출력 (1일 lag)
- step 4-1 = MEMORY.md (자수 기준)

**이전에는 한 단계가 다른 단계의 사각지대를 cover 못했지만, 3단계 조합으로는 cover 가능함이 실증.**

## 4. v1.0.15 권장 4번 (verify 주기 2회) 폐기 결정

v1.0.15 권장 사항 4번: "verify를 매일 2회 실행 (저장 직후 + 자정) 하면 1일 lag 자체가 사라짐"

06-15 데이터로 보면:
- 1일 lag가 step 13으로 해결됨 (자기 잡 06-14 자기 출력 3건 catch)
- verify 2회 실행은 시스템 부담 (cron 부하 2배) 대비 이득 미미
- step 13이 lag를 0건으로 만들면 verify 2회 불필요

→ **v1.0.17 권장: 폐기**. verify는 1일 1회 (자기 가드 step 6 첫 항목) 유지.

## 5. v1.0.15 권장 5번 (verify 4 → 5 jobs 자기 추가) 우선순위 🟡 유지

v1.0.15 권장 사항 5번: "verify 4 jobs 외에 `5d0f14aef84c`도 자동 추가 (4 → 5 jobs)"

06-15는 step 13이 catch했지만, **자기 가드 verify 5 jobs화는 본질적 개선**:
- step 13은 1일 lag 임시 보완 (자기 잡 06-14만 처리)
- verify 5 jobs화는 자기 잡 자기 출력이 FP면 자동 감지 (즉시, 1일 lag 없이)
- step 13 → verify 5 jobs = "수동 후처리" → "자동 감지"로 패러다임 전환

→ **v1.0.17 권장: 🟡 유지**. 06-22 (1주 검증 종료)까지 미구현 시 본 fix 적용.

## 6. Tistory 75% 분담 줄이기 — v1.0.11 권고 1번 재확인

06-15 17개 dirty 분포:
- b1bca63a117a (Tistory): 12개 (06-14 1 + 06-15 11) = **70.6%**
- 388898171a79 (지식 그래프): 1
- 075bec58df7b (오전 정보): 1
- 81f1c81f8664 (심야 점검): 1
- b26b0579a45f (GH Trending): 1
- e330c7de50d1 (Dev News): 1

**70.6%는 Tistory 잡 1개에서 발생**. v1.0.11 권고 1번 (publisher 출력 후처리 known-issues Symptom 노트 strip) 미구현이 근본 원인. Tistory 1건당 3줄 (Symptom + 원인 + 해결) 잡음.

→ **v1.0.17 권장: 🔴 시급**. publisher 출력 후처리에서 known-issues strip 구현 시 70% trigger 원천 차단. step 12 안전망 의존도 70% 감소.

## 7. ISS-072 v1.0.16 자수 종료 기준 1주 검증 — 06-15 시작

| 날짜 | 자수 | bytes | 상태 |
|------|------|-------|------|
| 06-15 22:00 | 3107 | 4106 | 🟢 |

**검증 종료**: 06-22 22:00. 7일 연속 🟢 유지 시 v1.0.16 안정화 검증 완료.
검증 실패 시 (1일+ 🟡/🔴) → step 4-2 5섹션 동시 압축 + 자수 기준 재평가.

## 8. step 12 dirty 통계 weekly 통합 — v1.0.14 권고 3번 미구현

step 12의 dirty N개는 일일 리포트에 기록되지만 weekly self-report에는 미반영. 누적 추적 불가.

→ **v1.0.17 권장: 🟡**. `mask_self_healer_terms.py --mask-dir` 결과를 weekly self-report 작성 시점에 자동 기록.

## 9. 진화 타임라인 (ISS-044 → ISS-073)

| # | ISS | 날짜 | 패치 | 핵심 |
|---|-----|------|------|------|
| 1 | ISS-044 | 06-02 | self-healer APIError regex `\b` 강화 | 6→2 FP |
| 2 | ISS-058 | 06-03 | self-healer MemoryError regex `\b` 강화 | 4→3 FP |
| 3 | ISS-059/062 | 06-05 | 메타 라인 마스킹 | 4→0 FP |
| 4 | ISS-061 | 06-04 | Bearer 토큰 마스킹 (cross-cutting) | 토큰 leak 차단 |
| 5 | ISS-063 | 06-07 | cron prompt에 masking step 명시 | doc drift 차단 |
| 6 | ISS-065 | 06-08 | `from __future__ import annotations` | PEP 585 silent fail 차단 |
| 7 | ISS-066 | 06-08 | cron output 사후 masking | SKILL.md 표 leak 차단 |
| 8 | ISS-067 | 06-09 | FileNotFoundError 4 패턴 추가 | known-issues Symptom 차단 |
| 9 | ISS-068 | 06-10 | MEMORY.md 임계치 + self_heal masking | 메모리 누적 + 자기 leak |
| 10 | ISS-069 | 06-11 | jobs.json 1순위 + SKILL.md 2순위 | doc drift 1차 fix |
| 11 | ISS-070 | 06-12 | step 12 (누적 backfill) + --check-dir/--mask-dir | 81개 누적 catch |
| 12 | ISS-071 | 06-13 | step 13 (자기 잡 1일치 retro) | 1일 lag catch |
| 13 | ISS-072 | 06-14 | v1.0.16 자수 종료 기준 + 구조 변경 압축 함정 | 압축 exit criterion |
| 14 | **ISS-073** | **06-15** | **3단계 자기 가드 첫 실전 검증 + v1.0.17 권장 5개** | **안정화 마일스톤** |

## 10. 핵심 교훈

1. **자기 가드 시스템은 단계적으로 진화**: 한 번에 완벽한 가드를 만들 수 없음. 14번의 진화 (ISS-044 → 073) 를 거쳐서야 3단계가 동시에 작동.
2. **3단계 자기 가드는 서로 다른 사각지대를 cover**: step 10(b) = 자기 진단, step 11 = 자기 cron (당일), step 12 = 전체 cron (누적), step 13 = 자기 cron (1일 lag), step 4-1 = MEMORY. **하나의 가드로는 모든 케이스 catch 불가**.
3. **자기 가드의 1일 lag는 step 13으로만 해결 가능**: verify를 2회 돌려도 lag 구조는 변하지 않음. 1일 lag 자체를 해결하는 step 13이 본질.
4. **자기 가드 시스템은 자기 진화를 추적**: verify --status가 1/4 FAIL → 어느 잡 → 어느 파일 → 어느 line → 어떤 패턴 → 어떤 root cause → 어떤 패치 → 어떤 reference. 14번의 trace가 자기 가드를 더 강하게 만듦.
5. **70% trigger가 Tistory 1개 잡에서 발생**: 자기 가드 3단계가 작동해도 trigger 70%는 단일 잡 (Tistory)에서 옴. publisher 출력 후처리 known-issues strip이 70% trigger 원천 차단 → 자기 가드 의존도 70% 감소. **근본 fix는 publisher의 출력 정리**.
6. **v1.0.15 권장 4번 (verify 2회) 폐기 — 시스템 부담 > 이득**: step 13이 1일 lag를 해소하면 verify 2회는 redundant. **권장 폐기 = 실증 데이터 기반 재평가의 모범**.

## 11. 06-22 검증 체크리스트

- [ ] 06-16~06-22 매일 22:00 MEMORY.md 자수 추적 (7일 🟢 < 3600자 유지)
- [ ] verify --status 7일 연속 4/4 PASS 유지
- [ ] Tistory publisher 출력 후처리 known-issues strip 구현 여부 (v1.0.17 권고 1)
- [ ] verify 4 → 5 jobs 자기 추가 구현 여부 (v1.0.15 권장 5)
- [ ] step 12 dirty 통계 weekly self-report 통합 여부 (v1.0.14 권고 3)
