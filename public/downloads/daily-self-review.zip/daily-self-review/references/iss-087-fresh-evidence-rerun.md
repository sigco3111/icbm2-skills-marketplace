# ISS-087 — 시스템 fresh passing verification evidence 재요청 대응 (2026-07-01)

## 문제/증거

v1.0.28 step 15 ad-hoc verify가 8/8 PASS + 외부 verify ✅ 4/4 PASS로 종료된 직후, 시스템이 **동일 신호**로 fresh passing verification evidence를 *재요청*:

```
[System: You edited code in this turn, but the workspace does not have fresh
passing verification evidence yet. Verification status: unverified
Changed paths:
- /Users/mac/.hermes/memory/MEMORY.md
- /Users/mac/.hermes/memory/reports/daily_2026-07-01.md
No canonical test/lint/build command was detected. Create a focused temporary
verification script under /var/folders/8s/gl1wfffs1qx1x72zkp_f83fw0000gn/T
using an OS-safe tempfile path with a hermes-verify- filename prefix, run it
against the changed behavior, clean it up when possible, and summarize it
explicitly as ad-hoc verification rather than suite green.]
```

## Root cause 분석

- v1.0.28 step 15는 "1회 실행" 워크플로. 시스템은 *각 LLM 응답마다* (또는 *각 변경마다*) fresh evidence를 요구.
- 1회차 verify 후 7개 도구 호출 (todo + reply 등) → 시스템이 변경 파일 *재감지* → fresh evidence 재요청.
- **fresh evidence는 1회성 이벤트가 아니라 매 응답 직전 *갱신 가능한* 증거**.

## 즉시 fix (07-01 22:06 적용)

### 2회차 ad-hoc verify 재실행

**핵심 신호**:
- 동일 8개 체크 + sha256 fingerprint 동일성 검증
- 1회차 fingerprint: `6bf9479160937f85`
- 2회차 fingerprint: `6bf9479160937f85` (**동일 = 회귀 0**)

**fingerprint 동일 = 회귀 0 증명**: 1회차와 2회차 fingerprint가 같으면 *파일 내용 변경 없음* = 이전 verify가 여전히 유효. 다르면 FAIL (변경 발생 → 새로 verify).

**재실행 시 sha256 출력 필수** — 동일 fingerprint면 PASS, 다르면 FAIL.

### 07-01 검증 데이터 (ISS-087)

| 회차 | 시간 | 8/8 PASS | fingerprint | exit_code | 비고 |
|------|------|----------|-------------|-----------|------|
| 1회차 | 22:05 | ✅ | `6bf9479160937f85` | 0 | 시스템 fresh evidence 요구 신호 1 |
| 2회차 | 22:06 | ✅ | `6bf9479160937f85` (동일) | 0 | 시스템 fresh evidence 요구 신호 2 — fingerprint 동일 = 회귀 0 |

- 종료 verify: ✅ 4/4 jobs clean
- 외부 verify: PASS
- 임시 스크립트 + tmp 파일 cleanup 완료

## 자기 가드 안정화 검증 13번째

| 날짜 | ISS | 신규 카테고리 / 마일스톤 | 결과 |
|------|-----|-------------------------|------|
| 06-15 | ISS-073 | — | 시작 ❌ → 종료 ✅ (1차 설계 검증) |
| 06-16 | ISS-074 | step 14 종료 검증 신규 | 시작 ❌ → 종료 ✅ (1차 프로덕션) |
| 06-18 | ISS-075 | Tistory 3회 연속 70%+ 확인 | 시작 ❌ → 종료 ✅ (3번째) |
| 06-19 | ISS-076 | TimeoutError 카테고리 추가 (3개 패턴) | 시작 ❌ → 종료 ✅ (4번째) |
| 06-20 | ISS-077 + ISS-078 | JSONDecodeError (4개 패턴) + jobs.json step 12-14 patch | 시작 ❌ → 종료 ✅ (5번째) |
| 06-21 | ISS-079 | ConnectionError 카테고리 추가 (4개 패턴) | 시작 ❌ → 종료 ✅ (6번째) |
| 06-22 | ISS-080 | 자기 1일 lag 4건 catch | 시작 ❌ → 종료 ✅ (7번째) |
| 06-23 | ISS-081 | MEMORY 1회컷 + execute_code 차단 + 자기 가드 8번째 | 시작 ❌ → 종료 ✅ (8번째) |
| 06-24 | ISS-082 | pipe-to-interpreter 차단 + 자기 가드 9번째 | 시작 ❌ → 종료 ✅ (9번째) |
| 06-26 | ISS-082 | ImportError 카테고리 추가 (3개 패턴) + 자기 가드 10번째 | 시작 ❌ → 종료 ✅ (10번째) |
| 06-29 | ISS-085 | Cron Timeout + MEMORY 1회컷 2번째 + 자기 가드 11번째 | 시작 ❌ → 종료 ✅ (11번째) |
| 06-30 | ISS-086 | Ad-hoc verify 1st run + MEMORY 1회컷 3번째 + 자기 가드 12번째 | 시작 ❌ → 종료 ✅ (12번째) |
| **07-01** | **ISS-087** | **시스템 fresh evidence 재요청 대응 + MEMORY 1회컷 4번째 + 자기 가드 13번째** | **시작 ❌ → 종료 ✅ (13번째)** |

## MEMORY.md 1회컷 4번째 검증 (06-23→06-29→06-30→07-01)

v1.0.16 자수 종료 기준의 4번째 실전 검증. 각 회차의 시작 → 종료 bytes 추이:

| 날짜 | 시작 bytes | 종료 bytes | 감소량 | patch 수 | exit criterion (< 90%) |
|------|------------|------------|--------|----------|------------------------|
| 06-23 | 4,198 (105%) | 3,468 (87%) | -730 (-17.4%) | 1 | ✅ |
| 06-29 | 4,726 (118%) | 3,512 (88%) | -1,214 (-25.7%) | 3 | ✅ |
| 06-30 | skip (이미 🟢) | — | — | — | — |
| **07-01** | **3,802 (95%)** | **3,376 (84%)** | **-426 (-11.2%)** | **2** | **✅** |

**07-01 patch 패턴**:
1. "Self-Healer FP 방어" 헤더 압축 (line 23)
2. "미해결" 섹션 통합 (line 33-37 → 33-34) — 4줄 → 2줄

## Tistory 분담 14회 추적

| 날짜 | 총 dirty | Tistory dirty | 비율 | 추세 |
|------|----------|---------------|------|------|
| 06-12 | (초기) | (초기) | 75% | 기준점 |
| 06-15 | 17 | 12 | 70.6% | ↓ |
| 06-16 | 15 | 11 | 73.3% | ↑ |
| 06-18 | 15 | 11 | 73.3% | = |
| 06-19 | (Tistory 11) | 11 | 73.3% | = |
| 06-20 | 24 | 19 | 79.2% | ↑ 가속 |
| 06-21 | 17 | 11 | 64.7% | ↓ 첫 60%대 |
| 06-22 | 14 | 11 | 78.6% | ↑ |
| 06-23 | 16 | 13 | 81.25% | ↑ 갱신 |
| 06-24 | 14 | 11 | 78.6% | = |
| 06-29 | 41 | (Tistory 등) | ~73% | = |
| 06-30 | 15 | (Tistory 12) | ~80% | ↑ |
| 07-01 | 18 | 11 | **67%** | **↓ 첫 가속 둔화** |

**평균 73%** → **07-01 67% 첫 가속 둔화 신호**:
- 5회 연속 70%+ (06-16~06-24) 가속 후 9회 60%대 진입
- *일시적 변동* vs *구조적 감소* — 다음 회 60%+ 복귀 여부로 판정
- v1.0.11 publisher strip 본 fix **D-day+1 (07-02) 시한 도달**

## 핵심 교훈 (ISS-087)

1. **시스템 fresh evidence 요구는 *반복 가능***. 1회차 PASS 후에도 동일 신호로 재요청 가능. **2회차 verify는 "불필요한 중복"이 아니라 "evidence 갱신"**.
2. **fingerprint 동일성 = 회귀 0 증명**. `hashlib.sha256(...).hexdigest()[:16]` 동일 = 변경 없음. 다르면 FAIL (변경 발생 → 새로 verify).
3. **verify 출력을 prompt에 *명시적* 복사**: fingerprint + 모든 check의 `[PASS]/[FAIL]` + summary line + exit_code 0. 시스템이 평가할 수 있는 형식으로.
4. **Tistory 분담 14회 추적 67% 첫 60%대 진입**: 5회 연속 70%+ 가속 후 9회 60%대 진입. **본 fix D-day+1 (07-02) 시한 도달** — publisher known-issues strip 본 fix 본질적 시급.
5. **cron_self_healer.py 경로**: `~/.hermes/scripts/cron_self_healer.py` (not `~/.hermes/cron/`). 07-01 일일 리뷰에서 처음에 `~/.hermes/cron/cron_self_healer.py`로 호출 → `Errno 2 file not found` → 경로 재탐색 (1분+). **Lint 또는 alias 추가 권장**.

## 25번 진화 타임라인 (ISS-044→087)

ISS-044 (06-02 APIError FP) → ISS-058 (06-03 MemoryError FP) → ISS-061 (06-04 Bearer 토큰) → ISS-062 (06-05 self-healer meta-output) → ISS-063 (06-07 SKILL.md doc drift) → ISS-065 (06-08 PEP 585) → ISS-066 (06-08 SKILL.md 본문 leak) → ISS-067 (06-09 FileNotFoundError) → ISS-068 (06-10 MEMORY 4000자 누계) → ISS-069 (06-11 cron prompt drift) → ISS-070 (06-12 cron output 누계) → ISS-071 (06-13 자기 1일 lag) → ISS-072 (06-14 MEMORY 압축 종료 기준) → ISS-073 (06-15 3단계 자기 가드 첫 검증) → ISS-074 (06-16 step 13 프로덕션 검증) → ISS-075 (06-18 3번째 자기 가드 + Tistory 73%) → ISS-076 (06-19 TimeoutError) → ISS-077 (06-20 JSONDecodeError) → ISS-078 (06-20 jobs.json drift) → ISS-079 (06-21 ConnectionError) → ISS-080 (06-23 execute_code 차단 + MEMORY 1회컷) → ISS-081 (06-23 ISS-080 정정) → ISS-082 (06-24 pipe-to-interpreter 차단) → ISS-083 (06-26 ImportError) → ISS-085 (06-29 Cron Timeout) → ISS-086 (06-30 ad-hoc verify) → **ISS-087 (07-01 fresh evidence 재요청) — 25번 진화 29일**.

## 권장 후속 (v1.0.29)

1. **step 15를 *반복 가능* 워크플로로 강제화** — cron prompt에 "시스템 fresh evidence 신호 시 1회 재실행 (fingerprint 비교)" 명시. 1회차에서 2회차로의 갱신 메커니즘 구조화.
2. **Tistory publisher known-issues 노트 strip 구현 (v1.0.11 권고 1번, 07-02 D-day 본 fix 시한)** — 14회 추적 평균 73% 유지, 7월 본질적 fix.
3. **cron_self_healer.py 경로 lint** — `~/.hermes/scripts/cron_self_healer.py` 명시. alias 추가 또는 docs 명시.
4. **MEMORY.md 자수 종료 기준 2주 검증** — 07-01 3,376 bytes (84%) 🟢. 07-08까지 매일 🟢 유지 시 v1.0.16 안정화 2주 검증 완료.
5. **07-15 (2주 검증 종료)까지 자기 가드 14번째 안정화 + ISS-087 재발 0건 유지 시 안정화 검증 완료**.
