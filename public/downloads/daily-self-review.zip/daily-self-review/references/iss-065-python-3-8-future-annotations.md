# ISS-065 — Python 3.8 / 3.10+ 이중 시스템에서 `from __future__ import annotations` (PEP 563) 활용

## 클래스-수준 함정 (CRITICAL)

Hermes 환경은 **`/usr/bin/python3` = Python 3.8.8** (시스템 기본) + **`/usr/local/bin/python3.10`** (별도 설치) 두 버전이 공존한다. cron 잡은 시스템 기본 `python3`로 실행되므로, **PEP 585 어노테이션 (`list[str]`, `dict[str, int]`, `tuple[str, ...]`, `type[X] | None` 등) 을 쓰면 import 단계에서 silent fail**한다.

## 증상

```python
# scripts/mask_self_healer_terms.py (ISS-065 root cause)
def main(argv: list[str]) -> int:   # ← PEP 585 — Python 3.9+ 전용
    ...
```

```
$ python3 scripts/mask_self_healer_terms.py --check foo.md
Traceback (most recent call last):
  File ".../mask_self_healer_terms.py", line 145, in <module>
    def main(argv: list[str]) -> int:
TypeError: 'type' object is not subscriptable
```

- **3.8.8에서는 즉시 import 실패** — `TypeError`로 import 자체가 깨짐
- **3.10+에서는 정상 작동**
- cron 잡은 `python3` (3.8)로 실행되므로 **silent하게 step이 skip**되어 후속 self-healer가 FP를 잡아냄

## 영향 사례 (실전)

| 일자 | 스크립트 | 증상 | 영향 |
|------|---------|------|------|
| 2026-06-08 | `mask_self_healer_terms.py` | 9단계 masking step silent fail | 어제 daily review cron output에 raw trigger 잔존 → 22:00 self-healer가 1건 FP 감지 |
| 2026-04~ | `scripts/knowledge_graph.py` 등 | `dict[str, int]` 같은 type hint로 간헐적 import fail | 크론 가끔 실패, 디버깅 어려움 |

## 해결 — `from __future__ import annotations` (PEP 563)

```python
# 파일 최상단 (import sys/re 위에) — 한 줄 추가
from __future__ import annotations

import re
import sys

# 이제 아래 PEP 585 어노테이션은 3.8에서도 정상 작동
def main(argv: list[str]) -> int:
    items: dict[str, int] = {}
    ...
```

**왜 이게 작동하나**:
- PEP 563은 모든 어노테이션을 **lazy string**으로 평가 (런타임에 `__annotations__`이 dict[str, str])
- PEP 585 `list[str]` 같은 builtin generic subscript가 3.8에서 `TypeError`로 평가되던 것이, **3.9+ 호환 string으로 저장**되어 import 단계에서 실패하지 않음
- 3.10+에서도 동일하게 동작 (string → 실제 type은 `typing.get_type_hints()`로 명시적으로 꺼내야 사용)

## 진짜 안전한 패턴 (v1.0.10+ 권장)

모든 Hermes 스크립트는 **다음 패턴으로 작성**할 것:

```python
#!/usr/bin/env python3
"""..."""

# CRITICAL: cron은 시스템 python3 (3.8)로 실행되므로 PEP 585 호환 필수
from __future__ import annotations

import re
import sys
from typing import Optional, List, Dict   # ← 호환을 위해 typing 모듈도 함께 사용

def main(argv: List[str]) -> int:   # ← List[str] (typing 모듈) 권장
    items: Dict[str, int] = {}
    ...
```

**이중 안전망**:
- `from __future__ import annotations` (PEP 563) — `list[str]` 어노테이션 자체를 3.8 호환 string으로
- `from typing import List, Dict, Optional` — 3.8에서도 eval 가능한 명시적 generic

## 검증 절차

새 스크립트 작성 후 cron에 등록하기 전:

```bash
# 1) 시스템 python3 (3.8)로 import test
python3 -c "import sys; sys.path.insert(0, 'PATH/TO/SCRIPT'); import SCRIPT_NAME; print('OK 3.8')"

# 2) python3.10으로 동일 test
/usr/local/bin/python3.10 -c "import sys; sys.path.insert(0, 'PATH/TO/SCRIPT'); import SCRIPT_NAME; print('OK 3.10')"

# 3) 둘 다 OK여야 cron 등록
```

## SKILL.md Pitfall 섹션 보강 권장 (v1.0.10+)

`daily-self-review/SKILL.md` 본문의 기존 "### ⚠️ Pitfall: Python 버전 불일치" 섹션은 **Type union (`X | None`) 만** 다루고 있음. **PEP 585 builtin generic subscript (`list[str]`)** 는 별도 함정이므로, 본문 Pitfall 섹션을 다음과 같이 확장 권장:

```markdown
### ⚠️ Pitfall: Python 3.8 vs 3.10+ 호환성 (ISS-036, ISS-065 통합)

**함정 1 — Type union (`X | None`)**: 3.8에서 `TypeError: unsupported operand type(s) for |: 'type' and 'NoneType'`
**함정 2 — PEP 585 builtin generic (`list[str]`, `dict[str, int]`)**: 3.8에서 `TypeError: 'type' object is not subscriptable`

**공통 해결 — 모든 Hermes 스크립트 최상단에**:
\`\`\`python
from __future__ import annotations   # PEP 563: 어노테이션을 lazy string으로 (3.8/3.10+ 둘 다 호환)
from typing import List, Dict, Optional, Tuple  # 3.8 호환을 위해 명시적 typing 사용
\`\`\`

상세: \`references/iss-065-python-3-8-future-annotations.md\`
```

## 재발 감지 체크리스트

스크립트가 cron에서 silent fail하는지 의심되는 경우:

- [ ] `python3 -c "import SCRIPT"` 가 3.8.8에서 import 성공하는가?
- [ ] `python3 -c "import SCRIPT; print(SCRIPT.__annotations__)"` 가 정상 dict를 출력하는가?
- [ ] `from __future__ import annotations` 가 파일 최상단에 있는가?
- [ ] 3.8 호환 typing (`List`, `Dict`) 만 사용하고 `list[str]` 직접 사용은 안 하는가?

## 관련

- ISS-036: 기존 `X | None` type union 함정 (2026-04~ 발견)
- ISS-065: PEP 585 `list[str]` silent fail (2026-06-08, 이 reference 작성)
- `references/iss-063-cron-prompt-doc-drift.md` — doc drift와 silent fail의 결합 위험
