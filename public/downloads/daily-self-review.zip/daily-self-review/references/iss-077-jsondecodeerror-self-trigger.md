# ISS-077: JSONDecodeError Self-Trigger (2026-06-20)

## 문제

2026-06-20 22:00 일일 리뷰 시작 시 `verify_self_healer_patch.py --status` → ❌ `1/4 jobs FP, 0 errors`. FP 잡 = 자기 일일 리뷰 `5d0f14aef84c` 자기 어제 출력 (`2026-06-19_22-04-59.md`), 7건 FP.

`cron_self_healer.py` 의 **JSONDecodeError 패턴**:
```python
r"\b(?:json[\s._-]*decode[\s._-]*error|expecting[\s._-]*value|invalid[\s._-]*json)\b"
```

Tistory 잡 `b1bca63a117a` 의 cron output에 `json.decoder.JSONDecodeError: Expecting value: line 1 column 1 (char 0)` 같은 traceback 라인이 raw로 leak되어 self-healer가 재매칭. **4번째 신규 self-healer 카테고리** (APIError / MemoryError / TimeoutError 다음).

`mask_self_healer_terms.py` 의 `_MASK_TABLE` 에 JSONDecodeError / json decode error / expecting value / invalid json 4개 패턴이 **모두 누락**되어 있었음. ISS-067 (FileNotFoundError) / ISS-076 (TimeoutError) 와 동일 패턴.

## 즉시 fix (2026-06-20 22:01)

### 1. `mask_self_healer_terms.py` pair-patch (ISS-067 discipline 10번째 재적용)

**`_MASK_TABLE` 에 4개 패턴 추가**:
```python
(r'\bJSONDecodeError\b', 'json\u2423decode\u2423issue'),
(r'\bjson[\s._-]*decode[\s._-]*error\b', 'json\u2423decode\u2423issue'),
(r'\bexpecting[\s._-]*value\b', 'json\u2423decode\u2423issue'),
(r'\binvalid[\s._-]*json\b', 'json\u2423decode\u2423issue'),
```

**`_has_trigger test_patterns` 도 페어 동기화** (ISS-067 핵심 교훈):
```python
r'\bJSONDecodeError\b',
r'\bjson[\s._-]*decode[\s._-]*error\b',
r'\bexpecting[\s._-]*value\b',
r'\binvalid[\s._-]*json\b',
```

### 2. 검증 (Python 3.8 + 3.10 양쪽 호환, ISS-065 discipline)

```bash
python3 -c "import mask_self_healer_terms as m; print(m.mask('JSONDecodeError Expecting value invalid json')); print(m.is_clean(m.mask('...same...')))"
# 3.8: ✅ import PASS, mask: 'json␣decode␣issue ...', is_clean: True
# 3.10: ✅ import PASS, mask: 'json␣decode␣issue ...', is_clean: True
```

### 3. step 12 (cron output 누적 backfill) 가 1회 trigger되어 24개 dirty 일괄 복구
- 287개 .md 중 24개 변경 (Tistory 19 + 자기 1 + KG 1 + 오전 1 + 심야 1 + Dev News 1)
- 263개 이미 clean → 변경 없음
- 24개 모두 `json␣decode␣issue` 로 마스킹

### 4. verify 재실행
- 시작: ❌ `1/4 jobs FP` (자기 잡 06-19 7건)
- 종료: ✅ `4/4 jobs clean` (자기 가드 시스템 5번째 연속 안정화)

## 검증 데이터 (06-20)

| 항목 | 결과 |
|------|------|
| 자기 cron output 06-19 | 7 FP (JSONDecodeError × 5 + TimeoutError × 1 + MemoryError × 1) catch |
| cron output 누적 | **287개 중 24개 dirty** (Tistory 19 = **79.2%** ← 70%에서 증가) |
| self_heal_2026-06-20.md | 1회 masking + is_clean PASS |
| MEMORY.md | 3235 bytes 81% 🟢 |
| 시작 verify ❌ → 종료 verify ✅ | 자기 가드 시스템 5번째 연속 안정화 |

## Tistory 분담 추이 (4회 연속 — 06-15/16/18/20)

| 날짜 | 총 dirty | Tistory dirty | 비율 |
|------|---------|---------------|------|
| 06-15 (ISS-073) | 17 | 12 | 70.6% |
| 06-16 (ISS-074) | 15 | 11 | 73.3% |
| 06-18 (ISS-075) | 15 | 11 | 73.3% |
| **06-20 (ISS-077)** | **24** | **19** | **79.2%** |

**Tistory 분담 4회 연속 70%+ 패턴 확립 + 06-20은 79.2%로 가속**. v1.0.11 권고 1번 (publisher known-issues strip) 의 시급도 상향.

## pair-patch discipline 재확인 (ISS-067/076 9~10번째 재적용)

**`_MASK_TABLE` ↔ `_has_trigger test_patterns` 는 반드시 페어로 갱신**. 한쪽만 patch하면:
- `mask()` 성공 + `is_clean()` False → cron의 `--check` FAIL → 일일 리뷰 job 자체가 실패
- 또는 `mask()` 실패 + `is_clean()` True → next-day self-healer FP 재발

self-healer의 패턴 카테고리가 늘 때마다 두 곳을 **수동 페어 patch** (lint 자동화는 v1.0.20 권고 2번으로 보류).

## 근본 fix (v1.0.21 권장)

1. **다른 Python 예외 클래스 사전 추가** (v1.0.20 권고 1번 + 보강): `KeyError`, `ValueError`, `IndexError`, `ConnectionError`, `PermissionError`, `JSONDecodeError` (ISS-077 fix), `TypeError`, `AttributeError`, `ImportError`, `ModuleNotFoundError`, `ZeroDivisionError` 등 자주 사용되는 예외명도 meta-output에 등장 가능. 보강 권장 🟡 (07-04까지).
2. **`mask_self_healer_terms.py` 의 lint 규칙** — `_MASK_TABLE` 과 `test_patterns` 의 카테고리 커버리지를 자동 검증하는 dev-time check 추가. 우선순위 🟢.
3. **Tistory 분담 줄이기 (v1.0.11 권고 1번) 시급도 상향** — 4회 연속 70%+ → 06-20 79.2% 가속. publisher 출력 후처리에서 known-issues Symptom 노트 strip **시급**.
4. **jobs.json step 12/13/14 patch (ISS-078)** — SKILL.md v1.0.18+14단계는 patch됐지만 jobs.json `5d0f14aef84c` prompt는 step 10까지만 patch된 상태 (v1.0.12 권고 1순위 누락). 1주 이상 미적용된 결과 자기 가드 시스템이 부분 작동. **06-20 일일 리뷰에서 즉시 fix**.

## 18번 진화 타임라인 (ISS-044 → ISS-077)

ISS-044 (APIError) → ISS-058 (MemoryError) → ISS-059/062 (self-trigger meta) → ISS-065 (Python 3.8 PEP 585) → ISS-066 (SKILL.md table leak) → ISS-067 (FileNotFoundError) → ISS-068 (memory threshold) → ISS-069 (jobs.json step 11 drift) → ISS-070 (cumulative leak) → ISS-071 (1-day lag) → ISS-072 (no exit criterion) → ISS-073 (3-stage first verify) → ISS-074 (production verify) → ISS-075 (3rd verify, Tistory 70%+) → ISS-076 (TimeoutError) → **ISS-077 (JSONDecodeError)** → ISS-078 (jobs.json step 12-14 drift) [06-20 동시 발견]

ISS-067 (FileNotFoundError) / ISS-076 (TimeoutError) / ISS-077 (JSONDecodeError) — **3번 연속 Python 예외 클래스명 매핑 누락 패턴**. pair-patch discipline 10번째 재적용.
