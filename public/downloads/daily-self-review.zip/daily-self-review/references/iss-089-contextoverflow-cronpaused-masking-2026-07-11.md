# ISS-089 — ContextOverflow/CronPaused 계열 self-heal 마스킹 누락 (2026-07-11)

## 증상

2026-07-11 일일 리뷰에서 `cron_self_healer.py`를 실행한 뒤 당일 `self_heal_2026-07-11.md`에 새로운 self-trigger 계열이 남았다. 기존 `mask_self_healer_terms.py`는 API/File/Timeout/JSON/Connection/Import 계열만 처리했고, `ContextOverflow`, `PermissionError`, `CronPaused` 및 `paused/disabled/stopped` 계열은 처리하지 못했다.

## 영향

- `mask_self_healer_terms.py --check self_heal_YYYY-MM-DD.md`가 FAIL.
- `verify_self_healer_patch.py --status`가 daily/self-heal 출력의 FP를 감지할 수 있음.
- self-healer가 자기 산출물의 메타 진단을 실제 오류로 재매칭하는 루프가 재발할 수 있다.

## 수정

`skills/automation/daily-self-review/scripts/mask_self_healer_terms.py`에 다음 페어를 추가했다.

1. `_MASK_TABLE`
   - `ContextOverflow` → `context␣size␣issue`
   - `context ... overflow/exceeded`, `token ... limit`, `too long` → `context␣size␣issue`
   - `PermissionError`, `permission denied`, `cannot open`, `access denied` → `permission␣issue`
   - `CronPaused`, `paused`, `disabled`, `stopped` → `cron␣state␣issue`
2. `_has_trigger()` 검증 패턴도 동일하게 추가.
3. `_cli_check()` 디버그 패턴에도 동일 계열을 추가해 다음 누락을 바로 찾게 했다.

## 검증

```bash
python3 -m py_compile ~/.hermes/skills/automation/daily-self-review/scripts/mask_self_healer_terms.py
python3 ~/.hermes/skills/automation/daily-self-review/scripts/mask_self_healer_terms.py --check ~/.hermes/memory/self_heal_2026-07-11.md
```

결과: `self_heal_2026-07-11.md` clean PASS.

## 재발 방지

새로운 `cron_self_healer.py` error pattern을 추가하거나 발견하면 반드시 3곳을 페어 패치한다.

- `_MASK_TABLE`
- `_has_trigger()`
- `_cli_check()`의 디버그 `test_patterns`

특히 replacement 문자열 자체가 기존 패턴에 다시 걸리지 않는지 샘플 `m.is_clean(m.mask(sample))`로 확인한다. 이번 케이스에서 `cron␣paused␣issue`는 `paused`에 다시 걸렸으므로 `cron␣state␣issue`로 변경했다.
