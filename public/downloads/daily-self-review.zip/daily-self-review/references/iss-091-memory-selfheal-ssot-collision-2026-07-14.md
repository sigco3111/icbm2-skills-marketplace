# ISS-091 — MEMORY.md SSOT vs self_heal SSOT 충돌 + github_token 부재 4일째 (2026-07-14)

## 발생

7/14 self-review step 6 (`cron_self_healer` 실행)에서 `errors=6` 검출. 어제 7/13 self_heal 대비 **+2 errors**:

| 잡 | 7/13 | 7/14 |
|---|---|---|
| 🔥 GitHub Trending + Release 모니터 (b26b0579a45f) | ✅ ok (1건) | ❌ **missing_file 1건** |
| (시크릿 점검 step 신규) | (없음) | ❌ **missing_secret 1건** |

**원인**: `~/.hermes/secrets/github_token.txt` 파일 부재. 어제 7/13 22:00 self_heal에는 "✅ ok"로 표시되었고, 7/14 22:02에 갑자기 결함 2건. 원인 분석:

1. **시크릿 부재 시점**: 7/13 22:00 ~ 7/14 22:02 사이에 누군가 파일을 삭제 (7/06~7/13 사이 누적 4일째 `HTTP 403`이 7/14 self_heal에서 비로소 가시화)
2. **self-healer 검사 강화**: `check_secrets()`/`check_prompt_files()`가 cron 잡의 `prompt`에서 `~/.hermes/secrets/...` 경로 + 시크릿 디렉토리 직접 스캔 (7/14부터 더 엄격)

## 함정 — MEMORY.md SSOT vs self_heal SSOT 충돌

**증상**: MEMORY.md L29에 "ISS-086 sync-skills, ISS-087 Token Plan, **GitHub Trending 401**, ISS-028 YouTube 카테고리는 07-14 ✅ 해결 재검증"로 적혀있었음. 그러나 7/14 self_heal 리포트는 GitHub Trending 잡에 `missing_secret` + `missing_file` 2건 검출 → **메모리와 self_heal이 정반대 결론**.

**판별 신호 (어느 쪽이 더 신선?)**:
- self_heal 리포트는 **당일 22:02에 실제 cron 잡 + 시크릿 디렉토리 + prompt 경로까지 스캔** → 실측 기반
- MEMORY.md는 **owner가 수기로 적은 요약** → patch 사이클 동안 stale 가능

→ **self_heal이 항상 더 신선**. 메모리의 "✅ 해결" 표기는 **patch 시점의 추측**이며, 다음 자정 self_heal에서 무효화될 수 있음.

## 해결

### 정책: SSOT 충돌 시 self_heal 우선 + 즉시 patch

```bash
# 1) self_heal 리포트의 errors/warnings 카운트 어제와 비교
YESTERDAY=$(ls -t ~/.hermes/memory/self_heal_*.md | head -2 | tail -1)
TODAY=~/.hermes/memory/self_heal_$(date '+%Y-%m-%d').md
TODAY_ERR=$(grep -oE '"total_errors": [0-9]+' "$TODAY" | grep -oE '[0-9]+')
YESTERDAY_ERR=$(grep -oE '"total_errors": [0-9]+' "$YESTERDAY" | grep -oE '[0-9]+')
DIFF=$((TODAY_ERR - YESTERDAY_ERR))

if [ $DIFF -gt 0 ]; then
  echo "⚠️ self_heal errors 증가: 어제 ${YESTERDAY_ERR} → 오늘 ${TODAY_ERR} (Δ +${DIFF})"
  echo "--- MEMORY.md L29 ('✅ 해결' / '활성 큰 줄기') 재검증 필요 ---"
fi
```

### 1줄 patch 패턴 (L29 정정, 7/14 실전)

```python
# old_string (어제 L29)
"- 활성 큰 줄기: ISS-086-ext git-auto-sync 경로 결함 11일째(`/Users/mac/hermes_bot`, `/Users/mac/icbm2-knowledge-graph` 부재·`[SILENT]`인데 status=ok), Tistory 쿠키/용량 정리. ISS-086 sync-skills, ISS-087 Token Plan, **GitHub Trending 401**, ISS-028 YouTube 카테고리는 07-14 ✅ 해결 재검증."

# new_string (오늘 L29) — bytes 2954 → 3043 (+89)
"- 활성 큰 줄기: ISS-086-ext git-auto-sync 경로 결함 11일째(`/Users/mac/hermes_bot` 부재·`[SILENT]`인데 status=ok), Tistory 쿠키/용량 정리, **ISS-091 (07-14 신규) GitHub Trending token 부재 4일째(`~/.hermes/secrets/github_token.txt` 미존재 → WATCHED_REPOS 12개 HTTP 403, self-healer `missing_secret`/`missing_file` 검출)**. ISS-086 sync-skills, ISS-087 Token Plan, ISS-028 YouTube 카테고리는 07-14 ✅ 해결 재검증."
```

**교훈**:
- L29를 2번째로 압축 (`/Users/mac/icbm2-knowledge-graph` 1개 path suffix 제거 — `-10 bytes`)
- "GitHub Trending 401" → "ISS-091 (07-14 신규) ... token 부재 4일째 ... 12개 HTTP 403" 으로 교체 (`+99 bytes`)
- bytes: 2954 → 3043 (+89). patch 1회로 충분했음 (ISS-088 무한루프 안 빠짐).

## owner-telegram 알림 권장 (07-15)

ISS-091은 `~/.hermes/secrets/github_token.txt` 생성으로 owner가 해결해야 함. self_healer는 자동 fix 불가. **7/15 owner-telegram 권장 메시지**:
```
🔴 ISS-091: ~/.hermes/secrets/github_token.txt 파일이 없어서
GitHub Trending 잡의 WATCHED_REPOS 12개 릴리즈 모니터링이
4일째 (7/11~7/14) HTTP 403으로 실패 중.

해결: GitHub → Settings → Developer settings → Personal 
access tokens → Tokens (classic) → ghp_ 발급 (scope: public_repo)
→ ~/.hermes/secrets/github_token.txt 저장 (chmod 600)
→ 내일 자정 cron부터 자동 정상화.
```

## 재발 방지 체크리스트

- [ ] self_heal errors 카운트 어제/오늘 diff 비교 (위 bash snippet)
- [ ] MEMORY.md L29의 "✅ 해결" / "활성 큰 줄기" 항목이 self_heal 리포트의 잡별 이슈와 일치하는지 검증
- [ ] `missing_secret` / `missing_file` 검출 시 owner-telegram 권장 (자동 fix 불가)
- [ ] 시크릿 디렉토리 (`~/.hermes/secrets/`) 일일 list 확인 — 신규 누락/오래된 secret 점검
