# ISS-097 — Context detector self-quote 오탐과 Markdown code tick 정규화 (2026-08-02)

## 증상

22:06 self-heal dry-run이 실제 monitor `18 ok / 0 critical`과 달리 2개 잡을 실패로 분류했다.

- 일일 자기 개선 리뷰: 최종 응답이 과거 자기 누출을 설명하며 detector label을 인용
- 심야 통합 점검: 위 진단 결과를 다시 요약하며 동일 label을 인용

둘 다 `jobs.json` 상태는 `ok`였고 최신 최종 응답도 정상 종료였다.

## 근본 원인

`cron_self_healer.py`는 마지막 `## Response`만 검사하도록 이미 고쳐졌지만, context-window 패턴은 여전히 넓었다.

```python
r"(?:context.*overflow|context.*exceeded|token.*limit|too long)"
```

ISS-062 메타 라인 필터에 해당 detector의 자기 인용 문구가 없었다. 특히 Markdown code tick 때문에 `출력에서 `label` 감지`가 문자열 marker `출력에서 label 감지`와 일치하지 않았다.

## 수정

1. ISS-089/090 및 context detector 자기 인용 marker를 `meta_markers`에 추가.
2. marker 비교 전에 Markdown code tick을 제거한 `marker_line`을 사용.
3. 실제 예외명과 실행 실패 문장은 그대로 탐지하도록 범위를 제한.

## TDD 검증

### RED

6개 fixture 중 3개 오탐 재현:
- 실제 예외/실행 실패/토큰 한도 초과 3건은 탐지
- 스킬 인용/ISS 회고/자가진단 요약 3건은 잘못 탐지

### GREEN

fixture 6/6 통과 + 실제 최신 output 2개 모두 미탐지, `py_compile` 통과.

### 통합 실측

```text
cron_self_healer.py --dry-run
20 jobs / 18 healthy / 0 errors / 2 warnings / 0 fixes
```

남은 warning 2건은 의도된 상태다.
- 완료된 일회성 outage watch 비활성
- 월요일 첫 실행 예정 weekly queue 미실행

## 교훈

- Prompt/Response 분리만으로 메타 오탐이 끝나지 않는다. **Response가 이전 진단을 인용할 수 있다.**
- Markdown formatting 문자는 의미가 아니므로 메타 marker 비교 전에 정규화한다.
- 진짜 runtime shape를 유지하는 fixture와 실제 최신 output fixture를 함께 검증해야 과도한 quieting을 막는다.
