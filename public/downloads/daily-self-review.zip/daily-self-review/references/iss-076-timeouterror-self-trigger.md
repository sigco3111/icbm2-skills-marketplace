# ISS-076: TimeoutError meta-output self-trigger (2026-06-19)

## 문제

cron_self_healer.py의 TimeoutError 패턴 `r"\b(?:timeout|timed\s*out|deadline\s*exceeded)\b"` 가 자기 진단 보고서의 meta-output 라인:

```
[output_error] 출력에서 TimeoutError 감지 — 패턴 매치: (?:timeout|timed out|deadline exceeded)
```

을 재매칭. 결과적으로 self_heal_YYYY-MM-DD.md에 raw trigger 1건 잔존 → 다음 날 self-healer 재실행 시 FP 감지.

## 증상

2026-06-19 22:00 일일 리뷰 시작 시:
- `verify_self_healer_patch.py --status` → ❌ FAIL: 1/4 jobs have FP
- FP 잡: 🛡️ 심야 통합 점검 (정비+에러)
- FP 위치: `~/.hermes/memory/self_heal_2026-06-19.md`
- FP 패턴: `[output_error] 출력에서 TimeoutError 감지 — 패턴 매치: (?:timeout|...)`

## 즉시 fix (2026-06-19 22:05 적용)

`mask_self_healer_terms.py` 의 두 곳에 3개 패턴 추가 (페어 패치, ISS-067 교훈):

### _MASK_TABLE (mask 함수용)
```python
(r'\bTimeoutError\b', 'timeout\u2423issue'),
(r'\b(?:timed\s*out|deadline\s*exceeded)\b', 'timeout\u2423issue'),
(r'\bconnection\s+timeout\b', 'timeout\u2423issue'),
```

### _has_trigger test_patterns (is_clean 함수용)
```python
r'\bTimeoutError\b',
r'\b(?:timed\s*out|deadline\s*exceeded)\b',
r'\bconnection\s+timeout\b',
```

## 검증 결과

- 시작 verify: ❌ 1/4 FAIL
- step 12 + step 13 + step 10(b) + ISS-076 매핑 패치
- 자기 cron output 06-19 1개 masking 적용 (당일 신규)
- 종료 verify: ✅ 4/4 PASS

## 진화 타임라인 (ISS-044 → ISS-076, 17번 진화)

044 (APIError) → 058 (MemoryError) → 061 (Bearer) → 062 (메타 출력) → 063 (cron prompt) →
065 (Python 3.8) → 066 (SKILL.md 표) → 067 (FileNotFoundError) → 068 (memory 임계치) →
069 (cron prompt v1.0.12 drift) → 070 (누적 backfill) → 071 (1일 lag) →
072 (자수 종료) → 073 (3단계 검증) → 074 (프로덕션 검증) → 075 (Tistory 73.3%) →
**076 (TimeoutError)**.

## 패턴 분석

**"매핑 카테고리 신규 추가" 패턴**: self-healer의 패턴 카테고리가 늘어날 때마다 `_MASK_TABLE`과 `_has_trigger` test_patterns를 **항상 페어로 패치**해야 함. 한쪽만 패치하면:
- `_MASK_TABLE`만 추가 → `mask()`는 성공하지만 `is_clean()`이 False 리턴 → 일일 리뷰 cron의 assert fail 위험
- `_has_trigger`만 추가 → `mask()`가 매칭하지 못해 raw trigger 잔존

ISS-067 (FileNotFoundError)에서 이미 학습된 교훈을 9번째로 실전 적용.

## 자기 가드 안정화 검증 (v1.0.19 4번째)

| 날짜 | ISS | 검증 |
|------|-----|------|
| 06-15 | ISS-073 | 시작 ❌ → 종료 ✅ (1차 설계 검증) |
| 06-16 | ISS-074 | 시작 ❌ → 종료 ✅ (1차 프로덕션 검증) |
| 06-18 | ISS-075 | 시작 ❌ → 종료 ✅ (3번째) |
| **06-19** | **ISS-076** | **시작 ❌ → 종료 ✅ (4번째, TimeoutError 신규 카테고리 추가)** |

**결론**: 자기 가드 시스템이 매번 신규 카테고리도 즉시 흡수하면서 자기 자신을 catch하는 안정적 구조 확립. step 14 종료 검증 패턴 4회 연속 안정.

## 후속 권장

1. **다른 Python 예외 클래스 사전 추가** — `KeyError`, `ValueError`, `IndexError`, `ConnectionError`, `PermissionError` 등 자주 사용되는 예외명도 meta-output에 등장 가능. 보강 권장 🟡
2. **self-healer의 test_patterns 패턴 동기화 자동 lint** — `_MASK_TABLE`과 `_has_trigger test_patterns`가 같은 카테고리 커버하는지 검증하는 CI 규칙 추가 🟢
3. **07-03 (2주 검증 종료)까지 ISS-076 재발 0건 유지 시 안정화 검증 완료**
