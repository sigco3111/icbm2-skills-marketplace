#!/usr/bin/env bash
# diagnose-submodules.sh — automated report for submodule drift
#
# Run inside the parent repo. Prints four sections:
#   1. Index gitlinks vs .gitmodules entries (Mode A detection)
#   2. Submodule status with prefix legend
#   3. Local .git/modules cache inventory
#   4. CI workflow submodule config (if .github/workflows exists)
#
# Exit codes:
#   0 — no inconsistencies detected
#   1 — index/.gitmodules drift detected (Mode A)
#   2 — uninitialized submodules detected (Mode B)
#   3 — both
#
# Usage: bash scripts/diagnose-submodules.sh [repo-path]

set -uo pipefail

REPO="${1:-$(pwd)}"
cd "$REPO" || { echo "Cannot cd to $REPO" >&2; exit 4; }

echo "============================================================"
echo " Submodule diagnostic report — $(basename "$REPO")"
echo " Branch: $(git rev-parse --abbrev-ref HEAD 2>/dev/null || echo '?')"
echo " HEAD:   $(git rev-parse HEAD 2>/dev/null || echo '?')"
echo " Time:   $(date -u +%Y-%m-%dT%H:%M:%SZ)"
echo "============================================================"
echo

EXIT_CODE=0

#------------------------------------------------------------------
# 1. Index gitlinks vs .gitmodules entries
#------------------------------------------------------------------
echo "── 1. Index gitlinks vs .gitmodules entries ──"
echo

# All gitlinks in the parent repo's index (mode 160000)
GITLINKS=$(git ls-files --stage | awk '$1==160000 {print $4}' | sort)

# All paths in .gitmodules
GITMOD_PATHS=$(git config -f .gitmodules --get-regexp '^submodule\.' 2>/dev/null \
                | awk '/\.path$/ {print $2}' | sort -u)

# Drift: in index but not in .gitmodules (Mode A)
echo "Gitlinks missing a .gitmodules entry (FAIL — Mode A):"
DRIFT_A=""
while IFS= read -r p; do
    [ -z "$p" ] && continue
    if ! grep -Fxq "$p" <<< "$GITMOD_PATHS"; then
        echo "  ✗ $p"
        DRIFT_A+="$p"$'\n'
    fi
done <<< "$GITLINKS"
[ -z "$DRIFT_A" ] && echo "  (none)"
echo

# Drift: in .gitmodules but no gitlink in index
echo ".gitmodules entries with no gitlink in index (usually intentional after migration):"
DRIFT_B=""
while IFS= read -r p; do
    [ -z "$p" ] && continue
    if ! grep -Fxq "$p" <<< "$GITLINKS"; then
        echo "  ⚠ $p"
    fi
done <<< "$GITMOD_PATHS"
echo

if [ -n "$DRIFT_A" ]; then
    echo "DIAGNOSIS: at least one Mode A inconsistency — git CI will fail with:"
    echo '  "No url found for submodule path \'<path>\' in .gitmodules"'
    EXIT_CODE=$((EXIT_CODE | 1))
fi
echo

#------------------------------------------------------------------
# 2. Submodule status with prefix legend
#------------------------------------------------------------------
echo "── 2. Submodule status ──"
echo "  prefix legend: ' '=OK  '-'=uninit  '+'=newer-than-checkout  'U'=conflict"
echo
git submodule status 2>&1 | sed 's/^/  /'
echo

UNINIT=$(git submodule status 2>&1 | grep -E '^-' || true)
if [ -n "$UNINIT" ]; then
    echo "DIAGNOSIS: uninitialized submodules detected (Mode B):"
    echo "$UNINIT" | sed 's/^/  /'
    EXIT_CODE=$((EXIT_CODE | 2))
fi
echo

#------------------------------------------------------------------
# 3. Local .git/modules cache
#------------------------------------------------------------------
echo "── 3. Local .git/modules cache ──"
echo
if [ -d .git/modules ]; then
    cd .git/modules && find . -name HEAD 2>/dev/null | sed 's|^\./|  ✓ |; s|/HEAD$||' | sort
    cd - >/dev/null
else
    echo "  (no .git/modules — no submodule ever initialized)"
fi
echo

#------------------------------------------------------------------
# 4. CI workflow submodule config
#------------------------------------------------------------------
echo "── 4. CI workflow submodule config ──"
echo
if [ -d .github/workflows ]; then
    for f in .github/workflows/*.yml .github/workflows/*.yaml; do
        [ -f "$f" ] || continue
        if grep -qE 'submodule|actions/checkout' "$f"; then
            echo "── $f ──"
            grep -nE 'submodule|paths:|fetch-depth' "$f" \
                | grep -vE '^[0-9]+:#' \
                | sed 's/^/  /'
            echo
        fi
    done
else
    echo "  (no .github/workflows — not an Actions repo)"
fi

#------------------------------------------------------------------
# Summary
#------------------------------------------------------------------
echo "============================================================"
echo " SUMMARY"
echo "============================================================"
case $EXIT_CODE in
    0) echo "  ✓ No submodule inconsistencies detected" ;;
    1) echo "  ✗ Mode A: gitlink/.gitmodules drift (CI will fail with exit 128)" ;;
    2) echo "  ✗ Mode B: uninitialized submodules" ;;
    3) echo "  ✗ Both Mode A and Mode B — fix in this order: edit .gitmodules, then 'git submodule update --init'" ;;
    *) echo "  (exit $EXIT_CODE)" ;;
esac
echo
exit "$EXIT_CODE"
