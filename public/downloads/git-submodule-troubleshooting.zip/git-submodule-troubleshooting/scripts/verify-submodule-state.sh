#!/usr/bin/env bash
# verify-submodule-state.sh — pre-push invariant check
#
# Verifies the three invariants from SKILL.md §6 Rule 2:
#   1. Every gitlink in the index has a matching .gitmodules entry
#   2. No submodule is in '-'/uninitialized state
#   3. Spot-check a known file path exists (catches "checked out but empty")
#
# Exit codes:
#   0 — all invariants pass (or no submodules configured)
#   1 — invariant 1 fail (index/.gitmodules drift)
#   2 — invariant 2 fail (uninitialized submodules)
#   3 — invariant 3 fail (spot-check path missing)
#
# Wire as a pre-push hook by symlinking into .git/hooks/pre-push

set -uo pipefail

REPO="${1:-$(pwd)}"
cd "$REPO" || exit 4

EXIT=0

# Skip if there are no submodules at all
if ! git ls-files --stage | grep -qE '^160000'; then
    echo "verify-submodule-state: no submodules, skipping"
    exit 0
fi

echo "verify-submodule-state: checking invariants..."

# Invariant 1: every gitlink has a .gitmodules entry
INCONSISTENT=$(git ls-files --stage | awk '$1==160000 {print $4}' | while read p; do
    if ! git config -f .gitmodules --get "submodule.${p}.url" >/dev/null 2>&1; then
        echo "$p"
    fi
done)

if [ -n "$INCONSISTENT" ]; then
    echo "  ✗ Invariant 1 fail — gitlinks missing .gitmodules entry:"
    echo "$INCONSISTENT" | sed 's/^/      /'
    EXIT=1
else
    echo "  ✓ Invariant 1 — all gitlinks have .gitmodules entries"
fi

# Invariant 2: no uninitialized submodules
UNINIT=$(git submodule status 2>&1 | grep -E '^-' || true)
if [ -n "$UNINIT" ]; then
    echo "  ✗ Invariant 2 fail — uninitialized submodules:"
    echo "$UNINIT" | sed 's/^/      /'
    EXIT=$((EXIT | 2))
else
    echo "  ✓ Invariant 2 — all submodules initialized"
fi

# Invariant 3: spot-check (sample first submodule)
FIRST_SUB=$(git config -f .gitmodules --get-regexp '^submodule\.' 2>/dev/null \
            | awk '/\.path$/ {print $2; exit}')
if [ -n "$FIRST_SUB" ]; then
    FILE_COUNT=$(find "$FIRST_SUB" -type f 2>/dev/null | wc -l | tr -d ' ')
    if [ "${FILE_COUNT:-0}" -lt 1 ]; then
        echo "  ✗ Invariant 3 fail — $FIRST_SUB is empty"
        echo "      Try: git submodule update --init '$FIRST_SUB'"
        EXIT=$((EXIT | 3))
    else
        echo "  ✓ Invariant 3 — $FIRST_SUB has $FILE_COUNT files"
    fi
fi

if [ "$EXIT" -eq 0 ]; then
    echo "verify-submodule-state: all good ✓"
fi
exit "$EXIT"
