# Worked example: game-assets-pool, 2026-07-15 → 2026-07-16

A real failure transcript and how it was diagnosed using the patterns in SKILL.md §3.

## Symptom

GitHub Actions run #29396119504 fails:

> ❌ No url found for submodule path 'curated/3d-resources' in .gitmodules
> ❌ The process 'git' failed with exit code 128

Triggered by push #1: "fix: explicit submodule update step in Pages workflow" at 16:03 KST on 2026-07-15. Builds took ~11 seconds before failing on `actions/checkout@v4`.

## Diagnosis (no fix attempted in this run)

User asked for help with the error; the diagnosis showed the failure had already auto-recovered from a later push.

### Step 1 — inventory the three sources of truth

```bash
cd /Users/mac/work/game-assets-pool

git ls-files --stage | grep 160000
# →
# 160000 0b50467a5c21804bf376d5c5219d18d939a714b8 0  curated/3d-resources
# 160000 ad397dc5122d12f86978cdd69f3ac55cd21f63d7 0  curated/awesome-game-engine-dev
# 160000 11ca1263ef9adb76f3f1f8179c2e7343f6ba2e0c 0  curated/awesome-opensource-unity
# ... (17 more gitlinks)

git config -f .gitmodules --get-regexp '^submodule\.' | grep '\.path'
# →
# submodule.curated/VoxelAssets-mirror.path = curated/VoxelAssets-mirror
# ... (also 20 entries — matched)
```

**Wait — there's no drift in current `.gitmodules`**. The gitlinks have entries. The CI failure was from an *earlier* state.

### Step 2 — check what was pushed at the failure commit

```bash
git log --oneline .gitmodules | head -3
# 73ee209 feat: 큐레이션 카드 ZIP 다운로드 URL 변환 + 노이즈 필터 + UI 분리
# 060b42f fix: complete .gitmodules with 3d-resources and awesome-opensource-unity entries
# ... (older)

git show 060b42f -- .gitmodules | grep -E '^\+\[submodule|^\+\s+url'
# (the fix commit that re-added the three missing entries)
```

The `060b42f` commit was exactly the recipe in SKILL.md §4.1: re-add the entries, commit, push. Pushed at 16:04 KST.

### Step 3 — look at the failing run vs. its triggers

```bash
gh run list --limit 10 -R sigco3111/game-assets-pool
# 29400490892  completed  success  feat: 큐레이션 카드 ZIP 다운로드 ...   46s
# 29399880802  completed  success  fix: filtered() ...                    1m1s
# 29399498211  completed  success  feat: 풀 카드 표시 ...                 48s
# 29399178977  completed  success  fix: GitHub Pages subpath base ...     40s
# 29398631042  completed  success  feat: 카드형 UI (Vercel 디자인) ...    55s
# 29396615922  completed  success  ui: add data-size banner ...           53s
# 29396119504  completed  failure  fix: explicit submodule update step ... 11s  ← THE FAILURE
# 29396032139  completed  success  fix: 14 curation READMEs as submodules 29s
# 29395676349  completed  success  Deploy Pages (Catalog Site)             33s
# 29395603551  completed  success  fix: pagination visibility ...         29s
```

The failed run (#29396119504) sits between two successful runs (#29396615922 at 16:12 and #29396032139 at 16:02). The `ui: add data-size banner` push at 16:12 KST came **after** the fix commit `060b42f` at 16:04 KST, so all subsequent runs operated with `.gitmodules` complete.

But — wait — the success runs after the failure are pushed commits that didn't re-touch `.github/workflows/pages.yml`, the only `paths:` trigger entry that would re-run the workflow. So those "success" runs are misleading: **the workflow simply didn't re-run for those pushes** (the `paths:` filter skipped them).

The next time the workflow *actually* re-ran (#29398631042 at 16:49, from a push that touched the workflow's `paths:`), `.gitmodules` was already correct → success. **That's the silent recovery.**

### Step 4 — confirm: which paths triggered which runs?

```yaml
# .github/workflows/pages.yml
on:
  push:
    branches: [ main ]
    paths:
      - 'site/**'
      - 'metadata/**'
      - '.github/workflows/pages.yml'
```

`site/**` is touched by almost every feature push — that's why the workflow runs frequently. `.gitmodules` is **not** in the list — so a `.gitmodules`-only commit won't trigger a re-run, even when it's a fix.

## Conclusion

User asked: "game-assets-pool action failed"
Diagnosis: failure was from push at 16:03 KST (yesterday morning) where `.gitmodules` was mid-edit. Already auto-recovered by push at 16:04 KST (`060b42f`). All current main builds pass.

User chose: "그대로 두기" (do nothing).

This is the **silently-recovered failure mode** — CI didn't notify anyone of the actual fix because there was no re-trigger, but the next legitimate `paths:`-matching push happened to verify it.

## Lessons captured in SKILL.md

1. **SKILL.md §5.2** — the `paths:` trigger pitfall that causes silent recovery lag.
2. **SKILL.md §3.3** — diagnose the *failing run's commit's* `.gitmodules` state, not the current working tree.
3. **SKILL.md §4.1** — exact repair recipe for Mode A.
4. **`scripts/diagnose-submodules.sh`** — automates the three-true-sources cross-check.

## What the prevention rule would have stopped

`scripts/verify-submodule-state.sh` (SKILL.md §6 Rule 2) would have caught the missing entries *before* the YAML push happened. Wire it as a pre-push hook:

```bash
ln -sf "$(pwd)/scripts/verify-submodule-state.sh" .git/hooks/pre-push
```
