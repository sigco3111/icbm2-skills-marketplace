# CI `paths:` trigger pitfall — why a `.gitmodules`-only fix can fail silently

## The problem

You push a commit that fixes `.gitmodules`. The build stays red. Why?

```yaml
# .github/workflows/pages.yml
on:
  push:
    paths:
      - 'site/**'
      - 'metadata/**'
      - '.github/workflows/pages.yml'
```

`.gitmodules` isn't in the paths. So GitHub Actions **doesn't re-run** for your fix commit. The current failing run (from before the fix) still shows red on the UI. Eventually someone pushes a `site/**` change, which DOES re-run, and the build goes green.

**You appear to have fixed it instantly. Reality: the fix didn't take effect until something else triggered a re-run.**

## Why this matters

The user-visible failure can persist for hours (until the next `site/**` or workflow file commit), even though a fix exists in main. During that window:
- The Actions UI shows red run stuck at top of history
- `gh run list` shows the new green run *lower in the list*
- New contributors see the failing run, assume the repo is broken, waste time

## How to detect

```bash
# Get the SHA the failing run was triggered by
RUN_ID=29396119504
TRIGGER_SHA=$(gh run view "$RUN_ID" --json headSha --jq '.headSha')

# Compare against current main
git log --oneline "$TRIGGER_SHA..origin/main" -- .gitmodules
```

If there's a commit that touches `.gitmodules` between the failing run's trigger and HEAD, the fix exists in main but the workflow didn't re-run.

## Two fixes

### Fix A — include `.gitmodules` in paths (preferred)

```yaml
on:
  push:
    paths:
      - 'site/**'
      - 'metadata/**'
      - '.github/workflows/**'
      - '.gitmodules'           # <-- add this
      - 'curated/**'            # <-- add submodule-related paths
      - 'tools/build-*.py'      # <-- add if build scripts depend on submodules
```

Trade-off: more triggers, more CI minutes. For most projects this is fine.

### Fix B — drop the `paths:` filter

```yaml
on:
  push:
    branches: [ main ]
```

Every push triggers the workflow. Honest but expensive. Fine for low-cost workflows (Pages, MDX rebuild, etc.).

## Operational workaround: `workflow_dispatch`

If you don't want to wait for the next accidental trigger:

```bash
gh workflow run pages.yml -R owner/repo
```

This adds a manually-triggered run that uses the latest main — useful for confirming a fix is live.

## Lesson (game-assets-pool case, 2026-07-15)

The build went red at 16:03 KST, green at 16:49 — that's a **46-minute** silent gap because `.gitmodules` wasn't in `paths:`. The actual fix was a 1-line `git config submodule.curated/3d-resources.url=...` and a 30-character commit message.
