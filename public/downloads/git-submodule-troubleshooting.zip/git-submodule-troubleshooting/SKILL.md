---
name: git-submodule-troubleshooting
description: Class-level skill for diagnosing and repairing git submodule issues — index/.gitmodules mismatch, "No url found" exit 128 in CI, missing .git/modules entries, broken paths, monorepo onboarding, and CI-specific failure modes. Use whenever actions/checkout@v4 fails on `submodule update --init --recursive`, when `git submodule status` shows `-` (uninitialized) prefix, or when a submodule was added/removed but `.gitmodules` was edited without syncing the parent repo's git index.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [git, submodule, CI, GitHub-Actions, troubleshooting, monorepo]
    related_skills: [github-cli, github-actions]
---

# Git Submodule Troubleshooting

Diagnose and repair git submodule problems — they have two sources of truth (the parent repo's git index at mode `160000`, and `.gitmodules`) that can drift apart; CI fails the moment they disagree. This skill is the playbook for that class of failure.

**Sections (jump directly):**

1. [Mental model — when do submodules break?](#1-mental-model)
2. [Five failure modes](#2-five-failure-modes)
3. [Diagnostic workflow](#3-diagnostic-workflow)
4. [Repair recipes](#4-repair-recipes)
5. [CI-specific: Actions submodule checkout failure](#5-ci-specific-actions-submodule-checkout-failure)
6. [Prevention — keep index and .gitmodules in sync](#6-prevention)

---

## 1. Mental model

A submodule entry in the parent repo has **three** pieces of state, all of which must agree:

| Piece | Lives in | What it says |
|---|---|---|
| **Index entry** | parent repo's `.git/index` (mode `160000` = gitlink) | "Path X points at submodule commit SHA Y" |
| **`.gitmodules`** | working tree, tracked file | "Path X is a submodule, fetch from URL Z" |
| **`.git/modules/<path>`** | parent repo's local git dir | Cached clone of the submodule's own `.git` (so subsequent fetches are incremental) |

**A submodule works iff** all three agree AND the working tree at `<path>/` is checked out at the recorded SHA. If any one of them is stale or missing, `git submodule update --init --recursive` fails or leaves `<path>/` empty.

**Why this matters in CI (especially Actions):**

`actions/checkout@v4` defaults to `submodules: false`. To get submodule content in CI, you must set `submodules: 'recursive'` (or `'true'`). Behind the scenes it runs `git submodule update --init --depth 1 --recursive`, which **requires URL from `.gitmodules`** for every gitlink in the index. A gitlink without a matching `.gitmodules` entry → exit 128 with the message `No url found for submodule path '<path>' in .gitmodules`.

**Common drift causes:**

- Someone deleted `.gitmodules` entries to "tidy up" without `git rm`-ing the corresponding paths from the index
- Someone edited `.gitmodules` URLs in a way that left the index's gitlinks referencing old paths
- A `.gitmodules.bak` backup file exists in the working tree (never commit `.bak` — it confuses diff reading but doesn't actually break things, the danger is when the diff is captured against the *backup* state)
- A repo was force-pushed or rebased and submodule refs were lost in the rewrite

---

## 2. Five failure modes

| # | Symptom | Root cause | Quick check |
|---|---|---|---|
| **A** | `No url found for submodule path '<path>' in .gitmodules` (exit 128 in CI) | Gitlink exists in index, but `.gitmodules` has no entry for that path | `git ls-files --stage \| grep 160000` vs `git config -f .gitmodules --list` |
| **B** | `-<sha> <path>` in `git submodule status` (minus prefix = uninitialized) | `.git/modules/<path>` is missing — clone half done | `ls .git/modules/<path>/HEAD 2>/dev/null` |
| **C** | Directory `<path>/` exists locally but submodule commands error | Submodule registered in index, but working tree not a gitlink-aware checkout | `git submodule status <path>` |
| **D** | CI succeeds but local clone leaves `<path>/` empty | Local host's `.git/config` has wrong `submodule.<path>.url` (typo, old fork, scheme mismatch) | `git config --get submodule.<path>.url` |
| **E** | "Please make sure you have the correct access rights" in submodule clone | URL in `.gitmodules` is wrong, repo is private, or auth scope missing | Try `git clone <url>` directly to isolate |

**Most common in practice: A + B combo** — gitlink present, URL missing, working tree has stale files from a prior partial state.

---

## 3. Diagnostic workflow

Run these in order; stop when you've localized the failure.

### 3.1 Inventory the three sources of truth

```bash
cd /path/to/repo

# (1) Index: what paths does the parent repo treat as submodules, and at what SHA?
git ls-files --stage | awk '$1==160000 {print}' 

# (2) .gitmodules: what does the parent repo claim about URLs and paths?
git config -f .gitmodules --list | grep '^submodule\.'

# (3) Local cache: which submodules does this clone already have a .git dir for?
ls .git/modules/ 2>/dev/null   # for non-recursive; or:
git submodule foreach --quiet 'echo "$name -> $sm_path -> $(git rev-parse HEAD)"'
```

**Cross-check:** for every `160000 <sha> <path>` in (1), there must be a matching `submodule.<path>.url=` in (2). If not, you have failure mode **A**.

### 3.2 Status of each submodule

```bash
git submodule status
```

Output format: `<prefix><sha> <path> [(reason)]` where prefix is:

| Prefix | Meaning |
|---|---|
| (space) | OK — checked out at `<sha>` |
| `-` | Not initialized (no `.git/modules/<path>`) |
| `+` | Different SHA than expected (index moved on; you haven't updated) |
| `U` | Unmerged conflicts |

`-` prefix = failure mode **B**. `+` prefix = someone updated the index without you pulling. `U` = half-completed merge, finish it with `git submodule update --recursive`.

### 3.3 Read the failing CI log

Look for the *exact* error string:

| Error | Mode |
|---|---|
| `No url found for submodule path '<path>' in .gitmodules` | A |
| `fatal: unable to access '<path>/.git'`: remote hung up unexpectedly | E |
| `fatal: clone of '<url>' into submodule path '<path>' failed` | D or E |
| `Submodule '<path>' (<url>) registered for path '<path>' but .gitmodules has no entry` | A (mirror variant) |
| `fatal: refusing to fetch into current branch refs/heads/<x>` (rare, post force-push) | rebuild required |

### 3.4 Inspect the workflow file

If CI fails:

```bash
cat .github/workflows/*.yml | grep -A 5 -B 1 "submodule"
```

Common bugs:
- `actions/checkout@v4` without `submodules:` key → default is **NOT recursive** (it's `false`). Must explicitly set `submodules: recursive`.
- A separate `git submodule update --init --depth 1 --recursive` step that conflicts with checkout's behavior.
- `paths:` trigger that excludes `.gitmodules` → fixes to that file don't re-run the workflow, masking failures.

### 3.5 Capture state for handoff

Before fixing, snapshot so the user sees what changed:

```bash
git diff HEAD -- .gitmodules
git submodule status > /tmp/submodule-status.txt
```

The verification script `scripts/diagnose-submodules.sh` automates 3.1–3.3 and prints a single report.

---

## 4. Repair recipes

### 4.1 Mode A — gitlink in index, no `.gitmodules` entry

**Symptom:** `git ls-files --stage | grep 160000` shows the path, `.gitmodules` doesn't.

**Fix:** re-add the entry to `.gitmodules`:

```bash
git config -f .gitmodules submodule.<path>.path <path>
git config -f .gitmodules submodule.<path>.url <url>
git add .gitmodules
git commit -m "fix: complete .gitmodules with <path> entry"
```

If the entry used to exist and was removed by accident, check `git log -p --all -- .gitmodules | grep -A 4 '<path>'` for the old URL.

### 4.2 Mode B — `.git/modules/<path>` missing (uninitialized)

**Fix:** initialize without re-cloning if possible (saves bandwidth):

```bash
git submodule update --init <path>            # single path
git submodule update --init --recursive       # all
```

If `--init` fails on a single path with `error: Server does not allow request for unadvertised object <sha>`: the index references an SHA not in the remote's history → either the remote URL is wrong (mode D) or the index SHA is wrong (someone force-pushed). Try `git ls-remote <url>` and confirm the expected SHA exists; if not, pick a valid SHA from upstream and `git update-index --add --cacheinfo 160000,<new-sha>,<path>`.

### 4.3 Mode C — directory exists but isn't a submodule checkout

**Fix:** unregister from index, re-initialize:

```bash
git rm --cached <path>
git submodule add --force <url> <path>
```

Never `git rm` an active submodule with pending changes — it'll wipe them.

### 4.4 Mode D — wrong URL in `.gitmodules`

```bash
# Fix in .gitmodules
git config -f .gitmodules submodule.<path>.url <correct-url>
# Sync to .git/config so subsequent fetches don't keep using the old URL
git config submodule.<path>.url <correct-url>
git submodule sync <path>
git submodule update --init <path>
```

`submodule sync` is mandatory — without it, the local clone's `.git/config` keeps pointing at the wrong URL even after you fix `.gitmodules`.

### 4.5 Mode E — auth/access issue

For private submodule repos, the CI workflow needs an SSH key or PAT that has read access **to both** the parent and the submodule. Add to the workflow:

```yaml
- uses: actions/checkout@v4
  with:
    submodules: 'recursive'
    ssh-key: ${{ secrets.SUBMODULE_DEPLOY_KEY }}
    # OR for HTTPS: token via .gitconfig
```

For HTTPS, the submodule URL must embed the token (e.g. `https://x-access-token:${{ secrets.GH_TOKEN }}@github.com/owner/repo.git`) OR you set `git config --global url.https://x-access-token:${{ secrets.GH_TOKEN }}@github.com/.insteadOf https://github.com/` before the `submodule update` step.

### 4.6 Nuclear option — full reset

If the local clone's submodule state is unrecognizably broken:

```bash
git submodule deinit --all -f
rm -rf .git/modules/
git checkout HEAD -- .gitmodules    # restore tracked state
git submodule update --init --recursive
```

This is destructive (wipes any uncommitted submodule changes). Always warn the user before running it.

---

## 5. CI-specific: Actions submodule checkout failure

### 5.1 The standard pattern that works

```yaml
- uses: actions/checkout@v4
  with:
    submodules: 'recursive'
    fetch-depth: 1

- name: Init and update submodules (explicit)
  run: git submodule update --init --depth 1 --recursive
```

Note: `actions/checkout@v4` with `submodules: true` *does* run `update --init` itself. Adding the separate step is belt-and-suspenders for when checkout's defaults change.

### 5.2 Why a fix can seem "not to take"

If your workflow has:

```yaml
on:
  push:
    paths: ['site/**', 'metadata/**', '.github/workflows/pages.yml']
```

…and you push only `.gitmodules`, the workflow **won't re-run**. That's how a real failure can persist silently until the next `.github/workflows` change forces a re-run. Always add `.gitmodules` and `.gitmodules`'s parent paths to `paths:` for submod-heavy repos, OR drop the `paths:` filter entirely.

### 5.3 Pages-style workflows that read submodule files

Examples: static site generators reading the submodule as content (game-assets-pool's `tools/build-index.py` reading `curated/*/README.md`).

Pitfall: a submodule must be **populated** for these scripts to find content. Workflow must:
1. `actions/checkout@v4` with `submodules: 'recursive'` ✓
2. Explicit `git submodule update --init --depth 1 --recursive` step ✓
3. Optional `for d in <path-prefix>/*/; do test -f "$d/README.md" && ...; done` verification step that **fails the job** if any submodule is empty (rather than silently building with broken data).

### 5.4 Quick recovery when CI is down

If you don't have time to fix `.gitmodules` and just need the build green again:

```yaml
- uses: actions/checkout@v4
  with:
    submodules: false   # only the parent repo, skip submodules

- name: Build with empty submodule stubs
  run: |
    for d in <prefix>/*/; do
      mkdir -p "$d"
      [ -f "$d/README.md" ] || echo "# Placeholder" > "$d/README.md"
    done
```

This is a **workaround, not a fix**. The CI is no longer building real submodule content; either the data is missing or stale. Get the proper submodule checkout working before long.

---

## 6. Prevention

The single most common cause is editing `.gitmodules` URLs/entries without syncing the index. Two rules prevent it:

**Rule 1 — never hand-edit `.gitmodules`.** Use `git submodule add` / `git submodule deinit` to register changes; git will keep the index in sync.

```bash
# To add a new submodule:
git submodule add <url> <path>

# To remove one:
git submodule deinit -f <path>
git rm -f <path>
# (git rm automatically removes the gitlink from .git/index AND the
#  working tree entry — that's what `git rm --cached` does NOT do for
#  gitlinks; you need regular `git rm` for submodule paths.)
```

**Rule 2 — after any `.gitmodules` edit, verify three invariants:**

```bash
# (1) Every gitlink in the index has a matching .gitmodules entry
git ls-files --stage | awk '$1==160000 {print $4}' | while read p; do
  if ! git config -f .gitmodules --get "submodule.${p}.url" >/dev/null 2>&1; then
    echo "MISSING .gitmodules entry for: $p"
  fi
done

# (2) Status prefix is space, not '-'
git submodule status | grep -E '^-' && echo "FAIL: some submodules uninitialized" || echo "OK"

# (3) CI fails are visible: pick a path and confirm it has files
test -f "<some-known-file>" || echo "FAIL: <path> empty after checkout"
```

The verification script `scripts/verify-submodule-state.sh` runs these as a pre-push hook candidate.

### Companion rule for CI workflows

For repos with `paths:` triggers, explicitly include any submodule-relevant tracked files:

```yaml
on:
  push:
    paths:
      - '.gitmodules'
      - 'curated/**'
      - 'site/**'
      - '.github/workflows/**'
```

---

## Reference files

- `references/index-vs-gitmodules-drift.md` — worked example of the 2026-07-15 game-assets-pool failure with full transcript
- `references/ci-triggers-and-paths-pitfall.md` — why a `.gitmodules`-only push can fail silently to retrigger CI
- `scripts/diagnose-submodules.sh` — automated §3.1–3.3 diagnostic report
- `scripts/verify-submodule-state.sh` — pre-push style invariant check (§6, Rule 2)

## Quick reference table

| Symptom | Mode | Recipe |
|---|---|---|
| "No url found for submodule path '<path>' in .gitmodules" | A | §4.1 |
| `git submodule status` shows `-` prefix | B | §4.2 |
| Directory exists but `git submodule update` errors | C | §4.3 |
| Local clone leaves `<path>/` empty | D | §4.4 |
| "Permission denied" / "could not read Username" | E | §4.5 |
| Total mess, need clean slate | — | §4.6 |
| CI silently broken after `.gitmodules` push | paths trigger | §5.2 |
