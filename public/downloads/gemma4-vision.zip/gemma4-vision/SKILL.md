---
name: gemma4-vision
description: "이미지 분석 스킬 — OpenRouter 경유 비전 모델로 이미지를 분석 (기존: 카글 Gemma 4 서버)"
tags: [vision, openrouter, multimodal, image-analysis, deprecated-kaggle]
---

# 이미지 분석 (OpenRouter 비전)

> ⚠️ **2026-04-16 변경:** 카글 Gemma 4 서버 종속성 제거. 이제 OpenRouter (google/gemini-3-flash-preview)를 통해 이미지를 분석합니다.

## 현재 방식

ICBM2의 `vision_analyze` 툴이 자동으로 OpenRouter 비전 모델을 사용합니다.

- **프로바이더:** OpenRouter
- **모델:** google/gemini-3-flash-preview
- **설정:** `~/.hermes/config.yaml` → `auxiliary.vision.provider: openrouter`

## 사용 방법

### 1. 텔레그램 이미지 분석
- 텔레그램으로 이미지를 직접 보내면 자동으로 분석
- 또는 이미지와 함께 "이거 분석해줘" 전송

### 2. vision_analyze 툴 직접 사용
```
vision_analyze(image_url="/path/to/image.jpg", question="이미지 설명해줘")
```

## 레거시: 카글 Gemma 4 서버 (사용 중단)

기존에는 카글 T4 x2 GPU에서 Gemma 4 26B A4B-it을 구동했으나, 아래 이유로 사용 중단:
- 카글 세션 40분 유휴 타임아웃 → 서버 자동 종료
- 주간 GPU 30시간 제한 → 상시 서버 유지 불가
- ICBM2가 서버를 원격 재시작할 수 없음

### 레거시 스크립트 (참고용)
- `~/.hermes/scripts/kaggle_account2_gemma4_final.py` — 카글 노트북 레시피
- `~/.hermes/scripts/kaggle_account2_gemma4_multimodal.py` — 대체 레시피
- `~/.hermes/scripts/gemma-4-26b-a4b-it-gguf.ipynb` — Jupyter 노트북
