---
name: gemma4-vision
description: "카글 Gemma 4 26B 서버를 경유하여 이미지를 분석하는 스킬 — 텔레그램 이미지를 Gemma 4 비전 모델로 전송하여 상세 분석"
tags: [vision, gemma4, kaggle, multimodal, image-analysis]
---

# Gemma 4 Vision (카글 서버 경유)

카글에서 구동 중인 Gemma 4 26B A4B-it 서버의 비전 엔드포인트를 사용하여 이미지를 분석합니다.

## 전제 조건

- 카글 Gemma 4 서버가 실행 중이어야 함 (`~/.hermes/scripts/kaggle_account2_gemma4_final.py`)
- ngrok URL 확인 필요 (서버 시작 시 출력됨)

## 서버 URL 설정

ngrok URL은 세션마다 바뀝니다. 카글 서버 시작 후:

1. 카글 노트북 출력에서 `🔗 API 서버: https://xxx.ngrok-free.dev` 확인
2. 아래 명령어로 URL을 등록:
   ```
   gemma4 서버주소 https://xxx.ngrok-free.dev
   ```
3. 또는 환경변수 `GEMMA4_URL`에 설정

## 사용 방법

### 1. 이미지 URL 분석
```
gemma4 분석해줘 https://example.com/image.jpg
```

### 2. 텔레그램 이미지 분석
- 텔레그램으로 이미지를 직접 보내면 자동으로 감지
- 또는 이미지와 함께 "이거 분석해줘" 전송

### 3. 프롬프트 커스텀
```
gemma4 이 이미지에서 텍스트를 읽어줘
```
(이미지와 함께 전송 시)

## API 엔드포인트

| 엔드포인트 | 메서드 | 설명 |
|---|---|---|
| `/` | GET | 서버 상태 확인 |
| `/chat` | POST | 텍스트 채팅 |
| `/vision` | POST | 이미지 분석 |

## /vision 요청 형식

```json
{
  "image_url": "https://example.com/image.jpg",
  "prompt": "이 이미지를 설명해줘.",
  "max_tokens": 512
}
```

## 이미지 처리 플로우

1. 텔레그램에서 이미지 수신 → 로컬에 임시 저장
2. litterbox.catbox.moe에 업로드하여 공개 URL 획득 (1시간 유효)
3. Gemma 4 서버 `/vision` 엔드포인트에 URL 전송
4. 분석 결과 반환

※ 0x0.st는 스팸 문제로 업로드 중단됨. transfer.sh는 타임아웃. litterbox 사용.

## 스크립트

참고: `~/.hermes/scripts/gemma4_vision_client.py`

## 카글 Gemma 4 구동 핵심 팁

- `local_dir="/kaggle/working"` + `local_dir_use_symlinks=False` — 디스크 터짐 방지
- `tensor_split=[1, 1]` — T4 듀얼 GPU 분산 로드
- `n_ctx=2048` — 메모리 확보 (모델 전체 컨텍스트는 262144)
- Base64 인코딩 + User-Agent 헤더로 이미지 다운로드 403 우회
- mmproj 로드 시 `Llava15ChatHandler(clip_model_path=mmproj_path)` 사용
- llama-cpp-python은 cu121 pre-built wheel 사용 (`--extra-index-url https://abetlen.github.io/llama-cpp-python/whl/cu121`)
- 성공한 노트북: `~/.hermes/scripts/gemma-4-26b-a4b-it-gguf.ipynb`

## OpenCode 연동 (계획)

- Claude Code는 커스텀 엔드포인트 불가 ❌
- OpenCode는 OpenAI 호환 API 지원 → llama-cpp-python 내장 `create_app` 사용하면 `/v1/chat/completions` 자동 생성 ✅
- ngrok 무료 URL은 세션마다 변경 → 설정 매번 업데이트 필요

## 주의사항

- ngrok 무료 URL은 세션마다 변경됨 — 서버 재시작 시 URL 재등록 필요
- 카글 GPU 세션이 끊기면 서버도 종료됨 (주 30시간 제한)
- 이미지 업로드에는 litterbox.catbox.moe 사용 (1h/12h/24h/72h 유효)
- 타임아웃: 이미지 분석은 최대 60초
- 0x0.st는 스팸 문제로 업로드 중단됨, transfer.sh는 타임아웃 발생
