"""
Gemma 4 Vision Client — 카글 서버 경유 이미지 분석
=================================================
텔레그램에서 받은 이미지를 Gemma 4 서버로 전송하여 분석

사용법:
  python gemma4_vision_client.py --url https://xxx.ngrok-free.dev --image /path/to/image.jpg
  python gemma4_vision_client.py --url https://xxx.ngrok-free.dev --image-url https://example.com/img.jpg
"""

import requests
import sys
import os
import time

# 서버 URL (환경변수 또는 직접 입력)
GEMMA4_URL = os.environ.get("GEMMA4_URL", "")


def check_server(url: str) -> bool:
    """서버 상태 확인"""
    try:
        r = requests.get(f"{url}/", timeout=10)
        return r.status_code == 200
    except:
        return False


def upload_to_litterbox(image_path: str, expire: str = "1h") -> str:
    """로컬 이미지를 litterbox.catbox.moe에 업로드하여 공개 URL 획득
    expire: 1h, 12h, 24h, 72h
    """
    try:
        with open(image_path, "rb") as f:
            r = requests.post(
                "https://litterbox.catbox.moe/resources/internals/api.php",
                data={"reqtype": "fileupload", "time": expire},
                files={"fileToUpload": (os.path.basename(image_path), f)},
                timeout=30
            )
        r.raise_for_status()
        url = r.text.strip()
        if not url.startswith("http"):
            raise RuntimeError(f"Unexpected response: {url}")
        return url
    except Exception as e:
        raise RuntimeError(f"이미지 업로드 실패: {e}")


def analyze_image(server_url: str, image_url: str, prompt: str = "이 이미지를 한국어로 상세히 설명해줘.", max_tokens: int = 512) -> dict:
    """Gemma 4 서버에 이미지 분석 요청"""
    r = requests.post(
        f"{server_url}/vision",
        json={
            "image_url": image_url,
            "prompt": prompt,
            "max_tokens": max_tokens
        },
        timeout=60
    )
    r.raise_for_status()
    return r.json()


def analyze_local_image(server_url: str, image_path: str, prompt: str = "이 이미지를 한국어로 상세히 설명해줘.") -> dict:
    """로컬 이미지 → 업로드 → 분석"""
    print(f"📤 이미지 업로드 중...")
    image_url = upload_to_litterbox(image_path)
    print(f"✅ 업로드 완료: {image_url}")
    return analyze_image(server_url, image_url, prompt)


def chat_text(server_url: str, prompt: str, max_tokens: int = 512) -> dict:
    """텍스트 채팅"""
    r = requests.post(
        f"{server_url}/chat",
        json={"prompt": prompt, "max_tokens": max_tokens},
        timeout=60
    )
    r.raise_for_status()
    return r.json()


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--url", required=True, help="Gemma 4 서버 URL")
    parser.add_argument("--image", help="로컬 이미지 경로")
    parser.add_argument("--image-url", help="이미지 URL")
    parser.add_argument("--prompt", default="이 이미지를 한국어로 상세히 설명해줘.")
    parser.add_argument("--chat", help="텍스트 채팅 모드")
    args = parser.parse_args()

    if not check_server(args.url):
        print(f"❌ 서버에 연결할 수 없습니다: {args.url}")
        sys.exit(1)

    print(f"✅ 서버 연결 성공: {args.url}")

    if args.chat:
        result = chat_text(args.url, args.chat)
        print(f"\n💬 {result['response']}")
    elif args.image:
        result = analyze_local_image(args.url, args.image, args.prompt)
        print(f"\n🖼️ {result['response']}")
    elif args.image_url:
        result = analyze_image(args.url, args.image_url, args.prompt)
        print(f"\n🖼️ {result['response']}")
    else:
        print("사용법: --image, --image-url, 또는 --chat 중 하나를 지정하세요")
