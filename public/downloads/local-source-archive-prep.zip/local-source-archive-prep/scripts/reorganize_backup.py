#!/usr/bin/env python3
"""
Reorganize a local backup/source folder into GitHub-ready buckets.

Validated against /Users/mac/work/backup (2026-07-31):
  - 26 GB, 134 k files, 4 output buckets, 1349 empty folders pruned, zero data loss.

Usage:
  python3 reorganize_backup.py --root /path/to/backup --dry-run
  python3 reorganize_backup.py --root /path/to/backup           # actual move

The defaults below are the validated scheme; pass --config <json> to override.
"""
from __future__ import annotations

import argparse
import json
import shutil
from dataclasses import dataclass, field
from pathlib import Path


# ---------------------------------------------------------------------------
# Default triage rules — edit here or pass --config
# ---------------------------------------------------------------------------
DEFAULT_CONFIG = {
    "public_top_level": [
        # folder names (or relative paths) that go to 01-public
    ],
    "private_subcategories": {
        "01-회사-외주-자료": [
            "기획",
            "업무참고 자료",
            "비밀스런자료_에헷~♡",
            "더욱_비밀스런자료_에헷~♡",
            "제안서",
            "모바일개발관련",
            "이스트빌_작업",
        ],
        "02-개인-문서-경력": [
            "이력서",
            "asdf.txt",
            "경력사항.txt",
        ],
        "03-SDK-기술문서-엔진": [
            "NDS_SDK",
            "NDS 교육자료",
            "도움말모음",
        ],
        "04-원본-소스-에셋-백업": [
            "NDS_Work",
            "Mobile_Work",
            "GameSound",
            "문서화작업",
        ],
    },
    "review_required_folder_names": [
        "Being_not_open_to_the_public",
        "비밀",
        "Secret",
        "Do_not_share",
    ],
    "protected_roots": [
        "00-inbox",
        "01-public",
        "02-private",
        "99-archive",
        ".omo",
        ".codegraph",
        # User-named "!..." prefixes go in here too if you want them kept
        # even when their own contents are emptied.
        "!개발관련자료",
        "!모바일개발관련",
        "!이스트빌_작업",
    ],
    "hermes_runtime": [".omo", ".codegraph"],
    "build_exclude_globs": [
        ".DS_Store", ".git", ".svn", "Thumbs.db",
        "*.ncb", "*.suo", "*.user", "*.opt", "*.plg", "*.positions",
        "*.pdb", "*.idb", "*.obj", "*.pch", "*.sbr", "*.bsc", "*.res",
        "*.tlog", "*.lastbuildstate", "BuildLog.htm",
        "Debug", "Release", "build", "dist", "bin", "obj",
        "DerivedData", "xcuserdata", "*.xcuserstate",
    ],
}


@dataclass
class Report:
    moved: list[tuple[str, str]] = field(default_factory=list)
    deleted_empty: list[str] = field(default_factory=list)
    skipped_protected: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _matches_any(name: str, patterns: list[str]) -> bool:
    from fnmatch import fnmatch
    return any(fnmatch(name, p) for p in patterns)


def _is_safe_move_target(src: Path, dst: Path) -> bool:
    """Ensure moving src -> dst won't recurse into itself."""
    try:
        return dst.resolve().is_relative_to(src.resolve()) is False
    except AttributeError:  # py<3.9 fallback
        return str(dst.resolve()).startswith(str(src.resolve()) + "/") is False


def _bucket_for(name: str, cfg: dict) -> str:
    if name in cfg["public_top_level"]:
        return "01-public"
    for token in cfg["review_required_folder_names"]:
        if token in name:
            return "00-inbox/review-required"
    # else private — caller decides sub-category
    return "02-private"


def _private_subbucket(name: str, cfg: dict) -> str | None:
    for subcat, names in cfg["private_subcategories"].items():
        if name in names:
            return f"02-private/{subcat}"
    return None


# ---------------------------------------------------------------------------
# Phases
# ---------------------------------------------------------------------------

def phase1_inventory(root: Path) -> dict:
    total_files = sum(1 for _ in root.rglob("*") if _.is_file())
    total_dirs = sum(1 for _ in root.rglob("*") if _.is_dir())
    return {
        "total_files": total_files,
        "total_dirs": total_dirs,
        "top_level": sorted(p.name for p in root.iterdir()),
    }


def phase5_exclude(root: Path, archive: Path, cfg: dict, dry_run: bool, report: Report) -> None:
    """Move system/build metadata into 99-archive."""
    if not archive.exists() and not dry_run:
        archive.mkdir()
    patterns = cfg["build_exclude_globs"]
    for p in root.rglob("*"):
        rel = p.relative_to(root)
        if p.is_file() and _matches_any(p.name, patterns):
            dst = archive / rel
            if not dry_run:
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.move(str(p), str(dst))
            report.moved.append((str(p), str(dst)))


def phase6_7_reorganize(root: Path, cfg: dict, dry_run: bool, report: Report) -> None:
    """Move top-level items into their bucket + private subcategory."""
    protected = set(cfg["protected_roots"])
    for p in sorted(root.iterdir()):
        if p.name in protected:
            report.skipped_protected.append(p.name)
            continue

        bucket = _bucket_for(p.name, cfg)
        if bucket == "02-private":
            sub = _private_subbucket(p.name, cfg)
            dst = root / sub / p.name if sub else root / "02-private" / p.name
        else:
            dst = root / bucket / p.name

        if not _is_safe_move_target(p, dst):
            report.errors.append(f"Unsafe move target: {p} -> {dst}")
            continue

        if not dry_run:
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(p), str(dst))
        report.moved.append((str(p), str(dst)))


def phase8_remove_empty(root: Path, cfg: dict, dry_run: bool, report: Report) -> None:
    """Deepest-first sweep — leaves go first, then newly-empty parents."""
    protected = set(cfg["protected_roots"])
    # depth-descending: more path parts = deeper
    for d in sorted(root.rglob("*"), key=lambda p: -len(p.parts)):
        if not d.is_dir() or any(d.iterdir()):
            continue
        if d.parent == root and d.name in protected:
            report.skipped_protected.append(d.name)
            continue
        if not dry_run:
            d.rmdir()
        report.deleted_empty.append(str(d))


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--root", required=True, type=Path, help="Backup folder root")
    ap.add_argument("--config", type=Path, help="Optional JSON config override")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    cfg = DEFAULT_CONFIG
    if args.config and args.config.exists():
        cfg = json.loads(args.config.read_text())

    if not args.root.exists():
        raise SystemExit(f"Root not found: {args.root}")

    print("=== Phase 1: inventory ===")
    inv = phase1_inventory(args.root)
    print(json.dumps(inv, indent=2))

    print("\n=== Phase 5: build/system metadata -> 99-archive ===")
    report = Report()
    phase5_exclude(args.root, args.root / "99-archive", cfg, args.dry_run, report)

    print("\n=== Phase 6+7: top-level -> buckets + private sub-categories ===")
    phase6_7_reorganize(args.root, cfg, args.dry_run, report)

    print("\n=== Phase 8: empty-folder sweep ===")
    phase8_remove_empty(args.root, cfg, args.dry_run, report)

    print("\n=== Report ===")
    print(f"moved: {len(report.moved)}")
    print(f"deleted_empty: {len(report.deleted_empty)}")
    print(f"skipped_protected: {report.skipped_protected}")
    if report.errors:
        print("ERRORS:")
        for e in report.errors:
            print(" -", e)


if __name__ == "__main__":
    main()