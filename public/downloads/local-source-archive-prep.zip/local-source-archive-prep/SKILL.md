---
name: local-source-archive-prep
description: "로컬 백업 폴더를 깃허브 공개/비공개용 버킷으로 재구성."
last_updated: 2026-07-31
status: validated
---

# Local Source Archive → GitHub Publication Prep

Reorganize a messy local backup/source folder into GitHub-ready buckets without losing content. This is **organization only** — actual GitHub repo creation, README authoring, and `gh repo create` are downstream tasks handled by `github-repo-management`.

The session that validated this workflow processed ~26GB across ~134k files in `/Users/mac/work/backup` and produced 4 output buckets with zero data loss.

---

## When to Use

- User has a local backup folder with mixed public/private/review-required material
- User wants GitHub publication but the source tree has duplicates, build artifacts, system metadata, and nested empty folders
- User wants to move (not copy) — actual folder rename/restructure
- The job stops at "ready to push" — README, license, `.gitignore`, `gh repo create` come next

Do NOT use when:
- Source is a clean fresh project → `python-oss-bootstrap` or `oss-fork-localization`
- Source is a forked repo needing localization → `oss-fork-localization`
- User only wants a Next.js navigation page over existing repos → `github-portfolio-planner`

---

## Workflow (7 Phases)

### Phase 1. Inventory BEFORE moving anything

Before relocating a single file:

1. Confirm path exists (`os.path.exists`)
2. Walk `rglob('*')` once to count files, dirs, total bytes (`du -sh`)
3. Identify protected roots that must NEVER be moved:
   - Hermes runtime: `.omo/`, `.codegraph/`
   - User-named top-level dirs the user explicitly preserves (often `!`-prefixed or starting with capitals)
   - Any hidden service folder the user mentions

**Pitfall:** A user may say "these three folders are all empty" but they're not — they may have *nested* empty folders plus content. Always verify with `p.exists() and not any(p.iterdir())` AND a deep scan (`rglob`).

### Phase 2. Triage matrix

Classify each top-level item into exactly one bucket:

| Bucket | Definition | Typical contents |
|---|---|---|
| `01-public` | User confirmed OK to publish | Self-authored portfolio projects, samples, public docs |
| `02-private` | User confirmed NOT to publish | Company/외주 work, personal documents, SDKs, original assets |
| `00-inbox/review-required` | Folder name signals private OR ambiguous origin | Anything literally named `Being_not_open_to_the_public`, `비밀`, `Secret`, `Do_not_share`, contracts |
| `99-archive` | System metadata / duplicates / leftover stubs | `.DS_Store`, `.git`, `.svn`, build outputs with no source |

The folder-name test beats location: a project inside a `포트폴리오/` parent is still review-required if its own name contains `not_open`, `비밀`, `private`, `secret`.

### Phase 3. Sub-classify non-portfolio private folders

`02-private` should be subdivided by domain. The validated scheme:

- `01-회사-외주-자료/` — 통신사 디바이스 게임, 계약/제안/런칭, 회사 작업 폴더
- `02-개인-문서-경력/` — 이력서, 경력사항, 자기소개, 메모 txt
- `03-SDK-기술문서-엔진/` — NitroSDK, 3D_Study, 도움말모음 등 외부 SDK 번들
- `04-원본-소스-에셋-백업/` — NDS_Work, Mobile_Work, GameSound, 기획 원본 에셋

Sub-class names with leading numbers (`01-`, `02-`, ...) keep them sorted by importance.

### Phase 4. Resolve duplicate copies BEFORE moving

When the same project appears in multiple parent paths (e.g. `작업/포트폴리오` and `포트폴리오`), decide explicitly:

1. Compare file counts and timestamps
2. The most complete copy is the canonical home
3. Other copies: delete entirely (don't merge — easier to verify nothing was lost)
4. **Pitfall:** Never silently merge — duplicates often differ in subtle ways (different file versions, missing files). Deletion is reversible from backup; merge corruption is not.

### Phase 5. Apply file exclusion patterns

Run a glob sweep to quarantine system/build metadata into `99-archive`:

```python
patterns = ['.DS_Store', '.git', '.svn', 'Thumbs.db']
build_globs = ['*.ncb', '*.suo', '*.user', '*.opt', '*.plg', '*.positions',
               '*.pdb', '*.idb', '*.obj', '*.pch', '*.sbr', '*.bsc', '*.res',
               '*.tlog', '*.lastbuildstate', 'BuildLog.htm',
               'Debug/', 'Release/', 'build/', 'dist/', 'bin/', 'obj/',
               'DerivedData/', 'xcuserdata/', '*.xcuserstate']
```

Move (don't copy) matching files into `99-archive`. Keep the structure (relative paths) so provenance is preserved.

Skip the exclusion sweep if user explicitly wants the originals preserved (rare — usually they want cleanup).

### Phase 6. Move, don't copy

The user almost always picks "actually move" over "copy into new location". Reasons:

- 26GB+ backups take hours to copy
- Duplicates after a copy waste space forever
- Move is atomic per file (`shutil.move`) — partial failures are visible
- Backup-before-move is a separate concern (recommend `rsync` to external disk first)

**Pitfall:** A move operation that walks `rglob` and moves files into a target that itself is a subdirectory of the move source will create a recursive nest. Always verify the destination path is OUTSIDE the source tree before iterating.

### Phase 7. Empty-folder cleanup

After all moves, run a recursive empty-folder sweep. **Two passes:**

1. **Count pass:** `rglob('*')` sorted deepest-first; count empties for the report
2. **Remove pass:** iterate again deepest-first; `rmdir()` if empty AND not in protected set

Protected set (NEVER remove even if empty):
- All bucket roots: `00-inbox`, `01-public`, `02-private`, `99-archive`
- Hermes runtime: `.omo`, `.codegraph`
- User-named folders the user explicitly preserves (often `!`-prefixed)

**Pitfall:** Counting empties with `sorted(depth-ascending)` undercounts because parents are not re-evaluated after children are removed. The remove pass needs `sorted(depth-descending)` so leaves go first, then their now-empty parents.

Verified count delta: 1138 → 1349 (after multi-level pruning).

### Phase 8. Verify

Always run after the sweep:

```bash
ls /backup/                     # top-level buckets present
du -sh /backup/*/               # capacity sanity check
find /backup -type d -empty     # should be near zero (only intentional stubs)
```

For each output bucket:
- Confirm directory count matches expectation
- Spot-check 1-2 projects for missing files
- Total file count should equal (source count − excluded − duplicates deleted)

---

## Common Pitfalls

### 1. The flatten-after-archive mistake

Moving items into an archive bucket that itself lives under the archive parent creates `99-archive/02-private/...` instead of `02-private/...`. Fix: either compute destination as sibling of archive (`root / child.name`) or move archive contents back to root, then `rmdir()` the now-empty archive stub.

### 2. The "empty folder" misread

User says "이 폴더 안에는 비어있는 폴더만 있는 것 같은데" — but the top-level has 4-7 items; only the *deep* tree has empties. Verify with both surface-level (`iterdir()`) and deep (`rglob`) checks before reporting.

### 3. SVN metadata inflation

`.svn/text-base`, `.svn/tmp/prop-base`, `.svn/props`, `.svn/wcprops`, `.svn/tmp/text-base`, `.svn/tmp/wcprops` — each is a separate folder per source file. A 100-file project can produce 500+ empty `.svn` folders. These are safe to remove; SVN metadata is recreated on `svn checkout`.

### 4. Stray items in wrong bucket

When moving sibling groups into sub-categories, a misplaced item (`asdf.txt` into `04-원본-소스-에셋-백업` instead of `02-개인-문서-경력`) creates an `_extra`-suffixed file. Add a verification step: list each sub-category after population and re-route obvious misplacements.

### 5. Recursive move target

`shutil.move(src, target)` where `target` is inside `src` causes the source to nest inside itself on retry. Always assert `Path(target).resolve().is_relative_to(Path(src).resolve()) is False` before iterating, or use `Path(target).resolve().parent != Path(src).resolve()`.

### 6. The folder-named-as-private trap

A user says "포트폴리오 폴더는 공개" but a subfolder inside it is named `Being_not_open_to_the_public` or `!!비밀스런자료_에헷~♡`. The folder name itself is a stronger signal than the parent. Always inspect the child name, not just the parent.

### 7. macOS-only `@` extended attribute on moved files

After `shutil.move`, the resulting folder may carry an `@` flag in `ls -la` (extended attributes). This is harmless but trips up shell scripts that compare attributes. Don't treat as an error.

---

## Verification Checklist

Before reporting completion:

- [ ] All 4 output buckets exist (`00-inbox`, `01-public`, `02-private`, `99-archive`)
- [ ] `02-private` subdivided into 4 sub-categories (or user-approved variant)
- [ ] User-named roots preserved (`!`-prefixed folders still in place, even if they appear empty at top level — confirm with `du -sh`)
- [ ] Hermes runtime untouched (`.omo/`, `.codegraph/` byte counts unchanged)
- [ ] Total file count matches expectation (source minus excluded minus duplicate-deleted)
- [ ] `find -type d -empty` returns ≤ intentional stubs only
- [ ] Spot-check 1-2 projects per bucket for content integrity
- [ ] No mid-process archive-of-archive nesting

---

## Output Format for User

Report in this order:

1. **최종 루트 구조** — tree-style listing of bucket contents (top 2 levels)
2. **주요 결정 사항** — public/private boundary calls you made, with reasoning
3. **처리한 중복** — duplicate copies you deleted vs folded, by name
4. **추가 옵션** — 3-4 next-step options the user can pick (e.g. "공개 후보 보강", "통신사별 분류", "빌드 산출물 제거", "이력서 정리")

Keep it concise — the user typically wants to verify, not read a novel.

---

## Downstream Skills

After this skill completes, the user usually wants:

1. **`github-repo-management`** — for creating the actual GitHub repos (`gh repo create --source . --private`)
2. **`skill-security-audit`** — before making anything public, scan for secrets/PII
3. **`local-dashboard`** or **`github-portfolio-planner`** — to build a navigation index of the new public repos
4. **`memory-error-tracker`** or **`nightly-maintenance-workflow`** — to monitor the new private repos for accidental leaks

---

## Bundled Script

- `scripts/reorganize_backup.py` — runnable re-implementation of the 7-phase workflow. Supports `--dry-run` and a JSON `--config` override for custom triage rules. Defaults match the validated scheme from the 2026-07-31 session.