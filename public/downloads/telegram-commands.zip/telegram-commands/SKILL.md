# Telegram Interactive Commands (ICBM2)

Quick command access to ICBM2 automation features via Telegram.

## Overview

이 스킬은 ICBM2의 핵심 자동화 기능에 빠르게 접근할 수 있는 텔레그램 명령어 라우터를 제공합니다. 텔레그램 봇 컨텍스트에서 직접 호출하거나 cron을 통해 자동으로 실행됩니다.

## Script

`~/.hermes/scripts/telegram_command_router.py`

## Usage

```bash
python3 ~/.hermes/scripts/telegram_command_router.py <command>
```

## Available Commands

| Command     | Description                          | Source                            |
|-------------|--------------------------------------|-----------------------------------|
| /status     | 전체 자동화 상태 요약                | crontab, memory files             |
| /news       | 최신 뉴스 5개 요약                   | Notion iOS Trend + AI Model DB    |
| /invest     | 오늘 시황 요약                       | Notion Invest Memo DB             |
| /idea       | 랜덤 아이디어 노트 하나 생성          | Notion 아이디어 노트 DB           |
| /skills     | 등록된 스킬 목록                     | ~/.hermes/skills/                 |
| /deploy     | 웹 대시보드 README 갱신 & 배포       | icbm2-knowledge-graph 리포        |
| /help       | 명령어 목록                          | 내장                              |

## Output Format

- Plain text only (Telegram 호환, 마크다운 미사용)
- 이모지로 시각적 구조 제공
- 한국어 출력
- 4000자 이내 (Telegram 메시지 제한)

## Notion DB IDs

- iOS Trend: 33c76f2e-9097-8112-84f6-c60096cc0e11
- Invest Memo: 33c76f2e-9097-8107-800f-efc2f699aa93
- AI Model Tracker: 33c76f2e-9097-8132-9033-e434f4055b56
- 아이디어 노트: 32e76f2e-9097-8081-98d0-f54524fe4c47

## Integration

이 스크립트는 텔레그램 봇의 webhook handler나 poller에서 직접 호출하도록 설계되었습니다. 표준 출력으로 포맷된 텍스트를 반환하므로, 봇이 그대로 전송하면 됩니다.

## Error Handling

모든 명령어는 에러 발생 시 친근한 한국어 에러 메시지를 반환합니다. Notion API 실패, 파일 없음, 네트워크 오류 등을 우아하게 처리합니다.
