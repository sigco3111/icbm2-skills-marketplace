#!/bin/bash
# Headless dungeon dump via cargo example → tee screenshot.
# Verifies BSP + half-block wall_glyph working end-to-end without TUI launch.
#
# Usage: ./dump-headless.sh <project_dir> [<procgen_crate_name>] [<seed_hex>]
#
# Example:
#   ./dump-headless.sh /Users/mac/work/asciirogue asciirogue-procgen CAFEBABE

set -e
PROJECT="${1:-/Users/mac/work/<project>}"
PROC_CRATE="${2:-<crate>-procgen}"
SEED="${3:-CAFEBABE}"

if [ ! -d "$PROJECT" ]; then
  echo "Project dir not found: $PROJECT" >&2
  exit 1
fi

if ! [ -f "$PROJECT/crates/procgen/examples/dump.rs" ]; then
  echo "examples/dump.rs missing. Create first (see README §7)." >&2
  exit 1
fi

cd "$PROJECT"

# Load cargo if needed
. "$HOME/.cargo/env" 2>/dev/null || {
  echo "cargo not on PATH. install rustup first." >&2; exit 1;
}

# Run, tee log
LOG="/tmp/dump-$(date +%s).log"
cargo run --example dump -p "$PROC_CRATE" 2>&1 | tee "$LOG" | head -25

echo
echo "===== Headless dump summary ====="
echo "Logged: $LOG ($(wc -l < "$LOG") lines)"
echo
echo "Quick coherence check — half-block chars visible?"
grep -c '[▀▄▌▐█]' "$LOG" || echo "(no half-block chars seen — check wall_glyph impl)"
echo "Rooms declared: $(grep -E '^Dungeon:' "$LOG" || echo '(no header)')"
