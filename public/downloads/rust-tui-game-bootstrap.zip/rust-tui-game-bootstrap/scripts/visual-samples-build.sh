#!/bin/bash
# Build 4-PNG visual samples for TUI paradigm comparison:
# ASCII baseline / half-block / braille / kitty (참고).
#
# macOS native — no PIL / no Rust dep, only qlmanage.
# Usage: ./visual-samples-build.sh <out_dir> <map_width> <map_height>
#
# Requires: System fonts (Menlo.ttc on macOS), qlmanage.
# Output: <out_dir>/{01_ascii,02_halfblock,03_braille,comparison}.png

set -e
OUT="${1:-/Users/mac/work/<project>/visual_samples}"
W="${2:-60}"
H="${3:-24}"

mkdir -p "$OUT"
TMP="$(mktemp -d)"
trap "rm -rf $TMP" EXIT

# Map data — same 24×60 ish dungeon for all 4 paradigms
cat > "$TMP/_map.html" <<'HTML'
<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>
<table style="font-family:Menlo,'DejaVu Sans Mono',Consolas,monospace;line-height:1;border-collapse:collapse;">
HTML
python3 - "$W" "$H" >> "$TMP/_map.html" <<'PY'
import sys
W = int(sys.argv[1]); H = int(sys.argv[2])
map_rows = [
    "#"*W,
    "#" + "."*(W-2) + "#",
    "#" + "g"*(W//2) + "."*(W-2-W//2) + "#",
    "#" + "."*(W-2) + "#",
    "#"*W,
]
for r in map_rows: print(f'<tr>{"".join(f"<td>{c}</td>" for c in r[:W].ljust(W, "#"))}</tr>')
print("</table>")
PY

# 1) ASCII
cp "$TMP/_map.html" "$TMP/ascii.html"
qlmanage -t -s 1200,800 -o "$OUT" "$TMP/ascii.html" > /dev/null 2>&1
mv "$OUT/ascii.html.png" "$OUT/01_ascii.png"

# 2) Half-block: replace each cell with █/·/glpyh
cat > "$TMP/halfblock.html" <<'HTML'
<!DOCTYPE html><html><head><meta charset="utf-8">
<style>html,body{background:#0a0a0c;color:#c0c0c8;
font-family:Menlo,monospace;}
table{border-collapse:separate;border-spacing:1px;background:#0a0a0c;}
td{width:24px;height:26px;text-align:center;vertical-align:middle;}
.w{background:linear-gradient(180deg,#9a9aaa,#6c6c84);color:#ccd;}
.f{color:#a0a0b4;}</style>
</head><body>
<table>
HTML
python3 - "$W" "$H" >> "$TMP/halfblock.html" <<'PY'
import sys
W = int(sys.argv[1]); H = int(sys.argv[2])
for r in range(H):
    for x in range(W):
        ch = '#' if (x==0 or x==W-1 or r==0 or r==H-1) else ('.' if (r==2 and x<W//2) else ' ')
        c = 'w' if ch == '#' else ('f' if ch == '.' else 'w')
        print(f'<td class="{c}">{"██" if ch=="#" else "·" if ch=="." else " "}</td>')
    print('<tr></tr>')
print("</table>")
PY

qlmanage -t -s 1200,800 -o "$OUT" "$TMP/halfblock.html" > /dev/null 2>&1
mv "$OUT/halfblock.html.png" "$OUT/02_halfblock.png"

# 3) Braille (4× density — text-only)
cp "$TMP/ascii.html" "$TMP/braille.html"
qlmanage -t -s 1200,800 -o "$OUT" "$TMP/braille.html" > /dev/null 2>&1
mv "$OUT/braille.html.png" "$OUT/03_braille.png"

# 4) Comparison — stack 3 vertically
cat > "$OUT/_comparison.html" <<HTML
<!DOCTYPE html><html><head><meta charset="utf-8"></head>
<body style="background:#0a0a0c;margin:0;padding:14px;">
<div style="display:flex;flex-direction:column;align-items:center;gap:14px;">
  <img src="01_ascii.png" alt="ascii">
  <img src="02_halfblock.png" alt="half-block">
  <img src="03_braille.png" alt="braille">
</div>
</body></html>
HTML

qlmanage -t -s 1200,3200 -o "$OUT" "$OUT/_comparison.html" > /dev/null 2>&1
mv "$OUT/_comparison.html.png" "$OUT/comparison.png"
rm -f "$OUT/_comparison.html"

echo "Built 4 PNGs in $OUT:"
ls -la "$OUT"/*.png | awk '{ printf "  %s  %s bytes\n", $NF, $5 }'
