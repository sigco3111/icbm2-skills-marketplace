<file_content>#!/bin/bash
# Headless key-probe runner. Compiles and runs the `key_probe` example
# binary, which synthesises crossterm::Event::Key values into the real
# App::handle() and prints before/after state. Used when the user asks
# "does Y work?" or "변화가 없음" and code analysis alone is not enough.
#
# Usage: ./probe-key-direct.sh <project_dir> [<probe_name>]
#
# Example:
#   ./probe-key-direct.sh /Users/mac/work/asciirogue

set -e
PROJECT="${1:-/Users/mac/work/<project>}"
PROBE="${2:-key_probe}"

if [ ! -d "$PROJECT" ]; then
  echo "Project dir not found: $PROJECT" >&2
  exit 1
fi

cd "$PROJECT"

# Load cargo if needed
. "$HOME/.cargo/env" 2>/dev/null || {
  echo "cargo not on PATH" >&2; exit 1;
}

# Build (release) and run. Tee to /tmp for inspection.
LOG="/tmp/key-probe-$(date +%s).log"
echo "Building $PROBE example..."
cargo build --release --example "$PROBE" 2>&1 | tail -3

echo
echo "Running probe..."
BIN="./target/release/examples/$PROBE"
if [ ! -x "$BIN" ]; then
  BIN="./target/debug/examples/$PROBE"
fi
"$BIN" 2>&1 | tee "$LOG"
echo
echo "===== probe log saved: $LOG ====="
echo "Lines: $(wc -l < "$LOG")"

# Sanity grep: any panic / failed assertion
if grep -E "panic|FAILED|assertion" "$LOG" >/dev/null; then
  echo "WARNING: probe log mentions panic/fail — investigate."
  exit 2
fi
echo "No panic / failed-assertion markers found in log."
