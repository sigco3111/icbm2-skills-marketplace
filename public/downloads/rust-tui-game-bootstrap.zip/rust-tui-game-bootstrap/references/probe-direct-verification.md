<file_content># 헤드리스 프로브 검증 (Probe-Direct Verification)

> TUI 게임의 한 종류 픽스 — 사용자가 "변화가 없음" / "직접 테스트해봐" 라고 할 때 가장 가치 있는 클래스: **`App::handle(&Event)` + `examples/` probe** 로 키 단위로 직접 검증. PTY 자동화보다 10× 빠르고 정확.

## 문제

`cargo run --release`로 사용자 자기 검증이 필요하지만, 사용자가 본 결과를 **agent가 자동 검증**하기 어려움:

- Hermes sandbox에서 PTY + raw mode 자동화 한계 (5분 timeout)
- 키 입력 자동화 어려움 (crossterm + raw mode 조합)
- 스크린샷은 사용자 환경 의존 + 이미지 비교는 깜빡임 문제

**`--dump` 패턴 한계**: dump는 BSP + FOV + 엔티티 *위치*는 보여주지만, **키 핸들러가 정확히 호출되는지** (입력 → 분기 → 결과) 검증 못함. 사용자가 "변화가 없음"이라고 하면 코드 분석만으로 추측하지 말고 직접 키를 보내서 결과 확인.

## 해결 — `examples/` probe + probe-friendly API

### 1. lib API 노출 (binary.rs → lib.rs 변환)

`crates/app/Cargo.toml`에 둘 다 선언:

```toml
[[bin]]
name = "asciirogue"
path = "src/main.rs"

[lib]
name = "asciirogue"
path = "src/lib.rs"

[dev-dependencies]
```

`src/main.rs`는 thin wrapper:

```rust
use anyhow::Result;
fn main() -> Result<()> {
    asciirogue::run_main()
}
```

`src/lib.rs`에 `run_main()` 노출 + 모든 함수 `pub`.

### 2. probe-friendly 메서드 추가

```rust
// crates/app/src/lib.rs — 끝부분
impl App {
    /// Run one player turn in `dir` (same as the `h/j/k/l/...?` keys).
    pub fn step(&mut self, dir: Direction) -> bool { ... }

    /// Read-only ECS world access for probes.
    pub fn world_ref(&self) -> &hecs::World { &self.world }

    /// Mutable world access for probes that need to teleport the player,
    /// pre-fill inventory, etc.
    pub fn world_mut(&mut self) -> &mut hecs::World { &mut self.world }

    /// Read-only message log access.
    pub fn messages(&self) -> &[String] { &self.messages }

    /// Inject a raw crossterm event. The key handler that the real TUI loop
    /// uses. Probes feed synthesised KeyEvent values through here.
    pub fn handle(&mut self, ev: &Event) { ... } // already pub
}
```

### 3. `examples/` probe 디렉토리

```rust
// crates/app/examples/key_probe.rs
use asciirogue::App;
use asciirogue_core::{Health, Inventory, Item, Position, TilePos};
use crossterm::event::{Event, KeyCode, KeyEvent, KeyEventKind, KeyModifiers, KeyEventState};

fn press(app: &mut App, code: KeyCode) {
    app.handle(&Event::Key(KeyEvent {
        code, modifiers: KeyModifiers::NONE,
        kind: KeyEventKind::Press, state: KeyEventState::NONE,
    }));
}

fn main() {
    let mut app = App::new(0xCAFE_BABE_DEAD_BEEF);

    // 1) 'g' on empty floor — should produce "주울 아이템이 없습니다"
    let prev_len = app.messages().len();
    press(&mut app, KeyCode::Char('g'));
    let new_msgs: Vec<_> = app.messages()[prev_len..].to_vec();
    println!("'g' msgs: {:?}", new_msgs);

    // 2) Teleport player onto ground item via world_mut
    if let Some((ix, iy)) = find_ground_item_pos(&app) {
        teleport(&mut app, ix, iy);
        press(&mut app, KeyCode::Char('$'));  // alias for 'g'
        let inv_filled = app.world_ref()
            .query::<&Inventory>().iter().next()
            .map(|(_, inv)| inv.slots.iter().filter(|s| s.is_some()).count())
            .unwrap_or(0);
        println!("inventory after '\$': {}/8", inv_filled);
    }

    // 3) Inventory-full path
    fill_inventory(&mut app);
    press(&mut app, KeyCode::Char('$'));
    let final_msgs = app.messages();
    let last = final_msgs[final_msgs.len() - 1];
    assert!(last.contains("인벤토리가") || last.contains("가득"),
            "expected inventory-full message, got {:?}", last);
}
```

### 4. 실행 패턴

```bash
# Run the headless probe and capture every assertion message
. "$HOME/.cargo/env"
cargo build --release --example key_probe 2>&1 | tail -5
./target/release/examples/key_probe 2>&1 | tee /tmp/probe.log

# Look for unexpected values — every "panic" or "FAILED" is a bug
grep -i "fail\|panic\|error" /tmp/probe.log
```

## 사용자가 보는 신호 — 언제 probe가 필요한가

다음 3가지 신호는 직접 키를 보내서 결과를 확인해야 함 (코드 분석만으로 추측 금지):

1. **"변화가 없음" / "여전히 X" / "직접 테스트해봐"** — 사용자가 자기 환경에서 검증한 결과. 코드 분석이 틀릴 수 있음.
2. **"Y는 무엇이지?"** — 입력 키가 어디서 처리되는지 모를 때. probe가 짧게 확인.
3. **"이 픽스가 효과 있나?"** — 픽스 적용 후 자기 검증 안 함, 다른 환경 가정 함.

## Pickup tri-state 결과 enum 패턴 (★ v0.5.4 핵심 학습)

probe 운용 중 발견한 **두 번째 발견**: 픽업 함수가 `bool` 반환하면 "주울 아이템이 없습니다" 메시지가 **인벤 full**일 때도 출력되어 사용자한테 잘못된 정보. **tri-state enum** 필요:

```rust
// BAD: bool → caller 메시지가 두 케이스 구분 못함
pub fn try_pickup(world: &mut World, player: hecs::Entity) -> bool

// GOOD: caller가 세 가지 결과 구분 가능
#[derive(Copy, Clone, Debug, Eq, PartialEq)]
pub enum PickupOutcome {
    NoItem,         // ground에 아이템 없음
    Picked,          // inventory에 추가됨
    InventoryFull,  // ground에 아이템 있지만 inventory 가득 참
}

pub fn pick_up_outcome(world: &mut World, player: hecs::Entity) -> PickupOutcome { ... }

// caller: 정확한 메시지 분기
match pick_up_outcome(...) {
    PickupOutcome::Picked        => log("아이템을 주웠습니다."),
    PickupOutcome::NoItem        => log("주울 아이템이 없습니다."),
    PickupOutcome::InventoryFull => log("인벤토리가 가득 찼습니다."),
}
```

**일반화**: `bool` 리턴하는 모든 game-state mutation 함수는 의심. `Result<(), ErrorKind>` 또는 **이벤트 enum**이 정답.

## 사용자가 직접 키 동작 검증 요청 패턴

사용자가 "Y는 무엇이지?" / "X가 실제로 되는지 확인해봐" 같은 메시지를 보내면:

1. **스크린샷 분석하지 말 것** — 실제 키 매핑 검증 필요
2. **`App::handle(&Event::Key(...))` 직접 호출**로 synthesise
3. **after-state 검사**: `app.messages()`, `app.world_ref().query::<&Inventory>()`, etc.
4. **probe 출력 + 변화량 표시**: "before: empty, after pressing g: 1/8 filled"

사용자가 본 환경과 agent 환경은 다름. **probe-direct가 사용자 직접 검증의 80% 대체**.

## 사용자가 만족하는 신호

다음 3가지 중 하나라도 보이면 probe가 충분:

- "응 그거다" / "확인됨"
- 새 픽스가 즉시 작동 → 사용자가 별도 검증 안 함
- 픽스 후 브라우저 캡처 / TTY 출력 변화가 사용자 자기 검증 일치

## 사용자가 안 만족하는 신호 — 더 깊은 진단 필요

- "여전히 안 됨" / "같은 증상"
- 픽스가 적용 안 됐다고 의심 → **probe의 environment 차이 의심** — 시드, FOV, 입력 매핑, 인벤 상태 등 사용자가 다른 환경 가정
- 사용자가 별도 스크린샷 보내면 그것이 진짜 ground truth → 그것과 비교
