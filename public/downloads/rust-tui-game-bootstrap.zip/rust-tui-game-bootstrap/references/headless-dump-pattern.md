# 헤드리스 `--dump` 모드 패턴 (PTY 검증 한계 우회)

> Hermes sandbox의 PTY 자동 검증 한계를 헤드리스 stdout 출력으로 우회하는 표준 패턴. asciirogue (2026-07-29) 검증.

## 문제

Hermes desktop GUI 안에서 `cargo run --release`로 TUI 게임을 띄우면:
- `pty.fork()`로 child process 만들어도 raw mode TUI는 5분 안에 timeout
- 키 입력 자동화 어려움 (crossterm KeyEvent 생성 후 stdin 주입도 환경 의존)
- OpenPreview로 /dev/tty 캡쳐 안 됨
- 사용자가 별도 터미널에서 `cargo run` 해야 시각 확인 가능

## 해결

**Binary가 두 모드를 지원**:
1. **기본 (인자 없음)**: ratatui TUI 게임 (raw mode + key event loop). 사용자 자체 검증.
2. **`--dump <args>`**: TTY 없이 stdout으로 BSP + FOV + 엔티티 캡처. 자동 검증.

## 구현 패턴

```rust
// crates/app/src/main.rs (또는 binary 진입점)
use std::env;

fn main() -> Result<()> {
    let args: Vec<String> = env::args().collect();
    let dump_mode = args.iter().any(|a| a == "--dump");

    if dump_mode {
        let count: u32 = args.windows(2)
            .find(|w| w[0] == "--count")
            .and_then(|w| w[1].parse().ok())
            .unwrap_or(3);
        let seed: u64 = args.windows(2)
            .find(|w| w[0] == "--seed")
            .and_then(|w| parse_seed(&w[1]).ok())
            .unwrap_or(0xCAFE_BABE_DEAD_BEEF);
        return dump_to_stdout(seed, count);
    }

    if args.iter().any(|a| a == "--help" || a == "-h") {
        eprintln!("Usage: asciirogue ... [--dump --count N --seed N] [--help]");
        return Ok(());
    }

    // panic hook + TUI main loop
    let original = std::panic::take_hook();
    std::panic::set_hook(Box::new(move |info| {
        let _ = crossterm::terminal::disable_raw_mode();
        let _ = crossterm::execute!(std::io::stderr(),
            crossterm::terminal::LeaveAlternateScreen);
        original(info);
    }));

    run().context("asciirogue runtime error")
}

fn parse_seed(s: &str) -> Result<u64> {
    if let Some(rest) = s.strip_prefix("0x").or_else(|| s.strip_prefix("0X")) {
        return u64::from_str_radix(rest, 16).with_context(|| format!("bad hex: {s}"));
    }
    s.parse::<u64>().with_context(|| format!("bad decimal: {s}"))
}
```

### dump_to_stdout 내용

```rust
fn dump_to_stdout(seed: u64, count: u32) -> Result<()> {
    for i in 0..count {
        let s = seed.wrapping_add(i as u64);
        let dungeon = bsp::generate(MAP_W, MAP_H, s, bsp::Config::default());
        // spawn player + enemy + Viewshed (Fov + vision::compute)
        let mut world = World::new();
        let (px, py) = dungeon.rooms.first().map(|r| r.center())
            .unwrap_or((MAP_W/2, MAP_H/2));
        let player = world.spawn((
            Position(TilePos(px, py)),
            Renderable::new('@', 0xFFD65A),
            Viewshed::new(VIEW_RADIUS, MAP_W, MAP_H),
        ));
        // optional: enemy spawn
        let mut visible: Vec<TilePos> = Vec::new();
        vision::compute(TilePos(px, py), MAP_W, MAP_H,
                        VIEW_RADIUS, &blocks, &mut visible);
        let vis_set: HashSet<(i32,i32)> = visible.iter()
            .map(|&TilePos(x,y)| (x,y)).collect();

        eprintln!("── seed 0x{seed:016X}  player @({px},{py})  visible {}", visible.len());
        // ...
        for y in 0..MAP_H {
            let mut line = String::with_capacity(MAP_W as usize + 16);
            for x in 0..MAP_W {
                if let Some(&(ch, _)) = entities.get(&(x, y)) {
                    line.push(ch);
                } else if vis_set.contains(&(x, y)) {
                    line.push(match dungeon.at(x, y) {
                        Tile::Wall => wall_glyph(&dungeon, x, y),
                        Tile::Floor => '.',
                        Tile::Rock => ' ',
                    });
                } else if matches!(dungeon.at(x, y), Tile::Wall | Tile::Rock) {
                    line.push(' ');
                } else {
                    line.push('·');  // dim floor (revealed but not visible)
                }
            }
            println!("{}", line);
        }
    }
    Ok(())
}
```

### 검증 게이트

```bash
# 1) 기본 빌드 + 테스트
cargo build --release && cargo test

# 2) --help 동작 확인
./target/release/asciirogue --help

# 3) 헤드리스 캡처 (FOV 정확성 + 엔티티 표시 확인)
./target/release/asciirogue --dump --count 1 --seed 0xCAFE 2>&1 | head -25
./target/release/asciirogue --dump --count 3 --seed 0xCAFEBABE

# 4) 결정성 검증 (같은 시드 → 같은 결과)
./target/release/asciirogue --dump --count 1 --seed 42 > /tmp/a.txt
./target/release/asciirogue --dump --count 1 --seed 42 > /tmp/b.txt
diff /tmp/a.txt /tmp/b.txt && echo "OK"

# 5) 사용자 자체 TUI 검증 (본인 터미널에서)
cargo run --release
# q / r / hjkl / yubn / 화살표 테스트
```

## 한 단계 더 (★ v0.2 헤드리스 기능 추가 옵션)

**`--dump`에 추가 옵션**:
- `--combat <seed> <steps>`: 적 자동 처치 시뮬레이션 (전투 formula 흐름 캡처)
- `--fov-only <seed>`: FOV 시야만 (벽/시야 출력)
- `--seeds <n>`: 첫 n개 시드를 짧게 캡처

```rust
let combat_mode = args.iter().any(|a| a == "--combat");
let fov_mode = args.iter().any(|a| a == "--fov-only");
match (dump_mode, combat_mode, fov_mode) {
    (true, true, _) => simulate_combat(seed, count),
    (true, _, true) => dump_fov_only(seed),
    _ => ...,
}
```

## TUI 자체 검증은 사용자 책임

PTY 자동 검증은 Hermes sandbox 한계로 **불가능**. 사용자가 본인 터미널에서 직접:
```bash
cargo run --release
# 1. 게임 화면 정상 출력
# 2. hjkl / 화살표 / yubn 이동
# 3. 적 처치 / HP 감소 / 메시지 출력
# 4. q / Esc 정상 종료 (raw mode 해제 + alt screen restore)
```

→ 단위 테스트 + `--dump`로 **엔진 결정성 100% 검증**, 실제 TUI 시각/입력 UX는 사용자 본인 검증.

## ASCII 스타일 시각화 핵심

half-block (`▀▄█`)으로 시야 안/밖 색 차이를 표현:
- visible: 밝은 회색 + `wall_glyph`
- revealed만 (어두웠던 적 있음): 어두운 회색 + 동일 wall_glyph
- hidden: 완전 검정 (공백)
- `.`: floor visible (밝음 회색), `·`: floor dim (reveled만)
