# ECS + FOV 7-step 시스템 (Rust TUI 로그라이크 표준)

> ratatui 0.29 + hecs 0.10 + doryen-fov 0.1 — 검증된 asciirogue week-2 패턴 (2026-07-29).

## 7단계 (boilerplate-free)

### 1. 핵심 의존성

```toml
# Cargo.toml (workspace)
[workspace.dependencies]
ratatui        = "0.29"
crossterm      = "0.28"
hecs           = "0.10"
doryen-fov     = "0.1"   # ★ 추가
```

doryen-fov 0.1.1 API:
- `MapData::new(w, h)` → transparent 기본값 true
- `map.set_transparent(x, y, false)` = 벽
- `fov.compute_fov(&mut map, ox, oy, max_radius, light_walls: bool)`
- `map.is_in_fov(x, y) → bool`

### 2. core 컴포넌트

```rust
#[derive(Copy, Clone, Debug, Default, Eq, PartialEq, Hash)]
pub struct TilePos(pub i32, pub i32);

#[derive(Copy, Clone, Debug, Default)]
pub struct Position(pub TilePos);

#[derive(Copy, Clone, Debug, Eq, PartialEq)]
pub struct Renderable {
    pub glyph: char,
    pub fg_rgb: u32,  // 0xRR_GG_BB packed — 24bit RGB
}

#[derive(Copy, Clone, Debug, Default)]
pub struct Player;  // marker

#[derive(Copy, Clone, Debug)]
pub struct Viewshed {
    pub range: i32,
    pub visible: Vec<TilePos>,
    pub revealed: Vec<bool>,
}
```

### 3. Direction enum (vim + yubn 8-way)

```rust
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
pub enum Direction {
    Up, Down, Left, Right,
    UpLeft, UpRight, DownLeft, DownRight,
    None,
}

impl Direction {
    pub const EIGHT: [Direction; 8] = [
        Direction::Up, Direction::UpRight, Direction::Right,
        Direction::DownRight, Direction::Down, Direction::DownLeft,
        Direction::Left, Direction::UpLeft,
    ];
    pub fn delta(self) -> (i32, i32) { /* (dx, dy) */ }
}
```

**키바인딩**:
- `h j k l` → Left/Down/Up/Right
- `y u b n` → UpLeft/UpRight/DownLeft/DownRight
- `← ↓ ↑ →` → 4-way only (방향키는 표준 4-way)
- `.` → None (가만히)

### 4. vision (doryen-fov wrapper)

```rust
pub fn compute(origin: TilePos, width: i32, height: i32,
               radius: i32, blocks: &[bool], out: &mut Vec<TilePos>) {
    out.clear();
    let mut map = MapData::new(width as usize, height as usize);
    for y in 0..height as usize {
        for x in 0..width as usize {
            // blocks[x+y*W]=true means wall → set_transparent(false)
            map.set_transparent(x, y, !blocks[x + y * width as usize]);
        }
    }
    let mut fov = FovRecursiveShadowCasting::new();
    fov.compute_fov(&mut map, origin.0 as usize, origin.1 as usize,
                    radius as usize, true);  // light_walls=true
    for y in 0..height {
        for x in 0..width {
            if map.is_in_fov(x as usize, y as usize) {
                out.push(TilePos(x, y));
            }
        }
    }
}
```

### 5. draw_world (3단계 visibility + entity overlay)

```rust
pub fn draw_world(frame: &mut Frame<'_>, area: ratatui::layout::Rect,
                  map: &Dungeon, world: &hecs::World, viewshed: &Viewshed) {
    let visible: HashSet<(i32, i32)> = viewshed.visible
        .iter().map(|&TilePos(x,y)| (x,y)).collect();

    let mut buf = frame.buffer_mut();
    for y in 0..area.height {
        for x in 0..area.width {
            let (wx, wy) = (x as i32, y as i32);
            if wx >= map.width || wy >= map.height { continue; }
            let is_visible = visible.contains(&(wx, wy));
            let is_revealed = viewshed.revealed[(wy * map.width + wx) as usize];

            let (sym, col) = if is_visible {
                match map.at(wx, wy) {
                    Tile::Wall  => (wall_glyph(map, wx, wy), Color::Rgb(180,180,200)),
                    Tile::Floor => ('·', Color::Rgb(140,140,170)),
                    Tile::Rock  => ('#', Color::Rgb(80,80,90)),
                }
            } else if is_revealed {
                match map.at(wx, wy) {
                    Tile::Wall  => (wall_glyph(map, wx, wy), Color::Rgb(60,60,70)),
                    Tile::Floor => ('·', Color::Rgb(40,40,50)),
                    Tile::Rock  => (' ', Color::Reset),
                }
            } else { (' ', Color::Reset) };
            buf[(area.x + x, area.y + y)].set_char(sym).set_fg(col);
        }
    }

    // Pass 2: entities, only those on visible tiles
    for (_id, (pos, render)) in world.query::<(&Position, &Renderable)>().iter() {
        let TilePos(x, y) = pos.0;
        if !visible.contains(&(x, y)) { continue; }
        if x >= area.width as i32 || y >= area.height as i32 { continue; }
        let color = Color::Rgb(
            ((render.fg_rgb >> 16) & 0xFF) as u8,
            ((render.fg_rgb >> 8) & 0xFF) as u8,
            (render.fg_rgb & 0xFF) as u8,
        );
        buf[(area.x + x as u16, area.y + y as u16)]
            .set_char(render.glyph).set_fg(color);
    }
}
```

### 6. hecs borrow rules (★ 함정)

```rust
// get으로 개별 컴포넌트 borrow — 타입이 아닌 ref 명시
let pos = if let Ok(p) = self.world.get::<&Position>(entity) { p.0 }
          else { TilePos(0, 0) };

// mutable borrow도 동일
if let Ok(mut p) = self.world.get::<&mut Position>(entity) {
    p.0 = new_pos;
}

// 동일 world를 query + borrow 동시 시도 → 컴파일 에러
// 해결: snapshot pattern
let viewshed_snapshot = if let Ok(v) = self.world.get::<&Viewshed>(player) {
    Viewshed { range: v.range, visible: v.visible.clone(),
               revealed: v.revealed.clone() }
} else { Viewshed::new(VIEW_RADIUS, MAP_W, MAP_H) };
draw_world(frame, centered, &self.dungeon, &self.world, &viewshed_snapshot);
```

**hecs 0.10은 `world.get<T>(id)` 이 아니라 `world.get::<&T>(id)` 형태**. `T` 자체는 `ComponentRef` 트레잇 만족 안 함.

### 7. FOV 4개 테스트 (vision::tests)

1. **origin_always_visible**: 동일 위치 자신은 항상 보임
2. **wall_blocks_line_of_sight**: 한 칸 떨어진 벽 너머 안 보임 (단, `light_walls=true`면 벽 자신은 보임)
3. **determinism_is_perfect**: 동일 입력 → 동일 출력
4. **radius_limits_visibility**: range=5면 6칸 떨어진 곳 안 보임

## 한계 (week-3 이후로 미룸)

- Viewshed.visible을 Vec + HashSet rebuild (성능 약간 아쉬움, v0.2에서 비트맵 or GridVec 전환)
- Revealed 타일 메모리 (Vec<bool>) — 엔티티 시야 미통합
- 다중 entity same-tile 충돌 해소를 entity_at()으로 매 액션 O(n) 스캔 — 공간 인덱스 미구축

## 다음 (week-3): Combat / AI

`take_turn(ai::AiAction)`, `attack::resolve_attack(Stats, Stats)`, `ai::AiKind` 추가 →
→ `references/combat-ai.md` 참조.
