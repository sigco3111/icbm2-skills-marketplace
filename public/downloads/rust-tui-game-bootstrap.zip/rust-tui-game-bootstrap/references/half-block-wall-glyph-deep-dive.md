# Half-block wall_glyph 4-bit mask 16 경로 매핑

asciirogue 2026-07-29 1차 검증 알고리즘. ratatui 0.29 + half-block 픽셀 비주얼.

## 기본 마스크

```
N (북, y-1) = bit 0 (1)
S (남, y+1) = bit 1 (2)
W (서, x-1) = bit 2 (4)
E (동, x+1) = bit 3 (8)
```

총 16개 조합 (0..15). 가장 자연스러운 half-block 글리프는:

| 마스크 (bits) | N | S | W | E | 글리프 | 의미 |
|---:|---|---|---|---|---|---|
| 0 | - | - | - | - | ' ' (공백) | 인접한 벽 없음 — 사실 wall 이면 안 됨 |
| 1 | ✓ | | | | '▀' | 위쪽만 채움 (천장) |
| 2 | | ✓ | | | '▄' | 아래쪽만 채움 (바닥 가장자리) |
| 3 | ✓ | ✓ | | | '█' | 위+아래 모두 (수직 벽) |
| 4 | | | ✓ | | '█' | 서쪽만 (좌벽) |
| 5 | ✓ | | ✓ | | '█' | 모서리 NW |
| 6 | | ✓ | ✓ | | '█' | 모서리 SW |
| 7 | ✓ | ✓ | ✓ | | '█' | 3면 (좌+위+아래) |
| 8 | | | | ✓ | '█' | 동쪽만 (우벽) |
| 9 | ✓ | | | ✓ | '█' | 모서리 NE |
| 10 | | ✓ | | ✓ | '█' | 모서리 SE |
| 11 | ✓ | ✓ | | ✓ | '█' | 3면 (동+위+아래) |
| 12 | | | ✓ | ✓ | '█' | 좌+우 (수평 벽 — 두꺼운 복도) |
| 13 | ✓ | | ✓ | ✓ | '█' | 3면 (좌+우+위) |
| 14 | | ✓ | ✓ | ✓ | '█' | 3면 (좌+우+아래) |
| 15 | ✓ | ✓ | ✓ | ✓ | '█' | 4면 (고립/밀집) |

## v0.1 단순 매핑 (현재 asciirogue)

```rust
fn wall_glyph(map: &Dungeon, x: i32, y: i32) -> char {
    let is_w = |dx, dy| matches!(map.at(x+dx, y+dy), Tile::Wall);
    let m = (is_w(0,-1) as u8) | (is_w(0,1) as u8) << 1
          | (is_w(-1,0) as u8) << 2 | (is_w(1,0) as u8) << 3;
    match m {
        0  => ' ',
        1  => '▀',
        2  => '▄',
        3..=15 => '█',  // v0.1: dense — 너무 단순
    }
}
```

v0.1은 corner/dense 모두 '█'. 실제로 보이면 9가지 패턴 (`▀`, `▄`, `█` + 빈 셀) 으로 충분히 분위기 살림.

## v0.2 확장 (★ 향후 작업용) — 9 패턴

```rust
fn wall_glyph(map: &Dungeon, x: i32, y: i32) -> char {
    let n = matches!(map.at(x, y-1), Tile::Wall);
    let s = matches!(map.at(x, y+1), Tile::Wall);
    let w = matches!(map.at(x-1, y), Tile::Wall);
    let e = matches!(map.at(x+1, y), Tile::Wall);
    let m = (n as u8) | ((s as u8) << 1) | ((w as u8) << 2) | ((e as u8) << 3);
    // 9 + path corners
    match (m, n, s, w, e) {
        (0, _, _, _, _)       => ' ',
        (_, true, true, _, _) => '█',  // vertical wall
        (_, _, _, true, true) => '█',  // horizontal wall
        (_, false, true, false, false) => '▄',  // floor cap
        (_, true, false, false, false) => '▀',  // ceiling cap
        (_, false, false, false, false) => ' ',  // lone (no neighbors)
        (_, true, false, _, _) => '▘',  // N top
        (_, false, true, _, _) => '▖',  // S bottom
        // corner walls:
        (_, true, true, true, false) => '▛',  // NW corner
        (_, true, true, false, true) => '▜',  // NE corner
        (_, true, true, true, true)  => '█',  // 3-faced
        (_, _, _, true, false) => '▌',  // W only
        (_, _, _, false, true) => '▐',  // E only
        // ...
        _ => '█',
    }
}
```

이 단계에서 한 번에 9-13 패턴 모두 구현하기 보다, **8-9 패턴만 점진적으로 추가**하는 게 깔끔. 가장 임팩트 큰 것부터:
1. corner 4종 (NW/NE/SW/SE) — `▛▜▙▟`
2. T자 4종 — `▘▝▖▗`
3. cross — `█`

## 색상 팔레트 (v0.1)

```rust
// crates/render/src/lib.rs
match tile {
    Tile::Wall  => (wall_glyph(map, wx, wy),  Color::Rgb(180, 180, 200)),  // cool gray
    Tile::Floor => ('·', Color::Rgb(110, 110, 130)),                       // dim gray
    Tile::Rock  => (' ', Color::Reset),                                     // 0a0a0c 배경
}
```

8-bit color 가 아닌 RGB color 쓸 수 있는 게 ratatui 장점 — **첫 색상 결정 후 매번 정하기보다 팔레트 정의 후 일관성 유지**.

## ENTITY 색상 가이드 (★ 후속 milestones)

| 글리프 | 의미 | 색상 (start point) |
|---|---|---|
| `◉` | player | gold `255,215,90` |
| `g` | goblin | magenta `180,90,210` |
| `T` | troll | red `210,90,90` |
| `D` | dragon | bright red `240,80,80` |
| `r` | rat | pink `230,130,130` |
| `s` | snake | green `120,200,120` |
| `U` | undead | gray `180,180,180` |
| `W` | wraith | white `240,240,240` |
| `$` | gold | yellow `255,210,70` |
| `!` | potion | mint `90,220,160` |
| `^` | trap | brown `170,110,80` |
| `+` | door | amber `190,150,90` |
| `>` | stairs | white `240,240,240` |

## 던전 외곽 (Tile::Rock)

맵 가장자리 / 미할당 영역 = ' ' + 배경 (`#0a0a0c`). 검은 테두리 효과.

## 디버그 디스플레이 (★ 단위 테스트용)

```rust
// 예제 dump.rs
for y in 0..d.height {
    for x in 0..d.width {
        let ch = match d.at(x, y) {
            Tile::Wall  => wall_glyph(&d, x, y),
            Tile::Floor => '.',
            Tile::Rock  => ' ',
        };
        print!("{}", ch);
    }
    println!();
}
```

이 dump 결과를 `cat` 으로 보면 BSP가 만든 12개 룸 + L자 통로가 half-block 으로 표시 — micro 시연으로 충분.
