# Items / Inventory / Floor Cycle Pattern (week-4)

## When to use

Rust TUI roguelike의 **4주차 마일스톤** = 첫 보스 클리어 빌드. 다음 3가지 추가 시:

1. 아이템 시스템 (gold, potion, weapon, armor)
2. 다층 변주 (예: 8 floor = 동굴 → 카타콤 → 카타콤 [BOSS])
3. 보스 처치 게이트 (층마다 깊어진 적 + 보스 한 마리)

## Item + Inventory 컴포넌트

`crates/core/src/lib.rs`에 추가. **decisions**:
- Item은 별도 enum `ItemKind` + struct `{ kind, name, glyph, fg_rgb, bonus }`로 — Renderable 분리
- Inventory는 **고정 크기 Vec\<Option\<Item\>\>** — 8개 슬롯이면 8 capacity. push/take 명시적 결과 (`Result<usize, ()>`)
- 골드는 Item으로 만들고 `bonus: n` 필드가 곧 값

```rust
pub enum ItemKind { Coin, HealthPotion, ManaPotion, Weapon, Armor }

pub struct Item {
    pub kind: ItemKind,
    pub name: String,    // Korean display
    pub glyph: char,     // ground rendering
    pub fg_rgb: u32,     // 24-bit packed
    pub bonus: i32,      // potion=heal, weapon=STR, gold=value
}

pub struct Inventory { pub slots: Vec<Option<Item>>, pub max: usize }

impl Inventory {
    pub fn push(&mut self, item: Item) -> Result<usize, ()> { /* ... */ }
    pub fn take(&mut self, idx: usize) -> Option<Item> { /* ... */ }
    pub fn is_empty(&self) -> bool { /* ... */ }
}
```

## Ground items는 entity로 spawn

한 타일에 둘 이상 못 둠 + automatic despawn 지원 위해 ECS entity로 보관:

```rust
world.spawn((
    Position(TilePos(cx, cy)),
    Renderable::new(glyph_for(kind), color_for(kind)),
    Item::gold(n),
));
```

`try_pickup()` 함수가 발밑 entity를 inventory로 옮기고 despawn.

## Floor Theme + 다층 변주

`FloorTheme` enum + `from_depth` 매핑:

```rust
pub enum FloorTheme { Cave, Catacomb, Garden, Library, Forge, Temple, FinalMaw, Boss }

impl FloorTheme {
    pub fn from_depth(depth: u32) -> Self {
        match depth {
            1..=4 => Self::Cave, 5..=8 => Self::Catacomb,
            9..=12 => Self::Garden, 13..=16 => Self::Library,
            17..=20 => Self::Forge, 21..=24 => Self::Temple,
            25..=27 => Self::FinalMaw, _ => Self::Boss,
        }
    }
}
```

**per-floor seed 결합** (`App::new_at(seed, floor)`):
```rust
let seed = base_seed.wrapping_add(floor as u64 * 0x9E37_79B9_7F4A_7C15);
```
같은 base_seed에서도 층마다 다른 던전. 결정성 보존 (test 가능).

## populate_floor() — 적과 loot 자동 spawn

```rust
fn populate_floor(world: &mut World, dungeon: &Dungeon, floor: u32, theme: FloorTheme) {
    let scale = floor as i32;
    spawn_enemy(world, dungeon, 1, 'r', "쥐", 6+scale, Stats::new(3,8,1,1,5), 8, AiKind::Coward);
    let glyph2 = match theme { FloorTheme::Cave|Garden => 'g', Catacomb|Library => 'S', ... };
    spawn_enemy(world, dungeon, 2, glyph2, name, 14+scale*2, ..., AiKind::Chase);
    if floor >= 3 { spawn_enemy(world, dungeon, 3, 'B', "곰", ...); }
    if floor == BOSS_FLOOR { /* 별도 boss spawn — HP 120+ */ }
    for (i, room) in dungeon.rooms.iter().enumerate() {
        if i == 0 || i % 2 == 0 { continue; }   // 짝수 룸에만 chest
        // gold/potion/weapon 순환
    }
}
```

## 보스 처치 게이트 — `max_hp > 100` heuristic

**보스는 일반 적보다 큰 HP** (120+ at floor 8). `despawn_dead()`에서:

```rust
let mut boss: Option<hecs::Entity> = None;
for &e in &dead {
    if let Ok(h) = world.get::<&Health>(e) {
        if h.max > 100 { boss = Some(e); break; }
    }
}
// ... despawn 이후
if boss.is_some() && !self.boss_defeated {
    self.boss_defeated = true;
    self.log(format!("{}층 보스 격파! '>' 내려가기.", self.floor));
}
```

`>` 키 분기:
```rust
KeyCode::Char('>') => {
    if self.floor == BOSS_FLOOR && !self.boss_defeated {
        self.log("보스를 먼저 처치하세요.");
    } else if next_floor > MAX_FLOORS { ... }
    else { *self = App::new_at(seed, next_floor); }
}
```

이 패턴은 **8 floor / 28 floor / 가변 N floor 모두 일반화 가능**.

## ★ KeyCode 의미 분리 함정

```rust
KeyCode::Char('>') | KeyCode::Char('.') => { /* ... */ }
```

**절대 OR로 묶지 말 것**. `>`(내려가기)과 `.`(wait)는 완전 다른 의미. 매치 분기 한 번에 다 처리하는 함정:

```rust
// BAD: '>'도 '.'도 같은 분기로 들어감 → wait 누르면 descent 트리거
match k.code {
    KeyCode::Char('>') | KeyCode::Char('.') => { ... }
}

// GOOD: 별도 분기
match k.code {
    KeyCode::Char('>') => { descend(...) }
    KeyCode::Char('.') => { wait(...) }
    // ... 또는 default direction catch-all로 '.'처리 + 별도 Char('>') 분기
}
```

## ★ Ref\<T\> deref clone 패턴 (hecs item pickup 함정)

```rust
let cloned = match world.get::<&Item>(e) {
    Ok(r) => Some((*r).clone()),    // ← *r 로 명시적 deref
    Err(_) => None,
};
```

hecs의 `world.get::<&T>(e)`는 `Result<Ref<T>, _>` 반환. `Ref<T>`는 `Deref<Target=T>` 구현하지만 **직접 `r.clone()`**은 `Ref<T>::clone()` 호출 (different type — `Ref<T>` 안에 잡힌 포인터 카피). **`(*r).clone()` 패턴**으로 안의 `T`를 clone해야 함.

## Borrow checker rules (week-4에서 풀었던 것들)

1. **`for (e, item) in items`** → `items`를 consume하지 않게 `let count = picked.len()` 미리 캡쳐. 그래야 `for e in picked` 후 `picked.is_empty()` 호출 가능. 안 그러면 **E0382 borrow of moved value**.

2. **`world.query::<(&Position, &Item)>().iter().filter_map(...)`** → 모은 `Vec<hecs::Entity>` 따로 분리한 뒤 다시 `world.get::<&Item>(e)`. 단일 query가 immut borrow 잡은 채로 item mutate 불가능.

3. **`world.get::<&mut Inventory>(player)` 후 `world.despawn(e)`** → `Inventory` Ref를 명시적으로 `drop(inv)`로 풀어주고 `for e in picked { world.despawn(e); }`로 분리. 안 그러면 **E0502 immut+mut borrow**.

## 검증 흐름

```bash
# 1) 8층 덤프 (boss floor는 자동 [BOSS] 라벨)
./target/release/asciirogue --dump --count 8 --seed 0xCAFE 2>&1 \
  | grep -E "^──" | head -10
# 1F 동굴 / 4F 동굴 / 5F 카타콤 / 8F 카타콤 [BOSS] 모두 나와야

# 2) 아이템 spawn 확인
./target/release/asciirogue --dump --count 1 --seed 0xCAFE | head -28 | grep -E "[@SgBD\$\!\)\?]"
# '@'(player) 'g'/'S'(적) '$'(골드) '!'/'?'(물약) ')'(무기) 모두 표시

# 3) 단위 테스트 — 32 통과 확인
cargo test | grep "test result"
```

## 안티패턴

- Item을 enum만으로 표현하지 말 것. struct + ItemKind enum 합성으로 가는 게 확장성 좋음 (enchantment 추가 시 Item에 필드 하나 더 추가)
- Ground items를 별도 자료구조 (예: `Vec<TileItem>`)에 보관하지 말 것 — ECS entity 하나로 일관성 좋음, `despawn`이 자동 정리
- populate_floor를 빈도마다 새 함수로 분기하지 말 것. `if-else + match theme`로 한 함수에 통합
- Boss 처리를 `Entity`-tagged marker로 하지 말고 `max_hp > THRESHOLD` heuristic으로 — marker 컴포넌트 추가하면 ECS query 더 복잡해짐
