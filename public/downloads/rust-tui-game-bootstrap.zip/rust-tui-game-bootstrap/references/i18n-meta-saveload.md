# i18n + Meta Progression + Save/Load Pattern (week-5)

## When to use

Rust TUI roguelike의 **5주차 마일스톤** = 외부 플레이 가능한 빌드 마감. 다음 3가지 추가 시:

1. **다국어 메시지** (한국어 + 영어) — i18n 시스템
2. **메타 진행** — 런 종료 후 누적 보너스 (Soul Remembrance 같은 영구 변수)
3. **세이브/로드** — RON + 디스크 (XDG 경로) 자동 저장

## What v0.5 unlocks

`Spec §14 5주차` 동시에 채워지는 3개:

- 사용자 환경설정(`ASCIITROGUE_LANG=ko|en` 환경변수) → 게임 시작 시 로케일 결정
- 런 사이 누적 (영구) 메타 보너스 → 다음 런에 챔피언 영혼 1장 + 클리어 카운트
- 메타 상태를 `~/.local/share/asciirogue/remembrance.ron`에 자동 저장
- 게임 안에서 `S`키로 수동 저장, `L`키로 ko ↔ en 토글, `?`키로 인게임 도움말

## i18n 모듈

`crates/core/src/i18n.rs`에 살짝 들어감 — **외부 .toml 로딩 안 함**, enum + table로 인라인 (v0.5 단순화 정책).

```rust
#[derive(Copy, Clone, Debug, Eq, PartialEq)]
pub enum Locale { Korean, English }

impl Locale {
    pub fn from_code(s: &str) -> Self {
        match s.to_ascii_lowercase().as_str() {
            "en" | "english" => Self::English,
            _ => Self::Korean,  // default for unknown / missing
        }
    }
}

#[derive(Copy, Clone, Debug, Eq, PartialEq)]
pub enum Key {
    UiGameTitle, UiPickUp, UiUsePotion, ..., MsgDeath, // 19 keys
}

const TABLE: &[(Key, &str, &str)] = &[
    (Key::UiGameTitle, "asciirogue — 한국어 우선 로그라이크", "asciirogue — Korean-first roguelike"),
    (Key::MsgFloorEntered, "{}층 {} 진입", "Entering {}F {}"),
    (Key::MsgBossDown, "{}층 보스 격파! '>' 내려가기.", "Boss defeated on F{}! ..."),
    // ...
];

pub fn t_for(key: Key, locale: Locale) -> &'static str {
    for (k, ko, en) in TABLE {
        if *k == key {
            return match locale {
                Locale::Korean => ko,
                Locale::English => en,
            };
        }
    }
    "???"
}
```

**왜 enum + table이 외부 .toml보다 단순한가**:
- 19개 메시지만 있다 — `HashMap<String, (ko, en)>`는 overkill
- 컴파일 타임에 키 누락 검출 가능 (enum variant 추가 시 `t_for`이 `"???"` 반환 → 빌드 후 게임에서 발견)
- 사용자 locale 토글 즉시 가능, 별도 파일 IO 없음

**한계**: 메시지 추가는 Rust 코드 수정 필요. v1.0+ 에서 `assets/i18n/{ko,en}.toml`로 분리할 것.

### 포맷팅 헬퍼

`{}` 1개 정도의 positional substitution만 지원. v0.5에는 `format!`처럼 `{0}` 같은 인덱스나 named 가 아닌, **순서 기반**:

```rust
fn t_format_with_locale(
    key: I18nKey, locale: Locale, args: &[&dyn std::fmt::Display],
) -> String {
    let raw = i18n::t_for(key, locale);
    let mut out = String::new();
    let mut arg_idx = 0;
    let mut chars = raw.chars().peekable();
    while let Some(c) = chars.next() {
        if c == '{' && chars.peek() == Some(&'}') {
            chars.next(); // consume '}'
            if let Some(a) = args.get(arg_idx) {
                use std::fmt::Write;
                let _ = write!(&mut out, "{}", a);
                arg_idx += 1;
            } else {
                out.push_str("{}");  // not enough args → leave as literal
            }
        } else {
            out.push(c);
        }
    }
    out
}
```

`App` 빌드 중 (필드 값으로 `Locale` 보관)는 `t_format(app, key, args)` 한 줄 호출, 그 외엔 `t_format_with_locale(key, locale, args)`.

### 게임 시작 시 로케일 결정

```rust
fn new(base_seed: u64) -> Self {
    let loc = Locale::from_code(
        &std::env::var("ASCIITROGUE_LANG").unwrap_or_default()
    );
    Self::new_at_with(base_seed, 1, load_remembrance(), loc, 0)
}
```

**사용자 env var로 시작 시 override**, 게임 내에서 `L` 키로 토글. **빈 문자열은 `Locale::Korean` default** (의도된 결정 — unknown → 안전한 한국어 fallback).

## 메타 진행 — Soul Remembrance

`crates/core/src/meta.rs`에 데이터 모델:

```rust
#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
pub struct SoulRemembrance {
    pub champion_count: u32,    // 30 cap (§18)
    pub wisps: u8,             // 8 cap
    pub marks_of_departed: u32, // 50 cap
    pub last_wager_gold: u32,   // 200 cap
    pub clears: u32,
}

impl SoulRemembrance {
    /// Apply end-of-run rewards. Called from gameplay (e.g. `>` 키 when on BOSS_FLOOR).
    pub fn on_run_end(&mut self, final_floor: u32, gold_remaining: u32, bosses_killed_this_run: u32) {
        if final_floor >= 8 {
            self.clears = self.clears.saturating_add(1);
            self.champion_count = (self.champion_count + 1).min(30);
        }
        let deposit = ((gold_remaining as u32) / 10).min(200);
        self.last_wager_gold = self.last_wager_gold.saturating_add(deposit).min(200);
        self.marks_of_departed = self
            .marks_of_departed
            .saturating_add(bosses_killed_this_run)
            .min(50);
    }
}
```

**3가지 결정 패턴**:

1. **모든 숫자가 saturating** — `saturating_add`로 overflow 방지
2. **모든 cap은 `.min(MAX)` 명시** — SPEC §18의 cap 표 그대로 코드에 박힘
3. **`on_run_end`는 pure 메소드** — IO 없음. 호출자가 decide when (clear, death, mid-run 등)

### Caps 표 (SPEC §18 그대로)

| 리소스 | Cap | 의미 |
|---|---|---|
| `champion_count` | 30 | 클래스/종족별 챔피언 영혼 |
| `wisps` | 8 | 장비 슬롯 +1개 (강령 파편 1장) |
| `marks_of_departed` | 50 | 보스 -1% HP per mark |
| `last_wager_gold` | 200 | 다음 런 시작 골드 (10% carry) |

v0.5에서 v0.6+로 갈 때 이 표에 더 추가 (예: 증언, 명성 등).

## 세이브 / 로드

**경로 결정**: XDG `$HOME/.local/share/<project>/` (macOS/Linux cross):

```rust
fn save_root() -> std::path::PathBuf {
    let mut p = std::env::var_os("HOME")
        .map(std::path::PathBuf::from)
        .unwrap_or_else(|| std::path::PathBuf::from("/tmp"));
    p.push(".local");
    p.push("share");
    p.push("asciirogue");
    let _ = std::fs::create_dir_all(&p);
    p.push("remembrance.ron");
    p
}

fn save_remembrance(r: &SoulRemembrance) -> std::io::Result<()> {
    let path = save_root();
    let s = ron::to_string(r)
        .map_err(|e| std::io::Error::new(std::io::ErrorKind::Other, e))?;
    std::fs::write(path, s)
}

fn load_remembrance() -> SoulRemembrance {
    let path = save_root();
    match std::fs::read_to_string(&path) {
        Ok(s) => ron::from_str(&s).unwrap_or_default(),
        Err(_) => SoulRemembrance::new(),  // missing file → fresh state
    }
}
```

**관용적 패턴 4가지**:

1. **`unwrap_or_default()` 폴백** — 파일 없음/파싱 실패 → fresh state 복귀, 크래시 아님
2. **`create_dir_all` 멱등성** — 여러 번 호출 OK
3. **RON 선택** — TOML보다 Rust 친화적, JSON보다 가독성, trait derive 1줄로 끝
4. **메타 데이터만 persist** — 게임 상태(inventory, HP 등)는 의도적으로 **저장 안 함** — 외부 사람의 디버그/치팅 위험 회피. 메타만 저장.

### 자동 저장 트리거

```rust
// 1) `S` 키 (수동 저장)
KeyCode::Char('S') => {
    let _ = save_remembrance(&self.remembrance);
    self.log(format!("영혼 기억 저장: {} 회 클리어, ...",
                      self.remembrance.clears, ...));
}

// 2) 최종 클리어 시 (자동 저장)
KeyCode::Char('>') => {
    // ...
    } else if next_floor > MAX_FLOORS {
        self.remembrance.on_run_end(MAX_FLOORS, self.gold, 1);
        let _ = save_remembrance(&self.remembrance);  // ← auto-save
        self.log("쏠쏠리의 방 클리어! clears=...");
    }
}
```

**death 시 자동 저장 의도적 안 함** — 죽음은 무한 재도전 기회, 의도된 메카닉. 죽은 런으로 챔피언 영혼 안 잃음.

## 새 키 3개 패턴

| 키 | 동작 | 설계 |
|---|---|---|
| `S` | `save_remembrance` 호출 + 카운터 메시지 | 명시적 — 사용자가 "지금 저장"을 알 수 있게 |
| `L` | `self.locale` 토글 + 짧은 확인 메시지 | 가벼운 토글 |
| `?` | 도움말 줄 3개 연속 로그 | 일회성 부하 — 사용자가 `?` 한 번 누르면 끝 |

**3개 분리보다 1개 키 = 한 가지 액션이 직관적**. `M` = 메뉴, `i` = 인벤토리 같은 multi-mode 스킬들은 1키가 다른 모드, 별도 액션은 별도 키.

## 결정 / 디자인 다섯 가지

### 1. i18n .toml 미사용 (v0.5)

**이유**: 19개 메시지라 `HashMap<String, (ko, en)>` 트래시. enum + const 배열로 끝. **트레이드오프**: 사용자 추가 메시지 = Rust 코드 수정. v1.0+에 `assets/i18n/{ko,en}.toml`로 분리 필요.

### 2. 메타 메소드가 pure (no IO)

**이유**: `on_run_end`가 디스크 부르면 호출자 부담. 분리하면 테스트 가능.

### 3. 세이브 빈도: 수동(S) + 단일 자동(클리어)

**이유**: 매 액션마다 자동 저장 = I/O 너무 많음. `S`/클리어 두 트리거가 운영적으로 충분.

### 4. 게임 상태 미저장

**이유**: 디버그 방지. 도중에 inventory 값 조작 등 가능. 메타만 persist.

### 5. 죽음 = 자동 저장 안 함

**이유**: 죽음은 의도된 상태. 챔피언 영혼 잃지 않는 메카닉.

## 검증 흐름 (week-5 추가)

```bash
# 1) i18n 테스트
cargo test -p asciirogue-core | grep "test i18n"
# locale_code_round_trip + strings_pair_exist + translate_returns_non_empty

# 2) 메타 round-trip 테스트
cargo test meta
# ron_round_trip + capstone_respects_max_caps + clearing_grants_champion_soul + dying_floor_4

# 3) 환경변수 override (TUI 없이 검증)
ASCIITROGUE_LANG=en ./target/release/asciirogue --dump --count 1
# 시작 메시지가 영문으로 표시 (현재 v0.5의 dump mode는 단순 format이라 ko만 표시)
# → 실제 게임 안에서는 시작 메시지 + 키 안내 모두 영문으로 전환

# 4) 40 tests 통과 확인
cargo test | grep "test result"
# 4 app + 9 combat + 20 core + 5 procgen + 2 render = 40 passed
```

## 안티패턴

### `t_for` 키 추가 시 누락 검출 안 됨

키 enum 추가했지만 `TABLE`에 안 넣으면 `t_for`이 `"???"` 반환. **빌드 안 됨**. 대응:

```rust
// BAD: silent miss
const TABLE: &[(Key, &str, &str)] = &[
    (Key::UiGameTitle, ...),
    // MsgDeath 빠뜨림
];
pub fn t_for(key: Key, locale: Locale) -> &'static str {
    for (k, ko, en) in TABLE {
        if *k == key { return ...; }
    }
    "???"  // 조용히 0개 매치
}

// GOOD: 테스트로 누락 차단
#[cfg(test)]
mod tests {
    use std::collections::HashSet;
    #[test]
    fn no_missing_keys() {
        let in_table: HashSet<_> = TABLE.iter().map(|(k,_,_)| *k).collect();
        let all_keys: HashSet<_> = /* enum::iter().collect() */;
        assert_eq!(in_table, all_keys);
    }
}
```

### `ron::to_string` 실패 조용히 무시

```rust
// BAD: serde 에러 무시
let _ = ron::to_string(r).unwrap();  // never panics in production

// GOOD: io::Error로 매핑
let s = ron::to_string(r).map_err(|e| std::io::Error::new(std::io::ErrorKind::Other, e))?;
std::fs::write(path, s)
```

### 디스크 저장 시 동기 write만 사용

`tokio::fs` 같은 비동기 I/O는 TUI 게임 loop와 어울리지 않음. 1ms 이내 완료되므로 `std::fs::write`로 충분. 사용자 키 응답성에 영향.

### `last_wager_gold` saturating 없이 +=

```rust
// BAD: u32 overflow
self.last_wager_gold += deposit;  // saturate 안 하면 wraparound

// GOOD: saturating + cap
self.last_wager_gold = self.last_wager_gold.saturating_add(deposit).min(200);
```

## 직교와 얻어진 결과

5주차 끝에 외부 사람이 `cargo install --path .`로 게임 받아서 플레이 → 첫 8층 클리어 시 챔피언 영혼 1장 + clearance counter + 1 디스크 자동 저장 + 보스 1% 약화 보너스. **메타 진행이 한 세션 만에 닫힌 사이클**.

### 다음 단계 (차별화 결)

- §19 Auto-Pilot — 페르소나 9종 + 자동 행동 depth-2 결정 트리
- §20 Knob 슬라이더 15종 — 런 시작 시 매개변수 미세 조정
- 별도 게임 (= 종료). 외부 사람의 첫 피드백 후 디자인 디테일 결정.
