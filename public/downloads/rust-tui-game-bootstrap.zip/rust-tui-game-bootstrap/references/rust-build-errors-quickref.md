# Rust 첫 부트스트랩 빌드 에러 4종 cheat sheet

asciirogue 2026-07-29 실제 만나서 픽스한 패턴. ratatui 0.29 + Cargo workspace 부트스트랩 직후 발생.

| # | 에러 코드 | 위치 | 메시지 | 해결 |
|---|---|---|---|---|
| 1 | E0502 | `crates/procgen/src/bsp.rs:170` | "cannot borrow `dungeon` as mutable because it is also borrowed as immutable" | `let snap = dungeon.rooms.clone(); for r in snap { dungeon.carve_room(r); }` |
| 2 | E0596 | `crates/app/src/main.rs:84` | "cannot borrow `terminal` as mutable, as it is not declared as mutable" | `let mut terminal = ratatui::init();` |
| 3 | elided_lifetimes_in_paths | `crates/render/src/lib.rs:53` | "hidden lifetime parameters in types are deprecated" | `pub fn draw_map(frame: &mut Frame<'_>, ...)` |
| 4 | deprecated method | `crates/render/src/lib.rs:65` | "use of deprecated method `ratatui::buffer::Buffer::get_mut`" | `buf[(x, y)]` 인덱싱 (대신 `get_mut(x, y)` 안 됨) |

## E0502: rooms immut + dungeon mut

```rust
// ❌ forbidden — borrow checker 거부
for &r in &dungeon.rooms {
    dungeon.carve_room(r);  // immut borrow 살아있는데 mut 호출
}

// ✅ clone + for in (Vec 100개 정도면 비용 무시 가능)
let snap = dungeon.rooms.clone();
for r in snap {
    dungeon.carve_room(r);
}

// ✅ 대안 1 — drain 사용 (consume)
let rooms = std::mem::take(&mut dungeon.rooms);   // Vec 비움
for r in rooms {
    dungeon.carve_room(r);
}

// ✅ 대안 2 — index 기반으로 분리
let n = dungeon.rooms.len();
for i in 0..n {
    let r = dungeon.rooms[i];
    dungeon.carve_room(r);
}
```

## E0596: terminal mut

```rust
// ❌ 컴파일 에러
let terminal = ratatui::init();
terminal.draw(...);    // E0596

// ✅
let mut terminal = ratatui::init();
terminal.draw(...);
```

## elided_lifetimes_in_paths (Frame<'_>)

```rust
// ❌ 에러 (rust 2021 + deny(rust_2018_idioms))
pub fn draw_map(frame: &mut Frame, ...) { ... }

// ✅ 정확한 표기
pub fn draw_map(frame: &mut Frame<'_>, ...) { ... }
```

다른 ratatui 타입: `Terminal<'_>`, `Buffer<'_>` 등.

## Buffer 인덱싱 (ratatui 0.29 변경)

```rust
// ❌ deprecated: get_mut
buf.get_mut(x, y).set_char(c).set_fg(color);

// ✅ 새 인덱싱 (Index tuple trait)
buf[(x, y)].set_char(c).set_fg(color);

// read도 동일
if buf[(x, y)].symbol() == ' ' { ... }
```

## panic hook (★ raw mode cleanup)

```rust
fn main() -> anyhow::Result<()> {
    let original = panic::take_hook();
    panic::set_hook(Box::new(move |info| {
        // panic 발생해도 terminal 복원
        let _ = crossterm::terminal::disable_raw_mode();
        let _ = crossterm::execute!(std::io::stderr(), crossterm::terminal::LeaveAlternateScreen);
        original(info);
    }));
    run()
}
```

panic hook 빠지면 panic 메시지가 raw mode/alt screen 에 갇혀 사용자가 터미널 재설정해야 함.

## rustfmt 미설치 warning (★ minimal profile 함정)

```
error: 'rustfmt' is not installed for the toolchain 'stable-aarch64-apple-darwin'.
help: run `rustup component add rustfmt` to install it
```

→ `cargo build` 자체는 통과 (warning). lint 단계(`cargo fix`, `cargo fmt`)만 사용 불가.
`--profile minimal` 의도적으로 rustfmt/clippy 제외. 차후 풀려면:
```bash
rustup component add rustfmt clippy
```

## unused imports 4종 (warnings)

```rust
use ratatui::{DefaultTerminal, Terminal};   // unused
use crossterm::terminal::{ disable_raw_mode, enable_raw_mode, EnterAlternateScreen, LeaveAlternateScreen };
// enable_raw_mode, EnterAlternateScreen unused (ratatui::restore() 가 처리)
```

→ 빌드 통과 영향 없음. `cargo fix` 로 자동 정리 가능:
```bash
cargo fix --bin "<name>" -p <crate> --tests
```

## 정리 — 빌드 첫 단계 효율적 검증 순서

```bash
cd /Users/mac/work/<project>
cargo build 2>&1 | tail -20    # 첫 빌드는 deps 컴파일로 느림
# → E0502 / E0596 / lifetime / deprecated 모두 이 단계에서 잡힘
```

오타/에러 → 한 줄 패치 → 다시 빌드 → 4-5 회 반복이면 거의 통과. 0단계에서 한꺼번에 안 됨.
