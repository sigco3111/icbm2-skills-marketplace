# Combat + Enemy AI (Rust TUI 로그라이크)

> ratatui + hecs 0.10 환경. asciirogue week-3 (2026-07-29) 검증 패턴.

## 컴포넌트 (core에 추가)

```rust
#[derive(Copy, Clone, Debug, Default, Eq, PartialEq)]
pub struct Health { pub current: i32, pub max: i32 }
impl Health {
    pub fn new(max: i32) -> Self { Self { current: max, max } }
    pub fn is_dead(&self) -> bool { self.current <= 0 }
    pub fn take(&mut self, dmg: i32) -> i32 {
        let dealt = dmg.max(0).min(self.current);
        self.current -= dealt;
        dealt
    }
}

#[derive(Copy, Clone, Debug, Default, Eq, PartialEq)]
pub struct Mana { pub current: i32, pub max: i32 }
impl Mana {
    pub fn spend(&mut self, cost: i32) -> bool {
        if self.current >= cost { self.current -= cost; true } else { false }
    }
}

#[derive(Copy, Clone, Debug, Default, Eq, PartialEq)]
pub struct Stats {
    pub strength: i32, pub dexterity: i32,
    pub intellect: i32, pub wisdom: i32, pub constitution: i32,
}
```

## 적 타입 (AiKind — extension 가능)

```rust
pub enum AiKind { Chase, Coward, PatrolThenChase }

pub struct Ai { pub kind: AiKind, pub speed: i32, pub vision: i32 }
pub struct Name(pub String);
pub struct StatusEffects {
    pub poison_turns: u8, pub burn_turns: u8,
    pub slow_turns: u8, pub bleed_turns: u8,
}
```

## Combat 시스템 (`crates/combat/`)

### attack.rs — pure-fn

```rust
pub fn resolve_attack(atk: &Stats, def: &Stats, rng: u32, bonus: i32) -> AttackOutcome {
    let roll = (rng as i32).clamp(0, 99);
    // to-hit: 50 + DEX_atk*2 + bonus vs DEX_def*3 dodge
    let to_hit_chance = 50 + atk.dexterity * 2 + bonus;
    let dodge_threshold = def.dexterity * 3;
    let target = 100 - to_hit_chance + dodge_threshold;
    let crit = roll >= 95;
    let hit = crit || roll >= target;
    if !hit { return AttackOutcome { hit: false, dmg: 0, crit: false }; }
    // dmg = MAX(1, STR + d<STR> - DEF_CON/2)
    let variance = atk.strength.max(1);
    let d = (rng as i32 % (variance * 2 + 1)) - variance;
    let mut dmg = (atk.strength + d - def.constitution / 2).max(1);
    if crit { dmg = dmg * 5 / 2; }
    AttackOutcome { hit: true, dmg, crit }
}

pub struct AttackOutcome { pub hit: bool, pub dmg: i32, pub crit: bool }
```

★ 테스트 5개: `miss_with_high_dodge`, `hit_with_high_attacker`, `natural_crit_on_highest_roll`, `damage_caps_at_one_minimum`, `crit_overrides_miss`.

### ai.rs — BFS-style 결정 (pure-fn)

```rust
pub fn take_turn<F: Fn(i32, i32) -> bool>(
    enemy: TilePos, player: TilePos,
    vision: i32, kind: AiKind,
    passable: F,
) -> AiAction {
    if !can_see(enemy, player, vision) { return AiAction::Idle; }
    let adj = adjacent_enemy(enemy, player);
    if adj != Direction::None { return AiAction::AttackPlayer; }
    let target = match kind {
        AiKind::Coward => flee_step(enemy, player, &passable),
        AiKind::Chase | AiKind::PatrolThenChase => chase_step(enemy, player, &passable),
    };
    target.map(AiAction::Step).unwrap_or(AiAction::Wait)
}

fn best_step_toward<F, S>(from: TilePos, target: TilePos, score: S, passable: F)
    -> Option<Direction>
where F: Fn(i32, i32) -> bool, S: Fn(i32) -> i32
{
    let mut best_score: Option<i32> = None;
    let mut best_dir: Option<Direction> = None;
    for &dir in Direction::EIGHT.iter() {
        let (dx, dy) = dir.delta();
        if dx == 0 && dy == 0 { continue; }
        let np = TilePos(from.0 + dx, from.1 + dy);
        if !passable(np.0, np.1) { continue; }
        let dist = (np.0 - target.0).abs().max((np.1 - target.1).abs());
        let s = score(dist);
        // strict < 유지 → 동점 시 first-seen 우위 (stable)
        if best_score.map_or(true, |b| s < b) {
            best_score = Some(s);
            best_dir = Some(dir);
        }
    }
    best_dir
}

fn chase_step<…>(…) -> Option<Direction> {
    best_step_toward(from, target, std::convert::identity, passable)
    // 작은 score = 가까움 = 좋음
}
fn flee_step<…>(…) -> Option<Direction> {
    best_step_toward(from, target, |d| -d, passable)
    // 작은 score = 멂 = 좋음 (chase 반전)
}
```

### 디버깅 함정 (★ week-3 실측)

**처음 코드는**:
```rust
// ❌ 멀리 가는 방향이 best로 선택됨 — score 의미 정반대
fn chase_step(…) { best_step_toward(from, target, |d| -d, passable) }
```

`score = -dist` (멀수록 작은 score) + 비교 `s < b` (작은 게 best) → 멀리 가는 step 선택. **버그.**

**정답**:
- chase = `identity` (작을수록 가까움 = 좋음)
- flee = `-d` (작을수록 멂 = 좋음)
- 비교는 strict `<` (stable tie-break)

### App 통합 (`crates/app/src/main.rs`)

```rust
fn try_player_act(&mut self, dir: Direction) {
    let cur = self.world.get::<&Position>(self.player).map(|p| p.0).unwrap();
    let (dx, dy) = dir.delta();
    if dx == 0 && dy == 0 { self.tick += 1; self.enemy_take_turns(); return; }
    let next = TilePos(cur.0 + dx, cur.1 + dy);
    let target = self.entity_at(next);  // O(n) 스캔
    if let Some(entity) = target {
        self.player_attack(entity);
    } else if is_passable(&self.dungeon, next.0, next.1) {
        if let Ok(mut p) = self.world.get::<&mut Position>(self.player) { p.0 = next; }
        self.recompute_fov();
    }
    self.tick += 1;
    self.enemy_take_turns();
}

fn enemy_take_turns(&mut self) {
    let player_pos = self.world.get::<&Position>(self.player).map(|p| p.0).unwrap();
    let plan: Vec<(Entity, TilePos, Ai)> = self.world
        .query::<(&Position, &Ai)>().iter()
        .map(|(e, (p, a))| (e, p.0, *a))
        .collect();
    for (e, pos, ai) in plan {
        let action = ai::take_turn(pos, player_pos, ai.vision, ai.kind,
            |x, y| is_passable(&self.dungeon, x, y)
                && self.entity_at(TilePos(x, y)).is_none());
        if let ai::AiAction::Step(d) = action {
            // apply move + collision check
        }
        if let ai::AiAction::AttackPlayer = action {
            self.enemy_attack(e);
        }
    }
}

fn despawn_dead(&mut self) {
    let dead: Vec<Entity> = self.world.query::<&Health>().iter()
        .filter(|(_, h)| h.is_dead()).map(|(e, _)| e).collect();
    let n = dead.len();
    for e in dead { let _ = self.world.despawn(e); }
    if n > 0 { self.log(format!("{n} 처치!")); }
}
```

### 적 스폰 헬퍼

```rust
fn spawn_enemy(world: &mut World, dungeon: &Dungeon,
               room_idx: usize, glyph: char, name: &str,
               hp: i32, stats: Stats, vision: i32, kind: AiKind) {
    if let Some(room) = dungeon.rooms.get(room_idx) {
        let (ex, ey) = room.center();
        let fg = match glyph {
            'r' => 0xE68282,  // rat pink
            'g' => 0xB45AD2,  // goblin magenta
            _ => 0xFFFFFF,
        };
        world.spawn((
            Position(TilePos(ex, ey)),
            Renderable::new(glyph, fg),
            Health::new(hp),
            stats,
            Ai::new(kind, 100, vision),  // speed=100 → 1 turn per cycle
            Name(name.to_string()),
        ));
    }
}
```

★ asciirogue 기본 던전: 1쥐(room 1, Coward) + 1고블린(room 2, Chase) — SpawnEnemy scheduler 더 있으면 좋음.

## Tick / Energy 큐

v0.3은 **단순 턴제** (플레이어 액션 → 모든 적 순차 행동). 진짜 에너지 큐는 v0.4 이후:

```rust
// v0.4 계획: 적별 speed=80 ~ 120, 누적 energy ≥ 100 → 행동
pub struct Energy(pub i32);
pub const ENERGY_PER_TURN: i32 = 100;
// 각 tick: 모든 엔티티 energy += speed, ≥100 행동 후 -= 100
// 슬라임 speed=50 (느림), 트롤 speed=80, 빠른 적 speed=120
```

## 테스트 (9개)

- attack (5): miss_with_high_dodge, hit_with_high_attacker, natural_crit_on_highest_roll, damage_caps_at_one_minimum, crit_overrides_miss
- ai (4): attacks_when_adjacent, waits_when_player_outside_vision, chases_toward_player_when_visible, coward_steps_away_from_player (DownLeft 동점 first-seen)

## 다음 (week-4)

- 8층 변주 (BSP + 환경별 룸 팔레트,SPEC §7)
- 아이템 시스템 — `Item` component + 인벤토리 Vec<Entity>
- 보스 1 (HP 50, spawn at stair)
- 첫 보스 클리어 가능 빌드

## 다음 (week-5) — 외부 플레이 가능

- i18n (`assets/i18n/{ko,en}.toml`)
- 메타 진행 (SPEC §18 Soul Remembrance)
- README + 첫 release `v0.1.0`
