---
name: rust-tui-game-bootstrap
description: Rust TUI 게임 부트스트랩, ratatui + half-block + BSP.
version: 0.1.0
author: HyeRin
license: MIT
metadata:
  hermes:
    tags: [rust, ratatui, tui, rogu elike, half-block, bs p, game-bootstrap]
    related_skills: [oss-fork-localization, vite-threejs-game-bootstrap, image-analysis]
---

# Rust TUI Game Bootstrap (ratatui + half-block)

## Use when

- 새 **Rust TUI 게임/로그라이키/던전 크롤러** 처음부터 시작 — Cargo 5-crate workspace + ratatui + half-block + BSP
- 시각화 결(half-block vs ASCII vs Braille vs Kitty) 비교 결정할 때 — HTML+qlmanage로 4장 PNG 생성 → 사용자 의사결정 자료
- ratatui 0.29 + hecs 0.10로 첫 Dungeon 화면 띄울 때

대칭 레퍼런스: `vite-threejs-game-bootstrap` (Three.js + Vite + vitest). 같은 결.

## 5-crate workspace (★ 검증됨)

```toml
# /Cargo.toml
[workspace]
resolver = "2"
members = ["crates/core","crates/procgen","crates/combat","crates/render","crates/app"]

[workspace.dependencies]
ratatui        = "0.29"
crossterm      = "0.28"
hecs           = "0.10"
serde          = { version = "1", features = ["derive"] }
ron            = "0.8"
bracket-random = "0.8"
anyhow         = "1"
```

```
crates/
├── core/      # ECS 컴포넌트, 일반 타입 — No rendering, No I/O
├── procgen/   # 절차 생성 (BSP/WFC), Tile/Rect/Dungeon, 결정론 RNG
├── combat/    # energy queue, hit/dodge, status effect
├── render/    # ratatui 프레젠터, half-block wall_glyph 알고리즘
└── app/       # main binary, 키바인딩, 화면(타이틀/던전/메뉴)
```

## 9단계 (★ asciirogue 2026-07-29 verified)

### 1. Rust 툴체인
```bash
curl --proto "=https" --tlsv1.2 -sSf https://sh.rustup.rs \
  | sh -s -- -y --default-toolchain stable --profile minimal
. "$HOME/.cargo/env"   # 새 셸에서 PATH
```
`--profile minimal`은 rustfmt/clippy 제외해도 빌드 정상. 차후:
```bash
rustup component add rustfmt clippy   # write_file 단계마다 lint 잡음 제거
```

**★ rustfmt 없어도 빌드 가능**: `write_file`/`patch` 단계마다 사전 lint 체크가 빨간 줄을 띄우지만 (pre-existing errors — 이 edit didn't introduce new ones), **빌드와 테스트는 영향 없음**. 추가 안 해도 진행 가능. 첫 컴파일 빨라지려면 minimal 유지가 좋음.

### 2. core crate — TilePos / Energy / Tick
```rust
// crates/core/src/lib.rs
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash, Serialize, Deserialize)]
pub struct TilePos(pub i32, pub i32);
#[derive(Copy, Clone, Debug, Default, Eq, PartialEq, Ord, PartialOrd)]
pub struct Tick(pub u64);
#[derive(Copy, Clone, Debug, Default, Eq, PartialEq, Ord, PartialOrd)]
pub struct Energy(pub i32);
pub const ENERGY_PER_TURN: i32 = 100;
```

### 3. procgen crate — Tile/Rect/Dungeon + BSP
```rust
// crates/procgen/src/lib.rs
pub enum Tile { Wall, Floor, Rock }   // Rock = 벽 밖
impl Tile { pub fn is_passable(self) -> bool { matches!(self, Tile::Floor) } }

pub struct Dungeon { pub width: i32, pub height: i32,
                      pub tiles: Vec<Tile>, pub rooms: Vec<Rect> }
```

BSP는 `procgen/src/bsp.rs` 결정론 xorshift64 RNG + 재귀 split:
```rust
pub fn generate(width: i32, height: i32, seed: u64, cfg: Config) -> Dungeon { /* ... */ }
```

**★ 결정론 테스트 (BSP identity)**:
```rust
#[test] fn determinism() { /* seed 42 → A, B 동일 tiles */ }
#[test] fn different_seeds_differ() { /* seed 1 vs 2 → 다름 */ }
```

### 4. render crate — ★ half-block wall_glyph + ratatui draw

```rust
// crates/render/src/lib.rs
use asciirogue_procgen::{Dungeon, Tile};
use ratatui::style::Color;

/// 4-bit mask (N=1, S=2, W=4, E=8) → half-block char
pub fn wall_glyph(map: &Dungeon, x: i32, y: i32) -> char {
    let is_w = |dx, dy| matches!(map.at(x+dx, y+dy), Tile::Wall);
    let m = (is_w(0,-1) as u8) | (is_w(0,1) as u8)<<1
          | (is_w(-1,0) as u8)<<2 | (is_w(1,0) as u8)<<3;
    match m {
        0 => ' ', 1 => '▀', 2 => '▄',
        // corners + dense:
        _ => '█',
    }
}

pub fn draw_map(frame: &mut Frame<'_>, area: ratatui::layout::Rect, map: &Dungeon) {
    let buf = frame.buffer_mut();
    for y in 0..area.height {
        for x in 0..area.width {
            let (symbol, color) = match map.at(x as i32, y as i32) {
                Tile::Wall => (wall_glyph(map, x as i32, y as i32),
                               Color::Rgb(180,180,200)),
                Tile::Floor => ('·', Color::Rgb(110,110,130)),
                Tile::Rock => (' ', Color::Reset),
            };
            buf[(area.x + x, area.y + y)].set_char(symbol).set_fg(color);
        }
    }
}
```

### 5. combat crate — 얇은 placeholder
```rust
// crates/combat/src/{lib,damage,status}.rs
pub enum StatusKind { Poison, Burn, Slow, Silence, Bleed }
pub struct DamageFormula { base, variance, crit_threshold }
```
v0.1는 placeholder로 충분. `combat-system-design.md` 참조 확장.

### 6. app crate — main binary + 키바인딩 + panic hook
```rust
// crates/app/src/main.rs
fn run() -> Result<()> {
    let mut terminal = ratatui::init();          // ← mut 필수
    let result = (|| -> Result<()> {
        let mut app = App::new(0xCAFEBABEu64);
        while app.running {
            terminal.draw(|f| app.draw(f))?;
            if crossterm::event::poll(Duration::from_millis(50))? {
                app.handle(&crossterm::event::read()?);
            }
        }
        Ok(())
    })();
    ratatui::restore();   // raw mode + alt screen restore
    result
}

fn main() -> Result<()> {
    let original = panic::take_hook();
    panic::set_hook(Box::new(move |info| {
        let _ = crossterm::terminal::disable_raw_mode();
        let _ = crossterm::execute!(io::stderr(), LeaveAlternateScreen);
        original(info);
    }));
    run()
}
```

**키바인딩 패턴**: `q`/`Esc` quit, `r` new seed, `hjkl` or arrow move, `.` 가만히.

### 7. dev-deps + 헤드리스 dump
```toml
# crates/procgen/Cargo.toml
[dev-dependencies]
asciirogue-render = { path = "../render" }
```
```rust
// crates/procgen/examples/dump.rs
use asciirogue_procgen::bsp::{generate, Config};
use asciirogue_render::wall_glyph;
fn main() {
    let d = generate(60, 24, 0xCAFEBABEu64, Config::default());
    for y in 0..d.height {
        for x in 0..d.width {
            let ch = match d.at(x, y) {
                Tile::Wall => wall_glyph(&d, x, y),
                Tile::Floor => '.',
                Tile::Rock => ' ',
            };
            print!("{}", ch);
        }
        println!();
    }
}
```

### 8. 검증 게이트 (모든 commit 전)
```bash
cargo build && cargo build --release && cargo test \
  && cargo run --example dump -p asciirogue-procgen | head -25
```
→ **헤드리스 검증**: OpenPreview/PTY 없이도 TUI 출력 가능. **사용자 1차 검증 단계**.

### 9. 비주얼 비교 PNG (★ 의사결정 자료)

4가지 시각화 PNG를 생성해서 사용자에게 보여주기 (사용자 의사결정 받기 전 **반드시** 거쳐야 함):

| 모드 | 글리프 | 픽셀 밀도 | TUI 호환성 |
|---|---|---|---|
| ASCII | `# . @ g` | 1× | 어떤 터미널 |
| **Half-block** | `▀ ▄ █ ▌ ▐` | 2×(수직) | UTF-8 (★가장 일반적) |
| Braille | `⠿ ⣿` | 4×(2×4) | UTF-8 |
| Kitty/Sixel | 진짜 픽셀 | >100× | Kitty/iTerm2 한정 |

**★ PIL 의존성 없을 때 우회 (Hermes venv 깨졌을 때)**: macOS native `qlmanage` 사용.
```bash
# 1) HTML + CSS로 각 모드 렌더링
cat > /tmp/sample.html <<'HTML'
<!DOCTYPE html><html><head><meta charset="utf-8">
<style>html,body{background:#0a0a0c;color:#c0c0c8;
font-family:Menlo,monospace;}</style>
<table style="border-collapse:collapse;...">
  <!-- 동일 map 4번 렌더링 -->
</table>
HTML

# 2) macOS native HTML → PNG
qlmanage -t -s 1200,800 -o /Users/mac/work/<project>/visual_samples /tmp/sample.html
mv /tmp/sample.html.png /Users/mac/work/<project>/visual_samples/02_halfblock.png
```
**PIL `_imaging` import 에러 시 유일 대안**. 비교용 4장 + 합성 1장(`comparison.png` img 참조) 묶음.

### 10. GitHub repo bootstrap + ★ 부산물 cleanup

```bash
cd /Users/mac/work/<project>
gh repo create sigco3111/<project> --public \
  --description "..." --confirm 2>/dev/null
# 사용자 명시 신호 시에만 실행 (외부 액션 게이트)
git remote add origin https://github.com/sigco3111/<project>.git
git add -A
git -c user.email='sigco3111@users.noreply.github.com' \
    -c user.name='sigco3111' \
    commit -m 'feat: initial bootstrap ...'
git push -u origin main
```

**★ path 오타 부산물 cleanup (2026-07-29 실측)**: `write_file` 호출 시 `path` 인자에 `</path>`/`path>` 같이 shell-special 문자가 끼면 **디렉토리째 부산물 파일이 disk에 생기고 첫 commit에 tracked됨**. 

```bash
# 1) 부산물 디렉토리 모두 찾기 + 삭제
find . -name '*</*' -not -path '*/target/*' -exec rm -rfv {} \;

# 2) git tree에 ghost entries로 남은 것 untrack
git rm --cached 'crates/procgen/Cargo.toml</path>' 'crates/procgen/src/lib.rs</path>'
git -c user.email='...' -c user.name='...' commit -m 'fix: drop typo-path artifacts accidentally tracked'

# 3) 푸시
git push -u origin main
```

**검증**: `git ls-files | grep -E '</|path>'` — 비어 있어야 깨끗.

### Git commit message 쉘 escape 함정 (실측 2026-07-29)

commit 메시지에 `(`, `>`, `$`, `*` 등 shell-special 문자 + multiline string 사용 시 bash escape 문제로 commit 자체가 실패. **해결**: 단일 라인으로 짧게:

```bash
# BAD: multiline + shell-special → "File name too long" 에러
git commit -m 'feat(...): items, inventory, 8-floor themes, boss clear gate

Multi-line body with (special) chars...'

# GOOD: 한 줄, 동사는 통일
git commit -m 'feat(week-4): items, inventory, 8-floor themes, boss clear gate'
git commit -m 'feat: initial bootstrap'
```

**변경 사유**: README/CI 외부에 노출되는 메타데이터이므로 일관된 prefix (`feat:` / `fix:` / `docs:` / `refactor:`) 사용.

---

## 핵심 함정 (★ 이번 세션 실측 2026-07-29)

### 빌드 에러 4종 (첫 Rust 부트스트랩에서 흔함)

| # | 에러 | 위치 | 해결 |
|---|---|---|---|
| 1 | E0502 immut + mut borrow | `procgen/src/bsp.rs:170` | `let snap = dungeon.rooms.clone(); for r in snap { ... }` |
| 2 | E0596 terminal not mutable | `app/src/main.rs:84` | `let mut terminal = ratatui::init();` |
| 3 | elided_lifetimes_in_paths | `render/src/lib.rs:53` | `mut Frame<'_>` 명시 |
| 4 | `Buffer::get_mut` deprecated | `render/src/lib.rs:65` | `buf[(x, y)]` 인덱싱 |

### ECS + FOV 7-step 패턴 (★ week-2 검증)

```toml
# Cargo.toml (workspace)
doryen-fov = "0.1"   # 핵심 추가
```

```rust
// crates/core/src/lib.rs — 컴포넌트
pub struct Position(pub TilePos);
pub struct Renderable { pub glyph: char, pub fg_rgb: u32 /* 24bit packed */ }
pub struct Player;            // marker
pub struct Enemy;             // marker
pub struct BlocksTile;        // marker
pub struct Viewshed { pub range: i32, pub visible: Vec<TilePos>, pub revealed: Vec<bool> }
pub struct Direction { Up, Down, Left, Right, UpLeft, UpRight, DownLeft, DownRight, None }
// Direction 8개 + delta() i32,i32

pub enum Direction { /* ... */ }
impl Direction {
    pub const EIGHT: [Direction; 8] = [Up, UpRight, Right, DownRight, Down, DownLeft, Left, UpLeft];
    pub fn delta(self) -> (i32, i32) { match self { /* N=0,-1 etc. */ } }
}
```

```rust
// crates/core/src/vision.rs — doryen-fov wrapper
pub fn compute(origin: TilePos, width: i32, height: i32, radius: i32,
               blocks: &[bool], out: &mut Vec<TilePos>) {
    // blocks[x + y*W] = true = wall (doryen transparent=false)
    // FovRecursiveShadowCasting::new().compute_fov(&mut map, ox, oy, r, true /* light_walls */)
}
```

**draw_world 3단 처리 (★ `crate/render/src/draw_world`)**:
- visible 타일 → 밝은 색 (180,180,200)
- revealed만 → dim (60,60,70)
- hidden → 검정 공백
- entity는 visible 타일 위에서만 `Renderable.glyph` 렌더

**hew ECS borrow rule (★ hecs 0.10)**:
- `world.get::<&Position>(id)` (T가 아닌 `&T` 명시) — `world.get::<Position>(id)`는 컴파일 안 됨 (ComponentRef trait 안 만족)
- hecs `query` 안에서 동시에 borrow 안 됨 — `let snap = viewshed.clone(); let world_ref = &world; draw_world(world_ref, &snap)`로 분리
- mutation: `world.get::<&mut Position>(id)` → viewshed mutable도 마찬가지

FOV 결정성 + wall block + radius limit을 unit test로 검증 (`crates/core/src/vision.rs::tests` 4개).

### Combat + Enemy AI (★ week-3 검증, 2026-07-29)

```rust
// crates/combat/src/attack.rs
pub fn resolve_attack(atk: &Stats, def: &Stats, rng: u32, bonus: i32) -> AttackOutcome {
    // d100 (rng clamped to 0..99): target = 100 - (50 + DEX_atk*2 + bonus) + DEF*3 (dodge)
    // crit if roll >= 95; crit → hit (overrides miss)
    // dmg = MAX(1, STR + d<STR> - DEF_CON/2); crit → dmg * 5 / 2
}

// crates/combat/src/ai.rs (pure-fn, deterministic)
pub fn take_turn<F: Fn(i32, i32) -> bool>(enemy: TilePos, player: TilePos,
                                          vision: i32, kind: AiKind,
                                          passable: F) -> AiAction {
    // 1) Vision 밖 → Idle
    // 2) Adjacent (Chebyshev ≤ 1) → AttackPlayer
    // 3) Chase (AiKind::Chase / PatrolThenChase) → Chebyshev 거리 min
    // 4) Coward → Chebyshev 거리 max
    // 후보 step 8방향 순회, score 작은 게 best, 동점 시 first-seen (stable tie-break)
}

pub enum AiAction { Step(Direction), Wait, AttackPlayer, Idle }
pub enum AiKind { Chase, Coward, PatrolThenChase }
```

**★ 점수 함수 결정성 함정 (week-3 디버깅)**:
- 처음 `score = -dist; if s < b { update }`는 멀리 가는 방향 best로 잘못 작동
- 정답: chase = identity (작을수록 가까움 = 좋음), coware = `-d` (작을수록 멂 = 좋음)
- best 비교는 strict `<` (stable tie-break: 동점은 first-seen 유지)

**App 통합 패턴**:
- `spawn_enemy(world, dungeon, room_idx, glyph, ko_name, hp, stats, vision, kind)` 헬퍼
- `try_player_act(dir)`: 인접 적 → `player_attack(target)`, 빈 바닥 → `move + recompute_fov`, 벽 → bump (no-op)
- `enemy_take_turns()`: snapshot player_pos → 모든 Ai entity의 `take_turn` 호출 → `entity_at` 충돌 검사 → step
- `despawn_dead()`: HP 0 entity 정리 + 메시지 큐

### Items + Inventory (★ week-4 검증, 2026-07-29)

```rust
// crates/core/src/lib.rs
#[derive(Copy, Clone, Debug, Eq, PartialEq)]
pub enum ItemKind { Coin, HealthPotion, ManaPotion, Weapon, Armor }

pub struct Item {
    pub kind: ItemKind,
    pub name: String,       // Korean display
    pub glyph: char,        // ground rendering
    pub fg_rgb: u32,        // 24-bit packed RGB
    pub bonus: i32,         // potions=heal amount, weapons=STR bonus, gold=value
}
// constructors: Item::gold(n), Item::potion_hp(), Item::potion_mp(), Item::weapon(b, name), Item::armor(b, name)

#[derive(Clone, Debug, Default)]
pub struct Inventory {
    pub slots: Vec<Option<Item>>,
    pub max: usize,
}
impl Inventory {
    pub fn new(max: usize) -> Self { Self { slots: vec![None; max], max } }
    /// Returns Ok(idx) on insert, Err(()) if full.
    pub fn push(&mut self, item: Item) -> Result<usize, ()> {
        for (i, slot) in self.slots.iter_mut().enumerate() {
            if slot.is_none() { *slot = Some(item); return Ok(i); }
        }
        Err(())
    }
    pub fn take(&mut self, idx: usize) -> Option<Item> {
        self.slots.get_mut(idx).and_then(|s| s.take())
    }
    pub fn is_empty(&self) -> bool { self.slots.iter().all(|s| s.is_none()) }
}
```

**ground items는 ground entity로 spawn** — Position + Renderable + Item. 그리고 `try_pickup` 함수가 발밑 entity를 inventory로 옮김 + entity despawn:

```rust
world.spawn((Position(TilePos(cx, cy)),
            Renderable::new(glyph_for(kind), color_for(kind)),
            Item::gold(n)));
```

**★ KeyCode 의미 분리 함정 (week-4 실측)**: `KeyCode::Char('>') | KeyCode::Char('.')` 같이 OR로 묶으면 `>` 키와 `.` 키가 **동일한 분기**로 들어가면서 의도와 다른 동작 발생 — `>`(내려가기)과 `.`(wait). 절대 OR로 묶지 말 것. **각 키마다 별도 분기**.

### Floor Theme 다층 변주 (★ week-4 검증)

```rust
#[derive(Copy, Clone, Debug, Eq, PartialEq)]
pub enum FloorTheme { Cave, Catacomb, Garden, Library, Forge, Temple, FinalMaw, Boss }

impl FloorTheme {
    pub fn from_depth(depth: u32) -> Self {
        match depth {
            1..=4 => Self::Cave,        5..=8 => Self::Catacomb,
            9..=12 => Self::Garden,    13..=16 => Self::Library,
            17..=20 => Self::Forge,    21..=24 => Self::Temple,
            25..=27 => Self::FinalMaw, _ => Self::Boss,
        }
    }
    pub fn label(self) -> &'static str { /* Korean: "동굴","카타콤",... */ }
}

pub struct Floor(pub u32);
```

**Per-floor seed 결합** (`App::new_at(seed, floor)`):
```rust
let seed = base_seed.wrapping_add(floor as u64 * 0x9E37_79B9_7F4A_7C15);
```
같은 base_seed로도 층마다 다른 던전. 결정성 보존 (test 가능).

**populate_floor 패턴**: floor 번호를 받으면 적과 loot을 **scale + theme**로 자동 spawn:
```rust
fn populate_floor(world: &mut World, dungeon: &Dungeon, floor: u32, theme: FloorTheme) {
    let scale = floor as i32;
    spawn_enemy(world, dungeon, 1, 'r', "쥐", 6+scale, ..., AiKind::Coward);
    // Tier 2: theme에 따라 적 종류 분기 (Cave=g, Catacomb=S, Forge=T 등)
    let glyph2 = match theme { FloorTheme::Cave | FloorTheme::Garden => 'g', ... };
    spawn_enemy(world, dungeon, 2, glyph2, name, 14+scale*2, ..., AiKind::Chase);
    // Boss floor guard
    if floor == BOSS_FLOOR {
        // 별도 boss spawn — HP 120+ (max_hp > 100 heuristic으로 보스 식별)
    }
    // Loot: 짝수 룸(i%2==0)에 chest — gold/potion/weapon 순환
    for (i, room) in dungeon.rooms.iter().enumerate() { ... }
}
```

### Boss 처치 게이트 (★ week-4 검증)

**max_hp heuristic**: 보스는 일반 적보다 큰 HP로 spawn (120+), 그 후 `despawn_dead()`에서:
```rust
let mut boss: Option<hecs::Entity> = None;
for &e in &dead {
    if let Ok(h) = world.get::<&Health>(e) {
        if h.max > 100 { boss = Some(e); break; }
    }
}
// ... despawn 모두
if boss.is_some() && !self.boss_defeated {
    self.boss_defeated = true;
    self.log(format!("{}층 보스 격파! '>' 내려가기.", self.floor));
}
```

**`>` 키는 BOSS_FLOOR가 아니면 자유롭게 다음 층**, BOSS_FLOOR면 `boss_defeated` 체크:
```rust
KeyCode::Char('>') => {
    if self.floor == BOSS_FLOOR && !self.boss_defeated {
        self.log("보스를 먼저 처치하세요.");
    } else if next_floor > MAX_FLOORS { ... }
    else { *self = App::new_at(seed, next_floor); }
}
```

**이 패턴은 8 floor / 28 floor / 가변 N floor 모두 일반화 가능** — `BOSS_FLOOR` 상수와 비교, `max_hp > THRESHOLD` heuristic.

### Ref<T> deref clone 패턴 (★ week-4 item pickup 함정)

```rust
let cloned = match world.get::<&Item>(e) {
    Ok(r) => Some((*r).clone()),    // 명시적 deref — 직접 .clone()은 안 됨
    Err(_) => None,
};
```

hecs의 `world.get::<&T>(e)`는 `Result<Ref<T>, _>` 반환. `Ref<T>`는 `Deref<Target=T>` 구현하지만 직접 `r.clone()`은 `Ref<T>::clone()` 호출 (different type). **`(*r).clone()` 패턴**으로 안의 `T`를 clone해야 함. 자주 헷갈리는 함정.

**추가 borrow checker rules (week-4 E0502 / E0382 풀었던 것들)**:
1. **`for (e, item) in items { inv.push(item).is_ok() }`** — `items`를 consume하지 않게 `let count = picked.len()` 미리 캡쳐 후 `for e in picked` 사용 → `picked.is_empty()` 호출 가능. 안 그러면 E0382 borrow of moved value.
2. **`world.query::<(&Position, &Item)>().iter().filter_map(...)`** → 모은 `Vec<hecs::Entity>` 따로 분리한 뒤 다시 `world.get::<&Item>(e)` — 단일 query가 immut borrow 잡은 채로 item mutate 불가능.
3. **`world.get::<&mut Inventory>(player)` 후 `world.despawn(e)`** — `Inventory` Ref를 명시적으로 `drop(inv)`로 풀어주고 `for e in picked { world.despawn(e); }`로 분리. 안 그러면 E0502 immut+mut borrow.

### 위임 child 기다리기 (★ 14분 자가실측 패턴 2026-07-29)

**child kickoff 직후의 transcript는 stopped처럼 보이지만 실제 작업 중일 수 있음.** `deleg_34f31fa7`(14m 25s 작업) 사례:
- t=0분: dispatch + transcript "start" 표시, tool 호출 0개
- t=0.5분: 1개 tool 호출 (skill_view)
- t=2분: terminal 호출
- t=14분: 정직 작업 마무리, 200줄 20KB 파일 작성 완료
- **인내심**: dispatch 후 최소 **5분, 보통 10-15분** 기다린 후 transcript를 다시 확인. **`hermes-subagent-diagnosis` §"Common Pitfalls"** 의 fake-empty-response 패턴 교차 검증 권장.

**정직하게 진짜 빈 응답 vs 작업 중**: 파일/저장 상태 직접 검사 → "파일이 disk에 있나?"가 가장 확실한 검증. transcript만 보지 말 것.

### `--dump` 헤드리스 모드 (★ PTY 자동 검증 한계 회피 핵심)

**문제**: Hermes sandbox의 `pty.fork()` + raw mode TUI 검증은 **5분 timeout으로 죽음**, 키 입력 자동화 어려움. 사용자는 PTY 결과를 못 보지만, 헤드리스로 동일 코드 경로를 stdout 출력 가능.

**해결**: binary에 `--dump <args>` 인자 모드 추가 → cargo로 실행 → stdout으로 던전 + FOV + 엔티티 캡처. 사용자가 **직접 화면 확인 없이도** 게임 엔진 결정성 검증.

```rust
// crates/app/src/main.rs
fn main() -> Result<()> {
    let args: Vec<String> = env::args().collect();
    let dump_mode = args.iter().any(|a| a == "--dump");
    if dump_mode {
        let count: u32 = args.windows(2).find(|w| w[0] == "--count")
            .and_then(|w| w[1].parse().ok()).unwrap_or(3);
        let seed: u64 = args.windows(2).find(|w| w[0] == "--seed")
            .and_then(|w| parse_seed(&w[1]).ok())
            .unwrap_or(0xCAFE_BABE_DEAD_BEEF);
        return dump_to_stdout(seed, count);  // BSP + FOV + 엔티티 stdout
    }
    if args.iter().any(|a| a == "--help" || a == "-h") {
        eprintln!("Usage: asciirogue ... [--dump] [--help]");
        return Ok(());
    }
    // panic hook + TUI main loop
    run().context("asciirogue runtime error")
}
```

**검증 워크플로 (PTY 사용 안 함)**:
```bash
# 1) 빌드 + 테스트
cargo build --release
cargo test

# 2) 헤드리스 캡처
./target/release/asciirogue --dump --count 3 --seed 0xCAFE > /tmp/floor.txt
./target/release/asciirogue --dump --count 1 --seed 0xCAFEBABE | head -25

# 3) 사용자 자체 TUI 검증 (cargo run, 본인이 보는 화면)
cargo run --release
```

**왜 `--dump`가 검증 값어치가 큰가**:
- `seed → output` 결정성 검증
- FOV 정확성 (`visible N` 헤더로 벽 뒤 시야 차단 확인)
- 엔티티 스폰 위치 검증
- 시야 안 적 위치에 `g` 같은 글리프 출력 확인
- 다음 PR / 다음 세션에서도 같은 헤드리스 패턴 유지

이건 **모든 TUI 게임 부트스트랩의 기본 패턴**이어야 함 — `cargo run` user 검증 + `--dump` 자동 검증 둘 다 챙기는 것.

### ★ Probe-Direct 검증 (handles `App::handle(&Event)` directly) — `references/probe-direct-verification.md`

**`--dump`로 안 잡히는 케이스**: 사용자가 "Y는 무엇이지?", "X가 작동해?", "변화가 없음"이라고 핀포인트 키 동작 지적하면 **probe가 키를 직접 synthesise**.

```rust
// crates/app/Cargo.toml — lib + binary 둘 다 선언
[[bin]] name = "asciirogue", path = "src/main.rs"
[lib]  name = "asciirogue", path = "src/lib.rs"

// crates/app/src/lib.rs — pub API for probes
impl App {
    pub fn step(&mut self, dir: Direction) -> bool { ... }
    pub fn world_ref(&self) -> &hecs::World { &self.world }
    pub fn world_mut(&mut self) -> &mut hecs::World { &mut self.world }
    pub fn messages(&self) -> &[String] { &self.messages }
}

// crates/app/examples/key_probe.rs — drive the real handler, no TTY
use asciirogue::App;
use crossterm::event::{Event, KeyCode, KeyEvent, KeyEventKind, KeyModifiers};
fn press(app: &mut App, code: KeyCode) {
    app.handle(&Event::Key(KeyEvent {
        code, modifiers: KeyModifiers::NONE,
        kind: KeyEventKind::Press, state: KeyEventState::NONE,
    }));
}
// ... test 7+ scenarios, print result of each, assert expected messages.
```

**장점**: probe가 진짜 키 매핑을 직접 검증 → 스크린샷 의존 X, 사용자가 "X가 작동 안 하는데" 할 때 정확한 진단. `App::handle`이 `pub`이어야 동작. `world_mut`까지 노출하면 teleport/인벤 채우기 가능.

**v0.5.4에서 발견한 pickup tri-state enum** (이 reference 파일 §"Pickup tri-state 결과 enum 패턴" 절 참고):

```rust
// BAD: bool → caller 메시지가 두 케이스 구분 못함
pub fn try_pickup(world: &mut World, player: hecs::Entity) -> bool

// GOOD: tri-state — 사용자한테 세 가지 결과 구분 메시지
#[derive(Copy, Clone, Debug, Eq, PartialEq)]
pub enum PickupOutcome { NoItem, Picked, InventoryFull }
pub fn pick_up_outcome(world: &mut World, player: hecs::Entity) -> PickupOutcome { ... }
```

`Inventory::push` → `Result<(), ()>` 같은 함수가 호출자한테 "정확히 무슨 일이 일어났는지" 안 알려주는 함정. pickup/equip/sell/buy 같은 모든 mutation API에 적용.

### ratatui 0.29 + deps 정확 버전

```toml
ratatui = "0.29"        # 0.30+ Buffer API 변경됨
crossterm = "0.28"      # 0.29 일부 변경
hecs = "0.10"           # light ECS
```

### 위임 child 보고 함정 (★ 운영 패턴)

이번 세션의 `deleg_34f31fa7` (Rust 레퍼런스 조사 14분):
- dispatch 직후 5분 transcript 확인 → kickoff tool 호출 후 stop 표시
- **빈 응답 보고 가정 후 직접 작업 시작** ← 실수
- **14분 후 실제 완료** — 200줄 20KB 보고서 정직하게 작성
- **결론**: 위임 child 의 initial transcript stop 은 "self-report 즉시 보고"가 아니라 "kickoff stop". **15-30분 기다려야 진짜 self-report 도착**. **transcript 의 "stop" 단어만 보고 추측하지 말 것**.
- **detail**: `hermes-subagent-diagnosis` SKILL.md §"Common Pitfalls #12" 참조. 거기 same-session 2회 빈 응답 보고 = 룰 격상 패턴이 정리돼 있음.

## 검증 체크리스트

- [ ] Rust 툴체인 stable minimal profile 설치 (rustfmt/clippy 추가 가능)
- [ ] Workspace 5-crate 구조
- [ ] `crates/core` 컴파일 + ENERGY_PER_TURN 상수 + 1 테스트
- [ ] `crates/procgen` BSP 재귀 split + 결정론 RNG + 결정론/차이 테스트
- [ ] `crates/combat` 5종 StatusKind + DamageFormula::roll
- [ ] `crates/render` `wall_glyph` + `draw_map` + 2 테스트
- [ ] `crates/app` panic hook + 키바인딩 (q=quit, r=new seed)
- [ ] `cargo build`, `cargo test`, `cargo run --example dump` 모두 통과
- [ ] 4-PNG 비교 (ASCII/half-block/Braille/Kitty) 생성 → 사용자 의사결정
- [ ] 헤드리스 stdout 던전 출력 1장이라도 캡처
- [ ] **(GitHub 공개 시)** `gh repo create --public` 후 path 오타 부산물 cleanup → `git ls-files | grep -E '</|path>'` 비어 있는지 확인

## 관련 references / templates / scripts

- `references/scaffold.md` — 5-crate Cargo.toml + src/lib.rs 검증된 스니펫
- `references/visual-paradigm-comparison.md` — half-block vs ASCII vs braille 의사결정 자료
- `references/half-block-wall-glyph-deep-dive.md` — 4-bit mask 16 경로 + 색상 팔레트
- `references/bsp-fallthroughs.md` — recursive BSP 함정
- `references/ecs-component-catalog.md` — Position/Renderable/CombatStats/AIPath/Vision hecs 시그니처
- `references/rust-build-errors-quickref.md` — E0502/E0596/elided_lifetimes/buffer indexing cheat sheet
- `references/visual-samples-render-html-template.md` — qlmanage용 HTML 템플릿
- **`references/ecs-fov-system.md`** — ECS + FOV 7-step 패턴 (hecs 0.10 + doryen-fov 0.1)
- **`references/combat-ai.md`** — combat/attack/AI pure-fn + App 통합 + ★ score 부호 함정
- **`references/headless-dump-pattern.md`** — `--dump` 헤드리스 검증 패턴 (PTY 한계 우회)
- **`references/probe-direct-verification.md`** — ★ `App::handle(&Event)` + `examples/` probe로 키 단위 직접 검증 (사용자가 "변화가 없음"이라고 할 때 정답)
- **`references/items-inventory-floor-cycle.md`** — ★ week-4 패턴 (Item/Inventory/FloorTheme/boss gate/Ref deref clone)
- **`references/i18n-meta-saveload.md`** — ★ week-5 패턴 (i18n enum + t_format positional + Soul Remembrance + saturating caps + on_run_end pure + RON save to XDG + `S`/`L`/`?` key 3종)
- `templates/Cargo.toml` — workspace 루트 보일러플레이트
- `templates/lib.rs.core` / `lib.rs.procgen` / `lib.rs.render` / `main.rs.app` — 빈 보일러
- `scripts/dump-headless.sh` — `cargo run --example dump | tee` 캡처 스크립트
- `scripts/visual-samples-build.sh` — qlmanage로 4-PNG 자동 빌드
- `scripts/probe-key-direct.sh` — ★ `examples/key_probe` 빌드 + 실행 + panic 마커 grep (probe-direct 검증 자동화)
