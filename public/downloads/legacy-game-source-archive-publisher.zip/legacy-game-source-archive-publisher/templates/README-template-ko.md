# README Template (Korean, for Legacy Game Archive)

This is the section skeleton to follow for any legacy Windows game archive published to GitHub.

---

```markdown
# 🎮 <Game Title> — <Korean subtitle>

> <One-sentence Korean elevator pitch describing genre + platform + notable feature>.
> 비영리 개인 프로젝트로, 본인이 직접 작성한 C++ 소스와 게임 리소스를 공개합니다.

![platform](https://img.shields.io/badge/platform-Windows-0078d4?style=flat-square) ![lang](https://img.shields.io/badge/C%2B%2B-VC%2B%2B%206.0-00599c?style=flat-square) ![graphics](https://img.shields.io/badge/graphics-DirectDraw7-red?style=flat-square) ![sound](https://img.shields.io/badge/sound-DirectSound-blue?style=flat-square) ![input](https://img.shields.io/badge/input-Keyboard+%2B+Mouse-green?style=flat-square) ![license](https://img.shields.io/badge/license-MIT-blue?style=flat-square)

---

## 📸 관련 자료   ← IMPORTANT: TOP, not bottom

> 🎯 이 자료는 본 저장소의 직접적인 선행/동기 작업입니다.

### <시제품 / 원본 프로젝트명> 스크린샷

| 항목 | 내용 |
|---|---|
| 원본 파일 | `manual/Etc/<KEY>.htm` + `manual/Etc/<KEY>.jpg` |
| 개발 기간 | <decoded from EUC-KR HTM> |
| 환경 | <DirectX 버전 등> |
| 비고 | <핵심 컨셉> |

![<KEY> screenshot](docs/<KEY>-screenshot-<year>.jpg)

> **개발자 노트(EUC-KR 원문 발췌)**: "<decoded quote>"

### 본 게임과의 연결
| 선행 항목 | 본 게임의 대응 |
|---|---|
| <X> | <경로/모듈> |

### 같은 시리즈 부록
| 약어 | 시기 | 원본 위치 | 비고 |
|---|---|---|---|

---

## 📜 목차

- [개요](#-개요)
- [🎮 게임 컨셉](#-게임-컨셉)
- [🖼️ 게임 화면 미리보기](#️-게임-화면-미리보기)
- [✨ 주요 특징](#-주요-특징)
- [⌨️ 조작](#️-조작)
- [📂 폴더 구성](#-폴더-구성)
- [🧱 코드 모듈](#-코드-모듈)
- [🧬 시스템 아키텍처](#-시스템-아키텍처)
- [<Game-specific sections>]
- [🎨 그래픽 시스템](#-그래픽-시스템)
- [🔊 사운드 시스템](#-사운드-시스템)
- [⚙️ 빌드 환경](#️-빌드-환경)
- [🔨 빌드 방법](#-빌드-방법)
- [🐛 알려진 한계](#-알려진-한계)
- [📜 라이선스](#-라이선스)
- [📁 원본 출처](#-원본-출처)

---

## 개요

**<Game Title>**는 Windows용 <장르>입니다.
<시대, 환경, 기술 요약>.

원본 폴더에 남아 있는 `<핵심 자료 파일>`은 게임의 <무엇을> 담고 있어, <왜 중요한지>.

---

## 🎮 게임 컨셉

- 장르
- 플랫폼
- 엔진
- 해상도 / 색상
- 스테이지 / 보스 수
- 입력 방식
- 점수 / RPG 시스템 요약

---

## 🖼️ 게임 화면 미리보기

[ASCII art 다이어그램 - 한 줄 80자 이내 박스 형태]

---

## ✨ 주요 특징

| 영역 | 설명 |
|---|---|
| 🎨 렌더링 | DirectDraw 7 + ... |
| ⌨️ 입력 | ... |
| 🏛️ 보스 | ... |
| ... | ... |

---

## ⌨️ 조작

| 입력 | 동작 |
|---|---|
| 키 | 동작 |
| 키 | 동작 |

매크로 정의 (있다면):
```cpp
#define KeyDown(vk_code) ...
```

---

## 📂 폴더 구성

```text
<프로젝트>/
├── 소스 파일들 (.cpp/.h)
├── Data/
│   ├── Image/
│   └── Sound/
├── 매뉴얼 (한국어)
└── 빌드 파일 (.dsp/.dsw)
```

---

## 🧱 코드 모듈

### 메인 게임 (<헤더 파일>)

```cpp
// 핵심 상수 + 매크로 + 글로벌 변수
```

### <핵심 클래스 1>

```cpp
class CXxx : public CObject {
    // 멤버 + 메서드 시그니처
};
```

### <핵심 클래스 2>

(...)

### 모듈 표

| 모듈 | 역할 |
|---|---|
| 모듈명 | 역할 |

---

## 🧬 시스템 아키텍처

### 게임 루프

```text
[WinMain]
  ↓
[InitInstance]
  ↓
[Game Loop]
  ↓
[Cleanup + Exit]
```

### 클래스 다이어그램

```
        ┌──────────────┐
        │   CObject    │  (추상)
        └──────┬───────┘
               │ 상속
     ┌─────────┼──────────┐
     │         │          │
[파생 클래스들]
```

### 데이터 흐름

(...)

---

## <Game-specific sections>

### <주요 시스템 1>
### <주요 시스템 2>

---

## 🎨 그래픽 시스템

### DirectDraw 7 서피스

```cpp
extern LPDIRECTDRAWSURFACE7 ...
```

### 스프라이트 시트

(...)

---

## 🔊 사운드 시스템

(...)

---

## ⚙️ 빌드 환경

| 항목 | 값 |
|---|---|
| 플랫폼 | Windows (Win32) |
| 언어 | C++ (VC++ 6 스타일) |
| 해상도 | 800×600 |
| 그래픽 | DirectDraw 7 SDK |
| 컴파일러 | Microsoft Visual C++ 6.0 |
| 프로젝트 파일 | `<project>.dsp`, `<project>.dsw` |

---

## 🔨 빌드 방법

### Visual C++ 6.0

```cmd
cd <project>
devenv <project>.dsw /Build Release
```

### Visual Studio 2005 이상

(...)

---

## 🐛 알려진 한계

1. VC++ 6 빌드 시스템
2. DirectDraw 7 호환성
3. 전역 변수 남용
4. 한글 인코딩
5. ...

---

## 📜 라이선스

- 본 저장소의 **소스 코드와 게임 리소스**는 MIT 라이선스로 공개합니다.
- 다음은 본 저장소에 포함되어 있지 않습니다:
  - **Visual C++ 6.0** — Microsoft 소유
  - **DirectDraw/DirectInput/DirectSound SDK** — Microsoft 소유
- 본 프로젝트는 비영리 개인 학습·아카이브 목적입니다.

---

## 📁 원본 출처

이 저장소는 다음 경로의 사본입니다.

```text
~/work/backup/01-public/<path>/<ProjectName>/
```

원본 빌드 산출물과 사용자 환경 파일은 공개 저장소에서 제외했습니다.

---

> 🕹️ **Tip**: Windows 10 이상에서는 호환성 모드로 실행해야 할 수 있습니다.
```