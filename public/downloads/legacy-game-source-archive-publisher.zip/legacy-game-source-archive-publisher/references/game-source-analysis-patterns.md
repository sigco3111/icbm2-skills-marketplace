# Game Source Analysis Patterns

How to quickly identify genre, engine, controls, AI, and asset layout from header files alone, without reading every file.

## First read: `main.h` or top-level header

Every legacy Win32 game has a `main.h` or `<ProjectName>.h` at the project root that includes all other headers. Read it FIRST.

```cpp
// Indicators to look for in main.h:

#include <ddraw.h>       → DirectDraw 7 (2000s era Windows game)
#include <dinput.h>      → DirectInput keyboard/mouse
#include <dsound.h>      → DirectSound audio
#include <Mmsystem.h>    → Windows Multimedia (timeGetTime, midi)
#include <wincon.h>      → Win32 console API (only for console games)
#include <iostream.h>    → Pre-standard C++ (VC++ 6 era)
```

| Header pattern | Era | Engine |
|---|---|---|
| `<ddraw.h>` + `<dinput.h>` + `<dsound.h>` | 2001-2004 | DirectX 7 |
| `<ddraw.h>` + `<dinput.h>` only | 2001-2003 | DirectX 7 audio via winmm |
| `<windows.h>` + `<wincon.h>` only, no `<ddraw.h>` | 2000-2002 | Win32 Console (no graphics) |

## Read second: character / enemy / player class headers

The class names in headers reveal the game design.

```cpp
class CPlayer : public CObject { ... }    → 표준 플레이어
class CBoss1, CBoss2, CBoss3            → 멀티 보스 (스테이지 진행형)
class CEnemy, CEnemy2, CEnemy3            → 적 종류 (단계별 난이도)
class CHero : public CObject {             → 액션 RPG 주인공
    BOOL m_jump; int m_jumpPower; int m_gravity;  → 점프 물리
    CQueue<int> InputQue;                       → 커맨드 큐 (격투 게임)
    CInputStack<int> InputStack;
};
class CMap {                              → 맵 시스템
    BYTE Mapchk(...);                        → 충돌 판정
};
class CScore {                            → 점수 시스템
    long lScore[10]; char name[10][21];    → 상위 10개 점수
};
```

## Specific genre markers

### Vertical shooting (슈팅)
- `Bullet`, `Missile`, `Enemy` 단수형 클래스
- `MissileA, MissileB, MissileC, MissileD` → 다단 미사일
- `Bullet_Move()` 또는 `Update()`에서 단발·확산·유도 패턴
- HP바, 점수, 콤보 카운터
- 보스 클래스: `CBoss1, CBoss2, CBoss3` 또는 신화 기반 이름 (`AIAS`, `TYPHON`, `ARACHNE`)

### Side-scrolling action (횡스크롤 액션)
- 점프/중력 멤버 (`m_jump`, `m_gravity`)
- 콤보 입력 큐 (`m_Comm[8]`, `InputQue`, `InputStack`) → 격투 게임
- 다중 적 (돼지/병아리/뱀 류)
- 보스: `Boss1_Fire`, `Boss1_Missile`, `Boss3_Ston` 등 다단 공격

### Action RPG (액션 RPG)
- 5+ 종 플레이어블 캐릭터
- 마을 시스템 (호텔, 무기점, 갑옷점, 아이템점)
- HP/SP 시스템, 인벤토리, 장비 조합
- 스테이지 맵 (`Stage01-01_Map.Map` 등)
- 엔딩 일러스트

### Board game (보드게임)
- 국가 정보 (`국가정보.txt`), 부동산 시세 (`부동산시세.txt`)
- 도시·랜드마크·호텔 개념
- `AI`, `CPU_FCard`, `Dice` 클래스
- 28개국 보드 (부루마블 류)

### Console (콘솔)
- `<wincon.h>` 사용
- `Console` 클래스로 커서 이동·색상 속성 처리
- `SetConsoleCursorPosition`, `SetConsoleTextAttribute`
- 그래픽 클래스 없음 (전부 ASCII)

## Asset layout patterns

| Game type | Sprite path | Sound path | Map path |
|---|---|---|---|
| GP32 | `GPMM/<project>/Data/{Img,PCM}/` | `GPMM/<project>/Data/PCM/` | (없음) |
| Win32 DirectDraw 7 | `Data/Image/<category>/` | `Data/Sound/` | `Data/Map/*.Map` |
| Win32 DirectDraw 단일 | `Data/Image/` | `Data/Sound/` | `Data/Map/` |

## Sprite sheet index files

`.txt` 파일이 정확한 프레임 수와 경로를 명시하면, 자동으로 로드 코드와 매핑됩니다.

```text
# 예: ARACHNE.txt
10
Data\Image\ARACHNE\00
Data\Image\ARACHNE\01
...
Data\Image\ARACHNE\09
```

이런 인덱스가 있으면 README의 "보스 스프라이트 시트" 표에 정확한 프레임 수를 적을 수 있습니다.

## Dev notes 발견

`*.TXT`, `*.txt`, `*.htm`(EUC-KR)이 다음 위치에 자주 있습니다:

- `도움말/` — 게임 내 매뉴얼 (한글 파일명 다수)
- `manual/Etc/` — 개발자 노트 (시리즈 다른 프로젝트史料)
- `<project>/` 루트의 `*.TXT` — 기획 메모, 경험치 표, 점수 데이터, 스프라이트 시트 인덱스

## Final sanity check

Before writing README, run:

```bash
grep -h "^class\|^struct\|^enum" *.h | head -40
```

이 40줄만 보면 게임의 핵심 구조가 다 드러납니다. README의 "🧱 코드 모듈" 표에 그대로 옮기면 됩니다.