# File Exclusion Checklist

Per-archive-type exclusion rules. Run all of these before `git add` to keep the public repo clean. Use the inline Python snippet at the bottom.

## Universal (all archives)

| Pattern / Path | Why exclude |
|---|---|
| `.DS_Store` | macOS Finder metadata, not user-meaningful |
| `Thumbs.db`, `Thumbs.db:encryptable` | Windows thumbnail cache |
| `desktop.ini` | Windows folder metadata |
| `*.bak`, `*.tmp`, `*.swp`, `*.swo` | Editor temp files |
| `~$*.*` | Office / Photoshop lock files |

## Visual C++ 6 / Visual Studio 2005

| Pattern | Why |
|---|---|
| `*.opt`, `*.plg`, `*.ncb`, `*.positions`, `*.suo`, `*.aps`, `*.user`, `*.userosscache`, `*.sdf`, `*.opensdf` | User/IDE environment files, contain local paths |
| `*.dsp`, `*.dsw` | **KEEP** — VC++ 6 project files, source of truth |
| `*.vcproj`, `*.sln` | **KEEP** — VS2005+ project files |
| `Debug/`, `Release/`, `debug/`, `release/` | Build output folders (case-sensitive on Linux) |
| `*.obj`, `*.sbr`, `*.pdb`, `*.idb`, `*.pch`, `*.ilk`, `*.bsc`, `*.res`, `*.tlog`, `*.lastbuildstate` | Compiled object / debug symbol files |
| `BuildLog.htm` | Local build log |
| `*.exe`, `*.dll` | Built binaries (keep in repo only if Releases page not used) |
| `*.exp`, `*.lib` | Export / import libraries (rebuild from sources) |
| `*.log`, `*.dep` | Build logs / dependency cache |
| `StdAfx.cpp`, `StdAfx.h` | **KEEP** — VC++ precompiled header source |

## DirectX SDK content

| Pattern / Path | Why |
|---|---|
| `*.dll` (in source tree) | If DirectX redistributable DLLs were copied into project — exclude |
| `DirectX SDK/` folder | **EXCLUDE entirely** — Microsoft SDK |
| `*.lib` for DirectX (`ddraw.lib`, `dinput.lib`, `dsound.lib`) | System libraries, not part of source |

## GP32 / GamePark specific

| Pattern / Path | Why |
|---|---|
| `ads/ads.zip` | **ARM Developer Suite** — paid SDK, **NEVER include**. Even when stripped, leave a NOTE in README explaining that ADS is required separately. |
| `gp32-toolchain/*` | GP32 GCC toolchain (paid distribution) |
| `GPMM/`, `FxeMaker/`, `geepee32/`, `GPDevTool/`, `GPDevUtil2/`, `MakeManager/` | GP32 tool binaries (referenced via `.lnk` shortcuts but never committed) |
| `__*.lnk`, `__*.exe.lnk`, `make_*.lnk` | Windows shortcut icons to local tools |

## General Windows shortcuts

| Pattern | Why |
|---|---|
| `*.lnk` | Windows shortcut files — meaningless without the target |

## Korean / EUC-KR archive files

| Pattern | Why |
|---|---|
| `*.zip` (full project backup) | Almost always redundant with the project folder itself — exclude |
| `*.bak`, `*.bk` | Backups |
| `도움말/Help.bak` | Backups of help HTML |
| `*.tmp`, `~*` | Editor temp |
| `*.dat` (game data) | **KEEP unless huge** — often holds save data or sprite indices |
| `*.sfk` (game audio) | **KEEP** — original game audio format |

## Notes about the `output.dat` file

Some games (e.g. `consol_shooting`) have an `output.dat` file at the project root. This is **runtime game data**, not a build artifact — **KEEP** but mention in README that its structure is undocumented (refer to `xxx.cpp` for parsing).

## Zips and binaries inside the source folder

Sometimes developers left zip backups inside the source folder. These are usually redundant and add noise:

| Pattern | Why |
|---|---|
| `ProjectName.zip` (in project root) | Backup of source folder — exclude |
| `*소스.zip`, `*코드만.zip` | Code-only backups — exclude |
| `manual/Etc/*.zip` | If present, exclude |

If the README has screenshots that are zipped separately, **unzip them first** and add the JPGs to `docs/` instead.

## Inline Python snippet (drop into `execute_code` or `terminal`)

```python
from pathlib import Path
import shutil, fnmatch

root = Path('/Users/mac/work/github/<repo-name>')

# Patterns to delete (file or empty dir match)
patterns = [
    '*.opt', '*.plg', '*.ncb', '*.positions', '*.aps', '*.suo',
    '*.user', '*.userosscache', '*.sdf', '*.opensdf',
    '*.obj', '*.sbr', '*.exe', '*.pdb', '*.idb', '*.pch', '*.ilk',
    '*.bsc', '*.res', '*.tlog', '*.lastbuildstate', '*.exp', '*.lib',
    '*.log', '*.dep', '*.bak', '*.tmp', '*.swp', '*.swo',
    'BuildLog.htm', 'Thumbs.db', 'desktop.ini',
    '*.lnk',  # Windows shortcuts
    '*.zip',  # project backups (review manually if you want to keep some)
]

# Directories to delete (any depth)
dirs_to_delete = ['Debug', 'Release', 'debug', 'release', '.vs', '.vscode']

removed_count = 0
removed_bytes = 0

for f in list(root.rglob('*')):
    if not f.is_file():
        continue
    for pat in patterns:
        if fnmatch.fnmatch(f.name, pat):
            removed_bytes += f.stat().st_size
            f.unlink()
            removed_count += 1
            break

# Delete specific named files
for special in ['ads.zip', 'ads/ads.zip']:
    p = root / special
    if p.exists() and p.is_file():
        removed_bytes += p.stat().st_size
        p.unlink()
        removed_count += 1

# Remove empty build dirs
for d in sorted(root.rglob('*'), key=lambda p: -len(p.parts)):
    if d.is_dir() and not any(d.iterdir()) and d.name in dirs_to_delete:
        try: d.rmdir()
        except OSError: pass

print(f'Removed {removed_count} files, {removed_bytes/1024/1024:.1f} MB')
```

## Manual review after the script runs

Always `ls -la` the result and confirm:

- No `Debug/` or `Release/` folders left
- No `*.exe` files
- No `*.zip` (unless intentional)
- `.dsp`/`.dsw`/`.vcproj`/`.sln` project files **present**
- Source files (`.cpp`/`.h`) **present**
- Game assets (`.bmp`, `.wav`, `.mp3`, `.Spr`, `.Map`, `.SEF`, `.sfk`) **present**
- `.gitignore` and `README.md` and `LICENSE` at the root

If a `Debug/` or `Release/` folder remains with content you want to keep (e.g. release binaries with side-by-side `PleasureGate.exe`), reconsider whether to keep — usually the safer choice is to exclude and rely on GitHub Releases for distribution.