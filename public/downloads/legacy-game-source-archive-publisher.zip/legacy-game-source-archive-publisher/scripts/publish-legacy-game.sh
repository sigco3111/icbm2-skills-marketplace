#!/usr/bin/env bash
# publish-legacy-game.sh
# Complete pipeline: stage archive → strip artifacts → write README/LICENSE →
# commit → push to public GitHub repo → verify.
#
# Usage:
#   ./publish-legacy-game.sh <source-folder> <repo-name> "<description>" "<commit-msg>"
#
# Example:
#   ./publish-legacy-game.sh \
#       "/Users/mac/work/backup/01-public/Win/PleasureGate" \
#       pleasuregate-shmup \
#       "PleasureGate Windows 슈팅 게임 (비영리, 공개)" \
#       "PleasureGate 슈팅 게임 공개 릴리스"

set -euo pipefail

SOURCE="$1"
REPO_NAME="$2"
DESCRIPTION="$3"
COMMIT_MSG="$4"

WORK_DIR="/Users/mac/work/github/${REPO_NAME}"

echo "=== 1. Stage working copy ==="
mkdir -p /Users/mac/work/github
rm -rf "${WORK_DIR}"
cp -a "${SOURCE}" "${WORK_DIR}"
echo "  → ${WORK_DIR}"

echo "=== 2. Strip build artifacts ==="
python3 <<PYEOF
from pathlib import Path
import fnmatch
root = Path("${WORK_DIR}")
patterns = [
    '*.opt','*.plg','*.ncb','*.positions','*.aps','*.suo',
    '*.user','*.userosscache','*.sdf','*.opensdf',
    '*.obj','*.sbr','*.exe','*.dll','*.pdb','*.idb','*.pch',
    '*.ilk','*.bsc','*.res','*.tlog','*.lastbuildstate','*.exp',
    '*.lib','*.log','*.dep','*.lnk','*.zip','*.bak','*.tmp',
    'BuildLog.htm','Thumbs.db','desktop.ini',
]
removed = removed_bytes = 0
for f in list(root.rglob('*')):
    if not f.is_file(): continue
    for pat in patterns:
        if fnmatch.fnmatch(f.name, pat):
            removed_bytes += f.stat().st_size
            f.unlink()
            removed += 1
            break
# GP32 special: remove ads.zip and the ads/ folder if present
for special in ['ads.zip', 'ads/ads.zip']:
    p = root / special
    if p.exists() and p.is_file():
        removed_bytes += p.stat().st_size
        p.unlink()
        removed += 1
# Remove empty build dirs
for d in sorted(root.rglob('*'), key=lambda p: -len(p.parts)):
    if d.is_dir() and not any(d.iterdir()) and d.name in {'Debug','Release','debug','release'}:
        try: d.rmdir()
        except OSError: pass
print(f'Removed {removed} files, {removed_bytes/1024/1024:.1f} MB')
PYEOF

echo "=== 3. Add .gitignore + LICENSE (if not present) ==="
if [ ! -f "${WORK_DIR}/.gitignore" ]; then
  # Copy from skill template
  SKILL_DIR="$HOME/.hermes/skills/automation/legacy-game-source-archive-publisher"
  cp "${SKILL_DIR}/templates/.gitignore-template" "${WORK_DIR}/.gitignore"
  echo "  → .gitignore created"
fi
if [ ! -f "${WORK_DIR}/LICENSE" ]; then
  SKILL_DIR="$HOME/.hermes/skills/automation/legacy-game-source-archive-publisher"
  # Replace <YEAR> with current year
  YEAR=$(date +%Y)
  sed "s/<YEAR>/${YEAR}/g" "${SKILL_DIR}/templates/LICENSE-MIT-template" > "${WORK_DIR}/LICENSE"
  echo "  → LICENSE created"
fi

echo "=== 4. git init + commit ==="
cd "${WORK_DIR}"
git init -q -b main
git config user.email "[email protected]"
git config user.name "sigco3111"
git add .
git status --short | wc -l | xargs -I {} echo "  → {} files staged"
git commit -q -m "${COMMIT_MSG}"
git log --oneline -1

echo "=== 5. gh repo create --public --push ==="
gh repo create "${REPO_NAME}" --public \
  --description "${DESCRIPTION}" \
  --source . --push 2>&1 | tail -5

echo "=== 6. Verify ==="
gh repo view "${REPO_NAME}" --json name,visibility,url,defaultBranchRef,description 2>&1 | head -10
echo "---"
gh api "repos/sigco3111/${REPO_NAME}/contents/" \
  | python3 -c "import sys,json; r=json.load(sys.stdin); print(f'Root items: {len(r)}'); [print(f'  {e[\"type\"]:5} {e[\"name\"]}') for e in r[:20]]"
echo "---"
gh api "repos/sigco3111/${REPO_NAME}/commits/main" \
  | python3 -c "import sys,json; c=json.load(sys.stdin); print(f'Latest commit: {c[\"sha\"][:7]}  {c[\"commit\"][\"message\"].splitlines()[0]}')"
echo "---"
gh api "repos/sigco3111/${REPO_NAME}/readme" \
  | python3 -c "import sys,json; r=json.load(sys.stdin); print(f'README: {r[\"size\"]} bytes')"

echo ""
echo "✓ Done. URL: https://github.com/sigco3111/${REPO_NAME}"