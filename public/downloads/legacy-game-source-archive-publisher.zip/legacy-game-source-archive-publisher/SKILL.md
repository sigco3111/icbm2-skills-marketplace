---
name: legacy-game-source-archive-publisher
description: "Publish a legacy game source archive to GitHub."
trigger: "Use when publishing a legacy game source archive as a new GitHub repo."
last_updated: 2026-07-31
status: active
---

# Legacy Game Source Archive → GitHub Publisher

Class-level skill for taking a single legacy game project folder (C/C++ Windows DirectX-era project, with sprite BMPs, sound WAVs, dev notes) and publishing it as an individual public GitHub repository with a polished bilingual README.

## Core principles

1. **NEVER touch the original archive.** Always work on a copy under `/Users/mac/work/github/<repo-name>/`. Originals stay byte-identical.
2. **One project per repository.** Never combine multiple game projects into one repo.
3. **Default to public.** Only ask the user if a project should be private when it contains company code, paid SDKs, or other restricted assets.
4. **Historical context is part of the README.** `manual/Etc/*.htm`, `*.TXT` planning notes, `*.txt` index files are史料 (archival evidence), not noise. Decode EUC-KR HTM and surface dates / teams / decisions.
5. **Related materials go at the TOP of the README, not the bottom.** User explicitly corrected this: "위치를 목차 위로 변경해줘". Screenshot of developer's contemporary project, series table of related games, and connection-to-other-projects section all belong right after the TOC, before "개요".

## Workflow (8 steps)

### 1. Analyze the source archive
- `find` the project for top-level layout (cpp/h/bmp/wav/spr/sfk/etc.)
- `du -sh` to estimate size
- Read key headers (`main.h`, character class, player class) — they reveal genre, controls, AI patterns
- Read any `*.TXT` / `*.txt` notes — dev timelines, frame indices, asset counts
- For Korean dev notes in `*.htm` files, decode EUC-KR (see `references/euckr-htm-dev-notes.md`)

### 2. Stage the working copy
```bash
mkdir -p /Users/mac/work/github
cp -a "/path/to/original/<ProjectName>" /Users/mac/work/github/<repo-name>
```

### 3. Strip build artifacts
Run inline Python to remove (use `fnmatch` for case-insensitive glob, iterate `rglob('*')` bottom-up):
- `*.opt *.plg *.ncb *.positions *.aps *.suo` (VC++ environment)
- `*.obj *.sbr *.exe *.pdb *.idb *.pch *.ilk *.bsc *.res *.tlog`
- `Debug/ Release/ debug/ release/` folders
- `*.lnk` (Windows shortcut icons)
- `*.zip` (duplicate of source dir)
- `.DS_Store`
- GP32 archives must also remove `ads.zip` (ARM Developer Suite, paid SDK)

### 4. Copy historical screenshots (if any)
```bash
mkdir -p <repo>/docs
cp /path/to/manual/Etc/<KEY>.jpg <repo>/docs/<KEY>-screenshot-<year>.jpg
```
The `manual/Etc/` folder contains developer's contemporary project screenshots with EUC-KR HTM wrappers.

### 5. Write the README
See `templates/README-template-ko.md` for the full pattern. Required section order:
1. Title with shields.io badges (platform / lang / graphics / sound / input / license)
2. **📸 관련 자료 (TOP — not bottom!)** — screenshot + series table + connection-to-other-projects
3. 📜 목차 (anchor links)
4. 개요
5. 🎮 게임 컨셉
6. 🖼️ 게임 화면 미리보기 (ASCII diagram)
7. ✨ 주요 특징 (table of 10+ feature rows)
8. ⌨️ 조작 / 커맨드
9. 📂 폴더 구성 (emoji tree)
10. 🧱 코드 모듈 (with header snippets)
11. 🧬 시스템 아키텍처 (game loop + class diagram)
12. Game-specific sections
13. 🎨 그래픽 시스템 + 🔊 사운드 시스템
14. ⚙️ 빌드 환경 + 🔨 빌드 방법
15. 🐛 알려진 한계
16. 📜 라이선스
17. 📁 원본 출처

### 6. Add .gitignore + LICENSE
- .gitignore: VC++/VS env files, build outputs, `.lnk`, `.DS_Store`, IDE dirs. For GP32: `ads.zip` always excluded.
- LICENSE: MIT, dated to original copyright year, with NOTE that DirectX/DirectDraw SDK / Visual C++ are NOT included.

### 7. Commit + push
```bash
cd /Users/mac/work/github/<repo-name>
git init -q -b main
git config user.email "[email protected]"
git config user.name "sigco3111"
git add .
git commit -q -m "<Korean one-line summary>

- <module>: <description>
- 공개: <asset types> (MIT)
- 제외: <excluded types>"

gh repo create <repo-name> --public \
  --description "<Korean description>" \
  --source . --push
```

### 8. Verify (always)
```bash
gh repo view <repo-name> --json name,visibility,url,defaultBranchRef,description
gh api repos/sigco3111/<repo-name>/contents/ | python3 -c "import sys,json; r=json.load(sys.stdin); print(len(r), 'items')"
gh api repos/sigco3111/<repo-name>/commits/main
gh api repos/sigco3111/<repo-name>/readme
```

If user reports "리드미가 안보여요" or "푸시한거 맞나?" — cause is almost always:
- Browser cache: hard refresh (Cmd+Shift+R) or open in incognito
- GitHub README cache: 1-2 min delay
- Wrong URL: give both repo URL and direct README URL

If push fails because remote has newer commits, use `git pull --rebase origin main`. If README conflicts, manually resolve by keeping both versions, then `GIT_EDITOR=true git rebase --continue`.

## Pitfalls

- **Touching the original.** Always work on a copy. Originals stay byte-identical.
- **README at bottom.** User explicitly corrected this. The 📸 관련 자료 section goes at the TOP after the TOC.
- **Single mega-repo.** Never combine projects.
- **Skipping verification.** Always run the gh api verification step. User has asked "푸시한거 맞나?" multiple times.
- **Empty commits.** Substantive commit message listing what was added and what was excluded.
- **Korean dev notes.** EUC-KR `.htm` files in `manual/Etc/` are gold. Decode them.
- **Series connections.** When publishing X, look at other projects. Often X is a sequel/precursor. Document in README.
- **Image-only references.** If you embed an image, the file must be in the same repo (relative path). `file://` won't render on github.com — only relative paths.

## References

- `references/euckr-htm-dev-notes.md` — How to decode Korean developer notes from EUC-KR HTM files
- `references/file-exclusion-checklist.md` — Per-archive-type exclusion rules
- `references/game-source-analysis-patterns.md` — How to identify genre/engine from headers

## Templates

- `templates/README-template-ko.md` — Full fancy README skeleton
- `templates/.gitignore-template` — Generic VC++ / Windows build ignore
- `templates/LICENSE-MIT-template` — MIT with explicit non-inclusion of proprietary SDKs

## Scripts

- `scripts/publish-legacy-game.sh` — Complete pipeline from `cp -a` to `gh api` verification