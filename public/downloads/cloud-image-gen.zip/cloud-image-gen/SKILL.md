---
name: cloud-image-gen
description: "Kaggle/Colab T4 GPU에서 SDXL 이미지를 생성하고, 텔레그램으로 전송하는 스킬 — ngrok 터널 경유 API 호출"
tags: [image-generation, sdxl, kaggle, colab, telegram, gpu]
---

# Cloud Image Generation

Kaggle/Colab 무료 T4 GPU에서 SDXL 이미지를 생성하는 API 서버를 구동하고, 로컬에서 이미지를 요청하거나 텔레그램으로 전송합니다.

## 전제 조건

- Kaggle 또는 Google Colab 계정
- ngrok 계정 (무료): https://dashboard.ngrok.com/get-started/your-authtoken
- HuggingFace 계정 + 토큰: https://huggingface.co/settings/tokens

## 1단계: Kaggle 노트북 설정

Kaggle에서 새 노트북 생성 → Settings → **Internet: On** → **Accelerator: GPU T4 x2**

### 셀 1 — 의존성 설치
```python
!pip install -q pyngrok flask diffusers transformers accelerate torch
import torch
print(f"GPU: {torch.cuda.get_device_name(0)}")
print(f"VRAM: {torch.cuda.get_device_properties(0).total_memory / 1e9:.1f} GB")
```

### 셀 2 — 모델 로드 (SDXL)
```python
import torch
from diffusers import StableDiffusionXLPipeline
import time
from huggingface_hub import login

login("HF_TOKEN_HERE")  # ← 본인 HF 토큰으로 교체

print("Loading SDXL...")
t0 = time.time()
pipe = StableDiffusionXLPipeline.from_pretrained(
    "stabilityai/stable-diffusion-xl-base-1.0",
    torch_dtype=torch.float16,
    variant="fp16"
).to("cuda")
print(f"SDXL loaded in {time.time()-t0:.1f}s")
print(f"VRAM: {torch.cuda.memory_allocated()/1e9:.1f} GB")
```

### 셀 3 — ngrok 터널
```python
NGROK_AUTHTOKEN = "NGROK_TOKEN_HERE"  # ← 본인 ngrok 토큰으로 교체
from pyngrok import ngrok
ngrok.set_auth_token(NGROK_AUTHTOKEN)
public_url = ngrok.connect(8000)
print(f"Public URL: {public_url}")
print(f"API: {public_url}/generate")
```

### 셀 4 — API 서버
```python
import io, time
import threading
from flask import Flask, request, Response

app = Flask(__name__)

@app.route("/")
def root():
    return {"service": "Cloud Image Gen", "model": "sdxl", "status": "running"}

@app.route("/generate")
def generate():
    prompt = request.args.get("prompt", "")
    width = int(request.args.get("width", 1024))
    height = int(request.args.get("height", 1024))
    seed = int(request.args.get("seed", -1))
    steps = int(request.args.get("num_inference_steps", 25))
    guidance = float(request.args.get("guidance_scale", 7.5))

    if not prompt:
        return {"error": "prompt is required"}, 400

    generator = None
    if seed >= 0:
        generator = torch.Generator(device="cuda").manual_seed(seed)

    t0 = time.time()
    image = pipe(
        prompt=prompt,
        width=min(width, 1024),
        height=min(height, 1024),
        num_inference_steps=max(10, min(steps, 50)),
        guidance_scale=guidance,
        generator=generator
    ).images[0]
    elapsed = time.time() - t0

    buf = io.BytesIO()
    image.save(buf, format="PNG")
    buf.seek(0)
    return Response(buf.getvalue(), mimetype="image/png",
                    headers={"X-Generation-Time": f"{elapsed:.1f}s"})

threading.Thread(target=lambda: app.run(host="0.0.0.0", port=8000), daemon=True).start()
print("Server running on port 8000")
```

## 2단계: 로컬 클라이언트 사용

서버 URL을 알면 curl이나 Python으로 바로 요청 가능합니다.

### curl 사용
```bash
curl -o image.png "SERVER_URL/generate?prompt=A+cute+cat"
```

### Python 클라이언트
```python
import requests

def generate_image(prompt, url, output_path="image.png", steps=25, guidance=7.5, width=1024, height=1024, seed=-1):
    params = {
        "prompt": prompt,
        "num_inference_steps": steps,
        "guidance_scale": guidance,
        "width": width,
        "height": height,
        "seed": seed
    }
    resp = requests.get(f"{url}/generate", params=params, timeout=120)
    if resp.status_code == 200:
        with open(output_path, "wb") as f:
            f.write(resp.content)
        gen_time = resp.headers.get("X-Generation-Time", "?")
        print(f"Saved: {output_path} ({gen_time})")
    else:
        print(f"Error: {resp.status_code} {resp.text}")
```

## 3단계: 텔레그램으로 이미지 전송

이미지를 생성하고 텔레그램으로 바로 보내려면:

```python
import requests

def generate_and_send_telegram(prompt, server_url, bot_token, chat_id):
    # 1. 이미지 생성
    resp = requests.get(f"{server_url}/generate", params={"prompt": prompt}, timeout=120)
    if resp.status_code != 200:
        return f"Error: {resp.status_code}"
    
    # 2. 텔레그램 API로 이미지 전송
    files = {"photo": ("image.png", resp.content, "image/png")}
    data = {"chat_id": chat_id, "caption": f"🎨 {prompt}"}
    result = requests.post(f"https://api.telegram.org/bot{bot_token}/sendPhoto", files=files, data=data)
    return result.json()
```

## 주의사항

- **ngrok 무료**: URL이 세션마다 바뀜. 서버 재시작 시 URL 갱신 필요
- **Kaggle GPU**: 주 30시간 무료. 세션이 끊기면 모델 재로드 필요 (~3분)
- **HF 토큰, ngrok 토큰**: 절대 공개하지 말 것
- **Internet 설정**: Kaggle에서 Settings → Internet → On 필수 (기본 Off)
- **SDXL vs FLUX**: T4 GPU(16GB)에서는 SDXL만 구동 가능. FLUX는 ~24GB 필요 (OOM)
