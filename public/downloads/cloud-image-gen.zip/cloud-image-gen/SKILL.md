---
name: cloud-image-gen
description: "Kaggle T4 GPU에서 FLUX.1-schnell GGUF 이미지를 생성하는 스킬 — ComfyUI-GGUF + ngrok 터널 경유 API"
tags: [image-generation, flux, schnell, gguf, kaggle, telegram, gpu, comfyui]
---

# Cloud Image Generation

Kaggle 무료 T4 GPU에서 FLUX.1-schnell GGUF (Q5_1) 이미지를 생성하는 API 서버를 구동합니다. ComfyUI-GGUF 기반으로 SDXL 대비 품질 24% 향상, Apache 2.0 라이선스(상업용 OK). T4에서 4스텝 기준 ~40-50초 소요.

## 모델 구성

| 컴포넌트 | 모델 | 크기 | 포맷 |
|---|---|---|---|
| UNET | FLUX.1-schnell Q5_1 | 8.37 GB | GGUF |
| T5 인코더 | T5-v1.1-xxl Q4_K_M | 2.70 GB | GGUF |
| CLIP L | FLUX.1 | 0.25 GB | safetensors |
| VAE | FLUX.1 | 0.33 GB | safetensors |
| **총계** | | **~13.2 GB** | |

## FLUX.1-schnell 특징

- **속도**: 4스텝으로 1024x1024 이미지 생성 → T4에서 ~40-50초 (첫 생성), ~35-40초 (연속)
- **포토리얼리즘**: SDXL + RealVisXL 파인튜닝 모델이 유리. FLUX는 "AI 아트 느낌"이 강함
- **품질**: GenEval 0.72 (SDXL 0.58 대비 +24%, FLUX.1-dev 0.77의 하위)
- **라이선스**: Apache 2.0 — 상업적 이용 가능
- **guidance**: 불필요 (cfg=1.0 고정, guidance_scale 파라미터 무시)
- **네거티브 프롬프트**: 불필요

## SDXL vs FLUX.1-schnell 비교

| 항목 | SDXL | FLUX.1-schnell |
|---|---|---|
| GenEval | ~0.58 | **~0.72** (+24%) |
| 속도 (T4) | 5-8초 (20스텝) | **35-50초 (4스텝)** |
| 텍스트 렌더링 | 약함 | **강함** |
| 라이선스 | RAIL++ | **Apache 2.0** |
| VRAM | ~6GB | ~13.2GB |

## 전제 조건

- Kaggle 계정
- ngrok 계정 (무료): https://dashboard.ngrok.com/get-started/your-authtoken
- HuggingFace 계정 + 토큰: https://huggingface.co/settings/tokens

## 카글 노트북 스크립트

전체 스크립트: `~/.hermes/scripts/kaggle_account1_flux_gguf.py`

Kaggle 노트북 설정: Settings → **Internet: On** → **Accelerator: GPU T4 x2**

### Kaggle Secrets에 추가할 항목
- `NGROK_TOKEN` — ngrok 대시보드에서 발급
- `HF_TOKEN` (선택) — 게이트된 리포 다운로드용

### 셀 1 — ComfyUI + ComfyUI-GGUF 설치
```python
import subprocess, os
os.chdir("/kaggle/working")

if not os.path.exists("ComfyUI"):
    subprocess.run(["git", "clone", "https://github.com/comfyanonymous/ComfyUI.git"], check=True)

nodes_dir = "ComfyUI/custom_nodes"
os.makedirs(nodes_dir, exist_ok=True)
if not os.path.exists(f"{nodes_dir}/ComfyUI-GGUF"):
    subprocess.run(["git", "clone", "https://github.com/city96/ComfyUI-GGUF.git",
                    f"{nodes_dir}/ComfyUI-GGUF"], check=True)

subprocess.run(["pip", "install", "--upgrade", "gguf"], check=True)
subprocess.run(["pip", "install", "pyngrok", "flask"], check=True)
subprocess.run(["pip", "install", "-r", "ComfyUI/requirements.txt"], check=True)
```

### 셀 2 — 모델 다운로드 (~11.7 GB)
```python
from huggingface_hub import hf_hub_download

for d in ["unet", "clip", "vae"]:
    os.makedirs(f"ComfyUI/models/{d}", exist_ok=True)

UNET = hf_hub_download("city96/FLUX.1-schnell-gguf", "flux1-schnell-Q5_1.gguf",
                        local_dir="ComfyUI/models/unet")
T5 = hf_hub_download("city96/t5-v1_1-xxl-encoder-gguf", "t5-v1_1-xxl-encoder-Q4_K_M.gguf",
                      local_dir="ComfyUI/models/clip")
CLIP = hf_hub_download("comfyanonymous/flux_text_encoders", "clip_l.safetensors",
                        local_dir="ComfyUI/models/clip")
VAE = hf_hub_download("black-forest-labs/FLUX.1-dev", "ae.safetensors",
                       local_dir="ComfyUI/models/vae")
```

### 셀 3-5 — 서버 시작 + ngrok + 테스트
전체 스크립트 참조: `~/.hermes/scripts/kaggle_account1_flux_gguf.py`

## API 엔드포인트

- `GET /` — 서버 상태 (모델명, VRAM, 라이선스 정보)
- `GET /generate?prompt=...&width=1024&height=1024&num_inference_steps=4&seed=-1` — 이미지 생성 (PNG 반환)

### 파라미터

| 파라미터 | 기본값 | 설명 |
|---|---|---|
| `prompt` | (필수) | 이미지 생성 프롬프트 |
| `width` | 1024 | 가로 해상도 |
| `height` | 1024 | 세로 해상도 |
| `num_inference_steps` | 4 | 스텝 수 (schnell은 4면 충분) |
| `seed` | -1 | 랜덤 시드 (-1=자동) |
| `guidance_scale` | (무시됨) | schnell은 guidance 없음 |

## 로컬 클라이언트

```python
import requests

def generate_image(prompt, url, output_path="image.png", steps=4,
                   width=1024, height=1024, seed=-1):
    params = {"prompt": prompt, "num_inference_steps": steps,
              "width": width, "height": height, "seed": seed}
    resp = requests.get(f"{url}/generate", params=params, timeout=120)
    if resp.status_code == 200:
        with open(output_path, "wb") as f:
            f.write(resp.content)
        gen_time = resp.headers.get("X-Generation-Time", "?")
        print(f"Saved: {output_path} ({gen_time})")
    else:
        print(f"Error: {resp.status_code} {resp.text}")
```

## 텔레그램으로 이미지 전송

```python
def generate_and_send_telegram(prompt, server_url, bot_token, chat_id):
    resp = requests.get(f"{server_url}/generate", params={"prompt": prompt}, timeout=120)
    if resp.status_code != 200:
        return f"Error: {resp.status_code}"
    files = {"photo": ("image.png", resp.content, "image/png")}
    data = {"chat_id": chat_id, "caption": f"🎨 {prompt}"}
    return requests.post(f"https://api.telegram.org/bot{bot_token}/sendPhoto",
                         files=files, data=data).json()
```

## 주의사항

- **ngrok 무료**: URL이 세션마다 바뀜. 서버 재시작 시 URL 갱신 필요
- **Kaggle GPU**: 주 30시간 무료. 세션이 끊기면 ComfyUI + 모델 재로드 필요 (~10분)
- **HF 토큰, ngrok 토큰**: 절대 공개하지 말 것
- **Internet 설정**: Kaggle에서 Settings → Internet → On 필수 (기본 Off)
- **guidance_scale 무시**: schnell은 cfg=1.0 고정. guidance_scale 파라미터를 보내도 무시됨
- **OOM 시**: UNET을 Q4_K_S (6.32GB)로 다운그레이드하거나, 해상도를 768x768로 낮추세요
- **Q5_1 vs Q4_K_S**: Q5_1은 ~13.2GB, Q4_K_S는 ~11.1GB. 속도 차이는 미미하므로 Q5_1 권장
- **CLIP-L 단독 불가**: FLUX 아키텍처가 T5 임베딩 차원을 필수로 요구함. CLIP-L만으로는 구동 불가 (400 에러)
- **T5 제거 시도 실패**: Q3_K_M으로 줄여도 품질/호환성 이슈. T5 Q4_K_M 유지가 정석
- **T4 x2**: 기본적으로 단일 GPU(cuda:0)만 사용. 별도 설정 없이는 두 번째 GPU 유휴
- **블로그 이미지 파이프라인**: FLUX 생성 → Tistory 업로드(영구 호스팅) → 글 발행. 실패 시 Picsum 폴백
