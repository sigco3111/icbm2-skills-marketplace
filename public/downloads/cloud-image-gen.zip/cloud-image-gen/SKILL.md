---
name: cloud-image-gen
description: "이미지 생성 스킬 — Pollinations.ai (기본) / FLUX.1-schnell GGUF (카글, 필요시 수동 구동)"
tags: [image-generation, pollinations, flux, gguf, kaggle, telegram, gpu, comfyui]
---

# 이미지 생성

> ⚠️ **2026-04-16 변경:** 기본 이미지 생성을 Pollinations.ai로 전환. 카글 FLUX 서버는 필요시 수동 구동.

## 현재 방식: Pollinations.ai (기본)

무료 API, API 키 불필요, 카글 서버 없이 즉시 사용 가능.

```
https://image.pollinations.ai/prompt/{encoded_prompt}?width=1080&height=720&nologo=true
```

### Tistory 발행 시 이미지 생성
`tistory_publisher.py`의 `insert_auto_images()`에서 자동 사용:
1순위: Pollinations.ai → 2순위: Picsum 폴백

### Pollinations 한계
- FLUX보다 품질 낮음
- 한국어 프롬프트 지원 제한적 (영어 권장)
- 커스텀 모델/스타일 제어 불가

## 레거시: 카글 FLUX 서버 (사용 중단)

### FLUX.1-schnell GGUF Q5_1 사양
| 항목 | 값 |
|---|---|
| UNET | 8.37GB (Q5_1) |
| T5-XXL | 2.70GB (Q4_K_M) |
| CLIP-L | 0.25GB |
| VAE | 0.33GB |
| 총 VRAM | ~13.2GB |
| GPU | T4 x2 (카글) |
| 추론 속도 | ~5초/장 (4스텝) |

### 사용 중단 사유
- 카글 40분 유휴 타임아웃 → 서버 자동 종료
- 주간 GPU 30시간 제한
- ICBM2가 서버 원격 재시작 불가

### 레거시 스크립트
- `~/.hermes/scripts/kaggle_account1_flux_gguf.py` — FLUX.1-schnell GGUF 서버
- `~/.hermes/scripts/kaggle_account1_flux_dev.py` — FLUX.1 Dev 서버
