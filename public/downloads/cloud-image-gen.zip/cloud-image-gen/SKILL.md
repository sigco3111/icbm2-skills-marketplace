---
name: cloud-image-gen
description: "Kaggle/Colab T4 GPU에서 FLUX.1 Dev GGUF 이미지를 생성하는 스킬 — ComfyUI-GGUF + ngrok 터널 경유 API"
tags: [image-generation, flux, gguf, kaggle, colab, telegram, gpu, comfyui]
---

# Cloud Image Generation

Kaggle 무료 T4 GPU에서 FLUX.1 Dev GGUF (Q4_K_S) 이미지를 생성하는 API 서버를 구동합니다. ComfyUI-GGUF 기반으로 SDXL보다 훨씬 높은 품질의 이미지를 T4에서 생성 가능합니다.

## 모델 구성

| 컴포넌트 | 모델 | 크기 | 포맷 |
|---|---|---|---|
| UNET | FLUX.1-dev Q4_K_S | 6.81 GB | GGUF |
| T5 인코더 | T5-v1.1-xxl Q4_K_M | 2.90 GB | GGUF |
| CLIP L | FLUX.1-dev | 0.25 GB | safetensors |
| VAE | FLUX.1-dev | 0.33 GB | safetensors |
| **총계** | | **~10.3 GB** | |

## 전제 조건

- Kaggle 계정
- ngrok 계정 (무료): https://dashboard.ngrok.com/get-started/your-authtoken
- HuggingFace 계정 + 토큰: https://huggingface.co/settings/tokens

## 카글 노트북 스크립트

전체 스크립트: `~/.hermes/scripts/kaggle_account1_flux_gguf.py`

Kaggle 노트북 설정: Settings → **Internet: On** → **Accelerator: GPU T4 x2**

### 셀 1 — ComfyUI + ComfyUI-GGUF 설치
```python
import subprocess, os
os.chdir("/kaggle/working")

if not os.path.exists("ComfyUI"):
    subprocess.run(["git", "clone", "https://github.com/comfyanonymous/ComfyUI.git"], check=True)

nodes_dir = "ComfyUI/custom_nodes"
os.makedirs(nodes_dir, exist_ok=True)
if not os.path.exists(f"{nodes_dir}/ComfyUI-GGUF"):
    subprocess.run(["git", "clone", "https://github.com/city96/ComfyUI-GGUF.git",
                    f"{nodes_dir}/ComfyUI-GGUF"], check=True)

subprocess.run(["pip", "install", "--upgrade", "gguf"], check=True)
subprocess.run(["pip", "install", "-r", "ComfyUI/requirements.txt"], check=True)
```

### 셀 2 — 모델 다운로드 (~10.3 GB)
```python
from huggingface_hub import hf_hub_download

for d in ["unet", "clip", "vae"]:
    os.makedirs(f"ComfyUI/models/{d}", exist_ok=True)

UNET = hf_hub_download("city96/FLUX.1-dev-gguf", "flux1-dev-Q4_K_S.gguf",
                        local_dir="ComfyUI/models/unet")
T5 = hf_hub_download("city96/t5-v1_1-xxl-encoder-gguf", "t5-v1_1-xxl-encoder-Q4_K_M.gguf",
                      local_dir="ComfyUI/models/clip")
CLIP = hf_hub_download("black-forest-labs/FLUX.1-dev", "clip_l.safetensors",
                        local_dir="ComfyUI/models/clip")
VAE = hf_hub_download("black-forest-labs/FLUX.1-dev", "ae.safetensors",
                       local_dir="ComfyUI/models/vae")
```

### 셀 3-5 — 서버 시작 + ngrok + 테스트
전체 스크립트 참조: `~/.hermes/scripts/kaggle_account1_flux_gguf.py`

## API 엔드포인트

- `GET /` — 서버 상태
- `GET /generate?prompt=...&width=1024&height=1024&num_inference_steps=20&guidance_scale=3.5&seed=-1` — 이미지 생성 (PNG 반환)

## 로컬 클라이언트

```python
import requests

def generate_image(prompt, url, output_path="image.png", steps=20, guidance=3.5,
                   width=1024, height=1024, seed=-1):
    params = {"prompt": prompt, "num_inference_steps": steps, "guidance_scale": guidance,
              "width": width, "height": height, "seed": seed}
    resp = requests.get(f"{url}/generate", params=params, timeout=600)
    if resp.status_code == 200:
        with open(output_path, "wb") as f:
            f.write(resp.content)
        gen_time = resp.headers.get("X-Generation-Time", "?")
        print(f"Saved: {output_path} ({gen_time})")
    else:
        print(f"Error: {resp.status_code} {resp.text}")
```

## 텔레그램으로 이미지 전송

```python
def generate_and_send_telegram(prompt, server_url, bot_token, chat_id):
    resp = requests.get(f"{server_url}/generate", params={"prompt": prompt}, timeout=600)
    if resp.status_code != 200:
        return f"Error: {resp.status_code}"
    files = {"photo": ("image.png", resp.content, "image/png")}
    data = {"chat_id": chat_id, "caption": f"🎨 {prompt}"}
    return requests.post(f"https://api.telegram.org/bot{bot_token}/sendPhoto",
                         files=files, data=data).json()
```

## 주의사항

- **ngrok 무료**: URL이 세션마다 바뀜. 서버 재시작 시 URL 갱신 필요
- **Kaggle GPU**: 주 30시간 무료. 세션이 끊기면 ComfyUI + 모델 재로드 필요 (~10분)
- **HF 토큰, ngrok 토큰**: 절대 공개하지 말 것
- **Internet 설정**: Kaggle에서 Settings → Internet → On 필수 (기본 Off)
- **FLUX.1 Dev**: SDXL보다 품질이 훨씬 뛰어남. guidance_scale은 3.5가 기본값 (SDXL의 7.5보다 낮음)
- **OOM 시**: T5를 Q3_K_M (2.3GB)으로 다운그레이드하거나, 해상도를 768x768로 낮추세요
