---
name: cloud-image-gen
description: "이미지 생성 스킬 — Pollinations.ai (기본) / FLUX.1-schnell GGUF (카글, 필요시 수동 구동)"
tags: [image-generation, pollinations, flux, gguf, kaggle, telegram, gpu, comfyui]
---

# 이미지 생성

> ⚠️ **2026-04-16 변경:** 기본 이미지 생성을 Pollinations.ai로 전환. 카글 FLUX 서버는 필요시 수동 구동.

## 현재 방식: Pollinations.ai (기본)

무료 API, API 키 불필요, 카글 서버 없이 즉시 사용 가능.

```
https://image.pollinations.ai/prompt/{encoded_prompt}?width=1080&height=720&nologo=true
```

### Tistory 발행 시 이미지 생성
`tistory_publisher.py`의 `insert_auto_images()`에서 자동 사용:
1순위: Pollinations.ai → 2순위: Picsum 폴백

### Telegram 전송 워크플로우

```bash
# 1. Pollinations로 이미지 생성 → 임시 파일 저장
curl -s "https://image.pollinations.ai/prompt/{encoded_prompt}&width=1024&height=1280&nologo=true" \
  -o ~/.hermes/tmp_<이름>.png

# 2. 파일 크기로 실패 감지 (875bytes 이하 = 빈 응답)
if [ $(stat -f%z ~/.hermes/tmp_<이름>.png) -lt 876 ]; then
  echo "실패, 재시도..."
  curl -s "..." -o ~/.hermes/tmp_<이름>.png
fi

# 3. Telegram 전송: MEDIA:/Users/hjshin/.hermes/tmp_<이름>.png
```

### 개인화 이미지 생성 가이드

**Telegram에서 "나/아내/자녀 이미지 생성해줘" 요청 시 사용:**

| 대상 | 프롬프트 키워드 | 해상도 |
|------|---------------|--------|
| 본인 (테크 애호가) | Korean tech enthusiast, workspace, headphones, cinematic portrait | 1024x1280 |
| 아내 | Beautiful Korean woman, elegant smile, soft natural lighting, portrait photography | 1024x1280 |
| 딸 | Adorable Korean girl, cheerful smile, casual outfit, lifestyle photography | 1024x1280 |
| 아들 | Adorable Korean boy, playful expression, casual smart style | 1024x1280 |

**포토리얼리즘 프롬프트 템플릿:**
```
[subject description], cinematic portrait photography, shallow depth of field, 
photorealistic, 8K, [mood description], warm golden hour lighting, 
magazine cover quality
```

**주의:** Pollinations 응답이 비어있을 수 있으므로 항상 파일 크기 체크 후 재시도.

### Pollinations 한계
- FLUX보다 품질 낮음
- 한국어 프롬프트 지원 제한적 (영어 권장)
- 커스텀 모델/스타일 제어 불가
- 고해상도 (1024px+) 생성 시 타임아웃 가능 → 90초 timeout 설정 권장
- 빈 응답 (875bytes 이하) 시 재시도

## 레거시: 카글 FLUX 서버 (사용 중단)

### FLUX.1-schnell GGUF Q5_1 사양
| 항목 | 값 |
|---|---|
| UNET | 8.37GB (Q5_1) |
| T5-XXL | 2.70GB (Q4_K_M) |
| CLIP-L | 0.25GB |
| VAE | 0.33GB |
| 총 VRAM | ~13.2GB |
| GPU | T4 x2 (카글) |
| 추론 속도 | ~5초/장 (4스텝) |

### 사용 중단 사유
- 카글 40분 유휴 타임아웃 → 서버 자동 종료
- 주간 GPU 30시간 제한
- ICBM2가 서버 원격 재시작 불가

### 레거시 스크립트
- `~/.hermes/scripts/kaggle_account1_flux_gguf.py` — FLUX.1-schnell GGUF 서버
- `~/.hermes/scripts/kaggle_account1_flux_dev.py` — FLUX.1 Dev 서버
