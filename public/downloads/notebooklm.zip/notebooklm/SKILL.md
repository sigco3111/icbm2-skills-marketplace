---
name: notebooklm
description: "Google NotebookLM 자동화 — 비디오 오버뷰 생성, 소스 관리, YouTube 업로드 (일반 계정)"
tags: [notebooklm, video, slide-deck, google, ai-content]
---

# Google NotebookLM 자동화 (일반 계정)

notebooklm-py를 사용해 Google NotebookLM의 모든 기능을 프로그래밍 방식으로 제어합니다.

## 🚨 영상 자동 생성 절대 금지 — 핵심 규칙

> **이 규칙을 위반하면 매번 실패한다. 반복적으로.**

**절대 하지 말 것:**
- `notebooklm generate video` 자동 호출
- `notebooklm_youtube_pipeline.py` 자동 실행
-侯選 topic 선택 후 영상 생성 명령 포함
- 사용자가 "노트북 생성" 이라고 하면 → `notebooklm_prepare.py`만 실행 (노트북+소스), 영상 생성 명령 **절대 포함 안 함**

**올바른侯選 워크플로우 순서:**
```
16:00 크론 →侯選 전송 (notebooklm_selection.py)
    ↓
사용자가 번호 선택 (예: 1,3,5)
    ↓
notebooklm_prepare.py 실행 → 노트북+소스 생성만
    ↓
🎬 사용자가 NotebookLM에서 수동으로 비디오 오버뷰 생성
    ↓
사용자가 '업로드'라고 입력
    ↓
notebooklm_upload_pipeline.py 실행 → 다운로드+업로드
```

**영상 생성은 100% 수동이다.** ICBM2가 자동으로 시도하면 매번 타임아웃/실패한다.

## 전제 조건

| 항목 | 설명 |
|------|------|
| notebooklm-py v0.3.4+ | `~/.hermes/venv-notebooklm/`에 설치됨 |
| Python 3.13 | venv 전용 (시스템 패키지와 격리) |
| 구글 로그인 | `~/.hermes/venv-notebooklm/bin/activate && notebooklm login` |
| 인증 파일 | `~/.notebooklm/storage_state.json` |

## 인증

```bash
source ~/.hermes/venv-notebooklm/bin/activate
notebooklm login              # 브라우저 로그인
notebooklm auth check --test  # 인증 상태 확인
```

### ⚠️ `notebooklm login` PTY auto-abort 우회 방법

`notebooklm login`은 PTY 모드에서 stdin TTY 감지로 인해 **즉시 abort** 발생:
```
Aborted!
```

**올바른 방법 — 백그라운드 + submit:**
```bash
# 1. 백그라운드로 실행 (notify_on_complete 필수)
terminal(background=true, notify_on_complete=true)
→ "브라우저에 Google 로그인 화면 열렸어요! 로그인 완료 후 아무 키나 누르세요"

# 2. 사용자가 로그인 완료 후 submit
process(action='submit', session_id='...', data='')

# 3. 완료 대기
process(action='wait', session_id='...', timeout=15)
→ "Authentication saved to: ~/.notebooklm/storage_state.json"
```

**절대 하지 말 것:** `pty=true`로foreground 실행 → 사용자가 로그인하는 동안 CLI가abort됨

## 기본 사용법

모든 notebooklm 명령어는 반드시 venv 활성화 후 실행:

```bash
source ~/.hermes/venv-notebooklm/bin/activate
```

## 노트북 관리

```bash
notebooklm create "제목"           # 노트북 생성 (ID 반환)
notebooklm list                   # 노트북 목록
notebooklm use <notebook_id>      # 현재 노트북 설정
notebooklm delete -n <partial_id> # 노트북 삭제 (-n 플래그 필수, 부분 ID 매칭 가능)
```

## 소스 추가

```bash
# URL
notebooklm source add "https://example.com"

# YouTube 영상
notebooklm source add "https://youtube.com/watch?v=xxx"

# 로컬 파일 (PDF, 텍스트, 마크다운)
notebooklm source add "./paper.pdf"

# 인라인 텍스트
notebooklm source add "요약할 텍스트 내용" --title "제목"

# 웹 리서치 자동 수집 (시간 걸림, 2~5분)
notebooklm source add-research "검색어" --mode deep

# 소스 목록 확인
notebooklm source list
```

## 콘텐츠 생성

### 비디오 (YouTube 업로드용)

```bash
# Video Overview (빠름, ~5-10분)
notebooklm generate video "설명" --style whiteboard --language ko --wait
notebooklm download video ./output.mp4

# Cinematic Video (Veo 3, ~30-40분, AI Ultra 필요)
notebooklm generate cinematic-video "설명" --language ko --wait
notebooklm download cinematic-video ./output.mp4
```

**비디오 스타일:** `auto`, `classic`, `whiteboard`, `kawaii`, `anime`, `watercolor`, `retro-print`, `heritage`, `paper-craft`

**비디오 포맷:** `explainer` (기본), `brief`, `cinematic`

### 슬라이드 덱

```bash
notebooklm generate slide-deck "설명" --format detailed --language ko --wait
notebooklm download slide-deck ./slides.pdf     # PDF
notebooklm download slide-deck ./slides.pptx    # PPTX
```

### 기타 콘텐츠

```bash
# 인포그래픽 (PNG)
notebooklm generate infographic --orientation portrait --wait
notebooklm download infographic ./info.png

# 마인드맵 (JSON)
notebooklm generate mind-map --wait
notebooklm download mind-map ./mindmap.json

# 퀴즈
notebooklm generate quiz --difficulty hard --wait
notebooklm download quiz --format markdown ./quiz.md

# 플래시카드
notebooklm generate flashcards --quantity more --wait
notebooklm download flashcards --format json ./cards.json

# 리포트
notebooklm generate report --format blog-post --wait
notebooklm download report ./report.md

# 데이터 테이블 (CSV)
notebooklm generate data-table "비교 항목" --wait
notebooklm download data-table ./data.csv
```

## 채팅

```bash
notebooklm ask "질문"
```

## YouTube 업로드 파이프라인 (자동 노트북 정리 포함)

무료 계정은 최대 5개 노트북 제한이 있으므로, 업로드 완료 후 노트북을 자동 삭제합니다.

```bash
# 1. 노트북 생성 + 소스 추가
NOTEBOOK_ID=$(notebooklm create "주제")
notebooklm use $NOTEBOOK_ID
notebooklm source add "https://url1.com"
notebooklm source add "https://url2.com"

# 2. 비디오 생성 (한국어)
notebooklm generate video "한국어로 흥미롭게 설명해주세요" --style whiteboard --language ko --wait

# 3. 비디오 artifact ID 확인
notebooklm artifact list  # completed 상태 비디오 ID 확인

# 4. 다운로드 (경로 마지막 positional, --force 필수)
notebooklm download video --artifact <artifact_id> --force /tmp/video.mp4

# 5. YouTube 업로드
python3 ~/.hermes/scripts/notebooklm_youtube_pipeline.py --mode video --type daily_tech

# 5. 노트북 삭제 (무료 계정 5개 제한 관리) — -n 플래그 필수
notebooklm delete -n <partial_id> -y
```

⚠️ **필수:** 비디오 다운로드를 완료한 후에만 삭제하세요. 생성 콘텐츠는 다운로드 전에 노트북 삭제하면 유실됩니다.

## YouTube 업로드 파이프라인 (On-Demand)

사용자가 **이미 생성된 비디오 오버뷰**를 YouTube에 올려달라고 URL만 알려줄 때.

**절대 Playwright 사용 금지** — 네트워크 캡처/요소 탐색 불안정.
**CLI + ffmpeg + OAuth API 방식만 사용.**

**🚨 중요:** 업로드 시 **일반 영상 + 숏츠(60초 9:16)를 항상 함께** 생성·업로드한다. 일반 영상만 업로드하고 숏츠를 생략하면 안 된다.

```bash
# 1. 노트북 접근 + artifact ID 확인
source ~/.hermes/venv-notebooklm/bin/activate
notebooklm use <notebook_id>
notebooklm artifact list  # completed 상태 비디오 ID 확인

# 2. 다운로드 (--artifact로 부분 ID 매칭)
notebooklm download video --artifact <artifact_id> --force /tmp/video.mp4

# 3. ffprobe로 정보 확인
ffprobe -v error -show_entries stream=width,height,duration -of json /tmp/video.mp4

# 4. 숏츠 생성 (60초, 9:16, Pad Letterbox 방식 — convert_to_shorts 함수 사용)
#    ✅ crop/boxblur 방식이 아닌 scale+pad.black 방식 사용 (FFmpeg 4.3 안정版)
python3 -c "
import sys
sys.path.insert(0, '/Users/hjshin/.hermes/scripts')
from notebooklm_youtube_pipeline import convert_to_shorts, OUTPUT_DIR, FFPROBE, FFMPEG
import os, subprocess

video_path = '/tmp/video.mp4'
shorts_path = '/tmp/shorts.mp4'
ok, result = convert_to_shorts(video_path, shorts_path)
print('숏츠 변환:', '成功' if ok else f'失敗: {result}')
"

# 5. YouTube OAuth 업로드 (일반 영상 + 숏츠 동시)
~/.hermes/hermes-agent/venv/bin/python3 -c "
import os, pickle
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

TOKEN=os.path.expanduser('~/.hermes/secrets/youtube_token.pickle')
with open(TOKEN,'rb') as f:
    creds=pickle.load(f)
if creds.expired:
    creds.refresh(Request())
    with open(TOKEN,'wb') as f:
        pickle.dump(creds,f)

youtube=build('youtube','v3',credentials=creds)

# 일반 영상 업로드
resp1=youtube.videos().insert(
    part='snippet,status',
    body={
        'snippet':{'title':'영상 제목','description':'설명\\n\\n#해시태그','categoryId':'28'},
        'status':{'privacyStatus':'public'}
    },
    media_body=MediaFileUpload('/tmp/video.mp4')
).execute()
print(f'일반 영상: https://youtu.be/{resp1[\"id\"]}')

# 숏츠 업로드
resp2=youtube.videos().insert(
    part='snippet,status',
    body={
        'snippet':{'title':'[SHORTS] 영상 제목','description':'설명\\n\\n#shorts #해시태그','categoryId':'28'},
        'status':{'privacyStatus':'public'}
    },
    media_body=MediaFileUpload('/tmp/shorts.mp4')
).execute()
print(f'숏츠: https://youtu.be/{resp2[\"id\"]}')
"

# 6. 임시 파일 정리
rm -f /tmp/video.mp4 /tmp/shorts.mp4
```

**파이프라인 모드 (`notebooklm_youtube_pipeline.py`):**
- `--mode video` — 일반 영상만
- `--mode shorts` — 숏츠만
- `--mode both` — **영상+숏츠 동시** (권장)

**핵심 교훈 (2026-05-03):**
- 오늘처럼 일반 영상만 업로드하고 숏츠를 빠뜨리는 실수 방지 → `both` 모드 사용
- Playwright 비디오 URL 캡처 → 실패 (blob URL, cross-origin iframe 등으로 실제 파일 URL 노출 안 됨)
- CLI `notebooklm download video` → 완벽 작동
- **항상 CLI 우선**

## ⚠️侯選 번호 매핑 — 크론 출력 기준 (2026-05-02)

**매우 중요:** 사용자가侯選 번호(예: `1,3,5`)를 선택하면, **반드시 크론 출력 파일 기준**으로 매핑해야 합니다.

**문제:** `~/.hermes/memory/notebooklm_selection.json`은侯選 전송 시점의快照이며, Notion DB 순서와 다를 수 있음. 사용자에게 표시된 번호는 크론 출력 기준.

**올바른 방법:** 최신 크론 출력 파일에서侯選 topic 추출:
```bash
# 가장 최근 notebooklm侯選 크론 출력 찾기
LATEST=$(ls -t ~/.hermes/cron/output/*/2026-*.md 2>/dev/null | head -1)
if [ -n "$LATEST" ]; then
  # Markdown에서 topic 목록 추출 (URL 포함)
  grep -A 200 "侯選\|候選" "$LATEST" | grep "topic?id=" | head -12
fi
```

**또는侯選 전송 크론 job ID 기준:**
```python
import subprocess, json, re

# 가장 최근侯選 크론 job 찾기
result = subprocess.run(
    ["ls", "-t", "/Users/hjshin/.hermes/cron/output/"],
    capture_output=True, text=True, timeout=10
)
job_dirs = [d.strip() for d in result.stdout.splitlines() if len(d.strip()) == 14]

for job_id in job_dirs[:3]:  # 최신 3개 확인
    md_file = subprocess.run(
        ["ls", "-t", f"/Users/hjshin/.hermes/cron/output/{job_id}/"],
        capture_output=True, text=True, timeout=10
    ).stdout.splitlines()[0].strip()
    path = f"/Users/hjshin/.hermes/cron/output/{job_id}/{md_file}"
    content = open(path).read()
    if "侯選" in content or "NotebookLM侯選" in content:
        # URL 추출
        urls = re.findall(r'topic\?id=(\d+)', content)
        print(f"Job {job_id}: {len(urls)} topics found")
        print(f"  URLs: {urls}")
        break
```

**절대 하지 말 것:**
- `notebooklm_selection.json`만 읽고侯選 매핑 → **昨/실시간Notion DB topic과 섞임**
- 실시간 Notion DB 질의로 번호 확정 →侯選 전송內容과 불일치

## 🚨 장애 처리 정책 (중요)

**비디오 오버뷰 생성 장애 발생 시:**
1. **재시도 금지** — 장애 감지 시 즉시 중단
2. 소스를 NotebookLM 노트북에 추가해둔 상태로 유지
3. **주인님에게 텔레그램으로 알림** — 어떤 노트북/소스에서 장애 발생했는지 명시
4. **알림에 추천 프롬프트 포함** —的主人님이 NotebookLM에서 직접 생성할 때 사용할 프롬프트 제공
5. 주인님이 직접 해당 노트북에서 생성 후, 편집/업로드를 ICBM2에 요청
6. **야간 크론잡에서도 동일** — 장애 시 텔레그램 메시지 남기고 대기

### 알림 메시지 형식 (텔레그램)

```
⚠️ NotebookLM 생성 장애

📝 노트북: {notebook_title} ({notebook_id})
🔧 작업: video_overview
📋 소스: {소스 목록 요약}
❌ 오류: {에러 내용}

— 아래 프롬프트를 NotebookLM에서 직접 실행해주세요 —

{추천 프롬프트}

완료되면 편집/업로드 요청해주세요!
```

### 추천 프롬프트 템플릿

```
이 소스들을 바탕으로 한국어로 흥미롭게 설명하는 비디오 오버뷰를 만들어주세요. 전문적이면서도 일반인이 이해하기 쉬운 톤으로, 핵심 내용을 논리적으로 전달해주세요.
```

> ⚠️ 프롬프트는 콘텐츠 타입(ai_news, github_trending 등)에 맞게 문맥을 추가해서 제공할 것

## Notion DB → NotebookLM 워크플로우

**크론 트리거:** 매일 16:00 →侯選 전송 → 사용자 선택 → 수동 생성

###侯選 URL 원칙

1. **URL이 있는 활성 topic만** → NotebookLM 소스로 추가
2. **URL 없으면 → 스킵** (키워드 수집 폴백 없음)

###侯選 topic 선택 시 올바른 응답

사용자가侯選 topic 번호(예: `1,3,5`)를 선택하면:

```
✅ {N}번 선택 확인!
notebooklm_prepare.py 실행 중... (노트북+소스 생성)
...
✅ 노트북 {N}개 생성 완료!
🎬 각 노트북에서 직접 비디오 오버뷰 생성해주세요.
완료되면 '업로드' 라고 알려주세요.
```

**절대 하지 말 것:** prepare 실행 후 `notebooklm generate video` 또는 `notebooklm_youtube_pipeline.py` 자동 실행

###侯選가 없는 경우
URL 없는 topic은侯選에서 제외 — "NotebookLM 생성" 시 스킵

## 주요 함정

| 문제 | 해결 |
|------|------|
| 일일 쿼터 제한 (cinematic-video) | `--retry 5` 추가, 1~24시간 대기 |
| 비디오 생성 타임아웃 | `--wait` 600s CLI 타임아웃 ≠ 서버 완료. CLI 타임아웃 후에도 `artifact list`로 server-side 상태 확인 |
| **CLI 타임아웃 후 서버는 계속 진행** | `--wait`이 600s 지나면 CLI가 에러로 종료되지만 서버에선 계속 생성 중. `artifact list`로 `pending`/`in_progress`/`completed` 확인 후 `artifact wait <id>`로 완전 대기 |
| **동일 노트북에서 2회 비디오 생성** | 각 생성마다 새 artifact ID가 생김. `--latest` 또는 artifact 제목(`--name`)으로 원하는 것 다운로드 |
| Video Overview pending 멈춤 | NotebookLM 서버 측 이슈. `--wait --retry 5` 옵션 사용. 업데이트: `pip install git+https://github.com/teng-lin/notebooklm-py.git`. 노트북 55개 제한 있음 |
| YouTube 제목 덮어쓰기 버그 | 출처 빌드 루프에서 `title = item.get("title")`이 YouTube 제목 덮어씀 → `item_title`, `item_url`, `item_source` 지역 변수명 사용 |
| **키워드 수집 불일치** |侯選 URL 우선 — Notion DB에 없으면 긱뉴스 크롤링으로 URL 직접查找. 자동 키워드 검색 금지 |
| **9:16 블러 필터 crop 버그** | `scale=...:increase,crop=1080:1920` → crop이 letterbox 영역 자름 → 블러 안 됨. crop 제거: `scale=1080:1920,boxblur=20` |
| **pipeline_shorts shorts_type 버그** | `notebooklm_youtube_pipeline.py`에서 `build_youtube_description(shorts_type, ...)` → `content_type`으로 수정 |
| stdout 버퍼링 | 백그라운드 프로세스는 `PYTHONUNBUFFERED=1` 또는 `python3 -u` 사용. 폴링 중 `in_progress`만 반복 — kill하지 말고 기다릴 것 |
| 소스 처리 안 됨 | URL 추가 후 `source list`로 ready 상태 확인 |
| 소스 JSON 파싱 실패 | `source list --json`은 `{sources:[...]}` 형태, 최상위 배열 아님 |
| 폰트 경로 오류 | macOS 폰트는 `.otf`가 아닌 `.ttc`(TrueType Collection) — `AppleSDGothicNeo.ttc` |
| 인증 만료 | `notebooklm login` 재실행 |
| venv 미활성화 | 모든 명령어 앞에 `source ~/.hermes/venv-notebooklm/bin/activate` 필수 |
| httpx 충돌 | 시스템 Python이 아닌 반드시 venv 사용 |
| 숏츠 길이 약간 초과 | 60초 초과 약간 허용됨 (주인님 명시) |
| **download video 경로 순서** | `notebooklm download video --artifact <id> --force <path>` — 경로는 반드시 마지막 positional 인자. `--artifact`는 부분 ID도 매칭됨 |
| **노트북 삭제 형식** | `notebooklm delete -n <partial_id>` — `-n` 플래그 필수. 테이블에 보이는 truncated ID도 사용 가능. 예: `notebooklm delete -n fc5ff5c5 -y` |
| **NOTEBOOKLM_NOTEBOOK env var** | subprocess에서 NOTEBOOKLM_NOTEBOOK env로 notebook 컨텍스트 전달 → 실패. 각 작업마다 `notebooklm use <id>`를 별도 터미널 세션에서 실행 |
| **병렬 비디오 생성** | `notebooklm use` + `generate video --wait`를 각각 별도 background 터미널에서 실행하면 동시에 4개까지 가능 |

## 🚨 [SILENT] 장애 디버깅 —侯選 전송 크론이 조용히 실패할 때

**증상:** 16:00侯選 크론이 `last_status: ok`인데 사용자가侯選을 받지 못함.

**진단 순서:**
1. 크론 출력 파일 확인: `~/.hermes/cron/output/dc9a2e6aaaaa/YYYY-MM-DD_16-00-XX.md`
2. `[SILENT]`이 있으면 → 크론 에이전트가 전달할 내용을 받지 못한 것
3.侯選 파일 존재 확인: `ls ~/.hermes/memory/notebooklm_selection.json`
   - 파일이 없으면 → 스크립트가侯選 수집 실패
   - 파일이 있어도 `[SILENT]`이면 → **스크립트 내부 Telegram 전송 실패**
4. 스크립트 수동 실행으로 재현:
   ```bash
   bash -c "source ~/.hermes/venv-notebooklm/bin/activate && python3 ~/.hermes/scripts/notebooklm_selection.py"
   ```
   → `⚠️ 텔레그램 전송 실패` 또는 `⚠️ 텔레그램 설정 없음` 출력되면 전송 경로 문제

**원인별 해결:**
| 원인 | 해결 |
|------|------|
|侯選 파일 없음 (오늘 수집 안 됨) |侯選 전송 크론 프롬프트에侯選 파일 생성을 반드시 포함하도록 함 |
| 스크립트 Telegram 전송 실패 | `notebooklm_selection.py`의 `send_telegram()` 함수 또는 텔레그램 CLI 경로 확인 |
|侯選 전송 크론과 다른 크론 시간 겹침 | `0 16 * * *` → `0 16 * * *` 동일 시간대 다른 크론이 先순위 점유. 크론 스케줄 분리 고려 |

**16:00侯選 크론이 `[SILENT]`일 때紧急 복구:**
1.侯選 파일이 5/2 이후로 안 만들어졌으면 →侯選 전송 크론을 **수동 실행** ( cronjob run)
2.侯選 파일이 있는데 `[SILENT]`이면 → `notebooklm_selection.py`를 수동 실행해서侯選 수집 + 전송

## 스크립트

- `~/.hermes/scripts/notebooklm_youtube_pipeline.py` — Video Overview + Shorts 파이프라인
- `~/.hermes/scripts/notebooklm_prepare.py` — 노트북 생성 + 소스 추가
- `~/.hermes/scripts/notebooklm_upload.py` — 다운로드 + YouTube 업로드 + 삭제

## 병렬 비디오 생성 (동시 4개)

`NOTEBOOKLM_NOTEBOOK` 환경변수는 subprocess에서 reliable하게 동작하지 않음. 대신 각 노트북마다 별도 터미널 세션에서 `notebooklm use <id>` 실행.

```bash
# 1. 소스까지 모두 추가 (병렬 가능 — NOTEBOOKLM_NOTEBOOK env 사용)
for nb_id in $IDS; do
  NOTEBOOKLM_NOTEBOOK=$nb_id notebooklm source add "https://..." &
done
wait

# 2. 비디오는 각각 별도 background 터미널에서 (--wait 포함)
for nb_id in $IDS; do
  (
    source ~/.hermes/venv-notebooklm/bin/activate
    notebooklm use $nb_id
    notebooklm generate video "..." --style whiteboard --language ko --wait
  ) &
done

# 3. 완료 대기 (각 터미널 완료 알림 수신 후)
#    - 먼저 완료된 것부터 download: notebooklm download video --latest --name "제목"
#    - ffprobe로 길이 확인
#    - 타임아웃(600s) 이후에도 server에서 계속 진행 중일 수 있음
#    - artifact list로 server-side 상태 확인 후 artifact wait로 완전 대기
```

## 한계

- 비공식 API — 구글이 언제든 변경 가능
- cinematic-video는 Google AI Ultra 구독 필요 (일일 쿼터 있음)
- 무료 계정은 최대 5개 노트북 — 파이프라인은 생성 후 자동 삭제
- 생성 시간: video ~5-10분, cinematic ~30-40분
