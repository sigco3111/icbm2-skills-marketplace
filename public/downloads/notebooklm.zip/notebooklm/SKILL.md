---
name: notebooklm
description: "Google NotebookLM 자동화 — 비디오/오디오/슬라이드 생성, 소스 관리, 다운로드 (일반 계정)"
tags: [notebooklm, video, audio, podcast, slide-deck, google, ai-content]
---

# Google NotebookLM 자동화 (일반 계정)

notebooklm-py를 사용해 Google NotebookLM의 모든 기능을 프로그래밍 방식으로 제어합니다.

## 전제 조건

| 항목 | 설명 |
|------|------|
| notebooklm-py v0.3.4+ | `~/.hermes/venv-notebooklm/`에 설치됨 |
| Python 3.13 | venv 전용 (시스템 패키지와 격리) |
| 구글 로그인 | `~/.hermes/venv-notebooklm/bin/activate && notebooklm login` |
| 인증 파일 | `~/.notebooklm/storage_state.json` |

## 인증

```bash
source ~/.hermes/venv-notebooklm/bin/activate
notebooklm login              # 브라우저 로그인
notebooklm auth check --test  # 인증 상태 확인
```

## 기본 사용법

모든 notebooklm 명령어는 반드시 venv 활성화 후 실행:

```bash
source ~/.hermes/venv-notebooklm/bin/activate
```

## 노트북 관리

```bash
notebooklm create "제목"           # 노트북 생성 (ID 반환)
notebooklm list                   # 노트북 목록
notebooklm use <notebook_id>      # 현재 노트북 설정
notebooklm delete <notebook_id>   # 노트북 삭제
```

## 소스 추가

```bash
# URL
notebooklm source add "https://example.com"

# YouTube 영상
notebooklm source add "https://youtube.com/watch?v=xxx"

# 로컬 파일 (PDF, 텍스트, 마크다운)
notebooklm source add "./paper.pdf"

# 인라인 텍스트
notebooklm source add "요약할 텍스트 내용" --title "제목"

# 웹 리서치 자동 수집 (시간 걸림, 2~5분)
notebooklm source add-research "검색어" --mode deep

# 소스 목록 확인
notebooklm source list
```

## 콘텐츠 생성

### 비디오 (YouTube 업로드용)

```bash
# Video Overview (빠름, ~5-10분)
notebooklm generate video "설명" --style whiteboard --language ko --wait
notebooklm download video ./output.mp4

# Cinematic Video (Veo 3, ~30-40분, AI Ultra 필요)
notebooklm generate cinematic-video "설명" --language ko --wait
notebooklm download cinematic-video ./output.mp4
```

**비디오 스타일:** `auto`, `classic`, `whiteboard`, `kawaii`, `anime`, `watercolor`, `retro-print`, `heritage`, `paper-craft`

**비디오 포맷:** `explainer` (기본), `brief`, `cinematic`

### 오디오 (팟캐스트)

```bash
notebooklm generate audio "설명" --format deep-dive --language ko --wait
notebooklm download audio ./podcast.mp3
```

**오디오 포맷:** `deep-dive` (기본), `brief`, `critique`, `debate`
**오디오 길이:** `short`, `default`, `long`

### 슬라이드 덱

```bash
notebooklm generate slide-deck "설명" --format detailed --language ko --wait
notebooklm download slide-deck ./slides.pdf     # PDF
notebooklm download slide-deck ./slides.pptx    # PPTX
```

### 기타 콘텐츠

```bash
# 인포그래픽 (PNG)
notebooklm generate infographic --orientation portrait --wait
notebooklm download infographic ./info.png

# 마인드맵 (JSON)
notebooklm generate mind-map --wait
notebooklm download mind-map ./mindmap.json

# 퀴즈
notebooklm generate quiz --difficulty hard --wait
notebooklm download quiz --format markdown ./quiz.md

# 플래시카드
notebooklm generate flashcards --quantity more --wait
notebooklm download flashcards --format json ./cards.json

# 리포트
notebooklm generate report --format blog-post --wait
notebooklm download report ./report.md

# 데이터 테이블 (CSV)
notebooklm generate data-table "비교 항목" --wait
notebooklm download data-table ./data.csv
```

## 채팅

```bash
notebooklm ask "질문"
```

## YouTube 업로드 파이프라인 (자동 노트북 정리 포함)

무료 계정은 최대 5개 노트북 제한이 있으므로, 업로드 완료 후 노트북을 자동 삭제합니다.

```bash
# 1. 노트북 생성 + 소스 추가
NOTEBOOK_ID=$(notebooklm create "주제")
notebooklm use $NOTEBOOK_ID
notebooklm source add "https://url1.com"
notebooklm source add "https://url2.com"

# 2. 비디오 생성 (한국어)
notebooklm generate video "한국어로 흥미롭게 설명해주세요" --style whiteboard --language ko --wait

# 3. 다운로드
notebooklm download video /tmp/video.mp4

# 4. YouTube 업로드 (youtube-uploader 스킬 사용)
cd /path/to/youtube-uploader/scripts
python3 upload.py /tmp/video.mp4 --title "제목" --description "설명" --category 28 --privacy public

# 5. 노트북 삭제 (무료 계정 5개 제한 관리)
notebooklm delete $NOTEBOOK_ID
```

⚠️ **필수:** 비디오 다운로드를 완료한 후에만 삭제하세요. 생성 콘텐츠는 다운로드 전에 노트북 삭제하면 유실됩니다.

## 주요 함정

| 문제 | 해결 |
|------|------|
| 일일 쿼터 제한 (cinematic-video) | `--retry 5` 추가, 1~24시간 대기 |
| 비디오 생성 타임아웃 | `--wait` 없이 생성 후 `download video`로 폴링 |
| 소스 처리 안 됨 | URL 추가 후 `source list`로 ready 상태 확인 |
| 인증 만료 | `notebooklm login` 재실행 |
| venv 미활성화 | 모든 명령어 앞에 `source ~/.hermes/venv-notebooklm/bin/activate` 필수 |
| httpx 충돌 | 시스템 Python이 아닌 반드시 venv 사용 |

## YouTube 자동화 파이프라인

`~/.hermes/scripts/notebooklm_youtube_pipeline.py` — NotebookLM → YouTube 일일 자동 업로드 시스템

### 일반 영상 (Video Overview)
```bash
python3 ~/.hermes/scripts/notebooklm_youtube_pipeline.py --mode video --type daily_tech
python3 ~/.hermes/scripts/notebooklm_youtube_pipeline.py --mode video --type ai_deep_review
```
파이프라인: 콘텐츠 수집 → 노트북 생성 → 소스 추가 → Video Overview 생성(whiteboard/ko) → MP4 다운로드 → YouTube 업로드 → 노트북 삭제

### 숏츠 (Audio Podcast → 60초 영상)
```bash
python3 ~/.hermes/scripts/notebooklm_youtube_pipeline.py --mode shorts --type ai_news
python3 ~/.hermes/scripts/notebooklm_youtube_pipeline.py --mode shorts --type github_trending
python3 ~/.hermes/scripts/notebooklm_youtube_pipeline.py --mode shorts --type dev_tip
python3 ~/.hermes/scripts/notebooklm_youtube_pipeline.py --mode shorts --type opensource
```
파이프라인: 콘텐츠 수집 → 노트북 생성 → 소스 추가 → Audio Podcast(brief/short/ko) → MP3 다운로드 → 60초 트리밍 → 배경 이미지 합성 → Shorts MP4 → YouTube 업로드 → 노트북 삭제

### 콘텐츠 타입

| 타입 | 모드 | 스케줄 | 설명 |
|------|------|--------|------|
| `daily_tech` | video | 23:15 | 데일리 테크 브리핑 (HN + Reddit) |
| `ai_deep_review` | video | 01:15 | AI/테크 심층 리뷰 |
| `ai_news` | shorts | 04:15 | AI 뉴스 속보 |
| `github_trending` | shorts | 00:15 | GitHub 트렌딩 프로젝트 |
| `dev_tip` | shorts | 22:15 | 개발 팁/인사이트 |
| `opensource` | shorts | 02:15 | 오픈소스 도구 소개 |

### 공통 옵션
```
--no-upload    # 업로드 생략 (테스트용)
--no-cleanup   # 노트북 삭제 생략
```

### 의존성
- notebooklm-py venv: `~/.hermes/venv-notebooklm/`
- Pillow (배경 이미지): hermes-agent venv에서 sys.path injection
- ffmpeg / ffprobe: 시스템
- YouTube 업로드: `~/.hermes/skills/creative/youtube-uploader/scripts/upload.py`

## 한계

- 비공식 API — 구글이 언제든 변경 가능
- cinematic-video는 Google AI Ultra 구독 필요 (일일 쿼터 있음)
- 무료 계정은 최대 5개 노트북 — 파이프라인은 생성 후 자동 삭제
- 생성 시간: video ~5-10분, cinematic ~30-40분, audio ~3-5분
