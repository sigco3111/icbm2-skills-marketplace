---
name: notebooklm
description: "Google NotebookLM 자동화 — 비디오 오버뷰 생성, 소스 관리, YouTube 업로드 (일반 계정)"
tags: [notebooklm, video, slide-deck, google, ai-content]
---

# Google NotebookLM 자동화 (일반 계정)

notebooklm-py를 사용해 Google NotebookLM의 모든 기능을 프로그래밍 방식으로 제어합니다.

## 전제 조건

| 항목 | 설명 |
|------|------|
| notebooklm-py v0.3.4+ | `~/.hermes/venv-notebooklm/`에 설치됨 |
| Python 3.13 | venv 전용 (시스템 패키지와 격리) |
| 구글 로그인 | `~/.hermes/venv-notebooklm/bin/activate && notebooklm login` |
| 인증 파일 | `~/.notebooklm/storage_state.json` |

## 인증

```bash
source ~/.hermes/venv-notebooklm/bin/activate
notebooklm login              # 브라우저 로그인
notebooklm auth check --test  # 인증 상태 확인
```

## 기본 사용법

모든 notebooklm 명령어는 반드시 venv 활성화 후 실행:

```bash
source ~/.hermes/venv-notebooklm/bin/activate
```

## 노트북 관리

```bash
notebooklm create "제목"           # 노트북 생성 (ID 반환)
notebooklm list                   # 노트북 목록
notebooklm use <notebook_id>      # 현재 노트북 설정
notebooklm delete <notebook_id>   # 노트북 삭제
```

## 소스 추가

```bash
# URL
notebooklm source add "https://example.com"

# YouTube 영상
notebooklm source add "https://youtube.com/watch?v=xxx"

# 로컬 파일 (PDF, 텍스트, 마크다운)
notebooklm source add "./paper.pdf"

# 인라인 텍스트
notebooklm source add "요약할 텍스트 내용" --title "제목"

# 웹 리서치 자동 수집 (시간 걸림, 2~5분)
notebooklm source add-research "검색어" --mode deep

# 소스 목록 확인
notebooklm source list
```

## 콘텐츠 생성

### 비디오 (YouTube 업로드용)

```bash
# Video Overview (빠름, ~5-10분)
notebooklm generate video "설명" --style whiteboard --language ko --wait
notebooklm download video ./output.mp4

# Cinematic Video (Veo 3, ~30-40분, AI Ultra 필요)
notebooklm generate cinematic-video "설명" --language ko --wait
notebooklm download cinematic-video ./output.mp4
```

**비디오 스타일:** `auto`, `classic`, `whiteboard`, `kawaii`, `anime`, `watercolor`, `retro-print`, `heritage`, `paper-craft`

**비디오 포맷:** `explainer` (기본), `brief`, `cinematic`

### 슬라이드 덱

```bash
notebooklm generate slide-deck "설명" --format detailed --language ko --wait
notebooklm download slide-deck ./slides.pdf     # PDF
notebooklm download slide-deck ./slides.pptx    # PPTX
```

### 기타 콘텐츠

```bash
# 인포그래픽 (PNG)
notebooklm generate infographic --orientation portrait --wait
notebooklm download infographic ./info.png

# 마인드맵 (JSON)
notebooklm generate mind-map --wait
notebooklm download mind-map ./mindmap.json

# 퀴즈
notebooklm generate quiz --difficulty hard --wait
notebooklm download quiz --format markdown ./quiz.md

# 플래시카드
notebooklm generate flashcards --quantity more --wait
notebooklm download flashcards --format json ./cards.json

# 리포트
notebooklm generate report --format blog-post --wait
notebooklm download report ./report.md

# 데이터 테이블 (CSV)
notebooklm generate data-table "비교 항목" --wait
notebooklm download data-table ./data.csv
```

## 채팅

```bash
notebooklm ask "질문"
```

## YouTube 업로드 파이프라인 (자동 노트북 정리 포함)

무료 계정은 최대 5개 노트북 제한이 있으므로, 업로드 완료 후 노트북을 자동 삭제합니다.

```bash
# 1. 노트북 생성 + 소스 추가
NOTEBOOK_ID=$(notebooklm create "주제")
notebooklm use $NOTEBOOK_ID
notebooklm source add "https://url1.com"
notebooklm source add "https://url2.com"

# 2. 비디오 생성 (한국어)
notebooklm generate video "한국어로 흥미롭게 설명해주세요" --style whiteboard --language ko --wait

# 3. 다운로드
notebooklm download video /tmp/video.mp4

# 4. YouTube 업로드
python3 ~/.hermes/scripts/notebooklm_youtube_pipeline.py --mode video --type daily_tech

# 5. 노트북 삭제 (무료 계정 5개 제한 관리)
notebooklm delete $NOTEBOOK_ID
```

⚠️ **필수:** 비디오 다운로드를 완료한 후에만 삭제하세요. 생성 콘텐츠는 다운로드 전에 노트북 삭제하면 유실됩니다.

## YouTube 업로드 파이프라인 (On-Demand)

사용자가 **이미 생성된 비디오 오버뷰**를 YouTube에 올려달라고 URL만 알려줄 때.

**절대 Playwright 사용 금지** — 네트워크 캡처/요소 탐색 불안정.
**CLI + ffmpeg + OAuth API 방식만 사용.**

```bash
# 1. CLI로 비디오 다운로드
source ~/.hermes/venv-notebooklm/bin/activate
notebooklm use <notebook_id>
notebooklm download video <notebook_id> /tmp/video.mp4

# 2. ffprobe로 정보 확인
ffprobe -v error -show_entries stream=width,height,duration -of json /tmp/video.mp4

# 3. 숏츠 생성 (60초, 9:16, letterbox 블러 배경)
# ⚠️ crop 방식ではなくletterbox 블러 방식 사용 (2026-04-30 수정)
ffmpeg -y -i /tmp/video.mp4 \
  -t 60 \
  -filter_complex "
[0:v]split=2[fg][bg];
[fg]scale=1080:-1[fg2];
[bg]scale=1080:1920,boxblur=20[bg2];
[0:a]atrim=0:60,afade=t=out:st=55:d=5[aout];
[bg2][fg2]overlay=(W-w)/2:(H-h)/2[vout]
" \
  -map "[vout]" -map "[aout]" \
  -c:v libx264 -preset ultrafast -crf 26 \
  -c:a aac -b:a 128k \
  -pix_fmt yuv420p -shortest \
  /tmp/shorts.mp4

# 4. YouTube OAuth 업로드
~/.hermes/hermes-agent/venv/bin/python3 -c "
import os, pickle
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

TOKEN = os.path.expanduser('~/.hermes/secrets/youtube_token.pickle')
with open(TOKEN, 'rb') as f:
    creds = pickle.load(f)
if creds.expired:
    creds.refresh(Request())
    with open(TOKEN, 'wb') as f:
        pickle.dump(creds, f)

youtube = build('youtube', 'v3', credentials=creds)
resp = youtube.videos().insert(
    part='snippet,status',
    body={
        'snippet': {
            'title': '영상 제목',
            'description': '설명\n\n#해시태그',
            'categoryId': '28',
        },
        'status': {'privacyStatus': 'public'}
    },
    media_body=MediaFileUpload('/tmp/video.mp4')
).execute()
print(f'URL: https://youtu.be/{resp[\"id\"]}')
"
```

**핵심 교훈 (2026-04-30):**
- Playwright 비디오 URL 캡처 → 실패 (blob URL, cross-origin iframe 등으로 실제 파일 URL 노출 안 됨)
- CLI `notebooklm download video` → 완벽 작동
- **항상 CLI 우선**

## 🚨 장애 처리 정책 (중요)

**비디오 오버뷰 생성 장애 발생 시:**
1. **재시도 금지** — 장애 감지 시 즉시 중단
2. 소스를 NotebookLM 노트북에 추가해둔 상태로 유지
3. **주인님에게 텔레그램으로 알림** — 어떤 노트북/소스에서 장애 발생했는지 명시
4. **알림에 추천 프롬프트 포함** —的主人님이 NotebookLM에서 직접 생성할 때 사용할 프롬프트 제공
5. 주인님이 직접 해당 노트북에서 생성 후, 편집/업로드를 ICBM2에 요청
6. **야간 크론잡에서도 동일** — 장애 시 텔레그램 메시지 남기고 대기

### 알림 메시지 형식 (텔레그램)

```
⚠️ NotebookLM 생성 장애

📝 노트북: {notebook_title} ({notebook_id})
🔧 작업: video_overview
📋 소스: {소스 목록 요약}
❌ 오류: {에러 내용}

— 아래 프롬프트를 NotebookLM에서 직접 실행해주세요 —

{추천 프롬프트}

완료되면 편집/업로드 요청해주세요!
```

### 추천 프롬프트 템플릿

```
이 소스들을 바탕으로 한국어로 흥미롭게 설명하는 비디오 오버뷰를 만들어주세요. 전문적이면서도 일반인이 이해하기 쉬운 톤으로, 핵심 내용을 논리적으로 전달해주세요.
```

> ⚠️ 프롬프트는 콘텐츠 타입(ai_news, github_trending 등)에 맞게 문맥을 추가해서 제공할 것

## Notion DB → NotebookLM 워크플로우

**크론 트리거:** 매일 16:00 →侯選 전송 → 사용자 선택 → 생성

###侯選 URL 원칙

1. **URL이 있는 활성 topic만** → NotebookLM 소스로 추가
2. **URL 없으면 → 스킵** (키워드 수집 폴백 없음)

### 워크플로우

```
16:00 크론 실행
  → notebooklm_selection.py 실행
    → Notion DB에서 URL 있는 활성 topic 조회
    →侯選 topic 텔레그램 전송 (선택 요청)
    → 선택 결과를 notebooklm_selection.json에 저장

사용자가 번호 선택 (예: 1,3,5)
  → 에이전트가 notebooklm_prepare.py 실행
    → 선택된 topic의 URL로 NotebookLM 노트북 생성
    → 소스(Notion DB URL) 추가
    → 완료 텔레그램 전송
```

###侯選 topic 선택 예시

```
🎬 *NotebookLM侯選 주제*
...
1. 🤖 Claude한테 짜게 시키고...
2. 🤖 DeepSeek-V4 논문 읽기 요약
...

💡 Tip: 쉼표로 여러 개 선택 가능 (예: 1,3,5,7)
⏰ 선택 후 'NotebookLM 생성' 이라고 알려주세요
```

###侯選가 있는 경우
Notion DB의 `상태 == "활성"` topic 중 `URL` 필드가 있는 것만侯選로 표시

###侯選가 없는 경우
URL 없는 topic은侯選에서 제외 — "NotebookLM 생성" 시 스킵

## 주요 함정

| 문제 | 해결 |
|------|------|
| 일일 쿼터 제한 (cinematic-video) | `--retry 5` 추가, 1~24시간 대기 |
| 비디오 생성 타임아웃 | `--wait` 없이 생성 후 `download video`로 폴링 |
| Video Overview pending 멈춤 | NotebookLM 서버 측 이슈. `--wait --retry 5` 옵션 사용. 업데이트: `pip install git+https://github.com/teng-lin/notebooklm-py.git`. 노트북 55개 제한 있음 |
| YouTube 제목 덮어쓰기 버그 | 출처 빌드 루프에서 `title = item.get("title")`이 YouTube 제목 덮어씀 → `item_title`, `item_url`, `item_source` 지역 변수명 사용 |
| **키워드 수집 불일치** |侯選 URL 우선 — Notion DB에 없으면 긱뉴스 크롤링으로 URL 직접查找. 자동 키워드 검색 금지 |
| **9:16 블러 필터 crop 버그** | `scale=...:increase,crop=1080:1920` → crop이 letterbox 영역 자름 → 블러 안 됨. crop 제거: `scale=1080:1920,boxblur=20` |
| **pipeline_shorts shorts_type 버그** | `notebooklm_youtube_pipeline.py`에서 `build_youtube_description(shorts_type, ...)` → `content_type`으로 수정 |
| stdout 버퍼링 | 백그라운드 프로세스는 `PYTHONUNBUFFERED=1` 또는 `python3 -u` 사용. 폴링 중 `in_progress`만 반복 — kill하지 말고 기다릴 것 |
| 소스 처리 안 됨 | URL 추가 후 `source list`로 ready 상태 확인 |
| 소스 JSON 파싱 실패 | `source list --json`은 `{sources:[...]}` 형태, 최상위 배열 아님 |
| 폰트 경로 오류 | macOS 폰트는 `.otf`가 아닌 `.ttc`(TrueType Collection) — `AppleSDGothicNeo.ttc` |
| 인증 만료 | `notebooklm login` 재실행 |
| venv 미활성화 | 모든 명령어 앞에 `source ~/.hermes/venv-notebooklm/bin/activate` 필수 |
| httpx 충돌 | 시스템 Python이 아닌 반드시 venv 사용 |
| 숏츠 길이 약간 초과 | 60초 초과 약간 허용됨 (주인님 명시) |

## 스크립트

- `~/.hermes/scripts/notebooklm_youtube_pipeline.py` — Video Overview + Shorts 파이프라인
- `~/.hermes/scripts/notebooklm_prepare.py` — 노트북 생성 + 소스 추가
- `~/.hermes/scripts/notebooklm_upload.py` — 다운로드 + YouTube 업로드 + 삭제

## 한계

- 비공식 API — 구글이 언제든 변경 가능
- cinematic-video는 Google AI Ultra 구독 필요 (일일 쿼터 있음)
- 무료 계정은 최대 5개 노트북 — 파이프라인은 생성 후 자동 삭제
- 생성 시간: video ~5-10분, cinematic ~30-40분
