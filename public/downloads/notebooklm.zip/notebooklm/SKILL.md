---
name: notebooklm
description: "Google NotebookLM 자동화 — 비디오/오디오/슬라이드 생성, 소스 관리, 다운로드 (일반 계정)"
tags: [notebooklm, video, audio, podcast, slide-deck, google, ai-content]
---

# Google NotebookLM 자동화 (일반 계정)

notebooklm-py를 사용해 Google NotebookLM의 모든 기능을 프로그래밍 방식으로 제어합니다.

## 전제 조건

| 항목 | 설명 |
|------|------|
| notebooklm-py v0.3.4+ | `~/.hermes/venv-notebooklm/`에 설치됨 |
| Python 3.13 | venv 전용 (시스템 패키지와 격리) |
| 구글 로그인 | `~/.hermes/venv-notebooklm/bin/activate && notebooklm login` |
| 인증 파일 | `~/.notebooklm/storage_state.json` |

## 인증

```bash
source ~/.hermes/venv-notebooklm/bin/activate
notebooklm login              # 브라우저 로그인
notebooklm auth check --test  # 인증 상태 확인
```

## 기본 사용법

모든 notebooklm 명령어는 반드시 venv 활성화 후 실행:

```bash
source ~/.hermes/venv-notebooklm/bin/activate
```

## 노트북 관리

```bash
notebooklm create "제목"           # 노트북 생성 (ID 반환)
notebooklm list                   # 노트북 목록
notebooklm use <notebook_id>      # 현재 노트북 설정
notebooklm delete <notebook_id>   # 노트북 삭제
```

## 소스 추가

```bash
# URL
notebooklm source add "https://example.com"

# YouTube 영상
notebooklm source add "https://youtube.com/watch?v=xxx"

# 로컬 파일 (PDF, 텍스트, 마크다운)
notebooklm source add "./paper.pdf"

# 인라인 텍스트
notebooklm source add "요약할 텍스트 내용" --title "제목"

# 웹 리서치 자동 수집 (시간 걸림, 2~5분)
notebooklm source add-research "검색어" --mode deep

# 소스 목록 확인
notebooklm source list
```

## 콘텐츠 생성

### 비디오 (YouTube 업로드용)

```bash
# Video Overview (빠름, ~5-10분)
notebooklm generate video "설명" --style whiteboard --language ko --wait
notebooklm download video ./output.mp4

# Cinematic Video (Veo 3, ~30-40분, AI Ultra 필요)
notebooklm generate cinematic-video "설명" --language ko --wait
notebooklm download cinematic-video ./output.mp4
```

**비디오 스타일:** `auto`, `classic`, `whiteboard`, `kawaii`, `anime`, `watercolor`, `retro-print`, `heritage`, `paper-craft`

**비디오 포맷:** `explainer` (기본), `brief`, `cinematic`

### 오디오 (팟캐스트)

```bash
notebooklm generate audio "설명" --format deep-dive --language ko --wait
notebooklm download audio ./podcast.mp3
```

**오디오 포맷:** `deep-dive` (기본), `brief`, `critique`, `debate`
**오디오 길이:** `short`, `default`, `long`

### 슬라이드 덱

```bash
notebooklm generate slide-deck "설명" --format detailed --language ko --wait
notebooklm download slide-deck ./slides.pdf     # PDF
notebooklm download slide-deck ./slides.pptx    # PPTX
```

### 기타 콘텐츠

```bash
# 인포그래픽 (PNG)
notebooklm generate infographic --orientation portrait --wait
notebooklm download infographic ./info.png

# 마인드맵 (JSON)
notebooklm generate mind-map --wait
notebooklm download mind-map ./mindmap.json

# 퀴즈
notebooklm generate quiz --difficulty hard --wait
notebooklm download quiz --format markdown ./quiz.md

# 플래시카드
notebooklm generate flashcards --quantity more --wait
notebooklm download flashcards --format json ./cards.json

# 리포트
notebooklm generate report --format blog-post --wait
notebooklm download report ./report.md

# 데이터 테이블 (CSV)
notebooklm generate data-table "비교 항목" --wait
notebooklm download data-table ./data.csv
```

## 채팅

```bash
notebooklm ask "질문"
```

## YouTube 업로드 파이프라인 (자동 노트북 정리 포함)

무료 계정은 최대 5개 노트북 제한이 있으므로, 업로드 완료 후 노트북을 자동 삭제합니다.

```bash
# 1. 노트북 생성 + 소스 추가
NOTEBOOK_ID=$(notebooklm create "주제")
notebooklm use $NOTEBOOK_ID
notebooklm source add "https://url1.com"
notebooklm source add "https://url2.com"

# 2. 비디오 생성 (한국어)
notebooklm generate video "한국어로 흥미롭게 설명해주세요" --style whiteboard --language ko --wait

# 3. 다운로드
notebooklm download video /tmp/video.mp4

# 4. YouTube 업로드 (youtube-uploader 스킬 사용)
cd /path/to/youtube-uploader/scripts
python3 upload.py /tmp/video.mp4 --title "제목" --description "설명" --category 28 --privacy public

# 5. 노트북 삭제 (무료 계정 5개 제한 관리)
notebooklm delete $NOTEBOOK_ID
```

⚠️ **필수:** 비디오 다운로드를 완료한 후에만 삭제하세요. 생성 콘텐츠는 다운로드 전에 노트북 삭제하면 유실됩니다.

## 주요 함정

| 문제 | 해결 |
|------|------|
| 일일 쿼터 제한 (cinematic-video) | `--retry 5` 추가, 1~24시간 대기 |
| 비디오 생성 타임아웃 | `--wait` 없이 생성 후 `download video`로 폴링 |
| Video Overview pending 멈춤 (2026-04-19~) | NotebookLM 서버 측 장애. Video Overview 완전 불가, Audio deep-dive 간헐적 타임아웃, brief/short만 안정. 22:15/23:15 크론잡을 Video→Podcast+Manim으로 대체 운영 중. `podcast_manim_pipeline.py --type daily_tech/github_trending` |
| stdout 버퍼링으로 프로세스误kill | 백그라운드 프로세스는 `PYTHONUNBUFFERED=1`+`-u` 써도 Manim 단계 출력이 버퍼링됨. 폴링 중엔 `in_progress`만 반복해서 새 출력 없음 — kill하지 말고 기다릴 것 |
| 소스 처리 안 됨 | URL 추가 후 `source list`로 ready 상태 확인 |
| 소스 JSON 파싱 실패 | `source list --json`은 `{sources:[...]}` 형태, 최상위 배열 아님 |
| 폰트 경로 오류 | macOS 폰트는 `.otf`가 아닌 `.ttc`(TrueType Collection) — `AppleSDGothicNeo.ttc` |
| 인증 만료 | `notebooklm login` 재실행 |
| venv 미활성화 | 모든 명령어 앞에 `source ~/.hermes/venv-notebooklm/bin/activate` 필수 |
| httpx 충돌 | 시스템 Python이 아닌 반드시 venv 사용 |
| stdout 버퍼링 (파이프라인) | `PYTHONUNBUFFERED=1` 또는 `python3 -u` 사용 |
| 숏츠 길이 약간 초과 | 60초 초과 약간 허용됨 (주인님 명시) |

## 🎯 주인님이 직접 YouTube 업로드를 요청할 때

주인님이 대화에서 "유튜브에 올려줘", "영상 만들어줘" 등으로 YouTube 업로드를 요청하면, **반드시 먼저 형식을 선택하도록 물어봐라.**

### 선택지

| 항목 | 비디오 오버뷰 | 팟캐스트 |
|------|-------------|---------|
| 엔진 | NotebookLM Video Overview | Edge TTS + Manim v2 |
| 형식 | 화이트보드 애니메이션 영상 | 남녀 2인진 대화 + Manim 배경 |
| 목소리 | 1인 내레이션 (NotebookLM 기본) | SunHi(여) + InJoon(남) 교차 |
| 길이 | 5~10분 (소스 양에 따라) | 5~7분 |
| 장점 | 시각적 설명 강점, 자연스러운 흐름 | 팟캐스트 느낌, 남녀 대화로 생동감 |
| 단점 | 목소리 선택 불가, NotebookLM 의존 | Manim 배경이 단순 |
| 적합한 주제 | 기술 설명, 튜토리얼, 리뷰 | 뉴스 분석, 트렌드 토크, 의견 교환 |

### 물어보는 방식

```
영상 형식을 선택해주세요:

1. 🎬 비디오 오버뷰 — NotebookLM 화이트보드 애니메이션 (5~10분)
2. 🎙️ 팟캐스트 — 남녀 2인진 대화 + Manim (5~7분)
```

주인님이 선택하면 해당 형식에 맞는 파이프라인을 실행한다.

**⚠️ 크론잡에는 영향 없음** — 크론잡은 각각 고정 형식으로 이미 설정됨

---

## YouTube 자동화 파이프라인

`~/.hermes/scripts/notebooklm_youtube_pipeline.py` — NotebookLM → YouTube 일일 자동 업로드 시스템

### 일반 영상 (Video Overview)
```bash
python3 ~/.hermes/scripts/notebooklm_youtube_pipeline.py --mode video --type daily_tech
python3 ~/.hermes/scripts/notebooklm_youtube_pipeline.py --mode video --type ai_deep_review
```
파이프라인: 콘텐츠 수집 → 노트북 생성 → 소스 추가 → Video Overview 생성(whiteboard/ko) → MP4 다운로드 → YouTube 업로드 → 노트북 삭제

### 팟캐스트+Manim 일반 영상 (Audio Podcast 남녀 2인진 + Manim 애니메이션)
```bash
python3 ~/.hermes/scripts/podcast_manim_pipeline.py --type ai_news
python3 ~/.hermes/scripts/podcast_manim_pipeline.py --type github_trending
```
파이프라인: 콘텐츠 수집 → 노트북 생성 → 소스 추가 → Audio Podcast(deep-dive/long/ko, 남녀 2인진) → MP3 다운로드 → Manim 스크립트 자동 생성 → Manim 렌더링 → 팟캐스트 오디오+Manim 영상 합성(ffmpeg) → YouTube 업로드 → 노트북 삭제

### 숏츠 (Audio Podcast → 60초 영상)
```bash
python3 ~/.hermes/scripts/notebooklm_youtube_pipeline.py --mode shorts --type ai_news
```
파이프라인: 콘텐츠 수집 → 노트북 생성 → 소스 추가 → Audio Podcast(brief/short/ko) → MP3 다운로드 → 60초 트리밍 → 배경 이미지 합성(한글 폰트=AppleSDGothicNeo.ttc) → Shorts MP4 → YouTube 업로드 → 노트북 삭제

### 콘텐츠 타입

| 타입 | 모드 | 스케줄 | 설명 |
|------|------|--------|------|
| `daily_tech` | podcast_manim | 22:15 | 데일리 테크 브리핑 (HN + Reddit) — 2026-04-21부터 Video→Podcast+Manim으로 변경 |
| `github_trending` | podcast_manim | 23:15 | GitHub 트렌딩 분석 — 2026-04-21부터 Video→Podcast+Manim으로 변경 |
| `ai_news` | podcast_manim | 00:15 | AI 뉴스 심층 팟캐스트 (남녀 2인진+Manim) |
| `github_trending` | podcast_manim | 01:15 | GitHub 트렌딩 분석 팟캐스트 (남녀 2인진+Manim) |
| `ai_news` | shorts | 02:15 | AI 뉴스 속보 |

### 공통 옵션
```
--no-upload    # 업로드 생략 (테스트용)
--no-cleanup   # 노트북 삭제 생략
```

### 의존성
- notebooklm-py venv: `~/.hermes/venv-notebooklm/`
- Pillow (배경 이미지): hermes-agent venv에서 sys.path injection
- Manim Community Edition: `pip install manim` (podcast_manim 모드)
- ffmpeg / ffprobe: 시스템
- YouTube 업로드: `~/.hermes/skills/creative/youtube-uploader/scripts/upload.py`

## 스크립트
- `~/.hermes/scripts/notebooklm_youtube_pipeline.py` — Video Overview + Shorts 파이프라인
- `~/.hermes/scripts/podcast_manim_pipeline.py` — Podcast+Manim 일반 영상 파이프라인

## 한계

- 비공식 API — 구글이 언제든 변경 가능
- cinematic-video는 Google AI Ultra 구독 필요 (일일 쿼터 있음)
- 무료 계정은 최대 5개 노트북 — 파이프라인은 생성 후 자동 삭제
- 생성 시간: video ~5-10분, cinematic ~30-40분, audio ~3-5분
