---
name: perpetual-engine-zai
description: Multi-agent AI startup framework fork with ZAI (GLM) support. Provider adapter pattern, concurrency limiter, agent team design for ICBM2.
---

# Perpetual Engine ZAI

Multi-agent AI startup framework fork with ZAI (GLM) support.

## Overview
- **Original:** https://github.com/greatsk55/perpetual-engine
- **Fork:** https://github.com/sigco3111/perpetual-engine-zai
- Claude Code CLI 기반 멀티 에이전트 프레임워크를 ZAI(GLM) 지원하도록 개조
- Hermes 없이 독립 동작 (Node.js + tmux + Express 대시보드)

## Key Modifications from Original
- **Provider Adapter Pattern:** `provider-adapter.ts` 인터페이스로 런타임 추상화
  - `providers/claude-code-adapter.ts` — Claude Code CLI (원본 호환)
  - `providers/opencode-adapter.ts` — OpenCode 지원
  - `providers/http-api-adapter.ts` — ZAI/OpenAI HTTP API 지원
- **Concurrency Limiter:** `concurrency-limiter.ts` — 모델별 동시성 큐 관리
- **Config Extension:** `agent_providers`, `providers`, `concurrency` 설정 추가
- **Agent Skills:** Claude Code 슬래시 커맨드 → 프롬프트 기반 스킬 변환
- **Installation Guide:** `docs/installation-guide.md` — LLM 에이전트 자동 설치 지원

## Agent Team Design (ICBM2용)
| Role | Runtime | Concurrency | Notes |
|------|---------|-------------|-------|
| PM | Hermes/HTTP API (GLM-4-Plus, 동시20) | 자유 | 오케스트레이션 |
| Coder | OpenCode CLI (ZAI 코딩플랜) | **큐 기반 순차** | GLM-5-Turbo 동시1 제한 준수 |
| Writer | HTTP API (GLM-4.5, 동시10) | 병렬 OK | 콘텐츠 생성 |
| Researcher | HTTP API (GLM-4.5, 동시10) | 병렬 OK | 정보 수집/분석 |
| Trader | HTTP API (GLM-4.5, 동시10) | 병렬 OK | 투자 분석 |
| Ops | HTTP API (GLM-4.5, 동시10) | 병렬 OK | 시스템 운영/미디어 |

## Concurrency Strategy
- Coder가 GLM-5-Turbo(동시1) 사용 중일 때, Hermes 본체는 GLM-4.5/4-Plus로 폴백하여 충돌 방지
- 상세 제한: `~/.hermes/docs/zai-rate-limits.md` 참조

## Remaining Work
1. `session-manager.ts`가 ProviderAdapter 사용하도록 리팩토링
2. `orchestrator.ts`가 ConcurrencyLimiter 연결
3. 통합 테스트 + ZAI API 엔드투엔드 테스트

## History
- 2026-04-20: 포크 생성, 핵심 모듈 7개 추가, 4개 파일 수정, PR #1 머지 (빌드 에러 수정)
