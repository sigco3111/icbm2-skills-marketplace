---
name: invest-memo
description: 투자 관련 뉴스와 시황을 매일 Notion에 기록 — 한국/미국 주식 시장 종합
version: 1.0.0
author: icbm2
metadata:
  hermes:
    tags: [Investment, Stock, Notion, Daily]
prerequisites:
  secret_files: [notion_idea_token.txt]
---

# 투자 메모

매일 투자 관련 주요 뉴스와 시황을 Notion DB에 기록합니다.

## Notion DB

- **DB ID:** `33c76f2e-9097-8107-800f-efc2f699aa93`
- **DB명:** Invest Memo
- **속성:** Name(title), Date(date), Ticker(rich_text), Sentiment(select), URL(url)
- **Sentiment 옵션:** Bullish, Bearish, Neutral

## 실행 단계

### 1. 시장 데이터 수집

stock-market-tracker 스킬의 데이터 수집 방식 참고:

- 한국 시장: pykrx로 주요 지표(KOSPI, KOSDAQ) 수집
- 미국 시장: S&P 500, NASDAQ, VIX 지표
- 당일 주요 뉴스: 경제 뉴스 사이트에서 투자 관련 헤드라인 수집

### 2. Notion에 기록

```python
import os, json, subprocess
from datetime import datetime, timezone, timedelta

TK_PATH = os.environ["NOTION_TOKEN_PATH"]
DB_ID = "33c76f2e-9097-8107-800f-efc2f699aa93"
today = datetime.now(timezone(timedelta(hours=9))).strftime("%Y-%m-%d")

with open(TK_PATH) as f:
    tk = f.read().strip()

payload = {
    "parent": {"database_id": DB_ID},
    "properties": {
        "Name": {"title": [{"text": {"content": "제목"}}]},
        "Date": {"date": {"start": today}},
        "Ticker": {"rich_text": [{"text": {"content": "AAPL"}}]},
        "Sentiment": {"select": {"name": "Bullish"}},
        "URL": {"url": "https://..."}
    }
}
with open("/tmp/notion_entry.json", "w") as f:
    json.dump(payload, f, ensure_ascii=False)

env = dict(os.environ)
env["NTK"] = tk
r = subprocess.run(
    f'curl -s -X POST --max-time 15 https://api.notion.com/v1/pages -H "Authorization: Bearer $NTK" -H "Notion-Version: 2022-06-28" -H "Content-Type: application/json" -d @/tmp/notion_entry.json',
    shell=True, capture_output=True, text=True, env=env
)
```

### 3. 품질 기준

- **최소 3개, 최대 7개** 항목 기록
- 주요 지표(KOSPI, NASDAQ 등) 요약 1개는 항상 포함
- 각 항목에 1-2문장 요약을 페이지 본문에 추가
- Ticker가 있는 뉴스는 반드시 Ticker 속성에 기입
- **관련 링크가 여러 개 있으면 본문에 bullet_list로 추가 기록** (각 링크에 출처 1줄 설명 포함)
- 한국어로 작성

### 4. 완료 확인

기록된 항목 수와 당일 시장 요약을 출력.
