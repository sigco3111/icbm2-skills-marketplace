---
name: ai-tool-evaluation-skip-criteria
description: "Use when evaluating AI tool adoption. 5-gate skip check."
version: 0.1.0
platforms: [macos, linux]
metadata:
  hermes:
    tags: [evaluation, ai-tools, decision-making, due-diligence]
    trigger: "도구 도입 후보 평가, 새 라이브러리 검토, OSS 서비스 도입"
---

# AI 도구 도입 평가 — Skip Criteria 가드레일

새 AI 도구/OSS/서비스 도입을 검토할 때 **시간 낭비 방지** 체크리스트. 도입 결정 전 반드시 5단계 게이트 통과.

## When to Use

- 새 AI 라이브러리/CLI/스킬을 "써보자" 하기 직전
- GitHub trending/블로그에서 흥미로운 프로젝트 발견
- "이거 우리 워크플로우에 끼우면 좋겠다" 싶을 때
- 크레딧/API 키 비용이 따르는 유료 의존성 도입 검토

## When NOT to Use

- 단순 라이브러리 1개 import (가벼운 의존성)
- 이미 검증된 도구의 minor 버전 업그레이드
- 삭제/정리 의사결정 (별도 `automation-decommission` 스킬)

## 5단계 Skip Criteria (게이트)

설치/setup 시작 전에 아래 5개를 모두 통과해야 진행. 하나라도 막히면 보류.

### 1. Real use case (정량)
"이걸로 무엇을 자동화/가속할 것인가?" 답할 수 있어야 함.

실패 신호:
- "그냥 신기해서" / "트렌드라서"
- 현재 워크플로우에서 해당 작업 빈도 **월 1회 미만**
- 기존 도구로 대체 가능 (TTS→edge-tts, 영상후처리→수동 편집 등)

**Skip**: ✗ 사용 빈도/대체재 확인 전 진행 금지

### 2. 의존성 비용 가시화
유료 API/서비스 의존성이 있으면 **구체적 비용** + **무료 한도** 명시.

체크:
- 필수 유료 API (예: ElevenLabs Scribe)
- 월 비용 추정 (사용 빈도 × 단가)
- 무료 티어 한도 + 초과 시 강제 과금 여부
- 키 발급/관리 부담

**Skip 트리거**: "돈이 들지만 정당화 못 함"

이번 video-use 사례:
- 1시간 영상 = $3~$6
- 실제 활용 영상 **0건**
- → Skip ✗

### 3. 대안 가능성 (lock-in 위험)
핵심 기능을 대체할 수 있는지가 도입 가치 결정.

예시:
- ElevenLabs Scribe → OpenAI Whisper (어댑터 작업 필요, 1~2시간)
- 단, video-use가 Scribe 응답 포맷에 **강결합** → 어댑터 비용 높음 → ROI 불확실

**질문**: "유료 의존성을 빠지는 fork 작업 비용 vs 도입 가치"

### 4. Setup 부담 (관대한 추정)
README를 **처음부터 끝까지** 읽고 실제 setup 시간·난이도 산정.

과대평가 금지:
- "5분이면 되겠지" → 실제로는 의존성 5개 + 인증 3개 + 디버깅 30분
- setup.md/install.md가 없으면 위험 (영어/README 가정)
- macOS-specific 함정 (Apple Silicon vs x86)

**Skip**: setup.md 없거나 "follow README"만 있는 경우

### 5. 트리거 재방문 조건 명시
보류 결정 시 **언제 다시 꺼낼지** 메모. "나중에 다시" 라는 모호한 보류 금지.

예 (video-use):
- 정기적으로 토크 헤드/인터뷰 영상 쌓이기 시작
- 유튜브 자동화 파이프라인에 영상 후처리 단계 필요
- Whisper 베이스 OSS 대안이 성숙

## Workflow

```
후보 발견 → 5단계 게이트 자동 검사
  │
  ├─ 모두 통과:  setup 프롬프트 작성 → 설치
  └─ 1개+ 실패:  Skip + 트리거 조건 기록 → 30일 후 재평가
```

## Skip Decision 기록 템플릿

보류 시 `~/.hermes/memory/skip-decisions.log` 또는 session_search 인덱스에:

```markdown
## [YYYY-MM-DD] <도구명>
- 후보: github.com/...
- skip 사유: (Real use case / 의존성 비용 / 대안 부족 / setup / 우선순위)
- 추정 비용: (유료 의존성 있을 때만)
- 재방문 트리거: (구체적 조건 1~2개)
```

## Common Pitfalls

1. **"신기해서 해보자"** — 검증된 필요성 없이 setup → 시간 낭비
2. **유료 의존성 숨기기** — "일단 무료 키만..." 이라고 나중에 월 $50 청구 받는 구조도 있음
3. **README skim** — 설치/README 안 읽고 추상적으로 "통합 어려워보인다" 판단
4. **Fork 작업 과대평가** — "어댑터 만들면 되겠지" → 실제로는 4시간+
5. **모호한 보류** — "나중에 다시" 라고만 남김 → 영원히 안 봄

## Related Skills

- `automation-decommission` — 이미 도입한 도구 정리
- `investment-memo` — 비용/ROI 가시화 패턴
- `ai-model-tracker` — 모델 릴리즈 추적 (도입 후보 발굴 직전 단계)

## Session Notes

- 2026-07-28: video-use skip 결정에서 패턴 추출. 5단계 게이트 명문화.
