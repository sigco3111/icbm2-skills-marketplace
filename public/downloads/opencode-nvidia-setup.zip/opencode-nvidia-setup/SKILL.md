---
name: opencode-nvidia-setup
description: OpenCode + oh-my-openagent NVIDIA NIM 설정 및 에이전트 스쿼드 구성
---

# OpenCode + oh-my-openagent NVIDIA NIM 설정

## 목적
NVIDIA NIM API 4 개 키를 활용하여 OpenCode 와 oh-my-openagent 플러그인을 최적화한 에이전트 스쿼드 구성.

## 설정 파일
- **위치**: `~/.config/opencode/oh-my-openagent.json`
- **주의**: 파일명은 `oh-my-openagent.json` (agents.json 아님)

## NVIDIA API 키 관리
- **키 파일**: `~/.hermes/secrets/nvidia_keys.env`
- **키 구성**:
  - `NVIDIA_API_KEY_HERMES`: 에르메스 전용
  - `NVIDIA_API_KEY_OPENCODE_1`, `NVIDIA_API_KEY_OPENCODE_2`: OpenCode 전용 (키 1, 2)
  - `NVIDIA_API_KEY_CLAUDE`: Claude Code 전용
- **키 교체 스크립트**: `~/.hermes/scripts/nvidia_key_rotator_opencode.py`
  - OpenCode 실행 시 키 1, 2 를 랜덤/라운드로빈으로 선택하여 `NVIDIA_API_KEY` 환경 변수 설정
  - 실행 권한 부여: `chmod +x ~/.hermes/scripts/nvidia_key_rotator_opencode.py`

## 에이전트 매핑 (최종 확정)
| 에이전트 | 모델 | 용도 |
|---|---|---|
| `sisyphus` (메인) | `Qwen/Qwen3-Coder-480B-A35B-Instruct` | 코딩, 리팩토링, 디버깅 |
| `oracle` | `Qwen/Qwen3-Coder-480B-A35B-Instruct` | 아키텍처 설계 |
| `librarian` | `Qwen/Qwen3-Coder-480B-A35B-Instruct` | 코드 분석/검색 |
| `explore` | `Qwen/Qwen3-Coder-480B-A35B-Instruct` | 아이디어 탐색 |
| `multimodal-looker` | `meta/llama-3.2-90b-vision-instruct` | 비전/이미지 분석 |
| `prometheus` | `meta/llama-3.1-405b-instruct` | 모니터링/이상 탐지 |
| `metis` | `meta/llama-3.1-405b-instruct` | 전략/계획 |
| `momus` | `nvidia/nemotron-3-super-120b-a12b` | 창의적 사고 |
| `atlas` | `Qwen/Qwen3-Coder-480B-A35B-Instruct` | 문서화 |
| `sisyphus-junior` | `Qwen/Qwen3-Coder-480B-A35B-Instruct` | 경량 작업 |

## 동시성 설정
```json
"background_task": {
  "providerConcurrency": {
    "qwen": 6,
    "meta": 4,
    "github-copilot": 3,
    "nvidia": 3
  }
}
```

## 실행 방법
1. **환경 변수 로드**: `source ~/.hermes/secrets/nvidia_keys.env`
2. **OpenCode 실행**: `opencode` 또는 `python3 ~/.hermes/scripts/nvidia_key_rotator_opencode.py`
3. **에이전트 전환**: TUI 에서 `/agent sisyphus`

## 주의사항
- **모델명 정확성**: 설정 파일의 모델명은 오픈코드 TUI 에서 표시되는 이름과 대소문자/기호 정확히 맞춤 (예: `Qwen/Qwen3-Coder-480B-A35B-Instruct`)
- **파일명**: `oh-my-openagent.json` 사용 (agents.json 아님)
- **키 교체**: OpenCode 실행 시 키 교체 스크립트 사용 권장

## 문제 해결
- **에러 "model is not valid"**: 모델명 대소문자/기호 재확인, TUI 에서 직접 선택 후 자동 업데이트 시도
- **설정 파일 로드 안 됨**: 파일명 `oh-my-openagent.json` 확인, `opencode` 재시작