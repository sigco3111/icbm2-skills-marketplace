---
name: opencode-nvidia-setup
description: OpenCode와 oh-my-opencode 플러그인을 NVIDIA NIM API로 설정하는 워크플로. brew의 oh-my-agent는 다른 프로젝트 - npm `oh-my-opencode` (2026-07-09 사용자 코렉션). install (bunx 비대화형), TUI 재시작, config JSON 덮어쓰기, 모델 매핑 검증 포함. NIM 모델 ID는 provider-prefix + catalog-id 형식 (예 nvidia/openai/gpt-oss-120b). 2026-07-09 라이브 검증.
---

# OpenCode + oh-my-opencode NVIDIA NIM 설정

## ⚠️ 패키지 이름 식별 (2026-07-09 사용자 코렉션, 2번째)

주인님가 **"오마이오픈에이전트"** 라고 말할 때는 **세 가지 가능한 프로젝트**가 있어요. 항상 schema URL 또는 config 파일 내용으로 식별:

| 이름 | 배포 채널 | 정체 | 정식 install |
|---|---|---|---|
| `oh-my-agent` | brew | Multi-Agent Orchestrator for AI IDEs (12,418 파일, 95.9MB) | `brew install oh-my-agent` |
| **`oh-my-opencode`** | **npm (code-yeongyu/oh-my-opencode, 실제 시그니처)** | **OpenCode 전용 플러그인 (11 agents, 54+ hooks, 5 MCPs)** | **`bunx oh-my-opencode@latest install`** |
| `oh-my-openagent` (구명) | ❌ 더 이상 사용 안 함 | 2026-07-09 시점에 npm 패키지명 `oh-my-openagent`는 deprecated/typo. 실제 프로젝트는 `oh-my-opencode` | — |

**식별 신호 (2026-07-09 확정)**:
- 사용자가 보낸 config JSON의 `$schema` URL: `https://raw.githubusercontent.com/code-yeongyu/oh-my-opencode/dev/...` → **`oh-my-opencode`** (npm)
- `bunx oh-my-opencode --version` → `4.16.0` 또는 `4.13.0` 출력 → `oh-my-opencode` 정상
- `bunx oh-my-openagent --version` → npm 패키지 없으면 ENOENT, 있으면 deprecated 별칭일 수 있음
- 워크플로 키워드 "ultrawork", "ulw", "Sisyphus", "Team Mode" → **`oh-my-opencode`**

**교훈 (2026-07-09 toss-trader 실측)**: README/AGENTS.md 작성 시 "**oh-my-openagent**" 라고 적었는데 사용자가 "**bun install oh-my-opencode@latest로 설치해서 사용 중**" 이라고 직접 코렉션. **첫 단어 `oh-my-openagent`(agent) vs `oh-my-opencode`(opencode)** — 한 글자 차이인데 단어 자체가 흔해서 그럴듯했음. **다음부턴 `bunx <pkg> --version`으로 1차 실측 후 README 박기** 원칙 명시.

## 목적
NVIDIA NIM API 4 개 키를 활용하여 OpenCode 와 oh-my-openagent 플러그인을 최적화한 에이전트 스쿼드 구성.

## 설정 파일
- **위치**: `~/.config/opencode/oh-my-openagent.json`
- **주의**: 파일명은 `oh-my-openagent.json` (agents.json 아님)

## NVIDIA API 키 관리
- **키 파일**: `~/.hermes/secrets/nvidia_keys.env`
- **키 구성**:
  - `NVIDIA_API_KEY_HERMES`: 에르메스 전용
  - `NVIDIA_API_KEY_OPENCODE_1`, `NVIDIA_API_KEY_OPENCODE_2`: OpenCode 전용 (키 1, 2)
  - `NVIDIA_API_KEY_CLAUDE`: Claude Code 전용
- **키 교체 스크립트**: `~/.hermes/scripts/nvidia_key_rotator_opencode.py`
  - OpenCode 실행 시 키 1, 2 를 랜덤/라운드로빈으로 선택하여 `NVIDIA_API_KEY` 환경 변수 설정
  - 실행 권한 부여: `chmod +x ~/.hermes/scripts/nvidia_key_rotator_opencode.py`

## 에이전트 매핑 (최종 확정, 2026-07-06 갱신)
| 에이전트 | 모델 | 용도 |
|---|---|---|
| `sisyphus` (메인) | `Qwen/Qwen3-Coder-480B-A35B-Instruct` | 코딩, 리팩토링, 디버깅 |
| `oracle` | `Qwen/Qwen3-Coder-480B-A35B-Instruct` | 아키텍처 설계 |
| `librarian` | `Qwen/Qwen3-Coder-480B-A35B-Instruct` | 코드 분석/검색 |
| `explore` | `Qwen/Qwen3-Coder-480B-A35B-Instruct` | 아이디어 탐색 |
| `multimodal-looker` | `meta/llama-3.2-90b-vision-instruct` | 비전/이미지 분석 |
| `prometheus` | `meta/llama-3.1-405b-instruct` | 모니터링/이상 탐지 |
| `metis` | `meta/llama-3.1-405b-instruct` | 전략/계획 |
| `momus` | **`nvidia/openai/gpt-oss-120b`** | 창의적 사고 (2026-07-06 확정) |
| `atlas` | `Qwen/Qwen3-Coder-480B-A35B-Instruct` | 문서화 |
| `sisyphus-junior` | `Qwen/Qwen3-Coder-480B-A35B-Instruct` | 경량 작업 |

> **⚠️ NIM 모델 ID 함정 (2026-07-06 라이브 검증)**: `momus` 행이 `nvidia/openai/gpt-oss-120b`인 이유 — oh-my-openagent.json의 모델 키 형식은 `<provider>/<model-id>`. OpenCode의 NVIDIA provider는 NIM 카탈로그의 raw ID (예: `openai/gpt-oss-120b`)를 그대로 받아 `<provider>/<catalog-id>` 형식으로 normalize → 결과 `nvidia/openai/gpt-oss-120b`. raw ID 그대로 적으면 OpenAI 직접 라우팅에 잡혀버림 (NIM GPU 안 탐).
>
> **재검증 도구**:
> - 빠른: `bash scripts/verify-nim-model.sh gpt-oss-120b` (이 스킬 번들)
> - 상세: `references/nim-model-id-verification.md` (3단계 cookbook + 결정 매트릭스 + 4종 흔한 실수)

## 동시성 설정
```json
"background_task": {
  "providerConcurrency": {
    "qwen": 6,
    "meta": 4,
    "github-copilot": 3,
    "nvidia": 3
  }
}
```

## 실행 방법
1. **환경 변수 로드**: `source ~/.hermes/secrets/nvidia_keys.env`
2. **OpenCode 실행**: `opencode` 또는 `python3 ~/.hermes/scripts/nvidia_key_rotator_opencode.py`
3. **에이전트 전환**: TUI 에서 `/agent sisyphus`

## oh-my-opencode install (2026-07-09 검증, 2번째)

**사전 체크**:
```bash
# OpenCode 설치 확인
which opencode && opencode --version  # 1.17.10+

# Bun 설치 확인 (없으면 brew install bun)
which bun && bun --version

# oh-my-opencode 정상 설치 확인
bunx oh-my-opencode --version   # v4.13.0 또는 v4.16.0+ 출력되어야 함
```

**비대화형 install** (주인님가 sudo 캐시 + 프로바이더 결정된 상태):
```bash
# minimax-coding-plan 구독 시
bunx oh-my-opencode install \
  --no-tui \
  --platform=opencode \
  --minimax-coding-plan=yes \
  --skip-auth
```

**플래그 의미**:
- `--no-tui`: TUI 없이 비대화형 실행 (백그라운드 가능)
- `--platform=opencode`: OpenCode Ultimate Edition 설치 (default)
- `--minimax-coding-plan=yes`: MiniMax 모델 구독 활성화 (주인님 환경)
- `--skip-auth`: 인증 가이드 메시지만 스킵. **실제 provider 인증은 OpenCode TUI 재시작 후 별도** (Phase 4 TTY 작업)

**install 후 위치**:
- 플러그인 등록: `~/.config/opencode/opencode.json` (또는 `oh-my-opencode.json`)
- agent/model config: `~/.config/opencode/oh-my-opencode.json` (또는 `.jsonc`)
- agent 스킬: `~/.config/opencode/agent/` 또는 oh-my-opencode 캐시 디렉토리

**config JSON 덮어쓰기 (사용자 설정 파일 받은 경우)**:

주인님가 `oh-my-opencode.json` 같은 파일을 보내면 `~/.config/opencode/oh-my-opencode.json`에 직접 덮어쓰기:
```bash
# 백업 후 덮어쓰기
cp ~/.config/opencode/oh-my-opencode.json \
   ~/.config/opencode/oh-my-opencode.json.bak.$(date +%Y%m%d_%H%M%S)
cp <받은_파일> ~/.config/opencode/oh-my-opencode.json
```

**검증**:
```bash
# OpenCode 재시작 후
opencode
# TUI에서 /agent sisyphus → 모델이 정상 로드되는지 확인
# 또는 bunx 명령으로 검증
bunx oh-my-opencode@latest --help 2>&1 | head -10
```

**인증은 TUI에서**: `opencode` 실행 → `/connect` 또는 settings → 각 provider API key 입력. GitHub OAuth 사용 시 `gh auth login` 선행.

## 문제 해결
- **모델명 정확성**: 설정 파일의 모델명은 오픈코드 TUI 에서 표시되는 이름과 대소문자/기호 정확히 맞춤 (예: `Qwen/Qwen3-Coder-480B-A35B-Instruct`)
- **파일명**: `oh-my-opencode.json` 사용 (agents.json 아님, `oh-my-openagent.json`도 ❌ deprecated)
- **키 교체**: OpenCode 실행 시 키 교체 스크립트 사용 권장

## 문제 해결
- **에러 "model is not valid"**: 모델명 대소문자/기호 재확인, TUI 에서 직접 선택 후 자동 업데이트 시도
- **설정 파일 로드 안 됨**: 파일명 `oh-my-openagent.json` 확인, `opencode` 재시작
- **`momus` 401/404**: NVIDIA provider가 NIM 키로 호출하는지 확인 (`NVIDIA_API_KEY` env). 모델 ID가 `openai/gpt-oss-120b` (NIM raw ID)로 적혀있으면 라우팅이 OpenAI로 새빠짐 — `references/nim-model-id-verification.md` 참조.

### 🆕 Codex CLI NIM provider `wire_api` enum 함정 (2026-07-10 실측)

`codex` CLI에서 NIM provider를 등록할 때 `wire_api`에 `"openai"`를 쓰면 Codex 0.143+에서 즉시 거부됨:
```
Error loading config.toml: unknown variant `openai`, expected `responses`
in `model_providers.<name>.wire_api`
```

**허용 enum**: `responses` (OpenAI Responses API 호환) / `chat` (Chat Completions 호환). `"openai"`는 옛 alias라 제거됨. NIM은 OpenAI Responses API 호환이므로 `"responses"` 권장.

**`CODEX_HOME` 함정 (2026-07-10 실측)**: 환경변수 `CODEX_HOME`이 다른 경로(예: orca runtime-home)로 export되어 있으면 `~/.codex/config.toml`은 무시되고 `$CODEX_HOME/config.toml`이 읽힘. 둘 다 동기화해야 함:

```bash
# 진짜로 읽히는 config 위치 확인
echo "CODEX_HOME=$CODEX_HOME"
ls -la "$CODEX_HOME/config.toml" ~/.codex/config.toml 2>/dev/null

# 둘 다 patch (sisyphus oh-my-opencode runtime 동기화 가정)
sed -i.bak 's/wire_api = "openai"/wire_api = "responses"/' \
  ~/.codex/config.toml \
  "$CODEX_HOME/config.toml"

codex exec --skip-git-repo-check \
  -c 'model="nvidia/llama-3.1-nemotron-70b-instruct"' \
  -c 'model_provider="nim"' \
  "ping" </dev/null
```

정상 흐름: `model: <...> / provider: nim` 까지 출력되고 `Missing environment variable: NVIDIA_API_KEY`로 넘어감 (키 없으면 당연히 호출 불가). 이 시점 = config 파싱 OK.

---

## 🆕 NIM API 키 발급 — 직행 URL (2026-07-07 사용자 코렉션)

**함정**: NVIDIA NIM 키 발급 가이드를 쓸 때 무의식적으로 **카탈로그 탐색 패턴**(Build 사이트 → 모델 검색 → 모델 페이지 → "Get API Key")을 끼워넣기 쉬워요. 실제 NVIDIA 흐름은 그게 아님 — **직행 URL로 즉시 발급 가능**.

**올바른 진입 경로 (3분 발급)**:

| Step | 동작 | URL |
|---|---|---|
| 1 | **키 발급 페이지 직행** | https://build.nvidia.com/settings/api-keys |
| 2 | 회원가입 + **핸드폰 인증** (Generate Key 활성화 조건) | — |
| 3 | "Generate Key" → 이름 입력 → 키 복사 | — |

**대안 URL**: https://org.ngc.nvidia.com/setup/api-key

**불필요한 단계 (절대 README/가이드에 넣지 말 것)**:
- ❌ `build.nvidia.com/models` 카탈로그 진입
- ❌ 모델 검색 ("gpt-oss-120b" 검색)
- ❌ 모델 페이지 우측 패널의 "Get API Key" 버튼 (이 경로는 deprecated/UX 우회)

**인증 함정 (실측)**:
- **핸드폰 인증 미완료** → "Generate Key" 버튼이 **비활성화**됨 (회색 처리). 이메일 인증은 별개 — 핸드폰 인증이 핵심.
- 401 Unauthorized → 키 오타 OR 핸드폰 인증 해제 (90일 만료 후 재인증 필요)
- 핸드폰 인증 코드 → SMS, 5분 내 입력

**README/가이드 작성 시 체크리스트**:
- [ ] 진입 URL이 `settings/api-keys`로 시작하는가? (`models` 아님)
- [ ] Step 수가 **5 이하**인가? (모델 페이지 단계 제거)
- [ ] "핸드폰 인증"이 **명시적으로 강조**되어 있는가? (이메일 인증은 부수적)
- [ ] "이메일 인증 메일 재발송" 같은 **잘못된 함정**을 넣지 않았는가?

**교훈 (2026-07-07, BYOK 게임 README 세션)**: 제가 6단계 가이드("Build 사이트 → 모델 카탈로그 → 모델 페이지 → Get API Key → 키 발급 → 검증")를 처음에 작성했는데, 사용자가 "모델 페이지 가지 않아도 회원가입 후 핸드폰 인증 후 키발급이 바로 가능" 이라고 직접 교정함. **카탈로그형 UX는 제 머릿속 패턴이지 NVIDIA의 실제 흐름이 아님**. 모델 페이지 자체가 "Explore" 용도일 뿐, 키 발급의 정식 경로는 `settings/api-keys`.

---

## 🆕 oh-my-openagent install 필수 플래그 (2026-06-26 검증)

**첫 시도에서 막힌 함정**: `--no-tui` 모드에서 `--claude` / `--gemini` / `--copilot` 셋 다 명시 안 하면 즉시 fail:

```
oMoMoMoMo... Install 
[X] Validation failed:
  * --claude is required (values: no, yes, max20)
  * --gemini is required (values: no, yes)
  * --copilot is required (values: no, yes)
```

**해결 — 항상 3개 명시** (사용 안 할 거라도 `=no`):

```bash
bunx oh-my-openagent install \
  --no-tui \
  --platform=opencode \
  --minimax-coding-plan=yes \
  --claude=no \
  --gemini=no \
  --copilot=yes \
  --skip-auth
```

**판별 가이드 (주인님 환경 기준)**:
- `oh-my-openagent.json`에 `github-copilot/gpt-5-mini` 같은 모델 있으면 → `--copilot=yes`
- `anthropic/claude-*` 모델 있으면 → `--claude=yes` (또는 `max20`)
- `google/gemini-*` 모델 있으면 → `--gemini=yes`
- 전부 안 쓰면 → 셋 다 `=no` (이 경우도 명시 필수!)

---

## 🆕 Claude Code → MiniMax (Anthropic-호환) 라우팅 (2026-06-26)

**상황**: brew로 `claude-code` (Anthropic 공식 CLI) 설치 후, 주인님의 주력 모델이 **MiniMax-M3 (minimax-coding-plan 구독)**. Claude Code는 기본적으로 `api.anthropic.com`을 호출하므로 MiniMax로 라우팅 필요.

**해결 — `.zshrc`에 3개 환경변수 등록** (Hermes secrets 구조 활용):

```bash
# >>> claude code (MiniMax) env >>>
# Claude Code를 MiniMax API로 라우팅 (Anthropic 호환 엔드포인트)
export ANTHROPIC_BASE_URL="https://api.minimax.io/anthropic"
export ANTHROPIC_AUTH_TOKEN="$MINIMAX_API_KEY"   # Hermes secrets/minimax.env 에서 자동 로드
export ANTHROPIC_MODEL="MiniMax-M3"               # 선택: 기본 모델
# Hermes API 키 자동 로드
[ -f ~/.hermes/secrets/minimax.env ] && source ~/.hermes/secrets/minimax.env
# <<< claude code (MiniMax) env <<<
```

**작동 원리**:
- `ANTHROPIC_BASE_URL` → Claude Code의 `https://api.anthropic.com` 호출을 `https://api.minimax.io/anthropic`으로 리다이렉트
- `ANTHROPIC_AUTH_TOKEN` → API 키 자리 (Anthropic 키 대신 MiniMax 키)
- `ANTHROPIC_MODEL` → `claude` 명령 시작 시 기본 모델 지정
- Hermes `secrets/minimax.env` → 키 관리 SSOT (주인님가 다른 PC에서도 같은 구조 사용)

**Hermes config 검증** (`~/.hermes/config.yaml`):
```yaml
model:
  default: MiniMax-M3
  base_url: https://api.minimax.io/anthropic
providers:
  minimax:
    api_key_env: MINIMAX_API_KEY
```

**검증 방법**:
```bash
source ~/.zshrc
claude --version   # 2.1.181 정상
claude             # 새 세션 — 모델이 MiniMax-M3으로 시작하는지 확인
```

**장점**:
- Anthropic API 키 구매 불필요 (주인님 MiniMax 구독 활용)
- oh-my-openagent의 `minimax-coding-plan/MiniMax-M3` 모델 매핑과 동일 모델 사용 → 두 도구 간 일관성
- `.zshrc` 영구 등록이라 새 shell마다 자동 적용

**함정 / 주의**:
- MiniMax는 Anthropic API **호환**이지만 완전 1:1은 아님. 일부 beta 기능 (`extended thinking` 등) 다르게 동작할 수 있음.
- MiniMax 쿼타 소진 시 Claude Code는 **자체 폴백 없음** — `--fallback-model` 옵션으로 NIM 등 추가 가능 (별도 설정 필요)
- macOS에서 `source ~/.hermes/secrets/minimax.env` 패턴이 `.zshrc`에 박혀있어 키 회전 시 한 번에 반영됨

---

## Hermes secrets 구조 (AI 코딩 CLI 라우팅의 SSOT)

주인님 환경에서 **모든 AI CLI 인증 토큰**이 한 곳에서 관리되는 패턴:

| 파일 | 용도 | ENV |
|---|---|---|
| `~/.hermes/secrets/minimax.env` | MiniMax (Claude Code, OpenCode, oh-my-openagent 공통) | `MINIMAX_API_KEY` |
| `~/.hermes/secrets/nvidia_keys.env` | NVIDIA NIM (4개 키 풀) | `NVIDIA_API_KEY*` |
| `~/.hermes/secrets/nvidia_qwen.env` | Qwen 전용 NIM | `NVIDIA_API_KEY` |
| `~/.hermes/secrets/nvidia_kimi.env` | Kimi 전용 NIM | `NVIDIA_API_KEY` |
| `~/.hermes/secrets/telegram_bot_token.txt` | Telegram 봇 | `TELEGRAM_BOT_TOKEN` |
| `~/.hermes/secrets/notion_token.txt` | Notion API | `NOTION_TOKEN` |

**패턴**: `[ -f ~/.hermes/secrets/<name>.env ] && source ~/.hermes/secrets/<name>.env` 로 `.zshrc`에 등록 → 새 shell마다 자동 로드. AI CLI 라우팅 설정 시 **반드시 이 구조 활용** (그렇지 않으면 키가 shell마다 분산됨).

---

## 4순위 패키지 추가 — `claude-code` (2026-06-26)

```bash
brew install claude-code   # Cask 2.1.181, /opt/homebrew/bin/claude
```

**3가지 운영 모드** (주인님 환경 권장: B):

| 모드 | API 키 | 라우팅 | 비고 |
|---|---|---|---|
| A. Native Anthropic | Anthropic 직접 구매 | `api.anthropic.com` | 비쌈 ($20/월+) |
| **B. MiniMax 라우팅** | **MiniMax 구독** | **`api.minimax.io/anthropic`** | **주인님 권장** |
| C. OpenRouter 라우팅 | OpenRouter 키 | `openrouter.ai/api/v1` | 모델 다양 |

B 모드 설정 완료 후 (위 라우팅 섹션), `claude` 명령이 즉시 MiniMax-M3으로 시작.

---

## 🆕 Next.js 16 보일러플레이트 머지 (2026-07-10, toss-trader 실측)

**상황**: docs만 있는 기존 repo (예: `sigco3111/toss-trader`처럼 AGENTS.md + README.md + LICENSE + docs/ 4~6개 파일, **코드 0줄**)에 Next.js 보일러플레이트를 **기존 파일 보존하며** 추가. 단순 `cd && create-next-app .`은 안 됨 — 빈 디렉토리여야 하므로.

**5단계 머지 워크플로** (`/tmp/scaffold` → `toss-trader`):

```bash
# 1) /tmp/scaffold에 보일러플레이트 생성
rm -rf /tmp/<project>-scaffold
npx --yes create-next-app@latest /tmp/<project>-scaffold \
  --typescript --tailwind --app --eslint \
  --no-src-dir \
  --use-npm \
  --disable-git \
  --import-alias "@/*" \
  --yes
# ⚠️ --yes가 새 AGENTS.md 자동 생성을 묵살하지 못함 → 2단계에서 보존 파일 보호

# 2) 기존 repo로 보존 파일 보호하며 복사
cd /tmp/<project>-scaffold
cp -R app public package.json tsconfig.json next.config.ts \
  next-env.d.ts eslint.config.mjs postcss.config.mjs package-lock.json \
  /Users/mac/work/<project>/
# ⚠️ 절대 cp -R . 전체 ❌. AGENTS.md(327B 기본)/CLAUDE.md(11B)/README.md(1.5KB)
#    scaffold 기본이 기존 v0.3 10KB+ 문서 덮어씀

# 3) .gitignore: Next 표준 + 프로젝트 시크릿 격리 규칙 병합
#    Next 표준: /node_modules, /.next, /out, .env*, .vercel, next-env.d.ts 등
#    프로젝트 secrets: tossinvest.env, *.key, *.pem, *.pem 등

# 4) 빈 디렉토리 placeholder (.gitkeep)
#    기존 AGENTS.md/README.md에 명시된 미래 디렉토리는 미리 만들어둠
mkdir -p schemas lib components
echo "# 빈 디렉토리 유지용. 2~5단계에서 채움." > schemas/.gitkeep
echo "# 빈 디렉토리 유지용." > lib/.gitkeep
echo "# 빈 디렉토리 유지용." > components/.gitkeep

# 5) 검증 4종
npm run build          # Turbopack 0 에러
npm run lint           # 0 에러
bash ~/.hermes/skills/ad-hoc-verifier/scripts/check-kr-en-mixed-headings.sh \
  AGENTS.md README.md docs/*.md   # 헤딩 0/0 깨짐
# 프로젝트별 자기 검증 (예: LLM 호출 0줄 grep)
grep -rEn "openai|nim|anthropic|apiKey|BYOK" app/ components/ lib/ || echo "0건 OK"
```

**create-next-app @latest 함정 (2026-07-10 실측)**:

| 함정 | 영향 | 회피 |
|---|---|---|
| `--agents-md`가 **default** | 327B의 Next.js 16 가이드 AGENTS.md가 자동 생성 → 기존 v0.3 10KB+ AGENTS.md와 충돌 | `--no-agents-md` 옵션은 **없음**. `/tmp/scaffold` 패턴으로 회피 |
| `--disable-git` 누락 | 기존 repo의 `.git/`을 덮어쓰려 함 | **항상 명시** |
| `--src-dir` 기본값 = `src/app/` | AGENTS.md에 `app/` 루트 적었으면 안 맞음 | `--no-src-dir` 명시 |
| `--turbopack`/`--rspack` 안 적으면 webpack 빌드 | Next 16 = turbopack 기본이지만 `npm run build`는 webpack일 수 있음 | 기본값 유지 (안정성) |

**Next 16 = breaking change (2026-07-10 실측, scaffold 기본 AGENTS.md가 경고)**:

```
<!-- BEGIN:nextjs-agent-rules -->
# This is NOT the Next.js you know
This version has breaking changes — APIs, conventions, and file structure may
all differ from your training data. Read the relevant guide in
`node_modules/next/dist/docs/` before writing any code. Heed deprecation notices.
```

→ AGENTS.md 첫 줄에 `> ⚠️ Next.js 16 (날짜 보일러플레이트 검증)` 노트 박아둘 것. + `node_modules/next/dist/docs/` 우선 참조.

**Tailwind v4 vs v3 함정**:
- v4 = `postcss.config.mjs` (플러그인 `@tailwindcss/postcss`) ← scaffold가 생성
- v3 = `tailwind.config.js` ← v4에 **없음**. 옛날 가이드 따라 적으면 빌드 깨짐

**`gh api --jq` escape 함정 (2026-07-10 실측)**: bash에서 `gh api ... --jq '.tree[] | "\\(.path)\t\(.size)B"'` → `\(...)` 리터럴 출력 (백슬래시 escape). python 파이프 권장:

```bash
gh api repos/<owner>/<repo>/git/trees/main?recursive=1 \
  --jq '.tree[] | select(.type=="blob") | "\(.path) \(.size)B"' \
| python3 -c "
import sys
for l in sys.stdin.read().splitlines():
    if l.strip():
        path, size = l.rsplit(' ', 1)
        print(f'  {path:50s} {size}')
"
```

**details**: `references/nextjs-scaffold-merge.md` (전체 명령 + 검증 어서션 셋 + 디렉토리별 cp 매트릭스).

---

## 📎 부속 파일 (재검증 워크플로)

- **`references/nim-model-id-verification.md`** — NIM 모델 ID 검증 3단계 cookbook (카탈로그 raw ID → oh-my-openagent 별칭 cross-check → live chat 200 OK). 흔한 오답 4종 + 결정 매트릭스.
- **`references/nextjs-scaffold-merge.md`** — 기존 repo (docs만) + Next.js 16 보일러플레이트 머지 워크플로. `/tmp/scaffold` 패턴, cp -R 파일 매트릭스, 4종 검증 어서션, create-next-app 옵션 함정 표.
- **`scripts/verify-nim-model.sh`** — 위 cookbook 자동화. 인자: `<model-search-keyword> [provider-name]`. 사용 예: `bash scripts/verify-nim-model.sh gpt-oss-120b`.
