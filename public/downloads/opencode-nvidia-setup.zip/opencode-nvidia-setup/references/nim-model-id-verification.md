# NVIDIA NIM 모델 ID 검증 Cookbook (oh-my-openagent용)

주인님가 `oh-my-openagent.json`에 새 NIM 모델을 추가하라고 할 때, **`model` 필드에 적어야 할 정확한 ID**를 빠르게 찾는 검증 절차. **"추측 → 라이브 호출 → 카탈로그 cross-check"** 3단계.

> **원칙**: NIM 카탈로그 ID와 oh-my-openagent 카탈로그 ID는 **다르다**. OpenCode provider 시스템이 두 ID를 어떻게 합치는지 검증 없이 추측하면 라우팅이 OpenAI/OpenRouter로 새버림.

---

## 3단계 검증 절차

### Step 1. NIM 카탈로그 raw ID 조회 (카탈로그 raw + chat 검증)

```bash
# 키 풀 중 하나 사용 (5개 풀: NVIDIA_API_KEY_HERMES, _1, _2, OPENCODE_1, OPENCODE_2)
source ~/.hermes/secrets/nvidia_keys.env
export NVIDIA_API_KEY="$NVIDIA_API_KEY_1"

# 1a. 카탈로그에서 모델 ID 추출
curl -sS https://integrate.api.nvidia.com/v1/models \
  -H "Authorization: Bearer $NVIDIA_API_KEY" \
  | python3 -c "
import json, sys
d = json.load(sys.stdin)
for m in d.get('data', d):
    if 'gpt-oss' in m.get('id','').lower():  # 검색 키워드
        print(m.get('id'), 'owned_by:', m.get('owned_by'))
"
```

**관찰**: gpt-oss-120b의 raw ID는 **`openai/gpt-oss-120b`** (owned_by: openai). org prefix 포함.

### Step 2. oh-my-openagent 내부 카탈로그 cross-check

oh-my-openagent v4.15+ 내 모델 레지스트리는 `dist/index.js` 평면 객체. 같은 모델이 **여러 별칭으로 동시 등록**되어 있어 (각 provider scope마다):

```bash
LATEST=$(ls -d ~/.bun/install/cache/oh-my-openagent@4.* 2>/dev/null | sort -V | tail -1)
grep -oE '"((?:[^"]+/)?gpt-oss-120b)"' "$LATEST/dist/index.js" | sort -u
```

**실제 출력 (2026-07-06 검증)**:
```
"gpt-oss-120b"
"openai/gpt-oss-120b"
"hf:openai/gpt-oss-120b"
"TEE/gpt-oss-120b"
"tee/gpt-oss-120b"
```

**각 별칭의 의미**:
| ID | 용도 |
|---|---|
| `gpt-oss-120b` (plain) | OpenCode가 NIM 카탈로그에서 가져올 때 정식 키 (org prefix strip됨) |
| `openai/gpt-oss-120b` | OpenAI 직접 API 호출용 |
| `hf:openai/gpt-oss-120b` | HuggingFace 라우팅 |
| `TEE/` / `tee/` | TEE provider (별도 서비스) |
| **`nvidia/gpt-oss-120b`** | **NIM 라우팅용 키** (OpenCode가 NIM provider normalize) |

### Step 3. 실제 chat endpoint 호출 (live 200 OK 검증)

```bash
for M in "openai/gpt-oss-120b" "gpt-oss-120b" "nvidia/gpt-oss-120b"; do
  RESP=$(curl -sS -X POST https://integrate.api.nvidia.com/v1/chat/completions \
    -H "Authorization: Bearer $NVIDIA_API_KEY" \
    -H "Content-Type: application/json" \
    -d "{\"model\":\"$M\",\"messages\":[{\"role\":\"user\",\"content\":\"hi\"}],\"max_tokens\":30,\"stream\":false}")
  OK=$(echo "$RESP" | python3 -c "import json,sys; d=json.load(sys.stdin); print('OK' if d.get('choices') else 'ERR')" 2>&1)
  echo "  $M → $OK"
done
```

**결과**:
- `openai/gpt-oss-120b` → OK (200)
- `gpt-oss-120b` → 404 page not found
- `nvidia/gpt-oss-120b` → 404 page not found

---

## 결정 매트릭스: 어떤 ID를 쓰느냐

| oh-my-openagent.json 위치 | 적어야 할 ID | 이유 |
|---|---|---|
| 일반 모델 (NIM 호스팅, OpenCode가 NIM provider 노출) | **`nvidia/gpt-oss-120b`** | OpenCode가 `<provider>/<catalog-id>` 형태로 normalize |
| OpenAI 직접 호출 원할 때 | `openai/gpt-oss-120b` | OpenAI 정식 API 키 + family: gpt-oss 매칭 |
| HuggingFace 라우팅 | `hf:openai/gpt-oss-120b` | HF Inference API |
| TEE provider | `TEE/gpt-oss-120b` (또는 `tee/...`) | 별도 빌드 |

---

## ⚠️ 흔한 실수 4종 (검증 완료)

### 1. NIM 카탈로그 ID와 OpenCode 모델 키를 혼동
- ❌ NIM raw ID는 `openai/gpt-oss-120b` — OpenCode TUI의 `/models`에서 보면 `nvidia/openai/gpt-oss-120b`로 노출
- ❌ oh-my-openagent.json에 raw ID 그대로 적으면 OpenAI 직접 라우팅에 잡힘 — NIM 안 탐
- ✅ 정답: **`nvidia/openai/gpt-oss-120b`** (oh-my-openagent v4.15.1 기준)

### 2. OpenCode 모델 키 형식 가정
- oh-my-openagent.json의 기존 매핑은 모두 `<provider>/<model>` 형식 (`minimax-coding-plan/MiniMax-M3`, `github-copilot/gpt-5-mini`)
- NIM은 provider = `nvidia`, 그 뒤 catalog ID 그대로 = `nvidia/openai/gpt-oss-120b`

### 3. API 200 OK ≠ 정답
- `openai/gpt-oss-120b`로 NIM 키 보내면 200 OK이지만, oh-my-openagent 라우팅 시 OpenAI 직접 호출로 빠질 수 있음
- API 호출 검증만으로는 "이 키가 oh-my-openagent와 호환되는가"를 알 수 없음 → **카탈로그 + 실 OpenCode TUI 호출 필요**

### 4. 대소문자 / 슬래시 흔들림
- `openai/GPT-OSS-120B`, `gpt_oss_120b`, `openai/gpt-oss/120b` → 전부 ERR
- NIM 카탈로그의 ID는 **소문자 + 하이픈 + 슬래시 정확히 1개**

---

## 실전: 새 NIM 모델 추가 시 체크리스트

```
□ Step 1. NVIDIA 카탈로그에서 raw ID 조회
□ Step 2. oh-my-openagent dist/index.js에서 같은 모델 5별칭 검색
□ Step 3. 라이브 chat 호출로 200 OK 확인 (소문자 정확)
□ Step 4. OpenCode 공식 docs에서 provider 이름 확인 (이번 케이스: `nvidia`)
□ Step 5. provider/catalog-id 형식으로 oh-my-openagent.json에 매핑
□ Step 6. OpenCode TUI 재시작 후 /agent <role> 로 검증
```

## 빠른 검증 스크립트

`scripts/verify-nim-model.sh` 참조 (자동화 가능):
- 인자: 모델 이름 (예: `gpt-oss-120b`)
- 출력: 카탈로그 ID, oh-my-openagent 별칭 5개, oh-my-openagent.json에 적어야 할 최종 키
