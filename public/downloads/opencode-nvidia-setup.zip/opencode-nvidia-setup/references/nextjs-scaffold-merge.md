# Next.js 16 보일러플레이트 머지 워크플로 (2026-07-10 실측)

## 트리거 조건

다음 조건을 **모두** 만족하는 작업에 이 워크플로 사용:

- 기존 GitHub repo가 있고, **로컬 clone 경로**가 있음 (예: `/Users/mac/work/<project>`)
- repo에 **docs만 있고 코드는 0줄** (또는 최소 코드). `docs/`, `AGENTS.md`, `README.md`, `LICENSE`만 존재
- **기존 AGENTS.md / README.md가 v0.3+ 정식 문서** (수 KB) — 절대로 잃으면 안 됨
- 새로 **Next.js 보일러플레이트**를 코드 추가하되, 기존 docs를 보존

## 절대 안 되는 패턴

### ❌ `cd && create-next-app .`

```bash
cd /Users/mac/work/toss-trader
npx create-next-app@latest .   # ❌ 디렉토리 비어있지 않으면 fail
```

### ❌ `cp -R scaffold/* .` (은밀한 덮어쓰기)

```bash
cp -R /tmp/scaffold/* /Users/mac/work/toss-trader/   # ❌ AGENTS.md, README.md, LICENSE, docs/ 전부 덮어씀
```

## ✅ 안전 패턴: `/tmp/scaffold` + 파일 선택 복사

5단계:

### 1단계: `/tmp/scaffold`에 보일러플레이트 생성

```bash
rm -rf /tmp/<project>-scaffold
npx --yes create-next-app@latest /tmp/<project>-scaffold \
  --typescript --tailwind --app --eslint \
  --no-src-dir \
  --use-npm \
  --disable-git \
  --import-alias "@/*" \
  --yes
```

**함정 표**:

| 함정 | 영향 | 회피 |
|---|---|---|
| `--agents-md`가 **default** | 327B의 Next.js 16 가이드 AGENTS.md가 자동 생성 | `--no-agents-md` 옵션 없음 → `/tmp/scaffold` 패턴이 본질적 회피 |
| `--disable-git` 누락 | scaffold가 `git init` 시도 → 기존 repo의 `.git/` 덮어쓰려 함 | **항상 명시** |
| `--src-dir` (default) | `src/app/` 구조 | AGENTS.md가 `app/` 루트면 `--no-src-dir` |
| `--turbopack` (default in Next 16) | dev는 turbopack, build는 webpack | 옵션 없음, 기본값 유지 |
| `--use-npm` 명시 안 함 | pnpm/yarn/bun 자동감지 → 환경 따라 다름 | **항상 명시** (`--use-npm`) |

### 2단계: 기존 repo로 보존 파일 보호하며 복사

```bash
cd /tmp/<project>-scaffold

# ✅ Next.js 파일만 선택 복사 (덮어쓰기 안전: app/, public/, package.json 등은
#    기존 <project>에 없음)
cp -R app public package.json tsconfig.json next.config.ts \
   next-env.d.ts eslint.config.mjs postcss.config.mjs package-lock.json \
   /Users/mac/work/<project>/
```

**파일 매트릭스** (예: toss-trader 실측):

| 파일 | 크기 | 출처 | 비고 |
|---|---|---|---|
| `app/layout.tsx` | ~720B | scaffold | 보존 (Tailwind + Geist 폰트) |
| `app/page.tsx` | ~2.9KB | scaffold | 보존 (1단계). 2단계에서 toss-trader 대시보드로 교체 |
| `app/globals.css` | ~490B | scaffold | 보존 (Tailwind v4 directives) |
| `app/favicon.ico` | ~26KB | scaffold | 보존 (1단계) |
| `public/*.svg` (5개) | ~3KB total | scaffold | 보존 (Next.js logo 등. 2단계에서 toss-trader 로고 교체) |
| `package.json` | ~540B | scaffold | **정정 필요**: `name: "<project>-scaffold"` → `name: "<project>"` |
| `tsconfig.json` | ~670B | scaffold | 보존 (`paths: { "@/*": ["./*"] }`) |
| `next.config.ts` | ~130B | scaffold | 보존 (빈 config) |
| `next-env.d.ts` | ~250B | scaffold | **`.gitignore` 처리** (Next 표준) |
| `eslint.config.mjs` | ~470B | scaffold | 보존 (ESLint 9 flat config) |
| `postcss.config.mjs` | ~95B | scaffold | 보존 (Tailwind v4 plugin) |
| `package-lock.json` | ~230KB | scaffold | 보존 (commit 추적) |
| `AGENTS.md` | 327B | scaffold | **❌ 절대 복사 금지** (기존 v0.3 10KB+ 보존) |
| `CLAUDE.md` | 11B | scaffold | **❌ 절대 복사 금지** (다른 에이전트용. `.gitignore` 처리) |
| `README.md` | ~1.5KB | scaffold | **❌ 절대 복사 금지** (기존 v0.3 10KB+ 보존) |

### 3단계: `.gitignore` 병합

Next 표준 + 프로젝트 시크릿 격리:

```gitignore
# See https://help.github.com/articles/ignoring-files/ for more about ignoring files.

# dependencies
/node_modules
/.pnp
.pnp.*
.yarn/*
!.yarn/patches
!.yarn/plugins
!.yarn/releases
!.yarn/versions

# testing
/coverage

# next.js
/.next/
/out/

# production
/build

# misc
.DS_Store
*.pem

# debug
npm-debug.log*
yarn-debug.log*
yarn-error.log*
.pnpm-debug.log*

# env files (can opt-in for committing if needed)
.env*

# vercel
.vercel

# typescript
*.tsbuildinfo
next-env.d.ts

# === <project> 추가 (v0.3 시크릿 격리) ===
# Secrets — 절대 추적 금지
*.key
tossinvest.env

# Runtime / state
.history/
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
.venv/
venv/
env/
.pytest_cache/
.mypy_cache/
.ruff_cache/
.coverage
htmlcov/

# Project runtime
history/*.json
!history/.gitkeep
.cache/
logs/
*.log

# Local data
*.db
*.sqlite3

# IDE / OS
.idea/
.vscode/
Thumbs.db
*.swp
*.swo

# Build (Python)
build/
dist/
*.egg-info/
*.egg
.tox/
.eggs/

# CLAUDE.md는 추적 안 함
CLAUDE.md
```

### 4단계: 빈 디렉토리 placeholder

AGENTS.md/README.md에 명시된 미래 디렉토리는 미리 만들어둠 (디렉토리가 비어있으면 git이 추적 안 함):

```bash
mkdir -p /Users/mac/work/<project>/{schemas,lib,components}
cat > /Users/mac/work/<project>/schemas/.gitkeep <<'EOF'
# 빈 디렉토리 유지용. 2단계에서 recommendation.schema.json 추가 예정.
EOF
cat > /Users/mac/work/<project>/lib/.gitkeep <<'EOF'
# 빈 디렉토리 유지용. 2단계에서 toss.ts, 3단계에서 safety.ts 추가 예정.
EOF
cat > /Users/mac/work/<project>/components/.gitkeep <<'EOF'
# 빈 디렉토리 유지용. 5단계에서 Portfolio.tsx, OrderButton.tsx 추가 예정.
EOF
```

### 5단계: 검증 4종 (4중 어서션 셋)

```bash
cd /Users/mac/work/<project>

# (a) 빌드 0 에러
echo "=== npm run build ===" && npm run build 2>&1 | tail -10
# 기대: "✓ Compiled successfully in 1XXXms" + 4 정적 페이지

# (b) 린트 0 에러
echo "=== npm run lint ===" && npm run lint 2>&1 | tail -5
# 기대: 0 에러

# (c) 헤딩 정규화 (bash + python 2중)
echo "=== 2중 헤딩 검증 ===" && \
  bash ~/.hermes/skills/ad-hoc-verifier/scripts/check-kr-en-mixed-headings.sh \
    AGENTS.md README.md docs/*.md
python3 - <<'PY'
import re, sys
total = 0
files = ['AGENTS.md', 'README.md'] + \
        [f for f in __import__('os').listdir('docs') if f.endswith('.md')]
for f in files:
    t = open(f).read()
    bad = re.findall(r'^##+ [^()\n]*[가-힣][^()\n]*[A-Za-z][^()\n]*$', t, flags=re.MULTILINE)
    bad = [h for h in bad if h.count('(') != h.count(')')]
    print(f"  {f}: {len(bad)} / 0")
    total += len(bad)
print(f"TOTAL: {total} / 0")
PY
# 기대: 모두 0/0

# (d) 프로젝트 자기 검증 (예: LLM 호출 0줄, BYOK 0줄, 다중 provider 0줄)
echo "=== 자기 검증 (프로젝트 의존) ==="
grep -rEn "openai|nim|anthropic|apiKey|BYOK|SettingsForm|ChatPanel" \
  /Users/mac/work/<project>/app \
  /Users/mac/work/<project>/components \
  /Users/mac/work/<project>/lib 2>/dev/null \
  | grep -v ".gitkeep" \
  || echo "  (0건 OK)"
# 기대: 0건
```

**검증 실패 시 fail-fast**: 위 4종 중 하나라도 실패하면 commit 금지. 다음으로 안 가고 함수정/원인 분석부터.

## Next 16 = breaking change

scaffold가 생성한 AGENTS.md (327B)에는 다음 경고가 있음:

```
<!-- BEGIN:nextjs-agent-rules -->
# This is NOT the Next.js you know
This version has breaking changes — APIs, conventions, and file structure may
all differ from your training data. Read the relevant guide in
`node_modules/next/dist/docs/` before writing any code. Heed deprecation notices.
```

→ 우리 AGENTS.md 첫 줄에 노트 박아둘 것:

```markdown
# AGENTS.md — <project> 작업 가이드

> ⚠️ **Next.js 16 (<날짜> 보일러플레이트 검증)**: `create-next-app@latest` 결과 = `next@16.x.x` + `react@19.x.x` + `tailwind@4`. Next 15와 API/관례/파일 구조가 다를 수 있음. `node_modules/next/dist/docs/`의 가이드 우선 참조 + deprecation 경고 주의.
```

## Tailwind v4 vs v3

| 차원 | v3 (옛) | v4 (Next 16 기본) |
|---|---|---|
| 설정 파일 | `tailwind.config.js` (필수) | **없음** (configless) |
| PostCSS 플러그인 | `tailwindcss` | `@tailwindcss/postcss` |
| PostCSS config | `postcss.config.js` | `postcss.config.mjs` (scaffold 생성) |
| CSS imports | `@tailwind base/components/utilities` | `@import "tailwindcss"` (단일) |

→ 옛날 가이드 따라 `tailwind.config.js` 만들면 빌드 깨짐. v4는 `postcss.config.mjs`만 유지.

## `gh api --jq` escape 함정

bash에서 `gh api ... --jq '.tree[] | "\\(.path)\\t\\(.size)B"'` → `\(...)` 리터럴 출력 (백슬래시 escape 문제). python 파이프 권장:

```bash
# ❌ bash에서 깨짐
gh api repos/<owner>/<repo>/git/trees/main?recursive=1 \
  --jq '.tree[] | select(.type=="blob") | "\\(.path)\t\(.size)B"'

# ✅ python 파이프
gh api repos/<owner>/<repo>/git/trees/main?recursive=1 \
  --jq '.tree[] | select(.type=="blob") | "\(.path) \(.size)B"' \
| python3 -c "
import sys
for l in sys.stdin.read().splitlines():
    if l.strip():
        path, size = l.rsplit(' ', 1)
        print(f'  {path:50s} {size}')
"
```

## commit 메시지 템플릿

```
feat(scaffold): Next.js 16.x.x + React 19.x.x + Tailwind 4 보일러플레이트 (1/N)

<주인님 승인 요약>.

- app/ (N파일): <간단 설명>
- public/ (N SVG): <간단 설명>
- package.json: name=<project>, <deps>
- tsconfig.json: paths '@/*' 별칭
- next.config.ts / next-env.d.ts / eslint.config.mjs / postcss.config.mjs
- package-lock.json (commit 추적)
- .gitignore: Next 표준 + <project> 시크릿 격리(<files>) 병합
- schemas/ lib/ components/ 빈 디렉토리 (.gitkeep + N~M단계에서 채움)
- CLAUDE.md (scaffold 기본) → .gitignore 처리
- AGENTS.md/README.md: Next 16 호환 노트 + 스택 정보 vN에 맞춰 추가

검증:
- npm run build: ✓ Compiled successfully in 1XXXms (Turbopack)
- npm run lint: 0 에러
- 헤딩 정규화: 0/0 깨짐 (bash + python 2중 어서션)
- 자기 검증: <프로젝트 의존 어서션 결과>

다음: N+1단계 (<다음 단계 이름>)
```

## 실측 사례: sigco3111/toss-trader (2026-07-10)

- repo: `toss-trader` (v0.3 docs만)
- 결과: `fcb8b10 → d03c934` (commit), 24파일 푸시
- 의존성: `next@16.2.10` + `react@19.2.4` + `tailwindcss@4` + `typescript@5` + `eslint@9`
- 검증: 4종 모두 PASS (build/lint/헤딩/v0.3 자기 검증)

## 다음 단계 (이 워크플로로 시작하는 일반적 작업)

1. **단순 웹앱** (시각화, 토이) → 1단계 보일러플레이트 후 바로 구현
2. **API 통합** (Toss, Notion, Telegram) → 2단계: `app/api/<name>/route.ts` + `lib/<name>.ts` 클라이언트
3. **상태 안전장치** (paper trading, 결제) → 3단계: `lib/safety.ts` + TDD (`vitest` 추가)
4. **UI 통합** → 4단계: `app/page.tsx` + `components/<Name>.tsx` 교체
5. **배포** → 5단계: `vercel.json` + Vercel env + deploy

## 흔한 실수 (anti-patterns)

| ❌ | ✅ | 이유 |
|---|---|---|
| `cd <project> && npx create-next-app .` | `/tmp/scaffold` 패턴 | 빈 디렉토리 아니면 fail |
| `cp -R /tmp/scaffold/* <project>/` | `cp -R app/ public/ package.json ...` (선택) | AGENTS.md/README.md/LICENSE/docs/ 덮어쓰기 |
| `package.json`의 `name` 그대로 (`-scaffold` 접미) | 직접 정정 (`name: "<project>"`) | npm 배포 시 이름 충돌 |
| `package-lock.json` `.gitignore` 추가 | commit 추적 | lockfile = 재현성 SSOT |
| Tailwind v3 config (`tailwind.config.js`) 추가 | v4 = configless, `postcss.config.mjs`만 | 빌드 깨짐 |
| `git init` 2번 | `--disable-git` + 기존 repo 사용 | `.git/` 덮어쓰기 위험 |
| 빈 디렉토리 그냥 두기 | `.gitkeep` + 주석 | git이 추적 안 함 |
