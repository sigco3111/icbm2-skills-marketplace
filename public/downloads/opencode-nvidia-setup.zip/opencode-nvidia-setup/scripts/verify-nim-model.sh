#!/usr/bin/env bash
# ============================================================================
# verify-nim-model.sh — NVIDIA NIM 모델 ID 검증 (oh-my-openagent 매핑용)
# ----------------------------------------------------------------------------
# 사용법: bash verify-nim-model.sh <model-search-keyword> [provider-name]
# 예시:   bash verify-nim-model.sh gpt-oss-120b
#         bash verify-nim-model.sh nemotron-3-super nvidia
#
# 출력:
#   1. NIM 카탈로그 raw ID (matched against keyword)
#   2. oh-my-openagent 내부 카탈로그 별칭 5개 (가능한 경우)
#   3. oh-my-openagent.json에 매핑해야 할 최종 키 후보
#   4. live chat 호출로 200 OK 검증
# ----------------------------------------------------------------------------
# 의존성: curl, python3, oh-my-openagent 캐시 디렉토리
# ============================================================================
set -euo pipefail

KEYWORD="${1:-gpt-oss-120b}"
PROVIDER="${2:-nvidia}"

# 1. 키 풀 로드
ENV_FILE="$HOME/.hermes/secrets/nvidia_keys.env"
if [[ ! -f "$ENV_FILE" ]]; then
  echo "❌ $ENV_FILE 없음" >&2; exit 1
fi
# shellcheck source=/dev/null
source "$ENV_FILE"

# 첫 번째 사용 가능한 키 선택
KEY=""
for VAR in NVIDIA_API_KEY_1 NVIDIA_API_KEY_HERMES NVIDIA_API_KEY_OPENCODE_1 NVIDIA_API_KEY_OPENCODE_2 NVIDIA_API_KEY_2; do
  if [[ -n "${!VAR:-}" ]]; then KEY="${!VAR}"; break; fi
done
if [[ -z "$KEY" ]]; then
  echo "❌ NVIDIA_API_KEY 풀에 사용 가능한 키 없음" >&2; exit 1
fi
export NVIDIA_API_KEY="$KEY"

echo "============================================================"
echo "NVIDIA NIM 모델 검증: '$KEYWORD'"
echo "============================================================"

# --- Step 1. NIM 카탈로그 raw ID ---
echo
echo "📋 Step 1. NIM 카탈로그 raw ID 조회"
RAW_ID=$(curl -sS https://integrate.api.nvidia.com/v1/models \
  -H "Authorization: Bearer $KEY" \
  | python3 -c "
import json, sys
d = json.load(sys.stdin)
for m in d.get('data', d):
    if '$KEYWORD'.lower() in m.get('id','').lower():
        print(m.get('id'))
        break
")
echo "   카탈로그 raw ID: ${RAW_ID:-<NOT FOUND>}"

# --- Step 2. oh-my-openagent 내부 카탈로그 별칭 ---
echo
echo "📋 Step 2. oh-my-openagent 카탈로그 별칭 (dist/index.js 검색)"
LATEST=$(ls -d "$HOME/.bun/install/cache/oh-my-openagent"@4.* 2>/dev/null | sort -V | tail -1)
if [[ -z "$LATEST" || ! -f "$LATEST/dist/index.js" ]]; then
  echo "   ⚠️ oh-my-openagent 캐시 없음 — skip"
  ALIASES=""
else
  ALIASES=$(grep -oE "\"((?:[^/\"]+/)?${KEYWORD})\"" "$LATEST/dist/index.js" | sort -u | tr -d '"')
fi
if [[ -z "$ALIASES" ]]; then
  echo "   (oh-my-openagent 카탈로그에 등록 안 됨 — NIM 라우팅 직접 매핑 필요)"
else
  echo "$ALIASES" | sed 's/^/   /'
fi

# --- Step 3. oh-my-openagent.json 매핑 후보 ---
echo
echo "📋 Step 3. oh-my-openagent.json 매핑 후보"
if [[ -n "$RAW_ID" ]]; then
  echo "   정답: \"$PROVIDER/$RAW_ID\""
  echo "   (oh-my-openagent config 예시)"
  cat <<EOF

   {
     "<your-agent-role>": {
       "model": "$PROVIDER/$RAW_ID",
       "variant": "medium"
     }
   }
EOF
fi

# --- Step 4. live chat 검증 (raw ID로) ---
if [[ -n "$RAW_ID" ]]; then
  echo
  echo "📋 Step 4. live chat 검증 (NIM 키로 raw ID 호출)"
  STATUS=$(curl -sS -X POST https://integrate.api.nvidia.com/v1/chat/completions \
    -H "Authorization: Bearer $KEY" \
    -H "Content-Type: application/json" \
    -d "{\"model\":\"$RAW_ID\",\"messages\":[{\"role\":\"user\",\"content\":\"hi\"}],\"max_tokens\":30,\"stream\":false}" \
    | python3 -c "
import json, sys
try:
  d = json.load(sys.stdin)
  if d.get('choices'): print('OK (200)')
  else: print('ERR: ' + str(d.get('error',{}).get('message','?')[:80]))
except Exception as e:
  print('parse error: ' + str(e)[:80])
" 2>&1)
  echo "   $RAW_ID → $STATUS"
fi

echo
echo "============================================================"
echo "✅ 검증 완료. '$PROVIDER/$RAW_ID' 가 oh-my-openagent.json 매핑 정답."
echo "============================================================"
