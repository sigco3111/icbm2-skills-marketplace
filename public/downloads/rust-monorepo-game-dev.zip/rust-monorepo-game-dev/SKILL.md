---
name: rust-monorepo-game-dev
description: "Local-dev setup and orchestration for Rust-server + TypeScript/Svelte-client + WASM-shared monorepo games. Worked example: Julian-adv/OpenMMO. Covers port matrix design, OAuth Web Client ID issuance, Vite proxy configuration, cold-build timeline (~28 min), background-process lifecycle (OOM/death patterns), graphics-preset-via-localStorage pattern, and the canonical 'terrain route 404' debugging trap. Load when the user forks or starts a modern Rust/TS game/server project and needs to bring it up on a dev machine, or when an existing instance is stuck (silent hangs, terrain 404s, background process death)."
version: 0.2.0
author: 혜린 (Hermes Agent)
license: MIT
metadata:
  hermes:
    tags: [rust, typescript, svelte, three.js, wasm, vite, monorepo, game-dev, mmorpg, devops, worldgen, terrain, openmmo]
    related_skills: [mac-bootstrap, autonomous-coding-agents, direct-device-execution]
    category: devops
---

# Rust + TypeScript Monorepo Game/Server Dev

Setup and orchestration playbook for **Rust backend + TypeScript/Svelte frontend + WASM shared crate** monorepos (OpenMMO-style, vibe-coded MMO stacks). The cold-start cost is ~28 min end-to-end, every layer has its own build cache, and the whole stack silently dies when 16 GB RAM fills up. This skill captures the patterns and traps so the next fork (or the next debugging session) does not relearn them.

## When to Use

Activate when any of these signals appear:

- User asks "can I run this on Hermes PC / my Mac?" for a Rust+TS repo with WASM
- User asks "what API keys do I need?" and the answer is non-trivial (OAuth, NPC tokens, admin emails)
- A Rust+TS+WASM+Vite monorepo is being cloned for the first time on a fresh machine
- A running stack is stuck at `Preparing world...` / silent hang / WebGL errors
- Background dev processes (`cargo watch`, `npm run dev`) have died silently mid-session
- Terrain / asset routes return 404 with no clear cause

## The 4-Layer Architecture (OpenMMO canonical)

| Layer | Role | Toolchain |
|---|---|---|
| `server/` | WebSocket game server + REST API | Rust, Tokio, Axum, rusqlite (bundled) |
| `client/` | Browser SPA | Svelte 5 + Three.js (Threlte) + Vite + WebGPU |
| `shared/` | Types/protocol used by both | Rust → compiled to **WASM via wasm-pack** |
| `tools/` | Data conversion, asset pipelines | Node, Python (venv + uv) |

Canonical port matrix (4 ports, 2 services):

| Port | Service | Bound to |
|---|---|---|
| 10004 | Vite dev server (browser entry) | 0.0.0.0 |
| 10005 | GLB/asset editor | 0.0.0.0 |
| 10006 | Server WebSocket | 0.0.0.0 |
| 10007 | Server REST API (terrain/housing/NPCs) | **127.0.0.1 only** |

The `client/vite.config.ts` proxies `/api → :10007` and `/ws → :10006` so the browser only talks to :10004. **This proxy is non-negotiable for browser-side cookies/auth — never have the browser connect directly to 10006/10007.**

For port matrix / proxy config detail → `references/openmmo-case-study.md`.

## Setup Workflow (5 Phases)

### Phase 1 — Triage (no installation yet)

Answer in 60 seconds:

1. **Server + client both in repo?** Check top-level dirs (`server/`, `client/`, `shared/`, `terrain/`).
2. **API keys required?** Look for `OAuth`, `GOOGLE_CLIENT_ID`, `VITE_GOOGLE_CLIENT_ID`, `Bearer`, `JWT` in README and `client/.env.example`. Almost always: **one Google OAuth Web Client ID**. Optionally: NPC/bot token (auto-generated), admin emails (env).
3. **Platform compatibility?** Check for native deps (`objc2`, `windows-sys`, CUDA). On M-series Mac, anything `#[cfg(target_os = "linux")]`-only blocks you — but pure-Rust crates with `rusqlite(bundled)` and `reqwest(rustls-tls)` are macOS-clean.

### Phase 2 — Toolchain install (parallel where safe)

```bash
# Always safe in parallel — they don't share caches
rustup (background, ~80s)         # stable-aarch64-apple-darwin
cargo install cargo-watch (~6m)   # only if dev workflow uses -w flags
cargo install wasm-pack (~3.5m)   # only if client uses shared/ WASM
npm install (~10s, foreground OK)
python3 -m venv .venv + uv        # only if tools/*.py exist
```

> **Never run `cargo install` and `npm run dev` (which triggers `wasm-pack build`) at the same time** — both spawn `rustc` and will fight for CPU. Sequence: install all cargo binaries first, then start dev servers.

### Phase 3 — Cold build (notify_on_complete)

```bash
# Server (background, 4-5 min cold; ~30s incremental)
cargo run -p onlinerpg-server &

# Client (background, 13 min cold first time due to wasm-bindgen-cli install)
cd client && npm run dev &

# Both with notify_on_complete=true so you don't sit polling
```

Watch for `MMORPG Server listening on: 0.0.0.0:10006` and `VITE v7.x ready` markers.

### Phase 4 — Verify the four ports

```bash
lsof -i :10004 -i :10005 -i :10006 -i :10007
curl -sI http://127.0.0.1:10004/                  # → 200 OK
curl -s  http://127.0.0.1:10007/api/announcements  # → 200 + JSON body
# WebSocket handshake (returns 101):
curl -i -H "Upgrade: websocket" -H "Connection: Upgrade" \
     -H "Sec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==" \
     -H "Sec-WebSocket-Version: 13" http://127.0.0.1:10006/
```

### Phase 5 — Play + diagnose hangs

Browser → `http://127.0.0.1:10004`. If it hangs at `Preparing world...`:

1. Open browser devtools (View → Developer → Developer Tools on macOS Chrome)
2. Console tab — look for `JSON.parse` errors, `WebGPU` errors, 404s
3. Network tab — any request stuck in `(pending)`?

For 90% of `Preparing world...` hangs, see **Pitfall: Terrain route 404** below.

For cold-build timing data + verified port matrix → `references/cold-build-orchestration.md`.
For OpenMMO-specific OAuth + Vite config example → `references/openmmo-case-study.md`.

## Pitfalls (verified this session)

### ❌ Pitfall 1: OOM on 16 GB Mac when cargo + wasm-pack + Vite all run together

A 16 GB Mac with cargo's `rusqlite/bundled` (200 MB RSS) + Vite dev server with esbuild + 213 npm packages + svelte-check + WebGPU in Chrome can push past swap. **Symptom:** both background processes vanish silently, no error log.

**Fix:**
1. `pkill -9 -f "cargo watch"; pkill -9 -f onlinerpg-server` to clean residual
2. `rm -rf target/debug target/.fingerprint client/node_modules/.vite client/src/lib/wasm`
3. `cargo clean` (400 files / 160 MB on OpenMMO)
4. Restart server first (`cargo run` — has cargo's hot cache), wait for LISTEN, then start client (`npm run dev`)

If using `cargo watch`, drop it for first cold build and use plain `cargo run` — the watcher itself competes for CPU during compile storms.

### ❌ Pitfall 2: "Terrain route 404" silent hang

**Symptom:** Server logs show `Player joined the game [#1]`, client gets `Preparing world...` and never advances. Browser console shows:
```
:10004/api/terrain/grass/0/0:1 Failed to load resource: 404
GLTFLoader.parse: SyntaxError: Unexpected token 'v', "version ht"... is not valid JSON
```

**Root cause:** Vite proxy returns the backend's 404 HTML page → GLTFLoader tries to JSON-parse it → throws → `bootstrapSceneAssets()` Promise never resolves → `initialDataReady = false` → loading screen stays.

**Diagnose (3 steps):**

```bash
# 1) Direct backend (bypass Vite) — should return 200
curl -s -o /dev/null -w "%{http_code}\n" http://127.0.0.1:10007/api/terrain/grass/0/0

# 2) If 404, find the actual route
grep -E "\.route\(" server/src/terrain/routes.rs

# 3) Compare: client URL vs server's actual path pattern
grep -rE "/api/terrain/" client/src/lib/network/
```

**Most likely fixes:**
- The path parameter name mismatches (`{x}/{z}` vs `{rx}/{rz}` in OpenMMO)
- An older route definition got cached; do `cargo clean` + full rebuild
- The chunk coords are outside valid range (server only serves terrain that exists)
- **Fresh clone has empty `data/terrain/`** — terrain routes return 404 because no data files exist yet. Run `cargo run -p terrain-gen --release -- bake --seed 42` (or smaller region: `--region-x-min -25 --region-x-max -23 --region-z-min 73 --region-z-max 75`) before first gameplay. The full 32km bake is 30+ min; per-tile coordinates live in `client/src/lib/components/GameScene.svelte` and the server-side route only serves files that physically exist on disk.

**The `Preparing world...` hang mechanism (verified by reading `client/src/lib/components/GameScene.svelte`):**
1. App calls `bootstrapSceneAssets({...terrainTiles...})` (line 915 in OpenMMO)
2. That promise is awaited inside `bootstrapSceneAssets().then(() => initialDataReady = true)` (line 931)
3. `bootstrapSceneAssets` internally awaits **every terrain tile's GLB + texture fetch** — if any single terrain fetch 404s and GLTFLoader throws, the promise rejects (or hangs in awaiting the next)
4. `initialDataReady` never flips to true → `GameHud.svelte:217` keeps showing `Preparing world...` overlay forever
5. The smooth-frame detector (`smoothFrameCount >= 3 && rawDeltaTime < 100ms`) only runs AFTER `initialDataReady` is true — so it's not the bottleneck

→ **The hang is upstream of any client-side timing logic.** A single missing terrain file silently dooms the load.

### ❌ Pitfall 3: Cargo incremental build hides route registration

After `cargo watch -w shared` triggers, only `shared` rebuilds, NOT `server`. If you added a new route in `server/src/terrain/routes.rs` while `cargo watch` was already running, the rebuild only checks the changed crate, and stale routes can persist. **Always do a `cargo clean` + full rebuild when routes mysteriously 404.**

### ❌ Pitfall 4: OAuth Web Client ID needs Authorized JavaScript origins

For any Rust+TS game with browser-based Google login:

1. Google Cloud Console → APIs & Services → Credentials
2. Create **OAuth client ID** with type **"Web application"** (NOT Desktop, NOT Android)
3. Authorized JavaScript origins must include **every scheme + host + port** the browser will hit:
   - `http://localhost:10004` (dev HTTP)
   - `http://127.0.0.1:10004`
   - `https://openmmo.to.nexus:10004` (if using demo tunnel)
4. **No trailing slashes**, **no path**, **exact port**
5. Same Client ID goes in **both** server (`GOOGLE_CLIENT_ID` env) and client (`VITE_GOOGLE_CLIENT_ID` in `.env.local`)
6. **Web Client needs no secret** — leave Client secret blank

If login fails with `redirect_uri_mismatch` → origins list is wrong.
If login fails with `Access blocked` → email not in OAuth consent screen's Test users list.

### ❌ Pitfall 5: Vite default host resolution kills the proxy

If the backend only binds to `127.0.0.1`, **Node 18+ resolves `localhost` to `::1` first**, which fails → Vite proxy resets every `/ws` and `/api` request. Symptom: WebSocket connects but immediately gets `Disconnected 1006`.

**Fix in `vite.config.ts`:**
```ts
const backendHost = env.VITE_BACKEND_HOST ?? '127.0.0.1'  // never 'localhost'
```

### ❌ Pitfall 6: WASM cold build is 13 min, not 1 min

First `npm run dev` triggers `wasm-pack build`, which:
1. Runs `cargo install wasm-bindgen-cli` (~5-6 min if not cached)
2. Compiles `shared/` crate to WASM target (~6 min)
3. Runs `wasm-opt` (~30s)

This is the longest single bottleneck. **If user is impatient, run `cargo install wasm-pack --locked` BEFORE `npm run dev`** so wasm-bindgen-cli is pre-installed and only step 2 runs.

### ❌ Pitfall 7: macOS dev tools sleep kills background processes

macOS suspend / screen lock / low-power mode can kill background `cargo watch` and `npm run dev` silently. After waking, processes are gone with no error log. Always verify with `ps aux | grep -E "vite|onlinerpg" | grep -v grep` after returning to the machine.

### ✅ Pattern: Graphics preset via localStorage

For Three.js/Svelte games with quality settings, **persist via localStorage** rather than a settings file:

```ts
const STORAGE_KEY = 'onlinerpg_graphicsQuality'
// 'high' | 'medium' | 'low'
localStorage.setItem(STORAGE_KEY, 'low')  // then page.reload()
```

`reloadNeeded` derived store detects if antialias changed (renderer needs recreation).

For full preset schema (pixelRatioCap, shadowMapSize, refraction, reflection, grassDensity, mobile-safe auto-detection) → `references/graphics-presets-pattern.md`.

## Diagnostic Decision Tree (Quick Reference)

```
Game stuck at "Preparing world..."
│
├─ Browser dev tools Console tab
│  ├─ "SyntaxError: Unexpected token 'v'"  → terrain route 404 → Pitfall 2
│  ├─ "WebGPU" error                       → Chrome flag or browser too old
│  ├─ "Cross-Origin-Opener-Policy"         → harmless (Chrome Built-In AI notice)
│  └─ No errors, just hang                 → bootstrapSceneAssets() Promise stuck
│                                              → likely backend 404 (Pitfall 2)
│
├─ Browser dev tools Network tab
│  ├─ All terrain/* requests 404           → server routes missing/renamed
│  ├─ All requests (pending)               → backend died (Pitfall 1 or 7)
│  └─ Everything 200                       → renderer compilation hang (lower graphics)
│
└─ Terminal — server logs
   ├─ "Player joined the game"             → backend is fine, client issue
   ├─ No "joined the game" log             → WebSocket / EnterGame not reaching server
   └─ Connection handler finished          → client disconnected before EnterGame
```

## Cold Build Timeline (Reference, OpenMMO M4 Mac mini 16GB)

| Step | Time | Sequential vs parallel |
|---|---|---|
| `git clone` (855 files) | 5 s | solo |
| `npm install` (213 packages) | 9 s | parallel-safe with cargo install |
| `.venv` + `uv` | 5 s | solo |
| `rustup` install | 78 s | parallel-safe with cargo install |
| `cargo install cargo-watch` | 6 m 19 s | **do first, before wasm-pack** |
| `cargo install wasm-pack` | 3 m 29 s | **do first, before npm run dev** |
| `cargo run -p onlinerpg-server` (cold) | ~4 min | solo (single rustc) |
| `npm run dev` → wasm-pack build | 13 m 27 s | solo (own rustc) |
| Vite ready | 3.4 s | — |
| **Total wall-clock** | **~28 min** | optimal sequencing |

For detail and incremental rebuild timings → `references/cold-build-orchestration.md`.

## Related Skills

- **`autonomous-coding-agents`** — for delegating OpenMMO modifications to Claude Code/Codex/OpenCode
- **`mac-bootstrap`** — for installing the Rust + Node + Python toolchain from scratch
- **`direct-device-execution`** — for SSH-style remote orchestration of these dev servers

## Procedural Worldgen Pattern (OpenMMO terrain-gen)

Many Rust+TS games ship **procedural world generation** as a separate CLI binary that pre-bakes tile data into the format the runtime REST API serves. OpenMMO's `tools/terrain-gen` is the canonical example.

**Subcommands** (verified working 2026-07-22):

```bash
# Quick visual check (PNG output, <30s)
cargo run -p terrain-gen --release -- preview --seed 42

# Bake the full 32km × 32km world (262,144 tiles, 30+ min)
cargo run -p terrain-gen --release -- bake --seed 42

# Bake only a small region around spawn (fast, ~1-3 min)
cargo run -p terrain-gen --release -- bake --seed 42 \
  --region-x-min -25 --region-x-max -23 \
  --region-z-min 73 --region-z-max -75

# Debug a single tile
cargo run -p terrain-gen --release -- inspect-tile --seed 42 --tile-x -24 --tile-z 74

# Probe world at world coords (for heightmap sampling)
cargo run -p terrain-gen --release -- probe-point --seed 42 --at -1475,4741
```

**When to run what:**
- **First setup**: `bake --seed 42 --region-x-min -25 ...` to enable gameplay around spawn without baking the whole world
- **World design iteration**: `preview --seed N` to dump PNGs in `data/terrain/worldgen_preview/<seed-hex>/`
- **Bug investigation**: `inspect-tile` for visualising one tile's biome/height/objects

**Spawn coordinate discovery**: Server log emits spawn coords at startup:
```
INFO onlinerpg_server::world_config: Spawn position: (-1475.2, 0.7, 4741.6)
```
Tile coords are `(world_x / 64, world_z / 64)` rounded toward zero (OpenMMO tile size = 64 world units). `-1475.2 / 64 ≈ -23` → tile x ≈ -23. Confirmed empirically: `data/terrain/trees/-23/74` is the spawn-area tile.

**Why this isn't auto-run**: The procedural generator is CPU-heavy (rayon-parallelized but still minutes-to-hours). It's intentionally a **separate tool** the user invokes once, not part of every dev server start. Don't add it to `package.json` scripts or `build.rs`.

## Pre-existing Skills Consolidation Note

This skill and `rust-frontend-monorepo-setup` overlap substantially (both cover cold-install timeline + OpenMMO port matrix + Vite proxy). The split:
- **`rust-frontend-monorepo-setup`**: emphasizes the *install* sequence (rustup → cargo install → cold build ordering)
- **`rust-monorepo-game-dev`**: emphasizes the *runtime* (port matrix, OAuth, debugging hangs, OOM recovery)

Curator may consolidate these if/when one becomes stale. Don't write redundant detail in both.
