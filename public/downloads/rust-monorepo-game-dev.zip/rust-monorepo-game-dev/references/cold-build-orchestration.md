# Cold-Build Orchestration — OpenMMO on M4 Mac mini 16GB

Verified wall-clock data from a fresh setup on 2026-07-22. Hermes PC, M4 arm64, macOS 26.5.2, 16 GB RAM. Host had no pre-existing Rust toolchain.

## Sequence That Worked

Total wall-clock: ~28 min from `git clone` to "VITE ready".

| # | Command | Wall time | Notes |
|---|---|---|---|
| 1 | `git clone https://github.com/Julian-adv/OpenMMO ~/work/openmmo` | 5 s | 855 files, 1.16 MB |
| 2 | `npm install` (in `client/`) | 9 s | 213 packages |
| 3 | `python3 -m venv .venv && source .venv/bin/activate && pip install uv` | 5 s | For `tools/*.py` data conversion |
| 4 | `curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs \| sh -s -- -y --default-toolchain stable --profile minimal` | 78 s | Background OK |
| 5 | `cargo install cargo-watch` | 6 m 19 s | Background OK, watchexec → clap → notify-rust → cargo-watch 8.5.3 |
| 6 | `cargo install wasm-pack --locked` | 3 m 29 s | **Do this BEFORE `npm run dev`** to skip the 5-min wasm-bindgen-cli install inside wasm-pack |
| 7 | `cargo run -p onlinerpg-server` (cold) | ~4 min | tokio + axum + rusqlite compile storm |
| 8 | `npm run dev -- --port 10004 --host 127.0.0.1` (cold, with pre-installed wasm-pack) | ~13 min | WASM compile + Vite ready in 3.4 s |
| 9 | `cd client && cp .env.example .env.local && edit VITE_GOOGLE_CLIENT_ID` | <30 s | Required before login |

## Sequencing Rules (Observed)

**Safe to run in parallel:**
- `git clone`, `npm install`, `rustup`, `python -m venv` — all independent, no shared cache
- Multiple `cargo install` calls against the same cargo home (serialized by cargo lock but not CPU-blocking each other)

**NEVER run simultaneously:**
- `cargo install ...` (any package) and `npm run dev` (which calls `wasm-pack build`) — both spawn `rustc`, fight for cores, both slow down 30-50%
- `cargo install` and `cargo run` of a workspace — same rustc instance, but cargo's serialization of builds makes this slow

**Run in this exact order to minimize wall-clock:**
1. `rustup` (background, fast)
2. `cargo install cargo-watch` AND `cargo install wasm-pack --locked` (background, can be parallel)
3. Wait for both cargo installs to finish
4. `cargo run -p <server>` (background, foreground OK actually — it'll go to foreground)
5. After server compiles, `cd client && npm run dev` (background)

## Incremental Rebuild Times (after cold build done)

These are the times for second/subsequent builds with everything cached:

| Action | Time |
|---|---|
| `cargo check -p onlinerpg-server` | ~25 s |
| `cargo watch -w server -w shared -w data-src -x "run -p onlinerpg-server"` initial run | ~5 min (full server + shared + terrain rebuild) |
| `cargo watch` after `shared/src/lib.rs` only change | ~30 s (only shared recompiles) |
| `npm run dev` second invocation (with cached wasm) | ~3-5 s (Vite ready) |
| Edit Svelte component + HMR | <500 ms |

The asymmetric cargo vs wasm-pack timing is because wasm-pack compiles `shared/` to **wasm32-unknown-unknown** target — a different compilation target from the host's `aarch64-apple-darwin`. They don't share cached artifacts. Both targets need to be warmed up separately.

## Disk Footprint

| Component | Size |
|---|---|
| Source tree | ~5 MB |
| `target/debug/` (server) | ~250 MB |
| `target/wasm32-unknown-unknown/` (client WASM) | ~80 MB |
| `client/node_modules/` | ~190 MB |
| `client/src/lib/wasm/` (generated) | ~5 MB |
| Total on disk after full build | ~530 MB |

`cargo clean` removes everything except `Cargo.lock` and saves ~330 MB. Use sparingly — full rebuild is 28 min from scratch.

## OOM Risk and Background Process Death

On a 16 GB Mac, the following processes together consume ~5-7 GB RSS at peak:

| Process | Peak RSS |
|---|---|
| `cargo` (rustc instances) | up to 1.5 GB during compile |
| `onlinerpg-server` | ~250 MB |
| `node` (Vite + esbuild pre-bundle) | ~1.5 GB |
| `wasm-pack` (during npm run dev) | ~1 GB |
| Chrome with WebGPU canvas loaded | 2-4 GB |
| macOS + other apps | ~3-4 GB |

**Total: 8-12 GB at peak.** On a 16 GB Mac this leaves <4 GB headroom. **Symptoms of OOM:**

1. Both background processes silently disappear from `ps aux`
2. Vite emits `[vite] server connection lost. Polling for restart...` then dies
3. WebSocket client gets `Disconnected 1006` after a few minutes of running

**Recovery sequence (verified):**

```bash
# 1) Kill any zombies (sometimes pkill -9 fails for cargo watch)
pkill -9 -f "cargo watch"
pkill -9 -f onlinerpg-server
sleep 2

# 2) Verify clean
ps aux | grep -E "onlinerpg|cargo watch" | grep -v grep | wc -l
# Should print 0

# 3) Nuclear option — wipe all caches
cd ~/work/openmmo
rm -rf target/debug target/.fingerprint
rm -rf client/node_modules/.vite client/src/lib/wasm
cargo clean  # ~160 MB freed, 400 files removed

# 4) Restart server first (it competes less for memory than the full Vite+wasm stack)
cargo run -p onlinerpg-server &
# Wait for "MMORPG Server listening on: 0.0.0.0:10006"

# 5) Then client
cd client && npm run dev &
```

## Memory Profile After All Processes Up

After ~5 min of stable operation (all Rust + Vite caches warm):

| Process | Steady-state RSS |
|---|---|
| `onlinerpg-server` | ~180 MB |
| `vite` (node) | ~600 MB |
| Chrome with 1 WebGPU tab + 1 normal tab | ~2.5 GB |
| macOS system | ~4 GB |
| **Total** | ~7.3 GB |

So 16 GB is enough for development. But **don't open Chrome DevTools with Performance tab recording + 10 other tabs** — that pushes past 12 GB and triggers swap thrash.
