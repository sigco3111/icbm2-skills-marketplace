# Graphics Preset Pattern — localStorage-Backed Three.js Settings

Extracted from OpenMMO's `client/src/lib/stores/graphicsSettings.ts`. This pattern is reusable for any Three.js / Svelte / WebGPU game that needs quality settings.

## Schema

```ts
type QualityLevel = 'high' | 'medium' | 'low'
type RenderBudget = 'full' | 'mobile'

interface GraphicsPreset {
  renderBudget: RenderBudget
  pixelRatioCap: number          // 1.0 to 2.0
  shadowMapSize: number          // 512 to 4096
  antialias: boolean             // AA toggle — requires renderer recreation
  refraction: boolean            // water/sky refraction pass
  reflection: boolean            // planar reflections
  grassDensity: number           // 0.0 to 1.0 (multiplier)
  enableDirectionalShadows: boolean
  enableWaterLayer: boolean
  enableWaterEffects: boolean
  enableGrassLayer: boolean
  grassCastsShadow: boolean
  enableTreeLayer: boolean
  treeInstanceLimit: number      // cap on instanced meshes
  treeCastsShadow: boolean
  enableWindParticles: boolean
  enableHousingLayer: boolean
  enableTorchEffects: boolean
  enableTorchShadows: boolean
  terrainQueueDrainTilesBeforeStagger: number | Infinity
  terrainTileWorkPerFrame: number | undefined
  terrainMaterialPrecompilePoolSize: number
  initialTerrainQueueDrainCount: number | Infinity
  initialTileWorkDrainCount: number | Infinity
  warmupScenePipelines: boolean
  worldMapDefaultZoomSpan: number
  worldMapMaxZoomSpan: number
  worldMapImageCacheLimit: number | Infinity
}
```

## OpenMMO's Three Tiers

### Full (Desktop)

| Preset | pixelRatio | shadowMap | AA | refraction | reflection | grassDensity |
|---|---|---|---|---|---|---|
| high | 2.0 | 4096 | ✅ | ✅ | ✅ | 1.0 |
| medium | 1.5 | 2048 | ❌ | ✅ | ✅ | 1.0 |
| low | 1.0 | 1024 | ❌ | ❌ | ❌ | 0.5 |

Default for desktop: `medium`.

### Mobile (auto-detected, applied as overlay)

Triggered when `touchDevice && (coarsePointer || narrowViewport)` OR explicit iPhone UA OR `(maxTouchPoints > 0 && viewport ≤ 430px)`.

```ts
{
  renderBudget: 'mobile',
  pixelRatioCap: 0.75,
  shadowMapSize: 512,
  antialias: false,
  refraction: false, reflection: false,
  grassDensity: 0,                  // grass off entirely on mobile
  enableWaterEffects: false,
  enableGrassLayer: false,
  enableTreeLayer: true,
  treeInstanceLimit: 384,           // ~38% of desktop
  terrainTileWorkPerFrame: 1,       // throttle per-frame work
  initialTerrainQueueDrainCount: 1, // stagger initial mount
  warmupScenePipelines: false,      // skip precompile
}
```

## Persistence Pattern

```ts
const STORAGE_KEY = 'onlinerpg_graphicsQuality'
const STORAGE_KEY_APPLIED_AA = 'onlinerpg_appliedAA'  // tracks what AA the renderer was created with

function loadQuality(): QualityLevel {
  try {
    const stored = localStorage.getItem(STORAGE_KEY)
    if (stored === 'high' || stored === 'medium' || stored === 'low') return stored
  } catch {}
  return 'medium'  // default
}

export const graphicsQuality = writable<QualityLevel>(loadQuality())

graphicsQuality.subscribe((level) => {
  localStorage.setItem(STORAGE_KEY, level)  // auto-persist
  const preset = getEffectivePreset(level)
  refractionEnabled.set(preset.refraction)   // reactive side-effects
  reflectionEnabled.set(preset.reflection)
})
```

## AA Change Detection — Renderer Recreation Gate

When `antialias` flips, the existing renderer must be destroyed and recreated. Detect via derived store:

```ts
export const reloadNeeded = derived(graphicsQuality, (level) => {
  const appliedAA = localStorage.getItem(STORAGE_KEY_APPLIED_AA) === 'true'
  return getEffectivePreset(level).antialias !== appliedAA
})

// After renderer creation:
export function applyInitialAntialias(): boolean {
  const aa = getEffectivePreset(loadQuality()).antialias
  localStorage.setItem(STORAGE_KEY_APPLIED_AA, String(aa))
  return aa
}
```

UI can subscribe to `reloadNeeded` to show a "Reload to apply graphics changes" prompt.

## How to Force a Preset (Debug / Dev)

From browser devtools console:
```js
// Set the quality level
localStorage.setItem('onlinerpg_graphicsQuality', 'low')
localStorage.setItem('onlinerpg_appliedAA', 'false')  // so AA change is detected
location.reload()  // required because of renderer recreation
```

For deeper override (e.g., force mobile budget on desktop):
```ts
// Edit graphicsSettings.ts line ~123:
export function getDeviceRenderBudget(): RenderBudget {
  return 'mobile'  // force mobile preset overlay regardless of detection
}
```

## Reusability Notes

This pattern is well-suited for:
- Three.js + Svelte/React/Vue games
- Any browser game with HDR/post-processing toggles
- Mobile/responsive game wrappers (auto-detect + override)

It is NOT suited for:
- Server-rendered games (no localStorage)
- Multi-device synced settings (use server profile + auth)
- Hot-reloadable quality (requires renderer recreation in most engines)
