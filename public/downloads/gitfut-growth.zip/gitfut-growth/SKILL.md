---
name: gitfut-growth
description: Use when improving sigco3111's GitFut card. Weekly PR review queue + DEF/PAS auto-comment drafts + GitHub Watch.
---

# gitfut-growth

sigco3111 (GitFut OVR 70, SILVER) 카드를 **DEF 47** 중심으로 끌어올리는 전용 워크플로우.

## 핵심 진단

- GitFut 엔진은 **z-score 기반**: 가장 약한 스탯이 다른 모든 스탯의 tension penalty를 잠금
- DEF 47 → SHO 64 / PAS 67 / PHY 71 5-10pt씩 부양 잠금 해제
- DRI 81 / Languages 86은 이미 한계 → **DEF가 유일한 고ROI 약점**
- ⚠️ z-score이므로 "모두 강함" 보다는 "최약점을 들어올림"이 효과적

## 통제 가능 영역 (코드북)

| 메트릭 | 통제 | 핵심 행동 |
|---|:---:|---|
| Commits / Contributions / Repositories / Languages / Active days | ✅ | 평소 OSS 작업 |
| **Reviews** (DEF 주) | ✅ | **본 트랙의 80%** |
| **Issues** (DEF 주) | ✅ | 좋은 이슈 발굴 +1 |
| Pull requests (PAS 주) | ✅ | 문서/오타/i18n PR |
| Followers (PAS 부) | ⚠️ | README 카드 + 자연 유입 |
| Stars earned / Top repo reach | ❌ | 영향 불가 — 수용 |
| Account age / Active years | ❌ | 시간 의존 |

## 매주 자동 실행 루틴 (cron)

**트리거**: 매주 월요일 09:00 KST
**산출물**: `~/Downloads/gitfut-weekly-pr-queue.md` + 텔레그램 알림 1줄

### Phase 1 — Watch 풀 유지
대상 (sigco3111이 실제로 사용 중인 도구):
```
anomalyco/opencode
code-yeongyu/oh-my-openagent
NousResearch/hermes-agent
anomalyco/models.dev
junhoyeo/tokscale
```
→ `gh watch <repo>` 1회 실행으로 풀 초기화. 누락 시 보충.

### Phase 2 — PR 큐 만들기 (DEF + PAS 동시)
대상 레포에서 **지난 7일 + comments ≤ 3 + label:documentation OR 'good first issue' OR label:help-wanted** PR 추출.

```bash
gh api "search/issues?q=is:open+is:pr+repo:<repo>+comments:0..3+created:><7일전>&per_page=10"
```

각 PR에 대해 한국어 코멘트 초안 1개 작성:
- 🟢 "Why?" 질문형 (가장 안전) → "이 부분 이렇게 구현하신 이유가 있나요?"
- 🟡 docs 개선형 → "README의 X 부분 한국어 번역 PR을 보내도 될까요?"
- 🟠 i18n 제안형 → "이 부분 한국어 컨트리뷰션 큐에 등록해드릴까요?"

### Phase 3 — 출력 파일 포맷
```markdown
# GitFut Weekly PR Queue — 2026-08-04

## 📊 현재 카드 추정
- OVR: 70-71 (지난주 대비 +0-1)
- DEF 추정: 47-49
- 목표: +0.5 OVR / 4주

## 🎯 이번 주 리뷰 후보 (5개)

### 1. anomalyco/opencode#39759 (use correct user-agent...)
- URL: ...
- 난이도: 🟢 쉬움 (docs/typo)
- 한국어 코멘트 초안:
  ```
  Hi! 작은 제안인데 user-agent 상속 부분 — npm 설치 시 환경변수가 그대로 전달되는지...
  ```
- 행동: [ ] 직접 코멘트 [ ] 스킵

### 2. ...
```

### Phase 4 — 한국어 번역 PR (PAS 동시)
sigco3111 fork 9개 중 하나를 upstream에 동기화할 때:
- 영어 commit message로 변환
- `Co-authored-by: sigco3111 <...>` trailer 추가
- CHANGELOG/PR template 자동 매칭

## 직접 해야 하는 것 (자동화 불가)

- [ ] GitHub UI에서 코멘트 실제 게시 (자격/윤리)
- [ ] GitHub 알림 설정 확인 (월 1회)
- [ ] 본인 카드를 README에 박았는지 확인 (월 1회)

## 리포트 cron 등록

`~/.hermes/cron/gitfut-weekly.json`:
```json
{
  "name": "gitfut-weekly-queue",
  "schedule": "0 9 * * 1",
  "prompt": "gitfut-growth 스킬 로드 후 sigco3111의 주간 PR 큐를 만들어 ~/Downloads/gitfut-weekly-pr-queue.md 에 저장 + 텔레그램 1줄 요약 발송",
  "skills": ["gitfut-growth"]
}
```

## 검증 체크리스트 (월 1회)

- [ ] `gh api user/sigco3111` → public_repos, followers 증가 추이
- [ ] gitfut.dev 본인 카드 캡처 → OVR 변화
- [ ] tension 완화 확인: SHO/PAS 점수 +1-2pt 동반 상승 여부

## Pitfall (함정)

1. **인위적 star/follow 절대 금지** — GitFut anti-gaming heuristic 있음
2. **동일 레포에 한 PR만**: fork upstream에 PR 보내고 끝, 그 다음은 다른 레포로
3. **큰 레포 (opencode 1100+ PR)** 에 너무 자주 코멘트 → rate limit + 시간 낭비. **목록은 작게**
4. **PR 너무 빨리 merge 요청** — 컨트리뷰터 가이드 라인 먼저 읽기

## 첫 행동 (10분)

```bash
# 1) Watch 풀 초기화
for repo in anomalyco/opencode code-yeongyu/oh-my-openagent NousResearch/hermes-agent anomalyco/models.dev junhoyeo/tokscale; do
  gh watch "$repo"
done

# 2) GitHub 알림 설정 확인
open https://github.com/settings/notifications

# 3) 큐 첫 파일 받기
gh api 'search/issues?q=is:open+is:pr+repo:anomalyco/opencode+comments:0..3+created:>2026-07-25&per_page=10'
```
