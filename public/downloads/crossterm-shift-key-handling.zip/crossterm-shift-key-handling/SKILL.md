---
name: crossterm-shift-key-handling
trigger: "When handling key events in Rust with crossterm, need to detect Shift-modified characters."
description: "Detect Shift+Key for '$' via KeyModifiers::SHIFT."
---

## Overview
Guidelines for handling Shift-modified keys (e.g., `$` via `Shift+4`) in Rust applications using the `crossterm` crate.

## Steps
1. Import required types:
   ```rust
   use crossterm::event::{Event, KeyCode, KeyEvent, KeyModifiers, KeyEventKind};
   ```
2. In the event loop, match on `Event::Key(k)` and ensure `k.kind == KeyEventKind::Press`.
3. Detect Shift‑modified characters by checking both `code` and `modifiers`:
   ```rust
   if k.code == KeyCode::Char('4') && k.modifiers.contains(KeyModifiers::SHIFT) {
       // Treat as '$'
   }
   ```
   This works for any symbol produced by holding Shift while typing a key.
4. Optionally fall back to direct `KeyCode::Char('$')` handling for terminals that emit the symbol directly.

## Pitfalls
- Matching only `KeyCode::Char('$')` misses Shift‑generated symbols on many terminals.
- Ensure you differentiate `'4'` with no Shift from `'4'` with Shift; the latter should be treated as `$`.
- Some terminals may emit the literal symbol; keep both checks for robustness.

## References
Reference file: references/shift_key_handling.md
