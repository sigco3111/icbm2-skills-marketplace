---
name: idea-bank-sync
description: sigco3111/idea-bank 저장소의 4파일 동기화 워크플로우. 신규 카테고리 파일 생성 시 README.md + IDEA_INDEX.md + IDEA_GENERATION_GUIDE.md 3개 인덱스 파일을 자동으로 갱신해서 푸시하는 패턴. 기존 카테고리 파일 확장 시에도 동일한 동기화 + 헤더/요약표/Top N 갱신 포함. **라운드 누적 패턴** (5→12→20개 등 점진적 확장) + **직군별 매칭 표** 추가 검증. "아이디어 문서에 갱신해줘", "idea-bank 추가", "아이디어뱅크 동기화", "idea-bank 4파일 갱신" 같은 요청에 발동.
version: 0.1.1
author: icbm2
metadata:
  hermes:
    tags: [idea-bank, github, sync, brainstorm, doc-maintenance, round-update]
    related_skills: [python-oss-bootstrap, auto-researcher, canvas-static-site-pipeline]
trigger: "idea-bank(sigco3111/idea-bank) 카테고리 파일 신규 생성 또는 확장 요청 시. '아이디어 문서에 갱신해줘', 'idea-bank 추가', '아이디어뱅크 동기화', 'idea-bank 4파일 갱신' 같은 요청에 발동."
last_updated: 2026-06-25
status: battle-tested-3rounds
---

# Idea-Bank 4-File Sync Workflow

sigco3111/idea-bank 저장소에 **하나의 카테고리가 일관되게 노출**되도록 4개 파일을 동기화하는 워크플로. 검증 사례: TUI 게임 카테고리 신규(라운드 1, 5개) → 확장(라운드 2, +7개 → 12개) → 확장(라운드 3, +8개 → 20개).

## ⚠️ 트리거 시 절대 놓치지 말 것

1. **반드시 4개 파일 모두 갱신** — 1\~3개만 갱신하면 인덱스 깨짐. 다음 세션에 검색이 빗나감.
2. **카운트 동기화** — README 표 / IDEA_INDEX 통계 / IDEA_GENERATION_GUIDE 맵 3곳 모두 같은 숫자
3. **신규 카테고리 vs 기존 확장 분기** — 신규는 신규 파일 1개 + 3 인덱스, 기존 확장은 기존 파일 + 3 인덱스 (PART 추가)
4. **아이디어 형식 준수** — IDEA_GENERATION_GUIDE.md의 형식 템플릿 (`### N. 🎯 — 한 줄 / **기술:** / **난이도:** / **내용:** / **포인트:**`)
5. **한국어만** + **GitHub + Vercel 무료 배포 가능 / macOS CLI** 원칙

## 🏗️ idea-bank 구조 (4-File Sync의 대상)

```
idea-bank/
├── README.md                              # ① 카테고리 표 + 구조 트리
├── IDEA_GENERATION_GUIDE.md               # ② 카테고리 커버리지 맵 (AI 에이전트용)
├── IDEA_INDEX.md                          # ③ 카테고리별 마스터 인덱스 (검색용)
├── EXISTING_REPOS.md                      # ④ 중복 방지용 기존 repo 목록
└── {Category}_Project_Ideas.md            # ⑤ 카테고리 본문 (N개)
```

**반드시 함께 갱신해야 하는 4파일**:
1. `{Category}_Project_Ideas.md` — 본문 (생성 또는 확장)
2. `README.md` — 카테고리 표 + 구조 트리
3. `IDEA_INDEX.md` — 카테고리 섹션 + 통계
4. `IDEA_GENERATION_GUIDE.md` — 카테고리 커버리지 맵

## 🚀 워크플로 (Phase 0: 설계 → Phase 1: 본문 → Phase 2: 인덱스 → Phase 3: 푸시)

### Phase 0: 설계 결정 (사용자 선택)

브레인스토밍 우선 (사용자 선호 신호 — MEMORY.md "브레인스토밍 우선 워크플로우"):

| 결정 포인트 | 옵션 |
|---|---|
| **카테고리 선택** | 신규 카테고리 파일 vs 기존 카테고리 확장 |
| **깊이** | 최소 형식 vs 확장 형식 vs 풀 형식 (시안 + 상세 + Top 7) |
| **아이디어 수** | 5개 / 10개 / 25개 (가이드라인: 대부분 25) |
| **중복 검사** | IDEA_INDEX.md + EXISTING_REPOS.md grep으로 검증 |
| **푸시 방식** | 로컬 clone → patch → push (vs gh api contents 직접) |

각 결정에 추천 1개 + 사유 + 대안 1\~2개 (clarify 도구로 결정).

### Phase 1: 본문 파일 작성

**신규 카테고리 파일** (`{Category}_Project_Ideas.md`):

```markdown
# 🏷️ {Category} 프로젝트 아이디어 모음

> {한 줄 설명}
> 생성일: YYYY-MM-DD | 작성: ICBM2

---

## 📌 배경

{왜 이 카테고리가 필요한지, 어떤 도메인/기술/직군을 다루는지}

### 참고: 기존 관련 저장소
- `existing-repo` — {설명} (참고: {차용할 부분})

---

## PART 1: {소그룹 1} (N개)

---

### 1. 🎯 아이디어명 — 한 줄 설명

**기술:** React, [관련 기술]  
**난이도:** 쉬움/보통/높음

**내용:**
- 기능 1
- 기능 2
- 기능 3

**포인트:**  
핵심 차별점 한 줄

---

{추가 아이디어...}

## 📊 요약

| # | 이름 | 위장 화면 | 직군 | ... |
|---|------|----------|------|-----|

## 🏆 ICBM2 최종 추천 Top 7

1. **#1 ...** — 한 줄 평
```

**기존 카테고리 확장**:
- 새 PART 추가 (PART 6\~12 같은 식)
- 헤더에 "최종 업데이트" + 라운드 표시 (아래 "라운드 누적 갱신 패턴" 참조)
- 요약표 + Top N 갱신 (필수)
- 카테고리 본문이 길어지면 "직군별 베스트 매칭" 표 추가 권장

### Phase 2: 3개 인덱스 파일 패치

#### 2-A. README.md

```bash
# 위치 확인
grep -n "🌐 3D 글로브\|🎮 웹 게임\|🖥️ TUI 게임" README.md

# 1. 카테고리 표에 행 추가
| 🆕 [{Category}]({Category}_Project_Ideas.md) | {한 줄 설명} | {N} |

# 2. 구조 트리에 라인 추가
├── {Category}_Project_Ideas.md      # {Category} 아이디어 ({N}개)
```

#### 2-B. IDEA_INDEX.md

```bash
# 1. 카테고리 섹션 추가/갱신 (README 카테고리 표와 동일한 순서)
## 🏷️ {Category} ({N}개) — [상세보기]({Category}_Project_Ideas.md)

| # | Name | 설명 | 종류 | 난이도 |
|---|------|------|------|--------|
| 1 | {name} | {설명} | {종류} | {난이도} |
...

# 2. 통계 표 갱신 (카운트)
| {Category} | {N} |
| **총합** | **{sum} |
```

#### 2-C. IDEA_GENERATION_GUIDE.md

```bash
# 카테고리 커버리지 맵에 행 추가
| {Category} | {Category}_Project_Ideas.md | {N} | {5\~10개 키워드 콤마구분} |
```

### Phase 3: 푸시

```bash
# 로컬 clone (있으면 pull)
gh repo clone sigco3111/idea-bank /tmp/idea-bank-clone
cd /tmp/idea-bank-clone && git pull

# 파일 작성/패치
{파일 작업}

# 4파일 모두 stage
git add {Category}_Project_Ideas.md README.md IDEA_INDEX.md IDEA_GENERATION_GUIDE.md

# 커밋
git commit -m "feat({Category}): 신규 카테고리 ({N}개)

- {Category}_Project_Ideas.md: N개 아이디어
  1. {name1}
  2. {name2}
  ...
- README.md: 카테고리 표 + 구조 트리
- IDEA_INDEX.md: 카테고리 섹션 + 통계 (M→N, 총 K→L)
- IDEA_GENERATION_GUIDE.md: 커버리지 맵 추가"

# 푸시
git push origin main

# 검증
gh api repos/sigco3111/idea-bank/contents/{Category}_Project_Ideas.md --jq '.size'
```

## 🔄 라운드 누적 갱신 패턴 (2026-06-25 검증, TUI 게임 라운드 1→2→3)

**시나리오**: 한 카테고리를 여러 세션에 걸쳐 점진적으로 확장할 때 (예: 5개 → 12개 → 20개). 라운드마다 4파일 모두 갱신 + 누적 카운트 추적.

**검증 사례**: TUI 게임 카테고리
- 라운드 1 (2026-06-24): 5개 → 통계 379→384
- 라운드 2 (2026-06-24): +7개 → 통계 384→391 (총 12개)
- 라운드 3 (2026-06-24): +8개 → 통계 391→399 (총 20개)

### 갱신 위치 4곳 (모두 라운드마다 갱신)

1. **본문 헤더**: `생성일: YYYY-MM-DD | 최종 업데이트: YYYY-MM-DD (라운드 N)`
   - 라운드 메모 추가 (선택): "**라운드 1 (PART 1\~5)**: ..." "**라운드 2 (PART 6\~12)**: ..."
2. **본문 요약표**: N개 행 전체 + 컬럼 추가 (예: 직군 매칭 컬럼)
3. **본문 Top N**: "🏆 ICBM2 최종 추천 Top 7 (라운드 N 갱신)"
4. **3개 인덱스 파일**: 카운트 + 섹션 (위 2-A/2-B/2-C 절차 동일)

### 라운드 누적 패턴 체크리스트

- [ ] 헤더 "최종 업데이트: YYYY-MM-DD (라운드 N)"
- [ ] 배경 섹션에 라운드 메모 (라운드 2부터)
- [ ] 요약표에 N개 행 전체 추가 (전체 다시 나열, 일부만 ❌)
- [ ] Top N 추천 갱신 ("라운드 N 신규 포함" 명시)
- [ ] 직군 매칭 표 추가 (라운드 3+, 아이디어가 10개 넘을 때 권장)
- [ ] IDEA_INDEX.md 통계 카운트 정확히 (기존 + 신규 = 새 총합)
- [ ] IDEA_GENERATION_GUIDE.md 키워드 추가 (신규 N개)
- [ ] 커밋 메시지에 누적 통계 명시: "총 391→399"

### ⚠️ 라운드 함정 3개

1. **요약표 일부만 갱신** — 신규 N개만 추가하고 기존 행은 손대지 않으면 컬럼 정렬 깨짐. **전체 다시 나열** 권장.
2. **Top N 미갱신** — 신규 아이디어가 더 좋은데 기존 Top 7 그대로 두면 추천 정확도 ↓. 매 라운드 갱신.
3. **카운트 표기 불일치** — 헤더 "라운드 2" 인데 통계는 12개, IDEA_INDEX.md는 13개 식. 4곳 모두 일치 확인.

---

## 📋 체크리스트 (Phase 종료 시)

**신규 카테고리:**
- [ ] `{Category}_Project_Ideas.md` 생성 (PART + N개 + 요약표 + Top N)
- [ ] README.md 카테고리 표 + 구조 트리 행 추가
- [ ] IDEA_INDEX.md 카테고리 섹션 + 통계 (카운트)
- [ ] IDEA_GENERATION_GUIDE.md 커버리지 맵 행 추가
- [ ] 4파일 모두 commit + push
- [ ] gh api로 size 검증

**기존 카테고리 확장:**
- [ ] `{Category}_Project_Ideas.md`에 새 PART 추가
- [ ] 헤더 "최종 업데이트" + 라운드 표시
- [ ] 요약표 + Top N 갱신 (N 추가된 만큼, 전체 다시 나열)
- [ ] README.md 카테고리 표 카운트 (M→N)
- [ ] IDEA_INDEX.md 카테고리 섹션 + 통계 (카운트)
- [ ] IDEA_GENERATION_GUIDE.md 커버리지 맵 카운트
- [ ] 4파일 모두 commit + push

**라운드 누적 확장 (3회차부터):**
- [ ] 위 체크리스트 모두 수행
- [ ] 배경 섹션에 라운드 메모 추가
- [ ] 직군별 베스트 매칭 표 추가 (아이디어 10개+ 권장)
- [ ] 커밋 메시지에 누적 통계 명시 (379→384, 384→391, ...)

## ⚠️ 검증된 함정 (Pitfalls)

1. **1\~3개만 갱신** — 가장 흔한 실수. 카운트 동기화 안 하면 다음 세션에 검색 빗나감. 4파일 셋트 (또는 5번째로 EXISTING_REPOS.md도 같이 봐야 함).
2. **통계 총합 계산 실수** — 기존 합계 + 신규 카운트. IDEA_INDEX.md 통계 표에서 "총합" 행을 수동 계산기로 다시 검증.
3. **README 구조 트리 빠뜨림** — 카테고리 표에만 추가하고 `├── ... ``` 트리에는 안 넣음. 두 곳 모두 갱신.
4. **헤더 날짜 갱신 안 함** — 라운드 2 확장 시 1차 헤더 그대로 두면 "최종 업데이트" 의미 없어짐. "생성일 | 최종 업데이트: YYYY-MM-DD (라운드 N)" 패턴.
5. **카테고리 표 vs 카테고리 순서 불일치** — README 표와 IDEA_INDEX.md 섹션 순서가 다르면 사용자 혼란. **README 표 순서가 곧 표준**.
6. **gh api --jq 사용 시 보안 승인 필요** — `gh api ... | python3` 파이프는 보안 검사로 차단됨. `--jq` 단독 사용 OK.
7. **푸시 전 git status로 4파일 확인** — 빠뜨린 파일 없는지 `git status --short` 출력으로 시각 확인.
8. **IDEA_GENERATION_GUIDE.md 키워드** — 5\~10개 콤마구분, 카테고리 본문의 핵심 키워드 1개씩 (예: "htop 경영, vim 추리, Grafana RTS"). 다음 세션 AI 에이전트가 검색할 단서.
9. **라운드 누적 시 요약표 일부만 갱신** — 신규만 추가하고 기존 행 그대로 두면 컬럼 정렬 깨짐. 전체 다시 나열.
10. **라운드 누적 시 Top N 미갱신** — 신규 아이디어가 더 좋은데 기존 Top 7 그대로 두면 추천 정확도 ↓.

## 🔗 관련 스킬

- `python-oss-bootstrap` — sigco3111 GitHub repo 푸시 패턴 차용 (gh CLI 비대화형, `--source` 푸시)
- `canvas-static-site-pipeline` — 브레인스토밍 우선 워크플로 (Phase 0 결정)
- `auto-researcher` — 중복 검사 패턴 (IDEA_INDEX.md + EXISTING_REPOS.md grep)
- `text-game-builder` — 다중 파일/다중 repo 동기화 패턴 (장르 repo 4개 일괄 푸시)
- `device-environment-migration` — `migration-verify.sh` 47항목 dry-run 패턴과 동일한 "사전 검증 후 진행" 철학 공유