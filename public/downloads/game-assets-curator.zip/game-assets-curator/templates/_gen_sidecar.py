#!/usr/bin/env python3
"""
_gen_sidecar.py — 각 추출된 에셋 옆에 YAML sidecar를 생성합니다.

sidecar 예시:
  /path/to/extracted/wesnoth/units/bats/fruit-bat.png.yaml

실행:
  python3 _gen_sidecar.py --game wesnoth --license CC-BY-4.0 --dest ./extracted/wesnoth
  python3 _gen_sidecar.py --game freeciv --license GPL-2.0 --dest ./extracted/freeciv

의존성:
  - Python 3.9+ (macOS 시스템 Python OK)
  - PyYAML (선택, 없으면 JSON으로 fallback)

확장: 새 게임 추가 시 GAME_AUTHORS 와 CATEGORY_KEYWORDS 두 dict 만 패치.
        메타는 _game_authors.py 모듈로 SSOT 분리된 변형도 함께 사용 (templates 참고).
"""
import os, json, argparse
from pathlib import Path
from typing import Optional
from datetime import datetime

# 게임별 메타데이터 (copyright/license/source_repo).
# 메타 SSOT 가 따로 _game_authors.py 에 있어도 — 이 dict 동기화 필수.
GAME_AUTHORS = {
    "wesnoth": {
        "copyright": "Copyright © 2003-2026 The Battle for Wesnoth contributors",
        "license_code": "GPL-2.0-only",
        "license_assets": "CC-BY-4.0",
        "source_repo": "https://github.com/wesnoth/wesnoth",
        "extracted_license": "CC-BY-4.0 (에셋만 추출, 코드 GPL 분리)",
    },
    "veloren": {
        "copyright": "Copyright © Veloren contributors",
        "license_code": "MPL-2.0",
        "license_assets": "CC-BY-4.0",
        "source_repo": "https://gitlab.com/veloren/veloren",
        "extracted_license": "CC-BY-4.0",
    },
    "freeciv": {
        "copyright": "Copyright © Freeciv contributors",
        "license_code": "GPL-2.0-or-later",
        "license_assets": "GPL-2.0-only",
        "source_repo": "https://github.com/freeciv/freeciv",
        "extracted_license": "GPL-2.0 (그림도 GPL)",
    },
    "openttd": {
        "copyright": "Copyright © OpenTTD contributors / Transport Tycoon original by Chris Sawyer",
        "license_code": "GPL-2.0-only",
        "license_assets": "GPL-2.0-only",
        "source_repo": "https://github.com/OpenTTD/OpenTTD",
        "extracted_license": "GPL-2.0 (원본 픽셀 저작권 별도 표기)",
    },
    "warzone": {
        "copyright": "Copyright © Warzone 2100 contributors / Pumpkin Studios original",
        "license_code": "GPL-2.0-only",
        "license_assets": "CC-BY-SA-2.0 (제한적 상업적 재사용 가능)",
        "source_repo": "https://github.com/Warzone2100/warzone2100",
        "extracted_license": "CC-BY-SA-2.0 (에셋만)",
    },
    "godot-open-rts": {
        "copyright": "Copyright © lampe-games contributors",
        "license_code": "MIT",
        "license_assets": "MIT",
        "source_repo": "https://github.com/lampe-games/godot-open-rts",
        "extracted_license": "MIT",
    },
}

# 경로 키워드 → 카테고리 — 새 게임 추가 시 여기에 키워드 등록
CATEGORY_KEYWORDS = {
    "wesnoth": {
        "units": "unit-sprite",
        "portraits": "portrait",
        "music": "background-music",
        "sounds": "sfx",
        "terrain": "terrain-tile",
        "items": "item-icon",
    },
    "veloren": {
        "voxel": "voxel-model",
        "item": "item-icon",
        "world": "world-asset",
        "figure": "character-figure",
        "element": "ui-element",
        "face": "character-face",
    },
    "freeciv": {
        "flags": "country-flag",
        "terrain": "terrain-tile",
        "units": "unit-sprite",
        "icons": "ui-icon",
        "city": "city-image",
        "misc": "misc-asset",
        "wonders": "world-wonder",
        "nations": "nation-emblem",
    },
    "openttd": {
        "vehicles": "vehicle-sprite",
        "terrain": "terrain-tile",
        "buildings": "building-sprite",
        "gui": "ui-element",
        "music": "background-music",
        "sounds": "sfx",
    },
    "warzone": {
        "units": "unit-3d",
        "structures": "structure-3d",
        "terrain": "terrain-texture",
        "features": "feature-mesh",
        "weapons": "weapon-model",
        "effects": "vfx",
        "interface": "ui-element",
    },
    "godot-open-rts": {
        "unit": "unit-model",
        "building": "building",
        "terrain": "terrain-texture",
        "ui": "ui-element",
    },
}


def categorize(path_rel: Path, game: str) -> str:
    """파일 경로에서 카테고리 자동 추정"""
    parts = [s.lower() for s in path_rel.parts]
    kw = CATEGORY_KEYWORDS.get(game, {})
    for k, v in kw.items():
        for p in parts:
            if k in p:
                return v
    return "asset"


def file_size_safe(p: Path) -> int:
    """symlink 따라가서 실제 파일 크기 계산 (중요 — symlink 자체는 st_size=0)"""
    try:
        if p.is_symlink():
            target = Path(os.path.realpath(p))
            if target.exists():
                return target.stat().st_size
        return p.stat().st_size
    except (OSError, FileNotFoundError):
        return 0


def make_sidecar(asset_path: Path, dest_root: Path, game: str, info: dict) -> Optional[Path]:
    """asset_path 옆에 sidecar (.yaml 또는 .json) 생성"""
    rel = asset_path.relative_to(dest_root)
    cat = categorize(rel, game)
    obj = {
        "source_game": game,
        "source_repo": info["source_repo"],
        "copyright": info["copyright"],
        "license_code": info["license_code"],
        "license_assets": info["license_assets"],
        "extracted_license": info["extracted_license"],
        "extracted_at": datetime.utcnow().isoformat() + "Z",
        "filename": str(asset_path.name),
        "rel_path": str(rel),
        "size_bytes": file_size_safe(asset_path),
        "category": cat,
        "attribution_required": info["license_assets"] not in ("CC0-1.0",),
        "modifications": "none (symlinked from upstream sparse-checkout)",
    }
    out = asset_path.parent / (asset_path.name + ".yaml")
    try:
        import yaml
        out.write_text(yaml.safe_dump(obj, sort_keys=False, allow_unicode=True))
    except ImportError:
        out = asset_path.parent / (asset_path.name + ".json")
        out.write_text(json.dumps(obj, indent=2, ensure_ascii=False))
    return out


SKIP_EXT = {".yaml", ".json", ".md", ".txt", ".gitkeep", ".LICENSE", ".LICENSE.txt"}


def main():
    ap = argparse.ArgumentParser(description="에셋 옆에 sidecar YAML/JSON 생성")
    ap.add_argument("--game", required=True, choices=list(GAME_AUTHORS.keys()))
    ap.add_argument("--dest", required=True, type=Path, help="sidecar 생성 대상 디렉터리")
    ap.add_argument("--license", required=True, help="라이선스 라벨 (메타데이터에 기록)")
    ap.add_argument("--limit", type=int, default=0, help="sidecar 생성 갯수 상한 (0=무제한)")
    args = ap.parse_args()

    info = GAME_AUTHORS[args.game]
    print(f"📝 {args.game} sidecar 생성 중 → {args.dest}")

    sidecars = 0
    skipped = 0
    for fp in args.dest.rglob("*"):
        if fp.is_dir():
            continue
        ext = fp.suffix.lower()
        if ext in SKIP_EXT or fp.name.startswith("."):
            continue
        size = file_size_safe(fp)
        if size < 100:  # 너무 작음 (symlink이나 메타데이터가 아닌 것은 skip)
            skipped += 1
            continue
        out = make_sidecar(fp, args.dest, args.game, info)
        if out:
            sidecars += 1
            if args.limit and sidecars >= args.limit:
                break

    print(f"✅ {sidecars} sidecar 생성 ({skipped} 건너뜀)")


if __name__ == "__main__":
    main()
