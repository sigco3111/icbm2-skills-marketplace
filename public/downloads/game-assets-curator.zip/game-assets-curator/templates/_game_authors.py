"""_game_authors.py — 게임 저작자/라이선스 SSOT.

`tools/_gen_sidecar.py` 와 `tools/extract-with-metadata.sh` 가 둘 다 import 하는
공유 메타데이터 모듈. 게임 추가 시 이 dict + CATEGORY_KEYWORDS dict 만 패치하면
두 도구가 자동 동작.
"""
from typing import Dict, Any

GAME_AUTHORS: Dict[str, Dict[str, Any]] = {
    "wesnoth": {
        "copyright": "Copyright © 2003-2026 The Battle for Wesnoth contributors",
        "license_code": "GPL-2.0-only",
        "license_assets": "CC-BY-4.0",
        "source_repo": "https://github.com/wesnoth/wesnoth",
        "extracted_license": "CC-BY-4.0 (에셋만 추출, 코드 GPL 분리)",
    },
    "veloren": {
        "copyright": "Copyright © Veloren contributors",
        "license_code": "MPL-2.0",
        "license_assets": "CC-BY-4.0",
        "source_repo": "https://gitlab.com/veloren/veloren",
        "extracted_license": "CC-BY-4.0",
    },
    "freeciv": {
        "copyright": "Copyright © Freeciv contributors",
        "license_code": "GPL-2.0-or-later",
        "license_assets": "GPL-2.0-only",
        "source_repo": "https://github.com/freeciv/freeciv",
        "extracted_license": "GPL-2.0 (그림도 GPL)",
    },
    "openttd": {
        "copyright": "Copyright © OpenTTD contributors / Transport Tycoon original by Chris Sawyer",
        "license_code": "GPL-2.0-only",
        "license_assets": "GPL-2.0-only",
        "source_repo": "https://github.com/OpenTTD/OpenTTD",
        "extracted_license": "GPL-2.0 (원본 픽셀 저작권 별도 표기)",
    },
    "warzone": {
        "copyright": "Copyright © Warzone 2100 contributors / Pumpkin Studios original",
        "license_code": "GPL-2.0-only",
        "license_assets": "CC-BY-SA-2.0 (제한적 상업적 재사용 가능)",
        "source_repo": "https://github.com/Warzone2100/warzone2100",
        "extracted_license": "CC-BY-SA-2.0 (에셋만)",
    },
    "godot-open-rts": {
        "copyright": "Copyright © lampe-games contributors",
        "license_code": "MIT",
        "license_assets": "MIT",
        "source_repo": "https://github.com/lampe-games/godot-open-rts",
        "extracted_license": "MIT",
    },
}

# categorize() 함수에서 카테고리 자동 추론용 키워드
CATEGORY_KEYWORDS: Dict[str, Dict[str, str]] = {
    "wesnoth": {
        "units": "unit-sprite",
        "portraits": "portrait",
        "music": "background-music",
        "sounds": "sfx",
        "terrain": "terrain-tile",
        "items": "item-icon",
    },
    "veloren": {
        "voxel": "voxel-model",
        "item": "item-icon",
        "world": "world-asset",
        "figure": "character-figure",
        "element": "ui-element",
        "face": "character-face",
    },
    "freeciv": {
        "flags": "country-flag",
        "terrain": "terrain-tile",
        "units": "unit-sprite",
        "icons": "ui-icon",
        "city": "city-image",
        "misc": "misc-asset",
        "wonders": "world-wonder",
        "nations": "nation-emblem",
    },
    "openttd": {
        "vehicles": "vehicle-sprite",
        "terrain": "terrain-tile",
        "buildings": "building-sprite",
        "gui": "ui-element",
        "music": "background-music",
        "sounds": "sfx",
    },
    "warzone": {
        "units": "unit-3d",
        "structures": "structure-3d",
        "terrain": "terrain-texture",
        "features": "feature-mesh",
        "weapons": "weapon-model",
        "effects": "vfx",
        "interface": "ui-element",
    },
    "godot-open-rts": {
        "unit": "unit-model",
        "building": "building",
        "terrain": "terrain-texture",
        "ui": "ui-element",
    },
}
