#!/usr/bin/env bash
# fetch-cc0-assets.sh — _curation_cc0_ccby_*.jsonl 의 ZIP URL을 다운로드해서
# 라이선스별·카테고리별 디렉터리로 자동 분류.
#
# 사용: ./fetch-cc0-assets.sh [jsonl_file]
# 의존: curl, python3, unzip
# 함정: 100MB 이하는 안전 / 100-500MB 가능 / 500MB+ skip (curl timeout)
set -euo pipefail

JSONL="${1:-$HOME/work/game-assets-pool/free/_curation_cc0_ccby_2026-07-15.jsonl}"
REPO="$HOME/work/game-assets-pool"
FREE="$REPO/free"
TMP="$REPO/.cache/downloads"
mkdir -p "$TMP"

[ -f "$JSONL" ] || { echo "❌ JSONL 없음: $JSONL"; exit 1; }

# 분류 디렉터리 생성
mkdir -p "$FREE/3D/CC0" "$FREE/2D/CC0" "$FREE/UI/CC0" "$FREE/Audio/CC0" "$FREE/Voxel/CC0"

total=$(wc -l < "$JSONL" | tr -d ' ')
echo "📥 $total assets to fetch"
echo ""

ok=0; fail=0; size_added=0

# 병렬 실행 — 최대 4 동시 (codeload 429 회피)
SEM=4
> "$TMP/.sem"
while IFS= read -r line; do
  # 필드 추출
  name=$(echo "$line" | python3 -c "import sys,json;print(json.loads(sys.stdin.read())['name'])")
  url=$(echo "$line" | python3 -c "import sys,json;print(json.loads(sys.stdin.read())['url'])")
  license=$(echo "$line" | python3 -c "import sys,json;print(json.loads(sys.stdin.read())['license'])")
  category=$(echo "$line" | python3 -c "import sys,json;print(json.loads(sys.stdin.read())['category'])")
  size_mb=$(echo "$line" | python3 -c "import sys,json;print(json.loads(sys.stdin.read())['size_estimate_mb'])")
  notes_kr=$(echo "$line" | python3 -c "import sys,json;print(json.loads(sys.stdin.read()).get('notes_kr',''))")

  safe_name=$(echo "$name" | tr ' ' '_' | tr -cd 'A-Za-z0-9._-')
  zip_path="$TMP/${safe_name}.zip"

  # 카테고리 prefix 매핑
  case "$category" in
    2D*) target_dir="$FREE/2D/CC0" ;;
    3D*) target_dir="$FREE/3D/CC0" ;;
    UI*) target_dir="$FREE/UI/CC0" ;;
    Audio*) target_dir="$FREE/Audio/CC0" ;;
    Voxel*) target_dir="$FREE/Voxel/CC0" ;;
    Catalog|Catalog/*) target_dir="$FREE/Catalog/CC0" ;;
    *) target_dir="$FREE/_misc/CC0" ;;
  esac

  # mixed 라이선스 처리
  if [[ "$license" == *"CC-BY"* ]] && [[ "$license" == *"CC0"* ]]; then
    target_dir="$FREE/Voxel/CC0_with_CC-BY"
    safe_name="${safe_name}_NOTICE"
  fi

  # 500MB+ skip
  if [ "$size_mb" -gt 500 ]; then
    echo "  ⏭️  skip (size ${size_mb}MB): $name"
    continue
  fi

  if [ -d "$target_dir/$safe_name" ]; then
    echo "  ⏩ already exists: $safe_name"
    ok=$((ok+1)); continue
  fi

  echo "  📥 [$category/$license] $name (${size_mb}MB)"
  if [ ! -f "$zip_path" ]; then
    curl -fsL --max-time 120 "$url" -o "$zip_path" 2>/dev/null || {
      echo "     ❌ download failed"; fail=$((fail+1)); continue
    }
  fi

  mkdir -p "$target_dir/$safe_name"
  unzip -q -o "$zip_path" -d "$target_dir/$safe_name" 2>&1 || true

  # SOURCE.md
  cat > "$target_dir/$safe_name/SOURCE.md" << NOTICE
# $name

- **출처**: $url
- **다운로드 일**: $(date -I)
- **라이선스**: $license
- **카테고리**: $category
- **메모(원본)**: $notes_kr

라이선스 표기:
\`\`\`
$name
© $(date +%Y) 원본 저작자 (라이선스 $license)
Source: $url
\`\`\`
NOTICE

  ok=$((ok+1))
  size_added=$((size_added + size_mb))
done < "$JSONL"

echo ""
echo "=========================================="
echo "  완료: $ok / $total · 누적 ${size_added}MB 추정"
echo "  실패: $fail"
echo "=========================================="
