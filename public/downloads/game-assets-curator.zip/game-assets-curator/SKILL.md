---
name: game-assets-curator
description: 게임 에셋 통합 허브 — GitHub 저장소 + 라이선스별 디렉터리 표준 + sidecar YAML 메타데이터 + GitHub Pages 카드형 카탈로그 자동 생성. 무료 팩 19종 자동 재수집 + 오픈소스 게임 5종 (Wesnoth/FreeCiv/Warzone/Veloren/OpenTTD) 에셋 추출·라이선스 표기 + submodule 운영·Pages workflow 안정화. "게임 에셋 카탈로그", "부트스트랩", "추출", "재배포", "정리", "Vercel → Pages" 같은 요청에 발동.
category: content-creation
---

# Game Assets Curator

게임 개발용 에셋을 GitHub 오픈소스에서 수집 → 분류 → 라이선스 표기 → 게임프로젝트에 submodule 배포 + Vercel/GitHub Pages 카탈로그 자동화까지. **에셋 옆에 sidecar YAML 메타데이터**를 강제하고, **라이선스별 디렉터리를 분리**해 게임 프로젝트가 필요한 라인업만 submodule로 잡을 수 있는 구조가 정답.

## 언제 쓰나
- 게임 프로젝트용 에셋을 GitHub 오픈소스에서 빠르게 모아 카탈로그로 만들 때
- Battle for Wesnoth / Veloren / Warzone2100 등 GPL/CC-BY 게임에서 에셋만 추출할 때
- 라이선스 표기 표준을 만들어 게임 빌드에 동봉할 때
- Kenney / KayKit / OpenGameArt / 큐레이션 허브 등을 카테고리·톤별로 정규화할 때
- 게임 프로젝트에 submodule로 자산을 끌어오거나 CC0 자산을 자동 재수집할 때
- **GitHub Pages 카드형 카탈로그 사이트 배포** 시 (썸네일 + 라이선스 배지 + 클라이언트 사이드 검색)
- **GitHub Pages 자동 배포** 활성화 + 빌드 실패 디버깅 시
- **이전 Vercel 카탈로그 → GitHub Pages 단일 사이트로 통합** 시 — 카드 UI + 썸네일 자산 재사용

## 핵심 디자인 원칙

| 원칙 | 이유 |
|---|---|
| **에셋과 메타데이터는 쌍** | `bats/fruit-bat.png` 옆에 반드시 `bats/fruit-bat.png.yaml` (license, copyright, source_repo, category, attribution_required) |
| **symlink 우선** | sparse-checkout 본 위에 symlink로 트리 복제 → 디스크 안 늘고 라이선스 추적성 유지 |
| **license별 dir 분리** | `free/2D/CC0`, `free/2D/CC-BY`, `free/2D/CC-BY-SA` 식으로 — 게임 프로젝트가 필요한 라인업만 submodule로 잡을 수 있게 |
| **실물 자산은 .gitignore로 푸시 제외** | `free/` 안의 .png/.fbx/.obj/\\~.zip 등은 git에 commit 하지 않고 SOURCE.md(JSON 출처) 만 추적. 게임 프로젝트에서 `bash tools/fetch-cc0-assets.sh` 한 줄로 재수집 |
| **curation 본체 = submodule** | `clone` 후 `git add` 하면 embedded git 경고 → **반드시 `git submodule add`** |
| **CREDITS.md 자동 생성** | 모든 게임 빌드에 동봉 + 게임 내 "크레딧" 화면에 동일 텍스트 노출 |
| **대용량 자산(>1GB)은 자동 다운로드에서 제외** | `sgossner/VCSL` (3.9GB), `SoundSafari/CC0-1.0-Music` (72GB LFS) 등 — 메타 인덱싱만, 다운로드 skip |
| **canonical 사이트 = GitHub Pages 단일** | Vercel 카탈로그는 2026-07-15 결정적으로 폐기 후 보존된 카드 UI 자산(`vercel-catalog/public/index.html` 디자인)을 GitHub Pages 카탈로그에 이식해 사용자 진입 경로 단일화. `vercel-catalog/` 디렉터리는 `.gitignore` 처리. |

## 두 워크스페이스 분리 패턴

```
~/work/
├── game-assets/                # 원본 워크스페이스 (submodule 아님, sparse-checkout 보존)
│   ├── curated/                # 5종+ 메타 큐레이션 (clone)
│   └── sources/
│       └── wesnoth/data/       # sparse-checkout 1.1GB (라이선스 분리 추출 원본)
│
└── game-assets-pool/           # GitHub 저장소 (submodule로 게임 프로젝트가 가져옴)
    ├── free/                   # 수집된 풀 (메타+재수집 가능)
    ├── extracted/wesnoth/      # game-assets/sources → symlink
    ├── curated/                # GitHub submodule (직접 clone 아님)
    ├── metadata/INDEX.json
    ├── site/index.html         # GitHub Pages 카탈로그 (records[:3000])
    ├── vercel-catalog/         # Vercel 폐기, 보존된 자산만
    └── tools/                  # fetch, extract, build-index, build-site, build-cards
```

## 표준 디렉터리 레이아웃

```
sigco3111/game-assets-pool/
├── free/                              # SOURCE.md 메타만 추적, 자산은 .cache + 추후 fetch
│   ├── 2D/{CC0,CC-BY,CC-BY-SA}
│   ├── 3D/{CC0,CC-BY}
│   ├── Audio/{CC0,CC-BY}
│   ├── Tilesets/CC0
│   ├── Sprites/CC0
│   ├── UI/CC0
│   ├── Fonts/CC0
│   ├── Voxel/CC0
│   ├── Effects/CC0
│   ├── Animations/CC0
│   └── _curation_cc0_ccby_*.jsonl     # provenance JSONL
├── extracted/                         # symlink only
│   ├── wesnoth/{units,portraits,music,sounds,campaigns}
│   ├── veloren/
│   └── godot-open-rts/
├── curated/                           # 외부 큐레이션 (GitHub submodule)
│   ├── 3d-resources/
│   ├── awesome-game-engine-dev/
│   ├── awesome-opensource-unity/
│   ├── VoxelAssets-mirror/            # git submodule
│   ├── base-meshes/                   # git submodule
│   └── spritecook-mirror/             # git submodule
├── metadata/
│   ├── INDEX.json                     # 마스터 인덱스 (전체 11k+ 항목)
│   └── INDEX.md
├── site/
│   ├── index.html                     # GitHub Pages 카탈로그 (1,520 카드)
│   ├── data/cards.json                # 1,520 카드 (20 assets + 1,500 links)
│   └── thumbnails/                    # 14+ 썸네일 (kaykit, nieobie 등)
├── docs/CREDIT-TEMPLATES.md
└── .github/workflows/pages.yml        # GitHub Pages 자동 배포 (PyYAML + build-cards.py 단계 필수)
```

## 지원 파일

- `references/sidecar-format.md` — sidecar YAML 필드 명세
- `references/license-policy.md` — 라이선스별 표기 의무 + 정책
- `references/cc0-ccby-asset-lineup-2026-07-15.md` — HEAD 200 검증된 GitHub CC0/CC-BY ZIP 20개 라인업 + 발굴 절차
- `references/source-workspace-pattern.md` — `~/work/game-assets/sources/` 와 `game-assets-pool` 분리 워크스페이스 결정의 이유
- `references/known-game-sources-table.md` — 5종 게임별 검증된 sparse-checkout 패턴 + 실제 추출 sidecar 수
- `references/engine-import-recipes.md` — `tools/convert-to-{godot,bevy,pixelart}.py` 사용법
- `references/vercel-deploy-recipes.md` — vercel 사이트 + GitHub Pages 워크플로우 1회 셋업 + enable 절차 + 흔한 빌드 장애 디버깅
- `references/safe-cleanup-pattern.md` — 부유 sidecar 진단·정리 멱등 패턴 (4회 데이터 손실 사고 후 v9+ 권장)
- `references/dual-site-operations.md` — Vercel + GitHub Pages 양 사이트 동기 운영 + README 정문 + push 한 줄 파이프라인
- `references/pages-submodule-and-cleanup-safety.md` — submodule 20-카드 함정, gitlink 수동 등록, cleanup idempotent 회복 패턴
- `references/pages-subpath-base-prefix.md` — **GitHub Pages subpath 위임 함정**: 카드 0개 + stats `—` 빈값의 90% 원인. 자동 prefix detect (`deriveBase()`) + 3단계 자가진단 + 빌드 사이클 + 절대 디버깅 순서. subpath vs submodule sync 트랩 우선순위.
- `references/pages-card-displays-1500-full.md` — **풀 카탈로그 노출 패턴 (2026-07-15)**: cards.json cap=1500 + `convert_to_zip_url()` 로 큐레이션 card ZIP 즉시 다운로드 + `allAssets.concat(allLinks)` + cards UI 외부 링크 ↗ / 다운로드 ZIP 📦 분리. 자가진단 체크리스트 6단계.
- `references/pages-gitmodules-gitlink-sync.md` — **`.gitmodules` ↔ git index 160000 gitlink 불일치 함정 (2026-07-16 사례)**: `No url found for submodule path` 에러, `.gitmodules` 수동 편집 시 git index 자동 동기 X, `paths` 트리거 누락 시 자동 재실행 X. 4단계 자가진단 + `.bak` 기반 마이그레이션 복구 절차 + 워크플로우 fail-fast 가드 코드.

## 소비자 (downstream 게임 프로젝트) 시점

`game-assets-curator`는 풀을 **만들고 유지**하는 시점. 게임 프로젝트가 풀을 **소비**하는 패턴은 별도 umbrella:

- → `devops/godot-game-bootstrap` (Godot 4 게임 프로젝트 부트스트랩) 의 `templates/setup-assets.sh.tpl` 참고 — 풀 디렉터리를 게임 프로젝트의 `assets/` 아래로 카테고리 필터링 후 심볼릭 링크로 연결. 멱등.
