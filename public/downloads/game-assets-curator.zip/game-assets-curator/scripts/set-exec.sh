#!/usr/bin/env bash
# 재현: ~/work/game-assets-pool 디렉터리로 cd 후 실행
chmod +x /Users/mac/.hermes/skills/game-assets-curator/templates/extract-with-metadata.sh
