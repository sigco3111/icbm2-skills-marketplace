# Pages Subpath Base Prefix — 진단 & 해결 레시피

증상: GitHub Pages 카탈로그의 stats 카드 4개 모두 `—` 빈값, 카드 그리드 0개, 페이지네이션 작동 안 함. 정적 11,306 stat 만 표시.

근본 원인: GitHub Pages 는 `<user>.github.io/<repo>/` subpath 위임. 정적 HTML 안에 하드코딩된 `fetch('/data/cards.json')` 가 root 도메인에서 404.

## 빠르게 자가 진단 (3단계)

```bash
# 1. cards.json 이 subpath 로 잘 서빙되는가?
curl -fsI https://sigco3111.github.io/game-assets-pool/data/cards.json
# 기대: HTTP 200 + content-type: application/json
# 만약 404: Pages 빌드 자체가 실패한 것 — workflow log 먼저

# 2. cards.json 이 subpath 없이 root 에서도 존재하는가? (이게 404 면 정상 — prefix 함정이 진짜 원인)
curl -fsI https://sigco3111.github.io/data/cards.json
# 기대: HTTP 404 (subpath 위임 확인)

# 3. 사이트 HTML 안에 base prefix 자동 detect JS 가 들어있는가?
curl -fs https://sigco3111.github.io/game-assets-pool/ | grep -o "deriveBase\|window.location.pathname" | head
# 기대: 1줄 이상 — detect 함수 + pathname 체크 있어야 함
```

## 즉시 fix 패턴

`site/index.html` 의 `<script>` 시작 부분에 추가:

```js
// GitHub Pages 는 /<repo>/ subpath 위임 — fetch 경로 보정
function deriveBase() {
  return window.location.pathname.startsWith('/<repo-name>/') ? '/<repo-name>' : '';
}
const base = deriveBase();

// init() 안에서
const cardsUrl = base + '/data/cards.json';
const r = await fetch(cardsUrl);

// 이미지 src에도 base prefix (썸네일 깨짐도 동일 원인)
? `<img src="${base}${escapeHtml(a.thumbnail)}" loading="lazy">`
```

**최고 빈번한 진단 트랩** — 사용자가 "카드 0개" 라고 보고할 때, 페이지네이션 버그나 데이터셋 손실로 의심하지만 **9번 중 9번 모두 subpath prefix 누락**. console.log fetch URL 만 봐도 즉시 원인 파악됨.

## 빌드 도구에서 fetch URL 로그

```js
const r = await fetch(cardsUrl);
console.log('[catalog] fetch', cardsUrl, 'status:', r.status, 'content-type:', r.headers.get('content-type'));
```

이 한 줄로 "URL 어디로 갔는지" + "HTTP 무엇 반환하는지" + "JSON 으로 파싱 가능한지" 세 가지 동시 확인.

## pages.yml 빌드 사이클

GitHub Actions workflow 가 트리거되는 조건:
- `paths:` 매칭 (예: `site/**`, `metadata/**`, `.github/workflows/pages.yml`)

**README, .gitignore 단독 push 는 트리거 안 됨** — 사용자가 "전체 카드 바뀌지 않음" 라고 하면 90% 이 패턴.

## 검증 가능한 play

```bash
# 1. 로컬에서 site/ 서빙 (Python http.server)
cd ~/work/game-assets-pool/site && python3 -m http.server 8001 &
sleep 2
curl -fsI http://127.0.0.1:8001/index.html

# 2. cards.json 도 직접
curl -fsI http://127.0.0.1:8001/data/cards.json

# 3. thumbnails PNG 도
curl -fsI http://127.0.0.1:8001/thumbnails/kaykit/adventurers.png
```

3개 모두 200 + 적절한 content-type 이어야 정상. 하나라도 404면 그 부분 진단.

## 잘 작동하면 (push 후 1-2분)

```
✅ gh run list --workflow=pages.yml --limit 1
completed	success	fix: ...	Deploy Pages (Catalog Site)	main	push	29399178977	40s
✅ curl -fsI https://<user>.github.io/<repo>/  → HTTP 200
✅ <사이트 stats 4개 모두 채워짐 + 카드 그리드 정상>
```

## 잘 안 되면 (push 후 1-2분)

```
❌ gh run list --workflow=pages.yml --limit 1
completed	failure	...  10s  (너무 빠르게 fail — 일반적으로 setup 단계)
```

흔한 원인 4가지 (Pages cards 0과 분리):
1. **Pages disabled** — `gh api .../pages` 가 404 반환. 1회 POST 필수 (함정 #21).
2. **PyYAML 미설치** — `setup-python@v5` 에 `pip install pyyaml` 단계 누락 (함정 #22).
3. **submodule sync 누락** — `actions/checkout@v4` 의 `submodules: 'recursive'` 만으론 submodule 안 파일 fetch 조용히 실패. `git submodule update --init --depth 1 --recursive` 명시 step 추가 (함정 #20a).
4. **build 가 너무 짧음** — log 의 `Build site/index.html size` 가 13KB (= 정상 cards JSON 임베드 + vite html)인지 또는 너무 작은지 (예: 5KB = 데이터 손실).

## 절대 디버깅 함수정

```
사용자: "카드 안 보여" → 1순위 의심: subpath base prefix (이 문서) → 2순위: submodule sync → 3순위: workflow 안 트리거.
이 순서대로 진단하지 않으면 subtree 와 site 둘 다 정상이지만 작동 안 함.
```

## fix 검증 단계 (2026-07-15 실측 시간)

| 단계 | 시간 | 결과 |
|---|---|---|
| 1. cards.json HEAD fetch | 5초 | HTTP 200, JSON 정상 |
| 2. site/index.html patch (base prefix 추가) | 30초 | grep 으로 `deriveBase` 확인 |
| 3. commit + push | 10초 | `c1b6b8d` |
| 4. workflow 트리거 | 즉시 | `in_progress 30s` |
| 5. Pages 반영 | 1-2분 | `completed success` |
| 6. 사용자 검증 | 10초 | 카드 + stats 정상 |

총 소요 5분. 사용자가 "여전히 안 됨" 이라고 보고 시 다시 console.log fetch URL + pathname 확인.
