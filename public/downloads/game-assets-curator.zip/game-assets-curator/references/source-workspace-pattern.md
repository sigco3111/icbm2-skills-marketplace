# Source Workspace Pattern — 왜 `~/work/game-assets/`와 `game-assets-pool`을 분리하나

## 두 워크스페이스가 하는 일

| 워크스페이스 | 역할 | GitHub에 푸시? |
|---|---|---|
| `~/work/game-assets/` | 원본 sparse-checkout 보존 + 큐레이션 clone 인덱싱 베이스 | ❌ (개인 작업) |
| `~/work/game-assets-pool/` | GitHub 공개 저장소 + submodule로 게임 프로젝트에 배포 | ✅ |

## 분리 이유 (3가지)

### 1. Wesnoth 1.1GB raw 를 submodule로 배포하면 부담

```
게임 프로젝트 A: `git submodule add game-assets-pool` → 1.1GB 다운로드
게임 프로젝트 B: `git submodule add game-assets-pool` → 또 1.1GB
```

대신:
- `~/work/game-assets/sources/wesnoth/data/` → 1.1GB **한 번만** (희정님 PC에 존재)
- `~/work/game-assets-pool/extracted/wesnoth/` → symlink tree (~250KB)

게임 프로젝트 clone 시 `extracted/wesnoth/` 안에 있는 파일들은 broken symlink로 표시되지만, **희정님이 submodule 가져다 쓴 PC = sources PC** 라 동작 정상. 다른 사람이 clone하면 Wesnoth 자체를 서브모듈로 별도 clone 해야 하지만, 그 자체로 빈 디렉터리는 OK (다음 세션에서 자동 fetch).

### 2. 큐레이션 mirror들도 submodule로 관리

`awesome-list` 같은 큐레이션은 자체 mirror가 있어 submodule로 등록하면 outer repo clone 시 자동 fetch. 단순 clone은 outer의 git이 embedded git을 알아차리지 못 함 → `git submodule add`가 정석.

Phyronnaz/VoxelAssets 처럼 자체 git mirror 가 있으면 submodule, 3d-resources 처럼 1회용 clone이면 그냥 클론 후 `git add .`.

### 3. 자동 다운로드 캐시와 분리

`fetch-cc0-assets.sh` 가 만드는 1GB 자산은 `./.cache/downloads/` 에 ZIP으로 보존되고, free/ 디렉터리의 자산 실물은 .gitignore. 이 캐시는 local-only → outer repo 와 무관.

## 작업 흐름

```bash
# 1회: 원본 sparse-checkout (희정님 PC에서 1회)
cd ~/work
mkdir -p game-assets/sources
cd game-assets/sources
git clone --filter=blob:none --depth 1 --sparse https://github.com/wesnoth/wesnoth.git
cd wesnoth
git sparse-checkout set --no-cone 'data/core' 'data/campaigns' 'COPYING.txt'

# 1회: GitHub 저장소 + 풀 추출 + 인덱스
cd ~/work
gh repo create sigco3111/game-assets-pool --public --license CC0-1.0
git clone https://github.com/sigco3111/game-assets-pool.git
# ... 골격 + submodule + symlink 추출 + CC0 fetch + 인덱스 ...

# 평소: 게임 프로젝트에 submodule로 활용
cd my-game
git submodule add https://github.com/sigco3111/game-assets-pool.git assets
ln -s assets/extracted/wesnoth/units assets-units   # broken symlink OK (희정님 PC만)
ln -s assets/free/2D/CC0 assets-2d-cc0              # free/ 자산은 submodule 안에서 fetch 받아야
```

## 다른 PC에서 clone 시

다른 PC (예: 빌드 서버) 에서 `game-assets-pool` 을 submodule 로 받으면:

1. `extracted/wesnoth/` → broken symlink (sources 워크스페이스 없음)
2. `free/<pack>/` → SOURCE.md 만 (자산 실물 없음)

→ 빌드 직전 `bash tools/fetch-cc0-assets.sh` 자동 fetch, Wesnoth 는 별도 git clone 후 sparse-checkout + symlink 재생성.

## 절대 하면 안 되는 패턴

```bash
# ❌ game-assets-pool 안에 sources/wesnoth 를 submodule로 추가
git submodule add https://github.com/wesnoth/wesnoth.git sources/wesnoth
# → submodule 안에 sources/wesnoth 가 또 들어가는 nested submodule disaster

# ❌ game-assets-pool 안에 extracted/wesnoth 를 submodule로 추가
git submodule add <...> extracted/wesnoth
# → 같은 nested 문제

# ❌ free/ 자산 실물을 git에 commit
git add free/KayKit_Adventurers/
# → 800MB commit, 100MB+ clone 저주
```
