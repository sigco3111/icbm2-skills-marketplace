# Known Game Sources — 5종 검증 추출 표

2026-07-15 시점 `game-assets-pool` 에서 검증된 게임 소스 sparse-checkout 패턴 + 실제 추출 sidecar 결과.

## 검증 게임 매트릭스

| 게임 | Repo | License (code/assets) | 메인 sparse 디렉터리 | 추출 sidecar 수 | 게임 톤 매칭 |
|---|---|---|---|---:|---|
| **Battle for Wesnoth** | github.com/wesnoth/wesnoth | GPL-2.0 / CC-BY-4.0 | `data/core`, `data/campaigns` | **1,088** | ✅ 어두운 low-fantasy political (희정님 톤) |
| **FreeCiv** | github.com/freeciv/freeciv | GPL-2.0 / GPL-2.0 | `data/flags`, `data/icons`, `data/wonders`, `data/misc` | **2,988** | ⚠️ 문명풍 (정치 톤 OK, 마법 없음) |
| **Veloren** | gitlab.com/veloren/veloren | MPL-2.0 / CC-BY-4.0 | `assets/voxygen/{voxel,element,face,anim,figure,item}` | **55** (sparse 미완, **4,752 .vox 파일** 잠재) | ⚠️ voxel + fantasy (정치 톤 약함) |
| **OpenTTD** | github.com/OpenTTD/OpenTTD | GPL-2.0 / GPL-2.0 | `media/baseset/orig_extra/` (PNG), `media/openttd.*.png` (icons) | **19** | 차량·트럭 픽셀 (정치 톤 무관) |
| **Warzone 2100** | github.com/Warzone2100/warzone2100 | GPL-2.0 / CC-BY-SA-2.0 | `data/base/images/{units,structures,terrain,features,weapons,effects}` | **730** | ⚠️ 미래전 RTS (정치 톤 약함) |
| **godot-open-rts** | github.com/lampe-games/godot-open-rts | MIT / MIT | (코드에 임베드, sparse 가치 낮음) | 0 (메타만) | MIT 클린 코드 본 |

**함의**: 2026-07-15 시점에서 **Wesnoth + FreeCiv + Warzone = 4,806 sidecar (98%)**. Veloren 과 OpenTTD 는 sparse 더 풀면 5,000+ 늘 가능. **희정님의 low-fantasy 톤 게임**에는 **Wesnoth 단독이 가장 직격**, 정치 톤에는 FreeCiv.

## 게임별 상세 sparse-checkout 명령

### Battle for Wesnoth
```bash
GAMEROOT=~/work/game-assets/sources
git clone --filter=blob:none --depth 1 --sparse https://github.com/wesnoth/wesnoth.git "$GAMEROOT/wesnoth"
cd "$GAMEROOT/wesnoth"
git sparse-checkout set --no-cone 'data/core' 'data/campaigns' 'COPYING.txt' 'README.md' 'doc'
```
- **이점**: core 디렉터리 + 모든 캠페인 데이터 (총 5GB 미만)
- **함정**: `data/campaigns/*/images/units/` 가 7개 캠페인 각자 — 모든 디렉터리 가져와야 9360+ 유닛 받음
- **추출**: `bash tools/extract-with-metadata.sh wesnoth`

### FreeCiv
```bash
git clone --filter=blob:none --depth 1 --sparse https://github.com/freeciv/freeciv.git "$GAMEROOT/freeciv"
cd "$GAMEROOT/freeciv"
git sparse-checkout set --no-cone 'data' 'freeciv/data' 'doc' 'COPYING' 'INSTALL'
```
- **핵심 데이터**: `data/flags/` (2,916 국가 깃발 PNG, **2,988 sidecar의 거의 전부**)
- **함정**: `data/wonders/` 도 큰 의미 (세계 불가사의 그림). `COPYING` 패턴은 sparse root-level 파일이라 prefix `/` 추가 필요.
- **sparse ** `'data'` 만 해도 365MB 받음** — flag가 모든 PNG
- **추출**: `bash tools/extract-with-metadata.sh freeciv`

### Veloren
```bash
GAMEROOT=~/work/game-assets/sources
git clone --depth 1 --filter=blob:none --sparse https://gitlab.com/veloren/veloren.git "$GAMEROOT/veloren"
cd "$GAMEROOT/veloren"
# ❌ sparse-checkout set --no-cone '**/*' 작동 안 함 (GitLab sparse 한정)
# ✅ 대신 풀 clone (75MB)
git sparse-checkout disable
git fetch --unshallow  # 필요 시
```
- **핵심 데이터**: `assets/voxygen/voxel/` — 4,752개 `.vox` (MagicaVoxel 모델)
- **GitLab sparse 제약**: `--no-cone '**/*'` 가 무시됨, sparse 비활성화 필요
- **함정**: vox 파일은 1-50KB 작음, 4,752개 해도 부피 50MB 미만
- **추출**: `bash tools/extract-with-metadata.sh veloren`

### OpenTTD
```bash
git clone --filter=blob:none --depth 1 --sparse https://github.com/OpenTTD/OpenTTD.git "$GAMEROOT/openttd"
cd "$GAMEROOT/openttd"
git sparse-checkout set --no-cone 'media' 'src/graphics' 'bin' 'README.md' 'COPYING.md'
```
- **핵심**: `media/baseset/orig_extra/` (PNG 트럭/열차/건물) + `media/openttd.*.png` (앱 아이콘)
- **함정**: PNG가 별로 적음. **주 자산은 sprite 압축 (`.grf`, `.obs`)** — 별도 도구 필요
- **추출**: `bash tools/extract-with-metadata.sh openttd`

### Warzone 2100
```bash
git clone --filter=blob:none --depth 1 --sparse https://github.com/Warzone2100/warzone2100.git "$GAMEROOT/warzone"
cd "$GAMEROOT/warzone"
git sparse-checkout set --no-cone 'data' 'icons' 'README.md' 'COPYING'
```
- **핵심**: `data/base/images/` 안에 `{units,structures,terrain,features,weapons,effects,frontend,intfac}/` 카테고리별 PNG 풀
- **함정**: **옛 가이드는 `data/mods/global/images/`** 를 가리키지만 2018 이후 메인 데이터가 `data/base/` 로 이동. 옛 주소는 빈 디렉터리 (`thisDirectoryIsEmpty` 마커).
- **추출**: `bash tools/extract-with-metadata.sh warzone`

## 6번째 게임 후보 큐

| 게임 | Repo | License | 추정 sidecar | 톤 매칭 |
|---|---|---|---:|---|
| **Minetest (game only)** | github.com/minetest/minetest_game | CC0/LGPL-2.1 | 10k+ 블록+아이템 | voxel 무관 |
| **FreeOrion** | github.com/freeorion/freeorion | GPL-2.0 | 5k+ 일러스트 | ✅ 우주 4X 전략 |
| **0 A.D.** | github.com/0ad/0ad | GPL-2.0 | 5k+ 일러스트 | ✅ 고대 전쟁 전략 |
| **Zero-K RTS** | github.com/ZeroK-RTS/Zero-K | GPL-2.0 | 8k+ 유닛 | ✅ Spring 엔진 RTS |
| **Arx Libertatis** | github.com/arx/ArxLibertatis | GPL-3.0 (Arx Fatalis remake) | 8k+ 던전 3D | ⚠️ 던전 RPG |
| **OpenArena** | github.com/OpenArena/gamecode | GPL-2.0 | 2k+ 모델+텍스처 | ⚠️ FPS |
| **Cave Story (NXEngine)** | github.com/nxengine/nxengine-evo | 자유 (Cave Story fangame) | 2k+ 픽셀 타일 | ⚠️ 2D 탐험 |
| **LÖVE 예제** | github.com/love2d-community/awesome-love2d | CC0 (모아둔 큐) | - | - |

각 게임은 신규 sparse-checkout 시 검증 단계 강제: `gh api repos/<owner>/<repo> | jq .default_branch` + `gh api repos/<owner>/<repo>/contents/<candidate_dir>` 후 본문 추가. **빈 디렉터리 → 불필요 (skip) → 다음 게임 후보로**.
