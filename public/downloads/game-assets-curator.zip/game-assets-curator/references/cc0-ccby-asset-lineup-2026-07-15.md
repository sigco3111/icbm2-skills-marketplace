# CC0/CC-BY Mass-Archive Lineup (2026-07-15 검증 스냅샷)

20개 GitHub `codeload.github.com` HEAD 200 확인된 게임 에셋 ZIP 라인업.
원본 JSONL은 `game-assets-pool/free/_curation_cc0_ccby_2026-07-15.jsonl`.

## 검증 절차 (다음 세션에 그대로 재사용 가능)

```bash
# 1. 후보 검색 — license 필드명 주의 (NOT licenseInfo)
gh search repos "<topic>" --limit 30 \
  --json fullName,description,stargazersCount,license,url,size \
  --jq '.[] | select(.stargazersCount > 20) | "\(.fullName)\t\(.license.spdx_id // "?")\t\(.size)KB"'

# 2. license + default_branch 검증 (비인증 시 gh api 우선)
gh api repos/<owner>/<repo> --jq '{default_branch, size, license_spdx: (.license.spdx_id // null)}'

# 3. codeload ZIP HEAD 검증 — main/master 모두 테스트
for branch in main master; do
  url="https://codeload.github.com/<owner>/<repo>/zip/refs/heads/$branch"
  curl -sIL "$url" -o /dev/null -w "$branch: %{http_code}\n"
done

# 4. README에 라이선스 명시 여부 직접 확인 (SPDX가 부정확할 수 있음)
curl -sL "https://raw.githubusercontent.com/<owner>/<repo>/<branch>/README.md" | head -20
```

## 검증된 20개 (2026-07-15)

| # | 리포 | 브랜치 | 사이즈 | 라이선스 | 카테고리 |
|---|---|---|---|---|---|
| 1 | Nieobie/game-icon-pack | main | 3.4MB | CC0-1.0 | UI icons |
| 2 | KayKit-Game-Assets/KayKit-Character-Pack-Adventures-1.0 | main | 24MB | CC0-1.0 | 3D chars |
| 3 | KayKit-Game-Assets/KayKit-City-Builder-Bits-1.0 | main | 4.7MB | CC0-1.0 | 3D props |
| 4 | KayKit-Game-Assets/KayKit-Prototype-Bits-1.0 | main | 5.5MB | CC0-1.0 | 3D props |
| 5 | KayKit-Game-Assets/KayKit-Medieval-Hexagon-Pack-1.0 | main | 29MB | CC0-1.0 | 3D tilesets |
| 6 | KayKit-Game-Assets/KayKit-Dungeon-Remastered-1.0 | main | 26MB | CC0-1.0 | 3D env |
| 7 | KayKit-Game-Assets/KayKit-Character-Pack-Skeletons-1.0 | main | 19MB | CC0-1.0 | 3D chars |
| 8 | KayKit-Game-Assets/KayKit-Restaurant-Bits-1.0 | main | 9.7MB | CC0-1.0 | 3D props |
| 9 | mr-breakfast/mrbreakfasts_free_prompts | main | 14MB | CC0-1.0 | 2D prompt pack |
| 10 | devanshutak25/3d-resources | main | 6.7MB | CC0-1.0 | 3D catalog |
| 11 | felladrin/game-development-resources-list | master | 176KB | CC0-1.0 | meta-list |
| 12 | Toxsam/open-source-3D-assets | main | 64KB | CC0-1.0 | 3D catalog |
| 13 | sparklinlabs/superpowers-asset-packs | master | 80MB | CC0-1.0 | 2D+3D mix |
| 14 | PHI-LABS-INC/phi-objects | main | 70MB | CC0-1.0 | 3D objects |
| 15 | tstamborski/pixelart-icons | main | 633KB | CC0-1.0 | pixel icons |
| 16 | Kimbatt/cc0-textures | master | 1.7MB | CC0-1.0 | PBR textures |
| 17 | Phyronnaz/VoxelAssets | master | 27MB | CC0/CC-BY mixed | voxel |
| 18 | sgossner/VCSL | master | 3.9GB | CC0-1.0 | audio samples |
| 19 | doficia/project-cordon-sprites | master | 9.7MB | CC0-1.0 | pixel sprites |
| 20 | gmgeo/osmic | master | 17MB | CC0-1.0 | SVG icons |

## 제외했지만 참고할 후보 (검증 결과 부적합)

| 리포 | 사유 |
|---|---|
| OpenMoji (`hfg-gmuend/openmoji`) | CC-BY-SA — 라인업 기준 미달 |
| Google material-design-icons | Apache-2.0 |
| SoundSafari/CC0-1.0-Music (72GB) | LFS로 다운로드 비용 비대비 |
| OpenGameArt `?field_license_value=CC0` | 404 (Drupal 필터링 browse 미작동) |
| itch.io URL 일괄 HEAD | 429 — mass-verify 불가 |

## 한국어 설명 (notes_kr)

전체 한국어 1줄 설명은 JSONL `notes_kr` 필드에 들어 있음. 예시:

- Nieobie/game-icon-pack → "548개의 둥근 스타일 아이콘 (게임 UI/인벤토리 버튼에 최적화, 상업적 사용 가능)"
- KayKit Adventurers → "낮은 폴리 4명 모험자 캐릭터 + 75 애니메이션 (FBX/OBJ/GLTF, Godot/Unity/Unreal 모두 호환)"
- sgossner/VCSL → "다용도 오디오 샘플 라이브러리 (오케스트라/타악 등 CC0, 대용량 — 전체 ZIP 다운로드 후 일부만 추출 권장)"

## 다음 세션 재현 메모

- 위 20개 URL codeload HEAD 200 모두 검증됨 (2026-07-15)
- Phyronnaz/VoxelAssets만 라이선스가 subfolder별 상이 → `Oasis/LICENSE.txt` 등 직접 확인 필요
- archive 추출 스크립트는 `extract-with-metadata.sh` 활용 (skill의 templates/ 참조)
- 신규 CC0 후보 발굴 시: topic `cc0` 또는 `topic:kenney`, stars > 20 필터가 가장 효율
