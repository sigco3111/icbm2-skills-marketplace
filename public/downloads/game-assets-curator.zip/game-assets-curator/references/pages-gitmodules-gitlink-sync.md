# Pages 워크플로우 `.gitmodules` / Git Index gitlink (160000) 불일치 함정

> **사례 발생일**: 2026-07-16 진단 (run #29396119504, "fix: explicit submodule update step in Pages workflow")
> **상태**: 어제 자동 복구 완료, 예방 문서로 보존

## 증상

GitHub Actions `actions/checkout@v4` + `submodules: 'recursive'` 단계가 다음 에러로 실패:

```
fatal: No url found for submodule path 'curated/X' in .gitmodules
fatal: Execution failed for command git submodule update --init --recursive.
Exit code 128
```

워크플로우 `build` 잡이 11초 만에 ❌ 종료.

## 근본 원리

git 서브모듈은 **두 곳에 동시 등록**되어야 한다:

| 위치 | 역할 | 등록 방법 |
|---|---|---|
| **`.gitmodules`** | URL + path (사람이 읽는 manifest) | 직접 편집 / `git submodule add` |
| **`git index` (160000 gitlink)** | 서브모듈 SHA (실제 트래킹) | `git submodule add` / `git add <path>` |

**하나만 등록된 상태**는 git이 silent로 받아들이지만 Actions는 `submodule update --init --recursive` 시도 시 `.gitmodules`에 URL 없는 path를 발견하고 죽음.

## 발생 시나리오 (이 풀에서 실제 발생)

1. 어제(2026-07-15) 정리 세션에서 `.gitmodules`를 수동 편집해 3개 엔트리(`curated/3d-resources`, `curated/awesome-game-engine-dev`, `curated/awesome-opensource-unity`)를 **빠뜨린 채로 푸시**
2. 로컬 워크스페이스의 git index에는 `160000 0b50467a... curated/3d-resources` 형태로 gitlink 3개가 그대로 살아있어서 로컬 작동은 정상
3. **`git diff HEAD -- .gitmodules`은 비어있음** — 푸시된 HEAD의 `.gitmodules` 자체는 이 상태였기 때문
4. Pages 워크플로우 `paths` 트리거는 `site/**`, `metadata/**`, `.github/workflows/pages.yml`만 watch → **`.gitmodules` 변경은 자동 트리거 X**
5. 1시간 9분 뒤 사용자가 워크플로우 파일을 수정해 푸시 → 그 시점에 미완성 `.gitmodules`가 우연히 실행되어 **첫 빌드 fail**
6. 그 후 `.gitmodules`를 다시 채워서 푸시 → `.gitmodules` 변경은 트리거 X라 워크플로우가 자동으로 안 돈다. 다른 푸시에서 우연히 돌 때만 검증됨 (모두 success)

## 자가 진단 체크리스트 (4단계)

`game-assets-pool`에서 Pages fail 발생 시:

```bash
cd ~/work/game-assets-pool

# 1. .gitmodules에 등록된 서브모듈
git config -f .gitmodules --list | grep "^submodule\." | awk -F'[.=]' '{print $2}' | sort

# 2. git index에 등록된 gitlink (160000) — 커밋 전 로컬
git ls-files --stage | awk '$2=="160000"{print $4}' | sort

# 3. 실제 디렉토리 존재 확인 (.git/modules/curated/*)
ls .git/modules/curated/ 2>/dev/null

# 4. (선택) GitHub remote의 HEAD .gitmodules와 비교
git show HEAD:.gitmodules | grep "^\[submodule" | sort
```

**1 ~ 4 사이 개수 불일치 = 불일치 함정 가능성 100%**

## 복구 절차 (멱등, 안전한 순서)

```bash
cd ~/work/game-assets-pool

# A) 누락된 URL만 .gitmodules에 수동 추가 (.bak 활용)
diff .gitmodules.bak .gitmodules    # 빠진 블록 확인
# 빠진 [submodule ...] + url 블록을 .gitmodules에 복사-붙여넣기

# B) 또는 .bak에서 URL 일치 부분만 마이그레이션
#    .bak에는 추가 있는데 HEAD .gitmodules에는 없는 URL 블록을
#    3-way diff로 추출 → 다시 추가

# C) 검증 — 양쪽 동기 확인
git config -f .gitmodules --list | grep "^submodule\." | wc -l        # N개
git ls-files --stage | awk '$2=="160000"{c++} END{print c}'           # N개

# D) push
git add .gitmodules
git commit -m "fix: complete .gitmodules to match gitlink count"
git push origin main
```

## 예방 가드 (워크플로우에 추가 가능 — opt-in)

`pages.yml`에 다음 단계를 **`actions/checkout@v4` 직후**에 추가:

```yaml
      - name: Verify .gitmodules/gitlink consistency
        run: |
          url_count=$(git config -f .gitmodules --list | grep -c "^submodule\.")
          gitlink_count=$(git ls-files --stage | awk '$2=="160000"{c++} END{print c}')
          echo "urls=$url_count gitlinks=$gitlink_count"
          if [ "$url_count" != "$gitlink_count" ]; then
            echo "::error::.gitmodules ($url_count) and gitlink ($gitlink_count) count mismatch"
            exit 1
          fi
```

이 가드가 있으면 **첫 푸시 시점에 fail-fast** 되어 어제처럼 11초 만에 일찍 발견 가능.

## 함정 정리표

| 증상 | 원인 | 진단 | 해결 |
|---|---|---|---|
| `No url found for submodule path 'curated/X'` | `.gitmodules`에 URL 누락 | `git config -f .gitmodules --list \| grep X` | `.gitmodules`에 `[submodule "curated/X"] path=... url=...` 블록 복구 |
| `.gitmodules` 수정해도 워크플로우 안 돈다 | `paths` 트리거에 `.gitmodules` 없음 | `.github/workflows/pages.yml`의 `on.push.paths` 확인 | `paths`에 `.gitmodules` 추가 또는 `workflow_dispatch` |
| 로컬에서는 멀쩡, Actions만 fail | 로컬은 gitlink만 보고 URL 검증 안 함 | 위 자가진단 4단계 | 위 복구 절차 |
| `.gitmodules.bak`는 있는데 HEAD는 불완전 | 어제 작업에서 잘못 편집 후 푸시 | `git log -p -- .gitmodules` | `.bak`에서 빠진 블록 마이그레이션 |

## 안 변하는 원칙

- **.gitmodules와 git index는 항상 동시 갱신** — `git submodule add`만 신뢰, 수동 편집 후 푸시는 위험
- **수동 편집 시**: 편집 직후 `git config -f .gitmodules --list` ↔ `git ls-files --stage | grep 160000` 카운트 비교 필수
- **워크플로우 트리거 안 걸리는 변경**(.gitmodules, free/* 등)은 빌드 안 돌고 누적되므로 `workflow_dispatch`로 주기적 검증 권장
