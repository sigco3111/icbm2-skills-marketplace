# Sidecar YAML Format

`game-assets-pool`에서 모든 추출 에셋 옆에 위치하는 `.yaml` (또는 `.json` fallback) 파일 형식 명세.

## 필드 명세

| 키 | 타입 | 필수 | 설명 |
|---|---|---|---|
| `source_game` | string | ✓ | 추출 출처 게임 키 (`wesnoth`, `veloren`, `godot-open-rts`) |
| `source_repo` | string (URL) | ✓ | 원본 Git 저장소 URL |
| `copyright` | string | ✓ | 저작권 문 (저작자 + 연도) |
| `license_code` | SPDX id | ✓ | 게임 **코드** 라이선스 (게임 본체 사용 시 트리거) |
| `license_assets` | SPDX id | ✓ | 게임 **에셋** 라이선스 (추출해서 쓸 때 적용) |
| `extracted_license` | string | ✓ | 실제로 게임 빌드에 동봉할 라이선스 + 분리 메모 |
| `extracted_at` | ISO8601 (UTC, Z 접미) | ✓ | 추출 시각 (재현성 + audit) |
| `filename` | string | ✓ | 원본 파일 이름 |
| `rel_path` | path | ✓ | `dest_root` 기준 상대경로 |
| `size_bytes` | int | ✓ | 실측 파일 크기 (symlink 따라가서 계산) |
| `category` | enum | ✓ | 카테고리 (아래 표 참조) |
| `attribution_required` | bool | ✓ | CC-BY/CC-BY-SA = true, CC0 = false |
| `modifications` | string | ✓ | 변경 사항 (raw 추출 = "none") |

## 카테고리 enum

| 게임 | 카테고리 키워드 (path에서 자동 추출) | 결과 category |
|---|---|---|
| wesnoth | `units` / `portraits` / `music` / `sounds` / `terrain` / `items` | unit-sprite / portrait / background-music / sfx / terrain-tile / item-icon |
| veloren | `voxel` / `item` / `world` | voxel-model / item-icon / world-asset |
| godot-open-rts | `unit` / `building` / `terrain` / `ui` | unit-model / building / terrain-texture / ui-element |
| 기타 | 매칭 안 됨 | `asset` |

새 게임 추가 시 `tools/_gen_sidecar.py`의 `CATEGORY_KEYWORDS` 에 등록.

## 예시: `extracted/wesnoth/units/bats/fruit-bat.png.yaml`

```yaml
source_game: wesnoth
source_repo: https://github.com/wesnoth/wesnoth
copyright: Copyright © 2003-2026 The Battle for Wesnoth contributors
license_code: GPL-2.0-only
license_assets: CC-BY-4.0
extracted_license: CC-BY-4.0 (에셋만 추출, 코드 GPL 분리)
extracted_at: '2026-07-15T05:12:56.123Z'
filename: fruit-bat.png
rel_path: units/bats/fruit-bat.png
size_bytes: 3889
category: unit-sprite
attribution_required: true
modifications: none (symlinked from upstream sparse-checkout)
```

## 검증 체크리스트

빌드 동봉 전 확인:

1. `license_assets` 가 게임 빌드 라이선스와 호환되는지
2. `attribution_required: true` 면 `CREDITS.md` 에 해당 항목 추가했는지
3. `modifications` 가 'none'이 아니면 상세 변경 이력 빌드 README에 기록했는지

## JSON fallback

`yaml` 모듈 없을 때 자동 fallback — `bats/fruit-bat.png.json` 형식으로 동일 내용 JSON. 처리 도구는 둘 다 인식해야 함.
