# GitHub Pages 카탈로그: 1,500 카드 풀 노출 패턴

**날짜**: 2026-07-15 (CURD-39 빌드 사이클)
**적용 사이트**: `sigco3111.github.io/game-assets-pool/`
**문제**: 이전엔 20 카드만 표시. 풀 11,306 큐레이션을 카드 카탈로그에 노출하는 빌드 패턴.

## 핵심 교훈 4가지

### 1. `filtered()`가 `allAssets`만 보고 `allLinks` 무시 — concatenated view 함정

**증상**: cards.json은 `assets=20` + `links=1500` 인데 사이트는 20 카드만 표시. stats 4개도 `—` (값 없음).

**원인**: `cards.json`에서 `{ "assets": [...], "links": [...] }` 분리 저장. JS의 `filtered()` 가 `allAssets.filter(a => ...)` 만 사용. `allLinks.concat()` 누락 → 1,500개 카드 무음 처리.

**수정**:
```js
const allAssets = [];
const allLinks = [];
// init() 끝에서
const allCards = allAssets.concat(allLinks);

return allCards.filter(a => {
  // ... 카테고리/라이선스/검색 필터
});
```

**자가 진단 3단계**:
1. `curl /data/cards.json` → `assets=20 links=1500` 확인
2. `curl /` → HTML 안 `const allCards`/`allAssets.concat` 검색
3. 브라우저 console.log `'[catalog] loaded 20 assets, 1500 links; total=1520'` 확인

### 2. GitHub Pages subpath 위임 — `deriveBase()` 자동 prefix detect

**이미 같은 카탈로그이 subpath 함정이 있음 (pitfall 62a)**. 본 단계에서 실전 검증되어 추가 진단 절차:

```js
function deriveBase() {
  return window.location.pathname.startsWith('/game-assets-pool/')
    ? '/game-assets-pool' : '';
}
const base = deriveBase();  // top-level const
```

`fetch('/data/cards.json')` 와 `<img src="/thumbnails/.../foo.png">` 모두 `base + '/data/...'` 형태로 자동 prefix.

**subpath vs submodule sync 트랩 우선순위**: 만약 두 가지가 동시에 발생하면 **subpath 부터 fix** (더 명확함). `git push` 후 `gh run view --log` 에서 submodule sync step 의존성 확인.

### 3. 큐레이션 카드 ZIP 다운로드 URL 자동 변환 + 노이즈 필터

**문제**: 큐레이션 카드 1,500개 중 34% 만 진짜 GitHub repo URL. 나머지 66%는:
- `https://github.com/owner/repo` 만 (raw README URL) → 클릭 시 repo만 보여줌
- `https://img.shields.io/...` (README 배지) → 노이즈
- `https://3d.devanshutak.xyz` (외부 위키/블로그) → 사이트 이동은 OK이지만 다운로드 아님

**자동 변환 + 필터**:
```python
def convert_to_zip_url(url: str) -> tuple:
    """Returns: (converted_url, is_github_zip)"""
    import re as _re
    if not url:
        return ("#", False)
    if 'shields.io' in url or url.endswith('.svg'):
        return ("#skip#", False)  # 노이즈 완전 제외
    if _re.search(r'/(issues|blob|raw|actions)/', url):
        return ("#skip#", False)
    # github.com/{owner}/{repo} → codeload ZIP
    m = _re.match(r'^https?://github\.com/([^/]+)/([^/]+?)(?:\.git)?/?$', url)
    if m:
        return (f"https://codeload.github.com/{m.group(1)}/{m.group(2)}/zip/refs/heads/main", True)
    return (url, False)
```

**UI에서 시각 분리** (사용자 의도 명확화):
```js
const linkLabel = a.is_external_link ? '외부 링크 ↗' : '다운로드 ZIP 📦';
const linkClass = a.is_external_link ? 'card-link ext' : 'card-link';
const link = a.url ? `<a class="${linkClass}" href="${escapeHtml(a.url)}" target="_blank" rel="noopener">${linkLabel}</a>` : '';
```

**CSS 분리**:
```css
.card-link { color: var(--accent); border: 1px solid var(--accent); }
.card-link:hover { background: rgba(74,144,226,0.1); }
.card-link.ext { color: var(--text-dim); border-color: var(--border); }
```

### 4. `cards.json` cap을 300 → 1500으로 확장

이전 cap `curation_cards[:300]` 가 너무 strict. 풀 노출 위해:
```python
curations = INDEX.get("curation_items", [])  # 전체 11,306 모두
# ... 
out = {
    "stats": stats,
    "assets": cards,
    "links": curation_cards[:1500],  # 풀 11,306 중 상위 1,500
}
```

`PAGE_SIZE=24` 일 때 1,500 카드 = 63 페이지 → 한 페이지당 60개 미만 = 적당.

## 결과 (2026-07-15 라이브)

- `assets=20 + links=1500 = 1,520 카드` 노출
- ZIP 다운로드 가능: **510 카드** (codeload 변환)
- 외부 링크: **1,010 카드** (블로그/위키)
- 노이즈 제거: **5개** (shields/issues/blob)
- 페이지: `1,520 / 24 = 64 페이지`
- data-banner: 빨간 → info (`cards < 50` 임계값 안 잡힘)

## 워크플로 한 줄 명령 5단계

```bash
python3 tools/build-index.py            # INDEX.json (11,306 큐레이션)
python3 tools/build-cards.py             # cards.json (1,520 카드)
                                       #  ↑ 핵심: 16k JSON
python3 tools/build-site.py              # site/index.html (Pages 카드 그리드)
git add tools/ site/ README.md
git commit -m "feat: full catalog exposure"
git push                                # Pages 자동 배포 27초
```

## 자가 진단 체크리스트

풀 카드가 안 보일 때 순서대로 확인:

| 순서 | 확인 | 명령 |
|---|---|---|
| 1 | cards.json 라이브 fetch | `curl https://<host>/data/cards.json` |
| 2 | `assets` + `links` 둘 다 있는지 | `python3 -c "import json; d=json.load(open('/tmp/c.json')); print(len(d['assets']), len(d['links']))"` |
| 3 | 사이트 HTML에 `allAssets.concat(allLinks)` 있는지 | `curl -fs <host>/ \| grep allAssets.concat` |
| 4 | `const base = deriveBase()` 있는지 (subpath) | `curl -fs <host>/ \| grep deriveBase` |
| 5 | workflow success | `gh run list --workflow=pages.yml --limit 1` |
| 6 | submodule 비었는지 (5개+ 비면 error) | `gh run view <id> --log \| grep submodule` |

## 체크포인트

- **정답 위치 = `cards.json`**: assets + links 합 = 사용자 화면 카드 수
- **`subpath prefix` = subpath 위임**: `deriveBase()` 자동 계산
- **`ZIP vs 외부 링크` = codeload 변환**: convert_to_zip_url() 와 is_external_link
