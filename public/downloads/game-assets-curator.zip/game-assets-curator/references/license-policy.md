# License Attribution Policy

게임 빌드에 동봉해야 하는 라이선스 표기 의무 요약. 각 저장소 폴더에 `LICENSE` placeholder가 있고, 빌드 시 자동으로 `docs/CREDIT-TEMPLATES.md` 기반으로 `CREDITS.md` 생성.

## 라이선스별 의무

### CC0-1.0 / Public Domain
- **표기 의무**: 선택
- 표기할 때 형식:
  ```
  Asset: [Resource Name]
  Source: https://[URL]
  License: CC0-1.0 (Public Domain Dedication)
  Author: [Author]
  ```
- 게임 내 "크레딧" 화면에 표시 의무 없음 (다만 표시 권장)

### CC-BY-4.0
- **표기 의무**: 필수 (4가지 모두)
- 게임 내 + `CREDITS.md` 동봉 필수:
  ```
  [Resource Name] © [Author] [Year]
  Licensed under CC-BY-4.0 (https://creativecommons.org/licenses/by/4.0/)
  Source: [URL]
  Modifications: [Yes/No — 무엇을 바꿨는지]
  ```
- **상업 배포 가능**, 저작자 표시만 정확히 하면 됨

### CC-BY-SA-4.0
- **표기 의무**: CC-BY + 동일 라이선스 (Share-Alike)
- 게임 전체가 SA 따라야 할 수 있음 — **SA 자원만 별도 분리해서 사용 권장**
- **상업 배포 시 SA 의무 검토** 필수:
  ```
  [Resource Name] © [Author] [Year]
  Licensed under CC-BY-SA-4.0 (https://creativecommons.org/licenses/by-sa/4.0/)
  Source: [URL]
  Modifications: Yes — [brief description]
  ```

### CC-BY-NC-4.0
- **표기 의무**: 저작자 + 라이선스 + **비상업**
- 상업 게임에서 사용 불가

### GPL-2.0 / GPL-3.0 (게임 코드)
- **표기 의무**: LICENSE 파일 + 소스 공개
- 코드 사용 시 게임 자체에 GPL 전염 (가장 큰 함정)
- **에셋만** 추출해서 쓸 때는 GPL 전염 없음. sidecar로 분리 추적:
  ```
  This game uses artwork extracted from [Game Name], © [Authors].
  Artwork licensed GPL-2.0 / CC-BY (mixed — see COPYING).
  Game source code: unaffected by artwork usage.
  ```

### MIT / BSD-3-Clause / Apache-2.0 (코드)
- **표기 의무**: 저작권 고지 / LICENSE 원문 동봉
- 게임 디렉터리에 `third_party_licenses/` 폴더 만들고 원문 동봉:
  ```
  [Resource Name] © [Copyright Holder]
  Licensed under [MIT|BSD-3-Clause|Apache-2.0]
  License text: see third_party_licenses/[name].LICENSE.txt
  ```

## 게임별 적용 매트릭스

| 게임 | 코드 라이선스 | 에셋 라이선스 | 상업 이용 | 표기 의무 |
|---|---|---|---|---|
| Battle for Wesnoth | GPL-2.0 | CC-BY | 가능 | 저작자 + CC-BY URL |
| Veloren | MPL-2.0 | CC-BY | 가능 | 저작자 + CC-BY URL |
| godot-open-rts | MIT | MIT | 가능 | 저작권 고지만 |
| Warzone 2100 | GPL-2.0 | CC-BY-NC-SA-3.0 | 비상업 | 저작자 + 라이선스 + 변경 |
| Kenney 무료팩 | — | CC0 | 가능 | 표기 선택 |
| 큐레이션 본체 (awesome-*) | — | CC0 | 가능 | 표기 선택 |
| 3d-resources 각 항목 | — | UNKNOWN | — | 사용 전 URL 재확인 |

## 검증 절차 (게임 빌드 전)

1. `metadata/INDEX.md` 에서 사용 자원 목록 확인
2. 각 자원의 `attribution_required` 가 true 면 CREDITS.md에 항목 추가
3. 모든 LICENSE 원문 `third_party_licenses/` 에 동봉
4. 게임 내 "설정 → 크레딧" 화면에 동일 텍스트 노출
5. 빌드 zip/dmg/AppImage 패키지에 `CREDITS.md` 와 `third_party_licenses/` 포함 확인

## 빠른 참조: SPDX ID

| SPDX | 정식 명 |
|---|---|
| `CC0-1.0` | Creative Commons Zero v1.0 Universal Public Domain Dedication |
| `CC-BY-4.0` | Creative Commons Attribution 4.0 International |
| `CC-BY-SA-4.0` | Creative Commons Attribution-ShareAlike 4.0 International |
| `CC-BY-NC-4.0` | Creative Commons Attribution-NonCommercial 4.0 International |
| `GPL-2.0-only` | GNU General Public License v2.0 only |
| `GPL-3.0-only` | GNU General Public License v3.0 only |
| `MIT` | MIT License |
| `BSD-3-Clause` | BSD 3-Clause "New" or "Revised" License |
| `Apache-2.0` | Apache License 2.0 |
| `MPL-2.0` | Mozilla Public License 2.0 |

라이선스 전문 출처:
- Creative Commons: <https://creativecommons.org/licenses/>
- GNU GPL FAQ: <https://www.gnu.org/licenses/gpl-faq.html>
- SPDX 리스트: <https://spdx.org/licenses/>
