# Dual-Site 운영 패턴 — Vercel + GitHub Pages

`game-assets-pool` 의 카탈로그는 **두 사이트를 동시 운영**합니다. 이 문서는 README/사이트/pipeline 동기화 패턴을 정리합니다.

## 1. 왜 두 사이트인가

| 측면 | GitHub Pages | Vercel |
|---|---|---|
| URL | sigco3111.github.io/game-assets-pool | game-assets-pool-catalog.vercel.app |
| 카드 cap | records[:3000] (안전) | records[:9000] (대역폭 여유) |
| 빌드 비용 | 0 (GitHub Actions 무료) | 0 (Vercel Hobby 무료) |
| 자동 배포 | `.github/workflows/pages.yml` | `vercel deploy --token $TOK` |
| 의존성 | 없음 (정적 HTML + JS) | 없음 (정적 HTML + JS + JSON) |
| 썸네일 | 없음 | KayKit/Nieobie 14+ |

**SSOT** = `metadata/INDEX.json`. 두 사이트 모두 같은 metadata 를 다른 cap 으로 보여줌.

## 2. 양 사이트 운영 한 줄 파이프라인

```bash
alias gap="python3 tools/build-index.py && python3 tools/build-site.py && python3 vercel-catalog/scripts/build_cards.py"

# 갱신 후 양 사이트 push
gap
TOK=$(cat ~/.hermes/secrets/vercel_token.txt)
cd vercel-catalog && vercel deploy --token "$TOK" --yes --prod && cd ..
git add . && git commit -m "docs: 갱신" && git push
```

## 3. README 양 사이트 일관성

README.md 가 진정한 정문이라면, 양 사이트 URL 둘 다 표시해야 함:

```markdown
<div align="center">

🎯 [라이브 카탈로그 · Vercel](https://game-assets-pool-catalog.vercel.app) ·
[GitHub Pages](https://sigco3111.github.io/game-assets-pool/)

</div>
```

**단일 URL 만 표기 → 다른 사이트 라이브인데 README 가 stale 로 보임**. 항상 둘 다 검증 후 push.

## 4. README 카운트 동기화

```markdown
## 풀 규모
- 큐레이션 14개
- 유니크 링크 11,306개
- 자동 수집 CC0/CC-BY 팩 19개 (VCSL 19/20)
- 추출 게임 5종 (Wesnoth/FreeCiv/Warzone/Veloren/OpenTTD)
- sidecar YAML 4,528개
- 자동화 도구 8종
- 라이브 사이트 2개 (Vercel + GitHub Pages)
```

이 카운트는 `metadata/INDEX.json` + `extract 카운트` + `recent fetch JSONL` 의 결과. `python3 tools/build-index.py` 직후 stdout 의 카운트를 그대로 README 에 옮김.

## 5. 양 사이트 상태 검증 (5단계)

```bash
# Step 1: Vercel
curl -fsLI https://game-assets-pool-catalog.vercel.app/ -o /dev/null -w "Vercel HTTP %{http_code}\n"

# Step 2: GitHub Pages
curl -fsLI https://sigco3111.github.io/game-assets-pool/ -o /dev/null -w "Pages HTTP %{http_code}\n"

# Step 3: cards.json 데이터 양
curl -fsL https://game-assets-pool-catalog.vercel.app/data/cards.json | python3 -c "
import json, sys
d = json.load(sys.stdin)
print(f'total={d[\"stats\"][\"total\"]}, thumb={d[\"stats\"][\"with_thumbnail\"]}')
"

# Step 4: Pages 워크플로 상태
gh run list --workflow=pages.yml --limit 1

# Step 5: 카운트 종합
python3 -c "
import json
d = json.load(open('metadata/INDEX.json'))
print('curation_total:', d['curation_total'])
print('wesnoth_sidecars:', d['wesnoth_assets_total'])
"
```

모두 OK 이면 README push.

## 6. 양 사이트 갱신 시 흔한 누락

| 누락 | 영향 | 예방 |
|---|---|---|
| `site/index.html` 만 빌드, `vercel-catalog/public/data/cards.json` 잊음 | Vercel 카탈로그 stale | `gap` alias 사용 |
| `vercel deploy` 만 실행, GitHub Pages workflow 안 트리거 | Pages 사이트 stale | `git push` 의무 |
| README 만 갱신, 양 사이트 안 갱신 | 카운트 mismatch | README push 시 build/all step 강제 |
| 양 사이트 갱신 후 README 동기화 안 함 | 카운트 불일치 | README 갱신 후 push 직전 검증 |

## 7. 두 사이트 차이의 의도

| 의도 | GitHub Pages | Vercel |
|---|---|---|
| 풀 마스터 인덱스 | ✅ | 부분 (cap 9000) |
| 사용자 진입 카탈로그 | 보조 | ✅ |
| 자동 배포 | ✅ | 수동 |
| 썸네일 카드 | ❌ | ✅ |
| 사이드 페이지 | ❌ | ❌ |

결론: **Vercel이 사용자 중심, GitHub Pages가 풀 무결성 증명**. README 가 양쪽 모두 가리키면 사용자/검색 엔진 둘 다 도달.
