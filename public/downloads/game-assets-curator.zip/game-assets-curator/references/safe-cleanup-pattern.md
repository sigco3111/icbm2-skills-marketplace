# Safe Cleanup Pattern — 부유 Sidecar 진단·정리

여러 cleanup 스크립트를 시도하면서 학습한 **데이터 손실이 일어나지 않는 안전한 정리 패턴** 정리.

## 1. 안 되는 패턴 (재현 사고 사례)

```
2026-07-14 / 2026-07-15 cleanup 스크립트 v1~v8 손상 이력:
1. v1: `target.exists() 면 unlink` → 740 sidecar 손실
2. v2: rel_path 따라 move → 4,596 이동 + 동일 파일을 또 잡아 일부 unlink
3. v3: same_users PNG 와 같은 dir yaml 옮기기 → 다시 옮긴 위치가 rel_path 와 어긋남
4. v4: Users 디렉터리 자체 delete → 다음 추출 전까지 sidecar 부유
5. v8: rel_path 추출 후 target_rel_path 와 정답 위치가 다름 → extracted/*/*/foo.bar.yaml 
   같은 추출 단계에서 만든 "잘못된 위치" yaml 을 또 옮기면서 원위치 yaml 손실
```

원인: **cleanup 스크립트는 멱등성이 없음** — 두 번 돌리면 두 번째에 첫 번째 결과를 일부 손실시킴.

## 2. 안전한 멱등 정리 4단계

### Step 1: 부유 경로 discovery (read-only)

```bash
# 부유 yaml 의 source_game 확인 — 게임 분포 파악
for g in wesnoth freeciv openttd warzone veloren; do
  n=$(find "extracted/$g" -path "*Users/mac*" -name "*.yaml" 2>/dev/null | wc -l)
  printf "  %-12s 부유 yaml: %d\n" "$g" "$n"
done
```

### Step 2: 전체 재추출 (멱등, 가장 안전)

```bash
# 게임별로 완전 클린 후 재추출
for g in wesnoth freeciv openttd warzone veloren; do
  rm -rf "extracted/$g"
  bash tools/extract-with-metadata.sh "$g"
done
```

**이게 가장 안전** — `extract-with-metadata.sh` 가 멱등이고, cleanup 스크립트보다 다시 돌리기 안전.

### Step 3: 정답 위치 sidecar 한 번 더 생성

```bash
# sidecar 가 다른 작업으로 사라졌다면 재실행 (Python 직접 호출)
python3 tools/_gen_sidecar.py --game wesnoth --license CC-BY-4.0 --dest extracted/wesnoth
python3 tools/_gen_sidecar.py --game freeciv --license GPL-2.0-only --dest extracted/freeciv
# ...
```

### Step 4: 검증

```bash
# 정답 위치 vs 부유 위치 카운트
for g in wesnoth freeciv openttd warzone veloren; do
  ok=$(find "extracted/$g" -name "*.yaml" -not -path "*Users/mac*" 2>/dev/null | wc -l)
  stray=$(find "extracted/$g" -name "*.yaml" -path "*Users/mac*" 2>/dev/null | wc -l)
  printf "  %-12s 정답: %5d  부유: %d\n" "$g" "$ok" "$stray"
done
```

## 3. 부유 sidecar 정답 위치 매핑

부유 yaml 의 `rel_path:` 값이 정답 위치를 알려줍니다.

```python
import re
from pathlib import Path
import shutil

ROOT = Path("extracted")

for yp in ROOT.rglob("*Users/mac*/**/*.yaml"):
    text = yp.read_text(errors="ignore")
    rel = re.search(r'rel_path:\s*(.+)', text).group(1).strip()
    target = ROOT / rel

    if target.with_suffix(target.suffix + ".yaml").exists():
        # 정답 위치에 이미 yaml 있다 → 부유는 dead, log + skip
        print(f"  SKIP (target exists): {yp.name}")
        continue
    else:
        # 정답 위치에 없으면 move
        target_yaml = target.parent / (target.name + ".yaml")
        target_yaml.parent.mkdir(parents=True, exist_ok=True)
        if not target_yaml.exists():
            shutil.move(str(yp), str(target_yaml))
```

**safety hooks**:
- `target.with_suffix(target.suffix + ".yaml").exists()` 면 절대 `unlink` 금지
- 이미 옮긴 파일은 절대 다시 처리하지 말 것
- `rm -rf` 사용자 확인을 받기 전엔 절대 사용 금지

## 4. 부유 sidecar **삭제 결정 기준**

| 조건 | 액션 |
|---|---|
| `rel_path` 가 정답 위치를 가리킴 + 정답 위치에 YAML 이미 존재 | delete OK |
| `rel_path` 가 정답 위치를 가리킴 + 정답 위치에 YAML 부재 | move |
| YAML 안에 license/copyright/source_repo 정보 정상 + 정답 위치 PNG 부재 | **keep** (분실 위험) |
| YAML 안에 license/copyright/source_repo 빈/null | log + delete |
| `Users/mac/...` 부유 경로만 보고 delete | **never** |

## 5. v9+ 권장 패턴

```python
"""
Idempotent cleanup - 절대 두 번 이상 같은 파일을 처리하지 말 것
"""
from pathlib import Path
import shutil

ROOT = Path("extracted")
processed = set()  # 절대 같은 파일 두 번 처리 금지

def safe_path(p: Path) -> Path:
    """realpath 의 일관성 보장 — symlink 안 따라감"""
    return p.resolve(strict=False)

for yp in list(ROOT.rglob("*Users/mac*/**/*.yaml")):
    safe_yp = safe_path(yp)
    if safe_yp in processed:
        continue
    processed.add(safe_yp)

    text = yp.read_text(errors="ignore")
    rel = re.search(r'rel_path:\s*(.+)', text)
    if not rel:
        continue
    target_yaml = ROOT / rel
    target_yaml = target_yaml.parent / (target_yaml.name + ".yaml")

    if target_yaml.exists():
        # 정답 위치에 이미 있다 = 부유는 dead, 절대 unlink 안 함
        # 대신 .bak 로 rename 후 다음 패스에서 자체 결정
        bak = yp.with_suffix(yp.suffix + ".bak")
        if not bak.exists():
            yp.rename(bak)
        continue

    # 정답 위치에 없으면 move
    target_yaml.parent.mkdir(parents=True, exist_ok=True)
    if not target_yaml.exists():
        shutil.move(str(yp), str(target_yaml))
```

## 6. 위험 시 즉시 사용 가능한 복구

```bash
# 가장 빠른 회복: 게임별로 전체 재추출
bash tools/extract-with-metadata.sh wesnoth
bash tools/extract-with-metadata.sh freeciv
bash tools/extract-with-metadata.sh openttd
bash tools/extract-with-metadata.sh warzone
bash tools/extract-with-metadata.sh veloren
```

이 작업은 **5-30초** 걸리고 멱등이며 손실 없이 sidecar 완전히 재생성. 이게 `extract-with-metadata.sh` 의 위대한 점 — cleanup보다 안전.
