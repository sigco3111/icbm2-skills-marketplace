# GitHub Pages 자동 배포 — submodule + 수동 gitlink 갱신 패턴

## 핵심 교훈

**GitHub Actions Pages 워크플로우가 submodule 콘텐츠를 못 가져올 때 11,306 → 20 카드로 갉먹히는 사건이 발견됨.** 데이터 손실 아님 — 로컬 site/index.html 에는 6,000 카드 정상. **자동 카탈로그 갱신을 신뢰하기 전에 submodule + gitlink 가 완전한지 검증 필수**.

## submodule 등록 후에도 수동 작업이 필요한 경우

`git submodule add --depth 1 <url> <path>` 만으로는 부족할 때가 있음:

1. **.gitmodules 누락** — `submodule add` 가 이미 디렉터리가 비어 있으면 fail, 하지만 `.git/index` 에 empty path 가 남는 경우
2. **gitlink (160000 mode file) 미등록** — `submodule add --force` 로 빈 디렉터리 위에 추가하면 gitlink 가 잘못된 commit 해시 가리킬 수 있음

**수동 회복 절차**:
```bash
# 1. .gitmodules에 entry 추가/수정
cat >> .gitmodules <<'EOF'
[submodule "curated/X"]
	path = curated/X
	url = https://github.com/<owner>/X.git
EOF

# 2. .git/modules/curated/X 이미 정리
rm -rf .git/modules/curated/X

# 3. clone
git clone --depth 1 https://github.com/<owner>/X.git curated/X

# 4. gitlink 수동 등록 (commit SHA 기준)
cd curated/X
HEAD=$(git rev-parse HEAD)
cd ../..
git update-index --add --cacheinfo 160000,$HEAD,curated/X

git add curated/X .gitmodules
git commit -m "fix: register gitlink + .gitmodules for X"
git push
```

## Actions Pages 워크플로우의 정확한 submodule 단계

`.github/workflows/pages.yml` 의 build 단계는 다음 두 가지 모두 필수:

```yaml
- uses: actions/checkout@v4
  with:
    submodules: 'recursive'        # string (NOT boolean!)
    fetch-depth: 1

- name: Init and update all submodules
  run: |
    git submodule update --init --depth 1 --recursive

- name: Verify submodules populated
  run: |
    for d in curated/*/; do
      if [ -d "$d" ] && [ -f "$d/README.md" ]; then
        echo "  $(basename $d): $(wc -l < $d/README.md) lines"
      else
        echo "  $(basename $d): EMPTY"
      fi
    done
```

`submodules: recursive` 만으론 submodule 안의 콘텐츠 fetch 가 조용히 fail 할 수 있음 — `/tmp/build-ws` 같은 임시 디렉토리 마운트 트릭은 **2025 이후 Actions 에서 무의미**. explicit `git submodule update --init --depth 1 --recursive` step 사용.

## build-index.py 가 repo 내부 데이터만 읽도록 강제

CI에서 `~/work/game-assets/curated/` 같은 **외부 절대경로 의존**은 절대 동작 안 함. **repo 내부 데이터만**:

```python
REPO = Path(__file__).resolve().parent.parent  # tools/ 기준
CURATED = REPO / "curated"
EXTRACTED = REPO / "extracted"
```

그 후에 submodule 이 그 디렉토리에 들어옴 (위 pattern 따라).

## 진단 트리

| 증상 | 원인 |
|---|---|
| GitHub Pages 가 auto-collected 팩 20개만 표시 | (a) submodule 콘텐츠 미fetch 또는 (b) build-index.py 가 외부 경로 의존 |
| `fatal: No url found for submodule path 'curated/X' in .gitmodules` | .gitmodules 누락 — submodule deinit 후 재등록 |
| `fatal: 'curated/X' already exists in the index and is not a submodule` | `git rm --cached curated/X` 후 `submodule add` 또는 `update-index --add --cacheinfo 160000,<sha>,curated/X` |
| 빈 submodule 디렉토리 | `.git/modules/curated/X` 가 stale — `rm -rf .git/modules/curated/X && git submodule update --init` |

## 양 사이트 운영 (Pages 만 유지 후 발견)

사용자가 두 카탈로그(Vercel + Pages) 운영 후 결정적으로 **Vercel 폐기 → Pages 단독**. 그 영향:
- `vercel-catalog/` 디렉터리 → `.gitignore` 처리 (`.vercel/` + `node_modules/` 자동)
- `vercel.json` 도 `.gitignore`
- README 에서 Vercel mention 0
- **단일 SSOT**: `metadata/INDEX.json` → `site/index.html` 단일 흐름

## cleanup 스크립트 절대 패턴 (핸드-온 hard-learn)

**5번 iteration (v1-v9) 손실 후 발견된 안전 패턴**:

### MUST
- **`processed` set 으로 절대 같은 파일 두 번 처리 안 함**:
  ```python
  processed.add(Path(yaml_path).resolve())
  for yp in candidates:
    if Path(yp).resolve() in processed: continue
  ```
- **`target.exists()` 면 절대 delete 금지** — 같은 파일을 두 번 읽어 옮긴 결과를 다음 패스가 지워버리는 사고
- **`rm -rf` 항상 `find ... -printf '%p\n'` 로 미리 확인 후 실행**
- **cleanup → 멱등 회복**: `rm -rf extracted/<game> && bash tools/extract-with-metadata.sh <game>` 가 5초면 복구. cleanup script 자체보다 빠름
- **glob으로 for 루프 사용 시 `[ -d "$x" ] || continue` 필수** — `$X/*/...` 가 빈 디렉토리에 대해 literal pattern 그대로 떨어질 수 있음

### MUST NOT
- 같은 yaml 을 두 번 읽고 두 번 move/​delete — **single-pass find 또는 processed-set**
- `target_dir = yp.parent.parent.parent.parent` 식 깊은 chain skip — 한 단계씩 명시
- 같은 게임 안의 다른 case 분기 (freeciv `for sub in flags ...` 같은)가 warzone 같은 DEST_ROOT 에 부작용 만들기 — **case 분기마다 자기 DEST_ROOT 만 만짐**
- bash heredoc 안의 `"""` docstring + 한글 파이프 깨짐 — **f-string 안에 `\`+한글+백틱 혼합 금지**

### 디버그 헬퍼
```bash
# 부유 sidecar 찾기
find extracted -path "*Users/mac*" -name "*.yaml" | wc -l
find extracted -path "*Users*" -type d

# sidecar 두 번 처리된 흔적 (하나의 파일에 동일 author가 sidecar 2개)
find extracted -name "*.yaml" | sort | uniq -c | awk '$1>1'

# 정상 위치 vs 부유 위치 카운트
find extracted -name "*.yaml" -not -path "*Users/mac*" | wc -l  # 정답
find extracted -name "*.yaml" -path "*Users/mac*" | wc -l        # 청소 대상
```

## 사용자에게 보여줄 요약

"20 카드만 보인다고 보고하신 문제의 원인은 submodule 등록이 CI 안에서 안 잡혀서. **데이터 손실 아니라** submodule 체크아웃 단계 누락이었음. 4개 submodule (`3d-resources`, `awesome-opensource-unity`, `VoxelAssets`, `awesome-game-engine-dev`) 의 `.gitmodules` 미등록 + gitlink 미등록이 진짜 원인. 다음 세션 시작 시 `git submodule update --init` 으로 회복."
