# Vercel + GitHub Pages 카탈로그 배포 레시피

`game-assets-pool` 저장소에는 두 개의 정적 카탈로그 사이트가 운영됩니다:
- **GitHub Pages** (records ≤ 3000, 자동 push-on-PR)
- **Vercel** (records ≤ 9000, 수동 token + 게임 프로젝트 별 운영)

이 문서는 두 사이트의 셋업 절차, 빌드 산출물 위치, 자주 발생하는 장애 패턴을 정리합니다.

---

## 1. GitHub Pages

### 자동화 흐름

```
git push origin main → .github/workflows/pages.yml
  → pip install pyyaml → python3 tools/build-index.py
  → python3 tools/build-site.py
  → Upload site/ as artifact
  → actions/deploy-pages@v4 → sigco3111.github.io/game-assets-pool
```

### 1순위 장애: "Get Pages site failed. Not Found" (CRITICAL)

**증상**: workflow 5초 만에 fail.

**원인**: 저장소 Settings → Pages 가 미활성화 상태.

**수정** (workflow 보다 먼저 1회):

```bash
gh api repos/sigco3111/game-assets-pool/pages --method POST \
  --input '{"build_type":"workflow","source":{"branch":"main","path":"/"},"public":true}' \
  -H "Accept: application/vnd.github+json"
```

응답의 `html_url: https://sigco3111.github.io/game-assets-pool/` 와 `pending_domain_unverified_at: null` 확인. 후속 `gh run list --workflow=pages.yml --limit 1` 가 `success`로 바뀜.

### 2순위 장애: PyYAML 미설치

**증상**: `actions/setup-python@v5` 직후 `import yaml` ModuleNotFoundError.

**수정**: `.github/workflows/pages.yml` build 잡에

```yaml
- name: Install PyYAML
  run: pip install pyyaml
```

### 디버그 단축키

```bash
gh run list --workflow=pages.yml --limit 5
gh run view <run-id> --log-failed | tail -50
```

---

## 2. Vercel 카드형 카탈로그

### 자동화 흐름

```
bash vercel-catalog/scripts/copy_thumbnails.sh
  → python3 vercel-catalog/scripts/build_cards.py
  → vercel deploy --token $TOK --yes --prod
```

### 2.1. 토큰 위치

`~/.hermes/secrets/vercel_token.txt`
- `vcp_` prefix + 32 chars (예: `vcp_3mGHlza6HjUd4xA1...`)
- `chmod 600` 권장
- `vercel whoami --token "$(cat ~/.hermes/secrets/vercel_token.txt)"` 로 인증 검증

### 2.2. 디렉터리 구조

```
game-assets-pool/
├── vercel-catalog/
│   ├── vercel.json               # {"outputDirectory": "public"} 명시
│   ├── public/
│   │   ├── index.html            # 카드형 SPA (단일 HTML + JS)
│   │   ├── data/cards.json       # 자동 빌드된 카드 데이터
│   │   └── thumbnails/{kaykit,nieobie,others,phaser}/
│   └── scripts/{copy_thumbnails.sh,build_cards.py,local_preview.sh}
```

### 2.3. vercel.json — 가장 중요한 파일

```json
{
  "$schema": "https://openapi.ver.sh/vercel.json",
  "version": 2,
  "name": "game-assets-pool-catalog",
  "outputDirectory": "public"
}
```

**CRITICAL**: `outputDirectory` 의 자동 룰은 `output: public if exists, else .`. 우리처럼 `vercel-catalog/` 안에 `public/` 과 root의 `vercel.json` 모두 있는 경우, **`outputDirectory` 생략 시 Vercel 이 Next.js로 감지해 빈 `_next/` 페이지로 빌드**할 수 있다. **반드시 `outputDirectory: "public"` 명시**.

### 2.4. 첫 deploy 절차

```bash
TOK=$(cat ~/.hermes/secrets/vercel_token.txt)

cd ~/work/game-assets-pool
bash vercel-catalog/scripts/copy_thumbnails.sh
python3 vercel-catalog/scripts/build_cards.py

cd vercel-catalog
vercel deploy --token "$TOK" --yes --prod
# → https://<name>-<hash>-sigco3111s-projects.vercel.app (즉시)
# → https://game-assets-pool-catalog.vercel.app (1-3분 alias 전파)
```

### 2.5. URL 검증

```bash
# hash URL은 즉시 200
curl -fsLI "https://game-assets-pool-catalog-<hash>-sigco3111s-projects.vercel.app/" \
  -o /dev/null -w "HTTP %{http_code}\n"

# alias URL은 1-3분 후 200
sleep 180
curl -fsLI "https://game-assets-pool-catalog.vercel.app/" \
  -o /dev/null -w "HTTP %{http_code}\n"
```

### 2.6. 흔한 장애 패턴

| 증상 | 원인 | 수정 |
|---|---|---|
| `Output Directory` 비었음 | `outputDirectory` 미명시 | `vercel.json` 에 `"outputDirectory": "public"` 추가 |
| 메인 `/` 만 200, `/data/cards.json` 404 | Vercel이 root `index.html`만 deploy, `public/` 무시 | 모든 정적 파일을 `public/` 안에 두기 |
| alias URL이 404 | 첫 deploy 직후 1-3분 alias 전파 안 됨 | hash URL 로 검증, 5분 후 alias 재시도 |
| 데이터 fetch 시 SSO 302 redirect | `vercel.com/sso-api?url=` 미들웨어 | 브라우저에서 우리 origin fetch 시 SSO 안 걸림 (curl 직접 fetch 안 됨) |
| `vercel deploy` 6분+ 멈춤 | 빌드 컨테이너 large zip 처리 중 | 재실행 또는 `--force` |
| `name` deprecation 경고 | 2026년 정책 변경 | 경고만 — deploy 작동 |

### 2.7. cards.json 구조

```json
{
  "stats": {
    "total": 188,
    "with_thumbnail": 14,
    "auto_packs": 20
  },
  "assets": [
    {
      "id": "kaykit-character-pack-adventurers-1-0",
      "title": "KayKit Character Pack: Adventurers 1.0",
      "category": "3D 캐릭터",
      "license": "CC0-1.0",
      "thumbnail": "/thumbnails/kaykit/adventurers.png",
      "description": "...",
      "url": "https://github.com/...",
      "tags": ["KayKit"],
      "size_mb": 24,
      "available": true
    }
  ],
  "links": []
}
```

`build_cards.py` 의 `THUMB_MAP` dict 가 asset title 키워드 → thumbnail 매핑. 새 팩 추가 시 5줄 패턴 등록.

### 2.8. 카드 UI 기능

- 24 카드/페이지 페이지네이션
- 검색 (제목 + description + 태그)
- 카테고리 / 라이선스 / 썸네일-only 필터
- 라이선스 배지 (🌐 CC0 / ©️ CC-BY / ©️ CC-BY-SA / 🄯 GPL / ❓ UNKNOWN)
- 카테고리 아이콘 (🧙 캐릭터 / 🧱 타일 / 📦 오브젝트 / 🎨 PBR / 🧊 Voxel 등)
- 외부 원본 "소스 보기 ↗"

### 2.9. 자동 thumbnail 추출 로직

`copy_thumbnails.sh` 핵심:

```bash
img_src=$(find "$WORK/free/$rel_path" -maxdepth 5 -type f \
  \( -name "*.png" -o -name "*.svg" \) -size +1k 2>/dev/null | sort | head -1)
```

**왜 hardcoded path 안 쓰는가**: README 가 정확한 경로를 알려주지만 ZIP 받은 후엔 깊이가 다를 수 있음 (`KayKit-Character-Pack-Adventures-1.0-main/addons/kaykit_character_pack_adventures/Textures/rogue_texture.png` 처럼). **find+head가 가장 견고**.

**head -1 함정**: 라이선스/저작자 정보 같은 작은 metadata PNG 만 잡힐 수 있어. **size +1k 이상으로 필터링** 권장.

### 2.10. 카탈로그 카드 cap 결정

| 사이트 | cap | 이유 |
|---|---|---|
| GitHub Pages | records[:3000] | 100GB/월 bandwidth limit + 페이지 속도 |
| Vercel | records[:9000] | bandwidth limit 느슨함, 1.7MB JSON 임베드 OK |
| 둘 다 | records[:3000]+ | lazy JSON fetch 가 다음 단계 |

---

## 3. 두 사이트 운영 단축키

```bash
cd ~/work/game-assets-pool
python3 tools/build-index.py && \
python3 tools/build-site.py && \
python3 vercel-catalog/scripts/build_cards.py && \
TOK=$(cat ~/.hermes/secrets/vercel_token.txt); cd vercel-catalog && \
vercel deploy --token "$TOK" --yes --prod && \
cd .. && git add . && git commit -m "..." && git push
```

이 한 라인으로:
1. INDEX 갱신
2. GitHub Pages 사이트 빌드
3. Vercel 카드 데이터 빌드
4. Vercel prod deploy
5. GitHub commit + push (Pages 워크플로 트리거)
