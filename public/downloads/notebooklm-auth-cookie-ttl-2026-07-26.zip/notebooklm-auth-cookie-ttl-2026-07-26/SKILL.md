---
name: notebooklm-auth-cookie-ttl-2026-07-26
description: "NotebookLM 인증 만료 진단 — storage_state 9KB+인데도 list/create가 Auth 에러 → 풀 OAuth 재로그인 필요 (5분). 기존 0-byte/Workspace-residual 케이스 보완. Playwright --browser chrome."
version: 1.0.0
metadata:
  updated: 2026-07-26
---

# NotebookLM 인증 — TTL 빠짐 & 풀 OAuth 재로그인 (2026-07-26)

> 작성: 2026-07-26 (NotebookLM YouTube 자동화 8/8 업로드 세션)
> **핵심 발견**: rookiepy로 갱신한 쿠키는 **수십 초~수 분 단위로 만료** → 풀 OAuth (`notebooklm login`) 만 안정적

---

## ⚠️ 증상

`notebooklm list --json` 또는 `notebooklm create` 호출 시:

```
Unexpected error: Authentication expired or invalid.
Redirected to: https://accounts.google.com/<redacted>
Run 'notebooklm login' to re-authenticate.
```

근데 `storage_state.json` 안의 SID 쿠키는 `expires_unix` 기준 **수 일 남아있음** (e.g. 2026-08-09).

→ 쿠키가 valid여도 **NotebookLM 페이지 접근 시점에 CSRF 토큰 (`SNlM0e`) 이나 session ID (`FdrFJe`)를 받지 못하고** `accounts.google.com`으로 리다이렉트됨.

---

## 🔸 진단 (30초)

```bash
# 1. storage_state.json 크기 (정상 케이스: 9KB+)
ls -la ~/.notebooklm/profiles/default/storage_state.json

# 2. SID 쿠키 도메인 (정상: .google.com only)
python3 -c "
import json
d = json.load(open('/Users/mac/.notebooklm/profiles/default/storage_state.json'))
for c in d.get('cookies', []):
    if c['name'] == 'SID':
        print('SID domain:', c['domain'])
"

# 3. notebooklm list 시도
source ~/.hermes/venv-notebooklm/bin/activate
notebooklm list 2>&1 | head -3
```

**케이스 분류** (기존 `notebooklm-workspace-cookie-removal-2026-07-12.md` 보완):

| 케이스 | storage_state.json | SID 도메인 | 해결 |
|--------|-------------------|-----------|------|
| 풀 OAuth 만료 | 0 bytes | ❌ 없음 | 풀 OAuth 재로그인 (5분) |
| Workspace 쿠키 잔재 | 12KB+ | `.google.com` + `.google.co.kr` | `.google.co.kr` 쿠키 1줄 제거 (10초) |
| **이번 케이스 (JWT/세션 토큰 만료)** | 9KB+ | `.google.com` only | **풀 OAuth 재로그인 (5분)** |

---

## 🔸 해결 — 풀 OAuth (`notebooklm login --browser chrome`)

```bash
# 1단계: rookiepy 시도 (5초, 99% 실패하지만 가벼움)
source ~/.hermes/venv-notebooklm/bin/activate
notebooklm login --browser-cookies chrome 2>&1 | tail -10
# → "Cookies verified successfully" 나와도 곧 만료됨

# 2단계: 풀 OAuth (5분, 진짜 안정)
# 터미널에서 (background=true 필수 — Chromium 창이 사용자에게 떠야 함)
```

백그라운드 호출:
```bash
terminal(
  background=true,
  command="bash -c 'source ~/.hermes/venv-notebooklm/bin/activate && notebooklm login --browser chrome 2>&1 | tee /tmp/notebooklm_login.log; echo EXIT=$?'"
)
```

**Chromium 창에 consumer Gmail 계정으로 로그인** → 자동 저장 → 
```
Profile: default
Opening Google Chrome for Google login...
Using persistent profile: /Users/mac/.notebooklm/profiles/default/browser_profile
Already logged in.
Identifying Google account...
Account: hjshin@ubob.com

Authentication saved to: ...
EXIT=0
```

**주의**: 5분 안에 완료. 그 이후엔 다시 만료 시작.

---

## 🔸 검증

```bash
source ~/.hermes/venv-notebooklm/bin/activate
notebooklm create "TEST nb" 2>&1 | head -3
# → UUID 나오면 OK
```

---

## 📋 빠른 결정 트리

```
준비/업로드 → Auth 에러
  ↓
storage_state.json 0B? → 풀 OAuth (5분)
  ↓ 아니오
SID = .google.com only? → 풀 OAuth (5분) ← ★ 이번 케이스
  ↓ 아니오 (.google.co.kr 있음)
.google.co.kr 쿠키 1줄 제거 (10초)
```

---

## 💡 다른 메모

- **`storage_state.json` 날짜/owner 표기**: 정상 9KB+ → 풀 OAuth 가 답
- **rookiepy (`--browser-cookies chrome`)**: 쿠키는 추출되지만 NotebookLM이 추가 검증(쿠키-OAuth 토큰 페어링?)에서 fail. 짧은 시간만 동작
- **백업 정책**: `storage_state.json` 덮어쓰기 전 `cp ~/.notebooklm/profiles/default/storage_state.json ~/.notebooklm/profiles/default/storage_state.json.bak.$(date +%s)` 권장

---

## 🔗 관련 reference

- `~/.hermes/skills/automation/notebooklm-youtube-automation/references/notebooklm-workspace-cookie-removal-2026-07-12.md` — Workspace 잔재 케이스 (10초 해결)
- `~/.hermes/skills/automation/notebooklm-youtube-automation/references/notebooklm-relogin-2026-06-16.md` — 풀 OAuth 절차 (5분)
- `~/.hermes/skills/automation/notebooklm-youtube-automation/references/notebooklm-upstream-diagnostics-matrix-2026-07-12.md` — 전체 진단 매트릭스
