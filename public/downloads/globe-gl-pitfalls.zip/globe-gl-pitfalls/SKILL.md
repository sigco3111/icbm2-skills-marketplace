---
name: globe-gl-pitfalls
description: react-globe.gl/three-globe 글로브의 흔들림, 42K 포인트 버벡임, 클릭 패턴.
last_updated: 2026-08-03
status: battle-tested
version: 1.0
metadata:
  hermes:
    tags: [globe, three-js, react-globe-gl, 3d, webgl, performance]
    related_skills: [pixijs-v8-pitfalls, idea-bank-sync, python-oss-bootstrap]
---

# Globe.gl Pitfalls

Globe.gl / react-globe.gl / three-globe 기반 3D 글로브 프로젝트의 class-level 함정 모음. **sigco3111/deep-ocean** (NOAA ETOPO1 42,615 포인트 시각화 + Wikipedia feature 인터랙션)에서 4번 핫픽스(v0.1.0 → v0.2.3)로 실측 검증.

## 트리거 키워드
react-globe.gl, three-globe, Globe.gl, htmlElementsData, onGlobeClick, 글로브 흔들림, 가로 스크롤, 42K 포인트 버벡임, fps 저하, 3D 글로브 신규 프로젝트, sigco3111 idea-bank 3D_Globe(49개) 또는 deckGL_Game(25개) 카테고리 작업.

## 사용 시기
- Globe.gl 프로젝트의 흔들림 / 스크롤 / viewport 초과 증상
- 10K+ 포인트 성능 최적화
- DOM 핀 vs WebGL 드래그 충돌
- Globe.gl 클릭 인터랙션 설계

## 함정 1 — `width/height` JS prop이 매 프레임 reflow 유발 (★★★ 가장 빈번)

Globe.gl은 `width` / `height` prop이 바뀌면 canvas를 **destroy + recreate**함. `window.innerWidth` JS prop을 넘기면 자동 회전 인터벌(30ms)이 돌 때마다 미세 reflow → "좌우 흔들림" 증상 발생.

**증상**:
- 페이지 좌우가 살짝 흔들림
- 카메라가 자동으로 살짝 흔들리는 듯한 느낌

**원인**:
```jsx
<Globe
  width={window.innerWidth}      // ← 30ms마다 변경 가능
  height={window.innerHeight}
  ...
/>
```

**해결 — JS prop 제거, CSS로 처리**:
```jsx
<Globe ... />  {/* width/height prop 완전 제거 */ }
```
```css
#root canvas {
  display: block;
  width: 100vw !important;
  height: 100vh !important;
  position: absolute !important;
  top: 0 !important;
  left: 0 !important;
}
```

## 함정 2 — `htmlElementsData`로 DOM 핀 만들면 드래그와 충돌 (★★★ 가장 빈번)

Globe.gl의 `htmlElementsData`는 N개 DOM element를 globe surface 위에 띄움. 마우스가 그 element 위로 가면 Globe.gl의 drag-rotate가 가로채서 **element가 끌려가는 듯한 흔들림** + 가로 스크롤 발생.

**증상**:
- 글로브 좌우로 흔들림
- 가로 스크롤 발생
- 핀 클릭이 부정확 (드래그와 충돌)

**원인**:
```jsx
htmlElementsData={features}        // ← 90개 DOM element
htmlElement={(d) => {
  const el = document.createElement('div');
  el.innerText = '🌋';
  el.onclick = () => handleClick(d);  // ← 드래그와 충돌
  return el;
}}
```

**해결 — `onGlobeClick` + nearest feature 계산**:
```jsx
// DOM 핀 완전 제거 → WebGL ring/pulse로만 시각화
<Globe
  ringsData={features.map(f => ({ lat: f.lat, lng: f.lon, ... }))}
  // 글로브 자체 클릭 핸들러 (DOM overlay 없음)
  onGlobeClick={({ lat, lng }) => {
    let best = null, bestDist = Infinity;
    for (const f of features) {
      const d = Math.hypot(f.lat - lat, f.lon - lng);
      if (d < bestDist) { bestDist = d; best = f; }
    }
    if (best && bestDist < 5) handleClick(best);  // 5° 반경
  }}
/>
```

## 함정 3 — body overflow + position 미고정 → 가로/세로 스크롤

Globe.gl canvas는 inline style로 `position: absolute; top: 0; left: 0`을 박는데, body에 `overflow: hidden`이 없으면 canvas가 살짝 viewport 밖으로 나가서 **가로 스크롤 발생**. macOS 트랙패드의 rubber-band scroll도 발생.

**해결**:
```css
html, body {
  margin: 0; padding: 0;
  width: 100%; height: 100%;
  background: #000;
  overflow: hidden;       /* 가로/세로 스크롤 완전 차단 */
  overscroll-behavior: none;  /* rubber-band 스크롤 방지 */
  touch-action: none;     /* 모바일 핀치/스크롤 방지 */
}

#root {
  position: fixed;        /* viewport에 완전 고정 */
  top: 0; left: 0;
  overflow: hidden;
}
```

## 함정 4 — 10K+ 포인트 전체 렌더링 시 PC 버벡임

ETOPO1처럼 42,615개 같은 점 데이터 전체를 매 프레임 렌더링하면 GPU/CPU 부하 폭증. 카메라가 보이는 영역과 무관하게 모든 점이 처리됨.

**증상**:
- 회전 시 FPS 5\~10 (매우 끊김)
- PC 팬 소음 증가
- zoom in/out 시 응답 없음

**해결 패턴 — viewport-based 5° grid + throttle**:

```js
const GRID_SIZE = 5;
const VIEWPORT_OVERSCAN = 1.6;
const CAMERA_UPDATE_MS = 120;

function gridKey(lat, lon) {
  return `${Math.floor((lat + 90) / GRID_SIZE)}:${Math.floor((lon + 180) / GRID_SIZE)}`;
}

function buildOceanGrid(points) {
  const grid = new Map();
  for (const p of points) {
    const key = gridKey(p.lat, p.lon);
    const cell = grid.get(key);
    if (cell) cell.push(p);
    else grid.set(key, [p]);
  }
  return grid;
}

// O(가시 셀 수)로 lookup — O(N) 아님
function visibleOceanPoints(grid, view) {
  const latSpan = Math.min(180, Math.max(8, view.altitude * 28)) * VIEWPORT_OVERSCAN;
  const lngSpan = Math.min(360, Math.max(8, view.altitude * 28)) * VIEWPORT_OVERSCAN;
  const points = [];
  for (let lat = Math.floor((minLat + 90) / GRID_SIZE); lat <= Math.floor((maxLat + 90) / GRID_SIZE); lat += 1) {
    for (let lng = Math.floor((minLng + 180) / GRID_SIZE); lng <= Math.floor((maxLng + 180) / GRID_SIZE); lng += 1) {
      const cell = grid.get(`${lat}:${((lng % 72) + 72) % 72}`);
      if (cell) points.push(...cell);
    }
  }
  return points;
}

// React: useMemo로 grid 1회 빌드, throttle로 120ms마다 visiblePoints 갱신
function Component() {
  const oceanGrid = useMemo(() => buildOceanGrid(oceanPoints), [oceanPoints]);

  useEffect(() => {
    let timeoutId;
    const updateVisiblePoints = () => {
      timeoutId = undefined;
      if (!globeEl.current || !oceanPoints.length) return;
      setVisiblePoints(visibleOceanPoints(oceanGrid, globeEl.current.pointOfView()));
    };
    const scheduleUpdate = () => {
      if (timeoutId === undefined) timeoutId = setTimeout(updateVisiblePoints, CAMERA_UPDATE_MS);
    };
    updateVisiblePoints();
    window.addEventListener('resize', scheduleUpdate);
    const id = setInterval(scheduleUpdate, CAMERA_UPDATE_MS);
    return () => {
      if (timeoutId !== undefined) clearTimeout(timeoutId);
      clearInterval(id);
      window.removeEventListener('resize', scheduleUpdate);
    };
  }, [oceanGrid, oceanPoints.length]);
}
```

**예상 효과**:
- 줌인 시 ~500\~1,500개만 렌더링 (1\~3° 스팬)
- 줌아웃 시 ~10,000\~20,000개 (전체 윤곽)
- 60fps 유지

**진화 패턴 (함정 4 v1 → v2)**:

| 버전 | 패턴 | 비용 |
|------|------|------|
| v0.2.2 | `points.filter()` 매번 O(N) linear scan | 42K × 100ms = 420K ops/sec |
| v0.2.3 | 5° grid Map lookup + throttle | 가시 셀 수만 (~10\~200개 셀) |

## 함정 5 — Globe.gl `onGlobeClick`은 가장 가까운 feature 자동 선택이 아님

`onGlobeClick`은 클릭한 좌표만 반환. 사용자가 "이 핀을 클릭"한 게 아니라 "이 좌표 부근을 클릭"한 거라서, **threshold로 가장 가까운 feature를 선택해야 함**.

**해결 패턴**:
```js
onGlobeClick={({ lat, lng }) => {
  let best = null, bestDist = Infinity;
  for (const f of features) {
    const d = Math.hypot(f.lat - lat, f.lon - lng);
    if (d < bestDist) { bestDist = d; best = f; }
  }
  if (best && bestDist < 5) handleClick(best);  // 5° 반경 내만
}}
```

거리 threshold는 카메라 altitude 따라 동적 조정 가능:
```js
const threshold = Math.min(10, view.altitude * 5);
```

## 함정 6 — Globe.gl `backgroundColor`는 페이지 배경을 덮음

`backgroundColor="#000"` 지정 시 globe canvas 영역 전체가 검정 → 페이지 CSS의 radial-gradient 등이 보이지 않음.

**해결**:
```jsx
<Globe backgroundColor="rgba(0,0,0,0)" />  {/* 투명 */ }
```
```css
#root {
  background: radial-gradient(ellipse at center, #001a2e 0%, #000000 80%);
}
```

## 누적 통계

| 지표 | 값 |
|------|-----|
| 검증된 함정 | 6개 |
| 검증 프로젝트 | sigco3111/deep-ocean (4.8MB NOAA ETOPO1, 42,615 points) |
| 해소된 증상 | 흔들림, 스크롤, 버벡임, 클릭 부정확, UI 가려짐 |
| 핫픽스 횟수 | 4회 (v0.1.0 → v0.1.1 → v0.2.1 → v0.2.2 → v0.2.3) |

## 빠른 진단 체크리스트

Globe.gl 프로젝트에서 다음 증상 중 하나라도 보이면:

| 증상 | 진단 | 함정 |
|------|------|------|
| 페이지 좌우 흔들림 | width/height JS prop + body overflow | 1 + 3 |
| 가로 스크롤 발생 | body에 `overflow: hidden` 없음 | 3 |
| DOM 핀 클릭 부정확 + 흔들림 | htmlElementsData 사용 | 2 |
| PC 버벡임 (FPS 5\~10) | 10K+ points 전체 렌더링 | 4 |
| 핀 클릭해도 반응 없음 | htmlElementsData vs onGlobeClick 혼용 | 2 + 5 |
| CSS 배경 gradient 안 보임 | backgroundColor="#000" 사용 | 6 |

## 연결된 스킬

- `idea-bank-sync` — 14개 카테고리 중 **3D 글로브 49개** + **deck.gl 게임 25개** = 신규 프로젝트 발굴 시 참고. 본 함정들은 즉시 적용 가능.
- `pixijs-v8-pitfalls` — PixiJS 게임 vs Globe.gl 글로브는 다른 라이브러리지만 **DOM overlay hit testing 패턴**은 유사. PixiJS v8의 `eventMode='static' + hitArea` 명시 패턴이 Globe.gl의 DOM 충돌 회피 사례로 교훈 공유.
- `python-oss-bootstrap` — nbody-html-scaffold-case 참조. 단일 HTML Globe.gl 프로젝트 배포 패턴.

## 검증된 인스턴스

- **2026-08-03**: sigco3111/deep-ocean 프로젝트에서 6개 함정 모두 실측
  - 흔들림/스크롤 (함정 1+2+3) → v0.2.1에서 일괄 해결
  - 42K 포인트 버벡임 (함정 4) → v0.2.2 → v0.2.3에서 2단계 최적화
  - 클릭 인터랙션 (함정 5) → v0.2.1에서 `onGlobeClick` 전환
  - 배경 가려짐 (함정 6) → v0.1.1에서 `backgroundColor="rgba(0,0,0,0)"` + radial-gradient
  - 최종 v0.2.3에서 사용자 만족

## 다음 활용 예정

- sigco3111 idea-bank 카테고리:
  - **3D_Globe_Project_Ideas** (49개 중 미구현 16개) — sky-radar, migration-globe, lang-globe 등
  - **deckGL_Game_Project_Ideas** (25개) — 헥사곤 정복자, 도주 추격전 등
  - **deckGL_Project_Ideas** (25개) — 글로벌 항공편, 산불 등
- 본 함정들 (특히 1+2+3 + 4 viewport clipping)은 **모든 Globe.gl 신규 프로젝트에 즉시 적용 가능**
