---
name: oss-fork-localization
description: "기존 OSS 프로젝트 fork + 한국어 환경 최적화 + 외부 LLM 백엔드 교체 + **크로스 플랫폼 배포** 클래스 워크플로우. Apache 2.0 §4(a) + MODIFIED.md + 6단계 빌드 환경 분류 + 모드팩 패턴 + LÖVE/Lua T() 함수 + UTF-8 byte iteration 함정 + Steamworks shim + CJK 폰트 + luac -p 검증 + **LÖVE 게임 .app/zip/tar.gz 배포 + GitHub Releases (gh workflow scope 우회)** + macOS Contents/Frameworks/* 10개 footgun + unzip -o prompt footgun. 'fork해서 한글화', 'LÖVE 게임 한글화', '누구나 쉽게 접근 가능하도록 배포' 요청에 발동. 4 사례 검증 (generative_agents-kr, wesnoth-kr, sango-rising-dragons-kr, snkrx-clone v0.1.14 + GitHub Release v0.1.12)."
version: 1.17.0
author: HyeRin (MiniMax)
license: MIT
metadata:
  hermes:
    tags: [oss, fork, korean, localization, llm-backend, nim, embedding, apache-2-0, josa, negation-guard, asymmetric, django-ui, e2e-verification, zsh-quoting, delegation, django-4-migration, pythonpath-hermes, cplusplus, game-engine, gettext, po-file, wesnoth, sparse-checkout, auto-progression, v4a-patch, pref-getter-setter, 1-18-pthread, linux-ci-only, multiline-state-machine, macos-m4-build, preflight-check, cjk-search, sangokushi, three-kingdoms, lua, love2d, utf-8-byte-iteration, cjk-font-fallback, macos-retina-fullscreen, steamworks-shim, type-guard, patch-fuzzy-collision, gatekeeper-quarantine, headless-process-verification]
    related_skills: [oss-python-bootstrap, github-profile-readme, github-repo-management, ad-hoc-verifier, legacy-repo-modernization]
---

# OSS Fork + 한글화 + LLM 백엔드 교체 워크플로우

> 기존 오픈소스 프로젝트(논문 기반, 인기 OSS 등)를 fork해서 **한국어 환경에 맞게 최적화**하면서 **외부 LLM 백엔드를 교체**(OpenAI → 사설 호스팅)할 때 사용하는 클래스 워크플로우.

## 언제 사용하나

| 사용자 요청 | 트리거 |
|------------|--------|
| "이 OSS 한글화하고 한국 시나리오 추가해줘" | ✓ |
| "이거 fork해서 한국어 UI/페르소나/프롬프트 작업" | ✓ |
| "LLM 백엔드 OpenAI → NIM/Ollama/vLLM 으로 교체" | ✓ |
| "한국어 임베딩 검색 정확도 검증해줘" | ✓ |
| "Stanford generative_agents 같은 거 fork 가자" | ✓ |
| "이 프로젝트 한국어 커뮤니티용 배포판 만들고 싶어" | ✓ |
| "이 게임 한글화하고 싶어" / "Wesnoth/OpenDiablo2/OpenRA 한글화" | ✓ (game-engine sub-class) |
| "이 게임에 자동진행 기능 추가하고 싶어" | ✓ (auto-progression feature add) |
| "삼국지/코에이風 게임 찾아줘" | ✓ (CJK 게임 검색) |
| **"이 게임 빌드해서 실행까지 해줘"** | ⚠️ **사전 검증 필수** (macOS C++ = 90분+ 낭비 가능) |

## ⭐ 90분 투자 회수 — 빌드 환경 사전 검증 (CRITICAL, 2026-07-20)

사용자가 "이 게임 빌드해서 실행까지 해줘" 같은 요청을 하면 **5분 사전 확인**이 우선.

**왜?** wesnoth-kr 2026-07-20에서 사용자가 정리 요청한 계기:
- Boost 1.90 + modern clang의 `static_visitor` 비호환
- 1.18 + pthread Apple Clang 한계
- Boost 1.83 별도 빌드 → rpath + headerpad_max_install_names 부족
- 총 90분 투자 후 사용자가 "내 기대와 다르네" + 정리 요청

**해결**: C++ 게임 엔진 fork 시 **5분 사전 검증** → 가능/보류/대체 결정.

→ 자세한 5단계 검증 + 사용자 의사결정 가이드: `references/build-environment-preflight-check.md`

**즉시 적용 패턴**:
- 사용자가 "빌드까지/실행까지" → `references/build-environment-preflight-check.md` §사용자 의사결정 가이드 3가지 질문 (빌드 환경/실행 환경/검증 깊이)
- 위임 신호 → 4-옵션 응답 금지, 단일 권장 옵션 제시 (§14)
- Linux/macOS CI 정답 → GitHub Actions `macos-15` runner (5분 셋업, 5배 확실)

### "Linux CI로 빌드해도 맥에서 사용가능한가?" — 명백한 오류 (2026-07-20 사용자 정정)

사용자가 "GitHub Actions로 빌드" 옵션을 선택하려 할 때 **절대 하지 말 것**: "Linux CI 빌드로 macOS 바이너리 받기" 같은 답.

**진실 (사용자 정정 후 학습)**:
- **Linux x86_64 빌드 → macOS에서 실행 불가능**. Mach-O vs ELF 호환 불가.
- macOS arm64 네이티브 바이너리는 **반드시 macOS 환경**에서 빌드해야 함
- **GitHub Actions `macos-14`/`macos-15` runner** 사용해야 함 (M1/M2/M4 arm64 네이티브)
- macos-15 runner = Apple Silicon M4, 무료, artifact 다운로드 → M4에서 바로 실행

**GitHub Actions runner 옵션 정리**:

| Runner | OS | 아키텍처 | 비용 (퍼블릭) | 용도 |
|---|---|---|---|---|
| `ubuntu-22.04` | Linux | x86_64 | 무료 | CI sanity check (코드 컴파일 검증) |
| `macos-13` | macOS | arm64 | 무료 | M1 네이티브 빌드 (M2/M4 호환) |
| `macos-14` | macOS | arm64 | 무료 | M2 네이티브 빌드 (M4 호환) |
| `macos-15` | macOS | arm64 | 무료 | M4 네이티브 빌드 (**사용자 M4와 동일**) |

**올바른 추천** (사용자 M4 환경):
```yaml
jobs:
  build:
    runs-on: macos-15  # Apple Silicon M4 네이티브
    steps:
      - uses: actions/checkout@v4
      - name: Install deps
        run: brew install sdl2 ...
      - name: Build
        run: scons build=release
      - name: Upload artifact
        uses: actions/upload-artifact@v4
        with:
          name: wesnoth-mac-m4
```

→ artifact 다운로드 → M4에서 `./wesnoth` 직접 실행 가능. **5분이면 셋업, 90분 로컬 빌드 시도 대비 5배+ 확실**.

**자주 하는 착각 패턴**:
- ❌ "Linux에서 빌드한 .so/.dylib는 어디서든 실행 가능" — **아님**, Mach-O는 macOS 전용
- ❌ "Cross-compile로 Mac 바이너리 만들 수 있음" — Apple은 공식 cross-compile 미허용 (실용적으로)
- ❌ "Docker로 Mac 빌드" — Docker는 macOS 게스트 지원 안 함
- ✅ "GitHub Actions macos-15 runner = M4 네이티브" — 이게 정답

## ⭐ 성공 사례: sango-rising-dragons 한국어화 (2026-07-20, NEW)

Wesnoth 90분 낭비 직후 사용자가 "일단 가져와서 한글화를 진행한 후 실행해보자" → **ryantsai/sango-rising-dragons**로 전환 → **6시간 만에 macOS 빌드 + 한글화 + GitHub 푸시 + 게임 플레이 검증까지 성공**.

**왜 성공했나 (Wesnoth 실패 대비)**:
1. **언어**: TypeScript/Phaser 3 → macOS 네이티브 빌드 환경 함정 0
2. **빌드 시스템**: `npm install` 2초, `npm run dev` 즉시 HTTP 200
3. **데이터 구조**: `public/data/{pack}/*.json` 모드팩 시스템 → 원본 건드리지 않고 한국어 오버레이
4. **UI vs 데이터 분리**: TS는 1,978 LOC로 모듈화, 데이터는 JSON
5. **빌드 도구**: Vite 6 + TypeScript 5 (현대 스택) → 5분 셋업

**워크플로 (성공 패턴)**:
```
1. [5분] macOS 빌드 검증: npm install + npm run dev
2. [10분] 데이터 분석: 6개 JSON + entry 수 확인
3. [30분] ko/ 모드팩 생성: manifest.json에 packs: ["ko", "base"] 추가
4. [60분] TS UI 한자→한국어 일괄 변환
5. [10분] HTML lang/title/폰트 업데이트
6. [10분] build + Playwright 스크린샷 검증
7. [10분] play.sh 스크립트 (dev/serve/build/open)
8. [20분] README + GitHub push
```

**핵심 패턴 — 5단계 빌드 환경 분류**:

| 분류 | 빌드 도구 | 빌드 시간 | macOS 호환성 | 사례 |
|------|----------|----------|--------------|------|
| 🟢 **즉시 성공** | `npm`/`yarn` (Vite, Next.js) | 2초 | ✅ 네이티브 | sango-rising-dragons (TypeScript) |
| 🟡 **Java/Gradle** | `./gradlew` | 30초~5분 | ✅ 안정 | triplea, FreeCol |
| 🟠 **Rust/cargo** | `cargo build` | 1~5분 | ✅ 안정 | zemeroth, veloren |
| 🔴 **C++ scons/CMake** | `scons`/`make` | 30분~1시간 | ⚠️ 환경 의존 | Wesnoth (Boost/SDL 함정) |
| ⚫ **C#** | `dotnet`/`mono` | 1~5분 | ⚠️ mono 의존 | RTK2020-CORE |

**즉시 적용 규칙**: 사용자가 "한국어화 + 실행" 요청 시 **먼저 빌드 시스템 분류** → 🟢/🟡/🟠이면 진행, 🔴/⚫이면 `references/build-environment-preflight-check.md` 적용.

## ⭐ `play.sh` 실행 스크립트 패턴 (NEW, 2026-07-20)

`./play.sh {dev|serve|build|open}` 4-옵션 표준 스크립트. 게임 fork 시 매번 유용.

**표준 구현**:
```bash
#!/bin/bash
# {game-name} 실행 스크립트 (Mac/Linux)
set -e
cd "$(dirname "$0")"
PORT="${PORT:-8080}"

case "${1:-serve}" in
  dev)    # Vite/Next.js 개발 서버 (HMR)
    npm run dev
    ;;
  serve)  # 정적 빌드 서빙 (가장 안정)
    [ ! -d dist ] && npm run build
    python3 -m http.server "$PORT" --directory dist
    ;;
  build)  # 정적 빌드만
    npm run build
    ;;
  open)   # Safari로 dist/index.html 열기
    [ ! -d dist ] && npm run build
    open "dist/index.html"  # macOS
    # xdg-open "dist/index.html"  # Linux
    ;;
esac
```

**왜 serve가 가장 안정적인가**:
- `file://` 프로토콜에서 `fetch()`가 일부 제한될 수 있음 (게임 데이터 로드 실패)
- `python3 -m http.server`는 Mac/Linux 모두 사용 가능
- port 8080 default, `PORT=3000 ./play.sh serve`로 변경 가능

**사용자 선호 시그널**: "실행은 어떻게 하지?" → "어떤 옵션으로 실행할까요?" 3-옵션 + 추천. `./play.sh serve` (가장 안정) 권장.

## ⭐ GitHub `gh repo create` 원격 origin 실패 함정 (NEW, 2026-07-20)

sango-rising-dragons-kr 푸시 시 발생한 함정.

**증상**:
```bash
$ gh repo create sigco3111/repo --public --description "..." --source=. --remote=origin --push=false
# 출력: https://github.com/sigco3111/repo (성공으로 보임)
# X Unable to add remote "origin"  ← 경고
# git push 시: 404 Not Found
```

**원인**: `--source=.` + `--remote=origin` 조합이 가끔 origin 자동 추가에 실패. `gh`는 저장소 생성은 성공했지만 remote 추가 실패를 **경고만** 출력하고 성공 표시.

**해결 (2단계 검증)**:
```bash
# 1. 저장소 생성
gh repo create sigco3111/repo --public --description "..." --source=. 2>&1 | tail -5

# 2. 즉시 HTTP 검증 (404면 실패)
curl -s -o /dev/null -w "HTTP %{http_code}\n" "https://api.github.com/repos/sigco3111/repo"
# HTTP 200 = OK, 404 = 다시 시도

# 3. remote 강제 설정
git remote remove origin 2>&1 || true
git remote add origin https://github.com/sigco3111/repo.git
git remote -v  # 검증
```

**즉시 적용 규칙**: `gh repo create` 후 **반드시 curl로 200 확인** → 404면 remote 재설정. **절대 출력만 신뢰하지 말 것**.

## ⭐ 모드팩 (data override) 워크플로우 (NEW, 2026-07-20, sango-rising-dragons 핵심 패턴)

**구조**:
```
public/data/
├── manifest.json           # {"packs": ["ko", "base"]}  ← ko 우선
├── base/                   # 원본 (건드리지 않음)
│   ├── cities.json
│   ├── officers.json
│   ├── factions.json
│   └── ...
└── ko/                     # 한국어 모드팩
    ├── cities.json         # 같은 id 필드만 덮어씀
    ├── officers.json
    └── ...
```

**mergeById 로직 (content.ts)**:
```typescript
function mergeById<T extends { id: string }>(base: T[], extra: T[]): T[] {
  const map = new Map(base.map((e) => [e.id, e]));
  for (const e of extra) map.set(e.id, { ...map.get(e.id), ...e });
  return [...map.values()];
}
```

**⚠️ CRITICAL: 모드팩은 base의 모든 필드를 덮어쓸 필요 없음**. `{id, name}` 만 있어도 base의 다른 필드 유지. **단, choices 배열 같은 nested field는 base의 전체 배열을 덮어씀** — base choices 2개 중 ko에 1개만 있으면 ko의 1개만 적용됨.

**실제 버그 사례 (2026-07-20)**: ko/events.json에 `intro`의 choices 1개만 번역 → base의 2번째 choice 사라짐. **해결: 모든 choices를 ko에 복사 후 label만 번역**.

**표준 생성 워크플로**:
```python
import json
from pathlib import Path

base_dir = Path('public/data/base')
ko_dir = Path('public/data/ko')
ko_dir.mkdir(exist_ok=True)

# 각 JSON 파일별로
for fname in ['cities.json', 'officers.json', ...]:
    with open(base_dir / fname) as f:
        base_data = json.load(f)
    
    # ko 버전: id + 번역된 필드만
    ko_data = []
    for item in base_data:
        ko_item = {'id': item['id']}
        for key in TRANSLATABLE_FIELDS[fname]:
            if key in item:
                ko_item[key] = translate(item[key])
        # choices는 배열 통째로 복사 + label만 번역
        if 'choices' in item:
            ko_item['choices'] = [
                {**ch, 'label': translate(ch['label'])} for ch in item['choices']
            ]
        ko_data.append(ko_item)
    
    with open(ko_dir / fname, 'w', encoding='utf-8') as f:
        json.dump(ko_data, f, ensure_ascii=False, indent=2)

# manifest.json 업데이트
with open('public/data/manifest.json') as f:
    manifest = json.load(f)
if 'ko' not in manifest['packs']:
    manifest['packs'] = ['ko'] + manifest['packs']
with open('public/data/manifest.json', 'w') as f:
    json.dump(manifest, f, ensure_ascii=False, indent=2)
```

**장점**:
- 원본 업데이트 시 `git pull upstream`만으로 자동 반영 (id 동일)
- 한국어 패치만 깔끔하게 분리
- 다른 모드팩 추가 가능 (예: 일본어, 베트남어)

## ⭐ mergeById packs 순서 함정 — 가장 중요한 함정 (NEW, 2026-07-20, 발견)

**sango-rising-dragons에서 4번의 빌드-캡처 → 매번 한자 노출 → 막대한 디버깅 시간 낭비 후 발견**.\n\n**원본 mergeById 로직**:
```typescript
function mergeById<T extends { id: string }>(base: T[], extra: T[]): T[] {
  const map = new Map(base.map((e) => [e.id, e]));
  for (const e of extra) map.set(e.id, { ...map.get(e.id), ...e });
  // extra가 base를 덮어씀
}
```

**loadContent의 호출 순서**:
```typescript
for (const pack of manifest.packs) {
  // pack 별로 fetch → content에 mergeById
  content.events = mergeById(content.events, events);
}
```

**WRONG (발견된 버그)** — `manifest.packs: ["ko", "base"]`로 설정 시:
1. `content.events = mergeById([], ko)` = ko (12개)
2. `content.events = mergeById(ko, base)` = **`{...ko_intro, ...base_intro}`** = **base가 덮어씀**

→ 화면에 base 한자 표시. fetch 응답은 200 OK, JSON 파싱 OK, fetch 12개 모두 정상 — **그런데 화면에 한자**. **진단 매우 어려움** (4번 반복 빌드/캡처).

**CORRECT (수정)** — `manifest.packs: ["base", "ko"]`:
1. `content.events = mergeById([], base)` = base (12개)
2. `content.events = mergeById(base, ko)` = **ko가 base를 덮어씀**

→ 화면에 ko 한국어 표시. **올바른 동작**.

**이름/원칙**: **`manifest.packs`는 "덮어쓰기 순서" — **뒤에 있는 pack이 앞의 pack을 덮어씀** (last-wins)**. 한국어 모드팩은 **반드시 마지막**에 와야 함.

**올바른 manifest.json**:
```json
{
  "packs": ["base", "ko"]  // base → ko (ko가 마지막, 가장 우선)
}
```

**잘못된 manifest.json** (겉보기에는 더 자연스러워 보임):
```json
{
  "packs": ["ko", "base"]  // ko → base (base가 마지막, ko를 덮어씀) ❌
}
```

**표준 manifest.json 빌더**:
```python
import json
from pathlib import Path

mf = Path('public/data/manifest.json')
manifest = json.loads(mf.read_text())

# base → ko 순서 보장
if 'ko' not in manifest['packs']:
    manifest['packs'] = ['ko'] + manifest['packs']  # ❌ WRONG: ko 먼저
elif manifest['packs'][0] == 'ko':
    manifest['packs'] = manifest['packs'][1:] + ['ko']  # ✅ CORRECT: ko 마지막

mf.write_text(json.dumps(manifest, ensure_ascii=False, indent=2))
```

**즉시 적용 규칙**:
1. 모드팩 시스템 사용 시 **`manifest.packs` 검증** 첫 단계
2. 사용자 모드팩은 **반드시 마지막**에 배치
3. 새 모드팩 추가 시 `packs: [...기존, "newmod"]` (last-wins)
4. 화면에 한자가 여전히 보이면 **`packs` 순서부터** 확인 (90분 디버깅 회수)

**디버깅 시그널**:
- 데이터 fetch는 200 OK
- JSON 파싱 OK
- 모드팩 디렉토리에 번역된 JSON 존재
- **그런데 화면에 원본 한자** → **`packs` 순서 = `["modpack", "base"]` 버그** 99%

**이름/원칙**: **`manifest.packs`는 "덮어쓰기 순서" — **뒤에 있는 pack이 앞의 pack을 덮어씀** (last-wins)**. 한국어 모드팩은 **반드시 마지막**에 와야 함. `["ko", "base"]`로 쓰면 base가 ko를 덮어씀 → 한자 노출. **`["base", "ko"]`가 정답**.

## ⭐ 모드팩 필드명 컨벤션 일치 — silent NaN 함정 (NEW, 2026-07-20)

**sango-rising-dragons v0.4에서 발견**: 이벤트 데이터의 `effects[].troopsHome` 필드가 base는 `v: 1500`인데 한국어화 시 `amount: 1500`으로 작성됨. `applyEffects` 핸들러는 `e.v`만 읽음 → `undefined` → `home.troops += undefined = NaN`. **일단 NaN 박히면 recruit +1500 = NaN + 1500 = NaN (영구 회복 불가)**.

**진단 신호**:
- 이벤트 모달 선택 직후 도시 병력이 NaN으로 표시
- 이후 모든 recruit이 로그에는 "+1,500" 뜨지만 UI는 NaN 유지
- 콘솔 `__sango.getG().cities['chenliu'].troops` = `NaN`

**근본 규칙 — modpack의 데이터 필드명은 base와 1:1 일치해야 함**:
| base 필드 | 모드팩 필드 | 결과 |
|-----------|------------|------|
| `v` | `v` | OK 정상 |
| `v` | `amount` | FAIL silent fail (코드 핸들러가 `v`만 보면 NaN) |
| 키 자체 추가 (`alias`, `full_name`) | OK | OK (없어도 base 값 유지) |

**방어 코드 (권장)**: 핸들러는 **모든 가능한 필드명 + NaN 가드**:
```typescript
case 'troopsHome': {
  const home = citiesOf(G.playerFaction)[0];
  // 양쪽 컨벤션 + NaN 가드 (modpack 작성자 실수 방어)
  const delta = Number((e as any).v ?? (e as any).amount ?? 0);
  if (home && Number.isFinite(delta) && delta !== 0) {
    home.troops = Math.max(200, home.troops + delta);
  }
  break;
}
```

**모드팩 검증 워크플로 (1분)**:
```python
import json
base = json.load(open('public/data/base/events.json'))
ko = {e['id']: e for e in json.load(open('public/data/ko/events.json'))}
for ev in base:
    for i, ch in enumerate(ev.get('choices', [])):
        for j, eff in enumerate(ch.get('effects', [])):
            base_keys = set(eff.keys())
            ko_eff = ko.get(ev['id'], {}).get('choices', [{}]*99)[i].get('effects', [{}]*99)[j]
            ko_keys = set(ko_eff.keys())
            missing = base_keys - ko_keys
            if missing: print(f'  FAIL {ev["id"]}/{i}/{j}: missing {missing}')
# missing 없으면 안전
```

**즉시 적용 규칙**:
1. 모드팩 작성 시 **`base/*.json`의 모든 필드명을 그대로 복사** 후 번역할 필드만 덮어쓰기
2. **`v`/`amount`/`value` 등 컨벤션 혼용 금지** — base와 통일
3. 핸들러 작성 시 **여러 후보 필드 + NaN/finite 가드**
4. save/load 직전 **`Number.isFinite()` sanitize** — NaN 세이브가 있으면 자동 복구

## ⭐ 세이브 데이터 NaN 자동 복구 (`sanitizeGameState`, 2026-07-20, NEW)

modpack 데이터 NaN → 사용자 세이브에 영구 박힘 → 새 빌드 배포 후에도 `loadGame()`으로 그대로 복원되어 게임 영구 손상. **방어선 3개**:

**1단계 — sanitize on load (필수)**:
```typescript
function sanitizeGameState(g: any): void {
  const safe = (v: any, fallback = 0) => Number.isFinite(Number(v)) ? Number(v) : fallback;
  g.gold = safe(g.gold, 0);
  g.food = safe(g.food, 0);
  if (g.cities) for (const id of Object.keys(g.cities)) {
    const c = g.cities[id];
    c.troops = safe(c.troops, 1000);  // NaN troops → 안전한 기본값
  }
}
export function loadGame(): boolean {
  G = JSON.parse(raw);
  sanitizeGameState(G);  // 항상 호출
  return true;
}
```

**2단계 — 진단 훅 (선택)**:
```typescript
const corrupted = Object.values(G.cities || {}).filter((c: any) => !Number.isFinite(c?.troops)).length;
if (corrupted > 0) (window as any).__sangoSaveHeal = { fixedCities: corrupted, when: new Date().toISOString() };
```

**3단계 — 디버그 로그 강화 (선택)**: 효과 적용 전후로 `before`/`after` 값 콘솔에 박기 → silent NaN 즉시 발견.

**실전 패턴 (sango-rising-dragons)**: 사용자 콘솔에서 `__sangoSaveHeal.fixedCities` 확인 → 0이면 깨끗, 1 이상이면 자동 복구됨.

## ⭐ `fill_empty.py` v4 multiline + longest prefix match (NEW, 2026-07-20)

PO 파일 채우기 도구. wesnoth-kr에서 v1~v3까지 진화한 버전.

**알고리즘**:
1. PO 파일을 라인별로 파싱 (msgid는 multiline 가능)
2. translations dict에서 msgid 정확 매칭 시도
3. 실패 시 **longest prefix match** (긴 키 우선)
4. 매칭된 msgstr로 빈 msgstr 채우기

**왜 longest prefix**:
- PO 파일의 실제 msgid가 600자 multiline (예: 아랍 이름 리스트)
- translations.json 키는 30자 발취본 (예: "Abiha,Afaf,A’isha,...")
- 정확 매칭 실패 → prefix로 매칭해야 함

**구현 핵심** (Python):
```python
def patch_po_multiline(content: str, translations: dict):
    lines = content.split('\n')
    out_lines = []
    i = 0
    
    while i < len(lines):
        line = lines[i]
        m = re.match(r'msgid\s+"(.*)"', line)
        if m:
            # multiline msgid 수집
            msgid_parts = [m.group(1)]
            j = i + 1
            while j < len(lines):
                next_line = lines[j]
                mm = re.match(r'"(.*)"', next_line)
                if mm and j > i + 1 and not next_line.startswith('msgstr') and not next_line.startswith('msgid '):
                    msgid_parts.append(mm.group(1))
                    j += 1
                elif next_line.startswith('#') or next_line.strip() == '':
                    j += 1
                else:
                    break
            
            # msgstr 다음 줄이 빈 경우 채우기
            if j < len(lines):
                next_line = lines[j]
                ms_match = re.match(r'msgstr\s+"(.*)"', next_line)
                if ms_match and not ms_match.group(1):
                    full_msgid = ''.join(msgid_parts)
                    # longest prefix match
                    best = find_best_match(full_msgid, translations)
                    if best:
                        out_lines.append(f'msgstr "{best}"')
                        filled += 1
                        i = j + 1
                        continue
            
            for k in range(i, j):
                out_lines.append(lines[k])
            i = j
            continue
        
        out_lines.append(line)
        i += 1
    
    return '\n'.join(out_lines), filled
```

**→ 이 도구 본체는 `scripts/fill_empty.py`에 저장됨 (이미 skill에 포함)**.

## ⭐ Wesnoth 교훈 직접 적용 (2026-07-20, 6시간 작업 검증됨)

Wesnoth-kr에서 90분 낭비 → sango-rising-dragons에서 6시간 성공. **순서가 다름**:

| 단계 | Wesnoth-kr (실패) | sango-rising-dragons (성공) |
|------|-------------------|-------------------------------|
| **1. 빌드 시스템 분류** | ❌ 안 함 (C++ scons) | ✅ 먼저 함 (TypeScript Vite) |
| **2. 모드팩 가능성 확인** | ❌ PO gettext 시스템 | ✅ `public/data/{pack}/*.json` |
| **3. 5분 빌드 검증** | ❌ 90분 낭비 후 실패 | ✅ 2초 npm install |
| **4. 데이터 구조 파악** | ✅ 잘 함 | ✅ 잘 함 |
| **5. 모듈화** | ✅ 잘 함 | ✅ 잘 함 (1,978 LOC TS) |
| **6. UI 텍스트 vs 데이터 분리** | ⚠️ 혼재 | ✅ 명확히 분리 |

**결론**: **빌드 시스템 분류가 가장 중요한 첫 단계**. 사용자 요청 받자마자 즉시 분류:
- 🟢/🟡 → 진행
- 🔴/⚫ → 5분 사전 검증 + 4-옵션 제시

**즉시 적용 규칙**: 새 OSS fork/localization 요청 시 **첫 번째 응답**에서 빌드 도구 분류 → 안전도 평가 → 작업량 추정.

**성공 사례 (sango-rising-dragons-kr, 2026-07-20)**: → `references/sango-rising-dragons-success.md` (6시간 성공 워크플로우, 모드팩 패턴, play.sh 표준, 점수화 매트릭스, 체크리스트 20개)

## ⭐ LÖVE/Lua 게임 fork-한글화 워크플로우 (NEW, 2026-07-21, SNKRX 성공)

**sango-rising-dragons(TypeScript/Phaser, JSON 모드팩)**와 **SNKRX(Lua/LÖVE, 코드 내장 텍스트)**는 모드팩 패턴이 다릅니다. Lua 게임은 데이터(JSON/PO) 외부화가 안 되어 있어 **다른 클래스**의 워크플로우가 필요합니다.

### 핵심 패턴: `T()` 함수 + `lang/<code>.lua` 모듈

Lua 코드 안에 텍스트가 흩어진 게임의 표준 우회 패턴:

```lua
-- shared.lua (가장 먼저 require되는 모듈)
lang = lang or {}
lang.current = 'ko'
lang.dicts = {}
lang.dicts.en = {}  -- 영어 = 원본 default
lang.dicts.ko = require('lang.ko')
lang.fallback = 'en'

function T(key, default)
  local dict = lang.dicts[lang.current] or {}
  local fb = lang.dicts[lang.fallback] or {}
  if dict[key] ~= nil then return dict[key] end
  if fb[key] ~= nil then return fb[key] end
  return default or key
end
```

```lua
-- lang/ko.lua (모듈식 번역 테이블)
return {
  arena_run = '아레나 런',
  options = '옵션',
  quit = '종료',
  -- ...
}
```

**사용**: `'arena run'` → `T('arena_run', 'arena run')` — default가 영어 원본이므로 폴백 안전.

**언어 전환**: `lang.current = 'en'` 한 줄 변경만으로 전체 UI 영어로 복귀. 향후 ja/zh 모드팩 추가도 같은 패턴.

### CJK 폰트 자동 fallback (LÖVE 11.x 한정, 가장 큰 함정)

**LÖVE 11.x의 TTF BitmapFont는 한글 glyph가 없으면 글리프 깨짐**. 반드시 lazy fallback 구현:

```lua
-- engine/graphics/font.lua
function Font:has_cjk(text)
  for i = 1, #text do
    local b = string.byte(text, i)
    if (b >= 0xE0 and b <= 0xEF) then return true end  -- 멀티바이트 CJK
  end
  return false
end

function Font:_ensure_ko_font()
  if self.ko_font then return self.ko_font end
  local ko_path = "assets/fonts/NotoSansKR-Regular.ttf"
  if love.filesystem.getInfo(ko_path) then
    self.ko_font = love.graphics.newFont(ko_path, self.size)
  else
    self.ko_font = self.font
  end
  return self.ko_font
end

function Font:get_font_for_text(text)
  if self:has_cjk(text) then return self:_ensure_ko_font() end
  return self.font
end

function Font:get_text_width(text)  -- 너비도 CJK 고려
  if self.ko_font and self:has_cjk(text) then
    return self.ko_font:getWidth(text)
  end
  return self.font:getWidth(text)
end
```

**3곳 패치 필수**: `engine/graphics/font.lua` (위), `engine/graphics/text.lua` (`Text:format_text` + `Text:draw`), `engine/graphics/graphics.lua` (`graphics.print` + `graphics.print_centered`). 한 곳만 빠지면 텍스트 폭이 어긋나서 한글 글자가 짤리거나 겹침.

### Lua 5.5 luac 함정 — `x and y() or z` 패턴 실패

`luac -p` 검증 시 `obj.method and obj.method() or obj.field` 패턴이 **"function arguments expected near 'and'"** 에러로 실패할 수 있음 (Lua 5.5 엄격성). **명시적 if/else로 변경**:

```lua
-- ❌ luac -p 에러 (일부 환경)
local active_font = font:get_font_for_text and font:get_font_for_text(text) or font.font

-- ✅ 안전
local active_font
if font.get_font_for_text then
  active_font = font:get_font_for_text(text)
else
  active_font = font.font
end
```

**즉시 적용 규칙**: Lua 코드에서 `obj.method and ... or obj.field` 안드로이드 패턴 절대 금지. 항상 명시적 if/else.

### patch() 함정 — 유사 코드 패턴 false match (Lua 게임 주의)

Lua 게임에는 비슷한 메서드 정의가 많아 (`function X:on_mouse_enter()...end` 같은) `patch()`가 **잘못된 위치**를 잡아 duplicate function 에러 발생 가능. SNKRX buy_screen.lua 1541번에서 steam_button 코드를 ItemCard:on_mouse_enter에 매칭하는 사고 발생 → `end expected near <eof>` syntax 에러.

**해결**:
1. **항상 충분한 context lines 포함** (앞/뒤 3줄 이상)해서 unique anchor 만들기
2. 패치 후 **반드시 `luac -p` 검증** (모든 .lua 한 번에)
3. 실패 시 `git checkout -- <file>`로 원본 복구 후 재시도

### 검증 도구 — `luac -p`로 실행 전 syntax 검증

LÖVE는 GUI 앱이라 헤드리스에서 실행 시 SIGKILL로 죽어서 검증 불가. **`luac -p`로 모든 .lua 파일 syntax 검증**이 표준 워크플로:

```bash
for f in shared.lua main.lua mainmenu.lua buy_screen.lua arena.lua enemies.lua player.lua objects.lua media.lua engine/graphics/font.lua engine/graphics/text.lua engine/graphics/graphics.lua lang/ko.lua; do
  echo -n "$f: "
  luac -p "$f" 2>&1 && echo "OK"
done
```

## ⭐ UTF-8 byte vs character iteration 함정 (NEW, 2026-07-21, SNKRX 실측, CRITICAL)

**모든 다국어 게임 fork에서 만나는 가장 위험한 함정** — 언어/엔진 무관.

**증상 (실측 SNKRX 에러)**:
```
Error: engine/graphics/text.lua:139: UTF-8 decoding error: Not enough space
        [C]: in function 'getWidth'
```

**원인 (SNKRX 원본 `engine/graphics/text.lua:206-218`)**:
```lua
for i = 1, #line.text do
  local c = line.text:sub(i, i)   -- ← single BYTE, not character
  table.insert(line.characters, {character = c, ...})
end
```
`#line.text`는 **바이트 수**, `sub(i, i)`는 **1바이트**. ASCII `"hello"` (5 bytes / 5 chars) → OK. 한글 `"아레나 런"` (UTF-8에서 12 bytes / 5 chars) → 각 iteration이 깨진 바이트 1개 (`"\xEC"`, `"\x95"`, `"\x84"` 등)를 추출. 이후 `Font:getWidth("\xEC")` 호출 시 love2d의 UTF-8 디코더가 **"Not enough space"** 에러로 크래시.

**다른 언어 같은 위험 패턴**:
| 언어 | 위험 코드 | 안전한 대안 |
|------|----------|-------------|
| **Lua/LuaJIT** | `for i=1,#s do s:sub(i,i)` | lead byte 분석 (아래 fix) |
| **JavaScript** | `str.charAt(i)`, `str[i]`, `str.slice(i,i+1)` | `Array.from(str)` 또는 `for (const ch of str)` |
| **Python 2** | `for c in str: ...` (str=bytes) | `for c in unicode: ...` |
| **Python 3** | `bytes(s,'utf-8')[i]` | `s[i]` (str = 코드포인트) |
| **C++** | `char buf[N]; buf[i]=s[i]` (UTF-8 raw) | `char32_t` / `std::u32string` |
| **Java** | `substring(i, i+1)` (ASCII only) | `codePointAt(i)` + `charCount(cp)` |

**Lua 표준 fix (lead byte 분석, LuaJIT 호환)**:
```lua
local i = 1
while i <= #text do
  local b = text:byte(i)
  local cont = 1
  if b >= 0xF0 then cont = 4      -- 4-byte (CJK Extension B+, Emoji)
  elseif b >= 0xE0 then cont = 3  -- 3-byte (한글, 한자, 히라가나)
  elseif b >= 0xC0 then cont = 2  -- 2-byte (Latin extended, 부호)
  end                              -- 0x80~0xBF = continuation byte (orphan, 무시)
  local c = text:sub(i, i + cont - 1)   -- ← full UTF-8 character
  ...process c...
  i = i + cont
end
```

**LuaJIT (LÖVE) 주의**: Lua 5.3의 `utf8.*` 라이브러리는 **LuaJIT에 없음** (`utf8.char/charpattern` 같은 일부만 호환). 위 lead byte 패턴이 표준.

**CJK 폰트 자동 감지 단순화** — `Font:has_cjk()`도 byte 기반이므로 같이 수정:
```lua
-- ❌ WRONG: 2-byte Latin extended (é, ñ)도 true 반환
-- if (b >= 0xE0 and b <= 0xEF) or (b >= 0xAC and b <= 0xD7) or (b >= 0xEA) then
-- ✅ CORRECT: lead byte만 체크
for i = 1, #text do
  local b = text:byte(i)
  if b >= 0xE0 then return true end   -- 3-byte: 한글/CJK, 4-byte: emoji
end
return false
```

**즉시 적용 규칙** (모든 fork 워크플로에 공통):
1. **언어 무관 체크리스트** — fork 첫 단계에서 byte-iteration 패턴 grep:
   ```bash
   python3 scripts/detect_utf8_byte_iteration.py /path/to/project
   # 또는 grep:
   grep -rn "charAt\|:sub([^,]*,[^)]*)\|:byte(" --include="*.lua" --include="*.js" --include="*.py" .
   ```
   → `scripts/detect_utf8_byte_iteration.py`로 Lua/JS/Python/C++ 위험 패턴 자동 스캔 (OSS-fork-localization §사전감지 도구).
2. **per-character width/draw 호출**: `cf:getWidth(c.character)` — `c.character`가 full UTF-8 char여야 안전
3. **빌드 검증 후 첫 게임 시작 직전**: `Font:getWidth("테스트 한글")` 단독 호출 → 크래시 없으면 통과
4. **언어 무관 적용**: 한글/일본어/중국어/아랍어/이모지 모두 영향. ASCII 전용 게임은 무관

**SNKRX 실측 교훈**:
- 1차 fix: `Font:has_cjk`가 Latin extended에도 true → 한글 없는 영어 게임도 ko_font 로드
- 2차 fix: lead byte만 체크 → 영어 게임 영향 없음, 한글만 ko_font
- 3차 fix: byte iteration으로 `c.character` 추출 → UTF-8 decoding error
- **최종 fix**: lead byte 분석 (text.lua) + lead byte만 체크 (font.lua) → 한국어 정상 렌더링

## ⭐ Lua 5.5 luac 검증 함정 — `x and y() or z` 패턴 실패 (NEW, 2026-07-21, SNKRX 실측)

`luac -p` (Lua 5.5) 검증 시 **"function arguments expected near 'and'"** 에러 발생.

**발생 코드 (SNKRX engine/graphics/graphics.lua:66, 1차 시도)**:
```lua
local active_font = font:get_font_for_text and font:get_font_for_text(text) or font.font
--                       ^^^^^^^^^^^^^^^^^^^^^^
-- luac: "function arguments expected near 'and'"
```

**왜 실패하나**: Lua 5.5 파서가 `font:get_font_for_text(text)` 호출 시 메서드 호출 표현식이 and-expression의 두 번째 operand로 들어가면서 **Lua 5.4+의 엄격해진 문법 검사**에서 reject. Lua 5.1~5.3에서는 잘 작동했지만 LuaJIT(5.1) 환경이라도 luac 5.5로 검증하면 실패.

**해결 — 명시적 if/else**:
```lua
local active_font
if font.get_font_for_text then
  active_font = font:get_font_for_text(text)
else
  active_font = font.font
end
```

**즉시 적용 규칙**: Lua 게임 fork 시 `obj.method and obj.method() or obj.field` 패턴 **절대 금지**. 항상 if/else. **luac -p로 검증 필수**.

## ⭐ 폰트/텍스트 API의 **숫자 입력** 가드 — `type(text) ~= "string"` (NEW, 2026-07-21, SNKRX 실측)

**Lua 게임 fork에서 가장 빈번하게 만나는 footgun**. 게임 코드에서 `graphics.print(숫자, ...)` 같은 호출이 매우 흔함 (가격, 레벨, 점수, 데미지 등).

**실측 에러 (SNKRX buy_screen.lua:1750)**:
```
Error: engine/graphics/font.lua:54: attempt to get length of local 'text' (a number value)
        [C]: in function '__len'
        engine/graphics/font.lua:54: in function 'has_cjk'
        engine/graphics/font.lua:63: in function 'get_font_for_text'
        engine/graphics/graphics.lua:84: in function 'print_centered'
        buy_screen.lua:1750: in function 'draw'
```

**실제 코드**:
```lua
-- buy_screen.lua:1750 — 가격(숫자)을 print_centered에 직접 넘김
graphics.print_centered(self.parent.cost, pixul_font, ...)
--                          ^^^^^^^^^^^^^^^ 숫자 (예: 3 = 골드 3)
```

**왜 크래시하나**: 우리 `print_centered`는 `font:get_font_for_text(text)` 호출 → `Font:has_cjk(text)`. **`if not text then return false` 가드 무력화**: Lua에서 `not 0`은 false (0이 truthy!) → 가드 통과 → `#3` 시도 → "attempt to get length of local 'text' (a number value)".

**해결 — 모든 폰트/텍스트 API에 type guard 추가**:
```lua
function Font:has_cjk(text)
  if text == nil then return false end
  if type(text) ~= "string" then return false end  -- ← 핵심: 숫자/boolean 즉시 차단
  -- ... 기존 UTF-8 검사 ...
end

function Font:get_text_width(text)
  if text == nil or type(text) ~= "string" then return 0 end  -- ← 핵심
  -- ... 기존 검사 ...
end
```

**근본 원인 (왜 게임 코드가 숫자를 텍스트 API에 넘기나)**:
- `love.graphics.print(3, font, ...)`는 LÖVE가 자동으로 `"3"`으로 변환 (정상 작동)
- 우리 `graphics.print/print_centered`가 그걸 **훼손** — `font:get_font_for_text(text)`로 raw `text` 그대로 전달
- `Font:has_cjk(text)`에서 `not text` 가드는 nil/false만 차단, **0/숫자는 통과** (Lua truthy 주의)

**다른 언어 같은 위험**:
| 언어 | API 패턴 | 위험 |
|------|----------|------|
| JavaScript | `if (!text)` → `text = 0` 통과 | 동일 위험 |
| Python | `if not text:` → `text = 0`도 falsy (안전) | Python은 OK |
| Lua | `if not text then` → `text = 0` truthy (위험) | Lua만 위험 |

**즉시 적용 규칙** (모든 fork 워크플로):
1. **폰트/텍스트 API 가드는 `type(x) ~= "string"` 또는 `x == nil` 명시**: `if not x` 금지
2. **숫자 → 문자열 변환**: hook 호출 전 `tostring(text)`로 강제 변환하면 더 안전
3. **검증 패턴**: 게임 코드 grep으로 `print\([^"]*\bself\.\w+\b[^"]*\)` 검색 → 숫자 가능성 있는 호출 모두 점검
4. **게임 첫 시작 후 다양한 화면 클릭**: 가격 표시, 데미지 숫자, 점수판 — 모두 숫자 가능성

**SNKRX buy_screen.lua:1750 구체 fix**:
```lua
-- engine/graphics/graphics.lua: print_centered에 tostring 래핑
function graphics.print_centered(text, font, ...)
  text = type(text) == "number" and tostring(text) or text
  -- ... 기존 로직 ...
end
```
**또는 `Font:get_font_for_text`만 강화해서 `font.font:getWidth(tostring(text))`로 폴백. **둘 다 OK, 후자가 덜 침습적**.

### window size sentinel 우선순위 함정 — `'max'` vs `'half'` 순서 (NEW, 2026-07-21, SNKRX 실측)

**증상**: `engine/init.lua`에서 `'max'` 비교가 `'half'` 비교보다 먼저이면 arithmetic error:

```lua
-- ❌ WRONG: 'half'가 먼저 비교 안 됨
if config.window_width ~= 'max' then window_width = config.window_width end
--                            ↑ 'half'도 'max'가 아니므로 window_width = 'half' (문자열) 박힘
if config.window_width == 'half' then window_width = math.floor(window_width / 2) end
--                            ↑ 'half' / 2 → "attempt to perform arithmetic on a string value"

-- ✅ CORRECT: 'half'를 먼저 처리한 후 'max' 비교
if config.window_width == 'half' then window_width = math.floor(window_width / 2) end
if config.window_width ~= 'max' and config.window_width ~= 'half' then window_width = config.window_width end
```

**즉시 적용 규칙**: 다중 sentinel 비교 시 **가장 구체적인 것부터 처리** ('half' → 'max' → 숫자). 일반적인 코드 리뷰에서도 sentinel 패턴 추가 시 순서 점검.

### macOS Retina `usedpiscale` 함정 (NEW, 2026-07-21, SNKRX/M4 실측)

**증상**: M4 Mac + Retina 디스플레이에서 `love.window.setMode(1280, 720)` 호출 → 윈도우는 1280x720 픽셀이지만 **love2d 내부 좌표계는 자동으로 640x360으로 축소 매핑**. UI가 보이지만 작게 보임.

**원인**: love2d 11.x의 `t.window.usedpiscale = true`(기본값)이 Retina DPI를 자동 적용. 물리 윈도우 크기와 love2d 좌표계가 다르게 됨.

**해결 — conf.lua**:
```lua
function love.conf(t)
  t.version = "11.3"
  t.window.width = 1280
  t.window.height = 720
  t.window.vsync = 1
  t.window.msaa = 0
  t.window.resizable = true
  t.window.usedpiscale = false  -- ★ Retina DPI 자동 축소 비활성화
end
```

**검증 워크플로**:
1. `usedpiscale = false` 설정 후 love 실행
2. 메인 메뉴 텍스트가 **원본 960x540의 1.33배 크기로 보이면** 정상
3. 여전히 작으면 `main.lua`의 `engine_run`에서 `sx = window_width / game_width` 비율 확인 → 1280/480 ≈ 2.67이어야 함

**왜 이 함정이 위험한가**: `sx = 2.67` 비율은 정상이어도 love2d가 Retina에서 1/2로 매핑하면 결과적으로 1.33배만 보임 → 사용자가 "창은 큰데 오브젝트 작다" 정정 신호.

**즉시 적용 규칙**:
- M4/Apple Silicon 사용자에게 LÖVE 게임 fork 시 **반드시 `usedpiscale = false` 명시**
- 사용자가 "오브젝트가 작다" 정정 시 1순위 의심: `usedpiscale` → `game_width` 비율 → `state.sx` 비정상 순으로 디버깅

### `state.sx` 비정상 데이터 풀스크린 트리거 함정 (NEW, 2026-07-21, SNKRX 실측)

**증상**: 게임을 한 번이라도 실행하면 `engine/init.lua:99`에서 `state.sx, state.sy = sx, sy`로 현재 비율이 `~/Library/Application Support/LOVE/{game_name}/state.txt`에 저장됨. 다음 실행 시 `if state.sx and state.sy` 분기를 타서 `setMode(state.sx * gw, state.sy * gh)` 호출 → **state.sx=4 같은 비정상 값이면 setMode(1920, 1920) → macOS가 자동 풀스크린화**.

**근본 원인 3가지**:
1. 이전 게임이 다른 해상도에서 실행됨 (예: 1920x1080 풀스크린 게임) → state.sx=4
2. 코드 변경으로 game_width 변경됐는데 이전 세이브 그대로 로드
3. 여러 번 실행/디버깅하면서 state.sx가 어중간한 값으로 박힘

**해결 — `state.sx` 범위 가드 + state.txt 정리**:
```lua
-- engine/init.lua
if state.sx and state.sy then
  -- ★ state.sx가 0.5~3 범위 벗어나면 비정상 데이터로 간주
  if state.sx >= 0.5 and state.sx <= 3 and state.sy >= 0.5 and state.sy <= 3 then
    sx, sy = state.sx, state.sy
    love.window.setMode(state.sx*gw, state.sy*gh, ...)
  else
    -- 비정상 state.sx → 무시하고 기본 사이즈
    state.sx, state.sy = nil, nil
    love.window.setMode(window_width, window_height, ...)
  end
else
  -- state.sx 없음 (첫 실행 or state.txt 삭제됨)
  state.sx, state.sy = sx, sy
  love.window.setMode(window_width, window_height, ...)
end
```

**state.txt 위치**: macOS = `~/Library/Application Support/LOVE/{game_name}/state.txt`. 게임 비정상 동작 시 가장 먼저 의심할 위치.

**즉시 적용 규칙**:
1. `state.txt`는 fork 첫 실행 직전에 `rm` 권장 (특히 게임 설정 변경 후)
2. `state.sx` 사용 시 **반드시 범위 가드** (0.5~3 또는 사용 가능한 스케일 값)
3. 비정상 시 `state.sx, state.sy = nil, nil`로 무효화 → 다음 분기에서 기본값 사용
4. 사용자 정정 "풀스크린 됨" 시그널 → 1순위로 `state.sx` 의심

### Steamworks shim 작성 시 자주 빠뜨리는 5개 함수 (NEW, 2026-07-21, SNKRX 실측)

**shim 작성 워크플로**: 게임 코드 전체 grep → 모든 메서드 no-op 정의.

| API | 호출 위치 | 빠뜨리면 |
|-----|----------|----------|
| `steam.runCallbacks()` | **`engine/init.lua` 메인 루프** (매 프레임) | `attempt to call field 'runCallbacks' (a nil value)` — 첫 프레임 직후 크래시 |
| `steam.userStats.setAchievement()` | arena.lua 등 (도전과제) | nil 호출 에러 |
| `steam.userStats.storeStats()` | 도전과제 직후 | nil 호출 에러 |
| `steam.friends.setRichPresence()` | 메뉴/상점 진입 시 | nil 호출 에러 |
| `steam.shutdown()` | 게임 종료 | nil 호출 에러 |

**검증 grep**: `grep -rn "steam\.\w\+\.\w\+\|\bsteam\.\w\+\(" --include="*.lua"` → 모든 호출 추출.

**가장 흔한 실수**: `runCallbacks` 빼먹기 (메인 루프에서 호출되므로 첫 1초 안에 크래시). SNKRX는 `engine/init.lua:149`에서 호출.

## ⭐ 헤드리스 `love` 프로세스 alive 검증 패턴 (NEW, 2026-07-21, SNKRX)

**LÖVE는 GUI 앱이라 헤드리스에서 실행 시 SIGKILL로 죽음**. 게임 부팅 성공 여부 확인:

```bash
# 백그라운드 실행
love . > /tmp/love_run.log 2>&1 &
LOVE_PID=$!
sleep 5

# 검증 1: 프로세스 살아있나?
ps -p $LOVE_PID -o pid,stat,command
# STAT=Ss = sleep = 정상 (메인 루프 진입 성공)
# STAT=Z = zombie = 죽음
# 빈 줄 = 죽음

# 검증 2: stderr 비어있나? (에러 없음 = 정상)
cat /tmp/love_run.log
# 비어있으면 OK, 에러 있으면 크래시

# 정리
kill -9 $LOVE_PID
```

**SIGNAL 해석**:
| STAT | 의미 | GUI 실행 가능? |
|------|------|----------------|
| `Ss` | 정상 sleep (메인 루프 진입) | ✅ |
| `S` | interruptible sleep | ✅ |
| `R` | running | ✅ |
| `Z` | zombie | ❌ 크래시 후 잔여 |
| `T` | stopped | ❌ |

**즉시 적용 규칙**: LÖVE 게임 fork 시 5초 백그라운드 실행 + `ps` + stderr 체크. **헤드리스에서 GUI 화면 확인은 불가능하지만 코드 로딩 성공 여부는 검증 가능**.

## ⭐ `:activate({})` 함수 인자 안 `local` 선언 불가 — Lua syntax error (NEW, 2026-07-21, SNKRX v0.1.7 실측)

**가장 빈번하게 만나는 footgun** — Lua 함수 호출 인자는 **expression**이어야 하고 **statement**는 불가. `local var = ...`은 statement이므로 `:activate({...})` 같은 table 인자 안에 넣을 수 없음.

**실측 에러**:
```
luac: buy_screen.lua:1120: unexpected symbol near 'local'
```

**실수 패턴 (3번 같은 실수 반복 — 같은 패턴을 여러 곳에 복제할 때 매번 발생)**:
```lua
self.info_text:activate({
  -- ❌ luac: "unexpected symbol near 'local'"
  local char_name = T('char_' .. self.character, self.character)
  if lang.current == 'en' then char_name = self.character:capitalize() end
  local desc_func = (lang.current == 'ko' and lang.character_descriptions_ko ...) or character_descriptions[self.character]
  {text = '[' .. character_color_strings[self.character] .. ']' .. char_name .. '...'},
  ...
})
```

**올바른 패턴 — local을 `:activate({})` 호출 전으로 이동**:
```lua
-- ✅ CORRECT: local 선언은 함수 호출 밖에서
local char_name = T('char_' .. self.character, self.character)
if lang.current == 'en' then char_name = self.character:capitalize() end
local desc_func = (lang.current == 'ko' and lang.character_descriptions_ko ...) or character_descriptions[self.character]
self.info_text:activate({
  {text = '[' .. character_color_strings[self.character] .. ']' .. char_name .. '...'},
  ...
})
```

**왜 이런 실수가 많이 나오는가**:
- Python/JS에서는 `{local var = ...; ...}` 같은 표현식이 자연스러움 (Python은 walrus operator, JS는 statement-expression 모호)
- Lua는 명확히 구분: function call argument = expression만
- **4개 객체 (TutorialCharacterPart, CharacterPart, TutorialClassIcon, ClassIcon)에서 같은 실수 반복** — 같은 패턴을 여러 곳 적용할 때 처음에 실수하면 4번 복제

**안전 가드 패턴 — 함수 호출을 한 단계 분리**:
```lua
-- BEST: 변수 미리 준비 + activate는 table literal만
local lines = {
  {text = '[' .. character_color_strings[self.character] .. ']' .. char_name .. '...'},
  {text = desc_func(self.level), ...},
  {text = effect_desc_func(), ...},
}
self.info_text:activate(lines, nil, nil, nil, nil, 16, 4, nil, 2)
```

**즉시 적용 규칙**:
1. Lua에서 `:method({...})` 호출 — `{...}` 안에는 **절대 `local`/`function`/`if-then-else` 같은 statement 금지**
2. 패치 후 즉시 `luac -p` 검증 — statement-in-arg 에러는 즉시 발견됨
3. **여러 객체에 같은 패턴 적용 시**: 첫 번째만 직접 작성, 나머지는 `read_file`로 첫 번째 결과 확인 후 → 같은 실수 복제 방지
4. **복잡한 변수가 5개 이상일 때**: 가장 안전한 패턴 = lines table을 미리 만들어서 activate에 통째로 전달

## ⭐ Lua 모듈 간 `local` 함수 의존성 함정 (NEW, 2026-07-21, SNKRX v0.1.8 실측)

**Lua 다국어 fork에서 가장 자주 만나는 footgun 중 하나** — 원본 코드가 모듈 내부의 `local` 함수를 사용하면, ko.lua 같은 별도 모듈에서 그 함수를 호출할 수 없음.

**실측 에러 (SNKRX v0.1.7 → v0.1.8)**:
```
Error: lang/class_descriptions_ko.lua:3: attempt to call global 'ylb1' (a nil value)
stack traceback:
        lang/class_descriptions_ko.lua:3: in function 'class_desc_func_c'
        buy_screen.lua:2041: in function 'on_mouse_enter'
```

**원인**:
- `main.lua` 내부에서 `local ylb1 = function(lvl) ... end`로 정의된 helper 함수
- 원본 `class_descriptions` 테이블은 `ylb1(lvl)` 호출 — main.lua 내부에서 호출되므로 OK
- 우리 `class_descriptions_ko.lua`도 `ylb1(lvl)` 호출 — 그러나 **모듈 시점에 `_G.ylb1`가 정의 안 됨** (main.lua의 local이라 global 환경 노출 안 됨)

**왜 이런 일이?**: Lua의 `local`은 모듈 스코프. `main.lua`의 `function init()` 안에 `local ylb1 = ...` 정의 → `_G.ylb1`로 노출 안 됨. `class_descriptions_ko.lua`를 `require`해도 `_G.ylb1`는 nil.

**해결 패턴 — fork 모듈 자체에 helper 복제**:
```lua
-- lang/class_descriptions_ko.lua
local ylb1 = function(lvl)
  if lvl == 3 then return 'light_bg'
  elseif lvl == 2 then return 'light_bg'
  elseif lvl == 1 then return 'yellow'
  else return 'light_bg' end
end
local ylb2 = function(lvl)
  if lvl == 3 then return 'light_bg'
  elseif lvl == 2 then return 'yellow'
  else return 'light_bg' end
end
local ylb3 = function(lvl)
  if lvl == 3 then return 'yellow'
  else return 'light_bg' end
end

return {
  ['ranger'] = function(lvl) return '[' .. ylb1(lvl) .. ']3[light_bg]/... end,
  ...
}
```

**해결 패턴 — `_G` 명시 노출** (원본 코드 수정 가능한 경우):
```lua
-- main.lua init() 안
local ylb1 = function(lvl) ... end
_G.ylb1 = ylb1  -- ← 명시적 global 노출 (ko.lua에서 사용 가능)
```

**진단 신호**:
- "attempt to call global 'X' (a nil value)" 에러
- 에러 위치는 ko.lua, 호출 스택은 hover/callback에서
- 같은 함수가 원본에서는 잘 동작 (`class_descriptions`)

**판별 매트릭스**:
| 패턴 | 글로벌? | 모듈에서 사용 가능? |
|------|--------|---------------------|
| `function helper() ... end` | ✅ (글로벌) | ✅ |
| `local helper = function() ... end` (모듈 밖) | ❌ (모듈 스코프) | ❌ |
| `function module.helper() ... end` | ❌ (모듈 스코프) | ❌ |
| `local helper; helper = function() ... end` | ❌ | ❌ |
| `_G.helper = local_var` | ✅ | ✅ |

**즉시 적용 규칙**:
1. **게임 코드 grep으로 `local \w+ = function` 패턴 추출** → 다국어 ko 모듈에서 호출 가능한지 확인
2. **호출 불가 시 2가지 해결**:
   - **A) ko.lua에 helper 함수 자체를 복제** (가장 간단, 원본 비수정)
   - **B) main.lua에 `_G.helper = local_var` 명시 추가** (원본 수정, 깔끔)
3. **verify 워크플로**: 게임 부팅 → 클래스 hover (또는 가장 자주 호출되는 패널) → 에러 없으면 통과
4. **글로벌 vs 로컬 패턴 확인**: `grep -n "^local \w\+\s*=\s*function\|local \w\+$" main.lua`

**다른 언어 같은 위험 (대비)**:
- **Python**: 모듈 스코프 함수는 `from module import func` 또는 `module.func`로 접근. **private/public 구분 없음** → fork 모듈에서 import 가능.
- **JavaScript**: `const helper = ...`도 모듈 스코프 → export 안 하면 외부 접근 불가. ES module 사용 시 자동 private.
- **TypeScript**: `private` 명시 가능. export 안 한 함수는 외부 접근 불가.

→ 즉, **Lua만** 함수 export 명시 없이 local로 정의해도 호출 시도 가능 (단, nil로 실패). Python/JS는 import/export 명시 필요.

## ⭐ 대량 함수 테이블 자동 일괄 매핑 (NEW, 2026-07-21, SNKRX v0.1.9 실측)

게임 데이터가 큰 dict (50~300개)일 때 **수동 번역은 비현실적**. Python regex + 함수 본문 변환으로 **반자동 처리**.

**사례 (SNKRX v0.1.9)**:
- `passive_names` 테이블 84개 (영문 이름 → 한글)
- `passive_descriptions` 테이블 84개 (짧은 영어 설명 → 한글)
- `passive_descriptions_level` 테이블 84개 × `function(lvl) return ... end` (레벨별 동적 설명 → 한글)

**총 250+ 개 항목** — 손으로 1주일 작업. **Python으로 30분**.

**Python 일괄 매핑 표준 패턴 (단어 사전 기반)**:
```python
import re

# 1) 영한 단어 사전 (가장 자주 쓰는 단어부터)
translations = {
  'movement speed': '이동속도',
  'movement': '이동',
  'projectile damage': '투사체 데미지',
  'projectiles per second': '투사체/초',
  'AoE damage': '광역 데미지',
  'defense': '방어력',
  'damage': '데미지',
  'attack speed': '공격속도',
  # ... 100+ 항목
}

def translate_en_to_ko(text):
  # ★ Longest first 매칭 (짧은 단어가 긴 단어의 일부로 매칭되는 것 방지)
  sorted_keys = sorted(translations.keys(), key=len, reverse=True)
  result = text
  for en in sorted_keys:
    if en in result:
      result = result.replace(en, translations[en])
  result = re.sub(r'\s+', ' ', result).strip()
  return result

# 2) main.lua에서 원본 테이블 추출
with open('main.lua', 'r', encoding='utf-8') as f:
  content = f.read()

start = content.index("passive_descriptions_level = {")
brace_count = 0
i = start
while i < len(content):
  if content[i] == '{': brace_count += 1
  elif content[i] == '}':
    brace_count -= 1
    if brace_count == 0: break
  i += 1
section = content[start:i+1]

# 3) 각 라인 파싱 → ko.lua 생성
output = ["return {"]
for line in section.split('\n'):
  m = re.match(r"^\s*\['([^']+)'\]\s*=\s*function\(lvl\)\s*return\s+(.+?)\s+end,?\s*$", line)
  if m:
    key, body = m.group(1), m.group(2)
    # body를 ' .. ' 단위로 분리, 각 부분 처리 (ts() 호출은 그대로)
    parts = re.split(r'\s*\.\.\s*', body)
    new_parts = []
    for part in parts:
      part = part.strip()
      if part.startswith('ts(') and part.endswith(')'):
        new_parts.append(part)  # ts() 그대로
      else:
        sm = re.match(r"^'(.*)'$", part)
        if sm:
          new_parts.append(f"'{translate_en_to_ko(sm.group(1))}'")
        else:
          new_parts.append(part)
    output.append(f"  ['{key}'] = function(lvl) return {' .. '.join(new_parts)} end,")

with open('lang/passive_descriptions_level_ko.lua', 'w', encoding='utf-8') as f:
  f.write('\n'.join(output) + '\n')
```

**핵심 기법**:
1. **Longest-first 매칭**: `'movement speed'`와 `'movement'`가 둘 다 있을 때, `'movement speed'`를 먼저 매칭 → `'movement'` 단독 매칭은 speed 뒤에 매칭됨. `sorted_keys = sorted(..., key=len, reverse=True)`
2. **`ts()` 호출 보존**: 레벨별 다른 값 (10/20/30%)은 `ts(lvl, ...)` 호출. 이건 그대로 두고 정적 텍스트만 번역.
3. **`' .. '` 단위로 split**: Lua 문자열 연결 연산자. 각 부분을 개별 처리.

**검증 워크플로**:
1. `luac -p lang/passive_*.lua` — syntax OK
2. 게임 부팅 → 패시브 카드 hover → 한글 표시
3. **일부 어색한 번역 발견** (예: "to 모든 유닛" 같은 어색한 결과) → 사전에 매핑 추가 후 재생성

**즉시 적용 규칙**:
1. **dict 크기 > 30이면 자동화**: 손 번역보다 Python 사전 매핑이 5~10배 빠름
2. **ts()/getX()/dynamic 함수는 그대로**: 정적 텍스트만 매핑. 함수 호출은 게임 로직.
3. **결과물 100% 번역은 아님**: 사전에 없는 단어는 영어 그대로. **80% 번역 + 20% 영어 혼용**이 일반적. 게임플레이에 영향 없음.
4. **사전은 점진적 확장**: 1차 번역 후 사용자 피드백 → 2차 사전 확장 → 재생성 (재배포 불필요, ko.lua만 갱신)
5. **python 사용처는 Lua 모듈 출력**: `return { ... }` 형식 그대로 → `require('lang.<name>_ko')`로 로드

**대안**: LLM 호출해서 한 줄씩 번역도 가능하지만, **수백 개 항목이면 비용/시간 큼**. 사전 매핑 + 점진 확장이 가장 효율적.

## ⭐ patch() fuzzy-match collision — Lua 게임의 `function X:method()...end` 패턴 (NEW, 2026-07-21, SNKRX buy_screen.lua:1541 실측)

**문제**: SNKRX buy_screen.lua에서 steam_button 코드를 추가하려고 했는데, `patch()`가 **ItemCard:on_mouse_enter() 메서드 정의**를 잘못 매칭 → 1541번 라인이 중복 함수 정의 → `end expected near <eof>` syntax 에러 → buy_screen.lua 전체 로드 실패.

**왜 이런 일이?** Lua 코드는 비슷한 메서드 정의가 많아 (`function X:on_mouse_enter()...end` 같은). patch의 fuzzy match가 다른 클래스/객체의 메서드를 우연히 매칭할 수 있음.

**해결 규칙**:
1. **항상 충분한 context lines 포함** (앞/뒤 3줄 이상) → unique anchor 만들기
2. **패치 후 반드시 `luac -p` 검증** (모든 .lua 한 번에) — 실패 시 즉시 발견
3. **실패 시 `git checkout -- <file>`로 원본 복구 후 재시도**
4. **특정 라인 위치 (예: `at line 1541`)를 정확히 알고 있으면 `read_file`로 그 라인 주변 10줄 먼저 확인**

**실측 패턴 (SNKRX)**:
- 1차 시도: short anchor → ItemCard:on_mouse_enter에 우연히 매칭 → 1541번 라인이 `function ItemCard:on_mouse_enter()`가 됨 (이미 1541에 정의되어 있던 것 + patch가 추가한 것 = 중복) → syntax 에러
- 2차 시도: `function ItemCard:on_mouse_enter()` 라인을 정확히 제거 (1개만 남김) → 정상

**Lua 게임에서 흔한 fuzzy-match 위험 패턴**:
- `function X:on_mouse_enter()...end` (여러 객체에 존재)
- `function X:on_mouse_exit()...end` (동일)
- `function X:draw()...end` (모든 게임 오브젝트)
- `function X:update()...end` (모든 게임 오브젝트)

**즉시 적용 규칙**:
1. **Lua 게임 patch() 호출 시 context 최소 5줄** (앞 3줄 + 뒤 2줄)
2. **패치 후 즉시 `luac -p` 실행** → 실패 시 즉시 발견
3. **`function X:method_name()...end` 라인은 특히 주의** — 동일 메서드명이 다른 객체에 있을 가능성 높음

## ⭐ Apple Gatekeeper quarantine 제거

brew로 설치한 macOS 앱이 **"love(를)를 열지 못함 — Apple이 서명되지 않은 Mac용 소프트웨어에서..."** 팝업 띄울 때.

**원인**: brew cask가 2026년 이후 Gatekeeper를 통과하지 못하는 앱越来越多. love는 **2026-09-01부터 brew에서 deprecation 예정**.

**해결 (1초)**:
```bash
xattr -dr com.apple.quarantine "/Applications/love.app"
# 검증: quarantine 속성 사라졌는지 확인
xattr -l "/Applications/love.app"
# → com.apple.provenance만 남으면 OK
```

**대안 (Finder UI, 30초)**: 우클릭 → 열기 → 경고 다시 클릭 → 열기

**대안 (시스템 설정, 1분)**: 시스템 설정 → 개인 정보 보호 및 보안 → "그래도 열기" 버튼

**즉시 적용 규칙**: brew cask로 설치한 GUI 앱이 "Apple이 서명되지 않은..." 팝업 띄우면 **가장 빠른 건 quarantine 제거**. 단, 알 수 없는 출처 앱에는 적용 금지.

### LÖVE 빌드 환경 분류 (5단계 표에 추가)

| 분류 | 빌드 도구 | 빌드 시간 | macOS 호환성 | 사례 |
|------|----------|----------|--------------|------|
| 🟢 **LÖVE/Lua 게임** | `love .` (런타임) | 0초 | ✅ brew cask `love` | **SNKRX** (✅ 30분, 신 클래스) |
| 🟢 **즉시 성공** | `npm`/`yarn` | 2초 | ✅ | sango-rising-dragons |
| 🟡 **Java/Gradle** | `./gradlew` | 30초~5분 | ✅ | triplea |
| 🟠 **Rust/cargo** | `cargo build` | 1~5분 | ✅ | zemeroth |
| 🔴 **C++ scons/CMake** | `scons`/`make` | 30분~1시간 | ⚠️ | Wesnoth |
| ⚫ **C#** | `dotnet`/`mono` | 1~5분 | ⚠️ | RTK2020-CORE |

**즉시 적용 규칙**: 사용자가 LÖVE/Lua 게임 fork-한글화 요청 시 → 위 `T()` + CJK 폰트 + `luac -p` 3종 세트로 즉시 시작.

**SNKRX 성공 사례 (2026-07-21)**: → `references/love-game-fork.md` (LÖVE/Lua 게임 fork-한글화 패턴: Steamworks shim, Apple Gatekeeper quarantine, T() 함수 + lang/*.lua 모드팩, CJK 폰트 lazy fallback, luac -p offline 검증, 헤드리스 love 검증, patch fuzzy match 함정, MODIFIED.md 템플릿)

- [Steamworks shim 표준 템플릿]: → `scripts/luasteam_shim_template.lua` (SNKRX 검증된 no-op Steamworks shim. 게임 코드 grep으로 사용된 steam.* 함수 확인 후 그대로 복사해서 `engine/external/luasteam.lua`로 배치)
- [옵션 영구 저장 + 풀스크린 토글 패턴 (state.sx/sy, display 옵션 macOS 버그)]: → `references/love2d-option-state-persistence.md` (snkrx-clone v0.1.20~v0.1.25 5번 반복 디버깅 끝에 정착. 옵션 버튼 save_state() 추가, state.sx 가드, 풀스크린 토글, window_sx 백업 키, setMode display 옵션 macOS 버그 회피까지 종합)

### ⭐ LÖVE 게임 크로스 플랫폼 배포 — `.love` + macOS .app + Windows zip + Linux tar.gz (NEW, 2026-07-21, SNKRX Release v0.1.12)

**한글화 끝났으면 누구나 다운로드 → 더블클릭 → 게임 시작** 가능해야 함. SNKRX v0.1.12 GitHub Release 발행으로 검증된 4 플랫폼 배포 워크플로.

### 4개 플랫폼 배포 산출물

| 플랫폼 | 형식 | 크기 | 내용 |
|---|---|---|---|
| **macOS** | `.zip` (`.app` 번들) | 86M | love2d 실행파일 + `Contents/Frameworks/*` (10개 .framework) + `Info.plist` + `game.love` + 아이콘 |
| **Windows** | `.zip` (폴더) | 4.3M | `love.exe` + DLL (OpenAL, SDL2, lua51, mpg123, msvcp/cr120) + `game.love` + `run.bat` |
| **Linux** | `.tar.gz` | 65M | `love.AppImage` (x86_64) + `game.love` + `run.sh` |
| **크로스** | `.love` 단독 | 62M | love2d가 설치된 모든 OS에서 `love game.love` |

### 1단계: `.love` 파일 빌드 (게임 데이터 zip)

**`.love` = 표준 zip 포맷**. love2d가 직접 실행 가능. `zip -r game.love . -x ".git/*" ".DS_Store" dist/*`

```bash
#!/bin/bash
# build_love.sh
set -e
VERSION="${VERSION:-v0.1.12}"
OUTPUT="dist/snkrx-kr-$VERSION.love"
mkdir -p dist
zip -r "$OUTPUT" . -x "*.git*" "*.DS_Store" "dist/*" "*.love" -q
```

**.git, .DS_Store, dist, .love 제외**로 136M → 62M 축소.

### 2단계: macOS .app 번들

**SNKRX에서 가장 까다로운 부분** — 3가지 함정:

#### 함정 1: `Contents/Frameworks/*` 10개 .framework 번들 필수

**증상 (SNKRX 실측)**:
```
dyld[24163]: Library not loaded: @rpath/love.framework/Versions/A/love
  Referenced from: <...> /path/to/SNKRX-한국어.app/Contents/MacOS/love
  Reason: tried: '.../Contents/MacOS/../Frameworks/love.framework/...' (no such file)
```

**원인**: `/Applications/love.app/Contents/Frameworks/`에 있는 10개 .framework 번들이 의존성. `.app`에 같이 복사해야 함.

**10개 .framework**:
```
Lua.framework, OpenAL-Soft.framework, SDL2.framework, freetype.framework,
libmodplug.framework, love.framework, mpg123.framework, ogg.framework,
theora.framework, vorbis.framework
```

**해결** (build_macos.sh 안에):
```bash
FRAMEWORKS_SRC="/Applications/love.app/Contents/Frameworks"
FRAMEWORKS_DST="$CONTENTS/Frameworks"
mkdir -p "$FRAMEWORKS_DST"
cp -R "$FRAMEWORKS_SRC"/* "$FRAMEWORKS_DST/"
```

#### Info.plist (Contents/Info.plist) — Apple 표준

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleName</key><string>SNKRX 한국어</string>
    <key>CFBundleDisplayName</key><string>SNKRX 한국어</string>
    <key>CFBundleExecutable</key><string>love</string>
    <key>CFBundleIdentifier</key><string>com.sigco3111.snkrx-kr</string>
    <key>CFBundleVersion</key><string>0.1.12</string>
    <key>CFBundleShortVersionString</key><string>0.1.12</string>
    <key>CFBundlePackageType</key><string>APPL</string>
    <key>LSMinimumSystemVersion</key><string>10.13</string>
    <key>NSHighResolutionCapable</key><true/>
    <key>NSPrincipalClass</key><string>NSApplication</string>
    <key>CFBundleDocumentTypes</key>
    <array>
        <dict>
            <key>CFBundleTypeName</key><string>LÖVE Game</string>
            <key>CFBundleTypeRole</key><string>Viewer</string>
            <key>LSItemContentTypes</key>
            <array><string>org.love2d.love-game</string></array>
        </dict>
    </array>
</dict>
</plist>
```

**`.love` 파일은 `Contents/Resources/game.love`로 배치** (love2d가 자동으로 찾음).

### 3단계: Windows zip (love2d 공식 패키지 사용)

```bash
mkdir -p dist/windows
curl -L -o love.zip "https://github.com/love2d/love/releases/download/11.5/love-11.5-win64.zip"
unzip -q -o love.zip  # ← -o 필수 (없으면 interactive prompt에서 멈춤)
rm love.zip
cp dist/snkrx-kr-$VERSION.love dist/windows/love-11.5-win64/
zip -r snkrx-kr-windows-$VERSION.zip dist/windows/love-11.5-win64/
```

#### 함정 2: `unzip` interactive prompt

**증상 (SNKRX 빌드 스크립트 실측)**:
```
replace love-11.5-win64/changes.txt? [y]es, [n]o, [A]ll, [N]one, [r]ename:  NULL
(EOF or read error, treating as "[N]one" ...)
```

**원인**: 기존 love-11.5-win64 폴더가 있을 때 unzip이 각 파일마다 덮어쓸지 interactive prompt. stdin 닫혀있으면 자동 [N]one이지만 빌드 자동화에서 hang 위험.

**해결**: **`unzip -o` 플래그** (overwrite yes). 단, `unzip -o -q love.zip`처럼 `-q` (quiet)와 같이 사용.

### 4단계: Linux AppImage

```bash
curl -L -o love.AppImage "https://github.com/love2d/love/releases/download/11.5/love-11.5-x86_64.AppImage"
chmod +x love.AppImage
cp dist/snkrx-kr-$VERSION.love dist/linux/
tar czf snkrx-kr-linux-$VERSION.tar.gz dist/linux/
```

**AppImage는 4.8MB**로 매우 작음. 자체 FUSE + libfuse 의존성, 또는 `--appimage-extract`로 squashfs 추출 가능.

### 5단계: 통합 빌드 스크립트 (`build_all.sh`)

**3개 플랫폼 + .love를 한 번에**:

```bash
#!/bin/bash
set -e
VERSION="${VERSION:-v0.1.12}"
PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
DIST_DIR="$PROJECT_DIR/dist"
LOVE_OUTPUT="$DIST_DIR/snkrx-kr-$VERSION.love"

# 1. .love 빌드
"$PROJECT_DIR/build_love.sh"

# 2. macOS .app
"$DIST_DIR/macosx/build_macos.sh"
(cd "$DIST_DIR" && zip -r "snkrx-kr-macos-$VERSION.zip" "SNKRX-한국어.app" -q)

# 3. Windows zip (cd 절대 path로 — 현재 디렉토리 부작용 방지)
WINDOWS_DIR="$DIST_DIR/windows"
(cd "$WINDOWS_DIR" && unzip -q -o love.zip)  # 또는 사전 다운로드
cp "$LOVE_OUTPUT" "$WINDOWS_DIR/"
(cd "$WINDOWS_DIR" && zip -r "$DIST_DIR/snkrx-kr-windows-$VERSION.zip" love-11.5-win64/ -q)

# 4. Linux tar.gz
LINUX_DIR="$DIST_DIR/linux"
cp "$LOVE_OUTPUT" "$LINUX_DIR/"
(cd "$LINUX_DIR" && tar czf "$DIST_DIR/snkrx-kr-linux-$VERSION.tar.gz" love.AppImage "snkrx-kr-$VERSION.love" run.sh README.txt)
```

**subshell `(cd ...)`로 현재 디렉토리 부작용 방지** — `cd $DIST_DIR/windows` 후 zip 호출하면 상대 경로가 의도와 다르게 됨.

### 6단계: GitHub Release 발행 — `gh release create` workflow scope 우회

> **⭐ 사용자 확인 게이트 (NEW, 2026-07-22, snkrx-clone v0.1.20)**: GitHub Release 자산 업로드는 **사용자 확인 후에만** 실행. 자동 발행 금지. 이 세션에서 v0.1.15~v0.1.19까지 매 수정마다 4개 asset을 재업로드했는데, 사용자가 "앞으로 내가 확인 할 때 까지 릴리즈는 하지말도록해" 라고 정정함. 빌드는 로컬에서 하고 (`./build_all.sh`), `gh release create`/`curl` 업로드는 사용자가 명시적으로 "릴리즈해줘" 라고 하기 전까지 보류. 빌드 산출물은 `dist/`에 그대로 두고 commit만 진행. 자세한 패턴은 `references/oss-fork-localization/release-confirmation-workflow.md` 참조.

**증상 (SNKRX 실측)**:
```
$ gh release create v0.1.12 ...
! Failed to create release, "workflow" scope may be required.
$ gh auth refresh -h github.com -s workflow
```

**원인**: `gh` CLI의 기본 `repo` scope은 `gh release create` API를 호출 가능하지만, 내부에서 GitHub Actions workflow까지 트리거하려면 `workflow` scope 필요. 토큰에 없으면 실패.

**해결 — curl로 API 직접 호출**:

```bash
TOKEN=$(gh auth token 2>/dev/null)
RELEASE_DATA='{
  "tag_name": "v0.1.12",
  "name": "SNKRX 한국어 v0.1.12",
  "body": "## 한글화 완료\n\n13개 영역 + 적 이름 표시\n\n### 다운로드\n- macOS: ...",
  "draft": true
}'

# 1) Release 생성 (draft)
curl -s -X POST \
  -H "Authorization: Bearer $TOKEN" \
  -H "Accept: application/vnd.github+json" \
  https://api.github.com/repos/sigco3111/snkrx-clone/releases \
  -d "$RELEASE_DATA" \
  | python3 -c "import sys,json; d=json.load(sys.stdin); print(f'Created: {d[\"id\"]}, upload_url: {d[\"upload_url\"]}')"

# 2) Release ID 추출
RELEASE_ID="<id>"

# 3) Asset 업로드 (4개)
UPLOAD_URL="https://uploads.github.com/repos/sigco3111/snkrx-clone/releases/${RELEASE_ID}/assets{?name,label}"
for file in dist/snkrx-kr-*.zip dist/snkrx-kr-*.tar.gz dist/snkrx-kr-*.love; do
  name=$(basename "$file")
  curl -s -X POST \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/zip" \
    --data-binary "@$file" \
    "${UPLOAD_URL//\{?name,label\}/?name=$name}" \
    -o /dev/null -w "  HTTP %{http_code} (%{size_upload} bytes)\n"
done

# 4) Draft → Published
curl -s -X PATCH \
  -H "Authorization: Bearer $TOKEN" \
  -H "Accept: application/vnd.github+json" \
  https://api.github.com/repos/sigco3111/snkrx-clone/releases/$RELEASE_ID \
  -d '{"draft":false,"tag_name":"v0.1.12","name":"SNKRX 한국어 v0.1.12"}'
```

**Asset 업로드 HTTP 201 = 성공**. 4개 asset 모두 한 번에 업로드.

**게시물 작성 패턴** (release notes 예시):
```markdown
## SNKRX 한국어화 fork v0.1.12

### 🎮 한글화 완료 (13개 영역)
- 메인 메뉴, 상점, 튜토리얼, 옵션, ...
- 새 기능: 적 이름 표면 표시

### 📦 다운로드
| 플랫폼 | 파일 | 크기 |
|---|---|---|
| macOS | snkrx-kr-macos-v0.1.12.zip | 86M |
| Windows | snkrx-kr-windows-v0.1.12.zip | 4.3M |
| Linux | snkrx-kr-linux-v0.1.12.tar.gz | 65M |
| 크로스 | snkrx-kr-v0.1.12.love | 62M |

### 🚀 설치
**macOS**: 압축 해제 → SNKRX-한국어.app을 Applications로 드래그 → 실행
**Windows**: 압축 해제 → love-11.5-win64/run.bat 더블클릭
**Linux**: 압축 해제 → ./run.sh
```

### 7단계: .gitignore + README 다운로드 섹션

```gitignore
# .gitignore
dist/
```

```markdown
<!-- README.md 상단 -->
## 📦 다운로드 (v0.1.12)

**[GitHub Releases 페이지](https://github.com/sigco3111/snkrx-clone/releases/tag/v0.1.12)**

| 플랫폼 | 파일 | 크기 | 설치 |
|---|---|---|---|
| macOS | snkrx-kr-macos-v0.1.12.zip | 86M | 압축 해제 → .app을 Applications로 드래그 |
| Windows | snkrx-kr-windows-v0.1.12.zip | 4.3M | 압축 해제 → run.bat 더블클릭 |
| Linux | snkrx-kr-linux-v0.1.12.tar.gz | 65M | 압축 해제 → ./run.sh |
| 크로스 | snkrx-kr-v0.1.12.love | 62M | love2d 설치 후 love game.love |
```

### 누적 통계 (SNKRX v0.1.14 + Release v0.1.12)

| 메트릭 | 값 |
|---|---|
| **v0.1 ~ v0.1.14** | 14개 커밋 푸시 |
| **Release v0.1.12** | 4개 asset, 226M 합 |
| **빌드 산출물** | `.love` (62M), macOS .app (84M), Windows zip (4.3M 압축), Linux tar.gz (65M) |
| **GitHub Release** | https://github.com/sigco3111/snkrx-clone/releases/tag/v0.1.12 |

### 즉시 적용 규칙 — LÖVE 게임 배포 시

1. **`build_love.sh` 첫 작성**: zip -r game.love, `.git/.DS_Store/dist` 제외
2. **macOS .app**: `Contents/Frameworks/*` 10개 .framework 필수 복사 (가장 자주 빠뜨림 → `dyld: Library not loaded` 에러)
3. **Windows zip**: `unzip -q -o` (interactive prompt 방지)
4. **Linux AppImage**: 4.8MB만 다운로드, FUSE 의존성 인지
5. **`gh release create` 권한 부족 시**: curl API 직접 호출 (workflow scope 없이 가능)
6. **Asset 업로드**: `Content-Type: application/zip` 헤더 + `--data-binary @file`
7. **.gitignore**: `dist/` 추가 (대용량 빌드 결과물 제외)
8. **README 다운로드 섹션**: 플랫폼별 파일 + 크기 + 설치 명령 표

### 빌드 함정 체크리스트 (4개)

| 함정 | 증상 | 해결 |
|---|---|---|
| macOS Frameworks 누락 | `dyld: Library not loaded: @rpath/love.framework` | `cp -R /Applications/love.app/Contents/Frameworks/* dist/.../Contents/Frameworks/` |
| `unzip` interactive prompt | stdin 닫혀있으면 hang 또는 [N]one 자동 | `unzip -q -o` |
| `gh release` workflow scope | `! Failed to create release, "workflow" scope may be required` | curl API 직접 호출 (Bearer $TOKEN) |
| build script `cd` 부작용 | 다른 플랫폼 빌드 시 잘못된 path | subshell `(cd $DIR && cmd)` |

### Skill 부재 시 fallback 워크플로

- `build_all.sh`가 `cp $(LOVE_OUTPUT) $WINDOWS_DIR/` 후 `(cd $WINDOWS_DIR && zip ...)` 패턴 — 현재 디렉토리 부작용 회피
- `gh` CLI 권한 부족 시 모든 release 작업을 `curl + Bearer token`으로 우회 가능
- macOS .app Frameworks 10개 = `/Applications/love.app/Contents/Frameworks/` 전체 복사가 가장 안정

## ⭐ 색상 태그 보존 sed 일괄 치환 (게임 데이터 한정, 2026-07-21 추가)

게임 데이터에서 색상 태그(`[yellow]`, `[blue]`, `[fg]` 등)가 포함된 문자열은 단순 sed/string-replace가 안 됨 (태그와 단어를 구분해야 함).

**패턴**: `'<color_tag>EnglishName'` → `'<color_tag>한글명'`

**Python 일괄 처리 표준 (게임 캐릭터/스킬/아이템 이름)**:
```python
import re

# 1) 색상 태그 매핑 정의
translations = {
  'Warrior': '전사', 'Mage': '마법사', 'Nuker': '누커',
  'Ranger': '레인저', 'Rogue': '도적', 'Healer': '힐러',
  'Enchanter': '인챈터', 'Psyker': '사이커', 'Builder': '빌더',
  'Voider': '보이드', 'Curser': '커서', 'Swarmer': '스워머',
  'Forcer': '포서', 'Conjurer': '컨저러', 'Sorcerer': '소서러',
  'Mercenary': '머서너리', 'Explorer': '탐험가',
}

# 2) 색상 태그 + 이름 영역만 추출 (영향 최소화)
with open('main.lua', 'r', encoding='utf-8') as f:
    lines = f.readlines()

start, end = None, None
for i, l in enumerate(lines):
    if 'character_class_strings = {' in l: start = i
    elif start and l.strip() == '}': end = i; break

if start and end:
    # 3) 색상 태그 (']) 다음의 단어만 치환
    for i in range(start, end + 1):
        for en, ko in translations.items():
            # ']EnglishName\b' → ']한글명' (regex word boundary)
            lines[i] = re.sub(r'\]\s*' + en + r'\b', ']' + ko, lines[i])
    with open('main.lua', 'w', encoding='utf-8') as f: f.writelines(lines)
```

**왜 word boundary (`\b`) 필요한가**: `'[blue]Mage'`에서 'Mage'만 치환하고 'Magenta' 같은 다른 단어는 안 건드리기 위함.

**경계 케이스 처리**:
- 두 번째 클래스에 색상 없음 (`'[blue]Mage, Enchanter'`) → `Enchanter`는 매칭 안 됨 → 수동 패치 1~2개
- 같은 키가 여러 파일에 등장 (`buy_soundtrack`, `credits`, `loop` 등) → grep으로 모든 위치 파악 후 일괄 처리:
  ```bash
  grep -rn "button_text = 'X'" --include="*.lua"  # 모든 위치 파악
  ```

**즉시 적용 규칙** (게임 fork 시):
1. 색상 태그가 있는 문자열은 **항상 `<color_tag>이름` 형태** — sed/python regex로 정확히 매칭
2. word boundary 필수 (MagicKnight 같은 다른 단어 보호)
3. 영역 한정 처리 — `character_class_strings = {` ~ `}` 같은 명확한 섹션 안에서만
4. 다중 파일 같은 키는 grep으로 일괄 파악 후 패치

## ⭐ UI 풍성화 + alias 캐스팅 패턴 (NEW, 2026-07-20, sango-rising-dragons v0.3)

**sango-rising-dragons v0.3에서 발견한 패턴**: 모드팩 데이터 + TypeScript UI 코드 양쪽에 한국어 풍성화 적용.

### 모드팩 JSON에 메타 필드 추가

```json
[
  {
    "id": "caocao",
    "name": "조조",
    "alias": "패왕",
    "full_name": "조조 (패왕)"
  }
]
```

**alias/full_name** 같은 메타 필드를 ko 모드팩에서 추가. **원본 base에는 없는 필드** → TypeScript 타입 오류 가능.

### TypeScript에서 런타임 데이터 타입 우회

```typescript
// hud.ts
import { OfficerDef } from './types';

// OfficerDef에 alias 필드 없음 → 타입 오류
const o = officerDef(o.id) as OfficerDef & { alias?: string };
o.name + (o.alias ? ` (${o.alias})` : '');

// 더 간단한 우회: any 캐스팅
const o = officerDef(o.id) as any;
o.name + (o.alias ? ` (${o.alias})` : '');
```

**왜 이걸 쓰나**: TypeScript의 정적 타입 시스템은 런타임 fetch 데이터의 실제 구조를 알 수 없음. 모드팩이 런타임에 필드를 추가하면 정적 타입이 모름. **`as any` 또는 intersection type으로 우회**.

### 사이드 패널 풍성화 패턴 (hud.ts)

**v0.2 → v0.3에서 추가한 UI 텍스트**:

```typescript
// 진영/도시/유닛 카드 hover 도움말 풍성화
const cityDesc = (cityDef(selectedCity) as any).desc || '';
body.innerHTML = `
  <div class="city-info">
    <i>${cityDesc}</i>  <!-- 도시 역사적 설명 -->
  </div>
  <button title="농업 개발 (${DEV_COST} 금, 1⚡). 매 레벨마다 매 턴 식량 +50">🌾 개간</button>
  <button title="수색: 성 안의 재야 인재를 찾거나 세금 100 금 징수 (1⚡)">🔍</button>
  <button title="장수와 부대를 인접한 성으로 출정 (1⚡). 적지는 자동으로 전투 발생">🚩 출정</button>
`;

// 적/중립 vs 아군 도시 분기 (한국어 라벨링)
if (c.owner === 'neutral') {
  body.innerHTML = `🏴 <b>재야 성도</b> — 수비 약함...`;
} else if (!own) {
  body.innerHTML = `⚔ <b>${f.name}의 영지</b> (적)...`;
} else {
  body.innerHTML = `내 ${cityDesc}...`;
}
```

**핵심 원칙**:
- 한 단어 라벨 → 풍성한 설명 (예: "개간" → "🌾 개간 (200금, 1⚡). 매 레벨마다 매 턴 식량 +50")
- 모호한 메시지 → 구체적 수치 (예: "재야 인재 있음" → "소문에 성 중에 재야 인재가 있다고……")
- 도시/유닛 카드는 모드팩 데이터(`desc`, `alias`, `full_name`) 적극 활용

### 출정 모달 풍성화

```typescript
// modals: marchDialog
showModalRaw(`
  <h2>${hostile ? '⚔ 공격' : '🚩 이동'}: ${cityDef(to).name}</h2>
  <div class="mShort">${cityDef(from).name}에서 출발 · 출정 후 잔류 병력: <b id="mLeft"></b></div>
  ${intel}  <!-- "수비군: 약 5,000 병력, 성벽 3단계, 수장: 여포 (무쌍)" -->
  <div>통솔 장수를 선택하세요 (최대 3명):</div>
  <div>출정 병력: <b id="mTroopsVal"></b> 
       <span style="color:var(--muted);font-size:11px">(남겨둘 병력: ${(src.troops - 500).toLocaleString()})</span>
  </div>
  <div class="mChoices">
    <button id="mGo" class="primary">${hostile ? '⚔ 공격!' : '🚩 출발'}</button>
    <button id="mCancel">취소</button>
  </div>
`);
```

**변경 사항**:
- 단순 `공격${도시명}` → `공격: ${도시명}` (콜론으로 분리)
- `병력${값}단계` → `병력 ${값} 단계` (공백)
- 출정 병력 옆에 `남겨둘 병력` 정보 추가
- 모드팩의 `alias`도 모달에서 표시: `수장: ${defOff.map(o => officerDef(o.id).name + (officerDef(o.id) as any).alias ? ` (${(officerDef(o.id) as any).alias})` : '').join(', ')}`

**즉시 적용 규칙**:
1. 모드팩에 `alias`, `full_name`, `desc` 같은 메타 필드 자유 추가
2. UI 코드에서 `(x as any).필드명` 패턴으로 타입 우회
3. 라벨은 항상 풍성하게 (이모지 + 짧은 이름 + 효과 + 비용)
4. 모달은 입력 필드 + 결과 예측 함께 표시 (출정 병력 → 남겨둘 병력)

## ⭐ Python `http.server` + Playwright fetch 디버깅 패턴 (NEW, 2026-07-20)

**sango-rising-dragons 디버깅 중 발견한 4가지 흔한 함정**.

### 함정 1: mergeById packs 순서 (위 섹션)

### 함정 2: Vite dist/ JS에 옛날 manifest 인라인

**증상**:
```bash
$ grep "{packs" dist/assets/*.js
{packs:["base"]}   # ← 옛날 빌드 (현재 manifest.json은 ["base", "ko"])
```

**원인**: Vite 6이 빌드 시점에 매크로/import를 inline. **빌드 캐시 또는 이전 빌드 잔재**.

**해결**:
```bash
# Vite 캐시 강제 삭제
rm -rf node_modules/.vite
# manifest.json / ko data 파일 touch (수정 시간 갱신)
touch public/data/manifest.json
touch public/data/ko/events.json
# 재빌드
./play.sh build
```

**검증**:
```bash
grep "packs" dist/assets/*.js
# → {packs:["base","ko"]} (현재 manifest와 일치)
```

### 함정 3: dist 정적 서버 vs dev 서버 응답 차이

**증상**: Vite dev 서버 (`npm run dev`, 5173)와 Python `http.server` (`./play.sh serve`, 8080) **둘 다** 200 OK 반환하지만, 빌드 산출물(`dist/`)이 다를 수 있음.

**확인 방법**:
```bash
# 어느 서버가 살아있는지
lsof -i :5173 -i :8080
# 5173: Vite dev (소스 그대로 서빙)
# 8080: Python http.server (dist/ 서빙)

# 두 서버의 응답 비교
curl -s http://localhost:5173/data/ko/events.json | python3 -c "import json,sys; print(json.load(sys.stdin)[0]['text'][:50])"
curl -s http://localhost:8080/data/ko/events.json | python3 -c "import json,sys; print(json.load(sys.stdin)[0]['text'][:50])"
# → 다르면 한쪽이 옛날 캐시
```

**해결**: 항상 **한 서버만** 살아있게 유지 (다른 것 kill). Playwright는 한 URL만 보도록 명시.

### 함정 4: Playwright fetch 인터셉터로 한국어 텍스트 검증

**sango-rising-dragons에서 mergeById 디버깅용 도구**:

```javascript
import { chromium } from 'playwright';

const browser = await chromium.launch({ headless: true });
const page = await browser.newPage();

// 모든 fetch 응답 가로채기
page.on('response', async (resp) => {
  if (resp.url().includes('data/')) {
    console.log(`[fetch] ${resp.url()} → ${resp.status()}`);
    if (resp.url().includes('events.json')) {
      const body = await resp.json();
      const intro = body.find(e => e.id === 'intro');
      if (intro) {
        console.log(`  intro text: ${intro.text.substring(0, 80)}`);
        console.log(`  intro title: ${intro.title}`);
      }
    }
  }
});

await page.goto(URL, { waitUntil: 'networkidle' });
// 진영 선택 → 모달 → fetch 12개 모두 로깅됨
```

**왜 강력한가**:
- 화면에 한자가 보일 때 — 이 도구로 **실제 fetch된 JSON** 확인
- 데이터가 한국어 → JS 코드 문제 (mergeById 순서 등)
- 데이터가 한자 → fetch 자체가 옛날 캐시 또는 dev 서버 캐시

**→ 이 도구로 4번의 빌드-캡처 미스터리 해결**.

### Vite + Python http.server 통합 workflow

```bash
# 평소: dev 서버 (HMR)
./play.sh dev
# 5173

# 빌드 검증: 정적 서버
./play.sh serve
# 8080

# Playwright 테스트 (정적 서버 권장 - 결정성)
node /tmp/screenshot.mjs  # http://localhost:8080
```

**주의**: 두 서버 동시에 실행 시 Playwright가 어떤 것을 보는지 추적 어려움. **항상 하나만**.

## ⭐ `tsc --noEmit` LSP 캐시 vs 실제 파일 상태 (NEW, 2026-07-20)

**sango-rising-dragons v0.3에서 발견**: LSP가 "error TS2339: Property 'alias' does not exist"로 보고하지만, 실제로는 `npx tsc --noEmit`은 0 에러. → **LSP 캐시가 늦음**.

**해결**:
```bash
# LSP 무시하고 직접 tsc로 확인
cd /Users/mac/work/sango-rising-dragons
npx tsc --noEmit 2>&1 | head -20
# 0 에러면 OK

# LSP 캐시 리프레시는 IDE 측에서 처리
# Hermes에서는 신경 안 써도 됨
```

**즉시 적용 규칙**: LSP 경고가 의심스러우면 **직접 tsc --noEmit**로 재검증.

## ⭐ 사용자가 "한글화가 매우 부족하네" (2026-07-20) 정정 시그널 — 작업 단계 조정

사용자가 "한글화 부족" 정정을 줬을 때, sango-rising-dragons-kr v0.2 → v0.3에서 **데이터 → UI → 게임 화면 검증** 순서로 재작업.

**교훈**:
- **데이터만 한국어** (v0.1) → 한자 UI 텍스트 잔존
- **데이터 + UI 코드 한국어** (v0.2) → **v0.2 게임 화면은 한자** (??)
- **데이터 + UI + Playwright 검증 + packs 순서** (v0.3) → **한글화 100%**

**즉시 적용 규칙**: 사용자가 "한글화 부족" 정정을 하면 **3가지** 확인:
1. 데이터 (JSON/PO) 100% 번역?
2. UI 코드 (HTML/TS/CSS) 한자 0?
3. **게임 화면에서 실제로 한자 안 보이는지 Playwright로 검증**?
4. 모드팩 시스템이면 `manifest.packs` 순서?

**이 중 하나라도 빠지면** 사용자가 "여전히 부족"이라고 다시 정정할 가능성 ↑. **검증 없이는 v0.3가 진짜 완료인지 알 수 없음**.

사용자가 "TOP 3의 깃허브 링크를 알려줘" 같은 짧은 요청을 할 때:

**❌ 절대 금지** (이런 식으로 응답):
```
| 순위 | 저장소 | ⭐ | 언어 | 라이선스 | 크기 | URL | 빌드 | 한국어화 가치 | 활발도 | 설명 |
| ... |
(긴 매트릭스 + 여러 페이지)
```

**✅ 권장**:
```
| 순위 | 저장소 | ⭐ | 언어 | URL |
|---|---|---|---|---|
| 🥇 1 | repo/name | 1967 | TypeScript | https://github.com/... |
| 🥈 2 | repo/name | 1454 | Rust | https://github.com/... |
| 🥉 3 | repo/name | 1861 | TypeScript | https://github.com/... |
```

**원칙**: 사용자가 명시적으로 원하는 정보만 (이름 + URL), 추가 컨텍스트는 별도 질문 시에만.

**사용자 정정 시그널**:
- "내 기대와 다르네..." → 잘못된 작업의 방향성
- "별로인데..." → 출력 형식/내용이 사용자 의도와 안 맞음
- "링크를 알려줘" → URL만, 추가 분석은 후속 질문 시
- "시간이 오래걸릴까?" → 솔직한 추정, 매트릭스 X

## ⭐ 동양 역사 게임 (삼국지/코에이風) 검색 (NEW, 2026-07-20)

CJK 게임 검색은 **로마자 transliteration (sangokushi)이 100배 효과적**. CJK 한자 (三/国)는 GitHub API에서 부정확.

**검색어 우선순위**:
1. `sangokushi` (74개, 가장 풍부)
2. `三国 + 战 + 武将 + game` (CJK, 보조)
3. `three kingdoms` / `romance of the three kingdoms` (영어, 부정확)
4. `tam quoc` (베트남어)
5. `dynasty warriors` / `koei style strategy`

**발견된 후보 5개** (우선순위):
- 🥇 cheft/sanguo (⭐52, JS) — **빌드 불필요**, 클래식 三国霸业
- 🥈 freeors/War-Of-Kingdom (⭐71, C) — 본격 턴제 전략, Rose SDK
- 🥉 freeciv + 三国 시나리오 (⭐1566, C) — 안정, 시나리오 추가형
- 4. BlurayDisc/SangoKushi2 (⭐1, Java) — 학습/참고용
- 5. tenshikaito/sengoku-scroll-old (⭐5, C#) — 코에이 스타일 UI 참고

→ 자세한 검색 워크플로 + 후보 평가 매트릭스: `references/cjk-game-search-workflow.md`

## ⭐ 미완성 게임 함정 — 후보 선정 시 반드시 검증 (NEW, 2026-07-20)

**3국지 게임 후보 선정 시 star 수, 빌드 용이성, 활성도만 보면 안 됨**. 가장 중요한 검증 = **"실제로 게임이 플레이 가능한가?"**.

**cheft/sanguo (⭐52, 1주 전 업데이트) 교훈**:
- 모든 표면 지표 훌륭: star 52, 활발한 개발, LayaAir 엔진 + 빌드 불필요
- **실측 검증 결과**: README에 "君主、武将、武器、地图、城池、战场地图 기능 정리 완료; **AI, 전투, 명령 시스템 미구현**" 명시
- **한글화 가치 🟡 낮음**: 도시/영웅 데이터 + 메뉴 UI만 있고 실제 게임플레이 불가능

**검증 워크플로 (후보 선정 전 필수, 2분)**:
1. **README 전체 읽기** — "완성" / "미완성" / "WIP" / "todo" / "TBD" / "미구현" 같은 단어 검색
2. **screenshot/GIF 확인** — 도시/영웅 화면만 vs 실제 플레이 화면 (전투/AI 행동)
3. **commit 메시지 분석** — `git log --oneline` 으로 "AI", "battle", "combat", "system" 같은 기능 단어 추출
4. **이슈/PR 탭** — "play", "complete", "missing" 키워드 검색
5. **Wiki/문서** — "current features" vs "planned features" 명확히 구분되는지

**판별 매트릭스**:
| 상태 | 신호 | 한국어화 가치 |
|------|------|----------------|
| **플레이 가능** | 실제 게임 화면 GIF, "play against AI" 설명 | 🟢 높음 |
| **메뉴/데이터만** | 도시/영웅 스크린샷, "data complete" | 🟡 낮음 |
| **기술 데모** | "tech demo", "experimental" | 🔴 매우 낮음 |
| **포크/모드** | 원본 게임 + 추가 모드 | 🟡 낮음~중간 |

**Wesnoth 사례와 결합**: 미완성 + macOS 빌드 안 됨 = 최악의 조합. 90분 낭비 2회 반복 가능.

## 핵심 원칙

### 1. 라이선스 의무는 **먼저** (Apache 2.0 §4(a))

`fork + 수정`은 **반드시** LICENSE + MODIFIED.md + 변경 표시 3종 세트로 진행. 이거 나중에 하면 blame 비용 ↑.

| 의무 | 위치 | 검증 |
|------|------|------|
| 원본 LICENSE 보존 | 그대로 | `grep "Apache License" LICENSE` |
| 저작권 표시 | 원본 + 본인 | `MODIFIED.md` §원본 정보 |
| 변경 파일 명시 | `MODIFIED.md` 표 | 본인 PR/커밋 |
| 라이선스 자동 인식 | repo Description | GitHub API `license.spdx_id` |

**자주 실수하는 라이선스별 의무**:

| 라이선스 | 허용 | 의무 | 비고 |
|---------|------|------|------|
| Apache 2.0 | 상업, 수정, 배포 | LICENSE, 변경, **NOTICE** | 가장 permissive |
| MIT | 상업, 수정 | LICENSE + 저작권 | 가장 짧음 |
| BSD-3 | 상원, 수정 | LICENSE + 저작권 | "광고 조항" 주의 |
| GPL-3.0 | 상업, 수정 | **파생 저작물 GPL** | 가장 strict, fork면 GPL |
| AGPL-3.0 | 상업, 수정 | **네트워크 사용 시도 GPL** | SaaS 망함 |
| **라이선스 미명시** | ❓ | **fork 보류 권장** | 법적 불명확 — `references/cjk-game-search-workflow.md` §라이선스 미명시 시 대응 |

**Stanford generative_agents 사례** (2026-07-14 sigco3111): Apache 2.0 fork → LICENSE 보존 + MODIFIED.md 작성 → GitHub이 `Apache-2.0` 라이선스 자동 인식 확인.