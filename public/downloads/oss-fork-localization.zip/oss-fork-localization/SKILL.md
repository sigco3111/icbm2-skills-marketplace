---
name: oss-fork-localization
description: OSS fork + 한국어화 + 크로스 플랫폼 배포. 6단계 빌드 환경 + LÖVE/Lua/Three.js/Next.js/JS/Java 모드팩 + UTF-8 + Steamworks shim + CJK 폰트 + 90분+ 함정 + NoBuildDependencies i18n + 게임 후보 5축 + Athena Crisis 3대 함정 + Open Core 비공개 본체 7시그널 + 한국어 진행도 preflight + Vercel 자동배포 + Godot 4 i18n 5대 함정 + Cross-fork PR 5대 함정 + Java Swing i18n Phase 2 확장 + ui.properties 3언어 동기화 + patch 도구 4줄+ 함정 + **YAML 배열 객체 평탄화 함정 (2026-07-28 4차)** + **부분 번역 PR 금지 (2026-07-28 4차)** + **사용자 직접 게임 실행 명령어 안내 패턴 (2026-07-28 4차)** + **Go UI 하드코딩 라벨 일괄 처리 패턴 (2026-07-28 5차, localization.G() 24+개 Render/Println)** + **4대 축 통합 워크플로 (2026-07-28 5차)** + **lua_error.go multi-line patch 덮어쓰기 사고 (2026-07-28 5차)** + **PTY 후처리 검증 패턴 (2026-07-28 5차)** + **YAGNI 100% 한글화 원칙 (2026-07-28 5차)** + **PR 5커밋 stacked 분리 패턴 (2026-07-28 6차)** + **다국어 README + 언어 탭 + 한국어 설정 섹션 동봉 패턴 (2026-07-28 6차)** + **`localization.SetCurrent` 누락 함정 (2026-07-28 6차)** + **PTY subprocess UTF-8 디코딩 함정 (2026-07-28 6차)** + **PR 본문 6섹션 best practice (2026-07-28 6차)**. 'fork해서 한글화' 요청. 5분 preflight 필수.
tags: [oss, fork, korean, localization, game, i18n, github-pr]
---

# OSS Fork + 한국어화 + 크로스 플랫폼 배포

이 skill은 umbrella 역할만 합니다. **상세 지식은 아래 references에 모두 들어있습니다**. 워크플로 시작 시 가장 관련 있는 reference 1-2개 먼저 읽으세요.

## 빠른 시작

1. **"GitHub에서 개선/한글화할 프로젝트 찾아줘"** → `references/game-fork-candidate-survey-workflow.md` + `references/github-game-candidate-scouting.md`
2. **fork + 빌드 환경 파악** → `references/build-environment-preflight-check.md`
3. **i18n 인프라 정찰 (로더 코드 읽기)** → `references/i18n-architecture-reconnaissance.md` + `scripts/i18n-yaml-verify.sh`
4. **Open Core 함정 사전 체크** → `references/open-core-preflight-checklist.md` + `references/open-core-fork-pitfall.md`
4. **빌드 환경별 한국어화**:
   - LÖVE/Lua → `references/love-game-fork.md` + `references/love2d-game-fork.md` + `references/love-lua-game-fork.md` + `references/snkrx-clone-success.md` + `references/sango-rising-dragons-success.md`
   - Three.js/JS 웹 → `references/threejs-browser-game-fork.md` + `references/i18n-nobuild-js-pattern.md` + `references/webapp-i18n-render-verification.md`
   - Godot 4 → `references/godot-4-i18n-preflight.md` + **`references/godot-4-i18n-po-fork-workflow.md` (2026-07-28 verified — 166 msgid 한국어화, fork 3단계 분해, POT escape regex, headless 검증 스모크, project.godot 자동 변경 분리)**
   - Java/Gradle → `references/game-engine-po-localization.md` + `references/closed-source-artifact-blocker.md` + `references/java-resourcebundle-locale-lookup-pitfall.md` (Phase 1) + **`references/java-swing-i18n-scaling.md` (Phase 2+ 확장, 2026-07-28 — 잠재량 vs 실측 가능량 + Lombok 제약 + 3언어 동시 게이트 + N파일 위임 패턴)**
5. **PR 보내기** → `references/github-pr-cross-fork-pitfalls.md` (gh CLI cross-fork 5대 함정)
6. **배포** → `references/love2d-cross-platform-distribution.md` + `references/vercel-auto-deploy-korean-locale.md` + `references/vercel-auto-deploy-import-once.md` + `references/love-windows-zip-build-pitfalls.md`
7. **chrome-only 거절 신호 + terminate 절차 (2026-07-28, TripleA 4차)** ★★★ → `references/oss-fork-terminate-conditions.md` — "이 정도는 한글화라고 할 수 없음" 거절 신호 = 3가지 한계 (map XML / HistoryNode 직렬화 / 잠재량 1%) + 종료 절차 (commit + push 한 트랜잭션) + pre-flight 6번째 축 (콘텐츠 외부 자원 검사)

## Pre-flight 5축 (모든 fork 후보 공통)

5분 안에 5개 다 통과 못하면 후속 작업 가치 없음:

| 축 | 확인 명령 | 실패 시 |
|---|---|---|
| 1. **Open Core 비공개** | `art/` `Variants.nkzw.tsx` `.gitignore codegen` `isOpenSource existsSync` 빈 src/ 7시그널 | `references/open-core-fork-pitfall.md` — placeholder 빌드 절대 금지 |
| 2. **한국어 진행도** | `gh search issues "repo:X korean"`, `find . -name "*ko*"` | greenfield면 좋음, 22.5% polish도 가치 큼 |
| 3. **라이선스 코드/에셋 분리** | `cat LICENSE` + `cat assets/LICENSE.md` (CC-BY-NC 함정) | fork-first 결정, LICENSE.MODIFIED 작성 |
| 4. **CLA 저작권 양도** | `grep -i "copyright\|assign\|transferable" .github/CONTRIBUTING.md` | CLA 있으면 독립 fork, PR 안 함 |
| 5. **빌드 환경** | `package.json`/`Cargo.toml`/`Makefile`/`build.gradle.kts` 존재 | 6단계 분류: 🟢 npm 🟡 Java/Gradle 🟠 Rust 🔴 C++ |

## 🚨 핵심 함정 (이번 세션 2026-07-28 추가)

### Cross-fork PR 5대 함정

### Cross-fork PR 5대 함정
- gh CLI `0 commits between master` GraphQL 버그 (4회 연속 실패 사례)
- "compare across forks" UI 단계 누락 → URL 직접 (`?expand=1`) 우회
- branch push 후 즉시 PR 시 캐시 stale → 재push 또는 30초 대기
- base/head 순서 뒤바뀜 (`<base>...<head>` 규칙)
- fork default branch 다름 (upstream=master, self=main) → base는 upstream default만 맞추면 OK

### AGENTS.md outdated 위험 (TripleA 사례)
- AGENTS.md가 `./gradlew :game-app:game-headed:run` 명시했지만 실제로는 `:game-headed:build` (flat modules)
- **3분 빌드 낭비** 후 `./gradlew projects` 로 실제 확인
- **교훈**: AGENTS.md 첫 줄 신뢰 금지, 빌드 명령은 `./gradlew projects` + 실제 settings.gradle.kts 확인

### i18n 코드 literals vs resource bundles 구분
- TripleA: 12,628 strings 중 **ui.properties 59개만** properties 기반, 나머지는 Java String literals
- Evolve: 10,164 keys 모두 JSON (full i18n)
- Godot tr() 호출: 870개 tr() → 모두 .translation으로 i18n 가능
- **판별**: `find . -name "*.properties" -o -name "*.po" -o -name "*.json" -path "*lang*"` + `grep -r "tr("` 비교
- **결과**: literals 많으면 fork 가치 ↓ (translation patch PR이 너무 큼), resources만 있으면 가치 ↑

### 잠재량 vs 실측 가능량 분리 (2026-07-28, TripleA) ★★★
- 공식 문서 "12,628 strings"는 **잠재 string 수** (전체 Java String literals + properties + 포맷팅 후보)
- 실측 가능 신규 candidates: **약 1% (121)** — Swing 위젯 literal → `getText(...)` 치환으로 추가 가능한 것만
- **판별 명령**:
  - 현재 properties 키: `find game-app -name "*.properties" -path "*/i18n/*" | xargs grep -h '^[a-z]' | wc -l`
  - 신규 후보 Swing literal: `grep -rE 'new JMenu[A-Za-z]*Builder\("|JOptionPane\.show' --include="*.java" game-app | wc -l`
  - 이미 i18n 사용: `grep -rE 'I18nEngineFramework\.get\(\)\.getText\(' --include="*.java" game-app | wc -l`
- **결론**: 한국어 확장 PR 가치 평가할 때 **잠재량과 실측 가능량 분리**. 잠재량만 보고 "PR 너무 큼"으로 판단하면 안 됨

### Java ResourceBundle.Locale.lookup 함정 (2026-07-28)
- `Locale.lookup(ranges, available)`은 RFC 4647 lookup algorithm — `en-US;q=1.0` weight면 ko 매칭돼도 영어 우선
- TripleA 사례: `en-US;q=1.0, de-DE;q=0.5` → 시스템 locale이 ko여도 en_US로 fallback
- **증상**: `ui_ko.properties` JAR에 들어있고 시스템 locale ko_KR이어도 한국어 안 나옴
- **해상**: `Locale.getDefault().getLanguage()` 직접 매칭하는 `computeLocale()` 메서드
- **반드시 확인**: `Locale.lookup` 결과가 기대 locale인지 작은 Java probe로 검증 후 적용
- **reference**: `references/java-resourcebundle-locale-lookup-pitfall.md`

### Java 게임 properties → I18nResourceBundle 등록 4단계 (Phase 1)
- 4단계 모두 필요 (그중 하나만 빠지면 한국어 안 나온):
  1. `I18nResourceBundle.java`에 `Locale.KOREA` 등록 (`mapSupportedLocales.put`, `getSupportedLanguages`)
  2. `ui_ko.properties` 생성 (기존 ui_de.properties 형식 참고)
  3. `computeLocale()` 같이 `Locale.getDefault()` 직접 매칭 메서드 (Lookup 함정 회피)
  4. 빌드 후 `unzip -l shadow.jar | grep ui_.*properties` 로 JAR 포함 확인

### Java Swing i18n 확장 Phase 2+ (2026-07-28, TripleA) ★★★
- **`I18nResourceBundleTest` 자동 게이트**: 10자 이상 string이 EN과 동일 값이면 "번역 안 됨"으로 빌드 실패. **3개 언어 properties 동시 추가 강제** (EN/DE/KO 하나라도 빠지면 깨짐).
- **DE == EN 함정 (2026-07-28 LobbyFrame 사례)**: 독일어 번역이 영문과 정확히 동일하면 (`lobby.LobbyFrame.Title=TripleA Lobby`, 12자) 테스트가 실패. 브랜드명은 보존해야 하지만 테스트 게이트 통과 위해 **"TripleA-Lobby" 처럼 하이픈을 넣는 미세 변형** 필요. 단순히 영문 그대로 복사하면 빌드 깨짐. 헬퍼: `python3 -c "for k in en: if en[k]==de[k] and len(en[k])>10: print(k, en[k])"`
- **Lombok `@UtilityClass` 제약**: 인스턴스 필드 추가 불가 → `I18nEngineFramework.get().getText(...)` 직접 호출 또는 lambda 안에서 `final String title = ...` 지역 변수.
- **`static final String` + `getText()` 이니셜라이저 함정 (2026-07-28 PurchasePanel/RepairPanel 사례) ★**: `private static final String BUY = I18nEngineFramework.get().getText(...)` 패턴은 **빌드 에러** (`cannot find symbol variable I18nEngineFramework`). 이유: (1) static initializer는 클래스 로딩 시 평가되는데 `I18nResourceBundle`이 그 시점에 미로드이거나 (2) **import 누락** 가능성 (다른 패키지에서 `I18nResourceBundle` 사용한다고 import 안 했어도 자동으로 따라오지 않음). 해결: `private String buyLabel;` 인스턴스 필드로 변경 → **생성자에서 lazy 초기화**. `public static final`인 상수(LBL_UNITS_LEFT_TO_PLACE 등)는 외부 참조 보존 위해 인스턴스화 불가 → import 확인 후 그대로 사용 (런타임에 `I18nEngineFramework`이 main 시작 후 로드됨).
- **`import` 누락 패턴 (2026-07-28 PurchasePanel 사례)**: `I18nEngineFramework.get()`를 호출하는데 `import games.strategy.engine.framework.I18nEngineFramework;`가 없으면 컴파일 실패. **patch 시 import 추가 매트릭스 신중히 확인** — 다른 클래스가 같은 패키지에서 import 안 했어도 자동으로 따라오지 않음.
- **JOptionPane msg/title 키 분리 원칙**: 동일 string이라도 `.Msg` / `.Title` 접미사로 별도 키 — msg는 동사형, title은 명사형 (한국어 자연스러움).
- **ASCII-escape 한글 properties** (`\uc2dc\uc791` = "시작"): 기존 파일과 일관성. UTF-8 직접 입력 시 일부 빌드/IDE에서 깨짐. macOS 생성: `python3 -c "..."` 한 줄.
- **heredoc `\n` → 빈 라인 함정 (2026-07-28 D4-B 사례)**: `cat >> file.properties <<'EOF'` 안에 `ingame.X.MsgPrefix=\n` 라인이 있으면 heredoc이 다음 라인 시작을 새 라인으로 인식해 **`MsgPrefix=` (값 빈)** 상태로 들어감. **증상**: `i18n error: Key 'ingame.X.MsgPrefix' not translated into language 'ko_KR'` (한국어만 깨짐, EN/DE는 빈 값 통과). **회피**: heredoc 안에서 빈 값 만들지 말 것. 필요 시 `python3`로 직접 작성 + `replace("\n", "")` 후속 처리.
- **1파일 검증 → N파일 위임 패턴 (사용자 선호 = 직접 오케스트레이션, 칸반 X) ★★★**: 사람 손으로 1파일 proven template 만들고 → 내가 직접 워커 dispatch + 결과 검증. **사용자가 명시적으로 칸반 워커플로 거부 (2026-07-28, 두 번 강조)**: "칸반 작업의 만족도가 낮음. 칸반은 사용하지 말고, 필요하면 서브에이전트를 생성해서 직접 오케스트레이션하도록". 워커 표준 프롬프트에 5대 안전장치 필수: (1) 환경 `JAVA_HOME` 명시 (subagent 셸 자동 안 풀림) (2) 인코딩 utf-8 검증 (독일어 Latin-1 사고) (3) 메서드 이름 변경 금지 (Lombok getter 오타 사고) (4) 키 중복 방지 (5) 코드 보존 (`if/return/}/;` 절대 손대지 말 것).
- **워커 도구 호출 한도 패턴 (2026-07-28 B 워커 사례) ★**: 단일 워커에게 12파일 ~50 string 위임 시 tool calling 50회 한도로 **2-3개 파일만 처리 후 중단** (`api_calls=50, duration=329s`). **워크플로**: (1) 워커 1명에게 3-5파일 (~20-30 string) 위임 (2) 워커 종료 후 부모가 직접 나머지 처리 (3) **3+ 파일 + 30+ string은 1명이 못 끝냄**을 기본 가정. 분할 dispatch는 2-3명까지 가능하지만 properties 동시 수정 충돌 위험 큼.
- **워커 patch 사고 4종 (D4-B 실측) ★★★**:
  1. **삭제 사고**: `final JPanel panel = new JPanelBuilder()...` 패턴을 patch할 때 new_string이 `new JPanelBuilder()...`로 시작하면 `final JPanel panel = ` 라인이 통째로 사라짐. **증상**: 컴파일 에러 `cannot find symbol variable panel`. **회피**: patch old_string에 `final JPanel panel = ` 라인 포함
  2. **추가 사고**: 원본에 없는 `chooser.setTitle(message);` 라인을 patch가 추가했는데 `chooser` 변수가 그 scope에 정의 안 됨. **증상**: 컴파일 에러 `cannot find symbol variable chooser`. **회피**: patch new_string에 원본에 없는 라인 추가 금지
  3. **이름 변경 사고**: `ban.getEpochMillEndDate()`를 `ban.getEpochMilliEndDate()`로 "고치려는" 시도 → Lombok이 만든 메서드 이름 오타로 빌드 실패. **회피**: new_string에 메서드 호출은 원본과 정확히 동일하게
  4. **무단 추가 사고**: `ViewMenu.fitHeight`에 `ratio = Math.min(1, ratio);` 추가 — 빌드/테스트 통과하지만 동작 변경. **회피**: patch 후 `git diff` 직접 확인 + 라인 수가 늘었으면 의심
- **`installDist` 누락 함정 (2026-07-28)**: `:game-headed:compileJava` + `:game-headed:installDist`는 **별개 task**. compileJava만 돌리면 `build/install/game-headed/` 스크립트는 옛날 jar — properties만 갱신해도 메뉴바 한국어 안 보임. **반드시 `./gradlew :game-headed:installDist --rerun-tasks`로 jar 재생성 후 게임 실행**. 게임 실행: `build/install/game-headed/bin/game-headed`
- **ResourceBundle 런타임 probe (필수)**: i18n test 통과 ≠ 런타임 키 로딩 정상. 작은 Java probe로 `ResourceBundle.getBundle(...).getString(key)` 직접 호출 확인. EN/DE/KO 3개 모두 출력. **또한 한계**: 10자 이하는 EN==DE/EN==KO 검사 스킵되므로 짧은 라벨은 probe로 직접 확인 필수.
- **동시 다중 워커 / properties 충돌 함정 (D4-B 2026-07-28 실측) ★★★**: 같은 `ui.properties`를 두 명 이상의 에이전트가 동시에 patch 도구로 수정할 때, 한 쪽의 patch가 다른 쪽이 읽은 텍스트 위에 적용되어 **조용히 키 이름이 변형**되거나 라인이 누락됨. 빌드는 통과해서 며칠 뒤에야 발견되는 silent corruption. **회피**: (1) properties 파일은 단일 에이전트만 손대기 (별도 임시 파일 격리 → 마지막 머지) (2) 매 patch 직후 `read_file`로 anchor 라인 재확인 (3) patch 도구 warning에 "modified by sibling subagent" 메시지 뜨면 즉시 작업 중단 + 부모 보고 (4) 커밋 직전 `git diff <properties>` 첫/마지막 50줄 사람 눈으로 확인. **공개 상수 보존 원칙**: `public static final String ACTION_LABEL_*` 같은 상수는 호출 지점에서 `getText("ingame.X.Title")`로 직접 치환하고 **상수 자체는 보존** (외부 `switch case`/어노테이션 사용처 보존 위해).
- **reference**: `references/java-swing-i18n-scaling.md` (Phase 2+ 전체 워크플로우 — FileMenu 사례 + 우선순위 측정 + 커밋/PR 사이즈 전략 + installDist 함정 + 워커 표준 프롬프트 5대 안전장치 + 4종 patch 사고 + heredoc 빈 라인 함정)

### i18n 인프라 정찰 누락 (2026-07-28, BigJk/end_of_eden 실측) ★★★
- 번역 작업 시작 전 **i18n 로더 코드(system/localization/localization.go)를 먼저 읽지 않으면** 첫 PR이 잘못된 위치에 작성됨. 정찰해야 할 5가지: (1) Locale 코드 형식 (`ko` vs `ko-KR`) (2) 포맷 (YAML/JSON/properties/PO) (3) 키 구조 (nested vs flat) (4) Fallback 정책 (ko → en → key?) (5) 자동 폴더 스캔 패턴.
- **Go 게임 한정 — locale 코드 2글자 강제 함정**: `system/localization/localization.go`에 `if len(local) != 2 { return fmt.Errorf(...) }` 같은 검증 있으면 `ko-KR`/`ko_KR` 안됨 → `ko`만 가능. ko-KR로 작성하면 모든 키 silent fallback.
- **하드코딩 위치 분기**: Lua `name = l("cards.X.name", default)` 패턴 → YAML override 가능. Lua `name = "Waking up..."` 직접 하드코딩 → 별도 리팩토링 PR 필요. 두 가지를 구분하지 않고 시작하면 작업량 50% 잘못 추정.
- **첫 PR 가치 결정**: 5단계 정찰로 작업 범위 표 만들고 → 데이터 추가만 vs 로더 패치 포함 vs Lua 리팩토링 별도 분리. 메인테이너 거부 확률: 데이터 추가만 = 낮음, 로더 패치 = 중간, Lua 리팩토링 = 높음.
- **reference**: `references/i18n-architecture-reconnaissance.md` — 5분 5단계 reconnaissance 절차 + end_of_eden 실측 사례

### TUI 게임 스크린샷 검증 함정 (2026-07-28, BigJk/end_of_eden 실측) ★
- **bubble tea TUI는 PTY에서 ANSI escape sequence로 픽셀 단위 렌더링** → `script` 명령으로 캡처해도 텍스트 추출 불가. PTY 출력은 이스케이프 + 픽셀 데이터로 채워지고, 화면 단위 렌더링은 캡처되지 않음.
- **스크린샷 약속 금지**: 사용자가 "게임 실행 + 스크린샷" 요청할 때 TUI 게임이면 **시각 검증 단언 금지**. 대신 (1) 게임 빌드 성공 (2) i18n loader 단위 테스트로 키 검증 (3) YAML 스크립트 검증 + commit message에 "단위 테스트 통과, 시각 검증은 사용자 터미널 환경 의존" 명시.
- **macOS TUI 게임 폰트 함정 (예측 → 확인 결과)**: `cmd/game/main.go`(macOS TUI entrypoint)는 폰트를 로드 안 함. `cmd/game_win/main.go`(Windows ebitengine)만 폰트 로드. 즉 **macOS TUI는 시스템 터미널 폰트 사용** → `assets/fonts/`에 한글 폰트 추가해도 macOS TUI에서는 무용. Windows 빌드(`game_win`)에 영향. **판별**: `grep -n 'LoadFaces\|LoadFont\|Font' cmd/*/main.go`로 어느 entrypoint가 폰트 로드하는지 확인 후 폰트 작업 범위 결정.
- **대안 단위 테스트 패턴**: throwaway Go program + tempfile + `go run`. 실제 게임 빌드 안 해도 i18n 로더 통과 검증 가능. 118개 키를 1초 안에 검증.
- **PTY 후처리 검증 패턴 (2026-07-28 5차 보완) ★**: 사용자가 게임 직접 실행 후 PTY 로그 후처리:
  ```bash
  cat /tmp/eoe_ko.log | sed 's/\x1b\[[0-9;]*[mKHJABCDEsu]//g' | tr -d '\r' \
    | LC_ALL=en_US.UTF-8 grep -oE '[가-힣][가-힣 ,!?:.\-]*' | sort -u
  ```
  escape sequence 제거 + 한글만 추출. **LC_ALL=en_US.UTF-8 강제 필수** (macOS 기본 sed가 multi-byte에서 `illegal byte sequence` 에러). 검증 단어 예: "메인 메뉴", "완료!", "메인 메뉴", "게임 종료" 등.
- **reference**: `scripts/i18n-yaml-verify.sh` — Go 프로젝트에서 YAML i18n 키를 단위 테스트하는 패턴 (end_of_eden 검증에 사용)

### Go `internal/fs` 커스텀 fs wrapper의 `Stat` 부재 (2026-07-28 실측) ★
- 많은 Go 프로젝트가 `internal/fs` 같은 wrapper를 만들어 `ReadDir`, `ReadFile`, `WriteFile`, `Walk`만 노출하고 `Stat`은 빼버림. 폴더 존재 확인하려고 `fs.Stat(path)` 호출하면 컴파일 에러 `undefined: fs.Stat`.
- **해결**: `ReadDir` 호출 후 에러 체크. `if files, err := fs.ReadDir(dir); err == nil { ... }`. 에러가 나면 폴더 없는 것 → fallback.
- **패턴**: locale overlay 추가할 때 `if files, err := fs.ReadDir(localeDir); err == nil { for _, f := range files { ... } }` 한 줄로 끝. `info.IsDir()` 체크도 ReadDir 결과에는 불필요 (파일만 반환).
- **reference**: `references/i18n-architecture-reconnaissance.md` §Go 게임 한정: 자산 로더 locale overlay 패턴

### Commit message 범위 명시 (2026-07-28 best practice)
- i18n PR은 작업 범위가 빠르게 커짐 (YAML 추가 → 로더 패치 → Lua 리팩토링 → 데이터 overlay). 커밋 메시지에 **명시적으로 제외한 작업**을 적어야 메인테이너가 PR 리뷰 시 "이건 왜 안 했지?" 의문 없이 통과 가능.
- **패턴** (end_of_eden 3번째 커밋 본문):
  > Out of scope for this PR: event / narrative text in assets/scripts/events/act_0/*.lua is still hard-coded English. That text uses inline highlight() / highlight_warn() markers and lives inside Lua callbacks, so it needs a separate refactor PR to extract into the localization layer.
- **효과**: 리뷰어가 PR 전체 그림을 빠르게 파악 + 별도 PR 후보가 자연스럽게 분리됨 + main에 머지 후 다음 PR로 자연스럽게 연결

### "부분 번역 PR" 금지 — 사용자 명시 선호 (2026-07-28, BigJk/end_of_eden 4차) ★★★
- **사용자 지시 그대로 인용**: "아직 한글화 안된 부분이 너무 많아. 다시 확인하고, 100% 가까이 한글화 될 때 까지 PR금지".
- **함정 (3단계 진행으로 발생)**: 1차 PR (카드/UI 일부) → 2차 커밋 (cards 확장 + verify_ko.sh) → 3차 커밋 (gen.go locale overlay + 텍스트 파일) → **"PR 보내자" 시점에 사용자가 작업 중단**: 게임 직접 실행해보니 메뉴/이벤트/적 행동/UI 라벨이 거의 다 영문. 4번째 커밋이 이미 들어가 있었음.
- **이전 워크플로 함정**: "i18n 인프라 정찰 + 일부 번역 데이터 → 커밋 → PR 진행"을 기본으로 했는데, **사용자 선호는 "100% 근접까지 모은 다음 단일 PR"**. PR 보내기 시점을 작업량 30~40%에서 결정하면 안 됨.
- **올바른 신호**:
  - Phase 0 (스카우팅)에서 "X개 영역, Y개 키" 작업량 표 만들 때 → **사용자에게 "지금 PR 진행 vs 100% 기다림" 명시적 확인 받기** (사용자 선호는 100%, 하지만 사용자가 시간 압박 느끼면 부분 PR 허용할 수도 있음)
  - 진행 중에도 중간에 **"이 영역 끝나면 PR 보낼까요?" 같은 체크포인트 추가 금지** — 한 번 가닥 잡으면 끝까지 가는 게 사용자 만족도 ↑
  - **작업 범위 4대 축 모두 마치고 단일 PR**:
    1. i18n YAML 데이터 (cards/status_effects/artifacts/enemies/events/intents/ui/weapons)
    2. Lua 코드 l() 감쌈 (events, equipment, enemies, _util)
    3. 로더 패치 (Go game: `gen.go` locale overlay 같은)
    4. 비-i18n 데이터 파일 (`assets/gen/ko/*.txt` 등)
- **체크리스트 추가** (검증 체크리스트에):
  - [ ] **사용자에게 PR 진행 시점 확인 받음 (Phase 0에서 부분 vs 전체)**
  - [ ] **사용자가 게임 직접 실행해서 한 번 더 확인한 후 PR 진행 신호 줌**
  - [ ] 작업 범위 4대 축 모두 완료 후 PR
- **대안 (사용자 시간 부족 시)**: 작업 범위를 명확히 좁혀서 "1차 PR = 카드+UI (사용자 가장 자주 보는 영역), 2차 PR = 이벤트, 3차 PR = Go UI 라벨" 같이 **단계적 PR 계획을 처음부터 공유**. 사용자가 명시적으로 "1차 PR 진행" 신호 주면 진행. 사용자 모르게 단계 쪼개기 금지.

### YAML 배열 → 객체 평탄화 함정 (2026-07-28, BigJk/end_of_eden 실측) ★
- i18n YAML에 `choices: [{description: "..."}, {description: "..."}]` 처럼 **배열**로 저장하면, Go `localization.AddFile()`의 `walk` 함수가 점 표기(`choices.0.description`)로 평탄화하지 않음. 배열 키는 그냥 `choices` (slice) 그대로 남고 `events.MERCHANT.choices.0.description`로 `Get()` 호출 시 fallback (en 또는 key 자체)으로 빠짐.
- **증상**: 10개 키 `events.MERCHANT.choices.0.description` 등이 단위 테스트에서 FAIL (returned the key). YAML 자체는 valid.
- **해결 (코드 변경 없이 데이터만)**: YAML에서 명시적으로 객체 형태로:
  ```yaml
  choices:
    0.description: 거래한다
    1.description: 지나간다
  ```
  또는 Python yaml 처리 시 평탄화:
  ```python
  new_choices = {}
  for i, c in enumerate(orig_choices):
      for k, v in c.items():
          new_choices[f"{i}.{k}"] = v
      e['choices'] = new_choices
  ```
- **판별 명령**: YAML 파싱 후 `len(data['events'][eid]['choices'])` 가 리스트면 → 함정 매치. dict면 정상.
- **reference**: `references/i18n-architecture-reconnaissance.md` §i18n 로더가 walk 평탄화하는지 확인 단계 추가

### 사용자 직접 게임 실행 명령어 안내 패턴 (2026-07-28, end_of_eden 4차) ★★
- bubble tea TUI는 헤드리스 검증 불가 → 사용자가 **로컬에서 직접 실행해서 확인**하도록 명령어 안내하는 패턴이 자연스러움.
- **안내 명령어 세트**:
  ```bash
  cd /Users/mac/work/<repo>
  cat > settings_term.json <<'EOF'
  {
    "audio": true,
    "volume": 1,
    "language": "ko"
  }
  EOF
  ./build/<binary>
  ```
- **게임별 설정 파일 위치 확인 필수**: `grep -rn 'SettingsName\|SetDefault' cmd/`로 빌드 디렉토리에 어떤 `settings_*.json`이 생성되는지 확인. TripleA 사례: `settings_term.json` (cmd/game). **사용자가 어떤 파일을 수정해야 하는지 정확히 안내**.
- **게임 종료 키 안내**: 게임별 종료 키가 다름 (q / Ctrl+C / ESC). 빌드한 게임의 README나 main.go에서 quit handler 찾기.
- **추가 검증 명령** (사용자가 PR 보내기 전에 다시 돌릴 수 있게):
  ```bash
  go build -o ./build/<binary> ./cmd/<entrypoint>
  ./verify_<lang>.sh  # 단위 테스트 자동 검증
  ```
- **메모리 정책 준수**: push/PR은 사용자 명시 확인 후. 단, 게임 실행 자체는 사용자가 판단하는 영역 → 안내 후 대기.

### Go UI 하드코딩 라벨 일괄 처리 패턴 (2026-07-28, end_of_eden 5차) ★★★
- **문제**: Go 코드 (`ui/menus/*/*.go`, `cmd/*/main.go`)에 UI 라벨이 **Render("Settings")**, **`fmt.Println("Initializing Audio. Please wait...")`** 형태로 **영문 하드코딩**되어 있음. 24+개 라벨이 사용자 시야에 보임.
- **처리 패턴 3단계**:
  1. **영문 Render/Println 추출**:
     ```bash
     grep -rhn 'Render("[A-Z]' ui/ cmd/  # Render() 안 영문
     grep -rhn 'fmt.Println("[A-Z]' cmd/  # init 메시지
     ```
  2. **`localization.G("ui.X.key", "English default")` 패턴으로 감싸기**:
     ```go
     // Before
     m.list.Title = "Settings"
     fmt.Println(loadStyle.Render("Initializing Audio. Please wait..."))
     // After
     m.list.Title = localization.G("ui.settings.title", "Settings")
     fmt.Println(loadStyle.Render(localization.G("ui.init.audio", "Initializing Audio. Please wait...")))
     ```
  3. **YAML에 한국어 추가**:
     ```yaml
     ui:
       settings:
         title: 설정
       init:
         audio: 오디오 초기화 중. 잠시만 기다려 주세요...
         settings: 설정 초기화 중. 잠시만 기다려 주세요...
         proc_gen: 생성기 초기화 중. 잠시만 기다려 주세요...
         localization: 다국어 초기화 중. 잠시만 기다려 주세요...
         done: 완료!
       title: End Of Eden
     ```
- **import 추가**: `localization`이 없는 파일에는 `import "github.com/<owner>/<repo>/system/localization"` 한 줄 추가. 의존성 cycle 없으면 OK (system/localization은 internal/fs만 의존).
- **순서 중요**: import 먼저 추가 → LSP unused import 경고 → 사용처 patch → unused warning 사라짐. **순서 거꾸로 하면** patch가 import 없는 함수를 호출하려 해서 Go는 사용 안 한 import를 죽이지만 patch 결과는 OK.
- **render vs init 메시지 분리**:
  - `Render()` 안 → UI 라벨 (`ui.menu.*`, `ui.merchant.wares`, `ui.gameview.intend` 등) — 게임 화면에 표시
  - `fmt.Println()` 안 → init/boot 메시지 (`ui.init.*`, `ui.title`) — 게임 시작 시 잠깐 표시
  - 둘 다 같은 `localization.G()` 처리
- **작업량 측정**: 한 세션에 24개 라벨 + 6개 init 메시지 = 30개 라벨 일괄 처리. 각 라벨당 ~3줄 (구문 1줄 + YAML 키 1줄 + 한국어 값 1줄). **평균 2분/라벨** = 1시간.
- **검증**:
  ```bash
  go build -o ./build/<binary> ./cmd/<entrypoint>
  # 사용자 직접 실행 + 화면에 "메인 메뉴", "완료!" 등 표시 확인
  ```
  **TUI 게임에서 화면 텍스트 추출**: `cat /tmp/eoe_ko.log | sed 's/\x1b\[[0-9;]*[mKHJABCDEsu]//g' | tr -d '\r' | grep -oE '[가-힣][가-힣 ,!?:.\-]*' | sort -u` — escape sequence 제거 + 한글만 추출 → "메인 메뉴", "완료!" 같은 표시 확인.
- **Fallthrough**: `init.Done` 같은 5번 반복되는 "Done!"도 단일 키로 처리 (replace_all=true).

### 4대 축 통합 워크플로 (2026-07-28, end_of_eden 5차 종합) ★★★
- **문제**: 게임/i18n 프로젝트에서 **localizable text가 4곳에 분산**:
  1. **i18n YAML** (cards, status_effects, artifacts, enemies, events) — YAML override로 처리
  2. **Lua 하드코딩** (equipment descriptions, enemy intents, event descriptions) — `l()` 헬퍼로 감싸기
  3. **Go UI 하드코딩** (메뉴 라벨, init 메시지) — `localization.G()` 로 감싸기
  4. **비-i18n 텍스트 파일** (`assets/gen/*.txt`, `assets/data/*.txt`) — locale overlay loader로 폴더별 분리
- **작업 순서** (각 축 완료 후 다음 축 진행):
  1. **축 1: i18n YAML 데이터** — 가장 안전 (메인테이너 거부 확률 최저)
  2. **축 2: Lua `l()` 감쌈** — 호출 패턴 기존 (`name = l("cards.X.name", default)`)이 이미 있으면 일괄 적용
  3. **축 3: 비-i18n 텍스트 파일 + locale overlay loader** — loader 패치 1개 + 폴더별 데이터 추가
  4. **축 4: Go UI 라벨** — localization import 추가 + Render/Println 감싸기 (cycle 위험 검증 후)
- **각 축 작업량 추정**: 축 1 (1-2시간) / 축 2 (1-2시간) / 축 3 (1시간) / 축 4 (1시간). **총 4-6시간**.
- **축 4의 cycle 위험 검증**: import 하기 전 `grep -l "github.com/BigJk/end_of_eden" system/localization/` 같은 명령으로 system/localization이 다른 어떤 BigJk/end_of_eden 패키지를 import하지 않는지 확인. `system/localization → internal/fs` 단일 의존이면 모든 ui/cmd 패키지에서 안전하게 import 가능.
- **축 2의 patch 순서**: `name = "X"` → `name = l("KEY", "X")` 단순 patch 100+개 가능. 단, **`state = function(ctx) return "X" ..` 같은 콜백 안**의 string은 다른 변수와 결합되어 있어서 단순 patch 어려움 → `l()` 첫 호출로 분리: `return l("KEY", "X") .. highlight(...)`.
- **축 4의 render vs fmt.Println 차이**: Render는 함수의 인자로 들어가는 단일 string이라 직접 `localization.G()` 감쌈 OK. fmt.Println은 함수 호출 자체가 아니라 인자라 `fmt.Println(localization.G("...", "..."))` 식으로 한 단계 깊어짐. 단, `loadStyle.Render(...)` 안에서 `localization.G()` 호출하면 됩니다.

### patch 도구 4줄+ 함정 + multi-line 덮어쓰기 사고 (2026-07-28, end_of_eden 5차 실측) ★★
- **증상 (lua_error.go 실측)**: patch가 old_string을 new_string으로 교체할 때, **new_string에 old_string의 일부만 들어가고 나머지 라인이 중복**되어 syntax 에러 (`missing ',' before newline in argument list`).
- **원인**: old_string이 multi-line이고 patch가 new_string에 의도하지 않게 첫 줄만 교체 → 결과 파일에 라인이 2개로 중복 (예: `fmt.Sprintf(ErrorFormat, style.RedText.Copy()...)` + `fmt.Sprintf(ErrorFormat, style.RedText.Copy()...)` 2번).
- **회피 패턴**:
  - **multi-line patch 전후로 read_file로 파일 확인** — line count 변했는지
  - new_string이 old_string보다 **단순히 어떤 부분만 교체**하는 형태면 OK
  - new_string이 old_string 전체를 포함 + 새 내용 추가면 OK
  - new_string이 old_string과 비슷한 형태지만 **다른 부분**이면 syntax 에러 위험 ↑
- **사례** (lua_error.go 잘못된 patch):
  ```diff
  -		fmt.Sprintf(ErrorFormat, style.RedText.Copy().Bold(true).Render("Lua Error!"), `
  +		fmt.Sprintf(ErrorFormat, style.RedText.Copy().Bold(true).Render("Lua Error!"), `
  +fmt.Sprintf(ErrorFormat, style.RedText.Copy().Bold(true).Render(localization.G(...)), `
  ```
  결과: 2줄이 그대로 살아있어 syntax 에러.
- **수정**: 새 patch로 정확히 교체:
  ```diff
  -		fmt.Sprintf(ErrorFormat, style.RedText.Copy().Bold(true).Render("Lua Error!"), `
  -If you want to report this error please use "Copy Clipboard"
  +		fmt.Sprintf(ErrorFormat, style.RedText.Copy().Bold(true).Render(localization.G(...)), `
  +If you want to report this error please use "Copy Clipboard"
  ```
  old_string에 전체 4줄 다 포함 + new_string에서 첫 줄만 `localization.G()` 적용.
- **판별 명령**: patch 후 `go build` 실패 시 syntax 에러 → 즉시 의심. `git diff <file>`로 라인 수 비교 + 첫/마지막 30줄 확인.

### YAGNI 원칙 — "100% 한글화" 의도 해석 (2026-07-28, end_of_eden 5차 후속)
- **사용자 명시**: "100% 가까이 한글화 될 때 까지 PR금지".
- **해석**: 정확히 100% 안 해도 됨, **사용자 시야의 모든 한글이 100%에 가까워야 함**. 즉 (1) 게임 메인 화면에서 보이는 영문이 (2) 디버그/내부 텍스트가 아니라 사용자 의도된 표시여야 함.
- **판별 기준**:
  - ✅ 번역 대상: 메뉴, 카드, 적, 상점, 로딩 힌트, 게임 내 라벨
  - ❌ 번역 제외: 디버그 로그 (`log.Println("...")`), test 함수 내 assertion 메시지 (`"Card not in hand"`), 코멘트 (`---`), 도큐먼트 (`docs/`), README, AGENTS.md
- **증거**: 사용자 게임 실행 후 화면 텍스트 추출했을 때 한글 메뉴 + 한국어 카드/적 + 영문 init 메시지가 보였음. 사용자가 init 메시지 영문도 추가 처리 신호 주면 그때 처리 (실제로 5차에서 처리 완료).
- **YAGNI over-application 방지**: 사용자가 "100%"라고 해도 의미 없는 텍스트까지 강제 번역하면 작업 낭비. 핵심 영역 (사용자 시야) 우선 처리 후 사용자 신호 받으면 그때 더 추가.

### 사용자 게임 실행 → 반복 추가 발견 패턴 (2026-07-28 4-5차, BigJk/end_of_eden verified) ★★★
- **현상**: 단위 테스트 239 PASS + PTY 검증으로 "메인 메뉴", "완료!" 확인 → 사용자 실제 실행 → "아직 한글화 안된 부분이 너무 많아" + "튜토리얼은 아직 한글화가 안되어 있음" + "메인메뉴의 정보도 한글화 안되어 있음" 같은 반복 신호.
- **원인 4가지**:
  1. **튜토리얼이 별도 폴더에 있음**: `assets/tutorial/tutorial.lua` — 메인 `assets/scripts/`와 분리되어 스캔에서 누락
  2. **메뉴 정보가 정적 변수로 박혀있음**: `ui/title.go`의 `var About = "..."`처럼 단순 변수는 `grep 'Render("...")'`로 안 잡힘
  3. **다중 entrypoint**: `cmd/game/main.go`만 처리했는데 `cmd/game_wasm/`, `cmd/game_win/`도 동일한 init 메시지 보유
  4. **5축 누락**: YAML + Lua `l()` + Go `localization.G()` + 텍스트 파일 + **별도 자산 폴더 (tutorial 등)**
- **대응 패턴**:
  - **5축 + 추가 자산 폴더** 스캔 단계 추가 (Phase 6 reconnaissance 확장):
    ```bash
    # 1. i18n YAML (기존)
    find assets/locals -name "*.yml" 2>/dev/null
    # 2. Lua l() 헬퍼 (기존)
    grep -rl 'register_\(card\|enemy\|event\)' assets/scripts/ 2>/dev/null
    # 3. Go Render/Println (기존)
    grep -rn 'Render("[A-Z]\|fmt.Println("[A-Z]' ui/ cmd/ 2>/dev/null
    # 4. 비-i18n 텍스트 파일 (기존)
    find assets/ -name "*.txt" -not -path "*/locals/*" 2>/dev/null
    # 5. 별도 자산 폴더 (NEW) — 게임별 변동
    ls assets/  # tutorial/, mods/, scenes/, etc.
    find . -name "*.lua" -not -path "./.git/*" | xargs grep -l "register_" 2>/dev/null
    # 6. 정적 변수 (NEW) — 단순 string 변수도 user-visible
    grep -rE '^var [A-Z][a-zA-Z]+ = `' *.go ui/ cmd/ 2>/dev/null
    # 7. README/AGENTS.md에 언급된 사용자 시야 자산 (NEW)
    grep -E '^\s*[-*] ' README.md AGENTS.md 2>/dev/null | grep -iE 'tutorial|about|info|menu'
    ```
  - **사용자 발견 후 자동 다음 작업**: 사용자가 "X 영역 안 됨" 신호 → 5축 + 6·7번 스캔 즉시 재실행 → 누락 영역 일괄 처리 → 5분 안에 보고
  - **메모리 기록**: 작업 진행 시 5축 + 추가 자산 폴더 SSoT 유지. "100%" 라고 사용자 시야 정의도 같이.
- **교훈**: 단위 테스트가 PASS여도 사용자 시야의 모든 화면을 자동 검증하긴 어려움. **PTY 검증 + 사용자 직접 실행**으로 1차 거른 뒤에도 누락 발견 가능. **한 번에 모든 영역 발견하려 하지 말고, 사용자 피드백으로 발견되는 영역을 즉시 처리하는 워크플로가 자연스러움**.

### 정적 변수 → 함수 리팩토링 패턴 (2026-07-28, ui/title.go verified) ★★
- **문제**: `ui/title.go`의 `var About = "long english text..."`처럼 정적 변수로 박혀있으면 `localization.G()` 호출 못함.
- **패턴** (3단계 리팩토링):
  ```go
  // Before: 정적 변수
  var About = `Welcome to a world 500 years in the future, ...`

  // After: 함수로 변환
  func AboutText() string {
      return localization.G("ui.about_text", "Welcome to a world 500 years in the future, ...")
  }
  ```
- **호출 측 변경**: `ui.About` → `ui.AboutText()` (모든 사용처에서 함수 호출로 변경)
- **YAML 추가**:
  ```yaml
  ui:
    about_text: '미래 500년 뒤, 기후 변화와 핵전쟁으로 황폐화된 세계에 오신 걸 환영합니다...'
  ```
- **호출 측 grep 명령**:
  ```bash
  grep -rn 'ui\.About\b' ui/ cmd/ --include="*.go"
  # → ui.AboutText() 로 일괄 변경 (replace_all 패턴)
  ```
- **검증 단계**: `localization.G()` 함수가 runtime에 호출되므로 `localization.SetCurrent("ko")` 이후에만 한국어 반환. 단위 테스트는 `SetCurrent("ko")` 호출 후 `AboutText()` 직접 호출해서 검증:
  ```go
  localization.Global.AddFolder("./assets/locals")
  localization.SetCurrent("ko")
  v := ui.AboutText()
  if v == "" || strings.HasPrefix(v, "Welcome") { panic("fallback") }
  ```
- **적용 가능한 다른 패턴**: `var Title`, `var Description`, `var Help`, `var Intro` 등 단순 문자열 변수. 모두 `func Text() string { return localization.G(...) }` 패턴으로 통일 가능.
- **호출 측 부작용 없음**: 기존 `ui.Title`는 그대로 두고 추가 변수만 함수화. 메인테이너 거부 확률 ↓.

### 다중 entrypoint 처리 함정 (2026-07-28, cmd/game/*/main.go verified) ★
- **현상**: 게임에 여러 entrypoint (`cmd/game/`, `cmd/game_wasm/`, `cmd/game_win/`)가 있고 각각 `init` 메시지가 중복으로 박혀있을 때, 하나만 처리하면 다른 빌드에서 한국어 안 보임.
- **판별 명령**:
  ```bash
  grep -rln 'fmt.Println.*"[A-Z]' cmd/ --include="*.go"
  # → 모든 entrypoint의 init 메시지 매니페스트 출력
  ```
- **처리 패턴**: 각 entrypoint마다 동일한 `localization.G()` 적용 + YAML 키 한 번만 추가 (locale overlay가 모든 빌드 공유).
- **end_of_eden 사례**: `cmd/game/main.go` 처리 → `cmd/game_wasm/main.go`와 `cmd/game_win/main.go`는 동일 영문 그대로 남음. 사용자 PR 보내기 전 자동 처리 권장.
- **권장**: 5축 스캔 시 `cmd/*/main.go` 모두 매니페스트 + 처리. 또는 PR 본문에 "Desktop version만 처리, Web/Windows는 follow-up PR" 명시 (사용자 신호 받으면 follow-up).
- **PTY 검증 범위**: macOS TUI 빌드는 `cmd/game/`만 검증 가능. wasm/win 빌드는 헤드리스 검증 어려움 → 단위 테스트 + 빌드 통과로 충분.

### PTY 직접 실행 vs PTY 캡처 검증 차이 (2026-07-28 5차 verified) ★★
- **문제**: 에이전트가 PTY에서 캡처한 텍스트와 사용자가 직접 화면에서 보는 텍스트가 다를 수 있음. 두 검증 모두 필요.
- **PTY 캡처 검증** (에이전트):
  ```bash
  script -q /tmp/eoe_ko.log ./build/end_of_eden < /dev/null
  cat /tmp/eoe_ko.log | sed 's/\x1b\[[0-9;]*[mKHJABCDEsu]//g' | tr -d '\r' \
    | LC_ALL=en_US.UTF-8 grep -oE '[가-힣][가-힣 ,!?:.\-]*' | sort -u
  ```
  - 한글 추출: "메인 메뉴", "완료!" 등
  - **한계**: bubble tea TUI는 픽셀 모드 렌더링이라 텍스트 추출 불가. ANSI escape + 셀 좌표만 캡처됨.
- **사용자 직접 실행** (사용자):
  ```bash
  cd /Users/mac/work/<repo>
  cat > settings_term.json <<'EOF'
  {"audio": true, "volume": 1, "language": "ko"}
  EOF
  ./build/<binary>
  # 게임 안에서 직접 화면 보면서 한글이 깨졌는지 확인
  ```
  - **장점**: 실제 사용자 시야 그대로 검증. 폰트 깨짐(tofu), UI 레이아웃 깨짐, 메시지 잘림 등 확인 가능.
  - **한계**: 사용자가 직접 돌려야 함. 에이전트 자동 검증 불가.
- **협업 패턴**:
  1. 에이전트가 단위 테스트 + 빌드 + PTY 캡처 자동 검증
  2. **사용자에게 게임 직접 실행 명령어 안내**
  3. 사용자가 발견한 누락 영역을 에이전트에게 다시 요청
  4. 에이전트가 누락 영역 처리 + 재검증
  5. 100% 사용자 시야가 한국어가 될 때까지 2-3 반복
- **사용자 안내 시 포함 명령어** (end_of_eden 사례):
  ```bash
  cd /Users/mac/work/end_of_eden
  cat > settings_term.json <<'EOF'
  {"audio": true, "volume": 1, "language": "ko"}
  EOF
  go build -o ./build/end_of_eden ./cmd/game
  ./build/end_of_eden
  # 종료: q 또는 Ctrl+C
  ```
- **메모리 정책 준수**: 게임 실행 + 화면 확인은 사용자 영역. 에이전트는 안내 + 대기. push/PR은 명시 신호 후.

### ModPack vs Locale overlay 비교 (2026-07-28, end_of_eden 5차 종합) ★★
- **ModPack 패턴**: 게임이 `mods/` 폴더 자동 스캔 → mod 파일이 원본 데이터 덮어쓰기. 메인테이너가 PR 안 해도 사용자가 별도 설치.
- **Locale overlay 패턴**: 로더가 `<lang>` 폴더 자동 스캔 → locale 데이터가 원본 덮어쓰기. 코드 1줄 변경 + locale별 폴더만 추가.
- **선택 기준**:
  - 게임이 이미 mods 시스템 있음 → modpack (코드 변경 0)
  - 게임이 locale 시스템 있거나 추가 쉬움 → locale overlay
  - 둘 다 없음 → 1줄 추가 (end_of_eden `gen.go`가 이 패턴)
- **end_of_eden 패턴** (참고용 — 가장 작은 침습):
  ```go
  // Before: 1 line init
  // After: +12 lines (locale overlay)
  locale := localization.GetCurrent()
  localeDir := "./assets/gen/" + locale
  if localeFiles, localeErr := fs.ReadDir(localeDir); localeErr == nil {
      for _, file := range localeFiles {
          if !file.IsDir() && strings.HasSuffix(file.Name(), ".txt") {
              bytes, _ := fs.ReadFile(localeDir + "/" + file.Name())
              data[strings.Split(file.Name(), ".")[0]] = strings.Split(string(bytes), "\n")
          }
      }
  }
  ```
  호출 측 변경 0 (`gen.GetRandom("loading_lines")` 그대로). fallback 시 영문 동작 동일.

### Java Swing 데스크탑 게임 빌드/실행 (TripleA 사례)
- **JDK 버전**: AGENTS.md가 outdated일 수 있음 → 실제로 `cat build.gradle.kts | grep -i javaVersion` 확인
- TripleA: AGENTS.md는 Java 17 명시, 실제는 **JDK 25** 필수 → `brew install openjdk@25`
- **빌드 명령**: `./gradlew projects` 먼저 실행해서 실제 module path 확인
  - AGENTS.md는 `:game-app:game-headed:run` (outdated), 실제는 `:game-headed:build` (flat modules)
- **빌드 시간**: 첫 빌드 1.5-3분, incremental 30-40초 (Gradle daemon 활용)
- **shadow JAR**: `./gradlew :game-headed:build` → `game-app/game-headed/build/libs/game-headed-*.jar` (42MB)
- **실행**: `java -jar game-headed-*.jar` (Swing UI 자동 실행)
- **빌드 함수꼭 확인**:
  - `--add-opens java.base/java.lang=ALL-UNNAMED` (JDK 17+ 필수)
  - `-Duser.language=ko -Duser.country=KR -Dfile.encoding=UTF-8`
- **Kotlin metadata 중복 경고**: 무해 (shadow plugin default warn)

## 6단계 빌드 환경 분류

| 🟢 | 빌드 도구 | fork 가치 | 예시 |
|---|---|---|---|
| 🟢 | npm/yarn/pnpm | 최고 (5분 빌드) | Evolve, 브라우저 게임 |
| 🟢 | Lua (LÖVE) | 최고 | SNKRX, youtd2 |
| 🟡 | Java/Gradle | 중간 (15-25분) | TripleA, Cataclysm-BN |
| 🟡 | C#/.NET | 중간 | Shattered Pixel Dungeon |
| 🟠 | Rust/cargo | 낮음 (20-40분 + 빌드 에코시스템) | Veloren |
| 🔴 | C++/CMake/Boost | 매우 낮음 (90분+ 함정) | Wesnoth, OpenRA |

## 모드팩 패턴 (NoBuildDependencies i18n)

**핵심**: fork가 아닌 **modpack** 또는 **theme override**로 fork 가치 유지하면서 upstream 호환.

- LÖVE: `lang/<code>.lua` + `T()` helper
- Three.js: `paintMenu()` 양방향 + `last-wins` export
- Next.js: `sub` + `pure 양` (key/value export)
- Godot: `texts.csv`에 `ko` 컬럼 추가 + `texts.ko.translation` 자동 생성
- Java/.properties: `I18nResourceBundle.java`에 Locale 등록

## 워커 위임 시 주의 (메모리 참조)

- **사용자 명시 선호 (2026-07-28): "칸반 작업의 만족도가 낮음. 칸반은 사용하지 말고, 필요하면 서브에이전트를 생성해서 직접 오케스트레이션하도록"**. **칸반 워커플로 X** — todo는 내가 추적, 워커는 직접 dispatch.
- **워크플로**: 사람 손으로 1파일 proven template → 워커 dispatch (5대 안전장치 + 작업 범위 한정) → 사람 손으로 5단계 verification gauntlet → 사람 손으로 커밋. 워커 보고만 신뢰 ❌.
- **워커 표준 프롬프트 5대 안전장치 (2026-07-28 검증)**:
  1. **환경 `JAVA_HOME` 명시** (subagent 셸에서 자동 안 풀림): `export JAVA_HOME=/opt/homebrew/Cellar/openjdk@25/25.0.4/libexec/openjdk.jdk/Contents/Home && export PATH=$JAVA_HOME/bin:$PATH` 매 빌드 명령 앞에
  2. **인코딩 utf-8 검증** (독일어 Latin-1 손상 — `Vollst�ndige` 사례): `python3 -c "..."` 각 properties 작성 직후 + 종료 직전
  3. **메서드 이름 변경 금지** (Lombok getter 오타 — `getEpochMillEndDate` 사례): new_string에 메서드 호출 시 원본 그대로
  4. **키 중복 방지** (`awk '!seen[$0]++'`로 dedup 필수): 추가 전 `grep "^<prefix>\." ui.properties | sort -u`로 확인
  5. **코드 보존**: `if/return/}/;` 절대 손대지 말 것, patch 후 `git diff` 직접 확인
- **Java 게임 installDist 함정**: `:game-headed:compileJava` + `:game-headed:installDist`는 **별개 task**. properties만 갱신하고 compileJava만 돌리면 메뉴바 한국어 안 보임 — **반드시 `./gradlew :game-headed:installDist --rerun-tasks`**로 jar 재생성
- **워커 분할 dispatch**: 단일 워커 1명에게 100+ string 맡기면 위험. 2-3명 분할, **각자 겹치지 않는 키 prefix** 부여
- **자격/봉쇄 영역 사전 정직 보고** (외부 PR 자동 push, OAuth 토큰, Vercel_TOKEN 등)
- `"OK 예감" 자신감 표현 금지` → 막히면 솔직히 보고 + 대안 3개

## Related references (전체 목록)

<details>
<summary>50+ references 파일 (클릭하여 펼치기)</summary>

### 빌드 환경별 fork 워크플로
- `references/love-game-fork.md`, `references/love2d-game-fork.md`, `references/love-lua-game-fork.md`
- `references/love2d-cross-platform-distribution.md`, `references/love-windows-zip-build-pitfalls.md`
- `references/threejs-browser-game-fork.md`
- `references/i18n-nobuild-js-pattern.md`, `references/webapp-i18n-render-verification.md`
- `references/godot-4-i18n-preflight.md`
- **`references/godot-4-i18n-po-fork-workflow.md` (2026-07-28)** — `godot_dialogue_manager` 166 msgid 한국어화 실측. fork 3단계 분해, POT escape regex, headless 검증 스모크, `git restore project.godot` 자동 변경 분리
- `references/game-engine-po-localization.md`, `references/closed-source-artifact-blocker.md`
- `references/django-ui-localization.md`
- **`references/java-swing-i18n-scaling.md` (2026-07-28, Phase 2+ 확장)** — TripleA FileMenu 사례 기반 Java Swing i18n 적용/위임 패턴

### Open Core / 빌드 함정
- `references/open-core-fork-pitfall.md`, `references/open-core-preflight-checklist.md`
- `references/closed-source-artifact-blocker.md`
- `references/athena-crisis-variants-nkzw-dummy-pitfall.md`, `references/athena-crisis-korean-fork.md`
- `references/athena-crisis-kr-offline-build-verification.md`
- `references/athena-crisis-fbtee-batch-translation.md`, `references/athena-crisis-autobattle-and-fbtee.md`
- `references/athena-crisis-open-core-pitfall.md`
- `references/static-asset-game-preflight.md`, `references/macos-pip-pep668-pitfall.md`

### 후보 스카우팅 / 검색
- `references/game-fork-candidate-survey-workflow.md`
- `references/cjk-game-search-workflow.md`
- `references/build-environment-preflight-check.md`
- **`references/i18n-architecture-reconnaissance.md` (2026-07-28, BigJk/end_of_eden)** — i18n 로더 코드 5단계 정찰 + Go 게임 한정 locale overlay 패턴 + 작업 범위 분류 (데이터 추가 vs 로더 패치 vs Lua 리팩토링)
- **`references/four-axis-i18n-workflow.md` (2026-07-28, BigJk/end_of_eden 5차)** — 4대 축 통합 워크플로: i18n YAML + Lua l() + Go localization.G() + 비-i18n 텍스트 파일. 축별 작업량 추정 + 의존성 cycle 검증 + 순서 결정

### PR / 배포
- `references/github-pr-cross-fork-pitfalls.md` (2026-07-28)
- `references/vercel-auto-deploy-korean-locale.md`
- `references/vercel-auto-deploy-import-once.md`
- `references/release-confirmation-workflow.md`

### 성공 사례 (verified)
- `references/snkrx-clone-success.md`
- `references/sango-rising-dragons-success.md`
- `references/evolve-kr-boot-pitfalls.md`
- `references/evolve-kr-deploy-pitfalls.md`

### 번역 / LLM 파이프라인
- `references/direct-llm-dict-translation-pipeline.md`
- `references/opencode-batch-translation.md`
- `references/prompt-auto-translation.md`
- `references/korean-persona-seed-pattern.md`
- `references/llm-max-tokens-pitfall.md`, `references/llm-markdown-response-parsing.md`

### 기타 보조
- `references/nim-api-key-500-pitfall.md`, `references/nim-llm-backend-swap.md`
- `references/git-large-storage-pitfall.md`
- `references/love2d-option-state-persistence.md`
- `references/korean-simulation-verification.md`, `references/two-terminal-sim-execution.md`
- `references/embedding-validation-50-cases.md`, `references/korean-embedding-benchmarks.md`
- `references/asymmetric-embedding-pattern.md`
- `references/sim-diagnostic-lookup.md`
- `references/apache-2-0-modified-md-template.md`
- `references/release-confirmation-workflow.md`
- `references/java-resourcebundle-locale-lookup-pitfall.md`

### 검증 스크립트
- `scripts/verify_lua_syntax.py`
- `scripts/stats.py`
- `scripts/detect_utf8_byte_iteration.py`
- `scripts/fill_empty.py`
- `scripts/release_github_template.sh`
- `scripts/static-game-boot-probe.sh`
- `scripts/verify_windows_zip.sh`
- `scripts/build_macos_app_template.sh`
- `scripts/build_love_template.sh`
- `scripts/java-i18n-locale-probe.sh` (Locale.lookup 함정 진단, Java 게임용)
- **`scripts/i18n-yaml-verify.sh` (2026-07-28, BigJk/end_of_eden)** — Go 프로젝트 YAML i18n 키 throwaway program + `go run` 단위 검증 패턴 (게임 빌드 없이 100+ 키 1초 안에 검증)
- **`scripts/pty-screen-text-extract.sh` (2026-07-28 5차)** — bubble tea TUI PTY 로그에서 escape sequence 제거 + 한글/영문 추출 검증

## 검증 체크리스트 (전체)

- [ ] Pre-flight 5축 모두 5분 내 통과
- [ ] **i18n 인프라 정찰 5단계 완료** (로더 코드 읽고 locale 코드 형식/포맷/키 구조/fallback/자동 스캔 패턴 파악)
- [ ] 작업 범위 표 작성 (데이터 추가 vs 로더 패치 vs Lua 리팩토링 분리)
- [ ] **4대 축 통합 분류** (i18n YAML + Lua l() + Go localization.G() + 비-i18n 텍스트 파일)
- [ ] Open Core 7시그널 0개 (또는 명시적 결정)
- [ ] 라이선스 코드/에셋 분리 확인 + LICENSE.MODIFIED 작성
- [ ] CLA 없음 (또는 fork-first 결정)
- [ ] 빌드 환경 1단계 분류 완료
- [ ] 한국어 1차 번역 데이터 작성 (작업량 추정)
- [ ] **잠재량 vs 실측 가능량 분리** (PR 가치 평가 — 공식 문서 수치 그대로 믿지 말 것)
- [ ] **3언어 properties 동시 추가** (Java/Gradle i18n — 한 언어만 추가 시 test 깨짐)
- [ ] **YAML i18n 단위 테스트 통과** (`scripts/i18n-yaml-verify.sh` 또는 동등한 throwaway Go program 검증)
- [ ] **TUI 게임이면 시각 검증 약속 안 함** — 단위 테스트 + PTY 텍스트 추출 검증으로 PR 가치 입증
- [ ] **PTY 텍스트 추출 검증** (사용자 직접 실행 + 로그 후처리) — "메인 메뉴", "완료!" 등 한글 단어 확인
- [ ] PR cross-fork 함정 우회 (URL 직접 또는 UI "compare across forks")
- [ ] PR 머지 가능성 80%+ (작은 변경 + Demo URL)
- [ ] **Commit message 범위 명시** (이번 PR에서 제외한 작업 + 별도 PR 후보 명시)
- [ ] **PR 진행 시점 사용자 명시 확인** (Phase 0에서 "부분 PR vs 100% 기다림" + 게임 직접 실행 후 신호 대기)
- [ ] **YAML 배열 → 객체 평탄화 확인** (`choices: [{description: "..."}]` 형태면 점 표기로 변환 — walk 함수가 평탄화 안 함)
- [ ] **5축 + 별도 자산 폴더 스캔** (튜토리얼/mods/같은 별도 폴더, README에 언급된 자산) — 사용자 발견 전 미리 잡기
- [ ] **정적 변수 → 함수 리팩토링** (단순 `var X = "..."` 변수는 `func XText() string { return localization.G(...) }`로 변환)
- [ ] **다중 entrypoint 처리** (`cmd/game/`, `cmd/game_wasm/`, `cmd/game_win/` 등 모든 entrypoint의 init 메시지 동일 처리)
- [ ] **사용자 직접 실행 안내 + 반복 발견 워크플로** (PTY 검증 + 사용자 직접 실행 → 누락 발견 → 즉시 처리, 100% 근접까지)
- [ ] **사용자 게임 직접 실행 명령어 세트 제공** (cd → settings_*.json 설정 → ./build/binary → 종료키 안내)
- [ ] **Go UI 라벨 일괄 처리** (Render/Println 추출 → `localization.G()` 감싸기 → YAML 키 추가 → 빌드 + PTY 검증)
- [ ] **Lua `l()` 키 naming 일관성** (`cards.X.name` / `events.X.choices.0.description` 같은 점 표기)
- [ ] **cycle 위험 검증** (system/localization 같은 단일 의존 패키지는 모든 ui/cmd에서 안전 import 가능)
- [ ] 배포 자동화 (Vercel push, GitHub Release, itch.io 등)
- [ ] i18n JSON .translation 자동 생성 확인
- [ ] 게임 실행 + 한국어 모드 검증

### PR 준비 + 다국어 README 워크플로 (2026-07-28 6차, BigJk/end_of_eden verified) ★★
- **PR 시점 사용자 명시 확인 후 5커밋 분리 + squash 미적용** — 4대 축이 다 완료되면 (i18n YAML + Lua l() + Go localization.G() + 비-i18n 텍스트 파일) **의미 단위로 커밋 분할**:
  1. `docs:` — README 변경만 (PR reviewer가 본문 검토 분리 가능)
  2. `feat(i18n):` — 데이터 + Lua + Go 전체를 묶어서 (단일 PR은 하나의 i18n 기여로 인식)
  3. 이전 단계 커밋들이 이미 main 위에 있을 때 → 그 위에 깔끔하게 stacked commit 5개로 PR
- **squash 전략**: 메인테이너가 squash 선호 시 머지 시 squash, 별도 요청 없으면 5커밋 유지. **사용자에게 squash 여부 묻지 않고 일반적으로 stacked 커밋 유지** (squash는 메인테이너가 결정).
- **다국어 README 패턴 (사용자 명시 요청, 2026-07-28 6차)** — OSS fork + 한국어화 시 **한글 README 동봉은 표준**:
  1. **별도 파일**: `README.md` (영문) + `README.ko.md` (한국어) — GitHub이 양쪽 자동 인식
  2. **양방향 언어 탭** 두 파일 상단에 추가:
     ```markdown
     <p align="right">
       <a href="README.md">🇬🇧 English</a> · <a href="README.ko.md">🇰🇷 한국어</a>
     </p>
     ```
  3. **README.ko.md에 "한국어 설정 방법" 섹션 동봉** — 사용자가 게임 빌드 후 한국어로 플레이하는 명령어 안내:
     ```bash
     # 1) 한국어 설정 파일 만들기
     cd /Users/mac/work/<repo>
     cat > settings_term.json <<'EOF'
     {
       "audio": true,
       "volume": 1,
       "language": "ko"
     }
     EOF

     # 2) 빌드
     go build -o ./build/<binary> ./cmd/<entrypoint>

     # 3) 실행
     ./build/<binary>
     ```
  4. **README 번역 범위**: 헤더, 설명, 스크린샷 섹션, How to play (Docker / 설정 / 콘솔 / Lua 모딩 / 빌드 / 버전 관리 / 소셜 / 크레딧 / 라이선스) — **"Interesting bits" 등 내부 기술 디테일은 한국어 README에서는 `<details>`로 접어두거나 한 줄 요약으로 축소 가능** (사용자가 fork한 게임의 기술적 흥미거리보다 사용법이 더 중요)
  5. **사용자가 직접 요청**: "리드미에 한글탭을 추가해서 한글리드미도 볼 수 있도록해줘" + "한국어 리드미에 아래내용을 정리해서 추가해줘" (build 명령어 + 설정 + 실행) — **사용자가 README 단계까지 신호 주면 적극 추가**. 영어-only README는 한국어 기여자에게 진입장벽 ↑.
- **PR 본문 best practice (2026-07-28 6차) — 6섹션 구성**:
  1. **Summary**: 한국어화가 어디까지 적용되는지 1-2문단
  2. **What's translated**: 카테고리별 나열 (UI / Cards / Events / Intents / Logs / Tutorial / Loading / Settings)
  3. **What is NOT translated (and why)**: de/ YAML 보존, Lua `---` 주석, Nerd Font CJK 부재, test() 함수 등 — 명시적으로 구분하면 리뷰어 의문 ↓
  4. **How it's structured**: locale overlay / `l()` helper / `localization.G()` 사용 설명 + fallback 안전성
  5. **Verification**: `./verify_ko.sh` 출력 + `go build` 결과 + 실제 게임 실행 확인 결과
  6. **Notes for review**: fallback이 어떻게 안전한지, 행동 변경 없는지, 사이드 이펙트 가능성
- **PR 본문 사이즈**: 약 50-80줄 (한국어 5,000자 이내). 너무 짧으면 "이게 다야?" 의심, 너무 길면 리뷰 안 함. 코드 diff가 본문보다 훨씬 크므로 본문은 **맥락 + 안전성 증명**에 집중.

### `localization.SetCurrent()` 호출 누락 함정 (2026-07-28 6차, BigJk/end_of_eden verified) ★★
- **현상**: 단위 테스트에서 `localization.Global.AddFolder(...)` 호출 후 `Get("ko", key)`는 한국어 반환하지만, `G(key)`는 영어 fallback. 게임 코드 본체에서는 `SetCurrent("ko")` 호출 후 `G()` 사용하므로 정상 동작.
- **근본 원인**: `localization.G(key, default)` = `l.Get(l.current, key, default)`. `l.current`가 `"en"` (기본값)인 상태에서 ko 키가 있으면 ko 반환하지만, ko 키가 없으면 `l.Get("en", key)` 재귀 → 영어 fallback. **`Get("ko", key)`는 직접 ko locale 지정**이라 정상 동작.
- **테스트 작성 함정 패턴** (Go throwaway test):
  ```go
  // ❌ 작동 안 함 — G()의 current가 "en"
  localization.Global.AddFolder("./assets/locals")
  v := localization.G("ui.foo", "FOO")  // FOO 반환 (en fallback)

  // ✅ 두 가지 방법 중 하나
  // 방법 A: SetCurrent 명시
  localization.SetCurrent("ko")
  v := localization.G("ui.foo", "FOO")  // 한국어 반환

  // 방법 B: Get 직접 사용
  v := localization.Global.Get("ko", "ui.foo")  // 한국어 반환
  ```
- **검증 스크립트 (verify_ko.sh) 권장 패턴**: `verify_ko.sh`는 **`Get("ko", key)`를 직접 사용** → `SetCurrent` 호출 없이 100+ 키 검증 가능. 따라서 단위 테스트는 `Get`으로 통일.
- **디버그 신호**: YAML에 분명히 있는데도 테스트가 fallback (영문) 반환 → (1) `SetCurrent` 호출했는지 (2) YAML 키 경로가 정확한지 (`Get`과 `G` 동작 차이 가능) 확인.
- **PTY 후처리 검증에서 subprocess 디코딩 에러 함정 (2026-07-28 6차, BigJk/end_of_eden verified)**: Go binary의 stdout/stderr를 Python `subprocess.run()`으로 캡처할 때 **한글 UTF-8 바이트가 `decode('utf-8')`에서 `UnicodeDecodeError: 'utf-8' codec can't decode bytes` 발생**.
  - **원인**: subprocess는 시스템 인코딩(C/POSIX = ASCII)으로 디코딩 시도. macOS/Linux 기본은 ASCII이므로 한글 깨짐.
  - **해결**:
    ```python
    result = subprocess.run([...], capture_output=True)
    # 방법 1: 환경변수로 UTF-8 강제 (가장 안전)
    env={**os.environ, 'LC_ALL': 'C.UTF-8', 'LANG': 'C.UTF-8'}
    # 방법 2: decode에 errors='replace' 추가
    stdout = result.stdout.decode('utf-8', errors='replace')
    ```
  - **방법 1 권장** — `errors='replace'`는 깨진 바이트를 `?`로 바꿔서 검증 신호 손실. `LC_ALL=C.UTF-8`로 환경변수 통일하면 깨끗하게 UTF-8 디코딩.
  - **PTY 검증에서도 동일**: `LC_ALL=en_US.UTF-8 grep -oE '[가-힣][가-힣 ,!?:.\-]*'` 강제 — macOS 기본 sed는 multibyte에서 `illegal byte sequence` 에러.
- **PTY 텍스트 추출 + 한글 검증 패턴 (Python subprocess)**:
  ```python
  import subprocess, os
  result = subprocess.run(
      ['go', 'run', f'{check_dir}/main.go'],
      capture_output=True,
      cwd='/Users/mac/work/<repo>',
      env={**os.environ, 'LC_ALL': 'C.UTF-8', 'LANG': 'C.UTF-8'},
      timeout=120,
  )
  print(result.stdout.decode('utf-8', errors='replace'))
  ```
