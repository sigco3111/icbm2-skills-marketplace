---
name: oss-fork-localization
description: "기존 OSS 프로젝트 fork + 한국어 환경 최적화 + 외부 LLM 백엔드 교체 클래스 워크플로우. Apache 2.0 §4(a) 변경 표시 의무 + MODIFIED.md 패턴 + 비대칭 임베딩 검증 (passage↔query) + NIM self-test + 한글 페르소나/프롬프트 단계별 적용. '이거 fork해서 한글화해줘', 'Apache 2.0 라이선스 표시 의무', 'LLM 백엔드 교체해줘 (OpenAI → NIM)', '한국어 임베딩 검증해줘', '한국어 페르소나 적용' 같은 요청에 발동. macOS Sonoma+ PEP 668 환경 설치 + Hermes venv 활용 + 사용자에게 위임 가능한 단계 식별 포함. generative_agents-kr 사례 검증 (Stanford 2023 → sigco3111 NIM 2026-07-14)."
version: 1.8.0
author: HyeRin (MiniMax)
license: MIT
metadata:
  hermes:
    tags: [oss, fork, korean, localization, llm-backend, nim, embedding, apache-2.0, josa, negation-guard, asymmetric, django-ui, e2e-verification, zsh-quoting, delegation, django-4-migration, pythonpath-hermes]
    related_skills: [oss-python-bootstrap, github-profile-readme, github-repo-management, ad-hoc-verifier, legacy-repo-modernization]
---

# OSS Fork + 한글화 + LLM 백엔드 교체 워크플로우

> 기존 오픈소스 프로젝트(논문 기반, 인기 OSS 등)를 fork해서 **한국어 환경에 맞게 최적화**하면서 **외부 LLM 백엔드를 교체**(OpenAI → 사설 호스팅)할 때 사용하는 클래스 워크플로우.

## 언제 사용하나

| 사용자 요청 | 트리거 |
|------------|--------|
| "이 OSS 한글화하고 한국 시나리오 추가해줘" | ✓ |
| "이거 fork해서 한국어 UI/페르소나/프롬프트 작업" | ✓ |
| "LLM 백엔드 OpenAI → NIM/Ollama/vLLM 으로 교체" | ✓ |
| "한국어 임베딩 검색 정확도 검증해줘" | ✓ |
| "Stanford generative_agents 같은 거 fork 가자" | ✓ |
| "이 프로젝트 한국어 커뮤니티용 배포판 만들고 싶어" | ✓ |

## 핵심 원칙

### 1. 라이선스 의무는 **먼저** (Apache 2.0 §4(a))

`fork + 수정`은 **반드시** LICENSE + MODIFIED.md + 변경 표시 3종 세트로 진행. 이거 나중에 하면 blame 비용 ↑.

| 의무 | 위치 | 검증 |
|------|------|------|
| 원본 LICENSE 보존 | 그대로 | `grep "Apache License" LICENSE` |
| 저작권 표시 | 원본 + 본인 | `MODIFIED.md` §원본 정보 |
| 변경 파일 명시 | `MODIFIED.md` 표 | 본인 PR/커밋 |
| 라이선스 자동 인식 | repo Description | GitHub API `license.spdx_id` |

**자주 실수하는 라이선스별 의무**:

| 라이선스 | 허용 | 의무 | 비고 |
|---------|------|------|------|
| Apache 2.0 | 상업, 수정, 배포 | LICENSE, 변경, **NOTICE** | 가장 permissive |
| MIT | 상업, 수정 | LICENSE + 저작권 | 가장 짧음 |
| BSD-3 | 상원, 수정 | LICENSE + 저작권 | "광고 조항" 주의 |
| GPL-3.0 | 상업, 수정 | **파생 저작물 GPL** | 가장 strict, fork면 GPL |
| AGPL-3.0 | 상업, 수정 | **네트워크 사용 시도 GPL** | SaaS 망함 |

**Stanford generative_agents 사례** (2026-07-14 sigco3111): Apache 2.0 fork → LICENSE 보존 + MODIFIED.md 작성 → GitHub이 `Apache-2.0` 라이선스 자동 인식 확인.

### 2. 외부 LLM 백엔드 교체는 **인터페이스 1 파일만**

대부분의 OSS LLM 프로젝트는 `gpt_structure.py` 같은 **wrapper 1개**에 모든 호출이 집중되어 있음. 이걸 새로 작성하면 호환됨.

**체크리스트 (OpenAI → NIM 기준)**:

| 항목 | 작업 |
|------|------|
| API base URL | `https://integrate.api.nvidia.com/v1` |
| ChatCompletion | `openai.ChatCompletion.create` → `_nim_post("/chat/completions", ...)` |
| Completion (구 API) | `openai.Completion.create` → 같은 chat endpoint로 fallback |
| Embedding | `openai.Embedding.create` → `_nim_post("/embeddings", ...)` (asymmetric 시 `input_type` 추가) |
| 인증 | `Bearer $NVIDIA_API_KEY` 헤더 |
| rate limit | 동일 (분당 요청 수) |

**원본 인터페이스 보존** — 호출부 (`persona/cognitive_modules/`)는 무수히 많지만 wrapper 시그니처는 그대로 두면 일제히 동작. 예: `ChatGPT_request(prompt) → str`, `get_embedding(text) → list[float]`.

### 3. 비대칭 임베딩은 **함수 2개 분리**

`llama-nemotron-embed-1b-v2` 같은 비대칭 모델은 **passage(저장) / query(검색)** 임베딩이 의미적으로 다르게 align됨. 단일 `get_embedding()`은 정확도 ↓.

```python
def get_passage_embedding(text):
    return _nim_embed(text, "passage")  # 메모리 저장

def get_query_embedding(text):
    return _nim_embed(text, "query")    # 메모리 검색
```

원본 `get_embedding()`은 `get_passage_embedding()`의 alias로 유지 (호환).

### 4. 한국어 검색의 **부정 가드 (NEGATION_GUARD)** (NEW, 2026-07-14)

검증된 한계: 임베딩 모델은 한국어/영어 부정 표현 `"~않다"`, `"~not"`, `"hate"`를 무시하고 높은 유사도를 산출. retrieval 시 위양성 ↑.

**자동 가드 패턴** (5줄):
```python
NEGATION_KO = ["않", "안 ", "못 ", "없", "아니", "말고", "싫어하", "거부하", "반대하"]
NEGATION_EN = ["not ", "n't ", " no ", "never", "none", "cannot", "won't", "hate", "refuse"]

def negation_penalty(text_a, text_b):
    a_neg = any(neg in text_a.lower() for neg in NEGATION_KO + NEGATION_EN)
    b_neg = any(neg in text_b.lower() for neg in NEGATION_KO + NEGATION_EN)
    if a_neg != b_neg: return 0.4  # 한쪽만 부정 → 강한 페널티
    if a_neg and b_neg: return 0.1  # 둘 다 부정 → 약한 페널티
    return 0.0
```

→ 실측: `"이서연 카페 커피"` ↔ `"이서연 카페 커피 마시지 않았다"` → 0.457 (위양성) → **0.057** (87% 감소).

### 5. self-test는 푸시 전에 **반드시**

`gpt_structure.py`에 `if __name__ == "__main__":` 블록 추가, **3줄 출력**:
- LLM 호출 (ping → "ping")
- 비대칭 임베딩 (차원 + 유사도)
- 부정 가드 (가드 전/후)

### 6. 한국어 조사(josa) 자동 처리 (NEW, 2026-07-14)

페르소나 whisper 생성 시 "이서연은/박지우와" 같은 조사 자동 처리. `(char - 0xAC00) % 28 == 0`이면 받침 없음.

→ 자세한 패턴: `references/korean-persona-seed-pattern.md`

### 7. 한국어 임베딩 벤치마크 (NEW, 2026-07-14)

NIM 11개 임베딩 모델 실측 결과, 한국어 메모리 retrieval에는 **`nvidia/llama-nemotron-embed-1b-v2`** 가 75% (6/8) 정확도로 1위. 다른 모델들은 50% 이하이거나 NIM 미서빙.

→ 자세한 벤치마크: `references/korean-embedding-benchmarks.md`

## ⚠️ 핵심 함정

### 함정 1: storage/ 1GB가 git 인덱싱에서 행 걸림

Stanford generative_agents (및 대부분의 시뮬레이션/UI 프로젝트)는 **결과물 storage + 시각 자산** 으로 1GB+ 차지. `git add -A`가 60초 timeout.

**3-step 해결**:
```bash
# 1. .gitignore에 storage 추가
echo "environment/frontend_server/storage/" >> .gitignore
echo "environment/frontend_server/compressed_storage/" >> .gitignore

# 2. 실제 디렉토리 삭제 (디스크 절약)
rm -rf environment/frontend_server/storage
rm -rf environment/frontend_server/compressed_storage

# 3. .git 통째로 재생성 (가장 빠름)
rm -rf .git && git init -b main
git remote add origin https://github.com/{user}/{repo}.git
git add -A && git commit -m "chore: import + localize"
```

`git rm --cached`는 60초+ 걸리므로 통째 재생성이 효율적.

### 함정 2: 모델 ID는 **prefix 필수**

OpenAI 호환 NIM 모델은 `provider/catalog-id` 형식:
| 이름 | 실제 ID |
|------|---------|
| gpt-oss-120b | `openai/gpt-oss-120b` |
| llama-3.1-70b | `meta/llama-3.1-70b-instruct` |
| llama-3.1-nemotron-embed-1b-v2 | `nvidia/llama-nemotron-embed-1b-v2` |

`gpt-oss-120b` 단독 호출 → **404 page not found**. `openai/gpt-oss-120b`로 호출 → 200 OK.

**NIM 모델 카탈로그 조회**:
```bash
curl -s "https://integrate.api.nvidia.com/v1/models" -H "Authorization: Bearer $NVIDIA_API_KEY_1"
# → 121개 모델 목록 (전체 ID 확인 가능)
```

### 함정 3: embedding `input_type` 비대칭 함정

`nv-embedqa-e5-v5` 같은 비대칭 모델은 `input_type=query|passage` 없으면 400 에러. 같은 모델을 `input_type=passage`로 통일하면 retrieval 의미가 깨져서 **모든 케이스 0.93+** (구분 불가). 반드시 **passage(p) ↔ query(q)** 분리 호출.

### 함정 4: Korean 환경 변수명은 **소문자 snake**

LLM 키 환경변수 네이밍 컨벤션은 snake 케이스:
- ✅ `NVIDIA_API_KEY`, `MINIMAX_API_KEY`, `OPENAI_API_KEY`
- ❌ `nvidiaApiKey`, `nvidia-api-key`

`.env` 파일은 `~/.hermes/secrets/{provider}_keys.env` 패턴 권장 (이미 ICBM2 컨벤션).

### 함정 5: README 영문 → 한글 시 attribution 단절

Apache 2.0 fork에서 원본 README를 즉시 한국어로 덮어쓰면 **원본 표시 의무 위반**으로 해석될 여지. 안전 패턴:
1. 원본 영문 README를 **그대로 보존** + 위쪽에 "한국어 버전 아래" 한 줄
2. **MODIFIED.md에 명시** "원본 README 그대로 + 한글 번역 추가 제공"

### 함정 6: 음절/키워드 substring 중복 (NEW, 2026-07-14)

페르소나 whisper 생성 시 "짝사랑함" vs "짝사랑" 같은 단어는 **exact match는 실패하지만 substring match는 성공**. 한국어 중복 키워드 검출에는 substring 사용.

```python
# ❌ exact match: 실패 ("짝사랑" not in "짝사랑함")
if rel_type in persona.get("secret", ""): continue

# ✅ substring match: 성공 (re.findall로 추출한 2글자+ 키워드)
for word in re.findall(r'[가-힣]+', rel_type):
    if len(word) >= 2 and word in secret_text: continue
```

### 함정 7: relative path 함정 (NEW, 2026-07-14)

`../../environment/...` 같은 relative path는 cwd 따라 깨짐. 절대 경로 변환 필수.

```python
OUT_CSV = os.path.join(os.path.dirname(__file__), "..", "..", "..", "environment", ...)
OUT_CSV = os.path.abspath(OUT_CSV)
assert os.path.exists(OUT_CSV), f"CSV 경로 없음: {OUT_CSV}"
```

### 함정 8: 프롬프트 자동번역 시 LLM 응답 길이 제한 (NEW, 2026-07-14)

2584자 같은 큰 프롬프트는 `gpt_structure.py`의 `ChatGPT_request` 기본 `max_tokens=2048`로는 응답이 잘림. **`GPT4_request`는 `max_tokens=4096` 사용**.

→ 자세한 chunked 번역 패턴은 `references/prompt-auto-translation.md` §함정 1.

### 9. 대용량 fork는 세션 컨텍스트 빨리 소진 (NEW, 2026-07-14)

`oss-fork-localization` Stage 3.5 (35개 프롬프트 자동번역 + 검수)는 **위임 가능한 단일 작업**이지만, 메인 세션에서 직접 풀면 컨텍스트가 빨리 폭발함.

**권장 패턴**:
- 자동화 가능한 단계 (active 식별 → LLM 번역 → 자동 검수 → 재번역 루프)는 **완전 위임**
- 위임 명령 시 "수동검수는 내가 해야하나?" 같은 사용자 부담 → "검수 자동화 도구가 있으니 위임 가능" 명시
- 푸시는 **단계별로 분할** (5-7개 파일 단위) — 전체 35개를 한 PR에 묶지 말 것

→ 전체 워크플로 자동화 패턴은 `project-delegation` 스킬 참고.

### 6. 임베딩 API 500 + 빈 텍스트 → zero-vector 폴백 (NEW, 2026-07-14) ★

NIM embeddings 엔드포인트(`/v1/embeddings`)는 chat과 달리 **빈 텍스트/특수 입력**에 500을 반환할 수 있음. 그리고 perceive.py 같은 호출부는 사용자 입력에서 나오는 텍스트를 그대로 임베딩에 넘기므로 빈 문자열/괄호 잔재(`"()"` → split 후 `""`)가 흘러들어올 가능성이 매우 높음.

**증상** (실측 — 시뮬레이션 실행 중):
```
File ".../gpt_structure.py", line 314, in _nim_embed
    resp = _nim_post("/embeddings", body)
urllib.error.HTTPError: HTTP Error 500: Internal Server Error
Error.
```

`/v1/chat/completions`이 200 OK로 ping 응답하는 상황에서도 `/v1/embeddings`는 500을 던질 수 있음 — **다른 엔드포인트이므로 키 진단 패턴이 다름**. 체인처럼 호출 시 chat reasoning 버그와 무관.

**해결** (`_nim_embed` robust 패턴):
```python
def _nim_embed(text, input_type):
    # 1) 빈/공백만 있는 텍스트 → NIM 호출 없이 2048d 0 벡터 반환
    safe_text = (text or "").strip()
    if not safe_text:
        return [0.0] * 2048  # 모델 출력 차원과 동일
    body = {
        "model": EMBED_MODEL,
        "input": [safe_text],
        "input_type": input_type,
    }
    try:
        resp = _nim_post("/embeddings", body)
        return resp["data"][0]["embedding"]
    except urllib.error.HTTPError as e:
        # 2) 5xx — 1회만 재시도, 그래도 안되면 0 벡터
        if e.code in (500, 502, 503, 504):
            try:
                resp = _nim_post("/embeddings", body)
                return resp["data"][0]["embedding"]
            except Exception:
                return [0.0] * 2048
        return [0.0] * 2048
    except Exception:
        return [0.0] * 2048
```

**왜 0 벡터 폴백이 안전한가**:
- retrieval cosine similarity에서 0 벡터는 모든 벡터와 직교 → score 0에 가까움
- `cosine_similarity(0_vec, any_vec) = 0.0` 또는 정의불가 (모든 entry 0) → 실질적으로 "관련 없음"
- 시뮬레이션은 죽지 않고 진행되며, 해당 메모리는 retrieval 후보에서 자연스럽게 탈락

**판별 방법** (500 vs 키 불량):
```bash
# 1. curl로 직접 짧은 텍스트 테스트
curl -s -w "\nHTTP_CODE: %{http_code}\n" -X POST \
  "https://integrate.api.nvidia.com/v1/embeddings" \
  -H "Authorization: Bearer $NVIDIA_API_KEY_1" \
  -H "Content-Type: application/json" \
  -d '{"model": "nvidia/llama-nemotron-embed-1b-v2", "input": ["test"], "input_type": "passage"}'

# HTTP 200 + 정상 임베딩 → 키 정상, 코드의 빈 텍스트가 500 유발
# HTTP 500 + "Missing request extension" → 키 불량 (chat과 동일 진단)
# HTTP 500 (other) → 모델 ID prefix 또는 다른 일시적 문제
```

**Push 전 검증**:
- `gpt_structure.py` self-test 3-row 출력 모두 정상이어도 시뮬레이션 중 빈 텍스트 경로에서 500 가능
- 시뮬레이션의 `_run_100_step` 후 500 없이 끝까지 진행되는지 별도 확인 필요
- 또는 self-test에 명시적으로 `get_embedding("")` + `get_embedding("()")` 호출 추가해서 0 벡터 폴백 경로 검증

### 5. reasoning 모델의 `content=None` 함정 (CRITICAL, 2026-07-14) ★

`openai/gpt-oss-120b` 같은 reasoning 모델을 그냥 `choices[0].message.content`로 받으면 **모든 호출이 빈 문자열**이 됩니다. self-test는 통과해도 시뮬레이션 시작 시 silent fail.

**즉시 증상**:
- self-test `[1]` 은 정상 ("ping" 응답)
- `ChatGPT_safe_generate_response` 호출에서 모든 반복이 빈 응답 → `fail_safe_response` 반환
- 시뮬레이션 로그에는 "FAIL SAFE TRIGGERED" 반복, persona가 단일 단어 행동으로 stuck

**검출**:
```python
import os, urllib.request, json
body = json.dumps({"model": "openai/gpt-oss-120b",
                   "messages": [{"role": "user", "content": "ping"}],
                   "temperature": 0, "max_tokens": 50}).encode()
req = urllib.request.Request("https://integrate.api.nvidia.com/v1/chat/completions",
                              data=body, method="POST")
req.add_header("Authorization", f"Bearer {os.environ['NVIDIA_API_KEY_1']}")
req.add_header("Content-Type", "application/json")
resp = json.loads(urllib.request.urlopen(req, timeout=30).read())
print(resp["choices"][0]["message"])
# {'content': None, 'reasoning_content': 'The user asks: ping...'}  ← 즉시 확인 가능
```

**fix**: `nim-llm-backend-swap.md` §함정 5의 `_nim_chat` 보강 적용 (10줄 추가).

### 11. .gitignore 강제 적용으로 디렉토리 중복 생성 (NEW, 2026-07-14)

`utils.py`, `gpt_structure.py` 등을 `.gitignore`에 등록하면, 자동화 스크립트가 `KR_DIR = os.path.join(PROMPT_DIR, "prompt_template_kr")` 형태로 쓸 때 **PROMPT_DIR 자체가 prompt_template 디렉토리**라서 `prompt_template/prompt_template_kr/` 중복 생성됩니다.

**증상**:
- `translate_prompts_kr.py` 실행 → `prompt_template/prompt_template_kr/`에 결과 저장
- 실제 시뮬레이션은 `prompt_template_kr/` (한 단계 위) 찾음 → 한국어 라우팅 실패
- 검수 도구도 다른 경로에서 0개 발견

**해결** (2단계):
```python
# ❌ 중복 생성
KR_DIR = os.path.join(PROMPT_DIR, "prompt_template_kr")  # prompt_template/prompt_template_kr

# ✅ 부모 디렉토리 기준으로
PROMPT_DIR = os.path.dirname(os.path.abspath(__file__))
KR_DIR = os.path.join(os.path.dirname(PROMPT_DIR), "prompt_template_kr")
```

**탐지**:
```bash
find . -type d -name "prompt_template_kr"  # 2개 이상 나오면 중복
```

### 12. bash grep 한글 escape 함정 (NEW, 2026-07-14)

`bash -c "grep -oE '!<INPUT [0-9]+>!' file"` 형태로 한국어 코드 마커 검색 시 **백슬래시 escape** 때문에 매칭 실패합니다.

**증상**: `grep -oE '!<INPUT \d+>!'` → 빈 결과, 그러나 `find . -name "*.txt"`에는 분명히 파일 존재.

**해결**: bash heredoc에서 escape하지 말 것 — `python3` re 모듈 사용 또는 grep에서 backslash 제거.
```bash
# ❌ bash가 \! 를 escape
grep -E '\!<INPUT 0>\!' file

# ✅ raw pattern (single-quoted, 또는 Python)
python3 -c "import re; print(re.findall(r'!<INPUT \d+>!', open('file').read()))"
```

### 13. macOS Sonoma+ `pip install -r requirements.txt` 실패 (NEW, 2026-07-14) ★

신 macOS 시스템 Python은 PEP 668 보호가 걸려 직접 `pip install` 불가. 원본 OSS의 `requirements.txt`는 2022-2023년 Python 3.7-3.9용 버전이 박혀있어 3.11에서 빌드 실패 추가 발생.

**증상 1**: `pip: command not found: pip` (시스템 Python에 pip 미설치)
**증상 2**: `error: externally-managed-environment` (PEP 668 보호)
**증상 3**: `Pillow==8.4.0` 빌드 실패 (libjpeg 등 native 의존성, Python 3.11 미지원)
**증상 4**: `gensim==3.8.0` ImportError (3.8은 Python 3.11 미지원, 4.x 필요)

**해결 — Hermes venv + flexible 버전 통합 설치**:
```bash
# 1. Hermes venv 활성화 (이미 PIL 12.x 설치되어 있음)
source ~/.hermes/hermes-agent/venv/bin/activate

# 2. 핵심 패키지를 flexible 버전으로 설치 (원본 strict 버전 우회)
pip install --quiet 'Django>=4.2,<5' \
              'numpy>=1.26,<2' 'pandas>=2.0' \
              'scikit-learn>=1.4' 'scipy>=1.11' \
              'gensim>=4.3' 'nltk>=3.8' 'openai>=1.0' \
              'statsmodels>=0.14' 'seaborn>=0.13' 'matplotlib>=3.8'

# 3. self-test
cd reverie/backend_server/persona/prompt_template
python3 gpt_structure.py
```

**대안 — 새 .venv 만들기**:
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt  # Pillow는 빌드 실패할 수 있음
```

**README 보강** — 위 환경별 설치 가이드를 README §설치 섹션에 명시:
- 시스템 Python 사용자 → `.venv` 생성
- Hermes venv 사용자 → `source ~/.hermes/hermes-agent/venv/bin/activate`
- macOS Sonoma+ → "command not found: pip" 안내 + "외부 관리 환경" 에러 설명
- **zsh 따옴표 필수** — `pip install "Pillow>=10.0"` 형태로 모든 version specifier 감싸기 (`>`, `<` 는 zsh에서 redirection)

### 14. 사용자 위임 선호 신호 (NEW, 2026-07-14) ★

이 워크플로의 자동화 단계 (LLM 번역 / 자동 검수 / 재번역 / 시뮬 검증)는 **모두 위임 가능**. 사용자가 "수동검수는 내가 해야하나?"라고 물으면:

**응답 패턴**:
- ✅ "검수 자동화 도구 (review_prompts_kr.py)가 있어서 위임해도 됩니다"
- ✅ 위임 시 점진 보고 (5-7파일 단위로 푸시 + 진행 상황 URL)
- ✅ 검수 결과 'clean 90% 이상'이면 사용자 액션 없이 일괄 푸시
- ❌ "사용자가 봐야 합니다" 같은 부담 표현 금지

검수 결과 신뢰도가 낮을 때만 (clean < 70%, 코드 손실 5개 이상) 샘플 5개 검토 요청.

**위임 시 4-옵션 나열 금지** (2026-07-14 추가): 위임을 받는 즉시 "옵션 A/B/C/D" 표 + "어떤 옵션?" 으로 다시 묻는 행동은 **anti-pattern**. 대신:
- ✅ 기본 추천 옵션 1개로 시작 + "이 방향으로 가도 될까요?" 한 번 확인
- ❌ 옵션 4개 표 + "선택해주세요" → "위임한 의미" 사라짐
- 위임 모드 = "내가 알아서 결정해줘" 모드. 결정 권한을 다시 사용자에게 넘기지 말 것.

### 16. `write_file` path 매개변수 literal `</path>` 함정 (NEW, 2026-07-14) ★

`write_file(path=..., content=...)` 호출 시 path 매개변수 끝에 `</path>` JSON closing tag가 **literal로 파일명에 포함**되는 함정.

**증상** (실측 사례):
```python
write_file(path="/Users/mac/work/foo/bar.txt", content="...")
# → 실제 저장: /Users/mac/work/foo/bar.txt<  (literal '<' 추가됨!)
# → 또는 /Users/mac/work/foo/path> (closing tag가 파일명으로)
```
실제 파일은 만들어지지만 `cat bar.txt`로 못 찾음 → ls -la 해봐야 `<`/`path>` 접미사가 보임.

**원인**: path 매개변수에 trailing `</path>` 태그가 그대로 들어감 (tool input 파서가 tag를 path에 concat).

**해결**:
1. **path 매개변수 끝에 `</path>` 또는 다른 tag literal이 있는지** 항상 점검 (특히 처음 도구 호출 시)
2. **빠른 진단**:
   ```bash
   ls -la --color=never path/to/dir | head -10
   # → 파일명에 `<` 또는 `path>` 같은 비정상 literal 발견 시 write_file 호출 검토
   ```
3. **복구**:
   ```bash
   # 잘못된 파일을 올바른 위치로 이동
   mv 'bar.txt<' 'bar.txt'
   mv 'path>' 'bar.txt'
   
   # 빈 디렉토리 잘못 생성된 경우
   rm -rf 'bar.txt<' 'path>'
   ```

**예방**:
- path 매개변수 끝에 슬래시나 HTML/XML 태그 literal이 들어가지 않도록 주의
- write_file 호출 직후 `ls -la path/` 로 검증
- 특히 새 파일을 처음 만들 때 첫 호출은 반드시 ls로 확인

### 15. README 갱신 시 Phase 진행 상태 표 추가 (NEW, 2026-07-14)

이 워크플로 완료 후 README는 **반드시** 현재 Phase 상태 반영. 패턴:

```markdown
| Phase | 내용 | 결과 |
|-------|------|------|
| 1 | LLM 백엔드 교체 | ✅ (커밋 해시) |
| 2 | 비대칭 임베딩 + 부정 가드 | ✅ (커밋 해시) |
| 3 | 페르소나 시드 (3명) | ✅ |
| 4 | 프롬프트 자동번역 (35개) + 라우팅 | ✅ |
| 5 | Django UI 한글화 (6 templates) | ✅ |
| 6 | Bug Fix: reasoning 모델 content=None | ✅ |
| 7 | E2E 검증 (test_kr_sim.py) | ✅ |
```

각 Phase 끝에 **커밋 해시 + 검증 출력 (한국어 agent_chat 예시) 포함**하면 README가 곧 문서가 됨.

### 17. Django 2.x → 4.x 마이그레이션 (Django 프로젝트 fork 시) (NEW, 2026-07-14)

fork 대상이 Django 프로젝트면 (`python manage.py runserver` 필요) 4가지 자동 패치 필요:

| 파일 | 변경 |
|------|------|
| `requirements.txt` | `django-cors-headers>=3.5` |
| `project/urls.py` | `from django.conf.urls import url` → `from django.urls import re_path` + `url()` → `re_path()` |
| `app/views.py` | `from django.contrib.staticfiles.templatetags.staticfiles import static` → `from django.templatetags.static import static` |
| 모든 템플릿 | `{% load staticfiles %}` → `{% load static %}` |

상세 sed 패턴 + 검증 워크플로는 `legacy-repo-modernization` 스킬의 `references/django-2-to-4-migration.md` 참조.

### 18. PYTHONPATH Hermes 데스크탑 간섭 (NEW, 2026-07-14) ★

Hermes 데스크탑 사용자가 `.venv` 활성화해도 sys.path[1]에 Hermes venv가 들어와 .venv 패키지가 아닌 Hermes 패키지가 import됨.

**증상**: `python3 -c "import django; print(django.__file__)"` → `/Users/mac/.hermes/...` (Hermes 것)

**해결**: venv 활성화 직후 `unset PYTHONPATH`.

자세한 진단 + alias 등록 패턴: `legacy-repo-modernization` 스킬의 §7단계 참조.

### 19. `read_file` partial view + `patch` 도구 충돌 (NEW, 2026-07-14) ★

`read_file`을 `offset`/`limit`으로 호출하면 partial view가 됨. 그 다음 `patch` 도구로 같은 파일 수정 시도하면:

```
patch error: file was last read with offset/limit pagination (partial view)
```

**해결**:
- `patch` 전에 항상 전체 파일 다시 읽기 (`offset`/`limit` 없이)
- 또는 `skill_manage action=edit` (전체 SKILL.md 재작성) 사용
- 작은 부분 변경은 `patch`로, 큰 재작성은 `write_file`/전체 재작성으로 분리

### 20. `storage/` 시나리오 부재 + sparse-checkout으로 1GB 다운로드 (NEW, 2026-07-14) ★

storage/가 .gitignore 처리되어 fork할 원본 시나리오가 비어 있는 함정. 시뮬레이션 fork가 `reverie.py` 내부에서 `copyanything(../../storage/<fork_name>, ...)`를 호출하다가 FileNotFoundError로 죽음.

**증상**:
```
Enter option: run 100
FileNotFoundError: [Errno 2] No such file or directory: '../../environment/frontend_server/storage/ICBM'
```

**해결 — git sparse-checkout으로 storage/만 다운로드** (전체 1GB 아닌 일부만):
```bash
# 임시 디렉토리에 원본 sparse clone (storage/ 만)
TMPDIR=/tmp/generative-agents-original
git clone --depth 1 --filter=blob:none --sparse \
  https://github.com/joonspk-research/generative_agents.git "$TMPDIR"
cd "$TMPDIR"
git sparse-checkout set environment/frontend_server/storage

# 가장 작은 base 시나리오만 복사 (68KB)
cp -r environment/frontend_server/storage/base_the_ville_isabella_maria_klaus \
  /Users/mac/work/generative-agents-kr/environment/frontend_server/storage/

# 정리
rm -rf "$TMPDIR"
```

**용량 옵션**:
- `base_the_ville_isabella_maria_klaus` (68KB) — 3명 페르소나, 데모용
- `base_the_ville_n25` (508KB) — 25명 페르소나, UIST 데모
- 전체 23개 시나리오 (1GB) — `cp -r environment/frontend_server/storage/*` 대신 선별

**이후 `reverie.py` 실행**:
```
Enter the name of the forked simulation: base_the_ville_isabella_maria_klaus
Enter the name of the new simulation: ICBM_kr_test
Enter option: run 100
```

### 21. .gitignore 누락: `environment/frontend_server/temp_storage/` (NEW, 2026-07-14)

`.gitignore`는 `reverie/backend_server/temp_storage/`만 차단하고 `environment/frontend_server/temp_storage/`는 **빠져있음**. 첫 시뮬 실행 시 `temp_storage/curr_step.json`이 자동 생성되어 commit accident.

**증상**: `git status`에 `environment/frontend_server/temp_storage/curr_step.json`이 untracked로 표시.

**해결 — .gitignore에 누락 패턴 추가**:
```gitignore
# 시뮬레이션 결과는 추적 안함 (재생성 가능)
environment/frontend_server/storage/
environment/frontend_server/compressed_storage/
environment/frontend_server/temp_storage/   # ← 누락 발견 시 추가
environment/frontend_server/db.sqlite3
environment/frontend_server/*.log
environment/frontend_server/environment/     # ← 누락 발견 시 추가
reverie/backend_server/storage/
reverie/backend_server/temp_storage/
reverie/backend_server/environment/
```

**커밋 후 실수로 들어간 파일 untrack**:
```bash
git rm --cached environment/frontend_server/temp_storage/curr_step.json
git add .gitignore
git commit -m "fix: .gitignore에 누락된 temp_storage/ 패턴 추가"
```

### 22. Two-terminal 시뮬레이션 실행 패턴 (NEW, 2026-07-14) ★

Stanford generative_agents 같은 시뮬레이션 OSS는 **두 개의 별도 프로세스**가 동시에 실행 중이어야 함. 이 사실을 모르면 한쪽만 띄우고 "왜 안 되지?" 무한 디버깅 함정.

**필수 두 프로세스**:

| 터미널 | 명령 | 종료 |
|--------|------|------|
| **1 (Django 시각화)** | `python manage.py runserver` (port 8000) | `Ctrl+C` |
| **2 (시뮬 백엔드)** | `python3 reverie.py` (interactive prompt) | `fin` |

**`reverie.py` 메인 명령어**:

| 입력 | 효과 |
|------|------|
| `run 100` | 100 step 진행 (~17분, NIM API 호출) |
| `save` | 현재 상태 저장 (storage/ICBM_kr_test/) |
| `fin` / `finish` | 저장 후 종료 (다음에 resume 가능) |
| `print persona schedule 이서연` | 해당 페르소나의 일과 출력 |
| `exit` | 저장 안 함, 데이터 삭제 |

**브라우저 URL**:
- 시뮬레이션 목록: `http://localhost:8000/replay/`
- 특정 시뮬: `http://localhost:8000/replay/{sim_code}/{step}/`
- 한국어 UI로 페르소나 행동/대화 실시간 표시 (Django 시각화 서버 띄워져 있어야)

**resume 패턴**:
```
Enter the name of the forked simulation: ICBM_kr_test  # 이전에 fin 한 시나리오로 재시작
Enter the name of the new simulation: ICBM_kr_test_resume
```

**README 6단계 가이드** (위 내용 통합): 설치 → sparse-checkout → 새 시뮬 생성 → `run 100` → 브라우저 확인 → `fin`.

→ `references/two-terminal-sim-execution.md` (전체 워크플로)

### 23. gpt-oss-120b reasoning 모델의 markdown 응답 파싱 (NEW, 2026-07-14) ★

reasoning 모델은 응답에 markdown (`**이름**` 헤더, `| 표 |` 행)을 자주 사용해서, 원본 split 기반 파서가 깨집니다. Stanford generative_agents의 `task_decomp` 같은 곳에서 `IndexError: list index out of range`로 시뮬이 죽음.

**증상** (실측):
```
TOODOOOOOO
**Isabella Rodriguez – 08:00 AM ~ 09:00 AM (총 60분) – 5분 단위 하위 작업**

| 순번 | 수행 작업 | 소요 시간 | 남은 시간 |
|------|-----------|-----------|-----------|
| 1) Isabella는 ... (duration in minutes: 5, minutes left: 55)
2) Isabella는 ... (duration in minutes: 5, minutes left: 50)
...
-==- -==- -==-
IndexError: list index out of range
```

**해결 — regex-first + 라인 기반 폴백**:
```python
import re
pattern = r'(\d+)\)\s*(.*?)\(duration in minutes:\s*(\d+)'
matches = re.findall(pattern, gpt_response, re.DOTALL)
cr = []
if matches:
    for _, task, dur in matches:
        task = task.strip().rstrip(".")
        task = re.sub(r'\s+', ' ', task).strip()
        try:
            cr += [[task, int(dur)]]
        except ValueError:
            pass
if not cr:
    # 폴백: 원본 split + markdown 라인 skip
    temp = [i.strip() for i in gpt_response.split("\n")]
    cleaned = []
    for line in temp:
        if not line: continue
        if (line.startswith("**") and line.endswith("**")) or \
           line.startswith("|") or line.startswith("---") or \
           (line.startswith("**") and ("–" in line or "-" in line)):
            continue
        cleaned.append(line)
    # ... 원본 파싱 ...
```

**검증**:
- 마크다운 표 응답: 5개 작업 추출 (5+5+5+5+5=25분)
- 한국어 직접 응답: 3개 작업 추출 (15+30+30=75분)
- self-test (`gpt_structure.py`) 통과

→ `references/llm-markdown-response-parsing.md` (전체 패턴)

### 26. `GPT_request()` max_tokens=100 기본값 함정 (CRITICAL, 2026-07-14) ★★★

원본 `safe_generate_response` → `GPT_request(prompt, gpt_parameter)` 체인에서 NIM으로 호출 시 `gpt_parameter` dict에 있는 `max_tokens`가 **100 기본값**으로 적용됩니다. OpenAI `text-davinci-003`(구 Completion API)에서는 100 토큰으로 짧은 응답이 충분했지만, **NIM gpt-oss-120b 같은 reasoning 모델**은 (1) reasoning trace + (2) 본문 = 100 토큰을 쉽게 초과. 초과 시 NIM은 "TOKEN LIMIT EXCEEDED" 문자열을 반환하고 시뮬은 fail_safe 폴백 → 무한 루프.

**증상** (self-test는 통과하지만 실제 시뮬 실행에서):
```
=== NIM gpt_structure self-test ===
[1] ChatGPT_single_request('ping 한 단어만')
    응답: ping           # ← self-test는 단답이라 통과
[2] 비대칭 임베딩 (passage vs query)
    차원: 2048
    '이서연 카페 커피' ↔ '이서연 음료' = 0.474
    재호출 안정성: 0.474
    부정 케이스 (가드 전): 0.457, (가드 후): 0.057

# run 100 실행 시:
TOODOOOOOO
TOKEN LIMIT EXCEEDED
-==- -==- -==-
TOODOOOOOO
TOKEN LIMIT EXCEEDED
...
```

**원인** (Stanford generative_agents 원본):
```python
def GPT_request(prompt, gpt_parameter):
    return _nim_chat(
        [{"role": "user", "content": prompt}],
        temperature=gpt_parameter.get("temperature", 0.7),
        max_tokens=gpt_parameter.get("max_tokens", 100),  # ← 기본값 100
    )
```

**해결** — `GPT_request()` 기본값을 1000으로 상향 (혹은 항상 큰 값):
```python
def GPT_request(prompt, gpt_parameter):
    """NIM gpt-oss-120b 마이그레이션: max_tokens 기본값 100 → 1000으로 상향.
    (reasoning 모델이 응답 잘림 방지)
    """
    temp_sleep()
    try:
        return _nim_chat(
            [{"role": "user", "content": prompt}],
            model=CHAT_MODEL,
            temperature=gpt_parameter.get("temperature", 0.7),
            max_tokens=gpt_parameter.get("max_tokens", 1000),  # ← 1000으로
        )
    except Exception:
        return "TOKEN LIMIT EXCEEDED"
```

**판별 방법** — 시뮬 실행 시 DEBUG에 "TOKEN LIMIT EXCEEDED" 다수 등장 + (default task) 폴백이 100% 사용되면 `max_tokens` 문제. self-test는 짧은 prompt라서 통과하므로 **self-test만으로 정상 판정 불가**. 실제 시뮬 step 1-2의 DEBUG 출력을 확인해야 발견.

**대안** (NIM max_tokens 제약 회피):
- max_tokens를 2000-4000으로 (gpt-oss-120b는 권장 4096)
- `temperature=0` (reasoning 모델은 0 권장, 일관성 ↑)
- `top_p=0.95` 등 reasoning이 끝까지 도달하도록

**왜 OpenAI 원본은 100이 충분했나**:
- `text-davinci-003`는 짧은 텍스트(2-3줄) 출력에 100 토큰 충분
- 호출부 `safe_generate_response`는 `func_validate`로 짧은 JSON 파싱 의존
- NIM reasoning 모델은 "**let me think...**" 트레이스 + 본문 → 300-1000 토큰

**Push 전 검증**:
```bash
# 시뮬 실행해서 DEBUG "TOKEN LIMIT EXCEEDED" 다수 + (default task) 폴백 확인
ga-sim
# → 100 step 중 LLM 출력이 모두 깨지면 max_tokens 의심
```

→ `references/llm-max-tokens-pitfall.md` (별도 가이드)

### 25. 시뮬레이션 FileExistsError + `run 100` 정확한 명령어 (NEW, 2026-07-14)

Stanford generative_agents 시뮬레이션을 두 번째 실행할 때 `Enter the name of the new simulation: ICBM_kr_test`가 이전에 만들어둔 폴더와 같은 이름이면 `shutil.copytree`가 `FileExistsError`로 죽음. 그리고 `reverie.py` 메인 프롬프트는 **정확히 `run 100` 한 단어**만 인식 (`100` 단독은 무시되고 다음 프롬프트로 넘어감).

**증상 1 — 같은 이름으로 재실행**:
```bash
Enter the name of the new simulation: ICBM_kr_test
FileExistsError: [Errno 17] File exists: '../../environment/frontend_server/storage/ICBM_kr_test'
```

**증상 2 — 명령어 오타**:
```
Enter option: 100
Enter option: 100   # ← prompt가 다시 나옴 (무시된 명령)
Enter option: 100
```

**해결 1 — 두 가지 옵션**:
```bash
# A. 이전 시나리오 이어가기
Enter the name of the forked simulation: ICBM_kr_test   # 이전 폴더 이름
Enter the name of the new simulation: ICBM_kr_test_v2

# B. 깨끗하게 처음부터
rm -rf environment/frontend_server/storage/ICBM_kr_test
python3 reverie.py
Enter the name of the forked simulation: base_the_ville_isabella_maria_klaus
Enter the name of the new simulation: ICBM_kr_test
```

**해결 2 — `run 100` (공백 + 숫자)**: `sim_command[:3].lower() == "run"` 매칭이므로 정확히 `run 100` 형식. `100`만 입력하면 [:3]가 `'100'`이라 `'run'` 매칭 실패.

**README 가이드 추가**:
```markdown
⚠️ **같은 이름으로 재실행 시** `FileExistsError` 에러 발생. ...
⚠️ **정확히 `run 100` 한 단어로 입력** — `100` 단독은 무시되고 다음 프롬프트로 넘어감.
```

### 24. NIM API 키 불량 → 500 에러 (NEW, 2026-07-14) ★

`HTTP Error 500: Internal Server Error`가 LLM/embedding 호출에서 동시에 나올 때, **키가 불량일 가능성 90%**. NIM API 키는 `nvapi-XXX...` 형식이지만, 환경변수에 다른 형식의 키나 만료된 키가 export 되어 있으면 NIM이 "Missing request extension" 에러로 500을 반환.

**즉시 진단**:
```bash
source ~/.hermes/secrets/nvidia_keys.env
echo "현재 키로 chat 호출:"
curl -s -w "\nHTTP_CODE: %{http_code}\n" -X POST "https://integrate.api.nvidia.com/v1/chat/completions" \
  -H "Authorization: Bearer $NVIDIA_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"model": "openai/gpt-oss-120b", "messages": [{"role":"user","content":"ping"}], "max_tokens": 50}' 2>&1 | head
```

**HTTP 200 → 정상**, **HTTP 500 + "Missing request extension: headers::common::authorization"** → **키 불량**.

**해결**:
1. `~/.hermes/secrets/nvidia_keys.env`에 저장된 `NVIDIA_API_KEY_1`이 정상인지 확인
2. 여러 키 보유 시 명시적으로 `export NVIDIA_API_KEY="$NVIDIA_API_KEY_1"`
3. 모두 실패 시 https://build.nvidia.com 에서 새 키 발급

**헷갈림 방지**:
- zsh 환경에서 다른 shell의 `export`이 남아있을 수 있음 → `echo $NVIDIA_API_KEY`로 어떤 키가 export 됐는지 먼저 확인
- `~/.zshrc`에 잘못된 키가 export 되어 있으면 새 shell이 매번 잘못된 키 사용

→ `references/nim-api-key-500-pitfall.md`

## 워크플로우 (5단계)

### Stage 0: 메타 결정 (사용자 cross-check 필수)

```
1. LICENSE 호환성 — Apache 2.0 / MIT / BSD 권장, GPL/AGPL 사용자 확인
2. LLM 백엔드 — OpenAI 호환 제공자 (NIM / OpenRouter / Ollama / vLLM)
3. 외부 LLM 모델 — gpt-oss-120b / llama-3.1 / claude / minimax 등
4. 임베딩 모델 — 비대칭 (llama-nemotron) vs 대칭 (nv-embed-v1) 트레이드오프
5. 한글화 범위 — wrapper만 / 페르소나 / 프롬프트 / UI 전부
6. Django 마이그레이션 필요 여부 (Django 프로젝트면 §17 참조)
7. 사용자 Hermes 데스크탑 여부 (PYTHONPATH 간섭 가능성 §18)
```

### Stage 1: 클론 + LICENSE

```bash
mkdir -p ~/work/{repo-name}-kr && cd ~/work/{repo-name}-kr
cp -r /tmp/{repo-name}-check/. .  # 또는 git clone --depth 1
echo "storage/" >> .gitignore
echo "compressed_storage/" >> .gitignore
echo "db.sqlite3" >> .gitignore
rm -rf .git && git init -b main
git remote add origin https://github.com/{user}/{repo-name}-kr.git

# LICENSE 보존 + MODIFIED.md 작성 + Apache 2.0 §4(a) 표시
git add -A
git -c user.email=action@github.com -c user.name="{user}" \
  commit -m "chore: import upstream (LICENSE)"
git push -u origin main
```

### Stage 2: LLM 백엔드 교체 (gpt_structure.py)

원본 파일 read → `wrapper` 1개 작성 → self-test → commit. **reasoning 모델 처리 필수** (함정 10).

### Stage 3: 임베딩 검증 (50 케이스)

비대칭/대칭 + 카테고리별(어순/부정/부분정보/같은카테고리/시간/시제 등) 테스트 → 모델 선정 → 적용.

### Stage 4: 한글 페르소나 + 프롬프트 + UI

페르소나 시드 (3-25명) + 프롬프트 파일 (50+) + Django/React UI 순차.

### Stage 3.5: 프롬프트 자동번역 (NEW, 2026-07-14)

프롬프트 파일이 30개+ 일 때 LLM 자동번역 필수. `run_gpt_prompt.py`의 dead code (`########` 마커) 제외하고 실제 active만 식별.

전체 패턴 + 검수 도구 + 재번역 루프:
→ `references/prompt-auto-translation.md`

핵심 3단계:
1. `translate_prompts_kr.py` — NIM gpt-oss-120b 일괄 자동번역 (35개 → 4.7분)
2. `review_prompts_kr.py` — 코드 손실 + 한국어 어색 패턴 자동 검수 (74% clean)
3. 손상 파일 6개 추출 → 재번역 (LLM 응답 길이/품질 변동성 흡수)

### Stage 5: README + 검증 + push

한글 README + 첫 commit → 진행 단계 표시 + 푸시.

### Stage 4.5: Django UI 한글화 (NEW, 2026-07-14)

`base.html` 보강 (헤더/푸터 + `lang="ko"`) + 정적 텍스트 sed 매핑 + 이모지 prefix. JS는 거의 패스 (LLM 한국어 응답으로 자동). persona_state 같은 detail 페이지는 python re.sub으로 25+ 라벨 일괄 처리.

→ `references/django-ui-localization.md`

### Stage 5.5: end-to-end 시뮬레이션 검증 (NEW, 2026-07-14)

Django + reverie.py 양쪽 띄우는 무거운 검증 대신, 핵심 인지 모듈 4개 (daily_planning / task_decomp / decide_to_talk / agent_chat)을 직접 호출해서 LLM 응답이 자연스러운 한국어인지 검증. `test_kr_sim.py` 1개 파일로 ~90초 안에 끝남.

→ `references/korean-simulation-verification.md`

## NIM self-test 템플릿 (gpt_structure.py 끝부분)

```python
if __name__ == "__main__":
    print("=== NIM self-test ===\n")

    print("[1] LLM")
    print(f"    ChatGPT_single_request('ping'): {ChatGPT_single_request('ping').strip()}")

    print("[2] 비대칭 임베딩")
    p = get_passage_embedding("이서연은 카페에서 커피를 마신다")
    q = get_query_embedding("이서연이 마신 음료는?")
    print(f"    차원: {len(p)}, 유사도: {cosine_similarity(p, q):.3f}")

    print("[3] 부정 가드")
    pn = get_passage_embedding("이서연은 카페에서 커피를 마시지 않았다")
    pqn = cosine_similarity(pn, q)
    pqn_guarded = pqn - negation_penalty(
        "이서연은 카페에서 커피를 마시지 않았다",
        "이서연이 마신 음료는?")
    print(f"    부정 케이스: {pqn:.3f} → (가드 후) {pqn_guarded:.3f}")
```

기대 출력:
```
[1] LLM
    ChatGPT_single_request('ping'): ping
[2] 비대칭 임베딩
    차원: 2048, 유사도: 0.474
[3] 부정 가드
    부정 케이스: 0.457 → (가드 후) 0.057
```

## 검증 워크플로 (push 후)

- [ ] GitHub repo Description에 LICENSE 자동 인식 (`spdx_id: Apache-2.0`)
- [ ] 원본 LICENSE 파일 그대로 보존
- [ ] MODIFIED.md 작성 (Apache 2.0 §4(a) 표시)
- [ ] `gpt_structure.py self-test` 3-row 출력 정상
- [ ] 임베딩 차원/유사도가 비대칭 모델 (예: llama-nemotron = 2048d)
- [ ] **LLM 응답에 `reasoning_content` 또는 `content` 둘 중 하나 추출** (reasoning 모델 fix 검증)
- [ ] 한/영 혼용 README 시 원본 영문 보존
- [ ] 프롬프트 자동번역: `python3 review_prompts_kr.py` 실행 → `clean >= 90%`
- [ ] 코드 손실 0개 (`MISSING 마커` 항목 비어있음)
- [ ] 한국어 어색 패턴 ≤ 5개 (조사 연속, 잔존 영어)
- [ ] end-to-end dry-run: `generate_prompt()` 라우팅 + `ChatGPT_safe_generate_response()` 호출 → 한국어 자연스러운 응답 1회 검증
- [ ] **prompt_template_kr/ 중복 디렉토리 없음** (`find . -name prompt_template_kr` 결과 1개만)
- [ ] **.gitignore 검증**: `environment/frontend_server/{temp_storage,compressed_storage,db.sqlite3,*.log,environment}` 모두 ignore되어 있는지
- [ ] **zsh 따옴표 점검**: README의 모든 `pip install <pkg>>=X.Y` 라인에서 version specifier가 따옴표로 감싸져 있는지 (macOS 기본 셸 = zsh, `>` 는 redirection)
- [ ] **README Phase 표**: 완료된 모든 단계 + 커밋 해시 + 검증 출력 (한국어 agent_chat 예시)
- [ ] **write_file path 검증**: 새 파일 생성 직후 `ls -la path/` 로 파일명에 `<`/`path>` 같은 literal 없는지 확인
- [ ] **Django 마이그레이션** (해당 시): `manage.py check` "System check identified no issues" + `runserver` HTTP 200
- [ ] **PYTHONPATH unset** (Hermes 데스크탑): venv 활성화 후 `unset PYTHONPATH` 실행
- [ ] **storage/ 시나리오 부재 시 sparse-checkout**: `git clone --depth 1 --filter=blob:none --sparse` 로 1GB 중 일부만 다운로드
- [ ] **NIM API 키 진단**: gpt_structure.py self-test 500 → `curl` 로 직접 NIM 호출 → HTTP_CODE로 키 불량/만료/오타 모델ID 판별
- [ ] **Two-terminal 실행**: Django(터미널1) + reverie.py(터미널2) 동시, `run 100` 후 브라우저 `http://localhost:8000/replay/{sim}/{step}/` 확인
- [ ] **LLM markdown 응답 파싱**: reasoning 모델 응답에 `**이름**`/`| 표 |` 섞이면 regex-first 파싱 (`re.DOTALL`) + 라인 기반 폴백

## 관련 스킬

- `oss-python-bootstrap` — 새 OSS 프로젝트 0→1 (이 스킬은 fork)
- `github-profile-readme` — 프로필 README (LLM 키 표시 같은 표기 일관성)
- `github-repo-management` — fork/PR/release 운영
- `ad-hoc-verifier` — 검증 단계 ad-hoc 패턴
- `gjc-cli-setup` — gjc CLI provider 등록 시 gpt-oss-120b prefix 학습
- **`legacy-repo-modernization`** — 2022 → 2026 마이그레이션 종합 (이 스킬과 클래스 중복 — Django/PYTHONPATH/venv 함정 정식 참조처)

## 보조 파일

- `references/apache-2.0-modified-md-template.md` — Apache 2.0 fork용 MODIFIED.md 작성 템플릿 (Stanford generative_agents 사례)
- `references/nim-llm-backend-swap.md` — OpenAI → NIM wrapper 변경 패턴 (함수 시그니처 호환)
- `references/embedding-validation-50-cases.md` — 한국어 임베딩 50 케이스 검증 데이터 (어순/시제/조사/부정/같은카테고리 등)
- `references/asymmetric-embedding-pattern.md` — 비대칭 임베딩 (passage/query) 함수 분리 + retrieval 점수 산정
- `references/korean-embedding-benchmarks.md` — NIM 11개 임베딩 모델 실측 벤치마크 (llama-nemotron-embed-1b-v2 승자) ★ NEW
- `references/korean-persona-seed-pattern.md` — 한국어 페르소나 시드 (josa 자동 + 비밀 중복 제거 + whisper 생성) ★ NEW
- `references/prompt-auto-translation.md` — 35+ 프롬프트 파일 LLM 자동번역 + 검수 + 재번역 루프, v3_ChatGPT dead code 식별, `########` 마커 패턴, INPUT 마커 손실 사례 (decide_to_react 9개 손실 → 직접 작성), task_decomp 2584자 LLM 응답 길이 한계, **prompt_template_kr/ 중복 디렉토리 함정** ★ NEW
- `references/nim-llm-backend-swap.md` — OpenAI → NIM wrapper 변경 패턴 + **reasoning 모델 `content=None` CRITICAL fix (10줄)** ★ UPDATED 2026-07-14
- `references/git-large-storage-pitfall.md` — 1GB+ storage 디렉토리 git 인덱싱 60초 timeout 함정 + 3-step 해결
- `references/django-ui-localization.md` — Django/HTML 템플릿 한글화 (base/landing/home/error/demo/persona_state), sed 매핑 + 이모지 prefix, JS는 패스 ★ NEW
- `references/korean-simulation-verification.md` — Phase 5 end-to-end 검증, `test_kr_sim.py` 4모듈 패턴 (daily_planning/task_decomp/decide_to_talk/agent_chat), 검증 4축 + reasoning 모델 진단 ★ NEW
- `references/macos-pip-pep668-pitfall.md` — macOS Sonoma+ `pip install` 실패 4가지 증상 + 3가지 해결책 (Hermes venv / .venv / --break-system-packages), flexible 버전 통합 설치 패턴 ★ NEW
- `references/prompt-auto-translation.md` — 35+ 프롬프트 파일 LLM 자동번역 + 검수 + 재번역 루프, v3_ChatGPT dead code 식별, `########` 마커 패턴, INPUT 마커 손실 사례 (decide_to_react 9개 손실 → 직접 작성), task_decomp 2584자 LLM 응답 길이 한계, **prompt_template_kr/ 중복 디렉토리 함정** ★ NEW
- `references/two-terminal-sim-execution.md` — Django 시각화(터미널 1) + reverie.py(터미널 2) 동시 실행, sparse-checkout으로 storage/ 다운로드, fork 시나리오 이름 규약, run/fin/save 명령, 브라우저 URL ★ NEW 2026-07-14
- `references/llm-markdown-response-parsing.md` — gpt-oss-120b reasoning 모델의 markdown 표/별표 헤더 응답 처리, regex-first 파싱 패턴 (re.DOTALL), task_decomp IndexError 해결 ★ NEW 2026-07-14
- `references/llm-max-tokens-pitfall.md` — `GPT_request()` `max_tokens=100` 기본값 함정 (CRITICAL, 2026-07-14 ★★★), reasoning 모델에서 100 토큰은 reasoning trace도 못 담음, self-test는 통과하지만 시뮬에서 100% fail_safe 폴백, 4가지 검증 방법 + 모델별 권장 max_tokens 표 ★ NEW 2026-07-14
- `references/nim-api-key-500-pitfall.md` — NIM 500/401 에러 즉시 진단법 (`Missing request extension: headers::common::authorization` = 키 불량), curl로 직접 검증 패턴, `~/.hermes/secrets/nvidia_keys.env` 활용 ★ NEW 2026-07-14
- `references/sim-diagnostic-lookup.md` — 시뮬레이션 실행 중 발생하는 13개 에러 위치별 즉석 패치 룩업 표 (reverie.py / Django / NIM chat+embed / LLM 파서 / FileExists/FileNotFound / port 충돌), 5분 진단 룰, 단계별 정상 출력 패턴 ★ NEW 2026-07-14
