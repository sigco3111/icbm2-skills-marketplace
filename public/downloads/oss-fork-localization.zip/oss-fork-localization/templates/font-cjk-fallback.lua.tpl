-- Font 클래스에 추가할 CJK 헬퍼 (snkrx-clone 2026-07-21 검증 완료)
-- 이 코드를 engine/graphics/font.lua의 Font 클래스에 복사
-- 그리고 graphics.lua + text.lua도 패치 필요 (아래 주석 참조)

function Font:has_cjk(text)
  if not text then return false end
  for i = 1, #text do
    local b = string.byte(text, i)
    -- CJK Unified Ideographs (U+4E00-U+9FFF), Hangul Syllables (U+AC00-U+D7AF)
    -- 멀티바이트 UTF-8 시작 바이트 (0xE0-0xEF)
    if (b >= 0xE0 and b <= 0xEF) then return true end
  end
  return false
end


function Font:_ensure_ko_font()
  if self.ko_font then return self.ko_font end
  -- Noto Sans KR 파일이 없으면 영어 폰트로 폴백 (깨지지만 작동)
  local ko_path = "assets/fonts/NotoSansKR-Regular.ttf"
  if love.filesystem.getInfo(ko_path) then
    self.ko_font = love.graphics.newFont(ko_path, self.size)
  else
    self.ko_font = self.font
  end
  return self.ko_font
end


function Font:get_font_for_text(text)
  if self:has_cjk(text) then return self:_ensure_ko_font() end
  return self.font
end


-- get_text_width 오버라이드 (CJK 너비 정확 계산)
-- 원본의 function Font:get_text_width(text)를 교체
function Font:get_text_width(text)
  if self.ko_font and self:has_cjk(text) then
    return self.ko_font:getWidth(text)
  end
  return self.font:getWidth(text)
end


--[[ ─────────────────────────────────────────────────────────────
  engine/graphics/graphics.lua — graphics.print/print_centered 패치

  원본:
    function graphics.print(text, font, x, y, r, sx, sy, ox, oy, color)
      local _r, g, b, a = love.graphics.getColor()
      if color then love.graphics.setColor(color.r, color.g, color.b, color.a) end
      love.graphics.print(text, font.font, x, y, r or 0, sx or 1, sy or 1, ox or 0, oy or 0)
      if color then love.graphics.setColor(_r, g, b, a) end
    end

  교체:
    function graphics.print(text, font, x, y, r, sx, sy, ox, oy, color)
      local _r, g, b, a = love.graphics.getColor()
      if color then love.graphics.setColor(color.r, color.g, color.b, color.a) end
      local active_font
      if font.get_font_for_text then
        active_font = font:get_font_for_text(text)
      else
        active_font = font.font
      end
      love.graphics.print(text, active_font, x, y, r or 0, sx or 1, sy or 1, ox or 0, oy or 0)
      if color then love.graphics.setColor(_r, g, b, a) end
    end

  ※ Lua 5.5 luac가 `font:get_font_for_text and font:get_font_for_text(text) or font.font`
    패턴을 "function arguments expected near 'and'" 에러로 거부함.
    반드시 명시적 if/else 사용.

───────────────────────────────────────────────────────────── ]]


--[[ ─────────────────────────────────────────────────────────────
  engine/graphics/text.lua — Text:format_text + Text:draw 패치

  Text:format_text 내 line_width 계산:
    원본: local line_width = math.max(line.font:get_text_width(line.raw_text), line.alignment_width or 0)
    교체:
      local active_font
      if line.font.get_font_for_text then
        active_font = line.font:get_font_for_text(line.raw_text)
      else
        active_font = line.font.font
      end
      local line_width = math.max(active_font:getWidth(line.raw_text), line.alignment_width or 0)

  캐릭터별 폭 계산 (x = x + cf:getWidth(c.character)):
    원본: c.w = line.font:get_text_width(c.character)
    교체:
      local cf
      if line.font.get_font_for_text then
        cf = line.font:get_font_for_text(c.character)
      else
        cf = line.font.font
      end
      c.w = cf:getWidth(c.character)

  Text:draw 내 graphics.print 호출:
    원본: graphics.print(c.character, line.font, ...)
    교체: (graphics.print가 이미 CJK 자동 처리하므로 그대로 두거나,
           명시적으로 line.font:get_font_for_text(c.character) 사용)

───────────────────────────────────────────────────────────── ]]