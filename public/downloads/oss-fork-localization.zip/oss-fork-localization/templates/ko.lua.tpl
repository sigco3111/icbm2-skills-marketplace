-- ko.lua — 한국어 번역 테이블 (starter)
-- 이 파일을 lang/ko.lua로 복사 후 게임에 맞게 키 추가
-- 누락 시 T(key, default)이 default를 그대로 표시하므로 영어 원본 안전 폴백
return {
  -- ===== 메인 메뉴 =====
  -- 예: button_text = T('arena_run', 'arena run') 패턴
  -- arena_run = '아레나 런',
  -- options = '옵션',
  -- quit = '종료',

  -- ===== 일반 UI =====
  -- 예: Text2{...{text = '[fg]' .. T('continue', 'continue')}}
  -- continue = '계속',
  -- cancel = '취소',
  -- back = '뒤로',
  -- close = '닫기',
  -- yes = '예',
  -- no = '아니오',
}