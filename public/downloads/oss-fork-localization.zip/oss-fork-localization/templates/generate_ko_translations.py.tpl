#!/usr/bin/env python3
"""Generate fbtee translate input file for any new locale.

Reusable batch-translation generator for Meta's `fbtee` pipeline.

- Reads `source_strings.json` (output of `pnpm fbtee:collect`)
- Extracts every unique `hashToLeaf[hash]` -> {desc, text}
- Calls a public LibreTranslate endpoint in 30-item batches
- Emits `<LOCALE>_translations.json` in the fbtee translate input schema:

  {
    "fb-locale": "<LOCALE>",
    "translations": {
      "<hash>": {
        "tokens": {},
        "types": {},
        "translations": [{
          "translation": "<translated text>",
          "variations": []
        }]
      }
    }
  }

Variables to set at top of `main()`:
  SOURCE_PATH: fbtee collect output (default: source_strings.json)
  OUT_PATH: target fbtee translate input file (default: <LOCALE>_translations.json)
  TARGET_LOCALE: e.g. "ko_KR", "ja_JP", "zh_CN"
  SOURCE_LOCALE: e.g. "en", "en_US"
  ENDPOINT: LibreTranslate-compatible URL (default: translate.fedilab.app)
  BATCH_SIZE: 30 (batch count per HTTP call)
  DELAY_BETWEEN_BATCH: 0.4s (rate limit guard)
  MAX_RETRIES: 4 (exponential backoff per batch)

After running:
  cd ares
  pnpm fbtee:translate -- --translations ../<OUT_PATH> --output-locale-style preserve
  -> ares/src/generated/<LOCALE>.json
"""
import json
import sys
import time
import urllib.request
import urllib.error

# --- Configurable variables ---
SOURCE_PATH = "source_strings.json"
OUT_PATH = "ko_KR_translations.json"
TARGET_LOCALE = "ko_KR"
SOURCE_LOCALE = "en"

ENDPOINT = "https://translate.fedilab.app/translate"
BATCH_SIZE = 30
DELAY_BETWEEN_BATCH = 0.4
MAX_RETRIES = 4

# --- Translator ---
session_total_calls = 0


def translate_batch(items):
    """Translate (id, text) items in one batch. Returns dict id -> translated.

    On total failure, returns dict mapping id -> original English text (so the
    fbtee pipeline still emits English fallback for those entries). Always
    logs batch failures to stderr for follow-up polish sessions.
    """
    global session_total_calls
    payload = json.dumps({
        "q": [t for _, t in items],
        "source": SOURCE_LOCALE,
        "target": TARGET_LOCALE,
        "format": "text",
    }).encode("utf-8")
    headers = {
        "Content-Type": "application/json",
        "User-Agent": "fbtee-batch-translate/1.0",
    }

    last_err = None
    for attempt in range(MAX_RETRIES):
        try:
            req = urllib.request.Request(
                ENDPOINT, data=payload, headers=headers, method="POST",
            )
            with urllib.request.urlopen(req, timeout=60) as resp:
                body = resp.read().decode("utf-8")
            session_total_calls += 1
            data = json.loads(body)
            if (
                "translatedText" in data
                and isinstance(data["translatedText"], list)
                and len(data["translatedText"]) == len(items)
            ):
                return {id_: ko for (id_, _), ko in zip(items, data["translatedText"])}
            if "translatedText" in data and isinstance(data["translatedText"], str):
                if len(items) == 1:
                    return {items[0][0]: data["translatedText"]}
                last_err = f"Single response for batch of {len(items)}"
            elif "error" in data:
                last_err = data["error"]
            else:
                last_err = f"Unknown response: {body[:200]}"
        except urllib.error.HTTPError as e:
            last_err = f"HTTP {e.code}: {e.reason}"
        except urllib.error.URLError as e:
            last_err = f"URLError: {e.reason}"
        except Exception as e:
            last_err = f"{type(e).__name__}: {e}"
        time.sleep(2 * (attempt + 1))
    print(f"  !! batch translate failed ({len(items)} items): {last_err}",
          file=sys.stderr)
    # Fallback: keep English text
    return {id_: orig for id_, orig in items}


def main():
    with open(SOURCE_PATH, "r", encoding="utf-8") as f:
        src = json.load(f)

    leaf_map = {}  # hash -> (desc, text)
    for phrase in src["phrases"]:
        for h, leaf in phrase["hashToLeaf"].items():
            if h not in leaf_map:
                leaf_map[h] = (leaf.get("desc", "") or "", leaf.get("text", "") or "")

    items = [(h, txt) for h, (_, txt) in leaf_map.items() if txt.strip()]
    print(f"Unique leaf hashes: {len(leaf_map)}, non-empty: {len(items)}")

    translated = {}
    start = time.time()
    for i in range(0, len(items), BATCH_SIZE):
        batch = items[i:i + BATCH_SIZE]
        print(f"  batch {i}..{min(i + BATCH_SIZE, len(items))} "
              f"({len(batch)} items, {session_total_calls} calls total)",
              end=" ")
        result = translate_batch(batch)
        translated.update(result)
        print(f"-> {len(result)} done ({time.time() - start:.1f}s)")
        time.sleep(DELAY_BETWEEN_BATCH)

    out_translations = {}
    for h, (desc, text) in leaf_map.items():
        out_translations[h] = {
            "tokens": {},
            "types": {},
            "translations": [{
                "translation": translated.get(h, text),
                "variations": [],
            }],
        }

    payload = {
        "fb-locale": TARGET_LOCALE,
        "translations": out_translations,
    }

    with open(OUT_PATH, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)

    elapsed = time.time() - start
    print(f"\nWrote {OUT_PATH} with {len(out_translations)} entries "
          f"({session_total_calls} calls, {elapsed:.1f}s)")


if __name__ == "__main__":
    main()
