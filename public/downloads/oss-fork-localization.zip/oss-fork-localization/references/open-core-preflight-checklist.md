# Open Core / 비공개 본체 함정 + 5분 Preflight 실측 가이드

> 2026-07-27 athena-crisis-kr 4시간 낭비 직후 정리. "i18n 모듈 분리형 · 모드팩 패턴 · Vercel 즉시 배포" 같은 외관 좋은 특징만 보고 들어갔다가 **게임 본체가 비공개**라 어떤 방법으로도 빌드 안 되는 Open Core 정책 함정에 빠진 사례에서 추출.

## 🚨 결정적 교훈 (즉시 적용)

**Open Core 정책 = 핵심 코드는 비공개, peripheral(UI/i18n/문서)만 공개.** GitHub에서 `gh repo view --json`이 노출하는 건 peripheral뿐이라 **i18n 패키지가 잘 분리되어 있어도 본체 소스가 없으면 빌드 절대 불가**.

## athena-crisis 실측 — 4시간 낭비 타임라인

| 시점 | 한 일 | 결과 |
|---|---|---|
| T+0 | 후보 5개 추천 (athena-crisis 1순위, MIT 라이선스) | ✅ |
| T+5 | fork + 셋업 + pnpm install 33초 + 5173 OK | ✅ |
| T+10 | fbtee 한국어 키 추출 (1,493개) | ✅ |
| T+15 | AutoBattleAI 추가 + Conservative/Aggressive 등록 | ✅ |
| T+20 | ko_KR_translations.json 1,535개 채움 | ✅ |
| T+30 | `pnpm build:offline` → dist/offline/index.html (1.85MB) | ⚠️ **게임이 아닌 영문 안내 페이지** |
| T+45 | `pnpm build:client` 시도 | ❌ `ares/vite.config.ts` 부재로 실패 |
| T+60 | codegen 시도 (`pnpm codegen` → 5개 generator Done) | ⚠️ 산출물은 peripheral만 |
| T+90 | `art/Variants.nkzw.tsx` 더미로 우회 시도 | ❌ **이 파일은 paid 모드 마커일 뿐, 의존성 아님** |
| T+120 | ares/vite.config.ts + index.html + main.tsx 가짜로 빌드 | ❌ 가짜 빌드 (한국어 1단어 박힌 빈 페이지) |
| T+180 | 정직하게 인정: 어떤 방법으로도 게임 빌드 불가 | ❌ |
| T+240 | 보존 자산 (1,535개 번역 + AutoBattleAI 코드) + 깨끗이 롤백 | ✅ 의미 있는 자산 보존 |

**총 4시간, 게임 0개 배포.** 보존된 자산(번역 데이터 + AI 로직)은 다른 fork에 재사용 가능.

## 🔍 5분 Preflight 실측 명령 (CRITICAL)

**`gh repo view --json` + README 분석만으로 빌드 가능성 판단하지 말 것.** 다음 5개를 **반드시 실측**:

```bash
# 1) 디렉토리 구조 (특히 vite.config / package.json / src/ 존재)
gh api repos/<owner>/<repo>/git/trees/<branch>?recursive=1 | \
  python3 -c "import json,sys; d=json.load(sys.stdin); [print(t['path']) for t in d.get('tree',[]) if t['path'] in ('package.json','vite.config.ts','vite.config.js','Cargo.toml','index.html') or t['path'].endswith('/main.tsx') or t['path'].endswith('/main.js') or t['path'].endswith('/App.tsx')]"

# 2) 라이선스 정확 확인 (README 언급 믿지 말 것)
gh repo view <owner>/<repo> --json licenseInfo --jq '.licenseInfo.spdxId // "NOASSERTION"'
# → NOASSERTION = 라이선스 미명시 (대부분 비공개 가능성)
# → AGPL-3.0 / GPL-3.0 / LGPL / SSPL = fork 시 강력한 의무
# → MIT / BSD-2/3 / Apache-2.0 = 가장 안전

# 3) README 외관 좋은 i18n 분리도 함정
gh api repos/<owner>/<repo>/contents/i18n 2>/dev/null
gh api repos/<owner>/<repo>/contents/src/i18n 2>/dev/null
# ↑ i18n 있어도 본체가 비공개면 무의미

# 4) .gitignore에 의도적 추적 제외 파일이 있는지
gh api repos/<owner>/<repo>/contents/.gitignore --jq '.content' | base64 -d | head -40
# ↓ 위험 신호 패턴
#   ares/.src_manifest.json
#   ares/**/__generated__
#   ares/src/generated/*
#   art/Variants.nkzw.tsx (있으면 paid 마커)
#   app/EncodedActions.tsx
#   app/Routes.tsx

# 5) 실제 clone + 빌드 시도 (가장 결정적, 5분)
git clone --depth 1 https://github.com/<owner>/<repo>.git /tmp/preflight-<name>/
cd /tmp/preflight-<name>/
ls node_modules/ 2>/dev/null && echo "← 이미 의존성 있으면 유리" || echo "← clone만으로는 판단 불가"
# 빌드 명령이 README에 있든 말든 직접 시도
pnpm install --ignore-scripts   # ignore-scripts로 postinstall trap 우회
pnpm build 2>&1 | head -20
# ↑ vite.config 부재 / main.tsx 부재 / Vite "Cannot resolve entry" 에러 → 비공개 본체
```

**5개 중 1개라도 비공개 신호 → 진입 보류, 다른 후보로.**

## 🎯 Open Core / 비공개 본체 신호 5가지

| 신호 | 의미 |
|---|---|
| `.gitignore`에 `src/generated/*`, `app/EncodedActions.tsx`, `app/Routes.tsx` 같은 codegen 산출물이 명시 | codegen이 비공개 소스로부터 만드는 구조 — 공개 fork는 codegen 실행 못 함 |
| `art/Variants.<customer>.tsx` 같은 paid 마커 파일 | customer 이름 = 클라이언트명, paid 플랜일 때만 존재. OSS fork에서는 없어서 paid 모드 강제 가능 |
| `infra/isOpenSource.tsx`의 `existsSync`로 paid/OSS 분기 | paid 모드에서는 본체 모듈이 closed artifact에서 옴, OSS에서는 무력한 placeholder만 |
| i18n이 너무 잘 분리되어 있음 (peripheral만 공개) | 본체 비공개 + peripheral만 OSS로 친절하게 공개하는 마케팅 전략 |
| Discord/유료 고객/엔터프라이즈 mention in README | 본체는 closed distribution |

**판별 매트릭스**:

| 상태 | 신호 조합 | 진입 결정 |
|---|---|---|
| **진짜 OSS** | package.json + main.tsx + LICENSE(permissive) + 모든 src/ 추적 | 🟢 진행 |
| **Open Core peripheral** | i18n 모듈 + codegen 산출물만 .gitignore + paid 마커 | 🔴 **진행 금지** |
| **Open Source with paid extras** | 일부 feature는 paid 마커 뒤에, 핵심은 OSS | 🟡 paid feature 제외하고 진행 |
| **Monorepo with closed subpackage** | 모노레포 안에 `private-packages/<name>` 추적 제외 | 🔴 해당 subpackage 의존 시 진행 금지 |

## 📋 라이선스별 fork 의무 매트릭스 (GitHub API의 spdxId 기준)

| 라이선스 | spdxId | fork 의무 | 한국어 리소스 추가 시 |
|---|---|---|---|
| **MIT** | `MIT` | 저작권 + LICENSE 텍스트 포함 | 🟢 자유 |
| **BSD-2-Clause / BSD-3-Clause** | `BSD-2-Clause` / `BSD-3-Clause` | 저작권 + LICENSE 텍스트 | 🟢 자유 |
| **Apache-2.0** | `Apache-2.0` | LICENSE + NOTICE + 변경 표시 | 🟢 MODIFIED.md 권장 |
| **MPL-2.0** | `MPL-2.0` | **수정한 파일만 MPL 공개** (§3.1-3.3) | 🟢 변경분만 공개하면 OK |
| **LGPL-2.1 / LGPL-3.0** | `LGPL-2.1-only` 등 | 동적 링크 시 LGPL 유지, 정적 링크 시 소스 공개 | 🟡 라이선스 검토 필요 |
| **GPL-2.0 / GPL-3.0** | `GPL-2.0` / `GPL-3.0` | **fork 결과물 전체 GPL 전파** | 🔴 강력 권장 |
| **AGPL-3.0** | `AGPL-3.0` | GPL + **네트워크 서비스로 제공 시 §13 소스 공개 의무** | 🔴 Vercel/웹 배포 시 법무 확인 |
| **SSPL-1.0** | `SSPL-1.0` | 서비스화 시 전체 인프라 소스 공개 | 🔴🔴 SaaS 불가 |
| **NOASSERTION** | (라이선스 미명시) | 법적 불명확 | 🔴 **진행 금지** |

**`gh repo view --json licenseInfo --jq '.licenseInfo.spdxId'`로 정확 확인.** README가 "MIT"라 써도 실제는 다른 라이선스일 수 있음 (athena-crisis: 워커가 처음에 "MIT"로 추측 → 실제 확인 시 복잡한 Open Core 구조).

## ⭐ Evolve의 `Object.assign` 폴백 i18n 패턴 (NEW, 2026-07-27, 재사용 권장)

**Evolve (pmotschmann/Evolve, MPL-2.0)의 깔끔한 i18n 구조** — 한국어 87.3% 미번역 상태에서도 **사용자가 못 느끼는** silent 폴백. 다른 fork에 그대로 적용 가능.

```js
// src/locale.js
const translations = {
  'en-US': require('../strings/strings.json'),
  'ko-KR': require('../strings/strings.ko-KR.json'),
  // ...
};

function getString(locale) {
  const fallback = translations['en-US'];
  const localized = translations[locale] || {};
  return Object.assign({}, fallback, localized);
  // 미번역 키는 fallback(en-US)에서 가져옴 → silent 폴백
}
```

**장점**:
- 미번역 키 0개여도 게임은 동작 (영문 표시)
- 한국어 점진 번역 가능 (1,506개 → 500개 → 100개 → 0)
- `checkStrings.py` 같은 정적 검증 도구로 미번역 비율 추적

**번역 진척도 추적 워크플로**:
```bash
# Evolve의 strings/checkStrings.py 활용 예시
python3 strings/checkStrings.py
# 출력: "Coverage: 87.3% (10164/11641), Missing: 1506, KO-only: 29"

# 미번역 키 추출 (직접 작성)
python3 -c "
import json
en = json.load(open('strings/strings.json'))
ko = json.load(open('strings/strings.ko-KR.json'))
missing = [k for k in en if k not in ko or not ko[k].strip()]
print(f'Missing: {len(missing)} / {len(en)} = {len(missing)/len(en)*100:.1f}%')
for k in missing[:5]: print(f'  {k} = {repr(en[k])[:80]}')
"
```

**한국어 100% 달성을 위한 작업량 추정**:
| 미번역 키 수 | 작업 시간 | 방식 |
|---|---|---|
| 0~100개 | 10분 | LLM 일괄 (배치 10개씩) |
| 100~500개 | 1~2시간 | LLM + 사용자 검토 |
| 500~2000개 | 4~8시간 | LLM 일괄 + 사후 품질 검수 |
| 2000개+ | 1~2일 | LLM + 도메인 전문가 검수 + glossary 구축 |

## 🛡️ 진행 전 4-gate 체크리스트

```markdown
# OSS fork 후보 진행 전 4-gate
- [ ] Gate 1: `gh repo view --json licenseInfo --jq '.licenseInfo.spdxId'`이 permissive (MIT/BSD/Apache) 또는 약한 copyleft (MPL-2.0) 인가
- [ ] Gate 2: 실제 clone 후 `ls node_modules/` 비어있고 `pnpm install` 5분 내 성공
- [ ] Gate 3: `pnpm build` 또는 `npm run build` 5분 내 산출물 생성 (dist/ 또는 build/)
- [ ] Gate 4: 빌드 산출물 grep으로 게임 핵심 텍스트/UI 1개 이상 박혀있음 (예: "Welcome", "시작", "Press Start")
```

**4개 모두 통과해야 진행. 1개라도 실패 시 다른 후보로 즉시 전환.**

## 🔄 Evolve 한국어화 진행 중 (2026-07-27 기준)

- 저장소: https://github.com/sigco3111/evolve-kr
- 부팅: HTTP 200 ✅
- 한국어 번역: 87.3% (1,506개 미번역)
- 첫 commit `397365a` 푸시 완료
- 2단계 워커 실행 중 (한국어 100% + vercel.json + .gitignore 정리)

**이번 사례의 가치**:
- ✅ 5분 preflight에서 "정적 사이트 + 87.3% 한국어 + MIT급 라이선스" 확인 → 진행 결정 정당
- ✅ Open Core 함정 없음 (전체 소스 추적)
- ✅ 한국어 100% 달성은 미번역 1,506개 채우기로 달성 가능
- ⚠️ `package.json`의 잘못된 `dependencies.node` 라인이 Vercel 빌드 함정 → 4단계에서 동시 해결

## 즉시 적용 규칙 (모든 OSS fork 작업)

1. **첫 5분 = preflight 실측** — README/모듈 구조 보지 말고 clone + install + build 실측
2. **라이선스는 `spdxId`로** — README의 "MIT" 언급 절대 믿지 말 것
3. **Open Core 신호 5개** — `.gitignore`의 codegen 산출물 / paid 마커 / i18n 과도한 분리 / Discord 언급
4. **AGPL-3.0 / GPL / SSPL은 Vercel 배포 시 법무 확인 우선** — 배포하지 않고 dev 환경에서만 써도 OK
5. **4-gate 모두 통과해야 진행** — 1개 실패 시 즉시 다른 후보로
6. **Evolve 스타일 `Object.assign` 폴백** — 미번역 키가 silent 폴백되는 i18n 패턴 우선 선택
7. **가짜 빌드 절대 금지** — `vite.config.ts` + `index.html` + `main.tsx` 더미로 "한국어 박혔다" 보고는 정직성 위반. 본체 빌드 실패 시 **솔직히 인정하고 다른 후보로**

## 다른 포크 클래스에 적용

- ✅ **브라우저 게임 (Vite/Three.js/Phaser)** — preflight 5분 실측 게이트 동일
- ✅ **LÖVE/Lua 게임** — 동일
- ✅ **Godot/Unity** — Godot 4.6+ / Unity 6 LTS 명시 확인 + `project.godot` / `Assets/` 추적 여부
- ✅ **Python/pygame** — `pyproject.toml` + `setup.py` + entry point 확인
- ✅ **C++ scons/CMake** — Boost/SDL 의존성 함정은 기존과 동일, Open Core 가능성 한 번 더 점검

## 후속 작업 후보 (athena-crisis 4시간 손실 회수용)

- **Evolve 한국어 100% + Vercel 배포** (현재 진행 중, 2단계)
- **이 패턴 재사용 가능한 곳에 적용**:
  - `slaytheweb` (AGPL-3.0) — 가벼운 웹 로그라이크, 한국어 0%
  - `PuzzleScript` (MIT) — 퍼즐 엔진, 한국 예제 게임 3종 동시
  - `increpare/PuzzleScript` 한국화 가이드
- **athena-crisis 보존 자산** (다른 fork에 재사용):
  - `ko_KR_translations.json` (1,535개 fbtee 키, 게임 일반 용어 사전)
  - `dionysus/AutoBattleAI.tsx` (Conservative/Aggressive 분기)
  - fbtee 워크플로 검증
