# Java i18n Bundle Coherence — ui.properties / ui_en.properties / ui_ko.properties 동기화

> TripleA 3차 (2026-07-28) 실측. **Java ResourceBundle Babel-style fallback chain** (`ui` → `ui_en` → `ui_ko`)에서 **3개 properties 파일의 key가 어긋나면 silent 어수선** — 빌드는 통과하지만 의미상 inconsistency.

## 문제 정의

TripleA / 다수 Java 게임이 `messages_*.properties` 또는 `ui_*.properties` 패턴을 사용. Babel-style fallback chain:

1. `ui.properties` (default = English)
2. `ui_en.properties` (English, optional override)
3. `ui_de.properties` (German)
4. `ui_ko.properties` (Korean)
5. ...

`getText("foo.bar")` 호출 시:
- 우선 `ui_ko.properties`에서 찾기
- 없으면 `ui_en.properties`로 fallback
- 없으면 `ui.properties` (default) 사용

## TripleA 3차 실측 — silent 차이

3차 C 작업 직전 properties 키 차이:

| 파일 | 키 수 |
|---|---|
| `ui.properties` (default EN) | 425 |
| `ui_en.properties` (partial EN) | 65 |
| `ui_ko.properties` (KO) | 437 |

**차이 분석**:
- `ui.properties`에만: `ingame.EditPanel.Cancel` (1개)
- `ui_ko.properties`에만: `menubar.ViewMenu.ShowZoomPercentage` (1개)
- `ui_en.properties`에만: 없음
- **빌드 OK, 한국어 게임 표시 OK** — 그러나 3개 파일이 의미상 맞지 않음

### 차이의 원인

2차 워커 (2026-07-28)가 `ui_en.properties`에 partial EN 추가하다 만 결과:
- `ui.properties` (default EN) = 메인 진실의 소스
- `ui_en.properties` = 일부 키만 (65개)
- `ui_ko.properties` = 1, 2차 + 3차 누적 (437개)

## 증상

빌드는 정상. 한국어 게임 표시도 정상. **그러나**:
- 새 빌드 환경에서 누가 `ui_en.properties`만 보고 properties 키 전체라고 오해
- 마이그레이션 / 자동화 도구가 3개 파일 각각 다르게 처리
- EN `ui.properties`만 보고 properties sync 검증 시 KO 키 누락이 catch 안 됨

## 회피 패턴

### 1. 매 세션 시작 시 차이 확인

```bash
python3 -c "
en = set()
ko = set()
en_partial = set()
for line in open('ui.properties').read().splitlines():
    if '=' in line and not line.startswith('#'):
        en.add(line.split('=',1)[0].strip())
for line in open('ui_en.properties').read().splitlines():
    if '=' in line and not line.startswith('#'):
        en_partial.add(line.split('=',1)[0].strip())
for line in open('ui_ko.properties').read().splitlines():
    if '=' in line and not line.startswith('#'):
        ko.add(line.split('=',1)[0].strip())
print('default ui.properties만:', sorted(en - ko - en_partial))
print('ui_en.properties만:', sorted(en_partial - en - ko))
print('ui_ko.properties만:', sorted(ko - en - en_partial))
"
```

### 2. 3개 언어 추가 시 항상 동시 추가

```bash
# 새 키 "ingame.X.Msg" 추가 시
echo "" >> ui.properties
echo "ingame.X.Msg=Original English" >> ui.properties
echo "ingame.X.Msg=Original Deutsch" >> ui_de.properties
echo "ingame.X.Msg=\\uc6d0\\ubcf8 \\ud55c\\uad6d\\uc5b4" >> ui_ko.properties
```

### 3. 간단한 패턴이 가장 안전

**권장**: `ui.properties` (default EN) + `ui_ko.properties` (KO) 두 개만. `ui_en.properties` partial EN을 만들지 말 것.

- `ui.properties` = default EN (English가 곧 default)
- `ui_<locale>.properties` = locale-specific override
- `<locale> = en` 이면 default와 동일 = partial EN 안 만들어도 됨

### 4. TripleA 사례

TripleA build 3차 시점:
1. `ui.properties` = default EN (425 keys)
2. `ui_en.properties` = 2차 워커 부산물 (65 keys, 사용 안 됨)
3. `ui_ko.properties` = 1차 + 2차 + 3차 (437 keys)

**해결**: `ui_en.properties`를 삭제하거나, `ui.properties`와 정확히 동일하게 만들기 (양쪽 다 425 keys). 3차에서는 시간 부족으로 그대로 두었으나 다음 세션에서 정리 가치 큼.

## 검증 명령 (Phase 1 동기화 위반 자동 검출)

```bash
# TripleA build 후
./gradlew :game-core:test --tests "games.strategy.engine.framework.I18nResourceBundleTest"
# → Default EN과 다른 언어 (KO, DE) 모두 10자 이상 키가 다른 값이어야 통과
# → 키가 한 언어에 없어도 fail

# 추가 검사: 3개 파일 diff
python3 -c "
import sys
files = ['ui.properties', 'ui_de.properties', 'ui_ko.properties']
keys = {}
for f in files:
    keys[f] = set()
    for line in open(f).read().splitlines():
        if '=' in line and not line.startswith('#'):
            keys[f].add(line.split('=',1)[0].strip())
all_keys = set().union(*keys.values())
for f in files:
    missing = all_keys - keys[f]
    if missing:
        print(f'{f} has {len(missing)} missing keys: {sorted(missing)[:10]}...')
"
```

## 관련 레퍼런스

- `java-swing-i18n-scaling.md` — Phase 2+ Swing i18n 확장 + 3언어 동시 추가 강제
- `java-resourcebundle-locale-lookup-pitfall.md` — Phase 1 Locale.lookup 함정
- `oss-fork-localization` SKILL.md — umbrella + pre-flight 5축
