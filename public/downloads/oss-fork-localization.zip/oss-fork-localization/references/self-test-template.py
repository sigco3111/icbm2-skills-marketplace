#!/usr/bin/env python3
"""
NIM + 비대칭 임베딩 + 부정 가드 self-test (gpt_structure.py 끝부분 패턴)

용도: LLM 백엔드 교체 후 push 전 호출. 3-row 출력으로 검증.

사용법:
  export NVIDIA_API_KEY="nvapi-..."
  python3 self_test_nim.py
"""
import os, sys
import urllib.request, urllib.error
import json
import math

API_KEY = os.environ.get("NVIDIA_API_KEY", "")
BASE_URL = "https://integrate.api.nvidia.com/v1"
CHAT_MODEL = "openai/gpt-oss-120b"
EMBED_MODEL = "nvidia/llama-nemotron-embed-1b-v2"


def _post(endpoint, body, timeout=120):
    url = f"{BASE_URL}{endpoint}"
    data = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(url, data=data, method="POST")
    req.add_header("Authorization", f"Bearer {API_KEY}")
    req.add_header("Content-Type", "application/json")
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def chat(messages, temperature=0.7, max_tokens=2048):
    return _post("/chat/completions", {
        "model": CHAT_MODEL, "messages": messages,
        "temperature": temperature, "max_tokens": max_tokens
    })["choices"][0]["message"]["content"]


def embed(text, input_type):
    return _post("/embeddings", {
        "model": EMBED_MODEL, "input": [text], "input_type": input_type
    })["data"][0]["embedding"]


def get_passage_embedding(text):
    return embed((text or "this is blank").replace("\n", " "), "passage")


def get_query_embedding(text):
    return embed((text or "this is blank").replace("\n", " "), "query")


def cosine_similarity(a, b):
    if not a or not b: return 0.0
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(x * x for x in b))
    if na == 0 or nb == 0: return 0.0
    return sum(x * y for x, y in zip(a, b)) / (na * nb)


NEG_KO = ["않", "안 ", "못 ", "없", "아니", "말고", "싫어하", "거부하", "반대하"]
NEG_EN = ["not ", "n't ", " no ", "never", "none", "cannot", "won't", "hate", "refuse"]


def negation_penalty(text_a, text_b):
    a = text_a.lower(); b = text_b.lower()
    a_neg = any(n in a for n in NEG_KO + NEG_EN)
    b_neg = any(n in b for n in NEG_KO + NEG_EN)
    if a_neg != b_neg: return 0.4
    if a_neg and b_neg: return 0.1
    return 0.0


def main():
    if not API_KEY:
        print("❌ NVIDIA_API_KEY 환경변수가 설정되지 않았습니다.")
        sys.exit(1)

    print("=== NIM self-test ===\n")

    print("[1] LLM 호출")
    try:
        r = chat([{"role": "user", "content": "ping 한 단어만"}])
        print(f"    응답: {r.strip()}")
    except Exception as e:
        print(f"    ❌ {e}")
        sys.exit(2)

    print("\n[2] 비대칭 임베딩 (passage vs query)")
    try:
        p = get_passage_embedding("이서연은 카페에서 커피를 마신다")
        q = get_query_embedding("이서연이 마신 음료는?")
        sim = cosine_similarity(p, q)
        print(f"    차원: {len(p)}")
        print(f"    '이서연 카페 커피' ↔ '이서연 음료' = {sim:.3f}")
    except Exception as e:
        print(f"    ❌ {e}")
        sys.exit(3)

    print("\n[3] 부정 가드 (NEGATION_PENALTY)")
    try:
        pn = get_passage_embedding("이서연은 카페에서 커피를 마시지 않았다")
        qn = get_query_embedding("이서연이 마신 음료는?")
        sim_neg = cosine_similarity(pn, qn)
        guarded = sim_neg - negation_penalty(
            "이서연은 카페에서 커피를 마시지 않았다",
            "이서연이 마신 음료는?"
        )
        print(f"    부정 케이스 (가드 전): {sim_neg:.3f}")
        print(f"    부정 케이스 (가드 후): {guarded:.3f}")
    except Exception as e:
        print(f"    ❌ {e}")
        sys.exit(4)

    print("\n✅ self-test 통과")


if __name__ == "__main__":
    main()
