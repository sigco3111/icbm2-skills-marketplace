# Savegame Serialization vs i18n — 왜 Delegate startEvent는 못 건드리는가

> TripleA 3차 (2026-07-28) 실측. **delegate 75개 startEvent는 i18n 치환 시 세이브 호환성 깨짐** — 단일 패치의 silent corruption보다 더 위험한 클래스.

## 문제 정의

TripleA의 delegate 패키지 (MoveDelegate, BattleDelegate, TechActivationDelegate 등)에 `bridge.getHistoryWriter().startEvent("X attacks with Y")` 호출이 **75개** 있음. 이 string literal은:

1. **HistoryNode의 title 필드**에 저장됨
2. HistoryNode는 **Java 직렬화**로 게임 세이브 파일에 들어감 (AGENTS.md 명시: "Save-game compatibility: Do NOT rename or delete private fields of classes extending GameDataComponent")
3. 즉 **"X attacks with Y"라는 영어 string이 바이너리 세이브 파일에 그대로 박힘**

## i18n 치환 시 무슨 일이 일어나나

```java
// AS-IS
bridge.getHistoryWriter().startEvent("X attacks with Y");

// TO-BE (i18n 적용)
bridge.getHistoryWriter().startEvent(
    I18nEngineFramework.get().getText("ingame.MoveDelegate.AttacksWith"));
```

- **런타임**: 새 게임에서는 한국어 "X가 Y로 공격"이 HistoryNode.title에 들어감. HistoryLog.setText()에 한국어 표시.
- **옛 세이브 로드**: 세이브 파일의 English "X attacks with Y"가 HistoryNode.title에 들어옴. **한국어 properties에 "X attacks with Y" 키 없으므로** HistoryLog setText에서 fallback 영어 표시.
- **silent corruption**: HistoryLog의 `title.equals("Initializing Delegates")`, `title.matches("\\w+ win")` 같은 string 매칭이 **한국어/영어 둘 다 깨짐**. `\\w+` regex가 한국어에서 다르게 매칭됨.

## 판별 명령

```bash
# delegate의 startEvent (HistoryNode 직렬화 대상) 카운트
grep -rh "startEvent.*\"" --include="*.java" game-app/game-core/src/main/java/games/strategy/triplea/delegate/ | wc -l

# HistoryNode.equals 매칭 (영어가 박힌 regex) — 깨질 부분
grep -rh "title.equals(\|title.matches(\|title.contains(" --include="*.java" game-app/game-core/src/main/java/games/strategy/triplea/ui/ | grep -v "Start/" | head -20
```

## 처리 가능/불가 영역

| 영역 | i18n 가능? | 이유 |
|---|---|---|
| **Swing 다이얼로그** (JOptionPane, JMenu, JLabel, JButton) | ✅ | 위젯 인스턴스 생성 시점에 getText() 호출, 직렬화 영향 없음 |
| **HistoryLog StringBuilder 출력** (Phase 2+ 다이얼로그 본문) | ✅ | HistoryNode.title은 **English로 들어오지만** HistoryLog가 StringBuilder로 새로 만듦. 디자인 노트 등 title.equals() 매칭 깨지지 않게 regex 패턴 추가 |
| **Delegate startEvent 75개** | ❌ | HistoryNode.title 직렬화 = 세이브 호환성 깨짐 |
| **HistoryNode.title.equals() 매칭** (HistoryLog의 `title.equals("Initializing Delegates")` 등) | ❌ | 영어 string 그대로 두거나 regex 한국어화 시 test 깨짐 |

## 회피 패턴

1. **delegate startEvent는 절대 i18n으로 치환하지 말 것** — 작업 효율이 0이고 회귀 위험만 증가
2. **HistoryNode.title을 받은 후** StringBuilder로 다시 가공하는 영역 (HistoryLog.printTurnString 등)만 i18n 처리
3. **title.equals() / title.matches() / title.contains() 매칭은 영어 그대로** — 한국어 properties에서 title에 매칭되는 값을 getText()로 가져와서 비교하면 lazy loading 이슈 가능
4. **Phase 2+ 확장 시 위 영역 분리**: 1) widget 다이얼로그 (안 ) 2) 로그/dialog 재생성 (안 ) 3) delegate startEvent (차단)

## 검증 명령 (silent corruption 감지)

```bash
# 옛 세이브 파일이 있는 경우
git checkout <세이브_파일이_있는_버전> -- <savegame_file>
./gradlew :game-headed:installDist --rerun-tasks
./build/install/game-headed/bin/game-headed
# → 옛 세이브 로드 후 HistoryLog 표시 확인
```

3차에서 검증 안 됨 (옛 세이브 파일 부재), 다만 **이론상 옛 세이브 호환성 깨짐은 확실** — Phase 2+ 작업 시 가장 먼저 확인해야 할 회귀.

## 관련 레퍼런스

- `java-swing-i18n-scaling.md` — Phase 2+ Swing i18n 확장 패턴
- `java-resourcebundle-locale-lookup-pitfall.md` — Phase 1 Locale.lookup 함정
- `oss-fork-localization` SKILL.md — umbrella + pre-flight 5축
