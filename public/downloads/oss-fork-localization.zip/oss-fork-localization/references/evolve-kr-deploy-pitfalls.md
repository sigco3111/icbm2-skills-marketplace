---
name: evolve-kr-deploy-pitfalls
description: "Evolve 한국어화 + Vercel 라이브 배포 실측에서 발견한 3가지 보완 워크플로 — 한국어 진행도 preflight grep (i18n 모듈 ≠ 실제 번역 데이터), Vercel 자동배포 = push만 (이미 연결된 프로젝트 한정 + 워커 서브쉘 VERCEL_TOKEN 전파 안 됨 함정), console 에러 ≠ 게임 결함 (content.js:4 = 브라우저 확장)."
---

# Evolve KR Vercel 라이브 배포 — 3가지 보완 워크플로

Evolve(pmotschmann/Evolve, MPL-2.0) 한국어화 + Vercel 라이브 배포를 11,670개 한국어 번역 + 자동 빌드 + 라이브 URL까지 완성하면서 발견한 3가지. 본 문서는 `oss-fork-localization` SKILL.md의 "i18n 디렉토리 8개 위치" + "5단계 빌드 분류" + "Open Core 비공개 본체 함정" 패턴을 보강합니다.

---

## 1) 한국어 진행도 preflight grep — `i18n 모듈 분리 + 0%` 보고에 속으면 안 됨

**문제의 본질**: 후보 평가에서 "i18n 모듈 분리형, 한국어 0%" → 🟢 최우선 추천. **하지만 `i18n` 등록 ≠ 실제 번역 파일 존재**.

Athena Crisis처럼 `i18n/AvailableLanguages.tsx`에 `ko_KR`만 등록되고 `strings.ko-KR.json`이 비어있는 경우 **번역 데이터는 처음부터 작업해야 함** (1,500+ 키). fbtee 기반 빌드라면 `source_strings.json`이 빌드 시점에 추출됨.

### 해결 — 30초 preflight

```bash
# i18n 디렉토리 8개 위치 + 한국어 파일 + 키 개수 일괄 측정
for path in resources/lang i18n strings lang locales src/data public/data data; do
  for ext in json ts js lua po; do
    find $path -name "*ko*.$ext" 2>/dev/null | head -3
  done
done

# fbtee 같은 빌드 도구 기반 (Athena Crisis/Evolve 모두)
cat source_strings.json 2>/dev/null | python3 -c "
import json, sys
try:
    d = json.load(sys.stdin)
    phrases = d.get('phrases', [])
    print(f'phrases: {len(phrases)} (한국어 번역 데이터 추출 가능)')
except: pass
"

# locale.js / i18n config에서 한국어 등록 확인
grep -n "ko[_-]KR\|한국어" src/locale.js i18n/AvailableLanguages.tsx 2>/dev/null
```

### 판별 매트릭스

| 한국어 진행도 | 한국어화 작업량 | 추천 |
|---|---|---|
| **90%+** (Evolve 사례) | 1~2시간 (누락 키만 채우기) | 🟢 최우선 |
| **50~80%** (OpenFrontIO) | 반나절 | 🟢 추천 |
| **0~30%** (Athena Crisis) | 2~5일 | 🟡 조건부 (Open Core 아닌지 확인 필수) |
| **`i18n` 등록만** (모듈은 있는데 ko_KR.json 비어있음) | 5~10일 | 🔴 시간 투자 큼, 다른 후보 우선 |

### Evolve 실측 (2026-07-27)

```bash
$ ls strings/strings.ko-KR.json
# → 803KB, 10,164 키 (87.3%)
$ cat source_strings.json | python3 -c "import json; print(len(json.load(open('source_strings.json'))['phrases']))"
# → 1,506개 미번역 키 추출 → LLM이 30분 내 채움
```

→ 1,506개 한국어 번역 → 11,670개 (100%) 도달, 그 후 2단계 작업이 `vars.js` `locale: 'en-US'` → `'ko-KR'` 한 줄로 한국어 기본 로케일 강제.

---

## 2) Vercel 자동배포 = GitHub push만 — **이미 연결된 프로젝트 한정**

**사용자 정정 시그널 (2026-07-27)**: "오늘 아침에도 배포했잖아. 이거 네가 배포한거야" — minimax-of-duty 프로젝트의 Vercel 자동배포를 워커가 직접 한 게 아니라 **Vercel이 push 감지해서 자동 빌드/배포**.

### 즉시 적용 규칙

| 시나리오 | Vercel 동작 | 워커 액션 |
|---|---|---|
| **이미 Vercel에 import된 프로젝트** (minimax-of-duty 같은) | push 감지 → 자동 빌드 → 자동 배포 | `git push`만 |
| **새 fork 저장소** (최초 1회) | 자동 트리거 없음 | `vercel --prod --yes` 1회 (또는 Vercel 웹 UI Import) |
| **2회차 push부터** | 자동 트리거 | `git push`만 |

→ 즉 **한 번 Import 후에는 Vercel 토큰 자체가 필요 없음**. 토큰은 `vercel CLI`로 새 프로젝트 첫 배포할 때만 사용.

### 워커 서브쉘 `VERCEL_TOKEN` 전파 안 됨 함정

**증상**:
- `~/.zshenv`에 `export VERCEL_TOKEN="vcp_***"` 박아도 **새 터미널/서브쉘에서 자동 source 안 됨**
- 워커 서브쉘에서 `vercel --prod --token "$VERCEL_TOKEN"` 호출 시 `Error: missing token value`로 실패
- `vercel whoami --token "$VERCEL_TOKEN"`도 동일 에러

**근본 원인**:
- `~/.zshenv`는 zsh 시작 시점에 로드되지만, **명시적 새 인스턴스(서브쉘, 스크립트)는 부모 환경변수 상속**
- 워커가 spawn하는 서브프로세스는 부모 셸 환경변수를 그대로 상속받음 → `~/.zshenv` 재로드 안 일어남

**해결 3가지**:

1. **워커 명령에 `source ~/.zshenv` 명시 호출** (가장 안전):
   ```bash
   source ~/.zshenv && vercel --prod --yes --token "$VERCEL_TOKEN" --name evolve-kr
   ```
2. **호출 명령에 토큰 직접 인라인** (sub-shell 격리 확실):
   ```bash
   vercel --prod --yes --token "vcp_1DdWJWcm7WLcTNl7dinjD40jAjEmUr1bV3j94mzC0HEPEBrSrp3sGHrN" --name evolve-kr
   ```
3. **이미 Vercel 연결된 프로젝트는 그냥 `git push`** (토큰 불필요) — 가장 권장

### 토큰 자체 함정

- `~/.zshenv`에 박을 때 `export` 키워드 + 따옴표 정확히: `export VERCEL_TOKEN="vcp_..."`
- 따옴표 누락/오타 시 셸 시작 시 syntax error로 전체 `~/.zshenv` 로드 실패
- **검증**: `bash -c 'source ~/.zshenv && echo ${#VERCEL_TOKEN}'` — 길이 0이면 등록 실패

### Vercel 프로젝트 처음 Import하는 정석 워크플로

```bash
# 1) Vercel CLI 인증 (인터랙티브)
vercel login

# 2) 프로젝트 디렉토리에서 첫 배포
cd /Users/mac/work/my-project
vercel --prod --yes --token "$VERCEL_TOKEN" --name my-project

# 3) 결과 URL 확인
vercel ls my-project
# → https://my-project.vercel.app + 자동 alias
```

이 한 번 끝나면 **이후 `git push origin main`만으로 Vercel이 자동 빌드/배포**.

---

## 3) Console 에러 ≠ 게임 결함 (NEW, 2026-07-27, evolve-kr 라이브 콘솔 함정)

### 증상

Evolve 라이브 (https://evolve-kr.vercel.app) 콘솔에:
```
Uncaught TypeError: r.closest is not a function
    at HTMLDocument.<r> (content.js:4:15460)
```

한국어가 안 나오는 원인으로 의심했음. **잘못된 진단**이었음.

### 진단 결과

- 우리 빌드(`evolve/main.js`)에 `closest` 호출 **0건** (curl + grep 검증)
- `content.js:4`는 우리 번들이 아니라 **브라우저 확장 프로그램의 content script**
- Playwright 깨끗한 헤드리스 세션에서는 **콘솔 에러 0건**
- Playwright `ko-KR` 강제 후 한글 52자 정상 렌더

### 판별 워크플로 (5분)

```bash
# 1) 우리 번들에 해당 함수 호출 있는지
curl -sS https://[라이브]/evolve/main.js | grep -o "closest" | wc -l
# → 0건이면 우리 문제 아님

# 2) Playwright 헤드리스 깨끗한 세션 (확장 없음)
playwright open --headless https://[라이브]
# → 콘솔 에러 0건이면 확장 프로그램 의심
```

### 한국어 미표시 우선순위 진단표 (Evolve 실측)

| 순위 | 진단 | 해결 | 시간 |
|---|---|---|---|
| 1 | 브라우저 캐시 | `Cmd+Shift+R` 강력 새로고침 | 10초 |
| 2 | 확장 프로그램 | 시크릿 창 (`Cmd+Shift+N`) | 30초 |
| 3 | Playwright 깨끗 세션 | 콘솔 깨끗 확인 | 1분 |
| 4 | localStorage 로케일 | `localStorage.setItem('evolve.locale', 'ko-KR')` + reload | 30초 |
| 5 | **소스 기본 로케일 변경** | `src/vars.js` `locale: 'en-US'` → `'ko-KR'` + redeploy | 5분 (최후) |

### Evolve 한국어 미표시 최종 해결

Evolve의 로케일 키는 `global.settings.locale`이고, `src/vars.js:1316`에서 항상 `'en-US'`로 초기화됩니다. `localStorage` 변경은 사용자 한 명만 영향. **모든 방문자에게 한국어 강제**하려면:

```js
// src/vars.js:1316
locale: 'en-US',  // →  locale: 'ko-KR',

// src/vars.js:1490-1491
if (!global.settings['locale']){
    global.settings['locale'] = 'en-US';  // →  'ko-KR'
}
```

→ `npm run build && vercel --prod` 한 번이면 **첫 방문자 전부 한국어로 시작**. 11,670개 한국어 번역이 이미 들어가 있으므로 즉시 정상 렌더.

### localStorage 키 이름 확인법 (Evolve 사례)

`src/vars.js` 끝부분에 `save.setItem('evolved', LZString.compressToUTF16(JSON.stringify(global)))` — Evolve는 **전체 global 객체를 `evolved` 키 하나에 압축 저장**. 따라서 `localStorage.setItem('evolve.locale', 'ko-KR')` 같은 단순 키는 안 통함.

**올바른 진단**:
```js
// 1) 저장된 키 목록 확인
Object.keys(localStorage).filter(k => k.includes('evolve') || k.includes('locale'))
// → ['evolved'] 하나만 나옴

// 2) 어떤 키에 locale 정보 있는지 코드 grep
grep -n "localStorage\|setItem" src/locale.js src/vars.js
// → vars.js:2269 'evolved' 키에 global 객체 통째로 압축 저장
```

다른 게임은 키 이름 다를 수 있음. **코드 grep으로 확인 후** localStorage 직접 수정 시도.

---

## 4) README + 라이브 URL 자동 박기 패턴

Evolve fork 마지막 단계에서 한 일:
- README `## 플레이` 섹션에서 `원본 (영어)` 링크 제거
- `🎮 한국어 라이브 데모: https://evolve-kr.vercel.app` 한 줄 강조
- `docs/screenshot-korean-game.png` 첨부 (게임 화면 캡처)
- `git add + commit + push` (Vercel 자동배포가 라이브 반영)

```bash
# 스크린샷 첨부 패턴
cp "/Users/mac/Downloads/screenshot.jpg" /Users/mac/work/evolve-kr/docs/screenshot-korean-game.png

# README 마크다운 삽입
## 플레이

🎮 **한국어 라이브 데모**: https://evolve-kr.vercel.app

![한국어 게임 스크린샷](docs/screenshot-korean-game.png)
```

---

## 5) Evolve 실측 정리 — 잘된 점 / 나쁜 점

### 잘된 점
- **한국어 87.3% → 100%**: 1,506개 LLM 번역 + `vars.js` 기본 로케일 변경
- **Vercel 자동배포**: 첫 Import 후 push만으로 라이브 반영
- **빌드 4개 한 번에**: `npm run build` = `evolve` + `evolve-less` + `wiki` + `wiki-less` 모두 0 exit

### 발견된 함정 (위 1~3에 정리)
- i18n 등록 ≠ 번역 데이터 존재
- Vercel 토큰 서브쉘 전파 안 됨
- 콘솔 에러 ≠ 게임 결함

### 시간 투자 회수
- 셋업 5분 (1단계)
- 한국어 번역 30~60분 (2단계 — LLM)
- 빌드 + Vercel 5분 (3단계)
- README + 스크린샷 5분 (4단계)
- **총 1~2시간** 라이브

Athena Crisis의 4시간 낭비와 비교하면 **1/4 시간**으로 라이브 게임 완성.
