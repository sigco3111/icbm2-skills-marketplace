# LÖVE/Lua 게임 Fork + 한국어화 (SNKRX 사례, 2026-07-21)

> [a327ex/SNKRX](https://github.com/a327ex/SNKRX) 한국어화 + 개선 작업에서
> 발견한 패턴. C++ (Wesnoth), TypeScript (sango)와는 **완전히 다른 함정 클래스**.
>
> 자세한 워크플로 + 코드 샘플은 `references/lua-lua-game-fork.md` 참조.

## 왜 LÖVE 게임이 별도 클래스인가

| 게임 종류 | 텍스트 위치 | 모드팩 패턴 | 빌드 |
|----------|-----------|-----------|------|
| JSON 기반 (sango) | `data/*.json` | `modpack/*.json` + `mergeById` | `npm run dev` 2초 |
| C++ (Wesnoth) | `data/po/*.po` | gettext + `fill_empty.py` | scons 90분+ |
| **Lua/LÖVE (SNKRX)** | **코드 안에 흩어짐** | **`T()` 함수 + `lang/*.lua`** | **`love .` 즉시** |

Lua 게임의 결정적 차이:
- 텍스트가 `button_text = 'arena run'`처럼 Lua 식 안에 박혀 있음 → JSON 게임의 `mergeById` 패턴 적용 불가
- LÖVE 11.x의 TTF는 CJK glyph 없으면 깨짐 → 자동 fallback 필수
- Steamworks SDK 연동 (`luasteam`)이 게임 코드에 깊이 통합됨 → brew로 깐 love는 죽음
- LÖVE 자체가 GUI 앱이라 헤드리스 환경에서 검증 불가 → `luac -p` offline check가 유일한 안전망

## 5단계 빌드 환경 분류에 추가

| 분류 | 빌드 도구 | 빌드 시간 | macOS 호환성 | 추가 사례 |
|------|----------|----------|--------------|----------|
| 🟢 **즉시 성공 (Lua/LÖVE)** | `love .` | 0초 (인터프리터) | ✅ brew cask + shim | SNKRX, Balatro, Celeste-classic |

**즉시 적용 규칙**: 사용자가 "Lua 게임 fork" 요청 시
1. Steamworks 의존성 확인 (`grep -r 'luasteam'`)
2. brew cask love 설치 + quarantine 제거 (1초)
3. luasteam shim 작성
4. lang/*.lua + Font CJK fallback 적용

## ⭐ Steamworks shim 패턴 (CRITICAL, SNKRX 사례)

**원본**:
```lua
-- engine/external/init.lua:7
steam = require 'luasteam'
```

**문제**: brew로 설치한 `love`에는 `luasteam.so` (Steamworks SDK 바인딩) 없음.
게임 시작 즉시 죽음:
```
Error: engine/external/init.lua:7: module 'luasteam' not found
```

**해결 (3단계)**:

**1단계 — shim 작성**: `engine/external/luasteam.lua` 생성
```lua
-- engine/external/luasteam.lua — Steam shim (Steam 클라이언트 없이 실행)
local M = {}

function M.init() return true end
function M.shutdown() end

M.userStats = {
  requestCurrentStats = function() return true end,
  setAchievement = function() end,
  storeStats = function() end,
  getStatInt = function() return 0 end,
  setStatInt = function() end,
}

M.friends = {
  setRichPresence = function() end,
  activateGameOverlay = function() end,
}

M.utils = {
  getAppID = function() return 915310 end,
}

return M
```

**2단계 — init.lua 패치**:
```lua
-- require 'luasteam' → require(path .. ".luasteam") (같은 디렉토리에서 찾기)
steam = require(path .. ".luasteam")
```

**3단계 — 호출 검증**: 게임 코드에서 사용하는 Steam 함수 모두 shim에 포함 확인
```bash
grep -rhE "steam\.(userStats|friends|utils|appshover|callback)" main.lua arena.lua buy_screen.lua
# → 결과로 사용된 모든 함수 목록. shim에 없으면 nil 호출 → 죽음.
```

**호출 빈도**: SNKRX는 `steam.userStats.setAchievement` 50+회, `steam.friends.setRichPresence` 6회. shim 누락 시 게임 시작 직후 죽음.

**즉시 적용 규칙**: Lua/LÖVE 게임 fork 시 **첫 번째 검증 단계**. shim 작성 전까지는 어떤 코드 수정도 무의미.

## ⭐ Apple Gatekeeper quarantine 제거

**증상**: brew로 설치한 love (또는 다른 비공인 dev tool) 실행 시 팝업:
> "love"(을)를 열지 못음
> Apple은 "love"에서 서명되지 않은 Mac용 소프트웨어를 식별할 수 없습니다.

**brew 경고**:
```
Warning: love has been deprecated because it does not pass the macOS Gatekeeper check!
It will be disabled on 2026-09-01.
```

**해결 (1초)**:
```bash
xattr -dr com.apple.quarantine "/Applications/love.app"
# 검증
xattr -l "/Applications/love.app" | head -3
# → com.apple.provenance 만 남으면 OK
```

**즉시 적용 규칙**: brew cask로 dev tool 설치 후 `xattr -dr com.apple.quarantine` 자동 실행. 사용자에게 "팝업 떴다" 보고 받으면 이 명령으로 즉시 해결.

## ⭐ T() 함수 + lang/*.lua 모드팩 패턴 (Lua 게임)

JSON 게임의 `modpack/*.json` + `mergeById` 패턴은 Lua 게임에 적용 불가.
**왜?** Lua 코드는 직접 require되므로 JSON을 외부에서 로드해도 코드에서 그 필드를 참조해야 하는데, 코드는 컴파일 시점에 박혀 있음.

**해결**: 텍스트 리터럴을 `T('key', 'default')` 래퍼로 교체.

**1단계 — T() 함수 추가** (`shared.lua` 또는 초기화 모듈):
```lua
lang = lang or {}
lang.current = 'ko'  -- 기본값
lang.dicts = {}
lang.dicts.en = {}   -- 폴백 (영어 원본은 모든 곳에 default로 박혀있음)
lang.dicts.ko = require('lang.ko')
lang.fallback = 'en'

function T(key, default)
  local dict = lang.dicts[lang.current] or {}
  local fb = lang.dicts[lang.fallback] or {}
  if dict[key] ~= nil then return dict[key] end
  if fb[key] ~= nil then return fb[key] end
  return default or key
end
```

**2단계 — lang/ko.lua 생성**:
```lua
return {
  arena_run = '아레나 런',
  options = '옵션',
  -- ... 200+ 키
}
```

**3단계 — 텍스트 교체**:
```lua
-- 전: button_text = 'arena run'
-- 후: button_text = T('arena_run', 'arena run')
```

**장점**:
- default가 영어 원본 → 누락 시 안전 폴백
- lang.current 한 줄 변경만으로 ko/en/ja/zh 전환
- 영어 원본 보존 (번역 누락 시 자연스럽게 영어로 표시)

**단점**:
- 코드 patches가 많아짐 (~200개 위치)
- 각 언어별로 모든 키 정의 필요

**다른 언어 추가**:
```bash
cp lang/ko.lua lang/ja.lua  # 번역 후
# shared.lua에 한 줄 추가:
lang.dicts.ja = require('lang.ja')
```

## ⭐ CJK 폰트 fallback 패턴 (Font:has_cjk + get_font_for_text)

**문제**: LÖVE 11.x TTF는 CJK glyph 없으면 깨짐 (□ 박스 렌더링).

**해결**: Font 객체에 두 가지 메서드 추가:

```lua
-- engine/graphics/font.lua

function Font:_ensure_ko_font()
  if self.ko_font then return self.ko_font end
  local ko_path = "assets/fonts/NotoSansKR-Regular.ttf"
  if love.filesystem.getInfo(ko_path) then
    self.ko_font = love.graphics.newFont(ko_path, self.size)
  else
    self.ko_font = self.font
  end
  return self.ko_font
end

function Font:has_cjk(text)
  if not text then return false end
  for i = 1, #text do
    local b = string.byte(text, i)
    if (b >= 0xE0 and b <= 0xEF) then return true end  -- UTF-8 multibyte 시작
  end
  return false
end

function Font:get_font_for_text(text)
  if self:has_cjk(text) then return self:_ensure_ko_font() end
  return self.font
end
```

**렌더링 시점 사용** (`engine/graphics/graphics.lua`):
```lua
function graphics.print(text, font, x, y, r, sx, sy, ox, oy, color)
  -- ...
  local active_font
  if font.get_font_for_text then
    active_font = font:get_font_for_text(text)
  else
    active_font = font.font
  end
  love.graphics.print(text, active_font, x, y, r or 0, sx or 1, sy or 1, ox or 0, oy or 0)
end
```

**폰트 파일 선택**:
- ✅ **Noto Sans KR Regular OTF** (~4.6MB, LÖVE에서 작동 확인)
- ❌ AppleSDGothicNeo.ttc (TTC는 LÖVE에서 직접 미지원)
- ✅ Noto Sans CJK KR Regular OTF
- ❌ PixulBrush / FatPixelFont (원본 픽셀 폰트, 한글 없음)

**Noto Sans KR 받기**:
```bash
curl -L -o assets/fonts/NotoSansKR-Regular.ttf \
  "https://github.com/notofonts/noto-cjk/raw/main/Sans/SubsetOTF/KR/NotoSansKR-Regular.otf"
```

**텍스트 폭 측정도 CJK 처리 필수** — `Font:get_text_width(text)`도 CJK 감지 → ko_font:getWidth() 사용. 안 하면 한글 텍스트 폭이 좁게 측정되어 UI 깨짐.

## ⭐ Luac -p offline syntax check (LÖVE GUI 검증 대체)

**문제**: LÖVE는 GUI 앱이라 헤드리스 환경에서 실행 시 SIGKILL. 
```
$ love .
Killed: 9
# 코드 에러인지 정상 종료인지 알 수 없음
```

**해결**: `luac -p` (Lua offline syntax checker)로 syntax 검증
```bash
brew install lua  # luac 포함

for f in shared.lua main.lua mainmenu.lua buy_screen.lua \
         arena.lua enemies.lua player.lua objects.lua media.lua \
         engine/graphics/font.lua engine/graphics/text.lua \
         engine/graphics/graphics.lua lang/ko.lua; do
  luac -p "$f" && echo "$f: OK"
done
```

**장점**: 모든 lua 파일 빠르게 검증. patch 후 즉시 확인 가능.

**luac 5.5 함정**: Lua 5.5의 luac는 5.1과 미묘한 차이가 있음. `font.font or font.font` 같은 표현이 함수 인자로 오해될 수 있음. 안전한 패턴:
```lua
-- ❌ 위험: luac 5.5에서 "function arguments expected near 'and'"
local active_font = font:get_font_for_text and font:get_font_for_text(text) or font.font

-- ✅ 안전: 명시적 if-else
local active_font
if font.get_font_for_text then
  active_font = font:get_font_for_text(text)
else
  active_font = font.font
end
```

## ⭐ 헤드리스 love 실행 검증 (실제 코드 로드 확인)

`luac -p`는 syntax만 검증. 런타임 에러 (nil 인덱싱, require 실패)는 별도 확인 필요.

**방법**: 백그라운드 exec + ps 확인
```bash
cd /Users/mac/work/snkrx-clone
exec /opt/homebrew/bin/love . > /tmp/love_run.log 2>&1
# → 백그라운드 프로세스 (session_id 받음)

# 5초 후
ps -p <PID> -o pid,stat,command
# STAT=Ss (sleeping) = 메인 루프 진입 성공

cat /tmp/love_run.log
# 비어있으면 정상 (에러 없음)
# stack traceback 있으면 require/호출 실패
```

**검증 신호**:
| 상황 | ps 상태 | stderr | 의미 |
|------|--------|--------|------|
| ✅ 정상 | Ss (sleeping) | 비어있음 | 메인 루프 진입, 코드 로드 성공 |
| ❌ require 실패 | 종료됨 | `module 'X' not found` | shim 누락 |
| ❌ syntax 에러 | 종료됨 | `line N: syntax error` | patch 실수 |
| ❌ nil 인덱싱 | 종료됨 | `attempt to index nil` | 함수 시그니처 불일치 |

## ⭐ patch tool fuzzy match 함정 (이번 세션 직접 겪음)

**사례**: buy_screen.lua의 `steam_button` / `guide_button`을 T() 래핑하려 했는데,
fuzzy match가 다른 위치의 `function ItemCard:on_mouse_enter()` 함수에 잘못 매칭.

**원인**: 두 코드 블록에 "button_text" 문자열 + 비슷한 들여쓰기 + `function ... end` 구조.

**결과**: ItemCard 함수 안에 중복 `function ItemCard:on_mouse_enter()` 삽입됨 → 
syntax 에러 1541 line near EOF.

**즉시 적용 규칙**:
1. **패치 전 파일 읽기** (read_file로 정확한 라인 확인)
2. **패치 후 `luac -p`로 syntax 검증** (반드시)
3. **큰 패치 시 `git diff`로 변경 확인** (특히 함수 시작/끝 라인)
4. **유사 패턴이 의심될 때**: `search_files`로 모든 occurrence 먼저 확인 후 
   가장 구체적인 unique context로 old_string 작성

## SNKRX 한국어화 작업 시간 (실측)

| 단계 | 시간 |
|------|------|
| 클론 + 구조 파악 | 5분 |
| MODIFIED.md + 라이선스 | 2분 |
| brew install --cask love | 2분 |
| quarantine 제거 (나중에) | 10초 |
| luasteam shim + init.lua 패치 | 5분 |
| lang/ko.lua (200+ 키) | 15분 |
| Font CJK fallback (font.lua/graphics.lua/text.lua) | 10분 |
| mainmenu.lua T() 래핑 | 5분 |
| buy_screen.lua T() 래핑 | 10분 |
| luac -p 전체 검증 | 1분 |
| love 백그라운드 실행 + ps 확인 | 1분 |
| **총합** | **~55분** |

## 한국어 번역 우선순위 (SNKRX 기준)

1. **메인 메뉴** (5 버튼) — 사용자가 가장 먼저 보는 화면
2. **상점 탭** (5 탭) — 게임플레이 핵심
3. **튜토리얼** (9 문장) — 신규 사용자 온보딩
4. **일시정지 / NG+** — 진행 중 자주 봄
5. **능력치 라벨** — 게임플레이 중 자주 봄
6. **영웅 이름** — 키 기반이므로 모듈화 필요
7. **적 이름** — 가장 빈도 낮음 (후순위)

## SNKRX vs sango-rising-dragons 비교

| 항목 | sango (TypeScript) | SNKRX (Lua/LÖVE) |
|------|-------------------|------------------|
| 빌드 도구 | npm 2초 | love 0초 |
| 텍스트 위치 | JSON | Lua 코드 |
| 모드팩 시스템 | manifest.json + packs 배열 | T() 함수 + lang/*.lua |
| 번역 누락 시 | 모드팩 미적용 → 영어 노출 | default 폴백 → 영어 노출 |
| CJK 폰트 | CSS font-family | Font:get_font_for_text() |
| 빌드 검증 | tsc --noEmit + Playwright | luac -p + 백그라운드 love |
| 한국어화 난이도 | 쉬움 (모듈화 잘 됨) | 중간 (코드 patches 많음) |

## Lua/LÖVE 게임 fork 체크리스트

- [ ] brew install --cask love
- [ ] xattr -dr com.apple.quarantine "/Applications/love.app"
- [ ] brew install lua (luac 용)
- [ ] git clone + 구조 파악 (`grep -r 'luasteam'`)
- [ ] MODIFIED.md 작성 (라이선스 표시)
- [ ] engine/external/luasteam.lua shim 작성
- [ ] engine/external/init.lua 패치 (require 'luasteam' → require(path .. ".luasteam"))
- [ ] lang/ko.lua 생성
- [ ] Font CJK fallback (font.lua/graphics.lua/text.lua 패치)
- [ ] Noto Sans KR Regular 임베드
- [ ] mainmenu.lua / buy_screen.lua 핵심 텍스트 T() 래핑
- [ ] luac -p 전체 검증 (syntax)
- [ ] 백그라운드 love 실행 + ps 확인 (런타임)
- [ ] 사용자 GUI 검증 요청 (스크린샷)

## ⭐ Window size config — sentinel 값 우선순위 함정 (SNKRX 실측)

게임 엔진 표준 패턴 (`engine/init.lua`):

```lua
local window_width, window_height = love.window.getDesktopDimensions(flags.display)
if config.window_width ~= 'max' then window_width = config.window_width end
if config.window_height ~= 'max' then window_height = config.window_height end
```

`'max'`는 sentinel (전체 화면), 그 외는 픽셀 숫자. 반응형 윈도우 크기 추가 시 `'half'` 같은 새 sentinel 만들면 순서 함정 발생.

### ❌ 1차 시도 (실패, "attempt to perform arithmetic on local 'window_width' (a string value)")

```lua
-- 1. 일반 sentinel 체크 먼저
if config.window_width ~= 'max' then window_width = config.window_width end  -- 'half' 문자열이 박힘
-- 2. 새 sentinel 처리
if config.window_width == 'half' then window_width = math.floor(window_width / 2) end  -- 'half' / 2 → arithmetic 에러
```

### ✅ 2차 시도 (정상)

```lua
-- 1. 새 sentinel 먼저 처리 (실제 숫자로 변환)
if config.window_width == 'half' then window_width = math.floor(window_width / 2) end
if config.window_height == 'half' then window_height = math.floor(window_height / 2) end
-- 2. 일반 sentinel 체크 (새 sentinel도 명시적으로 제외)
if config.window_width ~= 'max' and config.window_width ~= 'half' then window_width = config.window_width end
if config.window_height ~= 'max' and config.window_height ~= 'half' then window_height = config.window_height end
```

### 일반화된 규칙 (모든 sentinel config에 적용)

**sentinel 값을 추가할 때마다**:
1. **새 sentinel을 먼저 처리** (실제 값으로 변환하거나 적용)
2. **일반 "not sentinel" 체크는 모든 sentinel을 명시적으로 제외**
3. **순서 바꾸면 즉시 타입 에러** (예: `'half' / 2`, `nil.foo()` 등)

### 다른 엔진에 적용

| 엔진/프레임워크 | 비슷한 패턴 | sentinel 추가 시 주의 |
|----------------|------------|---------------------|
| LÖVE (Lua) | `engine/init.lua` window config | 위 예시 |
| Phaser (TS) | `scale.mode = 'FIT'` vs `'WIDTH_CONTROLS_HEIGHT'` | 새 mode 추가 시 첫 분기에서 처리 |
| Unity (C#) | `Screen.fullScreenMode` | enum 추가 시 default 먼저 |
| Godot (GDScript) | `OS.window_size` | ProjectSettings에서 override |

### 즉시 적용 규칙

1. **게임 엔진 config sentinel 추가 시** — 먼저 처리 후 일반 체크
2. **다중 sentinel (max/half/quarter 등)** — 모두 첫 블록에 나열
3. **숫자+문자열 혼합 config** — `tostring()` 변환 또는 if/else 분기로 타입 안전

## ⭐ CharacterIcon hover info 패턴 — 다중 텍스트 + 함수 테이블 우회 (NEW, 2026-07-21, snkrx-clone v0.1.2~v0.1.3)

LÖVE 게임에서 hover tooltip처럼 **5+개 텍스트 항목을 한꺼번에 표시**하는 UI가 흔함. SNKRX buy_screen.lua의 CharacterIcon이 정확히 이 패턴:
- 영웅 이름 (정적)
- 비용 라벨 (정적)
- 클래스 (정적)
- 설명 본문 (함수 결과)
- Lv.3 효과 이름 + 설명 (정적/함수 혼합)

**해결 전략 (5단계 분기)**:

```lua
function CharacterIcon:on_mouse_enter()
  -- 1. 영웅 이름: T('char_' .. self.character, ...) — 정적 키
  local char_name = T('char_' .. self.character, self.character)
  if lang.current == 'en' then
    char_name = self.character:capitalize()  -- ★ 영어일 때만 capitalize
  end

  -- 2. 동적 테이블 분기 (함수 테이블도 모듈화)
  local desc_func = (lang.current == 'ko' and lang.character_descriptions_ko and lang.character_descriptions_ko[self.character]) or character_descriptions[self.character]
  local effect_name = (lang.current == 'ko' and lang.character_effect_names_ko and lang.character_effect_names_ko[self.character]) or (self.level == 3 and character_effect_names[self.character] or character_effect_names_gray[self.character])
  local effect_desc_func = (lang.current == 'ko' and lang.character_effect_descriptions_ko and lang.character_effect_descriptions_ko[self.character]) or (self.level == 3 and character_effect_descriptions[self.character] or character_effect_descriptions_gray[self.character])

  -- 3. 5개 항목 activate
  self.info_text:activate({
    {text = char_name .. ' - ' .. T('cost_label', 'cost: ') .. self.parent.cost, ...},
    {text = T('class_label_hover', 'Classes: ') .. character_class_strings[self.character], ...},
    {text = desc_func(1), ...},
    {text = T('lv3_effect_label', 'Effect - ') .. effect_name, ...},
    {text = effect_desc_func(), ...},
  }, ...)
end
```

**함수 테이블 모듈화 (`lang/character_descriptions_ko.lua`)**:

```lua
-- 함수도 모듈로 분리 가능 — 57개 영웅 설명 함수
return {
  ['vagrant'] = function(lvl) return '[fg]투사체를 발사해 데미지' end,
  ['swordsman'] = function(lvl) return '[fg]광역 데미지' end,
  -- ...
}
```

**shared.lua에 로딩 추가**:

```lua
lang.character_descriptions_ko = require('lang.character_descriptions_ko')
```

**★ `string.lower/capitalize` 언어별 분기 (CRITICAL)**: 원본 코드가 `string.lower(character_names[char])`로 영웅 이름을 소문자 출력. **한국어는 lower가 무의미하지만, 무조건 적용해도 됨**. 단, 미래 다국어 안전을 위해 `lang.current == 'en'` 분기:

```lua
-- ❌ 무조건 lower (한글에 적용되어도 무해하지만 명확하지 않음)
char_name = string.lower(char_name)

-- ✅ 언어별 분기 (명확하고 미래 언어 추가 시 안전)
if lang.current == 'en' then
  char_name = string.lower(char_name)
end
```

**main.lua 정적 테이블 일괄 한글화 (Python 스크립트 패턴)**:

`character_class_strings`, `character_effect_names` 같은 정적 테이블은 손으로 한 줄씩 번역하지 말고 Python 스크립트로 일괄 치환. **색상 태그(`]`) 다음에 오는 클래스명만** 정확히 매칭:

```python
import re

class_translations = {
  'Warrior': '전사', 'Mage': '마법사', 'Nuker': '누커',
  'Ranger': '레인저', 'Rogue': '도적', 'Healer': '힐러',
  'Enchanter': '인챈터', 'Psyker': '사이커', 'Builder': '빌더',
  'Voider': '보이드', 'Curser': '커서', 'Swarmer': '스워머',
  'Forcer': '포서', 'Sorcerer': '소서러', 'Mercenary': '머서너리',
}

for en, ko in class_translations.items():
  # 색상 태그 (]) 다음에 오는 클래스명만 치환 — ']Mage' → ']마법사'
  content = re.sub(r'\]\s*' + en + r'\b', ']' + ko, content)
```

**장점**: 60+ 클래스명을 5초에 일괄 치환. 색상 태그는 보존. 색상 태그 없는 경우(예: `[blue]마법사, Enchanter`)는 미치환 → 다음 세션에서 수동 처리.

**즉시 적용 규칙**:
1. hover/info_text UI는 **항상 5단계 분기** (이름/라벨/클래스/설명/효과)
2. **함수 테이블**도 `lang/<name>_ko.lua`로 분리 가능
3. **정적 테이블**은 Python 스크립트로 일괄 치환 (color tag 보존)
4. `string.lower`/`capitalize`는 **반드시 `lang.current == 'en'` 분기**
5. 함수 테이블 모듈화 시 shared.lua에 명시적 require 추가 필수 (T() 함수와 별개)

## ⭐ Lua `:activate({})` 인자 안 `local` 선언 불가 — 가장 빈번한 footgun (2026-07-21, SNKRX v0.1.7~v0.1.11 4번 반복 실수)

**Lua에서 table을 함수 인자로 넘길 때, 그 안에는 statement가 아닌 expression만 가능** — 즉 `local var = ...` 같은 statement를 `{...}` 안에 쓸 수 없음. SNKRX 작업 중 4번 반복 만남. 같은 패턴을 여러 객체에 복제할 때 매번 실수하는 대표적 함정.

**실측 에러**:
```
luac: buy_screen.lua:1120: unexpected symbol near 'local'
```

**실수 패턴**:
```lua
self.info_text:activate({
  -- ❌ luac: "unexpected symbol near 'local'"
  local char_name = T('char_' .. self.character, self.character)
  if lang.current == 'en' then char_name = self.character:capitalize() end
  local desc_func = (lang.current == 'ko' and lang.character_descriptions_ko and lang.character_descriptions_ko[self.character]) or character_descriptions[self.character]
  {text = '[' .. character_color_strings[self.character] .. ']' .. char_name .. ' - ...'},
  ...
})
```

**올바른 패턴 — local을 `:activate({})` 호출 전으로 이동**:
```lua
-- ✅ CORRECT: local 선언은 함수 호출 밖에서
local char_name = T('char_' .. self.character, self.character)
if lang.current == 'en' then char_name = self.character:capitalize() end
local desc_func = (lang.current == 'ko' and lang.character_descriptions_ko and lang.character_descriptions_ko[self.character]) or character_descriptions[self.character]
self.info_text:activate({
  {text = '[' .. character_color_strings[self.character] .. ']' .. char_name .. ' - ...'},
  ...
})
```

**더 안전한 패턴 — table literal을 변수로 분리**:
```lua
-- BEST: 변수 미리 준비 + activate는 table literal만
local lines = {
  {text = '[' .. character_color_strings[self.character] .. ']' .. char_name .. '...'},
  {text = desc_func(1), ...},
  {text = effect_desc_func(), ...},
}
self.info_text:activate(lines, nil, nil, nil, nil, 16, 4, nil, 2)
```

**왜 이런 실수가 많이 나오는가**:
- Python의 `f"{var=}"` walrus operator, JS의 statement-expression 모호성 → `{local var = ...; ...}`가 자연스러워 보임
- Lua는 **명확히 구분**: function call argument = expression만
- **4개 객체 (TutorialCharacterPart, CharacterPart, TutorialClassIcon, ClassIcon)에서 같은 실수 반복** — 같은 패턴을 여러 곳 적용할 때 처음에 실수하면 4번 복제

**즉시 적용 규칙** (Lua 게임 fork 워크플로에 추가):
1. Lua에서 `:method({...})` 호출 시 `{...}` 안에 **절대 `local`/`function`/`if-then-else` 같은 statement 금지**
2. 패치 후 즉시 `luac -p` 검증 — statement-in-arg 에러는 즉시 발견됨
3. **여러 객체에 같은 패턴 적용 시**: 첫 번째만 직접 작성, 나머지는 `read_file`로 첫 번째 결과 확인 → 같은 실수 복제 방지
4. **복잡한 변수가 5개 이상일 때**: `lines` table 미리 만들어서 activate에 통째로 전달
5. SNKRX 같은 게임에서 `info_text:activate` 24개 위치 — 5개 정도 패치 후엔 자동 패턴으로 충분

## ⭐ Lua 모듈 간 `local` 함수 의존성 함정 (2026-07-21, SNKRX v0.1.8 + v0.1.10 두 번 만남)

**다국어 모듈 (lang/*_ko.lua)을 require로 로드할 때, main.lua 내부의 `local` 함수에 접근 불가**. SNKRX에서 `ylb1/2/3` (v0.1.8) + `ts` (v0.1.10) 두 번 만남. 다국어 fork 워크플로의 보편적 함정.

**실측 에러**:
```
Error: lang/class_descriptions_ko.lua:3: attempt to call global 'ylb1' (a nil value)
        lang/class_descriptions_ko.lua:3: in function 'class_desc_func_c'
        buy_screen.lua:2041: in function 'on_mouse_enter'
```

**원인**:
- `main.lua` 내부에서 `local ylb1 = function(lvl) ... end`로 helper 정의
- 원본 `class_descriptions`는 `ylb1(lvl)` 호출 — main.lua 내부에서 호출되므로 OK
- fork 모듈 `class_descriptions_ko.lua`도 `ylb1(lvl)` 호출 — 그러나 **모듈 시점에 `_G.ylb1`가 정의 안 됨** (main.lua의 local이라 global 환경 노출 안 됨)

**판별 매트릭스**:
| 패턴 | 글로벌? | 모듈에서 사용 가능? |
|------|--------|---------------------|
| `function helper() ... end` | ✅ (글로벌) | ✅ |
| `local helper = function() ... end` (모듈 밖) | ❌ (모듈 스코프) | ❌ |
| `function module.helper() ... end` | ❌ (모듈 스코프) | ❌ |
| `_G.helper = local_var` | ✅ | ✅ |

**해결 패턴 A — ko.lua에 helper 자체를 복제** (가장 간단, 원본 비수정):
```lua
-- lang/class_descriptions_ko.lua
local ylb1 = function(lvl)
  if lvl == 3 then return 'light_bg'
  elseif lvl == 2 then return 'light_bg'
  elseif lvl == 1 then return 'yellow'
  else return 'light_bg' end
end
-- ... (ylb2, ylb3 동일)
return {
  ['ranger'] = function(lvl) return '[' .. ylb1(lvl) .. ']3[light_bg]/...' end,
  ...
}
```

**해결 패턴 B — `_G` 명시 노출** (원본 코드 수정 가능한 경우):
```lua
-- main.lua init() 안
local ylb1 = function(lvl) ... end
_G.ylb1 = ylb1  -- ← 명시적 global 노출
```

**진단 워크플로**:
1. `attempt to call global 'X' (a nil value)` 에러 발생
2. 에러 위치는 ko.lua, 호출 스택은 hover/callback에서
3. 같은 함수가 원본에서는 잘 동작
4. → `grep -n 'local X = function' main.lua`로 X 정의 위치 확인

**즉시 적용 규칙** (다국어 모듈 분리 시):
1. **게임 코드 grep으로 `local \\w+ = function` 패턴 추출** → ko 모듈에서 호출 가능한지 확인
2. **호출 불가 시 2가지 해결**: (A) ko.lua에 helper 복제, (B) main.lua에 `_G.X = ...` 추가
3. **verify**: 게임 부팅 → hover/콜백 → 에러 없으면 통과
4. **글로벌 vs 로컬 패턴**: `grep -n "^local \\w\\+\\s*=\\s*function\\|local \\w\\+$\" main.lua`

**다른 언어와 대조**:
- **Python**: 모듈 스코프 함수는 `from module import func`로 접근 가능. private/public 구분 없음.
- **JavaScript**: `const helper = ...`도 모듈 스코프 → export 안 하면 외부 접근 불가. ES module 사용 시 자동 private.
- **Lua만** 함수 export 명시 없이 local로 정의해도 호출 시도 가능 (단, nil로 실패).

## ⭐ v0.1.12 매핑 한계 — 자동 80% (수동 보완 100%, 2026-07-21, SNKRX)

**Python 사전 매핑으로 84개 패시브 자동 번역했지만, 100% 달성은 못함**. 잔여 단어 매핑 필요.

**결과**:
- 84개 중 약 **80%** 자연스러운 한글 문장
- 20%는 영어 + 한글 혼용 (예: "to 모든 유닛" 같은 어색한 결과)
- 100% 달성이 목표면 **수동 보완** 필요 (2~3시간)

**왜 100% 못하나**:
- `ts()` / 동적 함수 호출은 **건드릴 수 없음** (레벨별 값 10/20/30%)
- 단어 매칭의 한계: `'movement speed'`와 `'movement'`가 둘 다 있을 때 긴 패턴 우선 매칭 필요
- 게임만의 slang/약어: 'AoE', 'aspd', 'crit' 등 → 매핑 누락 시 영어 그대로

**수동 보완 워크플로**:
1. 게임 부팅 → 패시브 카드 hover → 어색한 부분 메모
2. 사전에 누락 매핑 추가 → `lang/passive_descriptions_level_ko.lua` 재생성
3. **재배포 시 ko.lua만 갱신** — buy_screen.lua는 그대로

**LLM 대안**:
- Claude API로 84개 항목을 한 번에 번역 → 더 자연스러운 결과
- 단, 비용 발생 + API 키 필요 + 결정적이지 않음 (재생성 시마다 다른 결과 가능)

**즉시 적용 규칙** (대량 데이터 자동 번역 시):
1. Python 사전 매핑으로 **80% 자동** + 20% 수동 보완 (가장 효율적)
2. `ts()` / 동적 함수는 **그대로 보존** (게임 로직)
3. 사전에 누락된 slang는 **점진적 확장** (매 배포마다 5~10개씩)
4. 100% 달성이 목표면 LLM API 사용 고려 (단, 결정성 손해)
5. **솔직한 보고**: 자동 번역의 한계 (80%)를 PR/CHANGELOG에 명시

## ⭐ GitHub `private-user-images` 404 + 공개 `user-images` 대안 (NEW, 2026-07-21)

**문제**: 사용자가 README 영상 첨부용으로 `https://private-user-images.githubusercontent.com/...mp4?jwt=...` 링크를 제공했는데, **404 Not Found**. JWT 토큰 만료.

**진단**:
```bash
$ curl -sI "https://private-user-images.githubusercontent.com/409773/...?jwt=..."
HTTP/2 404
retry-after: 0
```

**원인**:
- `private-user-images.githubusercontent.com`는 사용자 인증 토큰(JWT)이 필요한 비공개 링크
- `?jwt=...` 파라미터가 만료되면 접근 불가
- 재인증 메커니즘 없음

**해결 — 공개 `user-images` URL 사용**:
- 원본 a327ex/SNKRX README에 있는 공개 URL 사용
- `https://user-images.githubusercontent.com/409773/119258159-ea982b00-bb9e-11eb-8082-37e2c65591ea.mp4`
- JWT 파라미터 없음, 누구나 접근 가능, GitHub 자동 임베드

**검증 워크플로**:
```bash
# 영상 URL 받으면 즉시 검증
curl -sI "$URL" | head -3
# HTTP/2 200 = OK
# HTTP/2 404 = 만료, 대안 필요
# HTTP/2 302 (redirect) = 인증 필요
```

**대안 영상 소스 (우선순위)**:
1. 원본 OSS의 README/문서에 있는 공개 영상 (가장 안전)
2. YouTube (Gameplay 영상 등)
3. Steam 스토어 페이지 스크린샷
4. `figma.com` / `gfycat.com` 등 영상 호스팅

**즉시 적용 규칙** (README 작성 시 영상 첨부):
1. **사용자가 제공한 영상 URL은 항상 curl 검증** → 404면 대안 요청
2. **`private-user-images` / `private-user-files` 링크는 사용자에게 요청** — 영구 링크 아님
3. **`user-images.githubusercontent.com` 공개 URL 사용** (원본 OSS README에 흔함)
4. README에 출처 명시 (예: "(원본 a327ex/SNKRX README에서 동일한 영상 사용)")