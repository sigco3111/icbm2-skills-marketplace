# NIM API 키 불량 → 500 에러 즉시 진단

`HTTP Error 500: Internal Server Error`가 LLM/embedding 호출에서 동시에 나올 때, **키가 불량일 가능성 90%**. NIM API 키는 `nvapi-XXX...` 형식이지만, 환경변수에 다른 형식의 키나 만료된 키가 export 되어 있으면 NIM이 "Missing request extension" 에러로 500을 반환.

## 증상 (실측)

`gpt_structure.py self-test` 결과:
```
[1] ChatGPT_single_request('ping 한 단어만')
    ❌ HTTP Error 500: Internal Server Error

[2] 비대칭 임베딩 (passage vs query)
    ❌ HTTP Error 500: Internal Server Error
```

LLM과 embedding 모두 동시에 500 → **키 문제** (모델 문제는 한쪽만 깨짐).

**NIM 에러 메시지 (curl로 직접 보면):**
```json
Missing request extension: Extension of type `headers::common::authorization::Autho...er>` was not found. Perhaps you forgot to add it? See `axum::Extension`.
HTTP_CODE: 500
```

→ "Authorization 헤더가 인식 안 됨" = **API 키 자체가 NIM에서 거부당함**.

## 즉시 진단 (curl)

```bash
source ~/.hermes/secrets/nvidia_keys.env
echo "=== 현재 zsh env의 NVIDIA_API_KEY로 chat 호출 ==="
curl -s -w "\nHTTP_CODE: %{http_code}\n" -X POST "https://integrate.api.nvidia.com/v1/chat/completions" \
  -H "Authorization: Bearer $NVIDIA_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"model": "openai/gpt-oss-120b", "messages": [{"role":"user","content":"ping"}], "max_tokens": 50}' 2>&1 | tail -10
```

**판정**:
- `HTTP_CODE: 200` → 정상. 다른 곳의 문제.
- `HTTP_CODE: 500` + "Missing request extension" → **키 불량**
- `HTTP_CODE: 401` / `403` → 키 형식 오류 또는 권한 없음
- `HTTP_CODE: 404` → 모델 ID 오타 (예: `gpt-oss-120b` 단독 vs `openai/gpt-oss-120b` prefix)

여러 키 보유 시 `NVIDIA_API_KEY_1`도 시도:
```bash
curl -s -w "\nHTTP_CODE: %{http_code}\n" -X POST "https://integrate.api.nvidia.com/v1/chat/completions" \
  -H "Authorization: Bearer $NVIDIA_API_KEY_1" \
  -H "Content-Type: application/json" \
  -d '{"model": "openai/gpt-oss-120b", "messages": [{"role":"user","content":"ping"}], "max_tokens": 50}' 2>&1 | head -3
```

## 해결

### 1. 명시적으로 올바른 키 export

```bash
source ~/.hermes/secrets/nvidia_keys.env
export NVIDIA_API_KEY="$NVIDIA_API_KEY_1"  # ← 명시적
unset NVIDIA_API_KEY  # ← 다른 잘못된 키 지우기 (안전 차원)
export NVIDIA_API_KEY="$NVIDIA_API_KEY_1"
```

### 2. 새 키 발급 (모든 기존 키가 불량 시)

https://build.nvidia.com → 로그인 → API Keys → Generate Personal Key
- 키 형식: `nvapi-XXX...` (보통 60자+)
- 90일 무료 (만료되면 재생성)

### 3. ~/.zshrc에 잘못된 키 export 확인

```bash
grep -n "NVIDIA_API_KEY" ~/.zshrc
# 잘못된 키가 export되어 있으면 그 줄 삭제 후 source ~/.zshrc
```

새 shell을 열 때마다 `~/.zshrc`가 자동 실행되어 잘못된 키가 매번 export되는 함정.

## 진단 흐름도

```
gpt_structure.py self-test 500
    ↓
zsh 환경에서 `echo $NVIDIA_API_KEY` 출력 확인
    ↓
[키 형식 nvapi-XXX 맞음] → 2번 단계 (export 확인)
[다른 형식 / 빈 값]      → 1번 단계 (올바른 키 export)
    ↓
올바른 키 export 후에도 500
    ↓
curl로 NIM 직접 호출 → HTTP_CODE 확인
    ↓
[200] → 코드 문제 (reasoning 모델 처리 등 다른 곳)
[500] → 키 자체가 NIM 거부 → build.nvidia.com에서 새 키
[401/403] → 키 만료 또는 권한 회수
[404] → 모델 ID prefix 확인 (openai/, nvidia/, meta/ 등)
```

## 헷갈림 방지

### NIM 키 한 줄 점검

```bash
source ~/.hermes/secrets/nvidia_keys.env
[ -n "$NVIDIA_API_KEY" ] && echo "KEY1 set: ${NVIDIA_API_KEY:0:10}..." || echo "KEY1 missing"
[ -n "$NVIDIA_API_KEY_1" ] && echo "1: ${NVIDIA_API_KEY_1:0:10}..." || echo "1 missing"
[ -n "$NVIDIA_API_KEY_2" ] && echo "2: ${NVIDIA_API_KEY_2:0:10}..." || echo "2 missing"
```

### nvidia_keys.env 표준 구조 (sigco3111 컨벤션)

```bash
# ~/.hermes/secrets/nvidia_keys.env
export NVIDIA_API_KEY_1="nvapi-XXX..."
export NVIDIA_API_KEY_2="nvapi-YYY..."
# (선택) NIM 키가 둘 이상일 때
export NVIDIA_API_KEY="$NVIDIA_API_KEY_1"  # default
```

`source ~/.hermes/secrets/nvidia_keys.env` 후 명시적으로 `export NVIDIA_API_KEY="$NVIDIA_API_KEY_1"` 하면 어떤 shell에서든 동일.

## 실측 사례 (2026-07-14)

| 시점 | zsh env | curl 결과 | 해결 |
|------|---------|----------|------|
| 첫 시뮬 | `$NVIDIA_API_KEY=***` (옛 키) | HTTP 500 "Missing request extension" | `NVIDIA_API_KEY_1` 명시적 export |
| fix 후 | `NVIDIA_API_KEY="$NVIDIA_API_KEY_1"` | HTTP 200 + "Pong! 🚀" | self-test 통과 |

## Quick reference

```bash
# 가장 빠른 진단
source ~/.hermes/secrets/nvidia_keys.env
export NVIDIA_API_KEY="$NVIDIA_API_KEY_1"
curl -s -w "HTTP %{http_code}\n" -X POST "https://integrate.api.nvidia.com/v1/chat/completions" \
  -H "Authorization: Bearer $NVIDIA_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"model":"openai/gpt-oss-120b","messages":[{"role":"user","content":"ping"}],"max_tokens":5}' -o /dev/null

# 200 → 코드 문제로 디버깅
# 500 → 키 불량
# 401/403 → 만료/권한
# 404 → 모델 ID prefix 확인
```
