# 🚨 Cross-Fork GitHub PR 제출 5대 함정 (2026-07-28)

> pmotschmann/Evolve 한국어 PR 사례에서 4회 연속 실패 → "compare across forks" UI 패턴으로 우회.
> `oss-fork-localization`의 PR 단계에 추가 필수.

## 언제 이 함정에 빠지나

다음 모두 충족:
- `gh repo fork <upstream>` 로 본인 fork에 push 완료
- 본인 fork에 새 브랜치 푸시 (`pr/ko-kr-translation` 등)
- 본인 fork는 `upstream`보다 1+ commit ahead
- `gh pr create --repo <upstream> --head <self>:<branch> --base <branch>` 시도

## 🚨 5대 함정 (시간순)

### 함정 1: gh CLI cross-fork GraphQL 버그
**증상**:
```
pull request create failed: GraphQL: Head sha can't be blank, Base sha can't be blank,
Head repository can't be blank, No commits between <upstream>:master and <self>:<branch>,
Head ref must be a branch, not all refs are readable (createPullRequest)
```

**원인**:
- gh CLI의 GraphQL API가 cross-fork PR 헤드 SHA를 못 가져옴
- 또는 GitHub의 "0 commits between" 캐시가 stale (브랜치 방금 푸시했을 때)
- API로 직접 branch 확인하면 정상 존재 (1 commit ahead 맞음)

**해결**:
1. gh CLI로 안 되면 **GitHub UI에서 직접**
2. URL: `https://github.com/<upstream>/<repo>/compare/<base>...<self>:<branch>?expand=1`
3. `gh pr create --web` 으로 PR 작성 페이지를 브라우저로 열 수도 있지만 일관성 없음

### 함정 2: 브랜치 push 후 즉시 PR 시 "0 commits"
**증상**: 푸시 직후 (5-10초) PR 생성 시 "0 commits between" 에러
**원인**: GitHub의 비교 엔진이 push 이벤트를 아직 인덱싱 안 함
**해결**:
- `gh api repos/<self>/<repo>/branches/<branch>` 로 200 OK 확인 후 PR
- 또는 `git push origin --delete <branch>` + `git push -u origin <branch>` 로 강제 refresh
- 또는 30초 정도 대기 후 재시도

### 함정 3: "compare across forks" 단계 누락 (UI)
**증상**: `https://github.com/<upstream>/compare/<base>...<self>:<branch>` 접속해도
- base/compare 드롭다운에 본인 fork 브랜치가 안 보임
- "There isn't anything to compare" 표시
- "Create pull request" 버튼 비활성

**원인**: GitHub compare UI는 기본적으로 **같은 repo의 브랜치**만 보여줌. 타인 fork의 브랜치는 자동 안 뜸.

**해결 (정확한 절차)**:
1. **https://github.com/<upstream>/<repo>/compare** 접속
2. "**compare across forks**" 텍스트 링크 클릭 (페이지 상단 노란 박스 안에 있음)
3. **head ref** 드롭다운: 본인 fork (`<self>/<repo>`) → 브랜치 선택
4. base는 자동으로 upstream의 master/main
5. "Create pull request" 활성화

**또는 URL 직접**:
```
https://github.com/<upstream>/<repo>/compare/<base>...<self>:<branch>?expand=1
```
이 URL은 위 단계를 한 번에 거쳐서 compare 페이지로 이동. **이게 가장 빠름**.

### 함정 4: base/head 순서 뒤바뀜
**증상**: `<base>...<head>` 순서를 `head...base`로 적으면 GitHub이 "There's nothing to compare"
**규칙**: `<a>...<b>` = "a에서 b로" (즉 a가 base, b가 head/compare)

### 함정 5: fork default branch와 upstream default branch 다름
**증상**: `gh repo view` 로 확인했는데 default branch가 다름
- e.g. `pmotschmann/Evolve` default = `master`
- `sigco3111/evolve-kr` default = `main`
- PR base = `master`, head = `main:branch` 처럼 혼재

**해결**:
- PR base는 **반드시 upstream의 default branch** (`<upstream>:<default>`)
- head는 본인 fork의 PR 브랜치 (`<self>:<branch>`)
- 두 fork의 default branch가 달라도 PR은 가능, base만 맞추면 됨

## 검증 절차 (PR 보낸 후)

```bash
# 1) PR 존재 확인
gh pr list --repo <upstream> --head <self>:<branch>
# 2) PR 본문/제목
gh pr view --repo <upstream> <PR_NUMBER>
# 3) diff 통계
gh pr diff --repo <upstream> <PR_NUMBER> --stat
# 4) merge 가능 여부
gh pr view --repo <upstream> <PR_NUMBER> --json mergeable,state,additions,deletions,changedFiles
```

## 결정 트리

```
PR 보낼 때
├─ gh CLI 성공? → 끝
├─ gh CLI "0 commits between" 5분 내
│  ├─ URL 직접 시도? (함정 3)
│  ├─ 그래도 안 됨? → branch 삭제 + 재push (함정 2)
│  └─ 그래도 안 됨? → gh API로 직접 만들기 (rare)
└─ gh CLI 처음부터 실패 (GraphQL blank) → UI만 가능 (함정 1)
```

## 메타 교훈

- **gh CLI는 cross-fork PR에서 신뢰할 수 없음**. 항상 UI fallback 계획
- **GitHub compare UI는 단계가 2개**: same-repo → across-forks. 기본 화면엔 across-forks 진입점이 안 보임
- **URL 직접** (`?expand=1`) 가 가장 빠름 — `compare across forks` 클릭 단계 생략
- **branch 이름은 의미있게**: `pr/<description>` 또는 `i18n/<lang>` 처럼 PR 의도가 보이게

## Evolve PR 실제 성공 절차 (참고)

```bash
# 1) 깨끗한 브랜치 (upstream/master 기반)
git checkout -b i18n/korean-polish upstream/master
git checkout main -- strings/strings.ko-KR.json  # 변경 파일만
git commit -m "feat(i18n): complete Korean (ko-KR) translation"
git push -u origin i18n/korean-polish

# 2) gh CLI는 4회 실패 (GraphQL cache + cross-fork bug)
# → UI에서 직접:
# https://github.com/pmotschmann/Evolve/compare/master...sigco3111:i18n/korean-polish?expand=1
# → "Create pull request" 클릭 → 제목/본문 입력
```
