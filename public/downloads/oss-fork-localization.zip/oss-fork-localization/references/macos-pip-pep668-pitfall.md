---
title: macOS pip PEP 668 환경별 설치 가이드
description: macOS Sonoma+에서 `pip install -r requirements.txt` 실패 시 우회 패턴 (Hermes venv 활용 + flexible 버전)
when_to_load: macOS 사용자가 "pip: command not found" 또는 "externally-managed-environment" 에러를 만났을 때, requirements.txt의 Pillow/gensim 버전이 Python 3.11에서 빌드 실패할 때
related_pitfall: 13 (SKILL.md 본문)
---

# macOS Sonoma+ pip 환경 함정

## 문제 정의

신 macOS (Sonoma 14+, Sequoia 15+)의 시스템 Python(`/usr/bin/python3`)은 **PEP 668** 보호가 걸려 있어 `pip install`이 차단됩니다. 동시에 `requirements.txt`는 일반적으로 작성 시점 기준 (2022-2023년, Python 3.7-3.9) 버전이 박혀있어 Python 3.11에서 빌드 실패 추가 발생.

## 4가지 증상 + 진단

### 증상 1: `command not found: pip`
```bash
$ pip install -r requirements.txt
zsh: command not found: pip
```
- **원인**: 시스템 Python에 pip 미설치 (macOS 기본 정책)
- **진단**: `which python3 pip` → 둘 중 하나만 있거나 둘 다 없음

### 증상 2: `externally-managed-environment`
```bash
$ python3 -m pip install -r requirements.txt
error: externally-managed-environment
```
- **원인**: PEP 668 보호 (Homebrew Python과 시스템 Python 모두)
- **진단**: `python3 -c "import sys; print(sys.executable)"` → `/usr/bin/python3` 또는 `/opt/homebrew/bin/python3`

### 증상 3: Pillow 빌드 실패
```bash
ERROR: Failed building wheel for Pillow
Failed building Pillow
```
- **원인**: Pillow 8.4.0이 libjpeg/libtiff native 의존성을 요구하지만 시스템에 없음
- **해결책**: `Pillow>=10` 또는 Hermes venv의 `Pillow==12.2.0` 재사용

### 증상 4: gensim ImportError
```bash
ModuleNotFoundError: No module named 'gensim'
```
- **원인**: gensim 3.8.0은 Python 3.11 미지원 (4.x 필요)
- **해결책**: `gensim>=4.3`

### 증상 5: zsh 따옴표 함정 (`>`, `<`, `!` 모두 redirection/reserved)

```bash
$ pip install Pillow>=10.0
zsh: 10.0 not found
```

- **원인**: zsh가 `>=` 의 `>` 를 **출력 리다이렉션**으로 해석. 그 뒤의 `10.0`을 명령어로 실행하려다 실패.
- **증상**: bash에서 같은 명령은 작동하지만 zsh만 깨짐. macOS 기본 셸 = zsh (Catalina 이후).
- **해결책**: **반드시 따옴표로 감싸기**
  ```bash
  # ❌ zsh 깨짐
  pip install Pillow>=10.0
  pip install Django>=4.2,<5 gensim>=4.3

  # ✅ zsh 안전 (bash도 동일하게 작동)
  pip install "Pillow>=10.0"
  pip install "Django>=4.2,<5" "gensim>=4.3"
  ```
- **영향 범위**: zsh의 redirection 문자 (`>`, `<`, `>>`), history expansion (`!`), brace/glob (`{a,b}`). pip install에서 version specifier 쓸 때 **항상 따옴표 권장**.
- **README 작성 시 규칙**: macOS 기본 셸 = zsh. README의 모든 `pip install <pkg>>=X.Y` 명령은 따옴표 포함해야 안전.

**빠른 확인** (현재 셸이 무엇인지):
```bash
echo $SHELL
# /bin/zsh → zsh  (따옴표 필수)
# /bin/bash → bash (따옴표 없어도 작동하지만 통일성 위해 사용)
```

**왜 이 함정이 자주 발생하는가**: README는 보통 영문 위주로 작성되므로 작성자가 bash 환경이면 명령이 잘 작동하지만, macOS 사용자가 그대로 복붙하면 zsh에서 깨짐. README 작성 단계에서 미리 따옴표 포함하면 사용자 액션 절약.

## 해결책 — 3가지 선택지

### 선택 A: Hermes venv 활용 (가장 빠름) ⭐

```bash
# 1. Hermes venv 활성화 (PIL 12.x 이미 설치됨)
source ~/.hermes/hermes-agent/venv/bin/activate

# 2. 핵심 패키지를 flexible 버전으로 설치 (원본 strict 버전 우회)
pip install --quiet 'Django>=4.2,<5' \
              'numpy>=1.26,<2' 'pandas>=2.0' \
              'scikit-learn>=1.4' 'scipy>=1.11' \
              'gensim>=4.3' 'nltk>=3.8' 'openai>=1.0' \
              'statsmodels>=0.14' 'seaborn>=0.13' 'matplotlib>=3.8'

# 3. self-test
cd reverie/backend_server/persona/prompt_template
python3 gpt_structure.py
```

**장점**: Pillow 빌드 우회, 의존성 0개, 즉시 시작.

### 선택 B: 새 .venv 만들기

```bash
cd /Users/mac/work/generative-agents-kr
python3 -m venv .venv
source .venv/bin/activate

# .venv의 pip는 새로 깔린 거라 PEP 668 우회됨
pip install -r requirements.txt
# Pillow는 여전히 빌드 실패할 수 있음 → flexible 버전으로 교체
```

**장점**: 프로젝트별 격리. **단점**: Pillow 빌드 실패 별도 처리 필요.

### 선택 C: 시스템 Python 우회 (비권장)
```bash
python3 -m pip install --user --break-system-packages -r requirements.txt
```
- 시스템 전체에 설치되며 추후 충돌 가능
- **macOS 사용자에게 권장하지 않음**

## README 보강 패턴

사용자가 README의 `pip install -r requirements.txt` 라인에서 멈춘다면, README §설치 섹션을 다음 패턴으로 갱신:

```markdown
## 설치

\`\`\`bash
# 1. 클론
git clone https://github.com/{user}/{repo}-kr.git
cd {repo}-kr

# 2. venv 생성 (PEP 668 회피 — macOS Sonoma+ 권장)
python3 -m venv .venv
source .venv/bin/activate

# 3. 의존성 설치
pip install -r requirements.txt

# 4. ...
\`\`\`

> ⚠️ **macOS Sonoma+ / 시스템 Python 사용자**: `pip install` 시
> "command not found: pip" 또는 "externally-managed-environment" 에러가 날 수 있습니다.
> 위 예시처럼 `.venv`를 만들고 활성화해서 사용하세요.
>
> 이미 다른 venv를 쓰고 있다면 그것을 활성화해도 됩니다.
> (예: Hermes 환경이 있다면 `source ~/.hermes/hermes-agent/venv/bin/activate`)
```

## 검증

```bash
# 1. venv 격리 확인
which python3 pip
# → .venv/bin/python3, .venv/bin/pip (또는 Hermes venv 경로)

# 2. 핵심 임포트 검증
python3 -c "import django, numpy, pandas, gensim; print('all OK')"

# 3. LLM/임베딩 작동 확인 (OSS가 NIM/gpt-oss-120b 사용 시)
python3 gpt_structure.py
# → "ping" 응답 + 2048d 임베딩 + 부정 가드 출력
```

## 검증된 사례

`generative_agents-kr` (Stanford fork → NIM, 2026-07-14):
- 시스템 Python 3.9.6 (Sonoma)
- Hermes venv 3.11.15 활용
- `pip install --quiet 'Django>=4.2,<5' ...` 한 줄로 13개 패키지 설치 (90초)
- `gpt_structure.py` self-test 통과 (ping + 0.474 + 0.057)

## 관련 도구

- `oss-python-bootstrap` — 새 OSS 프로젝트 부트스트랩 시 처음부터 venv 고려
- `device-environment-migration` — PC 교체 시 venv 재생성 패턴
- `mac-bootstrap` — Apple Silicon Mac 부트스트랩 시 venv 자동 생성
