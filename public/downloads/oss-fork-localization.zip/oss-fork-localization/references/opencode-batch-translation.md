# OpenCode CLI Batch-Translation Delegation (2026-07-27, evolve-kr)

Captured during evolve-kr v1.4.10 한국어 번역 87.3% → 100% session. 1,506
미번역 키를 6개 그룹으로 분할해 `opencode run` 병렬 위임. **2/6 완료**
(eden 153, portal 192), 나머지 4개 그룹은 default Sisyphus 에이전트가
planning 단계에서 도구 호출 한도를 소진해 미완. 이 문서는 다음 워커가
같은 함정을 안 밟도록 한다.

---

## 1. `--` 구분자는 필수 — prompt는 무조건 `--` 뒤로

```bash
# ❌ 잘못된 호출 — opencode가 prompt 전체를 파일 경로로 해석
opencode run --pure --auto -m gpt-5.4-mini --file source.json \
  "translate all 443 values into Korean..."

# 결과: Error: File not found: translate all 443 values into Korean...

# ✅ 올바른 호출 — `--`가 prompt를 message args로 라우팅
opencode run --pure --auto -m gpt-5.4-mini --file source.json -- \
  "translate all 443 values into Korean..."
```

`opencode run`은 argv를 위치 인자로 파싱한다. `--file` 플래그 뒤에
`--` 없이 오는 모든 위치 인자는 프로젝트/파일 경로로 해석된다. 한국어
긴 prompt도 그냥 파일 경로 시도 → 실패. **반드시 `--`로 분리.**

## 2. `/tmp/*` 소스는 `external_directory` 자동 거부됨

OpenCode의 기본 permission allowlist:
- 작업 디렉토리 내부 경로
- `/Users/mac/.local/share/opencode/tool-output/*`
- `/var/folders/8s/.../T/opencode/*`

평범한 `/tmp/*`는 목록에 없으므로 모델이 다음을 받는다:

```
!  permission requested: external_directory (/tmp/*); auto-rejecting
✗  Read /tmp/evolve-wiki-source.json failed
```

**해결:** 소스를 작업 디렉토리에 `.hermes-evolve-*-source.json` 형태로
복사. 점 prefix는 두 가지 역할:
1. `.gitignore` 가능 (작업 산물)
2. "transient working artifact"임을 명시

```bash
cp /tmp/evolve-core-source.json .hermes-evolve-core-source.json
```

## 3. `--agent "Sisyphus - ultraworker"` → default agent로 silent fallback

```bash
$ opencode run --pure --auto --agent "Sisyphus - ultraworker" \
    -m gpt-5.4-mini --file src.json -- "..."
!  agent "Sisyphus - ultraworker" not found. \
  Falling back to default agent
> build · gpt-5.4-mini
```

이름이 정확히 일치하지 않으면 (공백·하이픈 차이) 조용히 default로
fallback. default는 Sisyphus personality로, 다음을 자동 수행:
- `<intent_verbalization>` preamble 출력
- `<Behavior_Instructions>` todo list 작성
- `Read package.json`, `Read strings/strings.ko-KR.json` 등 "코드베이스
  평가" 수행
- `<Phase 0 - Intent Gate>` → "implement explicitly requested" 확인

결과: **단일-shot 파일 쓰기 대신 planning + 파일 읽기 + 승인 요청**으로
들어가서 시간 한도 초과. 또는 markdown으로 감싼 출력을 만들고 끝.

**해결:** `--agent` 인자 완전 제거. `-m modelname --format default`만
지정하면 bare `build` 에이전트가 실행 (personality 오버헤드 0, 승인
게이트 0, 파일 즉시 작성).

```bash
# ✅ 검증된 패턴
opencode run --pure --auto -m github-copilot/gpt-5.4-mini \
  --file .hermes-evolve-eden-source.json -- \
  "translate all 153 values into Korean..."
```

## 4. `--pure --auto` 조합의 의미

| 플래그 | 효과 |
|--------|------|
| `--pure` | 외부 플러그인 비활성화 (oh-my-openagent 등 무시) |
| `--auto` | 명시적으로 거부되지 않은 권한 자동 승인 |

둘 다 지정해도 default Sisyphus personality의 행동 강령은 그대로
적용됨. `--auto`는 "permission gating"만 우회할 뿐 "intent gating"은
우회 못 함. **personality 우회하려면 `--agent` 제거가 핵심.**

## 5. ZSH `.cargo/env` stderr는 환경 노이즈 — 무시

모든 `opencode run` 호출이 stderr 첫 줄로 다음을 출력:

```
/Users/mac/.zshenv:.:1: no such file or directory: /Users/mac/.cargo/env
```

사용자 `.zshenv`가 uninstall된 Rust toolchain을 source 시도 → 무해.
opencode와 무관. 명령은 정상 실행됨. **로그에서 무시.**

## 6. 청크 크기 (≈1,500 키를 6개로)

| 그룹 | 키 수 | 비고 |
|------|-------|------|
| core | 443 | 가장 큼, 가장 느림 |
| wiki | 347 | 긴 문장 다수 |
| portal | 192 | 악마/분위기 텍스트 |
| eden | 153 | Eden 메커니즘 |
| race_trait | 199 | 종족명 + 설명 |
| wish_achieve | 172 | 짧은 제목 + 긴 설명 |

각 호출은 **정확히 한 chunk의 JSON 한 파일**만 `--file`로 첨부.
프롬프트에 "정확히 N개 키를 번역하고 json.load로 검증 후 끝낼 것"
명시.

## 7. "완료" 보고 전 반드시 검증

모델이 파일을 안 쓰고 "완료"라고 보고하는 경우 빈번. 검증:

```bash
ls -la .hermes-evolve-{group}-ko.json
python3 - <<PY
import json
src = json.load(open('.hermes-evolve-{group}-source.json'))
dst = json.load(open('.hermes-evolve-{group}-ko.json'))
assert len(src) == len(dst), f'key count {len(src)} != {len(dst)}'
assert list(src.keys()) == list(dst.keys()), 'key order mismatch'
hangul = sum(1 for v in dst.values() if any('가' <= c <= '힣' for c in v))
print(f'{len(dst)} keys, {hangul} have Hangul')
PY
```

파일이 비었거나 미생성 시 retry. retry prompt에 "다른 파일 읽지 말 것,
계획/설명 금지, 단일 patch/write로 JSON 전체를 한 번에 쓸 것" 명시.

## 8. 위임 전 upstream PR 확인

evolve-kr처럼 활발한 fork는 본업 upstream에 한국어 PR이 열려있을 수
있다. work 중복 제거 + 기존 번역 일관성 확보:

```bash
gh pr list -R upstream/repo --search 'Korean OR korea OR ko-KR' \
  --state all --limit 50 --json number,title,state,headRefName,url \
  --jq '.[] | [.number,.state,.title,.url] | @tsv'

gh pr view <number> -R upstream/repo \
  --jq '.files[]|select(.path=="strings/strings.ko-KR.json")|.raw_url'

# 본문 직접 fetch
curl -fsSL "<raw_url>" -o /tmp/pr<N>-ko.json
```

evolve-kr 실측 (2026-07-27):
- PR #1549 (youknowone, open, 2026-01-26) — 149개 변경
- PR #1522 (closed, 2026-01-03) — 120개 신규 추가 (Hangul 3개 포함)

이걸 먼저 머지한 뒤 누락분만 자동 번역하면 작업량 1/10 수준.

## 9. 머지 후 한국어 JSON sanity 체크

`strings.ko-KR.json` 머지 직후 다음을 확인:

```bash
python3 - <<'PY'
import json, re
en = json.load(open('strings/strings.json'))
ko = json.load(open('strings/strings.ko-KR.json'))
print(f'en={len(en)} ko={len(ko)} '
      f'missing={len(set(en)-set(ko))} '
      f'extra={len(set(ko)-set(en))}')

# 토큰 보존 검사
bad = []
for k in en:
    if k in ko:
        et = sorted(re.findall(r'%\d+', en[k]))
        kt = sorted(re.findall(r'%\d+', ko[k]))
        if et != kt:
            bad.append((k, et, kt))
print(f'token mismatches: {len(bad)}')

# 한자 잔존 검사 (새 번역분 한자 금지)
han = re.compile(r'[\u4e00-\u9fff\uf900-\ufaff]')
han_hits = [(k,v) for k,v in ko.items() if han.search(v)]
print(f'hanja-bearing entries: {len(han_hits)}')
PY
```

`strings/checkStrings.py`는 `tokens_regex` (`%\d+(?!\d)`),
`leading space`, `periods`, `numbers` 4종 자동 검사 — `python3
strings/checkStrings.py ko-KR`로 사전 점검.

## 10. background 호출의 "exited"는 종료를 보장하지 않음

`opencode run ... &`로 background 실행 후 `process(action='wait')`
60s 안에 `status=exited`로 보고될 수 있으나, **실제 작업은 진행 중**
인 경우가 많다. wait 로그에 `> build · <model>` + 빈 body만 보이는 게
특징. 검증은 `ls .hermes-evolve-*-ko.json`으로 직접.

---

## 요약 체크리스트 (다음 워커용)

- [ ] 소스를 `.hermes-evolve-*-source.json`로 작업 디렉토리에 복사
- [ ] `opencode run --pure --auto -m model --file ... -- "..."` 형태로 호출
- [ ] `--agent` 인자 **사용 금지** (Sisyphus personality 발동 회피)
- [ ] 각 호출에 정확한 키 개수 명시 + json.load 검증 요구
- [ ] background wait 후 `ls`로 실제 파일 존재 확인
- [ ] 머지 전 `checkStrings.py ko-KR`로 토큰/공백/구두점 검사