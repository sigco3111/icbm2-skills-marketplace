# 🌐 Three.js + WebGL2 + Vite 풀 프로시저럴 브라우저 FPS fork (minimax-of-duty 사례, 2026-07-27)

> [mshumer/Claude-of-Duty](https://github.com/mshumer/Claude-of-Duty)의 한국어 fork / 개선 작업.
> Three.js r180 + WebGL2 + Vite + 11개 서브시스템 + ~55k LOC + 풀 프로시저럴 (텍스처/메시/사운드를 코드로 생성).
> **MIT 라이선스** (Copyright 2026 mshumer).
>
> 이 레퍼런스는 **다른 브라우저 FPS / Three.js 풀 프로시저럴 게임 fork**에도 재사용 가능.

## 왜 별도 서브클래스인가

| 게임 종류 | 진입점 | 데이터 외부화 | 빌드 | 분포 |
|----------|--------|-------------|------|------|
| sango (Phaser TS) | Vite + Phaser | `public/data/ko/` 모드팩 | `npm run dev` | `dist/` + `play.sh` |
| SNKRX (Lua/LÖVE) | `love .` | `T()` + `lang/*.lua` | love 즉시 | `.love` + `.app` + `.zip` + `.tar.gz` |
| **Claude-of-Duty (3.js)** | **`index.html` + ES modules** | **없음 (하드코딩)** | **`npm run dev`** | **`dist/` HTML 빌드** |

**Claude-of-Duty만의 결정적 차이**:
- **풀 프로시저럴**: 런타임 의존성 `three` 단 하나 (텍스처/메시/사운드 다 코드)
- **11개 서브시스템**: render / materials / sky / world / physics / player / weapons / fx / ai / ui / audio — 각자 소유권 경계
- **멀티에이전트 산물**: ARCHITECTURE.md가 소유권 계약. **영문 보존 필수** (번역하면 계약 깨짐)
- **모드팩 시스템 부재**: 텍스트가 영어로 하드코딩. 한국어화하려면 T() + lang/*.lua 패턴 **신규 도입** 필요 (후속 작업)
- **bare `index.html` + ES modules**: Vite dev 서버가 즉시 ESM 변환
- **MIT 라이선스**: LICENSE + README attribution 두 가지만 신경

## ⭐ 5단계 빌드 환경 분류에 추가

| 분류 | 빌드 도구 | 빌드 시간 | macOS 호환성 | 추가 사례 |
|------|----------|----------|--------------|----------|
| 🟢 **즉시 성공 (3.js+Vite 풀 프로시저럴)** | `npm run dev` | 1초 | ✅ 네이티브 | **Claude-of-Duty** (Three.js r180 + WebGL2) |

**즉시 적용 규칙** (브라우저 FPS/게임 fork 요청):
1. `package.json` dependencies 확인 → `{three: ...}` 하나뿐 = 풀 프로시저럴 가능
2. ARCHITECTURE.md 존재 = 멀티에이전트 산물 (서브시스템 소유권 명시). **번역 금지**
3. 모드팩/i18n/locale 시스템 grep — 없으면 후속 작업으로 분류
4. `index.html` + `src/main.js` 패턴이면 Vite esbuild로 즉시 boot

## ⭐ MIT 라이선스 처리 (가장 가벼움)

기존 스킬에는 Apache 2.0 / GPL 등 비교는 있지만 **MIT 처리 절차**가 없었음. 이 세션에서 정리:

| 의무 | Apache 2.0 | **MIT (mthis)** | BSD-3 |
|------|-----------|----------------|-------|
| LICENSE 파일 | ✅ 보존 | **✅ 보존** | ✅ 보존 |
| NOTICE 파일 | ✅ 필수 | **❌ 없음** | ❌ 없음 |
| MODIFIED.md | ✅ 의무 | ⚪ **권장** | ⚪ 권장 |
| README attribution | ✅ 강력 권장 | ✅ **권장** | ✅ 권장 |

**작업 순서 (MIT fork 표준)**:

```bash
# 1. 클론
git clone https://github.com/UPSTREAM/REPO.git /Users/mac/work/FORK_NAME
cd /Users/mac/work/FORK_NAME

# 2. origin 정리 (gh가 충돌하지 않게)
git remote remove origin

# 3. gh로 새 fork 레포 생성
gh repo create sigco3111/FORK_NAME --public \
  --description "한국어 fork — {원본 설명 한국어 번역}" \
  --source=. --remote=origin --push 2>&1 | tail -5

# 4. origin 검증 (CRITICAL)
git remote -v
# sigco3111/FORK_NAME.git 이 표시되어야 함
# mshumer/... 이면 → git remote remove origin && git remote add origin https://...

# 5. (필요 시) 강제 push
git push -u origin main

# 6. LICENSE는 원본 그대로 보존 (MIT = 21줄, 짧음)
# → vim X, 그냥 둠
```

**MODIFIED.md는 만들지 않음** — README.md 하단에 attribution 섹션으로 흡수.

## ⭐ README.md 2단 구조 (원본 자가평가 보존 패턴)

원본 README가 솔직한 자기평가(예: "5.05/10, CoD에 한참 못 미치는 AMATEUR")를 포함하면:

```markdown
# {Fork Name}

> **{원본 저장소 링크}의 한국어 fork.**
> {게임 설명 1줄}
> **{원본 작성자 이름}의 [원본](url)으로, 다중 LLM 에이전트가 {N}일 만에 만든 {LOC}/11 서브시스템 작품.**

**[원본 저장소](url)** · **[라이선스: MIT](./LICENSE)** (Copyright {year} {author})

---

## 한국어 안내

{폴더 구조 한국어 번역 표}
{실행 방법 한국어}
{툴/하네스 한국어 번역 표}
{성능 지표 (숫자는 그대로)}

## 정직한 자가평가 (원본 그대로)

> ⚠️ 이 섹션은 원본 저자의 자기평가다. 번역하지 않고 원문 그대로 보존한다. 평가가 더 궁금하면 [원본 README](url)에서 직접 읽을 수 있다.

(원문 그대로 인용 — 자가평가 + viewmodel light overbright 등 알려진 unfixed root cause)

## 프로세스 기록 (원본)

(원문 그대로 인용)

---

## 원본 출처 / Attribution

- **원본 저장소:** [owner/repo](url)
- **원본 작성자:** Name ([@handle](url))
- **원본 라이선스:** [MIT](./LICENSE) — Copyright (c) {year} {author}
- **원본 사이트:** [site/newsletter url](url)

MIT 라이선스에 따라 원본의 저작권/허가 표시를 보존한다. 이 fork에서 추가되는 코드도 동일한 MIT 라이선스를 따른다.
```

**왜 자가평가 섹션을 원문 그대로 두나**:

| 이유 | 설명 |
|------|------|
| **투명성** | 한국어 사용자가 "번역하면서 숫자를 조작했나?" 의심할 가능성 차단 |
| **원작자 목소리** | 평가가 안 좋을수록 ("5.05/10", "AMATEUR") 원본 작성자의 솔직함이 fork의 strongest selling point |
| **검증 가능** | 원본 README 링크로 사용자가 직접 비교 가능 |
| **법적 부담 없음** | MIT는 attribution만 요구, 원문 vs 번역 선택 자유 |

**즉시 적용 규칙** (모든 OSS fork-한글화 README):
1. 폴더 구조·실행법·툴 설명 = **한글 번역**
2. 정량 지표 (숫자·단위) = **그대로**
3. 정성 평가 (자가평가·디자인 철학) = **원문 보존** + 짧은 한국어 헤더
4. ARCHITECTURE.md / LICENSE / 코드 = **절대 번역 X**
5. attribution 섹션 = README 하단에 의무 배치

## ⭐ ARCHITECTURE.md는 영문 보존 (번역 금지)

원본의 `ARCHITECTURE.md`가 **에이전트 계약서**일 가능성 높음. Claude-of-Duty의 경우:

```
Subsystem interface, directory ownership, the cross-subsystem event vocabulary,
and shared surface types.
```

이런 계약 문서를 번역하면:
- 디렉터리 소유권 표 (`render → src/render/` 등)가 한글/영문 혼재 → grep 어려움
- 이벤트 vocabulary (`bullet:impact`, `damage:dealt`)가 영어로 박혀 있어야 코드와 1:1 매칭
- Hard rules 섹션 ("Never edit files outside it")이 코드 주석과 일치해야 함

**즉시 적용 규칙** (모든 멀티에이전트 산물 fork):
1. **ARCHITECTURE.md / DESIGN.md / CONTRIBUTING.md**: 영문 보존
2. 코드 주석과 일치하는 표 (`Subsystem | Owns | ...`)는 **번역 X**
3. README.md만 한글로 (사용자 대상)
4. Quick start / Tutorial만 한글로 추가

## ⭐ 첫 커밋 템플릿 (Attribution 보존 commit)

```bash
git add README.md
git commit -m "docs: 한국어 README + 원본 출처 / Attribution

{Owner}/{Repo}의 MIT 포크다. 원본의 자기평가·성능 지표·프로세스
기록은 그대로 살리되, 첫 화면을 한국어 사용자가 읽을 수 있게 했다.

- 상단: 한국어 안내 (폴더 구조, 실행법, 성능/자가평가)
- 하단: 원본 저장소 링크 + 작성자 + 라이선스 (MIT, Copyright {year} {author})
- 원본 ARCHITECTURE.md / LICENSE / 코드는 영문 보존"
```

**commit 메시지가 attribution 역할**을 동시에 함:
- `docs:` prefix로 의도 명시
- "원본 출처 / Attribution"이 commit subject에 박힘 → `git log`로 추적 가능
- 본문에 "한글화 범위 vs 영문 보존 범위" 명시 → 다음 워커가 무엇이 바뀌었는지 즉시 파악

## ⭐ 풀 프로시저럴 게임의 한국어화 후속 작업 (CRITICAL 후속 단계)

**minimax-of-duty 사례가 아직 끝나지 않았음**. 다음 단계로 분류:

| 단계 | 작업 | 우선순위 |
|------|------|----------|
| **1 (완료)** | 클론 + 라이선스 + README 한글로 | ✅ |
| **2 (완료)** | 첫 commit + GitHub push | ✅ |
| **3 (예정)** | **모드팩/T() 패턴 도입** — 언어 분리 | 🟠 |
| **4 (예정)** | ARCHITECTURE.md 확인 — `src/core/`가 소유주인지 점검 | 🟡 |
| **5 (예정)** | viewmodel light rig fix (원본 README가 "unfixed root cause"로 박은 것) | 🟢 |
| **6 (예정)** | 성능 / 시각 품질 개선 | 🟢 |

**3단계 — 모드팩 패턴 도입은 이 게임에 없는 시스템이라 신규 설계 필요**:

```js
// src/core/i18n.js (신규 모듈)
const dicts = { en: {}, ko: {} };
export const lang = { current: 'ko' };

export function T(key, fallback) {
  return dicts[lang.current][key] ?? dicts.en[key] ?? fallback ?? key;
}

// src/core/i18n_ko.js (신규)
export default {
  weapon_rifle: '라이플',
  // ... 점진 확장
};
```

**시작 위치**: `src/ui/style.js` (DOM/CSS HUD)가 텍스트 박스가 가장 많아 첫 진입점으로 좋음.

**주의**:
- `src/ui/`는 다른 서브시스템의 이벤트를 listening — `damage:dealt` 같은 payload key는 절대 번역 X
- `src/core/`는 lead-owned — shared 추가 모듈 (`src/core/i18n.js`) 승인 필요
- `src/weapons/`, `src/ai/`의 영문 알림/대사는 게임 디자인 의도 → 후순위

**5단계 — viewmodel light rig fix (README가 박은 unfixed root cause)**:

원본 (가상, ARCHITECTURE.md에 명시):
```js
// src/render/index.js — viewmodel light intensity
viewLight.intensity = worldLight.intensity * 20;  // ← 부당하게 20×
```

수정 후보:
```js
// world light와 같은 광량, F0=0.04가 아닌 진짜 머티리얼 응답
viewLight.intensity = worldLight.intensity * 1.0;
```

검증:
- `tools/imagediff.mjs` (픽셀 게이트) — 시각 변화 확인
- `tools/baseline.mjs` (재현 가능한 캡처) — 비트 동일성
- 게임플레이 직접 — 무기 albedo가 더 이상 무의미하게 어두워지지 않음

## ⭐ `npm run dev` 즉시 부팅 + 워크플로 가드

이 프로젝트의 부팅은:
```bash
cd /Users/mac/work/minimax-of-duty
npm install       # ← 1~2분 (three + esbuild + playwright + pngjs + vite)
npm run dev       # ← http://127.0.0.1:5173 즉시
```

**즉시 적용 규칙** (브라우저 게임 fork 후 첫 실행):
1. **반드시 `npm install` 먼저** (vite, esbuild 등 dev 의존성)
2. `npm run dev` 후 `curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:5173` → 200 확인
3. 캔버스 클릭 → cursor lock → `tools/playtest.mjs` (자동 스크립트)
4. `npm run build` → `dist/` 단일 SPA 결과물 (LÖVE의 4개 플랫폼 빌드와 다름)

## minimax-of-duty 작업 시간 (실측, 2026-07-27)

| 단계 | 시간 |
|------|------|
| README/ARCHITECTURE.md 읽기 + LICENSE 확인 | 2분 |
| 디렉토리 클론 + 정리 | 1분 |
| README.md 한글 작성 | 15분 (자가평가 보존 결정 + 다중 LLM attribution 포함) |
| git init + 첫 commit | 1분 |
| gh repo create + push + 원격 검증 | 2분 |
| **합계** | **~20분** |

**다음 세션 시간 추정 (예정 작업)**:
| 단계 | 시간 |
|------|------|
| src/core/i18n.js + lang/en.js/lang/ko.js 모듈 분리 | 30분 |
| src/weapons/parts.js `geometry.js`의 영어 하드코딩 → T()로 | 1시간 |
| src/ui/style.js 한국어 폰트 fallback | 30분 |
| viewmodel light rig fix (PIXEL-EXACT 게이트 포함) | 30분 |
| **합계** | **~2.5시간** |

## 다른 브라우저 FPS fork 체크리스트

- [ ] LICENSE 종류 확인 (MIT / Apache 2.0 / GPL 등) — 의무 다름
- [ ] MIT면 LICENSE + README attribution 2가지만 신경
- [ ] Apache 2.0 / GPL이면 `references/apache-2-0-modified-md-template.md` 참고
- [ ] ARCHITECTURE.md / DESIGN.md 영문 보존 (에이전트 계약서 가능성)
- [ ] README.md 2단 구조 (한글 안내 + 원본 자가평가 보존)
- [ ] `git remote remove origin` 후 `gh repo create` (origin 충돌 방지)
- [ ] push 직후 `git remote -v` 검증
- [ ] 첫 commit 메시지에 attribution 박기
- [ ] 모드팩/i18n 시스템 grep → 없으면 후속 설계
- [ ] viewmodel/world light 비율 (Three.js 프로젝트의 흔한 함정)

## 학습 기록

- **2026-07-27 (minimax-of-duty)**: 풀 프로시저럴 Three.js 게임 fork의 첫 단계 (라이선스 + README)가 20분이면 완료. MIT 라이선스의 간결함이 Apache 2.0 대비 큰 장점.
- **2026-07-27**: README 자가평가 섹션 원문 보존 패턴 — fork의 strongest selling point가 "원작자가 자기 작품을 어떻게 평가하는가"일 때.
- **2026-07-27**: `gh repo create --remote=origin` + upstream-cloned 프로젝트 = origin 함정 (sango 함정과 별개). 클론 직후 `git remote remove origin` 1줄이 예방.
- **2026-07-27**: ARCHITECTURE.md는 멀티에이전트 산물에서 소유권 계약 — 번역하면 grep·이벤트 vocabulary 매칭 깨짐. 절대 번역 금지.
- **2026-07-27 (B1 hands 진단 시도 후 추가)**: `tools/capture.mjs --shot=weapon`은 viewmodel closeup을 못 찍음. `src/dev/shots.js`의 `__APPLY_SHOT__`가 `engine.camera`(world cam)만 옮기고 `engine.viewCamera`는 건드리지 않음. viewmodel은 항상 viewCamera에 매달려 있어 화면 모서리에 작게 보일 뿐, 핸드 그립 자세/봉합선/그라인 진단에 0% 도움. **자동 캡처로 viewmodel 진단하려는 모든 시도가 시간 낭비** — viewOnly 분기 패치(1~2시간) 또는 라이브 데모 직접 플레이가 필요. 진단 자동화 첫 시도 시 이를 의심.
