# 게임 fork 후보 조사 워크플로 (Game Fork Candidate Survey Workflow)

> **2026-07-27 검증 사례**: 사용자가 "한국어화 또는 기능 개선 가치가 높은 GitHub 게임 후보를 조사해 추천" 요청. 5개 후보를 비교 분석한 실측 워크플로.
> **목표**: 후보 1개 선정 → 첫 PR 머지까지 **30분 이내** 끝낼 수 있는 데이터 모음.

이 워크플로는 **이미 만들어진 OSS 게임을 fork해서 한국어화/개선할 후보를 선정하는 단계** 전용이다. fork/빌드/번역 자체의 워크플로는 다른 references를 참조:
- LÖVE/Lua 게임 fork → `references/love-game-fork.md`
- 브라우저/TS 게임 fork → `references/threejs-browser-game-fork.md`
- 동양 역사 게임 CJK 검색 → `references/cjk-game-search-workflow.md`
- 빌드 환경 5분 사전 검증 → `references/build-environment-preflight-check.md`

## 핵심 원칙 (30분 안 PR 머지)

**가장 중요한 신호 1개**: **`i18n 인프라 + 한국어 번역 진행률`** — 이게 작업량을 **1주 → 1시간**으로 결정한다.

| 한국어 상태 | 추정 작업량 | 추천도 |
|------------|------------|--------|
| `ko.json` 또는 `ko-KR.json` 이미 존재 + 키 > 1000 | **1~2시간** (보완 + PR) | 🥇 최우선 |
| `ko.json` 일부 키만 존재 | 1~3일 (보완 + 코드) | 🥈 좋음 |
| `AvailableLanguages.tsx`에 `ko_KR` 등록만 됨 | 3~5일 (전체 풀번역) | 🥉 보통 |
| i18n 시스템 자체가 없음 | 1~2주 (인프라 + 번역) | 🟡 보류 |
| 라이선스 미명시 + 한국어 미지원 | 작업 불가 | ⛔ skip |

**즉시 적용 규칙**: 후보 조사 시작 즉시 **i18n 디렉토리 + 한국어 파일 존재 확인**이 1순위. 다른 모든 메트릭보다 우선.

## 5축 후보 평가 매트릭스 (CRITICAL, 2026-07-27 검증)

| 축 | 검증 방법 | 합격선 | 함정 |
|----|----------|--------|------|
| **1. 라이선스** | `gh repo view ... --json licenseInfo` + `raw.githubusercontent.com/.../LICENSE` 직접 fetch | MIT / BSD / Apache / MPL-2.0 / AGPL / GPL 모두 fork 가능. **NOASSERTION = 보류** | README는 "open-source" 명시하지만 LICENSE 파일 404 가능 — 항상 raw fetch로 검증 |
| **2. 활동성** | `pushedAt` (최근 30일 이내면 활발), `open_issues_count`, `forks_count` | pushed < 30일, forks > 100 | "최근 9개월 전 pushed"는 PR 머지 가능성 낮음 — 우선순위 ↓ |
| **3. 빌드 난이도** | `package.json` scripts / `*.godot` / `Cargo.toml` / `build.gradle` | 🟢 npm 2초 / 🟡 pnpm·gradle 30초~5분 / 🔴 C++ scons·CMake 위험 | Rust도 안정 (5분), Godot도 안정. **C++ scons + Boost는 90분+ 함정** |
| **4. 한국어 상태** | `resources/lang/`, `i18n/`, `strings/`, `lang/`, `locales/` 디렉토리 + `ko.json`/`ko-KR.json`/`ko.lua` raw fetch | 위 "추정 작업량" 표 참조 | i18n 인프라 명시 (예: `AvailableLanguages.tsx`) ≠ 실제 번역 파일 존재. 둘 다 확인 필요 |
| **5. 실행 가능성** | README 첫 화면의 GIF/screenshot 또는 `npm run dev` 5분 검증 | 실제 플레이 화면 GIF > 메뉴/데이터만 > WIP | **Wesnoth·cheft/sanguo 사례**: star 많고 활발해도 README에 "AI, 전투 미구현" → 실제 게임 안 됨 |

## 7단계 조사 워크플로 (총 15~20분)

### 1단계: `gh search repos` 광역 검색 (2분)

```bash
# 장르 + 언어 + 활동 + 별점 조합
gh search repos --limit 15 --sort stars --order desc \
  'topic:game language:Lua stars:100..5000' 2>&1 | head -30

# 또는
gh search repos --limit 10 --sort stars --order desc \
  'tower-defense language:Rust stars:200..3000' 2>&1 | head -20

# 또는 장르 키워드 직접
gh search repos --limit 10 --sort stars --order desc \
  'incremental-game stars:300..5000 language:TypeScript language:JavaScript'
```

**검색어 디자인 4가지 패턴**:
- 장르 (`roguelike`, `tower-defense`, `incremental-game`, `turn-based-strategy`)
- 라이브러리 (`love2d`, `wasm`, `godot`, `phaser`)
- 주제 (`sangokushi` CJK, `retro-game`, `simulator`)
- 구체 기능 (`ascii`, `terminal-roguelike`, `cyberpunk`)

### 2단계: 메타데이터 일괄 확인 (3분)

```bash
# 후보 1개당 1초 — 병렬화 가능
for repo in OWNER/REPO; do
  gh repo view "$repo" --json name,description,stargazerCount,licenseInfo,pushedAt,primaryLanguage,url
done
```

**필수 확인 필드**:
- `licenseInfo.spdx_id` → "NOASSERTION" 또는 null = ❌ 보류
- `pushedAt` → ISO 8601, 30일 이전이면 ✅
- `stargazerCount` → >= 200이면 활발
- `primaryLanguage` → JS/TS/GDScript/Rust = 🟢, Java/C# = 🟡, C++ scons = 🔴

### 3단계: README raw fetch (3분) — **`gh --json readme` 미작동 함정 회피**

```bash
# ❌ WRONG: gh repo view --json readme — Unknown JSON field: "readme"
gh repo view nkzw-tech/athena-crisis --json readme

# ✅ CORRECT: raw.githubusercontent.com 직접 fetch
curl -sL https://raw.githubusercontent.com/OWNER/REPO/main/README.md -o /tmp/readme.md
curl -sL https://raw.githubusercontent.com/OWNER/REPO/master/README.md -o /tmp/readme.md  # master fallback
```

**main vs master 확인법**:
```bash
curl -sL https://api.github.com/repos/OWNER/REPO 2>&1 | python3 -c "import json,sys; r=json.load(sys.stdin); print(r.get('default_branch'))"
```

**README 분석 우선순위**:
1. **"Build from sources" / "Setup" 섹션** → 빌드 명령어, 의존성 (5분 사전 검증의 입력)
2. **"Roadmap" / "TODO" / "WIP" 키워드** → 미완성 게임 함정 발견
3. **스크린샷/GIF URL** → 실제 플레이 화면 vs 메뉴만 구분
4. **"License" 섹션** → 자체 명시 라이선스. raw LICENSE 파일과 일치 확인

### 4단계: i18n 인프라 + 한국어 파일 확인 (3분)

**i18n 디렉토리 자동 탐색**:
```bash
# 일반적인 i18n 디렉토리 후보 5개
for path in resources/lang i18n strings lang locales src/locale; do
  curl -sL "https://api.github.com/repos/OWNER/REPO/contents/$path" 2>&1 | \
    python3 -c "import json,sys; r=json.load(sys.stdin); \
    print('\n'.join(i['name'] for i in r if isinstance(r,list)))" 2>/dev/null | grep -E "ko|en" | head -5
done
```

**한국어 파일 raw fetch + 키 개수 측정**:
```bash
curl -sL https://raw.githubusercontent.com/OWNER/REPO/main/resources/lang/ko.json 2>&1 | \
  python3 -c "import json,sys; r=json.load(sys.stdin); print('keys:', len(r) if isinstance(r, (dict,list)) else 'not dict'); print('first:', list(r)[:5] if isinstance(r, dict) else r[:5])"
```

**예상 출력**:
- `keys: 50` + `first: [('lang', ...), ('common', ...)]` → 50개 키 그룹 (OpenFrontIO 사례)
- `keys: 10164` → 이미 90%+ 번역 완료 (Evolve 사례)
- `Empty / 404` → 한국어 파일 없음

### 5단계: 빌드 명령어 추출 + 5분 사전 검증 (5분)

**5단계 빌드 환경 분류** (기존 스킬 §LÖVE 빌드 환경 분류 참조):

| 분류 | 빌드 도구 | 빌드 시간 | macOS 호환성 | 사례 |
|------|----------|----------|--------------|------|
| 🟢 즉시 성공 | `npm`/`yarn` | 2초 | ✅ 네이티브 | OpenFrontIO, sango-rising-dragons, Claude-of-Duty |
| 🟢 LÖVE/Lua 게임 | `love .` | 0초 | ✅ brew cask | SNKRX |
| 🟡 Java/Gradle | `./gradlew` | 30초~5분 | ✅ 안정 | triplea, FreeCol |
| 🟠 Rust/cargo | `cargo build` | 1~5분 | ✅ 안정 | zemeroth, veloren |
| 🔴 C++ scons/CMake | `scons`/`make` | 30분~1시간 | ⚠️ 환경 의존 | Wesnoth (Boost/SDL 함정) |
| ⚫ C# | `dotnet`/`mono` | 1~5분 | ⚠️ mono 의존 | RTK2020-CORE |

**5분 사전 검증**: 자세한 워크플로는 `references/build-environment-preflight-check.md` 참조.

### 6단계: 즉시 실행 명령어 작성 (2분)

각 후보에 대해 fork + 빌드 + 첫 실행 명령어까지 한 블록으로 제공:
```bash
# 1순위 후보
gh repo fork OWNER/REPO --clone
cd REPO
[build command from README]
[verify command: dev server URL or .love build]
```

### 7단계: 추천 매트릭스 + 의사결정 가이드 작성 (2분)

**사용자에게 보여줄 매트릭스 형태**:
```markdown
| 순위 | 후보 | ⭐ | 라이선스 | 한국어 상태 | 빌드 | 추천도 |
|------|------|------|----------|------------|------|--------|
| 🥇 1 | OWNER/REPO | 2,429 | AGPL-3.0 | 50% (50개 키 그룹) | 🟢 npm | ⭐⭐⭐⭐⭐ |
| 🥈 2 | OWNER/REPO | 1,967 | MIT | 0% (등록만) | 🟡 pnpm | ⭐⭐⭐⭐ |
```

**즉시 적용 규칙 (사용자 출력 형식)**:
- 사용자 요청이 "TOP 3 링크만 알려줘"면 **매트릭스 X, 링크만** (이전 스킬 §사용자 정정 시그널)
- "조사하고 추천해줘"면 **순위 + 이유 + 명령어** 매트릭스 OK
- 단, 매트릭스 열 6개를 초과하지 말 것 — 가독성 폭발 방지

---

## 2026-07-27 실측: 5개 후보 비교

### 🥇 1순위: openfrontio/OpenFrontIO (⭐ 2,429)

| 항목 | 값 |
|------|---|
| URL | https://github.com/openfrontio/OpenFrontIO |
| 라이선스 | AGPL-3.0 (자산 CC BY-SA 4.0) |
| 언어 | TypeScript |
| 한국어 상태 | **🟢 `resources/lang/ko.json` 이미 존재, 50개 키 그룹** (닫기/복사/로그인/플레이/순위표 등) |
| 활동성 | pushed 2026-07-27 (어제!), 145 issues, 1,218 forks |
| 빌드 | 🟢 `npm run inst && npm run dev:client` 2초, 브라우저 자동 오픈 |
| 실행 가능성 | ✅ openfront.io 데모 즉시 플레이 가능 |
| 첫 PR까지 예상 | **1~2시간** (ko.json 보완 + 신규 키 동시 추가) |
| 함정 | AGPL — SaaS 배포 시 소스 공개 의무. sigco3111 개인 repo는 무관 |

### 🥈 2순위: nkzw-tech/athena-crisis (⭐ 1,967)

| 항목 | 값 |
|------|---|
| URL | https://github.com/nkzw-tech/athena-crisis |
| 라이선스 | **MIT** (Copyright 2024 Nakazawa Tech KK) |
| 언어 | TypeScript, pnpm monorepo |
| 한국어 상태 | **🟡 `i18n/AvailableLanguages.tsx`에 `ko_KR` 등록됨, `i18n` 전용 패키지 존재, 실제 번역은 부재** |
| 활동성 | pushed 2026-07-17, 158 forks |
| 빌드 | 🟡 `pnpm install && pnpm dev:setup` + `pnpm dev:docs` (localhost:3003). pnpm 경험 필요 |
| 실행 가능성 | ✅ athenacrisis.com 데모 무료 플레이. **Open-core**: 엔진/맵 데이터만 오픈, 캠페인/멀티플레이는 유료 |
| 첫 PR까지 예상 | **3~5일** (i18n/ko_KR/ 풀번역 + 코드 통합) |
| 함정 | pnpm 셋업. Open-core — 캠페인 데이터 fork 불가 |

### 🥉 3순위: pmotschmann/Evolve (⭐ 1,185)

| 항목 | 값 |
|------|---|
| URL | https://github.com/pmotschmann/Evolve |
| 라이선스 | MPL-2.0 |
| 언어 | JavaScript (jQuery 기반) |
| 한국어 상태 | **🟢 `strings/strings.ko-KR.json` 이미 존재, 10,164개 키** (90%+ 번역 완료) |
| 활동성 | pushed 2026-07-27 (어제!) |
| 빌드 | 🟢 정적 빌드, `python3 -m http.server`로 즉시 서빙 |
| 실행 가능성 | ✅ itch.io + GitHub Pages에서 플레이 가능 |
| 첫 PR까지 예상 | **30분** (번역 누락 키 보완 + 신규 콘텐츠 동시 번역) |
| 함정 | MPL-2.0 — 수정 파일 공개 의무 (영향 작음) |

### 4순위: P1X-in/tanks-of-freedom-ii (⭐ 418)

| 항목 | 값 |
|------|---|
| URL | https://github.com/P1X-in/tanks-of-freedom-ii |
| 라이선스 | ⚠️ **NOASSERTION (라이선스 미명시)** — README에 LICENSE.md 링크 있지만 raw 404 |
| 언어 | GDScript (706,888 LOC) |
| 한국어 상태 | 🔴 i18n 인프라 미확인 |
| 활동성 | pushed 2025-10-02 (9개월 전) — 다소 멈춤 |
| 빌드 | 🟢 Godot 4.2+ 에디터에서 import |
| 실행 가능성 | ✅ itch.io에서 다운로드 가능 |
| 첫 PR까지 예상 | 작업 보류 권장 |
| 함정 | **라이선스 미명시 = 법적 불명확**. 1편(`w84death/Tanks-of-Freedom`)은 MIT, 그쪽 fork가 더 안전 |

### 5순위: FreezingMoon/AncientBeast (⭐ 1,862)

| 항목 | 값 |
|------|---|
| URL | https://github.com/FreezingMoon/AncientBeast |
| 라이선스 | AGPL-3.0 |
| 언어 | TypeScript |
| 한국어 상태 | 🟡 클래스/스킬 이름 다수 — 디자인 깊이 깊음 |
| 활동성 | pushed 2026-07-25, 460 issues, 700 forks — 활발 |
| 빌드 | 🟡 npm + 자체 빌드 시스템 |
| 실행 가능성 | ✅ web/electron 모두 지원 |
| 첫 PR까지 예상 | 1~2주 |
| 함정 | AGPL-3.0 + 디자인 깊이 → 작업량 큼 |

---

## ⭐ `gh repo view --json readme` 미작동 함정 (CRITICAL, 2026-07-27 발견)

**증상**:
```bash
$ gh repo view OWNER/REPO --json readme 2>&1
Unknown JSON field: "readme"
Available fields:
  archivedAt, assignableUsers, codeOfConduct, contactLinks, ...
  ← readme 필드 **없음**
```

**원인**: `gh repo view --json`의 **사용 가능한 필드 목록**에 `readme`가 포함되어 있지 않다. README 본문을 GraphQL로 가져오려면 별도 쿼리 필요.

**해결**: `curl -sL https://raw.githubusercontent.com/.../README.md` 직접 fetch:
```bash
curl -sL https://raw.githubusercontent.com/OWNER/REPO/main/README.md -o /tmp/readme.md
# master 브랜치 시도
[ ! -s /tmp/readme.md ] && curl -sL https://raw.githubusercontent.com/OWNER/REPO/master/README.md -o /tmp/readme.md
wc -l /tmp/readme.md  # 0이면 둘 다 실패 → 빈 README
```

**기본 브랜치 자동 감지**:
```bash
curl -sL https://api.github.com/repos/OWNER/REPO 2>&1 | python3 -c "import json,sys; r=json.load(sys.stdin); print(r.get('default_branch'))"
```

**다른 사용 가능한 GraphQL 필드** (필요 시):
- `description` — 저장소 설명 (간단 요약에 충분)
- `openGraphImageUrl` — README 자동 생성 OG 이미지 URL (visual 검증)
- `licenseInfo.spdx_id` — 라이선스
- `repositoryTopics` — 주제 태그

## ⭐ stderr/stdout JSON 분리 함정 (2026-07-27 발견)

**증상**: `gh repo view --json ... 2>&1 | python3 -c "json.load(sys.stdin)"` 호출 시 `Expecting value: line 1 column 1 (char 0)` 에러.

**원인**: `gh`가 `!` 시작하는 경고 메시지(`! Failed to ...`)를 stderr가 아닌 stdout에 섞어 출력 → JSON 파싱 실패.

**해결 — redirect 분리**:
```bash
# ❌ WRONG: stderr와 stdout 혼합 → JSON 파싱 실패
gh repo view OWNER/REPO --json readme 2>&1 | python3 -c "import json,sys; ..."

# ✅ CORRECT: stderr 분리 + 파일로 캡처
gh repo view OWNER/REPO --json licenseInfo 2>&1 1>/tmp/repo.json
python3 -c "import json; print(json.load(open('/tmp/repo.json')))"
```

**또는 curl + jq가 더 안정**:
```bash
curl -sL -H "Authorization: Bearer $(gh auth token)" \
  https://api.github.com/repos/OWNER/REPO \
  | python3 -c "import json,sys; print(json.load(sys.stdin).get('license'))"
```

## ⭐ i18n 디렉토리 표준 위치 8가지 (2026-07-27 검증)

OSS 게임에서 i18n/locale 디렉토리는 다음 8개 위치 중 하나 (우선순위):

| 위치 | 사례 | 한국어 파일 패턴 |
|------|------|-----------------|
| `resources/lang/` | OpenFrontIO, Wesnoth | `ko.json` (영어 fallback) |
| `i18n/` | athena-crisis, mshumer/Claude-of-Duty | `AvailableLanguages.tsx` + `ko_KR/` 디렉토리 |
| `strings/` | pmotschmann/Evolve | `strings.ko-KR.json` (JQuery getJSON) |
| `lang/` | SNKRX (Lua) | `lang/ko.lua` 모듈 |
| `locales/` | SNKRX의 보조 디렉토리 | `ko.lua` 또는 `ko.po` |
| `src/data/locale*` | sango-rising-dragons | `ko.json` 또는 `ko/ko.json` |
| `data/` | Wesnoth, sango | `data/ko/...` 또는 `data/ko.json` |
| `public/data/` | sango-rising-dragons 모드팩 | `public/data/ko/*.json` + `manifest.json` |

**탐색 스크립트** (위 8개 위치 순회):
```bash
for path in resources/lang i18n strings lang locales src/data/locale src/data src/locale data public/data; do
  files=$(curl -sL "https://api.github.com/repos/$1/contents/$path" 2>&1 | \
    python3 -c "import json,sys; r=json.load(sys.stdin); print('|'.join(i['name'] for i in r if isinstance(r,list) and any(i['name'].startswith(p) for p in ['ko', 'en'])))" 2>/dev/null)
  if [ -n "$files" ]; then echo "  $path: $files"; fi
done
```

## ⭐ 미완성 게임 함정 (2026-07-27 재확인, 기존 §미완성 게임 함정 참조)

이번 5개 후보에서 모두 **실제 플레이 가능** 확인됨 (Wesnoth/cheft/sanguo 사례 회피). **단, Tanks of Freedom II는 라이선스 미명시 + 활동 멈춤으로 보류**.

---

## 즉시 실행 명령어 (사용자 보고용)

```bash
# 1순위: OpenFrontIO fork → 첫 PR
gh repo fork openfrontio/OpenFrontIO --clone
cd OpenFrontIO
npm run inst
npm run dev:client  # → http://localhost:3000, 한국어 확인
# → ko.json 보완 + PR

# 2순위: athena-crisis fork → 풀번역
gh repo fork nkzw-tech/athena-crisis --clone
cd athena-crisis
pnpm install && pnpm dev:setup
pnpm dev:docs  # → http://localhost:3003, i18n 디렉토리 확인
# → i18n/ko_KR/ 풀번역

# 3순위: Evolve 검증 + 보완
gh repo fork pmotschmann/Evolve --clone
cd Evolve
python3 -m http.server 8000  # → http://localhost:8000, ko-KR locale 동작 확인
# → strings/strings.ko-KR.json 보완 + PR
```

---

## 다음 세션에 전달할 교훈

1. **`gh repo view --json readme`는 작동 안 함** → raw fetch 패턴 표준화
2. **i18n 인프라 + 한국어 키 개수가 fork 가치를 결정** → 다른 어떤 메트릭보다 우선
3. **stderr 분리 redirect** (`2>&1 1>/tmp/file`) — gh CLI JSON 파싱 전제조건
4. **i18n 디렉토리 8개 표준 위치** 자동 순회 스크립트 — fork 첫 단계에서 즉시 활용
5. **미완성 게임 함정**: README "WIP/TODO/미구현" 키워드 + screenshot이 메뉴만 → 보류