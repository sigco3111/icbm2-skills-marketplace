# 한국어 임베딩 벤치마크 — NIM 11개 모델 실측 (2026-07-14)

> Stanford generative_agents-kr 작업 중 한국어 retrieval 정확도 검증한 결과.
> 다음에 또 한국어 OSS fork 만들 때 같은 함정 안 빠지도록.

## 결론 (TL;DR)

| 모델 | 차원 | 비대칭? | 한국어 정확도 | 판정 |
|------|------|--------|---------------|------|
| **nvidia/llama-nemotron-embed-1b-v2** | **2048** | ✅ (input_type 필수) | **6/8 (75%)** | ✅ **승자** |
| nvidia/nv-embed-v1 | 4096 | ❌ 대칭 | 4-5/12 (50%) | ⚠️ 점수 너무 높음 (위양성 多) |
| nvidia/nv-embedqa-e5-v5 | 1024 | ✅ | 4/8 (50%) | ❌ retrieval 분해능 낮음 (0.36~0.44 범위) |
| nvidia/llama-nemotron-embed-vl-1b-v2 | 2048 | ✅ | 4/8 (50%) | 비전 임베딩, 부적합 |
| nvidia/nv-embedcode-7b-v1 | 4096 | ✅ | 3/8 (38%) | 코드 특화 |
| baai/bge-m3 | - | - | - | ❌ NIM 500 Internal Server Error |
| snowflake/arctic-embed-l | - | - | - | ❌ NIM 404 |
| nvidia/embed-qa-4 | - | - | - | ❌ NIM 404 |
| nvidia/llama-3.2-nv-embedqa-1b-v1 | - | - | - | ❌ NIM 404 |
| nvidia/nv-embedqa-mistral-7b-v2 | - | - | - | ❌ NIM 404 |
| nvidia/llama-3.2-nemoretriever-1b-vlm-embed-v1 | - | - | - | ❌ NIM 404 |

## 카테고리별 정확도 (8 핵심 케이스)

llama-nemotron-embed-1b-v2 기준:

| 카테고리 | 케이스 | 의도 | 유사도 | 판정 |
|---------|--------|------|--------|------|
| 어순재배열 | "이서연 카페 커피" ↔ "카페에서 커피 마시는 이서연" | HIGH (≥0.55) | 0.591 | ✅ |
| 시제변형 | "카페 커피 마신다" ↔ "카페 커피 마실 것이다" | HIGH | 0.878~0.970 | ✅ |
| 의역/동의어 | "공부한다" ↔ "학습한다" | HIGH | 0.848~0.969 | ✅ |
| 조사변형 | "이서연은" ↔ "이서연이" | HIGH | 0.928~0.961 | ✅ |
| 시간변경 | "어제 카페 커피" ↔ "오늘 카페 커피" | HIGH | 0.593 | ✅ |
| 관계변경 | "친구와 영화" ↔ "가족과 영화" | HIGH | 0.839 | ✅ |
| 부분정보 | "카페 커피 마신다" ↔ "이서연이 마신 음료는?" | MID (0.30-0.55) | 0.474 | ✅ |
| 같은카테고리 | "비빔밥 한국 전통" ↔ "김치는 한국 전통" | MID | 0.550 (경계) | ❌ |
| 다른사람 | "이서연 카페 커피" ↔ "김민준 도서관 공부" | LOW (<0.40) | 0.222 | ✅ |
| 완전무관 | "이서연 카페 커피" ↔ "오늘 날씨가 어때?" | LOW | 0.044 | ✅ |
| **부정** | "비빔밥은 한국 전통 음식이다" ↔ "비빔밥은 한국 전통 음식이 **아니다**" | LOW | **0.676** | ❌ **모델 약점** |

## 발견된 함정

### 함정 A: 비대칭 모델 단일 타입 통일 시 모든 점수 0.93+

```python
# ❌ 이렇게 하면 retrieval 작동 안 함 (모든 passage가 다 관련 있어 보임)
for text in texts:
    emb = embed(model, text, input_type="passage")

# ✅ 반드시 passage(저장) ↔ query(검색) 분리
passage_emb = embed(model, "이서연은 카페에서 커피를 마신다", "passage")
query_emb = embed(model, "이서연이 마신 음료는?", "query")
sim = cosine_similarity(passage_emb, query_emb)
```

**검증된 비대칭 모델** (NIM):
- `nvidia/llama-nemotron-embed-1b-v2` ✅
- `nvidia/nv-embedqa-e5-v5` ✅
- `nvidia/nv-embedcode-7b-v1` ✅

**대칭 모델** (input_type 불필요):
- `nvidia/nv-embed-v1` (4096d, 한국어 점수 너무 높아서 위양성 多)

### 함정 B: nv-embedqa-e5-v5 retrieval 분해능 부족

비대칭 QA 모델이라 retrieval에 특화되어야 하지만, 한국어 일반 메모리 검색에는 **모든 케이스 0.36~0.44 범위로 뭉개짐**. 카테고리 구분 안 됨. → QA 문서 검색용으로는 OK, generative agent 메모리 검색용으로는 부적합.

### 함정 C: 부정 표현 무시는 모든 모델 공통

`"~않다"`, `"~not"`, `"hate"` 등을 임베딩 모델이 무시하고 **관련 케이스와 동일하게 0.85+ 점수** 반환. 두 모델 모두에서 검증됨.

→ **반드시 retrieval 점수 레이어에서 `negation_penalty()` 가드 필요** (5줄 패턴, SKILL.md §4 참조).

## 50 케이스 전체 카테고리 분포

`nvidia/nv-embed-v1` 기준:

| 카테고리 | n | 정확도 | 비고 |
|---------|---|--------|------|
| 시제변형 | 5 | 100% | 어제/오늘/내일 자유 변환 |
| 어순재배열 | 5 | 100% | "이서연 카페 커피" ↔ "카페에서 커피 마시는 이서연" |
| 의역/동의어 | 5 | 100% | 마심 ↔ 즐김, 공부 ↔ 학습 |
| 조사변형 | 5 | 100% | 은/는/이/가 변형 |
| 시간변경 | 2 | 100% | 어제/오늘/내일 |
| 관계변경 | 1 | 100% | 친구 ↔ 가족 |
| 행동반대 | 1 | 100% | 산다 ↔ 판다 |
| **부정** | 5 | **0%** | ⚠️ "~않다" 무시 (가드 필수) |
| **부분정보** | 5 | **0%** | ⚠️ 의문사 retrieval 약함 |
| **같은카테고리** | 5 | **0%** | ⚠️ "비빔밥↔김치" 0.78 |
| **행동변경** | 5 | **0%** | ⚠️ 같은 사람 다른 행동도 0.5+ |
| 다른사람 | 5 | 40% | 의도보다 모두 높게 나옴 |
| 장소변경 | 1 | 0% | "한강↔공원" 0.81 |

## 재현 코드 (50 케이스 측정)

```python
import os, json, math, urllib.request

KEY = os.environ["NVIDIA_API_KEY"]
URL = "https://integrate.api.nvidia.com/v1/embeddings"
MODEL = "nvidia/llama-nemotron-embed-1b-v2"  # 검증된 승자

def embed_passage(text):
    return _nim_embed(MODEL, text, "passage")

def embed_query(text):
    return _nim_embed(MODEL, text, "query")

def cos(a, b):
    na = math.sqrt(sum(x*x for x in a))
    nb = math.sqrt(sum(x*x for x in b))
    return sum(x*y for x, y in zip(a, b)) / (na * nb)

# 8개 핵심 케이스만 추렸을 때 6/8 (75%)
test_cases = [
    ("이서연은 카페에서 커피를 마신다", "카페에서 커피를 마시는 이서연", "HIGH"),
    ("비빔밥은 한국의 전통 음식이다", "비빔밥은 한국 전통 음식이 아니다", "LOW"),
    ("이서연은 카페에서 커피를 마신다", "이서연이 마신 음료는?", "MID"),
    ("이서연은 카페에서 커피를 마신다", "김민준은 도서관에서 공부한다", "LOW"),
    ("비빔밥은 한국의 전통 음식이다", "김치는 한국의 전통 음식이다", "MID"),
    ("이서연은 어제 카페에서 커피를 마셨다", "이서연은 오늘 카페에서 커피를 마신다", "HIGH"),
    ("이서연은 카페에서 커피를 마신다", "오늘 날씨가 어때?", "LOW"),
    ("이서연은 카페에서 커피를 마신다", "이서연은 카페에서 커피를 마실 것이다", "HIGH"),
]

# 측정 후 negation_penalty 가드 추가
NEGATION_KO = ["않", "안 ", "못 ", "없", "아니", "말고", "싫어하"]
NEGATION_EN = ["not ", "n't ", " no ", "never", "none", "hate"]

def negation_penalty(a, b):
    a_neg = any(n in a.lower() for n in NEGATION_KO + NEGATION_EN)
    b_neg = any(n in b.lower() for n in NEGATION_KO + NEGATION_EN)
    if a_neg != b_neg: return 0.4
    if a_neg and b_neg: return 0.1
    return 0.0
```

## 적용 결론

| 시나리오 | 추천 모델 |
|---------|----------|
| 한국어 메모리 retrieval (generative agents 등) | **llama-nemotron-embed-1b-v2** |
| 한국어 QA 문서 검색 | nv-embedqa-e5-v5 |
| 영어/다국어 메모리 | nv-embed-v1 (대칭, 4096d) |
| 코드 검색 | nv-embedcode-7b-v1 |
| 부정 검색이 중요한 경우 | 어떤 모델이든 **negation_penalty 가드 필수** |

## NIM `/v1/models` 전체 목록 (참고)

NIM에 등록된 121개 모델 중 임베딩 후보 11개 (위 표). 그 외:
- LLM: gpt-oss-120b (`openai/gpt-oss-120b`), llama-3.1-70b, nemotron 등
- Vision: nvidia/llama-3.2-nemoretriever-1b-vlm-embed-v1
- Code: nv-embedcode-7b-v1
- Reasoning: openai/gpt-oss-120b, llama-3.1-405b

자세한 모델 목록은 `curl https://integrate.api.nvidia.com/v1/models -H "Authorization: Bearer $KEY"` 로 조회.
