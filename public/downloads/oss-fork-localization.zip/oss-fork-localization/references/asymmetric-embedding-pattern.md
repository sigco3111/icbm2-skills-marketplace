# 비대칭 임베딩 패턴 (Asymmetric Embedding)

> NIM `llama-nemotron-embed-1b-v2` 같은 비대칭 모델은 메모리 retrieval 작업에서 6/8 (75%) 정확도로 **대칭형 (nv-embed-v1, ada-002) 보다 우수**. 단, 반드시 `input_type=passage|query` 분리가 필요.

## 비대칭 모델이란

대부분의 임베딩 모델은 **대칭형(symmetric)** — "A 쿼리"와 "A 문서"가 같은 벡터 공간에 align됨.

비대칭 모델은 **두 가지 다른 함수**로 호출:
- `passage` 모드: "저장할 문서"에 특화된 벡터 (검색 인덱스)
- `query` 모드: "검색할 질문"에 특화된 벡터 (쿼리)

내부적으로 **다른 신경망 경로**를 타며, 의미적으로 **align** 되어 있어서 retrieval 정확도가 압도적.

## 한국어 검증 결과 (12 핵심 케이스)

검증 일자: 2026-07-14 (sigco3111/generative_agents-kr Phase 1)

| 모델 | 차원 | 정확도 (HIGH≥0.55, MID 0.30-0.55, LOW<0.40) | 판정 |
|------|------|---------------------------------------------|------|
| **nvidia/llama-nemotron-embed-1b-v2** | 2048 | **6/8 (75%)** | ✅ **최고** |
| nvidia/nv-embedqa-e5-v5 | 1024 | 4/8 (50%) | 중간 |
| nvidia/llama-nemotron-embed-vl-1b-v2 | 2048 | 4/8 (50%) | 비전 임베딩이라 부적합 |
| nvidia/nv-embedcode-7b-v1 | 4096 | 3/8 (38%) | 코드 특화, 부적합 |
| nvidia/embed-qa-4 | - | 404 | NIM 미서빙 |
| nvidia/llama-3.2-nv-embedqa-1b-v1 | - | 404 | NIM 미서빙 |
| nvidia/nv-embedqa-mistral-7b-v2 | - | 404 | NIM 미서빙 |
| nvidia/llama-3.2-nemoretriever-1b-vlm-embed-v1 | - | 404 | NIM 미서빙 |
| nv-embed-v1 (대칭) | 4096 | 4-5/8 | 어순/시제만 정확, 다른 사람 분리 약함 |

## llama-nemotron-embed-1b-v2 상세 (8 핵심 케이스 점수)

| 케이스 | 의도 | 유사도 | 판정 |
|--------|------|--------|------|
| 어순재배열 | HIGH | 0.591 | ✅ |
| 부정 | LOW | 0.676 | ❌ (가드 필요) |
| 부분정보 | MID | 0.474 | ✅ |
| 다른사람 | LOW | 0.222 | ✅ |
| 같은카테고리 | MID | 0.550 | ❌ (경계값) |
| 시간변경 | HIGH | 0.593 | ✅ |
| 무관 | LOW | 0.044 | ✅ |
| 시제변형 | HIGH | 0.596 | ✅ |

**부정(negation)** 만 미해결 → 5줄 `negation_penalty()` 가드 필수.

## 코드 패턴

### 1. 함수 2개 분리 (저장/검색)

```python
EMBED_MODEL = "nvidia/llama-nemotron-embed-1b-v2"

def _nim_embed(text, input_type):
    body = {"model": EMBED_MODEL, "input": [text], "input_type": input_type}
    return _nim_post("/embeddings", body)["data"][0]["embedding"]

def get_passage_embedding(text):
    """메모리 저장 (init.json 로드, 새 observation 추가) 시 사용."""
    text = (text or "this is blank").replace("\n", " ")
    return _nim_embed(text, "passage")

def get_query_embedding(text):
    """메모리 검색 (retrieval step) 시 사용."""
    text = (text or "this is blank").replace("\n", " ")
    return _nim_embed(text, "query")

def get_embedding(text, model=None):
    """원본 호환 — passage 기본값 (저장 시)."""
    return get_passage_embedding(text)
```

### 2. Retrieval 점수 통합 (cos + negation)

```python
def cosine_similarity(a, b):
    if not a or not b: return 0.0
    na = sum(x * x for x in a) ** 0.5
    nb = sum(x * x for x in b) ** 0.5
    if na == 0 or nb == 0: return 0.0
    return sum(x * y for x, y in zip(a, b)) / (na * nb)

def score_memory(query_text, memory_text,
                 query_emb=None, memory_emb=None,
                 use_negation_guard=True):
    if query_emb is None:
        query_emb = get_query_embedding(query_text)
    if memory_emb is None:
        memory_emb = get_passage_embedding(memory_text)
    sim = cosine_similarity(query_emb, memory_emb)
    if use_negation_guard:
        sim -= negation_penalty(query_text, memory_text)
    return max(0.0, sim)
```

### 3. 호출부 변경 (모든 retrieval 지점)

```python
# ❌ 원본 (OpenAI ada-002 호환)
mem_emb = get_embedding(memory)
query_emb = get_embedding(query)
score = cosine_similarity(mem_emb, query_emb)

# ✅ 비대칭 (NIM llama-nemotron)
mem_emb = get_passage_embedding(memory)   # 저장 시
query_emb = get_query_embedding(query)    # 검색 시
score = score_memory(query_text=query, memory_text=memory,
                     query_emb=query_emb, memory_emb=mem_emb)
```

## 함정

### 1. `input_type=passage` 통일 시 retrieval 깨짐

비대칭 모델을 **하나의 input_type으로만** 호출하면 모든 케이스 0.93+로 collapse:
```
모든 (p, q) 쌍: 0.93 ~ 0.99
"관련" vs "무관" 구분 불가
```
→ **반드시 passage ↔ query 분리 호출.**

### 2. 차원 변경 시 기존 인덱스 무효화

| 모델 | 차원 |
|------|------|
| OpenAI ada-002 | 1536 |
| nv-embed-v1 | 4096 |
| llama-nemotron-embed-1b-v2 | 2048 |

한 번 임베딩 모델을 바꾸면 **기존 시뮬레이션 storage 의 모든 임베딩 캐시 무효화**. 다음 시뮬레이션 시작 시 재계산됨 (Generative Agents 구조상 매 simulation 별 init).

### 3. 메모리 비용

| 차원 | 25명 × 1000 메모리 |
|------|-------------------|
| 1536 | ~150 MB |
| 2048 | ~200 MB |
| 4096 | ~400 MB |

대칭 4096d 비대칭 2048d 차이 = 50% 절약.

## 검증 단계별 체크리스트

LLM 백엔드 교체 시 다음 순서로 검증:

1. **NIM 키 로드** — `config_check()` 출력 확인
2. **chat 호출** — `ChatGPT_request("ping") → "ping"`
3. **passage 임베딩** — 차원 + 음수/양수 혼합 (정규화 전 raw)
4. **query 임베딩** — passage 와 다른 벡터 (검증: `cos(p, q_p) < 0.95`)
5. **비대칭 검색** — 의도된 (p, q) 쌍이 검색 점수 분해됨

## 결정 가이드

| 트레이드오프 | 선택 |
|------------|------|
| 정확도 우선, 메모리 OK | **llama-nemotron-embed-1b-v2** (2048d, 비대칭) |
| 메모리 우선, 정확도 ↓ | nv-embed-v1 (4096d, 대칭) |
| OpenAI 호환 원격 | ada-002 (1536d) |

**2026-07-14 추천**: `llama-nemotron-embed-1b-v2` (75% 정확도 + 2048d 절약 + 한국어 어순/조사/시제 우수).
