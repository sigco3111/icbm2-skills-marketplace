# Git LFS 우회 mirror 푸시 (08-08 verified)

> Git LFS object가 클론 시 누락된 채 mirror해야 할 때 — `git push --mirror`가
> `fatal: did not receive expected object <sha>` 에러로 실패하는 문제의
> 4단계 우회 절차. **proofofplay/piratenation-art (CC0, 154K 파일, 692MB)** +
> **proofofplay/piratenation-game (MIT, 37K 파일, 978MB)** 실측 검증.

---

## ⚠️ 언제 이 함정에 빠지나

원본 저장소가 다음 조건을 만족할 때 **clone 후 LFS object가 모두 placeholder**로 남음:

1. `.gitattributes`에 `*.png filter=lfs diff=lfs merge=lfs` 등 LFS 추적 패턴 정의
2. `git lfs`가 clone 환경에 미설치 (또는 LFS server 도달 불가)
3. `file <asset>.png` 출력이 `version https://git-lfs.github.com/spec/v1` (ASCII text 132B)
4. LFS server fetch 실패 또는 quota 초과

이 상태에서 `git push --mirror` 또는 `git push origin main` 하면:

```
remote: fatal: did not receive expected object 6a59a9127f7d78a23fbb3cd31baf76dc3ec4acc1
error: remote unpack failed: index-pack failed
```

**원인**: pack이 reachable하지 않은 dangling LFS object를 포함. index-pack 검증 실패.

---

## 🚫 시도해본 것 (안 됨)

| 시도 | 결과 | 이유 |
|---|---|---|
| `git push --mirror` | ❌ "did not receive expected object" | LFS object 누락 |
| `GIT_LFS_SKIP_PUSH=1 git push --mirror` | ❌ 동일 | pack 생성 단계에서 LFS object 요구 |
| `GIT_LFS_SKIP_PUSH=1 git push --mirror --no-thin` | ❌ origin/main ref 거부 | --mirror가 upstream fetch ref까지 시도 |
| `git push origin main --force --no-thin` | ❌ 동일 | pack에 LFS object 포함 |
| `brew install git-lfs && git lfs fetch --all` | ⏱️ 692MB → 1시간+ | LFS server 응답 + quota 위험 |
| `git lfs push --all origin main` | 💸 quota 초과 위험 | GitHub LFS 1GB 무료 |

---

## ✅ 4단계 우회 절차 (실측 성공)

### Step 1 — 임시 디렉토리로 복사 + .git 제거

```bash
cd ~/work
rm -rf /tmp/<repo>-fresh
cp -R <repo> /tmp/<repo>-fresh
cd /tmp/<repo>-fresh
rm -rf .git
```

### Step 2 — fresh git init + LFS filter 무력화

```bash
git init -b main
git config user.email "sigco3111@users.noreply.github.com"
git config user.name "sigco3111"

# LFS filter를 단순 cat으로 → LFS pointer 텍스트가 pack에 그대로 포함됨
git config filter.lfs.clean "cat"
git config filter.lfs.smudge "cat"
git config filter.lfs.process "cat"
git config filter.lfs.required "false"

# .gitattributes는 LFS 복원용으로 백업
mv .gitattributes .gitattributes.original
```

**핵심**: `filter.lfs.clean = "cat"`이 pointer 텍스트를 변환 없이 통과시킴. .gitattributes를 `.original`로 빼면 LFS 추적이 **비활성** 상태가 됨.

### Step 3 — add + 1 squash commit

```bash
git add -A  # 154K 파일이라도 30~60초면 끝남 (LFS object 없으므로)
git commit -m "Mirror of proofofplay/<repo> (CC0) with Korean docs

원본: https://github.com/proofofplay/<repo>
라이선스: CC0 1.0 Universal

원본 mirror + 한국어 문서 추가.
LFS filter 우회로 push (pointer 텍스트만 포함).
실제 자산은 git lfs pull로 받아야 함."
```

**squash 1 commit**의 가치: dangling object가 단일 commit에 응축되어 검증 부담 감소. 또한 mirror 신호 명확.

### Step 4 — origin 변경 + force push

```bash
git remote remove origin 2>/dev/null
git remote add origin https://github.com/sigco3111/<repo>.git
git push origin main --force
```

**`--force` 필수**: GitHub에 이미 다른 mirror commit이 있을 수 있음 (`79456f8` 같은 Initial commit). force로 덮어쓰기.

---

## 📊 실측 결과 (proofofplay/piratenation-art)

| 단계 | 시간 | 결과 |
|---|---|---|
| Step 1 (cp + rm .git) | 30초 | 임시 디렉토리 준비 |
| Step 2 (init + filter) | 5초 | LFS 우회 설정 |
| Step 3 (add + commit) | 60초 | 154,281 파일 commit |
| Step 4 (push) | 30초 | 79456f8 → 38d5773 forced update |
| **총** | **2분** | ✅ mirror 완료 |

원본 작업 시간 추정: 30~60분 (LFS object fetch) → **2분으로 단축**.

---

## 🔄 mirror 사이클 — 5단계 정형 (다른 agent가 작업한 mirror 푸시 시)

**3번째 검증 (2026-08-08 piratenation-art/game 2차 mirror)**: 다른 에이전트/세션이
로컬에서 mirror 작업 (한국어 README 추가 등) 후 푸시하지 못한 흔적을 발견했을 때
적용하는 정형 절차. 단순 4단계 우회 + 사전 검증 1단계 추가.

### Step 0 — 인증 + 상태 확인 (NEW 2026-08-08)

```bash
# 1) GitHub 인증 확인 (다른 agent가 sigco3111이 아닐 수 있음)
gh auth status
# → "Logged in to github.com account sigco3111 (keyring)" 확인
# 다른 계정이면:
gh auth login --hostname github.com --with-token < ~/.hermes/secrets/github_token.txt

# 2) 원본 폴더 상태 확인
cd ~/work/<repo>
git status --short
git log --oneline -3
git remote -v
```

**판별 신호**:
- untracked `.omo/` 또는 `.aider*` → AI 도구 캐시, .gitignore에 추가
- modified `README.md` 또는 새 `README.md` → 다른 agent가 작업한 흔적
- GitHub HEAD ≠ 로컬 HEAD → 푸시 필요
- origin이 `proofofplay/...` → mirror 푸시 시 sigco3111로 임시 변경

### Step 0.5 — AI 도구 캐시 .gitignore 추가 (NEW 2026-08-08)

```bash
# .gitignore 끝에 표준 패턴 추가
cat >> .gitignore <<'EOF'

# AI tool caches (oh-my-opencode, aider, etc.) — never commit
.omo/
.aider*
EOF
```

**왜**: oh-my-opencode 세션 캐시 (`.omo/`)와 aider AI 도구 캐시 (`.aider*`)는
**도구 임시 파일**로 절대 커밋하면 안 됨. mirror뿐 아니라 **모든 저장소 작업**에서
표준 추가 권장.

**검증**: `git status`로 `.omo/`가 untracked에서 사라졌는지 확인.

### Step 1~4 — 위의 4단계 우회 절차 그대로 적용

`.gitignore` 갱신 + 다른 agent 작업물 (한국어 README 등)이 working tree에 보존된 상태로
fresh init → 1 squash commit → force push. .gitattributes와 .omo는 무시됨.

### Step 5 — HEAD 검증 + origin 복원 (확장 2026-08-08)

```bash
# HEAD SHA 일치 확인
LOCAL=$(git -C /tmp/<repo>-fresh rev-parse HEAD)
REMOTE=$(gh api repos/sigco3111/<repo>/commits/main --jq '.sha')
[ "$LOCAL" = "$REMOTE" ] && echo "✅ 동기화 완료" || echo "❌ 불일치"

# 로컬 원본 폴더 origin 복원 (사용자가 다시 작업 가능)
cd ~/work/<repo>
git remote set-url origin https://github.com/proofofplay/<repo>.git
git remote -v  # origin이 proofofplay 가리키는지 확인

# 임시 디렉토리 정리
rm -rf /tmp/<repo>-fresh
rm -f /tmp/setup_<repo>_*.sh
```

**5단계 총 소요 시간**: 3~5분. 다른 agent가 작업한 mirror가 있을 때의 정형 워크플로.

---

## 🎯 결과의 한계 + 사용자 안내

### GitHub에 올라간 것

- ✅ 파일 트리: 모든 154K 파일 GitHub에서 보임
- ✅ LICENSE, README, 소스 코드, 셰이더, .gltf 등 텍스트 기반 자산
- ❌ PNG/MP4/SVG/GLTF 등 바이너리 — **LFS pointer 132B 텍스트로만** push됨

### raw URL로 받아보면

```bash
curl -sL https://raw.githubusercontent.com/sigco3111/<repo>/main/path/to/file.png -o /tmp/test.png
file /tmp/test.png
# → "ASCII text" 132 bytes
# → "version https://git-lfs.github.com/spec/v1..."
```

**GitHub API의 size는 LFS object의 실제 크기**(예: 1,542,934B)를 표시하지만, raw URL은 pointer 텍스트만 반환. 사용자가 헷갈릴 수 있음.

### 사용자 안내 (README 또는 메시지)

> 이 mirror는 Git LFS 우회로 푸시되었습니다. PNG/MP4/SVG/GLTF 등의
> 바이너리 자산은 모두 LFS pointer 텍스트로 저장되어 있어요.
> 실제 파일을 받으려면:
>
> ```bash
> git lfs install
> git lfs pull
> ```

---

## 🔗 연관 시나리오

### 시나리오 A — LFS object fetch가 가능한 경우

`git lfs install` 가능하고 LFS server 응답하면, 그냥 fetch 후 push가 정답:

```bash
brew install git-lfs  # 한 번
git lfs install
git lfs fetch --all  # 692MB → 5~30분
git push --mirror    # LFS object 포함 push
```

⚠️ 단, GitHub LFS quota (1GB 무료) 초과 위험. 큰 저장소는 신중히.

### 시나리오 B — LFS object 없이도 충분히 쓸 만한 경우

문서/코드만 필요하면 pointer만 받아도 됨. 이 skill의 4단계가 정답.

### 시나리오 C — 다른 agent가 같은 작업을 했는데 푸시 안 함 (3차 검증 2026-08-08)

**다른 세션/에이전트가 sigco3111 계정으로 작업 후 푸시하지 않은 흔적** (예: `git status`에 변경사항 + origin은 proofofplay)이 발견될 때:

1. **인증 + 상태 확인** (Step 0) — `gh auth status` + `git status` + `git log` + `git remote -v`
2. **AI 도구 캐시 .gitignore 추가** (Step 0.5) — `.omo/` + `.aider*` 표준 패턴
3. **4단계 우회 절차** (Step 1~4) — working tree의 다른 agent 작업물 보존되어 add -A로 자동 포함
4. **HEAD 검증 + origin 복원** (Step 5) — `LOCAL == REMOTE` 확인 + proofofplay로 복원 + 임시 정리

→ **mirror 사이클 5단계 정형** (위 섹션 참조). 3~5분 소요.

### 시나리오 D — 다른 GitHub 계정으로 작업한 mirror

`gh auth status`가 다른 계정을 보여주면, `gh auth login --with-token`으로 sigco3111 전환 후
5단계 진행. 인증 토큰은 `~/.hermes/secrets/github_token.txt`에 저장돼 있음.

---

## 📋 검증 체크리스트

푸시 후 GitHub에서 확인할 것:

```bash
# 1) HEAD SHA 변경 확인
LOCAL=$(git -C /tmp/<repo>-fresh rev-parse HEAD)
gh api repos/sigco3111/<repo>/commits/main --jq '.sha'
# 두 SHA가 일치해야 함

# 2) 파일 카운트 (truncated: true 면 1000+ 파일 OK)
gh api repos/sigco3111/<repo>/git/trees/<sha>?recursive=1 --jq '.tree | length'

# 3) LICENSE / README 존재
gh api repos/sigco3111/<repo>/contents/LICENSE --jq '.name'
gh api repos/sigco3111/<repo>/contents/README.md --jq '.name'

# 4) LFS pointer 다운로드 확인
curl -sL "https://raw.githubusercontent.com/sigco3111/<repo>/main/<path>.png" -o /tmp/test.png
file /tmp/test.png
# "ASCII text" 132 bytes 정상
```

---

## 🚨 안티패턴 (하지 말 것)

1. **squash 안 하고 원본 history 보존** → dangling object가 많으면 검증 부담 큼
2. **origin 복원 안 함** → 사용자가 로컬에서 `git push` 시 upstream 권한 없음 에러
3. **README에 LFS 우회 사실 안 명시** → 사용자가 실제 파일 없다고 항의
4. **`.gitattributes.original` 삭제** → 사용자가 LFS 복원 시 원본 추적 패턴 잃음
5. **GitHub LFS quota 무시** → 큰 저장소에서 push 자체가 거부됨
6. **`.omo/` 또는 `.aider*` 커밋** → AI 도구 임시 파일이 영구 저장소에 박힘. 모든 mirror/fork 작업에 `.gitignore` 표준 추가 필수
7. **다른 agent가 푸시 안 한 mirror 발견하고 일반 commit으로 push 시도** → "did not receive expected object" 에러로 막힘. 무조건 5단계 정형 (인증 + .gitignore + 4단계 우회 + HEAD 검증 + origin 복원) 따르기
