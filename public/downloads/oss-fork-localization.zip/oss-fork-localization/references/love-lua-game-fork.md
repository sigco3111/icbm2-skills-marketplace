# LÖVE/Lua 게임 Fork 세션 노트 (SNKRX-kr, 2026-07-21)

## 세션 개요

| 항목 | 값 |
|---|---|
| 원본 | a327ex/SNKRX (Steamworks 기반 LÖVE 11.x 오토배틀러 로그라이크) |
| 라이선스 | MIT (코드) / 자산별 별도 |
| fork 목표 | 한국어화 + 한글 폰트 + Steam shim + 창 크기 조정 |
| 환경 | macOS 26.5.2 (M4 Mac, Retina), brew lua 5.5 (luac 검증용) |
| 총 소요 | ~4시간 (UI 작업 8건 + 환경 함정 4건 디버깅) |
| git push | (사용자가 GUI 검증 후 결정) |

## 발견된 8가지 에러 → Fix 로그

### 에러 1: brew love Gatekeeper 차단
```
'hate'(를) 열지 못함 / Apple이 'love'에서 사용자의 Mac에 손상을 입히거나
사용자의 개인정보에 침범할 수 있는 악성 코드가 없음을 확인할 수 없습니다.
```
**원인**: brew cask love는 Apple Gatekeeper 공인 인증서 없음 (2026-09-01 deprecation 예정).
**Fix**: `xattr -dr com.apple.quarantine /Applications/love.app`
**교훈**: brew로 macOS GUI 앱 설치 시 Gatekeeper 해제 항상 동반.

### 에러 2: luasteam 모듈 not found
```
Error: engine/external/init.lua:7: module 'luasteam' not found
```
**원인**: SNKRX는 Steamworks SDK 바인딩(`luasteam`) 사용. brew love에는 포함 안 됨.
**Fix**: `engine/external/luasteam.lua` no-op shim + `init.lua`에서 `require(path .. ".luasteam")`으로 변경.
**교훈**: Steam 의존 LÖVE 게임 fork 시 **첫 단계**가 Steam shim 작성.

### 에러 3: UTF-8 decoding error (가장 흔한 LÖVE 한글 버그)
```
Error: engine/graphics/text.lua:139: UTF-8 decoding error: Not enough space
```
**원인**: `Text:parse()`가 `for i = 1, #text do c = text:sub(i, i)` — **바이트** 1개씩. 한글 3바이트 깨짐.
**Fix**: lead byte 분석으로 continuation 바이트 수 계산해 char 단위로 추출 (SKILL.md §4단계 참조).
**교훈**: LÖVE 엔진의 `Text:parse()`는 모든 CJK 게임에서 사전 fix 필수. 미리 안 하면 매번 한글 추가할 때마다 만남.

### 에러 4: runCallbacks nil
```
Error: engine/init.lua:149: attempt to call field 'runCallbacks' (a nil value)
```
**원인**: steam shim에 `M.runCallbacks` 미정의. main loop에서 매 프레임 호출됨.
**Fix**: `M.runCallbacks = function() end` shim에 추가.
**교훈**: shim 작성 시 원본 SDK의 모든 public API + main loop 콜백 다 찾아서 정의. `grep -r 'steam\.'`로 누락 확인.

### 에러 5: 'attempt to get length of local text (a number value)'
```
Error: engine/graphics/font.lua:54: attempt to get length of local 'text' (a number value)
```
**원인**: `Font:has_cjk`가 `if not text then return false` 가드 → 숫자 `0`이 truthy라 통과 → `#0` 크래시. 호출처는 `graphics.print_centered(cost, ...)`로 cost가 숫자.
**Fix**: 가드를 `type(text) ~= "string"`로 강화. `get_text_width`도 동일하게.
**교훈**: Lua에서 `if not x`는 `if x == nil or x == false`만 체크. `0`, `""` 모두 truthy. **type 가드는 항상 명시**.

### 에러 6: macOS 풀스크린 강제 변환 (3회 반복)
```
Error 없이 love . 실행 → 풀스크린 윈도우 열림
```
**원인**: `setMode(window_width, window_height, ...)` 호출 시 (a) M4 디스플레이와 해상도 일치, (b) `usedpiscale=true`로 Retina 자동 축소, (c) 이전 state.sx 비정상 값 중 하나가 발생 시 macOS가 풀스크린화.
**Fix 조합**:
- 비표준 사이즈 (1280x720) — 표준 해상도 회피
- `t.window.usedpiscale = false` — DPI 매핑 비활성
- `state.sx/sy` 범위 가드 (0.5~3)
- `setMode` 옵션에 `fullscreen=false, borderless=false, display=1`

**교훈**: M4 Mac에서 LÖVE 게임 윈도우 크기 = 4가지 함정 동시 고려. 헤드리스에서 검증 불가, **사용자 스크린샷 필수**.

### 에러 7: window_width arithmetic on string value
```
Error: engine/init.lua:59: attempt to perform arithmetic on local 'window_width' (a string value)
```
**원인**: `'max'` 체크를 먼저 → `'half'` 문자열이 window_width에 박힘 → 그 다음 `'half' / 2` 크래시.
**Fix**: `'half'`를 `'max'` 체크보다 **먼저** 처리. 또는 `'half'`/`'max'` 모두 같은 if에서 제외.
**교훈**: 문자열 키워드 처리 시 **순서가 의미**. 검증 단계 추가 시 이전 단계가 박은 값과 충돌 가능.

### 에러 8: 좌표계 vs 윈도우 크기 mismatch (가장 흔한 UI 실수)
```
창만 커지고 오브젝트는 그대로 작게
```
**원인**: SNKRX는 `setMode(480*sx, 270*sy)` 같은 호출에서 **480x270 좌표계 하드코딩 가정**. `game_width=1280`으로 키워도 좌표계는 480x270 그대로 → sx=1.0 → 모든 게 그대로.
**Fix**: `game_width=480, game_height=270` (원본 좌표계) **그대로** 두고 `window_width=1280`으로 키워서 sx = 1280/480 ≈ 2.67 자동 비례 확대.
**교훈**: SNKRX/Godot 같은 게임의 좌표계 = **수정 대상 아님**. 스케일 = `window/coord`. 큰 UI 원하면 window만 키워.

## 검증 워크플로 (헤드리스)

```bash
# 1. luac로 syntax 검증
for f in shared.lua main.lua mainmenu.lua buy_screen.lua arena.lua enemies.lua player.lua \
         engine/graphics/font.lua engine/graphics/text.lua engine/graphics/graphics.lua \
         lang/ko.lua engine/external/luasteam.lua engine/init.lua; do
  luac -p "$f" 2>&1
done

# 2. love 백그라운드 실행 + 프로세스 생존 확인
love . > /tmp/love_run.log 2>&1 &
LOVE_PID=$!
sleep 5
ps -p $LOVE_PID -o pid,stat,command
# STAT=Ss = 메인 루프 진입. exit_code != 0 = 크래시.
cat /tmp/love_run.log  # stderr 비어있음 = require/load 에러 없음

# 3. kill
kill -9 $LOVE_PID
```

**한계**: 헤드리스에서 화면 검증 불가. GUI 띄워야 확인 가능 → **사용자에게 스크린샷 위임**.

## 최종 설정 (동작 확인됨)

### main.lua
```lua
function love.run()
  return engine_run({
    game_name = 'SNKRX',
    window_width = 1280,    -- 비표준 사이즈 (macOS 풀스크린 회피)
    window_height = 720,
    game_width = 480,       -- SNKRX 좌표계 (수정 X)
    game_height = 270,
  })
end
```

### conf.lua
```lua
function love.conf(t)
  t.version = "11.3"
  t.window.width = 480
  t.window.height = 270
  t.window.vsync = 1
  t.window.msaa = 0
  t.window.resizable = true
  t.window.usedpiscale = false  -- Retina DPI 매핑 비활성
end
```

### engine/init.lua setMode (모든 호출)
```lua
love.window.setMode(w, h, {
  vsync = config.vsync, msaa = msaa or 0,
  display = 1, fullscreen = false, borderless = false, resizable = true,
})
```

## 다음 세션 위임 가이드

A 단계 (한국어화) 완료 후 B~D 단계로 가는 경우:

| 작업 | 예상 시간 | 의존성 |
|---|---|---|
| A 미완료 부분 (steam_button 위치, 영웅 이름 패턴) | 30분 | ko.lua 키 추가 + T() 호출 |
| B 새 영웅/클래스 + 시너지 | 2~4시간 | A 완료 + 모드팩 패턴 확장 |
| C 신 게임 모드 (보스 레이드) | 3~5시간 | B 완료 (콘텐츠 베이스) |
| D 풀 자동위임 (sango 결정 큐) | 2~3시간 | A~C 완료 (UI 검증 상태) |

**B 시작 전 추천**: 영웅/적 이름 패턴 파악 (`player.lua`/`enemies.lua`의 `name = 'log'` 키 → ko.lua의 `hero_rogue = '로그'` 매핑 후 코드에서 사용).

## 라이선스 표시

`MODIFIED.md` 작성 완료:
- 원본: a327ex/SNKRX (MIT)
- fork: sigco3111/snkrx-clone (예정)
- 변경: 한국어 UI + 모드팩 + Steam shim + macOS 호환

## 메모리 갱신 후보

사용자 선호 (이 세션에서 새로 확인된 것):
- macOS 풀스크린 함정 → `oss-fork-localization` §LÖVE/Lua에 이미 포함. 메모리 갱신 불필요.
- T() 패턴 → skill에 포함. 메모리 갱신 불필요.

## 참고: SKILL.md 메타데이터 변경

기존 tags: `[oss, fork, korean, ...]`
추가: `lua`, `love2d`, `utf-8-iteration`, `cjk-font-fallback`, `macos-retina-fullscreen`, `steam-shim`, `t-function-pattern`