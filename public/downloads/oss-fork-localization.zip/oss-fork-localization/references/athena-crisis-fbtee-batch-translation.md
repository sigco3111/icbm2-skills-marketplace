# Athena Crisis fbtee 배치 번역 파이프라인 — 실전 노트 (2026-07-27)

`scripts/generate_ko_translations.py` 작성 + 실행을 통해 검증한 fbtee 입력 파일 생성 + 번역 provider 선택 + 출력 정밀도 노트. `athena-crisis-autobattle-and-fbtee.md`(워크플로 + AI 패턴)와 짝.

## 1. fbtee translate가 기대하는 정확한 입력 스키마

`translate-BBnIj-zQ.mjs` + `translateUtils-pKQpltoQ.mjs` 의 `processFiles`/`processTranslations` 코드에서 다음이 강제된다:

```json
{
  "fb-locale": "ko_KR",
  "translations": {
    "<leaf_hash>": {
      "tokens": {},
      "types": {},
      "translations": [{
        "translation": "번역된 문자열",
        "variations": []
      }]
    }
  }
}
```

### 사실 검증 디테일 (fbtee@3.0.1 source)

| 필드 | 동작 | 함정 |
|---|---|---|
| `fb-locale` | `localeIdentifier.f_BnHCjm.mjs`의 `getLocaleIdentity()` → `Intl.getCanonicalLocales(...)` 로 bcp47 정규화. `ko_KR` 입력 → `"ko-KR"`. `fb-locale`은 입력 시 그대로, 출력 직전 `outputLocaleStyle` 변환됨. | legacy/bcp47 둘 다 OK이지만 출력명이 달라지므로 의도적으로 `--output-locale-style preserve` 사용. |
| `<leaf_hash>` | `translateUtils-pKQpltoQ.mjs`의 `processTranslations`가 `group.translations[hash]`를 직접 lookup. | **존재하지 않는 hash는 무시**, 모든 source leaf hash가 entry가 있을 필요 없음. 누락된 hash는 build 시 원문 fallback. |
| `tokens`/`types` | `TranslationData.fromJSON(json.tokens, json.types, json.translations)`이 그대로 통과. 비워두면 internal이 원본 사용. | placeholder 보간이 있는 경우에만 채워야 함. 우리 fork는 desc-only 텍스트 위주라 거의 비워둠. |
| `translations[].translation` | `TranslationBuilder.build()`가 single variation이면 그대로 사용. | 빈 문자열도 OK — 단, 빌더가 fallback 호출해서 원문으로 채울 수도 있음. |
| `translations[].variations` | plural/gender 변형용. 우리 fork는 1,535 leaf 중에 7개 parent (153, 1477, 7 등) 만 변형 보유. | 단일 variation이면 `[]`로 두면 됨. 변형이 여러 개인 경우 array index 순서 주의 (fbtee 런타임이 array index로 매칭). |

### source_strings.json과의 관계

- `phrases[i].hashToLeaf[hash]` 키 → 출력 entry의 top-level key
- `phrases[i].hashToLeaf[hash].desc` → 번역 안 함 (영어 그대로 유지, translator hint)
- `phrases[i].hashToLeaf[hash].text` → 번역 대상
- `phrases[i].jsfbt.m` (variation metadata) → fbtee가 leaf hash를 어떻게 변형 매핑에 쓸지 결정. 우리는 신경 안 써도 됨 (leaf hash key 방식만 알면 충분).
- `childParentMappings` (예 `{"7": 6, "153": 152, ...}`) → 변형-부모 표시일 뿐, leaf hash 충족 여부와 무관. **모든 leaf hash는 독립적으로 번역 entry 필요**.

### 발동 명령

```bash
cd ares
pnpm fbtee:translate -- \
  --translations ../ko_KR_translations.json \
  --output-locale-style preserve
```

→ `ares/src/generated/ko_KR.json` 작성. `AvailableLanguages.tsx`의 `ko_KR` 매핑은 이미 등록돼 있어 추가 작업 불필요.

## 2. 풀 배치 번역 provider 비교표 (1,500+ 짧은 게임 텍스트용)

| Endpoint | 비용 | 2026-07 검증 상태 | 함정 |
|---|---|---|---|
| `translate.googleapis.com/translate_a/single?client=gtx` | 무료 | ❌ 302 → `www.google.com/sorry` CAPTCHA | IP/헤더 기반 차단 강화됨 |
| `api.mymemory.translated.net/get?q=...&langpair=en\|ko` | 무료, 5000 chars/day | ⚠️ 한도 너무 낮음 | 짧은 게임 텍스트 1,500개 × 평균 30 chars = 45K chars → 9일 필요 |
| `libretranslate.com/translate` | 무료 | ❌ `Visit https://portal.libretranslate.com to get an API key` | 키 강제 |
| `translate.argosopentech.com/translate` | 무료 | ⚠️ 자주 502/503 | 신뢰성 부족 |
| `translate.terraprint.co/translate` | 무료 | ⚠️ 502 | 가끔만 살아있음 |
| **`translate.fedilab.app/translate`** (LibreTranslate 공개 인스턴스) | 무료, 사실상 무제한 | ✅ 검증 완료 | 가끔 502 → retry/backoff |

**권장**: `translate.fedilab.app/translate`. POST `{"q": ["text1","text2",...], "source":"en","target":"ko","format":"text"}` → `{"translatedText":["ko1","ko2",...]}`. 라이브러리 의존성 0개 (`urllib.request`로 충분).

### 품질 노트

- **컨텍스트가 있는 phrase (10자+ + 보통 명사구)**: 정확도 양호. UI 라벨/버튼 텍스트는 5–10% polish 필요할 수 있지만 fbtee translate 출력은 통과시킴.
- **단일 단어 (1–3자)**: 정확도 들쭉날쭉. 예: `"Automatic"` → `"제품정보"` (noise). `"Default"` → `"기본 정보"` (noise). 이건 게임 컨텍스트가 없으면 LibreTranslate가 부정확. **대응**: 단일 단어는 수동으로 사전을 만들어 override하거나, desc를 추가 prompt로 활용. 본 세션에서는 자동 fallback으로 두고 후속 세션에서 polish.
- **변수가 있는 phrase**: LibreTranslate가 `{name}` 등을 그대로 보존. 완벽.

## 3. 생성기 스크립트 핵심 패턴

`scripts/generate_ko_translations.py`는 다음 원칙으로 작성 (재현 가능한 패턴):

1. `source_strings.json` 로드 → `hashToLeaf` 키를 모두 추출 → `(hash, text)` 리스트 만들기 (desc는 보존만, 번역 X).
2. 텍스트가 비어있지 않은 entry만 배치 대상 (`if not text.strip(): skip`).
3. 30개씩 BATCH_SIZE로 잘라 HTTP POST → exponential backoff 재시도 (최대 4회).
4. 실패한 entry는 **영문으로 fallback** (에러로 죽지 않게) — stderr에만 경고. 후속 LLM polish 세션에서 채울 수 있도록.
5. 배치 간 0.4s 슬립 → rate limit 회피. 1,500개 약 50배치 ≈ 20–60초.
6. 출력 JSON 구조는 fbtee 입력 스키마 정확히 따르기.

코드 템플릿: `templates/generate_ko_translations.py.tpl`.

## 4. 실행 사이클 노트 (이번 세션 실측)

- **소요 시간**: 1,535 hash × 30 배치 ≈ 52회 HTTP call. 평균 0.4–1s/call → 30–60s 예상. 실제 1,500개 실제 운영 시 network variable이라 5분까지 가능.
- **background 실행 권장**: `terminal(background=true, notify_on_complete=true)`. 동기 실행은 다른 작업을 멈춤.
- **진행 중 검증**: stdout에 `batch N..M (count items, total calls)` 출력 → 한 줄씩 누적되며 진행률 표시. hermes에서 `process(action='poll')`로 모니터링.
- **완료 후 다음 단계**:
  1. `pnpm exec fbtee translate --source-strings source_strings.json --translations ko_KR_translations.json --output-dir ares/src/generated --output-locale-style preserve`
  2. `cd offline && pnpm exec vite ./offline/` (background)
  3. UI에 `한국어` 토글 → 모든 라벨 한국어 표시 검증

## 5. 함정 vs 해결 모음

| 증상 | 원인 | 해결 |
|---|---|---|
| `pnpm fbtee:prepare` 가 `ENOENT source_strings.json` | 이 프로젝트는 root에 source_strings.json 미커밋 | `pnpm fbtee` (collect → translate) 사용. 또는 직접 `--source-strings ../source_strings.json` 으로 `pnpm fbtee:translate` 호출 |
| `fbtee translate` 출력 파일명이 `ko-KR.json` | 기본 `--output-locale-style bcp47` | `--output-locale-style preserve` 추가 |
| LibreTranslate가 단일 단어를 product info로 번역 | 컨텍스트 없음 | 1) 수동 override dictionary, 2) desc 컨텍스트를 prompt로 합쳐 다중 호출, 3) 후속 LLM polish 세션 |
| `git push` 직후 PR 충돌 | 표준 GitHub flow — 한국어 fork라서 흔함 | `git fetch upstream && git rebase upstream/main` 후 push |
| TypeScript `unit.health <= 50` 처럼 쓰고 싶은데 unit 클래스 메서드? | health는 `Entity.health` 직접 public field (getter 아님) | 직접 비교 OK. `athena/map/Unit.tsx:91, 126, 416` |

## 6. 이 워크플로 적용 가능성

다른 fbtee 기반 OSS 프로젝트 (e.g., Meta fbtee 공식 demo, react-native-localize와 결합된 fork)에서도 동일한 fb-locale/translations 스키마를 따른다. 따라서:

- `source_strings.json` → `ko_KR_translations.json` 변환 스크립트는 어떤 fbtee 프로젝트든 재사용 가능
- LibreTranslate (`translate.fedilab.app/translate`)는 영어→한국어 외 다른 언어 쌍에도 동작 (일본어, 중국어, 베트남어 시도 결과 모두 양호)
- `--output-locale-style preserve` + AvailableLanguages의 legacy locale identifier 매칭은 Meta fbtee 프로젝트 전반의 표준 패턴
