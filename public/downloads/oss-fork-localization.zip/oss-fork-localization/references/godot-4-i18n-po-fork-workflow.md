# Godot 4 addons 한국어화 — POT/.po Fork Workflow

> **2026-07-28 godot_dialogue_manager 실측**. 166 msgid 한국어화 + Godot 4.7 검증 + `gh` fork 분해 시퀀스. 일반화 가능한 패턴.

## 1. Fork 3단계 분해 (gh CLI hang 회피)

`gh repo fork <repo> --clone` 단독 실행은 zsh 환경에서 "Press RETURN"에서 멈춤. **3단계로 분해**:

```bash
# 1) GitHub에 fork 생성
gh repo fork nathanhoad/godot_dialogue_manager  # URL만 출력

# 2) 로컬 clone (--depth=1로 시간 절약)
git clone --depth=1 https://github.com/sigco3111/godot_dialogue_manager.git

# 3) upstream remote 등록 (PR 머지 후 sync 위함)
cd godot_dialogue_manager
git remote add upstream https://github.com/nathanhoad/godot_dialogue_manager.git
git remote -v  # origin + upstream 둘 다 표시 확인
```

**zsh `.zshenv` .cargo/env 부재 에러 회피**: `bash -c` 래핑 또는 `unset CARGO_ENV` 후 실행.

## 2. i18n 디렉토리 + locale loader 자동 로드 검증

Godot addon은 **두 가지 패턴**으로 locale을 로드:

| 패턴 | 예시 | 자동 로드? |
|---|---|---|
| `addons/<name>/l10n/<locale>.po` 하드코딩 경로 | godot_dialogue_manager (`constants.gd:223`이 `l10n/<locale>.po` 직접 참조) | ✅ `.po` 파일만 두면 됨 |
| `project.godot`의 `[internationalization] locale/translations=PackedStringArray(...)` | Godot 표준 | ❌ `.po` 또는 `.translation` 직접 등록 필요 |

**판별 명령**:
```bash
# 1) locale loader 코드 경로 확인
grep -rn "l10n\|locale" addons/<name>/utilities/ --include="*.gd" | head -10
grep -rn "TranslationServer\|Translation" addons/<name>/utilities/ --include="*.gd" | head -10

# 2) project.godot [internationalization] 섹션
grep -A 5 "\[internationalization\]" project.godot
```

**`locale/language_filter` vs `locale_filter_mode`** (자주 혼동):
- `language_filter=["de","en"]`: 에디터가 **표시할 locale 후보군**. 이건 *기본 필터*라 ko.po가 있어도 자동 차단 안 함.
- `locale_filter_mode=0|1|2`: 0=show all, 1=show only selected, 2=show best match. `1`이면 `language_filter`에 한국어 추가 필요.

→ **모드 1 + 한국어 미추가**: 사용자가 시스템 locale을 ko_KR로 설정해도 에디터 balloon이 안 보일 수 있음. **PR에 language_filter=["de","en","ko"] 추가** 검토.

## 3. POT 파싱 — escape 시퀀스 함정

**나쁜 regex** (함정):
```python
import re
ids = re.findall(r'msgid "([^"]*)"', pot)
# → C-string `\\"` 또는 multi-line msgid가 다음 msgid로 잘못 매칭됨
# → "missing" 보고 → dict에서 잘못된 키 찾게 됨
```

**올바른 regex** (verified):
```python
ids = []
for m in re.finditer(r'^msgid\s+((?:"(?:[^"\\]|\\.)*"\s*)+)', pot, re.MULTILINE):
    block = m.group(1)
    parts = re.findall(r'"((?:[^"\\]|\\.)*)"', block, re.DOTALL)
    ids.append(''.join(parts))
# header msgid '' 제외
ids = [i for i in ids if i != '']
```

## 4. .po 빌더 — escape 필수

`.po` 출력 시 msgid/msgstr **둘 다** escape 필수 (`\`와 `"`):
```python
def esc(s: str) -> str:
    return s.replace('\\', '\\\\').replace('"', '\\"')

# 1. POT에서 추출한 id가 unescape된 상태
# 2. dict에서 한국어 msgstr 찾기
# 3. .po 출력 시 esc() 적용
```

**검증 명령**:
```python
assert len(ids) == len(ko_dict)  # 100% 매칭 확인
assert sum(1 for _ in re.finditer(r'^msgid "', po_content, re.MULTILINE)) - 1 == len(ids)
```

## 5. 번역 스타일 가이드 (UI 메뉴/에러/상태)

| POT 패턴 | 한국어 스타일 | 예시 |
|---|---|---|
| 단일 단어 메뉴/버튼 | 짧은 명사/동사 2-4자 | `Insert` → "삽입", `Clear` → "지우기", `Sponsor` → "후원" |
| `xxx.find_yyy` | "yyy에서 xxx" 또는 "xxx" | `search.find` → "찾기", `find_in_files` → "대화에서 찾기..." |
| `xxx.error_yyy` | "에러: yyy" 또는 자연스러운 한국어 | `errors.empty_cue` → "빈 큐" |
| `runtime.dialogue_balloon_missing_start_method` | "대화 풍선에 start 메서드가 없음" (직역) | - |
| `{placeholder}` | 그대로 보존 (Godot이 치환) | `"{path}"에 저장할까요?` |
| 다중 단어 상태 | 띄어쓰기 존중 | `Auto advance` → "자동 진행" |
| 약어 보존 | BBCode, CSV, UUID, JSON, ID 그대로 | "BBCode", "ID 접두사" |

**리소스 위치**:
- 메뉴/도구 버튼 → `addons/.../l10n/translations.pot` 1차
- balloon 본문 사용자 대사 → 게임 측 `.dialogue` 파일 (addon이 아니라 게임 콘텐츠, **PR 범위 밖**)
- 런타임 에러 → `runtime.*` 키 (게임 코드에서는 `tr("runtime.no_resource")` 식 호출)

## 6. Godot 4.7 headless 검증 — .po 로드 확인

**`TranslationServer.get_loaded_locales()`는 `-s` script 모드에서 항상 `[]`**. 수동으로 .po를 load 후 `get_message()` 호출해야 검증 가능.

**스모크 테스트 스크립트** (warning-as-error 우회, 모든 변수 타입 명시):
```gdscript
extends SceneTree
func _init() -> void:
    var tr: Translation = load("res://addons/<name>/l10n/ko.po")
    print("loaded tr:", tr, "locale:", tr.locale if tr else "n/a")
    if tr:
        var keys: PackedStringArray = ["Translations", "Insert", "History", "Clear"]
        for i: int in keys.size():
            var k: String = keys[i]
            var v: String = tr.get_message(k)
            print("%s -> %s" % [k, v])
    quit()
```

```bash
godot --headless -s /tmp/smoke.gd
# 출력: "locale:ko" + "Translations -> 번역" 식
```

**파싱 시 주의**:
- `for k in dict` → `warning: for iterator variable has no static type` → `for i: int in keys.size(): var k: String = keys[i]`
- `var x = ...` → `var x: Type = ...` 명시
- `func _init():` → `func _init() -> void:`

## 7. Godot 첫 import의 project.godot 자동 변경 — PR 분리 필수

`godot --headless --editor --quit-after 2`로 한 번 import하면:

```diff
- config/features=PackedStringArray("4.7", "C#")
+ config/features=PackedStringArray("4.7")
+ locale/translations_pot_files=PackedStringArray("res://tests/main.dialogue", ...)
```

**PR에 섞으면 안 됨** — ko.po만 single-file diff로 보내야 함:
```bash
git status --short  # project.godot modified, ko.po untracked 확인
git restore project.godot  # 원본 복원
git add addons/<name>/l10n/ko.po
git diff --staged --stat  # ko.po 단일 파일만 스테이지
```

## 8. PR 작성 가이드 (외부 PR 승인율 90%+ 케이스)

`godot_dialogue_manager` 외부 PR 18개 중 16개 MERGED, 2개 CLOSED (단순 중복). PR 머지율을 높이는 패턴:

- **단일 목적**: locale 추가만, 다른 변경 금지
- **이름 패턴 일치**: 다른 locale(`.po`)과 동일 파일명 (`ko.po`)
- **헤더 일치**: `Last-Translator`, `Language-Team`, `X-Generator` 등 기존 locale과 동일 형식
- **자릿수만 바꾸지 않기**: zh가 6,500자면 ko도 비슷한 자릿수. 11KB는 OK
- **첫 PR은 draft로**: 메인테이너가 안정성 검토 가능
- **본인/포크 링크 명시**: PR 본문에 "Forked from sigco3111:godot_dialogue_manager" + 한국어 사용자에게 미치는 영향

## 9. 실측 작업 통계 (2026-07-28)

| 항목 | 값 |
|---|---|
| POT msgid 수 | 166 |
| 한국어 msgstr 완성 | 166/166 (100%) |
| ko.po 크기 | 11,065 bytes (zh 8,136 / zh_TW 8,129 대비 1.4배) |
| fork → 로컬 작업 | 5분 (fork + clone + upstream 등록) |
| 166 entries 번역 작성 | 15분 (dict 구성 + .po 생성) |
| Godot 검증 | 5분 (smoke script + 수동 load) |
| 외부 PR 가능성 | 90%+ (기존 18개 중 16개 MERGED) |
| **총 소요** | **25-30분** (검증 포함) |

## 10. 다음 워커가 이걸 다시 안 헤매게

- **POT 파싱 시** `r'msgid\s+((?:"(?:[^"\\]|\\.)*"\s*)+)'` + parts concat 패턴 복사
- **.po 빌더** `esc()` 함수 100% 적용, 헤더는 기존 .po에서 그대로 복사
- **Godot headless 검증** 위 스모크 스크립트 그대로 사용, warning-as-error 대응
- **PR 직전** `git restore project.godot` + `git status --short` 단일 파일 diff 확인
