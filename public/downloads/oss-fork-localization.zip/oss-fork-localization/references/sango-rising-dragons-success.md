# 🏯 OSS 게임 fork-한글화 성공 사례: sango-rising-dragons-kr (2026-07-20)

> Wesnoth 90분 낭비 후 사용자가 "일단 가져와서 한글화를 진행한 후 실행해보자" → **ryantsai/sango-rising-dragons** 선택 → **6시간 만에 빌드 + 한글화 + 푸시 + 실행 검증 완료**.

이 레퍼런스는 **다른 게임 fork-한글화 시 복사용**으로 가치가 큼. 모든 패턴은 모듈화되어 있어 sango-rising-dragons가 아닌 다른 게임에도 그대로 적용 가능.

## 왜 성공했나 (Wesnoth 실패 대비)

| 단계 | Wesnoth-kr (실패) | sango-rising-dragons (성공) |
|------|-------------------|-------------------------------|
| **1. 빌드 시스템 분류** | ❌ 안 함 (C++ scons) | ✅ 먼저 함 (TypeScript Vite) |
| **2. 모드팩 가능성 확인** | ❌ PO gettext 시스템 | ✅ `public/data/{pack}/*.json` |
| **3. 5분 빌드 검증** | ❌ 90분 낭비 후 실패 | ✅ 2초 npm install |
| **4. 데이터 구조 파악** | ✅ 잘 함 | ✅ 잘 함 |
| **5. 모듈화** | ✅ 잘 함 | ✅ 잘 함 (1,978 LOC TS) |
| **6. UI 텍스트 vs 데이터 분리** | ⚠️ 혼재 | ✅ 명확히 분리 |

**결론**: **빌드 시스템 분류가 가장 중요한 첫 단계**. 사용자 요청 받자마자 즉시 분류 → 🟢/🟡/🟠이면 진행, 🔴/⚫이면 사전 검증.

## 5단계 빌드 환경 분류

| 분류 | 빌드 도구 | 빌드 시간 | macOS 호환성 | 사례 |
|------|----------|----------|--------------|------|
| 🟢 **즉시 성공** | `npm`/`yarn` (Vite, Next.js) | 2초~5분 | ✅ 네이티브 | **sango-rising-dragons** (TypeScript/Phaser 3, ✅ 성공) |
| 🟡 **Java/Gradle** | `./gradlew` | 30초~5분 | ✅ 안정 | triplea, FreeCol |
| 🟠 **Rust/cargo** | `cargo build` | 1~5분 | ✅ 안정 | zemeroth, veloren |
| 🔴 **C++ scons/CMake** | `scons`/`make` | 30분~1시간 | ⚠️ 환경 의존 | **Wesnoth** (Boost/SDL 함정, ❌ 90분 낭비) |
| ⚫ **C#** | `dotnet`/`mono` | 1~5분 | ⚠️ mono 의존 | RTK2020-CORE |

**즉시 적용 규칙**: 사용자가 "한국어화 + 실행" 요청 시 **첫 응답에서 빌드 시스템 분류**:
- 🟢/🟡/🟠 → 진행
- 🔴/⚫ → `references/build-environment-preflight-check.md` 적용 + 4-옵션 제시

## 후보 선정 절차 (5분)

**선정 이유 (sango-rising-dragons 경우)**:
- **Star 1이지만 게임이 완성** (README에 "전략 레이어 + 전술 전투 + 자동저장 + 11개 모드팩" 명시)
- **TypeScript + Phaser 3** → 5단계 분류상 🟢 즉시 성공
- **Phaser 3 런타임** + **Vite 6 빌드** = Mac 네이티브 빌드 환경 함정 0
- **mod-pack 시스템** (`public/data/ko/`) — 원본 건드리지 않고 한국어 오버레이 가능

**검증 절차**:
1. `git clone --depth 1 https://github.com/{owner}/{repo}`
2. `cd {repo} && npm install` — **2초** 만에 17 패키지 설치
3. `npm run dev` — HTTP 200, 5분 내 실행 확인

## 작업 시간 (실측)

| 단계 | 시간 | 비고 |
|------|------|------|
| 클론 + 빌드 검증 | 5분 | npm install 2초, dev 서버 즉시 200 |
| 데이터 분석 (6개 JSON) | 10분 | Python 파서로 entry 수 + 카테고리 분류 |
| `ko/` 모드팩 생성 | 30분 | cities/officers/factions/events/items/skills 6개 파일 |
| `manifest.json` 업데이트 | 1분 | `{"packs": ["ko", "base"]}` |
| TS UI 한자→한국어 변환 | 60분 | 4개 파일 (hud.ts, main.ts, state.ts, scenes/*.ts) |
| HTML lang/title/폰트 | 10분 | `lang="ko"`, Noto Sans KR |
| 빌드 + Playwright 검증 | 10분 | 2.2초 빌드, 스크린샷 4장 |
| `play.sh` 스크립트 | 5분 | 4-옵션 (dev/serve/build/open) |
| README + GitHub push | 20분 | v0.1 → v0.2 한글화 보강 |
| **합계** | **~2.5시간** | (Wesnoth 90분 vs sango 2.5시간) |

## ⭐ 모드팩 (data override) 워크플로우

원본의 `public/data/ko/` 패턴이 fork-친화적 모드팩 시스템의 정석:

```
public/data/
├── manifest.json           # {"packs": ["ko", "base"]}  ← ko 우선
├── base/                   # 원본 (건드리지 않음)
│   ├── cities.json
│   ├── officers.json
│   ├── factions.json
│   └── ...
└── ko/                     # 한국어 모드팩
    ├── cities.json         # 같은 id 필드만 덮어씀
    ├── officers.json
    └── ...
```

**mergeById 로직 (원본 `content.ts`)**:
```typescript
function mergeById<T extends { id: string }>(base: T[], extra: T[]): T[] {
  const map = new Map(base.map((e) => [e.id, e]));
  for (const e of extra) map.set(e.id, { ...map.get(e.id), ...e });
  return [...map.values()];
}
```

**⚠️ CRITICAL: 모드팩은 base의 모든 필드를 덮어쓸 필요 없음**. `{id, name}` 만 있어도 base의 다른 필드 유지. **단, choices 배열 같은 nested field는 base의 전체 배열을 덮어씀** — base choices 2개 중 ko에 1개만 있으면 ko의 1개만 적용됨.

**실제 버그 사례 (2026-07-20)**: ko/events.json에 `intro`의 choices 1개만 번역 → base의 2번째 choice 사라짐. **해결: 모든 choices를 ko에 복사 후 label만 번역**.

**표준 생성 워크플로**:
```python
import json
from pathlib import Path

base_dir = Path('public/data/base')
ko_dir = Path('public/data/ko')
ko_dir.mkdir(exist_ok=True)

# 각 JSON 파일별로
for fname in ['cities.json', 'officers.json', ...]:
    with open(base_dir / fname) as f:
        base_data = json.load(f)
    
    # ko 버전: id + 번역된 필드만
    ko_data = []
    for item in base_data:
        ko_item = {'id': item['id']}
        for key in TRANSLATABLE_FIELDS[fname]:
            if key in item:
                ko_item[key] = translate(item[key])
        # choices는 배열 통째로 복사 + label만 번역 (CRITICAL)
        if 'choices' in item:
            ko_item['choices'] = [
                {**ch, 'label': translate(ch['label'])} for ch in item['choices']
            ]
        ko_data.append(ko_item)
    
    with open(ko_dir / fname, 'w', encoding='utf-8') as f:
        json.dump(ko_data, f, ensure_ascii=False, indent=2)

# manifest.json 업데이트
with open('public/data/manifest.json') as f:
    manifest = json.load(f)
if 'ko' not in manifest['packs']:
    manifest['packs'] = ['ko'] + manifest['packs']
with open('public/data/manifest.json', 'w') as f:
    json.dump(manifest, f, ensure_ascii=False, indent=2)
```

**장점**:
- 원본 업데이트 시 `git pull upstream`만으로 자동 반영 (id 동일)
- 한국어 패치만 깔끔하게 분리
- 다른 모드팩 추가 가능 (예: 일본어, 베트남어) — 같은 패턴
- 새 콘텐츠 추가도 `mypack/` 모드팩으로 분리 가능

## ⭐ `play.sh` 실행 스크립트 표준 패턴

게임 fork 시마다 사용자가 "실행은 어떻게 하지?" 물음 → **표준 4-옵션 스크립트**로 즉시 응답.

```bash
#!/bin/bash
# {game-name} 실행 스크립트 (Mac/Linux)
set -e
cd "$(dirname "$0")"
PORT="${PORT:-8080}"

case "${1:-serve}" in
  dev)    # Vite/Next.js 개발 서버 (HMR)
    npm run dev
    ;;
  serve)  # 정적 빌드 서빙 (가장 안정, 기본)
    [ ! -d dist ] && npm run build
    python3 -m http.server "$PORT" --directory dist
    ;;
  build)  # 정적 빌드만
    npm run build
    ;;
  open)   # Safari로 dist/index.html 열기
    [ ! -d dist ] && npm run build
    open "dist/index.html"  # macOS
    # xdg-open "dist/index.html"  # Linux
    ;;
esac
```

**왜 serve가 가장 안정적인가**:
- `file://` 프로토콜에서 `fetch()`가 일부 제한될 수 있음 (게임 데이터 로드 실패)
- `python3 -m http.server`는 Mac/Linux 모두 사용 가능
- port 8080 default, `PORT=3000 ./play.sh serve`로 변경 가능

**GitHub push 시 반드시 포함**:
```bash
chmod +x play.sh
git add play.sh
git commit -m "Add play.sh 실행 스크립트"
```

## ⭐ `gh repo create` 원격 origin 실패 함정

**증상**:
```bash
$ gh repo create sigco3111/repo --public --description "..." --source=. --remote=origin --push=false
# 출력: https://github.com/sigco3111/repo (성공으로 보임)
# X Unable to add remote "origin"  ← 경고
# git push 시: 404 Not Found
```

**원인**: `--source=.` + `--remote=origin` 조합이 가끔 origin 자동 추가에 실패. `gh`는 저장소 생성은 성공했지만 remote 추가 실패를 **경고만** 출력하고 성공 표시.

**해결 (2단계 검증)**:
```bash
# 1. 저장소 생성 (--source=. 또는 --push=false 안전)
gh repo create sigco3111/repo --public --description "..." --source=. 2>&1 | tail -5

# 2. 즉시 HTTP 검증 (404면 실패)
curl -s -o /dev/null -w "HTTP %{http_code}\n" "https://api.github.com/repos/sigco3111/repo"
# HTTP 200 = OK, 404 = 다시 시도

# 3. remote 강제 설정 (필요 시)
git remote remove origin 2>&1 || true
git remote add origin https://github.com/sigco3111/repo.git
git remote -v  # 검증
```

**즉시 적용 규칙**: `gh repo create` 후 **반드시 curl로 200 확인** → 404면 remote 재설정. **절대 출력만 신뢰하지 말 것**.

## sango-rising-dragons 한글화 통계

| 항목 | 수치 |
|------|------|
| 도시 | 20개 (100%) |
| 장수 | 49명 (100%) |
| 진영 | 11개 (100%) |
| 이벤트 | 12개 (100%) |
| 아이템 | 5개 (100%) |
| 스킬 | 7개 (100%) |
| UI 한자→한국어 | 50+ 패턴 (hud.ts, main.ts, state.ts, scenes/*.ts) |
| 추가 콘텐츠 | 진영 symbol/slogan, 장수 alias, 도시 desc |

**v0.2 보강에서 추가한 콘텐츠** (풍성화):
- 모든 이벤트 choices에 효과 설명 (예: "연맹에 가담한다 (금 +500, 전 장수 경험치 +60)")
- 4개 이벤트의 2번째 choice 추가
- 인트로 모달 3단락 텍스트
- 진영 `symbol` (위/촉/오 한자) + `slogan` (시그니처 한마디)
- 장수 `alias` (별칭: 패왕/맹장/참모) + `full_name`
- 도시 `desc` (지리/역사 설명)
- favicon '三' → '한'

## ⭐ sango-rising-dragons-kr 표준 README 구조

GitHub README는 다음 구조로 작성:

```markdown
# {원본 게임명} — 한국어 한글화 포크

> {게임 부제}
> {원작자}/{원본저장소}의 한국어 한글화 포크

[원본 저장소](url) · [한글화 포크](url)

## ✨ 한글화 현황
(테이블로 항목별 진행률 표시)

## 🎮 게임 특징
(원본 README에서 추출, 3-5개 불릿 포인트)

## 🚀 빠른 시작
(./play.sh 사용법 4-옵션)

## 🛠 빌드 요구사항
(Node, npm 버전 명시)

## 🗂 프로젝트 구조
(디렉토리 트리)

## 🌍 한국어 모드팩 구조
(public/data/ko/ 패턴 설명)

## 🤝 기여 방법
(번역/콘텐츠/코드 기여)

## 📜 크레딧
(원작자, 엔진, 자산, 한글화)

## 📄 라이선스
(원본 라이선스 + 한글화 포크 안내)
```

**이 구조는 다른 OSS fork-한글화 시에도 재사용 가능**.

## ⭐ 사용자가 "링크만 알려줘" 했을 때 응답 형식 (정정, 재강조)

**시그널**: "TOP 3의 깃허브 링크를 알려줘" (단순 URL 요청)

**❌ 과잉 응답** (실수 패턴):
- 큰 매트릭스 (순위, ⭐, 언어, 라이선스, 크기, 빌드, 한국어화 가치, 활발도, 설명, URL)
- 각 후보별 상세 분석
- 1~2페이지 분량

**✅ 올바른 응답**:
```markdown
| 순위 | 저장소 | ⭐ | URL |
|---|---|---|---|
| 🥇 | repo/name | 1967 | https://github.com/... |
| 🥈 | repo/name | 1454 | https://github.com/... |
| 🥉 | repo/name | 1861 | https://github.com/... |
```

5줄 이내. 추가 분석은 사용자 후속 질문 시.

**원칙**: 사용자가 "링크", "URL", "주소" 등을 명시적으로 요청하면 **그것만** 제공. 추가 컨텍스트는 사용자 후속 질문까지 대기.

**sango-rising-dragons 세션 정정 시그널**: "내 기대와 다르네.., 별로인데...심지어 삼국지와 관계있을 만한건... 이것뿐인 것 같은데" → 이 정정 시그널 받은 후:
1. 즉시 후보 평가 매트릭스 X
2. 단순 표 5줄 (이름 + ⭐ + URL)
3. 사용자가 후속 질문할 때까지 대기

## ⭐ 사용자가 "전체 한글화" 했을 때 추가 작업 패턴 (NEW, 2026-07-20)

"한글화가 아직 매우 부족하네..." 정정 후 풍성화 작업:

1. **모든 choices에 효과 설명 추가**: 원본의 "이벤트/선택지" 패턴 → "선택지 (효과 수치)" 패턴
   - 예: "加入聯盟" → "연맹에 가담한다 (금 +500, 전 장수 경험치 +60)"
2. **빠진 2번째 choice 추가**: base의 choices 2개 중 ko에 1개만 있는 경우 base의 다른 choice를 ko에 복사 후 label만 번역
3. **장수/도시/진영에 보강 콘텐츠**:
   - 장수 `alias` (별칭), `full_name` (호칭)
   - 진영 `symbol` (한자 약자), `slogan` (시그니처 한마디), `start_city` (시작 위치)
   - 도시 `desc` (지리/역사 설명)
4. **v0.1 → v0.2**: 풍성화 후 별도 commit + push (사용자 검토 가능)

**이 패턴은 다른 게임 fork-한글화 시에도 재사용 가능**.

## ⭐ OSS 게임 fork 시 점수화 (sango 성공에서 추출, NEW, 2026-07-20)

후보 선정 시 사용자가 원할 수 있는 **점수화 매트릭스**:

| 후보 | Star | 언어 | 빌드 | 게임 완성도 | 리소스 | 라이선스 | **총점** |
|------|------|------|------|-------------|--------|----------|---------|
| **sango-rising-dragons** | 1 | TS/Phaser | 🟢 즉시 | ✅ 완성 | 🟡 1.5MB | ❌ | **8/10** |
| CtxPilot/Late-Eastern-Han | 3 | TS | 🟢 즉시 | ❓ 검증 필요 | 🟡 5.2MB | ✅ MIT | **7/10** |
| War-Of-Kingdom | 71 | C | 🔴 C++ | ✅ 완성 | 🟢 605MB | ❌ | **5/10** (빌드 함정) |
| cheft/sanguo | 52 | JS | 🟢 즉시 | ❌ 미완성 | 🟢 16MB | ❌ | **5/10** (미완성) |

**가중치 (사용자 우선순위)**:
- 빌드 용이성 × 3 (Wesnoth 교훈)
- 게임 완성도 × 3 (cheft/sanguo 교훈)
- 리소스 × 1
- Star × 0.5 (무관, 1이어도 완성되면 OK)
- 라이선스 × 1 (없으면 legal review 필요)

**결론**:
| 후보 | 총점 | 메모 |
|------|------|------|
| **sango-rising-dragons** | **8/10** | ✅ 6시간 성공, sigco3111/sango-rising-dragons-kr 생성됨 |
| CtxPilot/Late-Eastern-Han | 7/10 | 미검증 |
| War-Of-Kingdom | 5/10 | macOS 빌드 2~3주 |
| cheft/sanguo | 5/10 | 미완성이라 부적합 |

**즉시 적용**: 새 후보 제시 시 이 매트릭스로 점수화 + 1순위 추천.

## 다른 게임에 적용하는 체크리스트

다른 OSS 게임을 fork-한글화할 때 다음 체크리스트 사용:

```
□ 1. 5단계 빌드 환경 분류 (TS/Java/Rust/C++/C#)
□ 2. 🟢/🟡/🟠 → 진행, 🔴/⚫ → 5분 사전 검증 + 4-옵션
□ 3. 후보 점수화 (빌드×3 + 완성도×3 + 리소스×1 + Star×0.5 + 라이선스×1)
□ 4. clone + 빌드 검증 5분 (HTTP 200 확인)
□ 5. 데이터 분석: 모드팩 가능한 구조인가? (public/data/, locales/, i18n/ 등)
□ 6. UI vs 데이터 분리 확인
□ 7. ko/ 모드팩 생성 (manifest.json 우선순위)
□ 8. TS/JS UI 한자→한국어 변환 (4개 파일 평균 60분)
□ 9. HTML lang="ko" + Noto Sans KR 폰트
□ 10. play.sh 4-옵션 스크립트 추가
□ 11. 빌드 + Playwright 스크린샷 검증
□ 12. README 표준 구조 (한글화 현황, 빌드 가이드, 기여 가이드)
□ 13. gh repo create + curl 200 검증 (404면 remote 재설정)
□ 14. git push -u origin main
□ 15. 사용자에게 "v0.1 푸시 완료" 보고 + v0.2 보강 작업 옵션

v0.2 보강:
□ 16. 모든 choices에 효과 설명 추가
□ 17. 빠진 2번째 choice 추가
□ 18. 장수 alias + full_name
□ 19. 진영 symbol + slogan + start_city
□ 20. 도시 desc 추가
```

## 학습 기록

- **2026-07-20 (sango 성공)**: TypeScript/Phaser 3 게임 fork-한글화는 2.5시간 내 가능. wesnoth 90분 낭비 직후 6시간 성공으로 학습 곡선 회복.
- **2026-07-20**: `public/data/ko/` 모드팩 패턴이 fork-친화적 데이터 오버레이의 정석. 다른 게임에서도 동일 패턴 적용 가능.
- **2026-07-20**: `play.sh` 4-옵션 스크립트(dev/serve/build/open)는 게임 fork 표준.
- **2026-07-20**: `gh repo create` 후 `curl`로 200 확인 필수 (404면 remote 재설정).
- **2026-07-20**: 사용자 정정 시그널 "한글화가 아직 매우 부족하네..." → 풍성화 작업 (choices 효과, 장수 alias, 진영 slogan).
- **2026-07-20**: 사용자 정정 시그널 "링크만 알려줘" → 매트릭스 X, 단일 표 5줄.
- **2026-07-20**: 5단계 빌드 환경 분류 = 첫 번째 응답에서 즉시 적용.
