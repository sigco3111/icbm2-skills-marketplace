# Vercel 자동배포 임포트-원스 패턴 (2026-07-27 실측)

> **신규 fork 저장소 + Vercel 자동배포의 진짜 메커니즘** — Athena Crisis / Evolve 한국어화 세션에서 발견한 함정.
> "minimax-of-duty.vercel.app 자동배포 봤는데 오늘은 왜 직접 해야 해?" 정정 신호에서 출발.

## 핵심 진실

**Vercel은 신규 fork 저장소를 모릅니다.** `git push origin main`은 GitHub에만 도달하고, Vercel에는 webhook이 안 걸려 있어 자동 빌드가 안 일어납니다.

**minimax-ofuty가 자동배포됐던 진짜 이유**:
- 사용자가 한 번 Vercel 대시보드에서 import 했음 (또는 최초 워커가 처리)
- GitHub App 설치 + webhook 등록 완료
- 이후 모든 `git push` → Vercel 자동 빌드 + alias 갱신

**Athena Crisis / Evolve에서 "5분 가이드" 안내로 빠진 이유**:
- 두 프로젝트 모두 **신규 fork** → Vercel이 모름
- `vercel login` 헤드리스 불가 (OAuth 브라우저 핸드셰이크)
- Vercel 웹 5분 가이드 = "사용자가 한 번 import 클릭" 안내
- **실은 `vercel --yes --prod` CLI 한 줄로 import+deploy 동시 가능** — 토큰만 박으면 자동

## 동작 메커니즘

```
신규 fork 생성
   ↓
git push origin main (GitHub에 push, Vercel은 모름)
   ↓
vercel --yes --prod --token "$VERCEL_TOKEN"   ← 첫 호출: import+deploy 동시
   ↓
   ✓ Created    sigco3111/<project>
   ▲ Aliased    https://<project>.vercel.app
   ↓
이후 모든 git push → Vercel 자동 빌드 (이제부터)
```

## 환경변수 함정 — $VERCEL_TOKEN 자동 인식 안 됨

```bash
export VERCEL_TOKEN="***"
echo $VERCEL_TOKEN  # 출력 OK
vercel whoami       # ❌ "No existing credentials found"
```

**원인**: Vercel CLI는 `VERCEL_TOKEN` 환경변수를 자동 인식하지 않습니다. `~/.vercel/auth.json` (login 캐시) 또는 명시적 `--token` 플래그만 인식.

**해결**:

```bash
# 1. 매번 --token 명시
TOK="$VERCEL_TOKEN"
vercel --yes --prod --token "$TOK"

# 2. alias로 단축
alias v='vercel --token "$VERCEL_TOKEN" --yes'
v --prod

# 3. 영구화 (셸 재시작 후에도)
echo 'export VERCEL_TOKEN="'$VERCEL_TOKEN'"' >> ~/.zshenv
source ~/.zshenv
# ⚠️ ~/.zshenv에 박아도 --token 플래그는 여전히 필요
```

## 판별 매트릭스

| 토큰 위치 | `vercel whoami` 자동 인식 | 워크플로 |
|---|---|---|
| `~/.hermes/secrets/vercel_token.txt` (vcp_ 접두사) | ❌ --token 필요 | `vercel --token "$(cat ...)"` |
| `$VERCEL_TOKEN` 환경변수 | ❌ --token 필요 | `vercel --token "$VERCEL_TOKEN"` |
| `vercel login` (인터랙티브) | ✅ `~/.vercel/auth.json` 캐시 | `--token` 불요 |
| `~/.netrc` + machine api.vercel.com | ✅ | `--token` 불요 |

| 시나리오 | 자동배포 | 진단 |
|---|---|---|
| 이미 Vercel import + GitHub App 설치 | ✅ push → 자동 | `vercel ls <project>` 또는 대시보드 project 존재 |
| 신규 fork (오늘 만든 것) | ❌ import 필요 | `vercel --yes --prod` 첫 호출 = import+deploy 동시 |

## 워크플로 (신규 fork 5분 자동 배포)

```bash
# 1. 토큰 영구화 (1회)
TOK="$VERCEL_TOKEN"
echo 'export VERCEL_TOKEN="'$TOK'"' >> ~/.zshenv
source ~/.zshenv

# 2. 첫 배포 = import + deploy 동시
cd /Users/mac/work/<project>
vercel --yes --prod --token "$TOK"
# 출력:
#   ✓ Created    sigco3111/<project>
#   ▲ Aliased    https://<project>.vercel.app

# 3. 이후 모든 push → 자동
git push origin main
# 5~30초 후 Vercel 자동 빌드 (silent fail 가능 → vercel 스킬 §자동배포 silent fail 참조)
```

## 실측 시나리오 (Athena Crisis + Evolve)

### Athena Crisis (실패 사례)
1. fork + 부팅 검증 OK (offline 빌드 1.85MB)
2. vercel.json 작성 + 한국어 README + push
3. **Vercel 자동배포 안 됨** — 사용자에게 "5분 가이드" 안내
4. 사용자: "매번 네가 vercel 배포를 해줬는데, 오늘을 내가 직접해야하는 이유가 뭐지?"
5. 정직 답변: "Athena Crisis는 신규 fork라 Vercel이 모름. 한 번 import 필요. minimax-ofuty는 이미 import된 저장소라 자동."
6. **자동화 가능**: `vercel --yes --prod --token "$TOK"` 한 줄로 import+deploy 동시 — 사용자가 "직접해줘" 했으면 워커에 디스패치

### Evolve (성공 사례 — 부분)
1. fork + 부팅 검증 OK
2. 한국어 11,670개 번역 100% + vercel.json + .gitignore 정리
3. CLI 인증: `vercel --prod --yes --name evolve-kr` → "No credentials" → "Vercel 웹 5분 가이드" 안내
4. 사용자: "토큰을 주면 오늘 아침처럼 직접가능함?"
5. 진단: `$VERCEL_TOKEN` 환경변수 박혀있음 → `--token "$VERCEL_TOKEN"` 박으면 됨
6. 사용자: "내가 얼마전에 export VERCEL_TOKEN=... 으로 등록했는데 왜 없다고 하지?"
7. **진짜 원인 발견**: vercel CLI는 `VERCEL_TOKEN` env 자동 인식 X. `--token` 플래그 필요
8. **자동화 워커 디스패치**: `vercel --yes --prod --token "$TOK"` + `~/.zshenv` 영구화 + README URL 박기 + push

## 즉시 적용 규칙 (모든 OSS fork + Vercel)

1. **신규 fork** → Vercel import 한 번 필수. **`vercel --yes --prod --token "$TOK"`** 한 줄이 가장 빠름
2. **이미 import된 저장소** → `git push`만으로 자동. 별도 vercel CLI 호출 불요
3. **"매번 자동배포 된다"는 사용자 정정** → "이 저장소는 Vercel에 import 되어 있어서. 신규 fork는 한 번 클릭 필요" 솔직하게 짚기
4. **사용자에게 "직접 클릭" 안내** → **마지막 수단**. 토큰만 박으면 CLI 한 줄로 자동. 사용자가 토큰 주겠다고 하면 워커 디스패치로 끝
5. **모든 vercel 호출에 `--token "$TOK"` 명시** — 환경변수 자동 인식 안 됨
6. **셸 재시작 대비 `~/.zshenv` 영구화** — 그래도 `--token`은 필요

## 후속 작업 체크리스트

- [ ] `~/.zshenv`에 `export VERCEL_TOKEN="..."` 박기 (한 번)
- [ ] `vercel --token "$TOK" --yes --prod` 첫 호출 = import+deploy 동시
- [ ] `vercel ls <project>` 또는 대시보드에서 project 존재 확인
- [ ] alias URL (`<project>.vercel.app`) README에 박기
- [ ] 이후 모든 `git push` → 자동 (별도 작업 불요)
- [ ] silent fail 검증: `vercel ls <project>` → 새 deployment Ready + alias JS hash 변경 확인

## 관련 스킬/레퍼런스

- `vercel/SKILL.md` §"$VERCEL_TOKEN 자동 인식 부재" + §"`git push` → 자동배포가 항상 일어나는 게 아니다"
- `vercel/SKILL.md` §"Team-scope anon 시 SSO 302" — README URL은 항상 alias (`<project>.vercel.app`) 사용
- `vercel/SKILL.md` §"자동배포 silent fail" — push 후 alias JS hash 검증
