# Apache 2.0 fork — MODIFIED.md 템플릿

> Apache License 2.0 §4(a) 변경 표시 의무를 충족하는 표준 양식.
> Stanford generative_agents-kr (2026-07-14) 실제 사례에서 검증됨.

## 본문 (그대로 복사해서 사용)

```markdown
# MODIFIED.md — 변경 사항 명시 (Apache 2.0 §4(a) 준수)

## 원본 정보
- **원본 저장소**: https://github.com/{org}/{repo}
- **원본 저자**: {원본 저자/소속}
- **원본 논문/문서**: [{제목}]({url})
- **원본 라이선스**: Apache License 2.0
- **원본 commit (import 시점)**: upstream main ({YYYY-MM-DD})
- **저작권 표시**: © {연도} {저자}. Apache 2.0.

## 본 저장소 ({user}/{repo-name})

### 주요 변경 사항

| # | 파일/모듈 | 변경 내용 |
|---|----------|----------|
| 1 | {파일 경로} | {변경 요약} |
| 2 | {파일 경로} | {변경 요약} |
| 3 | ... | ... |

### 보존된 사항

- 원본 LICENSE 파일 (Apache 2.0 전문) 그대로 유지
- 원본 디렉토리 구조 ({구조}) 유지
- {기타 보존 사항}

### 추가 의존성 (원본 대비)

| 패키지 | 용도 | 라이선스 |
|--------|------|---------|
| {pkg} | {용도} | {license} |

### 검증 (LLM 백엔드)

- `python {entry_point}.py` self-test: {검증 항목}
- 한국어 {N} 케이스 retrieval 정확도: {퍼센트}
- {기타 검증}

### 면책 조항

본 저장소는 원본의 학술 연구를 {사용 환경/언어}에 적용하고 {변경 사항}을 시도한 비공식 fork입니다. 원본 저자({저자})의 공식 입장을 대표하지 않으며, 모든 책임은 사용자에게 있습니다.

---

**Apache License 2.0 §4(a)**: "You must give any other recipients of the Work or Derivative Works a copy of this License; and You must cause any modified files to carry prominent notices stating that You changed the files."
```

## 사용 예 (sigco3111/generative_agents-kr 실제 사례, 2026-07-14)

원본: https://github.com/joonspk-research/generative_agents
- **저자**: Joon Sung Park + 5명 (Stanford University)
- **논문**: "Generative Agents: Interactive Simulacra of Human Behavior"
- **라이선스**: Apache 2.0

변경 사항 8개 항목 모두 표로 정리:
1. gpt_structure.py — LLM 백엔드 OpenAI → NIM
2. gpt_structure.py — 임베딩 OpenAI → NIM asymmetric
3. gpt_structure.py — passage/query 함수 분리
4. gpt_structure.py — 부정 가드
5. gpt_structure.py — score_memory() 통합
6. utils.py — NIM 환경변수
7. test.py — 한글 sanity check
8. README.md — 한글 설치 가이드

## 검증 방법 (GitHub API)

```bash
# repo 라이선스 자동 인식 확인
curl -sL "https://api.github.com/repos/{user}/{repo}" | \
  python3 -c "import json, sys; d=json.load(sys.stdin); \
    print('license:', d['license']['spdx_id'] if d.get('license') else 'NONE')"
```

기대 출력: `license: Apache-2.0` (자동 인식), `license: MIT`, 또는 `license: GPL-3.0`.
`license: NONE`이면 GitHub이 LICENSE 파일을 인식 못 한 상태 — 파일이 root에 있는지 확인.

## 체크리스트

- [ ] 원본 LICENSE 파일이 repo root에 그대로 보존
- [ ] repo root에 MODIFIED.md 작성 (이 템플릿)
- [ ] 본인 repo Description에 `{원본 이름} 한글화 + ... · Apache 2.0 fork` 명시
- [ ] GitHub API로 `license.spdx_id` 자동 인식 확인 (NONE이면 LICENSE 파일 위치 재확인)
- [ ] 모든 변경 파일에 `원본: {org}/{repo} (Apache 2.0)` 또는 `라이선스: Apache 2.0 — sigco3111 fork` 헤더 코멘트
