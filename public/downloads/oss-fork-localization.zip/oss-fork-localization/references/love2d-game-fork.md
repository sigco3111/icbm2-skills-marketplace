# 🎮 LÖVE (Lua) 게임 fork-한글화 성공 사례: snkrx-clone (2026-07-21)

> [a327ex/SNKRX](https://github.com/a327ex/SNKRX) — LÖVE 11.x 기반 오토배틀러 로그라이크.
> ~22K LOC, MIT 라이선스, Steamworks SDK 의존. **30분 안에 부팅 + 한글 화면까지 성공** (반복 디버깅 포함).
> wesnoth-kr의 C++ 함정, sango-rising-dragons-kr의 TypeScript 모듈성을 거친 **세 번째 게임 fork 사례**.

이 레퍼런스는 LÖVE 2D 엔진 기반 게임을 fork-한글화할 때 **복사용**으로 가치가 큼. SNKRX에 한정되지 않은 일반 패턴:

## 왜 LÖVE인가 (5단계 빌드 환경 분류 확장)

기존 분류:

| 분류 | 빌드 도구 | macOS 호환성 | 사례 |
|------|----------|--------------|------|
| 🟢 즉시 성공 | `npm`/`yarn` (Vite, Next.js) | ✅ 네이티브 | sango-rising-dragons (TS) |
| 🟡 Java/Gradle | `./gradlew` | ✅ 안정 | triplea, FreeCol |
| 🟠 Rust/cargo | `cargo build` | ✅ 안정 | zemeroth, veloren |
| 🔴 C++ scons/CMake | `scons`/`make` | ⚠️ 환경 의존 | Wesnoth (실패) |
| ⚫ C# | `dotnet`/`mono` | ⚠️ mono 의존 | RTK2020-CORE |

**신규 추가 (LÖVE/Lua 게임 카테고리)**:

| 분류 | 빌드 도구 | macOS 호환성 | 사례 |
|------|----------|--------------|------|
| 🟢 **LÖVE/Lua** | `brew install --cask love` + `love .` | ✅ 매우 안정 (런타임 1개) | **SNKRX** ✅ 성공 (2026-07-21) |

**왜 안전한가**:
- `love.app` 한 개만 설치 → brew cask로 2분
- LÖVE 11.x → 표준 Lua 5.1/LuaJIT, 외부 SDK 의존은 게임이 직접 require
- **Steamworks 같은 외부 SDK는 shim으로 우회 가능** (Steam 클라이언트 없이도 게임플레이 가능)
- snkrx-clone 22K LOC 게임이 5분 안에 부팅 + 한글 표시까지 성공

**즉시 적용 규칙**: 사용자가 LÖVE 게임 fork 요청 시 **Wesnoth처럼 빌드 함정 걱정 없음**. brew cask love → `love .` → 메인 루프 진입.

## ⭐ Steamworks SDK shim 패턴 (CRITICAL, 2026-07-21)

대부분의 상용 LÖVE 게임은 Steamworks 바인딩을 사용:
```lua
-- 원본 engine/external/init.lua
steam = require 'luasteam'  -- Steamworks SDK Lua 바인딩
```

brew로 깐 `love.app`에는 `luasteam.so` (또는 `.dylib`)가 **포함되어 있지 않음**. → `module 'luasteam' not found` 에러.

**해결: 같은 디렉토리에 shim 만들기 (Wesnoth 90분 낭비의 정반대 — 5분)**.

```lua
-- engine/external/luasteam.lua — Steam shim (no-op)
local M = {}
function M.init() return true end
function M.shutdown() end
function M.runCallbacks() end  -- love.main_loop에서 매 프레임 호출됨

M.userStats = {
  requestCurrentStats = function() return true end,
  setAchievement = function() end,
  storeStats = function() end,
  getStatInt = function() return 0 end,
  setStatInt = function() end,
}

M.friends = {
  setRichPresence = function() end,
  activateGameOverlay = function() end,
}

M.utils = {
  getAppID = function() return 0 end,
}

return M
```

**init.lua에서 shim 경로 명시**:
```lua
-- 변경 전
steam = require 'luasteam'

-- 변경 후 (v0.1 fork)
steam = require(path .. ".luasteam")  -- 같은 디렉토리의 luasteam.lua 사용
```

**장점**:
- 원본 `luasteam.so` 의존성 제거 → MIT 코드만으로 완전 동작
- Steam 클라이언트 미설치 환경에서도 게임플레이 가능
- Steam 업적/친구/RichPresence 모두 no-op 처리 (게임플레이 영향 0)
- fork 사용자가 Steam 없이도 빌드 가능

**shim에 반드시 포함할 메서드 (검증된 목록)**:
- `steam.init()`, `steam.shutdown()`, `steam.runCallbacks()`
- `steam.userStats.setAchievement()`, `storeStats()`
- `steam.friends.setRichPresence()`

**검증 방법**: `grep -rn "steam\." main.lua buy_screen.lua arena.lua` → 사용된 모든 메서드 shim에 추가.

## ⭐ UTF-8 character 단위 iteration 패턴 (CRITICAL, 2026-07-21)

LÖVE 11.x의 `love.graphics.newFont(TTF)`는 한글 glyph가 없으면 깨진 박스(□) 출력. 하지만 **그보다 먼저 죽는 함정**: `Text:parse()` 함수가 **byte 단위로 iteration**하여 한글을 개별 바이트로 쪼갬.

**원본 (engine/graphics/text.lua)**:
```lua
for i = 1, #line.text do
  local c = line.text:sub(i, i)  -- ← 1 BYTE (한글 = 3바이트)
  ...
  table.insert(line.characters, {character = c, visible = true, ...})
end
```

**증상**: `cf:getWidth(c.character)` 호출 시 **"UTF-8 decoding error: Not enough space"** 크래시. `c.character`가 단일 바이트(예: `\xEC`)라 유효한 UTF-8 문자열이 아니기 때문.

**해결 (lead byte 분석)**:
```lua
local i = 1
while i <= #line.text do
  local b = line.text:byte(i)
  local cont = 1
  if b >= 0xF0 then cont = 4      -- 4-byte (CJK Extension B+, Emoji)
  elseif b >= 0xE0 then cont = 3  -- 3-byte (한글, CJK, 일본어)
  elseif b >= 0xC0 then cont = 2  -- 2-byte (Latin extended)
  elseif b >= 0x80 then cont = 1  -- continuation byte (orphan)
  end
  local c = line.text:sub(i, i + cont - 1)  -- ← full UTF-8 character
  ...
  i = i + cont
end
```

**장점**:
- 원본의 ASCII 기반 가정 깨지지 않음 (ASCII는 모두 cont=1)
- 한글/일본어/중국어 모두 정확히 1 character = N bytes로 처리
- `cf:getWidth(c.character)` 정상 동작

**⚠️ tag 위치 주의**: tag boundary가 byte index를 사용하지만, 우리 iteration은 character index. ASCII tag(`[fg]`, `[bg10]` 등)는 byte == character라 무관. **non-ASCII tag는 거의 없으므로 안전**.

## ⭐ CJK 폰트 자동 fallback 패턴 (2026-07-21)

LÖVE TTF는 한글 glyph가 없으면 □ 출력. → **별도 한글 폰트 (NotoSansKR-Regular.ttf) 임베드 + 자동 전환**.

**Font 객체 확장 (engine/graphics/font.lua)**:
```lua
function Font:has_cjk(text)
  if text == nil then return false end
  if type(text) ~= "string" then return false end  -- 숫자 가드 (CRITICAL)
  for i = 1, #text do
    local b = text:byte(i)
    if b >= 0xE0 then return true end  -- 3-byte lead byte = 한글/CJK
  end
  return false
end

function Font:_ensure_ko_font()
  if self.ko_font then return self.ko_font end
  local ko_path = "assets/fonts/NotoSansKR-Regular.ttf"
  if love.filesystem.getInfo(ko_path) then
    self.ko_font = love.graphics.newFont(ko_path, self.size)
  else
    self.ko_font = self.font
  end
  return self.ko_font
end

function Font:get_font_for_text(text)
  if self:has_cjk(text) then
    return self:_ensure_ko_font()
  end
  return self.font
end

function Font:get_text_width(text)
  if text == nil or type(text) ~= "string" then return 0 end
  if self.ko_font and self:has_cjk(text) then
    return self.ko_font:getWidth(text)
  end
  return self.font:getWidth(text)
end
```

**`type(text) ~= "string"` 가드 (CRITICAL)**: `graphics.print(self.parent.cost, ...)`처럼 가격(숫자)도 호출됨. `has_cjk(3)` → `#3` → 크래시. `type() ~= "string"` 가드로 즉시 0/false 반환.

**graphics.print / graphics.print_centered CJK 처리 (engine/graphics/graphics.lua)**:
```lua
function graphics.print(text, font, x, y, r, sx, sy, ox, oy, color)
  local _r, g, b, a = love.graphics.getColor()
  if color then love.graphics.setColor(color.r, color.g, color.b, color.a) end
  local active_font
  if font.get_font_for_text then
    active_font = font:get_font_for_text(text)
  else
    active_font = font.font
  end
  love.graphics.print(text, active_font, x, y, r or 0, sx or 1, sy or 1, ox or 0, oy or 0)
  if color then love.graphics.setColor(_r, g, b, a) end
end
```

**text.lua format_text / draw도 같은 패턴 적용**:
```lua
local cf
if line.font.get_font_for_text then
  cf = line.font:get_font_for_text(c.character)
else
  cf = line.font.font
end
love.graphics.print(c.character, cf, ...)
```

**NotoSansKR-Regular.ttf 다운로드**:
```bash
curl -L -o assets/fonts/NotoSansKR-Regular.ttf \
  "https://github.com/notofonts/noto-cjk/raw/main/Sans/SubsetOTF/KR/NotoSansKR-Regular.otf"
```
- 4.6MB — 적당한 크기
- SIL Open Font License 1.1 (상업/수정/배포 자유)

## ⭐ macOS 풀스크린 함정 디버깅 (2026-07-21, 4번 반복)

LÖVE 11.5 + macOS M4 (Retina) 조합에서 윈도우 크기 변경 시 풀스크린화되는 함정. **4번의 다른 시도 끝에 해결**.

### 함정 1: `love.window.getDesktopDimensions()`이 디스플레이 크기 (Retina 픽셀) 반환

**증상**: `window_width = love.window.getDesktopDimensions()` → M4에서 2560x1600 반환. `sx, sy = 2560/480 = 5.33` → 거대 스케일 → setMode에서 풀스크린화.

**해결**: `window_width/height = 'max'` 대신 **절대 픽셀** (예: 1280x720) 직접 전달.

### 함정 2: `state.sx = 4` 같은 비정상 세이브 데이터

**증상**: `~/Library/Application Support/LOVE/SNKRX/state.txt`에 저장된 `sx=4` → `setMode(4*480, 4*270) = 1920x1920` → 풀스크린화.

**해결 (2단계)**:
```bash
# 1. state.txt 삭제 (가장 빠름)
rm ~/Library/Application\ Support/LOVE/SNKRX/state.txt

# 2. 코드 가드 (state.sx/sy 비정상 범위 무시)
if state.sx and state.sy then
  if state.sx >= 0.5 and state.sx <= 3 and state.sy >= 0.5 and state.sy <= 3 then
    -- 정상 범위: state.sx/sy 사용
  else
    -- 비정상: 무시하고 기본 사이즈 사용
    state.sx, state.sy = nil, nil
  end
end
```

### 함정 3: display flag 누락 → 메인 디스플레이 외 다른 디스플레이로 setMode

**증상**: 멀티 디스플레이 환경에서 `flags.display = nil` → love2d가 자동으로 디스플레이 1 외 다른 곳으로 윈도우 생성.

**해결**: `setMode` 옵션에 **`display = 1` 명시**:
```lua
love.window.setMode(window_width, window_height, {
  vsync = config.vsync,
  msaa = msaa or 0,
  display = 1,           -- ← 메인 디스플레이 강제
  fullscreen = false,    -- ← 풀스크린화 차단
  borderless = false,    -- ← borderless 모드 차단
  resizable = true,      -- ← 사용자 직접 조절 가능
})
```

### 함정 4: 표준 사이즈(1920x1080) = 디스플레이 해상도와 일치 → 풀스크린

**증상**: M4 14" 디스플레이 정확히 1920x1080 → setMode(1920, 1080) → macOS가 풀스크린화.

**해결**: **비표준 사이즈 사용** (1280x720, 1440x810, 1280x800 등).

### 최종 setMode 호출 (모든 가드 통합):

```lua
-- engine/init.lua
local _, _, flags = love.window.getMode()
local window_width, window_height = love.window.getDesktopDimensions(flags.display)

-- 'half' 모드 (옵션)
if config.window_width == 'half' then window_width = math.floor(window_width / 2) end
if config.window_height == 'half' then window_height = math.floor(window_height / 2) end

if config.window_width ~= 'max' and config.window_width ~= 'half' then window_width = config.window_width end
if config.window_height ~= 'max' and config.window_height ~= 'half' then window_height = config.window_height end

gw, gh = config.game_width or 480, config.game_height or 270
sx, sy = window_width/(config.game_width or 480), window_height/(config.game_height or 270)
ww, wh = window_width, window_height

-- state.sx/sy 무시하고 매번 config 기반 재계산
state.sx, state.sy = sx, sy
love.window.setMode(window_width, window_height, {
  vsync = config.vsync,
  msaa = msaa or 0,
  display = 1,
  fullscreen = false,
  borderless = false,
  resizable = true,
})
```

**⚠️ state.sx/sy 분기 단순화의 중요성**: 원본은 state.sx/sy가 있으면 그 값으로 덮어써서 윈도우 사이즈가 어긋남. **v0.1 fork에서 단순화 — 매번 config 기반 재계산**.

## ⭐ 좌표계 vs 윈도우 사이즈 분리 (CRITICAL, 2026-07-21)

SNKRX는 좌표계를 480x270으로 **하드코딩 가정** (모든 오브젝트 위치, 모든 setMode 호출). main.lua의 `setMode(480*sx, 270*sy)` 호출.

**문제**: 게임 좌표(game_width/height)와 윈도우 크기(window_width/height)를 어떻게 분리할까?

**해결**:
```lua
-- main.lua love.run
return engine_run({
  game_name = 'SNKRX',
  window_width = 1280,    -- 윈도우 (Retina 매핑 후 보이는 크기)
  window_height = 720,
  game_width = 480,        -- 게임 좌표계 (원본 480x270 유지!)
  game_height = 270,
})
```

**동작**:
- `sx = window_width / game_width = 1280 / 480 ≈ 2.67`
- 모든 `graphics.rectangle(x, y, w, h)`가 sx=2.67로 자동 비례 확대
- **창은 크고, 오브젝트도 비례 확대되어 자연스럽게 보임**
- K/L 키 핸들러의 `setMode(480*sx, 270*sy)`도 같은 비율 유지 → 호환

**다른 크기 옵션**:
| 윈도우 | sx 비율 | Retina 매핑 후 보이는 크기 | 원본 대비 |
|---|---|---|---|
| 720x405 | 1.5 | 360x202 | 0.75배 |
| 960x540 | 2.0 | 480x270 | 1.0배 (원본) |
| **1280x720** | **2.67** | **640x360** | **1.33배** |
| 1440x810 | 3.0 | 720x405 | 1.5배 |
| 1920x1080 | 4.0 | 960x540 | 2.0배 (단, 풀스크린 위험) |

**선택 가이드**: 1280~1440 사이가 안전 (비표준 + 적당한 크기).

## ⭐ LÖVE DPI 스케일링 (usedpiscale, NEW, 2026-07-21)

LÖVE 11.x의 `usedpiscale` (default: true)이 Retina에서 윈도우 크기를 DPI 비율로 자동 축소.

**증상**: `setMode(1280, 720)` → love2d가 Retina 매핑 → 내부 좌표계가 640x360으로 보임.

**해결 (conf.lua)**:
```lua
function love.conf(t)
  t.version = "11.3"
  t.window.width = 1280    -- ← 초기 윈도우 크기도 conf에서 결정
  t.window.height = 720
  t.window.vsync = 1
  t.window.msaa = 0
  t.window.resizable = true
  t.window.usedpiscale = false  -- ← DPI 스케일링 비활성화 (CRITICAL)
end
```

**왜 중요한가**:
- `usedpiscale = true` → M4 Retina에서 setMode(1280, 720)이 내부적으로 640x360 좌표로 표시됨
- `usedpiscale = false` → 1280x720 윈도우가 진짜 1280x720 픽셀로 표시
- **외부 setMode 호출과 무관** — love.conf에서 미리 설정해야 함

## ⭐ LÖVE Gatekeeper 우회 (macOS, NEW, 2026-07-21)

`brew install --cask love`로 설치한 love.app은 Apple 공인 개발자 인증서 없음 → Gatekeeper 차단.

**증상**: "love를(을) 열지 못했습니다. Apple이 'love'에서 사용자의 Mac에 손상을 입히거나 사생활에 문제가 생길 수 있는 악성 코드를 확인했습니다" 팝업.

**해결 (1초, 가장 빠름)**:
```bash
xattr -dr com.apple.quarantine "/Applications/love.app"
```

**검증**:
```bash
xattr -l "/Applications/love.app"  # quarantine 속성 제거 확인
```

**대안**:
- Finder에서 love.app 우클릭 → "열기" → "열기" (Gatekeeper 우회, 1회)
- 시스템 설정 → 보안 및 개인 정보 보호 → "그래도 열기" (30초)

## ⭐ `luasteam`이 없다는 에러와 처리 (NEW, 2026-07-21)

**증상**:
```
Error: engine/external/init.lua:7: module 'luasteam' not found:
    no field package.preload['luasteam']
    no 'luasteam' in LOVE game directories.
    no file '/usr/local/share/luajit-2.1/luasteam.lua'
    ...
```

**원인**: Steamworks SDK 바인딩 (`luasteam.so`)이 brew의 love.app에 포함 안 됨.

**해결**: 위 Steamworks SDK shim 패턴 (§) 참조.

## ⭐ runCallbacks 누락 에러 (NEW, 2026-07-21)

**증상**:
```
Error: engine/init.lua:149: attempt to call field 'runCallbacks' (a nil value)
```

**원인**: `engine/init.lua`에서 매 프레임 `steam.runCallbacks()` 호출. shim에 빠짐.

**해결**: shim에 추가:
```lua
function M.runCallbacks() end
```

## ⭐ type() 가드 — 숫자 전달 시 크래시 (NEW, 2026-07-21)

**증상**:
```
Error: engine/graphics/font.lua:54: attempt to get length of local 'text' (a number value)
```

**원인**: `graphics.print(self.parent.cost, pixul_font, ...)`로 가격(숫자 3) 전달. 우리 `print_centered`의 `font:get_font_for_text(text)` → `has_cjk(3)` → `#3` 시도 → 크래시.

**Lua 함정**: `if not text then return false`에서 `if not 0 then`은 false (0은 truthy!) → 가드 통과 후 `#text` 크래시.

**해결**: `type(text) ~= "string"` 명시적 가드:
```lua
function Font:has_cjk(text)
  if text == nil then return false end
  if type(text) ~= "string" then return false end  -- ← 숫자/boolean 방어
  ...
end
```

**⚠️ CRITICAL**: 모든 `T()` / `has_cjk()` / `get_text_width()` 호출에 `type(text) ~= "string"` 가드 필수. 게임 코드가 의외로 숫자를 텍스트로 출력하는 경우 많음.

## ⭐ 게임 시작 검증을 위한 백그라운드 + ps 패턴 (NEW, 2026-07-21)

LÖVE는 GUI 앱이라 헤드리스 환경에서 foreground 실행 시 SIGKILL. **백그라운드 + ps로 검증**.

**패턴**:
```bash
# 백그라운드 실행 (foreground '&' 금지)
terminal(background=true) command="cd /path && exec /opt/homebrew/bin/love . > /tmp/love.log 2>&1"

# 5초 후 검증
terminal(command="sleep 5 && ps -p $PID -o pid,stat,command")
# STAT=Ss = sleeping (정상 메인 루프), exit/died = 크래시

# 로그 확인
terminal(command="cat /tmp/love.log")
# 빈 로그 = 정상 (love2d는 에러만 stderr 출력), 에러 있으면 크래시

# 종료
process(action='kill', session_id=...)
```

**SIGKILL vs SIGTERM**:
- SIGKILL(9): 즉시 강제 종료, 헤드리스 환경에서 love GUI 띄우려다 OS가 죽임
- 정상 부팅: 프로세스 살아있음, stderr 빈 상태
- 크래시: 즉시 exit, stderr에 에러 메시지

## ⭐ `lang/<code>.lua` 모드팩 패턴 (LÖVE 버전, NEW, 2026-07-21)

sango-rising-dragons의 JSON 모드팩과 달리, LÖVE 게임은 텍스트가 **Lua 코드 안에 흩어져 있음** (`text = 'arena run'`). 다른 패턴 필요:

**`T()` 전역 함수 + `lang/ko.lua` 모듈**:
```lua
-- shared.lua
lang = lang or {}
lang.current = 'ko'
lang.dicts = {}
lang.dicts.en = {}
lang.dicts.ko = require('lang.ko')
lang.fallback = 'en'

function T(key, default)
  local dict = lang.dicts[lang.current] or {}
  local fb = lang.dicts[lang.fallback] or {}
  if dict[key] ~= nil then return dict[key] end
  if fb[key] ~= nil then return fb[key] end
  return default or key
end
```

**`lang/ko.lua`**:
```lua
return {
  arena_run = '아레나 런',
  options = '옵션',
  ...
}
```

**게임 코드에서 사용**:
```lua
-- 변경 전
button_text = 'arena run'
-- 변경 후
button_text = T('arena_run', 'arena run')
```

**장점**:
- 영어 원본이 default → 폴백 안전
- `lang.current = 'ko'/'en'` 한 줄로 전체 UI 언어 전환
- 다른 언어 추가 용이 (lang/ja.lua, lang/zh.lua)

**vs sango의 JSON 모드팩 차이**:
| 항목 | sango (JSON 모드팩) | snkrx (T() 함수) |
|------|---------------------|-------------------|
| 데이터 구조 | JSON 파일 | Lua 코드 안에 흩어진 텍스트 |
| 모드팩 추가 | `public/data/ko/*.json` | `lang/ko.lua` 키 추가 |
| UI/데이터 분리 | 명확 (TS vs JSON) | 혼재 → T() 함수로 우회 |
| 게임플레이 영향 | 0 (데이터만 교체) | 0 (T() fallback) |

**언제 어떤 패턴?**: 데이터(JSON/CSV/PO) 외부화 게임 → 모드팩 패턴. 코드 안에 텍스트 → T() 함수 패턴.

## ⭐ CharacterIcon hover info 패턴 — 다중 텍스트 우회 (NEW, 2026-07-21)

**영웅 이름 + 클래스 + 설명 + 비용 + 효과** 5개 항목이 한꺼번에 표시되는 hover info. 일부는 동적 함수 (`character_descriptions[char](1)`).

**해결 전략**:
1. 영웅 이름: `T('char_' .. self.character, self.character)` — 정적 키
2. 라벨 (cost, classes): `T('cost_label', 'cost: ')` — 정적 키
3. 클래스명: main.lua 테이블 직접 한글화 (sed로 일괄 치환)
4. 효과 이름: main.lua 테이블 직접 한글화
5. **설명 본문 (함수 테이블)**: `lang.character_descriptions_ko[self.character]` 별도 테이블 + `lang.current == 'ko'` 분기

**main.lua 테이블 일괄 한글화 (Python 스크립트)**:
```python
import re
class_translations = {
    'Warrior': '전사', 'Mage': '마법사', 'Nuker': '누커',
    'Ranger': '레인저', 'Rogue': '도적', 'Healer': '힐러',
    'Enchanter': '인챈터', 'Psyker': '사이커', 'Builder': '빌더',
    'Voider': '보이드', 'Curser': '커서', 'Swarmer': '스워머',
    'Forcer': '포서', 'Sorcerer': '소서러', 'Mercenary': '머서너리',
}
# color tag (]) 다음에 오는 클래스명만 치환
new_line = re.sub(r'\]\s*' + en + r'\b', ']' + ko, new_line)
```

**별도 설명 테이블 (`lang/character_descriptions_ko.lua`)**:
```lua
-- 57개 영웅 설명 함수
return {
  ['vagrant'] = function(lvl) return '[fg]투사체를 발사해 [yellow]{dmg}[fg] 데미지' end,
  ...
}
```

**buy_screen.lua에서 분기**:
```lua
local desc_func = (lang.current == 'ko' and lang.character_descriptions_ko and lang.character_descriptions_ko[self.character]) or character_descriptions[self.character]
text = desc_func(1)
```

**장점**: 함수 테이블도 깔끔하게 분리. 원본 영어 보존 + 한국어 패치 분리.

## ⭐ `lang.current == 'en'`일 때만 string.lower() (NEW, 2026-07-21)

원본 SNKRX는 `string.lower(character_names[self.character])`로 영웅 이름을 소문자로 출력 (시각 효과). 한국어에 적용하면 영향 없지만, **안전하게 언어별 분기**:

```lua
local char_name = T('char_' .. self.character, self.character)
if lang.current == 'en' then
  char_name = self.character:capitalize()  -- 영어만 capitalize
end
```

**⚠️ 한글에 string.lower() 적용 가능하지만 무의미**: 한글 음절에 lower 변환이 정의되어 있지 않아 그대로 반환. 하지만 미래에 다른 CJK 언어 추가 시 안전을 위해 분기.

## ⭐ 작업 시간 (실측, snkrx-clone)

| 단계 | 시간 | 비고 |
|------|------|------|
| 클론 + 구조 파악 | 5분 | git clone + wc -l + 파일 트리 |
| LÖVE 설치 + Gatekeeper 우회 | 3분 | brew install + xattr |
| Steam shim 작성 | 3분 | 25줄 Lua |
| UTF-8 character iteration 수정 | 5분 | text.lua parse 함수 |
| CJK 폰트 fallback | 10분 | Font 클래스 확장 + NotoSansKR 다운로드 |
| `T()` 함수 + ko.lua | 15분 | ~80 키 번역 |
| buy_screen.lua / mainmenu.lua T() 적용 | 30분 | 15+ 텍스트 교체 |
| **에러 디버깅 (4번)** | **40분** | luasteam 없음 → UTF-8 → runCallbacks → type 가드 |
| 풀스크린 함정 디버깅 | 30분 | state.sx, display=1, 비표준 사이즈 |
| 윈도우 사이즈 비례 확대 | 15분 | game_width=480 + window_width=1280 |
| GitHub 푸시 | 5분 | gh repo create + curl 200 검증 |
| 추가 한글화 (v0.1.1~v0.1.3) | 30분 | 클래스명 60+, 효과 이름 60+ |
| **합계** | **~3시간** | (Wesnoth 90분 vs SNKRX 3시간, but SNKRX는 Steam+MacOS 함정 추가) |

## 다른 LÖVE 게임에 적용하는 체크리스트

```
□ 1. brew install --cask love + xattr quarantine 제거
□ 2. Steam shim 작성 (engine/external/luasteam.lua) + init.lua 수정
□ 3. UTF-8 character iteration 수정 (engine/graphics/text.lua parse)
□ 4. CJK 폰트 자동 fallback (Font:get_font_for_text + type 가드)
□ 5. graphics.print / print_centered CJK 처리
□ 6. text.lua format_text / draw CJK 처리
□ 7. NotoSansKR 임베드 (assets/fonts/)
□ 8. lang/ko.lua 작성 + shared.lua에 T() 함수
□ 9. UI 텍스트 T()로 일괄 교체
□ 10. macOS 풀스크린 함정 디버깅 (state.sx, display=1, 비표준 사이즈)
□ 11. usedpiscale = false (conf.lua)
□ 12. 좌표계 vs 윈도우 사이즈 분리 (game_width=원본, window_width=1280~1440)
□ 13. 백그라운드 love 실행 + ps 검증
□ 14. gh repo create + curl 200 검증
□ 15. 모드팩 패턴: lang.character_descriptions_ko.lua 별도 함수 테이블
□ 16. main.lua 클래스명/효과명 일괄 한글화 (Python 스크립트)
□ 17. README 표준 구조 + MODIFIED.md 변경 이력
```

## 학습 기록

- **2026-07-21**: LÖVE/Lua 게임 fork-한글화는 Wesnoth(C++)와는 정반대 — brew cask 1개로 빌드 환경 0 함정.
- **2026-07-21**: Steamworks SDK shim 패턴 = 외부 SDK 의존 게임을 SDK 없이 실행하는 정석. 5분 작업.
- **2026-07-21**: UTF-8 byte vs char iteration 버그 = LÖVE 11.x의 모든 다국어 게임에 적용 가능한 보편적 함정. lead byte 분석으로 해결.
- **2026-07-21**: CJK 폰트 자동 fallback = `type(text) ~= "string"` 가드 필수 (숫자 전달 시 크래시).
- **2026-07-21**: macOS 풀스크린 함정 4가지 (state.sx, display=nil, 표준 사이즈 일치, getDesktopDimensions Retina 픽셀).
- **2026-07-21**: 좌표계 vs 윈도우 사이즈 분리 = `game_width=480, window_width=1280` 패턴.
- **2026-07-21**: `usedpiscale = false` = Retina에서 좌표계 자동 축소 방지.
- **2026-07-21**: 백그라운드 love 실행 + ps 검증 = 헤드리스 환경에서 LÖVE 부팅 검증 표준.
- **2026-07-21**: `lang/character_descriptions_ko.lua` 분리 = 함수 테이블도 모듈화.