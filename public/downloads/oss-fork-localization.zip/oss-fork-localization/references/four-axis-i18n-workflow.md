# 4대 축 통합 워크플로

> 2026-07-28, BigJk/end_of_eden 5차 실측.

## 왜 필요한가

대부분의 게임/i18n 프로젝트에서 사용자-facing text는 **한 곳에만 있는 게 아님**. 4개 위치에 분산:

```
[1] i18n YAML/JSON          ← 카드, 적, 상태이상 같은 게임 데이터
[2] Lua/Python/JS 하드코딩   ← 이벤트 내러티브, 적 행동 표시
[3] Go/C#/Java UI 코드      ← 메뉴 라벨, init 메시지, 다이얼로그
[4] 비-i18n 텍스트 파일      ← assets/gen/*.txt, data/*.json 같은 raw 데이터
```

**하나만 처리하고 PR 보내면** 게임 직접 실행 시 "여기만 한글, 저기는 영문" → 사용자 거절 신호. **4대 축 모두 끝낸 다음 단일 PR**이 핵심.

## 4대 축 분류 + 처리 패턴

### 축 1: i18n YAML 데이터 (가장 안전)

**위치**: `assets/locals/<code>/*.yml`, `i18n/<code>/*.json`, `lang/<code>.properties` 등

**처리**:
- 원본 `en` (또는 `de`) 폴더와 동일한 구조로 `ko` 폴더 생성
- 영문 키-값을 한국어로 번역
- 로더가 walk로 평탄화 (e.g. `cards.MELEE_HIT.name`)인지 확인

**메인테이너 거부 확률**: **낮음** (i18n은 모든 OSS 환영)

**작업량**: 1-2시간 (한 폴더당 50-100 키)

### 축 2: Lua/스크립트 하드코딩

**위치**: `name = "Waking up..."` 같은 Lua/JS/Python inline string

**처리 전 확인**: 이미 `l()`, `T()`, `tr()` 같은 헬퍼가 있는지
- 있음 → `name = l("events.START.name", "Waking up...")` 단순 patch
- 없음 → 별도 리팩토링 PR (축 1과 분리 권장)

**YAML 키 일관성**: `cards.X.name`, `events.X.name`, `events.X.choices.0.description` 등 점 표기 + 순서 인덱스

**메인테이너 거부 확률**: **중간** (호출 패턴 이미 있으면 낮음, 없으면 높음)

**작업량**: 1-2시간 (Lua 50-100개 patch)

### 축 3: Go/C#/Java UI 하드코딩

**위치**: `m.list.Title = "Settings"`, `fmt.Println("Initializing...")`, `JLabel("Continue")` 등

**처리 패턴**:
```go
// 1단계: import 추가
import "github.com/OWNER/REPO/system/localization"

// 2단계: localization.G() 패턴으로 감싸기
m.list.Title = localization.G("ui.settings.title", "Settings")

// 3단계: YAML에 한국어 추가
ui:
  settings:
    title: 설정
```

**중요**: import 추가 후 LSP unused import 경고가 뜸 → 사용처 patch 후 사라짐. **순서 중요**.

**의존성 cycle 검증**:
```bash
# system/localization이 다른 어떤 패키지 import하는지 확인
grep -l "github.com/OWNER/REPO" system/localization/
# → 아무것도 없으면 안전 (단일 의존 = internal/fs만)
```

**메인테이너 거부 확률**: **중간** (cycle 없으면 낮음, 코드 변경이므로 리뷰 필요)

**작업량**: 1시간 (24-30개 라벨)

### 축 4: 비-i18n 텍스트 파일

**위치**: `assets/gen/*.txt`, `assets/scripts/enemies.json`, `data/dialogue.xml` 등

**처리 패턴 A: locale overlay (loader 패치 1개)**:
```go
// system/gen/gen.go
localeDir := "./assets/gen/" + localization.GetCurrent()
if localeFiles, err := fs.ReadDir(localeDir); err == nil {
    for _, file := range localeFiles {
        bytes, _ := fs.ReadFile(localeDir + "/" + file.Name())
        data[strings.Split(file.Name(), ".")[0]] = strings.Split(string(bytes), "\n")
    }
}
```

**처리 패턴 B: 데이터 파일 직접 한국어화**:
- 원본 파일을 한국어 파일로 교체 (호출 측 변경 0)

**호출 측 변경 검증**:
```bash
# loader 패치 후 호출 측 함수가 그대로 동작하는지
grep -rn 'GetRandom\|LoadData\|ReadText' . | grep -v _test
# → 같은 signature면 OK
```

**메인테이너 거부 확률**: **낮음** (loader 패치는 fallback 동일 검증 시), **중간** (loader 시그니처 변경 시)

**작업량**: 1시간 (loader 1개 + 폴더별 데이터)

## 작업 순서 결정

### 권장 순서

```
[축 1] i18n YAML         ← 가장 안전, 가장 빠른 검증 가능
        ↓
[축 2] Lua l() 감쌈      ← 기존 헬퍼 있으면 patch만
        ↓
[축 3] 비-i18n 텍스트     ← loader 패치 + 데이터
        ↓
[축 4] Go UI 라벨        ← 가장 큰 영향, cycle 검증 후
```

### 의존성

- 축 1 (i18n YAML) → 다른 모든 축의 키 namespace 제공
- 축 2 (Lua) → 축 1의 YAML에 키 추가 → 번역
- 축 3 (텍스트 파일) → loader 패치 후 → 데이터 추가 (loader 먼저 작성 후 데이터)
- 축 4 (UI 라벨) → 축 1과 독립 (별도 ui.* 키 namespace)

### 병렬 가능

축 1과 축 4는 독립이라 병렬 작업 가능. 단, 같은 `assets/locals/ko/cards.yml`을 동시 수정하면 merge conflict → **단일 에이전트가 직렬로**.

## 사용자 시야 검증

각 축 작업 후 **PTY 텍스트 추출 검증**:
```bash
./scripts/pty-screen-text-extract.sh /tmp/eoe_ko.log
# → 한글 메뉴/카드/적 표시 확인
# → 잔여 영문 라벨 목록 (축 4 작업 후보)
```

## 작업량 추정

| 축 | 키 수 | 시간 | 메인테이너 거부 확률 |
|---|---|---|---|
| 1. i18n YAML | 50-200 | 1-2h | 낮음 |
| 2. Lua l() | 30-100 | 1-2h | 중간 |
| 3. 비-i18n 텍스트 | 100-500줄 | 1h | 낮음 |
| 4. Go UI 라벨 | 20-50 | 1h | 중간 |
| **총** | **200-800** | **4-6h** | **낮음 (단일 PR)** |

## 단일 PR vs 단계적 PR 결정

**단일 PR 선호 (사용자 신호)**:
- "100% 한글화 후 PR"
- "이 정도면 다 끝난 것 같아. 보내자"

**단계적 PR 선호 (사용자 시간 부족)**:
- "일단 카드+UI부터 보내고, 나머지는 후속 PR"
- "1차 PR = 카드, 2차 PR = 이벤트"

**판별**: 사용자가 명시적으로 어느 쪽 선호인지 처음에 확인.

## 검증 워크플로

```
[축 1] i18n YAML 작업
  └→ ./scripts/i18n-yaml-verify.sh (단위 테스트)
      → 100+ 키 PASS 확인
      └→ [축 2로 진행]

[축 2] Lua l() 감쌈
  └→ grep 'l() 미사용 영문' (남은 미번역 검색)
      → 0건 또는 디버그/test만 남음
      └→ [축 3로 진행]

[축 3] 비-i18n 텍스트 파일
  └→ go build (loader 패치 검증)
      └→ [축 4로 진행]

[축 4] Go UI 라벨
  └→ go build (모든 import 통과)
      └→ 게임 실행 + PTY 텍스트 추출
          → 한글 메뉴/카드/적 표시 확인
          → 잔여 영문 0개 확인
```

## end_of_eden 실측 (2026-07-28)

### 작업 범위

```
축 1: 96 키 (cards 22 + status_effects 12 + artifacts 10 + enemies 9 + events 18 + intents 9 + ui 14 + weapons 4)
축 2: 50+ Lua patch (events, equipment, enemies, _util)
축 3: 2 파일 (assets/gen/ko/loading_lines.txt 9줄 + merchant_lines.txt 104줄) + gen.go 12줄 패치
축 4: 30 라벨 (ui/menus/mainmenu 8, ui/menus/overview 5, ui/menus/merchant 4, ui/menus/gameview 5, ui/menus/gameover 6, ui/menus/carousel 1, ui/menus/lua_error 5, ui/menus/settings 1, cmd/game init 5 + title 1)
```

### 시간 분배 (실측)

| 단계 | 시작 → 완료 | 비고 |
|---|---|---|
| 사전 분석 + i18n 정찰 | 30분 | `i18n-architecture-reconnaissance.md` 절차 |
| 축 1 i18n YAML | 1시간 | base.yml 45 + cards.yml 53 키 |
| 축 2 Lua (events/enemies) | 2시간 | 30+ patch + 9개 이벤트 + 7개 적 |
| 축 3 텍스트 파일 + loader | 1시간 | loading + merchant + gen.go 패치 |
| 축 4 Go UI 라벨 | 1시간 | 30개 라벨 + cycle 검증 |
| **총** | **5.5시간** | 검증 + patch 사고 수정 포함 |

### 최종 검증

```
PASS: 239 / FAIL: 0 / TOTAL: 239
All Korean keys load correctly.

PTY 검증:
- 메인 메뉴 ✓ (한글)
- 완료! ✓ (한글)
- 영문 메뉴/라벨 0개 (사용자 시야)
```

## 관련 reference

- `references/i18n-architecture-reconnaissance.md` — 축 1 시작 전 i18n 로더 정찰
- `scripts/i18n-yaml-verify.sh` — 축 1 단위 테스트
- `scripts/pty-screen-text-extract.sh` — 축 4 후 사용자 시야 검증
- `references/four-axis-i18n-workflow.md` (이 파일)
