# Athena Crisis 한국어 fork — offline 빌드 검증 / Vercel 호스팅 / 자동전투 분기 레시피

> 이 문서는 2026-07-27 세션(`athena-crisis-kr` 워크스페이스, branch `main`, 푸시 커밋 `dcecb52`)에서 검증된 실전 절차를 정리합니다. SKILL.md 본문이 USER-OWNED라면 거기에 함정 문구를 추가하지 말고, 이 reference를 가리키는 한 줄 포인터만 직접 더하세요.

## 1. 빌드 명령 디코딩

`package.json`의 `build:offline`은 셸 체인입니다 (분해 필수):

```bash
rm -rf ./dist/offline
pnpm vite build --outDir ../dist/offline -c ./offline/vite.config.ts ./offline
rm -rf mobile/dist/offline
mkdir mobile/dist
cp -R dist/offline mobile/dist/offline
rm -rf electron/offline
cp -R dist/offline electron/offline
```

핵심: vite 실행이 성공하면 **Vercel 배포에 필요한 `dist/offline/index.html`은 이미 만들어진 상태**입니다. 이후 `cp -R dist/offline mobile/dist/offline` / `cp -R dist/offline electron/offline` 두 줄은 `mobile/`, `electron/` 디렉토리가 있어야 하고, 이 fork에서는 **둘 다 없으므로 exit 1**입니다.

## 2. 함정 — 빌드 실패로 오해하지 말 것

- **증상**: `pnpm build:offline` 끝에 `mkdir: mobile: No such file or directory` + `ELIFECYCLE Command failed with exit code 1`.
- **사실**: vite는 이미 성공했고 `dist/offline/index.html` (약 1.85 MB) 생성을 끝낸 상태. 후속 cp는 노이즈.
- **판단 기준**: `ls dist/offline/index.html`이 존재하면 배포 가능 상태. 빠진 mobile/electron은 이 fork scope 밖.
- **해결 옵션** (택 1):
  - (a) 그대로 둠 — Vercel은 `outputDirectory: dist/offline`만 본다.
  - (b) `package.json`의 `build:offline` 후속 cp 두 줄을 `mkdir -p mobile/dist electron` 가드로 감싸거나, `pnpm pkg set scripts.build:offline=` 으로 vite 빌드 부분만 별도 분리.
  - (c) `mobile/`, `electron/`을 빈 `.gitkeep`과 함께 추가.

## 3. vercel.json 최소 작성

Athena Crisis fork 같은 Vite 단일 HTML 산출물:

```json
{
  "framework": "vite",
  "buildCommand": "pnpm build:offline",
  "outputDirectory": "dist/offline",
  "installCommand": "pnpm install",
  "cleanUrls": true,
  "rewrites": [{ "source": "/(.*)", "destination": "/" }]
}
```

Vercel이 자동으로 인식하지 못하면 (`framework: vite` 미매칭) 셋 중 위 4개 키만 정확히 두면 빌드/배포는 동작합니다. `engines: node >=23` WARN은 Vercel이 알아서 처리합니다.

## 4. 한국어 번역 검증 — 어디를 봐야 하는가

| 빌드 | 한국어 인라인 위치 | 검증 grep |
|---|---|---|
| `pnpm build:offline` (`dist/offline/`) | **없음** — 이건 앱 오프라인 안내용 영문 스플래시 | 의미 없음 |
| `pnpm build:client` (`dist/ares/`) | 메인 클라이언트 본체, fbtee로 인라인됨 | `grep -E "취소\|다시 시도\|기본"` |
| `pnpm build:splash` (`dist/deimos/`) | 데모 사이트 | 데모 페이지 한정 |

> **교훈 — 한국어 검증 command 선택은 매우 신중해야**: 사용자가 "offline 빌드 결과물에 한국어 들어갔는지 확인" 같은 식으로 요청하면, 실제로는 **메인 클라이언트 빌드**를 봐야 한다는 뜻일 가능성이 큽니다. 시작 전에 확인 질문 두 개 — (a) 어느 디렉토리 호스팅이 최종 산출물인가, (b) 한국어 인라인 빌드 stage가 어디인가를 먼저 명확히.

번역 데이터 원천은 `ko_KR_translations.json` (fbtee 포맷, base64 토큰 키). `pnpm fbtee:prepare`로 `ares/translations/ko_KR.json` 생성. `source_strings.json`은 .gitignore 처리됨 (재추출 필요).

## 5. AutoBattleAI 분기 검증 체크리스트

`dionysus/AutoBattleAI.tsx` (169 lines) 분기 패턴 — fork 후 회귀 검증용:

- [ ] `AutoBattleMode = 'conservative' | 'aggressive'` 유니온 export
- [ ] `CONSERVATIVE_HEALTH_RATIO` vs `AGGRESSIVE_HEALTH_RATIO` 상수 분리 (Athena Crisis 현재 값: 0.5 vs 0.2)
- [ ] `hasLowHealthUnit(map, ratio)` 헬퍼 — `map.matchesPlayer` + `isCompleted()` 가드
- [ ] `ConservativeAutoBattleAI.action()` → 저체력 시 attack/capture 스킵 + 전체 50% 저체력이면 `EndTurnAction`
- [ ] `AggressiveAutoBattleAI.action()` → 70% critical이면 EndTurn, 그 외엔 `super.action(map)` (= DionysusAlpha 풀 플래너)
- [ ] `AIRegistry.tsx`에 `AIID.ConservativeAutoBattle` / `AIID.AggressiveAutoBattle` 등록, `published: true`
- [ ] **멀티플레이/소켓 경로에 import 없음을 grep으로 확인** — `grep -R "AutoBattle" artemis/ zeus/` 0건이어야 함
- [ ] `npm run tsc:check` (= `tsgo`)로 타입 통과

## 6. 커밋 / 푸시 패턴 (Athena Crisis fork)

- 큰 산출물(`ko_KR_translations.json` 약 365KB / 15,355 lines)은 의도적으로 **스테이징 후 커밋** (fbtee i18n 데이터는 자산)
- 임시 산출물(`ko_batch_*.json`, `_all_batch_combined.json`, `_build_translations.py`, `_additional_mappings.py`)은 .gitignore 후 별도 추적 안 함
- `pnpm-lock.yaml`이 자동 수정되어 있으면 **의도적으로 커밋에서 제외**하고 별도 PR로 다룸이 깔끔 — 의존성 lock은 fork 팀 리뷰 받아야 함

예시 커밋 메시지:
```
feat: vercel.json + AutoBattleAI + 한국어 안내 README

- vercel.json: Vite 정적 빌드 (buildCommand: pnpm build:offline, outputDirectory: dist/offline)
- dionysus/AutoBattleAI.tsx: Conservative(50% 임계치)/Aggressive(20% 임계치) 자동전투 AI
- dionysus/AIRegistry.tsx: AutoBattle 모드 두 종류 등록 (ID 4, 5, published)
- README.md: 라이브 데모 placeholder, 자동전투/멀티플레이 미지원 명시, 로컬 실행 가이드
- ko_KR_translations.json: 한국어 번역 데이터 (fbtee 포맷)
- scripts/generate_ko_translations.py: 배치 번역 스크립트
- .gitignore: ko_batch_*.json 임시 배치 파일 제외

참고: 멀티플레이/소켓 경로는 건드리지 않음. offline 빌드는 1.8MB 단일 HTML 생성 확인.
```

## 7. 한 줄 메타

- 워크스페이스: `/Users/mac/work/athena-crisis-kr`
- 원격: `https://github.com/sigco3111/athena-crisis-kr.git`
- 브랜치: `main`
- 최종 커밋 (이 세션): `dcecb52`
- base node: 22.23.1 (engines 요구 ≥23 — 빌드는 동작하지만 WARN, Vercel은 OK)
