# LLM Markdown 응답 파싱 (gpt-oss-120b reasoning 모델)

LLM backend를 reasoning 모델(`openai/gpt-oss-120b`, DeepSeek-R1, o1 등)로 교체하면 응답에 **markdown**(`**이름**` 헤더, `| 표 |` 행, `---` 분리선)이 자주 섞입니다. Stanford generative_agents 같은 OSS의 원본 파서는 단순 split 기반이라 이 응답을 처리하지 못하고 시뮬이 죽습니다.

## 증상 (실측)

```
TOODOOOOOO
**Isabella Rodriguez – 08:00 AM ~ 09:00 AM (총 60분) – 5분 단위 하위 작업**

| 순번 | 수행 작업 | 소요 시간 | 남은 시간 |
|------|-----------|-----------|-----------|
| 1) Isabella는 문을 열고 보안 시스템을 해제한다 (duration in minutes: 5, minutes left: 55)
2) Isabella는 조명 및 전자기기 전원을 켠다 (duration in minutes: 5, minutes left: 50)
3) Isabella는 오늘의 재고를 확인한다 (duration in minutes: 5, minutes left: 45)
...
-==- -==- -==-
Traceback (most recent call last):
  File "run_gpt_prompt.py", line 378, in __func_clean_up
    duration = int(k[1].split(",")[0].strip())
IndexError: list index out of range
```

원본 파서(`run_gpt_prompt.py`의 `__func_clean_up` 메서드)는 응답을 `\n` 분리 → 각 줄을 공백 split → `(duration in minutes:` 위치에서 split → 4번째 단어부터 task로 추출. 하지만:
- 마크다운 표 안에 `| 1) task (duration: 5, ...) |` 가 있으면 split[3:]이 깨짐
- `**이름**` 헤더가 첫 줄에 있으면 그것이 task[0]이 됨

## 해결 — regex-first + 라인 기반 폴백

```python
import re

def parse_task_decomp(gpt_response, prompt):
    # 1차: regex (DOTALL로 여러 줄 매칭)
    pattern = r'(\d+)\)\s*(.*?)\(duration in minutes:\s*(\d+)'
    matches = re.findall(pattern, gpt_response, re.DOTALL)
    cr = []
    if matches:
        for _, task, dur in matches:
            task = task.strip()
            if task.endswith("."):
                task = task[:-1]
            task = re.sub(r'\s+', ' ', task).strip()
            try:
                cr += [[task, int(dur)]]
            except ValueError:
                pass
        return cr

    # 2차: 라인 기반 폴백 (원본 split + markdown skip)
    temp = [i.strip() for i in gpt_response.split("\n")]
    cleaned = []
    for line in temp:
        if not line: continue
        if (line.startswith("**") and line.endswith("**")) or \
           line.startswith("|") or line.startswith("---") or \
           (line.startswith("**") and ("–" in line or "-" in line)):
            continue
        cleaned.append(line)
    if not cleaned:
        cleaned = [i.strip() for i in gpt_response.split("\n") if i.strip()]

    _cr = []
    for count, i in enumerate(cleaned):
        if count != 0:
            parts = i.split(" ")
            if len(parts) >= 4:
                _cr += [" ".join([j.strip() for j in parts][3:])]
            else:
                _cr += [i]
        else:
            _cr += [i]
    for i in _cr:
        k = [j.strip() for j in i.split("(duration in minutes:")]
        if len(k) < 2: continue
        task = k[0]
        if task[-1] == ".": task = task[:-1]
        try:
            duration = int(k[1].split(",")[0].strip())
            cr += [[task, duration]]
        except (ValueError, IndexError):
            continue
    return cr
```

## 검증 결과

| LLM 응답 형식 | regex 결과 | 라인 폴백 결과 |
|--------------|----------|----------|
| **마크다운 표 안** (`\| 1) task (duration: 5, ...) \|`) | 5개 작업 (25분) ✓ | (regex가 잡음) |
| **한국어 직접** (`1) 이서연은... (duration: 15, ...)`) | 3개 작업 (75분) ✓ | (regex가 잡음) |
| **영어 단답** (테스트 케이스) | regex 실패 | 라인 기반 작동 |

## 적용 위치

Stanford generative_agents에서 영향 받는 함수:
- `run_gpt_prompt.py`의 `__func_clean_up` 메서드 (모든 `safe_generate_response(func_clean_up=...)` 호출에 영향)
- 매 step마다 4-8회 호출되므로, 단 한 곳에서 깨져도 시뮬 전체가 멈춤

**실측 영향 step**: `plan.py:579`의 `generate_task_decomp` 호출이 가장 빈번. `convo.py`의 `agent_chat`도 비슷한 패턴이지만 markdown 헤더가 안 섞여서 영향 적음.

## 작은 보너스 정규식 패턴

### 한국어 조사 일관성 검증

```python
# "~않다" / "~안 ~" / 못 / 없 / 아니 패턴 일관성
NEGATION_KO = ["않", "안 ", "못 ", "없", "아니", "말고", "싫어하", "거부하", "반대하"]
def has_negation(text):
    return any(neg in text for neg in NEGATION_KO)
```

### 대명호 일관성 (English to Korean)

LLM이 혼용하는 경향: "이/그/저" → `이_페르소나`, `그_대상` 형태로 통일 가능.

### 다중 라인 JSON 파싱

reasoning 모델이 JSON을 `\`\`\`json ... \`\`\`` markdown으로 감싸는 경우:
```python
import re, json
def parse_json_block(text):
    m = re.search(r'```(?:json)?\s*(\{.*?\})\s*```', text, re.DOTALL)
    if m:
        try: return json.loads(m.group(1))
        except: pass
    # 폴백: { 부터 } 까지 추출
    m = re.search(r'\{.*\}', text, re.DOTALL)
    if m:
        try: return json.loads(m.group(0))
        except: return None
    return None
```

## 일반화 — 다른 OSS에 적용

| OSS | 영향 받는 함수 | 응답에 섞이는 markdown |
|-----|--------------|---------------------|
| Stanford generative_agents | `__func_clean_up` (4-5개) | `**이름**`, `\| 표 \|` |
| AI Town | `parseAction`, `parseDialogue` | `\`\`\`json\`\`\`` |
| Camel-AI | response parser | `**Bold**` (강조) |
| MetaGPT | action output parser | `\`\`\`python\`\`\`` |

**패턴**: LLM이 structured output을 만들 때 markdown으로 감싸는 것은 **universal** 함정. 모든 OSS의 response parser는 regex-first + markdown skip + JSON block 추출 패턴 적용 권장.

## 검증 도구 (재현 가능한 셀프 테스트)

`gpt_structure.py`에 추가:

```python
def test_markdown_parsing():
    gpt_response = '''**Isabella – 08:00 (60분)**

| 순번 | 작업 | 시간 |
|------|------|------|
| 1) Isabella는 문을 연다 (duration in minutes: 5, minutes left: 55)
2) Isabella는 조명을 켠다 (duration in minutes: 5, minutes left: 50)
'''
    prompt = "total duration in minutes 60"
    result = parse_task_decomp(gpt_response, prompt)
    assert len(result) == 2, f"expected 2, got {len(result)}"
    assert result[0][0] == "Isabella는 문을 연다"
    assert result[0][1] == 5
    print("✓ markdown parsing OK")
```

## 함정 — regex가 놓치는 케이스

### 함정 A: 영어 응답에서 `(duration in minutes: 5, ...)` 표기 변형

일부 LLM은 `duration: 5 min` 또는 `duration: 5분` 또는 `5 minutes` 같은 변형 출력. regex는 `duration in minutes:`만 잡음.

**해결**:
```python
# 더 관대한 패턴
pattern = r'(\d+)\)\s*(.*?)\(\s*duration[^)]*?(\d+)\s*(?:min|분|minutes)?'
```

### 함정 B: 소수점 duration

LLM이 가끔 `duration in minutes: 2.5` (소수점) 출력. `int(dur)` 실패.

**해결**:
```python
try:
    cr += [[task, int(float(dur))]]  # int(float(...))로 변환
except (ValueError, TypeError):
    pass
```

### 함정 C: 한국어 마침표 누락

한국어 LLM이 마침표 없이 "이서연은 문을 연다 (duration in minutes: 5, ...)" 출력. regex가 `(duration in minutes:` 까지만 greedy가 가져가 task에 마침표가 안 남음 → 정상.

단, task가 `\n`이나 마침표로 끝나면 다음 task와 합쳐질 수 있어 `re.DOTALL`로 안전하게 처리.
