# Evolve 한국어 fork — 부팅 검증 + 한국어 i18n 인프라 레퍼런스

> **출처**: 2026-07-27 evolve-kr fork 세션 실측 (`/Users/mac/work/evolve-kr`, 원격 `https://github.com/sigco3111/evolve-kr.git`, 첫 commit `397365a`).
> SKILL.md 본문이 USER-OWNED라면 함정 문구를 거기 추가하지 말고, 본 reference를 가리키는 한 줄 포인터만 더하세요.

## 1. 왜 이 fork 후보인가

| 항목 | 값 |
|------|---|
| 원본 | https://github.com/pmotschmann/Evolve |
| ⭐ | ~3k (인크리멘털 게임) |
| 라이선스 | **MPL-2.0** (Mozilla Public License 2.0) |
| i18n 시스템 | **strings.json 5-단계 폴백 패턴** — `strings/strings.json` (영문 베이스) + `strings/strings.<locale>.json`이 `Object.assign`으로 머지 |
| 한국어 상태 | **87.3% (10,164 / 11,641 키)** — `strings.ko-KR.json` 이미 존재, `src/locale.js`의 `locales` 상수에 `'ko-KR': '한국어'` 이미 등록됨 |
| 빌드 도구 | esbuild + less + csso (esbuild 0.25.0, less 3.13.0) |
| 부팅 검증 | ✅ HTTP 200 (8개 endpoint 모두) — 본 문서 §4 |
| 첫 commit | README 한국어 안내만 (LICENSE + 빌드 산출물 보존) |

**한국어화 가치 평가**:
- ✅ MPL-2.0 — file-level copyleft, fork 자유. LICENSE 보존만 의무
- ✅ 87.3% 번역됨 — **첫 세션부터 채울 게 아니라 검토/개선이 메인 작업**
- ✅ 외부 의존성 0 (jQuery/Vue/Buefy는 unpkg CDN)
- ✅ 한국 콘텐츠 추가 가치 — 한국적 컨셉·이벤트·항목 (korean-ballad-from-reference 같은 패턴 적용 가능)

## 2. 부팅 검증 워크플로 (실측 5분)

### 디렉토리 구조

```
evolve-kr/                              # repo root
├── index.html                          # 게임 진입점 (esbuild/main.js, jQuery/Vue CDN)
├── save.html                           # 세이브 매니저
├── wiki.html                           # 위키 진입점
├── src/                                # JS 모듈 (게임 + 위키)
│   ├── main.js, index.js               # 진입점
│   ├── locale.js                       # 🔑 i18n 헬퍼 + locales 상수 (L90~104)
│   ├── vars.js, actions.js, tech.js, races.js, jobs.js, resources.js, ...
│   └── wiki/                           # 위키 모듈 (arpa.js, basics.js, 32개)
├── strings/                            # 🌐 다국어 번역
│   ├── strings.json                    # 기본 (영문, 11,641 키)
│   ├── strings.ko-KR.json              # 한국어 (10,164 키, 803KB) ← 이미 채워져 있음
│   └── strings.<locale>.json           # 13개 언어
├── evolve/                             # 빌드 산출물 (git 추적됨)
│   ├── main.js                         # esbuild 결과 (~2.3MB)
│   ├── evolve.css                      # less + csso 결과
│   └── evolve.js                       # (?)
├── wiki/                               # 빌드 산출물 (wiki.js ~2.4MB + wiki.css)
├── lib/                                # 외부 라이브러리 (buefy.min.css, weather-icons, lz-string)
├── font/                               # 웹 폰트
├── buildEvolve.js                      # esbuild 스크립트 (entryPoints: ./src/main.js → evolve/main.js)
├── buildWiki.js                        # esbuild 스크립트 (./src/wiki/wiki.js → wiki/wiki.js)
├── buildEvolveDebug.js, buildWikiDebug.js
├── Dockerfile                          # nginx 8080 정적 호스팅
├── package.json                        # esbuild + less + servehere + csso-cli + gh-pages
└── LICENSE                             # MPL-2.0
```

### Step-by-step (실측 5분)

```bash
# [1분] 빈 디렉토리 + shallow clone + origin 정리 + gh repo create
mkdir -p /Users/mac/work/evolve-kr && cd /Users/mac/work/evolve-kr
git init -b main
# ⚠️ .git이 이미 있으면 clone 거부 — `mv .git /tmp/xxx.git.bak` 후 clone
git clone --depth 1 https://github.com/pmotschmann/Evolve.git .
git remote remove origin
gh repo create sigco3111/evolve-kr --public \
  --description "Evolve 한국어 + 한국 콘텐츠 (Vercel 정적 호스팅)" \
  --source=. --remote=origin --push=false
curl -s -o /dev/null -w "HTTP %{http_code}\n" "https://api.github.com/repos/sigco3111/evolve-kr"

# [3분] 빌드 도구만 직접 설치 (full `npm install`은 fail — §3 참조)
npm install --ignore-scripts \
  esbuild@0.25.0 less@3.13.0 servehere@1.7.0 csso-cli@4.0.2

# [1분] 빌드 4종
npm run evolve       # esbuild → evolve/main.js (2.3MB, 68ms)
npm run evolve-less  # less → evolve.css
npm run wiki         # esbuild → wiki/wiki.js (2.4MB, 48ms)
npm run wiki-less    # less → wiki.css

# [1분] 부팅 검증 — npx servehere -c (port 4400)
npx servehere -c &
SERVE_PID=$!
sleep 2
for url in / /evolve/main.js /evolve/evolve.css /strings/strings.ko-KR.json \
           /lib/lz-string.min.js /save.html /wiki.html /wiki/wiki.js; do
  printf "%-40s " "$url"
  curl -sI "http://localhost:4400$url" | head -1
done
kill $SERVE_PID

# [1분] 한국어 번역 검증 (JSON 파싱 + 미번역 키 카운트)
python3 -c "
import json
en = json.load(open('strings/strings.json'))
ko = json.load(open('strings/strings.ko-KR.json'))
print(f'EN: {len(en)} keys / KO: {len(ko)} keys / 커버리지: {len(ko)/len(en)*100:.1f}%')
print(f'미번역: {len(set(en)-set(ko))} / KO 고유: {len(set(ko)-set(en))}')
"

# [1분] 첫 commit + push (shallow clone 때문에 첫 push fail — §3 참조)
git branch -m master main  # upstream default가 master라 자동 설정됨
git add README.md
git -c user.name="sigco3111" -c user.email="sigco3111@users.noreply.github.com" \
  commit -m "docs: 한국어 안내 README 추가

Evolve 한국어 fork의 목적·디렉토리 구조·번역 위치·빌드 명령을
한국어로 정리. ...
- 라이선스: MPL-2.0 보존"

# 첫 push는 fail (orphan commit) — upstream 추가 후 unshallow
git remote add upstream https://github.com/pmotschmann/Evolve.git
git fetch --unshallow upstream  # 4,691 커밋 복원
git push -u origin main          # race condition 1회 재시도 → "Everything up-to-date"
git ls-remote origin             # 397365a refs/heads/main 확인
```

## 3. 함정 — `npm install` fail + phantom npm 패키지

### 증상

```
npm error Error: Cannot find module 'node-darwin-arm64/package.json'
npm error Require stack:
npm error - /Users/mac/.../node_modules/node/installArchSpecificPackage.js
```

`node_modules/` 통째로 생성 안 됨. exit 0 (npm이 종료코드 무관), `package.json`에 `dependencies.node` + `dependencies.npmcli` 라인이 원인.

### 원인

`pmotschmann/Evolve`의 `package.json`은 2018년경 작성된 것으로 보이며, `dependencies`에 의도하지 않은 npm 패키지 두 개가 들어 있음:
- `"node": "^16.1.0"` — Node.js 자체 버전을 참조하려는 의도였을 가능성 (잘못된 의존성 선언)
- `"npmcli": "^1.2.2"` — npm CLI 모듈 참조 (잘못된 의존성 선언)

이 두 의존성을 만족시키려고 `node-bin-setup`이 arch별 바이너리 (`node-darwin-arm64`)를 받아오는데, Node 22 + npm 10 환경에서는 더 이상 작동하지 않음. **postinstall 스크립트에서 module-not-found 에러 → npm install 전체 fail**.

### 해결

build/runtime에 실제로 필요한 4개 도구만 `--ignore-scripts`로 별도 설치:

```bash
npm install --ignore-scripts \
  esbuild@0.25.0 \
  less@3.13.0 \
  servehere@1.7.0 \
  csso-cli@4.0.2
# → "added 208 packages in 1s"
```

`--ignore-scripts`는 postinstall 스크립트를 건너뛰지만 의존성 패키지 자체는 설치함. `node-bin-setup`이 깨져도 esbuild/less/servehere/csso는 정상.

### 근본 수정 (upstream PR용)

```json
// package.json에서 이 두 줄 삭제
"dependencies": {
- "esbuild": "0.25.0",
- "node": "^16.1.0",          // ← 삭제
- "npmcli": "^1.2.2",         // ← 삭제
+ "esbuild": "0.25.0"          // devDependencies로 이동
}
```

`esbuild`는 devDependencies에 이미 있지만 `dependencies`에도 중복 선언되어 있음. 정리하면 `npm ci` 정상 작동.

### 예방 (다른 fork 후)

시작 전에 5분 진단:

```bash
# 1) 의심 의존성 식별
cat package.json | python3 -c "import json,sys; d=json.load(sys.stdin); print(d.get('dependencies',{}))"
# → "node", "npmcli", "core-js" 같은 메타 이름이 dependencies에 있는지

# 2) npm view로 실제 존재 확인 + 최신 버전
for pkg in node npmcli core-js; do
  echo -n "$pkg: "
  npm view $pkg version 2>&1 | head -1
done
# 존재해도 *의도가 잘못됨* — Node 버전 자체를 참조하려는 의미가 dependencies에 들어간 것
```

## 4. 함정 — shallow clone push fail (`index-pack failed`)

### 증상

```
remote: fatal: did not receive expected object 7994fe3e5c0e7fb547d6fa6e021170a01e69c7d9
error: remote unpack failed: index-pack failed
 ! [remote rejected]   main -> main (failed)
```

`--depth 1`로 받은 첫 커밋의 **부모 hash**를 GitHub가 검증하려 하지만 로컬에는 없음. 빈 저장소에도 부모 검증은 강제됨.

### 해결 (3단계)

```bash
# 1) 원본 upstream 추가
git remote add upstream https://github.com/pmotschmann/Evolve.git

# 2) unshallow — 원본의 전체 4,691 커밋 복원
git fetch --unshallow upstream
# 또는 처음부터 --depth 1을 안 썼다면 이 단계 불필요

# 3) push 재시도
git push -u origin main
# → 첫 시도에 "cannot lock ref 'refs/heads/main': reference already exists" race condition
# → 한 번 더 push → "Everything up-to-date" 또는 정상 push
# → 검증: git ls-remote origin | grep refs/heads/main
```

### race condition 디버깅

`refs/heads/main: reference already exists` 에러는 첫 push 시도가 실제로는 성공했지만 lock 파일 충돌 때문에 두 번째 시도가 거부된 케이스. **`git ls-remote origin`으로 실제 원격 상태 확인** — 커밋 hash가 보이면 push 성공한 것.

### 예방

```bash
# 처음부터 shallow를 쓰지 않음
git clone https://github.com/pmotschmann/Evolve.git .   # full clone
# 또는
git clone --no-single-branch https://...                 # 모든 브랜치 받기

# shallow가 강제 필요한 경우 (디스크/네트워크 절약)
git clone --depth 1 https://... .
# → push 직전에 반드시 unshallow (위 3단계)
```

## 5. 부팅 검증 매트릭스 (HTTP 200 모두 확인)

`npx servehere -c` (port 4400) 띄운 후 다음 8개 endpoint를 모두 검증:

| Endpoint | 의미 | 비고 |
|---|---|---|
| `/` | 게임 진입점 | Content-Length 3230, index.html 직접 서빙 |
| `/evolve/main.js` | esbuild 게임 번들 | 2.3MB, type="module" |
| `/evolve/evolve.css` | less + csso 게임 CSS | |
| `/strings/strings.ko-KR.json` | 한국어 번역 | 803KB, JSON 파싱 가능 |
| `/lib/lz-string.min.js` | 세이브 압축 | CDN 안 쓰고 로컬 서빙 |
| `/save.html` | 세이브 매니저 | |
| `/wiki.html` | 위키 진입점 | |
| `/wiki/wiki.js` | esbuild 위키 번들 | 2.4MB |

**한국어 JSON 검증** 주의: `curl http://... | head -5 | python3 -m json.tool`은 첫 5줄만 잘려서 **JSON 파싱 실패처럼 보임**. `python3 -c "import json; json.load(open('strings/strings.ko-KR.json'))"`로 **파일 직접** 검증할 것.

## 6. 한국어 번역 — 어디를 봐야 하는가

### 이미 있는 인프라 (수정 불필요)

| 파일 | 역할 |
|---|---|
| `strings/strings.ko-KR.json` | 한국어 번역 10,164 키 (87.3% 커버리지) |
| `src/locale.js` L101 | `'ko-KR': '한국어'` 이미 등록됨 |
| `src/locale.js` L42~88 | `getString()` 함수: `strings/strings.json` + `Object.assign(..., strings.${locale}.json)` 폴백 |
| `src/locale.js` L6~40 | `loc(key, variables)`: 토큰(`%0`, `%1`, ...)을 변수로 치환 |

### 미번역 키 추출

```python
import json
en = json.load(open('strings/strings.json'))
ko = json.load(open('strings/strings.ko-KR.json'))
missing = sorted(set(en) - set(ko))
print(f"미번역 {len(missing)}개:")
for k in missing[:30]:
    print(f"  {k}")
# → portal_throne_of_evil_skill, portal_casino_flair, ...
```

### KO 고유 키 (검토 필요)

EN에는 없고 KO에만 있는 키 29개: `tech_slave_pens`, `tech_casino`, `city_slave_pen_effect` 등. EN 업데이트 누락일 가능성 → upstream에 알릴 가치 있음.

### 검증 도구

`strings/checkStrings.py` — 누락 키 자동 체크. `python3 strings/checkStrings.py`로 실행.

## 7. README 한국어 안내 — 작성 패턴

원본 `README.md`는 보존하고 **한국어 안내 박스**를 상단에 추가하는 패턴. 라이선스 + 빌드 명령은 원본 그대로 두되, 한국어화 목적·번역 위치·디렉토리 구조는 새 섹션으로.

자세한 템플릿은 이 세션에서 작성된 `/Users/mac/work/evolve-kr/README.md` 참조 (77줄 추가, 60줄 제거). 핵심:
- `strings/strings.ko-KR.json` (이미 10,164 키)
- `src/locale.js` `locales` 상수 (L101)
- `npm run build` / `npm run serve` (localhost:4400)

## 8. Vercel 호스팅 (다음 세션 작업)

`vercel.json`은 아직 미작성. 단일 페이지 정적 호스팅:

```json
{
  "framework": null,
  "buildCommand": "npm run build",
  "outputDirectory": ".",
  "cleanUrls": true,
  "rewrites": [{ "source": "/(.*)", "destination": "/index.html" }]
}
```

또는 `outputDirectory: dist`로 별도 분리 (`npm run build` + `cp -r *.html evolve lib font strings wiki dist` 패턴은 upstream `npm run deploy`에서 따옴).

**주의**: `npm install` 실패가 Vercel에서도 재현될 수 있음 → `buildCommand`를 `npm install --ignore-scripts esbuild@... less@... servehere@... csso-cli@... && npm run build`로 우회하거나, `package.json`의 `dependencies.node`/`npmcli` 줄을 미리 삭제한 후 push.

## 9. 후속 권장 작업 우선순위

1. **즉시** (5분): `package.json`의 `dependencies.node`/`npmcli` 라인을 삭제한 cleanup commit (upstream PR 가치)
2. **단기** (1일): `strings/checkStrings.py`로 미번역 1,506개 키 목록 추출 → 번역 작업 큐
3. **중기** (3일): 한국 콘텐츠 추가 (한국적 컨셉, 이벤트, 항목) — `korean-ballad-from-reference` 패턴 적용
4. **장기** (1주): Vercel 배포 + 도메인 연결, `npm run deploy` (gh-pages) 대신 Vercel pipeline

## 10. 메트릭 (실측)

| 항목 | 값 |
|---|---|
| Shallow clone 시간 | 3~5초 |
| shallow + push fail 시간 | 30~60초 (unshallow 후 재시도) |
| `npm install` fail → 우회 설치 시간 | 30초 (208 packages) |
| esbuild 게임 빌드 | 68ms (2.3MB) |
| esbuild 위키 빌드 | 48ms (2.4MB) |
| LESS 게임 CSS 빌드 | 1초 |
| LESS 위키 CSS 빌드 | 1초 |
| `npx servehere` 부팅 시간 | 1초 |
| HTTP 200 검증 (8 endpoint) | 2초 |
| 한국어 번역 검증 (JSON + 커버리지) | 1초 |
| 첫 commit → push | 1분 (race condition 포함) |
| **총 작업 시간** | **~10분** |

## 11. 한 줄 메타

- 워크스페이스: `/Users/mac/work/evolve-kr`
- 원격: `https://github.com/sigco3111/evolve-kr.git`
- 브랜치: `main` (master에서 리네임)
- 최종 커밋 (이 세션): `397365a`
- base node: 22.23.1 (engines 요구 ≥16)
- 라이선스: MPL-2.0 (file-level copyleft — fork 자유)