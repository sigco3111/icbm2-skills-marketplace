# Direct LLM dict 기반 번역 파이프라인 — 실전 노트 (2026-07-27)

`athena-crisis-fbtee-batch-translation.md`(LibreTranslate API 기반)와 짝. 사용자가 "직접 LLM이 한국어로 번역"을 명시적으로 요청할 때 쓰는 패턴.

## 1. 언제 이 파이프라인을 쓰나

| 상황 | 파이프라인 |
|---|---|
| **fbtee 인프라 없음** (Plain JSON batches) | ✅ Direct LLM dict |
| **fbtee 있음, 한국어 키 0%** | 둘 다 OK (Direct LLM이 더 빠름) |
| **fbtee 있음, LibreTranslate 공개 인스턴스 살아있음** | ❌ fbtee batch (기존 노트) |
| **오프라인 / API 키 없음** | ✅ Direct LLM dict (이미 매핑 dict로 작업) |
| **번역 품질 최우선** | ❌ fbtee + LibreTranslate (자동) — 후속 LLM polish 세션 |
| **사용자가 "직접 LLM이 번역" 명시** | ✅ Direct LLM dict |

## 2. 입력 데이터 구조

Athena Crisis의 140개 batch 파일:
```json
[
  {
    "hash": "AopFz/4APFEzAVsMK9rJuA==",
    "text": "Automatic",
    "desc": "Description for automatically selecting an AI"
  },
  ...
]
```

**핵심 필드**:
- `hash`: base64 fb-locale hash 키 — 번역 매핑의 식별자
- `text`: 번역 대상 (영문)
- `desc`: 개발자 힌트 (영문) — 톤/용도 결정에 사용 (예: "Cancel button label (as short as possible, ideally one word)")

**desc 활용 예**:
- `"Cancel button label (as short as possible, ideally one word)"` → "취소" (단일어)
- `"Generic error message"` → "앗, 문제가 발생했습니다."
- `"Defeat {number of units} more units without losing a unit to secure the {starName} star."` → placeholder 보존: "유닛을 잃지 않고 {number of units}대를 더 처치하면 {starName} 별을 확보합니다."

## 3. 출력 데이터 구조 (3개 동기화 필요)

### a) Per-batch translated JSON (140개)

```json
[
  {
    "hash": "AopFz/4APFEzAVsMK9rJuA==",
    "ko": "자동",
    "text": "Automatic",
    "desc": "Description for automatically selecting an AI"
  },
  ...
]
```

**왜 `text` + `desc` 보존하나**: 후속 LLM polish 세션에서 (a) 어떤 영문이 번역됐는지 추적 (b) 게임 컨텍스트 검증에 사용.

### b) Consolidated translations JSON (1개)

fbtee 스키마 형식 (`athena-crisis-fbtee-batch-translation.md` §1 참조):
```json
{
  "fb-locale": "ko_KR",
  "translations": {
    "AopFz/4APFEzAVsMK9rJuA==": {
      "tokens": {},
      "types": {},
      "translations": [
        {
          "translation": "자동",
          "variations": []
        }
      ]
    },
    ...
  }
}
```

### c) Python 빌드 스크립트 (재현 가능)

`_build_translations.py` 패턴:
```python
T = { "Automatic": "자동", "Default": "기본", ... }

# 통합 파일 빌드
all_items = []
for f in sorted(glob.glob('ko_batch_*.json')):
    data = json.load(open(f))
    for item in data:
        all_items.append(item)

# 배치 처리
batch_results = {}
for i, item in enumerate(all_items):
    text = item['text']
    ko = T.get(text, text)  # fallback to original
    batch_idx = i // 10
    batch_results.setdefault(batch_idx, []).append({
        'hash': item['hash'], 'ko': ko,
        'text': text, 'desc': item.get('desc', '')
    })

# 출력
for idx in sorted(batch_results.keys()):
    with open(f'ko_batch_{idx:04d}_translated.json', 'w') as f:
        json.dump(batch_results[idx], f, ensure_ascii=False, indent=2)

# Consolidated 갱신
translations_file = json.load(open('ko_KR_translations.json'))
for items in batch_results.values():
    for item in items:
        h = item['hash']
        if h in translations_file['translations']:
            old = translations_file['translations'][h]['translations'][0]['translation']
            if old != item['ko'] and not any('가' <= c <= '힣' for c in old):
                translations_file['translations'][h]['translations'][0]['translation'] = item['ko']
json.dump(translations_file, open('ko_KR_translations.json', 'w'), ensure_ascii=False, indent=2)
```

## 4. 매핑 dict 작성 워크플로

### 4.1 통합 파일 먼저 작성

```bash
python3 -c "
import json, glob
all_items = []
for f in sorted(glob.glob('ko_batch_*.json')):
    for item in json.load(open(f)):
        all_items.append(item)
json.dump(all_items, open('_all_batch_combined.json', 'w'), ensure_ascii=False, indent=2)
print(len(all_items))  # 1398
"
```

### 4.2 게임 텍스트 카테고리 파악 (1단계 페이지네이션)

`python3 -c "import json; data=json.load(open('_all_batch_combined.json')); [print(f'{i:4d} | {it[\"hash\"][:10]} | {it[\"text\"][:120]}') for i, it in enumerate(data[:100])]"`

대부분 게임 UI의 카테고리는:
- 0-99: 기본 UI / 시스템
- 100-199: 모드 / 라운드 / 매크로 placeholder
- 200-299: 크리스탈 / 라운드 / 라벨
- 300-499: 스킬 / 캠페인 / 캐릭터 이름
- 500-599: 캐릭터 이름 (한국어 음역)
- 600-749: 유닛/건물/장소 이름
- 750-857: 건물/필드/캐릭터 설명 (긴 본문)
- 858-999: 캐릭터 소개 / 유닛 설명
- 1000-1397: 짧은 태그 / {tag} 패턴 / 통보

### 4.3 카테고리별 dict 작성

```python
# 1) 짧은 UI 라벨 (50-100개씩 묶음)
T.update({
    "Automatic": "자동",
    "Default": "기본",
    ...
})

# 2) 긴 본문 (100-200자) — desc 참고해서 톤 결정
T.update({
    "There was an error preparing the assets...": "이 플랫폼에서 ... 지금은 ...",
    ...
})

# 3) 매칭 안 되는 항목 보고 추가 (incremental)
exec(open('_build_translations.py').read().split('# 배치 처리')[0])
unmatched = [t for t in all_texts if t not in T and t.isascii()]
# → unmatched 보고 2차 dict 추가 → 재실행
```

### 4.4 1398/1398 매칭 확인

```bash
python3 _build_translations.py 2>&1 | tail -5
# Matched: 1398/1398
# Unmatched (fallback to original): 0
```

## 5. 결정적 함정 5가지

### 함정 1: 따옴표 안 공백 (`Map "{mapName} "` vs `Map "{mapName}"`)

원본: `'Map "{mapName} " was saved.'` (따옴표 안에 공백)
매핑 작성: `'Map "{mapName}" was saved.'` (공백 빠짐) → 매칭 실패

**진단**:
```python
import repr
print(repr(text))  # 'Map "{mapName} " was saved.' (앞뒤 공백 정확히 보임)
```

**해결**: dict 키 작성 시 `repr()`로 정확한 공백 확인. 통합 파일 만들 때 `json.dump(..., indent=2)`로 텍스트 보존.

### 함정 2: placeholder 변형 — `{previous items}, {following items}` vs `{previous items} ; {following items}`

같은 의미를 다른 placeholder 패턴으로 표현한 항목이 여러 개 있음:
```json
{previous items}, {following items}
{previous items}; {following items}
{previous items} • {following items}
{list of items}, and {last item}
{list of items} and {last item}
{list of items}, or {last item}
{list of items} or {last item}
```

**해결**: 각 변형마다 별도 매핑 항목. 8개 변형 × 한국어 번역 = 8개 dict entry.

### 함정 3: 빌드 스크립트 안 `T.update(...)` 동기화

`_build_translations.py`의 `T` dict가 거대해지면 (~1,500 항목) 편집 시 위치 추적 어려움.

**해결 패턴**: 분리 파일
```python
# _build_translations.py
import importlib.util
spec = importlib.util.spec_from_file_location("addmap", "_additional_mappings.py")
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
T.update(mod.ADDITIONAL)
```

`_additional_mappings.py`는 단일 `ADDITIONAL = {...}` dict만 보유. 작은 매핑 단위로 split 가능:
- `_ui_labels.py`: 0-199 카테고리
- `_character_names.py`: 500-601
- `_unit_descriptions.py`: 750-910

각각 `T.update()` 호출. 파일 크기 1MB 이하 유지.

### 함정 4: Python dict repr 출력 시 따옴표 이스케이프 오류

대형 dict (1,500+ entry)를 `repr()`로 출력 → 따옴표가 escape된 형태로 파일에 박힘 → `ast.literal_eval()` 실패 또는 syntax error.

**해결**: `ast.literal_eval()`로 안전 로드:
```python
import ast
content = open('_additional_mappings.py').read()
ADD = ast.literal_eval(content.split('ADDITIONAL = ', 1)[1].split('\n')[0])
```

또는 `json.dump(ADD, open('out.json', 'w'))`로 JSON으로 저장 → 빌드 스크립트에서 `json.load()`.

### 함정 5: 한국어 fallback 처리 — placeholder 텍스트

`{previous items}, {following items}` 같은 placeholder 텍스트는 한국어화 불필요 → fallback 동작:
```python
has_korean = any('가' <= c <= '힣' for c in text)
has_special = not text.isascii()
if has_korean or has_special or re.match(r'^[\d\s\-+.%,]+$', text):
    ko = text  # 그대로 유지
else:
    ko = T.get(text, text)  # fallback
```

이 fallback이 없으면 placeholder 텍스트가 dict에 없어서 매칭 실패 → 한 번 더 빌드해야 함.

## 6. 품질 노트

**완벽한 번역이 아님**. 1,398개 중 placeholder 보존 (`{name}`, `{charges}`)이 가장 흔한 실수. 단일 단어 (1-3자) 게임 용어도 컨텍스트 없이 일관 매핑 어려움.

**후속 polish 세션 권장**:
1. 빌드 산출물에서 한국어 빠진 항목 grep: `python3 -c "import json; [print(it['text']) for it in json.load(open('ko_batch_0000_translated.json')) if not any('가' <= c <= '힣' for c in it['ko'])]"`
2. 부자연스러운 번역은 사용자 피드백 받아 2차 dict 갱신 → 재빌드
3. 최종 polish 후 fbtee 변환 (`pnpm fbtee:translate`)

## 7. 즉시 적용 규칙

1. **fbtee 없거나 "직접 LLM" 명시 시** → 본 파이프라인
2. **140 batch × 10 = 1,398** — 매핑 dict는 1,500+ 항목으로 시작 (placeholder 변형 포함)
3. **desc 활용**: 톤 결정의 핵심 신호 ("Cancel button" → 단일어 / "Generic error" → 완곡체)
4. **반복 매칭 패턴**: `python3 _build_translations.py | grep "Unmatched"` → unmatched 보고 2차 dict 추가
5. **3개 산출물 동기화**: `_all_batch_combined.json` + `ko_batch_*_translated.json` × 140 + `ko_KR_translations.json`
6. **fallback 안전망**: 한국어/숫자/특수문자만 있는 텍스트는 그대로 유지 (placeholder 보존)
7. **repr()로 공백/따옴표 검증**: dict 키 작성 시 `repr(text)` 출력

## 8. 다른 fbtee / LÖVE / Phaser 게임에 적용

| 게임 종류 | 적용 방식 |
|-----------|----------|
| **Athena Crisis (fbtee)** | 본 파이프라인 → `ko_KR_translations.json` → fbtee 변환 가능 |
| **JSON manifest 게임** (sango, SNKRX Lua dict) | 본 파이프라인 → ko/*.json 직접 작성 (ko/ 모드팩 패턴) |
| **소스 코드 임베디드** (Three.js, Phaser) | 본 파이프라인 → `t('key')` 추출 후 dict 매핑 (i18n-nobuild-js-pattern.md §Stage 3 참조) |
| **C++ gettext PO** | fill_empty.py 패턴 (cpp-game-koreanization §fill_empty.py) |

핵심은 **"1,000+ 텍스트를 어떻게 빠르고 일관되게 번역할 것인가"** 문제 → 매핑 dict + 카테고리별 페이지네이션 + incremental 매칭이 공통 해법.