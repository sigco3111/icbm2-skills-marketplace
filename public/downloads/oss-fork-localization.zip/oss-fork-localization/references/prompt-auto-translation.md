# 프롬프트 자동번역 + 검수 워크플로우 (Korean Prompt L10n)

> LLM 기반 OSS (Generative Agents 등)의 `.txt` 프롬프트 파일을 일괄 한국어로 자동번역 + 자동 검수하는 패턴. `oss-fork-localization` Stage 3.5 (페르소나 → 프롬프트) 단계에서 사용.

## 📍 적용 시점

- Stage 3 (페르소나 시드) 완료 후
- Stage 4 (UI) 직전
- active 프롬프트 파일이 **20~100개** 정도일 때 (직접 번역은 비현실적, 자동화 필요)

## 🎯 핵심 발견: v3_ChatGPT = dead code

원본 `run_gpt_prompt.py`에서 import하는 프롬프트 디렉토리 검출 시, **`########` 주석으로 마킹된 라인은 dead code** (legacy).

```python
# run_gpt_prompt.py (원본)
prompt_template = "persona/prompt_template/v2/wake_up_hour_v1.txt"  # ✅ active
prompt_template = "persona/prompt_template/v3_ChatGPT/agent_chat_v1.txt ########  # ❌ dead
```

→ **초기 추산의 절반이 실제 작업 대상** (Stanford generative_agents: 48개 → 35개, 42,319자 → 24,039자).

## 🔍 active 프롬프트 식별 패턴

```python
import re

def get_active_prompts():
    runner = "run_gpt_prompt.py"
    with open(runner) as f:
        content = f.read()
    active = set()
    for line in content.split("\n"):
        if "prompt_template =" in line:
            if not line.lstrip().startswith("#"):  # 주석 라인 제외
                cleaned = line.split("########")[0]  # dead code 마커 제거
                if '"' in cleaned:
                    parts = cleaned.split('"', 2)
                    if len(parts) >= 2:
                        val = parts[1]
                        # 'persona/prompt_template/' prefix 정규화
                        if val.startswith("persona/prompt_template/"):
                            val = val[len("persona/prompt_template/"):]
                        active.add(val)
    return sorted(active)
```

**여기서 prefix 정규화가 핵심** — 원본은 `persona/prompt_template/v2/...`인데 base path가 이미 `persona/prompt_template/`이라서, 그냥 더하면 `persona/prompt_template/persona/prompt_template/...`가 됨.

## 🤖 LLM 자동번역 파이프라인

`translate_prompts_kr.py` — NIM gpt-oss-120b 일괄 호출.

### Translation Guide (프롬프트 핵심)

```python
TRANSLATION_GUIDE = """당신은 영문 프롬프트를 한국어로 번역하는 전문가입니다.

=== 번역 규칙 ===
1. **코드 변수 보존 (절대 변경 금지)**:
   - `<NAME_0>`, `[ ... ]`, `{ ... }`, `!<INPUT N>!`, `###`
   - `\\n` (이스케이프 시퀀스), 함수 호출 형식
   - JSON 키/값, 정규식 패턴

2. **콘텐츠 (영어 본문)**:
   - 자연스러운 한국어 (~습니다체 기본, 명령문은 ~하세요)
   - 어려운 영문 어구는 풀어서 설명
   - 예시 이름을 한국 이름으로 변경 가능

3. **한국어 조사 처리**:
   - 받침 있으면 "은/이", 없으면 "는/가" 자동
   - "와/과", "을/를" 정확히

4. **번역 스타일**:
   - 기계번역 말투 X
   - 자연스러운 한국어 LLM 프롬프트 OK

5. **출력 형식**:
   - 오직 번역된 텍스트만 출력 (설명 금지)
   - 원본 포맷 (들여쓰기, 줄바꿈) 보존
"""
```

### 메인 루프

```python
import time, os, sys
sys.path.insert(0, ".")
from gpt_structure import ChatGPT_request

KR_DIR = "prompt_template_kr"
os.makedirs(KR_DIR, exist_ok=True)

success, skip, fail = 0, 0, 0
for i, rel in enumerate(active, 1):
    src = f"prompt_template/{rel}"
    dst = f"{KR_DIR}/{rel}"
    if os.path.exists(dst):
        skip += 1  # 재실행 시 비용 절약
        continue

    t0 = time.time()
    prompt = TRANSLATION_GUIDE + "\n=== 번역할 텍스트 ===\n" + open(src).read() + "\n=== 끝 ===\n\n위 텍스트를 한국어로 번역하세요. 번역 결과만 출력:"
    response = ChatGPT_request(prompt)

    if response and response != "ChatGPT ERROR" and len(response) > 50:
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        with open(dst, "w", encoding="utf-8") as f:
            f.write(response.strip() + "\n")
        success += 1
    else:
        fail += 1
    print(f"  [{i:2d}/{len(active)}] {rel} ({os.path.getsize(src)}자) -> {os.path.getsize(dst) if os.path.exists(dst) else '?'}자 ({time.time()-t0:.1f}초)")
    time.sleep(0.5)  # NIM rate limit 보호
```

### 실측 결과 (2026-07-14 generative_agents)

| 항목 | 값 |
|------|-----|
| 활성 파일 | 35개 (24,039자) |
| 자동번역 소요 | 4.7분 |
| 성공 | 28 + 스킵 6 + 실패 1 |
| 평균 응답 시간 | 7-15초/파일 |
| 성공률 | 28/29 = 96.6% |

## ⚠️ 함정 1: 큰 파일 LLM 응답 제한

`task_decomp_v3.txt` (2584자)는 **2회 연속 호출 실패** → LLM 응답 길이/품질 한계.

**해결**: chunked 번역 또는 max_tokens 증가 (`gpt_structure.py`에서 `max_tokens=4096`).

```python
# 단일 호출 시 충분한 토큰
def GPT4_request(prompt):
    return _nim_chat(
        [{"role": "user", "content": prompt}],
        temperature=0.8,
        max_tokens=4096,  # 기본 2048 → 4096
    )
```

## ⚠️ 함정 2: 코드 손실 자동 검출 필수

LLM 자동번역은 **`!<INPUT 11>!` 같은 코드 표식을 드롭**하는 경우가 있음. (Stanford 사례: 5개 INPUT 마커 손실).

**자동 검수 도구 패턴** (`review_prompts_kr.py`):

```python
import re

def extract_code_markers(text):
    """번역에서 보존되어야 할 코드 표식 추출."""
    markers = set()
    for m in re.findall(r"!<INPUT\s+\d+>!", text): markers.add(m)
    for m in re.findall(r"<NAME_\d+>", text): markers.add(m)
    for m in re.findall(r"<commentblockmarker>###</commentblockmarker>", text): markers.add(m)
    for m in re.findall(r'"[a-z_]+":\s', text): markers.add(m.strip().rstrip(":"))
    for m in re.findall(r"\[\d+-\d+\]", text): markers.add(m)
    return markers

def check_preservation(src_text, dst_text):
    src_markers = extract_code_markers(src_text)
    dst_markers = extract_code_markers(dst_text)
    return src_markers - dst_markers, dst_markers - src_markers, len(src_markers)
```

## ⚠️ 함정 3: 한국어 어색 패턴 자동 검출

```python
def check_korean_naturalness(text):
    issues = []
    patterns = [
        (r"는\s+를", "조사 어색: ~는를 연속"),
        (r"가\s+을", "조사 어색: ~가를 연속"),
        (r"을\s+이", "조사 어색: ~을이 연속"),
        (r"\bthe\s+", "번역 안 된 'the' 발견"),
        (r"\bis\s+", "번역 안 된 'is' 발견"),
        (r"\bare\s+", "번역 안 된 'are' 발견"),
    ]
    for pat, msg in patterns:
        for m in re.finditer(pat, text):
            issues.append((msg, text[max(0, m.start()-15):m.end()+15]))
    return issues
```

→ "을이" 연속 같은 어색한 조사, "Describe the" 같은 부분 번역 자동 발견.

## 🔄 자동 검수 → 재번역 루프

```bash
# 1. 자동 검수 실행 (코드 손실 + 어색 조사 파일 식별)
python3 review_prompts_kr.py
# 출력: total=35, translated=35, code_loss=4, korean_issues=6, clean=26

# 2. CODE_LOSS / KR_ODD 파일만 추출 → dst 삭제 → 재번역
for f in v1/action_location_sector_v1.txt v2/decide_to_react_v1.txt; do
  rm "prompt_template_kr/$f"
done

# 3. 재번역 (건너뛰기 캐시 덕분에 손상 파일만)
python3 translate_prompts_kr.py

# 4. 재검수 → clean 비율 확인
python3 review_prompts_kr.py
```

## 📂 디렉토리 구조 (작업 후)

```
prompt_template/                # 원본 (영문, 35개 active)
  ├─ v1/*.txt
  ├─ v2/*.txt
  ├─ v3_ChatGPT/*.txt          # dead code, 번역 불필요
  └─ safety/*.txt

prompt_template_kr/            # ✅ 번역본 (34/35, 1개 미번역)
  ├─ v1/*.txt
  ├─ v2/*.txt
  ├─ v3_ChatGPT/*.txt
  └─ safety/*.txt

prompt_template_kr_review/     # 검수 리포트 (.md)
  ├─ v1__action_location_sector_v1.txt.md  # 원본 + 번역 + MISSING 마커
  └─ ...
```

## 🔌 run_gpt_prompt.py 라우팅 (실측 검증, 2026-07-14)

현재 `prompt_template_kr/`는 **디스크에만 존재**. 시뮬레이션에서 사용하려면 `run_gpt_prompt.py`의 경로를 일괄 변경하거나, `generate_prompt()` wrapper에서 자동 라우팅:

```python
# Option A: 경로 직접 변경
prompt_template = "persona/prompt_template_kr/v2/wake_up_hour_v1.txt"  # 35개 모두

# Option B: gpt_structure.py generate_prompt()에서 자동 (권장)
def generate_prompt(curr_input, prompt_lib_file):
    # 한글 디렉토리에 같은 파일 있으면 우선 사용
    if prompt_lib_file.startswith("persona/prompt_template/"):
        kr_path = prompt_lib_file.replace("persona/prompt_template/", "persona/prompt_template_kr/")
        if os.path.exists(kr_path):
            prompt_lib_file = kr_path
    # ... 기존 로직
```

→ **Option B 권장** — 영문/한글 토글 쉽게, A/B 테스트 가능.

### ⚠️ 함정 4: 단순 replace가 cwd-의존성 함정에 걸림 (NEW, 2026-07-14)

첫 시도 단순 replace는 시뮬레이션이 cwd=`reverie/backend_server/persona/`인데 prompt_lib_file이 `persona/prompt_template/...` 더블 prefix라서 **영문 원본도 못 찾음** (FileNotFoundError).

**해결**: multi-candidate 후보 경로 + 절대경로 fallback.
```python
def generate_prompt(curr_input, prompt_lib_file):
    if prompt_lib_file.startswith("persona/prompt_template/"):
        ko_rel = prompt_lib_file[len("persona/prompt_template/"):]
        candidates = [
            os.path.join("persona", "prompt_template_kr", ko_rel),  # cwd-relative
            os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                         "prompt_template_kr", ko_rel),  # module-absolute
            os.path.join("prompt_template_kr", ko_rel),  # cwd=persona
        ]
        for c in candidates:
            if os.path.exists(c):
                prompt_lib_file = c
                break
    # ... 기존 로직
```

### ✅ End-to-end dry-run 검증 (실측)

라우팅 패치 후 검증:
```python
inputs = ['이서연은 도서관에서 공부하고 있다', '오전 9시', '이서연이 자전거를 싣고 라이딩을 한다']
prompt = generate_prompt(inputs, 'persona/prompt_template/v2/whisper_inner_thought_v1.txt')
# → 한국어 프롬프트 자동 로드: "이서연은 도서관에서 공부하고 있다에 대한 진술로 다음 생각을 번역하세요..."

result = ChatGPT_safe_generate_response(prompt, '김민준은 도서관에서 공부 중이다',
    'JSON 형식으로만 출력', repeat=2, ...)
# → "이서연은 오전 9시에 도서관에서 공부하고 있다." (자연스러운 한국어 출력)
```

검증 4축:
1. ✅ 라우팅: 영문 경로 → 한국어 프롬프트 자동 로드
2. ✅ INPUT 치환: `!<INPUT N>!` → 실제 값
3. ✅ NIM 호출: gpt-oss-120b 한국어 응답 생성
4. ✅ 자연스러운 한국어 출력

### 🚦 한국어 자동 라우팅의 다중 cwd 시나리오

| 시뮬레이션 cwd | 원본 path | 한국어 자동 후보 |
|----------------|-----------|-----------------|
| `reverie/backend_server/persona/` | `persona/prompt_template/v2/...` | `prompt_template_kr/v2/...` (cwd-direct) |
| `reverie/backend_server/persona/prompt_template/` | `persona/prompt_template/v2/...` | `persona/prompt_template_kr/v2/...` (cwd-relative) |
| 외부 (`~/work/`) | `persona/prompt_template/v2/...` | module-absolute path (os.path.abspath(__file__)) |

→ multi-candidate 패턴이 **이 3가지 시나리오 모두 커버**.

## 📊 작업량 추산 (확정)

| 항목 | 자동번역 | 검수 + 재번역 | 총 |
|------|---------|--------------|-----|
| 30개 미만 | 3-5분 | 5분 | 10분 |
| 30-50개 | 5-10분 | 15분 | 25분 |
| 50-100개 | 10-20분 | 30분 | 50분 |
| 100개+ | 20-40분 | 1시간 | 1.5시간 |

## 💡 위임 가능

자동번역 + 자동 검수 + 재번역 루프는 **완전 자동화 가능** (위임). 작업자 역할:
- 사용자: "한국어 프롬프트 만들어줘" 한마디
- 자동: active 식별 → LLM 번역 → 자동 검수 → 손상 파일 재번역 → 리포트
- 사용자 검토: 의심스러운 5~10개 (전체의 20%)만 직접 검토
