# 🎮 Godot 4 한국어화 Preflight + i18n 워크플로

> Praytic/youtd2 (Godot 4.3, MIT code + CC-BY-NC assets, GDScript) 사례 (2026-07-28) 기반.
> **"tr() 호출 많다 = i18n 구조 있다" 함정**과 **"에셋 .import만 있다 = 빌드 가능" 함정**을 새 recipe로 명시.

## 언제 사용하나

다음 모두 충족할 때:
- 후보 repo가 `project.godot` (Godot 4) + `.gd` 스크립트 + `assets/` 디렉토리
- `tr("KEY_NAME")` 호출이 코드에 다수 존재 (≥50개)
- `.po`/`.translation` 파일이 0~3개 (영문/소수 언어만)
- README에 **에셋이 별도 다운로드** 명시 (Google Drive / Hugging Face / itch.io)

## 🚨 5대 핵심 함정 (preflight 5분 안에 판별)

### 함정 1: tr() 많음 ≠ 번역 인프라 있음
- `tr("WAVE_STATUS_COLUMN_LEVEL")`이 **수백 개 호출되어도** `.translation` 파일이 0개일 수 있음
- 즉, 모든 tr() 키가 **영문 그대로** 노출됨
- **체크**: `find . -name "*.po" -o -name "*.translation"` → 0개면 greenfield
- **체크**: `project.godot`의 `[internationalization]` 섹션에 `locale/translations=` 배열 확인

### 함정 2: `assets/`에 .import만 = 게임 플레이 불가
- Godot은 `.png`/`.mp3` 본체를 git에 안 넣고 `.import` 메타만 커밋
- **에셋 실제 파일은 별도 위치** (Google Drive / releases 페이지)
- CONTRIBUTING.md 또는 README에 Drive 링크가 있음
- **에셋 없으면** `Godot --import`만 통과하고 **실행하면 텍스처 누락으로 깨짐**
- **체크**: `find assets/ -name "*.png" | wc -l` → 0개면 .import만 있는 상태

### 함정 3: 라이선스 2-tier (코드 vs 에셋)
- `LICENSE` (루트) = MIT / GPL 등 코드 라이선스
- `assets/LICENSE.md` (서브) = **CC-BY-NC 4.0** (NonCommercial) 가능성 매우 높음
- **NC = 유료 Steam/itch.io/SaaS 배포 금지**, 무료 fork는 OK
- **체크**: `cat LICENSE` + `cat assets/LICENSE.md` 둘 다 확인
- **fork 시**: `LICENSE.MODIFIED` 파일에 코드/에셋 라이선스 분리 명시

### 함정 4: CLA (Contributor License Agreement) 저작권 양도
- 일부 OSS는 `CONTRIBUTING.md`에 CLA 명시: "By submitting your PR, you assign copyright to project maintainer"
- **PR 보내면 내가 쓴 코드의 저작권 잃음** → fork-first가 안전
- **체크**: `grep -i "copyright\|assign\|transferable" .github/CONTRIBUTING.md`
- **CLA 있으면 → 독립 fork 유지, PR 안 함**

### 함정 5: `popup/item_count = N` (Godot 3 잔재)
- Godot 4는 `popup/item_N/text` entries로 **자동 카운트**
- `item_count = N`이 명시되어 있으면 Godot 4.3은 마지막 값 사용하지만 parser 충돌 가능
- **새 언어 추가 시**: `item_count` 줄을 **삭제**하고 `popup/item_N/text`만 추가

## 5단계 Preflight (5분)

### 1단계: 프로젝트 구조 + Godot 버전 (30초)
```bash
# Godot 버전 요구
grep "config/features" project.godot  # e.g. "4.3"
which godot  # 로컬 Godot 버전
godot --version  # 4.7.1 등

# 에셋 상태
echo "PNG: $(find assets/ -name "*.png" | wc -l)"
echo "OGG: $(find assets/ -name "*.ogg" | wc -l)"
echo "import files: $(find assets/ -name "*.import" | wc -l)"

# tr() 키 개수
grep -rohE 'tr\("[A-Z_][A-Z0-9_]*"\)' --include="*.gd" . | sort -u | wc -l
grep -rohE 'Utils\.tr\("[A-Z_][A-Z0-9_]*"\)' --include="*.gd" . | sort -u | wc -l
```

### 2단계: 라이선스 + CLA Cross-Check (1분)
```bash
# 코드 라이선스
head -3 LICENSE
# 에셋 라이선스 (서브 LICENSE.md가 있을 수 있음)
find . -name "LICENSE.md" -o -name "LICENSE.txt" 2>/dev/null | head -5
# CLA 확인
grep -iE "copyright|assign|transferable|grant" .github/CONTRIBUTING.md | head -10
```

### 3단계: 에셋 다운로드 위치 + 방식 (1분)
```bash
# CONTRIBUTING에서 에셋 링크 추출
grep -E "drive\.google\.com|dropbox|huggingface|itch\.io" CONTRIBUTING.md .github/CONTRIBUTING.md README.md 2>/dev/null

# Google Drive 폴더면 gdown --json + curl 병렬 (37배 빠름)
# gdown --folder 자체는 30분+ 걸림 (직렬, 1파일 5초)
~/.local/bin/gdown --folder "<DRIVE_URL>" --json > /tmp/filelist.json
# → URL + path 리스트 추출
python3 -c "
import json
data = json.load(open('/tmp/filelist.json'))
for d in data: print(d['url'], d['path'])
" > /tmp/urls.tsv
# → curl 병렬 (16 workers, 49초 vs 30분)
xargs -P 16 -n 2 -I {} bash -c 'curl -sSLo "/tmp/assets/$(echo {} | cut -d" " -f2)" "$(echo {} | cut -d" " -f1)"' < /tmp/urls.tsv
```

### 4단계: i18n 구조 + 한국어 갭 측정 (1분)
```bash
# 기존 translation 파일
find . -name "*.translation" 2>/dev/null
# texts.csv (csv_translation importer source)
find . -name "texts.csv" 2>/dev/null
# ko 컬럼 존재?
head -1 $(find . -name "texts.csv" | head -1)  # "keys","en","zh","it" → ko 없으면 추가
# 한국어 잔존률 (polish 가치 측정)
python3 -c "
import json
d = json.load(open('/tmp/ko.json'))  # texts.ko-KR.json 류
total = len(d)
not_ko = [k for k,v in d.items() if v and not any(0xAC00<=ord(c)<=0xD7A3 for c in v) and len(v)>5]
print(f'Polish rate: {len(not_ko)*100/total:.1f}% ({len(not_ko)}/{total} residue)')
"
```

### 5단계: 빌드 검증 (1분 30초)
```bash
# headless import (에디터 안 뜨고 .tscn 메타 생성)
/path/to/godot --headless --quit --import 2>&1 | tail -5
# → "ERROR: Cannot open file 'res://...'" 없으면 통과
# → ".translation" 파일 자동 생성됨 (texts.csv → texts.{lang}.translation)

# check-only (스크립트 파싱 검증)
/path/to/godot --headless --quit --check-only 2>&1 | tail -5

# 직접 실행 (메인 scene은 project.godot의 run/main_scene)
MAIN=$(grep "run/main_scene" project.godot | sed 's/.*"\(.*\)"/\1/')
/path/to/godot --path . "$MAIN"  # macOS에 창 뜸
```

## 한국어 번역 적용 4단계

### 1단계: texts.csv에 ko 컬럼 추가
```python
import csv
KO = {"Blademaster": "검의 대가", "Acid Coating": "산성 코팅", "GAME_STATS_COLUMN_NAME": "이름", ...}
with open('assets/texts/texts.csv', encoding='utf-8', newline='') as f:
    reader = csv.reader(f); header = next(reader); rows = list(reader)
new_header = header + ['ko']
new_rows = []
for row in rows:
    en = row[1] if len(row) > 1 else ''
    ko = EN_TO_KO.get(en, '')  # 또는 row[0]가 key면 UI_KEYS.get(row[0], '')
    new_rows.append(row + [ko])
with open('assets/texts/texts.csv', 'w', encoding='utf-8', newline='') as f:
    w = csv.writer(f, quoting=csv.QUOTE_ALL)
    w.writerow(new_header); w.writerows(new_rows)
```

### 2단계: texts.csv.import + project.godot에 ko 등록
```ini
# assets/texts/texts.csv.import
files=["...texts.en.translation", "...texts.zh.translation", "...texts.it.translation", "...texts.ko.translation"]
dest_files=[...동일...]

# project.godot
[internationalization]
locale/translations=PackedStringArray("res://assets/texts/texts.zh.translation", ..., "res://assets/texts/texts.ko.translation")
```

### 3단계: Language enum에 KOREAN 추가
```gdscript
# src/enums/language.gd
enum enm { ENGLISH, CHINESE, ITALIAN, KOREAN }
static var language_map: Dictionary = {
    Language.enm.ENGLISH: "en", Language.enm.CHINESE: "zh",
    Language.enm.ITALIAN: "it", Language.enm.KOREAN: "ko"
}
static var language_option_map: Dictionary = { ENGLISH: 0, CHINESE: 1, ITALIAN: 2, KOREAN: 3 }
static var language_option_locale_map: Dictionary = { 0:"en", 1:"zh", 2:"it", 3:"ko" }
```

### 4단계: settings_menu.tscn에 언어 옵션 추가
```ini
[node name="Language" type="OptionButton" parent="..."]
selected = 0
popup/item_0/text = "English"
popup/item_1/text = "中文"
popup/item_1/id = 1
popup/item_2/text = "Italiana"
popup/item_2/id = 2
popup/item_3/text = "한국어"
popup/item_3/id = 3
# item_count = 4  ← 삭제! Godot 4는 자동 계산
```

## 🚨 폰트 Fallback 3가지 패턴 (한글 □□□ 해결)

**패턴 A: SystemFont (.tres)** — 가장 간단, macOS/Windows/Linux 모두 처리
```ini
# resources/theme/wc3_fallback_font.tres
[gd_resource type="SystemFont" format=3]
[resource]
font_names = PackedStringArray("Apple SD Gothic Neo", "Noto Sans CJK KR", "Noto Sans KR", "Arial Unicode MS")
allow_system_fallback = true
```

**패턴 B: theme_override_fonts/font** — 특정 노드만 다른 폰트 (영문 디자인 보존)
```ini
[ext_resource type="SystemFont" path="res://resources/theme/wc3_fallback_font.tres" id="1_sys"]
[node name="Language" type="OptionButton" ...]
theme_override_fonts/font = ExtResource("1_sys")
```

**패턴 C: font .import의 fallbacks** — 작동 안 함 (Godot 4 한계)
- `fallbacks=["path/to/font"]` (String) → ERROR "Unable to convert from String to Object"
- `fallbacks=[ExtResource(...)]` (.import는 sub-resource 못 가짐) → 파싱 실패
- **이 방법은 쓰지 말 것**

**default_font 교체 시 부작용**:
- `default_font`를 SystemFont로 바꾸면 게임 전체 글리프가 AppleSDGothicNeo로 → Friz Quadrata 디자인 (워3/디아블로 분위기) 사라짐
- **권장**: `default_font`는 Friz 유지 + `theme_override_fonts/font`로 Language OptionButton만 SystemFont

## 🚨 Runtime Locale Refresh 한계

`TranslationServer.set_locale("ko")` 호출 후:
- **새로 tr() 호출되는 텍스트**: ko 키 있으면 한국어 반환, 없으면 en fallback
- **이미 화면에 그려진 tr() 결과**: 자동 갱신 안 됨 (Label.text는 캐시됨)
- **해결**: locale 변경 후 settings_menu를 hide + show 트리거, 또는 게임 재시작
- **Game locale 재시작 없이 강제 갱신**은 게임 코드 수정 필요 (대규모 변경)

## Godot 4 vs Godot 3 차이점 (i18n 관련)

| 항목 | Godot 3 | Godot 4 |
|---|---|---|
| 번역 importer | `csv` + .po | `csv_translation` + .csv (4컬럼) |
| `item_count` 속성 | 필수 | 자동 계산 (명시하면 파싱 충돌 가능) |
| 폰트 fallback | String path | Resource reference (sub-resource 또는 ext_resource) |
| `tr()` 키 형식 | 자유 | 보통 UPPER_SNAKE_CASE |
| enum syntax | `enum { A, B }` | `enum enm { A, B }` (이름 강제) |
| `--main-pack` 빌드 | 있음 | `--export-release "name" out` |

## 정리 워크플로

```bash
# 1) 다운로드 파일 정리
rm -rf /tmp/ytd2-assets /tmp/filelist.json /tmp/urls.tsv
# 2) .godot 캐시는 보존 (다음 빌드에서 import 생략 가능)
ls -la /Users/mac/work/ytd2-kr/.godot/  # 121MB 정도, OK
# 3) 불필요한 import 캐시 정리 (선택)
find .godot/imported -size 0 -delete
```

## 검증 체크리스트

- [ ] Godot 버전 호환 (project.godot 요구 ≤ 로컬 설치)
- [ ] 코드 라이선스 ≠ 에셋 라이선스 분리 확인
- [ ] CLA 없음 (또는 fork-first 결정)
- [ ] 에셋 다운로드 완료 (Google Drive / 49초)
- [ ] `headless --import` 통과
- [ ] `texts.ko.translation` 자동 생성됨
- [ ] 메인 scene 직접 실행 시 게임 창 뜸
- [ ] Language 콤보박스에 4개 옵션 표시
- [ ] "한국어" 선택 시 한국어 tr() 키 매칭
- [ ] 한글이 □□□ 안 됨 (theme_override_fonts/font 또는 SystemFont)

## 학습 기록

- **2026-07-28 (ytd2)**: Praytic/youtd2 한국어화 — Godot 4.3 + 870개 tr() + greenfield i18n
  - 5대 함정 모두 preflight에서 발견했어야 (CLA, CC-BY-NC 에셋, .import만, 472 Drive 파일, item_count)
  - SystemFont (AppleSDGothicNeo) fallback이 한글 □□□ 해결의 정석
  - theme_override_fonts/font를 Language OptionButton에만 적용 → 영문 디자인 보존
  - runtime locale refresh는 게임 코드 수정 필요 → 1차 범위 밖
  - curl 병렬 다운로드: gdown 30분+ vs curl -P 16 49초 (37배)
