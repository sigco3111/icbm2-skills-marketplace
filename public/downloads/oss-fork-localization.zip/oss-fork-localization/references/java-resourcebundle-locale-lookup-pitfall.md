# Java ResourceBundle Locale.lookup 함정 (2026-07-28, TripleA 사례)

## 증상

Java 게임 (TripleA, 12,628 strings 중 59 properties 기반)의 한국어화가 안 됨:
- `ui_ko.properties` JAR 안에 정상 포함됨 (5909 bytes)
- 시스템 locale이 `ko_KR`
- `LANG=ko_KR`, `LC_ALL=ko_KR` 환경변수 설정됨
- `-Duser.language=ko -Duser.country=KR` JVM 옵션 전달
- 그럼에도 게임 UI는 **영어로** 표시

## Root Cause: `Locale.lookup`의 RFC 4647 lookup algorithm

`I18nResourceBundle.java`는 `Locale.lookup()`을 사용:

```java
private static final Locale locale =
    Locale.lookup(getSupportedLanguageRange(), Arrays.asList(Collator.getAvailableLocales()));
```

여기서 `getSupportedLanguageRange()`는:
```
en-US;q=1.0, de-DE;q=0.5, ko-KR;q=0.5
```

`Locale.lookup()`은 RFC 4647 lookup algorithm 사용:
- 우선순위 weight가 높은 locale 선택
- **`en-US;q=1.0`이 절대 우선**이라 시스템 locale이 `ko`여도 영어 매칭
- 한국어는 `q=0.5`라 시스템이 매칭 후보에 있어도 영어가 이김

**작은 Java probe로 확인**:
```java
HashMap<Locale, Double> supported = new HashMap<>();
supported.put(Locale.US, 1.0);
supported.put(Locale.KOREA, 0.5);
supported.put(Locale.GERMANY, 0.5);
// range: "en-US;q=1.0,ko-KR;q=0.5,de-DE;q=0.5"
Locale result = Locale.lookup(ranges, available);  // → en_US (always!)
```

## 해결: `Locale.getDefault()` 직접 매칭

`I18nResourceBundle.java`의 static locale 초기화를 직접 매칭으로 교체:

```java
private static final Locale locale = computeLocale();

private static Locale computeLocale() {
    final Locale system = Locale.getDefault();
    final String lang = system.getLanguage();
    if ("ko".equals(lang)) {
        return Locale.KOREA;
    }
    if ("de".equals(lang)) {
        return Locale.GERMANY;
    }
    return Locale.US;
}
```

이게 `Locale.lookup`보다 단순하지만 결정적. 시스템 locale이 한국어면 무조건 한국어 properties 로드.

## 한국어 properties 4단계 등록 (전부 필수)

`ui_ko.properties`만 만드는 것으로는 안 됨. 4단계 모두 필요:

1. **Locale 등록** (`I18nResourceBundle.java`)
   ```java
   newMapSupportedLocales.put(Locale.KOREA, 0.5);
   // ...
   return Arrays.asList(Locale.ENGLISH, Locale.GERMAN, Locale.KOREAN);
   ```

2. **properties 파일 생성**
   - 기존 `ui_de.properties` 형식 참고
   - `ui_ko.properties` (UTF-8, 59 keys 등)

3. **Locale 매칭 메서드** (Lookup 함정 회피)
   - `computeLocale()` 같이 `Locale.getDefault()` 직접 매칭

4. **JAR 포함 확인**
   ```bash
   unzip -l build/libs/game-headed-*.jar | grep ui_.*properties
   # i18n/games/strategy/engine/framework/ui_ko.properties  (있어야 함)
   ```

## 진단 체크리스트 (한국어 안 나올 때)

순서대로 확인:

- [ ] 1단계: `ui_ko.properties`가 JAR 안에? → `unzip -l ... | grep ko`
- [ ] 2단계: `I18nResourceBundle.java`에 `Locale.KOREA` 등록? → `grep Locale.KOREA`
- [ ] 3단계: `Locale.lookup` 결과가 `ko_KR`로 나옴? → 작은 Java probe 실행
- [ ] 4단계: `computeLocale()` 같은 직접 매칭 메서드 있음?
- [ ] 5단계: 시스템 locale이 `ko_KR`? → `defaults read -g AppleLocale`
- [ ] 6단계: 게임 재실행 후 main panel 텍스트 확인

## 한국어 번역 양이 적을 때 현실

TripleA 사례 (2026-07-28):
- 12,628 strings 중 **properties 기반 59개만**
- 나머지 12,569 strings는 **Java String literals** (`getString()` 같은 래퍼 없음)
- i18n 문서 (docs/development/i18n_languages.md)도 "5% (650 strings)만 목표"라고 명시
- 즉 **properties 등록 + 59 keys 한국어화**가 1차 작업의 끝
- 2차 작업 (12,628 strings 추출)은 큰 PR — upstream에 받아들여질지 미지수

## TripleA 빌드/실행 명령 (재사용 가능)

```bash
# Java 설치 (TripleA는 JDK 25 요구 — AGENTS.md는 17 명시지만 outdated)
brew install openjdk@25
export JAVA_HOME=/opt/homebrew/opt/openjdk@25
export PATH=$JAVA_HOME/bin:$PATH

# 빌드 (3분 30초 첫 빌드, 40초 incremental)
cd /Users/mac/work/triplea-kr
./gradlew :game-headed:build -x test --no-daemon --console=plain

# 실행 (Swing UI)
java -jar game-app/game-headed/build/libs/game-headed-2026-07.16.1.jar
```

## 빌드 환경 진단 명령 (재사용 가능)

```bash
# 1) 실제 module path 확인 (AGENTS.md outdated 가능성)
./gradlew projects | grep Project

# 2) 실제 JDK 버전 확인 (AGENTS.md outdated 가능성)
grep -r "JavaVersion\|languageVersion" build.gradle.kts gradle/build-logic/ 2>/dev/null

# 3) i18n 자원 실제 갯수
find . -name "*.properties" -o -name "*.po" -o -name "*.json" -path "*lang*"

# 4) i18n code literals 갯수
grep -r "getText\|ResourceBundle" --include="*.java" . | wc -l
```

## lessons learned

1. **Java i18n은 단순히 properties 파일 추가한다고 안 됨** — 코드 레벨 Locale 등록 필수
2. **`Locale.lookup`의 RFC 4647 우선순위가 시스템 locale보다 우선** — 직접 매칭이 안전
3. **빌드 후 shadow JAR에 i18n 파일 포함 여부 검증 필수** — `unzip -l` 확인
4. **AGENTS.md는 outdated 가능성 큼** — `./gradlew projects`로 실제 module path 확인
5. **JDK 버전도 AGENTS.md outdated 가능** — `build.gradle.kts` 직접 확인
6. **Java String literals는 translation patch로 처리 못 함** — properties 추출은 별도 PR
