# i18n Architecture Reconnaissance (Pre-Translation Phase 0.5)

> 2026-07-28, BigJk/end_of_eden 실측. **번역 시작 전 i18n 로더 코드를 먼저 읽으면 작업 범위 + 함수정 + 첫 PR 가치를 30분 안에 확정 가능**. 안 읽고 시작하면 1시간 후 "이게 아니라 다른 건데" 깨달음.

## 왜 필요한가

기존 fork-localization 사전 확인(5축)은 **외부 시그널**(라이선스, 한국어 진행도, CLA)에 집중. 하지만 **번역 작업을 어디에 어떤 형태로 작성해야 하는지**는 알 수 없음:

- YAML? properties? JSON? PO? Lua의 `l()` 헬퍼?
- Locale 코드 길이 제한? (`ko` vs `ko_KR`)
- Fallback 동작? (없는 키는 en으로? 빈 문자열? 키 그대로?)
- 하드코딩 텍스트는 어디까지? (Lua inline vs YAML override)
- 카드/상태이상/아티팩트 같은 게임 데이터는 YAML로 덮어쓸 수 있는 구조인가?

**이 5가지 모르면**: 첫 PR이 50% 작업한 후 "잘못된 위치에 작성" 깨달음 → 다 지우고 다시 시작하는 비용.

## 5분 reconnaissance 절차

### 1단계: i18n 모듈 위치 찾기 (30초)

```bash
# Godot
find . -path '*/addons/*/l10n/*' -o -name '*.po' -o -name '*.translation'

# LÖVE
find . -path '*/lang/*' -o -name 'T.lua' -o -name 'lang.lua'

# Godot 4
find . -name 'project.godot' -path '*godot*'  # TranslationLocale 옵션 확인
grep -A 3 'translation' project.godot

# JS/TS webapp
grep -rn 'i18next\|react-i18next\|vue-i18n\|Lingui' package.json
find . -path '*/locales/*' -o -path '*/i18n/*' -name '*.json'

# Java
find . -name '*.properties' -path '*i18n*' -o -name 'I18nResourceBundle*'
grep -rn 'Locale\.' src/ --include='*.java' | head -10

# Go (게임/앱)
find . -name 'localization*.go' -o -name 'i18n*.go' -o -name 'translations*.go'
grep -rn 'AddFolder\|AddFile\|loadLocale\|t\.T\(' system/ --include='*.go' | head -5
```

### 2단계: 로더 핵심 코드 읽기 (2분)

가장 중요한 파일 1-2개를 **전체** 읽는다. 패턴:

**Go (end_of_eden 실측)**:
```go
// system/localization/localization.go 핵심 30줄
func (l *Localization) AddFile(file string) error {
    var parsed map[string]map[string]any
    yaml.Unmarshal(data, &parsed)
    for local, v := range parsed {
        if len(local) != 2 {
            return fmt.Errorf("invalid locale: %s", local)  // ← 2글자 강제!
        }
        ...
        walk(found, v, "")  // ← nested key → dot-separated
    }
}

func (l *Localization) Get(locale, key string, defaults ...string) string {
    if _, ok := l.locals[locale]; !ok {
        return l.Get("en", key, defaults...)  // ← fallback
    }
    if _, ok := l.locals[locale][key]; !ok {
        return l.Get("en", key, defaults...)  // ← fallback
    }
    return l.locals[locale][key]
}
```

**확인할 5가지**:
1. **Locale 코드 형식**: `ko` vs `ko-KR` vs `ko_KR` (어떤 거 받나)
2. **포맷**: YAML/JSON/properties/PO 중 무엇
3. **키 구조**: nested (점 분리) vs flat
4. **Fallback 정책**: ko → en → key? ko → ko_KR → en?
5. **자동 폴더 스캔**: `assets/locals/<code>/*.yml` 같은 패턴?

### 3단계: 하드코딩 텍스트 위치 파악 (2분)

```bash
# Lua 하드코딩 (게임 이벤트/대화)
grep -rE 'name\s*=\s*"' assets/scripts/ | head -20
grep -rE 'description\s*=\s*"' assets/scripts/ | head -10

# Java Swing literals (이미 식별된 패턴)
grep -rE 'new JLabel\("' src/ --include='*.java' | wc -l
grep -rE 'JOptionPane\.showMessageDialog' src/ --include='*.java' | wc -l

# C# WinForms literals
grep -rE 'this\.\w+\.Text\s*=\s*"' --include='*.cs' | head -10

# TypeScript inline
grep -rE '(text|label|title)\s*[:=]\s*["'"'"']' src/ --include='*.ts' --include='*.tsx' | head -10
```

**핵심 판별**: hardcoded가 **l() 헬퍼/T()/tr()**로 감싸져 있으면 → i18n 인프라 활용 가능. **그냥 `"문자열"`**이면 → 리팩토링 필요 (별도 PR).

### 4단계: 한국어 기존 진행도 측정 (30초)

```bash
# GitHub 검색
gh search issues "repo:OWNER/REPO korean OR 한국어" --limit 5
gh search prs "repo:OWNER/REPO korean OR 한국어" --limit 5

# 코드베이스 내 한국어 흔적
find . -path '*ko*' -o -path '*korean*' | head -10
grep -rl '[가-힣]' . --include='*.json' --include='*.yml' --include='*.properties' 2>/dev/null | head -10
```

**판별**:
- 0건 → **greenfield** (한국어 파일 추가 자체가 첫 PR 가치)
- 5건 미만 + 부분 key → polish (추가 번역 PR 가치 큼)
- 10건+ + 활발 → 다른 후보 또는 신중 (메인테이너가 컨트리뷰터 받으려 안 할 수 있음)

### 5단계: 첫 PR 범위 결정 (30초)

위 4단계 결과로 다음 표 작성:

| 카테고리 | 위치 | 첫 PR 가능? | 작업량 |
|---|---|---|---|
| UI 설정 라벨 | `<i18n>/<code>/base.yml` | ✅ | ~50 keys |
| 카드/아이템 | `<i18n>/<code>/cards.yml` (override 패턴) | ✅ | ~30 keys |
| 상태이상 | 같은 override 패턴 | ✅ | ~15 keys |
| 이벤트 내러티브 | Lua 하드코딩, `highlight()` 마커 포함 | ❌ 별도 리팩토링 | N/A |
| 상인/로딩 텍스트 | `assets/gen/*.txt` | ⚠️ loader 패치 필요 | ~100 lines |

## 실측 사례 (BigJk/end_of_eden, 2026-07-28)

### 1단계 결과
- `system/localization/localization.go` 발견
- `assets/locals/<code>/*.yml` 패턴 확인 (de만 존재)

### 2단계 결과 (로더 30줄)
- ✅ Locale은 **2글자 강제** → `ko` OK, `ko-KR` 안됨
- ✅ YAML 포맷, nested → dot key (`cards.MELEE_HIT.name`)
- ✅ Fallback: ko → en → key
- ✅ `AddFolder("./assets/locals")` 자동 스캔

### 3단계 결과
- ✅ 카드/적/아티팩트: Lua `register_card/register_enemy/register_artifact` 안에 `name = l("cards.X.name", default)` 패턴 → **YAML override 가능**
- ⚠️ 이벤트 텍스트: `name = "Waking up..."` (하드코딩) → 별도 리팩토링
- ⚠️ `assets/gen/*.txt`: `gen.GetRandom("loading_lines")` → **locale overlay 필요** (system/gen/gen.go 패치)

### 4단계 결과
- 한국어 0건 → **완전 greenfield**

### 5단계 결정
- **PR 1**: i18n YAML 2개 (base + cards, 총 ~100 keys) + 검증 스크립트
- **PR 2 (현재 세션에 같이 진행)**: `gen.go` locale overlay + `assets/gen/ko/*.txt`
- **PR 3 (별도 권장)**: Lua 이벤트 텍스트 추출 (리팩토링)

## 코드 변경 vs 데이터 추가 분리 원칙

이게 **핵심 교훈**:

- ✅ **데이터만 추가** (YAML, properties, .txt) → 메인테이너 거부 확률 낮음 (i18n은 모두 환영)
- ⚠️ **로더 패치** (gen.go) → 호출 측 변경 0 + fallback 시 동작 동일 검증된 경우만 OK
- ❌ **Lua 리팩토링** (highlight() 마커, callback 구조 변경) → 메인테이너 거부 가능성 ↑

**원칙**: 첫 PR은 데이터 추가만. 로더 패치는 **호출 측 변경 0**이고 **fallback 시 동작 동일**이 검증된 경우만 포함. Lua 리팩토링은 별도 PR + 별도 사전 합의.

## Go 게임 i18n 한정: 자산 로더 locale overlay 패턴

Go 게임에서 `assets/gen/*.txt`, `assets/scripts/*`, `assets/data/*` 같은 데이터 파일이 **i18n 인프라 밖**에서 별도 로더로 읽히는 경우 흔함. 이때 다음 패턴:

```go
// system/gen/gen.go (end_of_eden 패턴)
func InitGen() {
    // 1) 기본 (영문) 데이터 로드
    files, _ := fs.ReadDir("./assets/gen")
    for _, file := range files {
        if strings.HasSuffix(file.Name(), ".txt") {
            data[strings.Split(file.Name(), ".")[0]] = strings.Split(read(file), "\n")
        }
    }
    
    // 2) locale overlay (있으면 덮어쓰기)
    locale := localization.GetCurrent()
    localeDir := "./assets/gen/" + locale
    if localeFiles, err := fs.ReadDir(localeDir); err == nil {
        for _, file := range localeFiles {
            if strings.HasSuffix(file.Name(), ".txt") {
                data[strings.Split(file.Name(), ".")[0]] = strings.Split(read(file), "\n")
            }
        }
    }
}
```

**호출 측 변경 0** + **locale 폴더 없으면 panic 없이 영문 fallback** → 안전한 패치.

`internal/fs` 같은 커스텀 fs wrapper는 `Stat()`이 없을 수 있음 → **`ReadDir` + error 체크**로 폴더 존재 확인.

## 관련 도구

- `scripts/i18n-yaml-verify.sh` — throwaway Go program + tempfile + `go run`으로 i18n 키 로드 검증 (end_of_eden 118개 키 검증한 패턴)
- `scripts/i18n-architecture-probe.sh` — 위 5단계 reconnaissance를 한 번에 실행하는 진단 스크립트