# Vercel 자동배포 + 한국어 강제 패턴 (2026-07-27, Evolve + minimax-of-duty 실측)

> 정적 SPA 게임 fork의 배포 패턴. **`git push`만 하면 자동 빌드/배포**가 되는 영구 파이프라인 구축 + 한국어 fork에서 **첫 방문자도 자동으로 한국어**가 보이게 만드는 1줄 패턴.

## 🌐 라이브 사례 (2026-07-27 기준)

- **minimax-of-duty**: https://minimax-of-duty.vercel.app (Claude of Duty 한국어화, Three.js+Vite)
- **evolve-kr**: https://evolve-kr.vercel.app (Evolve 한국어화, 11,670개 번역, MPL-2.0)

두 프로젝트 모두 **git push → Vercel 자동 빌드 → 라이브 URL 변경** 파이프라인이 잡혀있음.

## 🪤 가장 큰 함정 — `VERCEL_TOKEN` 환경변수 (사용자 정정)

### 진짜 문제 (evolve-kr v1 배포 시 만난 함정)
- 사용자가 "`~/.zshrc`에 `export VERCEL_TOKEN=*** 등록했어`" 라고 했지만
- 워커 환경에서 `$VERCEL_TOKEN` 길이 = **0** (빈 문자열)
- 원인: `vercel` CLI는 환경변수를 **자동으로 안 읽음** + 사용자가 등록한 셸 세션이 워커 서브프로세스에 export 안 됨
- 워커가 `vercel whoami` → "No credentials"로 30분 낭비

### 진짜 해결 — 명시적 플래그 + 영구화 위치

```bash
# 1) 영구 등록 — ~/.zshenv 사용 (모든 zsh 세션 + 비대화형 셸에서 자동 로드)
echo 'export VERCEL_TOKEN="***"' >> ~/.zshenv
source ~/.zshenv

# 2) CLI 호출 시 --token 명시 (자동 인식 X)
vercel whoami --token "$VERCEL_TOKEN"
vercel --prod --yes --non-interactive --token "$VERCEL_TOKEN" --name evolve-kr
```

**핵심**:
- `~/.zshenv` (NOT `~/.zshrc` — 비대화형 서브셸에서 안 읽힘)
- CLI는 환경변수 자동 인식 X → **반드시 `--token` 플래그**

## 🔄 비-인터랙티브 배포 워크플로

### 첫 배포 (Vercel 프로젝트 페이지에 처음 등록)
```bash
# 1) GitHub 저장소 fork
gh repo create sigco3111/evolve-kr --public --source=. --remote=origin --push=false
git push -u origin main

# 2) Vercel 자동배포 — Vercel이 GitHub 연결 감지해서 import
#    첫 한 번만 UI에서 "Import Project" 클릭 필요
#    이후 git push만 하면 자동 빌드/배포
```

### 헤드리스 자동 배포 (CI/CD 또는 서브에이전트)
```bash
vercel --prod --yes --non-interactive \
  --token "$VERCEL_TOKEN" \
  --name evolve-kr
```

- `--non-interactive`: remote 선택 / 환경 변수 / 도메인 등 모든 prompt 자동 응답
- 없으면 remote 2개 (origin + upstream) 선택에서 멈춤
- 첫 빌드는 import 단계 거치지만, 두 번째부터는 `--prod` 한 줄로 끝

### 자동배포 영구화 파이프라인

```
git push origin main
    ↓ (GitHub webhook)
Vercel 자동 감지
    ↓ (Vercel 내부)
vercel.json installCommand + buildCommand 실행
    ↓
Output Directory 정적 호스팅
    ↓
evolve-kr.vercel.app 라이브 갱신
```

**이 한 번 import 후로는 git push만 하면 됨**. 새 git push가 있을 때마다 Vercel이 자동 빌드 + URL 갱신.

## 📦 vercel.json 표준 (정적 SPA 게임)

```json
{
  "framework": null,
  "buildCommand": "npm run build",
  "outputDirectory": ".",
  "installCommand": "npm install --ignore-scripts esbuild@0.25.0 less@3.13.0 csso-cli@4.0.2",
  "engines": { "node": "22.x" }
}
```

**각 필드의 의미 (evolve-kr 실측)**:
- `outputDirectory: "."` — **점 하나, 절대 `dist/` 아님**. `index.html`이 루트에 있고 상대 경로로 `evolve/main.js` 참조
- `installCommand`에 빌드 도구 명시 — `npm ci`만 하면 dev/postinstall에서 native 모듈 에러 가능
- `engines.node` 명시 — Vercel 기본 24.x → 22.x로 강제 (esbuild/less 호환성)

## 🇰🇷 한국어 강제 패턴 — 1줄 패치 (가장 결정적 학습)

### 증상 (evolve-kr 라이브 후)
- 한국어 번역 11,670개 정상 서빙 + HTTP 200
- 브라우저 첫 방문 시 **여전히 영문 표시**
- `localStorage.setItem('evolve.locale', 'ko-KR')` → **키 이름이 다름 (실제: `global.settings.locale` + LZString 압축된 `evolved` 키에 저장)**

### 진짜 해결 — `vars.js` 기본값 1줄 패치

```js
// src/vars.js:1316
locale: 'en-US',  →  locale: 'ko-KR',

// src/vars.js:1490-1491
if (!global.settings['locale']) {
    global.settings['locale'] = 'en-US';  →  'ko-KR'
}
```

이 한 줄 + redeploy → **모든 방문자 자동 한국어**. 게임 내 Settings에서 다른 언어로 변경 가능.

### 왜 이게 표준 해법인가
1. **첫 방문자 자동 적용** — `navigator.language` 의존 안 함
2. **세션 저장 충돌 없음** — `localStorage.evolved` 덮어쓰지 않음
3. **원본 upstream과 호환** — `vars.js`의 기본값만 바꾸면 upstream pull 받아도 패치 유지
4. **사용자가 영문 보고 싶으면** — 게임 내 Settings → 언어 변경

### 다른 OSS 게임에 적용하는 판별 매트릭스

| 게임 구조 | 강제 방법 |
|---|---|
| `vars.js`/`config.js`에 `locale: 'en-XX'` 기본값 | **1줄 패치** (가장 안전) |
| `navigator.language`만 사용 | fallback 추가 (`|| 'ko-KR'`) |
| i18next/react-intl 같은 라이브러리 | `lng: 'ko'` 기본값 또는 `<html lang="ko">` 박기 |
| `localStorage.locale` 키로 강제 | `lang/` 디렉토리에 `ko.json` 만들면 자동 |

## 🛠️ 한 번에 끝내는 4단계 (evolve-kr 실측 워크플로)

```bash
# 1) 한국어 기본값 패치
cd /Users/mac/work/evolve-kr
sed -i '' "s/locale: 'en-US'/locale: 'ko-KR'/g" src/vars.js
sed -i '' "s/global.settings\['locale'\] = 'en-US'/global.settings['locale'] = 'ko-KR'/g" src/vars.js

# 2) 빌드 4개 + 검증
npm run evolve && npm run evolve-less && npm run wiki && npm run wiki-less
grep -c 'ko-KR' evolve/main.js  # 박혔는지 확인

# 3) Vercel redeploy
vercel --prod --yes --non-interactive --token "$VERCEL_TOKEN" --name evolve-kr

# 4) 라이브 검증
curl -fsS https://evolve-kr.vercel.app/strings/strings.ko-KR.json | python3 -c "
import json, sys
d = json.load(sys.stdin)
samples = [(k, v) for k, v in d.items() if any(ord(c) >= 0xAC00 for c in str(v))][:3]
for k, v in samples: print(f'  {k}: {v[:50]}')
"
# → tab_evolve: 진화 ... 출력되면 정상
```

## ⚠️ 발견된 추가 함정 — 브라우저 콘솔 오해

콘솔에 `Uncaught TypeError: r.closest is not a function at content.js:4` 에러가 떴을 때:
- **우리 빌드 문제가 아닐 가능성 ↑** — `content.js:4`는 일반적으로 **브라우저 확장 프로그램**이 inject하는 content script의 위치
- 검증: Playwright 헤드리스 (확장 없는 깨끗한 Chrome)로 페이지 로드 → console error 0건이면 우리 코드 아님
- 사용자 브라우저에서 시크릿 모드 또는 확장 비활성화로 재확인 안내

## 🛡️ 안전 규칙

1. **VERCEL_TOKEN 절대 채팅에 직접 박지 말 것** — `~/.zshenv`에 영구 등록 + 워커가 `--token` 플래그로 호출
2. **출력 디렉토리는 절대 `dist/`로 추측 금지** — `index.html` 위치 + 상대 경로 확인 후 결정
3. **`--non-interactive` 항상 포함** — 헤드리스 환경에서 remote 선택 prompt에서 멈춤
4. **engines.node 명시** — Vercel 기본 24.x와 esbuild/less 호환성 함정
5. **한국어 강제는 1줄 패치** — `vars.js`/`config.js` 기본값이 가장 안전

## 🔄 다음 프로젝트 적용 체크리스트

- [ ] `vercel.json` 작성 (outputDirectory 확인)
- [ ] `engines.node` 명시 (22.x 권장)
- [ ] 한국어 i18n 키 추출 → `lang/ko.json` 또는 fbtee 포맷
- [ ] 미번역 키 워커가 직접 LLM으로 채우기 (1,000개당 ~30분)
- [ ] `vars.js` 또는 동등한 기본값 파일의 `locale: 'en-XX'` → `'ko-KR'`
- [ ] 빌드 4개 + 라이브 검증
- [ ] `vercel --prod --yes --non-interactive --token "$VERCEL_TOKEN" --name <project>`
- [ ] README에 라이브 URL 박기 + git push

## 📌 관련 스킬/참조

- `oss-fork-localization` 상위 스킬 — fork 전반 워크플로
- `references/open-core-fork-pitfall.md` — Open Core 정책 함정 (Athena Crisis 사례)
- `references/threejs-browser-game-fork.md` — Three.js 게임 fork (minimax-of-duty)
- `references/sango-rising-dragons-success.md` — TS/Phaser 게임 fork (Vercel 배포)
