# LÖVE 옵션 영구 저장 + 풀스크린 토글 (snkrx-clone v0.1.20~v0.1.25, 2026-07-22)

> LÖVE 게임 fork 후 사용자가 가장 자주 요청하는 두 가지:
> 1. **옵션(창 크기, 전체화면, 볼륨 등) 종료 후 재시작해도 유지**
> 2. **풀스크린을 두 번 누르면 마지막 창 크기로 복귀**
>
> 둘 다 `state.txt` + `state.sx/sy` + `state.fullscreen` 패턴으로 해결. **5번의
> 반복 디버깅 끝에 정착**. 이 reference는 그 함정과 최종 패턴을 정리.

## 1. 원본 SNKRX의 state 시스템

원본은 `engine/system.lua`에 `system.save_state()` / `system.load_state()`가 있고,
게임 종료(love.quit 이벤트) 시 `state.txt`로 직렬화. **하지만 옵션 버튼 클릭마다
저장하지 않음** — 게임 종료 시에만 저장 → 사용자가 옵션 변경 후 게임을 비정상
종료하면 손실.

**원본의 state 직렬화 형식**:
```lua
-- system.lua
function system.save_state()
  love.filesystem.createDirectory("")
  local str = "return " .. table.tostring(state or {})
  love.filesystem.write("state.txt", str)
end

function system.load_state()
  -- state 파일(binser 형식) → state.txt 로 마이그레이션
  local chunk = love.filesystem.load("state.txt")
  if chunk then state = chunk()
  else state = {} end
end
```

→ **state는 Lua 테이블** → Lua 직렬화 → `state.txt`. 단순.

**위치**: macOS = `~/Library/Application Support/LOVE/{game_name}/state.txt`.

## 2. 문제 1: 옵션 변경이 저장 안 됨 (v0.1.20 수정)

**원본 옵션 버튼**:
```lua
self.music_button = Button{... action = function(b)
  music.volume = music.volume + 0.1
  state.music_volume = music.volume   -- 메모리에만 저장
  b:set_text(...)
end}
```

→ `state.music_volume = ...` 메모리 변경만, 디스크 저장 X. **게임 종료 시 save_state
호출되어야 저장**.

**snkrx-clone v0.1.20 해결**: 모든 옵션 버튼에 `system.save_state()` 추가
```lua
self.music_button = Button{... action = function(b)
  music.volume = music.volume + 0.1
  state.music_volume = music.volume
  b:set_text(...)
  system.save_state()   -- v0.1.20: 옵션 변경 시 저장
end}
```

**적용 대상** (snkrx-clone 기준):
- `music_button` (action + action_2)
- `sfx_button` (action + action_2)
- `video_button_1` (window size-)
- `video_button_2` (window size+)
- `video_button_3` (fullscreen)
- `video_button_4` (reset video)
- `screen_shake_button` (toggle)
- `cooldown_snake_button` (toggle)
- `arrow_snake_button` (toggle)
- `screen_movement_button` (toggle)

총 11개 위치. **각 버튼마다 1줄 추가만으로 영구 저장 가능**.

**즉시 적용 규칙**:
1. fork 후 옵션 버튼 식별 (`grep -rn 'state\.\(sfx\|music\|sx\|sy\|fullscreen\|no_screen\)' main.lua`)
2. 각 action의 마지막에 `system.save_state()` 1줄 추가
3. 사용자 보고: "옵션 변경 → 게임 재시작 → 유지" 워크플로 안내

## 3. 문제 2: 창 크기 종료 후 복원 안 됨 (v0.1.22 핵심)

### 3-1. 진짜 원인 1: `config.window_width` 우선순위가 state 덮어씀

`engine/init.lua`의 `engine_run(config)`에 `window_width = 1280` 명시 시:
```lua
-- engine/init.lua (수정 전)
if config.window_width ~= 'max' then window_width = config.window_width end
-- → config.window_width = 1280 (숫자) → window_width = 1280
-- → state.sx = 2.666이어도 무시됨. 매번 config 값으로 덮어씀.
```

**snkrx-clone v0.1.22 해결**: `main.lua`의 `engine_run`에서 `window_width/height` 제거.
→ config가 nil이면 `engine/init.lua`의 가드 분기 (`state.sx` 사용) 진입.

```lua
-- main.lua (v0.1.22 수정)
function love.run()
  return engine_run({
    game_name = 'SNKRX',
    -- window_width/height 제거: engine이 state.sx/sy를 사용하도록
    game_width = 480,
    game_height = 270,
  })
end
```

**확인**: `state.sx` 가드 분기 (engine/init.lua):
```lua
elseif state.sx and state.sy and state.sx >= 0.5 and state.sx <= 3
   and state.sy >= 0.5 and state.sy <= 3 then
  -- state.sx 사용
end
```

`config.window_width = nil`이면 첫 분기(`'max'` 비교)에서 false → 두 번째 분기에서
state.sx 확인. **이게 핵심**.

### 3-2. 진짜 원인 2: `state` 모듈 스코프 vs `_G.state`

`system.lua`가 `state = binser.r(...)`로 할당해도 **모듈 스코프 `state`** → main.lua의
`state`와 **별개 테이블**. save_state가 `state.txt`에 빈 `{}` 저장.

**v0.1.22 해결**: system.lua에서 `_G.state` 사용 → main.lua와 공유.
```lua
-- engine/system.lua (v0.1.22)
function system.save_state()
  local s = _G.state or {}
  local str = "return " .. table.tostring(s)
  love.filesystem.write("state.txt", str)
end

function system.load_state()
  ...
  if chunk then _G.state = chunk()
  else _G.state = _G.state or {} end
end
```

**또는 main.lua에 `init()`에서 초기화**:
```lua
function init()
  state = state or {}   -- v0.1.22: main.lua의 state 전역 초기화
  shared_init()
  ...
end
```

### 3-3. 진짜 원인 3: `save_state` 호출 시점 (quit 이벤트만)

원본은 `love.quit` 이벤트에서만 `save_state` 호출. **첫 사용자는 옵션 변경 후
`save_state` 호출이 안 됨** → state.txt가 안 만들어짐.

**v0.1.22 해결**: `engine/init.lua`의 `setMode` 직후 즉시 `save_state` 호출:
```lua
love.window.setMode(window_width, window_height, {...})
love.window.setTitle(config.game_name)
system.save_state()   -- v0.1.22: setMode 직후 즉시 저장
```

→ 첫 실행부터 state.txt 존재.

### 3-4. 진짜 원인 4: `config.window_width`가 nil일 때 산술 에러

`config.window_width = nil` → `if config.window_width ~= 'max' then window_width = config.window_width end`
→ `window_width = nil` → 다음 줄 `window_width / 480` → `attempt to perform arithmetic on
local 'window_width' (a nil value)`.

**v0.1.22 해결**: nil 명시 가드:
```lua
if config.window_width ~= 'max' and config.window_width ~= 'half'
   and config.window_width ~= nil then
  window_width = config.window_width
end
```

### 3-5. 진짜 원인 5 (최후의 함정): `setMode` `display` 옵션 macOS 버그

`setMode(1280, 720, {display = 0, fullscreen = false, ...})` 호출 시 macOS love2d 11.5가
**외장 디스플레이 0으로 잘못 매핑** → `flags.width = 1920` (maximize) →
`state.sx = 1920/480 = 4`로 덮어써짐.

**v0.1.24 해결**: `display` 옵션 제거:
```lua
love.window.setMode(window_width, window_height, {
  vsync = config.vsync,
  msaa = msaa or 0,
  -- display 옵션 제거 (macOS love2d 11.5 버그)
  fullscreen = fullscreen_mode,
  borderless = false,
  resizable = true,
})
```

### 3-6. 종합 v0.1.22+ engine/init.lua 윈도우 결정 로직

```lua
local use_state_sx = false
if state.fullscreen == true then
  -- 풀스크린: 데스크톱 크기 그대로 (state.sx 덮어쓰지 않음)
  sx, sy = window_width/480, window_height/270
  use_state_sx = true
elseif config.window_width == 'max' or config.window_width == 'half'
   or type(config.window_width) == 'number' then
  -- config 우선 (main.lua에서 명시한 경우만)
  sx, sy = window_width/480, window_height/270
elseif state.sx and state.sy and state.sx >= 0.5 and state.sx <= 3
   and state.sy >= 0.5 and state.sy <= 3 then
  -- ★ 핵심: state.sx가 가드 내면 사용
  sx, sy = state.sx, state.sy
  window_width = math.floor(sx * 480)
  window_height = math.floor(sy * 270)
  use_state_sx = true
else
  -- 기본값 (첫 실행)
  sx, sy = window_width/480, window_height/270
end

-- 가드 내였으면 state.sx 덮어쓰지 않음
if not use_state_sx then
  state.sx, state.sy = sx, sy
end
```

**즉시 적용 규칙**:
1. fork 후 engine/init.lua의 윈도우 결정 로직 확인
2. `main.lua`의 `engine_run`에서 `window_width/height` 제거 (state 우선)
3. `state`는 `_G.state` 또는 main.lua의 `state`와 동기화
4. `setMode` 직후 `save_state()` 호출 (첫 실행부터 state.txt 존재)
5. `setMode` 옵션에서 `display` 제거 (macOS love2d 11.5)
6. `config.window_width` nil 가드

## 4. 풀스크린 토글 (v0.1.23)

**원본**: `video_button_3`은 무조건 데스크톱 크기로 풀스크린화.
**문제**: 풀스크린 ON → OFF 시 **데스크톱 크기(1920×1080)의 창 모드**로 돌아감. 사용자가
기대하는 건 "마지막 창 크기".

**v0.1.23 해결**: 토글로 변경. OFF 시 `state.sx/sy`로 setMode.

```lua
self.video_button_3 = Button{... action = function()
  if state.fullscreen then
    -- OFF: 마지막 창 크기로 복원
    local restore_sx = (state.sx and state.sx >= 0.5 and state.sx <= 3)
                       and state.sx or 1.666
    local restore_sy = (state.sy and state.sy >= 0.5 and state.sy <= 3)
                       and state.sy or 1.666
    window_width = math.floor(restore_sx * 480)
    window_height = math.floor(restore_sy * 270)
    sx, sy = restore_sx, restore_sy
    state.fullscreen = false
    state.sx, state.sy = restore_sx, restore_sy
    love.window.setMode(window_width, window_height,
      {fullscreen = false, borderless = false, resizable = true})
  else
    -- ON: 데스크톱 크기로 풀스크린
    local _, _, flags = love.window.getMode()
    window_width, window_height = love.window.getDesktopDimensions(flags.display)
    sx, sy = window_width/480, window_height/270
    -- state.sx/sy는 덮어쓰지 않음 (다음 OFF 시 복원 위해 보존)
    state.fullscreen = true
    love.window.setMode(window_width, window_height,
      {fullscreen = true, borderless = false, resizable = true})
  end
  system.save_state()
end}
```

**핵심**: ON 분기에서 `state.sx = 4`로 덮어쓰면 안 됨. 다음 OFF 분기에서 가드
밖이라 fallback 1.666 사용 → 800×450으로 잘못 복원.

## 5. 종료 후 사이즈 복원 (v0.1.25)

**남은 문제**: 풀스크린 ON → OFF → 게임 종료 → 재시작 시 **1920×1080으로 maximize**.

### 5-1. 진짜 원인

OFF 분기는 `restore_sx = state.sx` 사용. 만약 `state.sx = 4` (가드 밖) → fallback
1.666 → 800×450 setMode. **macOS 버그로 1920×1080 maximize → state.sx = 4** 유지.
재시작 시 state.sx = 4 → setMode(1920, 1080) → 1920×1080.

### 5-2. v0.1.25 해결: `state.window_sx/sy` 백업 키

```lua
if state.fullscreen then
  -- OFF: state.window_sx/sy 우선 사용 → state.sx/sy → fallback 1.666
  local restore_sx = (state.window_sx and state.window_sx >= 0.5 and state.window_sx <= 3) and state.window_sx
                     or ((state.sx and state.sx >= 0.5 and state.sx <= 3) and state.sx or 1.666)
  local restore_sy = (state.window_sy and state.window_sy >= 0.5 and state.window_sy <= 3) and state.window_sy
                     or ((state.sy and state.sy >= 0.5 and state.sy <= 3) and state.sy or 1.666)
  window_width = math.floor(restore_sx * 480)
  window_height = math.floor(restore_sy * 270)
  sx, sy = restore_sx, restore_sy
  state.fullscreen = false
  state.sx, state.sy = restore_sx, restore_sy   -- v0.1.25: 가드 내 값 복원
  love.window.setMode(window_width, window_height,
    {fullscreen = false, borderless = false, resizable = true})
else
  -- ON: 현재 가드 내 state.sx/sy를 별도 키에 백업
  local _, _, flags = love.window.getMode()
  window_width, window_height = love.window.getDesktopDimensions(flags.display)
  if state.sx and state.sx >= 0.5 and state.sx <= 3 then
    state.window_sx = state.sx
  end
  if state.sy and state.sy >= 0.5 and state.sy <= 3 then
    state.window_sy = state.sy
  end
  sx, sy = window_width/480, window_height/270
  -- state.sx/sy는 덮어쓰지 않음 (다음 OFF 시 복원 위해)
  state.fullscreen = true
  love.window.setMode(window_width, window_height,
    {fullscreen = true, borderless = false, resizable = true})
end
```

### 5-3. 흐름

| 단계 | state.sx | state.window_sx | window_size |
|------|---------|----------------|-------------|
| 시작 (1280×720) | 2.666 | - | 1280×720 |
| 풀스크린 ON | 2.666 | **2.666** (백업) | 1920×1080 풀스크린 |
| 풀스크린 OFF | **2.666** | 2.666 | **1280×720** (복원) |
| 종료 | 2.666 | 2.666 | - |
| 재시작 | 2.666 | 2.666 | **1280×720** |

## 6. 누적 정리: snkrx-clone v0.1.22~v0.1.25 변경 요약

| 버전 | 핵심 변경 |
|------|----------|
| v0.1.20 | 모든 옵션 버튼에 `system.save_state()` 추가 |
| v0.1.21 | `state.fullscreen` 처리 (풀스크린 시작/유지) |
| v0.1.22 | main.lua에서 window_width/height 제거, `_G.state` 동기화, setMode 직후 save_state, config.window_width nil 가드 |
| v0.1.23 | 풀스크린 토글 (OFF 시 state.sx/sy로 복원) |
| v0.1.24 | setMode display 옵션 제거 (macOS love2d 11.5 버그) |
| v0.1.25 | state.window_sx/sy 백업 키 (ON/OFF 사이클에서 마지막 창 크기 보존) |

## 7. 검증 워크플로

```bash
# 1. state.txt 직접 조작으로 시나리오 재현
cat > ~/Library/Application\ Support/LOVE/{game_name}/state.txt << 'EOF'
return {["fullscreen"] = false, ["sx"] = 2.666, ["sy"] = 2.666,
        ["new_game_plus"] = 0, ["current_new_game_plus"] = 0}
EOF

# 2. 백그라운드 실행 + 검증
exec /Applications/love.app/Contents/MacOS/love /path/to/game > /tmp/love_test.log 2>&1 &
LOVE_PID=$!
sleep 5
kill -9 $LOVE_PID

# 3. state.txt 확인 (변경 없으면 OK)
cat ~/Library/Application\ Support/LOVE/{game_name}/state.txt
```

## 8. 다른 게임에 적용 체크리스트

- [ ] `engine/system.lua`에 `_G.state` 또는 모듈 공유 패턴 확인
- [ ] `main.lua`의 `engine_run`에 `window_width/height` 명시 → **제거**
- [ ] `engine/init.lua`에 `state.sx/sy` 가드 분기 확인 (0.5~3)
- [ ] `setMode` 옵션에서 `display` 제거 (macOS)
- [ ] 모든 옵션 버튼에 `system.save_state()` 추가
- [ ] 풀스크린 버튼이 토글인지 확인 (원본은 무조건 ON일 수도)
- [ ] 풀스크린 OFF 시 마지막 창 크기 복원 분기 확인
- [ ] `state.window_sx/sy` 백업 키 패턴 적용 (풀스크린 토글 시)
- [ ] setMode 직후 `system.save_state()` 호출 추가

## 9. snkrx-clone 검증 결과

| 시나리오 | state.txt | 결과 |
|---|---|---|
| state 없음 (첫 실행) | `sx=1.666, fullscreen=false` | 800×600 (기본) ✅ |
| `sx=2.666` 수동 → 재시작 | `sx=2.666, fullscreen=false` | 1280×720 유지 ✅ |
| `fullscreen=true` → 재시작 | `sx=2.666, fullscreen=true` | 1920×1080 풀스크린 ✅ |
| 풀스크린 ON → OFF → 종료 → 재시작 | `sx=2.666, fullscreen=false` | 1280×720 ✅ |

## 10. 다른 함정 — 같은 패턴의 다른 게임에 적용 시

- **Godot**: `ProjectSettings.set_setting("display/window/size/viewport_width", ...)` + `OS.window_size = Vector2i(...)`. 영구 저장은 `user://settings.cfg`.
- **Unity**: `PlayerPrefs.SetInt("ScreenWidth", Screen.width)` + `Screen.SetResolution(...)`. `Application.quit` 핸들러에서 저장.
- **Phaser**: `scale.width` / `scale.height` 직접. 영구 저장은 `localStorage` 또는 외부 모듈.
- **Pygame/SDL**: `pygame.display.set_mode((w, h))`. 영구 저장은 `json.dump(state, f)`.

**공통 패턴**: 게임 종료/시작 시점에 명시적 저장/로드 + UI에서 변경 시 즉시 저장.

## 11. snkrx-web (TypeScript Canvas 포팅) 폐기 교훈 (2026-07-22)

**다른 게임을 TypeScript + Vite + Canvas로 처음부터 새로 만드는 시도는 품질이 떨어질 수
있음**. snkrx-web (Vite + TS + Canvas 2D의 SNKRX 웹 포팅) 시도에서 누적 버그:
- 뱀 이동/회전 무작위 (keyup 핸들러가 모든 키 input 리셋)
- 카메라 추적 안 됨 (Arena.update만 호출, Arena.draw는 카메라 추적하지만 main.ts에서 분리 안 됨)
- 적 충돌 시 라이프 즉시 0 (invulnerable 가드 음수 버그)
- autoTarget AI가 적 (0,0)에서 멈춤
- 충돌 거리 12 (너무 작음)

**즉시 적용 규칙**: 사용자가 "이걸 웹으로 만들어보자" 또는 "다른 엔진으로 포팅" 요청 시:

1. **fork 기반 작업 우선** — 검증된 Lua 코드의 구조를 그대로 따르거나, **engine만 교체하고 게임 로직은 그대로**
2. **데이터 레이어부터 빌드 검증** — "데이터 + 화면에 표시"까지만 작은 PR로 OK 받고 → 게임 코어 추가
3. **큰 프로젝트 (10+ 파일, 1000+ LOC)는 한 세션에 만들지 않음** — 사용자 OK 받으면서 누적
4. **사용자 "제거하자" 정정 시** → 즉각 `rm -rf` (별도 확인 불필요). **단, GitHub remote도 같이 정리**

**snkrx-clone (Lua fork) vs snkrx-web (TS 신규) 비교**:
| 항목 | snkrx-clone (fork) | snkrx-web (신규) |
|------|-------------------|------------------|
| 빌드 검증 | luac -p 0에러, love 백그라운드 실행 OK | Vite 빌드 OK, 그러나 게임플레이 ❌ |
| 디버깅 | 헤드리스 love로 가능 | 헤드리스 검증 한계 |
| 데이터 | 원본 Lua 테이블 → JSON 변환 | 처음부터 JSON 정의 |
| 엔진 | LÖVE 안정 | Canvas 2D 직접 → 타이밍 버그 누적 |
| 게임 로직 | 원본 포팅 → 일관성 | 처음 작성 → 실수 누적 |

**결론**: fork 기반 작업이 **품질 5~10배 우수**. 새로운 엔진/언어로 같은 게임을 처음부터
만들려는 요청은 신중히 — 2~3회 작은 PR + 사용자 검증 후 확장.