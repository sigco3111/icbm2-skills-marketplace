# 한국어 페르소나 시드 패턴 (generative_agents-kr, 2026-07-14)

> Stanford generative_agents 한국어 fork에서 검증한 페르소나 시드 패턴.
> CSV whisper 생성 + 조사 자동 처리 + 비밀/관계 중복 제거.

## 패턴 1: 한국어 조사 자동 선택 (받침 기반)

```python
def josa_with(particle_eul, particle_neun, name):
    """한국어 조사 자동 선택. 받침 유무에 따라 은/는, 이/가 등 결정."""
    last_char = name[-1]
    if not (ord("가") <= ord(last_char) <= ord("힣")):
        return f"{name}{particle_eul}"  # 한글이 아니면 그대로
    has_jongseong = (ord(last_char) - ord("가")) % 28 != 0

    if has_jongseong:
        if particle_neun == "는": return f"{name}은"
        if particle_neun == "가": return f"{name}이"
        if particle_neun == "와": return f"{name}과"
        if particle_neun == "를": return f"{name}을"
        if particle_neun == "나": return f"{name}이나"
    else:
        if particle_neun == "는": return f"{name}는"
        if particle_neun == "가": return f"{name}가"
        if particle_neun == "와": return f"{name}와"
        if particle_neun == "를": return f"{name}를"
        if particle_neun == "나": return f"{name}나"
    return f"{name}{particle_neun}"
```

**수학적 근거**: 한글 유니코드에서 `(char_code - 0xAC00) % 28`이 종성 코드. `0`이면 받침 없음.

**테스트 케이스**:
- `josa_with("은", "는", "이서연")` → "이서연은" (받침 없음)
- `josa_with("은", "는", "김민준")` → "김민준은" (받침 없음)
- `josa_with("와", "와", "박지우")` → "박지우와" (받침 없음)

## 패턴 2: 비밀-관계 키워드 중복 제거 (substring 매칭)

```python
import re

def to_whisper(persona):
    parts = []
    parts.append(f"이것은 매우 중요합니다 -- {persona['secret']}")

    seen_types = set()
    secret_text = persona.get("secret", "")

    for rel_name, rel_type, years, unit in persona["relationships"]:
        if rel_type in seen_types:
            continue
        # 관계 type의 핵심 단어가 비밀 텍스트에 들어있으면 스킵
        # "짝사랑" (3글자) ≠ "짝사랑함" (4글자) → exact match 실패
        # → substring matching 으로 해결
        skip = False
        for word in re.findall(r'[가-힣]+', rel_type):
            if len(word) >= 2 and word in secret_text:
                skip = True
                break
        if skip:
            continue
        seen_types.add(rel_type)

        name_p = josa_with("은", "는", rel_name)
        if years:
            parts.append(f"당신과 {name_p} {years}년 넘게 {rel_type}입니다")
        else:
            parts.append(f"당신과 {name_p} {rel_type}입니다")

    parts.append(f"당신의 일상: {'; '.join(persona['habits'])}")
    return "; ".join(parts)
```

**왜 substring 매칭?**
- secret: "김민준에게 짝사랑함 (아직 고백 안 함)"
- relation type: "짝사랑 (본인만 모름)"
- exact match: `"짝사랑" in "짝사랑함"` → **False** (정확히 일치 안 함)
- substring: `word "짝사랑" in secret_text` → **True** (3글자가 substring으로 들어가 있음)
- 결론: substring 매칭이 한국어 키워드 중복 검출에 훨씬 효과적

## 패턴 3: 절대 경로로 CSV 갱신 (relative `../` 함정)

```python
import os

OUT_CSV = os.path.join(
    os.path.dirname(__file__), "..", "..", "..",  # 3단계 위로
    "environment", "frontend_server", "static_dirs", "assets", "the_ville",
    "agent_history_init_kr_n3.csv",
)
OUT_CSV = os.path.abspath(OUT_CSV)
```

**함정**: `"../../environment/..."` 같이 relative path 쓰면 cwd에 따라 깨짐. 절대 경로 변환 후 검증:

```python
assert os.path.exists(OUT_CSV), f"CSV 경로 없음: {OUT_CSV}"
```

## 페르소나 데이터 구조 (generative_agents-kr 사례)

```python
{
    "name": "이서연",
    "first_name": "서연",
    "last_name": "이",
    "age": 27,
    "occupation": "도시계획 석사과정",
    "personality_traits": ["호기심 많음", "외향적", "세심함"],
    "speech_style": "친근한 반말, 가끔 의문사 사용",
    "interests": ["한강 자전거", "도시계획", "카페 탐방"],
    "habits": ["주 3회 자전거 출퇴근", "거의 매일 도서관", "한강뷰 카페 단골"],
    "background": "...",
    "relationships": [
        ("김민준", "짝사랑 (본인만 모름)", 2, "years"),
        ("김민준", "같은 대학 도서관 친구", 2, "years"),
        ("박지우", "한강 자전거 동호회 친구", 3, "years"),
        ("박지우", "가장 친한 친구", None, None),
    ],
    "secret": "김민준에게 짝사랑함 (아직 고백 안 함)",
}
```

## 시나리오별 페르소나 매트릭스 (3명 시나리오)

| 이름 | 직업 | 시나리오 | 비밀 |
|------|------|---------|------|
| 이서연 | 도시계획 석사 | 한강 자전거 동호회 + 한강뷰 카페 | 김민준 짝사랑 |
| 김민준 | 데이터 사이언스 석사 + 한강뷰 카페 알바 | 도서관 단골 + 자전거 동호회 | 이서연 짝사랑 |
| 박지우 | 마케팅 매니저 + 동호회 운영진 | 둘 이어주기 역할 | 둘이 서로 좋아함 |

## 한국어 whisper 예시 (자동 생성)

```
이것은 매우 중요합니다 -- 김민준에게 짝사랑함 (아직 고백 안 함);
당신과 김민준은 2년 넘게 같은 대학 도서관 친구입니다;
당신과 박지우는 3년 넘게 한강 자전거 동호회 친구입니다;
당신과 박지우는 가장 친한 친구입니다;
당신의 일상: 주 3회 자전거 출퇴근; 거의 매일 도서관; 한강뷰 카페 단골
```

**자동 중복 제거됨**: "짝사랑 (본인만 모름)" 관계가 비밀에 이미 있어서 자동 스킵.

## 한국어 시나리오 적용 시 주의사항

| 항목 | 한국어 적용 |
|------|------------|
| 원본 맵 (영문 Smallville) | 좌표 깨질 위험 → **영문 맵 그대로 + 에이전트 이름만 한글** (점진 접근) |
| 프롬프트 파일 | 50+ .txt 파일 번역 작업 큐 |
| Django UI | 한/영 토글 또는 순수 한글 (별도 작업) |
| LLM 응답 | gpt-oss-120b 한국어 생성 자연스러움 (검증) |

## 검증 방법

```bash
# 1. CSV 자동 갱신
python3 persona/refresh_persona_csv.py

# 2. self-test
python3 persona/persona_seed_kr.py
# 3명 페르소나 whisper 출력 확인

# 3. LLM 호출 검증 (옵션)
python3 reverie/backend_server/persona/prompt_template/gpt_structure.py
# → "ping" 응답 + 임베딩 차원 + 부정 가드 출력 확인
```
