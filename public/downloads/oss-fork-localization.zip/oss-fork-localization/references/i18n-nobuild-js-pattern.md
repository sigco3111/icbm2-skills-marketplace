# JS-only i18n 인프라 패턴 (NoBuildDependencies)

> 2026-07-27 `sigco3111/minimax-of-duty` (Three.js r180 + WebGL2 + Vite 풀 프로시저럴 브라우저 FPS) 실측.
> mshumer/Claude-of-Duty fork의 한국어화 + 한↔영 토글 작업에서 검증됨.
> 핵심: **외부 의존성 0개** (`three` only 정책 유지), **공통 ctx 패턴** 따름, **오프라인 작동**.

## 왜 이 패턴이 필요한가

대부분의 게임/앱이 한국어화할 때 쓰는 도구:

| 도구 | 외부 의존 | 한↔영 토글 | 마찰 포인트 |
|---|---|---|---|
| **i18next + react-i18next** | 2개 npm 패키지 + JSON 분리 | ✅ | React 전용, 번들 +50 KB, 비동기 로딩 기본 |
| **react-intl (FormatJS)** | 4개 npm + ICU MessageFormat | ✅ | React 전용, ICU 문법 학습 |
| **next-intl** | 1개 npm, App Router 전용 | ✅ | Next.js 전용 |
| **js-lingui** | 3개 npm 패키지 | ✅ | config + 플러그인 + AST 매직 |

**공통 문제**: 외부 의존성 가산, 빌드 도구/번들러 필요, 종종 비동기 message loading (오프라인 깨짐 위험), JSON 분리 도구 학습곡선.

**minimax-of-duty 같은 환경**:
- ARCHITECTURE.md hard rule: "No new npm dependencies. `three` only."
- ARCHITECTURE.md hard rule: "No CDN fetches, no external images/HDRIs/models/audio files — the game must run fully offline."
- 11개 서브시스템이 동시에 로드 (UI는 그 중 하나)

→ **외부 의존성을 못 더하고, 오프라인이어야 함**. 라이브러리 없이 200줄로 풀 자체 설계.

## 파일 구조

```
src/i18n/
├── index.js          # I18nSystem 서브시스템 + pure functions
└── locales/
    ├── ko.js         # DEFAULT_LOCALE — 한국어
    └── en.js         # FALLBACK — 영어
```

## 핵심 디자인 결정 5개

| 결정 | 이유 |
|---|---|
| **Pure function + class 둘 다 export** | pure `t()`는 모든 모듈에서 `import { t } from '../i18n'` 으로 직접 사용. I18nSystem class는 engine.add() 등록용 |
| **en이 폴백** | ko에서 키 누락 → en에서 시도 → 그것도 없으면 키 자체 반환 (크래시 X). **반대로 en이 DEFAULT면 ko 키 누락이 영구 은폐됨** |
| **모듈 스코프 `_locale` 변수** | i18next 같은 라이브러리는 context/provider 인프라 만들지만 **단일 인스턴스 게임은 모듈 변수 1개면 충분** |
| **`{xp}` placeholder 보간** | `t('xp.headshot', { xp: 150 })` → "+150 XP · 헤드샷". jsx-translate/gettext 의존 없이 5줄 |
| **`window.dispatchEvent` 추가 발행** | `onLocaleChange()`는 동일 컴포넌트 내 구독용, `dispatchEvent`는 **다른 컴포넌트 / 디버그 콘솔 / 다른 탭에서도 listen 가능** |

## locale 결정 순서 (last-wins 일관성)

`?lang=` URL → `localStorage.minimax.lang` → `navigator.language` → `DEFAULT_LOCALE`

**중요**: 어떤 단계가 우선이고 다른 단계가 언제 박히는지가 일관돼야 함. 같은 순서대로:
- **boot 시점 resolveLocale()** — first choice
- **runtime setLocale()** — `localStorage` write-through + 구독자에게 알림

→ locale 결정이 두 경로 (boot vs runtime)에 나눠지면 역설적 함정 가능. **두 경로 모두 한 함수 (`resolveLocale`/`setLocale`)로 단일화** 권장.

## 동적 라벨 패턴 — 비어있는 placeholder + sync 시 repaint

**핵심 4단계**:

1. **빌드 시 라벨이 정해지는 곳** → `t('menu.graphics')` 즉시 박기 (행 헤더, 정적)
2. **빌드 시 로케일 미지정인 곳** → `''` 비워두기 (preset 버튼, 토글 버튼)
3. **syncFromConfig()** 안에서 매 프레임 다시 그리기 (highlight + value)
4. **paintMenu()** 별도 메서드, setLocale 직후 + 메뉴 열 때만 (라벨 다시)

## 결정적 함정 4개 (실측)

### 함정 1: 메뉴 row 위치 + paintMenu keys 순서 어긋남

`_row(name)` 호출 순서와 `paintMenu()`의 `keys` 배열 순서가 다르면 한쪽이 잘못된 텍스트 박힘.

**해결**: 매니페스트 배열을 const로 클래스 시작에 정의.
```js
const ROW_KEYS = ['menu.graphics', 'menu.sensitivity', 'menu.fov', 'menu.invertLook', 'menu.language'];
```

### 함정 2: paintMenu를 매 프레임 호출 (비용 폭증)

sync는 highlight만 (cheap) ≠ paintMenu는 setLocale 후 한 번만 (expensive).

**해결**: syncFromConfig()는 highlight + preset text만. paintMenu는 별도 메서드, setLocale 직후 + 메뉴 열 때만 호출.

### 함정 3: XP 매직넘버를 양쪽 로케일에 박음

`'+150 XP'`가 ko/en 양쪽에 박혀있으면, 게임 밸런스 조정 시 양쪽 파일 박스 모두 수정. 빠뜨리면 한쪽 어색.

**해결**: `'+{xp} XP · 헤드샷'` placeholder. 로케일은 텍스트 구조만. 매직넘버는 호출 시점에 `t('xp.headshot', { xp: 150 })`로 보간.

### 함정 4: CSS 클래스명 같은 식별자를 t()로 감쌈

`'ow-btn'`, `'armour'` 같은 CSS 클래스명을 `t()`로 감싸면 ko/en마다 다른 클래스가 박혀서 **CSS 룰 매칭 실패**.

**해결**: 식별자는 절대 t() 거치지 않음. t()는 **사용자에게 보이는 텍스트만** (label, hint, banner, sub).

## 번역 대상 vs 비대상 판별 매트릭스

| 패턴 | 예시 | 번역? |
|---|---|---|
| 디스플레이 텍스트 | `'Paused'`, `'Health'` | ✅ `t()` 치환 |
| 본(bone) 이름 | `'Hips'`, `'Spine'`, `'HeadTop'` | ❌ 데이터 ID, 손대지 마 |
| CSS / JS 클래스명 | `'ow-btn'`, `'ow-vt-lbl'` | ❌ 손대지 마 |
| 라이브러리 호출 | `'webkit'`, `'.copyTexImage2D'` | ❌ 손대지 마 |
| 매직넘버 + 텍스트 박힌 문자열 | `'+150 XP · HEADSHOT'` | ✅ 보간형 (`t('xp.headshot', { xp: 150 })`) |

## 마이그레이션 결정 (코드베이스 전체 점검)

```bash
grep -rn -E "'(Reload|Health|Armour|Armor|Ammo|Paused|Resume|Defaults|Graphics Preset|
Enemy Eliminated|HEADSHOT|Loading|Generating|You Died|Stance|Sprint|Crouch|Slide|
Inspect|Inspected|Volume|Quality|Low|Medium|High|Ultra|Sniper|SMG|Pistol|
Shotgun|Headshot|Kill|Eliminated|Respawn|Frag|Smoke|Grenade|Cover)'" src/
```

다음 패턴 찾아보기:
- `'[A-Z][a-z]+( [A-Z][a-z]+){0,4}'` — 일반 영문 표시문
- bone/bone-tree 제외
- 매직넘버는 보간형으로

## 검증 4축 (minimax-of-duty 실측)

| 검증 | 명령 | PASS 기준 |
|---|---|---|
| **로컬 빌드** | `npm run build` | exit 0, gzip +1.7 KB 이하 |
| **모듈 카운트** | `npm run build` 출력 | 145 → 148 (+3: `i18n/index.js` + `i18n/locales/ko.js` + `i18n/locales/en.js`) |
| **Vercel 라이브 검증** | `curl -sI https://<alias>.vercel.app` | HTTP 200 + anon (team-scope SSO 302 회피) |
| **번들에 한국어/영어 박힘** | `grep -o "한국어\|English\|일시정지\|Paused"` in JS bundle | 양쪽 다 박힘 |

**시각 영향 0 검증**: 텍스트만 바뀌므로 imagediff 픽셀 동일성 게이트 유지 가능.

## 다른 클래스에 적용 — 판단 기준

| 포크 종류 | 채택 | 이유 |
|---|---|---|
| **브라우저 게임 (Vite/Three.js/Phaser)** | ✅ | 의존성 0, ESM, Vercel CDN |
| **데이터 헤비 웹앱** | ✅ | 동일 이득 |
| **SNKRX (Lua/LÖVE)** | ❌ 안 채택 | 이미 T() + lang/*.lua 패턴 다름 |
| **sango (TypeScript/Phaser)** | ✅ 약간 다름 | 이미 i18next 있다면 본 패턴 불요 |
| **Next.js 풀스택** | ❌ 안 채택 | next-intl/react-intl 표준 |
| **Django/Python 백엔드** | ❌ 안 채택 | gettext .po 표준 |
| **Electron / Tauri** | ⚠️ 검토 | 의존성 정책에 따라 |
| **React Native** | ⚠️ 검토 | i18n 라이브러리 생태계 성숙 |

## 변형 — 색상 토큰 + i18n 결합 (게임 데이터 다량)

글로벌 게임 fork의 이름/스킬 테이블이 50~300개 항목이면 손번역 비현실적.

```js
// src/i18n/locales/ko.js (확장)
{
  'menu.paused': '일시정지',
  'name.warrior': '전사',
  'name.rogue': '도적',
  'name.ranger': '레인저',
  // 84개 패시브 이름 ...
}

t('name.' + passive.id.toLowerCase(), passive.id)
```

**대량 매핑 자동화**: SNKRX 실측 패턴 — Python regex + 단어 사전 + longest-first 매칭. JS 버전은 동일 알고리즘 + JSON 출력.

## 정리 — 이 패턴의 핵심 가치 4가지

1. **의존성 0** — `three` only 정책 같은 strict dep 제약 환경에서 유일하게 작동
2. **빌드 5분** — npm install + npm run build + auto-deploy로 즉시 라이브
3. **시각 영향 0** — 텍스트만 바뀌므로 imagediff 게이트 자연 유지
4. **유지보수 양호** — 새 키 추가는 한 곳에 더 적으면 됨. 키 매핑 어긋나도 en 폴백이 silently 처리
