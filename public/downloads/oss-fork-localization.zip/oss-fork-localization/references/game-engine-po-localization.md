# 🎮 C++ 게임 엔진 Fork + PO/gettext 한국어화 워크플로우

> Python LLM 백엔드 교체 + Django UI 한글화가 아닌 **C++ 게임 엔진 fork + gettext PO 파일 한국어화 + 기능 패치(gameloop 자동진행)** 워크플로우. wesnoth-kr (2026-07-20) 사례 기반.

## 언제 사용하나

| 사용자 요청 | 트리거 |
|------------|--------|
| "이 게임 한글화하고 싶은데" | ✓ |
| "오픈소스 게임 fork해서 한국어 패치 만들자" | ✓ |
| "Wesnoth / Battle for Wesnoth 한글화" | ✓ |
| "Poedit 없이 .po 파일 자동 채우고 싶어" | ✓ |
| "이 게임에 자동진행 기능 추가하고 싶어" | ✓ |
| "오픈소스 게임에 옵션 토글 추가하는 법 알려줘" | ✓ |

## 핵심 원칙 (Python LLM 포크와 다른 점)

### 1. 라이선스는 동일하게 — GPL fork면 GPL 강제

Wesnoth는 **GPL v2**. 포크도 GPL v2 강제. 라이선스 표시는 원본 보존 + `CREDITS` 또는 `MODIFIED.md`에 mistzone(2019) → sigco3111(2026) chain 명시.

```markdown
## Translation credits
- Original Korean translation: mistzone (2019, Poedit 2.2.4)
- Continuation + auto-progression: sigco3111 (2026)
```

원본 `po/LINGUAS`에 `ko`가 **이미 등록되어 있는지** 먼저 확인 — wesnoth는 `ko`만 등록되고 `ko.po` 파일이 7년간 누락된 상태였음. upstream에 등록은 됐지만 PR이 머지 안 된 케이스.

### 2. gettext PO 파일은 **빈/오역/fuzzy 3축**으로 분석

Python LLM 프로젝트와 달리 게임은 **gettext .po/.pot 시스템** 사용. PO 파서 직접 만들어서 통계 추출:

```python
import re

def analyze_po(path):
    entries = []
    current_file = None
    current_msgid, current_msgstr = [], []
    state = 'header'
    fuzzy = False
    for line in open(path, 'r', encoding='utf-8'):
        line = line.rstrip('\n')
        if line.startswith('#:'):
            current_file = line[2:].strip().split()[0] or current_file
        if line.startswith('#, fuzzy'):
            fuzzy = True
        if line.startswith('msgid "'):
            if state == 'msgstr' and current_msgid:
                entries.append({...})
            m = re.match(r'msgid "(.*)"', line)
            if m: current_msgid = [m.group(1)]; state = 'msgid'; fuzzy = False
        elif line.startswith('msgstr "'):
            m = re.match(r'msgstr "(.*)"', line)
            if m: current_msgstr = [m.group(1)]; state = 'msgstr'
        elif line.startswith('"') and state in ('msgid', 'msgstr'):
            m = re.match(r'"(.*)"', line)
            if m:
                if state == 'msgid': current_msgid.append(m.group(1))
                else: current_msgstr.append(m.group(1))
    ...
    return total, translated, empty, fuzzy
```

**카테고리별 분포**를 출력해서 "사용자 영향도" 기준 우선순위:
- `data/advanced_preferences.cfg` (설정 UI) → 최우선
- `data/core/macros.cfg` (게임 본체) → 상
- `src/addon/*`, `core/editor/*` → 저 (사용자가 거의 안 봄)

### 3. "기존 번역 있음" 발견 시 **extend vs rebuild 결정**

신규 번역 작업 시작 전에 반드시 `ko.po` (또는 타겟 언어) 존재 확인:

| 상태 | 전략 |
|------|------|
| 파일 자체 없음 | 신규 작성 (빈 entry 많음, 작업량 큼) |
| 파일 있으나 0% (모두 빈 msgstr) | 위와 동일 |
| **부분 번역 (50~95%)** | **extend** — 빈 entry만 채움, fuzzy 검수 |
| 95%+ 완성 | maintenance 모드 — 자동 도구만 |

wesnoth 사례: **91% (mistzone 2019)** → extend 전략으로 19개 신규 + 진행률 92.1%로 갱신. **번역 작업량의 80%가 절약**됨.

**⭐ Audit-first 원칙 (2026-07-20 검증)**: 작업 시작 전 `git log -- po/<lang>.po | head -20` + `wc -l po/<lang>.po` + `grep -c '^msgstr ""' po/<lang>.po` 3종을 먼저 실행. mistzone 님처럼 **7년 묵은 부분 번역 (91%)**이 흔함 — 이걸 무시하고 0부터 새로 작성하면 시간 낭비 + 기존 번역자 기여 무시. **transifex/Wesnoth 공식 번역 사이트에서 `ko`가 LINGUAS에 등록되어 있지만 `ko.po` 파일이 누락된 케이스**도 있음 — 이 경우 빈 entry 채우기만으로 거의 끝. **translations.json에 기존 msgid를 그대로 import**하면 빈 entry에 대한 자동 매핑의 90%+가 해결됨.

### 4. 게임 preference 시스템은 **C++ 매크로 1줄로 선언 + UI 토글 + 로직**

Wesnoth 사례의 `auto_end_turn` 추가 — 3개 파일 패치:

```cpp
// 1) src/preferences/preferences_list.hpp — preference 선언
ADDPREF(auto_end_turn)   // ← 매크로 1줄

// 2) src/gui/dialogs/preferences_dialog.cpp — UI 토글 등록
register_bool("auto_end_turn", true,
    []() {return prefs::get().auto_end_turn();},
    [](bool v) {prefs::get().set_auto_end_turn(v);});

// 3) src/playsingle_controller.cpp — 게임 로직
void playsingle_controller::play_human_turn() {
    ...
    while(!should_return_to_play_side() && !end_turn_requested_) {
        play_slice_catch();
        // [wesnoth-kr] Auto-End Turn
        if(prefs::get().auto_end_turn() && !has_pending_moves_remaining()) {
            end_turn_enable(false);
            end_turn_requested_ = true;
            break;
        }
    }
}
```

**핵심**: `PREF_GETTER_SETTER` / `ADDPREF` 매크로가 getter/setter 자동 생성 → preference 명세만 추가하면 됨. UI는 `register_bool` 한 줄.

### 5. 자동진행 feature taxonomy (B1~B6)

게임별 자동진행의 단계를 정의해서 점진적 추가:

| 단계 | 이름 | 난이도 | 게임플레이 영향 |
|------|------|--------|----------------|
| **B1** | Auto-End Turn | ⭐ 쉬움 | 사용자 명령형, 결정 큐 마지막 step |
| **B2** | Auto-Combat (AI 위임) | ⭐⭐ 보통 | 전투 결정만 AI, 이동은 사용자 |
| **B3** | Auto-Scenario (캠페인 진행) | ⭐⭐⭐ 보통 | lua hook + 체크포인트 저장 |
| **B4** | Auto-Save (결정 큐 스냅샷) | ⭐⭐ 보통 | 스토리형 게임의 분기점 저장 |
| **B5** | Spectator Mode | ⭐ 쉬움 | 기존 기능 활용 (전투 리플레이만) |
| **B6** | Full Auto-Play (AI 턴 통째) | ⭐⭐⭐⭐ 높음 | 신규 lua API 필요 |

**권장 사이클**: B1+B2 먼저 (2주 검증), 사용자 반응 보고 B3~B4 확장.

### 6. 5GB 게임 엔진 sparse-checkout 전략

Wesnoth 전체 repo는 **5GB**. 풀 clone + 빌드 = 30~45분. **분석 단계에서는 sparse-checkout**으로 폴더만 추출:

```bash
TMPDIR=/tmp/wesnoth-probe
git clone --depth 1 --filter=blob:none --sparse \
  https://github.com/wesnoth/wesnoth.git "$TMPDIR"
cd "$TMPDIR"

# 1차: PO 파일만 (번역 분석)
git sparse-checkout set po

# 2차: 게임 데이터 (시나리오 대화 검수)
git sparse-checkout add data/campaigns

# 3차: C++ 소스 (preference 패치 분석)
git sparse-checkout add src
```

`--filter=blob:none`은 blob은 lazy fetch, `--sparse`는 명시한 경로만 checkout. **5GB → 수십MB로 압축**.

⚠️ PO 파일은 `po/wesnoth/*.po` 형태로 한 단계 더 nesting됨 (`po/wesnoth/ko.po`). 첫 시도에서 잘못 잡지 않도록 ls로 확인.

### 7. 패치 파일은 `.patch` V4A 형식으로 보관

코드 패치는 PR-able한 `.patch` 파일로 별도 보관:

```diff
*** Begin Patch
*** Update File: src/preferences/preferences_list.hpp
@@ 컨텍스트: ADDPREF(disable_auto_moves) 라인 주변 @@
 	ADDPREF(disable_auto_moves)
+	ADDPREF(auto_end_turn)
+	ADDPREF(auto_combat)
+	ADDPREF(auto_play_ai)
*** End Patch
```

V4A 형식은 `*** Update File: path` + `@@ context @@`로 old_string 명시. upstream PR 시 그대로 `git apply` 가능.

### 8. `upstream/` 서브디렉토리 패턴

fork를 메인으로 두지 않고 `upstream/` 하위에 원본을 clone + 패치 적용:

```
wesnoth-kr/
├── po/                    # 한국어 번역 (fork 핵심 자산)
├── patches/               # 자동진행 패치
├── scripts/               # PO 분석 도구
├── docs/                  # 빌드 가이드
└── upstream/              # .gitignore에 추가 (원본 clone + 패치)
    └── wesnoth/           # 빌드 대상
```

장점:
- fork repo 자체는 **수십 MB** (번역/패치/문서만)
- 원본 업스트림 pull 충돌 없음
- 새 upstream 버전 시도 시 `rm -rf upstream && git clone` 으로 깨끗하게

## ⚠️ 핵심 함정

### 함정 1: C++ 매크로 preference 시스템 안에서 `PREF_GETTER_SETTER` 다름

Wesnoth의 preference 시스템은 2가지 매크로:
- `PREF_GETTER_SETTER(name, type, default)` — 선언 + getter/setter 자동
- `ADDPREF(name)` — preferences_list.hpp에서 등록 (preferences.cpp가 자동 처리)

**둘 다 추가해야 동작**. 한쪽만 추가하면 컴파일은 되지만 preference가 작동 안 함.

### 함정 2: `register_bool` 두 번째 인자는 "advanced" 플래그

```cpp
register_bool("auto_end_turn", true,    // ← 두 번째 인자: 기본값이 아닌 "advanced" 표시
    []() {return prefs::get().auto_end_turn();},
    [](bool v) {prefs::get().set_auto_end_turn(v);});
```

Wesnoth에서는 두 번째 인자가 **advanced preference 여부**. 잘못 이해하면 환경설정 UI에 안 보임.

### 함정 3: `po/wesnoth/` vs `po/` nesting

Wesnoth는 PO 파일을 `po/wesnoth/ko.po`에 둠 (`po/LINGUAS`, `po/Makevars` 등 메타 파일은 `po/wesnoth/`에). 다른 OSS는 `po/<lang>.po` 평면 구조일 수 있음.

sparse-checkout 후 반드시 `ls po/ po/wesnoth/` 두 번 확인.

### 함정 4: `_main.cfg`의 `_`는 i18n이 아님

Wesnoth WML config 파일의 `# #-#-#-#-# ... #-#-#-#-#` 마커는 **PO 자동 병합이 만든 synthetic entry**가 아니라 **i18n key가 있는 WML 매크로 마커**. 무시해도 됨.

### 함정 5: build = 30~45분 + 부분 빌드 1~3분

C++ 게임 엔진은 초기 빌드가 길어요. macOS M4 기준:
- 풀 빌드 (cold): 30~45분
- 부분 빌드 (헤더 1개 변경): 1~3분
- PO 파일만 변경: 재빌드 불필요 (런타임에 로드)

**개발 사이클**: 코드 변경 → 부분 빌드 → 게임 실행 → 검증. PO 파일 변경 → 게임 재시작만.

### 함정 6: `auto_play_ai` 풀 통합은 lua hook 필요

B6 (Full Auto-Play)은 단순 preference 추가가 아니라 **lua script가 매 턴 hook**해야 함:
- `wml.notify`로 턴 시작 이벤트 수신
- `wesnoth.interface.game_display` API로 AI 호출
- 사용자 입력 대기 없이 다음 턴으로 진행

이건 단순 C++ 패치가 아니라 **lua addon**으로 추가하는 게 안전. wesnoth addon 시스템 (`~/.local/share/wesnoth/<version>/data/add-ons/`).

### 함정 7: sparse-checkout blob:none은 git diff에서 누락

`--filter=blob:none` clone은 파일이 lazy-fetch 상태. `git log -- <file>`이 작동 안 할 수 있음. 분석 목적이면 무시 OK, **PR 만들 때는 full clone 필요**.

### 함정 8: PO 파일 통계 파싱 — multiline msgid 누적 함정

PO 파일은 msgid/msgstr이 여러 줄로 나뉠 수 있음:

```
msgid ""
"multi-line "
"string"
msgstr ""
```

`re.match(r'msgid "(.*)"', line)` 한 줄만 보면 **첫 줄의 빈 문자열만 잡힘**. multiline 누적을 직접 처리해야 정확한 통계 나옴 (위 §2 코드 참조).

### 함정 9: C++ 5GB 풀 clone이 디스크 빨리 잡아먹음

PO 분석만 필요하다면 sparse-checkout 후 **임시 디렉토리에서 작업 + 마지막에 rm -rf**:

```bash
TMPDIR=/tmp/wesnoth-probe
git clone --depth 1 --filter=blob:none --sparse https://... "$TMPDIR"
cd "$TMPDIR"
# 분석...
cp po/wesnoth/ko.po /Users/mac/work/wesnoth-kr/po/
rm -rf "$TMPDIR"
```

## 📋 권장 워크플로우

### Stage 0: 메타 결정
1. LICENSE 확인 (GPL → GPL fork 강제)
2. **기존 번역 존재 여부** 확인 → extend vs rebuild 결정
3. 게임 preference 시스템 패턴 파악 (C++ 매크로 / config / GUI 정의 파일)
4. 자동진행 범위 (B1~B6) — 검증 사이클이면 B1+B2부터

### Stage 1: 클론 + sparse-checkout
- 임시 디렉토리에 sparse clone
- `po/`, `data/`, `src/` 폴더 순차 checkout
- PO 통계 + 빈 entry + fuzzy entry 분석

### Stage 2: 한국어 갱신
- `translations.json`에 빈 entry 매핑 추가
- `fill_empty.py`로 원본 PO 패치
- 자동진행 preference 라벨 3개 (영문 msgid + 한국어 msgstr) 추가

### Stage 3: 게임 패치 작성
- `patches/auto-progression.patch` 작성 (preferences_list.hpp + dialog + controller)
- V4A 형식, `@@ context @@` 명시
- 단일 패치 파일에 B1+B2 동시 (검증 사이클)

### Stage 4: 빌드 가이드 + 스크립트
- `docs/BUILD_MACOS.md` 작성 (의존성 + scons 명령 + 트러블슈팅)
- `scripts/stats.py` 작성 (PO 파일 통계 + 카테고리 분포)
- `scripts/fill_empty.py` 작성 (translations.json → PO patch)

### Stage 5: README + push
- 진행 단계 표 + 빌드 명령 + 자동진행 사용법
- `upstream/` `.gitignore` 추가
- fork repo는 **수십 MB**로 가볍게
- GitHub repo 생성 + 푸시 + description에 원본 링크

## 🔧 도구 템플릿

### PO 파일 통계 스크립트 (scripts/stats.py)

```python
#!/usr/bin/env python3
"""PO 파일 통계 + 카테고리 분포 출력."""
import sys, re
from collections import Counter
from pathlib import Path

def analyze(path: Path):
    # ... 위 §2 파서 ...
    real = [e for e in entries if e['msgid']]
    total = len(real)
    empty = [e for e in real if not e['msgstr']]
    fuzzy_e = [e for e in real if e['fuzzy'] and e['msgstr']]
    translated = total - len(empty)
    
    print(f"📊 {path.name}")
    print(f"   전체: {total}")
    print(f"   번역됨: {translated} ({translated/total*100:.1f}%)")
    print(f"   빈 msgstr: {len(empty)}")
    print(f"   Fuzzy (재검수 필요): {len(fuzzy_e)}")
    # 카테고리 분포...

if __name__ == '__main__':
    for p in sys.argv[1:]:
        analyze(Path(p))
```

### 빈 msgstr 채우기 스크립트 (scripts/fill_empty.py)

핵심 로직 (라인 단위 patch):

```python
def patch_po_inplace(content: str, translations: dict) -> tuple[str, int]:
    lines = content.split('\n')
    out_lines, filled = [], 0
    i = 0
    while i < len(lines):
        line = lines[i]
        m = re.match(r'msgid\s+"(.*)"', line)
        if m:
            # multiline msgid 수집
            msgid_parts = [m.group(1)]
            j = i + 1
            while j < len(lines) and lines[j].startswith('"'):
                mm = re.match(r'"(.*)"', lines[j])
                if mm: msgid_parts.append(mm.group(1)); j += 1
                else: break
            full_msgid = ''.join(msgid_parts)
            
            # msgstr 라인 확인
            msgstr_line = lines[j] if j < len(lines) else ''
            mm = re.match(r'msgstr\s+"(.*)"', msgstr_line)
            
            for k in range(i, j):
                out_lines.append(lines[k])
            
            if mm and not mm.group(1) and full_msgid in translations:
                out_lines.append(f'msgstr "{translations[full_msgid]}"')
                filled += 1
                i = j + 1
                continue
            i = j
            continue
        out_lines.append(line)
        i += 1
    return '\n'.join(out_lines), filled
```

원본 라인 구조 보존하면서 빈 msgstr만 정확히 치환 — POT 머지 후에도 안전.

## ✅ 검증 체크리스트 (push 후)

- [ ] `scripts/stats.py po/wesnoth-ko.patched.po` → 진행률 90%+ 표시
- [ ] 빈 entry 카테고리 분포 — 사용자 영향도 높은 영역(설정 UI, 게임 본체) 0건
- [ ] 자동진행 preference 3개 모두 PO에 등록 (`wesnoth.auto_*`)
- [ ] `patches/auto-progression.patch` V4A 형식 — upstream에서 `git apply` 가능
- [ ] 매크로 `ADDPREF` + UI `register_bool` + 로직 `play_human_turn` **3종 모두** 패치됨
- [ ] `upstream/` `.gitignore` 등록 — fork repo 자체는 수십 MB
- [ ] `docs/BUILD_MACOS.md` — 의존성 + scons 명령 + 트러블슈팅
- [ ] README에 진행 단계 표 + 자동진행 사용법
- [ ] 라이선스 chain 명시 (mistzone 2019 → sigco3111 2026)
- [ ] upstream PR 가능성 검토 (Wesnoth 메인테이너에게 auto-progression 제안)

## 📂 폴더 구조

```
{project}-kr/
├── po/
│   ├── {project}-ko.po            # 원본 (참고용, upstream 변경 추적)
│   ├── {project}-ko.patched.po    # 실제 적용본
│   └── translations.json          # 빈 msgstr 채우기 매핑
├── patches/
│   └── auto-progression.patch     # V4A 형식 코드 패치
├── scripts/
│   ├── fill_empty.py              # translations.json → PO patch
│   └── stats.py                   # PO 통계 + 카테고리 분포
├── docs/
│   ├── BUILD_MACOS.md             # 빌드 가이드
│   └── KOREAN.md                  # 한글화 가이드
├── upstream/                      # .gitignore (원본 sparse clone + 패치)
└── README.md                      # 진행 단계 + 사용법
```

## 🔗 관련 스킬

- **`oss-fork-localization`** (umbrella) — Python LLM backend swap + Django UI 패턴
- `github-repo-management` — fork/PR/release 운영
- `github-pr-workflow` — upstream PR 제출
- `ad-hoc-verifier` — 자동진행 preference 검증
- `ad-hoc-verification-bash-heredoc-pitfall` — bash heredoc 안에서 Python 스크립트 안전 실행

## ⚠️ 빌드 환경 함정 (CRITICAL, 2026-07-20) ★

C++ 게임 엔진 fork는 **반드시 로컬 빌드 검증**이 필요. 다음 9개 함정은 wesnoth-kr (1.19.25+dev, M4 macOS)에서 실측.

### 함정 A: Boost 1.90 + modern clang의 `static_visitor` 비호환 ★★★

**가장 흔한 빌드 실패 원인**. homebrew Boost가 1.90으로 업그레이드되면 Wesnoth 등 Boost variant 기반 코드가 컴파일 안 됨.

**증상**:
```
src/formula/callable_objects.cpp:538:54: error: base class 'boost::static_visitor<variant>' has protected default constructor
return cfg_[key].apply_visitor(wfl_variant_visitor{});
                                  ^
/opt/homebrew/include/boost/variant/static_visitor.hpp:52:5: note: declared protected here
static_visitor() = default;
```

**원인**: Boost 1.90에서 `boost::static_visitor<T>::static_visitor()`가 protected로 변경됨 (Variant 라이브러리 정책 변경). Wesnoth master (1.19.x)는 **Boost 1.83 이하 가정**으로 작성됨.

**판별**:
```bash
brew list --versions boost
# boost 1.90.0  ← 1.83 이상이면 함정 A 가능성

grep -n "static_visitor" src/ -r | head -5
# → match 있으면 Boost 1.83 이하 가정 코드
```

**해결 (4개 옵션)**:

| 옵션 | 작업 | 위험도 | 시간 |
|------|------|--------|------|
| **A1: 1.18 브랜치 시도** | `git checkout 1.18.x` 후 재빌드 | 낮음 | 30분 |
| A2: Boost 다운그레이드 | `brew install boost@1.83` (formula 없을 수 있음) | 중 | 1시간 |
| A3: 직접 코드 패치 | `callable_objects.cpp` 수정 | 높음 (다른 호환성 문제 가능) | 10분 |
| **A4: 빌드 보류 + 텍스트 작업 우선** | 다른 빈 entry 채우기로 전환 | 무 | 즉시 |

**추천**: 옵션 A4 (즉시 가치 추가) + A1 (다음 사이클). 빌드 검증은 CI로 위임.

### 함정 B: SCons의 `cxx_std=20` vs `cxx_std=c++20` (2026-07-20) ★

Wesnoth SConstruct는 `cxx_std` 변수를 **숫자 문자열**로 받음. `c++20`은 enum 검증 실패.

**증상**:
```
scons: *** Invalid value for enum variable 'cxx_std': 'c++20'. Valid values are: ['17', '20']
```

**해결**:
```bash
# ❌ 잘못
scons cxx_std=c++20 build=release

# ✅ 올바름
scons cxx_std=20 build=release
```

**확인 방법** (SConstruct에서 enum 검사):
```bash
grep -A 5 "choices.*cxx_std" SConstruct | head -10
# choices=['17', '20']  ← 숫자만 받음
```

### 함정 C: SDL3 헤더 네이밍 규칙 (2026-07-20) ★

Wesnoth 1.19는 **SDL3 기반**. 헤더 include 경로가 SDL2와 다름.

**증상**:
```
src/build_info.cpp:39:10: fatal error: 'SDL3_image/SDL_image.h' file not found
   39 | #include <SDL3_image/SDL_image.h>
      |          ^~~~~~~~~~~~~~~~~~~~~~~~
```

**해결 — SDL3 brew 패키지 설치 + 환경변수**:
```bash
brew install sdl3 sdl3_image sdl3_mixer sdl3_ttf

# 빌드 시 환경변수
export SDL3DIR="/opt/homebrew/opt/sdl3"
export SDL3IMAGEDIR="/opt/homebrew/opt/sdl3_image"
export SDL3MIXERDIR="/opt/homebrew/opt/sdl3_mixer"
export SDL3TTFDIR="/opt/homebrew/opt/sdl3_ttf"
```

**판별 (Wesnoth가 SDL2 vs SDL3 어느 쪽인지)**:
```bash
grep -r "SDL3_\|SDL_image.h\|SDL3_image" src/build_info.cpp 2>&1
# SDL3_image/SDL_image.h → SDL3 기반
# SDL2/SDL_image.h        → SDL2 기반 (구버전)
```

### 함정 D: sparse-checkout → 풀 checkout 전환 시 패치/번역 손실 (2026-07-20) ★

sparse-checkout으로 PO/src만 받아 분석 후, 풀 checkout으로 전환하면 **이전에 적용한 한글화/패치가 다 풀림**.

**증상**:
```bash
git sparse-checkout disable
git checkout --force  # ← 한글화/패치 전부 reset됨
```

**해결 — 작업 순서 확정**:
```bash
# Stage 1: 분석 (sparse, 임시 디렉토리)
git clone --depth 1 --filter=blob:none --sparse <repo>
cd <repo>
git sparse-checkout set po data/campaigns
# PO 분석, 번역 매핑 작성...
cp po/wesnoth/ko.po /Users/mac/work/{project}-kr/po/{project}-ko.po

# Stage 2: 빌드 검증 (full checkout, 별도 디렉토리)
cd /Users/mac/work/{project}-kr
rm -rf upstream && mkdir upstream && cd upstream
git clone --depth 1 <repo> .  # full
git submodule update --init --recursive  # ← 반드시
git apply ../patches/auto-progression.patch  # ← 새로 적용
cp ../po/{project}-ko.patched.po po/wesnoth/ko.po  # ← 다시 복사

# Stage 3: 빌드
scons build=release cxx_std=20 ...
```

**핵심**: sparse clone은 분석 전용, 빌드는 별도 full clone에서. **두 단계를 분리**.

### 함정 E: PO 파일 빈 entry 카운트 정확도 (2026-07-20) ★

PO 파서를 단순 `grep -c 'msgstr ""'`로 하면 **fuzzy로 시작하는 msgstr도 빈 문자열로 카운트**해서 부정확. **multiline msgid 누적 + state machine**이 핵심.

올바른 파서 패턴은 본문 §2 참조. 검증된 출력 예 (wesnoth-kr v0.1):
```
전체: 1,427
번역됨: 1,314 (92.1%)
빈 msgstr: 113
Fuzzy (재검수 필요): 331
```

→ `scripts/stats.py` 전체 코드는 `oss-fork-localization/scripts/` 참조.

### 함정 F: V4A `.patch` 파일은 `git apply` 안 됨 (2026-07-20) ★

`*** Begin Patch` V4A 형식은 Hermes 전용. 표준 `git apply`는 인식 못 함 → "No valid patches in input" 에러.

**증상**:
```
$ git apply patches/auto-progression.patch
error: No valid patches in input (allow with "--allow-empty")
```

**해결 — 표준 unified diff로 직접 작성**:
```diff
diff --git a/src/preferences/preferences_list.hpp b/src/preferences/preferences_list.hpp
--- a/src/preferences/preferences_list.hpp
+++ b/src/preferences/preferences_list.hpp
@@ -80,6 +80,12 @@
 	ADDPREF(disable_auto_moves)
+	/** [wesnoth-kr] B1: automatically end turn */
+	ADDPREF(auto_end_turn)
+	ADDPREF(auto_combat)
+	ADDPREF(auto_play_ai)
```

**추천 워크플로**: 패치 적용 후 깨끗한 디렉토리에서 `git diff > file.patch`로 표준 형식 추출:
```bash
git checkout -- src/   # 깨끗하게
git apply patches/auto-progression.patch  # 임시 적용
git diff > patches/auto-progression.patch  # 표준 형식으로 재생성
git checkout -- src/   # 다시 깨끗하게
```

**올바른 사용 패턴**:
- V4A 형식 → SKILL.md / references/ 안에서 사용 (agent 간 patch 교환)
- 표준 unified diff → upstream PR / git apply (외부 시스템과 호환)

### 함정 G: `register_bool` 두 번째 인자 의미 확인 (2026-07-20)

Wesnoth의 `register_bool(name, ???, getter, setter)`에서 두 번째 인자는 **bool 기본값이 아니라 advanced preference 플래그**:

```cpp
// ❌ 오해 — bool 기본값 같지만
register_bool("auto_end_turn", true,  // ← 이건 advanced=true 플래그
    ...);

// ✅ 정확한 의도
register_bool(name, advanced_flag, getter, setter);
```

**판별**:
```bash
grep -A 5 "void register_bool" src/gui/dialogs/preferences_dialog.cpp | head -15
# → 두 번째 인자명이 `advanced` 인지 확인
```

### 함정 H: scons 빌드 O3 최적화 + `-Werror=non-virtual-dtor` (2026-07-20) ★

Wesnoth master는 **모든 경고를 에러로 처리** (`-Werror=non-virtual-dtor`). 신 clang 옵션 추가 시 빌드 깨질 수 있음.

**경고는 무시해도 OK** (실측):
```
warning: unknown warning option '-Wtrampolines' [-Wunknown-warning-option]
warning: unknown warning option '-Wno-maybe-uninitialized'
```

이건 `-Werror`로 분류되지 않아서 빌드는 계속 진행됨. **`2 warnings generated` 후 다음 .o 파일로 넘어가면 정상**.

**진짜 에러 신호**:
```
fatal error: 'X.h' file not found
error: base class ... has protected default constructor
```

이런 "fatal" / "error:" 패턴이 나오면 즉시 중단. 경고는 흘려보내도 OK.

### 함정 I: homebrew `libtheora` 이름 변경 (2026-07-20)

Wesnoth 의존성 패키지 중 `libtheora`는 brew에서 **그냥 `theora`**로 이름 바뀜.

**증상**:
```
Warning: No available formula with the name "libtheora". Did you mean theora or libtecla?
```

**해결**:
```bash
# ❌ 잘못
brew install libtheora

# ✅ 올바름
brew install theora
```

### 함정 J: 빈 entry 카운트가 3가지로 갈림 (2026-07-20) ★

**PO 파일의 "빈 entry" 개수는 파서 구현에 따라 3개 결과로 갈림**. 가장 중요한 함정.

| 카운트 방식 | 명령 / 파서 | wesnoth 결과 | 비고 |
|---|---|---|---|
| **simple (stats.py v1)** | `entries`에서 `e['msgstr']` 비어있는 것 | 8개 | 헤더 `msgid ""` 까지 카운트해서 **가장 작음** |
| **multiline 정확** | state machine으로 multiline msgid 누적 | 52개 | **fill_empty.py와 일치하는 진짜 수치** |
| **grep 단순 카운트** | `grep -c '^msgstr ""'` | 213개 | **가장 큼**. fuzzy로 시작하는 msgstr + multiline의 첫 줄만 잡아서 부정확 |

**증상** (실측):
```
[stats.py simple] 8 empty
[multiline 정확 파서] 52 empty  ← fill_empty.py 매칭 결과와 일치
[grep 단순] 213 empty
```

**왜 stats.py가 8개라고 했는데 fill_empty.py는 45개만 채웠지?** → 8개 카운트는 헤더(빈 entry가 아닌 메타데이터)까지 포함하는 단순 카운트. **multiline msgid의 누적 길이가 stats.py 파서로는 짧게 잡혀서** 메시지 본문이 "비어있다"고 잘못 인식.

**해결 — fill_empty.py v2 (longest prefix match)**:
```python
def find_best_match(msgid, translations):
    if msgid in translations:
        return msgid, translations[msgid]
    # prefix match - 긴 키 우선
    candidates = []
    for k in translations:
        if k and (msgid.startswith(k) or k.startswith(msgid)):
            candidates.append((len(k), k, translations[k]))
    if candidates:
        candidates.sort(reverse=True)
        return candidates[0][1], candidates[0][2]
    return None
```

**왜 longest prefix?** fuzzy msgid가 길 때 translations.json에는 짧은 키만 있는 경우 (예: msgid에 한/영 두 버전이 concat된 경우 — Wesnoth의 mistzone 작업 흔적). 짧은 키가 긴 msgid의 prefix면 매칭. wesnoth-kr v0.3에서 이 매칭 추가로 **1개 → 45개** 매칭 (45배 향상).

**진행률 보고 일관성**: `stats.py` 출력과 `fill_empty.py` 결과가 일치해야 함. 둘 다 **동일 파서 (multiline 정확 + longest prefix)** 사용. 단순 카운트는 보고용으로만.

### 함정 K: PO multiline msgid 파서 `j > i + 1` 버그 (2026-07-20) ★

**가장 자주 발생하는 PO 파서 버그**. `fill_empty.py`를 직접 작성할 때 90% 확률로 빠지는 함정.

**버그 코드** (v1 패턴):
```python
msgid_parts = [m.group(1)]
j = i + 1
while j < len(lines) and lines[j].startswith('"'):  # ← 단순 startswith
    mm = re.match(r'"(.*)"', lines[j])
    if mm:
        msgid_parts.append(mm.group(1))
        j += 1
```

**문제**: `lines[j].startswith('"')` 만으로는 **msgstr 라인도 multiline msgid의 일부로 잘못 인식**할 수 있음. 표준 PO 파일에서 msgstr 직전의 `msgid "..."` 의 `"..."` 라인이 그 예.

**올바른 코드** (v2 패턴):
```python
is_continuation = (
    j > i + 1  # ← 첫 줄은 항상 msgid 라인
    and not next_line.startswith('msgstr')  # ← msgstr 시작 라인 제외
    and not next_line.startswith('msgid ')  # ← 다음 entry 시작 제외
    and not next_line.startswith('msgid_plural')
)
```

**실측 디버그 단서**: `fill_empty.py`가 "채워진 빈 msgstr: 0"로 보고하는데 translations.json에는 매핑이 명확히 있을 때 → 99% 이 버그. **stats.py로 측정한 빈 entry 수 > fill_empty.py가 채운 수** 차이로 탐지 가능.

### 함정 L: 빌드 검증 보류 시 텍스트 작업 우선 (2026-07-20) ★

Boost 1.90 비호환(함정 A) 같은 빌드 환경 문제는 **당일 해결이 안 될 수 있음** (1.18 브랜치 시도 30분, Boost 다운그레이드 1시간). 이때 **다른 가치 추가 작업으로 전환**이 효과적.

**wesnoth-kr 실측 흐름**:
1. Boost 1.90 비호환 → 빌드 실패
2. **즉시 판단**: 1.18 브랜치 시도는 다음 사이클로 이월
3. **대신 진행**: 빈 entry 132개 → 44개 채움 (90.7% → 97.0%)
4. **순 효과**: 빌드 검증 못 했지만 진행률 6.3%p ↑ + 자동진행 패치 안정화 + 빌드 가이드 문서화
5. **다음 사이클**: 1.18 브랜치 시도 OR GitHub Actions로 CI 자동 빌드

**결정 트리**:
```
빌드 실패
├─ 헤더/라이브러리 누락? → brew install 즉시 해결 (함정 C)
├─ 환경변수 누락? → export 추가 (함정 B, C)
├─ Boost 버전 비호환? → 빌드 보류, 텍스트 작업 우선 (함정 A, L)
└─ 코드 자체 문제? → 패치 수정 후 재시도
```

**핵심**: 빌드 검증 못 했다고 작업 무효가 아님. **PO 파일과 자동진행 preference 패치 자체는 빌드와 무관하게 가치**. 사용자에게 "빌드는 다음 사이클, 지금은 진행률 6.3%p + 가이드 문서 추가됨" 보고.

### 빌드 검증 단계 요약 (2026-07-20)

```bash
# 1. 환경 점검
brew install --quiet sdl3 sdl3_image sdl3_mixer sdl3_ttf \
                     pango libvorbis theora opusfile openssl@3 readline lua boost pkg-config
python3 -m pip install --user scons
export PATH="$HOME/Library/Python/3.9/bin:$PATH"

# 2. 풀 클론 + 서브모듈
cd /Users/mac/work/{project}-kr
rm -rf upstream && mkdir upstream && cd upstream
git clone --depth 1 <repo> .
git submodule update --init --recursive

# 3. 한글화 + 패치 적용
cp ../po/{project}-ko.patched.po po/{lang}.po
git apply ../patches/auto-progression.patch

# 4. 빌드
export BOOST_ROOT="/opt/homebrew"
export SDL3DIR="/opt/homebrew/opt/sdl3"
export SDL3IMAGEDIR="/opt/homebrew/opt/sdl3_image"
scons build=release cxx_std=20 cxx_toolchain=clang++ jobs=8

# 5. 검증
ls -lh wesnoth  # 바이너리 생성 확인
./wesnoth --version  # 실행 가능 확인
```

**예상 시간**: M4 macOS 16GB 기준 cold build 30~45분, partial 1~3분.

**빌드 검증 실패 시 우선순위**:
1. Boost 1.90 비호환 (함정 A) — 텍스트 작업으로 전환 후 다음 사이클에 1.18 브랜치 시도
2. SDL3 헤더 미설치 (함정 C) — 즉시 brew install 가능
3. 그 외 — 에러 로그 첫 줄로 판단