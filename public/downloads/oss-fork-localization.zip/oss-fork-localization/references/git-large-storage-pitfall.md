# Storage 1GB+ git 인덱싱 함정 (BIG STORAGE)

> 시뮬레이션/UI 프로젝트의 **storage/ 디렉토리가 1GB+** 차이할 때 git add 가 60초 timeout 으로 멈춤. 3-step 해결 패턴.

## 증상

```bash
$ cd repo && git add -A
# (60초 후) [Command timed out after 60s]
# "Your index.lock is in use. Another git process is running."
```

원인:
- `storage/` (시뮬레이션 결과), `compressed_storage/` (Django/Wagtail dump), `static_dirs/assets/` (RPG Maker 비주얼 팩) 등이 1GB+ 차지
- git 가 모든 파일을 인덱싱 시도 → CPU/메모리 spike + 디스크 I/O 폭주

## 3-step 해결

### Step 1: .gitignore 강화 (빠름)

```bash
cat >> .gitignore <<'EOF'

# 시뮬레이션 결과 — 재생성 가능 (1GB+ 함정)
environment/frontend_server/storage/
environment/frontend_server/compressed_storage/
environment/frontend_server/db.sqlite3
environment/frontend_server/*.log
reverie/backend_server/storage/
reverie/backend_server/temp_storage/
reverie/backend_server/environment/

# Django/Flask
*.sqlite3
*.log
EOF
```

### Step 2: 실제 디렉토리 물리 삭제 (디스크 절약)

```bash
# 먼저 비웠는지 확인 (스크린샷/cv 등 외부 백업은 별도)
du -sh environment/frontend_server/storage compressed_storage 2>/dev/null

# 삭제 (긴 시간 걸릴 수 있음 — 60초 timeout 주의)
rm -rf environment/frontend_server/storage
rm -rf environment/frontend_server/compressed_storage

# 확인
du -sh .  # 800KB - 10MB 정도로 떨어짐
```

### Step 3: .git 통째 재생성 (가장 빠름)

`git rm --cached .` 는 60초+ 걸리므로 통째 재생성:

```bash
rm -rf .git
git init -b main
git remote add origin https://github.com/{user}/{repo-name}.git
# upstream 도 추가 (필요 시)
# git remote add upstream https://github.com/{original-org}/{original-repo}.git

# 이제 .gitignore 가 적용되어 빠르게 add
time git add -A
# real    0m2.3s  ← 30배+ 빨라짐

git -c user.email=action@github.com -c user.name="{user}" \
  commit -m "chore: import + localize"

git push -u origin main
```

## 시간 비교 (Stanford generative_agents-kr 사례)

| 방법 | 시간 | 결과 |
|------|------|------|
| (a) 그냥 `git add -A` | 60s timeout | ❌ 멈춤 |
| (b) `.gitignore` 추가 후 `git add -A` | 60s timeout | ❌ (이미 인덱스 시작함) |
| (c) `git rm --cached .` | 60s+ | ❌ (제거 자체가 I/O) |
| **(d) `rm -rf .git && git init` + .gitignore** | **2-5초** | ✅ 통과 |

→ **무조건 (d)** 이 가장 안정적이고 빠름.

## 자주 같이 등장하는 거대 디렉토리

| 디렉토리 | 용도 | 크기 |
|---------|------|------|
| `storage/`, `temp_storage/`, `compressed_storage/` | 시뮬레이션 결과 | 100MB ~ 1GB+ |
| `static_dirs/assets/*/visuals/` | 게임/시각 자산 | 100MB ~ 1GB |
| `static_dirs/assets/*/matrix/` | 매트릭스 데이터 | 50KB ~ 50MB |
| `node_modules/` | Frontend 의존성 | 100MB ~ 500MB |
| `__pycache__/` | Python 컴파일 캐시 | 수십 MB |
| `*.egg-info/`, `build/`, `dist/` | Python 패키지 빌드 | 50MB ~ 500MB |
| `.next/`, `dist/`, `build/` | Frontend 빌드 | 50MB ~ 300MB |
| `venv/`, `.venv/`, `env/` | Python 가상환경 | 100MB+ |

### 표준 Python .gitignore 보강 템플릿

```gitignore
# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
env/
venv/
.venv/
*.egg-info/
build/
develop-eggs/
dist/
downloads/
eggs/
.eggs/
.installed.cfg

# Frontend
node_modules/
.next/
.cache/
.parcel-cache/

# Django/DB
*.sqlite3
db.sqlite3
db.sqlite3-journal
*.log

# 시뮬레이션 결과 (재생성 가능)
storage/
temp_storage/
compressed_storage/
environment/

# OS
.DS_Store
Thumbs.db

# Editor
.vscode/
.idea/
*.swp
*~
```

## 안전 확인 (실수 방지)

```bash
# 1. 삭제 전 잘 들어있는지 확인 (중요 백업이 있다면)
ls environment/frontend_server/storage/base_the_ville_isabella_maria_klaus/ 2>/dev/null | head

# 2. .gitattributes 에서 원본 추적 의도 확인 (LFS 힌트)
cat .gitattributes 2>/dev/null

# 3. 원본 repo 의 README 에서 "필요한 데이터" 안내 확인
```

원본 generative_agents 의 경우 `storage/base_the_ville_isabella_maria_klaus/*` 와 `storage/base_the_ville_n25/*` 는 **baseline 시뮬레이션 시작점**이라 README 에서 안내하나, 결과 폴더는 **재생성 가능**. README 가이드가 우선.

## 추가 안전장치

```bash
# 큰 파일 찾기 (정렬 후 상위 20개)
find . -path ./.git -prune -o -type f -size +10M -print 2>/dev/null | \
  xargs -I {} du -h {} 2>/dev/null | sort -h | tail -20

# 또는 du 직접
du -h -d 3 2>/dev/null | sort -h | tail -10
```

이걸로 어디가 무거운지 미리 파악 후 .gitignore / rm -rf 결정.
