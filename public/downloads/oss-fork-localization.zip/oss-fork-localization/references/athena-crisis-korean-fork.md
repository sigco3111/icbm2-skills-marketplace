# Athena Crisis 한국어 fork — 부팅 검증 + i18n 인프라 레퍼런스

> **출처**: 2026-07-27 athena-crisis-kr fork 세션 실측. SKILL.md 본문은 워크플로 + 함정만 — 본 파일은 환경·디렉터리·후속 작업 상세.

## 1. 프로젝트 개요 (왜 fork 후보였나)

| 항목 | 값 |
|------|---|
| 원본 저장소 | https://github.com/nkzw-tech/athena-crisis |
| ⭐ | 1,967 |
| 라이선스 | **MIT** (Copyright 2024 Nakazawa Tech KK) |
| i18n 시스템 | **FBtee** (Facebook의 i18n 도구) — `ares/translations/ko_KR.json`로 한국어 |
| 한국어 상태 | 0% — `fbtee:prepare`에 `ko_KR` 등록만, 실제 번역 0줄 |
| 빌드 도구 | pnpm monorepo + Vite 8.1.5 + Node ≥23 (실제 22.23.1) |
| 부팅 검증 | ✅ HTTP 200 (offline/ 디렉토리) — 본 문서 §2 |
| 첫 PR까지 | 3~5일 (실측) — 본 문서 §5 |

**한국어화 가치 평가**:
- ✅ MIT (가장 짧은 의무) — LICENSE 보존 + README attribution만
- ⚠️ i18n 등록만 됨 (한국어 키 0) — sango/Evolve와 달리 `ko.json` 같은 기존 파일 없음
- ✅ `dionysus/` AI 모듈 + `athena/` 게임 로직 분리 → 자동전투 추가 가능
- ⚠️ 게임 컨텐츠 (`art/`, `music/`, `campaign/`)는 closed-source — fork는 **엔진만** 사용

## 2. 부팅 검증 워크플로 (9분, 실측)

### 디렉토리 구조 (codegen-only entry 가림)

```
athena-crisis-kr/                      # pnpm workspace root
├── apollo/                            # 클라이언트 (codegen 결과 의존)
├── ares/                              # ⚠️ codegen-only entry — open-source에서 부팅 불가
│   ├── package.json                   # (트래킹됨)
│   └── src/                           # ❌ 비어있음 (codegen 결과물, .gitignore됨)
├── artemis/                           # 서버 (codegen + Prisma 의존)
├── dionysus/                          # AI 모듈 (codegen 의존)
├── offline/                           # ✅ 자체 entry — 부팅 가능
│   ├── index.html
│   ├── index.js
│   ├── vite.config.ts                 # viteSingleFile + minify
│   └── package.json
├── docs/                              # ✅ 자체 entry — 부팅 가능
├── hera/, hermes/, zeus/, deimos/     # 게임 로직 모듈
├── codegen/                           # generate-all.tsx
├── infra/isOpenSource.tsx             # art/Variants.nkzw.tsx 존재 체크
├── pnpm-workspace.yaml
└── package.json                       # dev:client = PORTLESS_APP_PORT=3031 portless ...
```

### Step-by-step (실측 9분)

```bash
# [1분] 빈 디렉토리 + full clone
cd /Users/mac/work
git clone https://github.com/nkzw-tech/athena-crisis.git athena-crisis-kr  # 1,329 commits, 3~5초
cd athena-crisis-kr
git remote remove origin
git remote add origin https://github.com/sigco3111/athena-crisis-kr.git

# [1분] gh repo create
gh repo create sigco3111/athena-crisis-kr --public \
  --description "Athena Crisis 한국어 + 자동전투 (Vercel 정적 호스팅)" \
  --source=. --remote=origin --push=false
curl -s -o /dev/null -w "HTTP %{http_code}\n" "https://api.github.com/repos/sigco3111/athena-crisis-kr"
# HTTP 200 = OK

# [5분] pnpm install
pnpm install --prefer-offline
# Done in 2m 5.5s — peer dep warning 1건 (react-relay 21 vs @nkzw/relay-utils ^18||^19||^20) 무시

# [1분] 부팅 검증 — offline/ 직접 vite (portless 우회)
PORT=3031 pnpm exec vite --host 0.0.0.0 --port 3031 ./offline/ &
VITE_PID=$!
sleep 8
curl -s -o /dev/null -w "HTTP %{http_code}\n" http://localhost:3031/
# HTTP 200
curl -s http://localhost:3031/ | head -1
# <!doctype html>
curl -s http://localhost:3031/ | grep -i title
# <title>Athena Crisis</title>
kill $VITE_PID

# [1분] 첫 commit + push
git add README.md  # 한국어 안내 분기 추가
git -c user.name="sigco3111" -c user.email="sigco3111@users.noreply.github.com" \
  commit -m "fork: 한국어 안내 + 한국어화/자동전투/Vercel 호스팅 분기 ..."
git push -u origin main  # ✅ full clone이라 정상 push
```

## 3. 5단계 빌드 환경 분류 (확장, v1.19.0)

| 분류 | 빌드 도구 | 빌드 시간 | macOS 호환성 | 사례 |
|------|----------|----------|--------------|------|
| 🟢 즉시 성공 | `npm`/`yarn` (Vite) | 2초 | ✅ 네이티브 | OpenFrontIO, sango, Claude-of-Duty |
| 🟢 LÖVE/Lua | `love .` | 0초 | ✅ brew cask | SNKRX |
| 🟢 정적 HTML/JS | `python3 -m http.server` | 0초 | ✅ | Evolve |
| 🟡 pnpm monorepo (portless-free) | `pnpm exec vite ./offline/` | 2초 | ✅ | **athena-crisis** |
| 🟡 Java/Gradle | `./gradlew` | 30초~5분 | ✅ | triplea, FreeCol |
| 🟠 Rust/cargo | `cargo build` | 1~5분 | ✅ | zemeroth, veloren |
| 🔴 C++ scons/CMake | `scons`/`make` | 30분~1시간 | ⚠️ | Wesnoth |
| ⚫ C# | `dotnet`/`mono` | 1~5분 | ⚠️ | RTK2020-CORE |

## 4. portless 도구 함정 — 상세

### portless가 필요한 이유 (정확한 이해)

`portless`는 **HTTPS reverse proxy + 멀티 프로젝트 라우터**:
- `https://athena-crisis.local.test/` → vite dev (port 3031)
- `https://api.athena-crisis.local.test/` → artemis server (port 3032)
- HTTPS 필수 (service worker, geolocation, secure context API 사용 위함)
- **macOS sudo**: hosts 파일 수정 + port 80/443 바인딩 위해 필요

### Hermes 헤드리스에서 fail하는 이유

```
> portless athena-crisis ./ares/ares.tsx

portless
Proxy is not running and no TTY is available for sudo.
Option 1: start the proxy in a terminal (will prompt for sudo):
  sudo portless proxy start --https
```

- `sudo`는 **TTY에서만 password 입력 받음** — 비-TTY stdin은 password 못 받음 → fail
- Hermes `terminal()`은 비-TTY → portless HTTPS 모드 시작 불가
- 대안 제시 (`--port 1355`)도 sudo 필요 (port < 1024 회피용)

### 우회 4가지 패턴

| 패턴 | 명령어 | 부팅 가능성 | 비고 |
|------|--------|-------------|------|
| **A) 자체 entry 직접 vite** | `pnpm exec vite ./offline/` | ✅ | 가장 안정 |
| **B) `--port 1355` portless** | `sudo portless proxy start --port 1355 --https` | ❌ sudo 필요 | 헤드리스 불가 |
| **C) `dev:client` script 우회** | `pnpm run dev:client` | ❌ 내부에서 portless 호출 | 동일 fail |
| **D) `dangerouslyAllowUnhandledRequests`** | 없음 | ❌ | portless 자체가 sudo 필수 |

**패턴 A만 가능**. `offline/`이 자체 vite.config.ts를 보유하는 게 결정적.

### 판별: portless 사용 저장소인지 첫 30초에 알기

```bash
# package.json scripts에서 portless grep
grep -n "portless" package.json
# PORTLESS_APP_PORT=3031 portless athena-crisis ./ares/ares.tsx
# → portless 사용 저장소

# 대안 entry 후보 자동 탐색
ls -d */ 2>&1 | while read d; do
  if [ -f "$d/index.html" ] && [ -f "$d/vite.config.ts" ]; then
    echo "✅ bootable: $d"
  elif [ -f "$d/vite.config.ts" ]; then
    echo "⚠️  vite-only: $d"
  fi
done
```

## 5. 한국어화 후속 워크플로

### FBtee 워크플로 (표준, 5일 작업)

```bash
# 1. 한국어 키 추출
pnpm fbtee:collect
# → source_strings.json 생성 (영문 키 + 한국어 빈 msgstr)

# 2. 한국어 msgstr 채우기 (수동 + Python 일괄 매핑)
# → source_strings.json 그대로 수정

# 3. fbtee translate → ares/translations/ko_KR.json 생성
pnpm fbtee:translate
# → 한국어 200~500 키 자동 번역 (Google Translate API 옵션)

# 4. 빌드 검증
pnpm build:offline
# → dist/offline/index.html 단일 파일 (한글 폰트 + 한국어 UI 번들)
```

### 한국어 fbtee 키 위치 (실측 grep)

| 패턴 | 위치 | 처리 |
|------|------|------|
| `fbt(...)` 호출 | `hera/`, `apollo/`, `ui/` (src 디렉토리) | 한국어 번역 필요 |
| `<fbt>` JSX 태그 | `hera/` (UI 컴포넌트) | 한국어 번역 필요 |
| `fbt:param` | 동적 키 | placeholder 보간 |
| `Intl.Plural` | 복수형 | 한국어는 단/복 구분 없음 → 1형태로 |

### 자동전투 AI 통합 위치

```
dionysus/                          # AI 모듈 (codegen 의존)
├── ai/                            # 평가 함수 + 결정 알고리즘
└── scripts/

athena/                            # 게임 로직
├── info/Unit.tsx                  # 유닛 정의
├── map/Map.tsx                    # 맵 정의
└── Game.tsx                       # 게임 루프

hera/                              # UI 컴포넌트
└── game/                          # 게임 화면
```

**자동전투 추가 패턴**:
1. `dionysus/ai/`의 결정 함수를 결정론적(자동) 모드로 wrap
2. `athena/Game.tsx`의 메인 루프에 `autoPlay: boolean` 옵션 추가
3. `hera/game/` 메뉴에 "자동전투 시작/정지" 버튼 추가
4. fbtee 키 추가: `game.autoplay.start`, `game.autoplay.stop` 등

## 6. Vercel 정적 호스팅

### 자동 배포 설정

`vercel.json` (저장소 루트):
```json
{
  "buildCommand": "pnpm build:offline",
  "outputDirectory": "dist/offline",
  "framework": null,
  "rewrites": [{"source": "/(.*)", "destination": "/index.html"}]
}
```

### 빌드 산출물

`pnpm build:offline` 실행 시:
```
dist/offline/
├── index.html       # 모든 JS/CSS 인라인 (viteSingleFile)
├── fonts/           # AthenaNova.woff2 등
├── keyart.jpg
└── manifest.json
```

→ Vercel 자동 CDN 배포: `https://athena-crisis-kr.vercel.app/`

### 단일 파일의 장점

- service worker 등록 가능 → 오프라인 플레이
- HTML 1개에 모든 의존성 → 캐시 단순화
- 한국어 fbtee 키가 inline → 추가 fetch 불필요

## 7. 진단 워크플로 (다른 사람이 같은 함정 만날 때)

```bash
# 1. 부팅 검증 실패 시 — 어느 entry가 살아있는지
for entry in offline docs web static client app; do
  if [ -f "$entry/vite.config.ts" ]; then
    echo "✅ $entry/vite.config.ts"
    cat "$entry/vite.config.ts" | head -10
    echo "---"
  fi
done

# 2. codegen 성공 후 실제 파일 생성 확인
pnpm codegen
ls -la apollo/EncodedActions.tsx i18n/Entities.ts hera/i18n/MessageMap.tsx 2>&1
# 모두 존재하면 OK, 하나라도 없으면 codegen 분기 확인

# 3. portless 의존성 확인
grep -l "portless" package.json apollo/package.json ares/package.json 2>&1

# 4. isOpenSource 분기 트래킹
grep -rn "isOpenSource\|Variants.nkzw" infra/ codegen/ --include="*.tsx" | head -5
# → closed-source 의존 entry 식별

# 5. push 실패 시 — depth 확인 + unshallow 레시피 (NEW, evolve-kr 2026-07-27 검증)
git rev-list --parents -n 1 HEAD | wc -w
# 1 = root commit (push OK)
# 2 = has parent (depth 1 = parent 없음 → push fail 시 parent fetch 필요)

# 증상:
#   remote: fatal: did not receive expected object <hash>
#   error: remote unpack failed: index-pack failed
#
# 원인: --depth 1로 받은 커밋의 부모 hash를 remote가 검증하라고 요구하지만 로컬에는 없음.
#       빈 GitHub 저장소(gh repo create 직후)에도 부모 검증 단계가 있어 fail.
#
# 해결 (3단계):
git remote add upstream https://github.com/<org>/<repo>.git
git fetch --unshallow upstream          # 원본 전체 커밋 복원 (evolve-kr: 4,691 커밋)
git push -u origin main                  # "cannot lock ref" race condition 1회 재시도 시 idempotent
#
# 예방: --depth 1 대신 처음부터 full clone. fork 워크플로는 push가 항상 필요하므로 shallow는 안티패턴.

# 6. npm install 실패 — package.json에 가짜 npm 패키지 함정 (NEW, evolve-kr 2026-07-27)
# 증상:
#   npm error Error: Cannot find module 'node-darwin-arm64/package.json'
#   npm error Require stack: node_modules/node/installArchSpecificPackage.js
#
# 원인: package.json dependencies에 "node": "^16.1.0" + "npmcli": "^1.2.2"처럼
#       잘못된 npm 패키지 이름이 들어간 경우 (pmotschmann/Evolve가 대표 사례).
#       node-bin-setup이 arch별 바이너리를 받아오는데 Node 22에서 동작 안 함.
#       전체 install을 죽이고 node_modules/도 생성 안 됨.
#
# 해결: build/runtime에 실제로 필요한 도구만 --ignore-scripts로 별도 설치
npm install --ignore-scripts \
  esbuild@0.25.0 less@3.13.0 servehere@1.7.0 csso-cli@4.0.2
# → "added 208 packages in 1s"
npm run evolve && npm run evolve-less && npm run wiki && npm run wiki-less
#
# 판별 (5분):
cat package.json | python3 -c "import json,sys; d=json.load(sys.stdin); print(d.get('dependencies',{}))"
# → "node" + "npmcli" 의도가 dependencies에 들어갔는지 확인
#
# 근본 수정: package.json dependencies에서 node/npmcli 라인을 삭제. fork-local은
# --ignore-scripts 우회로 빌드 가능하게 만들고, upstream cleanup PR은 별도.
```

## 8. 후속 권장 작업 우선순위

1. **즉시** (5분): `git remote add upstream https://github.com/nkzw-tech/athena-crisis.git` + README 한국어 안내 박기
2. **단기** (1일): fbtee 키 수집 + 한국어 msgstr 200개 번역
3. **중기** (3일): `dionysus/` AI 결정 함수 분석 → 자동전투 wrapper 추가
4. **장기** (1주): Vercel 배포 + 도메인 연결

## 9. 메트릭 (실측)

| 항목 | 값 |
|------|---|
| 풀 클론 시간 | 3~5초 (1,329 commits) |
| pnpm install 시간 | 2분 5.5초 |
| offline vite 부팅 시간 | 1.68초 (Vite ready in 1680ms) |
| HTTP 200 응답 | 즉시 |
| HTML 응답 크기 | ~5KB (Vite client + minimal HTML) |
| 첫 commit → push | 1분 |
| **총 작업 시간** | **~9분** |