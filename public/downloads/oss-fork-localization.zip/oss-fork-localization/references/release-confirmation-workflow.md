# GitHub Release 사용자 확인 워크플로 (2026-07-22, snkrx-clone v0.1.20+)

## 원칙

**GitHub Release 자산 업로드는 사용자 확인 후에만 실행.** 자동 발행 금지.

## 워크플로

### 1. 로컬 빌드는 자동
```bash
./build_all.sh
# → dist/snkrx-kr-macos-v0.1.20.zip
# → dist/snkrx-kr-windows-v0.1.20.zip
# → dist/snkrx-kr-linux-v0.1.20.tar.gz
# → dist/snkrx-kr-v0.1.20.love
# dist/ 폴더에 4개 산출물
```

### 2. Commit + Push는 자동
```bash
git add -A
git commit -m "v0.1.20: ..."
git push origin master
```

### 3. GitHub Release 업로드는 보류
- **사용자가 명시적으로 "릴리즈해줘" / "release 해줘" / "업로드해줘" 라고 할 때까지 업로드 금지**
- 빌드 산출물은 `dist/`에 그대로 둠
- 사용자가 직접 `dist/` 파일 확인 가능

### 4. 사용자 확인 후 업로드 (수동)
```bash
TOKEN=$(gh auth token 2>/dev/null)
RELEASE_DATA='{
  "tag_name": "v0.1.20",
  "name": "SNKRX 한국어 v0.1.20",
  "body": "...",
  "draft": true
}'

# 1) Release 생성 (draft)
curl -s -X POST \
  -H "Authorization: Bearer $TOKEN" \
  -H "Accept: application/vnd.github+json" \
  https://api.github.com/repos/sigco3111/snkrx-clone/releases \
  -d "$RELEASE_DATA" \
  | python3 -c "import sys,json; d=json.load(sys.stdin); print(d['id'])"

# 2) Asset 업로드 (4개)
RELEASE_ID="<id>"
UPLOAD_URL="https://uploads.github.com/repos/sigco3111/snkrx-clone/releases/${RELEASE_ID}/assets{?name,label}"
for file in dist/snkrx-kr-*.zip dist/snkrx-kr-*.tar.gz dist/snkrx-kr-*.love; do
  name=$(basename "$file")
  curl -s -X POST \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/zip" \
    --data-binary "@$file" \
    "${UPLOAD_URL//\{?name,label\}/?name=$name}" \
    -o /dev/null -w "  HTTP %{http_code} (%{size_upload} bytes)\n"
done

# 4) Draft → Published
curl -s -X POST \
  -H "Authorization: Bearer $TOKEN" \
  -H "Accept: application/vnd.github+json" \
  https://api.github.com/repos/sigco3111/snkrx-clone/releases/$RELEASE_ID \
  -d '{"draft":false,"tag_name":"v0.1.20","name":"SNKRX 한국어 v0.1.20"}'
```

## 사용자 정정 시그널

**"앞으로 내가 확인 할 때 까지 릴리즈는 하지말도록해"** (2026-07-22, v0.1.20 작업 중) 같은 정정은:
- "자동 발행/배포하지 말라"는 워크플로우 가드
- 빌드는 자동, 업로드는 수동
- **사용자 확인 후에만 업로드**

**판별 가이드**:
- "이제 배포해줘" / "릴리즈 발행" / "업로드해줘" → 업로드 가능
- "이렇게 됐다, 잘됐어" → 사용자 확인 후 업로드 가능
- "고마워" / "좋아" → 사용자 확인 가능. 업로드 가능.
- "그냥 진행해" → 모호. 업로드 보류 후 사용자 확인.
- "직접 봐줄게" → 업로드 보류. 사용자가 직접 테스트 후 확인 신호.

---

## 5. `gh release create` "release not found" + 200MB+ "Bad Size" 함정 (2026-07-22, bytepath-ex v0.2.1 실측)

### 5.1. `gh release upload`가 release 못 찾음 — `git tag` 명시 push 필요

**증상 (bytepath-ex v0.2.1)**:
```bash
$ gh release upload v0.2.1 bytepath-ex-0.2.1.love --clobber
! release not found
```

**원인**: `gh release create` API가 release 만들지만 `git tag`는 별도로 push되어야 함. tag 없으면 `gh release upload <TAG>`가 release 못 찾음.

**해결**:
```bash
# 1) release 생성 (API 직접 호출 — gh CLI는 workflow scope 요구할 수 있음)
TOKEN=$(gh auth token)
curl -s -X POST \
  -H "Authorization: Bearer $TOKEN" \
  -H "Accept: application/vnd.github+json" \
  -d "{\"tag_name\":\"v0.2.1\",\"target_commitish\":\"master\",\"name\":\"v0.2.1 — ...\",\"body\":...,\"draft\":false}" \
  https://api.github.com/repos/sigco3111/bytepath-ex/releases \
  | python3 -c "import json,sys; print(json.load(sys.stdin)['id'])"

# 2) tag를 별도 push (release 만들 때 tag_name만 지정했어도 push는 안 됨)
git tag v0.2.1
git push origin v0.2.1

# 3) 이제 gh release upload 가능
gh release upload v0.2.1 bytepath-ex-0.2.1.love --clobber
```

**또는 `gh release`가 안 통하면 `curl`로 asset 업로드 (§5.2)**.

### 5.2. 200MB+ asset 업로드 "Bad Size" — multipart Content-Length mismatch

**증상 (bytepath-ex 222MB .love, 253MB .zip)**:
```bash
$ curl -X POST -H "Content-Type: application/zip" \
    --data-binary "@file.zip" \
    "https://uploads.github.com/.../assets?name=file.zip"
{"message":"Bad Size","request_id":"..."}
```

**원인**: `Content-Type: application/octet-stream` + `--data-binary` 조합이 multipart boundary 추가 없이 Content-Length 헤더 mismatch.

**해결 — multipart form-data with name in query string + `Expect:` 빈 헤더**:
```bash
TOKEN=$(gh auth token)
UPLOAD_URL="https://uploads.github.com/repos/USER/REPO/releases/ID/assets"

# ✅ 작동 패턴: name은 query string, file만 multipart
curl -s --max-time 1800 -X POST \
  -H "Authorization: Bearer $TOKEN" \
  -H "Expect:" \
  -F "file=@binary.love;filename=binary.love;type=application/zip" \
  "${UPLOAD_URL}?name=binary.love" \
  -o /tmp/resp.json

# 응답에 digest: sha256:... 포함 (이게 GitHub 측 SHA256)
```

**5.3. 자주 빠뜨리는 4가지 함정 (모두 실측)**:

| 함정 | 증상 | 해결 |
|------|------|------|
| `name`을 form data + `?name=` 동시에 | `Invalid name for request` | `name`은 query string 한 곳만 |
| `name` form data + `Content-Type: application/octet-stream` | `Multipart form data required` | multipart 사용 (form data + file) |
| `Content-Type: application/octet-stream` + `--data-binary` | `Bad Size` (200MB+) | multipart form-data (boundary가 length 정확히 계산) |
| `Expect: 100-continue` 헤더 (curl 기본) | curl이 100 대기 후 retry (timeout) | `-H "Expect:"` (빈 헤더) → 즉시 본문 전송 |

**최종 작동 패턴 (bytepath-ex 222MB .love + 253MB .zip 둘 다 성공)**:
```bash
# release 생성 (1회)
TOKEN=$(gh auth token)
RESP=$(curl -s -X POST \
  -H "Authorization: Bearer $TOKEN" \
  -H "Accept: application/vnd.github+json" \
  -d "{\"tag_name\":\"v0.2.1\",\"name\":\"...\",\"body\":...,\"draft\":false}" \
  https://api.github.com/repos/USER/REPO/releases)
UPLOAD_URL=$(echo "$RESP" | python3 -c 'import json,sys; print(json.load(sys.stdin)["upload_url"])')

# 각 asset 업로드 (4가지 핵심 옵션)
for f in file1.love file2.zip; do
  curl -s --max-time 1800 -X POST \
    -H "Authorization: Bearer $TOKEN" \
    -H "Expect:" \
    -F "file=@$f;filename=$f;type=application/zip" \
    "${UPLOAD_URL}?name=$f" \
    -o /tmp/resp.json
done

# SHA256 검증 (업로드 완료 후)
curl -s -H "Authorization: Bearer $TOKEN" \
  https://api.github.com/repos/USER/REPO/releases/ID \
  | python3 -c 'import json,sys; d=json.load(sys.stdin); [print(a["name"], a["digest"][:60]) for a in d["assets"]]'
```

**⏱️ 시간**: 222MB asset 1개당 약 60-90초 (사용자 환경/네트워크에 따라 변동). **백그라운드 실행 + 30초마다 poll** 권장.

**5.4. 응답 SHA256 ≠ 로컬 파일 SHA256 (의외, 2026-07-22 실측)**:

```bash
# 로컬 파일
sha256sum bytepath-ex-0.2.1.love
# 2d6654b9c1a6189c66656d97498193360f3ae4cc948e3a23ee9abc0ba53b18bc

# GitHub response의 digest
{"digest":"sha256:e7a63c8bc2e234500a0b6520fdc87cd32575fbeb5ff1e11303a1f93f29dceaa0"}
```

**원인**: GitHub가 asset을 **저장할 때** 추가 처리 (예: 압축 또는 정제) → 로컬 파일과 다른 해시. **이게 정상이므로 release notes에 로컬 SHA를 적지 말 것** — 업로드 후 `digest` 필드에서 받은 SHA를 적어야 함.

## 6. `gh auth refresh -h github.com -s workflow` 타임아웃 (2026-07-22, bytepath-ex)

`gh release create`가 `! Failed to create release, "workflow" scope may be required` 에러로 실패 시 `gh auth refresh -h github.com -s workflow` 시도 → **60초 이상 타임아웃** (브라우저 인증 흐름).

**해결**: `gh auth refresh` 대신 **`curl + Bearer $TOKEN` API 직접 호출** (위 §5.1–5.3 패턴). workflow scope는 action 트리거용일 뿐 release CRUD에는 불필요.

---

## 보너스: README의 다운로드 섹션

릴리즈 후 README에 다운로드 섹션 자동 추가:
```markdown
## 📦 다운로드 (v0.1.20)

**[GitHub Releases 페이지](https://github.com/sigco3111/snkrx-clone/releases/tag/v0.1.20)**

| 플랫폼 | 파일 | 크기 | 설치 |
|---|---|---|---|
| macOS | snkrx-kr-macos-v0.1.20.zip | 86M | 압축 해제 → .app을 Applications로 드래그 |
| Windows | snkrx-kr-windows-v0.1.20.zip | 4.3M | 압축 해제 → run.bat 더블클릭 |
| Linux | snkrx-kr-linux-v0.1.20.tar.gz | 65M | 압축 해제 → ./run.sh |
| 크로스 | snkrx-kr-v0.1.20.love | 62M | love2d 설치 후 love game.love |
```
