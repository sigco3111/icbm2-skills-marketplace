# 🎮 LÖVE/Lua 게임 fork-한글화 성공 사례: snkrx-clone (2026-07-21)

> SNKRX(a327ex/SNKRX, MIT, 22K LOC, LÖVE/Lua 5.3 기반 오토배틀러 로그라이크)를 fork해서
> **30분 만에** 핵심 모드팩 + CJK 폰트 fallback + 메인 메뉴/상점 한국어 적용 완료.

이 레퍼런스는 **LÖVE/Lua 엔진 게임 fork-한글화 시 복사용**으로 가치가 큼.
sango-rising-dragons(TypeScript/Phaser)의 JSON 모드팩과 다른 **Lua 코드 내장 텍스트** 케이스를 다룸.

## 왜 LÖVE/Lua 게임이 별도 클래스인가

| 구분 | sango-rising-dragons (TypeScript) | SNKRX (Lua) |
|------|-----------------------------------|--------------|
| 엔진 | Phaser 3 + Vite 6 | LÖVE 11 + Lua 5.3 |
| 텍스트 위치 | `public/data/{pack}/*.json` 데이터 | Lua 코드 안에 `'arena run'` 리터럴 |
| 모드팩 방식 | JSON 디렉토리 + mergeById | `T()` 함수 + `lang/<code>.lua` 모듈 |
| 폰트 | 브라우저 자동 fallback | LÖVE 11.x TTF BitmapFont 수동 구현 |
| 빌드 검증 | `npm run dev` HTTP 200 | `luac -p` syntax 검증 (헤드리스 love는 SIGKILL) |
| 패턴 | data override | code string override |

**핵심 차이**: LÖVE 게임은 데이터(JSON/PO) 외부화가 거의 안 되어 있어 **코드 자체를 T() 함수로 우회**해야 함.

## 작업 시간 (실측)

| 단계 | 시간 | 비고 |
|------|------|------|
| LÖVE 설치 (`brew install --cask love`) | 1분 | macOS Gatekeeper deprecation 경고 (2026-09-01까지) |
| 클론 + 구조 파악 | 5분 | 22K LOC, 12개 .lua + engine/ |
| MODIFIED.md 작성 (MIT 표시) | 2분 | 라이선스 의무 |
| Noto Sans KR 폰트 다운로드 | 1분 | 4.6MB TTF |
| `lang/ko.lua` + `T()` 함수 구현 | 5분 | 모드팩 패턴 |
| CJK 폰트 lazy fallback (3파일 패치) | 10분 | font.lua + text.lua + graphics.lua |
| 메인 메뉴 + 상점 핵심 텍스트 교체 | 5분 | 9개 버튼 + 5개 탭 + 튜토리얼 9줄 |
| `luac -p` syntax 검증 | 1분 | 12개 파일 |
| **합계** | **~30분** | (sango 2.5시간 vs SNKRX 30분) |

## 핵심 패턴: T() 함수 + lang/<code>.lua

### shared.lua (가장 먼저 require되는 모듈)

```lua
function shared_init()
  -- ... 기존 색상/사운드 초기화 ...
  
  fat_font = Font('FatPixelFont', 8)
  pixul_font = Font('PixulBrush', 8)
  
  -- 한국어화 모듈 (v0.1)
  lang = lang or {}
  lang.current = 'ko'
  lang.dicts = {}
  lang.dicts.en = {}  -- 영어 = 원본 (모든 키의 default가 영어)
  lang.dicts.ko = require('lang.ko')
  lang.fallback = 'en'
  
  function T(key, default)
    local dict = lang.dicts[lang.current] or {}
    local fb = lang.dicts[lang.fallback] or {}
    if dict[key] ~= nil then return dict[key] end
    if fb[key] ~= nil then return fb[key] end
    return default or key
  end
end
```

### lang/ko.lua (모듈식 번역 테이블)

```lua
-- 누락 시 T(key, default)가 default를 그대로 표시하므로 영어 원본 안전 폴백
return {
  -- 메인 메뉴
  arena_run = '아레나 런',
  options = '옵션',
  quit = '종료',
  -- 상점 탭
  shop_label = '상점',
  party_label = '파티',
  classes_label = '클래스',
  -- 튜토리얼
  welcome_desc1 = '당신은 자동으로 근처 적을 공격하는 여러 영웅의 뱀을 조종합니다.',
  -- ... ~80 키 ...
}
```

### 사용 패턴

```lua
-- mainmenu.lua
-- Before
self.arena_run_button = Button{..., button_text = 'arena run', ...}

-- After
self.arena_run_button = Button{..., button_text = T('arena_run', 'arena run'), ...}
```

**장점**:
- `default`가 영어 원본이라 **폴백 안전** — ko.lua에 키 없으면 영어 표시
- `lang.current = 'en'` 한 줄 변경만으로 **전체 UI 영어로 복귀**
- ja/zh 모드팩 추가도 같은 패턴 (`lang/ja.lua` + `lang.current = 'ja'`)
- 원본 코드 구조 유지 — fork-친화적

## CJK 폰트 자동 fallback (LÖVE 11.x 핵심 함정)

### 문제

LÖVE 11.x의 `love.graphics.newFont(path, size)`는 TTF BitmapFont를 만들고, **TTF에 없는 glyph는 깨진 사각형으로 표시**.
영어 게임 (`FatPixelFont.ttf`, `PixulBrush.ttf`)에는 한글 glyph가 없어서 **한글이 □로 깨짐**.

### 해결: lazy fallback (3파일 패치 필수)

**1. `engine/graphics/font.lua` — Font 클래스에 CJK 헬퍼 추가**:

```lua
function Font:has_cjk(text)
  if not text then return false end
  for i = 1, #text do
    local b = string.byte(text, i)
    if (b >= 0xE0 and b <= 0xEF) then return true end  -- 멀티바이트 CJK
  end
  return false
end

function Font:_ensure_ko_font()
  if self.ko_font then return self.ko_font end
  local ko_path = "assets/fonts/NotoSansKR-Regular.ttf"
  if love.filesystem.getInfo(ko_path) then
    self.ko_font = love.graphics.newFont(ko_path, self.size)
  else
    self.ko_font = self.font
  end
  return self.ko_font
end

function Font:get_font_for_text(text)
  if self:has_cjk(text) then return self:_ensure_ko_font() end
  return self.font
end

function Font:get_text_width(text)
  if self.ko_font and self:has_cjk(text) then
    return self.ko_font:getWidth(text)
  end
  return self.font:getWidth(text)
end
```

**2. `engine/graphics/graphics.lua` — `graphics.print`/`print_centered` 패치**:

```lua
function graphics.print(text, font, x, y, r, sx, sy, ox, oy, color)
  local _r, g, b, a = love.graphics.getColor()
  if color then love.graphics.setColor(color.r, color.g, color.b, color.a) end
  local active_font
  if font.get_font_for_text then
    active_font = font:get_font_for_text(text)
  else
    active_font = font.font
  end
  love.graphics.print(text, active_font, x, y, r or 0, sx or 1, sy or 1, ox or 0, oy or 0)
  if color then love.graphics.setColor(_r, g, b, a) end
end
```

**3. `engine/graphics/text.lua` — `Text:format_text` + `Text:draw` 패치**:
- `format_text`에서 line_width 계산 시 `get_font_for_text` 사용
- `draw`에서 캐릭터별로 CJK 감지 후 ko_font로 그리기

**한 곳 빠지면 텍스트 폭 어긋남**: font.lua만 패치하면 텍스트는 그려지지만 폭 계산이 영어 폭 → 한글 글자 겹침/짤림. **3곳 모두 필수**.

## Lua 5.5 luac 함정 — and-or 패턴 실패

### 문제

`luac -p` (Lua 5.5) 검증 시 다음 패턴이 **"function arguments expected near 'and'"** 에러로 실패:

```lua
-- ❌ luac -p 에러
local active_font = font:get_font_for_text and font:get_font_for_text(text) or font.font
```

**원인 추정**: Lua 5.5 파서가 `font:get_font_for_text and font:get_font_for_text(text)`를 함수 인자 목록으로 잘못 해석.

### 해결: 명시적 if/else

```lua
-- ✅ 안전
local active_font
if font.get_font_for_text then
  active_font = font:get_font_for_text(text)
else
  active_font = font.font
end
```

**즉시 적용 규칙**: Lua 코드에서 `x.method and x.method() or x.field` 안드로이드 패턴 **절대 금지**. 항상 명시적 if/else.

## patch() 함정 — Lua 게임 false match

### 문제

SNKRX buy_screen.lua 1541번에서 `patch()`가 steam_button 코드를 ItemCard:on_mouse_enter에 잘못 매칭하는 사고 발생 → `function ItemCard:on_mouse_enter()`가 중복 → `end expected near <eof>` syntax 에러.

**원인**: 두 코드 모두 `function X:on_mouse_enter()` 비슷한 시그니처 + Button 패턴이 매칭 가능.

### 해결

```lua
-- ❌ 짧은 anchor → false match 위험
function ItemCard:on_mouse_enter()
  self.selected = true

-- ✅ 충분한 context (앞/뒤 5줄)
function ItemCard:on_mouse_enter()
  self.selected = true
  ui_hover1:play{pitch = random:float(1.3, 1.5), volume = 0.5}
  self.spring:pull(0.2, 200, 10)
  self:create_info_text()
end
```

**즉시 적용 규칙**:
1. patch() anchor는 **앞/뒤 최소 5줄 context** 포함
2. 패치 후 **반드시 `luac -p` 검증** (모든 .lua 한 번에)
3. 실패 시 `git checkout -- <file>`로 원본 복구 후 재시도

## 검증 도구 — `luac -p` 표준 워크플로

LÖVE는 GUI 앱이라 헤드리스에서 실행 시 SIGKILL로 죽어서 검증 불가. **luac로 syntax 검증만 가능**.

### 표준 검증 스크립트

```bash
cd {project}
for f in shared.lua main.lua mainmenu.lua buy_screen.lua arena.lua enemies.lua player.lua objects.lua media.lua engine/graphics/font.lua engine/graphics/text.lua engine/graphics/graphics.lua lang/ko.lua; do
  echo -n "$f: "
  luac -p "$f" 2>&1 && echo "OK"
done
```

**출력 예**:
```
shared.lua: OK
main.lua: OK
mainmenu.lua: OK
...
engine/graphics/font.lua: OK
engine/graphics/text.lua: OK
engine/graphics/graphics.lua: OK
lang/ko.lua: OK
```

**한 파일이라도 FAIL이면 실행 불가** — love 프로세스가 시작 즉시 죽음 (에러 메시지 stderr 없음).

### GUI 실행 (사용자 직접)

```bash
# macOS
love .

# 또는 brew로 설치한 경우
/opt/homebrew/bin/love .
```

## MODIFIED.md 템플릿 (MIT 라이선스용)

```markdown
# MODIFIED.md — {게임명} 한국어화 + 개선

이 문서는 [{owner}/{repo}](url)의 fork에서 **무엇이 변경되었는지** 명시합니다
({라이선스} §원본 저작권 의무 준수).

## 원본 정보

| 항목 | 값 |
|------|-----|
| 원본 저장소 | https://github.com/{owner}/{repo} |
| 원본 라이선스 | {MIT/Apache 2.0/GPL/...} |
| 원본 저작권자 | {copyright holder} ({year}) |
| Steam | {steam url if applicable} |

## Fork 정보

| 항목 | 값 |
|------|-----|
| Fork 저장소 | sigco3111/{repo} |
| 목적 | {한국어화 + 콘텐츠 확장 + 자동위임 + UI 개선} |
| 작성자 | sigco3111 |

## 변경 이력

### v0.1 ({date}) — 한국어화 + 모드팩 패턴 도입
- [x] MODIFIED.md 작성
- [x] `lang/ko.lua` 한국어 텍스트 모듈 추가
- [x] `T()` 함수 + CJK 폰트 lazy fallback
- [x] 메인 메뉴 + 상점 핵심 텍스트 번역

## 라이선스 준수 사항

- 원본 {LICENSE} 파일 그대로 보존
- 모든 원본 저작권 표시 유지
- 원본 자산 라이선스 — 게임 내 크레딧 화면 참조 (변경 없음)
- 본 fork로 인한 파생 저작물도 {원본 라이선스} 적용
```

## 다른 LÖVE/Lua 게임에 적용하는 체크리스트

```
□ 1. 빌드 환경 분류 확인 (LÖVE/Lua = 🟢 즉시)
□ 2. `brew install --cask love` (macOS Gatekeeper deprecation 경고 확인)
□ 3. `git clone https://github.com/{owner}/{repo}`
□ 4. LICENSE 확인 → MODIFIED.md 작성 (MIT/Apache 2.0/GPL 등)
□ 5. conf.lua의 love 버전 vs brew 설치 버전 호환 확인
□ 6. 메인 진입점 (`main.lua`) require 순서 파악
□ 7. Font 클래스 위치 확인 (engine/graphics/font.lua)
□ 8. 텍스트 위치 파악: `grep "text = '" *.lua | head -50`
□ 9. Noto Sans KR (또는 CJK 폰트) 다운로드 → assets/fonts/
□ 10. Font:has_cjk + get_font_for_text 추가 (lazy init)
□ 11. graphics.print/print_centered 패치 (CJK 자동 전환)
□ 12. Text:format_text + Text:draw 패치 (폭 + 그리기)
□ 13. shared.lua에 T() 함수 + lang 모듈 추가
□ 14. lang/ko.lua 작성 (~50~200 키, 영어 default 폴백)
□ 15. 모든 button_text + Text{...} 의 string 리터럴 → T() 호출로 교체
□ 16. `luac -p` 검증 (모든 .lua 한 번에)
□ 17. `love .` 실행 → 사용자가 직접 GUI 검증 (헤드리스 불가)
```

## 학습 기록

- **2026-07-21 (snkrx-clone 성공)**: LÖVE/Lua 게임 fork-한글화는 30분 내 가능. sango(TS)와는 다른 클래스이지만 같은 효율성.
- **2026-07-21**: LÖVE 11.x의 TTF BitmapFont 한글 깨짐 → lazy ko_font fallback이 표준 해결책.
- **2026-07-21**: Lua 5.5 luac 엄격성 → `x.method and x.method() or x.field` 패턴 실패, 명시적 if/else 권장.
- **2026-07-21**: patch()가 Lua 메서드 정의 사이에서 false match → 충분한 context (앞/뒤 5줄) + luac 검증 필수.
- **2026-07-21**: love 헤드리스 실행 SIGKILL → luac -p가 유일한 검증 도구, GUI 실행은 사용자 직접.
- **2026-07-21**: 모드팩 (JSON) vs T() 함수 (Lua) — 데이터 외부화 여부에 따라 패턴 분기.