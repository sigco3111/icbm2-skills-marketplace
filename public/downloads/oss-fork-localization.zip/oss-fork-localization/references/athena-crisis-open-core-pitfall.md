# 🚨 Open Core / 비공개 본체 함정 (NEW, 2026-07-27, athena-crisis-kr 실측)

> Athena Crisis(nkzw-tech/athena-crisis, ⭐1967, MIT) 한국어 fork에서 4시간 투자 후 깨달은 교훈.
> **공개 repo + i18n 모듈 분리 + 한국어 0%** 같은 "완벽해 보이는" 신호가 **빌드 가능성을 보장하지 않음**.
> Wesnoth(C++/Boost/SDL)보다 훨씬 단순해 보여서 5분 preflight를 건너뛴 결과, 9단계 워커 + 4시간이 Open Core라는 벽에 부딪힘.

## 무엇이 문제였나

**Athena Crisis의 공개 repo 구조**:
- `ares/`: `package.json` + `node_modules/` + `src/generated/` (빈 폴더) — **본체 소스 0개**
- `deimos/`, `dionysus/`: 동일 패턴 (워크스페이스 스텁만)
- `.gitignore`에 핵심 산출물들 명시:
  ```
  ares/.enum_manifest.json
  ares/.src_manifest.json
  ares/**/__generated__
  ares/src/generated/*
  ares/vite.config.ts.timestamp-*
  ```
- `art/Variants.nkzw.tsx`: paid 모드 마커. `existsSync`로만 검사. 빌드 차단/허용과 무관.

**즉, 공개 repo를 clone만 하면 `pnpm build:client`가 항상 실패**:
```
[UNRESOLVED_ENTRY] Cannot resolve entry module ares/vite.config.ts
```

`ares/vite.config.ts`, `ares/src/*.tsx`, `deimos/`, `dionysus/` 본체 소스는 **모두 비공개 저장소에 있음**. README/웹사이트/Discord에서만 배포본을 받음. **공식 라이선스(MIT)는 클라이언트/엔진이 아니라 web/app 배포본에 적용**되고, 소스 자체는 Open Core 정책.

## 5분 preflight로 잡을 수 있던 신호 5가지

| 신호 | Athena Crisis 실측 | 일반화 |
|---|---|---|
| 1. **모노레포인데 워크스페이스 디렉토리가 비어있음** | `ares/src/` (빈 폴더), `dionysus/` (스텁만) | "의존성만 공개, 본체 비공개" 1순위 신호 |
| 2. **`.gitignore`에 `ares/src/generated/*` 명시** | codegen 산출물 추적 제외 | 빌드 시 codegen 필요, codegen 결과는 비공개일 가능성 ↑ |
| 3. **공식 배포 URL 존재 (athenacrisis.com)** | 정적 사이트/앱 직접 호스팅 | "웹에서 플레이" 가능 = 소스 비공개일 가능성 ↑ (반드시 ✕는 아님) |
| 4. **`.timestamp-*` 패턴이 .gitignore에** | `ares/vite.config.ts.timestamp-*` | 빌드 시점 의존성 = codegen 후 생성 |
| 5. **Discord/Patron/유료 멤버십 흔적** | nkzw-tech KK (일본 회사) Discord | 비공개 본체 배포 경로 가능성 ↑ |

## 진단 워크플로 (1분)

```bash
# 1) 모노레포 워크스페이스 구조 확인
find . -maxdepth 3 -name "package.json" -not -path "./node_modules/*" | xargs -I {} dirname {} | head -20
# → 각 워크스페이스 디렉토리별 파일 수 확인

# 2) 빈 워크스페이스 찾기 (본체 없는 워크스페이스)
for ws in ares deimos dionysus apollo hera; do
  count=$(find "$ws" -name "*.ts" -o -name "*.tsx" 2>/dev/null | grep -v node_modules | wc -l)
  echo "$ws: $count .ts/.tsx files (excluding node_modules)"
done
# → 0~5개면 "스텁만" → 비공개 본체 위험

# 3) .gitignore 핵심 산출물 추적 제외
grep -E "\.generated|\.timestamp|src/generated|__generated__" .gitignore
# → 매치 많으면 codegen 의존성 ↑

# 4) 공식 배포 URL
grep -E "https?://[a-zA-Z0-9.-]+\.(com|app|gg|io|net|me)" README.md | head -5

# 5) LICENSE 파일 종류 (LICENSE vs LICENSE.md)
ls LICENSE* 2>&1
# → LICENSE.md는 종종 README에 흡수된 변형. .txt/.md 차이는 무관
```

## 판별 매트릭스

| 신호 조합 | 위험도 | 권장 |
|---|---|---|
| **빈 워크스페이스 1+** + codegen 추적 제외 + 공식 URL | 🔴 **매우 높음** | **fork 보류**, 다른 후보 |
| 빈 워크스페이스 1+ + codegen 추적 제외 + 공식 URL 없음 | 🟠 높음 | sparse-checkout 시도 후 결정 |
| 모든 워크스페이스 본체 존재 + codegen 추적 제외 | 🟡 중간 | codegen 단계까지 preflight |
| 모든 워크스페이스 본체 존재 + .gitignore 평범 | 🟢 낮음 | 일반 빌드 preflight |

## 빌드 dry-run 단계 (5분 preflight의 6단계, 추가)

`build-environment-preflight-check.md`의 1~5단계 후 **반드시 추가**:

```bash
# 6단계: 빌드 dry-run (5분)
cd /Users/mac/work/{project}-probe
# 가벼운 빌드 명령 (가장 적은 산출물)
pnpm build:offline 2>&1 | tail -20
# 또는
pnpm exec vite build 2>&1 | tail -20

# 판별
# ✅ "built in Xms" / "dist/.../index.html generated" → 빌드 가능
# ❌ "Cannot resolve entry module X" / "X not found in repository" → 비공개 본체
# ❌ "gyp ERR!" / "fatal error: too many errors" → C++ 의존성 함정 (별도 가이드)
```

**실측 (Athena Crisis)**: 6단계에서 즉시 `[UNRESOLVED_ENTRY] ares/vite.config.ts` → 4시간 절약 가능했음. 1~5단계만으로는 "i18n 모듈 분리 + ko_KR 지원 + Vite" 같은 표면 신호에 속아서 "🟢 즉시 성공"으로 판단.

## 다른 Open Core / 비공개 본체 후보 패턴

| 패턴 | 신호 |
|---|---|
| **Open Core (소스 부분 공개)** | 비어있는 워크스페이스 + codegen 산출물 추적 + 공식 URL |
| **데스크톱 앱만 공개** | `electron/`, `desktop/`, `mobile/` 등 빌드된 산출물만, 소스 없음 |
| **상용 SDK 래핑** | `vendor/`, `sdk/`, `lib/`, `lib64/` 등 비어있고 README에 "download from X" |
| **클라이언트/서버 분리 공개** | `client/`만 공개, `server/` 비공개 (또는 반대) |

## 본체 비공개 의심 시 graceful 대안

| 후보 상태 | 대안 |
|---|---|
| **완전 비공개 (Athean Crisis 케이스)** | 다른 fork 후보로 전환. server-survival(Three.js, MIT), Cave Story Rust 리메이크(Rust, MIT) |
| **부분 비공개 (빌드 가능, 일부는 미공개)** | 미공개 모드 표시하고 fork 진행. README에 "일부 기능 비활성화" 명시 |
| **빌드 가능 + 비공개 기능 옵션** | 모드 토글로 비공개 기능 on/off, 사용자가 옵트인 |

## 정리 워크플로 추가 (Open Core fork 종료 시)

`build-environment-preflight-check.md`의 "정리 워크플로" 외 추가로:

```bash
# 1) 의미 있는 자산 보존 (다음 fork에 재사용)
mv /Users/mac/work/{project}-kr/{src,scripts,translations,*.json} /tmp/{project}-assets/ 2>/dev/null
# 예: dionysus/AutoBattleAI.tsx + ko_KR_translations.json + scripts/generate_*.py

# 2) 로컬 디렉토리 삭제
rm -rf /Users/mac/work/{project}-kr

# 3) GitHub 저장소 삭제 (gh CLI scope 필요)
gh repo delete {owner}/{repo} --yes
# 403 시: 사용자 직접 https://github.com/{owner}/{repo}/settings

# 4) Vercel 정리
vercel projects ls 2>&1 | grep {project}
# → 있으면 vercel remove {project}
# → CLI 인증 없으면 https://vercel.com/dashboard
```

## 학습 기록

- **2026-07-27**: athena-crisis-kr 4시간 투자. 1,535개 한국어 번역 + AutoBattleAI 로직은 보존되었으나 정식 게임 빌드는 어떤 방법으로도 불가. **다음에는 빈 워크스페이스 + codegen 추적 + 공식 URL 3가지 동시 매치 시 무조건 보류**.

## 즉시 적용 규칙

1. **모든 GitHub 게임 fork 후보** = 5분 preflight 6단계 (1~5 + 빌드 dry-run) 필수
2. **빈 워크스페이스 1개+** = Open Core 의심 → sparse-checkout 또는 보류
3. **codegen 산출물 .gitignore 추적** = 비공개 codegen 의존 가능성 ↑
4. **공식 배포 URL** = "웹에서 플레이" + "소스 공개"는 별개 — 1순위 검증 대상
5. **Open Core 확정 시** = 보존 자산 (번역 데이터 + AI 로직) 정리 후 다른 후보로 전환
6. **사용자 "정리해줘"** = 4단계: 자산 보존 → 로컬 삭제 → GitHub 삭제 → Vercel 삭제. **gh `delete_repo` scope 없으면 사용자가 직접 1번 클릭**으로 안내
