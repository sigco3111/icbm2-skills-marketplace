# LLM max_tokens 기본값 함정 — OpenAI → NIM 마이그레이션 시 핵심 함정

> Stanford generative_agents (Apache 2.0) 의 `gpt_structure.py`를 NIM gpt-oss-120b로 교체할 때, self-test는 통과해도 시뮬 실행 시 100% TOKEN LIMIT으로 시뮬이 fail_safe 폴백 → 무한 루프하는 함정.

## 증상 (실측 — 2026-07-14 sigco3111 generative_agents-kr)

```bash
$ cd reverie/backend_server/persona/prompt_template
$ python3 gpt_structure.py
=== NIM gpt_structure self-test ===

[1] ChatGPT_single_request('ping 한 단어만')
    응답: ping
[2] 비대칭 임베딩 (passage vs query)
    차원: 2048
    '이서연 카페 커피' ↔ '이서연 음료' = 0.474
    재호출 안정성: 0.474
    부정 케이스 (가드 전): 0.457, (가드 후): 0.057

# self-test는 통과. 그러나 시뮬 실행:
$ ga-sim
Enter option: run 100
DEBUG
[['TOKEN LIMIT EXCEEDED', 1440]]    # ← 1440 토큰에서 응답 잘림
[0, 1]
index 0
index 1
?????
5분 단위로 하위 작업을 기술하세요. ...
TOODOOOOOO
TOKEN LIMIT EXCEEDED
-==- -==- -==-
TOODOOOOOO
TOKEN LIMIT EXCEEDED
-==- -==- -==-
```

모든 LLM 호출이 "TOKEN LIMIT EXCEEDED" 또는 1440 토큰에서 잘린 응답 → 시뮬은 `(default task)`로만 동작 → 무한 fail_safe 루프.

## 원인 (Stanford generative_agents 원본 `gpt_structure.py`)

```python
# 원본 OpenAI text-davinci-003 (구 Completion API) 호환 wrapper
def GPT_request(prompt, gpt_parameter):
    """원본 Completion.create() 호환. gpt-3.5-turbo로 우회."""
    temp_sleep()
    try:
        return _nim_chat(
            [{"role": "user", "content": prompt}],
            model=CHAT_MODEL,
            temperature=gpt_parameter.get("temperature", 0.7),
            max_tokens=gpt_parameter.get("max_tokens", 100),  # ← 기본값 100
        )
    except Exception:
        return "TOKEN LIMIT EXCEEDED"
```

호출 체인:
```
safe_generate_response(prompt, gpt_param, ...)
  → GPT_request(prompt, gpt_param)
    → _nim_chat(messages, max_tokens=gpt_param.get("max_tokens", 100))
```

`gpt_param` dict는 원본 OpenAI `safe_generate_response` 호출 시 정의된 dict. Stanford generative_agents의 `run_gpt_prompt.py`에서 `gpt_param = {"engine": "text-davinci-003", "max_tokens": 1000, "temperature": 0, "top_p": 1, "stream": False, ...}` 형태로 전달. 즉 **정상 케이스에서는 max_tokens=1000**이 들어감.

**그런데 NIM의 gpt-oss-120b는 reasoning 모델이라 같은 max_tokens=1000이라도 응답이 그 안에 안 들어감**:
- reasoning trace: 500-800 토큰
- 본문: 200-500 토큰
- 합계: 700-1300 토큰 → 1000 초과 → 잘림

`max_tokens=100` 기본값이 적용되는 경우(`gpt_param`이 불완전하게 전달되거나 다른 경로) — 100% 잘림.

## 왜 self-test는 통과했나

`ChatGPT_single_request('ping 한 단어만')`은 `_nim_chat`을 직접 호출 (gpt_parameter 안 거침). self-test는 short prompt → 100 토큰 안에 들어감 → 정상 응답. 그러나 `safe_generate_response` → `GPT_request` 체인은 `gpt_param` dict 거치며 max_tokens=1000 또는 100 적용. 시뮬의 실제 LLM 호출이 후자 경로이므로 self-test 통과 ≠ 시뮬 작동.

## 해결

### A. `GPT_request()` 기본값 100 → 1000 (최소 패치)

```python
def GPT_request(prompt, gpt_parameter):
    """NIM gpt-oss-120b 마이그레이션: max_tokens 기본값 100 → 1000으로 상향.
    (reasoning 모델이 응답 잘림 방지)
    """
    temp_sleep()
    try:
        return _nim_chat(
            [{"role": "user", "content": prompt}],
            model=CHAT_MODEL,
            temperature=gpt_parameter.get("temperature", 0.7),
            max_tokens=gpt_parameter.get("max_tokens", 1000),  # ← 100 → 1000
        )
    except Exception:
        return "TOKEN LIMIT EXCEEDED"
```

### B. 모든 `gpt_param` 정의 위치에서 max_tokens=1000 강제

원본 `run_gpt_prompt.py`의 모든 `gpt_param = {...}` 정의에서:
```python
gpt_param = {
    "engine": "text-davinci-003",
    "max_tokens": 1000,  # ← 100 → 1000
    "temperature": 0,
    "top_p": 1,
    "stream": False,
    "frequency_penalty": 0,
    "presence_penalty": 0,
    "stop": None
}
```

`grep "max_tokens" run_gpt_prompt.py`로 모든 정의 위치 찾아 일괄 변경.

### C. reasoning 모델용 별도 파라미터

```python
# reasoning 모델 (gpt-oss-120b, o1, deepseek-r1) 권장 설정
GPT_REASONING_PARAM = {
    "max_tokens": 4000,      # 4K 권장 (reasoning + 본문)
    "temperature": 0,        # reasoning 일관성
    "top_p": 1.0,
    "stream": False,
}

# 일반 모델 (llama-3.1, mistral) 권장 설정
GPT_REGULAR_PARAM = {
    "max_tokens": 1000,
    "temperature": 0.7,
    "top_p": 1.0,
    "stream": False,
}
```

## 검증 방법

### 1. self-test만으로 부족 (핵심)

`gpt_structure.py` self-test는 `_nim_chat` 직접 호출 → gpt_parameter 안 거침 → 정상 작동. 따라서 **self-test 통과 ≠ 시뮬 작동**. 반드시 실제 시뮬 step 1-2의 DEBUG 출력 확인.

### 2. 시뮬 DEBUG에서 TOKEN LIMIT 패턴 검출

```bash
# 시뮬 실행 후 DEBUG 로그 grep
grep -c "TOKEN LIMIT EXCEEDED" /tmp/reverie_debug.log
# 5회 이상 = max_tokens 문제 의심

# 또는 (default task) 폴백 사용 빈도
grep -c "(default task)" /tmp/reverie_debug.log
# 100% = 모든 step이 폴백 = max_tokens 문제
```

### 3. 직접 curl로 max_tokens 효과 검증

```bash
source ~/.hermes/secrets/nvidia_keys.env

# max_tokens=100 vs 1000 vs 4000 비교
for mt in 100 1000 4000; do
  echo "=== max_tokens=$mt ==="
  curl -s -X POST "https://integrate.api.nvidia.com/v1/chat/completions" \
    -H "Authorization: Bearer $NVIDIA_API_KEY_1" \
    -H "Content-Type: application/json" \
    -d "{\"model\": \"openai/gpt-oss-120b\", \"messages\": [{\"role\":\"user\",\"content\":\"5분 단위로 3개 작업 나열하세요.\"}], \"max_tokens\": $mt}" \
    2>&1 | python3 -c "import json,sys; d=json.load(sys.stdin); m=d['choices'][0]['message']; print('content:', (m.get('content') or '')[:100], '...'); print('reasoning:', (m.get('reasoning_content') or '')[:100], '...')"
  echo
done
```

**예상 결과**:
- `max_tokens=100`: reasoning만 나오고 content 빈 경우 있음
- `max_tokens=1000`: 본문 일부 잘림
- `max_tokens=4000`: reasoning + 본문 완전

### 4. `gpt_structure.py` self-test 확장 (권장)

```python
if __name__ == "__main__":
    print("=== NIM self-test ===\n")

    print("[1] LLM (단답)")
    print(f"    ChatGPT_single_request('ping'): {ChatGPT_single_request('ping').strip()}")
    # ↑ 기존 — 단답이라 통과

    print("[2] LLM (장문, gpt_parameter 경로)")
    # ↓ 신규 — gpt_param dict 거치는 경로 테스트
    gpt_param = {"temperature": 0, "max_tokens": 1000, "top_p": 1}
    long_result = safe_generate_response(
        "5분 단위로 작업 3개 나열하세요.",
        gpt_param,
        repeat=1,
    )
    print(f"    safe_generate_response: {long_result[:200]}")
    # ← 이게 빈 문자열/짧으면 max_tokens 문제

    print("[3] 비대칭 임베딩 ...")
```

## 다른 모델의 max_tokens 권장값

| 모델 | 권장 max_tokens | 비고 |
|------|----------------|------|
| `openai/gpt-oss-120b` | 4000 | reasoning trace 포함 |
| `openai/o1-preview` | 4000-8000 | reasoning trace 매우 김 |
| `openai/o1-mini` | 2000-4000 | mini지만 reasoning 포함 |
| `deepseek-ai/deepseek-r1` | 4000-8000 | reasoning 모델 |
| `meta/llama-3.1-70b-instruct` | 1000-2000 | 일반 모델 |
| `meta/llama-3.3-70b-instruct` | 1000-2000 | 일반 모델 |
| `mistralai/mistral-large-2` | 1000-2000 | 일반 모델 |
| `nvidia/nemotron-4-340b-instruct` | 1000-2000 | 일반 모델 |

## 다른 OSS 마이그레이션 시 체크리스트

| 항목 | 확인 |
|------|------|
| `GPT_request`/`Completion.create` max_tokens 기본값 | ⚠️ 100-200 → 1000+ |
| `safe_generate_response`/`generate_with_retry` max_tokens | ⚠️ 원본 1000+ 확인 |
| `chat.completions.create` max_tokens | ⚠️ reasoning 모델은 4000+ |
| 모든 NIM 호출에 max_tokens 명시 | ⚠️ 명시 없으면 NIM 기본값(작음) |

## push 전 검증

```bash
# 1. self-test 확장 (위 4번)
cd reverie/backend_server/persona/prompt_template
python3 gpt_structure.py

# 2. 시뮬 step 1-2 DEBUG에서 TOKEN LIMIT 안 나오는지
ga-sim
Enter the name of the forked simulation: base_the_ville_isabella_maria_klaus
Enter the name of the new simulation: ICBM_kr_test
Enter option: run 100
# → DEBUG에 "TOKEN LIMIT EXCEEDED" / "(default task)" 다수 = fix 미적용
# → DEBUG에 실제 task 분해 (1) ~ 9)) 출력 = fix 적용 완료
```

## 관련 함정

- `references/nim-llm-backend-swap.md` §5 reasoning 모델 `content=None` 함정 (같은 reasoning 모델의 두 번째 함정)
- `references/nim-api-key-500-pitfall.md` 500 에러 진단 (max_tokens 문제와 다른 원인)
