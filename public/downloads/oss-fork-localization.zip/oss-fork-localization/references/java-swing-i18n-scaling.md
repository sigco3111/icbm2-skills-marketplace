# Java Swing i18n 확장 — 잠재량 vs 실측 가능량 + 검증된 위임 패턴

> TripleA Phase 2 (2026-07-28) 사례. **Locale.lookup 함정을 넘어선 실전 한국어화 확장** 워크플로우 — 잠재 string 카운트(공식 문서) ≠ 실제 i18n 가능 string (실측).

## 핵심 교훈: 잠재량 vs 실측 가능량

공식 문서 `docs/development/i18n_languages.md`가 "TripleA = **12,628 strings**" 라고 명시. **하지만 12,628은 잠재 string 수** (전체 Java String literals + properties + 포맷팅 후보)이지, 실제 properties로 추출 가능한 양이 아님. 실측:

| 구분 | 갯수 | i18n 가능? |
|---|---|---|
| 잠재 string (공식 문서) | 12,628 | 직접 properties화 안 됨 — String literals라 코드 리팩터링 필요 |
| **현재 properties 키** | 59 (1차) | ✅ 이미 properties 있음 |
| **신규 properties 후보** (실측) | **121** | ✅ Swing 위젯 literal → `getText(...)` 치환으로 추가 가능 |
| 공식 5% 목표 (650 strings) | — | Phase 2+3 = 약 4배 |

**판별 명령**:
```bash
# 현재 properties 키 수
find game-app -name "*.properties" -path "*/i18n/*" | xargs grep -h '^[a-z]' | wc -l

# 신규 후보 Swing literal (예: JMenuBuilder, JOptionPane msg/title)
grep -rE 'new JMenu[A-Za-z]*Builder\("|JOptionPane\.show' --include="*.java" game-app | wc -l

# getText() 이미 쓰는 곳
grep -rE 'I18nEngineFramework\.get\(\)\.getText\(' --include="*.java" game-app | wc -l
```

**결론**: 한국어 확장 PR 가치를 평가할 때 **공식 잠재량과 실측 가능량을 분리**. 잠재량만 보고 "PR이 너무 큼"으로 판단하면 안 됨.

## 검증된 Swing i18n 적용 패턴 (FileMenu 사례)

### Step 1: import 추가
```java
import games.strategy.engine.framework.I18nEngineFramework;
```

### Step 2: Swing 위젯 literal → `getText(...)` 치환
```java
// JMenuBuilder
new JMenuBuilder("File", mnemonic.FILE)
→ new JMenuBuilder(I18nEngineFramework.get().getText("menubar.FileMenu.File"), mnemonic.FILE)

// JMenuItemBuilder
new JMenuItemBuilder("Save", mnemonic.SAVE)
→ new JMenuItemBuilder(I18nEngineFramework.get().getText("menubar.FileMenu.Save"), mnemonic.SAVE)

// JOptionPane showMessageDialog (msg + title 2개 키)
JOptionPane.showMessageDialog(frame, "Game Saved", "Game Saved", JOptionPane.INFORMATION_MESSAGE)
→ JOptionPane.showMessageDialog(frame,
    I18nEngineFramework.get().getText("menubar.FileMenu.GameSavedMsg"),
    I18nEngineFramework.get().getText("menubar.FileMenu.GameSavedTitle"),
    JOptionPane.INFORMATION_MESSAGE)

// lambda 안에서 변수
() -> {
  final String title = I18nEngineFramework.get().getText("menubar.FileMenu.ManualGamesavePost");
  ...
}
```

### Step 3: properties 키 명명 규칙
- **패턴**: `<파일명 PascalCase>.<위젯명>.<속성>` — 예: `menubar.FileMenu.Save`
- **msg/title 분리**: 동일 string이라도 `Msg` / `Title` 접미사로 별도 키 2개 — 한국어 msg는 동사형, title은 명사형이 자연스러움
- **영역 prefix**: `menubar.`, `lobby.`, `panel.` 등 다음 영역과 충돌 방지

### Step 4: 3개 언어 properties 동시 추가 (필수)

**한 언어만 추가하면 `I18nResourceBundleTest`가 깨짐**:
- EN: 원본 literal 그대로
- DE: 기존 ui_de.properties 톤 따라 번역
- KO: ASCII-escape 한글 (예: `\uc2dc\uc791` = "시작")

```properties
# ui.properties (영문)
menubar.FileMenu.File=File
menubar.FileMenu.Save=Save

# ui_de.properties (독일어)
menubar.FileMenu.File=Datei
menubar.FileMenu.Save=Speichern

# ui_ko.properties (한국어, ASCII escape)
menubar.FileMenu.File=\ud30c\uc77c
menubar.FileMenu.Save=\uc800\uc7a5
```

### Step 5: 검증

#### 빌드
```bash
./gradlew :game-headed:compileJava --console=plain
# → BUILD SUCCESSFUL
```

#### i18n 자동 테스트 (가장 중요)
```bash
./gradlew :game-core:test --tests "games.strategy.engine.framework.I18nResourceBundleTest" --console=plain
# → BUILD SUCCESSFUL
```

이 테스트가 자동으로:
- 모든 key가 EN/DE/KO 모두에 있는지 확인 (`MissingResourceException`이면 실패)
- 10자 이상 string이 EN과 동일 값이면 "번역 안 됨"으로 실패 (`!enString.equals(langString)`)

#### ResourceBundle 로딩 직접 검증 (테스트 통과 ≠ 런타임 정상)

**중요**: 위 테스트가 통과해도 `getText(...)` 런타임 호출이 키를 못 찾으면 fallback이 동작해서 빌드는 됨. **반드시 직접 probe**:

```bash
cat > /tmp/CheckI18n.java <<'EOF'
import java.util.Locale;
import java.util.ResourceBundle;
public class CheckI18n {
  public static void main(String[] a) {
    String base = "i18n.games.strategy.engine.framework.ui";
    String[] keys = { /* 신규 키들 */ };
    for (String k : keys) {
      for (Locale l : new Locale[]{Locale.US, Locale.KOREA, Locale.GERMANY}) {
        ResourceBundle b = ResourceBundle.getBundle(base, l);
        try { System.out.println(k + " " + l + " = " + b.getString(k)); }
        catch (Exception e) { System.out.println(k + " " + l + " = MISSING"); }
      }
    }
  }
}
EOF
javac -d /tmp /tmp/CheckI18n.java
java -cp /tmp:/path/to/game-core.jar CheckI18n
```

TripleA FileMenu 실측 결과:
```
menubar.FileMenu.File           EN=File  KO=파일  DE=Datei
menubar.FileMenu.Save           EN=Save  KO=저장  DE=Speichern
menubar.FileMenu.GameSavedMsg   EN=Game Saved  KO=게임이 저장되었습니다  DE=Spiel gespeichert
```

## Lombok `@UtilityClass` 제약

`@UtilityClass` Lombok 애노테이션이 붙은 클래스는 **모든 필드가 static + 인스턴스 필드 추가 불가**. 즉 `private final I18nResourceBundle bundle = I18nEngineFramework.get();` 같은 인스턴스 필드 못 만듦.

**해결 2가지**:
1. **직접 호출 (단순)**: `I18nEngineFramework.get().getText(...)` 매번 호출
2. **지역 변수 (lambda/inner class용)**: `final String title = I18nEngineFramework.get().getText("...");`

TripleA 메뉴바는 `@UtilityClass`라 직접 호출 패턴 일관 적용.

## ASCII-escape 한글 properties 일관성

**기존 `ui_ko.properties`가 이미 ASCII-escape 형태** (`\uc2dc\uc791` = "시작"). 신규 키도 같은 형식으로 추가해야 일관성. UTF-8 직접 입력 시 일부 빌드 환경/IDE에서 깨질 수 있음.

**생성 도구 (macOS)**:
```bash
python3 -c "
import sys
text = sys.argv[1]
print(''.join(f'\\\\u{ord(c):04x}' if ord(c) > 127 else c for c in text))
" "게임 나가기"
# \uac8c\uc784 \ub098\uac00\uae30
```

**검증**:
```bash
python3 -c "print(bytes('\\uac8c\\uc784', 'utf-8').decode('unicode_escape'))"
# 게임
```

## 1파일 검증 → N파일 일괄 위임 패턴

한 파일을 **사람 손으로 직접 검증**해서 proven template을 만들고 → 그 template를 N개 파일에 일괄 위임.

### 1단계: 사람 손으로 1파일 처리
- FileMenu 직접 수정 + properties 3개 언어 추가 + 빌드 + 테스트 + ResourceBundle probe
- 이 한 사이클로 패턴이 **실측 검증**

### 2단계: 워커에게 N파일 일괄 위임
워커 표준 프롬프트 (메모리 패턴):
- `fabricate 금지` (실제 read/grep 결과만)
- `솔직히 보고` (막히면 시간순 시도 + 대안 3개)
- `실제 실행 결과만 보고`
- `최대 N회 retry`
- `실패 시 다음 시도 방향 명시`
- `"OK 예감" 자신감 표현 금지`

위임 프롬프트에 반드시 포함:
1. **proven template 명시** (위 Step 1~5 코드 패턴 그대로)
2. **properties 키 명명 규칙** + 3개 언어 동시 추가 강제
3. **각 파일 처리 후 `./gradlew :game-headed:compileJava` 실행** — 실패 시 다음 파일 진행 안 함
4. **모든 파일 완료 후 i18n test 통과 확인**
5. **결과 형식**: `SUMMARY: <처리 파일>/<전체>/<BUILD SUCCESSFUL|BUILD FAILED>`
6. **커밋은 사람 손으로** — 워커가 검증 + 커밋하면 품질 편차 위험

### 3단계: 사람 손으로 시각 검증
- 게임 실행 (`java -jar game-headed-*.jar`)
- 시스템 locale ko_KR 설정 후 메뉴바 한국어 표시 확인
- macOS: `defaults write -g AppleLocale ko_KR`

## 영역별 우선순위 (TripleA 실측)

워커 위임 전 측정으로 우선순위 결정 (이전 세션의 `_survey_measure.py` 패턴):

| 영역 | 파일 | 신규 후보 | 추천 |
|---|---|---|---|
| **A. 메뉴바** | 8 | 61 | 1순위 — 빌더 패턴 3종 통일, 파일당 7.6개 집중 |
| **B. 로비 클라이언트** | 20 | 8 | 3순위 — 파일당 0.4개 분산, 임팩트 작음 |
| **C. 인게임 패널** | 32 | 51 (menubar 제외) | 2순위 — 다이얼로그 30건이 가장 큰 묶음 |
| **D. 시작 화면** | 11 | 1 (공백) | skip — 이미 1차에서 처리됨 |

**함정: 영역 중첩** — `triplea/ui/menubar/`는 `triplea/ui/`의 하위. A와 C 후보 string 셋이 겹침. 카운트 시 한쪽만 처리하거나 분리 표시.

## 공식 i18n 5% 목표 vs 실질 100%

`docs/development/i18n_languages.md`가 명시한 목표:
- "5% (around 650 strings). The rest is either having only functional purpose or can be translated later."
- "We are going to target to have every user-display string translated? **Yes, that would be the final goal.** However, in a first step the extraction would be a good start."

**PR 가치 판단**:
- 1차 (메뉴바 + 시작화면 ~120 keys): upstream PR 가치 큼 — 작은 변경 + 가시성
- 2차 (인게임 패널 ~50 + 다이얼로그 ~30): 가성비 좋음
- 3차 (코드 리팩터링으로 string literal 추출 ~1000+): PR 너무 큼, 위험 — 별도 fork-only 작업

## 커밋/PR 사이즈 전략

TripleA fork에서 검증된 패턴:
- **커밋 단위 = 1개 영역 (예: "i18n: extend Korean UI bundle to FileMenu")**
- **PR 단위 = 2~3개 영역 묶음** (메뉴바 전체 = 1 PR, 인게임 패널 = 1 PR)
- **각 커밋에 검증 결과 명시**: 빌드 SUCCESSFUL + i18n test SUCCESSFUL + ResourceBundle probe 출력

## 검증 체크리스트 (Java Swing i18n)

- [ ] 잠재 string vs 실측 가능량 분리 (`grep` 명령으로 측정)
- [ ] 1개 파일 proven template (사람 손으로 빌드+테스트+probe 통과)
- [ ] N파일 일괄 위임 시 각 파일 빌드 + 최종 i18n test
- [ ] 3개 언어 properties 동시 추가 (한 언어만 추가 시 test 깨짐)
- [ ] ResourceBundle probe로 런타임 로딩 직접 확인
- [ ] 게임 실행 + 시스템 locale ko_KR로 시각 검증
- [ ] 커밋 메시지에 빌드/test 결과 명시

## TripleA D2 실측 — 잠재량 vs 실측 가능량 (2026-07-28 D2 완료) ★

1차(FileMenu) + 2차 D2(메뉴바 7파일) 완료 후 실측:

| 영역 | 파일 | 1차 후 | D2 추가 | **D2 후 실측** | 워커 추정 vs 실측 |
|---|---|---|---|---|---|
| 시작화면 | MainPanel 외 | 59 keys | 0 | 59 keys | 59 ✓ |
| **메뉴바 (전체)** | 8 | 8 | **84** | **92** | 워커 보고 61 → 실측 92 (LobbyMenu 11 + GameMenu/ViewMenu에서 추가 발견) |
| 로비 클라이언트 | 20 | 0 | 0 | 0 | 8 |
| 인게임 패널 | 32 | 0 | 0 | 0 | 51 |

**교훈**: 워커가 보고한 신규 string 수는 **약 30% 과소 추정**. 이유는 (1) Worker가 JMenuItemCheckBoxBuilder 패턴을 일부 누락 (2) JOptionPane msg+title 분리 키를 한 키로 계산 (3) JLabel/JButton 등 다양한 패턴 일부 미측정. **사람 손으로 1개 파일 proven 후 추가 발견이 다수**.

**D2 실측 검증 결과** (92 menubar keys × 3개 언어):
- 빌드 SUCCESSFUL
- I18nResourceBundleTest SUCCESSFUL
- ResourceBundle smoke probe (Java probe로 92 keys × 3 locales 직접 로딩): **0 missing, 0 untranslated** (각 키가 EN/DE/KO 모두 존재, 10자 이상 키가 EN과 다른 값)
- 누적 한국어: **159 keys** (1차 59 + A1 8 + D2 92)

## Worker 5단계 verification gauntlet (필수) ★

TripleA D2에서 워커가 BUILD SUCCESSFUL 보고했으나 silent 회귀 다수 발생. 사람 손으로 **5단계 게이트** 필수:

```bash
# 1. Diff audit — silent 추가/삭제 라인 (P6/P7)
git diff <each_modified_file.java>

# 2. UTF-8 깨진 문자 (P3)
python3 -c "
for f in [...3 properties...]:
    with open(f,'rb') as fh:
        for i,line in enumerate(fh.readlines(),1):
            try: line.decode('utf-8')
            except: print(f'{f}:L{i}: {line[:80]!r}')
"

# 3. Properties dedup (P8)
python3 -c "
seen=set(); out=[]
for line in open(f):
    if not line.strip(): out.append(line); continue
    key=line.split('=',1)[0] if '=' in line else line
    if key in seen: continue
    seen.add(key); out.append(line)
open(f,'w').write('\n'.join(out)+'\n')
"

# 4. Java↔Properties 키 매칭 (P9)
grep -rE 'getText\("' game-app --include="*.java" | sed 's/.*getText("//; s/").*//' | sort -u > /tmp/used_keys.txt
grep -E '^[a-z]+\.' game-app/game-core/src/main/resources/.../ui.properties | cut -d= -f1 | sort -u > /tmp/defined_keys.txt
diff /tmp/used_keys.txt /tmp/defined_keys.txt

# 5. Build + i18n test
./gradlew :game-headed:compileJava :game-core:test --tests I18nResourceBundleTest

# 6. ResourceBundle smoke probe (Step 5의 Java probe)
java -cp /tmp:game-core.jar CheckI18n
```

## 워커 손상 사례 (D2 실측, 회피 패턴) ★

**사례 1 — Worker가 무단 라인 추가 (P6)**:
- `ViewMenu.getZoomMenu()`의 `fitHeight` action listener에 `ratio = Math.min(1, ratio);` 클램프가 추가됨
- 원인: Worker가 손상된 patch를 복구하면서 `fitWidth` 본문을 `fitHeight`에 잘못 복사
- 빌드/테스트 모두 통과 (코드 변경이지만 동작 변경은 테스트 안 함)
- 사람 손으로 diff 보고 발견, 라인 제거로 복구

**사례 2 — Properties 키 중복 (P8)**:
- Worker가 일부 GameMenu/NetworkMenu 키를 미리 추가, 사람이 patch로 전체 키 추가
- 결과: 23개 GameMenu 키가 2번씩 등장
- 빌드는 통과 (Java Properties last-wins), smoke test도 통과 (마지막 값 사용)
- 사람 손으로 dedup 스크립트 실행, 146줄 × 3 파일로 일치시킴

**사례 3 — Java/Properties 키 불일치 (P9)**:
- Worker가 Java에 `menubar.GameMenu.RollsNoEffectOnGame` 추가, 사람이 properties에 `RollsNoEffectLabel` 추가
- 빌드는 통과 (둘 다 존재)
- 사람 손으로 grep 비교로 발견, Java 키명에 맞춰 properties 정정

**교훈**: 워커는 **빌드 + 기본 i18n test는 통과시키지만 silent 회귀는 못 잡음**. 사람 손으로 5단계 게이트 필수.

## 다음 세션 작업 (TripleA 한국어 100% 확장)

| 영역 | 파일 수 | 신규 string | 추천 시작 |
|---|---|---|---|
| B. 로비 클라이언트 UI | 20 | ~8 | 다음 세션 1차 — 소규모라 직접 처리 가능 |
| C. 인게임 패널 | 32 | ~60 | 다음 세션 2차 — 워커 위임 가능 |
| D. 다이얼로그 (C에 포함) | — | ~30 | C와 함께 |

**다음 세션 시작 명령**:
```bash
cd /Users/mac/work/triplea-kr
git log --oneline -5  # 9f30d3b e618b6e 7a3cc70 (1차+A1+D2) 확인
./gradlew :game-headed:compileJava  # sanity build
```
그 다음 B 영역 LobbyFrame 등 8 string 직접 처리 → C 영역 60 string 워커 위임.

## 동시 다중 워커 / properties 충돌 함정 (D4-B 2026-07-28 실측) ★★★

**증상**: 같은 properties 파일 (`ui.properties`)을 두 명 이상의 워커/에이전트가 동시에 patch 도구로 수정할 때, 한 쪽의 patch가 다른 쪽이 읽은 텍스트 위에 적용되어 **조용히 키 이름이 변형**되거나 라인이 누락됨. 빌드는 통과해서 며칠 뒤에야 발견되는 silent corruption.

**실측 사례** (D4-B EditPanel 1차 처리):
- 본 워커가 `patch` 도구로 `menubar.ViewMenu.ShowZoomPercentage`를 anchor로 `ingame.EditPanel.*` 26개 키를 추가하려고 시도
- **그 사이 sibling agent `20260728_090931_a5fc64`**가 같은 파일에 patch로 `menubar.ViewMenu.ShowZoomPercentages` 라인을 별도 위치에 삽입 (anchor 끝에 s 한 글자 추가된 동일 라인)
- 본 워커 patch의 `old_string`이 unique 매칭에 성공해 적용됐지만, sibling이 추후 다시 patch하면 본 워커가 추가한 ingame.* 키가 들어있는 라인을 old_string으로 잘못 인식 가능 → **silent 키 변형** (`ShowZoomPercentage` → `ShowZoomPercentages`)
- patch 도구 warning에 `"modified by sibling subagent '...'"` 메시지 노출됨 — 묵묵히 진행하면 위험

**회피 패턴 (다음 워커플로 필수)**:
1. **properties 파일은 단일 에이전트만 손댄다** — 부모(orchestrator)가 명시적으로 "이 파일은 본 워커의 사적 영역"을 선언하거나, **별도 임시 properties 파일**을 만들어 한 워커당 1개 파일로 격리 → 마지막 단계에서 단일 에이전트가 머지
2. **각 patch 호출 직후 즉시 read_file로 파일을 다시 읽어** anchor 라인이 의도대로 존재하는지 확인 (`grep -c "<expected_anchor>" <file>` ≥ 1)
3. **patch 도구 warning에 "modified by sibling" / "but this agent never read it" 메시지가 뜨면 즉시 작업 중단 + 부모에게 보고** — 절대 묵묵히 진행 금지
4. **커밋 직전 사용자 눈으로 `git diff <properties_file>` 첫 50줄 + 마지막 50줄을 확인** — 키 이름 오타 한 글자가 silent하게 들어가는 게 가장 흔한 손상 모드
5. **키 중복은 자동 dedup 스크립트 (Worker 5단계 verification gauntlet #3 참고) 가 잡지만, 키 이름 오타는 못 잡음** — 사람 눈 diff audit가 최종 방어선

## 공개 상수 보존 원칙 (D4-B EditPanel 실측)

`EditPanel.ACTION_LABEL_COULD_NOT_PERFORM_EDIT` 같은 `public static final String` 상수가 외부 코드가 직접 참조하지 않더라도, **호출 지점마다 `getText("ingame.EditPanel.FooTitle")`로 직접 치환하고 상수 자체는 보존**한다.

- 이유: 상수 자체를 `getText()` 호출 결과로 바꾸면 상수의 컴파일타임-상수 보장이 깨지면서 외부 `switch case`/어노테이션 사용처가 깨질 수 있음
- D4-B 실측: TripleA EditPanel의 4개 `ACTION_LABEL_*` 상수 모두 EditPanel 내부에서만 사용 → 사실상 dead code였지만, **principle of least surprise**로 보존
- 판별: `grep -rn "<상수명>" --include="*.java" game-app` 결과에 EditPanel 외 호출이 하나라도 있으면 무조건 보존. 0개여도 보존 추천.

## `static final String` + `getText()` 이니셜라이저 함정 (2026-07-28, PurchasePanel/RepairPanel) ★★★

`private static final String BUY = I18nEngineFramework.get().getText("...");` 패턴은 **빌드 에러** `cannot find symbol variable I18nEngineFramework`.

**원인 2가지**:

1. **import 누락**: 다른 패키지에서 `I18nResourceBundle`을 import 했다고 자동으로 따라오지 않음. PurchasePanel.java가 이 함정에 빠졌음. 해결: `import games.strategy.engine.framework.I18nEngineFramework;` 명시.
2. **static initializer 순서**: 클래스가 처음 로딩될 때 static 필드가 평가되는데, `I18nResourceBundle`이 아직 로드 안 됐을 가능성. `Lombok @UtilityClass`는 모든 필드가 static이라 인스턴스 lazy init 불가능. 일반 클래스도 `public static final String`이 외부에서 참조되는 경우 lazy로 못 바꿈.

**해결 패턴**:
```java
// AS-IS (빌드 실패)
private static final String BUY = I18nEngineFramework.get().getText("ingame.PurchasePanel.Buy");

// TO-BE (인스턴스 lazy)
private String buyLabel;
private String changeLabel;

// 생성자에서 초기화 (인스턴스 생성 시점에 호출됨 = main 시작 후)
public PurchasePanel(final GameData data, final MapPanel map) {
  super(data, map);
  buyLabel = I18nEngineFramework.get().getText("ingame.PurchasePanel.Buy");
  changeLabel = I18nEngineFramework.get().getText("ingame.PurchasePanel.Change");
  buyButton = new JButton(buyLabel);
  ...
}
```

**판별**: `grep -nE 'private static final String .*I18nEngineFramework' game-app`로 사전 점검. 발견되면 즉시 인스턴스 필드로 변경 결정.

## heredoc `\n` → 빈 라인 함정 (2026-07-28, D4-B) ★

`cat >> file.properties <<'EOF'`로 properties를 일괄 추가할 때 `ingame.X.MsgPrefix=\n` 같이 줄 시작 부분이 `\n`으로 끝나면 다음 라인이 새 라인으로 인식되어 **값이 비어있는 키가 들어감**.

**실측 사례 (BattlePanel 한국어)**:
```bash
# heredoc 내용
ingame.BattlePanel.AttackSubmarinesMsgPrefix=
ingame.BattlePanel.AttackSubmarinesMsgSuffix=(의)에서 잠재함을 공격하시겠습니까?
```
→ `AttackSubmarinesMsgPrefix=` (값 빈), `AttackSubmarinesMsgSuffix=(의)에서...` 라인이 별도 키로 잘못 등록됨.

**증상**: 한국어 properties만 깨짐 (`i18n error: Key 'ingame.BattlePanel.AttackUnitsMsgPrefix' not translated into language 'ko_KR'`), EN/DE는 빈 값 통과.

**회피**:
1. heredoc 안에서 `=` 뒤에 빈 값 만들지 말 것. 필요 시 한국어/독일어 모두 같은 prefix/suffix 키로 분리해서 값 채우기.
2. 또는 `python3`로 직접 작성 + 후속 처리:
   ```python
   content = content.replace('=\n', '=값\n')  # 빈 값을 명시적으로 채움
   ```

## 워커 도구 호출 한도 패턴 (2026-07-28) ★

단일 워커에게 12파일 ~50 string 위임 시 **tool calling 50회 한도**로 **2-3개 파일만 처리 후 중단**하는 패턴 반복 (3개 워커 모두 동일).

**실측 사례**:
- B 워커 (12파일 ~50 string, 5대 안전장치 포함): `api_calls=50, duration=329s`, 12파일 중 **2파일 (EditPanel, TechPanel) + 일부 작업 후 중단**
- A 워커 (TripleAFrame 1파일 50 string): `api_calls=50, duration=354s`, 50개 string 중 45개 처리 후 properties 누락

**워크플로 결정**:
- **3개 이상 파일 + 30+ string은 단일 워커 1명에게 맡기지 말 것**
- 대신:
  - 워커 1명당 3-5파일 (~20-30 string) 한정
  - 워커 종료 후 부모(나)가 직접 나머지 처리 (이게 가장 효율적이었음 — 검증 시간 단축)
  - 분할 dispatch는 2-3명까지 가능하지만 **properties 동시 수정 충돌** 위험 큼 → 단일 에이전트가 파일별 부분 작업 → 마지막 머지 패턴

## 워커 patch 사고 4종 (D2/D4-B 실측) ★★★

워커가 만드는 patch 사고 패턴 4가지 — **빌드/테스트 모두 통과할 수 있어 silent**:

1. **삭제 사고 (MovePanel ScrambleWarning)**: 원본 `final JPanel panel = new JPanelBuilder()...`를 patch new_string이 `new JPanelBuilder()...`로 시작하면 **`final JPanel panel = ` 라인이 통째로 사라짐**. 컴파일 에러 `cannot find symbol variable panel`. 
   - **회피**: patch old_string에 `final JPanel panel = ` 라인 정확히 포함, new_string도 동일하게 시작

2. **추가 사고 (MovePanel ScrambleWarning)**: 원본에 없는 `chooser.setTitle(message);` 라인을 patch가 추가했는데 **`chooser` 변수가 그 scope에 정의 안 됨**. 컴파일 에러 `cannot find symbol variable chooser`.
   - **회피**: patch new_string에 원본에 없는 라인 추가 금지. 의심 시 라인 삭제 후 빌드 → 빌드 OK면 원본 의도 보존

3. **이름 변경 사고 (PlayerBansTab getter)**: 워커가 `ban.getEpochMillEndDate()`를 `ban.getEpochMilliEndDate()`로 "고치려는" 시도 → **Lombok이 만든 메서드 이름 오타**로 빌드 실패. 워커는 "오타처럼 보여서 고쳤다"고 보고. 
   - **회피**: new_string에 메서드 호출은 원본과 **완전히 동일하게**. Lombok getter는 `getEpochMillEndDate`처럼 짧거나 `getEpochMilliEndDate`처럼 길거나 — 원본 그대로 보존

4. **무단 추가 사고 (ViewMenu fitHeight)**: `fitWidth`에서 클램프 `ratio = Math.min(1, ratio);` 라인을 `fitHeight`에도 추가 — **빌드/테스트 통과하지만 동작 변경** (fitHeight zoom이 1로 클램핑됨). 원본 의도와 다름. 
   - **회피**: patch 후 `git diff` 직접 확인 + 라인 수가 늘었으면 의심. 새 라인은 의심 없이 추가 안 함

**공통**: 모든 사고가 **`patch` 도구 사용 시 발생**. `patch` 도구 사용 후에는 항상 빌드 + `git diff` 직접 확인 필수.

## DE == EN test failure 회피 패턴 (2026-07-28, LobbyFrame.Title 사례) ★

`I18nResourceBundleTest`는 **10자 이상** string 중 EN과 동일 값이면 "번역 안 됨"으로 실패. 브랜드명처럼 EN 그대로 둬야 하는 string도 게이트 통과 못함.

**회피 2가지**:

1. **미세 변형**: `TripleA Lobby` → `TripleA-Lobby` (하이픈 추가). 브랜드명 인식성은 유지하면서 테스트 통과.
2. **국제 표준 단어 키 분리**: `"OK"`, `"Cancel"` 같은 표준 단어에도 키 추가해서 한국어/독일어로 다르게 번역.

**검증 헬퍼**:
```bash
python3 -c "
en = {}
with open('game-app/.../ui.properties') as f:
    for line in f:
        if '=' in line and line.startswith('lobby.'):
            k,v = line.split('=',1)
            en[k.strip()] = v.strip()
de = {}
with open('game-app/.../ui_de.properties') as f:
    for line in f:
        if '=' in line and line.startswith('lobby.'):
            k,v = line.split('=',1)
            de[k.strip()] = v.strip()
for k in en:
    if k in de and en[k] == de[k] and len(en[k]) > 10:
        print(f'en == de ({len(en[k])} chars): {k} = {en[k]!r}')
"
```

## 관련 레퍼런스

- `java-resourcebundle-locale-lookup-pitfall.md` — Phase 1 (Locale.lookup 함정 + 4단계 등록) — 본 문서는 Phase 2+ (확장)
- `cross-fork-pr-pitfalls.md` — PR 제출 시 gh CLI 우회
- `oss-fork-localization` SKILL.md — 전체 umbrella, pre-flight 5축
