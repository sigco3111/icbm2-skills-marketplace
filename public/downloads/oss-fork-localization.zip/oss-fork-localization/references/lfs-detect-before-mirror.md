# README에서 LFS 상태 빠르게 감지 (mirror 푸시 전 체크)

원본 mirror 또는 fork 작업 전, GitHub README/리소스에서 LFS 추적 여부를 빠르게
판단하는 30초 체크리스트. LFS 추적 + fetch 불가 환경에서는 `references/lfs-mirror-bypass.md`
4단계 우회 절차로 진입.

## 1단계 — .gitattributes 존재 여부 (5초)

```bash
curl -sL "https://raw.githubusercontent.com/OWNER/REPO/$(gh repo view OWNER/REPO --json defaultBranchRef -q .defaultBranchRef.name)/.gitattributes" 2>/dev/null \
  | head -30
```

**해석**:
- `*.png filter=lfs diff=lfs merge=lfs` 같은 라인 → **LFS 추적** (이 skill 적용)
- 부재 → 일반 mirror, `gh repo create` + `git push` 충분

## 2단계 — 실제 파일 vs LFS pointer (10초)

```bash
# 첫 PNG/SVG/MP4 한 개 검사
curl -sL "https://raw.githubusercontent.com/OWNER/REPO/main/path/to/asset.png" -o /tmp/probe.png
file /tmp/probe.png
```

**해석**:
- `PNG image data` → 실제 파일, LFS fetch 성공
- `ASCII text` + 내용에 `version https://git-lfs.github.com/spec/v1` → **LFS pointer, fetch 실패**
- `HTML document` → 404 또는 잘못된 경로

## 3단계 — LFS object fetch 가능성 (10초)

```bash
which git-lfs 2>&1
gh api repos/OWNER/REPO/lfs 2>&1 | head -5  # LFS endpoint 활성?
```

**해석**:
- `git-lfs` 없음 + LFS 추적 → `brew install git-lfs` 후 fetch 시도
- `git-lfs` 있음 + LFS server 응답 → fetch 후 push
- `git-lfs` 있음 + LFS server 미응답 → bypass 4단계로 진입

## 4단계 — quota 위험 평가 (5초)

큰 저장소 (1GB+)는 LFS push 시 quota 초과 가능. 이 경우 **bypass 4단계**가 정답.

## Quick Decision Tree

```
LFS 추적? ──NO──→ 일반 fork+localize (oss-fork-localization 메인)
  │
 YES
  │
git-lfs 있음? ──NO──→ brew install git-lfs
  │                          │
 YES                        YES
  │                          │
LFS server OK? ──NO──→ bypass 4단계
  │
 YES
  │
저장소 <1GB? ──NO──→ quota 위험 → bypass 4단계
  │
 YES
  │
git lfs fetch + 정상 push
```

## 실측 예시 (proofofplay/piratenation-art)

```
$ curl -sL ".../piratenation-art/main/.gitattributes" | head -5
*.png filter=lfs diff=lfs merge=lfs -text
*.svg filter=lfs diff=lfs merge=lfs -text
*.gif filter=lfs diff=lfs merge=lfs -text
... → LFS 추적 확인

$ which git-lfs
git: 'lfs' is not a git command → git-lfs 미설치

→ brew install git-lfs → git lfs fetch --all → 692MB 1시간+ 소요
→ quota 위험
→ bypass 4단계로 2분 안에 mirror
```

## bypass로 갈 때

→ `references/lfs-mirror-bypass.md` 의 4단계 절차 따르기.
