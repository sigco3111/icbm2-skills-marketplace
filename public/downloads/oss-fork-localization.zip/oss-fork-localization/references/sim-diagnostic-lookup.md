# 시뮬레이션 실행 시 즉석 진단 + 패치 룩업 (Sim Runtime Diagnostic Lookup)

> Stanford generative_agents 같은 시뮬레이션 OSS를 처음 띄울 때 **이 에러 → 이 fix** 한 번에 매핑. `oss-fork-localization` Stage 5 (E2E) 진행 중 발생하는 모든 silent fail과 crash 패턴을 한 곳에 정리.

## 사용 시점

- `reverie.py` 실행 → 에러 메시지 받음 → 어디서 어떻게 고치지 모를 때
- LLM 호출 후 `content=None` / `IndexError` / `ValueError` / `HTTP 500` / `FileNotFoundError` / `FileExistsError` 등 — **에러 위치별로 즉석 매핑**
- 디버깅 시작 1분 전에 이 파일을 먼저 본다

## 🔍 에러 위치별 즉석 패치 표

| 시뮬 에러 위치 | 증상 | 원인 | 즉석 fix 위치 |
|--------------|------|------|---------------|
| **`gpt_structure.py: _nim_chat`** | `[1] ChatGPT_single_request('ping')` 빈 문자열, 시뮬 모두 fail_safe 반환 | reasoning 모델 (`gpt-oss-120b`, `o1`, `o3`, `deepseek-r1`) — `content=None` | `_nim_chat` 보강: `reasoning_content` → `<final>...</final>` 매칭 → fallback to last line |
| **`gpt_structure.py: _nim_embed`** | `urllib.error.HTTPError: HTTP Error 500` | (a) 빈/공백 텍스트 NIM 거부 (b) 잘못된 NIM 키 | (a) `(text or "").strip() == ""` → 0 벡터 반환; (b) curl로 키 진단 |
| **`run_gpt_prompt.py: __func_clean_up`** | `ValueError: invalid literal for int()` on `(total duration in minutes ...)` | 한국어 번역이 `(총 소요 시간 180분)`으로 형식 변경 | try/except + 정규식 폴백 `r'\(total duration in minutes[^0-9]*(\d+)'` + 60분 기본값 |
| **`run_gpt_prompt.py: __func_clean_up`** | `IndexError: list index out of range` on `k[1].split(",")[0]` | LLM 응답이 markdown 표 + `**이름**` 헤더 | regex-first `r'(\d+)\)\s*(.*?)\(duration in minutes:\s*(\d+)'` (re.DOTALL) + 라인 폴백 (마크다운 skip) |
| **`run_gpt_prompt.py: __func_clean_up`** | `IndexError` + `TOODOOOOOO` + `TOKEN LIMIT EXCEEDED` 출력 | 입력 프롬프트가 토큰 한도 초과 시 NIM이 "TOKEN LIMIT" 응답 | 응답 시작 가드: `if "TOKEN LIMIT" in gpt_response.upper(): return [["(default task)", 5]]` |
| **`reverie.py: ReverieServer.__init__`** | `FileNotFoundError: .../storage/<sim_name>` | `storage/` 디렉토리가 .gitignore 처리되어 비어 있음 | sparse-checkout으로 1GB storage/ 일부 다운로드 후 `cp -r environment/frontend_server/storage/base_the_ville_isabella_maria_klaus ...` |
| **`reverie.py: ReverieServer.__init__`** | `FileExistsError: [Errno 17] File exists: .../storage/<new_sim>` | 같은 이름으로 두 번 fork 시도 | 옵션 A: `rm -rf environment/frontend_server/storage/ICBM_kr_test` 후 재실행 / 옵션 B: forked에 이전 이름 + new에 `_v2` 입력 |
| **`reverie.py: open_server`** | `Enter option: 100` 4번 반복 (무시됨) | `sim_command[:3].lower() == "run"` 매칭이라 정확히 `run 100` (공백 + 숫자) 한 단어만 인식 | `run 100` 한 단어로 정확히 입력 |
| **`reverie.py: run`** | `ModuleNotFoundError: No module named 'selenium'` | 새 shell이 venv 비활성화 | `source .venv/bin/activate` (또는 alias `ga-sim`) |
| **`manage.py: runserver`** | `ModuleNotFoundError: No module named 'django'` | (a) venv 비활성화 (b) PYTHONPATH가 Hermes 가리킴 | (a) `source .venv/bin/activate` (b) `unset PYTHONPATH` (alias `ga-server`는 둘 다 자동) |
| **`manage.py: runserver`** | `Error: That port is already in use` | 이전 `python manage.py runserver`가 백그라운드 살아있음 | `lsof -i :8000` → `kill <PID>` |
| **NIM chat 200 OK + embed 500** | chat ping 응답, embed 500 | 두 엔드포인트 다른 처리 — keys는 OK, 빈 텍스트 문제 | `_nim_embed`의 빈 텍스트 가드 적용 (위 2번) |
| **NIM 500 + `Missing request extension: headers::common::authorization`** | chat/embed 모두 500 | zsh env의 `NVIDIA_API_KEY`가 NIM 거부 (만료/오타/잘못된 키) | `source ~/.hermes/secrets/nvidia_keys.env && export NVIDIA_API_KEY="$NVIDIA_API_KEY_1"` |
| **CSS 깨짐 / 한글 깨짐** | 페이지에 이상한 박스, □□□ | `lang="en"` + `<meta charset>` 누락 | `templates/base.html` 보강: `<html lang="ko">` + `<meta charset="UTF-8">` + 한글 헤더/푸터 |
| **Persona 이름에 한국어 안 보임** | Isabella 등 영어 그대로 | `maze_assets_loc` 또는 persona dict가 영문 소스 | 한국어 페르소나 시드 (`persona_seed_kr.py`) 적용 + whisper CSV 재생성 |

## 🔧 진단 우선순위 (5분 룰)

시뮬 실행 후 에러 → 이 순서로 1분 안에 진단:

```bash
# 1. venv/PYTHONPATH 확인 (가장 흔한 원인)
source .venv/bin/activate
unset PYTHONPATH
which python3 && python3 -c "import django, selenium, numpy; print('OK')"

# 2. NIM API 키 진단 (두 번째 흔한 원인)
source ~/.hermes/secrets/nvidia_keys.env
echo "  chat:" && curl -s -w "  HTTP_CODE: %{http_code}\n" -X POST "https://integrate.api.nvidia.com/v1/chat/completions" \
  -H "Authorization: Bearer $NVIDIA_API_KEY_1" -H "Content-Type: application/json" \
  -d '{"model": "openai/gpt-oss-120b", "messages": [{"role":"user","content":"ping"}], "max_tokens": 50}' 2>&1 | head -2
echo "  embed:" && curl -s -w "  HTTP_CODE: %{http_code}\n" -X POST "https://integrate.api.nvidia.com/v1/embeddings" \
  -H "Authorization: Bearer $NVIDIA_API_KEY_1" -H "Content-Type: application/json" \
  -d '{"model": "nvidia/llama-nemotron-embed-1b-v2", "input": ["test"], "input_type": "passage"}' 2>&1 | head -2
# 200 + JSON = 정상. 500 + "Missing request extension" = 키 불량.

# 3. Django self-test (Django 4.x 호환성)
cd environment/frontend_server
python manage.py check
# "System check identified no issues" 정상. corsheaders/six/url 에러 → Django 2→4 마이그레이션 (legacy-repo-modernization §3)

# 4. NIM gpt_structure self-test (reasoning 모델 + 임베딩)
cd reverie/backend_server/persona/prompt_template
python3 gpt_structure.py
# [1] "ping" 빈 문자열 = reasoning 모델 fix 누락. [2] 차원 2048 = 정상. [3] 0.057 = 부정 가드 정상.

# 5. 시뮬레이션 자체 (위 4개 모두 OK 시)
cd reverie/backend_server
python3 reverie.py
# forked: ICBM_kr_test → new: ICBM_kr_test_v2 → run 100
# step 0~5 진행 후 DEBUG 로그에 "TOODOOOOOO" + 깨진 응답 보이면 → 위 표의 (run_gpt_prompt.py) 행 참조
```

## 📊 시뮬레이션 단계별 정상 출력 패턴 (참고)

| 단계 | 기대 출력 |
|------|----------|
| `reverie.py` 시작 | `Note: The agents in this simulation package are computational...` |
| `Enter name of forked simulation:` | 사용자 입력 대기 |
| `Enter name of new simulation:` | 사용자 입력 대기 |
| `Enter option: run 100` | 17분간 진행 — step마다 LLM 호출 + persona state 업데이트 |
| step마다 DEBUG | `TOODOOOOOO` + LLM 응답 + `-==-` 구분선 + IndexError 없이 마무리 |
| 100 step 완료 | `Enter option:` 다시 표시 |
| `fin` | 시뮬 저장 + 종료, 다음에 `ICBM_kr_test`로 forked 가능 |

→ **TOODOOOOOO 없이 step 출력** = 정상. 매 step 끝에 `-==- -==- -==-` 구분선만 있고 IndexError 없으면 OK.
