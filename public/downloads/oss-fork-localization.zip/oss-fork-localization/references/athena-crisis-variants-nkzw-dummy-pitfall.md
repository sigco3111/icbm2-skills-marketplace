# Athena Crisis — `Variants.nkzw.tsx` 더미 우회 함정 + Hermes 가드 패턴 (2026-07-27)

## 1. Variants.nkzw 더미로 `pnpm build:client` 우회 불가

`art/Variants.nkzw.tsx`는 `infra/isOpenSource.tsx`의 `existsSync` 검사만 통과시키므로 **`isOpenSource()` boolean 플래그**만 전환한다. 이 값은 `codegen`, `babelPresets` 분기에서만 소비되고 vite 빌드 자체에는 영향 없음.

### 증상

Variants.nkzw.tsx 더미 작성 후 `pnpm build:client` 실행 → 동일하게 실패:

```
failed to load config from /Users/mac/work/athena-crisis-kr/ares/vite.config.ts
[UNRESOLVED_ENTRY] Cannot resolve entry module ares/vite.config.ts.
```

### 원인

`ares/` 워크스페이스 자체가 codegen-only — `vite.config.ts`, `ares.tsx`/`index.html`/`main.tsx`, `src/*.tsx`가 모두 `.gitignore` 또는 export 제외 상태. `isOpenSource`가 true든 false든 vite는 entry를 못 찾으니 통과 못함.

### 판단 기준

빌드가 막힐 때 Variants.nkzw.tsx 유무가 아니라 다음 두 가지로 분기:

1. `ares/vite.config.ts` 실존 여부 (`ls ares/vite.config.ts`)
2. `ares/src/` 안 entry 파일 실존 (`ls ares/src/*.tsx ares/src/index.html`)

둘 중 하나라도 없으면 `pnpm build:client`는 어떤 더미로도 못 통과시킨다.

### 우회

한국어 검증은 `offline/` 빌드(`pnpm build:offline`)로 갈음. `dist/offline/index.html`의 한국어 박힘만 확인해도 메인 클라이언트 본체의 fbtee 인라인 결과 검증으로 충분하다 (Athena Crisis는 `offline/`과 `ares/`가 동일한 fbtee 산출물을 공유, 차이는 빌드 타깃뿐).

### 진단 명령

```bash
# Variants.nkzw 효과 확인 — paid 모드 마커가 됐는지만 봄
ls art/Variants.nkzw.tsx  # 존재 → isOpenSource=false (paid)

# ares 워크스페이스 실존성 — 이것이 실제 빌드 가능 판정
ls ares/vite.config.ts 2>&1
ls ares/src/*.tsx ares/src/index.html 2>&1
ls ares/src/  # 비어 있으면 codegen 미실행 상태

# offline 워크스페이스 — 빌드 가능 대안
ls offline/vite.config.ts offline/index.html  # 둘 다 있으면 빌드 가능
```

## 2. Hermes 가드 — `vite build`도 long-lived로 오인됨

`pnpm exec vite build --outDir dist/ares ...` 형태도 헤드리스 `terminal()`에서 `exit_code=-1` ("long-lived server/watch process")로 거부됨. `timeout 60` 같은 셸 wrapper도 통과 못함.

### 해결 패턴 (bounded build commands)

```python
# 1) background로 던지고
terminal(command="...", background=true, timeout=120)
# → session_id 받음

# 2) wait로 종료 대기
process(action="wait", session_id=..., timeout=60)
# → exit_code 받음 (정상 빌드면 0, 실패면 1, 둘 다 bounded 끝)
```

### watch_patterns vs wait 분기 기준

| 시나리오 | 권장 패턴 | 이유 |
|---|---|---|
| `vite ./offline/` (dev server) | `background=true` + `watch_patterns=['Local:']` | 절대 안 끝남, mid-process 신호 필요 |
| `vite build --outDir ...` (build) | `background=true` + `process wait` | 종료 정해져 있음, exit_code 필요 |
| `pnpm build:client` (셸 체인) | `background=true` + `process wait` | 동일 |
| 장기 watcher (daemon) | `background=true` + `watch_patterns=['started']` | 절대 안 끝남 |

**즉시 적용 규칙**: build는 `wait`, dev/watcher는 `watch_patterns`. 빌드의 "vite v8.1.5 building" 같은 일시적 메시지는 watch에 부적합 — `ready` 문구만 알면 끝나는 게 아니고, 빌드 후 결과 코드까지 받아야 하므로 `wait` 패턴이 정답.

## 3. 한국어 검증 stage 선택 (재확인)

`references/athena-crisis-kr-offline-build-verification.md` §4의 표를 재강조:

| 빌드 | 한국어 인라인 위치 | 검증 grep |
|---|---|---|
| `pnpm build:offline` (`dist/offline/`) | 메인 엔진 fbtee 산출물, 인라인됨 | `grep -E "취소\|다시 시도\|기본" dist/offline/index.html` |
| `pnpm build:client` (`dist/ares/`) | ares 전용 (본 세션에선 빌드 불가) | 검증 불가 |
| `pnpm build:splash` (`dist/deimos/`) | 데모 사이트 한정 | 데모 페이지 검증 |

`dist/offline/`의 한국어 박힘이 본 세션의 최종 검증 목표였다 → `dist/offline/` 1.85 MB 인라인 HTML이 한국어 fbtee 키를 포함하는지만 확인하면 된다.
