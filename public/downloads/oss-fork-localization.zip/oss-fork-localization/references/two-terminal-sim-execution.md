# Two-Terminal Simulation Execution (Stanford Generative Agents 패턴)

Stanford generative_agents, AI Town, 그리고 대부분의 LLM-driven 시뮬레이션 OSS는 **두 개의 별도 프로세스**가 동시에 실행 중이어야 합니다. 한쪽만 띄우면 "왜 안 되지?" 무한 디버깅 함정. 이 문서는 정확한 6단계 워크플로를 정리합니다.

## 두 프로세스의 역할

| 터미널 | 프로세스 | 기본 명령 | 역할 |
|--------|----------|----------|------|
| **1 (Django)** | `python manage.py runserver` | port 8000 | 시각화, 페르소나 sprite 렌더링, 대사 표시 |
| **2 (시뮬)** | `python3 reverie.py` | stdin (interactive) | LLM 호출, 페르소나 행동 계획, step 진행 |

**Django는 시뮬 결과를 시각화만 합니다. 시뮬을 시작/진행시키는 것은 `reverie.py`입니다.**

## 6단계 가이드

### 단계 1: storage/ 시나리오 다운로드 (sparse-checkout)

`.gitignore`로 storage/가 빠진 상태에서는 시뮬을 시작할 수 없습니다. **1GB 전체가 아닌 일부만** 받기:

```bash
# 임시 디렉토리에 sparse clone
TMPDIR=/tmp/generative-agents-original
rm -rf "$TMPDIR"
git clone --depth 1 --filter=blob:none --sparse \
  https://github.com/joonspk-research/generative_agents.git "$TMPDIR"
cd "$TMPDIR"
git sparse-checkout set environment/frontend_server/storage

# 가장 작은 base 시나리오만 복사 (68KB — 3명 페르소나, 데모용)
cp -r environment/frontend_server/storage/base_the_ville_isabella_maria_klaus \
  /Users/mac/work/generative-agents-kr/environment/frontend_server/storage/

# 또는 25명 시나리오 (508KB)
cp -r environment/frontend_server/storage/base_the_ville_n25 \
  /Users/mac/work/generative-agents-kr/environment/frontend_server/storage/

rm -rf "$TMPDIR"
```

**옵션 비교**:

| 시나리오 | 크기 | 페르소나 수 | 용도 |
|---------|------|------------|------|
| `base_the_ville_isabella_maria_klaus` | 68KB | 3 | 빠른 데모/검증 |
| `base_the_ville_n25` | 508KB | 25 | UIST 데모 |
| 전체 23개 | 1GB | - | 전체 history |

### 단계 2: Django 시각화 서버 (터미널 1)

```bash
cd /path/to/generative-agents-kr
source .venv/bin/activate
unset PYTHONPATH  # ← Hermes 데스크탑 사용 시 필수
export NVIDIA_API_KEY="nvapi-..."

cd environment/frontend_server
python manage.py runserver
# → http://localhost:8000 (브라우저 열어두기)
```

Django는 백그라운드에서 움직이면서도 터미널 1을 점유합니다. `Ctrl+C`로 종료하지 말고 계속 켜두세요.

### 단계 3: 시뮬 백엔드 (터미널 2)

```bash
cd /path/to/generative-agents-kr
source .venv/bin/activate
unset PYTHONPATH
export NVIDIA_API_KEY="nvapi-..."

cd reverie/backend_server
python3 reverie.py
```

그러면:
```
Note: The agents in this simulation package are computational
constructs powered by generative agents architecture and LLM...

Enter option: 
```

### 단계 4: 새 시나리오 생성 (reverie.py 입력)

```
Enter the name of the forked simulation: base_the_ville_isabella_maria_klaus
Enter the name of the new simulation: ICBM_kr_test
```

그러면:
1. `storage/base_the_ville_isabella_maria_klaus/` 내용을 `storage/ICBM_kr_test/`로 복사
2. `meta.json`의 `fork_sim_code`만 새 시나리오로 변경
3. 메인 프롬프트 진입

### 단계 5: 시뮬레이션 시작

```
Enter option: run 100
```

- 100 step 진행 (1 step당 ~10초 = 약 17분)
- 매 step마다 NIM API 호출 (LLM 비용 발생)
- step 진행 시 Django 시각화에 페르소나 행동이 실시간 반영됨

**시뮬 중 사용 가능한 명령**:
| 명령 | 효과 |
|------|------|
| `save` | 현재 step까지 저장 (storage/ICBM_kr_test/ 그대로 보존) |
| `fin` | 저장 후 종료. 다음에 resume 가능 |
| `exit` | 저장 안 함, 데이터 삭제 (storage/ICBM_kr_test/ 통째 삭제) |
| `print persona schedule 이서연` | 해당 페르소나의 일과 출력 |
| `print all persona schedule` | 모든 페르소나의 일과 출력 |

### 단계 6: 브라우저에서 실시간 확인

Django가 켜져 있는 동안 브라우저로:

| URL | 용도 |
|-----|------|
| `http://localhost:8000/` | 시뮬레이션 목록 (env_server UI 한글) |
| `http://localhost:8000/replay/ICBM_kr_test/0/` | 특정 시뮬의 step 0 |
| `http://localhost:8000/replay/ICBM_kr_test/50/` | step 50 시점 |
| `http://localhost:8000/replay/ICBM_kr_test/100/` | step 100 시점 |

URL의 마지막 숫자(step 번호)로 시점 이동. 한국어 UI에 페르소나 이름, 현재 행동, 위치, 대사가 표시됨.

## resume (이어서 시뮬)

`fin`으로 저장한 시뮬을 다시 시작:

```
Enter the name of the forked simulation: ICBM_kr_test
Enter the name of the new simulation: ICBM_kr_test_continued
```

`storage/ICBM_kr_test_continued/`가 새로 만들어지며, `ICBM_kr_test/`의 마지막 step부터 이어서 진행.

## 함정

### 함정 1: Django만 띄우고 시뮬 안 띄움

```
브라우저 → http://localhost:8000/replay/
→ "시뮬레이션 서버 미연결" 페이지
```

**해결**: 터미널 2에서 `python3 reverie.py` 실행.

### 함정 2: run 100 입력 후 silent fail

NIM API 키가 잘못되었거나, reasoning 모델 처리가 안 되어 있으면 `run 100`이 무한히 멈춤. 콘솔에 "DEBUG", "TOODOOOOOO" 같은 디버그 로그만 반복.

**해결**:
- `gpt_structure.py self-test` 통과 확인
- `~/.hermes/secrets/nvidia_keys.env`에서 정상 키 사용 확인
- `references/llm-markdown-response-parsing.md` 확인

### 함정 3: venv 새로 열 때마다 다시 활성화

새 터미널을 열면 venv가 풀려 `python3 reverie.py`가 `ModuleNotFoundError`로 죽음.

**해결**: 매 새 터미널마다:
```bash
cd /path/to/generative-agents-kr
source .venv/bin/activate
unset PYTHONPATH
```

### 함정 4: 25명 시나리오 fork 후 run 100 = 30분+

`base_the_ville_n25` (25명) 시나리오에서 100 step은 약 30분. 각 step마다 25명 × LLM 호출 = 100+ 호출.

**해결**:
- 처음 검증은 3명 시나리오 + `run 10` (1-2분)
- 검증 후 큰 시나리오 시도

### 함정 5: shell `&`로 백그라운드 못 띄움

```bash
python manage.py runserver 8001 &  # ❌ Hermes terminal에서 거부
```

**해결**: `terminal(background=true)` 또는 `process action=kill` 도구 사용. bash의 `&`는 이 환경에서 Forbidden.

## 한국어 페르소나로 시뮬 시작 (선택)

base 시나리오는 Isabella/Maria/Klaus 영어 페르소나. 한국 페르소나(이서연/김민준/박지우)로 시작하려면:

1. base 시나리오 fork 후 `reverie/meta.json`의 `persona_names`를 한국 이름으로 교체
2. `storage/<sim_code>/personas/meta.json`에 한국어 whisper CSV 로드 (`persona/agent_history_init_kr_n3.csv`)
3. 또는 별도 `Korean_3personas_base` 시나리오 직접 작성

이 작업은 fork + 한국어 persona_seed + map JSON 편집이 결합된 별도 단계이므로, **이번 skill의 Stage 4.5 확장으로 다룰 것**.

## 검증 체크리스트

- [ ] `git sparse-checkout`으로 base 시나리오만 다운로드 (전체 X)
- [ ] `python manage.py check` → "System check identified no issues"
- [ ] `python manage.py runserver` → HTTP 200 OK on `http://localhost:8000/`
- [ ] `python3 reverie.py` → "Enter option:" 프롬프트 표시
- [ ] `run 100` → step 진행 + NIM LLM 호출 정상
- [ ] 브라우저 `/replay/ICBM_kr_test/50/` → 한국어 UI + 페르소나 행동 표시
- [ ] `fin` → storage/ICBM_kr_test/ 보존
- [ ] 새 터미널 열 때마다 venv 재활성화 + `unset PYTHONPATH`

## 실측 사례 (sigco3111/generative_agents-kr, 2026-07-14)

6단계 모두 통과:
- sparse-checkout 1분, Django runserver 5초, reverie.py fork 10초
- run 100 = ~17분 (1 step = 10초)
- 브라우저 한국어 UI 정상 (Django 한글화 패치 덕분)
- `fin`으로 정상 저장, 재시작 가능
