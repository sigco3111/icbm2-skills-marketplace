# Django/HTML UI 한글화 패턴 (generative_agents-kr Phase 4, 2026-07-14)

> OSS fork의 Django UI 템플릿(.html) + base.html을 한글화하는 정형 패턴. `oss-fork-localization` Stage 4 (UI) 단계에서 사용. 다른 Python/Node/React UI도 같은 패턴 적용 가능.

## 적용 시점

- Stage 3 (페르소나 시드) + Stage 3.5 (프롬프트) 완료 후
- Stage 4 (UI) 직전 — 사용자 첫 화면이 한국어인지 즉시 확인 가능
- 시뮬레이션 결과는 LLM 한국어 응답이라 자동 적용, **UI 자체 텍스트만 별도 번역**

## 핵심 발견: JS 텍스트는 거의 안 건드림

대부분의 시뮬레이션 UI에서 템플릿의 JS (`main_script.html`)는 **페르소나 행동 텍스트만 동적 삽입** → LLM이 한국어 응답 → 자동 한국어 표시. 노출되는 영문 UI 텍스트는 **HTML 템플릿의 정적 텍스트만**.

`grep`로 빠르게 노출 텍스트 식별:
```bash
grep -nE 'font-weight:800"|<strong>|<h[1-6]|<p|button.*Play|<input.*value="' templates/**/*.html
```

## 한글화 우선순위

| 파일 | 줄수 | 노출 텍스트 수 | 우선순위 |
|------|-----|---------------|---------|
| `base.html` | ~40 | 2-5 (헤더/푸터) | 🟢 항상 |
| `landing.html` | ~10 | 1 | 🟢 항상 |
| `<앱>/home.html` | ~80 | 5-10 | 🟡 항상 |
| `<앱>/error_*.html` | ~10 | 1-2 | 🟡 항상 |
| `<앱>/demo.html` | ~150 | 8-15 | 🟡 권장 |
| `<앱>/main_script.html` (JS) | ~500 | 0-2 (대부분 동적) | 🟢 패스 |
| persona_state/detail 페이지 | ~250 | 25-30 (라벨) | 🟢 마이너 |
| `path_tester/*.html` | ~20 | 0 | 🟢 패스 |

## 패턴 1: base.html 보강 (헤더/푸터 + lang 속성)

원본 base.html이 단순 wrapper면 헤더/푸터/nav 추가:

```html
<!-- 원본 -->
<!DOCTYPE html>
{% load staticfiles %}
<html lang="en">
<head><title>Reverie</title></head>
<body>{% block content %}{% endblock %}</body>
</html>

<!-- 한글화판: nav + 헤더 + 푸터 + lang="ko" -->
<!DOCTYPE html>
{% load staticfiles %}
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{% block title %}제너러티브 에이전트 시뮬레이션{% endblock %}</title>
  <link rel="stylesheet" href="...bootstrap...">
  <link rel="icon" href="{% static 'img/favicon.png' %}">
</head>
<body>
  <header style="background-color:#2c3e50; color:white; padding:1em 2em;">
    <h1 style="margin:0; font-size:1.4em">🏘️ <strong>제너러티브 에이전트</strong> 한국어판</h1>
    <p style="margin:0.3em 0 0; font-size:0.85em">
      Stanford Generative Agents 한국어 시뮬레이션 · Apache 2.0 Fork
    </p>
  </header>
  {% block content %}{% endblock %}
  <footer style="text-align:center; padding:1.5em; color:#888">
    제너러티브 에이전트 한국어판 ·
    <a href="https://github.com/sigco3111/generative_agents-kr">sigco3111/generative_agents-kr</a>
  </footer>
</body>
</html>
```

**핵심**:
- `lang="en"` → `lang="ko"` (브라우저 자동 한글 폰트/IME 적용)
- 원본 `{% block content %}` 보존 — 자식 템플릿 그대로 동작

## 패턴 2: 정적 텍스트 sed 치환 + 아이콘

시각 자산에 의존하지 않는 정적 텍스트는 **sed/python re.sub**로 일괄 치환:

```python
import re
mapping = {
    "Current Time:": "⏰ 현재 시각:",
    "Current Action:": "🎯 현재 행동:",
    "Location:": "📍 위치:",
    "Current Conversation:": "💬 현재 대화:",
    "Play": "재생",
    "Pause": "일시정지",
    "State Details": "📋 상세 보기",
}
for en, ko in mapping.items():
    text = re.sub(r'(font-weight:800">)' + re.escape(en) + r'(</td>)',
                  r'\1' + ko + r'\2', text)
```

**이모지 prefix 추가**는 단순 시각 효과지만 사용자 경험에서 **한글화 느낌을 크게 향상** (🎯📍💬 vs plain text).

## 패턴 3: 페이지 안내문 (landing/error)

원본: `Your environment server is up and running!`
한글화: 환경 서버 안내 + 실행 가이드 단계 + 버튼 그룹

```html
<div style="background-color:#ecf0f1; padding:2em; border-radius:10px">
  <h2>✅ 환경 서버 정상 동작 중!</h2>
  <p>시뮬레이션 시각화 서버가 작동합니다. 백엔드를 시작한 후 새로고침하세요.</p>
</div>
<div style="background-color:#fff8dc; padding:1.5em; border-radius:10px">
  <h3>📋 실행 안내</h3>
  <ol>
    <li>백엔드: <code>cd reverie/backend_server</code></li>
    <li>시뮬 실행: <code>python3 reverie.py</code></li>
    <li>시뮬 이름 입력 → <code>run 100</code></li>
    <li>새로고침</li>
  </ol>
</div>
<div style="text-align:center">
  <a href="/"><button>🏠 메인으로</button></a>
  <a href="/demo/"><button>🎬 데모</button></a>
</div>
```

## 패턴 4: 다중 라벨 매핑 (persona_state 같은 detail 페이지)

원본이 25+ 라벨이면 일괄 매핑 dict + 패턴별 re.sub:

```python
# persona_state.html 사례 (28개 라벨)
mapping = {
    "First name": "이름 (성 제외)",
    "Last name": "성",
    "Age": "나이",
    "Current time": "현재 시각",
    "Current tile": "현재 위치",
    "Vision Radius": "시야 반경",
    "Attention Bandwidth": "주의 대역폭",
    "Retention": "기억 유지력",
    "Innate tendency": "선천적 성향",
    "Learned tendency": "학습된 성향",
    "Currently": "현재 상태",
    "Lifestyle": "라이프스타일",
    "Daily Requirement": "일일 요구사항",
    "Daily Schedule": "일일 일정",
    "Action Address": "행동 장소",
    "Action Start Time": "행동 시작 시간",
    "Action Duration": "행동 지속 시간",
    "Action Description": "행동 설명",
}
# 두 단계: td 라벨 + h3 헤딩
for en, ko in mapping.items():
    text = re.sub(r'(font-weight:800">)' + re.escape(en) + r'(</td>)',
                  r'\1' + ko + r'\2', text)
text = text.replace("<strong>Basic information</strong>", "<strong>📋 기본 정보</strong>")
text = text.replace("<strong>Settings</strong>", "<strong>⚙️ 설정</strong>")
```

## ⏭️ 패턴 5: view/URL은 그대로

`views.py`의 `template = "home/home.html"` 같은 경로는 **건드리지 않음**. URL 패턴 `{% url 'replay_persona_state' %}`도 그대로.

→ Django i18n (`ugettext`, `_('...')`) 도입 안 함. 단순 HTML 직접 치환이 가장 빠르고 효과적.

## ⏭️ 패턴 6: 시각 자산 (이미지/맵)은 그대로

원본 게임 맵 (Stanford Smallville 등)의 sprite/profile 이미지는 **레이아웃이 한글 이름과 안 맞아** 보일 수 있어 그대로 둠. 페르소나 이름은 LLM 응답으로 자동 한국어, 위치/장소명도 LLM이 자연스럽게 번역.

→ 시각 자산 한글화는 무한 작업, **시뮬레이션 텍스트가 한국어면 80% 완성**.

## 📂 변경 후 구조

```
templates/
├─ base.html                # ✅ 한글 헤더/푸터 + lang="ko"
├─ landing/landing.html     # ✅ 환경 안내 + 실행 가이드
├─ home/home.html           # ✅ Current Time/Action → 한국어
├─ home/error_*.html        # ✅ 백엔드 미연결 안내
├─ demo/demo.html           # ✅ 데모 화면 전체
├─ home/main_script.html    # (패스 — JS 동적)
├─ demo/main_script.html    # (패스)
├─ persona_state/*.html     # ✅ 25+ 라벨 매핑
└─ path_tester/*.html       # (패스 — 텍스트 없음)
```

## 📊 작업량 (실측, 2026-07-14)

| 파일 | 변경 방법 | 시간 |
|------|----------|------|
| base.html | 직접 작성 | 5분 |
| landing.html | 직접 작성 | 5분 |
| home.html | sed 직접 | 5분 |
| error_start_backend.html | 직접 작성 | 3분 |
| demo.html | 직접 작성 | 10분 |
| persona_state.html | python re.sub 매핑 | 10분 |
| main_script.html | 패스 (0건) | 0분 |
| **합계** | | **~40분** |

## ⚠️ 함정 1: write_file 경로 꼬리 string

`write_file(path="/.../templates/base.html.kra</path>")` 형태로 path 끝에 `</path>`가 literal string으로 들어가서 **빈 파일 `base.html.kra<` 생성**됨.

**증상**: `ls templates/` → `base.html.kra<` 같이 `<` 접미사 등장.

**해결**:
```bash
# 빈 디렉토리/파일 정리
rm -rf 'templates/base.html.kra<'
```

## ⚠️ 함정 2: bash grep 한글 escape

`grep -E '\\!<INPUT 0>\\!' file.txt` 같은 형태는 bash escape로 매칭 실패. Python re 사용:

```bash
python3 -c "import re; print(re.findall(r'!<INPUT \d+>!', open('file.txt').read()))"
```

## ⚠️ 함정 3: views.py의 `template = "..."` 경로는 무수히 많음

경로를 일괄 `_kr` 디렉토리로 변경하지 말고, **HTML 파일 안에서 자체적으로 `lang="ko"` + 한글 텍스트** 로 작업. `views.py`는 무수한 곳에서 template 경로를 참조하므로 건드리면 광범위한 변경 필요.

## ✅ 검증

- [ ] `lang="ko"` 속성이 base.html에 들어갔는지
- [ ] `<head>` charset=UTF-8 보존
- [ ] 모든 라벨 (`font-weight:800"`) 한글화
- [ ] 동적 삽입 부분 (`{{ p_name }}`, `{% url %}`) 보존
- [ ] `templates/base.html.kra<` 같은 빈 파일 없음
- [ ] `views.py` 변경 없음 (template 경로 그대로)

## 🔗 관련

- `references/korean-persona-seed-pattern.md` — 페르소나 CSV/whisper
- `references/prompt-auto-translation.md` — 프롬프트 자동번역
- `references/korean-simulation-verification.md` — Phase 5 end-to-end 검증 (다음 단계)
