# Web App i18n 렌더 검증 (Next.js / next-intl / i18next 풀스택)

> **트리거**: 풀스택 웹앱(Next.js, Remix, SvelteKit 등)에서 `messages/<locale>.json` 추가 후 dev 서버 띄우고 "한국어가 실제로 렌더되는지" 빠르게 검증하고 싶을 때. ssr html에 `lang="ko"` 박혀있는지, JSON key가 아닌 user-facing label이 한국어로 나오는지 확인하는 워크플로.

## 핵심 함정: JSON 키 vs 사용자 텍스트 분리 (2026-07-27, neko-master-ko 실측)

`next-intl` / `i18next` / `react-intl` 어떤 라이브러리든 `messages/{locale}.json`은 **SSR payload 전체가 HTML 안에 인라인**된다. 그래서 `grep`으로 한국어/한자/영문 매치를 찍으면:

- ✅ 진짜 사용자 텍스트 (예: `대시보드`, `仪表盘`, `Dashboard`)
- ❌ JSON payload 안의 camelCase **key 이름** (예: `sortByTraffic`, `topDomains`, `uniqueDomains`, `autoRefresh`)
- ❌ 라이브러리 디폴트 fallback 문구

이 셋이 모두 grep 카운트에 잡힌다. **"영문이 1개 매치됐다" → "한글화 안 됐다" 오판하지 말 것**.

## 4축 검증 워크플로 (실측 neko-master-ko, 2026-07-27)

### 1단계: 의존성 + dev 서버 띄우기

```bash
# pnpm 워크스페이스면 corepack 활성 후
corepack enable && corepack prepare pnpm@9.15.9 --activate
pnpm install --prefer-offline  # 889 패키지 정도, 10~15초

# 백그라운드로 dev 띄우기 (notify_on_complete=true)
pnpm dev  # turbo가 shared + collector + web 동시 부팅

# Next.js Ready 신호 polling
process action=poll ... # Next.js 16 + Turbopack이면 261ms Ready
```

**시그널**:
- Next.js Turbopack 첫 부팅 ~250~400ms → 매우 빠름
- `tsx watch` (collector)는 의존성 설치 후 즉시 Ready
- `tsc --watch` (shared)는 첫 컴파일 5~15초

### 2단계: HTTP 상태 + html lang 속성

```bash
curl -sS -o /tmp/ko_dash.html -w "HTTP=%{http_code}\n" -L http://localhost:3000/ko/dashboard
# → HTTP 200이어야 정상 (i18n 라우터가 locale 세그먼트로 redirect 안 함)

grep -oE '<html[^>]*lang="[^"]*"' /tmp/ko_dash.html | head -1
# → <html lang="ko"  정상
```

**함정**: 어떤 프로젝트는 middleware에서 locale prefix 없이 동작 (쿠키 기반). `curl -L`로 redirect 따라가도 locale 없는 root로 가면 `lang`이 defaultLocale로 박힐 수 있음. **반드시 locale-prefixed URL로 직접 fetch**.

### 3단계: 한국어 label 마커 검사

```bash
# ko.json에서 실제 user-facing label (사람이 읽는 단어) 5~10개 선정
KO_LABELS=("대시보드" "새로고침" "상위 도메인" "규칙" "네트워크" "트래픽" "디바이스")
for s in "${KO_LABELS[@]}"; do
  printf "  %-22s " "$s"
  grep -c "$s" /tmp/ko_dash.html
done

# 비교군: zh 페이지 같은 마커의 한자 버전
ZH_LABELS=("仪表盘" "刷新" "上 域名" "规则" "网络")
for s in "${ZH_LABELS[@]}"; do
  printf "  %-22s " "$s"
  grep -c "$s" /tmp/zh_dash.html
done
```

**판정 기준**:
- 한국어 label 5/7개 이상 검출 → 한국어 정상 렌더
- zh도 5/5개 검출 → 회귀 없음
- 한쪽이라도 0 → JSON에 키 누락이거나 `notFound()` 분기 (404 다름)

### 4단계: 영문 잔재 false positive 분류 (가장 중요)

```bash
# 영문 매치 조사 — camelCase JSON 키가 잡힐 것
for s in "Refresh" "Traffic" "Domains" "Rules"; do
  echo "--- $s ---"
  grep -oE ".{40}${s}.{40}" /tmp/ko_dash.html | head -3
done
```

**출력 예 (실측 neko-master-ko)**:
```
--- Refresh ---
}시간 전\",\"daysAgo\":\"{days}일 전\",\"autoRefresh\":\"자동 새로고침\",\"paused\":\"일시정지\"

--- Traffic ---
도메인\",\"topDomains\":\"상위 도메인\",\"sortByTraffic\":\"트래픽순 정렬\",\"sortByConnections\":\"연
Proxies\":{\"title\":\"상위 프록시\",\"sortByTraffic\":\"트래픽순 정렬\"
```

**판독**:
- 매치 주변에 `\"key\":\"value\"` 패턴 → **camelCase JSON key** → ✅ 정상 (UI엔 영향 없음)
- 매치 주변에 `>영문단어<` (HTML 태그 사이) → **실제 UI 잔재** → ❌ 번역 누락

**핵심**: SSR HTML에는 JSON payload 전체가 `<script>`로 인라인되므로, JSON key는 **반드시 매치됨**. 이를 false positive로 인지하지 못하면 i18n 작업 시간을 낭비함.

## 검증 매트릭스

| 신호 | 의미 | 조치 |
|------|------|------|
| `<html lang="ko">` 있음 + label 5/7개 검출 + 영문 매치는 camelCase key만 | ✅ 정상 | 작업 완료 |
| `<html lang="ko">` 있는데 label 0개 | ❌ JSON에 locale 데이터 없거나 잘못된 locale fetch | `messages/<locale>.json` 존재 + `routing.locales.includes()` 확인 |
| label 검출 + 영문 잔재가 `<tag>English</tag>` 패턴 | ❌ 번역 누락 | 누락된 key를 ko.json에 추가 |
| HTTP 404 on `/ko/...` | ❌ i18n 라우터에 locale 미등록 | `i18n/routing.ts`에 locale 추가 |
| HTTP 200 but html lang이 default | ⚠️ locale prefix 없이 default로 fallback | middleware가 locale prefix 강제하는지 확인 |
| curl -L 안 했는데 redirect 307 | ⚠️ `/ko` → `/ko/dashboard` 등 | `-L` 플래그로 redirect 따라가기 |

## 추가 확인 — language switcher 노출

language switcher가 dropdown 형태라면 새 locale이 **자동 노출되는지** vs **하드코딩**인지 확인:

```bash
# switcher 컴포넌트 찾기
grep -rn "LanguageSwitcher\|language-switcher" apps/web/components/

# locales 배열 하드코딩?
grep -A3 "const locales" apps/web/components/common/language-switcher.tsx
# → const locales = ["en", "zh", "ko"] as const;  ← 하드코딩 (추가 시 수동 편집 필요)
# → {routing.locales.map(...)}  ← 자동 노출 (routing.ts만 수정하면 OK)
```

**권장**: routing.ts에서 자동 노출하도록 refactor (locale 추가할 때마다 2군데 수정 안 해도 됨). 단, 라벨 표시(예: "한국어" vs "Korean")는 switcher 자체에서 관리 필요.

## hermes `open_preview`로 사용자 시각 검증

curl + grep이 통과했어도 **실제 브라우저 렌더**는 다를 수 있음 (CSS 깨짐, 폰트 누락, layout shift). 마지막 단계:

```
open_preview(url="http://localhost:3000/ko/dashboard", label="KO dashboard")
```

→ 사용자 데스크탑 Hermes 패널에 페이지 띄움 → 사용자 직접 확인.

## 시간 단축 비교

| 방법 | 시간 | 정확도 |
|------|------|--------|
| Playwright 스크린샷 + OCR | 30~60초 | 95% |
| **curl + html lang + grep label (이 워크플로)** | **10초** | **85%** |
| curl만 | 3초 | 50% (UI 검증 불가) |
| 사용자에게 "확인해주세요"만 | 0초 | 의존 |

**선택 가이드**:
- "대시보드 1페이지 라벨만 빠르게 확인" → curl + grep
- "전체 라우트 × 모든 locale" → Playwright
- "사용자가 직접 봐야 함" → open_preview + 사용자 확인

## neko-master-ko 실측 종합 (2026-07-27)

| 단계 | 시간 | 산출 |
|------|------|------|
| 의존성 설치 | 11.4초 | 889 packages |
| pnpm dev 부팅 | ~400ms | shared + collector + web Ready |
| curl 3개 URL | 1초 | ko/zh 모두 200 |
| html lang 검사 | <0.1초 | ko, zh 둘 다 정상 |
| label grep | <0.1초 | 한국어 5/7, 한자 4/5 |
| 영문 잔재 분류 | 0.5초 | camelCase key만 매치 → 정상 |
| open_preview | 0초 (back) | 사용자 시각 검증 대기 |

**총 12~15초에 i18n 검증 + 시각 검증 환경 조성 완료**.

## 즉시 적용 규칙

1. **의존성 미설치 환경이면**: `corepack enable && corepack prepare pnpm@9.15.9 --activate`부터 (corepack은 Node 16.10+ 기본 포함)
2. **백그라운드 dev 띄울 때**: `notify_on_complete=true` + dev 서버 Ready 신호 polling (Next.js Turbopack이면 0.5초 이내)
3. **3개 locale 모두 fetch**: ko + zh + en 비교 — 한쪽만 검증하면 회귀 놓칠 수 있음
4. **grep 라벨은 사용자 단어로**: camelCase key (`sortByTraffic` 등) ❌, UI 단어 (`새로고침` 등) ⭕
5. **html lang + label 5/7 + 영문 잔재가 camelCase key뿐** → 통과
6. **마지막은 open_preview**: CSS / layout / 폰트는 curl로 못 잡음