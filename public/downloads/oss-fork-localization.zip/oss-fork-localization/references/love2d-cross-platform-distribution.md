# LÖVE 게임 크로스 플랫폼 배포 — `build_all.sh` + GitHub Releases

SNKRX v0.1.12 GitHub Release (2026-07-21) 발행 워크플로. LÖVE 11.5 게임 4개 플랫폼 (.love + macOS .app + Windows zip + Linux tar.gz) + GitHub Release 자동 업로드.

## 사용 시기

- LÖVE/Lua 게임 fork + 한글화 끝난 후
- "누구나 쉽게 접근할 수 있도록 배포" 요청 시
- itch.io, Steam Workshop 대신 GitHub Releases 무료 배포 선택 시
- 게임 본인이 호스팅 (외부 의존성 0)

## 4개 플랫폼 산출물

| 플랫폼 | 형식 | 크기 | 내용 |
|---|---|---|---|
| macOS | `.zip` (`.app` 번들) | 86M | love 실행파일 + 10개 .framework + Info.plist + game.love + 아이콘 |
| Windows | `.zip` (폴더) | 4.3M | love.exe + DLL + game.love + run.bat + README.txt |
| Linux | `.tar.gz` | 65M | love.AppImage + game.love + run.sh + README.txt |
| 크로스 | `.love` 단독 | 62M | love2d 설치된 모든 OS에서 `love game.love` |

## 통합 빌드 스크립트 (`build_all.sh`)

```bash
#!/bin/bash
set -e
VERSION="${VERSION:-v0.1.12}"
PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
DIST_DIR="$PROJECT_DIR/dist"
LOVE_OUTPUT="$DIST_DIR/snkrx-kr-$VERSION.love"

# 1. .love 빌드
"$PROJECT_DIR/build_love.sh"

# 2. macOS .app
"$DIST_DIR/macosx/build_macos.sh"
(cd "$DIST_DIR" && zip -r "snkrx-kr-macos-$VERSION.zip" "SNKRX-한국어.app" -q)

# 3. Windows zip (subshell cd로 부작용 방지)
WINDOWS_DIR="$DIST_DIR/windows"
[ ! -f "$WINDOWS_DIR/love.exe" ] && (
    curl -L -o "$WINDOWS_DIR/love.zip" "https://github.com/love2d/love/releases/download/11.5/love-11.5-win64.zip"
    cd "$WINDOWS_DIR" && unzip -q -o love.zip && rm love.zip
)
cp "$LOVE_OUTPUT" "$WINDOWS_DIR/"
(cd "$WINDOWS_DIR" && zip -r "$DIST_DIR/snkrx-kr-windows-$VERSION.zip" love-11.5-win64/ -q)

# 4. Linux tar.gz
LINUX_DIR="$DIST_DIR/linux"
[ ! -f "$LINUX_DIR/love.AppImage" ] && (
    curl -L -o "$LINUX_DIR/love.AppImage" "https://github.com/love2d/love/releases/download/11.5/love-11.5-x86_64.AppImage"
    chmod +x "$LINUX_DIR/love.AppImage"
)
cp "$LOVE_OUTPUT" "$LINUX_DIR/"
(cd "$LINUX_DIR" && tar czf "$DIST_DIR/snkrx-kr-linux-$VERSION.tar.gz" love.AppImage "snkrx-kr-$VERSION.love" run.sh README.txt)
```

## macOS .app 빌드 (build_macos.sh) — 3가지 함정

### 함정 1: Contents/Frameworks/* 10개 .framework 번들 필수

**증상**:
```
dyld[24163]: Library not loaded: @rpath/love.framework/Versions/A/love
```

**원인**: macOS .app은 self-contained. `/Applications/love.app/Contents/Frameworks/*`를 같이 복사해야 함.

**10개 .framework** (love2d 11.5):
```
Lua.framework, OpenAL-Soft.framework, SDL2.framework, freetype.framework,
libmodplug.framework, love.framework, mpg123.framework, ogg.framework,
theora.framework, vorbis.framework
```

**해결**:
```bash
FRAMEWORKS_SRC="/Applications/love.app/Contents/Frameworks"
FRAMEWORKS_DST="$CONTENTS/Frameworks"
mkdir -p "$FRAMEWORKS_DST"
cp -R "$FRAMEWORKS_SRC"/* "$FRAMEWORKS_DST/"
```

### Info.plist (Contents/Info.plist)

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleName</key><string>SNKRX 한국어</string>
    <key>CFBundleDisplayName</key><string>SNKRX 한국어</string>
    <key>CFBundleExecutable</key><string>love</string>
    <key>CFBundleIdentifier</key><string>com.sigco3111.snkrx-kr</string>
    <key>CFBundleVersion</key><string>0.1.12</string>
    <key>CFBundleShortVersionString</key><string>0.1.12</string>
    <key>CFBundlePackageType</key><string>APPL</string>
    <key>LSMinimumSystemVersion</key><string>10.13</string>
    <key>NSHighResolutionCapable</key><true/>
    <key>NSPrincipalClass</key><string>NSApplication</string>
    <key>CFBundleDocumentTypes</key>
    <array>
        <dict>
            <key>CFBundleTypeName</key><string>LÖVE Game</string>
            <key>CFBundleTypeRole</key><string>Viewer</string>
            <key>LSItemContentTypes</key>
            <array><string>org.love2d.love-game</string></array>
        </dict>
    </array>
</dict>
</plist>
```

### `.love` 위치: Contents/Resources/game.love

love2d가 자동으로 찾음. `Contents/Resources/`에 배치.

### Gatekeeper — "love(를)를 열지 못함" 팝업

`.app`을 Applications로 드래그 후 실행 시 **"Apple이 서명되지 않은 Mac용 소프트웨어에서...\" 팝업** 뜸.

**해결 (1초)**: Finder에서 .app 우클릭 → "열기" → 경고 다시 "열기"
**해결 (Finder UI, 30초)**: 우클릭 → 열기 → 경고 다시 클릭 → 열기
**해결 (quarantine 제거, 1초)**: 
```bash
xattr -dr com.apple.quarantine "/Applications/SNKRX-한국어.app"
```

## Windows zip — `unzip -o` interactive prompt 함정

**증상**:
```
replace love-11.5-win64/changes.txt? [y]es, [n]o, [A]ll, [N]one, [r]ename:  NULL
```

**해결**: `unzip -q -o love.zip` (overwrite yes)

```bash
# .love 복사
cp dist/snkrx-kr-$VERSION.love dist/windows/love-11.5-win64/

# run.bat
@echo off
cd /d "%~dp0"
love.exe snkrx-kr-$VERSION.love
if errorlevel 1 pause
```

## Linux AppImage

```bash
# 다운로드 (4.8MB)
curl -L -o love.AppImage "https://github.com/love2d/love/releases/download/11.5/love-11.5-x86_64.AppImage"
chmod +x love.AppImage

# run.sh
#!/bin/bash
set -e
cd "$(dirname "$0")"
./love.AppImage snkrx-kr-$VERSION.love "$@"
```

**FUSE 미설치 환경**:
```bash
./love.AppImage --appimage-extract
./squashfs-root/AppRun snkrx-kr-$VERSION.love
```

## GitHub Release 발행 — `gh release create` workflow scope 우회

**증상**:
```
$ gh release create v0.1.12 ...
! Failed to create release, "workflow" scope may be required.
```

**해결 — curl API 직접 호출**:

```bash
TOKEN=$(gh auth token 2>/dev/null)

# 1) Draft release 생성
curl -s -X POST \
  -H "Authorization: Bearer $TOKEN" \
  -H "Accept: application/vnd.github+json" \
  https://api.github.com/repos/OWNER/REPO/releases \
  -d '{"tag_name":"v0.1.12","name":"...","body":"...","draft":true}' \
  | python3 -c "import sys,json; d=json.load(sys.stdin); print(f'ID: {d[\"id\"]}')"

# 2) Asset 업로드 (4개)
RELEASE_ID="<id>"
UPLOAD_URL="https://uploads.github.com/repos/OWNER/REPO/releases/${RELEASE_ID}/assets{?name,label}"
for file in dist/snkrx-kr-*.zip dist/snkrx-kr-*.tar.gz dist/snkrx-kr-*.love; do
  name=$(basename "$file")
  curl -s -X POST \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/zip" \
    --data-binary "@$file" \
    "${UPLOAD_URL//\{?name,label\}/?name=$name}" \
    -o /dev/null -w "  HTTP %{http_code} (%{size_upload} bytes)\n"
done

# 3) Draft → Published
curl -s -X PATCH \
  -H "Authorization: Bearer $TOKEN" \
  https://api.github.com/repos/OWNER/REPO/releases/$RELEASE_ID \
  -d '{"draft":false}'
```

**HTTP 201 = 성공**. 4개 asset 모두 한 번에 업로드.

## 빌드 산출물 검증 워크플로

```bash
# 1. 모든 플랫폼 .zip/.tar.gz 존재 확인
ls -lh dist/snkrx-kr-{macos,windows,linux}-*.{zip,tar.gz} dist/snkrx-kr-*.love

# 2. macOS .app 부팅 검증
"dist/SNKRX-한국어.app/Contents/MacOS/love" &
LOVE_PID=$!
sleep 5
ps -p $LOVE_PID -o pid,stat,command 2>/dev/null && echo "ALIVE" || echo "DIED"
kill -9 $LOVE_PID

# 3. .love 단독 실행 검증 (love2d 설치된 모든 OS)
love dist/snkrx-kr-*.love &
# ... 동일

# 4. syntax 검증 (Lua 게임)
for f in shared.lua main.lua main.lua buy_screen.lua arena.lua; do
  luac -p "$f" 2>&1 && echo "$f: OK"
done
```

## .gitignore 패턴

```gitignore
dist/
```

**이유**: 빌드 결과물은 수십~수백 MB. GitHub push에 부담. **소스 + 빌드 스크립트만** repo에 보관. 빌드 결과물은 GitHub Releases에만.

## README 다운로드 섹션 템플릿

```markdown
## 📦 다운로드 (v1.0.0)

**[GitHub Releases 페이지](https://github.com/USER/REPO/releases/tag/v1.0.0)**

| 플랫폼 | 파일 | 크기 | 설치 |
|---|---|---|---|
| macOS | projectname-macos-v1.0.0.zip | 86M | 압축 해제 → .app을 Applications로 드래그 |
| Windows | projectname-windows-v1.0.0.zip | 4.3M | 압축 해제 → run.bat 더블클릭 |
| Linux | projectname-linux-v1.0.0.tar.gz | 65M | 압축 해제 → ./run.sh |
| 크로스 | projectname-v1.0.0.love | 62M | love2d 설치 후 love projectname-v1.0.0.love |
```

## SNKRX v0.1.12 실제 결과 (검증된 워크플로)

| 메트릭 | 값 |
|---|---|
| **v0.1 ~ v0.1.14** | 14개 커밋 푸시 |
| **Release v0.1.12** | https://github.com/sigco3111/snkrx-clone/releases/tag/v0.1.12 |
| **Release asset 4개** | macOS 90M, Windows 4.5M, Linux 68M, .love 63M |
| **합계** | 226M |
| **빌드 시간** | `build_all.sh` 한 번 실행 = 5~10분 (love2d 다운로드 포함) |

## 즉시 적용 규칙

1. **`.love` 파일 우선**: 가장 단순한 형식. love2d 설치된 모든 OS 호환.
2. **macOS .app = Frameworks 10개 필수**: 가장 자주 빠뜨림 → `dyld: Library not loaded` 에러
3. **Windows zip = `unzip -o` 필수**: interactive prompt 방지
4. **GitHub Release = `gh release create`보다 `curl API`가 안정**: workflow scope 의존성 없음
5. **Asset 업로드 = `Content-Type: application/zip` 헤더 필수**: 415 에러 방지
6. **.gitignore `dist/`**: 대용량 빌드 결과물 제외
7. **README 다운로드 섹션 = 표 형식**: 플랫폼/파일/크기/설치 4컬럼
