# 한국어 시뮬레이션 End-to-End 검증 (test_kr_sim.py 패턴, 2026-07-14)

> 페르소나 시드 + 프롬프트 한국어화 + UI 한글화가 모두 끝난 뒤, **시뮬레이션 자체가 한국어로 정상 작동하는지** 통합 검증하는 패턴. `oss-fork-localization` Stage 5 (검증) 단계에서 사용.

## 적용 시점

- Stage 4 (UI) 완료 후
- 푸시 전 마지막 sanity check
- 또는 시뮬레이션 silent fail (fail-safe 반복 트리거) 시 진단

## 왜 별도 검증 도구가 필요한가

시뮬레이션 코드 (e.g. `reverie/backend_server/reverie.py`)는 인터랙티브 prompt 기반이라 **자동 실행이 어려움**. 대신 시뮬레이션의 핵심 인지 모듈(cognitive module) 함수들을 **직접 호출**해서 LLM 응답이 한국어로 자연스러운지 검증.

Django + reverie.py 양쪽 띄우는 무거운 검증보다 가볍고 빠름.

## 검증 대상 모듈 (예: generative_agents)

| 모듈 | 시뮬 역할 | 검증 의미 |
|------|----------|----------|
| `daily_planning` | 페르소나의 일일 계획 생성 | 한국어 일정이 자연스러운지 |
| `task_decomp` | 5분 단위 작업 분해 | 한국어 작업 분해가 자연스러운지 |
| `decide_to_talk` | 대화 시작 여부 결정 | 한국어 컨텍스트에서 yes/no 결정 |
| `agent_chat` | 실제 대화 생성 | 한국어 대화가 페르소나 특성을 반영하는지 |

## test_kr_sim.py 패턴

```python
"""
File: test_kr_sim.py (Phase 5 verification)
용도: Generative Agents 한국어 통합 검증 (시뮬레이션 1단계에 사용되는 핵심 함수들 직접 호출)
"""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from persona.prompt_template.gpt_structure import ChatGPT_request, generate_prompt

# 한국어 페르소나 시드 (실제 시뮬레이션에서 load될 whisper)
PERSONAS_KR = {
    "이서연": {
        "commonset": "이서연은 27세 도시계획 석사과정 학생이다. 호기심이 많고 외향적이며 세심하다.",
        "curr_time": "오전 9시",
        "current_action": "자전거를 타고 한강변을 지나고 있다",
        "location": "한강 자전거 코스 (여의도 구간)",
    },
    "김민준": {
        "commonset": "김민준은 28세 데이터 사이언스 석사과정 학생이다. 내향적이고 꼼꼼하며 창의적이다.",
        "curr_time": "오전 9시",
        "current_action": "도서관에서 공부하고 있다",
        "location": "오크힐 대학 도서관",
    },
}

def test_daily_planning(persona_name):
    inputs = [
        PERSONAS_KR[persona_name]["commonset"],
        PERSONAS_KR[persona_name]["curr_time"],
        "2026-05-10 Saturday",
        "초기 생활 시나리오",
    ]
    prompt = generate_prompt(inputs, "persona/prompt_template/v2/daily_planning_v6.txt")
    print(f"[{persona_name}] === daily_planning ===")
    print(f"프롬프트 미리보기: {prompt[:150]}...")
    response = ChatGPT_request(prompt)
    print(f"응답:\n{response}\n")
    return response

def test_task_decomp(persona_name, task):
    inputs = [
        PERSONAS_KR[persona_name]["commonset"],
        f"{persona_name}는 오전에는 공부할 계획이고, 오후에는 동호회 모임에 참석할 계획입니다.",
        persona_name, persona_name, task,
        "09:00 ~ 12:00", "180", persona_name,
    ]
    prompt = generate_prompt(inputs, "persona/prompt_template/v2/task_decomp_v3.txt")
    print(f"[{persona_name}] === task_decomp ===")
    response = ChatGPT_request(prompt)
    print(f"응답:\n{response}\n")
    return response

def test_decide_to_talk(p1_name, p2_name):
    p1 = PERSONAS_KR[p1_name]["commonset"]
    p2 = PERSONAS_KR[p2_name]["commonset"]
    inputs = [
        f"{p1_name}은 {p1}. {p2_name}은 {p2}.",
        "오전 9시 30분", p1_name, p2_name, "오전 9시",
        "자전거 코스", f"{p1_name}이(가) 도서관으로 가는 중",
        f"{p2_name}이(가) 같은 도서관에 있다", p1_name, p2_name,
    ]
    prompt = generate_prompt(inputs, "persona/prompt_template/v2/decide_to_talk_v2.txt")
    print(f"[{p1_name} → {p2_name}] === decide_to_talk ===")
    response = ChatGPT_request(prompt)
    print(f"응답: {response[:200]}\n")
    return response

def test_agent_chat(p1_name, p2_name):
    inputs = [
        f"{p1_name}이(가) {p2_name}에게 말하기 시작한다.",
        f"{p1_name}은 {PERSONAS_KR[p1_name]['commonset']}",
        f"{p2_name}은 {PERSONAS_KR[p2_name]['commonset']}",
    ]
    prompt = generate_prompt(inputs, "persona/prompt_template/v3_ChatGPT/agent_chat_v1.txt")
    response = ChatGPT_request(
        prompt + "\n\n답변은 한국어로, 두 사람의 짧은 대화를 JSON으로 출력하세요. "
        "예: '[[\"이서연\", \"안녕!\"], [\"김민준\", \"안녕하세요!\"]]'"
    )
    print(f"[{p1_name} ↔ {p2_name}] === agent_chat ===\n{response}\n")
    return response

def main():
    print("=" * 70)
    print("🇰🇷 Generative Agents 한국어 시뮬레이션 통합 검증")
    print("=" * 70)
    test_daily_planning("이서연")
    test_daily_planning("김민준")
    test_task_decomp("이서연", "도시계획 논문 작성")
    test_task_decomp("김민준", "머신러닝 과제 작성")
    test_decide_to_talk("이서연", "김민준")
    test_agent_chat("이서연", "김민준")
    print("=" * 70)
    print("✅ 검증 완료")

if __name__ == "__main__":
    main()
```

## 실측 결과 (2026-07-14 generative_agents-kr)

실행 시간: ~90초 (4 모듈 × 평균 8-15초/호출)

### 1. daily_planning (김민준)

```
08:00 - 기상·세면·스트레칭·아침 루틴
08:30 - 09:00 | 오늘 할 일 정리 (To‑Do 리스트 작성, 목표 설정)
09:00 - 10:00 | 한강 자전거 정비·장비 체크
10:00 - 12:00 | **한강 자전거 라이딩** (여의도 → 반포 → 잠원)
12:00 - 12:30 | 라이드 종료·샤워·간단 정리
12:30 - 13:30 | **점심** (한강 카페 근처 샐러드·쌀밥·주스)
13:30 - 17:30 | **알바 근무** (한강 카페)
17:30 - 18:00 | 근무 정리·정산·퇴근
18:00 - 18:30 | 가벼운 스낵·차 한 잔
18:30 - 20:00 | **데이터 사이언스 개인 프로젝트**
20:00 - 20:45 | 저녁 식사 (집에서 직접 만든 파스타·샐러드)
20:45 - 21:30 | **가벼운 독서** (인문·예술 서적)
21:30 - 22:30 | TV 시청 (다큐멘터리·예능) 혹은 **음악 감상**
22:30 - 23:00 | 취침 준비 (스트레칭·다음 날 일정 체크)
23:00 | **취침**
```

✅ 페르소나 특성 (자전거 동호회 + 한강 카페 알바) 자연스럽게 반영.

### 2. task_decomp (이서연, 머신러닝 과제)

| # | 작업 | 소요 | 남음 |
|---|------|-----|-----|
| 1 | 요구사항 검토 | 15분 | 165분 |
| 2 | 데이터 수집·정리 | 30분 | 135분 |
| 3 | 전처리·탐색적 분석 | 30분 | 105분 |
| ... | ... | ... | ... |

✅ 5분 단위 분해 + 한국어 자연스러움 + 합계 180분 일치.

### 3. decide_to_talk

답변: `[yes]` → 이서연이 김민준에게 대화 시작함.

### 4. agent_chat

```json
[
  ["이서연", "민준아, 요즘 데이터 분석 프로젝트는 어때?"],
  ["김민준", "음... 아직 모델링 단계라 좀 복잡하지만 재밌어."],
  ["이서연", "우리 이번 주말에 한강 자전거 타면서 얘기 좀 할까?"],
  ["김민준", "좋아! 타면서 도시계획 아이디어도 공유하고 말이야."],
  ["이서연", "내가 조사한 교통 흐름 데이터도 보여줄게."],
  ["김민준", "완전 기대된다. 서로 배울 점이 많겠네!"]
]
```

✅ 6회전 자연스러운 한국어 대화 + 두 사람의 직업/관심사 반영 + 격식/비격식 자연스럽게 섞임 + 한강 자전거 동호회 시나리오 등장.

## 검증 4축 (체크리스트)

1. **라우팅**: 영문 경로 → 한국어 프롬프트 자동 로드
2. **INPUT 치환**: `!<INPUT N>!` → 실제 값
3. **NIM 호출**: gpt-oss-120b 한국어 응답 생성
4. **자연스러운 한국어 출력**: 페르소나 특성 + 시나리오 + 조사 정확

## ⚠️ 함정 1: reasoning 모델 content=None (CRITICAL)

위 test_kr_sim.py 호출이 **빈 응답**으로만 나오면 → `gpt_structure.py`의 `_nim_chat`이 reasoning 모델을 처리 안 함. 즉시 검증:

```python
import os, urllib.request, json
body = json.dumps({"model": "openai/gpt-oss-120b",
                   "messages": [{"role": "user", "content": "ping"}],
                   "temperature": 0, "max_tokens": 50}).encode()
req = urllib.request.Request("https://integrate.api.nvidia.com/v1/chat/completions",
                              data=body, method="POST")
req.add_header("Authorization", f"Bearer {os.environ['NVIDIA_API_KEY_1']}")
req.add_header("Content-Type", "application/json")
resp = json.loads(urllib.request.urlopen(req, timeout=30).read())
print(resp["choices"][0]["message"])
# {'content': None, 'reasoning_content': '...'}  ← 즉시 확인 가능
```

→ 해결: `references/nim-llm-backend-swap.md` §함정 5 (`_nim_chat` 10줄 보강).

## ⚠️ 함정 2: 옛 prompt_template_kr 경로 참조

`test_kr_sim.py`에서 직접 path를 박을 때 `prompt_template/prompt_template_kr/` (중복) 경로가 자동으로 만들어진 경우가 있음. 확인:

```bash
find . -type d -name "prompt_template_kr"  # 2개 이상이면 중복
```

→ 옛 경로일 시 새 경로 (`prompt_template_kr/`)로 패치.

## ⚠️ 함정 3: 프롬프트 max_tokens

`task_decomp_v3.txt` 같은 큰 파일 응답은 `max_tokens=2048`로 부족할 수 있음. `gpt_structure.py`에서 `max_tokens=4096`으로 조정.

## ⏱️ 실행 시간 / 비용

| 호출 수 | 모듈 | 소요 | API 비용 (대략) |
|---------|-----|------|-----------------|
| 2 | daily_planning | ~30초 | $0.05 |
| 2 | task_decomp | ~40초 | $0.08 |
| 1 | decide_to_talk | ~10초 | $0.02 |
| 1 | agent_chat | ~15초 | $0.03 |
| **합계** | | **~90초** | **~$0.18** |

## 📂 추천 위치

```
<repo>/reverie/backend_server/
├─ test.py            # 원본 — 단일 LLM ping
└─ test_kr_sim.py     # ✅ 한국어 통합 검증 (위 패턴)
```

## 🔗 푸시 메시지 템플릿

```
feat: Phase 5 - 시뮬레이션 한국어 통합 검증 도구 + 결과

test_kr_sim.py 추가:
- daily_planning / task_decomp / decide_to_talk / agent_chat 4모듈 검증

검증 결과 (한국어 페르소나 3명 시나리오 '한강 자전거 동호회'):

이서연: '민준아, 요즘 데이터 분석 프로젝트는 어때?'
김민준: '음... 아직 모델링 단계라 좀 복잡하지만 재밌어.'
이서연: '우리 이번 주말에 한강 자전거 타면서 얘기 좀 할까?'
김민준: '좋아! 타면서 도시계획 아이디어도 공유하고 말이야.'

→ Phase 1-5 모두 완료. 한국어 시뮬레이션 기능 검증됨.
```

## 🔗 관련

- `references/django-ui-localization.md` — UI 한글화 (Stage 4)
- `references/prompt-auto-translation.md` — 프롬프트 자동번역 (Stage 3.5)
- `references/korean-persona-seed-pattern.md` — 페르소나 시드 (Stage 3)
- `references/nim-llm-backend-swap.md` — reasoning 모델 fix (CRITICAL)
