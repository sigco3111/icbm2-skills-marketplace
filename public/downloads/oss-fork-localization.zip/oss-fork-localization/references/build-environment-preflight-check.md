# 🛡️ C++ 게임 엔진 Fork — 빌드 환경 사전 검증

> 사용자가 "기대와 다르네" + 정리 요청한 사례 (wesnoth-kr 2026-07-20) 기반.
> **90분 투자 후 깨달음**: macOS M4에서 C++ 게임 엔진 빌드는 환경 호환성 문제로 거의 불가능. **빌드 검증은 시작 전 사전 확인이 핵심**.

## 언제 사용하나

이 워크플로의 **Stage 0 메타 결정 단계** 전에 반드시 실행:
- "C++ 게임 엔진 fork / 한글화 / 자동진행 추가" 요청
- 사용자가 "빌드까지 마무리해줘", "실행까지" 같은 표현을 쓸 때
- 새 게임 후보를 발견해서 fork 검토 중일 때

## 핵심 원칙: **빌드 가능성 = 환경 × 엔진 × 의존성**

3가지 축의 호환성을 시작 전에 확인하지 않으면 **90분+ 시간 낭비** 가능.

```
        macOS M4 + Apple Clang 21
                    ✕
        Boost 1.83 가정 (Wesnoth 1.18, SDL3 등)
                    ✕
        C++ 게임 엔진 빌드
                    ✕
        = 90분 시간 낭비
```

## 사전 검증 5단계 (5분이면 끝)

### 1단계: 언어/빌드 도구 확인 (1분)

```bash
# 컴파일러
clang++ --version
# Apple clang version 21.0.0

# 빌드 도구
scons --version  # 또는 cmake --version
which ninja

# Python (PEP 668 환경)
python3 --version
python3 -m pip --version
```

**판별**:
- Apple Clang 19+ → Boost 1.83 이하 호환성 문제 가능성 ↑ (함정 A)
- scons 4.0+ → 옵션 명세 다름 (`cxx_std=20` 숫자만)
- Python 3.9 시스템 Python → pip 외부 관리 환경

### 2단계: 의존성 설치 가능성 (1분)

```bash
brew install --quiet sdl3 sdl3_image sdl3_mixer sdl3_ttf \
                     pango libvorbis theora opusfile openssl@3 readline lua boost pkg-config
```

**판별**:
- `theora` (이전 이름 `libtheora`) — brew formula 이름 변경
- `boost@1.83` 직접 설치는 formula 없을 가능성 ↑ (보통 latest 1.90만)
- SDL2 vs SDL3 — 게임이 어느 쪽 요구하는지 grep으로 확인

### 3단계: upstream 코드 헤더 검사 (2분)

```bash
TMPDIR=/tmp/check-build-$RANDOM
git clone --depth 1 --filter=blob:none --sparse <repo> "$TMPDIR"
cd "$TMPDIR"
git sparse-checkout set src SConstruct

# Boost variant 사용 확인 (함정 A 핵심)
grep -rn "static_visitor\|apply_visitor" src/ 2>&1 | head -3
# → match 있으면 Boost 1.83 이하 가정 (macOS 1.90과 비호환 가능성 ↑)

# cxx_std 옵션 enum 확인 (함정 B)
grep -A 3 "choices.*cxx_std\|choices=\['17'" SConstruct 2>&1
# → ['17', '20'] 형태면 숫자만 받음 (c++20 에러)

# SDL2 vs SDL3
grep -rn "SDL3_image/SDL_image.h\|SDL2/SDL_image.h" src/build_info.cpp 2>&1
# → SDL3_image → sdl3_image brew 필요
# → SDL2/SDL_image → sdl2_image brew 필요

# 서브모듈 확인
ls src/modules/ 2>&1  # lua, mariadbpp 등
# → 비어있으면 git submodule update --init --recursive 필요
```

### 4단계: 이전 fork/PR 시그널 (1분)

```bash
# PR이 받아졌는지 (이전 fork의 성공/실패 이력)
gh search prs "is:open <repo>" --json title,state | head -5
# 또는 GitHub web 검색: "is:pr <repo> korean OR korea OR translate"

# 라이선스
gh repo view <repo> --json licenseInfo
# → GPL-2.0 fork면 GPL 강제, AGPL-3.0이면 SaaS 망함
```

### 5단계: 정리 + 보고 (30초)

```bash
# 분석 끝난 임시 디렉토리 정리
rm -rf "$TMPDIR"
```

## 판별 매트릭스 (요약)

| 환경 | macOS M4 | Linux CI | Windows |
|---|---|---|---|
| Boost 1.83 이하 호환 | ❌ (1.90 homebrew) | ✅ (apt 1.83) | ⚠️ (vcpkg) |
| SDL3 brew 패키지 | ✅ | ✅ (apt) | ⚠️ (msys2) |
| scons 4.x 옵션 | ✅ (enum 확인 필요) | ✅ | ⚠️ |
| pthread | ❌ (Apple Clang 한계) | ✅ | ✅ |
| **권장** | **CI로 위임** | **빌드 환경** | **WSL2 권장** |

## ⭐ 사용자 의사결정 가이드 (2026-07-20 학습)

사용자가 "이 게임 한글화하고 실행까지 해줘" 같은 요청을 하면:

**먼저 확인해야 할 3가지** (사용자에게 직접):

1. **빌드 환경**: 로컬 macOS에서 실행할 바이너리가 필요한가, GitHub Actions로 받은 산출물로 충분한가?
2. **실행 환경**: M4 Mac, Intel Mac, Linux PC, Windows? (각각 빌드 명령 다름)
3. **검증 깊이**: 코드 PR 수준의 컴파일 검증? 실제 게임 플레이 검증? 한글/기능 동작 검증?

**권장 분기**:

```
사용자 응답 분기
├─ "GitHub Actions로 충분" → macos-15 runner workflow 추가 (5분, 확실)
├─ "로컬 빌드 원함" → 환경 점검 후 가능 여부 보고 → 빌드 or 보류 결정
├─ "검증은 코드만" → 컴파일 sanity check (Linux CI) + PO/patch 검수만
└─ "직접 빌드 가능" → 사용자가 환경 책임지고 빌드 → 패치/번역만 제공
```

## 4-옵션 응답 패턴 (위임 시 절대 금지)

사용자가 "위임할게" 또는 "맞아, 진행해" 식의 위임 신호를 보냈을 때:

**❌ 절대 금지**:
```
A. GitHub Actions로 자동 빌드
B. Boost 1.83 별도 설치
C. callable_objects.cpp 직접 패치
D. 우선순위 변경

어떤 옵션?
```

**✅ 권장**:
```
옵션 A로 진행할게요. 이유:
- macOS 빌드는 Boost 1.90 비호환 + pthread Apple Clang 한계로 90분+ 시간 소요
- GitHub Actions의 macos-15 runner는 5분이면 M4 네이티브 산출물
- 90분 투자 대비 확실성 5배

이 방향 OK?
```

**위임 모드 = "내가 알아서 결정해줘" 모드**. 결정 권한을 다시 사용자에게 넘기지 말 것 (oss-fork-localization §14 참조).

## 90분 투자 회수 패턴 (실측)

wesnoth-kr 2026-07-20에서 90분 투자 후 깨달은 교훈:

| 시점 | 진행률 | 누적 시간 | 핵심 발견 |
|---|---|---|---|
| 시작 | 90.7% (원본) | 0 | |
| master + Boost 1.90 시도 | - | 5분 | Boost API 변경 (함정 A) |
| 1.18 + Boost 1.90 시도 | - | 30분 | pthread 인식 실패 |
| pthread 환경변수 | - | 35분 | Apple Clang 한계 |
| Boost 1.83 빌드 | - | 42분 | 빌드 성공 (17,378 targets) |
| Wesnoth + Boost 1.83 | - | 50분 | rpath 문제 (headerpad 부족) |
| install_name_tool 시도 | - | 90분 | 시간 낭비, 사용자가 정리 요청 |
| **사용자 결정** | - | - | **GitHub Actions (macos-15) 위임** |
| **순 효과** | 97.0% (6.3%p ↑) | + 텍스트 작업 | **빌드 무관 가치 추가** |

**교훈**: C++ 게임 엔진 fork에서 **빌드 검증은 5분 사전 확인 → 90분 낭비 or 5분 셋업** 결정.

## 정리 워크플로 (사용자 "정리해줘" 요청 시)

### 단계 1: GitHub 저장소
```bash
# gh auth refresh로 delete_repo scope 추가 시도
gh auth refresh -h github.com -s delete_repo
# → 브라우저 인증 필요 (timeout 가능)

# 대안: API 직접 호출 (사용자가 토큰 제공 시)
# 또는 사용자 직접 삭제 가이드:
# GitHub → Repository → Settings → Danger Zone → Delete this repository
```

### 단계 2: 로컬 디렉토리
```bash
# 프로젝트 디렉토리 (수십 MB)
rm -rf /Users/mac/work/{project}-kr

# 임시 sparse clone (1GB+)
rm -rf /tmp/wesnoth-probe /tmp/check-build-*

# Boost 소스 (1.2GB)
rm -rf ~/work/boost-build

# 빌드 산출물 (수 MB)
rm -rf upstream/{build,build-release}
```

### 단계 3: /tmp 임시 파일
```bash
# 빌드 로그
rm -f /tmp/wesnoth-build.log

# 임시 패치
rm -f /tmp/playsingle_*.patch

# 임시 분석 JSON
rm -f /tmp/{tips,empty,remaining}-*.{json,txt}
```

### 단계 4: 검증
```bash
# 프로젝트 흔적 0건 확인
find / -maxdepth 4 -name "*{project-name}*" 2>/dev/null | grep -v ".git/" | head
# → 비어있으면 OK

# 디스크 회수 확인
df -h ~/work /tmp
# → 2.3GB 회수 확인
```

### 단계 5: brew 패키지 결정
```bash
# Wesnoth 빌드용으로만 설치된 패키지:
# sdl2_image, sdl2_mixer, sdl2_ttf, sdl2-compat
# sdl3_image, sdl3_mixer, sdl3_ttf
# pango, cairo, libvorbis, theora, opusfile, readline
# pkg-config, scons (별도 위치)

# 다른 프로젝트와 공용 가능성 → 그대로 둠
# 단, 명확히 Wesnoth 전용이면 uninstall:
brew uninstall sdl2-compat sdl3_image sdl3_mixer sdl3_ttf libvorbis theora opusfile readline
```

## 검증 체크리스트 (사전 확인 완료 후)

- [ ] 1단계: 컴파일러/빌드도구/Python 버전 확인됨
- [ ] 2단계: brew 의존성 설치 가능 (theora 등 이름 변경 확인)
- [ ] 3단계: upstream 코드에서 `static_visitor` 등 Boost 1.83 가정 흔적 확인됨
- [ ] 4단계: cxx_std enum ['17', '20'] 형식 확인됨
- [ ] 5단계: SDL2/SDL3 헤더 요구 확인됨
- [ ] 6단계: 서브모듈 목록 (lua, mariadbpp 등) 확인됨
- [ ] 7단계: 라이선스 호환성 확인됨 (GPL-2.0 fork = GPL 강제 인지)
- [ ] 8단계: 이전 fork/PR 이력 확인됨 (실패 이력 + 학습 자료)
- [ ] 9단계: 사용자 의사결정 가이드 3가지 (빌드 환경/실행 환경/검증 깊이) 질문됨
- [ ] 10단계: 4-옵션 응답 금지 규칙 적용 (위임 시 단일 권장 옵션 제시)

## 관련 함정

- `oss-fork-localization` §함정 A: Boost 1.90 비호환
- `oss-fork-localization` §함정 J: PO 빈 entry 카운트 3가지
- `oss-fork-localization` §함정 L: 빌드 검증 보류 시 텍스트 작업 우선
- `oss-fork-localization` §14: 사용자 위임 선호 신호
- `oss-fork-localization` §15: 4-옵션 응답 금지
- `oss-fork-localization` §16: write_file path literal 함정

## 학습 기록

- **2026-07-20**: wesnoth-kr 90분 빌드 투자 후 사용자가 "내 기대와 다르네" + 정리 요청. 5분 사전 확인으로 90분 낭비 방지 가능.
- **2026-07-20**: macOS M4 + C++ 게임 엔진 = 환경 호환성 함정 다발. Linux CI (macos-15 GitHub Actions runner)가 정답.
- **2026-07-20**: 2.3GB 회수 완료 (프로젝트 50MB + Boost 소스 1.2GB + 임시 sparse clone 1.1GB).

## ⚠️ iOS 전용 분기 함정 (NEW, 2026-07-20, freeors/War-Of-Kingdom 실측)

자체 엔진(librose/kingdom)을 가진 게임을 macOS 데스크톱으로 컨버팅할 때 **가장 큰 함정 = iOS 전용 분기**.

**실측 결과 (freeors/War-Of-Kingdom)**:
- **librose: 197 cpp + 236 hpp** (자체 엔진)
- **kingdom: 239 cpp + 187 hpp** (게임 로직)
- **iOS 전용 분기: 65곳** (`#if TARGET_OS_IPHONE`, `#if __APPLE__`, `#if TARGET_OS_MAC`)
- **iOS 전용 파일: 30개**
- **Boost 헤더 사용: 2,580곳** (`boost/intrusive_ptr`, `boost/foreach`, `boost/numeric/...` 등)
- **SDL 헤더: 6종** (SDL_events, SDL_image, SDL_timer, SDL_video 등)
- **자산: 605MB**
- **빌드 시스템: iOS Xcode만 있음** (VC는 Windows, Xcode-iOS는 iOS, macOS 데스크톱 .xcodeproj 없음)
- **iOS 빌드 스크립트 경로**: `/Users/ancientcc/...` — macOS 빌드 이력은 있으나 iOS만

**판별 기준 (iOS 전용 분기 위험도)**:
| 위험도 | iOS 분기 수 | 작업 시간 |
|---|---|---|
| 🟢 낮음 | 0~10곳 | 1~3일 |
| 🟡 중간 | 10~30곳 | 3~7일 |
| 🟠 높음 | 30~50곳 | 1~2주 |
| 🔴 매우 높음 | 50+곳 | 2주+ 또는 포기 |

**검사 명령 (5분 사전 확인)**:
```bash
# 1. iOS 전용 분기 개수
grep -r "TARGET_OS_IPHONE\|__APPLE_CC__\|TARGET_OS_MAC" src/ | wc -l

# 2. iOS 전용 파일
grep -rl "TARGET_OS_IPHONE\|#import <UIKit" src/

# 3. Objective-C++ (.m/.mm) 사용
find src/ -name "*.m" -o -name "*.mm" | wc -l

# 4. 자체 엔진 / 외부 라이브러리
find src/ -name "*.cpp" | wc -l
```

**결론**:
- iOS 전용 분기 **30곳+** = **2주+ 작업 + 30~50% 성공률** (Wesnoth 패턴 반복)
- 60곳+ = **포기 권장** (다른 후보 검색)
- iOS 빌드만 가능 / macOS 데스크톱 .xcodeproj 없음 = **macOS 직접 빌드 안 됨, 100% 신규 프로젝트**

**macOS 데스크톱 컨버팅 시간 추정 (freeors/War-Of-Kingdom 같은 경우)**:
| 단계 | 내용 | 시간 |
|---|---|---|
| 1. 환경 구축 | Boost 1.83 + SDL2 2.0.4 빌드, librose 의존성 | 2~4시간 |
| 2. macOS Xcode 프로젝트 생성 | iOS Xcode 기반 → macOS 타겟 추가 | 2~4시간 |
| 3. iOS 분기 정리 | 65곳 iOS/macOS 분기 (UIKit → Cocoa 등) | 1~3일 |
| 4. 컴파일 에러 수정 | SDL2/Boost API 변경 대응 | 1~3일 |
| 5. 디버깅 + 테스트 | 런타임 크래시, GPU 렌더링 이슈 | 2~5일 |
| 6. 한국어화 | gettext .po 번역 (4,000+ string) | 1~2주 |
| **합계** | | **2~3주** (풀타임) |
| **성공률** | Wesnoth 교훈 적용 후 | 30~50% |
