# OSS Fork 한국어화 — 종료 절차 + 한계 진단

> TripleA 3차/4차 (2026-07-28) 실측. **사용자 거절 신호 신드롬**: "이 정도는 한글화라고 할 수 없음" → chrome-only 한국어화는 가짜 가치가 됨. **이런 발견을 언제 terminate로 연결할지, 어떻게 정리할지**.

## 1. 세 가지 구조적 한계 (chrome-only 한국어화가 가짜 가치인 이유)

TripleA fork 경험을 통해 도출된 **한국어 localization이 hollow해지는 3가지 원인**:

### 한계 1: 화면 번역 OK, 콘텐츠 번역 불가

```
fork가 닿는 영역:           외부에서 오는 영역:
┌─────────────────────┐    ┌─────────────────────┐
│ Swing UI 다이얼로그   │    │ 게임 안의 string      │
│ JMenu, JButton, JLabel │    │ 국가명, 유닛명, 영토명 │
│ JOptionPane msg/title │    │ (XML, 별도 저장소)   │
│  → 한국어 OK           │    │  → 한국어 X          │
└─────────────────────┘    └─────────────────────┘
       UI chrome                  콘텐츠
```

**TripleA fork가 chrome-only 완료에 그친 이유**: 국가명/유닛명/영토명은 `triplea-maps/*` 별도 GitHub 조직에서 옴. 이 저장소들은 dozens of map makers가 관리. 한국어 TripleA를 만들려면:
- 모든 맵 XML을 번역 (수십 개 저장소, 맵당 ~200+ gamer)
- 또는 런타임 맵 string wrapper (TripleA는 지원 안 함 — 큰 업스트림 작업)

어느 쪽도 fork 한 명이 결정할 수 없는 업스트림 + 커뮤니티 협업 작업.

### 한계 2: 게임 본문은 Java 직렬화되어 있음

```
delegate 75개 startEvent("X attacks with Y")
    ↓
HistoryNode.title = "X attacks with Y"
    ↓
Java 직렬화 → game.save 파일에 그대로 박힘
    ↓
Network: ChatMessage/Sound에도 같은 stream
```

`AGENTS.md` 명시:
> **Save-game compatibility**: Do NOT rename or delete private fields of classes extending `GameDataComponent`. Game saves use Java serialization.
> **Network compatibility**: Methods annotated `@RemoteActionCode` ... API signatures must not change.

이 string을 한국어 properties로 바꾸면:
- 새 게임은 한국어 → HistoryNode.title = "X가 Y로 공격"
- 옛 세이브 로드 시 → title = "X attacks with Y" (그대로 영어)
- 두 string이 HistoryLog의 `title.equals("Initializing Delegates")`, `title.matches("\\w+ win")` 매칭을 **양쪽 모두 깨뜨림**
- Java Properties getText() fallback이 EN 기반이라 사용자 보기에 silent하게 깨짐

### 한계 3: Discovery phase 과대평가

```
공식 docs: "TripleA = 12,628 strings"
실측: ~121 strings (Swing 위젯 literal) 만 i18n 가능
      = 잠재량 vs 실측 가능량 1%
```

`docs/development/i18n_languages.md`가 "12,628 strings" 라고 명시하지만 그건 잠재 string 수 (전체 Java String literals + properties + format 자리). 이 중:
- 이미 properties 있음: ~59 (1차 후)
- 신규 i18n 가능 (Swing widget literal → getText() 치환): ~121
- 절대 못 건드림 (delegate startEvent): ~75
- i18n 대상이 아닌 string (로그, exception, 주석): ~12,000

**4차 session PR 가치를 정확히 수치화**: 506 keys → 12,628 잠재 = 4%. **공식 5% 목표보다 낮음**.

## 2. 사용자 거절 신호 → terminate 결정 트리거

다음 신호 중 **하나라도** 발생하면 가짜 가치 의심:

| 신호 | 의미 | 다음 행동 |
|---|---|---|
| "이 정도는 한글화라고 할 수 없음" | chrome-only 결과가 사용자가 원한 가치와 다름 | terminate 결정 |
| "PR은 포기" | upstream 통합 가치 부재 | fork-first 결정, 로컬 완료 |
| "리드미에 정확한 상황을 기록" | 솔직한 종료 보고서 선호 | 한국어 README + kill notice |
| "프로젝트를 마무리하자" | 명시적 종료 선언 | terminate 절차 즉시 시작 |

**판별**: **이번 session에 한 번이라도 거절 신호가 떴으면** 다음 턴 응답에 terminate 후보를 제안해야 함. 무시하고 계속 작업하는 건 사용자의 인내심만 소모.

## 3. terminate 절차 (TripleA 4차 session 실측)

```bash
# 1. 솔직한 한국어 README 작성 (영문 X)
#    - 사실: 얼마나 한국어화됐는지 (chrome-only)
#    - 사실: 왜 100%가 불가능한지 (3가지 한계)
#    - 사실: 무엇을 했고 안 했는지 (의도적으로)
#    - 사실: 빌드 상태, 미커밋 처리
#    - 사실: upstream 라이선스, 원본 프로젝트 링크

# 2. README.md를 working tree 맨 꼭대기에 위치
git add README.md

# 3. 모든 3차 작업 코드 + properties + README 함께 커밋 (분할 X)
git commit -m "i18n: Korean localization extension (lobby UI + HistoryLog + misc gaps)

Adds ~85 new keys to ui_ko.properties covering:
- TripleAFrame dialog body strings
- 5 lobby login/account/email/password panels
- FindTerritoryAction, EndTurnPanel, BattleCalculatorPanel,
  ClientModel, SoundOptions, LanchesterDebugAction
- HistoryLog dialog

Total ui_ko.properties: 457 keys (chrome-only, see README).

Also updates README.md to a Korean-language kill notice explaining
why this fork is discontinued: map XML strings live in external
triplea-maps/* repositories, and the HistoryNode.title field used
for in-game history logs is serialized into save games and the
network protocol, so translating them would break save compatibility
and online play."

# 4. 푸시 (CRITICAL — 누락 시 GitHub에 영문 README 남음)
git push origin main

# 5. GitHub UI에서 README가 한국어로 표시되는지 확인
gh repo view sigco3111/triplea-kr --web
```

**4차 실제 실수**: 푸시 단계 누락 → "푸시 안했나? 깃허브 저장소에서는 아직 리드미가 영문으로 보이는데?" 사용자 짜증 받음. **terminate 절차에서 commit + push는 한 트랜잭션으로 묶을 것**.

## 4. 작업 중일 때 거절 신호 받은 워크플로

```
[사용자] "이 정도는 한글화라고 할 수 없음"
       ↓
[나] 즉시 작업 stop, 현 상태 정직 보고
    - chrome-only 결과물 설명
    - 한계 3가지 확인 (read_file로 증거)
       1. map XML = 외부 저장소 (curl raw.githubusercontent.com)
       2. HistoryNode 직렬화 = read save file structure
       3. 잠재량 vs 실측 가능량 = grep 카운트
    - terminate 옵션 3개 제시:
       A. 로컬 fork 완료 + 한국어 README (현재 상태)
       B. upstream PR 보냄 (낮은 품질, 작은 가치)
       C. 다른 게임 후보로 옮김
    - 사용자 결정 대기
       ↓
[사용자] "A. 한국어 README + 마무리하자"
       ↓
[나] terminate 절차 실행 (3-step)
```

**거절 신호 받기 전 미리**: 정기적으로 **잠재량 vs 실측 가능량을 보고**해 사용자가 거절 신호 없이도 chrome-only 한계를 인지하도록. 4차에서는 이걸 안 해서 사용자가 작업 끝에 거절.

## 5. 다음 워커가 같은 실수 안 하도록

**불변 사실 (3차/4차 검증)**:
- TripleA fork로 100% 한국어 TripleA 불가능
- chrome-only 한국어화는 가짜 가치 (사용자 거절)
- 그 외 다른 게임:
  - **JSON i18n 자원 보유** (Evolve, etc.) → fork 가치 높음
  - **Lua gettext 보유 SNKRX 류** → fork 가치 높음, 빠른 빌드
  - **Java Swing only (맵 데이터 외부)** → chrome-only trap — 시작 금지
  - **delegate 직렬화 트랩 보유** (TripleA) → chrome-only trap — 시작 금지

**시작 전 pre-flight 5축** (기존 `oss-fork-localization` SKILL.md의 5축)에 **6번째 축 추가**:

| 축 | 확인 방법 | chrome-only trap 신호 |
|---|---|---|
| 6. **콘텐츠가 외부 자원인가?** | `find . -name "*.properties" -path "*i18n*"` + `grep -r "tr(" --include="*.json\|*.xml"` | **i18n 자원이 0%면 chrome-only trap** — fork 가치를 재평가 |

## 6. SKILL.md 본문과의 관계

이 reference는 `oss-fork-localization` SKILL.md의 `🚀 핵심 함정` 섹션에 새로운 항목으로 인용되어야 함:

```markdown
### OSS Fork 한국어화 chrome-only 거절 신호 (2026-07-28, TripleA 4차) ★★★
- "이 정도는 한글화라고 할 수 없음" 사용자 거절 신호 = fork 가치 평가의 strong negative signal
- chrome-only (UI 외부피) 가짜 가치: 메뉴/다이얼로그만 번역, 게임 콘텐츠(국가/유닛/영토)는 English
- 3가지 한계: map XML 외부 저장소 / HistoryNode 직렬화 / 잠재량 vs 실측 가능량 1%
- terminate 절차: 솔직한 한국어 README + commit + push (한 트랜잭션)
- 4차 session의 실수: 푸시 단계 누락 → 영문 README 그대로 GitHub 노출 → 사용자 짜증
- reference: `references/oss-fork-terminate-conditions.md`
```

**reference**: `references/savegame-serialization-i18n-pitfall.md` (delegate startEvent 함정 상세), `references/java-swing-i18n-scaling.md` (잠재량 vs 실측 가능량).

## 7. TripleA 4차 session 패턴 (재현 방지)

**timeline**:
1. 1차~3차: 506 keys 한 줄씩 작업, 빌드 통과, 한국어 chrome 검증
2. 사용자가 보기: "이 정도는 한글화라고 할 수 없음" — 거절 신호
3. 솔직한 한국어 README 작성 (좋음)
4. **working tree에 19개 파일 변경 그대로 두었고 commit 안 함** (실수)
5. 사용자가 발견: "푸시 안했나? 깃허브 저장소에서는 아직 리드미가 영문으로 보이는데?"
6. 한꺼번에 commit + push (수정)

**재발 방지 패턴**:
- **사용자 지시 "푸시해줘"를 받기 전에 terminate 절차 끝까지 자동화**. terminate 결정 = git add + git commit + git push가 한 세트.
- README가 working tree에 있으면 **그 자체가 push-ready 마커**. 다음 응답에서 푸시까지 자동으로 진행.
- "마무리하자" = 코드 + README + commit + push = 4-step. 사용자가 "푸시 해줘"라고 말해야 다음 단계로 가는 건 살짝 게으른 동작.

## 8. 다음 세션에서 즉시 호출

다음 워커가 이 reference를 먼저 읽고:
```bash
# 1. 한국어화 가치 재평가 (chrome-only trap 신호)
grep -rE "find_skills|i18n|String literal" game-app --include="*.java" | wc -l
# + json/properties 언어 파일 존재 확인
# + map 데이터 외부 저장소 확인

# 2. 거절 신호 시 즉시 terminate 옵션 제시
# (사용자가 "이 정도는 한글화라고 할 수 없음" 등으로 가짜 가치 시사)

# 3. terminate 시 자동 절차
git add -A && git commit -m "..." && git push origin main
# (단계 분리 X — 한 트랜잭션)
```

## 9. TripleA 한국어화 작업의 4차 session 진짜 결과

| 항목 | 값 |
|---|---|
| 1차 시작 | 59 keys |
| 2차 | +363 keys (메뉴바 + 로비 + 인게임) |
| 3차 A | +9 keys (TripleAFrame 다이얼로그) |
| 3차 B | +38 keys (lobby 로그인 + 잔여) |
| 3차 C | +11 keys (HistoryLog) |
| 3차 G | +26 keys (누락분) |
| 4차 session 종료 시 | **~506 keys** in `ui_ko.properties` |
| chrome-only trap | 사용자 거절 |
| final commit | `8e8edc7` (1 commit, 4차 session 통합) |
| README | 한국어 종료 보고서 (`README.md`) |
| GitHub | `https://github.com/sigco3111/triplea-kr` |

**이게 진짜 끝**. 다른 게임 후보로 가려면 `oss-fork-localization` SKILL.md pre-flight 5축 + 이 reference의 한계 3가지로 시작.

## 10. 다른 fork 후보 pre-flight 6번째 축 (chrome-only trap 가드)

```bash
# 외부 콘텐츠 자원 검사 (mirror of SKILL.md pre-flight #6)
echo "=== 1. 맵/콘텐츠 XML 외부 의존 ==="
find . -name "*.xml" -path "*map*" | head -5
echo ""
echo "=== 2. 게임 본문 delegate 직렬화 검사 ==="
grep -rE "getText.*startEvent|writeValue.*String" game-app --include="*.java" | wc -l
echo ""
echo "=== 3. 잠재량 vs 실측 가능량 ==="
total=$(grep -rE '\"[A-Z][a-zA-Z ]{15,}\"' game-app --include="*.java" | wc -l)
i18n_ready=$(grep -rE 'I18nEngineFramework|getText\("' game-app --include="*.java" | wc -l)
echo "잠재 string: $total, 이미 i18n 캡슐화: $i18n_ready"
echo ""
echo "=== 4. i18n 자원 보유 여부 (JSON, .po, .properties) ==="
find . \( -name "*.po" -o -name "*.mo" -o -name "messages*.json" -o -name "lang*.json" -o -name "*.properties" -path "*i18n*" \) | wc -l
```

**판별**:
- i18n 자원 >= 5개 = ✅ i18n 인프라 있음
- i18n 자원 0-1개 + Java 직렬화 + XML 컨텐츠 = ❌ chrome-only trap — 시작 금지
- i18n 자원 0-1개 + JSON 데이터 + 런타임 교체 가능 = ⏸️ 사용자 명시 요청 시에만

## 11. verify (skip — cron mode)

이 reference는 작업 중 사용 — cron에서 자동 검증 X.
