# OpenAI → NIM Wrapper 변경 패턴

> Stanford generative_agents (Apache 2.0) 의 `gpt_structure.py` 를 NIM 으로 교체한 실전 사례.

## 호환 인터페이스 목록

원본 OpenAI wrapper 가 노출하는 함수 시그니처 (호출부에서 흔히 사용):

| 함수 | 용도 | 반환 |
|------|------|------|
| `ChatGPT_request(prompt)` | gpt-3.5-turbo 단건 | `str` |
| `ChatGPT_single_request(prompt)` | gpt-3.5-turbo 단건 (간단) | `str` |
| `GPT4_request(prompt)` | gpt-4 호출 | `str` |
| `GPT_request(prompt, gpt_parameter)` | 구 Completion API | `str` |
| `safe_generate_response(prompt, gpt_parameter, ...)` | 재시도 + JSON 파싱 | `str` |
| `ChatGPT_safe_generate_response(prompt, ...)` | 안전 모드 ChatGPT | `str` |
| `GPT4_safe_generate_response(prompt, ...)` | 안전 모드 GPT4 | `str` |
| `generate_prompt(curr_input, prompt_lib_file)` | 프롬프트 템플릿 슬롯 채우기 | `str` |
| `get_embedding(text, model="...")` | 임베딩 | `list[float]` |

→ 모든 시그니처는 **그대로 보존**. wrapper 만 교체.

## NIM 클라이언트 표준 패턴 (urllib.request, requests 의존성 0)

```python
import os, json, urllib.request, urllib.error, time

# utils.py 에서 환경변수 주입
nim_api_key = os.environ.get("NVIDIA_API_KEY", "")
NIM_BASE_URL = "https://integrate.api.nvidia.com/v1"
CHAT_MODEL = "openai/gpt-oss-120b"

def _nim_post(endpoint, body, timeout=120):
    url = f"{NIM_BASE_URL}{endpoint}"
    data = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(url, data=data, method="POST")
    req.add_header("Authorization", f"Bearer {nim_api_key}")
    req.add_header("Content-Type", "application/json")
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))

def _nim_chat(messages, model=CHAT_MODEL, temperature=0.7, max_tokens=2048):
    body = {
        "model": model, "messages": messages,
        "temperature": temperature, "max_tokens": max_tokens, "top_p": 1.0,
    }
    return _nim_post("/chat/completions", body)["choices"][0]["message"]["content"]
```

## 호환 wrapper 함수 (모두 보존)

```python
def ChatGPT_single_request(prompt):
    return _nim_chat([{"role": "user", "content": prompt}])

def ChatGPT_request(prompt):
    try:
        return _nim_chat([{"role": "user", "content": prompt}])
    except Exception as e:
        if debug: print(f"[ERROR] {e}")
        return "ChatGPT ERROR"

def GPT4_request(prompt):
    # gpt-oss-120b 가 gpt-4 대체 (high temp, max_tokens 증가)
    return _nim_chat(
        [{"role": "user", "content": prompt}],
        temperature=0.8, max_tokens=4096)

def _safe_generate(model_name, prompt, example_output, special_instruction,
                    repeat=3, fail_safe_response="error",
                    func_validate=None, func_clean_up=None, verbose=False):
    full_prompt = '"""\n' + prompt + '\n"""\n'
    full_prompt += f"Output the response to the prompt above in json. {special_instruction}\n"
    full_prompt += "Example output json:\n"
    full_prompt += '{"output": "' + str(example_output) + '"}'

    for i in range(repeat):
        try:
            response = (GPT4_request if model_name == "GPT4" else ChatGPT_request)(full_prompt).strip()
            end_index = response.rfind("}") + 1
            parsed = json.loads(response[:end_index])["output"]
            if func_validate and func_validate(parsed, prompt=full_prompt):
                return func_clean_up(parsed, prompt=full_prompt) if func_clean_up else parsed
        except Exception:
            continue
    return fail_safe_response

# 원본 GPT-3 (Completion) 호환 — chat 으로 우회
def GPT_request(prompt, gpt_parameter):
    try:
        return _nim_chat(
            [{"role": "user", "content": prompt}],
            temperature=gpt_parameter.get("temperature", 0.7),
            max_tokens=gpt_parameter.get("max_tokens", 100),
        )
    except: return "TOKEN LIMIT EXCEEDED"

def safe_generate_response(prompt, gpt_parameter, repeat=5, fail_safe_response="error",
                            func_validate=None, func_clean_up=None, verbose=False):
    for i in range(repeat):
        resp = GPT_request(prompt, gpt_parameter)
        if func_validate and func_validate(resp, prompt=prompt):
            return func_clean_up(resp, prompt=prompt) if func_clean_up else resp
    return fail_safe_response

def generate_prompt(curr_input, prompt_lib_file):
    """원본 generate_prompt() 와 완전 호환."""
    if isinstance(curr_input, str): curr_input = [curr_input]
    with open(prompt_lib_file, "r", encoding="utf-8") as f:
        prompt = f.read()
    for count, i in enumerate(curr_input):
        prompt = prompt.replace(f"!<INPUT {count}>!", i)
    if "<commentblockmarker>###</commentblockmarker>" in prompt:
        prompt = prompt.split("<commentblockmarker>###</commentblockmarker>")[1]
    return prompt.strip()
```

## 임베딩 (비대칭 분리)

```python
EMBED_MODEL = "nvidia/llama-nemotron-embed-1b-v2"

def _nim_embed(text, input_type):
    body = {"model": EMBED_MODEL, "input": [text], "input_type": input_type}
    return _nim_post("/embeddings", body)["data"][0]["embedding"]

def get_embedding(text, model=None):
    """원본 호환: input_type=passage 기본값."""
    return _nim_embed((text or "this is blank").replace("\n", " "), "passage")

def get_passage_embedding(text):
    """메모리 저장 시 사용."""
    return _nim_embed((text or "this is blank").replace("\n", " "), "passage")

def get_query_embedding(text):
    """메모리 검색 시 사용."""
    return _nim_embed((text or "this is blank").replace("\n", " "), "query")
```

## utils.py 패턴 (환경변수 + NIM 키)

```python
import os

# GitHub 시크릿 또는 ~/.hermes/secrets/{provider}_keys.env 에서
openai_api_key = os.environ.get("NVIDIA_API_KEY", "")
key_owner = os.environ.get("KEY_OWNER", "user-handle")

# 원본 경로 구조 유지
maze_assets_loc = "../../environment/frontend_server/static_dirs/assets"
env_matrix = f"{maze_assets_loc}/the_ville/matrix"
env_visuals = f"{maze_assets_loc}/the_ville/visuals"
fs_storage = "../../environment/frontend_server/storage"
fs_temp_storage = "../../environment/frontend_server/temp_storage"
collision_block_id = "32125"

debug = os.environ.get("DEBUG", "false").lower() == "true"

def config_check():
    if not openai_api_key:
        print("⚠️  NVIDIA_API_KEY 환경변수가 설정되지 않았습니다.")
        return False
    print(f"✅ NIM API 키 로드됨 (길이: {len(openai_api_key)}자)")
    return True
```

## .gitignore 패턴 (보안)

```gitignore
# 민감 정보 — 절대 추적 안함
reverie/backend_server/utils.py
frontend_server/settings/local.py
```

## 흔한 함정

### 1. 모델 ID prefix 누락

| 잘못된 ID | 올바른 ID |
|----------|----------|
| `gpt-oss-120b` | `openai/gpt-oss-120b` |
| `llama-3.1-70b-instruct` | `meta/llama-3.1-70b-instruct` |
| `gpt-4` | `openai/gpt-4` (또는 `gpt-oss-120b` 대체) |

→ `404 page not found` → prefix 추가.

### 2. `request.get_full_url()` 같은 requests API 사용 불가

`urllib.request` 환경에서는 `requests`가 설치되지 않을 수 있음. `urllib.request` 표준 라이브러리만 사용.

### 3. openai SDK 그대로 두고 client 교체

```python
# ❌ SDK 에 의존
import openai
openai.api_base = "https://integrate.api.nvidia.com/v1"
openai.Completion.create(...)

# ✅ 직접 HTTP (sync 가 깔끔)
import urllib.request
urllib.request.urlopen(...)
```

이유: `openai` SDK 가 설치되지 않은 환경에서 동작 보장.

### 4. UTF-8 인코딩 명시

NIM 응답 JSON 의 한글 안전성:
```python
json.loads(r.read().decode("utf-8"))  # ✅
json.loads(r.read())                  # ❌ (환경에 따라 깨질 수 있음)
```

### 5. reasoning 모델의 `content=None` 함정 (CRITICAL, 2026-07-14) ★

`openai/gpt-oss-120b`, `openai/o1*`, `openai/o3*`, `deepseek-r1` 같은 **reasoning 모델**은 응답을 `content` 필드가 아닌 별도 `reasoning_content` 필드에 출력합니다. 단순히 `choices[0].message.content`를 반환하면 **모든 호출이 빈 문자열/None**이 되어 시뮬레이션이 완전히 멈춥니다.

**증상**:
```python
result = ChatGPT_request("ping 한 단어만")
print(result)
# 출력: "" 또는 None  ← 호출은 200 OK지만 content 비어있음
```

**원인** (NIM 응답 실제 구조):
```json
{
  "choices": [{
    "message": {
      "content": null,
      "reasoning_content": "The user asks: \"ping\"... They want..."
    }
  }]
}
```

**해결** (`_nim_chat` 보강):
```python
def _nim_chat(messages, model=CHAT_MODEL, temperature=0.7, max_tokens=2048, top_p=1.0):
    body = {"model": model, "messages": messages,
            "temperature": temperature, "max_tokens": max_tokens, "top_p": top_p}
    resp = _nim_post("/chat/completions", body)
    msg = resp["choices"][0]["message"]

    content = msg.get("content") or ""
    if not content.strip():
        reasoning = msg.get("reasoning_content") or ""
        if reasoning.strip():
            import re as _re
            # 1) "<final>...</final>" 패턴 우선 시도
            m = _re.search(r"<final>(.*?)</final>", reasoning, _re.DOTALL)
            if m:
                content = m.group(1).strip()
            else:
                # 2) 마지막 줄 fallback
                lines = [l for l in reasoning.strip().split("\n") if l.strip()]
                last = lines[-1].strip().strip("`")
                if len(last) > max_tokens * 4:
                    content = (lines[-2].strip() if len(lines) > 1 else last)[:max_tokens * 3]
                else:
                    content = last
    return content
```

**판별 기준** (NIM 모델 카탈로그 응답 형식으로 확인 가능):
| 모델 ID | reasoning? |
|--------|-----------|
| `openai/gpt-oss-120b` | ✅ reasoning |
| `openai/o1-preview`, `o1-mini`, `o3-mini` | ✅ reasoning |
| `deepseek-ai/deepseek-r1` | ✅ reasoning |
| `meta/llama-3.1-70b-instruct` | ❌ 일반 |
| `meta/llama-3.3-70b-instruct` | ❌ 일반 |
| `mistralai/mistral-large-2-instruct` | ❌ 일반 |

**Push 전 필수 검증** — `[1] ChatGPT_single_request('ping')` self-test에서 빈 문자열이 나오면 reasoning 버그. fix 적용 후 'ping' 응답 확인 필수.

## 검증 (push 전)

```bash
export NVIDIA_API_KEY="nvapi-..."
cd reverie/backend_server/persona/prompt_template
python3 gpt_structure.py
```

기대 출력:
```
[1] ChatGPT_single_request('ping')     → 'ping'  ← 빈 문자열 ❌ 이면 reasoning 버그
[2] 차원: 2048, 유사도: 0.474
[3] 부정 가드 전: 0.457 → 후: 0.057
```

이 출력 3-row 가 보이면 push 가능. **[1]이 빈 문자열이면 reasoning 모델 — 위 함정 5 fix 적용 후 재검증.**
