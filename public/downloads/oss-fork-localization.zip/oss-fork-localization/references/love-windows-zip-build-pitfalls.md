# LÖVE 게임 Windows zip 빌드 4단계 함정 + 디버깅 (SNKRX 실측, 2026-07-21)

> SNKRX 한글화 fork에서 **Windows 사용자가 다운로드 → 더블클릭으로 실행**까지 4번의 시도 끝에 성공.
> 각 함정은 명확한 에러 메시지로 진단 가능. **이 순서대로 점검하면 30분 이내 해결**.

## 사용 시기

- LÖVE 게임 fork + 한글화 + 4플랫폼 배포 후 **Windows 사용자**가 실행 시도
- `run.bat 더블클릭` 시 에러 발생
- zip에 `run.bat` 또는 `love.exe`가 없는 듯
- `love.exe` 인식 못 함 또는 한글 깨짐

## 4단계 함정 + 해결 (실측 순서)

### 함정 1: zip에 `run.bat` 누락

**증상**: 사용자가 zip 압축 해제 후 폴더에 `love.exe`만 있고 `run.bat` 없음. cmd에서 수동으로 `love.exe game.love` 입력해야 함.

**원인**: 빌드 스크립트에서 `love-11.5-win64/` 폴더만 zip으로 묶음. `run.bat`는 같은 폴더에 있는데 zip 명령이 `run.bat`를 포함하지 않음.

**진단**:
```bash
unzip -l dist/snkrx-kr-windows-*.zip | grep -E "run.bat|love.exe|snkrx"
# -rw-r--r--  run.bat  ← 있어야 함
# -rwxr-xr-x  love-11.5-win64/love.exe  ← 반드시 있어야 함
```

**해결 — `run.bat` + `README.txt`를 명시적으로 zip에 포함**:
```bash
(cd "$WINDOWS_DIR" && zip -r "$DIST_DIR/snkrx-kr-windows-$VERSION.zip" love-11.5-win64/ run.bat README.txt -q)
```

**`run.bat` 표준 템플릿** (ASCII 전용, Windows CMD 호환):
```bat
@echo off
REM SNKRX Korean fork launcher (Windows)
cd /d "%~dp0"
cd love-11.5-win64
love.exe snkrx-kr-v0.1.12.love
if errorlevel 1 (
    echo.
    echo Game failed to start.
    echo Install Visual C++ 2013 Redistributable.
    echo Or run: lovec.exe snkrx-kr-v0.1.12.love
    pause
)
```

**핵심**: 
- `cd /d "%~dp0"` — batch 파일의 폴더로 이동 (Windows ANSI 코드페이지)
- `cd love-11.5-win64` — `love.exe`는 하위 폴더에 있음
- `love.exe snkrx-kr-v0.1.12.love` — 직접 호출

---

### 함정 2: `run.bat` 한글 깨짐

**증상** (실측 SNKRX):
```
'k'은(는) 내부 또는 외부 명령, 실행할 수 있는 프로그램, 또는
배치 파일이 아닙니다.
'0"'은(는) 내부 또는 외부 명령, 실행할 수 있는 프로그램, 또는
배치 파일이 아닙니다.
'krx-kr-v0.1.12.love'은(는) 내부 또는 외부 명령, 실행할 수 있는 프로그램, 또는
배치 파일이 아닙니다.
'el'은(는) 내부 또는 외부 명령, 실행할 수 있는 프로그램, 또는
배치 파일이 아닙니다.
'뚯엫'은(는) 내부 또는 외부 명령, 실행할 수 있는 프로그램, 또는
배치 파일이 아닙니다.
계속하려면 아무 키나 누르십시오 . . .
```

**원인**:
1. `run.bat`이 **UTF-8 한글**로 작성됨 (`# SNKRX 한국어화 fork 실행 스크립트 (Windows)` 같은 주석)
2. Windows CMD는 **기본 코드페이지 949 (한국어) 또는 437 (영문)** 환경
3. UTF-8 BOM 없음 + 한글 코드 → CMD가 멀티바이트를 잘못 파싱
4. `'k'`, `'0"'`, `'el'` 같은 깨진 ASCII 단편이 명령으로 실행 시도

**진단**:
```cmd
# 메모장으로 run.bat 열기 → "한글 표시 깨짐" → 이 함정 100%
```

**해결 — 순수 ASCII 전용** (한글 들어가지 마):
```bat
@echo off
REM SNKRX Korean fork launcher (Windows)  ← REM 주석도 ASCII
cd /d "%~dp0"
cd love-11.5-win64
love.exe snkrx-kr-v0.1.12.love
if errorlevel 1 (
    echo.
    echo Game failed to start.
    echo Install Visual C++ 2013 Redistributable.
    echo Or run: lovec.exe snkrx-kr-v0.1.12.love
    pause
)
```

**`README.txt`는 한글 가능** (사용자가 메모장으로 열면 자동 디코딩):
```
SNKRX Korean fork v0.1.12 (Windows)

[How to Run]
1. Double-click run.bat
2. Or: cd love-11.5-win64 && love.exe snkrx-kr-v0.1.12.love

[Troubleshooting]
- "Missing DLL": Install Visual C++ 2013 Redistributable
- Run with console: lovec.exe snkrx-kr-v0.1.12.love
```

**즉시 적용 규칙**:
- `.bat`/`.ps1`/`.sh` 같은 **스크립트 파일**은 **순수 ASCII**
- `README.txt`/`.md`는 **한글 OK** (메모장/VSCode가 자동 디코딩)
- 빌드 스크립트에서 `cat > file.bat <<EOF` heredoc 사용 시 **모든 주석/메시지 영문**

---

### 함정 3: `'love.exe'은(는) 내부 또는 외부 명령...` (PATH 문제)

**증상** (함정 2 해결 후):
```
'love.exe'은(는) 내부 또는 외부 명령, 실행할 수 있는 프로그램, 또는
배치 파일이 아닙니다.

Game failed to start.
Install Visual C++ 2013 Redistributable.
Or run: lovec.exe snkrx-kr-v0.1.12.love
계속하려면 아무 키나 누르십시오 . . .
```

**원인**:
- `run.bat`이 **zip 루트**에 있고
- `love.exe`는 **`love-11.5-win64/love.exe`** 하위 폴더에 있음
- zip 루트에서 `love.exe` 호출 시 PATH에 없어서 실패
- ASCII 메시지 ("Install Visual C++...")는 정상 출력 → 한글이 깨지지 않음 = 함정 2는 해결됨

**진단**:
```cmd
cd love-11.5-win64
dir love.exe
REM 있어야 함
```

**해결 — `cd love-11.5-win64` 추가**:
```bat
@echo off
cd /d "%~dp0"
cd love-11.5-win64        ← ★ 추가
love.exe snkrx-kr-v0.1.12.love
```

**대안** (zip 루트에 love.exe를 직접 복사):
```bash
cp dist/windows/love-11.5-win64/love.exe dist/windows/
# → zip 루트에 love.exe가 있어서 cd 불필요
# 단점: DLL이 옆에 없으면 못 찾음 → love-11.5-win64/love.exe가 안정
```

**즉시 적용 규칙**:
- `run.bat`은 **`love.exe`와 같은 폴더**에 두거나 `cd`로 이동
- `love-11.5-win64/` 폴더 구조 유지 + `cd` 명령으로 진입

---

### 함정 4: `.love` zip 인식 실패 (한글 Windows 경로)

**증상** (함정 3 해결 후):
```
Error
[love "boot.lua"]:330: Cannot load game at path 'C:/Users/신희정/Downloads/snkrx-kr-windows-v0.1.12/love-11.5-win64/snkrx-kr-v0.1.12.love'.
Make sure a folder exists at the specified path.
```

**원인**:
- Windows 사용자 이름이 한글 (예: `신희정`)
- `.love` 파일은 표준 zip 포맷이지만 **일부 love2d 버전 (11.5 Windows)**이 한글 경로에서 zip 파싱 실패
- love2d 11.5가 `dlopen`/zip 라이브러리에서 한글 코드페이지 인식 못 함

**진단**:
```cmd
REM 에러 메시지에 경로에 한글이 보임 → 경로 문제
REM 한글이 깨져 보이면 다른 인코딩 문제
```

**해결 — game/ 폴더 방식**:
```bash
# .love 압축 해제 → love-11.5-win64/game/ 에 풀기
GAME_DIR="$WINDOWS_DIR/love-11.5-win64/game"
rm -rf "$GAME_DIR"
mkdir -p "$GAME_DIR"
(cd "$GAME_DIR" && unzip -q -o "$LOVE_OUTPUT")

# run.bat: love.exe game
love.exe game
```

**또는 — `.love` + `game/` 둘 다 포함** (사용자 선택권):
```bash
# .love 파일도 같이 복사
cp "$LOVE_OUTPUT" "$WINDOWS_DIR/love-11.5-win64/"

# run.bat 자동 폴백
@echo off
cd /d "%~dp0"
cd love-11.5-win64
echo Starting SNKRX (folder mode)...
love.exe game
if errorlevel 1 (
    echo.
    echo Folder mode failed. Trying .love zip mode...
    love.exe snkrx-kr-v0.1.12.love
    if errorlevel 1 (
        echo.
        echo Both modes failed.
        echo Install Visual C++ 2013 Redistributable.
        echo Or run: lovec.exe game
        pause
    )
)
```

**즉시 적용 규칙**:
- **macOS zip → game/ 폴더만**: macOS는 한글 경로 거의 없어서 폴더 OK
- **Windows zip → game/ + .love 둘 다**: 한글 경로 안전 (폴더) + 영문 경로 호환 (.love)
- 사용자가 영문 경로 (예: `C:\games\`)면 .love 직접 사용, 한글 경로면 game/ 폴더 사용

---

## 종합 빌드 스크립트 (Windows zip)

```bash
#!/bin/bash
# Windows zip 빌드 (모든 함정 해결)
set -e
VERSION="${VERSION:-v0.1.12}"
DIST_DIR="$(cd "$(dirname "$0")/.." && pwd)/dist"
WINDOWS_DIR="$DIST_DIR/windows"

# 1. love2d Windows 다운로드 (첫 실행만)
if [ ! -f "$WINDOWS_DIR/love.exe" ]; then
    echo "love2d Windows 다운로드..."
    curl -L -o "$WINDOWS_DIR/love.zip" "https://github.com/love2d/love/releases/download/11.5/love-11.5-win64.zip"
    (cd "$WINDOWS_DIR" && unzip -q -o love.zip)  # -o 필수 (interactive prompt 방지)
    rm "$WINDOWS_DIR/love.zip"
fi

# 2. .love 파일을 game/ 폴더에 압축 해제 (한글 경로 우회)
GAME_DIR="$WINDOWS_DIR/love-11.5-win64/game"
rm -rf "$GAME_DIR"
mkdir -p "$GAME_DIR"
(cd "$GAME_DIR" && unzip -q -o "$DIST_DIR/snkrx-kr-$VERSION.love")

# 3. .love 파일도 복사 (영문 경로 사용자용 폴백)
cp "$DIST_DIR/snkrx-kr-$VERSION.love" "$WINDOWS_DIR/love-11.5-win64/"

# 4. run.bat 생성 (ASCII 전용, game/ 폴더 우선, .love 폴백)
cat > "$WINDOWS_DIR/run.bat" <<'BAT'
@echo off
REM SNKRX Korean fork launcher (Windows)
cd /d "%~dp0"
cd love-11.5-win64
echo Starting SNKRX (folder mode)...
love.exe game
if errorlevel 1 (
    echo.
    echo Folder mode failed. Trying .love zip mode...
    love.exe snkrx-kr-v0.1.12.love
    if errorlevel 1 (
        echo.
        echo Both modes failed.
        echo Install Visual C++ 2013 Redistributable.
        echo Or run: lovec.exe game
        pause
    )
)
BAT

# 5. README.txt (영문 + 한글 혼재 OK)
cat > "$WINDOWS_DIR/README.txt" <<'TXT'
SNKRX Korean fork v0.1.12 (Windows)

[How to Run]
1. Double-click run.bat
2. Or: cd love-11.5-win64 && love.exe game

[Troubleshooting]
- "Missing DLL": Install Visual C++ 2013 Redistributable
- Run with console: lovec.exe game

[Original] https://github.com/a327ex/SNKRX
[Fork] https://github.com/sigco3111/snkrx-clone
TXT

# 6. zip으로 묶기 (love-11.5-win64/ + run.bat + README.txt)
cd "$DIST_DIR"
rm -f "snkrx-kr-windows-$VERSION.zip"
zip -r "snkrx-kr-windows-$VERSION.zip" "windows/love-11.5-win64" "windows/run.bat" "windows/README.txt" -q
```

**`unzip -o`**: interactive prompt 방지. stdin 닫혀있으면 [N]one 자동이지만, hang 위험. `-o`로 명시적 overwrite.

---

## 종합 함정 체크리스트 (4개)

| # | 증상 | 원인 | 해결 |
|---|------|------|------|
| 1 | `run.bat` 없음 | zip 명령이 love-11.5-win64/만 묶음 | `zip -r ... love-11.5-win64/ run.bat README.txt -q` |
| 2 | `'k'은(는)...` 깨진 단편 에러 | `run.bat`이 UTF-8 한글 포함 | run.bat은 **순수 ASCII**만 |
| 3 | `'love.exe'은(는)...` (PATH 문제) | run.bat 루트, love.exe 하위 폴더 | `cd love-11.5-win64` 추가 |
| 4 | `Cannot load game at path '...'` | 한글 Windows 경로에서 .love zip 파싱 실패 | `game/` 폴더 방식 (.love zip 압축 해제) |

**사용자 디버깅 워크플로**:
1. 에러 메시지 캡처 (텍스트/스크린샷)
2. 위 4개 체크리스트와 대조
3. 1~4 순서로 patch → `run.bat` 파일 다시 첨부 → 사용자가 재실행

---

## 테스트 워크플로 (사용자 배포 전)

1. **macOS에서 zip 빌드**: `build_all.sh` 실행 → `dist/snkrx-kr-windows-v*.zip` 생성
2. **zip 내용 확인**:
   ```bash
   unzip -l dist/snkrx-kr-windows-*.zip | head -20
   # -rw-r--r--  run.bat          ← ★ 반드시 있어야 함
   # -rw-r--r--  README.txt        ← ★ 있어야 함
   # -rwxr-xr-x  love-11.5-win64/love.exe
   # -rwxr-xr-x  love-11.5-win64/*.dll
   # -rwxr-xr-x  love-11.5-win64/game/*  ← game/ 폴더
   # -rwxr-xr-x  love-11.5-win64/snkrx-kr-v*.love  ← .love 파일
   ```
3. **ASCII 검증**: `unzip -p dist/.../run.bat | cat -v` → 한글이 깨진 패턴 없어야 함
4. **GitHub Release 업로드**: `curl` + `Content-Type: application/zip` 헤더
5. **사용자 테스트**: 사용자에게 영문/한글 경로 둘 다 테스트 요청

---

## 즉시 적용 규칙 — LÖVE 게임 Windows zip 빌드 시

1. **`zip` 명령에 `love-11.5-win64/ run.bat README.txt` 3개 모두 명시** (run.bat 누락 방지)
2. **`run.bat`은 순수 ASCII**: `<<'BAT'` heredoc으로 따옴표 escape. `echo 한 줄` 한글 메시지 절대 금지
3. **`cd love-11.5-win64`** 또는 **love.exe zip 루트에 복사** (둘 중 하나)
4. **`game/` 폴더 + `.love` 파일 둘 다** 압축 → 한글/영문 경로 모두 호환
5. **`unzip -q -o`**: interactive prompt 방지
6. **GitHub Release 업로드 시** `Content-Type: application/zip` 헤더 필수

---

## 학습 기록

- **2026-07-21 (snkrx-clone Windows 배포)**: 4번의 시도 끝에 성공. 각 함정이 명확한 에러 메시지로 진단 가능했음.
- **2026-07-21**: 한글 깨짐 (UTF-8 vs CP949) → run.bat ASCII 전용이 가장 안전
- **2026-07-21**: `love.exe` PATH 문제 → `cd love-11.5-win64` 한 줄로 해결
- **2026-07-21**: `.love` zip 인식 실패 (한글 경로) → `game/` 폴더 방식이 가장 안전. `.love` 직접 호출은 영문 경로에서만
- **2026-07-21**: `unzip` interactive prompt → `-o` 플래그 필수 (CI/CD 자동화에서도)
- **2026-07-21**: 사용자가 ".love 파일을 .zip에 포함해주면 안되나?" 직접 요청 → `.love` + `game/` 둘 다 포함하는 패턴 채택
