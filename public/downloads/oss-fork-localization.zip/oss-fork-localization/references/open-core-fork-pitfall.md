# Open Core / 클로즈드소스 fork 함정 (2026-07-27, Athena Crisis 실측)

> **가장 비싼 함정입니다.** 한국어화 4시간 + Vercel 셋업 + 자동전투 AI까지 다 만들어놓고 **빌드가 안 됨을 마지막에 발견**. 이 패턴은 OSS 게임 fork에서 점점 흔해지고 있고, 첫 단계에서 잡지 않으면 큰 시간 낭비.

## 🪤 정확한 증상 (Athena Crisis 사례)

- 저장소: `nkzw-tech/athena-crisis`, MIT, ⭐ 1,967
- README, package.json, i18n 패키지, 모노레포 등 **모든 게 오픈소스로 보임**
- 한국어 (`ko_KR`) 번역 키도 i18n 패키지에 이미 등록
- 분산된 AI 클래스 4종도 `dionysus/` 워크스페이스에 존재
- **겉보기에는 fork 가능해 보임**
- 실제: `pnpm dev:client` (= ares 클라이언트 빌드)가 `art/Variants.nkzw.tsx` 부재로 실패
- `.gitignore` 추적: `ares/.enum_manifest.json`, `ares/.src_manifest.json`, `ares/src/generated/*`, `ares/vite.config.ts.timestamp-*` — **본체 산출물이 의도적으로 git에서 제외됨**
- **결론**: Open Core 정책 — 핵심 게임 본체는 비공개 저장소에만 존재

## 🩺 첫 단계 5분 preflight (가장 중요)

fork 작업 들어가기 **전**, 단 3가지만 확인:

```bash
# 1) .gitignore에서 핵심 산출물 제외 패턴 확인
gh repo view OWNER/REPO --json name,description
gh api repos/OWNER/REPO/contents/.gitignore --jq '.content' | base64 -d | grep -E "(generated|src_manifest|enum_manifest|timestamp-|__generated__|prisma-client)"

# 2) 빌드 매니페스트 실제 존재 확인
gh api repos/OWNER/REPO/contents/ares/vite.config.ts 2>&1
gh api repos/OWNER/REPO/contents/ares/src/index.html 2>&1
gh api repos/OWNER/REPO/contents/ares/src/main.tsx 2>&1

# 3) package.json scripts의 dev:client가 실제 어떤 파일 빌드하는지
gh api repos/OWNER/REPO/contents/package.json --jq '.content' | base64 -d | python3 -c "import json,sys; d=json.load(sys.stdin); [print(f'  {k}: {v}') for k,v in d.get('scripts',{}).items()]"
```

**판별 매트릭스**:

| 신호 | 판정 |
|---|---|
| `.gitignore`에 `ares/`, `src/generated/`, `__generated__`, `prisma-client`, `.src_manifest.json` 등 다수 | 🔴 **Open Core 가능성 ↑** — 빌드 안 될 수 있음 |
| `vite.config.ts`는 git에 있는데 `ares/src/main.tsx`가 없음 | 🔴 **본체 비공개** |
| 빌드 명령은 있는데 entry 파일 없음 | 🔴 **codegen 의존** (prepublish 단계 필요) |
| README에 "Open Core", "Enterprise", "Premium" 키워드 | 🔴 명시적 신호 |
| dev:server + dev:client 둘 다 있지만 dev:client만 막힘 | 🔴 **클라이언트만 비공개** (서버는 공개) |

## 🚪 빌드 검증 통과 기준 (5분 안에)

```bash
cd /tmp/probe && git clone --depth 1 https://github.com/OWNER/REPO.git
cd REPO && (pnpm install --ignore-scripts 2>/dev/null || npm install --ignore-scripts 2>/dev/null)
# 핵심 빌드 명령 실행 — exit 0 + dist/ 생성되어야 통과
pnpm dev:client 2>&1 | head -5 &  # 백그라운드, 5초 후 curl
sleep 5
curl -fsS http://localhost:3000 > /dev/null && echo "PASS" || echo "FAIL"
```

**5분 안에 PASS가 안 나오면 → 그 프로젝트는 fork 불가능한 상태일 가능성 ↑**

## 🧹 깨끗한 종료 워크플로 (4시간 낭비 회수)

빌드 통과 못 하면 **즉시 보존 자산 정리 + 종료**:

```bash
# 1) 의미 있는 자산은 보존 (다른 fork에 재사용 가능)
git log --diff-filter=A --name-only --pretty=format: | sort -u > preserved-files.txt

# 2) 임시 산출물 / 가짜 빌드 / dummy 파일 제거
rm -f art/Variants.nkzw.tsx  # 우리가 만든 더미
rm -f ares/vite.config.ts ares/index.html ares/src/main.tsx  # 가짜 빌드

# 3) README에 솔직한 한계 명시
cat >> README.md << 'EOF'
## ⚠️ 빌드 한계
이 fork는 [원본 저장소]의 [Open Core 정책 / 비공개 본체 소스] 때문에 
빌드 가능한 게임을 만들 수 없습니다. 번역 데이터와 한국어화 코드는 보존되어 
있으며 다른 프로젝트에 재사용 가능합니다.
EOF

# 4) 정리 commit + push
git add -A && git commit -m "docs: clarify fork limits and preserve reusable assets"
```

## 🔄 솔직한 한계 인정이 핵심

**사용자가 "전부 롤백" 선택했을 때의 교훈**:
- 의미 없는 가짜 빌드(빈 index.html + "한국어" 단어 1개 박기)는 **만들지 않음**
- 1,535개 한국어 번역 + 분기 로직은 **다른 fork에 재사용 가능한 진짜 자산** → 보존
- README에 한계 명시 = **신뢰 회복** (사용자가 "내 기대와 다르네" 정정을 안 함)

## 🔍 다른 프로젝트에서 Open Core 신호 찾는 법

```bash
# 상위 OSS 게임 저장소에서 흔한 Open Core 신호:
gh search repos "tower defense" --limit 30 --json name,description,stargazersCount
# 후보마다 위 5분 preflight 적용
```

**확인된 Open Core 게임 사례 (2026-07-27 기준)**:
- nkzw-tech/athena-crisis (MIT 겉보기, 실제 Open Core) — 4시간 낭비 후 종료

**Mindustry, Shattered Pixel Dungeon 등은 GPL-3.0이라도 본체 소스가 전부 공개** — 진짜 OSS. 라이선스 ≠ 본체 공개 여부.

## ⚠️ 즉시 적용 규칙

1. **첫 응답에서 "Open Core 가능성" 명시**: 후보 1순위 추천 시 .gitignore 1줄 확인 후 "본체 소스 확인됨" 또는 "Open Core 가능성 있음" 박기
2. **5분 preflight 통과 못 하면 다른 후보로**: 30분 이상 빌드 우회 시도 금지
3. **가짜 빌드 절대 금지**: `index.html` + "한국어" 단어 박아서 빌드 통과한 척하기 → 사용자 신뢰 손상
4. **자산 보존 후 종료**: 의미 있는 코드는 다른 fork에 재사용 가능, push는 그대로
5. **사용자 결정 존중**: "전부 롤백" 선택 시 즉시 정리 워크플로 + README 한계 명시
