#!/bin/bash
# build_macos.sh — LÖVE 게임 macOS .app 번들 빌드
# SNKRX v0.1.12 Release 검증 (2026-07-21)
#
# 사용법: ./build_macos.sh
# 출력: dist/<AppName>.app
#
# ⚠️ CRITICAL: /Applications/love.app 의 10개 .framework 번들 필수 복사
#    (Contents/Frameworks/*) — 빠뜨리면 dyld: Library not loaded 에러

set -e

VERSION="${VERSION:-v0.1.0}"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
DIST_DIR="$PROJECT_DIR"
SOURCE_LOVE="$DIST_DIR/${PROJECT_NAME}-${VERSION}.love"

# 자동 탐지: 프로젝트 이름 = 부모 디렉토리명
PROJECT_NAME="$(basename "$PROJECT_DIR")"
SOURCE_LOVE="$DIST_DIR/${PROJECT_NAME}-${VERSION}.love"
APP_NAME="${PROJECT_NAME}"
APP_BUNDLE="$DIST_DIR/$APP_NAME.app"
CONTENTS="$APP_BUNDLE/Contents"
MACOS_DIR="$CONTENTS/MacOS"
RESOURCES_DIR="$CONTENTS/Resources"

# Info.plist는 동일 디렉토리에 있어야 함
PLIST_SRC="$SCRIPT_DIR/Info.plist"
if [ ! -f "$PLIST_SRC" ]; then
    echo "❌ Info.plist not found: $PLIST_SRC"
    echo "   build_macos.sh와 같은 디렉토리에 Info.plist 배치 필요"
    exit 1
fi

# 1. 기존 번들 정리
rm -rf "$APP_BUNDLE"

# 2. .app 구조 생성
mkdir -p "$MACOS_DIR" "$RESOURCES_DIR"

# 3. love2d 실행 파일 복사
if [ ! -f "/Applications/love.app/Contents/MacOS/love" ]; then
    echo "❌ /Applications/love.app/Contents/MacOS/love not found"
    echo "   brew install --cask love 먼저 실행"
    exit 1
fi
cp "/Applications/love.app/Contents/MacOS/love" "$MACOS_DIR/love"
chmod +x "$MACOS_DIR/love"

# 3.5. ★ CRITICAL: love2d Frameworks 10개 복사 (의존성)
FRAMEWORKS_SRC="/Applications/love.app/Contents/Frameworks"
FRAMEWORKS_DST="$CONTENTS/Frameworks"
if [ -d "$FRAMEWORKS_SRC" ]; then
    mkdir -p "$FRAMEWORKS_DST"
    cp -R "$FRAMEWORKS_SRC"/* "$FRAMEWORKS_DST/"
    echo "✅ Frameworks 복사: $(ls "$FRAMEWORKS_DST" | wc -l)개"
else
    echo "❌ /Applications/love.app/Contents/Frameworks/ not found"
    exit 1
fi

# 4. Info.plist 복사
cp "$PLIST_SRC" "$CONTENTS/Info.plist"

# 5. .love 파일 복사
if [ ! -f "$SOURCE_LOVE" ]; then
    echo "❌ .love not found: $SOURCE_LOVE"
    echo "   먼저 build_love.sh 실행"
    exit 1
fi
cp "$SOURCE_LOVE" "$RESOURCES_DIR/game.love"

# 6. 아이콘 (선택)
if [ -f "/Applications/love.app/Contents/Resources/GameIcon.icns" ]; then
    cp "/Applications/love.app/Contents/Resources/GameIcon.icns" "$RESOURCES_DIR/GameIcon.icns"
fi

# 7. PkgInfo
echo -n "APPL????" > "$CONTENTS/PkgInfo"

echo "✅ Built: $APP_BUNDLE"
echo "📦 Size: $(du -sh "$APP_BUNDLE" | cut -f1)"
echo ""
echo "설치 방법:"
echo "  1. Finder에서 $APP_BUNDLE 더블클릭"
echo "  2. Applications로 드래그"
echo "  3. Launchpad에서 '$APP_NAME' 실행"
echo ""
echo "Gatekeeper 우회 (필요 시):"
echo "  xattr -dr com.apple.quarantine \"$APP_BUNDLE\""
