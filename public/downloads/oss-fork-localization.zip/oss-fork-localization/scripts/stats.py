#!/usr/bin/env python3
"""PO 파일 통계 + 카테고리 분포 출력.

번역 진행률, 빈 msgstr 개수, fuzzy 항목, 카테고리별 분포를 한눈에 보여줍니다.

사용법:
    python3 stats.py <po_file> [po_file2 ...]

출력 예시:
    📊 wesnoth-ko.patched.po
       전체: 1427
       번역됨: 1314 (92.1%)
       빈 msgstr: 113
       Fuzzy (재검수 필요): 331
       빈 카테고리 TOP 5:
         -   27 | src/addon
         -   10 | internal
         -    7 | src/gui
         -    6 | core/macros
         -    5 | core/editor
"""
import sys
import re
from collections import Counter
from pathlib import Path


def analyze(path: Path):
    entries = []
    current_file = None
    current_msgid = []
    current_msgstr = []
    state = 'header'
    fuzzy = False

    with open(path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.rstrip('\n')
            if line.startswith('#:'):
                current_file = line[2:].strip().split()[0] if line[2:].strip() else current_file
                continue
            if line.startswith('#, fuzzy'):
                fuzzy = True
                continue
            if line.startswith('msgid "'):
                if state == 'msgstr' and current_msgid:
                    entries.append({'file': current_file, 'msgid': ''.join(current_msgid), 'msgstr': ''.join(current_msgstr), 'fuzzy': fuzzy})
                m = re.match(r'msgid "(.*)"', line)
                if m:
                    current_msgid = [m.group(1)]; current_msgstr = []; state = 'msgid'; fuzzy = False
            elif line.startswith('msgstr "'):
                m = re.match(r'msgstr "(.*)"', line)
                if m:
                    current_msgstr = [m.group(1)]; state = 'msgstr'
            elif line.startswith('"') and state in ('msgid', 'msgstr'):
                m = re.match(r'"(.*)"', line)
                if m:
                    if state == 'msgid': current_msgid.append(m.group(1))
                    else: current_msgstr.append(m.group(1))

    if state == 'msgstr' and current_msgid:
        entries.append({'file': current_file, 'msgid': ''.join(current_msgid), 'msgstr': ''.join(current_msgstr), 'fuzzy': fuzzy})

    real = [e for e in entries if e['msgid']]
    total = len(real)
    empty = [e for e in real if not e['msgstr']]
    fuzzy_e = [e for e in real if e['fuzzy'] and e['msgstr']]
    translated = total - len(empty)

    print(f"📊 {path.name}")
    print(f"   전체: {total}")
    print(f"   번역됨: {translated} ({translated/total*100:.1f}%)" if total else "")
    print(f"   빈 msgstr: {len(empty)}")
    print(f"   Fuzzy (재검수 필요): {len(fuzzy_e)}")

    def cat(f):
        if not f:
            return 'unknown'
        if f.startswith('data/campaigns/'):
            parts = f.split('/')
            return f"campaigns/{parts[2]}" if len(parts) > 2 else 'campaigns'
        if f.startswith('data/core/'):
            parts = f.split('/')
            return f"core/{parts[2]}" if len(parts) > 2 else 'core'
        if f.startswith('data/'):
            return f.split('/')[1]
        if f.startswith('src/'):
            parts = f.split('/')
            return f"src/{parts[1]}" if len(parts) > 1 else 'src'
        return f.split('/')[0]

    print(f"   빈 카테고리 TOP 5:")
    c = Counter(cat(e['file']) for e in empty)
    for cat_name, cnt in c.most_common(5):
        print(f"     - {cnt:>3} | {cat_name}")


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: stats.py <po_file> [po_file2 ...]")
        sys.exit(1)
    for p in sys.argv[1:]:
        analyze(Path(p))
        print()