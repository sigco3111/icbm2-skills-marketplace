#!/usr/bin/env python3
"""
verify_lua_syntax.py — LÖVE/Lua 게임 표준 syntax 검증 스크립트

사용법:
    python3 scripts/verify_lua_syntax.py [project_dir]

project_dir 생략 시 현재 디렉토리 기준.
luac -p로 모든 .lua 파일 syntax 검증 + 빈 출력 파일 체크.
"""
import subprocess
import sys
from pathlib import Path

def find_lua_files(project_dir: Path) -> list[Path]:
    """모든 .lua 파일 찾기 (.git, node_modules 등 제외)"""
    exclude_dirs = {'.git', 'node_modules', 'builds', 'dist'}
    files = []
    for lua_file in project_dir.rglob('*.lua'):
        if not any(part in exclude_dirs for part in lua_file.parts):
            files.append(lua_file)
    return sorted(files)


def verify_syntax(lua_file: Path) -> tuple[bool, str]:
    """luac -p로 syntax 검증"""
    try:
        result = subprocess.run(
            ['luac', '-p', str(lua_file)],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode == 0:
            return True, 'OK'
        return False, result.stderr.strip().split('\n')[0]
    except FileNotFoundError:
        return False, 'luac not found (brew install lua)'
    except subprocess.TimeoutExpired:
        return False, 'timeout'


def main():
    project_dir = Path(sys.argv[1]) if len(sys.argv) > 1 else Path.cwd()
    if not project_dir.exists():
        print(f"Error: {project_dir} does not exist")
        sys.exit(1)

    lua_files = find_lua_files(project_dir)
    if not lua_files:
        print(f"No .lua files found in {project_dir}")
        sys.exit(0)

    print(f"=== Lua Syntax Verification ({len(lua_files)} files) ===")
    passed, failed = 0, 0
    for lua_file in lua_files:
        rel_path = lua_file.relative_to(project_dir)
        ok, msg = verify_syntax(lua_file)
        if ok:
            print(f"  ✓ {rel_path}")
            passed += 1
        else:
            print(f"  ✗ {rel_path}: {msg}")
            failed += 1

    print(f"\n=== Result: {passed}/{passed + failed} passed ===")
    sys.exit(0 if failed == 0 else 1)


if __name__ == '__main__':
    main()