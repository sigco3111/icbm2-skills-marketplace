#!/bin/bash
# i18n-yaml-verify.sh — verify that a YAML-based locale file loads correctly
# through the project's real localization loader, and that all known keys
# return non-fallback strings for the target locale.
#
# Usage:
#   ./scripts/i18n-yaml-verify.sh <repo-root> <locale-code> <key1,key2,key3...>
#
# Or with --keys-from-file:
#   ./scripts/i18n-yaml-verify.sh <repo-root> <locale-code> --keys-from-file keys.txt
#
# Real-world usage (end_of_eden, 2026-07-28):
#   ./scripts/i18n-yaml-verify.sh . ko \
#     "basics.on,basics.off,settings.audio.title,cards.MELEE_HIT.name,..."
#
# Requires: go (any 1.21+), jq-style key list (comma-separated)
#
# How it works:
#   1. Reads the i18n loader source to discover the Go package path
#   2. Builds a throwaway Go program in $TMPDIR that imports the loader
#   3. Calls the same AddFolder/AddFile path the game uses
#   4. Iterates over the supplied keys, asserts each returns the locale value
#      (NOT the en fallback AND NOT the key string itself)
#   5. Exits 0 if all pass, non-zero with diff if any fail
#
# This is the pattern that verified 118 Korean keys against BigJk/end_of_eden
# without needing to build the full game binary.

set -e

REPO_ROOT="${1:-.}"
LOCALE="${2:-ko}"
KEYS_ARG="${3:-}"

if [ -z "$KEYS_ARG" ]; then
    echo "Usage: $0 <repo-root> <locale-code> <comma-separated-keys>"
    echo "  or: $0 <repo-root> <locale-code> --keys-from-file <file>"
    exit 2
fi

# Normalize repo root
REPO_ROOT="$(cd "$REPO_ROOT" && pwd)"
cd "$REPO_ROOT"

if [ "$KEYS_ARG" = "--keys-from-file" ]; then
    KEYS_FILE="${4:?missing keys file path}"
    if [ ! -f "$KEYS_FILE" ]; then
        echo "ERROR: keys file not found: $KEYS_FILE"
        exit 2
    fi
    KEYS_CSL=$(grep -v '^[[:space:]]*$' "$KEYS_FILE" | grep -v '^[[:space:]]*#' | paste -sd, -)
else
    KEYS_CSL="$KEYS_ARG"
fi

# Detect Go module path
if [ ! -f "go.mod" ]; then
    echo "ERROR: no go.mod in $REPO_ROOT. This script assumes a Go project."
    exit 2
fi
MODULE=$(head -1 go.mod | awk '{print $2}')

# Detect i18n loader package (look for common patterns)
LOADER_PKG=""
for cand in "system/localization" "pkg/i18n" "internal/i18n" "i18n"; do
    if [ -d "$cand" ]; then
        LOADER_PKG="${MODULE}/${cand}"
        LOADER_DIR="$cand"
        break
    fi
done

if [ -z "$LOADER_PKG" ]; then
    echo "ERROR: could not auto-detect i18n loader package."
    echo "Tried: system/localization, pkg/i18n, internal/i18n, i18n"
    echo "Pass --loader-pkg explicitly or extend this script."
    exit 2
fi

echo "Detected loader: $LOADER_PKG"
echo "Repo root: $REPO_ROOT"
echo "Locale: $LOCALE"
echo "Key count: $(echo "$KEYS_CSL" | tr ',' '\n' | wc -l | tr -d ' ')"

# Build throwaway Go program
WORK=$(mktemp -d)
trap "rm -rf $WORK" EXIT

cat > "$WORK/main.go" <<EOF
package main

import (
	"fmt"
	"os"
	"strings"
	"${LOADER_PKG}"
)

func main() {
	if err := ${LOADER_PKG##*.}.Global.AddFolder("$REPO_ROOT/assets/locals"); err != nil {
		fmt.Println("AddFolder error:", err)
		os.Exit(1)
	}

	keys := strings.Split(\`$KEYS_CSL\`, ",")
	pass, fail := 0, 0
	var missing []string
	for _, k := range keys {
		k = strings.TrimSpace(k)
		if k == "" {
			continue
		}
		v := ${LOADER_PKG##*.}.Global.Get("$LOCALE", k)
		// "missing" = either returned the key itself OR started with the key (likely en fallback)
		if v == k || strings.HasPrefix(v, k) {
			fail++
			missing = append(missing, k)
		} else {
			pass++
		}
	}
	fmt.Printf("\n========== %s (locale) localization check ==========\n", "$LOCALE")
	fmt.Printf("PASS: %d\nFAIL: %d\nTOTAL: %d\n", pass, fail, len(keys))
	if fail > 0 {
		fmt.Println("\nMissing keys (fell back to en or returned the key):")
		for _, k := range missing {
			fmt.Println("  -", k)
		}
		os.Exit(1)
	}
	fmt.Println("\nAll keys load correctly for locale:", "$LOCALE")
}
EOF

# Run with the repo as cwd (so the loader's "./assets/locals" path resolves)
go run "$WORK/main.go"