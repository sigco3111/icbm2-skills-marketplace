#!/bin/bash
# scripts/java-i18n-locale-probe.sh
#
# Java i18n Locale.lookup 함정 빠른 진단 스크립트.
# ResourceBundle.getBundle()이 어떤 locale로 매칭되는지 확인.
#
# Usage:
#   bash scripts/java-i18n-locale-probe.sh [path/to/classes_or_jar]
#
# Output:
#   - 시스템 locale (ko_KR 인지 등)
#   - Collator.getAvailableLocales() 매칭 결과
#   - ui_ko.properties 로드 가능 여부
#   - 트리거: en-US weight=1.0 → 한국어 매칭 안 됨 경고
#
# 사용 전제:
#   - JAVA_HOME이 설정된 JDK 17+ 환경
#   - properties 파일이 classpath에 있어야 함 (target/classes 또는 JAR)

set -e

JVM_OPTS=""
if [ -n "$1" ]; then
    JVM_OPTS="-cp $1"
fi

# Try to find a built classes dir or JAR
if [ -z "$1" ]; then
    if [ -d "target/classes" ]; then
        JVM_OPTS="-cp target/classes"
    elif ls build/libs/*.jar 2>/dev/null | head -1 | grep -q jar; then
        JAR=$(ls build/libs/*.jar | head -1)
        JVM_OPTS="-jar $JAR --help 2>/dev/null || true"
    fi
fi

# 1) Print system locale
echo "=== System Locale ==="
java -XshowSettings:properties -version 2>&1 | grep -E "user\.language|user\.country|file\.encoding" | head -5

# 2) Run Locale.lookup test
echo ""
echo "=== Locale.lookup Test (RFC 4647 lookup algorithm) ==="
cat > /tmp/LocaleProbe.java << 'EOF'
import java.text.Collator;
import java.util.*;

public class LocaleProbe {
    public static void main(String[] args) {
        HashMap<Locale, Double> supported = new HashMap<>();
        supported.put(Locale.US, 1.0);
        supported.put(Locale.GERMANY, 0.5);
        supported.put(Locale.KOREA, 0.5);

        StringBuilder sb = new StringBuilder();
        for (var entry : supported.entrySet()) {
            sb.append(",").append(entry.getKey().toLanguageTag()).append(";q=").append(entry.getValue());
        }
        String range = sb.substring(1);
        System.out.println("Range: " + range);

        List<Locale.LanguageRange> ranges = Locale.LanguageRange.parse(range);
        Locale[] available = Collator.getAvailableLocales();
        System.out.println("Available locales count: " + available.length);

        Locale result = Locale.lookup(ranges, Arrays.asList(available));
        System.out.println("Lookup result: " + result);
        System.out.println("System default: " + Locale.getDefault());

        if ("ko".equals(Locale.getDefault().getLanguage())
                && !"ko".equals(result.getLanguage())) {
            System.out.println("");
            System.out.println("⚠️  WARNING: System is Korean but lookup returned " + result);
            System.out.println("   This means Locale.lookup() is overriding your system locale.");
            System.out.println("   Fix: Replace Locale.lookup() with Locale.getDefault() direct match.");
            System.out.println("   See: references/java-resourcebundle-locale-lookup-pitfall.md");
        }

        // Test loading ui_ko.properties
        try {
            ResourceBundle bundle = ResourceBundle.getBundle("i18n.games.strategy.engine.framework.ui", Locale.KOREA);
            System.out.println("");
            System.out.println("✅ Korean bundle loaded! Keys: " + bundle.keySet().size());
            System.out.println("Sample: " + bundle.getString("startup.MainPanel.btn.Play.Lbl"));
        } catch (Exception e) {
            System.out.println("");
            System.out.println("❌ Korean bundle NOT loaded: " + e.getMessage());
        }
    }
}
EOF

javac /tmp/LocaleProbe.java -d /tmp/
java -cp /tmp/ LocaleProbe

echo ""
echo "=== Diagnosis ==="
if java -cp /tmp/ LocaleProbe 2>&1 | grep -q "WARNING: System is Korean"; then
    echo "🔴 Locale.lookup 함정 발견됨 — 한국어 등록해도 영어로 fallback됨"
    echo "   조치: I18nResourceBundle.java의 Locale.lookup을 computeLocale()로 교체"
    exit 1
elif java -cp /tmp/ LocaleProbe 2>&1 | grep -q "Korean bundle loaded"; then
    echo "🟢 Locale.lookup 정상 — 한국어 properties 매칭 가능"
    exit 0
else
    echo "🟡 불명확 — 수동 확인 필요"
    exit 2
fi
