#!/bin/bash
# verify_windows_zip.sh — Windows zip 빌드 결과물 자동 검증
# 4단계 함정 (run.bat 누락 / 한글 깨짐 / love.exe 경로 / .love 인식) 자동 점검.
#
# 사용법: ./scripts/verify_windows_zip.sh dist/snkrx-kr-windows-*.zip
# 종료 코드 0 = 모두 통과, 1+ = 실패

set -e

if [ $# -eq 0 ]; then
  echo "사용법: $0 <windows-zip-path>"
  echo "예: $0 dist/snkrx-kr-windows-v0.1.12.zip"
  exit 1
fi

ZIP_FILE="$1"

if [ ! -f "$ZIP_FILE" ]; then
  echo "❌ FAIL: zip 파일 없음: $ZIP_FILE"
  exit 1
fi

echo "=== Windows zip 검증: $ZIP_FILE ==="
echo

# 임시 디렉토리에 압축 해제
TMP_DIR=$(mktemp -d)
trap "rm -rf '$TMP_DIR'" EXIT
unzip -q "$ZIP_FILE" -d "$TMP_DIR"

PASS=0
FAIL=0

# === 검사 1: run.bat 존재 ===
echo "[1/4] run.bat 존재 확인"
if find "$TMP_DIR" -name "run.bat" -type f | grep -q .; then
  echo "  ✅ PASS: run.bat 발견"
  PASS=$((PASS+1))
else
  echo "  ❌ FAIL: run.bat 없음 (zip 명령이 run.bat를 포함 안 함)"
  FAIL=$((FAIL+1))
fi

# === 검사 2: run.bat이 순수 ASCII (한글 깨짐 방지) ===
echo "[2/4] run.bat ASCII 검증 (한글 깨짐 방지)"
if find "$TMP_DIR" -name "run.bat" -type f | head -1 | xargs -I {} file {} | grep -q "ASCII"; then
  echo "  ✅ PASS: run.bat은 ASCII 인코딩"
  PASS=$((PASS+1))
else
  echo "  ⚠️  WARN: run.bat이 UTF-8 (한글 포함 가능). 한글 깨짐 발생 가능."
  echo "  해결: cat > run.bat <<'BAT' heredoc으로 ASCII 전용 작성"
  FAIL=$((FAIL+1))
fi

# === 검사 3: love.exe가 love-11.5-win64/ 하위에 있거나, run.bat이 cd ===
echo "[3/4] love.exe 경로 + run.bat의 cd"
LOVE_EXE=$(find "$TMP_DIR" -name "love.exe" -type f | head -1)
if [ -z "$LOVE_EXE" ]; then
  echo "  ❌ FAIL: love.exe 없음"
  FAIL=$((FAIL+1))
else
  echo "  love.exe: $LOVE_EXE"
  if grep -q "cd love-11.5-win64" "$TMP_DIR/run.bat" 2>/dev/null; then
    echo "  ✅ PASS: run.bat이 'cd love-11.5-win64' 포함"
    PASS=$((PASS+1))
  elif [ -f "$TMP_DIR/love.exe" ]; then
    echo "  ✅ PASS: love.exe가 zip 루트에 있음 (cd 불필요)"
    PASS=$((PASS+1))
  else
    echo "  ❌ FAIL: love.exe는 $LOVE_EXE 에 있지만 run.bat이 cd하지 않음"
    FAIL=$((FAIL+1))
  fi
fi

# === 검사 4: .love 또는 game/ 폴더 중 하나는 zip에 포함 ===
echo "[4/4] .love 파일 또는 game/ 폴더 존재"
LOVE_FILE=$(find "$TMP_DIR" -name "*.love" -type f | head -1)
GAME_DIR_EXIST=$(find "$TMP_DIR" -type d -name "game" | head -1)
if [ -n "$LOVE_FILE" ] || [ -n "$GAME_DIR_EXIST" ]; then
  if [ -n "$LOVE_FILE" ]; then
    echo "  ✅ PASS: .love 파일 존재: $LOVE_FILE (영문 경로 호환)"
  fi
  if [ -n "$GAME_DIR_EXIST" ]; then
    echo "  ✅ PASS: game/ 폴더 존재: $GAME_DIR_EXIST (한글 경로 호환)"
  fi
  PASS=$((PASS+1))
else
  echo "  ❌ FAIL: .love 파일도 game/ 폴더도 없음 — love.exe 실행할 게임 데이터 없음"
  FAIL=$((FAIL+1))
fi

echo
echo "=== 결과: $PASS PASS, $FAIL FAIL ==="

if [ $FAIL -gt 0 ]; then
  echo "❌ 검증 실패. 빌드 스크립트(build_all.sh) 확인 필요."
  echo "참조: references/love-windows-zip-build-pitfalls.md (4단계 함정 + 해결)"
  exit 1
fi

echo "✅ 모든 검증 통과. Windows 사용자 배포 가능."
exit 0
