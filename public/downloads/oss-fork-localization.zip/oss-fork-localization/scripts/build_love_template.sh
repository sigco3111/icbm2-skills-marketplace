#!/bin/bash
# build_love.sh — 프로젝트 폴더를 .love 파일로 패키징
# SNKRX v0.1.12 Release 검증 (2026-07-21)
#
# 사용법: ./build_love.sh
# 출력: dist/<projectname>-<version>.love
#
# .love = 표준 zip 포맷. love2d가 직접 실행 가능.
# `love game.love`로 모든 OS에서 실행.

set -e

VERSION="${VERSION:-v0.1.0}"
PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
DIST_DIR="$PROJECT_DIR/dist"

# 프로젝트 이름 (현재 디렉토리명 사용)
PROJECT_NAME="$(basename "$PROJECT_DIR")"
OUTPUT="$DIST_DIR/${PROJECT_NAME}-${VERSION}.love"

mkdir -p "$DIST_DIR"

cd "$PROJECT_DIR"

# .git, .DS_Store, dist 폴더, .love 파일 제외
zip -r "$OUTPUT" . \
  -x "*.git*" \
  -x "*.DS_Store" \
  -x "dist/*" \
  -x "*.love" \
  -q

echo "✅ Built: $OUTPUT"
echo "📦 Size: $(du -h "$OUTPUT" | cut -f1)"
echo ""
echo "테스트 실행:"
echo "  macOS:   love $OUTPUT"
echo "  Linux:   love $OUTPUT"
echo "  Windows: love.exe $OUTPUT"
