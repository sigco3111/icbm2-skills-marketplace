#!/usr/bin/env python3
"""
PO 파일 빈 msgstr 채우기 스크립트 v2 — longest prefix match + 정확 multiline 파싱.

translations.json의 msgid -> msgstr 매핑으로 PO 파일의 빈 msgstr만 정확히 치환합니다.
원본 PO 파일의 라인 구조와 주석, file_refs, fuzzy 마커를 모두 보존합니다.

v1 (single-line only) → v2 추가 사항 (2026-07-20, wesnoth-kr 검증):
- multiline msgid 정확히 파싱 (다음 줄이 msgstr/msgid_plural이 아닌 "..."이면 multiline)
- longest prefix match: msgid가 정확 일치하지 않아도 translations의 키가 msgid의
  prefix인 경우 (또는 그 반대) 매칭. fuzzy msgid가 긴 msgid 일부만 translations에
  있을 때 유용 — wesnoth-kr에서 1개 매칭 → 45개 매칭으로 45배 향상.
- msgstr[0]/msgstr[1] plural form 지원

사용법:
    python3 fill_empty.py <input.po> <output.po> <translations.json>

출력:
    채워진 빈 msgstr 개수 + 입출력 파일 크기 통계
"""
import json
import re
import sys
from pathlib import Path


def find_best_match(msgid, translations):
    """msgid에 대해 translations에서 가장 일치하는 키 찾기.

    매칭 우선순위:
    1. 정확 일치
    2. longest prefix match (긴 키 우선)
    """
    if msgid in translations:
        return msgid, translations[msgid]

    # prefix match - 긴 키 우선
    candidates = []
    for k in translations:
        if k and (msgid.startswith(k) or k.startswith(msgid)):
            candidates.append((len(k), k, translations[k]))

    if candidates:
        candidates.sort(reverse=True)
        return candidates[0][1], candidates[0][2]

    return None


def patch_po_multiline(content: str, translations: dict):
    """multiline msgid를 정확히 처리하면서 longest prefix match 적용.

    PO 형식:
        msgid "first line"
        "second line"
        "third line"
        msgstr ""

    또는 plural:
        msgid "first line"
        msgid_plural "plural line"
        msgstr[0] ""
        msgstr[1] ""
    """
    lines = content.split('\n')
    out_lines = []
    filled = 0
    i = 0

    while i < len(lines):
        line = lines[i]

        m = re.match(r'msgid\s+"(.*)"', line)
        if m:
            # multiline msgid 수집 (다음 줄이 msgstr/msgid_plural가 아닌 "..." 라인이면 multiline)
            msgid_parts = [m.group(1)]
            j = i + 1
            while j < len(lines):
                next_line = lines[j]
                mm = re.match(r'"(.*)"', next_line)
                if mm:
                    # 다음 라인이 multiline msgid의 연속인지 확인
                    is_continuation = (
                        j > i + 1
                        and not next_line.startswith('msgstr')
                        and not next_line.startswith('msgid ')
                        and not next_line.startswith('msgid_plural')
                    )
                    if is_continuation:
                        msgid_parts.append(mm.group(1))
                        j += 1
                        continue
                    break
                elif next_line.startswith('#') or next_line.strip() == '':
                    j += 1
                else:
                    break

            # msgid 라인들 출력
            for k in range(i, j):
                out_lines.append(lines[k])

            # 다음 줄이 msgstr인지 확인
            if j < len(lines):
                next_line = lines[j]
                ms_match = re.match(r'msgstr\s+"(.*)"', next_line)
                ms_plural = re.match(r'msgstr\[0\]\s+"(.*)"', next_line)

                full_msgid = ''.join(msgid_parts)
                match_result = find_best_match(full_msgid, translations)

                if ms_match and not ms_match.group(1) and match_result:
                    _, translation = match_result
                    out_lines.append(f'msgstr "{translation}"')
                    filled += 1
                    i = j + 1
                    continue
                elif ms_plural and not ms_plural.group(1) and match_result:
                    _, translation = match_result
                    out_lines.append(f'msgstr[0] "{translation}"')
                    filled += 1
                    if j + 1 < len(lines):
                        ms1_match = re.match(r'msgstr\[1\]\s+"(.*)"', lines[j+1])
                        if ms1_match and not ms1_match.group(1):
                            out_lines.append(f'msgstr[1] "{translation}"')
                            i = j + 2
                            continue
                    i = j + 1
                    continue

            i = j
            continue

        out_lines.append(line)
        i += 1

    return '\n'.join(out_lines), filled


def parse_entries(content):
    """stats.py와 동일한 multiline PO 파서 (단일 진실 소스, v3 2026-07-20).

    multiline regex의 j > i + 1 버그(함정 K)를 우회하기 위해 stats.py와
    동일한 state machine으로 리팩토링. wesnoth-kr v0.3 검증:
    1개 → 45개 매칭 (45배 향상).
    """
    lines = content.split('\n')
    i = 0
    file_ref = None
    in_msgid = False
    in_msgstr = False
    msgid_parts = []
    msgstr_parts = []
    entries = []

    while i < len(lines):
        line = lines[i]
        if line.startswith('#:'):
            if file_ref and msgid_parts:
                entries.append({
                    'file': file_ref,
                    'msgid': ''.join(msgid_parts),
                    'msgstr': ''.join(msgstr_parts),
                })
            file_ref = line[2:].strip().split()[0] if line[2:].strip() else None
            msgid_parts = []
            msgstr_parts = []
            in_msgid = False
            in_msgstr = False
        elif file_ref:
            m = re.match(r'msgid\s+"(.*)"', line)
            if m:
                in_msgid = True
                in_msgstr = False
                msgid_parts = [m.group(1)]
            elif re.match(r'msgstr\s+"(.*)"', line):
                in_msgid = False
                in_msgstr = True
                m = re.match(r'msgstr\s+"(.*)"', line)
                msgstr_parts = [m.group(1)]
            elif line.startswith('"') and (in_msgid or in_msgstr):
                m = re.match(r'"(.*)"', line)
                if m:
                    if in_msgid: msgid_parts.append(m.group(1))
                    else: msgstr_parts.append(m.group(1))
        i += 1

    if file_ref and msgid_parts:
        entries.append({
            'file': file_ref,
            'msgid': ''.join(msgid_parts),
            'msgstr': ''.join(msgstr_parts),
        })

    return entries


def serialize_entries(entries, original_content):
    """entries를 PO 형식으로 직렬화 (원본 주석/file_ref 보존)."""
    lines = original_content.split('\n')
    new_lines = []
    i = 0
    file_ref = None
    in_msgid = False
    in_msgstr = False
    msgid_parts = []
    msgstr_parts = []
    current_entry = None
    entries_iter = iter(entries)
    next_entry = next(entries_iter, None)

    while i < len(lines):
        line = lines[i]

        if line.startswith('#:'):
            if file_ref and msgid_parts and next_entry:
                current_entry = next_entry
                next_entry = next(entries_iter, None)
            file_ref = line[2:].strip().split()[0] if line[2:].strip() else None
            msgid_parts = []
            msgstr_parts = []
            in_msgid = False
            in_msgstr = False
            new_lines.append(line)
            i += 1
            continue

        m = re.match(r'msgid\s+"(.*)"', line)
        if m:
            in_msgid = True
            in_msgstr = False
            msgid_parts = [m.group(1)]
            new_lines.append(line)
            i += 1
            continue

        m = re.match(r'msgstr\s+"(.*)"', line)
        if m:
            in_msgid = False
            in_msgstr = True
            if current_entry and current_entry['msgstr'] and not m.group(1):
                new_lines.append(f'msgstr "{current_entry["msgstr"]}"')
            else:
                new_lines.append(line)
            msgstr_parts = [m.group(1)]
            i += 1
            continue

        if line.startswith('"') and (in_msgid or in_msgstr):
            m = re.match(r'"(.*)"', line)
            if m:
                if in_msgid: msgid_parts.append(m.group(1))
                else: msgstr_parts.append(m.group(1))
            new_lines.append(line)
            i += 1
            continue

        new_lines.append(line)
        i += 1

    return '\n'.join(new_lines)


def main():
    if len(sys.argv) < 4:
        print("Usage: fill_empty.py <input.po> <output.po> <translations.json>")
        sys.exit(1)

    input_po = Path(sys.argv[1])
    output_po = Path(sys.argv[2])
    translations_json = Path(sys.argv[3])

    translations = json.loads(translations_json.read_text(encoding='utf-8'))
    # _comment 키 제거 (JSON의 메타 주석)
    translations = {k: v for k, v in translations.items() if not k.startswith('_')}

    content = input_po.read_text(encoding='utf-8')
    entries = parse_entries(content)

    # 빈 entry 채우기
    filled = 0
    for e in entries:
        if e['msgid'] and not e['msgstr']:
            translation = find_best_match(e['msgid'], translations)
            if translation:
                e['msgstr'] = translation
                filled += 1

    # 출력
    output_content = serialize_entries(entries, content)
    output_po.write_text(output_content, encoding='utf-8')

    print(f"✅ 처리 완료:")
    print(f"   입력: {input_po} ({len(content):,} chars)")
    print(f"   출력: {output_po} ({len(output_content):,} chars)")
    print(f"   채워진 빈 msgstr: {filled}")
    print(f"   매핑 사전: {len(translations)} entries")


if __name__ == '__main__':
    main()