-- luasteam_shim_template.lua — LÖVE 게임용 Steamworks shim 템플릿
-- 원본: require 'luasteam' (Steamworks SDK 바인딩)
-- 교체: require 'path.to.luasteam_shim' (no-op 버전)
--
-- 사용법:
-- 1. 이 파일을 engine/external/luasteam.lua로 복사
-- 2. init.lua에서 require 'luasteam' → require(path .. ".luasteam") 로 변경
-- 3. 게임 코드에서 사용하는 모든 steam.* 함수가 shim에 있는지 확인
--    grep -rhE "steam\.(userStats|friends|utils|appshover|callback)" *.lua
--
-- 왜 필요한가:
-- brew로 설치한 love에는 Steamworks SDK 바인딩(luasteam.so) 없음
-- Steam 클라이언트 미실행 상태에서도 게임플레이 가능하도록 모든 Steam API를 no-op으로
-- Steam achievements, leaderboard, 친구 기능은 작동하지 않지만 게임 자체는 정상 작동

local M = {}

function M.init() return true end
function M.shutdown() end

-- User Stats (achievements, stats)
M.userStats = {
  requestCurrentStats = function() return true end,
  setAchievement = function() end,
  storeStats = function() end,
  getStatInt = function() return 0 end,
  setStatInt = function() end,
  getStatFloat = function() return 0.0 end,
  setStatFloat = function() end,
  resetAllStats = function() return false end,
}

-- Friends (rich presence, overlay)
M.friends = {
  setRichPresence = function() end,
  activateGameOverlay = function() end,
  activateGameOverlayToWebPage = function() end,
  requestUserInformation = function() end,
}

-- Utils
M.utils = {
  getAppID = function() return 0 end,
  getCurrentGameLanguage = function() return "english" end,
}

-- Apps
M.apps = {
  isDlcInstalled = function() return false end,
}

return M