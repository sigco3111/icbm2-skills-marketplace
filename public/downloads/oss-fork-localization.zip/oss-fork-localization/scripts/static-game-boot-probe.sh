#!/bin/bash
# static-game-boot-probe.sh — 5분 preflight for HTML/JS only game repos
#
# Usage: ./static-game-boot-probe.sh <owner/repo> [<owner/repo> ...]
# Example: ./static-game-boot-probe.sh oskarrough/slaytheweb increpare/PuzzleScript pmotschmann/Evolve
#
# What it does (per repo):
#   1. GitHub API: default_branch, license.spdx_id, size_kb
#   2. LICENSE file: cross-check first line vs API
#   3. npm install: only if dependencies/runtime present AND dev script exists
#   4. Static boot via `python3 -m http.server` (different port per repo)
#   5. Probe root + 1-2 known asset paths, report HTTP 200/404
#   6. Cleanup server
#
# Output: per-repo status block (PASS / FAIL with reason)
# Requires: curl, git, python3 (>=3.6), gh (optional for license cross-check)

set -uo pipefail

start_port="${START_PORT:-8001}"
TMPDIR="${TMPDIR:-/tmp/preflight-$$}"

cleanup_servers() {
  for port in $(seq "$start_port" "$((start_port + ${#repos[@]} - 1))"); do
    pids=$(lsof -nP -iTCP:"$port" -sTCP:LISTEN -t 2>/dev/null)
    if [ -n "$pids" ]; then
      kill $pids 2>/dev/null
    fi
  done
  rm -rf "$TMPDIR" 2>/dev/null
}
trap cleanup_servers EXIT INT TERM

if [ "$#" -lt 1 ]; then
  echo "Usage: $0 <owner/repo> [<owner/repo> ...]" >&2
  exit 1
fi

echo "=== Environment check ==="
node --version 2>/dev/null || echo "node: missing"
npm --version 2>/dev/null || echo "npm: missing"
git --version 2>/dev/null || echo "git: missing"
python3 --version 2>/dev/null || { echo "python3: required"; exit 1; }
echo

for i in "$@"; do
  port=$((start_port + $# - $#))  # placeholder, overwritten below
done

i=0
for repo in "$@"; do
  port=$((start_port + i))
  i=$((i + 1))
  name=$(basename "$repo")
  target="$TMPDIR/$name"

  echo
  echo "============================================================"
  echo "  $repo  (port $port)"
  echo "============================================================"

  # 1) GitHub API check
  echo "--- Phase 1: GitHub API ---"
  api_data=$(curl -s "https://api.github.com/repos/$repo")
  echo "$api_data" | python3 -c "
import json, sys
try:
    d = json.load(sys.stdin)
    msg = d.get('message', '')
    if msg:
        print(f'  API ERROR: {msg}')
    else:
        lic = (d.get('license') or {}).get('spdx_id', 'NONE')
        size = d.get('size', 0)
        branch = d.get('default_branch', '?')
        pushed = (d.get('pushed_at') or '')[:10]
        print(f'  branch={branch} license={lic} size={size}KB pushed={pushed}')
except Exception as e:
    print(f'  parse error: {e}')
"

  # 2) Clone + LICENSE cross-check
  echo "--- Phase 2: Clone + LICENSE ---"
  rm -rf "$target"
  git clone --depth=1 "https://github.com/$repo.git" "$target" 2>&1 | tail -2

  if [ -f "$target/LICENSE" ]; then
    license_first=$(head -1 "$target/LICENSE" 2>/dev/null)
    echo "  LICENSE line 1: $license_first"
  elif [ -f "$target/LICENSE.md" ]; then
    license_first=$(head -1 "$target/LICENSE.md" 2>/dev/null)
    echo "  LICENSE.md line 1: $license_first"
  else
    echo "  WARNING: no LICENSE file"
  fi

  # 3) Build script detection
  echo "--- Phase 3: Build script analysis ---"
  has_pkg=0
  has_runtime_dep=0
  has_dev_script=0
  if [ -f "$target/package.json" ]; then
    has_pkg=1
    python3 <<PY
import json
with open("$target/package.json") as f:
    d = json.load(f)
deps = d.get("dependencies") or {}
scripts = d.get("scripts") or {}
print(f"  runtime deps: {len(deps)}")
print(f"  scripts: {list(scripts.keys())}")
runtime = bool(deps) and bool(scripts.get("dev") or scripts.get("start"))
print(f"  -> runtime boot viable: {runtime}")
PY
  else
    echo "  (no package.json — pure static repo)"
  fi

  # 4) Static boot + probe
  echo "--- Phase 4: Static boot + HTTP probe ---"
  # Pick the directory that has index.html or src/ with index.html
  if [ -f "$target/src/editor.html" ] || [ -f "$target/src/index.html" ]; then
    cd "$target/src"
    echo "  serving: src/"
  elif [ -f "$target/index.html" ]; then
    cd "$target"
    echo "  serving: ."
  else
    cd "$target"
    echo "  serving: . (no index.html — manual probe needed)"
  fi

  python3 -m http.server "$port" --bind 127.0.0.1 >/dev/null 2>&1 &
  server_pid=$!
  sleep 2

  # probe root + a couple of likely assets
  curl -s -o /dev/null -w "  /                       HTTP:%{http_code} bytes:%{size_download}\n" \
    "http://127.0.0.1:$port/"
  for asset in play.html editor.html evolve/evolve.js lib/main.js index.html; do
    code=$(curl -s -o /dev/null -w "%{http_code}" "http://127.0.0.1:$port/$asset")
    [ "$code" != "404" ] && echo "  /$asset  HTTP:$code"
  done

  kill $server_pid 2>/dev/null
  wait $server_pid 2>/dev/null

  cd /tmp
done

echo
echo "============================================================"
echo "  Pre-flight summary"
echo "============================================================"
echo "  All probes complete. Inspect per-repo block for HTTP codes."
echo "  Cleanup: kill any leftover background servers via lsof -iTCP:LISTEN"
