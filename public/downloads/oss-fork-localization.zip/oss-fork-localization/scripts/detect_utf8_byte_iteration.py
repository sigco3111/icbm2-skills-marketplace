#!/usr/bin/env python3
"""
detect_utf8_byte_iteration.py — UTF-8 byte-iteration 위험 패턴 감지

SNKRX fork-한글화에서 만난 가장 위험한 함정을 사전에 감지.
다국어 게임 fork 시 첫 단계에서 실행 권장.

감지 패턴 (언어별):
  - Lua/LuaJIT:   for i = 1, #text do ... sub(i, i) ...
  - JavaScript:   str.charAt(i), str[i], str.slice(i, i+1)
  - Python 2:     for c in str (str = bytes)
  - C/C++:        char buf[N]; for (int i=0; i<N; i++) buf[i]=s[i]

사용법:
    python3 scripts/detect_utf8_byte_iteration.py [project_dir]
"""
import re
import sys
from pathlib import Path

# 위험 패턴 (정규식)
PATTERNS = {
    'lua': [
        # for i = 1, #s do s:sub(i, i) — 가장 위험
        (r'for\s+\w+\s*=\s*1\s*,\s*#\s*\w+\s+do.*:sub\(\s*\w+\s*,\s*\w+\s*\)',
         'byte iteration with sub(i, i)'),
        # s:byte(i) in CJK detection (2-byte Latin extended 잘못 감지 위험은 별도)
        (r':byte\(\s*\w+\s*\)',
         'byte access — verify UTF-8 lead-byte logic'),
    ],
    'javascript': [
        # str.charAt(i), str[i], str.slice(i, i+1)
        (r'\.charAt\([^)]*\)',
         'charAt() — returns UTF-16 code unit, not character'),
        (r'\.slice\([^,)]+,\s*[^,)]+\)',
         'slice() on string — may split surrogate pair'),
    ],
    'python': [
        # Python 2 only — Python 3 str은 코드포인트
        (r'for\s+\w+\s+in\s+str\s*:',
         'Python 2 str iteration (str = bytes) — use unicode'),
    ],
    'cpp': [
        # char buf[N] + indexed access
        (r'char\s+\w+\s*\[[^\]]+\][^;]*for\s*\([^;]+;\s*\w+\s*<\s*sizeof',
         'char buffer with sizeof-bounded loop — may split UTF-8'),
    ],
}

EXT_LANG_MAP = {
    '.lua': 'lua',
    '.js': 'javascript',
    '.ts': 'javascript',
    '.py': 'python',
    '.cpp': 'cpp',
    '.c': 'cpp',
    '.h': 'cpp',
    '.hpp': 'cpp',
}


def scan_file(file_path: Path) -> list[tuple[int, str, str]]:
    """단일 파일에서 위험 패턴 찾기. (line, pattern_desc, line_text) 반환."""
    ext = file_path.suffix
    lang = EXT_LANG_MAP.get(ext)
    if not lang or lang not in PATTERNS:
        return []

    try:
        content = file_path.read_text(encoding='utf-8', errors='replace')
    except OSError:
        return []

    results = []
    for line_num, line in enumerate(content.splitlines(), 1):
        for pattern, desc in PATTERNS[lang]:
            if re.search(pattern, line):
                # 주석은 무시 (-- lua, # python, // cpp/js)
                stripped = line.strip()
                if ext in {'.lua'} and stripped.startswith('--'):
                    continue
                if ext in {'.py'} and stripped.startswith('#'):
                    continue
                if ext in {'.js', '.ts', '.cpp', '.c', '.h', '.hpp'} and stripped.startswith('//'):
                    continue
                results.append((line_num, desc, line.strip()[:120]))
    return results


def main():
    project_dir = Path(sys.argv[1]) if len(sys.argv) > 1 else Path.cwd()
    if not project_dir.exists():
        print(f"Error: {project_dir} does not exist")
        sys.exit(1)

    exclude_dirs = {'.git', 'node_modules', 'builds', 'dist', '.venv', 'venv'}

    print(f"=== UTF-8 Byte-Iteration Detection ({project_dir}) ===\n")
    total_findings = 0
    files_scanned = 0

    for file_path in sorted(project_dir.rglob('*')):
        if not file_path.is_file():
            continue
        if any(part in exclude_dirs for part in file_path.parts):
            continue
        if file_path.suffix not in EXT_LANG_MAP:
            continue

        files_scanned += 1
        results = scan_file(file_path)
        if results:
            rel = file_path.relative_to(project_dir)
            for line_num, desc, text in results:
                print(f"  ⚠ {rel}:{line_num} [{desc}]")
                print(f"    > {text}")
                total_findings += 1

    print(f"\n=== Scanned {files_scanned} files, {total_findings} findings ===")
    if total_findings == 0:
        print("✓ No dangerous byte-iteration patterns detected.")
        print("  Still: test with actual CJK text before declaring fork safe.")
        sys.exit(0)
    else:
        print("\n⚠ CRITICAL: Review each finding.")
        print("  Byte-iteration on multi-byte UTF-8 text causes 'Not enough space'")
        print("  errors (Lua), broken glyph rendering (JS), or silent data corruption.")
        print("  See: SKILL.md §UTF-8 byte vs character iteration 함정")
        sys.exit(1)


if __name__ == '__main__':
    main()