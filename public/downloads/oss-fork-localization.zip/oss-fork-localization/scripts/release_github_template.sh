#!/bin/bash
# release_github.sh — GitHub Releases 발행 (gh workflow scope 우회)
# SNKRX v0.1.12 Release 검증 (2026-07-21)
#
# 사용법:
#   REPO=USER/REPO ./release_github.sh
# 또는 gh CLI 인증된 사용자로 자동:
#   ./release_github.sh
#
# gh release create가 "workflow scope required" 에러 시 자동으로 curl API 사용.

set -e

VERSION="${VERSION:-v0.1.0}"
DIST_DIR="${DIST_DIR:-dist}"
REPO="${REPO:-}"
TOKEN="${GITHUB_TOKEN:-}"

# 1. gh CLI 우선 시도
if command -v gh >/dev/null 2>&1 && [ -n "$REPO" ] && gh auth status >/dev/null 2>&1; then
    echo "Attempting gh release create..."
    cd "$DIST_DIR"
    if gh release create "$VERSION" \
        *.zip *.tar.gz *.love 2>/dev/null \
        --repo "$REPO" \
        --title "Release v$VERSION" \
        --notes-file <(cat <<EOF
## Release v$VERSION

자동 생성된 릴리스 노트.
EOF
) ; then
        echo "✅ Release created via gh CLI"
        exit 0
    fi
    echo "gh CLI 실패, curl API로 fallback..."
fi

# 2. curl API fallback
[ -z "$TOKEN" ] && TOKEN=$(gh auth token 2>/dev/null) || true
[ -z "$TOKEN" ] && {
    echo "❌ GITHUB_TOKEN 또는 gh CLI 인증 필요"
    echo "   export GITHUB_TOKEN=ghp_... 또는 gh auth login"
    exit 1
}
[ -z "$REPO" ] && {
    echo "❌ REPO=USER/REPO 환경변수 필요"
    exit 1
}

echo "Using curl API to create release on $REPO..."

# Step 1: Draft release 생성
RELEASE_JSON=$(curl -s -X POST \
    -H "Authorization: Bearer $TOKEN" \
    -H "Accept: application/vnd.github+json" \
    "https://api.github.com/repos/$REPO/releases" \
    -d "{
        \"tag_name\": \"$VERSION\",
        \"name\": \"Release v$VERSION\",
        \"body\": \"## Release v$VERSION\\n\\n자동 생성된 릴리스.\",
        \"draft\": true
    }")

RELEASE_ID=$(echo "$RELEASE_JSON" | python3 -c "import sys,json; print(json.load(sys.stdin).get('id', ''))")
if [ -z "$RELEASE_ID" ]; then
    echo "❌ Release 생성 실패:"
    echo "$RELEASE_JSON"
    exit 1
fi
echo "✅ Draft release created: ID=$RELEASE_ID"

# Step 2: Asset 업로드
UPLOAD_URL="https://uploads.github.com/repos/$REPO/releases/$RELEASE_ID/assets{?name,label}"
COUNT=0
for file in "$DIST_DIR"/*.zip "$DIST_DIR"/*.tar.gz "$DIST_DIR"/*.love; do
    [ ! -f "$file" ] && continue
    name=$(basename "$file")
    echo "Uploading $name..."
    HTTP=$(curl -s -X POST \
        -H "Authorization: Bearer $TOKEN" \
        -H "Content-Type: application/zip" \
        --data-binary "@$file" \
        "${UPLOAD_URL//\{?name,label\}/?name=$name}" \
        -o /dev/null -w "%{http_code}")
    [ "$HTTP" = "201" ] && echo "  ✅ $HTTP" || echo "  ❌ $HTTP"
    COUNT=$((COUNT + 1))
done
echo "✅ $COUNT asset(s) 업로드 완료"

# Step 3: Draft → Published
curl -s -X PATCH \
    -H "Authorization: Bearer $TOKEN" \
    -H "Accept: application/vnd.github+json" \
    "https://api.github.com/repos/$REPO/releases/$RELEASE_ID" \
    -d '{"draft":false}' > /dev/null

echo ""
echo "🎉 Release published!"
echo "URL: https://github.com/$REPO/releases/tag/$VERSION"
