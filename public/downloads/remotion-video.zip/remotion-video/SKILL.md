---
name: remotion-video
description: "Production pipeline for programmatic video creation using Remotion. Creates data-driven videos, animated dashboards, tech trend visualizations, AI benchmark comparisons, and web-native animations. Use when users request: animated data visualizations, tech news videos, benchmark comparisons, dashboard animations, GitHub activity videos, AI model comparison visuals, or any programmatic video with React/CSS/SVG/WebGL. ⚠️ Remotion 4.x requires specific API patterns — see SKILL.md for correct setup (Composition from 'remotion', registerRoot only in index.ts)."
version: 1.1.0
category: creative
---

# Remotion 4.x Video Production Pipeline

## ⚠️ Remotion 4.x API Patterns (CRITICAL)

Remotion 4.x has different API from 3.x. Wrong imports cause `registerRoot() called more than once` or `Composition not found` errors.

### Correct Remotion 4.x File Structure

**src/index.ts** — registerRoot only here, ONCE:
```ts
import { registerRoot } from "remotion";
import { RemotionRoot } from "./Root";

registerRoot(RemotionRoot);
```

**src/Root.tsx** — Composition from 'remotion', NOT '@remotion/cli/config':
```tsx
import React from "react";
import { Composition } from "remotion";  // ← NOT from '@remotion/cli/config'
import { Video } from "./Video";

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="Video"
      durationInFrames={1350}
      fps={30}
      width={1080}
      height={1920}
      component={Video}
    />
  );
};
```

**src/Video.tsx** — Core components from 'remotion':
```tsx
import {
  AbsoluteFill,
  Sequence,
  interpolate,
  spring,
  useCurrentFrame,
} from "remotion";

export const Video: React.FC = () => (
  <AbsoluteFill style={{ backgroundColor: "#0D1117" }}>
    <Sequence from={0} durationInFrames={150}>
      <Scene1 />
    </Sequence>
    <Sequence from={150} durationInFrames={150}>
      <Scene2 />
    </Sequence>
  </AbsoluteFill>
);
```

### Rendering
```bash
npx remotion render Video out/video.mp4 --fps=30 --height=1920 --width=1080 --quality=1
```

### Common Errors
| Error | Cause | Fix |
|-------|-------|-----|
| `registerRoot() called more than once` | registerRoot in both index.ts AND Root.tsx | Remove from Root.tsx |
| `Composition not found` | Importing from '@remotion/cli/config' | Import from 'remotion' |
| `Sequence context` errors | Using frame outside Sequence | Use `useRelFrame(from)` helper |
| `Can't resolve 'url'` | webpack polyfill bug | Install `url` package: `npm install url` |

## Overview

Remotion lets you create videos programmatically using React. Every web technology is available: CSS animations, SVG graphics, Canvas, WebGL, data visualizations, and React's component model.

```
PLAN --> CODE --> RENDER --> STITCH --> UPLOAD
```

## When to Use Remotion vs Other Tools

| Tool | Best For | macOS Local |
|------|----------|-------------|
| **Remotion** | Complex React animations, data viz, particle effects | ✅ Works (with Audio require() pattern) |
| **FFmpeg** | Text overlays, BGM, bar charts, gradients, transitions | ✅ Works |
| Manim (archived) | Mathematical proofs, LaTeX equations | ✅ Works |

---

## FFmpeg Fallback Workflow (Recommended for macOS)

```bash
mkdir -p out
# 1. Generate BGM
ffmpeg -f lavfi -i "aevalsrc=0.2*sin(2*PI*220*t)+0.15*sin(2*PI*330*t)+0.1*sin(2*PI*440*t):s=48000:d=45,afade=t=in:st=0:d=3,afade=t=out:st=42:d=3,volume=0.4" -y out/bgm.mp3

# 2. Render video with text overlays
ffmpeg -y \
  -f lavfi -i "color=c=#0D1117:s=1080x1920:d=45:fps=30" \
  -f lavfi -i out/bgm.mp3 \
  -filter_complex "
    [0:v]drawtext=text='ICBM2':fontsize=120:fontcolor=#58C4DD:x=(w-text_w)/2:y=h*0.25:enable='between(t,0,5)',
    drawtext=text='AUTOMATION':fontsize=72:fontcolor=white:x=(w-text_w)/2:y=h*0.42:enable='between(t,1,5)',
    ...[outv]
  " \
  -map "[outv]" -map 1:a \
  -c:v libx264 -preset fast -crf 23 \
  -c:a aac -b:a 128k -shortest \
  out/icbm2-shorts.mp4
```

### FFmpeg Text Overlay Parameters

| Parameter | Description |
|-----------|-------------|
| `text='...'` | Text content |
| `fontsize=120` | Font size |
| `fontcolor=#HEX` | Color |
| `x=(w-text_w)/2` | Center horizontally |
| `y=h*0.25` | Position from top |
| `enable='between(t,0,5)'` | Show from 0-5 seconds |
| `borderw=3:bordercolor=black` | Text outline |

### Color Palette

| Name | Hex | Use |
|------|-----|-----|
| Tech Dark BG | `#0D1117` | Background |
| Primary | `#58C4DD` | ICBM2, main accent |
| Secondary | `#83C167` | GLM, success |
| Accent | `#FFFF00` | Highlights |
| Pink | `#FF6B9D` | GPT, alerts |

### Bar Chart (FFmpeg)

```bash
# Bar chart at bottom — drawbox x=pos:y=bottom:w=width:h=height:color=HEX
drawbox=x=100:y=1200:w=250:h=400:color=#58C4DD:enable='between(t,11,20)'
```

## Prerequisites

```bash
# Install Node.js 18+ and Remotion
npm install @remotion/cli remotion

# Create new project
npx create-video@latest my-project
cd my-project

# Start preview server
npm start
```

## Project Structure

```
my-video/
├── src/
│   ├── Root.tsx           # Entry point, aspect ratio, duration
│   ├── Video.tsx          # Main composition
│   ├── scenes/
│   │   ├── Intro.tsx
│   │   ├── MainContent.tsx
│   │   └── Outro.tsx
│   ├── components/
│   │   ├── Title.tsx
│   │   ├── Chart.tsx
│   │   └── Badge.tsx
│   └── styles/
│       └── theme.ts
├── package.json
└── remotion.config.ts
```

## Stack

| Layer | Tool | Purpose |
|-------|------|---------|
| Core | Remotion + React 18 | Video composition, component model |
| Rendering | @remotion/cli | Frame-by-frame rendering |
| Styling | CSS-in-JS, Tailwind, or plain CSS | Visual design |
| Charts | Recharts, D3, or raw SVG | Data visualization |
| Fonts | Google Fonts, @remotion/google-fonts | Typography |
| Audio | @remotion/aio or edge-tts | Narration/TTS |
| Video I/O | ffmpeg (via Remotion) | Format conversion |

## Core Concepts

### 1. Sequence (시간 기반)

```tsx
import { Sequence, AbsoluteFill } from 'remotion';

const Video = () => {
  return (
    <>
      <Sequence from={0} duration={60}>
        <Intro />
      </Sequence>
      <Sequence from={60} duration={120}>
        <MainContent />
      </Sequence>
      <Sequence from={180} durationInFrames={300}>
        <Outro />
      </Sequence>
    </>
  );
};
```

### 2. spring() for Animations

```tsx
import { spring } from 'remotion';

const scale = spring({
  frame,
  fps: 30,
  config: { mass: 1, stiffness: 100, damping: 20 }
});

<div style={{ transform: `scale(${scale})` }}>Animated</div>
```

### 3. interpolate() for Transitions

```tsx
import { interpolate } from 'remotion';

const opacity = interpolate(frame, [0, 30], [0, 1]);
const x = interpolate(frame, [0, 60], [200, 0], { extrapolateRight: 'clamp' });
```

### 4. Data-Driven Content

```tsx
const data = [
  { label: 'GPT-4', score: 95 },
  { label: 'Claude-3', score: 92 },
  { label: 'Gemini', score: 89 },
];

const BarChart = ({ data }) => (
  <div style={{ display: 'flex', gap: 20, alignItems: 'flex-end' }}>
    {data.map((item, i) => (
      <div key={i} style={{ textAlign: 'center' }}>
        <div style={{ 
          height: `${item.score}%`, 
          width: 60, 
          background: '#58C4DD',
          transition: 'height 0.5s ease'
        }} />
        <span>{item.label}</span>
      </div>
    ))}
  </div>
);
```

## Color Palettes

| Palette | Background | Primary | Secondary | Accent | Use Case |
|---------|-----------|---------|-----------|--------|----------|
| **Tech Dark** | `#0D1117` | `#58C4DD` | `#83C167` | `#FFFF00` | AI/Tech content |
| **Modern Light** | `#F8F9FA` | `#1A73E8` | `#34A853` | `#FBBC04` | Clean, modern |
| **Neon Cyber** | `#0A0A0A` | `#00F5FF` | `#FF00FF` | `#39FF14` | Systems/Architecture |
| **Warm Dark** | `#1C1C1C` | `#FF6B6B` | `#FFD93D` | `#6BCB77` | Approachable tech |

## Typography

```tsx
const theme = {
  fontFamily: 'Inter, sans-serif',
  titleSize: 72,
  headingSize: 48,
  bodySize: 32,
  captionSize: 24,
};
```

## Video Specs

| Property | Value |
|----------|-------|
| FPS | 30 |
| Aspect Ratio | 16:9 (1920x1080) or 9:16 (1080x1920) for Shorts |
| Format | MP4 (H.264) |
| Duration | 60-300 seconds typical |

## Rendering

```bash
# Preview in browser
npm start

# Render to MP4
npm run build

# Or with specific composition
npx remotion render Video out/video.mp4 --fps=30 --height=1080 --width=1920

# Shorts (9:16)
npx remotion render Video out/shorts.mp4 --fps=30 --height=1920 --width=1080
```

## Data-Driven Video Templates

### AI Benchmark Comparison

```tsx
const benchmarks = [
  { model: 'GLM-5', math: 92, code: 88, reasoning: 90 },
  { model: 'Claude-3.5', math: 95, code: 94, reasoning: 96 },
  { model: 'GPT-4o', math: 93, code: 91, reasoning: 94 },
];

const BenchmarkChart = ({ data }) => (
  <div style={{ background: '#0D1117', padding: 40 }}>
    <h2 style={{ color: '#58C4DD', fontSize: 48 }}>AI Model Benchmark</h2>
    {data.map((item, i) => (
      <div key={i} style={{ marginBottom: 20 }}>
        <span style={{ color: 'white' }}>{item.model}</span>
        <div style={{ display: 'flex', gap: 10, marginTop: 8 }}>
          {['math', 'code', 'reasoning'].map(metric => (
            <div key={metric} style={{ flex: 1 }}>
              <div style={{ 
                height: item[metric], 
                background: `hsl(${item[metric] * 1.2}, 70%, 50%)`,
                transition: 'all 0.5s ease'
              }}>
                <span style={{ color: 'white' }}>{item[metric]}</span>
              </div>
              <span style={{ color: '#888' }}>{metric}</span>
            </div>
          ))}
        </div>
      </div>
    ))}
  </div>
);
```

### GitHub Activity Stats

```tsx
const GitHubUnwrapped = ({ stats }) => (
  <div style={{ background: '#0D1117', minHeight: '100%' }}>
    <h1 style={{ color: '#58C4DD', fontSize: 72 }}>
      2025 GitHub Unwrapped
    </h1>
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 40 }}>
      <StatBox label="Total Commits" value={stats.commits} />
      <StatBox label="Repositories" value={stats.repos} />
      <StatBox label="Lines Changed" value={stats.lines} />
      <StatBox label="Languages Used" value={stats.languages} />
    </div>
  </div>
);
```

## ⚠️ Audio 추가: FFmpeg 방식 권장

Remotion의 `<Audio>` 컴포넌트는 로컬 렌더링 시 오디오가 포함되지 않는 문제가 있어요 (13kB만 출력됨).
**FFmpeg로 렌더링 후 별도 믹싱하는 방식이 더 확실해요.**

```bash
# 1. Remotion으로 영상만 렌더링
npx remotion render Video out/video_only.mp4 --fps=30 --height=1920 --width=1080 --quality=1

# 2. BGM 생성
ffmpeg -f lavfi -i "aevalsrc=0.8*sin(2*PI*440*t)+0.6*sin(2*PI*880*t):s=48000:d=45" \
  -af "afade=t=in:st=0:d=2,afade=t=out:st=43:d=2,loudnorm=I=-16" -ac 2 -y out/bgm.mp3

# 3. FFmpeg로 영상+오디오 믹싱
ffmpeg -i out/video_only.mp4 -i out/bgm.mp3 \
  -filter_complex "[1:a]aresample=48000[a1];[0:a][a1]amix=inputs=2:duration=shortest[aout]" \
  -map 0:v -map "[aout]" -c:v copy -c:a aac -b:a 192k -y out/final_video.mp4
```

### Remotion Audio 컴포넌트 사용법 (참고용)
- 파일을 `src/` 폴더에 배치
- `require()` 사용: `<Audio src={require("./bgm.mp3")} />`
- 검증: `ffprobe -v error -show_entries stream=bit_rate -of json out/video.mp4` → 오디오 bit_rate가 128kbps 이상이어야 함

## Decision Framework: Shorts vs Regular Video (BEFORE Creating)

| 예상 길이 | 판정 | 포맷 | 해상도 |
|-----------|------|------|--------|
| **≤60초** | **Shorts** ✅ | 9:16 (세로) | 1080×1920 |
| **>60초** | 일반 영상 | 16:9 (가로) | 1920×1080 |

> ⚠️ **반드시 렌더링 전에 결정** — 해상도/길이가 다르면 Composition 설정이 달라짐

## BGM 워크플로우 (외부 다운로드 방식 - 권장)

BGM은 **직접 생성하지 말고 외부에서 다운로드**할 것.

### 무료 로열티프리 소스
| 소스 | URL | 라이센스 |
|------|-----|---------|
| **Free Music Archive** | freemusicarchive.org/genre/Classical/ | CC-BY/PD |
| **Pixabay Music** | pixabay.com/music/search/new%20age/ | CC-BY |
| **MuseOpen** | musopen.org | Public Domain |
| **YouTube Audio Library** | youtube.com/audiolibrary | 무료 |

### 다운로드 → FFmpeg 믹싱 파이프라인
```bash
# 1. BGM 다운로드
curl -L "https://files.freemusicarchive.org/..." -o out/bgm.mp3

# 2. 영상 + BGM 믹싱 (30초로 자르기)
ffmpeg -y \
  -i out/video_only.mp4 \
  -i out/bgm.mp3 \
  -filter_complex "[1:a]atrim=0:30,asetpts=PTS-STARTPTS[a1]" \
  -map 0:v -map "[a1]" \
  -c:v copy \
  -c:a aac -b:a 128k \
  -shortest \
  out/final_short.mp4
```

### 숏츠 조건 자동 검증
```bash
ffprobe -v error -show_entries stream=width,height,duration \
  -of json out/final_short.mp4
# → 9:16 (w/h≈0.5625), ≤60s 확인
```

## Workflow

### Step 1: 판정 — Shorts or 일반 영상?
길이预估 → 포맷 결정 (위 Decision Framework 참조)

### Step 2: Plan
Create `PLAN.md` with:
- Video concept and narrative
- Scene breakdown with timing
- Data content to include
- Color palette selection

### Step 3: 데이터 수집
Web search로 타임라인/통계 데이터 수집 → `src/data/timelineData.ts` 구성

### Step 4: Code
```bash
npx create-video@latest my-video --template=blank
cd my-video
```
Create components in `src/` following the structure.

### Step 5: Preview
```bash
npm start
# Open http://localhost:3000 to preview
```

### Step 6: BGM 다운로드
FMA/Pixabay/MuseOpen에서 로열티프리 곡 다운로드

### Step 7: Render
```bash
# Shorts (9:16)
npx remotion render Video out/video_only.mp4 --fps=30 --height=1920 --width=1080 --quality=1

# 일반 영상 (16:9)
npx remotion render Video out/video_only.mp4 --fps=30 --height=1080 --width=1920 --quality=1
```

### Step 8: FFmpeg 믹싱
영상 + BGM 결합 (위 BGM 워크플로우 참조)

### Step 9: YouTube 업로드
`youtube-uploader` 스킬 사용 — 숏츠(≤60s)는 `--shorts` 플래그

## Quality Checklist

- [ ] All text readable (min 24px equivalent)
- [ ] Animations smooth (no janky transitions)
- [ ] Colors consistent across scenes
- [ ] Duration appropriate for content
- [ ] Audio synced
- [ ] Shorts 조건 충족 (9:16, ≤60s)
- [ ] File size reasonable (<500MB for 5min)

## Tips

1. **Preview first** — Always test at 480p before full render
2. **Use spring()** — Natural feeling animations
3. **Data from JSON** — Keep data separate from components
4. **Export constants** — Colors, fonts, spacing in theme file
5. **BGM은 생성而非 — 외부 다운로드**: Pixabay/FMA/MuseOpen 활용
6. **Shorts vs 일반영상 먼저 판정** — 이후 해상도 설정

## When Manim is Still the Right Tool

Despite this skill being the default for video, the previous Manim pipeline still owns a narrow niche: **LaTeX equation rendering and 3Blue1Brown-style mathematical geometry**. Reach for Manim (Manim Community Edition) when the user specifically asks for:

- Math proofs / equation derivations where the equation IS the visual (e.g. `MathTex`, `Tex`)
- Geometric transformations, parametric surfaces, 3D vector field visualizations
- "3Blue1Brown-style" or "make this math concept visual" prompts
- Algorithm visualization where the data structure's geometric structure carries meaning

For all other video requests (data dashboards, tech news, code walkthroughs, marketing, music videos, web animations), use Remotion. Manim requires `texlive-full` / `mactex` + Manim CE v0.20+ and is dramatically slower to iterate on than Remotion.

## Useful Links

- Docs: https://www.remotion.dev/docs
- Examples: https://remotion.dev/examples
- Templates: https://remotion.dev/templates
- GitHub: https://github.com/remotion-dev/remotion
