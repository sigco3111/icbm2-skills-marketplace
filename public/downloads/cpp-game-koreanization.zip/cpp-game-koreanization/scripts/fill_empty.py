#!/usr/bin/env python3
"""
Fill empty msgstr entries in a PO file using a translations.json dictionary.

Handles multiline msgid (continuation lines starting with `"`).
Uses longest-prefix matching for entries where msgid was concatenated with
previous translation attempts (common in historical PO files).

Usage:
    python3 fill_empty.py <input.po> <output.po> <translations.json>

Translation dictionary format (JSON):
{
    "msgid string": "msgstr translation",
    "_comment_...": "...",  // keys starting with _ are ignored
    ...
}
"""

import json
import re
import sys
from pathlib import Path


def parse_entries(content: str) -> list:
    """Parse PO file into list of {file, msgid, msgstr} entries.

    Handles multiline msgid/msgstr (continuation lines starting with ").
    """
    lines = content.split('\n')
    i = 0
    file_ref = None
    in_msgid = False
    in_msgstr = False
    msgid_parts = []
    msgstr_parts = []
    entries = []

    while i < len(lines):
        line = lines[i]
        if line.startswith('#:'):
            if file_ref and msgid_parts:
                entries.append({
                    'file': file_ref,
                    'msgid': ''.join(msgid_parts),
                    'msgstr': ''.join(msgstr_parts),
                })
            file_ref = line[2:].strip().split()[0] if line[2:].strip() else None
            msgid_parts = []
            msgstr_parts = []
            in_msgid = False
            in_msgstr = False
        elif file_ref:
            m = re.match(r'msgid\s+"(.*)"', line)
            if m:
                in_msgid = True
                in_msgstr = False
                msgid_parts = [m.group(1)]
            elif re.match(r'msgstr\s+"(.*)"', line):
                in_msgid = False
                in_msgstr = True
                m = re.match(r'msgstr\s+"(.*)"', line)
                msgstr_parts = [m.group(1)]
            elif line.startswith('"') and (in_msgid or in_msgstr):
                m = re.match(r'"(.*)"', line)
                if m:
                    if in_msgid:
                        msgid_parts.append(m.group(1))
                    else:
                        msgstr_parts.append(m.group(1))
        i += 1

    if file_ref and msgid_parts:
        entries.append({
            'file': file_ref,
            'msgid': ''.join(msgid_parts),
            'msgstr': ''.join(msgstr_parts),
        })

    return entries


def find_best_match(msgid, translations):
    """Find the best matching translation.

    Priority: exact match → longest prefix match (either direction).
    Returns translation string or None.
    """
    if msgid in translations:
        return translations[msgid]

    candidates = []
    for k in translations:
        if k and (msgid.startswith(k) or k.startswith(msgid)):
            candidates.append((len(k), translations[k]))

    if candidates:
        candidates.sort(reverse=True)
        return candidates[0][1]

    return None


def patch_po(content: str, translations: dict) -> tuple[str, int]:
    """Patch PO file in-place: fill empty msgstr using translations dict.

    Returns (patched_content, fill_count).
    """
    entries = parse_entries(content)
    filled = 0

    for e in entries:
        if e['msgid'] and not e['msgstr']:
            translation = find_best_match(e['msgid'], translations)
            if translation:
                e['msgstr'] = translation
                filled += 1

    # Re-serialize preserving comments and file_refs
    # This is a simplified serializer; for production, preserve full original structure
    out = []
    for e in entries:
        out.append(f'#: {e["file"]}')
        out.append(f'msgid "{e["msgid"]}"')
        out.append(f'msgstr "{e["msgstr"]}"')
        out.append('')

    return '\n'.join(out), filled


def main():
    if len(sys.argv) < 4:
        print(f"Usage: {sys.argv[0]} <input.po> <output.po> <translations.json>")
        sys.exit(1)

    input_po = Path(sys.argv[1])
    output_po = Path(sys.argv[2])
    translations_json = Path(sys.argv[3])

    translations = json.loads(translations_json.read_text(encoding='utf-8'))
    # Filter out developer note keys (starting with _)
    translations = {k: v for k, v in translations.items() if not k.startswith('_')}

    content = input_po.read_text(encoding='utf-8')
    patched, filled = patch_po(content, translations)
    output_po.write_text(patched, encoding='utf-8')

    print(f"Filled {filled} empty msgstr entries")
    print(f"Input:  {input_po} ({len(content):,} chars)")
    print(f"Output: {output_po} ({len(patched):,} chars)")
    print(f"Dictionary: {len(translations)} entries")


if __name__ == '__main__':
    main()