#!/usr/bin/env python3
"""
Compute true stats for a PO file with multiline msgid/msgstr support.

Use this instead of naive grep -c for accurate progress reporting.

Usage:
    python3 po_stats.py <file.po> [<file2.po> ...]
"""

import re
import sys
from collections import Counter
from pathlib import Path


def parse_entries(content: str) -> list:
    """Parse PO file, handling multiline msgid and msgstr correctly."""
    lines = content.split('\n')
    i = 0
    file_ref = None
    in_msgid = False
    in_msgstr = False
    msgid_parts = []
    msgstr_parts = []
    entries = []

    while i < len(lines):
        line = lines[i]
        if line.startswith('#:'):
            if file_ref and msgid_parts:
                entries.append({
                    'file': file_ref,
                    'msgid': ''.join(msgid_parts),
                    'msgstr': ''.join(msgstr_parts),
                })
            file_ref = line[2:].strip().split()[0] if line[2:].strip() else None
            msgid_parts = []
            msgstr_parts = []
            in_msgid = False
            in_msgstr = False
        elif file_ref:
            m = re.match(r'msgid\s+"(.*)"', line)
            if m:
                in_msgid = True
                in_msgstr = False
                msgid_parts = [m.group(1)]
            elif re.match(r'msgstr\s+"(.*)"', line):
                in_msgid = False
                in_msgstr = True
                m = re.match(r'msgstr\s+"(.*)"', line)
                msgstr_parts = [m.group(1)]
            elif line.startswith('"') and (in_msgid or in_msgstr):
                m = re.match(r'"(.*)"', line)
                if m:
                    if in_msgid:
                        msgid_parts.append(m.group(1))
                    else:
                        msgstr_parts.append(m.group(1))
        i += 1

    if file_ref and msgid_parts:
        entries.append({
            'file': file_ref,
            'msgid': ''.join(msgid_parts),
            'msgstr': ''.join(msgstr_parts),
        })

    return entries


def categorize(f):
    """Bucket a file path into a coarse category for reporting."""
    if not f:
        return 'unknown'
    if f.startswith('data/campaigns/'):
        parts = f.split('/')
        return f"campaigns/{parts[2]}" if len(parts) > 2 else 'campaigns'
    if f.startswith('data/core/'):
        parts = f.split('/')
        return f"core/{parts[2]}" if len(parts) > 2 else 'core'
    if f.startswith('data/'):
        return f.split('/')[1]
    if f.startswith('src/'):
        parts = f.split('/')
        return f"src/{parts[1]}" if len(parts) > 1 else 'src'
    return f.split('/')[0]


def analyze(path: Path):
    entries = parse_entries(path.read_text(encoding='utf-8'))
    real = [e for e in entries if e['msgid']]  # skip empty-header entries
    total = len(real)
    empty = [e for e in real if not e['msgstr']]
    translated = total - len(empty)
    pct = (translated / total * 100) if total else 0

    print(f"📊 {path.name}")
    print(f"   Total entries:    {total}")
    print(f"   Translated:       {translated} ({pct:.1f}%)")
    print(f"   Empty msgstr:     {len(empty)}")

    if empty:
        c = Counter(categorize(e['file']) for e in empty)
        print(f"   Top empty categories:")
        for cat_name, cnt in c.most_common(5):
            print(f"     - {cnt:>3} | {cat_name}")


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print(f"Usage: {sys.argv[0]} <file.po> [<file2.po> ...]")
        sys.exit(1)

    for p in sys.argv[1:]:
        analyze(Path(p))
        print()