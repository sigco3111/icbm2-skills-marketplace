#!/usr/bin/env python3
"""
build_verify.py — Fast (5-minute) build preflight for open source game forks.

Run this BEFORE committing to hours of i18n work on a foreign codebase.

The single-question test: "Can this game produce a runnable binary in <5 min on my machine?"

Why this exists: Wesnoth-kr wasted 90+ minutes assuming a macOS build would work, with
multiple failed strategies (master branch + Boost 1.90, 1.18 + system Boost, 1.18 + self-built
Boost 1.83 with rpath fixes). The lesson learned was: verify the build environment FIRST,
commit i18n work only after seeing a working binary.

Usage:
    python3 build_verify.py <repo_dir>
    python3 build_verify.py --type=auto <repo_dir>

Exit codes:
    0 = build verified, safe to proceed
    1 = build failed, do not proceed without user decision
    2 = project type not recognized, manual inspection needed
"""
import os
import sys
import subprocess
import json
import shutil
from pathlib import Path


def detect_project_type(repo_dir: Path) -> str:
    """Detect build system from repo files."""
    if (repo_dir / "SConstruct").exists() or (repo_dir / "SConstruct.py").exists():
        return "scons"
    if (repo_dir / "CMakeLists.txt").exists():
        return "cmake"
    if (repo_dir / "Cargo.toml").exists():
        return "cargo"
    if (repo_dir / "package.json").exists():
        return "npm"
    if (repo_dir / "Makefile").exists() or any((repo_dir / f).exists() for f in ["GNUmakefile", "makefile"]):
        return "make"
    if any((repo_dir / f).exists() for f in ["build.gradle", "build.gradle.kts", "settings.gradle"]):
        return "gradle"
    if any((repo_dir / f).exists() for f in ["pom.xml", "build.xml"]):
        return "maven"
    return "unknown"


def verify_npm(repo_dir: Path, timeout: int = 120) -> tuple[bool, str]:
    """Verify an npm-based project builds quickly. Best case (5-min target)."""
    if not shutil.which("npm"):
        return False, "npm not found"

    print("  → Running npm install...")
    result = subprocess.run(
        ["npm", "install", "--no-audit", "--no-fund"],
        cwd=repo_dir, capture_output=True, text=True, timeout=timeout
    )
    if result.returncode != 0:
        return False, f"npm install failed:\n{result.stderr[-1000:]}"

    print("  → Running npm run build (dry-run)...")
    pkg = json.loads((repo_dir / "package.json").read_text())
    scripts = pkg.get("scripts", {})
    build_cmd = scripts.get("build") or scripts.get("build:prod")
    if not build_cmd:
        # No build script — dev server only
        return True, "No build script. Use `npm run dev` to test in browser."

    print(f"  → Running: {build_cmd}")
    result = subprocess.run(
        ["npm", "run", "build"],
        cwd=repo_dir, capture_output=True, text=True, timeout=timeout
    )
    if result.returncode != 0:
        return False, f"npm run build failed:\n{result.stderr[-1000:]}"

    # Check for dist/ or build/ output
    dist_dirs = [d for d in ["dist", "build", "out", "public"] if (repo_dir / d).exists()]
    if not dist_dirs:
        return True, f"Build succeeded but no dist/ folder. Check output manually."

    artifacts = []
    for d in dist_dirs:
        for f in (repo_dir / d).rglob("*"):
            if f.is_file() and f.stat().st_size > 1000:
                artifacts.append(str(f.relative_to(repo_dir)))
                if len(artifacts) > 5:
                    break
    return True, f"Build succeeded. Artifacts:\n  " + "\n  ".join(artifacts[:5])


def verify_cmake(repo_dir: Path, timeout: int = 300) -> tuple[bool, str]:
    """CMake configure step only (don't do full build in 5-min preflight)."""
    if not shutil.which("cmake"):
        return False, "cmake not found"

    build_dir = repo_dir / "build-verify"
    if build_dir.exists():
        shutil.rmtree(build_dir)
    build_dir.mkdir()

    print(f"  → Running cmake configure in {build_dir}...")
    result = subprocess.run(
        ["cmake", ".."],
        cwd=build_dir, capture_output=True, text=True, timeout=timeout
    )
    if result.returncode != 0:
        return False, f"cmake configure failed:\n{result.stderr[-1500:]}"

    return True, f"CMake configure succeeded. Run 'cmake --build .' for full build (may be slow)."


def verify_scons(repo_dir: Path, timeout: int = 300) -> tuple[bool, str]:
    """SCons dry-run only (full build may take 30+ min for C++ games)."""
    if not shutil.which("scons"):
        return False, "scons not found"

    # SCons dry-run shows what would be compiled
    print("  → Running scons -n (dry run)...")
    result = subprocess.run(
        ["scons", "-n", "--warn=no-deprecated"],
        cwd=repo_dir, capture_output=True, text=True, timeout=timeout
    )
    combined = result.stdout + result.stderr

    # Check for known fatal signals
    fatal_signals = [
        ("Boost not found", "boost"),
        ("submodule not found", "submodule"),
        ("Prerequisites not met", "WARNING: "),
        ("No such file or directory", "No such file"),
    ]
    for label, pattern in fatal_signals:
        if pattern in combined and "yes" not in combined.split(pattern)[1][:100]:
            return False, f"SCons dry-run suggests issue: {label}\n{combined[-1000:]}"

    return True, f"SCons dry-run completed. Output: {len(combined)} bytes. Run full scons for actual build."


def verify_cargo(repo_dir: Path, timeout: int = 600) -> tuple[bool, str]:
    """Cargo check is fast and catches most issues."""
    if not shutil.which("cargo"):
        return False, "cargo not found"

    print("  → Running cargo check (fast verification, no full build)...")
    result = subprocess.run(
        ["cargo", "check"],
        cwd=repo_dir, capture_output=True, text=True, timeout=timeout
    )
    if result.returncode != 0:
        return False, f"cargo check failed:\n{result.stderr[-1500:]}"

    return True, "cargo check succeeded. Run `cargo build --release` for actual binary."


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(2)

    repo_dir = Path(sys.argv[-1]).resolve()
    if not repo_dir.exists():
        print(f"❌ Repo dir not found: {repo_dir}")
        sys.exit(2)

    project_type = detect_project_type(repo_dir)
    print(f"📦 Detected project type: {project_type}")
    print(f"📁 Repo: {repo_dir}")
    print()

    handlers = {
        "npm": ("HTML/JS/TS — usually quick (2-5 min)", verify_npm),
        "cargo": ("Rust — cargo check is fast", verify_cargo),
        "cmake": ("C++ with CMake — configure is fast, full build slow", verify_cmake),
        "scons": ("C++ with SCons — dry-run is fast, full build slow", verify_scons),
    }

    if project_type not in handlers:
        print(f"❌ Unknown project type. Manual inspection needed.")
        print(f"   Look for: package.json, CMakeLists.txt, Cargo.toml, SConstruct, Makefile")
        sys.exit(2)

    label, handler = handlers[project_type]
    print(f"🔍 {label}")
    print()

    success, message = handler(repo_dir)
    print()
    if success:
        print(f"✅ VERIFIED")
        print(f"   {message}")
        print()
        print("   Safe to proceed with i18n work.")
        sys.exit(0)
    else:
        print(f"❌ BUILD VERIFICATION FAILED")
        print(f"   {message}")
        print()
        print("   Do NOT commit to hours of i18n work. Consider:")
        print("   - Switching to a different game (JSON-based preferred)")
        print("   - Using GitHub Actions / Docker for build")
        print("   - Asking the user to confirm a longer preflight budget")
        sys.exit(1)


if __name__ == "__main__":
    main()
