---
name: cpp-game-koreanization
description: Fork a C++ open source game (Wesnoth, vcmi, OpenDiablo2, OpenRA) for Korean localization + custom feature patches. Use when user wants to Koreanize an open source game, add custom preferences/features, or build/fork a gettext-based C++ game. For JSON-data-based games (Phaser/Godot/HTML), see references/json-i18n-modpack.md — much faster.
category: software-development
---

# C++ Open Source Game Fork + Koreanization

Class-level workflow for forking a gettext-based C++ game into a Koreanized + customized derivative. Pattern proven on Battle for Wesnoth (`wesnoth/wesnoth` → `sigco3111/wesnoth-kr`).

## 🚨 CRITICAL: Phase 0 — Build verification (5 min, mandatory)

**Before any translation work, verify the build environment produces a working binary in 5 minutes.**

The Wesnoth experience burned 90+ minutes on:
- master branch + Homebrew Boost 1.90 → `static_visitor` API break
- 1.18 + system Boost 1.90 → pthread detection failure (Apple Clang)
- Self-built Boost 1.83 → install_name rpath chains + headerpad

**All of this is wasted work if you can't build the game at all.** Run `scripts/build_verify.py` first:

```bash
python3 scripts/build_verify.py /path/to/upstream/
```

**Decision tree after verification:**

| Project type | Verification result | Action |
|--------------|---------------------|--------|
| HTML/JS/TS (npm) | PASS | Proceed immediately. ~2 hours to working i18n. |
| Rust (cargo) | cargo check PASS | Proceed. ~3-5 hours to working i18n. |
| C++ (CMake/SCons) | PASS | Proceed with caution. Full build still slow. |
| C++ (CMake/SCons) | FAIL | **Stop.** Switch to GitHub Actions or different game. |

**For Koreanization candidates, strongly prefer JSON-data-based games** (Phaser 3, Godot, HTML, Unity Addressables) — see `references/json-i18n-modpack.md`. The sango-rising-dragons success took 2 hours end-to-end; the Wesnoth C++ effort took 90+ minutes just to fail at build.

## Start here (decision tree)

1. **Picking the target game or assessing feasibility?** Run `scripts/build_verify.py` first. Then read Phase 1.
2. **Working with PO files / translation stats?** Read `references/po-multiline-parsing.md` (the parser mismatch bug has burned hours before).
3. **Adding a custom feature patch?** Read `references/wesnoth-1.18-vs-master.md` for which branch to target and what files to touch.
4. **Trying to build on macOS?** Read `references/macos-boost-build-pitfalls.md` **before doing anything**. The TL;DR is "use GitHub Actions macos-15, not local macOS".
5. **JSON-data-based game instead of C++?** Read `references/json-i18n-modpack.md`. The data mod pack pattern is dramatically faster.
6. **About to declare the fork done?** Run through `references/i18n-progress-checklist.md`.

1. **Picking the target game or assessing feasibility?** Read Phase 1 only.
2. **Working with PO files / translation stats?** Read `references/po-multiline-parsing.md` (the parser mismatch bug has burned hours before).
3. **Adding a custom feature patch?** Read `references/wesnoth-1.18-vs-master.md` for which branch to target and what files to touch.
4. **Trying to build on macOS?** Read `references/macos-boost-build-pitfalls.md` **before doing anything**. The TL;DR is "use GitHub Actions Linux, not local macOS".
5. **About to declare the fork done?** Run through `references/i18n-progress-checklist.md`.

## When to use this skill

User signals:
- Wants to fork / Koreanize / improve an open source game (not a from-scratch build)
- Working with a gettext/PO-based C++ project (Wesnoth, Battle for Wesnoth, Battle of Wesnoth forks, Heroes III derivatives)
- Needs to add a custom feature (preference toggle, automation, UI addition) to an upstream game
- Building/testing a C++ game on macOS with SDL/Boost dependencies

User explicitly does NOT want this if:
- They are building a brand-new Godot/Unity game (use `godot-game-bootstrap` instead)
- They are modding an existing game without forking the engine
- The game uses JSON/YAML i18n, not gettext PO files — **see `references/json-i18n-modpack.md` for the much faster JSON-data mod pack pattern** (sango-rising-dragons, 2026-07-20)

## Phase 1 — Target assessment (15 min)

Before forking, verify the target supports what you want:

1. **Localization status**
   - `find . -name "*.po" -path "*/po/*"` — count existing PO files
   - Read existing `<lang>.po` for the target language (often partial, e.g. Wesnoth ko.po at 91% from 2019 work)
   - Check `LINGUAS` / `po/LINGUAS` for which languages are registered

2. **Build system**
   - Wesnoth uses **SCons** (SConstruct + SConscript)
   - vcmi uses **CMake**
   - OpenRA uses **nant + Makefile**
   - Identify before designing patches — patch format and `git apply` workflow differ

3. **Submodule map** (often missed — kills builds silently)
   - `cat .gitmodules` — list all submodules
   - Wesnoth needs `src/modules/lua` + `src/modules/mariadbpp` + `src/modules/mariadbpp/external/cmake-modules`
   - **Always** run `git submodule update --init --recursive` before any build attempt

4. **Branch strategy**
   - Stable LTS branches (Wesnoth 1.18) are easier to build than master
   - But API differences mean **patches must be rewritten per branch** (see references/wesnoth-1.18-vs-master.md)

## Phase 2 — Translation work (bulk of effort)

PO files are line-based but msgid/msgstr span multiple lines. The naive grep-based stats script **undercounts** empty entries. Use a real parser.

See `references/po-multiline-parsing.md` for the full technique. Key points:

- A msgid block collects continuation `"..."` lines until non-string line
- "Empty" means `msgstr ""` (with content on the line) — NOT absent msgstr
- For batch filling with a JSON dictionary, use **longest prefix matching** because historical PO files (Wesnoth, pre-2020) often have msgid concatenated from English + previous translation, e.g. msgid `"English..." + "한국어..."`
- Compute true progress with the multiline parser; `msgfmt --statistics` is a quick cross-check but doesn't show category breakdowns

Translation batch workflow:
1. Build `translations.json` mapping msgid → msgstr
2. Iterate `scripts/fill_empty.py` (provided below) which patches PO files in-place
3. Round-trip parse + regenerate stats after every batch
4. Aim for 95%+ completion before adding custom features

## Phase 3 — Custom feature patches

**Critical pitfall**: Patch files use **unified diff** format (with `--- a/path` / `+++ b/path` headers). The Hermes V4A format (`*** Begin Patch ... *** End Patch`) is **Hermes-only** and `git apply` will reject it with "No valid patches in input".

Always verify a patch:
```bash
# From a clean checkout state:
git apply --check path/to/patch.patch
git apply path/to/patch.patch
git diff --stat  # should show expected files
```

For multi-file patches with branching differences (Wesnoth 1.18 vs master), it is often easier to **regenerate the patch from a known-good state** than to hand-author unified diff:
```bash
# After manually editing files:
git diff src/foo.cpp src/bar.hpp > patches/my-feature.patch
```

See `references/wesnoth-1.18-vs-master.md` for the preference-system divergence and how to write version-specific patches.

## Phase 4 — Build environment

**Stop and read this if you are on macOS.**

macOS is **not a good build environment** for most C++ games with Boost dependencies. Even with the right Boost version, macOS-specific quirks (`install_name_tool`, rpath chains, header padding) can take hours to debug.

**Canonical solution: GitHub Actions on Linux**, then download the artifact. SDL/Boost are portable — Linux build will run on macOS unmodified.

If the user insists on local build:
- Wesnoth 1.18 master fails on macOS with Boost 1.90 (API break in `boost::static_visitor`)
- Wesnoth 1.18.7 + system Boost 1.90 fails because pthread detection needs `-pthread` env var setup the SCons script doesn't honor on Apple Clang
- Self-built Boost 1.83 with `-j8 install` succeeds but produces dylibs with `@rpath/libboost_*.dylib` install_name; `install_name_tool -id` + `-change` rewrites are needed, AND the original Boost build needs `-Wl,-headerpad_max_install_names` for cross-references to fit (this is the trap that makes it look like it should work but the final dylib still has unresolved cross-refs)

Full details: `references/macos-boost-build-pitfalls.md`

**Recommended path**: set up GitHub Actions workflow (`ubuntu-22.04` + `apt install libsdl2-dev libsdl2-image-dev libsdl2-mixer-dev libsdl2-ttf-dev libboost-all-dev`) and download artifact. 5 minutes to set up, 10 minutes per build, no macOS pain.

## Phase 5 — Verification without local build

If local build is blocked but patches + PO files are ready, verify in this order:

1. **PO file stats** — progress should be 95%+, fuzzy count reasonable (<400)
2. **Patch dry-run** — `git apply --check` on a clean checkout succeeds
3. **Diff stat review** — patches touch expected files only, no accidental edits
4. **PO round-trip** — `msgfmt -c -o /dev/null po/wesnoth-ko.po` (or equivalent) shows no syntax errors
5. **Linux CI build** — the canonical "did it work" check

Don't conflate "build environment is broken" with "code is broken". They are separate concerns and can ship independently.

## Pitfalls (encountered in real failures)

1. **V4A patch format incompatibility** — `*** Begin Patch` blocks are Hermes-only. `git apply` needs unified diff. Symptom: "No valid patches in input (allow with --empty)".

2. **Submodules not initialized** — `scons` reads `SConstruct` which tries to find lua/mariadbpp paths. Fails with cryptic errors if submodules absent. Always `git submodule update --init --recursive` first.

3. **Stats.py vs fill_empty.py parser mismatch** — if they parse PO differently, fill_empty reports "0 filled" while stats shows many empty. Use the same parser in both, or have fill_empty accept stats output as input.

4. **Longest prefix vs exact match** — historical PO files (Wesnoth mistzone 2019) have msgids concatenated from English + partial translation. Exact-match fill_empty.py catches 0; longest-prefix catches 45+.

5. **Boost 1.90 + Wesnoth master** — `boost::variant` static_visitor default constructor visibility changed from public to protected. Single-line compile error blocks entire build. Use 1.18 branch or wait for upstream patch.

6. **macOS install_name_tool without -headerpad** — `error: changing install names or rpaths can't be redone ... larger updated load commands do not fit`. Requires re-linking Boost with `-Wl,-headerpad_max_install_names`. Don't try to patch the dylibs after the fact.

7. **PO file "translations" key collision** — when JSON has both `"foo": "..."` (msgid) and `"_comment_foo": "..."` (developer note), the script needs to filter `_`-prefixed keys. Easy to miss; symptom: stat count off by developer note count.

8. **Empty msgid ≠ no msgid** — PO format requires every entry to have `msgid ""` (empty header entry for metadata like `Project-Id-Version`). Don't strip these thinking they're junk.

## Reference files

- `references/po-multiline-parsing.md` — the Python multiline PO parsing technique with longest-prefix matching
- `references/wesnoth-1.18-vs-master.md` — preference system and patch surface differences between Wesnoth branches
- `references/macos-boost-build-pitfalls.md` — full rpath/headerpad/pthread story with diagnosis commands
- `references/i18n-progress-checklist.md` — what to verify before declaring a localization fork "done"

## Scripts

- `scripts/fill_empty.py` — batch fill empty msgstr from translations.json (longest-prefix aware)
- `scripts/po-stats.py` — multiline-aware PO file statistics (true empty count + category breakdown)

## Memory interactions

User-level preference: "user prefers terse delegations and trusts recommendations; OK deferring build verification to CI when local env is hostile". Already in USER.md. Don't re-capture in this skill.