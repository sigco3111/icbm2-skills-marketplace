---
name: cpp-game-koreanization
description: Fork an open source game into a Koreanized + customized derivative. Covers gettext/PO C++ games (Wesnoth, vcmi, OpenDiablo2, OpenRA), JSON-data mod packs (Phaser 3, Godot, Unity Addressables — see references/json-i18n-modpack.md), and source-code ESM i18n extraction in browser games (Three.js + Vite, mshumer-style procedural FPS — see references/js-source-code-i18n.md). Use when user wants to fork / Koreanize / improve an open source game, or deploy one to Vercel (see references/procedural-threejs-vercel-deploy.md).
category: software-development
---

# Open-Source Game Fork + Koreanization (C++, JSON, ESM)

Class-level workflow for forking an open source game into a Koreanized + customized derivative. Three patterns proven across:

- **C++ with gettext/PO** — Battle for Wesnoth (`wesnoth/wesnoth` → `sigco3111/wesnoth-kr`).
- **JSON-data mod pack** — Phaser 3 / Godot / Unity Addressables / `sango-rising-dragons` (see `references/json-i18n-modpack.md`).
- **Browser ESM source-code extraction** — Three.js / Vite / procedural browser FPS / `mshumer/Claude-of-Duty` → `sigco3111/minimax-of-duty` (see `references/js-source-code-i18n.md` and `references/procedural-threejs-vercel-deploy.md`).

The three patterns share the same Phase 0 (target assessment) and Phase N (declaring the fork done) — only the middle translation work differs.

## 🚨 CRITICAL: Phase 0 — Build verification (5 min, mandatory)

**Before any translation work, verify the build environment produces a working binary in 5 minutes.**

The Wesnoth experience burned 90+ minutes on:
- master branch + Homebrew Boost 1.90 → `static_visitor` API break
- 1.18 + system Boost 1.90 → pthread detection failure (Apple Clang)
- Self-built Boost 1.83 → install_name rpath chains + headerpad

**All of this is wasted work if you can't build the game at all.** Run `scripts/build_verify.py` first:

```bash
python3 scripts/build_verify.py /path/to/upstream/
```

**Decision tree after verification:**

| Project type | Verification result | Action |
|--------------|---------------------|--------|
| HTML/JS/TS (npm) | PASS | Proceed immediately. ~2 hours to working i18n. Path: source-code extraction (see `references/js-source-code-i18n.md`). |
| Rust (cargo) | cargo check PASS | Proceed. ~3-5 hours to working i18n. |
| C++ (CMake/SCons) | PASS | Proceed with caution. Full build still slow. |
| C++ (CMake/SCons) | FAIL | **Stop.** Switch to GitHub Actions or different game. |
| Has JSON content manifest | n/a | **Prefer the data mod pack path** — see `references/json-i18n-modpack.md`. ~5× faster than source-code extraction when the manifest supports it. |

**For Koreanization candidates, strongly prefer JSON-data-based games** (Phaser 3, Godot, HTML, Unity Addressables) — see `references/json-i18n-modpack.md`. The sango-rising-dragons success took 2 hours end-to-end; the Wesnoth C++ effort took 90+ minutes just to fail at build.

## Start here (decision tree)

1. **Picking the target game or assessing feasibility?** Run `scripts/build_verify.py` first. Then read Phase 1.
2. **Working with PO files / translation stats?** Read `references/po-multiline-parsing.md` (the parser mismatch bug has burned hours before).
3. **Adding a custom feature patch (C++ / gettext game)?** Read `references/wesnoth-1.18-vs-master.md` for which branch to target and what files to touch.
4. **Trying to build on macOS?** Read `references/macos-boost-build-pitfalls.md` **before doing anything**. The TL;DR is "use GitHub Actions Linux, not local macOS".
5. **JSON-data-based game (Phaser / Godot / Unity Addressables / LÖVE content JSON)?** Read `references/json-i18n-modpack.md`. The data mod pack pattern is dramatically faster.
6. **Browser ESM game with hardcoded strings (Three.js / Vite / Vercel)?** Read `references/js-source-code-i18n.md`. Runtime `t('key')` extraction + locale toggle.
7. **Deploying a procedural Three.js game to Vercel?** Read `references/procedural-threejs-vercel-deploy.md`. Covers alias-vs-team-scope 302, `.vercel/` tracking, JS hash verification, auto-deploy GitHub App.
8. **About to declare the fork done?** Run through `references/i18n-progress-checklist.md`.

## When to use this skill

User signals:
- Wants to fork / Koreanize / improve an open source game (not a from-scratch build)
- Working with a gettext/PO-based C++ project (Wesnoth, Heroes III derivatives)
- Working with a JSON-data-based web game (Phaser 3, Godot, Unity Addressables, LÖVE content)
- Working with a browser ESM game whose strings live in JS/TS modules (Three.js, Babylon.js, PIXI, etc.)
- Needs to add a custom feature (preference toggle, automation, UI addition, language toggle) to an upstream game
- Building/testing a C++ game on macOS with SDL/Boost dependencies
- Wants to deploy an open-source browser fork to Vercel with public alias

User explicitly does NOT want this if:
- They are building a brand-new Godot/Unity game (use `godot-game-bootstrap` or `unity-game-bootstrap` instead)
- They are modding an existing game without forking the engine
- The target is a brand-new project with no upstream (use canvas-static-site-pipeline)

## Phase 1 — Target assessment (15 min)

Before forking, verify the target supports what you want:

### C++ / gettext games

1. **Localization status**
   - `find . -name "*.po" -path "*/po/*"` — count existing PO files
   - Read existing `<lang>.po` for the target language (often partial, e.g. Wesnoth ko.po at 91% from 2019 work)
   - Check `LINGUAS` / `po/LINGUAS` for which languages are registered
2. **Build system** — Wesnoth uses SCons, vcmi uses CMake, OpenRA uses nant + Makefile. Identify before designing patches.
3. **Submodule map** — `cat .gitmodules`. Always `git submodule update --init --recursive` before any build attempt.
4. **Branch strategy** — stable LTS branches easier to build than master, but API differences mean patches must be rewritten per branch.

### JSON-data games

1. **Manifest present?** `cat data/manifest.json` — if it lists `packs: [...]`, use the data mod pack path. If hardcoded content, fall through to source-code extraction.
2. **Schema id-field** — entries must have a stable `id` (or equivalent) for `mergeById` to work.

### Browser ESM games

1. **Single bundled SPA or multi-page?** Most procedural Three.js projects are single-bundle Vite SPAs.
2. **String surface** — `grep -nE "'[A-Z][a-z]+( [A-Z][a-z]+){0,3}'" src/ui/` to find hardcoded display text. Skeletal bone names (`'Hips'`, `'Spine1'`) show up but aren't user-visible.
3. **Locale awareness already present?** If the game already has `lang/<code>.json` files, take that path. If not, the source-code extraction reference applies.
4. **Build + deploy story** — Vite? Webpack? Parcel? Vercel-friendly all of them; the threejs deploy reference assumes Vite.

## Phase 2 — Translation work (bulk of effort)

### C++ / gettext path

PO files are line-based but msgid/msgstr span multiple lines. The naive grep-based stats script **undercounts** empty entries. Use a real parser.

See `references/po-multiline-parsing.md` for the full technique. Key points:

- A msgid block collects continuation `"..."` lines until non-string line
- "Empty" means `msgstr ""` (with content on the line) — NOT absent msgstr
- For batch filling with a JSON dictionary, use **longest prefix matching** because historical PO files (Wesnoth, pre-2020) often have msgid concatenated from English + previous translation, e.g. msgid `"English..." + "한국어..."`
- Compute true progress with the multiline parser; `msgfmt --statistics` is a quick cross-check but doesn't show category breakdowns

Translation batch workflow:
1. Build `translations.json` mapping msgid → msgstr
2. Iterate `scripts/fill_empty.py` (provided below) which patches PO files in-place
3. Round-trip parse + regenerate stats after every batch
4. Aim for 95%+ completion before adding custom features

### JSON-data mod pack path

See `references/json-i18n-modpack.md` (sango-rising-dragons worked example). The 5-step pattern: create `ko/` override directory, write per-id overrides, prepend to `manifest.json`. ~1-2 hours end-to-end, no source mod.

### Browser ESM source-code extraction path

See `references/js-source-code-i18n.md` for full architecture (thin `I18nSystem` + pure `t('key')` facade + co-located locale files), stage-by-stage extraction workflow, and 7 failure modes. The five stages:

1. Full scan for hardcoded display text (regex pattern in the reference).
2. Design the key namespace (`menu.*`, `hud.*`, `feed.*`, `quality.*`).
3. Mechanically extract `t('key')` then hand-tune.
4. Wire a one-way toggle inside the existing menu (default-locale = user's active language).
5. Verify visually with `tools/imagediff.mjs`, ship via auto-deploy.

The procedural Three.js deploy reference (`references/procedural-threejs-vercel-deploy.md`) covers the Vercel end: alias vs team-scope 302, `.vercel/` tracking, JS hash verification recipe, GitHub App auto-deploy.

## Phase 3 — Custom feature patches

**Critical pitfall**: Patch files use **unified diff** format (with `--- a/path` / `+++ b/path` headers). The Hermes V4A format (`*** Begin Patch ... *** End Patch`) is **Hermes-only** and `git apply` will reject it with "No valid patches in input".

Always verify a patch:
```bash
# From a clean checkout state:
git apply --check path/to/patch.patch
git apply path/to/patch.patch
git diff --stat  # should show expected files
```

For multi-file patches with branching differences (Wesnoth 1.18 vs master), it is often easier to **regenerate the patch from a known-good state** than to hand-author unified diff:
```bash
# After manually editing files:
git diff src/foo.cpp src/bar.hpp > patches/my-feature.patch
```

For browser ESM games, the "custom feature patch" is usually a language toggle button (see `references/js-source-code-i18n.md` Stage 4), a new menu setting, or a new key. **Don't ship features via patch files for browser games** — direct commits are simpler. Patches are for backporting to other branches.

See `references/wesnoth-1.18-vs-master.md` for the preference-system divergence and how to write version-specific patches.

## Phase 4 — Build environment

### C++ / macOS

**Stop and read this if you are on macOS.**

macOS is **not a good build environment** for most C++ games with Boost dependencies. Even with the right Boost version, macOS-specific quirks (`install_name_tool`, rpath chains, header padding) can take hours to debug.

**Canonical solution: GitHub Actions on Linux**, then download the artifact. SDL/Boost are portable — Linux build will run on macOS unmodified.

If the user insists on local build:
- Wesnoth 1.18 master fails on macOS with Boost 1.90 (API break in `boost::static_visitor`)
- Wesnoth 1.18.7 + system Boost 1.90 fails because pthread detection needs `-pthread` env var setup the SCons script doesn't honor on Apple Clang
- Self-built Boost 1.83 with `-j8 install` succeeds but produces dylibs with `@rpath/libboost_*.dylib` install_name; `install_name_tool -id` + `-change` rewrites are needed, AND the original Boost build needs `-Wl,-headerpad_max_install_names` for cross-references to fit (this is the trap that makes it look like it should work but the final dylib still has unresolved cross-refs)

Full details: `references/macos-boost-build-pitfalls.md`

**Recommended path**: set up GitHub Actions workflow (`ubuntu-22.04` + `apt install libsdl2-dev libsdl2-image-dev libsdl2-mixer-dev libsdl2-ttf-dev libboost-all-dev`) and download artifact. 5 minutes to set up, 10 minutes per build, no macOS pain.

### Browser ESM / macOS

Browser ESM games build on macOS without drama. Two specific patterns:

- **`npm install` is fast** (~1 minute for a Three.js + Vite project) — skip the GitHub Actions detour.
- **`npm run build` produces a `dist/` folder** that's directly Vercel-deployable. Vite auto-detects by Vercel's framework recognizer.

The procedural Three.js deploy reference (`references/procedural-threejs-vercel-deploy.md`) goes deeper on what's specific to Vercel deployments of these.

## Phase 5 — Verification

### C++ / gettext
1. **PO file stats** — progress should be 95%+, fuzzy count reasonable (<400)
2. **Patch dry-run** — `git apply --check` on a clean checkout succeeds
3. **Diff stat review** — patches touch expected files only, no accidental edits
4. **PO round-trip** — `msgfmt -c -o /dev/null po/wesnoth-ko.po` (or equivalent) shows no syntax errors
5. **Linux CI build** — the canonical "did it work" check

### JSON-data
1. **Manifest resolves** — `npm run dev` (or equivalent) starts without "missing pack" warning
2. **Override keys present** — open in browser, verify the override values render
3. **Merge correctness** — a record with only id + name override should inherit all other fields from base

### Browser ESM
1. **Pixel parity** — `tools/imagediff.mjs` (if the game ships a capture harness, e.g. Claude-of-Duty): 0 changed pixels vs pre-i18n. This is the load-bearing test — i18n by extraction is bit-perfect.
2. **New keys present in both locales** — `grep -c "menu.paused" dist/assets/index-*.js`. Both ko and en keys in built bundle.
3. **Locale default behavior** — `localStorage.clear()`, reload, click menu. First language is DEFAULT_LOCALE.
4. **Toggle live re-render** — open menu, click English. All row labels + presets + killfeed banner re-render.
5. **Persistence** — reload page. Language toggle selection survives.
6. **URL force** — open `?lang=en`. Browser ignores localStorage, uses en.
7. **Vercel auto-deploy check** — `git push` triggers fresh `index-<hash>.js` on the alias within ~10s.

Don't conflate "build environment is broken" with "code is broken". They are separate concerns and can ship independently.

## Pitfalls (encountered in real failures)

1. **V4A patch format incompatibility** — `*** Begin Patch` blocks are Hermes-only. `git apply` needs unified diff. Symptom: "No valid patches in input (allow with --empty)".

2. **Submodules not initialized** — `scons` reads `SConstruct` which tries to find lua/mariadbpp paths. Fails with cryptic errors if submodules absent. Always `git submodule update --init --recursive` first.

3. **Stats.py vs fill_empty.py parser mismatch** — if they parse PO differently, fill_empty reports "0 filled" while stats shows many empty. Use the same parser in both, or have fill_empty accept stats output as input.

4. **Longest prefix vs exact match** — historical PO files (Wesnoth mistzone 2019) have msgids concatenated from English + partial translation. Exact-match fill_empty.py catches 0; longest-prefix catches 45+.

5. **Boost 1.90 + Wesnoth master** — `boost::variant` static_visitor default constructor visibility changed from public to protected. Single-line compile error blocks entire build. Use 1.18 branch or wait for upstream patch.

6. **macOS install_name_tool without -headerpad** — `error: changing install names or rpaths can't be redone ... larger updated load commands do not fit`. Requires re-linking Boost with `-Wl,-headerpad_max_install_names`. Don't try to patch the dylibs after the fact.

7. **PO file "translations" key collision** — when JSON has both `"foo": "..."` (msgid) and `"_comment_foo": "..."` (developer note), the script needs to filter `_`-prefixed keys. Easy to miss; symptom: stat count off by developer note count.

8. **Empty msgid ≠ no msgid** — PO format requires every entry to have `msgid ""` (empty header entry for metadata like `Project-Id-Version`). Don't strip these thinking they're junk.

9. **Browser ESM: bone/anatomical names look translatable but aren't** — `grep -nE "'(Hips|Spine|Neck|Head)'"` matches in `src/ai/rig.js`, but these are skeletal rigging identifiers not user-visible strings. Translate only what is in `src/ui/`.

10. **Browser ESM: `t()` button textContent race** — buttons can't be created with `t()` textContent because locale isn't resolved until `I18nSystem.init()` runs, AFTER `UiSystem` is initialized. Solution: create with empty textContent, paint on first `syncFromConfig()`. The very first paint happens inside the `show()` callback the same frame the menu opens.

11. **Vercel team-scope URL trap** — `https://<project>-<hash8>-sigco3111s-projects.vercel.app` returns 302 to anon users. Public-readme URL must be `<project>.vercel.app` alias, not the team-scope production URL. `vercel ls` output's `▲ Aliased` line is the correct one.

12. **Vercel `.vercel/` in `.gitignore`** — `vercel deploy` writes `.vercel/` and adds it to `.gitignore`. Sigco3111 standard: drop `.vercel` from `.gitignore`, commit `project.json` + `README.txt`. Lets future sessions boot into the existing project.

## Reference files

- `references/po-multiline-parsing.md` — the Python multiline PO parsing technique with longest-prefix matching
- `references/wesnoth-1.18-vs-master.md` — preference system and patch surface differences between Wesnoth branches
- `references/macos-boost-build-pitfalls.md` — full rpath/headerpad/pthread story with diagnosis commands
- `references/i18n-progress-checklist.md` — what to verify before declaring a localization fork "done"
- `references/json-i18n-modpack.md` — JSON-data override path (Phaser 3, Godot, Unity Addressables, LÖVE content JSON) — sango-rising-dragons 2026-07-20
- `references/js-source-code-i18n.md` — runtime extraction path for browser ESM games with hardcoded strings (Three.js / Vite / Vercel deploy worked example) — minimax-of-duty 2026-07-27
- `references/procedural-threejs-vercel-deploy.md` — Vite → Vercel auto-deploy reference for procedural Three.js games (alias vs team-scope 302, `.vercel/` tracking, hash-verification recipe) — minimax-of-duty 2026-07-27

## Scripts

- `scripts/fill_empty.py` — batch fill empty msgstr from translations.json (longest-prefix aware) — C++ only
- `scripts/po-stats.py` — multiline-aware PO file statistics (true empty count + category breakdown) — C++ only
- `scripts/build_verify.py` — 5-minute pre-flight detect-and-verify across scons/cmake/cargo/npm — all paths

## Memory interactions

User-level preference: "user prefers terse delegations and trusts recommendations; OK deferring build verification to CI when local env is hostile". Already in USER.md. Don't re-capture in this skill.