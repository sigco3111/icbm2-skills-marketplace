# Localization fork — done checklist

Before declaring a localization fork "complete enough to push to GitHub" or "ready for PR upstream":

## Translation work

- [ ] PO file progress ≥ 95% via multiline parser (run `po_stats.py`)
- [ ] Cross-validate with `msgfmt --statistics` — numbers should match
- [ ] No msgfmt syntax errors: `msgfmt -c -o /dev/null po/<lang>.po` exits 0
- [ ] Empty msgstr < 50 entries (or document the 50 remaining as "low priority")
- [ ] Fuzzy entries reviewed (or document them as "known mismatches, leave for upstream")
- [ ] All `_, fuzzy` flags cleared for new translations (don't ship fuzzy)
- [ ] PO file header updated: `Language: ko` matches actual target language
- [ ] Plural-Forms line correct for target language (Korean: `nplurals=1; plural=0;`)

## Custom features

- [ ] Patch applies cleanly: `git apply --check patches/*.patch` exits 0
- [ ] Patch applies on a clean checkout: `git checkout -- . && git apply patches/*.patch`
- [ ] `git diff --stat` shows only intended files modified
- [ ] No accidentally-included binary blobs or large data files
- [ ] No upstream commit hashes referenced in comments (will go stale)
- [ ] New strings added in source are mirrored in PO file (if applicable)
- [ ] Preference/setting defaults are sensible (don't ship with feature "on" by default unless that's clearly desired)

## Repository hygiene

- [ ] README explains: what the fork is, who it's for, how to build/use
- [ ] LICENSE inherited from upstream (GPL v2 for Wesnoth)
- [ ] `.gitignore` excludes build artifacts, upstream clone, IDE files
- [ ] No `_comment_*` keys in shipped translations.json (filter `_`-prefixed)
- [ ] No commits include `upstream/` (it's the original repo, should be cloned separately)
- [ ] Branching: decide whether to fork master or 1.18 and stick to it

## Build verification (if applicable)

- [ ] Local build succeeds OR GitHub Actions workflow succeeds
- [ ] Binary artifact is uploaded (release page or actions artifact)
- [ ] Smoke test: launch game, change one preference, exit cleanly
- [ ] PO file actually loads: launch game, switch language to fork target, verify a known translated string appears in UI

## Documentation

- [ ] BUILD.md / INSTALL.md covers the actual build commands used
- [ ] KNOWN_ISSUES.md or section lists known bugs, broken features, blockers
- [ ] CONTRIBUTING.md describes translation review process
- [ ] CHANGELOG.md (or release notes) lists the localization fork's version

## Optional but recommended

- [ ] CI workflow that rebuilds on push (catches upstream merge conflicts early)
- [ ] Tag releases so users can pin to a specific fork revision
- [ ] Reference original translator (mistzone 2019 for Wesnoth) in README to maintain attribution chain
- [ ] Mention the upstream issue/PR if one exists, so future contributors can find context