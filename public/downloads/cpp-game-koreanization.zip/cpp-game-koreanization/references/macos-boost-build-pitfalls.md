# macOS + Boost + C++ game build — the full story

This is the canonical failed-build journey. Reading this first will save 90+ minutes.

## TL;DR

**Don't try to build Wesnoth (or any Boost-heavy C++ game) locally on macOS in 2026.** Use GitHub Actions on Linux, download the artifact, run on macOS. The Linux binary works on macOS because SDL/Boost are portable.

If you must build locally, use a Linux VM or Docker. Below is what happens if you ignore this.

## The four failure modes

### Failure 1: master branch + Homebrew Boost 1.90

**Symptom**:
```
src/formula/callable_objects.cpp:538:54: error: base class 'boost::static_visitor<variant>' has protected default constructor
```

**Cause**: Wesnoth master (1.19.25+dev) was written against Boost 1.83 and earlier. Boost 1.90 changed `boost::static_visitor`'s default constructor visibility from public to protected. One line of code, entire build blocked.

**Detection**:
```bash
grep -n "static_visitor" /opt/homebrew/include/boost/variant/static_visitor.hpp
```

**Fix**: Not worth it for a fork. Use 1.18 branch.

### Failure 2: 1.18 branch + system Boost 1.90 — pthread detection

**Symptom**:
```
Checking for C library pthread... no
WARNING: Base prerequisites are not met
```

**Cause**: SCons' `CheckLibWithHeader` for pthread on Apple Clang doesn't honor `LDFLAGS="-pthread"`. Apple Clang has different pthread handling than GCC.

**Detection**:
```bash
# Manually test pthread detection:
echo '#include <pthread.h>
int main(){pthread_create(0,0,0,0);return 0;}' | gcc -x c - -lpthread
```

**Fix**: Not a flag fix. Apple Clang needs different invocation. Real fix is Boost itself compiled with `-pthread` so the binary has pthread baked in.

### Failure 3: Self-built Boost 1.83 — install_name rpath

**Symptom**:
```
dyld[12345]: Library not loaded: @rpath/libboost_iostreams.dylib
```

**Cause**: `b2 install` produces dylibs with `@rpath/libboost_*.dylib` install_name by default. The SCons `CheckBoost` runs a tiny compiled probe that tries to dlopen these — and fails because `@rpath` is not set in the probe binary.

**Partial fix**:
```bash
# Change install_name from @rpath to absolute path:
for dylib in libboost_*.dylib; do
    install_name_tool -id "/Users/mac/work/boost-install/lib/$dylib" "$dylib"
done
```

This fixes the `id` (self-reference) but NOT the cross-references inside other dylibs.

### Failure 4: Cross-reference install_names — headerpad

**Symptom** (after install_name_tool -change on cross-refs):
```
error: changing install names or rpaths can't be redone for: libboost_coroutine.dylib
(for architecture arm64) because larger updated load commands do not fit
(the program must be relinked, and you may need to use -headerpad or -headerpad_max_install_names)
```

**Cause**: When you replace `@rpath/libboost_context.dylib` with `/Users/mac/work/.../libboost_context.dylib` (longer absolute path), the load command doesn't fit in the existing space. Solution is `otool -l ... -headerpad_max_install_names` during link.

**Real fix**:
```bash
# Rebuild Boost with this flag:
./b2 ... cflags="-Wl,-headerpad_max_install_names" cxxflags="-Wl,-headerpad_max_install_names" ...
```

After this, `install_name_tool -change` will succeed for cross-references.

### Combined time cost

| Step | Time |
|---|---|
| Diagnose Failure 1 | 5 min |
| Diagnose Failure 2 | 10 min |
| Diagnose Failure 3 | 30 min (download + build Boost 1.83) |
| Diagnose Failure 4 | 30 min |
| Apply fixes 3+4 | 20 min |
| Verify build | 30 min (Wesnoth compile is slow) |
| **Total** | **~2 hours** |

vs. **5 minutes to write a GitHub Actions workflow and 10 minutes per build**.

## What works on macOS without this pain

- SDL-only games (no Boost): fine. Use `pkg-config` and you're done.
- Games with system Boost that's already correct version: fine.
- Games with header-only Boost dependencies: fine.
- Anything with Boost > 1.5 deps AND non-system Boost version: **don't**, use CI.

## GitHub Actions template

```yaml
name: build
on: [push, pull_request]
jobs:
  build:
    runs-on: ubuntu-22.04
    steps:
      - uses: actions/checkout@v4
        with:
          submodules: recursive
      - name: Install deps
        run: sudo apt install -y libsdl2-dev libsdl2-image-dev libsdl2-mixer-dev libsdl2-ttf-dev libboost-all-dev libpango1.0-dev libcairo2-dev libcurl4-openssl-dev
      - name: Build
        run: scons build=release cxx_std=20 jobs=4
      - name: Upload artifact
        uses: actions/upload-artifact@v4
        with:
          name: wesnoth-linux
          path: wesnoth
```

5 minutes to set up. 10 minutes per build. No host machine pain.

## Wesnoth-specific environment

For scons options, the **right** boost variables on 1.18:
```bash
scons --config=force \
  boostdir=/path/to/boost/include \
  boostlibdir=/path/to/boost/lib \
  build=release \
  cxx_std=20 \
  cxx_toolchain=clang++ \
  jobs=8
```

Note: `boostdir` should be the **include directory**, not the install root. SCons auto-appends nothing.

For 1.19+ master, the variable names changed:
```bash
export BOOST_ROOT=/path/to/boost
export Boost_INCLUDE_DIR=/path/to/boost/include
export Boost_LIBRARY_DIR=/path/to/boost/lib
```

Always check the target branch's SConstruct for the variable names — they do change between Wesnoth versions.