# Wesnoth branch preference system — 1.18 vs master

Adding custom preferences (auto-end-turn, auto-combat, etc.) requires different patch surface depending on which branch you target.

## master (1.19+)

Uses a macro-based preference registry in `src/preferences/preferences_list.hpp`:

```cpp
ADDPREF(disable_auto_moves)
```

This expands (via `PREF_GETTER_SETTER` macro in `preferences.hpp`) to a getter, setter, default value, and entry in an enum. UI registration is in `src/gui/dialogs/preferences_dialog.cpp`:

```cpp
register_bool("disable_auto_moves", true,
    []() {return prefs::get().disable_auto_moves();},
    [](bool v) {prefs::get().set_disable_auto_moves(v);});
```

**Patch surface for adding `auto_end_turn`:**
1. `src/preferences/preferences_list.hpp` — add `ADDPREF(auto_end_turn)` (3 lines)
2. `src/playsingle_controller.cpp` — add check in `play_human_turn()` (5-10 lines)
3. `src/gui/dialogs/preferences_dialog.cpp` — add `register_bool` block (3 lines)

Total: ~15 lines added.

## 1.18 (1.18.7 stable)

Uses individual function declarations per preference, scattered across `src/preferences/*.hpp` and `.cpp`:

`src/preferences/general.hpp`:
```cpp
bool disable_auto_moves();
void set_disable_auto_moves(bool value);
```

`src/preferences/general.cpp`:
```cpp
bool disable_auto_moves()
{
    return get("disable_auto_moves", false);
}

void set_disable_auto_moves(bool value)
{
    preferences::set("disable_auto_moves", value);
}
```

UI registration in `src/gui/dialogs/preferences_dialog.cpp` (different syntax — function references, not lambdas):
```cpp
register_bool("disable_auto_moves", true,
    disable_auto_moves, set_disable_auto_moves);
```

**Patch surface for adding `auto_end_turn`:**
1. `src/preferences/general.hpp` — add 2 function declarations (6 lines)
2. `src/preferences/general.cpp` — add 2 function definitions (12 lines)
3. `src/playsingle_controller.cpp` — add check in `play_human_turn()` (5-10 lines)
4. `src/gui/dialogs/preferences_dialog.cpp` — add `register_bool` (3 lines)

Total: ~30 lines added.

## Verifying the patch applies

Patches are written as unified diff with `--- a/path` / `+++ b/path` headers. Always verify with `git apply --check` on a clean checkout:

```bash
# From the upstream/ directory:
git checkout src/preferences/general.hpp src/preferences/general.cpp \
            src/gui/dialogs/preferences_dialog.cpp src/playsingle_controller.cpp
git apply --check ../patches/auto-progression-1.18.patch
git apply ../patches/auto-progression-1.18.patch
git diff --stat
```

If the patch fails to apply, do NOT try to hand-edit the diff — re-apply the changes manually, then `git diff` to regenerate the patch. The hand-edited diffs almost always break because line numbers shift between Wesnoth versions and even between patch attempts.

## Branching choice guidance

- **Fork for users / bug fixes / small features**: target **1.18.7**. Stable, builds, fewer surprises.
- **Fork for new game features that need modern C++**: target **master**, accept that you'll need Linux CI.
- **Upstream PR**: target **master**. Submit to wesnoth/wesnoth via PR.

Never ship a fork that targets both branches with the same patch file — the differences will cause divergence pain.