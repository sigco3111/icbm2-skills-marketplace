# JSON-based i18n — data mod pack pattern (sango-rising-dragons, 2026-07-20)

When a game stores its content in JSON files (Phaser 3, Godot, Unity Addressables, LÖVE2D, Bevy assets), Koreanization is **dramatically simpler** than the gettext/PO flow. The data mod pack pattern:

1. **Don't touch the source code** — game has a manifest of content packs loaded at startup
2. **Add a `ko/` (or `<lang>/`) directory** with JSON files containing only the fields you want to override
3. **Edit `manifest.json` to put the new pack first** so its values win the merge
4. **Override only what you need** — for the rest, the original data is the fallback

Reference implementation: `ryantsai/sango-rising-dragons` (Phaser 3 + TypeScript, MIT-style permissive).

## Why this works

Games with manifest-based content loading already have a merge story. The schema-driven `mergeById(base, extra)` pattern (combine by `id` field, deep-merge per-entry) means a new pack is just a JSON tree that wins on id collision and inherits everything else.

For sango-rising-dragons, the loader was:

```ts
function mergeById<T extends { id: string }>(base: T[], extra: T[]): T[] {
  const map = new Map(base.map((e) => [e.id, e]));
  for (const e of extra) map.set(e.id, { ...map.get(e.id), ...e });
  return [...map.values()];
}
```

So adding `ko/officers.json` with `[{ "id": "caocao", "name": "조조" }]` produced:

```json
{
  "id": "caocao",
  "name": "조조",       // overridden by ko pack
  "faction": "wei",      // inherited from base
  "war": 78,             // inherited
  "int": 92              // inherited
  // ... etc
}
```

## How to detect a game supports this pattern

Grep for these signals in the source:

```bash
# Manifest-based content
grep -r "manifest" src/ | grep -i "pack\|content\|load"
grep -r "mergeById\|merge.*id\|byId" src/

# JSON data directories
ls -d data/ assets/ content/ public/data/

# Pattern: data packs with manifest
cat data/manifest.json
```

If the game has `data/manifest.json` with a `packs: [...]` array — you can use this pattern. If it has a single monolithic JSON or hard-coded content, the pattern needs more work.

## Full workflow (sango-rising-dragons)

```bash
# 1. Inspect data structure
cat public/data/manifest.json
ls public/data/base/

# 2. Build translations.json (msgid → msgstr)
#    49 officers, 20 cities, 11 factions, 12 events, 5 items, 7 skills = 104 entries
cat > po-translations.json << 'EOF'
{
  "caocao": "조조",
  "曹操": "조조",
  ...
}
EOF

# 3. Build ko/ override files (only override fields you want to localize)
mkdir -p public/data/ko
cat > public/data/ko/cities.json << 'EOF'
[
  {"id": "beiping", "name": "북평"},
  {"id": "jinyang", "name": "진양"}
  ...
]
EOF

# 4. Prepend to manifest (so ko wins merge conflicts)
cat > public/data/manifest.json << 'EOF'
{ "packs": ["ko", "base"] }
EOF
```

5. **HTML lang attribute + Noto Sans KR font** (for the locale switch to feel native):

```html
<html lang="ko">
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@400;500;700&display=swap" rel="stylesheet">
<style>
  body { font-family: "Noto Sans KR", "Noto Sans TC", "Microsoft JhengHei", sans-serif; }
</style>
```

6. **In-source string handling**: the sango-rising-dragons game had ~100+ hard-coded Chinese strings in HTML and TypeScript (button labels, log messages, modal text). These need a separate pass:

```bash
# Find all CJK strings
grep -rn "[一-鿿]" src/ index.html | head -30

# Replace one by one (script the simple ones, hand-edit the complex ones)
python3 -c "
import re
mapping = {
    '指令點不足': '명령점 부족',
    '儲存': '저장',
    # ... etc
}
content = open('src/hud.ts').read()
for old, new in mapping.items():
    content = content.replace(old, new)
open('src/hud.ts', 'w').write(content)
"
```

## When this pattern does NOT work

- **Hard-coded strings only** — if the game has no JSON content and no manifest, you must edit source code (and that means dealing with build systems).
- **Text baked into images** (bitmap fonts, pre-rendered textures) — needs image replacement, not text substitution.
- **C++ gettext games** — these use PO files, not JSON. Different technique. The `po-multiline-parsing.md` reference applies.

## Comparison vs gettext PO

| Aspect | PO files (Wesnoth) | JSON modpack (sango-rising-dragons) |
|--------|---------------------|--------------------------------------|
| Source code mods | 0 (only PO files) | 0 (only JSON + manifest) |
| Empty entry detection | Multiline parser required | None — schema-driven, no "empty" concept |
| Longest-prefix matching | Required (Wesnoth mistzone 2019 pattern) | Not needed — id-based merge is clean |
| Build environment | C++/Boost/SDL — high friction | None — runs in browser, just `npm run dev` |
| Total effort to 95%+ | Hours to days | 1-2 hours for 100+ entries |
| Verification | Build + smoke test | Playwright screenshot of running game |

## Other games to consider with this pattern

- **Caves of Qud** (JSON content)
- **Dominion / card games** (JSON card data)
- **Tactic Game Engine** style projects
- **Godot 4 projects** with `.tres` resource files (convert to JSON via godot --headless)
- **Any itch.io open-source game** that uses JSON for content

The key question to ask in Phase 0 target assessment: "Does this game load its content from JSON files I can override without touching the source?"
