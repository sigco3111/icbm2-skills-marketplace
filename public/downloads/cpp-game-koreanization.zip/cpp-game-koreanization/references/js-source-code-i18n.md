# JS/TS source-code i18n — runtime extraction pattern (minimax-of-duty, 2026-07-27)

When a browser game ships with **hardcoded strings in JS/TS modules** (no JSON content layer, no manifest), Koreanization requires editing source — the opposite of the data-modpack pattern in `json-i18n-modpack.md`. This reference covers the runtime extraction pattern: introducing a small `t('key')` subsystem, extracting every user-visible string, and shipping both languages statically.

Worked example: `mshumer/Claude-of-Duty` (MIT) — Three.js r180 + Vite, 11 subsystems, ~55k LOC. Fork at `sigco3111/minimax-of-duty`.

## When this pattern applies

- ESM/Three.js/Babylon.js/PIXI/Phaser 3 single-page browser games
- Vite/Vanilla `npm run dev` workflow (any build that produces a `dist/` for Vercel/Cloudflare Pages)
- Strings are inlined in `.js`/`.ts` modules, **no runtime data layer to override**
- The codebase follows a `static id` subsystem registry pattern (often the case with multi-system game engines like `Engine.add(RenderSystem).add(UiSystem)…`)

If the game has a data manifest + JSON content packs, **stop and use `references/json-i18n-modpack.md` instead** — it's ~5× faster.

## Architecture: thin subsystem + pure-function facade

Two-API design proven by Claude-of-Duty fork:

```js
// src/i18n/index.js — pure-function facade usable from anywhere
export function t(key, params) {
  const active = TABLES[_locale]?.[key];
  const value = active ?? FALLBACK[key] ?? key;  // key itself is the last-resort fallback
  if (!params) return value;
  return value.replace(/\{(\w+)\}/g, (m, k) =>
    Object.prototype.hasOwnProperty.call(params, k) ? String(params[k]) : m
  );
}
export function setLocale(loc) { /* ... writes through to localStorage */ }
export function getLocale() { return _locale; }

// Subsystem wrapper — only exists so the engine registry sees "i18n" cleanly
export class I18nSystem {
  static id = 'i18n';
  static deps = [];
  init(ctx) {
    _locale = resolveLocale();
    document.documentElement.lang = _locale;
    window.__I18N__ = { t, setLocale, getLocale, SUPPORTED_LOCALES };
    return this;
  }
}
```

Key choices:

1. **Pure-function facade separate from the subsystem**. t() is module-scoped state, not ctx.get('i18n').t() — avoids hydration ceremony in already-init'd code (menus, banners, killfeed).
2. **English as FALLBACK**, not as primary. Missing key in active locale → English → key string. Never throw during render.
3. **Locale resolution is boot-once**: `?lang=` URL > `localStorage.<prefix>.lang` > `navigator.language` > DEFAULT_LOCALE. Inside `init()`.
4. **`localStorage` write-through**: every `setLocale()` call writes to storage so other tabs and reloads agree.
5. **`<html lang="…">`** set in init() — fonts that key off `lang` attribute (and accessibility tools) pick up the active language.

## Locale files: static, co-located

```js
// src/i18n/locales/ko.js
export const ko = {
  'menu.paused': '일시정지',
  'menu.graphics': '그래픽 품질',
  'menu.fov': '시야각',
  'hud.health': '체력',
  'feed.enemyEliminated': '적 처치',
  'xp.headshot': '+{xp} XP · 헤드샷',     // param interpolation
  'quality.ultra': '울트라',
  // ...
};

// src/i18n/locales/en.js — fallback. New translations land here first.
export const en = { /* same keys, English values */ };
```

Two-file pattern, not nested: easier to diff, easier to grep, easier to add a third language.

## Extraction workflow (Claude-of-Duty fork, 5 stages)

### Stage 1 — full scan for hardcoded display text

```bash
# Per-quote pattern with capitalized word sequences (English/COD-style strings)
grep -rn -E "'(Reload|Health|Armour|Armor|Ammo|Paused|Resume|Defaults|Graphics Preset|Enemy Eliminated|HEADSHOT|Loading|Generating|You Died|Stance|Sprint|Crouch|Slide|Inspect|Mouse Sensitivity|Field Of View|Invert Look|Volume|Quality|Low|Medium|High|Ultra|Headshot|Kill|Eliminated|Respawn)'" src/ui/

# Filter out skeletal-bone names ('Hips', 'Spine', 'Neck') and font names
grep -rnE "'(Hips|Spine|Neck|Head|Avenir|Helvetica|Inter|Impact)'" src/ai/ src/ui/   # bones — DO NOT translate
```

Most text lives in `src/ui/`. Bones in `src/ai/rig.js` are not user-visible.

### Stage 2 — design the key namespace

Group by surface, not by grammar:
- `menu.*` — pause/settings menu (graphics, sensitivity, FOV, invert-look, language, resume, defaults, hint)
- `hud.*` — vitals widget (health, armour, ammo, reload)
- `match.*` — scoreboard (score, timeLeft)
- `feed.*` — killfeed (enemyEliminated, headshot)
- `xp.*` — XP banner text (xp.regular, xp.headshot with `{xp}` param)
- `quality.*` — preset names (low/medium/high/ultra)

Don't translate bone/anatomical names ('Spine1', 'ClavicleR').

### Stage 3 — extract mechanically, then hand-tune

```js
// Before
this.banner.show('Enemy Eliminated', e.headshot ? '+150 XP · HEADSHOT' : '+100 XP');

// After
this.banner.show(
  t('feed.enemyEliminated'),
  e.headshot ? t('xp.headshot', { xp: 150 }) : t('xp.regular', { xp: 100 })
);
```

The `{key}` interpolation in `t()` should reuse real number values, not magic constants — see the match score formatter pattern below for clean separation of number from label.

### Stage 4 — wire a one-way toggle inside the existing menu

Default locale (the one the first user sees) is **the user's active language** — for Korean-first operators, set `DEFAULT_LOCALE = 'ko'`. Add a segmented control in the pause menu:

```js
const langRow = this._row(t('menu.language'));
const langSeg = el('div', 'ow-seg', langRow);
this.langBtns = [];
for (const loc of SUPPORTED_LOCALES) {
  const lbl = loc === 'ko' ? '한국어' : 'English';
  const b = el('button', null, langSeg, lbl);
  b.addEventListener('click', () => {
    setLocale(loc);          // writes localStorage + emits CustomEvent
    this.paintMenu();        // re-render row labels live (cheap)
    this.syncFromConfig();   // refresh highlight + quality buttons
  });
  this.langBtns.push([b, loc]);
}
```

Two details that look trivial but matter:

- **Buttons get `textContent = ''` at construction**, then paint on first `syncFromConfig()` and every paint. Otherwise `t()` is called once with the wrong locale locked in and re-rendering fights itself.
- **`syncFromConfig()` paints the preset button labels** (`quality.low / medium / high / ultra`). This means locale-switching + config-sync unify into one path that always reads from `t()`.

For any menu that has paint-after-build side effects, register an `onLocaleChange(fn)` subscriber that calls `paintMenu()`. Cheap, no rebuild of DOM nodes.

### Stage 5 — verify visually, then ship

The Claude-of-Duty fork ran the existing `tools/baseline.mjs` + `tools/imagediff.mjs` gate after the i18n change. Result: pixel-identical to pre-i18n on all 11 capture shots. **This is the proof i18n-by-extraction is bit-perfect** — text rendering changes label strings but layout/positioning/hue are independent.

```bash
npm run build                          # produces dist/
node tools/baseline.mjs --shot=combat  # captures 'before' baseline
# ...edit code, npm run build again...
node tools/imagediff.mjs --shot=combat # must report 0 changed pixels
```

## Pitfalls

1. **`src/ui/index.js` line 200 stale XP magic numbers** — the original used `+100 XP` / `+150 XP` as bare strings. Extract with `t('xp.regular', { xp: 100 })`, not with a separate key per XP value. Adding a fourth XP tier later means adding one locale key, not rewriting call sites.
2. **Buttons can't be created with `t()` textContent** — locale isn't resolved until `I18nSystem.init()` runs, after `UiSystem` is already initialized. Solution: create with `''`, paint on first `syncFromConfig()`. The very first paint happens inside the `show()` callback the same frame the menu opens.
3. **Game-side `el(...)` helper** (Claude-of-Duty has `el(tag, class, parent, text)`) is great for the first paint but is the wrong abstraction when text changes — it creates a new node. Keep DOM refs (`this.resumeBtn`, `this._hintEl`, `this._defaultsBtn`) and call `setText(el, t('key'))` on locale change.
4. **Bone names** in animation rigs (`'Hips'`, `'Spine1'`, `'ClavicleR'`, `'UpLegL'`) are not user-visible but show up in `grep -nE "'[A-Z][a-z]+([ ][A-Z][a-z]+){0,4}'"`. Don't translate them — they map to procedural rigging math that breaks if renamed.
5. **Avoid `localStorage.removeItem('minimax.lang')` in dispose**. The whole point is persistence-across-reloads; even on engine disposal, the next page load should respect the user's choice.
6. **`window.__I18N__` in dev only** — useful for the DevTools console (`__I18N__.t('menu.paused')`) but the agent should never depend on it. Always import `t` directly in production code.
7. **The `setLocale()` invalidates nothing** — it doesn't trigger a Vite HMR if you imported `t` once at module scope. Either import inside render functions, or ensure the boot-time `resolveLocale()` correctly reads the same storage key the toggle writes. Verified on Claude-of-Duty: no HMR after switch, but menu re-opens cleanly with new locale.

## Verification strategy

After Stage 4 + commit:

| Check | Tool | Pass criterion |
|---|---|---|
| Pixel parity | `tools/imagediff.mjs` (if available) | 0 changed pixels vs pre-i18n |
| New keys present in both locales | `grep -c "menu.paused" dist/assets/index-*.js` | Both ko and en keys in built bundle |
| Locale default behavior | `localStorage.clear()`, reload, click menu | First language is DEFAULT_LOCALE (ko) |
| Toggle live re-render | open menu, click English | All row labels + presets + killfeed banner re-render |
| Persistence | reload page | Language toggle selection survives |
| URL force | open `?lang=en` | Browser ignores localStorage, uses en |

If the game has no baseline capture harness, fall back to a manual screenshot diff before/after via Playwright (see `vercel` skill's wind-tunnel-cfd reference pattern).

## What this leaves out

- **Pluralization** — most shooter UIs don't need `{n} bullets` plural forms. If you do, add a parameter `{n: 5}` and a `plural(n)` helper per locale.
- **Date/time formatting** — locale-aware time strings. Add `Intl.DateTimeFormat` wrappers if the HUD shows a clock.
- **Right-to-left layouts** — Arabic/Hebrew. Out of scope for this fork.
- **CJK font loading** — required for the Korean text to render, but that's an `index.html` `<link>` + font-stack issue, not an i18n issue. See `references/cjk-font-stack.md` (TODO).
- **Dynamic input tables** (per-weapon name) — Claude-of-Duty uses placeholder names; weapon-naming UI is future work.

## Related references

- `references/json-i18n-modpack.md` — when JSON content manifest is available, take that path instead. ~5× faster, no source mods.
- `references/wesnoth-1.18-vs-master.md` — gettext/PO workflow for C++ games. Don't apply here.
- `references/i18n-progress-checklist.md` — when the work crosses into "adding more than 30 keys" or starts touching weapons/item names.
