# PO file multiline parsing — why naive stats are wrong

## The trap

A typical PO file looks like:
```
#: src/foo.cpp:42
msgid "Press the button"
"to continue"
msgstr "버튼을 눌러서"
"계속하세요"
```

The msgid spans **multiple lines**, each `"..."` is a continuation. A naive parser that only looks for the immediately-following `msgstr ""` line **misses every multiline empty entry**.

For Wesnoth `wesnoth-ko.po` (14,500 lines), the difference was:
- Naive stats: **28 empty entries** (wrong, way too low)
- Multiline stats: **213 empty entries** (correct, what `msgfmt --statistics` also reports)

Worse: the count of "fuzzy" entries (328) overlaps with the empty count in the naive count, making it look like work is done when it isn't.

## The parser (Python, no external deps)

```python
def parse_entries(content: str) -> list:
    """Collect entries with multiline msgid and msgstr."""
    lines = content.split('\n')
    i = 0
    file_ref = None
    in_msgid = False
    in_msgstr = False
    msgid_parts = []
    msgstr_parts = []
    entries = []

    while i < len(lines):
        line = lines[i]
        if line.startswith('#:'):
            # New entry reference — flush previous
            if file_ref and msgid_parts:
                entries.append({
                    'file': file_ref,
                    'msgid': ''.join(msgid_parts),
                    'msgstr': ''.join(msgstr_parts),
                })
            file_ref = line[2:].strip().split()[0] if line[2:].strip() else None
            msgid_parts = []
            msgstr_parts = []
            in_msgid = False
            in_msgstr = False
        elif file_ref:
            m = re.match(r'msgid\s+"(.*)"', line)
            if m:
                in_msgid = True; in_msgstr = False
                msgid_parts = [m.group(1)]
            elif re.match(r'msgstr\s+"(.*)"', line):
                in_msgid = False; in_msgstr = True
                m = re.match(r'msgstr\s+"(.*)"', line)
                msgstr_parts = [m.group(1)]
            elif line.startswith('"') and (in_msgid or in_msgstr):
                m = re.match(r'"(.*)"', line)
                if m:
                    if in_msgid: msgid_parts.append(m.group(1))
                    else: msgstr_parts.append(m.group(1))
        i += 1

    if file_ref and msgid_parts:
        entries.append({...})  # flush last

    return entries
```

State machine: track `in_msgid` / `in_msgstr` flags. Only `"..."` lines while a flag is true are continuations. New `msgid` / `msgstr` keyword resets state.

## Longest-prefix matching

Historical PO files (especially when a previous translator concatenated English + their attempt at Korean) have **multilingual msgids**:

```
msgid "Abiha,Afaf,A’isha,..."  # English names
msgid "Abiha,Afaf,아이샤,..."  # Korean names, appended
```

When your `translations.json` has only the English portion as the key, exact match catches 0. Longest-prefix catches the right entry:

```python
def find_best_match(msgid, translations):
    if msgid in translations:
        return translations[msgid]
    candidates = []
    for k in translations:
        if k and (msgid.startswith(k) or k.startswith(msgid)):
            candidates.append((len(k), translations[k]))
    if candidates:
        candidates.sort(reverse=True)
        return candidates[0][1]
    return None
```

On Wesnoth this lifted the fill rate from **1 entry** (exact match) to **45 entries** (longest-prefix).

## Plural forms

Entries with `msgid_plural` and `msgstr[N]` need separate handling. The simplest:

```python
# Only fill msgstr[0] and msgstr[1] if BOTH are empty AND we have a translation
if ms0_empty and ms1_empty and match:
    out.append(f'msgstr[0] "{translation}"')
    out.append(f'msgstr[1] "{translation}"')  # or two translations
```

Don't try to be clever with plural rules — for batch filling, identical translation in both slots is acceptable for languages without plural morphology (like Korean).

## Empty msgid ≠ no entry

Every PO file has at least one entry with `msgid ""` (empty header entry that holds `Project-Id-Version`, `Language`, `Plural-Forms` etc.). When counting "empty entries", **skip entries where msgid itself is empty** — they're not translatable.

```python
empty = [e for e in entries if e['msgid'] and not e['msgstr']]
```

## Quick cross-check with msgfmt

Always cross-validate with `msgfmt`:
```bash
msgfmt -c -o /dev/null po/wesnoth-ko.po
msgfmt --statistics po/wesnoth-ko.po
```

The statistics line ("X translated messages, Y fuzzy, Z untranslated") is the ground truth. Your Python parser should match.