# Procedural Three.js + Vite + Vercel deploy (minimax-of-duty, 2026-07-27)

Reference for deploying a mshumer-style procedural browser FPS (Three.js r180+, Vite, no external art assets) to Vercel with public alias. Builds on the `vercel` skill for generic Vercel CLI mechanics; this document covers what's specific to the procedural Three.js + ESM + viewmodel-separate-scene shape.

Worked example: `mshumer/Claude-of-Duty` fork at `sigco3111/minimax-of-duty` → `https://minimax-of-duty.vercel.app` (8s build, no runtime errors).

## Why the deploy is straightforward

A mshumer-style project has exactly the properties Vercel Static Hosting handles best:

- **Single SPA bundle.** `npm run build` produces `dist/index.html` + `dist/assets/index-<hash>.js` (1.6 MB / gzip 498 KB in our case). No SSR, no API routes, no edge functions.
- **Runtime deps = `three` only.** No CDN fetches for HDRI, no image/audio assets, no `node-fetch` calls during render. The game runs fully offline once built.
- **No whitelisting concerns.** Vercel's CSP/CDN accepts Three.js bundles as-is; no `unsafe-eval` or `wasm-unsafe-eval` flags.
- **Vite auto-detect.** Vercel sees `package.json` with `"vite": "^7.x"` and runs `npm run build` without prompting.

## Reusable deploy script (use as-is)

```bash
#!/usr/bin/env bash
# .tmp-deploy-init.sh — single-shot first prod deploy + GitHub App auto-connect
set -eo pipefail
cd /Users/mac/work/<project>

# preflight
git status --short | grep -q . && { echo "❌ WT dirty"; exit 1; }
[ "$(git rev-parse HEAD)" = "$(git rev-parse origin/main)" ] || { echo "❌ not in sync with origin"; exit 1; }
for f in index.html package.json vite.config.js .gitignore; do
  [ -s "$f" ] && echo "✓ $f" || { echo "❌ $f missing"; exit 1; }
done

TOK=$(cat ~/.hermes/secrets/vercel_token.txt)
echo "=== vercel --yes --prod (first run creates project + GitHub connect) ==="
vercel --yes --prod --token "$TOK" 2>&1 | tail -40
```

First deploy reports:

```
✓ Created         sigco3111s-projects/<project>
> Connecting GitHub repository: https://github.com/<user>/<repo>
> Connected
...
✓ Ready in 19s
▲ Aliased         https://<project>.vercel.app
```

The `> Connected` line is the money — GitHub App auto-deploy is wired **on first deploy**. Subsequent `git push origin main` triggers a fresh build within ~10s.

## What is Vercel-specific vs general Three.js

These bits don't belong in the game's code, but you'll see them on every deploy:

### 1. `team-scope` URL trap

Vercel personal accounts under `sigco3111s-projects` produce **two URLs** per deploy:

| URL | anon access |
|---|---|
| `https://<project>-<hash8>-sigco3111s-projects.vercel.app` | **302 SSO** — visible only to sigco3111 |
| `https://<project>.vercel.app` (alias) | **200** — public |

**Always paste the alias in the README.** Pasted wrong, the public sees an SSO bounce page.

### 2. `.vercel/` and `.gitignore` mismatch

First successful `vercel deploy` writes:
- `.gitignore` line: `.vercel`
- `.vercel/project.json` (the `projectId` we want to track)
- `.vercel/README.txt` (irrelevant)

**Sigco3111 standard pattern**: drop `.vercel` from `.gitignore`, commit both `.vercel/project.json` + `.vercel/README.txt`. Lets a future session boot straight into the existing project instead of creating a duplicate.

```bash
# in commit after first deploy
sed -i.bak '/^\.vercel$/d' .gitignore
rm -f .gitignore.bak
git add .gitignore .vercel/README.txt .vercel/project.json
git commit -m "chore: track .vercel/ project metadata"
```

### 3. `package.json` license SPD-X

Project LICENSE file says **MIT** but `package.json` ships as `"license": "ISC"` (default in many templates). GitHub's license detection picks up whatever package.json says. Mismatch isn't fatal — just inconsistent. Patch once:

```diff
- "license": "ISC",
+ "license": "MIT",
```

### 4. Built JS hash is the source of truth for "did the auto-deploy run"

Hash changes after every build. To verify a push actually re-deployed:

```bash
ALIAS_HTML=$(curl -sL https://<project>.vercel.app)
LOCAL_HASH=$(ls dist/assets/index-*.js 2>/dev/null | sed 's/.*index-//;s/\.js//')
ALIAS_HASH=$(echo "$ALIAS_HTML" | grep -oE 'index-[A-Za-z0-9_-]+\.js' | head -1 | sed 's/.*index-//;s/\.js//')
[ "$LOCAL_HASH" = "$ALIAS_HASH" ] && echo "✓ alias serving latest build"
```

If hashes diverge after a successful `git push`, Vercel GitHub App didn't fire — check `vercel ls` for stuck deployments or re-link the repo via Vercel dashboard.

## Post-deploy verification recipe (4 axes)

```bash
ALIAS="https://<project>.vercel.app"
TOK=$(cat ~/.hermes/secrets/vercel_token.txt)

# 1. alias HTTP 200 + identity to the bundle we just built
curl -sI -A "Mozilla/5.0" "$ALIAS" | head -1
curl -sL "$ALIAS" -o /tmp/idx.html
ALIAS_HASH=$(grep -oE 'index-[A-Za-z0-9_-]+\.js' /tmp/idx.html | head -1 | sed 's/index-//;s/\.js//')
echo "alias serving: index-$ALIAS_HASH.js"

# 2. JS bundle responds with current content
JS_PATH=$(grep -oE '/assets/index-[^"]+\.js' /tmp/idx.html | head -1)
curl -sI "$ALIAS$JS_PATH" | head -1

# 3. specific content present in served bundle (proxy for "feature shipped")
curl -s "$ALIAS$JS_PATH" -o /tmp/built.js
grep -oc "menu.paused" /tmp/built.js && echo "✓ i18n keys in bundle"

# 4. Vercel deployment list — newest must be ● Ready Production
vercel ls <project> --token "$TOK" | head -10
```

All four must pass. If (1)+(2) pass but (3) fails, the build uploaded stale content — force redeploy with `vercel deploy --yes --prod --force`.

## Pitfalls

1. **First deploy under wrong directory name** — `vercel --yes --prod` derives project name from current directory, not from `package.json` "name". If you `cd /tmp/scratch` to deploy, the alias becomes `scratch.vercel.app`. Always cd to `/Users/mac/work/<project>` before running deploy.
2. **`@/path` aliases in import statements** — Vite resolves them, Vercel builds succeed, but the runtime bundle can drift if `vite.config.js` `resolve.alias` is misconfigured. Confirm by `grep -E "from ['\"]@/" dist/assets/index-*.js` — empty result is correct (Vite resolved at build time).
3. **Pointer Lock + first-click UX** — the game requires canvas click to enter pointer lock. Vercel serves `index.html` with `<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">`. Don't override this — mobile visitors still see a frame.
4. **WebGL2 ≠ supported everywhere** — Safari 15+, Chrome 56+, Firefox 51+. Don't ship a graceful canvas-2D fallback inside the Vite bundle unless the game actually supports it; in this style the project assumes WebGL2 and crashes otherwise.
5. **ESM-only `import` statements** — Vite ships `<script type="module">` with `crossorigin` on the bundle, which is correct. Don't add a `<script nomodule>` fallback; the game won't run on browsers without ESM and we want to know that.
6. **Console errors on cold load** — pre-warm shaders compile during init. On slow connections the first frame may freeze 200-400ms. The original Claude-of-Duty ships a boot screen via `<pre style="position:fixed;inset:0;...">` block on `engine.init()` rejection (see `src/main.js` line ~52-62). Don't gut that fallback.
7. **`import.meta.hot` cleanup at the bottom of `main.js`** — Vite dev server reloads cause the prior engine to dispose. The disposal calls into every subsystem — make sure your i18n subsystem's `dispose()` clears its subscriber set, otherwise the memory grows across HMR reloads.

## What this doesn't cover

- **CDN rules / CORS on the alias** — Vite outputs absolute-path assets (`/assets/index-XXX.js`) served from the same origin. No CORS headers needed.
- **Custom domain attach** — out of scope; `vercel domains add <domain> <project>` is the path. The base workflow above does NOT touch domains.
- **Preview URLs** — every PR auto-deploys a `<branch>-<user>.vercel.app` URL but this skill doesn't use them. If review via preview URL matters, expose `--target=preview` in `vercel.json` and gate the production deploy accordingly.
- **Environment-variable injection** — Claude-of-Duty-style forks don't have secrets. If a fork does, follow the `vercel` skill's `env add` pattern.

## Related references

- `vercel` skill — generic Vercel CLI mechanics, alias vs team-scope 302, vercelignore pitfalls, GitHub commit status API, hash-silent-fail diagnosis.
- `coding-mission-fullcycle` — the OpenCode 2-phase variant: fork task, implement, then deploy + verify. The umbrella that this Three.js-specific deploy normally lives under.
