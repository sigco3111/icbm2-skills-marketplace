---
name: docker-manager
description: Docker 컨테이너/이미지/네트워크/볼륨 관리 — 컨테이너 생성, 배포, 모니터링, 로그 수집, 자동 정리 등 전체 Docker 라이프사이클 관리
tags: [docker, containers, devops, deployment, monitoring]
dependencies:
  - docker >= 7.0.0 (CLI)
  - docker Python SDK >= 7.0
---

# Docker Manager

Docker CLI와 Python SDK를 활용한 컨테이너 관리 자동화. 배포, 모니터링, 로그 수집, 자동 정리까지.

## 환경 확인

```bash
# Docker 설치 확인
docker --version
docker info 2>&1 | head -5

# Python SDK 확인
python3 -c "import docker; print('SDK OK')"

# Docker 데몬 상태
docker info >/dev/null 2>&1 && echo "RUNNING" || echo "STOPPED"
```

## 기본 명령어 레퍼런스

### 컨테이너 라이프사이클

```bash
# 실행 중 컨테이너 목록
docker ps
docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}\t{{.Image}}"

# 전체 컨테이너 (중지 포함)
docker ps -a

# 컨테이너 생성 & 실행
docker run -d --name myapp -p 8080:80 -v /data:/app/data nginx:latest

# 중지 / 시작 / 재시작
docker stop myapp
docker start myapp
docker restart myapp

# 삭제 (중지 후)
docker stop myapp && docker rm myapp

# 로그 보기
docker logs myapp --tail 100 -f
docker logs myapp --since 1h

# 컨테이너 내부 실행
docker exec -it myapp bash
docker exec myapp cat /app/config.json

# 리소스 사용량
docker stats --no-stream
```

### 이미지 관리

```bash
# 이미지 목록
docker images --format "table {{.Repository}}\t{{.Tag}}\t{{.Size}}"

# 이미지 빌드
docker build -t myapp:latest ./Dockerfile

# 이미지 정리
docker image prune -f          # 사용 안하는 이미지 삭제
docker system prune -af        # 전체 정리 (컨테이너+이미지+캐시)
```

### 네트워크 & 볼륨

```bash
# 네트워크
docker network create mynet
docker network ls
docker network inspect mynet

# 볼륨
docker volume create mydata
docker volume ls
docker volume inspect mydata
```

## Python SDK 패턴

### 컨테이너 상태 점검

```python
import docker

client = docker.from_env()

# 전체 컨테이너 상태 요약
def get_container_status():
    containers = client.containers.list(all=True)
    result = []
    for c in containers:
        result.append({
            'name': c.name,
            'image': str(c.image.tags[0]) if c.image.tags else str(c.image.id[:12]),
            'status': c.status,
            'ports': c.attrs.get('NetworkSettings', {}).get('Ports', {}),
        })
    return result
```

### 컨테이너 배포

```python
import docker

def deploy_container(name: str, image: str, port: int = None,
                     env_vars: dict = None, volumes: dict = None,
                     restart_policy: str = 'unless-stopped'):
    client = docker.from_env()

    # 기존 컨테이너 정리
    try:
        old = client.containers.get(name)
        old.stop()
        old.remove()
    except docker.errors.NotFound:
        pass

    ports = {f'{port}/tcp': port} if port else None
    container = client.containers.run(
        image,
        name=name,
        detach=True,
        ports=ports,
        environment=env_vars or {},
        volumes=volumes or {},
        restart_policy={'Name': restart_policy}
    )
    return container
```

### 로그 수집

```python
import docker

def get_logs(name: str, tail: int = 100):
    client = docker.from_env()
    container = client.containers.get(name)
    return container.logs(tail=tail).decode('utf-8')
```

### 리소스 모니터링

```python
import docker

def get_resource_usage():
    client = docker.from_env()
    containers = client.containers.list()
    stats = []
    for c in containers:
        s = c.stats(stream=False)
        stats.append({
            'name': c.name,
            'cpu_percent': s['cpu_stats']['cpu_usage']['total_usage'] / max(s['cpu_stats']['system_cpu_usage'], 1) * 100,
            'memory_mb': s['memory_stats']['usage'] / 1024 / 1024,
            'memory_limit_mb': s['memory_stats']['limit'] / 1024 / 1024,
            'network_rx_mb': sum(v['rx_bytes'] for v in s.get('networks', {}).values()) / 1024 / 1024,
            'network_tx_mb': sum(v['tx_bytes'] for v in s.get('networks', {}).values()) / 1024 / 1024,
        })
    return stats
```

### 자동 정리

```python
import docker

def cleanup_docker():
    """미사용 컨테이너, 이미지, 볼륨, 네트워크 정리"""
    client = docker.from_env()
    report = {}

    # 중지된 컨테이너 삭제
    stopped = client.containers.list(filters={'status': 'exited'})
    for c in stopped:
        c.remove()
    report['removed_containers'] = len(stopped)

    # 미사용 이미지 삭제
    images = client.images.list(filters={'dangling': True})
    for img in images:
        client.images.remove(img.id, force=True)
    report['removed_images'] = len(images)

    # 미사용 볼륨 삭제
    volumes = client.volumes.list()
    removed_vols = 0
    for v in volumes:
        if not v.attrs.get('UsageData', {}).get('RefCount', 0):
            v.remove()
            removed_vols += 1
    report['removed_volumes'] = removed_vols

    return report
```

## 실전 시나리오

### 개발 서버 일괄 관리

```bash
# 서버 목록 확인
docker ps --format "{{.Names}}: {{.Status}}"

# 전체 재시작
docker restart $(docker ps -q)

# 특정 서비스만 재시작
docker restart nginx redis postgres
```

### Docker Compose 관리

```bash
# 실행 (백그라운드)
docker compose up -d

# 로그
docker compose logs -f --tail 50

# 재빌드 & 재시작
docker compose up -d --build

# 중지 & 삭제
docker compose down

# 상태 확인
docker compose ps
```

### 디스크 정리

```bash
# 디스크 사용량
docker system df

# 전체 정리 (안전하게)
docker system prune -f
docker system prune -af --volumes  # 공격적 정리 (확인 후 실행)
```

## 헬스체크 통합

automation-healthcheck 스킬에서 Docker 상태를 점검할 때 사용:

```python
def docker_healthcheck():
    import docker
    client = docker.from_env()
    try:
        client.ping()
        containers = client.containers.list()
        return {
            'daemon': 'running',
            'container_count': len(containers),
            'containers': [{'name': c.name, 'status': c.status} for c in containers]
        }
    except Exception as e:
        return {'daemon': 'error', 'message': str(e)}
```

## 주의사항

- `docker rm` 전 항상 컨테이너 내부 데이터 백업 확인
- `docker system prune -af`는 복구 불가, 신중하게 사용
- 볼륨 마운트 시 경로 정확히 확인 (호스트 경로 vs 컨테이너 경로)
- 프로덕션 환경에서는 `restart_policy` 항상 설정
- 포트 충돌 방지를 위해 배포 전 `docker ps`로 사용 중 포트 확인
- 이미지 태그는 항상 명시 (`latest` 대신 버전 고정 권장)

## 파일 구조

```
~/.hermes/skills/automation/docker-manager/
├── SKILL.md                    # 이 파일
├── scripts/
│   ├── deploy.py               # 컨테이너 배포 스크립트
│   ├── monitor.py              # 리소스 모니터링
│   ├── cleanup.py              # 자동 정리
│   └── healthcheck.py          # 헬스체크 연동
└── templates/
    └── docker-compose.yaml     # 범용 compose 템플릿
```
