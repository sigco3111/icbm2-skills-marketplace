#!/usr/bin/env python3
"""Docker 컨테이너 관리 스크립트"""

import argparse
import json
import sys
import docker


def get_client():
    try:
        return docker.from_env()
    except docker.errors.DockerException as e:
        print(f"Docker 연결 실패: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_ps(args):
    """컨테이너 목록"""
    client = get_client()
    containers = client.containers.list(all=not args.running)
    result = []
    for c in containers:
        ports = []
        for p in (c.attrs.get('NetworkSettings', {}).get('Ports') or {}).values():
            if p:
                ports.append(f"{p[0].get('HostIp', '*')}:{p[0].get('HostPort')}")
        result.append({
            'name': c.name,
            'image': c.image.tags[0] if c.image.tags else c.image.short_id,
            'status': c.status,
            'ports': ', '.join(ports) if ports else '-',
            'created': c.attrs['Created'][:19]
        })
    print(json.dumps(result, ensure_ascii=False, indent=2))


def cmd_stats(args):
    """리소스 사용량"""
    client = get_client()
    containers = client.containers.list()
    result = []
    for c in containers:
        s = c.stats(stream=False)
        cpu_delta = s['cpu_stats']['cpu_usage']['total_usage'] - s['precpu_stats']['cpu_usage']['total_usage']
        sys_delta = s['cpu_stats']['system_cpu_usage'] - s['precpu_stats']['system_cpu_usage']
        cpu_pct = round(cpu_delta / max(sys_delta, 1) * 100, 2) if sys_delta > 0 else 0
        mem_mb = round(s['memory_stats'].get('usage', 0) / 1024 / 1024, 1)
        mem_limit = round(s['memory_stats'].get('limit', 0) / 1024 / 1024, 1)
        mem_pct = round(mem_mb / max(mem_limit, 1) * 100, 1)

        result.append({
            'name': c.name,
            'cpu_percent': cpu_pct,
            'memory_mb': mem_mb,
            'memory_limit_mb': mem_limit,
            'memory_percent': mem_pct,
        })
    print(json.dumps(result, ensure_ascii=False, indent=2))


def cmd_logs(args):
    """컨테이너 로그"""
    client = get_client()
    try:
        container = client.containers.get(args.name)
        logs = container.logs(tail=args.tail, timestamps=args.timestamps).decode('utf-8')
        print(logs)
    except docker.errors.NotFound:
        print(f"컨테이너 '{args.name}'을 찾을 수 없습니다", file=sys.stderr)
        sys.exit(1)


def cmd_deploy(args):
    """컨테이너 배포"""
    client = get_client()

    try:
        old = client.containers.get(args.name)
        print(f"기존 컨테이너 '{args.name}' 중지 및 삭제...")
        old.stop()
        old.remove()
    except docker.errors.NotFound:
        pass

    env = {}
    if args.env:
        for e in args.env:
            k, v = e.split('=', 1)
            env[k] = v

    volumes = {}
    if args.volume:
        for v in args.volume:
            parts = v.split(':')
            if len(parts) == 2:
                volumes[parts[0]] = {'bind': parts[1], 'mode': 'rw'}

    ports = {}
    if args.port:
        for p in args.port:
            host_port, container_port = p.split(':')
            ports[f'{container_port}/tcp'] = int(host_port)

    try:
        container = client.containers.run(
            args.image,
            name=args.name,
            detach=True,
            ports=ports or None,
            environment=env or None,
            volumes=volumes or None,
            restart_policy={'Name': args.restart},
            command=args.command or None,
        )
        print(f"배포 성공: {container.name} ({container.short_id})")
        print(f"이미지: {args.image}")
        print(f"상태: {container.status}")
    except Exception as e:
        print(f"배포 실패: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_cleanup(args):
    """Docker 정리"""
    client = get_client()
    report = {}

    if not args.aggressive:
        stopped = client.containers.list(filters={'status': 'exited'})
        for c in stopped:
            c.remove()
        report['removed_containers'] = len(stopped)

        images = client.images.list(filters={'dangling': True})
        for img in images:
            client.images.remove(img.id, force=True)
        report['removed_dangling_images'] = len(images)

        networks = client.networks.list(filters={'type': 'custom'})
        removed_nets = 0
        for net in networks:
            if len(net.containers) == 0:
                net.remove()
                removed_nets += 1
        report['removed_networks'] = removed_nets
    else:
        client.containers.prune()
        client.images.prune(filters={'dangling': False})
        client.volumes.prune()
        client.networks.prune()
        client.builder.prune()
        report['mode'] = 'aggressive'

    print(json.dumps(report, ensure_ascii=False, indent=2))


def cmd_healthcheck(args):
    """Docker 헬스체크"""
    client = get_client()
    try:
        client.ping()
        containers = client.containers.list()
        stopped = client.containers.list(filters={'status': 'exited'})

        result = {
            'daemon': 'running',
            'running': len(containers),
            'stopped': len(stopped),
            'containers': []
        }
        for c in containers:
            result['containers'].append({
                'name': c.name,
                'status': c.status,
                'image': c.image.tags[0] if c.image.tags else c.image.short_id
            })
        print(json.dumps(result, ensure_ascii=False, indent=2))
    except Exception as e:
        print(json.dumps({'daemon': 'error', 'message': str(e)}))
        sys.exit(1)


def main():
    parser = argparse.ArgumentParser(description='Docker 컨테이너 관리')
    sub = parser.add_subparsers(dest='command')

    ps = sub.add_parser('ps', help='컨테이너 목록')
    ps.add_argument('--running', action='store_true', help='실행 중인 것만')

    sub.add_parser('stats', help='리소스 사용량')

    logs = sub.add_parser('logs', help='로그 보기')
    logs.add_argument('name', help='컨테이너 이름')
    logs.add_argument('--tail', '-n', type=int, default=100, help='라인 수')
    logs.add_argument('--timestamps', '-t', action='store_true')

    deploy = sub.add_parser('deploy', help='컨테이너 배포')
    deploy.add_argument('name', help='컨테이너 이름')
    deploy.add_argument('--image', '-i', required=True, help='이미지')
    deploy.add_argument('--port', '-p', action='append', help='포트 (host:container)')
    deploy.add_argument('--env', '-e', action='append', help='환경변수 (KEY=VALUE)')
    deploy.add_argument('--volume', '-v', action='append', help='볼륨 (host:container)')
    deploy.add_argument('--restart', '-r', default='unless-stopped', help='재시작 정책')
    deploy.add_argument('--command', '-c', help='실행 명령어')

    cleanup = sub.add_parser('cleanup', help='정리')
    cleanup.add_argument('--aggressive', '-a', action='store_true', help='공격적 정리')

    sub.add_parser('healthcheck', help='헬스체크')

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    commands = {
        'ps': cmd_ps,
        'stats': cmd_stats,
        'logs': cmd_logs,
        'deploy': cmd_deploy,
        'cleanup': cmd_cleanup,
        'healthcheck': cmd_healthcheck,
    }
    commands[args.command](args)


if __name__ == '__main__':
    main()
