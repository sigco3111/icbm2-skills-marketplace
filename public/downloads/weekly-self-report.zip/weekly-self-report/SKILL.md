---
name: weekly-self-report
description: ICBM2 주간 자기 개선 리포트 — 모든 자동화 활동을 종합 분석하여 성과와 개선점을 도출
version: 1.0.0
author: ICBM2
metadata:
  hermes:
    tags: [self-improvement, weekly-report, cron-analysis, automation]
---

# ICBM2 주간 자기 개선 리포트

## 개요

매주 모든 크론 잡, 자동화 활동, Ship or Slop 제출, 봇마당 활동, Notion 아이디어 노트 등을 종합 분석하여 주간 성과를 요약하고 자가 개선 제안을 도출합니다.

## 실행 방법

### 스크립트 실행

```bash
# 주간 리포트 (기본 7일)
python3 scripts/weekly_report.py

# 월간 리포트
python3 scripts/weekly_report.py --days 30

# JSON 출력
python3 scripts/weekly_report.py --json
```

### 크론 잡에서 실행

이 스킬이 크론 잡에 연결되면 자동으로 스크립트를 실행하고 결과를 전달합니다.

## 분석 대상

### 1. 크론 잡 운영 현황
- `cronjob(action='list')`로 전체 크론 잡 조회
- 각 잡의 실행 횟수, 성공/실패, 성공률, 에러 내용 분석

### 2. Ship or Slop 분석
- 아이디어 제출 성공/실패/스킵 수
- 프레임워크별 사용 빈도
- Slop 기록 (이름, 점수)
- 리서치 ID 다양성 (고유 ID 수, 최다 재사용)
- 최근 제출 아이디어

### 3. 봇마당 활동
- 게시글/댓글 수
- 사용된 페르소나 종류
- 최근 게시글

### 4. Notion 아이디어 노트
- 생성 수
- 최근 제목

### 5. 세션 활동
- 활동 파일 수

## 개선 제안 자동 도출 로직

스크립트가 다음 기준으로 자동 개선 제안을 생성합니다:

| 조건 | 심각도 | 제안 |
|------|--------|------|
| 크론 실패 | 🔴 | 에러 로그 확인 후 프롬프트/API 점검 |
| 성공률 < 100% | 🟡 | 안정화 검토 |
| Slop 건수 > 0 | 🟡 | 품질 가이드 준수 확인 |
| 단일 리서치 ID 재사용 > 5회 | 🟡 | 다양한 리서치 소스 확보 |
| 스킵 > 20회 | 🟡 | 스케줄/의존도 조정 |
| 모든 시스템 정상 | 🟢 | 새 자동화 도입 검토 |

## 출력 형식

### 텍스트 리포트 (기본)
```
==================================================
📊 ICBM2 자기 개선 리포트 — 이번 주
기간: 2026-04-01 ~ 2026-04-06
생성: 2026-04-06 15:47 KST
==================================================

━━━ 1. 크론 잡 운영 현황 ━━━
...

━━━ 2. Ship or Slop 분석 ━━━
...

━━━ 3. 봇마당 활동 ━━━
...

━━━ 4. Notion 아이디어 노트 ━━━
...

━━━ 5. 세션 활동 ━━━
...

━━━ 6. 개선 제안 ━━━
...

━━━ 7. 다음 주 목표 ━━━
...
```

### JSON 모드
`--json` 플래그로 구조화된 JSON 출력 가능.

## 저장 위치

- 리포트: `memory/reports/weekly_YYYY-MM-DD.md`
- 스크립트: `scripts/weekly_report.py`

## 관련 파일

| 파일 | 설명 |
|------|------|
| `memory/shiporslop.md` | Ship or Slop 상태 |
| `memory/botmadang.md` | 봇마당 상태 |
| `memory/notion_idea.md` | 노션 아이디어 노트 상태 |
| `memory/cron_quality.md` | 크론 품질 모니터링 |
| `cron/output/*/` | 크론 잡별 로그 |
