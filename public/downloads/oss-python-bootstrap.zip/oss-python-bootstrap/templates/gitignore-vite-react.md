# Canonical .gitignore for Vite + React + TypeScript + Tailwind projects

Use this BEFORE the first `git add -A` in any Vite/React SPA bootstrap. Adding ignore rules later does NOT unstage symlinks already added by `git add -A` — write this first.

```gitignore
# ─── Dependencies ──────────────────────────────────────────
node_modules/

# ─── Build output ─────────────────────────────────────────
dist/
dist-types/
.vite/                  # Vite 5+ cache (optional, regenerable)

# ─── TypeScript build cache ──────────────────────────────
*.tsbuildinfo

# ─── Vercel deploy state ─────────────────────────────────
.vercel/

# ─── Local tooling state (sigco3111) ─────────────────────
.codegraph/             # symlink → ~/.omo/codegraph/projects/...
.omo/                   # oh-my-opencode session run continuation JSON

# ─── OS / IDE ─────────────────────────────────────────────
.DS_Store
*.log
*.swp
*.swo
.idea/
.vscode/                # OK to commit if you want shared settings, otherwise ignore
*.iml

# ─── Environment ──────────────────────────────────────────
.env
.env.local
.env.*.local

# ─── Test / coverage ─────────────────────────────────────
coverage/
.nyc_output/

# ─── Optional: framework-specific ────────────────────────
# Next.js (if mixed with Vite)
.next/
out/

# SvelteKit (different build output)
.svelte-kit/
build/

# Storybook
storybook-static/
```

## ⚠️ Why symlinks are the killer trap

When `~/.hermes/` (or any agent tool) drops a symlinked directory into your project root — e.g. `.codegraph → /Users/mac/.omo/codegraph/projects/<hash>` — `git add -A` will:

1. **Stage the symlink itself** as a `120000` mode blob (the symlink path string, not the target contents).
2. Even though `.gitignore` may also list `.codegraph/`, **ignore rules are evaluated at `git add` time, not after**.
3. The result: `git ls-files` shows `.codegraph`, the symlink string gets committed, and on a fresh clone you have a broken pointer to a path that doesn't exist on the new machine.

**Fix order when you forgot to add ignore rules first**:

```bash
# Option A: full reset (cleanest)
git reset                                   # clear staging area entirely
# ... now write .gitignore ...
git add -A && git commit -m "..."

# Option B: surgical unstage (works AFTER commit too)
git rm -r --cached .codegraph .omo node_modules dist dist-types *.tsbuildinfo .vercel
git add .gitignore
git commit --amend --no-edit                # squash into the original commit
```

**Diagnostic**:

```bash
git ls-files | wc -l                        # should be ~20-50 for a Vite app, NOT 3000+
git ls-files | grep -E "codegraph|omo|node_modules" | head -5
# Any hit = symlink or untracked dir got staged
```

## Minimal version (if you're sure nothing weird is in the dir)

If you want the bare minimum that handles 95% of Vite/React cases:

```gitignore
node_modules/
dist/
*.tsbuildinfo
.vercel/
.DS_Store
.env
.env.local
```

But for sigco3111's setup specifically, add `.codegraph/` and `.omo/` — these are present in every project under `~/work/` and will silently pollute the repo otherwise.
