---
name: oss-python-bootstrap
description: "Use when bootstrapping a new open-source Python project from zero — `gh repo create` + src-layout package + pyproject.toml + README/CHANGELOG/LICENSE + smoke tests + initial v0.1.0 tag, all in one session, ready for the actual coding to happen on another machine."
version: 1.1.0
author: HyeRin (MiniMax)
license: MIT
metadata:
  hermes:
    tags: [github, python, packaging, scaffolding, open-source, bootstrap]
    related_skills: [github-cli, readme-changelog-automation, test-driven-development, requesting-code-review]
---

# Open-Source Python Project Bootstrap

## Overview

새 오픈소스 Python 프로젝트를 0부터 만들 때, **"사람이 봐도 되고 `pip install` 도 되고 테스트도 돌고 릴리즈 태그도 찍힌 상태"**까지 한 세션에 끝내는 워크플로우. 실제 구현(파서/알고리즘/엔진)은 다른 PC에서 이어서 작업할 때, **이 스킬로 깬 뼈대 + 문서 + 첫 릴리즈**를 정확히 세팅해두는 게 목표.

`github-cli` 가 `gh repo` 명령을 다룬다면, 이 스킬은 **"저장소 + 패키지 + 문서 + 테스트 + 태그" 라이프사이클 전체**를 관장. 트리거가 명확해서 "Python OSS 하나 새로 만들자" 한마디면 발동.

## When to Use

- "오픈소스 Python 라이브러리 하나 새로 만들자" / "GitHub에 새 프로젝트 부트스트랩"
- 아이디어만 있고 구현은 다른 환경(다른 PC, 다음 주 등)에서 진행할 예정
- `pyproject.toml` + `src/` 레이아웃 + 테스트 + README를 30분 안에 끝내고 싶을 때
- v0.1.0 / v0.2.0 / v0.3.0 같은 **시맨틱 버저닝 첫 릴리즈**가 필요할 때

**Don't use for:**
- 단순 GitHub 저장소 README만 만들 때 → `github-cli` 만으로 충분
- Python이 아닌 언어 (Node, Go, Rust) 부트스트랩
- 기존 저장소에 새 기능 추가 (이건 일반 코딩 워크플로우, TDD/plan 스킬 영역)
- 사내 비공개 라이브러리 (라이선스/공개 옵션 다름)

## 핵심 원칙

1. **구현 안 해도 동작해야 한다.** 파서는 스텁이어도, CLI + Python API + 테스트는 import 되고 `pytest` 가 돌아가야 함. 다음 PC에서 clone → `pip install -e .[dev]` → `pytest` 한 번에 통과.
2. **문서가 README를 따라간다.** 기능 미구현 부분은 "Roadmap" 섹션에 명시. 사용자가 GitHub에서 봤을 때 "이거 진짜 만들려는 거구나" 확신이 들어야 함.
3. **첫 릴리즈 = v0.1.0, 시맨틱 버저닝.** 0.x는 초기 개발 신호 — API 변경 자유롭다는 뜻. 사용자가 헷갈리지 않게 CHANGELOG에 명시.
4. **테스트는 처음부터.** 빈 파서라도 `test_version`, `test_missing_file`, `test_unsupported_extension` 같은 스모크 테스트는 박아둠. TDD 신봉 아니어도, **테스트 없는 부트스트랩 = 다음 세션이 안티패턴**을 학습하게 됨.

## 라이선스 / 공개 범위 결정 가이드

사용자 신호 기반 선택:

| 신호 | 추천 |
|------|------|
| "오픈소스로 공개", "남들도 Star 가능하게" | **MIT, Public** (기본 추천) |
| "patent grant 신경 쓰임" | **Apache-2.0, Public** |
| "일단 사적으로 시작" | **MIT, Private** → 나중에 `gh repo edit --visibility public` |
| 불확실 | MIT/Public 기본값 + 사후 변경 안내 |

`gh repo create` 의 `--license` 플래그는 약 13개 SPDX 식별자만 받음. **MIT, Apache-2.0, GPL-3.0, BSD-3-Clause, MPL-2.0, Unlicense** 등은 OK. 그 외는 사후에 `gh repo edit --license-filename LICENSE` 로 별도 파일 업로드.

## 표준 디렉토리 레이아웃

```
<project-root>/
├── README.md              ← 설치/빠른시작/지원형식/로드맵/기여
├── CHANGELOG.md           ← Keep a Changelog 형식, [Unreleased] + [0.1.0]
├── LICENSE                ← gh가 자동 생성, MIT 표준 텍스트
├── pyproject.toml         ← setuptools + ruff + mypy + pytest (single source of truth)
├── .gitignore             ← Python + 프로젝트 특화 (출력 디렉토리 등)
├── src/
│   └── <package_name>/
│       ├── __init__.py    ← 공개 API re-export
│       ├── core.py        ← convert(), batch_convert() 같은 dispatcher
│       ├── cli.py         ← `hwp2md` 엔트리포인트
│       ├── exceptions.py  ← 계층형 예외
│       └── backends/
│           ├── __init__.py
│           ├── hwpx.py    ← 포맷별 파서 (스텁 OK)
│           └── hwp5.py
└── tests/
    ├── __init__.py
    └── test_cli.py        ← 스모크 5~6개로 시작
```

**왜 `src/` 레이아웃?**
- 평면(`./<pkg>/`)은 `pytest`가 시스템 site-packages를 잘못 잡을 수 있음
- `src/` 는 강제로 editable/develop install 필요 → 실수 방지
- 2026년 Python 신규 프로젝트 사실상 표준

## 단계별 부트스트랩 절차

### 1. 환경 검증 (실패 잦음, 가장 먼저)
```bash
gh --version
gh auth status 2>&1 | head -5    # 계정 + 토큰 scope 확인
```
- `gh` 미설치 → `brew install gh` 안내 후 중단
- 인증 안 됨 → `gh auth login` 안내 후 중단
- 토큰 scope 부족 → `repo, workflow, delete_repo` 포함 확인

### 2. 결정 확인 (clarify 도구)
한 번에 다 묶어서 묻기:
- 이름 / 라이선스 / 공개 범위 (위 가이드 표)
- 설명 (한 줄, 영문 or 한글) — `gh repo create --description` 에 들어감
- CLI 엔트리포인트 이름 = 패키지명 권장 (예: `hwp2md` 패키지 → `hwp2md` 커맨드)

### 3. 저장소 생성
```bash
cd ~/Documents   # 또는 사용자 워크스페이스
gh repo create <name> \
  --public \
  --description "<한 줄 설명>" \
  --license MIT \
  --confirm
gh repo view <owner>/<name> --json name,url  # 검증
```

`--confirm` 는 `gh 2.86+` 에서 deprecated 됐지만 여전히 동작. 비대화형 보장은 `--add-readme` 같이 명시 플래그 주는 게 더 깔끔.

**대안 패턴 (2026-06-19 검증, 추천)** — **이미 로컬 파일이 있을 때 한 줄로 푸시까지**:

```bash
cd ~/Documents/<name>   # README 등 로컬 파일이 이미 있는 경우
gh repo create <owner>/<name> --public \
  --description "<한 줄 설명>" \
  --source=. --push
```

`--source=.` 로 현재 디렉토리를 지정 + `--push` 까지 한 번에.
별도 `git init` / `git remote add` / `git push` 단계 불필요.
빈 디렉토리부터 시작할 때 가장 빠른 패턴.

### 4. 클론 + 파일 작성
```bash
git clone https://github.com/<owner>/<name>.git
cd <name>
```

`write_file` 로 다음 7종을 한 번에 작성 (각각 `path` 절대경로 명시):
1. `pyproject.toml` — setuptools ≥68 + 프로젝트 메타 + 의존성 (필수는 zero) + optional-dependencies + ruff/mypy/pytest 설정
2. `README.md` — "왜 이걸 만드는가" / 설치 / 빠른시작 / 지원형식 / 사용사례 / 로드맵 / 기여
3. `CHANGELOG.md` — `[Unreleased]` + `[0.1.0] - <오늘 날짜>` + `Added/Planned` 섹션
4. `.gitignore` — Python 템플릿 + 프로젝트 산출물
5. `src/<pkg>/__init__.py` — `__version__` + 공개 API re-export
6. `src/<pkg>/core.py` — `convert()`, `batch_convert()` dispatcher
7. `src/<pkg>/cli.py` — argparse + entry point
8. `src/<pkg>/exceptions.py` — 베이스 + 구체 예외
9. `src/<pkg>/backends/{__init__,hwpx,hwp5}.py` — 스텁 (NotImplementedError 변환)
10. `tests/__init__.py` + `tests/test_cli.py` — 스모크 5~6개

### 5. 로컬 검증 (반드시)
```bash
/usr/bin/python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip    # macOS 시스템 python3.9에서 editable install 위해 필수
pip install -e ".[all,dev]"
pytest -q                    # 5~6개 모두 통과 확인
<hwp2md-command> --version
<hwp2md-command> --help
```

**Pitfall:** `pip install -e .` 가 `setup.py` / `setup.cfg` 부재 에러로 실패하면 → pip 버전이 너무 옛날 거임. `pip install --upgrade pip` 으로 해결. `pyproject.toml` 만으로는 setuptools 기반 editable install이 안 됨.

### 6. 커밋 + 푸시
```bash
git add -A
git status --short          # 의도치 않은 파일 없는지
git commit -m "feat: initial project skeleton (v0.1.0)

- <공개 API 한 줄>
- <CLI 한 줄>
- <예외/스텁 한 줄>
- <테스트 통과 n/m>
- <README/CHANGELOG 한 줄>
- MIT License

Refs: <owner>/<repo>#1"
git push -u origin main
```

### 7. v0.1.0 태그 + 푸시
```bash
git tag -a v0.1.0 -m "v0.1.0 - Initial project skeleton

<무엇이 포함됐는지 1~2줄>
<다음 버전에서 뭐가 추가될지>"
git push origin v0.1.0
```

### 8. About 설명 한글화 (한국 사용자 흔한 후속 요청)
```bash
gh repo edit <owner>/<name> --description "<한글 한 줄>"
```

## README 구조 (검증된 템플릿)

```markdown
# <project-name>

> <한 줄 요약 — 임팩트, 의존성, 차별점>

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](...)
[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](...)
[![Status: Alpha](https://img.shields.io/badge/status-alpha-orange.svg)]()

**English** | **한국어** (이 문서)

---

## 🎯 왜 <project> 인가?
- ❌ <기존 방식의 pain point 1>
- ❌ <pain point 2>
- ❌ <pain point 3>
- ✅ <이 프로젝트의 해결책 1>
- ✅ <해결책 2>
- ✅ <해결책 3>

## 📦 설치
### 기본 (의존성 X)
\`\`\`bash
pip install <name>
\`\`\`
### 옵션 1
\`\`\`bash
pip install "<name>[<extra1>]"
\`\`\`

## 🚀 빠른 시작
### CLI
\`\`\`bash
<cmd> <input>.<ext> -o <output>.md
\`\`\`
### Python API
\`\`\`python
from <pkg> import convert
md = convert("input.<ext>")
\`\`\`

## 📋 지원 형식
| 형식 | 확장자 | 상태 | 의존성 |
|------|--------|------|--------|
| ... | `.x` | ✅ | none |
| ... | `.y` | 🚧 | `<dep>` |

## 🗺️ 로드맵
- [x] **0.1.0** — <이번>
- [ ] **0.2.0** — <다음>
- [ ] **1.0.0** — <안정>

## 🤝 기여하기
## 📄 라이선스
```

**중요:** README는 **현재 작동하는 기능만 자랑하지 말고, 미구현 부분도 로드맵에 투명하게** 보여줘야 함. 사용자가 GitHub 처음 봤을 때 "이거 만들고 있구나" 명확.

### README 다국어 + 다층 깊이 패턴 (2026-06-29 추가, 사용자 선호)

한국 사용자가 자주 요청하는 README 패턴. 기본 README 템플릿 위에 다음을 추가:

**1. 한/영 병기**: README 상단에 `## 🇰🇷 한국어` 섹션과 `## 🇺🇸 English` 섹션을 명확히 분리. **한국어를 기본(first)**으로 두고 영어는 미러링. 사용자 선호: 영어 first보다 한국어 first + 영문 병기.

**2. 다층 깊이 (단순 > 옵션 > 고급)**: "기본 시드"만 두지 말고 옵션을 제시.

```markdown
### 어바웃 (About) — 한국어 only
이 프로젝트는 무엇이고, 누구를 위한 것이고, 어떤 결정이 핵심인지 설명.

### 사용법 — 옵션 3가지 + 추천
- **옵션 A** (쉬움): `open index.html`
- **옵션 B** (추천): `python3 -m http.server`
- **옵션 C** (고급): 직접 빌드

### 커스터마이즈 — 직접 작성 (고급)
`CONFIG` 객체의 각 키가 어떻게 동작하는지 한 줄씩 설명.

### 로드맵 — 다단계 로드맵
- 0.1.0 (이번)
- 0.2.0 (다음)
- 1.0.0 (안정)
```

**3. Built With 섹션 명시**: 도구 + 모델 출처를 분명히 남길 것 (예: opencode + MiniMax-M3).

```markdown
## 🛠 Built With
This project was scaffolded using **[opencode](https://opencode.ai)** running
the **MiniMax-M3** model. The following prompt generated the simulation:
> <프롬프트 원문 인용>
```

이렇게 하면 다른 사람이 봤을 때 "어떤 도구로 어떻게 만들었는지" 즉시 파악 가능.

**4. About 추가 시**: `개요` 다음에 `### 어바웃 (About)` 한국어 섹션을 추가. 영어 미러는 만들지 말 것 (사용자 요청 시에만).

## CHANGELOG 표준 (Keep a Changelog)

```markdown
# Changelog

All notable changes documented here.
Format: https://keepachangelog.com/en/1.1.0/
Versioning: https://semver.org/spec/v2.0.0.html

## [Unreleased]
### Planned
- <다음 버전 기능>

## [0.1.0] - YYYY-MM-DD
### Added
- <이번 릴리즈 추가된 것>
- <테스트 n/m 통과>
- <README, CHANGELOG, .gitignore>
```

## pyproject.toml 핵심 패턴

```toml
[build-system]
requires = ["setuptools>=68", "wheel"]
build-backend = "setuptools.build_meta"

[project]
name = "<name>"
version = "0.1.0"
description = "<짧은 한 줄>"
readme = "README.md"
license = {text = "MIT"}
requires-python = ">=3.9"
keywords = ["<kw1>", "<kw2>"]
authors = [{name = "<owner>", email = "<email>"}]
classifiers = [
    "Development Status :: 3 - Alpha",
    "Intended Audience :: Developers",
    "License :: OSI Approved :: MIT License",
    "Operating System :: OS Independent",
    "Programming Language :: Python :: 3",
    "Programming Language :: Python :: 3.9",
    "Programming Language :: Python :: 3.10",
    "Programming Language :: Python :: 3.11",
    "Programming Language :: Python :: 3.12",
]
dependencies = []   # zero-deps 정책 시 비워두기

[project.optional-dependencies]
dev = ["pytest>=7.4", "ruff>=0.1.0", "mypy>=1.7"]
<extra1> = ["<dep>>=<ver>"]   # 포맷별
all = ["<dep1>>=<ver>", ...]  # 모든 extra 통합

[project.scripts]
<cmd> = "<pkg>.cli:main"      # CLI 엔트리포인트

[project.urls]
Homepage = "https://github.com/<owner>/<name>"
Repository = "https://github.com/<owner>/<name>"
Issues = "https://github.com/<owner>/<name>/issues"

[tool.setuptools.packages.find]
where = ["src"]

[tool.ruff]
line-length = 100
target-version = "py39"

[tool.mypy]
python_version = "3.9"
strict = true

[tool.pytest.ini_options]
testpaths = ["tests"]
addopts = "-v --tb=short"
```

**Pitfall:** `dependencies = []` 일 때도 `pip install -e .` 는 동작. zero-deps 정책을 README와 pyproject 모두에 일관되게 반영.

## 테스트 스모크 최소 셋 (파서 스텁이라도)

```python
import subprocess, sys
from pathlib import Path
import pytest
from <pkg> import __version__, convert, batch_convert
from <pkg>.exceptions import ConversionError, UnsupportedFormatError


def test_version_is_string() -> None:
    assert isinstance(__version__, str)
    assert __version__.count(".") >= 1

def test_convert_missing_file_raises(tmp_path: Path) -> None:
    with pytest.raises(FileNotFoundError):
        convert(tmp_path / "nope.hwp")

def test_convert_unsupported_extension(tmp_path: Path) -> None:
    f = tmp_path / "test.txt"
    f.write_text("hello")
    with pytest.raises(UnsupportedFormatError):
        convert(f)

def test_convert_<format>_not_implemented(tmp_path: Path) -> None:
    f = tmp_path / "test.<ext>"
    f.write_bytes(b"<magic bytes>")
    with pytest.raises(ConversionError):
        convert(f)

def test_batch_convert_skips_non_<format>_files(tmp_path: Path) -> None:
    # batch가 .txt 같은 거 건너뛰는지 + .<ext>에서 ConversionError
    ...

def test_cli_help_runs() -> None:
    result = subprocess.run(
        [sys.executable, "-m", "<pkg>.cli", "--help"],
        capture_output=True, text=True,
    )
    assert result.returncode == 0
    assert "<expected help string>" in result.stdout
```

## Common Pitfalls

1. **"다른 PC에서 작업할 거야" 신호 무시.** 부트스트랩 단계에서 **모든 파일을 실제 동작 가능한 상태**로 만들어두지 않으면, 다른 PC 사용자가 clone → install → test 한 번에 안 됨. **반드시 `pytest` + `<cmd> --version` + `<cmd> --help` 통과 확인 후 푸시.**

2. **빈 README.** "이 프로젝트가 뭔지" + "왜 필요한지" + "어떻게 쓰는가" + "로드맵" 4섹션 없으면 GitHub에서 봤을 때 묻혀감. 미구현이어도 로드맵으로 정직하게 노출.

3. **CHANGELOG 없이 v0.1.0 태그.** 시맨틱 버저닝과 Keep a Changelog는 짝. 둘 중 하나만 있으면 "이게 표준 프로젝트인가?" 의심.

4. **LICENSE 헤더만 있고 LICENSE 파일 없음.** `gh repo create --license MIT` 가 자동으로 `LICENSE` 파일 생성해줌. 안 만들었으면 누락.

5. **macOS 시스템 python3.9 + 옛 pip.** `pip install -e .` 가 `setup.py`/`setup.cfg` 부재 에러 → **반드시 `pip install --upgrade pip` 먼저.** 이거 빼먹으면 부트스트랩 마지막 단계에서 멈춤.

6. **의존성을 `dependencies` 에 박는 실수.** 옵션성 의존성 (HWP5용 olefile, HWPX용 lxml 등) 은 **항상 `optional-dependencies` 로.** zero-deps 정책 깨지면 다른 사용자 입장에서 진입장벽 생김.

7. **`gh repo create --description` 한글.** 작동은 하지만 GitHub UI 일부가 한글 description 렌더링 약함. 영어 기본 + 사용자 명시 요청 시에만 한글.

8. **스텁 파서가 `pass` 로 비어있음.** `raise ConversionError("not yet implemented")` 같은 **명시적 에러**로 둬야 사용자가 "이거 왜 안 되지?" 디버깅 가능. silent pass 는 안티패턴.

9. **태그 푸시 누락.** `git push` 는 브랜치만 푸시. 태그는 `git push origin v0.1.0` 별도. 깜빡하면 GitHub Releases 페이지 비어있음.

10. **`gh repo view`로 검증 안 함.** `gh repo create` 가 exit 0이라도 description/license가 다르게 적용될 수 있음. 항상 `--json` 으로 한 번 더 확인.

## Verification Checklist

부트스트랩 완료 전:
- [ ] `gh auth status` 인증 OK
- [ ] `gh repo create` exit 0 + `gh repo view --json` 에서 name/description/license 확인
- [ ] 로컬에 클론 디렉토리 존재, `.git` 있음, LICENSE 있음
- [ ] `src/<pkg>/` 레이아웃 + `tests/` 존재
- [ ] `pyproject.toml` 에 `[project.scripts]` 엔트리포인트 등록
- [ ] `.gitignore` Python 표준 + 프로젝트 산출물 (출력 md, hwp 등) 포함
- [ ] `pip install --upgrade pip` 후 `pip install -e ".[all,dev]"` 성공
- [ ] `pytest -q` 5~6개 모두 통과
- [ ] `<cmd> --version` 정상 출력
- [ ] `<cmd> --help` 정상 출력
- [ ] `git add -A && git status` 에 의도치 않은 파일 없음
- [ ] 커밋 메시지 conventional commit 형식 (`feat:`, `chore:`, `docs:`)
- [ ] `git push -u origin main` 성공
- [ ] `git tag -a v0.1.0` + `git push origin v0.1.0` 성공
- [ ] GitHub Releases 페이지에 v0.1.0 노출 확인 (필요 시)

## 다른 PC 핸드오프 메시지 템플릿

작업 종료 시 사용자에게 전달할 표준 메시지:

```markdown
## ✅ 부트스트랩 완료
- **저장소:** https://github.com/<owner>/<name>
- **로컬:** `~/Documents/<name>/`
- **테스트:** n/m 통과 ✅
- **v0.1.0 태그:** 푸시 완료

## 다른 PC에서 시작
\`\`\`bash
git clone https://github.com/<owner>/<name>.git
cd <name>
python -m venv .venv && source .venv/bin/activate
pip install -e ".[all,dev]"
pytest
\`\`\`

## 다음 PC 작업 (로드맵 순서)
1. **0.2.0: <파서 A> 구현** — `src/<pkg>/backends/<a>.py` 의 `TODO(0.2.0)` 부분
2. **0.2.0: <파서 B> 구현** — `<dep>` 사용
3. **0.3.0:** <정확도 개선>
4. **0.4.0:** <GitHub Action / 배포>

작업하시다가 막히면 코드 던져주시면 같이 봐드릴게요.
```

이 템플릿 그대로 쓰면 사용자가 다음 세션/다른 PC에서 즉각 작업 가능.

## 한 세션 안에서 끝내기 어려운 경우 (예외)

- 사용자가 **README/CHANGELOG 내용도 같이 고민하고 싶어함** → 부트스트랩 1~3 단계만 끝내고 중단, 다음 세션에서 4~7
- 사용자가 **"일단 빈 저장소만"** 명시 → 1~3 + 빈 커밋 1개로 축소
- **Windows 타겟** (사용자가 macOS가 아니라고 명시) → `pyproject.toml` 의 `target-version` 조정, README의 macOS 가정 제거
- **Monorepo 의 일부** → 이 스킬이 아니라 일반 Git 워크플로우 영역, 이 스킬 발동 안 함

## One-Shot Recipes

### Recipe 1: 표준 부트스트랩 (위 절차 1~8 그대로)
사용자가 "오픈소스 Python 하나 부트스트랩하자" 한마디 → 위 절차 1~8 순서대로.

### Recipe 2: 한글 About 후속 요청
부트스트랩 후 사용자가 "깃허브 About 한글화" 요청:
```bash
gh repo edit <owner>/<name> --description "<한글 한 줄>"
gh repo view <owner>/<name> --json description  # 검증
```

### Recipe 3: 0.1.0 → 0.2.0 마이너 릴리즈
다음 PC에서 파서 구현 완료 후:
```bash
# CHANGELOG.md 갱신 (수동 patch)
# src/<pkg>/__init__.py 의 __version__ 갱신
# pyproject.toml 의 version 갱신
git commit -am "feat: implement <format> parser"
git tag -a v0.2.0 -m "v0.2.0 - <format> parser implemented"
git push origin main v0.2.0
```

### Recipe 4: 0.x → 1.0.0 안정 릴리즈
- API 동결, 모든 경고 제거, 90%+ 테스트 커버리지
- CHANGELOG의 모든 `## [Unreleased]` 항목 `## [1.0.0]` 으로 이동
- README의 `[![Status: Alpha]]` → `[![Status: Stable]]` 로
- `version = "1.0.0"` 동기화 (3곳: `__init__.py`, `pyproject.toml`, 태그)

### Recipe 5: 오픈소스 영감 + 우리 스택 재설계 (2026-07-09 실측)

**트리거**: "이거 우리 식으로 다시 만들 수 있을까?" / "X 영감 받아서 재설계하자" 류 요청. GitHub 링크 1개 받고 출발.

**7단계 패턴** (sigco3111/toss-trader = kstost/stock 재설계 실측):

1. **원본 분석** — README + 핵심 lib/ 파일 + OpenAPI spec 200~240KB 박힌 것
2. **5가지 결정포인트 brainstorm** (A/B/C 옵션 + 추천):
   - 언어/스택, 분석 엔진, 거래 실행 모드, 데이터 저장, UI/배포
3. **차별점 매트릭스** — 원본 vs 우리, 5~7행 (안전장치 강화, 데이터 이중화, paper trading 등)
4. **저장소 스캐폴드** — 1차 = 4파일 (README + .gitignore + LICENSE + AGENTS.md) + `git init` + `gh repo create` cold-start
5. **헤딩 정규화 11종** (canvas-static-site-pipeline §7.5.3.1.1) — 처음부터 이모지+한글 only로 박아서 패치 0회
6. **정식 docs/ 폴더** — 원본 API reference 사본 + 우리 안전 가드 매트릭스 + Rate limit 표 + URL/발급 절차
7. **commit + push + post-push 검증** — `git status --short` WT 0건, 헤딩 두 어서션, `gh api .../contents/` 추적 확인

**Pitfall 5종** (이번 세션 실측):
- **도구명 혼동 (OpenCode 플러그인)**: `oh-my-opencode` (정확) vs `oh-my-openagent` (오타) — bunx `oh-my-opencode --version`으로 1차 실측 후 README 박기. 추측 단정 ❌
- **시크릿 평문 노출 (원본 문제)**: Next.js 서버 메모리에 API Key 보관 → 우리는 `~/.hermes/secrets/<name>.env` chmod 600 강제
- **yolo 모드 함정**: 원본 `codex --yolo --ephemeral` → 우리는 플러그인 화이트리스트로 격리
- **발급 자격 검증**: API 키 발급이 사업자 무관 / 사업자 필수에 따라 paper trading 정책 + `DRY_RUN` opt-in 방식이 달라짐. **반드시 `terminal`+`curl`로 공식 `/llms.txt` + `openapi-docs/overview.md` 직접 fetch** (delegate_task 웹 fetch는 600초 타임아웃 가능성 — project-delegation §7.1)
- **도메인 404 함정**: kstost README의 `openapi.tossinvest.com`이 404였지만 `openapi.tossinvest.com/openapi-docs/overview.md`는 작동. **루트 URL 404 ≠ API 서버 죽음**. LLM 친화 마크다운이 별도 경로에 있을 가능성

**Brainstorm 템플릿 (5개 결정포인트, A/B/C + 추천)**:
- A. 언어/스택: Python 3.11+ (PEP 604) (✅ 추) / TypeScript + Next.js / Go
- B. 분석 엔진: oh-my-opencode bunx (✅ 추) / opencode 단독 / Claude Code CLI
- C. 거래 실행: paper trading 우선 + opt-in (✅ 추) / 실계좌 즉시 / 시뮬만
- D. 데이터 저장: Notion DB + 로컬 JSON 이중 (✅ 추) / 로컬 JSON only / 클라우드 DB
- E. UI/배포: CLI + Telegram inline button (✅ 추) / Vercel 웹 / 데스크탑 GUI

**원본 vs 우리 매트릭스 템플릿** (README "디자인 결정" 섹션에 박기):
| 차원 | 원본 | 우리 |
|---|---|---|
| 분석 엔진 | codex --yolo | oh-my-opencode 화이트리스트 |
| 시크릿 | 서버 메모리 | ~/.hermes/secrets/ chmod 600 |
| 주문 실행 | 화면 버튼 즉시 | Telegram inline confirm |
| 데이터 | 로컬 JSON only | Notion + JSON 이중 |
| 안전장치 | prompt 차원 | safety.py dry-run 가드 |
