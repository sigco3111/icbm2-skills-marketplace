---
name: notion-dev-news-sync
description: "Notion 뉴스 클리핑 DB → LLM Wiki 자동 동기화 시 발생하는 함정과 패턴 — raw 파일 slug wikilink 함정, patch anchor uniqueness, GeekNews DOM 변동, Medium 403 skip file 패턴, 동일 도구 다중 항목 통합, wiki 부트스트랩"
version: 1.2.0
---

# Notion Dev News → LLM Wiki 동기화 함정 노트

llm-wiki skill은 bundled skill이라 직접 패치할 수 없으므로, 이 skill은 llm-wiki의 Notion sync 워크플로에서 반복적으로 나타나는 함정들을 보강합니다.

## 1. Raw 파일 slug는 wikilink로 쓰지 말 것

**함정**: `raw/articles/anthropic-developer-goodwill-2026-07-07.md` 같은 raw 파일 경로의 슬러그를 `[[anthropic-developer-goodwill]]` 같은 wikilink로 쓰면 깨진 링크가 됨. raw 파일은 entity/concept 페이지가 아니므로 `[[wikilink]]` 타겟이 될 수 없음.

**올바른 패턴**:
- raw 파일을 본문에서 참조할 때: plain text로 `raw/articles/anthropic-developer-goodwill-2026-07-07.md` 작성
- 또는 entity가 존재하면 `[[anthropic]]` 같은 entity 슬러그 사용
- "이 raw 파일이 다루는 주제"를 wikilink하려는 본능이 작동하면 항상 "그 주제의 entity/concept가 이미 존재하는가?" 먼저 확인

**검증 단계**: patch 적용 전 본문에 추가한 모든 `[[wikilink]]` 에 대해 `ls ~/wiki/entities/ ~/wiki/concepts/ ~/wiki/comparisons/ ~/wiki/queries/` 로 슬러그 존재 확인. 매칭 안 되는 슬러그가 있으면 entity로 만들지 plain text로 바꿀지 결정.

## 2. Patch anchor는 페이지 내에서 unique해야 함

**함정**: `## [[ai-agents-trends-2026]] 내 위치` 같은 헤더가 한 페이지에 두 번 이상 나타나면 (예: section이 끝나는 부분 + Related Concepts 목록에 다시 등장), patch tool이 잘못된 위치를 매칭하여 헤더 중복 + 빈 줄 손상.

**증상**: vibe-coding.md에서 발생. patch 적용 후 파일을 다시 읽어보니 `## [[ai-agents-trends-2026]] 내 위치` 헤더가 두 번 연속 등장하고 그 사이 빈 줄이 사라짐.

**해결 패턴**:
- patch `old_string`에 헤더만 쓰지 말고 헤더 + 다음 1-2줄의 본문까지 포함시켜 unique하게 만든다
- 또는 anchor로 헤더가 아니라 마지막 bullet의 unique한 문장을 사용한다
- patch 후 반드시 `read_file` 로 해당 영역을 다시 읽어 structural integrity 확인 (특히 헤더 개수, 빈 줄, 마지막 bullet이 살아있는지)

## 3. GeekNews DOM은 변경 가능 — 다중 selector fallback

**함정**: llm-wiki skill과 references는 `topic-text` class selector를 가정하지만, 2026-07-07 실제 fetch에서는 `topic-text` 가 매칭되지 않고 `<article>` 태그가 body를 담고 있었음.

**Fallback 순서** (2026-07-07 검증):
1. `<div class="topic-text">` (기존 가정)
2. `<div id="topic">` 
3. `<article>` ← 이게 2026-07-07 시점에 동작
4. `<main>`
5. `<h1>` 주변 영역

## 4. Medium URL은 fetch 시도 없이 skip

**함정**: Medium 403은 거의 모든 User-Agent에 대해 발생. fetch 시도를 해도 403 + 0-byte 응답만 받음.

**올바른 패턴**:
- URL이 `medium.com/...` 인 경우 fetch 시도 없이 즉시 `raw/articles/<slug>-skip-YYYY-MM-DD.md` 작성
- `fetch_status: not_extracted`, `skip_reason: medium-403` 명시

## 5. Skip 파일 작성 후 entity 페이지 본문에 1줄 보강

**함정**: skip 파일만 작성하면 "어떤 Wiki 페이지에 이 정보가 반영되었는가" 추적 불가.

**올바른 패턴** (vibe-coding.md 사례):
- skip 파일 작성
- 해당 주제의 기존 entity/concept 페이지 `## 관련` 또는 본문 끝에 1줄 보강
- "Medium '7 Claude Skills for Vibe Coding' (2026-07-07, 접근 불가) 도 같은 결론 — 바이브 코딩의 핵심 = Claude Code의 7가지 스킬 숙달"
- 이렇게 하면 skip file + entity 페이지 양쪽에서 발견 가능

## 6. Fable 명명 충돌 — 동음이의 처리

**함정**: "Fable" 이라는 단어가 (1) Anthropic Claude Fable 5 / Mythos 5 모델명, (2) ammaarreshi의 C&C Generals iOS 포팅의 코드명/포크명 두 곳에서 등장. 검색 시 혼동 발생.

**올바른 패턴**:
- [[fable-incident]] (Claude Fable 5 정치화 사건) 페이지에 명시적 "## Fable 명명 충돌 — 동음이의" 섹션 추가
- "본 페이지는 [[anthropic]] 의 Fable 5 / Mythos 5 사건만 다룸" 명시
- C&C Generals 사례는 [[ios-trends-2026]] / [[local-llm-agentic-coding]] "비-AI 결정론적 변환" 패턴으로 분류

## 7. "Domain-mismatch" skip 사유 — content는 풍부하지만 위키 관심사 밖 (2026-07-08)

**함정**: `itssosunny/job-searcher` (24개 채용 플랫폼 정규화 JSON, Claude Code 스킬 팩, MIT) — 정보는 풍부하지만 **위키 주력 도메인 (AI 모델/에이전트/오픈소스 도구) 의 upstream이 아님**. 단순히 "관심사 밖"으로 자르면 "왜?" 가 사라짐. 다음 cron에서 동일 도메인 도구가 또 등장했을 때 같은 결정을 반복하게 됨.

**올바른 패턴**:
- skip 파일 작성 + `skip_reason: domain-mismatch-or-low-news` 명시
- 본문에 "향후 재평가 기준" 섹션 포함: **"만약 동일 카테고리 도구가 60일 내 5종 이상 등장하면 → '에이전트 = 데이터 표준화 도구' 컨셉 페이지로 업그레이드"**
- 이러면 (a) 도메인 결정이 명시적이고, (b) 다음 sync에서 "이번 skip이 일관된 도메인 결정인지, 재평가할 시점인지" 판단 가능
- log 엔트리의 🚫 skip 섹션에는 단순 사유가 아닌 **카테고리 결정** 명시: "도메인 mismatch — 채용 자동화는 위키 주력 외 (60일 내 동종 5종 등장 시 컨셉 페이지 검토)"

**vs "interest-domain" skip과의 구분**: llm-wiki SKILL.md의 기존 "Items outside the owner's interest domain" 규칙은 너무 추상적. 본 패턴은 **구체적 도메인 경계** (예: "채용/HR/SaaS = 위키 upstream 아님") 와 **재평가 트리거** ("5종/60일") 까지 명시.

## 8. 빈 concept 페이지 (phantom-wikilink 호스트) 처리 (2026-07-08)

**함정**: 어떤 concept 페이지가 `ls entities/` 에서는 존재하지만 **0바이트 (빈 파일)** 일 수 있음. 보통 초기 생성만 하고 컨텐츠를 채우다 만 케이스. 어떤 페이지가 wikilink로 참조될 때 ([[edge-ai]] 가 `[[ternlight]]` 페이지에서 참조됨 등) 그 빈 페이지도 broken wikilink 처럼 보이지만 실제로는 "wikilink target exists but is empty".

**탐지**:
```bash
find ~/wiki/concepts ~/wiki/entities -name "*.md" -size 0   # 0-byte pages
grep -E '\[\[edge-ai\]\]' ~/wiki/index.md ~/wiki/concepts/*.md ~/wiki/entities/*.md  # who references it
```

**올바른 처리 (위키 sync cron 시점)**:
- 새로 추가할 entity/concept 의 [[wikilink]] 가 어떤 빈 페이지를 가리킬 경우: **지금 바로 그 빈 페이지에 컨텐츠를 채우는 기회**
- `concepts/<name>.md` 가 빈 상태로 발견되면 → 새 entity 와 같은 sync에서 첫 컨텐츠를 채우기 (frontmatter + 핵심 사례 + 백링크)
- 이렇게 하면 wiki graph가 단번에 복구됨 (빈 페이지 = broken wikilink로 lint에 잡힐 잠재 위협 회피)
- 본 사례: 2026-07-08 sync에서 [[ternlight]] 신규 + [[edge-ai]] 빈 페이지 채우기를 동시 수행 → wiki graph density 즉시 회복

## 9. log.md append — cron 환경에서 heredoc 안전 패턴 (2026-07-08)

**함정**: `echo "..." >> "$WIKI/log.md"` 같은 inline 변수를 포함한 echo 명령은 셸이 `$변수`를 보존하려고 시도하다 **read-only 파일시스템 오류**를 만날 수 있음. `printf`도 마찬가지. `python3` heredoc은 cron에서 막힘 (`BLOCKED: execute_code ... cron_mode`).

**올바른 패턴** (`cat << 'QUOTED' >> file`):
```bash
cat >> "/Users/mac/Documents/ObsidianVault/wiki/log.md" << 'ENDOFLOGENTRY'
## [YYYY-MM-DD] ingest | ...
- Source: Notion 뉴스 클리핑 DB (N건, ...)
  - ✅ **신규**: ...
ENDOFLOGENTRY
```

**이 패턴이 안전한 이유**:
- `'ENDOFLOGENTRY'` (작은따옴표) → heredoc 내부에서 **변수展開 금지**. `$WIKI`, `$SHELL_VAR` 가 그대로 텍스트로 남음
- `>> file` (append) → 기존 log.md 끝에 안전 추가
- cron 환경 + 한국어/특수문자 포함 컨텐츠에 가장 안정적
- 본 세션 (2026-07-08) 에서 처음 `printf` 가 실패했지만 heredoc 으로 전환 후 성공

**검증**: append 직후 `wc -l $WIKI/log.md` 으로 라인 수 1증가 확인.

## 10. Wiki 미초기화 상태에서의 부트스트랩 (2026-07-15)

**함정**: llm-wiki skill은 "wiki가 존재한다" 가정하에 SCHEMA.md/index.md/log.md를 읽으라고 지시하지만, **새 PC 또는 첫 sync에서는 위키 자체가 없음**. `ls ~/wiki/` → "No such file or directory". SCHEMA.md가 어디에도 없을 수 있음.

**탐지 순서** (find 명령은 macOS에서 60초 timeout 잘 걸림 — maxdepth 3만 사용):
```bash
# 1. 기본 위치 확인 (각각 5초 timeout)
test -d ~/wiki && echo wiki_EXISTS || echo wiki_MISSING
test -d ~/Documents/ObsidianVault && echo vault_EXISTS || echo vault_MISSING
test -d ~/Documents/ObsidianVault/wiki && echo WIKI_IN_VAULT || echo NO
test -d ~/work/wiki && echo work_wiki_EXISTS || echo NO

# 2. find는 비용 큼 — search_files로 SCHEMA.md 직접 검색 (훨씬 빠름)
search_files pattern="SCHEMA.md" target="files" path="/Users/mac/Documents"
search_files pattern="SCHEMA.md" target="files" path="/Users/mac/work"
```

**올바른 부트스트랩 절차** (위키가 어디에도 없을 때):
1. **기본 위치 결정**: `~/wiki` 우선 (Obsidian vault 외부, cron에서 write_file 안정성 검증됨). vault 내부 wiki 폴더는 write_file이 60초 hang 걸리는 케이스 있음 (2026-07-15 관찰).
2. **디렉터리 생성** (단일 명령, 안전):
   ```bash
   mkdir -p ~/wiki/{raw/articles,raw/papers,raw/transcripts,raw/assets,entities,concepts,comparisons,queries,references,_archive}
   ```
3. **3개 핵심 파일 write_file** (병렬):
   - `~/wiki/SCHEMA.md` — 도메인별 맞춤 (예: AI/ML, LLM 에이전트, iOS/Swift)
   - `~/wiki/index.md` — 빈 section 4개 (Entities/Concepts/Comparisons/Queries)
   - `~/wiki/log.md` — `## [YYYY-MM-DD] create | Wiki initialized` 엔트리
4. **log.md의 create 엔트리에 위치 명시**: "위치: ~/wiki" — 다음 sync에서 cron이 위치를 즉시 파악 가능

**함정 (vault 내부 wiki 폴더)**: `~/Documents/ObsidianVault/wiki/` 폴더는 존재하지만 비어 있고, write_file이 60초 timeout으로 hang 됨 (2026-07-15 실측, mv 단계에서 Terminated). 이유는 추정: macOS TCC (Transparency, Consent, and Control) 또는 iCloud sync 잠금. **vault 내부 wiki 폴더는 피하고 `~/wiki/` 사용 권장**. Obsidian 사용자는 vault 외부 wiki를 symlink/copy로 연동 가능.

**write_file이 hang 시 fallback**:
- 1차: 다른 위치 시도 (`~/wiki`)
- 2차: write_file 재시도 (transient 가능성)
- 3차: `cat << 'EOF' > file` heredoc 직접 사용 (cron 환경에서 safe 패턴 — #9 참조)

## 11. 동일 도구/서비스의 다중 항목 통합 (2026-07-15)

**함정**: 한 digest에 같은 도구/서비스가 여러 표현으로 등장할 수 있음. 예: 2026-07-15 Notion DB에 "Orca Mode Studio" (북마크, https://orca.teaboard.link/) 와 "Claude, Codex, Grok을 한 화면에서? Orca IDE로 구현하는 AI 오케스트레이션" (YouTube) 이 별개 2건으로 들어옴. 두 항목 모두 같은 도구(Orca)를 가리킴.

**탐징 신호**:
- 두 항목의 URL이 같은 도메인 (orca.teaboard.link) 또는 같은 서비스를 지목
- 두 항목의 제목이 같은 핵심 단어("Orca")를 공유
- 한 항목이 다른 항목의 "튜토리얼/데모 영상"인 관계

**올바른 처리** (Cron sync 시점):
1. **본문을 fetch 하기 전** 제목 + URL 도메인으로 동일 도구 여부 1차 판정
2. 같은 도구로 판정되면 → **하나의 entity 페이지**로 통합:
   - 메인 항목(공식 URL/앱 랜딩)은 `entity/<slug>.md` 페이지로
   - 부가 항목(YouTube 영상 등)은 `raw/articles/<slug>-skip-YYYY-MM-DD.md` 로 skip 처리하되, **본문에 명시적으로 통합 사유 기록**:
     ```
     ## Skip 사유
     동일 도구(Orca Mode Studio)의 YouTube 영상 — 자막 미공개로 추출 불가.
     본 skip 사유는 [[orca-mode-studio]] 페이지로 통합되었음을 명시.
     ```
3. **entity 페이지의 `sources:` frontmatter에 두 항목 모두 등록**:
   ```yaml
   sources:
     - raw/articles/orca-mode-studio-2026-07-15.md  # 공식 북마크
     - raw/articles/orca-ide-orchestration-youtube-skip-2026-07-15.md  # 통합된 YouTube
   ```
4. **log.md의 🚫 skip 섹션에 "통합" 사유 명시**:
   ```
   - Orca IDE AI 오케스트레이션 YouTube → 동일 도구([[orca-mode-studio]])로 통합
   ```

**vs 독립 항목과의 구분**: 두 항목이 정말 독립적인 도구/서비스라면 (예: acp-ui와 Cate처럼 디자인 철학이 다른 두 도구), llm-wiki SKILL.md의 "Same-week sibling tool pair" 패턴대로 별도 entity 페이지 + cross-link. 본 패턴은 **같은 도구의 다른 표현/채널** 일 때만 통합.

**vs 무관한 항목과의 구분**: 제목에 같은 단어가 있어도 다른 맥락이면 통합 금지. 예: "Hermes"라는 단어가 (1) Hermes Agent (소프트웨어) 와 (2) 신발 브랜드 Hermes에서 등장해도 두 entity는 별개 — 도메인이 다름. 위키 도메인(SCHEMA.md의 Domain 섹션) 안에서만 통합 결정.
