# Medium 본문 검증 케이스 (2026-08-03, Gao Dalie Graph Engineering)

This is a session-specific detail file supporting Section #26 (Medium 본문이
조사 대상일 때 fallback ladder) and Section #27 (파일 변경 금지 parent 위임 모드)
of `SKILL.md`. Read alongside those sections.

## Source article (Medium)

- URL: `https://medium.com/@GaoDalie_AI/forget-loop-engineering-graph-engineering-is-about-this-713a9cf2e985`
- Title: "FORGET Loop Engineering. Graph Engineering is about THIS"
- Author: Gao Dalie (高達烈 / Kaoutar Tarik)
- Published: 2026-07-26
- Body length: ~11,500 chars (English, with one Chinese aside)
- Reactions: 5 / restacks: 2 (verified via Substack JSON metadata mirror)

## Why direct Medium fetch failed

All 7 standard attempts returned non-extractable bodies:

| Attempt | HTTP | Notes |
|---------|------|-------|
| direct GET (Mozilla UA) | 403 | Cloudflare `cf_chl_opt` challenge, 5.9KB HTML, 0 body content |
| `?format=json` | 403 | same challenge page |
| `web.archive.org/web/2026/<url>` | timeout | DNS / rate limit |
| `archive.org/wayback/available` API | 429 | rate limited |
| Google search (qsl 식 + hl=en) | 429 | rate limited |
| DuckDuckGo HTML / lite | challenge | bot detection, requires human verification |
| Bing Korea | 200, 0 results | 매체 인덱스 부족 |

## Successful fallback chain

### Step 4 — Brave Search

URL: `https://search.brave.com/search?q=%22graph+engineering%22+%22loop+engineering%22+GaoDalie`

Returns:
- Medium metadata (title, "Jul, 2026", author display name)
- 20+ media URLs that re-discuss the article
- 2-4 snippet excerpts per result (covers ~30-50% of original body)
- Critic / skeptic quotes inline (e.g., "Skeptics like @RhysSullivan, @DavidKPiano (creator of XState), @PawelHuryn, @NathanFlurry")

Best part: Brave returned the article body AND 5+ counter-positions
from authoritative voices (LangChain, David Khourshid, Carlos E. Perez,
SmartScope, AI Builder Club). This ended up being more useful than the
original article itself for wiki synthesis.

### Step 5 — Substack mirror

URL: `https://gaodalie.substack.com/p/forget-loop-engineering-graph-engineering`

Self-published by Gao Dalie himself (1차 mirror). The Substack JSON metadata
block contains:

- `slug: "forget-loop-engineering-graph-engineering"`
- `post_date: "2026-07-26T13:30:36.188Z"`
- `canonical_url: "https://gaodalie.substack.com/p/forget-loop-engineering-graph-engineering"`
- `reactions: {"❤": 5}`
- `restacks: 2`

The body matches the Medium article 1:1 — first paragraph identical to
Brave snippet, ends with same `Subscribe for free` call-to-action.

**Mirror-validation check applied**:

1. Slug is shorter than Medium (Substack removes trailing article id)
2. post_date within 24h of Medium `published_time`
3. First sentence matches Brave snippet
4. Code blocks (LangGraph Python example) preserved

## Extracted body structure (~11,500 chars)

```
[Lead] (subtitle): Graph engineering is about designing the relationships
                    between those processes. The name is new. But most of
                    the hard problems are not.

[§ The rise of graph engineering — July 2026]
  - Trigger: Peter Steinberger (OpenClaw) tweet asking "Are we still
    talking about loops, or did we move on to graphs?"
  - Loop engineering recap: AI discovers / executes / verifies / records
    / moves to next task
  - New problem: cross-domain tasks (product / architecture / data /
    security / testing / release / cost / compliance)

[§ Loop engineering review]
  - Example: AI writes articles, reviews, rewrites, reevaluates
  - Human decides only purpose + passing criteria; specifics left to AI

[§ In graphs, humans design the paths]
  - If quality eval fails → back to writing
  - If direction wrong → back to structure creation
  - Unapproved docs cannot proceed to publication
  - AI moves within pre-designed map, not freely

[§ Prompt / Loop / Graph — 3-tier engineering]
  | Tier      | Makes reliable        | Core object              |
  |-----------|----------------------|--------------------------|
  | Prompt    | single model call    | instruction              |
  | Loop      | agent behavior       | control cycle            |
  | Graph     | collaboration        | topology                 |
  - These layers are NOT interchangeable
  - Graph is not an upgraded wrapper around Loop

[§ Where does it make sense?]
  - Loop enough: single domain, clear flow, simple failure recovery
  - Graph needed: cross-domain / multi-agent / long-running / parallel /
    approvals / audits
  - Don't graph everything — OpenAI Agents SDK prefers code-centric
    flexibility over declarative graphs

[§ LangGraph implementation]
  - 3 abstractions: Node, Edge, State
  - Code example: 4-node contract analysis (understand → retrieve →
    generate → judge) with conditional retry edges, FSM-style branching
  - 4 design principles: global state, conditional edges, back edges,
    forced exit conditions (`retry_count >= 3`)

[§ My Impression]
  - "It's only been three days, so no one knows if the term ... will
    survive"
  - Underlying concepts (task decomposition, parallelism, decision
    checks) have outlived the name

[Outro] Source link to Google Drive + consulting call CTA
```

## Cross-reference URLs (Brave Search results worth linking in wiki)

| URL | Role | Why useful |
|-----|------|-----------|
| `aibuilderclub.com/home/blog/graph-engineering-vs-loop-engineering` | 5-layer model definition | Most cited single-piece framing |
| `aibuilderclub.com/home/blog/graph-engineering-guide-2026` | Implementation guide | LangGraph-centric, practical |
| `langchain.com/blog/3-years-of-graph-engineering-with-langgraph` | Official LangChain position | David Khourshid: "a loop is just a directed, cyclic graph" |
| `medium.com/intuitionmachine/from-loop-engineering-to-graph-engineering-d3ebeb08511c` | Carlos E. Perez | "single loop... is not a better loop but a graph of loops" |
| `smartscope.blog/en/blog/graph-engineering-loop-engineering-logic-review` | Counter-position | "Containment, not generational replacement" |
| `truefoundry.com/home/blogs/graph-engineering-for-multi-agent-systems-...` | Production perspective | Architecture/governance/observability |
| `turingpost.com/p/fod-159-is-graph-engineering-real` | Industry overview | FOD#159 — "Loop engineering lasted six weeks" |
| `marktechpost.com/.../prompt-engineering-vs-loop-engineering-vs-graph-engineering` | Co-existence framing | Treats them as parallel patterns, not evolution |
| `explainx.ai/.../graph-engineering-wire-multi-agent-orgs-...` | Org-design angle | Compares to programming agent behavior cycles |
| `flowtivity.ai/.../from-loops-to-graphs-the-next-paradigm-in-ai-agent-engineering` | Formal definition | "Network of nodes (entities, decisions, concepts) connected by typed edges (relationships)" |
| `threads.com/@aiposthub/post/Da7asNTARML/` | Chinese translation | Substantive Chinese-language summary |

## Wiki reflection proposal (NOT applied — file 변경 금지 mode)

### Option A (recommended): create new concept page `concepts/graph-engineering.md`

Justification per SCHEMA.md Page Thresholds:

- "central to one source" — fully satisfied (article has stable concept identity)
- Plus 11+ cross-references in Brave results → effectively "2+ sources"

```yaml
---
title: 그래프 엔지니어링 (Graph Engineering)
created: 2026-08-03
updated: 2026-08-03
type: concept
tags: [agent, architecture, comparison]
sources:
  - raw/articles/graph-engineering-gaodalie-medium-2026-07-26.md
  - raw/articles/graph-engineering-guide-2026-aibuilderclub.md
  - raw/articles/langchain-3-years-of-graph-engineering.md
  - raw/articles/from-loop-engineering-to-graph-engineering-carlos-perez.md
contradictions: [double-loop-ai-research]
status: contested-vocabulary
---

# 그래프 엔지니어링 (Graph Engineering)

> "Graph engineering is about designing the relationships between those
> processes. The name is new. But most of the hard problems are not."
> — Gao Dalie (高達烈), 2026-07-26
```

**Recommended: Option A.** Reasons:

1. SCHEMA.md Page Thresholds 의 "central to one source" 충족 + 11+
   cross-reference = 사실상 "2+ sources"
2. `[[loop-engineering]]` 페이지는 이미 5,502 bytes, ~89 lines — Option B
   추가 시 100+ lines (split threshold 200 이지만 가독성 임계점 도달)
3. `[[double-loop-ai-research]]` 가 index.md 에 등재되어 있으나 실제
   .md 파일 부재 (graph engineering 과 명확히 다른 주제이지만 wikilink
   충돌 방지를 위해 별도 페이지가 필요)

## Issues found in current wiki state

### 1. index.md 의 phantom reference

File `~/Documents/ObsidianVault/wiki/concepts/double-loop-ai-research.md`
does not exist on disk, but `~/Documents/ObsidianVault/wiki/index.md`
references `[[double-loop-ai-research]]` in the Concepts section.
Additionally `log.md` 2026-07-15 and 2026-07-16 entries reference it.

Suggested: parent decides whether to (a) create stub page, (b) remove
the `[[double-loop-ai-research]]` line from index.md, or (c) leave
for cron to handle.

### 2. `[[loop-engineering]]` 페이지 (위키 갱신 권고)

Currently has 2026-07-14 cutoff + mentions bilevel-autoresearch but
not graph engineering. Section #16의 4-tier 진화 (Prompt →
Harness → Factory → Loop → Graph) 가 추가 가치.

## Verification receipts

- Source article JSON metadata (from Substack): preserved in substack
  metadata block above
- Cross-reference: Brave Search HTML preserved at /tmp/brave.html
- Mirror body: preserved at /tmp/article_full.txt (~11,500 chars)
- This report: parent summary only — no wiki files written
