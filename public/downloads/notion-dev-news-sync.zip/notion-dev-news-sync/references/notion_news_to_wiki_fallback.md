# Notion News DB 직접 조회 fallback — `days=1` 필터 보정

`notion_news_to_wiki.py` 가 `NO_NEW_ITEMS` 를 반환해도 **실제로는 오늘 등록된 항목이 있는 경우** (Section #20) 에 대비한 7일 fallback 조회 스크립트. Cron 세션에서 `execute_code` 가 차단되므로 `terminal` + `python3 << 'PYEOF'` heredoc 패턴을 쓴다 (Section #0, #9).

## 핵심 변수

- `DB_ID`: `24976f2e-9097-814c-9aea-dfad0f531672` (Notion 뉴스 클리핑 DB)
- `NOTION_TOKEN`: `~/.hermes/secrets/notion_token.txt` (50자, OAuth user token)
- `발견일` 프로퍼티: KST 자정 기준일과 UTC 자정 사이의 미스매치 가능성이 가장 큰 필드

## 1단계: 7일 Raw JSON 다운로드

```bash
NOTION_KEY=$(cat ~/.hermes/secrets/notion_token.txt)
SINCE=$(date -v-7d +%Y-%m-%d 2>/dev/null || date -d "7 days ago" +%Y-%m-%d)
TODAY_KST=$(date +%Y-%m-%d)
curl -s --max-time 15 -X POST \
  "https://api.notion.com/v1/databases/$DB_ID/query" \
  -H "Authorization: Bearer $NOTION_KEY" \
  -H "Notion-Version: 2022-06-28" \
  -H "Content-Type: application/json" \
  -d "{\"page_size\": 30, \"filter\": {\"property\": \"발견일\", \"date\": {\"on_or_after\": \"$SINCE\"}}, \"sorts\": [{\"property\": \"발견일\", \"direction\": \"descending\"}]}" \
  > /tmp/notion_seven_day.json
ls -la /tmp/notion_seven_day.json   # 0 byte면 auth/network 실패
```

`0 byte` 가 나오면 → API 키 (50자) 만료/오타 가능성. Notion 워크스페이스의 internal integration token 이 OAuth user token 으로 변경되었을 수 있음. 이 경우 `~/.hermes/secrets/notion_token.txt` 갱신 필요.

## 2단계: 오늘(KST) 항목만 필터 + 형식 변환

```bash
python3 << 'PYEOF'
import json
with open('/tmp/notion_seven_day.json') as f:
    data = json.load(f)
results = data.get('results', [])
today = __import__('datetime').datetime.now().strftime('%Y-%m-%d')
today_entries = [r for r in results
                 if r.get('properties', {}).get('발견일', {}).get('date', {})
                 and r['properties']['발견일']['date']['start'].startswith(today)]
print(f'전체 {len(results)}건 중 오늘(KST {today}) {len(today_entries)}건')

entries = []
for r in today_entries:
    props = r.get('properties', {})
    entry = {'id': r['id']}
    for k, v in props.items():
        pt = v.get('type')
        if pt == 'title':
            entry['title'] = ''.join([t['plain_text'] for t in v.get('title', [])])
        elif pt == 'multi_select':
            entry['categories'] = [t['name'] for t in v.get('multi_select', [])]
        elif pt == 'date':
            d = v.get('date')
            entry['date'] = d.get('start', '')[:10] if d else ''
        elif pt == 'rich_text':
            entry['description'] = ''.join([t['plain_text'] for t in v.get('rich_text', [])])
        elif pt == 'url':
            entry['url'] = v.get('url', '') or ''
        elif pt == 'checkbox' and k == '즐겨찾기':
            entry['favorite'] = v.get('checkbox', False)
    entries.append(entry)

with open('/tmp/notion_news_digest.json', 'w') as f:
    json.dump(entries, f, ensure_ascii=False, indent=2)

for i, e in enumerate(entries, 1):
    print(f"{i}. [{', '.join(e.get('categories', []))}] {e.get('title', '')}")
    if e.get('url'): print(f"   URL: {e['url']}")
PYEOF
```

## 3단계: 빈 결과 처리

- `today_entries` 0건 → 진짜 NO_NEW_ITEMS. cron 종료 (`[SILENT]`).
- `today_entries` > 0건 → 원래 동기화 절차 (raw/article → entity/concept → index.md → log.md) 진행.

## 4단계: Raw HTML 본문 추출 (Notion DB의 description은 보통 0~200자)

Notion DB 의 `description` (rich_text) 만으로는 깊이가 부족. URL 본문을 직접 fetch 해야 함. GeekNews 와 AITimes 의 selector 차이:

### GeekNews (news.hada.io)

```bash
URL="https://news.hada.io/topic?id=31744"
curl -s --max-time 10 -A "Mozilla/5.0" "$URL" > /tmp/geeknews.html
python3 << 'PYEOF'
import re
import sys
with open('/tmp/geeknews.html') as f:
    html = f.read()
# 본문 영역 후보 (시점별 fallback)
patterns = [
    r'<div class="topic-text">(.*?)</div>',
    r'<div id="topic">(.*?)</div>',
    r'<article>(.*?)</article>',
    r'<main>(.*?)</main>',
]
body = ''
for pat in patterns:
    m = re.search(pat, html, re.DOTALL)
    if m:
        text = re.sub(r'<[^>]+>', ' ', m.group(1))
        text = re.sub(r'\s+', ' ', text).strip()
        if len(text) > 100:
            body = text
            break
# 최후 수단: <h1> 끝부터 related-topics 시작 전까지
if not body:
    h1 = re.search(r'<h1[^>]*>(.*?)</h1>', html, re.DOTALL)
    if h1:
        start = h1.end()
        end = html.find('related-topics', start)
        if end == -1: end = start + 8000
        chunk = html[start:end]
        body = re.sub(r'<[^>]+>', ' ', chunk)
        body = re.sub(r'\s+', ' ', body).strip()

# meta description 도 같이 추출 (selector 실패 시 안전망)
desc = re.search(r'<meta name="description" content="([^"]+)"', html)
og_desc = re.search(r'<meta property="og:description" content="([^"]+)"', html)

print('BODY:', body[:2000])
print('---DESC---', (desc or og_desc).group(1)[:500] if (desc or og_desc) else 'N/A')
PYEOF
```

### AITimes (www.aitimes.com)

```bash
URL="https://www.aitimes.com/news/articleView.html?idxno=213088"
curl -s --max-time 10 -A "Mozilla/5.0" "$URL" > /tmp/aitimes.html
python3 << 'PYEOF'
import re
with open('/tmp/aitimes.html') as f:
    html = f.read()
# 1. OG title/description (본문이 SPA로 늦게 로드될 때 가장 안정적)
title = re.search(r'<meta property="og:title" content="([^"]+)"', html)
desc = re.search(r'<meta property="og:description" content="([^"]+)"', html)
print('TITLE:', title.group(1) if title else 'N/A')
print('DESC:', desc.group(1)[:500] if desc else 'N/A')
# 2. 본문 (article-body / content-body / contents 영역)
for pat in [r'<div[^>]*article-body[^>]*>(.*?)</div>',
            r'<div[^>]*content-body[^>]*>(.*?)</div>',
            r'<div[^>]*class="[^"]*body[^"]*"[^>]*>(.*?)</section>']:
    m = re.search(pat, html, re.DOTALL)
    if m:
        text = re.sub(r'<[^>]+>', ' ', m.group(1))
        text = re.sub(r'\s+', ' ', text).strip()
        if len(text) > 200:
            print('BODY:', text[:2000])
            break
PYEOF
```

**중요**: AITimes 본문은 SPA로 늦게 로드되어 본문 영역이 비어 있는 경우가 있다. 이때는 `og:description` (보통 200~500자) 만으로 raw 파일 작성. fetch_status frontmatter 를 `og-meta-only` 로 명시.

## 5단계: log.md 적기 (sync 진행 시)

```markdown
## [YYYY-MM-DD] ingest | Notion Dev News → LLM Wiki 동기화 (script fallback)
- ⚠️ script `days=1` 필터가 오늘 KST 09:00~17:00 사이 발견일 N건을 놓쳐 NO_NEW_ITEMS 출력
- 7일 fallback 으로 직접 조회 → 오늘 N건 확보, 정상 sync 진행
- upstream 패치 권고: script `days=1` → `days=2` 또는 Notion `Processed` 체크박스 도입
```

## 관련 섹션

- Section #0 (cron 환경 execute_code 차단)
- Section #9 (heredoc safe append)
- Section #15 (patch anchor uniqueness)
- Section #19 (phantom header)
- Section #20 (이번 보강의 본 함정 — `days=1` 필터 누락)
- Section #21 (patch 매개변수 누락 방어)
