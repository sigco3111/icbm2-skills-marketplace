---
name: github-trending-monitor
description: GitHub Trending 리포지토리 + 관심 리포의 새 릴리즈를 매일 자동으로 수집하여 Notion DB에 저장하고, 텔레그램용 한국어 요약을 출력하는 스킬. AI/ML/iOS 관련 리포만 필터링.
tags: [github, automation, cron, notion, korean, translation]
---

# GitHub Trending + Release Monitor

## 설명
GitHub 트렌딩 리포지토리와 관심 프로젝트의 새 릴리즈를 자동으로 모니터링하는 스킬입니다.
AI/ML/iOS 관련 트렌딩 리포를 수집하고, 관심 리포지토리의 릴리즈를 추적하여 Notion DB에 저장합니다.
Telegram용 한국어 요약도 함께 출력합니다.

## 스크립트
- `scripts/github_trending_monitor.py`
- 번역 패턴 상세: [references/translation-api.md](references/translation-api.md)
- Apple Silicon Python 환경 정리: [references/apple-silicon-python.md](references/apple-silicon-python.md)
- Hermes cron 실행 환경 실측값: [references/cron-setup-verified.md](references/cron-setup-verified.md)
- 2026-07-14 세션 (일시적 rate limit 자가복구 + jobs.json 패치): [references/session-2026-07-14-rate-limit-recovery.md](references/session-2026-07-14-rate-limit-recovery.md)

## 사용법

### 기본 실행 (전체 수집 + Notion 저장)
```bash
python3 scripts/github_trending_monitor.py
```

### 간결한 요약만 (--summary)
```bash
python3 scripts/github_trending_monitor.py --summary
```

### Notion 저장 없이 확인만
```bash
python3 scripts/github_trending_monitor.py --no-notion
```

### 릴리즈만 확인
```bash
python3 scripts/github_trending_monitor.py --releases-only
```

### 트렌딩만 확인
```bash
python3 scripts/github_trending_monitor.py --trending-only
```

## 설정

### 관심 리포지토리 (WATCHED_REPOS)
스크립트 내 `WATCHED_REPOS` 리스트에 추가/수정:
- anthropics/claude-code
- opencode-ai/opencode
- openai/swarm
- langchain-ai/langchain
- microsoft/autogen
- ollama/ollama
- vercel/ai
- anthropics/anthropic-sdk-python
- google-gemini/generative-ai-python
- swiftlang/swift
- apple/swift-openai-generator
- sirwandrie/llm-swift

### Notion DB
- **DB ID**: 33f76f2e-9097-8176-a537-d40ebb476ef9
- **부모 페이지**: ICBM 봇 (2f876f2e909780d797e5e7aa58f7c0c8)
- **속성**: Name, URL, Description, Stars, Language, Category, TrendingTopic, Date

### 트렌딩 카테고리
- Python, Swift, TypeScript (GitHub Trending 페이지 기반)

### 필터링 키워드
AI/ML 관련: ai, llm, gpt, claude, gemini, agent, langchain, transformer 등
iOS 관련: ios, swift, swiftui, uikit, xcode, apple, iphone 등

### 상태 파일
- `data/github_trending_state.json` — 마지막 확인한 릴리즈 태그 저장

### Cron 스케줄
매일 오전 9시 KST 실행:
```
0 0 * * * cd ~/.hermes/scripts && /usr/local/bin/python3 github_trending_monitor.py --summary >> /tmp/github_trending.log 2>&1
```

> ⚠️ **Python 호환성 주의 (Apple Silicon M1/M2/M3/M4)**:
> - `/usr/bin/python3` → macOS 시스템 3.9.6, `requests`/`bs4` 없음. **사용 금지.**
> - `/usr/local/bin/python3` → Intel Mac용 경로. **Apple Silicon에는 존재하지 않음** (실행 시 `No such file or directory`).
> - `/opt/homebrew/bin/python3.12` → Apple Silicon Homebrew 경로. 여기에 deps 설치 가능하지만 PEP 668 때문에 시스템 site-packages 격리됨.
> - 권장: `uv`로 ad-hoc venv 만들고 의존성 설치 후 실행:
>   ```bash
>   uv venv /tmp/gh_monitor --python /opt/homebrew/bin/python3.12
>   uv pip install --python /tmp/gh_monitor/bin/python3 requests beautifulsoup4
>   /tmp/gh_monitor/bin/python3 ~/.hermes/scripts/github_trending_monitor.py --summary
>   ```
> - **영구 해결 (실제 검증됨, 2026-07-05)**: `uv`가 관리하는 Python은 externally-managed라 일반 `uv pip install`이 거부됨. **`--break-system-packages` 플래그 필수**:
>   ```bash
>   uv pip install --python ~/.local/share/uv/python/cpython-3.11.15-macos-aarch64-none/bin/python3 \
>     --break-system-packages requests beautifulsoup4
>   ```
>   그 후 이 경로를 cron에서 직접 호출. (`cd`를 빼면 작업 디렉토리 차이로 스크립트 내부의 상대 경로(`STATE_FILE` 등)가 깨질 수 있음 — `cd ~/.hermes/scripts && ...` 유지.)

> ⚠️ **이 스킬은 system crontab이 아닌 Hermes cron job(`b26b0579a45f`)으로 실행됨.** 토큰 주입은 `~/.hermes/cron/jobs.json`의 command 필드 또는 prompt 안에서 처리해야 함.

## 트러블슈팅

### GitHub API HTTP 403 (모든 WATCHED_REPOS 실패)
증상: `⚠️ <owner>/<repo>: API 오류 (HTTP 403)` 12개 전부, "0개의 새 릴리즈 발견".
원인: `GITHUB_TOKEN` 미설정 + 직전 트렌딩 스크래핑(42회) 소진 → 익명 요청은 시간당 60회 제한에 걸림.

⚠️ **먼저 재실행 한 번 해보라 — 토큰이 없어도 자동 복구되는 경우가 흔하다** (2026-07-14 실측: 첫 실행 12/12 403 → 30초 후 재실행 1/12도 빠짐 없이 200). GitHub의 익명 IP 한도(reset window ~1시간)는 같은 IP에서 빠르게 회복되는 경우가 많아, 토큰 파일을 만들기 전에 한 번 더 돌려보면 대부분은 그냥 풀린다. 만약 2회 연속 모두 403이면 아래 영구 해결로 진행.

영구 해결:
1. GitHub → Settings → Developer settings → Personal access tokens → **Tokens (classic)** 발급, scope `public_repo`만 체크.
2. `~/.hermes/secrets/github_token.txt`에 토큰 저장 (`chmod 600`).
3. 스크립트는 환경변수 `GITHUB_TOKEN`만 자동 인식 — token 파일 직접 로드는 안 함.

#### 환경별 토큰 주입 방법

**로컬 CLI (zsh/bash에서 직접 실행):**
```bash
export GITHUB_TOKEN=$(cat ~/.hermes/secrets/github_token.txt)
python3 ~/.hermes/scripts/github_trending_monitor.py --summary
```

**System crontab:**
```cron
0 0 * * * export GITHUB_TOKEN=$(cat ~/.hermes/secrets/github_token.txt) && cd ~/.hermes/scripts && /opt/homebrew/bin/python3.12 github_trending_monitor.py --summary >> /tmp/github_trending.log 2>&1
```

**Hermes cron job — 검증된 prompt 패턴 (실제 jobs.json에 적용, 2026-07-14):**
prompt의 bash 블록 안에 토큰 파일 존재 체크 + uv 경로 명시까지 한 줄로 묶어서 넣는다. 토큰 파일이 없을 때 `$(cat …)`가 빈 문자열을 export해버리는 함정(`export GITHUB_TOKEN=`가 silent success라 403이 그대로 남음)을 `[ -f … ]` 가드로 회피.
```bash
if [ -f ~/.hermes/secrets/github_token.txt ]; then
  export GITHUB_TOKEN="$(cat ~/.hermes/secrets/github_token.txt)"
else
  echo "[WARN] github_token.txt missing — releases will fail with 403"
fi
cd ~/.hermes/scripts && /Users/mac/.local/share/uv/python/cpython-3.11.15-macos-aarch64-none/bin/python3 github_trending_monitor.py --summary
```
> 이 스킬의 cron 잡은 `b26b0579a45f`. jobs.json의 `prompt`를 직접 수정하거나, 새 잡을 만들 때 위 블록을 통째로 넣어야 함. `crontab -l`에는 아무것도 안 보임 (Hermes가 자체 스케줄링함).

#### 디자인 결함 참고
스크립트가 `GITHUB_TOKEN`이 비어 있을 때도 트래픽을 소비하는 것은 낭비. 차후 개선 시 `__main__` 진입점에서 토큰 부재 감지 → 즉시 종료 + "TOKEN MISSING" 안내 메시지가 이상적. 현재는 403 메시지가 그대로 출력됨.

### 트렌딩은 수집되는데 릴리즈만 0개
→ **먼저 30~60초 기다린 뒤 한 번만 더 돌려보라.** 토큰이 없어도 일시적 rate limit 회복으로 정상화되는 경우가 압도적. 두 번째도 0개면 위 403 해결 섹션의 영구 해결로 진행.

### 한글이 깨지거나 번역이 이상함
→ MyMemory 무료 API 일 5000자 한도. 초과 시 원문 fallback. 상세: `references/translation-api.md`.

## 출력 형식
Telegram 메시지로 전달하기 적합한 한국어 요약을 출력합니다.
--summary 플래그 시 간결하게 상위 3개만 표시합니다.

## 한국어 번역
영어 description은 자동으로 한국어로 번역되어 출력/저장됩니다.
- **API**: MyMemory 무료 API (키 불필요, 일 5000자 한도)
- **Notion**: `🇰🇷 한국어 번역 + 🌐 원문` 형태로 Description 필드에 저장
- **Telegram 요약**: `🇰🇷 한국어` 한 줄 추가
- **릴리즈 노트**: 번역 안 함 (markdown/이슈 트래커 깨질 위험)
- **실패 시**: 원문 그대로 fallback (크론 실패 방지)
- **캐시**: 세션 내 dict 캐시로 같은 description 반복 번역 방지
- **상세 구현/한계/대안 API**: [references/translation-api.md](references/translation-api.md)
