# GitHub Trending + Release Monitor

## 설명
GitHub 트렌딩 리포지토리와 관심 프로젝트의 새 릴리즈를 자동으로 모니터링하는 스킬입니다.
AI/ML/iOS 관련 트렌딩 리포를 수집하고, 관심 리포지토리의 릴리즈를 추적하여 Notion DB에 저장합니다.
Telegram용 한국어 요약도 함께 출력합니다.

## 스크립트
- `scripts/github_trending_monitor.py`

## 사용법

### 기본 실행 (전체 수집 + Notion 저장)
```bash
python3 scripts/github_trending_monitor.py
```

### 간결한 요약만 (--summary)
```bash
python3 scripts/github_trending_monitor.py --summary
```

### Notion 저장 없이 확인만
```bash
python3 scripts/github_trending_monitor.py --no-notion
```

### 릴리즈만 확인
```bash
python3 scripts/github_trending_monitor.py --releases-only
```

### 트렌딩만 확인
```bash
python3 scripts/github_trending_monitor.py --trending-only
```

## 설정

### 관심 리포지토리 (WATCHED_REPOS)
스크립트 내 `WATCHED_REPOS` 리스트에 추가/수정:
- anthropics/claude-code
- opencode-ai/opencode
- openai/swarm
- langchain-ai/langchain
- microsoft/autogen
- ollama/ollama
- vercel/ai
- anthropics/anthropic-sdk-python
- google-gemini/generative-ai-python
- swiftlang/swift
- apple/swift-openai-generator
- sirwandrie/llm-swift

### Notion DB
- **DB ID**: 33f76f2e-9097-8176-a537-d40ebb476ef9
- **부모 페이지**: ICBM 봇 (2f876f2e909780d797e5e7aa58f7c0c8)
- **속성**: Name, URL, Description, Stars, Language, Category, TrendingTopic, Date

### 트렌딩 카테고리
- Python, Swift, TypeScript (GitHub Trending 페이지 기반)

### 필터링 키워드
AI/ML 관련: ai, llm, gpt, claude, gemini, agent, langchain, transformer 등
iOS 관련: ios, swift, swiftui, uikit, xcode, apple, iphone 등

### 상태 파일
- `data/github_trending_state.json` — 마지막 확인한 릴리즈 태그 저장

### Cron 스케줄
매일 오전 9시 KST 실행:
```
0 0 * * * /usr/bin/python3 scripts/github_trending_monitor.py --summary >> /tmp/github_trending.log 2>&1
```

## 출력 형식
Telegram 메시지로 전달하기 적합한 한국어 요약을 출력합니다.
--summary 플래그 시 간결하게 상위 3개만 표시합니다.
