# 2026-07-14 — 일시적 Rate Limit 자가-복구 + jobs.json 패치

## 세션 요약

- 잡 ID: `b26b0579a45f` (GitHub Trending + Release Monitor, 매일 09:00 KST)
- 결과: 트렌딩 39개 Notion 저장 ✅, 새 릴리즈 1개 발견 (ollama v0.32.0)
- 상태: 완전 성공 (재실행 후)

## 핵심 발견: 403 ≠ 영구 토큰 부재

**첫 실행**: 12/12 WATCHED_REPOS가 HTTP 403 → "0개의 새 릴리즈"  
**30초 후 재실행**: 12/12 200, ollama v0.32.0 정상 발견

원인 추정:
1. 직전 트렌딩 스크래핑이 한 IP에서 42회 발생
2. 익명 GitHub API 한도(60/h) 소진
3. 같은 IP라도 같은 윈도우 안에서 빠르게 reset되거나 부분 회복됨
4. 두 번째 실행은 trending 스크래핑 1회 + releases 12회 = 13회로 한도 내

**교훈**: 403이 떴다고 바로 토큰 파일 만들 필요 없다. 30~60초 후 한 번 더 돌리면 대부분 자동 복구됨. SKILL.md 본문도 이 함정을 반영해 "먼저 재실행" 가이드를 최상단에 추가함.

## 검증된 jobs.json prompt 패턴

기존 prompt는 단순히 `python3 ...`만 호출 → 토큰 env var 주입 안 됨, 시스템 python3 사용 시도 가능성. 패치 후:

```bash
if [ -f ~/.hermes/secrets/github_token.txt ]; then
  export GITHUB_TOKEN="$(cat ~/.hermes/secrets/github_token.txt)"
else
  echo "[WARN] github_token.txt missing — releases will fail with 403"
fi
cd ~/.hermes/scripts && /Users/mac/.local/share/uv/python/cpython-3.11.15-macos-aarch64-none/bin/python3 github_trending_monitor.py --summary
```

적용된 잡: `~/.hermes/cron/jobs.json`의 `b26b0579a45f` prompt 필드.

### 가드의 의의
- `[ -f ... ]` 체크가 없으면 `$(cat ~/.hermes/secrets/github_token.txt)`가 빈 문자열을 export하고 명령이 silent success → 403이 그대로 남고 다음 디버깅 라운드에서 토큰이 "있어 보이는데" 안 먹는 함정에 빠짐.
- `[WARN]` 메시지로 cron 로그에 명시적 신호 남김 → 사후 진단이 쉬워짐.
- uv 경로 명시 → `python3` 셸 alias가 시스템 3.9를 가리키는 함정 회피.

## 환경 스냅샷 (2026-07-14 기준)

- `~/.hermes/secrets/github_token.txt`: **없음** (계속 미생성)
- `~/.hermes/secrets/` 다른 토큰들: 모두 정상 존재 (notion, telegram, tistory, vercel, nvidia, ... 등 12개)
- Python: `/Users/mac/.local/share/uv/python/cpython-3.11.15-macos-aarch64-none/bin/python3` (arm64, requests 2.34.2 / bs4 4.15.0 설치됨)
- Notion DB: `33f76f2e-9097-8176-a537-d40ebb476ef9` (39/39 저장 성공)

## 향후 토큰 발급 시 참고

- GitHub → Settings → Developer settings → Personal access tokens → **Tokens (classic)**
- Scope: `public_repo`만 (read-only로 충분)
- 저장 위치: `~/.hermes/secrets/github_token.txt`, `chmod 600`
- 발급 후 `export GITHUB_TOKEN=$(cat ~/.hermes/secrets/github_token.txt) && python3 ... --summary` 로컬에서 1회 검증 → cron은 패치된 prompt가 자동 로드.