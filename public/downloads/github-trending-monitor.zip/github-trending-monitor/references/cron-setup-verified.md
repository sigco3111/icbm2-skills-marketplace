# Cron 실행 환경 — 검증된 설정

작성일: 2026-07-05 (실제 cron 실행 디버깅 후)

## 핵심 사실
이 스킬의 cron 잡(`b26b0579a45f`)은 **Hermes 자체 스케줄러**로 실행됨.
→ `crontab -l`에는 등록 안 됨. → 시스템 crontab 편집해도 의미 없음.
→ 토큰/Python 경로 주입은 `~/.hermes/cron/jobs.json`의 `command` 필드 또는 prompt의 실행 블록에서 처리.

## 검증된 Python 경로 (2026-07-05)
- 위치: `/Users/mac/.local/share/uv/python/cpython-3.11.15-macos-aarch64-none/bin/python3`
- arch: `arm64` (Apple Silicon)
- 의존성: `requests 2.34.2`, `beautifulsoup4 4.15.0` 설치 확인 완료
- 설치 명령 (재현):
  ```bash
  uv pip install --python ~/.local/share/uv/python/cpython-3.11.15-macos-aarch64-none/bin/python3 \
    --break-system-packages requests beautifulsoup4
  ```
  ⚠️ **`--break-system-packages` 필수.** uv가 관리하는 Python은 externally-managed라 기본 `uv pip install`이 거부됨. SKILL.md 본문의 "영구 해결" 레시피는 이 플래그가 빠져 있어서 그대로는 동작하지 않음 — 위 패치된 레시피 사용.

## 검증된 cron 실행 패턴
```bash
cd ~/.hermes/scripts && \
/Users/mac/.local/share/uv/python/cpython-3.11.15-macos-aarch64-none/bin/python3 \
  github_trending_monitor.py --summary
```

## 토큰 부재 시 동작 (개선 필요)
현재 스크립트는 `GITHUB_TOKEN`이 빈 문자열이어도:
1. 트렌딩 스크래핑을 모두 실행 (42회 요청 → 익명 한도 60회/h 거의 소진)
2. 그 다음 WATCHED_REPOS 12개 호출 → 전부 HTTP 403
3. "0개의 새 릴리즈 발견"으로 끝남

이상적 동작: `__main__` 진입점에서 토큰 부재 즉시 감지 → "TOKEN MISSING: ~/.hermes/secrets/github_token.txt" 안내 후 종료. 트래픽 낭비 방지. 차후 스크립트 패치 시 참고.

## secrets 디렉토리 실측 (2026-07-05)
존재: `notion_token.txt`, `telegram_bot_token.txt`, `tistory.env`, `youtube_token.pickle`, `vercel_token.txt`, `nvidia_keys.env`, `minimax.env`, `skillsmp/`, ...

없음: `github_token.txt` ← 이걸 만들어야 403 해결됨.