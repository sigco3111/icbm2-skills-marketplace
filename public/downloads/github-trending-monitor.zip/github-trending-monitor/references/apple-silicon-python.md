# Apple Silicon Python 환경 정리

작성일: 2026-07-02 (github-trending-monitor 크론 실패 디버깅 중 발견)

## 결론
Apple Silicon(M1/M2/M3/M4) Mac에서 `/usr/local/bin/python3` 경로는 **존재하지 않음**. 기존에 Intel Mac 기준으로 작성된 많은 스크립트/크론잡이 이 경로를 사용하고 있어 전부 깨져 있음.

## 환경별 Python 경로 매핑

| 경로 | Apple Silicon | Intel Mac | 비고 |
|------|---------------|-----------|------|
| `/usr/bin/python3` | ✅ (3.9.6 시스템) | ✅ (3.9.6 시스템) | `requests`/`bs4` 없음 |
| `/usr/local/bin/python3` | ❌ 없음 | ✅ (Homebrew) | **Intel 전용 가정 주의** |
| `/opt/homebrew/bin/python3.12` | ✅ (3.12.13 Homebrew) | ❌ 없음 | PEP 668 — 시스템 site-packages 격리 |
| `~/.local/share/uv/python/cpython-3.11.15-macos-aarch64-none/bin/python3` | ✅ | ❌ 없음 | uv 설치 Python (arch-specific) |

## 의존성 설치 표준 패턴

PEP 668 때문에 시스템 Python이나 Homebrew Python에 직접 `pip install` 불가. 항상 다음 셋 중 하나:

### 옵션 A: `uv` 임시 venv (가장 빠름)
```bash
uv venv /tmp/<job_name> --python /opt/homebrew/bin/python3.12
uv pip install --python /tmp/<job_name>/bin/python3 <패키지>
/tmp/<job_name>/bin/python3 <스크립트>
```

### 옵션 B: uv 영구 venv (크론잡에 권장)
```bash
uv venv ~/.venvs/<job_name> --python /opt/homebrew/bin/python3.12
uv pip install --python ~/.venvs/<job_name>/bin/python3 <패키지>
# 크론에서 ~/.venvs/<job_name>/bin/python3 호출
```

### 옵션 C: 기존 venv에 의존성 추가
```bash
uv pip install --python ~/.local/share/uv/python/cpython-3.11.15-macos-aarch64-none/bin/python3 <패키지>
```

## 진단 체크리스트
스크립트가 `No module named 'requests'` 또는 `No such file or directory`로 실패하면:
1. `which python3` — 의외의 경로(예: `/usr/bin/python3`)를 가리키는 게 흔함
2. `ls /opt/homebrew/bin/python*` — Apple Silicon에서는 이 경로 확인
3. `uv --version` — 없으면 `brew install uv` 또는 `curl -LsSf https://astral.sh/uv/install.sh | sh`
4. 임시 venv 만들고 의존성 설치 → 그 venv의 python으로 스크립트 실행

## 영향받는 크론잡 (2026-07-02 기준)
- `github_trending_monitor` — `/usr/local/bin/python3` 경로 사용 중 → **고장**
- 다른 `~/.hermes/scripts/*.py` 크론잡도 동일 패턴 의심됨 → 일괄 점검 필요

## 마이그레이션 액션
1. 크론잡마다 임시 venv 생성 + 의존성 설치
2. 크론 라인의 `python3` → `/tmp/<job_name>/bin/python3` 또는 `~/.venvs/<job_name>/bin/python3`으로 교체
3. 시간이 되면 일괄 마이그레이션 스크립트 작성해서 한 번에 처리