---
name: vite-react-spa-game-fork
description: "Vite + React SPA 게임 fork 워크플로우."
---

# ⭐ Vite + React SPA 게임 fork 워크플로우 (NEW, 2026-07-27, Athena Crisis 실측)

> Next.js로 오해하기 쉬운 **Vite + React 19 + pnpm 모노레포** 게임의 표준 fork-한글화-배포 워크플로우.
> Athena Crisis (nkzw-tech/athena-crisis, MIT, ⭐1967) fork 실측 기반.

## ⭐ Next.js vs Vite SPA — 첫 단계에서 판별

코드베이스에 `next` 패키지 / `next.config.*` / `pages/` / `app/` 디렉토리가 **하나도 없으면** Vite SPA일 가능성 100%.

| 신호 | Next.js | **Vite + React SPA** |
|---|---|---|
| `package.json` | `next` 의존성 | `react`, `react-dom`, `react-router-dom` |
| 라우팅 | `pages/` 또는 `app/` | `react-router-dom ^6 \|\| ^7` |
| 빌드 | `next build` | `vite build` |
| 정적 호스팅 | Vercel 기본 호환 | Vercel/GitHub Pages 모두 OK |
| 멀티플레이 | API Routes + Edge Functions | **완전 별도 서버 패키지** (artemis 같은) |

**즉시 검증 명령**:
```bash
grep -E "next|next.config" package.json 2>/dev/null | head -3
ls -la pages/ app/ 2>/dev/null | head -5
```

→ 둘 다 비어있으면 **Vite SPA 확정**. 모노레포면 워크스페이스별로 확인.

## ⭐ 모노레포 + closed-source variant 함정 (가장 큰 함정)

일부 게임의 클라이언트 워크스페이스는 `art/Variants.nkzw.tsx` 같은 **closed-source artifact**가 있어야 부팅됨. open-source fork에서는 이 파일이 없어서 `pnpm dev:client` (메인 클라) 불가능.

**판별 명령**:
```bash
grep -r "Variants.nkzw\|nkzw-tech/proprietary\|artifacts/" --include="*.ts*" --include="*.json" .
```

**대안 부팅 경로**:
```bash
# open-source에서 부팅 가능한 워크스페이스 찾기
ls -d */ | xargs -I {} sh -c 'test -f {}/index.html && test -f {}/vite.config.ts && echo "BOOTABLE: {}"'
# → 보통 offline/, docs/ 같은 단일 페이지 빌드가 부팅 가능
```

**표준 부팅 검증 (2단계)**:
1. **단일 워크스페이스 부팅** (예: `offline/`):
   ```bash
   PORT=3031 pnpm exec vite --host 0.0.0.0 --port 3031 ./offline/
   curl -s -o /dev/null -w "HTTP %{http_code}\n" http://localhost:3031
   ```
2. 풀스택 부팅은 closed-source artifact 받아서 진행 (fork 시 우선순위 낮음)

**즉시 적용 규칙**: 모노레포 게임 fork 시 **5분 안에 부팅 가능한 워크스페이스 1개만** 먼저 검증 → 본 작업 시작.

## ⭐ `portless` sudo TTY 함정

`pnpm dev`가 `portless` 도구(서브도메인 프록시)를 호출하는 프로젝트는 **헤드리스/원격/CI 환경에서 sudo TTY 요구 → fail**.

**판별**:
```bash
cat package.json | python3 -c "import json,sys; d=json.load(sys.stdin); print(d.get('scripts',{}).get('dev',''))"
# → "portless -l pnpm exec vite" 같은 형태면 함정 위험
```

**해결 — `portless` 우회**:
```bash
# ❌ 막힘 (헤드리스/CI)
pnpm dev

# ✅ 직접 vite 호출
pnpm exec vite --host 0.0.0.0 --port 3031 ./offline/
# 또는
PORT=3031 pnpm exec vite ./offline/
```

**왜 중요한가**: `portless`는 회사 네트워크(서브도메인 기반 멀티 서비스)에서 sudo TTY가 필요한 도구. 로컬 macOS에서는 sudo 안 해도 되지만, headless/CI 환경에서 hang. **portless 없이 직접 vite 부팅이 가장 안전**.

## ⭐ `--depth 1` clone 후 push 실패 — `parent object not found`

```bash
$ git clone --depth 1 <repo> .
# origin 자동 추가, shallow clone (commits 1개)

$ gh repo create sigco3111/fork --public --source=. --remote=origin --push
# X index-pack failed: parent object not found
```

**원인**: shallow clone의 commit은 parent를 참조하지만 로컬에 parent object가 없음. push 시 `git pack-objects`가 parent를 만들어내려다 실패.

**해결 — 풀 클론**:
```bash
# ❌ WRONG (함정)
git clone --depth 1 https://github.com/upstream/repo.git .

# ✅ CORRECT
git clone https://github.com/upstream/repo.git .  # 풀 history
git remote remove origin
gh repo create sigco3111/fork --public --description "..." --source=. --remote=origin --push=false
# 검증
git remote -v
git push -u origin main
```

**즉시 적용 규칙**: `gh repo create --push`까지 자동으로 가려면 **풀 클론 필수**. shallow clone + push는 두 단계로 나누면 안전.

## ⭐ `gh repo create` origin 매핑 함정 (sango 함정과 동일 계열)

```bash
# 1단계: clone (origin은 upstream을 가리킴)
git clone https://github.com/upstream/repo.git .

# 2단계: gh repo create는 origin 갱신 시도하지만, 가끔 실패
gh repo create sigco3111/fork --public --source=. --remote=origin --push=false
# X Unable to add remote "origin"  ← 경고
# 저장소 생성은 성공했지만 remote 추가 실패
```

**해결 — 2단계 검증**:
```bash
# 1) repo create
gh repo create sigco3111/fork --public --description "..." --source=. 2>&1 | tail -5

# 2) HTTP 200 확인
curl -s -o /dev/null -w "HTTP %{http_code}\n" "https://api.github.com/repos/sigco3111/fork"
# 404면 실패, 200이면 OK

# 3) origin 강제 재설정
git remote remove origin 2>&1 || true
git remote add origin https://github.com/sigco3111/fork.git
git remote -v  # 검증
```

→ `oss-fork-localization`의 "gh repo create origin 실패" 함정과 동일. 해당 함정 참조.

## ⭐ fbtee i18n 파이프라인 (Meta의 fbtee)

일부 게임(특히 React SPA)은 Meta의 **fbtee** 라이브러리로 i18n 처리. 단순 JSON 파일 수정이 아님.

**워크플로**:
```bash
# 1) 소스에서 메시지 자동 추출
pnpm fbtee
# 또는 pnpm fbtee:collect + pnpm fbtee:translate

# 2) 추출된 source_strings.json 구조
{
  "childParentMappings": {"7": 6, "68": 67, ...},
  "phrases": [
    {
      "hashToLeaf": {
        "HASH_BASE64": {
          "desc": "Description for human translator",
          "text": "Original English"
        }
      },
      "filename": "../hera/ui/AISelector.tsx",
      "loc": {"start": {...}, "end": {...}}
    },
    ...
  ]
}
```

**한국어 번역 추가 위치**:
- `source_strings.json` 자체에 `msgstr` 필드 추가 (방식 A)
- 또는 `ares/src/generated/` 안에 `ko_KR.ts` 같은 컴파일된 모듈 (방식 B)
- **정확한 위치는 fbtee codegen 출력 경로 확인 후 결정**

**검증 명령**:
```bash
# fbtee codegen이 만든 파일 찾기
find . -name "*.ts" -path "*/generated/*" 2>/dev/null | head -10
find . -name "*ko_KR*" -o -name "*ko_KR.ts" 2>/dev/null | head -10
```

**번역 키 개수 추정 (Athena Crisis 실측)**: 1,493개 phrases. 이 규모면:
- 🟢 Google Translate 일괄 → 후속 LLM 검토
- 🟡 수동 번역 (수 주)
- 🔴 LLM 한 줄씩 (수천 호출 = 비용 큼)

**즉시 적용 규칙**: fbtee 프로젝트 fork 시 `pnpm fbtee` 실행 → `source_strings.json` 확인 → 키 개수에 따라 번역 전략 결정.

## ⭐ AIRegistry 패턴 — 자동 노출되는 UI

`dionysus/AIRegistry.tsx`에 AI 클래스 등록만 하면 별도 UI 토글 컴포넌트 없이 기존 `AISelector.tsx` UI에 자동 노출됨. 이 패턴이 가장 깔끔.

**표준 워크플로** (AI/플러그인 추가):
```typescript
// 1) 새 AI 클래스 작성
export class MyAutoAI extends BaseAI {
  // ...
}

// 2) Registry에 등록
AIRegistry.set(6, {
  id: 6,
  name: 'MyAutoAI',
  description: 'Auto battle with custom rules',
  published: true,  // ← 이게 true면 UI에 자동 노출
  factory: () => new MyAutoAI(),
});
```

**장점**:
- UI 컴포넌트 수정 불필요
- 멀티플레이/싱글플레이 양쪽에서 같은 경로로 노출
- `published: false`로 일시적 비활성화 가능 (테스트용)

**즉시 적용 규칙**: 모드/AI/플러그인 추가 시 **레지스트리 패턴 우선 확인**. 레지스트리가 있으면 UI 변경 없이 등록만으로 작업 끝.

## ⭐ Vercel 정적 호스팅 — 멀티플레이 제외 결정

게임 프로젝트가 멀티플레이 서버(별도 워크스페이스)를 가질 때 **Vercel로 풀스택 배포는 어려움** (socket.io 미지원). 정적 클라이언트만 배포하는 게 표준.

**vercel.json (Vite SPA 표준)**:
```json
{
  "buildCommand": "pnpm build:client",
  "outputDirectory": "dist/ares",
  "framework": "vite",
  "rewrites": [
    { "source": "/(.*)", "destination": "/index.html" }
  ]
}
```

**멀티플레이 제외 명시 (README 필수)**:
```markdown
## ⚠️ 멀티플레이 미지원

이 fork는 정적 호스팅입니다. 멀티플레이 서버는 포함되지 않으며,
싱글플레이 캠페인/스커미시/AI 자동전투만 지원합니다.
```

**즉시 적용 규칙**: 모노레포 게임 fork + Vercel 배포 시:
1. `outputDirectory` = 클라이언트 워크스페이스의 dist 경로
2. `rewrites` = SPA fallback (모든 path → index.html)
3. README에 멀티플레이 미지원 명시

## ⭐ Node 22 vs Node 23 엔진 경고

일부 게임은 `engines.node: ">=23"` 명시. Node 22에서 pnpm install은 warning만, 실행도 정상.

**Vercel 영향**: Vercel 기본 빌드 환경 = Node 20/22. 엔진 요구 23이면 빌드 실패 가능.

**해결 — Vercel 프로젝트 설정**:
- Settings → General → Node.js Version → 22.x 또는 23.x 명시
- 또는 `package.json` engines를 `>=22`로 완화 (fork에서만)

**즉시 적용 규칙**: `engines.node` 확인 → Vercel 빌드 환경과 일치하는지 검증 → 불일치 시 Vercel 설정 또는 engines 완화.

## ⭐ Vite + pnpm 모노레포 부팅 우선순위

모노레포 게임에서 부팅 가능한 워크스페이스를 빠르게 찾는 법:

```bash
# 1) index.html + vite.config.ts 모두 가진 워크스페이스
find . -name "index.html" -not -path "*/node_modules/*" -not -path "*/dist/*" 2>/dev/null | while read f; do
  dir=$(dirname "$f")
  if [ -f "$dir/vite.config.ts" ] || [ -f "$dir/vite.config.js" ]; then
    echo "BOOTABLE: $dir"
  fi
done
```

→ 보통 `offline/`, `docs/`, `landing-page/` 같은 단일 페이지 워크스페이스가 부팅 가능.

**즉시 적용 규칙**: 모노레포 게임 fork 시 5분 부팅 검증은 **단일 워크스페이스** (offline 등) 으로. `pnpm dev` 풀스택 부팅은 closed-source artifact 이슈로 시간이 오래 걸림.

## 종합 워크플로 (Athena Crisis fork 실측 기반)

### 1단계: 셋업 (10분)
```bash
# 1) 디렉토리 + git init
mkdir -p /Users/mac/work/{name}-kr
cd /Users/mac/work/{name}-kr
git init && git checkout -b main

# 2) 풀 클론 (depth 1 절대 금지 — push 실패)
git clone https://github.com/upstream/repo.git .

# 3) origin 정리
git remote remove origin

# 4) gh repo create (--push=false로 두 단계로)
gh repo create sigco3111/{name}-kr --public --description "..." --source=. --remote=origin --push=false

# 5) origin 검증
git remote -v  # sigco3111/{name}-kr 가리키는지 확인

# 6) README + LICENSE + .gitignore 첫 commit
git add README.md LICENSE.md .gitignore
git commit -m "Initial commit: fork with Korean attribution"
git push -u origin main
```

### 2단계: 부팅 검증 (5분)
```bash
# 1) 의존성 설치
pnpm install  # 2~3분

# 2) 부팅 가능한 워크스페이스 찾기
find . -name "vite.config.ts" -not -path "*/node_modules/*" | head -5

# 3) 단일 워크스페이스 부팅
PORT=3031 pnpm exec vite --host 0.0.0.0 --port 3031 ./offline/ &
sleep 5
curl -s -o /dev/null -w "HTTP %{http_code}\n" http://localhost:3031
# → 200 OK 확인
```

### 3단계: i18n 추출 + 번역 (1~2시간)
```bash
# 1) 키 추출
pnpm fbtee
# → source_strings.json 생성

# 2) 키 개수 확인
python3 -c "import json; d=json.load(open('source_strings.json')); print(len(d.get('phrases', [])))"
# → 1,493 같은 결과

# 3) 한국어 번역 (Google Translate API 또는 수동)
# → 후속 LLM 검토로 품질 다듬기
```

### 4단계: 신규 기능 (1~3시간)
```bash
# 1) 기존 Registry 패턴 확인
cat dionysus/AIRegistry.tsx  # 또는 유사 Registry

# 2) 새 클래스 추가
cat > dionysus/AutoBattleAI.tsx << 'EOF'
// ... (워커 작성)
EOF

# 3) Registry에 등록
# → published: true면 UI 자동 노출
```

### 5단계: Vercel 정적 호스팅 (10분)
```bash
# 1) vercel.json 작성
cat > vercel.json << 'EOF'
{
  "buildCommand": "pnpm build:client",
  "outputDirectory": "dist/ares",
  "framework": "vite",
  "rewrites": [{"source": "/(.*)", "destination": "/index.html"}]
}
EOF

# 2) gh를 통해 Vercel 연결 (또는 GitHub 연결)
# → Vercel 대시보드에서 Import GitHub repo
```

### 6단계: README + 멀티플레이 제외 명시
```markdown
## 한국어 안내
- 1,493개 UI/캠페인 텍스트 한국어 번역
- 자동전투 AI 추가 (보수적/공격적)
- MIT 라이선스 (upstream 동일)

## ⚠️ 멀티플레이 미지원
Vercel 정적 호스팅으로 멀티플레이 서버(artemis)는 포함되지 않습니다.
싱글플레이 캠페인/스커미시/AI 자동전투만 지원합니다.
```

## 누적 통계 (Athena Crisis fork 실측, 2026-07-27)

| 메트릭 | 값 |
|---|---|
| **저장소** | https://github.com/sigco3111/athena-crisis-kr |
| **부팅 검증** | Vite 8.1.5, HTTP 200, 5분 |
| **fbtee 키** | 1,493 phrases |
| **자동전투 AI** | 2개 (Conservative + Aggressive) |
| **공통 함정** | depth 1 push 실패, portless sudo, closed-source variant, fbtee codegen |
| **Vercel 배포** | 정적 호스팅, 멀티플레이 제외 |

## 즉시 적용 규칙 종합

1. **모노레포 + Vite SPA** = Next.js 아님. 첫 단계에서 판별.
2. **closed-source variant** = 풀 부팅 막힘. 단일 워크스페이스 부팅 우선.
3. **portless sudo TTY** = 헤드리스 fail. 직접 vite 호출로 우회.
4. **`--depth 1` clone + push** = parent object not found. 풀 클론 필수.
5. **fbtee** = 단순 JSON 수정이 아님. `pnpm fbtee` 워크플로 따라야 함.
6. **AIRegistry** = UI 자동 노출. Registry 패턴 우선 확인.
7. **Vercel 정적 호스팅** = 멀티플레이 제외. README에 명시.
8. **Node 22 vs 23** = Vercel 빌드 환경과 일치 검증.

## 후속 작업

- 본 워크플로가 1회 실측이라, 다른 Vite SPA 게임 fork에서 재검증 필요
- fbtee 한국어 번역 후속 LLM 품질 검토 자동화 스킬 (별도 작업)
- AIRegistry 패턴 일반화 — 플러그인/모드 시스템 표준화 스킬
