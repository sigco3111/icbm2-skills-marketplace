---
name: notion
description: Notion API for creating and managing pages, databases, and blocks via curl. Search, create, update, and query Notion workspaces directly from the terminal.
version: 1.0.0
author: community
license: MIT
metadata:
  hermes:
    tags: [Notion, Productivity, Notes, Database, API]
    homepage: https://developers.notion.com
prerequisites:
  env_vars: [NOTION_API_KEY]
---

# Notion API

Use the Notion API via curl to create, read, update pages, databases (data sources), and blocks. No extra tools needed — just curl and a Notion API key.

## Prerequisites

1. Create an integration at https://notion.so/my-integrations
2. Copy the API key (starts with `ntn_` or `secret_`)
3. Store it in `$ENV_FILE`:
   ```
   NOTION_API_KEY=ntn_your_key_here
   ```
   **Token file path on this system:** `~/.hermes/secrets/notion_token.txt`
4. **Important:** Share target pages/databases with your integration in Notion (click "..." → "Connect to" → your integration name)

## API Basics

All requests use this pattern:

```bash
curl -s -X GET "https://api.notion.com/v1/..." \
  -H "Authorization: Bearer $NOTION_API_KEY" \
  -H "Notion-Version: 2025-09-03" \
  -H "Content-Type: application/json"
```

The `Notion-Version` header is required. This skill uses `2025-09-03` (latest). In this version, databases are called "data sources" in the API.

## Common Operations

### Search

```bash
curl -s -X POST "https://api.notion.com/v1/search" \
  -H "Authorization: Bearer $NOTION_API_KEY" \
  -H "Notion-Version: 2025-09-03" \
  -H "Content-Type: application/json" \
  -d '{"query": "page title"}'
```

### Get Page

```bash
curl -s "https://api.notion.com/v1/pages/{page_id}" \
  -H "Authorization: Bearer $NOTION_API_KEY" \
  -H "Notion-Version: 2025-09-03"
```

### Get Page Content (blocks)

```bash
curl -s "https://api.notion.com/v1/blocks/{page_id}/children" \
  -H "Authorization: Bearer $NOTION_API_KEY" \
  -H "Notion-Version: 2025-09-03"
```

### Create Page in a Database

```bash
curl -s -X POST "https://api.notion.com/v1/pages" \
  -H "Authorization: Bearer $NOTION_API_KEY" \
  -H "Notion-Version: 2025-09-03" \
  -H "Content-Type: application/json" \
  -d '{
    "parent": {"database_id": "xxx"},
    "properties": {
      "Name": {"title": [{"text": {"content": "New Item"}}]},
      "Status": {"select": {"name": "Todo"}}
    }
  }'
```

### Query a Database

```bash
curl -s -X POST "https://api.notion.com/v1/data_sources/{data_source_id}/query" \
  -H "Authorization: Bearer $NOTION_API_KEY" \
  -H "Notion-Version: 2025-09-03" \
  -H "Content-Type: application/json" \
  -d '{
    "filter": {"property": "Status", "select": {"equals": "Active"}},
    "sorts": [{"property": "Date", "direction": "descending"}]
  }'
```

### Create a Database

```bash
curl -s -X POST "https://api.notion.com/v1/data_sources" \
  -H "Authorization: Bearer $NOTION_API_KEY" \
  -H "Notion-Version: 2025-09-03" \
  -H "Content-Type: application/json" \
  -d '{
    "parent": {"page_id": "xxx"},
    "title": [{"text": {"content": "My Database"}}],
    "properties": {
      "Name": {"title": {}},
      "Status": {"select": {"options": [{"name": "Todo"}, {"name": "Done"}]}},
      "Date": {"date": {}}
    }
  }'
```

### Update Page Properties

```bash
curl -s -X PATCH "https://api.notion.com/v1/pages/{page_id}" \
  -H "Authorization: Bearer $NOTION_API_KEY" \
  -H "Notion-Version: 2025-09-03" \
  -H "Content-Type: application/json" \
  -d '{"properties": {"Status": {"select": {"name": "Done"}}}}'
```

### Add Content to a Page

```bash
curl -s -X PATCH "https://api.notion.com/v1/blocks/{page_id}/children" \
  -H "Authorization: Bearer $NOTION_API_KEY" \
  -H "Notion-Version: 2025-09-03" \
  -H "Content-Type: application/json" \
  -d '{
    "children": [
      {"object": "block", "type": "paragraph", "paragraph": {"rich_text": [{"text": {"content": "Hello from Hermes!"}}]}}
    ]
  }'
```

## Property Types

Common property formats for database items:

- **Title:** `{"title": [{"text": {"content": "..."}}]}`
- **Rich text:** `{"rich_text": [{"text": {"content": "..."}}]}`
- **Select:** `{"select": {"name": "Option"}}`
- **Multi-select:** `{"multi_select": [{"name": "A"}, {"name": "B"}]}`
- **Date:** `{"date": {"start": "2026-01-15", "end": "2026-01-16"}}`
- **Checkbox:** `{"checkbox": true}`
- **Number:** `{"number": 42}`
- **URL:** `{"url": "https://..."}`
- **Email:** `{"email": "user@example.com"}`
- **Relation:** `{"relation": [{"id": "page_id"}]}`

## ⚠️ Database Has TWO IDs — Which One to Use for What

When you `GET /v1/databases/{data_source_id}`, the response contains **two IDs**:

```json
{
  "id": "36976f2e-9097-81e1-bb34-000b13fb3627",      // data_source_id — for QUERYING
  "parent": {
    "database_id": "36976f2e-9097-81e1-a373-e06f2da6e99c"  // ACTUAL database_id — for CREATING PAGES
  }
}
```

| Operation | Endpoint | Use This ID |
|-----------|----------|-------------|
| Query rows | `POST /v1/data_sources/{id}/query` | `data_source_id` (the `id` field) |
| Create page | `POST /v1/pages` with `parent.database_id` | `parent.database_id` (NOT the `id` field!) |

**Symptom of using wrong ID:** `POST /v1/pages` with `parent: {database_id: DATA_SOURCE_ID}` returns `404 object_not_found`. Use `parent.database_id` from the GET response.

## ⚠️ API Version Gotcha: Creating Databases

**`2025-09-03` CANNOT create new databases** — it returns:
```
"Creating new databases with data sources is not supported in this endpoint for API version 2025-09-03"
```

**Use `2022-06-28` to create databases** (`POST /v1/databases`), then use `2025-09-03` for everything else:

```bash
# Creating a new database — use 2022-06-28
curl -s -X POST "https://api.notion.com/v1/databases" \
  -H "Authorization: Bearer $NOTION_API_KEY" \
  -H "Notion-Version: 2022-06-28" \
  -H "Content-Type: application/json" \
  -d '{
    "parent": {"page_id": "xxx"},
    "title": [{"type": "text", "text": {"content": "My Table"}}],
    "properties": {
      "Name": {"title": {}},
      "Status": {"rich_text": {}}
    }
  }'
```

**Rule of thumb:** Use `2022-06-28` for create/delete operations on databases; use `2025-09-03` for queries and page operations.

## Key Differences in API Version 2025-09-03

- **Databases → Data Sources:** Use `/data_sources/` endpoints for queries and retrieval
- **Two IDs:** Each database has both a `database_id` and a `data_source_id`
  - Use `database_id` when creating pages (`parent: {"database_id": "..."}`)
  - Use `data_source_id` when querying (`POST /v1/data_sources/{id}/query`)
- **Search results:** Databases return as `"object": "data_source"` with their `data_source_id`

## ⚠️ Destructive Operations Safety

**CRITICAL: Never use DELETE or archive operations without explicit user confirmation.**

The following operations are **destructive and irreversible**:
- `DELETE /v1/blocks/{block_id}` — permanently deletes a block
- `DELETE /v1/pages/{page_id}` — permanently deletes a page
- `PATCH` with `"archived": true` — archives a page/database

**Before any destructive operation:**
1. Verify the target ID is correct (double-check UUID)
2. Confirm with the user before executing
3. If automating, use `in_trash: false` filters to avoid modifying trash items
4. Never chain delete operations in a loop without user approval

**Historical incident (2026-04-08):** Accidentally deleted the Notion 아이디어 노트 DB during page restructuring. Data was NOT recoverable from trash. Always confirm before destructive API calls.
**Historical incident (2026-04-29):** First table rebuild displayed rows in wrong order (18→1 instead of 1→18). Root cause: Notion displays rows in creation order, not insertion order. Fix: insert rows in reverse (18→1) so they display correctly (1→18). See reverse insertion note above.

## ⚠️ Schema Introspection Before Writing

**Always introspect the actual database schema before creating pages**, not just assuming from documentation. Property types can differ from expectations (e.g., a field named "Tier" may be `url` type instead of `select`).

```bash
# Introspect database schema
curl -s "https://api.notion.com/v1/databases/{DATABASE_ID}" \
  -H "Authorization: Bearer $NOTION_API_KEY" \
  -H "Notion-Version": 2022-06-28" | \
  jq '.properties | to_entries[] | "\(.key): \(.value.type)"'
```

> **⚠️ Korean Property Names on This System:** ICBM2's Notion databases use Korean property names (이름, 날짜, 상태, etc.) — NOT the English names shown in documentation examples. Using English names (e.g., `"Name"`, `"Date"`, `"Status"`) causes `400 validation_error`. See `references/db-schema-introspection.md` for the full reference including working Python examples.

**Known gotcha:** The Agent Benchmark Tracker DB (`34076f2e-9097-81a0-9314-c781e2742b83`) has `Tier` as `url` type (not `select`), so the Tier property must be omitted when writing — use the calculated tier value only in page body text or as a comment.

## Table Rebuild Workflow (When Patching Isn't Enough)

The Notion API has limitations with inline table blocks:
- **Cannot reorder rows** — PATCH only updates individual rows in place
- **Cannot remove columns** — existing table properties cannot be deleted
- **Cannot change row order** — rows are always appended; the API doesn't support reordering

**When to rebuild instead of patch:**
- Need to reorder rows (e.g., sort by schedule)
- Need to remove/rename columns
- Bulk delete old rows + insert new ones (more than ~5 changes)
- Table structure changed significantly

**Rebuild procedure:**
1. `DELETE /v1/blocks/{block_id}` — archive the old inline table block
2. `POST /v1/databases` (API v2022-06-28) — create new database with desired schema
3. `PATCH /v1/blocks/{page_id}/children` — add `child_database` block referencing the new DB
4. `POST /v1/pages` in a loop — insert rows in **REVERSE order** (see above)
5. Verify with `POST /v1/databases/{id}/query`

**⚠️ Critical: Row Display Order is CREATION ORDER, not insertion order.**
Notion displays table rows in **creation order** (oldest first, newest last). This is NOT alphabetical or property-based.
To get a specific display order (e.g., 03:00 at top → 22:00 at bottom), **insert rows in REVERSE order**:
- Sort your data in ascending order (e.g., 03:00, 03:30, ... 22:00)
- Then iterate and insert them in **descending order** (insert 22:00 first, 03:00 last)
- Result: 03:00 appears at top of table, 22:00 at bottom ✅

**⚠️ Position limitation:** The new `child_database` block always appears at the **bottom of the parent page**, regardless of where the old block was. Rebuilding cannot preserve the original page position. If position matters, you must manually drag the table in Notion UI after rebuilding.

**Note:** The new `child_database` block auto-appears on the page when the DB is created under the page as parent. Adding it explicitly as a block is optional (API is unreliable for this).

## Notes

- Page/database IDs are UUIDs (with or without dashes)
- Rate limit: ~3 requests/second average
- The API cannot set database view filters — that's UI-only
- Use `is_inline: true` when creating data sources to embed them in pages
- Add `-s` flag to curl to suppress progress bars (cleaner output for Hermes)
- Pipe output through `jq` for readable JSON: `... | jq '.results[0].properties'`

## ⚠️ Shell Escaping: Always Use Temp JSON Files for POST/PATCH

**NEVER pass JSON inline in curl HEREDOC or subprocess strings** — shell interprets `{`, `}`, quotes, and newlines incorrectly, causing cryptic exit code 3 or 400 errors.

**Always write the JSON payload to `/tmp/` first, then use `-d @/tmp/file.json`:**

```bash
# ❌ BAD — fails with shell escaping issues
curl -s -X POST "https://api.notion.com/v1/pages" \
  -H "Authorization: Bearer $NOTION_API_KEY" \
  -H "Notion-Version: 2025-09-03" \
  -H "Content-Type: application/json" \
  -d '{"parent": {"database_id": "xxx"}, ...}'

# ✅ GOOD — reliable, no escaping issues
echo '{"parent": {"database_id": "xxx"}, ...}' > /tmp/notion_payload.json
curl -s -X POST "https://api.notion.com/v1/pages" \
  -H "Authorization: Bearer $NOTION_API_KEY" \
  -H "Notion-Version: 2025-09-03" \
  -H "Content-Type: application/json" \
  -d @/tmp/notion_payload.json
```

**This applies to both terminal() and execute_code environments.** In execute_code, `subprocess.check_output(cmd, shell=True)` with inline JSON always fails. Use `subprocess.check_output(cmd)` with a pre-written temp file, or write the JSON in the shell via `echo '...' > /tmp/file.json`.

## ⚠️ Query Verification: `/data_sources/{id}/query` May Return 0 Despite Pages Existing

The `POST /v1/data_sources/{id}/query` endpoint (API v2025-09-03) can return `{"results": []}` even when pages known to exist are in the database. Date filters on `생성일` property seem to return 0 regardless of actual data.

**For verification, use `/search` instead:**
```bash
curl -s -X POST "https://api.notion.com/v1/search" \
  -H "Authorization: Bearer $NOTION_API_KEY" \
  -H "Notion-Version: 2025-09-03" \
  -H "Content-Type: application/json" \
  -d '{"query": "PAGE_TITLE_FRAGMENT", "filter": {"value": "page", "property": "object"}}' \
  | jq '.results | length'
```

The search endpoint reliably finds pages created via the API.
