---
name: mac-bootstrap
description: |
  M4/M3 등 새 Apple Silicon Mac 부트스트랩 워크플로. Homebrew → CLI 도구(cmus/cmux/VS Code 등) →
  런타임(Bun/Node) → 셸 alias 등록까지 단계별 자동화. **반드시 TTY가 필요한 작업(brew install.sh,
  OAuth login 등) 은 사용자가 직접 Terminal.app에서 실행**하도록 안내. "맥 새로 셋팅",
  "M4 이주", "Mac 부트스트랩", "macOS 환경 셋업", "Apple Silicon 세팅" 같은 요청에 발동.
  **Apple Silicon arm64 vs x86_64 바이너리 섞임 함정 (Errno 86 Bad CPU type) 진단/해결 포함** —
  `file $(which <tool>)` + `uname -m` 대조 → 정상 arm64 바이너리로 교체.
version: 1.0.2
author: sigco3111
license: MIT
metadata:
  hermes:
    tags: [macos, m4, apple-silicon, bootstrap, homebrew, setup, migration, terminal]
    related_skonces: [tokscale, python-oss-bootstrap, opencode-nvidia-setup]
---

# Mac 부트스트랩 — M4/M3 새 Apple Silicon Mac 환경 셋업

> "M4 맥으로 마이그레이션해서 없는게 많음. 지금부터 필요한 앱들을 하나씩 요청할테니 설치해줘"

## 핵심 원칙: 비대화형 함정을 미리 알고 TTY 작업은 사용자에게 위임

이 워크플로의 가장 큰 함정은 **PTY가 필요한 도구(brew install.sh, OAuth login)** 를
`terminal()` 비대화형 백그라운드로 띄우면 silent fail 한다는 것. `sudo whoami`가 비번
없이 root 떨어지는 환경이어도 brew는 fail함 — 스크립트 자체가 `have_sudo_access()` 호출
시 TTY 체크함.

**3-tier 작업 분류:**

| Tier | 종류 | 자동 가능? | 예시 |
|---|---|---|---|
| **T1 (자동)** | 비대화형 설치 | ✅ | `brew install bun node`, `brew install --cask cmux vscode` |
| **T2 (사용자 직접)** | TTY 필요 | ❌ | `brew install.sh` (install), `tokscale login` (OAuth) |
| **T3 (사용자 직접)** | 인증 필요 | ❌ | GitHub login, Apple ID, sudo 캐시 갱신 |

## 단계별 워크플로

### Phase 0 — 진단 (먼저 환경 파악)

```bash
# 1. 시스템 정보
uname -m && sw_vers

# 2. Xcode CLT (대부분 설치됨)
xcode-select -p  # /Library/Developer/CommandLineTools 나오면 OK

# 3. sudo 캐시 상태 (NOPASSWD 설정 환경 체크)
sudo -n true 2>&1 && echo 'SUDO_CACHED' || echo 'NEED_PASSWORD'

# 4. 기존 런타임 체크
for cmd in brew bun node npx npm python3 git gh; do
  command -v $cmd && echo "✅ $cmd: $($cmd --version 2>&1 | head -1)"
done
```

**NOPASSWD 함정**: `sudo -n true` 가 통과해도 brew install.sh는 fail할 수 있음.
**항상 Phase 1에서 사용자에게 TTY 작업 위임 필요.**

### Phase 1 — Homebrew 설치 (TTY 필요 → 사용자 직접)

사용자에게 Terminal.app에서 직접 실행하도록 안내:

```bash
# 1단계: sudo 캐시 갱신
sudo -v

# 2단계: brew 설치 (TTY라 정상 작동, sudo 비번 묻는 창 뜨면 입력)
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# 3단계: PATH 등록
echo 'eval "$(/opt/homebrew/bin/brew shellenv)"' >> ~/.zprofile
```

**사용자가 "brew 설치 끝" 알리면 그 다음부터 자동.**

### Phase 2 — 핵심 도구 설치 (전부 자동)

```bash
# CLI 도구 (sikr)
brew install git gh jq yq fzf ripgrep bat eza

# 런타임 (자주 쓰는 조합)
brew install bun node python@3.11

# GUI 앱 (cask)
brew install --cask visual-studio-code iterm2 arc raycast
```

각 설치 후 `which <cmd> && <cmd> --version` 으로 검증.

### Phase 2.5 — Python 도구 격리 설치: `uv` (2026-06-29 추가)

**시스템 Python(3.9.6 등)은 macOS에서 보호되어** 임의 패키지 설치가 거부될 수 있고, macOS Monterey+는 PEP 668(externally-managed)로 `pip install`을 막음. brew Python(`/opt/homebrew/bin/python3`)으로 글로벌 설치하면 시스템 도구와 충돌 위험. **해결**: Astral `uv`로 격리된 venv에 도구 설치.

```bash
# 1) uv 설치 (공식 설치 스크립트, 비대화형 OK)
curl -LsSf https://astral.sh/uv/install.sh | sh
# → /Users/<user>/.local/bin/uv

# 2) PATH 영구 등록 (~/.zshrc)
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.zshrc

# 3) 격리 도구 설치 (system Python 안 건드림)
uv tool install <pkg>          # 예: uv tool install ruff, uv tool install black

# 4) 검증
which uv && uv --version
# (설치한 도구 실행 예) ruff --version
```

**왜 `uv tool install`인가?**
- **격리**: 각 도구가 독립 venv에 설치 → 시스템/다른 도구와 의존성 충돌 없음
- **시스템 Python 보호**: macOS 기본 `python3` (3.9.x) 와 `/opt/homebrew/bin/python3` 둘 다 안 건드림
- **brew 의존성 X**: `brew install python@3.XX` 안 해도 됨 (uv가 자체 Python 다운로드)
- **빠른 속도**: Rust로 작성, venv 생성 ~ms 단위
- **PEP 668 자동 우회**: 시스템 Python 건드리지 않으므로 externally-managed 에러 안 남

**핵심 도구 패턴 (brew vs uv 분담)**:

| 종류 | 도구 | 설치 방법 |
|---|---|---|
| 시스템 CLI (git, gh, jq, ripgrep) | brew formula | `brew install <pkg>` |
| 런타임 (Bun, Node — 자체 의존성 큼) | brew formula | `brew install bun node` |
| 시스템 Python 패키지 (numpy 등 글로벌 도구) | brew formula | `brew install python@3.11 && /opt/homebrew/bin/pip3 install <pkg>` |
| **Hermes/에이전트/Python CLI 도구 (ruff, black, notebooklm-py 등)** | **uv tool** | **`uv tool install <pkg>` (격리 venv)** |
| Python 프로젝트 의존성 | uv project | `uv sync` / `uv pip install` |

**검증 체크리스트**:
```bash
# uv 자체
which uv && uv --version    # uv 0.x.x ...

# 설치한 도구 (ruff 예시)
uv tool list                # 설치된 uv 도구 목록
ruff --version              # 격리 도구 실행

# 격리 환경 확인 (시스템 Python 미오염)
/usr/bin/python3 --version  # 여전히 3.9.6
which python3               # /opt/homebrew/bin/python3 (brew) 또는 /usr/bin/python3 (system)
```

**자주 쓰는 uv 명령 레퍼런스**:
```bash
uv tool install <pkg>       # 격리 설치
uv tool list                # 설치된 도구 + Python 버전
uv tool uninstall <pkg>     # 제거
uv tool upgrade <pkg>       # 업그레이드
uv python install 3.12      # 격리 Python 다운로드 (uv가 자체 관리)
uv run <cmd>                # 임시 venv에서 <cmd> 실행
uvx <tool> <args>          # 일회성 (uv tool run의 단축형, npm npx와 유사)
```

**함정 1 (`uv` 설치 후 PATH 미적용)**:
- 첫 설치 후 `which uv` → not found. **다음 명령으로 즉시 적용**:
  ```bash
  export PATH="$HOME/.local/bin:$PATH"
  ```
- 영구 등록은 `~/.zshrc`에 추가. **다른 dotfile (`.zprofile`, `.bashrc` 등) 안 건드림** — brew와 uv의 PATH 등록 위치 충돌 방지.

**함정 2 (zshrc 안 uv PATH가 있어도 `terminal()` 비대화형 호출에서 인식 안 됨)**:
- Hermes `terminal()`은 비대화형 서브셸이라 `~/.zshrc`가 로드 안 됨.
- **해결**: 명령 안에 `export PATH="$HOME/.local/bin:$PATH"` 명시, 또는 `source ~/.zshrc && <tool> ...` 형태 사용.
- **권장 패턴**: `terminal(command='export PATH="$HOME/.local/bin:$PATH" && <tool> ...')`

### Phase 3 — 셸 alias 등록

**패턴**: 헤더 마커로 블록 단위 관리 → 중복 추가 방지.

```bash
# >>> <tool> aliases (added YYYY-MM-DD) >>>
# <설명>
alias <name>='<cmd>'  # <설명>
alias <name>='<cmd>'  # <설명>
# <<< <tool> aliases <<<
```

`~/.zshrc` 끝에 append. 기존 블록 있으면 마커로 제거 후 재생성.

**검증**:
```bash
zsh -i -c 'alias | grep "^alias <prefix>"'  # 새 shell 시뮬레이션
zsh -i -c '<alias_name>'                       # 실제 명령 동작
```

### Phase 4 — TTY 필요 작업 (사용자 직접)

OAuth login, Apple ID 인증, ssh 키 생성, git config user.name/email 등.
**사용자에게 1-2-3 단계로 명확히 안내:**

```bash
# 예: tokscale GitHub OAuth
bunx tokscale@latest login   # 브라우저 열림, GitHub 계정 1회 인증
```

## 🪤 함정 모음 (2026-06-26 M4 마이그레이션 검증)

### 1. brew install.sh 비대화형 fail
**증상**: `terminal()` 또는 백그라운드 PTY로 `curl | bash` 실행 → "Need sudo access" 출력하고 abort.
**원인**: 스크립트 line 530 `have_sudo_access` → TTY 체크 → 비대화형 환경에서 sudo 비번 못 묻고 fail.
**해결**: 사용자 Terminal.app에서 직접 실행. `sudo -v` 미리 해두면 brew install 자체는 자동 진행됨 (단, brew install.sh 호출은 TTY 필수).

### 2. `sudo -n true` 통과 ≠ brew 통과
**증상**: `sudo -n true` 가 비번 없이 root 떨어지는 환경에서도 brew는 fail.
**원인**: brew 스크립트가 별도로 `have_sudo_access()` 함수 호출하면서 추가 검증.
**교훈**: sudo 캐시 상태만 보고 "자동 가능" 단정 금지. **Phase 1은 항상 사용자 TTY 위임**.

### 3. Apple Silicon arm64 호환성
**확인**: `uname -m == arm64` → Homebrew prefix `/opt/homebrew/` (Intel Mac의 `/usr/local/` 아님).
**셸 PATH 우선순위**: `/opt/homebrew/bin` 이 `/usr/local/bin` 보다 앞에 와야 함. macOS 기본 PATH는 `/usr/local/bin` 먼저 — `~/.zprofile`에 `eval "$(/opt/homebrew/bin/brew shellenv)"` 추가 필수.

### 4. zsh vs bash PATH 로딩 순서
**증상**: `~/.zshrc`에 alias 추가해도 새 shell에서 인식 안 됨.
**원인**: zsh는 `.zshrc` (interactive non-login) 와 `.zprofile` (login) 모두 로드. brew PATH는 `.zprofile`에, alias는 `.zshrc`에.
**검증 패턴**: `zsh -i -c 'alias | grep ...'` 로 interactive shell 시뮬레이션.

### 4a. ⚠️ 도구 터미널이 bash인데 zshrc를 source 하면 망가진다 (2026-06-26 검증)
**증상**: macmini 환경에서 도구 셸이 bash(`/opt/homebrew/bin/bash`)인데 `source ~/.zshrc` 실행 → `bindkey: 명령을 찾을 수 않음`, `(I)_direnv_hook: 표현식에서 산술 문법 오류`.
**원인**: 도구 환경이 bash로 실행되는데 bash는 zsh 전용 명령(`bindkey`, `typeset -f _direnv_hook` 등)을 모름. 사용자에게 적용됐다고 거짓 보고 → 사용자가 새 터미널 열어봐야 진짜 깨져있는지 알게 됨.
**교훈**: 도구 환경에서 `source ~/.zshrc` 같은 zsh 전용 dotfile 직접 실행하면 안 됨. 검증할 때는 **`zsh -c 'source ~/.zshrc && bindkey | grep ...'`** 로 명시적으로 zsh 서브셸 띄워서 검증.
**검증 패턴**:
```bash
# ❌ 잘못된 검증 (bash 환경에서 실행 시 망가짐)
source ~/.zshrc && bindkey | grep '^R'

# ✅ 올바른 검증 (zsh 명시)
zsh -c 'source ~/.zshrc 2>&1; echo "EXIT=$?"; bindkey | grep -E "\^R|\^T" | head -3'
```
**사용자에게 적용됐다고 보고하기 전**: `zsh -i -c 'bindkey | grep <key>'`로 한 번 더 확인.

### 4b. ⚠️ brew fzf의 `key-bindings.zsh`는 zsh에서 깨진다 (2026-06-26 검증)
**증상**: `source <(fzf --zsh)` 또는 `source /opt/homebrew/opt/fzf/shell/key-bindings.zsh` 하면 → `예기치 않은 ')' 토큰 주변에서 문법 오류`, `() {` 익명 함수 줄에서 fail.
**원인**:
- brew의 `fzf/shell/key-bindings.zsh`는 첫 줄 shebang이 없고 `() { ... }` bash 익명 함수 문법 사용 — zsh는 이걸 명령으로 파싱하다가 `)`에서 syntax error.
- `source <(...)` (process substitution)도 zsh와 bash 간 호환성 문제로 부작용.
**해결 — `.zshrc`에 zsh-안전 패턴 직접 작성**:
```bash
# fzf: completion만 (homebrew site-functions)
if [ -f /opt/homebrew/share/zsh/site-functions/_fzf ]; then
  source /opt/homebrew/share/zsh/site-functions/_fzf 2>/dev/null
fi

# fzf key bindings (수동 등록)
if command -v fzf >/dev/null 2>&1; then
  bindkey '^T' fzf-file-widget     # Ctrl+T: 파일 fuzzy
  bindkey '^R' fzf-history-widget  # Ctrl+R: 히스토리 fuzzy
  bindkey '\ec' fzf-cd-widget      # Alt+C: 디렉토리 fuzzy → cd
fi
```
**검증**: `zsh -c 'bindkey | grep -E "\^R|\^T"'` → `fzf-history-widget` / `fzf-file-widget` 나오면 OK.
**일반화**: brew로 설치한 shell integration (bash/zsh 양쪽 미지원) → 직접 `bindkey` 등록이 더 안전. fzf 외에 다른 도구도 같은 패턴 가능.

### 5. `--cask` vs `--formula` 선택
**공식 CLI 도구** → `formula` (brew install bun)
**GUI 앱** → `cask` (brew install --cask visual-studio-code)
**CLI만 있는 cask 앱** (cmux) → cask여도 `/opt/homebrew/bin/` 에 CLI 심볼릭 링크 자동 생성됨.

### 6. conda 잡 흔적 (M4 새 PC)
**현상**: 인텔맥에서 conda 사용했었다면 M4에 흔적 없음 → 신규 설치 필요.
**판단**: `which conda` → 없으면 깨끗한 상태로 보고 표준 venv/uv 패턴 사용.

### 7. ⚠️ "오마이오픈에이전트" 사용자 코렉션 (2026-06-26)
**상황**: 주인님가 "오마이오픈에이전트" 설치 요청.
**잘못한 첫 시도**: `brew install oh-my-agent` — 이건 **다른 프로젝트** (Multi-Agent Orchestrator for AI IDEs, oh-my-agent 10.4.0). 이름만 비슷.
**정답**: `code-yeongyu/oh-my-openagent` (npm: `oh-my-opencode` 듀얼 퍼블리시) — OpenCode 플러그인.
**판별법**: brew search로 `oh-my*` 확인 후, 사용자가 보낸 config JSON schema URL (`https://raw.githubusercontent.com/code-yeongyu/oh-my-openagent/dev/assets/oh-my-openagent.schema.json`)로 정확히 식별.
**교훈**: 이름 비슷한 두 프로젝트 — "oh-my-agent" (brew, 다중 IDE orchestrator) vs "oh-my-openagent" (npm, OpenCode 전용 플러그인) — 사용자가 말한 이름이 헷갈리면 **무조건 schema/config URL로 식별** 후 진행.

### 8. oh-my-openagent 비대화형 install 패턴
**표준 install**: `bunx oh-my-openagent install` (TUI 가이드) → OAuth 단계가 있어 TTY 필요.
**비대화형 옵션** (주인님가 sudo 캐시 살아있을 때 OK):
```bash
bunx oh-my-openagent install --no-tui --platform=opencode --minimax-coding-plan=yes --skip-auth
```
**인증은 skip하지 마라**: `--skip-auth` 플래그는 가이드 메시지만 스킵, 실제 provider 설정은 OpenCode TUI에서 별도. **OAuth 인증은 사용자 직접** (Phase 4로 위임).

**⚠️ 2026-06-26 함정: --claude/--gemini/--copilot 셋 다 필수** (사용 안 해도 명시):
```
[X] Validation failed:
  * --claude is required (values: no, yes, max20)
  * --gemini is required (values: no, yes)
  * --copilot is required (values: no, yes)
```
**정답**:
```bash
bunx oh-my-openagent install --no-tui --platform=opencode \
  --minimax-coding-plan=yes --claude=no --gemini=no --copilot=yes --skip-auth
```
자세한 함수정 + Claude Code 라우팅 패턴은 `devops/opencode-nvidia-setup` 스킬 참조.

### 9. Claude Code → MiniMax Anthropic-호환 라우팅 (2026-06-26)
**상황**: `brew install claude-code` (Anthropic CLI) 깔고 주인님의 주력 모델은 MiniMax-M3. Claude Code는 기본 `api.anthropic.com` 호출 → MiniMax 구독 활요하려면 라우팅 필요.
**해결 — `.zshrc`에 환경변수 3개**:
```bash
# >>> claude code (MiniMax) env >>>
export ANTHROPIC_BASE_URL="https://api.minimax.io/anthropic"
export ANTHROPIC_AUTH_TOKEN="$MI...EY"   # source로 로드됨
export ANTHROPIC_MODEL="MiniMax-M3"
[ -f ~/.hermes/secrets/minimax.env ] && source ~/.hermes/secrets/minimax.env
# <<< claude code (MiniMax) env <<<
```
**근거 위치**: `~/.hermes/config.yaml`의 `model.base_url: https://api.minimax.io/anthropic` + `providers.minimax.api_key_env: MINIMAX_API_KEY`. Hermes secrets 구조를 활용해서 키가 한 곳에서 관리됨. 자세한 패턴은 `devops/opencode-nvidia-setup` 스킬의 "Claude Code → MiniMax 라우팅" 섹션 참조.

### 10. ⚠️ x86_64 바이너리가 arm64 시스템에 섞임 — `Errno 86 Bad CPU type` (2026-07-02 검증)
**증상**: Apple Silicon(M4) 시스템에서 x86_64 바이너리를 호출하면:
```
OSError: [Errno 86] Bad CPU type in executable: '/Users/mac/.hermes/bin/uv'
```
또는 터미널에서 직접 실행 시:
```
arch: posix_spawnp: /Users/mac/.hermes/bin/uv: Bad CPU type in executable
```
**근본 원인**:
- M4 (arm64) 시스템에서 x86_64 바이너리는 `arch -x86_64` (Rosetta) 경유 필요
- brew formula / curl install.sh / 옛 배포본이 어떤 경로로 x86_64 빌드를 가져왔을 때 발생
- 일반적으로 `/opt/homebrew/bin/` (Apple Silicon brew)에는 arm64 바이너리가 깔리지만, **수동 설치 / 옛 설치본 / 다른 prefix (예: `~/.hermes/bin/` 같은 비표준 경로)에 x86_64가 섞여 들어간 케이스**가 흔함
- Rosetta 2가 설치 안 됐거나 비대화형 컨텍스트에서 fallback이 안 되는 환경에서 fail
**실제 사례 (2026-07-02)**:
- `~/.hermes/bin/uv` = Mach-O **x86_64** (53MB, 6/26 설치) ← 잘못된 빌드
- `~/.local/bin/uv` = **aarch64-apple-darwin** v0.11.25 ← 정상 빌드
- M4 (Apple Silicon) 시스템
- `arch -x86_64 ~/.hermes/bin/uv` → `posix_spawnp: Bad CPU type in executable` (Rosetta fallback도 안 됨)
- `hermes update`가 시스템 Python venv에서 `~/.hermes/bin/uv`를 호출 → `OSError [Errno 86]`로 dependency install 단계 fail

**진단 3종 (무조건 같이 실행)**:
```bash
# 1) 시스템 아키텍처 확인
uname -m                          # arm64 (Apple Silicon) 또는 x86_64 (Intel)

# 2) 의심 바이너리 아키텍처 확인
file $(which <tool>)              # "Mach-O 64-bit executable x86_64" vs "arm64"
# 또는 명시적 경로
file /Users/mac/.hermes/bin/uv    # 둘 다 표시되어야 비교 가능

# 3) 정적 확인 (lipo)
lipo -archs /Users/mac/.hermes/bin/uv   # x86_64 또는 arm64 또는 둘 다(fat binary)

# 4) Rosetta fallback 가능 여부
arch -x86_64 $(which <tool>) --version   # "Bad CPU type" → Rosetta 미설치 또는 x86_64도 깨진 상태
```

**해결 패턴 (3가지, 추천 순)**:

| 옵션 | 내용 | 시간 | 트레이드오프 |
|---|---|---|---|
| **A (추천)** | 정상 arm64 바이너리가 시스템 어딘가에 있으면 → 그걸로 복사 | 30초 | 가장 빠름. 데이터/설정 무손실 |
| B | Rosetta 2 설치 후 x86_64 살리기 | 5~10분 | 시스템 변경 큼, 검증 시간 김 |
| C | 도구 재설치 (`brew install`, `curl | sh`) | 1~3분 | 환경에 따라 다른 prefix로 또 섞일 위험 |

**A안 명령어 (가장 자주 쓰는 패턴)**:
```bash
# 1) 정상 arm64 바이너리가 어딘가에 있는지 확인
ls -la /Users/mac/.local/bin/uv  # uv-tool-install로 설치한 정상본
~/.local/bin/uv --version

# 2) 정상본 → 깨진 위치로 복사
cp -f /Users/mac/.local/bin/uv /Users/mac/.hermes/bin/uv
chmod +x /Users/mac/.hermes/bin/uv

# 3) 검증
file /Users/mac/.hermes/bin/uv      # "Mach-O 64-bit executable arm64"
/Users/mac/.hermes/bin/uv --version  # 정상 버전 출력

# 4) 원래 명령이 정상 작동하는지
hermes update
```

**B안 — Rosetta 2 설치** (어쩔 수 없이 x86_64 바이너리를 살려야 할 때):
```bash
softwareupdate --install-rosetta --agree-to-license
# 또는 GUI 안내
```

**C안 — brew 재설치** (수동 설치 경로가 brew와 충돌할 때):
```bash
brew uninstall <tool>
brew install <tool>            # arm64 자동 설치
file $(which <tool>)           # 검증
```

**체크리스트 (Apple Silicon 환경 작업 시 무조건)**:
- [ ] 새 도구 설치 직후 `file $(which <tool>)` → arm64 확인
- [ ] 수동 설치 (`curl | sh`, github release binary) 시 architecture 명시
- [ ] 비표준 prefix (예: `~/.hermes/bin/`, `~/.local/bin/`) 도구는 brew 설치본과 별개로 추적
- [ ] `arch -x86_64`로 fallback이 필요한지 사전 판단

**같은 함정 다른 사례 (이전/유사)**:
- 2026-06-26 `oh-my-openagent` 설치 시: bunx가 어떤 arch로 받았는지 검증 안 됨 → 같은 패턴 주의
- 2026-07-02 `hermes update` 실패: `~/.hermes/bin/uv` x86_64 → 이번 케이스
- 일반화: "**수동 설치한 바이너리는 항상 architecture 1차 확인**"이 Apple Silicon의 첫 번째 규칙

**예방**:
- 수동 다운로드 binary 받을 때 GitHub release에서 `aarch64-apple-darwin` 또는 `arm64` 명시
- `which <tool>`이 brew prefix(`/opt/homebrew/bin`)와 다른 경로면 의심
- MIGRATION 시 다른 PC에서 옛 prefix가 섞여 들어올 수 있음 → 이 함수로 1차 검증
- 같은 이름의 도구가 시스템 내 여러 위치에 있을 수 있음 (`which -a <tool>`) → 모두 같은 arch인지 확인

**검증**: `file $(which <tool>)` × `uname -m` 결과 arch가 일치하면 OK. 어긋나면 위 해결 패턴 적용.

## 첫 부트스트랩 추천 패키지 목록 (2026-06-26 sigco3111 검증)

### 1순위 (반드시)
- `brew` (Homebrew 6.0+)
- `git` `gh` (GitHub CLI, 인증 + PR/이슈)
- `bun` (Bun 1.3+, tokscale 등 npm 도구)
- `node` (Node 20+ LTS, npx 자동 포함)
- `python@3.11` (Hermes 등 Python 도구)

### 2순위 (자주 씀)
- `cmux` (cask, 터미널 멀티플렉서)
- `visual-studio-code` (cask, 에디터)
- `iterm2` (cask, 터미널)
- `jq` `yq` (JSON/YAML 파서)
- `fzf` `ripgrep` `bat` `eza` (CLI 툴킷)
- `raycast` (cask, 런처)

### 3순위 (선택)
- `arc` (cask, 브라우저)
- `claude` / `codex` / `opencode` (AI 코딩 CLI)
- `docker` (cask, 컨테이너)

### 4순위 (AI 코딩 워크플로 — 2026-06-26 추가)
- `opencode` (formula) — `brew install opencode` 1.17.10 설치. ripgrep 15.1.0, pcre2 10.47 자동 의존성.
- `oh-my-openagent` (npm, **brew 아님!**) — `bunx oh-my-openagent install --no-tui --platform=opencode --<provider>=yes --skip-auth` (주인님 `minimax-coding-plan` 구독 시). OpenCode TUI 재시작 후 `ultrawork`/`ulw` 명령어 즉시 사용 가능. **자세한 설정은 `devops/opencode-nvidia-setup` 스킬 참조** (NVIDIA NIM 4개 키, oh-my-openagent.json 덮어쓰기 절차 포함).

## 검증 체크리스트 (부트스트랩 완료 후)

```bash
# 런타임
brew --version && bun --version && node --version && npx --version

# GitHub CLI 인증
gh auth status

# uv (Python 도구 격리 매니저)
export PATH="$HOME/.local/bin:$PATH" && which uv && uv --version

# uv 도구 (Phase 2.5에서 설치한 격리 도구)
uv tool list     # 설치된 격리 도구 목록

# Python (Hermes용)
ls ~/.hermes/hermes-agent/venv/bin/python3 && ~/.hermes/hermes-agent/venv/bin/python3 --version

# 사용자 .zshrc alias 동작
zsh -i -c 'alias | wc -l'  # 등록한 alias 개수만큼 떠야 함

# sudo 캐시 (재부팅 후 5분)
sudo -n true 2>&1
```

## 시그널 / 트리거

이 스킬은 다음 요청 시 자동 발동:
- "맥 새로 샀어", "M4 맥", "Apple Silicon", "macOS 새 환경"
- "부트스트랩", "환경 셋팅", "기본 도구 설치"
- "이주했어", "마이그레이션", "hjshin→mac 잔재" (인텔맥에서 이사)
- "Homebrew 설치", "brew 부터"
- "tk, tks alias" 같이 alias 일괄 등록 요청
- "오픈코드 설치", "OpenCode CLI" (`devops/opencode` 스킬과 협업)
- **"오마이오픈에이전트"** = `code-yeongyu/oh-my-openagent` (NOT brew `oh-my-agent`) — 사용자 코렉션 2026-06-26
- "oh-my-openagent 설정 파일 덮어써줘" → `~/.config/opencode/oh-my-openagent.json` 위치 + `opencode-nvidia-setup` 스킬 협업
- **"uv 설치해줘", "Python 도구 격리 설치", "uv tool install", "PEP 668 우회"** → Phase 2.5 발동 (2026-06-29 추가)
- uv로 격리 설치할 Python CLI 도구는 Phase 2.5 (`uv tool install <pkg>`) + 검증 단계까지 자동
- **"Python 3.10+ 필요해", "시스템 Python은 못 건드려"** → uv 도구 격리 설치 패턴 권장
- **"Errno 86", "Bad CPU type", "이 도구가 갑자기 안 돼", "OSError [Errno 86]"** → 함정 10번 (x86_64/arm64 mismatch) 진단/해결 패턴 (2026-07-02 추가)
- **`hermes update` 실패 (의존성 설치 단계에서 `OSError`)** → 함정 10번 우선 의심 — `~/.hermes/bin/uv` 아키텍처 점검
- **수동 설치한 도구 검증 요청** → `file $(which <tool>)` + `uname -m` 1차 확인 패턴

## 보조 파일

자세한 내용은 `references/` 참조:
- **`references/m4-verified-2026-06-26.md`** — 이번 세션 검증된 4개 앱 설치 실제 로그 + 함정 재현 단계
- **`references/alias-template.md`** — `<tool> aliases >>>` 블록 표준 템플릿 (재사용 가능)
- **`references/pty-vs-interactive.md`** — PTY 백그라운드 vs Terminal.app 직접 실행 비교표
- **`references/claude-code-minimax-routing-2026-06-26.md`** — Claude Code → MiniMax (Anthropic-호환) 라우팅 검증 (Hermes secrets 구조, 3가지 운영 모드 비교, 폴백 전략)
- **`references/zsh-dotfile-verification-2026-06-26.md`** — `.zshrc`에 fzf/direnv 추가 시 깨지는 두 함정 (도구 셸이 bash인 점 + brew fzf shell integration의 zsh 비호환) + `zsh -c` 명시 검증 패턴
- **`references/uv-tool-install-2026-06-29.md`** (Phase 2.5 신규, 2026-06-29 추가) — `uv` 설치 + `uv tool install <pkg>` 격리 Python 도구 워크플로. brew/uv 분담 결정 매트릭스, PATH 함정 2종 (`zshrc` 비대화형 미적용, `terminal()` 비대화형 셸), 격리 환경 검증 4종 oneliner.
- **`references/arm64-x86-binary-mismatch-2026-07-02.md`** (함정 10, 2026-07-02 신규) — Apple Silicon arm64 vs x86_64 바이너리 섞임 → `Errno 86 Bad CPU type`. 진단 4종 oneliner + 3가지 해결 옵션 (A: 정상 arm64 복사 / B: Rosetta 설치 / C: 도구 재설치) + 검증 체크리스트. `~/.hermes/bin/uv` 사례 + brew 수동 설치 / `curl | sh` / GitHub release binary 다운로드 시 공통 적용.
- **`scripts/arch-check.sh`** (함정 10 신규, 2026-07-02 추가) — 시스템 내 주요 도구 18종 (uv/bun/node/python/git/gh/brew/opencode/claude/codex 등) arch 일괄 점검 스크립트. MISMATCH 발견 시 arm64 교체 가이드 출력. `bash arch-check.sh [tool1 tool2 ...]` 형태. 새 PC 셋업 후 + MIGRATION 후 1차 검증에 활용. `chmod +x` 필요.

## 변경 이력

| 날짜 | 버전 | 내용 |
|---|---|---|
| 2026-06-26 | v1.0.0 | 초기 작성. M4 맥미니 부트스트랩 워크플로 확립. 4개 앱 설치 검증 (cmus/cmux/VS Code/opencode). 9개 함정 (T1/T2/T3 분류, brew install.sh PTY, sudo NOPASSWD, Apple Silicon PATH, zsh PATH 로딩, bash↔zsh 도구 환경, fzf zsh 비호환, conda 잔재, "oh-my-agent" 코렉션). |
| 2026-06-26 | v1.0.0 | 함정 7번 ("oh-my-agent" vs "oh-my-openagent" 사용자 코렉션), 함정 8번 (oh-my-openagent 비대화형 install + 2026-06-26 `--claude/--gemini/--copilot` 셋 다 필수 함정), 함정 9번 (Claude Code → MiniMax Anthropic-호환 라우팅). 4순위 AI 코딩 워크플로 섹션 추가. |
| 2026-06-29 | v1.0.1 | **Phase 2.5 (`uv` 격리 설치)** 신규 추가. macOS 시스템 Python 보호 + PEP 668 우회. brew/uv 분담 결정 매트릭스. PATH 함정 2종 (`zshrc` 비대화형 미적용, `terminal()` 비대화형 셸). `references/uv-tool-install-2026-06-29.md` 신규. |
| 2026-07-02 | v1.0.2 | **함정 10번 (arm64 vs x86_64 바이너리 섞임 → `Errno 86 Bad CPU type`)** 신규 추가. M4 시스템에서 `~/.hermes/bin/uv`가 x86_64로 섞인 실제 사례. 진단 4종 oneliner + 3가지 해결 옵션 (A: 정상 arm64 복사 / B: Rosetta / C: 재설치). `references/arm64-x86-binary-mismatch-2026-07-02.md` + `scripts/arch-check.sh` (시스템 일괄 점검 스크립트) 신규. Apple Silicon 첫 번째 규칙: "수동 설치 binary는 항상 architecture 1차 확인". 9개 → 10개 함정. |
