# zsh dotfile 검증 — macmini 환경 학습 로그 (2026-06-26)

> **언제 발동**: brew로 새 도구 설치 후 `.zshrc`에 key binding / shell integration 추가하고 검증할 때

## 세션 요약

macmini 환경(M4, `/Users/mac`, Homebrew 6.0.4)에서 mac-bootstrap 워크플로 후속 작업:

1. 사용자 요청: "M4맥에 대충 필요한건 다 설치한 것 같은데, 뭔가 빠진것이 없나 체크"
2. `brew install gh ffmpeg tmux fzf fd htop tree direnv wget` (10개 패키지)
3. `npm install -g playwright` (chromium 1228은 이미 캐시에 있었음)
4. `.zshrc`에 fzf key-bindings + direnv hook 추가
5. `source ~/.zshrc` → **실패**

## 함정 두 가지

### A. 도구 환경 셸 ≠ 사용자 셸

도구 환경에서 `terminal(command="source ~/.zshrc")` 실행 시:
- 도구 환경 셸은 `/opt/homebrew/bin/bash` (bash 5.x)
- `~/.zshrc`는 zsh 전용 문법 (`bindkey`, `typeset -f _direnv_hook` 등)
- bash가 zsh 명령 만나면 fail → 거짓 보고

재현:

```bash
# 도구 환경에서 (bash)
$ source ~/.zshrc
bindkey: 명령을 찾을 수 없음
(I)_direnv_hook: 표현식에서 산술 문법 오류

$ echo $0
bash  # 사용자 셸(zsh)과 다른 환경
```

**교훈**: 도구 환경의 `$0`을 먼저 확인할 것. 사용자에게 "적용 완료" 보고 전엔 zsh로 명시 검증.

### B. brew fzf shell integration이 zsh 비호환

`source <(fzf --zsh)` 또는 `/opt/homebrew/opt/fzf/shell/key-bindings.zsh` 직접 source 시:

```bash
$ source /opt/homebrew/opt/fzf/shell/key-bindings.zsh
/opt/homebrew/opt/fzf/shell/key-bindings.zsh: 줄 23: 예기치 않은 ')' 토큰 주변에서 문법 오류
/opt/homebrew/opt/fzf/shell/key-bindings.zsh: 줄 23: `  () {'
```

왜?
- 첫 줄 shebang 없음
- 23번 줄에 `() { ... }` bash 익명 함수 문법 — zsh는 명령으로 파싱하다 `)`에서 죽음

해결: `.zshrc`에 zsh-안전 패턴 직접 작성.

```bash
# fzf completion (homebrew site-functions는 zsh 호환)
if [ -f /opt/homebrew/share/zsh/site-functions/_fzf ]; then
  source /opt/homebrew/share/zsh/site-functions/_fzf 2>/dev/null
fi

# fzf key bindings — 수동 등록
if command -v fzf >/dev/null 2>&1; then
  bindkey '^T' fzf-file-widget
  bindkey '^R' fzf-history-widget
  bindkey '\ec' fzf-cd-widget
fi
```

## 검증 패턴 (zsh 명시)

```bash
# 1. dotfile 문법 검증 (source가 깨끗한지)
zsh -c 'source ~/.zshrc 2>&1; echo "EXIT=$?"'

# 2. 키바인딩 등록 확인
zsh -c 'bindkey | grep -E "\^R|\^T" | head -3'
# 기대: "^R" fzf-history-widget / "^T" fzf-file-widget

# 3. direnv hook 등록 확인
zsh -c 'typeset -f _direnv_hook >/dev/null && echo "direnv OK"'

# 4. alias 등록 확인 (Phase 3 일반)
zsh -i -c 'alias | grep "^alias tk"'
```

## 일반화

이번 세션에서 발견한 함정의 보편 원칙:

1. **도구가 실행하는 셸 ≠ 사용자가 쓰는 셸** — 매 세션 시작 시 `echo $0` 확인
2. **brew의 shell integration 파일은 bash 가정** — `bindkey`로 수동 등록이 안전
3. **dotfile 적용 보고 전엔 명시 셸로 검증** — `source` 만 돌리고 끝내지 말 것
4. **첫 줄 shebang 없으면 zsh 호환 아닐 확률 높음** — 의심하고 `head -1 <file>`로 확인

## 다른 도구로 일반화 가능한 패턴

- `fzf` 외에 `atuin`, `navi`, `delta` 같은 도구도 brew shell integration 파일이 같은 함정 가능
- zsh native module (`zsh-autosuggestions`, `zsh-syntax-highlighting`)은 brew가 별도 formula라 정상 작동
- "source하면 깨지는 brew 파일" 발견 시 → zsh-안전 패턴으로 직접 작성 후 스킬에 기록

## 관련

- `mac-bootstrap/SKILL.md` § 함정 #4a, #4b — 본 검증 로그를 요약한 본문
- `mac-bootstrap/SKILL.md` § Phase 3 검증 패턴 — `zsh -i -c 'alias | grep'`