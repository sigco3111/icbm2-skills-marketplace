# Alias 블록 표준 템플릿

`~/.zshrc` 끝에 append할 때 사용하는 표준 패턴. **헤더 마커**로 블록 단위 관리하면
중복 추가 방지 + 향후 일괄 제거 쉬움.

## 1. 기본 5-alias 블록 템플릿

```bash
# >>> <tool> aliases (added YYYY-MM-DD) >>>

# <한 줄 설명>
# 사용법: <가장 흔한 3-4개 alias>

alias <short>='<full command>'  # <설명>
alias <short>='<full command>'  # <설명>
alias <short>='<full command>'  # <설명>

# <<< <tool> aliases <<<
```

## 2. 실제 예시 — tokscale (검증됨, 2026-06-26)

```bash
# >>> tokscale aliases (added 2026-06-26) >>>

# AI 토큰 사용량 추적 + 글로벌 리더보드
# Bun 권장 (Bun 없을 시 tk-npx 사용)
# 사용법: tk (메인), tks (제출), tkw (연말 리캡), tkt (TUI)

alias tk='bunx tokscale@latest'  # Tokscale 메인 리포트 (TUI)
alias tks='bunx tokscale@latest submit'  # Tokscale 글로벌 리더보드 제출
alias tks-dry='bunx tokscale@latest submit --dry-run'  # Tokscale 제출 미리보기
alias tks-yes='(echo y | bunx tokscale@latest submit)'  # Tokscale 비대화형 제출 (cron용)
alias tkw='bunx tokscale@latest wrapped'  # Tokscale 연말 Wrapped (Spotify 스타일)
alias tkt='bunx tokscale@latest tui'  # Tokscale 인터랙티브 TUI
alias tkclients='bunx tokscale@latest clients'  # Tokscale 로컬 데이터 소스 확인
alias tkwho='bunx tokscale@latest whoami'  # Tokscale 현재 로그인 사용자
alias tk-npx='npx -y tokscale@latest'  # Tokscale via npx (Bun 미설치 PC용)

# <<< tokscale aliases <<<
```

## 3. Python 스크립트로 안전하게 추가

`write_file` / `patch` 대신 Python `str.replace()` 패턴으로 마커 블록 단위 관리:

```python
from pathlib import Path

zshrc = Path.home() / ".zshrc"
header_start = "# >>> <tool> aliases (added YYYY-MM-DD) >>>"
header_end = "# <<< <tool> aliases <<<"

existing = zshrc.read_text() if zshrc.exists() else ""

# 기존 마커 블록 있으면 제거 (idempotent update)
if header_start in existing and header_end in existing:
    start_idx = existing.index(header_start)
    end_idx = existing.index(header_end) + len(header_end)
    existing = existing[:start_idx] + existing[end_idx:].lstrip("\n")
    zshrc.write_text(existing)

# 새 블록 append
block = f"""{header_start}

# <설명>
alias <name>='<cmd>'  # <설명>

{header_end}
"""
with open(zshrc, "a") as f:
    f.write("\n" + block)
```

## 4. 검증 명령어 (3종)

```bash
# 1. alias 개수 확인
zsh -i -c 'alias | grep "^alias <prefix>" | wc -l'

# 2. 실제 alias 동작 확인
zsh -i -c '<alias_name> --version' 2>&1 | head -3

# 3. .zshrc 직접 grep
grep -A 20 '<tool> aliases' ~/.zshrc
```

## 5. 네이밍 규칙

| 종류 | 패턴 | 예시 |
|---|---|---|
| 메인 명령 | `tk`, `gh`, `dc` (2-3자 단축) | `tk` = tokscale 메인 |
| 변형 (동사) | `<prefix><verb>` | `tks` = tokscale submit, `tkw` = wrapped |
| 비대화형 변형 | `<prefix><verb>-yes` | `tks-yes` = stdin 자동 y |
| dry-run | `<prefix><verb>-dry` | `tks-dry` = submit --dry-run |
| 폴백 (다른 런타임) | `<prefix>-<runtime>` | `tk-npx` = npx 폴백 |

**규칙**: prefix는 2-3자, 변형 suffix는 1-2자, 하이픈 구분. 토큰 수 4-7자 유지.
