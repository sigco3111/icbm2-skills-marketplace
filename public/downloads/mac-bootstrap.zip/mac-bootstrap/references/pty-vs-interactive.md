# PTY 백그라운드 vs Terminal.app 직접 실행

> **핵심 요약**: 백그라운드 PTY는 비대화형과 동급. 진짜 TTY는 사용자 Terminal.app뿐.

## 비교표

| 항목 | `terminal()` 포그라운드 | `terminal(background=true, pty=true)` | 사용자 Terminal.app |
|---|---|---|---|
| **TTY 여부** | ❌ 비대화형 | ❌ 비대화형으로 분류 | ✅ 진짜 TTY |
| **sudo 비번 입력** | ❌ 못 물어봄, fail | ❌ 사용자에 안 보임, fail | ✅ 정상 |
| **OAuth 브라우저** | ❌ | ❌ | ✅ |
| **신뢰할 수 있는가** | 비대화형 OK 작업만 | 사용 안 함 | 모든 작업 |
| **사용 시기** | Phase 2 자동 설치 | (실패 패턴이라 안 씀) | Phase 1, 4 |

## 백그라운드 PTY가 fail한 실제 사례 (2026-06-26)

```python
# ❌ 안 되는 패턴
terminal(
    command="sudo -v && /bin/bash -c \"$(curl ...)\"",
    background=True,
    pty=True
)
```

**출력** (백그라운드에서 4분 후 SIGTERM):
```
Password:
sudo: a password is required
```

**이유**:
- 백그라운드 PTY는 시스템 콜 레벨에서 `isatty()` = false
- brew install.sh의 `have_sudo_access()` 함수가 `isatty(STDIN)` 체크 → 비대화형으로 판단
- 비번 묻는 프롬프트는 stdout에 출력되지만 사용자 화면에는 안 뜨고 스크립트는 abort

**해결**: 사용자가 **별도 Terminal.app**에서 직접 실행. 그 터미널은 사용자의
`bash`/`zsh` 세션이라 진짜 TTY로 인식됨.

## "비번 없이 sudo root 떨어지는" 함정 (NOPASSWD 효과)

`sudo whoami` 가 비번 묻지 않고 root 떴는데 brew는 fail한 이유:

```bash
$ sudo -n whoami
root  # NOPASSWD 설정 또는 Touch ID 자동 인증

$ sudo -n true
echo $?  # 0 (캐시 OK)

# BUT
$ NONINTERACTIVE=1 /bin/bash -c "$(curl ...brew...)"
Need sudo access on macOS!  # abort
```

**분석**:
- `sudo -n` = non-interactive, 캐시만 확인 → 통과
- `brew install.sh` = TTY 체크 후 `sudo -v` 호출 → TTY 없어 fail
- Touch ID 인증은 GUI 세션(Terminal.app)에서만 작동

**결론**: sudo 캐시 상태와 brew 설치 가능성은 **별개**. Phase 1은 항상 사용자 Terminal.app 위임.

## 어떤 작업을 어디서 할까?

| 작업 | 어디서 | 비고 |
|---|---|---|
| `brew install <formula>` | **자동** (`terminal()` 포그라운드) | 비대화형 OK |
| `brew install --cask` | **자동** | 비대화형 OK |
| `brew install.sh` (초기 설치) | **사용자 Terminal.app** | TTY 필요 |
| `sudo -v` (캐시 갱신) | **사용자 Terminal.app** | 비번/Touch ID 입력 |
| OAuth login (`tokscale login`, `gh auth login`) | **사용자 Terminal.app** | 브라우저 열림 |
| Apple ID 인증 | **사용자 GUI** | "시스템 설정" 앱 |
| ssh 키 생성 (`ssh-keygen`) | **사용자 Terminal.app** | passphrase 입력 |
| git config user.name/email | **자동 또는 사용자** | 비대화형 OK지만 본인 정보 |

## 자동화 스크립트 작성 시 체크리스트

```bash
# ❌ 위험: 비대화형 가정
curl -fsSL https://example.com/install.sh | bash
# 스크립트 내부에서 sudo 또는 read 호출 시 fail

# ✅ 안전: 사용자 안내 + 비대화형 부분 분리
echo "1. Terminal.app 열고 다음 실행:"
echo "   curl -fsSL https://example.com/install.sh | bash"
echo ""
echo "2. 끝나면 '완료' 라고 알려주세요"
# 그 다음은 자동 작업
brew install --formula1
brew install --formula2
```

## 디버깅 팁

brew가 자꾸 fail하면:
```bash
# 1. TTY 환경 확인 (Terminal.app)
tty  # /dev/ttys000 같은 진짜 TTY 나오면 OK

# 2. sudo 캐시 확인
sudo -n true && echo CACHED || echo NEED_PASSWORD

# 3. brew 진단
brew doctor
```

## 참고 링크

- Homebrew install.sh 소스: https://github.com/Homebrew/install/blob/master/install.sh
- 핵심 함수: `have_sudo_access` (line 235), `execute_sudo` (line 295)
