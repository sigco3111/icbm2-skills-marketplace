# Unity Hub/Editor 설치 및 완전 제거 (macOS, 2026-07-20 검증)

Unity 자체를 셋업하거나 깨끗하게 들어낼 때 쓰는 정석 recipe. brew cask가 정답, 직접 CDN URL은 작동 안 함.

## 설치

### 1. Unity Hub (CLI로)
```bash
brew install --cask unity-hub
# → /Applications/Unity Hub.app (3.19.5, 2026-07-20 시점)
```

**❌ 실패 패턴 — 절대 하지 말 것**:
```bash
curl -L -o UnityHub.dmg "https://public-cdn.cloud.unity3d.com/hub/prod/UnityHubSetup.dmg"
# → 404 NoSuchKey, HTML 페이지 361 bytes만 받아짐
```
Unity가 CDN 경로를 바꿔서 직접 .dmg URL은 작동 안 함. unity.com/download 페이지는 JS 렌더링이라 curl로 URL 추출도 안 됨.

### 2. Unity Editor (Hub GUI 안에서만)
- Unity Hub CLI 옵션 없음 (`--help` 빈 출력)
- Hub 켜고 → 왼쪽 **Installs** → 우측 상단 **Install Editor**
- 버전 선택: 2022.3 LTS 또는 Unity 6 LTS (에셋 요구사항에 따라)
- 모듈: Visual Studio Community + Mac Build Support (IL2CPP) 체크
- 다운로드 ~3GB, 5분

### 3. 로그인
- Hub 우측 상단 사람 아이콘 → Sign in
- **구매한 에셋 계정과 동일**해야 Package Manager → My Assets에 보임

## 사용 — Asset Store 에셋 받기

1. Hub → Unity에서 열기 → 빈 프로젝트 생성 (Templates → Core → 3D/2D)
2. Unity Editor → **Window → Package Manager**
3. 좌상단 드롭다운 → **My Assets** 변경
4. 에셋 클릭 → 우측 **Download** → **Import** → 팝업 전체 체크 Import
5. (선택) `.unitypackage`로 Export해서 다른 프로젝트 재사용: Project 창에서 우클릭 → Export Package

## 완전 제거 (총 ~22GB 회수)

순서 중요: Editor → Hub → 캐시 → 잔재.

### 단계 1 — Unity Editor (가장 큼, ~17GB)
```bash
rm -rf "/Applications/Unity"
```

### 단계 2 — Unity Hub (~530MB)
```bash
rm -rf "/Applications/Unity Hub.app"
```

### 단계 3 — Brew Cask 정리
```bash
brew uninstall --cask unity-hub
```

### 단계 4 — 잔재 13개 위치 (한 번에)
```bash
rm -rf ~/Library/Application\ Support/Unity
rm -rf ~/Library/Application\ Support/"Unity Technologies"
rm -rf ~/Library/Application\ Support/UnityHub
rm -rf ~/Library/Application\ Support/DefaultCompany  # "My project" Unity 로그
rm -rf ~/Library/Unity                              # ~4.2GB
rm -rf ~/Library/Caches/com.unity3d.UnityEditor
rm -rf ~/Library/Caches/Unity
rm -rf ~/Library/Caches/Homebrew/Cask/unity-hub--*.dmg
rm -rf ~/Library/Logs/Unity
rm -f  ~/Library/Preferences/com.unity3d.UnityEditor*.plist
rm -f  ~/Library/Preferences/com.unity3d.unityhub.plist
rm -f  ~/Library/Preferences/Unity
rm -f  ~/Library/Preferences/unity*.plist  # DefaultCompany, hub 등
rm -rf ~/Unity\ user\ templates
rm -rf ~/.unity
rm -f  ~/Downloads/UnityHub*.dmg
```

### 잔재 검증
```bash
find /Users/mac -maxdepth 5 -iname "*unity*" \
  -not -path "*/game-assets*" \
  -not -path "*/game-assets-pool*" \
  -not -path "*/node_modules/*" \
  -not -path "*/.hermes/*" \
  -not -path "*/ObsidianVault/*" \
  2>/dev/null | grep -v "Permission denied"
# → 출력 없으면 깨끗
```

## Pitfalls

- **순서 거꾸로 하지 말 것**: Hub 먼저 지우면 Editor 안 지워짐 (의존성 검사할 일 없지만 깔끔)
- **5GB+ 삭제 작업은 사용자 확인 필수**: A/B/C/D 옵션으로 분기 제시. 17GB는 절대 한 줄로 그냥 지우지 말 것
- **Brew 캐시는 uninstall만으로 안 비워짐**: 수동으로 `~/Library/Caches/Homebrew/...` 정리 필요
- **unity...plist** (이름 일부만 보이는 손상된 plist)도 Preferences에 있을 수 있음 — `unity*.plist` 글로브로 잡힘
- **권한 에러**: 일부 시스템 경로는 sudo 필요할 수 있으나 위 경로들은 user 영역이라 sudo 불필요

## 호환성 참고

| 에셋 요구 버전 | Editor 권장 |
|---------------|------------|
| "Gaia for Unity 6" 등 Unity 6 전용 | Unity 6000.x LTS |
| 일반 Asset Store 에셋 | 2022.3 LTS (가장 호환성 높음) |
| 옛날 에셋 (2018~2020) | 2022.3 LTS (URP 버전 호환 확인) |

## 검증된 환경 (2026-07-20)
- macOS 26.5.2, M4 Mac mini 16GB
- Unity Hub 3.19.5 (brew cask)
- Unity 6000.5.4f1 (Unity 6.5)
- Gaia for Unity 6 + URP 17.5 정상 동작 확인

## 다음에 비슷한 작업할 때
- Unity 재설치: §설치 그대로 따라가면 됨
- 다른 dev tool (Docker, VSCode 등): brew cask 가능 여부 먼저 체크 (직접 dmg 다운로드보다 안전)