# Claude Code → MiniMax 라우팅 검증 (2026-06-26)

> M4 맥 부트스트랩 마지막 단계. brew `claude-code` (Anthropic 공식 CLI 2.1.181) 설치 후, 주인님의 주력 모델 MiniMax-M3 (minimax-coding-plan 구독)으로 라우팅 설정한 실제 워크플로.

## 1. 사전 진단 — Hermes secrets 구조 활용

주인님 환경에서 API 키는 **Hermes `secrets/` 디렉토리에서 SSOT 관리**:

```bash
$ ls -la ~/.hermes/secrets/ | grep minimax
-rw-r--r--   1 mac  staff   148 Jun 26 13:10 minimax.env
```

`minimax.env` 내용 (마스킹):
```bash
export MINIMAX_API_KEY=...
```

`~/.hermes/config.yaml` 관련 정의:
```yaml
model:
  default: MiniMax-M3
  base_url: https://api.minimax.io/anthropic
providers:
  minimax:
    api_key_env: MINIMAX_API_KEY
```

**핵심**: `base_url: https://api.minimax.io/anthropic` — **Anthropic 호환 엔드포인트**라 Claude Code가 그대로 호출 가능.

## 2. `.zshrc` 환경변수 등록

```bash
# >>> claude code (MiniMax) env >>>
# Claude Code를 MiniMax API로 라우팅 (Anthropic 호환 엔드포인트)
export ANTHROPIC_BASE_URL="https://api.minimax.io/anthropic"
export ANTHROPIC_AUTH_TOKEN="<loaded from MINIMAX_API_KEY>"
export ANTHROPIC_MODEL="MiniMax-M3"
# API 키 로드 (Hermes secrets)
[ -f ~/.hermes/secrets/minimax.env ] && source ~/.hermes/secrets/minimax.env
# <<< claude code (MiniMax) env <<<
```

**패턴 분석**:
- `ANTHROPIC_BASE_URL` — Claude Code의 기본 엔드포인트 오버라이드
- `ANTHROPIC_AUTH_TOKEN` — `MINIMAX_API_KEY` 값으로 자동 채워짐 (`source` 시점)
- `ANTHROPIC_MODEL` — `claude` 명령 기본 모델 (선택사항)
- 마커 헤더 (`>>> ... >>>`) — 중복 추가 방지 + `skill_manage`로 패치 용이

## 3. 검증

```bash
$ which claude
/opt/homebrew/bin/claude

$ claude --version
2.1.181 (Claude Code)

$ source ~/.zshrc && echo $ANTHROPIC_BASE_URL
https://api.minimax.io/anthropic
```

## 4. 함정 / 학습

| 함정 | 학습 |
|---|---|
| Claude Code는 기본 `api.anthropic.com` 호출 | MiniMax는 `/anthropic` 호환 엔드포인트 제공 → 3개 환경변수만 바꾸면 됨 |
| Hermes `secrets/*.env` 자동 source 패턴 | AI CLI 라우팅 시 `.zshrc`에 `[ -f ... ] && source ...` 한 줄로 SSOT 연결 |
| `base_url`이 Hermes config의 모델 정의와 일치 | Claude Code 호출과 oh-my-openagent 모델 매핑이 같은 모델명(MiniMax-M3) 사용 → 도구 간 일관성 |

## 5. 3가지 운영 모드 비교

| 모드 | API 키 | base_url | 비고 |
|---|---|---|---|
| A. Native Anthropic | Anthropic 직접 구매 | `api.anthropic.com` (default) | 비쌈 ($20/월+) |
| **B. MiniMax 라우팅 (주인님 권장)** | **minimax.io 구독** | **`api.minimax.io/anthropic`** | **저렴, 주인님 표준** |
| C. OpenRouter 라우팅 | OpenRouter 키 | `openrouter.ai/api/v1` | 모델 다양 |

## 6. 폴백 전략 (미구현)

현재는 Claude Code → MiniMax 단일 경로. MiniMax 쿼타 소진 시 폴백 없음. 향후 추가 가능:

```bash
# Claude Code의 --fallback-model 옵션으로 NIM 등 추가
claude --model MiniMax-M3 --fallback-model openai/gpt-oss-120b
```

단, `--fallback-model`은 **세션 시작 시**만 적용 가능 (런타임 자동 폴백 X). 자동 폴백은 OpenRouter 등 미들웨어 필요.

## 7. mac-bootstrap 4순위 패키지 추가

```bash
brew install claude-code   # Cask 2.1.181 (의존성 없음, Node 글로벌)
```

주인님의 AI 코딩 CLI 풀세트:
- **oh-my-openagent** (OpenCode 플러그인) — `minimax-coding-plan/MiniMax-M3` 11 에이전트
- **OpenCode CLI** — `opencode` 1.17.10
- **Claude Code** — `claude` 2.1.181 (이번 라우팅 설정)
- **tokscale** — `tk` / `tks` (사용량 추적 + 리더보드)

## 8. 관련 스킬

- `devops/mac-bootstrap` — 새 Mac 부트스트랩 전체 워크플로
- `devops/opencode-nvidia-setup` — Claude Code 라우팅 패턴 + oh-my-openagent 설정 + NIM 폴백
- `automation/tokscale` — 사용량 추적 + 두 PC 통합
