# arm64 vs x86_64 바이너리 섞임 함정 (2026-07-02 검증)

## 시나리오

M4 (Apple Silicon, arm64) 시스템에서 수동 설치 경로의 바이너리가 x86_64로 섞여 들어간 상태로, 시스템 Python venv / 다른 도구가 그 바이너리를 호출할 때 `OSError: [Errno 86] Bad CPU type in executable` 발생.

## 실제 세션 재현 단계 (2026-07-02)

### 1단계: `hermes update` 실패

```bash
$ hermes update
⚕ Updating Hermes Agent...
→ Fetching updates...
→ Local changes detected — stashing before update...
→ Pulling updates...
→ Restoring local changes...
✓ Already up to date!
```

→ 업데이트는 성공한 것처럼 보이지만, 이어서:
```
→ Updating Python dependencies...
Traceback (most recent call last):
  File "/Users/mac/.hermes/hermes-agent/venv/bin/hermes", line 10, in <module>
    sys.exit(main())
  ...
  File "/Users/mac/.hermes/hermes-agent/hermes_cli/managed_uv.py", line 170, in update_managed_uv
    result = subprocess.run(...)
  ...
  File "/Users/mac/.local/share/uv/python/cpython-3.11.15-macos-aarch64-none/lib/python3.11/subprocess.py", line 1955, in _execute_child
    raise child_exception_type(errno_num, err_msg, err_filename)
OSError: [Errno 86] Bad CPU type in executable: '/Users/mac/.hermes/bin/uv'
```

핵심 에러: `Bad CPU type in executable: '/Users/mac/.hermes/bin/uv'`

### 2단계: 진단 (4종 oneliner)

```bash
# 1) 시스템 아키텍처
$ uname -m
arm64

$ sysctl -n machdep.cpu.brand_string
Apple M4

# 2) 문제 바이너리 아키텍처
$ file /Users/mac/.hermes/bin/uv
/Users/mac/.hermes/bin/uv: Mach-O 64-bit executable x86_64

$ lipo -archs /Users/mac/.hermes/bin/uv
x86_64

# 3) 코드 사이닝 (참고)
$ codesign -dv --verbose=4 /Users/mac/.hermes/bin/uv
/Users/mac/.hermes/bin/uv: code object is not signed at all

# 4) Rosetta fallback 테스트
$ arch -x86_64 /Users/mac/.hermes/bin/uv --version
arch: posix_spawnp: /Users/mac/.hermes/bin/uv: Bad CPU type in executable
```

**진단 결과**: 시스템은 arm64, 바이너리는 x86_64, Rosetta fallback도 안 됨 → 정상 arm64 바이너리로 교체 필요.

### 3단계: 정상 arm64 바이너리 발견

```bash
$ which -a uv
/Users/mac/.local/bin/uv

$ file /Users/mac/.local/bin/uv
/Users/mac/.local/bin/uv: Mach-O 64-bit executable arm64

$ /Users/mac/.local/bin/uv --version
uv 0.11.25 (1fc7de7c4 2026-06-26 aarch64-apple-darwin)
```

`uv-tool-install-2026-06-29.md` 패턴으로 설치한 정상 arm64 빌드가 시스템 어딘가에 있음 → 이걸로 복사.

### 4단계: 해결 (A안, 추천)

```bash
# 정상본 → 깨진 위치로 복사
$ cp -f /Users/mac/.local/bin/uv /Users/mac/.hermes/bin/uv
$ chmod +x /Users/mac/.hermes/bin/uv

# 검증
$ file /Users/mac/.hermes/bin/uv
/Users/mac/.hermes/bin/uv: Mach-O 64-bit executable arm64

$ /Users/mac/.hermes/bin/uv --version
uv 0.11.25 (1fc7de7c4 2026-06-26 aarch64-apple-darwin)
```

### 5단계: hermes update 재실행

```bash
$ hermes update
⚕ Updating Hermes Agent...
→ Fetching updates...
→ Local changes detected — stashing before update...
→ Restoring local changes...
✓ Already up to date!
```

이번엔 dependency install 단계가 자동 재개되어 깨끗하게 완료.

### 6단계: 최종 검증

```bash
$ hermes --version
Hermes Agent v0.18.0 (2026.7.1) · upstream b3bc3023
Project: /Users/mac/.hermes/hermes-agent
Python: 3.11.15
Up to date
```

→ `Up to date`로 모든 단계 정상 완료 확인.

## 진단 oneliner 4종 (복붙용)

```bash
# 1) 시스템 arch
uname -m

# 2) 의심 바이너리 arch
file $(which <tool>)

# 3) 다중 arch (fat binary 여부)
lipo -archs $(which <tool>)

# 4) Rosetta fallback 가능 여부
arch -x86_64 $(which <tool>) --version
```

## 해결 옵션 3가지 (사용자 선택 패턴)

| 옵션 | 명령 | 시간 | 트레이드오프 |
|---|---|---|---|
| **A (추천)** | `cp -f /정상/arm64/위치/uv /깨진/위치/uv && chmod +x /깨진/위치/uv` | 30초 | 가장 빠름, 데이터 무손실 |
| B | `softwareupdate --install-rosetta --agree-to-license` 후 x86_64 살리기 | 5~10분 | 시스템 변경 큼, 검증 시간 김 |
| C | `brew uninstall <tool> && brew install <tool>` (또는 `curl \| sh` 재설치) | 1~3분 | 환경에 따라 다른 prefix로 또 섞일 위험 |

## 핵심 교훈 3가지

1. **수동 설치 binary는 항상 architecture 1차 확인** — Apple Silicon의 첫 번째 규칙
2. **여러 prefix의 같은 이름 도구 추적** — `which -a <tool>`로 시스템 내 모든 위치 확인
3. **해결 시 가장 빠른 길 = 정상본이 어딘가에 있는지 확인** → 복사. 재설치는 최후의 수단.

## 재발 방지 체크리스트

- [ ] 새 도구 설치 직후 `file $(which <tool>)` → arm64 확인
- [ ] `curl | sh` 로 받은 바이너리는 GitHub release에서 `aarch64-apple-darwin` 또는 `arm64` 명시
- [ ] `which -a <tool>` 로 시스템 내 모든 위치 + arch 추적
- [ ] MIGRATION 시 다른 PC에서 옛 prefix가 섞여 들어올 수 있음 → 이 함정으로 1차 검증
- [ ] M4 환경 작업 시 `arch -x86_64` fallback 사전 판단

## 같은 함정 다른 사례 (관련 학습)

| 날짜 | 도구 | 원인 | 해결 |
|---|---|---|---|
| 2026-06-26 | `oh-my-openagent` bunx | 수동 설치 arch 미검증 | bunx 환경변수로 명시 arch 요청 |
| 2026-07-02 | `~/.hermes/bin/uv` (이 케이스) | 옛 설치본 / 다른 PC 이전 잔재 가능 | `~/.local/bin/uv` (정상 arm64) 복사 |
| 일반 | `curl \| sh` GitHub release | amd64 vs arm64 혼동 | release notes에 명시 arch 다운로드 |

## 검증 도구: `arch-check.sh` (선택)

다음 세션 시작 시 한 번 실행하면 시스템 내 모든 도구 arch를 한 번에 확인:

```bash
#!/usr/bin/env bash
# arch-check.sh — 시스템 내 모든 도구 arch 일괄 점검
SYS=$(uname -m)
echo "=== System: $SYS ==="
echo
printf "%-30s %-10s %s\n" "TOOL" "ARCH" "PATH"
printf "%-30s %-10s %s\n" "----" "----" "----"

for cmd in uv bun node npx python3 git gh brew opencode; do
  path=$(command -v $cmd 2>/dev/null)
  if [ -n "$path" ]; then
    arch=$(file -b "$path" | grep -oE '(x86_64|arm64|i386)' | head -1)
    status="OK"
    if [ "$arch" != "$SYS" ] && [ "$arch" != "arm64" ] && [ "$SYS" = "arm64" ]; then
      status="MISMATCH!"
    fi
    printf "%-30s %-10s %s [%s]\n" "$cmd" "$arch" "$path" "$status"
  else
    printf "%-30s %-10s %s\n" "$cmd" "-" "not found"
  fi
done
```

→ Apple Silicon 시스템에서 x86_64로 잡히는 도구가 있으면 MISMATCH 경고.
