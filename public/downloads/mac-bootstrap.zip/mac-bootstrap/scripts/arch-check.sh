#!/usr/bin/env bash
# arch-check.sh — 시스템 내 주요 도구 arch 일괄 점검
#
# Apple Silicon (M1/M2/M3/M4) 시스템에서 x86_64 바이너리가 섞여 들어갔는지
# 한 번에 확인. 발견 시 MISMATCH 경고.
#
# Usage:
#   bash arch-check.sh              # 시스템 내 모든 도구 점검
#   bash arch-check.sh uv bun node  # 특정 도구만 점검
#
# Exit codes:
#   0 = all MATCH (arm64)
#   1 = any MISMATCH detected
#   2 = unsupported architecture (Intel Mac)

set -e

SYS=$(uname -m)
echo "=========================================="
echo "  Architecture Mismatch Checker"
echo "=========================================="
echo "System: $SYS"
echo "Date:   $(date '+%Y-%m-%d %H:%M:%S')"
echo

if [ "$SYS" = "x86_64" ]; then
  echo "ℹ️  Intel Mac detected — no mismatch possible (all x86_64)"
  exit 2
fi

if [ "$SYS" != "arm64" ]; then
  echo "⚠️  Unknown system arch: $SYS"
  exit 2
fi

# 점검할 도구 목록 (인자 있으면 그걸로, 없으면 기본 세트)
DEFAULT_TOOLS="uv bun node npx python3 python3.11 python3.12 git gh brew opencode claude codex cmus jq rg fzf bat eza"

if [ $# -gt 0 ]; then
  TOOLS="$@"
else
  TOOLS="$DEFAULT_TOOLS"
fi

printf "%-20s %-10s %-50s %s\n" "TOOL" "ARCH" "PATH" "STATUS"
printf "%-20s %-10s %-50s %s\n" "----" "----" "----" "------"

MISMATCH=0
NOT_FOUND=0

for cmd in $TOOLS; do
  # which -a: 시스템 내 모든 위치 확인
  paths=$(command -v $cmd 2>/dev/null || true)

  if [ -z "$paths" ]; then
    printf "%-20s %-10s %-50s %s\n" "$cmd" "-" "(not found)" "SKIP"
    NOT_FOUND=$((NOT_FOUND + 1))
    continue
  fi

  # which -a 출력은 줄바꿈으로 구분. 첫 번째 매치만 검사 (보통 PATH 우선순위).
  # 여러 경로가 있으면 모두 표시.
  for path in $paths; do
    [ -f "$path" ] || continue
    arch=$(file -b "$path" 2>/dev/null | grep -oE '(x86_64|arm64|i386|fat)' | head -1)
    arch=${arch:-unknown}

    if [ "$arch" = "arm64" ] || [ "$arch" = "fat" ]; then
      status="OK"
    else
      status="⚠️  MISMATCH"
      MISMATCH=$((MISMATCH + 1))
    fi

    printf "%-20s %-10s %-50s %s\n" "$cmd" "$arch" "$path" "$status"
  done
done

echo
echo "=========================================="
echo "Summary:"
echo "  System:        $SYS"
echo "  Tools checked: $(echo $TOOLS | wc -w | tr -d ' ')"
echo "  Mismatch:      $MISMATCH"
echo "  Not found:     $NOT_FOUND"
echo "=========================================="

if [ $MISMATCH -gt 0 ]; then
  echo
  echo "🔴 Action needed: MISMATCH 도구는 arm64 바이너리로 교체 필요"
  echo "   진단/해결 패턴: mac-bootstrap skill → 함정 10번 (arm64-x86-binary-mismatch)"
  echo "   reference: references/arm64-x86-binary-mismatch-2026-07-02.md"
  exit 1
fi

echo
echo "✅ All tools match system architecture"
exit 0
