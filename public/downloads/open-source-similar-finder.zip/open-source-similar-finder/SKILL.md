---
name: open-source-similar-finder
description: Use when the user references a specific open-source project and asks for similar/alternative projects — "find me an OSS game like SNKRX", "what's a good alternative to X", "X랑 비슷한 오픈소스 추천해줘". Captures the GitHub API + awesome-* + same-author methodology with verification gates (stars/license/recency) and a concise table output.
---

# Open Source Similar Project Finder

## When to use

User references a specific open-source project (game, library, tool, framework) and asks for similar or alternative projects. Triggers:

- "find me an OSS like X"
- "X랑 비슷한 오픈소스 추천해줘"
- "what's a good alternative to Y"
- "비슷한 거 없나?"
- "X처럼 생긴 다른 거 있어?"

If the user just drops a single GitHub URL and asks "이거 뭔가?" / "사용할만 할까?" → use `github-repo-triage` instead. This skill is for **discovering alternatives**, not evaluating a given project.

## Core methodology

### Step 1: Extract the reference's distinguishing characteristics

Before searching, identify what makes the reference unique. Without this you'll drown in unrelated results:

- **Domain** (game / dev tool / library / CLI / web app)
- **Stack** (language + framework + render/engine type)
- **Visual/interaction style** (minimalist, pixel, terminal, 3D, web)
- **Core mechanics** (auto-battle, build theorycraft, roguelike, turn-based, real-time)
- **Distribution** (CLI, GUI, web, desktop, mobile, library)
- **Health signals** (Steam release, active CI, recent commits, active issues)

For SNKRX example: auto-battle roguelike + Lua+LÖVE + pixel minimal + build theorycraft + Steam-released + 1979⭐ + active.

### Step 2: Search GitHub API with progressively broader queries

GitHub API search is restrictive — many valid queries return 0 results. Try multiple strategies before giving up:

1. **Same-author exploration**: `/users/{author}/repos?per_page=100&sort=stars`
   - Often the same author has 2-5 similar projects. Example: a327ex made both SNKRX and BYTEPATH.
2. **Topic search**: `/search/repositories?q=topic:{topic}+stars:>N`
3. **Language + keyword**: `q={lang}+{mechanic}+stars:>N`
4. **Description search**: `q={characteristic}+in:description,readme`

**Pitfall**: Many valid queries return 0 results due to API strictness. Don't burn 10 queries on the same approach — move to fallback after 2-3 empty results.

### Step 3: Fallback to awesome-* curated lists

When GitHub API search returns nothing, pivot to community-curated lists:

- `awesome-{language}` (awesome-love2d, awesome-godot, awesome-rust)
- `awesome-open-source-games` (michelpereira/awesome-open-source-games)
- `awesome-{domain}` (awesome-game-engine-dev, awesome-self-hosted)

Fetch and parse:
```bash
curl -sL "https://raw.githubusercontent.com/{owner}/{repo}/master/README.md" > /tmp/awesome.md
grep -n "^## " /tmp/awesome.md
# then grep github.com references in the relevant section
```

### Step 4: Verify each candidate

Before recommending, hit `/repos/{owner}/{name}` and check:

| Field | What to look for |
|-------|------------------|
| `stargazers_count` | Popularity signal |
| `forks_count` | Community engagement |
| `license.spdx_id` | MIT/GPL/Apache = safe; NOASSERTION = read LICENSE file manually |
| `pushed_at` | Recency — prefer <2 years |
| `language` | Stack match |
| `topics` | Domain tags |
| `description` | Use case fit |

Skip if archived, no license info, or >3 years no push (unless user explicitly wants legacy).

### Step 5: Rank by alignment

Prioritize:

1. **Same author** — strongest signal (same dev = similar aesthetic)
2. **Same stack** — same language/framework
3. **Same domain** — same type of project
4. **Similar mechanics** — same gameplay/library pattern

## Output format

Concise table, 4-5 columns max. Match the user's preferred language.

```markdown
| # | 이름 | ⭐ | 엔진 | 라이선스 | 매칭 포인트 |
|---|------|----|------|----------|-------------|
| 1 | a327ex/BYTEPATH | 1,535 | Lua+LÖVE | MIT | 같은 개발자 — 가장 강력 추천 |
```

Then 1-2 lines per top-3 candidate explaining the match. End with a clarifying follow-up (A→B→C→D 옵션) if user might want to fork/build one — matches user's preferred multi-step delegation pattern.

## Pitfalls

- **GitHub API search returns 0 often**: Always have a fallback ready. Don't burn time retrying the same approach.
- **License field can be null**: Handle NoneType in Python parsing. `r.get('license') or {}` then `.get('spdx_id', 'N/A')`.
- **Don't recommend huge projects as "alternatives"**: A 28k⭐ Mindustry doesn't feel like an alternative to a 2k⭐ SNKRX. Surface mid-size candidates first unless user wants popular.
- **AGPL has commercial-use restrictions**: Flag it explicitly in the 매칭 포인트 column.
- **Match user's output language**: Korean user → Korean; English user → English.
- **Avoid abandoned repos**: >2 years no push + open issues = dead project.
- **Don't fabricate descriptions**: If GitHub API description is null/None, fetch from README. Never invent.
- **Don't drown the user**: 5 candidates is plenty. 10+ is too many. Rank, don't list.

## Verification commands

```bash
# Same-author exploration
curl -s "https://api.github.com/users/{author}/repos?per_page=100&sort=stars" | \
  python3 -c "import json,sys
for r in json.load(sys.stdin):
    if not r.get('archived'):
        print(f\"{(r.get('stargazers_count') or 0):>5}⭐  {r['name']:<35} {(r.get('description') or '')[:60]}\")"

# Verify single repo (handle None fields)
curl -s "https://api.github.com/repos/{owner}/{name}" | \
  python3 -c "import json,sys
r = json.load(sys.stdin)
lic = r.get('license') or {}
print(f\"⭐ {r.get('stargazers_count',0)} | 🍴 {r.get('forks_count',0)} | 📜 {lic.get('spdx_id','N/A')} | 📅 {(r.get('pushed_at') or 'N/A')[:10]}\")"

# Search with topic + language + stars
curl -s "https://api.github.com/search/repositories?q=topic:{topic}+language:{lang}+stars:>N&sort=stars" | \
  python3 -c "import json,sys
for r in (json.load(sys.stdin).get('items') or []):
    print(f\"{(r.get('stargazers_count') or 0):>5}⭐  {r['full_name']:<40} {(r.get('description') or '')[:55]}\")"

# Fetch awesome-* README
curl -sL "https://raw.githubusercontent.com/{owner}/{repo}/master/README.md" > /tmp/awesome.md
grep -n "^## " /tmp/awesome.md
```

## Related skills

- `github-repo-triage` — for evaluating a single given URL ("이거 뭔가?")
- `github-trending-monitor` — for monitoring trending repos over time (cron)
- `github-portfolio-planner` — for sigco3111's own repo portfolio navigation