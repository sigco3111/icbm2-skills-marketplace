---
name: learning-gap-tracker
description: ICBM2가 대화 중 '모르는 것'을 자동 감지하고 학습 큐에 등록 — 반복 질문 패턴 분석, 자동 조사 큐 관리
tags: [self-improvement, learning, memory]
---

# Learning Gap Tracker

ICBM2가 대화 중 알지 못하는 것을 감지하고 학습 큐에 등록하는 시스템입니다.

## 💡 언제 사용하는가

- 주인님이 질문했는데 **정확한 답변을 주지 못한 경우**
- 주인님이 "이것 좀 조사해봐"라고 한 뒤 **결과물의 질이 낮았던 경우**
- 같은 주제가 **2회 이상 반복** 등장한 경우
- 크론 잡이나 스크립트에서 **에러 해결에 실패**한 경우

## 📋 동작 원리

### 1. 감지 (Detect)
대화 중 다음 패턴이 감지되면 자동으로 학습 갭으로 기록:
- "모르겠습니다", "확실하지 않습니다", "조사가 필요합니다" 등 불확실성 표현
- 주인님이 교정/추가 정보를 제공한 경우
- 같은 질문이 반복된 경우 (encounter_count 증가)

### 2. 기록 (Record)
```bash
python3 ~/.hermes/scripts/learning_gap_tracker.py add \
  --topic "주제" \
  --context "맥락" \
  --severity medium \
  --tags "태그1,태그2"
```

심각도 (severity):
- `low` — 사소한 정보 누락
- `medium` — 부분적 지식, 개선 필요
- `high` — 중요한 영역에서 지식 부족
- `critical` — 핵심 기능에 영향

### 3. 분석 (Analyze)
```bash
# 미해결 갭 목록
python3 ~/.hermes/scripts/learning_gap_tracker.py list --status open

# 통계
python3 ~/.hermes/scripts/learning_gap_tracker.py stats

# 일일 리뷰용 내보내기
python3 ~/.hermes/scripts/learning_gap_tracker.py export --format markdown
```

### 4. 해결 (Resolve)
학습 후 해결 처리:
```bash
python3 ~/.hermes/scripts/learning_gap_tracker.py resolve \
  --topic "주제" \
  --notes "학습 내용 요약"
```

### 5. 정리 (Cleanup)
```bash
# 30일 이상 된 해결 갭 자동 삭제
python3 ~/.hermes/scripts/learning_gap_tracker.py cleanup --days 30
```

## 🔄 일일 자기 개선 리뷰 통합

`daily-self-review` 리뷰에서 다음을 추가:
1. `learning_gap_tracker.py export --format markdown` 실행
2. 미해결 갭 중 encounter_count ≥ 2인 것을 우선 학습 대상으로 표시
3. 해결된 갭이 있으면 통계에 반영

## 📊 데이터 파일

- **저장소:** `~/.hermes/memory/learning_gaps.json`
- **구조:**
  ```json
  {
    "gaps": [
      {
        "topic": "주제",
        "context": "맥락",
        "severity": "medium",
        "tags": ["ios", "swift"],
        "status": "open",
        "created": "ISO timestamp",
        "last_encountered": "ISO timestamp",
        "encounter_count": 3,
        "contexts": ["맥락1", "맥락2"],
        "auto_researched": false
      }
    ],
    "stats": {"total_detected": 10, "total_resolved": 5}
  }
  ```

## ⚠️ 주의사항

- **중복 방지:** 동일 토픽이 이미 open 상태면 encounter_count만 증가
- **자동화 금지:** 학습 갭은 반드시 주인님과의 대화 맥락에서만 기록
- **과도한 기록 자제:** trivial한 정보는 기록하지 않음 (예: 특정 명령어 옵션)
- **우선순위:** encounter_count가 높은 갭을 학습 우선순위로 삼을 것
