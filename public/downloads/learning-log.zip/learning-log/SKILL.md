---
name: learning-log
description: 주간 자동화 세션 마이닝으로 학습 항목을 추출해 Notion DB(33c76f2e-9097-8184-b51e-fa09efcf6d4d)에 기록. session_search + bookend 추출 + scripts/post_entries.py 패턴.
version: 2.0.0
author: ICBM2
metadata:
  hermes:
    tags: [learning, weekly, notion, session-mining, cron]
    category: automation
    related_skills: [llm-wiki, weekly-automation-report, weekly-self-report]
---

# learning-log — 주간 학습 항목 Notion 기록

매주 일요일 cron으로 자동화 세션들을 마이닝해 학습 항목을 추출하고 Notion Learning Log DB에 기록한다.

## 파이프라인

1. **세션 ID 확보** — `session_search(limit=15)` browse로 최근 10개 + `query=` discover로 1주 전까지
2. **bookend 추출** — `session_search(query=...)` 결과의 `bookend_start` + `bookend_end` + `messages`에서 학습 단서 수집
3. **학습 항목 5~8개 도출** — 카테고리(Automation/iOS/AI-ML/Infra/Other) 분산, 1-2문장 요약
4. **Notion POST** — `scripts/post_entries.py` (또는 session-mining 우회 패턴)

## 핵심 워크플로우

### 1단계: 세션 ID 확보 (3단계 전략)

`session_search`는 세 가지 모드를 섞어 써야 한다:

- **browse 모드** (`limit=15`, query 없음) → 최근 10개만 나옴. 1주일 전 세션은 절대 안 잡힘
- **discover 모드** (`query=..., sort=newest`) → 매치되는 세션 + bookend + messages + `match_message_id`
- **scroll 모드** (`session_id + around_message_id`) → 특정 메시지 주변 ±window 컨텍스트. **`around_message_id`는 정확해야만 동작** (추측값은 무조건 `"not in session_id"` 실패)

```python
# 1차: 최근 10개 (browse)
session_search(limit=15)
# 2차: 1주 전까지 (query + sort=newest)
session_search(query="weekly-tech-digest Tistory", sort=newest, limit=5)
# 3차: 특정 세션의 bookend_end/messages 끝까지 (정확한 match_message_id 필요)
session_search(session_id="<sid>", around_message_id=<정확한 ID>, window=2)
```

#### ⚠️ scroll anchor 함정 (W28 cron에서 재확인, 2026-07-12)

browse 결과의 `message_count` (예: 11/22/52/66/59)는 **세션의 총 메시지 수가지 그 세션 내부의 실제 message_id가 아님**. 그 값을 그대로 `around_message_id`에 넣으면 100% 실패:

```
{"error": "around_message_id 52 not in session_id cron_7995f1387b79_20260712_160043", "success": false}
```

**정확한 message_id를 얻는 유일한 경로**: 그 세션의 `session_id` + `query`로 discover 모드 매치를 시켜서 결과의 `match_message_id` 필드를 읽는 것. 또는 `bookend_end`의 메시지 ID들을 보고 (`cron_xxxx_20260712_160043` 같은) 그 세션의 다른 매치를 시킨다. **browse의 `message_count`를 scroll anchor로 절대 사용하지 말 것**.

**실전 우회** (정확한 ID를 모를 때): scroll을 포기하고 discover 모드만으로 bookend_start/bookend_end/messages 전부를 한 번에 받는 게 안정적. bookend_end의 마지막 메시지가 충분히 길면 거기서 학습 단서를 직접 추출 가능 (5단계 참조).

### 2단계: 1주 전 세션은 반드시 query로

`browse`는 최신 10개 한계. 6/15~6/21 세션 중 6/15~6/17은 `browse`로 절대 안 나옴 → **session_id의 시간 prefix(예: `20260614`) + 자동화 스킬명 결합**이 가장 신뢰할 만한 키워드.

### 3단계: 큰 skill 본문이 매치 1번을 차지하는 함정 (W28 cron 재확인, 2026-07-12)

`tistory-publisher`/`daily-self-review` 같은 누적 참조가 큰 skill 본문은 **자신이 매치 대상 1번**으로 등장해서 다른 세션의 진짜 콘텐츠를 가린다. W28 시점에 tistory-publisher SKILL.md 본문이 **200KB+** (245KB+에서 더 커짐, 매 세션마다 1~2차 분량 추가) → discover 결과가 persisted-output 200KB+로 dump되어 그 매치 안에 weekly-tech-digest 본문까지 같이 들어와 컨텍스트 폭발. **임계치 갱신**: 200KB+ 매치 1개 = 1,500자 preview만 보이고 핵심은 파일 끝에 있음.

**실전 사례 (W28, 2026-07-12)** — `session_search(query="weekly-tech-digest W28 발행")` 결과:
- 매치 1번: 212,357 chars (cron 7/10 1,651 메시지짜리 텔레그램 세션 + 매치 1번이 tistory-publisher 본문) → persisted-output
- 매치 2번: tistory-publisher 본문 200KB+ 통째 → 다른 cron 세션 가림

**우회 1**: query 키워드를 잘게 쪼개서 1차 추출 (`"Tistory 자동 발행"` → 큰 skill 본문, 이어서 `"긱뉴스 patch CJK"` → 특정 차수 세션)
**우회 2**: 200KB+ 매치의 bookend에서 다른 세션 ID 추출 후 `session_search(query=...)` 2차 검색
**우회 3 (W28 신규, 권장)**: session_id 자체에 시간 prefix가 있으면 `query`에 cron 잡 ID 일부를 포함 — 예: `cron 7995f1387b79 20260712` 형태가 tistory-publisher 본문보다 잡 ID 자체에 더 강하게 매치되어 본 세션이 1번으로 올라옴.

### 4단계: persisted-output 처리

`session_search(query=..., limit=5)` 결과는 매치 1개당 수십~수백 KB. 컨텍스트 보호를 위해 1,500 chars로 truncate되고 `/var/folders/.../hermes-results/call_function_*.txt`에 풀 데이터 저장됨.

- 출력 프리뷰에 "persisted-output" 표시 + 풀 경로 같은 줄 노출
- `read_file path="<full_path>"` 또는 `python3 -c "import json; ..."`로 구조적 추출
- snippet 200자 + session_id만 추출하면 컨텍스트 폭발 없이 10개+ 세션을 한 번에 훑을 수 있음

```python
import json
with open('/var/folders/r2/.../call_function_xxx.txt') as f:
    data = json.load(f)
for r in data.get('results', []):
    sid = r.get('session_id', '')
    if sid.startswith('cron_') and '20260615' <= sid.split('_')[1] <= '20260621':
        print(sid, '|', r.get('when','')[:25], '|', r.get('title','')[:60])
```

#### W29 (2026-07-19) 실전 검증 — 일자별 backward scan 패턴

`query="cron 20260718"` / `query="cron 20260717"` 등 **일자 prefix**를 query로 던지면 그 일자의 cron 잡이 다수 매치됨. 각 persisted-output을 순회하며 `session_id.split('_')[2]` (3번째 토큰이 일자 `20260718` 형식)로 필터링:

```python
import json
files = [
    ('/var/folders/.../call_xxx_q18.txt', '20260718'),
    ('/var/folders/.../call_xxx_q17.txt', '20260717'),
    ('/var/folders/.../call_xxx_q16.txt', '20260716'),
]
seen = set()
for path, day in files:
    data = json.load(open(path))
    for r in data.get('results', []):
        sid = r.get('session_id', '')
        if sid.startswith('cron_') and sid not in seen:
            seen.add(sid)
            print(f'[{sid.split("_")[2]}] {sid}  {(r.get("when","") or "")[:16]}  {(r.get("title","") or "")[:60]}')
```

**핵심**: persisted-output 1개당 100~570KB이지만 `session_id`/`when`/`title` 3개 필드만 추출하면 10개+ 세션 식별에 컨텍스트 5KB 미만 사용. `message_count` / `match_message_id` / `snippet` 등 무거운 필드는 매치 1~2개에만 다시 scroll로 따로 본다.

### 5단계: bookend에서 진짜 학습 추출

세션의 `match_message_id`만 보면 매치된 한 줄 snippet만 보임. 학습 항목을 만들려면:

- `bookend_start` — 크론 job의 입력 (스킬 호출 + 사용자 instruction)
- `bookend_end` — 그 세션의 최종 출력 리포트 (정형화된 마일스톤 카운트, 분기 패턴, 트러블슈팅 결과)
- `messages` (anchor ±5) — 매치된 컨텍스트의 진짜 본문

`tistory-publisher` 세션의 `bookend_end`는 "X차 발행 완료" 리포트 형식이라 누적 마일스톤(1회 컷 N회째, CJK 0건 M회 연속, --record K회째)이 그대로 학습 데이터가 됨.

## Notion POST 패턴

### `scripts/post_entries.py`의 `_curl` 패턴이 유일하게 안전

2026-06-14 incident 검증됨. inline 예시코드에 박힌 `shell=True` + `env["NTK"]=tk` + `$NTK` bash env-var 패턴은 사전 검증은 통과하지만 POST는 모두 invalid.

**scripts/post_entries.py의 `_curl()` 패턴이 정답** — list-형 subprocess + Python f-string으로 auth_header 빌드. 다른 방식 시도 금지.

### scripts/post_entries.py의 알려진 함정 (2026-06-21 발견, 2026-07-05 재확인)

⚠️ **Pre-existing f-string syntax error** (46번 줄):
```python
# 고침 전 (SyntaxError):
auth_header = "Authorization: Bearer *** + tk
#                ↑ 닫는 따옴표+콤마 누락 → unterminated string literal

# 고침 후 (올바른 패턴):
auth_header = f"Authorization: Bearer {tk}"
```

`python3 scripts/post_entries.py` 실행 시 `SyntaxError: unterminated string literal (detected at line 46)`로 즉시 죽음. `ENTRIES`를 아무리 채워도 실행 안 됨.

**원인**: 이 패턴은 session-mining 가이드 §7.4의 known 함정과 동일. weekly-automation-report의 `notion_preflight.py` / `post_weekly_entries.py`에도 같은 버그가 있었음 (2026-06-14 incident, 2026-06-21 일요일 점검에서 재확인).

**확인 절차**: `read_file`로 46번 줄을 직접 확인. `Bearer ***` 다음에 `+ tk,`가 있으면 SyntaxError. `Bearer {tk}` 형태의 f-string이 정상.

**영구 fix 상태 (2026-07-05 cron에서 재발견)**: SKILL.md 본문에는 "2026-06-21 cron에서 patch 적용 완료"라고 기록되어 있으나, **2026-07-05 cron 실행 시점에 동일 SyntaxError가 다시 발생** (이번 cron에서 `f"Authorization: Bearer *** 형태로 patch 적용). 즉 "한 번 patch됐다"는 절대 보장되지 않음 — 다음 cron에서 재발할 가능성을 항상 가정하고 **§실행 절차의 0단계 (사전 검증)** 을 반드시 수행할 것.

**사전 검증 단계 (2026-07-05 신규, 2026-07-12 W28 cron 실전 입증)** — 실행 절차의 0단계로 추가:

0. **Syntax 사전 검증** — `python3 scripts/post_entries.py` 실행 *전에* 다음 1줄로 46번 줄의 syntax fix를 확인. 실패 시 즉시 patch 후 재실행:
   ```bash
   python3 -c "import ast; ast.parse(open('scripts/post_entries.py').read()); print('SYNTAX OK')"
   ```
   또는 `scripts/verify_post_entries_patch.py` (번들 검증 스크립트) 실행 — **5종 14체크를 한 번에 검증** (아래 §Support Files 참조).

**W28 (2026-07-12) 실전 결과** — verify_post_entries_patch.py 14/14 통과 확인됨. verify가 만드는 **임시 테스트 페이지는 POST 후 즉시 PATCH `archived=true`로 자동 정리**되므로 Notion DB를 오염시키지 않는다. 사전 검증 단계를 건너뛰면 SyntaxError 발생 시 ENTRIES 작성 + 실행 + 디버깅 30분+ 낭비 — 0단계 5초 비용이 압도적으로 이득.

**같은 함정이 다른 skill 스크립트에 또 있을 수 있음** — weekly-automation-report의 `notion_preflight.py` / `post_weekly_entries.py` 잔존 가능성. 다음 점검에서 동일 패턴 (`Bearer *** + tk`, `Bearer *** grep -nE "Bearer \*\*\* \+ tk" skills/*/scripts/*.py skills/*/templates/*.py 2>/dev/null`.

**우회 (긴급, skill patch 전)**: `urllib.request` 기반 임시 스크립트 (`/tmp/post_entries_urllib.py`):
```python
import urllib.request, json
req = urllib.request.Request(
    "https://api.notion.com/v1/pages",
    data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
    method="POST",
    headers={"Authorization": f"Bearer {tk}", "Notion-Version": "2022-06-28",
             "Content-Type": "application/json"},
)
with urllib.request.urlopen(req, timeout=20) as r:
    j = json.loads(r.read().decode())
```

## Notion DB 스키마

- **DB ID**: `33c76f2e-9097-8184-b51e-fa09efcf6d4d`
- **속성**: `Name`(title), `Date`(date), `Category`(select: iOS/Swift | AI/ML | Automation | Infra | Other), `Summary`(rich_text), `URL`(url, optional)
- **Notion API**: `https://api.notion.com/v1`, version `2022-06-28`
- **토큰**: `~/.hermes/secrets/notion_token.txt` (preflight `GET /v1/users/me` 통과 필수)

## 실행 절차

```bash
# 1) 세션 ID 확보 + bookend 추출 (세션 마이닝)
python3 /tmp/extract_sessions.py    # 1주치 cron 세션 ID

# 2) 각 세션의 bookend에서 학습 단서 추출
python3 /tmp/extract_bookends.py    # 또는 /tmp/extract_more.py

# 3) scripts/post_entries.py의 46번 줄 정상 여부 확인
#    (Bearer *** + tk, 패턴이면 patch 필요)

# 4) ENTRIES 리스트 5~8개 작성 (자동화 3+, iOS 1+, AI/ML 0~1, Infra 1+)

# 5) 실행
python3 scripts/post_entries.py

# 6) 결과 확인
# === Summary ===
# Success: 6/6
# Failed: 0
# Date: 2026-06-21
```

## Pitfalls

- **`execute_code`는 cron 컨텍스트에서 차단**됨. Python 데이터 처리는 `write_file /tmp/...` + `terminal python3 /tmp/...` 또는 `python3 -c "..."`로.
- **큰 skill 본문 매치 함정** (§3 참조) — query 키워드 쪼개기 또는 2차 검색
- **browse 10개 한계** — 1주 전 세션은 query로만 도달 가능
- **f-string `Bearer *** + tk,` syntax error** — scripts/post_entries.py 46번 줄, weekly-automation-report의 번들 스크립트 2건에도 동일 패턴
- **`scripts/post_entries.py` 46번 줄 patch는 "한 번 됐다"는 영구 보장이 아님** (2026-07-05 cron에서 재발 확인) — 매 실행 전 `scripts/verify_post_entries_patch.py` 또는 `python3 -c "import ast; ast.parse(open('scripts/post_entries.py').read())"` 1줄 사전 검증 필수
- **scroll anchor 함정 (W28 신규)** — browse 결과의 `message_count`는 그 세션의 메시지 총합이지 실제 message_id가 아님. `around_message_id`에 직접 넣으면 100% 실패. 정확한 ID는 discover 모드 `match_message_id`에서만. 모를 땐 scroll 자체를 건너뛰고 discover로 bookend_start/end/messages 전부 받기.
- **큰 skill 본문 매치 임계치 갱신 (W28)** — tistory-publisher SKILL.md가 200KB+ 도달. "245KB+" 기준이 아니라 "200KB+"면 의심"으로 임계값 낮춤. query에 cron 잡 ID prefix를 포함하면 본 세션이 1번으로 올라옴 (우회 3).
- **Unicode(한글) entry name**이 bash heredoc + f-string 조합에서 깨질 수 있음 — `scripts/post_entries.py`처럼 별도 파일 + `ensure_ascii=False`가 안전
- **Notion 토큰 silent expire** — 6주 연속 silent failure가 가장 위험 (2026-06-07 incident). `GET /v1/users/me` preflight 필수.
- **NotebookLM 후보 cron 마커 함정** (2026-06-20 발견) — `===== NOTEBOOKLM후보 =====` 마커는 텔레그램 실패 시에만 출력. 텔레그램 1차 성공 시 마커 부재 → '마커 없으면 SILENT'로 오해하기 쉬움. 실제 의도는 후보 12개를 final response에 출력하는 것. 보안 가드(approval prompt)는 cron에서 무시 가능.
- **tistory §3.11/§4 SSOT drift 3종 (W29 신규)** — (1) `run_pipeline()`이 publish 안 하고 `status=ready`까지만 → cron이 별도 `tistory_publisher.py` 호출 검증 필요, (2) `blog_pipeline_state.json` details 마지막 entry가 stale 그대로 + 실제 Tistory 글은 발행됨 → details append 누락 drift, (3) `last_published_id` vs `last_published_url` mismatch. SSOT 임의 보정은 **사용자 확인 후에만** (cron은 패치 보류).
- **Wiki lint regex 캡처 그룹 함정 (W29 신규)** — `LINK_RE = re.compile(r\[\[([^\[\]|]+?)(?:\|[^\]]+?)?\]\])` 같은 캡처 그룹 2개 → `findall`이 tuple 반환 → 모든 wikilink broken 오분류. 진단법: `findall` 결과가 `list[str]`이 아닌 `list[tuple]`이면 캡처 그룹 2개 이상. 단일 그룹 + 명시적 처리로 수정.
- **카운트 스크립트 불일치 (W29 신규)** — `weekly_report.py`는 142/2 ERR + 7c2b9a9be162 timeout까지 포착, `cron_weekly_summary.py`는 1 ERR만 카운트. **weekly_report.py 채택** (더 자세한 분류). 다른 카운트 스크립트 2종이 같은 일자에 다른 값 반환하면 더 자세한 쪽 채택 + 차이점 journal에 명시.
- **set -e + 빈 xargs 조합 버그 (W29 신규)** — `tistory_publish_count.sh`가 `set -e` + 빈 xargs로 TOTAL 0 표시 (실제 38건 발행). 동일 패턴 가진 다른 카운트 스크립트 점검 권장.

## 카테고리 힌트 매핑 (W29, 2026-07-19 검증)

| 세션 prefix | skill | 학습 카테고리 | 비고 |
|-------------|-------|-------------|------|
| `cron_b1bca63a117a_...` (06:00~22:00 KST) | tistory-publisher | Automation (Tistory 발행 정형화) | bookend_end의 "X차 발행 완료"에서 1회 컷/--record/§3.5 신호 마일스톤 추출. **W29 신규**: §3.11/§4 SSOT drift 3건 (details 누락, last_published_id mismatch, run_pipeline status=ready 한계) |
| `cron_7995f1387b79_...` (16:00 KST 일요일) | weekly-tech-digest | Automation (뉴스레터 발행/보류) | **W29 첫 보류 케이스**: C 등급 (52점 decision=rewrite) → 누적 13번째 skip, HTML/데이터 W29 재사용 |
| `cron_388898171a79_...` (21:00 KST) | knowledge-graph | Infra (Notion→그래프→GitHub Pages) | 노드/연결 수, 엔티티 Top 5 |
| `cron_075bec58df7b_...` (08:30 KST) | ios-trend-digest | iOS/Swift (Apple Developer News fetch) | Notion 기록 N/N 성공 |
| `cron_582ecc59aaee_...` (10:00 KST) | agent-benchmark-tracker | AI/ML (신모델 점수) | leaderboard 스크래핑 결과 |
| `cron_d7bd4309bbf0_...` (15:30 KST 일요일) | llm-wiki + weekly-self-report | Other (심층 점검 발견) | wiki lint, 자동화 리포트, skill self-repair. **W29**: 크론 99% 성공률 + Wiki lint 76/13/12 + Notion 학습 log 정형화 |
| `cron_dc9a2e6aaaaa_...` (16:00 KST) | notebooklm-youtube-automation | Automation (Tistory 마커 함정) | `===== NOTEBOOKLM후보 =====` 마커 함정 학습 항목 |
| `cron_e0ba30d8a122_...` (17:30 KST) | cron-error-monitor | Infra (실시간 에러 모니터링) | **W29 신규**: weekly_report.py vs cron_weekly_summary.py 카운트 불일치 함정 (weekly_report 채택) |
| `cron_0f893ba14797_...` (14:00 KST) | icbm2-daily-workspace-cleanup | Automation (Manim+Blog+YouTube 임시 산출물 정리) | 7/18 14:01 cron에서 5d0f14aef84c cleanup 정상 동작 |
| `cron_b02a45f4d14e_...` (13:00 KST) | blog-topic (Notion 긱뉴스 갱신) | Automation (Notion DB 갱신) | 매주 일요일 13:00, `blog_pipeline.py --refresh-topics`와 다른 별도 잡 |
| `cron_0b0e9f44e10a_...` (07:00 KST) | tistory-cookie-daily-check | Automation (쿠키 만료 자동 감지) | 7/19 07:00 세션 |
| `cron_7c2b9a9be162_...` | skills-marketplace-sync | Infra (실패 패턴 — 600s timeout) | **W29 실패 사례**: 7c2b9a9be162 timeout → 다음 점검 필요 |
| `20260717_143833_a702f23d` (telegram) | notebooklm-upload | Automation (선택→업로드) | W28 12/12 업로드 (일반 6 + Shorts 6) gold 패턴 |

## W29 (2026-07-19) cron 잡 ID prefix 신규 추가

이번 주 새로 식별된 잡 ID들 (앞자리 8자리는 `cron_` 제외):
- `b1bca63a117a` — tistory-publisher (06:00~22:00 KST 매일 다수)
- `7995f1387b79` — weekly-tech-digest (일요일 16:00)
- `d7bd4309bbf0` — llm-wiki 일요일 심층 점검 (일요일 15:30)
- `dc9a2e6aaaaa` — notebooklm-youtube-automation (일요일 16:00)
- `582ecc59aaee` — agent-benchmark-tracker (일요일 10:00)
- `e0ba30d8a122` — cron-error-monitor (매시 30분)
- `0f893ba14797` — icbm2-daily-workspace-cleanup (매일 14:00)
- `b02a45f4d14e` — blog-topic (Notion 긱뉴스 갱신, 매일 13:00)
- `0b0e9f44e10a` — tistory-cookie-daily-check (매일 07:00)
- `388898171a79` — knowledge-graph (매일 21:00) — **W29 실패**: Response truncated
- `7c2b9a9be162` — skills-marketplace-sync — **W29 실패**: 600s timeout

## W29 (2026-07-19) 신규 학습 항목 카테고리

이번 주 추가된 학습 카테고리 패턴:

1. **§3.5 신호 4 FAKE_PUBLISH 자동 가드** — daily_counts[오늘] ≥ 2 AND details[-1] 슬롯 변동 없음 → exit 1로 publish 단계 차단. 289차 가짜 발행 5건 사건에서 학습.
2. **PEP 604 → Optional[…] 3.9 호환화** — check_state_consistency.py에서 `str | None` → `Optional[str]` 변환으로 `/usr/bin/python3` (3.9)에서 정상 실행.
3. **SSOT drift 3종 (293차)** — details 누락, last_published_id mismatch, run_pipeline status=ready 한계. SSOT 임의 보정은 사용자 확인 후에만.
4. **Wiki lint regex 캡처 그룹 함정** — `findall`이 캡처 그룹 2개 이상이면 tuple 반환 → 모든 wikilink broken 오분류. 단일 그룹 + 명시적 처리 필수.
5. **첫 정석 보류 케이스** — weekly-tech-digest W28이 C 등급 → 누적 13번째 skip (W21/W24/W26/W27 모두 B 등급 발행).
6. **카운트 스크립트 불일치** — `weekly_report.py` (142/2 ERR) vs `cron_weekly_summary.py` (1 ERR e0ba30d8a122만) → weekly_report.py 채택 (더 자세한 에러 + timeout도 포착).

## 한 사이클 실전 예시 (W29, 2026-07-19)

```
1. session_search(limit=15) → 10개 7/19 cron 세션 ID 확보 (browse)
2. session_search(query="cron 20260718", sort=newest) → 5개 7/18 cron 잡 + persisted-output (562KB)
3. session_search(query="cron 20260717", sort=newest) → 5개 7/17 cron 잡 + persisted-output
4. session_search(query="cron 20260716", sort=newest) → backward 7/16까지
5. python3 /tmp/scan_w29_sessions.py → 9개 7/19 cron + 5개 7/18 cron + backward 추가 = 14개 W29 cron 세션 식별
6. 각 persisted-output을 python3 -c "import json; ..." 로 session_id+when+title만 추출 → 컨텍스트 5KB 미만
7. session_search(query="W29", sort=newest) → 7/19 16:00 weekly-tech-digest + 15:30 llm-wiki 매치
8. session_search(session_id=cron_7995f1387b79_20260719_160045, around_message_id=198475, window=8) → 7/19 weekly-tech-digest W28 C등급 보류 결정 본문
9. session_search(session_id=cron_d7bd4309bbf0_20260719_153040, around_message_id=198415, window=8) → 7/19 llm-wiki W29 점검 (cron 99% + Wiki lint 76/13/12) 본문
10. session_search(query="W29 Tistory 287차 288차", sort=newest) → 7/19 19:00 tistory 293차 SSOT drift 3건 본문
11. 7개 학습 항목 도출 (Automation 4, Other 1, Infra 2)
12. scripts/post_entries.py 0단계 ast.parse + verify_post_entries_patch.py 14/14 통과
13. python3 scripts/post_entries.py → 7/7 POST 성공
```

## Support Files

- `references/session-mining.md` — session_search 2단계 전략, persisted-output 처리, 카테고리 힌트 매핑 (W29 검증본)
- `scripts/post_entries.py` — Notion DB writer (ENTRIES 리스트 채운 후 `python3 scripts/post_entries.py`)
- `scripts/verify_post_entries_patch.py` — 46번 줄 f-string fix + module import + Notion preflight + POST/PATCH archive roundtrip을 한 번에 검증하는 ad-hoc verifier. `python3 scripts/post_entries.py` 실행 전 0단계 사전 검증으로 사용 (2026-07-05 cron에서 확립).

## W29 (2026-07-19) cron 결과 — 7/7 POST 성공

| # | 카테고리 | 제목 | 페이지 ID |
|---|---------|------|----------|
| 1 | Automation | tistory-publisher 287~293차 — 연속 76회 all-green + §3.5 신호 4 FAKE_PUBLISH | 3a276f2e-9097-81f5-a512-d15d2370797d |
| 2 | Automation | weekly-tech-digest W28 발행 보류 — 누적 13번째 skip + C 등급 | 3a276f2e-9097-816c-93b3-f6757be054d9 |
| 3 | Other | 일요일 심층 점검 W29 — 크론 99% 성공률 + Wiki lint 76/13/12 | 3a276f2e-9097-81f3-a222-d75d49fa68b3 |
| 4 | Automation | NotebookLM W28 12/12 업로드 — gold #11+#28+#44 정착 | 3a276f2e-9097-81ca-a1c3-fc522bc24606 |
| 5 | Automation | tistory 293차 §3.11/§4 SSOT drift 발견 | 3a276f2e-9097-81a8-9521-fc1f38adb7c5 |
| 6 | Infra | Wiki lint regex 캡처 그룹 함정 | 3a276f2e-9097-81ce-bdd0-e2604532feaf |
| 7 | Infra | Notion 학습 log 정형화 — W29 일요일 cron 7/7 POST | 3a276f2e-9097-8156-a7a7-ced937c35c3b |

**카테고리 분포**: Automation 4, Other 1, Infra 2 (iOS/Swift 0 — 이번 주 iOS cron 잡 미식별, AI/ML 0 — 벤치마크 cron은 매주 일요일 10:00 잡이지만 W29 journal에 별도 학습 단서 부족).
