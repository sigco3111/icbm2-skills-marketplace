---
name: learning-log
description: 주간 학습 로그를 Notion에 기록 — 주인님이 Telegram에서 물어본 기술 질문, 조사한 내용 자동 정리
version: 1.0.0
author: icbm2
metadata:
  hermes:
    tags: [Learning, Log, Notion, Weekly]
prerequisites:
  secret_files: [notion_idea_token.txt]
---

# 학습 로그

매주 일요일에 주인님의 기술 질문과 학습 내용을 Notion DB에 기록합니다.

## Notion DB

- **DB ID:** `33c76f2e-9097-8184-b51e-fa09efcf6d4d`
- **DB명:** Learning Log
- **속성:** Name(title), Date(date), Category(select), Summary(rich_text), URL(url)
- **Category 옵션:** iOS/Swift, AI/ML, Automation, Infra, Other

## 실행 단계

### 1. 세션 검색

`session_search`로 금주 세션에서 주인님이 기술적으로 물어본 내용 검색:

- 키워드: iOS, Swift, SwiftUI, Xcode, AI, ML, 자동화, Docker, 서버 등
- 주인님의 질문과 그에 대한 답변/조사 결과를 추출

### 2. Notion에 기록

각 학습 항목을 DB에 페이지로 생성:

```python
import os, json, subprocess
from datetime import datetime, timezone, timedelta

TK_PATH = os.environ["NOTION_TOKEN_PATH"]
DB_ID = "33c76f2e-9097-8184-b51e-fa09efcf6d4d"
today = datetime.now(timezone(timedelta(hours=9))).strftime("%Y-%m-%d")

with open(TK_PATH) as f:
    tk = f.read().strip()

payload = {
    "parent": {"database_id": DB_ID},
    "properties": {
        "Name": {"title": [{"text": {"content": "Swift Concurrency 개념 정리"}}]},
        "Date": {"date": {"start": today}},
        "Category": {"select": {"name": "iOS/Swift"}},
        "Summary": {"rich_text": [{"text": {"content": "async/await vs Combine 비교"}}]},
        "URL": {"url": ""}
    }
}
with open("/tmp/notion_entry.json", "w") as f:
    json.dump(payload, f, ensure_ascii=False)

env = dict(os.environ)
env["NTK"] = tk
r = subprocess.run(
    f'curl -s -X POST --max-time 15 https://api.notion.com/v1/pages -H "Authorization: Bearer $NTK" -H "Notion-Version: 2022-06-28" -H "Content-Type: application/json" -d @/tmp/notion_entry.json',
    shell=True, capture_output=True, text=True, env=env
)
```

### 3. 품질 기준

- **최소 1개, 최대 10개** 항목 기록 (학습한 것이 없으면 0개도 OK)
- Category는 반드시 지정
- Summary에 핵심 내용을 1-2문장으로 요약
- 본문에 상세 내용을 추가 (코드 스니펫, 결론 등)
- 한국어로 작성
- 학습한 것이 없으면 "이번 주 학습 내용 없음"이라고 기록

### 4. 완료 확인

기록된 항목 수를 출력.
