#!/usr/bin/env python3
"""learning-log Notion DB writer.

Posts weekly learning entries to Notion DB (33c76f2e-9097-8184-b51e-fa09efcf6d4d).
Edit the `ENTRIES` list with this week's learnings, then run:

    python3 scripts/post_entries.py

The script pre-validates the Notion token via GET /v1/users/me before
posting, and gracefully reports each entry's success/failure with a final
summary line.
"""
import os
import json
import subprocess
import sys
from datetime import datetime, timezone, timedelta

TK_PATH = os.path.expanduser("~/.hermes/secrets/notion_token.txt")
DB_ID = "33c76f2e-9097-8184-b51e-fa09efcf6d4d"
NOTION_API = "https://api.notion.com/v1"
NOTION_VERSION = "2022-06-28"
CATEGORIES = ["iOS/Swift", "AI/ML", "Automation", "Infra", "Other"]


def today_kst() -> str:
    return datetime.now(timezone(timedelta(hours=9))).strftime("%Y-%m-%d")


def _curl(tk, args):
    """Run curl with bearer token injected as a separate -H arg (no shell, no $var).

    CRITICAL: Do NOT use shell=True with `Authorization: Bearer $NTK` as a
    string literal. Two failure modes observed on 2026-06-14 cron run:
      1) Pre-check via shell-string form returned {"object":"user"} (looked
         fine), but the subsequent POST returned "API token is invalid" for
         ALL 6 entries. Root cause: shell-string + env-var expansion is
         inconsistent between GET and POST in tirith/cron context — the
         header reached curl as a literal $NTK in the GET but the POST was
         token-stripped.
      2) Same problem recurs in cron mode for any skill that posts to Notion.

    Fix: pass args as a Python list to subprocess.run, build the header as a
    single string, hand it to curl as a discrete -H arg. No shell, no env var.
    """
    auth_header = f"Authorization: Bearer {tk}"
    return subprocess.run(
        ["curl", "-s", "--max-time", "20", *args,
         "-H", auth_header,
         "-H", f"Notion-Version: {NOTION_VERSION}"],
        capture_output=True, text=True
    ).stdout


def check_token(tk):
    """Validate token via /v1/users/me. Returns True if valid."""
    try:
        resp = json.loads(_curl(tk, ["-X", "GET", f"{NOTION_API}/users/me"]))
        return resp.get("object") == "user"
    except Exception:
        return False


def post_entry(tk, entry, today):
    if entry["Category"] not in CATEGORIES:
        return False, f"INVALID_CATEGORY ({entry['Category']})"
    payload = {
        "parent": {"database_id": DB_ID},
        "properties": {
            "Name": {"title": [{"text": {"content": entry["Name"]}}]},
            "Date": {"date": {"start": today}},
            "Category": {"select": {"name": entry["Category"]}},
            "Summary": {"rich_text": [{"text": {"content": entry["Summary"]}}]},
            "URL": {"url": entry.get("URL")},
        },
    }
    with open("/tmp/notion_entry.json", "w") as f:
        json.dump(payload, f, ensure_ascii=False)
    try:
        resp = json.loads(
            _curl(tk, [
                "-X", "POST", f"{NOTION_API}/pages",
                "-H", "Content-Type: application/json",
                "-d", "@/tmp/notion_entry.json",
            ])
        )
    except Exception as e:
        return False, f"PARSE_ERROR ({e})"
    if resp.get("object") == "page":
        return True, resp.get("id", "")
    return False, resp.get("message", "unknown")[:120]


# Edit this list with the week's learning entries. Each entry is a dict with:
#   Name (str, required)    - Title, concise topic name
#   Category (str, required) - One of CATEGORIES
#   Summary (str, required) - 1-2 sentence core takeaway
#   URL (str, optional)     - Reference link
ENTRIES = [
    {
        "Name": "tistory-publisher 287~293차 — 연속 76회 all-green + §3.5 신호 4 FAKE_PUBLISH 자동 가드 실전 검증",
        "Category": "Automation",
        "Summary": "W29(7/13~7/19) tistory-publisher 7회차 cron 중 287차(#1043 SpaceX IPO)/292차(#1044 Claude Fable 5)/293차(#1045) 3건 진짜 발행 + 290차(env -i 격리 모드 자체 버그 발견) + 291차(raw 검증 워크어라운드) + 293차(stale+sensational skip) 모두 안전 운영. 289차 daily_counts[2026-07-18]=5 vs 실제 신규 0건 가짜 발행 5건 사건 → check_state_consistency.py 신호 4 FAKE_PUBLISH (daily_counts≥2 AND details[-1] 슬롯 변동 없음 → exit 1) 추가. PEP 604 → Optional[…] 변환으로 /usr/bin/python3 3.9 호환화 동반.",
        "URL": "https://sigco.tistory.com/1045",
    },
    {
        "Name": "weekly-tech-digest W28 발행 보류 — 누적 13번째 skip + C 등급 (52점 decision=rewrite)",
        "Category": "Automation",
        "Summary": "7/19 16:03 weekly-tech-digest cron이 W28(7/13~7/19) 본문 작성 후 품질 게이트 결과 C 등급(52점, decision=rewrite) → SKILL.md 명시 규칙 'C 이하 → 발행 보류 / 다음 주 연기' 따라 정석 보류. Readability 10/20 (평균 문장 91자, 권장 60자 이하), SEO 15/25 (서론 SEO 메타 부적합). HTML 10,767자 (권장 8,000자 초과), 데이터 27건은 OK (AI 9 / iOS 10 / 자동화 8). weekly_newsletter_state.json 누적 skip 이력 13건째. W28 HTML/데이터 보존되어 W29(7/26) 발행 시 재사용 권장.",
    },
    {
        "Name": "일요일 심층 점검 W29 — 크론 99% 성공률 + Wiki lint 76 브로큰 wikilink + 13 고아",
        "Category": "Other",
        "Summary": "7/19 15:30 llm-wiki 일요일 cron: 144 크론 실행 중 142 성공 / 2 실패 (skills-marketplace-sync 7c2b9a9be162 600s timeout + 388898171a79 Response truncated) → 99% 가동률. ObsidianVault/wiki 166 페이지 lint 결과: 브로큰 wikilink 76 instances / 63 unique (claude-code 9회, nvidia 3회), 고아 13개 (amd-mi355x/andon-labs/axon/retry-now/safari-mcp 등 7월 신규 페이지 backlink 누락), stale 12개 (>90일 미갱신). Tistory W29 false-negative는 set -e + 빈 xargs 조합 버그로 TOTAL 0 표시 → ls+xargs grep 수동 카운트 38건 확정.",
    },
    {
        "Name": "NotebookLM W28 12/12 업로드 — 일반 6 + Shorts 6 + 자동 스킵 gold #11+#28+#44 패턴 정착",
        "Category": "Automation",
        "Summary": "7/19 18:22~18:23 NotebookLM 파이프라인: GPT-5.6 볼록최적화 + Kimi K3 + Mindwalk + 루프 안의 인간은 지쳤다 등 6개 일반 + 6 Shorts = 12/12 YouTube 업로드 성공 (8개 노트북 중 비디오 오버뷰 미생성분 자동 패스 → 6 성공분만 업로드). 사후 정리도 성공분만 삭제 + 실패분 보존 (재시도 대비). selection_numbers 수동 패치 + notebooklm_prepare.py --skip-telegram 흐름 + upload --approved 자동 스킵 = 3중 gold 패턴 영구화. 7/19 cron dc9a2e6aaaaa가 W28 후보 12개 정상 전송 + 텔레그램 self-test bot 응답 검증.",
    },
    {
        "Name": "tistory 293차 §3.11/§4 SSOT drift 발견 — details 누락 + last_published_id mismatch",
        "Category": "Automation",
        "Summary": "7/19 19:01 293차에서 SSOT 정합 깨짐 3건 신규 발견: (a) run_pipeline()은 publish 안 하고 status=ready까지만 → cron이 별도 tistory_publisher.py 호출 검증 필요, (b) blog_pipeline_state.json details 마지막 entry가 #1043 (7/18 stale) 그대로인데 실제 Tistory #1044/#1045는 발행됨 → details append 누락 drift 패턴, (c) last_published_id=\"1043\" stale / last_published_url=\"#1045\" 정합 mismatch → 두 필드 동시 갱신 권장. commit_publish()가 details append/last_published_id 갱신 안 하면 5-3 함정 패치 확장 필요. details/daily_counts 임의 보정은 SSOT 변경이라 사용자 확인 후에만 수행 원칙 준수.",
    },
    {
        "Name": "Wiki lint regex 캡처 그룹 함정 — findall 튜플 반환 → 모든 링크 broken 오분류",
        "Category": "Infra",
        "Summary": "7/19 15:30 llm-wiki cron의 초기 lint 스크립트가 정규식 캡처 그룹 2개 `LINK_RE = re.compile(r\\[\\[([^\\[\\]|]+?)(?:\\|[^\\]]+?)?\\]\\])` 때문에 findall이 튜플 반환 → 모든 wikilink를 broken으로 오분류 (실제 76/63 → 잘못된 카운트). 단일 캡처 그룹 + 명시적 처리로 수정 후 실제 카운트 확인. Obsidian Vault 경로 자동 탐지 + regex 단일 그룹 함정은 다음 Wiki lint skill-bundled 정형화 시 영구 포함 권장. 신호 패턴: 'regex findall 결과가 list[str]이 아닌 list[tuple]이면 캡처 그룹 2개 이상' 진단법.",
    },
    {
        "Name": "Notion 학습 log 정형화 — W29 일요일 cron이 Notion DB 7/7 POST 성공",
        "Category": "Infra",
        "Summary": "7/19 15:34 llm-wiki 일요일 cron이 /tmp/post_weekly_W29.py로 Notion DB(33c76f2e-9097-81be-9ea4-cefd03512e81) 7개 항목 POST 7/7 성공: Tistory 발행 38 / Tistory cron 실행 50 / Cron 성공률 99 / Cron 실패 2 / Wiki 페이지 166 / Wiki 브로큰 76 / Wiki 고아 13. urllib.request.Request + Bearer 헤더 + ensure_ascii=False 패턴이 shell=True + env var 패턴보다 안전. status file fallback(preflight FAIL 시 status.md에 payload 보존 + 재실행 가이드)도 정형화. log.md 1246줄에 전체 lint 분석 영구 기록.",
    },
]


def main():
    if not os.path.exists(TK_PATH):
        print("NOTION_TOKEN_MISSING:", TK_PATH)
        return 1
    with open(TK_PATH) as f:
        tk = f.read().strip()

    if not check_token(tk):
        print("NOTION_TOKEN_INVALID - reissue integration at notion.so/my-integrations")
        return 2

    today = today_kst()
    print(f"[{today}] Posting {len(ENTRIES)} entries to Notion DB...")

    success, failed = 0, 0
    for entry in ENTRIES:
        ok, detail = post_entry(tk, entry, today)
        marker = "OK" if ok else "FAIL"
        print(f"  {marker} [{entry['Category']}] {entry['Name']} -> {detail}")
        if ok:
            success += 1
        else:
            failed += 1

    print(f"\n=== Summary ===\nSuccess: {success}/{len(ENTRIES)}\nFailed: {failed}\nDate: {today}")
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
