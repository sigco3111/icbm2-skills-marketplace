#!/usr/bin/env python3
"""learning-log Notion DB writer.

Posts weekly learning entries to Notion DB (33c76f2e-9097-8184-b51e-fa09efcf6d4d).
Edit the `ENTRIES` list with this week's learnings, then run:

    python3 scripts/post_entries.py

The script pre-validates the Notion token via GET /v1/users/me before
posting, and gracefully reports each entry's success/failure with a final
summary line.
"""
import os
import json
import subprocess
import sys
from datetime import datetime, timezone, timedelta

TK_PATH = os.path.expanduser("~/.hermes/secrets/notion_token.txt")
DB_ID = "33c76f2e-9097-8184-b51e-fa09efcf6d4d"
NOTION_API = "https://api.notion.com/v1"
NOTION_VERSION = "2022-06-28"
CATEGORIES = ["iOS/Swift", "AI/ML", "Automation", "Infra", "Other"]


def today_kst() -> str:
    return datetime.now(timezone(timedelta(hours=9))).strftime("%Y-%m-%d")


def _curl(tk, args):
    """Run curl with bearer token injected as a separate -H arg (no shell, no $var).

    CRITICAL: Do NOT use shell=True with `Authorization: Bearer $NTK` as a
    string literal. Two failure modes observed on 2026-06-14 cron run:
      1) Pre-check via shell-string form returned {"object":"user"} (looked
         fine), but the subsequent POST returned "API token is invalid" for
         ALL 6 entries. Root cause: shell-string + env-var expansion is
         inconsistent between GET and POST in tirith/cron context — the
         header reached curl as a literal $NTK in the GET but the POST was
         token-stripped.
      2) Same problem recurs in cron mode for any skill that posts to Notion.

    Fix: pass args as a Python list to subprocess.run, build the header as a
    single string, hand it to curl as a discrete -H arg. No shell, no env var.
    """
    auth_header = f"Authorization: Bearer {tk}"
    return subprocess.run(
        ["curl", "-s", "--max-time", "20", *args,
         "-H", auth_header,
         "-H", f"Notion-Version: {NOTION_VERSION}"],
        capture_output=True, text=True
    ).stdout


def check_token(tk):
    """Validate token via /v1/users/me. Returns True if valid."""
    try:
        resp = json.loads(_curl(tk, ["-X", "GET", f"{NOTION_API}/users/me"]))
        return resp.get("object") == "user"
    except Exception:
        return False


def post_entry(tk, entry, today):
    if entry["Category"] not in CATEGORIES:
        return False, f"INVALID_CATEGORY ({entry['Category']})"
    payload = {
        "parent": {"database_id": DB_ID},
        "properties": {
            "Name": {"title": [{"text": {"content": entry["Name"]}}]},
            "Date": {"date": {"start": today}},
            "Category": {"select": {"name": entry["Category"]}},
            "Summary": {"rich_text": [{"text": {"content": entry["Summary"]}}]},
            "URL": {"url": entry.get("URL")},
        },
    }
    with open("/tmp/notion_entry.json", "w") as f:
        json.dump(payload, f, ensure_ascii=False)
    try:
        resp = json.loads(
            _curl(tk, [
                "-X", "POST", f"{NOTION_API}/pages",
                "-H", "Content-Type: application/json",
                "-d", "@/tmp/notion_entry.json",
            ])
        )
    except Exception as e:
        return False, f"PARSE_ERROR ({e})"
    if resp.get("object") == "page":
        return True, resp.get("id", "")
    return False, resp.get("message", "unknown")[:120]


# Edit this list with the week's learning entries. Each entry is a dict with:
#   Name (str, required)    - Title, concise topic name
#   Category (str, required) - One of CATEGORIES
#   Summary (str, required) - 1-2 sentence core takeaway
#   URL (str, optional)     - Reference link
ENTRIES = [
    {
        "Name": "Tistory 175~177차: 1회 컷 57회째 + CJK 0건 65회 연속 안정화",
        "Category": "Automation",
        "Summary": "175차(노르웨이 AI 금지), 177차(sheger.io 사기 미래) 등 긱뉴스 본문 5,000~7,000자 + 정량 다수 분기에서 H2 7~8개 + 비교표 1~3개 + 1회 컷 누적 57회째. --record 19회째, --record-topic 50회째, Picsum ID 결정성 + CDN 2/2 안정.",
        "URL": "https://sigco.tistory.com/810",
    },
    {
        "Name": "Tistory 171차 clutio.com: Next.js SPA body 풍부 케이스",
        "Category": "Automation",
        "Summary": "긱뉴스 본문 961자 + clutio.com 직접 fetch 14,420자 풍부. 170차 cursor.com(JS bundle 추출 필요)과 달리 Next.js SPA지만 body 텍스트가 풍부하면 JS bundle 추출 불필요. 분기 판별: body 텍스트 길이 우선.",
        "URL": "https://sigco.tistory.com/797",
    },
    {
        "Name": "지식 그래프 자동화: 6/16→6/20 노드 952→971, GitHub Pages 배포 자동화",
        "Category": "Infra",
        "Summary": "knowledge-graph 크론이 6개 Notion DB에서 90일 데이터 수집, 엔티티/관계 추출, 인터랙티브 HTML 생성 후 GitHub Pages 자동 배포까지 한 번에 처리. 6/16 952 노드/8,260 연결 → 6/20 971 노드/8,436 연결로 점진 성장. invest_memo DB는 두 차례 모두 404.",
    },
    {
        "Name": "iOS Trend: Apple Developer News 직접 fetch로 105개 article 파싱 성공",
        "Category": "iOS/Swift",
        "Summary": "ios-trend-digest 6/19 실행에서 developer.apple.com/news 직접 fetch → 105개 article 파싱 → Notion 7/7 기록. 브라질 iOS 변경(CADE 합의, Attachment 12), iOS 27 Foundation Models API, ImageCreator deprecation, iOS 26.6 베타 등 6/8~6/18 7건 트렌드 추출.",
    },
    {
        "Name": "NotebookLM 후보 cron: ===== NOTEBOOKLM후보 ===== 마커 함정",
        "Category": "Automation",
        "Summary": "크론 프롬프트의 마커는 텔레그램 전송 실패 시에만 출력됨. 텔레그램 1차 성공 시 마커 부재 → '마커 없으면 SILENT'로 오해하기 쉬움. 실제 의도는 '후보 12개를 final response로 사용자에게 전달'이므로 final response에 후보 표 출력 필수. 보안 가드(approval prompt)는 cron에서 무시 가능.",
    },
    {
        "Name": "weekly-automation-report 번들 스크립트 2건 f-string syntax error 발견",
        "Category": "Infra",
        "Summary": "notion_preflight.py / post_weekly_entries.py 모두 `f'Authorization: Bearer *** + tk,` 형태로 닫는 따옴표+콤마 누락 → SyntaxError. session-mining 가이드 §7.4와 일치하는 known 함정. urllib.request 기반 우회 스크립트로 본 작업 수행. 다음 세션에서 skill patch 필요.",
    },
]


def main():
    if not os.path.exists(TK_PATH):
        print("NOTION_TOKEN_MISSING:", TK_PATH)
        return 1
    with open(TK_PATH) as f:
        tk = f.read().strip()

    if not check_token(tk):
        print("NOTION_TOKEN_INVALID - reissue integration at notion.so/my-integrations")
        return 2

    today = today_kst()
    print(f"[{today}] Posting {len(ENTRIES)} entries to Notion DB...")

    success, failed = 0, 0
    for entry in ENTRIES:
        ok, detail = post_entry(tk, entry, today)
        marker = "OK" if ok else "FAIL"
        print(f"  {marker} [{entry['Category']}] {entry['Name']} -> {detail}")
        if ok:
            success += 1
        else:
            failed += 1

    print(f"\n=== Summary ===\nSuccess: {success}/{len(ENTRIES)}\nFailed: {failed}\nDate: {today}")
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
