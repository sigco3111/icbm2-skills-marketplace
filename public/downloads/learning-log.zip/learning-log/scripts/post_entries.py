#!/usr/bin/env python3
"""learning-log Notion DB writer.

Posts weekly learning entries to Notion DB (33c76f2e-9097-8184-b51e-fa09efcf6d4d).
Edit the `ENTRIES` list with this week's learnings, then run:

    python3 scripts/post_entries.py

The script pre-validates the Notion token via GET /v1/users/me before
posting, and gracefully reports each entry's success/failure with a final
summary line.
"""
import os
import json
import subprocess
import sys
from datetime import datetime, timezone, timedelta

TK_PATH = os.path.expanduser("~/.hermes/secrets/notion_token.txt")
DB_ID = "33c76f2e-9097-8184-b51e-fa09efcf6d4d"
NOTION_API = "https://api.notion.com/v1"
NOTION_VERSION = "2022-06-28"
CATEGORIES = ["iOS/Swift", "AI/ML", "Automation", "Infra", "Other"]


def today_kst() -> str:
    return datetime.now(timezone(timedelta(hours=9))).strftime("%Y-%m-%d")


def _curl(tk, args):
    """Run curl with bearer token injected as a separate -H arg (no shell, no $var).

    CRITICAL: Do NOT use shell=True with `Authorization: Bearer $NTK` as a
    string literal. Two failure modes observed on 2026-06-14 cron run:
      1) Pre-check via shell-string form returned {"object":"user"} (looked
         fine), but the subsequent POST returned "API token is invalid" for
         ALL 6 entries. Root cause: shell-string + env-var expansion is
         inconsistent between GET and POST in tirith/cron context — the
         header reached curl as a literal $NTK in the GET but the POST was
         token-stripped.
      2) Same problem recurs in cron mode for any skill that posts to Notion.

    Fix: pass args as a Python list to subprocess.run, build the header as a
    single string, hand it to curl as a discrete -H arg. No shell, no env var.
    """
    auth_header = f"Authorization: Bearer {tk}"
    return subprocess.run(
        ["curl", "-s", "--max-time", "20", *args,
         "-H", auth_header,
         "-H", f"Notion-Version: {NOTION_VERSION}"],
        capture_output=True, text=True
    ).stdout


def check_token(tk):
    """Validate token via /v1/users/me. Returns True if valid."""
    try:
        resp = json.loads(_curl(tk, ["-X", "GET", f"{NOTION_API}/users/me"]))
        return resp.get("object") == "user"
    except Exception:
        return False


def post_entry(tk, entry, today):
    if entry["Category"] not in CATEGORIES:
        return False, f"INVALID_CATEGORY ({entry['Category']})"
    payload = {
        "parent": {"database_id": DB_ID},
        "properties": {
            "Name": {"title": [{"text": {"content": entry["Name"]}}]},
            "Date": {"date": {"start": today}},
            "Category": {"select": {"name": entry["Category"]}},
            "Summary": {"rich_text": [{"text": {"content": entry["Summary"]}}]},
            "URL": {"url": entry.get("URL")},
        },
    }
    with open("/tmp/notion_entry.json", "w") as f:
        json.dump(payload, f, ensure_ascii=False)
    try:
        resp = json.loads(
            _curl(tk, [
                "-X", "POST", f"{NOTION_API}/pages",
                "-H", "Content-Type: application/json",
                "-d", "@/tmp/notion_entry.json",
            ])
        )
    except Exception as e:
        return False, f"PARSE_ERROR ({e})"
    if resp.get("object") == "page":
        return True, resp.get("id", "")
    return False, resp.get("message", "unknown")[:120]


# Edit this list with the week's learning entries. Each entry is a dict with:
#   Name (str, required)    - Title, concise topic name
#   Category (str, required) - One of CATEGORIES
#   Summary (str, required) - 1-2 sentence core takeaway
#   URL (str, optional)     - Reference link
ENTRIES = [
    {
        "Name": "tistory-publisher 320~323차 — zombie 302 만료 + owner 수동 회복 + §3.8.1 가드 정형화",
        "Category": "Automation",
        "Summary": "W30(7/20~7/26) tistory-publisher 4건 중 320차 zombie 302 (하루 만에 18일→36시간으로 만료 주기 급격히 단축) + 322차 owner 5개 키 수동 paste (REACTION_GUEST/TSSESSION/_T_ANO 진짜 hash, __T_/__T_SECURE=1 fallback) + 323차 #1100 정상 발행 + 323차 #1101 신호 4 오탐 disambiguate 25연속 확정. verify-tistory-cookie.sh step [3] env 값-모양 hardcode false-positive 패치 완료 (REACTION_GUEST/__T_/__T_SECURE 3건은 LENGTH 미검증 + INFO 출력만, TSSESSION/_T_ANO만 LENGTH 검증, verdict RECOVERED 분기 추가). 만료 추이 5단계: 18일(7/24) → 36시간(7/26) → 매번 owner 수동 회복 패턴 정형화. 연속 all-green 100+회차 유지.",
        "URL": "https://sigco.tistory.com/1101",
    },
    {
        "Name": "NotebookLM 7/25 4개 노트북 생성 + 검토 데이터 날짜 가드 — selection_numbers 2/5/8/10 gold 패턴",
        "Category": "Automation",
        "Summary": "7/25 19:22 NotebookLM 4개 노트북 생성 (Claude 5 컨텍스트엔지니어링 / OpenAI-Anthropic 오픈웨이트 공동성명 / Show GN ADHDev / +1) + 7/26 08:18~20:37 검토 데이터 12개 date_uploaded 가드 사건. 텔레그램 12개 후보 중 8번까지만 표시되고 10번 잘림 → selection.json에서 12개 후보 풀 확인 후 [2,5,8,10] selection_numbers 수동 패치. 검토 데이터 4개 다 생성 후 '업로드' 1단어 (readiness probe 신호) → 자동 업로드 단계. date_uploaded 가드는 8/6 6:09 → 7/28 14:19 / 7/28 13:44 등 미래→과거 보정 사이클 — owner gate 시 1회 보정.",
    },
    {
        "Name": "GitFut Scout 5장 칸반 위임 — score 71→69 분석 + sigco3111 OVR 전략 정형화",
        "Category": "AI/ML",
        "Summary": "7/24 gitfut.com/sigco3111 점수 71→69 하락 분석 결과 SHO/DEF -2 (follower 110 baseline 영향 추정). 5장 카드를 gitfut-scout 격리 보드(별도 workspacce)에 동시 dispatch: (1) daily-scout NDJSON 자동 측정, (2) score_diff.py + 스킬 패키지, (3) daily-gitfut-scout cron 등록, (4) weekly-tech-digest sigco 채널 확장, (5) PR 본문 자동 초안. Node compute.js + Python calc_ovr.py 양방향 동일 결과 (OVR 69 / Playmaker CAM / PAC 76 DRI 80 SHO 65 DEF 51 PAS 62 PHY 72) 환산 검증. 카운터팩추얼 followers 50: 69→72 (+3) 시뮬. 외부 점수 진단 정형화 skill: external-score-diagnosis + gitfut-scout-sim (lib/scoring/engine.ts verbatim 포팅).",
    },
    {
        "Name": "snkrx-web Phase 4-5 8장 위임 사이클 — TDZ 회귀 + chain-follower spec 충돌 + 적 HP 5배 버그픽스",
        "Category": "Other",
        "Summary": "7/23 snkrx-web 칸반 8장 사이클: Phase 2-c discrete cell vs chain-follower spec 충돌 → B 채택 (chain-follower, spacing = TILE × 1.75) / Phase 4-3 Wave manager (commit 402543b, 1→2→3→4 spawn, 22/22 테스트) / Phase 4 TDZ ReferenceError 회귀 (waveManager 선언 위치) / Phase 4-4 snake HP HUD (commit aef29cb, 0.5초 무적, GAME OVER, 30/30 테스트) / Phase 5 7장 위임 (Camera/FX/Spawn/Shader/Lv.3/Slow/UI) + 사운드 위임 보완 / Phase 4-4 bugfix 적 HP 5~10배 + projectile 5. 디버깅·롤백 선호 (2026-07-23 신규): 패치 누적 → 안 풀리면 즉시 롤백, 다시 순차 진단. 시각 검증 필요 시 사용자 OK 신호 후 Done.",
    },
    {
        "Name": "Hermes M1 Mac mini 텔레그램 연동 가이드 md — 자동위임 cross-machine 디버깅 사례",
        "Category": "Infra",
        "Summary": "7/22 12:33~17:13 desktop 세션: M1 Mac mini에서 Hermes 설치 + Telegram 연동 실패 디버깅 → ~/.hermes/logs/gateway-stdout.log, gateway-stderr.log, agent.log, errors.log 4종에서 cross-machine 위임 추적. M1 → M4 동일 네트워크의 Hermes 설정을 그대로 복사하지 말 것 (API 키 / 봇 토큰 / 프로필 / 사용자 승인 정보 별도). 2026-07-22 15:51 deleg_525e20d8 bytepath-ex subagent 위임 (session 20260722_155110_b69124) 60s timeout + '&' backgrounding 패턴 보안 차단 사례. hermes kanban list/stats/runs/log/tail + delegate_task 추적 명령 5종 정형화. 결과: ~30KB M1 Mac mini 설정 가이드 md 다운로드 폴더에 생성.",
    },
    {
        "Name": "cron 7/25 self-review — Tistory 세션 체크 잡 provider drift + self-healer FP 1건",
        "Category": "Infra",
        "Summary": "7/25 22:00 일일 자기 개선 리뷰: 학습 승격 0건 / 반복 피드백 0건 / 모니터 17 정상 0 경고 1 치명 / self-healer 0 errors 2 warnings 1 fix FP. 🔴 Tistory 세션 체크 잡이 provider 변경 (minimax → minimax-oauth)으로 실행 차단됨 — 잡이 명시적으로 provider/model 고정되지 않아 보호 로직이 실행 중단. hermes cron edit 옵션에 provider/model 고정 미노출 → 이번 리뷰는 설정 임의 변경 안 함. 다음 owner gate: (1) 잡 현재 provider/model 명시 고정, (2) 다음 실행 결과 확인, (3) 세션 만료 + 출력 분석 정상 재검증. 🔴 self-healer 종료 검증 1/4 jobs FP 1건 — cron output 마스킹은 해결, self-healer 내부 오탐 검증 항목 1건 별도 조사 필요. MEMORY.md 3,711 bytes (90% 초과).",
    },
    {
        "Name": "PixiJS v8 PixiJS 8.6 + snkrx Phase 5 7장 위임 — Audio Asset Bundling + GC 트랩",
        "Category": "iOS/Swift",
        "Summary": "7/23~7/24 PixiJS v8 SNKRX 클론 Phase 5 7장 worker 동시 위임: Camera (충돌 방지 우선순위) / FX (particles 효율) / Spawn (wave 1→2→3→4 사이클) / Shader (glow) / Lv.3 (레벨업) / Slow (시간 슬로우) / UI (HUD). commit 402543b (Phase 4-3) + aef29cb (Phase 4-4) 정착. PixiJS 8.6 정석 부팅 패턴: `Assets.load(url)` → `loadOptional` → Image/ImageData 우회 (GC 트랩 회피). 음소거 시 사운드 자원이 PIXI.sound.cache에 남아 메모리 누적 → 명시적 destroy() 필수. HMR 캐시 무효화는 Shift+Cmd+R. MSG `AudioAsset`은 pak 파일 형식 권장 (Tauri / asar 압축). 시각 검증 필요 시 (1) 광범위 로깅 먼저 (2) hermes skills search+install (3) PixiJS 8.6 시멘틱 버전별 변경점 검색.",
    },
]


def main():
    if not os.path.exists(TK_PATH):
        print("NOTION_TOKEN_MISSING:", TK_PATH)
        return 1
    with open(TK_PATH) as f:
        tk = f.read().strip()

    if not check_token(tk):
        print("NOTION_TOKEN_INVALID - reissue integration at notion.so/my-integrations")
        return 2

    today = today_kst()
    print(f"[{today}] Posting {len(ENTRIES)} entries to Notion DB...")

    success, failed = 0, 0
    for entry in ENTRIES:
        ok, detail = post_entry(tk, entry, today)
        marker = "OK" if ok else "FAIL"
        print(f"  {marker} [{entry['Category']}] {entry['Name']} -> {detail}")
        if ok:
            success += 1
        else:
            failed += 1

    print(f"\n=== Summary ===\nSuccess: {success}/{len(ENTRIES)}\nFailed: {failed}\nDate: {today}")
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
