#!/usr/bin/env python3
"""learning-log Notion DB writer.

Posts weekly learning entries to Notion DB (33c76f2e-9097-8184-b51e-fa09efcf6d4d).
Edit the `ENTRIES` list with this week's learnings, then run:

    python3 scripts/post_entries.py

The script pre-validates the Notion token via GET /v1/users/me before
posting, and gracefully reports each entry's success/failure with a final
summary line.
"""
import os
import json
import subprocess
import sys
from datetime import datetime, timezone, timedelta

TK_PATH = os.path.expanduser("~/.hermes/secrets/notion_token.txt")
DB_ID = "33c76f2e-9097-8184-b51e-fa09efcf6d4d"
NOTION_API = "https://api.notion.com/v1"
NOTION_VERSION = "2022-06-28"
CATEGORIES = ["iOS/Swift", "AI/ML", "Automation", "Infra", "Other"]


def today_kst() -> str:
    return datetime.now(timezone(timedelta(hours=9))).strftime("%Y-%m-%d")


def _curl(tk, args):
    """Run curl with bearer token injected as a separate -H arg (no shell, no $var).

    CRITICAL: Do NOT use shell=True with `Authorization: Bearer $NTK` as a
    string literal. Two failure modes observed on 2026-06-14 cron run:
      1) Pre-check via shell-string form returned {"object":"user"} (looked
         fine), but the subsequent POST returned "API token is invalid" for
         ALL 6 entries. Root cause: shell-string + env-var expansion is
         inconsistent between GET and POST in tirith/cron context — the
         header reached curl as a literal $NTK in the GET but the POST was
         token-stripped.
      2) Same problem recurs in cron mode for any skill that posts to Notion.

    Fix: pass args as a Python list to subprocess.run, build the header as a
    single string, hand it to curl as a discrete -H arg. No shell, no env var.
    """
    auth_header = f"Authorization: Bearer {tk}"
    return subprocess.run(
        ["curl", "-s", "--max-time", "20", *args,
         "-H", auth_header,
         "-H", f"Notion-Version: {NOTION_VERSION}"],
        capture_output=True, text=True
    ).stdout


def check_token(tk):
    """Validate token via /v1/users/me. Returns True if valid."""
    try:
        resp = json.loads(_curl(tk, ["-X", "GET", f"{NOTION_API}/users/me"]))
        return resp.get("object") == "user"
    except Exception:
        return False


def post_entry(tk, entry, today):
    if entry["Category"] not in CATEGORIES:
        return False, f"INVALID_CATEGORY ({entry['Category']})"
    payload = {
        "parent": {"database_id": DB_ID},
        "properties": {
            "Name": {"title": [{"text": {"content": entry["Name"]}}]},
            "Date": {"date": {"start": today}},
            "Category": {"select": {"name": entry["Category"]}},
            "Summary": {"rich_text": [{"text": {"content": entry["Summary"]}}]},
            "URL": {"url": entry.get("URL")},
        },
    }
    with open("/tmp/notion_entry.json", "w") as f:
        json.dump(payload, f, ensure_ascii=False)
    try:
        resp = json.loads(
            _curl(tk, [
                "-X", "POST", f"{NOTION_API}/pages",
                "-H", "Content-Type: application/json",
                "-d", "@/tmp/notion_entry.json",
            ])
        )
    except Exception as e:
        return False, f"PARSE_ERROR ({e})"
    if resp.get("object") == "page":
        return True, resp.get("id", "")
    return False, resp.get("message", "unknown")[:120]


# Edit this list with the week's learning entries. Each entry is a dict with:
#   Name (str, required)    - Title, concise topic name
#   Category (str, required) - One of CATEGORIES
#   Summary (str, required) - 1-2 sentence core takeaway
#   URL (str, optional)     - Reference link
ENTRIES = [
    {
        "Name": "tistory-publisher 350~352차 — #1171 Chrome-AI + #1173 가짜 저자 + 함정 30 (write_file 빌드 스크립트 PYEOF_MARKER 잔재)",
        "Category": "Automation",
        "Summary": "W31(7/27~8/2) tistory-publisher 3차: 350차(8/1 05:01) FlowCraft 메타프롬프트 그래프 #1170 / 351차(8/1 22:01) #1171 Chrome AI 보안 엔지니어링 (gn=32019, 1,800자) — 연속 all-green 125회차 / 352차(8/2 05:01) #1173 가짜 저자 학회 남용 (gn=32039, 2,420자, 6종 빌드 검증 통과). 🆕 함정 30 (write_file 빌드 스크립트 PYEOF_MARKER 잔재): write_file로 /tmp/build_post_NNN.py 작성 시 본문 끝에 heredoc 종료 표식(PYEOF_MARKER/PYEOF/EOF)이 placeholder로 남아 `NameError` 빌드 실패 → 절대 포함 금지. 352차 19:00~20:00 §3.8.1 zombie 302 감지 → publish 단계 skip (Zombie 가드 정형). parts.append() 33건 정상 / §3.5 3중 신호 일치 OK / by_category 영구 잔존 56차 누적.",
        "URL": "https://sigco.tistory.com/1173",
    },
    {
        "Name": "NotebookLM 8/2 8/8 업로드 + download video path 함정 (CLI가 path 인자 무시)",
        "Category": "Automation",
        "Summary": "8/2 NotebookLM 후보 12개 중 [2, 4, 6, 10] 선택 → 노트북 4개 생성 + 비디오 오버뷰 4개 completed → 업로드 8건 (일반 4 + 숏츠 4) 모두 성공. 🆕 함정 (download video --notebook <id> <path>): CLI가 path 인자 무시하고 ~/$Flint_*.mp4 등에 자동 저장 → /tmp/icbm_notebooklm/videos/ mv 후 ffprobe 검증 + selection.json selected[]에 nb_id/file/number 박기. review skip 최적화: 4개 이하 + 모두 completed 시 사용자 '업로드' 1라운드에 본 업로드 자동 진행. 일반 1080p 본편 + 숏츠 9:16 59초 Letterbox 모두 정상. yt URL 8개: Lk8TjG6OP6I / hcHMSFgVkiM / MzUv3cK3OUs / eqWlp3EML1M / SilZbDZCTO0 / DT2GFGxBCkw / gE3ahMu8cCA / ozsBBHINb-I.",
    },
    {
        "Name": "W31 sigco3111 비공개 README 41개 푸시 + IsoMapTool 공개 — 빌드 산출물 .gitignore 정형화",
        "Category": "Other",
        "Summary": "7/31 sigco3111-private-projects 41개 비공개 repo 푸시 (Mobile 31 + NDS 4 + Bada 4 + iOS 1 + Android 1, 1,374MB, 64,300 파일) → IsoMapTool 2003 VC++ 6.0 MFC 공개 repo (https://github.com/sigco3111/IsoMapTool, README 25.6KB, 43 파일, 348K). 3차 푸시 (검색 URL 123개) → 무관한 검색 페이지 URL 자동 채워짐 → 롤백 → 평균 9KB 상태로 복귀. 패턴 정착: .gitignore로 .obj/.sbr/.pch/.pdb/.idb/.exe/.bsc + BackUp ZIP + VC 워크스페이스 캐시 (.opt/.ncb/.suo/.clw/.plg/.aps/.positions) 자동 차단 → .large_files_excluded/ 원본 보존. README 템플릿: shields.io 헤더 + 작업 사본 코드 분석 → 영문/한글 + 18단계 백업 히스토리.",
    },
    {
        "Name": "W31 일요일 학습 log cron — verify_post_entries_patch.py 14/14 통과 + f-string 46번 줄 사전 검증 정형",
        "Category": "Infra",
        "Summary": "W31(8/2) 일요일 학습 log cron: 7개 학습 항목 → scripts/post_entries.py 사전 검증 (ast.parse + 46번 줄 f-string Bearer {tk} syntax fix + script imports + _curl/post_entry/check_token/today_kst + GET /v1/users/me object=user + POST/PATCH archive roundtrip + ENTRIES list sanity 6종) 14/14 PASS. 실전 패턴: persisted-output 100~570KB일 때 session_id/when/title 3개 필드만 추출해 컨텍스트 5KB 이하로 10+ 세션 식별. W31 cron 잡 식별: b1bca63a(tistory 06~22), d7bd4309(일요일 15:30 점검), 7995f1387b79(weekly-tech-digest 일요일 16:00 보류), dc9a2e6aaaaa(NotebookLM 후보 일요일 16:00), 0f893ba14797(매일 14:00 정리), 582ecc59aaee(10:00 벤치마크), e0ba30d8a122(매시 30분 에러).",
    },
    {
        "Name": "W31 weekly-tech-digest + tistory 293차 §3.11/§4 SSOT drift 3종 — details 누락 + last_published_id mismatch",
        "Category": "Automation",
        "Summary": "W31(7/27~8/2) weekly-tech-digest W29 누적 13번째 skip (W21/W24/W26/W27 모두 B 등급 발행 유지). tistory 293차에서 §3.11/§4 SSOT drift 3종 발견: (1) run_pipeline()이 publish 안 하고 status=ready까지만 → cron이 별도 tistory_publisher.py 호출 검증 필요, (2) blog_pipeline_state.json details 마지막 entry가 stale + 실제 Tistory 글은 발행됨 → details append 누락 drift, (3) last_published_id vs last_published_url mismatch. SSOT 임의 보정은 사용자 확인 후에만 (cron 패치 보류). 통계 total=167→352차 167, today={AI/ML:1}, by_category[\"1219746\"]=1 영구 잔존 56차 누적 (297→352).",
    },
    {
        "Name": "W31 PixiJS v8 SNKRX Phase 6 + Hermes 부팅 환경 점검 — 대규모 빌드 스크립트 write_file 안전 패턴",
        "Category": "iOS/Swift",
        "Summary": "W31 SNKRX PixiJS v8 클론: PixiJS 8.6 부팅 패턴 (Assets.load → loadOptional → Image/ImageData 우회 GC 트랩 회피), Phase 6 추가 위임 사이클 진행 (Camera/FX/Spawn/Shader/Lv.3/Slow/UI 7장 + 사운드 보완). Hermes 환경 점검: cron self-healer FP 1건 (4 잡 중 1 종료 검증 오탐) — cron output 마스킹은 해결, self-healer 내부 검증 1건 별도 조사. W31 신규 함정 30 패턴이 다른 큰 빌드 스크립트 작성 워크플로우에도 적용 (write_file 안전 패턴 + heredoc 종료 표식 잔재 금지). HMR 캐시 무효화는 Shift+Cmd+R. 픽셀아트 SNKRX 검증은 사용자 OK 신호 후 Done.",
    },
    {
        "Name": "W31 자동위임 + cron 잡 provider/model 보호 로직 보강 — Tistory 세션 체크 잡 차단 사례",
        "Category": "Infra",
        "Summary": "W31 자동위임 cross-machine 사례: Tistory 세션 체크 잡(0b0e9f44e10a)이 provider 변경 (minimax → minimax-oauth)으로 실행 차단됨 — 잡이 명시적으로 provider/model 고정되지 않아 보호 로직 중단. hermes cron edit 옵션에 provider/model 고정 미노출 → 이번 리뷰는 설정 임의 변경 안 함. 다음 owner gate: (1) 잡 현재 provider/model 명시 고정, (2) 다음 실행 결과 확인, (3) 세션 만료 + 출력 분석 정상 재검증. self-healer 모니터 17 정상 0 경고 1 치명. MEMORY.md 2,130/2,200 chars (96%, 1주 위험). ssh multi-machine 워크플로우 외부 SSH 키 회전 정형화.",
    },
]  


def main():
    if not os.path.exists(TK_PATH):
        print("NOTION_TOKEN_MISSING:", TK_PATH)
        return 1
    with open(TK_PATH) as f:
        tk = f.read().strip()

    if not check_token(tk):
        print("NOTION_TOKEN_INVALID - reissue integration at notion.so/my-integrations")
        return 2

    today = today_kst()
    print(f"[{today}] Posting {len(ENTRIES)} entries to Notion DB...")

    success, failed = 0, 0
    for entry in ENTRIES:
        ok, detail = post_entry(tk, entry, today)
        marker = "OK" if ok else "FAIL"
        print(f"  {marker} [{entry['Category']}] {entry['Name']} -> {detail}")
        if ok:
            success += 1
        else:
            failed += 1

    print(f"\n=== Summary ===\nSuccess: {success}/{len(ENTRIES)}\nFailed: {failed}\nDate: {today}")
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
