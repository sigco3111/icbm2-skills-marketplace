#!/usr/bin/env python3
"""learning-log Notion DB writer.

Posts weekly learning entries to Notion DB (33c76f2e-9097-8184-b51e-fa09efcf6d4d).
Edit the `ENTRIES` list with this week's learnings, then run:

    python3 scripts/post_entries.py

The script pre-validates the Notion token via GET /v1/users/me before
posting, and gracefully reports each entry's success/failure with a final
summary line.
"""
import os
import json
import subprocess
import sys
from datetime import datetime, timezone, timedelta

TK_PATH = os.path.expanduser("~/.hermes/secrets/notion_token.txt")
DB_ID = "33c76f2e-9097-8184-b51e-fa09efcf6d4d"
NOTION_API = "https://api.notion.com/v1"
NOTION_VERSION = "2022-06-28"
CATEGORIES = ["iOS/Swift", "AI/ML", "Automation", "Infra", "Other"]


def today_kst() -> str:
    return datetime.now(timezone(timedelta(hours=9))).strftime("%Y-%m-%d")


def _curl(tk, args):
    """Run curl with bearer token injected as a separate -H arg (no shell, no $var).

    CRITICAL: Do NOT use shell=True with `Authorization: Bearer $NTK` as a
    string literal. Two failure modes observed on 2026-06-14 cron run:
      1) Pre-check via shell-string form returned {"object":"user"} (looked
         fine), but the subsequent POST returned "API token is invalid" for
         ALL 6 entries. Root cause: shell-string + env-var expansion is
         inconsistent between GET and POST in tirith/cron context — the
         header reached curl as a literal $NTK in the GET but the POST was
         token-stripped.
      2) Same problem recurs in cron mode for any skill that posts to Notion.

    Fix: pass args as a Python list to subprocess.run, build the header as a
    single string, hand it to curl as a discrete -H arg. No shell, no env var.
    """
    auth_header = f"Authorization: Bearer {tk}"
    return subprocess.run(
        ["curl", "-s", "--max-time", "20", *args,
         "-H", auth_header,
         "-H", f"Notion-Version: {NOTION_VERSION}"],
        capture_output=True, text=True
    ).stdout


def check_token(tk):
    """Validate token via /v1/users/me. Returns True if valid."""
    try:
        resp = json.loads(_curl(tk, ["-X", "GET", f"{NOTION_API}/users/me"]))
        return resp.get("object") == "user"
    except Exception:
        return False


def post_entry(tk, entry, today):
    if entry["Category"] not in CATEGORIES:
        return False, f"INVALID_CATEGORY ({entry['Category']})"
    payload = {
        "parent": {"database_id": DB_ID},
        "properties": {
            "Name": {"title": [{"text": {"content": entry["Name"]}}]},
            "Date": {"date": {"start": today}},
            "Category": {"select": {"name": entry["Category"]}},
            "Summary": {"rich_text": [{"text": {"content": entry["Summary"]}}]},
            "URL": {"url": entry.get("URL")},
        },
    }
    with open("/tmp/notion_entry.json", "w") as f:
        json.dump(payload, f, ensure_ascii=False)
    try:
        resp = json.loads(
            _curl(tk, [
                "-X", "POST", f"{NOTION_API}/pages",
                "-H", "Content-Type: application/json",
                "-d", "@/tmp/notion_entry.json",
            ])
        )
    except Exception as e:
        return False, f"PARSE_ERROR ({e})"
    if resp.get("object") == "page":
        return True, resp.get("id", "")
    return False, resp.get("message", "unknown")[:120]


# Edit this list with the week's learning entries. Each entry is a dict with:
#   Name (str, required)    - Title, concise topic name
#   Category (str, required) - One of CATEGORIES
#   Summary (str, required) - 1-2 sentence core takeaway
#   URL (str, optional)     - Reference link
ENTRIES = [
    {
        "Name": "Tistory 248~250차 35회 연속 all-green — §3.34.43/42/41/40 4개 함정 영구 보강",
        "Category": "Automation",
        "Summary": "W28(7/10~7/12) tistory-publisher가 248차(Codeberg)/249차(AI 스크레이퍼)/250차(SpaceX Starlink) 3건 정상 발행 + §3.5 5중 신호 일치 + cleanup cron 임무 #16 dry-run 35회 연속 all-green. §3.34.43(env -i bash 자동 cd → PWD 보강), §3.34.42(verify-tistory-cookie 격리 함정), §3.34.41(f-string 백슬래시 quote → string concat), §3.34.40(FRESH 4-field 매칭) 4개 함정 SKILL.md에 영구 보강 완료.",
        "URL": "https://sigco.tistory.com/974",
    },
    {
        "Name": "weekly-tech-digest W27 발행 #976 — 누적 13회째 B/61점 5중 신호 일치",
        "Category": "Automation",
        "Summary": "7/12 16:04 cron이 W27 뉴스레터 발행 (https://sigco.tistory.com/976). 본문 12,546자/HTML 14,733자, H2 6 + H3 33 + p 68, B 등급 61점 decision=pass, §3.5 5중 신호 5/5 일치, weekly_newsletter_state.json 누적 13회째(W17→W27), Picsum ID 432/85 결정성 유지. 가짜 발행 가드 정상.",
        "URL": "https://sigco.tistory.com/976",
    },
    {
        "Name": "toss-trader v1.4.2 캔들 정규화 — 토스 Open API 응답 4가지 차이 동시 fix",
        "Category": "Other",
        "Summary": "7/10 v1.4.2 (커밋 015e5e5)에서 lib/candles.ts의 normalizeCandles()가 실제 토스 Open API 응답 미처리 문제 fix: 필드명(openPrice vs open)·가격 타입(string vs number)·timestamp(ISO vs epoch)·envelope(result.candles)·정렬(newest-first→oldest-first) 5가지 차이 한 번에 보정. 144/144 unit + 13/13 e2e chromium PASS. TDD 함정 학습: 테스트가 인터페이스 형태로 mock하면 false GREEN — 실제 API 응답 mock 필수.",
    },
    {
        "Name": "NotebookLM 8/8 업로드 + W28 4개 노트북 — gold #28/#41/#44 패턴 정착",
        "Category": "Automation",
        "Summary": "7/10 NotebookLM 파이프라인: 6개 노트북 중 2개 영상 생성 실패 → 실패분 skipped 영속화(gold #44) 후 성공 4개만 업로드로 8/8(일반 4 + Shorts 4) YouTube 업로드. cleanup 시 성공 4개 삭제 + 실패 2개 보존(gold #11+#28). 7/12 cron dc9a2e6aaaaa가 W28 후보 12개 정상 전송. 7/11 텔레그램 self-test bot 응답 검증.",
    },
    {
        "Name": "Telegram 게이트웨이 워커 polling conflict — HERMES_TELEGRAM_DISABLE_FALLBACK=1 patch",
        "Category": "Infra",
        "Summary": "7/12 08:22 데스크탑 세션에서 텔레그램 봇 무반응 진단 → getUpdates 409 Conflict가 워커 정상 polling 신호임을 확인, sticky fallback 카운트 일시적 증가(176→201)는 부팅 1회분 자연 결과. plist에 HERMES_TELEGRAM_DISABLE_FALLBACK=1 환경변수 추가 + plugins/telegram/telegram_network.py 2줄 patch(discover_fallback_ips() early-return []). 5분 후 사용자 메시지 정상 응답 복구.",
    },
    {
        "Name": "learning-log verify_post_entries_patch.py 영구화 — 이번 cron 14/14 통과 입증",
        "Category": "Infra",
        "Summary": "7/5 cron에서 scripts/post_entries.py 46번 줄 f-string SyntaxError 재발한 함정을 사전 차단하기 위해 verify_post_entries_patch.py 신규 (ast.parse + line 46 form check + module import + Notion preflight + POST/PATCH archive roundtrip 5종 14 체크). 7/12 이번 cron에서 14/14 통과 — verify가 만든 임시 테스트 page는 archived=True 자동 정리. 사전 검증 단계(0단계)는 SKILL.md 실행 절차에 영구 포함.",
    },
    {
        "Name": "agent-benchmark-tracker W28 — benchlm.ai 단일 fetch로 12개 벤치마크 POST",
        "Category": "AI/ML",
        "Summary": "7/12 10:04 agent-benchmark-tracker 주간 cron이 benchlm.ai 1회 fetch로 AI 모델 리더보드 12개 신규 벤치마크 POST. Sakana Fugu Ultra(GPQA 95.5% #1 + LiveCodeBench 93.2% #2) 일본산 첫 90%대, DeepSeek V4 Pro Max(LiveCodeBench 93.5% #1), Qwen3.7 Max(LiveCodeBench 91.6% #3 + MMLU-Pro 89.6% #1) 더블 톱. DB 125→137 누적.",
    },
]


def main():
    if not os.path.exists(TK_PATH):
        print("NOTION_TOKEN_MISSING:", TK_PATH)
        return 1
    with open(TK_PATH) as f:
        tk = f.read().strip()

    if not check_token(tk):
        print("NOTION_TOKEN_INVALID - reissue integration at notion.so/my-integrations")
        return 2

    today = today_kst()
    print(f"[{today}] Posting {len(ENTRIES)} entries to Notion DB...")

    success, failed = 0, 0
    for entry in ENTRIES:
        ok, detail = post_entry(tk, entry, today)
        marker = "OK" if ok else "FAIL"
        print(f"  {marker} [{entry['Category']}] {entry['Name']} -> {detail}")
        if ok:
            success += 1
        else:
            failed += 1

    print(f"\n=== Summary ===\nSuccess: {success}/{len(ENTRIES)}\nFailed: {failed}\nDate: {today}")
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
