#!/usr/bin/env python3
"""learning-log Notion DB writer.

Posts weekly learning entries to Notion DB (33c76f2e-9097-8184-b51e-fa09efcf6d4d).
Edit the `ENTRIES` list with this week's learnings, then run:

    python3 scripts/post_entries.py

The script pre-validates the Notion token via GET /v1/users/me before
posting, and gracefully reports each entry's success/failure with a final
summary line.
"""
import os
import json
import subprocess
import sys
from datetime import datetime, timezone, timedelta

TK_PATH = os.path.expanduser("~/.hermes/secrets/notion_token.txt")
DB_ID = "33c76f2e-9097-8184-b51e-fa09efcf6d4d"
NOTION_API = "https://api.notion.com/v1"
NOTION_VERSION = "2022-06-28"
CATEGORIES = ["iOS/Swift", "AI/ML", "Automation", "Infra", "Other"]


def today_kst() -> str:
    return datetime.now(timezone(timedelta(hours=9))).strftime("%Y-%m-%d")


def _curl(tk, args):
    """Run curl with bearer token injected as a separate -H arg (no shell, no $var).

    CRITICAL: Do NOT use shell=True with `Authorization: Bearer $NTK` as a
    string literal. Two failure modes observed on 2026-06-14 cron run:
      1) Pre-check via shell-string form returned {"object":"user"} (looked
         fine), but the subsequent POST returned "API token is invalid" for
         ALL 6 entries. Root cause: shell-string + env-var expansion is
         inconsistent between GET and POST in tirith/cron context — the
         header reached curl as a literal $NTK in the GET but the POST was
         token-stripped.
      2) Same problem recurs in cron mode for any skill that posts to Notion.

    Fix: pass args as a Python list to subprocess.run, build the header as a
    single string, hand it to curl as a discrete -H arg. No shell, no env var.
    """
    auth_header = f"Authorization: Bearer {tk}"
    return subprocess.run(
        ["curl", "-s", "--max-time", "20", *args,
         "-H", auth_header,
         "-H", f"Notion-Version: {NOTION_VERSION}"],
        capture_output=True, text=True
    ).stdout


def check_token(tk):
    """Validate token via /v1/users/me. Returns True if valid."""
    try:
        resp = json.loads(_curl(tk, ["-X", "GET", f"{NOTION_API}/users/me"]))
        return resp.get("object") == "user"
    except Exception:
        return False


def post_entry(tk, entry, today):
    if entry["Category"] not in CATEGORIES:
        return False, f"INVALID_CATEGORY ({entry['Category']})"
    payload = {
        "parent": {"database_id": DB_ID},
        "properties": {
            "Name": {"title": [{"text": {"content": entry["Name"]}}]},
            "Date": {"date": {"start": today}},
            "Category": {"select": {"name": entry["Category"]}},
            "Summary": {"rich_text": [{"text": {"content": entry["Summary"]}}]},
            "URL": {"url": entry.get("URL")},
        },
    }
    with open("/tmp/notion_entry.json", "w") as f:
        json.dump(payload, f, ensure_ascii=False)
    try:
        resp = json.loads(
            _curl(tk, [
                "-X", "POST", f"{NOTION_API}/pages",
                "-H", "Content-Type: application/json",
                "-d", "@/tmp/notion_entry.json",
            ])
        )
    except Exception as e:
        return False, f"PARSE_ERROR ({e})"
    if resp.get("object") == "page":
        return True, resp.get("id", "")
    return False, resp.get("message", "unknown")[:120]


# Edit this list with the week's learning entries. Each entry is a dict with:
#   Name (str, required)    - Title, concise topic name
#   Category (str, required) - One of CATEGORIES
#   Summary (str, required) - 1-2 sentence core takeaway
#   URL (str, optional)     - Reference link
ENTRIES = [
    {
        "Name": "AI 벤치마크 7/5: Sakana Fugu Ultra 이중 톱 + DeepSeek·Qwen 코딩 양강",
        "Category": "AI/ML",
        "Summary": "agent-benchmark-tracker 주간 cron이 benchlm.ai 단일 fetch로 12개 신규 벤치마크 POST 성공. Sakana Fugu Ultra GPQA 95.5% #1 + LiveCodeBench 93.2% #2 (일본산 첫 90%대), DeepSeek V4 Pro (Max) LiveCodeBench 93.5% #1, Qwen3.7 Max 91.6% #3 + MMLU-Pro 89.6% #1 더블 톱. DB 125→137 누적.",
    },
    {
        "Name": "Tistory 발행 §3.8.1 Zombie 302 패턴 확립 + W26 skip 3중 사유",
        "Category": "Automation",
        "Summary": "Tistory 세션 만료 시 5종 쿠키 값이 env에 존재해도 184차 6/29 갱신 이래 6일 경과 시 manage API가 login redirect(HTTP 302 + Location: /auth/login). 3-endpoint probe로 §3.8(200 HTML) vs §3.8.1(302 login) 구분. 196차(LongCat-2.0) + 197차(무언가를 배워…) 연속 skip, 가짜 발행 0건.",
    },
    {
        "Name": "weekly-tech-digest W26 skip: Zombie 302 + W26 중복 + ICBM2 인사이트 0건",
        "Category": "Automation",
        "Summary": "AI 9건+iOS 10건+자동화 8건=27건 수집 후 W26 중복(7/1 #891 발행 완료) + Zombie 302(184차 6/29 쿠키 갱신 이래 6일) + published_posts=0 인사이트 부족 → 안전 skip. weekly_newsletter_data.json 보존되어 W27 발행 시 그대로 활용 가능.",
    },
    {
        "Name": "지식 그래프 7/1~7/4: 노드 1,051→1,056 / 연결 9,411→9,442, 엔티티 Top 5 안정",
        "Category": "Infra",
        "Summary": "knowledge-graph 일일 cron이 6개 Notion DB에서 90일 데이터 수집 → 그래프 자동 구축. 7/1 1,051노드/9,411연결 → 7/4 1,056노드/9,442연결. iOS 175회·AI 132회·Apple 131회·Swift 68회·SwiftUI 58회 Top 5 안정. invest_memo DB 404 + GitHub Pages 'not a git repository' 4일째 지속(수동 git init 필요).",
    },
    {
        "Name": "Apple News v4 파서 split+개별regex 영구 안정화 + 듀얼스킬 shared preflight 누적 4회차",
        "Category": "iOS/Swift",
        "Summary": "ios-trend-digest 7/5 일요일에 492KB Apple News 페이지 v4 파서(split `<article id=...>` 후 개별 regex 4번)로 104/104 매치(0.1초). 6/3~6/23 fallback 윈도우에서 7개 추출(Brazil CADE 합의, ImageCreator 폐기, Time Allowances, Design kits 등). Notion preflight를 ios-trend-digest + ai-model-tracker 1회로 통합 — 4회차 누적 0건 silent failure.",
    },
    {
        "Name": "weekly-automation-report W27: cron 99% 성공 + urllib 기반 Notion POST로 6주 silent-fail 차단",
        "Category": "Infra",
        "Summary": "일요일 심층 점검 7/5: Wiki 153페이지(고아 13, 브로큰 71), claude-code entity 부재가 14건 브로큰 링크의 단일 원인(다음 ingest 최우선), cron 139 실행/133 성공/96%, 4/4 POST 성공(`urllib.request` 기반 — f-string SyntaxError 회피). 주간 실패 2건(7/2 skills-marketplace-sync RuntimeError, 7/1 Token Plan 한도) 모두 일회성.",
    },
    {
        "Name": "scripts/post_entries.py 46번 줄 f-string SyntaxError 재발 — 동일 함정 다른 skill 잔존 가능",
        "Category": "Infra",
        "Summary": "learning-log Notion POST용 `scripts/post_entries.py` 46번 줄에 `auth_header = f'Authorization: Bearer *** + tk` (닫는 따옴표·콤마 누락) → SyntaxError 1회 재발. 이번 cron에서 `f'Authorization: Bearer *** 형태로 patch 완료. weekly-automation-report의 `notion_preflight.py` / `post_weekly_entries.py`에도 동일 패턴 잔존 가능 — 다음 점검에서 동일 함정 검색 필요.",
    },
]


def main():
    if not os.path.exists(TK_PATH):
        print("NOTION_TOKEN_MISSING:", TK_PATH)
        return 1
    with open(TK_PATH) as f:
        tk = f.read().strip()

    if not check_token(tk):
        print("NOTION_TOKEN_INVALID - reissue integration at notion.so/my-integrations")
        return 2

    today = today_kst()
    print(f"[{today}] Posting {len(ENTRIES)} entries to Notion DB...")

    success, failed = 0, 0
    for entry in ENTRIES:
        ok, detail = post_entry(tk, entry, today)
        marker = "OK" if ok else "FAIL"
        print(f"  {marker} [{entry['Category']}] {entry['Name']} -> {detail}")
        if ok:
            success += 1
        else:
            failed += 1

    print(f"\n=== Summary ===\nSuccess: {success}/{len(ENTRIES)}\nFailed: {failed}\nDate: {today}")
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
