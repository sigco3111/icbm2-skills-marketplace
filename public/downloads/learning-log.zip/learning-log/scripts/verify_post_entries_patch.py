"""
Ad-hoc verification for scripts/post_entries.py.

What it checks:
  1. Static: file parses with ast.parse (catches the known f-string
     SyntaxError on line 46 immediately, before any curl runs).
  2. Static: line 46 holds the fixed f-string form `f"...Bearer {tk}..."`
     (regression guard for the well-known `Bearer *** + tk` pattern).
  3. Module import via importlib.util succeeds.
  4. Live Notion preflight (GET /v1/users/me) via the patched _curl() returns
     `object == "user"` (proves the bearer token + auth header work).
  5. End-to-end POST + PATCH archive roundtrip via _curl() — creates a real
     Notion page in the Learning Log DB and immediately archives it, so the
     DB is not polluted. This is the strongest proof that the patched
     script actually works against the live API.
  6. ENTRIES list sanity (>=5 entries, all Categories in the allowed set,
     all Names + Summaries non-empty).

When to run:
  - Before every cron run of `python3 scripts/post_entries.py` (per the
    SKILL.md "사전 검증 단계 0"). This is the pre-flight check.
  - After any patch to scripts/post_entries.py — confirms the fix is still
    in place and end-to-end functional.
  - After any patch to Notion token / secret rotation — confirms the token
    still works with the patched _curl().

Run:
  python3 scripts/verify_post_entries_patch.py

Exit code: 0 if all checks pass, 1 otherwise. Designed for cron pipelines
that should refuse to run post_entries.py if the verifier fails.
"""
import os
import sys
import ast
import json
import tempfile
import importlib.util

SCRIPT = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "post_entries.py"
)
NOTION_API = "https://api.notion.com/v1"
TK_PATH = os.path.expanduser("~/.hermes/secrets/notion_token.txt")

results = []


def check(label, ok, detail=""):
    status = "PASS" if ok else "FAIL"
    results.append((label, ok, detail))
    print(f"  [{status}] {label}  {detail}")


def print_summary_and_exit(code=1):
    print()
    print("=" * 70)
    print("Summary")
    print("=" * 70)
    for label, ok, _ in results:
        marker = "PASS" if ok else "FAIL"
        print("  [" + marker + "] " + label)
    passed = sum(1 for _, ok, _ in results if ok)
    failed = sum(1 for _, ok, _ in results if not ok)
    print("")
    print(str(passed) + " passed, " + str(failed) + " failed (of " + str(len(results)) + ")")
    sys.exit(code)


# ─── 1) Static: script parses + line 46 holds the fixed f-string form ────
print("=" * 70)
print("1) Static syntax + line-46 f-string fix")
print("=" * 70)
try:
    with open(SCRIPT) as f:
        src_disk = f.read()
    ast.parse(src_disk)
    check("ast.parse succeeds", True)
except SyntaxError as e:
    check("ast.parse succeeds", False, f"{e}")
    print("FATAL: 46-line f-string SyntaxError is back. Patch scripts/post_entries.py line 46 first.")
    print_summary_and_exit(1)

with open(SCRIPT) as f:
    lines = f.readlines()
auth_lines = [(i + 1, ln.rstrip()) for i, ln in enumerate(lines)
              if "auth_header" in ln and "Bearer" in ln]
print("  auth_header lines: " + str(auth_lines))
ok_fix = False
for i, ln in auth_lines:
    s = ln.lstrip()
    if s.startswith("auth_header = f"):
        after_f = s.split("= f", 1)[1]
        if "Bearer" in after_f and "{tk}" in after_f and after_f.count(chr(34)) >= 2:
            ok_fix = True
            print("  fixed f-string form found on line " + str(i) + ": " + ln.rstrip())
            break
check("line 46 uses fixed f-string form `f...Bearer {tk}...`", ok_fix)
if not ok_fix:
    print("FATAL: 46-line f-string form is broken. Expected: auth_header = f\"Authorization: Bearer {tk}\"")
    print_summary_and_exit(1)

# ─── 2) Module import ─────────────────────────────────────────────────────
print()
print("=" * 70)
print("2) Module import check")
print("=" * 70)
spec = importlib.util.spec_from_file_location("post_entries", SCRIPT)
mod = importlib.util.module_from_spec(spec)
try:
    spec.loader.exec_module(mod)
    check("script imports as module", True)
except Exception as e:
    check("script imports as module", False, str(type(e).__name__) + ": " + str(e))
    print("Aborting — import failed.")
    print_summary_and_exit(1)

check("_curl present", callable(getattr(mod, "_curl", None)))
check("post_entry present", callable(getattr(mod, "post_entry", None)))
check("check_token present", callable(getattr(mod, "check_token", None)))
check("today_kst present", callable(getattr(mod, "today_kst", None)))

# ─── 3) Live Notion preflight via _curl() ────────────────────────────────
print()
print("=" * 70)
print("3) Live Notion preflight (GET /v1/users/me)")
print("=" * 70)
if not os.path.exists(TK_PATH):
    check("token file present", False, TK_PATH)
    print_summary_and_exit(1)
with open(TK_PATH) as f:
    tk = f.read().strip()
raw = mod._curl(tk, ["-X", "GET", NOTION_API + "/users/me"])
try:
    pre = json.loads(raw)
    ok = pre.get("object") == "user"
    check("GET /v1/users/me returns object=user", ok, "id=" + str(pre.get("id", "?"))[:20])
except Exception as e:
    check("GET /v1/users/me JSON-parseable", False, str(e) + "; raw[:200]=" + raw[:200])
    print_summary_and_exit(1)

# ─── 4) End-to-end POST + archive roundtrip via _curl() ──────────────────
print()
print("=" * 70)
print("4) End-to-end POST + PATCH archive roundtrip via _curl()")
print("=" * 70)
DB_ID = "33c76f2e-9097-8184-b51e-fa09efcf6d4d"  # Learning Log DB
probe_name = "[verify] ad-hoc patch test " + str(os.getpid())
probe_payload = {
    "parent": {"database_id": DB_ID},
    "properties": {
        "Name": {"title": [{"text": {"content": probe_name}}]},
        "Date": {"date": {"start": mod.today_kst()}},
        "Category": {"select": {"name": "Other"}},
        "Summary": {"rich_text": [{"text": {"content": "ad-hoc verification - will be archived"}}]},
    },
}
with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as f:
    json.dump(probe_payload, f, ensure_ascii=False)
    payload_path = f.name

try:
    raw = mod._curl(tk, [
        "-X", "POST", NOTION_API + "/pages",
        "-H", "Content-Type: application/json",
        "-d", "@" + payload_path,
    ])
    try:
        resp = json.loads(raw)
    except Exception as e:
        check("POST /pages JSON-parseable", False, str(e) + "; raw[:200]=" + raw[:200])
        resp = {}
    if resp.get("object") == "page":
        probe_id = resp.get("id", "")
        check("POST /pages created a page", True, "id=" + probe_id)
        raw2 = mod._curl(tk, [
            "-X", "PATCH", NOTION_API + "/pages/" + probe_id,
            "-H", "Content-Type: application/json",
            "-d", '{"archived": true}',
        ])
        try:
            resp2 = json.loads(raw2)
            check("PATCH archived=true cleans up", resp2.get("archived") is True,
                  "archived=" + str(resp2.get("archived")))
        except Exception as e:
            check("PATCH archived parses", False, str(e) + "; raw[:200]=" + raw2[:200])
    else:
        check("POST /pages created a page", False,
              "object=" + str(resp.get("object")) + ", message=" +
              str(resp.get("message", "?"))[:120])
finally:
    try:
        os.unlink(payload_path)
    except OSError:
        pass

# ─── 5) ENTRIES list sanity ───────────────────────────────────────────────
print()
print("=" * 70)
print("5) ENTRIES list sanity (this week's W27 entries)")
print("=" * 70)
entries = getattr(mod, "ENTRIES", [])
check("ENTRIES list non-empty (>=5)", len(entries) >= 5, "len=" + str(len(entries)))
allowed = {"iOS/Swift", "AI/ML", "Automation", "Infra", "Other"}
cats = [e.get("Category") for e in entries]
check("all Categories in allowed set", all(c in allowed for c in cats), "cats=" + str(set(cats)))
names = [e.get("Name") for e in entries]
check("all Names non-empty", all(n and isinstance(n, str) for n in names))
summaries = [e.get("Summary") for e in entries]
check("all Summaries non-empty", all(s and isinstance(s, str) for s in summaries))

print_summary_and_exit(0 if not [ok for _, ok, _ in results if not ok] else 1)
