---
name: asciirogue-devpitfalls-2026-07
description: Roguelike bug patterns + ECS gotchas from asciirogue v0.5.1 → v0.5.11. AI-through-walls, zero-damage log spam, invisible death, boss-detection, render order, pickup window/visibility parity, swap-collision in equip, E0252 re-export trap, item-clone discipline, modal two-mode dispatcher tests, touch-everywhere for keyboard remaps and bypass-resource UI, gold-bypass-inventory (out-parameter wallet), StairsDown visible & gated, the lib.rs/main.rs dual-App dual-edit trap, tile-triggered modal-confirm popup replacing a hotkey, and the cargo test --release requirement on this project's seed math.
---

# asciirogue dev pitfalls — 2026-07-29 session ledger

Session-specific bug-fix ledger for asciirogue v0.5.1 / v0.5.2. Class-level
parent: `../rust-roguelike-development/SKILL.md`. This file captures the
exact patterns that broke on 2026-07-29 — code shapes and user quotes.

## Five bug classes to never write twice

### Bug 1 — AI tracks the player through walls (v0.5.1)

User quote: "적도 나도 안 죽고 계속 반복됨."

Root: `combat::ai::take_turn` used Chebyshev distance as the visibility
predicate. Through a 1-tile wall the enemy still "sees" the player and
chases — even though the player can't see the enemy.

Canonical fix:

```rust
fn can_see_through<SB: Fn(i32, i32) -> bool>(
    a: TilePos, b: TilePos, range: i32, sb: &SB
) -> bool {
    let dx = b.0 - a.0;
    let dy = b.1 - a.1;
    let dist = dx.abs().max(dy.abs());
    if dist > range { return false; }
    for i in 1..dist {
        let t = i as f32 / dist as f32;
        let px = a.0 + (dx as f32 * t).round() as i32;
        let py = a.1 + (dy as f32 * t).round() as i32;
        if sb(px, py) { return false; }
    }
    true
}
```

Add `last_known_player: Option<TilePos>` to `Ai`. Update it at the caller
boundary (where you decide what the enemy is now aware of), not from
inside `take_turn`.

Play-test sidebar: VIEW_RADIUS 8 was almost half a 60×24 map. Five
twenty-four-line fights read better than four eight-tile ones.

### Bug 2 — `치명타! 0 피해!` log spam (v0.5.2)

User quote: "$ 표시와는 전투가 끝나지 않음" (direct quote, punctuation
preserved).

Root: `Health::take(dmg)` returns `dmg.max(0).min(self.current)`. When the
target's `current` is 0, `dealt` is 0. Caller logs `format!("{} {} 피해!",
crit, 0)` → `"치명타! 0 피해!"`. The pattern compounds when the player
walks into a corpse tile — `player_attack` runs the dice on a
just-killed entity.

Two-gate fix in `App::player_attack`:

```rust
// Gate 1 — skip entirely if dead.
let already_dead = self.world.get::<&Health>(target)
    .map(|h| h.is_dead()).unwrap_or(true);
if already_dead { return; }

// ... (roll dice, run take, get dealt) ...

// Gate 2 — let despawn_dead's "x 처치!" be the only message.
if dealt == 0 {
    self.despawn_dead();
    return;
}
self.log(format!("{}{} 피해!", crit_marker, dealt));
self.despawn_dead();
```

Generalised rule: **any combat log line that prints `0` is a bug.** Gate
on `dealt > 0` or pre-check `is_dead()`.

### Bug 3 — Death becomes invisible because the log scrolls past it (v0.5.1)

Symptom: the player thought they were not dying. They were. The death
message scrolled off the top of the 5-message FIFO queue during a
combat burst.

Three rules stack:

```rust
if player_died && !self.game_over {
    self.game_over = true;
    self.messages.clear();          // 1. forces death onto the visible rows
    self.messages.push("═══ 쓰러졌습니다… ═══".into());  // 2. unmistakable border
    // 3. App.game_over pauses the input loop except for R / q
}
```

Header title additionally becomes `" ☠ YOU DIED ☠ "`. Pause the input
loop — a visual message alone scrolls off too easily.

### Bug 4 — Boss detection heuristic must be frame-stable

asciirogue tags the boss by `Health::max > 100`. Works while the boss is
the only HP-monster. **Breaks the moment you spawn elite enemies with
HP > 100.** Use an explicit `Boss` marker component and check
`World::query::<&Boss>()` if you want multiple boss archetypes.

### Bug 5 — Render order: items < enemies < player

The user's two screenshots both showed the player's `@` overlapped by
glyphs from another entity sharing the player's tile.

Fix shape: in `draw_world`, render in this order:
1. Items / ground glyphs
2. Enemies
3. Player last

Three separate `world.query::<...>()` calls in that order, each writing
into the frame buffer. The last write wins. The wall glyph
`wall_glyph(dungeon, x, y)` is part of the tile pass — it does NOT
compete with entity glyphs.

## New Pitfall — `$` and `,` keys omitted from pickup handling (v0.5.3)

User observation: pressing `$` (gold glyph) or `,` did not pick up items, showing a generic "item not found" message despite items being present. This stemmed from the input handler only matching `KeyCode::Char('g') | KeyCode::Char('G')` and calling the legacy `try_pickup` which returned a simple boolean, losing the tri‑state outcome needed for proper messages.

Fix applied in this session:
- Expanded the key match to include `KeyCode::Char('$') | KeyCode::Char(',')`.
- Replaced the boolean `try_pickup` call with `pick_up_outcome`, which returns `PickupOutcome::Picked`, `NoItem`, or `InventoryFull`.
- Updated the log messages to distinct Korean strings for each case.

**Guideline for future changes:**
1. When adding alias keys for an action, always route through the same high‑level function (`pick_up_outcome`) to keep messaging consistent.
2. Preserve the tri‑state enum to allow callers to differentiate "no item" vs "full inventory".
3. Add regression tests covering all three outcomes for each pickup key alias.

See `references/pickup-key-aliases.md` for implementation details and the recommended regression test suite.

User observation: pressing `$` (gold glyph) or `,` did not pick up items, showing a generic "item not found" message despite items being present. This stemmed from the input handler only matching `KeyCode::Char('g') | KeyCode::Char('G')` and calling the legacy `try_pickup` which returned a simple boolean, losing the tri‑state outcome needed for proper messages.

Fix applied in this session:
- Expanded the key match to include `KeyCode::Char('$') | KeyCode::Char(',')`.
- Replaced the boolean `try_pickup` call with `pick_up_outcome`, which returns `PickupOutcome::Picked`, `NoItem`, or `InventoryFull`.
- Updated the log messages to distinct Korean strings for each case.

Guideline for future changes:
1. When adding alias keys for an action, always route through the same high‑level function (`pick_up_outcome`) to keep messaging consistent.
2. Preserve the tri‑state enum to allow callers to differentiate "no item" vs "full inventory".
3. Add regression tests covering all three outcomes for each pickup key alias.

---

## Three observations worth carrying forward

1. **Headless tests caught ~50%** of these. `--dump` surfaces
   zero-damage and boss-detection patterns. It does NOT surface
   "death is invisible" or "player glyph layer order" — those need a
   real player.

2. **Screenshot feedback is precise.** The user's two bug reports were
   one to two lines of Korean. They pointed at the symptom, not the
   cause. Treating the screenshot as the spec gave three concurrent
   causes per bug rather than one.

3. **"Don't write this" rules survive longer than declarative tutorials.**
   "the AI chases through walls" is a grep-friendly rule. "use FOV
   library X with parameter Y" is a recipe that rots.

## Bug 6 — Pickup "doesn't work" because the gold is not on the player's tile (v0.5.4)

User quote (2026-07-29): "$줍기가 몇시간째 처리중인데 안됨. 계속 같은 방법으로
시도하지 말고 새로운 방법을 찾아봐"

What was actually wrong: the pickup code (`pick_up_outcome`) was already
correct — the v0.5.4 tri-state properly distinguishes `NoItem` from
`InventoryFull`. The user's screenshot showed a `$` glyph that looked
adjacent to the `@`, but the gold's actual coordinate was **not on the
player's current tile**. Two sub-cases observed:

- (a) Gold is on a tile **separated from the player by a wall** — the
  player can't step onto it, so auto-pickup never fires.
- (b) Gold is **visually adjacent** (1-tile offset) but the player's
  current tile has nothing on it — pressing `g`/`$`/`Shift+4` logs
  `"주울 아이템이 없습니다."` truthfully. From the player's perspective
  it looks like "the key is broken".

Root pattern: **pickup is strictly player-tile-only, but the user has
no way to know where the gold actually is.** The status bar shows
`player (x,y)` but no distance-to-nearest-item or
direction-to-nearest-item.

Three fixes that should be added together (none of them alone is
enough):

1. **Header distance hint** — when the player is within N tiles of an
   item, render something like `→ 골드 (12,20) 5칸` in the status bar.
2. **Visual emphasis for items within reach** — tint gold/items on
   passable adjacent tiles differently from items behind walls. The
   `draw_world` layer order (Bug 5) already separates items; add a
   second-pass tint for "in-range but not on player tile".
3. **Pickup key accepts 1-tile reach** — pressing `g`/`$` when the
   player is adjacent (Chebyshev distance == 1) to an item on a
   passable tile should walk + pick up. Strict player-tile pickup is
   the canonical roguelike rule but it's also why the user thought the
   key was broken.

### Diagnostic recipe that found this

Headless probe with the user's exact seed reproduces the symptom
without a TTY:

```rust
// crates/app/examples/pickup_probe.rs
let mut app = App::new(USER_SEED);
let player = find_player(&app);
// 1. confirm player tile has no item
let on_player: Vec<_> = app.world_ref()
    .query::<(&Position, &Item)>()
    .iter()
    .filter(|(_, (p, _))| p.0 == player_pos)
    .collect();
// 2. list all ground items sorted by manhattan distance
// 3. simulate 'g' / '$' / Shift+4 keys — inventory must NOT grow
// 4. walk Left/Right/Up/Down — which directions are walls?
// 5. dump: player_pos, msgs, inventory, ground items
```

If the probe shows `inventory delta = 0` after every pickup attempt and
the ground items list is non-empty, **the code is correct and the bug
is UX**. Do not patch the code; ship fixes (1)(2)(3) above.

### Anti-pattern from this session — "code-fix loop with the same patch"

The user's frustration text "계속 같은 방법으로 시도하지 말고 새로운 방법을
찾아봐" is a **first-class signal** that the assistant has been patching
the code instead of changing the **diagnostic method**. The corrective
rule for any future "X doesn't work" report:

> Before applying the Nth patch to a function, run a headless probe
> that exercises the function with the **exact user-supplied inputs**.
> If the probe shows the function returning the right value, the bug
> is NOT in the function. Stop patching. Look at UX, data, environment.

For the asciirogue pickup case: 5 minutes of probe (`pickup_probe.rs`)
discovered `inventory delta = 0` with a truthy ground-items list, which
is a UX bug, not a code bug. The first patch the user might have
received (modifying `pick_up_outcome`) would have been a regression.

## v0.5.5 — surface pickup distance in header, bold adjacent items

After the probe proved the code was fine, the user picked **A+B 동시**
(header distance + bold adjacent) when offered 4 options. The fix
shipped as commit `78db4dd` and added the following API surface that
future sessions should know about.

### New probe-friendly API in `asciirogue::App`

```rust
// crates/app/src/lib.rs (impl App probe-friendly section)
pub fn dungeon_ref(&self) -> &asciirogue_procgen::Dungeon { &self.dungeon }
pub fn floor(&self) -> u32 { self.floor }
pub fn nearest_pickup_info(&self) -> Option<(usize, Direction, char)> {
    nearest_pickup_info(&self.dungeon, &self.world, self.player)
}
```

`nearest_pickup_info` is a free function too — takes `&Dungeon,
&hecs::World, player_entity` and returns `(bfs_distance,
first_step_cardinal_direction, item_glyph)`. BFS is 4-neighborhood,
capped at `MAX_PICKUP_SEARCH = 24` so a missing item doesn't walk the
whole 60×24 dungeon each frame. The `first_step_direction` is what
makes the header meaningful — it tells the player which way to walk
**first**, not just how far.

### `draw_world` signature now takes adjacent-item tiles

```rust
// crates/render/src/lib.rs
pub fn draw_world(
    frame: &mut Frame<'_>,
    area: ratatui::layout::Rect,
    map: &Dungeon,
    world: &hecs::World,
    viewshed: &Viewshed,
    near_pickup_tiles: &std::collections::HashSet<(i32, i32)>,
)
```

Items on the player's tile or any of its 4 cardinal neighbours get the
`ratatui::style::Modifier::BOLD` modifier via `Cell::set_style` (note:
ratatui 0.29 Cell has `set_style`, NOT `add_modifier` — the latter was
removed and the compiler will tell you so). Distant items keep their
normal weight — the spotlight only follows what you can actually pick
up right now.

### Two new probe examples

`crates/app/examples/pickup_probe.rs` — 3 scenarios using the exact
user seed `7581304714302077700`:
- **Scenario A**: teleport player to (13, 20), drop gold at (12, 20).
  `nearest_pickup_info` returns `Some((2, Up, '$'))` — matches the
  header output `pickup: ↑ $ 2`. The probe confirms `pick_up_outcome`
  is a no-op (correct: gold is not on the player's tile) and
  `App::step(Direction::Up)` walks one step closer.
- **Scenario B**: despawn every ground item. `nearest_pickup_info`
  returns `None` — header shows no pickup hint (correct).
- **Scenario C**: fresh seed, ground items in BSP-generated rooms.
  Returns `Some((8, Down, '?'))` — header would say `pickup: ↓ ? 8`,
  accurate for a fresh run.

`crates/app/examples/header_probe.rs` — renders the **exact** header
string `App::draw` builds, so we can verify it without driving a TTY.
Useful because PTY capture of ratatui apps is fragile (`cargo run` +
`q` + stdin race), but the header builder is pure Rust — a probe is
both faster and deterministic.

```bash
cargo run --example header_probe -p asciirogue
# → "asciirogue — seed … player (13,20)  visible 48  pickup: ↑ $ 2  HP 40/40  MP 15/15"
```

### New render test

```rust
// crates/render/src/lib.rs (tests)
fn draw_world_bolds_adjacent_pickups()
```

Drives `draw_world` through `ratatui::backend::TestBackend` (you can't
call `draw_world` directly — it needs a `Frame`). Asserts:
- gold at the player's neighbour has `Modifier::BOLD`
- gold far away does not
- both still have their glyph in the buffer

Viewshed in the test is built manually: `vs.visible.push(TilePos(x,y))`
for every tile (NOT `*cell = true` — `visible: Vec<TilePos>`, not
`Vec<bool>`); `vs.revealed[y * 5 + x] = true` with `(y * 5 + x) as usize`
casting (Rust requires `usize` for `Vec<bool>` indexing).

### What the user actually sees

```
asciirogue — seed 7581304714302077700  1F 동굴  player (13,20)  visible 48  pickup: ↑ $ 2  HP 40/40  MP 15/15
                                                                                       ↑ ↑
                                                                                       골드까지 위로 2칸
```

After one `k` (up), the header changes to `pickup: ↑ $ 1` and the gold
glyph becomes bold. Then `g` picks it up.

### Carry-forward patterns (not just for pickup)

- **TUI status bar distance hint** generalises to any "you need to find
  X" UX: stairs (next floor), enemies (lowest-HP), unexplored rooms.
  Same BFS, different `near_*_tiles` set.
- **`draw_world` 6th parameter pattern** generalises to any "highlight
  things in reach" — see the existing `viewshed.revealed` for memory
  tinting as a precedent.
- **Multi-option packaging (A+B 동시)**: when the user says "동시에" or
  picks >1 from a 4-option menu, ship them together. The user knows
  what they want; don't re-prioritise.

## v0.5.6 — pickup window = player tile + 4 cardinal neighbours

User feedback (2026-07-29, second session message): "1칸 반경 골드 BOLD
처리는 됨. 하지만 아직도 습득은 안됨."

v0.5.5 added the **visual** layer (BOLD highlight + header distance hint)
but left `pick_up_outcome` itself scoped to the player's tile only. That
matched auto-pickup-on-step semantics — when the player walks onto a
tile with an item, `try_player_act` calls `pick_up_outcome` for the
arrival tile and consumes it. But the explicit `g` / `$` / Shift+4 keys
felt broken: with a $ visually adjacent, pressing g replied
"주울 아이템이 없습니다." forever.

Probe finding on user seed `7581304714302077700`, player at (13, 20),
gold at (12, 20):

| Distance | v0.5.5 | v0.5.6 |
|---|---|---|
| 0 (on tile) | `Picked` | `Picked` |
| 1 (adjacent) | `NoItem` ❌ | `Picked` ✅ |
| 2+ | `NoItem` | `NoItem` |

### Fix shape in `crates/app/src/lib.rs`

```rust
pub fn pick_up_outcome(world: &mut World, player: hecs::Entity) -> PickupOutcome {
    let player_pos = world.get::<&Position>(player)?.0;
    let here = player_pos;
    let neighbours = [
        TilePos(player_pos.0 - 1, player_pos.1),
        TilePos(player_pos.0 + 1, player_pos.1),
        TilePos(player_pos.0, player_pos.1 - 1),
        TilePos(player_pos.0, player_pos.1 + 1),
    ];
    let wanted: HashSet<TilePos> =
        std::iter::once(here).chain(neighbours.iter().copied()).collect();
    let item_entities: Vec<_> = world.query::<(&Position, &Item)>().iter()
        .filter_map(|(e, (p, _))| if wanted.contains(&p.0) { Some(e) } else { None })
        .collect();
    // ... rest unchanged: clone items, push into Inventory, despawn on success.
}
```

**Order matters**: `std::iter::once(here).chain(neighbours)` puts the
player's tile first in the iteration order, which preserves the v0.5.4
auto-pickup-on-step invariant — when the player steps onto gold, the
gold-on-current-tile is consumed first, BEFORE any neighbour items.

### New regression test in `crates/app/src/main.rs`

```rust
#[test]
fn test_adjacent_pickup() {
    let mut app = App::new(0);
    app.world.get::<&mut Position>(app.player).unwrap().0 = TilePos(10, 10);
    app.world.get::<&mut Inventory>(app.player).unwrap()
        .slots.iter_mut().for_each(|s| *s = None);
    app.world.spawn((Position(TilePos(9, 10)), Item::gold(3)));
    let ev = Event::Key(KeyEvent { code: KeyCode::Char('g'), /* ... */ });
    app.handle(&ev);
    let inv = app.world.get::<&Inventory>(app.player).unwrap();
    let filled: Vec<&Item> = inv.slots.iter().filter_map(|s| s.as_ref()).collect();
    assert_eq!(filled.len(), 1);
    assert_eq!(filled[0].glyph, '$');
    assert!(app.messages.iter().any(|m| m.contains("주웠")));
}
```

### The 4-piece pickup set is now complete

| Layer | v0.5.4 | v0.5.5 | v0.5.6 |
|---|---|---|---|
| `pick_up_outcome` window | tile only | tile only | **tile + 4 neighbours** |
| Header distance hint | none | `pickup: ↑ $ 2` | unchanged |
| `draw_world` BOLD highlight | none | adjacent tiles | unchanged |
| Tests covering adjacent pickup | none | none | **test_adjacent_pickup** |

The lesson: **visual affordances without functional support confuse the
user more than no affordance at all.** v0.5.5's BOLD highlight made
players press g harder, but the function rejected them. The right
move on any "X is visible but X doesn't respond to my input" report is
to widen the input window in lockstep with the visibility window.

### Carry-forward: window-vs-highlight parity rule

> Any visual "in reach" indicator must be backed by a behavioural
> handler that also accepts the in-reach state. If `draw_world` BOLDs
> a tile, `pick_up_outcome` must include that tile in its query, and
> `try_player_act`'s auto-pickup must fire from that tile too.

Same pattern will apply to other "highlight + action" pairs:
- ranged attacks (highlight target in range, attack action accepts
  any tile in range)
- AoE spells (highlight blast radius, the spell targets all tiles in
  the same radius)
- interact (highlight adjacent interactable, the action triggers from
  the same radius)

### Diagnostic recipe for "highlight works but action doesn't"

When the user reports this pattern, the probe is two assertions in one
test:

```rust
// 1. visual layer says the item is in reach
assert!(near_pickup_tiles.contains(&(adj_x, adj_y)));

// 2. action layer says it ISN'T reachable (or vice versa)
assert_eq!(pick_up_outcome(...), PickupOutcome::Picked);
```

If (1) is true and (2) is false, you have a window-mismatch bug — fix
the action layer's window, NOT the visual layer (which was already
correct). Reversing the probe — looking for (1) false and (2) true —
would catch the opposite gap: action accepts something the user can't
see is in range.

## v0.5.7 — inventory modal + equipment system (WORK-IN-PROGRESS)

User feedback (2026-07-29, fourth session message): "이제 잘됨. 그런데,
아이템을 습득하면 물품을 확인하거나 사용 및 장비 할 수 있는 화면은
아직 없는 건가? 그리고 모두 탐색했는데, 다음 층으로 이동하는 것을
발견 못했음. 이것도 처리된 건가?"

Two unrelated missing features called out in one message:
1. **No inventory modal** — items were consumed immediately on press
   (`i` → `use_first_potion` ate the first HP/MP potion in one keystroke,
   no per-slot choice). Equipment items (`)` weapon, `[` armor) had no
   equip path at all.
2. **No `>` descend hint in footer** — `>` was wired (main.rs:267-290,
   conditional on `boss_defeated`) but the controls hint never listed it.
   User searched the whole map for stairs before asking.

### Pattern: feature vs discoverability gap

This was a discoverability gap more than a feature gap. The code already
had:
- `>` key handler with boss-defeated gate and Soul Remembrance reward
- `Inventory` component with 8 slots
- `Item::weapon` / `Item::armor` constructors
- `Stats` struct with a `bonus: i32` field (unused for damage at that point)

…none of which the user could discover from inside the game. Probe
check at session start (`rg "Inventory|use_first_pickup|weapon|armor|>"
crates/`) would have surfaced these as **implemented-but-undiscoverable**
in under a minute. Worth doing as a periodic audit.

### Modal-mode pattern that worked

Added `ModalMode { Closed, Inventory { cursor: usize } }` to `App`.
`App::handle` early-returns into `handle_inventory_key` while the modal
is open, so gameplay keys (movement, attack) freeze the world. This
matters because otherwise enemies could walk into the player mid-loot.

```rust
if let ModalMode::Inventory { cursor } = self.modal {
    self.handle_inventory_key(k.code, cursor);
    return;
}
```

Modal-local key dispatch returns the new cursor via
`self.modal = ModalMode::Inventory { cursor: next_cursor(cursor, 1) }`
— keeping modal state inside the existing enum keeps the variant
self-contained. No new field, no separate flag, no side-channel.

### Equipment as derived state on `Stats`

Rather than giving equipment its own attack/defense multiplier, fold
the bonus into `Stats.attack_bonus` / `Stats.defense_bonus` whenever
equipment changes. `recompute_stats_from_equipment(world, entity)`
walks `Equipment` + `Inventory` once and writes the totals. Combat
code (`resolve_attack`) stays oblivious to inventory.

This is the **same shape as `recompute_fov`**: derive viewshed state
from position + dungeon at the moment something changes, not on every
read. Combat doesn't need to know about Equipment; it just reads Stats.

### Window parity extended to modals

v0.5.5/v0.5.6 fixed window parity between visual highlight and action
window (5-tile pickup). v0.5.7 extends the same idea to UI surfaces:
the inventory modal MUST offer actions for every item kind it can
display. Specifically:

- Displayed: 8 slots, weapons tagged `[W]`, armor tagged `[A]`, potions, gold.
- Actions: `u` (use, potion-only — "장비는 (e) 키로 장착하세요."), `e`
  (toggle equip, weapon/armor only), `d`/`x` (drop), `Enter` (default —
  use for potions, toggle for equipment).
- Empty slot: explicitly log "빈 슬롯입니다." rather than silently doing
  nothing, so the user gets feedback when they hit `Enter` on the wrong
  row.

If the modal listed weapons but had no equip action, the same
window-mismatch bug class would re-surface in UI form. The checklist
for any new modal:

1. List what kinds of thing the modal can show.
2. For each kind, define what action keys do.
3. For each kind, decide what happens on `Enter` (the "default" key).
4. Empty/no-op state must produce an explicit message, not silence.

### Re-export `core` types when binary needs them

The binary crate (`crates/app/src/main.rs`) needs to construct and
match on `ModalMode` and `EquipSlot` directly. Adding `pub use
asciirogue_core::EquipSlot;` at the top of `lib.rs` is the smallest
change that makes `use asciirogue::EquipSlot;` work in the binary. Do
NOT re-export the whole `asciirogue_core::*` — pin to the specific
type the binary needs, so the binary's dependency surface stays
narrow.

**E0252 trap**: if the inner `use asciirogue_core::{ ..., EquipSlot,
... }` already imports the same name, you get `the name \`EquipSlot\`
is defined multiple times`. Drop it from the inner `use` block,
keep only the `pub use`. Symptom is unmistakable; the fix is mechanical.

### `equip_inventory_at` swap bug (caught only by test)

User reported no symptom — the bug was discovered by running the
v0.5.7 test suite. The original code did this when the player
equipped weapon A over an already-equipped weapon B:

```rust
// BROKEN:
if let Some(prev_item) = inv.take(prev_idx) {
    if inv.put_at(idx, prev_item.clone()).is_err() {
        let _ = inv.push(prev_item);
    }
}
// then later:
if inv.put_at(idx, item).is_err() { return Err("full"); }   // ← fills idx
```

`prev_idx == 1`, `idx == 2`, so step 1 happily puts the old dagger into
slot 2 (which was empty because we `take(2)`'d the axe first). Then
step 2 tries to put the axe into slot 2 — but the dagger is there.
`put_at` returns Err, the function returns early, **the weapon slot
still references slot 1, the dagger is "swallowed" into slot 2 with
no Equipment record**, and the player's Stats never update.

Correct shape — never write to `idx` while it's the destination of the
new item:

```rust
// CORRECT:
let mut placed = false;
for (i, slot) in inv.slots.iter_mut().enumerate() {
    if i != idx && slot.is_none() {
        *slot = Some(prev_item.clone());
        placed = true;
        break;
    }
}
if !placed {
    drop(inv);  // release the borrow before world.spawn
    // drop on the player's tile; fall back to any free slot; fall back
    // to overwrite idx (the player loses the old item but keeps the new).
}
```

**Carry-forward**: any function that takes `Item` out of a slot and
puts another back in has a "swap collision" risk. The mental check is
**"while holding the new item, where can the old one go? — never into
the destination of the new item."**

### Borrow checker trap with `world.spawn` mid-iteration

The naive "drop on floor if no room" branch above initially didn't
`drop(inv)` before calling `world.spawn`. Compiler error was:

```
error[E0502]: cannot borrow `*world` as mutable because it is also
             borrowed as immutable
  --> .../lib.rs:1205:25
   |
   | let mut inv = world.get::<&mut Inventory>(player).ok()?;  // mutable borrow
   | ...
   | world.spawn((...));  // ← second mutable borrow, conflict
```

The `hecs::RefMut<Inventory>` lives until end of scope. Spawning new
entities touches the world's archetype storage, so the borrow checker
correctly rejects the overlap. Drop the borrow first, then spawn.

**Carry-forward**: any code path that wants to `world.spawn` or
`world.despawn` after taking a `&mut Component` borrow needs an explicit
`drop(...)` line in the middle. Don't try to scope-curl it — Rust's
NLL is conservative with `hecs::RefMut` specifically.

### Item::clone discipline (twice in one function)

`Item` is not `Copy`. In `equip_inventory_at`'s swap fallback we needed
two survivors (the slot gets the new item; the old item needs to land
somewhere). The naive `inv.put_at(idx, prev_item)` followed by
`inv.push(prev_item)` fails to compile — `prev_item` was moved.

Pattern: `inv.put_at(idx, prev_item.clone()).is_err()` → on Err, push
the original. Same pattern surfaces in `unequip_slot` when the
original slot is full. The `drop(inv)` between the two mutations
matters because `prev_item.clone()` needs `&prev_item` while
`put_at` takes `Item` by value.

**Carry-forward**: any ECS function that mutates two collections on
the same entity needs an explicit mental count of how many survivors
of each `Item` it needs. Default to `clone()`; rewrite to a single
owner only when the borrow checker forces it.

## v0.5.8 — keyboard remap: `i` = inventory, `p` = quick potion

User feedback (2026-07-29, fifth session message): "인벤토리 단축키는
소문자 i 포션은 다른 키로 배정해줘 ... 인벤토리는 i 포션은 p로 해줘"

The v0.5.7 default (uppercase `I` for modal, lowercase `i` for
quick-potion) was backwards — the modal is the common action and
should be the unshifted key. Three-line patch in
`crates/app/src/main.rs`:

```rust
// was:
KeyCode::Char('i') | KeyCode::Char('I') => {
    if let Some(msg) = use_first_potion(...) { self.log(msg); } else { ... }
}
KeyCode::Char('I') => { /* open modal */ }

// becomes:
KeyCode::Char('i') => { /* open modal */ }
KeyCode::Char('p') => {
    if let Some(msg) = use_first_potion(...) { self.log(msg); } else { ... }
}
```

`i` now opens AND closes the modal (toggle) because the modal-local
dispatcher already accepts `Esc | 'i' | 'I' | 'q'` as close keys
(v0.5.7 added `I` for Shift-i muscle memory; v0.5.8 adds `i` for
natural extension).

### The touch-everywhere pattern (keyboard remaps are not 3 lines)

The actual patch touched **6 places** in the repo, not 3:

| Location | What needed updating |
|---|---|
| `crates/app/src/main.rs` handle() | key→action mapping |
| `crates/app/src/main.rs` draw() | footer hint string |
| `crates/app/src/main.rs` draw_inventory_modal() | modal title text |
| `crates/app/src/lib.rs` startup_msg (×2: bin + lib) | floor-entry banner |
| `crates/app/src/lib.rs` `?`-help log | in-game help burst |
| `README.md` + `docs/SPEC.md` | key reference tables |

All 6 places needed updating in the same commit. Forgetting any of
them leaves the user with the new key working but no documentation
that says so. **Grep the literal old key string across the whole
crate before declaring a remap done:**

```bash
rg --no-heading "Char\('i'\)" crates/
rg --no-heading "'i '" crates/
rg --no-heading "포션" crates/ README.md docs/
```

Then update each hit. This is the **same discoverability gap** that
caused the missing `> descend` hint in v0.5.7 — if the help text
doesn't mention a key, the user has no in-game way to know it exists.

### Modal-dispatcher close-keys have an asymmetric two-mode behaviour

When `App::handle` is at the top level (modal closed), only the
keys defined in the main `match` block dispatch. When the modal is
open, `handle_inventory_key` is the only dispatcher. So a key like
`I` (uppercase i) works **only** inside the modal — pressing `I`
at the top level does nothing, because the top-level match has no
`Char('I')` arm.

The first cut of `test_inventory_modal_open_close` for v0.5.8 tried
to assert `Char('I')` opens the modal — failed. The test then
corrected itself: `I` is a **close-only** key from inside the modal.

**Carry-forward**: when writing a modal test, phase-by-phase:

1. From `Closed`: the dispatcher's **open** keys fire.
2. From `Open`: the modal-local dispatcher's **all** keys (open,
   close, action, navigation) fire.
3. From `Closed` again: confirm the modal stays closed for keys
   that are only valid inside it.

A single-end-state test that just asserts "modal opens on i and
closes on Esc" misses mode 3 entirely.

### Test coverage for the remap

Two new tests (in `crates/app/src/main.rs`):

```rust
fn test_p_key_quick_potion() { /* 'p' heals HP, consumes potion,
                                  does NOT open the modal */ }

fn test_inventory_modal_open_close() { /* 4 phases:
    1. i opens
    2. i closes (toggle)
    3. i opens, Esc closes
    4. i opens, Shift-i (uppercase) closes (muscle memory) */ }
```

Total suite: 50 tests, all green. The four-phase modal test is what
caught the mode-3 mistake above.

### Keyboard remap is not 3 lines — see references

The "patch the dispatcher and call it done" mental model misses
footer hint, modal title, startup banner (×2), `?`-help burst (×2),
README table, and SPEC table. See
`references/keyboard-remap-touch-everywhere.md` for the full
checklist + grep recipe + test phase pattern.

## v0.5.11 — Stairs confirmation popup (replacing the `>` hotkey)

User feedback (2026-07-29): "다음층 이동을 단축키로 하지 말고, 접근하면
이동할 지 않할지 팝업으로 선택하는건 어려울까?"

The v0.5.10 gate kept `>` as a hotkey but required the player to be on
the stairs. That still had a "wrong-key-then-I'm-on-floor-2" risk and
zero ceremony for the spend. The user asked for a **tile-triggered
confirmation popup** instead of a hotkey. Shipped as commit `44f263f`,
64 tests, all green.

### The redesign: hotkey → tile-triggered modal

OLD shape (v0.5.10):
- `>` key listens while modal is Closed
- checks `matches!(dungeon.at(player_pos), Tile::StairsDown)`
- descends if true, else logs MsgStairs

NEW shape (v0.5.11):
- `try_player_act` walks onto StairsDown → sets `modal = ModalMode::ConfirmStairs`
- `App::handle`'s first check is `if matches!(self.modal, ModalMode::ConfirmStairs) { ... }`
- Modal-owned key dispatcher: `y`/`Enter` → descend, `n`/`Esc` → cancel, others ignore
- The `>` key dispatch is **removed entirely** from the main match block

The trade-off: the user can no longer accidentally descend. Two
keystrokes (walk + y) replaces one (`>`), but the ask-then-confirm
ceremony matches what the user actually asked for.

### ModalMode::ConfirmStairs — the third variant

```rust
#[derive(Copy, Clone, Debug, Eq, PartialEq)]
pub enum ModalMode {
    Closed,
    Inventory { cursor: usize },
    /// v0.5.11: "▼ 다음 층으로 내려갈까?" — y/Enter = descend, n/Esc = cancel.
    ConfirmStairs,
}
```

No new field on App — the modal enum already carried the open state.
The new variant just needed its own key dispatcher. **Pattern: any
new modal is a new enum variant, not a new flag.** This keeps the
state shape compact and the dispatcher branch-by-variant.

### descend_internal() — extract the shared path

The v0.5.10 `>` handler, the v0.5.11 ConfirmStairs modal handler, and
a future `--dump` probe all need the same descent logic. Pulled it
into a method:

```rust
fn descend_internal(&mut self) {
    let next_floor = self.floor + 1;
    if self.floor == BOSS_FLOOR && !self.boss_defeated {
        self.log(i18n::t_for(I18nKey::MsgBossFirst, self.locale));
        return;
    }
    if next_floor > MAX_FLOORS {
        self.log(i18n::t_for(I18nKey::MsgAlreadyAtBottom, self.locale));
        self.remembrance.on_run_end(MAX_FLOORS, self.gold, 1);
        let _ = save_remembrance(&self.remembrance);
        self.log(format!(
            "쏠쏠리의 방 클리어! clears={}, soul_wisps={}",
            self.remembrance.clears, self.remembrance.wisps,
        ));
        return;
    }
    let args: [&dyn std::fmt::Display; 1] = [&next_floor as &dyn std::fmt::Display];
    let msg = t_format_with_locale(I18nKey::MsgStairDescendOk, self.locale, &args);
    let rem = self.remembrance.clone();
    let locale = self.locale;
    let gold = self.gold;
    let seed_save = self.seed;
    *self = App::new_at_with(seed_save, next_floor, rem, locale, gold);
    self.log(msg);
}
```

Caller (`handle` ConfirmStairs branch) is responsible for setting
`modal = ModalMode::Closed` first; this method only handles the
floor transition + reward/last-floor logic. Single-path means
future i18n or reward tweaks happen in one place.

### THE big structural trap: main.rs and lib.rs each have their OWN App

This is the second time the asciirogue skill has hit this, and the
first time it bit hard. The workspace has:

- `crates/app/src/lib.rs` — `pub struct App { ... }` with `pub fn` methods
- `crates/app/src/main.rs` — `struct App { ... }` with `fn` methods (DUPLICATE)

Same enum, same Handle logic, same draw function, same `ModalMode`.
**Any feature change must be applied to BOTH files.** v0.5.11 edits
hit all five of these in main.rs:

1. `ModalMode::ConfirmStairs` variant (or import from lib.rs)
2. `try_player_act` end-of-function — stairs arrival detection
3. `handle` ConfirmStairs modal branch
4. `draw` ConfirmStairs overlay dispatch
5. `>` key handler — REMOVED

Plus the helper `descend_internal()` needs adding to both `impl App`
blocks. Plus the `?`-help log line + startup_msg reference to `>`
need scrubbing.

**Carry-forward**: when adding a feature to this project, **always
grep for the feature in both lib.rs AND main.rs**. The lib.rs/App
is what the tests exercise; the main.rs/App is what the binary
ships. They drift after every feature change unless you edit them
together.

```bash
rg "ModalMode::Inventory" crates/app/src/lib.rs crates/app/src/main.rs   # sanity check
rg "KeyCode::Char\('>'\)" crates/app/src/lib.rs crates/app/src/main.rs   # pre-removal
```

### Modal input lock — the "ConfirmStairs owns input" invariant

While `ConfirmStairs` is open, ALL gameplay keys must be inert. The
modal dispatcher **returns early** after handling its keys:

```rust
if matches!(self.modal, ModalMode::ConfirmStairs) {
    match k.code {
        KeyCode::Char('y') | KeyCode::Char('Y') | KeyCode::Enter => {
            self.modal = ModalMode::Closed;
            self.descend_internal();
        }
        KeyCode::Char('n') | KeyCode::Char('N') | KeyCode::Esc => {
            self.modal = ModalMode::Closed;
            self.log(i18n::t_for(I18nKey::MsgStairCancel, self.locale));
        }
        _ => { /* ignore everything else */ }
    }
    return;  // <- CRITICAL: never fall through to main match
}
```

`return` (not fall-through) is what stops the `h`/`j`/`k`/`l` from
also being interpreted as movement. The `Inventory` modal has the
same shape from v0.5.7. **Modal dispatcher always early-returns.**

**Test it**: `other_keys_in_confirm_are_ignored` in
`confirm_stairs_tests` simulates pressing `h` while the modal is
open and asserts `modal == ConfirmStairs` afterwards. The test
would have caught a missing `return` in the dispatcher.

### 8 confirm_stairs tests cover the full matrix

```rust
let mut app = App::new_at(0xCAFE_BABE_DEAD_BEEF, 1);
let (sx, sy) = put_player_on_stairs(&mut app);   // helpers in test module
clear_items(&mut app, sx, sy);                  // floor the tile
app.modal = ModalMode::ConfirmStairs;           // simulate arrival
app.handle(&char_event('y'));                   // <- the test input
```

The pattern:
1. Build a fresh app with the v0.5.9 seed
2. Helper `put_player_on_stairs` teleports the player to the last
   room's center (where BSP placed the StairsDown tile)
3. Helper `clear_items` despawns any Item entities on that tile
   (otherwise `pick_up_outcome` during auto-pickup could despawn
   the gold that BSP also placed there)
4. Set `modal = ModalMode::ConfirmStairs` directly (bypasses the
   walk-onto path which needs ratatui runtime)
5. Call `app.handle(&event)` with the test input
6. Assert on `app.floor`, `app.modal`, `app.messages`

8 tests covering: y descends, Enter descends, n cancels, Esc
cancels, h (movement) ignored, `>` does nothing (the removed hotkey),
modal opens on stairs arrival, modal closes on cancel.

### Cargo test --workspace panics in DEBUG on this project's seed math

`cargo test --workspace` (debug build) panicked:

```
thread '...' panicked at crates/app/src/lib.rs:112:27:
attempt to multiply with overflow
```

The line is `seed.wrapping_add(floor as u64 * 0x9E37_79B9_7F4A_7C15)` —
the `floor * 0x9E37_79B9_7F4A_7C15` doesn't wrapping_mul, so it
panics when `floor` is large enough. Debug builds check for overflow;
release builds do not.

**Fix: use `cargo test --workspace --release` for this project.**
The asciirogue README should mention this. Until the seed math
gets `wrapping_mul`, every test invocation needs `--release`.

This is a project-specific pitfall, not a general Rust lesson, but
the next session trying `cargo test --workspace` will hit this
exact line and lose 5 minutes debugging.

### Reading the v0.5.11 commit as a recipe

The 391-insertion commit touches 5 files in this order:

1. `crates/core/src/i18n.rs` — 3 new keys (MsgStairConfirm,
   MsgStairDescendOk, MsgStairCancel)
2. `crates/app/src/lib.rs` — ModalMode variant, arrival detection,
   ConfirmStairs dispatcher, descend_internal helper, draw overlay,
   8 tests (~270 lines added)
3. `crates/app/src/main.rs` — mirror of every lib.rs change + help
   text scrub + startup_msg scrub
4. `README.md` — control table updates `>` row → `y`/`n` row
5. `CHANGELOG.md` — v0.5.11 section

`git diff --stat` after v0.5.11: 5 files, +391/-64. The `+391` is
dominated by lib.rs (ModalMode + arrival + dispatcher + overlay +
descend_internal + 8 tests + extends) and main.rs (mirror). The
test count of 8 is the floor — any future modal-confirm feature
should match it.

### Carry-forward: any modal triggered by physical location

The ConfirmStairs pattern generalises to:
- Boss-room entry (arrive at boss-room door → "보스 방에 진입?")
- Shop counter (arrive at shop tile → "상점 입장?")
- Save point (arrive at shrine → "영혼 저장?")
- Trap reveal (step on a hidden pressure plate → "함정! 회피? y/n")

All four follow the same shape: physical event sets `modal = X`,
modal owns input, y/Enter confirms, n/Esc cancels, no global key
bypass. The enum's variant count grows by 1 per modal, but the
dispatcher is always the same `if matches!(self.modal, ModalMode::X)`
early-return gate.

## How to apply

```python
from hermes_tools import skill_view
skill_view(name='rust-roguelike-development')
skill_view(name='rust-roguelike-development',
           file_path='references/roguelike-feedback-triaging.md')
skill_view(name='asciirogue-devpitfalls-2026-07')
```

Edit guard: any time you touch `ai::take_turn`, `attack::resolve_attack`,
or `App::on_death`, add a regression test for each of the five bug
classes before merging. Save the screenshot + user's quote + the fix
as a commit-body triple — three months later, the quote is the only
context that survives.

## Carry-forward: when adding ANY new bypass resource


User feedback (2026-07-29, seventh session message): "골드가 인벤토리
슬롯에는 없어도 얼마인지 표시는 되어야지. 화면상에 골드를 표시해줘."

v0.5.9 routed gold through `App::gold` instead of Inventory, but
nowhere in the UI showed the running total. The header still read
`HP 38/40  MP 15/15` and the inventory modal listed only the 8 slots —
so the player could collect gold for a whole floor and never know how
much they had.

### The "display-side parity" rule for bypass resources

When an item bypasses inventory (gold, XP, keys, soul currency, …),
**the running total must appear on both**:

1. **Header / status bar** — always visible, glanceable. Format next to
   HP/MP: `G 27` for gold.
2. **Detail modal** (inventory, character sheet, …) — explicit listing
   with a meaningful label like "보유 골드: 27".

Picking only one surface recreates the same discovery gap that v0.5.7
hit with the missing `> descend` hint: the resource exists, but the
user has no in-game way to know its state.

### Concrete patch in asciirogue

Two header sites (one for each App struct — lib.rs and main.rs each
have their own `App`):

```rust
// crates/app/src/main.rs (and the mirror in crates/app/src/lib.rs)
let hp_mp = if let (Ok(h), Ok(m)) = (
    self.world.get::<&Health>(self.player),
    self.world.get::<&Mana>(self.player),
) {
    format!(
        "HP {}/{}  MP {}/{}  G {}",
        h.current, h.max,
        m.current, m.max,
        self.gold            // ← new: gold bypasses inventory, so it
                             //    can't be inferred from the slot list
    )
} else {
    format!("?  G {}", self.gold)
};
```

Modal patch in `draw_inventory_modal`:

```rust
// In the equipped/stats panel — extended to 3 lines:
Constraint::Length(10), // slot list
Constraint::Length(1),  // spacer
Constraint::Length(3),  // equipped + stats + gold
Constraint::Min(1),    // controls

// In the eq_lines block:
if let Some(s) = stats {
    lines.push(Line::from(format!(
        "공격 보너스: {:+}    방어 보너스: {:+}    보유 골드: {}",
        s.attack_bonus, s.defense_bonus, self.gold
    )));
} else {
    lines.push(Line::from(format!("보유 골드: {}", self.gold)));
}
```

### Touch-everywhere-again: bypass resources inherit the remap rule

Adding "show gold on screen" looks like 2 lines of edits but actually
touched:

| Location | What needed updating |
|---|---|
| `crates/app/src/main.rs` `draw()` `hp_mp` block | `G N` after `MP x/y` |
| `crates/app/src/main.rs` `draw_inventory_modal()` | equipped panel line, chunk heights |
| `crates/app/src/lib.rs` `draw()` `hp_mp` block | mirror for `--dump` mode |
| `README.md` | note that gold bypasses inventory |

Same as v0.5.8's keyboard-remap touch-everywhere pattern: a "show
X on the UI" change has to grep through the same 4–6 locations
to land cleanly. The pattern is **"state-with-no-home lives in
multiple surfaces"** — find them all before declaring done.

### Header Probe verifies without TTY

`crates/app/examples/header_probe.rs` (from v0.5.5) was already
generating the full header string in plain Rust. After the v0.5.10
patch, `cargo run --example header_probe -p asciirogue` prints
`HP 40/40  MP 15/15  G 0  pickup: ↑ $ 2 ...` — the `G 0` is the
right format with the new code. The probe was already in the right
shape; no edits needed because the helper function was reading from
the same struct fields as `App::draw`.

### Where to put the bypass counter

For gold, header gets `G N`. For other bypass resources:

| Resource | Header form | Modal form |
|---|---|---|
| Gold | `G 27` | `보유 골드: 27` |
| XP / souls | `XP 1240` | `경험치: 1240` |
| Keys (per-key) | `K 2` | `열쇠: 2` |
| Ammo (per-type) | — (too long) | `화살: 18 / 마법탄: 4` |

Header can hold at most 2–3 single-letter counters before becoming
noisy (`HP MP G XP K`). If more than 3 bypass types exist, drop the
header counter and keep only the modal — the player will hit the
modal when they need to know.

### Carry-forward: when adding ANY new bypass resource

1. Add the `App::gold`-style out-parameter / field on the appropriate
   struct (wallet for currencies, soul-counter for meta-currency, etc).
2. Update pickup / drop / use paths to fold into it (mirror the
   v0.5.9 out-parameter shape).
3. **In the SAME commit**, surface it on the header AND the
   relevant modal. Otherwise the user reports "I can't see how much
   I have" — exactly the v0.5.10 trigger.
4. Add a header_probe assertion (or extend the existing one) so the
   format stays consistent across refactors.

This is the v0.5.9 follow-up that the gold-bypass pattern implicitly
assumed but never spelled out. Future bypass resources should ship
the display half in the same commit as the storage half.



### The general pattern

Some game items **should not occupy bag slots** even when picked up:
gold (wallet), ammo / consumables with infinite stacks, currencies,
keys / quest tokens that are tracked separately, "souls" / meta-currency.
The classic roguelike mistake is treating these like regular items and
eating into the limited 8-slot bag, so a level-3 floor full of coins
leaves no room for the heal potions the player actually needs.

**The shape that works in ECS**:

1. The pickup function gets an **out-parameter** for the bypassed
   item's value:
   ```rust
   pub fn pick_up_outcome(
       world: &mut World,
       player: hecs::Entity,
       gold_gained: &mut u32,    // ← out-parameter
   ) -> PickupOutcome
   ```
2. Inside, items are split into two collections (gold vs non-gold).
   Gold is despawned immediately; its bonus accumulates into
   `*gold_gained`. Non-gold items take the existing Inventory path.
3. The **caller** (`App::handle`, auto-pickup in `try_player_act`)
   folds `gold_gained` into `App::gold` after the call returns:
   ```rust
   let mut gold_gained: u32 = 0;
   match pick_up_outcome(&mut self.world, self.player, &mut gold_gained) {
       PickupOutcome::Picked => {
           self.gold = self.gold.saturating_add(gold_gained);
           if gold_gained > 0 {
               self.log(format!("골드 +{}!", gold_gained));
           } else {
               self.log("아이템을 주웠습니다.");
           }
       }
       // ...
   }
   ```

The pure-function (`pick_up_outcome`) stays ignorant of the wallet;
the impure caller (`App`) is where the wallet lives. This split is
what makes the function probe-testable in isolation — see
`references/gold-bypass-pattern.md` for the full probe + test suite.

### Why out-parameter beats an enum return

Three alternatives were considered:

| Option | Problem |
|---|---|
| Return `(PickupOutcome, u32)` tuple | Breaks every existing call site; one extra line per call. |
| Add `PickupOutcome::PickedGold(u32)` variant | Forces callers to match on a different enum arm even when gold is 0. |
| Have `pick_up_outcome` mutate `App::gold` directly | Couples the pure helper to `App`; cannot unit-test the helper without an App. |
| **Out-parameter `&mut u32`** ✅ | Callers decide whether to fold into the wallet; probe/test code can ignore the wallet by passing a throwaway `let mut g = 0;`. |

### Mixed-pickup still works

If the 5-tile pickup window contains both gold and a potion, both
fire in the same call:

- gold → `gold_gained += n`, ground entity despawned
- potion → pushed into the first free inventory slot
- returned `PickupOutcome::Picked`
- caller logs both events separately

The probe confirms this in `pickup_probe.rs` Scenario D. The
split-into-two-collections shape preserves the existing
`PickupOutcome::Picked` return value, so any caller that already
handled "I picked something up" keeps working.

### Accessor + E0252 trap rolls forward to v0.5.9

`App::gold()` was added so tests and probes can read the wallet
without going through private fields. The `pub use` trap recurred:

```rust
// crates/app/src/lib.rs
pub use asciirogue_core::EquipSlot;   // v0.5.7 line — still here
// inner use:
use asciirogue_core::{ ..., EquipSlot, ... };   // ← E0252 collision
```

Fix is the same as v0.5.7: drop the duplicate from the inner `use`
block, keep only the `pub use`. Adding the v0.5.9 `gold()` accessor
required the same surgery in `crates/app/src/main.rs` because the
binary defines its own `App` struct (lib.rs and main.rs each have
their own copy).

### Carry-forward: probe-vs-App-state

When a probe tests `pick_up_outcome` directly, `App::gold` does NOT
auto-increment — the function returns the value via `&mut gold_gained`
and the caller (the App) is what folds it. Probes that want to
assert the full pipeline need to do the fold themselves:

```rust
let mut gold_gained: u32 = 0;
let outcome = pick_up_outcome(app.world_mut(), player, &mut gold_gained);
let wallet_after_simulated_pickup = app.gold() + gold_gained;
assert_eq!(wallet_after_simulated_pickup, app.gold() + gold_gained);
```

This is a feature, not a bug — it lets the probe test **both** the
pure helper (wallet math) and the App-level wiring (wall display,
auto-pickup on step) independently.

### Legacy Coin in inventory

`use_inventory_at` had a Coin branch from v0.5.7. Since v0.5.9 gold
never enters the inventory, this branch is effectively dead. We
kept it as a no-op with an explicit "v0.5.9 이전 데이터 — 자동
전환됨" message rather than deleting it — if a save file is
migrated from v0.5.8 the player gets a visible note instead of
silent gold loss.

### Edit guard addition

Any time you add a new **stackable / wallet / counter** item kind
(ammo, souls, keys, …), check first: should it bypass the inventory
like gold does? If yes, follow the same out-parameter shape. If no,
make sure it can't accidentally be treated like the bypass kind
(e.g. `ItemKind::Ammo` is a Coin-shaped bypass; `ItemKind::Arrow`
is a regular 1-slot item).

### What the user sees

Walking onto a gold `$`:

```
[before pickup]   gold: 0    inventory: [_, _, _, _, _, _, _, _]
[k (Up)]          gold: 0    inventory: [_, _, _, _, _, _, _, _]
                                                 ↑ gold at (12,20)
[after pickup]
  → "골드 +7!"
  → gold: 7    inventory: [_, _, _, _, _, _, _, _]
```

Press `g` next to the same gold before stepping onto it:

```
  → "골드 +7!"
  → gold: 14   inventory: [_, _, _, _, _, _, _, _]
```

Both paths converge to the same wallet state. Inventory stays empty
of gold regardless of how the pickup happened (auto on step, manual
`g`, `,` alias, or Shift+4).

### References

- `references/gold-bypass-pattern.md` — full probe + 4 scenarios,
  test suite, common mistakes.
- `references/keyboard-remap-touch-everywhere.md` — companion skill
  for "remap a key" workflow; the v0.5.9 pattern adds a new touch
  point: the README control table should mention that gold bypasses
  inventory, otherwise users will assume `$` goes into a slot.

## v0.5.10 — StairsDown visible & gated (the descent finally has a glyph)

Three changes in one commit, all about the `>` descend key:

1. New `Tile::StairsDown` variant — placed by BSP in the last room.
2. `>` key is now location-gated (must stand on `StairsDown`).
3. Header gets a `stairs: ↘ ▼ N` hint with a generous BFS cap.

### `Tile` enum additions break every `match` arm — 全行 점검

Adding `StairsDown` to `Tile` forced a fresh compile error in every
match site. Concretely: any `match tile { Wall, Floor, Rock => … }`
became non-exhaustive. Three sites needed patching:

- `lib.rs:1601` (draw_map + dump_to_stdout)
- `main.rs:1501` (draw_world)
- `crates/procgen/examples/dump.rs:14` (headless dump)

The cargo error message lists every site, so the fix is mechanical —
but the lesson is: **when extending an enum, run `cargo build` once
to see every match site, then fix them all in one pass.** Adding
to an enum is structurally similar to adding a field to a struct:
a single cargo build catches every break site, no grep required.

### `Tile::StairsDown` placement — last room, not random

The natural-looking option ("place StairsDown anywhere on a Floor
tile") is wrong — it has a 50/50 chance of landing in a corridor
or hidden under an item, with no visual rule. The chosen rule:

```rust
// crates/procgen/src/bsp.rs
if let Some(last_room) = rooms_snapshot.last() {
    let (cx, cy) = last_room.center();
    dungeon.set(cx, cy, Tile::StairsDown);
}
```

BSP's `collect_rooms` walks left/right subtree, so the last room
is the rightmost leaf — farthest from the player's spawn (first
room). This gives the descent a consistent spatial identity:
*spawn here, descend over there*. Verified on 5 seeds
(0xCAFE_BABE_DEAD_BEEF, 0x1234, 0xDEAD, 0xC0FFEE, 42) — every
floor has exactly one `StairsDown` at the last room's center.

**Boss caveat**: a future Boss spawn at the last room will sit
on the `StairsDown` tile. That's fine visually (boss on top of
stairs reads as "you have to kill this to descend") and the
`>` key still requires the player to be on the tile, so the boss
will be in the way. When the boss dies, the player walks onto
the now-empty `StairsDown` and can descend.

### `>` key — three-tier gating

The v0.5.7 handler was a 3-branch monster:

| Tier | Old gate | New gate |
|---|---|---|
| 1 | `floor == BOSS_FLOOR && !boss_defeated` | same |
| 2 | `next_floor > MAX_FLOORS` | same |
| 3 | (none) | **`can_descend` = stand on `StairsDown`** |

Tier 3 was added as a NEW gate that runs BEFORE the existing tier 1/2
checks. The combined handler:

```rust
let can_descend = if let Ok(pos) = self.world.get::<&Position>(self.player) {
    matches!(self.dungeon.at(pos.0.0, pos.0.1), Tile::StairsDown)
} else {
    false
};
if !can_descend {
    self.log(i18n::t_for(I18nKey::MsgStairs, self.locale));
    return;
}
// ... existing boss / bottom logic
```

The new i18n keys (`MsgStairs`, `MsgBossFirst`, `MsgAlreadyAtBottom`)
replace the old hard-coded Korean strings. Already in
`crates/core/src/i18n.rs` from earlier sessions — `t_for(Key::MsgStairs,
locale)` returns `"주위에 계단이 없습니다."` for Korean and
`"There are no stairs here."` for English.

### TWO BFS distance constants, not one

`pick_up_outcome` already had `MAX_PICKUP_SEARCH = 24` (tight — items
out of sight shouldn't clutter the header). When `nearest_stairs_info`
was added, **the logic for stealing this constant was wrong**:

```rust
// BROKEN: copy-pasted MAX_PICKUP_SEARCH into stairs function
if d >= MAX_PICKUP_SEARCH { break; }   // 24 cut stairs off at 24
```

Why it's wrong: 1st-room center to last-room center on a 60×24 map
is Manhattan ~31. The very first probe assertion caught this:

```
thread 'returns_some_when_stairs_within_radius' panicked at …
stairs must be reachable from first room
```

The fix is two constants, one per use case:

```rust
/// BFS distance caps. Tuned differently for items vs. stairs:
const MAX_PICKUP_SEARCH: usize = 24;   // hide items far away
const MAX_STAIRS_SEARCH: usize = 999;  // always show the descent
```

Rationale: items are abundant and noisy (multiple on a floor).
Stairs are exactly one per floor — always showing its direction
is more useful than hiding it past 24 tiles. The user's MEMORY
file even has a related rule: "bypass resources live in both
header + modal"; the stairs hint is the same idea extended to
"single-instance resources are always visible".

**Carry-forward**: when adding a new BFS-distance-based hint
(XP nearest mob, nearest shop, …), ask first: is X abundant or
exactly-one-per-floor? Abundant → tight cap (24); exactly-one
→ generous cap (999). Don't share a constant between two
use cases that have different UI goals.

### Header probe works, but `--dump` doesn't

`crates/app/examples/header_probe.rs` (from v0.5.5) renders the
exact header string in plain Rust — confirming `G 0` shows up
correctly. But the **floor map** dumper (`cargo run --dump
--seed 0xCAFE --count 1`) only draws tiles within `VIEW_RADIUS = 5`
of the player. The last room's center is at (54, 20); the player
spawns at (7, 4). Man distance ≈ 63 — way past 5.

So the new `▼` glyph **wasn't visible in the dump output on the
first try**. The verification path that caught this:

```rust
// crates/procgen/examples/stairs_check.rs (one-shot, then deleted)
let d = bsp::generate(60, 24, seed, bsp::Config::default());
let last = d.rooms.last().unwrap();
let (cx, cy) = last.center();
assert!(matches!(d.at(cx, cy), Tile::StairsDown),
        "stairs must be in last room");
```

This is a useful pattern: **`cargo run --dump` is not enough for
floor-wide verification. For new tiles, write a one-shot example
that places the camera at the destination tile and dumps again.**

Better: extend `dump` with a `--reveal` flag that bypasses VIEW_RADIUS
for any test that needs full coverage. Not done yet — for now the
one-shot example is the workaround.

### Compounded risk: code with literal `+` prefixes from a previous patch

The session inherited a lib.rs / main.rs diff from a previous session
that left **`+` literal characters at the start of patch output lines**
— i.e. the diff lines were committed into the file. When the new
session tried to `patch` those lines again, the new `patch` saw the
old `+` content as the *first line of the old_string* and tried to
match a longer block, which then chained into the new content,
resulting in nested duplicated lines.

Concrete example from session start (lib.rs:312):

```rust
KeyCode::Char('>') => {
    let can_descend = if let Ok(pos) = self.world.get::<&Position>(self.player) {
+                            matches!(self.dungeon.at(pos.0 .0, pos.0 .1), Tile::StairsDown)
+                        } else {
+                            false
+                        };   // ← `+` prefix is in the FILE, not in a diff
```

The compile error was:

```
error: expected expression, found `+`
   --> crates/app/src/lib.rs:315:1
    |
315 | +                            matches!(self.dungeon.at(...), Tile::StairsDown)
    | ^ expected expression
```

**Fix pattern**: `read_file` of the affected region WITH `offset`/`limit`
first, then use `patch` with the EXACT current text (without any `+` or
`-` prefix). If the file still contains malformed text, the fix is
ONE BIG `patch` that replaces the whole malformed block with corrected
code — not multiple small patches that chain on top of the broken state.

This is the same anti-pattern as `patch-line-context-safety` skill's
함정 A (compound context); the new lesson is to **read the file before
patching** when the file was last edited in a previous session.

**Carry-forward**: at session start, if `git diff` shows a large
uncommitted delta and the file is in a state where previous patches
left literal `+`/`-` lines, do NOT trust the delta. Re-read the file
sections you intend to patch. Treat the previous session's output as
untrusted.

### Probe vs. test coverage for the 5 new tests

The v0.5.10 commit added 5 tests:

```
stairs_info_tests::returns_some_when_stairs_within_radius   ✅
stairs_info_tests::returns_zero_when_standing_on_stairs    ✅
stairs_info_tests::returns_none_when_player_impassable     ✅
stairs_gate_tests::gate_blocks_descend_when_not_on_stairs   ✅
stairs_gate_tests::gate_permits_descend_when_on_stairs      ✅
```

Note the **gate test doesn't actually call `handle()`** — it tests
the precondition `matches!(dungeon.at(player_pos), Tile::StairsDown)`
directly. Cheap, deterministic, doesn't need a TTY. The same shape
will apply to any future location-gated action (boss-room entry,
shop access, dialogue trigger).

### StairsHint 자기-위치 상태 — the "always reachable" rule

A subtle UX point: when the player is on the stairs, `nearest_stairs_info`
returns `Some((0, Direction::None, '▼'))`. The header renders this
as `stairs: · ▼ 0` — which **collides with the pickup hint format**
(`pickup: ↑ $ 6`). The `·` (None) arrow is the only visible cue that
the player is standing on the stairs.

The header now reads:

```
asciirogue — seed X  1F 동굴  player (54,20)  visible 12  stairs: · ▼ 0  pickup: ↑ $ 5  HP 40/40  MP 15/15  G 0
```

The `· ▼ 0` is the "you are standing on stairs, press `>` to descend"
signal. Players who see `↘ ▼ 5` know which way to walk. Players who
see `· ▼ 0` know they're there. Both are important.

**Carry-forward**: when adding a hint with a "current position" state,
distinguish it visually from the "navigate there" state (arrow ↘ vs
none ·). Use the same glyph (▼) so the player knows it's the same
object.
