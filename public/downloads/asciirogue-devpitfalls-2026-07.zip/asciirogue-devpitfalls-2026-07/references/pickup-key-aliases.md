# Pickup key aliases added in v0.5.3

During the 2026-07-29 session the `$` (gold) and `,` (comma) keys were added as aliases for the `g` pickup command. The change was made by:

- Extending the key match in `App::handle` to include `KeyCode::Char('$') | KeyCode::Char(',')`.
- Switching from the boolean `try_pickup` function to the tri‑state `pick_up_outcome` call, providing distinct messages for:
  - `PickupOutcome::Picked` – "아이템을 주웠습니다."
  - `PickupOutcome::NoItem` – "주울 아이템이 없습니다."
  - `PickupOutcome::InventoryFull` – "인벤토리가 가득 찼습니다."

**Guideline:** When adding an alias for an existing action, always route through the highest‑level function (`pick_up_outcome`) to preserve consistent messaging and tri‑state handling. Add regression tests covering all three outcomes for each alias.
