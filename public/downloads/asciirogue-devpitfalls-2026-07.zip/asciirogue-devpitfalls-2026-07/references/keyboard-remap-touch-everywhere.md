# Keyboard remap in asciirogue: the touch-everywhere checklist

When you remap any single key in asciirogue (or any TUI game with
on-screen help text, modal titles, and a startup banner), you are
touching **at least 6 places**. Forgetting any of them leaves the
user with a working key and no documentation that says so. This is
the same class as the v0.5.7 missing-`> descend`-hint bug: feature
exists, footer doesn't say so.

## The 6 places, in patch order

### 1. The key dispatcher

`crates/app/src/main.rs` — `App::handle` (top-level) and
`handle_inventory_key` (modal-local). The top-level only fires when
`ModalMode::Closed`; modal-local only when open.

```rust
// top-level
KeyCode::Char('i') => { /* open inventory modal */ }
KeyCode::Char('p') => { /* quick potion */ }

// modal-local (handles i as both open AND close — toggle)
KeyCode::Esc | KeyCode::Char('i') | KeyCode::Char('I') | KeyCode::Char('q') => {
    self.modal = ModalMode::Closed;
}
```

### 2. The footer hint

`App::draw` — `controls_hint` string. Rendered every frame in the
bottom panel. Two variants (boss-defeated vs not):

```rust
let controls_hint = if self.boss_defeated && self.floor == BOSS_FLOOR {
    "g pick  i inv  p potion  > descend  R restart"
} else {
    "g pick  i inv  p potion  > descend  q quit  R restart"
};
```

### 3. The modal title

`draw_inventory_modal` — `Block::default().title(...)`. Updated
when the open-key changes:

```rust
let block = Block::default()
    .title(" 인벤토리 (i / Esc: 닫기) ")
    .borders(Borders::ALL);
```

### 4. The startup banner (×2: binary + lib)

Both `crates/app/src/main.rs` and `crates/app/src/lib.rs` build a
`startup_msg` string at floor entry. They duplicate the same Korean
string. Update BOTH.

```rust
match locale {
    Locale::Korean => "h/j/k/l, 화살표, yubn, i 인벤토리, p 포션, > 내려가기",
    Locale::English => "h/j/k/l, arrows, yubn, i inv, p potion, > to descend",
}
```

### 5. The `?`-help burst

In both `crates/app/src/main.rs` and `crates/app/src/lib.rs`, the
`KeyCode::Char('?')` arm fires multiple `self.log(...)` lines:

```rust
self.log("g 줍기 | i 인벤토리 | p 포션 | > 내려가기 | R 새 게임 | q 종료".to_string());
```

The four-space-pipe-separated format is deliberate — at 100-column
terminals with CJK characters, the visual rhythm needs the spaces.

### 6. README + SPEC

`README.md` control table and `docs/SPEC.md` 인벤토리 section. The
README table format:

```markdown
| `i` | 인벤토리 모달 열기 (장착/해제/사용/버리기) |
| `p` | 빠른 포션 사용 (HP/MP 회복) |
```

The SPEC 인벤토리 section uses both the **game-level** key (`i`
opens modal, `p` quick-potion) and the **modal-local** keys (`j`/`k`
navigate, `Enter`/`e`/`u`/`d`/`Esc` action).

## Grep recipe — find ALL old-key references before declaring done

After changing the meaning of any key, sweep the entire repo for
every place that mentions the old key string:

```bash
# old-key literal (e.g. 'i')
rg --no-heading -t rust "Char\('i'\)|'i '|'i inv|'i potion" crates/

# help-text strings that mention old mapping
rg --no-heading "포션 사용|포션 (HP|HP/MP 회복" crates/ README.md docs/

# README / SPEC tables
rg --no-heading "^\| \`i\` |" README.md docs/
```

Each hit is a place that needs updating or a deliberate confirmation
that the old text is now wrong-but-acceptable (e.g. historical commit
message).

## Test discipline for remaps

Modal-dispatcher tests need **phase coverage**, not just endpoint
checks:

```rust
fn test_inventory_modal_open_close() {
    let mut app = App::new(0);

    // Phase 1: Closed → i opens
    app.handle(&i_key);
    assert!(matches!(app.modal, ModalMode::Inventory { .. }));

    // Phase 2: Open → i closes (toggle)
    app.handle(&i_key);
    assert!(matches!(app.modal, ModalMode::Closed));

    // Phase 3: Closed → i opens → Esc closes
    app.handle(&i_key);
    app.handle(&esc_key);
    assert!(matches!(app.modal, ModalMode::Closed));

    // Phase 4: Closed → i opens → I (uppercase) closes (muscle memory)
    app.handle(&i_key);
    app.handle(&upper_i_key);
    assert!(matches!(app.modal, ModalMode::Closed));
}
```

The four phases caught a real bug in v0.5.8 — phase-1 originally
asserted that uppercase `I` would also open the modal, but it
doesn't, because the top-level dispatcher has no `Char('I')` arm.
The phase-by-phase test forced the correct understanding.

## Modal two-mode dispatcher rule

The same key has **different effects** depending on which dispatcher
is active:

| Key | Modal Closed (top-level) | Modal Open (modal-local) |
|---|---|---|
| `i` | open modal | close modal (toggle) |
| `I` | nothing (no arm) | close modal |
| `p` | quick-potion | no effect (cursor navigation only) |
| `Esc` | quit | close modal |
| `j` / `k` | move down/up | cursor down/up |

Documenting the **mode × key** matrix in the skill (rather than just
the keys) makes future dispatcher refactors safer — anyone changing
the top-level match can see which modal keys they may accidentally
collide with.

## Why modal-aware keys are useful

The `i`-toggles-modal pattern is friendlier than `i`-opens-`Esc`-closes
because:

1. **One key, two states** — user doesn't have to remember which
   close-key. Pressing the same key twice is a natural "I'm done"
   gesture (matches vim's `:q`, modal dialogs in Electron apps, etc.).
2. **Mode amnesia is impossible** — even if the user forgets whether
   the modal is open, pressing `i` does the right thing.
3. **Helps single-handed operation** — `i`, navigate with `j`/`k`,
   press `i` to close, all in one hand.

Tradeoff: the modal-local dispatcher must explicitly accept the
open-key as a close-key too. Easy to miss — covered by the
phase-4 test above.
