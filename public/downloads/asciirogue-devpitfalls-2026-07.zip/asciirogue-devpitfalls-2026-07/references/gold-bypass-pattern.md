# Gold-bypass-inventory pattern — full probe + tests

This is the implementation-level reference for the "special item
bypasses the inventory" pattern landed in asciirogue v0.5.9. The
SKILL.md captures the *why* and the *what*; this file captures the
exact code shapes and the four-scenario probe.

## The two-collection split

The single most important piece of v0.5.9 is that
`pick_up_outcome` does **not** push coins into Inventory. The
function looks like this (paraphrased from `crates/app/src/lib.rs`):

```rust
pub fn pick_up_outcome(
    world: &mut World,
    player: hecs::Entity,
    gold_gained: &mut u32,
) -> PickupOutcome {
    let player_pos = world.get::<&Position>(player)?.0;

    // Build the 5-tile pickup window (player + 4 neighbours).
    let wanted: HashSet<TilePos> = std::iter::once(player_pos)
        .chain([
            TilePos(player_pos.0 - 1, player_pos.1),
            TilePos(player_pos.0 + 1, player_pos.1),
            TilePos(player_pos.0, player_pos.1 - 1),
            TilePos(player_pos.0, player_pos.1 + 1),
        ].iter().copied())
        .collect();

    let item_entities: Vec<hecs::Entity> = world.query::<(&Position, &Item)>()
        .iter()
        .filter_map(|(e, (p, _))| if wanted.contains(&p.0) { Some(e) } else { None })
        .collect();
    if item_entities.is_empty() { return PickupOutcome::NoItem; }

    // Split into gold vs non-gold. Coins never reach the Inventory.
    let mut gold_entities: Vec<(hecs::Entity, i32)> = Vec::new();
    let mut non_gold_entities: Vec<hecs::Entity> = Vec::new();
    for e in &item_entities {
        match world.get::<&Item>(*e) {
            Ok(it) if matches!(it.kind, ItemKind::Coin) => gold_entities.push((*e, it.bonus)),
            Ok(_) => non_gold_entities.push(*e),
            Err(_) => {}
        }
    }

    // Despawn gold immediately; accumulate into the out-parameter.
    for (e, bonus) in &gold_entities {
        if *bonus > 0 {
            *gold_gained = gold_gained.saturating_add(*bonus as u32);
        }
        let _ = world.despawn(*e);
    }

    // Short-circuit: pure-gold pickup, no Inventory side-effect.
    if non_gold_entities.is_empty() {
        return if gold_entities.is_empty() {
            PickupOutcome::NoItem
        } else {
            PickupOutcome::Picked
        };
    }

    // Existing Inventory path, unchanged for non-gold items.
    let mut items_to_put: Vec<(hecs::Entity, TilePos, Item)> = Vec::new();
    for e in non_gold_entities {
        if let (Ok(r), Ok(p)) = (world.get::<&Item>(e), world.get::<&Position>(e)) {
            items_to_put.push((e, p.0, (*r).clone()));
        }
    }
    drop(world.get::<&Health>(player));
    let mut inv = world.get::<&mut Inventory>(player).ok().unwrap();
    let mut inserted = 0usize;
    let mut inventory_full = false;
    for (e, _pos, item) in items_to_put.drain(..) {
        match inv.push(item) {
            Ok(_) => inserted += 1,
            Err(()) => { inventory_full = true; break; }
        }
    }
    drop(inv);
    if inserted > 0 {
        let to_despawn: Vec<_> = world.query::<(&Position, &Item)>().iter()
            .filter_map(|(e, (p, _))| if wanted.contains(&p.0) { Some(e) } else { None })
            .take(inserted).collect();
        for e in to_despawn { let _ = world.despawn(e); }
    }
    if inventory_full { PickupOutcome::InventoryFull }
    else if inserted > 0 { PickupOutcome::Picked }
    else { PickupOutcome::NoItem }
}
```

The key invariant: **coins are despawned before any Inventory push
happens.** That guarantees a non-gold item whose push fails
(`InventoryFull`) does not block the gold despawn.

## Caller-side wallet fold

Every caller in `crates/app/src/main.rs` and `crates/app/src/lib.rs`
follows the same shape:

```rust
let mut gold_gained: u32 = 0;
match pick_up_outcome(&mut self.world, self.player, &mut gold_gained) {
    PickupOutcome::Picked => {
        self.gold = self.gold.saturating_add(gold_gained);
        if gold_gained > 0 {
            self.log(format!("골드 +{}!", gold_gained));
        } else {
            self.log("아이템을 주웠습니다.");
        }
    }
    PickupOutcome::NoItem => self.log("주울 아이템이 없습니다."),
    PickupOutcome::InventoryFull => {
        // gold_gained is still set even if Inventory rejected a
        // non-gold item — caller still credits the wallet.
        if gold_gained > 0 {
            self.gold = self.gold.saturating_add(gold_gained);
            self.log(format!(
                "골드는 +{} 챙겼지만 인벤토리가 가득 찼습니다.",
                gold_gained
            ));
        } else {
            self.log("인벤토리가 가득 찼습니다.");
        }
    }
}
```

Three call sites in main.rs + one in lib.rs — all four updated in
the same commit. The grep recipe from
`keyboard-remap-touch-everywhere.md` applied here too:

```bash
rg "pick_up_outcome\(" crates/
# → main.rs:208 (Shift+4), main.rs:283 (g/$/,), main.rs:399 (auto-pickup),
#   lib.rs:255 (lib-side handle — used by tests)
```

## Probe — 4 scenarios

`crates/app/examples/pickup_probe.rs` covers all four scenarios in
one run. Each scenario asserts the outcome, `gold_gained`, and the
final inventory count.

```rust
// ── Scenario A: gold on the player's tile ──
let mut app = App::new(USER_SEED);
let player = find_player(&app);
{
    let world = app.world_mut();
    world.get::<&mut Position>(player).unwrap().0 = TilePos(13, 20);
    world.get::<&mut Inventory>(player).unwrap().slots.iter_mut().for_each(|s| *s = None);
    world.spawn((Position(TilePos(13, 20)), Renderable::new('$', 0xFF_D2_46), Item::gold(7)));
}
let starting_gold = app.gold();
let mut gold_gained: u32 = 0;
let outcome = pick_up_outcome(app.world_mut(), player, &mut gold_gained);
assert_eq!(outcome, PickupOutcome::Picked);
assert_eq!(gold_gained, 7);
assert_eq!(inv_count(&app, player), 0);  // ← the v0.5.9 invariant

// ── Scenario B: gold 1 tile LEFT (the v0.5.6 fix combined with v0.5.9) ──
// Same shape; gold at (12, 20), player at (13, 20).
// Outcome Picked, gold_gained=7, inv_count=0.

// ── Scenario C: gold 2 tiles LEFT ──
// Outcome NoItem, gold_gained=0.

// ── Scenario D: gold + potion in same pickup window ──
// Spawn gold at (50,50) and potion_hp at (51,50). Player at (50,50).
// Outcome Picked, gold_gained=3, inv_count=1.
// The potion still occupies one slot; gold still bypasses Inventory.
```

The probe prints `=== all v0.5.9 pickup assertions passed ===` on
success. It is runnable in CI (`cargo run --example pickup_probe
-p asciirogue`) and exits 0 if all four pass.

## Test-suite updates

Three tests in `crates/app/src/main.rs` were changed; one new test
was added. The pattern of "the existing test was checking the
*inventory slot*, now must check the *wallet*" recurs:

```rust
// BEFORE (v0.5.6–v0.5.8):
app.handle(&g);
let inv = app.world.get::<&Inventory>(app.player).unwrap();
let filled = inv.slots.iter().filter(|s| s.is_some()).count();
assert_eq!(filled, 1);

// AFTER (v0.5.9):
app.handle(&g);
let starting_gold = app.gold();
app.handle(&g);
assert_eq!(app.gold(), starting_gold + 7);
let inv = app.world.get::<&Inventory>(app.player).unwrap();
assert!(inv.slots.iter().all(|s| s.is_none()));  // ← inventory stays empty
```

The new regression guard — `test_potion_pickup_still_uses_inventory` —
exists specifically to prevent a future "let's route everything
through the wallet" refactor from accidentally making potions
bypass the bag too:

```rust
#[test]
fn test_potion_pickup_still_uses_inventory() {
    let mut app = App::new(0);
    let player_pos = app.world.get::<&Position>(app.player).unwrap().0;
    app.world.spawn((Position(player_pos), Item::potion_hp()));
    let mut inv = app.world.get::<&mut Inventory>(app.player).unwrap();
    inv.slots.iter_mut().for_each(|s| *s = None);
    drop(inv);
    let g = Event::Key(KeyEvent { code: KeyCode::Char('g'), /* ... */ });
    app.handle(&g);
    let inv = app.world.get::<&Inventory>(app.player).unwrap();
    let filled = inv.slots.iter().filter(|s| s.is_some()).count();
    assert_eq!(filled, 1, "non-gold items still occupy a slot");
    assert_eq!(inv.slots[0].as_ref().unwrap().glyph, '!');
}
```

The name is the contract: `still` — anything that breaks this test
is a regression.

## README / SPEC touch-points

For consistency with the v0.5.8 keyboard-remap touch-everywhere
pattern, the README also needs a one-line note that gold does not
occupy a slot:

```markdown
## 🎮 컨트롤

> **골드(`$`)** 는 인벤토리를 차지하지 않습니다 — 픽업 즉시 `App::gold`(지갑)에 합산되고,
> 인벤토리 슬롯은 비어 있습니다. 포션·무기·방어구만 8슬롯에 들어갑니다.
```

`docs/SPEC.md` was not updated for v0.5.9 — there's no inventory
section in SPEC that lists item-kind handling. If a future session
adds such a section, it should explicitly call out the wallet
bypass.

## Common mistakes (don't write these)

| Mistake | Why it fails |
|---|---|
| `*gold_gained += bonus as u32` without `saturating_add` | If caller passes a u32 maxed out, this overflows in debug mode. |
| Forget to despawn gold before pushing non-gold | Gold entity stays on the ground, can be picked up again next turn. |
| Add `PickupOutcome::PickedGold(u32)` variant | Forces every existing match arm to handle a fourth variant, even when `gold_gained == 0`. |
| Make `pick_up_outcome` mutate `App::gold` directly | Couples pure helper to impure caller; test no longer matches behavior. |
| Don't add the `App::gold()` accessor | Tests must reach into `app.gold` field through private access; not possible in `crates/app/src/bin` tests where App is duplicated in main.rs. |
| Forget `drop(inv)` between borrow and `world.spawn` | Borrow checker E0502 — `hecs::RefMut<Inventory>` lives to end of scope. |

## Edit guard

Any new item kind added to `ItemKind` must answer one question
before merging: **does this go into the bag, or does it bypass the
bag?** The default is "goes into the bag" — only explicit wallet /
counter / stackable types get the bypass treatment. If the answer
is "bypass", follow the four-step recipe above; if it's "in the bag",
add a regression test for the pickup that mirrors
`test_potion_pickup_still_uses_inventory`.
