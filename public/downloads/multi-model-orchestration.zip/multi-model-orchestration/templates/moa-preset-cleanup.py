#!/usr/bin/env python3
"""
MoA preset cleanup helper.

USE WHEN:
- hermes moa configure 비대화형 호출로 프리셋이 망가졌을 때
  (moa:default 자기참조 + moa: 바깥 잔재 키 동시 존재)
- 안전하게 옵션 E 형태(MiniMax + NIM → NIM 합성)로 복구하고 싶을 때

USAGE:
  # 드라이런 (실제 수정 X)
  python3 moa-preset-cleanup.py --dry-run

  # 실제 수정
  python3 moa-preset-cleanup.py

  # 다른 프리셋 이름 / 다른 옵션 구조 적용 시 패치 후 사용

WHAT IT DOES:
1. ~/.hermes/config.yaml 백업 → .bak.full.<timestamp>
2. moa: 바깥 잔재 키 6개 제거 (reference_models / aggregator / *_temperature / max_tokens / enabled)
3. presets.default.reference_models에서 {provider: moa, model: default} 항목 제거
4. presets.default.aggregator가 자기참조면 nvidia-1:openai/gpt-oss-120b로 교체
5. 온도 옵션 E 권장값 (0.7 / 0.3) 적용
6. YAML 문법 재검사 + hermes moa list로 결과 출력
"""

import argparse
import shutil
import sys
import time
from pathlib import Path

import yaml

CONFIG = Path.home() / ".hermes" / "config.yaml"

OUTER_KEYS_TO_REMOVE = [
    "reference_models",
    "aggregator",
    "reference_temperature",
    "aggregator_temperature",
    "max_tokens",
    "enabled",
]

# 옵션 E 프리셋 (MiniMax-M3 + NIM gpt-oss-120b → NIM 합성)
OPTION_E_PRESET = {
    "enabled": True,
    "reference_models": [
        {"provider": "minimax", "model": "MiniMax-M3"},
        {"provider": "nvidia-1", "model": "openai/gpt-oss-120b"},
    ],
    "aggregator": {"provider": "nvidia-1", "model": "openai/gpt-oss-120b"},
    "reference_temperature": 0.7,
    "aggregator_temperature": 0.3,
    "max_tokens": 4096,
}


def backup(path: Path) -> Path:
    ts = int(time.time())
    bak = path.with_suffix(f".bak.full.{ts}")
    shutil.copy2(path, bak)
    print(f"✓ 백업: {bak}")
    return bak


def is_self_reference(entry: dict) -> bool:
    return entry.get("provider") == "moa" and entry.get("model") == "default"


def cleanup(config_path: Path, dry_run: bool = False) -> None:
    with open(config_path) as f:
        d = yaml.safe_load(f)

    moa = d.get("moa", {})
    if not moa:
        print("❌ config.yaml에 moa: 블록이 없음")
        sys.exit(1)

    # 1) moa: 바깥 잔재 제거
    removed_outer = [k for k in OUTER_KEYS_TO_REMOVE if k in moa]
    if not dry_run:
        for k in removed_outer:
            moa.pop(k)

    # 2) presets.default.reference_models에서 자기참조 제거
    presets = moa.get("presets", {})
    default = presets.get("default", {})
    refs = default.get("reference_models", [])
    clean_refs = [r for r in refs if not is_self_reference(r)]

    # 3) aggregator가 자기참조면 교체
    agg = default.get("aggregator", {})
    if is_self_reference(agg):
        clean_agg = OPTION_E_PRESET["aggregator"].copy()
    else:
        clean_agg = agg

    # 4) 온도/활성 등 옵션 E 형태로
    final_preset = {
        "enabled": default.get("enabled", OPTION_E_PRESET["enabled"]),
        "reference_models": clean_refs,
        "aggregator": clean_agg,
        "reference_temperature": OPTION_E_PRESET["reference_temperature"],
        "aggregator_temperature": OPTION_E_PRESET["aggregator_temperature"],
        "max_tokens": OPTION_E_PRESET["max_tokens"],
    }
    presets["default"] = final_preset

    print(f"제거된 moa 바깥 잔재: {removed_outer}")
    print(f"reference_models 변경: {len(refs)}개 → {len(clean_refs)}개")
    print(f"aggregator: {clean_agg}")
    print(f"reference_temperature: {final_preset['reference_temperature']}")
    print(f"aggregator_temperature: {final_preset['aggregator_temperature']}")

    if dry_run:
        print("\n[드라이런] 실제 저장 안 함")
        return

    # 5) 저장
    with open(config_path, "w") as f:
        yaml.safe_dump(d, f, default_flow_style=False, sort_keys=False, allow_unicode=True)
    print("\n✅ 저장 완료")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true", help="실제 수정 없이 미리보기")
    ap.add_argument("--config", default=str(CONFIG), help="config.yaml 경로")
    args = ap.parse_args()

    cfg = Path(args.config)
    if not cfg.exists():
        print(f"❌ {cfg} 없음")
        sys.exit(1)

    if not args.dry_run:
        backup(cfg)

    cleanup(cfg, dry_run=args.dry_run)

    if not args.dry_run:
        # 검증
        print("\n=== YAML 문법 재검사 ===")
        try:
            yaml.safe_load(open(cfg))
            print("✅ YAML 정상")
        except yaml.YAMLError as e:
            print(f"❌ YAML 깨짐: {e}")
            sys.exit(1)


if __name__ == "__main__":
    main()