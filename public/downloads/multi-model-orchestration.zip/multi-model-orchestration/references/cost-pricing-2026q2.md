# 비용/가격 참고 (2026-Q2)

MoA는 **사용자 1회 입력에 N+1회 LLM 호출**이 발생하므로, reference 2개 + aggregator 1개 = 3배 비용. 시뮬레이션 필수.

## 공시 가격 (Google AI Studio 기준, 2026-06 확인)

| 모델 | Input ($/1M tok) | Output ($/1M tok) | 무료 등급 |
|------|-------------------|---------------------|-----------|
| Gemini 2.5 Flash | 0.30 | 2.50 | ✓ 15 RPM |
| Gemini 2.5 Flash-Lite | 0.10 | 0.40 | ✓ 15 RPM |
| Gemini 2.5 Pro | 1.25 | 10.00 | ✓ **2 RPM** |
| Gemini 3.x Pro | (별도 확인) | (별도 확인) | ✓ 2 RPM |
| Gemini 3.x Flash | (별도 확인) | (별도 확인) | ✓ 15 RPM |

**참고**: 가격은 변동 가능. 사용 전 Google Cloud 가격표에서 재확인.

## NVIDIA NIM

- **공식 가격표 미공개** (응답 헤더/메타에 가격 정보 없음)
- NVIDIA Developer Program 가입자는 **무료 크레딧** 제공 (정확한 한도는 콘솔 확인)
- 가정: 본문 시뮬레이션에서는 **$0**으로 계산
- 실제 비용 발생 시 NVIDIA Cloud Functions 콘솔에서 크레딧 차감 확인

## MiniMax (M3 등)

- **공식 가격표 비공개** (구독/쿼타 기반)
- MiniMax 구독 메인 쿼타 내에서 사용 → MoA 내부 호출도 메인 쿼타 차감
- 가정: 본문 시뮬레이션에서는 **$0**으로 계산 (메인 쿼타)
- ⚠️ MoA는 1회 = 3배 호출이므로 쿼타 빠르게 소진

## 옵션별 1회 비용 시뮬레이션

**입력 가정**: 1,500 tokens (한국어 500자 + 시스템 프롬프트)
**출력 가정**: 각 reference/aggregator = 4,096 tokens (MoA max_tokens 기본값)
**Pro 합성 입력**: 1,500 + 4,096×2 = 9,692 tokens (원본 + reference 2개 답변)

### 옵션 A — Gemini Flash + NIM → Gemini Pro

```
Reference 1 Flash:  (1500/1e6)*0.30 + (4096/1e6)*2.50 = $0.0107
Reference 2 NIM:    $0 (무료 크레딧)
Aggregator Pro:     (9692/1e6)*1.25 + (4096/1e6)*10.00 = $0.0531
─────────────────────────────────────────────────────────
TOTAL / 1회:        $0.0638  ≈ 83원 (환율 1,300원/$)
```

| 횟수 | 비용 (USD) | 비용 (KRW) |
|------|-----------|-----------|
| 10회 | $0.64 | 829원 |
| 100회 | $6.38 | 8,289원 |
| 1,000회 | $63.77 | 82,894원 |

⚠️ **Pro 무료 등급 2 RPM** → 1,000회 = 8시간 20분 이상 소요.

### 옵션 E — MiniMax + NIM → NIM

모두 $0 (메인 쿼타 + NIM 크레딧).

### 옵션 G — Gemini Flash + NIM → NIM

```
Reference 1 Flash:  $0.0107
Reference 2 NIM:    $0
Aggregator NIM:     $0
─────────────────────────────────────────────────────────
TOTAL / 1회:        $0.0107  ≈ 14원
```

## 비용 결정 요인 분석

MoA 비용은 **aggregator 모델이 거의 100% 차지**:

- 옵션 A: Pro 합성이 66원 / 총 83원 = **80%**
- 합성 입력 = reference 2개 답변 + 원본 (reference 출력의 약 2.4배)
- 즉 Pro 모델 1회가 Flash 모델 5회 분

**절감 전략**:
1. **aggregator를 외부 모델로**: Pro → NIM 또는 Flash → 80% 비용 ↓
2. **reference 줄이기**: 3-way → 2-way → 33% 비용 ↓
3. **max_tokens 낮추기**: 4096 → 2048 → 50% 출력 비용 ↓ (품질 트레이드오프)

## 비용 검증 도구

실제 사용량 추적은:
- `~/.hermes/logs/gateway.log` — 호출 로그
- `~/.hermes/logs/agent.log` — 어시스턴트별 사용량
- `hermes insights --days N` — 일일 사용량 분석
- (있다면) `ai-model-tracker` 스킬로 Notion 기록

## 가격 변동 주의

본 가격표는 2026-06-29 기준. 사용 전:
- Google: https://ai.google.dev/pricing
- NVIDIA: https://build.nvidia.com/pricing (있으면)
- MiniMax: 공식 가격 페이지 (구독/엔터프라이즈별 상이)

**절대 가격을 단정하지 말 것**. 시뮬레이션 결과는 "추정"으로 표시.