# Provider Key 실측 검증 레시피

MoA 프리셋 만들기 전에 **반드시** 각 후보 provider를 실제 한 번씩 호출해서 확인할 것. `hermes status`는 키 존재만 알려주지 실제 동작을 보장하지 않음. 추측 금지.

## 진단 우선순위

1. **키 존재**: `hermes status` (provider별 ✓/✗)
2. **쿼타 상태**: `hermes auth` (소진/402 exhausted 여부)
3. **실제 호출**: 아래 curl 한 줄 명령어로 200 OK + 정상 답변 + usage 메타 확인
4. **헤더 검사**: cost/billing 메타데이터 있는지

## Gemini (Google AI Studio)

**⚠️ 함정**: `x-goog-api-key` 헤더는 **403 PERMISSION_DENIED** 반환. 쿼리스트링 방식만 동작.

```bash
GKEY=$(printenv GOOGLE_API_KEY)
curl -sS -X POST "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${GKEY}" \
  -H "Content-Type: application/json" \
  -d '{
    "contents": [{"role":"user","parts":[{"text":"ping. 1줄로 답해줘."}]}],
    "generationConfig": {"maxOutputTokens": 50, "temperature": 0.0}
  }' \
  -D /tmp/gem_h.txt -o /tmp/gem_b.json
head -1 /tmp/gem_h.txt  # HTTP/2 200 기대
cat /tmp/gem_b.json | python3 -m json.tool  # usageMetadata 확인
```

**기대 응답**:
```json
{
  "candidates": [{"content": {"parts": [{"text": "pong."}], ...}}],
  "usageMetadata": {
    "promptTokenCount": 11,
    "candidatesTokenCount": 2,
    "totalTokenCount": 13
  },
  "modelVersion": "gemini-2.5-flash"
}
```

**확인해야 할 것**: `usageMetadata.promptTokenCount`, `candidatesTokenCount` 둘 다 0 이상.

## NVIDIA NIM (openai/gpt-oss-120b)

**⚠️ 함정 1**: reasoning 모델은 `reasoning_content`에 추론 출력 → `max_tokens` 작은 값 (50 등) 으로 테스트하면 본 답변이 `content: null`이 됨.

**⚠️ 함정 2**: 응답 헤더에 cost/billing 메타 없음. `nvcf-reqid`만 찍힘. 가격은 NVIDIA Developer Program 콘솔에서 별도 확인.

```bash
NKEY=$(printenv NVIDIA_API_KEY_1)  # 또는 NVIDIA_API_KEY_HERMES
curl -sS -X POST "https://integrate.api.nvidia.com/v1/chat/completions" \
  -H "Authorization: Bearer *** \
  -H "Content-Type: application/json" \
  -d '{
    "model": "openai/gpt-oss-120b",
    "messages": [{"role":"user","content":"ping. 1줄로 답해줘."}],
    "max_tokens": 500,
    "temperature": 0.0
  }' \
  -D /tmp/nim_h.txt -o /tmp/nim_b.json
head -1 /tmp/nim_h.txt
cat /tmp/nim_b.json | python3 -m json.tool
```

**기대 응답**:
```json
{
  "model": "openai/gpt-oss-120b",
  "choices": [{
    "message": {
      "role": "assistant",
      "content": "Pong.",
      "reasoning": "User says ...",
      "reasoning_content": "User says ..."
    },
    "finish_reason": "stop"
  }],
  "usage": {
    "prompt_tokens": 75,
    "completion_tokens": 45,
    "total_tokens": 120
  }
}
```

**모델 카탈로그 조회** (가격 메타는 없지만 모델 존재 확인용):
```bash
curl -sS "https://integrate.api.nvidia.com/v1/models" \
  -H "Authorization: Bearer *** \
  | python3 -c "
import json, sys
d = json.load(sys.stdin)
for m in d.get('data', []):
    if 'gpt-oss' in m.get('id', ''):
        print(json.dumps(m, indent=2))
        break
"
```

## MiniMax (M3 / M2.7 / M2.5 / M2.1 / M2)

MiniMax는 자체 base_url + API 키. Hermes `providers:` 블록에 `minimax` 등록되어 있는지 먼저 확인:

```bash
grep -A2 "^providers:" ~/.hermes/config.yaml | head -10
```

`hermes chat -q "ping"` 한 줄로 동작 확인 가능 (MoA 외부). MiniMax는 메인 모델이라 quota/쿼타 차감될 수 있으니 테스트는 짧게.

## OpenRouter (⚠️ 402 exhausted 빈번)

`hermes auth`에서 `openrouter-vision: exhausted (402)` 보이면 즉시 제외. 사용하지 말 것.

복구 가능하면 `hermes auth reset openrouter` 후 재시도. 안 되면 다른 옵션으로.

## 디버깅 체크리스트

| 증상 | 원인 | 해결 |
|------|------|------|
| 401 Unauthorized | 키 만료/오타 | `hermes status`로 키 prefix 확인, 새 키 발급 |
| 403 PERMISSION_DENIED (Gemini) | 헤더 방식 잘못 | 쿼리스트링 `?key=` 방식으로 |
| 402 Payment Required | OpenRouter 쿼타 소진 | 다른 provider로 |
| 빈 content + finish_reason: length | reasoning 모델 max_tokens 부족 | 4096 이상으로 |
| 404 Model not found | 모델 ID 오타 | `/v1/models` 카탈로그 조회로 ID 확인 (특히 NIM은 `openai/gpt-oss-120b` prefix 필수) |
| Connection timeout | 네트워크/방화벽 | `curl -v`로 TLS 핸드셰이크 확인 |