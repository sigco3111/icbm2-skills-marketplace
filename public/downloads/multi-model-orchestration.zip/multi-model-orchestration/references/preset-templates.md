# MoA 프리셋 YAML 템플릿 모음

각 템플릿은 `~/.hermes/config.yaml`의 `moa:` 블록 전체를 교체. line 489 근처.

## 사용법

```bash
vim ~/.hermes/config.yaml
# :489 로 이동
# V17j (현재 줄부터 17줄 선택)
# d (삭제)
# i (삽입 모드)
# 아래 YAML 붙여넣기
# Esc
# :wq (저장)
```

## 옵션 A — 품질 우선 (Gemini Flash + NIM → Gemini Pro)

```yaml
moa:
  default_preset: default
  active_preset: default
  presets:
    default:
      reference_models:
        - provider: gemini
          model: gemini-2.5-flash
        - provider: nvidia-1
          model: openai/gpt-oss-120b
      aggregator:
        provider: gemini
        model: gemini-2.5-pro
      reference_temperature: 0.7
      aggregator_temperature: 0.3
      max_tokens: 4096
      enabled: true
```

**필수 사전 조건**: `providers:` 블록에 `gemini:` 등록 필요
```yaml
providers:
  # ... 기존 ...
  gemini:
    api_key_env: GOOGLE_API_KEY
```

## 옵션 E — 완전 무료 (MiniMax + NIM → NIM)

```yaml
moa:
  default_preset: default
  active_preset: default
  presets:
    default:
      reference_models:
        - provider: minimax
          model: MiniMax-M3
        - provider: nvidia-1
          model: openai/gpt-oss-120b
      aggregator:
        provider: nvidia-1
        model: openai/gpt-oss-120b
      reference_temperature: 0.7
      aggregator_temperature: 0.3
      max_tokens: 4096
      enabled: true
```

## 옵션 G — 비용 최저 (Gemini Flash + NIM → NIM)

```yaml
moa:
  default_preset: default
  active_preset: default
  presets:
    default:
      reference_models:
        - provider: gemini
          model: gemini-2.5-flash
        - provider: nvidia-1
          model: openai/gpt-oss-120b
      aggregator:
        provider: nvidia-1
        model: openai/gpt-oss-120b
      reference_temperature: 0.7
      aggregator_temperature: 0.3
      max_tokens: 4096
      enabled: true
```

## 3-way 변형 (옵션 B) — 최대 다양성

```yaml
moa:
  default_preset: default
  active_preset: default
  presets:
    default:
      reference_models:
        - provider: gemini
          model: gemini-2.5-pro
        - provider: nvidia-1
          model: openai/gpt-oss-120b
        - provider: minimax
          model: MiniMax-M3
      aggregator:
        provider: gemini
          model: gemini-2.5-pro
      reference_temperature: 0.7
      aggregator_temperature: 0.3
      max_tokens: 4096
      enabled: true
```

## OFF (MoA 비활성)

```yaml
moa:
  default_preset: default
  active_preset: ''           # ← 빈 문자열 = OFF
  presets:
    default:
      # ... 내용은 유지하되 active_preset이 ''이므로 호출 안 됨
```

## 검증 명령어

```bash
# 프리셋 내용 확인
hermes moa list

# active 상태 확인 (Active in config: default → ON, (off) → OFF)
hermes moa list

# /moa 슬래시 커맨드 테스트
hermes chat -q "/moa 한국 증시 12월 전망 3줄 요약"

# 단일 키/값 토글 (스칼라만)
hermes config set moa.active_preset default     # ON
hermes config set moa.active_preset ''          # OFF
```

## 커스텀 조합 가이드

**다양성 우선**: 다른 회사/아키텍처 모델끼리 묶기
- Anthropic Claude (OpenRouter) + Google Gemini + OpenAI gpt-oss
- 단, 키가 모두 있어야 동작

**속도 우선**: 응답 빠른 모델로만
- Gemini Flash + Grok (있으면) + NIM gpt-oss

**한국어 우선**: 한국어 성능 검증된 모델로
- MiniMax-M3 + Claude (Sonnet/Opus) + Gemini Pro

**특화 분야**: 코딩/리서치/창작 등
- 코딩: Claude Sonnet + DeepSeek Coder + Qwen Coder
- 리서치: Perplexity (online) + Gemini Pro + Claude Opus
- 창작: Claude Opus + GPT-4 + Mistral Large

조합 결정 후 `references/provider-key-validation.md`로 키 검증 → 비용 시뮬레이션 → 적용.