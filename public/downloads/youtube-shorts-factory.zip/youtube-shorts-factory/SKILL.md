---
name: youtube-shorts-factory
description: "YouTube Shorts 숏츠 영상 자동 제작 — NotebookLM 비디오 오버뷰 4개 중 하나를 랜덤 선택, 9:16으로 편집 후 숏츠 업로드"
tags: [youtube, shorts, video, notebooklm, automation, content-creation]
---

# YouTube Shorts Factory

00:15에서 다운로드된 NotebookLM 비디오 오버뷰 4개 중 하나를 랜덤으로 선택해, 9:16 비율로 편집하여 YouTube Shorts로 자동 업로드합니다.

## 크론 잡

|| 크론 | 설명 |
|------|------|------|
| `02:15 YouTube 숏츠` | 4개 비디오오버뷰 중 하나를 랜덤 선택 → 9:16 편집 → 숏츠 업로드 |

**02:15 숏츠 크론은 절대 NotebookLM에서 새 영상을 생성하지 않습니다.** Video Overview 생성은 불안정하므로 항상 기존 다운로드 영상을 사용합니다.

## 스크립트 위치

`~/.hermes/scripts/notebooklm_youtube_pipeline.py --mode shorts`

## 사용법

```bash
# 02:15 숏츠 크론과 동일한 로직
python3 ~/.hermes/scripts/notebooklm_youtube_pipeline.py --mode shorts --type ai_news
```

## 파이프라인

```
4개 다운로드된 영상 중 랜덤 선택 → 9:16 (1080x1920) 리사이즈 + 블러 배경 합성 → 60초 트림 → YouTube 숏츠 업로드
```

### Step 1: 랜덤 영상 선택
- `/tmp/icbm_notebooklm/`에서 `video_*.mp4` 목록 조회
- `random.choice()`로 4개 중 하나 랜덤 선택

### Step 2: 9:16 블러 배경 편집
- 원본 16:9 → 9:16 (1080x1920) 리사이즈
- 좌우 블러 배경 합성
- `ffmpeg -vf "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,boxblur=20:5,overlay=(W-w)/2:(H-h)/2"`

### Step 3: 60초 트림
- `-t 60`으로 최대 60초 트림

### Step 4: YouTube 업로드
- `~/.hermes/skills/creative/youtube-uploader/scripts/upload.py` 사용
- 제목: `{타입} | ICBM #{YYYY-MM-DD}`
- 카테고리: 28 (Science & Tech)
- 프라이버시: public

## 의존성

|| 항목 | 경로 | 비고 |
|------|------|------|
| ffmpeg | 시스템 `ffmpeg` | 필수 |
| ffprobe | 시스템 `ffprobe` | 필수 |
| upload.py | `~/.hermes/skills/creative/youtube-uploader/scripts/` | YouTube 업로드 |

## YouTube 설명 템플릿

```
{요약 텍스트}

▼ 더보기
📚 출처
• 제목
  https://url...

#ICBM #AI #테크 #개발자 #인공지능
```

**Shorts description=None(`""`) 금지** — 항상 유효한 설명 텍스트 사용

## ⚠️ 02:15 숏츠 크론 검증 체크리스트

02:15 크론 실행 후 반드시 확인할 것:
1. `/tmp/icbm_notebooklm/`에 다운로드된 MP4가 존재하는지
2. `/tmp/icbm_shorts/`에 편집된 숏츠 MP4가 생성되었는지
3. YouTube에 실제로 숏츠가 게시되었는지 (URL 반환 여부)
4. **description이 빈 문자열이 아닌지**

## 알려진 문제

|| 문제 | 원인 | 해결 |
|------|------|------|
| 숏츠 description 빈 문자열 | `upload_to_youtube(shorts_path, title, "", ...)` | `build_youtube_description()` 사용 ✓ |
| 02:15 크론 ok인데 숏츠 미업로드 | description=""인데 상태 ok로 표시 | 빈 description 시 텔레그램 알림 +紧急修复 |
| **숏츠에音频 스트림 없음** | `combine_video()`가 FFmpeg return code만 체크 | `has_audio_stream()` ffprobe 검증 추가 ✓ |

## ⚠️音频 검증 구현 포인트

FFmpeg의 `-c:a aac` 플래그가 있어도, 입력 audio가 없으면 FFmpeg는 **정상 종료(returncode=0)하지만 영상에 audio stream이 없음**. 반드시 ffprobe로 검증해야 함:

```python
def has_audio_stream(path):
    r = subprocess.run(
        ["ffprobe", "-v", "error", "-select_streams", "a",
         "-show_entries", "stream=codec_type", "-of", "csv=p=0", path],
        capture_output=True, text=True, timeout=10
    )
    return r.returncode == 0 and r.stdout.strip().startswith("audio")
```

**무음 영상이 YouTube에 업로드되는 것을 방지**하기 위해, 영상 생성 직후 + 업로드 직전에 반드시 이 검증 함수를 사용할 것.
