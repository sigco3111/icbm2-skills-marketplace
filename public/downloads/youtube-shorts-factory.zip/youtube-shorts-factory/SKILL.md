---
name: youtube-shorts-factory
description: "YouTube Shorts 숏츠 영상 자동 제작 — AI 뉴스, 개발 팁, GitHub 트렌딩, 오픈소스 소개, 커스텀 토픽을 60초 이내 숏츠로 자동 생성 (TTS 나레이션 + BGM + 배경 이미지)"
tags: [youtube, shorts, video, tts, automation, content-creation]
---

# YouTube Shorts Factory

AI 뉴스, 개발 팁, GitHub 트렌딩, 오픈소스 소개, 커스텀 토픽을 YouTube Shorts 숏츠 영상으로 자동 제작합니다.

## 스크립트 위치

`~/.hermes/scripts/youtube_shorts_factory.py`

## 사용법

### 기본 (AI 뉴스 자동 수집)

```bash
python3 ~/.hermes/scripts/youtube_shorts_factory.py --type ai_news
```

### 콘텐츠 타입

| 타입 | 옵션 | 설명 |
|------|------|------|
| `ai_news` | `--type ai_news` | HN + Reddit에서 AI 뉴스 자동 수집 |
| `dev_tip` | `--type dev_tip` | 사전 정의 개발 팁에서 랜덤 선택 |
| `github_trending` | `--type github_trending` | GitHub 트렌딩 레포 자동 수집 |
| `opensource` | `--type opensource` | 오픈소스 도구 자동 수집 |
| `custom` | `--type custom --topic "토픽"` | 커스텀 토픽 (필수: `--topic`) |

### 전체 옵션

```bash
python3 ~/.hermes/scripts/youtube_shorts_factory.py \
  --type custom \
  --topic "제목" \
  --extra "추가 설명 텍스트" \
  --no-upload    # 업로드 생략 (테스트용)
  --no-bgm       # BGM 생략
  --output-dir /tmp/output  # 출력 디렉토리 (기본: /tmp/icbm_shorts)
```

## 파이프라인

```
콘텐츠 수집 → 대본 생성 → TTS 나레이션 → 배경 이미지 → ffmpeg 영상 조합 → BGM 믹싱 → YouTube 업로드
```

### Step 1: 콘텐츠 수집 + 대본 생성
- **ai_news**: HN top 30 + r/artificial + r/MachineLearning에서 AI 키워드 매칭
- **dev_tip**: 사전 정의된 개발 팁 10개에서 랜덤 선택
- **github_trending**: GitHub Trending HTML 스크래핑
- **custom**: `--topic`과 `--extra`로 대본 구성
- 대본 구조: Hook → Body → CTA (구독 유도)

### Step 2: TTS 나레이션
- **기본**: edge-tts (`ko-KR-SunHiNeural`, rate=-3%, pitch=+1Hz)
- **대체**: macOS `say` 명령어
- 이모지 자동 제거 (`strip_emoji` — stdlib `unicodedata`만 사용)

### Step 3: 배경 이미지 (Pillow)
- 1080x1920 (9:16) 세로형
- 다크 그라디언트 배경 + 글로우 이펙트
- ICBM 로고 + 타입 뱃지 + Hook/Body/CTA 텍스트
- 해시태그 + 구독 유도 바

### Step 4: ffmpeg 영상 조합
- 정지 이미지 + 나레이션 → MP4 (libx264 + AAC)
- 최대 59초 자동 제한

### Step 4.5: BGM 믹싱 (선택)
- `~/.hermes/scripts/bgm_manager.py` 사용
- mood 기반 BGM 자동 선택 + 음성 구간 -35dB 자동 음소거

### Step 5: YouTube 업로드
- `~/.hermes/skills/creative/youtube-uploader/scripts/upload.py` 사용
- 제목: `{타입} | ICBM #{YYYY-MM-DD}`
- 카테고리: 28 (Science & Tech)
- 프라이버시: public

## 의존성

| 항목 | 경로 | 비고 |
|------|------|------|
| edge-tts | `~/.hermes/hermes-agent/venv/bin/edge-tts` | venv 내 |
| Pillow | venv `site-packages` (sys.path injection) | 시스템 Python 3.9에서 사용 |
| ffmpeg | 시스템 `ffmpeg` | 필수 |
| ffprobe | 시스템 `ffprobe` | 필수 |
| bgm_manager.py | `~/.hermes/scripts/bgm_manager.py` | BGM 믹싱 |
| upload.py | `~/.hermes/skills/creative/youtube-uploader/scripts/` | YouTube 업로드 |

## 색상 테마

| 타입 | Primary | Accent | Glow |
|------|---------|--------|------|
| ai_news | (30, 64, 175) | (96, 165, 250) | (59, 130, 246) |
| dev_tip | (22, 101, 52) | (74, 222, 128) | (34, 197, 94) |
| github_trending | (100, 50, 150) | (167, 139, 250) | (139, 92, 246) |
| opensource | (120, 53, 15) | (251, 146, 60) | (249, 115, 22) |
| custom | (30, 58, 95) | (56, 189, 248) | (14, 165, 233) |

## 알려진 문제

| 문제 | 원인 | 해결 |
|------|------|------|
| YouTube 업로드 실패 | cryptography 모듈 호환성 (Python 3.9 vs 3.11 venv) | `--no-upload` 후 수동 업로드, 또는 venv Python으로 실행 |
| AI 뉴스가 AI와 무관함 | HN top stories에 AI 기사가 없을 수 있음 | `--type custom`으로 직접 토픽 지정 |
| 대본이 너무 짧음 (18초 미만) | 수집된 뉴스가 짧을 때 발생 | `--extra`로 본문 텍스트 추가 |

## 출력

- 영상: `{output_dir}/output_bgm_{timestamp}.mp4`
- 썸네일: `{output_dir}/thumbnail.png`
- 나레이션: `{output_dir}/narration_{timestamp}.mp3`
- 배경: `{output_dir}/background_{timestamp}.png`
