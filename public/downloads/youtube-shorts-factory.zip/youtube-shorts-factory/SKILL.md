---
name: youtube-shorts-factory
description: "YouTube Shorts 숏츠 영상 자동 제작 — NotebookLM 비디오 오버뷰 4개 중 하나를 랜덤 선택, 9:16으로 편집 후 숏츠 업로드"
tags: [youtube, shorts, video, notebooklm, automation, content-creation]
---

# YouTube Shorts Factory

NotebookLM Video Overview를 YouTube Shorts로 편집 후 업로드하는 파이프라인.

## 현재 운용 방식

**02:15 크론은 사용안함** — 단종됨 (2026-04-30).
실제 숏츠 업로드는 `notebooklm_upload.py`에서 **N:N 정책**으로 자동 처리:
- 일반 영상 1개 + 숏츠 1개 = **동시에 2개 업로드**
- 숏츠 변환: FFmpeg letterbox 블러 방식

## 스크립트 위치

| 스크립트 | 역할 |
|----------|------|
| `~/.hermes/scripts/notebooklm_upload.py` | **주 파이프라인** — N:N 업로드 (일반 + 숏츠 동시) |
| `~/.hermes/scripts/notebooklm_youtube_pipeline.py --mode shorts` | 신규 생성용 — Notion DB 기반侯選 → 영상 → 숏츠 (거의 사용 안 함) |

## 핵심: FFmpeg 9:16 Crop-Fill 필터 (2026-04-30 수정)

**⚠️ Letterbox 블러 방식 사용 금지** — `scale=1080:-1` + overlay letterbox는 콘텐츠가 프레임의 ~32%만 차지 → **YouTube가 일반 영상으로 분류** (Shorts 아님).

**올바른 필터 — Center Crop-Fill:**
```bash
ffmpeg -y -i input.mp4 -t 60 \
  -filter_complex " \
[0:v]crop=ih*9/16:ih:(iw-ih*9/16)/2:0,scale=1080:1920,setsar=1[fg];
[0:a]atrim=0:60,afade=t=out:st=55:d=5[aout];
[fg][aout]concat=n=1:v=1:a=1[vout]" \
  -map "[vout]" \
  -c:v libx264 -preset ultrafast -crf 26 \
  -c:a aac -b:a 128k \
  -pix_fmt yuv420p -movflags +faststart \
  output.mp4
```

**원리:**
- `crop=ih*9/16:ih:(iw-ih*9/16)/2:0` → 16:9 landscape 원본의 중심에서 9:16 영역만 크롭
- `scale=1080:1920` → 9:16 1080x1920 고정 해상도
- `setsar=1` → SAR=1:1으로 고정 (DAR=9:16 정상)
- 최종: **화면 100%가 콘텐츠 + 메타데이터 정상** → YouTube Shorts로 자동 분류 ✅

**❌ 버그 수식 (사용 금지):**
```
crop=iw*min(1920/iw\,1080/ih):ih*min(1920/iw\,1080/ih):...
→ 16:9 (1920x1080)에서 min(1,1)=1 → crop 안 됨 → SAR/DAR 왜곡 → 일반 영상 분류
```

**crop 계산 검증:**
| 원본 | 크롭 결과 | 스케일 | SAR | DAR |
|------|-----------|--------|-----|-----|
| 1920x1080 | 608x1080 @ (656,0) | 1080x1920 | 1:1 ✅ | 9:16 ✅ |
| 1280x720 | 405x720 @ (438,0) | 1080x1920 | 1:1 ✅ | 9:16 ✅ |
| 3840x2160 | 1215x2160 @ (1312,0) | 1080x1920 | 1:1 ✅ | 9:16 ✅ |

**⚠️ 검증 단계 필수:** 업로드 후 `ffprobe`로 SAR/DAR 확인
```bash
ffprobe -v quiet -print_format json -show_streams output.mp4 | python3 -c "
import json,sys; d=json.load(sys.stdin)
for s in d['streams']:
    if s.get('codec_type')=='video':
        ok = abs(s['width']/s['height']-0.5625)<0.01 and s.get('sample_aspect_ratio')=='1:1'
        print(f'SAR={s.get(\"sample_aspect_ratio\")} DAR={s.get(\"display_aspect_ratio\")} → {\"✅ Shorts\" if ok else \"❌ 일반 영상\"}')"

## 사용법

```bash
# 일반 파이프라인 (N:N 업로드 — 이걸 사용)
python3 ~/.hermes/scripts/notebooklm_upload.py
```

## 의존성

|| 항목 | 경로 | 비고 |
|------|------|------|
| ffmpeg | 시스템 `ffmpeg` | 필수 |
| ffprobe | 시스템 `ffprobe` | 필수 |
| upload.py | `~/.hermes/skills/creative/youtube-uploader/scripts/` | YouTube 업로드 |

## YouTube 설명 템플릿

```
{요약 텍스트}

▼ 더보기
📚 출처
• 제목
  https://url...

#ICBM #AI #테크 #개발자 #인공지능
```

**Shorts description=None(`""`) 금지** — 항상 유효한 설명 텍스트 사용

## ⚠️ 02:15 숏츠 크론 검증 체크리스트

02:15 크론 실행 후 반드시 확인할 것:
1. `/tmp/icbm_notebooklm/`에 다운로드된 MP4가 존재하는지
2. `/tmp/icbm_shorts/`에 편집된 숏츠 MP4가 생성되었는지
3. YouTube에 실제로 숏츠가 게시되었는지 (URL 반환 여부)
4. **description이 빈 문자열이 아닌지**

## 알려진 문제

|| 문제 | 원인 | 해결 |
|------|------|------|
| 숏츠 description 빈 문자열 | `upload_to_youtube(shorts_path, title, "", ...)` | `build_youtube_description()` 사용 ✓ |
| 02:15 크론 ok인데 숏츠 미업로드 | description=""인데 상태 ok로 표시 | 빈 description 시 텔레그램 알림 +紧急修复 |
| **숏츠에音频 스트림 없음** | cron 프롬프트 임베디드 FFmpeg 명령에 `-map 0:a?` 누락 | ✅ 2026-04-29 수정 완료 (jobs.json db6af124e115) |
| **숏츠가 일반 영상으로 분류됨** | Letterbox 블러 방식 → 콘텐츠가 프레임의 ~32%만 차지 → YouTube가 Shorts 미분류 | ✅ 2026-04-30: Crop-Fill 방식으로 교체 (`notebooklm_upload.py` + SKILL.md 수정) |

## ⚠️ FFmpeg Audio Lost — 크론 프롬프트 임베디드 명령 주의

**발생 일시:** 2026-04-28, 2026-04-29 (连殺) → ✅ 2026-04-29 수정 완료

**근본 원인:** cron 프롬프트에 **임베디디드 FFmpeg 명령**에서 `-map 0:a?` 없이 `-filter_complex`만 사용하면, 필터 체인이 비디오 스트림만 출력하고 오디오는 버려짐. `-c:a aac -b:a 128k`가 있어도 **입력 오디오를 매핑하지 않으면 FFmpeg는 정상 종료(returncode=0)** 하므로 stderr로 탐지 불가.

**cf. `notebooklm_youtube_pipeline.py --mode shorts` 스크립트는 이미 `-map "[aout]"` 포함 so it was never the problem. The issue was always in the cron job's embedded prompt.**

**수정 완료 (2026-04-29):** `~/.hermes/cron/jobs.json` job `db6af124e115`의 FFmpeg 명령에 `-map 0:a?` 추가.

## ⚠️音频 검증 구현 포인트

FFmpeg의 `-c:a aac` 플래그가 있어도, 입력 audio가 없으면 FFmpeg는 **정상 종료(returncode=0)하지만 영상에 audio stream이 없음**. 반드시 ffprobe로 검증해야 함:

```python
def has_audio_stream(path):
    r = subprocess.run(
        ["ffprobe", "-v", "error", "-select_streams", "a",
         "-show_entries", "stream=codec_type", "-of", "csv=p=0", path],
        capture_output=True, text=True, timeout=10
    )
    return r.returncode == 0 and r.stdout.strip().startswith("audio")
```

**무음 영상이 YouTube에 업로드되는 것을 방지**하기 위해, 영상 생성 직후 + 업로드 직전에 반드시 이 검증 함수를 사용할 것.
