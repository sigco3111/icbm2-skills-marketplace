---
name: youtube-shorts-factory
description: "YouTube Shorts 숏츠 영상 자동 제작 — AI 뉴스, 개발 팁, GitHub 트렌딩, 오픈소스 소개, 커스텀 토픽을 60초 이내 숏츠로 자동 생성 (NotebookLM 팟캐스트 오디오 + 배경 이미지)"
tags: [youtube, shorts, video, podcast, notebooklm, automation, content-creation]
---

# YouTube Shorts Factory

AI 뉴스, 개발 팁, GitHub 트렌딩, 오픈소스 소개, 커스텀 토픽을 YouTube Shorts 숏츠 영상으로 자동 제작합니다. **NotebookLM 팟캐스트 오디오**를 나레이션으로 사용합니다.

## 스크립트 위치

`~/.hermes/scripts/youtube_shorts_factory.py`

## 사용법

### 기본 (AI 뉴스 자동 수집)

```bash
python3 ~/.hermes/scripts/youtube_shorts_factory.py --type ai_news
```

### 콘텐츠 타입

| 타입 | 옵션 | 설명 |
|------|------|------|
| `ai_news` | `--type ai_news` | HN + Reddit에서 AI 뉴스 자동 수집 |
| `dev_tip` | `--type dev_tip` | 사전 정의 개발 팁에서 랜덤 선택 |
| `github_trending` | `--type github_trending` | GitHub 트렌딩 레포 자동 수집 |
| `opensource` | `--type opensource` | 오픈소스 도구 자동 수집 |
| `custom` | `--type custom --topic "토픽"` | 커스텀 토픽 (필수: `--topic`) |

### 전체 옵션

```bash
python3 ~/.hermes/scripts/youtube_shorts_factory.py \
  --type custom \
  --topic "제목" \
  --extra "추가 설명 텍스트" \
  --no-upload    # 업로드 생략 (테스트용)
  --no-bgm       # BGM 생략
  --output-dir /tmp/output  # 출력 디렉토리 (기본: /tmp/icbm_shorts)
```

## 파이프라인

```
콘텐츠 수집 → 대본 생성 → NotebookLM 노트북 생성 → 소스 추가 → 팟캐스트 오디오 생성 → 59초 트림 → 배경 이미지 → ffmpeg 영상 조합 → YouTube 업로드
```

### Step 1: 콘텐츠 수집 + 대본 생성
- **ai_news**: HN top 30 + r/artificial + r/MachineLearning에서 AI 키워드 매칭
- **dev_tip**: 사전 정의된 개발 팁 15개에서 랜덤 선택
- **github_trending**: GitHub Trending HTML 스크래핑 + **Notion DB 기반 중복 방지** (이미 업로드한 repo 자동 제외)
- **opensource**: Product Hunt + GitHub trending 백업
- **custom**: `--topic`과 `--extra`로 대본 구성
- 대본 구조: Hook → Body → CTA (구독 유도)

### Step 2: NotebookLM 팟캐스트 오디오 생성
- 소스 텍스트로 NotebookLM 노트북 생성
- 팟캐스트(audio) 생성 요청 (`--format brief`, `--language ko`)
- `artifact poll`로 폴링하여 완료 대기 (최대 10분)
- 오디오 다운로드 후 59초로 자동 트림
- 노트북 자동 삭제 (정리)

### Step 3: 배경 이미지 (Pillow)
- 1080x1920 (9:16) 세로형
- 다크 그라디언트 배경 + 글로우 이펙트
- ICBM 로고 + 타입 뱃지 + Hook/Body/CTA 텍스트
- 해시태그 + 구독 유도 바

### Step 4: ffmpeg 영상 조합
- 정지 이미지 + 팟캐스트 오디오 → MP4 (libx264 + AAC)
- 최대 59초 자동 제한

### Step 5: YouTube 업로드
- `~/.hermes/skills/creative/youtube-uploader/scripts/upload.py` 사용
- 제목: `{타입} | ICBM #{YYYY-MM-DD}`
- 카테고리: 28 (Science & Tech)
- 프라이버시: public

## 의존성

| 항목 | 경로 | 비고 |
|------|------|------|
| notebooklm CLI | `~/.hermes/venv-notebooklm/bin/notebooklm` | Python 3.13 venv |
| Pillow | venv `site-packages` (sys.path injection) | 시스템 Python 3.9에서 사용 |
| ffmpeg | 시스템 `ffmpeg` | 필수 |
| ffprobe | 시스템 `ffprobe` | 필수 |
| upload.py | `~/.hermes/skills/creative/youtube-uploader/scripts/` | YouTube 업로드 |

## 색상 테마

| 타입 | Primary | Accent | Glow |
|------|---------|--------|------|
| ai_news | (30, 64, 175) | (96, 165, 250) | (59, 130, 246) |
| dev_tip | (22, 101, 52) | (74, 222, 128) | (34, 197, 94) |
| github_trending | (100, 50, 150) | (167, 139, 250) | (139, 92, 246) |
| opensource | (120, 53, 15) | (251, 146, 60) | (249, 115, 22) |
| custom | (30, 58, 95) | (56, 189, 248) | (14, 165, 233) |

## 중복 방지 (GitHub Trending)

`github_trending` 타입 실행 시 **Notion 🔥 GitHub Trending DB**를 조회하여 이미 YouTube에 업로드한 repo를 자동 제외합니다.

### Notion DB 설정
- **DB ID**: `33f76f2e-9097-8176-a537-d40ebb476ef9`
- **속성**: Uploaded (checkbox), UploadDate (date), VideoTitle (rich_text)

### 동작 흐름
1. GitHub Trending에서 전체 repo 수집
2. Notion DB에서 `Uploaded=true`인 repo URL 목록 조회
3. 중복 repo 제외 후 첫 번째 후보 선택
4. YouTube 업로드 성공 시 Notion에 `Uploaded=true` + `UploadDate` + `VideoTitle` 마킹
5. 모든 repo가 이미 업로드된 경우 "새 repo 없음"으로 종료

## YouTube 설명 템플릿 표준 (▼ 더보기 + 📚 출처)

모든 YouTube 업로드 시 **일관된 설명 템플릿**을 사용합니다.

### 템플릿 형식

```
{요약 텍스트}

▼ 더보기
📚 출처
• 제목...
  https://url...

#ICBM #AI #테크 #개발자 #인공지능
```

### 적용 스크립트

| 스크립트 | 설명 생성 함수 |
|---------|--------------|
| `youtube_shorts_factory.py` | `build_youtube_description(content_type, data, extra_text=full_script)` |
| `notebooklm_youtube_pipeline.py` | `build_youtube_description(content_type, data, extra_text="...")` |
| `youtube_video_factory.py` | `video_desc`에 직접 `▼ 더보기\n📚 출처\n{desc_links}` + 해시태그 포맷팅 |

### 핵심 규칙

- **Shorts**: description=None(`""`) 금지 → 항상 `build_youtube_description()` 사용
- **일반 영상**: `desc_links`가 있으면 `▼ 더보기\n📚 출처` 헤더 필수
- **data**: `{"url": "...", "title": "..."}` 형태의 list 또는 dict

## 알려진 문제

| 문제 | 원인 | 해결 |
|------|------|------|
| 숏츠 description 빈 문자열 | `upload_to_youtube(shorts_path, title, "", ...)` 로 호출 | `build_youtube_description()`으로 교체 ✓ (2026-04-27) |

## 출력

- 영상: `{output_dir}/output_bgm_{timestamp}.mp4`
- 썸네일: `{output_dir}/thumbnail.png`
- 나레이션: `{output_dir}/narration_{timestamp}.mp3`
- 배경: `{output_dir}/background_{timestamp}.png`
