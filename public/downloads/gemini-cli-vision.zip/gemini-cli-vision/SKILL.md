---
name: gemini-cli-vision
description: "Gemini CLI로 이미지 분석 — OpenRouter 불가 시 백업 또는 주인님 명시 요청 시 사용"
tags: [vision, gemini-cli, image-analysis, backup]
---

# Gemini CLI 이미지 분석

> Google Gemini CLI를 이용한 이미지 분석 스킬. 기본은 `vision_analyze`(OpenRouter gemini-3-flash-preview)를 사용하고, 본 스킬은 백업/명시 요청 시에만 사용.

## 사용 조건

- OpenRouter 비전 모델 사용 불가 시 (자동 폴백)
- 주인님이 명시적으로 "gemini cli로 분석해줘"라고 요청한 경우

## 사전 준비

- Gemini CLI 설치: `npm install -g @google/gemini-cli`
- 인증 완료: `gemini auth login` (브라우저 로그인 필요)
- 인증 상태는 `~/.gemini/` 디렉토리로 관리됨

## 실행 방법

### 1. 이미지를 워크스페이스로 복사 (중요!)

Gemini CLI는 샌드박스 제한으로 `~/.hermes/hermes-agent/` 외부 파일을 읽지 못함. 반드시 먼저 복사해야 함.

```bash
cp /path/to/source/image.jpg /Users/hjshin/.hermes/hermes-agent/tmp_vision.jpg
```

### 2. Gemini CLI 실행

```bash
cd /Users/hjshin/.hermes/hermes-agent && gemini -p "이 이미지를 한국어로 자세히 분석해줘. 파일: tmp_vision.jpg"
```

### 3. 임시 파일 정리

```bash
rm /Users/hjshin/.hermes/hermes-agent/tmp_vision.jpg
```

## 파이프라인 (한 줄 실행)

```bash
cp IMAGE_PATH ~/.hermes/hermes-agent/tmp_vision.jpg && cd ~/.hermes/hermes-agent && gemini -p "PROMPT. 파일: tmp_vision.jpg" && rm ~/.hermes/hermes-agent/tmp_vision.jpg
```

## 주의사항

- **샌드박스 제한:** 반드시 `~/.hermes/hermes-agent/` 내부에 파일을 복사 후 분석할 것
- **할루시네이션 주의:** OpenRouter(gemini-3-flash-preview)보다 할루시네이션 빈도가 높을 수 있음
- **토큰 제한:** API 무료 티어 기준 1,000건/일, 초과 시 4초 대기 후 재시도
- **실행 디렉토리:** `cd ~/.hermes/hermes-agent` 필수 (워크스페이스 루트여야 함)
- **시간 초과:** 분석에 30-60초 소요될 수 있음. `timeout=90` 권장

## 비교: Gemini CLI vs vision_analyze (OpenRouter)

| 항목 | Gemini CLI | vision_analyze |
|---|---|---|
| 모델 | Gemini 3 (기본) | gemini-3-flash-preview |
| 비용 | 무료 (1,000건/일) | OpenRouter 크레딧 소모 |
| 정확도 | 보통 (할루시네이션 가능) | 높음 |
| 속도 | 느림 (30-60초) | 빠름 |
| 파일 접근 | 워크스페이스 내부만 | 제한 없음 |
