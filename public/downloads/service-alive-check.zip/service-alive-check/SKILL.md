---
name: service-alive-check
description: Verify whether an online service or product the user referenced is still alive when its URL is dead, rebranded, or returning errors. The user explicitly wants two outcomes — "if it's still around, find the new URL" OR "if it's really dead, tell them honestly with sources". Triggers on any URL the user provided that 404s / DNS-fails / redirects off-topic, and on natural-language requests like "is X still around?", "X 링크 죽었는데 살아있어?", "X 서비스 종료됐어?", "이 사이트 살아있어?", "X 폐쇄됐다며? 진짜야?".
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [web, verification, link-checking, service-status, deadlink, rebranding]
    related_skills: [factchk, research/auto-researcher, research/arxiv, research/notion-dev-news-sync]
prerequisites:
  commands: [curl, python3, urllib]
---

# Service-Alive-Check — 죽은 URL 뒤에 숨은 새 도메인 찾기

사용자가 알려준 URL이 404를 반환할 때, "404예요"로 끝내지 않고 **같은 서비스가 다른 도메인으로 살아 있는지** 능동적으로 검증하는 클래스. 진짜 종료된 거면 위키/공식 announcement URL을 첨부해 정직하게 보고.

## When to use (trigger ladder)

1. 사용자가 **특정 URL을 명시**했는데 그 URL이 404 / DNS fail / redirect-to-other-product → 바로 발동
2. 사용자가 명시적으로 **"(서비스가 종료되었다면 종료되었다고 알려줘)"** 같은 멘트를 붙임 → 최강 트리거
3. 사용자가 "이 사이트 살아있어?", "X 서비스 종료됐어?" 류 자연어 → 발동
4. 단순 웹 검색/사실 확인은 `research/auto-researcher` 또는 `factchk` — 이 스킬은 **URL 죽음 + 새 도메인 추적**에 특화

## The two honest outcomes

워크플로우는 항상 이 두 결론 중 하나로 귀결돼야 함. **중간에 결론 회피 금지**.

### Outcome A — Re-alive at a new URL
- 정확한 새 URL (실측 200 검증)
- 한국어 페이지가 따로 있으면 그 URL도
- 다운로드 / 로그인 / 모바일 등 실제 진입점
- 가능한 한 공지/위키 출처

### Outcome B — Genuinely shut down
- "확인된 종료 사실" — 한국어 위키/공식 announcement/뉴스 1~2개 출처 첨부
- 종료일이 명확하면 함께 표기
- "대체 서비스 후보" 1~2개가 있으면 (사용자가 묻지 않아도) 정직하게 잠깐 첨부

**중간 상태일 때**: "명확한 증거 없음 — 다음 후보 직접 확인해주세요" + 사용자가 시도해볼 수 있는 URL 2~3개.

## Workflow (7 steps)

### 1. First-contact probe (1차 검증)
다이렉트로 1번 죽은 게 맞는지 한 번 더 확인. 30초 안에:

```bash
curl -sS -L -I -A "Mozilla/5.0" "https://<user-given-url>" 2>&1 | head -5
# DNS fail → Could not resolve host
# 404 → HTTP/2 404
# OK but redirect → follow Location
```

curl exit code 6 (DNS) / 22 (HTTP 4xx) / 28 (timeout) 구분. **redirect가 보이면 끝까지 따라가서** 진짜 어디로 갔는지 본다.

### 2. Parent domain sweep (상위 도메인)
종종 같은 서비스가 `<product>.com` → `<product>.<parent>.com` 같은 식으로 자리를 옮김. 흔한 패턴 시도:

```bash
for h in "<product>.nexon.com" "<product>.<parent>.com" "play<product>.com" \
         "<product>.<player>.com" "m<product>.<player>.com" "<product>.kr"; do
  code=$(curl -sS -o /dev/null -w "%{http_code}" -L --max-time 5 "https://$h")
  echo "$code  $h"
done
```

상위 브랜드가 한국이면 `nexon.com / ncsoft.com / krafton.com / netmarble.com / kakao.com / naver.com`, 글로벌이면 `<service>.github.io`, `app.<service>.com`, `m.<service>.com` 후보.

### 3. Wikipedia lookup (한국어/영문 양쪽)
**`User-Agent` 헤더 반드시 추가 — 기본 urllib은 일부 404 트랩이 있음** (2026-07-14 검증):

```python
import urllib.request
url = "https://en.wikipedia.org/wiki/<Title>"
req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (research)"})
with urllib.request.urlopen(req, timeout=15) as r:
    html = r.read().decode("utf-8", errors="replace")
```

검색 시도 순서:
- `https://en.wikipedia.org/wiki/<Exact Title>`
- 띄어쓰기 변형: `Title_Worlds` / `Title_Worlds_(service)` / `Title Worlds` 같은 변형
- 한국어: `https://ko.wikipedia.org/wiki/<URL-encoded>`

본문 `<p>` 텍스트 추출:
```python
import re, html as ihtml
ps = re.findall(r'<p[^>]*>(.*?)</p>', html, re.DOTALL)
for p in ps:
    t = re.sub(r'<[^>]+>', ' ', p)
    t = ihtml.unescape(re.sub(r'\s+', ' ', t)).strip()
    if 60 < len(t):
        print(t[:400])
```

상태 키워드 찾기:
```python
for m in re.findall(r'(terminated[^<>]{0,80}|discontinued[^<>]{0,80}|service[^<>]{0,40}ended[^<>]{0,80}|launched[^<>]{0,80})', html, re.IGNORECASE)[:6]:
    print("STATUS>", m[:200])
```

### 4. Korean developer/marketing blogs & notice pages
서비스가 한국 기업 거면 한국어 공지를 찾아봄:
- `<parent>.com/news` / `<parent>.com/notice`
- 인벤 / 디스이즈게임 / 게임 메카 / 게임동아 (한국 게임)
- RSS 검색
- `Tistory`/`Brunch`/Naver 검색 `"<서비스>" 종료 OR 폐쇄 OR 중단`

### 5. GitHub README / releases
오픈소스나 SaaS면 GitHub repository의 latest release 또는 README.md가 명시적 종료 표시를 갖고 있는 경우가 많음:
```bash
gh api repos/<owner>/<repo>/releases/latest --jq '.name, .published_at, .body'
```
또는 README 마지막 commit:
```bash
gh api repos/<owner>/<repo> --jq '.updated_at, .description'
```

### 6. Maplestory Worlds (2026-07-14) — verified case
가장 큰 학습 신호 케이스. `maplestoryworlds.com`을 열었을 때 404, "서비스 종료?" 로 끝낼 뻔했는데:

| 시도 | 결과 |
|---|---|
| `maplestoryworlds.com` | DNS resolve fail (hostname 없음 — 즉 도메인 자체가 비어있음) |
| `mstd.kr` | SSL cert SAN mismatch |
| `playmaplestoryworlds.com` / `mswnaver.com` | DNS resolve fail |
| `nexon.com/maplestoryworlds` | 302 → ko/en/es 페이지 |
| `maplestoryworlds.nexon.com` (정식 도메인) | **HTTP 200 OK, 다국어 페이지 라이브** |
| `maplestoryworlds.nexon.com/ko/download` | 200 OK (실제 다운로드 페이지) |
| `ko.wikipedia.org/wiki/메이플스토리_월드` | 위키 본문에 "2022년 9월 1일부터 시범 서비스 중", 종료 기재 전혀 없음 |
| Steam / Play Store | Not Found (그러나 죽은 게 아님 — PC 전용 안내) |

**결론**: ✅ 라이브. **새 URL**: `https://maplestoryworlds.nexon.com/ko` (한국어), `https://maplestoryworlds.nexon.com` (영문), `https://maplestoryworlds.nexon.com/ko/download` (다운로드). 다국어 라이브 (en, ko, es, zh-cn, zh-tw).

이 케이스의 **학습**:
- DNS resolve fail ≠ 서비스 종료 (구 도메인이 비었어도 새 도메인이 살아있을 수 있음)
- Nexon 사 본 도메인(`<parent>.com/<product>`)이 302 redirect되는 패턴 자주 관찰
- 위키 한국어 페이지 status 표시 확인이 정확도 ↑

### 7. Final report template
사용자에게 답변할 때 권장 구조:

```
✅/❌ 한 줄 결론

정확한 새 URL (또는 종료를 확정짓는 출처)
- https://<new-url>  → 200 OK, [언어 페이지 URL]
- [다운로드 / 로그인 진입점]
- [공식 announcement URL]

근거: [1~3줄 — 위키/공식 출처 기반]
```

## Pitfalls (read before starting)

- **Default `urllib.request.urlopen` returns 404 for some Wikipedia URLs.** Always add `User-Agent: Mozilla/5.0`. Verified live 2026-07-14 on en.wikipedia. Without it you'll get bogus 404s and conclude "Wikipedia has no article" when it actually does.
- **DNS resolve fail (curl exit 6) is not the same as service shutdown.** The domain name may simply be unsold — the service can still live at `<parent>.com/<product>` or a completely different TLD.
- **"Could not resolve" can also be SSL cert mismatch** (`mstd.kr` 2026-07-14) — try without `-k` first; if cert error blocks, try once with `-k` to verify the HTTP body before giving up.
- **Wikipedia titles vary**: `Maple_Story_Worlds`, `MapleStory_Worlds`, `MapleStory_Worlds_(service)` — try variations. Also Korean (`메이플스토리 월드`) usually has more up-to-date status info for Korean products.
- **Don't infinite-loop.** If the parent domain sweep (step 2) returns 0 candidates with status < 500, don't go deeper than that. Move to Wikipedia/Korean sources and call it.
- **Don't trust single-source termination claims.** Some Korean gaming blogs announce "shutdown" prematurely. Cross-check at least one Wikipedia or official source before concluding Outcome B.
- **Don't hallucinate new URLs.** If you can't verify with `curl -I` returning < 400, don't include the URL. Report "no verified new URL found".

## Reference

- `references/maplestory-worlds-case-2026-07.md` — full transcript of the 2026-07-14 MapleStory Worlds verification, including exact curl output and Wikipedia extraction.
- `references/wikipedia-ua-pitfall.md` — short note on the User-Agent requirement and the title-variation patterns that bite during Wikipedia lookups.
