# Wikipedia lookup pitfalls — 2026-07-14

## Pitfall 1: User-Agent 없으면 일부 URL이 404처럼 보임

`urllib.request.urlopen`을 그냥 호출하면:
```python
import urllib.request
with urllib.request.urlopen("https://en.wikipedia.org/wiki/Foo") as r:
    ...
```
→ 일부 타이틀에서 `urllib.error.HTTPError: HTTP Error 404: Not Found` 던짐.

해결: `User-Agent` 헤더 추가.
```python
req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (research)"})
with urllib.request.urlopen(req, timeout=15) as r:
    html = r.read().decode("utf-8", errors="replace")
```

curl은 영향 없음 (기본 User-Agent가 `curl/x.y.z`라 위키가 받아줌).

## Pitfall 2: Wikipedia title 변형

정확한 타이틀을 모를 때 후보:
- 띄어쓰기 차이: `Foo Bar Worlds` vs `Foo_Bar_Worlds`
- 줄임말: `Foo_Bar_Worlds` vs `Foo_Bar_Worlds_(service)` vs `Foo_Bar_Worlds_(video_game)`
- 한국어: `메이플스토리 월드`, `Foo Bar Worlds`, `Foo Bar 월드` 양쪽 시도

2026-07-14 검증된 실패한 시도들:
- `https://en.wikipedia.org/wiki/Maple_Story_Worlds` → 404
- `https://en.wikipedia.org/wiki/MapleStory_Worlds_(service)` → 404
- `https://en.wikipedia.org/wiki/MapleStory_Worlds` → 404
- `https://ko.wikipedia.org/wiki/메이플스토리_월드` → ✅ 200

→ 한국어 위키가 더 관대함 (또는 한국 서비스는 한국어 위키만 등록돼 있음).

## Pitfall 3: 본문 추출 패턴

위키 HTML에서 본문 발췌 표준 패턴:
```python
import re, html as ihtml
ps = re.findall(r'<p[^>]*>(.*?)</p>', html, re.DOTALL)
for p in ps[:20]:
    t = re.sub(r'<[^>]+>', ' ', p)
    t = ihtml.unescape(re.sub(r'\s+', ' ', t)).strip()
    if 60 < len(t):
        print(t[:600])
```

`<p>` 안에는 `<a>`/`<i>` 같은 태그가 또 들어있어서 `re.sub` 한 번으로는 깨끗해지지 않음 → 두 단계: 태그 제거 → 공백 압축.

## Pitfall 4: Wikipedia "discontinued" 문자열 패턴

상태 확인용 regex (대소문자 무시):
```python
re.findall(
    r'(terminated[^<>]{0,80}'
    r'|discontinued[^<>]{0,80}'
    r'|service[^<>]{0,40}ended[^<>]{0,80}'
    r'|launched[^<>]{0,80})',
    html, re.IGNORECASE)
```

부정 매치 함정: "launched a new update" 같이 **긍정적인 동사 launched**도 매칭됨. 항상 컨텍스트 보고 진짜 종료 표시인지 사람 눈으로 한 번 더 확인.
