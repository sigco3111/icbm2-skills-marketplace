# MapleStory Worlds — 2026-07-14 verification trace

User asked: "메이플스토리 월드도 관심이 생기는데, 링크로 가면 페이지가 없음. 다시 찾아줘. (서비스가 종료되었다면 종료되었다고 알려줘)"

They had tried `https://maplestoryworlds.com` and got a dead page.

## Initial probes (all in one batch)

```text
curl -sS -L -I "https://maplestoryworlds.com"
  → curl: (6) Could not resolve host: maplestoryworlds.com
  → 즉 도메인 자체가 비어있음 (등록 자체 안 됐거나 만료 후 미재등록)

curl -sS -L -I "https://mstd.kr"
  → curl: (60) SSL: no alternative certificate subject name matches target host name 'mstd.kr'
  → 인증서 SAN 불일치. -k 로 HTTP body는 볼 수 있음. 도메인 추측이 빗나갔음 시그널.

curl -sS -L -I "https://playmaplestoryworlds.com"
  → curl: (6) Could not resolve host

curl -sS -L -I "https://mswnaver.com"
  → curl: (6) Could not resolve host

curl -sS -L -I "https://www.nexon.com/maplestoryworlds"
  → HTTP/1.1 302 Found
  → Location: https://www.nexon.com/maplestoryworlds
  → 끝점이 `<parent>.com/<product>` 패턴 → 정식 도메인이 따로 있을 확률 ↑

curl -sS -L -I "https://maplestoryworlds.nexon.com"
  → HTTP/2 302
  → location: /en
  → x-envoy-upstream-service-time: 165
  → server: cloudflare
  → 🚨 라이브 시그널
```

## 정식 도메인 정밀 검증

```text
GET https://maplestoryworlds.nexon.com
  → HTTP 200, 702 KB, content-type text/html
  → 메타 og:image, sentry-trace, csr 정상

GET https://maplestoryworlds.nexon.com/play
  → HTTP 200, 704 KB

GET https://maplestoryworlds.nexon.com/ko
  → HTTP 200, 901 KB (가장 무거움 → 한글 페이지 진짜 한국어 컨텐츠 채워져 있음)

GET https://maplestoryworlds.nexon.com/ko/download
  → HTTP 200, 723 KB
  → 다운로드 페이지 라이브
```

다국어 모두 200:
- `https://maplestoryworlds.nexon.com/en/download` → 200
- `https://maplestoryworlds.nexon.com/ko/download` → 200
- `https://maplestoryworlds.nexon.com/es/download` → 200
- `https://maplestoryworlds.nexon.com/zh-cn/download` → 200
- `https://maplestoryworlds.nexon.com/zh-tw/download` → 200

## Wikipedia verification (en/ko 양쪽)

```python
import urllib.request
url = "https://ko.wikipedia.org/wiki/메이플스토리_월드"
req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
with urllib.request.urlopen(req, timeout=20) as r:
    html = r.read().decode("utf-8")
```

위키 본문 발췌:
> "메이플스토리 월드 (MapleStory Worlds)는 2022년 9월 1일부터 대한민국에서 서비스 중인 메이플스토리 IP 리소스를 활용해 유저가 직접 콘텐츠를 제작할 수 있고..."

→ **위키 본문에 "종료" / "서비스 중단" / "closed" / "discontinued" 어느 키워드도 매칭되지 않음**.

Infobox 개발사: `넥슨 코리아` (한국), 배급사: `Toben Studio Inc. (미 El Segundo)` — Toben은 Nexon의 글로벌 자회사.

## Stores (negative)

```text
store.steampowered.com MapleStory Worlds 검색 → 결과는 다른 게임 (Dungeons of the Deep)
play.google.com/store/apps/details?id=com.nexon.msw → 404 Not Found
```
→ 모바일 스토어에서 n/a. PC 전용 서비스로 보임 (이건 "죽음"이 아니라 "모바일 미제공" — 사용자에게 정직히 구분 보고).

## Final report (Outcome A)

✅ 메이플스토리 월드: **라이브**. 종료 아님.

새 정식 URL:
- 🇰🇷 한국어 페이지: https://maplestoryworlds.nexon.com/ko
- 🇬🇧 영문: https://maplestoryworlds.nexon.com
- 다운로드: https://maplestoryworlds.nexon.com/ko/download (코나 계정 → Nexon Launcher 필요)
- 모바일은 공식 미제공 (PC만)

근거: ko.wikipedia.org 위키 본문에 "2022년 9월 1일부터 시범 서비스 중" 명시, 종료 키워드 부재. 공식 도메인 200 OK.
