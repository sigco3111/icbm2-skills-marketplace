# SNKRX 2026-07-23 Session Arc — End-to-End Real-Time

> 일회성 작업 일지가 아닌, **이번 세션에서 실제로 작동한 패턴/순서/의사결정**을 다른 LÖVE → Web 세션이 재현할 수 있도록 정리한 자료. SNKRX의 다른 세션이나 다른 게임 포팅에서도 같은 함정/순서를 만날 가능성이 높음.

## 전체 시간 순서

```text
[Phase 0]      원본 기준선          cfb9132 (5분)
[Phase 1]      PixiJS 스캐폴딩      63d5a7c
[Phase 2]      DPR 처리            6cac860a
[Phase 3]      폰트 로딩
[Phase 4]      이미지 로딩 (pal → RGBA 변환 필수)
[Phase 5]      정지 화면 v1        f594aac (5분)
[Phase 5]      정지 화면 v2        59a8779 (10분)
[Phase 5]      정지 화면 v3-시각검증
[Phase 5]      정지 화면 v3 (적 elite)
[Phase 5]      **첫 Playtest**       ★ 47분+ 정지 → 직접 수정
[Phase 2-c]     snake chain-follower  8d7d04e (5분, 직접 작성)
[Phase 2-d]     snake 화면 경계 튕김  271f0e3
[Phase 3]       자동 조준 + 투사체   d48a95b
[Phase 4-1]     적 사망 + killCount  b02e56b
[Phase 4-bug]   snake head + WAVE  3b4423d
[Phase 4-3]     Wave manager
[Phase 4-4]     뱀 HP + 접촉 데미지
[Phase 4-5]     골드/점수 HUD
[Phase 5-1~8]   이펙트 (Camera/Flashes/SpawnMarker/Shader/Lv.3/SlowMotion/Shop)
[Phase 5-6]     사운드
```

## 실제로 일어난 결정들

### 1. PixiJS v8 채택 (Phase 1)

원래 LÖVE 8단계 → Canvas 2D로 시작 → Canvas 2D의 한계(파티클, 셰이더, sprite 수) 때문에 **PixiJS v8으로 변경**. Canvas 2D는 단순 데모에만, 진짜 게임은 PixiJS.

### 2. 작은 카드로 분해 (Phase 5)

"정지 전투 장면" 카드는 47분+ 16+회 patch 후에도 안 끝남. **5장 분할**:
1. 좌표/데이터
2. 화면 골격
3. 뱀 + 영웅
4. 적 + HP바
5. UI + diff 메모

각 카드 5~10분. 사용자 승인 게이트 후 다음 카드.

### 3. 사용자 직접 개입 (2026-07-23 후반)

작업자가 5단계 우회(`Texture.from(canvas)` → `Image` → `ImageData` → cache-bust → unload)로 시간을 낭비한 후, **공식 PixiJS 스킬**을 설치하니 [CRITICAL] 섹션이 `Assets.load(url)`을 정석으로 알려줌. 그걸로 1줄에 해결.

또 다른 정체 시점에 **사용자가 직접 src/main.ts를 보고 5분 만에 snake chain-follower를 작성** (`8d7d04e`). 작업자가 30분+ 막혀 있을 때 운영자 직접 수정이 더 빠름.

## "작동한" 운영 패턴

```text
1. 카드 1장 = 5~10분 작업
2. 사용자 시각 검증 게이트 (Plyatest 카드)
3. 작업자 review-required → 운영자가 commit + build + dev 200 확인 후 complete
4. 자동 검증 카드는 사용자에게 묻지 않음
5. 시각 검증 카드는 Telegram 알림 + 사용자 확인 대기
```

## "작동하지 않은" 패턴

```text
1. 풀 게임 1장 카드 → 47분+ patch 루프 → 강제 중단
2. Canvas 2D + 8단계 자동 진행 → 사용자 "안된다" 평가 → 폐기
3. LÖVE PNG 직접 사용 → 팔레트 PNG → PixiJS 빈 텍스처
4. `Texture.from(url)` → PixiJS v8에서 미지원 (캐시만 읽음)
5. `Texture.from(imageData, {width, height})` → 두 번째 인자 미지원 (throw)
6. `npm run dev | tee ... &` → Hermes terminal wrapper에 갇힘
7. 단순 history 스냅샷으로 snake 구현 → 회전 시 직선 늘어짐
8. 작업자 auto-decomposition → 큰 카드를 5-7장 자동 분해, 사용자 처리 중인 파일과 충돌
9. 모든 카드를 Telegram 구독 → 알림 폭주
10. Assets.load 실패 시 fallback 없으면 부팅 자체 실패
```

## 일회성 vs 재사용

| 일회성 (capture 안 함) | 재사용 (skill에 capture) |
|---|---|
| Snake 구현 코드 | chain-follower 패턴, 30px spacing, 모듈 스코프 보관 |
| HTMLImageElement 디버깅 로그 | 광범위 로깅 템플릿, PixiJS 부팅 정석 |
| snkrx-clone 자산 경로 | PIL 변환, color_type=6 |
| 토스 알림 | PixiJS 부팅 우선순위 표 |
