# SNKRX 2026-07-23 Session Arc — End-to-End Real-Time

> 일회성 작업 일지가 아닌, **이번 세션에서 실제로 작동한 패턴/순서/의사결정**을 다른 LÖVE → Web 세션이 재현할 수 있도록 정리한 자료. SNKRX의 다른 세션이나 다른 게임 포팅에서도 같은 함정/순서를 만날 가능성이 높음.

## 전체 시간 순서

```text
[Phase 0]      원본 기준선          cfb9132 (5분)
[Phase 1]      PixiJS 스캐폴딩      63d5a7c
[Phase 2]      DPR 처리            6cac860a
[Phase 3]      폰트 로딩
[Phase 4]      이미지 로딩 (pal → RGBA 변환 필수)
[Phase 5]      정지 화면 v1        f594aac (5분)
[Phase 5]      정지 화면 v2        59a8779 (10분)
[Phase 5]      정지 화면 v3-시각검증
[Phase 5]      정지 화면 v3 (적 elite)
[Phase 5]      **첫 Playtest**       ★ 47분+ 정지 → 직접 수정
[Phase 2-c]     snake chain-follower  8d7d04e (5분, 직접 작성)
[Phase 2-d]     snake 화면 경계 튕김  271f0e3
[Phase 3]       자동 조준 + 투사체   d48a95b
[Phase 4-1]     적 사망 + killCount  b02e56b
[Phase 4-bug]   snake head + WAVE  3b4423d
[Phase 4-3]     Wave manager         402543b
[Phase 4-3-bug] waveManager TDZ      efdc879
[Phase 4-4]     뱀 HP + 접촉 데미지   aef29cb
[Phase 4-4-tm1] 테스트 모드(v1)      915beed
[Phase 4-4-tm2] 테스트 모드(v1 revert) 6a98d65
[Phase 4-5]     골드/점수 HUD
[Phase 5-1~8]   이펙트 (Camera/Flashes/SpawnMarker/Shader/Lv.3/SlowMotion/Shop)
[Phase 5-6]     사운드
```

## Phase 4 후반부 (2026-07-23 오후 ~ 저녁) — 추가 교훈

### TDZ ReferenceError 패턴 (Phase 4-3에서 발견)

`setupBattleSystem` 함수 내에서 `let waveManager`로 선언하고, `updateHud`가 `waveManager.currentWaveIndex`를 참조하는 패턴. `updateHud`가 `setupBattleSystem`의 앞쪽에서 호출되거나, 함수 본문 안에서 `let` 선언 위쪽에서 호출되면 **`ReferenceError: Cannot access 'waveManager' before initialization`** (Temporal Dead Zone).

**해결**:
1. `let` → `const` + 즉시 초기화로 변경 (가장 안전)
2. 또는 선언을 함수의 가장 위로 이동
3. 또는 wrapper class/object에 넣어서 선언 시 null로 초기화 후 사용

**이후 패턴**: setup/initialize 함수에서 `let` 변수가 같은 함수 내에서 다른 helper에 의해 참조되는 구조는 거의 항상 TDZ 위험. `const` + 즉시 할당이 안전.

### 작업자 self-revert 안티패턴 (Phase 4-4 테스트 모드)

작업자가 `?test=1` URL 파라미터로 활성화되는 테스트 모드를 commit `915beed`로 만들었지만, **같은 카드 실행 내에서 즉시 commit `6a98d65 revert`로 원본 설정을 되돌렸음**. 결과:
- 카드는 `done`으로 끝남
- 사용자가 `?test=1`을 열어도 변화 없음
- 운영자가 git log를 봐야 revert를 발견할 수 있음

**원인 (가설)**: 작업자가 task body의 "테스트 모드"를 만들면서 **원본 설정 보존 vs 테스트 모드 영구 적용을 헷갈린 것**. 카드 body는 "테스트 모드 추가"라고 했지만 작업자가 "원본 복구 + 카드 done" 패턴으로 처리.

**신호 감지**:
- git log에서 두 commit이 짧은 시간(수 분) 안에 revert 관계로 등장
- 사용자가 `?test=1` URL을 열었는데 변화 없음
- task body를 다시 읽었을 때 "revert 금지" 같은 명시적 단서가 없음

**해결 카드 패턴** (★★★ 다음 세션에서 재발 방지):
- "테스트 모드" 카드를 만들 때 **본문에 "revert 금지, 사용자가 OK 할 때까지 유지"를 명시적으로 적을 것** (또는 별도 카드로 분리해서 "원본 복구" 단계를 명시)
- 작업자가 test mode + original 보존을 동시에 하려고 하면 보통 한쪽이 망가짐. **두 카드로 분리**:
  - 카드 1: "테스트 모드 적용" (완료 후 보류)
  - 카드 2: "테스트 모드 해제 + 원본 복구" (사용자 OK 후)

### 접촉 데미지 HP 밸런스 (Phase 4-4)

LÖVE 원작의 적 maxHp은 75-130 정도, projectile damage는 25. **그러면 적이 발사체 4-6번에 죽어서 snake가 닿기 전에 적 사망**. 이로 인해 snake-적 접촉 이벤트 자체가 트리거되지 않음.

**해결** (Phase 4-4-bugfix `aef29cb`):
- 적의 maxHp을 더 높게 (예: 200-500) 또는
- projectile damage를 낮춤 (예: 5-10) 또는
- 적에 spawn 후 짧은 invulnerable 시간 추가 (예: 1.5초)

**균형 가이드**: 적 사망까지 ~5초, snake가 적 도달까지 ~3초가 되도록. 접촉 직전까지 적이 살아남아야 contact event 검증 가능.

### 1차 sanity 체크 (모든 새 카드에 권장)

작업자가 카드 body에서 "테스트 모드 활성화" 같은 변경을 가하면, 카드 종료 시 **반드시 첫 프레임에서 변화가 보이는지 검증**:
1. 작업자가 commit + push
2. dev server reload
3. 사용자가 `?test=1` 같은 활성화 URL을 열어 봄
4. **변화가 없으면 카드 body를 다시 읽어 작업자가 revert하지 않았는지 확인**

이 1차 sanity가 30초 안에 통과 못하면, 카드 body가 모호하다는 신호 → body를 더 명확히 다시 작성.

## 일회성 vs 재사용

| 일회성 (capture 안 함) | 재사용 (skill에 capture) |
|---|---|
| Snake 구현 코드 | chain-follower 패턴, 30px spacing, 모듈 스코프 보관 |
| HTMLImageElement 디버깅 로그 | 광범위 로깅 템플릿, PixiJS 부팅 정석 |
| snkrx-clone 자산 경로 | PIL 변환, color_type=6 |
| 토스 알림 | PixiJS 부팅 우선순위 표 |
| (Phase 4 후반) `let` waveManager TDZ | **TDZ ReferenceError 패턴 → SKILL capture** |
| (Phase 4 후반) 작업자 self-revert | **테스트 모드 카드는 revert 금지 명시, 두 카드로 분리 → SKILL capture** |
| (Phase 4 후반) 적 HP 75로 접촉 불가 | **snake-적 접촉 검증 시 적 HP 밸런스 가이드 → SKILL capture** |

## 실제로 일어난 결정들

### 1. PixiJS v8 채택 (Phase 1)

원래 LÖVE 8단계 → Canvas 2D로 시작 → Canvas 2D의 한계(파티클, 셰이더, sprite 수) 때문에 **PixiJS v8으로 변경**. Canvas 2D는 단순 데모에만, 진짜 게임은 PixiJS.

### 2. 작은 카드로 분해 (Phase 5)

"정지 전투 장면" 카드는 47분+ 16+회 patch 후에도 안 끝남. **5장 분할**:
1. 좌표/데이터
2. 화면 골격
3. 뱀 + 영웅
4. 적 + HP바
5. UI + diff 메모

각 카드 5~10분. 사용자 승인 게이트 후 다음 카드.

### 3. 사용자 직접 개입 (2026-07-23 후반)

작업자가 5단계 우회(`Texture.from(canvas)` → `Image` → `ImageData` → cache-bust → unload)로 시간을 낭비한 후, **공식 PixiJS 스킬**을 설치하니 [CRITICAL] 섹션이 `Assets.load(url)`을 정석으로 알려줌. 그걸로 1줄에 해결.

또 다른 정체 시점에 **사용자가 직접 src/main.ts를 보고 5분 만에 snake chain-follower를 작성** (`8d7d04e`). 작업자가 30분+ 막혀 있을 때 운영자 직접 수정이 더 빠름.

## "작동한" 운영 패턴

```text
1. 카드 1장 = 5~10분 작업
2. 사용자 시각 검증 게이트 (Plyatest 카드)
3. 작업자 review-required → 운영자가 commit + build + dev 200 확인 후 complete
4. 자동 검증 카드는 사용자에게 묻지 않음
5. 시각 검증 카드는 Telegram 알림 + 사용자 확인 대기
```

## "작동하지 않은" 패턴

```text
1. 풀 게임 1장 카드 → 47분+ patch 루프 → 강제 중단
2. Canvas 2D + 8단계 자동 진행 → 사용자 "안된다" 평가 → 폐기
3. LÖVE PNG 직접 사용 → 팔레트 PNG → PixiJS 빈 텍스처
4. `Texture.from(url)` → PixiJS v8에서 미지원 (캐시만 읽음)
5. `Texture.from(imageData, {width, height})` → 두 번째 인자 미지원 (throw)
6. `npm run dev | tee ... &` → Hermes terminal wrapper에 갇힘
7. 단순 history 스냅샷으로 snake 구현 → 회전 시 직선 늘어짐
8. 작업자 auto-decomposition → 큰 카드를 5-7장 자동 분해, 사용자 처리 중인 파일과 충돌
9. 모든 카드를 Telegram 구독 → 알림 폭주
10. Assets.load 실패 시 fallback 없으면 부팅 자체 실패
```

## 일회성 vs 재사용

| 일회성 (capture 안 함) | 재사용 (skill에 capture) |
|---|---|
| Snake 구현 코드 | chain-follower 패턴, 30px spacing, 모듈 스코프 보관 |
| HTMLImageElement 디버깅 로그 | 광범위 로깅 템플릿, PixiJS 부팅 정석 |
| snkrx-clone 자산 경로 | PIL 변환, color_type=6 |
| 토스 알림 | PixiJS 부팅 우선순위 표 |
