# LÖVE → TypeScript/Canvas 2D 포팅 디버깅 체크리스트

> snkrx-web v0.1.12 실측. 게임이 "안 움직임" / "회전만 함" / "적이 안 보임" 등 증상별 1차 진단.
> 0.5초 간격 한 줄 디버깅 로그가 가장 효과적 — 화면 안 보일 때 headX/Y 변화 여부로 "이동 안 함 vs 이동하지만 화면 밖" 구분 가능.

## 증상별 진단

### 증상 1: "회전만 되고, 전진 안 됨"

**원인 후보 (우선순위 순)**:

1. **`setCameraPos` 호출 위치 오류** ★ 가장 흔함
   - `update()` 안에서만 호출 → `drawWorld()`에서 카메라 transform 적용 시 (0, 0) 그대로
   - **해결**: `drawWorld()` 안에서 `setCameraPos(arena.player.headX, arena.player.headY)` 명시적 호출
   - **증거**: headX/Y는 50~150씩 증가하지만 화면 밖으로 사라짐
   - **진단 로그**:
     ```ts
     if (Math.floor(performance.now() / 500) !== this._lastLog) {
       this._lastLog = Math.floor(performance.now() / 500);
       console.log(`[Player] head=(${this.headX.toFixed(1)}, ${this.headY.toFixed(1)})`);
     }
     ```
     - headX/Y 변함 → 이동은 OK, 카메라 문제
     - headX/Y 변하지 않음 → update/dt/speed 문제

2. **`invulnerable` 가드 음수**
   - `if (this.invulnerable > 0) this.invulnerable -= dt;` → 음수 됨
   - 충돌 가드 `if (this.player.invulnerable <= 0)` → 0 이하 충돌 → 라이프 0 → 게임오버 → reset → 적 스폰 → 충돌 → 무한 루프
   - **해결**:
     ```ts
     // Player.update
     if (this.invulnerable > 0) this.invulnerable = Math.max(0, this.invulnerable - dt);
     // Arena.handleCollisions
     if (this.player.invulnerable === 0) { /* 충돌 처리 */ }  // <= 0 → === 0
     ```

3. **speed/dt/angle 중 하나가 0 또는 NaN**
   - 로그: `head=(X, Y) angle=A° speed=S dt=D`
   - speed=0 → 1프레임 이동량 0. speed 기본값 명시 (예: 200)
   - dt=0 → 시간 정지. `requestAnimationFrame` 콜백의 `now - lastTime`
   - angle=NaN → `Math.cos(NaN) * 200 * 0.013 = NaN` → headX=NaN
   - 의심 위치: 적의 `vx/vy` NaN. `dx/dist * speed`에서 dist=0일 때. **해결**: `if (dist > 0.1) { vx = ... }` 가드 (이미 코드에 있지만 빠질 수 있음)

4. **적이 너무 가까이서 autoTarget이 (0, 0) 방향 가리킴**
   - `targetAngle = atan2(0, 0) = 0` (뱀 위치 0,0 / 적 위치 0,0)
   - 적과 충돌 빈번 → 라이프 감소 → 무한 루프
   - **해결**: 적이 너무 가까울 때 (`dist < 100`) autoTarget 무시 or 회피

### 증상 2: "키 누르면 90도만 움직임"

**원인**: `keyup` 핸들러가 `e.key` 검사 없이 무조건 `inputX=0, inputY=0`
- A 키 짧게 누름 (0.5초) → 0.5초 × 60fps × 3°/frame = 90° 회전
- 손 떼면 → `keyup` → 즉시 `inputX=0` → 더 이상 setTarget 호출 X
- **사용자 인식**: "90도만 회전하고 멈춤"

**해결**:
```ts
// ❌ WRONG
window.addEventListener('keyup', () => {
  if (!autoTarget) {
    inputX = 0; inputY = 0;  // 모든 키에 대해 무조건 리셋
  }
});

// ✅ CORRECT — e.key 검사
window.addEventListener('keyup', (e) => {
  if (e.key === 'a' || e.key === 'A' || e.key === 'ArrowLeft') inputX = Math.max(0, inputX);
  else if (e.key === 'd' || e.key === 'D' || e.key === 'ArrowRight') inputX = Math.min(0, inputX);
  else if (e.key === 'w' || e.key === 'W' || e.key === 'ArrowUp') inputY = Math.max(0, inputY);
  else if (e.key === 's' || e.key === 'S' || e.key === 'ArrowDown') inputY = Math.min(0, inputY);
});
```

**핵심**: `Math.max(0, inputX)` / `Math.min(0, inputX)` — A 떼면 좌측 입력이 0, 우측 입력이 있으면 유지. W/S도 동일.

### 증상 3: "적이 안 보임" / "적이 0,0 근처에 멈춤"

**원인**: 적의 `vx/vy`가 0 → AI가 안 움직임
- `Enemy:constructor`:
  ```ts
  if (def.ai === 'straight') {
    this.targetX = 0;
    this.targetY = 0;
  }
  ```
  → 추적자(Seeker)가 0,0 향해 가려다가 NaN. **`if (dist > 0.1)` 가드**가 빠지면 즉시 NaN.

**해결**:
```ts
switch (this.def.ai) {
  case 'chase':
  case 'boss':
    if (dist > 0.1) {
      this.vx = (dx / dist) * speed;
      this.vy = (dy / dist) * speed;
    }
    break;
  case 'straight':
    // 한 번에 (playerX - this.x, playerY - this.y) 방향으로 vx/vy 설정
    if (dist > 0.1) {
      this.vx = (dx / dist) * speed;
      this.vy = (dy / dist) * speed;
    }
    break;
  case 'swarm':
  case 'kamikaze':
    // chase와 동일
}
```

### 증상 4: "콘솔에 `r.closest is not a function` 에러"

**원인**: Vite dev overlay의 sr 함수가 `null` DOM 요소에 `.closest()` 호출. **빌드 후 dist로 띄우면 사라짐**.

**진단**:
```bash
# dev mode에서만 나타남
npm run dev  # 이 모드에서만 발생
# 해결: dist로 빌드
npm run build
npm run preview  # → http://localhost:4173 (이 모드에서 안 나타남)
```

### 증상 5: `L.closest is not a function` (Vite dev overlay 외)

**원인**: 게임 자체에서 `event.target.closest()` 호출 시 target이 null. `if (target) target.closest(...)` 가드 추가.

## 디버깅 로그 패턴 (가장 효과적)

### 패턴 1: 0.5초 간격 한 줄

```ts
if (Math.floor(performance.now() / 500) !== this._lastLog) {
  this._lastLog = Math.floor(performance.now() / 500);
  console.log(`[Player] head=(${this.headX.toFixed(1)}, ${this.headY.toFixed(1)}) angle=${(this.angle * 180 / Math.PI).toFixed(0)}° speed=${this.speed} dt=${dt.toFixed(4)} target=${(this.targetAngle * 180 / Math.PI).toFixed(0)}° units=${this.units.length} enemies=${enemies.filter(e => !e.dead).length}`);
}
```

**이 한 줄이 80% 진단**: headX/Y 변화 + 카메라 추적 여부 + 타겟 갱신 + 적/유닛 카운트.

### 패턴 2: 인스턴스 메모리에서 작업할 때 git push 누락

**흔한 함정**: 로컬에서 빌드 + Vercel deploy 끝났는데 `git push` 안 함 → GitHub Release 발행 안 함 → 사용자가 "릴리스 어디?" 물음.

**해결**: 빌드 스크립트 끝에 `git push origin master` 자동 추가하거나, README에 "Build → Vercel deploy → git push → gh release" 4단계 명시.

## 빌드 산출물 크기 가이드

| 산출물 | 크기 | 비고 |
|---|---|---|
| 8단계 완료 (snkrx-web v0.1) | 36.80 kB JS, 10.42 kB gzip | 데이터 + 게임 코어 + 렌더 모두 |
| 원본 SNKRX LÖVE | ~1.6 MB | love.exe 런타임 + 자산 |
| 게임 자산만 | ~80 MB | sprites + sounds |

**놀랍도록 작음** — TS는 JS로 컴파일되어 효율. 원본 SNKRX 대비 **2.3%**. (LÖVE 런타임 + 자산이 빠졌기 때문도 있음.)

## LÖVE → Canvas 2D 직접 매핑표 (요약)

| LÖVE | Canvas 2D | 비고 |
|---|---|---|
| `love.window.setMode(1280, 720)` | `<canvas width=1280 height=720>` + `ctx.scale(dpr, dpr)` | DPR 필수 |
| `love.graphics.rectangle(x,y,w,h,c)` | `ctx.fillRect(x-w/2, y-h/2, w, h)` | center-aligned |
| `love.graphics.circle(x,y,r,c)` | `ctx.arc(x, y, r, 0, 2π)` | |
| `love.graphics.print(t, font, x, y)` | `ctx.fillText(t, x, y)` | |
| `love.graphics.push()/pop()` | `ctx.save()/restore()` | |
| `love.image.newImage(path)` | `new Image(); img.src = path` | Promise 비동기 |
| `love.timer.step()` (dt) | `(now - lastTime) / 1000` | 직접 계산 |
| `love.filesystem.read(path)` | `fetch(path).then(r => r.text())` | |
| `Font:has_cjk(text)` | `/\\p{Script=Hangul}/u.test(text)` | Unicode property |
| `love.run` UTF-8 byte iter | `for (const ch of text)` | code point iterator |
| `love.system.getClipboardText()` | `navigator.clipboard.readText()` | Promise |
| `love.event.push('keypressed', key)` | `keydown` listener | 직접 매핑 |

## 즉시 적용 — 게임 포팅 시

1. **tsconfig strict는 v0.1에 끄고, v0.5+에 추가** (type-only import 강제는 인지 비용)
2. **data/ 폴더는 Python+regex 자동 변환** — 84개 영웅을 1초에
3. **render/ 폴더는 LÖVE의 `graphics.*` 1:1 매핑** — push/pop → save/restore
4. **game/ 폴더는 Entity-Component 패턴** — LÖVE의 GameObject 추상 클래스 + 상속
5. **LÖVE의 `local` 의존성은 TS에서는 `import/export`** — v0.1.8/v0.1.10 교훈
6. **DPR 스케일링 명시** — `ctx.scale(dpr, dpr)` 1줄
7. **모드팩 i18n (T() + lang/ko.json)** — LÖVE와 동일 아키텍처
8. **`setCameraPos`는 `drawWorld()` 안에서 호출** — 가장 흔한 함정
9. **invulnerable 가드는 `Math.max(0, ...)` + 충돌 체크는 `=== 0`** — 음수 버그 방지
10. **keyup 핸들러는 `e.key` 검사** — 입력 처리 함정 방지
11. **0.5초 간격 한 줄 디버깅 로그** — 80% 증상 진단 가능
12. **빌드 후 `git push + gh release` 자동화** — 인스턴스 메모리 함정 방지
