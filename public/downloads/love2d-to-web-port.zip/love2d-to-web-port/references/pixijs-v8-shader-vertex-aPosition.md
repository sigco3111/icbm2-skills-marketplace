# PixiJS v8 Shader Vertex Position Attribute (★ 2026-07-23 SNKRX session)

**Critical**: PixiJS v8 expects `aPosition` (NOT `aVertexPosition` like LÖVE or older PixiJS).

## The trap

Writing a custom vertex shader in PixiJS v8 with `in vec2 aVertexPosition;` produces:

```
Shader Error: geometry incompatible, geometry pixi_js?v=... missing the "aVertexPosition" attribute
```

The filter is then **silently disabled** — `sprite.filters = [filter]` still works, but the filter has no effect. This is one of the hardest PixiJS v8 bugs to debug because:

- Build passes
- `tsc --noEmit` passes
- `npm run build` succeeds
- `sprite.filters[0]` is not null
- `sprite.filters[0].enabled` is `true`
- The filter is added to PixiJS's filter system

**Yet the filter does nothing** because PixiJS's geometry is using `aPosition` and your vertex is binding `aVertexPosition`. PixiJS's filter system has no public way to set the location manually; the geometry has to match the vertex's input.

## The fix

Use `aPosition` (PixiJS v8's standard vertex attribute name). Copy the default vertex shader from `node_modules/pixi.js/lib/filters/defaults/defaultFilter.vert.mjs` (the v8 default). Or define it inline.

```typescript
import { Filter, GlProgram } from 'pixi.js'

// PixiJS v8 default vertex shader — must use aPosition, NOT aVertexPosition
const PIXIJS_V8_VERTEX = /* glsl */ `
in vec2 aPosition;
out vec2 vTextureCoord;

uniform vec4 uInputSize;
uniform vec4 uOutputFrame;
uniform vec4 uOutputTexture;

vec4 filterVertexPosition(void) {
  vec2 position = aPosition * uOutputFrame.zw + uOutputFrame.xy;
  position.x = position.x * (2.0 / uOutputTexture.x) - 1.0;
  position.y = position.y * (2.0 * uOutputTexture.z / uOutputTexture.y) - uOutputTexture.z;
  return vec4(position, 0.0, 1.0);
}

vec2 filterTextureCoord(void) {
  return aPosition * (uOutputFrame.zw * uInputSize.zw);
}

void main(void) {
  gl_Position = filterVertexPosition();
  vTextureCoord = filterTextureCoord();
}
`.trim()

// 5 shader families — combine / replace / shadow / full_combine / displacement
function createReplaceFilter(color: number): Filter {
  const glProgram = GlProgram.from({
    vertex: PIXIJS_V8_VERTEX,
    fragment: /* glsl */ `
in vec2 vTextureCoord;
out vec4 finalColor;
uniform sampler2D uTexture;
uniform vec4 uColor;
void main(void) {
  vec4 texColor = texture(uTexture, vTextureCoord);
  finalColor = vec4(uColor.rgb, texColor.a);
}
    `.trim(),
  })
  return new Filter({
    glProgram,
    resources: {
      replaceUniforms: {
        uColor: { type: 'vec4<f32>', value: float4FromHex(color) },
      },
    },
  })
}

// Apply to sprite — set enabled=true to activate
sprite.filters = [createReplaceFilter(0xff5252)]
sprite.filters[0]!.enabled = true
```

## Other common v8 vertex pitfalls

- `GlProgram.from({ vertex, fragment })` — both required, TypeError if either is missing
- `Texture.from(image, { width, height })` — v8 only accepts `boolean | undefined` for the 2nd arg, NOT `{ width, height }`
- `Texture.from(imageData)` — **throws** `Error: Could not find a source type for resource: [object ImageData]`; pass `imageData.data.buffer` instead, or use `Texture.from(canvas)`

## Diagnosing a silent filter failure

```typescript
// Add this to main.ts ticker to verify filter is active
app.ticker.add(() => {
  app.stage.children.forEach((child) => {
    if (child instanceof Sprite && child.filters?.length) {
      const f = child.filters[0] as Filter
      if (f.glProgram && !(f.glProgram as { name?: string }).name) {
        console.warn(`[snkrx] sprite ${child.label} has unnamed glProgram — likely vertex mismatch`)
      }
    }
  })
})
```

## When you should write a custom vertex

You almost never need to. PixiJS v8's `Filter.from()` accepts only `glProgram` and `gpuProgram` options; if you don't provide a vertex, it uses the default. The only reason to write a custom vertex is to **define extra `out` variables** that your fragment will read. For 99% of porting LÖVE shaders, the default vertex works.

If you do write a custom vertex, **start from the default vertex as a template** — don't write from scratch.
