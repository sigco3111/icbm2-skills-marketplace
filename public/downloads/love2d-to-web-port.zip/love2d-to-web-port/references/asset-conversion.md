# LÖVE 팔레트 PNG → PixiJS 호환 RGBA 변환 가이드

> SNKRX(LÖVE 11.5) → snkrx-web(PixiJS v8) 실측 (2026-07-23). 사용자 증상: "이 상태에서 안넘어감" + 정사각형 자리에 흰 십자선/placeholder만 표시.

## 문제 정의

LÖVE의 `love.image.newImageData`와 `ImageData:encode("png")`는 기본적으로 **8-bit colormap (palette) PNG**를 저장합니다.

```text
$ file /path/to/love-source/assets/images/warrior.png
PNG image data, 40 x 60, 8-bit colormap, non-interlaced
```

```text
PNG header:
- IHDR bytes 16-24: width=40 height=60
- IHDR byte 24: bit_depth=8
- IHDR byte 25: color_type=3  ← palette/indexed
```

PixiJS v8의 브라우저 PNG 디코더(HTMLImageElement → Canvas 2D → Texture 변환)는 일부 팔레트 PNG를 텍스처로 디코딩하지 못합니다. 결과적으로 Sprite는 만들어지지만 픽셀 텍스처가 비어 있어 **흰 십자선 placeholder** 또는 **빈 박스**만 화면에 보입니다.

## 디버깅이 어려운 이유

이 함정은 다음과 같이 모든 자동 검증 단계를 통과합니다:

```text
✓ curl HTTP 200 — 파일이 서빙됨
✓ npm run build 통과
✓ Assets.load() throw 안 함 — "성공" 반환
✓ PixiJS 로그에 에러 없음
✓ sprite.width / height 설정 정상
✓ 화면에 Sprite 객체 표시 (placeholder 흰 십자선)
✗ 실제 픽셀 텍스처가 안 보임  ← 사용자가 여기서 발견
```

"빌드 통과 + HTTP 200 + 코드 변경 정상"만으로는 발견할 수 없으며, **실제 브라우저에서 픽셀을 봐야만** 증상이 드러납니다.

## 해결: PIL로 RGBA로 변환

`scripts/png-palette-to-rgba.py` 참조. 핵심 로직:

```python
from PIL import Image
from pathlib import Path

for dst in sorted(dst_dir.glob('*.png')):
    src = backup_src / dst.name
    if src.read_bytes()[25] != 3:  # 팔레트가 아니면 그대로 복사
        dst.write_bytes(src.read_bytes())
        continue
    im = Image.open(src).convert('RGBA')
    im.save(dst, format='PNG', optimize=True')
```

## PIL 인터프리터 함정 (★ 가장 자주 만남)

macOS 시스템 Python의 PIL은 import 시 깨져 있습니다:

```bash
$ /usr/bin/python3 -c "from PIL import Image"
ImportError: cannot import name '_imaging' from 'PIL'
```

Hermes venv Python을 사용하면 정상:

```bash
$ /Users/mac/.hermes/hermes-agent/venv/bin/python -c "from PIL import Image; print(Image.__version__)"
12.2.0
```

스크립트 호출 시 명시적으로 Hermes venv Python을 사용:

```bash
HERMES_PY=/Users/mac/.hermes/hermes-agent/venv/bin/python
$HERMES_PY templates/png-palette-to-rgba.py \
    --src /Users/mac/work/snkrx-clone/assets/images \
    --dst /Users/mac/work/snkrx-web/public/assets/images
```

## ffmpeg / sips 회피 (★ 두 번째 자주 만남)

`ffmpeg`와 `sips`는 사용 가능해 보이지만 다음 문제가 있습니다:

```bash
# ffmpeg: 자동 2배 확대
$ ffmpeg -y -i warrior.png out.png
$ file out.png
PNG image data, 80 x 120, 8-bit/color RGBA, non-interlaced  ← 2배 확대됨

# ffmpeg: 일부 팔레트 PNG에서 변환 실패 (디코딩 에러)

# sips: 팔레트 → RGBA 변환 옵션이 약함 (실제로 변환 안 되는 경우 있음)
```

`-vf scale=W:H`로 명시적 크기를 줘도 `scale=iw/2:ih/2` 같은 명시적 필터가 자동으로 들어가는 경우가 있어 PIL이 가장 안전합니다.

## 검증 체크리스트

변환 후 다음을 모두 확인:

### 1. PNG 헤더 검증 (모든 파일)

```python
import struct
from pathlib import Path

for p in sorted(Path('public/assets/images').glob('*.png')):
    b = p.read_bytes()
    ct = b[25]  # 6 = RGBA, 3 = palette
    w, h = struct.unpack('>II', b[16:24])
    if ct != 6 or (w, h) != (40, 60):
        print(f'!! {p.name}: ct={ct} {w}x{h}')
```

```bash
$ file public/assets/images/warrior.png
PNG image data, 40 x 60, 8-bit/color RGBA, non-interlaced  ← ✓
```

### 2. dev server HTTP 200

```bash
$ npm run dev -- --host 127.0.0.1
$ curl -o /dev/null -w "%{http_code}\n" http://127.0.0.1:5173/assets/images/warrior.png
200
```

### 3. 브라우저 강력 새로고침 (★ HMR 캐시 무효화)

```text
Mac:  Shift + Cmd + R
Win:  Ctrl + Shift + R
```

Vite HMR이 이전 palette PNG 응답을 캐시할 수 있어 강력 새로고침 필수.

### 4. 콘솔에 텍스처 로드 경고 없는지

`loadOptional` 패턴을 쓴 경우 console.warn이 출력되지 않아야 정상:

```js
// main.ts
async function loadOptional(url) {
  try { return await Assets.load(url) }
  catch (e) { console.warn(`[snkrx] 텍스처 로드 실패 (${url}):`, e); return null }
}
```

## PixiJS 부팅 진단 절차 (텍스처가 안 보일 때)

1. **DevTools Console 확인**
   - `[snkrx] 텍스처 로드 실패 (...)` 경고 → URL 문제 (404, CORS, 잘못된 경로)
   - 경고가 없는데 placeholder → **팔레트 PNG 함정 (★ 9할)**

2. **Network 탭에서 이미지 응답 확인**
   - HTTP 200 + Content-Type: image/png → 서빙은 정상
   - Response size: 212 bytes (40x60 RGBA) vs 249 bytes (40x60 palette) → 변환됐는지 크기로 확인

3. **ImageBitmapSource.canConvert 확인** (PixiJS 내부)
   ```js
   const img = new Image()
   img.src = '/assets/images/warrior.png'
   await img.decode()
   console.log(img.width, img.height)  // 40 60 (정상 크기)
   console.log(img.src)  // 변환된 PNG URL인지
   ```

4. **PIL로 변환 안 됐는지 확인**
   ```bash
   $ /Users/mac/.hermes/hermes-agent/venv/bin/python -c "
   import struct
   b = open('public/assets/images/warrior.png','rb').read()
   print('ct=', b[25], 'size=', struct.unpack('>II', b[16:24]))
   "
   ct= 6 size= (40, 60)  ← RGBA, 원본 크기
   ```

## 부수 효과: loadOptional 패턴과 함께 쓰기

팔레트 PNG 함정을 완전히 막으려면 `loadOptional` + Sprite/Graphics fallback과 함께 쓰는 것이 안전:

```ts
async function loadOptional(url: string): Promise<Texture | null> {
  try { return await Assets.load<Texture>(url) }
  catch (e) { console.warn(`[snkrx] 텍스처 로드 실패 (${url}):`, e); return null }
}

const textures = {
  player: await loadOptional('/assets/images/warrior.png'),
  enemy: await loadOptional('/assets/images/speed_booster_elite.png'),
}

function addBattleDemo(app, textures) {
  if (textures.player) {
    const player = new Sprite(textures.player)
    // ... 정상 sprite
  } else {
    const player = new Graphics().rect(0, 0, 24, 36).fill(0xe53935)
    // ... 빨간 박스 fallback (어떤 경우에도 화면은 그려짐)
  }
}
```

**규칙**: PixiJS/Canvas 2D 부팅 시 모든 자산 로드는 `loadOptional`로 감싸고, 로드 결과가 null이어도 화면은 무조건 그린다. **빌드 성공 ≠ 부팅 성공 ≠ 화면 표시**.

## 학습 기록

- **2026-07-23**: SNKRX LÖVE 111개 PNG 중 61개가 팔레트. PIL로 일괄 변환. ffmpeg이 80x120으로 2배 확대되어 실패 → PIL 선택. macOS 시스템 Python의 PIL 깨짐 → Hermes venv Python 사용. 사용자 브라우저에서 placeholder 흰 십자선 → warrior.png와 speed_booster_elite.png가 비어 보임 → 변환 후 정상 표시.