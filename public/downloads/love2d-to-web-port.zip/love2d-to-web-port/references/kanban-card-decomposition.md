# Kanban 카드 분해 + Hermes 운영자 검증 패턴 (★ 2026-07-23)

## 핵심 교훈

풀 게임 한 장 카드는 **항상 실패**. 1시간+ 작업자 시간 낭비 + 16+ 회 patch 반복 후에도 끝나지 않음. 4-5장 단위로 분해하면 한 카드당 5-15분 내 완료.

## 카드 분해 규칙

### 안 되는 패턴 (★ 2026-07-23 1시간+ hang)

```text
[WEB-021] 정지 전투 장면 재현
  - 배경
  - 뱀 몸체
  - 영웅 위치
  - 적 생성
  - 투사체
  - HP바
  - 파티클
  - UI 골격
  → 47분+ 16+회 patch 후 npm run dev | tee & 백그라운드 wrapper에 갇힘
  → 강제 중단 후 archive
```

### 되는 패턴

```text
[WEB-021] 정지 전투 화면 v1: 좌표·코어 데이터
  - coords.ts에 모든 상수 정리
  - docs/STATIC_BATTLE_COORDS.md 작성
  - 5-10분 내 완료

[WEB-022] 정지 전투 화면 v2: 빌드 가능한 화면 골격
  - src/screens/staticBattle.ts 골격 작성
  - mountStaticBattleScene() 함수 시그니처만 확정
  - 배경 + 별 + placeholder 텍스트만 그리기
  - dev server에서 1280x720 응답 확인
  - 5-10분 내 완료

[WEB-023] 정지 전투 화면 v3: 뱀 본체 + 영웅 위치
  - 뱀 머리+몸통 history 기반 렌더
  - 첫 영웅 snake 머리 주변 자동 배치
  - 10-15분 내 완료

[WEB-024] 정지 전투 화면 v4: 적 + 투사체 + HP바 + 파티클
  - 적 4종 + HP바
  - 기본 투사체 자국 + 폭발 파티클 placeholder
  - 애니메이션 없이 정지 시각만
  - 10-15분 내 완료

[WEB-025] 정지 전투 화면 v5: UI 골격 + 비교 diff 메모
  - 골드/라운드/멈춤 버튼 placeholder UI
  - docs/STATIC_BATTLE_VISUAL_DIFF.md 작성
  - 자동 검증만, 시각 검증은 다음 카드
  - 10분 내 완료
```

## 카드 작성 템플릿

각 카드 body에 다음을 명시:

```text
## 작업
{구체적 1-2개 작업}

## 변경 허용 파일
- src/screens/staticBattle.ts (신규)
- src/main.ts (mountBattleDemo 호출 추가)
- src/assets.ts (좌표 import 추가)

## 완료 조건
- npm test 통과 (N개)
- npm run build 통과
- dev server 200 OK
- {시각 검증 여부}

## 제외사항
- 셰이더 작업 금지
- 다른 시스템 의존 금지
- 애니메이션 금지

## 의존성
- parent: t_XXXXXX (v1 완료 후 진행)
```

## 작업자 review-required 처리 패턴

모든 자동 검증 카드의 작업자가 마지막에 `kanban_block(reason='review-required: ...')`로 정지. **이는 정상 동작이지만 작업자 보고를 그대로 믿으면 안 됨**.

### Hermes 운영자 검증 단계

```bash
# 1. 실제 commit 확인
cd /Users/mac/work/snkrx-web
git log -3 --oneline
git show --stat HEAD

# 2. build 직접 재실행
npm run build

# 3. test 직접 재실행 (있는 경우)
npm test

# 4. dev server 띄워서 자산 200 OK 확인
npm run dev &  # 절대 | tee & 같은 wrapper 사용 금지
sleep 4
for url in $(grep -oE '/assets/[^"'\'']+\.png' src/main.ts | sort -u); do
  curl -fsS -o /dev/null -w "${url}: HTTP %{http_code}\n" \
    "http://127.0.0.1:5175${url}"
done

# 5. 모두 통과 시 kanban complete로 강제 종료 + 다음 카드 dispatch
hermes kanban --board snkrx-web complete <task_id> \
  --summary "..." \
  --metadata '{"tests_passed": N, "reviewed_by": "hermes"}'
hermes kanban --board snkrx-web dispatch --max 1

# 6. 통과 못 하면 kanban reclaim + 더 작은 카드로 재할당
hermes kanban --board snkrx-web reclaim <task_id> \
  --reason "검증 실패: {증상}"
```

### 검증 실패 시 분해 예시

```bash
# 작업자가 30분 넘게 patch 반복 + 백그라운드 wrapper에 갇힘
# 1. 강제 종료
kill -TERM <worker_pid>

# 2. 카드 archive
hermes kanban --board snkrx-web archive <task_id>

# 3. 분할된 카드 4-5장 등록 (parents로 체인)
python3 - <<'PY'
import json, subprocess
cards = [
    ("v1: coords", body1, 95),
    ("v2: 골격", body2, 94),
    ("v3: 뱀+영웅", body3, 93),
    ("v4: 적+HP바", body4, 92),
    ("v5: UI+diff", body5, 91),
]
ids = []
for title, body, prio in cards:
    p = subprocess.run([
        'hermes', 'kanban', 'create', title,
        '--body', body,
        '--assignee', 'default',
        '--workspace', 'dir:/Users/mac/work/snkrx-web',
        '--priority', str(prio),
        '--json',
    ], capture_output=True, text=True)
    d = json.loads(p.stdout)
    ids.append(d['id'])
    print(d['id'], title)
# 의존성 체인
for i in range(len(ids)-1):
    subprocess.run(['hermes', 'kanban', 'link', ids[i], ids[i+1]], ...)
PY

# 4. 첫 카드 dispatch
hermes kanban --board snkrx-web dispatch --max 1
```

## dev server 띄울 때 절대 금지 패턴

```bash
# ❌ WRONG — Hermes terminal wrapper에 갇혀 무한 대기
npm run dev | tee /tmp/snkrx-dev.log &

# ❌ WRONG — 비슷한 wrapper 패턴
npm run dev > /tmp/log 2>&1 &

# ✅ CORRECT — Hermes terminal tool이 detach 처리
# (실제 tool 호출에서 background=true, watch_patterns 사용)
npm run dev -- --host 127.0.0.1
```

작업자에게 위 패턴을 강제하거나, 작업자 prompt에 "dev server는 절대 `| tee &` 또는 `> log &`로 띄우지 말 것" 명시.

## Telegram 알림 설정

시각 검증 카드만 Telegram 알림 보내고, 자동 검증 카드는 보내지 않음:

```bash
# 기본: 모든 카드 구독
for tid in $(hermes kanban --board snkrx-web list --json | jq -r '.[].id'); do
  hermes kanban notify-subscribe $tid \
    --platform telegram --chat-id 8359527845
done

# 또는 시각 검증 카드만:
hermes kanban notify-subscribe t_7c252d77 --platform telegram --chat-id 8359527845  # 정지 전투
hermes kanban notify-subscribe t_fe6d6add --platform telegram --chat-id 8359527845  # Playtest
hermes kanban notify-subscribe t_37d0e940 --platform telegram --chat-id 8359527845  # 전투 계획
```

`chat_id`는 사용자 본인의 Telegram ID. 확인 방법: Hermes 로그에서 `inbound message: platform=telegram user=... chat=...` 검색.

## 작업자가 죽었을 때 정리 패턴

작업자가 강제 종료되면 **untracked 파일이 디스크에 그대로 남음**:

```bash
git status --short
# M  src/main.ts        ← commit 안 된 변경
# ?? public/assets/images/*.png  ← 복사만 되고 commit 안 됨
# ?? src/screens/       ← 신규 디렉토리
```

다음 dispatch 전에 정리:

```bash
# Option A: 보존하고 다음 작업자가 이어서
git add -A
git commit -m "WIP: 작업자 사망, 미커밋 변경 보존"

# Option B: 폐기하고 처음부터
git stash -u
git stash drop

# Option C: 일부만 보존
git add path/to/specific/file
git commit -m "..."
git checkout -- path/to/other/file
```

**기본은 A**: 작업자의 작업물은 대부분 유효하므로 보존하고 다음 카드가 이어받게 함.

## 카드 status 흐름

```text
created (todo)
  ↓ 부모 카드 완료 시 자동
promoted (ready)
  ↓ 디스패처가 claim
claimed (running)
  ↓ 작업자가 작업 중
  ├─ complete → done (자동으로 다음 ready 카드 dispatch)
  ├─ block(review-required) → blocked (Hermes 운영자가 검증 후 complete/reclaim)
  └─ crash/timeout → 자동 재시도 or blocked
```