# Hermes Kanban CLI: Known Quirks (★ 2026-07-23 SNKRX 실측)

> `hermes kanban` CLI를 Python 자동화나 shell script로 호출할 때 자주 만나는 함정. 운영자 또는 작업자가 깨닫지 못하면 디버깅에 시간 소모.

## 1. JSON 응답 필드: `id` not `task_id`

`hermes kanban create ... --json` 응답은 `id` 필드:

```python
# ❌ WRONG — KeyError
result = subprocess.run(['hermes', 'kanban', 'create', '...', '--json'], capture_output=True)
task_id = json.loads(result.stdout)['task_id']  # KeyError!

# ✅ CORRECT
task_id = json.loads(result.stdout)['id']
```

전체 응답 예시:

```json
{
  "id": "t_574f769c",
  "title": "...",
  "body": "...",
  "assignee": "default",
  "status": "ready",
  ...
}
```

## 2. `kanban link` 인자 순서: parent 먼저

```bash
# ❌ WRONG — (child, parent) 순서로 호출하면 의존성 그래프가 거꾸로 됨
hermes kanban link t_CHILD t_PARENT
# 출력: "Linked t_CHILD -> t_PARENT"
# 결과: CHILD가 PARENT의 부모가 됨 (의도와 반대)

# ✅ CORRECT — parent 먼저
hermes kanban link t_PARENT t_CHILD
# 출력: "Linked t_PARENT -> t_CHILD"
# 결과: PARENT가 CHILD의 부모
```

Python 자동화에서 특히 자주 발생:

```python
# ❌ WRONG
subprocess.run(['hermes', 'kanban', 'link', child_id, parent_id])

# ✅ CORRECT
subprocess.run(['hermes', 'kanban', 'link', parent_id, child_id])
```

`kanban link` 사용법: `kanban link [-h] parent_id child_id` (positional arguments).

## 3. `reclaim`은 `running` 상태에서만 작동

```bash
# ❌ WRONG — blocked 상태에서 reclaim 시도
hermes kanban reclaim t_XXX
# 출력: "cannot reclaim t_XXX (not running or unknown id)"

# ✅ CORRECT — 상태별 처리
hermes kanban unblock t_XXX --reason '...'      # blocked → ready
hermes kanban archive t_XXX                      # ready/done → archive
hermes kanban reclaim t_XXX                      # running → ready
```

상태 전이:

```text
ready → running (dispatcher picks up)
running → blocked (worker blocks with reason)
running → done (worker calls complete)
blocked → ready (operator calls unblock)
done → (terminal)
```

## 4. `kanban block`은 positional, `--reason` 플래그 없음

```bash
# ❌ WRONG — --reason 플래그 사용 (어떤 버전에서는 unrecognized arguments)
hermes kanban block t_XXX --reason 'bug'

# ✅ CORRECT — positional
hermes kanban block t_XXX 'bug description text'
# 또는
hermes kanban block t_XXX 'bug' --kind dependency
# kind 옵션만 사용 가능 (--kind {capability,dependency,needs_input,transient})
```

## 5. `kanban complete` vs `kanban block`

```bash
# complete: terminal 상태, done으로 종료
hermes kanban complete t_XXX --summary '작업 완료, ...' --metadata '{"key": "value"}'

# block: blocked 상태, 사용자/다른 작업자 입력 대기
hermes kanban block t_XXX 'block reason'
```

`complete`와 `block` 모두 `--summary` 플래그 지원 (positional summary는 안 됨). `--metadata`는 JSON dict.

## 6. Python subprocess와 글로벌 argv

`hermes`는 글로벌 argv를 자동 추가할 수 있음 (`--yolo`, `--safe-mode` 등). Python에서 multi-line argument 호출 시:

```python
# ❌ 깨질 수 있음 — long body를 heredoc으로 넘길 때
subprocess.run(['hermes', 'kanban', 'create', long_body, '--json'], capture_output=True)
# 출력: "hermes: error: unrecognized arguments: ..."

# ✅ WORKAROUND — 한 줄에 string으로 합치기
body = ' '.join([long_paragraph_line_1, long_paragraph_line_2])
subprocess.run(['hermes', 'kanban', 'create', body, '--json'], capture_output=True)

# ✅ 더 안전 — terminal 도구나 hermes의 kanban tools 사용
# terminal(command='hermes kanban create <title> --body <body>')
# 또는 kanban_create, kanban_link, kanban_complete 등의 tool 직접 사용
```

Python 자동화 권장 패턴: `subprocess.run` 결과가 exit code 2면 CLI 사용법 변경 가능성. `hermes kanban <verb> --help`로 먼저 확인.

## 7. card_status별 가능한 액션

| 현재 status | 가능 액션 |
|---|---|
| `triage` | specify, decompose, promote, archive |
| `todo` | link, archive, promote (의존성 만족 시 → ready) |
| `ready` | claim (dispatcher가 자동), archive, unlink (의존성 제거) |
| `running` | reclaim (→ ready), comment, attach, complete (강제), heartbeat |
| `blocked` | unblock (→ ready), comment, complete, archive |
| `done` | edit (recovery fields만), archive, comment |
| `archived` | (terminal) |

## 8. notify-subscribe는 task 단위, board 단위 아님

```bash
# ❌ board 전체 구독 — 이렇게 안 됨
hermes kanban notify-subscribe --board snkrx-web --platform telegram ...

# ✅ task 단위
hermes kanban notify-subscribe t_XXX --platform telegram --chat-id <id> --notifier-profile default
```

`--board` 플래그는 `kanban list`, `kanban show` 등 조회용. 구독은 task_id 필수.

## 9. dispatch 출력의 spawned 배열

```bash
hermes kanban --board <board> dispatch --max 1 --json
```

성공 시:

```json
{
  "reclaimed": 0,
  "crashed": [],
  "timed_out": [],
  "stale": [],
  "auto_blocked": [],
  "promoted": 0,
  "spawned": [
    { "task_id": "t_xxx", "assignee": "default", "workspace": "/path" }
  ],
  ...
}
```

`spawned: []`이 비어있으면:

```text
- ready 상태 카드가 없음 (모두 done이거나 blocked)
- 또는 dependency 링크가 깨져 ready로 승격 안 됨
- 또는 max 옵션으로 상한 도달
```

직접 spawn한 카드 ID로 작업자가 안 보이면, `hermes kanban --board <board> list --json`으로 status 재확인.

## 10. archive 후 unlink 불필요

```bash
# 의존성 그래프에서 카드 제거 시
hermes kanban archive t_XXX   # done → archived, unlink 자동
# 명시적 unlink 불필요
```

## 11. workspace 경로 형식

```bash
hermes kanban create '...' --workspace 'dir:/Users/mac/work/snkrx-web'  # 절대 경로 필수
hermes kanban create '...' --workspace 'worktree'                       # git worktree 자동 생성
hermes kanban create '...' --workspace 'scratch'                        # 임시 디렉토리
```

`dir:<path>` 형식에서 path는 절대 경로. 상대 경로(`./foo`)는 거부됨.

## 12. 자주 보는 exit codes

```text
0: 정상
1: 일반 에러
2: 인자 파싱 실패 (CLI 사용법 변경 가능성, --help로 확인)
137: SIGKILL (운영자가 kill -9 했을 때)
143: SIGTERM (운영자가 kill -TERM 했을 때)
```

`subprocess.run(capture_output=True)`로 stdout/stderr 모두 캡처 후 `returncode` 확인 패턴.
