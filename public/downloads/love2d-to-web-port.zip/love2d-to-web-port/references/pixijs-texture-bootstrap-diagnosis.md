# PixiJS v8 부팅 정석 — Assets.load + autoStart + log 검증

> snkrx-web 2026-07-23 세션 후반, 8단계 우회 시도 끝에 확정한 **PixiJS v8 부팅 정석 코드**. 공식 `pixijs/pixijs-skills/pixijs-assets` 스킬의 [CRITICAL] 가이드 + 실측 검증 완료. 부팅이 안 될 때 이 reference 그대로 적용.

## 최소 재현 — 부팅 정석

```ts
// src/main.ts
import { Application, Assets, Sprite, Texture, Graphics } from 'pixi.js'
import './style.css'

const LOGICAL_WIDTH = 1280
const LOGICAL_HEIGHT = 720

type LoadedTextures = {
  player: Texture | null
  enemy: Texture | null
}

function log(stage: string, payload?: unknown): void {
  if (payload === undefined) console.log(`[snkrx] ${stage}`)
  else console.log(`[snkrx] ${stage}`, payload)
}

async function boot(): Promise<void> {
  log('BOOT start')
  const root = document.querySelector<HTMLElement>('#game-root')
  const status = document.querySelector<HTMLElement>('#boot-status')
  if (!root || !status) throw new Error('root/status not found')
  log('BOOT dom', { root: !!root, status: !!status })

  const app = new Application()
  log('BOOT Application created')

  // ★ PixiJS v8 권장 옵션 — autoStart + sharedTicker: false
  await app.init({
    width: LOGICAL_WIDTH,
    height: LOGICAL_HEIGHT,
    backgroundColor: 0x1c1c22,
    antialias: false,
    autoDensity: true,
    resolution: window.devicePixelRatio || 1,
    autoStart: true,
    sharedTicker: false,
  })
  // ★ 명시적 ticker 시작 (autoStart만으로는 일부 환경에서 부족)
  app.ticker.start()
  log('BOOT app.init done', {
    canvasW: app.canvas.width,
    canvasH: app.canvas.height,
    rendererName: app.renderer.name,
    tickerStarted: app.ticker.started,
  })

  app.canvas.id = 'game-canvas'
  app.canvas.style.display = 'block'
  app.canvas.setAttribute('aria-label', '1280 × 720 PixiJS 게임 캔버스')
  root.appendChild(app.canvas)
  status.remove()

  // ★ PixiJS v8 정석 — Assets.load
  const bust = `?bust=${Date.now()}`
  const [playerTexture, enemyTexture] = await Promise.all([
    Assets.load<Texture>(`/assets/images/warrior.png${bust}`),
    Assets.load<Texture>(`/assets/images/speed_booster_elite.png${bust}`),
  ])

  log('BOOT playerTexture', { width: playerTexture?.width, height: playerTexture?.height })
  log('BOOT enemyTexture', { width: enemyTexture?.width, height: enemyTexture?.height })

  addBattleDemo(app, { player: playerTexture ?? null, enemy: enemyTexture ?? null })

  // 첫 프레임 강제 렌더 (안전장치 — ticker 첫 콜 전)
  app.renderer.render(app.stage)

  Object.assign(window, { snkrxApp: app })
  log('BOOT end')
}

function addBattleDemo(app: Application, textures: LoadedTextures): void {
  // Sprite가 있으면 사용, 없으면 Graphics placeholder
  const drawPlayer = textures.player
    ? new Sprite(textures.player)
    : new Graphics()
  if (drawPlayer instanceof Graphics) {
    drawPlayer.rect(0, 0, 24, 36).fill(0xe53935)
  } else {
    drawPlayer.width = 24
    drawPlayer.height = 36
  }
  drawPlayer.x = LOGICAL_WIDTH / 2 - 12
  drawPlayer.y = LOGICAL_HEIGHT / 2 - 18
  drawPlayer.label = 'player'
  app.stage.addChild(drawPlayer)

  const drawEnemy = textures.enemy
    ? new Sprite(textures.enemy)
    : new Graphics()
  if (drawEnemy instanceof Graphics) {
    drawEnemy.rect(0, 0, 24, 36).fill(0x1e88e5)
  } else {
    drawEnemy.width = 24
    drawEnemy.height = 36
  }
  drawEnemy.x = LOGICAL_WIDTH - 24 - 16
  drawEnemy.y = 16
  drawEnemy.label = 'enemy-speed-booster-elite'
  app.stage.addChild(drawEnemy)

  const healthBar = new Graphics()
  healthBar.rect(0, 0, 32, 3).fill(0x66666e)
  healthBar.rect(0, 0, 24, 3).fill(0xe53935)
  healthBar.x = LOGICAL_WIDTH - 24 - 16 + (24 - 32) / 2
  healthBar.y = 16 - 6
  healthBar.label = 'enemy-health-bar'
  app.stage.addChild(healthBar)
}

void boot().catch((error: unknown) => {
  const message = error instanceof Error ? error.message : String(error)
  const status = document.querySelector<HTMLElement>('#boot-status')
  if (status) {
    status.textContent = `초기화 실패: ${message}`
    status.dataset.state = 'error'
  }
  console.error('[snkrx] BOOT failed', error)
})
```

## 부팅 후 검증 (사용자에게 받을 로그)

```text
[snkrx] BOOT start
[snkrx] BOOT dom {root: true, status: true}
[snkrx] BOOT Application created
[snkrx] BOOT app.init done {canvasW: 1280, canvasH: 720, rendererName: 'webgl', tickerStarted: true}
[snkrx] BOOT playerTexture {width: 40, height: 60}
[snkrx] BOOT enemyTexture {width: 40, height: 60}
[snkrx] BOOT end
```

**판단 기준**:
- `rendererName: 'webgl'` → WebGL 컨텍스트 정상
- `tickerStarted: true` → ticker 동작
- `width=40 height=60` → 텍스처 데이터 정상 (40x60 PNG)
- 모든 sprite가 화면에 표시되어야 함

## 이 패턴이 실패할 때 의심할 것

1. **이미지가 화면에 안 보임** → 이전 작업자 patch가 디스크에 남았는지 확인 (`git status --short`)
2. **빌드는 통과하는데 화면이 비어있음** → `tickerStarted: false`로 보이면 `app.ticker.start()` 명시 호출
3. **흰 십자선 / placeholder만 보임** → 팔레트 PNG 함정 (color_type=3). PIL로 RGBA 변환 필요
4. **error: Could not find a source type** → `Texture.from(imageData)` 사용. `Assets.load(url)` 또는 `Image → Texture.from(image)`로 변경

## 절대 하지 말 것

```ts
// ❌ WRONG — 한 텍스처 실패가 부팅 전체 throw
const [a, b] = await Promise.all([Assets.load(...), Assets.load(...)])

// ❌ WRONG — Texture.from()은 캐시만 읽음 (PixiJS v8)
const tex = Texture.from('/path/to/image.png')

// ❌ WRONG — cache-bust 쿼리는 PixiJS URL prefix 매칭으로 우회 실패
const tex = await Assets.load('/path/to/image.png?t=Date.now()')  // 같은 prefix로 인식

// ❌ WRONG — Image GC 시 텍스처 사라짐
const tex = Texture.from(img)  // 명시적 HELD_TEXTURES 보관 없으면 위험
```

## 반드시 할 것

```ts
// ✅ CORRECT — PixiJS v8 정석
const tex = await Assets.load<Texture>('/path/to/image.png')

// ✅ CORRECT — 부팅이 죽지 않도록 loadOptional wrapper
async function loadOptional(url: string): Promise<Texture | null> {
  try { return await Assets.load<Texture>(url) }
  catch (e) { console.warn(`[snkrx] 텍스처 로드 실패 (${url}):`, e); return null }
}

// ✅ CORRECT — 명시적 ticker 시작
app.ticker.start()

// ✅ CORRECT — 부팅이 안 되면 fix 전에 모든 단계에 log
log('BOOT app.init done', { canvasW, canvasH, rendererName, tickerStarted })
log('BOOT playerTexture', { width, height })
```

## 부팅 함정 우선순위 (2026-07-23 확정)

| 증상 | 트랩 | 1차 시도 | 2차 시도 |
|---|---|---|---|
| "PixiJS 초기화 중..." 텍스트만 | Promise.all throw | loadOptional 분리 | 각 텍스처 try/catch |
| 빨간 정사각형 자리에 흰 십자선 | 팔레트 PNG | PIL로 RGBA 변환 | curl로 변환 검증 |
| `Error: Could not find a source type` | Texture.from(imageData) | Assets.load로 변경 | Image → Texture.from |
| 텍스처 만들었는데 화면에 안 보임 | Ticker 안 돔 | `app.ticker.start()` 명시 | `sharedTicker: false` 옵션 |
| 빨간 정사각형은 보이지만 적 안 보임 | Assets 캐시된 실패 | URL에 다른 query | `Assets.unload`로 캐시 비우기 |
