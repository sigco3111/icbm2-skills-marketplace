# Worker Playwright Trap + Operator Rescue Menu (★ 2026-07-23 SNKRX session)

## The Playwright trap (★ occurred 4-5 times in one session)

Workers stuck in `chrome-automation` skill calling `playwright install`, then `chromium.launch`, then `page.goto` — **on macOS these routinely fail** with:

- `page/context/browser has been closed`
- `Target page, context or browser has been closed`
- `unhandled errors in a TaskGroup (1 sub-exception)`
- `MallocStackLogging: can't turn off malloc stack logging because it was not enabled` (Python output side effects)

The worker then spirals into `session_search` trying alternatives, calling `grep`, `read_file` for 20-60 minutes. CPU drops to 0-2% but `status: running` so the dispatcher doesn't reclaim. The system looks fine from the outside; only `tail -f logs/<task_id>.log` shows the actual stuck state.

**Diagnose quickly** (★ 5-min rule):

```bash
# 1. Check the worker log
tail -f /Users/mac/.hermes/kanban/boards/<board>/logs/<task_id>.log
#   Signal: `chrome-automation` skill load, then long pause, no commit

# 2. Check worker process
ps -p <worker_pid> -o pid,etime,%cpu,stat
#   Signal: %cpu < 5% after 10+ minutes → stuck

# 3. If confirmed stuck, kill and reclaim
kill -TERM <pid>
sleep 2
kill -KILL <pid>
hermes kanban reclaim <task_id> --reason "playwright stall on macOS"
```

**Prevention (★ preferred over rescue)**: in the card body, add explicit text:

```
이 카드는 Playwright/chrome-automation 시각 검증 시도 금지. 자동 검증은 tsc/build/test만.
시각 검증은 사용자가 브라우저 강력 새로고침으로 직접 확인.
```

The user has explicitly confirmed this preference: "플레이라이트로 테스트해야할 것은 가능한 나에게 확인해달라고해" — visual verification is the user's job, not the worker's.

## Operator rescue menu (3-tier, by speed)

When a worker is stuck or making no progress, choose by speed:

### Tier 1: Operator direct fix (★ fastest for single-file issues)

When stuck for 5+ minutes on a simple task, kill the worker and fix directly. The worker may be on the right track but bogged down in TscConfig warnings, ESLint noise, Playwright retries, etc.

```bash
# 1. Stop the worker
kill -TERM <worker_pid>

# 2. Read the file the worker was editing
read_file /path/to/file.ts

# 3. Apply the fix directly with patch
patch <path> <old> <new>

# 4. Verify
npx tsc --noEmit
npm run build
# curl smoke test if applicable

# 5. Commit + push
git add -A
git commit -m "..."
git push origin main

# 6. Complete the card
hermes kanban complete <task_id> --summary "operator direct fix: <what>"
```

**2026-07-23 SNKRX case**: Phase 5-2 worker stuck 18+ minutes on TscConfig warnings. Operator killed, directly modified `src/main.ts` to import `CharacterLv3Effect` and integrated Lv.3 + Lv.20 trailer. **5 minutes vs 18+ minutes** — saved an hour by going direct.

### Tier 2: Reclaim + decompose into smaller cards

When the work is genuinely too big for one card (or worker is doing it wrong):

```bash
hermes kanban reclaim <task_id> --reason "task too large"
# 1. archive the failed card
hermes kanban archive <task_id>
# 2. create 4-5 smaller cards with explicit done conditions
# 3. link them in dependency order (parent → child)
```

**Decomposition rule (from 2026-07-23)**: A "static battle scene" card that was 47+ minutes stuck → decomposed into 5 cards (data/coordinates → screen skeleton → snake+heroes → enemies+HP bar → UI+diff memo). Each took 5-10 minutes.

### Tier 3: Reassign (rare)

Only when another profile exists and is better suited:

```bash
hermes kanban reassign <task_id> <other-profile> --reclaim
```

## Worker self-revert antipattern (★ 2026-07-23 specific)

Workers sometimes do `git add` → `git commit A feat:` → `git commit B revert: A` within the SAME card, ending with `kanban_complete done`. From the card's perspective it's "done" but the user sees no change.

**Detection**:

```bash
git log --since="1 hour ago" --oneline
# Signal: same author, same area, add → remove in 30 min
```

**Prevention** in card body:

```
중요: 이 카드는 revert 금지. 사용자가 OK 할 때까지 적용 유지.
```

**Better prevention**: split into two cards. Card 1: "테스트 모드 적용" (원본 보존), Card 2: "테스트 모드 해제 + 원본 복구" (사용자 OK 후). This way the worker can't revert in the same card.

## Worker auto-decomposition (specify/decompose) conflict

When a worker receives a large card, it may run `kanban_specify` or `kanban_decompose` to auto-split into 5-7 smaller cards. This creates problems:

1. The original card goes back to `todo` (not `done`)
2. 5-7 new cards are added, often with bodies that contradict the original spec
3. The new cards auto-dispatch before operator can review

**Example (2026-07-23)**: worker decomposed "snake 본체 추적" into 5 cards with body like "leader 1 + history 30 정사각형 + ←/→ 회전 + dt 이동" — but the user's intent was chain-follower (cumulative distance), not simple history snapshots. Operator had to:

```bash
# 1. Stop the worker that's auto-dispatching
kill -TERM <worker_pid>
# 2. Archive the 5 decomposed cards in batch
for tid in t_a t_b t_c t_d t_e; do
  hermes kanban archive $tid
done
# 3. Manually create the correct card
# 4. Dispatch
```

**Prevention** in card body: explicitly state the algorithm choice (chain-follower vs simple history vs accumulator) so the worker doesn't second-guess.

## Patch-loop signal

In the worker log, look for the pattern:

```
┊ 🔧 preparing patch…
┊ 🔧 preparing patch…
┊ 🔧 preparing patch…
┊ 🔧 preparing patch…
┊ 🔧 preparing patch…
```

5+ consecutive `preparing patch…` without a successful `npm run build` or `git commit` indicates a patch loop. **5 minutes of this is the trigger to go to Tier 1 (operator direct fix)**.

## User's explicit preference: Playwright is operator/user's job

The user (2026-07-23) said explicitly: "플레이라이트로 테스트해야할 것은 가능한 나에게 확인해달라고해". Translation: "ask me to verify things that need Playwright". This means:

- Workers should **not** call `chrome-automation` skill for visual verification
- For visual cards, the card should end with `kanban_block(reason="review-required: ...")` and wait for the user
- The user will **manually** open the URL and verify

Combined with the patch-loop rescue menu above, this means: when a worker starts Playwright on a visual card, **the answer is to rescue** (Tier 1 if the work is done, Tier 2 if not).

## Vite dev server pattern (replaces `| tee &` trap)

Workers will sometimes try to spawn a dev server with `npm run dev | tee /tmp/x.log &` which **deadlocks the Hermes terminal tool** waiting for the background process. The correct invocation:

```bash
# In operator's terminal session
hermes terminal command="npm run dev -- --host 127.0.0.1" run_in_background=true
# Or via Python:
subprocess.Popen(['npm', 'run', 'dev', '--', '--host', '127.0.0.1'],
                 stdout=subprocess.PIPE, stderr=subprocess.PIPE)
```

Workers should be told: **never use `| tee ... &` for dev servers**. Use `run_in_background: true` or `subprocess.Popen` with stdout/stderr capture.

## Monitor cadence (★ prevent late detection)

Don't check workers every 5 minutes. Set up a monitor:

```bash
# In a separate terminal, every 2-3 minutes
watch -n 180 'ps aux | grep -E "hermes.*t_" | grep -v grep | head -5; echo ---; tail -3 /Users/mac/.hermes/kanban/boards/*/logs/t_*.log 2>/dev/null'
```

If a worker has been running > 15 minutes without a commit and CPU < 5%, trigger Tier 1 rescue.
