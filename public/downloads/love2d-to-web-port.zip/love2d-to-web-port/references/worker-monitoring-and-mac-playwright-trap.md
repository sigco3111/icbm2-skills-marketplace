# Worker Monitoring & macOS Playwright Trap (★ 2026-07-23 Hermes Kanban 실측)

> LÖVE → Web 포팅 카드를 작업자에게 위임할 때, **작업자가 20~60분 동안 "잘 작동 중"이라고 보고하지만 실제로는 Playwright 자동 검증에 갇혀 끝나지 못하는** 패턴이 반복됨. 이 reference는 그 함정과 운영자 rescue 패턴을 정리.

## 핵심 신호 (Symptoms)

다음이 보이면 **거의 확실히** Playwright trap:

```text
작업자 CPU: 0.0% (또는 매우 낮음)
작업자 uptime: 20~60분+
마지막 액션: chrome-automation skill 또는 playwright spawn
console.log 또는 git commit 같은 정상 액션이 5분+ 없음
hermes kanban show <id>의 runs가 단 1개 (review-required로 끝나지 못함)
```

macOS + LÖVE → Web 포팅 작업자(특히 PixiJS) 환경에서 **이 패턴이 최소 2~3번** 반복됨.

## 왜 갇히나 (Why)

LÖVE → Web 포팅 작업자 (= Hermes의 default 프로필이 Kanban 카드에 spawn된 워커)는 보통 시각 검증을 위해 Chrome headless + Playwright를 사용. macOS 환경에서 Playwright Chromium은:

```text
- "page has been closed" 에러로 페이지 컨텍스트가 비정상 종료
- viewport 설정에 따라 60초 timeout 발생
- /tmp 스크린샷 캡처는 성공하지만 pageerror/pageclose 이벤트로 Promise reject
- 재시도해도 같은 에러 반복 (3~5회)
- 작업자는 "verify once more" 또는 "regenerate screenshot" 루프에 갇힘
- 보드 카드는 running 상태이지만 worker process는 stuck
```

작업자 로그에서 이런 패턴이 보임:

```text
┊ ⚙️ preparing process…
┊ ⚙️  proc      poll proc_xxxxx  0.0s
┊ ⚙️ preparing process…
┊ ⚙️ preparing process…
┊ 🔧 preparing patch…
┊ 🔧 preparing patch…
┊ 🔧 preparing patch…  ← 16~30회 반복
┊ 💻 $ node -e "const {chromium}=require(...) ... await chromium.launch({headless:true}) ..."  60.5s [exit 124]
```

`exit 124`는 60초 timeout, `preparing patch…`는 진전 없는 patch 시도의 신호.

## 사용자 명시 선호 (★ 2026-07-23 SNKRX 세션)

> "어려운 작업이 아닐꺼데, 너무 오래걸리는 것 같아. 이상없는지 체크해줘. **플레이라이트로 테스트해야할 것은 가능한 나에게 확인해달라고해.**"

해석:

```text
1. 단순 작업(단일 파일 수정, 1~2 line fix)이 20분+ 걸리면 작업자가 갇힌 신호
2. Playwright로 시각 검증이 필요하면 작업자에게 맡기지 말고 사용자가 직접 확인
3. 사용자가 macOS 환경에 있고 브라우저 강력 새로고침으로 직접 시각 확인 가능
4. 운영자는 작업자 uptime과 마지막 액션을 모니터링하다가 stuck이면 즉시 intervene
```

## 운영자 rescue 패턴 (Operator Rescue)

### 1단계: 5분+ 지연이면 상태 확인

```bash
# 작업자 프로세스 확인
ps aux | grep -E 'hermes.*t_XXX' | grep -v grep | head -1
# → uptime, %CPU 확인

# 카드 상태 확인
hermes kanban show t_XXX --json | python3 -c '
import json, sys
d = json.load(sys.stdin)
t = d["task"]; r = d["runs"][-1] if d["runs"] else {}
print("status:", t["status"])
print("started_at:", t["started_at"])
print("worker_pid:", r.get("worker_pid"))
print("latest:", (d.get("latest_summary") or "")[:200])
print("runs:", len(d["runs"]))
print("events tail:", d["events"][-3:])
'
```

판단 기준:

```text
uptime < 5분  → 대기
uptime 5~15분 + %CPU > 5% → 정상 작업 중
uptime 15분+ + %CPU = 0% + Playwright 흔적 → stuck
uptime 30분+ + 단일 run + heartbeat 없음 → 반드시 intervene
```

### 2단계: stuck 확인되면 옵션 선택

```text
옵션 A (단일 파일 fix에 가장 빠름):
  → 운영자가 직접 코드 수정 + commit + push
  → 카드는 done 또는 archive
  → 다음 카드 dispatch
  
옵션 B (Reclaim + 분할):
  → hermes kanban reclaim <id> --reason 'stuck on Playwright'
  → 더 작은 단위로 카드 재생성 (예: 5장 → 2장 + 2장)
  
옵션 C (작업자에게 노트 추가):
  → kanban_comment(task_id, "Chrome headless is failing on macOS. Skip visual verification. Commit + dev server 200 OK is enough. Push to main, then block for user verification.")
  → 작업자가 다음 turn에 노트를 보고 검증 시도 중단
```

### 3단계: 카드 강제 완료 (사용자 검증 후)

```bash
# git log로 commit 확인
git log -1 --oneline

# 사용자가 브라우저로 확인 후 OK 신호 받으면
hermes kanban --board <board> complete t_XXX --summary '사용자 확인 완료, ...' --metadata '{...}'
```

## 작업자 카드 body에 미리 적어둘 권장 패턴

```text
[자동 검증 카드 - 사용자 확인 필요]
1. 단일 파일 또는 2-3 line fix
2. node:test 또는 npm run build 통과
3. git commit + main push
4. ★★★ Chrome headless 또는 Playwright 시각 검증 시도 금지
5. 자동 검증 완료 시 kanban_block(review-required: ...)
6. 사용자가 브라우저 강력 새로고침으로 직접 확인

[시각 검증 카드 - 사용자 알림]
1. 작업자 검증 금지
2. dev server 띄우고 사용자 알림 (Telegram 등) 발송
3. 사용자 확인 대기 → kanban_block(review-required: 시각 확인 필요)
```

## 작업자 alive 모니터링 (Operator check pattern)

주기적으로 (1~2분마다) 확인할 때:

```bash
# 정상 작업 중
ps aux | grep -E 'hermes.*t_XXX' | grep -v grep | awk '{print $2, $4, $10}'  # PID, %CPU, ELAPSED
# 출력 예: 12345 12.5 02:34  → 12.5% CPU 2분34초 사용 = 정상

# stuck
# 출력: 12345 0.0 30:00  → 0% CPU 30분 = stuck
```

heartbeat 이벤트도 신호:

```bash
hermes kanban show t_XXX --json | python3 -c '
import json, sys
d = json.load(sys.stdin)
last_hb = max((e["created_at"] for e in d["events"] if e["kind"] == "heartbeat"), default=0)
import time
if last_hb and (time.time() - last_hb) > 60:
    print("heartbeat stale:", int(time.time() - last_hb), "sec")
'
```

## 다른 LÖVE → Web 포팅 세션 적용

```text
- 작업자가 git log --oneline을 안 찍고 patch 루프 → reclaim
- 작업자가 npm run build 결과를 안 보고 진행 → 카드 body에 명시
- 작업자가 dev server 안 띄움 → Telegram 알림으로 사용자가 확인 가능
- Playwright가 안 되면 → 사용자가 직접 브라우저로 확인
```

## 핵심: Playwright에 갇히면 빨리 죽이기

```text
- 30분+ stuck + Playwright 흔적 → 즉시 kill -TERM <pid>
- 운영자가 직접 검증 (npm run build, dev server 200, git log)
- 카드 done 또는 새 카드로 분할
- 작업자가 stuck 동안 5분마다 체크하지 말 것 (불필요한 모니터링 비용)
- 첫 신호에서 즉시 옵션 A (직접 수정) 또는 B (reclaim) 선택
```
