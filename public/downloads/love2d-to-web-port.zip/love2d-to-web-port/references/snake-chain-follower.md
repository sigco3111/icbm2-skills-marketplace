# 뱀 본체 추적: 단순 History vs Chain-Follower

LÖVE → 웹 포팅에서 뱀 게임의 본체 추적 두 가지 모델.

## 모델 1: 단순 History 스냅샷 (실패 패턴)

```ts
update(dt) {
  this.history.pop()                          // 가장 오래된 위치 제거
  this.history.unshift({ x: this.head.x, y: this.head.y })  // 직전 head 위치 push
  this.head = newHead                          // head 진행
}

getVisualPosition(i) {
  return this.history[i]  // 본체 i는 head의 N frame 전 위치
}
```

**문제**: 회전 시 본체가 직선으로 늘어짐. head가 회전 궤적을 그려도 history는 frame 단위 스냅샷이라 그 사이의 곡선 정보가 없음.

```
frame 1: head 우측 → (10, 0) history[0]
frame 2: head 우측 → (20, 0) history[0]
frame 3: head 위로 회전 → (30, -5) history[0]
frame 4: head 위로 → (30, -15) history[0]

본체 0 = history[0] = (30, -15) → 마지막 위치만 따라옴
본체 1 = history[1] = (30, -5) → 회전 전 직선 위치
본체 2 = history[2] = (20, 0) → 회전 전 직선 위치
```

즉 **회전 후의 history는 모두 직선상에 머무름**. 화면에 보이면 **회전 안 한 것처럼 직선**.

## 모델 2: Chain-Follower (누적 거리) — 정답

원본 LÖVE의 snake는 **누적 거리 기반**으로 각 마디가 head로부터 정확히 i*spacing 떨어진 거리를 유지.

```ts
update(dt) {
  // 1. head 진행
  this.head = { x: this.head.x + dx, y: this.head.y + dy }

  // 2. 각 segment를 직전 segment/head로부터 정확히 spacing 거리로 보정
  let prevX = this.head.x, prevY = this.head.y
  for (let i = 0; i < this.segments.length; i++) {
    const cur = this.segments[i]
    const ddx = cur.x - prevX
    const ddy = cur.y - prevY
    const dist = Math.hypot(ddx, ddy) || 1
    const scale = this.spacing / dist
    const newX = prevX + ddx * scale
    const newY = prevY + ddy * scale
    this.segments[i] = { x: newX, y: newY }
    prevX = newX
    prevY = newY
  }
}
```

**동작**:
- 각 segment는 직전 segment/head 방향으로 **정확히 spacing 거리** 떨어진 위치에 강제 배치
- head가 회전하면 segment[0]이 head의 회전 궤적을 따라가고, segment[1]이 segment[0]을 따라가는 chain-follower
- 30개 segment 모두 자연스러운 곡선 추적

**spacing 선택** (★ 2026-07-23 실측):
- SNAKE_TILE(16)과 같으면 마디가 겹침
- 24-32px 정도가 시각적으로 명확하게 구분
- SNKRX는 28px이 적절

## 사용자 진단 (2026-07-23 실측)

> "뱀이 좌우로 이동됨. 하지만 30개의 정사각형이라기 보다 그라데이션 같은데...의도한 것이 맞나?"

→ 단순 history 모델 적용. spacing=0이거나 chain-follower가 아닌 경우. **사용자 눈에 그라데이션처럼 보이는 건 spacing이 너무 작아서 30개 사각형이 거의 같은 위치에 그려지기 때문**.

> "이제 spacing이 유지됨. 그런데, 회전시 꼬리들이 부드럽게 따라오지 않고, 직선으로 따라옴."

→ chain-follower 미적용. spacing 보정 후에도 단순 history 모델이므로 회전 시 직선.

> "ok 곡선으로 움직임"

→ chain-follower 적용 완료. 회전 시 30개 본체가 머리 궤적을 따라 곡선으로 추적.

## 결정 가이드

| 게임 | 모델 | 이유 |
|---|---|---|
| 짧은 직선만 가는 뱀 (8방향 회전 없음) | 단순 history + spacing | 충분 |
| 회전 + 곡선 추적 (LÖVE, agar.io 류) | **chain-follower** | 필수 |
| 물리 시뮬레이션 (뱀이 천천히 늘어나는 효과) | chain-follower + lerp | 부드러움 |
| 멀티 마디 (centipede, dragon) | chain-follower + 3D | 거리 보존 필수 |

## PixiJS 구현 시 주의

- **spacing=0** 이면 모든 segment가 같은 위치 (실수하기 쉬움)
- **segments[0] = head 직후** (spacing 1배), segments[1] = spacing 2배, ..., segments[N-1] = spacing N배
- 초기화: 생성 시 `head - (i+1)*spacing` 방향으로 미리 떨어뜨려서 첫 프레임에 마디가 흩어져 보이지 않게
- **chain-follower는 LÖVE의 누적 거리 분기와 동등**이지만 단순화된 버전. 원본 LÖVE는 `target_distance` 누적 + 마디별 `current_distance` 보정 더 복잡한 알고리즘. **PixiJS에서는 단순 chain-follower로 충분**.

## LÖVE 원본 player.lua 패턴

원본 snkrx-clone/player.lua는 `units` 배열의 각 unit이:
1. `target_distance = (i+1) * spacing` 유지
2. 매 frame `current_distance` 갱신
3. `current_distance < target_distance`면 head 방향으로 이동
4. 회전 시 자연스러운 곡선 (target_distance 보존)

PixiJS에서 이걸 **chain-follower**로 단순화 가능.
