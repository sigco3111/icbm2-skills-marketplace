# SNKRX 2026-07-23 — Operator Rescue Patterns

Operator reflexes for unblocking kanban workers. The main SKILL.md has pitfalls; this file has the **how** (operator actions).

## Three-tier rescue menu (★ speed-sorted)

### Tier 1: Operator direct fix (5 min) — fastest for single-file bugs

When the worker is stuck on a clearly scoped single-file change, kill the worker and fix it yourself.

```bash
# 1. Identify stuck worker
ps aux | grep -E 'hermes.*t_<task_id>' | grep -v grep | head -1

# 2. Stop the worker
kill -TERM <pid>
sleep 2
ps -p <pid> 2>/dev/null && kill -KILL <pid>

# 3. Read the code
read_file <path> --offset <relevant_line_range>

# 4. Apply the fix
patch (mode='replace', path=..., old_string=..., new_string=...)

# 5. Verify locally
npx tsc --noEmit && npm run build

# 6. Commit + push
git add -A && git commit -m '...'
git push origin main

# 7. Mark card done
hermes kanban complete <task_id> --summary '...'
```

**When to use**: single file, clear fix, < 30 lines of change.

**Real examples from 2026-07-23 session**:
- Phase 4-3 waveManager TDZ ReferenceError — operator killed worker, moved `let waveManager` to top of `setupBattleSystem`, fixed in 5 min.
- Phase 4-5b collision precision — operator killed worker, changed `snakeHeadRadius` 8 → 12, committed in 3 min.
- Phase 5-2 HitFX integration — operator killed worker (18 min stuck on tsconfig warning analysis), added `hfx.update()` and `hfx.use('hit')` to main.ts, fixed in 5 min.
- Phase 5-3 test mode bug — operator identified `import.meta.env.DEV → 'production-dev'` root cause and fixed.

### Tier 2: Reclaim + split (10-15 min) — for unclear-stuck workers

```bash
# 1. Kill stuck worker (same as Tier 1)

# 2. Reclaim — only works on running state
hermes kanban reclaim <task_id> --reason 'worker stuck: <description>'

# 3. If reclaim says "not running or unknown id", use archive instead
hermes kanban archive <task_id>

# 4. Create smaller cards (priority ascending)
python3 - <<'PY'
import subprocess
for title, body, prio in [
    ('Sub-task 1', '...', 95),
    ('Sub-task 2', '...', 94),
]:
    p = subprocess.run(['hermes','kanban','create',title,
        '--body', body,
        '--assignee','default',
        '--workspace','dir:/Users/mac/work/snkrx-web',
        '--priority',str(prio),'--json'],
        capture_output=True, text=True)
    print(p.stdout, p.stderr)
PY

# 5. Link children to parent
hermes kanban link <parent> <child>
```

**When to use**: worker stuck on multi-file refactor, unclear root cause, or spec decomposition needed.

**Real example from 2026-07-23**:
- Phase 5 (Camera + shake) — worker stuck on Playwright for 31 min, operator killed + reclaimed + created v2 with explicit "Playwright 금지" in body.

### Tier 3: Wait and monitor (5-30 min) — for slow but progressing workers

```bash
# 1. Check if alive and progressing
ps aux | grep -E 'hermes.*t_<id>' | grep -v grep | awk '{print $2, $10, $11, $12, $13}'
# (PID, %CPU, elapsed, command)

# 2. Check what they last did
tail -10 /Users/mac/.hermes/kanban/boards/<board>/logs/<task_id>.log

# 3. If %CPU = 0% and log shows no recent activity, they're stuck → Tier 1 or 2
# 4. If %CPU > 0% and last log is recent, wait another 5 min
```

**5-min stuck rule**: User's explicit preference ("어려운 작업이 아닐꺼데, 너무 오래걸리는 것 같아. 이상없는지 체크해줘"). Default threshold: 5 minutes stuck = direct operator intervention.

**Stuck detection signals**:
- `%CPU` < 2% with status `running`
- Last heartbeat > 5 min ago
- Log shows `preparing patch…` repeating 16+ times with no commit
- Log shows Playwright/Chrome-automation loading but no progress
- Log shows `npx tsc --noEmit` looping (warning analysis)

## Card body anti-stuck patterns

**What to put in card body to prevent worker stalling** (★ 2026-07-23 SNKRX patterns):

1. **Playwright/Chrome-automation 금지 명시**:
   ```
   (중요: Playwright/chrome 자동 검증 사용 금지. 자동 검증에 갇혀서 30분+ 낭비함.
   자동 검증 단계를 건너뛰고 바로 commit + main push + 카드 완료. 
   시각 검증은 사용자가 직접 한다.)
   ```

2. **변경 허용 파일 명시**:
   ```
   변경 허용 파일: src/camera.ts, src/main.ts
   변경 금지: src/snake.ts (사용자가 직접 처리 중)
   ```

3. **변경 금지 명시** (테스트 모드 self-revert 방지):
   ```
   (이 카드는 revert 금지. 사용자가 OK 할 때까지 유지.)
   ```

4. **테스트 모드는 별도 카드로 분리**:
   ```
   카드 1: "테스트 모드 적용" (원본 보존)
   카드 2: "테스트 모드 해제 + 원본 복구" (사용자 OK 후, 별도 카드)
   ```
   → 작업자가 같은 카드 내에서 `commit A` + `commit B revert` 안티패턴 방지

5. **build/test/시각 검증 분리**:
   ```
   1. 코드 구현
   2. node:test 통과
   3. tsc --noEmit
   4. npm run build
   5. git add -A && git commit -m '...'
   6. git push origin main
   (시각 검증은 사용자가 한다)
   ```

## Vite dev mode test mode bug (★ 2026-07-23 발견, fix 커밋 16f41a3)

**Symptom**: After applying test mode with `?test=1` URL query, projectile 발사 became disabled in BOTH test mode AND normal mode. Users reported "일반모드: 투사체가 발사되지 않음".

**Root cause**: `isTestMode` function used `nodeEnv === 'development'` check, and **Vite dev server sets `process.env.NODE_ENV=development` automatically**. So test mode was auto-enabled in dev server, making `cooldown=Infinity` (projectile OFF) the default.

**Fix**: Use a sentinel string that Vite dev server cannot accidentally produce:

```typescript
// main.ts
const RUNTIME_NODE_ENV = import.meta.env.NODE_ENV
  ?? (import.meta.env.DEV ? 'production-dev' : import.meta.env.MODE)
const TEST_MODE = isTestMode(window.location.search, RUNTIME_NODE_ENV)
```

`production-dev` is a string that:
- Vite's `import.meta.env.DEV === true` produces
- `isTestMode` doesn't match `nodeEnv === 'development'`
- So dev server: only `?test=1` query enables test mode
- Production build (`import.meta.env.DEV === false`): `nodeEnv === 'development'` from build script does enable test mode

**Detection**: If `?test=1` 없이 들어가도 투사체가 안 발사되고, 콘솔에 `[snkrx] BOOT test mode enabled: true`가 보이면 이 버그 가능성. git log에서 `RUNTIME_NODE_ENV` 키워드로 검색.

## Spec conflict between worker's auto-decomposition and user's manual implementation

When operator directly edits a file (e.g. `src/snake.ts`) and worker simultaneously tries to add features to that file, worker's `kanban_specify` / `kanban_decompose` will auto-create child cards that depend on outdated assumptions.

**Example from 2026-07-23**:
- Operator implemented chain-follower snake (`src/snake.ts` with `segments[]` array).
- Worker received "Phase 2: snake body" card and auto-decomposed into 5 sub-tasks with body assuming "history[0]=head, history[1]=head prev" (snapshot model).
- Operator's chain-follower uses `segments[0]` directly. Conflict.

**Resolution**:
```bash
# 1. Kill the worker (if running)
kill -TERM <pid>

# 2. Archive the auto-decomposed children
for tid in t_<child1> t_<child2> t_<child3>; do
  hermes kanban archive $tid
done

# 3. Keep only the original parent + manual fix cards
# 4. Create a new "X manual integration" card that documents the conflict
hermes kanban create 'Phase 2-fix: chain-follower <-> worker spec conflict' --body '...'
```

## Operator verification checklist (★ 2026-07-23, run after every auto card)

```bash
# 1. Check commit
git log -1 --stat

# 2. Check diff matches worker's report
git show HEAD

# 3. Run build locally
npx tsc --noEmit && npm run build

# 4. Run tests
npm test -- --runInBand 2>/dev/null || node --test src/*.test.mjs

# 5. Check untracked files
git status --short

# 6. Manual commit if worker left uncommitted
git add -A && git commit -m 'operator cleanup' 2>/dev/null
```

If all green: `hermes kanban complete <task_id> --summary "..."`. If red: Tier 1 (operator direct fix) usually.

## Git branch / state recovery

When worker dies with untracked changes on disk:
```bash
# 1. Check what's there
git status --short
ls -la public/assets/images/ 2>/dev/null | head

# 2. If worker did partial implementation
git add -A
git commit -m 'partial: worker stopped mid-implementation; operator cleanup'
# (this preserves the work without forcing a single card to own it)

# 3. Or discard
git checkout -- <files>
```

**Real example from 2026-07-23**: Worker `t_8d7d04e` left 100+ PNG files in `public/assets/images/` untracked. Operator committed them as a separate "Phase 4 assets copy" commit so the next card didn't see them as untracked.

## Phase 5 e2e (★ 2026-07-23 후반, 완료 패턴)

Phase 5 e2e cards (Camera + shake, Flashes + HitFX, SpawnMarker, etc.) all succeeded when:
1. Card body explicitly excludes Playwright
2. Worker commits with single-feature commit message
3. Operator verifies with `npx tsc --noEmit && npm run build` and rejects on TypeScript errors
4. Each Phase 5-1 → 5-2 → 5-3 → 5-4 → 5-5 → 5-6/5-7/5-8 took 5-15 min
5. **Phase 5-6 사운드 (Web Audio API) was the only card the user reserved for manual handling** (not yet executed)

## User explicit preferences summary (★ 2026-07-23)

- **"혹시 쓸만한 픽셀js 스킬이 있다면 설치후 진행해줘"** — **blind fix 시도 전에 skill hub에 관련 스킬이 있는지 확인하고 설치**. 일반화: 부팅 실패 / 자산 로드 실패 / 무언가 안 될 때 첫 행동은 `hermes skills search <keyword>` + `hermes skills install`로 공식/커뮤니티 스킬 확인. 스킬의 [CRITICAL] 섹션에 정답이 이미 있을 가능성을 항상 고려.
- **"콜솔에서 더많은 정보를 수집할 수 있도록 로그를 추가해보는게 어때?"** — **fix 시도 전에 광범위 로깅을 먼저**. 빌드 통과 + HTTP 200 + 텍스처 정상 + Sprite 정상인데 화면에 안 그려지는 상태에서, 로깅 없는 fix 시도는 시간 낭비. 먼저 console 출력을 사용자에게 받아서 진단.
- **"어려운 작업이 아닐꺼데, 너무 오래걸리는 것 같아. 이상없는지 체크해줘"** — **5분 stuck rule**. 단일 파일 fix 같은 단순 작업이 20분+ 걸리면 작업자가 갇힌 신호. 운영자는 uptime/%CPU/heartbeat를 확인하고 즉시 옵션 A (직접 수정) 또는 B (reclaim + 분할) 선택.
- **"작업의 진행은 네가 중간중간 알려주나?"** — 자동 검증 카드는 **조용히 진행**하고, 시각 검증 카드는 **사용자 알림** (Telegram).
- **"플레이라이트로 테스트해야할 것은 가능한 나에게 확인해달라고해"** — **macOS Playwright는 사용자가 직접**. 작업자가 chrome-automation skill을 호출하면 15-30분 stuck. 카드 body에 "Chrome headless/Playwright 시각 검증 시도 금지"를 명시.
- **"사운드는 내가 처리" / "나머지는 위임할께"** — **위임할 모든 카드를 미리 생성** (사용자가 직접 처리하는 카드 포함). 카드 구조 자체가 작업 명세서이고, "사용자가 한다 / 작업자가 한다"는 런타임 선택.
- **GitHub Release 행동 (2026-07-22 정책)**: 로컬 빌드 + commit/push는 자동. **GitHub Release 자산 업로드는 사용자 명시 확인 후**. `dist/` 산출물은 commit만 하고 업로드는 보류. v0.1.15~v0.1.19에서 매 수정마다 4개 asset을 재업로드한 교훈.
