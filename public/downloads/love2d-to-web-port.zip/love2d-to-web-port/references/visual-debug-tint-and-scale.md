# 시각 디버깅: tint + scale로 GPU 업로드 vs 렌더 파이프라인 분리 (★ 2026-07-23)

## 문제

부팅 코드는 정상으로 보이지만 sprite가 화면에 안 보일 때, 다음 두 가지가 섞여 있어서 진단이 어려움:

1. **GPU 업로드 실패** (텍스처는 만들어졌지만 GPU에 안 올라감)
2. **렌더 파이프라인 문제** (Sprite 위치/Z-order/anchor 등)

빌드 통과 + HTTP 200 + 텍스처 데이터 정상 + Sprite 정상으로 로그가 찍혀도 화면이 비어 있으면 어디가 문제인지 못 좁힘.

## 해결: tint + scale 진단

원본 sprite가 **원래 작은 크기**(예: 40x60 warrior.png, 24x36으로 표시)이고 **단색(흰색)**이라, GPU 업로드가 실패해도 화면이 거의 비어 보이고 성공해도 잘 안 보임. **원본 sprite만으로는 GPU 업로드 성공/실패를 시각적으로 구분할 수 없음**.

**해결**: Sprite를 임시로 크게 키우고 **눈에 띄는 tint**를 적용해서, GPU 업로드가 성공하면 **분홍색 사각형**으로 보이고 실패하면 그대로 비어 있게 만듦.

```ts
// 진단용 임시 코드
const player = new Sprite(textures.player!)
player.width = 96          // 원본 24 → 4배 확대
player.height = 144        // 원본 36 → 4배 확대
player.x = 540             // 화면 좌측 중앙에 배치
player.y = 288
player.tint = 0xff5577     // 분홍색 (눈에 띄는 핑크)
player.anchor.set(0.5)
app.stage.addChild(player)

const enemy = new Sprite(textures.enemy!)
enemy.width = 96
enemy.height = 144
enemy.x = 1080             // 화면 우측 상단
enemy.y = 32
enemy.tint = 0x55aaff      // 하늘색
app.stage.addChild(enemy)
```

## 판정 기준

| 화면 | 의미 | 다음 행동 |
|---|---|---|
| **분홍/하늘색 사각형이 보임** | GPU 업로드 정상 | anchor/위치/Z-order 문제. anchor를 (0,0)으로 두고 위치 조정 |
| **분홍/하늘색 사각형도 안 보임** | GPU 업로드 실패 또는 렌더링 안 됨 | ticker 시작, context lost, canvas visibility, CSS 확인 |
| **분홍 사각형 + 보라색 가로선 = 원본 픽셀 형태** | GPU 업로드 + 텍스처 데이터 정상 | tint만 제거하고 원래 크기로 복원 |

## 실측 사례 (2026-07-23 SNKRX)

```text
1. 처음 시도: tint 안 줌, 원본 24x36 크기
   → 화면: '+' 와 '^' 같은 흰 placeholder만 보임
   → 작업자: "sprite 추가됐지만 안 보임" 보고
   → 진단: GPU 업로드 실패인지 렌더링 실패인지 불명

2. anchor(0.5) + tint(0xff0000) 시도
   → 화면: 분홍 십자선 (+) 보임
   → 진단: GPU 업로드 정상. anchor 문제였음
   → 픽스: anchor를 0,0으로 두고 width/height를 position에서 빼기

3. tint + scale(96x144) 시도
   → 화면: 분홍/하늘색 사각형 명확히 보임
   → 진단: 모든 게 정상
   → 픽스: tint 제거, 원본 24x36으로 복원
```

## 왜 tint+scale이 효과적인가

| 진단 방법 | 효과 | 한계 |
|---|---|---|
| 로그 (`sprite.texture.width`) | 텍스처 생성 여부 | **GPU 업로드 성공 후 사라지는 GC 문제**는 못 잡음 |
| tint 단독 (작은 크기) | 원본 픽셀 색상 변화 | 원본이 단색(흰색)이면 tint 효과가 약함 |
| scale 단독 (원본 픽셀) | 크기 변화만 | 원본이 픽셀이 별로 없으면(40x60 중 485개) 변화 미미 |
| **tint + scale 동시** | **분홍 사각형이 화면을 채움** | **GPU 업로드 + Sprite 정상 = 100% 시각 확인 가능** |

## 일반화된 템플릿 (어떤 게임이든)

```ts
function diagnosticBoot(app: Application): void {
  // 1. 큰 분홍 사각형 (Texture.from/Image/ImageData 우회 후)
  const diagSprite = new Sprite(GraphicsTexture)
  diagSprite.width = 200
  diagSprite.height = 200
  diagSprite.tint = 0xff5577
  diagSprite.x = 100
  diagSprite.y = 100
  diagSprite.label = 'GPU-CHECK'
  app.stage.addChild(diagSprite)

  // 2. 큰 하늘색 사각형 (다른 위치)
  const diagSprite2 = new Sprite(GraphicsTexture2)
  diagSprite2.width = 200
  diagSprite2.height = 200
  diagSprite2.tint = 0x55aaff
  diagSprite2.x = 500
  diagSprite2.y = 100
  app.stage.addChild(diagSprite2)

  // 3. 이 두 사각형이 안 보이면: GPU 업로드 또는 렌더링 문제
  //    두 사각형이 보이지만 게임 sprite가 안 보이면: 텍스처 데이터 문제
  //    모든 게 보이면: GPU 업로드 + Sprite 정상
}
```

## 디버깅 후 정리

확인이 끝나면 tint/스케일을 원래 값으로 되돌림:

```ts
player.tint = 0xffffff  // tint 제거
player.width = 24
player.height = 36
player.anchor.set(0)  // 또는 0.5
```

## 원본 sprite의 정체 확인 (★ 2026-07-23 발견)

디버깅하다 보면 자주 깨닫는 점: **원본 sprite가 우리가 생각한 것보다 훨씬 작거나 단순할 수 있다**.

```python
# 예: snkrx-clone warrior.png
from PIL import Image
im = Image.open('/path/to/warrior.png').convert('RGBA')
pixels = list(im.getdata())
nonzero = [p for p in pixels if p[3] > 0 and (p[0]+p[1]+p[2]) > 0]
print(f'40x60 중 nonzero 픽셀: {len(nonzero)}/{len(pixels)}')
# 출력: 485/2400  (즉 20%만 색이 있고 나머지는 투명)
```

`snkrx-clone/assets/images/warrior.png`는:
- 40x60 PNG
- 흰색 직사각형 + 가운데 가로선 모양
- 실제 캐릭터 sprite는 **여러 segment로 분할**되어 있고, 이 sprite는 그 중 **한 마디**임

**원본 LÖVE는 이 마디를 여러 개 이어 붙여서 뱀 본체를 만듦**. 우리는 한 sprite를 24x36으로 줄여 표시했는데, **픽셀이 직사각형+가로선뿐이라 sprite가 직선처럼 보임**.

따라서 tint+scale 진단 시:
- 분홍 사각형만 보임 → GPU 업로드 + Sprite 정상
- 원본 색상(흰색) 사각형은 직선 + 가로선 → 원본 디자인이 이런 것

## 결론

**GPU 업로드가 의심될 때마다 tint+scale 진단을 첫 번째로 적용**. 다른 우회나 fix 시도 전에 분홍 사각형이 보이는지부터 확인. 이게 가장 빠르고 확실한 GPU 업로드 검증 방법.
