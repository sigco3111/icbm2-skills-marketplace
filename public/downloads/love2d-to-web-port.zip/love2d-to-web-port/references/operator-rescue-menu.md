# Operator Rescue Menu (★ 2026-07-23 SNKRX 실측)

> 작업자가 5분+ stuck일 때 또는 1시간+ 진행 없을 때 운영자가 참조. 3-tier 메뉴 + 사용자 명시 선호 종합.

## 5분 stuck rule

작업자가 5분+ `running` 상태 + 0% CPU + commit 없음이면 **stuck**. 즉시 옵션 1 (직접 수정) 권장.

**진단 명령**:
```bash
# 1. 작업자 uptime 확인
ps aux | grep -E "hermes.*t_[a-f0-9]+" | grep -v grep | head -3
# → "elapsed 06:24 cpu 0.2 stat Us" → stuck

# 2. 마지막 commit 시각
cd /path/to/project && git log -1 --oneline
# → "5분 전 마지막 commit" + 그 후 patch 50회+ → patch-loop

# 3. 로그 확인
tail -50 ~/.hermes/kanban/boards/<board>/logs/<task_id>.log
# → "preparing patch..." 16-30회+ 반복, npm/tsc/build만 반복, commit 없음
```

## 3-tier operator rescue menu (★ 속도 순)

### Tier 1: 운영자가 직접 수정 (★ 가장 빠름, 5분)

**조건**: 단일 파일 fix (snake.ts, main.ts, combat.ts 등), 100줄 이내 변경

**절차**:
```bash
# 1. 작업자 중단
ps aux | grep -E "hermes.*t_<task_id>" | grep -v grep | awk '{print $2}' | xargs kill -TERM

# 2. 직접 read_file + patch + 검증 + commit
read_file /path/to/source.ts  # 현재 상태 확인
patch /path/to/source.ts old_string new_string  # 단일 fix
npx tsc --noEmit && npm run build  # 검증
git add -A && git commit -m 'fix: ...' && git push origin main

# 3. 카드 강제 완료
hermes kanban complete <task_id> --summary '...' --metadata '...'
```

**절대 안 함**: `hermes kanban complete` 호출 후에도 `git push`를 안 하면 다음 dispatch가 conflicting state에서 시작.

### Tier 2: Reclaim + 카드 분할

**조건**: 실패 모드가 불명확하거나 다중 파일 변경이 필요할 때

**절차**:
```bash
hermes kanban reclaim <task_id>  # running → ready
hermes kanban archive <task_id>  # ready → archive (작업자 commit 보존 후 정리)
# 더 작은 카드로 재생성
hermes kanban create <title> --body '...' --assignee default --workspace 'dir:/path' --json
# 의존성으로 연결
hermes kanban link <parent_id> <child_id>
```

**분할 규칙**:
- 풀 게임 1장 → 5장 (정지 화면 기준)
- 큰 카드 1장 → 3-4장 (정수 동작, 분수 동작, 보정, 시각 확인)
- 단일 화면 fix 1장 → 2장 (UI + 로직) 또는 3장 (이펙트/애니메이션/카메라)

### Tier 3: Reassign (다른 프로필)

**조건**: 동일 setup에 다른 profile이 있을 때만 (예: `default`, `docker-worker`, `cron-worker`).

```bash
hermes kanban reassign <task_id> <other-profile> --reclaim
```

**이 옵션을 거의 안 쓰는 이유**: 우리 setup에서 default 프로필 하나만 있어서 다른 profile로 갈 곳이 없음. profile을 더 만드는 건 운영자 부담.

## 패치-루프 신호

```text
preparing patch… (16-30회+)
preparing terminal…
(preparing terminal… 5회+)
```

위 패턴이 **+ commit/PR 없음**이면 진전 없는 루프. 운영자가 직접 수정 권장.

## 사용자 명시 선호 (★ 2026-07-23 종합)

### 1. Playwright/chrome-automation 자동 시각 검증 금지 (★★)

**이유**: macOS 환경에서 Playwright Chromium이 페이지를 비정상 종료(`page/context/browser has been closed`, `unhandled errors in a TaskGroup`)하고, 작업자는 `session_search`로 대안을 찾으면서 15-30분 stuck.

**대안**: 시각 검증이 필요한 카드는 **사용자가 직접 브라우저 강력 새로고침으로 확인**.

**카드 body 명시 패턴**:
```
Playwright/chrome-automation 시각 검증 시도 금지.
자동 검증은 tsc/build/test만.
시각 검증은 사용자가 한다.
```

**이미 stuck인 경우**: `kill -TERM <worker_pid>` + 운영자가 직접 수정.

### 2. 막히면 fix 전에 광범위 로깅을 먼저

PixiJS/LÖVE 포팅 중 화면이 안 그려지거나 부팅이 멈출 때, **fix를 시도하기 전에 모든 핵심 단계를 `[snkrx]` prefix 로그로 감싸서 어디서 막히는지 먼저 식별**.

**로깅 템플릿 (★ 2026-07-23 실측 채택)**:
```ts
function log(stage: string, payload?: unknown): void {
  if (payload === undefined) console.log(`[snkrx] ${stage}`)
  else console.log(`[snkrx] ${stage}`, payload)
}

async function boot(): Promise<void> {
  log('BOOT start')
  log('BOOT dom', { root: !!root, status: !!status })
  log('BOOT Application created')
  await app.init({ /* ... */ })
  log('BOOT app.init done', {
    canvasW: app.canvas.width, canvasH: app.canvas.height,
    rendererType: app.renderer.type, rendererName: app.renderer.name,
    tickerStarted: app.ticker.started,
  })
  // ... 텍스처 로드마다:
  log('LOAD start', url)
  log('LOAD image.onload', { url, w: img.naturalWidth, h: img.naturalHeight })
  log('LOAD Texture.from created', { url, texWidth: tex.width, texHeight: tex.height })
  // ... Sprite 추가 후:
  log('BOOT stage children count', app.stage.children.length)
  // ... 200ms 후 비동기 검증 (★ 효과적)
  setTimeout(() => {
    app.stage.children.forEach((child) => {
      if (child instanceof Sprite) {
        log(`VERIFY sprite ${child.label}: w=${child.width} h=${child.height} textureW=${child.texture.width}`)
        // textureW=0 → PixiJS 캐시/GC 문제 진단
      }
    })
  }, 200)
}
```

**사용자 원문 인용** (2026-07-23): "콜솔에서 더 많은 정보를 수집할 수 있도록 로그를 추가해보는게 어때?"

**규칙**: 빌드 통과 + HTTP 200 + 텍스처 데이터 정상 + Sprite 정상인데도 화면이 안 그려지면, **로깅을 추가하지 않은 채 fix를 시도하지 말 것**. 먼저 log를 모든 단계에 깔고, console 출력을 사용자에게 받아서 진단.

### 3. 사용자가 직접 처리하겠다고 한 카드는 카드로 등록

**사용자 원문 인용** (2026-07-23): "나머지는 위임할께", "사운드는 내가 처리", "사운드는 카드로 생성"

**패턴**: 카드는 **작업 단위**이지 사람 단위가 아님. 사용자가 직접 처리하더라도 **의존성 그래프에 포함된 카드로 만들어둠**. 작업자가 위임하는 카드와 동일하게 `hermes kanban create` + `kanban link`로 등록. 사용자는 직접 unblock/complete로 처리.

**이유**:
1. 의존성 그래프가 한 번에 보여 작업 흐름이 명확
2. 작업자가 자동 dispatch 가능한 카드를 명확히 분류
3. 사용자가 직접 처리할 카드도 unblock/complete 액션으로 명시적 표시

### 4. "?test=1" URL 기반 test mode + "이상 없음" 응답 → 카드 done

**사용자 검증 패턴**:
- 사용자가 "이상 없음" / "OK" / "정상" 등 단순 응답을 하면
- 운영자가 카드 done 처리 (kanban complete)
- 새 카드 dispatch

**이 규칙이 깨진 사례 (★ 주의)**: 2026-07-23 Phase 5-3에서 사용자가 "이상 없음" 응답했지만 카드는 다른 카드 (충돌 판정)에 영향. **사용자 "이상 없음"은 그 카드에 대해서만 OK 의미**. 다른 카드 검증은 별도.

### 5. "내가 확인해야할 것이 뭔지 어떻게 확인해야하는지 구체적으로 알려줘" (★★)

**사용자 원문 인용** (2026-07-23): 시각 검증 카드에 대해 "내가 확인해야할 것이 뭔지 어떻게 확인해야하는지 구체적으로 알려줘"

**해결**: 운영자는 시각 검증 카드에 대해 **"무엇을" + "어떻게" + "정상/비정상 동작"을 구체적 단계로 안내**해야 함.

**안 좋은 예**: "OK면 unblock" — 너무 일반적.
**좋은 예**: 
```
URL: http://127.0.0.1:5173/?test=1
- 뱀이 적에 닿는 순간 HP가 5/5 → 4/5로 깎임
- 적 sprite가 0.5초 동안 alpha 0.3↔1.0으로 깜빡임
- 화면이 0.1초 정도 흔들림
- 5번 닿으면 HP 0/5 → GAME OVER 표시
- 모두 보이면 OK
```

**왜 중요한지**: 사용자가 직접 브라우저 강력 새로고침으로 확인하는 게 가장 신뢰할 수 있는 검증 경로. 구체적 안내가 없으면 사용자가 \"이상 없음\"으로 응답할 때 어떤 부분을 봤는지 운영자가 알 수 없음.

### 6. 5분+ stuck 작업자는 즉시 kill

**사용자 원문 인용** (2026-07-23): "어려운 작업이 아닐꺼데, 너무 오래걸리는 것 같아. 이상없는지 체크해줘"

**운영자 행동**:
1. `ps aux | grep hermes.*<task_id>` → uptime/%CPU 확인
2. `git log -1 --oneline` → 마지막 commit 시각
3. `tail -50 .../logs/<task_id>.log` → `preparing patch…` 반복
4. 위 3가지 중 1개라도 "오래 막힘" 신호 → **즉시 kill -TERM + 직접 수정** (Tier 1)

### 7. 충돌 판정 시 적 maxHp 밸런스

**사용자 원문 인용** (2026-07-23): "적과 접촉 시 HP 감소 확인이 어려움. 적의 hp를 높여줘 (접근전에 적이 소멸됨.)"

**교훈**: 원작 LÖVE의 적 maxHp (75-130) + projectile damage (25)면 적이 4-6번에 사망 → **snake가 닿기 전에 적이 죽어서 contact event가 트리거되지 않음**.

**밸런스 가이드**:
- 적 사망까지 ~5초, snake가 적 도달까지 ~3초
- 적 maxHp 200-500 또는 projectile damage 5-10 또는 적 spawn 후 1.5초 invulnerable

**카드 body에 명시**: "스폰 직후 0.5초 무적 (테스트 모드에서 즉시 확인 가능)" 같은 사용자 검증 단서 포함.

### 8. 단일 파일 fix는 운영자가 직접

**사용자 원문 인용** (2026-07-23): "스스로 하고 있는건... 시간이 너무 걸려서 결국 직접 수정을 했었음"

**패턴**:
- 게임 개발 작업에서 단일 파일 fix (snake.ts, combat.ts, main.ts 등)는 운영자가 직접
- 작업자에게 맡기면 30분+ stuck 위험
- 운영자: kill -TERM → read_file → patch → tsc/build → git commit + push → kanban complete

**예시** (2026-07-23):
- Phase 5-2: snake.ts의 chain-follower 작업자가 30분+ stuck → 운영자가 직접 5분 작성
- Phase 5-4: shaders.ts의 aVertexPosition 에러 → 운영자가 직접 5분 수정
- Phase 4-5b: snake head radius 8→12 → 운영자가 직접 1분 수정

## Worktree 모드 (멀티에이전트 동시 작업)

```bash
# 새 작업자 격리
git worktree add /tmp/snkrx-web-wt/<task_id> -b wt/<task_id> main
# 작업자에게 HERMES_KANBAN_WORKSPACE=/tmp/snkrx-web-wt/<task_id> 전달
```

**조건**: 사용자가 명시적으로 "병렬로 진행해줘" / "동시에 여러 작업 해줘"라고 할 때만. 일반적으로는 단일 worktree에서 순차 진행이 안전.

## 운영자 검증 체크리스트 (★ 매 카드마다)

```text
1. git log -1 --stat → 작업자 commit 확인
2. git show HEAD → 실제 diff 검토 (작업자 보고와 일치하는지)
3. npm run build (또는 npm test) → 산출물 컴파일 검증
4. dev server + curl /assets/X.png HTTP 200 → 정적 자산 응답 검증
5. git status --short → untracked 파일 잔재 확인
6. 모두 통과 → kanban complete 또는 다음 카드 dispatch
7. 실패 → kanban reclaim + 더 작은 카드로 분할 OR 운영자가 직접 수정
```

**작업자가 죽으면 untracked 변경사항이 디스크에 남음** — 다음 dispatch 전에 `git stash -u` 또는 명시적 commit 필요. 그렇지 않으면 다음 카드가 conflicting state로 시작.

## ★ user에게 보고할 때의 형식 (★ 2026-07-23 명시)

**사용자 선호**: 
- 짧은 보고 + 다음 행동 제시
- 막힌 카드는 git log + uptime + ps 결과 보고
- 해결책 2-3개 제시 후 대기 (선택지 주지 않고 자동 진행 X)

**좋은 보고 예**:
```text
Phase 5-2 작업자가 18분째 stuck (patch 루프). 
옵션: A. 운영자가 직접 chain-follower 구현 (5분), 
B. 작업자 kill + 더 작은 카드로 분할
```

**나쁜 보고 예**:
```text
작업자가 진행 중입니다. 완료 시 알려드리겠습니다.
```

사용자는 "이 상태에서 안넘어감", "이상 없음" 같은 직접적 신호를 줄 때도 있고, 그게 아닐 때 명시적 선택지 요청이 필요. 두 경우 모두 커버하려면 짧은 보고 + 옵션 제시가 정답.
