# Test Mode via URL Query Param (★ 2026-07-23 SNKRX 실측 패턴)

> 게임 동작을 테스트할 때 **작업자가 변경한 코드를 영구 적용하지 않고**, 사용자가 브라우저에서 직접 테스트할 수 있도록 하는 패턴. **PixiJS/Canvas2D 게임 개발에서 사용자가 시각 검증을 자주 요청**하는 상황에 적합.

## 패턴: `?test=1` URL Query Parameter

### main.ts 진입부

```ts
// 페이지 로드 시 test 모드 결정
const TEST_MODE = new URLSearchParams(window.location.search).get('test') === '1'
  || import.meta.env.DEV   // dev 모드에서는 자동 활성화
```

### 자동 활성화 (선택)

```ts
// NODE_ENV=development일 때 자동 활성화, production에서는 URL의 ?test=1로만 켠다.
const isTestMode = (location: string, nodeEnv?: string): boolean => {
  if (location.includes('?test=1')) return true
  return nodeEnv === 'development'
}

const TEST_MODE = isTestMode(window.location.search, import.meta.env.MODE)
```

### 동작 모드 분기

```ts
// snake historyLength: 30 → 5 (HP=5로 게임 오버 테스트)
const SNAKE_HISTORY_LENGTH = TEST_MODE ? 5 : 30

// combat simulation: 발사 비활성화 (테스트로 접촉 데미지 보기)
const simulation = new CombatSimulation({
  cooldown: TEST_MODE ? Infinity : 0.4,  // Infinity면 절대 발사 안 함
  projectileSpeed: 360,
  projectileDamage: 25,
  projectileRadius: 5,
})

// 적 maxHp: 5~10배 증가 (snake가 닿기 전에 적이 안 죽도록)
const ENEMY_MAX_HP_MULTIPLIER = TEST_MODE ? 5 : 1
```

### 사용자 확인

```text
URL: http://127.0.0.1:5173/?test=1&bust=60
- hp = 5/5
- 적이 잘 살아남음
- snake가 닿으면 HP 감소
- 명멸 깜빡임
- 0.5초 무적
- GAME OVER
```

## 장점

```text
- git revert 위험 없음 (코드 변경 안 됨, URL 파라미터로만 분기)
- 사용자가 시각 검증을 위해 main 브랜치를 pollute하지 않음
- 일반 모드(?test 없음)는 production 동작 보장
- 작업자가 "테스트 모드" 카드를 만들어도 같은 URL 파라미터로 검증
```

## 함정: 작업자 self-revert 안티패턴

작업자가 같은 카드 실행 안에서 `commit A (test mode 추가) + commit B (revert A)`를 하는 경우. 결과: 카드는 `done`이지만 사용자가 `?test=1`을 열어도 변화 없음.

**해결**:

```text
1. 카드 body에 "revert 금지, 사용자가 OK 할 때까지 유지" 명시
2. 두 카드로 분리: 카드 1 "테스트 모드 적용", 카드 2 "원본 복구" (사용자 OK 후 별도)
3. 작업자가 "변경" + "revert" 둘 다 commit으로 남기는 게 정상 흐름이 되도록
```

## 일반화: 다른 작업에도 응용

```text
- 디버그 모드: ?debug=1 → console.log 추가, 강제 1초 정지
- 성능 측정: ?perf=1 → fps 표시, draw call 카운터 표시
- 시각 회귀: ?regression=1 → 비교용 캔처 + 픽셀 diff 표시
- A/B 테스트: ?variant=A 또는 ?variant=B
```

## 브라우저 강력 새로고침

캐시 무효화: `?bust=<timestamp>` 같은 cache buster를 URL 끝에 붙여 강력 새로고침과 동등 효과.

```text
http://127.0.0.1:5173/?test=1&bust=1700000000
```
