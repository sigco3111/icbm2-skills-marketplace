# boot-time 자산 로드 트랩 (★ 2026-07-23 PixiJS 실측)

## 증상

작업자가 다음과 같이 작성:
```ts
await Promise.all([
  Assets.load<Texture>('/assets/images/warrior.png'),
  Assets.load<Texture>('/assets/images/speed_booster_elite.png'),
])
addBattleDemo(app, playerTexture, enemyTexture)
```

그리고 보고:
- ✅ `npm run build` 통과
- ✅ Vite dev server HTTP 200
- ✅ `/assets/images/warrior.png` curl 200 OK (249 bytes)
- ✅ `/assets/images/speed_booster_elite.png` curl 200 OK (389 bytes)

하지만 사용자가 브라우저에서 본 화면:
- ❌ "PixiJS 초기화 중..." 텍스트만 보이거나
- ❌ 가운데 빨간 정사각형 1개만 보이고 우측 상단 sprite는 텅 빈 placeholder
- ❌ "이 상태에서 안넘어감"

## 원인

**빌드 성공 ≠ 부팅 성공 ≠ 화면 표시**.

`boot()` 안에서 `Promise.all([Assets.load(...), Assets.load(...)])`가 둘 중 하나라도 실패하면 throw. 이후 코드가 실행되지 않아 `app.stage.addChild(...)` 호출이 안 일어나 캔버스가 비어 있음.

가능한 throw 원인:
- 텍스처 경로 오타 (`/asset/...` vs `/assets/...`)
- CORS 헤더 누락
- MIME type 불일치 (PNG인데 text/plain 응답)
- 파일 0 bytes 또는 손상
- PixiJS Assets 캐시 충돌 (같은 키로 다른 URL 로드)

## 진단

```bash
# 1. 텍스처가 실제로 200 OK로 떨어지는지
curl -fsS -o /dev/null -w 'HTTP %{http_code} %{size_download}b\n' \
  http://127.0.0.1:5175/assets/images/warrior.png

# 2. 브라우저 콘솔에 PixiJS 에러가 있는지
# F12 → Console → "[snkrx] 텍스처 로드 실패" 검색

# 3. main.ts에서 Promise.all을 loadOptional로 바꿨는지
grep -n 'Promise.all\|Assets.load' src/main.ts
```

## 해결 (★ 단일 권장 패턴)

```ts
async function loadOptional(url: string): Promise<Texture | null> {
  try {
    return await Assets.load<Texture>(url)
  } catch (error) {
    console.warn(`[snkrx] 텍스처 로드 실패 (${url}):`, error)
    return null
  }
}

const textures: LoadedTextures = {
  player: await loadOptional('/assets/images/warrior.png'),
  enemy: await loadOptional('/assets/images/speed_booster_elite.png'),
}
addBattleDemo(app, textures)  // ← 항상 실행됨

function addBattleDemo(app: Application, textures: LoadedTextures): void {
  if (textures.player) {
    const player = new Sprite(textures.player)
    /* ... */
    app.stage.addChild(player)
  } else {
    // 빨간 정사각형 fallback (디버깅 가시화)
    const placeholder = new Graphics()
    placeholder.rect(0, 0, 24, 36).fill(0xe53935)
    /* ... */
    app.stage.addChild(placeholder)
  }
  // enemy도 동일 패턴
}
```

전체 작동 예제는 `templates/pixijs-boot-with-fallback.ts` 참조.

## 운영 규칙 (Kanban 카드 body에도 명시)

```text
부팅 시 모든 자산 로드는 loadOptional로 감싸고,
실패 시 console.warn + null 반환.
addBattleDemo는 텍스처 null이어도 항상 실행.
Sprite or Graphics fallback으로 빈 화면 방지.
빌드 성공만으로 카드 완료 금지 — 브라우저 시각 확인 필수.
```

## 검증 방법

작업자가 review-required로 멈춘 후 Hermes 운영자가 검증할 때:

```bash
# 1. 실제 화면이 그려지는지 (가장 중요)
#    브라우저에서 직접 보거나, curl로 index.html + main.ts 200 OK 확인
curl -fsS -o /dev/null -w 'HTTP %{http_code}\n' http://127.0.0.1:5175/
curl -fsS -o /dev/null -w 'HTTP %{http_code}\n' http://127.0.0.1:5175/src/main.ts

# 2. 모든 자산이 200 OK로 떨어지는지
for url in $(grep -oE '/assets/[^"'\'']+\.png' src/main.ts | sort -u); do
  code=$(curl -fsS -o /dev/null -w '%{http_code}' "http://127.0.0.1:5175${url}" 2>/dev/null || echo none)
  echo "${url}: ${code}"
done

# 3. Promise.all이 남아 있지 않은지
! grep -q 'Promise.all.*Assets.load' src/main.ts
```

## 사용자 보고 형식

작업자가 이 함정을 만났을 때 Hermes 운영자에게 보고:

```text
review-required: build + dev server 200 OK + 자산 200 OK 확인했으나
사용자 브라우저에서 [특정 증상] 발견.
src/main.ts L[N]의 Promise.all+Assets.load가 텍스처 실패 시 throw.
loadOptional + Sprite/Graphics fallback으로 수정 필요.
재현: 브라우저에서 http://127.0.0.1:5175/ 직접 확인.
```

작업자가 이 함정을 스스로 진단하지 못하면 Hermes 운영자가 직접 수정.