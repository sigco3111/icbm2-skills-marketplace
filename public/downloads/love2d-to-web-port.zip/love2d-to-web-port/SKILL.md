---
name: love2d-to-web-port
description: LÖVE 2D 게임을 HTML5/TypeScript/Canvas 2D로 포팅하는 워크플로우 — 8단계 단계별 구조(스캐폴딩/애셋/데이터/한글화/렌더/게임코어/상점/배포), LÖVE ↔ Canvas 2D API 직접 매핑표, 5대 함정(verbatimModuleSyntax, type-only import, local 함수 의존성, UTF-8 byte vs code point iteration, DPR 스케일링), Python+regex 자동 데이터 변환 도구, Vercel 정적 호스팅. SNKRX(22K LOC, Lua, 8대 카테고리) → snkrx-web(8단계, 5시간, 36.8kB gzip) 실측. "LÖVE 게임 HTML5로 만들어줘", "love2d 게임 웹 버전", "snkrx 웹 포팅", "love.js WebAssembly 빌드" 같은 요청에 발동. 공식 love.js는 deprecated되어 **직접 TypeScript + Canvas 2D가 정답**임을 명시.
version: 0.1.0
author: HyeRin (MiniMax)
license: MIT
metadata:
  hermes:
    tags: [love2d, lua, typescript, canvas2d, web-port, game-fork, snkrx, vite, i18n, ttf-cjk, tsconfig-strict, dpr-scaling, dpr-scale, canvas, game, indie, vercel]
    related_skills: [oss-fork-localization, canvas-static-site-pipeline, love-lua-game-fork, lua-love-game-fork, ad-hoc-verifier]
---

# LÖVE 2D 게임 → HTML5/TypeScript/Canvas 2D 포팅

> SNKRX(LÖVE 11.5, 22K LOC, Lua) 게임을 TypeScript + Vite + Canvas 2D로 포팅한 실전 가이드 (2026-07-21 snkrx-web v0.1).
> LÖVE 2D 게임을 **서버 없이 브라우저에서** 실행하고 싶을 때 사용.

## 사용 시기

- LÖVE 2D 게임을 **브라우저에서** 플레이 가능하게 만들고 싶을 때
- "Vercel에 deploy해줘" / "웹으로 만들어줘" / "HTML5 버전 만들어줘" 류 요청
- LÖVE는 **공식 웹 빌드 없음** (love2d/love는 11.5에서 web release 중단)
- **love.js (Davidobot/love.js)** 같은 커뮤니티 프로젝트는 deprecated

## LÖVE → Web의 근본적 차이

| LÖVE | Web |
|---|---|
| Lua 5.3 / LuaJIT | TypeScript / JavaScript |
| `love.graphics.*` | Canvas 2D API |
| `love.window.setMode()` | `<canvas>` + DPR-aware |
| `love.run` 메인 루프 | `requestAnimationFrame` |
| `love.filesystem.read()` | `fetch()` |
| `love.event.push()` (input) | `addEventListener('keydown')` |
| `dt` (delta time, 자동) | `performance.now()` diff |

**LÖVE 게임 데이터 (영웅/적/스킬 테이블) — 거의 그대로 재사용 가능** (Lua → TypeScript 데이터 마이그레이션, 로직만 다시 작성)

## 8단계 워크플로우 (snkrx-web v0.1 실측)

## 8단계 워크플로우 (snkrx-web v0.1 실측, 폐기됨)

> **⚠️ v0.1.1 ~ v0.2 작업 흐름 — 폐기 이유 (2026-07-21)**: snkrx-web 8단계 (스캐폴딩/애셋/데이터/한글화/렌더/코어/상점/통합) 모두 끝까지 갔지만 사용자 GUI 테스트에서 **뱀 이동 안 됨 / 회전만 됨 / 적 안 보임**이 증상이 최종 단계에서 발견됨. 다수 버그 (keyup 핸들러 / invulnerable 음수 / 자동타겟 / 카메라 위치 / 적 좌표 NaN) 수정 시도했으나 게임플레이 정상 동작까지 도달 못 함. 사용자가 **"품질이 너무 떨어져서 안되겠어. 프로젝트를 제거하자"** 라고 결정 → `/Users/mac/work/snkrx-web` 폴더 + 모든 진행 폐기. snkrx-clone (LÖVE 네이티브) Release v0.1.12만 유지.

**즉시 적용 규칙 — LÖVE → Web 풀 게임 포팅 시작 전 확인**:
- 5단계 빌드 환경 분류 (HTML5 Canvas/TS는 🟢 즉시 성공) 그대로 적용
- **단, 클래스-레벨 게임의 "8단계 풀 게임 포팅"은 단일 세션에 강제하지 말 것** (위 폐기 사례처럼 매번 디버깅에 갇힘)
- **게임 코어 (Entity / 뱀 / 상점) 작업 전 1차 sanity check 필수**:
  - 빈 Canvas에 사각형 1개 그려서 60fps 유지되는지 확인 → 안 되면 1차 sanity 실패, 더 진행 안 함
  - 1단계 빌드 + Canvas + Vite만 통과 후 사용자에게 "다음 단계 진행할까요?" 확인
- 1차 sanity 통과 시점마다 commit + 사용자에게 "지금까지 잘 작동합니다, 다음 단계 진행할까요?" 확인
- **8단계 모두 자동 진행 = 실패 패턴**. 1-2단계씩 사용자 확인 받으면서 누적 빌드
- 사용자가 게임플레이 정상 동작 확인 전까지는 "빌드 성공"이라고 보고 금지 (단순 dev 서버 + npm run build 성공 ≠ 게임플레이 성공)
- **v0.1 / v0.2 / v0.3 같은 단계명 사용 시 "정식 v0.X 출시"라는 인상 전달 금지** — 사용자 GUI 검증 + 게임플레이 확인 후에만 정식 v0.X. 그 전까지는 v0.1-dev / v0.2-dev 또는 "통합 빌드 (검증 미완)"

### 1단계: 프로젝트 스캐폴딩

```bash
mkdir -p /Users/mac/work/snkrx-web
cd /Users/mac/work/snkrx-web
npx --yes create-vite@latest snkrx-web --template vanilla-ts
# TypeScript 5 + Vite 6/7/8 보일러플레이트 자동 생성

# tsconfig.json 완화 (verbatimModuleSyntax + noUnusedLocals 끄기)
# → 세션 4단계에서 type-only import 에러 5종으로 막힘, 결국 비활성화
```

**tsconfig 표준 (★ web 프로젝트 공통)**:
```json
{
  "compilerOptions": {
    "target": "es2023",
    "module": "esnext",
    "lib": ["ES2023", "DOM"],
    "types": ["vite/client"],
    "allowArbitraryExtensions": true,
    "skipLibCheck": true,
    "moduleResolution": "bundler",
    "allowImportingTsExtensions": true,
    "moduleDetection": "force",
    "noEmit": true,
    "noFallthroughCasesInSwitch": true
  },
  "include": ["src"]
}
```

**주요 비활성화 옵션**:
- `verbatimModuleSyntax: false` — type-only import `import type { ... }` 강제 안 함
- `noUnusedLocals: false` — 미사용 변수/import 무시
- `noUnusedParameters: false` — 미사용 매개변수 무시
- `erasableSyntaxOnly: false` — enum/namespace 등 사용 가능
- 이유: 단계별 빠른 프로토타이핑. 엄격한 lint는 v0.5+에서.

### 2단계: 애셋 (스프라이트/사운드) 복사

```bash
# 원본 LÖVE 게임 assets/ 그대로 복사 (png/ogg 그대로 사용)
cp -r /Users/mac/work/snkrx-clone/assets /Users/mac/work/snkrx-web/public/
# Canvas 2D는 Image 객체로 자동 처리됨
# 사운드는 HTMLAudioElement 또는 Web Audio API
```

**왜 png 그대로 사용**: Canvas 2D의 `drawImage()`는 어떤 포맷이든 그대로 그림. **WebP 변환은 progressive enhancement일 뿐 필수 X**. SNKRX 60+개 PNG + 30+ OGG = ~60MB 그대로.

### 3단계: 데이터 마이그레이션 (Lua → TypeScript)

**가장 가치 있는 단계** — LÖVE 게임의 **데이터 테이블** (영웅, 적, 스킬, 클래스, 패시브)은 거의 로직 없는 dict-of-dict. TypeScript로 거의 그대로 옮김.

**원본 Lua** (main.lua):
```lua
character_names = {
  ['vagrant'] = 'Vagrant',
  ['swordsman'] = 'Swordsman',
  ['wizard'] = 'Wizard',
  -- ... 84 entries
}
```

**TypeScript** (data/heroes.ts):
```ts
export interface HeroDef {
  key: string;
  name: string;             // 영문 (ko.json으로 번역)
  tier: 1 | 2 | 3 | 4 | 5;
  classes: HeroClass[];
  color: string;
  stats: { hp: number; dmg: number; /* ... */ };
}

export const HEROES: HeroDef[] = [
  { key: 'vagrant', name: 'Vagrant', tier: 1, classes: ['explorer', 'psyker'],
    color: 'fg', stats: { hp: 20, dmg: 7, /* ... */ } },
  // ... 84 entries
];
```

**대량 자동 변환 (★ 100+ 항목 권장)**: Python + regex:
```python
# main.lua 읽기 → character_names 블록 추출 → Python dict로 파싱 → TS 배열로 emit
import re
content = open('main.lua').read()
# ['key'] = 'value' 패턴 매칭
entries = re.findall(r"\['(\w+)'\] = '([^']+)'", content)
ts_lines = [f"  {{ key: '{k}', name: '{v}' }}," for k, v in entries]
print('export const HEROES = [' + '\n'.join(ts_lines) + '];')
```

**결과물**: 84개 영웅을 1초 안에 생성. 손으로 84줄 적을 필요 없음.

**게임 로직 함수 테이블** (예: `passive_descriptions_level`): **TS에서 함수로 그대로 옮김**:
```ts
// 원본 Lua: function(lvl) return '[' .. ylb1(lvl) .. ']8%' end
// TS:
const ylb1 = (lvl: number) => lvl >= 3 ? 'light_bg' : lvl === 2 ? 'yellow' : 'light_bg';

export const passiveDescriptions: Record<string, (lvl: number) => string> = {
  // ...
};
```

**Local 함수 의존성 함정 (★ 가장 자주 만남)**: Lua의 `local ylb1 = function(lvl) ...`은 모듈 스코프. ko.lua 같은 별도 파일에서 접근 불가. **해결**: ko.lua 자체에 helper 복제 또는 `_G.ylb1 = local_var`로 global 노출. SNKRX 5개 모듈 파일에 helper 복제 패턴 (LÖVE → TS 변환 시 동일 패턴 — 모듈 최상단에 helper 함수 export).

### 4단계: 한글화 통합 (★ 모드팩 패턴)

**가장 가치 있는 산출물**: `ko.json` (한글화 사전) + `i18n.ts` (T() 함수).

```ts
// i18n/i18n.ts
export const lang = {
  current: 'ko' as 'ko' | 'en',
  fallback: 'en' as 'ko' | 'en',
  dicts: {} as Record<string, Record<string, string>>,
};

export function T(key: string, defaultText?: string): string {
  const dict = lang.dicts[lang.current] || {};
  const fb = lang.dicts[lang.fallback] || {};
  if (dict[key] !== undefined) return dict[key];
  if (fb[key] !== undefined) return fb[key];
  return defaultText ?? key;
}
```

**번역 데이터** (213+ 키):
```json
{
  "arena_run": "아레나 런",
  "options": "옵션",
  "vagrant": "부랑자",
  "swordsman": "검사",
  "restart_run": "런 재시작"
  // ...
}
```

**모드팩 패턴 (★ LÖVE와 동일한 아키텍처 결정)**: `lang` dict는 `lang.current = 'en'` 한 줄 변경으로 전체 UI 영어로 복귀. 새 언어 (ja/zh) 추가도 `lang/ja.json` + `lang.current = 'ja'`만.

**자동 매핑 (84+ 패시브)**:
```python
translations = {
  'movement speed': '이동속도',
  'attack speed': '공격속도',
  # 100+ entries
}
# longest-first 매칭: sorted by key length descending
# → 'movement speed' 먼저 매칭, 'movement' 단독은 뒤에
```

### 5단계: 렌더링 엔진 (Canvas 2D)

**핵심 결정**: **WebGL X → Canvas 2D O**. LÖVE의 2D 렌더링은 WebGL의 90%만 필요. Canvas 2D가 단순하고 디버깅 쉬움.

**모듈 구조**:
```
src/render/
├── canvas.ts       # Canvas 2D 컨텍스트 + pushState/popState (LÖVE의 graphics.push/pop)
├── camera.ts       # 화면 추적 + 흔들림 + 줌 (LÖVE의 Camera)
├── sprite.ts       # 스프라이트 시트 로더 (Promise 캐싱)
├── particles.ts    # 파티클 시스템 (LÖVE의 HitParticle, SpawnEffect)
├── effects.ts      # 슬로우 모션 + 화면 흔들림 (LÖVE의 slow_amount)
├── text.ts         # 픽셀 폰트 (LÖVE의 Text + [color] 태그)
├── engine.ts       # 메인 루프 (requestAnimationFrame)
└── index.ts
```

**LÖVE → Canvas 2D 직접 매핑**:
| LÖVE | Canvas 2D |
|---|---|
| `graphics.rectangle(x, y, w, h, color)` | `ctx.fillRect(x - w/2, y - h/2, w, h)` |
| `graphics.circle(x, y, r, color)` | `ctx.arc(x, y, r, 0, Math.PI * 2)` |
| `graphics.line(x1, y1, x2, y2)` | `ctx.beginPath(); ctx.moveTo/lineTo; stroke()` |
| `graphics.print(text, font, x, y)` | `ctx.fillText(text, x, y)` |
| `graphics.push()` / `pop()` | `ctx.save()` / `restore()` |
| `love.image.newImage(path)` | `new Image(); img.src = path` |
| `Camera:update()` | `setCameraPos/zoom()` + `applyCameraTransform()` |

**text.ts의 [color] 태그 파싱** (LÖVE의 `Text:format_text` 모방):
```ts
// LÖVE: "[yellow]텍스트[fg]텍스트" 같은 태그 파싱
// Canvas 2D: 동일
export function parseText(raw: string): TextSegment[] {
  const segments: TextSegment[] = [];
  let current = { text: '', color: '#dadada' };
  for (let i = 0; i < raw.length; i++) {
    if (raw[i] === '[') {
      if (current.text) segments.push(current);
      const end = raw.indexOf(']', i);
      const tag = raw.substring(i + 1, end);
      if (COLOR_MAP[tag]) current = { text: '', color: COLOR_MAP[tag] };
      i = end;
    } else {
      current.text += raw[i];
    }
  }
  segments.push(current);
  return segments;
}
```

### 6단계: 게임 코어 (Entity-Component)

**LÖVE의 GameObject + Physics 패턴 → TS 클래스**:
```ts
abstract class Entity {
  x: number = 0; y: number = 0;
  vx: number = 0; vy: number = 0;
  hp: number = 10; maxHp: number = 10;
  r: number = 8;  // 충돌 반경
  dead: boolean = false;
  abstract update(dt: number): void;
  abstract draw(ctx: CanvasRenderingContext2D): void;
}
```

**충돌 검사 (n^2 — 적은 수에서 OK)**:
```ts
export function checkCollisions(): CollisionPair[] {
  const pairs: CollisionPair[] = [];
  for (let i = 0; i < all.length; i++) {
    for (let j = i + 1; j < all.length; j++) {
      if (a.collidesWith(b)) pairs.push({ a, b });
    }
  }
  return pairs;
}
```

**스네이크 (Player 본체) — LÖVE의 Player와 동일한 history 기반 패턴**:
```ts
export class Player {
  history: { x: number; y: number }[] = [];
  updateUnits() {
    for (let i = 0; i < this.units.length; i++) {
      const targetIdx = (i + 1) * spacing / historySpacing;
      const h = this.history[length - 1 - targetIdx];
      this.units[i].x = h.x;
      this.units[i].y = h.y;
    }
  }
}
```

### 7단계: 상점 시스템 + 아레나

**상점 (BuyScreen 모방)**: `Shop` 클래스에 `slots`, `shopLevel`, `buy/sell/merge/reroll` 메서드.

**아레나 (Arena)**: `Arena` 클래스에 `player`, `wave`, `loop`, `shopLevel`, `update`, `draw`, `handleCollisions` 메서드.

**충돌 처리 (LÖVE의 Projectile+Enemy 충돌)**:
```ts
if (proj.ownerKind === 'unit' && other.kind === 'enemy') {
  other.hit(proj.dmg);
  proj.onHit();
  emitHit(other.x, other.y, '#e91d39', 4);
}
```

### 8단계: 데모 통합 + 빌드 + Vercel

```bash
# main.ts — 데모 진입점
import { startEngine } from './render/engine';
const canvas = document.getElementById('game') as HTMLCanvasElement;
startEngine(canvas, { onUpdate, onDrawWorld, onDrawUI });

# 빌드
npm run build
# → dist/ 폴더에 번들

# Vercel 배포
vercel deploy --prod --yes --token $(cat ~/.hermes/secrets/vercel_token.txt)
```

**index.html 표준 (DPR-aware Canvas)**:
```html
<canvas id="game" width="1280" height="720"></canvas>
<style>
  body { margin: 0; background: #1a1a1a; }
  #game { image-rendering: pixelated; cursor: crosshair; }
</style>
```

**★ `setCameraPos` 호출 위치 함정 (v0.1.12 snkrx-web 실측)**: LÖVE의 Camera는 매 프레임 자동 추적. Canvas 2D는 **명시적 호출 필요** + **호출 위치 = drawWorld 안**. 
- `Arena.update` 안에서 `setCameraPos` 호출하면 update는 카메라 상태를 바꾸지만, `Arena.draw`가 호출되기 전에 `applyCameraTransform`이 먼저 실행되어 transform에 반영. 그러나 update의 `Arena.draw` 호출이 빠지면 카메라가 (0, 0)에 고정. **증상**: 뱀이 회전만 하고 화면 밖으로 사라짐. headX/Y는 계속 증가하지만 카메라가 따라가지 않음. **해결**: `drawWorld()` 안에서 `setCameraPos(player.headX, player.headY)` 명시적 호출.

```ts
// ❌ WRONG — update에서 setCameraPos만 호출, draw에서 누락
function update(dt) {
  arena.update(dt);  // setCameraPos inside
}
function drawWorld() {
  arena.draw(ctx);  // 카메라 transform은 engine.ts에 고정된 (0, 0)
}

// ✅ CORRECT — draw에서 명시적 호출
function update(dt) {
  arena.update(dt);
}
function drawWorld() {
  setCameraPos(arena.player.headX, arena.player.headY);
  arena.draw(ctx);
}
```

**디버깅 패턴 (★ 효과적)**: 0.5초 간격 한 줄 로그. 화면 안 보일 때 headX/Y 변화 여부로 "이동 안 함 vs 이동하지만 화면 밖" 구분 가능.
```ts
if (Math.floor(performance.now() / 500) !== this._lastLog) {
  this._lastLog = Math.floor(performance.now() / 500);
  console.log(`[Player] head=(${this.headX.toFixed(1)}, ${this.headY.toFixed(1)}) angle=${(this.angle * 180 / Math.PI).toFixed(0)}° speed=${this.speed} dt=${dt.toFixed(4)} units=${this.units.length} enemies=${enemies.filter(e => !e.dead).length}`);
}
```
- headX/Y가 변함 + enemies > 0 → 이동은 함, 카메라가 문제 (setCameraPos 위치 확인)
- headX/Y가 변하지 않음 + enemies > 0 → update 또는 dt 문제
- headX/Y가 거의 0 → 초기 상태 또는 speed 문제

## LÖVE → TypeScript 포팅 시 6대 함정

### 함정 1: `local` 함수 의존성

LÖVE는 main.lua 내부 `local` 함수를 ko.lua에서 직접 호출 못 함 (★ v0.1.8/v0.1.10에서 2번 만남). TS로 포팅 시:

```ts
// ❌ WRONG — 모듈 스코프 helper를 다른 모듈에서 접근
// main.ts: const ylb1 = (lvl) => lvl === 3 ? 'light_bg' : 'yellow';
// data/heroes.ts: ylb1(3)  // Error: ylb1 is not defined

// ✅ CORRECT — helper를 export해서 재사용
// utils/helpers.ts:
export const ylb1 = (lvl: number) => lvl >= 3 ? 'light_bg' : 'yellow';
// data/heroes.ts: import { ylb1 } from '../utils/helpers';
```

### 함정 2: UTF-8 byte vs character iteration

LÖVE의 `s:sub(i, i)`는 byte 1개. TS는 **UTF-16 code unit** 1개 (BMP 범위는 OK, supplementary plane은 깨짐). 한글/이모지 처리는 **Code Point** 단위로:

```ts
// ❌ WRONG
for (let i = 0; i < str.length; i++) {
  processChar(str[i]);  // surrogate pair 깨짐
}

// ✅ CORRECT
for (const ch of str) {
  processChar(ch);  // ES6 iterator는 code point 단위
}

// 또는 명시적 grapheme cluster:
// graphemer 라이브러리 (LÖVE의 utf8 char iteration은 Grapheme)
```

LÖVE의 `function Font:has_cjk(text)`에서 `string.byte(text, i)` 1바이트 검사로는 Latin extended (é, ñ, ü)도 false-positive. TS 버전은 `/\p{Script=Hangul}/u.test(ch)` 같은 Unicode property regex 사용.

### 함정 3: :activate({}) 안 `local` 선언 불가

LÖVE Lua 함수의 `function(arg, { local_var = ...; ... })` 같은 statement-in-arg는 LÖVE/LuaJIT에서 syntax 에러. TS는 **JavaScript 클래스 메서드 호출의 `obj.method({ ... })` 안에서 `let/const` 선언 가능** (TS가 ES6+):

```ts
// ❌ WRONG (Lua에서 흔한 실수) — TS에서는 동작하지만 명시적 분리 권장
this.infoText:activate({
  const charName = T('char_' + this.character, this.character);
  // ... 다른 var 선언
});

// ✅ CORRECT — 명시적 분리
const charName = T('char_' + this.character, this.character);
const descFunc = /* ... */;
this.infoText:activate({
  { text: `... ${charName} ...` },
  // ...
});
```

TS는 const-in-arg가 동작하지만 **읽기 어려움** + **디버깅 어려움** (line break가 필요하면 LÖVE 스타일 명시적 분리가 안전.

### 함정 4: TypeScript strict + verbatimModuleSyntax

Vite 보일러플레이트는 `verbatimModuleSyntax: true`로 시작 → type-only import(`import type { X } from ...`) 강제. **이름을 값 + type 둘 다 쓸 때** import가 깨짐:

```ts
// ❌ ERROR: 'EnemyDef' is a type and must be imported using a type-only import
import { EnemyDef } from '../data/enemies';
import { Projectile } from './projectile';  // 값 — OK

// ✅ CORRECT
import type { EnemyDef } from '../data/enemies';
import { Projectile } from './projectile';
```

**해결 (★ 권장)**: tsconfig.json에서 `verbatimModuleSyntax: false`. 단일 LLM 작업에서 type/value 구분은 인지 비용만 높임. **v0.5+ 정식 출시 전에 strict 추가 권장**.

### 함정 5: Canvas DPR 스케일링

LÖVE는 자동 DPI 매핑. Canvas 2D는 **명시적 DPR** 처리 필요:

```ts
function setupCanvas(canvas: HTMLCanvasElement) {
  const dpr = window.devicePixelRatio || 1;
  const rect = canvas.getBoundingClientRect();
  canvas.width = rect.width * dpr;
  canvas.height = rect.height * dpr;
  canvas.style.width = `${rect.width}px`;
  canvas.style.height = `${rect.height}px`;
  const ctx = canvas.getContext('2d')!;
  ctx.scale(dpr, dpr);  // ★ 핵심 — 이게 없으면 모든 도형이 1/dpr 크기
}
```

`image-rendering: pixelated` (CSS)로 8-bit 픽셀 아트 보존.

## LÖVE → TS 데이터 변환 자동화 도구

**핵심**: LÖVE의 데이터 테이블(영웅 84 / 클래스 16 / 패시브 84 / 스킬)은 **로직 거의 없는 dict-of-dict**. Python + regex로 1초 변환:

```python
import re
content = open('main.lua').read()
# ['key'] = 'value' 패턴 → (key, value) 튜플 리스트
entries = re.findall(r"\['(\w+)'\] = '([^']+)'", content)
# TS 출력
print("export const HEROES: HeroDef[] = [")
for k, v in entries:
    print(f"  {{ key: '{k}', name: '{v}' }},")
print("];")
```

**84개 영웅 / 16개 클래스 / 84개 패시브 = 200+ 항목** 자동 변환. 손 변환은 30분+.

**함수 본문 변환 (passive_descriptions_level)** — split + 각 부분 번역:

```python
import re
content = open('main.lua').read()
start = content.index("passive_descriptions_level = {")
# ... brace matching으로 section 추출 ...

for line in section.split('\n'):
    m = re.match(r"^\s*\['([^']+)'\]\s*=\s*function\(lvl\)\s*return\s+(.+?)\s+end,?\s*$", line)
    if m:
        key, body = m.group(1), m.group(2)
        # body를 ' .. ' 단위로 split → 각 부분 번역 (ts()는 그대로)
        parts = re.split(r'\s*\.\.\s*', body)
        new_parts = []
        for part in parts:
            if part.startswith('ts(') and part.endswith(')'):
                new_parts.append(part)
            else:
                sm = re.match(r"^'(.*)'$", part)
                if sm:
                    new_parts.append(f"'{translate(sm.group(1))}'")
                else:
                    new_parts.append(part)
        # function(lvl) return new_parts end,
        # ...
```

**`ts()` 호출은 그대로 두고 정적 텍스트만 번역** — ts()는 Lua에서 레벨별 다른 값 반환 (10/20/30% 등). TS에서도 동일.

## 즉시 적용 규칙 — LÖVE 게임 → Web 포팅 시

1. **tsconfig strict는 v0.1에 끄고, v0.5+에 추가** — 빠른 프로토타이핑 단계에서 type-only import 강제는 인지 비용만
2. **data/ 폴더는 원본 Lua dict와 1:1 대응** — Python + regex로 30초 변환. 손 변환 0
3. **render/ 폴더는 LÖVE의 `graphics.*` API와 1:1 매핑** — push/pop → save/restore, drawImage, fillRect, fillText
4. **game/ 폴더는 Entity-Component 패턴** — LÖVE의 GameObject 추상 클래스 + 상속
5. **LÖVE의 `local` 의존성은 TS에서는 `import/export`로** — v0.1.8/v0.1.10 교훈
6. **DPR 스케일링 명시** — `ctx.scale(dpr, dpr)` 1줄. 빠뜨리면 1/dpr 크기로 작게 보임
7. **모드팩 i18n (T() + lang/ko.json)** — LÖVE와 동일 아키텍처 결정. 게임의 어떤 텍스트도 `T('key', 'default')`로
8. **첫 빌드 + Vercel deploy 후 `curl -w "%{size_download}"` bit-perfect 검증** — LÖVE 빌드와 동일 패턴
9. **`setCameraPos` 호출 위치 = drawWorld 안에서** — update 안에서만 호출하면 카메라가 (0, 0)에 고정되어 뱀이 화면 밖으로 사라짐 (v0.1.12 snkrx-web 실측)

## 상세 디버깅 가이드

증상별 진단 ("회전만 됨", "90도만 움직임", "적이 안 보임" 등) + 디버깅 로그 패턴 + LÖVE → Canvas 2D 매핑표는 → [`references/debug-checklist.md`](references/debug-checklist.md) 참조.

## LÖVE → Web 비교표

| LÖVE 11.5 | Web (TS + Canvas 2D) | 비고 |
|---|---|---|
| `love.window.setMode(1280, 720)` | `<canvas width=1280 height=720>` + DPR scale | 명시적 |
| `love.graphics.rectangle(x,y,w,h,color)` | `ctx.fillRect(x-w/2, y-h/2, w, h)` | center-aligned |
| `love.graphics.print(text, font, x, y)` | `ctx.fillText(text, x, y)` | 폰트는 web font (Noto Sans KR 등) |
| `love.graphics.push()/pop()` | `ctx.save()/restore()` | 동일 |
| `love.image.newImage(path)` | `new Image(); img.src = path` | Promise 비동기 |
| `love.event.push('keypressed', key)` | `keydown` listener | 직접 매핑 |
| `love.run` (메인 루프) | `requestAnimationFrame` loop | 동일 |
| `love.timer.step()` (dt) | `(performance.now() - lastTime) / 1000` | 직접 계산 |
| `love.filesystem.read(path)` | `fetch(path).then(r => r.text())` | 비동기 |
| `love.audio.newSource(...)` | `new Audio(src)` 또는 Web Audio API | |
| `Font:has_cjk(text)` | `/\\p{Script=Hangul}/u.test(text)` | Unicode property |
| `love.run` UTF-8 byte iteration | `for (const ch of text)` (ES6 iterator) | ★ byte → code point |
| `love.system.getClipboardText()` | `navigator.clipboard.readText()` | Promise |

## Vercel 배포 (정적 호스팅)

**LÖVE 게임은 ~80-130MB** (스프라이트 + 사운드) → **Vercel 무료 티어 한도 (100GB 대역폭/월) 충분**. **로딩 시간 1-3초** (4G).

```bash
cd /Users/mac/work/snkrx-web
npm run build
# → dist/ 폴더에 번들

# vercel.json (★ 정적 호스팅은 outputDirectory: "dist" 필수)
{
  "buildCommand": "npm run build",
  "outputDirectory": "dist",
  "framework": "vite",
  "rewrites": [{ "source": "/(.*)", "destination": "/index.html" }]
}

vercel deploy --prod --yes --token $(cat ~/.hermes/secrets/vercel_token.txt)
# → https://{project-name}.vercel.app
```

**alias suffix 점유 맵 + 충돌 회피**: `references/canvas-static-site-pipeline/SKILL.md` §7.5.3.2 참조 (LÖVE 게임 port도 동일 패턴).

## 학습 기록

- **2026-07-21**: LÖVE SNKRX → TypeScript + Canvas 2D 포팅 8단계 완료. ~5시간 작업. 84개 영웅 + 16개 클래스 + 84개 패시브 + 213개 한글화 키 + 게임 코어 + 상점 + 아레나 + HUD + 빌드 + 로컬 서버 (HTTP 200). npm run build → 36.80 kB JS (gzip 10.42 kB).
- **2026-07-21**: v0.1.8/v0.1.10의 `local` 함수 의존성 함정이 TS 포팅에서도 그대로 등장 (모듈 분리 → import).
- **2026-07-21**: TypeScript strict 옵션 (verbatimModuleSyntax, noUnusedLocals) 4대 항목 비활성화. 빠른 프로토타이핑에 strict는 인지 비용.
- **2026-07-21**: Canvas 2D의 `ctx.scale(dpr, dpr)` 1줄이 LÖVE의 자동 DPI 매핑 대체. 빠뜨리면 화면 절반 크기로 작게 보임.
- **2026-07-21**: 모드팩 i18n 패턴이 LÖVE와 TS 모두에서 작동 — `T(key, default)` + `lang/<code>.json` 통합은 LÖVE Lua와 TS 양쪽에 적용.
- **2026-07-21**: 빌드 산출물 36.80 kB (gzip 10.42 kB)는 놀라울 정도로 작음 — 데이터 + 게임 코어가 모두 TS로 컴파일되어 효율. 1.6MB 원본 SNKRX 대비 1.7% 크기. (LÖVE 런타임 + 80MB 자산이 빠졌기 때문도 있음.)
- **2026-07-21**: Python regex로 84개 영웅 1초 변환 — 손 84줄 적을 필요 없음. **Lua → TS 포팅의 가장 큰 효율화**.
- **2026-07-21**: `setCameraPos` 호출 위치 함정 — `Arena.update` 안에서만 호출하면 `Arena.draw` 시점에 카메라가 (0, 0)에 고정. 뱀이 회전만 하고 화면 밖으로 사라지는 증상. **해결**: `drawWorld()` 안에서 명시적 호출. 0.5초 간격 한 줄 디버깅 로그가 "이동 안 함 vs 이동하지만 화면 밖" 구분에 효과적.
- **2026-07-21**: 빌드 산출물 36.80 kB (gzip 10.42 kB)는 놀라울 정도로 작음 — 데이터 + 게임 코어가 모두 TS로 컴파일되어 효율.
