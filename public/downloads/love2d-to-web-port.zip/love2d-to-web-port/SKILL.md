---
name: love2d-to-web-port
description: LÖVE 2D 게임을 HTML5/TypeScript로 포팅하는 워크플로우 — PixiJS(1순위)와 Canvas 2D(2순위) 선택 기준, 5단계 빌드 환경 분류, 단계별 카드 분해 규칙, LÖVE ↔ Web API 매핑표, **30대 함정**(verbatimModuleSyntax, type-only import, local 함수 의존성, UTF-8 byte vs code point iteration, DPR 스케일링, **boot-time Promise.all 자산 로드 트랩**, **shell `| tee` 백그라운드 wrapper trap**, **worker review-required 루프 패턴**, **Vite dev NODE_ENV=development 자동 활성화 트랩**, **작업자 self-revert 안티패턴**, **chain-follower 뱀**, **Vite 5min stuck rule**, **PixiJS v8 `Assets.load(url)` 정석 우선순위**, **snake boundary reflect**, **TDZ ReferenceError in setup/initialize**, **worker auto-decomposition 충돌**, **tint+scale 시각 디버깅**, **원본 LÖVE sprite는 단순하다**), Python+regex 자동 데이터 변환 도구, Vercel 정적 호스팅, Hermes Kanban 카드 분할 패턴. SNKRX(22K LOC, Lua) → snkrx-web(PixiJS v8, 8단계) 실측 (2026-07-23). "LÖVE 게임 HTML5로 만들어줘", "love2d 게임 웹 포팅", "snkrx 웹 포팅", "love.js WebAssembly 빌드" 같은 요청에 발동. 공식 love.js는 deprecated되어 **직접 TypeScript가 정답**이며, 렌더링 라이브러리는 **PixiJS 우선**, Canvas 2D는 단순 데모에만 사용.
version: 0.1.0
author: HyeRin (MiniMax)
license: MIT
metadata:
  hermes:
    tags: [love2d, lua, typescript, canvas2d, web-port, game-fork, snkrx, vite, i18n, ttf-cjk, tsconfig-strict, dpr-scaling, dpr-scale, canvas, game, indie, vercel]
    related_skills: [oss-fork-localization, canvas-static-site-pipeline, love-lua-game-fork, lua-love-game-fork, ad-hoc-verifier]
---

# LÖVE 2D 게임 → HTML5/TypeScript/PixiJS 포팅

> SNKRX(LÖVE 11.5, 22K LOC, Lua) 게임을 TypeScript + Vite + **PixiJS v8**로 포팅한 실전 가이드 (2026-07-23 snkrx-web v0.1.0+, Phase 1~5 50+ commit 완료).
> LÖVE 2D 게임을 **서버 없이 브라우저에서** 실행하고 싶을 때 사용.

## ★ Phase 1~5 실측 결과 (snkrx-web, 2026-07-23~24)

5개 Phase (Phase 1 정지 화면 / Phase 2 뱀 chain-follower + 화면 경계 튕김 / Phase 3 자동 조준 + 투사체 / Phase 4 Wave manager + snake HP + HUD / Phase 5 Camera shake + HitFX + SpawnMarker + 셰이더 5종 + Lv.3 효과 + 사운드 + 슬로우+점수 팝업 + 상점 카드 UI). 50+ commit, github.com/sigco3111/snkrx-web. 248KB built (gzip 73KB).

**결정적 5가지** (실측 기반):
1. **PixiJS v8** (Canvas 2D 아님) — LÖVE의 graphics.* API와 1:1 매핑, 셰이더/파티클/블렌드 모드 이식이 훨씬 간단.
2. **Assets.load(url)** (Texture.from 우회 아님) — PixiJS v8 정석 텍스처 로딩. 디코딩 실패는 캐시에 저장되므로 모듈 스코프 보관이 아닌 `loadOptional` wrapper로 한 텍스처 실패가 부팅 전체를 막지 않게.
3. **Chain-follower 뱀** (단순 history 스냅샷 아님) — 누적 거리 기반 보정. 회전 시 머리 회전 궤적을 따라 자연스러운 곡선으로 추적. spacing 24~32px.
4. **카메라 흔들림 + HitFX + 셰이더 5종** (combine/replace/shadow/full_combine/displacement) — replace.frag 0xff5252 hitFilter tint로 명중 시 적 sprite 빨갛게 + alpha 0.3 깜빡임. vertex shader는 `aPosition` 사용 (LÖVE의 aVertexPosition 아님, PixiJS v8 함정).
5. **사운드는 마지막에** (Web Audio API + 15개 OGG, `?test=1` 자동 활성화 트랩 회피 sentinel) — 작업자가 일관 처리하면 자동 검증 카드 + 알림이 폭주하므로, 자동 검증 완료 + 시각 검증 + 사운드만 사용자 마지막 처리.

## ★ 운영 패턴 (snkrx-web에서 검증된 5가지)

- **시각 검증 카드는 사용자가 직접** (Playwright/chrome-automation 금지) — `chrome-automation` skill이 default toolsets에 있어 작업자가 부주의로 호출하기 쉬움. macOS에서 Playwright Chromium은 20-60분+ stuck. **카드 body에 "Playwright 시각 검증 시도 금지, 자동 검증은 tsc/build/test만, 시각 검증은 사용자가 한다" 명시.** 운영자는 `ps aux | grep t_<taskid>` + CPU 0% + 5분+ stuck 신호로 즉시 kill -TERM + kanban reclaim + 직접 수정 (5분) → kanban complete로 1-2시간 절약.
- **Telegram 알림은 task 단위, 자동 검증 카드 제외** — board 단위가 아니라 `hermes kanban notify-subscribe <task_id>` 로 구독. 시각 검증 + 사운드처럼 사용자가 봐야 할 카드만 구독. 자동 검증 완료 카드는 운영자가 commit + build 검증 후 강제 complete.
- **카드는 작업 단위로 분할, 사람 단위 X** — 1장 큰 카드는 47분+ patch 루프. 5장 분할이 정답. 사용자가 "사운드는 내가 처리"라고 해도 사운드 카드도 미리 만들어둠 (런타임 선택).
- **TscConfig 경고 분석 stuck = 직접 수정** — 18분+ tsconfig 경고 분석에 갇힌 작업자 = 5분+ stuck 신호. 운영자가 `read_file + patch + tsc + build + git commit + kanban complete` 직접 처리.
- **★ 5분 stuck rule** (사용자 명시: "어려운 작업이 아닐꺼데, 너무 오래걸리는 것 같아. 이상없는지 체크해줘") — 단일 파일 fix가 5분+ 걸리면 잘못된 방향 신호. 운영자가 즉시 옵션 A (직접 수정) 또는 B (reclaim + 분할) 선택. 2026-07-23 SNKRX Phase 5-2 사례가 이 패턴의 정석 — 작업자 18분+ tsconfig 분석 stuck → 운영자 kill + 직접 src/main.ts 수정 5분 + commit + 카드 완료로 1-2시간 절약.

## ★ Phase 6+ 추천 (snkrx-web에서)

snkrx-web Phase 5까지 끝난 후 다음 카드는 (Phase 6+):
- **Phase 6: 상점 화면** (영웅 구매, 골드 사용) — buy_screen.lua 이식
- **Phase 7: 게임 종료 + 승리** (Lv.20 trailer, ALL CLEAR)
- **Phase 8: NG+ (다음 사이클)**
- **Phase 9: 폴리싱 + GitHub Release**

각 카드는 Phase 5와 동일하게 작은 단위로 분할 (★ 사람 단위 X, 작업 단위 O). 사운드는 Phase 5-6 카드로 마지막에 작업자가 위임. Phase 6+ 진행 시 `★ Playwright 금지` + `Telegram 알림 자동 검증 카드 제외` + `★ 5분 stuck rule` + `★ 카드는 작업 단위 분할` 4가지 규칙을 모든 카드 body에 기본 포함.

## ★ 칸반 위임 에이전트 비교 (snkrx-web 운영 평가, 2026-07-24)

위임 카드를 처리할 에이전트 선택 (5개 후보):

| 에이전트 | CLI | 강점 | 단점 |
|---|---|---|---|
| Claude Code 2.1.181 | `claude` | 가장 안정, SWE-bench 검증 | subagent/plan-yolo 없음 |
| OpenAI Codex CLI 0.144.0 | `codex` | 빠름, 단순 `codex exec` | 컨텍스트 작음, ulw 없음 |
| OpenCode 1.18.4 | `opencode` | 무료 모델 100+, TUI + `pr <number>` | ulw 없음, 한국어 보통 |
| oh-my-pi 17.1.0 | `omp` | hash-anchored edits, `--prewalk`/`--plan-yolo` (ulw-유사), subagent, LSP | npm 설치 필요 |
| gajae-code 0.10.1 | `gjc` (npm) | 한국 개발자, 내장 Telegram daemon, npm | 베타 |

**`ulw` (Unlimited Work Loop) 4개 모두 표준 모드 없음** — `omp`의 `--plan-yolo`가 같은 효과 (plan → 자동 승인 → smol model 실행).

**snkrx-web 추천**: **`omp` 1순위** (hash-anchored + plan-yolo + subagent + LSP), **`claude` 폴백** (안정성), **`gjc` 보조** (Telegram 자동 알림). `opencode`는 무료 모델 다수라 비용 절감 가능.

## ★ PixiJS 부팅이 안 될 때 최우선 행동 (2026-07-23 세션 후반 확정)

작업자가 PixiJS 부팅에서 빈 화면 / placeholder / 캐시 실패 / silent GC로 막혔을 때, **5단계 우회(`Texture.from(canvas)` → `Image` → `ImageData` → cache-bust → unload/reload)를 순서대로 시도하면서 시간을 낭비하지 말 것**. 우선:

1. **공식 PixiJS 스킬 설치** — `hermes skills install --force pixijs/pixijs-skills/pixijs-assets`. [CRITICAL] 섹션이 "Texture.from() only reads the cache. It does not fetch from a URL" 명시. 이걸 먼저 봤으면 4단계 우회를 안 해도 됐음.
2. **`Assets.load(url)`로 변경** — PixiJS v8 정석 텍스처 로딩 경로. fetch + Image 디코딩 + GPU 업로드 + 캐시 모두 자동.
3. 그래도 안 되면 그때 `loadOptional` + Graphics fallback 패턴 적용.

> 세션 후반까지 4번의 우회 시도가 있었지만, 사실 정답은 `Assets.load(url)` 한 줄이었고, 이걸 알기 위해 필요한 정보는 `pixijs-assets` 스킬의 [CRITICAL] 섹션에 이미 있었습니다. **부팅 안 될 때 PixiJS 우회 시도 전에 공식 스킬 설치를 먼저.**

- **★ 사용자 위임 패턴 (2026-07-23 명시)**: 사용자가 "나머지는 위임할께"라고 하면 — **위임할 모든 카드를 미리 생성하고 의존성 체인으로 연결**. 사용자가 직접 처리하려던 카드(예: 사운드)도 **카드로 만들어둠**. 카드 구조 자체가 작업 명세서이고, "사용자가 한다 / 작업자가 한다"는 런타임 선택. 사용자가 "사운드는 내가 처리"라고 했어도 카드만 만들고, 사용자가 원하면 작업자에게 위임하거나 직접 처리. **즉시 모든 카드를 등록하는 이유는**: (1) 의존성 그래프가 한 번에 보여서 작업 흐름이 명확, (2) 작업자가 자동으로 다음 카드를 dispatch, (3) 사용자가 직접 처리할 카드는 unblock/complete 액션으로 명시적으로 표시. **카드 분할은 작업 단위**, 사람 단위가 아님.
- **"혹시 쓸만한 픽셀js 스킬이 있다면 설치후 진행해줘"** — 사용자는 **blind fix 시도 전에 skill hub에 관련 스킬이 있는지 확인하고 설치**하라고 명시적으로 요청. 일반화: **부팅 실패 / 자산 로드 실패 / 무언가 안 될 때, 첫 번째 행동은 `hermes skills search <keyword>` + `hermes skills install`로 공식/커뮤니티 스킬 확인**. 스킬의 [CRITICAL] 섹션에 정답이 이미 있을 가능성을 항상 고려.

## 사용 시기

- LÖVE 2D 게임을 **브라우저에서** 플레이 가능하게 만들고 싶을 때
- "Vercel에 deploy해줘" / "웹으로 만들어줘" / "HTML5 버전 만들어줘" 류 요청
- LÖVE는 **공식 웹 빌드 없음** (love2d/love는 11.5에서 web release 중단)
- **love.js (Davidobot/love.js)** 같은 커뮤니티 프로젝트는 deprecated

## 렌더링 라이브러리 선택 (★ 가장 중요한 첫 결정)

| 상황 | 1순위 | 2순위 |
|---|---|---|
| 화면 객체 > 30, 파티클, 셰이더, 다층 렌더 | **PixiJS v8** | Three.js (WebGL 직접) |
| 단순 데모, 게임 로직 자체가 주 목적 | Canvas 2D | PixiJS |
| LÖVE 셰이더(GLSL)를 그대로 옮김 | PixiJS (Filter) | Canvas 2D + 직접 GLSL |
| 3D 효과 필요 | Three.js | — |

**PixiJS를 1순위로 권장하는 이유** (v0.1 SNKRX 사용자 결정, 2026-07-23):
- LÖVE의 `love.graphics.*` API와 1:1 매핑 (Sprite ↔ Image, Container ↔ love Group, Filter ↔ love Shader)
- WebGL/WebGPU 자동 fallback → GPU 가속 무료
- 파티클·스프라이트·DPR·블렌드 모드 자동 관리
- GLSL 셰이더를 PixiJS Filter로 1:1 이식 가능 (LÖVE → PixiJS 셰이더 변환은 `templates/loveshader-to-pixi-filter.ts` 참조)
- Canvas 2D는 LÖVE 60fps를 따라가려면 Object pool + offscreen canvas를 직접 다 구현해야 함

**Canvas 2D를 쓰는 경우**: SNKRX처럼 화면에 영웅/적/탄환/파티클이 동시에 수십 개씩 뜨고 셰이더와 픽셀아트가 섞여 있는 게임에서는 부적합. 정말로 단순한 게임이나 프로토타입에서만.

## LÖVE → Web의 근본적 차이

| LÖVE | Web |
|---|---|
| Lua 5.3 / LuaJIT | TypeScript / JavaScript |
| `love.graphics.*` | PixiJS v8 (Sprite, Container, Graphics, Filter) 또는 Canvas 2D |
| `love.window.setMode()` | PixiJS `Application.init({width, height})` + DPR |
| `love.run` 메인 루프 | PixiJS `app.ticker.add()` |
| `love.filesystem.read()` | `fetch()` |
| `love.event.push()` (input) | `addEventListener('keydown')` |
| `dt` (delta time, 자동) | `ticker.deltaMS / 1000` (PixiJS) 또는 `performance.now()` diff |
| `love.image.newImage(path)` | `Assets.load<Texture>(path)` (PixiJS) / `new Image()` |
| `love.graphics.push()/pop()` | PixiJS Container 부모-자식 계층 / Canvas 2D `save()/restore()` |

**LÖVE 게임 데이터 (영웅/적/스킬 테이블) — 거의 그대로 재사용 가능** (Lua → TypeScript 데이터 마이그레이션, 로직만 다시 작성)

## 8단계 워크플로우 (snkrx-web v0.1.0+ 실측, PixiJS)

> **⚠️ 이전 v0.1 (Canvas 2D, 2026-07-21) — 폐기 이유**: snkrx-web 8단계 (스캐폴딩/애셋/데이터/한글화/렌더/코어/상점/통합) 모두 끝까지 갔지만 사용자 GUI 테스트에서 **뱀 이동 안 됨 / 회전만 됨 / 적 안 보임** 증상이 최종 단계에서 발견됨. 다수 버그 (keyup 핸들러 / invulnerable 음수 / 자동타겟 / 카메라 위치 / 적 좌표 NaN) 수정 시도했으나 게임플레이 정상 동작까지 도달 못 함. 사용자가 **"품질이 너무 떨어져서 안되겠어. 프로젝트를 제거하자"** 라고 결정 → `/Users/mac/work/snkrx-web` 폴더 + 모든 진행 폐기. snkrx-clone (LÖVE 네이티브) Release v0.1.12만 유지.

> **v0.1.0+ 재시작 (2026-07-23, PixiJS + Kanban)**: 이전 실패 원인 분석 후 **렌더링 라이브러리 변경 + 단계별 카드 분해 + 사용자 시각 검증 게이트** 3가지로 재구성.

> **⚠️ v0.1.1 ~ v0.2 작업 흐름 — 폐기 이유 (2026-07-21)**: snkrx-web 8단계 (스캐폴딩/애셋/데이터/한글화/렌더/코어/상점/통합) 모두 끝까지 갔지만 사용자 GUI 테스트에서 **뱀 이동 안 됨 / 회전만 됨 / 적 안 보임**이 증상이 최종 단계에서 발견됨. 다수 버그 (keyup 핸들러 / invulnerable 음수 / 자동타겟 / 카메라 위치 / 적 좌표 NaN) 수정 시도했으나 게임플레이 정상 동작까지 도달 못 함. 사용자가 **"품질이 너무 떨어져서 안되겠어. 프로젝트를 제거하자"** 라고 결정 → `/Users/mac/work/snkrx-web` 폴더 + 모든 진행 폐기. snkrx-clone (LÖVE 네이티브) Release v0.1.12만 유지.

**즉시 적용 규칙 — LÖVE → Web 풀 게임 포팅 시작 전 확인**:
- 5단계 빌드 환경 분류 (HTML5 Canvas/TS는 🟢 즉시 성공) 그대로 적용
- **단, 클래스-레벨 게임의 "8단계 풀 게임 포팅"은 단일 세션에 강제하지 말 것** (위 폐기 사례처럼 매번 디버깅에 갇힘)
- **게임 코어 (Entity / 뱀 / 상점) 작업 전 1차 sanity check 필수**:
  - 빈 Canvas에 사각형 1개 그려서 60fps 유지되는지 확인 → 안 되면 1차 sanity 실패, 더 진행 안 함
  - 1단계 빌드 + PixiJS + Vite만 통과 후 사용자에게 "다음 단계 진행할까요?" 확인
- 1차 sanity 통과 시점마다 commit + 사용자에게 "지금까지 잘 작동합니다, 다음 단계 진행할까요?" 확인
- **8단계 모두 자동 진행 = 실패 패턴**. 1-2단계씩 사용자 확인 받으면서 누적 빌드
- 사용자가 게임플레이 정상 동작 확인 전까지는 "빌드 성공"이라고 보고 금지 (단순 dev 서버 + npm run build 성공 ≠ 게임플레이 성공)
- **v0.1 / v0.2 / v0.3 같은 단계명 사용 시 "정식 v0.X 출시"라는 인상 전달 금지** — 사용자 GUI 검증 + 게임플레이 확인 후에만 정식 v0.X. 그 전까지는 v0.1-dev / v0.2-dev 또는 "통합 빌드 (검증 미완)"

### Hermes Kanban으로 작업할 때 — 카드 분해 규칙 (★ 2026-07-23 핵심 교훈)

**풀 게임 한 장 카드는 실패 패턴**. 이전 v0.1.12 세션에서 "정지 전투 장면 재현" 카드를 한 장으로 만들었더니 1시간 넘게 16+ 회 patch 반복 후 `npm run dev | tee ... &` 백그라운드 wrapper에 갇혀 끝나지 않았음. **해결**: 한 카드를 다음 4-5장 단위로 분해.

```text
정지 전투 장면 1장 (실패 패턴)
  → 1) 좌표·코어 데이터 (constants 모듈)
  → 2) 빌드 가능한 화면 골격 (mountStaticBattleScene placeholder)
  → 3) 뱀(snake) 본체 + 영웅 위치
  → 4) 적 + 투사체 + HP바 + 파티클
  → 5) UI 골격 + 비교 diff 메모
```

각 카드마다:
- **변경 허용 파일** 명시
- **완료 조건** 명시 (테스트 개수 + npm run build + 시각 검증 여부)
- **하지 말아야 할 것** 명시 (예: "셰이더 작업 금지", "다른 시스템 의존 금지")
- 작업자가 review-required로 멈추면 Hermes 운영자가 검증 후 재개
- 시각 검증 카드만 사용자 알림 (Telegram 등) 발송

### 작업자가 review-required로 멈추는 패턴과 처리

모든 자동 검증 카드의 작업자가 마지막에 `kanban_block(reason='review-required: ...')`로 정지함. 이는 정상 동작이지만 **작업자 보고를 그대로 믿으면 안 됨**. Hermes 운영자 검증 단계:

```text
1. git log -3 --oneline으로 실제 commit 확인
2. git show --stat HEAD로 변경 파일 검증
3. npm run build (또는 npm test) 직접 재실행
4. dev server 띄워서 curl /assets/images/X.png HTTP 200 확인
5. 모든 통과 시 kanban complete로 강제 종료 + 다음 카드 dispatch
6. 통과 못 하면 kanban reclaim + 분해된 더 작은 카드로 재할당
```

**★ 작업자가 review-required로 멈춘 후 검증에서 실제로 화면이 안 그려진 사례 (2026-07-23)**: 코드 변경은 정상, 빌드 통과, HTTP 200 OK, **그러나 사용자가 브라우저에서 "이 상태에서 안넘어감" + PixiJS 초기화 중 텍스트만 보임 증상 → boot-time Promise.all 트랩이 진짜 원인**.

### boot-time Promise.all 자산 로드 트랩 (★ v0.1.0 PixiJS 실측, 가장 자주 만남)

```ts
// ❌ WRONG — 한 텍스처라도 로드 실패하면 boot()이 throw하고 캔버스 안 그려짐
await Promise.all([
  Assets.load<Texture>('/assets/images/warrior.png'),
  Assets.load<Texture>('/assets/images/speed_booster_elite.png'),
])
addBattleDemo(app, playerTexture, enemyTexture)  // ← throw로 여기 도달 못 함
```

**증상**: 사용자가 본 화면 — 가운데 정사각형만 보이거나 "PixiJS 초기화 중..." 텍스트만 남음. 작업자가 "build 통과 + HTTP 200 + npm run build OK"라고 보고하지만 브라우저에는 게임 요소가 1개만 그려지거나 0개.

```ts
// ✅ CORRECT — loadOptional wrapper + Sprite/Graphics fallback
async function loadOptional(url: string): Promise<Texture | null> {
  try { return await Assets.load<Texture>(url) }
  catch (e) { console.warn(`[snkrx] 텍스처 로드 실패 (${url}):`, e); return null }
}

const textures = {
  player: await loadOptional('/assets/images/warrior.png'),
  enemy: await loadOptional('/assets/images/speed_booster_elite.png'),
}
addBattleDemo(app, textures)  // 항상 실행됨

function addBattleDemo(app: Application, textures: LoadedTextures): void {
  if (textures.player) {
    const player = new Sprite(textures.player)
    player.width = 24; player.height = 36
    /* ... */
    app.stage.addChild(player)
  } else {
    const placeholder = new Graphics()
    placeholder.rect(0, 0, 24, 36).fill(0xe53935)  // 빨간 박스 fallback
    /* ... */
    app.stage.addChild(placeholder)
  }
  // enemy도 동일 패턴
}
```

**규칙**: PixiJS/Canvas 2D 부팅 시 모든 자산 로드는 `loadOptional`로 감싸고, 로드 결과가 null이어도 화면은 무조건 그린다. **빌드 성공 ≠ 부팅 성공 ≠ 화면 표시**.

### LÖVE → PixiJS 단계별 차이

| LÖVE | PixiJS v8 |
|---|---|
| `love.graphics.rectangle(...)` | `new Graphics().rect(x, y, w, h).fill(color)` |
| `love.graphics.circle(...)` | `new Graphics().circle(x, y, r).fill(color)` |
| `love.graphics.print(text, x, y)` | `new Text({text, style: {fontFamily, fontSize, fill}})` |
| `love.image.newImageData` | `Texture.from()` 또는 `Assets.load()` |
| `love.image.newImage(path)` | `Assets.load<Texture>(path)` |
| `love.graphics.push()/pop()` | Container 부모-자식 (`stage.addChild`, `container.addChild`) |
| `love.graphics.translate(x, y)` | `container.position.set(x, y)` 또는 `container.x = x` |
| `love.graphics.rotate(angle)` | `container.rotation = angle` |
| `love.graphics.scale(sx, sy)` | `container.scale.set(sx, sy)` |
| `love.graphics.setColor(r,g,b,a)` | `sprite.tint = 0xRRGGBB`, `sprite.alpha = a` |
| `love.graphics.setBlendMode(mode)` | `sprite.blendMode = 'add' | 'multiply' | ...` |
| `love.graphics.draw(layer)` | `sprite.blendMode = 'add'`, Z-order는 `setChildIndex()` |
| `love.shader.send(name, value)` | `filter.resources.uniforms.uniformName = { value, type: 'f32' }` |
| `Camera:update()` | 부모 Container position으로 추적 + `setChildIndex` Z-order |
| `love.mousepressed(x, y)` | `stage.on('pointerdown', ...)` 또는 `app.renderer.events` |

### 1단계: 프로젝트 스캐폴딩

```bash
mkdir -p /Users/mac/work/snkrx-web
cd /Users/mac/work/snkrx-web
npx --yes create-vite@latest snkrx-web --template vanilla-ts
# TypeScript 5 + Vite 6/7/8 보일러플레이트 자동 생성

# tsconfig.json 완화 (verbatimModuleSyntax + noUnusedLocals 끄기)
# → 세션 4단계에서 type-only import 에러 5종으로 막힘, 결국 비활성화
```

**tsconfig 표준 (★ web 프로젝트 공통)**:
```json
{
  "compilerOptions": {
    "target": "es2023",
    "module": "esnext",
    "lib": ["ES2023", "DOM"],
    "types": ["vite/client"],
    "allowArbitraryExtensions": true,
    "skipLibCheck": true,
    "moduleResolution": "bundler",
    "allowImportingTsExtensions": true,
    "moduleDetection": "force",
    "noEmit": true,
    "noFallthroughCasesInSwitch": true
  },
  "include": ["src"]
}
```

**주요 비활성화 옵션**:
- `verbatimModuleSyntax: false` — type-only import `import type { ... }` 강제 안 함
- `noUnusedLocals: false` — 미사용 변수/import 무시
- `noUnusedParameters: false` — 미사용 매개변수 무시
- `erasableSyntaxOnly: false` — enum/namespace 등 사용 가능
- 이유: 단계별 빠른 프로토타이핑. 엄격한 lint는 v0.5+에서.

### 2단계: 애셋 (스프라이트/사운드) 복사

```bash
# 원본 LÖVE 게임 assets/ 그대로 복사 (png/ogg 그대로 사용)
cp -r /Users/mac/work/snkrx-clone/assets /Users/mac/work/snkrx-web/public/
# Canvas 2D는 Image 객체로 자동 처리됨
# 사운드는 HTMLAudioElement 또는 Web Audio API
```

**왜 png 그대로 사용**: Canvas 2D의 `drawImage()`는 어떤 포맷이든 그대로 그림. **WebP 변환은 progressive enhancement일 뿐 필수 X**. SNKRX 60+개 PNG + 30+ OGG = ~60MB 그대로.

### 3단계: 데이터 마이그레이션 (Lua → TypeScript)

**가장 가치 있는 단계** — LÖVE 게임의 **데이터 테이블** (영웅, 적, 스킬, 클래스, 패시브)은 거의 로직 없는 dict-of-dict. TypeScript로 거의 그대로 옮김.

**원본 Lua** (main.lua):
```lua
character_names = {
  ['vagrant'] = 'Vagrant',
  ['swordsman'] = 'Swordsman',
  ['wizard'] = 'Wizard',
  -- ... 84 entries
}
```

**TypeScript** (data/heroes.ts):
```ts
export interface HeroDef {
  key: string;
  name: string;             // 영문 (ko.json으로 번역)
  tier: 1 | 2 | 3 | 4 | 5;
  classes: HeroClass[];
  color: string;
  stats: { hp: number; dmg: number; /* ... */ };
}

export const HEROES: HeroDef[] = [
  { key: 'vagrant', name: 'Vagrant', tier: 1, classes: ['explorer', 'psyker'],
    color: 'fg', stats: { hp: 20, dmg: 7, /* ... */ } },
  // ... 84 entries
];
```

**대량 자동 변환 (★ 100+ 항목 권장)**: Python + regex:
```python
# main.lua 읽기 → character_names 블록 추출 → Python dict로 파싱 → TS 배열로 emit
import re
content = open('main.lua').read()
# ['key'] = 'value' 패턴 매칭
entries = re.findall(r"\['(\w+)'\] = '([^']+)'", content)
ts_lines = [f"  {{ key: '{k}', name: '{v}' }}," for k, v in entries]
print('export const HEROES = [' + '\n'.join(ts_lines) + '];')
```

**결과물**: 84개 영웅을 1초 안에 생성. 손으로 84줄 적을 필요 없음.

**게임 로직 함수 테이블** (예: `passive_descriptions_level`): **TS에서 함수로 그대로 옮김**:
```ts
// 원본 Lua: function(lvl) return '[' .. ylb1(lvl) .. ']8%' end
// TS:
const ylb1 = (lvl: number) => lvl >= 3 ? 'light_bg' : lvl === 2 ? 'yellow' : 'light_bg';

export const passiveDescriptions: Record<string, (lvl: number) => string> = {
  // ...
};
```

**Local 함수 의존성 함정 (★ 가장 자주 만남)**: Lua의 `local ylb1 = function(lvl) ...`은 모듈 스코프. ko.lua 같은 별도 파일에서 접근 불가. **해결**: ko.lua 자체에 helper 복제 또는 `_G.ylb1 = local_var`로 global 노출. SNKRX 5개 모듈 파일에 helper 복제 패턴 (LÖVE → TS 변환 시 동일 패턴 — 모듈 최상단에 helper 함수 export).

### 4단계: 한글화 통합 (★ 모드팩 패턴)

**가장 가치 있는 산출물**: `ko.json` (한글화 사전) + `i18n.ts` (T() 함수).

```ts
// i18n/i18n.ts
export const lang = {
  current: 'ko' as 'ko' | 'en',
  fallback: 'en' as 'ko' | 'en',
  dicts: {} as Record<string, Record<string, string>>,
};

export function T(key: string, defaultText?: string): string {
  const dict = lang.dicts[lang.current] || {};
  const fb = lang.dicts[lang.fallback] || {};
  if (dict[key] !== undefined) return dict[key];
  if (fb[key] !== undefined) return fb[key];
  return defaultText ?? key;
}
```

**번역 데이터** (213+ 키):
```json
{
  "arena_run": "아레나 런",
  "options": "옵션",
  "vagrant": "부랑자",
  "swordsman": "검사",
  "restart_run": "런 재시작"
  // ...
}
```

**모드팩 패턴 (★ LÖVE와 동일한 아키텍처 결정)**: `lang` dict는 `lang.current = 'en'` 한 줄 변경으로 전체 UI 영어로 복귀. 새 언어 (ja/zh) 추가도 `lang/ja.json` + `lang.current = 'ja'`만.

**자동 매핑 (84+ 패시브)**:
```python
translations = {
  'movement speed': '이동속도',
  'attack speed': '공격속도',
  # 100+ entries
}
# longest-first 매칭: sorted by key length descending
# → 'movement speed' 먼저 매칭, 'movement' 단독은 뒤에
```

### 5단계: 렌더링 엔진 (Canvas 2D)

**핵심 결정**: **WebGL X → Canvas 2D O**. LÖVE의 2D 렌더링은 WebGL의 90%만 필요. Canvas 2D가 단순하고 디버깅 쉬움.

**모듈 구조**:
```
src/render/
├── canvas.ts       # Canvas 2D 컨텍스트 + pushState/popState (LÖVE의 graphics.push/pop)
├── camera.ts       # 화면 추적 + 흔들림 + 줌 (LÖVE의 Camera)
├── sprite.ts       # 스프라이트 시트 로더 (Promise 캐싱)
├── particles.ts    # 파티클 시스템 (LÖVE의 HitParticle, SpawnEffect)
├── effects.ts      # 슬로우 모션 + 화면 흔들림 (LÖVE의 slow_amount)
├── text.ts         # 픽셀 폰트 (LÖVE의 Text + [color] 태그)
├── engine.ts       # 메인 루프 (requestAnimationFrame)
└── index.ts
```

**LÖVE → Canvas 2D 직접 매핑**:
| LÖVE | Canvas 2D |
|---|---|
| `graphics.rectangle(x, y, w, h, color)` | `ctx.fillRect(x - w/2, y - h/2, w, h)` |
| `graphics.circle(x, y, r, color)` | `ctx.arc(x, y, r, 0, Math.PI * 2)` |
| `graphics.line(x1, y1, x2, y2)` | `ctx.beginPath(); ctx.moveTo/lineTo; stroke()` |
| `graphics.print(text, font, x, y)` | `ctx.fillText(text, x, y)` |
| `graphics.push()` / `pop()` | `ctx.save()` / `restore()` |
| `love.image.newImage(path)` | `new Image(); img.src = path` |
| `Camera:update()` | `setCameraPos/zoom()` + `applyCameraTransform()` |

**text.ts의 [color] 태그 파싱** (LÖVE의 `Text:format_text` 모방):
```ts
// LÖVE: "[yellow]텍스트[fg]텍스트" 같은 태그 파싱
// Canvas 2D: 동일
export function parseText(raw: string): TextSegment[] {
  const segments: TextSegment[] = [];
  let current = { text: '', color: '#dadada' };
  for (let i = 0; i < raw.length; i++) {
    if (raw[i] === '[') {
      if (current.text) segments.push(current);
      const end = raw.indexOf(']', i);
      const tag = raw.substring(i + 1, end);
      if (COLOR_MAP[tag]) current = { text: '', color: COLOR_MAP[tag] };
      i = end;
    } else {
      current.text += raw[i];
    }
  }
  segments.push(current);
  return segments;
}
```

### 6단계: 게임 코어 (Entity-Component)

**LÖVE의 GameObject + Physics 패턴 → TS 클래스**:
```ts
abstract class Entity {
  x: number = 0; y: number = 0;
  vx: number = 0; vy: number = 0;
  hp: number = 10; maxHp: number = 10;
  r: number = 8;  // 충돌 반경
  dead: boolean = false;
  abstract update(dt: number): void;
  abstract draw(ctx: CanvasRenderingContext2D): void;
}
```

**충돌 검사 (n^2 — 적은 수에서 OK)**:
```ts
export function checkCollisions(): CollisionPair[] {
  const pairs: CollisionPair[] = [];
  for (let i = 0; i < all.length; i++) {
    for (let j = i + 1; j < all.length; j++) {
      if (a.collidesWith(b)) pairs.push({ a, b });
    }
  }
  return pairs;
}
```

**스네이크 (Player 본체) — LÖVE의 Player와 동일한 history 기반 패턴**:
```ts
export class Player {
  history: { x: number; y: number }[] = [];
  updateUnits() {
    for (let i = 0; i < this.units.length; i++) {
      const targetIdx = (i + 1) * spacing / historySpacing;
      const h = this.history[length - 1 - targetIdx];
      this.units[i].x = h.x;
      this.units[i].y = h.y;
    }
  }
}
```

### 7단계: 상점 시스템 + 아레나

**상점 (BuyScreen 모방)**: `Shop` 클래스에 `slots`, `shopLevel`, `buy/sell/merge/reroll` 메서드.

**아레나 (Arena)**: `Arena` 클래스에 `player`, `wave`, `loop`, `shopLevel`, `update`, `draw`, `handleCollisions` 메서드.

**충돌 처리 (LÖVE의 Projectile+Enemy 충돌)**:
```ts
if (proj.ownerKind === 'unit' && other.kind === 'enemy') {
  other.hit(proj.dmg);
  proj.onHit();
  emitHit(other.x, other.y, '#e91d39', 4);
}
```

### 8단계: 데모 통합 + 빌드 + Vercel

```bash
# main.ts — 데모 진입점
import { startEngine } from './render/engine';
const canvas = document.getElementById('game') as HTMLCanvasElement;
startEngine(canvas, { onUpdate, onDrawWorld, onDrawUI });

# 빌드
npm run build
# → dist/ 폴더에 번들

# Vercel 배포
vercel deploy --prod --yes --token $(cat ~/.hermes/secrets/vercel_token.txt)
```

**index.html 표준 (DPR-aware Canvas)**:
```html
<canvas id="game" width="1280" height="720"></canvas>
<style>
  body { margin: 0; background: #1a1a1a; }
  #game { image-rendering: pixelated; cursor: crosshair; }
</style>
```

**★ `setCameraPos` 호출 위치 함정 (v0.1.12 snkrx-web 실측)**: LÖVE의 Camera는 매 프레임 자동 추적. Canvas 2D는 **명시적 호출 필요** + **호출 위치 = drawWorld 안**. 
- `Arena.update` 안에서 `setCameraPos` 호출하면 update는 카메라 상태를 바꾸지만, `Arena.draw`가 호출되기 전에 `applyCameraTransform`이 먼저 실행되어 transform에 반영. 그러나 update의 `Arena.draw` 호출이 빠지면 카메라가 (0, 0)에 고정. **증상**: 뱀이 회전만 하고 화면 밖으로 사라짐. headX/Y는 계속 증가하지만 카메라가 따라가지 않음. **해결**: `drawWorld()` 안에서 `setCameraPos(player.headX, player.headY)` 명시적 호출.

```ts
// ❌ WRONG — update에서 setCameraPos만 호출, draw에서 누락
function update(dt) {
  arena.update(dt);  // setCameraPos inside
}
function drawWorld() {
  arena.draw(ctx);  // 카메라 transform은 engine.ts에 고정된 (0, 0)
}

// ✅ CORRECT — draw에서 명시적 호출
function update(dt) {
  arena.update(dt);
}
function drawWorld() {
  setCameraPos(arena.player.headX, arena.player.headY);
  arena.draw(ctx);
}
```

**디버깅 패턴 (★ 효과적)**: 0.5초 간격 한 줄 로그. 화면 안 보일 때 headX/Y 변화 여부로 "이동 안 함 vs 이동하지만 화면 밖" 구분 가능.
```ts
if (Math.floor(performance.now() / 500) !== this._lastLog) {
  this._lastLog = Math.floor(performance.now() / 500);
  console.log(`[Player] head=(${this.headX.toFixed(1)}, ${this.headY.toFixed(1)}) angle=${(this.angle * 180 / Math.PI).toFixed(0)}° speed=${this.speed} dt=${dt.toFixed(4)} units=${this.units.length} enemies=${enemies.filter(e => !e.dead).length}`);
}
```
- headX/Y가 변함 + enemies > 0 → 이동은 함, 카메라가 문제 (setCameraPos 위치 확인)
- headX/Y가 변하지 않음 + enemies > 0 → update 또는 dt 문제
- headX/Y가 거의 0 → 초기 상태 또는 speed 문제

## LÖVE → TypeScript 포팅 시 9대 함정

### 함정 -0.5: Vite dev server의 NODE_ENV=development 자동 활성화 트랩 (★ 2026-07-23 후반 발견, runtime bug)

PixiJS 부팅 시 `?test=1` URL 쿼리로 테스트 모드를 활성화하는 패턴이 있음. `isTestMode(search, nodeEnv)` 함수가 `nodeEnv === 'development'`를 체크하는데, **Vite dev server는 `import.meta.env.NODE_ENV`가 자동으로 `'development'`로 설정**됨. 결과: 사용자가 `?test=1`을 안 붙여도 test mode가 자동 활성화되어 `cooldown = Infinity` (projectile OFF)가 됨. **사용자가 "일반모드: 투사체가 발사되지 않음"이라고 보고해서 발견.**

**증상 — 진단이 특히 어려운 이유**:
- 일반 모드(`?test=1` 없이)인데 console에 `[snkrx] BOOT test mode enabled: true`가 보임
- 코드/커밋은 정상, 빌드 통과, HTTP 200
- 사용자가 직접 브라우저에서 reload해야 알 수 있음
- 카드 body의 "test mode 적용" 작업이 main에 push된 직후 발생

**해결 — sentinel 문자열 사용**:

```typescript
// ❌ WRONG — Vite dev의 import.meta.env.NODE_ENV='development'로 자동 매치
const RUNTIME_NODE_ENV = import.meta.env.NODE_ENV
  ?? (import.meta.env.DEV ? 'development' : import.meta.env.MODE)
const TEST_MODE = isTestMode(window.location.search, RUNTIME_NODE_ENV)
// 결과: Vite dev에서는 항상 TEST_MODE=true

// ✅ CORRECT — Vite dev에서 자동 매칭 안 되는 sentinel 사용
const RUNTIME_NODE_ENV = import.meta.env.NODE_ENV
  ?? (import.meta.env.DEV ? 'production-dev' : import.meta.env.MODE)
const TEST_MODE = isTestMode(window.location.search, RUNTIME_NODE_ENV)
// 결과: Vite dev에서는 'production-dev' → TEST_MODE=false (URL 쿼리로만 켜짐)
```

**규칙**: Vite dev mode에서 `?test=1` URL 쿼리로만 활성화하고 싶다면, `import.meta.env.NODE_ENV`이 `'development'`인지 검사하는 코드를 작성하지 말 것. 대신 `import.meta.env.DEV` boolean 또는 사용자 정의 sentinel을 사용. `import.meta.env.MODE`도 dev에서는 `'development'`로 설정되니 회피.

**자동 감지 패턴**:
```bash
# 일반 모드 콘솔에 BOOT test mode 메시지가 보이면 이 버그
grep -n "isTestMode\|RUNTIME_NODE_ENV" src/main.ts
```

### 함정 -0.4: 작업자 self-revert 안티패턴 (★ 2026-07-23 실측, 카드 구조 문제)

작업자가 **같은 카드 안에서 `commit A` + `commit B revert`**로 끝내는 패턴. 결과: 카드는 `done`이지만 `git log`에 두 commit이 짧은 시간(수 분) 안에 revert 관계로 등장하고, 사용자가 변화 없음을 보고. 예: 카드 "테스트 모드 적용" → `commit 915beed feat: test mode` + `commit 6a98d65 revert: test mode 제거`로 끝남. 카드 상태는 done이지만 `?test=1` URL로 들어가도 변화 없음.

**방지 패턴** (★ 카드 body에 직접 명시):
```
(중요: 이 카드는 revert 금지. 사용자가 OK 할 때까지 test mode 유지.)
```

**더 안전한 분리** (★ 권장):
- 카드 1: "테스트 모드 적용" (원본 보존, commit 1개)
- 카드 2: "테스트 모드 해제 + 원본 복구" (사용자가 OK 후 별도 카드, commit 1개)

→ 작업자가 같은 카드 내에서 revert 안티패턴 방지. 각 카드는 명확한 단일 책임.

**감지**: `git log --since="1 hour ago"`에서 같은 author + 같은 영역 코드가 add → remove → add 패턴으로 30분 안에 등장하면 안티패턴.

### 함정 -0.4: 작업자 self-revert 안티패턴 (★ 2026-07-23 실측, 카드 구조 문제)

작업자가 **같은 카드 안에서 `commit A` + `commit B revert`**로 끝내는 패턴. 결과: 카드는 `done`이지만 `git log`에 두 commit이 짧은 시간(수 분) 안에 revert 관계로 등장하고, 사용자가 변화 없음을 보고. 예: 카드 "테스트 모드 적용" → `commit 915beed feat: test mode` + `commit 6a98d65 revert: test mode 제거`로 끝남. 카드 상태는 done이지만 `?test=1` URL로 들어가도 변화 없음.

**방지 패턴 (★ 카드 body에 직접 명시)**:
```
(중요: 이 카드는 revert 금지. 사용자가 OK 할 때까지 test mode 유지.)
```

**더 안전한 분리** (★ 권장):
- 카드 1: "테스트 모드 적용" (원본 보존, commit 1개)
- 카드 2: "테스트 모드 해제 + 원본 복구" (사용자 OK 후 별도 카드, commit 1개)

→ 작업자가 같은 카드 내에서 revert 안티패턴 방지. 각 카드는 명확한 단일 책임.

**감지**: `git log --since="1 hour ago"`에서 같은 author + 같은 영역 코드가 add → remove → add 패턴으로 30분 안에 등장하면 안티패턴.

**작업자 patch-loop, Playwright stuck, decompose 충돌, 직접 수정 rescue 메뉴**: [`references/worker-rescue-menu.md`](references/worker-rescue-menu.md) 참조. 5분 stuck rule + 3-tier rescue (직접 수정 / reclaim+분할 / reassign) + Playwright 명시 금지 + `| tee &` trap 회피 + worker self-revert 방지 패턴.

### 함정 -0.5: Vite dev server의 NODE_ENV=development 자동 활성화 트랩 (★ 2026-07-23 후반 발견, runtime bug)

PixiJS 부팅 시 `?test=1` URL 쿼리로 테스트 모드를 활성화하는 패턴이 있음. `isTestMode(search, nodeEnv)` 함수가 `nodeEnv === 'development'`를 체크하는데, **Vite dev server는 `import.meta.env.NODE_ENV`가 자동으로 `'development'`로 설정**됨. 결과: 사용자가 `?test=1`을 안 붙여도 test mode가 자동 활성화되어 `cooldown = Infinity` (projectile OFF)가 됨. **사용자가 "일반모드: 투사체가 발사되지 않음"이라고 보고해서 발견.**

**증상 — 진단이 특히 어려운 이유**:
- 일반 모드(`?test=1` 없이)인데 console에 `[snkrx] BOOT test mode enabled: true`가 보임
- 코드/커밋은 정상, 빌드 통과, HTTP 200
- 사용자가 직접 브라우저에서 reload해야 알 수 있음
- 카드 body의 "test mode 적용" 작업이 main에 push된 직후 발생

**해결 — sentinel 문자열 사용**:

```typescript
// ❌ WRONG — Vite dev의 import.meta.env.NODE_ENV='development'로 자동 매치
const RUNTIME_NODE_ENV = import.meta.env.NODE_ENV
  ?? (import.meta.env.DEV ? 'development' : import.meta.env.MODE)
const TEST_MODE = isTestMode(window.location.search, RUNTIME_NODE_ENV)
// 결과: Vite dev에서는 항상 TEST_MODE=true

// ✅ CORRECT — Vite dev에서 자동 매칭 안 되는 sentinel 사용
const RUNTIME_NODE_ENV = import.meta.env.NODE_ENV
  ?? (import.meta.env.DEV ? 'production-dev' : import.meta.env.MODE)
const TEST_MODE = isTestMode(window.location.search, RUNTIME_NODE_ENV)
// 결과: Vite dev에서는 'production-dev' → TEST_MODE=false (URL 쿼리로만 켜짐)
```

**규칙**: Vite dev mode에서 `?test=1` URL 쿼리로만 활성화하고 싶다면, `import.meta.env.NODE_ENV`이 `'development'`인지 검사하는 코드를 작성하지 말 것. 대신 `import.meta.env.DEV` boolean 또는 사용자 정의 sentinel을 사용. `import.meta.env.MODE`도 dev에서는 `'development'`로 설정되니 회피.

**자동 감지 패턴**:
```bash
# 일반 모드 콘솔에 BOOT test mode 메시지가 보이면 이 버그
grep -n "isTestMode\|RUNTIME_NODE_ENV" src/main.ts
```

**`?test=1` URL 쿼리 패턴 + rev grep으로 안전하게 적용하는 절차**: [`references/test-mode-via-url-query.md`](references/test-mode-via-url-query.md) 참조. worker self-revert 안티패턴과 결합 — 카드 분할은 사람 단위가 아닌 작업 단위로.

### 함정 -0.6: 시야 디버깅 — tint + scale로 GPU 업로드 vs 렌더 파이프라인 분리 (★ 2026-07-23 후반 발견)

sprite가 만들어졌지만 화면에 안 보일 때 **fix 시도 전에** 다음을 적용해서 GPU 업로드 실패인지 렌더 파이프라인 문제인지 분리:

```typescript
// Step 1: sprite를 크게 키우고 눈에 띄는 tint 적용
const player = new Sprite(playerTexture)
player.width = 96          // 원래 24의 4배
player.height = 144        // 원래 36의 4배
player.tint = 0xff5577     // 분홍 (원본 흰색)
player.anchor.set(0.5)     // 위치 보정
player.x = 640              // LOGICAL_WIDTH / 2
player.y = 360              // LOGICAL_HEIGHT / 2
app.stage.addChild(player)
```

판단:
- **분홍 사각형 보임** → GPU 업로드 + 렌더 파이프라인 정상. **원본 sprite가 단순하거나 작아서 시각적으로 안 보일 뿐** (예: snkrx warrior.png는 40x60 중 485픽셀만 흰색). `tint`와 scale을 원래대로 되돌리고, `PIXI.Text` 디버깅으로 텍스트 label을 띄워 sprite가 어디 있는지 확인
- **분홍 사각형 안 보임** → GPU 업로드 또는 렌더 파이프라인 문제. `ticker`에 `player.getBounds()` 로깅, stage.children.length 확인, `sprite.filters[0]?.enabled` 확인, `texture.width`가 0인지 확인

전체 패턴: [`references/visual-debug-tint-and-scale.md`](references/visual-debug-tint-and-scale.md) 참조. **원본 LÖVE sprite는 단순한 게 정상** — 1개 warrior.png에 큰 캐릭터를 기대하지 말 것. 40x60 단일 sprite로는 거의 안 보임.

### 함정 -0.7: TDZ ReferenceError in setup/initialize 함수 패턴 (★ 2026-07-23 발견)

`let` 변수를 같은 함수 안에서 다른 helper가 참조하면 `ReferenceError: Cannot access 'X' before initialization` (Temporal Dead Zone) 발생. SNKRX v0.1.0 케이스: `setupBattleSystem()`에서 `let waveManager`로 선언된 변수를 같은 함수의 `updateHud()`가 호출해서 부팅 실패.

**신호 — PixiJS 부팅이 첫 프레임 후 멈춤**:
- `ReferenceError: Cannot access 'waveManager' before initialization`
- `at updateHud` (main.ts:273:23)
- `at setupBattleSystem` (main.ts:284:3)
- `at boot` (main.ts:115:3)
- canvas에 placeholder만 그려지거나 첫 화면이 멈춤
- **빌드 통과 + HTTP 200 OK이지만 canvas에 부팅 실패**

**해결 — 3가지 옵션** (선호 순):

```typescript
// ✅ OPTION 1 — 선언을 함수 최상단으로 이동 (가장 간단)
function setupBattleSystem(app: Application, opts: BattleSystemOpts): void {
  // 첫 줄에서 모든 let 선언
  let waveManager: WaveManager
  let activeHandles = new Map<string, EnemyHandle>()
  let currentWaveIndex = 0
  // ...
  waveManager = new WaveManager({ waves: waveDefs })  // 초기화는 그 뒤
  // ...
}

// ✅ OPTION 2 — wrapper class/object에 캡슐화 (가장 안전)
class BattleState {
  waveManager = new WaveManager({ waves: waveDefs })
  activeHandles = new Map<string, EnemyHandle>()
  currentWaveIndex = 0
  // ...
}
const state = new BattleState()
// 모든 코드는 state.waveManager, state.activeHandles로 접근

// ✅ OPTION 3 — const + 즉시 초기화 (또 다른 안전한 옵션)
const initialWaveManager = new WaveManager({ waves: waveDefs })
let waveManager = initialWaveManager  // const는 즉시 평가되므로 TDZ 회피
```

**가장 흔한 트랩**: 한 함수가 다른 함수를 호출할 때 `let`으로 선언된 외부 변수를 사용. 호출하는 함수가 `let` 선언보다 먼저 호출되면 TDZ.

**디버깅 시점**:
- 부팅이 첫 프레임 후 멈추면 `setupBattleSystem`, `setupSnake`, `boot` 같은 큰 함수 안에 TDZ 의심
- 가장 큰 함수에서 `let` 선언이 `const`/`function` 호출보다 뒤에 있는지 grep:
```bash
grep -nE "^\s*(let|const|function)" /path/to/main.ts | head -20
```

**결정 규칙 (★ 2026-07-23 사용자 선호)**: 동일한 함수에서 helper로 호출되는 변수는 **함수 최상단에서 const + 즉시 초기화**로 선언. `let`은 진짜 변경이 필요한 경우에만.

### 함정 -0.8: 작업자 auto-decomposition (specify/decompose) 충돌 (★ 2026-07-23 발견)

작업자가 큰 카드를 받으면 `kanban_specify` / `kanban_decompose`로 자동 분해해 5-7장의 카드를 만들 수 있음. **원본 카드도 todo로 돌아가고**, 분해된 카드가 자동 추가됨. **이 상황에서 분해된 카드는 자동 card body가 원본 spec과 충돌**하는 경우가 많음.

**SNKRX 사례 (2026-07-23)**: 작업자가 "snake 본체 추적" 카드를 분해해 5장 카드 생성. 카드 body는 "leader 1 + history 30 정사각형 + ←/→ 회전 + dt 이동" (단순 history 스냅샷 모델) — 하지만 원본 사용자 의도는 **chain-follower (누적 거리)**. 카드들이 자동 dispatch되어 사용자가 따로 정리하지 않으면 30분+ 동안 진행.

**운영자 처리 절차**:

```bash
# 1. 작업자 프로세스 중단
kill -TERM <worker_pid>

# 2. 분해된 카드 일괄 archive
for tid in t_decomposed_1 t_decomposed_2 ...; do
  hermes kanban archive $tid
done

# 3. 올바른 spec을 가진 단일 카드를 새로 만듦
# (kanban_create로 명시적 body 작성)

# 4. Dispatch
hermes kanban dispatch --max 1
```

**방지 패턴 (★ 카드 body에 직접 명시)**:

```
이 카드는 kanban_specify/kanban_decompose로 자동 분해 금지.
algorithm: chain-follower (누적 거리). 단순 history 스냅샷 아님.
```

### 함정 -0.9: Vite dev server 실행 패턴 — `| tee ... &` 절대 금지 (★ 2026-07-23 발견)

작업자가 dev server를 띄울 때 다음을 사용하면 Hermes terminal tool이 **detach하지 못해 무한 대기**:

```bash
# ❌ WRONG — 백그라운드 wrapper가 terminal을 block
npm run dev | tee /tmp/snkrx-dev.log &
```

**증상**:
- 작업자가 60분 가까이 멈춤
- `npm run dev`는 시작됐지만 tee가 background log에 write 후 종료 안 함
- 작업자가 process detach 실패로 stuck

**해결 — 운영자가 직접 띄울 때**:

```bash
# In Hermes terminal tool, use background + watch patterns
terminal command="npm run dev -- --host 127.0.0.1" run_in_background=true
# 또는 Python 자동화:
subprocess.Popen(['npm', 'run', 'dev', '--', '--host', '127.0.0.1'],
                 stdout=subprocess.PIPE, stderr=subprocess.PIPE)
```

작업자에게는 **dev server는 `run_in_background: true` 또는 `subprocess.Popen`으로 띄울 것**을 카드 body에 명시. `| tee ... &` 절대 금지.

### 함정 -0.10: sprite의 tint+scale 시각 디버깅 (★ 2026-07-23 실측, GPU 업로드 vs 렌더 문제 분리)

전체 패턴: [`references/visual-debug-tint-and-scale.md`](references/visual-debug-tint-and-scale.md) 참조. 위 함정 -0.6에 정리됨.

### 함정 0: PixiJS v8이 LÖVE 팔레트 PNG를 처리 못함 (★ v0.1.0 snkrx-web 실측, 가장 은폐된 함정)

LÖVE가 `love.image.newImageData`/`image.save`로 저장한 PNG는 거의 모두 **8-bit colormap 팔레트 PNG** (`color_type=3`) 입니다.

```text
$ file warrior.png
PNG image data, 40 x 60, 8-bit colormap, non-interlaced
```

PixiJS v8의 브라우저 PNG 디코더는 이 형식을 텍스처로 정상 디코딩하지 못해 **빈 텍스처(Sprite 박스만 보이고 픽셀 없음)** 또는 흰 십자선 placeholder를 표시합니다.

**증상 — 디버깅이 특히 어려운 이유**:
- `curl`/HTTP 200/PNG header 모두 정상
- PixiJS 로그에 에러 없음 (`Assets.load` 자체는 throw 안 함)
- 빌드 통과, `Assets.load`도 "정상" 반환
- 화면에 Sprite 박스만 보이고 픽셀 텍스처가 안 보임 (흰 십자선 또는 색 박스만)

**해결**: 모든 팔레트 PNG를 **RGBA(color_type=6)** 로 변환. **PIL(Pillow)** 가 가장 안전:

```python
from PIL import Image
from pathlib import Path

src_dir = Path('/path/to/web-project/public/assets/images')
backup_src = Path('/path/to/love-source/assets/images')

for dst in sorted(src_dir.glob('*.png')):
    src = backup_src / dst.name
    if not src.exists(): continue
    if src.read_bytes()[25] != 3:  # 팔레트가 아니면 그대로 복사
        dst.write_bytes(src.read_bytes())
        continue
    im = Image.open(src).convert('RGBA')
    im.save(dst, format='PNG', optimize=True)
```

**검증 (★ 변환 후 반드시 확인)**:
```python
import struct
b = Path('public/assets/images/warrior.png').read_bytes()
ct = b[25]  # 6 = RGBA, 3 = palette
w, h = struct.unpack('>II', b[16:24])
print(f'color_type={ct} {w}x{h}')  # color_type=6 40x60
```

**함정 — `ffmpeg`/`sips` 회피**:
- `ffmpeg -i input.png output.png` → 80x120으로 2배 확대됨 (필터 명시 필요: `-vf scale=40:60`)
- `ffmpeg`는 일부 palette PNG에서 변환 자체 실패 (디코딩 에러)
- macOS `sips`는 palette → RGBA 변환 옵션이 약함
- 따라서 **PIL이 정답**

**함정 — Python 인터프리터**: macOS 시스템 `/usr/bin/python3`의 PIL은 import 시 깨져 있음 (`cannot import name '_imaging'`). **Hermes venv Python 사용**:
```bash
/Users/mac/.hermes/hermes-agent/venv/bin/python -c "from PIL import Image; print(Image.__version__)"
```

**검증 자동화 체크리스트**:
1. `public/assets/images/*.png` 전부 `color_type=6` 확인
2. 원본 크기(예: 40x60) 유지 확인 (80x120으로 2배 확대됐으면 다시 변환)
3. `npm run dev` 후 `curl -o /dev/null -w "%{http_code}" http://localhost:5173/assets/images/warrior.png` 200 OK
4. 브라우저 강력 새로고침 (Shift+Cmd+R)로 HMR 캐시 무효화

전체 변환 스크립트는 [`references/asset-conversion.md`](references/asset-conversion.md) 참조.

### 함정 1: `local` 함수 의존성

LÖVE는 main.lua 내부 `local` 함수를 ko.lua에서 직접 호출 못 함 (★ v0.1.8/v0.1.10에서 2번 만남). TS로 포팅 시:

```ts
// ❌ WRONG — 모듈 스코프 helper를 다른 모듈에서 접근
// main.ts: const ylb1 = (lvl) => lvl === 3 ? 'light_bg' : 'yellow';
// data/heroes.ts: ylb1(3)  // Error: ylb1 is not defined

// ✅ CORRECT — helper를 export해서 재사용
// utils/helpers.ts:
export const ylb1 = (lvl: number) => lvl >= 3 ? 'light_bg' : 'yellow';
// data/heroes.ts: import { ylb1 } from '../utils/helpers';\n```
```

### 함정 2: UTF-8 byte vs character iteration

LÖVE의 `s:sub(i, i)`는 byte 1개. TS는 **UTF-16 code unit** 1개 (BMP 범위는 OK, supplementary plane은 깨짐). 한글/이모지 처리는 **Code Point** 단위로:

```ts
// ❌ WRONG
for (let i = 0; i < str.length; i++) {
  processChar(str[i]);  // surrogate pair 깨짐
}

// ✅ CORRECT
for (const ch of str) {
  processChar(ch);  // ES6 iterator는 code point 단위
}

// 또는 명시적 grapheme cluster:
// graphemer 라이브러리 (LÖVE의 utf8 char iteration은 Grapheme)
```

LÖVE의 `function Font:has_cjk(text)`에서 `string.byte(text, i)` 1바이트 검사로는 Latin extended (é, ñ, ü)도 false-positive. TS 버전은 `/\p{Script=Hangul}/u.test(ch)` 같은 Unicode property regex 사용.

### 함정 3: :activate({}) 안 `local` 선언 불가

LÖVE Lua 함수의 `function(arg, { local_var = ...; ... })` 같은 statement-in-arg는 LÖVE/LuaJIT에서 syntax 에러. TS는 **JavaScript 클래스 메서드 호출의 `obj.method({ ... })` 안에서 `let/const` 선언 가능** (TS가 ES6+):

```ts
// ❌ WRONG (Lua에서 흔한 실수) — TS에서는 동작하지만 명시적 분리 권장
this.infoText:activate({
  const charName = T('char_' + this.character, this.character);
  // ... 다른 var 선언
});

// ✅ CORRECT — 명시적 분리
const charName = T('char_' + this.character, this.character);
const descFunc = /* ... */;
this.infoText:activate({
  { text: `... ${charName} ...` },
  // ...
});
```

TS는 const-in-arg가 동작하지만 **읽기 어려움** + **디버깅 어려움** (line break가 필요하면 LÖVE 스타일 명시적 분리가 안전.

### 함정 4: TypeScript strict + verbatimModuleSyntax

Vite 보일러플레이트는 `verbatimModuleSyntax: true`로 시작 → type-only import(`import type { X } from ...`) 강제. **이름을 값 + type 둘 다 쓸 때** import가 깨짐:

```ts
// ❌ ERROR: 'EnemyDef' is a type and must be imported using a type-only import
import { EnemyDef } from '../data/enemies';
import { Projectile } from './projectile';  // 값 — OK

// ✅ CORRECT
import type { EnemyDef } from '../data/enemies';
import { Projectile } from './projectile';
```

**해결 (★ 권장)**: tsconfig.json에서 `verbatimModuleSyntax: false`. 단일 LLM 작업에서 type/value 구분은 인지 비용만 높임. **v0.5+ 정식 출시 전에 strict 추가 권장**.

### 함정 5: Canvas DPR 스케일링

LÖVE는 자동 DPI 매핑. Canvas 2D는 **명시적 DPR** 처리 필요:

```ts
function setupCanvas(canvas: HTMLCanvasElement) {
  const dpr = window.devicePixelRatio || 1;
  const rect = canvas.getBoundingClientRect();
  canvas.width = rect.width * dpr;
  canvas.height = rect.height * dpr;
  canvas.style.width = `${rect.width}px`;
  canvas.style.height = `${rect.height}px`;
  const ctx = canvas.getContext('2d')!;
  ctx.scale(dpr, dpr);  // ★ 핵심 — 이게 없으면 모든 도형이 1/dpr 크기
}
```

`image-rendering: pixelated` (CSS)로 8-bit 픽셀 아트 보존.

### 함정 5.5: PixiJS v8 부팅 정석 — `Assets.load(url)` 우선 (★★ 가장 큰 교훈, 2026-07-23)

세션 후반까지 `Texture.from(canvas)` → `Texture.from(image)` → `Texture.from(imageData)` 5단계 우회를 거치며 시간을 낭비함. **정답은 처음부터 `await Assets.load(url)`**.

```text
[CRITICAL] Using Texture.from(url) to load
Wrong:  Texture.from("https://example.com/image.png")
Correct: await Assets.load("https://example.com/image.png")
In v8, Texture.from() only reads the cache. It does not fetch from a URL.
```

**부팅 안 될 때 우선순위 (★ 2026-07-23 SNKRX 실측)**:

1. ★★★★★ **`await Assets.load(url)`** — PixiJS v8 정석. ImageSource 자동 디텍트, fetch + 디코딩 + GPU 업로드 + 캐시 모두 처리. **부팅 안 되면 이걸로 먼저 시도**
2. `loadOptional` wrapper로 감싸기 (한 텍스처 실패가 부팅 전체를 막지 않도록)
3. `HELD_TEXTURES: Texture[]` + `Texture.from(htmlImageElement)` 우회 — PixiJS 내부 캐시 미등록으로 GC 시 사라지는 문제 → 모듈 스코프 보관으로 해결
4. ~~`Canvas → Texture.from(canvas)`~~ — CanvasSource 비동기 GPU 업로드 실패 사례
5. ~~`ImageData → Texture.from(imageData, {width, height})`~~ — PixiJS v8에서 throw (`Could not find a source type for resource: [object ImageData]`). `Texture.from` 두 번째 인자는 `boolean | undefined`만 받음
6. **부팅 안 되면 fix 시도 전에 공식 PixiJS 스킬 설치** — `hermes skills install --force pixijs/pixijs-skills/pixijs-assets`. [CRITICAL] 섹션이 정확히 이 우선순위 1번을 명시

**부팅 후 검증 체크리스트**:
```ts
// 1. 렌더러가 무엇인지 확인
log('BOOT app.init done', {
  rendererType: app.renderer.type,  // 1 = WebGL, 2 = WebGPU, 0 = Canvas
  rendererName: app.renderer.name,
  tickerStarted: app.ticker.started,
})

// 2. 텍스처 생성 확인
log('LOAD Texture.from created', { url, texWidth: tex.width, texHeight: tex.height })

// 3. Sprite 추가 확인
log('BOOT stage children count', app.stage.children.length)

// 4. 200ms 후 비동기 검증 (★ 효과적 — "텍스처 만들었지만 안 보임" 진단)
setTimeout(() => {
  app.stage.children.forEach((child) => {
    if (child instanceof Sprite) {
      log(`VERIFY sprite ${child.label}: w=${child.width} h=${child.height} textureW=${child.texture.width}`)
      // textureW=0 → PixiJS 캐시/GC 문제
    }
  })
}, 200)
```

전체 PixiJS 부팅 정석 코드는 [`references/pixijs-texture-bootstrap-diagnosis.md`](references/pixijs-texture-bootstrap-diagnosis.md) 참조.

### 함정 6: boot-time Promise.all 자산 로드 트랩 (★ 가장 자주 만남, 2026-07-23 PixiJS 실측)

위 "boot-time Promise.all 자산 로드 트랩" 섹션 참조. Promise.all로 텍스처 묶어서 로드하고 그 결과를 addBattleDemo로 넘기면, 한 텍스처라도 실패하면 throw하고 화면이 안 그려짐. **빌드 성공 ≠ 화면 표시**. 항상 `loadOptional` + Sprite/Graphics fallback 패턴 사용.

### 사용자의 디버깅 선호: "막히면 광범위 로깅을 먼저" (★ 2026-07-23 사용자 명시 요청)

PixiJS/LÖVE 포팅 중 화면이 안 그려지거나 부팅이 멈출 때, **fix를 시도하기 전에 모든 핵심 단계를 `[snkrx]` prefix 로그로 감싸서 어디서 막히는지 먼저 식별**한다. 사용자가 "콜솔에서 더많은 정보를 수집할 수 있도록 로그를 추가해보는게 어때?"라고 명시적으로 요청한 패턴.

**광범위 로깅 템플릿** (실제 SNKRX 2026-07-23에서 사용):

```ts
function log(stage: string, payload?: unknown): void {
  if (payload === undefined) {
    console.log(`[snkrx] ${stage}`)
  } else {
    console.log(`[snkrx] ${stage}`, payload)
  }
}

async function boot(): Promise<void> {
  log('BOOT start')
  log('BOOT dom', { root: !!root, status: !!status })
  log('BOOT Application created')
  await app.init({ /* ... */ })
  log('BOOT app.init done', {
    canvasW: app.canvas.width, canvasH: app.canvas.height,
    rendererType: app.renderer.type, rendererName: app.renderer.name,
    contextLost: app.canvas.getContext('webgl2')?.isContextLost?.(),
    tickerStarted: app.ticker.started,
  })
  // ... 텍스처 로드마다:
  log('LOAD start', url)
  log('LOAD image.onload', { url, w: img.naturalWidth, h: img.naturalHeight })
  log('LOAD Texture.from created', { url, texWidth: tex.width, texHeight: tex.height })
  // ... Sprite 추가 후:
  log('BOOT stage children count', app.stage.children.length)
  // ... 200ms 후 비동기 검증:
  setTimeout(() => log('VERIFY after 200ms', { /* ... */ }), 200)
}
```

**로깅 후 진단 가능해진 단서** (2026-07-23 사례):
- `rendererType: 1 (webgl)` → PixiJS WebGLRenderer 동작 확인
- `child[0].textureW=40 textureH=60` → 텍스처는 정상 생성
- `child[0].visible=true alpha=1` → Sprite는 화면에 그려야 함
- 그런데도 안 보임 → "텍스처/스프라이트는 정상이지만 렌더링 파이프라인 다른 단계"로 좁힘

**규칙**: 빌드 통과 + HTTP 200 + 텍스처 데이터 정상 + Sprite 정상인데도 화면이 안 그려지면, **로깅을 추가하지 않은 채 fix를 시도하지 말 것**. 먼저 log를 모든 단계에 깔고, console 출력을 사용자에게 받아서 진단.

### 함정 6.5: PixiJS v8 `Assets.load` 텍스처 캐시 트랩 + `Texture.from(image)` GC (★ v0.1.0+ PixiJS 실측, 2026-07-23)

**증상 — 진단이 특히 어려운 이유**:
- `loadOptional`로 감싸도 PixiJS v8의 `Assets.load`가 **동일 URL의 디코딩 실패 결과를 텍스처 캐시에 영구 저장**
- 같은 URL을 다시 요청하면 캐시된 실패를 그대로 반환 → `{err: 'not found'}` 던짐
- `cache-bust` 쿼리(`?t=Date.now()`)를 붙여도 **PixiJS의 캐시 키는 URL prefix 매칭**이라서 같은 경로로 인식될 수 있음
- `Texture.from(htmlImageElement)`로 우회하면 텍스처가 만들어지지만 **PixiJS 내부 캐시에 등록되지 않아 다음 GC 사이클에서 사라짐** (Sprite가 빈 텍스처로 폴백)

**해결 — 모듈 스코프에 명시적 보관 + Image 디코딩 + 검증 로그**:

```ts
// ❌ WRONG — Texture.from만 호출하면 다음 GC에서 사라짐
async function loadTexture(url: string): Promise<Texture | null> {
  return new Promise((resolve) => {
    const img = new Image()
    img.onload = () => resolve(Texture.from(img))  // GC 후 사라짐
    img.onerror = () => resolve(null)
    img.src = url
  })
}

// ✅ CORRECT — 모듈 스코프 보관 + 디코딩 검증 + 명시적 GC 방지
const HELD_TEXTURES: Texture[] = []  // module-scope 보관

async function loadTextureFromUrl(url: string): Promise<Texture | null> {
  return new Promise((resolve) => {
    const img = new Image()
    img.crossOrigin = 'anonymous'
    img.onload = () => {
      // ★ 디코딩 검증 — naturalWidth 0이면 실패
      if (img.naturalWidth === 0 || img.naturalHeight === 0) {
        console.warn(`[snkrx] 이미지 디코딩 결과 비어 있음 (${url})`)
        resolve(null)
        return
      }
      try {
        const tex = Texture.from(img)
        // ★ Texture 자체 검증 — width 0이면 PixiJS 내부 캐시가 빈 텍스처를 반환한 것
        if (!tex || (tex.width ?? 0) === 0) {
          console.warn(`[snkrx] Texture.from 결과 비어 있음 (${url})`)
          resolve(null)
          return
        }
        HELD_TEXTURES.push(tex)  // ★ 명시적 보관으로 GC 방지
        console.log(`[snkrx] 텍스처 생성 (${url}) ${img.naturalWidth}x${img.naturalHeight}`)
        resolve(tex)
      } catch (e) {
        console.warn(`[snkrx] Texture.from 실패 (${url}):`, e)
        resolve(null)
      }
    }
    img.onerror = (e) => {
      console.warn(`[snkrx] 이미지 디코드 실패 (${url}):`, e)
      resolve(null)
    }
    img.src = url
  })
}
```

**첫 프레임 후 검증 패턴** (★ 효과적 — "텍스처 만들었지만 안 보임" 진단):

```ts
app.renderer.render(app.stage)  // 첫 프레임 강제 렌더
setTimeout(() => {
  app.stage.children.forEach((child) => {
    if (child instanceof Sprite) {
      console.log(`[snkrx] sprite ${child.label}: w=${child.width} h=${child.height} textureW=${child.texture.width} textureH=${child.texture.height}`)
      // textureW=0 → PixiJS가 빈 텍스처를 반환한 것 (캐시 트랩 또는 GC)
    }
  })
}, 500)
```

**판단 기준**:
- `textureW=0` → PixiJS 캐시 또는 GC 문제. `HELD_TEXTURES` 확인, `Texture.from(image)` 경로 재확인
- `textureW=정상`인데 화면에 안 보임 → 렌더 순서, Sprite 위치, Z-index 문제

**★ 가장 안정적인 우회 경로: `Texture.from(imageData)` (2026-07-23 세션 후반 채택)**

`Texture.from(htmlImageElement)` + `Texture.from(canvas)` 모두 일부 환경에서 PixiJS의 CanvasSource 경로를 타면서 비동기 GPU 업로드 + 실패가 발생함. **가장 안정적인 경로**는 픽셀 데이터를 직접 BufferSource로 만드는 것:

```ts
const HELD_IMAGE_DATA: ImageData[] = []  // GC 방지용 모듈 스코프 보관

async function loadTextureFromUrl(url: string): Promise<Texture | null> {
  return new Promise((resolve) => {
    const img = new Image()
    img.crossOrigin = 'anonymous'
    img.onload = () => {
      if (img.naturalWidth === 0 || img.naturalHeight === 0) {
        console.warn(`[snkrx] 이미지 디코딩 결과 비어 있음 (${url})`)
        resolve(null); return
      }
      try {
        const w = img.naturalWidth, h = img.naturalHeight
        const canvas = document.createElement('canvas')
        canvas.width = w; canvas.height = h
        const ctx = canvas.getContext('2d')!
        ctx.drawImage(img, 0, 0)
        const imageData = ctx.getImageData(0, 0, w, h)
        HELD_IMAGE_DATA.push(imageData)  // ★ ImageData 보관 (GC 방지)

        // ★ ImageData → BufferSource → GPU 업로드 (CanvasSource 우회)
        const tex = Texture.from(imageData)
        HELD_TEXTURES.push(tex)
        console.log(`[snkrx] 텍스처 생성 (${url}) ${w}x${h} → texture ${tex.width}x${tex.height}`)
        resolve(tex)
      } catch (e) {
        console.warn(`[snkrx] Texture.from 실패 (${url}):`, e)
        resolve(null)
      }
    }
    img.onerror = (e) => { console.warn(`[snkrx] 이미지 디코드 실패 (${url}):`, e); resolve(null) }
    img.src = url
  })
}
```

**채택 우선순위 (2026-07-23, PixiJS 공식 스킬 pixijs/pixijs-skills/pixijs-assets로 재정리)**:

> **가장 큰 교훈 (★★)**: 세션 후반까지 `Texture.from(canvas)` → `Texture.from(image)` → `Texture.from(imageData)` 5단계 우회를 거치며 시간을 낭비함. **`Texture.from(imageData)`는 PixiJS v8에서 명시적으로 throw** — `Error: Could not find a source type for resource: [object ImageData]`. **정답은 처음부터 `Assets.load(url)`**. 공식 스킬이 [CRITICAL]로 명시:

> **가장 큰 교훈 (★★)**: **`Assets.load(url)`이 정답**. 세션 후반까지 `Texture.from(canvas)` → `Texture.from(image)` → `Texture.from(imageData)` 5단계 우회를 거치며 시간을 낭비함. **`Texture.from(imageData)`는 PixiJS v8에서 명시적으로 throw** — `Error: Could not find a source type for resource: [object ImageData]`. **정답은 처음부터 `Assets.load(url)`**. 공식 스킬이 [CRITICAL]로 명시:
>
> ```text
> [CRITICAL] Using Texture.from(url) to load
> Wrong:  Texture.from("https://example.com/image.png")
> Correct: await Assets.load("https://example.com/image.png")
> In v8, Texture.from() only reads the cache. It does not fetch from a URL.
> ```

**수정된 우선순위 (★ 2026-07-23 SNKRX 실측)**:

1. ★★★★★ **`await Assets.load(url)`** — PixiJS v8 정석. ImageSource 자동 디텍트, fetch + 디코딩 + GPU 업로드 + 캐시 모두 처리. **부팅 안 되면 이걸로 먼저 시도**
2. `loadOptional` wrapper로 감싸기 (한 텍스처 실패가 부팅 전체를 막지 않도록)
3. ~~`Image → Texture.from(image)` + 모듈 스코프 `HELD_TEXTURES: Texture[]`~~ — 우회용. **그러나 `Assets.load`로 해결 후 불필요**. `Texture.from(image)`는 PixiJS 내부 캐시에 등록되지 않아 GC 시 사라짐 + ImageSource는 정상 인식되지만 Promise로 인한 비동기 GPU 업로드 실패 사례 있음
4. ~~`Canvas → Texture.from(canvas)`~~ — CanvasSource 비동기 GPU 업로드 실패 사례 있음. **그러나 `Assets.load`로 해결 후 불필요**

**★★ 부팅이 안 될 때 5번 우회로 시간을 낭비하지 말 것. 1번 `Assets.load`로 먼저 시도하고, 그래도 안 되면 그때 우회.** 2026-07-23 세션에서 4번 우회까지 시도한 게 가장 큰 시간 낭비였음. **가장 안정적인 우회 경로**: `ImageData → Texture.from(imageData)` (단, 2026-07-23 후반 채택). 하지만 그마저 실패 시 **`Assets.unload(url)` → `Assets.load(url)` 캐시 비우고 재로드**가 더 안정적. `loadOptional`로 감싸면 텍스처 실패가 부팅 전체를 막지 않음.

**PixiJS v8 `Texture.from` 시그니처 주의**:
- `Texture.from(string | HTMLCanvasElement | HTMLImageElement | HTMLVideoElement | ImageBitmap)` — ImageData는 자동으로 인식 안 됨
- 두 번째 인자 `{ width, height }`는 v8에서 더 이상 지원 안 함 (`boolean | undefined`만 받음)
- ImageData를 쓰려면 `Texture.from(imageData.data.buffer)` 형태로 `.data.buffer` 전달해야 하지만, 그마저 throw할 수 있어 비권장

**PixiJS 공식 스킬 (★ 사용자 명시 설치 요청 대응)**:
- `hermes skills install pixijs/pixijs-skills/pixijs` (허브 설치, 사용자 승인 필요)
- `hermes skills install pixijs/pixijs-skills/pixijs-assets` (community 경고, `--force` 필요)
- 두 스킬의 [CRITICAL] 섹션이 정확히 위 우선순위 1번을 명시. **부팅 안 될 때 fix 시도 전에 먼저 설치**

전체 패턴은 [`templates/pixijs-boot-with-fallback.ts`](templates/pixijs-boot-with-fallback.ts) 참조.

### 사용자의 디버깅 선호: "막히면 광범위 로깅을 먼저" (★ 2026-07-23 사용자 명시 요청)

PixiJS/LÖVE 포팅 중 화면이 안 그려지거나 부팅이 멈출 때, **fix를 시도하기 전에 모든 핵심 단계를 `[snkrx]` prefix 로그로 감싸서 어디서 막히는지 먼저 식별**한다. 사용자가 "콜솔에서 더많은 정보를 수집할 수 있도록 로그를 추가해보는게 어때?"라고 명시적으로 요청한 패턴.

**광범위 로깅 템플릿** (실제 SNKRX 2026-07-23에서 사용):

```ts
function log(stage: string, payload?: unknown): void {
  if (payload === undefined) {
    console.log(`[snkrx] ${stage}`)
  } else {
    console.log(`[snkrx] ${stage}`, payload)
  }
}

async function boot(): Promise<void> {
  log('BOOT start')
  log('BOOT dom', { root: !!root, status: !!status })
  log('BOOT Application created')
  await app.init({ /* ... */ })
  log('BOOT app.init done', {
    canvasW: app.canvas.width, canvasH: app.canvas.height,
    rendererType: app.renderer.type, rendererName: app.renderer.name,
    contextLost: app.canvas.getContext('webgl2')?.isContextLost?.(),
    tickerStarted: app.ticker.started,
  })
  // ... 텍스처 로드마다:
  log('LOAD start', url)
  log('LOAD image.onload', { url, w: img.naturalWidth, h: img.naturalHeight })
  log('LOAD Texture.from created', { url, texWidth: tex.width, texHeight: tex.height })
  // ... Sprite 추가 후:
  log('BOOT stage children count', app.stage.children.length)
  // ... 200ms 후 비동기 검증:
  setTimeout(() => log('VERIFY after 200ms', { /* ... */ }), 200)
}
```

**로깅 후 진단 가능해진 단서** (2026-07-23 사례):
- `rendererType: 1 (webgl)` → PixiJS WebGLRenderer 동작 확인
- `child[0].textureW=40 textureH=60` → 텍스처는 정상 생성
- `child[0].visible=true alpha=1` → Sprite는 화면에 그려야 함
- 그런데도 안 보임 → "텍스처/스프라이트는 정상이지만 렌더링 파이프라인 다른 단계"로 좁힘

**규칙**: 빌드 통과 + HTTP 200 + 텍스처 데이터 정상 + Sprite 정상인데도 화면이 안 그려지면, **로깅을 추가하지 않은 채 fix를 시도하지 말 것**. 먼저 log를 모든 단계에 깔고, console 출력을 사용자에게 받아서 진단.

### 함정 6.5: PixiJS v8 `Assets.load` 텍스처 캐시 트랩 + `Texture.from(image)` GC (★ v0.1.0+ PixiJS 실측, 2026-07-23)

**증상 — 진단이 특히 어려운 이유**:
- `loadOptional`로 감싸도 PixiJS v8의 `Assets.load`가 **동일 URL의 디코딩 실패 결과를 텍스처 캐시에 영구 저장**
- 같은 URL을 다시 요청하면 캐시된 실패를 그대로 반환 → `{err: 'not found'}` 던짐
- `cache-bust` 쿼리(`?t=Date.now()`)를 붙여도 **PixiJS의 캐시 키는 URL prefix 매칭**이라서 같은 경로로 인식될 수 있음
- `Texture.from(htmlImageElement)`로 우회하면 텍스처가 만들어지지만 **PixiJS 내부 캐시에 등록되지 않아 다음 GC 사이클에서 사라짐** (Sprite가 빈 텍스처로 폴백)

**해결 — 모듈 스코프에 명시적 보관 + Image 디코딩 + 검증 로그**:

```ts
// ❌ WRONG — Texture.from만 호출하면 다음 GC에서 사라짐
async function loadTexture(url: string): Promise<Texture | null> {
  return new Promise((resolve) => {
    const img = new Image()
    img.onload = () => resolve(Texture.from(img))  // GC 후 사라짐
    img.onerror = () => resolve(null)
    img.src = url
  })
}

// ✅ CORRECT — 모듈 스코프 보관 + 디코딩 검증 + 명시적 GC 방지
const HELD_TEXTURES: Texture[] = []  // module-scope 보관

async function loadTextureFromUrl(url: string): Promise<Texture | null> {
  return new Promise((resolve) => {
    const img = new Image()
    img.crossOrigin = 'anonymous'
    img.onload = () => {
      // ★ 디코딩 검증 — naturalWidth 0이면 실패
      if (img.naturalWidth === 0 || img.naturalHeight === 0) {
        console.warn(`[snkrx] 이미지 디코딩 결과 비어 있음 (${url})`)
        resolve(null)
        return
      }
      try {
        const tex = Texture.from(img)
        // ★ Texture 자체 검증 — width 0이면 PixiJS 내부 캐시가 빈 텍스처를 반환한 것
        if (!tex || (tex.width ?? 0) === 0) {
          console.warn(`[snkrx] Texture.from 결과 비어 있음 (${url})`)
          resolve(null)
          return
        }
        HELD_TEXTURES.push(tex)  // ★ 명시적 보관으로 GC 방지
        console.log(`[snkrx] 텍스처 생성 (${url}) ${img.naturalWidth}x${img.naturalHeight}`)
        resolve(tex)
      } catch (e) {
        console.warn(`[snkrx] Texture.from 실패 (${url}):`, e)
        resolve(null)
      }
    }
    img.onerror = (e) => {
      console.warn(`[snkrx] 이미지 디코드 실패 (${url}):`, e)
      resolve(null)
    }
    img.src = url
  })
}
```

**첫 프레임 후 검증 패턴** (★ 효과적 — "텍스처 만들었지만 안 보임" 진단):

```ts
app.renderer.render(app.stage)  // 첫 프레임 강제 렌더
setTimeout(() => {
  app.stage.children.forEach((child) => {
    if (child instanceof Sprite) {
      console.log(`[snkrx] sprite ${child.label}: w=${child.width} h=${child.height} textureW=${child.texture.width} textureH=${child.texture.height}`)
      // textureW=0 → PixiJS가 빈 텍스처를 반환한 것 (캐시 트랩 또는 GC)
    }
  })
}, 500)
```

**판단 기준**:
- `textureW=0` → PixiJS 캐시 또는 GC 문제. `HELD_TEXTURES` 확인, `Texture.from(image)` 경로 재확인
- `textureW=정상`인데 화면에 안 보임 → 렌더 순서, Sprite 위치, Z-index 문제

**★ 가장 안정적인 우회 경로: `Texture.from(imageData)` (2026-07-23 세션 후반 채택)**

`Texture.from(htmlImageElement)` + `Texture.from(canvas)` 모두 일부 환경에서 PixiJS의 CanvasSource 경로를 타면서 비동기 GPU 업로드 + 실패가 발생함. **가장 안정적인 경로**는 픽셀 데이터를 직접 BufferSource로 만드는 것:

```ts
const HELD_IMAGE_DATA: ImageData[] = []  // GC 방지용 모듈 스코프 보관

async function loadTextureFromUrl(url: string): Promise<Texture | null> {
  return new Promise((resolve) => {
    const img = new Image()
    img.crossOrigin = 'anonymous'
    img.onload = () => {
      if (img.naturalWidth === 0 || img.naturalHeight === 0) {
        console.warn(`[snkrx] 이미지 디코딩 결과 비어 있음 (${url})`)
        resolve(null); return
      }
      try {
        const w = img.naturalWidth, h = img.naturalHeight
        const canvas = document.createElement('canvas')
        canvas.width = w; canvas.height = h
        const ctx = canvas.getContext('2d')!
        ctx.drawImage(img, 0, 0)
        const imageData = ctx.getImageData(0, 0, w, h)
        HELD_IMAGE_DATA.push(imageData)  // ★ ImageData 보관 (GC 방지)

        // ★ ImageData → BufferSource → GPU 업로드 (CanvasSource 우회)
        const tex = Texture.from(imageData)
        HELD_TEXTURES.push(tex)
        console.log(`[snkrx] 텍스처 생성 (${url}) ${w}x${h} → texture ${tex.width}x${tex.height}`)
        resolve(tex)
      } catch (e) {
        console.warn(`[snkrx] Texture.from 실패 (${url}):`, e)
        resolve(null)
      }
    }
    img.onerror = (e) => { console.warn(`[snkrx] 이미지 디코드 실패 (${url}):`, e); resolve(null) }
    img.src = url
  })
}
```

**채택 우선순위 (2026-07-23, PixiJS 공식 스킬 pixijs/pixijs-skills/pixijs-assets로 재정리)**:

> **가장 큰 교훈 (★★)**: 세션 후반까지 `Texture.from(canvas)` → `Texture.from(image)` → `Texture.from(imageData)` 5단계 우회를 거치며 시간을 낭비함. **`Texture.from(imageData)`는 PixiJS v8에서 명시적으로 throw** — `Error: Could not find a source type for resource: [object ImageData]`. **정답은 처음부터 `Assets.load(url)`**. 공식 스킬이 [CRITICAL]로 명시:

> **가장 큰 교훈 (★★)**: **`Assets.load(url)`이 정답**. 세션 후반까지 `Texture.from(canvas)` → `Texture.from(image)` → `Texture.from(imageData)` 5단계 우회를 거치며 시간을 낭비함. **`Texture.from(imageData)`는 PixiJS v8에서 명시적으로 throw** — `Error: Could not find a source type for resource: [object ImageData]`. **정답은 처음부터 `Assets.load(url)`**. 공식 스킬이 [CRITICAL]로 명시:
>
> ```text
> [CRITICAL] Using Texture.from(url) to load
> Wrong:  Texture.from("https://example.com/image.png")
> Correct: await Assets.load("https://example.com/image.png")
> In v8, Texture.from() only reads the cache. It does not fetch from a URL.
> ```

**수정된 우선순위 (★ 2026-07-23 SNKRX 실측)**:

1. ★★★★★ **`await Assets.load(url)`** — PixiJS v8 정석. ImageSource 자동 디텍트, fetch + 디코딩 + GPU 업로드 + 캐시 모두 처리. **부팅 안 되면 이걸로 먼저 시도**
2. `loadOptional` wrapper로 감싸기 (한 텍스처 실패가 부팅 전체를 막지 않도록)
3. ~~`Image → Texture.from(image)` + 모듈 스코프 `HELD_TEXTURES: Texture[]`~~ — 우회용. **그러나 `Assets.load`로 해결 후 불필요**. `Texture.from(image)`는 PixiJS 내부 캐시에 등록되지 않아 GC 시 사라짐 + ImageSource는 정상 인식되지만 Promise로 인한 비동기 GPU 업로드 실패 사례 있음
4. ~~`Canvas → Texture.from(canvas)`~~ — CanvasSource 비동기 GPU 업로드 실패 사례 있음. **그러나 `Assets.load`로 해결 후 불필요**

**★★ 부팅이 안 될 때 5번 우회로 시간을 낭비하지 말 것. 1번 `Assets.load`로 먼저 시도하고, 그래도 안 되면 그때 우회.** 2026-07-23 세션에서 4번 우회까지 시도한 게 가장 큰 시간 낭비였음. **가장 안정적인 우회 경로**: `ImageData → Texture.from(imageData)` (단, 2026-07-23 후반 채택). 하지만 그마저 실패 시 **`Assets.unload(url)` → `Assets.load(url)` 캐시 비우고 재로드**가 더 안정적. `loadOptional`로 감싸면 텍스처 실패가 부팅 전체를 막지 않음.

**PixiJS v8 `Texture.from` 시그니처 주의**:
- `Texture.from(string | HTMLCanvasElement | HTMLImageElement | HTMLVideoElement | ImageBitmap)` — ImageData는 자동으로 인식 안 됨
- 두 번째 인자 `{ width, height }`는 v8에서 더 이상 지원 안 함 (`boolean | undefined`만 받음)
- ImageData를 쓰려면 `Texture.from(imageData.data.buffer)` 형태로 `.data.buffer` 전달해야 하지만, 그마저 throw할 수 있어 비권장

**PixiJS 공식 스킬 (★ 사용자 명시 설치 요청 대응)**:
- `hermes skills install pixijs/pixijs-skills/pixijs` (허브 설치, 사용자 승인 필요)
- `hermes skills install pixijs/pixijs-skills/pixijs-assets` (community 경고, `--force` 필요)
- 두 스킬의 [CRITICAL] 섹션이 정확히 위 우선순위 1번을 명시. **부팅 안 될 때 fix 시도 전에 먼저 설치**

전체 패턴은 [`templates/pixijs-boot-with-fallback.ts`](templates/pixijs-boot-with-fallback.ts) 참조.

### 함정 7: shell `| tee ... &` 백그라운드 wrapper trap (2026-07-23 실측)

작업자가 dev server를 띄울 때 다음 명령을 자주 사용:
```bash
npm run dev | tee /tmp/snkrx-dev.log &
```

이 명령은 shell background wrapper를 만들고, **Hermes terminal tool은 이를 detach하지 못해 무한 대기**하는 경우가 있음. 작업자가 60분 가까이 멈춘 후 강제 종료로 풀어야 했음.

**해결**: Hermes 운영자가 직접 dev server를 띄울 때는:
```bash
npm run dev -- --host 127.0.0.1
```
을 `background=true, notify_on_complete=true, watch_patterns=['Local:']`로 실행. 작업자에게 같은 패턴 강제하거나, 작업자 prompt에 "dev server는 백그라운드로 띄우고 PID만 기록, 절대 tee& 로 묶지 말 것" 명시.

### 함정 7.5: PixiJS v8 셰이더 vertex 위치 속성 — `aPosition` (NOT `aVertexPosition`) (★ 2026-07-23 SNKRX 실측, 가장 침묵하는 함정)

LÖVE 또는 PixiJS v7의 `aVertexPosition`을 PixiJS v8에서 쓰면 `Shader Error: geometry incompatible, geometry pixi_js?v=... missing the "aVertexPosition" attribute`로 **filter가 silently disabled**됨. sprite.filters는 들어가 있고 enabled=true인데 화면에 변화 없음. 진단 패턴은 [`references/pixijs-v8-shader-vertex-aPosition.md`](references/pixijs-v8-shader-vertex-aPosition.md) 참조 — PixiJS v8 기본 vertex (`aPosition` 사용) + 진단 코드 + 흔한 v8 함정 모음.

### 함정 8: LÖVE 셰이더 → PixiJS Filter 이식 시 핵심 규칙 3가지 (★ 2026-07-23 SNKRX 실측)

1. **위치 속성은 반드시 `aPosition`** (LÖVE의 `aVertexPosition` 아님)
2. **`GlProgram.from`은 vertex + fragment 둘 다 필요** (vertex 생략 시 TypeError)
3. **vertex shader는 PixiJS v8 기본 shader 사용** (vertex shader가 필요하면 `node_modules/pixi.js/lib/filters/defaults/defaultFilter.vert.mjs` 내용 복사)

가장 흔한 실수: `aVertexPosition` 사용 시 다음 에러로 filter가 자동 disabled됨:
```
Shader Error: geometry incompatible, geometry pixi_js?v=... missing the "aVertexPosition" attribute
```

**해결 — PixiJS v8 기본 vertex shader를 직접 정의**:

```typescript
// PixiJS v8 defaultFilter.vert.mjs 의 내용을 그대로 복사
const PIXIJS_V8_VERTEX = /* glsl */ `
in vec2 aPosition;  // ← 반드시 aPosition
out vec2 vTextureCoord;

uniform vec4 uInputSize;
uniform vec4 uOutputFrame;
uniform vec4 uOutputTexture;

vec4 filterVertexPosition( void )
{
    vec2 position = aPosition * uOutputFrame.zw + uOutputFrame.xy;
    position.x = position.x * (2.0 / uOutputTexture.x) - 1.0;
    position.y = position.y * (2.0*uOutputTexture.z / uOutputTexture.y) - uOutputTexture.z;
    return vec4(position, 0.0, 1.0);
}

vec2 filterTextureCoord( void )
{
    return aPosition * (uOutputFrame.zw * uInputSize.zw);
}

void main(void)
{
    gl_Position = filterVertexPosition();
    vTextureCoord = filterTextureCoord();
}
`.trim()
```

**LÖVE .frag → PixiJS 변환**:
- `Image` uniform → `sampler2D uTexture` (PixiJS가 자동 주입)
- `Texel(image, uv)` → `texture(uTexture, uv)`
- `VaryingTexCoord` → `vTextureCoord` (vertex가 out, fragment가 in)
- `gl_FragColor` → `finalColor` (GLSL ES 3.0)

**`createReplaceFilter(0xff5252)` 예제** (적 sprite 명중 시 빨간색):

```typescript
import { Filter, GlProgram } from 'pixi.js'

function createReplaceFilter(color: number): Filter {
  const glProgram = GlProgram.from({
    vertex: PIXIJS_V8_VERTEX,
    fragment: /* glsl */ `
in vec2 vTextureCoord;
out vec4 finalColor;
uniform sampler2D uTexture;
uniform vec4 uColor;
void main(void) {
  vec4 texColor = texture(uTexture, vTextureCoord);
  finalColor = vec4(uColor.rgb, texColor.a);
}
    `.trim(),
  })
  return new Filter({
    glProgram,
    resources: {
      replaceUniforms: {
        uColor: { type: 'vec4<f32>', value: float4FromHex(color) },
      },
    },
  })
}

// sprite에 적용 (명중 시)
sprite.filters = [createReplaceFilter(0xff5252)]
sprite.filters[0].enabled = true  // ★ enabled=false면 GPU 등록은 됐지만 화면에 안 보임
```

**filter 디버깅 체크리스트** (★ 2026-07-23 실측):

1. `console`에 "Shader Error" 있는지 확인 → 있으면 filter 자동 disabled
2. `filter.enabled === true` 확인 (false면 sprite에 등록만 되고 화면에 안 보임)
3. `sprite.filters.length > 0` 확인
4. **첫 프레임 후 setTimeout으로 검증** (★ 효과적):
```typescript
setTimeout(() => {
  app.stage.children.forEach((child) => {
    if (child instanceof Sprite) {
      console.log(`sprite ${child.label}: filters=${child.filters?.length} enabled=${child.filters?.[0]?.enabled}`)
    }
  })
}, 200)
```

**SNKRX v0.1.0+ 5종 셰이더 (combine / replace / shadow / full_combine / displacement) 1시간 내 이식 사례** — PixiJS Filter.from 패턴이 잘 동작.

**Uniform type 문자열** (PixiJS v8):
- `'vec4<f32>'` — 4 floats (색상)
- `'vec3<f32>'` — 3 floats
- `'vec2<f32>'` — 2 floats
- `'f32'` — single float
- `'mat3x3<f32>'` — 3x3 matrix
- `'mat2x2<f32>'` — 2x2 matrix

**가장 흔한 함정**:
1. `aPosition` 대신 `aVertexPosition` (★ 이 세션에서 직접 만남)
2. `Texture.from` 두 번째 인자 `{ width, height }` (PixiJS v8에서 더 이상 지원 안 함, `boolean | undefined`만 받음)
3. uniform `value` 필드 누락 (PixiJS가 0으로 디폴트 → 화면에 안 보임)

### LÖVE → PixiJS Filter 매핑표

| LÖVE | PixiJS v8 Filter |
|---|---|
| `love.graphics.newShader(code)` | `Filter` 인스턴스 |
| `shader:send('name', value)` | `filter.resources.uName.value = value` |
| `graphics.setShader(shader)` | `sprite.filters = [filter]` |
| `Image` uniform | `sampler2D uTexture` (PixiJS 자동 주입) |
| `Texel(image, uv)` | `texture(uTexture, uv)` |
| `VaryingTexCoord.xy` | `vTextureCoord` |
| `gl_FragColor` | `finalColor` (GLSL ES 3.0) |
| `varying` | `in` (frag) / `out` (vert) |

## LÖVE → TS 데이터 변환 자동화 도구

**핵심**: LÖVE의 데이터 테이블(영웅 84 / 클래스 16 / 패시브 84 / 스킬)은 **로직 거의 없는 dict-of-dict**. Python + regex로 1초 변환:

```python
import re
content = open('main.lua').read()
# ['key'] = 'value' 패턴 → (key, value) 튜플 리스트
entries = re.findall(r"\['(\w+)'\] = '([^']+)'", content)
# TS 출력
print("export const HEROES: HeroDef[] = [")
for k, v in entries:
    print(f"  {{ key: '{k}', name: '{v}' }},")
print("];")
```

**84개 영웅 / 16개 클래스 / 84개 패시브 = 200+ 항목** 자동 변환. 손 변환은 30분+.

**함수 본문 변환 (passive_descriptions_level)** — split + 각 부분 번역:

```python
import re
content = open('main.lua').read()
start = content.index("passive_descriptions_level = {")
# ... brace matching으로 section 추출 ...

for line in section.split('\n'):
    m = re.match(r"^\s*\['([^']+)'\]\s*=\s*function\(lvl\)\s*return\s+(.+?)\s+end,?\s*$", line)
    if m:
        key, body = m.group(1), m.group(2)
        # body를 ' .. ' 단위로 split → 각 부분 번역 (ts()는 그대로)
        parts = re.split(r'\s*\.\.\s*', body)
        new_parts = []
        for part in parts:
            if part.startswith('ts(') and part.endswith(')'):
                new_parts.append(part)
            else:
                sm = re.match(r"^'(.*)'$", part)
                if sm:
                    new_parts.append(f"'{translate(sm.group(1))}'")
                else:
                    new_parts.append(part)
        # function(lvl) return new_parts end,
        # ...
```

**`ts()` 호출은 그대로 두고 정적 텍스트만 번역** — ts()는 Lua에서 레벨별 다른 값 반환 (10/20/30% 등). TS에서도 동일.

## 즉시 적용 규칙 — LÖVE 게임 → Web 포팅 시

1. **tsconfig strict는 v0.1에 끄고, v0.5+에 추가** — 빠른 프로토타이핑 단계에서 type-only import 강제는 인지 비용만
2. **data/ 폴더는 원본 Lua dict와 1:1 대응** — Python + regex로 30초 변환. 손 변환 0
3. **render/ 폴더는 LÖVE의 `graphics.*` API와 1:1 매핑 (PixiJS)** — `push/pop` → `Container.addChild/removeChild`, `Sprite ↔ drawImage`, `Graphics.rect ↔ fillRect`
4. **game/ 폴더는 Entity-Component 패턴** — LÖVE의 GameObject 추상 클래스 + 상속
5. **LÖVE의 `local` 의존성은 TS에서는 `import/export`로** — v0.1.8/v0.1.10 교훈
6. **DPR 스케일링 명시** — PixiJS `autoDensity: true` + `resolution: devicePixelRatio` 2줄. 빠뜨리면 1/dpr 크기로 작게 보임
7. **모드팩 i18n (T() + lang/ko.json)** — LÖVE와 동일 아키텍처 결정. 게임의 어떤 텍스트도 `T('key', 'default')`로
8. **첫 빌드 + Vercel deploy 후 `curl -w "%{size_download}"` bit-perfect 검증** — LÖVE 빌드와 동일 패턴
9. **`setCameraPos` 호출 위치 = drawWorld 안에서** — update 안에서만 호출하면 카메라가 (0, 0)에 고정되어 뱀이 화면 밖으로 사라짐 (v0.1.12 snkrx-web 실측)
10. **boot-time 자산 로드는 loadOptional + Sprite/Graphics fallback** (★ 2026-07-23 추가, 가장 자주 만남) — Promise.all + throw하면 화면 안 그려짐
11. **dev server 띄울 때 `| tee ... &` 절대 금지** (★ 2026-07-23 추가) — Hermes terminal wrapper에 갇혀 멈춤. `background=true` + `watch_patterns` 사용
12. **풀 게임 한 장 카드는 만들지 말 것** (★ 2026-07-23 추가) — 4-5장 단위로 분해. 정지 화면 1장 → 좌표/골격/뱀/적/UI 5장
13. **작업자 review-required 보고는 검증 후 신뢰** (★ 2026-07-23 추가) — commit + build + dev server 200 OK 모두 확인 후 강제 complete
14. **모든 LÖVE PNG는 먼저 PIL로 RGBA 변환** (★ 2026-07-23 추가, 가장 은폐된 함정) — PixiJS v8은 팔레트 PNG를 텍스처로 디코딩 못함. ffmpeg/sips 회피, Hermes venv Python의 PIL로 `color_type=6` 변환
15. **작업자 patch 루프 신호 감지** (★ 2026-07-23 추가) — 로그에 `preparing patch…`가 16-30회+ 반복되면 진전 없는 루프로 판단. 즉시 kanban reclaim + 더 작은 카드로 재분할 또는 사용자 직접 처리
16. **PixiJS v8 `Assets.load` 캐시 트랩 회피** (★ 2026-07-23 추가) — `Assets.load`는 디코딩 실패를 영구 캐시. `Texture.from(htmlImageElement)` + 모듈 스코프 `HELD_TEXTURES` 배열로 우회. 첫 프레임 후 `sprite.texture.width` 0이면 캐시/GC 문제. 텍스처 디버깅 패턴: `img.onload`에서 `img.naturalWidth === 0` 체크 + `tex.width === 0` 체크
17. **에르메스 칸반 CLI 응답 필드 주의** (★ 2026-07-23 추가) — `kanban create --json`은 `task_id`가 아니라 **`id`** 필드 반환. `kanban link`는 **`parent_id child_id`** 순서 (parent 먼저). `kanban reclaim`은 **`running`** 상태에서만 작동
18. **시각 검증 게이트 분리 운영** (★ 2026-07-23 추가) — 자동 검증 카드는 Telegram 알림 구독 안 함, Hermes 운영자가 commit/build/curl 검증 후 강제 complete. 시각 검증 카드만 사용자 알림 + 사용자 Playtest 대기
19. **막히면 fix 전에 광범위 로깅을 먼저** (★ 2026-07-23 사용자 명시 요청) — `[snkrx]` prefix 로그로 BOOT/LOAD/DRAW/VERIFY 단계 모두 감싸기. 빌드 통과 + HTTP 200 + 텍스처 정상 + Sprite 정상인데 화면에 안 그려지는 경우, 로그 없는 fix 시도는 시간 낭비. 먼저 console 출력을 사용자에게 받아서 진단
20. **가장 안정적인 텍스처 경로: `Assets.load(url)`** (★ 2026-07-23 추가, PixiJS 공식 스킬 기준) — `Texture.from(canvas)`나 `Texture.from(imageData)` 같은 우회 경로는 PixiJS v8의 비동기 GPU 업로드 / GC / 캐시 트랩에 빠질 수 있음. 정석은 **`await Assets.load(url)`**. 부팅이 안 되면 fix 시도 전에 **공식 스킬 `pixijs/pixijs-skills/pixijs-assets` 설치**하고, [CRITICAL] 섹션 가이드를 따를 것. `loadOptional` wrapper로 감싸서 텍스처 실패가 부팅 전체를 막지 않도록 하기. `HELD_TEXTURES`나 `HELD_IMAGE_DATA` 같은 모듈 스코프 보관 배열은 Assets.load 사용 시 **불필요** (Assets가 캐시 관리).
21. **뱀 본체 추적: chain-follower (누적 거리)** (★ 2026-07-23 추가, SNKRX v0.1.0 실측) — 단순 history 스냅샷(매 frame head 위치를 기록하고 i번째 본체 = history[i])은 **회전 시 본체가 직선으로 늘어짐**. 원본 LÖVE의 snake는 누적 거리 기반: 각 본체 마디는 head로부터 정확히 i*spacing 떨어진 거리를 유지하며, 매 frame마다 직전 마디/head로부터의 거리를 보정. PixiJS 구현:
    ```ts
    update(dt) {
      // head 진행
      this.head = { x: this.head.x + dx, y: this.head.y + dy }
      // chain-follower 보정
      let prevX = this.head.x, prevY = this.head.y
      for (let i = 0; i < this.segments.length; i++) {
        const cur = this.segments[i]
        const ddx = cur.x - prevX, ddy = cur.y - prevY
        const dist = Math.hypot(ddx, ddy) || 1
        const scale = this.spacing / dist
        const newX = prevX + ddx * scale
        const newY = prevY + ddy * scale
        this.segments[i] = { x: newX, y: newY }
        prevX = newX; prevY = newY
      }
    }
    ```
    회전 시 segments가 head의 회전 궤적을 따라 자연스러운 곡선으로 추적됨. spacing은 SNAKE_TILE(16)보다 큰 24-32px이 적절.
22. **시각 디버깅: sprite 확대 + tint로 GPU 업로드 검증** (★ 2026-07-23 추가) — 텍스처가 만들어졌지만 Sprite가 안 보일 때, sprite를 96x144로 키우고 `tint = 0xff0000` (빨강) 적용. 화면에 빨간 사각형이 보이면 GPU 업로드 작동, 안 보이면 렌더 파이프라인 문제. **원본 sprite가 작거나 단색이라 시각적으로 안 보이는 경우와 GPU 업로드 실패를 구분하는 유일한 방법**.
23. **작업자 auto-decomposition(specify) 충돌 처리** (★ 2026-07-23 추가) — 작업자가 큰 카드를 받으면 `kanban_specify` / `kanban_decompose`로 자동 분해해 5-7장의 세분화 카드를 만들 수 있음. 이때 **원본 카드도 todo로 돌아가고**, 분해된 카드가 자동 추가됨. **이 상황에서 운영자는 분해된 카드들을 `archive`로 일괄 정리**하고, **사용자가 직접 처리 중인 파일(예: src/snake.ts)이 충돌하지 않도록 작업자 프로세스 중단** (`kill -TERM <pid>`). `kanban_specify`가 만든 카드들은 자동 card body가 원본 spec과 충돌하는 경우가 많음 (예: chain-follower vs 90° 회전+accumulator).
24. **Telegram 알림 구독은 task 단위** (★ 2026-07-23 추가) — board 단위가 아니라 task 단위로 `hermes kanban notify-subscribe <task_id> --platform telegram --chat-id <id> --notifier-profile default`. 자동 검증 카드는 구독 안 함, **시각 검증 카드만 구독**. 이전 세션처럼 모든 카드에 구독하면 알림 폭주로 사용자가 무시하게 됨.
25. **시각 디버깅: tint + scale로 GPU 업로드 vs 렌더 문제 분리** (★ 2026-07-23 추가) — sprite가 안 보일 때 다른 fix 시도 전에 Sprite를 크게 키우고(예: 96x144) **눈에 띄는 tint**(예: 0xff5577 분홍) 적용. 화면에 색깔 사각형이 보이면 GPU 업로드 정상, 안 보이면 GPU/렌더 파이프라인 문제. 원본 sprite가 작거나 단색일 때(예: snkrx warrior.png 40x60, 2400픽셀 중 485개만 색) 시각적으로 안 보일 뿐 GPU는 정상일 수 있음. 전체 패턴: [`references/visual-debug-tint-and-scale.md`](references/visual-debug-tint-and-scale.md)
26. **작업자 auto-decomposition(specify) 충돌** (★ 2026-07-23 추가) — 작업자가 큰 카드를 받으면 `kanban_specify`/`kanban_decompose`로 자동 분해해 5-7장 카드를 만들 수 있음. **원본 카드도 todo로 돌아가고**, 분해된 카드가 자동 추가됨. **이때 분해된 카드는 자동 card body가 원본 spec과 충돌**하는 경우가 많음 (예: chain-follower spec vs 90° 회전+accumulator spec). **운영자 처리**: 분해된 카드들을 `archive`로 일괄 정리 + **사용자가 직접 처리 중인 파일(예: src/snake.ts)이 충돌하지 않도록 작업자 프로세스 중단** (`kill -TERM <pid>`).
27. **TDZ ReferenceError in setupBattleSystem 패턴** (★ 2026-07-23 추가) — `let` 변수를 선언하기 전에 같은 함수에서 그 변수를 참조하면 `ReferenceError: Cannot access 'X' before initialization`. WaveManager가 `let`로 선언된 상태에서 `setupBattleSystem`이 그 변수를 호출하면 발생. **해결**: 변수 선언을 함수의 가장 위로 이동하거나 `const` + 즉시 초기화로 변경. 또는 변수를 wrapper class/object에 넣어서 선언 시 null로 초기화.
28. **Snake가 화면 밖으로 나갈 때 reflect로 안쪽 튕김** (★ 2026-07-23 추가, SNKRX 원본 동작) — 원본 LÖVE는 snake head가 480x270 경계를 넘으면 heading의 x 또는 y 성분을 `π - heading`으로 반사하고 head를 화면 안으로 clamp. PixiJS 구현:
    ```ts
    update(dt) {
      // head 진행
      this.head = { x: this.head.x + dx, y: this.head.y + dy }
      // 경계 반사
      if (this.head.x < 0) { this.head.x = 0; this.heading = Math.PI - this.heading }
      else if (this.head.x > LOGICAL_WIDTH) { this.head.x = LOGICAL_WIDTH; this.heading = Math.PI - this.heading }
      if (this.head.y < 0) { this.head.y = 0; this.heading = -this.heading }
      else if (this.head.y > LOGICAL_HEIGHT) { this.head.y = LOGICAL_HEIGHT; this.heading = -this.heading }
    }
    ```
    snake가 가장자리에서 안쪽으로 자연스럽게 튕기며 이동. 단순히 head를 clamp만 하면 snake가 경계에 붙어 정지하는 느낌이 듦.
29. **원본 LÖVE sprite는 생각보다 단순** (★ 2026-07-23 발견) — SNKRX의 `warrior.png`는 40x60 PNG에 **2400픽셀 중 485개(20%)만 흰색**, 나머지 80%는 투명. 흰색 픽셀은 **직사각형 + 가운데 가로선** 모양. 이게 **뱀의 한 마디 sprite**. 원본 LÖVE는 이 마디를 여러 개 이어 붙여서 뱀 본체를 만듦. **따라서 1개의 warrior.png를 "캐릭터"로 기대하지 말 것** — 40x60 단일 sprite로는 캐릭터가 안 보임. **sprite가 단순한 건 정상이므로 tint+scale 진단과 함께 사용자가 직접 픽셀 분포를 확인** (`PIL.Image.open().getdata()`로 nonzero 픽셀 카운트).

29.5. **호버 spring 진동 함정 (★ 2026-07-23 Phase 5-8 발견)** — LÖVE의 `on_mouse_enter` → `spring:pull(0.1)` → 1.0 복귀 진동 패턴을 그대로 이식하면, **미세한 마우스 움직임에 spring이 toggle되어 카드가 0.97 ↔ 1.03 진동 (≠ 0.1 → 1.0)** — 사용자가 "카드가 미세하게 커졌다 작아졌다"고 표현. **증상**:
- 미세 마우스 움직임마다 spring 새 target = 0.1 → 1.0으로 toggle
- spring damping 미적용으로 1.0 복귀 진동 + 다음 enter로 또 0.1 → 1.0
- 결과: 카드 크기 0.97 ~ 1.03 사이 미세 진동
- 호버 영역에 들어가면 줄어들다 안 보이고, 떼면 다시 1.0으로 복귀

**해결 — 호버 효과를 정적 alpha 변화로만** (★ 2026-07-23 SNKRX Phase 5-8 적용):

```ts
// ❌ WRONG — spring 진동 (card sizes 0.97 ↔ 1.03 미세 변동)
hoverEnter(id) {
  c.spring.activeTarget = 0.1
  c.phase = 'hovered'
}

// ✅ CORRECT — spring target 변경 안 함, phase 만 변경 (visual 변화 없음)
hoverEnter(id: string): void {
  void id  // no-op 또는 alpha/색만 변경
}
```

**규칙**: 미세 마우스 움직임에 sprite가 미세하게 변동되면 **spring 진동 의심**. **진단을 위해 호버 효과를 완전히 비활성화**한 후, 사용자가 "안 변한다"고 확인하면 다시 정밀하게 만들기. **PixiJS 환경에서 spring 기반 호버 효과는 가급적 정적 효과로 대체** — alpha 변화, glow filter, cursor 변화 등.

29.6. **snake head radius 시각 검증 정밀도 보정 (★ 2026-07-23 SNKRX Phase 4-5b 발견)** — 초기 snakeHeadRadius = 8 (SNAKE_TILE=16의 외접원 절반)이지만, 사용자가 "snake가 적에 살짝만 닿아도 HP가 깎이는지 확인하기 어렵다"고 피드백. **해결**: radius 8 → 12로 키워서 **접촉 판정 박스를 시각적으로 명확한 정도**로 확장. 작은 원형 충돌(8px)은 sprite가 16x16 정사각형이라 시각적 sprite와 충돌 박스 갭이 커서, sprite를 살짝 스쳐도 충돌 안 됨. radius 12~14 정도가 sprite 경계와 일치하는 느낌. **이 값은 사용자 시각 검증을 통해 결정** — 8(너무 작음) / 16(너무 커서 sprite가 적 안에 박힘) 사이에서 12~14가 적절.

```ts
// ❌ WRONG — sprite보다 너무 작은 radius (8) — sprite 스쳐도 충돌 안 됨
const snakeHeadRadius = 8

// ✅ CORRECT — sprite 외접원의 75% (12~14)
const snakeHeadRadius = 12
```

**시각 검증 정밀도 보정 절차** (★ 사용자 명시 선호): (1) 초기값으로 빌드 → 사용자 브라우저 강력 새로고침 → (2) 미세 마우스 이동으로 sprite가 적에 닿는지 확인 → (3) 안 닿으면 radius +2, 너무 빨리 닿으면 -2. (4) 사용자 OK 시점의 값이 **사용자 환경에 맞는 정밀도**.

## Patch-loop worker rescue 3가지 옵션

```python
# ❌ WRONG — `id` 필드를 못 찾음
result = subprocess.run(['hermes','kanban','create','...','--json'], capture_output=True)
task_id = json.loads(result.stdout)['task_id']  # KeyError!

# ✅ CORRECT — `id` 필드
task_id = json.loads(result.stdout)['id']
```

```python
# ❌ WRONG — 인자 순서 뒤집힘 (자식이 parent_id, parent가 child_id)
subprocess.run(['hermes','kanban','link',child_id, parent_id])

# ✅ CORRECT — parent_id 먼저
subprocess.run(['hermes','kanban','link',parent_id, child_id])
```

```bash
# ❌ WRONG — reclaim은 running 상태에서만
hermes kanban reclaim t_xxx  # cannot reclaim: not running or unknown id

# ✅ CORRECT
hermes kanban unblock t_xxx --reason '...'  # blocked → ready
hermes kanban archive t_xxx                  # ready/done → archive
hermes kanban reclaim t_xxx                  # running → ready
```

```bash
# ❌ WRONG — `--reason` 플래그 미지원 (positional)
hermes kanban block t_xxx --reason 'bug'

# ✅ CORRECT — positional
hermes kanban block t_xxx 'bug description'
```

```bash
# ❌ WRONG — Python subprocess로 hermes 호출 시 글로벌 argv가 깨질 수 있음
# hermes는 --yolo, --safe-mode 같은 플래그를 글로벌 argv에 자동 추가하기도 함
# subprocess 호출이 "unrecognized arguments" 에러로 실패할 수 있음

# ✅ CORRECT — 가능하면 terminal 도구나 hermes kanban tools (kanban_create 등) 사용
# Python subprocess는 fallback으로만
```

**Python 자동화 권장 패턴**: `subprocess.run` 결과가 exit code 2면 CLI 사용법 변경 가능성. `hermes kanban <verb> --help`로 먼저 확인.

## 사용자 명시 선호 (★ 2026-07-23)

- **★ 사용자 위임 패턴 (2026-07-23 명시)**: 사용자가 "나머지는 위임할께"라고 하면 — **위임할 모든 카드를 미리 생성하고 의존성 체인으로 연결**. 사용자가 직접 처리하려던 카드(예: 사운드)도 **카드로 만들어둠**. 카드 구조 자체가 작업 명세서이고, "사용자가 한다 / 작업자가 한다"는 런타임 선택. 사용자가 "사운드는 내가 처리"라고 했어도 카드만 만들고, 사용자가 원하면 작업자에게 위임하거나 직접 처리. **즉시 모든 카드를 등록하는 이유는**: (1) 의존성 그래프가 한 번에 보여서 작업 흐름이 명확, (2) 작업자가 자동으로 다음 카드를 dispatch, (3) 사용자가 직접 처리할 카드는 unblock/complete 액션으로 명시적으로 표시. **카드 분할은 작업 단위**, 사람 단위가 아님.
- **"혹시 쓸만한 픽셀js 스킬이 있다면 설치후 진행해줘"** — 사용자는 **blind fix 시도 전에 skill hub에 관련 스킬이 있는지 확인하고 설치**하라고 명시적으로 요청. 일반화: **부팅 실패 / 자산 로드 실패 / 무언가 안 될 때, 첫 번째 행동은 `hermes skills search <keyword>` + `hermes skills install`로 공식/커뮤니티 스킬 확인**. 스킬의 [CRITICAL] 섹션에 정답이 이미 있을 가능성을 항상 고려.
- **"콜솔에서 더많은 정보를 수집할 수 있도록 로그를 추가해보는게 어때?"** — 사용자는 **fix 시도 전에 광범위 로깅을 먼저** 선호. 일반화: 빌드 통과 + HTTP 200 + 텍스처 정상 + Sprite 정상인데 화면에 안 그려지는 상태에서, 로깅 없는 fix 시도는 시간 낭비. **먼저 console 출력을 사용자에게 받아서 진단**. [snkrx] prefix 로깅 템플릿 (BOOT/LOAD/DRAW/VERIFY) + 200ms 후 비동기 검증 패턴 사용.
- **"작업자 patch 루프 신호"는 사용자가 직접 처리** — `preparing patch…` 16-30회+ 반복 시 사용자가 "작업이 블록된 것 같은데, 상황을 보고해" 식으로 묻는 패턴. 이때 kanban 로그/heartbeat/runs를 확인하고, 30분+ 같은 긴 정지 시 `kanban reclaim` + 더 작은 카드로 재분할. 단일 파일 fix는 운영자가 직접 코드를 보는 게 더 빠름.
- **★ Playwright는 사용자가 직접 (★ 2026-07-23 명시)**: 사용자가 "플레이라이트로 테스트해야할 것은 가능한 나에게 확인해달라고해"라고 명시. 해석: macOS 환경에서 작업자가 Playwright Chromium 시각 검증에 자주 갇혀 stuck됨. **시각 검증이 필요한 카드는 사용자가 직접 브라우저 강력 새로고침으로 확인**. 작업자에게 Chrome headless 자동 검증을 맡기지 말 것. 작업자 카드 body에 "Chrome headless/Playwright 시각 검증 시도 금지"를 명시. 운영자 rescue 패턴은 [`references/worker-monitoring-and-mac-playwright-trap.md`](references/worker-monitoring-and-mac-playwright-trap.md) 참조.
- **"어려운 작업이 아닐꺼데, 너무 오래걸리는 것 같아. 이상없는지 체크해줘"** (★ 2026-07-23 명시) — 단일 파일 fix 같은 단순 작업이 20분+ 걸리면 작업자가 갇힌 신호. 운영자는 uptime/%CPU/heartbeat를 확인하고 즉시 옵션 A (직접 수정) 또는 B (reclaim + 분할) 선택. 5분+ stuck이면 kill -TERM으로 중단.
- **"내가 확인해야할 것이 뭔지 어떻게 확인해야하는지 구체적으로 알려줘"** (★ 2026-07-23 명시) — 사용자가 시각 검증 카드를 받았을 때, 운영자는 **"무엇을" + "어떻게" 확인해야 하는지 구체적 단계**로 알려야 함. 일반적인 "OK면 unblock"이 아니라: (1) 어떤 URL을 열고, (2) 무엇을 보고, (3) 어떤 동작이 정상이면 OK, 어떤 동작이 비정상이면 보정 카드. 예: "URL http://127.0.0.1:5173/?test=1, 뱀이 적에 닿으면 HP가 5/5 → 4/5로 깎이고 0.5초 깜빡임, GAME OVER 표시되면 OK". 사용자가 "이상 없음"이라고 회신할 때까지 카드 done 처리 보류. 이 패턴은 `playwright 자동 검증 금지` 선호와 결합되어 — 사용자가 직접 브라우저 강력 새로고침으로 확인하는 게 가장 신뢰할 수 있는 검증 경로.

**Operator verification checklist before kanban_complete (★ 2026-07-23 SNKRX 실측, 매 카드마다):**

```text
1. git log -1 --stat — 작업자 commit 확인
2. git show HEAD — 실제 diff 검토 (작업자 보고와 일치하는지)
3. npm run build (또는 npm test) — 산출물 컴파일 검증
4. dev server + curl /assets/X.png HTTP 200 — 정적 자산 응답 검증
5. git status --short — untracked 파일 잔재 확인 (public/, docs/ 등)
6. 모두 통과 → kanban complete 또는 다음 카드 dispatch
7. 실패 → kanban reclaim + 더 작은 카드로 분할 OR 운영자가 직접 수정
```

**작업자가 죽으면 untracked 변경사항이 디스크에 남음** — 다음 dispatch 전에 `git add -A && git commit` 또는 `rm -rf` 처리. 그렇지 않으면 다음 카드가 conflicting state로 시작.

## Patch-loop worker rescue 3가지 옵션** (★ 2026-07-23 추가, 속도 순):

```text
1. 운영자가 직접 수정 (단일 파일 fix에 가장 빠름)
   - snkrx-web src/main.ts 부트가 47분+ 막혔을 때, 운영자가 직접 5분 만에 수정
   - loadOptional + Texture.from + HELD_TEXTURES 패턴 적용
   - 절차: kill -TERM <worker_pid> → read_file → patch (직접 edit) → terminal `npx tsc --noEmit && npm run build` → git add -A && git commit -m '...' → git push origin main → `hermes kanban complete <task_id> --summary '...'`. **Patch-loop + Playwright stuck에 가장 효과적** (2026-07-23 SNKRX Phase 5-2 사례: 작업자가 18분+ tsconfig 경고 분석에 stuck → 운영자가 kill + 직접 main.ts 수정 5분 + commit + 카드 완료로 1-2시간 절약)

2. Reclaim + 카드 분할 (실패 모드가 불명확할 때)
   - `hermes kanban reclaim <id>`
   - archive 후 2-3장 더 작은 카드로 재생성
   - 예: 정지 전투 장면 1장 → 5장 (좌표/골격/뱀/적/UI)

3. Reassign (다른 프로필이 더 잘할 때만)
   - `hermes kanban reassign <id> <other-profile> --reclaim`
   - 단, 동일 setup에 다른 profile이 있을 때만 의미 있음
```

**Patch-loop 신호 감지**: 로그에 `preparing patch…` 16-30회+ 반복 + `npx tsc --noEmit` 통과나 `git commit` 성공이 없으면 진전 없는 루프.

**5분+ stuck 즉시 옵션 1 (직접 수정) 권장 임계값** — 단순한 fix가 5분+ 걸린다는 것은 작업자가 잘못된 방향으로 가고 있다는 신호. 2026-07-23 사용자가 "어려운 작업이 아닐꺼데, 너무 오래걸리는 것 같아. 이상없는지 체크해줘"라고 명시적으로 알렸던 패턴과 일치.

## 상세 디버깅 가이드

증상별 진단 ("회전만 됨", "90도만 움직임", "적이 안 보임" 등) + 디버깅 로그 패턴 + LÖVE → Canvas 2D 매핑표는 → [`references/debug-checklist.md`](references/debug-checklist.md) 참조.

**2026-07-23 추가 자료**:
- [`references/boot-time-asset-load-trap.md`](references/boot-time-asset-load-trap.md) — Promise.all 자산 로드 트랩 진단/수정 (가장 자주 만남)
- [`references/kanban-card-decomposition.md`](references/kanban-card-decomposition.md) — 풀 게임 카드를 4-5장 단위로 분해하는 규칙, Hermes 운영자 검증 단계, dev server wrapper trap, 작업자 사망 시 정리 패턴
- [`templates/pixijs-boot-with-fallback.ts`](templates/pixijs-boot-with-fallback.ts) — loadOptional + Sprite/Graphics fallback 패턴 전체 구현
- [`templates/png-palette-to-rgba.py`](templates/png-palette-to-rgba.py) — LÖVE 팔레트 PNG → RGBA PNG 일괄 변환 스크립트 (PIL 기반, ffmpeg/sips 함정 회피)
- [`references/asset-conversion.md`](references/asset-conversion.md) — 팔레트 PNG 변환 전체 절차, 검증 명령, PixiJS 부팅 진단
- [`references/pixijs-texture-bootstrap-diagnosis.md`](references/pixijs-texture-bootstrap-diagnosis.md) — ★ PixiJS v8 부팅 정석 코드 (Assets.load + loadOptional + autoStart + ticker.start) + 부팅 함정 6종 우선순위 표 + 절대 하지 말 것 / 반드시 할 것 + 부팅 후 검증 로그 템플릿. 부팅 안 될 때 이 reference 그대로 적용
- [`references/snake-chain-follower.md`](references/snake-chain-follower.md) — ★ 뱀 본체 추적 알고리즘 (단순 history 스냅샷 vs 누적 거리 chain-follower). 회전 시 직선 vs 곡선 추적 비교, chain-follower PixiJS 구현 코드, spacing 선택 가이드 (24-32px), 사용자 진단 인용 (2026-07-23)
- [`references/visual-debug-tint-and-scale.md`](references/visual-debug-tint-and-scale.md) — ★ GPU 업로드 vs 렌더 파이프라인 진단 분리: tint+scale로 분홍/하늘색 큰 사각형을 그려 Sprite가 안 보일 때 GPU 업로드 실패인지 렌더 문제인지 좁힘. 사용자 진단 인용 (2026-07-23)
- [`references/snkrx-2026-07-23-session-arc.md`](references/snkrx-2026-07-23-session-arc.md) — 2026-07-23 SNKRX v0.1.0~v0.4.0 한 세션의 실제 시간순/결정/작동-작동하지않음 패턴. 다른 LÖVE 게임 포팅 세션이 같은 함정 순서로 막히는지 비교/교훈 추출용.
- [`references/worker-monitoring-and-mac-playwright-trap.md`](references/worker-monitoring-and-mac-playwright-trap.md) — ★ 2026-07-23 SNKRX 세션에서 작업자가 macOS Playwright Chromium에 갇혀 20~60분+ stuck 패턴. 운영자 rescue 절차 (uptime/%CPU 모니터링 → 옵션 A: 직접 수정 / B: reclaim / C: 노트 추가). **사용자 명시 선호**: Playwright 검증이 필요한 카드는 사용자가 직접 확인.
- [`references/hermes-kanban-cli-quirks.md`](references/hermes-kanban-cli-quirks.md) — `hermes kanban` CLI의 알려진 함정: `id` not `task_id`, `kanban link` parent_id 먼저, `reclaim`은 running만, `block`은 positional. Python 자동화 시 자주 만남.
- [`references/test-mode-via-url-query.md`](references/test-mode-via-url-query.md) — `?test=1` URL 쿼리 파라미터로 사용자가 시각 검증할 수 있게 하는 패턴. git revert 위험 없이 테스트 모드. 작업자 self-revert 안티패턴 + 해결.
- [`references/snkrx-2026-07-23-operator-rescue.md`](references/snkrx-2026-07-23-operator-rescue.md) — **★ Operator rescue menu** (Tier 1: 직접 수정 5분 / Tier 2: reclaim + 분할 / Tier 3: wait & monitor), 5분 stuck rule, card body anti-stuck patterns, Vite dev `NODE_ENV=development` 자동 활성화 버그 (production-dev sentinel fix), worker's `kanban_specify/decompose` 자동 분해 충돌, Phase 5 e2e 완료 패턴, user explicit preferences 종합.

## LÖVE → Web 비교표

| LÖVE 11.5 | Web (TS + Canvas 2D) | 비고 |
|---|---|---|
| `love.window.setMode(1280, 720)` | `<canvas width=1280 height=720>` + DPR scale | 명시적 |
| `love.graphics.rectangle(x,y,w,h,color)` | `ctx.fillRect(x-w/2, y-h/2, w, h)` | center-aligned |
| `love.graphics.print(text, font, x, y)` | `ctx.fillText(text, x, y)` | 폰트는 web font (Noto Sans KR 등) |
| `love.graphics.push()/pop()` | `ctx.save()/restore()` | 동일 |
| `love.image.newImage(path)` | `new Image(); img.src = path` | Promise 비동기 |
| `love.event.push('keypressed', key)` | `keydown` listener | 직접 매핑 |
| `love.run` (메인 루프) | `requestAnimationFrame` loop | 동일 |
| `love.timer.step()` (dt) | `(performance.now() - lastTime) / 1000` | 직접 계산 |
| `love.filesystem.read(path)` | `fetch(path).then(r => r.text())` | 비동기 |
| `love.audio.newSource(...)` | `new Audio(src)` 또는 Web Audio API | |
| `Font:has_cjk(text)` | `/\\p{Script=Hangul}/u.test(text)` | Unicode property |
| `love.run` UTF-8 byte iteration | `for (const ch of text)` (ES6 iterator) | ★ byte → code point |
| `love.system.getClipboardText()` | `navigator.clipboard.readText()` | Promise |

## Vercel 배포 (정적 호스팅)

**LÖVE 게임은 ~80-130MB** (스프라이트 + 사운드) → **Vercel 무료 티어 한도 (100GB 대역폭/월) 충분**. **로딩 시간 1-3초** (4G).

```bash
cd /Users/mac/work/snkrx-web
npm run build
# → dist/ 폴더에 번들

# vercel.json (★ 정적 호스팅은 outputDirectory: "dist" 필수)
{
  "buildCommand": "npm run build",
  "outputDirectory": "dist",
  "framework": "vite",
  "rewrites": [{ "source": "/(.*)", "destination": "/index.html" }]
}

vercel deploy --prod --yes --token $(cat ~/.hermes/secrets/vercel_token.txt)
# → https://{project-name}.vercel.app
```

**alias suffix 점유 맵 + 충돌 회피**: `references/canvas-static-site-pipeline/SKILL.md` §7.5.3.2 참조 (LÖVE 게임 port도 동일 패턴).

## 학습 기록

- **2026-07-21**: LÖVE SNKRX → TypeScript + Canvas 2D 포팅 8단계 완료. ~5시간 작업. 84개 영웅 + 16개 클래스 + 84개 패시브 + 213개 한글화 키 + 게임 코어 + 상점 + 아레나 + HUD + 빌드 + 로컬 서버 (HTTP 200). npm run build → 36.80 kB JS (gzip 10.42 kB).
- **2026-07-21**: v0.1.8/v0.1.10의 `local` 함수 의존성 함정이 TS 포팅에서도 그대로 등장 (모듈 분리 → import).
- **2026-07-21**: TypeScript strict 옵션 (verbatimModuleSyntax, noUnusedLocals) 4대 항목 비활성화. 빠른 프로토타이핑에 strict는 인지 비용.
- **2026-07-21**: Canvas 2D의 `ctx.scale(dpr, dpr)` 1줄이 LÖVE의 자동 DPI 매핑 대체. 빠뜨리면 화면 절반 크기로 작게 보임.
- **2026-07-21**: 모드팩 i18n 패턴이 LÖVE와 TS 모두에서 작동 — `T(key, default)` + `lang/<code>.json` 통합은 LÖVE Lua와 TS 양쪽에 적용.
- **2026-07-21**: Python regex로 84개 영웅 1초 변환 — 손 84줄 적을 필요 없음. **Lua → TS 포팅의 가장 큰 효율화**.
- **2026-07-21**: `setCameraPos` 호출 위치 함정 — `Arena.update` 안에서만 호출하면 `Arena.draw` 시점에 카메라가 (0, 0)에 고정. 뱀이 회전만 하고 화면 밖으로 사라지는 증상. **해결**: `drawWorld()` 안에서 명시적 호출. 0.5초 간격 한 줄 디버깅 로그가 "이동 안 함 vs 이동하지만 화면 밖" 구분에 효과적.
- **2026-07-21**: 빌드 산출물 36.80 kB (gzip 10.42 kB)는 놀라울 정도로 작음 — 데이터 + 게임 코어가 모두 TS로 컴파일되어 효율.
- **2026-07-23**: Vite dev NODE_ENV=development 자동 활성화 트랩 — `?test=1` URL 쿼리 사용 시 dev server에서 `import.meta.env.NODE_ENV='development'` 자동 매칭으로 test mode가 자동 활성화되어 일반 모드에서 projectile이 발사되지 않음. **해결**: 'production-dev' sentinel로 dev server에서 자동 매칭 회피.
- **2026-07-23**: 작업자 self-revert 안티패턴 — "테스트 모드 적용" 카드를 만들 때 같은 카드 안에서 `commit A` + `commit B revert`로 끝나면 사용자에게 변화 없음. **해결**: 본문에 "revert 금지" 명시 + 두 카드로 분리 (적용/해제).
- **2026-07-23**: "내가 확인해야할 것이 뭔지 어떻게 확인해야하는지 구체적으로 알려줘" — 시각 검증 카드에 대해 (1) URL (2) 무엇을 보고 (3) 정상/비정상 동작을 구체적 단계로 안내하는 사용자 선호. "OK면 unblock" 같은 일반 지시는 부족.
- **2026-07-23 (세션 후반 추가 교훈)**:
  - **TDZ ReferenceError in setup/initialize 함수 패턴** — `let` 변수를 같은 함수 안에서 다른 helper가 참조하는 구조는 거의 항상 TDZ(Temporal Dead Zone) 위험. `updateHud()`가 `setupBattleSystem()` 본문에서 호출되고 `let waveManager`가 그 호출 뒤에 선언되면 `ReferenceError: Cannot access 'waveManager' before initialization`로 부팅 실패. **해결**: `let` → `const` + 즉시 초기화, 또는 선언을 함수 최상단으로 이동, 또는 wrapper class/object. **신호**: 콘솔에 `ReferenceError: Cannot access 'X' before initialization (anonymous) → at updateHud`. PixiJS 부팅이 첫 프레임 후 멈추고 canvas에 placeholder만 그려질 때 의심.
  - **작업자 self-revert 안티패턴** — "테스트 모드" 카드를 만들 때 작업자가 **같은 카드 실행 내에서 `commit A` + `commit B revert`**로 끝낼 수 있음. 결과: 카드는 `done`이지만 사용자가 `?test=1` URL을 열어도 변화 없음. **신호**: `git log`에서 두 commit이 짧은 시간(수 분) 안에 revert 관계로 등장. **해결 카드 패턴**: (1) 본문에 "revert 금지, 사용자가 OK 할 때까지 유지"를 명시. (2) **두 카드로 분리** — 카드 1: "테스트 모드 적용" (원본 보존), 카드 2: "테스트 모드 해제 + 원본 복구" (사용자 OK 후, 별도 카드).
  - **snake-적 접촉 이벤트 밸런스** — 원작 LÖVE의 적 maxHp 75-130 + projectile damage 25면 적이 발사체 4-6번에 죽어서 **snake가 닿기 전에 적이 사망** → contact event 트리거 안 됨 → 사용자가 "접촉 데미지 확인 어려움" 피드백. **균형 가이드**: 적 사망까지 ~5초, snake가 적 도달까지 ~3초가 되도록. 적 maxHp을 200-500으로 올리거나 projectile damage를 5-10으로 낮춤. 또는 적 spawn 후 1.5초 invulnerable 추가.
  - **카드 분할은 사람 단위가 아닌 작업 단위 (사용자 명시)** — 사용자가 "사운드는 내가 처리" / "나머지는 위임할께"라고 하면, **사용자가 직접 처리하려는 카드도 미리 만들어둠** (위임 카드와 동일하게 의존성 그래프에 연결). 카드 구조 자체가 작업 명세서이고, "사용자가 한다 / 작업자가 한다"는 런타임 선택. **즉시 모든 카드를 등록하는 이유**: (1) 의존성 그래프가 한 번에 보여서 작업 흐름이 명확, (2) 작업자가 자동으로 다음 카드를 dispatch, (3) 사용자가 직접 처리할 카드는 unblock/complete 액션으로 명시.
- **2026-07-23 (v0.1.0+ PixiJS 재시작, Kanban 도입)**: Canvas 2D 대신 PixiJS v8 채택 — LÖVE의 graphics.* API와 1:1 매핑이 더 자연스럽고 셰이더/파티클/블렌드 모드 이식이 Canvas 2D보다 훨씬 간단함.
- **2026-07-23 (v0.2+ 체인-팔로워 뱀 + 화면 경계 튕김)**: 단순 history 스냅샷은 회전 시 직선으로 늘어짐 → 누적 거리 chain-follower로 변경. 화면 경계에서 안쪽으로 튕기도록 reflect 추가. WarManager TDZ ReferenceError 수정. tint+scale 시각 디버깅 기법 확립. 팔레트 PNG → RGBA 변환, Assets.load 정석, 모듈 스코프 HELD_TEXTURES 보관 패턴 등 PixiJS v8 자산 로드 정석 확정.
- **2026-07-23**: Hermes Kanban 보드 `snkrx-web` 생성, `default` 프로필에 배정, Telegram `chat_id: 8359527845` 알림 구독 설정. 8장 카드로 시작 (기준선 → 스캐폴딩 → DPR → 폰트 → 이미지 → 정지 화면 v1~v4 → 첫 Playtest → 첫 전투 계획).
- **2026-07-23**: 카드 분해 규칙 — "정지 전투 장면" 1장 카드는 47분+ 16+회 patch 후에도 끝나지 않음 (`npm run dev | tee ... &` 백그라운드 wrapper에 갇힘). 5장 분할 (좌표·데이터 / 화면 골격 / 뱀+영웅 / 적+HP바 / UI 골격+비교)로 재구성.
- **2026-07-23**: 작업자 review-required 패턴 — 모든 자동 검증 카드의 작업자가 마지막에 `kanban_block(review-required: ...)`로 정지. **Hermes 운영자가 직접 검증 (commit + build + dev server curl) 후 kanban complete로 강제 종료** 필요.
- **2026-07-23**: **boot-time Promise.all 자산 로드 트랩** — `Promise.all([Assets.load(...), Assets.load(...)])`로 두 텍스처 묶어서 로드했는데, 코드 변경 정상 + 빌드 통과 + HTTP 200 OK임에도 사용자가 "이 상태에서 안넘어감" + "PixiJS 초기화 중..." 텍스트만 본 증상. **해결**: `loadOptional` wrapper + Sprite/Graphics fallback. **빌드 성공 ≠ 부팅 성공 ≠ 화면 표시**.
- **2026-07-23**: 작업자가 죽으면 untracked 변경사항이 디스크에 남음 (`public/assets/images/*.png` 100여 장 등). 다음 dispatch 전에 `git stash -u` 또는 명시적 commit 필요.
- **2026-07-23**: **작업자 patch 루프 패턴** — 작업자가 진전을 못 내면서 같은 파일에 16-30회+ patch를 반복하다가 결국 멈춤. 로그에서 `preparing patch…`가 반복되는 게 신호. **해결**: kanban reclaim + 작업 중단 + 카드를 더 작은 단위로 재분할. 사용자 직접 코드를 봐서 단일 화면을 만드는 게 더 빠를 수도 있음 (2026-07-23 src/main.ts 직접 수정 사례).
- **2026-07-23**: **PixiJS v8 팔레트 PNG 함정 (★ 가장 은폐된 함정)** — LÖVE가 저장한 PNG는 모두 `color_type=3` 8-bit colormap. PixiJS는 이를 텍스처로 디코딩 못해 빈 Sprite만 그려짐 (사용자: "이 상태에서 안넘어감"). curl/HTTP 200/PixiJS 로그 모두 정상이지만 화면에 흰 십자선/placeholder만 보임. **해결**: PIL로 모든 PNG를 `color_type=6` RGBA로 변환. macOS 시스템 Python의 PIL은 깨져있어 Hermes venv Python 사용 필수 (`/Users/mac/.hermes/hermes-agent/venv/bin/python`). `ffmpeg`/`sips`는 색 변환 시 80x120으로 2배 확대되거나 변환 실패 — 회피.
- **2026-07-23**: **PixiJS v8 `Assets.load` 텍스처 캐시 트랩 (★★ 가장 진단 어려운 함정)** — PixiJS v8의 `Assets.load`가 동일 URL의 텍스처 디코딩 실패를 **캐시에 영구 저장**. 팔레트 PNG → RGBA PNG 변환 후에도 같은 URL을 다시 요청하면 캐시된 실패(`{err: 'not found'}`)를 그대로 반환. cache-bust 쿼리(`?t=Date.now()`)도 prefix 매칭으로 우회 실패 사례 있음. **해결**: `Assets.load` 경로를 완전히 우회해서 `new Image()` + `Texture.from(img)` 패턴 사용. 그러나 `Texture.from(img)` 결과는 **PixiJS 내부 캐시에 등록되지 않아 다음 GC에서 사라짐** → 모듈 스코프 `HELD_TEXTURES: Texture[]` 배열에 명시적 보관 필수. 첫 프레임 후 `setTimeout`으로 `sprite.texture.width` 검증 → `textureW=0`이면 캐시/GC 문제 진단.
- **2026-07-23**: **에르메스 칸반 CLI 함정** — (1) `kanban create --json` 응답 필드는 `task_id`가 아니라 **`id`** (Python 스크립트에서 `d['task_id']` → KeyError). (2) `kanban link` 인자 순서는 `parent_id child_id` (**parent 먼저**). Python 스크립트가 `(child, parent)` 순서로 호출하면 의존성 그래프가 거꾸로 됨. (3) `kanban reclaim`은 **`running` 상태에서만 작동**, blocked/archived는 `unblock` 또는 `archive`로 처리. (4) `kanban block`은 `--reason "..."` 플래그가 아니라 **positional** (`kanban block <task_id> <reason...>`).
- **2026-07-23**: **칸반 카드 시각 검증 게이트 운영 규칙** — 자동 검증 카드(PixiJS 스캐폴딩, DPR, 폰트, 이미지)는 작업자가 `review-required`로 멈추면 **Hermes 운영자가 직접 검증 후 강제 complete** (commit + build + dev server curl 200 확인). 시각 검증 카드(정지 화면 재현, 첫 Playtest)만 사용자 알림 발송. 이전 세션의 "매 카드마다 멈춤 → 사용자 호출" 패턴은 **과잉 알림**이며, 시각 검증 카드만 알림이 오는 게 정답.
- **2026-07-23**: **에르메스 칸반 알림 구독 설정** — `hermes kanban notify-subscribe <task_id> --platform telegram --chat-id <id> --notifier-profile default`. board 단위가 아니라 **task 단위** 구독. 자동 검증 카드는 구독 안 함, 시각 검증 카드만 구독.
- **2026-07-23**: **★ 작업자 Playwright 시각 검증 함정 (가장 자주 발생, 4-5회 만남)** — 작업자가 시각 검증 단계에서 `chrome-automation` skill을 호출하면 macOS에서 Playwright Chromium이 페이지를 비정상 종료(`page/context/browser has been closed`, `unhandled errors in a TaskGroup`)하고, 작업자는 `session_search`로 대안을 찾으면서 15-30분 stuck. **증상**: `tail -f .../logs/<task_id>.log`에 `⚙️ proc poll proc_xxx` 또는 `chrome-automation` 로드 후 진전 없음, CPU 0-2% but status `running`. **해결 2가지**:
    1. **카드 body에 "Playwright/chrome-automation 시각 검증 시도 금지. 자동 검증은 tsc/build/test만. 시각 검증은 사용자가 한다."** 를 명시. 가장 안전.
    2. **이미 stuck인 경우**: `ps aux | grep t_<taskid>`로 PID 확인 → `kill -TERM <pid>` → `hermes kanban reclaim <id> --reason "playwright stall"` → 운영자가 직접 `read_file + patch + npm run build + git commit && git push origin main + heremes kanban complete` 로 직접 처리. 2026-07-23 SNKRX 세션에서 4번+ 작업자가 Playwright에 갇혀 stuck. `chrome-automation` skill이 **default toolsets에 포함되어 있어** 작업자가 부주의로 호출하기 쉬움. **카드 body에 명시적 금지 + 작업자 프로세스 모니터링**이 운영자 기본 동작.
- **2026-07-23 (세션 후반, 광범위 로깅 채택)**: 사용자가 "콜솔에서 더 많은 정보를 수집할 수 있도록 로그를 추가해보는게 어때?" 명시 요청 → `[snkrx]` prefix로 BOOT/LOAD/DRAW/VERIFY 4단계 모두 감싼 진단 템플릿 채택. 결과: `rendererType=1 (webgl)`, `child[0].textureW=40 textureH=60`, `child[0].visible=true alpha=1` 모두 정상으로 확인됨 → 텍스처/스프라이트는 정상이지만 화면에 안 그려지는 상태로 좁힘. **사용자 선호: 막히면 fix 전에 광범위 로깅을 먼저**.
- **2026-07-23 (세션 마지막)**: 가장 안정적인 텍스처 경로로 **`ImageData → Texture.from(imageData)`** 채택. `Image` 경로(`Texture.from(image)`)는 Image GC 시 텍스처 사라짐. `Canvas` 경로(`Texture.from(canvas)`)는 PixiJS v8의 CanvasSource 비동기 GPU 업로드 실패 사례. `ImageData`는 BufferSource 인터페이스로 직접 GPU 업로드 → 가장 안정적. `HELD_IMAGE_DATA: ImageData[]` 모듈 스코프 보관으로 GC 방지. PixiJS v8의 `Texture.from(buffer, { width, height })` 두 번째 인자는 더 이상 지원 안 함 (`boolean | undefined`만 받음). ImageData는 자체 width/height를 가지므로 별도 전달 불필요.
- **2026-07-21**: 빌드 산출물 36.80 kB (gzip 10.42 kB)는 놀라울 정도로 작음 — 데이터 + 게임 코어가 모두 TS로 컴파일되어 효율.
