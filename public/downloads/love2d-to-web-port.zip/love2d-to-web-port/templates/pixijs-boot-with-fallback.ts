// PixiJS 부팅 + 자산 로드 fallback 패턴 (★ 2026-07-23 v0.1.0+)
// Promise.all로 텍스처 묶어서 로드하지 말 것. 한 개라도 실패하면 throw하고
// 캔버스가 안 그려짐. 항상 loadOptional + Sprite/Graphics fallback 사용.
//
// 이 패턴은 references/boot-time-asset-load-trap.md 참조.

import { Application, Assets, Graphics, Sprite, Texture } from 'pixi.js'

const LOGICAL_WIDTH = 1280
const LOGICAL_HEIGHT = 720

type LoadedTextures = {
  player: Texture | null
  enemy: Texture | null
}

async function loadOptional(url: string): Promise<Texture | null> {
  try {
    return await Assets.load<Texture>(url)
  } catch (error) {
    console.warn(`[snkrx] 텍스처 로드 실패 (${url}):`, error)
    return null
  }
}

export async function boot(): Promise<void> {
  const root = document.querySelector<HTMLElement>('#game-root')
  if (!root) throw new Error('게임 루트 요소를 찾을 수 없습니다.')

  const app = new Application()
  await app.init({
    width: LOGICAL_WIDTH,
    height: LOGICAL_HEIGHT,
    backgroundColor: 0x1c1c22,
    antialias: false,
    autoDensity: true,
    resolution: window.devicePixelRatio || 1,
  })
  root.appendChild(app.canvas)

  // 텍스처 일부가 실패해도 화면은 항상 그린다.
  const textures: LoadedTextures = {
    player: await loadOptional('/assets/images/warrior.png'),
    enemy: await loadOptional('/assets/images/speed_booster_elite.png'),
  }
  addBattleDemo(app, textures)

  Object.assign(window, { snkrxApp: app })
}

function addBattleDemo(app: Application, textures: LoadedTextures): void {
  // 1) 배경은 app.init의 backgroundColor로 이미 채워짐

  // 2) 중앙에 플레이어 (스프라이트 or 빨간 박스 fallback)
  const playerTexture = textures.player
  const playerWidth = 24
  const playerHeight = 36
  const playerX = LOGICAL_WIDTH / 2 - playerWidth / 2
  const playerY = LOGICAL_HEIGHT / 2 - playerHeight / 2

  if (playerTexture) {
    const player = new Sprite(playerTexture)
    player.width = playerWidth
    player.height = playerHeight
    player.x = playerX
    player.y = playerY
    app.stage.addChild(player)
  } else {
    const placeholder = new Graphics()
    placeholder.rect(0, 0, playerWidth, playerHeight).fill(0xe53935)
    placeholder.x = playerX
    placeholder.y = playerY
    app.stage.addChild(placeholder)
  }

  // 3) 우측 상단에 적 (스프라이트 or 파란 박스 fallback)
  const enemyTexture = textures.enemy
  const enemyWidth = 24
  const enemyHeight = 36
  const enemyX = LOGICAL_WIDTH - enemyWidth - 16
  const enemyY = 16

  if (enemyTexture) {
    const enemy = new Sprite(enemyTexture)
    enemy.width = enemyWidth
    enemy.height = enemyHeight
    enemy.x = enemyX
    enemy.y = enemyY
    app.stage.addChild(enemy)
  } else {
    const enemy = new Graphics()
    enemy.rect(0, 0, enemyWidth, enemyHeight).fill(0x1e88e5)
    enemy.x = enemyX
    enemy.y = enemyY
    app.stage.addChild(enemy)
  }

  // 4) 적 머리 위 HP 바
  const hpBar = new Graphics()
  hpBar.rect(0, 0, 32, 3).fill(0x66666e)
  hpBar.rect(0, 0, 24, 3).fill(0xe53935)
  hpBar.x = enemyX + (enemyWidth - 32) / 2
  hpBar.y = enemyY - 6
  app.stage.addChild(hpBar)
}

void boot().catch((error: unknown) => {
  console.error('[snkrx] boot 실패:', error)
})