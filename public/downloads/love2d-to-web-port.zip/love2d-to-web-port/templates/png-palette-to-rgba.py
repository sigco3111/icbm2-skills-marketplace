#!/usr/bin/env python3
"""
LÖVE 팔레트 PNG (color_type=3) → RGBA PNG (color_type=6) 일괄 변환.

PixiJS v8 브라우저 PNG 디코더는 팔레트 PNG를 텍스처로 디코딩 못해 빈 Sprite만 그려짐
(이른바 "스프라이트 placeholder 흰 십자선" 함정). 이 스크립트는 모든 팔레트 PNG를
RGBA로 변환해서 PixiJS가 정상 텍스처로 인식하도록 만든다.

WHY PIL:
  - macOS 시스템 /usr/bin/python3의 PIL은 import 시 깨져 있음
    (`cannot import name '_imaging' from 'PIL'`).
  - Hermes venv Python (/Users/mac/.hermes/hermes-agent/venv/bin/python)이 정상 PIL 보유.
  - macOS sips / ffmpeg은 색 변환 시 80x120으로 2배 확대되거나 일부 palette PNG에서 변환 실패.
  - PIL은 원본 크기(40x60) 그대로 RGBA로 안전하게 변환.

사용:
  HERMES_PY=/Users/mac/.hermes/hermes-agent/venv/bin/python
  $HERMES_PY templates/png-palette-to-rgba.py \
      --src  /Users/mac/work/snkrx-clone/assets/images \
      --dst  /Users/mac/work/snkrx-web/public/assets/images

검증:
  python3 -c "import struct; b=open('warrior.png','rb').read(); print('ct=',b[25],'w=',struct.unpack('>I',b[16:20])[0],'h=',struct.unpack('>I',b[20:24])[0])"
  → ct= 6 w= 40 h= 60  (color_type=6 RGBA, 원본 크기 유지)
"""
from pathlib import Path
import argparse
import sys

try:
    from PIL import Image
except ImportError:
    sys.stderr.write(
        "PIL not available. Use Hermes venv Python:\n"
        "  /Users/mac/.hermes/hermes-agent/venv/bin/python templates/png-palette-to-rgba.py ...\n"
    )
    sys.exit(2)


def color_type(path: Path) -> int:
    """PNG color_type을 IHDR에서 읽어옴 (1 byte at offset 25)."""
    return path.read_bytes()[25]


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Convert LÖVE palette PNGs to RGBA in-place.")
    p.add_argument("--src", required=True, type=Path,
                   help="Source directory (원본 LÖVE assets/images).")
    p.add_argument("--dst", required=True, type=Path,
                   help="Destination directory (web-project public/assets/images).")
    p.add_argument("--dry-run", action="store_true",
                   help="변환 없이 통계만 출력.")
    return p.parse_args()


def main() -> int:
    args = parse_args()
    src_dir: Path = args.src
    dst_dir: Path = args.dst

    if not src_dir.exists():
        sys.stderr.write(f"Source directory not found: {src_dir}\n")
        return 1
    dst_dir.mkdir(parents=True, exist_ok=True)

    files = sorted(dst_dir.glob("*.png"))
    total = len(files)
    converted = 0
    copied = 0
    skipped_passthrough = 0
    missing_source = 0
    failed = []

    for dst in files:
        src = src_dir / dst.name
        if not src.exists():
            missing_source += 1
            failed.append((dst.name, "no source"))
            continue

        sb = src.read_bytes()
        sct = sb[25]

        if sct != 3:
            # 원본이 팔레트가 아니면 그대로 복사 (혹시 잘못된 80x120 결과 덮어쓰기)
            if args.dry_run:
                copied += 1
            else:
                dst.write_bytes(sb)
                copied += 1
            skipped_passthrough += 1
            continue

        if args.dry_run:
            converted += 1
            continue

        try:
            im = Image.open(src)
            if im.mode != "RGBA":
                im = im.convert("RGBA")
            im.save(dst, format="PNG", optimize=True)
            # 검증: color_type 6이고 원본 크기 유지
            tb = dst.read_bytes()
            if tb[25] != 6:
                failed.append((dst.name, f"output ct={tb[25]} expected 6"))
                continue
            converted += 1
        except Exception as e:
            failed.append((dst.name, str(e)[:80]))

    print(f"total={total} converted={converted} copied(copied from non-palette src)={copied} "
          f"missing_source={missing_source} failed={len(failed)}")
    if failed:
        sys.stderr.write("FAILED:\n")
        for name, err in failed[:20]:
            sys.stderr.write(f"  {name}: {err}\n")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())