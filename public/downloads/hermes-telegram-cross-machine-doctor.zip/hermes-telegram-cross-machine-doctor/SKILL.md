---
name: hermes-telegram-cross-machine-doctor
description: Use when two or more macOS/Linux Hermes Agent instances on the same LAN both report Telegram bot unreachability, OR when one machine's Telegram gateway hangs at "Connecting to Telegram (attempt 1/N)" or shows main-thread stack ending in select_kqueue_control_impl → kevent() and a sibling machine is available for cross-checking. Protocol distinguishes 4 cross-machine failure classes (token collision, version/mode mismatch, shared .env bot ID, LAN collision) using a 4-Question format that one healthy machine answers for the other. Covers "kevent wait ≠ hang" misdiagnosis, py-spy fallback via /usr/bin/sample, macOS sysctl key corrections (net.inet.tcp.win_scale_factor, not net.inet.tcp.win_scale), Python 3.11 built-in select vs 3.12 cpython-312-darwin.so environment-diff signal, and uvloop-installed-but-not-active gotcha. Distinct from hermes-gateway-doctor (which handles a single machine's gateway hangs); this skill is the multi-machine coordination layer.
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [macos, linux]
metadata:
  hermes:
    tags: [hermes, telegram, gateway, cross-machine, diagnosis, macos, kqueue, sample, py-spy, env-diff]
    related_skills: [hermes-gateway-doctor, hermes-agent, device-environment-migration]
---

# Hermes Telegram Cross-Machine Doctor

## Overview

When **two or more machines on the same LAN** both stop responding to Telegram, the cause is rarely identical symptoms — usually one is the offender and the other is collateral. The fastest path is to **interrogate the healthy machine** with a fixed 4-question protocol that maps each answer to a known failure class.

When a **single machine hangs** at the well-known `select_kqueue_control_impl → kevent()` stack, this skill teaches you that the stack alone is **not** a hang diagnosis — you must cross-check with sibling-machine state and the worker's other thread stacks to know if it is idle or actually stuck.

## When to Use

Trigger when ANY of these are true:

- Multiple machines on same LAN both have Telegram bot unreachability
- One machine asks you to "answer M1's questions" or "interrogate M4" or "check what state our other machine is in"
- User reports a gateway hang with main-thread stack ending in `select_kqueue_control_impl → kevent()` and asks for diagnosis
- User pastes cross-machine sysctl / Python / network questions and asks for matching output from a sibling machine

Do **not** use this skill for:

- Single-machine gateway hangs unrelated to LAN topology → `hermes-gateway-doctor`
- Bot token itself is wrong → just check `.env`
- Bot is banned by Telegram → look for 403/401 in err.log

## The 4-Question Diagnostic Set

Send these to the remote (or local) machine in this order. Each question maps to a single failure class.

### Q1 — Token uniqueness (rules out 409 polling conflict)

```text
지금 네가 텔레그램 봇(@<bot_username>)으로 polling 중이야? 그럼 우리 <OTHER>에서 같은 토큰으로
polling 시도하면 409 충돌이라 <OTHER>가 hang 해. 네 gateway를 잠깐 stop 시킬 수 있어? 그리고
네가 쓰는 토큰의 마지막 6자리가 뭔지 알려줘 (서로 다른 토큰이면 충돌 아님).
```

| Healthy answer | Red flag |
|---|---|
| Different bot ID + different last-6 digits | **Same last 6** → stop the other gateway, that's the conflict |

### Q2 — Gateway mode + environment diff

```text
네가 텔레그램과 연결할 때 polling 모드야 webhook 모드야? 그리고 hermes --version, hermes gateway
status, uname -m, sw_vers, python3 --version 결과를 알려줘. 우리 <OTHER>은 macOS 26.5.2 +
Python 3.11 + Hermes v0.19.0이야.
```

| Healthy answer | Red flag |
|---|---|
| `polling`, same Hermes version, same macOS build | `webhook` set · Python 3.12 vs 3.11 · stale plist warning |

### Q3 — Shared `.env` token

```text
네 ~/.hermes/.env 에서 TELEGRAM_BOT_TOKEN 값을 (마스킹해서) 보여줘. 우리 <OTHER> .env에
<suspect_bot_id>:*** 라인이 자리표시로 의심되는 상태야. 혹시 둘이 같은 봇 ID(<suspect_bot_id>)
토큰을 공유하고 있어?
```

| Healthy answer | Red flag |
|---|---|
| `getMe` returns a **different** bot ID than `<suspect_bot_id>` | Same bot ID in both `.env` files (would force user to mint a second bot via @BotFather) |

### Q4 — Same-LAN confirmation

```text
Wi-Fi 이름이 우리랑 같아? 내부 IP 충돌 가능성도 있어서.
```

| Healthy answer | Red flag |
|---|---|
| Same subnet, no IP collision | DHCP collision or different SSIDs entirely |

## Environment Diff Signals (the answer block Q2 should produce)

When machine B is asked "why does your stack differ from machine A?", these three are the highest-value signals to gather and report back.

### Python version + `select` extension location

```bash
VENV_PY=~/.hermes/hermes-agent/venv/bin/python
"$VENV_PY" -c 'import sys; print(sys.version)'
"$VENV_PY" -c 'import selectors; print(selectors.KqueueSelector.__module__); print(selectors.__file__)'
```

- **Python 3.11 (uv-installed build)**: `select` is **built-in** (`"select" in sys.builtin_module_names`). No `.so` file on disk.
- **Python 3.12 (Homebrew)**: `select` is a **dynamically loaded** C extension; `select.cpython-312-darwin.so` appears in any stack trace.

If machine A and machine B differ here, **that is the most likely cause** of identical "hang at kevent" symptoms. Aligning the venv Python to the same version is the 1st fix.

### asyncio loop + selector class

```bash
"$VENV_PY" -c '
import asyncio
loop = asyncio.new_event_loop()
print(loop.__class__)            # expect _UnixSelectorEventLoop on macOS
print(loop._selector.__class__)  # expect KqueueSelector on macOS
loop.close()
'
```

Both macOS Apple Silicon machines should print the same two classes. Different classes → wrong event loop policy.

### uvloop installed but unused

```bash
"$VENV_PY" -c 'import uvloop; print(uvloop.__version__)'
```

If uvloop is installed but the loop is `_UnixSelectorEventLoop`, **uvloop is not driving the gateway**. The Hermes gateway loop does not use uvloop even when the package is in the venv. Do not assume it does.

## `kevent()` Wait Is NORMAL, Not a Hang

The most common misdiagnosis in cross-machine gateway hangs. A worker Python thread sitting in `_PyEval_EvalFrameDefault → select_kqueue_control_impl → kevent()` is **idle event-loop wait**, not a hang.

**Live evidence (M4 healthy gateway, sampled with `/usr/bin/sample 85304 1`)**:

```text
Thread_5638692 DispatchQueue_1: com.apple.main-thread (serial)
└── select_kqueue_control_impl (in python3.11)
    └── kevent (in libsystem_kernel.dylib)
```

M4 gateway was healthy and answering Telegram messages. Its main thread looked identical to M1's reported "hang". Do not escalate to "deadlock" on this stack alone.

To distinguish **real hang** from **idle wait**, look at adjacent worker threads:

| Other thread state | Interpretation |
|---|---|
| `socket_getaddrinfo → getaddrinfo → mdns_addrinfo → kevent` stuck for minutes | **Real DNS hang** — look at mdns resolver behavior |
| `_PyEval_EvalFrameDefault` for >30s in HTTP retry loops | **Real network issue** — likely sticky fallback IP, see `hermes-gateway-doctor` Step 6 |
| All other threads idle | **Normal idle wait** — not a hang |

## `py-spy` Fallback: `/usr/bin/sample`

`py-spy` is rarely pre-installed. On macOS, `/usr/bin/sample` is always available and gives a usable call graph in seconds.

```bash
# 1-second sample, full Python call graph for the gateway PID
sample <GATEWAY_PID> 1

# Output written to /tmp/python3_<TIMESTAMP>_<HASH>.sample.txt
```

The output is dense (a full image list fills the bottom half) but the top ~50 lines contain the actual call graph for all threads. Filter on `Thread_<N>` headers then read the `+` lines for the actual call stack; ignore the `Binary Image` section.

```bash
# Quick filter for the relevant frames
grep -E 'Thread_[0-9]+|select_kqueue_control_impl|socket_getaddrinfo|getaddrinfo' \
  /tmp/python3_*.sample.txt | head -40
```

## macOS sysctl: The Wrong Key, The Right Key

A frequent cross-machine question asks for `net.inet.tcp.win_scale`. **That key does not exist on macOS.** The correct key is `net.inet.tcp.win_scale_factor`.

```bash
# Will return "unknown oid" on macOS — DO NOT trust this in scripts
sysctl net.inet.tcp.win_scale

# Correct:
sysctl net.inet.tcp.win_scale_factor
# net.inet.tcp.win_scale_factor: 3
```

Related macOS TCP buffer keys that **do** exist:

```bash
net.inet.tcp.mssdflt            # 512 default
net.inet.tcp.delayed_ack        # 3 default
net.inet.tcp.sendspace          # 131072 default
net.inet.tcp.recvspace          # 131072 default
net.local.stream.sendspace      # 8192 default
net.local.stream.recvspace      # 8192 default
```

There is **no `net.core.*` namespace on macOS** — that's Linux-only.

## Output Format When Reporting Back

When you have to forward machine B's findings back to machine A (or to the user), package them as a **flat Q&A block**, not prose. Prose answers get truncated in Telegram and lose structure.

```text
Q1: 토큰 충돌?  →  아니오 (봇 ID 다름, last6=YYYYXX)
Q2: 모드 + 환경 →  polling, Hermes v0.19.0, macOS 26.5.2 (25F84), Python 3.11.15
Q3: .env 공유?  →  아니오 (우리 .env에 너 봇 ID 없음)
Q4: 같은 LAN?   →  같은 서브넷, IP 충돌 없음

스택: select_kqueue_control_impl → kevent() (정상 idle)
Python: 3.11.15 (uv 빌드), select 내장, uvloop 0.22.1 설치되어 있으나 미사용
```

## Common Pitfalls

1. **Asking only Q1 and stopping** — token uniqueness alone doesn't prove the gateway is healthy. The stack-level hang is still real on the failing machine. Always walk all 4 questions.
2. **Trusting `python3 --version` (system Python)** — Hermes runs from `~/.hermes/hermes-agent/venv/bin/python`. Always check the **venv** Python version, not the system one. On M4 the system `python3` was 3.9.6 while the venv Python was 3.11.15.
3. **Reading the kqueue stack alone as "hang"** — see the section above. Sample at least 5 seconds; check adjacent threads.
4. **Forgetting to mask the bot token** — when forwarding back, show `bot_id:***last6` only. Never paste the full token in a Telegram response.
5. **Stopping the wrong gateway** — if Q1 reveals a conflict, stop the **gateway that is not the user's primary**, not the one the user is actively using.
6. **macOS sysctl "unknown oid" treated as failure** — it is normal for `net.inet.tcp.win_scale` and many Linux keys. Use the macOS equivalents listed above.

## Verification Checklist

- [ ] Q1 answered with a different bot ID and last-6
- [ ] Q2 answered with `polling` mode and matching Hermes version
- [ ] Q3 confirmed no shared `.env` bot ID
- [ ] Q4 confirmed same LAN / no IP collision
- [ ] Python venv version compared between machines
- [ ] Stack dump gathered via `sample` or `py-spy`
- [ ] Other thread stacks checked for real-stuck vs idle
- [ ] WARP mode + version reported (if installed)

## Quick Reference: 30-Second Cross-Machine Probe

```bash
# Run on the suspected-healthy machine
TOKEN=$(grep TELEGRAM_BOT_TOKEN ~/.hermes/.env | cut -d= -f2)
echo "=== Bot identity ==="
curl -sS --max-time 6 "https://api.telegram.org/bot${TOKEN}/getMe" \
  | python3 -c 'import json,sys; d=json.load(sys.stdin); r=d.get("result",{}); print(f"id={r.get(\"id\")} username=@{r.get(\"username\")}")'

echo "=== Mode + Webhook ==="
curl -sS --max-time 6 "https://api.telegram.org/bot${TOKEN}/getWebhookInfo" \
  | python3 -c 'import json,sys; r=json.load(sys.stdin).get("result",{}); print(f"webhook={\"set\" if r.get(\"url\") else \"unset\"} pending={r.get(\"pending_update_count\")}")'

echo "=== Environment ==="
hermes --version | head -1
sw_vers | grep ProductVersion
~/.hermes/hermes-agent/venv/bin/python -c 'import sys; print(f"venv python={sys.version.split()[0]}")'

echo "=== Worker state ==="
launchctl list 2>/dev/null | grep -iE "ai\\.hermes"
```

## Related Skills

- `hermes-gateway-doctor` — single-machine gateway hangs (409, sticky fallback IP, plist corruption, single-IP trap). Use after this skill rules out cross-machine causes.
- `hermes-agent` — general Hermes CLI / config / docs reference.
- `device-environment-migration` — for cross-machine **migration** (full env transfer), not just cross-machine **diagnosis** (compare-and-report).