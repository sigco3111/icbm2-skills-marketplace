---
name: godot-dialogue-manager-testing
description: Run headless tests for Godot Dialogue Manager addon.
trigger: When you need to verify Dialogue Manager tests in CI or locally.
version: 1.0.0
author: 혜린
license: MIT
category: godot
---

# Purpose
Provide a reliable workflow to run the automated test suite for the Godot Dialogue Manager addon, with optional C# support handling.

# Steps
1. **Prerequisites**
   - Install Godot 4.7+ (`brew install --cask godot` or download from the official site).
   - (Optional) Install .NET 6 SDK for C# (`brew install --cask dotnet-sdk`).
2. **C# handling**
   - *Disable C#* if not needed to avoid autoload errors:
     ```bash
     patch \
       --mode=patch \
       --path=project.godot \
       --old_string='CSharpState="*res://tests/CSharpState.cs"' \
       --new_string='' 
     ```
   - *Enable C#* by building the assembly:
     ```bash
     dotnet build ./tests/CSharpState.csproj -c Release
     ```
3. **Run headless tests**
   ```bash
   godot --headless --path . -s res://tests/tests.tscn
   ```
   Successful output ends with something like `85 tests with 367 assertions in 3.33s`.
4. **Verification**
   - No `CSharpState` autoload errors.
   - If failures persist, verify the `[autoload]` lines in `project.godot` match your C# setup.

# Pitfalls & Workarounds
- **UI still English** – Locale may not be set to `ko` or translation files missing. Set `locale="ko"` in `project.godot` and ensure Korean entries exist in PO/CSV files under `res://l10n/`.
- **CSharpState autoload error** – occurs when the .dll is missing or the autoload line points to a non‑existent file. Either build the C# project (step 2) or remove the autoload line (step 2‑a).
- **Missing .NET SDK** – Godot will report `no loader found for resource` for C# files. Install the SDK or disable C#.
- **Version mismatch** – the test scene expects Godot 4.7.1 or newer. Older versions may fail to load resources.

# References
- `references/testing.md` – detailed command examples, common error transcripts, and extra notes.
