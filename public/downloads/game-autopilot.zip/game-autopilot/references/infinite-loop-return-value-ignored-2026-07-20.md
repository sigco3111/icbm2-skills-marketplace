# Infinite Loop — Action Return Value Ignored + Pre-Check Missing (2026-07-20)

**Class**: Game autopilot (turn-based strategy)
**Severity**: High — silent infinite loop, no error, log looks "successful"
**Reproduction**: sango-rising-dragons-kr `state.ts` autopilot path

## Real symptom log

```
🤖 #118 관우 🎯 조련 ✓ (금 변화 0) (남은 CP: 2)
🤖 #119 관우 🎯 조련 ✓ (금 변화 0) (남은 CP: 2)
🤖 #120 관우 🎯 조련 ✓ (금 변화 0) (남은 CP: 2)
... repeats forever until browser tab closed
```

User reported: "위임했더니, 해당 로그가 계속 갱신됨" — same action, CP unchanged, but log shows ✓.

## Root cause — 3 simultaneous defects

### Defect 1: `pickBest*` lacks resource pre-check

```ts
// ❌ Before
function pickBestTrain(): AutoAction | null {
  if (G.cp <= 0) return null;
  const my = officersOf(G.playerFaction)
    .filter((o) => !o.acted)
    .sort((a, b) => a.level - b.level || a.exp - b.exp);
  return my[0] ? { kind: 'train', officerId: my[0].id } : null;
}
```

No `G.gold >= 150` guard → returns a doomed target every cycle once gold runs out.

### Defect 2: `stepPlayerAutopilot` ignores action return value

```ts
// ❌ Before
if (a.kind === 'train' && a.officerId) {
  trainOfficer(a.officerId);   // ← return value discarded!
  bus.emit('log', `🤖 #${autoStepIdx} ${officerDef(a.officerId).name} 🎯 조련 ✓ ...`);
  return G.cp > 0;
}
```

`trainOfficer` returns `false` when gold insufficient, but the step always logs ✓.

### Defect 3: `return G.cp > 0` is the only termination signal

Resource-consuming actions (train costs gold, recruit costs gold, develop costs gold) don't change `G.cp` on failure. So when step 2 swallows the `false`, the next call to `stepPlayerAutopilot` re-enters with same CP → `return true` → loop.

## Fix (all 3 together)

```ts
// ✅ After — pickBestTrain with pre-check
function pickBestTrain(): AutoAction | null {
  if (G.cp <= 0) return null;
  if (G.gold < 150) return null;
  const my = officersOf(G.playerFaction)
    .filter((o) => !o.acted && G.gold >= 150)
    .sort((a, b) => a.level - b.level || a.exp - b.exp);
  return my[0] ? { kind: 'train', officerId: my[0].id } : null;
}

// ✅ After — step branches honor return value
if (a.kind === 'train' && a.officerId) {
  if (!trainOfficer(a.officerId)) return false;  // fail → turn ends
  bus.emit('log', `🤖 #${autoStepIdx} ${officerDef(a.officerId).name} 🎯 조련 ✓`);
  return G.cp > 0;
}
```

Same pattern applied to `recruit` and `develop` branches (gold-consuming actions).

## Diagnosis checklist for future infinite-loop reports

When user reports "log keeps repeating" or "action N repeats forever":

| Check | Where | Red flag |
|---|---|---|
| 1. `pickBest*` pre-check | candidate selection function | No `G.gold` / `G.cp` / `G.food` guard before filter |
| 2. Return value usage | step dispatch branch | `액션함수(...)` called without `if (!result) return false` |
| 3. Termination signal | step return | Only `return G.cp > 0` (any resource-failure action can skip CP deduction) |
| 4. Log vs reality | `bus.emit('log', '✓')` | "✓" displayed but CP/gold delta = 0 across cycles |

Any 2 of these = high likelihood of silent infinite loop.

## Why this didn't surface in single-action tests

The bug only fires when **all of**:
- Action fails on the *first* attempt (e.g., gold runs out mid-loop)
- Pick function has no pre-check (always returns a candidate)
- Step branch ignores return value (logs success regardless)

In sango, gold dropped below 150 only after several successful trains → loop kicked in late → user noticed after #118+ cycles.

## Reusable fix pattern (`safeRunAction` helper)

For future game autopilots, recommend a wrapper:

```ts
type Action = () => boolean;  // returns true on success
function safeRunAction(name: string, action: Action): boolean {
  if (!action()) {
    bus.emit('log', `⚠ ${name} 실패 — 자동위임 종료`);
    return false;
  }
  return G.cp > 0;
}

if (a.kind === 'train') return safeRunAction('조련', () => trainOfficer(a.officerId));
```

This collapses defects 2+3 into one place. Pre-check (defect 1) still belongs in `pickBest*` because that's where candidates are filtered.

## Test verification

```ts
// Inject: G.gold = 100, G.cp = 5
// Expected: step returns false on first try, no infinite loop
// Old: infinite loop logging "✓" each iteration
// New: 1 attempt → log "⚠ 조련 실패" → return false → runAutopilotTurn exits
```

## Related

- §3 in `SKILL.md` — setTimeout + march race (different root cause: async, not return-value)
- §3.5 in `SKILL.md` — same fix pattern, abstract level
- ISS-091 (separate) — token recovery → errors 0