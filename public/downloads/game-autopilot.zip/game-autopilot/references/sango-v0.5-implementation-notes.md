# sango-rising-dragons v0.5 Autopilot 구현 노트

2026-07-20 실제 구현 의사결정 + 트러블슈팅 기록. SKILL.md 본문의 보충 참조.

## 결정 큐 진화 과정

### v0.4 (1단계 — 기본 자동위임)
- 4-tier 우선순위: 출정 → 이동 → 수색/조련 → 개발/징병
- `pickBestAttack` 단순 ratio 비교 (threshold 1.4 / 1.0)
- 문제: 출정 후보가 거의 항상 큐 맨 앞 → 다른 액션 거의 안 일어남
- 문제: trainOfficer/recruit/develop 반환값 무시로 무한 루프

### v0.4.1 (무한 루프 fix)
- stepPlayerAutopilot이 함수 반환값 체크하도록 변경
- runAutopilotTurn에 `_depth` 50회 안전 카운터
- 5-tier로 확장: attack → move → search → train → develop/recruit
- setTimeout 60ms → 220ms (로그 가독성)
- march는 `bus.emit('autopilotMarch')` 후 flow.ts가 자동 결산 + runAutopilotTurn 재호출

### v0.5 (2단계 — 풀 자동위임 + 밸런스 C안)
- 출정 점수화: ratio + weaknessBonus + chainBonus
- 부대 합치기 (약한 도시 → 강한 인접 아군)
- 밸런스: 시작 자원 ↑, 적 AI 약화, 시작 보너스

### v0.4.1 롤백 — 전투 위임 제거
- 사용자: "전술전투 위임 제거하자 (이전 롤백)"
- 이유: BattleScene player phase 자동화는 100+ 줄 추가 필요, 게임 의미↓
- 결정: out-of-combat만 자동화, 전투는 사용자 직접

## 무한 루프 디버깅 시퀀스

증상: 로그에 같은 `#N 관우 🎯 조련 ✗ (금 변화 0) (남은 CP: 2)` 반복

```bash
# 1) 함수 정의 직접 확인
grep -A 15 "export function trainOfficer" src/state.ts

# 2) 호출 측 확인
grep -B 2 -A 10 "if (a.kind === 'train'" src/state.ts

# 3) 원인 진단
# trainOfficer(): if (G.gold < 150) { log('⚠ 조련에는...'); return false; }  ← false 반환
# 호출측: const ok = trainOfficer(a.officerId);  // ok는 false인데 무시
#          bus.emit('log', `🤖 ${name} 🎯 조련 ✓ ...`);  // 항상 ✓ 출력
#          return G.cp > 0;  // CP 안 줄어 true → 같은 후보 무한 재시도

# 4) fix: ok 체크 + continue
const ok = trainOfficer(a.officerId);
if (!ok) {
  bus.emit('log', `🤖 #${autoStepIdx} ${officerDef(a.officerId).name} 🎯 조련 ✗ 스킵.`, 'auto');
  continue;  // 다음 후보 시도
}
bus.emit('log', `🤖 #${autoStepIdx} ${officerDef(a.officerId).name} 🎯 조련 ✓ ...`, 'auto');
return G.cp > 0;
```

## 모달 함수 인라인화 패턴

`searchTalent()` (state.ts 원본) — 모달 띄우므로 autopilot 차단:

```ts
// 원본 — 모달 띄움
export function searchTalent(cityId: string, searcherId: string): boolean {
  // ...
  if (Math.random() < chance) {
    bus.emit('modal', {
      title: '인재가 합류합니다!',
      text: `${...}`,
      choices: [{ label: '환영합니다!', effects: [] }],
    });
  }
  // ...
}

// autopilot 버전 — 같은 로직 인라인, 모달 → 로그
const searcher = G.officers[a.officerId];
searcher.acted = true;
G.cp--;
const free = freeOfficersIn(a.cityId);
const pol = effStat(searcher, 'pol');
if (free.length === 0) {
  G.gold += 100;
  bus.emit('log', `🤖 #${i} ${city} 🔍 수색 ✓ 인재 없음, 세금 +100 금`, 'auto');
} else {
  const target = free[Math.floor(Math.random() * free.length)];
  const chance = 0.35 + pol / 200;
  if (Math.random() < chance) {
    target.faction = G.playerFaction;
    bus.emit('log', `🤖 #${i} ${city} 🔍 수색 ✓ ${officerDef(target.id).name} 합류!`, 'auto');
  } else {
    bus.emit('log', `🤖 #${i} ${city} 🔍 수색 — ${officerDef(target.id).name} 영입 실패`, 'auto');
  }
}
return G.cp > 0;
```

## 출정 자동 결산 race 회피

```ts
// state.ts: bus.emit('autopilotMarch', setup) → flow.ts가 받음
// flow.ts: 즉시 autoResolve + applyBattleResult + runAutopilotTurn() 재호출
// state.ts: setTimeout 220ms 후 stepPlayerAutopilot() 호출

// 문제: setTimeout 체인에서 stepPlayerAutopilot이 또 호출되어 같은 march 큐에 들어감
// 해결: pendingMarch flag

// state.ts
let autoStepIdx = 0;

if (a.kind === 'march-attack' ...) {
  bus.emit('autopilotMarch', setup);
  return false;  // 한 step만, march handler가 재호출
}

// flow.ts
let pendingMarch: BattleSetup | null = null;
bus.on('autopilotMarch', (setup) => {
  if (!getAutopilot()) return;
  pendingMarch = setup;
  autoResolve(); applyBattleResult();
  pendingMarch = null;
  runAutopilotTurn();  // 재진입
});

function runAutopilotTurn() {
  setTimeout(() => {
    const more = stepPlayerAutopilot();
    if (more) runAutopilotTurn();
    else if (!pendingMarch) continueAi(0);  // march 처리 끝났을 때만 진행
  }, 220);
}
```

## 점수화 — 출정 선택의 진화

### v0.4 (ratio만)
```ts
const ratio = armyPower(sendTroops, picked) / Math.max(1, armyPower(t.troops, defOff, t.walls));
if (ratio >= threshold && (!best || ratio > best.ratio)) best = { ... };
```

문제: 강한 적만 우선 → 벽 1짜리 적도 안 잡음, 벽 5짜리 강한 적만 → 손해

### v0.5 (점수화)
```ts
const ratio = ...;
const weaknessBonus = (5 - t.walls) * 0.15 + (1 - Math.min(1, t.troops / 12000)) * 0.5;
const estRemaining = Math.floor(sendTroops * 0.5);
let chainBonus = 0;
for (const adj2 of cityDef(adjId).adj) {
  if (adj2 === c.id) continue;
  const t2 = G.cities[adj2];
  if (t2.owner === G.playerFaction) continue;
  const r2pow = armyPower(estRemaining, picked) / Math.max(1, armyPower(t2.troops, officersIn(adj2, t2.owner).map(o=>o.id), t2.walls));
  if (r2pow > 1.4) chainBonus += 0.6;
}
const score = ratio + weaknessBonus + chainBonus;
if (!best || score > best.score) best = { ... };
```

효과:
- 벽 0짜리 적 + 적은 병력 → weaknessBonus 1.15 → 강한 적보다 우선
- 공격 후 인접한 다른 적도 약해짐 → chainBonus 0.6 → 연속 공성 가능

## 사용자 디버그 워크플로

sigco3111은 매 세션 직접 게임 플레이. autopilot이 이상하게 동작하면 콘솔에서 확인:

```js
// 1. 현재 상태 확인
__sango.getG().cities
__sango.getG().gold
__sango.getG().cp

// 2. 특정 도시 확인
__sango.getG().cities['chenliu']
// { id: 'chenliu', owner: 'wei', troops: 8000, farm: 2, market: 1, walls: 2 }

// 3. 자동위임 토글 상태
localStorage.getItem('sango_autopilot_v1')
// '1' = ON, '0' = OFF

// 4. 세이브 자동 정화 확인
__sangoSaveHeal
// { fixedCities: 0, when: '2026-07-20T...' } — 0이면 깨끗

// 5. NaN 디버그 (recruit 후)
__sangoRecruitLog
// { cityId: 'chenliu', before: 6500, after: 8500, gold: 350, food: 1800 }
```

## 사용자 선호 (SKILL.md 본문에서 발췌)

- "어리석다"고 느끼면 재조정 요청 — "적당히 잘하는 AI"보다 "조금이라도 똑똑한 AI" 선호
- 콘솔 결과 보고 → 다음 액션 결정하는 워크플로
- 본인이 매 세션 게임 직접 플레이해서 검증

## 빌드/배포 사이즈 추이

| 버전 | dist/assets JS | index.html |
|---|---|---|
| v0.3 | ~1,510 KB | 12.23 KB |
| v0.4 | ~1,532 KB | 13.11 KB |
| v0.5 | ~1,542 KB | 13.11 KB |

빌드 시간 ~2초. Vercel 강제 redeploy로 새 JS hash 즉시 적용.