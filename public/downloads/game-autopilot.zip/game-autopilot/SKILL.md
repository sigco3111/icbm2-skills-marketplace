---
name: game-autopilot
description: 턴제/전략 게임에 AI 자동 플레이(autopilot)를 추가하는 워크플로 — 결정 큐 결정론 + 안티-무한루프 안전망 + 콘솔 디버그 훅 + 데이터 수정 vs 코드 수정 분리. CK3/EU4/Last Banner/sango-rising-dragons 류 JSON-data 전략 게임에 적용.
---

# 게임 자동위임(Autopilot) 워크플로

## 언제 사용하나

JSON-data 기반 턴제/전략 게임(특히 sigco3111이 Phaser/Godot/HTML로 만드는 fork 게임)에 "사용자가 거의 안 개입해도 엔딩까지 자동 진행"되는 autopilot 토글을 추가할 때. Last Banner(`incremental-game-design-last-banner-event-engine`)와 sango-rising-dragons 두 프로젝트에서 검증된 패턴.

## 핵심 설계 원칙 (4가지 동시 적용)

| # | 원칙 | 이유 |
|---|---|---|
| 1 | **결정 큐(decision queue)를 매 step마다 재계산** | mutable state + 시간 단계 모델 — 이전 step 결과를 반영해 다음 행동 결정 |
| 2 | **모든 step 함수의 boolean 반환값을 절대 무시하지 않음** | 무시하면 `troops += undefined = NaN` 또는 동일 후보 무한 재시도 |
| 3 | **setTimeout 200~250ms 간격** | 사용자가 로그를 한 줄씩 읽을 수 있는 속도 |
| 4 | **콘솔 디버그 훅 제공** | 사용자가 직접 `__sango.getG().cities['chenliu'].troops` 등으로 상태 확인 |

## 5-tier 우선순위 (sango-rising-dragons 패턴)

```
P1 march-attack  — 강한 적지 출정 (ratio 기반 + 점수화)
P2 march-move    — 부대 재배치/합치기
P3 search        — 재야 인재 수색 (modal 함수 호출 금지)
P4 train         — 가장 약한 아군 장수 조련
P5 develop       — 개간/통상/축성/징병 (CP 부족할 때만)
```

각 P는 `pick<P>Action(): AutoAction | null` 함수로 분리. 큐 빌더는 null 무시하고 다음 우선순위로 폴백.

## 결정 큐 빌더 정형 (TypeScript)

```ts
interface AutoAction {
  kind: 'march-attack' | 'march-move' | 'search' | 'train' | 'farm' | 'market' | 'walls' | 'recruit';
  cityId?: string; officerId?: string; targetCityId?: string;
  picked?: string[]; troops?: number;
}

function buildAutopilotQueue(allowRelaxed: boolean): AutoAction[] {
  const q: AutoAction[] = [];
  const atk = pickBestAttack(allowRelaxed);
  if (atk) q.push(atk);
  const mv = pickBestMove();
  if (mv) q.push(mv);
  const sr = pickBestSearch();
  if (sr) q.push(sr);
  const tr = pickBestTrain();
  if (tr) q.push(tr);
  // P5 inline
  for (const c of citiesOf(G.playerFaction)) {
    if (c.farm < 2 && G.gold >= DEV_COST) q.push({ kind: 'farm', cityId: c.id });
    if (c.market < 2 && c.farm >= 2 && G.gold >= DEV_COST) q.push({ kind: 'market', cityId: c.id });
    if (c.troops < 8000 && G.gold >= RECRUIT_COST_GOLD && G.food >= RECRUIT_COST_FOOD) {
      q.push({ kind: 'recruit', cityId: c.id });
    }
  }
  return q;
}
```

## ⚠️ 안티-무한루프 4대 함정 (실전 교훈)

### 1) 함수 반환값 무시 = silent fail → 무한 재시도

```ts
// ❌ 함정: trainOfficer()가 false 반환해도 "성공" 로그 + return true
trainOfficer(a.officerId);
bus.emit('log', `🤖 ${name} 🎯 조련 ✓`);
return G.cp > 0;  // CP 안 줄어 true → 같은 후보 무한 재시도

// ✅ 수정: 반환값 체크 → 실패 시 continue
const ok = trainOfficer(a.officerId);
if (!ok) { bus.emit('log', `🤖 ${name} 🎯 조련 ✗ 스킵.`, 'auto'); continue; }
bus.emit('log', `🤖 ${name} 🎯 조련 ✓ ...`, 'auto');
return G.cp > 0;
```

**증상**: 같은 `#N 관우 🎯 조련 ✗ 금 부족` 로그가 #100까지 반복. `Math.random()*30` 같은 게임 로직이 있어도 fail에서 retry하면 같은 후보 재선택.

### 2) 후보 선택에서 사전 체크 누락

```ts
// ❌ pickBestTrain이 후보를 만드는데 실제로는 gold 부족 → trainOfficer fail
function pickBestTrain() {
  return { kind: 'train', officerId: my[0].id };  // gold 체크 없음
}

// ✅ pick 후보 자체에 사전 체크
function pickBestTrain() {
  if (G.cp <= 0) return null;
  if (G.gold < 150) return null;
  const my = officersOf(G.playerFaction).filter((o) => !o.acted && G.gold >= 150);
  if (my.length === 0) return null;
  return { kind: 'train', officerId: my[0].id };
}
```

### 3.5) 액션 return값 무시 + pre-check 부재 무한루프 (2026-07-20 추가)

```ts
// ❌ trainOfficer()가 false 반환해도 step 분기가 "✓ 성공" 로그 + 다음 step 재호출
if (a.kind === 'train' && a.officerId) {
  trainOfficer(a.officerId);   // return값 안 봄!
  bus.emit('log', `🎯 ✓ (남은 CP: ${G.cp})`);  // 무조건 ✓
  return G.cp > 0;  // ← CP 안 줄면 true → 같은 후보 무한 재시도
}

// ✅ pickBestTrain에 pre-check + step에서 return값 반영
function pickBestTrain(): AutoAction | null {
  if (G.cp <= 0 || G.gold < 150) return null;  // pre-check
  const my = officersOf(G.playerFaction)
    .filter((o) => !o.acted && G.gold >= 150)   // 후보 단계에서도 gold 가드
    .sort((a, b) => a.level - b.level || a.exp - b.exp);
  return my[0] ? { kind: 'train', officerId: my[0].id } : null;
}

if (a.kind === 'train' && a.officerId) {
  if (!trainOfficer(a.officerId)) return false;  // 실패 시 즉시 턴 종료
  bus.emit('log', `🎯 ✓`);
  return G.cp > 0;
}
```

**함정 — 3가지 동시 결함**:
1. **pickBest* 함수에 자원(CP/gold/food) pre-check 부재** → 후보 선택 직후 액션 실패
2. **stepPlayerAutopilot 분기가 액션 함수의 return값 무시** → 실패해도 "성공" 로그 + 다음 step
3. **return `G.cp > 0`만 사용** → 자원 변화 없는 실패 케이스에서 무한 재시도

**증상 (실제 로그)**: `#118 관우 🎯 조련 ✓ (금 변화 0) (남은 CP: 2)` 반복 — 같은 행동 무한 루프

**판별 신호**:
- `pickBest*(...)` 내부에 `G.gold`, `G.cp`, `G.food` 가드가 없음
- step 분기에서 `액션함수(...)` 단독 호출 (return값 미사용)
- 로그에 "✓" 표시가 있는데 CP 변화 0인 케이스가 반복

### 3) setTimeout 비동기 + march 재진입 race

```ts
// ❌ march는 비동기 전투 → stepPlayerAutopilot()이 즉시 return false해도
//    다음 setTimeout이 또 호출되어 같은 march가 두 번 큐에 들어감
function runAutopilotTurn() {
  setTimeout(() => {
    const more = stepPlayerAutopilot();
    if (more) runAutopilotTurn();
    else continueAi(0);  // ← march handler가 또 호출하면 중복
  }, 220);
}

// ✅ pendingMarch flag로 가드
let pendingMarch = null;
bus.on('autopilotMarch', (setup) => {
  pendingMarch = setup;
  autoResolve(); applyBattleResult();
  pendingMarch = null;
  runAutopilotTurn();
});

function runAutopilotTurn() {
  setTimeout(() => {
    const more = stepPlayerAutopilot();
    if (more) runAutopilotTurn();
    else if (!pendingMarch) continueAi(0);  // ← march 핸들러가 안 끝났으면 대기
  }, 220);
}
```

### 4) 안전 카운터 (defense in depth)

```ts
// 50회 시도 넘으면 강제 종료 (어떤 함정이든 결국 멈춤)
function runAutopilotTurn() {
  if ((runAutopilotTurn as any)._depth === undefined) (runAutopilotTurn as any)._depth = 0;
  (runAutopilotTurn as any)._depth++;
  if ((runAutopilotTurn as any)._depth > 50) {
    (runAutopilotTurn as any)._depth = 0;
    bus.emit('log', '🤖 ⚠ 자동위임 안전 종료 (50회 시도 초과).', 'auto');
    continueAi(0);
    return;
  }
  setTimeout(() => {
    if (!busy || G.over) { (runAutopilotTurn as any)._depth = 0; return; }
    // ... 본 로직
  }, 220);
}
// AI 턴 진입 시 reset: continueAi() 첫 줄에서 _depth = 0
```

## 모달 함수 인라인화 (sango searchTalent 실측)

`searchTalent()`가 내부에서 `bus.emit('modal', ...)`로 모달 띄우면 → autopilot이 막힘. **인라인 복제**:

```ts
// ❌ searchTalent() 호출 → 모달 → autopilot 차단
if (search(a.cityId, a.officerId)) return G.cp > 0;

// ✅ 같은 로직 인라인, 모달 대신 로그
const searcher = G.officers[a.officerId];
searcher.acted = true;
G.cp--;
const free = freeOfficersIn(a.cityId);
if (free.length === 0) {
  G.gold += 100;
  bus.emit('log', `🤖 #${i} ${city} 🔍 수색 ✓ 인재 없음, 세금 +100 금`, 'auto');
} else {
  const target = free[Math.floor(Math.random() * free.length)];
  const chance = 0.35 + effStat(searcher, 'pol') / 200;
  if (Math.random() < chance) {
    target.faction = G.playerFaction;
    bus.emit('log', `🤖 #${i} ${city} 🔍 수색 ✓ ${officerDef(target.id).name} 합류!`, 'auto');
  } else {
    bus.emit('log', `🤖 #${i} ${city} 🔍 수색 — ${officerDef(target.id).name} 영입 실패`, 'auto');
  }
}
```

## 점수화 — 단순 ratio 비교 대신

```ts
// ❌ 단순 ratio max
if (ratio >= threshold && (!best || ratio > best.ratio)) best = { ... };

// ✅ weakness + chain bonus 포함
const weaknessBonus = (5 - t.walls) * 0.15 + (1 - Math.min(1, t.troops / 12000)) * 0.5;
const estRemaining = Math.floor(sendTroops * 0.5);
let chainBonus = 0;
for (const adj2 of cityDef(adjId).adj) {
  if (adj2 === c.id) continue;
  const t2 = G.cities[adj2];
  if (t2.owner === G.playerFaction) continue;
  const r2pow = armyPower(estRemaining, picked) / Math.max(1, armyPower(t2.troops, officersIn(adj2, t2.owner).map(o=>o.id), t2.walls));
  if (r2pow > 1.4) chainBonus += 0.6;  // 한 번 더 잡을 수 있음
}
const score = ratio + weaknessBonus + chainBonus;
if (!best || score > best.score) best = { ... };
```

## 콘솔 디버그 훅 패턴

```ts
// main.ts 마지막 줄
(window as any).__sango = { game, bus, getG: () => G };

// recruit 같은 mutation 후에 스냅샷 박기
(window as any).__sangoRecruitLog = { cityId, before, after, gold, food };

// loadGame 후 NaN 복구 시
(window as any).__sangoSaveHeal = { fixedCities: N, when: '2026-07-20T07:48:00Z' };
```

사용자가 콘솔에서 `__sango.getG().cities['chenliu'].troops` 또는 `__sangoSaveHeal` 확인 → 진단 정보. **본인이 매 세션 게임 직접 플레이해서 검증**하는 sigco3111 선호와 시너지.

## 토글 UI 정형

```html
<label class="auto-toggle" id="autoLabel" title="...">
  <input type="checkbox" id="autopilotToggle"> 🤖 자동위임
</label>
```

```css
.auto-toggle { display:flex; align-items:center; gap:6px; padding:4px 10px; border:1px solid var(--panel-edge); border-radius:16px; font-size:12px; cursor:pointer; }
.auto-toggle.on { border-color:#4ea1ff; color:#b6dcff; background:rgba(78,161,255,.12); box-shadow:0 0 12px rgba(78,161,255,.35); }
```

```ts
// state.ts — localStorage 영속화
const AUTOPILOT_KEY = 'sango_autopilot_v1';
let autopilotOn = false;
export function getAutopilot(): boolean { return autopilotOn; }
export function setAutopilot(on: boolean): void {
  autopilotOn = !!on;
  try { localStorage.setItem(AUTOPILOT_KEY, on ? '1' : '0'); } catch {}
  bus.emit('autopilotChanged', autopilotOn);
}
export function loadAutopilot(): boolean {
  try { autopilotOn = localStorage.getItem(AUTOPILOT_KEY) === '1'; } catch { autopilotOn = false; }
  return autopilotOn;
}
```

게임 세이브 키와 **분리** — UI 설정이지 게임 상태가 아님.

## Enter 단축키 (턴 종료) — autopilot과 함께 자주 요청됨

```ts
window.addEventListener('keydown', (e: KeyboardEvent) => {
  if (e.key !== 'Enter') return;
  if (e.shiftKey || e.ctrlKey || e.metaKey || e.altKey) return;
  const tag = (e.target as HTMLElement | null)?.tagName?.toLowerCase();
  if (tag === 'input' || tag === 'textarea' || (e.target as HTMLElement | null)?.isContentEditable) return;
  if (!document.getElementById('modalWrap')?.classList.contains('hidden')) return;  // ★ 모달 무시
  e.preventDefault();
  if (G?.over) return;
  if (!isBusy()) { sfx('click'); endTurn(); }
});
```

**가드 3종 필수**: ① 입력 필드, ② 모달(autopilot뿐 아니라 모든 게임 모달), ③ 조합키. 모달 가드 빼면 출정 모달에서 Enter 누를 때마다 턴 종료됨.

## 데이터 수정 vs 코드 수정 (NaN fix 교훈)

**autopilot이 city.troops += undefined = NaN** 만드는 경로 3가지:
1. `applyEffects('troopsHome')` 핸들러가 `e.v`만 보고 `e.amount` 무시 → ko/events.json의 `amount` 필드 무시 → NaN
2. `recruit`/`trainOfficer`/`develop` 함수 silent fail (위 안티-무한루프 #1)
3. `loadGame` 시 saved state의 troops가 NaN (예전 세이브에 박혀있음)

**해결 패턴 — 데이터와 코드 양쪽 fix**:
```ts
// 1) 데이터: ko/events.json의 `amount` → `v`로 통일 (base 형식)
// 2) 코드: applyEffects 핸들러에 `e.v ?? e.amount ?? 0` + Number.isFinite 가드
// 3) 마이그레이션: loadGame() 시 sanitizeGameState() 1회 자동 정화
function sanitizeGameState(g: any): void {
  const safe = (v: any, fallback = 0) => Number.isFinite(Number(v)) ? Number(v) : fallback;
  g.gold = safe(g.gold, 0);
  g.food = safe(g.food, 0);
  g.cp = safe(g.cp, 0);
  if (g.cities) for (const id of Object.keys(g.cities)) {
    g.cities[id].troops = safe(g.cities[id].troops, 1000);  // NaN → 1,000
    g.cities[id].farm = safe(g.cities[id].farm, 0);
    g.cities[id].market = safe(g.cities[id].market, 0);
    g.cities[id].walls = safe(g.cities[id].walls, 0);
  }
}
```

## 밸런스 조정 (사용자 "어렵다" 신호 시)

| 단계 | 변경 |
|---|---|
| 1단계 (기본값) | 시작 자원 ↑, 개발 비용 ↓, 징병 보너스 ↑ |
| 2단계 (적 AI 약화) | 공성 threshold 1.45→1.7, 빈도 65%→40% |
| 3단계 (시작 보너스) | 수도 성벽 +1, 재야 장수 1명 무료 영입 |

**주의**: 밸런스 C안(위 3단계 전부)을 한 번에 적용하면 **본인이 한참 동안 게임 안 함**. 테스트는 1단계 → 2단계 → 3단계 순서로 점진 적용. 각 단계 후 사용자가 "아직 어렵다" 신호 보내면 다음 단계.

## 전투(turn-based combat)에 autopilot 추가 시 주의

sango-rising-dragons에서는 **전투 위임이 v0.4.1에서 롤백**됨 (사용자 요청). 이유:
- Phaser BattleScene의 player phase를 자동화하려면 100+ 줄 AI agent 필요
- AI가 강해지면 게임 의미가 줄음
- 사용자가 "직접 지휘" 옵션을 위임 OFF일 때 쓰는 게 더 자연스러움

**판단 기준**: autopilot이 **out-of-combat만** 자동화하고 전투는 수동 — sigco3111 사용자가 매 세션 직접 플레이해서 검증하는 워크플로에 적합. 전투까지 자동화 원하면 별도 요청 받을 것.

## 모드 분리 (JSON-data 게임의 강점)

```json
// public/data/manifest.json
{ "packs": ["base", "ko"] }
```

- `base/` = 원본 (중국어, 영어 등)
- `ko/` = 한국어 모드팩 (덮어쓰기)

**packs 순서 함정**: `['ko', 'base']`로 적으면 base가 ko를 덮어씀 → 한자 노출. **반드시 `['base', 'ko']`**. mergeById가 `{...map.get(id), ...e}` 형태라서 **나중 값 우선**.

## 🔗 관련 스킬

- `incremental-game-design-last-banner-event-engine` — 결정 큐 + 자동 진행 패턴 (sango보다 복잡한 케이스)
- `tistory-publisher` — 자동화의 다른 측면 (콘텐츠 발행 자동화)
- `github-trending-duplicate-prevention` — 자동화 워크플로의 품질 검증 패턴

## 관련 references

- `references/sango-v0.5-implementation-notes.md` — sango-rising-dragons v0.4~v0.5 실제 구현 노트 (코드 인용 + 의사결정)
- `references/infinite-loop-return-value-ignored-2026-07-20.md` — §3.5의 실제 진단 사례 (sango #118 관우 무한루프 로그 + 3결함 진단 체크리스트 + `safeRunAction` 헬퍼 패턴)