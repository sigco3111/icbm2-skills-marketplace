---
name: github-trending-duplicate-prevention
description: GitHub 트렌딩 리포지토리 기반 YouTube 영상 제작 시 중복 주제를 방지하기 위한 점수 기반 선정 시스템
category: automation
tags: [github, trending, duplicate-prevention, youtube, automation]
---

# GitHub Trending Duplicate Prevention

## 목적
GitHub 트렌딩 리포지토리 기반 YouTube 영상 제작 시, **동일한 주제가 매일 반복되는 문제**를 해결하기 위한 점수 기반 중복 방지 시스템.

## 문제점
- 인기 프로젝트 (ollama, langchain 등) 가 매일 트렌딩 상위권 유지.
- 영상 제작 시 매번 같은 주제로 제작해야 하는 상황 발생.

## 해결 전략
**점수 기반 선정 시스템** 도입:
- **기본 점수**: 오늘 별점 증가량 × 10
- **신규 리포 보너스**: +50 점
- **최근 등장 패널티**: 
  - 7 일 이내 등장: -30 점
  - 14 일 이내 등장: -10 점
- **빈번 등장 패널티**: 3 회 이상 등장 시 -15 점

## Notion DB 설정
**대상 DB**: `33f76f2e-9097-8176-a537-d40ebb476ef9` (GitHub 트렌딩)

**필요 필드**:
1. `Last_Appeared` (Date): 마지막 등장일
2. `Appearance_Count` (Number): 총 등장 횟수

## 스크립트 수정 (`github_trending_monitor.py`)

### 1. 점수 계산 함수 추가
```python
def calculate_trending_score(repo, db_id):
    """
    리포지토리 점수 계산:
    - 기본 점수: 오늘 별점 증가량 * 10
    - 신규 리포: +50 점 보너스
    - 최근 등장 리포: -30 점 (7 일 이내)
    - 빈번 등장 리포: -10 점 (주 2 회 이상 등장)
    """
    base_score = repo.get("today_stars", 0) * 10
    
    # Notion 에서 과거 데이터 조회
    result = notion_api("POST", f"databases/{db_id}/query", {
        "filter": {"property": "URL", "url": {"equals": repo["url"]}},
        "page_size": 1
    })
    
    penalty = 0
    bonus = 0
    
    if result and result["results"]:
        # 기존 리포
        page = result["results"][0]
        props = page["properties"]
        
        # 마지막 등장일 확인
        last_date = props.get("Last_Appeared", {}).get("date", {}).get("start", "")
        if last_date:
            last_dt = datetime.strptime(last_date, "%Y-%m-%d").replace(tzinfo=KST)
            days_ago = (datetime.now(KST) - last_dt).days
            if days_ago < 7:
                penalty += 30  # 7 일 이내 등장 시 패널티
            elif days_ago < 14:
                penalty += 10  # 14 일 이내는 약간의 패널티
        
        # 등장 횟수 확인
        count = props.get("Appearance_Count", {}).get("number", 0)
        if count >= 3:
            penalty += 15
    else:
        bonus = 50  # 신규 리포 보너스
    
    return base_score + bonus - penalty
```

### 2. 등장 기록 업데이트 함수 추가
```python
def update_appearance_record(repo_url, db_id):
    """리포 등장 기록 업데이트"""
    result = notion_api("POST", f"databases/{db_id}/query", {
        "filter": {"property": "URL", "url": {"equals": repo_url}},
        "page_size": 1
    })
    
    today = datetime.now(KST).strftime("%Y-%m-%d")
    
    if result and result["results"]:
        # 기존 리포: Last_Appeared 업데이트 + Count 증가
        page_id = result["results"][0]["id"]
        current_count = result["results"][0]["properties"].get("Appearance_Count", {}).get("number", 0)
        notion_api("PATCH", f"pages/{page_id}", {
            "properties": {
                "Last_Appeared": {"date": {"start": today}},
                "Appearance_Count": {"number": current_count + 1}
            }
        })
    else:
        # 신규 리포: DB 에 추가 (기존 save_to_notion 로직 활용)
        # ... (기존 코드)
```

### 3. 메인 로직 통합
```python
# 트렌딩 필터링 후 점수 계산
for repo in all_trending:
    repo["score"] = calculate_trending_score(repo, NOTION_DB_ID)

# 점수순 정렬
all_trending.sort(key=lambda x: x["score"], reverse=True)

# 상위 10 개만 선택 (중복 방지 적용 후)
selected = all_trending[:10]
print(f"🎯 최종 선정: {len(selected)}개 (점수 기반 중복 방지 적용)")

for i, r in enumerate(selected, 1):
    print(f" {i}. [{r['language']}] ({r['score']:.0f}점) {r['name']}")

# 등장 기록 업데이트
for repo in selected:
    update_appearance_record(repo["url"], NOTION_DB_ID)
```

## 실행 방법
1. **Notion DB 설정**: `Last_Appeared`, `Appearance_Count` 필드 추가
2. **스크립트 수정**: 위 로직 추가
3. **테스트**: `python3 ~/.hermes/scripts/github_trending_monitor.py --no-notion`
4. **본격 적용**: 크론 잡 자동 실행 (`0 9 * * *`)

## 주의사항
- 패널티 강도 (7 일, -30 점 등) 는 상황에 따라 조정 가능
- 등장 횟수 임계값 (3 회) 은 프로젝트 특성에 따라 변경 가능
- Notion API 호출 수 제한 주의 (필요시 캐싱 활용)

## 결과
- **신규 리포 우선**: 새로운 프로젝트가 높은 점수로 선정
- **과도한 중복 방지**: 7 일 이내 등장한 리포는 점수가 낮아져 하위로 밀림
- **핵심 프로젝트 유지**: 중요한 프로젝트는 7 일 이후 재등장 가능