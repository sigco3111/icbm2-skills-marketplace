---
name: godot-4-i18n-runtime-fallback
description: "Godot 4 한국어 fork 빌드 검증 4단계 + escape hatch."
tags: [godot-4, korean, i18n, popup, combobox, font-fallback, runtime-locale, escape-hatch, ytd2]
---

# Godot 4 한국어 i18n — Runtime fallback 4단계 + escape hatch

**상위 스킬**: `oss-fork-localization` (recipes/godot-4-i18n-preflight.md + 9단계 체크리스트)

**트리거**:
- "popup 한국어 안 보임", "한글 □□□", "runtime locale 안 바뀜", "settings_menu에 한글 옵션 추가 안 됨"
- 5단계 preflight 통과 후에도 빌드 검증 실패

**이 스킬이 필요한 상황**:
- texts.csv ko 컬럼 + texts.ko.translation 생성까지 성공
- Language enum KOREAN 추가 + settings_menu.tscn popup item 4번째 추가
- SystemFont fallback 설정도 했음
- **그런데 게임 실행 시 4번째 옵션 안 보이거나, 한글이 □□□, 또는 한국어 선택해도 즉시 영문**

## 🚨 4단계 순차 검증 (각 단계 통과해야 다음 진행)

### 1단계: 콤보박스 옵션 텍스트가 모두 보이는가

**실패 시나리오**:
- "한국어" 항목이 □□□ 빈 박스로 표시
- 또는 4번째 옵션 자체가 안 보임 (3개만 표시)

**원인 (3가지, 가장 흔한 순서)**:
1. **`item_count = 3` 줄이 .tscn에 남아있음** → popup이 3개로 제한
2. **`theme_override_fonts/font/fallbacks` .tscn inline 문법 오류** → Parse Error, 콤보박스 못 그림
3. **SystemFont .tres의 font_names에 한글 가능한 폰트 없음** → Apple SD Gothic Neo가 macOS에 없어서 fallback

**해결 (확인된 순서)**:
```ini
; settings_menu.tscn에서 [node name="Language"] 블록
[node name="Language" type="OptionButton" ...]
selected = 0
; item_count = N  ← 이 줄 **삭제** (Godot 4는 자동 카운트)
theme_override_fonts/font = ExtResource("1_sys")  ; SystemFont
popup/item_0/text = "English"
popup/item_1/text = "中文"
popup/item_1/id = 1
popup/item_2/text = "Italiana"
popup/item_2/id = 2
popup/item_3/text = "한국어"  ; ← 이게 보임
popup/item_3/id = 3
```

```tres
; resources/theme/wc3_fallback_font.tres
[gd_resource type="SystemFont" format=3]
[resource]
font_names = PackedStringArray("Apple SD Gothic Neo", "Noto Sans CJK KR", "Noto Sans KR", "Arial Unicode MS")
allow_system_fallback = true
```

```ini
; settings_menu.tscn ext_resource
[ext_resource type="SystemFont" path="res://resources/theme/wc3_fallback_font.tres" id="1_sys"]
```

### 2단계: 옵션 선택 시 locale이 바뀌는가

**실패 시나리오**: "한국어" 클릭 → 게임 재시작 안 함 → 다른 메뉴로 가도 여전히 영문

**원인**: `_on_language_item_selected(index)`가 `TranslationServer.set_locale("ko")`만 호출. **UI 갱신 trigger 없음**. 즉 새로 tr() 호출되는 텍스트는 갱신, 이미 그려진 것은 캐시.

**확인 방법**: settings_menu 닫고 title screen으로 → 한국어 적용됐는지 (메뉴 라벨 tr() key로 만들어졌으면 OK)

### 3단계: tr() 결과가 즉시 갱신되는가

**확인 방법**: 게임 재시작 없이 title screen 재방문 → 메뉴 라벨 tr() key면 한국어. 다른 scene으로 전환됐다가 돌아오면 갱신됨.

**갱신 안 되면**: 게임 코드가 `tr("...")` 결과를 `Label.text`로 한 번만 할당하는 패턴. 다국어 앱의 흔한 버그.

### 4단계: 한글이 □□□로 표시되지 않는가

**실패 시나리오**: 한글이 빈 박스 (tofu)로 표시

**원인 + 해결** (위 1단계의 SystemFont fallback이 작동하지 않을 때):
- Friz Quadrata 단독 사용 → 한글 글리프 없음
- `font .import`의 `fallbacks=[]`는 Godot 4에서 작동 안 함 (String → Object 변환 에러)
- `theme_override_fonts/font/fallbacks`는 .tscn inline 불가 (sub_resource 필요)

**검증된 해결**: SystemFont .tres + `theme_override_fonts/font` 직접 할당 (위 1단계 코드).

## 🛑 3가지 escape hatch (4단계 모두 실패 시)

### Escape A: OS locale 강제 (게임 코드 수정 불필요)

```bash
# 한국어 시스템 locale로 게임 시작 → 첫 tr()부터 한국어
LANG=ko_KR.UTF-8 LC_ALL=ko_KR.UTF-8 \
  /path/to/godot --path /Users/mac/work/ytd2-kr \
  res://src/ui/title_screen/title_screen.tscn
```

**macOS에서 ko_KR.UTF-8 없는 경우**:
```bash
# 시스템 환경설정 → 언어 및 지역 → 한국어를 우선순위 1위로
# 또는 터미널에서 임시 설정
export LANG="ko_KR"
export LC_ALL="ko_KR"
```

### Escape B: settings_menu.gd에 reload trigger (1줄 patch)

```gdscript
# src/ui/game_menu/settings_menu.gd의 _on_language_item_selected 끝에
func _on_language_item_selected(index: int) -> void:
    var selected_locale: String = Language.get_locale_from_option(index)
    Settings.set_setting(Settings.LANGUAGE, selected_locale)
    TranslationServer.set_locale(selected_locale)
    # ↓ 추가: 현재 scene을 다시 로드해서 모든 Label 갱신
    get_tree().reload_current_scene()
```

**단점**: settings_menu 자신도 reload → 사용자가 선택 직후 깜빡임. **재선택 필요 가능**.

**더 나은 패턴**: `TranslationServer.set_locale()` 후 `get_tree().call_group("i18n_labels", "refresh_text")` 트리거 (Label 노드들이 subscribe).

### Escape C: default_language를 ko로 (영구, fork 사용자 모두 영향)

```gdscript
# src/enums/language.gd
static var default_language: String = "ko"  # was "en"
```

**부작용**: fork 빌드 사용자 모두 한국어로 시작. PR에는 포함 안 함 (fork 전용).

## 📋 ytd2 실패 회고 (2026-07-28)

**진행**: preflight 5단계 모두 통과 → 169개 한국어 번역 → build 검증에서 **4단계 모두 실패**:
1. 4번째 옵션 텍스트 안 보임 (item_count 잔재 + SystemFont 미적용)
2. 옵션 선택 시 locale 변경 안 됨 (UI reload 없음)
3. tr() 갱신 안 됨 (Label.text 1회 할당)
4. 한글 □□□ (SystemFont fallback 미적용)

**결론**: 프로젝트 종료 결정. 5단계 preflight 통과만으로 fork 가치 보장 안 됨. **빌드 검증 4단계까지 통과해야 진짜 완성**.

## 다음 후보 (빌드 검증 부담 적은 순서)

| 후보 | 한국어 갭 | 빌드 | 빌드 검증 난이도 |
|---|---|---|---|
| **pmotschmann/Evolve** | 22.5% polish 가치 | 브라우저 (빌드 불필요) | 쉬움 (Vercel URL만 확인) |
| **triplea-game/triplea** | 0건 greenfield | Java/Gradle (15분 첫 빌드) | 중간 |
| **00-Evan/shattered-pixel-dungeon** | 7 PR (polish) | Java/libGDX | 중간 (Android asset 다운로드) |
| **Mindustry** | 활발 (번역 잘 됨) | Java | 어려움 (대규모, 차별화 ↓) |
| **Wesnoth** | 진행 중 | C++ | 매우 어려움 (C++ 빌드 함정) |

**1순위 권장**: **Evolve** (브라우저 게임, 빌드 검증 = Vercel URL만 클릭). 

## 사용법

이 스킬은 `oss-fork-localization`의 preflight 후 **빌드 검증 단계에서 호출**:
1. `oss-fork-localization` → preflight 5단계 + 한국어 번역 4단계
2. **이 스킬** → 빌드 검증 4단계 (combo box / locale / tr() / 폰트)
3. 실패 시 3가지 escape (OS locale / reload / default)
4. 모든 escape 실패 → 다른 후보로 (Evolve 추천)
