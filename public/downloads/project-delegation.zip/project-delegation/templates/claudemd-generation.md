# CLAUDE.md 자동 생성 프롬프트

이 프롬프트는 에이전트가 프로젝트를 처음 열 때 CLAUDE.md를 자동으로 생성하도록 합니다.

---

## Claude Code용 (claude -p)

```
이 프로젝트를 분석하고 CLAUDE.md를 생성하세요.

## 분석 순서
1. 디렉토리 구조 파악: find . -type f -name "*.py" -o -name "*.ts" -o -name "*.js" -o -name "*.go" -o -name "*.rs" | grep -v node_modules | grep -v __pycache__ | grep -v .venv | head -80
2. 의존성 확인: cat package.json, cat requirements.txt, cat pyproject.toml, cat go.mod (해당하는 것)
3. 설정 파일 확인: cat .env.example, cat config.yaml, cat Makefile, cat docker-compose.yml (있는 것만)
4. 핵심 파일 5~10개 읽기 (entry point, router, model, config 등)
5. 테스트 구조: find . -name "test_*" -o -name "*_test.*" | head -20

## CLAUDE.md에 포함할 내용

# {프로젝트명}

{프로젝트 한 줄 설명}

## Architecture
{아키텍처 개요 - 패턴, 레이어, 주요 모듈}

## Directory Structure
{주요 디렉토리와 역할 (5~10줄)}

## Key Commands
- Build: {빌드 명령}
- Dev: {개발 서버 실행}
- Test: {테스트 실행}
- Lint: {린트 명령}

## Tech Stack
- Language: {언어, 버전}
- Framework: {프레임워크}
- Database: {DB, 있으면}
- etc: {기타 주요 의존성}

## Code Style
- {indent 규칙}
- {naming convention}
- {기타 중요 컨벤션}

## Environment
- {필요한 환경변수 (실제 값 제외, 이름만)}

## Important Notes
- {에이전트가 알아야 할 주의사항}

## 규칙
- 파일 경로, 함수명, 클래스명은 실제 프로젝트에서 가져올 것
- 추측하지 말고 코드에서 확인할 것
- 50줄 이내로 간결하게
- 시크릿/비밀번호는 절대 포함하지 말 것
```

---

## delegate_task용

```
[CODING AGENT]
프로젝트 구조를 분석하고 CLAUDE.md를 생성하세요.

## 프로젝트 경로
{workdir}

## 분석 방법
1. find . -type f \( -name "*.py" -o -name "*.ts" -o -name "*.js" \) | grep -v node_modules | grep -v __pycache__ | head -80 실행
2. 의존성 파일 읽기 (package.json / requirements.txt / pyproject.toml)
3. 핵심 소스 파일 5~10개 읽기
4. 테스트 파일 구조 확인

## CLAUDE.md 형식
# 프로젝트명
한 줄 설명

## Architecture
## Directory Structure
## Key Commands (build, dev, test, lint)
## Tech Stack
## Code Style (indent, naming, conventions)
## Environment Variables (이름만, 값 제외)
## Important Notes (에이전트 주의사항)

## 규칙
- 실제 코드에서만 정보 추출 (추측 금지)
- 50줄 이내
- 시크릿/비밀번호 절대 포함 금지
- {workdir}/CLAUDE.md에 저장
```
