# 에이전트 프롬프트 템플릿 모음

## Claude Code 프롬프트 템플릿

### T1. 기능 구현
```
## 프로젝트
{project_summary}

## 작업: {task_name}
{task_description}

## 파일
- 생성: {file_paths}
- 수정: {file_paths}

## 요구사항
{requirements_list}

## 제외사항
{exclusions}

## 완료 조건
{completion_criteria}
```

### T2. 버그 수정
```
## 버그 리포트
- 증상: {symptom}
- 재현: {reproduction_steps}
- 에러 로그:
```
{error_log}
```

## 작업
1. 에러 로그에서 루트 카우스 파악
2. 관련 코드 읽기 ({suspect_files})
3. 수정 (최소 변경)
4. 재현 테스트로 확인
5. 회귀 방지 테스트 추가

## 주의
- 다른 기능에 영향 주지 마세요
- 왜 버그가 발생했는지 코멘트로 남겨주세요
```

### T3. 리팩토링
```
## 리팩토링 대상
{target_files_or_modules}

## 현재 문제
{current_problems}

## 목표 구조
{desired_structure}

## 규칙
- 동작은 변경하지 마세요 (behavior-preserving)
- 테스트가 모두 통과해야 합니다
- 한 번에 하나의 리팩토링만 (단계별)
- 각 단계 후 테스트 실행

## 완료 조건
- {refactoring_criteria}
- 기존 테스트 전부 통과
```

### T4. 테스트 작성
```
## 테스트 대상
{target_module_or_file}

## 테스트 프레임워크
{framework} (pytest / jest / vitest 등)

## 커버리지 목표
{coverage_target}

## 커버해야 할 케이스
- 정상 케이스: {happy_paths}
- 에러 케이스: {error_cases}
- 엣지 케이스: {edge_cases}

## 규칙
- 테스트 이름은 동작을 설명해야 함 (test_함수명_상황_기대결과)
- mock은 최소한으로
- 각 테스트는 독립적이어야 함
```

### T5. 코드 리뷰
```
## 리뷰 대상
{files_or_pr}

## 리뷰 기준
- [ ] 기능이 요구사항을 충족하는가?
- [ ] 에러 처리가 적절한가?
- [ ] 보안 이슈가 없는가? (인젝션, 하드코딩된 시크릿 등)
- [ ] 성능 이슈가 없는가? (N+1, 불필요한 루프 등)
- [ ] 테스트가 충분한가?
- [ ] 코드가 읽기 쉬운가?

## 출력 형식
### Critical (반드시 수정)
- ...

### Important (수정 권장)
- ...

### Minor (선택)
- ...

### Verdict: APPROVED / REQUEST_CHANGES
```

---

## delegate_task 프롬프트 템플릿

### D1. 파일 생성/수정
```
[CODING AGENT]
당신은 코딩 전문 에이전트입니다.

## 프로젝트
{project_summary}

## 작업
{task_description}

## 관련 파일
{file_list}

## 규칙
1. 구현 전 기존 코드를 먼저 읽을 것
2. 최소 변경 원칙 (사이드 이펙트 최소화)
3. 완료 후 `python3 -m py_compile {target_file}`로 문법 검증
4. 주석은 한국어로

## 완료 조건
{completion_criteria}
```

### D2. 조사/분석
```
[RESEARCH AGENT]
당신은 기술 리서치 에이전트입니다.

## 조사 주제
{topic}

## 조사 범위
{scope}

## 출력 형식
1. 핵심 요약 (3~5줄)
2. 상세 분석
   - 현재 상태
   - 장단점 비교
   - 추천 방안
3. 참고 출처 (URL 포함)
4. 신뢰도: 높음/보통/낮음

## 언어
한국어로 작성
```

### D3. 설정/인프라
```
[AUTOMATION AGENT]
당신은 자동화/인프라 에이전트입니다.

## 작업
{task_description}

## 대상
{target_path_or_service}

## 규칙
1. 변경 전 현재 상태 백업/확인
2. 한 번에 하나씩 변경
3. 각 변경 후 상태 확인
4. 실패 시 롤백 방법 명시

## 완료 조건
{completion_criteria}
```

---

## 병렬 실행 프롬프트 조합 예시

### 예시: REST API + 프론트엔드 동시 구현
```python
delegate_task(
    tasks=[
        {
            "goal": """[CODING AGENT]
## 작업: User API 엔드포인트 구현
## 파일: src/api/users.py, tests/test_users.py
## 요구사항:
- GET /users — 전체 유저 조회 (pagination)
- POST /users — 유저 생성 (이메일 중복 체크)
- GET /users/:id — 단건 조회 (404 처리)
## 완료: pytest tests/test_users.py -v 전체 통과""",
            "context": "FastAPI 프로젝트, SQLAlchemy ORM, Python 3.11",
            "toolsets": ["terminal", "file"]
        },
        {
            "goal": """[CODING AGENT]
## 작업: User 컴포넌트 구현
## 파일: src/components/UserList.tsx, src/components/UserForm.tsx
## 요구사항:
- UserList: 유저 목록 테이블 (이름, 이메일, 가입일)
- UserForm: 신규 유저 생성 폼 (유효성 검사)
- API: GET/POST /users 호출
## 완료: npm run build 에러 없음""",
            "context": "React + TypeScript, Tailwind CSS, Vite",
            "toolsets": ["terminal", "file"]
        }
    ]
)
```

### 예시: 기능 구현 + 테스트 + 문서 동시
```python
delegate_task(
    tasks=[
        {
            "goal": "[CODING AGENT] 이메일 발송 서비스 구현...",
            "toolsets": ["terminal", "file"]
        },
        {
            "goal": "[RESEARCH AGENT] 이메일 발송 베스트 프랙티스 조사...",
            "toolsets": ["web"]
        },
        {
            "goal": "[CREATIVE AGENT] 이메일 발송 기능 API 문서 작성...",
            "toolsets": ["file"]
        }
    ]
)
```
