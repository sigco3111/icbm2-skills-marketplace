# 프로젝트 위임 체크리스트

프로젝트를 에이전트에 위임하기 전/후로 확인하는 체크리스트입니다.

---

## 위임 전 체크리스트

### 필수
- [ ] 프로젝트 경로 확인 (`workdir` 지정)
- [ ] Git 상태 정리 (uncommitted changes 없는지)
- [ ] 의존성 설치 완료 (`npm install`, `pip install` 등)
- [ ] 환경변수 설정 (`.env` 파일)
- [ ] 에이전트 인증 상태 확인 (`claude auth status`, `opencode auth list`)

### 권장
- [ ] 기존 테스트 통과 확인 (`npm test`, `pytest` 등)
- [ ] CLAUDE.md 존재 여부 확인 (없으면 자동 생성)
- [ ] 브랜치 분리 (`git checkout -b feature/xxx`)
- [ ] 작업 범위 명확히 정의

### 병렬 실행 시 추가
- [ ] 태스크 간 파일 충돌 없음 확인
- [ ] 각 태스크가 독립적임 확인
- [ ] worktree 분리 필요시 준비

---

## 에이전트 선택 결정 트리

```
주어진 작업을 분석하세요:

1. 단순 파일 수정 (1~2 파일)?
   ├─ YES → delegate_task (terminal, file)
   └─ NO → 2번으로

2. 코드를 읽고 분석만 하면 됨?
   ├─ YES → delegate_task (file만)
   └─ NO → 3번으로

3. 웹 검색이 필요함?
   ├─ YES → delegate_task (web)
   └─ NO → 4번으로

4. 5개 이상 파일 수정 또는 복잡한 로직?
   ├─ YES → 5번으로
   └─ NO → delegate_task (terminal, file)

5. 다단계 대화/피드백 루프 필요?
   ├─ YES → Claude Code (tmux interactive)
   └─ NO → Claude Code (claude -p)

6. OpenCode 선호 또는 oh-my-openagent 사용?
   ├─ YES → opencode run
   └─ NO → Claude Code
```

---

## 작업 분할 원칙

### 태스크 크기 가이드
| 복잡도 | 파일 수 | 예상 시간 | 에이전트 |
|--------|-------|----------|---------|
| XS | 1 | 1분 | delegate_task |
| S | 1~2 | 2~3분 | delegate_task |
| M | 3~5 | 3~5분 | Claude Code -p |
| L | 5~10 | 5~10분 | Claude Code -p |
| XL | 10+ | 10~20분 | Claude Code tmux 또는 분할 |

### 분할이 필요한 신호
- "그리고... 그리고..."로 요구사항이 길 때
- 서로 다른 레이어/모듈을 건드릴 때
- 완료 조건이 5개 이상일 때
- 10분 이상 걸릴 것 같을 때

### 분할하지 말아야 할 신호
- 하나의 함수/클래스에 집중된 작업
- 파일 간 밀접한 의존성이 있을 때
- 전체를 봐야 설계 결정을 내릴 때
```

## 위임 후 체크리스트

### 각 태스크 완료 시
- [ ] 에이전트 종료 코드 확인 (성공/실패)
- [ ] 변경된 파일 확인 (`git diff --stat`)
- [ ] 테스트 실행 결과 확인
- [ ] 커밋 완료

### 전체 완료 시
- [ ] 전체 테스트 통과
- [ ] 변경 요약 보고
- [ ] 불필요한 파일/디렉토리 정리
- [ ] 브랜치 병합 또는 PR 생성

### 실패 시 대응
1. 에러 로그 분석
2. 프롬프트 수정 후 재시도
3. 더 작은 태스크로 분할
4. 다른 에이전트로 전환
5. 최후: 직접 구현
