#!/usr/bin/env python3
"""
project-planner.py — 프로젝트 요구사항을 받아 에이전트 위임 계획을 자동 생성

사용법:
  python3 project-planner.py "FastAPI로 TODO 앱 만들어줘" --workdir ~/projects/todo-app
  python3 project-planner.py "버그 수정: 로그인 500 에러" --workdir ~/projects/web-app --mode quick
  python3 project-planner.py --stdin < requirements.md --workdir ~/projects/api

출력: 위임 계획 (JSON) — 에이전트 배정, 프롬프트, 실행 순서 포함
"""

import argparse
import json
import sys
from pathlib import Path


def analyze_complexity(description: str) -> str:
    """요구사항 복잡도 분석"""
    indicators = {
        "simple": ["수정", "fix", "버그", "에러", "오타", "typo", "추가", "add"],
        "medium": ["기능", "feature", "구현", "만들", "생성", "refactor", "리팩토링"],
        "complex": ["시스템", "앱", "application", "API", "서비스", "마이그레이션", "아키텍처"],
    }
    
    desc_lower = description.lower()
    scores = {level: 0 for level in indicators}
    for level, keywords in indicators.items():
        for kw in keywords:
            if kw in desc_lower:
                scores[level] += 1
    
    if scores["complex"] > 0:
        return "complex"
    elif scores["medium"] > 0:
        return "medium"
    return "simple"


def suggest_agent(complexity: str, has_web: bool = False, has_db: bool = False) -> dict:
    """복잡도에 따른 에이전트 추천"""
    recommendations = {
        "simple": {
            "agent": "delegate_task",
            "reason": "간단한 작업 — 내장 서브에이전트로 충분",
            "toolsets": ["terminal", "file"],
            "max_iterations": 20,
            "estimated_time": "1~3분",
        },
        "medium": {
            "agent": "claude-code",
            "reason": "중간 복잡도 — Claude Code print mode",
            "mode": "-p",
            "max_turns": 10,
            "estimated_time": "3~8분",
        },
        "complex": {
            "agent": "claude-code",
            "reason": "복잡한 작업 — Claude Code 세션 연속성 활용",
            "mode": "tmux-interactive",
            "max_turns": 20,
            "estimated_time": "10~20분",
        },
    }
    return recommendations[complexity]


def generate_plan(description: str, workdir: str, mode: str = "full") -> dict:
    """위임 계획 생성"""
    complexity = analyze_complexity(description)
    agent = suggest_agent(complexity)
    
    plan = {
        "description": description,
        "workdir": workdir,
        "complexity": complexity,
        "mode": mode,
        "agent": agent,
        "phases": [],
    }
    
    if mode == "quick":
        plan["phases"] = [
            {"name": "execute", "type": "single", "priority": 1},
            {"name": "verify", "type": "check", "priority": 2},
        ]
    else:
        plan["phases"] = [
            {"name": "analyze", "type": "analysis", "priority": 1},
            {"name": "claudemd", "type": "setup", "priority": 2},
            {"name": "implement", "type": "execution", "priority": 3},
            {"name": "review", "type": "validation", "priority": 4},
            {"name": "report", "type": "summary", "priority": 5},
        ]
    
    return plan


def main():
    parser = argparse.ArgumentParser(description="프로젝트 위임 계획 생성기")
    parser.add_argument("description", nargs="?", help="프로젝트 요구사항")
    parser.add_argument("--workdir", "-w", required=True, help="프로젝트 경로")
    parser.add_argument("--mode", "-m", choices=["full", "quick"], default="full",
                        help="full=전체 파이프라인, quick=긴급 최소 파이프라인")
    parser.add_argument("--stdin", action="store_true", help="표준입력에서 요구사항 읽기")
    parser.add_argument("--output", "-o", choices=["json", "text"], default="text",
                        help="출력 형식")
    
    args = parser.parse_args()
    
    if args.stdin:
        description = sys.stdin.read().strip()
    elif args.description:
        description = args.description
    else:
        parser.error("description 또는 --stdin 필요")
    
    plan = generate_plan(description, args.workdir, args.mode)
    
    if args.output == "json":
        print(json.dumps(plan, indent=2, ensure_ascii=False))
    else:
        print(f"📋 프로젝트 위임 계획")
        print(f"{'='*40}")
        print(f"요구사항: {plan['description']}")
        print(f"복잡도: {plan['complexity']}")
        print(f"경로: {plan['workdir']}")
        print(f"모드: {plan['mode']}")
        print(f"에이전트: {plan['agent']['agent']} ({plan['agent']['reason']})")
        print(f"예상 시간: {plan['agent']['estimated_time']}")
        print(f"{'='*40}")
        print(f"실행 단계:")
        for i, phase in enumerate(plan["phases"], 1):
            print(f"  {i}. {phase['name']} ({phase['type']})")


if __name__ == "__main__":
    main()
