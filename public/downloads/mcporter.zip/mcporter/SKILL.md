---
name: mcporter
description: Use the mcporter CLI to list, configure, auth, and call MCP servers/tools directly (HTTP or stdio), including ad-hoc servers, config edits, and CLI/type generation.
version: 1.0.0
author: community
license: MIT
metadata:
  hermes:
    tags: [MCP, Tools, API, Integrations, Interop]
    homepage: https://mcporter.dev
prerequisites:
  commands: [npx]
---

# mcporter

Use `mcporter` to discover, call, and manage [MCP (Model Context Protocol)](https://modelcontextprotocol.io/) servers and tools directly from the terminal.

## Prerequisites

Node.js or Bun. Install:
```bash
# Bun (preferred on this machine, global bin at ~/.bun/bin)
bun add -g mcporter

# Or via npm
npm install -g mcporter

# Or no install (per-call)
npx mcporter list
```

⚠️ **Bun global PATH gotcha**: `bun add -g mcporter` installs to `~/.bun/bin/mcporter` but does NOT add it to your shell `$PATH`. Either `export PATH="$HOME/.bun/bin:$PATH"` for the session, or append it once to `~/.zshrc`.

## Vault and non-interactive token injection (Pitfall)

Many MCP servers (e.g. Kakao PlayMCP `mcp-gateway`) require pre-issued OAuth tokens (exchanged out-of-band from a One Time Token) and **do not support interactive browser auth**. The correct mcporter 0.12.x entry point is `mcporter vault set`, NOT direct `credentials.json` editing:

```bash
# 1. Get the access + refresh tokens from the upstream OAuth provider
# 2. Write them to a temp JSON file matching the schema below
# 3. Inject via:
mcporter vault set <server-name> --tokens-file <path-to-tokens.json>
```

Tokens JSON shape mcporter 0.12.x expects — **must wrap in a `tokens` key**:
```json
{
  "tokens": {
    "access_token": "eyJ...",
    "token_type": "Bearer",
    "refresh_token": "..."
  }
}
```

mcporter will reject the file with `Vault payload must include a 'tokens' object.` if you pass the unwrapped form. The upstream PlayMCP/mcp-gateway connection guide's hand-written `credentials.json` example (with `version`, `entries`, `clientInfo.client_id`, `updatedAt`) is **not** what mcporter 0.12.x's vault stores either. Following that example verbatim produces a 401 `auth required` even though `mcporter config list` shows the server configured. Use `vault set` to let mcporter write its own vault file.

For a verified end-to-end workflow including the PlayMCP-specific One Time Token exchange, see `references/playmcp-mcp-gateway.md`. For a one-shot verification script that handles OTT → token → vault → initialize → list in a single Python invocation, see `scripts/playmcp_connect.py`.

## Diagnosing "auth required" 401s (Pitfall)

When `mcporter list <server>` returns `401 auth required`, walk this ladder:

1. **`mcporter list <server> --output json`** — get `issue.statusCode` and `issue.rawMessage`.
2. **Curl the protected resource metadata**: most OAuth 2.1 MCP servers publish it:
   ```bash
   curl -sS "https://<host>/.well-known/oauth-protected-resource/mcp"
   ```
   Look for `authorization_servers[]` to confirm the issuer. If absent, the server is non-OAuth and may need a static API key.
3. **Test the bearer directly**:
   ```bash
   curl -i -X POST https://<host>/mcp \
     -H 'accept: application/json, text/event-stream' \
     -H 'Content-Type: application/json' \
     -H "Authorization: Bearer <access_token>" \
     -d '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"test","version":"0"}}}'
   ```
   - HTTP 200 → token works, mcporter isn't picking it up: re-run `mcporter vault set` or `mcporter auth <server> --reset`.
   - HTTP 401 → token rejected: refresh flow, or your token is from a different audience (cross-audience rejection is common).
   - Look for `WWW-Authenticate: Bearer resource_metadata="..."` header — that URL is your ground truth for which OAuth issuer the resource trusts.
4. **One Time Tokens (OTT) are single-use — the exchange endpoint immediately invalidates the OTT on the first successful call** (Kakao PlayMCP returns `ERR-CHAT-90400` / "유효하지 않거나 만료된 One Time Token" on the second call, even within seconds). Treat the OTT → access_token exchange as a *consumable resource*: the access token you receive is valid for ~12 hours, but you only get **one** shot to exchange. If your script catches a network error or has a logic bug between the exchange and the `vault set` step, you must request a fresh OTT. **Always run OTT → exchange → vault set → Bearer verify → `mcporter list` in a single uninterrupted script** (e.g. one `execute_code` block). Any pause to inspect intermediate state risks needing a new OTT. See `scripts/playmcp_connect.py` for a verified one-shot.

## Quick Start

```bash
# List MCP servers already configured on this machine
mcporter list

# List tools for a specific server with schema details
mcporter list <server> --schema

# Call a tool
mcporter call <server.tool> key=value
```

## Discovering MCP Servers

mcporter auto-discovers servers configured by other MCP clients (Claude Desktop, Cursor, etc.) on the machine. To find new servers to use, browse registries like [mcpfinder.dev](https://mcpfinder.dev) or [mcp.so](https://mcp.so), then connect ad-hoc:

```bash
# Connect to any MCP server by URL (no config needed)
mcporter list --http-url https://some-mcp-server.com --name my_server

# Or run a stdio server on the fly
mcporter list --stdio "npx -y @modelcontextprotocol/server-filesystem" --name fs
```

## Calling Tools

```bash
# Key=value syntax
mcporter call linear.list_issues team=ENG limit:5

# Function syntax
mcporter call "linear.create_issue(title: \"Bug fix needed\")"

# Ad-hoc HTTP server (no config needed)
mcporter call https://api.example.com/mcp.fetch url=https://example.com

# Ad-hoc stdio server
mcporter call --stdio "bun run ./server.ts" scrape url=https://example.com

# JSON payload
mcporter call <server.tool> --args '{"limit": 5}'

# Machine-readable output (recommended for Hermes)
mcporter call <server.tool> key=value --output json
```

## Auth and Config

```bash
# Interactive browser OAuth flow (most servers)
mcporter auth <server | url> [--reset]

# Non-interactive token injection (pre-issued access/refresh tokens)
mcporter vault set <server> --tokens-file <path>

# Manage config
mcporter config list
mcporter config get <key>
mcporter config add <server>
mcporter config remove <server>
mcporter config import <path>
```

Config file location: `./config/mcporter.json` (override with `--config`).
System-level credentials vault: `~/.mcporter/` (mcporter writes this when you run `vault set`).

## Daemon

For persistent server connections:
```bash
mcporter daemon start
mcporter daemon status
mcporter daemon stop
mcporter daemon restart
```

## Code Generation

```bash
# Generate a CLI wrapper for an MCP server
mcporter generate-cli --server <name>
mcporter generate-cli --command <url>

# Inspect a generated CLI
mcporter inspect-cli <path> [--json]

# Generate TypeScript types/client
mcporter emit-ts <server> --mode client
mcporter emit-ts <server> --mode types
```

## Notes

- Use `--output json` for structured output that's easier to parse
- Ad-hoc servers (HTTP URL or `--stdio` command) work without any config — useful for one-off calls
- OAuth auth may require interactive browser flow — use `terminal(command="mcporter auth <server>", pty=true)` if needed
