#!/usr/bin/env python3
"""
playmcp_connect.py — One-shot verified PlayMCP mcp-gateway connection.

Usage:
  python3 playmcp_connect.py <oneTimeToken>

Runs the entire OTT → token exchange → vault set → Bearer initialize → mcporter list
chain in a single uninterrupted process. Critical because the OTT is single-use:
any pause between steps risks needing a new OTT.

Verified 2026-07-14 against mcporter 0.12.3 + PlayMCP production endpoints.
"""

import json
import os
import subprocess
import sys
import base64
from pathlib import Path

MCPORTER = "/Users/mac/.bun/bin/mcporter"
PLAYMCP_GATEWAY = "https://playmcp.kakao.com/mcp"
OTT_EXCHANGE_URL = "https://playmcp.kakao.com/api/v1/auths/otts:exchange"
SERVER_NAME = "mcp-gateway"
TOKENS_PATH = "/tmp/playmcp-vault/tokens.json"


def step1_exchange_ott(ott: str) -> dict:
    """POST OTT → tokens. THIS IS THE ONLY CALL THAT USES THE OTT."""
    print("=" * 60)
    print(f"STEP 1: POST {OTT_EXCHANGE_URL}")
    print("=" * 60)
    r = subprocess.run(
        [
            "curl", "-sS", "-X", "POST", OTT_EXCHANGE_URL,
            "-H", "accept: */*",
            "-H", "Content-Type: application/json",
            "-d", json.dumps({"tokenValue": ott}),
        ],
        capture_output=True, text=True, check=True,
    )
    resp = json.loads(r.stdout)
    if "accessToken" not in resp:
        print(f"⛔ OTT exchange failed: {resp}")
        sys.exit(1)
    access = resp["accessToken"]["tokenValue"]
    refresh = resp["refreshToken"]["tokenValue"]
    exp = resp["accessToken"]["expiresAt"]
    print(f"✓ access_token 길이: {len(access)}")
    print(f"✓ refresh_token 길이: {len(refresh)}")
    print(f"✓ access_token 만료: {exp}")

    # Decode JWT payload for visibility (no signature verification)
    try:
        payload_b64 = access.split(".")[1]
        payload_b64 += "=" * (-len(payload_b64) % 4)
        payload = json.loads(base64.urlsafe_b64decode(payload_b64))
        print(
            f"✓ JWT claims: sub={payload.get('sub')}, "
            f"aud={payload.get('aud')[:16]}..., "
            f"scope={payload.get('scope')}"
        )
    except Exception as e:
        print(f"⚠ JWT decode skipped: {e}")

    return {"access": access, "refresh": refresh, "expires_at": exp}


def step2_vault_set(access: str, refresh: str) -> None:
    """Write tokens.json with the `tokens` wrapper mcporter requires, then vault set."""
    print()
    print("=" * 60)
    print(f"STEP 2: mcporter vault set {SERVER_NAME}")
    print("=" * 60)
    Path(TOKENS_PATH).parent.mkdir(parents=True, exist_ok=True)
    Path(TOKENS_PATH).write_text(json.dumps({
        "tokens": {
            "access_token": access,
            "token_type": "Bearer",
            "refresh_token": refresh,
        }
    }, indent=2))

    r = subprocess.run(
        [MCPORTER, "vault", "set", SERVER_NAME, "--tokens-file", TOKENS_PATH],
        capture_output=True, text=True,
    )
    print(f"vault set: {r.stdout.strip()}")
    if r.returncode != 0:
        print(f"⛔ vault set failed: {r.stderr}")
        sys.exit(1)


def step3_bearer_initialize(access: str) -> int:
    """POST initialize to the gateway with Bearer header. Returns HTTP status."""
    print()
    print("=" * 60)
    print("STEP 3: Bearer initialize (sanity check)")
    print("=" * 60)
    r = subprocess.run(
        [
            "curl", "-sS", "-o", "/tmp/playmcp-vault/initialize.json",
            "-w", "%{http_code}", "-X", "POST", PLAYMCP_GATEWAY,
            "-H", "accept: application/json, text/event-stream",
            "-H", "Content-Type: application/json",
            "-H", f"Authorization: Bearer {access}",
            "-d", json.dumps({
                "jsonrpc": "2.0", "id": 1, "method": "initialize",
                "params": {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {},
                    "clientInfo": {"name": "playmcp_connect", "version": "1.0.0"},
                }
            }),
        ],
        capture_output=True, text=True,
    )
    print(f"HTTP {r.stdout}")
    body = Path("/tmp/playmcp-vault/initialize.json").read_text()
    print(f"body: {body[:400]}")
    return int(r.stdout)


def step4_mcporter_list() -> dict:
    """Run `mcporter list mcp-gateway --output json` and return parsed status."""
    print()
    print("=" * 60)
    print(f"STEP 4: mcporter list {SERVER_NAME} --output json")
    print("=" * 60)
    r = subprocess.run(
        [MCPORTER, "list", SERVER_NAME, "--output", "json"],
        capture_output=True, text=True,
    )
    if r.returncode != 0:
        print(f"⛔ mcporter list failed: {r.stderr}")
        sys.exit(1)
    data = json.loads(r.stdout)
    status = data.get("status", "?")
    print(f"✓ status: {status}")
    if status == "ok":
        tools = [t["name"] for t in data.get("tools", [])]
        print(f"✓ tools ({len(tools)}): {', '.join(tools[:10])}")
        if len(tools) > 10:
            print(f"  ... and {len(tools) - 10} more")
    else:
        print(f"⚠ non-ok response: {json.dumps(data, indent=2)[:600]}")
    return data


def main() -> int:
    if len(sys.argv) != 2:
        print("usage: playmcp_connect.py <oneTimeToken>")
        sys.exit(2)
    ott = sys.argv[1].strip()
    if len(ott) != 64:
        print(f"⚠ OTT length is {len(ott)}, expected 64 hex chars")

    tokens = step1_exchange_ott(ott)
    step2_vault_set(tokens["access"], tokens["refresh"])
    http_status = step3_bearer_initialize(tokens["access"])
    if http_status != 200:
        print(f"\n⛔ Bearer initialize returned HTTP {http_status}, aborting.")
        sys.exit(1)
    result = step4_mcporter_list()
    if result.get("status") != "ok":
        print("\n⛔ mcporter list did not return status=ok.")
        sys.exit(1)

    print()
    print("=" * 60)
    print("✅ PlayMCP mcp-gateway connected. You can now call tools via:")
    print(f"   mcporter call {SERVER_NAME}.<tool> ...")
    print("=" * 60)
    return 0


if __name__ == "__main__":
    sys.exit(main())