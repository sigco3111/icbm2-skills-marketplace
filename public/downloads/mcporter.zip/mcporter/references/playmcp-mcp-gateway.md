# PlayMCP mcp-gateway — Kakao MCP Gateway Connection Reference

End-to-end reference for connecting to `https://playmcp.kakao.com/mcp` via mcporter 0.12.x, verified 2026-07-14. Source docs:
- https://playmcp.kakao.com/llms.txt
- https://playmcp.kakao.com/llms/mcp-connection-guide.md

## Architecture (verified)

```
User (PlayMCP UI) → OTT issued
User → pastes OTT to AI agent
Agent → POST /api/v1/auths/otts:exchange  → access_token (JWT, ~12h) + refresh_token (~90d)
Agent → mcporter vault set mcp-gateway --tokens-file <tmp.json>
Agent → mcporter list mcp-gateway  → status: "ok", tools enumerated
Agent → mcporter call mcp-gateway.<tool> ...  → invokes PlayMCP gateway
```

## Key endpoints (live as of 2026-07-14)

| Endpoint | Purpose |
|---|---|
| `POST https://playmcp.kakao.com/api/v1/auths/otts:exchange` | Exchange OTT → tokens. Body: `{"tokenValue": "<ott>"}`. Returns 200 with `accessToken.tokenValue` + `refreshToken.tokenValue`, or 400 with `ERR-CHAT-90400` if OTT was already consumed. |
| `GET  https://playmcp.kakao.com/.well-known/oauth-protected-resource/mcp` | OAuth 2.1 protected resource metadata (RFC 9728). Returns `authorization_servers: ["https://playauth.kakao.com/playmcp"]`, `bearer_methods_supported: ["header"]`. |
| `POST https://playmcp.kakao.com/mcp` | The MCP gateway itself. Requires `Authorization: Bearer <access_token>` header. MCP Streamable HTTP transport. |

## JWT shape (verified)

Access token is RS256, ~695 chars. Decoded payload:
```json
{
  "sub": "804",
  "aud": "HElMUWdVoroTsrXxezeTSemg8gXzzCKWARb5MJux8gY",
  "nbf": 1784014379,
  "scope": ["default"],
  "iss": "https://playauth.kakao.com/playmcp",
  "exp": 1784057579,
  "iat": 1784014379,
  "jti": "a8d3bdb6-4d2b-4200-bf59-c3516bbd4ffa"
}
```
- `aud` must match `client_id` registered in `~/.mcporter/credentials.json` `clientInfo.client_id` (same value).
- Header `kid` is `playmcp-rsa-key` (RS256).
- `exp - iat = 12h` for access token, refresh token ~90 days.

## Pitfalls (battle-tested)

1. **OTT is one-shot.** First exchange call returns 200 with a real JWT; calling again (even seconds later) returns 400 `ERR-CHAT-90400`. The server immediately invalidates the OTT after first use. Do NOT debug by re-calling — request a new OTT.
2. **The upstream guide's `credentials.json` example is WRONG for mcporter 0.12.x.** The guide shows `{"version": 1, "entries": {"mcp-gateway|<hash>": {...}}}`. mcporter does write to that exact file structure via `vault set`, but if you write it by hand, the access_token field will be ignored because mcporter's vault key format or encoding diverges. Always use `mcporter vault set <server> --tokens-file <path>` — let mcporter build the file.
3. **`vault set` requires `{"tokens": {...}}` wrapper**, not just `{access_token, refresh_token}`. Error if wrong: `Vault payload must include a 'tokens' object.`
4. **`config add` is enough for the bearer server entry** — `mcporter config add mcp-gateway https://playmcp.kakao.com/mcp --auth oauth --scope home` writes only `mcporter.json`. The credentials live in a separate vault file at `~/.mcporter/credentials.json` (written by `vault set`).
5. **`WWW-Authenticate` header** on 401 from the gateway is your debug handle: `Bearer resource_metadata="https://playmcp.kakao.com/.well-known/oauth-protected-resource/mcp"` — fetch that URL to confirm the trusted issuer.
6. **The "auth required" suggestion to run `mcporter auth <server>`** (interactive browser OAuth) is a fallback when no token is cached. For OTT-derived tokens, never use `auth` — only `vault set`.

## What you can actually call (tools discovered after successful connection)

On a fresh PlayMCP toolbox, the gateway exposes whatever MCP servers the user has added to their toolbox (max 10). At the time of verification, the user's toolbox contained:

| Tool | Purpose |
|---|---|
| `KakaotalkChat-MemoChat` | Send a "note to self" KakaoTalk message (max 200 chars). |
| `worldagentcraft-join_game` | Join World of AgentCraft (text RPG), requires `name`. |
| `worldagentcraft-get_my_state` | Get settlement state (resources, buildings, villagers). |
| `worldagentcraft-get_players` | List all players and world tick. |

Tool inventory is per-user; re-run `mcporter list mcp-gateway --schema` after the user adds/removes servers from their toolbox.

## Token refresh (not yet exercised, predicted path)

mcporter 0.12.x should auto-refresh via the refresh_token when access_token expires. If it doesn't, force a refresh by re-running `mcporter vault set mcp-gateway --tokens-file <new-tokens.json>`. To refresh manually:
1. Read `refresh_token` from `~/.mcporter/credentials.json`.
2. POST to `https://playauth.kakao.com/playmcp/oauth/token` with `grant_type=refresh_token` + `client_id=HElMUWdVoroTsrXxezeTSemg8gXzzCKWARb5MJux8gY` + `refresh_token=<value>`.
3. Update vault.

⚠️ The `/oauth/token` endpoint was not verified live (it returned 404 on the exact path tried in session). If you need manual refresh, hit `https://playauth.kakao.com/playmcp/.well-known/openid-configuration` first to discover the actual token endpoint.

## Files written by a successful connection

```
~/.bun/bin/mcporter                      # CLI (via `bun add -g mcporter`)
~/.mcporter/mcporter.json                # Server definitions
~/.mcporter/credentials.json             # OAuth tokens (chmod 600)
```

`credentials.json` final shape (written by `vault set`, NOT hand-editable reliably):
```json
{
  "version": 1,
  "entries": {
    "mcp-gateway|92ef5a9fd655a681": {
      "serverName": "mcp-gateway",
      "serverUrl": "https://playmcp.kakao.com/mcp",
      "tokens": {
        "access_token": "eyJraWQ...",
        "token_type": "Bearer",
        "refresh_token": "j14eOBqI..."
      },
      "clientInfo": {
        "client_id": "HElMUWdVoroTsrXxezeTSemg8gXzzCKWARb5MJux8gY"
      },
      "updatedAt": "2026-07-14T07:59:28.045Z"
    }
  }
}
```

The 16-char hex suffix after `mcp-gateway|` is `shasum -a 256` of `{"name":"mcp-gateway","url":"https://playmcp.kakao.com/mcp","command":null}`, truncated to 16 chars. mcporter computes this internally; you don't need to pre-compute.