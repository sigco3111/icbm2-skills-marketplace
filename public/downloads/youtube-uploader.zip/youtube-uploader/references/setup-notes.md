# Google Cloud Console OAuth 설정 시 주의사항

## 인증 오류 해결 체크리스트

1. ✅ YouTube Data API v3 활성화
2. ✅ OAuth 클라이언트 ID: 데스크톱 앱
3. ✅ 리디렉션 URI: `http://localhost` 포함
4. ✅ OAuth 동의 화면: 앱 이름, 이메일, 홈페이지, 개인정보처리방침 입력
5. ✅ 테스트 사용자에 이메일 추가
6. ✅ Google Search Console에서 홈페이지 소유권 확인 (HTML 태그 방식)
7. ✅ 게시 상태: 테스트 (개인 용도)
8. ✅ 인증 시 경고 → "고급" → "에르메스봇(으)로 이동" 클릭

## 홈페이지 & 개인정보처리방침

- 레포: https://github.com/sigco3111/hermes-landing
- 홈페이지: https://sigco3111.github.io/hermes-landing/
- 개인정보처리방침: https://sigco3111.github.io/hermes-landing/privacy.html
- Search Console: URL 접두어 방식으로 등록, HTML 태그로 소유권 확인

## 업로드 쿼터

- YouTube Data API 기본 쿼터: 10,000 units/일
- 영상 업로드 1회: ~1,600 units
- 일일 최대 약 6개 업로드 가능
