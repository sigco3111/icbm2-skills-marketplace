#!/usr/bin/env python3
"""Upload video to YouTube using direct HTTP requests with OAuth2 token"""

import json
import os
import sys
import pickle
import argparse
import subprocess
import requests
from google.auth.transport.requests import Request

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SCRIPT_DIR)
from auth import get_authenticated_service

TOKEN_FILE = os.path.expanduser("~/.hermes/secrets/youtube_token.pickle")


def validate_shorts(file_path):
    """Validate if video meets YouTube Shorts requirements."""
    result = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "stream=width,height,duration",
         "-of", "json", file_path],
        capture_output=True, text=True
    )
    try:
        streams = json.loads(result.stdout)["streams"]
        video_stream = next((s for s in streams if s.get("width")), streams[0])
        w = video_stream["width"]
        h = video_stream["height"]
        dur = float(video_stream.get("duration", 0))
    except (KeyError, IndexError, ValueError):
        print("⚠️  Could not read video metadata, skipping validation")
        return

    is_vertical = w < h and abs(w / h - 9 / 16) < 0.05
    issues = []

    if not is_vertical:
        issues.append(f"비율 오류: {w}x{h} (9:16 세로 필요)")
    if dur > 60:
        issues.append(f"길이 초과: {dur:.1f}s (60s 이하 필요)")

    if issues:
        print("⚠️  숏츠 조건 미충족:")
        for i in issues:
            print(f"    ❌ {i}")
    else:
        print(f"✅ 숏츠 조건 충족: {w}x{h}, {dur:.1f}s")


def upload_video(file_path, title, description="", tags=None, category="22", privacy="private"):
    """Upload video to YouTube."""
    creds = get_authenticated_service()
    if not creds:
        print("ERROR: Not authenticated. Run auth.py first.")
        return None

    if not os.path.exists(file_path):
        print(f"ERROR: File not found: {file_path}")
        return None

    file_size = os.path.getsize(file_path)
    token = creds.token

    # Auto-validate if vertical
    validate_shorts(file_path)

    print(f"Uploading: {file_path} ({file_size/1024/1024:.1f}MB)")
    print(f"Title: {title}")
    print(f"Privacy: {privacy}")

    # Step 1: Initiate resumable upload
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }

    body = {
        "snippet": {
            "title": title,
            "description": description,
            "tags": tags or [],
            "categoryId": category,
        },
        "status": {
            "privacyStatus": privacy,
            "selfDeclaredMadeForKids": False,
        }
    }

    r = requests.post(
        "https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status",
        headers=headers,
        json=body,
    )

    upload_url = r.headers.get("Location")
    if not upload_url:
        print(f"Error initiating upload: {r.status_code} {r.text}")
        return None

    # Step 2: Upload the file
    with open(file_path, "rb") as f:
        r = requests.put(upload_url, data=f, headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "video/mp4",
            "Content-Length": str(file_size),
        })

    if r.status_code == 200:
        video_id = r.json()["id"]
        url = f"https://www.youtube.com/watch?v={video_id}"
        print(f"\n✅ Upload successful!")
        print(f"URL: {url}")
        return url
    else:
        print(f"Error: {r.status_code} {r.text}")
        return None


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Upload video to YouTube")
    parser.add_argument("file", help="Video file path")
    parser.add_argument("--title", "-t", required=True, help="Video title")
    parser.add_argument("--description", "-d", default="", help="Video description")
    parser.add_argument("--tags", nargs="+", default=[], help="Tags")
    parser.add_argument("--category", default="22", help="Category ID (default: 22)")
    parser.add_argument("--privacy", "-p", default="private",
                       choices=["private", "unlisted", "public"],
                       help="Privacy status (default: private)")
    args = parser.parse_args()

    upload_video(
        file_path=args.file,
        title=args.title,
        description=args.description,
        tags=args.tags,
        category=args.category,
        privacy=args.privacy,
    )
