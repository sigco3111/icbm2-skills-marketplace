youtube_upload_pw.py 스크립트가 위치한 곳 (실제 파일은 ~/.hermes/scripts/ 에 있음)
