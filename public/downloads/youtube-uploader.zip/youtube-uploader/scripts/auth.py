#!/usr/bin/env python3
"""YouTube OAuth2 authentication for ICBM2"""

import os
import pickle
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request

SCOPES = ["https://www.googleapis.com/auth/youtube.upload"]
CREDENTIALS_DIR = os.path.expanduser("~/.hermes/secrets")
CREDENTIALS_FILE = os.path.join(CREDENTIALS_DIR,
    "client_secret_1088895812408-fa0fjavjisgfdaubidspvegqk0harjqg.apps.googleusercontent.com.json")
TOKEN_FILE = os.path.join(CREDENTIALS_DIR, "youtube_token.pickle")


def get_authenticated_service():
    """Get authenticated YouTube credentials."""
    creds = None

    if os.path.exists(TOKEN_FILE):
        with open(TOKEN_FILE, "rb") as f:
            creds = pickle.load(f)

    if creds and creds.expired and creds.refresh_token:
        creds.refresh(Request())
    elif not creds:
        if not os.path.exists(CREDENTIALS_FILE):
            print("ERROR: YouTube client secret not found.")
            print(f"Path: {CREDENTIALS_FILE}")
            return None

        flow = InstalledAppFlow.from_client_secrets_file(CREDENTIALS_FILE, SCOPES)
        creds = flow.run_local_server(port=8080)

    with open(TOKEN_FILE, "wb") as f:
        pickle.dump(creds, f)

    return creds


if __name__ == "__main__":
    creds = get_authenticated_service()
    if creds:
        print("✅ Authentication successful!")
        print(f"Token valid: {creds.valid}")
    else:
        print("❌ Authentication failed")
