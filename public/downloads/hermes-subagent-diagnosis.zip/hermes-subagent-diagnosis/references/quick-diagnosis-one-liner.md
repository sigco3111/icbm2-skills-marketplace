# Quick Diagnosis One-Liners

상황별 한 줄 진단 명령 모음. `hermes-subagent-diagnosis`의 4-state 판정을 빠르게 수행.

---

## 1. 진행 중인지 빠르게 확인

```bash
ps -axo pid,etime,state,command | grep -E "session-key [0-9_a-z]+" | grep -v grep
```

여러 child session이 동시에 살아있을 수 있음. 모두 출력.

---

## 2. child session_id를 모를 때 (메인 세션 ID만 있을 때)

```bash
MAIN="20260722_151430_10f62e"  # 메인 세션 ID
grep -nE "tools.async_delegation.*Dispatched.*$MAIN" ~/.hermes/logs/agent.log* 2>/dev/null | tail -3
# 직전/직후 컨텍스트에서 child ID 추출:
grep -A2 "Dispatched async delegation" ~/.hermes/logs/agent.log* 2>/dev/null | grep -oE "session=[0-9_a-z]+" | sort -u
```

또는 메인 세션의 `delegate_task` tool response 직접 grep:

```bash
grep -B1 -A10 "tool delegate_task completed" ~/.hermes/logs/agent.log* 2>/dev/null | tail -30
# 응답 본문에 child session_id가 들어있음
```

---

## 3. child session_id를 알 때 (가장 흔한 케이스)

```bash
CHILD="20260722_155110_b69124" && {
  ps -axo pid,etime,state,command | grep "$CHILD" | grep -v grep || echo "(프로세스 종료)"
  echo "---"
  grep -E "Turn ended:.*session=$CHILD\b" ~/.hermes/logs/agent.log* 2>/dev/null && echo "✓ Turn ended" || echo "✗ Turn ended 부재"
  echo "---"
  grep -E "API call #[0-9]+:.*\[$CHILD\]" ~/.hermes/logs/agent.log* 2>/dev/null | tail -1
}
```

---

## 4. 자식 로그 전체 추출 (다른 세션과 격리)

```bash
CHILD="20260722_155110_b69124"
grep -Rni "\[$CHILD\]" ~/.hermes/logs 2>/dev/null > /tmp/subagent-$CHILD.log
echo "lines: $(wc -l < /tmp/subagent-$CHILD.log)"
echo "last 5 activities:"
grep -E "tool .* completed|Turn ended" /tmp/subagent-$CHILD.log | tail -5
echo "errors:"
grep -ni "\[$CHILD\]" ~/.hermes/logs/errors.log 2>/dev/null | tail -10
```

---

## 5. 프로젝트 변경 검증 (3종 git/non-git 공용)

```bash
PROJECT_DIR="/Users/mac/work/bytepath-ex"  # 프로젝트 경로
cd "$PROJECT_DIR" && {
  echo "=== git status ==="
  git status --short 2>/dev/null || echo "(not a git repo)"
  echo "=== changed in last 30 min ==="
  find . -type f -mmin -30 -not -path './.git/*' -not -path './dist/*' -print 2>/dev/null | head -20
  echo "=== syntax check (Lua) ==="
  find . -name '*.lua' -not -path './.git/*' -print0 2>/dev/null | xargs -0 -n1 luac -p 2>&1 | head -10
}
```

---

## 6. 칸반 작업과 헷갈릴 때

```bash
# 위임 (subagent, 메모리 휘발성)
echo "=== async delegations ==="
grep -c "tools.async_delegation: Dispatched" ~/.hermes/logs/agent.log* 2>/dev/null
echo "=== kanban tasks (영속 SQLite) ==="
hermes kanban list 2>/dev/null | tail -10
```

- 카운트 0 + kanban list 비어있음 = 둘 다 작업 없음
- 카운트 > 0 + kanban 비어있음 = 일반 subagent 위임 (본 스킬 진단)
- 카운트 0 + kanban 있음 = 칸반 작업만 (kanban 명령군 사용)

---

## 7. cron과 헷갈릴 때

```bash
echo "=== active subagents (slash_worker with child session pattern) ==="
ps -axo pid,etime,command | grep "slash_worker" | grep -v grep | wc -l
echo "=== active cron jobs ==="
hermes cron list 2>/dev/null | tail -10
echo "=== subagent sessions in last 24h ==="
find ~/.hermes/sessions -name "*subagent*" -mtime -1 2>/dev/null | head -10
```

---

## 8. 한 줄 풀 진단 (자주 쓰는 통합 명령)

```bash
CHILD="CHILD_ID_HERE"; \
{ ps -axo pid,etime,state,command | grep "$CHILD" | grep -v grep | head -3 || echo "(프로세스 없음)"; } && \
echo "--- Turn ended ---" && \
{ grep -E "Turn ended:.*session=$CHILD\b" ~/.hermes/logs/agent.log* 2>/dev/null | tail -1 || echo "(부재)"; } && \
echo "--- last 3 tools ---" && \
grep -E "tool .* completed.*\[$CHILD\]" ~/.hermes/logs/agent.log* 2>/dev/null | tail -3 && \
echo "--- errors ---" && \
grep -ni "\[$CHILD\]" ~/.hermes/logs/errors.log 2>/dev/null | tail -5
```

출력 예 (abandoned):

```text
(프로세스 없음)
--- Turn ended ---
(부재)
--- last 3 tools ---
agent.tool_executor: tool read_file completed (0.08s, 15232 chars)
agent.tool_executor: tool patch completed (0.15s, 3176 chars)
agent.tool_executor: tool patch completed (0.14s, 1255 chars)
--- errors ---
WARNING ... Tool terminal returned error (60.17s) ...
WARNING ... Tool terminal returned error (0.00s) ...
```

→ 5초 안에 판정 가능. **abandoned** (프로세스 종료 + Turn ended 부재 + warning만 + 마지막 활동이 read_file).

---

## 9. 모든 child session_id 목록 (multi-agent 워커 환경)

```bash
# 최근 24시간 동안 활동한 모든 subagent 세션 ID
grep -oE "session=[0-9_a-z]+ model=.*platform=subagent" ~/.hermes/logs/agent.log* 2>/dev/null | \
  grep -oE "session=[0-9_a-z]+" | sort -u
```

→ 1줄에 1개 session_id. multi-agent 워커가 N개 subagent를 동시에 띄웠을 때 N개 모두 추출.

---

## 10. budget exhausted vs 정상 종료 구분

```bash
CHILD="..." && \
grep -E "Turn ended:.*session=$CHILD\b" ~/.hermes/logs/agent.log* 2>/dev/null
```

- `reason=text_response(finish_reason=stop)` → 정상 완료
- `reason=max_iterations` → budget exhausted (60회 한도 도달, **completed의 일종**)
- `reason=tool_use` → 도구 호출 중단 (보통 비정상)
- `reason=error` → 모델 API 에러
- `reason=cancelled` → 사용자 또는 시스템 취소

**budget exhausted는 failed가 아님**. 60회 안에 LLM이 stop 토큰을 못 냈다는 뜻. 사용자가 이어서 시키려면 `delegate_task` 재호출 필요.
