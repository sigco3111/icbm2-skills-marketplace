# 4-State 판정 실측 사례

`hermes-subagent-diagnosis`의 4-state (running / completed / abandoned / errored) 각각의 실측 사례. 진단 출력 + 사용자 보고 템플릿 포함.

---

## 사례 1: bytepath-ex 풀스택 위임 (2026-07-22) — **abandoned**

### 상황

메인 세션 `20260722_151430_10f62e` (Telegram DM 사용자 8359527845)가 `delegate_task`로 bytepath-ex LÖVE 게임 한글화 작업을 서브에이전트에 위임.

### Step 1: child session_id 추출

```bash
$ grep -RniE "platform=subagent history=0 msg=" ~/.hermes/logs 2>/dev/null | tail -1
/Users/mac/.hermes/logs/agent.log:17144:2026-07-22 15:51:10,703 INFO [20260722_155110_b69124] agent.turn_context: conversation turn: session=20260722_155110_b69124 model=MiniMax-M3 provider=minimax platform=subagent history=0 msg='bytepath-ex LÖVE 11.5 게임 한글화 1차 풀스택 작업을 진행해줘. ...'

$ CHILD="20260722_155110_b69124"
$ echo "child session_id: $CHILD"
child session_id: 20260722_155110_b69124
```

delegation_id도 추출:

```bash
$ grep -Rni "Dispatched async delegation" ~/.hermes/logs 2>/dev/null | tail -1
/Users/mac/.hermes/logs/agent.log:17142:2026-07-22 15:51:10,669 INFO [20260722_151430_10f62e] tools.async_delegation: Dispatched async delegation batch deleg_525e20d8 (1 task(s), session_key=20260722_151430_10f62e)
```

→ `deleg_id = deleg_525e20d8`

### Step 2: 자식 로그 격리

```bash
$ grep -Rni "\[$CHILD\]" ~/.hermes/logs 2>/dev/null > /tmp/subagent-$CHILD.log
$ wc -l /tmp/subagent-$CHILD.log
    1004 /tmp/subagent-20260722_155110_b69124.log
```

→ 1004줄. 충분히 작업한 흔적.

### Step 3: errors.log 교차 확인

```bash
$ grep -ni "\[$CHILD\]" ~/.hermes/logs/errors.log 2>/dev/null > /tmp/subagent-$CHILD-errors.log
$ cat /tmp/subagent-$CHILD-errors.log
2026-07-22 15:53:55,091 WARNING [20260722_155110_b69124] agent.tool_executor: Tool terminal returned error (60.17s): {"output": "[Command timed out after 60s]", "exit_code": 124, "error": null}
2026-07-22 15:54:16,941 WARNING [20260722_155110_b69124] agent.tool_executor: Tool terminal returned error (0.00s): {"output": "", "exit_code": -1, "error": "Foreground command uses '&' backgrounding. ..."}
```

→ 2개 warning. 둘 다 terminal 명령 부분 실패. fatal 아님.

### Step 4: 4-state 판정

```bash
$ ps -axo pid,etime,state,command | grep "$CHILD" | grep -v grep || echo "(프로세스 없음)"
(프로세스 없음)

$ grep -E "Turn ended:.*session=$CHILD\b" /tmp/subagent-$CHILD.log && echo "✓ 정상 종료" || echo "✗ Turn ended 부재"
✗ Turn ended 부재 (abandoned or errored)

$ grep -E "API call #[0-9]+:.*\[$CHILD\]" /tmp/subagent-$CHILD.log | tail -1
2026-07-22 15:59:14,676 INFO [20260722_155110_b69124] agent.conversation_loop: API call #46: ... latency=5.2s
```

판정:

| 신호 | 값 |
|---|---|
| ps 프로세스 | 없음 (종료) |
| `Turn ended` | **부재** |
| 마지막 API call | #46/60 (budget 잔여) |
| 마지막 활동 | `tool read_file completed` |
| errors.log | warning 2개 (fatal 아님) |
| 판정 | **abandoned** (부분 완료) |

### Step 5: 프로젝트 변경 검증

```bash
$ cd /Users/mac/work/bytepath-ex
$ git status --short
 M lang/ko.lua
 M lang/en.lua
 M main.lua
?? lang/ko_8.lua
?? NOTES-i18n.md
...
```

```bash
$ git diff --stat
 lang/en.lua       | 12 ++++++------
 lang/ko.lua       | 87 ++++++++++++++++++++++++++++-----------------------
 main.lua          |  3 +++
 3 files changed, 49 insertions(+), 53 deletions(-)
```

```bash
$ find . -type f -mmin -30 -not -path './.git/*' -print | head -10
./lang/ko.lua
./lang/en.lua
./main.lua
./lang/ko_8.lua
./NOTES-i18n.md
...
```

### 사용자 보고 템플릿

```text
서브에이전트 상태: 부분 완료 (abandoned)

▸ child session_id: 20260722_155110_b69124
▸ delegation_id: deleg_525e20d8
▸ 작업 내용: bytepath-ex LÖVE 11.5 게임 한글화 1차 풀스택

진행 내역:
  - 46회 API 호출
  - 다수 파일 read + 6개 patch + 2개 write_file
  - todo 상태 4회 갱신
  - 정상 tool 호출 종료 (read_file)

문제 신호:
  - ps에서 자식 프로세스 종료
  - agent.log에 "Turn ended" 라인 부재
  - errors.log: terminal 60초 timeout 1회 + '&' backgrounding 차단 1회

결과:
  - 작업이 100% 끝나기 전 비정상 종료로 추정
  - 5개 파일이 실제로 변경됨 (lang/ko.lua, lang/en.lua, main.lua, lang/ko_8.lua, NOTES-i18n.md)
  - 49 insertions, 53 deletions

다음 단계 옵션:
  1) 사용자가 직접 diff 검수 → 부족한 부분만 이어서 위임
  2) 변경 파일 롤백 → 다른 subagent 또는 다른 모델로 재시도
  3) 직접 마무리 (이전 세션 컨텍스트 참고)

신뢰 가드: "성공했습니다"는 git status + Turn ended 4중 가드 통과해야만 보고.
```

---

## 사례 2: completed (정상 종료) — **일반 패턴**

### agent.log 끝부분 발췌

```text
2026-07-22 15:54:08,547 INFO [CHILD_ID] agent.conversation_loop: API call #44: ...
2026-07-22 15:54:08,573 INFO [CHILD_ID] agent.conversation_loop: Turn ended: reason=text_response(finish_reason=stop) model=MiniMax-M3 api_calls=8/60 budget=8/60 tool_turns=38 last_msg_role=assistant response_len=7051 session=CHILD_ID
2026-07-22 15:54:12,131 INFO gateway.run: Suppressing normal final send for session ...: final delivery already confirmed (streamed=True previewed=False content_delivered=True).
2026-07-22 15:54:12,132 INFO gateway.run: response ready: platform=telegram chat=8359527845 time=296.8s api_calls=8 response=7051 chars
```

핵심 신호:

```text
Turn ended: reason=text_response(finish_reason=stop) ... session=CHILD_ID
```

→ `finish_reason=stop` + 마지막 메시지 role=assistant + `response_len=N>0` = **정상 종료**.

### 사용자 보고 (간결 템플릿)

```text
서브에이전트 정상 종료 ✓
- child session_id: CHILD_ID
- API 호출: 8/60
- 응답 길이: 7051 chars
- 총 소요: 296.8s
```

---

## 사례 3: errored — **fatal 다수**

### errors.log 발췌

```text
2026-07-22 12:34:56,789 ERROR [CHILD_ID] agent.tool_executor: Tool terminal returned error (5.0s): {"output": "Permission denied", "exit_code": 13, "error": null}
2026-07-22 12:35:02,123 ERROR [CHILD_ID] agent.tool_executor: Tool patch returned error: file_not_found
2026-07-22 12:35:10,456 ERROR [CHILD_ID] agent.tool_executor: Tool terminal returned error (5.0s): {"output": "command not found", "exit_code": 127, "error": null}
2026-07-22 12:35:18,901 ERROR [CHILD_ID] agent.tool_executor: Tool terminal returned error (5.0s): {"output": "Permission denied", "exit_code": 13, "error": null}
```

agent.log 끝:

```text
2026-07-22 12:35:18,999 INFO [CHILD_ID] agent.conversation_loop: API call #12: ...
# 그 후 침묵
```

판정:

| 신호 | 값 |
|---|---|
| ps | 없음 (종료) |
| `Turn ended` | 부재 |
| errors.log | ERROR 다수 (4개) |
| exit_code | 13, 127 = fatal (Permission, command not found) |
| 판정 | **errored** |

### 사용자 보고 템플릿

```text
서브에이전트 실패 (errored)

▸ child session_id: CHILD_ID
▸ API 호출: 12회 후 비정상 종료
▸ errors.log: ERROR 4건 (exit_code 13, 127)

핵심 에러:
  - Permission denied (2회) → 작업 디렉터리 권한 확인 필요
  - command not found (1회) → PATH 또는 의존성 누락
  - patch: file_not_found (1회) → 작업 대상 파일 부재

권장 다음 단계:
  1) 작업 디렉터리 권한 + 의존성 설치
  2) 대상 파일 경로 다시 확인
  3) 재시도
```

---

## 사례 4: running — **진행 중**

### ps 출력

```bash
$ ps -axo pid,etime,state,command | grep "$CHILD" | grep -v grep
12345   04:23:18 Ss   /Users/mac/.hermes/hermes-agent/venv/bin/python -m tui_gateway.slash_worker --session-key CHILD_ID --model MiniMax-M3
```

→ etime 4시간 23분, Ss (interruptible sleep, 정상 idle).

### agent.log 끝

```text
2026-07-22 16:10:23,456 INFO [CHILD_ID] agent.conversation_loop: API call #23: ... latency=4.2s
2026-07-22 16:10:23,789 INFO [CHILD_ID] agent.tool_executor: tool read_file completed (0.10s, 5432 chars)
2026-07-22 16:10:25,012 INFO [CHILD_ID] agent.conversation_loop: API call #24: ...
# (진행 중, 최근 활동)
```

판정:

| 신호 | 값 |
|---|---|
| ps etime | 4:23:18 (살아있음) |
| `Turn ended` | 부재 (정상, 진행 중) |
| 마지막 활동 | 최근 1분 이내 |
| 판정 | **running** |

### 사용자 보고 (간결)

```text
서브에이전트 진행 중
- child session_id: CHILD_ID
- 경과 시간: 4시간 23분
- API 호출: 24회 / 60 (40% 사용)
- 최근 활동: 1분 전 (read_file)
- 이상 신호: 없음
```

---

## 판정 매트릭스 (요약)

| 4-state | ps | `Turn ended` | errors.log fatal | git diff | 보고 라벨 |
|---|---|---|---|---|---|
| **running** | 살아있음 | 부재 (정상) | 무시 가능 | 진행 중 | "진행 중" + 진행 % |
| **completed** | 종료 | **있음 (stop)** | 없음 | 변경됨 | "정상 종료 ✓" |
| **abandoned** | 종료 | **부재** | warning만 | 부분 변경 | "부분 완료" + 옵션 3개 |
| **errored** | 종료 | **부재** | **fatal 다수** | 거의 없음 | "실패" + 핵심 에러 |

**가장 큰 함정**: completed처럼 보여도 **errors.log fatal 다수 + git diff 빈약 = 사실상 실패**. `Turn ended`만으로 성공 보고 금지.
