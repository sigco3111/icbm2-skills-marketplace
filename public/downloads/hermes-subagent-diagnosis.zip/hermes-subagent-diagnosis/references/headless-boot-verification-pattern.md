# 헤드리스 부팅 검증 패턴 (서브에이전트 60s timeout + '&' backgrounding 회피법)

## 문제

서브에이전트(`delegate_task`)가 LÖVE/Godot/Unity 등 GUI 앱의 **헤드리스 부팅 검증**을 시도할 때 다음 두 함정을 **동시에** 만남 (2026-07-22 bytepath-ex 케이스 실측):

```text
# 1차 시도: foreground terminal로 love . 호출
WARNING [세션] agent.tool_executor: Tool terminal returned error (60.17s):
  {"output": "[Command timed out after 60s]", "exit_code": 124, "error": null}

# 2차 시도: LLM이 '&' 백그라운딩으로 우회 → 즉시 차단
WARNING [세션] agent.tool_executor: Tool terminal returned error (0.00s):
  {"output": "", "exit_code": -1,
   "error": "Foreground command uses '&' backgrounding.
   Use terminal(background=true) for long-lived processes,
   then run health checks and tests in follow-up terminal call."}
```

**왜 동시에?** LÖVE/GUI 앱은 `love .` 후 무한히 살아있음 → default timeout 60s 초과 → LLM이 합리적으로 `&`로 백그라운딩 → Hermes 보안 정책으로 즉시 차단. LLM은 다음 turn에서 우회 방법을 찾지 못해 **검증 단계를 포기한 채 다른 작업으로 진행** → 검증 누락 상태로 abandon 위험 증가.

## 올바른 패턴: background + timeout=10 + 별도 검증

```python
# 1) 백그라운드로 띄우기 — 10초 timeout으로 "boot alive" 신호 확보
terminal(
    command="love . > /tmp/love_out.log 2>&1",
    workdir="/Users/mac/work/bytepath-ex",
    background=True,
    timeout=10,
)

# 2) 세션 ID 회신 받음 → 3-5초 대기 후 검증
process(action="poll", session_id="<ID>", timeout=5000)
# → status=running + elapsed 초 확인

# 3) 부팅 검증 (stderr 비어있는지)
terminal(command="cat /tmp/love_out.log | head -20", workdir="...")

# 4) ps로 프로세스 살아있는지 확인
terminal(command="pgrep -fl 'love .'")

# 5) 검증 끝나면 kill
process(action="kill", session_id="<ID>")
```

**핵심**: `background=True` + `timeout=10` (작아도 OK — 백그라운드 자체는 timeout 10초 후 process 도구로 계속 추적 가능). 검증 명령은 **별도 `terminal(foreground)` 호출** — 동일 호출 안에 `&`나 `kill` 섞지 말 것.

## 엔진별 권장 명령

### LÖVE 2D (lua-love-game-fork)
```bash
# 부팅
terminal(command="love . > /tmp/love_out.log 2>&1",
         workdir="<PROJECT>", background=True, timeout=10)
# 검증
terminal(command="pgrep -fl 'love ' && cat /tmp/love_out.log")
# 종료
process(action="kill", session_id="<ID>")
# 헤드리스 stderr-only 검증 (디스플레이 없는 환경)
terminal(command="love . 2>&1 | head -50", workdir="<PROJECT>",
         timeout=8)  # 8초 안에 안 끝나면 OK (정상 부팅 신호)
```

### Godot 4
```bash
terminal(command="godot --headless --quit 2>&1 | head -30",
         workdir="<PROJECT>", timeout=20)
# --quit 플래그로 부팅 검증 후 자동 종료 (헤드리스)
```

### Unity
```bash
terminal(command="Unity -batchmode -nographics -quit -projectPath <PROJECT>",
         workdir="<PROJECT>", timeout=30)
# -batchmode -nographics -quit = 부팅 검증 + 자동 종료
```

## subagent 작성 스킬에 권장하는 안내

서브에이전트에게 위임할 때 다음 문구를 작업 설명에 포함시키면 위 두 함정을 동시에 회피 가능:

> **헤드리스 부팅 검증 필요 시**: `terminal(background=True, timeout=10)`로 띄우고 → `process(poll/log/kill)`로 관리 → 검증 명령은 별도 `terminal(foreground)`로 호출. `&` 백그라운딩이나 `--timeout` 옵션 변경으로 우회하지 말 것.

이 한 줄이면 LLM이 60s timeout + '&' backgrounding 함정을 동시에 만나지 않음. 검증 단계 포기 → abandon 위험 패턴 회피.

## 검증된 케이스

- 2026-07-22 bytepath-ex 풀스택 위임 (`20260722_155110_b69124`): 60s + '&' 두 함정 동시 노출, abandoned 판정. 다음 위임부터 `background=True` 패턴 적용 권장.