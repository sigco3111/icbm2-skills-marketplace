---
name: hermes-subagent-diagnosis
description: Use when an async Hermes subagent (delegate_task child) appears stuck, silent, or unaccounted for — "서브에이전트 뭐 하고 있지?", "delegate_task가 끝났는지 어떻게 확인해?", "child session이 정상 종료한 거야?", "위임한 작업 어디까지 됐어?", "서브에이전트 응답이 안 와", "서브에이전트 에러 났나?", "백그라운드 위임 결과 어디서 봐". Class-level umbrella for inspecting child session logs (agent.log, errors.log), distinguishing "still running" from "completed normally" from "abandoned mid-task" from "errored out", cross-checking with ps/etimes, and verifying the project-side effects (git status, file mtimes, syntax checks). Distinct from hermes-gateway-doctor (which handles gateway hangs) and from hermes-agent (which is the bundled source-of-truth reference). 4-state 판정 (running / completed / abandoned / errored) + 프로젝트 변경 검증.
version: 1.1.0
author: Hermes Agent
license: MIT
platforms: [macos, linux]
metadata:
  hermes:
    tags: [hermes, subagent, delegate_task, async-delegation, child-session, doctor, log-diagnosis, agent-log, errors-log, ps-etime, project-verification]
    related_skills: [hermes-agent, hermes-gateway-doctor, hermes-telegram-cross-machine-doctor, subagent-driven-development]
---

# Hermes Subagent Diagnosis

## Overview

Hermes에서 메인 세션이 `delegate_task`로 자식 서브에이전트(platform=`subagent`)를 띄우면, 그 작업은 **별도 child session_id**로 로그에 남고, **별도 Python 프로세스**로 실행됩니다. 사용자가 "서브에이전트 결과가 어디 갔지?", "위임한 거 잘 돌아가고 있나?", "delegate_task가 끝난 거 맞아?" 같은 질문을 던질 때, 우리는 4개 신호(프로세스 / agent.log / errors.log / 프로젝트 변경)를 교차 확인해서 **현재 상태를 4-state로 판정**해야 합니다:

1. **running** — 아직 실행 중 (정상)
2. **completed** — `Turn ended: reason=text_response(finish_reason=stop)` 등으로 정상 종료
3. **abandoned** — `Turn ended` 없이 `agent.log`가 침묵. 부분 완료 또는 검증 전 종료
4. **errored** — `errors.log`에 `WARNING/ERROR` 다수, `subagent_stop`에 status=failed

가장 흔한 함정은 "API 호출이 60회 가까이 갔고 patch도 했는데 `Turn ended`가 없으면 = abandoned" 인데, 사용자에게 "성공했습니다"라고 잘못 보고하는 것입니다. **반드시 `Turn ended` 라인을 grep으로 확인**한 후에 정상 완료라고 말합니다.

**2026-07-22 추가**: bytepath-ex 풀스택 위임 케이스 실측. 자식 세션이 46회 API 호출 + 다수 patch + write_file까지 수행했지만, `Turn ended: ... session=20260722_155110_b69124` 가 `agent.log`에 부재. 프로세스도 종료. → **abandoned (부분 완료) 판정** 후 `git status` + `find -mmin` + `luac -p`로 변경 검증이 진짜 보고.

## When to Use

다음 신호 중 하나라도 보이면 즉시 트리거:

- 메인 세션 로그에 `tools.async_delegation: Dispatched async delegation batch deleg_XXXX (1 task(s), ...)` 등장
- 메인 세션이 `delegate_task` 도구 호출을 한 직후
- 사용자: "서브에이전트 뭐 하고 있어?", "delegate_task 결과 어디서 봐?", "위임한 거 끝났나?"
- 자식 세션 ID (예: `20260722_155110_b69124`)가 보이는 로그
- 자식 세션의 `slash_worker` 프로세스가 `ps aux`에 보임
- 메인 세션이 "다른 작업 시키는 중"으로 보이는 동안 자식 세션의 진척을 확인하고 싶음

Don't use for:

- **칸반 작업 확인** → `hermes kanban list` / `hermes kanban show <task_id>` / `hermes kanban watch` 사용. 칸반은 `subagent` 플랫폼이 아니고 영속 SQLite + 워커 풀 + dispatcher로 동작 (별도 진단 체계)
- **게이트웨이 봇 무반응** → `hermes-gateway-doctor` (launchd 데몬, 텔레그램 polling, sticky fallback IP 트랩이 핵심)
- **메인 세션의 tool 사용 추적** → 메인 세션 ID로 `agent.log`를 그대로 보면 됨. 위임된 서브에이전트가 아니므로 본 스킬의 자식 세션 격리 로직이 불필요
- **헤드리스 cron 작업 추적** → `cron-stale-triage` 또는 `hermes cron list` 사용. cron은 subagent와 별개

## The 4-State 판정 매트릭스

| 상태 | ps etime | agent.log 마지막 줄 | errors.log | 프로젝트 변경 | 판정 |
|---|---|---|---|---|---|
| **running** | 살아있음, 누적 시간 증가 중 | `API call #N` 도는 중, `tool_X completed` 반복 | WARNING/ERROR 없거나 무시 가능 수준 | 점진적 변경 | 정상 진행 |
| **completed** | 종료됨, etime 정지 | `Turn ended: reason=text_response(finish_reason=stop) session=<CHILD>` | 마지막 호출 전후에 명시적 fatal 없음 | git status에 명확한 변경 | **정상 종료** |
| **abandoned** | 종료됨 | `Turn ended` 없음, 마지막 활동이 `tool_X completed` 또는 `WARNING` | 비어 있거나 사소한 WARNING | 부분 변경 (find -mmin으로 일부만 갱신) | **부분 완료, 사용자에게 솔직히 보고** |
| **errored** | 종료됨 | `Turn ended` 없음, 마지막 활동이 `WARNING` 또는 `ERROR` | `Tool X returned error ... exit_code=NON_ZERO` 또는 `exception` 다수 | 변경 없거나 빈약 | **실패 보고** |

**핵심**: `Turn ended` 라인이 `agent.log`에 없으면 completed가 아닙니다. running 중에도 일시적으로 안 보일 수 있지만, **프로세스도 종료 + `Turn ended` 부재 = abandoned 또는 errored**.

## 진단 5단계 (가벼운 케이스)

### Step 1: child session_id + delegation_id 추출

메인 세션의 agent.log에서 위임 기록을 찾습니다:

```bash
# delegation ID 추출
grep -RniE "async delegation|Delegated async delegation" ~/.hermes/logs 2>/dev/null | tail -10
# 예: 2026-07-22 15:51:10,669 INFO [20260722_151430_10f62e] tools.async_delegation: Dispatched async delegation batch deleg_525e20d8 (1 task(s), ...)

# child session_id 추출
CHILD=$(grep -RniE "platform=subagent history=0 msg=" ~/.hermes/logs 2>/dev/null | tail -1 | grep -oE "session=[0-9_a-z]+" | head -1 | cut -d= -f2)
echo "child session_id: $CHILD"
```

예시 출력:

```text
deleg_525e20d8
child session_id: 20260722_155110_b69124
```

### Step 2: child session 로그만 추출

```bash
CHILD="20260722_155110_b69124"  # Step 1 결과로 교체
grep -Rni "\[$CHILD\]" ~/.hermes/logs 2>/dev/null > /tmp/subagent-$CHILD.log
wc -l /tmp/subagent-$CHILD.log
```

- 출력이 **0줄** → child session_id가 틀렸거나, 로그가 로테이션. 메인 세션의 `delegate_task` tool response로 받은 session_id를 다시 확인.
- 출력이 **수십~수백 줄** → 정상.

### Step 3: errors.log 교차 확인

```bash
grep -ni "\[$CHILD\]" ~/.hermes/logs/errors.log 2>/dev/null > /tmp/subagent-$CHILD-errors.log
wc -l /tmp/subagent-$CHILD-errors.log
head -30 /tmp/subagent-$CHILD-errors.log
```

흔한 에러 신호:

```text
Tool terminal returned error (60.17s): {"output": "[Command timed out after 60s]", "exit_code": 124, "error": null}
Tool terminal returned error (0.00s): {"output": "", "exit_code": -1, "error": "Foreground command uses '&' backgrounding."}
MCP server 'godot-ai' failed initial connection after 3 attempts, parking ...
```

이런 에러는 **개별 실패**이지 **전체 작업 실패**가 아닙니다. `Turn ended`가 있고 마지막 API call이 stop으로 끝났으면 부분 실패가 있더라도 정상 완료로 봅니다.

### Step 4: 4-state 판정

```bash
# 1) running? — 프로세스 살아있는지
ps -axo pid,etime,state,command | grep "$CHILD" | grep -v grep || echo "(프로세스 없음 — 종료됨)"

# 2) completed? — Turn ended 라인 존재?
grep -E "Turn ended:.*session=$CHILD\b" /tmp/subagent-$CHILD.log && echo "✓ 정상 종료" || echo "✗ Turn ended 부재 (abandoned or errored)"

# 3) 최종 tool call + API call 번호
grep -E "API call #|tool .* completed" /tmp/subagent-$CHILD.log | tail -5
```

**판정 출력 예시 (abandoned case)**:

```text
(프로세스 없음 — 종료됨)
✗ Turn ended 부재 (abandoned or errored)
API call #46: model=MiniMax-M3 provider=minimax in=93099 out=98 total=93197 latency=5.2s
tool read_file completed (0.08s, 15232 chars)
```

→ 46회 API 호출 + 마지막 활동이 read_file → **abandoned 판정**.

### Step 5: 프로젝트 변경 검증

서브에이전트가 무엇을 바꿨는지 확인:

```bash
cd <PROJECT_DIR>  # 예: /Users/mac/work/bytepath-ex

# git이 있는 프로젝트
git status --short
git diff --stat

# 최근 30분 내 변경된 파일 (서브에이전트 작업 추정)
find . -type f -mmin -30 \
  -not -path './.git/*' \
  -not -path './dist/*' \
  -print

# 문법 검증 (언어별)
# Lua
find . -name '*.lua' -not -path './.git/*' -print0 | xargs -0 -n1 luac -p
# TypeScript / JavaScript
npx tsc --noEmit 2>&1 | head -20
# Python
python3 -m py_compile $(find . -name '*.py' -not -path './.git/*' -not -path './.venv/*' | head -50) 2>&1
```

**판정 가드레일**:

- **completed + git diff 있음** → 정상 보고. 사용자에게 "N개 파일 변경됨, K개 patch 적용"으로 요약
- **abandoned + git diff 일부** → "부분 완료" 솔직히 보고. **다음 단계는 (1) 사용자 검수 후 이어서 위임, (2) 롤백 후 다른 subagent, (3) 직접 마무리" 옵션 3개 제시
- **errored + git diff 빈약** → "거의 손대지 못함" 보고. 에러 로그 핵심 1~2줄 인용

## 진단 5단계 (가벼운 케이스) Quick-Reference: 한 줄

```bash
CHILD="20260722_155110_b69124"; \
{ ps -axo pid,etime,state,command | grep "$CHILD" | grep -v grep || echo "(프로세스 종료)"; } && \
echo "---" && \
{ grep -E "Turn ended:.*session=$CHILD\b" ~/.hermes/logs/agent.log* 2>/dev/null && echo "✓ Turn ended"; } || echo "✗ Turn ended 부재" && \
echo "---" && \
grep -E "API call #[0-9]+:.*$CHILD" ~/.hermes/logs/agent.log* 2>/dev/null | tail -1
```

## Common Pitfalls

1. **"`Turn ended` 부재 = 실패"는 사실이지만, "있다 = 무조건 성공" 도 아님** — `Turn ended`는 단순히 LLM이 stop 토큰으로 응답한 것. 그 응답이 빈 문자열이거나 모델이 "작업 완료"라고 거짓말했을 수도 있음. **반드시 git status + diff로 프로젝트 측 변경을 cross-check** 해야 함. (2026-07-22 bytepath-ex 케이스에서 `Turn ended` 부재지만 46회 API + 다수 patch → abandoned 판정이 정답이었음)

2. **child session_id 패턴 혼동** — 메인 세션 `20260722_151430_10f62e` 와 자식 세션 `20260722_155110_b69124` 는 다름. grep 시 **항상 `[CHILD]` 패턴으로 양쪽을 bracketed match** 해야 다른 세션 로그와 섞이지 않음. `grep "$CHILD" ~/.hermes/logs` 는 timestamp가 겹쳐서 다른 세션 로그가 섞일 수 있음. 반드시 `\b$CHILD\b` word boundary 또는 `\[$CHILD\]` 사용.

3. **agent.log가 비어 있는 서브에이전트는 거의 없지만, errors.log가 비어 있는 건 정상** — 서브에이전트가 `delegate_task`로 도착한 직후 첫 tool 호출에서 에러가 나지 않는 한 errors.log는 비어 있을 수 있음. errors.log 0줄 = 정상 신호로 해석. 0줄이 비정상인 건 **프로세스도 0 + `Turn ended`도 0**인 케이스.

4. **메인 세션의 `delegate_task` tool response 안에 child session_id** — 서브에이전트 결과를 받기 전이라도, 메인 세션의 `agent.tool_executor: tool delegate_task completed` 응답 본문(`4311 chars` 등)에 child session_id가 들어있음. **가장 빠른 추출법**: `grep -E "tool delegate_task completed" ~/.hermes/logs/agent.log` 한 줄 찾고, 직전/직후 컨텍스트에서 child session_id grep.

5. **ps에서 `slash_worker`가 살아있다고 서브에이전트가 살아있는 건 아님** — `slash_worker --session-key <ID>` 프로세스는 TUI 세션마다 살아있고, 위임된 subagent와 1:1 매칭이 아님. **반드시 `--session-key` 값이 child session_id와 일치하는 프로세스를 찾거나, child session_id로 etime/cmdline을 grep**. 안 그러면 다른 TUI 세션의 slash_worker를 잘못 보고함.

6. **칸반 작업과 헷갈리지 말 것** — `hermes kanban list` 가 비어있어도 서브에이전트는 정상 동작 중일 수 있음. 위임 = `delegate_task` (메모리 휘발성), 칸반 = 영속 SQLite + dispatcher. **완전히 다른 시스템**. 위임 추적은 본 스킬의 4-state, 칸반 추적은 `hermes kanban` 명령군.

7. **자식 세션의 60번째 turn에서 멈춘 것처럼 보일 수 있음** — `max_iterations=50~60` (config.yaml의 `agent.max_turns`)에 도달하면 `Turn ended: reason=max_iterations` 로 종료. 이건 failed가 아니라 budget exhausted. errors.log도 비어있음. **budget exhausted는 completed의 일종**으로 보고하되, "예산 소진으로 중간에 멈춤"임을 명시. 사용자가 이어서 시키려면 `delegate_task` 재호출 필요.

8. **MCP 실패는 subagent 실패가 아님** — `MCP server 'X' failed initial connection ... parking` 로그는 해당 MCP 도구를 못 쓰는다는 신호일 뿐, subagent 자체가 죽었다는 뜻 아님. LÖVE/Godot 같은 비-MCP 프로젝트는 무관. 본 스킬 진단의 본질은 **`Turn ended` 유무 + 프로젝트 변경 + errors.log의 fatal 신호** 3가지.

9. **tool별 시간 초과(60s)는 부분 실패일 뿐, 작업 실패가 아님** — `Tool terminal returned error (60.17s): exit_code=124`는 그 한 명령만 60초 timeout. LLM이 다음 turn에서 우회하거나 다른 도구로 대체하는 게 정상 패턴. **errors.log 다수 + `Turn ended` 부재 = errored**, **errors.log 일부 + `Turn ended` 정상 = completed (with warnings)**. 두 케이스 구분 필수.

10. **헤드리스 부팅 검증 시 60s + '&' backgrounding 동시 노출 함정** (2026-07-22 bytepath-ex 케이스) — LÖVE/Godot/Unity 헤드리스 부팅을 `terminal(foreground)`로 띄우면 default 60s timeout 초과 → LLM이 `&`로 우회 → 즉시 차단 (`Foreground command uses '&' backgrounding`). **올바른 패턴**: 처음부터 `terminal(background=True, timeout=10)` + `process(action='poll'/'log'/'kill')` + 검증 명령은 별도 `terminal(foreground)`. **subagent가 이 두 함정을 동시에 만나는 것은 부팅 검증 의도에서 매우 흔하므로** 위임 작업 설명에 "헤드리스 부팅은 background=True로" 한 줄 포함 권장. 상세: `references/headless-boot-verification-pattern.md`.

11. **사용자에게 "성공했습니다"라고 보고하기 전 4중 가드**:
    ```text
    □ 1) ps etime 또는 종료 확인 — 프로세스 살아있으면 running, 끝났으면 다음 검사
    □ 2) agent.log에 `Turn ended: ... session=<CHILD>` 존재 — 있으면 정상 종료 신호
    □ 3) errors.log에 fatal 패턴 (exit_code != 0 다수, exception) 없는지
    □ 4) 프로젝트 디렉터리에서 `git status` + 변경 파일 검증
    ```
    4개 다 통과해야 "성공". 1개라도 빗나가면 솔직히 "부분 완료" 또는 "실패" 보고. **사용자 신뢰는 fabricate "성공" 한 번에 깨지고, "abandoned였음" 정직 보고 10번 쌓여도 안 깨짐** (memory §솔직한 보고 패턴).

## Verification Checklist

진단 후 다음을 모두 확인:

- [ ] child session_id를 메인 세션의 `delegate_task` tool response에서 추출 (또는 `tools.async_delegation: Dispatched` 로그에서 child ID grep)
- [ ] `\[CHILD_ID\]` 패턴으로 자식 로그만 격리 (다른 세션과 섞이지 않게)
- [ ] ps에서 child session_id의 프로세스 상태 (살아있음 / 종료) 확인
- [ ] `Turn ended: ... session=<CHILD_ID>` 라인 존재 여부 grep
- [ ] 마지막 API call 번호 + 마지막 tool 호출 (의미 있는 작업으로 끝났는지)
- [ ] errors.log의 fatal 신호 (exit_code != 0, exception) 다수 여부
- [ ] 프로젝트 디렉터리에서 `git status --short` + `git diff --stat`
- [ ] 30분 내 변경 파일 `find -mmin -30`
- [ ] 문법 검증 (해당 언어: luac -p / tsc --noEmit / py_compile)
- [ ] **4-state (running/completed/abandoned/errored) 중 하나로 확정**
- [ ] 사용자에게 솔직히 보고 — "성공"/"부분 완료"/"실패" 중 정확한 라벨

## Cross-Reference: 다른 진단 스킬과의 경계

| 스킬 | 담당 | 본 스킬이 아님 |
|---|---|---|
| `hermes-gateway-doctor` | launchd 데몬 / 텔레그램 polling / sticky fallback IP / 409 Conflict | ✓ |
| `hermes-telegram-cross-machine-doctor` | 같은 LAN의 여러 Hermes 인스턴스 cross-check (4-Question protocol) | ✓ |
| `hermes-agent` (bundled) | Hermes Agent 소스/CLI/스킬 라이브러리 자체 (source of truth) | ✓ |
| `subagent-driven-development` | **delegate_task로 구현 계획을 실행**하는 스킬 (plan + worker loop) | ✓ |
| `kanban-codex-lane` | 칸반 워커가 Codex CLI를 백엔드로 쓰는 패턴 | ✓ |
| **본 스킬** | 위임된 subagent의 **현재 상태를 사후 진단** | ← 본 스킬 |

**요약**: 본 스킬은 `subagent-driven-development` (실행) 와는 다른 **관측/진단** 역할. 실행이 끝난 후 또는 진행 중에 "지금 뭐 하고 있지?" / "잘 끝났나?"를 묻는 모든 상황에 발동.

## Support Files

- `references/4-state-judgment-examples.md` — 실측 4-state 판정 사례. `running` / `completed` / `abandoned` / `errored` 각각의 agent.log 발췌 + git diff 발췌 + 사용자 보고 템플릿. 2026-07-22 bytepath-ex 케이스 전체 (60s timeout + '&' backgrounding 2회 warning).
- `references/quick-diagnosis-one-liner.md` — 한 줄 진단 명령 5종 (상황별: 진행 중 / 종료 + 정황 모를 때 / 명시적 ID 있을 때 / 칸반과 헷갈릴 때 / cron과 헷갈릴 때).
- `references/headless-boot-verification-pattern.md` — **2026-07-22 신규**: LÖVE/Godot/Unity 헤드리스 부팅 검증 시 60s timeout + '&' backgrounding 두 함정을 동시에 만나는 패턴의 회피법. `terminal(background=True, timeout=10)` + `process(poll/log/kill)` + 검증 명령 별도 호출 패턴. 엔진별 권장 명령 (LÖVE/`love .`, Godot/`--headless --quit`, Unity/`-batchmode -nographics -quit`).
- `scripts/scan-child-sessions.sh` — 현재 살아있는 모든 child session_id를 ps + agent.log에서 한 번에 추출하는 셸. multi-agent 워커가 동시에 여러 서브에이전트를 띄운 경우에 유용. (예정)
