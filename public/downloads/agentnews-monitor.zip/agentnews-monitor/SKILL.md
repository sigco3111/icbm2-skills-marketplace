---
name: agentnews-monitor
description: AgentNews 실시간 모니터링 — 매시간 AI 에이전트 뉴스 피드를 확인하고 관심사 매칭 뉴스를 threshold 기반으로 알림 (하루 2~3건 제한)
version: 1.0.0
author: ICBM2
metadata:
  hermes:
    tags: [AgentNews, AI News, Real-time Alert, Monitoring]
---

# ICBM2 AgentNews 실시간 모니터

## 개요

AgentNews (https://agent.news) 피드를 매시간 확인하여, 주인님의 관심사와 높게 매칭되는 뉴스만 실시간 알림으로 전송합니다. morning-briefing에 이미 AgentNews가 통합되어 있지만, 이 스킬은 **실시간 알림**에 초점을 맞춥니다.

## 작동 방식

1. **매시간 피드 확인** — `https://agent.news/api/v1/feed` 에서 최신 아이템 조회
2. **키워드 매칭** — 주인님 관심사 키워드 + 가중치 기반 점수 계산
3. **Threshold 필터** — 점수 12점 이상만 알림 대상
4. **일일 제한** — 하루 최대 3건까지만 알림 발송
5. **중복 제거** — 이미 본 아이템은 건너뜀

## 점수 시스템

### 카테고리 가중치
- `insight`: +3 (가치 높음)
- `tool`: +2 (실용적)
- `infrastructure`: +2 (중요)
- `show`: +0 (낮음)

### 관심사 키워드 (점수)
| 카테고리 | 키워드 | 점수 |
|---------|--------|------|
| AI/ML 핵심 | AI model, LLM, GPT, Claude, OpenAI, Anthropic | 9-10 |
| AI 에이전트 | AI agent, MCP, agentic | 10 |
| iOS/Apple | iOS, Swift, WWDC, Apple | 8-10 |
| 투자 | NVIDIA, semiconductor, IPO | 7-8 |
| 개발 | automation, developer tool | 6-7 |

최종 점수 = 카테고리 가중치 + 매칭 키워드 점수 합

## 실행

### 일반 실행 (크론용)
```bash
python3 scripts/agentnews_monitor.py
```

출력이 있으면 알림 대상, `NO_ALERTS:` 로 시작하면 알림 없음.

### 상태 확인
```bash
python3 scripts/agentnews_monitor.py --stats
```

### 일일 카운터 리셋
```bash
python3 scripts/agentnews_monitor.py --reset
```

## 상태 파일

`memory/agentnews_state.json`:
```json
{
  "seen_ids": ["id1", "id2"],
  "daily_alerts": [{"id": "...", "title": "...", "score": 15}],
  "last_alert_date": "2026-04-09"
}
```

- `seen_ids`: 최대 500개 유지 (자동 정리)
- `daily_alerts`: 매일 자정(KST) 자동 리셋

## 크론 설정

```bash
# 매 정시 5분에 실행 (AgentNews 업데이트 :55분 이후)
# 05 * * * * → 하루 24번 확인, 알림은 최대 3건
```

## 주의사항

- 알림 없음(`NO_ALERTS:`)일 때는 메시지 전송하지 않음 (스팸 방지)
- threshold 조정 필요하면 스크립트의 `MIN_SCORE_THRESHOLD` 변경
- 키워드 추가/수정 필요하면 `INTEREST_KEYWORDS` 딕셔너리 편집
- 일일 제한 변경은 `DAILY_ALERT_LIMIT` 조정
