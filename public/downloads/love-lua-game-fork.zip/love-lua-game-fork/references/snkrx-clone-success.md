># SNKRX 한국어화 fork — 30분 + 6개 버전 성공 사례

> **날짜**: 2026-07-21
> **저장소**: https://github.com/sigco3111/snkrx-clone
> **원본**: https://github.com/a327ex/SNKRX (MIT, ⭐~2k)

## 무엇을 했나

LÖVE 11.5 + LuaJIT 5.1 기반 로그라이크 오토배틀러 게임 SNKRX를 fork해서 한국어 환경에 맞게 다음을 적용:

| 항목 | 결과 |
|---|---|
| 메인 메뉴 5버튼 | 한글 |
| 상점 (shop/party/classes/items) 탭 | 한글 |
| 영웅 이름/클래스/설명 (hover) | 한글 (~57 영웅) |
| Lv.3 효과 이름/설명 | 한글 |
| 옵션 메뉴 전체 | 한글 |
| Arena 승리/패배/엔딩 | 한글 |
| 안내 메시지 (골드 부족 등) | 한글 |
| Steam 클라이언트 의존 | shim으로 우회, MIT 코드만 실행 |
| macOS Retina 풀스크린 함정 | 해결 |
| 창 크기 1280x720 비례 확대 | OK |

## 시간순 진행 (30분 + 누적 작업)

```
00:00 [요청] SNKRX 클론 + 개선
00:02       클론 완료 (Linux/macOS 빌드 분류)
00:05       LÖVE 설치 + Gatekeeper quarantine 해제
00:08       Steamworks shim 작성 → love 실행 → 첫 에러 (luasteam 없음)
00:10       shim 수정 (runCallbacks 누락) → 재실행
00:12       UTF-8 byte iteration 에러 (UTF-8 decoding error)
00:18       lead byte 분석 fix → 한글 정상
00:22       type guard (숫자 footgun) → buy_screen 진입 OK
00:25       첫 GitHub push (v0.1) — ko.lua + T() + CJK 폰트 + Steam shim
00:30 [검증] 사용자가 GUI에서 정상 동작 확인

--- 다음 세션 (위임 풀스택) ---
[+] v0.1.1: 영웅 70+ 이름 + 옵션 메뉴 T() 적용
[+] v0.1.2: hover 영웅 이름 + 라벨 T() 적용
[+] v0.1.3: hover 설명 본문 + 클래스명 + 효과 이름 한글화
[+] v0.1.4: Lv.3 효과 설명 + 옵션 토글 한글화
[+] v0.1.5: arena 승리/패배 + 일시정지 + 옵션 볼륨 한글화
[+] v0.1.6: 안내 메시지 + 승리/엔딩 메시지 + 외부 게임 추천
```

## 핵심 코드 변경 파일

| 파일 | 변경 |
|---|---|
| `MODIFIED.md` | 라이선스 의무 + 변경 이력 |
| `shared.lua` | `T(key, default)` + `lang` 모듈 + ko.lua 로딩 |
| `engine/graphics/font.lua` | `has_cjk` + `get_font_for_text` + type guard |
| `engine/graphics/text.lua` | UTF-8 character 단위 파싱 + CJK 너비 |
| `engine/graphics/graphics.lua` | `print/print_centered` CJK 폰트 선택 |
| `engine/init.lua` | state.sx 가드 + setMode 풀스크린 옵션 명시 |
| `engine/external/init.lua` | luasteam shim 경로로 require |
| `engine/external/luasteam.lua` | 신규 — Steamworks no-op shim |
| `main.lua` | 옵션 메뉴 T() + 일시정지 controls T() |
| `mainmenu.lua` | 메인 메뉴 5버튼 T() |
| `buy_screen.lua` | 상점 탭 + hover CharacterIcon + 안내 메시지 |
| `arena.lua` | 승리/패배/엔딩/credits/loop T() |
| `conf.lua` | 1280x720 + usedpiscale=false |
| `lang/ko.lua` | 신규 — 150+ 키 번역 테이블 |
| `lang/character_descriptions_ko.lua` | 신규 — 57 영웅 설명 함수 |
| `lang/character_effect_descriptions_ko.lua` | 신규 — 57 Lv.3 효과 설명 함수 |
| `assets/fonts/NotoSansKR-Regular.ttf` | 신규 — 한글 폰트 fallback |

## 가장 큰 디버깅 교훈 5가지

### 1. UTF-8 byte vs character iteration

**증상**: `engine/graphics/text.lua:139: UTF-8 decoding error: Not enough space`

**원인**: 원본 `for i = 1, #line.text do c = line.text:sub(i, i)` — `#text`는 바이트, `sub(i,i)`는 1바이트. 한글 `아`는 UTF-8 3바이트라서 깨진 바이트가 `c.character`에 들어가서 `Font:getWidth()`에서 크래시.

**해결**: lead byte 분석으로 UTF-8 character 단위 반복.

**교훈**: 모든 다국어 게임 fork 시 첫 단계에서 byte-iteration 패턴 grep.

### 2. Steamworks shim — runCallbacks 누락

**증상**: `engine/init.lua:149: attempt to call field 'runCallbacks' (a nil value)`

**원인**: 첫 shim 작성 시 `userStats`/`friends`만 정의하고 `runCallbacks` 빼먹음. 메인 루프의 `steam.runCallbacks()` 호출이 첫 프레임 직후 크래시.

**해결**: shim에 `function M.runCallbacks() end` 추가.

**교훈**: `grep -rn "steam\.\w\+\.\w\+" --include="*.lua"` → 모든 호출 추출 후 shim에 정의. `runCallbacks`가 가장 흔히 빠짐.

### 3. macOS Retina state.sx 풀스크린

**증상**: 게임을 한 번이라도 실행하면 다음 실행 시 풀스크린으로 시작.

**원인**: `state.sx=4` (이전 풀스크린 게임)이 `state.txt`에 저장 → `setMode(state.sx * gw, state.sy * gh) = setMode(1920, 1920)` → macOS가 자동 풀스크린.

**해결**: `state.sx >= 0.5 and state.sx <= 3` 범위 가드 + `state.txt` 삭제.

**교훈**: M4 Mac 사용자에게 LÖVE 게임 fork 시 `state.sx` 가드 필수.

### 4. `usedpiscale` Retina DPI 스케일링

**증상**: `setMode(1280, 720)` 호출해도 UI가 작게 보임.

**원인**: `t.window.usedpiscale = true` (기본값)이 Retina DPI 자동 적용 → love2d 내부 좌표계 1/2 축소.

**해결**: `conf.lua`에 `t.window.usedpiscale = false` 추가.

**교훈**: "창은 큰데 오브젝트 작다" 정정 시 1순위로 의심.

### 5. patch() fuzzy-match collision

**증상**: buy_screen.lua 패치 후 `end expected near <eof>` syntax 에러.

**원인**: `patch()`가 비슷한 `function ItemCard:on_mouse_enter()...end`를 우연히 매칭 → 중복 함수 정의.

**해결**: patch() 호출 시 context 최소 5줄 + 패치 후 즉시 `luac -p` 검증.

**교훈**: Lua 게임에서 `function X:method_name()` 라인은 항상 unique anchor 만들기.

## 모드팩 패턴 (sango vs SNKRX 차이)

| 게임 | 데이터 구조 | 모드팩 방식 |
|------|------------|------------|
| **sango-rising-dragons** | JSON 파일 (`public/data/{pack}/*.json`) | `mergeById` 함수로 id 기반 머지 |
| **SNKRX** | Lua 코드 내장 (영웅 이름이 `character_names['vagrant']` 테이블) | `T('char_' .. key, default)` 함수 + `lang/ko.lua` 모듈 |

**공통점**:
- 원본 데이터 보존
- 영어 fallback 보장 (default)
- 새 언어 추가 쉬움 (한 줄 변경)

**차이점**:
- JSON 게임 → 데이터 파일 단위 모드팩
- Lua 게임 → 텍스트 단위 모드팩 (함수 테이블은 `lang.<table>_ko`로 별도 파일)

## 검증 도구

### luac -p (헤드리스 syntax 검증)

```bash
for f in shared.lua main.lua mainmenu.lua buy_screen.lua arena.lua enemies.lua player.lua \
         objects.lua media.lua engine/graphics/font.lua engine/graphics/text.lua \
         engine/graphics/graphics.lua lang/ko.lua; do
  echo -n "$f: "
  luac -p "$f" 2>&1 && echo "OK"
done
```

### love 백그라운드 alive 확인

```bash
love . > /tmp/love_run.log 2>&1 &
LOVE_PID=$!
sleep 5
ps -p $LOVE_PID -o pid,stat,command
# STAT=Ss = 정상 sleep (메인 루프 진입)
cat /tmp/love_run.log
kill -9 $LOVE_PID
```

### HTTP 검증 (gh repo create 후)

```bash
curl -s -o /dev/null -w "HTTP %{http_code}\n" "https://api.github.com/repos/sigco3111/snkrx-clone"
# HTTP 200 = OK
```

## 누적 통계

| 항목 | 값 |
|---|---|
| 총 버전 | 6개 (v0.1 ~ v0.1.6) |
| 총 커밋 | 6개 (604dd92 ~ bdadc0b) |
| 신규 파일 | 5개 (MODIFIED.md, lang/*.lua ×3, fonts/*.ttf) |
| 변경 파일 | 13개 |
| 번역 키 | 150+ 개 |
| 영웅 번역 | 70+ 개 |
| 클래스명 | 16개 |
| 효과 이름 | 60+ 개 |
| 효과 설명 | 60+ 개 |

## GitHub 푸시 기록

```bash
# 1차
gh repo create sigco3111/snkrx-clone --public --description "SNKRX 한국어화 + UI/콘텐츠 개선 fork" --source=. 2>&1 | tail -5
# → 404 가능성, 반드시 curl 200 확인
curl -s -o /dev/null -w "HTTP %{http_code}\n" "https://api.github.com/repos/sigco3111/snkrx-clone"

# 2차~6차
git -c user.email="sigco3111@users.noreply.github.com" -c user.name="sigco3111" commit -m "..."
git push origin master
```

## 다음 단계 (v0.2+)

- **콘텐츠 확장**: 새 영웅/클래스/시너지 추가
- **신 게임 모드**: 보스 레이드, 데일리 챌린지
- **풀 자동위임**: sango 결정 큐 패턴 적용

---

# SNKRX 옵션 영구 저장 v0.1.20~v0.1.21 (2026-07-22, 후속 세션)

## 사용자 요구

"옵션의 모든 설정값이 저장되었으면 함. 창크기나 전체화면등은 저장이 안되는 것 같음."

→ **사용자가 옵션 변경 → 게임 종료 → 재시작** 시 **창 크기, 전체화면, 사운드/음악 볼륨, 토글 설정**이 모두 유지되어야 함.

## 발견된 진짜 버그 3개

### 버그 1: 옵션 변경 시 save_state() 호출 안 됨

**증상**: 옵션 화면에서 sfx/music 볼륨, 창 크기, 토글 등을 변경해도 **state.txt에 저장 안 됨**. 다음 시작 시 모든 값 기본값.

**원인**: `main.lua`의 옵션 버튼들이 `state.xxx = yyy`만 설정하고 `system.save_state()` 호출 안 함. 원본 SNKRX도 같은 패턴 — 사용자가 한 번 게임을 시작해서 메뉴 진입 시 state.txt가 자동 생성되지만, 옵션 변경은 그 후.

**해결 — 매 클릭마다 save**:
```lua
self.music_button = Button{..., action = function(b)
  music.volume = music.volume + 0.1
  state.music_volume = music.volume
  b:set_text(...)
  system.save_state()  -- ★ v0.1.21: 매 옵션 변경마다
end}
```

**모든 옵션 버튼에 추가**:
- sfx_button.action / action_2
- music_button.action / action_2
- video_button_1, 2, 3, 4
- screen_shake_button
- cooldown_snake_button
- arrow_snake_button
- screen_movement_button

### 버그 2: `state.sx` 매번 덮어써짐

**증상**: 사용자가 옵션에서 'window size+' 1번 눌러서 1280×720 (sx=2.666) → 종료 → 재시작 → **800×600 (sx=1.666) 복귀**.

**원인**: `engine/init.lua:97`의 `state.sx, state.sy = sx, sy` **무조건 덮어쓰기** (v0.1.18 풀스크린 회피 패치에서 추가됨). 사용자가 설정한 값이 다음 시작에 무시됨.

**v0.1.20 첫 시도** (use_state_sx 가드 빈약):
```lua
-- ❌ use_state_sx가 가드 범위 (0.5~3) 안일 때만 true
if state.sx and state.sy and state.sx >= 0.5 and state.sx <= 3 then
  sx, sy = state.sx, state.sy
  use_state_sx = true
else
  sx, sy = window_width/480, window_height/270  -- 새로 계산 → 덮어씀
end
if not use_state_sx then state.sx, state.sy = sx, sy end
```

**문제**: sx=4 (풀스크린 시) → 가드 밖 → `use_state_sx=false` → 덮어씀 → 무한 풀스크린.

### 버그 3: `state.fullscreen` 저장 안 됨 + sx 충돌

**증상**: 'fullscreen' 옵션 클릭 → 풀스크린 됨 → 종료 → 재시작 → 풀스크린은 적용되지만 **게임 캔버스는 디폴트 크기(800×600)로 좌상단 출력**.

**원인**: `video_button_3` (fullscreen)가 `setMode(window_width, window_height, {fullscreen = true})` 호출 — `window_width = 데스크톱(예: 1920)`. setMode는 풀스크린으로 변환하지만, **캔버스 크기 동기화 안 됨** (love2d 11.5 알려진 버그 가능성). 또 `state.fullscreen = true` 저장 안 함.

**해결**:
```lua
self.video_button_3 = Button{..., action = function()
  local _, _, flags = love.window.getMode()
  local window_width, window_height = love.window.getDesktopDimensions(flags.display)
  sx, sy = window_width/480, window_height/270
  state.sx, state.sy = sx, sy
  ww, wh = window_width, window_height
  state.fullscreen = true  -- ★ v0.1.21: 풀스크린 상태 저장
  love.window.setMode(window_width, window_height, {fullscreen = true})  -- ★ 풀스크린으로 setMode
  system.save_state()
end}
```

## v0.1.21 최종 해결 — `state.fullscreen == true` 분기 최우선

**engine/init.lua**:
```lua
gw, gh = config.game_width or 480, config.game_height or 270

local use_state_sx = false
if state.fullscreen == true then
  -- ★ 풀스크린 모드: 데스크톱 크기 그대로
  sx, sy = window_width/(config.game_width or 480), window_height/(config.game_height or 270)
  use_state_sx = true  -- state.sx 덮어쓰지 않음
elseif config.window_width == 'max' or config.window_width == 'half' or type(config.window_width) == 'number' then
  sx, sy = window_width/(config.game_width or 480), window_height/(config.game_height or 270)
elseif state.sx and state.sy and state.sx >= 0.5 and state.sx <= 3 and state.sy >= 0.5 and state.sy <= 3 then
  sx, sy = state.sx, state.sy
  window_width = math.floor(sx * (config.game_width or 480))
  window_height = math.floor(sy * (config.game_height or 270))
  use_state_sx = true
else
  sx, sy = window_width/(config.game_width or 480), window_height/(config.game_height or 270)
end
ww, wh = window_width, window_height

local fullscreen_mode = state.fullscreen == true

if not use_state_sx then
  state.sx, state.sy = sx, sy
end
love.window.setMode(window_width, window_height, {
  vsync = config.vsync,
  msaa = msaa or 0,
  display = 1,
  fullscreen = fullscreen_mode,
  borderless = false,
  resizable = true,
})
```

**핵심**: `state.fullscreen == true`면 **`use_state_sx = true` 강제** → state.sx 덮어쓰지 않음 → 다음 시작 시 풀스크린 유지.

## 검증 시나리오 + 결과

| 시나리오 | 결과 |
|---|---|
| state 없음 (첫 실행) → 자동 저장 | `sx=1.666, sy=1.666, fullscreen=false` ✅ |
| state.sx=2.666 수동 → 재시작 | `sx=2.666` 유지 ✅ |
| state.fullscreen=true → 재시작 | `fullscreen=true`, `sx=2.666` 유지 ✅ |
| state.sx=4 (비정상) → 재시작 | `sx`가 가드 밖이라 무시 → 1.666으로 재계산 ✅ |

## 시간순

```
14:00 [v0.1.20] v0.1.18 setMode 덮어쓰기 회피 + use_state_sx 가드
14:02       luac OK
14:05       state.sx=2.666으로 시작 → state.sx=2.666 유지 확인 ✓
14:08       fullscreen=true 시작 → state.txt에 fullscreen=true 저장 확인 ✓
14:12 [v0.1.21] 모든 옵션 버튼에 system.save_state() 호출 추가
14:15       sfx/music 볼륨 / window size± / fullscreen / 토글 4종
14:18       빌드 + GitHub Release 4개 asset 업로드
14:25       커밋 + 푸시
14:28 [끝] v0.1.21 완료
```

## 핵심 교훈

1. **모든 옵션 변경 시 save_state() 필수**: 토글, 볼륨, 비디오, 풀스크린 — **state.xxx 변경 후 무조건 `system.save_state()` 호출**
2. **`state.fullscreen == true` 분기 최우선**: 풀스크린과 state.sx 보존이 **상호 충돌** (sx=4 vs 가드 0.5~3) → 풀스크린 분기에서 use_state_sx = true 강제
3. **setMode 옵션에 fullscreen = fullscreen_mode**: state 기반 풀스크린 모드 전달 (config 기반 강제 false가 아닌)
4. **state.sx 가드 범위 (0.5~3)**: 비정상 데이터(데스크톱 크기 4) 보호
5. **state.txt 위치**: macOS `~/Library/Application Support/LOVE/{game_name}/state.txt` — 비정상 동작 시 가장 먼저 의심

## 옵션 영구 저장 표준 체크리스트

**engine/init.lua**:
- [ ] `use_state_sx` 가드 + fullscreen 분기
- [ ] `setMode({fullscreen = fullscreen_mode})`
- [ ] `if not use_state_sx then state.sx = sx end`

**main.lua 옵션 버튼** (각각):
- [ ] `state.xxx = yyy` 설정
- [ ] `b:set_text(...)` 라벨 갱신
- [ ] `system.save_state()` ← ★ 가장 빠뜨리기 쉬움

**state.fullscreen 저장 위치**:
- [ ] `video_button_3` (fullscreen 버튼) — setMode 호출 전 `state.fullscreen = true` 후 save_state
- [ ] `video_button_4` (reset video) — `state.fullscreen = true` (원본 동작)

**검증 시나리오 (수동)**:
1. state.txt 비우고 게임 실행 → 기본값으로 시작
2. 옵션에서 창 크기 변경 → 종료
3. `cat state.txt` → 변경된 값 저장 확인
4. 게임 재시작 → 변경된 값으로 시작
5. 옵션에서 fullscreen 클릭 → 종료
6. `cat state.txt` → `fullscreen=true` 확인
7. 게임 재시작 → 풀스크린으로 시작

→ 옵션 영구 저장 미구현 시 가장 먼저 의심할 곳: `main.lua`의 각 옵션 버튼에 `system.save_state()` 호출 누락.

---

# SNKRX 빌드 + GitHub Release 워크플로우 (v0.1.12, 2026-07-21)

## 사용자 요구

"윈도우에서 어떻게 실행하지?" → "방법1로 진행" → run.bat 추가 → ASCII 인코딩 / 한글 경로 / .love zip 인식 3개 버그 차례로 수정.

## v0.1.13~v0.1.19 디버깅 흐름

```
v0.1.13: build_all.sh에 Windows run.bat/README.txt 자동 생성 추가
v0.1.14: 첫 Windows zip에 run.bat 누락 발견 (즉시 수정)
v0.1.15: run.bat 수정 (ci love-11.5-win64 진입)
v0.1.16: 한글 깨짐 (UTF-8 디코더) → ASCII 전용으로 변경
v0.1.17: love.exe 경로 → cd love-11.5-win64 추가
v0.1.18: .love zip 인식 실패 → game/ 폴더 방식 (한글 경로 우회)
v0.1.19: .love zip도 함께 포함 (사용자 선택권)
```

## 핵심 버그 3개와 해결

### 1. `run.bat` 한글 깨짐

**증상**: CMD에서 `k`, `0"`, `krx-kr-v0.1.12.love` 같은 깨진 ASCII 단편이 명령으로 실행 → `'love.exe'은(는) 내부 또는 외부 명령...` 에러.

**원인**: run.bat이 UTF-8 한글로 작성 → Windows CMD 코드페이지 949에서 디코딩 실패.

**해결**: run.bat을 **순수 ASCII** (영문) 명령으로 작성.

```bat
@echo off
REM SNKRX Korean fork launcher (Windows)
cd /d "%~dp0"
love.exe snkrx-kr-v0.1.12.love
if errorlevel 1 (
    echo.
    echo Game failed to start.
    echo Install Visual C++ 2013 Redistributable.
    echo Or run: lovec.exe snkrx-kr-v0.1.12.love
    pause
)
```

**핵심**: `keyup`이 **e.key 검사 없이** 무조건 `inputX = 0`으로 리셋 → 0.5초 누르면 90도 회전 후 멈춤 (사용자 인식 "90도만 움직임").

**해결**: keyup에 e.key 검사 → 정확한 키만 0으로 리셋:

```lua
window.addEventListener('keyup', (e) => {
  if (e.key === 'a' || e.key === 'A' || e.key === 'ArrowLeft') inputX = Math.max(0, inputX);
  else if (e.key === 'd' || e.key === 'D' || e.key === 'ArrowRight') inputX = Math.min(0, inputX);
  // ... W, S도 동일
});
```

**Math.max(0, -1) = 0**: A 떼면 좌측 입력이 0, 우측 입력이 있으면 유지. W/S도 동일.

**즉시 적용 규칙** (Lua 게임 + 모든 키보드 입력 시스템):
1. **keyup은 e.key 검사**: 정확한 키만 0으로 리셋
2. **Math.max(0, -1) / Math.min(0, 1)**: 단방향 입력 유지
3. **테스트**: 0.5초 이상 길게 키 누르고 회전량 확인 — 정상이면 v0.1.17 fix 적용

## v0.1.17~v0.1.18 디버깅 — 전진 안 됨 (4단계 검증)

**사용자 정정**: "뱀이 이동하지지 않음. (좌/우 회전만됨.)"

**1단계**: 로그 추가 → 회전만 작동 확인. headX/Y 증가하지만 사용자가 "기본값"으로 인식.

**2단계 의심**: setMode 후 `setCameraPos` 호출 안 됨 → 카메라 (0, 0) 고정 → 뱀이 화면 밖.

**3단계 의심**: keyup이 모든 키 input 리셋 → 0.5초 누르면 90도 회전 후 멈춤.

**4단계 의심**: `use_state_sx` 가드 빈약 → state.sx 매번 덮어써짐.

**최종 해결** (4개 모두):
1. `drawWorld`에 `setCameraPos(player.headX, player.headY)` 명시 호출
2. keyup에 e.key 검사 + Math.max(0, ...) 패턴
3. `use_state_sx` 가드 + `state.fullscreen == true` 분기
4. 옵션 버튼마다 `system.save_state()` 호출

## 검증 자동화 (snkrx-web에서 유래)

**Headless 검증** (LÖVE 게임 fork 표준 도구):
- `luac -p <file>.lua` — syntax 검증
- `love .` 백그라운드 실행 + `ps` 로 alive 확인 + stderr 체크
- `gh repo create` 후 `curl 200` 확인

**즉시 적용 규칙**:
1. **luac -p로 모든 .lua 검증**: 헤드리스에서도 가능
2. **love 백그라운드 실행 5초 + ps STAT=Ss 확인**: 메인 루프 진입 확인
3. **gh repo create 후 curl 200**: 404면 remote 재설정
4. **state.txt 비정상 의심 시 즉시 `rm`**: 다음 실행에서 깨끗한 기본값으로 시작

## snkrx-web 프로젝트 사망 원인 (2026-07-21)

**시도**: SNKRX 한국어화 + LÖVE → HTML5 Canvas 2D로 직접 포팅 (TypeScript + Vite).

**사망 이유**:
- LÖVE 11.5 공식 웹 빌드 없음 (Davidobot/love.js 등 커뮤니티 도구도 deprecated)
- 직접 TypeScript + Canvas 2D로 처음부터 빌드 시도
- 1단계 (스캐폴딩) + 2단계 (데이터) + 3단계 (렌더) + 4단계 (게임 코어) + 5단계 (상점) + 7단계 (데모 통합) 완료
- **데모 실행 시**: 뱀 회전만 되고 전진 안 됨. 적 충돌 시 라이프 0 → 즉시 게임 오버 → 무한 루프
- 버그 fix 시도 (invulnerable 음수 방지, keyup e.key 검사, use_state_sx 가드, autoTarget 버그) — **복잡도 누적 + Lua SNKRX와 다른 버그 클래스 (Canvas 2D 렌더링, TypeScript verbatimModuleSyntax, LÖVE local 함수 의존성 등)**
- **품질 낮음 → 폐기 결정**

**교훈** (sango-rising-dragons 성공 사례와 비교):
- **sango**: 모드팩 패턴 + LÖVE/Lua 게임의 Lua 함수 의존성 없음 → TypeScript + Vite로 6시간 만에 성공
- **snkrx-web**: SNKRX는 LÖVE 11.5 + LuaJIT + 22K LOC + 자체 엔진 → TypeScript 직접 포팅은 **복잡도 폭발**
- **결론**: LÖVE 게임의 LÖVE → Web 포팅은 **deprecated된 love.js 도구 또는 wasm-4 / Emscripten** 사용해야 함. **직접 TypeScript 포팅은 권장 안 함**

**즉시 적용 규칙** (LÖVE/Lua 게임 → Web):
1. **공식 love2d 빌드 11.5 확인**: `https://github.com/love2d/love/releases` — web release 없음 확인
2. **love.js (Davidobot) deprecated**: `gh repo` 검색 + `archived: true` 필터
3. **wasm-4 또는 Emscripten**: LÖVE 코드 → WASM 컴파일. 빌드 시스템 복잡도 매우 높음
4. **직접 TypeScript 포팅**: 큰 게임 (10K+ LOC)에는 부적합. 작은 게임만 가능.

**snkrx-web 폴더 (200M)는 이미 삭제됨** (2026-07-21). 새로 시작 시 위 결정 트리 적용.

## TypeScript verbatimModuleSyntax 함정 (v0.1.7, 2026-07-21)

**증상**: `error TS1484: 'EntityKind' is a type and must be imported using a type-only import when 'verbatimModuleSyntax' is enabled.`

**원인**: Vite 8이 생성한 tsconfig.json이 `verbatimModuleSyntax: true` + `noEmit: true` 기본값. **type과 value를 한 import에서 같이 가져오면 에러**.

**해결**:
- tsconfig.json에서 `verbatimModuleSyntax: true` 제거 (개발 시)
- 또는 모든 import에 `import type { EntityKind }` 명시

**즉시 적용 규칙** (TypeScript + Vite 프로젝트):
1. **tsconfig.json** 작성 시 `verbatimModuleSyntax: false` 권장 (개발 시)
2. 또는 모든 type-only import를 `import type`으로 명시
3. **Vite 8 기본값**: tsc 컴파일 + Vite 빌드 — strict 모드 OK

## linter/preview 오탐 (2026-07-21)

**증상**: patch 도구의 linter가 'TS5112 tsconfig.json present but will not be loaded if files are specified' 경고 → 실제로는 컴파일 정상.

**원인**: linter는 patch가 파일 직접 지정 → tsconfig 자동 로드 안 함 → "직접 명령으로 실행할 때는 tsconfig 무시됨" 경고.

**즉시 적용 규칙** (patch 도구 사용 시):
1. **linter 경고 ≠ 컴파일 에러**: `npm run build` 또는 `npx tsc --noEmit` 결과로 판단
2. **linter 경고 무시 가능**: tsconfig 의존 안 하는 직접 컴파일은 정상
3. **검증 우선순위**: linter < TypeScript 컴파일 < 브라우저 실제 테스트

---

# SNKRX 빌드 시스템 (v0.1.12, build_all.sh, 2026-07-21)

## 4개 플랫폼 빌드 + GitHub Release

| 플랫폼 | 형식 | 크기 | 내용 |
|---|---|---|---|
| macOS | `.zip` (`.app`) | 86M | love2d + 10 Frameworks + Info.plist + game.love + icon |
| Windows | `.zip` (폴더) | 4.3M | love.exe + DLL + game.love + run.bat (ASCII) |
| Linux | `.tar.gz` | 65M | love.AppImage + game.love + run.sh |
| 크로스 | `.love` | 62M | love2d 설치된 모든 OS |

## build_all.sh 표준 워크플로우

```bash
#!/bin/bash
set -e
VERSION="${VERSION:-v0.1.12}"
PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
DIST_DIR="$PROJECT_DIR/dist"
LOVE_OUTPUT="$DIST_DIR/snkrx-kr-$VERSION.love"

# 1. .love 빌드
"$PROJECT_DIR/build_love.sh"

# 2. macOS .app
"$DIST_DIR/macosx/build_macos.sh"
(cd "$DIST_DIR" && zip -r "snkrx-kr-macos-$VERSION.zip" "SNKRX-한국어.app" -q)

# 3. Windows zip
WINDOWS_DIR="$DIST_DIR/windows"
(cd "$WINDOWS_DIR" && unzip -q -o love.zip)
cp "$LOVE_OUTPUT" "$WINDOWS_DIR/"
# run.bat / README.txt 자동 생성 (cat heredoc)
(cd "$WINDOWS_DIR" && zip -r "$DIST_DIR/snkrx-kr-windows-$VERSION.zip" love-11.5-win64/ run.bat README.txt -q)

# 4. Linux tar.gz
LINUX_DIR="$DIST_DIR/linux"
cp "$LOVE_OUTPUT" "$LINUX_DIR/"
(cd "$LINUX_DIR" && tar czf "$DIST_DIR/snkrx-kr-linux-$VERSION.tar.gz" love.AppImage "snkrx-kr-$VERSION.love" run.sh README.txt)
```

## macOS .app 10대 함정

**가장 흔한 실수**: `Contents/Frameworks/` 디렉토리 10개 .framework 번들 누락.

**증상**:
```
dyld[24163]: Library not loaded: @rpath/love.framework/Versions/A/love
  Referenced from: <...> /path/to/SNKRX-한국어.app/Contents/MacOS/love
  Reason: tried: '.../Contents/MacOS/../Frameworks/love.framework/...' (no such file)
```

**해결** (build_macos.sh):
```bash
FRAMEWORKS_SRC="/Applications/love.app/Contents/Frameworks"
FRAMEWORKS_DST="$CONTENTS/Frameworks"
mkdir -p "$FRAMEWORKS_DST"
cp -R "$FRAMEWORKS_SRC"/* "$FRAMEWORKS_DST/"
```

**10개 .framework**:
Lua.framework, OpenAL-Soft.framework, SDL2.framework, freetype.framework, libmodplug.framework, love.framework, mpg123.framework, ogg.framework, theora.framework, vorbis.framework

## `unzip -o` interactive prompt (Windows zip 빌드)

**증상**:
```
replace love-11.5-win64/changes.txt? [y]es, [n]o, [A]ll, [N]one, [r]ename:  NULL
(EOF or read error, treating as "[N]one" ...)
```

**해결**: `unzip -q -o` (overwrite yes, quiet)

## gh release workflow scope (curl 우회)

**증상**: `gh release create` → `! Failed to create release, "workflow" scope may be required.`

**해결**:
```bash
TOKEN=$(gh auth token 2>/dev/null)
RELEASE_DATA='{"tag_name":"v0.1.12","name":"SNKRX 한국어 v0.1.12","body":"...","draft":true}'

# 1) Release 생성 (draft)
curl -s -X POST -H "Authorization: Bearer $TOKEN" -H "Accept: application/vnd.github+json" \
  https://api.github.com/repos/sigco3111/snkrx-clone/releases -d "$RELEASE_DATA" \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['id'])"

# 2) Release ID로 Asset 업로드
RELEASE_ID="<id>"
UPLOAD_URL="https://uploads.github.com/repos/sigco3111/snkrx-clone/releases/${RELEASE_ID}/assets{?name,label}"
for file in dist/snkrx-kr-*.zip dist/snkrx-kr-*.tar.gz dist/snkrx-kr-*.love; do
  curl -s -X POST -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/zip" \
    --data-binary "@$file" "${UPLOAD_URL//\{?name,label\}/?name=$(basename $file)}" \
    -o /dev/null -w "  HTTP %{http_code} (%{size_upload} bytes)\n"
done

# 3) Draft → Published
curl -s -X PATCH -H "Authorization: Bearer $TOKEN" -H "Accept: application/vnd.github+json" \
  https://api.github.com/repos/sigco3111/snkrx-clone/releases/$RELEASE_ID \
  -d '{"draft":false}'
```

## 누적 통계 (v0.1 ~ v0.1.21, 14개 커밋)

| 메트릭 | 값 |
|---|---|
| 총 버전 | 13개 (v0.1 ~ v0.1.21) |
| GitHub Release | 4개 asset (macOS 86M, Windows 4.3M, Linux 65M, .love 62M) |
| 번역 키 | 150+ 개 |
| 신규 파일 | 8개 (MODIFIED.md, lang/*.lua ×5, NotoSansKR.ttf) |
| 변경 파일 | 18개 |
| 누적 빌드 스크립트 | build_love.sh, build_macos.sh, build_all.sh |
| macOS .app 검증 | 10개 Framework 번들 + run.bat + README.txt |