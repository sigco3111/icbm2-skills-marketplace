# SNKRX 한국어화 fork — 30분 + 6개 버전 성공 사례

> **날짜**: 2026-07-21
> **저장소**: https://github.com/sigco3111/snkrx-clone
> **원본**: https://github.com/a327ex/SNKRX (MIT, ⭐~2k)

## 무엇을 했나

LÖVE 11.5 + LuaJIT 5.1 기반 로그라이크 오토배틀러 게임 SNKRX를 fork해서 한국어 환경에 맞게 다음을 적용:

| 항목 | 결과 |
|---|---|
| 메인 메뉴 5버튼 | 한글 |
| 상점 (shop/party/classes/items) 탭 | 한글 |
| 영웅 이름/클래스/설명 (hover) | 한글 (~57 영웅) |
| Lv.3 효과 이름/설명 | 한글 |
| 옵션 메뉴 전체 | 한글 |
| Arena 승리/패배/엔딩 | 한글 |
| 안내 메시지 (골드 부족 등) | 한글 |
| Steam 클라이언트 의존 | shim으로 우회, MIT 코드만 실행 |
| macOS Retina 풀스크린 함정 | 해결 |
| 창 크기 1280x720 비례 확대 | OK |

## 시간순 진행 (30분 + 누적 작업)

```
00:00 [요청] SNKRX 클론 + 개선
00:02       클론 완료 (Linux/macOS 빌드 분류)
00:05       LÖVE 설치 + Gatekeeper quarantine 해제
00:08       Steamworks shim 작성 → love 실행 → 첫 에러 (luasteam 없음)
00:10       shim 수정 (runCallbacks 누락) → 재실행
00:12       UTF-8 byte iteration 에러 (UTF-8 decoding error)
00:18       lead byte 분석 fix → 한글 정상
00:22       type guard (숫자 footgun) → buy_screen 진입 OK
00:25       첫 GitHub push (v0.1) — ko.lua + T() + CJK 폰트 + Steam shim
00:30 [검증] 사용자가 GUI에서 정상 동작 확인

--- 다음 세션 (위임 풀스택) ---
[+] v0.1.1: 영웅 70+ 이름 + 옵션 메뉴 T() 적용
[+] v0.1.2: hover 영웅 이름 + 라벨 T() 적용
[+] v0.1.3: hover 설명 본문 + 클래스명 + 효과 이름 한글화
[+] v0.1.4: Lv.3 효과 설명 + 옵션 토글 한글화
[+] v0.1.5: arena 승리/패배 + 일시정지 + 옵션 볼륨 한글화
[+] v0.1.6: 안내 메시지 + 승리/엔딩 메시지 + 외부 게임 추천
```

## 핵심 코드 변경 파일

| 파일 | 변경 |
|---|---|
| `MODIFIED.md` | 라이선스 의무 + 변경 이력 |
| `shared.lua` | `T(key, default)` + `lang` 모듈 + ko.lua 로딩 |
| `engine/graphics/font.lua` | `has_cjk` + `get_font_for_text` + type guard |
| `engine/graphics/text.lua` | UTF-8 character 단위 파싱 + CJK 너비 |
| `engine/graphics/graphics.lua` | `print/print_centered` CJK 폰트 선택 |
| `engine/init.lua` | state.sx 가드 + setMode 풀스크린 옵션 명시 |
| `engine/external/init.lua` | luasteam shim 경로로 require |
| `engine/external/luasteam.lua` | 신규 — Steamworks no-op shim |
| `main.lua` | 옵션 메뉴 T() + 일시정지 controls T() |
| `mainmenu.lua` | 메인 메뉴 5버튼 T() |
| `buy_screen.lua` | 상점 탭 + hover CharacterIcon + 안내 메시지 |
| `arena.lua` | 승리/패배/엔딩/credits/loop T() |
| `conf.lua` | 1280x720 + usedpiscale=false |
| `lang/ko.lua` | 신규 — 150+ 키 번역 테이블 |
| `lang/character_descriptions_ko.lua` | 신규 — 57 영웅 설명 함수 |
| `lang/character_effect_descriptions_ko.lua` | 신규 — 57 Lv.3 효과 설명 함수 |
| `assets/fonts/NotoSansKR-Regular.ttf` | 신규 — 한글 폰트 fallback |

## 가장 큰 디버깅 교훈 5가지

### 1. UTF-8 byte vs character iteration

**증상**: `engine/graphics/text.lua:139: UTF-8 decoding error: Not enough space`

**원인**: 원본 `for i = 1, #line.text do c = line.text:sub(i, i)` — `#text`는 바이트, `sub(i,i)`는 1바이트. 한글 `아`는 UTF-8 3바이트라서 깨진 바이트가 `c.character`에 들어가서 `Font:getWidth()`에서 크래시.

**해결**: lead byte 분석으로 UTF-8 character 단위 반복.

**교훈**: 모든 다국어 게임 fork 시 첫 단계에서 byte-iteration 패턴 grep.

### 2. Steamworks shim — runCallbacks 누락

**증상**: `engine/init.lua:149: attempt to call field 'runCallbacks' (a nil value)`

**원인**: 첫 shim 작성 시 `userStats`/`friends`만 정의하고 `runCallbacks` 빼먹음. 메인 루프의 `steam.runCallbacks()` 호출이 첫 프레임 직후 크래시.

**해결**: shim에 `function M.runCallbacks() end` 추가.

**교훈**: `grep -rn "steam\.\w\+\.\w\+" --include="*.lua"` → 모든 호출 추출 후 shim에 정의. `runCallbacks`가 가장 흔히 빠짐.

### 3. macOS Retina state.sx 풀스크린

**증상**: 게임을 한 번이라도 실행하면 다음 실행 시 풀스크린으로 시작.

**원인**: `state.sx=4` (이전 풀스크린 게임)이 `state.txt`에 저장 → `setMode(state.sx * gw, state.sy * gh) = setMode(1920, 1920)` → macOS가 자동 풀스크린.

**해결**: `state.sx >= 0.5 and state.sx <= 3` 범위 가드 + `state.txt` 삭제.

**교훈**: M4 Mac 사용자에게 LÖVE 게임 fork 시 `state.sx` 가드 필수.

### 4. `usedpiscale` Retina DPI 스케일링

**증상**: `setMode(1280, 720)` 호출해도 UI가 작게 보임.

**원인**: `t.window.usedpiscale = true` (기본값)이 Retina DPI 자동 적용 → love2d 내부 좌표계 1/2 축소.

**해결**: `conf.lua`에 `t.window.usedpiscale = false` 추가.

**교훈**: "창은 큰데 오브젝트 작다" 정정 시 1순위로 의심.

### 5. patch() fuzzy-match collision

**증상**: buy_screen.lua 패치 후 `end expected near <eof>` syntax 에러.

**원인**: `patch()`가 비슷한 `function ItemCard:on_mouse_enter()...end`를 우연히 매칭 → 중복 함수 정의.

**해결**: patch() 호출 시 context 최소 5줄 + 패치 후 즉시 `luac -p` 검증.

**교훈**: Lua 게임에서 `function X:method_name()` 라인은 항상 unique anchor 만들기.

## 모드팩 패턴 (sango vs SNKRX 차이)

| 게임 | 데이터 구조 | 모드팩 방식 |
|------|------------|------------|
| **sango-rising-dragons** | JSON 파일 (`public/data/{pack}/*.json`) | `mergeById` 함수로 id 기반 머지 |
| **SNKRX** | Lua 코드 내장 (영웅 이름이 `character_names['vagrant']` 테이블) | `T('char_' .. key, default)` 함수 + `lang/ko.lua` 모듈 |

**공통점**:
- 원본 데이터 보존
- 영어 fallback 보장 (default)
- 새 언어 추가 쉬움 (한 줄 변경)

**차이점**:
- JSON 게임 → 데이터 파일 단위 모드팩
- Lua 게임 → 텍스트 단위 모드팩 (함수 테이블은 `lang.<table>_ko`로 별도 파일)

## 검증 도구

### luac -p (헤드리스 syntax 검증)

```bash
for f in shared.lua main.lua mainmenu.lua buy_screen.lua arena.lua enemies.lua player.lua \
         objects.lua media.lua engine/graphics/font.lua engine/graphics/text.lua \
         engine/graphics/graphics.lua lang/ko.lua; do
  echo -n "$f: "
  luac -p "$f" 2>&1 && echo "OK"
done
```

### love 백그라운드 alive 확인

```bash
love . > /tmp/love_run.log 2>&1 &
LOVE_PID=$!
sleep 5
ps -p $LOVE_PID -o pid,stat,command
# STAT=Ss = 정상 sleep (메인 루프 진입)
cat /tmp/love_run.log
kill -9 $LOVE_PID
```

### HTTP 검증 (gh repo create 후)

```bash
curl -s -o /dev/null -w "HTTP %{http_code}\n" "https://api.github.com/repos/sigco3111/snkrx-clone"
# HTTP 200 = OK
```

## 누적 통계

| 항목 | 값 |
|---|---|
| 총 버전 | 6개 (v0.1 ~ v0.1.6) |
| 총 커밋 | 6개 (604dd92 ~ bdadc0b) |
| 신규 파일 | 5개 (MODIFIED.md, lang/*.lua ×3, fonts/*.ttf) |
| 변경 파일 | 13개 |
| 번역 키 | 150+ 개 |
| 영웅 번역 | 70+ 개 |
| 클래스명 | 16개 |
| 효과 이름 | 60+ 개 |
| 효과 설명 | 60+ 개 |

## GitHub 푸시 기록

```bash
# 1차
gh repo create sigco3111/snkrx-clone --public --description "SNKRX 한국어화 + UI/콘텐츠 개선 fork" --source=. 2>&1 | tail -5
# → 404 가능성, 반드시 curl 200 확인
curl -s -o /dev/null -w "HTTP %{http_code}\n" "https://api.github.com/repos/sigco3111/snkrx-clone"

# 2차~6차
git -c user.email="sigco3111@users.noreply.github.com" -c user.name="sigco3111" commit -m "..."
git push origin master
```

## 다음 단계 (v0.2+)

- **콘텐츠 확장**: 새 영웅/클래스/시너지 추가
- **신 게임 모드**: 보스 레이드, 데일리 챌린지
- **풀 자동위임**: sango 결정 큐 패턴 적용