-- engine/external/luasteam.lua — SNKRX 한국어화 fork 검증된 Steamworks shim
-- 원본은 Steamworks SDK와 연동되지만, 우리는 Steam 클라이언트 없이 게임플레이만 사용.
-- 모든 Steam API 호출을 no-op으로 만들어 호환성 유지.
--
-- 사용법:
-- 1. 게임 코드 grep으로 사용된 steam.* 함수 확인:
--      grep -rn "steam\.\w\+\.\w\+\|steam\.\w\+\(" --include="*.lua"
-- 2. shim에 누락된 함수 no-op으로 추가
-- 3. engine/external/init.lua 수정:
--      -- steam = require 'luasteam'           -- 원본
--      steam = require(path .. ".luasteam")    -- shim
local M = {}

function M.init() return true end
function M.shutdown() end
-- ★ engine/init.lua 메인 루프에서 매 프레임 호출됨 — 빠뜨리면 첫 프레임 직후 크래시
function M.runCallbacks() end

M.userStats = {
  requestCurrentStats = function() return true end,
  setAchievement = function() end,
  storeStats = function() end,
  getStatInt = function() return 0 end,
  setStatInt = function() end,
  resetAllStats = function(_)
    -- steam.userStats.resetAllStats(true) 호출 대응
  end,
}

M.friends = {
  setRichPresence = function() end,
  activateGameOverlay = function() end,
  requestUserInformation = function() return true end,
}

M.utils = {
  getAppID = function() return 915310 end,  -- Steam AppID
  getSteamID = function() return 0 end,
  isSteamRunning = function() return false end,
}

return M