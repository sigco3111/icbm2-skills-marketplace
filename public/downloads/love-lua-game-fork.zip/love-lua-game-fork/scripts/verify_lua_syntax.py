#!/usr/bin/env python3
"""
LÖVE 게임의 .lua 파일 전체를 luac -p로 syntax 검증.
헤드리스에서 GUI 실행이 불가능할 때 코드 로딩 가능성을 확인하는 표준 도구.

Usage:
    python3 verify_lua_syntax.py /path/to/game/
    python3 verify_lua_syntax.py file1.lua file2.lua ...
"""
import subprocess
import sys
from pathlib import Path


def find_lua_files(root: Path):
    """디렉토리에서 모든 .lua 파일 찾기 (node_modules, .git 제외)."""
    skip_dirs = {'.git', 'node_modules', '.venv', '__pycache__', 'build', 'dist'}
    for path in root.rglob('*.lua'):
        if not any(p in skip_dirs for p in path.parts):
            yield path


def check_luac_available():
    """luac 명령 사용 가능 여부."""
    try:
        subprocess.run(['luac', '-v'], capture_output=True, check=True)
        return True
    except (subprocess.CalledProcessError, FileNotFoundError):
        return False


def verify_file(path: Path):
    """단일 .lua 파일 syntax 검증."""
    try:
        result = subprocess.run(
            ['luac', '-p', str(path)],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode == 0:
            return True, None
        else:
            return False, result.stderr.strip()
    except subprocess.TimeoutExpired:
        return False, "TIMEOUT"
    except Exception as e:
        return False, str(e)


def main():
    if len(sys.argv) < 2:
        print("Usage: python3 verify_lua_syntax.py <path> [<path> ...]")
        print("  <path> can be a directory (recursive .lua) or single file")
        sys.exit(1)

    if not check_luac_available():
        print("⚠️  luac not found in PATH")
        print("   Install: brew install lua  (macOS)")
        print("   Verify:  which luac")
        sys.exit(2)

    files = []
    for arg in sys.argv[1:]:
        p = Path(arg)
        if p.is_dir():
            files.extend(find_lua_files(p))
        elif p.is_file():
            files.append(p)
        else:
            print(f"⚠️  Skip: {p} not found")

    if not files:
        print("No .lua files to verify")
        sys.exit(0)

    print(f"Verifying {len(files)} .lua file(s)...\n")

    ok_count = 0
    fail_count = 0
    failures = []

    for path in sorted(files):
        ok, err = verify_file(path)
        if ok:
            print(f"  ✅ {path}")
            ok_count += 1
        else:
            print(f"  ❌ {path}")
            if err:
                for line in err.split('\n')[:5]:
                    print(f"        {line}")
            fail_count += 1
            failures.append((path, err))

    print()
    print("=" * 60)
    print(f"✅ {ok_count} OK")
    if fail_count:
        print(f"❌ {fail_count} FAILED")
        print()
        print("FAILED FILES:")
        for path, err in failures:
            print(f"  {path}")
            if err:
                for line in err.split('\n')[:3]:
                    print(f"    {line}")
        sys.exit(1)
    print()
    print("🎉 All .lua files syntax valid")


if __name__ == '__main__':
    main()