#!/usr/bin/env python3
"""
LÖVE/Lua + JS/Python 게임의 UTF-8 byte iteration 함정 자동 스캔 도구.
게임 fork 시 첫 단계에서 실행하여 위험 패턴 탐지.

Usage:
    python3 detect_utf8_byte_iteration.py /path/to/game/src

위험 패턴 (수동 patch 필요):
- Lua:     for i=1,#text do text:sub(i,i)  → lead byte 분석
- JS:      text.charAt(i), text[i], text.slice(i,i+1)  → Array.from
- Python2: for c in str (str=bytes)  → unicode 처리
- C++:     char buf[N]; buf[i]=s[i]  → char32_t
- Java:    substring(i, i+1)  → codePointAt
"""
import re
import sys
from pathlib import Path

# 위험 패턴 정의 (정규식)
RISKY_PATTERNS = {
    'lua': [
        (r':sub\([^,]+,\s*[^)]+\)', "byte-iteration (UTF-8 깨짐 위험)"),
        (r'for\s+\w+\s*=\s*1\s*,\s*#\w+\s+do', "byte-based loop with # (length in bytes)"),
    ],
    'js': [
        (r'\.charAt\(\w+\)', "charAt (UTF-16 코드유닛, surrogate pair 위험)"),
        (r'\.charCodeAt\(\w+\)', "charCodeAt (single UTF-16 unit)"),
        (r'\.slice\(\s*\w+\s*,\s*\w+\s*\)', "slice single char (UTF-16 코드유닛)"),
        (r'\[\s*\w+\s*\](?!\s*=)', "indexer (UTF-16 코드유닛)"),
    ],
    'py2': [
        (r'for\s+\w+\s+in\s+\w+\s*:\s*$', "Python 2: str=bytes, iteration = bytes"),
    ],
    'cpp': [
        (r'char\s+\w+\[\w+\]', "char buffer (raw UTF-8 bytes)"),
        (r'wchar_t\s+\w+\[\w+\]', "wchar_t (Windows UTF-16, BMP only)"),
    ],
    'java': [
        (r'\.substring\(\s*\w+\s*,\s*\w+\s*\)', "substring (UTF-16 코드유닛)"),
        (r'\.charAt\(\w+\)', "charAt (UTF-16 코드유닛)"),
    ],
}

EXT_MAP = {
    '.lua': 'lua',
    '.js': 'js',
    '.ts': 'js',
    '.py': 'py2',  # Python 3도 경고 (str=unicode지만 인덱싱은 코드포인트)
    '.cpp': 'cpp',
    '.cc': 'cpp',
    '.cxx': 'cpp',
    '.h': 'cpp',
    '.hpp': 'cpp',
    '.java': 'java',
}

def scan_file(path: Path):
    """파일을 스캔하여 위험 패턴 발견."""
    findings = []
    ext = path.suffix.lower()
    if ext not in EXT_MAP:
        return findings

    lang = EXT_MAP[ext]
    patterns = RISKY_PATTERNS.get(lang, [])

    try:
        with open(path, 'r', encoding='utf-8') as f:
            for line_num, line in enumerate(f, start=1):
                # 주석 제거 (간단한 -- # // 처리)
                stripped = re.sub(r'(--.*|//.*|#.*)$', '', line)
                for pattern, description in patterns:
                    if re.search(pattern, stripped):
                        findings.append((line_num, line.rstrip(), description, lang))
    except (UnicodeDecodeError, IOError):
        pass

    return findings


def main():
    if len(sys.argv) < 2:
        print("Usage: python3 detect_utf8_byte_iteration.py <directory>")
        sys.exit(1)

    root = Path(sys.argv[1])
    if not root.exists():
        print(f"Error: {root} not found")
        sys.exit(1)

    all_findings = {}
    total_files = 0

    for path in root.rglob('*'):
        if not path.is_file():
            continue
        if any(p in path.parts for p in ['.git', 'node_modules', '.venv', '__pycache__']):
            continue
        if path.suffix.lower() not in EXT_MAP:
            continue

        total_files += 1
        findings = scan_file(path)
        if findings:
            all_findings[path] = findings

    if not all_findings:
        print(f"✅ Scanned {total_files} files — no byte-iteration patterns detected")
        return

    print(f"⚠️  Scanned {total_files} files — byte-iteration risks found:\n")
    for path, findings in sorted(all_findings.items()):
        rel = path.relative_to(root) if path.is_relative_to(root) else path
        print(f"📄 {rel}")
        for line_num, line, desc, lang in findings[:10]:
            print(f"   L{line_num}: {line.strip()[:80]}")
            print(f"        → {desc} [{lang}]")
        if len(findings) > 10:
            print(f"   ... and {len(findings) - 10} more")
        print()

    print("=" * 60)
    print(f"Total: {sum(len(f) for f in all_findings.values())} risks in {len(all_findings)} files")
    print()
    print("Recommended fix:")
    print("- Lua: lead byte 분석 (utf8 codepoint lead: 0xC0~0xDF=2byte, 0xE0~0xEF=3byte, 0xF0~0xF7=4byte)")
    print("- JS:  Array.from(text) 또는 for-of (UTF-16 surrogate pair 처리)")
    print("- Python: str[i] (Python 3 str = unicode 코드포인트)")
    print("- C++:  std::u32string + char32_t")
    print("- Java: codePointAt(i) + charCount(cp)")
    sys.exit(1)


if __name__ == '__main__':
    main()