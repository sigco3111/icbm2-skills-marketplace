---
name: love-lua-game-fork
description: "LÖVE 11.x (LuaJIT) 게임 fork + 한국어화 + Steam 비의존 + macOS Retina 호환 워크플로우. SNKRX 실전 검증된 패턴 8종 — T() 함수 + lang/<code>.lua 모드팩 (JSON 아닌 Lua 코드 내부 텍스트용), CJK 폰트 lazy fallback, UTF-8 byte vs character iteration (가장 위험한 함정), Steamworks shim 5종, macOS M4 Retina usedpiscale/state.sx 풀스크린 트리거 5종, Apple Gatekeeper quarantine, patch() fuzzy-match collision 회피, luac -p 헤드리스 검증 + love 백그라운드 프로세스 alive 확인. '이 게임 클론해서 한글화', 'LÖVE/Lua 게임 fork', 'SNKRX/오토배틀러 한글화', 'Steam 없이 게임 실행', 'love.app Gatekeeper 우회' 같은 요청에 발동. macOS M4 + brew cask love 환경."
version: 1.1.0
author: HyeRin (MiniMax)
license: MIT
metadata:
  hermes:
    tags: [lua, love2d, luajit, steamworks-shim, cjk-font-fallback, utf-8-byte-iteration, macos-retina-fullscreen, gatekeeper-quarantine, type-guard, patch-fuzzy-collision, headless-process-verification, luac-syntax-check, fork-localization, korean]
    related_skills: [oss-fork-localization, github-repo-management, ad-hoc-verifier]
---

# LÖVE/Lua 게임 fork & 한국어화 워크플로우

> LÖVE 11.x 게임을 fork해서 한국어 환경에 맞게 현지화하면서 Steam 클라이언트 없이 실행 가능하게 만드는 클래스 워크플로우. **SNKRX (2026-07-21, 6개 버전 푸시)** 실전 검증.

## 지원 파일 (support files)

- `references/snkrx-clone-success.md` — SNKRX 6개 버전 푸시 시간순 기록 + 5가지 핵심 디버깅 교훈 + 누적 통계
- `templates/luasteam_shim_template.lua` — 검증된 Steamworks no-op shim (그대로 복사해서 `engine/external/luasteam.lua`로 배치)
- `scripts/verify_lua_syntax.py` — 디렉토리/파일 전체 `luac -p` 검증 (헤드리스 표준 도구)
- `scripts/detect_utf8_byte_iteration.py` — Lua/JS/Python/C++/Java byte-iteration 위험 패턴 자동 스캔 (게임 fork 1단계에서 실행)

## 언제 사용하나

| 사용자 요청 | 트리거 |
|------------|--------|
| "이 LÖVE 게임 클론해서 한글화해줘" | ✓ |
| "Lua 게임 fork + 한국어 UI" | ✓ |
| "Steam 없이 게임 실행" | ✓ |
| "love 창이 풀스크린으로 자꾸 켜져" | ✓ |
| "한글이 □로 깨져요" | ✓ |
| "love 앱이 Gatekeeper 차단당해요" | ✓ |
| "LÖVE 게임 한글 자동 모드팩 추가해줘" | ✓ |

## 30초 빠른 워크플로우 (SNKRX 검증)

```
1. [5분]   brew install --cask love + xattr quarantine 제거
2. [5분]   love . 실행 → SIGKILL 확인 = 헤드리스 정상, 사용자에게 GUI 검증 위임
3. [5분]   Steamworks shim 작성 (engine/external/luasteam.lua)
4. [10분]  UTF-8 byte iteration 함수 탐지 → lead byte 분석으로 패치
5. [10분]  T(key, default) + lang/ko.lua 모듈 추가
6. [5분]   Font:has_cjk + CJK 폰트 lazy fallback 구현
7. [10분]  모드 mainmenu/buy_screen/arena 텍스트 T() 치환
8. [5분]   luac -p 전체 검증 + love 백그라운드 실행
9. [10분]  GitHub push (gh repo create + curl 200 확인 + remote 재설정)
```

## ⭐ T() 함수 + `lang/<code>.lua` 모드팩 (LÖVE/Lua 게임 표준)

**sango-rising-dragons(TypeScript/JSON)와 다른 패턴**: Lua 게임은 텍스트가 코드 안에 직접 박혀 있어 데이터 외부화가 어려움. **`T()` 함수 + `lang/<code>.lua` 모듈**이 표준.

```lua
-- shared.lua (가장 먼저 require되는 모듈 — shared_init 안)
lang = lang or {}
lang.current = 'ko'  -- 기본값
lang.dicts = {}
lang.dicts.en = {}   -- 영어 = 원본 (default로 사용)
lang.dicts.ko = require('lang.ko')
lang.fallback = 'en'

function T(key, default)
  local dict = lang.dicts[lang.current] or {}
  local fb = lang.dicts[lang.fallback] or {}
  if dict[key] ~= nil then return dict[key] end
  if fb[key] ~= nil then return fb[key] end
  return default or key
end
```

```lua
-- lang/ko.lua (모듈식 번역 테이블)
return {
  arena_run = '아레나 런',
  options = '옵션',
  quit = '종료',
  -- ...
}
```

**사용**: `'arena run'` → `T('arena_run', 'arena run')` — default가 영어 원본이므로 폴백 안전. 한 줄만 수정하면 영어로 복귀.

**언어 전환**: `lang.current = 'en'` 한 줄 변경만으로 전체 UI 영어로 복귀. 향후 ja/zh 모드팩 추가도 같은 패턴.

**함수 테이블 처리 (description 같은 동적 문자열)**: `lang.current == 'ko' and lang.<table>_ko or <table>` 패턴으로 분기 — buy_screen.lua hover info_text에서 사용:

```lua
local desc_func = (lang.current == 'ko' and lang.character_descriptions_ko and lang.character_descriptions_ko[self.character]) or character_descriptions[self.character]
```

**장점**:
- 함수 본문 자체는 건드리지 않음 → 게임 로직 보존
- 모드팩만 갈아끼우면 다른 언어 추가 가능
- 영어 fallback 보장 → ko.lua 키 누락 시에도 crash 없음

## ⭐ UTF-8 byte vs character iteration 함정 (가장 위험, CRITICAL)

**모든 다국어 게임 fork에서 만나는 가장 위험한 함정**. 언어/엔진 무관.

**증상 (SNKRX 실측)**:
```
Error: engine/graphics/text.lua:139: UTF-8 decoding error: Not enough space
        [C]: in function 'getWidth'
```

**원인** (SNKRX 원본 `engine/graphics/text.lua:206-218`):
```lua
for i = 1, #line.text do
  local c = line.text:sub(i, i)   -- ← single BYTE, not character
  table.insert(line.characters, {character = c, ...})
end
```

`#line.text`는 **바이트 수**, `sub(i, i)`는 **1바이트**. 한글 `"아레나 런"`은 UTF-8에서 12 bytes / 5 chars. 각 iteration이 깨진 바이트 1개(`"\xEC"`, `"\x95"`, `"\x84"`) 추출 → `Font:getWidth("\xEC")` → love2d UTF-8 디코더 "Not enough space" 크래시.

**Lua 표준 fix** (lead byte 분석, LuaJIT 호환, Lua 5.3의 `utf8.*`는 LuaJIT에 없음):
```lua
local i = 1
while i <= #text do
  local b = text:byte(i)
  local cont = 1
  if b >= 0xF0 then cont = 4      -- 4-byte (CJK Extension B+, Emoji)
  elseif b >= 0xE0 then cont = 3  -- 3-byte (한글, 한자, 히라가나)
  elseif b >= 0xC0 then cont = 2  -- 2-byte (Latin extended)
  end                              -- 0x80~0xBF = orphan continuation
  local c = text:sub(i, i + cont - 1)   -- ← full UTF-8 character
  -- ...process c...
  i = i + cont
end
```

**다른 언어 같은 위험 패턴**:
| 언어 | 위험 코드 | 안전한 대안 |
|------|----------|-------------|
| Lua | `for i=1,#s do s:sub(i,i)` | 위 lead byte 패턴 |
| JavaScript | `str.charAt(i)`, `str[i]`, `str.slice(i,i+1)` | `Array.from(str)` 또는 `for (const ch of str)` |
| Python 2 | `for c in str: ...` (str=bytes) | `for c in unicode: ...` |
| C++ | `char buf[N]; buf[i]=s[i]` | `char32_t` / `std::u32string` |
| Java | `substring(i, i+1)` (ASCII only) | `codePointAt(i)` + `charCount(cp)` |

**CJK 폰트 자동 감지 단순화** (`Font:has_cjk()`도 byte 기반):
```lua
-- ❌ WRONG: 2-byte Latin extended (é, ñ)도 true 반환
-- if (b >= 0xE0 and b <= 0xEF) or (b >= 0xAC and b <= 0xD7) or (b >= 0xEA) then
-- ✅ CORRECT: lead byte만 체크
for i = 1, #text do
  local b = text:byte(i)
  if b >= 0xE0 then return true end
end
return false
```

**사전감지 도구**: `scripts/detect_utf8_byte_iteration.py`로 Lua/JS/Python/C++ 위험 패턴 자동 스캔.

**즉시 적용 규칙**:
1. **언어 무관 체크리스트** — fork 첫 단계에서 byte-iteration 패턴 grep:
   ```bash
   grep -rn "charAt\|:sub([^,]*,[^)]*)\|:byte(" --include="*.lua" --include="*.js" --include="*.py" .
   ```
2. **per-character width/draw 호출**: `cf:getWidth(c.character)` — `c.character`가 full UTF-8 char여야 안전
3. **빌드 검증 후 첫 게임 시작 직전**: `Font:getWidth("테스트 한글")` 단독 호출 → 크래시 없으면 통과

## ⭐ CJK 폰트 lazy fallback (LÖVE 11.x 한정)

**LÖVE 11.x의 TTF BitmapFont는 한글 glyph 없으면 글리프 깨짐**. 반드시 lazy fallback:

```lua
-- engine/graphics/font.lua
function Font:init(asset_name, font_size)
  local primary_path = "assets/fonts/" .. asset_name .. ".ttf"
  self.font = love.graphics.newFont(primary_path, font_size)
  self.h = self.font:getHeight()
  self.asset_name = asset_name
  self.size = font_size
  self.ko_font = nil  -- lazy init
end

function Font:_ensure_ko_font()
  if self.ko_font then return self.ko_font end
  local ko_path = "assets/fonts/NotoSansKR-Regular.ttf"
  if love.filesystem.getInfo(ko_path) then
    self.ko_font = love.graphics.newFont(ko_path, self.size)
  else
    self.ko_font = self.font
  end
  return self.ko_font
end

function Font:has_cjk(text)
  if text == nil or type(text) ~= "string" then return false end  -- type guard (다음 섹션)
  for i = 1, #text do
    local b = text:byte(i)
    if b >= 0xE0 then return true end
  end
  return false
end

function Font:get_font_for_text(text)
  if self:has_cjk(text) then return self:_ensure_ko_font() end
  return self.font
end

function Font:get_text_width(text)
  if text == nil or type(text) ~= "string" then return 0 end
  if self.ko_font and self:has_cjk(text) then
    return self.ko_font:getWidth(text)
  end
  return self.font:getWidth(text)
end
```

**3곳 패치 필수**:
1. `engine/graphics/font.lua` (위)
2. `engine/graphics/text.lua`: `Text:format_text` + `Text:draw` — character별 너비 측정도 ko_font 사용
3. `engine/graphics/graphics.lua`: `graphics.print` + `graphics.print_centered` — 출력도 ko_font 사용

**한 곳만 빠지면** 텍스트 폭이 어긋나서 한글 글자가 짤리거나 겹침.

**폰트 파일**: `assets/fonts/NotoSansKR-Regular.ttf` (4.6MB). GitHub push 시 포함.

## ⭐ type guard — `type(text) ~= "string"` (숫자 footgun)

**Lua 게임 fork에서 가장 빈번한 footgun**. 게임 코드에서 `graphics.print(숫자, ...)` 호출이 매우 흔함 (가격, 레벨, 점수).

**실측 에러 (SNKRX buy_screen.lua:1750)**:
```
Error: engine/graphics/font.lua:54: attempt to get length of local 'text' (a number value)
```

**왜**: 우리 `print_centered`가 `font:get_font_for_text(text)` 호출 → `Font:has_cjk(text)` → `if not text then return false` 가드 무력화 (Lua에서 `not 0`은 false → 0은 truthy → 가드 통과) → `#3` 시도 → 크래시.

**해결 — 모든 폰트/텍스트 API에 type guard**:
```lua
function Font:has_cjk(text)
  if text == nil then return false end
  if type(text) ~= "string" then return false end  -- ← 핵심
  -- ...
end

function Font:get_text_width(text)
  if text == nil or type(text) ~= "string" then return 0 end  -- ← 핵심
  -- ...
end
```

**왜 게임 코드가 숫자를 텍스트 API에 넘기나**:
- `love.graphics.print(3, font, ...)`는 LÖVE가 자동 `"3"` 변환
- 우리 `graphics.print/print_centered`가 raw `text` 그대로 `Font`에 전달
- `Font:has_cjk(text)`에서 `not text` 가드는 nil/false만 차단, **0/숫자는 통과**

**Lua만 위험** (Python은 `if not x:`가 0도 falsy로 차단, 안전).

**즉시 적용 규칙**:
1. **폰트/텍스트 API 가드는 `type(x) ~= "string"` 또는 `x == nil` 명시**: `if not x` 금지
2. **숫자 → 문자열 변환**: hook 호출 전 `tostring(text)`로 강제 변환하면 더 안전
3. 게임 첫 시작 후 다양한 화면 클릭: 가격, 데미지, 점수 — 모두 숫자 가능성

## ⭐ Steamworks shim — `engine/external/luasteam.lua`

**게임이 Steam 클라이언트 의존 시 no-op shim으로 우회**. 표준 템플릿은 `templates/luasteam_shim_template.lua` 참조.

```lua
-- engine/external/luasteam.lua
local M = {}

function M.init() return true end
function M.shutdown() end
-- ★ engine/init.lua 메인 루프에서 매 프레임 호출 — 가장 흔히 빠뜨림
function M.runCallbacks() end

M.userStats = {
  requestCurrentStats = function() return true end,
  setAchievement = function() end,
  storeStats = function() end,
  getStatInt = function() return 0 end,
  setStatInt = function() end,
}

M.friends = {
  setRichPresence = function() end,
  activateGameOverlay = function() end,
}

M.utils = {
  getAppID = function() return 915310 end,
}

return M
```

**`engine/external/init.lua` 수정**:
```lua
-- ❌ WRONG: require 'luasteam' (Steamworks SDK 바인딩, brew love에 없음)
-- steam = require 'luasteam'

-- ✅ CORRECT: 같은 디렉토리의 shim 사용
steam = require(path .. ".luasteam")
```

**검증 grep**: `grep -rn "steam\.\w\+\.\w\+" --include="*.lua"` → 모든 호출 추출 후 shim에 누락 없이 정의.

**빠뜨리기 쉬운 5종** (SNKRX 실측):
| API | 호출 위치 | 빠뜨리면 |
|-----|----------|----------|
| `steam.runCallbacks()` | **`engine/init.lua` 메인 루프** (매 프레임) | 첫 프레임 직후 크래시 |
| `steam.userStats.setAchievement()` | arena.lua | nil 호출 |
| `steam.userStats.storeStats()` | 도전과제 직후 | nil 호출 |
| `steam.friends.setRichPresence()` | 메뉴/상점 진입 | nil 호출 |
| `steam.shutdown()` | 게임 종료 | nil 호출 |

## ⭐ macOS Retina fullscreen 트리거 5종 함정 (M4 Mac, NEW)

M4 Mac + LÖVE 조합에서 가장 빈번한 사용자 정정 신호: **"창 모드로 했는데 풀스크린 됨"**, **"창만 커지고 오브젝트 작음"**, **"오브젝트가 너무 작음"**.

### 함정 1: `state.sx` 비정상 데이터 풀스크린 트리거

**증상**: 게임 한 번이라도 실행 → `~/Library/Application Support/LOVE/{game_name}/state.txt`에 `state.sx=4` 저장 → 다음 실행 시 `setMode(state.sx * gw, state.sy * gh) = setMode(1920, 1920)` → macOS 자동 풀스크린.

**해결**:
```lua
-- engine/init.lua
if state.sx and state.sy then
  -- ★ 0.5~3 범위 벗어나면 비정상 데이터로 간주
  if state.sx >= 0.5 and state.sx <= 3 and state.sy >= 0.5 and state.sy <= 3 then
    sx, sy = state.sx, state.sy
    love.window.setMode(state.sx*gw, state.sy*gh, ...)
  else
    state.sx, state.sy = nil, nil
    love.window.setMode(window_width, window_height, ...)
  end
else
  state.sx, state.sy = sx, sy
  love.window.setMode(window_width, window_height, ...)
end
```

**state.txt 위치**: macOS = `~/Library/Application Support/LOVE/{game_name}/state.txt`. 비정상 동작 시 가장 먼저 의심.

**즉시 적용**:
1. fork 첫 실행 직전 `rm ~/Library/Application Support/LOVE/{game_name}/state.txt` 권장
2. `state.sx` 사용 시 **반드시 범위 가드** (0.5~3 또는 사용 가능한 스케일 값)

### 함정 2: 1920x1080 = M4 디스플레이 해상도 일치

**증상**: M4 Mac의 디스플레이가 1920x1080 (Retina) 또는 1440x900. `setMode(1920, 1080)` 호출 시 macOS가 풀스크린화.

**해결**: **비표준 사이즈 사용** (예: 1280x720). M4 디스플레이와 정확히 일치하지 않으면 풀스크렌화 회피.

### 함정 3: `usedpiscale = true` 자동 Retina DPI 스케일링

**증상**: M4 Mac + Retina에서 `love.window.setMode(1280, 720)` 호출 → 물리 윈도우는 1280x720 픽셀이지만 **love2d 내부 좌표계는 자동으로 640x360으로 축소 매핑**. UI가 작게 보임.

**해결 — conf.lua**:
```lua
function love.conf(t)
  t.version = "11.3"
  t.window.width = 1280
  t.window.height = 720
  t.window.vsync = 1
  t.window.msaa = 0
  t.window.resizable = true
  t.window.usedpiscale = false  -- ★ Retina DPI 자동 축소 비활성화
end
```

### 함정 4: setMode 옵션 누락 (fullscreen/borderless)

**해결 — setMode 옵션 명시**:
```lua
love.window.setMode(window_width, window_height, {
  vsync = config.vsync,
  msaa = msaa or 0,
  display = 1,            -- ★ 메인 디스플레이 강제
  fullscreen = false,     -- ★ 풀스크린 명시적 차단
  borderless = false,     -- ★ 타이틀바 있는 창 모드 강제
  resizable = true,
})
```

### 함정 5: window size sentinel 우선순위 — `'max'` vs `'half'` 순서

**증상**:
```lua
-- ❌ WRONG: 'half'가 먼저 비교 안 됨
if config.window_width ~= 'max' then window_width = config.window_width end
--                            ↑ 'half'도 'max'가 아니므로 window_width = 'half' (문자열) 박힘
if config.window_width == 'half' then window_width = math.floor(window_width / 2) end
--                            ↑ 'half' / 2 → "attempt to perform arithmetic on a string value"

-- ✅ CORRECT: 'half'를 먼저 처리한 후 'max' 비교
if config.window_width == 'half' then window_width = math.floor(window_width / 2) end
if config.window_width ~= 'max' and config.window_width ~= 'half' then
  window_width = config.window_width
end
```

**즉시 적용 규칙**: 다중 sentinel 비교 시 **가장 구체적인 것부터 처리** ('half' → 'max' → 숫자). sentinel 패턴 추가 시 순서 점검.

### 디버깅 우선순위 (사용자 "창/오브젝트 크기" 정정 시)

1. `usedpiscale` 확인 (`conf.lua`)
2. `state.sx` 범위 가드 확인 (`engine/init.lua`)
3. `game_width` vs `window_width` 비율 확인 (`main.lua`)
4. `state.txt` 직접 확인 (`~/Library/Application Support/LOVE/{game_name}/state.txt`)
5. `setMode` 옵션 `display/fullscreen/borderless` 확인

## ⭐ Apple Gatekeeper quarantine — `love.app` 실행 차단

brew로 설치한 macOS 앱이 **"love(를)를 열지 못함 — Apple이 서명되지 않은 Mac용 소프트웨어에서..."** 팝업 띄울 때.

**원인**: brew cask love는 2026-09-01부터 brew에서 deprecation 예정 (Gatekeeper 통과 못함).

**해결 (1초, 권장)**:
```bash
xattr -dr com.apple.quarantine "/Applications/love.app"
# 검증: quarantine 속성 사라졌는지
xattr -l "/Applications/love.app"
# → com.apple.provenance만 남으면 OK
```

**대안 (Finder UI, 30초)**: 우클릭 → 열기 → 경고 다시 클릭 → 열기

**즉시 적용 규칙**: brew cask로 설치한 GUI 앱이 "Apple이 서명되지 않은..." 팝업 띄우면 **quarantine 제거**. 알 수 없는 출처 앱에는 적용 금지.

## ⭐ Lua 5.5 luac 검증 함정 — `x and y() or z` 패턴 실패

`luac -p` 검증 시 **"function arguments expected near 'and'"** 에러:

```lua
-- ❌ luac -p 에러 (일부 환경)
local active_font = font:get_font_for_text and font:get_font_for_text(text) or font.font
--                       ^^^^^^^^^^^^^^^^^^^^^^
-- luac: "function arguments expected near 'and'"

-- ✅ 명시적 if/else
local active_font
if font.get_font_for_text then
  active_font = font:get_font_for_text(text)
else
  active_font = font.font
end
```

**왜**: Lua 5.4+ 엄격해진 문법. Lua 5.1~5.3 OK지만 LuaJIT(5.1) 환경이라도 luac 5.5로 검증하면 실패.

**즉시 적용 규칙**: `obj.method and obj.method() or obj.field` 패턴 **절대 금지**. 항상 if/else.

## ⭐ patch() fuzzy-match collision — Lua 게임의 `function X:method()...end` 패턴

**문제**: Lua 코드는 비슷한 메서드 정의가 많아 (`function X:on_mouse_enter()...end` 같은). `patch()`의 fuzzy match가 **다른 클래스/객체의 메서드를 우연히 매칭** → 중복 함수 정의 → `end expected near <eof>` syntax 에러 → 파일 전체 로드 실패.

**실측 (SNKRX buy_screen.lua:1541)**: steam_button 코드 패치 → ItemCard:on_mouse_enter에 우연히 매칭 → 1541번 라인이 `function ItemCard:on_mouse_enter()` 중복 → syntax 에러.

**해결 규칙**:
1. **항상 충분한 context lines 포함** (앞/뒤 3줄 이상) → unique anchor 만들기
2. **패치 후 반드시 `luac -p` 검증** (모든 .lua 한 번에) — 실패 시 즉시 발견
3. **실패 시 `git checkout -- <file>`로 원본 복구 후 재시도**
4. **특정 라인 위치를 정확히 알면 `read_file`로 그 라인 주변 10줄 먼저 확인**

**Lua 게임에서 흔한 fuzzy-match 위험 패턴**:
- `function X:on_mouse_enter()...end`
- `function X:on_mouse_exit()...end`
- `function X:draw()...end`
- `function X:update()...end`

**즉시 적용 규칙**:
1. Lua 게임 patch() 호출 시 **context 최소 5줄** (앞 3줄 + 뒤 2줄)
2. **패치 후 즉시 `luac -p` 실행** → 실패 시 즉시 발견
3. **`function X:method_name()...end` 라인은 특히 주의** — 동일 메서드명이 다른 객체에 있을 가능성 높음

## ⭐ 헤드리스 검증 — `luac -p` + `love` 백그라운드 alive 확인

LÖVE는 GUI 앱이라 헤드리스에서 실행 시 SIGKILL로 죽음. 게임 부팅 성공 여부 확인. `scripts/verify_lua_syntax.py`로 자동화 가능.

```bash
# 1. luac -p로 syntax 검증 (모든 .lua)
for f in shared.lua main.lua mainmenu.lua buy_screen.lua arena.lua enemies.lua player.lua \
         objects.lua media.lua engine/graphics/font.lua engine/graphics/text.lua \
         engine/graphics/graphics.lua lang/ko.lua; do
  echo -n "$f: "
  luac -p "$f" 2>&1 && echo "OK"
done
```

```bash
# 2. love 백그라운드 실행 + alive 확인
love . > /tmp/love_run.log 2>&1 &
LOVE_PID=$!
sleep 5
ps -p $LOVE_PID -o pid,stat,command
# STAT=Ss = 정상 sleep (메인 루프 진입 성공)
# STAT=Z = zombie = 죽음

cat /tmp/love_run.log
# stderr 비어있으면 OK, 에러 있으면 크래시

kill -9 $LOVE_PID
```

**STAT 해석**:
| STAT | 의미 | GUI 실행 가능? |
|------|------|----------------|
| `Ss` | 정상 sleep (메인 루프 진입) | ✅ |
| `S` | interruptible sleep | ✅ |
| `Z` | zombie | ❌ |
| `T` | stopped | ❌ |

**즉시 적용 규칙**: LÖVE 게임 fork 시 5초 백그라운드 실행 + `ps` + stderr 체크. **헤드리스에서 GUI 화면 확인은 불가능하지만 코드 로딩 성공 여부는 검증 가능**. 사용자에게 GUI 검증 위임.

## ⭐ gh repo create origin curl 200 확인 (git 워크플로)

`gh repo create` 후 `--source=.` + `--remote=origin` 조합이 가끔 origin 자동 추가에 실패. **출력은 성공으로 보이지만 push 시 404**.

**해결 (2단계 검증)**:
```bash
# 1. 저장소 생성
gh repo create sigco3111/repo --public --description "..." --source=. 2>&1 | tail -5

# 2. 즉시 HTTP 검증 (404면 실패)
curl -s -o /dev/null -w "HTTP %{http_code}\n" "https://api.github.com/repos/sigco3111/repo"
# HTTP 200 = OK, 404 = 다시 시도

# 3. remote 강제 설정 (이미 우리가 직접 설정한 경우 OK)
git remote remove origin 2>&1 || true
git remote add origin https://github.com/sigco3111/repo.git
git remote -v  # 검증
```

**즉시 적용 규칙**: `gh repo create` 후 **반드시 curl로 200 확인** → 404면 remote 재설정. **절대 출력만 신뢰하지 말 것**.

## ⭐ 색상 태그 보존 sed 일괄 치환 (게임 데이터)

게임 데이터에서 색상 태그(`[yellow]`, `[blue]`, `[fg]` 등)가 포함된 문자열은 단순 sed/string-replace가 안 됨.

**Python 일괄 처리 (영웅/스킬/아이템 이름)**:
```python
import re

translations = {
  'Warrior': '전사', 'Mage': '마법사', 'Nuker': '누커',
  'Ranger': '레인저', 'Rogue': '도적', 'Healer': '힐러',
  # ...
}

# 색상 태그 + 이름 영역만 추출 (영향 최소화)
with open('main.lua', 'r', encoding='utf-8') as f:
    lines = f.readlines()

start, end = None, None
for i, l in enumerate(lines):
    if 'character_class_strings = {' in l: start = i
    elif start and l.strip() == '}': end = i; break

if start and end:
    for i in range(start, end + 1):
        for en, ko in translations.items():
            # ']EnglishName\b' → ']한글명' (regex word boundary)
            lines[i] = re.sub(r'\]\s*' + en + r'\b', ']' + ko, lines[i])
    with open('main.lua', 'w', encoding='utf-8') as f: f.writelines(lines)
```

**왜 word boundary (`\b`) 필요한가**: `'[blue]Mage'`에서 'Mage'만 치환하고 'Magenta' 같은 다른 단어는 안 건드리기 위함.

**즉시 적용 규칙**:
1. 색상 태그가 있는 문자열은 **항상 `<color_tag>이름` 형태** — sed/python regex로 정확히 매칭
2. word boundary 필수
3. 영역 한정 처리 — `character_class_strings = {` ~ `}` 같은 명확한 섹션 안에서만
4. 다중 파일 같은 키는 grep으로 일괄 파악 후 패치

## ⭐ 빌드 환경 분류 (LÖVE/Lua 추가)

| 분류 | 빌드 도구 | 빌드 시간 | macOS 호환성 | 사례 |
|------|----------|----------|--------------|------|
| 🟢 **LÖVE/Lua 게임** | `love .` (런타임) | 0초 | ✅ brew cask `love` | **SNKRX** (✅ 30분, 6개 버전) |
| 🟢 **즉시 성공** | `npm`/`yarn` | 2초 | ✅ | sango-rising-dragons |
| 🟡 **Java/Gradle** | `./gradlew` | 30초~5분 | ✅ | triplea |
| 🟠 **Rust/cargo** | `cargo build` | 1~5분 | ✅ | zemeroth |
| 🔴 **C++ scons/CMake** | `scons`/`make` | 30분~1시간 | ⚠️ | Wesnoth |
| ⚫ **C#** | `dotnet`/`mono` | 1~5분 | ⚠️ | RTK2020-CORE |

→ 자세한 5단계 검증: `oss-fork-localization` §references/build-environment-preflight-check.md

## 핵심 원칙

1. **UTF-8 byte iteration 가장 먼저 의심** — 한글/일본어/중국어 깨짐은 이거 99%
2. **CJK 폰트 lazy fallback 필수** — LÖVE 11.x는 한글 glyph 없으면 깨짐
3. **type guard (`type(text) ~= "string"`)** — 숫자 footgun 방지
4. **Steamworks shim 5종 빠뜨리지 말 것** — `runCallbacks`가 메인 루프에서 호출됨
5. **macOS Retina state.sx 가드 필수** — M4 사용자에게 풀스크린 + 오브젝트 작음 정정 신호 시
6. **options 영구 저장 (state.sx + fullscreen 공존)** — 사용자가 옵션 변경 후 재시작해도 유지되어야 함

## ⭐ options 영구 저장 — state.sx + fullscreen 공존 패턴 (v0.1.21, NEW)

**사용자 요구**: 옵션 화면에서 변경한 창 크기 / 전체화면이 게임 재시작 후에도 유지되어야 함.

**근본 문제 3가지**:

1. **state.sx가 저장되지만 매번 덮어써짐**: `engine/init.lua:97`의 `state.sx, state.sy = sx, sy` 무조건 덮어쓰기 → 사용자가 설정한 값 소실.
2. **전체화면 시 sx=4 가드 밖**: 풀스크린은 `window_width = 데스크톱 크기`라서 `sx = 1920/480 = 4`. 가드 (0.5~3) 밖 → 새 계산 → state.sx = 4 → 다음 시작 시 또 풀스크린.
3. **state.fullscreen 미저장**: 옵션에서 'fullscreen' 클릭 시 `setMode(fullscreen=true)` 호출만 하고 `state.fullscreen` 저장 안 함.

**해결 — use_state_sx + fullscreen 분기** (engine/init.lua):

```lua
gw, gh = config.game_width or 480, config.game_height or 270

-- v0.1.21: state.sx/sy가 가드 범위(0.5~3) 안이면 사용.
-- 단, 풀스크린 모드면 state.sx/sy는 무시하고 데스크톱 크기 사용.
-- 풀스크린 → 창 모드 전환 시에만 state.sx/sy 적용.
local use_state_sx = false
if state.fullscreen == true then
  -- 풀스크린 모드: 데스크톱 크기 그대로
  sx, sy = window_width/(config.game_width or 480), window_height/(config.game_height or 270)
  use_state_sx = true  -- state.sx 덮어쓰지 않음 (다음 시작 시에도 풀스크린이면)
elseif config.window_width == 'max' or config.window_width == 'half' or type(config.window_width) == 'number' then
  sx, sy = window_width/(config.game_width or 480), window_height/(config.game_height or 270)
elseif state.sx and state.sy and state.sx >= 0.5 and state.sx <= 3 and state.sy >= 0.5 and state.sy <= 3 then
  sx, sy = state.sx, state.sy
  window_width = math.floor(sx * (config.game_width or 480))
  window_height = math.floor(sy * (config.game_height or 270))
  use_state_sx = true
else
  sx, sy = window_width/(config.game_width or 480), window_height/(config.game_height or 270)
end
ww, wh = window_width, window_height

-- v0.1.21: state.fullscreen이 true면 풀스크린 모드
local fullscreen_mode = state.fullscreen == true

-- v0.1.21: state.sx/sy 덮어쓰기 (가드 범위 내였으면 보존)
if not use_state_sx then
  state.sx, state.sy = sx, sy
end
love.window.setMode(window_width, window_height, {
  vsync = config.vsync,
  msaa = msaa or 0,
  display = 1,
  fullscreen = fullscreen_mode,    -- ★ state 기반 풀스크린
  borderless = false,
  resizable = true,
})
```

**옵션 버튼 클릭 시 save_state()** (main.lua):

```lua
self.sfx_button = Button{..., action = function(b)
  sfx.volume = sfx.volume + 0.1
  if sfx.volume > 1 then sfx.volume = 0 end
  state.sfx_volume = sfx.volume
  b:set_text(T('option_sfx_volume', 'sfx volume: ') .. tostring((state.sfx_volume or 0.5)*10))
  system.save_state()  -- ★ v0.1.21: 매 클릭 시 저장
end}
```

**모든 옵션 버튼 (sfx/music 볼륨, window size ±/fullscreen/reset, screen shake/cooldown/arrow/movement 토글)** 매번 `system.save_state()` 호출해야 함.

**검증 시나리오** (수동):
| 시나리오 | 결과 |
|---|---|
| state 없음 (첫 실행) | 기본 800×600, fullscreen=false ✅ |
| state.sx=2.666 → 재시작 | 1280×720 (유지) ✅ |
| fullscreen=true → 재시작 | 1920×1080 풀스크린 (유지) ✅ |
| fullscreen=true + state.sx=2.666 → 재시작 | 풀스크린 우선 (state.sx 무시) ✅ |

**디버깅 워크플로**:
1. `cat ~/Library/Application Support/LOVE/{game_name}/state.txt` → 현재 저장된 값 확인
2. `rm state.txt` → 비정상 데이터 제거
3. `love .` 백그라운드 실행 → 5초 후 `cat state.txt` → 자동 저장된 값 확인
4. 옵션 변경 → 즉시 state.txt 확인 → 재시작 → 유지 확인

**흔한 실수 — state.fullscreen == true 분기 안 함**:

```lua
-- ❌ WRONG: 풀스크린 시 sx=4 계산
sx, sy = window_width/(config.game_width or 480)  -- 1920/480 = 4
use_state_sx = false  -- 0.5~3 가드 밖 → 덮어씀
state.sx, state.sy = sx, sy  -- state.sx = 4 저장됨

-- 다음 시작: state.sx=4 → 0.5~3 가드 밖 → 새 계산 → 또 4 → 무한 풀스크린
```

→ `if state.fullscreen == true` 분기 **최우선**으로 추가 필수.

**즉시 적용 규칙**:
1. **`use_state_sx` 가드**: `if not use_state_sx then state.sx = sx end` — 덮어쓰기 조건부
2. **`state.fullscreen` 분기**: fullscreen이면 `use_state_sx = true` 강제 (덮어쓰지 않음)
3. **모든 옵션 버튼에 `system.save_state()`**: 토글, 볼륨, 비디오 등 매번
4. **state.fullscreen도 setMode 옵션에 전달**: `fullscreen = fullscreen_mode`
5. **state.txt 비정상 의심 시**: `rm state.txt` 후 재실행 → 깨끗한 기본값으로 시작
6. **Apple Gatekeeper quarantine 즉시 제거** — brew cask love 첫 실행 전
7. **luac -p 헤드리스 검증** — GUI 없이도 코드 로딩 성공 여부 확인 가능
8. **patch() context 최소 5줄** — Lua 게임 fuzzy-match collision 회피
9. **모두 검증 끝나면 사용자에게 GUI 검증 위임** — 헤드리스에서는 화면 확인 불가

## 관련 사례

- **SNKRX 성공 (2026-07-21, 30분 + 6개 버전 푸시)**: LÖVE 11.5 + Lua 5.1 + 22K LOC. 위 9가지 원칙 모두 적용. → `references/snkrx-clone-success.md`
- oss-fork-localization §6단계 빌드 환경 분류 §LÖVE/Lua 게임 섹션