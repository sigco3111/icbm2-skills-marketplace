# Visual sample rendering for Rust roguelike TUI planning

When you (or the user) is choosing between render styles — ASCII,
half-block Unicode, or Braille — you'll need to produce PNG previews
side-by-side. **The Hermes venv's Pillow is built against a Python
version the sandbox doesn't always load cleanly** (see the note
in `references/cli-loop-integration-testing.md`).

This reference documents the in-sandbox path that's been validated to
work on macOS 15.x.

## macOS-native path: qlmanage + HTML

1. Write three HTML files to a temp dir, one per style.
2. Apply CSS that mimics the TUI look (black background, monospace
   font, half-block glyphs in `▀▄█` palette, plus ASCII and Braille
   variants).
3. Invoke `qlmanage -t -s <width>,<height> -o <outputdir>
   <file>.html`. macOS ships this in `/usr/bin/qlmanage`.
4. Read the resulting `<file>.html.png` files.

```bash
qlmanage -t -s 1328,550 -o /Users/mac/work/end_of_eden/visual_samples \
  /tmp/ascii.html
```

This is what asciirogue used in the visual pre-selection step. It
produces reasonable pixel-level renderings of monospace + half-block
text without any Python dependency.

## Hand-rolled PNG via zlib (when you don't even have PIL)

If `qlmanage` is unavailable (Linux sandbox, headless CI), you can
synthesize a PNG with stdlib only:

```python
import zlib, struct, os
def write_png(path, width, height, pixels):
    sig = b'\x89PNG\r\n\x1a\n'
    def chunk(typ, data):
        return struct.pack('>I', len(data)) + typ + data + struct.pack('>I', zlib.crc32(typ + data))
    ihdr = struct.pack('>IIBBBBB', width, height, 8, 2, 0, 0, 0)
    raw = b''
    for y in range(height):
        raw += b'\x00' + pixels[y * width * 3:(y + 1) * width * 3]
    idat = zlib.compress(raw)
    with open(path, 'wb') as f:
        f.write(sig)
        f.write(chunk(b'IHDR', ihdr))
        f.write(chunk(b'IDAT', idat))
        f.write(chunk(b'IEND', b''))
```

Use this only when the data is genuine rectangles (no font, no
anti-aliasing). For TUI comparisons, it's good enough — the user is
looking at "is the wall glyph dense enough?" not the typography.

## What NOT to do

- **Don't depend on PIL/imagemagick/pillow being installed.** They
  all break in a fresh Hermes sandbox. Verify by `python3 -c
  "import PIL"` before using them.
- **Don't shell out to Chromium / Playwright.** Both have heavy native
  dependencies and frequently fail the same way PIL does.
- **Don't try to verify by repeatedly running TUI and watching it.**
  Even when the sandbox lets you, you can't tell from the rendered
  frame what the underlying state was. Use `--dump` instead.

## Decision: which path?

| Have macOS `qlmanage`? | Have a working PIL? | Use this |
|---|---|---|
| Yes | — | `qlmanage` path (above) |
| No  | No | Hand-rolled zlib PNG |
| No  | Yes | PIL `Image.new('RGB', ...)` + `ImageDraw` |
| — | — | The pattern: `--dump` text output is **always** useful as a baseline. PNGs are decoration. |

For asciirogue's actual execution: PNGs were produced both via `qlmanage`
(for the user's visual comparison) and via `--dump` text (for the
machine-verifiable assertion that walls are rendered correctly).
Neither step became a CI dependency.
