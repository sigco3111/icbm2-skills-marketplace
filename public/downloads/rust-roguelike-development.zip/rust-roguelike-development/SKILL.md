---
name: rust-roguelike-development
description: Roguelike/dungeon-crawler games in Rust from scratch.
category: software-development
---
# Rust Roguelike Development (class-level umbrella)

From-scratch roguelike / dungeon crawler / RPG games implemented in Rust.
Walks the full lifecycle: concept lock → week-milestone scope → ECS+procgen+
render loop → in-game feedback triage → git-tagged releases — with `cargo test`
at every commit and a TUI/dump-mode escape hatch for headless verification.

Use when the user asks for:
- A roguelike, dungeon crawler, dungeon builder, or "종류 로그라이크" in Rust
- Converting a Python/TS roguelike to Rust (or extracting one as a Rust crate)
- Wiring up hecs + procgen + ratatui for a half-block pixel TUI game
- A multiplayer/backend-light roguelike service that could be one binary

Do not use when:
- The deliverable is a board/strategy/4X game (use a different umbrella)
- The work is purely a single ECS demo (use autonomous-ai-agents / bevy_ecs patterns)
- A complete web/mobile game (use canvas-static-site-pipeline)

## The 5-phase shape that works

This umbrella exists because the asciirogue session (2026-07-29) revealed a
specific failure mode the user cares about: **start from a vague intuition,
climb through week milestones with the user deciding each milestone
end-state, never let "ship the milestone" become "ship a stub"**.

```
phase 1  concept lock          — what kind of roguelike, ASCII vs half-block vs 3D?
phase 2  week-1: viewport      — minimum: dungeon generator + ONE render path + dump-mode
phase 3  week-2..N-1: 1 milestone per week, each ends with cargo test passing
phase 4  week-N: meta + i18n   — save/load, locale, polish
phase 5  release tag v0.N      — git tag + brief CHANGELOG + bump
```

Every weekly milestone must end in three conditions:
1. `cargo build --release` exits 0 with 0 warnings (rustfmt is suggested, not
   enforced — Hermes sandbox can't install rustfmt cleanly).
2. `cargo test` exits 0 with monotonically-growing test count.
3. A user-runnable demo path exists: `--dump` (headless), `cargo run` (TUI), or
   an HTTP `/` (server). Without that, the milestone is fiction.

## Critical lessons (each drove pitfall capture below)

### 1. Always provide a headless verification path alongside the TUI
Hermes sandbox can `pty.fork()` but crossterm raw mode does not play nicely
with the in-sandbox pty + select(). **Always ship a `--dump` (or `--simulate`)
subcommand that writes the same view to stdout using the same model code.**

Ref: `references/cli-loop-integration-testing.md`

### 2. User screenshots ARE the spec — triage seriously
When the user pastes a screenshot and says "적도 나도 안 죽고 안 움직여",
the immediate temptation is to ask "what is happening". The screenshot
*is* the spec — read the footer, the header, the visible glyphs, and
diagnose THREE concurrent root causes (AI through walls + vision too wide +
death not surfaced). Resist the urge to fix one at a time.

Ref: `references/roguelike-feedback-triaging.md`

### 3. Pick ONE tech stack up front and stick to it
For asciirogue:
- `ratatui` 0.29 + `crossterm` 0.28 — TUI frontend
- `hecs` 0.10 — ECS (NOT specs, NOT bevy_ecs; minimal compile times)
- `bracket-random` (or `fastrand`) — procgen RNG
- `doryen-fov` 0.1 — FOV library that just works (RLTK-derived)
- `serde` + `ron` — save format. RON's hand-friendly syntax survives
  hand-editing during debugging, which JSON does not.
- Anyhow for `Result`-plumbing

DO NOT swap stacks mid-project. The 5-week speed is what it is because the
stack was chosen on day 1 and held. `references/ecs-stack-rust.md` covers
this in detail.

### 4. Weeks ≠ months. Push the milestone boundary at week boundaries.
asciirogue worked because:
- Week 1 = one renderable, BSP dungeon, cargo test green. `< 80 LOC`.
- Week 2 = ECS + FOV + keyboard. ~250 LOC total.
- Week 3 = combat. ~600 LOC.
- Week 4 = items + 8-floor theme cycle + boss. ~900 LOC.
- Week 5 = meta + i18n + save. ~1100 LOC.

Each week's increment was small enough to "just keep going". If a week
bloats, **split it**, do not stretch.

5. **Memory tells you what to refuse, skills tell you how to do it.**
   "When the user says '회차 반복 요소 추가' you don't record the answer; you
   add a section to the SPEC and code against it. When the user says 'stop being
   verbose', you patch the skill. These are not the same kind of update." —
   see USER.md and the SPEC discipline discussion.

6. **Don't ship a fix without driving it**. Patches that look correct in
   `cargo test` can still fail at runtime because the unit tests exercise
   functions in isolation while the runtime integrates them. **Create an
   `examples/<bug-name>.rs` binary that drives the same loop and prints
   state per step.** This caught a v0.5.3 attack-loop bug for asciirogue
   that 100% green tests + clean `--dump` couldn't see. See
   `references/headless-driver-binary.md`. The user's explicit ask
   "네가 로그를 찍으면서 직접 플레이해봐" = "you go run the loop and
   log it yourself" is not a one-off — it's the standard debugging posture
   for TUI roguelikes when fixes don't fix.

## Pitfalls (encountered during asciirogue 5 weeks)

1. **PIL/Pillow dependency drift on macOS**. The Hermes venv's Pillow is
   built against one Python and binds broken inside the sandbox. Don't
   rely on it for visual work — render HTML and use `qlmanage` (macOS
   built-in) to get PNG. `--dump` text output is also useful as a no-PIL
   fallback. Ref: `templates/visual-sample-png-gen.md`.

2. **`world.get::<&T>(entity)` vs `world.get::<T>(entity)`** in hecs. The
   former returns `Ref<'_, T>` (immutable), the latter `&mut T` (exclusive).
   hecs::World's API is `get<T: ComponentRef<'a>>`. Forgetting the `&`
   produces 5-line Rust compile errors that take a minute to parse. Burn
   this into muscle memory: read-only → `&T`, write → `&mut T`.

3. **Putting `App {...}` literals inside `Self { ... }` construction with
   zeroed-out fields to satisfy `t_for` before `App` is fully built**. Use a
   free function `t_format_with_locale(key, locale, args)` that does NOT
   need an `App` instance. We did this in asciirogue week-5 and got four
   patches of `unsafe std::mem::zeroed()` until we realized that. Avoid
   `unsafe` in a learning curve.

4. **`KeyCode::Char('>') | KeyCode::Char('.')` OR pattern collapses two
   intents**. The `>` key should descend floors; the `.` key should wait a
   turn. OR-arming them silently routes `.` to the wrong handler if either
   branch grows. **Always use two arms with their own implementation**, even
   if one is currently a stub.

5. **Forgetting `#[allow(dead_code)]` for utility functions introduced in
   the same commit**. The Rust compiler doesn't whine loudly — it's just an
   unused warning. But the next refactor that DELETES the helper doesn't
   know it's a helper you wanted.

6. **Patch tool `mode` arg silently dropped on batch calls**. When issuing
   multiple `patch` calls in one assistant turn, the system may silently
   drop `mode="replace"` for some. Use `write_file` for any batched edits;
   reserve `patch` for single-line fixes. Ref: asciirogue 2026-07-09
   commit, where 1 patch succeeded and 5 failed silently.

7. **`new_at_with` vs `new_at` vs `new` distinguish carefully**. When a
   constructor grows fields (locale, remembrance, gold), add a `_with`
   variant and **alias the legacy 2-arg `new_at` as `#[allow(dead_code)]`**
   rather than carrying both signatures through every call site.

8. **`/tmp/_marker.txt` path typo**: my `write_file` with a `/tmp/` path
   typed as `/tmp/_marke.txt` (typo) created an orphan dir with no cleanup.
   When you write a sentinel/placeholder file by full path, double-check
   the path is what you want. Asciirogue commit `f083a75` shows the kind
   of fix-up work that resulted.

9. **Cooldown / turn-boundary resets belong at the END of the action,
   not the START of the next**. Enemy cooldowns set to 1 after an attack
   must NOT be cleared at the start of `enemy_take_turns()` — that's the
   very next call, and clearing there means "any enemy that ever attacked
   once becomes eligible on the very next frame". The reset must happen
   at the player-turn boundary, after the previous enemy phase
   completed. Symptom: a "fixed" infinite-attack loop still runs,
   because the gate you added is closed for ~0 frames before reopening.
   The correct shape for asciirogue: `try_player_act` clears cooldowns
   *after* `enemy_take_turns` returns, never before. Tests in `cargo test`
   won't catch this — only a probe driving the actual loop will.
   See `references/cooldown-turn-boundary.md` for the full pattern
   (wrong vs right shape, exact placement rules, why the test passes
   while the bug remains).

10. **Treat `--dump` and `cargo test` as incapable of catching
    gameloop-ordering bugs**. They exercise the code paths but not the
    interaction between consecutive ticks. The v0.5.3 attack-loop bug
    had `--dump --count 8` passing cleanly while the real game loop
    froze. The fix is `crates/<app>/examples/play_probe.rs` — a real
    Cargo example binary that calls `App::step` repeatedly. See
    `references/headless-driver-binary.md`.

11. **When the user says "다른 방법을 찾아봐" / "stop trying the same
    thing" / "여전히 안됨"** — the diagnosis is wrong, not the patch.
    Three concrete signals trigger this: (a) the same symptom after
    multiple patches you thought were the fix, (b) the user pastes
    the same screenshot twice, (c) the bug description includes "I
    tried X already" or "still happening". Drop the code, write a
    headless probe that **directly observes the failed invariant**
    (player coords, inventory contents, message log, ground-item
    positions), THEN form a new hypothesis from the probe output. The
    asciirogue v0.5.5 → v0.5.6 pickup bug took exactly this shape: I
    patched pickup 4 times and the user said "still doesn't work";
    the probe revealed the coordinate search was scoped to the
    player's tile only, not to `±1` neighbours — completely different
    bug class than the message "주울 아이템이 없습니다" suggested. See
    `references/diagnosis-first-methodology.md`.

12. **hecs: cannot hold `world.get::<&mut T>` borrow and call any other
    `world.*` method (including `world.spawn`, `world.query`)**. The
    borrow checker enforces this. Pattern: when you need to spawn a
    ground entity inside a function that already holds an
    `Inventory` borrow, `drop(inv)` first, then touch `world`. Symptom:
    `error[E0502]: cannot borrow as mutable because also borrowed as
    immutable` on `world.spawn` with `inv` still in scope. Workaround
    in asciirogue v0.5.7 `equip_inventory_at`: drop the `Inventory`
    borrow before calling `world.spawn((Position, Renderable, Item))`
    for the displaced item.

13. **Equipment-swap bug: putting a displaced item into the same slot
    that will receive the new item.** Symptom: equipping a weapon
    when another is already equipped — the second weapon's
    `inv.put_at(idx, new_item)` fails because the swap put the old
    one into `idx` already. The fix: swap to ANY other free slot,
    not `idx`. Asciirogue v0.5.7 `equip_inventory_at` now scans
    `inv.slots` for the first non-`idx` empty slot; only as a last
    resort does it overwrite `idx`. Test: equip weapon A, equip
    weapon B, assert `attack_bonus == B.bonus` and `d.inventory
    contains A`.

14. **`pub use core::Type` collides with `use core::{Type, ...}`** when
    both are in the same file (e.g. `lib.rs` re-exports types for
    downstream binaries, AND uses them internally). Symptom:
    `error[E0252]: the name 'Type' is defined multiple times`. Fix:
    pick one — either re-export only the ones not in your local `use`,
    or just use `pub` items from the inner `use` directly without a
    separate `pub use`. Asciirogue v0.5.7 had
    `pub use asciirogue_core::EquipSlot;` next to
    `use asciirogue_core::{..., EquipSlot, ...};` — removed from the
    local `use`.

15. **Local variable shadowing a free function of the same name**:
    `let inv_count = inv_count(&app, player);` shadows the function
    `inv_count` for the rest of the scope. Symptom: `E0618: this
    function of the same name is available here, but it's shadowed by
    the local binding`. Fix: rename the binding (`count_a`, `count_b`,
    `inv_len`, …) or use `_ = inv_count(...);` to drop immediately.

## start here (decision tree)

1. **Picking the visual style?** → render 3 PNGs (ASCII / half-block / braille)
   and let the user pick. Don't argue.
2. **Choosing the ECS / render stack?** → `references/ecs-stack-rust.md`.
3. **First iteration of the dungeon + a key + character moving?** →
   `references/procgen-patterns.md`.
4. **Mid-development user feedback that says "this looks broken"?** →
   `references/roguelike-feedback-triaging.md`. Treat the screenshot as
   a spec. The sibling skill `asciirogue-devpitfalls-2026-07` lists
   five concrete bug classes observed in the asciirogue v0.5 round and
   is the canonical place to look BEFORE writing any AI / damage / death
   code in a roguelike codebase.
5. **Need to verify the TUI works without a real terminal?** →
   `references/cli-loop-integration-testing.md`. If the user reports a
   **runtime-loop** bug (the symptom contains verbs like "loops", "stuck",
   "spam", "doesn't end"), default straight to:
   `references/headless-driver-binary.md` for the `examples/play_probe.rs`
   pattern. **If the loop survives a `git commit` but the probe transcript
   shows the same enemy attacking from the same tile every turn**, the
   cooldown reset is in the wrong place — see
   `references/cooldown-turn-boundary.md`.
6. **The user says "여전히 안됨" / "다른 방법을 찾아봐" after your patch
   didn't fix it** → your diagnosis is wrong. Stop patching, write a
   probe that observes the failed invariant, re-form the hypothesis.
   See `references/diagnosis-first-methodology.md`.
7. **Releasing v0.x for the first time?** → `git tag -a v0.<N> -m ...` +
   push `--tags`. Always.

## The build / test / dump loop

```bash
cargo build --release
cargo test
./target/release/<name> --dump --count 3 --seed <seed>
```

`scripts/cargo-test-and-build-loop.sh` wraps this in a watchdog that
prints a 1-line summary on each step. Use it as a pre-commit:

```bash
bash ~/.hermes/skills/rust-roguelike-development/scripts/cargo-test-and-build-loop.sh
```

## What this umbrella is NOT

- Not a tutorial on Rust syntax. Use `rust-lang.org/book`.
- Not a bevy/RPG-Maker workflow (would warrant its own umbrella).
- Not a server multiplayer architecture guide (use `toss-trader`-style
  external OAuth pattern, link to `references/tossinvest-api-facts.md`).

## how to use this umbrella

```python
from hermes_tools import skill_view
# Get the umbrella's main SKILL.md
skill_view(name="rust-roguelike-development")
# Get a specific reference
skill_view(name="rust-roguelike-development", file_path="references/ecs-stack-rust.md")
# Run the diagnostic helper
bash ~/.hermes/skills/rust-roguelike-development/scripts/cargo-test-and-build-loop.sh
```

The references/ directory contains session-specific recipes. The
SKILL.md is the map. The pitfall list at the top of this file is the
canonical things-not-to-do — read it before any commit.
