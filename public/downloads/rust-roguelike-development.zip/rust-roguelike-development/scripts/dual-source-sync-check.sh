#!/usr/bin/env bash
# Pre-commit / pre-push check for the lib.rs + main.rs dual-source pattern.
# Warns when the two files' function/impl counts drift apart.
#
# Use as a pre-commit hook:
#   cp scripts/dual-source-sync-check.sh .git/hooks/pre-commit
#   chmod +x .git/hooks/pre-commit
#
# Or run manually:
#   bash scripts/dual-source-sync-check.sh
set -e
LIB=crates/app/src/lib.rs
MAIN=crates/app/src/main.rs
if [ ! -f "$LIB" ] || [ ! -f "$MAIN" ]; then
    exit 0
fi
LIB_FNS=$(grep -cE '^(pub )?fn |^impl ' "$LIB")
MAIN_FNS=$(grep -cE '^(pub )?fn |^impl ' "$MAIN")
if [ "$LIB_FNS" -ne "$MAIN_FNS" ]; then
    echo "WARN: lib.rs has $LIB_FNS functions/impls, main.rs has $MAIN_FNS."
    echo "      diff before commit:"
    diff -u <(grep -E '^(pub )?fn |^impl ' "$LIB") \
            <(grep -E '^(pub )?fn |^impl ' "$MAIN") | head -30
    exit 1
fi
echo "lib.rs / main.rs function counts match ($LIB_FNS / $MAIN_FNS)"
exit 0
