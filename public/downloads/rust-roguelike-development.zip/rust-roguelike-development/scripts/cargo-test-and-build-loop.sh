#!/usr/bin/env bash
#
# cargo-test-and-build-loop.sh — pre-commit / pre-push loop for Rust roguelikes.
# Tails the important lines of `cargo test`, `cargo build --release`,
# and a headless `--dump` of the binary. Use as a quick sanity check
# before declaring any week milestone green.
#
# Usage:
#   bash cargo-test-and-build-loop.sh [BIN_NAME=asciirogue] [DUMP_FLAGS="--count 8 --seed 0xCAFE"]
#
# Requires: cargo on PATH; the binary in question must live in
# `crates/<name>` or be in the workspace root.

set -e

BIN_NAME="${1:-asciirogue}"
DUMP_FLAGS="${2:---count 8 --seed 0xCAFE}"
WORKSPACE_ROOT="${WORKSPACE_ROOT:-$(pwd)}"

echo "[build/test/dump] target: $BIN_NAME  args: $DUMP_FLAGS  root: $WORKSPACE_ROOT"
echo

# 1. cargo test (verbose summary, last 5 lines only)
echo "─── cargo test (release) ───"
cargo test --release --all 2>&1 | tail -5

# 2. cargo build release (just confirm exit 0)
echo
echo "─── cargo build --release ───"
cargo build --release 2>&1 | tail -1

# 3. headless dump if the binary exists
BIN_PATH="$WORKSPACE_ROOT/target/release/$BIN_NAME"
if [[ -x "$BIN_PATH" ]]; then
  echo
  echo "─── $BIN_NAME $DUMP_FLAGS (headless dump) ───"
  "$BIN_PATH" $DUMP_FLAGS 2>&1 | head -30
else
  echo
  echo "[!] binary not found at $BIN_PATH — skipping dump step"
fi

echo
echo "[build/test/dump] ok"
