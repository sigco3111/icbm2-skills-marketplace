# Headless verification for Rust roguelike TUIs

The fundamental problem: **Hermes (and most sandboxed agents) cannot
sensibly run an interactive ratatui TUI in their `terminal` tool**.
`pty.fork()` exists but crossterm raw mode + select() interact poorly with
the sandbox. So you can't verify "the user's bug" by simply running the
binary.

This reference covers the patterns that DO work.

## Pattern 1 — `--dump` subcommand (the workhorse)

Every TUI binary in asciirogue ships with:

```bash
asciirogue --dump --count N --seed SEED
```

The dump path:

- Reuses the same `App::new`, `App::new_at`, `populate_floor`, `recompute_fov`
  code paths as the TUI loop.
- Replaces the `terminal.draw(|f| app.draw(f))` step with a stdout
  print loop using the same `ratatui::Frame`-less rendering — just
  walk the dungeon tile-by-tile and pick a glyph + FOV-aware color.
- Adds a `--count N` flag so you can show N floors in one shot.
- Adds `--seed` so user can reproduce exactly.
- Adds `--help` so the user always sees the dump mode + control hints.

This is enough to verify:
- Per-floor theme mapping (`1F 동굴 → 5F 카타콤`)
- BOSS marker placement
- FOV shape and visible count
- Enemy/loot glyphs at expected positions
- ASCII cells with half-block wall glyph density

What it does NOT verify: actual TUI redraw, keypress timing, panic
recovery, terminal escape codes.

## Pattern 2 — `cargo test` as the verification proxy

Most game logic that COULD only be verified by playing (movement,
combat, AI decisions) is **already behind pure functions** in
asciirogue's design. Test, don't play:

```rust
#[cfg(test)]
mod tests {
    #[test]
    fn chases_toward_player_when_seen() {
        let a = take_turn(
            TilePos(0, 0), TilePos(5, 0),
            8, AiKind::Chase,
            Some(TilePos(5, 0)),
            walkable_all, sight_no_walls,
        );
        match a {
            AiAction::Step(d) => assert_eq!(d.delta(), (1, 0)),
            _ => panic!(),
        }
    }
}
```

Rule: if it can be tested, **test it**. Treat `cargo test` as a poor
person's TUI integration test. Cover:
- New combat formulas
- AI decision branches
- Vision/LOS logic
- Inventory manipulation
- Save/load round-trip

## Pattern 3 — record / replay for runtime cases

For cases that genuinely only appear in the run loop (panic recovery,
message log overflow, terminal escape glitches), record and replay
inputs:

```rust
let input_script = "h h h h j h l r r r r r";
for ch in input_script.split_whitespace() {
    app.handle(&Event::Key(KeyEvent::new(KeyCode::Char(ch), ...)));
}
```

asciirogue did NOT implement this; mention it because it's the path
forward if you want CI tests against bug reports.

## Pattern 4 — the `cargo test && cargo build && ./target/release/X
--dump` one-liner

`scripts/cargo-test-and-build-loop.sh` codifies the canonical
verification loop:

```bash
cargo test --release --all 2>&1 | tail -3
cargo build --release 2>&1 | tail -1
./target/release/<bin> --dump --count N --seed <seed> 2>&1 | head -30
```

Use as a pre-commit or as a checkpoint before declaring any week
milestone done.

## What the dump output should look like (don't ship more)

A good `--dump` header is one line of "what is this":

```
── seed 0xF1BBCDCBFA54ABA6  8F 카타콤 [BOSS]  rooms 14  player@(8,5)  visible 87 ──
```

A single line per floor. ~24-line map of glyphs. No frame, no
colors-as-control-codes. The grep friendliness is the point: you
will paste fragments of these into bug triage sessions.

## Pitfalls

- **Don't shell out to the binary through the sandbox**. Some sandbox
  versions will block `pty.fork()` entirely. Use `cargo run --example
  dump` or `cargo run --bin <bin> -- --dump` from within `terminal`
  tool — the binary sees no TTY and proceeds in stdout mode.
- **Don't print to stderr in dump mode** unless you have to. The user
  pastes output into triage and grep'd text is your friend.
- **Don't forget `--help` is also stdout-friendly**. Always print to
  stdout (eprintln! is rare in dump paths) so the user can `asciirogue
  --help | less`.

## Sandbox limit — `pty.fork` does work, just barely

If you DO need to drive the real TUI from a script for user
verification, the receiving end needs to be a real interactive process
launched from a terminal that the user is watching. The pattern is:

```python
# from the user's terminal
cargo run --release
# user manually presses keys and watches the screen
```

vs the headless pattern:

```bash
cargo run --release -- --dump --count 8 --seed <seed>
```

Pick the right one for what you need to verify. Always default to
headless.

## Related reading

- `tui-game-development/SKILL.md` (referenced from prior
  investigations) for older TUI patterns.
- The Rust roguelike tutorial chapter 16 (wall-glyph 4-bit mask
  algorithm): <https://bfnightly.bracketproductions.com/rustbook/chapter_16.html>
- doryen-fov 0.1 docs (crate-level, terse).
- hecs 0.10 docs (book-style, fast read).
- bracket-random 0.8 source — quite a small surface, you can read it
  in 15 minutes.
