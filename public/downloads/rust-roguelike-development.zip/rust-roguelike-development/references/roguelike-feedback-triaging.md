# Triaging user feedback that says "the game looks broken"

The single most important lesson from asciirogue's week-5.1 bugfix: a
screenshot of the running game is the spec. Read it like a postmortem, then
diagnose root causes **concurrently** (multiple at once), not
sequentially.

## The pattern (use this, verbatim)

When the user reports something like "적이도 나도 안 죽고 계속 반복됨"
+ attaches a screenshot:

1. **Pull every datum from the screenshot before responding.**
   - Header (status line)
   - Footer (control hints)
   - Visible entities (any glyphs you recognize)
   - Color or border changes
   - Anything weird in the message log
   You are NOT trying to "interpret" yet. Just extract.

2. **Generate TWO POSSIBLE DIAGNOSES per visible anomaly.** Not one.
   Each leads to a different fix. Hold both in mind until you've
   exhausted #1.

3. **Identify which diagnoses share the same root cause.** Group them.
   A single symptom (e.g. "enemies attack from off-screen") can have
   THREE independent causes (vision too wide + AI through walls + death
   swallowed by HUD scroll). They all need separate fixes.

4. **Implement fixes in dependency order.** Foundation fixes
   (e.g. AI LOS) before UX fixes (e.g. death freeze). Test each
   one before moving on.

5. **Verify with the actual reproduction path, not a new test.** The
   user reproduced it in `--release` mode by pressing real keys.
   If your fix changes gameloop ordering, headless `--dump` won't
   catch it. Set up a deterministic record/replay path if you can.

## The asciirogue case study (2026-07-29, "버그 리포트")

User says: "적이도 나도 안 죽고 계속 반복됨" + screenshot.

### What the screenshot revealed

| Field observed | Value | Reading |
|---|---|---|
| Header | `seed 7581... 1F 동굴 player(14,19) visible 52 HP 38/40 MP 15/15` | HP 38/40 normal. 52 tiles visible (a lot). |
| Footer | `[치명타! 0 피해!  | 빗나감!]` | Two messages queued. Both engaged but no damage. |
| Center | 골드 `@` + `$`, no enemy glyph anywhere | Critters entered FOV and attacked from off-screen. |

### Three concurrent root causes (not one!)

1. **AI chases through walls.** `ai::take_turn` was using only
   Chebyshev distance for visibility check. Walls were ignored. Fix:
   add `last_known_player: Option<TilePos>` + `sight_blocks` closure
   to the signature.

2. **VIEW_RADIUS = 8 = nearly half a screen.** Player can see the
   enemy before it's anywhere near them, but the AI starts reacting
   from "half a screen away" too. Fix: tighten to 5.

3. **Death detection was almost invisible.** HP went to 0, a one-line
   log message showed up, then scrolling off = "did I die? where am I?".
   Fix: add `game_over: bool` field. Death → clear message queue →
   push `═══ 쓰러졌습니다… ═══`. Header title becomes `☠ YOU DIED ☠`.
   `handle()` ignores everything except R (restart) / q (quit).

### Why "fix one at a time" would have failed

If you had applied only the LOS fix, the AI would still chase through
walls, just from a slightly wider radius. If you had applied only the
vision-radius fix, the player would have been safe at radius 5 but the
AI still chased through walls. **Both behavioral symptoms
independently caused "can't kill or be killed".** The death-freeze
fix alone wouldn't have mattered because the player's HP didn't
actually drop.

## The triage template (use this for reports)

```
## Symptom (verbatim from user)
> "<paste their words>"

## What the screenshot shows
- header: <...>
- footer: <...>
- visible entities: <...>
- message log: <...>

## Hypotheses ranked
1. <hypothesis A> (most likely because <reason>)
2. <hypothesis B>
3. <hypothesis C>

## Root-cause group
H1 + H2 share <root cause>. H3 is independent.

## Fix order
- step 1 (foundation): <fix A>
- step 2 (tuning): <fix B>
- step 3 (UX): <fix C>

## Verification path after each step
- cargo test
- ./target/release/<bin> --dump --count 8 --seed <...>
- (final) cargo build --release && user reruns
```

## Hard rules (do not violate)

1. **The screenshot is the spec.** Do not ask the user to "tell me what
   happened" when they have already attached one.
2. **Read the footer first.** The control hints there reveal what the user
   thinks the keys do, often revealing their mental model of the bug.
3. **Never fix one cause at a time if multiple share the same root.**
   You'll ship a partial fix that masks the other cause.
4. **Do not invent causes from absence.** "I can't see a mouse drag handler"
   is a real diagnostic only if the user reported mouse drag. Don't add
   "could be a HUD rendering issue" without a screenshot or log.
5. **The fix has to be testable.** A "behavioral" fix without a unit test
   is a guess — run `cargo test`, then run the headless `--dump` or
   a recorded input replay.

## Common false diagnoses (do not fall for)

- "Add a sleep" — never. It's a magic constant that hides the cause.
- "Add a counter and read it from the UI" — useful as **provisional
  diagnostic** but always followed by removing the counter once the
  cause is found.
- "Increase the buffer" — if a buffer is overflowing, fix the producer
  not the consumer.
- "It's a compiler optimization" — almost never is. The Rust compiler
  is boringly stable.

## What this is NOT

- Not a substitute for actual play-testing on a real terminal. The
  screenshot, dump mode, and record-replay are diagnostic scaffolding
  for the moment when the user can't actually play.
- Not an excuse to skip reading the screenshot. The most common
  mistake we've made (and probably will make again) is asking the user
  to "tell me more" before doing any of steps 1–4 above.
