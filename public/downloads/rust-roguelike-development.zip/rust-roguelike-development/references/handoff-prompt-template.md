# Handoff Prompt Template (다른 AI 에이전트로 떠넘길 때)

When a single bug has burned 5+ patches with no resolution, stop iterating
and hand the codebase to a fresh agent. The new agent's fresh-eyes
perspective often finds the bug in 1-2 attempts because they read the
code without accumulated bias.

The handoff prompt is the only artifact you transfer — it must be
self-contained enough for the new agent to start debugging without
asking you any questions.

## Write the prompt in 8 sections

### 1. 작업 환경 (Environment)

- Repo URL + local path
- Branch + current version
- Test count ("101 tests passing")
- Tech stack summary (Cargo workspace layout, key crates)

### 2. 핵심 자산을 어떻게 재사용할 것인가 (Reusable infrastructure)

If the codebase has pre-built infrastructure (ModalMode enum, save/load,
button handlers), name them explicitly. The new agent needs to know what
NOT to rebuild. Use a table:

| Infrastructure | Path | Reuse pattern |
|---|---|---|
| `ModalMode` enum | `crates/app/src/lib.rs:86` | `Variant { cursor }` pattern |
| `SoulRemembrance` | `crates/core/src/meta.rs` | `ron` serialize |
| `new_at_with` | `crates/app/src/lib.rs:122` | constructor pattern |

### 3. SPEC / requirements (if relevant)

If the bug is about a missing feature, quote the relevant SPEC section.
The new agent should not have to re-read the entire SPEC to know what's
required.

### 4. 시도해본 패치 (Attempted patches, NOT applied)

This is the **most important section** for fresh-eyes diagnosis. List
every patch tried, what it tried to fix, and whether it actually moved
the needle:

| Version | Change | Did it work? |
|---|---|---|
| v0.5.11 | ConfirmStairs modal added, `>` key dismissed | No, modal never triggers |
| v0.5.14 | `modal_redraws: u8` 1-frame guarantee | No |
| v0.5.15 | `at_stairs: bool` header badge | No |
| v0.5.16 | n-cancel recovery UX | Made it worse (infinite modal trap) |
| v0.5.17 | debug log | log fires, modal still missing |
| v0.5.18 | recovery UX removed | No |
| v0.5.19 | entity_at filter for loot | No |

This table helps the new agent see **which hypotheses have been
exhausted** and which directions remain.

### 5. Code snippets (current state)

Include the exact code region the bug is in, with line numbers. Don't
just describe — paste the actual code. The new agent's first read should
be `git log` looking at the diff, not searching for the file.

### 6. Reproduction recipe (critical)

Spell out the exact reproduction:

```rust
let app = App::new_at(0xCAFE_BABE_DEAD_BEEF, 1);
let (sx, sy) = last_room_center;
let mut pos = app.world.get::<&mut Position>(app.player).unwrap();
pos.0 = TilePos(sx - 1, sy);  // place one tile LEFT of stairs
app.handle(&char_event('l'));    // press 'l' to walk onto stairs
// Modal should fire here. If it doesn't, that's the bug.
assert!(matches!(app.modal, ModalMode::ConfirmStairs));
```

Make this trivially copy-pasteable. The new agent should be able to
drop it into a test and run it.

### 7. Unverified hypotheses (your list)

The patches you wrote were guided by hypotheses. Some were tested and
proven wrong. **List the ones you didn't get to test.** These are the
new agent's most valuable leads:

- Could `pick_up_outcome` mutate `self.modal` somewhere we missed?
- Could `enemy_take_turns()` block the trigger by moving an enemy onto
  the stairs?
- Could `populate_floor` leave a hidden entity on the stairs tile that
  we don't see in `dungeon.rooms`?
- Could the modal state be cleared by some other handler between the
  stairs arrival and the next frame?

### 8. 작업 스타일 (User's working style)

Add a short note on how the user wants the work done:

- 3-5 day incremental releases (one milestone per release, not one
  big bang)
- Each step ends with `cargo test` + `cargo build` + `git push`
- Brief Korean summary at each step (10 lines max)
- Minimum new abstractions — don't introduce AutoPilot as a separate
  system if Modal can be reused
- main.rs and lib.rs sync required (dual-source binary pattern)

## Real example (asciirogue v0.5.19 stairs modal handoff)

The actual handoff prompt I wrote for the user covered:

1. **Environment**: Repo + version + tests passing
2. **Reusable infrastructure**: 7 items (entity_at, modal, populate_floor, etc.)
3. **Problem**: User report quoted verbatim
4. **Attempted patches**: 9-version table with what each tried
5. **Current code**: try_player_act full body + the v0.5.19 filter
6. **Reproduction**: 4-step cargo test
7. **Unverified hypotheses**: 5 numbered possibilities
8. **Style**: Korean summary, 3-5 day cycles, no premature optimization

Total ~1500 tokens. The new agent's first 30 minutes would be
understanding the codebase; with this prompt, that becomes 5 minutes.

## When NOT to use this template

- **Bug first reported in this session** — wait for at least 2-3 patches
  to confirm it's not a one-line mistake.
- **Multiple competing bugs** — split into separate handoffs.
- **User has clearly said "abort" / "different approach"** — they want
  stopping, not transfer.

## When to use aggressively

- **Same user-facing symptom + 3+ patches** — pattern match for handoff.
- **User says "여전히 안됨" / "다른 방법"** — they're giving up on this session.
- **Bug is in a "blind spot"** — modal handler, render order, borrow
  lifetimes — places where the current agent has been unable to apply
  meaningful eprintln trace.
