# Tile + Spawn Publish Pattern

When you add a new `Tile` variant that is positioned in a specific room or
tile (stairs, ladder, portal, trap, save point, shrine, anything with a
fixed per-floor location), the spawn helpers must be able to avoid it.
The naive pattern — "spawn at `rooms.last().center()`" — silently collides
with the new tile and the player cannot reach it.

## The asciirogue v0.5.10/v0.5.12 case study

1. v0.5.10 added `Tile::StairsDown` to procgen. The BSP generator placed
   one in the last room's center.
2. `populate_floor` chose spawn positions by `room.center()` and
   `rooms.last().center()` — exactly the same tile.
3. The boss on BOSS_FLOOR landed on the stairs tile. The player could
   not walk onto ▼ until the boss was killed.
4. v0.5.12 added `Dungeon.stairs: Option<TilePos>` so spawn helpers
   could check the location and nudge 1 tile away.

## The pattern

```
Tile variant X added to procgen with a fixed location
   ↓
Expose the location on Dungeon: pub foo: Option<TilePos>
   ↓
BSP generator publishes it: dungeon.foo = Some(pos) after carve
   ↓
Spawn helpers check: if (cx, cy) == dungeon.foo { nudge 1 tile }
   ↓
Test: assertion that no entity occupies the X tile
```

## Why "nudge 1 tile" is the right fallback

| Alternative | Why it fails |
|---|---|
| Skip the room entirely | Leaves a room with no enemy on some seeds |
| Despawn the new tile | Defeats the design — the tile must exist |
| Move the new tile | The user already saw it there; moving is bad UX |
| Reject the room | Same as skip — breaks spawn determinism |
| Nudge 1 tile (in-room) | Always works, preserves design, testable |

The nudge target is the 8-neighbour ring around the stairs tile. Walk
them in `(0,1) (1,0) (0,-1) (-1,0) (1,1) (1,-1) (-1,1) (-1,-1)` order
(cardinal first, then diagonal) and pick the first one inside the room.

```rust
fn nudge(room: &Rect, sx: i32, sy: i32) -> Option<(i32, i32)> {
    for (dx, dy) in [(0,1), (1,0), (0,-1), (-1,0),
                     (1,1), (1,-1), (-1,1), (-1,-1)] {
        let (nx, ny) = (sx + dx, sy + dy);
        if room.contains(nx, ny) && (nx != sx || ny != sy) {
            return Some((nx, ny));
        }
    }
    None
}
```

## What to test

A regression test that sweeps 30+ seeds asserting no entity occupies
the new tile. For the BOSS_FLOOR case, use a fixed seed plus a check
that the boss specifically is NOT on the new tile.

```rust
#[test]
fn no_entity_occupies_X_tile() {
    for seed in 0u64..30 {
        let app = App::new_at(seed, 1);
        let target = app.dungeon.foo.unwrap();
        for (_, pos) in app.world.query::<&Position>().iter() {
            assert_ne!((pos.0.0, pos.0.1), (target.0, target.1),
                "seed={}: entity at ({},{}) overlaps X tile",
                seed, target.0, target.1);
        }
    }
}
```

## When NOT to use this pattern

- Temporary tiles (a tile that only exists for one turn, then reverts
  to Floor). Those don't need a `Dungeon` field.
- Tiles that are not unique per floor (multiple chests, scattered
  rocks). Use a query/scan instead.
- Tiles whose location is computable from the BSP tree itself
  (e.g. "the deepest room" — already known as `rooms.last()`).

## Future variants this pattern covers

- **Ladders** (going up — same pattern, different glyph)
- **Portals** (return to a previous floor — same pattern)
- **Shrines** (save points, hp/mp restore — same pattern)
- **Trap pressure plates** (hidden until triggered — same pattern but
  spawn-time visibility)

Anything unit-testable as "exactly one per floor, in a known room,
spawn-sensitive" goes through this checklist.
