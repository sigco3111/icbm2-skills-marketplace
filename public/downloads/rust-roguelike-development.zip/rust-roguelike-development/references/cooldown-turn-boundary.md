# Cooldown / turn-boundary reset placement

The cooldown reset position bug — symptom: a "fixed" infinite-attack loop
still runs, only after a single key press.

## The pattern that breaks

```rust
fn enemy_take_turns(&mut self) {
    // WRONG — resets BEFORE we run the enemies
    self.world.query::<&mut Ai>().iter().for_each(|(_, ai)| ai.cooldown = 0);

    for entity in self.enemy_query_plan {
        if ai.cooldown > 0 { continue; }
        if matches!(action, AttackPlayer) {
            ai.cooldown = 1;  // gate to prevent re-attacks
            attack_used = true;
        }
    }
}

fn try_player_act(&mut self, dir: Direction) {
    // player action
    self.enemy_take_turns();  // calls the above
}
```

This looks right — the gate is in place. But the FIRST time an enemy attacks,
the very next `try_player_act` call runs `enemy_take_turns` again, which
opens with `cooldown = 0`, **re-enabling** the same enemy (and every
adjacent enemy that hasn't attacked yet) on the same turn's very next
attempt. The loop appears infinite because the gate is closed for ~0
frames — it gets reopened by the reset that's racing one frame ahead.

The right shape is **clear at the player-turn boundary, AFTER the enemy
phase ends**, never BEFORE the next enemy phase begins.

## The pattern that works

```rust
fn enemy_take_turns(&mut self) {
    // do NOT reset here
    for entity in self.enemy_query_plan {
        if ai.cooldown > 0 { continue; }     // honest gate
        if matches!(action, AttackPlayer) {
            ai.cooldown = 1;                    // set on attack
            attack_used = true;
        }
    }
}

fn try_player_act(&mut self, dir: Direction) {
    // ... player action
    self.enemy_take_turns();
    self.clear_enemy_cooldowns();              // explicit boundary fix
}
```

This is — strictly — the same statement with the same loop, but the timing
of the reset is what makes it work. After every player action, the enemy
phase runs once and ends. The reset is the LAST thing that happens in
the player-action cycle, so any cooldown=1 set by an attacker persists
until the NEXT full cycle. There is no race.

## Why this doesn't show up in `cargo test`

If you unit-test `enemy_attack(entity)` in isolation, you call it, it
sets cooldowns on the world, returns. There is no `enemy_take_turns` to
race against. The test passes.

The bug only shows up when the actual game loop runs: every player key
re-enters `try_player_act`, which calls `enemy_take_turns`, which
re-runs the enemy phase. **Cargo test is a poor person's TUI
integration test** (per the umbrella's references/cli-loop-integration-testing.md),
and this is exactly the class of failure cargo test misses.

## Detection

If the user says any of:
- "the enemies never stop hitting me"
- "every turn a new enemy attacks me"
- "the same enemy attacks from the same spot, over and over"
- "I press a key, nothing visible changes, but the log keeps scrolling"

You are looking at this bug. Build (or run) the `examples/play_probe.rs`
from the umbrella's references/headless-driver-binary.md and look for
the symptom at `t=N`: same player position, same messages capped at 5,
HP — but the message log ONLY changes by appending one new entry per
player step (e.g. another "적 명중! X 피해 (치명타!)").

## What to do

Fix is one line. Patch in this order:

1. Add `clear_enemy_cooldowns()` method on `App`.
2. Remove the cooldown-reset from the top of `enemy_take_turns`.
3. Call `clear_enemy_cooldowns()` at the END of every branch of
   `try_player_act` that calls `enemy_take_turns` (move, attack, wait).
   Bump (early return) does NOT call it, because a bump doesn't advance
   the world clock.
4. Re-run the probe. The infinite log should stop at exactly one message
   per real move.

## Why "just clear before the next action" tempts you back

The intuition "the player's next action starts a new turn, so clear at
the start of try_player_act" is correct semantically. The implementation
problem is that `try_player_act` is also called from `--dump` render and
from game-over handling, and if your `clear` runs there, you reset
cooldowns an extra time for free. **Always the END of the function that
OBSERVED the cooldown** — the attacker observing its own attack — is
the safest symmetric placement.

## Related

- references/headless-driver-binary.md — the diagnosis tool
- pitfalls list, item 9, in SKILL.md
</file_content>
