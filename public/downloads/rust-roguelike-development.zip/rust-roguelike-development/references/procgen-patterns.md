# Procedural generation patterns for Rust roguelikes

Anchored to asciirogue (`crates/procgen`). Covers BSP trees, deterministic
seed mixing, and the gotchas that come from seeding per-floor.

## BSP-tree dungeon (the one that works)

`crates/procgen/src/bsp.rs` (asciirogue) is the model. ~200 LOC:

1. Pick root `Rect { x1: 0, y1: 0, x2: W-1, y2: H-1 }`.
2. Pick a min-leaf size (`min_leaf_size: 8`) and recursion cap (`max_depth: 5`).
3. At each leaf, decide whether to split (width vs height ratio → horizontal
   vs vertical cut; cut point uniform in `[min_size, dim - min_size]`).
4. When a leaf hits a stop condition, place a room of size
   `[room_min, room_max]` aligned inside the leaf.
5. Walk the tree and connect sibling rooms' centers with L-shaped
   corridors.

Pitfalls:
- **Don't split non-uniformly** (random range per leaf). It produces
  **degenerate maps** with one giant room and several crawlspaces.
- **Cut point inclusive** at `min_size` will produce a 7-wide leaf after a
  cut (the spec says 8). Use `<` not `<=` in the cut loop.
- **Sibling pair connection order matters**. Pick a stable traversal order
  (left-right first, then middle) so two seeds always produce two maps
  that match frame-by-frame.

## Deterministic seed mixing across rooms / floors

```rust
let base_seed = 0xCAFE_BABE_DEAD_BEEF_u64;
let per_floor = base_seed.wrapping_add(floor as u64 * 0x9E37_79B9_7F4A_7C15);
let per_room = base_seed.wrapping_add(
    (room.x1 as u64) << 32 | (room.y1 as u64) << 16 | (room.x2 as u64)
);
```

`0x9E3779B97F4A7C15` is the golden ratio 64-bit fractional; mixing it
into the per-floor seed gives a statistically uncorrelated but
deterministic per-floor sequence.

Tradeoff: pure LCG / XorShift / wyrand — pick ONE and stick with it. asciirogue
went with XorShift (in `bracket-random`). Bracket random is single-threaded
by default → fine for procgen which is sequential.

## Test surface (must be in every rng/procgen module)

```rust
#[test]
fn determinism() {
    let a = generate(40, 24, seed, Config::default());
    let b = generate(40, 24, seed, Config::default());
    assert_eq!(a.tiles, b.tiles);
}

#[test]
fn different_seeds_differ() {
    let a = generate(40, 24, 1, Config::default());
    let b = generate(40, 24, 2, Config::default());
    assert_ne!(a.tiles, b.tiles);
}
```

If `rng` comes from a `std::time::SystemTime`-flavored source,
determinism breaks. Always seed from a `u64` argument.

## Spawn tables — keep them in module-level arrays

For enemy/item spawn templates:

```rust
const ENEMY_TEMPLATES: &[(char, &str, Stats, AiKind)] = &[
    ('r', "쥐",    Stats::new(3, 8, 1, 1, 5),  AiKind::Coward),
    ('g', "고블린", Stats::new(5, 6, 2, 2, 7),  AiKind::Chase),
    ('B', "곰",    Stats::new(9, 4, 1, 1, 12), AiKind::Chase),
    ('S', "스켈레톤", Stats::new(7, 7, 1, 1, 8), AiKind::Chase),
    ('D', "드래곤", Stats::new(12, 8, 6, 6, 16), AiKind::Chase),
];

fn spawn(world: &mut World, dungeon: &Dungeon, room_idx: usize, index: usize) {
    let (g, n, s, k) = ENEMY_TEMPLATES[index];
    // ...
}
```

Pitfall: putting these tables inside `App::new` makes them rebuild every
new floor. Hoist them out to `const`s or `lazy_static`s.

## Heuristics for which spawns per floor

- **Tier 1** (floors 1–2): only rat + goblin. Even a tougher enemy makes
  the early game feel like a meat grinder.
- **Tier 2** (3–4): rat + goblin + bear.
- **Tier 3** (5–7): all 5 enemy types but weighted toward tougher ones
  deeper in the dungeon.
- **Boss floor**: replace tier N with the boss template. Use a different
  detection mechanism than tier (e.g. `health.max > 100` threshold on the
  boss vs. tier enemies — see the boss_killed heuristic in
  asciirogue's `despawn_dead`).

The exact mapping is project-specific — but the tier+theme framing is
what you want to write down in your SPEC.md *before* you start coding
spawns.

## Loot tables

- **Color and glyph before logic.** Asciirogue's Item struct has `name`,
  `glyph`, `fg_rgb`, `bonus` — the visual surface.
- One `loot spawn per 2nd room` keeps proportions sane. Adjust ratio
  per floor.
- Every item pickup should immediately increase a deterministic
  counter. asciirogue logs "주울 아이템이 없습니다." even on empty
  pickup attempts — better than silent nothing.

## RNG within `try_pickup`-like loops

If a single function makes several RNG calls and you need
deterministic output, **pin the seed in the function's tests**.

`asciirogue combat attack::resolve_attack` takes `rng: u32` as an arg
explicitly so tests can pin it. Do the same. Don't bury the RNG inside
the function — the testability gain is enormous.

## Variation: 8-floor theme cycle

asciirogue = 8 floors max (full game). `FloorTheme` from depth:

```
1..=4   Cave
5..=8   Catacomb
9..=12  Garden
13..=16 Library
17..=20 Forge
21..=24 Temple
25..=27 FinalMaw
28      Boss
```

For 8-floor v1 the table extends accordingly. The label is Korean
("동굴", "카타콤", "정원", "도서관", "대장간", "신전", "심연", "쏠쏠리의 방").

The point is not the *exact* table — the point is *a per-floor theme
table that lives in your SPEC.md before you start coding*. Update the
table every time you decide a new theme; don't defer to "we'll figure
that out when we get there".
