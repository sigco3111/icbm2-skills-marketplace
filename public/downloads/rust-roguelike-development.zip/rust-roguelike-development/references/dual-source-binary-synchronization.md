# Dual-Source Binary Synchronization

When a Rust crate is split into `lib.rs` + `main.rs` (typically for
testability), the two files often carry parallel copies of the same
struct, methods, and helper functions. Every gameplay change must be
applied to BOTH files or the `--bin` will silently fall behind while
the tests (`--lib`) keep passing.

This is the asciirogue pattern: `lib.rs` defines the canonical `App`
struct, `populate_floor`, `spawn_enemy`, `try_player_act`, `handle`,
etc. `main.rs` re-defines the same things so that the binary's
`main()` can have its own `App`. The two files have drifted
synchronization-wise **every** version since v0.5.3 (lib/bin split).

## The pattern (asciirogue v0.5.10 / v0.5.11 / v0.5.12)

```
crates/app/src/
├── lib.rs     # App, handle, populate_floor, spawn_enemy, ... (canonical)
└── main.rs    # App, handle, populate_floor, spawn_enemy, ... (parallel)
```

When a gameplay change touches ANY of:

- `App` struct fields
- `App` methods (`handle`, `try_player_act`, `descend_internal`, …)
- helper functions (`populate_floor`, `spawn_enemy`, `pick_up_outcome`,
  `t_format_with_locale`, …)

you must apply it to BOTH files. The test suite only exercises `lib.rs`
because tests live in `lib.rs`. The binary in `main.rs` is what the
user actually runs.

## Symptom checklist (run BEFORE every commit)

Before committing any change to `crates/app/src/lib.rs`, run:

```bash
diff -u <(grep -E '^(pub )?fn |^(pub )?struct |^impl ' crates/app/src/lib.rs) \
        <(grep -E '^(pub )?fn |^(pub )?struct |^impl ' crates/app/src/main.rs)
```

If the diff is large, the two files are about to drift. Sync first.

## Why the split exists (and why it costs)

- **Why it was split**: `cargo test` works on `lib.rs`. Headless probe
  binaries import the lib. The split lets the test suite exercise
  gameplay paths without touching the TUI backend.
- **Why it costs**: every change is duplicated. The v0.5.10 stairs
  gating, v0.5.11 stairs confirm modal, v0.5.12 stairs-unblocked fix
  all required three near-identical edits (lib.rs + main.rs + render
  test fixtures). One forget and the binary boots but the test suite
  still passes.

## Mitigations (mitigate, don't eliminate)

The split is a real testability win. The mitigations below reduce the
sync cost without reverting to a single source.

### 1. Always diff both files before commit

```bash
git diff --stat HEAD -- crates/app/src/lib.rs crates/app/src/main.rs
```

If both files touched, the change is gameplay-affecting and the diff
needs to be visually cross-checked between the two.

### 2. Single source of truth for future helpers

When adding a NEW helper, put it in `lib.rs` as `pub fn` and import it
from `main.rs` via `use asciirogue::helper_name;`. The existing code
already has `pub fn populate_floor`, `pub fn spawn_enemy`, etc. in
`lib.rs` — `main.rs` could `use asciirogue::{populate_floor,
spawn_enemy, ...}` instead of redefining. The **refactor is on the
backlog** but the pattern is clear: the moment a third file wants the
same helper, promote it to `lib.rs` and import.

### 3. Synced test gate

Keep at least one regression test in `lib.rs` that exercises the same
path the `main.rs` change touches. The cargo test diff catches the
asymmetry if the test was written first.

```rust
// In lib.rs — keep this test in lockstep with the main.rs equivalent.
#[test]
fn main_rs_repo_keeps_stairs_unblocked() {
    // Reads from main.rs are awkward in a unit test; instead, run
    // `cargo build --release` and assert the binary compiles.
    // (This is a meta-test — the lib.rs copy is the source of truth.)
}
```

### 4. Code review checklist

When reviewing a PR that touches `lib.rs`, add this checklist:

```
[ ] `main.rs` mirrors the same change
[ ] `populate_floor` and `spawn_enemy` updated in both files
[ ] `try_player_act` and `handle` updated in both files
[ ] `App` struct field, if added, is in both files
[ ] `ModalMode` enum, if extended, is in both files
[ ] `cargo build --release` produces a working binary
[ ] `cargo run --release -- --dump --seed 0xCAFE` produces the expected
    layout (smoke check)
```

## The pre-commit script

Use this as a pre-commit hook:

```bash
#!/usr/bin/env bash
# ~/.hermes/skills/rust-roguelike-development/scripts/dual-source-sync-check.sh
set -e
LIB=crates/app/src/lib.rs
MAIN=crates/app/src/main.rs
if [ ! -f "$LIB" ] || [ ! -f "$MAIN" ]; then
    exit 0
fi
LIB_FNS=$(grep -cE '^(pub )?fn |^impl ' "$LIB")
MAIN_FNS=$(grep -cE '^(pub )?fn |^impl ' "$MAIN")
if [ "$LIB_FNS" -ne "$MAIN_FNS" ]; then
    echo "WARN: lib.rs has $LIB_FNS functions/impls, main.rs has $MAIN_FNS."
    echo "      diff before commit:"
    diff -u <(grep -E '^(pub )?fn |^impl ' "$LIB") \
            <(grep -E '^(pub )?fn |^impl ' "$MAIN") | head -30
    exit 1
fi
```

`cargo test --release` plus the script above is a reasonable gate.

## When to actually consolidate

If the project's test surface ever grows to the point where `main.rs`
only contains a `main()` wrapper, fold `main.rs` into `lib.rs`. The
trigger condition is roughly:

- `main.rs` < 20 lines (just `fn main()` and module declarations)
- All `App` initialisers live in `lib.rs` as `pub fn new_*`
- The TUI entry point is `pub fn run_tui() -> Result<()>` in `lib.rs`

The asciirogue project is at "moderately oversized `main.rs`; not
quite ready to fold" status. The `cargo test` + `cargo build` gate
above is the right intermediate stance.

## Anti-patterns

- **DON'T add a helper to `main.rs` that doesn't exist in `lib.rs`**.
  If the helper is real, it belongs in `lib.rs` as `pub fn`.
- **DON'T make `main.rs` the source of truth for a struct field**. The
  `App` struct should always be defined in `lib.rs` and `main.rs` should
  re-import via `use asciirogue::App`.
- **DON'T skip the cross-check on "trivial" changes**. Removing an
  unused parameter is the kind of edit that triggers `cargo test` passing
  on `lib.rs` while `main.rs` keeps the old signature and breaks the
  binary at runtime.
