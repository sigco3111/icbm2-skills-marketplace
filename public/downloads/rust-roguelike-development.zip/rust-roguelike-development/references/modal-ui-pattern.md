# Modal UI Pattern (TUI popup)

A TUI roguelike modal (inventory, confirm prompt, character sheet) needs
exactly four layers wired together. Missing any one of them and the
modal leaks input, fails to render, or both.

## The four layers

### 1. State (modal enum + App field)

```rust
#[derive(Copy, Clone, Debug, Eq, PartialEq)]
pub enum ModalMode {
    Closed,
    Inventory { cursor: usize },
    ConfirmStairs,  // v0.5.11 / v0.5.12
}

pub struct App {
    // …
    modal: ModalMode,
}
```

Keep the enum flat. Each variant carries just the per-modal state it
needs (cursor, hovered item, scroll offset). Don't bury modal state in
free-standing booleans — that loses the "exactly one modal at a time"
property.

### 2. Input gate (top of `handle()`)

```rust
pub fn handle(&mut self, ev: &Event) {
    if let Event::Key(k) = ev {
        if k.kind == KeyEventKind::Press {
            // Modal input gate — match BEFORE the gameplay event loop.
            if matches!(self.modal, ModalMode::ConfirmStairs) {
                match k.code {
                    KeyCode::Char('y') | KeyCode::Char('Y') | KeyCode::Enter => {
                        self.modal = ModalMode::Closed;
                        self.action_descend();
                    }
                    KeyCode::Char('n') | KeyCode::Char('N') | KeyCode::Esc => {
                        self.modal = ModalMode::Closed;
                        self.log(i18n::t_for(I18nKey::MsgStairCancel, self.locale));
                    }
                    _ => { /* ignore other keys, keep modal open */ }
                }
                return;  // never fall through to gameplay
            }
            // gameplay event loop continues here …
        }
    }
}
```

The `return` is mandatory. Without it, the gameplay loop also runs and
the player walks into a monster while answering the prompt.

### 3. Trigger site (set `modal = …` from gameplay events)

For modal-on-arrival (no separate hotkey):

```rust
fn try_player_act(&mut self, dir: Direction) {
    // … existing movement code …
    self.tick = self.tick.wrapping_add(1);
    self.enemy_take_turns();
    // Trigger ConfirmStairs AFTER enemy turn so any attacker on the
    // stairs tile has already acted.
    if matches!(self.modal, ModalMode::Closed)
        && matches!(self.dungeon.at(next.0, next.1), Tile::StairsDown)
    {
        self.modal = ModalMode::ConfirmStairs;
    }
}
```

For modal-on-hotkey (separate key opens it):

```rust
KeyCode::Char('i') => {
    let cursor = /* first non-empty slot */;
    self.modal = ModalMode::Inventory { cursor };
}
```

**Pick one trigger style per modal.** Mixing both ("open inventory with
`i` OR by walking onto a chest") is almost always a bug — the player
walks onto a chest they didn't intend to open.

### 4. Render overlay (last in `draw()`)

```rust
fn draw(&self, frame: &mut Frame) {
    self.draw_world(frame, area);
    // …
    // Modals last, so they paint over the world.
    if let ModalMode::Inventory { cursor } = self.modal {
        self.draw_inventory_modal(frame, area, cursor);
    }
    if matches!(self.modal, ModalMode::ConfirmStairs) {
        self.draw_confirm_stairs_modal(frame, area);
    }
}
```

The modal widget MUST use `Clear` before the inner block to wipe the
map underneath. Without it, the modal looks like a transparent overlay
sitting on top of glyphs.

```rust
fn draw_confirm_stairs_modal(&self, frame: &mut Frame, area: Rect) {
    let popup_w = 40u16.min(area.width.saturating_sub(2));
    let popup_h = 5u16;
    let x = area.x + (area.width.saturating_sub(popup_w)) / 2;
    let y = area.y + (area.height.saturating_sub(popup_h)) / 2;
    let popup = Rect::new(x, y, popup_w, popup_h);

    frame.render_widget(Clear, popup);  // wipe the map underneath
    let block = Block::default()
        .title(Span::styled("내려가기", Style::default().add_modifier(Modifier::BOLD)))
        .borders(Borders::ALL);
    frame.render_widget(block, popup);
    // render inner content …
}
```

## Layout math for centred popups

```
popup_w = min(40, area.width - 2)
popup_h = 5
x = area.x + (area.width - popup_w) / 2
y = area.y + (area.height - popup_h) / 2
```

The `-2` accounts for terminal-frame borders. If your terminal has
`Block::default().borders(Borders::ALL)` on the outer frame, the inner
`area` is already inset.

## i18n integration

Modal text should be in the i18n table, not hard-coded:

```rust
let prompt = i18n::t_for(I18nKey::MsgStairConfirm, self.locale);
let (y_label, n_label) = match self.locale {
    Locale::Korean => ("[y] 예", "[n/Enter] 취소"),
    Locale::English => ("[y] yes", "[n/Enter] cancel"),
};
```

The fallback message and the OK message are separate keys (e.g.
`MsgStairConfirm`, `MsgStairDescendOk`, `MsgStairCancel`). Reusing the
prompt key for the success message is a small bug that breaks the log
readability.

## Tests

Each modal needs at least 4 tests:

1. Open via the trigger site, assert `modal` matches.
2. Default-confirm key (y / Enter) executes the action and clears modal.
3. Default-cancel key (n / Esc) clears modal and skips the action.
4. Other keys (e.g. `h` movement) while modal is open are inert.

Plus an integration test that walks the player onto the trigger site
and asserts the modal opens:

```rust
#[test]
fn walking_onto_stairs_triggers_confirm() {
    let mut app = App::new_at(seed, 1);
    // teleport then trigger
    app.modal = ModalMode::ConfirmStairs;
    app.handle(&char_event('y'));
    assert_eq!(app.floor, 2);
}
```

## Anti-patterns

- **"Open via hotkey AND via trigger site"** — split-brain modal
  state. Pick one.
- **Modal state as a flat bool `confirm_stairs: bool`** — can't extend
  to a second modal without losing the "exactly one" property.
- **Modal handler at the BOTTOM of `handle()`** — input gate must be
  at the top, before gameplay events.
- **Render modal UNDER the world map** — modals always render last.
- **No `Clear` widget** — see the visual ghosting example above.
