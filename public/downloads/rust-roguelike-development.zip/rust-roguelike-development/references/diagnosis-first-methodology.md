# Diagnosis-first methodology — when "still doesn't work" means your model is wrong

This is the **meta-pattern** behind every successful asciirogue fix that
followed a long patch chain. It's not about TUI or hecs; it's about
recognising when to stop patching and start observing.

## The trigger signals

Any of these means **drop the keyboard, write a probe, re-form the hypothesis**:

1. The user reports the same symptom after two or more patches you were
   confident about.
2. The user pastes the same screenshot twice.
3. The user says "다른 방법을 찾아봐", "여전히 안됨", "stop trying the same
   thing", "I already tried X", or "계속 같은 방법으로 시도하지 말고".
4. The patch you just shipped **passes your own unit test but the user
   says it didn't fix the runtime symptom**. (Tests are a model; the
   user is the ground truth.)
5. You find yourself writing a fix that re-uses a previous fix's
   assumption without re-verifying it.

When these fire, do **NOT** write another patch in the same vein. That
is the loop the user is telling you to break out of.

## The four-step method

### Step 1 — write down the EXACT user-visible failure

Not "pickup is broken". Instead:

> "User reports: pressing `g` next to a gold coin says
> '주울 아이템이 없습니다' even though the coin is visible one tile away.
> The gold is at (12,20); the player is at (13,20); the message
> re-appears every press."

Three concrete facts: coordinates, message text, action. This makes
the next steps falsifiable.

### Step 2 — list the assumptions your last patch relied on

For asciirogue pickup, after three "fixes":

- **A1**: pickup searches for items by Position matching player_pos.
- **A2**: ground items are stored as entities with `Item` + `Position`.
- **A3**: the player position reflects the visible glyph.

A1 turned out to be the bug. A2 and A3 were both correct. Identifying
A1 from the probe output (Step 4) took one cycle.

### Step 3 — write a headless probe that OBSERVES, not just asserts

The probe must answer: "what is the actual value of the failed
invariant at the moment of failure?"

For pickup:

```rust
// crates/app/examples/pickup_probe.rs
let mut app = App::new(seed);
let player = find_player(&app);
// Teleport to the exact scenario, place the gold adjacent.
world.get::<&mut Position>(player).unwrap().0 = TilePos(13, 20);
world.spawn((Position(TilePos(12, 20)), Item::gold(7)));
// What does pickup say?
let outcome = pick_up_outcome(world, player);
println!("outcome={:?}", outcome);  // "NoItem" — confirms the bug
```

This is **NOT** a regression test that asserts `outcome == Picked`.
It is observation first. The assertion is for the test you write *after*
the patch, not the probe that informs the patch.

`pickup_probe.rs` and `header_probe.rs` (asciirogue v0.5.5) are
templates. The probe lives in `examples/` and prints `eprintln!` per
step — three lines of grep-friendly output beats a pretty CLI.

### Step 4 — read the probe output BEFORE writing code

The probe for asciirogue pickup printed:

```
[scenario-A nearest_pickup_info] = Some((2, Up, '$'))
[scenario-A after g] msgs = ["...주울 아이템이 없습니다."]
```

`Some((2, Up, '$'))` means **the gold is 2 tiles away in the BFS
direction Up, not 1 tile away**. So the player at (13,20) cannot
literally reach (12,20) — there's a wall between them. The visible
"adjacent" gold is at a different (x,y) entirely. The fix isn't to
widen pickup; it's to surface this distance to the player (which is
what v0.5.5 did) AND widen pickup to ±1 neighbourhood so the visible-
adjacent case (which IS what the user was hitting) gets picked up
(v0.5.6).

Notice: the probe output contradicted the user's framing ("gold is
right next to me") and contradicted my prior patch's model. **Both
were wrong in slightly different ways.** The probe told me which.

## Anti-patterns

- **"Let me try one more thing."** If the user said "다른 방법", another
  similar patch is the wrong move. The probe is the new method.
- **Reading the probe output through the lens of your prior model.**
  If the probe says "X", believe it. Do not reinterpret "X" as
  "X but in the way my last patch was assuming".
- **Skipping the probe because "I can just reason about it".** The
  whole point of the probe is that reasoning failed N times already.
- **Committing a probe as a regression test without first reading it.**
  Write the probe, run it, look at the output, THEN write the fix,
  THEN promote the probe's assertions into a `#[test]`.

## Pairing with the headless driver

`references/headless-driver-binary.md` covers `examples/play_probe.rs`
for **gameloop** bugs (loops, stuck, spam, doesn't end). This file
covers **state-invariance** bugs (the right code path produces the
wrong output). Both share the same shell:

```bash
cargo run --example <name>_probe
```

Different probes for different question shapes:

| Question | Probe name | Ref |
|---|---|---|
| "Does this loop terminate?" | `play_probe` | headless-driver-binary.md |
| "Does this coordinate/quantity match what the user sees?" | `pickup_probe`, `header_probe` | this file |
| "Does this assertion fail under this seed?" | in-tree `#[test]` | rust-lang.org/book |

## When the user pastes a screenshot

Combine this methodology with `references/roguelike-feedback-triaging.md`:

1. Read the screenshot — extract coordinates, message text, glyphs.
2. Write a probe that reproduces the exact pixel state.
3. Run the probe against your current build. The output is your
   ground truth, not your last patch's mental model.

The asciirogue v0.5.5 session did exactly this with a user-pasted
screenshot of "주울 아이템이 없습니다" + adjacent gold. Two probes
later (`pickup_probe` and `header_probe`) the entire situation became
readable in a way no patch attempt had been.

## Why this isn't "just try harder"

The temptation is to call this "debugging discipline". It isn't. It's
the recognition that **once you've patched 3+ times without progress,
your model is the bug**. The user has the ground truth in their head;
you have a hypothesis in your head. Until you observe theirs directly
(via probe), every further patch is gambling that you'll guess right
without evidence.

This is why the asciirogue session jumps from `cargo build` directly to
`cargo run --example pickup_probe` whenever the user signals
frustration: the probe is the cheapest possible bridge between your
model and their reality.
