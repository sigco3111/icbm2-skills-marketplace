# Headless driver binary via crate `examples/`

The third verification tier — between `--dump` and "ask the user to play for you".

`--dump` prints one frame per floor **at spawn time**. It cannot show:

- What happens over multiple player turns
- Enemy AI decisions accumulated over time
- Message log mutation patterns across many moves
- "Stuck" bugs (player can't move, but enemies still act)
- Death-then-respawn scenarios
- Boss-defeats-then-floor-transitions

The `examples/play_probe.rs` pattern — invented in asciirogue v0.5.3 — solves all of these. It's a Cargo example binary that drives the game under programmer control and prints state after every step.

## The structural prerequisite

The `examples/<name>.rs` binary needs to **call methods on `App`** directly. ratatui is the only thing keeping `App` private to a binary. If your `App` is inside `[[bin]] main.rs`, you cannot call `App::step(...)` from outside.

**One-time refactor**: split `crates/app/src/main.rs` into:
- `crates/app/src/lib.rs` — all the implementation; `App` is `pub struct`
- `crates/app/src/main.rs` — `fn main()` only, delegates to `asciirogue::run_main()`

Then in `crates/app/Cargo.toml`:

```toml
[lib]
name = "asciirogue"
path = "src/lib.rs"

[[bin]]
name = "asciirogue"
path = "src/main.rs"
```

You will then need to fix any `pub`/`priv` boundaries. **Globally prefix every top-level item with `pub` via sed** is the brute-force fix when the file is small enough; for larger codebases use `cargo doc --no-deps` to find missing pub's.

## The Cargo example stub

`crates/app/examples/play_probe.rs`:

```rust
//! Headless gameplay probe — drives a deterministic AI bot and prints every
//! state/log for inspection. Use when --dump isn't enough.

use asciirogue::App;
use asciirogue_core::{Ai, Direction, Health, Position, TilePos};

fn main() {
    let seed: u64 = 0xCAFE_BABE_DEAD_BEEF;
    let mut app = App::new(seed);

    // Show initial state — player position, HP, enemy positions.
    show_init_state(&app);

    // Drive 120 turns with a bot that walks toward the nearest enemy.
    for turn in 1..=120 {
        let dir = dir_toward_enemy(&app);
        app.step(dir); // <-- this is your probe API surface
        // After every step, print whatever signals matter.
        println!(
            "[t={:3}] player=({},{}) hp={}  msgs={:?}",
            turn, read_player_pos(&app).0, read_player_hp(&app),
            app.messages()
        );
        if app_is_game_over(&app) {
            println!("=== game over detected at turn {} ===", turn);
            break;
        }
    }
}
```

This requires `App::step`, `App::world_ref`, `App::messages`. Add them to `lib.rs`:

```rust
impl App {
    pub fn step(&mut self, dir: Direction) -> bool {
        self.try_player_act(dir);
        true
    }
    pub fn world_ref(&self) -> &hecs::World { &self.world }
    pub fn messages(&self) -> &[String] { &self.messages }
}
```

## Run it

```bash
cargo run --release --example play_probe
```

No TTY required. Output is grep-friendly. Pipe through `head -50` for a quick look, `grep -E "0 피해|치명타|쓰러|처치"` to find specific signals.

## What it caught in asciirogue

`--dump` passed all tests. `cargo test` was 100% green. The user reported
"the combat loop never ends". `play_probe` revealed the actual sequence:

```
[t= 1~7]  bot moves freely toward first enemy
[t= 8]    enemy enters adjacency and attacks — HP 38
[t= 9~N]  bot stuck against a wall, enemy attacks every turn
```

That's a **runtime gameloop-ordering bug** that `--dump` cannot see: the bot's blocked movement meant `try_player_act` early-returned (no enemy turn), but the test suite passed because the unit tests exercised the enemy_attack function in isolation, not the loop's interaction with `is_passable` false early return. **Only the probe, running the actual loop, showed the symptom.**

## When to reach for this vs --dump

| Symptom | Use |
|---|---|
| "Floor 8 has wrong theme" | `--dump --count 8` |
| "Walls look wrong" | `--dump` then visual diff |
| "Boss doesn't die" | **probe** |
| "Combat log spam" | **probe** |
| "Player can't kill anything" | **probe** |
| "Death doesn't trigger" | **probe + check `app_is_game_over` helper** |
| "Movement feels sticky" | **probe** |
| "Save/load corrupts state" | **probe + deserialize check** |
| "Crash on start" | `cargo run` + capture stderr |

Rule of thumb: if the bug description contains a verb that implies time
("loops", "stuck", "spam", "doesn't end", "every turn"), use the probe.
If it's a static layout/color/symbol issue, `--dump` is enough.

## Anti-patterns

- **Don't try to make `play_probe` "production quality"**. It's a debug
  tool. Hand-rolled, not parameterised. Three lines of grep-friendly
  output beats a pretty CLI.
- **Don't add multiple probe binaries** unless you have multiple
  distinctly different reproductions in flight. One probe per active
  investigation.
- **Don't put the probe in `src/`**. Cargo `examples/` keeps it out of
  the production binary and lets the harness rebuild it on demand.

## Pairing with re0 fixes

After a fix, the same probe script is your regression test. The
progression:

```bash
# 1. user reports "loop never ends"
# 2. you fix code patch v1
cargo build --release --example play_probe
./target/release/examples/play_probe | head -30 # inspect
# 3. probe still shows symptom → patch v2
./target/release/examples/play_probe | head -30 # re-inspect
# 4. probe shows clean gameplay → commit + tag
git commit -am "fix: ..."
git tag -a v0.X.Y -m "..."
```

Tag the patch with the same user quote you used in the commit body. Three
months later, the quote + the probe transcript is the documentation
that survives.

## Related

- `references/cli-loop-integration-testing.md` — the older layer about `--dump` and record/replay. This file supersedes the record/replay section.
- `references/roguelike-feedback-triaging.md` — the methodology for reading the screenshot before fixing. The probe is the implementation of step 5 ("Verify with the actual reproduction path").
