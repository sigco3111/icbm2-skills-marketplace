#!/usr/bin/env python3
"""
Fetch benchmark leaderboards from verified sources and save to /tmp/<tag>.html.

agent-benchmark-tracker/scripts/fetch_leaderboards.py
재실행 가능한 표준 fetch 스크립트. 검증된 소스 6개를 한 번에 받아 디스크에 저장.

사용법:
  python3 /tmp/fetch_leaderboards.py

결과:
  /tmp/lmmarketcap_swe_verified.html
  /tmp/benchlm_swe_verified.html
  /tmp/benchlm_livecodebench.html
  /tmp/benchlm_mmlu_pro.html
  /tmp/benchlm_webarena.html
  /tmp/benchlm_gpqa.html
  /tmp/pp_gpqa.html
  /tmp/pp_gaia.html
  /tmp/pp_aime24.html
  /tmp/pp_aime25.html
  /tmp/morphllm.html
  /tmp/presenc.html
"""
import subprocess, os

UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 15_5) AppleWebKit/537.36"

URLS = {
    "lmmarketcap_swe_verified": "https://lmmarketcap.com/benchmarks/swe_bench_verified",
    "benchlm_swe_verified": "https://benchlm.ai/benchmarks/sweVerified",
    "benchlm_livecodebench": "https://benchlm.ai/benchmarks/liveCodeBench",
    "benchlm_mmlu_pro": "https://benchlm.ai/benchmarks/mmluPro",
    "benchlm_webarena": "https://benchlm.ai/benchmarks/webArena",
    "benchlm_gpqa": "https://benchlm.ai/benchmarks/gpqa",
    "pp_gpqa": "https://pricepertoken.com/leaderboards/benchmark/gpqa",
    "pp_gaia": "https://pricepertoken.com/leaderboards/benchmark/gaia",
    "pp_aime24": "https://pricepertoken.com/leaderboards/benchmark/aime-2024",
    "pp_aime25": "https://pricepertoken.com/leaderboards/benchmark/aime-2025",
    "morphllm": "https://www.morphllm.com/swe-bench-pro",
    "presenc": "https://presenc.ai/research/agentic-benchmark-leaderboard-june-2026",
}


def fetch(tag, url, timeout=30):
    out_path = f"/tmp/{tag}.html"
    try:
        r = subprocess.run(
            ["curl", "-sL", "--max-time", str(timeout), "-A", UA, url, "-o", out_path],
            capture_output=True, text=True, timeout=timeout + 5
        )
        size = os.path.getsize(out_path)
        has_table = size > 1000  # crude heuristic
        print(f"[{tag}] {size:>8} bytes  {'OK' if has_table else 'SMALL'}")
        return size
    except Exception as e:
        print(f"[{tag}] ERROR: {e}")
        return 0


if __name__ == "__main__":
    print("=== Fetching verified leaderboards ===")
    total = 0
    for tag, url in URLS.items():
        sz = fetch(tag, url)
        total += sz
    print(f"\nTotal downloaded: {total} bytes across {len(URLS)} sources")
