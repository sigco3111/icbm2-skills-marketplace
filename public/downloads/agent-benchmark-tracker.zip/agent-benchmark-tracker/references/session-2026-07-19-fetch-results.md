# 2026-07-19 (Sun) KST 세션 fetch 결과 요약

## 검증된 소스별 카운트 / 상태

| 소스 | entry 수 | 비고 |
|------|----------|------|
| benchlm.ai SWE-bench Verified | **58** | 안정 |
| benchlm.ai LiveCodeBench | **6** | 7월 초 20 → 6 슬림화 |
| benchlm.ai MMLU-Pro | **42** | 안정 |
| benchlm.ai GPQA | **71** | 안정 |
| benchlm.ai WebArena | **0** | empty-by-design 확정 |
| benchlm.ai lastUpdated | "July 18, 2026" | 모든 페이지 동일 |
| benchlm.ai reviewedAt | 2026-07-15 ~ 07-18 | curator Glevd |
| lmmarketcap.com SWE-bench Verified | 52 (추정, fetch 됨) | 보조 |
| pricepertoken.com (5개 페이지) | HTML fetch OK, JSON regex 실패 | 보조 reference 용도 |
| morphllm.com/swe-bench-pro | 봇 차단 | Vercel Security Checkpoint |
| presenc.ai/agentic-leaderboard | JS 렌더링 | 본문 추출 불가 |

## 이번 주 DB 신규 15건 분포

| 벤치마크 | count | Tier |
|----------|-------|------|
| SWE-bench Verified | 4 | A×2, B×2 |
| LiveCodeBench | 3 | A×2, D×1 |
| MMLU-Pro | 4 | A×4 |
| GPQA | 4 | S×4 |

## DB 누적 상태

- 기존 145개 → 이번 주 +15 = 160개
- 페이지네이션: 2페이지 (100 + 58), unique (Title||Benchmark) 키 145 → 160
- 가장 최근 기존 등록일: 2026-04-19 (3개월 stale) → 이번 주로 최신화

## 검증된 1건

- **Sakana Fugu — GPQA (page 3a276f2e-9097-816b-a14f-e116fc75b35d):**
  - Title: "Sakana Fugu — GPQA" ✓
  - Date: 2026-07-19 ✓
  - Model: Sakana Fugu ✓
  - Provider: Sakana AI ✓
  - Score: 95.5 ✓
  - Benchmark: GPQA (select) ✓
  - URL: https://benchlm.ai/benchmarks/gpqa ✓
  - 본문 prefix: `[S]` + 한국어 요약 1문장 ✓

## 다음 주 액션 큐

1. morphllm.com 차단 해제 재시도 → SWE-bench Pro 카테고리 채우기
2. WebArena 대안 탐색 (현재 후보 모두 fail) — 신규 모델 vendor 발표 시에만 수동 기록
3. Claude Opus 4.8 / GPT-5.6 / Nemotron 3 Ultra 후속 벤치마크 결과 추적
4. Ornith-1.0-397B (DeepReinforce AI) — LiveCodeBench 명시 수치 부재로 SKIP, 다음 주 확인