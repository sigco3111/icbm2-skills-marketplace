# 검증된 벤치마크 소스 — 운영 노트 (2026-06 기준)

agent-benchmark-tracker 스킬에서 사용하는 4대 통합 소스와 1개 전용 소스의 운영 특성.
점수 분포 차이, 데이터 갱신 주기, fetch 안정성을 세션 경험 기반으로 정리.

## 1. benchlm.ai (⭐ 1순위 — 4개 벤치마크 통합)

**URL 패턴:** `https://benchlm.ai/benchmarks/<slug>`

**커버:** SWE-bench Verified, LiveCodeBench, MMLU-Pro, WebArena, GPQA, Aider, MATH

**URL 슬러그 목록 (검증됨):**
- SWE-bench Verified: `sweVerified` (53 모델)
- LiveCodeBench: `liveCodeBench` (20 모델, rolling 2026 set)
- MMLU-Pro: `mmluPro` (40 모델)
- WebArena: `webArena` (16 모델, Anthropic 모델 독주)
- GPQA: `gpqa` (확인 필요)

**강점:**
- 단일 fetch로 4개 벤치마크의 HTML 테이블을 한 번에 확보
- "Overall" 점수, 컨텍스트 윈도우, "Closed/Open" 모델 가중치 동시 표시
- `mcp_ddg_search_fetch_content`로 안정적 추출 (HTML 정적)

**약점:**
- 모델 수는 중규모 (LiveCodeBench 20개 vs pricepertoken 194개)
- WebArena는 "display only" 표기 — 점수 사용 시 "BenchLM mirror" 출처 명시 권장
- `sweBenchVerified`처럼 camelCase 슬러그 사용 (404 위험) — 반드시 `sweVerified`로 호출

**갱신 주기:** 페이지 하단 "Last updated: June 13, 2026" — 약 주 1회

## 2. pricepertoken.com (⭐ 1순위 — 7개 벤치마크 통합)

**URL 패턴:** `https://pricepertoken.com/leaderboards/benchmark/<slug>`

**커버:** GPQA, GAIA, LiveCodeBench, MMLU-Pro, AIME 2024, AIME 2025, MATH-500, Humanity's Last Exam, IFBench, LCR, Tau2, TerminalBench, SciCode, AGIEval

**URL 슬러그 목록 (검증됨):**
- GPQA: `gpqa` (241 모델, AA 데이터)
- GAIA: `gaia` (11 모델, LayerLens 데이터)
- LiveCodeBench: `livecodebench` (194 모델, AA 데이터)
- MMLU-Pro: `mmlu-pro` (확인 필요)
- AIME 2024/2025: `aime-2024`, `aime-2025`

**강점:**
- 모델 수가 가장 많음 (GPQA 241개, LiveCodeBench 194개)
- 각 모델에 Input $/M / Output $/M 가격 동시 표시
- Artificial Analysis의 raw 데이터 기반 (벤더 비의존)
- Tier 분포, 평균/표준편차 메타 표시

**약점:**
- GAIA는 11개 모델만 (LayerLens 데이터 소스 한정)
- 모델명은 camelCase + 버전 표기 (예: "GPT-5.1-Codex-Mini") — 정규화 필요
- 페이지 첫 fetch 시 JS 일부 누락 가능 → fallback으로 re-fetch

**갱신 주기:** 약 주 1~2회 (페이지 "Last updated" 표시)

## 3. lmmarketcap.com (SWE-bench Verified 특화)

**URL:** `https://lmmarketcap.com/benchmarks/swe_bench_verified`

**강점:**
- SWE-bench Verified 52개 모델의 정확한 resolve rate
- HuggingFace + LMArena 데이터 통합
- 가격/성능 동시 표시
- "Top Model" / "Average Score" / "Models Tested" 메타 헤더

**약점:**
- SWE-bench Verified만 (다른 벤치마크 페이지도 있으나 1순위는 benchlm)
- 상위 25개 위주로 상세 점수 제공, 26위 이하는 score만

**갱신 주기:** 페이지 헤더 "Last updated: 31m ago" — 약 매일

## 4. morphllm.com/swe-bench-pro (SWE-bench Pro 전용 — 유일)

**URL:** `https://www.morphllm.com/swe-bench-pro`

**커버:** SWE-bench Pro (vendor-reported, Scale SEAL 공개셋, Scale SEAL 상업용 비공개 셋)

**강점:**
- **유일한 SWE-bench Pro 신뢰할 수 있는 통합 소스**
- 3가지 평가 환경을 한 페이지에 비교 (vendor / Scale SEAL 공개 / Scale SEAL 상업)
- 95% 신뢰구간 (CI) 표시
- score per dollar (output $/M 대비 점수) 표
- Pro vs Verified 점수 차이 분석 (같은 모델)

**핵심 인사이트 (2026-06):**
- vendor 스캐폴드 80.3% vs Scale SEAL 51.9% — **14~22%p 격차**
- Pro commercial set은 모든 모델 14~47%대로 폭락 (오픈셋 오염 통제)
- 점수 비교 시 반드시 scaffold/셋 출처 명시

**약점:**
- SWE-bench Pro만 (다른 벤치마크는 benchlm/lmmarketcap)

**갱신 주기:** 페이지 "June 9, 2026" — 약 2주 1회

## 5. fallback / 비추천 소스

| URL | 이유 |
|-----|------|
| `swebench.com/verified.html` | JS 렌더링, fetch_content로 데이터 없음 |
| `livecodebench.github.io` | "Loading..."만 반환 |
| `arcprize.org/leaderboard` | JS 렌더링, 정적 fetch 비어있음 |
| `mcp_ddg_search_search` site: 한정자 | HN/Reddit 대부분 빈 결과 |

## 데이터 수집 시 권장 워크플로

```
1단계: benchlm.ai에서 4개 벤치마크를 단일 fetch
2단계: pricepertoken.com에서 GPQA/GAIA 추가 fetch
3단계: morphllm.com에서 SWE-bench Pro만 fetch (vendor vs SEAL)
4단계: lmmarketcap.com에서 SWE-bench Verified 백업 fetch
5단계: 모든 모델+벤치마크 조합을 dict로 정규화
6단계: Notion query_existing()으로 중복 체크
7단계: 신규 항목만 Notion POST
8단계: Telegram 보고에 source URL + 모델 수 명시
```

## 점수 차이 발생 시 우선순위

벤치마크 점수 비교 시 source 신뢰 우선순위:

1. **Scale SEAL 공개/상업 셋** (morphllm.com) — 표준화 scaffold, 직접 비교 가능
2. **Artificial Analysis 데이터** (pricepertoken.com) — 벤더 비의존
3. **benchlm.ai 자체 수집** — 모델 수는 적지만 신뢰할 수 있는 메타
4. **vendor-reported** (lmmarketcap.com 헤더, morphlm vendor 표) — vendor scaffold이므로 직접 비교 불가, 점수 사용 시 명시 필수
