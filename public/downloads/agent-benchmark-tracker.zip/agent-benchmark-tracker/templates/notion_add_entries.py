#!/usr/bin/env python3
"""
Notion DB에 신규 벤치마크 항목을 추가하는 표준 스크립트.

agent-benchmark-tracker 스킬의 templates/notion_add_entries.py 복사본.
사용법:
  1. 이 파일을 /tmp/add_entries.py로 복사
  2. ENTRIES 배열에 이번 주 신규 항목을 채움
  3. python3 /tmp/add_entries.py 실행
  4. 각 항목에 대해 "OK: <page_id>" 또는 "ERROR: <msg>" 출력

특징:
  - auth_header는 f-string으로 구성 (lint 안전)
  - tier는 score에서 자동 계산 후 본문 prefix로 삽입
  - query_existing() 결과를 활용해 중복 자동 스킵 (옵션)
  - Tier 속성은 payload에서 생략 (DB가 url 타입이라 거부)
  - write_file + terminal 패턴 (cron 환경 호환, execute_code 우회)
"""
import os, json, subprocess
from datetime import datetime, timezone, timedelta

TK_PATH = os.path.expanduser("~/.hermes/secrets/notion_token.txt")
DB_ID = "34076f2e-9097-81a0-9314-c781e2742b83"
KST = timezone(timedelta(hours=9))
today = datetime.now(KST).strftime("%Y-%m-%d")

with open(TK_PATH) as f:
    tk = f.read().strip()

# ⚠️ f-string으로 작성 — 큰따옴표 안에 "*** + tk" 리터럴을 두면
# Python lint가 unterminated string literal 오류를 발생시킴
auth_header = f"Authorization: Bearer ***    return f"OK: {resp.get('id', 'no id')}"


def query_existing():
    """DB의 기존 (Title||Benchmark) 키 셋 조회 — 중복 방지용"""
    query_payload = {"page_size": 100}
    with open("/tmp/notion_query.json", "w") as f:
        json.dump(query_payload, f)
    r = subprocess.run(
        ["curl", "-s", "-X", "POST",
         f"https://api.notion.com/v1/databases/{DB_ID}/query",
         "-H", auth_header,
         "-H", "Notion-Version: 2022-06-28",
         "-H", "Content-Type: application/json",
         "-d", "@/tmp/notion_query.json"],
        capture_output=True, text=True
    )
    try:
        result = json.loads(r.stdout)
    except Exception as e:
        return set(), f"PARSE_ERROR: {e} | raw={r.stdout[:200]}"
    if result.get("object") == "error":
        return set(), f"API_ERROR: {result.get('message', '?')[:200]}"
    keys = set()
    for page in result.get("results", []):
        props = page.get("properties") or {}
        title_list = props.get("Name", {}).get("title", []) or []
        title = "".join([t.get("plain_text", "") for t in title_list])
        benchmark_select = props.get("Benchmark")
        benchmark = ""
        if benchmark_select and benchmark_select.get("select"):
            benchmark = benchmark_select["select"].get("name", "")
        if title and benchmark:
            keys.add(title + "||" + benchmark)
    return keys, "OK"


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# ENTRIES: 이번 주 신규 벤치마크 결과를 채워주세요
# 각 dict: title, model, provider, benchmark, score, url, summary
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ENTRIES = [
    # 예시:
    # {
    #     "title": "Claude Fable 5 — SWE-bench Verified",
    #     "model": "Claude Fable 5",
    #     "provider": "Anthropic",
    #     "benchmark": "SWE-bench Verified",
    #     "score": 95.0,
    #     "url": "https://lmmarketcap.com/benchmarks/swe_bench_verified",
    #     "summary": "Anthropic의 Claude Fable 5가 SWE-bench Verified에서 95.0%를 기록했다. "
    #                "Claude Opus 4.8(88.6%) 대비 +6.4%p 상승.",
    # },
]


if __name__ == "__main__":
    print(f"=== {today} 신규 벤치마크 항목 추가 시작 ===")
    print(f"대상 DB: {DB_ID}")
    print(f"항목 수: {len(ENTRIES)}")

    if not ENTRIES:
        print("ENTRIES 배열이 비어있습니다. 종료.")
        raise SystemExit(0)

    # 중복 체크 (선택)
    existing_keys, qstatus = query_existing()
    print(f"기존 DB 항목 수: {len(existing_keys)} (status: {qstatus})")

    results = []
    for i, e in enumerate(ENTRIES, 1):
        # 중복 스킵
        key = e["title"] + "||" + e["benchmark"]
        if key in existing_keys:
            print(f"[{i:2d}/{len(ENTRIES)}] SKIP (중복): {e['title']}")
            results.append((e["title"], "SKIP"))
            continue

        result = add_entry(
            title=e["title"],
            model=e["model"],
            provider=e["provider"],
            benchmark=e["benchmark"],
            score=e["score"],
            url=e["url"],
            summary=e["summary"],
        )
        results.append((e["title"], result))
        print(f"[{i:2d}/{len(ENTRIES)}] {e['title']}: {result}")

    # 결과 요약
    success = sum(1 for _, r in results if r.startswith("OK:"))
    skipped = sum(1 for _, r in results if r == "SKIP")
    failed = len(results) - success - skipped
    print(f"\n=== 완료: 성공 {success}, 스킵 {skipped}, 실패 {failed} / 총 {len(results)} ===")
