---
name: agent-benchmark-tracker
description: AI 에이전트/모델 벤치마크 결과를 추적하여 Notion에 기록 — SWE-bench, HumanEval, GAIA, WebArena, LiveCodeBench 등
version: 1.1.0
author: icbm2
metadata:
  hermes:
    tags: [AI, Benchmark, Agent, Notion, Weekly]
prerequisites:
  secret_files: [notion_token.txt]
support_files:
  - templates/notion_add_entries.py
  - templates/notion_query_existing.py
  - references/verified_sources.md
---

# AI 에이전트 벤치마크 트래커

AI 모델/에이전트의 벤치마크 성능 결과를 주간으로 추적하여 Notion DB에 기록합니다. 코딩, 추론, 에이전트 능력 등 다양한 벤치마크를 종합 관리합니다.

## Notion DB

- **DB ID:** `34076f2e-9097-81a0-9314-c781e2742b83`
- **DB명:** Agent Benchmark Tracker
- **속성:**
  - Name(title): "모델명 — 벤치마크명" (예: "Claude 4 Opus — SWE-bench Verified")
  - Date(date): 결과 발표/업데이트 날짜
  - Model(rich_text): 모델명 (예: Claude 4 Opus, GPT-5, Gemini 2.5 Pro)
  - Provider(rich_text): 제공사 (OpenAI, Anthropic, Google, Meta, Mistral, DeepSeek 등)
  - Benchmark(select): 벤치마크 이름
  - Score(number): 점수 (퍼센트 또는 점수)
  - Tier(url): 성능 등급 — ⚠️ 실제 DB에서 url 타입으로 설정되어 있어 Notion 속성으로 기록 불가. 페이지 본문 상단에 `[S]`, `[A]`等形式으로 표기할 것
  - URL(url): 출처 링크
- **Benchmark 옵션:** SWE-bench Verified, SWE-bench Lite, HumanEval+, LiveCodeBench, GAIA, WebArena, Aider Polyglot, CodeForces, MMLU-Pro, GPQA, ARC-AGI, MATH, **AIME**, Other
- **Tier 등급 기준:** S(90%+), A(80-89%), B(70-79%), C(60-69%), D(<60%)

## 추적 벤치마크 목록

### 코딩 (Coding)
| 벤치마크 | 설명 | 측정 항목 |
|----------|------|----------|
| SWE-bench Verified | 실제 GitHub 이슈 해결 | resolve % |
| SWE-bench Lite | SWE-bench 축약版 | resolve % |
| LiveCodeBench | 라이브 코딩 경진대회 | pass@1 % |
| HumanEval+ | 함수 생성 | pass@1 % |
| Aider Polyglot | 다국어 코드 편집 | % completed |
| CodeForces | 경쟁 프로그래밍 | rating/점수 |

### 추론 (Reasoning)
| 벤치마크 | 설명 | 측정 항목 |
|----------|------|----------|
| GPQA | 대학원 수준 Q&A | 정확도 % |
| MMLU-Pro | 다분야 지식 | 정확도 % |
| ARC-AGI | 추론 능력 | 점수 |
| MATH | 수학 문제 해결 | 정확도 % |
| AIME 2024/2025 | 수학 경시대회 | 점수 |

### 에이전트 (Agent)
| 벤치마크 | 설명 | 측정 항목 |
|----------|------|----------|
| GAIA | 일반 AI 어시스턴트 | 정확도 % |
| WebArena | 웹 자동화 | 성공률 % |
| TAU-bench | 항공/소매 에이전트 | 성공률 % |
| OSWorld | OS 자동화 | 성공률 % |
| RULER | 긴 컨텍스트 이해 | 정확도 % |

## 실행 단계

### 1. 데이터 수집

> ⚠️ **중요:** 공식 리더보드 페이지(swebench.com, livecodebench.github.io)는 JavaScript 기반 렌더링으로 HTML 페치 시 데이터가 비어 있습니다. 반드시 아래 **검증된 소스**를 사용하세요.

#### 검증된 소스 (실제 데이터 확보 가능)

> ⭐ **2026-06 업데이트:** 아래 4개 사이트가 단일 fetch로 4~7개 벤치마크를 한 번에 커버합니다. 우선 시도하세요.

| 벤치마크 | ⭐ 1순위 단일 소스 | 보조 / 백업 |
|----------|---------------------|--------------|
| **SWE-bench Verified** | `https://lmmarketcap.com/benchmarks/swe_bench_verified` (52개 모델, 가격 포함) | `https://benchlm.ai/benchmarks/sweVerified` (53개) |
| **SWE-bench Pro** ⭐신규 | `https://www.morphllm.com/swe-bench-pro` (vendor vs Scale SEAL 비교, 95% CI 포함) | — |
| **LiveCodeBench** | `https://benchlm.ai/benchmarks/liveCodeBench` (rolling 2026, 20개) | `https://pricepertoken.com/leaderboards/benchmark/livecodebench` (194개, AA 데이터) |
| **MMLU-Pro** | `https://benchlm.ai/benchmarks/mmluPro` (40개) | `https://pricepertoken.com/leaderboards/benchmark/mmlu-pro` |
| **GPQA** | `https://pricepertoken.com/leaderboards/benchmark/gpqa` (241개, AA 데이터) | `https://benchlm.ai/benchmarks/gpqa` |
| **GAIA** | `https://pricepertoken.com/leaderboards/benchmark/gaia` (11개, LayerLens) | — |
| **WebArena** | `https://benchlm.ai/benchmarks/webArena` (16개, Anthropic 모델 독주) | `https://presenc.ai/research/agentic-benchmark-leaderboard-june-2026` (종합) |
| **AIME 2024/2025** | `https://pricepertoken.com/leaderboards/benchmark/aime-2024` | `https://pricepertoken.com/leaderboards/benchmark/aime-2025` |
| **ARC-AGI-2** | `https://arcprize.org/leaderboard` (공식, JS 렌더링이지만 fetch로 추출 가능) | — |
| **Terminal-Bench 2.0** | `https://www.tbench.ai/leaderboard` | — |
| **OSWorld** | `https://osworld-benchmark.github.io/` | — |
| **종합** | `https://benchlm.ai/` (247+ 벤치마크) | `https://localaimaster.com/tools/ai-model-leaderboard` |

**4대 통합 소스 (1번 fetch로 다수 벤치마크 커버):**
- **benchlm.ai** — SWE-bench Verified / LiveCodeBench / MMLU-Pro / WebArena / GPQA 일괄
- **pricepertoken.com** — GPQA / GAIA / LiveCodeBench / MMLU-Pro / AIME 2024·2025 / MATH-500 일괄
- **lmmarketcap.com** — SWE-bench Verified + 가격/성능 동시 표시
- **morphllm.com/swe-bench-pro** — SWE-bench Pro (vendor scaffold vs Scale SEAL 표준화 비교표)

**fallback / JS 렌더링으로 fetch_content가 비어있는 사이트:**
- swebench.com (공식) → fetch로 데이터 없음
- livecodebench.github.io (공식) → "Loading..."만 반환
- arcprize.org (공식) → JS 렌더링

#### 데이터 수집 파이프라인

```bash
# 1. benchlm.ai에서 MMLU-Pro + LiveCodeBench + WebArena + SWE-bench Verified를 한 번에
#    mcp_ddg_search_fetch_content로 leaderboard 테이블 전체 확보 가능 (HTML 파싱 불필요)

# 2. pricepertoken.com에서 GPQA + GAIA + LiveCodeBench를 한 번에 (Artificicial Analysis 데이터)

# 3. morphllm.com/swe-bench-pro에서 SWE-bench Pro (vendor vs Scale SEAL 비교) — 유일한 신뢰 소스

# 4. official 리더보드는 JavaScript 렌더링 — fetch_content로 데이터 획득 불가
#    swebench.com/verified.html → 텍스트 설명만, 테이블 없음
#    livecodebench.github.io → "Loading..."만 반환
#    arcprize.org → JS 렌더링, 정적 fetch 비어있음

# 5. search 도구 (mcp_ddg_search_search)는 site: 한정자 사용 시 대부분 실패
#    대신 mcp_ddg_search_fetch_content로 리더보드 페이지를 직접 가져오는 방식
```

#### cron 환경 fetch 워크플로

cron 잡으로 실행 시 `execute_code`는 차단됩니다 (`BLOCKED: cron_mode approvals`). 반드시 다음 패턴 사용:
1. `write_file`로 Python 스크립트 저장 (예: `/tmp/fetch.py`)
2. `terminal`로 `python3 /tmp/fetch.py` 실행
3. 결과를 파일로 저장한 뒤 `read_file`로 읽기

`curl URL | python3` 형태의 파이프는 tirith 보안 스캐너가 차단합니다.

#### 단일 fetch로 다수 벤치마크 수집 예시

```python
# mcp_ddg_search_fetch_content가 가장 안정적 (HTML 직접 fetch)
# 한 번의 fetch로 benchlm.ai/benchmarks/liveCodeBench의 20개 모델 데이터 확보
# → 본문에서 모델명+점수 정규식 추출 → Notion 배치 insert
```

### 2. Notion에 기록

> ⚠️ **cron 환경에서 `execute_code`는 차단됩니다** (`BLOCKED: cron_mode approvals`).
> 모든 Python 처리는 `write_file`로 스크립트 저장 → `terminal`로 실행하세요.
> `curl URL | python3` 파이프도 tirith 보안 스캐너가 차단합니다.

> ⚠️ **토큰 placeholder는 f-string으로:** `auth_header = f"Authorization: Bearer {tk}"` 형태를
> 반드시 사용하세요. `auth_header = "Authorization: Bearer *** + tk"`처럼 큰따옴표 안에
> placeholder 리터럴을 직접 쓰면 Python lint가 `SyntaxError: unterminated string literal`을
> 발생시킵니다 (write_file 단계에서 차단).

**실전에서 검증된 전체 코드는 `templates/notion_add_entries.py`를 복사해 사용하세요.**
해당 템플릿은 다음을 포함합니다:
- `query_existing()` — DB의 기존 (Title||Benchmark) 키 셋 조회 → 중복 방지
- `add_entry(title, model, provider, benchmark, score, url, summary)` — 페이지 생성, tier 자동 계산 후 `[S]/[A]/...` 본문 prefix
- `ENTRY_LIST` — 신규 12개 항목을 정의하는 dict 배열, 실행 시 1개씩 Notion POST
- 모든 subprocess 호출은 `auth_header` 변수를 `-H`로 직접 전달 (f-string)

**실행 패턴:**
```bash
# 1. write_file로 /tmp/add_entries.py에 복사
# 2. python3 /tmp/add_entries.py 실행
# 3. "OK: <page_id>" 또는 "ERROR: <msg>" 출력 확인
# 4. 성공 카운트와 page_id 목록을 텔레그램 보고에 포함
```

```python
import os, json, subprocess
from datetime import datetime, timezone, timedelta

TK_PATH = os.path.expanduser("~/.hermes/secrets/notion_token.txt")
DB_ID = "34076f2e-9097-81a0-9314-c781e2742b83"
today = datetime.now(timezone(timedelta(hours=9))).strftime("%Y-%m-%d")

with open(TK_PATH) as f:
    tk = f.read().strip()

def calc_tier(score):
    if score >= 90: return "S"
    elif score >= 80: return "A"
    elif score >= 70: return "B"
    elif score >= 60: return "C"
    else: return "D"

def add_entry(title, model, provider, benchmark, score, url, summary, tier):
    # ⚠️ Tier 필드는 DB에서 url 타입으로 설정되어 있어 속성 기록 불가 — tier를 본문 앞에 표기
    payload = {
        "parent": {"database_id": DB_ID},
        "properties": {
            "Name": {"title": [{"text": {"content": title}}]},
            "Date": {"date": {"start": today}},
            "Model": {"rich_text": [{"text": {"content": model}}]},
            "Provider": {"rich_text": [{"text": {"content": provider}}]},
            "Benchmark": {"select": {"name": benchmark}},
            "Score": {"number": score},
            "URL": {"url": url}
        },
        "children": [
            {
                "object": "block",
                "type": "paragraph",
                "paragraph": {
                    "rich_text": [{"text": {"content": f"[{tier}] {summary}"}}]
                }
            }
        ]
    }
    with open("/tmp/notion_entry.json", "w") as f:
        json.dump(payload, f, ensure_ascii=False)
    # ⚠️ auth_header는 반드시 별도 변수에 f-string으로 할당 후 사용
    # 큰따옴표 안에 "*** + tk"를 직접 쓰면 write_file의 Python lint가
    # "unterminated string literal" 오류를 발생시킵니다
    auth_header = f"Authorization: Bearer {tk}"
    r = subprocess.run(
        ["curl", "-s", "-X", "POST",
         "https://api.notion.com/v1/pages",
         "-H", auth_header,
         "-H", "Notion-Version: 2022-06-28",
         "-H", "Content-Type: application/json",
         "-d", "@/tmp/notion_entry.json"],
        capture_output=True, text=True, env=env
    )
    resp = json.loads(r.stdout)
    if resp.get("object") == "error":
        return f"ERROR: {resp.get('message', 'unknown')[:100]}"
    return f"OK: {resp.get('id', 'no id')}"

def query_existing():
    """Notion DB에서 기존 항목 조회 (중복 확인용)"""
    query_payload = {"page_size": 100}
    auth_header = f"Authorization: Bearer ***    r = subprocess.run(
        ["curl", "-s", "-X", "POST",
         f"https://api.notion.com/v1/databases/{DB_ID}/query",
         "-H", auth_header,
         "-H", "Notion-Version: 2022-06-28",
         "-H", "Content-Type: application/json",
         "-d", json.dumps(query_payload)],
        capture_output=True, text=True, env=env
    )
    result = json.loads(r.stdout)
    existing = []
    if "results" in result:
        for page in result["results"]:
            props = page.get("properties") or {}
            title_list = props.get("Name", {}).get("title", []) or []
            title = "".join([t.get("plain_text", "") for t in title_list])
            benchmark_select = props.get("Benchmark")
            if benchmark_select and benchmark_select.get("select"):
                benchmark = benchmark_select["select"].get("name", "")
            else:
                benchmark = ""
            if title and benchmark:
                existing.append(title + "||" + benchmark)
    return existing

# 사용 예시
result = add_entry(
    title="Claude 4 Opus — SWE-bench Verified",
    model="Claude 4 Opus",
    provider="Anthropic",
    benchmark="SWE-bench Verified",
    score=72.5,
    url="https://www.swe-bench.com/",
    summary="Anthropic Claude 4 Opus가 SWE-bench Verified에서 72.5%를 기록했다.",
    tier="B"
)
print(result)  # OK: page_id 또는 ERROR: message
```

### 3. 품질 기준

- **최소 5개, 최대 15개** 항목 기록 (주간)
- 최근 1주일간 발표/업데이트된 결과만 포함
- 반드시 Score와 Tier를 계산하여 기입
- 각 항목에 1-2문장 요약을 페이지 본문에 추가:
  - 어떤 변화가 있었는지 (새 기록, 개선폭, 이전 모델 대비 등)
  - 의미 있는 인사이트
- **URL 속성은 항상 기록** (공식 리더보드, 논문, 발표 페이지)
- 한국어로 작성
- 이미 기록된 모델+벤치마크 조합은 갱신하지 않음 (신규 결과만)

### 4. 주간 요약 (페이지 본문)

모든 항목 기록 후, 주간 트렌드 요약을 작성:
- 이번 주 가장 큰 성과를 낸 모델
- 가장 큰 점프를 기록한 벤치마크
- 새로 등장한 벤치마크나 평가 방식
- 코딩/추론/에이전트 분야별 순위 변동

## 스케줄

- **크론:** 매주 일요일 09:00 KST
- **delivery:** origin (Telegram)

## 참고

- ai-model-tracker 스킬과 보완 관계 (모델 트래커는 출시/업데이트, 벤치마크 트래커는 성능 결과)
- 점수 비교 시 동일 조건(pass@1, few-shot 수 등) 확인 필수

## ⚠️ 흔한 함정

**Tier 필드 에러:** DB의 Tier 필드는 `url` 타입으로 설정되어 있어 `{"select": {"name": tier}}`를 사용하면 `validation_error`가 발생합니다. Tier 값은 항상 페이지 본문 상단에 `[S]` / `[A]`等形式으로 표기하고, Tier 속성은 payload에서 생략하세요.

**토큰 경로:** `os.environ["NOTION_TOKEN_PATH"]`가 아닌 `os.path.expanduser("~/.hermes/secrets/notion_token.txt")`을 사용하세요.

**신규 삽입 전 검증:** 동일한 모델+벤치마크 조합이 이미 존재하는지 DB를 먼저 쿼리(`POST /databases/{id}/query`)하여 중복을 방지하세요. 기록된 조합은 갱신하지 않고 신규 결과만 추가합니다.

**LiveCodeBench 버전 주의:** `benchlm.ai`는 LiveCodeBench rolling 2026 set (20개), `pricepertoken.com`은 194개 (Artificial Analysis 데이터) — 두 소스의 점수 분포가 다릅니다. DB 기록 시 source URL에 버전/셋 정보 포함.

**vendor vs Scale SEAL SWE-bench Pro 격차:** 같은 모델이라도 스캐폴드에 따라 14~22%p 차이가 납니다.
- vendor-reported (Anthropic 자체 scaffold, Claude Fable 5): **80.3%**
- Scale SEAL 공개셋 (Opus 4.6 thinking): **51.9%**
- Scale SEAL 상업용 비공개 셋 (Opus 4.6 thinking): **47.1%**

→ Notion 기록 시 본문 summary에 "vendor scaffold" / "Scale SEAL 공개셋" / "Scale SEAL 상업용" 출처를 명시하세요. URL 필드도 `https://www.morphllm.com/swe-bench-pro`로 통일.

**검색 도구 제한:** DuckDuckGo MCP (`mcp_ddg_search_search`)는 `site:news.ycombinator.com`, `site:reddit.com` 등 사이트 한정 검색 시 대부분의 경우 빈 결과를 반환합니다. 벤치마크 데이터는 항상 `mcp_ddg_search_fetch_content`로 리더보드 페이지를 직접 가져오는 방식으로 수집하세요.

**tirith 보안 스캐너:** `curl URL | python3` 형태의 파이프 명령은 tirith 보안 스캐너가 차단합니다. 모든 데이터 처리는 Python 파일(`write_file`) 또는 별도 `.py` 스크립트로 분리하여 실행하세요. `write_file`로 스크립트를 저장한 뒤 `terminal`로 `python3 /path/script.py` 실행.

**cron 환경의 execute_code 차단:** cron 잡으로 실행 시 `execute_code`는 `BLOCKED: cron_mode approvals` 오류로 차단됩니다. 반드시 `write_file` + `terminal` 패턴 사용. 인라인 Python `subprocess.run`은 피하세요.

**Python lint의 placeholder string:** `auth_header = "Authorization: Bearer *** + tk"` 형태로 큰따옴표 안에 placeholder 리터럴을 쓰면 `write_file` 단계의 Python lint가 `SyntaxError: unterminated string literal`을 발생시킵니다. 반드시 f-string 사용: `auth_header = f"Authorization: Bearer ***`.

**DB 쿼리 페이지 크기:** `POST /databases/{id}/query`는 `page_size: 100`이 최대. 100개 이상이면 `start_cursor`로 페이지네이션 필요. 현재 DB는 100+ 항목이라 단일 쿼리로는 일부 누락 가능 — 신규 insert 후 재쿼리로 검증.

**2026-06 기준 신규 모델명:** Claude Fable 5, Claude Mythos 5, GPT-5.5 / 5.5 Pro, GPT-5.4 Pro, Gemini 3.5 Flash, Muse Spark, Qwen3.7 Max / Plus, DeepSeek V4 Pro Max, GLM-5/5.1. 기존 DB의 `Other` provider 옵션에 `Anthropic`이 없으면 추가 필요.
