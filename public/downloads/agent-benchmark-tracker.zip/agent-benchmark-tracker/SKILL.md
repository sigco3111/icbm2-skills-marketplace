---
name: agent-benchmark-tracker
description: AI 에이전트/모델 벤치마크 결과를 추적하여 Notion에 기록 — SWE-bench, HumanEval, GAIA, WebArena, LiveCodeBench 등
version: 1.0.0
author: icbm2
metadata:
  hermes:
    tags: [AI, Benchmark, Agent, Notion, Weekly]
prerequisites:
  secret_files: [notion_token.txt]
---

# AI 에이전트 벤치마크 트래커

AI 모델/에이전트의 벤치마크 성능 결과를 주간으로 추적하여 Notion DB에 기록합니다. 코딩, 추론, 에이전트 능력 등 다양한 벤치마크를 종합 관리합니다.

## Notion DB

- **DB ID:** `34076f2e-9097-81a0-9314-c781e2742b83`
- **DB명:** Agent Benchmark Tracker
- **속성:**
  - Name(title): "모델명 — 벤치마크명" (예: "Claude 4 Opus — SWE-bench Verified")
  - Date(date): 결과 발표/업데이트 날짜
  - Model(rich_text): 모델명 (예: Claude 4 Opus, GPT-5, Gemini 2.5 Pro)
  - Provider(rich_text): 제공사 (OpenAI, Anthropic, Google, Meta, Mistral, DeepSeek 등)
  - Benchmark(select): 벤치마크 이름
  - Score(number): 점수 (퍼센트 또는 점수)
  - Tier(select): 성능 등급 (S/A/B/C/D)
  - URL(url): 출처 링크
- **Benchmark 옵션:** SWE-bench Verified, SWE-bench Lite, HumanEval+, LiveCodeBench, GAIA, WebArena, Aider Polyglot, CodeForces, MMLU-Pro, GPQA, ARC-AGI, MATH, Other
- **Tier 옵션:** S(90%+), A(80-89%), B(70-79%), C(60-69%), D(<60%)

## 추적 벤치마크 목록

### 코딩 (Coding)
| 벤치마크 | 설명 | 측정 항목 |
|----------|------|----------|
| SWE-bench Verified | 실제 GitHub 이슈 해결 | resolve % |
| SWE-bench Lite | SWE-bench 축약版 | resolve % |
| LiveCodeBench | 라이브 코딩 경진대회 | pass@1 % |
| HumanEval+ | 함수 생성 | pass@1 % |
| Aider Polyglot | 다국어 코드 편집 | % completed |
| CodeForces | 경쟁 프로그래밍 | rating/점수 |

### 추론 (Reasoning)
| 벤치마크 | 설명 | 측정 항목 |
|----------|------|----------|
| GPQA | 대학원 수준 Q&A | 정확도 % |
| MMLU-Pro | 다분야 지식 | 정확도 % |
| ARC-AGI | 추론 능력 | 점수 |
| MATH | 수학 문제 해결 | 정확도 % |
| AIME 2024/2025 | 수학 경시대회 | 점수 |

### 에이전트 (Agent)
| 벤치마크 | 설명 | 측정 항목 |
|----------|------|----------|
| GAIA | 일반 AI 어시스턴트 | 정확도 % |
| WebArena | 웹 자동화 | 성공률 % |
| TAU-bench | 항공/소매 에이전트 | 성공률 % |
| OSWorld | OS 자동화 | 성공률 % |
| RULER | 긴 컨텍스트 이해 | 정확도 % |

## 실행 단계

### 1. 데이터 수집

다음 소스에서 최신 벤치마크 결과 수집:

```bash
# 공식 리더보드
# SWE-bench: https://www.swe-bench.com/
# LiveCodeBench: https://livecodebench.github.io/
# LMSYS Chatbot Arena: https://chat.lmsys.org/

# 모델 발표/논문
# HN 검색: benchmark results AI model
# Arxiv: cs.AI, cs.CL, cs.SE 최신 논문
# Reddit: r/LocalLLaMA, r/MachineLearning

# 각 제공사 공식 블로그/기술 보고서
```

### 2. Notion에 기록

```python
import os, json, subprocess
from datetime import datetime, timezone, timedelta

TK_PATH = os.environ["NOTION_TOKEN_PATH"]
DB_ID = "34076f2e-9097-81a0-9314-c781e2742b83"
today = datetime.now(timezone(timedelta(hours=9))).strftime("%Y-%m-%d")

with open(TK_PATH) as f:
    tk = f.read().strip()

def calc_tier(score):
    if score >= 90: return "S"
    elif score >= 80: return "A"
    elif score >= 70: return "B"
    elif score >= 60: return "C"
    else: return "D"

def add_entry(title, model, provider, benchmark, score, url):
    tier = calc_tier(score)
    payload = {
        "parent": {"database_id": DB_ID},
        "properties": {
            "Name": {"title": [{"text": {"content": title}}]},
            "Date": {"date": {"start": today}},
            "Model": {"rich_text": [{"text": {"content": model}}]},
            "Provider": {"rich_text": [{"text": {"content": provider}}]},
            "Benchmark": {"select": {"name": benchmark}},
            "Score": {"number": score},
            "Tier": {"select": {"name": tier}},
            "URL": {"url": url}
        },
        "children": [
            {
                "object": "block",
                "type": "paragraph",
                "paragraph": {
                    "rich_text": [{"text": {"content": "요약 내용을 여기에 작성"}}]
                }
            }
        ]
    }
    with open("/tmp/notion_entry.json", "w") as f:
        json.dump(payload, f, ensure_ascii=False)
    env = dict(os.environ)
    env["NTK"] = tk
    r = subprocess.run(
        f'curl -s -X POST --max-time 15 https://api.notion.com/v1/pages -H "Authorization: Bearer $NTK" -H "Notion-Version: 2022-06-28" -H "Content-Type: application/json" -d @/tmp/notion_entry.json',
        shell=True, capture_output=True, text=True, env=env
    )
    return r.stdout

# 사용 예시
add_entry(
    title="Claude 4 Opus — SWE-bench Verified",
    model="Claude 4 Opus",
    provider="Anthropic",
    benchmark="SWE-bench Verified",
    score=72.5,
    url="https://www.swe-bench.com/"
)
```

### 3. 품질 기준

- **최소 5개, 최대 15개** 항목 기록 (주간)
- 최근 1주일간 발표/업데이트된 결과만 포함
- 반드시 Score와 Tier를 계산하여 기입
- 각 항목에 1-2문장 요약을 페이지 본문에 추가:
  - 어떤 변화가 있었는지 (새 기록, 개선폭, 이전 모델 대비 등)
  - 의미 있는 인사이트
- **URL 속성은 항상 기록** (공식 리더보드, 논문, 발표 페이지)
- 한국어로 작성
- 이미 기록된 모델+벤치마크 조합은 갱신하지 않음 (신규 결과만)

### 4. 주간 요약 (페이지 본문)

모든 항목 기록 후, 주간 트렌드 요약을 작성:
- 이번 주 가장 큰 성과를 낸 모델
- 가장 큰 점프를 기록한 벤치마크
- 새로 등장한 벤치마크나 평가 방식
- 코딩/추론/에이전트 분야별 순위 변동

## 스케줄

- **크론:** 매주 일요일 09:00 KST
- **delivery:** origin (Telegram)

## 참고

- ai-model-tracker 스킬과 보완 관계 (모델 트래커는 출시/업데이트, 벤치마크 트래커는 성능 결과)
- 점수 비교 시 동일 조건(pass@1, few-shot 수 등) 확인 필수
