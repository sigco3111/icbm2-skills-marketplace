---
name: ci-failure-alert-triage
description: Use when a CI failure alert arrives. Bug, outage, or noise.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [CI, GitHub-Actions, outage, triage, alerting, false-alarm, verification]
    related_skills: [github-cli, cron-stale-triage, automation-healthcheck]
---

# CI Failure Alert Triage

Triggers on a forwarded CI/deploy failure alert — email, webhook, or pasted notification —
where you must decide what is actually true before acting.

A failure alert is a **claim**, not evidence. Before touching any workflow file, establish
which of three things happened:

| Verdict | Signature | Correct action |
|---|---|---|
| **Repo bug** | One repo, failure inside a step the repo authored, recent commit | Fix it — see `github-cli` §6.9 / `references/ci-troubleshooting.md` |
| **Platform outage** | Multiple unrelated repos, same narrow window, failure in a platform-managed step | Change nothing, wait, tell the user why |
| **Phantom / duplicate** | Alert count exceeds actual failure count in run history | Surface the discrepancy with counts |

The expensive mistakes run both directions: burning a session "fixing" a healthy workflow,
or telling the user to wait while a real bug ships. This skill exists because the default
instinct — open the YAML and start reading — is wrong for two of the three verdicts.

**Related:** `github-cli` §6.9 covers repo-side CI failures (the first row). This skill
covers the other two rows and the routing decision. `cron-stale-triage` is the ICBM2-cron
equivalent of the phantom-alert branch.

---

## Step 1 — Do not trust the alert's framing

Extract the falsifiable claims from what the user forwarded: which repos, which workflows,
which commits, and **how often / how long**. Frequency claims ("3일째 여러 차례", "it keeps
failing") are the ones most often wrong, and they change the diagnosis completely.

Ask for the run ID or link if the alert has one. It settles duplicate-vs-new instantly.

## Step 2 — Check platform status before reading any YAML

Cheap, unauthenticated, and it reorders everything downstream. Do this **first** whenever
more than one repo is implicated, or a scheduled job that has been green for weeks fails
with no intervening commit.

```bash
curl -s https://www.githubstatus.com/api/v2/summary.json | python3 -c "
import json,sys
d=json.load(sys.stdin)
for c in d['components']:
    if c['name'] in ('Actions','Pages','API Requests','Webhooks','Git Operations'):
        print(f\"{c['name']:16} {c['status']}\")
print('--- incidents ---')
for i in d['incidents'][:5]:
    print(f\"{i['created_at'][:16]}  [{i['status']}] {i['name']}\")
"
```

If anything is not `operational`, pull the update history — the bodies name the exact broken
subsystem and tell you whether recovery has started. See
`references/platform-outage-triage.md` §2 for that query and how to read incident status.

Non-GitHub equivalents: `https://www.vercel-status.com/api/v2/summary.json`,
`https://status.npmjs.org/api/v2/summary.json`, and most Statuspage-hosted services expose
the same `/api/v2/summary.json` shape.

## Step 3 — Read the failure at the right layer

```bash
gh run view <RUN_ID> -R owner/repo                      # ANNOTATIONS = the real reason
gh run view <RUN_ID> -R owner/repo --log-failed | tail -40
```

**If `--log-failed` prints nothing, that is the diagnosis, not a tool failure** — the job
never got a runner, so no step existed to fail. Fall back to the annotation and report it.
Never tell the user "no logs available."

Platform-side signatures (no repo fix exists for any of these) are tabulated in
`references/platform-outage-triage.md` §3.

## Step 4 — Correlate across repos

The decisive evidence is distribution. Failures clustered in **one window across unrelated
repos** = platform. Failures concentrated in **one repo across days** = that repo.

Run the scan as a bash script via `terminal`, not `execute_code` — see Pitfalls.
`scripts/gh-failure-scan.sh` does it end to end.

## Step 5 — Verify the user's premise against the data

When run history contradicts the user's description, do not silently accept it and do not
silently drop it. Check the places a failure can hide before concluding:

- all failures, not just the default workflow view (`gh run list --status failure -L 100`)
- automatic retries inside one run (`run_attempt`)
- environment deployments with no obvious workflow row (`/deployments?environment=...`)
- similarly-named sibling repos the user may be conflating

Queries for each are in `references/platform-outage-triage.md` §7. Then **state the
discrepancy with counts**, name the most likely explanation, and ask for the detail that
settles it. Duplicate notification emails are common during outages — webhook retries
re-fire the same alert.

## Step 6 — Recommend waiting, and say what "recovered" will look like

During a capacity-constrained outage, `gh run rerun` deepens the queue and usually times out
again. Recommend waiting unless the user needs a specific artifact urgently.

**Absence of runs is also a symptom.** Throttled webhooks mean push/schedule events create
no run at all, so "no new failures" ≠ recovered. Check whether the expected cadence is still
firing and tell the user "not running" rather than letting silence read as "fixed."

## Reporting

Lead with the verdict and the evidence that fixes it — a status-page component state, or a
count across repos. Give the user a table mapping each alert to its cause when there are
several. Quote the one terminal error line; never paste a polling loop's full log dump.
State plainly that no code change is needed when that is the finding.

---

## Pitfalls

1. **Reading workflow YAML first.** For two of three verdicts it is wasted work. Status
   check is one curl and reorders the whole investigation.
2. **`--log-failed` empty ≠ tool broken.** It is the signature of a job that never started.
   Read `gh run view` annotations.
3. **`execute_code` caps at 50 tool calls.** A loop calling `terminal()` per repo dies
   partway through a multi-repo scan, having already burned the budget. Use one bash script.
4. **`terminal()` inside `execute_code` can return a dict with no `output` key** on non-zero
   exit; `r["output"]` raises `KeyError`. Use `r.get("output", "")`.
5. **"No new failures" ≠ recovered** when webhooks are throttled (Step 6).
6. **Incident `status: investigating` can coexist with partial recovery.** Read the newest
   update body, not the status field alone.
7. **A green sibling day disproves "always broken", not "broken now".** Scope every claim to
   the window you actually queried.
8. **Correlate in UTC.** `gh --json createdAt` and status-page timestamps are both UTC; the
   user's email timestamps are local. Convert once, at the end, for the user.
9. **`actions/deploy-pages` 404 ≠ platform outage.** Per-repo Pages toggle defaults to off;
   if the alert mentions Pages + 404, check `gh api repos/<owner>/<repo>/pages` (404 = off)
   before assuming GitHub is broken. See `references/platform-outage-triage.md` §9 for the
   diagnosis + gh-pages branch fallback + REST API to enable Pages.
10. **`peaceiris/actions-gh-pages` push 403 = missing `contents: write`.** Default
    `GITHUB_TOKEN` is `contents: read` only; the gh-pages push step needs
    `permissions: contents: write` at the workflow top. Same trap applies to any
    branch-pushing action.

## Reference files

- `references/platform-outage-triage.md` — status-API queries, platform-side failure
  signatures, cross-repo scan, premise-verification queries, verified 2026-08-06 GitHub
  Actions/Pages outage transcript
- `scripts/gh-failure-scan.sh` — cross-repo failure distribution scan (date + repo histogram)
