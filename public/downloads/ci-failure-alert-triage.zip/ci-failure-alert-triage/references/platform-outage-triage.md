# Platform Outage vs. Repo Bug — Detail Reference

Companion to `SKILL.md`. Verified live during the 2026-08-06 GitHub Actions/Pages major
outage (incident `qcvjkzcs7j74`).

---

## 1. When to suspect the platform first

Check platform health **before** reading workflow YAML if any of these hold:

- **Multiple unrelated repos failed in the same window.** The single strongest signal.
- The failing workflows **succeeded on their previous run with no intervening commit**
  (scheduled jobs and `pages build and deployment` make this easy to confirm).
- The failure is in a **platform-managed step**, not a step the repo authored — runner
  acquisition, `actions/deploy-pages` queueing, artifact upload.
- `gh run view --log-failed` returns **empty output** (see §3).

Conversely, if exactly one repo fails and it changed recently, treat it as a normal repo bug
and route to `github-cli` §6.9 / its `references/ci-troubleshooting.md`.

---

## 2. Query GitHub status (no auth, no rate limit)

Two endpoints. `summary.json` for current state, `incidents.json` for the update history
that tells you what is actually broken.

Component status values: `operational`, `degraded_performance`, `partial_outage`,
`major_outage`. Incident `status`: `investigating` → `identified` → `monitoring` → `resolved`.

**An incident stays `investigating` while partially mitigated.** Do not read
"still investigating" as "nothing fixed yet" — read the latest update body.

```bash
# Full update history — the update bodies name the exact broken subsystem
curl -s https://www.githubstatus.com/api/v2/incidents.json | python3 -c "
import json,sys,re
d=json.load(sys.stdin)
for i in d['incidents'][:3]:
    print(f\"### {i['name']} ({i['impact']}) / {i['status']}\")
    for u in reversed(i['incident_updates']):
        body=re.sub('<[^>]+>','',u['body'])
        print(f\"  [{u['created_at'][:19]}] {u['status']}: {body[:280]}\")
    print()
"
```

Strip HTML from `body` — GitHub embeds literal `<br />` tags in incident text.

**Timezone:** status API timestamps are UTC and `gh run list --json createdAt` is also UTC
(`Z`-suffixed), so they compare directly. The user's email timestamps are local. Correlate
in UTC, then translate for the user.

---

## 3. Platform-side failure signatures, and the empty-log tell

| Log / annotation | Meaning | Repo-side fix? |
|---|---|---|
| `The job was not acquired by Runner of type hosted even after multiple attempts` | Hosted runner capacity exhausted; job never started | **No** |
| `Current status: deployment_queued` looping → `Timeout reached, aborting!` | Pages deploy queue stalled; `actions/deploy-pages` gave up (~10 min default) | **No** |
| `Canceled deployment with ID <sha>` right after the timeout | Consequence of the above, not a separate fault | **No** |
| Runners register but receive jobs that are no longer valid | Platform-side job assignment bug (named in the 2026-08-06 incident) | **No** |
| `Creating Pages deployment failed` → `HttpError: Not Found` → `Failed to create deployment (status: 404)` in `actions/deploy-pages@v5` | **Pages not enabled on the repo.** `gh api repos/<owner>/<repo>/pages` returns 404. Sphinx build itself succeeded. | **Repo-side** — not platform outage. Enable Pages (UI or API), or switch to gh-pages branch deploy (§9). |
| `Permission to <owner>/<repo>.git denied to github-actions[bot]` / 403 when pushing to `gh-pages` | `peaceiris/actions-gh-pages@v4` push lacked `contents: write`; default `GITHUB_TOKEN` is `read`-only | **Repo-side** — add `permissions: contents: write` at workflow top, or use a PAT with `repo` scope |

**The empty-log tell.** When a job never gets a runner, `gh run view <id> --log-failed`
prints **nothing** — there were no steps to fail. This reads as "the command broke" but it
is itself the diagnosis. Fall back to the annotation:

```bash
gh run view <RUN_ID> -R owner/repo            # ANNOTATIONS section carries the real reason
gh run view <RUN_ID> -R owner/repo --log-failed | tail -40   # empty => infra-level failure
```

Always run the plain `gh run view` when `--log-failed` comes back empty.

---

## 4. Cross-repo correlation scan

Loop in **bash**, not `execute_code` (see SKILL.md Pitfalls 3–4).
`scripts/gh-failure-scan.sh` is the packaged version; inline equivalent:

```bash
gh repo list <owner> -L 300 --json name,pushedAt -q 'sort_by(.pushedAt)|reverse|.[].name' > /tmp/_repos.txt

: > /tmp/_fails.tsv
n=0
while read -r name; do
  n=$((n+1)); [ "$n" -gt 80 ] && break
  gh run list -R "<owner>/$name" -L 30 --status failure \
    --json databaseId,name,createdAt,event \
    -q ".[] | select(.createdAt > \"<since>\") | \"$name\t\(.createdAt)\t\(.event)\t\(.name)\"" \
    2>/dev/null >> /tmp/_fails.tsv
done < /tmp/_repos.txt

cut -f2 /tmp/_fails.tsv | cut -c1-10 | sort | uniq -c | sort -k2   # by date
cut -f1 /tmp/_fails.tsv | sort | uniq -c | sort -rn                 # by repo
```

Reading it: failures **clustered into one narrow window across unrelated repos** = platform.
Failures **concentrated in one repo across days** = that repo's bug.

---

## 5. Absence of runs is also a symptom

During capacity recovery GitHub throttles webhook delivery (the 2026-08-06 incident
processed ~15% of webhooks). Push and schedule events then **never create a run at all**.

So "no new failures since the outage started" does **not** mean recovered. Check whether the
expected cadence is still firing:

```bash
gh run list -R owner/repo -L 10 --json createdAt,name,conclusion \
  -q '.[] | "\(.createdAt)  \(.conclusion)  \(.name)"'
# A job that runs every 3h with a 6h gap is being throttled, not passing.
```

Tell the user "not running" rather than letting silence read as "fixed".

---

## 6. Do not retry during a capacity-constrained outage

`gh run rerun` while runners are exhausted deepens the queue and usually times out again.
Recommend waiting; scheduled and push-triggered jobs self-recover once webhooks un-throttle.
Reserve manual reruns for after `status: resolved`, or when the user needs a specific
artifact urgently.

---

## 7. Verify the user's premise — where a failure can hide

```bash
# a) all failures, not just the default workflow view
gh run list -R owner/repo -L 100 --status failure \
  --json databaseId,name,createdAt,event -q '.[] | "\(.createdAt)\t\(.event)\t\(.name)"'

# b) automatic retries hidden inside one run
gh api repos/owner/repo/actions/runs/<RUN_ID> -q '{attempt:.run_attempt,concl:.conclusion}'

# c) environment deployments — a Pages deploy can fail without an obvious workflow row
gh api "repos/owner/repo/deployments?environment=github-pages&per_page=15" \
  -q '.[] | "\(.created_at)\t\(.sha[0:7])\t\(.id)"'
gh api "repos/owner/repo/deployments/<DEPLOY_ID>/statuses?per_page=1" -q '.[0].state'

# d) similarly-named sibling repos the user may be conflating
gh repo list <owner> -L 300 --json name -q '.[] | select(.name|test("<fragment>";"i")) | .name'

# e) which workflows even exist in the repo
gh workflow list -R owner/repo -a
```

`deployments/<id>/statuses[0].state` values: `success`, `failure`, `in_progress`, and
`inactive` — **`inactive` is normal**, it just means a later deploy superseded it. Do not
report `inactive` as a problem.

Then state the discrepancy with counts, offer the most likely explanation (duplicate
notification emails are common during outages, since webhook retries re-fire), name any
sibling repo that better fits the description, and ask for the run ID or email timestamps to
settle it.

---

## 8. Verified case — 2026-08-06 GitHub Actions/Pages outage

User forwarded three alerts across three repos and reported one of them ("icbm2-knowledge-graph")
had been failing for three days.

**What the data showed:**

| Repo | Workflow | Failure | Signature |
|---|---|---|---|
| `Repolis` | Traffic refresh (schedule) | 17:52Z | `job was not acquired by Runner of type hosted`, 15m1s |
| `icbm2-skills-marketplace` | Deploy to GitHub Pages (push) | 18:04Z | same, build 15m1s → deploy skipped |
| `icbm2-knowledge-graph` | pages build and deployment | 12:00Z | `deployment_queued` ×~30 → `Timeout reached, aborting!` |

Status API at investigation time: `Actions: major_outage`, `Pages: major_outage`, incident
open since 15:22Z, latest update naming "runners being assigned jobs that are no longer
valid" and webhook throttling to ~15%.

**The three-day claim did not hold.** Cross-checks that disproved it:
- `gh run list --status failure -L 100` → only failure was 2026-08-06; prior failures were April.
- Pages deploys on 08-05, 08-04, 08-03 were all `success`.
- `run_attempt = 1` — not even an automatic retry.
- 80-repo scan, 08-03 onward → 11 failures total, KG accounted for exactly 1.
- A sibling repo (`hermes-control-room`) had **5 failures on 08-04, four within 38 minutes** —
  a much better fit for "repeatedly, over days", and worth naming to the user.

**Correct output:** all three were the same platform outage; no code change needed; do not
rerun while capacity is constrained; state the premise mismatch with counts and ask for the
run ID / email timestamps.

**Follow-up in the same session:** the user surfaced a news article, which resolved to a
Hacker News post pointing at `githubstatus.com/incidents/qcvjkzcs7j74` — the identical
incident. External corroboration of a conclusion already reached from the status API; it
changed nothing, and saying so plainly was the right response.

The article's line that Pages "정상화와 재저하가 반복" (recovered and re-degraded repeatedly)
also explained the KG pattern: a single deploy caught in one bad window while adjacent days
stayed green. Worth noting — an oscillating platform component produces isolated failures
that look like flaky repo config.

**Site-fetch note from that follow-up:** the news URL was a Cloudflare-protected SPA, so
`curl` returned only a shell with placeholder `og:` meta tags (`news.example.com`) and no
article text. The content came from the site's own JSON endpoint at `/api/articles/<id>`
(found by trying `/api/news/<id>` → HTML, then `/api/articles/<id>` → JSON). When a SPA
returns no body text, probe sibling API paths before giving up; and do not report a
placeholder `og:title` as the page's real content.

---

## 9. Pages disabled — the most-misdiagnosed "404" failure

Distinct from the platform outage signatures above. Same-looking 404, completely different
fix.

**Signature:** `actions/deploy-pages@v5` step fails with

```
Creating Pages deployment failed
HttpError: Not Found
Failed to create deployment (status: 404) with build version <sha>.
  Request ID <...>
  Ensure GitHub Pages has been enabled: https://github.com/<owner>/<repo>/settings/pages
```

**Diagnosis (before assuming Pages is on):**

```bash
gh api repos/<owner>/<repo>/pages
# 404 Not Found → Pages not enabled. Stop here, do not read workflow YAML.
# {"source": {...}, ...} → Pages enabled; the 404 has another cause.
```

**Why this gets misdiagnosed as a platform outage:** the alert text says "Pages deploy
failed", the error mentions `404`, and Pages is a GitHub-managed feature — so the default
instinct is "GitHub is broken." It isn't. Pages is a **per-repo toggle** that defaults to
**off** on every new repo. The workflow can be 100% correct and still 404 at this step.

**Three fixes (pick by context):**

| Approach | When to use | What you change |
|---|---|---|
| **UI toggle** | One repo, one-off, no automation needed | Settings → Pages → Source: `Deploy from a branch` → Branch: `gh-pages` / `(root)` → Save |
| **REST API** | Owning the repo + wanting to automate (e.g. cron seeding many repos) | `gh api -X POST repos/<owner>/<repo>/pages -f source[branch]=gh-pages -f source[path]=/` — fine-grained PAT needs `pages:write`; classic PAT or `repo` scope works |
| **Switch to gh-pages branch deploy** | Repo should publish HTML even if Pages stays off, or you don't have `pages:write` | Replace the `actions/deploy-pages` step with `peaceiris/actions-gh-pages@v4` pointing at `gh-pages`. Push itself succeeds; only the public URL stays 404 until Pages is enabled |

**gh-pages workflow template (the third option):**

```yaml
permissions:
  contents: write        # default GITHUB_TOKEN is read-only; this is the #1 pitfall

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@<sha>
      - uses: actions/setup-python@<sha>
        with: {python-version: "3.12"}
      - run: pip install -r docs/requirements.txt
      - run: sphinx-build docs docs/_build/html
      - uses: peaceiris/actions-gh-pages@<sha>
        with:
          github_token: ${{ secrets.GITHUB_TOKEN }}
          publish_dir: ./docs/_build/html
          publish_branch: gh-pages
          force_orphan: true
          user_name: github-actions[bot]
          user_email: github-actions[bot]@users.noreply.github.com
```

Drop `pages: write` and `id-token: write` permissions, drop the `environment: github-pages`
block, drop the `actions/deploy-pages` step entirely. The job name is no longer `deploy`.

**Verification after enabling:**

```bash
# 1. Branch landed
gh api repos/<owner>/<repo>/branches --jq '.[] | .name' | grep gh-pages

# 2. Pages API now returns 200
gh api repos/<owner>/<repo>/pages --jq '.html_url'

# 3. Public URL serves the built HTML (allow 1–2 min for GitHub provisioning)
curl -sL https://<owner>.github.io/<repo>/ | grep -iE '<title>|<h1'
```

**Verified case — 2026-08-07 batgrl-gallery (sigco3111/batgrl-gallery):**
User forwarded "Run failed: Sphinx 문서화 시스템 – 메인 버전 (c2ce926)". `gh run view
--log-failed` showed the deploy step 404'd. `gh api repos/sigco3111/batgrl-gallery/pages`
→ 404 confirmed Pages was off. Three prior runs (08-06, 08-07) had all failed at the same
step with the same error. Workflow rewrite (gh-pages push) + `contents: write` →
`peaceiris/actions-gh-pages` push succeeded → REST API to enable Pages →
`curl -sI https://sigco3111.github.io/batgrl-gallery/` returned 200 with
`<title>batgrl Documentation — batgrl 0.51.3 documentation</title>`.
