#!/bin/bash
# Cross-repo CI failure distribution scan.
#
# Answers: "is this one repo's bug, or did the platform break?"
#   - failures clustered in one narrow window across unrelated repos => platform outage
#   - failures concentrated in one repo across days                  => that repo's bug
#
# Usage:  ./gh-failure-scan.sh <owner> [since-YYYY-MM-DD] [max-repos]
# Example: ./gh-failure-scan.sh sigco3111 2026-08-03 80
#
# Runs as ONE bash process on purpose. Do not port this to execute_code: that tool
# caps at 50 tool calls, so a per-repo terminal() loop dies partway through.
#
# Provenance: the core loop and the two histograms are verbatim from a scan that ran
# successfully against 80 repos on 2026-08-06. The wrapper added around them here
# (arg parsing, mktemp/trap, BSD/GNU date fallback, empty-result branch) has NOT been
# executed end to end. Run `bash -n "$0"` before trusting it in a hurry.

set -uo pipefail

OWNER="${1:?usage: $0 <owner> [since-YYYY-MM-DD] [max-repos]}"
SINCE="${2:-$(date -u -v-4d +%Y-%m-%d 2>/dev/null || date -u -d '4 days ago' +%Y-%m-%d)}"
MAX="${3:-80}"

command -v gh >/dev/null || { echo "gh CLI not found" >&2; exit 1; }
gh auth status >/dev/null 2>&1 || { echo "gh not authenticated (run: gh auth login)" >&2; exit 1; }

TMPDIR_SCAN=$(mktemp -d -t gh-failure-scan-XXXXXX)
trap 'rm -rf "$TMPDIR_SCAN"' EXIT
REPOS="$TMPDIR_SCAN/repos.txt"
FAILS="$TMPDIR_SCAN/fails.tsv"

# Most-recently-pushed first: active repos are where CI actually runs.
gh repo list "$OWNER" -L 300 --json name,pushedAt \
  -q 'sort_by(.pushedAt) | reverse | .[].name' > "$REPOS"

: > "$FAILS"
n=0
while read -r name; do
  n=$((n+1))
  [ "$n" -gt "$MAX" ] && break
  gh run list -R "$OWNER/$name" -L 30 --status failure \
    --json databaseId,name,createdAt,event \
    -q ".[] | select(.createdAt > \"$SINCE\") | \"$name\t\(.createdAt)\t\(.event)\t\(.name)\t\(.databaseId)\"" \
    2>/dev/null >> "$FAILS"
done < "$REPOS"

SCANNED=$((n-1)); [ "$SCANNED" -lt 0 ] && SCANNED=0
TOTAL=$(wc -l < "$FAILS" | tr -d ' ')

echo "=== scanned: $SCANNED repos (of $(wc -l < "$REPOS" | tr -d ' ')), since $SINCE ==="
echo "=== failures found: $TOTAL ==="

if [ "$TOTAL" -eq 0 ]; then
  echo
  echo "No failures in window. If the user reports failures anyway, check:"
  echo "  - a wider --since"
  echo "  - repos beyond the top $MAX by push recency"
  echo "  - deployments that fail without a workflow row:"
  echo "      gh api \"repos/$OWNER/<repo>/deployments?environment=github-pages&per_page=15\""
  exit 0
fi

echo
echo "=== by date (clustering here => platform outage) ==="
cut -f2 "$FAILS" | cut -c1-10 | sort | uniq -c | sort -k2

echo
echo "=== by repo (one repo dominating => that repo's bug) ==="
cut -f1 "$FAILS" | sort | uniq -c | sort -rn

echo
echo "=== detail (chronological) ==="
sort -t"$(printf '\t')" -k2 "$FAILS" \
  | awk -F"$(printf '\t')" '{printf "%-30s %s  %-16s %s\n", $1, substr($2,1,16), $3, $4}'

echo
echo "Next: for any run above, the annotation carries the real reason —"
echo "  gh run view <RUN_ID> -R $OWNER/<repo>"
echo "(empty --log-failed output means the job never got a runner: infra-level, not a repo bug)"
