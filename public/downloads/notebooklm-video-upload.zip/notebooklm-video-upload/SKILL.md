---
name: notebooklm-video-upload
description: NotebookLM에서 생성한 비디오 오버뷰를 YouTube에 업로드하는 자동화 워크플로우
category: media
version: "1.0"
---

# NotebookLM Video Upload Workflow

NotebookLM에서 생성한 비디오 오버뷰를 YouTube에 업로드하는 자동화 워크플로우.

## Trigger Conditions
- 주인님이 NotebookLM 비디오 오버뷰 URL을 제공
- "노트북엘엠 영상 올려줘", "비디오 오버뷰 업로드" 등의 요청

## Workflow Steps

### 1. NotebookLM 비디오 다운로드
```bash
# 노트북 ID 추출 (URL에서)
# 예: https://notebooklm.google.com/notebook/db759654-8218-4082-b936-7189bc2412c3
# ID: db759654-8218-4082-b936-7189bc2412c3

# 스크립트 실행
python3 ~/.hermes/scripts/notebooklm_download.py --notebook-id <ID>
```

### 2. YouTube 업로드 (일반 영상)
```bash
python3 ~/.hermes/skills/creative/youtube-uploader/scripts/upload.py \
  --file <downloaded_video.mp4> \
  --title "한국어 제목: 서브타이틀 🚀" \
  --description "상세 설명 포함" \
  --tags "태그1,태그2,태그3" \
  --category "Science & Technology" \
  --privacy "public"
```

### 3. 숏츠 생성 및 업로드
```bash
# 숏츠 생성 (60초, 세로 9:16)
ffmpeg -i <original_video.mp4> -vf "scale=720:1280:force_original_aspect_ratio=decrease,pad=720:1280:(ow-iw)/2:(oh-ih)/2,crop=720:1280" -t 60 <shorts.mp4>

# 숏츠 업로드
python3 ~/.hermes/skills/creative/youtube-uploader/scripts/upload.py \
  --file <shorts.mp4> \
  --title "주제 60 초 한 방! 🚀 #shorts" \
  --description "일반 영상 링크 포함" \
  --tags "shorts,주제" \
  --category "Science & Technology" \
  --privacy "public"
```

### 4. 임시 파일 정리
- 업로드 완료 후 `/tmp/icbm_notebooklm/` 폴더의 임시 파일은 수동으로 삭제하거나, 별도 정리 스크립트 사용
- **주의:** `rm -rf` 명령어는 위험하므로 자동화 스크립트에서는 사용하지 않음

## Title Guidelines
- **일반 영상:** "주제: 서브타이틀 🚀" (5 분 이상)
- **숏츠:** "주제 60 초 한 방! 🚀 #shorts" (60 초 이하)
- **카테고리:** Science & Technology (기본)
- **태그:** 주제 관련 한국어/영어 키워드 (5-10 개)

## Pitfalls
- **URL 추출:** iOS 앱에서는 공유 버튼이 없어 URL 직접 복사 불가 → 주인님이 브라우저에서 URL 복사 필요
- **비디오 생성:** NotebookLM에서 비디오 오버뷰가 생성되지 않으면 다운로드 불가 → 주인님이 직접 생성 필요
- **임시 파일:** `/tmp` 폴더는 재부팅 시 삭제되므로, 영구 보관 필요 시 다른 위치로 이동
- **인증:** YouTube OAuth 토큰 만료 시 수동 인증 스크립트 사용 (`~/.hermes/secrets/youtube_token.pickle`)

## Verification
- YouTube URL 확인 (업로드 완료 후)
- 영상 길이 확인 (일반: 5 분 이상, 숏츠: 60 초 이하)
- 프라이버시 설정 확인 (Public)
- 태그 및 카테고리 확인

## Example
```
입력: "https://notebooklm.google.com/notebook/db759654-8218-4082-b936-7189bc2412c3"
출력: 
  - 일반 영상: https://www.youtube.com/watch?v=xb9NiM6CR2Y
  - 숏츠: https://www.youtube.com/watch?v=H79eDdpPN34
```