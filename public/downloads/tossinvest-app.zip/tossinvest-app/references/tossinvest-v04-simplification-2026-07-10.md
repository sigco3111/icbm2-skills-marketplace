# toss-trader v0.3 → v0.4 단순화 결정 흐름 (★ SSOT)

> 작성일: 2026-07-10
> 적용 repo: https://github.com/sigco3111/toss-trader
> 적용 commit: `fcb8b10 docs: v0.3 단순화 — OpenCode 전환 + LLM 호출 0줄 (3파일)`
> 관련 tossinvest-app 섹션: §0, §1, §3, §4, §7, §8, §10

## 0. 사용자 코렉션 원문 (verbatim)

> "OpenCode 글로벌 디폴트모델 설정으로 하자, 사용자가 모델을 변경하고 싶으면 OpenCode를 통해서만 변경가능하도록, 우리 프로젝트에서는 따로 모델 설정이 필요 없게"

이 한 줄이 **v0.2 → v0.3 단순화의 출발점**. 다중 LLM provider 라우터 / BYOK 폼 / ChatPanel UI를 모두 폐기하는 결정의 근거.

## 1. 이전 상태 (v0.2)

| 차원 | 상태 |
|---|---|
| LLM provider 라우터 | NIM 6종 + OpenAI + Anthropic = 7~8종 |
| BYOK 폼 | 4개 키 (Toss client_id/secret + LLM key + DRY_RUN) |
| ChatPanel.tsx | LLM 대화 UI |
| 다중 provider 선택 | UI 드롭다운 |
| toss-trader 코드 내 LLM 호출 | Vercel Edge Function HTTP 호출 |
| tossinvest-v0.2.md 라인 수 | ~170줄 (toss-trader 본질보다 LLM 라우터 코드가 더 많음) |

## 2. 사용자 의도 명확화 질문 2개

주인님가 순차로 던진 두 가지 핵심 질문 (정확한 흐름):

### Q1: Codex → OpenCode 전환 찬성?

> 주인님: "코덱스 대신 오픈코드로 변경하려고 하는데 어떻게 생각해?"

→ 영향 분석 + 옵션 A/B/C/D 제시 → **주인님 승인**.

### Q2: OpenCode 글로벌 디폴트면 우리 프로젝트 자동 적용?

> 주인님: "오픈코드를 사용할 경우 사용자가 설정한 모델을 디폴트로 사용하게되나? 예를 들면 오픈코드에 모델을 미니맥스로 했다면 별다른 설정없이 우리 프로젝트에서 미니맥스를 사용하는 방식인가?"

→ 정답: **예. OpenCode는 config 기반이라 주인님가 한 번 글로벌 디폴트를 미니맥스로 설정해두면, 모든 프로젝트가 자동 적용.** + "그러나" — toss-trader의 LLM provider 라우터는 **별개 계층** (Vercel Edge Function HTTP 호출 vs 주인님 PC의 OpenCode).

### Q3: toss-trader 자체의 다중 LLM 라우터는?

> 주인님: "OpenCode 글로벌 디폴트모델 설정으로 하자, 사용자가 모델을 변경하고 싶으면 OpenCode를 통해서만 변경가능하도록, 우리 프로젝트에서는 따로 모델 설정이 필요 없게"

→ **v0.3 단순화 결정 확정**. toss-trader 코드 내 LLM 호출 0줄.

## 3. 4옵션 brainstorm (각 턴에서 제시했던 옵션들 종합)

### A. docs 3개 패치만 → 커밋 → 정지 (★ 추천)

| 항목 | 값 |
|---|---|
| 변경 범위 | AGENTS.md / README.md / docs/ARCHITECTURE.md 3파일 |
| 검증 | 헤딩 정규화 0/0 깨짐 (bash + python 2중 어서션) |
| 위험 | 0 (reversible, 단일 repo 내) |
| 시간 | 30분 |

### B. docs 패치 + install 가이드 작성

A + oh-my-opencode install 가이드 (주인님 PC 실측 가이드). 시간 60분.

### C. docs 패치 + 본인 PC에서 bunx install 실측

A + 주인님가 본인 PC에서 비대화형 install 실행. 시간 60분 (주인님 PC 작업).

### D. 다른 방향 (직접 설명)

사용자 자유 입력.

## 4. 최종 옵션: A (사용자 "추천옵션으로 진행" 응답)

주인님가 "추천옵션으로 진행" 응답 → 옵션 A로 진행.

## 5. 적용 결과 (2026-07-10 실측)

| 항목 | 값 |
|---|---|
| 패치 파일 | `AGENTS.md` (10,310B) + `README.md` (10,738B) + `docs/ARCHITECTURE.md` (5,982B) |
| 커밋 | `docs: v0.3 단순화 — OpenCode 전환 + LLM 호출 0줄 (3파일)` |
| 푸시 SHA | `aa5c59d → fcb8b10` |
| diff | 216+ / 330- (3파일 합계) |
| 헤딩 정규화 | 0/0 깨짐 (bash check-kr-en-mixed-headings.sh + python 정밀 2중) |
| OPENAPI_REFERENCE.md | 무변경 (10,522B 그대로) |

## 6. v0.3 단순화 핵심 결정 7가지 (★ 신규 정형화)

| # | 결정 | 근거 |
|---|---|---|
| 1 | toss-trader 코드 내 LLM 호출 0줄 | 사용자 코렉션 "우리 프로젝트에서는 따로 모델 설정이 필요 없게" |
| 2 | 모델 = OpenCode 글로벌 디폴트 (미니맥스 M3) | OpenCode config 기반 자동 적용 |
| 3 | 모델 변경 경로 = OpenCode 설정만 | UI 드롭다운 ❌ (사용자 명시) |
| 4 | 다중 LLM provider 라우터 폐기 | v0.2 7~8종 → v0.3 0개 |
| 5 | BYOK 폼 폐기 | v0.2 4개 키 → v0.3 0개 (tossinvest.env로 통합) |
| 6 | ChatPanel.tsx 폐기 | LLM 호출 0이므로 UI도 0 |
| 7 | 가드 #5 위치 이동 | `components/SettingsForm.tsx` → `lib/safety.ts` (BYOK 폼 제거에 따른 자연 통합) |

## 7. toss-trader v0.3 8단계 (단순화)

1. Next.js 15 + TypeScript + Tailwind 보일러플레이트
2. `app/api/toss/route.ts` 토스 Open API relay (시세/잔고)
3. `lib/safety.ts` 5대 가드 + TDD 단위 테스트
4. `app/api/telegram/route.ts` + `components/OrderButton.tsx`
5. `app/page.tsx` + `components/Portfolio.tsx` 대시보드
6. `app/api/notion/route.ts` 이력 기록
7. `vercel.json` + Vercel 배포 + 환경변수
8. e2e 테스트 (Vercel preview URL)

## 8. 부록: OpenCode 미설치 환경

주인님 PC가 아닌 다른 PC에서 toss-trader 작업 시:

```bash
# 1) OpenCode 설치
brew install opencode

# 2) oh-my-opencode install
bunx oh-my-opencode@latest install --no-tui \
  --platform=opencode \
  --minimax-coding-plan=yes \
  --claude=no --gemini=no --copilot=no \
  --skip-auth

# 3) TUI 인증 (1회)
opencode
# /connect → minimax API 키 입력

# 4) 글로벌 디폴트 확인
cat ~/.config/opencode/opencode.json | grep -A1 model
# "model": "minimax/MiniMax-M3" 출력되어야 함

# 5) toss-trader 의존성
cd toss-trader
npm install
npm run test  # v0.3 8단계 진행 중인 경우
```

## 9. 부록: AGENTS.md v0.3 Red Lines 7개

1. 시크릿 평문 노출 금지 (Vercel env 박지 마)
2. 메신저 평문 전송 절대 금지 (Telegram 메시지에 토큰 노출 ❌)
3. 주문 endpoint 호출은 opt-in (`DRY_RUN=true` 기본)
4. 사용자 행동지침 없으면 HOLD
5. Vercel serverless 제약 인지 (spawn ❌, HTTP만 ⭕)
6. 422 가드 자동 처리 (account-restricted / prerequisite-required / confirm-high-value-required)
7. **v0.3 단순화 위반 금지 (NEW)** — BYOK 폼 / LLM provider 라우터 / 다중 provider 코드 추가하지 마

## 10. 부록: 검증 도구 2중 어서션

이번 v0.3 패치에 사용한 헤딩 정규화 2중 검증:

```bash
# 1) bash 어서션 (skill 제공)
bash ~/.hermes/skills/ad-hoc-verifier/scripts/check-kr-en-mixed-headings.sh \
  AGENTS.md README.md docs/ARCHITECTURE.md

# 2) python 정밀 어서션
python3 - <<'PY'
import re
total = 0
files = ['AGENTS.md', 'README.md', 'docs/ARCHITECTURE.md']
for f in files:
    t = open(f).read()
    bad = re.findall(r'^##+ [^()\n]*[가-힣][^()\n]*[A-Za-z][^()\n]*$', t, flags=re.MULTILINE)
    bad = [h for h in bad if h.count('(') != h.count(')')]
    print(f"  {f}: {len(bad)} / 0")
    total += len(bad)
print(f"TOTAL: {total} / 0")
PY
```

두 어서션 모두 0/0 깨짐. **단일 어서션 통과 ≠ 안전** (지난 세션 함정 #39 — genetic 1 patch 회피 사례 있음). 정형화 원칙 = 항상 2중.

## 11. 부록: 기억해야 할 한 줄

> **toss-trader는 toss Open API 데이터만 제공한다. LLM 분석은 주인님 PC의 OpenCode 글로벌 디폴트가 처리한다. 모델 변경 = OpenCode 설정에서만. 우리 프로젝트는 모델 설정 코드 0줄.**
