# toss-trader v0.3 단순화 결정 흐름 (2026-07-10)

> **상태**: 본 문서는 `tossinvest-v04-simplification-2026-07-10.md`로 대체됐습니다 (v0.4 결정 후 rename).
> historical reference로 보존. v0.3/v0.4 단순화 결정의 SSOT는 새 파일을 참조하세요.

## 핵심 (옛 결정, v0.3 시점)

- 다중 LLM provider 라우터 / BYOK 폼 / ChatPanel 모두 폐기
- toss-trader 코드 내 LLM 호출 0줄
- 모델 = OpenCode 글로벌 디폴트(미니맥스 M3) 단일
- 모델 변경 = OpenCode 설정에서만

## 새 SSOT 위치

`tossinvest-v04-simplification-2026-07-10.md` — v0.3 + v0.4 통합 (Red Lines #7, 검증 도구 2중 어서션, OpenCode 미설치 부록 모두 포함)
