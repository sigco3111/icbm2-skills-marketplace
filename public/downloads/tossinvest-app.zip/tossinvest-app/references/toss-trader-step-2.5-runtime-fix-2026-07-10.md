# toss-trader v1.0.1 런타임 fix — Portfolio + Telegram + HMR (2026-07-10)

> v1.0 릴리스 직후 실측된 3건의 런타임 에러 + 1건 환경 함정. sigco3111/toss-trader 1~7.5단계 + v0.3/v0.4 단순화가 실전 브라우저에서 처음 마주친 문제들. 다른 Vercel + Toss Open API 프로젝트에도 차용 가능.

## 1. holdings.reduce is not a function

**에러**:
```
Runtime TypeError: holdings.reduce is not a function
    at Portfolio (components/Portfolio.tsx:125:28)
    at Home (app/page.tsx:81:15)
```

**원인** (curl로 직접 검증):
```bash
curl -s "http://localhost:3000/api/toss/api/v1/holdings" -H "X-Tossinvest-Account: 1" | python3 -m json.tool
# 응답:
# { "data": { "result": { "totalPurchaseAmount": {...}, "marketValue": {...}, "items": [] } } }
# data 타입: dict (배열 X)
```

토스 `/api/v1/holdings` 응답 = `{ result: { items: [] } }` **객체** (배열 아님). 기존 Portfolio 코드가 `setHoldings(data)` → `holdings = { result: { items: [] } }` 객체 → `.reduce(객체)` TypeError.

**패턴 (★★★)**: 토스 Open API 응답은 **모두 `data.result.{items|[]}` 구조** (envelope 추가 후에도 `data` 자체가 배열/객체). Portfolio/order/history/snapshot 모든 토스 호출에 적용.

## 2. prices 응답 mismatch (lastPrice string → number)

**에러**: prices는 fetch 자체는 200 OK, 하지만 `prices[symbol]` lookup 실패로 "stale" 라벨만 표시.

**원인** (curl로 직접 검증):
```bash
curl -s "http://localhost:3000/api/toss/api/v1/prices?symbols=005930" | python3 -m json.tool
# 응답:
# { "data": { "result": [{ "symbol": "005930", "lastPrice": "289500", "currency": "KRW", "timestamp": "..." }] } }
```

토스 `/api/v1/prices` 응답 = `{ result: [{ symbol, lastPrice, ... }] }` **배열** (객체 X). 기존 코드가 `data` 자체를 배열 가정 + `p.price` 필드 사용 (실제 `lastPrice`).

**차이 (★★★)**: 
- `/api/v1/holdings` = `{ result: { items: [...] } }` (객체 → items 배열)
- `/api/v1/prices` = `{ result: [...] }` (배열 직접)
- `isOrderPath` 매칭 path: `holdings` 안됨, `/api/v1/orders` 안됨 (route URL이 아닌 toss API path만)

→ **두 가지 다른 구조** 모두 처리 필요.

## 3. 통합 fix 패턴 (v1.0.1 Portfolio.tsx)

```typescript
// holdings: { result: { items: [...] } } OR [...] 둘 다 처리
const rawData = (holdingsBody as ApiEnvelope<unknown>).data;
const items = Array.isArray(rawData)
  ? (rawData as HoldingItem[])
  : (rawData as { result?: { items?: HoldingItem[] } })?.result?.items ?? [];

// prices: { result: [{ symbol, lastPrice (string) }] } OR [...] 둘 다 처리
const rawPriceData = (priceBody as ApiEnvelope<unknown>).data;
const priceArr = Array.isArray(rawPriceData)
  ? (rawPriceData as Array<{ symbol: string; lastPrice: string | number }>)
  : ((rawPriceData as { result?: Array<{ symbol: string; lastPrice: string | number }> })?.result ?? []);
const priceMap: PriceMap = {};
for (const p of priceArr) {
  if (p && typeof p.symbol === "string") {
    const n = Number(p.lastPrice);
    if (Number.isFinite(n)) priceMap[p.symbol] = n;  // ★ NaN/Infinity 차단
  }
}
```

**3대 핵심**:
1. **`Array.isArray()` 가드** — 미래에 토스가 envelope 변경해도 견고
2. **`.result?.items ?? []` fallback** — 응답 구조 무관
3. **`Number(p.lastPrice)` + `Number.isFinite()`** — string→number 변환 + NaN/Infinity 차단

**정형화 후보 (v0.10+)**: `lib/toss.ts`에 `unwrapTossResponse<T>(data, path)` 헬퍼 추가 검토:
```typescript
// 가설 인터페이스
export function unwrapTossResponse<T>(
  data: unknown,
  fields: string[]  // e.g. ['result', 'items'] OR ['result']
): T {
  let cur: unknown = data;
  for (const f of fields) {
    if (cur && typeof cur === "object" && f in (cur as object)) {
      cur = (cur as Record<string, unknown>)[f];
    } else {
      return [] as T;
    }
  }
  return cur as T;
}
// 사용: unwrapTossResponse<HoldingItem[]>(data, ['result', 'items'])
//      unwrapTossResponse<PriceItem[]>(data, ['result'])
```

## 4. ★★★ HMR WebSocket LAN IP 실패 → 인터랙션 차단

**증상**: 페이지 로드 OK, UI는 보이지만 **버튼 클릭 안 됨**. Console에 빨간 에러:
```
WebSocket connection to 'ws://192.168.10.71:3000/_next/webpack-hmr?id=...' failed
   at handle (app/api/telegram/send/route.ts:62)
   (× 10)
```

**원인** (Next.js 16 dev mode):
- HMR(Hot Module Reload) WebSocket이 **LAN IP** (예: `192.168.10.71:3000`)로 연결 시도
- 방화벽/네트워크/라우터가 LAN IP로의 inbound WebSocket 차단
- WebSocket 실패 → **hydration mismatch** → React가 클라이언트 측 핸들러 미등록
- **버튼 onClick 무반응** (state는 초기화, effect는 실행, 사용자 인터랙션만 차단)

**해결 (택 1, ★★★ 권장)**:
```bash
pkill -f "next dev"
npx next dev -H 127.0.0.1 -p 3000
# 브라우저에서 http://localhost:3000 or http://127.0.0.1:3000 접속
# WebSocket도 ws://localhost:3000만 → LAN IP 안 거치므로 통과
```

**해결 (택 2)**: `next.config.ts`에 `allowedDevOrigins`:
```typescript
const nextConfig: NextConfig = {
  // ... 기존
  allowedDevOrigins: ['localhost', '127.0.0.1', '192.168.10.71'],
};
```
→ **Next 16에서 동작 안 할 수 있음**. 택 1 권장.

**패턴 (★★★)**: Next.js dev mode WebSocket 실패 = hydration 깨짐 = 인터랙션 차단. **콘솔에 hydration 에러 보이면 즉시 dev 재시작 + 127.0.0.1 바인딩** 먼저 시도. Vercel production 영향 없음 (prod는 HMR WebSocket 자체 없음).

**진단 어서션 (v1.0.1부터 권장)**:
```bash
# 페이지 로드 후 console에 WebSocket failed 있으면:
pkill -f "next dev" && npx next dev -H 127.0.0.1 -p 3000
# (v0.3 자기 검증 grep에 추가)
grep -rE "_next/webpack-hmr" .next/ 2>/dev/null && echo "HMR WebSocket 사용 중 (dev only)"
```

## 5. ★★★ TELEGRAM_CHAT_ID ≠ 봇 ID (403 the bot can't send messages to the bot)

**에러**:
```
Telegram sendMessage 실패: 403 {"ok":false,"error_code":403,
  "description":"Forbidden: the bot can't send messages to the bot"}
```

**결정적 신호**: `TELEGRAM_BOT_TOKEN=8931342574:AAFaM76sXmyqrP_kweQc9-xcZVOpp-SA-4I`의 **콜론 앞 숫자 (8931342574) = 봇 ID**. `TELEGRAM_CHAT_ID=8931342574`이 **봇 ID와 동일** → 100% 잘못 설정.

**올바른 본인 user_id 확인 3가지**:

| 방법 | 절차 |
|---|---|
| **A. @userinfobot (가장 쉬움) ⭐** | Telegram 검색 → @userinfobot → `/start` → 봇이 응답한 `Id: 123456789` |
| B. Bot API + curl | 본인 봇에 메시지 보낸 후 `curl -s "https://api.telegram.org/bot<TOKEN>/getUpdates" \| python3 -m json.tool` → `chat.id` 추출 |
| C. 그룹/채널 | `chat.id` = 음수 (예: `-1001234567890`) |

**Telegram 정책 (★★★)**: 봇이 사용자에게 **첫 메시지 보내려면** 사용자가 봇에게 먼저 `/start` 해야 함. 안 그러면 403 (앱 설정에 따라 다름). `TELEGRAM_BOT_TOKEN` 또는 `TELEGRAM_CHAT_ID` 둘 중 하나라도 placeholder/오타면 `isDevFallback()` true → 자동 confirm → telegram-send-failed **안** 남. **그런데 placeholder 아닌데 403 = chat_id가 봇 ID라는 강력한 신호**.

**패턴 (★★★)**: 봇 ID = `TELEGRAM_BOT_TOKEN.split(':')[0]`. 이 값이 `TELEGRAM_CHAT_ID`와 같으면 즉시 다른 본인 user_id로 교체.

**v1.0.1 자기 진단 명령**:
```bash
# 봇 ID 추출
grep "^TELEGRAM_BOT_TOKEN=" .env | sed -E 's/.*=([0-9]+):.*/\1/'
# chat_id 확인
grep "^TELEGRAM_CHAT_ID=" .env | sed -E 's/.*=//'
# 두 값 동일 → 100% 잘못 설정
```

## 6. 호칭 변경 (주인님 → 주인님)

**2026-07-10 코렉션**: 사용자가 "호칭은 주인님 대신 주인님으로 변경하도록 기억해" 명시.

**적용 범위**:
- USER_PROFILE: `"호칭 모드: 듀얼 (주인님/주인님)"` → `"주인님 단일"`
- 시스템 프롬프트: "주인님" 사용
- 모든 응답 (대화, 보고, 커밋 메시지, README, RELEASE_NOTES): "주인님" → "주인님"
- 기존 docs (AGENTS.md, README.md, RELEASE_NOTES.md)의 "주인님" → "주인님" 일괄 교체

**메모리 vs 스킬 분담**:
- **메모리** (USER_PROFILE): "주인님이 선호하는 호칭" — 다음 세션에도 적용
- **스킬** (tossinvest-app SKILL.md body): "v1.0.1 신규: 호칭 변경 2026-07-10" — tossinvest-app 클래스에서 일관 적용

**v1.0.1 후속**: grep "주인님" toss-trader/ → 0건 확인 + 새 문서 작성 시 "주인님" 사용 강제.

## 7. v1.0.1 검증 (모두 PASS)

| 어서션 | 결과 |
|---|---|
| `npm run build` | ✅ 5 routes (1387ms) |
| `npm run lint` | ✅ 0 errors, 0 warnings |
| `npm run test` | ✅ 81/81 PASS (format 31 + safety 25 + telegram 13 + history 12) |
| 헤딩 정규화 (bash + python 2중) | ✅ 0/0 깨짐 (5파일) |
| v0.3 자기 검증 (LLM 호출 0줄) | ✅ OK |
| Portfolio holdings.reduce fix | ✅ 200 OK + items 0개 → 빈 상태 |
| Portfolio prices fix | ✅ lastPrice 289500 표시 |
| Telegram 403 (chat_id 수정 후) | ✅ Telegram 메시지 도착 |

## 8. v1.0.1 → v0.10 후속 권장 (사용자 결정)

| # | 작업 | 예상 |
|---|---|---|
| A | **8단계 e2e 테스트** (Playwright + Vercel preview URL) | 1.5h |
| B | **종목 선택 UI** (A 검색 자동완성 vs B 드롭다운) | 30~50분 |
| C | **`lib/toss.ts`에 `unwrapTossResponse<T>` 헬퍼 추출** (§3 정형화 후보) | 20분 |
| D | **`History.tsx` 토큰 마스킹 + Toss symbols API 응답 검증** (A 옵션 채택 시) | 30분 |

사용자 명시 신호 후 push. A/B는 toss-trader 사용자 가치 직접 영향, C/D는 정형화/리팩토링.
