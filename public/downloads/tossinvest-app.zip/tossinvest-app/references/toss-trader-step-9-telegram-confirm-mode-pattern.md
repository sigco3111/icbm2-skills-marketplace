# toss-trader v1.1.1 — Telegram confirm 모드 패턴 (2026-07-10)

## 배경

사용자 요청: "텔레그램으로 메시지를 보내는 것에 대한 on/off 설정이 있으면 좋겠음. 그리고 확인/취소 메시지 전송 없이 알아서 확인하는 설정도 추가되었으면함."

**설계 결정**: 단일 env + UI 토글 (옵션 A). 3개 모드 (telegram/auto/off).

## 3개 모드

| 모드 | Telegram 발송 | 사용자 confirm | 가드 5 (TELEGRAM_CONFIRM) | 용도 |
|---|---|---|---|---|
| `telegram` (기본) | ✅ | 필요 (인라인 button) | 자동 true | 실전 (가장 일반) |
| `auto` | ❌ | 즉시 confirmed | 자동 true | dev/test/봇 미설정 |
| `off` | ❌ | 안 함 | false → 425 차단 | paper 거래만 |

## 아키텍처 (4 파일)

### 1. `lib/settings.ts` (신규)

```typescript
export type TelegramConfirmMode = "telegram" | "auto" | "off";

export const TELEGRAM_CONFIRM_MODES = [
  { value: "telegram", label: "Telegram 메시지", description: "..." },
  { value: "auto", label: "자동 확인", description: "..." },
  { value: "off", label: "비활성화", description: "..." },
] as const;

export function loadConfirmMode(): TelegramConfirmMode { /* localStorage */ }
export function saveConfirmMode(mode: TelegramConfirmMode): void { /* localStorage */ }
export function getDefaultMode(): TelegramConfirmMode { /* process.env.TELEGRAM_CONFIRM_MODE */ }
```

**저장 우선순위**: localStorage (브라우저별 override) > env (서버 기본값).

### 2. `components/ConfirmModeToggle.tsx` (신규)

- UI 라디오 그룹 (3 옵션)
- `auto` 옵션 옆에 `dev/test` amber 뱃지
- 선택 시 `localStorage` 자동 저장 + 부모 onChange
- SSR hydration mismatch 회피: `useRef<boolean>(false)` + `setTimeout(0)` 마운트 패턴
- 접근성: `<label>` + `<input type="radio">` (네이티브)

### 3. `lib/telegram.ts` sendOrderConfirm 모드별 분기

```typescript
export async function sendOrderConfirm(
  req: OrderRequest,
  mode: "telegram" | "auto" | "off" = "telegram"
): Promise<SendResult> {
  // ... store set
  if (mode === "off") {
    pendingStore.delete(orderId);
    return { ok: false, message: "confirm 비활성화", mode: "off" };
  }
  if (mode === "auto") {
    pending.status = "confirmed";
    return { ok: true, message: "즉시 confirmed", mode: "auto" };
  }
  // mode === "telegram": 기존 로직
}
```

### 4. `app/api/telegram/send` + `app/page.tsx`

- route: body.confirmMode 받아서 lib/telegram.ts에 전달 + 응답 헤더 `X-Confirm-Mode` 추가
- page: 3-컬럼 grid (`lg:grid-cols-3`) — Portfolio + OrderButton + ConfirmModeToggle

## 6대 가드와의 상호작용 (중요)

`lib/safety.ts`의 가드 5 (TELEGRAM_CONFIRM):
- `live` 모드 + 주문 endpoint → `telegramConfirmed: true` 강제
- `paper` 모드 → 가드 5 비활성 (DRY_RUN=true)
- **`off` 모드** = `telegramConfirmed: false` → 가드 5에서 425 차단 (실제로는 order 자체가 실행 안 됨)

→ **3택 일관성**: `TOSS_TRADING_MODE` × `TELEGRAM_CONFIRM_MODE` × `DRY_RUN` 매트릭스.

| trading mode | confirm mode | DRY_RUN | 주문 가능 여부 |
|---|---|---|---|
| paper | telegram | true | ❌ (DRY_RUN 차단) |
| paper | auto | true | ❌ (DRY_RUN 차단) |
| paper | off | true | ❌ (DRY_RUN 차단) |
| live | telegram | false | ✅ Telegram confirm 필수 |
| live | auto | false | ✅ 즉시 confirmed (위험 — 신중) |
| live | off | false | ❌ (가드 5 차단) |
| simulation | * | * | ❌ (가드 1 차단) |

## TDD 사이클 (13 tests in 3 describe blocks)

`test/settings.test.ts`:
- `TELEGRAM_CONFIRM_MODES` 메타 검증 (2)
- `loadConfirmMode` 6 cases (빈/auto/off/잘못된 값/env 우선/localStorage 우선)
- `saveConfirmMode` 1 case (3종 저장→로드 라운드트립)
- `getDefaultMode` 4 cases (env 없음/auto/off/잘못된 값)

**jsdom 없이 vitest 4 + localStorage mock**:
- `vi.stubGlobal("window", { localStorage: localStorageMock })` 패턴
- jsdom 패키지 의존성 0
- 다른 client-side storage 테스트에도 적용 가능

## 안전성

- **`off`는 가드 5 통과 못함** → 실계좌 주문 차단. 가장 안전.
- **`auto`는 Telegram 봇 없이도 주문 가능** → `TOSS_TRADING_MODE=live`일 때만 위험. UI에 "dev/test" amber 뱃지로 명시.
- **`telegram`이 기본 + 실전** — 기존 코드와 100% 호환.

## UI 동작 (사용자 시나리오)

1. 페이지 로드 → `useRef(false)` + `setTimeout(0)` 마운트 후 `loadConfirmMode()` → localStorage 또는 env 기본값
2. 라디오 선택 → `saveConfirmMode(mode)` + `onChange(mode)` → 부모 state 업데이트
3. 다음 매수/매도 시 → `OrderButton`의 `confirmMode` prop → `/api/telegram/send` body.confirmMode → lib/telegram.ts 모드별 분기
4. 페이지 새로고침 후에도 localStorage 유지

## 자기 검증 명령 (v1.1.1)

```bash
# 자기 검증 1: 모드 UI 표시 확인
grep -E "TELEGRAM_CONFIRM_MODE|자동 확인|Telegram 메시지|비활성화" components/ConfirmModeToggle.tsx

# 자기 검증 2: 모드 분기 코드 확인
grep -E "mode === \"(off|auto|telegram)\"" lib/telegram.ts

# 자기 검증 3: env 키 1줄
grep "^TELEGRAM_CONFIRM_MODE=" .env.example

# 자기 검증 4: 3-컬럼 grid
grep "lg:grid-cols-3" app/page.tsx

# 자기 검증 5: 108/108 tests
npm test 2>&1 | tail -3
```

## 호환성

- **v0.3 단순화 호환**: BYOK 폼 ❌, 단일 모드 ❌ → 단순화된 3-모드 토글. UI 추가만 (코드 내 LLM 호출 0줄 유지).
- **v0.4 단순화 호환**: Toss Open API 호출 0 (UI 토글만).
- **기존 사용자 영향**: `confirmMode` prop이 기본값 `"telegram"`이라 기존 OrderButton 호출자(`page.tsx`)가 없으면 기본값으로 동작. **breaking change ❌**.
- **localStorage 키**: `toss-trader:confirm-mode` (3 파일 모두 일관).

## 다음 단계

- v1.2: 매도 시 보유 종목 + 평균가 자동 채움 (15분)
- v1.2: Portfolio에 보유 종목 테이블 (실제 데이터)
- v2.0: 실계좌 모드 + Telegram confirm 강화 (1억+ 가드 검증)
