# toss-trader step-11: v1.1.3 — TOSS_TRADING_MODE=paper 시 auto-live 즉시 confirmed

**v1.1.3 (2026-07-10)** — paper 사용자에게 `auto-live` 모드 선택 시 2차 confirm 강제 안 함. UX 개선.

## 문제 (v1.1.2 한계)

- v1.1.2에서 `auto-live`는 무조건 2차 confirm + 5초 카운트다운
- paper 거래 사용자가 `auto-live`를 선택해도 5초 대기 강제 → UX 마찰
- paper 환경에서 2차 confirm은 **불필요한 안전 (이미 paper라 무손해)**

## v1.1.3 디자인

- **`TOSS_TRADING_MODE=paper`** + **`confirmMode=auto-live`** → **즉시 confirmed (2차 confirm 면제)**
- **`TOSS_TRADING_MODE=live`** + **`confirmMode=auto-live`** → **2차 confirm + 5초 카운트다운** (기존 v1.1.2 그대로)
- 다른 모드(telegram/auto-paper/off)는 영향 ❌

## 핵심 변경 (3 파일 + 3 tests)

### 1. `lib/telegram.ts` — `isPaperMode()` 헬퍼 + auto-live 분기 최상단

```typescript
function isPaperMode(): boolean {
  const v = process.env.TOSS_TRADING_MODE ?? "paper";
  return v.toLowerCase() === "paper";
}

if (mode === "auto-live") {
  // v1.1.3: paper일 때는 auto-live 무시 (즉시 confirmed)
  if (isPaperMode()) {
    pending.status = "confirmed";
    return {
      ok: true,
      orderId,
      devFallback: false,
      expiresAt: new Date(expiresAt).toISOString(),
      message: "TOSS_TRADING_MODE=paper + auto-live. paper 거래는 즉시 confirmed (2차 confirm 면제).",
      mode: "auto-live",
    };
  }
  // 실계좌만 doubleConfirmed 분기 (기존)
  if (req.doubleConfirmed) { /* 2차 confirm 완료 */ }
  return { ok: false, ... }; // 1차 호출
}
```

### 2. `test/telegram.test.ts` — 3 tests 추가 (100 → 116)

```typescript
it("sendOrderConfirm auto-live + TOSS_TRADING_MODE=paper → 즉시 confirmed (2차 confirm 면제)", async () => {
  process.env.TOSS_TRADING_MODE = "paper";
  const r = await sendOrderConfirm(sampleOrder, "auto-live");
  expect(r.ok).toBe(true);
  expect(r.mode).toBe("auto-live");
  expect(r.message).toContain("paper 거래는 즉시 confirmed");
});

it("sendOrderConfirm auto-live + TOSS_TRADING_MODE=live + doubleConfirmed=false → ok:false (2차 confirm 필요)", async () => {
  process.env.TOSS_TRADING_MODE = "live";
  const r = await sendOrderConfirm(sampleOrder, "auto-live");
  expect(r.ok).toBe(false);
  expect(r.mode).toBe("auto-live");
  expect(r.message).toContain("2차 confirm 필요");
});

it("sendOrderConfirm auto-live + TOSS_TRADING_MODE=live + doubleConfirmed=true → 즉시 confirmed", async () => {
  process.env.TOSS_TRADING_MODE = "live";
  const r = await sendOrderConfirm({ ...sampleOrder, doubleConfirmed: true }, "auto-live");
  expect(r.ok).toBe(true);
  expect(r.mode).toBe("auto-live");
  expect(r.message).toContain("UI 2차 confirm 완료");
});
```

### 3. `beforeEach`에서 `TOSS_TRADING_MODE` reset 추가

```typescript
beforeEach(() => {
  delete process.env.TELEGRAM_BOT_TOKEN;
  delete process.env.TELEGRAM_CHAT_ID;
  delete process.env.TOSS_TELEGRAM_CHAT_ID;
  delete process.env.TELEGRAM_CONFIRM_TTL_SEC;
  delete process.env.TOSS_TRADING_MODE; // v1.1.3
  _resetPendingStore();
  // ... fetch mock
});
```

## 모드 매트릭스 (v1.1.3 최종)

| TOSS_TRADING_MODE | confirmMode | 동작 |
|---|---|---|
| **paper** (기본) | telegram | Telegram 메시지 → [확인] |
| paper | auto-paper | 즉시 confirmed (모달 없음) |
| paper | **auto-live** | **즉시 confirmed (v1.1.3)** — 2차 confirm 면제 |
| paper | off | 423 차단 (paper만) |
| **live** | telegram | Telegram 메시지 → [확인] |
| live | auto-paper | 즉시 confirmed (위험) |
| live | auto-live | **2차 confirm + 5초 카운트다운** |
| live | off | 423 차단 (가드 5) |

## TDD 사이클 실측 (116/116)

- 1차: 2/116 fail (TelegramConfirmMode 타입 변경에 따른 telegram.test.ts 일부 + description 변경)
- 2차: 1/116 fail (test file에 patch 중 추가 `});` 중복)
- 3차: 116/116 PASS
  - patch에서 L80 `});` 중복 → `});` 1개로 정정 (describe 닫기)
  - LSP stale 진단 + 실제 build/lint 모두 통과 확인 후 commit

## 발견한 함정 (v1.1.3 세션 실측)

| # | 함정 | 해결 |
|---|---|---|
| **34** | **TS test 파일 partial patch 중 `});` 중복** | multi-section patch가 describe 블록 닫기 위치 잘못. **임계값 3+ partial patch → 통째로 rewrite**. 정정 후 describe 구조 정확히 매치 |
| 35 | **`process.env.TOSS_TRADING_MODE` 격리** | beforeEach에서 명시적으로 `delete` (이전 테스트의 env가 다음 테스트에 영향) |

## 검증 (모두 PASS)

- npm run build: ✓ 5 routes
- npm run lint: 0 errors, 0 warnings
- npm run test: **116/116 PASS** (settings 18 + format 31 + safety 25 + telegram 16 + history 12 + stocks 14)
- 헤딩 정규화: 0/0 깨짐 (5파일)
- v0.3 자기 검증: LLM 호출 0줄 유지

## 즉시 확인 (주인님이 직접)

```bash
pkill -f "next dev"
cd /Users/mac/work/toss-trader
npx next dev -H 127.0.0.1 -p 3000
```

브라우저:
1. `TOSS_TRADING_MODE=paper` (`.env` 기본값) + **"자동 확인 (실계좌)"** 선택
2. **매수 진행** → 2차 confirm 모달 **없이 즉시 confirmed** → paper 주문 실행
3. `TOSS_TRADING_MODE=live` (.env 변경 후 dev 재시작) + 같은 모드 → 2차 confirm 모달 표시 (5초 카운트다운)

## commit message pattern

```
feat(telegram): v1.1.3 — TOSS_TRADING_MODE=paper 시 auto-live 즉시 confirmed (116/116)
```

## 다음 옵션

- v1.1.4: 매도 시 보유 종목 + 평균가 자동 채움
- v1.2: e2e 테스트 (Playwright) + 차트 + batch
- v1.3: 외부 history storage (S3/R2)
