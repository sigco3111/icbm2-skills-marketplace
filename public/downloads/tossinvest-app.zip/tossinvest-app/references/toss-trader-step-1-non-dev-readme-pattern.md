# toss-trader 1단계 — 비개발자용 README 5단계 가이드 패턴 (v0.5, 2026-07-10)

> sigco3111/toss-trader의 README v0.6 (비개발자용 5단계 + 🆘 자주 막히는 곳 + 🌐 API endpoint). sigco3111이 다른 토스/개발자 프로젝트 README 쓸 때 본 패턴 그대로 차용. **비개발자가 README만 보고 15분 안에 본인 환경에서 동작하게** = 1차 진입점 기준.

## 1. README 구조 (v0.6 정형화)

```
# 프로젝트명
> 한 줄 설명 1
> 한 줄 설명 2 (기술 스택 요약)
> 한 줄 설명 3 (스택 상세 버전)

[원본/영감 링크](URL) — 영감 받은 프로젝트

📌 **둘 중 하나만 따라 하세요** (분기 안내):
- 비개발자(코딩 모름) → 👉 비개발자 가이드 (5단계, 15분)
- 개발자 → 개발자 섹션으로 스크롤

---

## 🚀 비개발자 가이드 (5단계, 15분)
> 코딩 한 줄도 안 짜고 ... 띄우는 법.
> ... 모두 가능. **중간에 막히면 마지막 🆘 자주 막히는 곳 확인.**

### 1단계 — ... (5분)
> **왜?** 한 줄 설명

| # | 동작 | 화면 위치 |
|---|---|---|
| 1 | ... | ... |
| ... | ... | ... |

> ⚠️ **주의사항 N가지**:
> - **...** (재확인불가/공유금지/메뉴 신청)

```
[예시]
client_id     = toss_a1b2c3d4e5f6g7h8
client_secret = sk_live_9z8y7x6w5v4u3t2s1r0q
```

### 2단계 — ... (1분)
> **왜?** ...

**Mac / Linux** (터미널 앱 열고):
```bash
mkdir -p ~/.hermes/secrets
touch ~/.hermes/secrets/tossinvest.env
chmod 600 ~/.hermes/secrets/tossinvest.env
open -e ~/.hermes/secrets/tossinvest.env     # Mac
# 또는
nano ~/.hermes/secrets/tossinvest.env        # Linux
```

**Windows** (PowerShell):
```powershell
New-Item -ItemType File -Path "$HOME\.hermes\secrets\tossinvest.env" -Force
notepad "$HOME\.hermes\secrets\tossinvest.env"
```

파일 내용:
```
TOSS_CLIENT_ID=...
TOSS_CLIENT_SECRET=...
```

> 📁 **저장 위치 정리**:
> - ✅ 본인 PC: ... (chmod 600, 본인만 읽기)
> - ❌ GitHub/Vercel/클라우드/메신저: **절대 금지**

### 3단계 — ... (3분)
### 4단계 — ... (3분)
### 5단계 — ... (1분)

> ✅ **여기까지 완료! ...**

---

## 🆘 자주 막히는 곳

| 증상 | 원인 | 해결 |
|---|---|---|
| 토스 **"Open API" 메뉴가 안 보여요** | 사전 신청자 대상 단계적 롤아웃 중 | 토스 고객센터에 "Open API 사전 신청" 문의 |
| `client_id`를 **닫고 나서 다시 못 봐요** | 토스 정책 — 재확인 불가 | 1단계 처음부터 재발급 |
| ... 4개 더 | | |

> 그래도 안 풀리면 → [GitHub Issues](URL) 에 다음 4가지 첨부:
> 1. 오류 메시지 전문 (텍스트)
> 2. 어느 단계에서 막혔는지
> 3. OS (Mac/Windows/Linux)
> 4. 브라우저 (Chrome/Safari/Firefox)

---

## 🛠️ 개발자 섹션
(기존 기술 스택/로컬 개발/아키텍처 — 비개발자는 무시)
```

## 2. ★ 7대 패턴 (v0.6 실측 검증)

### 2.1 분기 안내 (맨 위, 비개발자/개발자)

```markdown
> 📌 **둘 중 하나만 따라 하세요**:
> - 비개발자(코딩 모름) → 👉 [🚀 비개발자 가이드 (5단계)](#-비개발자-가이드-5단계-15분)
> - 개발자 → [🛠️ 개발자 섹션](#-개발자-섹션) 으로 스크롤
```

**왜?** 비개발자는 위쪽만 읽으면 끝. 개발자는 스크롤. 한 문서로 두 audience 만족.

### 2.2 단계별 "왜?" 한 줄

```markdown
### 1단계 — 토스증권 Open API 키 발급 (5분)
> **왜?** 토스 서버가 "이 앱이 진짜 sigco3111님이 만든 거 맞아?" 확인하는 열쇠입니다. 두 개가 한 쌍이에요.
```

**왜?** 비개발자는 "왜 이 단계가 필요한지" 모르면 진행을 망설임. 한 줄로 동기부여.

### 2.3 표 형식 단계 (번호 + 동작 + 위치)

```markdown
| # | 동작 | 화면 위치 |
|---|---|---|
| 1 | 브라우저로 [https://www.tossinvest.com](https://www.tossinvest.com) 접속 | — |
| 2 | 본인 토스 계정으로 로그인 | 우상단 |
| 3 | 화면 **좌하단 ⚙️ 설정(톱니바퀴)** 클릭 | 좌하단 |
```

**왜?** 비개발자는 "어디 클릭?" 헷갈려함. 화면 위치 명시로 혼란 제거.

### 2.4 ⚠️ 주의사항 (3~4개 불릿)

```markdown
> ⚠️ **주의사항 3가지**:
> - **client_id / client_secret은 다시 안 보입니다.** 메모장/비밀번호 관리자에 즉시 붙여넣기. 닫으면 재발급.
> - **다른 사람/share 금지.** 이 키로 본인 토스 계좌 거래 가능.
> - **"Open API 메뉴가 안 보여요"** → 토스 고객센터에 "Open API 사전 신청" 문의. 일반 개인도 가능, 사업자등록증 불관.
```

**왜?** 가장 흔한 실수 3가지를 미리 경고. 비개발자 panic 방지.

### 2.5 OS별 분기 (Mac/Linux/Windows)

```markdown
**Mac / Linux** (터미널 앱 열고):
```bash
...
```

**Windows** (PowerShell):
```powershell
...
```
```

**왜?** 명령은 OS마다 다름. 비개발자가 본인 OS에 맞는 블록만 따라하면 됨.

### 2.6 🆘 자주 막히는 곳 (7개 증상 표)

```markdown
| 증상 | 원인 | 해결 |
|---|---|---|
| 토스 **"Open API" 메뉴가 안 보여요** | 사전 신청자 대상 단계적 롤아웃 중 | 토스 고객센터에 "Open API 사전 신청" 문의. 일반 개인도 가능 |
| `client_id`를 **닫고 나서 다시 못 봐요** | 토스 정책 — 재확인 불가 | 1단계 처음부터 재발급 |
| Vercel **Deploy가 빨간색으로 실패** | 의존성 오류 (드묾) | Deploy 로그의 마지막 줄 확인. 대부분 환경변수 오타 |
| ... 4개 더 | | |
```

**왜?** README 단계만 따라하다가 막히는 비개발자 = 90%. 흔한 증상 7개 + 해결을 박아두면 GitHub Issues 부담 감소.

### 2.7 ✅ 완료 신호 (마지막)

```markdown
> ✅ **여기까지 완료! 본인만의 토스 투자 대시보드가 인터넷에 떴습니다.**
```

**왜?** 비개발자는 "성공했는지" 확신이 필요. 명시적 완료 신호로 자존감 ↑ + 다음 행동 가이드.

## 3. 비개발자 친화 마커 모음 (총 19종)

| 마커 | 의미 | 사용 시점 |
|---|---|---|
| 📌 | 분기 안내 | README 맨 위 |
| 🚀 | 비개발자 가이드 시작 | 섹션 헤더 |
| ⚠️ | 주의사항 | 단계 끝 (3~4개 불릿) |
| 💡 | 팁 (예: Fork 설명) | 선택적 |
| 📁 | 위치/저장소 정리 | 단계 끝 |
| ⏱️ | 시간 정보 (예: 빌드 시간) | 대기 단계 |
| ✅ | 완료 신호 | 마지막 단계 끝 |
| 🆘 | 자주 막히는 곳 | 비개발자 가이드 끝 |
| 👉 | 링크/안내 | 분기 + 단계 시작 |
| 🌐 | API endpoint 섹션 | 개발자 섹션 (개발자/에이전트용) |
| 📦 | 외부 자료 (예: docs 링크) | 링크 박을 때 |
| 💬 | 의견/설명 | 일반 |
| 🛠️ | 개발자 도구 섹션 | 개발자 섹션 헤더 |
| 🔒 | 시크릿/보안 | 보안 관련 |
| 🧠 | AI/LLM 관련 | LLM 섹션 |
| 🗂️ | 데이터/이력 | 데이터 기록 |
| 📝 | 메모/이력 | 이력/PR 섹션 |
| 🎬 | 라이브 데모 | 데모 URL |
| 🤖 | 생성 정보 | AI/모델 관련 |

## 4. 단계별 시간 표시 (★ 사용자 부담 감소)

```markdown
### 1단계 — 토스증권 Open API 키 발급 (5분)
### 2단계 — 키를 본인 PC에 안전하게 저장 (1분)
### 3단계 — Vercel 계정 만들기 + GitHub 연동 (3분)
### 4단계 — Vercel에 자동 배포 (3분)
### 5단계 — 대시보드 접속 + 시세 확인 (1분)
```

**왜?** 비개발자는 "이게 얼마나 걸려?" 궁금. 단계별 시간 명시로 "15분 안에 끝난다"는 안심.

## 5. ★ 환경별 명령 박기 (Mac/Linux/Windows)

**원칙**: 비개발자가 본인 OS에 맞는 명령을 복사/붙여넣기 할 수 있도록 **별도 코드 블록**.

**Mac/Linux** (bash):
```bash
mkdir -p ~/.hermes/secrets
touch ~/.hermes/secrets/tossinvest.env
chmod 600 ~/.hermes/secrets/tossinvest.env
open -e ~/.hermes/secrets/tossinvest.env     # Mac
# 또는
nano ~/.hermes/secrets/tossinvest.env        # Linux
```

**Windows** (PowerShell):
```powershell
New-Item -ItemType File -Path "$HOME\.hermes\secrets\tossinvest.env" -Force
notepad "$HOME\.hermes\secrets\tossinvest.env"
```

**함정**: `~/.hermes`를 Windows가 모름 → Windows는 `$HOME\.hermes\secrets\` 사용. 두 환경 모두 박아야 함.

## 6. GitHub Issues 등록 4가지 첨부 (★ 비개발자 escalation)

```markdown
> 그래도 안 풀리면 → [GitHub Issues](https://github.com/.../issues) 에 다음 4가지 첨부:
> 1. 오류 메시지 전문 (텍스트)
> 2. 어느 단계에서 막혔는지 (1~5 중)
> 3. OS (Mac/Windows/Linux)
> 4. 브라우저 (Chrome/Safari/Firefox)
```

**왜?** 비개발자가 Issues 등록할 때 "이거 왜 안 돼요?" 한 줄만 쓰는 패턴. 4가지 양식 강제 = 디버깅 시간 80% 감소.

## 7. 헤딩 정규화 (★ v0.6 검증)

**비개발자 가이드 헤딩 패턴 (혼합 한글 + 영문 OK, 단 anchor 깨짐 없게)**:
- `## 🚀 비개발자 가이드 (5단계, 15분)` — ✅ 통과
- `## 🆘 자주 막히는 곳` — ✅ 통과
- `## 🌐 API endpoint (개발자/에이전트용)` — ✅ 통과
- `## ⚠️ 절대 어기지 말 것 (Red Lines)` — ✅ 통과 (괄호 매칭)

**검증 어서션**:
```bash
bash ~/.hermes/skills/ad-hoc-verifier/scripts/check-kr-en-mixed-headings.sh README.md
# → "✅ KR README 한/영 혼합 헤딩 부재"
```

## 8. 자기 검증 어서션 (v0.5/v0.6 toss-trader 실측)

| 어서션 | 결과 |
|---|---|
| 헤딩 정규화 (bash + python 2중) | 0/0 깨짐 |
| v0.3 자기 검증 (LLM 호출 0줄) | 0건 |
| 외부 링크 (URL 5+) 클릭 가능 | OK |
| 19개 표 (단계 + 자주 막히는 곳 + 동작 비교) | OK |
| 비개발자 친화 마커 (⚠️/💡/📁/📌/✅/⏱️/🆘) | 7종 사용 |

## 9. 재사용 시 체크리스트 (sigco3111 다른 프로젝트)

- [ ] 맨 위에 📌 분기 안내 (비개발자/개발자)
- [ ] 비개발자 가이드 = 5단계 + 단계별 시간
- [ ] 각 단계 시작에 **왜?** 한 줄
- [ ] 각 단계 끝에 ⚠️ 주의사항 3~4개
- [ ] OS별 명령 (Mac/Linux/Windows) 박기
- [ ] 단계별 표 (번호 + 동작 + 위치)
- [ ] 🆘 자주 막히는 곳 7개 증상 표
- [ ] GitHub Issues 4가지 첨부 가이드
- [ ] ✅ 완료 신호 (마지막 단계)
- [ ] 헤딩 정규화 2중 검증 통과
- [ ] 비개발자 친화 마커 5종+
- [ ] 개발자 섹션 (기술 스택/로컬 개발/아키텍처) 맨 아래에 보존
