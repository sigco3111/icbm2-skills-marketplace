# v1.1.4 — 3-모드 단순화 + DoubleConfirmModal 삭제

**날짜**: 2026-07-10
**커밋**: `feat(confirm-mode): v1.1.4 — auto 단순화 (3-모드 복귀, 5초/2차 confirm 제거, 116/116)`

## 핵심 결정

사용자 요청: "자동확인은 실계좌 연결에서도 사용가능하게" + "사용자편의를 위해 자동확인(실계좌)에서 5초대기와 2차 컴펌없이도 처리되도록" → **v1.1.2/v1.1.3의 4-모드(`auto-paper`/`auto-live`) 단순화, `auto` 단일 복귀**.

## v1.1.2/v1.1.3 → v1.1.4 단순화 비교

| 차원 | v1.1.2/v1.1.3 | v1.1.4 |
|---|---|---|
| 모드 수 | 4개 (telegram/auto-paper/auto-live/off) | **3개 (telegram/auto/off)** |
| auto 분기 | auto-paper/auto-live 분리 | **`auto` 단일** |
| 5초 대기 | auto-live 모드 | **제거** |
| 2차 confirm | auto-live 모드 | **제거** |
| doubleConfirmed 게이트 | auto-live 1차/2차 호출 | **제거** |
| `DoubleConfirmModal` 컴포넌트 | 존재 | **삭제** (4692B) |
| `isPaperMode()` 헬퍼 | 존재 | **제거** |
| TOSS_TRADING_MODE 분기 | paper → auto-live 즉시 | **제거 (단순화)** |

## 호환성

- **v1.1.1~v1.1.3 사용자가 v1.1.4로 업그레이드해도 기본값 'telegram'으로 기존 동작 동일** (변경 없음).
- v1.1.2/v1.1.3 옵션 (`auto-paper`/`auto-live`) 사용자가 v1.1.4로 업그레이드 시:
  - localStorage에 저장된 값 무효 → `'telegram'` fallback
  - TDD로 검증: `localStorage 'auto-paper' → 'telegram'`
  - TDD로 검증: `localStorage 'auto-live' → 'telegram'`

## 핵심 디자인 원칙: **이름·동작 일치**

`auto-live`라는 이름에 2차 confirm이 들어가는 것은 **사용자 의도와 모순**:
- "live" = 실계좌 → 안전장치 강화
- "auto" = 자동 → 사용자 개입 없음
- 두 라벨이 충돌 → 5초 대기/2차 confirm은 "auto"의 의미와 모순

**결론**: `auto` 단일로 단순화. 5초/2차 confirm 모두 제거. 실계좌 안전은 Telegram 메시지 (`telegram` 모드) + 가드 5 + 가드 1 (DRY_RUN) + 가드 2 (TRADING_MODE) + 가드 3 (AMOUNT) + 가드 8 (MARKET_HOURS) + 가드 9 (ACCOUNT) + 가드 10 (TELEGRAM_CONFIRM) + audit log로 이미 충분히 다층 방어.

## 3-모드 시스템 (v1.1.4)

| 모드 | Telegram | 사용자 confirm | 가드 5 | 용도 |
|---|---|---|---|---|
| **telegram** (기본) | ✅ 메시지 | [확인] 버튼 | 자동 true | 실전 안전 |
| **auto** | ❌ 안 보냄 | **즉시 confirmed** (5초/2차 confirm 없음) | 자동 true | paper/dev/test/실계좌 즉시 |
| **off** | ❌ 안 보냄 | 안 함 | false → 425 | paper만 |

## 핵심 코드 변경

### lib/settings.ts: 3-모드 + warning 제거
```typescript
export type TelegramConfirmMode = "telegram" | "auto" | "off";
// (warning 필드 제거, 'auto-paper'/'auto-live' 제거)
```

### lib/telegram.ts: auto 단일 분기
```typescript
if (mode === "auto") {
  // v1.1.4: auto 단일 (5초/2차 confirm 없음)
  pending.status = "confirmed";
  return {
    ok: true,
    ...
    message: "TELEGRAM_CONFIRM_MODE=auto 모드. 메시지 발송 없이 즉시 confirmed. paper/dev/test/실계좌 즉시 처리.",
    mode: "auto",
  };
}
// (auto-paper, auto-live, isPaperMode(), req.doubleConfirmed 모두 제거)
```

### components/OrderButton.tsx: confirmMode 단순화
```typescript
interface OrderButtonProps {
  confirmMode: "telegram" | "auto" | "off";
}
// (doubleConfirmed, handleDoubleConfirm, showDoubleConfirm 모두 제거)
```

### components/ConfirmModeToggle.tsx: 3 옵션
```typescript
// 3 옵션 (auto-paper/auto-live 제거, isDevTest/isLiveWarning 뱃지 제거)
```

## 삭제/단순화

- `components/DoubleConfirmModal.tsx` 삭제 (4692B)
- `lib/telegram.ts`: `isPaperMode()` 헬퍼 제거
- `lib/telegram.ts`: `OrderRequest`의 `doubleConfirmed` 필드 제거
- `lib/settings.ts`: `warning` 필드 제거 (TELEGRAM_CONFIRM_MODES)

## 검증 (모두 PASS)

| 어서션 | 결과 |
|---|---|
| `npm run build` | ✅ 5 routes (1387ms) |
| `npm run lint` | ✅ 0 errors, 0 warnings |
| `npm run test` | ✅ **116/116 PASS** (settings 19 + format 31 + safety 25 + telegram 13 + history 12 + stocks 14) |
| 헤딩 정규화 | ✅ 0/0 깨짐 (5파일) |
| v0.3 자기 검증 | ✅ LLM 호출 0줄 |

## TDD 사이클 (settings 19)

- **1차**: 4/19 fail (TelegramConfirmMode 타입 옛 4-모드 호환)
- **2차**: 19/19 PASS

## 커밋 SHA

- `cdeb25f → 9198eb3` (DoubleConfirmModal 삭제)
- `9198eb3 → 99632d3` (settings/telegram/UI/OrderButton/env)
- `6a5f034 → 9198eb3/99632d3` (총 2 커밋)

## 학습 정형화

1. **이름·동작 일치 원칙** — `auto-live`라는 이름이 2차 confirm과 충돌. **사용자 의도와 다른 이름은 단순화의 신호**.
2. **3-모드 단순화의 효과** — 4-모드 2개 (`auto-paper`/`auto-live`) → 1개 (`auto`). `DoubleConfirmModal` 4692B + `isPaperMode()` + `doubleConfirmed` 게이트 모두 삭제. 116/116 PASS 유지.
3. **호환성 TDD 검증** — localStorage `auto-paper`/`auto-live` → `telegram` fallback 명시적 테스트. **기존 사용자 보호 + 새 단순화 양립**.
4. **multi-patch 안전 패턴** — DoubleConfirmModal 5초 카운트다운 + req.doubleConfirmed 게이트 + handleDoubleConfirm 분기 등 동시 다중 patch. **`partial patch > 3번이면 통째로 rewrite` (함정 26) 재확인**.
