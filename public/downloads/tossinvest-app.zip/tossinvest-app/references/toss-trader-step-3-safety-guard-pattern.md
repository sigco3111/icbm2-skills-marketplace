# toss-trader 3단계 — lib/safety.ts 6대 가드 + vitest TDD 패턴

> 2026-07-10 sigco3111/toss-trader v0.7 실측. **6대 외부 가드** (`lib/safety.ts`의 `guardRequest()`) + **vitest 4.1.10 + Next 16** 호환 TDD 25/25 PASS.
> 본 reference는 2단계에서 끝난 toss Open API catch-all relay의 **요청 단위 안전 레이어**. toss.ts의 5대 내장 가드(DRY_RUN/422/429/401/네트워크)와 **이중 방어**.

## 1. 6대 가드 + chain 순서 (★ 환경변수 기반)

| # | 가드 | 환경변수 | 기본값 | 차단 시 |
|---|---|---|---|---|
| 1 | TRADING_MODE | `TOSS_TRADING_MODE` | `paper` | 423 trading-mode-paper / trading-mode-simulation |
| 2 | TRADE_AMOUNT_LIMIT | `TOSS_MAX_TRADE_AMOUNT` | 1,000,000원 | 422 amount-limit-exceeded |
| 3 | MARKET_HOURS | (KST 시간대) | 평일 09:00~15:30 (lunch 12~13) | 422 order-hours-closed |
| 4 | ACCOUNT_TYPE | `TOSS_ACCOUNT_TYPE_OVERRIDE` | 미설정 (통과) | 423 account-restricted |
| 5 | TELEGRAM_CONFIRM | (live 모드 강제) | `body.telegramConfirmed: true` | 425 telegram-confirm-required |
| 6 | AUDIT_LOG | (N/A) | 항상 | (side effect — stdout JSON) |

> **chain 순서가 곧 안전 정책**: 1 → 2 → 3 → 4 → 5. 6은 모든 가드 통과/차단 시점에 side effect. 예: 가드 2(금액) 실패가 가드 3(시간)보다 우선 — 금액이 더 명시적인 위반.

## 2. guardRequest() 시그니처 (★ Next 16 호환)

```ts
export interface GuardRequestInput {
  method: "GET" | "POST" | "PUT" | "DELETE";
  path: string;           // ← toss API path (e.g. "/api/v1/orders")
  body?: unknown;
  headers?: Record<string, string | undefined>;
  now?: Date;             // ← 테스트 주입용 (시간 의존 가드)
}

export function guardRequest(input: GuardRequestInput): GuardResult;
```

`GuardResult`는 `{ ok: true, mode: TradingMode } | { ok: false, httpStatus, error: TossErrorBody }` discriminated union. route.ts에서 `if (!guard.ok) return NextResponse.json(guard.error, { status })` 패턴.

## 3. route.ts 통합 (★ 1줄 패턴)

```ts
import { guardRequest } from "@/lib/safety";

// handle() 진입 직후, tossFetch() 호출 전
const guard = guardRequest({
  method,
  path: tossPath,   // ← joinPath(path) 결과 (반드시 toss API path!)
  body,
  headers: { /* ... */ },
});
if (!guard.ok) {
  return NextResponse.json(guard.error, { status: guard.httpStatus });
}
// → 여기서 통과하면 tossFetch() 호출
```

## 4. TDD 7 describe blocks × 25 tests (★ 3라운드 함정)

### 4.1 라운드 1: 적색 5건 (path prefix + telegramConfirmed)

- 가드 4 일반 계좌 통과 케이스: `telegramConfirmed: true` 누락 → 가드 5에서 차단 (false-FAIL)
- 가드 5 paper 모드 케이스: path를 `/api/toss/api/v1/orders`로 입력 → `isOrderPath` prefix false → 가드 1 통과 → 가드 5 (live 모드 아닐 때) → 통과 (ok: true) → 어서션은 차단 기대 (false-FAIL)
- 가드 2 BUY 통과 / 가드 3 10:00 통과 / 가드 2 SELL 통과: 3건 모두 live 모드 + `telegramConfirmed` 미포함 → 가드 5에서 차단 (false-FAIL)

### 4.2 라운드 2: 적색 3건 (telegramConfirmed 누락)

- 가드 2 BUY 통과, 가드 2 SELL 통과, 가드 3 10:00 통과 — `body: { ...sampleBuyOrder, telegramConfirmed: true }` 박아 통과

### 4.3 라운드 3: 25/25 PASS (그린)

### 4.4 최종 7 describe 분포

| describe | tests | 핵심 검증 |
|---|---|---|
| 가드 1 TRADING_MODE | 4 | paper/live/simulation/unknown |
| 가드 2 TRADE_AMOUNT_LIMIT | 4 | BUY 한도 내/초과, SELL 정상/수량0 |
| 가드 3 MARKET_HOURS | 6 | 장중/장시작전/lunch/장마감/주말/simulation 면제 |
| 가드 4 ACCOUNT_TYPE | 4 | pension/ria/综合매매/일반 |
| 가드 5 TELEGRAM_CONFIRM | 3 | confirmed/unconfirmed/paper |
| 가드 6 AUDIT | 2 | 차단 log/통과 log |
| 통합 (체인 순서) | 2 | 가드 1→2→3→4→5 체인, GET은 모두 통과 |
| **합계** | **25** | **25/25 PASS (vitest 4.1.10, 102ms)** |

## 5. TDD 3대 함정 (★ 정형화)

### 함정 A — live 모드 + telegramConfirmed 누락 (가장 빈번)

```ts
// ❌ round-1/2 적색 패턴
process.env.TOSS_TRADING_MODE = "live";
const r = guardRequest({
  method: "POST",
  path: "/api/v1/orders",
  body: sampleBuyOrder,   // ← telegramConfirmed 없음
  now: kstDate(2026, 7, 10, 10, 0),
});
// → 가드 5 차단 → false-FAIL

// ✅ 통과 케이스
body: { ...sampleBuyOrder, telegramConfirmed: true }
```

**규칙**: live 모드 + 주문 endpoint 통과 검증은 `telegramConfirmed: true` 필수.

### 함정 B — path prefix 오인

```ts
// ❌ 라우트 URL을 path에 입력
path: "/api/toss/api/v1/orders"   // ← isOrderPath prefix false → 가드 1 통과 → 가드 5 통과 (paper) → ok
// 결과: 어서션 "paper 모드에서 차단됨"이 false-FAIL

// ✅ toss API path
path: "/api/v1/orders"            // ← isOrderPath prefix match
```

**규칙**: 테스트 입력 path는 toss API path (`/api/v1/...`). route.ts의 `joinPath(path)`로 변환된 tossPath를 항상 전달.

### 함정 C — `now` 미주입으로 시간 의존 가드 비결론론

```ts
// ❌ now 미주입
const r = guardRequest({
  method: "POST",
  path: "/api/v1/orders",
  body: { ...sampleBuyOrder, telegramConfirmed: true },
  // now 없음 → 가드 3에서 Date.now() 사용 → 토요일/일요일/lunch 시간대면 비결론론 FAIL
});

// ✅ now 주입
function kstDate(year, month, day, hour, minute): Date {
  const utc = Date.UTC(year, month - 1, day, hour - 9, minute, 0);
  return new Date(utc);
}
now: kstDate(2026, 7, 10, 10, 0)  // 금요일 10시 = 장중
```

**규칙**: 시간 의존 가드(가드 3) 테스트는 항상 `now: Date` 주입. `kstDate()` helper로 KST → UTC 변환 명시.

## 6. 시간 변환 helper (KST = UTC+9)

```ts
const KST_OFFSET_MS = 9 * 60 * 60 * 1000;

function kstHourMinute(date: Date): { hour: number; minute: number; weekday: number } {
  const kst = new Date(date.getTime() + KST_OFFSET_MS);
  return {
    hour: kst.getUTCHours(),
    minute: kst.getUTCMinutes(),
    weekday: kst.getUTCDay(), // 0=Sun ... 6=Sat
  };
}
```

> **2026-07-10 = 금요일** (weekday=5). 주말 테스트는 `2026-07-11`(토) / `2026-07-12`(일). 평일 09:00 이전, 12:00~13:00 lunch, 15:30 이후 = 차단. 그 외 09:00~15:30 평일 = 통과.

## 7. 환경변수 셋업 (★ 테스트 간 누수 방지)

```ts
const ENV_BACKUP = { ...process.env };

beforeEach(() => {
  delete process.env.TOSS_TRADING_MODE;
  delete process.env.TOSS_MAX_TRADE_AMOUNT;
  delete process.env.TOSS_TELEGRAM_CHAT_ID;
  delete process.env.TOSS_ACCOUNT_TYPE_OVERRIDE;
  vi.spyOn(console, "log").mockImplementation(() => {});
});

afterEach(() => {
  process.env = { ...ENV_BACKUP };
  vi.restoreAllMocks();
});
```

> vitest는 `process.env` 누수 가능 — 매 테스트 전 `delete`로 reset. `vi.spyOn(console, "log")`로 audit log mock.

## 8. package.json 추가 (★ vitest 셋업)

```json
{
  "scripts": {
    "test": "vitest run",
    "test:watch": "vitest"
  },
  "devDependencies": {
    "vitest": "^4"
  }
}
```

`vitest.config.ts`:

```ts
import { defineConfig } from "vitest/config";
import path from "node:path";

export default defineConfig({
  test: {
    globals: true,
    environment: "node",
    include: ["test/**/*.test.ts"],
  },
  resolve: {
    alias: { "@": path.resolve(__dirname, "./") },
  },
});
```

> tsconfig paths alias (`@/*`) + vitest alias 동시 필요. `globals: true`로 `describe`/`it`/`expect` import 생략.

## 9. 검증 어서션 셋 (★ 4중 — 매 커밋마다)

```bash
# 1) 단위 테스트
npm test

# 2) TypeScript
npx tsc --noEmit

# 3) 빌드
npm run build

# 4) 헤딩 정규화 2중 (docs 파일)
bash ~/.hermes/skills/ad-hoc-verifier/scripts/check-kr-en-mixed-headings.sh README.md AGENTS.md docs/ARCHITECTURE.md docs/OPENAPI_REFERENCE.md
python3 -c "
import re
for f in ['README.md', 'AGENTS.md', 'docs/ARCHITECTURE.md', 'docs/OPENAPI_REFERENCE.md']:
    t = open(f).read()
    bad = re.findall(r'^##+ [^()\n]*[가-힣][^()\n]*[A-Za-z][^()\n]*\$', t, flags=re.MULTILINE)
    bad = [h for h in bad if h.count('(') != h.count(')')]
    print(f'  {f}: {len(bad)} / 0')
"

# 5) v0.3 자기 검증 — Vercel 코드 LLM 호출 0줄
grep -rEn "openai|nim|anthropic|apiKey|BYOK|SettingsForm|ChatPanel" app/ components/ lib/ | grep -v ".gitkeep" || echo "(0건)"
```

> 4중 + 자기 검증 모두 0/0이어야 commit + push 진행. `tossinvest-app` SKILL.md §6 "push BLOCKED 패턴" 준수.

## 10. lint 경고 회피 (★ 미사용 함수 + eslint-disable)

```ts
// 4단계에서 호출 예정인 helper — 즉시 suppress
void getTelegramChatId;
```

```ts
// eslint-disable 제거 — console.log는 audit log 정당
console.log(`[safety] ${line}`);   // ← eslint-disable-next-line no-console 안 박아도 OK
```

> vitest의 `vi.spyOn(console, "log")`가 mock 처리 → 실제 console은 안 찍힘. eslint는 source 그대로 보고 경고 가능. 미사용 함수 = `void` discard, eslint-disable = console.log는 정당하므로 제거.

## 11. 다음 단계 (4단계 진입)

| # | 작업 | 예상 |
|---|---|---|
| 4 | `app/api/telegram/route.ts` (Telegram Bot API + inline button 발송) + `components/OrderButton.tsx` (BUY/SELL + DRY_RUN 토글) | 30분 |
| 5 | `app/page.tsx` + `components/Portfolio.tsx` (시세/잔고 대시보드) | 20분 |

가드 5 (TELEGRAM_CONFIRM)의 `TOSS_TELEGRAM_CHAT_ID`는 4단계에서 사용. `void getTelegramChatId` discard는 4단계에서 제거.

## 12. meta

- **적용 시점**: toss-trader 또는 sigco3111의 다른 토스 투자 프로젝트의 3단계.
- **다른 sigco3111 프로젝트에 차용 시**: `guardRequest()`의 환경변수 이름 (TOSS_TRADING_MODE 등)만 변경하면 그대로 사용 가능. test/safety.test.ts의 7 describe blocks 패턴도 차용.
- **TDD 3라운드 함정**: 본 reference를 보면서도 같은 함정 3건 재발 가능. **첫 적색 → path/telegramConfirmed/now 점검** 순서로 진단.
