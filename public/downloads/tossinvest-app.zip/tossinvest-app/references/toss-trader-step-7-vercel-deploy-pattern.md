# 7단계 — Vercel 배포 + .env.example (v0.9)

> 2026-07-10 실측. README의 비개발자 5단계 가이드 보강 + vercel.json 보일러플레이트 + .env.example gitignore 함정 해결 + 자주 막히는 곳 11개로 확장.

## vercel.json 표준 템플릿

```json
{
  "$schema": "https://openapi.vercel.sh/vercel.json",
  "framework": "nextjs",
  "regions": ["icn1"],
  "buildCommand": "npm run build",
  "installCommand": "npm install",
  "outputDirectory": ".next",
  "trailingSlash": false,
  "cleanUrls": true,
  "headers": [
    {
      "source": "/(.*)",
      "headers": [
        { "key": "X-Content-Type-Options", "value": "nosniff" },
        { "key": "X-Frame-Options", "value": "DENY" },
        { "key": "Referrer-Policy", "value": "strict-origin-when-cross-origin" }
      ]
    }
  ],
  "functions": {
    "app/api/telegram/callback/route.ts": { "maxDuration": 10 },
    "app/api/telegram/send/route.ts": { "maxDuration": 10 },
    "app/api/toss/[...path]/route.ts": { "maxDuration": 10 },
    "app/api/history/route.ts": { "maxDuration": 10 }
  }
}
```

| 설정 | 이유 |
|---|---|
| `regions: ["icn1"]` | Vercel 서울 리전 (한국 latency 최소화) |
| `maxDuration: 10` | Edge Function 기본 10초, sub-second 응답이면 충분 |
| 보안 헤더 | nosniff / DENY frame / strict-origin-when-cross-origin |
| `env` 미포함 | **Vercel 보안 정책상 대시보드/Secrets에서만 주입** (커밋 노출 방지) |

## .env.example (9개 env 키)

```bash
# ─── 토스 Open API (필수, Runtime) ───────────────────────────
TOSS_CLIENT_ID=your_client_id_here
TOSS_CLIENT_SECRET=your_client_secret_here

# ─── 토스 Trading Mode (선택, 기본값 paper) ──────────────────
TOSS_TRADING_MODE=paper
TOSS_MAX_TRADE_AMOUNT=1000000
TOSS_ACCOUNT_TYPE_OVERRIDE=

# ─── Telegram (선택, 미설정 시 dev fallback) ────────────────
TELEGRAM_BOT_TOKEN=your_bot_token_here
TELEGRAM_CHAT_ID=your_chat_id_here
TELEGRAM_CONFIRM_TTL_SEC=300

# ─── 토스 API DRY_RUN (선택, 기본값 true) ──────────────────
DRY_RUN=true
```

## `.gitignore` `.env*` 패턴 함정 (★ v0.9 hotfix 발견)

```gitignore
# ❌ 이렇게만 박으면 .env.example도 차단됨
.env*

# ✅ 정답: 3줄 분할 + 명시적 예외
.env
.env.*
!.env.example
```

v0.9 hotfix commit (`6f4df36`)에서 발견. **.env.example은 git 추적 허용 (실제 값 없음), .env.local/.env.production은 차단** 패턴.

## 비개발자용 4단계 가이드 (README)

| # | 동작 | 위치 |
|---|---|---|
| 1 | GitHub fork | toss-trader 페이지 우상단 Fork |
| 2 | Vercel Sign Up with GitHub | vercel.com |
| 3 | Vercel Add New Project → Import | fork repo 선택 |
| 4 | Environment Variables 6개 추가 (TOSS_CLIENT_ID/SECRET 필수 + TELEGRAM_BOT_TOKEN/CHAT_ID 선택 + TOSS_TRADING_MODE + DRY_RUN) | Project Settings |
| 5 | Deploy | 하단 버튼 |
| 6 | Vercel URL 접속 → Dashboard/History 탭 | 자동 |

## 자주 막히는 곳 (v0.9 — 11개로 확장)

| 증상 | 해결 |
|---|---|
| **"401 Unauthorized"** | 토큰 만료 (1시간). 자동 재발급. 5분 후에도 안 되면 Vercel env 박스에서 `TOSS_CLIENT_ID` 철자 확인 |
| **"history-readonly"** | Vercel serverless filesystem = read-only. **정상**. dev/local 또는 외부 storage 필요 |
| **"telegram-send-failed"** | `TELEGRAM_BOT_TOKEN` / `TELEGRAM_CHAT_ID` 미설정. BotFather 토큰 재확인, chat_id는 @userinfobot |
| **Deploy 빨간색 실패** | env 누락. Deploy 로그 마지막 줄 확인. `TOSS_CLIENT_ID` / `TOSS_CLIENT_SECRET` env 박혔는지 |
| **"422 confirm-high-value-required"** | 1억+ 주문은 `confirmHighValueOrder: true` 헤더 필요. OrderButton 자동 설정 |
| **DRY_RUN=false 인데 주문 안 됨** | 가드 5 (Telegram confirm) 미통과. body에 `telegramConfirmed: true` 또는 Telegram [확인] 클릭 |

## 자동 배포 vs 수동 배포

**자동 (권장)**: GitHub push 시 Vercel 자동 preview + main → prod. `vercel.json`의 `framework: "nextjs"` + GitHub repo 연결만 하면 OK.

**수동 (CLI)**:
```bash
npm i -g vercel
vercel login
vercel link
vercel env add TOSS_CLIENT_ID  # → 값 입력 → Production/Preview/Development 선택
vercel --prod --yes --token $(cat ~/.hermes/secrets/vercel_token.txt)
```

## 다른 sigco3111 Vercel 프로젝트에 차용

vercel.json 표준 템플릿 + .env.example gitignore 3줄 패턴 + regions=icn1 + maxDuration=10 + 보안 헤더 3종은 **다른 Next.js + Toss/Notion/Upbit API 프로젝트에서도 동일 적용 가능**. 차이점:
- regions: 글로벌 사용자는 `iad1` (US East) 또는 `["hnd1", "icn1"]` 등.
- functions maxDuration: 외부 API 응답 느리면 30/60.
- 보안 헤더: Toss는 B2B라 더 강화 가능 (`Strict-Transport-Security` 등).
