# toss-trader v1.2 — Playwright e2e + GitHub Actions (2026-07-10)

v1.2 e2e 테스트 자동화 (Vercel preview URL 자동 검증). 실계좌 영향 zero (mock).

## 산출물 (8 파일)

```
playwright.config.ts (1417B) — chromium + webkit, CI/CD 패턴
test/e2e/helpers/api-mock.ts (6283B) — 토스/Telegram/history 가짜 응답
test/e2e/dashboard.spec.ts (5 tests) — 페이지 로드/매수/History/모드/매도
test/e2e/stock-search.spec.ts (3 tests) — 초기값/NAVER/없는종목
test/e2e/confirm-mode.spec.ts (3 tests) — 기본/자동/off
.github/workflows/e2e.yml (1604B) — GitHub Actions (PR+main)
+ package.json 스크립트 (test:e2e, test:e2e:ui)
+ .gitignore (test-results, playwright-report, .cache)
```

**총 11 e2e tests × 2 browsers (chromium + webkit) = 22 tests PASS**.

## 핵심 결정 (디자인)

| 차원 | 결정 | 이유 |
|---|---|---|
| 도구 | Playwright 1.61.1 + @playwright/test | toss-trader TypeScript 스택 일관성 |
| 프로젝트 | chromium + webkit | macOS Safari 호환 |
| CI | GitHub Actions + Vercel preview URL | PR마다 자동 검증 |
| Mock | setupApiMocks(page) beforeEach | 실계좌 영향 zero |
| baseURL | `PLAYWRIGHT_BASE_URL` env | dev: localhost, CI: Vercel preview |
| webServer | dev 자동 / CI는 Vercel 사용 | 로컬 반복 실행 빠름 |
| retries | CI 2회 / local 0회 | flaky 방지 |
| workers | CI 1 / local default | CI 리소스 절약 |
| reporter | github (CI) / list (local) | CI 로그 가독성 |

## playwright.config.ts 핵심 패턴

```typescript
import { defineConfig, devices } from "@playwright/test";

const PORT = process.env.PORT ?? "3000";
const BASE_URL = process.env.PLAYWRIGHT_BASE_URL ?? `http://localhost:${PORT}`;

export default defineConfig({
  testDir: "./test/e2e",
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: process.env.CI ? 1 : undefined,
  reporter: process.env.CI ? "github" : "list",
  timeout: 30_000,
  expect: { timeout: 5_000 },
  use: { baseURL: BASE_URL, trace: "on-first-retry", screenshot: "only-on-failure", video: "retain-on-failure" },
  projects: [
    { name: "chromium", use: { ...devices["Desktop Chrome"] } },
    { name: "webkit", use: { ...devices["Desktop Safari"] } },
  ],
  webServer: process.env.CI
    ? undefined
    : { command: "npm run dev", url: BASE_URL, reuseExistingServer: !process.env.CI, timeout: 60_000 },
});
```

## api-mock.ts 핵심 패턴 (setupApiMocks)

```typescript
const MOCK_HOLDINGS = {
  result: {
    items: [
      { symbol: "005930", symbolName: "삼성전자", quantity: 10, avgPrice: 70000, currentPrice: 75000 },
      { symbol: "000660", symbolName: "SK하이닉스", quantity: 5, avgPrice: 130000, currentPrice: 135000 },
      { symbol: "035720", symbolName: "카카오", quantity: 20, avgPrice: 50000, currentPrice: 48000 },
    ],
  },
};

const MOCK_PRICES: Record<string, number> = { "005930": 75000, "000660": 135000, "035720": 48000 };

export async function setupApiMocks(page: Page): Promise<void> {
  await page.route("**/api/toss/api/v1/holdings", async (route) => {
    await route.fulfill({ status: 200, contentType: "application/json",
      body: JSON.stringify({ data: MOCK_HOLDINGS, servedAt: new Date().toISOString(), dryRun: true, rateLimit: { limit: 5, remaining: 4, reset: 1 } }) });
  });

  await page.route("**/api/toss/api/v1/prices**", async (route) => {
    const url = new URL(route.request().url());
    const symbols = (url.searchParams.get("symbols") ?? "").split(",").filter(Boolean);
    const result = symbols.map((s) => ({ symbol: s, timestamp: new Date().toISOString(), lastPrice: String(MOCK_PRICES[s] ?? 70000), currency: "KRW" }));
    await route.fulfill({ status: 200, contentType: "application/json", body: JSON.stringify({ data: { result }, ... }) });
  });

  // 모드별 분기 (telegram/auto/off)
  await page.route("**/api/telegram/send", async (route) => {
    const body = JSON.parse(route.request().postData() ?? "{}");
    const mode = body.confirmMode ?? "telegram";
    const orderId = `order_${Date.now().toString(36)}_test`;
    const ok = mode !== "off";
    await route.fulfill({ status: 200, contentType: "application/json",
      body: JSON.stringify({ ok, orderId, devFallback: mode === "telegram" && !body.symbol,
        expiresAt: new Date(Date.now() + 300_000).toISOString(), message: `${mode} 모드 mock`, mode }) });
  });

  // /api/toss/api/v1/orders paper mock
  await page.route("**/api/toss/api/v1/orders", async (route) => {
    const body = JSON.parse(route.request().postData() ?? "{}");
    await route.fulfill({ status: 200, contentType: "application/json",
      body: JSON.stringify({ data: { result: { orderId: `toss-${Date.now()}`, clientOrderId: body.clientOrderId,
        symbol: body.symbol, side: body.side, quantity: body.quantity, price: body.price, status: "FILLED" }},
        servedAt: new Date().toISOString(), dryRun: true }) });
  });
}
```

## dashboard.spec.ts 핵심 (5 e2e tests)

```typescript
import { test, expect } from "@playwright/test";
import { setupApiMocks } from "./helpers/api-mock";

test.describe("Dashboard", () => {
  test.beforeEach(async ({ page }) => { await setupApiMocks(page); });

  test("페이지 로드 시 3-컬럼 표시", async ({ page }) => {
    await page.goto("/");
    await expect(page.getByRole("heading", { name: /toss-trader/ })).toBeVisible();
    await expect(page.getByText(/Portfolio \(계좌 #1\)/)).toBeVisible();
    await expect(page.getByRole("button", { name: "매수" }).first()).toBeVisible();
    await expect(page.getByText(/Telegram confirm 모드/)).toBeVisible();
  });

  test("매수 진행 → confirm 모달 → 발송 → 결과 (auto)", async ({ page }) => {
    await page.addInitScript(() => {
      window.localStorage.setItem("toss-trader:confirm-mode", "auto");
    });
    await page.goto("/");
    await page.getByRole("button", { name: "매수 진행" }).click();
    await expect(page.getByRole("heading", { name: "주문 confirm" })).toBeVisible();
    const modal = page.getByRole("heading", { name: "주문 confirm" }).locator("..");
    await expect(modal.getByText(/005930/)).toBeVisible();
    await page.getByRole("button", { name: "발송" }).click();
    await expect(page.getByText(/주문 성공/)).toBeVisible({ timeout: 10_000 });
  });

  test("매도 클릭 → 수량 10 자동 채움 (v1.1.5)", async ({ page }) => {
    await page.goto("/");
    await page.getByRole("button", { name: "매도" }).first().click();
    const qtyInput = page.locator("#quantity");
    await expect(qtyInput).toHaveValue("10");
  });
});
```

## GitHub Actions (.github/workflows/e2e.yml)

```yaml
name: E2E Tests (Playwright)
on:
  pull_request: { branches: [main] }
  push: { branches: [main] }
  workflow_dispatch:

concurrency:
  group: e2e-${{ github.ref }}
  cancel-in-progress: true

jobs:
  e2e:
    name: Playwright E2E (chromium + webkit)
    runs-on: ubuntu-latest
    timeout-minutes: 15
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: "20", cache: "npm" }
      - run: npm ci
      - run: npx playwright install --with-deps chromium webkit
      - run: npm run build
      - run: npm test  # vitest unit 먼저
      - env:
          PLAYWRIGHT_BASE_URL: ${{ secrets.VERCEL_PREVIEW_URL || 'http://localhost:3000' }}
          CI: "true"
        run: npx playwright test --project=chromium --project=webkit
        continue-on-error: false
      - uses: actions/upload-artifact@v4
        if: always()
        with:
          name: playwright-report
          path: | playwright-report/  test-results/
          retention-days: 7
          if-no-files-found: ignore
```

## 발견한 함정 (v1.2 실측)

### 1. Playwright strict mode `.or()` fail

```typescript
// ❌ strict mode violation: 2 elements 매치 시 fail
await expect(page.getByText(/A/).or(page.getByText(/B/))).toBeVisible();

// ✅ 1) 각 element 별도 검증
await expect(page.getByText("A")).toBeVisible();
await expect(page.getByText("B")).toBeVisible();

// ✅ 2) getByRole('heading', ...) 명시 (unique selector)
await expect(page.getByRole("heading", { name: "주문 confirm" })).toBeVisible();
```

### 2. `addInitScript` vs `evaluate` 차이

```typescript
// ❌ page.goto() 후에 evaluate로 localStorage 설정 → 다음 page reload에서 사라짐
await page.goto("/");
await page.evaluate(() => localStorage.setItem("x", "y"));

// ✅ addInitScript는 page navigation 전에 등록 → 모든 페이지 로드에 적용
await page.addInitScript(() => {
  window.localStorage.setItem("toss-trader:confirm-mode", "auto");
});
await page.goto("/");
```

### 3. 모달 내부 요소 스코프

```typescript
// ❌ 페이지 전체에서 검색 (탭 헤더에도 종목명 표시)
await expect(page.getByText(/삼성전자/)).toBeVisible();

// ✅ 모달 스코프 격리
const modal = page.getByRole("heading", { name: "주문 confirm" }).locator("..");
await expect(modal.getByText(/삼성전자/)).toBeVisible();
```

### 4. `webServer.reuseExistingServer` dev 중복 방지

```typescript
webServer: process.env.CI
  ? undefined  // CI: Vercel preview URL 사용
  : { command: "npm run dev", url: BASE_URL, reuseExistingServer: !process.env.CI, timeout: 60_000 }
```

`reuseExistingServer: !CI` → local에서 dev 이미 떠있으면 재사용 (반복 실행 시 빠름).

### 5. webkit 호환성

- chromium 11/11 PASS, webkit 11/11 PASS — 22/22 PASS
- macOS Safari 호환 (한글 IME, 자동완성 dropdown 위치 등 검증)

## v1.2 검증 결과

| 어서션 | 결과 |
|---|---|
| `npm run build` | ✅ 5 routes (1387ms) |
| `npm run lint` | ✅ 0 errors, 0 warnings |
| `npm run test` (vitest) | ✅ **124/124 PASS** |
| `npx playwright test --project=chromium` | ✅ **11/11 PASS** |
| `npx playwright test --project=webkit` | ✅ **11/11 PASS** |
| 헤딩 정규화 | ✅ 0/0 깨짐 (5파일) |
| v0.3 자기 검증 | ✅ LLM 호출 0줄 |

## 즉시 실행 가이드 (주인님)

```bash
# 1) 로컬 e2e (dev 자동 시작)
cd /Users/mac/work/toss-trader
npx playwright test

# 2) UI 모드 (디버깅)
npx playwright test --ui

# 3) Vercel preview URL로 (CI 환경)
PLAYWRIGHT_BASE_URL=https://toss-trader-git-v120-pr-XX-username.vercel.app npx playwright test

# 4) 단일 spec만
npx playwright test test/e2e/dashboard.spec.ts
```

## 호환성

- v1.1.5 → v1.2 호환 100% (코드 변경 없음, e2e만 추가)
- v0.3 단순화 (LLM 호출 0줄) ✓
- v0.4 단순화 (Notion 제거) ✓
- v1.1.1~v1.1.5 (Telegram confirm 3-모드) ✓
- v1.2 e2e: API 5개 (`/api/toss/*`, `/api/telegram/*`, `/api/history`) 모두 mock 가능
