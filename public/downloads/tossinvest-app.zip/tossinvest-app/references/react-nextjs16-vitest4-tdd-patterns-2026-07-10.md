# React + Next.js 16 + vitest 4 — TDD Specific Patterns (2026-07-10)

`toss-trader` v1.0 → v1.1.2 8단계 + 113 tests 실측에서 발견한 6가지 패턴. tossinvest-app의 React 19 + Next 16 + ESLint 9 환경에서 TDD를 돌릴 때 실전 참조.

## Pattern 1: `setTimeout 0` + clearTimeout cleanup (useEffect 안 setState 우회)

```typescript
// ❌ Lint error: set-state-in-effect
useEffect(() => {
  if (!open) {
    setRemaining(countdownSec);
    return;
  }
  const interval = setInterval(() => {
    setRemaining((r) => Math.max(0, r - 1));
  }, 1000);
  return () => clearInterval(interval);
}, [open, countdownSec]);

// ✅ Lint pass: 마이크로태스크 분리
useEffect(() => {
  if (!open) {
    // setTimeout 0으로 마이크로태스크 분리 (react-hooks/set-state-in-effect 우회)
    const t = setTimeout(() => setRemaining(countdownSec), 0);
    return () => clearTimeout(t);
  }
  const interval = setInterval(() => {
    setRemaining((r) => Math.max(0, r - 1));
  }, 1000);
  return () => clearInterval(interval);
}, [open, countdownSec]);
```

**왜 setTimeout(0)인가**: setState를 effect의 동기 호출이 아니라 **다음 마이크로태스크**으로 미룸. lint는 effect 안의 **즉시 호출**만 차단. cleanup `clearTimeout`이 언마운트 시 setState 호출 방지.

**적용**: 5개 컴포넌트 (Portfolio/OrderButton/StockSearch/ConfirmModeToggle/DoubleConfirmModal) 정형화.

## Pattern 2: `useRef<boolean>(false)` 초기화 1회 (props → state 동기화)

```typescript
// ❌ 무한 채움 루프: useEffect deps에 query 포함 → query 비면 매번 setQuery
useEffect(() => {
  if (defaultSymbol && !query) {
    setQuery(defaultName);
  }
}, [defaultSymbol, defaultName, query]); // query deps → 무한

// ✅ ref 패턴: 마운트 시 1회만
const initializedRef = useRef<boolean>(false);
useEffect(() => {
  if (!initializedRef.current && defaultSymbol) {
    initializedRef.current = true;
    const t = setTimeout(() => setQuery(defaultName), 0);
    return () => clearTimeout(t);
  }
  return undefined;
  // eslint-disable-next-line react-hooks/exhaustive-deps
}, []);
```

**왜 ref인가**: useState는 매번 갱신. useRef는 컴포넌트 인스턴스 수명 동안 유지. **마운트 시 1회만 실행** 보장.

**실측 버그**: StockSearch v1.1에서 `useEffect([defaultSymbol, defaultName, query])` + `if (!query) setQuery(defaultName)` → 사용자가 텍스트 전체 삭제하면 "삼성전자" 자동 채움 → 다른 종목 입력 불가. ref 패턴으로 fix.

## Pattern 3: `Date.now()` in event handler (`react-hooks/purity` 우회)

```typescript
// ❌ Lint error: Cannot call impure function in render
const startPolling = async (orderId: string): Promise<void> => {
  setPolling(true);
  const startTime = Date.now(); // Lint: render에 impure
  // ...
};

// ✅ Lint pass: handler 안은 정당
const startPolling = async (orderId: string): Promise<void> => {
  setPolling(true);
  // eslint-disable-next-line react-hooks/purity -- 이벤트 핸들러 안, render 아님
  const startTime = Date.now();
  // ...
};
```

**왜 handler는 안전한가**: `react-hooks/purity` 룰은 **render 중** 호출만 차단. event handler (`onClick` 등)는 사용자 이벤트 시점 = render 종료 후.

**판단 기준**:
- `useEffect` 안 → ❌ (effect는 render의 일부)
- `useMemo`/`useCallback` deps 함수 안 → ❌ (deps 함수는 render 중 실행 가능)
- `onClick`/`onChange` 등 event handler 안 → ✅ (사용자 이벤트 시점)
- `setTimeout(() => fn(), 0)` 콜백 안 → ✅ (마이크로태스크)
- 일반 async function (`fetch` 후 `.then` 등) 안 → ✅ (Promise 마이크로태스크)

## Pattern 4: vitest 4 + `environment: "node"`에서 localStorage 테스트

```typescript
// vitest.config.ts
export default defineConfig({
  test: {
    environment: "node", // 기본 (jsdom 무거움)
    include: ["test/**/*.test.ts"],
  },
});

// test/settings.test.ts — localStorage mock
const storage: Record<string, string> = {};
const localStorageMock = {
  getItem: (k: string) => storage[k] ?? null,
  setItem: (k: string, v: string) => { storage[k] = v; },
  removeItem: (k: string) => { delete storage[k]; },
  clear: () => { for (const k of Object.keys(storage)) delete storage[k]; },
  // ...
};

beforeEach(() => {
  localStorageMock.clear();
  delete process.env.MY_VAR;
  vi.stubGlobal("window", { localStorage: localStorageMock });
});

afterEach(() => {
  localStorageMock.clear();
  vi.unstubAllGlobals();
});
```

**왜 mock인가**: vitest 4의 `environmentMatchGlobs` 옵션이 없음. `// @vitest-environment jsdom` 주석도 일부 환경에서 무시. `vi.stubGlobal`이 가장 확실.

**작동 원리**: `lib/settings.ts`의 `typeof window !== "undefined"` 분기로 SSR 분기 + `window.localStorage` 호출. vi.stubGlobal로 window 주입 → 분기 통과 → mock 사용.

**vite/vitest 4 환경 비교**:
| 옵션 | vitest 4 | 비고 |
|---|---|---|
| `environment: "jsdom"` (config) | ✅ | 모든 테스트에 적용 (느려짐) |
| `environmentMatchGlobs` | ❌ | vitest 4에서 미지원 |
| `// @vitest-environment jsdom` (per-file) | ⚠️ | 일부 환경에서 무시됨 |
| `vi.stubGlobal('window', mock)` (per-test) | ✅ | 가장 확실, 빠름 |

## Pattern 5: 외부 API 응답 구조 mismatch (배열 vs 객체)

```typescript
// 토스 holdings 응답: { result: { items: [...] } } (객체)
// 토스 prices 응답:   { result: [...] } (배열)
// 둘 다 처리하는 가드

const rawData = (responseBody as ApiEnvelope<unknown>).data;
const items = Array.isArray(rawData)
  ? (rawData as HoldingItem[]) // 배열 직접 응답
  : (rawData as { result?: { items?: HoldingItem[] } })?.result?.items ?? []; // { result: { items } } 응답
```

**왜**: API가 응답 구조를 일관성 없이 제공. 클라이언트가 양쪽 다 처리하면 미래 API 변경에도 안전.

**추가 검증 (가격)**:
```typescript
const priceArr = Array.isArray(rawPriceData) ? rawPriceData : rawPriceData?.result ?? [];
for (const p of priceArr) {
  if (p && typeof p.symbol === "string") {
    const n = Number(p.lastPrice);
    if (Number.isFinite(n)) priceMap[p.symbol] = n; // NaN/Infinity 차단
  }
}
```

**runtime error 실측**: `holdings.reduce is not a function` — 토스 응답이 `{ result: { items: [] } }` 객체인데 클라이언트가 `setHoldings(items)`에 `data` 전체를 넣어 `holdings`가 객체 → `.reduce()` 실패.

## Pattern 6: Partial patch > 5번 → 통째로 rewrite (안전 패턴)

**임계값**: 동일 파일에 3+ partial patch + LSP 에러 → 즉시 `write_file`로 통째로 write.

```
- 1~2개 patch: 일반적
- 3~4개 patch: LSP stale 진단 주의 (이전 write 캐시)
- 5+ patch: 누적 손상 위험. write_file로 통째로 rewrite
```

**예시 (실측)**: OrderButton v1.1.2 patch 시도에서 449 lines 망가짐 (`}` parsing error). `write_file`로 380 lines 정상화. 1개 파일 multi-section patch 누적 손상 패턴.

**판단 기준**:
- `npm run build` 에러 (LSP는 stale일 수 있음) → 무조건 write_file
- `npm run lint` 에러가 3개 파일에 동시 → 누적 손상 의심
- 동일 파일에 같은 lint 에러가 2+ 회차 반복 → 다른 영역 망가진 것

**LSP false positive vs real error 구분**:
- LSP가 stale 진단 throw해도 실제 `npm run build` 통과 → LSP 무시
- LSP가 stale 진단 + `npm run build` 실패 → real error, write_file

## TDD 사이클 실측 (toss-trader v1.0 → v1.1.2)

| 단계 | Tests | Red→Green | 패턴 |
|---|---|---|---|
| 1 (보일러플레이트) | 0 (없음) | - | - |
| 2 (토스 relay) | 0 (통합) | - | Pattern 5 |
| 3 (안전 가드) | 25 | 1차 12→25 | - |
| 4 (Telegram) | 13 | 1차 4→13 | Pattern 1 + test 격리 |
| 5 (Portfolio) | 31 | 1차 3→31 | Pattern 2 |
| 6 (kstost history) | 12 | 1차 5→12 | `process.cwd()` + `_resetPendingStore` |
| 7 (Vercel) | 0 | - | vercel.json JSON 검증 |
| 7.5 (History UI) | 0 | - | - |
| 8 (runtime fix) | 0 | - | - |
| v1.1 (종목 검색) | 14 | 1차 1→14 | Pattern 4 |
| v1.1.1 (Telegram confirm) | 13 | 1차 3→13 | Pattern 1, 2, 4 |
| v1.1.2 (auto-live) | 18 | 1차 4→18 | Pattern 6 |

**총 113 tests** 모두 GREEN. 8+ TDD 사이클 실측.

## 5개 컴포넌트 lint 우회 패턴 적용 현황

| 컴포넌트 | Pattern 1 (setTimeout) | Pattern 2 (useRef) | Pattern 3 (Date.now) |
|---|---|---|---|
| Portfolio | ✅ | - | ✅ startPolling |
| OrderButton | ✅ | - | ✅ startPolling |
| StockSearch | ✅ | ✅ initializedRef | - |
| ConfirmModeToggle | ✅ | - | - |
| DoubleConfirmModal | ✅ | - | - |

**5개 모두에서 Pattern 1이 공통 적용**. 새 React 컴포넌트 작성 시 기본 패턴.

## A35 (clarify invisible choices) 회피 패턴

Telegram UI가 `clarify` 도구의 choices array를 invisible 렌더. **plain text 4옵션 + 추천 marker** + "A" 한 글자만 답해도 진행. 두 번째 clarify 호출 금지.

```
- ❌ clarify(question='A or B?', choices=['A: ...', 'B: ...', ...])
  → Telegram UI에서 choices 안 보임
- ✅ plain text:
  | # | 옵션 | 비고 |
  |---|---|---|
  | **A** ⭐ 추천 | ... | ... |
  | B | ... | ... |
  
  주인님, A로 진행할까요? (A35 회피 — "A" 또는 "진행"이라고만 답하셔도 됩니다.)
```

**3번 재발 패턴** (Telegram/human user 둘 다): 처음 clarify 호출 시 거의 항상 invisible. 두 번째 clarify 호출은 **항상** 안 보임 → 1번만 호출하고 답변은 plain text.

## 일반화 (React/Next.js 외)

이 패턴들은 **Next.js 16 + React 19 + ESLint 9 + vitest 4**에 종속이지만, **React 18+ / Vite / 다른 테스트 러너**에서도 적용 가능:
- Pattern 1: React 18+ 동일
- Pattern 2: React 16+ 동일
- Pattern 3: handler/render 구분만 알면 적용
- Pattern 4: vitest 3+ 동일, jest도 vi → jest 모킹
- Pattern 5: API 어디든 적용
- Pattern 6: 누적 patch 어느 도구든 적용
