# Codex + LazyCodex 통합 실측 노트 (2026-07-09)

toss-trader v0.3 결정 — 개발자 측 도구 통합. 사용자 분석 환경(Vercel Edge Function)과 분리된 별개 채널.

## 1. 설치 (실측)

```bash
# 1) Codex (OpenAI 공식, Homebrew Cask)
brew install --cask codex        # → v0.143.0, /opt/homebrew/bin/codex

# 2) LazyCodex (oh-my-openagent Codex 통합, npx)
npx lazycodex-ai install        # → @sisyphuslabs/omo-codex-plugin@4.16.0
# 23 hooks + 26 skills + 8 agents + 3 MCP servers 자동 등록
# config.toml 자동 패치 (sisyphuslabs marketplace + omO plugin enabled)
```

## 2. Codex 서브커맨드 (25개, v0.143.0)

| 카테고리 | 명령 | 용도 |
|---|---|---|
| 핵심 | `exec` / `e` | 비대화형 실행 (스크립트용) |
| | `review` | PR 리뷰 |
| | `apply` / `a` | diff git apply |
| 세션 | `resume` / `fork` / `archive` / `unarchive` / `delete` | 세션 lifecycle |
| 인증 | `login` / `logout` | ChatGPT OAuth |
| plugin | `plugin add/list/marketplace/remove` | marketplace 관리 |
| MCP | `mcp` / `mcp-server` | stdio MCP |
| 서버 | `app-server` / `remote-control` / `exec-server` / `cloud` | (experimental) |
| 앱 | `app` / `sandbox` / `debug` | 데스크탑/샌드박스/디버그 |
| 도구 | `doctor` / `update` / `features` / `completion` | 환경 진단/업데이트/플래그 |

## 3. OmO plugin 자동 등록 (실측)

`~/.codex/config.toml` 자동 추가:
```toml
[marketplaces.sisyphuslabs]
last_updated = "2026-07-09T10:41:35Z"
source_type = "local"
source = "/Users/mac/.hermes/skills/...cache/sisyphuslabs"

[plugins."omo@sisyphuslabs"]
enabled = true

# MCP servers
[plugins."omo@sisyphuslabs".mcp_servers.context7]  # enabled
[plugins."omo@sisyphuslabs".mcp_servers.codegraph]  # enabled
[plugins."omo@sisyphuslabs".mcp_servers.git_bash]   # disabled

# 23개 hooks (sha256 trusted_hash 등록)
# session_start, user_prompt_submit, pre_tool_use,
# post_tool_use, post_compact, stop, subagent_stop

# 8개 agents
[agents.explorer] / [agents.librarian] / [agents.metis] / [agents.momus]
[agents.plan] / [agents.lazycodex-executor] / [agents.lazycodex-code-reviewer] / [agents.lazycodex-qa-executor]
```

## 4. 26개 skills (실측)

`ultrawork`, `ulw-loop`, `ulw-plan`, `ulw-research`, `start-work`, `review-work`, `refactor`, `debugging`, `programming`, `lsp`, `lsp-setup`, `ast-grep`, `comment-checker`, `frontend`, `git-master`, `init-deep`, `rules`, `visual-qa`, `ultimate-browsing`, `lcx-doctor`, `lcx-report-bug`, `lcx-contribute-bug-fix`, `coding-agent-sessions`, `remove-ai-slops`, `teammode`

## 5. model-catalog.json (실측)

```json
{
  "version": "2026-06-04.gpt-5.5-400k-reviewer-high",
  "current": { "model": "gpt-5.5", "context_window": 400000, "reasoning": "high", "plan_reasoning": "xhigh" },
  "roles": {
    "default":  { "model": "gpt-5.5" },
    "verifier": { "model": "gpt-5.5" },
    "worker":   { "model": "gpt-5.5" }
  }
}
```

## 6. Codex NIM provider 등록 (실측)

NVIDIA plugin marketplace 직접 추가는 `codex plugin marketplace add <path>` 형식의 **절대경로/URL 거부** + **`openai-curated` reserved** 같은 함정. **정공법 = `~/.codex/config.toml` 직접 편집**:

```toml
[model_providers.nim]
name = "NVIDIA NIM"
base_url = "https://integrate.api.nvidia.com/v1"
env_key = "NVIDIA_API_KEY"
wire_api = "openai"
```

env: `export NVIDIA_API_KEY=nvapi-...` 후 `codex exec --provider nim --model "openai/gpt-oss-120b" "..."`.

## 7. Codex doctor 진단 (실측)

v0.143.0 환경 진단 출력:
- ✓ system / runtime / install / search / git / network / reachability 모두 OK
- ✗ config could not be loaded (auth 없으면 config 검증 skip — **의도된 동작**)
- ✗ auth (API key 미설정 — user가 OPENAI_API_KEY/NVIDIA_API_KEY env 설정 필요)

## 8. tossinvest-app과의 관계 (★★ 가장 중요한 정리)

| 차원 | Vercel (사용자 분석) | Codex (개발자 코딩) |
|---|---|---|
| 호출 위치 | `app/api/llm/route.ts` (Edge Function HTTP) | 사용자 PC (TUI/exec) |
| 모델 | NIM/MiniMax/OpenAI (BYOK localStorage) | gpt-5.5 또는 NIM plugin |
| 목적 | 매수/매도 시그널 | Next.js 컴포넌트 자동 생성 |
| 시크릿 | localStorage (영구) | `~/.codex/auth.json` / env |
| 인증 | BYOK (UI 입력) | `codex login` 또는 `OPENAI_API_KEY` env |
| Vercel env | Notion/Telegram bot만 | ❌ Codex 자체는 Vercel 미사용 |

**두 환경은 시크릿 격리 정책 동일 / 호출 인터페이스 분리 / 사용자 인증 분리**. 사용자는 두 곳에서 각각 BYOK 또는 auth.

## 9. 자주 빠지는 함정 4종 (2026-07-09 실측)

1. **`codex plugin marketplace add` 형식** — `owner/repo`, `git URL`, 로컬 path 셋 중 하나. **절대경로 거부**, `openai-curated` 같은 예약된 이름 거부. 정공법 = `config.toml` 직접 편집.
2. **marketplace.json 형식** — `.agents/plugins/marketplace.json` 위치 필수 (root marketplace.json ❌).
3. **doctor의 `config could not be loaded` fail** — auth 없으면 config skip. 의도된 동작, fail 아님. OPENAI_API_KEY env 설정 후 재진단.
4. **NVIDIA plugin 자체는 skills만** — model_providers 등록은 `config.toml`에서 별도. plugin은 skills + assets + .codex-plugin/plugin.json 메타데이터만 제공.

## 10. 1단계 작업 흐름 (★ toss-trader 실제 적용 패턴)

```bash
# 1) Codex로 Next.js 보일러플레이트 자동 생성
codex exec "create Next.js 15 + TypeScript + Tailwind boilerplate for toss-trader"

# 2) BYOK 폼 + localStorage 코드 자동 생성
codex exec "build components/SettingsForm.tsx with localStorage BYOK (4 fields)"

# 3) 토스 Open API relay 자동 생성
codex exec "implement app/api/toss/route.ts for token issuance + quote fetch"

# 4) LLM provider 라우터 자동 생성
codex exec "implement lib/llm/router.ts with NIM/OpenAI/Anthropic provider switching"

# 5) 안전 가드 + 단위 테스트
codex exec "implement lib/safety.ts with 5 guards + 20 vitest unit tests"
```

각 단계 끝나면 `git add ... && git commit -m "..."` (push는 사용자 명시 신호 후, §6 신호 의무).
