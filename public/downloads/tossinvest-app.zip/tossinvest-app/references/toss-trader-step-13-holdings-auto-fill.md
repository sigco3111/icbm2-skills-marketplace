# v1.1.5 — 매도 시 보유 종목 quantity/avgPrice 자동 채움

**날짜**: 2026-07-10
**커밋**: `feat(order): v1.1.5 — 매도 시 보유 종목 quantity/avgPrice 자동 채움 (124/124)`

## 핵심 결정

사용자 요청: "매도 시 보유 종목 + 평균가 자동 채움". 매도 UX가 가장 빈약했음 (수량 직접 입력). **holdings fetch + symbol 매칭으로 sellable quantity 자동 입력** 추가.

## UX 흐름

```
[사용자] "SELL" 클릭
    ↓
[OrderButton.handleSideChange('SELL')]
  - findHoldingBySymbol(holdings, symbol) → 매칭
  - getSellableQuantity(holding) → 보유 수량
    ↓
[수량 input] 자동 입력됨 (사용자 수정 가능)
    ↓
"매도 진행" → confirm 모달 → 발송 → 주문
```

## 핵심 코드

### lib/format.ts: 3개 exports
```typescript
export interface HoldingItem {
  symbol: string;
  symbolName?: string;
  quantity: number;
  avgPrice: number;
  currentPrice?: number;
}

export function findHoldingBySymbol(
  holdings: ReadonlyArray<HoldingItem>,
  symbol: string
): HoldingItem | undefined {
  if (!symbol) return undefined;
  return holdings.find((h) => h.symbol === symbol);
}

export function getSellableQuantity(holding: HoldingItem | undefined): number {
  if (!holding) return 0;
  return Math.max(0, Math.floor(holding.quantity));
}
```

### components/OrderButton.tsx: holdings fetch + 자동 채움
```typescript
// 30초 polling
useEffect(() => {
  const t = setTimeout(() => { void fetchHoldings(); }, 0);
  const interval = setInterval(() => { void fetchHoldings(); }, 30_000);
  return () => { clearTimeout(t); clearInterval(interval); };
}, [fetchHoldings]);

// SELL 선택 시 자동 채움
const handleSideChange = (newSide: Side): void => {
  setSide(newSide);
  if (newSide === "SELL") {
    const holding = findHoldingBySymbol(holdings, symbol);
    if (holding) {
      const sellable = getSellableQuantity(holding);
      if (sellable > 0) setQuantity(sellable);
    }
  } else {
    setQuantity(10); // BUY 복귀
  }
};
```

## 새 테스트 (8개, format 31 → 39)

```
✓ findHoldingBySymbol: 매칭 → holding 반환
✓ findHoldingBySymbol: 없는 symbol → undefined
✓ findHoldingBySymbol: 빈 symbol → undefined
✓ findHoldingBySymbol: 빈 holdings → undefined
✓ getSellableQuantity: holding 있음 → quantity 그대로
✓ getSellableQuantity: undefined → 0
✓ getSellableQuantity: 음수 → 0 (방지)
✓ getSellableQuantity: 소수 → 내림 (Math.floor)
```

## 검증 (모두 PASS)

| 어서션 | 결과 |
|---|---|
| `npm run build` | ✅ 5 routes |
| `npm run lint` | ✅ 0 errors, 0 warnings |
| `npm run test` | ✅ **124/124 PASS** (format 39 + settings 19 + safety 25 + telegram 13 + history 12 + stocks 14) |

## 발견된 함정 (정형화)

### HoldingItem 중복 정의 (함정 39)
`components/Portfolio.tsx`와 `lib/format.ts` 둘 다 같은 인터페이스 정의. v1.2+ 통합 권장: `lib/types.ts`로 단일화. 현재는 단순화 위해 양쪽 유지 (OrderButton은 format.ts에서 import, Portfolio는 자체 정의). **1개 인터페이스 변경 시 2곳 동시 수정 필요**.

### holdings fetch 중복 (함정 41)
Portfolio 10초 + OrderButton 30초 polling. v1.2+ Portfolio→Home→OrderButton 단일 fetch 통합 (React Context 또는 props drilling 권장).

### 즉시 fetch 시 마운트 직후 0~1초 사이 매칭 실패 가능
30초 polling이라 마운트 직후 0~1초 사이 매칭 실패 가능. `useEffect` 즉시 fetch는 하되 1초 내 도착하므로 실사용 영향 적음.

## 가격(price)은 자동 채움 안 함

- **수량만 자동** (보유 수량만큼 매도 가능)
- **가격은 현재가 그대로 유지** (사용자 수정 가능)
- 사용자가 매도 시장가로 원하는 경우 현재가 그대로 → 시장가 주문
- 사용자가 매도 지정가로 원하는 경우 가격 input 수정

이유: 가격 자동 입력은 사용자 의도 손상 가능 (지정가 vs 시장가). 수량은 **보유량 한도 내**라 안전.

## avgPrice는 OrderButton 안에서 사용 안 함

매도 가격은 `price` (현재가) 사용. `avgPrice`는 표시 안 함.

v1.2+ 참고용 avgPrice 표시 가능: "평단가 70,000원, 현재가 75,000원, 손익 +5,000원/주 (+7.14%)" 같은 라벨 추가.

## 커밋 SHA

- `99632d3 → 8229af2` (단일 커밋, +146 -4 lines)

## 학습 정형화

1. **v0.3 단순화 일관성** — LLM 호출 0줄, BYOK 폼 0, OpenCode 글로벌 디폴트. 매도 자동 채움은 토스 Open API holdings 호출만. **v0.3 철학 일치**.
2. **단일 fetch 통합 (v1.2+ 권장)** — 현재 Portfolio + OrderButton 둘 다 holdings fetch. 단일 fetch + props/Context로 통일 가능.
3. **가격 자동 입력 안 함 = 안전** — 수량은 보유량 한도 (안전). 가격은 의도 손상 가능 → 사용자 수동.
4. **`Math.floor`로 소수 수량 방지** — 토스 API가 quantity를 float로 반환할 가능성. 10.7주 → 10주.
