# toss-trader v1.1 — 종목 검색 자동완성 패턴 (2026-07-10 실측)

## 배경

v1.0까지 005930 (삼성전자) 하드코딩. v1.1에서 **어떤 종목이든 매수/매도 가능**하도록 동적 종목 선택.

## 핵심 발견: 토스 Open API는 검색 endpoint 없음

**openapi.json 4중 교차 검증** (`/api/v1/stocks` 파라미터 분석):
- `?query=삼성` ❌ 미지원
- `?keyword=삼성` ❌ 미지원
- `?search=삼성` ❌ 미지원
- `?symbols=005930` (정확 코드) ✅ **유일하게 지원**
- `rankings?query=...` ❌ 미지원 (필수 파라미터 요구)
- search/autocomplete endpoint **0개**

→ **검색 endpoint로 부적합**. 정적 마스터 + 클라이언트 사이드 fuzzy 검색으로 우회.

## 구현 패턴

### 1) `lib/stocks.ts` — 정적 마스터 + fuzzy 검색

```typescript
export interface StockMaster {
  symbol: string;
  name: string;
  market: "KR" | "US";
}

export const STOCK_MASTER: StockMaster[] = [
  { symbol: "005930", name: "삼성전자", market: "KR" },
  { symbol: "000660", name: "SK하이닉스", market: "KR" },
  // ... 31개 (KOSPI 시총 상위 + 대형주)
];

export function searchStocks(query: string, limit = 10): StockMaster[] {
  const q = normalize(query);  // trim + lowercase + NFC
  if (!q) return STOCK_MASTER.slice(0, limit);

  // 1) symbol 정확 매치
  const exact = STOCK_MASTER.filter((s) => s.symbol === q);
  if (exact.length > 0) return exact;

  // 2) 이름 prefix 매치
  const prefix = STOCK_MASTER.filter((s) => normalize(s.name).startsWith(q));
  if (prefix.length > 0) return prefix.slice(0, limit);

  // 3) 이름 contains 매치
  return STOCK_MASTER.filter((s) => normalize(s.name).includes(q)).slice(0, limit);
}
```

**3단계 매칭 우선순위**: symbol 정확 > 이름 prefix > 이름 contains. 사용자 의도와 가장 가까운 매치 먼저.

### 2) `components/StockSearch.tsx` — 자동완성 dropdown

**UX 패턴**:
- 200ms debounce (타이핑 멈추면 검색)
- 키보드 네비게이션 (↑↓ Enter Esc)
- 외부 클릭 시 dropdown 닫기
- `role="listbox"` / `role="option"` / `aria-selected` (접근성)
- 선택 시 `/api/toss/api/v1/prices?symbols=...` 자동 fetch → currentPrice 설정
- "매칭 없음" 메시지 (`query.length > 0` && `results.length === 0`)

```typescript
const handleSelect = async (s: StockMaster): Promise<void> => {
  setQuery(s.name);
  setOpen(false);
  try {
    const res = await fetch(`/api/toss/api/v1/prices?symbols=${s.symbol}`);
    const body = await res.json();
    const raw = body?.data?.result;
    const price = Number(raw?.[0]?.lastPrice ?? 0);
    onSelect(s.symbol, s.name, Number.isFinite(price) && price > 0 ? price : 0);
  } catch {
    onSelect(s.symbol, s.name, 0);
  }
};
```

**currentPrice 자동 fetch** (★★): 종목 선택 시 사용자가 가격을 직접 입력 안 해도 됨. 토스 API 응답에서 `lastPrice` (string) → `Number()` 변환 + `Number.isFinite()` 검증.

### 3) OrderButton 통합 — props → state

**Before (v1.0)**:
```typescript
export function OrderButton({ symbol, symbolName, currentPrice }: OrderButtonProps) {
  const [price, setPrice] = useState<number>(currentPrice);
  // ... symbol 하드코딩
}
```

**After (v1.1)**:
```typescript
export function OrderButton({ symbol: initialSymbol, symbolName: initialName, currentPrice: initialPrice, onSymbolChange }: OrderButtonProps) {
  const [symbol, setSymbol] = useState<string>(initialSymbol);
  const [symbolName, setSymbolName] = useState<string>(initialName ?? "");
  const [price, setPrice] = useState<number>(initialPrice);

  // 종목 선택 시 currentPrice 업데이트 + 부모(Home)에 알림
  const handleStockSelect = (newSymbol, newName, newPrice) => {
    setSymbol(newSymbol);
    setSymbolName(newName);
    if (newPrice > 0) setPrice(newPrice);
    onSymbolChange?.(newSymbol, newName, newPrice);
  };

  return (
    <div>
      <StockSearch onSelect={handleStockSelect} defaultSymbol={symbol} defaultName={symbolName} />
      {/* ... 매수/매도 UI */}
      <div>현재가 (자동): {price.toLocaleString()}원</div>
      <label>주문가 (수정 가능): <input value={price} onChange={...} /></label>
    </div>
  );
}
```

**`onSymbolChange` 콜백**: OrderButton의 종목 선택이 Portfolio + History에도 반영되도록 부모(Home)에 알림.

### 4) `app/page.tsx` — 동적 symbolFilter

```typescript
const [selectedSymbol, setSelectedSymbol] = useState<string>("005930");
const [selectedSymbolName, setSelectedSymbolName] = useState<string>("삼성전자");
const [selectedPrice, setSelectedPrice] = useState<number>(70000);

const handleSymbolChange = (symbol, name, price) => {
  setSelectedSymbol(symbol);
  setSelectedSymbolName(name);
  if (price > 0) setSelectedPrice(price);
};

<Portfolio accountSeq={1} symbolFilter={selectedSymbol} />
<OrderButton
  symbol={selectedSymbol}
  symbolName={selectedSymbolName}
  currentPrice={selectedPrice}
  onSymbolChange={handleSymbolChange}
/>
<History symbolFilter={selectedSymbol} />
```

**3-way sync**: 종목 선택 → Portfolio (symbolFilter) + History (symbolFilter) + OrderButton (price) 동시 업데이트.

## TDD 사이클 (14 tests)

| Round | 결과 | 핵심 교훈 |
|---|---|---|
| 1 | 1/14 fail | STOCK_MASTER 29개 (1개 빠짐) — 작성 시 실수 |
| 2 | 14/14 PASS | 삼성전자 + 카카오 + 기아 추가 = 31개 |

**핵심 테스트**:
- `정확한 symbol 매치 (005930) → 1개` — symbol 입력 시 즉시 매칭
- `이름 prefix '삼성' → 삼성 계열 4개` — prefix 매칭 우선
- `이름 contains '하이닉스' → SK하이닉스 1개` — contains fallback
- `공백 trim + 소문자 정규화` — "NAVER" = "naver" 결과 동일
- `매칭 없음 → 빈 배열` — graceful (에러 throw X)
- `STOCK_MASTER 31개, unique symbols, 005930 포함` — 마스터 무결성

## 발견한 함정 (★ 4번째 useState-in-useEffect 사례)

1. **JS 숫자 separator 8자리 vs 9자리 함정 (재확인)**: `1_0000_0000` (8자리) = 1억 ≠ `1_000_000_000` (9자리) = 10억. `STOCK_MASTER.length === 31` 어서션이 1자 빠진 차이로 29로 fail. **테스트에 자릿수 + 단위 주석 필수**: `1_0000_0000 // 1억` (8자) vs `1_0000_0000_0000 // 1조` (12자).

2. **defaultSymbol prop useState useEffect setState lint 함정**: StockSearch의 `useEffect` 안에서 `setQuery(defaultName)` 호출이 `react-hooks/set-state-in-effect` lint 위반. **`setTimeout(0)` 마이크로태스크 분리 + cleanup**: 
   ```typescript
   useEffect(() => {
     if (defaultSymbol && !query) {
       const t = setTimeout(() => setQuery(defaultName), 0);
       return () => clearTimeout(t);
     }
     return undefined;
   }, [defaultSymbol, defaultName, query]);
   ```
   `eslint-disable` (purity / exhaustive-deps 둘 다) 우회 안 됨. **이 패턴은 Portfolio/OrderButton/History/StockSearch 4개 컴포넌트에서 동일하게 사용** (v1.1 4번째 사례). **정형화: 다음 useState-in-useEffect 상황에서도 setTimeout(0) 우선 적용**.

3. **Portfolio `symbolFilter` prop 미선언**: `app/page.tsx`에서 `<Portfolio symbolFilter={...} />` 전달했지만 Portfolio 함수 시그니처에 prop 없음 → TS compile error. **수정: Portfolio 함수 시그니처에 `{ accountSeq?, symbolFilter? }` 추가 + filteredHoldings.reduce로 매칭 종목만 요약 계산**. `symbolFilter` 미사용 lint warning은 이걸로 해결.

4. **OrderButton `currentPrice` prop → `initialPrice` rename**: `<OrderButton currentPrice={70000} />` 호출 → `function OrderButton({ currentPrice })` 자동 destructure. **수정: `function OrderButton({ symbol: initialSymbol, symbolName: initialName, currentPrice: initialPrice })` rename** (props를 useState 초기값으로 사용). **패턴: props → state 변환 시 `_init` suffix 또는 rename으로 의도 명확히**.

5. **currentPrice 자동 fetch 실패 시 fallback**: 토스 API 응답 실패 (네트워크/401/500) → `onSelect(symbol, name, 0)`. UI는 가격 0 + "수정 가능" 라벨로 graceful. **자동 fetch는 편의, 수동 입력은 fallback**.

6. **`currentPrice` 자동 + `주문가` 수정 가능 분리 (★★)**: `자동 fetch된 현재가`는 표시용, `실제 주문가`는 별도 input. 사용자가 시장가/지정가 자유롭게 변경 가능. 라벨로 명확히 구분: "현재가 (자동)" vs "주문가 (수정 가능)".

## 다른 sigco3111 프로젝트로의 차용

| 차원 | v1.1 패턴 | 재사용 |
|---|---|---|
| **정적 마스터 + fuzzy 검색** | `STOCK_MASTER` + 3단계 매칭 | 다른 KOSPI/KOSDAQ/US 종목, 환율, 지수 등에도 동일 |
| **200ms debounce 자동완성** | `setTimeout` + cleanup | 다른 검색 input에도 |
| **키보드 네비게이션** | ↑↓ Enter Esc | 모든 listbox |
| **currentPrice 자동 fetch** | 선택 시 백그라운드 fetch | 다른 종목/자산 가격 fetch |
| **3-way sync (state 공유)** | 부모 state + child onChange | 여러 컴포넌트가 같은 데이터 의존 시 |
| **useState-in-useEffect setTimeout 0 패턴** | setTimeout + cleanup | 모든 useEffect 안 setState |

## 자기 진단 (검증 어서션)

```bash
cd /Users/mac/work/toss-trader
npm test -- test/stocks.test.ts  # 14 tests PASS
npm run build                    # 5 routes OK
npm run lint                     # 0 errors

# 검색 동작 확인
curl -s "http://localhost:3000/api/toss/api/v1/stocks?symbols=005930"  # 토스 API 동작
# → 200 OK + { result: [{ symbol, lastPrice, ... }] }
```

## v0.3 자기 검증 + 4번째 fix

v0.3 자기 검증 (LLM 호출 0줄) 자동 통과. **v1.1 신규 자기 검증**: 
- `grep -rEn "openai|nim|anthropic|apiKey|BYOK" app/ components/ lib/ | grep -v ".gitkeep"` → 0건
- 4번째 fix: **JS 숫자 separator 함정** (위 1번). 패턴 정형화: **테스트 자릿수 비교 시 `_0000_0000` (8자) ≠ `_000_000_000` (9자) ≠ `_0000_0000_0000` (12자)** — 항상 단위 주석 동반.

## 다음 작업 (v1.2+)

- **여러 종목 동시 매수** (배치): `/api/toss/api/v1/orders` 다중 호출 또는 order basket UI
- **차트/캔들** (`/api/v1/candles`): 종목 검색 후 캔들 차트 표시
- **STOCK_MASTER 자동 업데이트**: 토스 Open API에 종목 마스터 동기화 endpoint 생기면 cron 자동 갱신 (현재는 수동)
- **STOCK_MASTER 확장**: KOSDAQ + US 주식 + ETF 추가 (현재 31개 KOSPI만)
