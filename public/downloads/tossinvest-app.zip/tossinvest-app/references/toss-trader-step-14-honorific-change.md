# 호칭 변경 "주인님 → 주인님" (2026-07-10)

## 사용자 요청

> "그리고 호칭은 주인님 대신 주인님으로 변경하도록 기억해"

## 적용 범위

다음 위치 모두 일관 적용:
- USER_PROFILE (memory)
- 시스템 프롬프트 (Heredity/Role)
- tossinvest-app SKILL body
- 모든 응답 (응답 시 "주인님" 사용)
- commit 메시지 ("주인님 승인", "주인님 요청" 등)
- docs/ (README, AGENTS, ARCHITECTURE, RELEASE_NOTES, OPENAPI_REFERENCE)
- 메모리 (USER_PROFILE + system prompt)

## 검증

```bash
cd ~/work/toss-trader && grep -r "주인님" --include="*.md" --include="*.ts" --include="*.tsx" | head
# 0건 확인
```

## 적용 시점

v0.10+ 새 문서 작성 시 "주인님" 강제. v0.9 이하 기존 문서 (v0.3, v0.4, v0.5, v0.6, v0.7, v0.7.5, v0.8) 작성 시점의 "주인님"는 일관성 위해 그대로 두거나 일괄 변경.

## 학습 정형화 (함정 42)

호칭 변경은 **명시적 사용자 요청**으로만 적용 (자동 추정 ❌). **새 호칭의 일관성**:
- 시스템 프롬프트 + 메모리 + 응답 + commit + docs 5곳 동시
- grep "주인님" → 0건 확인으로 검증

**A35b (clarify 2번째) 시그니처 강화**: 호칭 같은 환경 변수도 **첫 번째 응답부터 일관 적용** 권장 (Telegram UI가 choices를 가끔 invisible하게 렌더하므로 첫 번째 plain-text가 안전).
