# 6단계 — Notion 제거 + kstost/stock 원본 history.ts 패턴 (v0.8)

> 2026-07-10 실측. toss-trader에서 v0.2 ~ v0.7까지 "Notion DB에 이력 기록" 예정이었으나 사용자 코렉션으로 **Notion 완전 제거 + kstost/stock 원본 `lib/history.ts` (로컬 JSON) 방식 채택**. Vercel serverless filesystem 제약 (read-only/ephemeral) + kstost 호환성 + 단순화 세 가지 모두 만족.

## 결정 흐름

1. **kstost/stock의 `lib/history.ts` 조사** — `gh api repos/kstost/stock/contents/lib/history.ts`로 raw fetch. 패턴: `history/<epochSeconds>.json` 형식, 1 record = 1 파일, `flag: "wx"` exclusive create + EEXIST counter suffix.
2. **사용자 코렉션 (2026-07-10)**: "노션 기능은 제거하고 원본 방식으로만 하자" → 즉시 v0.8 단순화.
3. **Vercel 제약 확인** — serverless filesystem = read-only + ephemeral. `writeHistory()`는 Vercel에서 `EACCES`/`EROFS` 실패 가능. **`checkHistoryAvailability()` 3-state graceful (`available` | `readonly` | `disabled`)** 도입.
4. **TDD 사이클** — 4라운드 (12 tests): (1) historyDir 모듈 import 시점 캡처 → getHistoryDir() 동적 함수, (2) 테스트가 옛날 historyDir 직접 사용 → sed 일괄 교체, (3) TTL=0 만료 → expiresAt <= now 정책 + 1ms setTimeout, (4) 시크릿 테스트 어서션 실수 (`expect(content).toContain("dirty")`) → v0.3 단순화 의도 정정.
5. **docs 4파일 일관 정리** — AGENTS.md / README.md / ARCHITECTURE.md / OPENAPI_REFERENCE.md 모두 Notion 섹션 제거. (OPENAPI_REFERENCE는 v0.6 이전이었고, v0.8에서 Notion 언급만 일관 제거.)

## kstost/stock 원본 패턴 (그대로 차용 + v0.3 시크릿 격리)

```ts
// lib/history.ts (v0.3 단순화)
import fs from "node:fs/promises";
import path from "node:path";
import type { HistoryRecord } from "./types";

// 동적 계산 (테스트 격리 + Vercel cwd 변경 대응)
export function getHistoryDir(): string {
  return path.join(process.cwd(), "history");
}

// 하위 호환 (모듈 import 시점)
export const historyDir = getHistoryDir();

export async function writeHistory(record: HistoryRecord): Promise<string> {
  const dir = getHistoryDir();
  await fs.mkdir(dir, { recursive: true });
  const base = `${record.epochSeconds}.json`;
  let filename = base;
  let counter = 2;
  while (true) {
    const target = path.join(dir, filename);
    try {
      await fs.writeFile(target, `${JSON.stringify(record, null, 2)}\n`, {
        flag: "wx", // exclusive create — 이미 있으면 EEXIST
      });
      return filename;
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== "EEXIST") throw error;
      filename = `${record.epochSeconds}-${counter}.json`;
      counter += 1;
    }
  }
}

export async function checkHistoryAvailability(): Promise<HistoryAvailability> {
  try {
    const dir = getHistoryDir();
    await fs.mkdir(dir, { recursive: true });
    const testFile = path.join(dir, ".write-test");
    await fs.writeFile(testFile, "test", { flag: "wx" });
    await fs.unlink(testFile).catch(() => undefined);
    return "available";
  } catch (e) {
    const code = (e as NodeJS.ErrnoException).code;
    if (code === "EACCES" || code === "EROFS" || code === "EPERM") return "readonly";
    return "disabled";
  }
}
```

## v0.3 단순화 차이 (kstost vs toss-trader)

| 차원 | kstost/stock 원본 | toss-trader v0.8 |
|---|---|---|
| **시크릿 보관** | ❌ `SessionState.apiKey`/`secretKey` 평문 저장 (Session에 보존) | ✅ 시크릿 0. 호출자 책임. lib/history.ts는 strip 안 함. |
| **Record 종류** | `analysis` + `order` (2종) | `analysis` + `order` + **`snapshot`** (3종) |
| **Vercel 제약** | ❌ 미고려 (로컬 only) | ✅ `checkHistoryAvailability()` 3-state + graceful |
| **path 동적 계산** | ❌ `const historyDir = ...` 모듈 import 시점 | ✅ `getHistoryDir()` 동적 함수 (테스트 격리 대응) |

## API route (`app/api/history/route.ts`)

```ts
export async function GET(req: NextRequest): Promise<NextResponse> {
  const url = new URL(req.url);
  const kind = url.searchParams.get("kind");
  const symbol = url.searchParams.get("symbol");
  const limit = Math.max(1, Math.min(1000, Number(url.searchParams.get("limit") ?? 100)));

  const availability = await checkHistoryAvailability();
  if (availability !== "available") {
    return NextResponse.json({
      code: `history-${availability}`,
      message: "Vercel/readonly filesystem: history 비활성화",
      availability,
      records: [],
    }, { status: 200 });
  }

  const records = kind ? await listHistoryByKind(kind, limit)
                : symbol ? await listHistoryBySymbol(symbol, limit)
                : await listHistory(limit);
  return NextResponse.json({ availability, count: records.length, records, servedAt: new Date().toISOString() });
}

export async function POST(req: NextRequest): Promise<NextResponse> {
  const body = await req.json();
  // body.record: HistoryRecord 검증
  // checkHistoryAvailability() → graceful
  // writeHistory() → filename 반환
}
```

## OrderButton 자동 history 기록

```ts
// components/OrderButton.tsx executeOrder() 끝에
try {
  const record: OrderHistoryRecord = {
    kind: "order",
    epochSeconds: Math.floor(Date.now() / 1000),
    createdAt: new Date(epochSeconds * 1000).toISOString(),
    orderId,  // lib/telegram.ts의 orderId
    request: { symbol, side, quantity, price, orderType: "LIMIT", telegramConfirmed: true },
    response: { ok: true, httpStatus: res.status, body: data },
  };
  await fetch("/api/history", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ record }),
  }).catch(() => undefined);
} catch {
  // history write 실패는 주문 자체에 영향 없음 (silent)
}
```

## TDD 사이클 4라운드 (12 tests)

1. **1차 12/12 fail** — `historyDir` 모듈 import 시점 vs `process.chdir()` 타이밍. → `getHistoryDir()` 동적 함수로 변경.
2. **2차 5/12 fail** — 테스트가 옛날 `historyDir` 직접 import (static) → `getHistoryDir()` 호출로 sed 일괄 교체.
3. **3차 1/12 fail** — `TTL=0` 만료 안 됨 (`v > 0` strict). → `v >= 0` 정책 + 1ms setTimeout (또는 `vi.useFakeTimers()`).
4. **4차 12/12 PASS** — 시크릿 테스트 어서션 정정: `expect(content).toContain("dirty")` → `expect(content).toContain("sk-leak")` (v0.3 의도 정직하게).

## 디렉토리 셋업

```bash
mkdir -p history
cat > history/.gitkeep <<'EOF'
# toss-trader history 디렉토리 (kstost/stock 원본 방식)
# - 각 record = 1 JSON 파일
# - 파일명: <epochSeconds>.json (또는 <epochSeconds>-<counter>.json)
# - 절대 추적 금지: history/*.json (Vercel ephemeral, .gitignore에서 처리)
EOF
```

`.gitignore` (이미 처리됨):
```
# Project runtime
history/*.json
!history/.gitkeep
```

## v0.8 History 탭 UI (`components/History.tsx`, v0.9)

5초 polling으로 `GET /api/history?limit=50&kind=order&symbol=005930` 조회. 3종 filter (kind 전체/주문/분석/스냅샷 + limit 20/50/100 + symbolFilter prop). availability 경고 UI (readonly/disabled). `app/page.tsx`의 Dashboard/History 탭 네비게이션으로 접근 (`role="tab"`/`aria-selected`).

## 다른 sigco3111 프로젝트에 차용 가능

본 reference는 toss-trader 6단계만의 노트가 아니라 **kstost/stock 호환 local-JSON history 패턴** 그 자체의 정형화. 다른 sigco3111 프로젝트 (예: crypto 트레이딩, 부동산 분석)도 Vercel serverless + read-only filesystem에서 동일한 패턴 적용 가능. 차이점:
- `HistoryRecord` 종류는 도메인에 따라 다름 (예: 부동산이면 `listing`/`inquiry`/`offer` 등).
- `checkHistoryAvailability()` 자체는 재사용.
- Vercel 외부 storage 필요 시 S3/R2 어댑터 추가 (v0.5+ TODO).
