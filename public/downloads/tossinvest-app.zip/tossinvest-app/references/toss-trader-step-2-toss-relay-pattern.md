# toss-trader 2단계 — 토스 Open API catch-all relay 패턴 (v0.5, 2026-07-10)

> sigco3111/toss-trader의 2단계 (toss Open API relay) 실측 노트. sigco3111이 다른 토스 투자 프로젝트 만들 때 본 reference 그대로 복사 가능. `lib/toss.ts` + `app/api/toss/[...path]/route.ts` 2파일 = 28개 endpoint relay + 5대 안전 가드 자동.

## 1. 아키텍처 (단 2파일)

```
lib/toss.ts                              # OAuth + 5대 가드 + fetch wrapper
app/api/toss/[...path]/route.ts          # catch-all relay (GET/POST/PUT/DELETE)
```

**왜 2파일?** toss Open API 28개 endpoint를 28개 route로 만들면 유지보수 폭발. catch-all dynamic route 1개로 forwarding하면 endpoint 추가 = 클라이언트 코드만 변경. 안전 가드는 `lib/toss.ts`에 내장.

## 2. lib/toss.ts 핵심 (★ 5대 가드 자동)

### 2.1 OAuth Client Credentials + 1h 메모리 캐시

```typescript
let cachedToken: { token: string; expiresAt: number } | null = null;
const TOKEN_TTL_MS = 55 * 60 * 1000; // 보수적 55분

async function fetchAccessToken(): Promise<string> {
  const now = Date.now();
  if (cachedToken && cachedToken.expiresAt > now) return cachedToken.token;

  const body = new URLSearchParams({
    grant_type: "client_credentials",
    client_id: getClientId(),
    client_secret: getClientSecret(),
  });
  const res = await fetch(TOSS_TOKEN_ENDPOINT, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body, cache: "no-store",
  });
  if (!res.ok) throw new TossError({ code: `token-${res.status}`, message: `OAuth 실패: ${res.status}`, httpStatus: res.status });
  const data = (await res.json()) as { access_token?: string };
  if (!data.access_token) throw new TossError({ code: "token-malformed", message: "access_token 없음", httpStatus: 502 });
  cachedToken = { token: data.access_token, expiresAt: now + TOKEN_TTL_MS };
  return data.access_token;
}
```

**핵심 결정**:
- **모듈 스코프 변수**로 캐시. Vercel serverless는 cold start마다 초기화되지만, 같은 cold start 안에서는 인스턴스 간 공유됨 (Edge Function 한정).
- **TTL = 55분** (1시간 미만 보수적). 토스 access token 만료 = 1시간, refresh token 없음.
- **`getClientId()` + `getClientSecret()` 호출 시 길이 검증** (가드 #5).

### 2.2 5대 안전 가드 (모두 `tossFetch()` 안)

```typescript
// 가드 1: DRY_RUN + POST → /api/v1/orders 차단
if (dryRun && (method === "POST" || method === "PUT" || method === "DELETE") && isOrderEndpoint(opts.path)) {
  throw new TossError({ code: "dry-run-blocked", message: `paper 모드 차단: ${method} ${opts.path}`, httpStatus: 423 });
}

// 가드 2: 422 → 사용자 친화 메시지
const CODE_422_MESSAGES: Record<string, string> = {
  "account-restricted": "이 계좌는 주문이 제한되어 있습니다 (연금/종합매매 등)...",
  "prerequisite-required": "토스 앱에서 약관 동의 / 위험 고지가 필요합니다...",
  "confirm-high-value-required": "1억+ 주문은 confirmHighValueOrder=true 헤더가 필요합니다...",
  // 7종 더 (OPENAPI_REFERENCE.md §422 가드 표 참조)
};

// 가드 3: 1억+ 주문 자동 설정
if (opts.confirmHighValue) headers["confirmHighValueOrder"] = "true";

// 가드 4: 429/5xx → Retry-After 우선 + 지수 백오프
if (RETRYABLE_STATUS.has(res.status) && attempt < MAX_RETRIES) {
  const retryAfter = res.headers.get("Retry-After");
  const waitMs = retryAfter ? Math.max(parseFloat(retryAfter) * 1000, 100) : 1000 * 2 ** attempt;
  await sleep(waitMs);
  continue;
}

// 가드 5: 401 → 캐시 무효화 + 1회 재시도
if (res.status === 401 && attempt === 0) { cachedToken = null; continue; }
```

### 2.3 응답 envelope (toss-trader 메타 추가)

```typescript
return {
  data,  // 토스 원본 응답
  servedAt: new Date().toISOString(),
  dryRun,
  rateLimit: {
    limit: numberOrNull(res.headers.get("X-RateLimit-Limit")),
    remaining: numberOrNull(res.headers.get("X-RateLimit-Remaining")),
    reset: numberOrNull(res.headers.get("X-RateLimit-Reset")),
  },
};
```

## 3. app/api/toss/[...path]/route.ts catch-all relay

```typescript
import { NextRequest, NextResponse } from "next/server";
import { tossFetch, TossError } from "@/lib/toss";

interface RouteContext { params: Promise<{ path: string[] }>; }  // ★ Next 15+

async function handle(req: NextRequest, ctx: RouteContext, method: "GET" | "POST" | "PUT" | "DELETE") {
  const { path } = await ctx.params;  // ★ await 필수
  const tossPath = "/" + path.join("/");
  // ... body 파싱 + tossFetch() 호출 + 에러 envelope
}

export async function GET(req: NextRequest, ctx: RouteContext) { return handle(req, ctx, "GET"); }
export async function POST(req: NextRequest, ctx: RouteContext) { return handle(req, ctx, "POST"); }
export async function PUT(req: NextRequest, ctx: RouteContext) { return handle(req, ctx, "PUT"); }
export async function DELETE(req: NextRequest, ctx: RouteContext) { return handle(req, ctx, "DELETE"); }
```

## 4. ★ 4대 함정 (2026-07-10 실측)

### 4.1 Next 15+ dynamic route params = `Promise<{...}>`

**문제**: 옛 패턴 `interface RouteContext { params: { path: string[] } }` + `function GET(req, ctx) { const { path } = ctx.params; }` → **TypeScript 에러**.

**해결**:
```typescript
interface RouteContext { params: Promise<{ path: string[] }>; }  // Promise 명시
async function GET(req, ctx) { const { path } = await ctx.params; }  // await 필수
```

이건 Next 15+의 표준. `app/api/[id]/route.ts`, `app/api/[...slug]/route.ts` 모두 동일.

### 4.2 `create-next-app --agents-md` default (Next 16부터)

**문제**: `create-next-app@latest --yes` 실행 시 scaffold 디렉토리에 **자동 AGENTS.md 생성** (Next.js 16 가이드). 우리처럼 자체 AGENTS.md 가진 프로젝트는 **명시적 `--no-agents-md` 옵션이 없어서 물어봄** (또는 무시하고 덮어씀).

**해결 패턴**: `/tmp/scaffold`에 생성 후 보존 파일 유지하며 선택 복사
```bash
# 1) /tmp에 scaffold 생성 (--disable-git으로 git init 회피)
npx --yes create-next-app@latest /tmp/toss-trader-scaffold \
  --typescript --tailwind --app --eslint \
  --no-src-dir --use-npm --disable-git \
  --import-alias "@/*" --yes

# 2) Next 파일만 toss-trader로 복사
cp -R /tmp/toss-trader-scaffold/app /tmp/toss-trader-scaffold/public \
  /tmp/toss-trader-scaffold/package.json /tmp/toss-trader-scaffold/tsconfig.json \
  /tmp/toss-trader-scaffold/next.config.ts /tmp/toss-trader-scaffold/next-env.d.ts \
  /tmp/toss-trader-scaffold/eslint.config.mjs /tmp/toss-trader-scaffold/postcss.config.mjs \
  /tmp/toss-trader-scaffold/package-lock.json \
  /Users/mac/work/toss-trader/

# 3) .gitignore 병합 (Next 표준 + toss-trader 시크릿 격리)
# 보존: .git/, AGENTS.md, README.md, LICENSE, docs/, schemas/
```

### 4.3 Next 16 = breaking change 경고

**문제**: scaffold의 기본 `AGENTS.md` (327B)에 `<!-- BEGIN:nextjs-agent-rules -->` 마커 안에 "**This is NOT the Next.js you know**" 경고.

**해결**: 우리 AGENTS.md 맨 위에 노트 추가
```markdown
> ⚠️ **Next.js 16 (2026-07-10 보일러플레이트 검증)**: `create-next-app@latest` 결과 = `next@16.2.10` + `react@19.2.4` + `tailwind@4`. Next 15와 API/관례/파일 구조가 다를 수 있음. `node_modules/next/dist/docs/`의 가이드 우선 참조 + deprecation 경고 주의.
```

### 4.4 env 키 이름 통일 (★ 실측 v0.5)

**문제**: OPENAPI_REFERENCE.md L27-28 예제는 `TOSSINVEST_API_KEY` / `TOSSINVEST_SECRET_KEY`. README/AGENTS.md는 `TOSS_CLIENT_ID` / `TOSS_CLIENT_SECRET`. **두 가지 다른 env 이름 = 사용자 혼란 + 코드 회귀 위험.**

**해결 (정식 = README/AGENTS.md = `TOSS_CLIENT_ID` / `TOSS_CLIENT_SECRET`)**:
1. OPENAPI_REFERENCE.md L27-28 예제 박스 통일
2. OPENAPI_REFERENCE.md L51-52 curl 예제 (`$TOSSINVEST_API_KEY` → `$TOSS_CLIENT_ID`) 통일
3. 통일 노트 박기: `> ℹ️ env 키 이름 통일 (2026-07-10): README v0.6/AGENTS.md = TOSS_CLIENT_ID / TOSS_CLIENT_SECRET. 본 문서(L27-28)는 README/AGENTS.md와 통일됨.`

**원칙**: 가장 최근 + 비개발자 가이드가 정본. OPENAPI_REFERENCE.md 같은 레퍼런스 문서는 거기에 맞춤.

## 5. 검증 어서션 셋 (★ 2중 + 자기 검증)

### 5.1 TypeScript + Build + Lint

```bash
npx tsc --noEmit                    # 0 에러
npm run build                       # ✓ Compiled successfully + dynamic route 노출
npm run lint                        # 0 에러
```

### 5.2 v0.3 자기 검증 (Vercel 코드 LLM 호출 0줄)

```bash
grep -rEn "openai|nim|anthropic|apiKey|BYOK|SettingsForm|ChatPanel" app/ components/ lib/ \
  | grep -v ".gitkeep" || echo "  (0건)"
```

`safety.ts` (3단계) 도입 후에도 같은 grep 유지. 만약 openai/nim 패턴이 잡히면 단순화 위반.

### 5.3 헤딩 정규화 (docs만)

```bash
bash ~/.hermes/skills/ad-hoc-verifier/scripts/check-kr-en-mixed-headings.sh \
  README.md AGENTS.md docs/ARCHITECTURE.md docs/OPENAPI_REFERENCE.md
python3 - <<'PY'
import re
total = 0
for f in ['README.md', 'AGENTS.md', 'docs/ARCHITECTURE.md', 'docs/OPENAPI_REFERENCE.md']:
    t = open(f).read()
    bad = re.findall(r'^##+ [^()\n]*[가-힣][^()\n]*[A-Za-z][^()\n]*$', t, flags=re.MULTILINE)
    bad = [h for h in bad if h.count('(') != h.count(')')]
    print(f"  {f}: {len(bad)} / 0")
    total += len(bad)
print(f"TOTAL: {total} / 0")
PY
```

## 6. 다음 단계로의 인계 (3단계: safety.ts)

**현재 (2단계)**: `lib/toss.ts` 안에 5대 가드 내장. `safety.ts` 없음.

**3단계**: `lib/safety.ts` 별도 파일로 추출. tossFetch() 호출 전에 `safety.guardRequest()` 한 번 더 통과 (defense in depth). 단위 테스트는 `vitest` + `msw`로 (의존성 추가, package.json scripts에 `"test": "vitest"`).

**5대 가드 책임 분리**:
- `lib/toss.ts` (현재): HTTP/토큰/응답 envelope
- `lib/safety.ts` (3단계): 비즈니스 룰 (DRY_RUN 모드, 계좌/주문 모드, 금액 한도, 사용자 confirm)

## 7. 재사용 시 체크리스트 (sigco3111 다른 토스 프로젝트)

- [ ] Next.js 16 `create-next-app@latest` (`/tmp/scaffold`에 생성 후 보존 파일 유지하며 복사)
- [ ] `lib/toss.ts` (11244B) 그대로 복사
- [ ] `app/api/toss/[...path]/route.ts` (3677B) 그대로 복사
- [ ] `TOSS_CLIENT_ID` / `TOSS_CLIENT_SECRET` env 이름 통일
- [ ] `.gitignore`에 `tossinvest.env` + `*.key` + `*.pem` 추가
- [ ] v0.3 자기 검증 grep (LLM 호출 0줄) 통과
- [ ] `npm run build` 0 에러 + dynamic route 노출 확인
- [ ] 본 reference의 §4 함정 4종 모두 회피 (Next 15+ params, --agents-md, Next 16 warning, env 키 통일)
