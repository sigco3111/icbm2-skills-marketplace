# toss-trader step-10: Confirm 모드 v1.1.2 (auto-paper/auto-live 분화 + 2차 confirm)

**v1.1.2 (2026-07-10)** — v1.1.1의 단일 `'auto'` 모드를 **'auto-paper' / 'auto-live' 2개로 분화** + UI 2차 confirm + 5초 카운트다운.

## 문제 (v1.1.1 한계)

- v1.1.1에서 `'auto'` 모드는 **"dev/test 전용"**로 명시
- 실계좌 연결 시 (`TOSS_TRADING_MODE=live` + `DRY_RUN=false`) 자동 confirm = 즉시 실계좌 주문 = **위험**
- 사용자 요청: **"자동확인은 실계좌 연결에서도 사용가능하게"** + 안전한 2차 가드

## v1.1.2 디자인 (4-모드)

| 모드 | Telegram | 사용자 confirm | 가드 5 | 용도 |
|---|---|---|---|---|
| `telegram` (기본) | ✅ 메시지 | [확인] 버튼 | 자동 true | 실전 (가장 안전) |
| `auto-paper` | ❌ 안 보냄 | 즉시 confirmed | 자동 true | paper 전용, dev/test |
| `auto-live` | ❌ 안 보냄 | **UI 2차 confirm + 5초** | 자동 true (2차 후) | **실계좌 안전 강화** |
| `off` | ❌ 안 보냄 | 안 함 | false → 425 | paper만 |

## 핵심 안전 흐름 (auto-live)

```
[사용자] 매수 진행 → 발송 클릭
    ↓
[OrderButton.handleSend] POST /api/telegram/send
  body: { ..., confirmMode: "auto-live", doubleConfirmed: false }
    ↓
[lib/telegram.sendOrderConfirm] mode='auto-live' + !doubleConfirmed
  → ok:false, message: "UI 2차 confirm 필요"
    ↓
[OrderButton] 1차 응답 ok:false → setShowDoubleConfirm(true)
    ↓
[DoubleConfirmModal] 실계좌 경고 배너 (빨간) + 5초 카운트다운
  - "확인 (주문 실행)" 버튼이 5초 후에만 활성화
  - 빨간색 강조 + 경고 메시지
    ↓
[사용자] 5초 후 "확인" 클릭
    ↓
[OrderButton.handleDoubleConfirm] POST /api/telegram/send
  body: { ..., confirmMode: "auto-live", doubleConfirmed: true }
    ↓
[lib/telegram.sendOrderConfirm] mode='auto-live' + doubleConfirmed=true
  → ok:true, status=confirmed
    ↓
[OrderButton.startPolling] → executeOrder → /api/toss/.../orders → 체결
```

## 코드 변경 핵심

### 1. `lib/settings.ts` (4-모드)

```typescript
export type TelegramConfirmMode = "telegram" | "auto-paper" | "auto-live" | "off";

export const TELEGRAM_CONFIRM_MODES = [
  { value: "telegram", label: "Telegram 메시지", description: "..." },
  { value: "auto-paper", label: "자동 확인 (paper)", description: "paper 거래만" },
  {
    value: "auto-live", label: "자동 확인 (실계좌)",
    description: "UI 2차 confirm + 5초 카운트다운. 실계좌 안전 강화.",
    warning: "실계좌 — 모든 주문에 5초 대기 + 2차 confirm 필요",
  },
  { value: "off", label: "비활성화", description: "paper 거래만, 실계좌 주문 차단" },
] as const;

export function isValidMode(v: unknown): v is TelegramConfirmMode {
  return v === "telegram" || v === "auto-paper" || v === "auto-live" || v === "off";
}
```

### 2. `lib/telegram.ts` (auto-live 분기 + doubleConfirmed 게이트)

```typescript
export interface OrderRequest {
  // ...
  doubleConfirmed?: boolean; // v1.1.2: auto-live 모드에서 2차 confirm 게이트
}

export async function sendOrderConfirm(
  req: OrderRequest,
  mode: "telegram" | "auto-paper" | "auto-live" | "off" = "telegram"
): Promise<SendResult> {
  // ... pending store ...
  
  if (mode === "auto-paper") {
    // 즉시 confirmed
    pending.status = "confirmed";
    return { ok: true, ..., mode: "auto-paper" };
  }

  if (mode === "auto-live") {
    if (req.doubleConfirmed) {
      // 2차 confirm 완료 → confirmed
      pending.status = "confirmed";
      return { ok: true, ..., mode: "auto-live" };
    }
    // 1차 호출 → ok:false (2차 모달 띄움)
    return { ok: false, ..., mode: "auto-live", message: "UI 2차 confirm 필요 (doubleConfirmed=true)." };
  }
  // ... telegram / off 분기 ...
}
```

### 3. `components/DoubleConfirmModal.tsx` (신규)

- 실계좌 경고 배너 (빨간 테두리 + 빨간 배경)
- 5초 카운트다운 (`setInterval` + `setRemaining((r) => Math.max(0, r - 1))`)
- "확인 (주문 실행)" 버튼 — 5초 후에만 활성화 (회색 → 빨간색)
- 접근성: `role="alertdialog"`, `aria-modal`, `aria-labelledby`, `aria-disabled`

### 4. `components/OrderButton.tsx` (handleDoubleConfirm)

```typescript
const handleDoubleConfirm = async (): Promise<void> => {
  if (!autoLiveOrderId) return;
  setSending(true);
  try {
    const res = await fetch("/api/telegram/send", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        symbol, side, quantity, price,
        confirmMode: "auto-live",
        doubleConfirmed: true, // 2차 호출: true
      }),
    });
    const data = await res.json();
    setShowDoubleConfirm(false);
    if (data.ok) {
      setPending(data as PendingOrder);
      void startPolling(data.orderId); // → executeOrder
    }
  } catch (e) { /* ... */ }
};
```

### 5. `components/ConfirmModeToggle.tsx` (4 옵션 UI)

```typescript
{TELEGRAM_CONFIRM_MODES.map((m) => {
  const isDevTest = m.value === "auto-paper";
  const isLiveWarning = m.value === "auto-live";
  return (
    <label>
      <input type="radio" checked={selected} onChange={() => handleChange(m.value)} />
      <span>{m.label}</span>
      {isDevTest && <span className="amber badge">dev/test</span>}
      {isLiveWarning && <span className="red badge">실계좌</span>}
      {m.warning && <div className="red text">⚠ {m.warning}</div>}
    </label>
  );
})}
```

## 호환성

- **v1.1.1 사용자 → v1.1.2**: localStorage에 저장된 `'auto'` 값 → 무효 → `'telegram'` fallback (TDD로 검증)
- **기본값 'telegram'**: 기존 사용자 행동 변화 ❌
- **5개 컴포넌트 lint 우회 패턴 정형화** (Portfolio/OrderButton/StockSearch/ConfirmModeToggle/DoubleConfirmModal) — `setTimeout 0` + clearTimeout

## 발견한 함정 (v1.1.2 세션 실측)

| # | 함정 | 해결 |
|---|---|---|
| 24 | `react-hooks/set-state-in-effect` lint | `setTimeout(0)` + `clearTimeout` cleanup |
| 25 | `react-hooks/purity` (`Date.now()` in handler) | `eslint-disable-next-line` (handler 안은 안전) |
| 26 | **partial patch > 5번 → 파일 망가짐** | 즉시 `write_file`로 통째로 rewrite (OrderButton 449 lines → 380 정상) |
| 27 | `'auto-paper' | 'auto-live' | 'telegram' | 'off'` 4-모드 호환 | `isValidMode()` 가드 + fallback |
| 28 | DoubleConfirmModal 5초 카운트다운 | `setInterval` + `setRemaining((r) => Math.max(0, r - 1))` |
| 29 | `req.doubleConfirmed` 게이트 | 1차 false → ok:false, 2차 true → confirmed |
| 30 | A35 clarify invisible (Telegram UI) | plain text 4옵션 + 추천 marker, 두 번째 clarify 금지 |
| 31 | TELEGRAM_CHAT_ID ≠ bot_id | `TELEGRAM_BOT_TOKEN.split(':')[0]` = 봇 ID. 해결: `@userinfobot` → /start |

## TDD 사이클 실측 (settings 18 tests)

- 1차: 4/18 fail (TelegramConfirmMode 타입 옛 `'auto'` 호환 + 4개 옵션 미반영)
- 2차: 18/18 PASS

## v1.1.2 검증

- npm run build: ✓ 5 routes
- npm run lint: 0 errors, 0 warnings
- npm run test: 113/113 PASS (settings 18 + format 31 + safety 25 + telegram 13 + history 12 + stocks 14)
- 헤딩 정규화: 0/0 깨짐 (5파일)
- v0.3 자기 검증: Vercel 코드 LLM 호출 0줄 유지

## commit message pattern

```
feat(confirm-mode): v1.1.2 — auto-paper/auto-live 분화 + UI 2차 confirm + 5초 카운트다운 (113/113)
```

## 다음 옵션 (v1.1.3 후보)

- A: TOSS_TRADING_MODE=paper일 때 auto-live 무시 (즉시 confirmed) — paper 사용자에게 2차 confirm 과한 안전
- B: 매도 시 보유 종목 + 평균가 자동 채움
- C: v1.1.2 마무리 → v1.2 (e2e 테스트, 차트, batch)
