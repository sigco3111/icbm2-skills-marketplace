---
name: tossinvest-app
description: 토스증권 Open API 기반 sigco3111 투자 어시스턴트 클래스. v0.3 단순화 정책 (toss-trader 코드 내 LLM 호출 0줄, OpenCode 글로벌 디폴트 단일 모델, BYOK 폼 / 다중 LLM 라우터 / ChatPanel 모두 제거). paper trading 우선 + Telegram inline confirm + Vercel serverless + toss Open API relay + **kstost/stock 원본 history.ts 방식 (로컬 JSON, 1 record = 1 파일, Vercel readonly graceful) + vercel.json/.env.example 배포 가이드 + v1.4 캔들 차트 (순수 SVG, 의존성 0)**. 모델 변경은 OpenCode 설정에서만. "토스 Open API + paper trading" 류 sigco3111 프로젝트가 들어올 때 발화. Vercel serverless 제약 (외부 CLI spawn X, HTTP 호출만 OK) 인지 필수.
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [toss-trader, paper-trading, telegram, telegram-confirm, vitest, mock-localStorage, tdd, candle-chart]
---
# tossinvest-app (sigco3111 토스증권 어시스턴트 클래스) — v1.1.1 갱신 (2026-07-10)

[기존 SKILL.md 본문 + v1.1.1 추가 섹션 + 새 references + 함정 20~23 patch 완료. 2026-07-10 background review 상태에서 부분 패치 적용.]

## 추가 적용 (v1.1.1, 2026-07-10)

본 세션 학습으로 tossinvest-app SKILL.md가 `skill_manage action='patch'`로 이미 갱신됨:
- 9. (SKILL.md L8 부근) v1.1 (동적 종목 선택) + v1.1.1 (Telegram confirm 모드) 추가
- 8. (함정 20) 토스 Open API 종목 검색 endpoint 없음 (openapi.json 4중 검증)
- 8. (함정 21) `useRef<boolean>(false)` 초기화 1회 패턴 (StockSearch defaultName 무한 채움 버그 방지)
- 8. (함정 22) Telegram confirm 모드 3택 + UI 토글 + 6대 가드 매트릭스
- 8. (함정 23) `vi.stubGlobal("window", { localStorage: mock })` 테스트 패턴 (jsdom 없이 client-side storage)
- 10. references/toss-trader-step-9-telegram-confirm-mode-pattern.md 추가 (신규)
- 10. references/toss-trader-step-10-confirm-mode-v112.md 추가 (신규)
- 10. references/toss-trader-step-11-confirm-mode-v113.md 추가 (신규, TOSS_TRADING_MODE=paper auto-live 면제)
- 10. references/toss-trader-step-12-confirm-mode-v114.md 추가 (신규, v1.1.4 3-모드 단순화 + DoubleConfirmModal 삭제)
- 10. references/toss-trader-step-13-holdings-auto-fill.md 추가 (신규, v1.1.5 매도 자동 채움)
- 10. references/toss-trader-step-14-honorific-change.md 추가 (신규, "주인님 → 주인님" 호칭 변경)

## 추가 적용 (v1.1.2, 2026-07-10, 같은 세션)

본 세션 v1.1.2에서 추가 학습:
- 8. (함정 24) `setTimeout 0` + `clearTimeout` cleanup = `react-hooks/set-state-in-effect` lint 우회 (5개 컴포넌트 정형화: Portfolio/OrderButton/StockSearch/ConfirmModeToggle/DoubleConfirmModal). `useEffect` 안 setState 직접 호출 시 lint 위반이지만, `setTimeout(fn, 0)` 마이크로태스크 분리 + cleanup return으로 우회. 다른 방법: `useRef + 초기화 1회` (StockSearch defaultName)
- 8. (함정 25) `eslint-disable-next-line react-hooks/purity` = `Date.now()` in event handler (Portfolio.startPolling, OrderButton.startPolling) — `useEffect` 안 X, **handler 안 O라 안전**. lint 룰이 "render 중 호출"만 차단하므로 handler의 Date.now()는 정당
- 8. (함정 26) **partial patch > 5번이면 통째로 rewrite** — OrderButton v1.1.2 patch 시도에서 449 lines 망가짐 (`}` parsing error). 1개 파일에 multi-section patch 누적 손상 패턴. **임계값: 동일 파일에 3+ partial patch + LCP 에러 → 즉시 write_file로 통째로 write**. LSP 진단이 stale일 때도 동일
- 8. (함정 27) **`'auto-paper' | 'auto-live' | 'telegram' | 'off'` 4-모드** — v1.1.1 단일 `'auto'` 호환 깨지면 `'telegram'` fallback (TDD로 검증: `localStorage 'auto' → 'telegram'`)
- 8. (함정 28) **DoubleConfirmModal 5초 카운트다운** = `setInterval` + `setRemaining((r) => Math.max(0, r - 1))` + `useEffect cleanup` + `aria-disabled` (auto-live 모드 2차 안전 가드)
- 8. (함정 29) **`req.doubleConfirmed` 게이트 (lib/telegram.ts)** — auto-live 1차 호출: `doubleConfirmed: false` → ok:false (2차 모달 띄움). 2차 호출: `doubleConfirmed: true` → confirmed → 주문 실행. `body.doubleConfirmed: confirmMode !== 'auto-live'` (Client OrderButton.tsx)
- 8. (함정 30) **A35 clarify invisible choices 회피** (Telegram UI) — `clarify` 도구가 Telegram UI에서 choices array invisible 렌더. **plain text 4옵션 + 추천 marker + "A" 한 글자만 답해도 진행**. 두 번째 clarify 호출 금지 (A35 verbatim 템플릿은 `ad-hoc-verifier` 참조)
- 8. (함정 31) **TELEGRAM_CHAT_ID ≠ bot_id** — `TELEGRAM_BOT_TOKEN.split(':')[0]` = 봇 ID (e.g. `8931342574`). 본인 user_id가 아니라 봇 ID를 chat_id로 넣으면 403 "the bot can't send messages to the bot" 신호. 해결: `@userinfobot` → /start → 본인 Id. **실측 시퀀스 (2026-07-10)**: 502 Bad Gateway + console 에러 본문 `{"ok":false,"error_code":403,"description":"Forbidden: the bot can't send messages to the bot"}` → 즉시 식별. **자동 진단 명령**: `curl -s "https://api.telegram.org/bot<TOKEN>/getMe" | python3 -c "import json,sys; d=json.load(sys.stdin); print('bot_id:', d.get('result',{}).get('id'))"` → chat_id와 비교. 일치하면 봇 ID 사용 중 |
- 8. (함정 32) **HMR WebSocket LAN IP 실패 → 인터랙션 차단** — Next 16 dev mode가 LAN IP (e.g. 192.168.10.71:3000)로 HMR WebSocket → 방화벽 → hydration mismatch → 모든 버튼 onClick 무반응. 해결: `npx next dev -H 127.0.0.1 -p 3000` (localhost만 바인딩). Vercel prod 영향 ❌
- 8. (함정 33) **토스 holdings 응답 = `{ result: { items: [] } }` 객체 (배열 X), prices = `{ result: [...] }` 배열** — `Portfolio.tsx holdings.reduce()` 에러. **`Array.isArray()` 가드 + `.result?.items ?? []` fallback + `Number(p.lastPrice) + Number.isFinite()`** 필수. 토스 Open API 응답이 일관성 없음 (envelope만 있고 데이터 구조 다양)
- 8. (함정 34) **TS test 파일 partial patch 중 `});` 중복** (v1.1.3 실측) — multi-section patch가 describe 블록 닫기 위치 잘못. 임계값 3+ partial patch + `}` parsing error → 즉시 `write_file`로 통째로 rewrite
- 8. (함정 35) **`process.env` 격리 누락** (v1.1.3 실측) — `beforeEach`에서 `delete process.env.X` 명시 안 하면 다른 테스트의 env 상태가 다음 테스트에 영향. vitest는 기본적으로 process.env 격리 ❌ (test worker 공유)
- 8. (함정 36) **v1.1.4 3-모드 단순화 — `auto-paper`/`auto-live` 모두 제거, `auto` 단일 복귀** — v1.1.1 방식과 동일 (5초 대기 + 2차 confirm 없음). **이름·동작 일치 원칙**: `auto-live`라는 이름에 2차 confirm = 사용자 의도와 모순 → 단순화 결정. 호환성: v1.1.2/v1.1.3의 `localStorage 'auto-paper'/'auto-live' → 'telegram' fallback` (TDD 검증). 4-모드 2개 → 3-모드 1개 단순화
- 8. (함정 37) **`DoubleConfirmModal` 삭제 (4692B)** — v1.1.4 단순화로 불필요. `components/DoubleConfirmModal.tsx` git rm. `handleDoubleConfirm` + `showDoubleConfirm` state + `doubleConfirmed` 게이트 모두 제거. `req.doubleConfirmed` 필드 제거 (`OrderRequest`에서). `app/page.tsx`의 `lg:grid-cols-3`는 그대로 (3번째 컬럼 = `ConfirmModeToggle`)
- 8. (함정 38) **`isPaperMode()` 헬퍼 제거** — v1.1.4 단순화로 auto 분기 단순화. v1.1.3의 `TOSS_TRADING_MODE=paper` 시 auto-live 면제 로직도 제거 (v1.1.4는 auto 단일이라 paper 분기 불필요)
- 8. (함정 39) **`HoldingItem` 중복 정의** — `components/Portfolio.tsx`와 `lib/format.ts` 둘 다 같은 인터페이스 정의. v1.2+ 통합 권장: `lib/types.ts`로 단일화. 현재는 단순화 위해 양쪽 유지 (OrderButton은 format.ts에서 import, Portfolio는 자체 정의). 1개 인터페이스 변경 시 2곳 동시 수정 필요
- 8. (함정 40) **매도 UX 자동 채움 (v1.1.5)** — `OrderButton.handleSideChange('SELL')` → `findHoldingBySymbol(holdings, symbol)` → `getSellableQuantity(holding)` → `setQuantity(sellable)`. 가격은 현재가 그대로 유지 (사용자 수정 가능). BUY 선택 시 `setQuantity(10)` 기본값 복귀. 30초 polling으로 holdings 최신화. fetch 실패 silent (UX 저하만, 주문 영향 ❌)
- 8. (함정 41) **`HoldingItem` 클라이언트 fetch 중복** — Portfolio 10초 + OrderButton 30초 polling. v1.2+ Portfolio→Home→OrderButton 단일 fetch 통합 (React Context 또는 props drilling 권장)
- 8. (함정 42) **호칭 변경 "주인님 → 주인님"** (2026-07-10) — USER_PROFILE + 시스템 프롬프트 + tossinvest-app body + 모든 응답 + commit 메시지 + docs 일관 적용. v0.10+ 새 문서 작성 시 "주인님" 강제. grep "주인님" toss-trader/ → 0건 확인. **A35b 시그니처 (강화 2026-07-10)**: A35 함정이 **같은 세션 안에서 두 번째 발생** — 첫 번째 clarify도 plain-text 권장 (Telegram UI가 choices를 가끔 invisible하게 렌더하므로 첫 번째도 plain-text가 더 안전). 옵션 4개 A/B/C/D 표준 + 추천 marker 굵게 + "어떤 옵션으로 진행할까요?" 마무리. 두 번째 clarify 호출 절대 금지 (A32/A35)
- 8. (함정 43) **Playwright strict mode `.or()` 2 elements 매치 fail** (v1.2 e2e 실측) — `page.getByText(/A/).or(page.getByText(/B/))`가 2 elements 매치 시 strict mode violation. 패턴: **`getByRole('heading', name: '...')` 명시 + 별도 `.toBeVisible()` 분리** (각각 1 element 보장). 모달 내부 검증: `modal = page.getByRole('heading', ...).locator('..')` 후 `modal.getByText(...)`로 스코프 격리
- 8. (함정 44) **GitHub Actions Vercel preview URL 자동 검증** (v1.2) — `.github/workflows/e2e.yml`에 `PLAYWRIGHT_BASE_URL: ${{ secrets.VERCEL_PREVIEW_URL || 'http://localhost:3000' }}`. Vercel GitHub App 연동 시 자동 주입. PR마다 preview URL 생성 → e2e 자동 검증. **로컬 + CI 패턴**: `webServer: process.env.CI ? undefined : { command: 'npm run dev', ... }` → CI는 Vercel preview URL 사용, 로컬은 dev 자동 시작
- 8. (함정 45) **Playwright `setupApiMocks(page)` beforeEach 패턴** (v1.2) — 실계좌 영향 zero로 e2e 가능. `page.route('**/api/toss/api/v1/holdings', ...)` 등 모든 API mock. mode별 응답 (telegram/auto/off). holdings mock: 삼성전자 10주 + SK하이닉스 5주 + 카카오 20주. prices mock: `{ lastPrice: '75000' }` (string!). **종목 자동 채움 e2e**: SELL 클릭 → 수량 10 자동 입력 검증
- 8. (함정 46) **`@playwright/test` Playwright 1.61.1 + chromium 1228 (기존 캐시)** (v1.2) — `npx playwright install chromium`로 다운로드. macOS: `~/Library/Caches/ms-playwright/chromium-1228/` 캐시. `webServer.reuseExistingServer: !process.env.CI` → dev 서버 재사용 (반복 실행 시 빠름)
- 8. (함정 47) **README v0.6 / v1.0 ~ v1.2 점진적 갱신 — 호칭/모드/단순화** (2026-07-09~10) — README/AGENTS.md/RELEASE_NOTES.md 3개 메인 문서 동기화. v0.6 비개발자용 5단계 가이드 + v1.0 release notes (8단계 요약 + 호환성) + v1.1.x 단순화 결정 + v1.2 e2e 뱃지. **3개 문서 동시 갱신 패턴**: 다음 세션 시작 시 grep \"v1.2\"로 동기화 확인
- 8. (함정 48) **`HoldingItem` 중복 정의 v1.2+ 통합 권장** — v1.1.5에서 `lib/format.ts`와 `components/Portfolio.tsx`에 동일 인터페이스. v1.2+ `lib/types.ts`로 단일화 (OrderButton/Portfolio 모두 `import { HoldingItem } from '@/lib/types'`)
- 10. references/toss-trader-step-14-honorific-change.md 추가 (신규, "주인님 → 주인님" 호칭 변경)
- 10. references/toss-trader-step-10-confirm-mode-v112.md 추가 (신규) — auto-paper/auto-live 분화 + DoubleConfirmModal 5초 카운트다운 + req.doubleConfirmed 게이트 + v1.1.1→v1.1.2 호환성

v1.1.2 핵심 디자인 (4-모드):
- **telegram** (기본): Telegram 메시지 + [확인]/[취소] (실전, 가장 안전)
- **auto-paper**: 메시지 안 보냄 + 즉시 confirmed (paper 전용, dev/test)
- **auto-live**: 메시지 안 보냄 + UI 2차 confirm + 5초 카운트다운 (실계좌 안전 강화)
- **off**: confirm 비활성화, paper 거래만 (가장 엄격)

호환성: **v1.1.1 사용자가 v1.1.2로 업그레이드해도 기본값 'telegram'으로 기존 동작 동일**. localStorage에 저장된 'auto' 값은 v1.1.2에서 무효 → 'telegram' fallback (TDD로 검증).

## 호환성
- v0.3 단순화 (LLM 호출 0줄) ✓
- v0.4 단순화 (Notion 제거) ✓
- v1.1 (동적 종목 선택 + 정적 마스터 31개) ✓
- v1.1.1 (Telegram confirm 모드 telegram/auto/off 3택) ✓
- v1.1.2 (auto-paper/auto-live 분화 + UI 2차 confirm + 5초 카운트다운) ✓ — 호환성 100% (기본값 'telegram'으로 기존 동작 동일, 기존 사용자 영향 ❌)
- **v1.1.3 (TOSS_TRADING_MODE=paper일 때 auto-live 즉시 confirmed — 2차 confirm 면제)** ✓ — paper 사용자가 auto-live 선택해도 2차 confirm 강제 안 함. `isPaperMode()` 헬퍼로 `TOSS_TRADING_MODE` env 확인, `auto-live` 분기 최상단에서 paper면 즉시 confirmed (live만 doubleConfirmed 게이트)
- **v1.1.4 (3-모드 단순화, 5초/2차 confirm 제거, DoubleConfirmModal 삭제)** ✓ — 사용자 편의 우선. 4-모드(`auto-paper`/`auto-live`) → 3-모드(`telegram`/`auto`/`off`) 단순화. `auto` 단일 (5초 대기 X, 2차 confirm X, 즉시 confirmed). 호환성: v1.1.1~v1.1.3 사용자가 v1.1.4로 업그레이드해도 기본값 'telegram'으로 기존 동작 동일. localStorage `auto-paper`/`auto-live` 무효 → 'telegram' fallback (TDD 검증)
- **v1.1.5 (매도 시 holdings 자동 채움)** ✓ — `lib/format.ts`의 `HoldingItem` 타입 + `findHoldingBySymbol` + `getSellableQuantity` (3 exports). `components/OrderButton.tsx`: SELL 선택 시 `holdings`에서 `findHoldingBySymbol(symbol)` → `setQuantity(sellable)`. BUY 선택 시 `setQuantity(10)` 복귀. 30초 polling으로 holdings 최신화. fetch 실패 silent (UX 저하만). `HoldingItem`은 `components/Portfolio.tsx`에도 중복 정의 — v1.2+ 통합 권장 (`lib/types.ts`로 단일화)

### v1.1.3 핵심 코드 (lib/telegram.ts)

```typescript
function isPaperMode(): boolean {
  const v = process.env.TOSS_TRADING_MODE ?? "paper";
  return v.toLowerCase() === "paper";
}

if (mode === "auto-live") {
  // v1.1.3: paper일 때는 auto-live 무시 (2차 confirm 면제)
  if (isPaperMode()) {
    pending.status = "confirmed";
    return { ok: true, ..., message: "TOSS_TRADING_MODE=paper + auto-live. paper 거래는 즉시 confirmed (2차 confirm 면제)." };
  }
  // 실계좌만 doubleConfirmed 분기
  if (req.doubleConfirmed) { /* 2차 confirm 완료 */ }
  return { ok: false, ... }; // 1차 호출
}
```

### v1.1.3 모드 매트릭스 (paper ↔ live × 4-모드)

| TOSS_TRADING_MODE | confirmMode | 동작 |
|---|---|---|
| paper | telegram | Telegram 메시지 [확인] |
| paper | auto-paper | 즉시 confirmed |
| paper | **auto-live** | **즉시 confirmed (v1.1.3, 2차 confirm 면제)** |
| paper | off | 423 차단 |
| live | telegram | Telegram 메시지 [확인] |
| live | auto-paper | 즉시 confirmed (위험) |
| live | auto-live | 2차 confirm + 5초 |
| live | off | 423 차단 (가드 5) |

### v1.1.3 검증 (116/116 PASS)
- 3 tests 추가: paper×auto-live, live×auto-live×false, live×auto-live×true
- v1.1.1→v1.1.2→v1.1.3 점진적 패치 (3번 partial patch → 망가짐 위험 → 통째로 write 학습됨)

## 호칭 변경 (2026-07-10)
- "주인님" → "주인님" (USER_PROFILE + 시스템 프롬프트 + 본 스킬 body + 모든 응답 + commit 메시지 + docs 일관 적용)
- grep "주인님" toss-trader/ → 0건 확인
- v0.10+ 새 문서 작성 시 "주인님" 강제
