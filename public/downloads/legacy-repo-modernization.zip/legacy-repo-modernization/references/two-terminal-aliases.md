# Two-Terminal Simulation Launch Aliases

> 시뮬레이션 OSS (Django 시각화 + reverie.py 백엔드) 의 한 줄 alias 3종 패턴. 매 새 shell마다 venv + PYTHONPATH + 디렉토리 + 환경변수 4가지를 반복 입력하지 않게 만듦.

## 왜 3개 alias 인가

| 시점 | 필요한 것 | alias |
|------|----------|-------|
| shell 열 때마다 | venv 활성화 + PYTHONPATH unset + KEY export | `ga-activate` |
| 시뮬레이션 띄울 때 (1회만) | activate + Django runserver | `ga-server` |
| 시뮬 백엔드 띄울 때 (1회만) | activate + reverie.py | `ga-sim` |

`ga-activate`만 단독으로 사용하지 않고 3종으로 쪼개는 이유: shell이 다른 작업(예: git commit)에도 쓰일 수 있어서 activate는 단독으로, 그리고 실제로 서버 띄울 때만 server/sim 사용. 이렇게 하면 `ga-sim`을 두 번 실행해도 같은 venv activate가 두 번 일어나 무해.

## 등록

```bash
# .zshrc 에 추가 (프로젝트 경로 조정)
cat >> ~/.zshrc << 'EOF'
alias ga-activate='cd /Users/mac/work/generative-agents-kr && source .venv/bin/activate && unset PYTHONPATH && export NVIDIA_API_KEY="$NVIDIA_API_KEY_1"'
alias ga-server='cd /Users/mac/work/generative-agents-kr && source .venv/bin/activate && unset PYTHONPATH && export NVIDIA_API_KEY="$NVIDIA_API_KEY_1" && cd environment/frontend_server && python manage.py runserver'
alias ga-sim='cd /Users/mac/work/generative-agents-kr && source .venv/bin/activate && unset PYTHONPATH && export NVIDIA_API_KEY="$NVIDIA_API_KEY_1" && cd reverie/backend_server && python3 reverie.py'
EOF
```

Hermes 데스크탑 사용자 주의:
- `ga-activate`가 `unset PYTHONPATH` 포함 — 필수 (Hermes PYTHONPATH 간섭)
- `NVIDIA_API_KEY_1`은 `~/.hermes/secrets/nvidia_keys.env`에서 옴
  - 새 shell에서 `source ~/.hermes/secrets/nvidia_keys.env` 한 번만 실행
  - 또는 alias 안에 `source ~/.hermes/secrets/nvidia_keys.env` 추가

## 실행 흐름

### 한 번만 (새 shell마다)
```bash
source ~/.zshrc       # alias 등록
source ~/.hermes/secrets/nvidia_keys.env  # KEY_1, KEY_2 등 export
```

### 터미널 1 (Django 시각화)
```bash
ga-server
# → cd project, source .venv, unset PYTHONPATH, export KEY
# → cd environment/frontend_server
# → python manage.py runserver (포그라운드)
# → http://localhost:8000 접속 후 열어두기
```

### 터미널 2 (시뮬 백엔드)
```bash
ga-sim
# → cd project, source .venv, unset PYTHONPATH, export KEY
# → cd reverie/backend_server
# → python3 reverie.py (인터랙티브 프롬프트)
# → 대화창 입력 시작
```

### 종료

- Django: `Ctrl+C`
- reverie.py: `fin` 입력 (저장 후 종료) 또는 `exit` (저장 안 함)

## 다른 프로젝트 적용

이 alias 패턴은 Django + LLM 백엔드 조합이 있는 **모든 시뮬레이션 OSS**에 적용 가능:

| 프로젝트 | 명령 |
|---------|------|
| generative_agents-kr | `cd path/generative-agents-kr` |
| ai-town (다른 fork) | `cd path/ai-town` |
| M2Lingual 같은 멀티에이전트 | `cd path/m2lingual` |

각 프로젝트의 cd 경로만 바꾸고 alias 3개 등록.

## 흔한 실수

### alias 등록 안 함

새 shell에서 `ga-server` 입력 → `zsh: command not found: ga-server`. alias 등록은 한 번만 하면 영구적이지만, **`.zshrc`가 자동 로드되지 않는 환경**도 있음 (예: ssh, tmux 새 세션). 이때는 매번 `source ~/.zshrc` 필요.

### alias 등록했지만 export 누락

```bash
ga-server
# → 'export NVIDIA_API_KEY="$NVIDIA_API_KEY_1"' 부분에서 빈 KEY 사용
# → NIM 500 / "Missing request extension"
```

→ `source ~/.hermes/secrets/nvidia_keys.env` 먼저 실행 (한 번만, 새 shell 열 때).

### alias 안 쓰고 4줄 반복

```bash
# 매 새 shell에서 이렇게 4줄 반복
cd /Users/mac/work/generative-agents-kr
source .venv/bin/activate
unset PYTHONPATH
export NVIDIA_API_KEY="$NVIDIA_API_KEY_1"
```

→ alias 3개로 단축. **특히 `unset PYTHONPATH` 빼먹기 쉬움** — alias에 강제 포함시킴.

## venv 종류별 가이드

`.venv` (프로젝트마다) vs Hermes venv (공유) 트레이드오프:

| | .venv | Hermes venv |
|---|------|------------|
| 격리 | 프로젝트별 깨끗한 환경 | 다른 패키지 영향 받음 |
| 디스크 | 프로젝트마다 ~500MB | 공유 1회 |
| 설정 시간 | 매번 60-90초 | 이미 PIL 등 설치됨 |
| 권장 | 새 프로젝트 시작 | 빠른 검증/Hack |

**권장**: 새 프로젝트는 `.venv`로 시작, 설치 잘 안 되면 Hermes venv (PIL 등 일부 wheel 빌드 패키지 미리 설치됨) fallback.

→ `references/2026-environment-notes.md` §venv 패턴 참조.
