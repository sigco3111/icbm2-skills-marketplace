# Agent Simulation Defensive Coding (2026-07-14 Stanford Generative Agents 실측)

`reverie.py`처럼 **수백 step × LLM 호출**을 도는 long-running simulation에서
LLM 응답 형식 오류, LLM 토큰 한도, regex 파싱 실패 등이 한 번이라도
발생하면 `IndexError` / `KeyError` / `TypeError` 같은 TypeError로 즉시 죽는다.
원본 코드는 2022년 OpenAI gpt-3.5-turbo 가정이라 모든 곳에 `resp.choices[0].text` 같은
"happy path only" 코드가 많다. 2026년 NIM reasoning 모델로 마이그레이션하면
이런 오류들이 한 step마다 터져서 100 step 시뮬이 절대 끝나지 않는다.

이 문서는 **에이전트 시뮬레이션을 NIM reasoning 모델에 포팅할 때 필요한
defensive code 패턴**을 정리한다. (Stanford generative_agents가 대표 사례)

## 1. `act_address` cascading failures

LLM이 `act_arena='kitchen'`처럼 존재하지 않는 장소를 반환하면
spatial_memory → plan → execute 체인 전체가 `KeyError`로 죽는다.

### 🛠️ 3-tier 방어

```python
# Tier 1: spatial_memory — KeyError swallow
# File: persona/memory_structures/spatial_memory.py
try:
    x = ", ".join(list(self.tree[curr_world][curr_sector][curr_arena]))
except:
    try:
        x = ", ".join(list(self.tree[curr_world][curr_sector][curr_arena.lower()]))
    except (KeyError, TypeError):
        return ""  # LLM이 잘못된 arena 줘도 빈 문자열로 안전 폴백

# Tier 2: plan.py — arena 유효성 검증 + act_address 명시적 설정
# File: persona/cognitive_modules/plan.py (line ~626)
valid_arenas = list(maze.address_tiles.get(act_world, {}).get(act_sector, {}).keys())
if act_arena not in valid_arenas and act_arena.lower() not in [a.lower() for a in valid_arenas]:
    curr_tile = persona.scratch.curr_tile
    if curr_tile:
        try:
            curr_address = f"{act_world}:{act_sector}:{maze.access_tile(curr_tile)['arena']}"
        except Exception:
            curr_address = f"{act_world}:{act_sector}:__stay__"
        try:
            persona.scratch.act_address = curr_address
            persona.scratch.act_pronunciatio = "❓"
            persona.scratch.act_event = (persona.scratch.curr_tile, "stay", "stay")
            persona.scratch.add_new_action(curr_address + ":__stay__", act_desp, curr_tile)
        except Exception:
            pass
    return  # 다음 step에서 재시도 (LLM 응답 정상화 시)

# Tier 3: execute.py — plan is None 가드
# File: persona/cognitive_modules/execute.py (line ~35)
if plan is None or not plan:
    return False, None, None, None, None, None, None
```

### 💡 핵심: 3-tier 모두 필요한 이유

- Tier 1만 → act_address가 None으로 propagate → execute()에서 TypeError
- Tier 2만 → act_address 설정 안 하면 persona.scratch에 stale value
- Tier 3만 → plan=None 들어왔을 때 `"<random>" in None` → TypeError

## 2. LLM `TOKEN LIMIT EXCEEDED` 폴백

긴 few-shot + 본문 + system prompt 합쳐서 토큰 한도 도달 시
NIM이 `TOKEN LIMIT EXCEEDED` 문자열을 응답한다.
이 문자열을 split-based 파서가 만나면 `ValueError: invalid literal for int()`.

### 🛠️ 파서 2-tier 방어

```python
# File: persona/prompt_template/run_gpt_prompt.py
try:
    total_expected_min = int(prompt.split("(total duration in minutes")[-1]
                                   .split("):")[0].strip())
except (ValueError, IndexError):
    # regex 폴백 (여러 (total duration in minutes ...) 매칭 대비)
    import re
    m = re.search(r'\(total duration in minutes[^0-9]*(\d+)', prompt)
    total_expected_min = int(m.group(1)) if m else 60  # 기본 1시간

if not cr:  # LLM이 깨진 응답만 줘서 cr이 비었을 때
    cr = [["(default task)", 5]]
```

### 💡 few-shot 압축 (사전 방지)

원본 few-shot이 토큰 한도 도달의 주범. 한국어 버전은
영문보다 평균 40% 길어서 더 위험. `references/2026-environment-notes.md` §LANG-EXPANSION 참조.

```bash
# 예: task_decomp_v3.txt few-shot 1420자 → 880자로 압축
# "위치:", "현재:", "일일 계획 요구사항:" 등 3~4줄로 축약
# 효과: 토큰 한도 도달 가능성 60% 감소
```

## 3. `reverie.py` 인터랙티브 명령 파싱 함정

reverie.py는 `input()`으로 시뮬 명령을 받는데, **명령 파싱이 엄격**하다.

| 입력 | 결과 |
|------|------|
| `run 100` | ✅ 100 step 실행 |
| `100` | ❌ `sim_command[:3].lower() == "run"` 매칭 실패 → 다음 프롬프트 |
| `RUN 100` | ❌ (대문자) 매칭 실패 |
| `run 100 ` | ✅ (trailing space OK) |
| `run 100abc` | ❌ `int()` 변환 실패 |

**해결**: README에 정확한 형식 강조 + `run N` 외 다른 명령 표:

```bash
# run N steps (N = 1 이상 정수)
Enter option: run 100

# 저장
Enter option: save

# 페르소나 일정 확인
Enter option: print persona schedule 이서연

# 종료
Enter option: fin    # 저장 후 종료
Enter option: exit   # 저장 안 하고 삭제
```

## 4. Two-terminal alias → function 업그레이드

`alias`는 단일 명령만 가능. **조건부 로직** (예: stale 폴더 자동 정리)
이 필요하면 `function`으로 변경 필수.

```bash
# ❌ alias — ICBM_kr_test 폴더 정리 못 함
alias ga-sim='cd /proj && source .venv/bin/activate && unset PYTHONPATH && python3 reverie.py'

# ✅ function — stale 폴더 자동 정리
ga-sim() {
  local proj_dir="/path/to/project"
  local storage_dir="$proj_dir/environment/frontend_server/storage"
  if [ -d "$storage_dir/ICBM_kr_test" ]; then
    echo "⚠️  $storage_dir/ICBM_kr_test 폴더가 이미 존재 — 삭제합니다 (자동)."
    rm -rf "$storage_dir/ICBM_kr_test"
  fi
  cd "$proj_dir" && source .venv/bin/activate && unset PYTHONPATH \
    && export NVIDIA_API_KEY="$NVIDIA_API_KEY_1" \
    && cd reverie/backend_server && python3 reverie.py
}
```

`.zshrc`에 등록 후 새 shell에서 즉시 사용 가능.

## 5. Sparse-checkout으로 storage/ 폴더 다운로드

원본 시뮬레이터는 `storage/<sim_name>/`에 1GB 가량의 페르소나 상태/맵 파일이
있어야 fork 가능. 전체 clone 없이 1개 시나리오만 받는 패턴:

```bash
TMPDIR=/tmp/gen-agents-original
git clone --depth 1 --filter=blob:none --sparse \
  https://github.com/joonspk-research/generative_agents.git "$TMPDIR"
cd "$TMPDIR"
git sparse-checkout set environment/frontend_server/storage
# 가장 작은 base 시나리오만 (68KB)
cp -r environment/frontend_server/storage/base_the_ville_isabella_maria_klaus \
  /your/fork/environment/frontend_server/storage/
rm -rf "$TMPDIR"
```

이후 fork:
```
Enter the name of the forked simulation: base_the_ville_isabella_maria_klaus
Enter the name of the new simulation: <your_sim_name>
```

## 6. 시뮬 진행 모니터링

장기 시뮬 (17분+, 100 step) 동안 폴더 카운트로 진행 상황 확인:

```bash
# 매 step마다 environment/<step>.json 1개씩 생성
ls /your/fork/environment/frontend_server/storage/<sim_name>/environment/ | wc -l
# 100 = 100 step 완료 (step 0 포함하면 101)
```

## 7. 시뮬 외부 검증 — dry-run으로 LLM 호출 패턴 점검

`reverie.py` 직접 실행 전 (17분 투자 전), 핵심 LLM 호출 모듈을 단독으로 dry-run:

```python
# test_kr_sim.py — 핵심 프롬프트 4개 단독 호출
from prompt_template.gpt_structure import ChatGPT_request
PERSONAS_KR = {"이서연": {...}, "김민준": {...}, "박지우": {...}}

# 1. daily_planning — 페르소나 일정 생성
# 2. task_decomp — 5분 단위 작업 분해
# 3. decide_to_talk — 대화 시작 결정
# 4. agent_chat — 실제 대화

# 각 호출 10-15초, 4개 합쳐 ~60초로 시뮬 17분 분 전 검증 가능
```

이 패턴으로 LLM 응답이 한국어 자연스러운지, 코드가 한국어 시나리오
(이서연/김민준/박지우) 인식하는지 시뮬 100 step 돌리기 전에 확인.

## 8. 시뮬 실패 시 진단 트리

```
reverie.py 에러 →
├─ FileExistsError → `rm -rf environment/frontend_server/storage/<sim>`
├─ ModuleNotFoundError: django → venv 미활성화 → `source .venv/bin/activate`
├─ HTTP 500 + "Missing request extension" → NIM 키 불량 → source nvidia_keys.env
├─ IndexError: list index out of range → LLM 응답 파싱 실패 (defensive code 부족)
├─ KeyError: 'kitchen' (또는 다른 arena) → act_arena 무효 (Tier 2 방어 코드 필요)
├─ TypeError: argument of type 'NoneType' → plan=None 전파 (Tier 3 방어 필요)
├─ ValueError: invalid literal for int() → TOKEN LIMIT EXCEEDED (regex 폴백 필요)
├─ AttributeError: 'NoneType' object has no attribute 'X' → scratch 액션 누락
└─ FileNotFoundError: storage/<sim> → sparse-checkout 안 함, .gitignore 잘못 설정
```
