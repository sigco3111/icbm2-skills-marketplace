# Background Server Health Check Pattern (Hermes)

> Hermes의 `terminal()` 도구로 long-lived 서버(Django runserver, gunicorn, fastapi dev, redis-server, vite dev 등)를 띄울 때, 즉시 health check로 실제 응답을 확인하는 패턴. shell의 `&` 백그라운딩이 금지된 Hermes 환경에서 필수.

## 왜 필요한가

Hermes는 shell-level `&` 백그라운딩을 거부합니다:
```
❌ "Foreground command uses '&' backgrounding. Use terminal(background=true) for long-lived processes"
```

하지만 `terminal(background=true)`만 쓰면:
- 서버가 실제로 부팅됐는지 모름 (5초 sleep 후에도 안 떠 있을 수 있음)
- 포트 충돌, ImportError, NIM 500 같은 부팅 시점이슈를 못 잡음
- 죽었을 때 자동 재시작 패턴 필요

→ 따라서 `background=true` + 5초 sleep + `curl` health check 조합이 표준 패턴.

## 기본 패턴 (Django runserver)

```bash
# 터미널 1: 서버 띄우기
cd /path/to/project
source .venv/bin/activate
unset PYTHONPATH
export NVIDIA_API_KEY="$NVIDIA_API_KEY_1"

# background=true 로 띄움
# (hermes tool) terminal(background=true) "python manage.py runserver 8001" ...
```

```bash
# 터미널 2 (또는 같은 세션의 후속 호출): health check
sleep 5
curl -s -o /tmp/django_test.html -w "HTTP_CODE: %{http_code}\n" \
  http://localhost:8001/ 2>&1
# HTTP_CODE: 200  → 정상
# HTTP_CODE: 000  → 서버 안 떴거나 포트 다름
# HTTP_CODE: 500  → 부팅 시점 에러 (NIM 500, corsheaders, urls.py 등)
```

## 향상된 패턴: 자동 진단

`HTTP_CODE: 000` 또는 `500` 일 때 즉시 진단:

```bash
# 포트 사용 중인 프로세스 확인
lsof -i :8001 2>&1 | head -3
# → 이미 떠 있으면 PID 표시

# 또는 Django 프로세스 직접 찾기
ps aux | grep "manage.py runserver" | grep -v grep | head

# 죽어 있으면 로그 확인 (background process 의 stdout 캡처)
# session_id 로 process list 보기
# (hermes) process(action=list) → background processes

# 또는 stderr 를 파일로
python manage.py runserver 8001 > /tmp/django.log 2>&1 &
# → 5초 sleep 후 /tmp/django.log tail 로 부팅 에러 확인
```

## 패턴 2: 검증 종료 후 kill

server를 띄우고 health check 확인한 후, 검증 끝나면 명시적으로 죽임. (long-lived는 그대로 두지만, **테스트용 일회성 서버**는 cleanup.)

```bash
# (hermes) terminal(background=true, notify_on_complete=false) "python manage.py runserver 8001"
sleep 5
curl -s -w "HTTP_CODE: %{http_code}\n" http://localhost:8001/
# 검증 결과 보존 — process는 명시적으로 kill 안 해도 됨 (대화 종료 시 자동 정리)

# 또는 명시적 kill
# (hermes) process(action='kill', session_id='proc_xxx')
```

Hermes는 bounded task (테스트, 빌드, CI 폴러) 에는 `notify_on_complete=true` 필수이지만, genuine long-lived 서버는 `notify_on_complete=false`로 두는 게 깔끔 (영원히 안 죽으므로 알림 의미 없음).

## 패턴 3: curl 로 응답 본문 검증

상태 코드만 확인하는 게 아니라 **HTML 본문 일부**를 검증해서 진짜로 우리 페이지가 떴는지 확인:

```bash
curl -s -o /tmp/page.html -w "HTTP_CODE: %{http_code}\n" http://localhost:8001/

# 응답 본문 일부 확인 (한국어 UI 라우팅 확인에 특히 유용)
head -c 500 /tmp/page.html | head
# → "한글 환경 서버 정상 동작 중!" 같은 한글 텍스트 보이면 OK
# → "Server Error (500)" 보이면 실패
```

## 패턴 4: 여러 엔드포인트 동시 체크

서버가 여러 경로를 제공할 때 일괄 검증:

```bash
sleep 5
for path in "/" "/replay/" "/demo/" "/api/health"; do
  code=$(curl -s -o /dev/null -w "%{http_code}" "http://localhost:8001${path}")
  echo "  $path → $code"
done
```

→ `200` 일관성 + `/api/health` 200 (별도 health endpoint 있는 경우) 으로 정상 부팅 확인.

## 패턴 5: 임베드 + NIM 500 격리 진단

시뮬레이션 서버 띄우고 실제 LLM 호출이 500을 반환하는지 즉시 확인:

```bash
# 1. 서버 띄움 (background)
# 2. LLM 호출 엔드포인트 확인
curl -s -X POST "http://localhost:8001/api/chat" \
  -H "Content-Type: application/json" \
  -d '{"prompt": "ping"}'
# → 200 OK + "ping" 또는 적절한 응답
# → 500 → NIM 500 → 키 진단 (trap 5 / trap 6 참조)
```

## 패턴 6: 한 줄 health check (단축)

```bash
# server-status 한 줄로 확인
curl -fs http://localhost:8001/ >/dev/null && echo "✅ OK" || echo "❌ DOWN"
```

`-f`: HTTP 에러 (4xx/5xx) 시 non-zero exit, `-s`: silent. health probe용 한 줄.

## 왜 `sleep 5` 인가

Django runserver, gunicorn 같은 mature 서버는 부팅 1-2초. **5초는 안전 마진**. 너무 짧으면 (1-2초) `lsof :8001`로 포트 listening 됐어도 Django app loading 중이라 502 반환할 수 있음. 너무 길면 (30초+) 검증 루프가 느려짐.

## `notify_on_complete` vs `notify_on_complete=false`

`background=true` 호출 시:

| 목적 | 값 |
|------|---|
| 짧은 bounded task (test, build, CI 폴러) | `notify_on_complete=true` (명시적 종료 시 알림) |
| long-lived 서버 (Django runserver, gunicorn, redis-server) | `notify_on_complete=false` (안 끝나므로 알림 의미 없음) |
| 명시적 deadline 있는 작업 (예: 60초 후 종료) | `notify_on_complete=true` + `timeout=60` |

## 실전 예시 (Django + reverie.py 검증)

```bash
# 터미널 1: Django
(hermes) terminal(background=true, notify_on_complete=false) "python manage.py runserver 8001"

# 짧은 sleep
sleep 5

# Health check
curl -s -w "HTTP_CODE: %{http_code}\n" http://localhost:8001/
# → 200 + 한국어 landing 페이지

# 응답 본문 일부 검증
curl -s http://localhost:8001/ | head -c 200
# → "<!--\nFile: landing.html (한글화판 — sigco3111)\n..."

# 정상 확인되면 검증 끝. Django는 그대로 두기 (브라우저가 사용).
```

## 함정

### 함정 1: `&` 백그라운딩 후 health check

```bash
python manage.py runserver 8001 > /tmp/log.txt 2>&1 &
sleep 5
curl -s -o /dev/null -w "%{http_code}" http://localhost:8001/
# 이 패턴은 Hermes에서 거부당함 (backgrounding 에러)
```

### 함정 2: `sleep 1` 너무 짧음

서버 부팅 + 첫 request 처리 = 1-3초. `sleep 1`은 일찍 끝나서 `Connection refused` (서버 아직 안 뜸) 가능. **5초 권장**.

### 함정 3: PID 추적

`lsof -i :8001` 또는 `ps aux | grep runserver` 로 PID 찾은 후 `kill <PID>`. **process list 도구의 session_id로도 kill 가능** (Hermes). 

## 요약 — 한 줄 호출 패턴

```bash
(hermes) terminal(background=true, notify_on_complete=false) "<server start command>"
sleep 5
curl -s -w "HTTP_CODE: %{http_code}\n" http://localhost:<port>/
```

이 3 줄로 어떤 long-lived 서버든 띄우고 health check 가능.
