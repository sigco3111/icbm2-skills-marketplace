# 2026 Python Environment Notes

2026년 7월 기준 macOS/Apple Silicon Python 환경 요약.

## 시스템 Python

- **위치**: `/usr/bin/python3`
- **버전**: macOS Sonoma+ (14+)에서 Python 3.9.6 (최종 시스템 버전)
- **제한**: PEP 668 — 시스템 pip으로 외부 패키지 설치 차단 (`externally-managed-environment`)
- **해결**: `.venv` 또는 Hermes venv 활성화 후 작업

## Homebrew Python

- **위치**: `/opt/homebrew/bin/python3.12`
- **장점**: 최신 버전, PEP 668 없음
- **단점**: 글로벌 설치로 시스템 오염 위험, 다른 venv와 충돌 가능

## venv 패턴

### 새 프로젝트마다 venv 생성 (권장)

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

### Hermes 환경 venv (재사용)

```bash
source ~/.hermes/hermes-agent/venv/bin/activate
# 3.11 + PIL 12.2.0 미리 설치됨
```

Hermes venv는 PIL이 이미 wheel 빌드 버전이라 새 프로젝트에서 그대로 활용 가능.

## zsh 특수성

`%` `>` `<` `|` `&` 등이 모두 특수문자. version specifier에 절대 사용 금지 (따옴표 필수):

```bash
# ❌ zsh: not found
pip install Pillow>=10.0

# ✅
pip install "Pillow>=10.0"
```

bash에서도 따옴표 습관 들이는 게 안전.

## requirements.txt 시대별 호환성

### 2018-2020 (Python 3.6-3.8)
- 모든 패키지 빌드 가능, wheel 대부분 존재

### 2020-2022 (Python 3.7-3.9)
- 대부분 OK, 일부는 libjpeg/libpng 등 native 의존성 필요
- Django 2.x, numpy 1.19-1.25

### 2024-2026 (Python 3.11+)
- Pillow 8.x/9.x 빌드 실패 (wheel 부재)
- Django 2.x 일부 syntax 미지원
- gensim 3.x cython 빌드 실패
- numpy/pandas/scipy ABI 변경 → 호환 버전 필요

### 호환 버전 매핑 (2026-07 검증)

| 패키지 | 2022 원본 | 2026 호환 |
|--------|----------|-----------|
| Pillow | 8.4.0 | >=10.0 |
| Django | 2.2 | >=4.2,<5 (LTS) |
| gensim | 3.8.0 | >=4.3 |
| numpy | 1.25.2 | >=1.26,<3 |
| pandas | 2.0.3 | >=2.0 |
| scikit-learn | 1.3.0 | >=1.4 |
| scipy | 1.11.1 | >=1.11 |
| asgiref | 3.5.2 | >=3.6 |
| six | 1.16.0 | >=1.16 |
| django-cors-headers | 2.5.3 | >=3.5 |

**`django-cors-headers==2.5.3`은 `from django.utils import six`를 import해서 Django 3.0+에서
즉시 깨짐.** 3.5+ (최신 4.x)로 패치 필수.

## macOS Sonoma+ Python 보호

- 시스템 Python에 PEP 668 적용
- `pip install` 직접 호출 시 "externally-managed-environment" 에러
- 해결: `python3 -m venv .venv && source .venv/bin/activate`
- 또는 `--break-system-packages` 플래그 (비권장, 시스템 오염)

## shell 별 venv 활성화 확인

```bash
# 새 shell마다 확인 필요
source .venv/bin/activate
which python3
# → /Users/.../project/.venv/bin/python3 (venv 활성)

# 비활성화
deactivate
```

`$VIRTUAL_ENV` 환경변수로도 확인 가능:
```bash
echo $VIRTUAL_ENV
# 비어있으면 비활성, 프로젝트 경로 나오면 활성
```

## 자주 헷갈리는 PATH 문제

```bash
# 시스템 Python pip은 macOS에서 흔들림
which pip pip3 python python3
# pip3 → /usr/bin/pip3 (PEP 668 적용)
# pip → Hermes venv 또는 .venv 활성 시에만 보임

# venv 활성 후:
which python3
# → /Users/.../project/.venv/bin/python3
which pip
# → /Users/.../project/.venv/bin/pip
```

## 영구 환경변수 설정

```bash
# 매번 export 대신 rc 파일에 추가
echo 'export NVIDIA_API_KEY="..."' >> ~/.zshrc

# 즉시 반영
source ~/.zshrc

# 확인
echo $NVIDIA_API_KEY
```

## PATH 환경 격리

Hermes와 새 프로젝트의 Python이 절대 섞이지 않도록:
- 각 프로젝트마다 별도 venv
- `source ~/.hermes/hermes-agent/venv/bin/activate` 절대 자동 로드 X
- 새 프로젝트 작업 시작 시 명시적으로 `cd` + `source .venv/bin/activate`

## Hermes 데스크탑의 PYTHONPATH 자동 export

Hermes 데스크탑 환경에서는 새 shell을 열 때마다 `PYTHONPATH=/Users/mac/.hermes/hermes-agent:/Users/mac/.hermes/hermes-agent/venv/lib/python3.11/site-packages`가 자동으로 export됩니다. 이 상태에서 `.venv`를 활성화해도 `sys.path[1]`이 Hermes venv로 고정되어, .venv의 패키지가 아닌 Hermes의 패키지가 import됩니다 (예: Django가 Hermes venv의 것을 import → `corsheaders`의 six import가 실패).

**즉시 해결**:
```bash
source .venv/bin/activate
unset PYTHONPATH  # ← 추가 필수
```

**영구 해결** (Hermes zsh 사용 시):
```bash
cat >> ~/.zshrc << 'EOF'
alias ungate-hermes='unset PYTHONPATH'
EOF
# 이후 작업 시: source .venv/bin/activate && ungate-hermes
```

**진단 단서**: ImportError나 ModuleNotFoundError 시 트레이스백 경로에 `/Users/mac/.hermes/hermes-agent/...`가 보이면 PYTHONPATH 문제.

## zsh `&` 백그라운딩 제약 (Hermes terminal)

Hermes의 `terminal()` 도구는 shell-level `&` 백그라운딩을 거부합니다:

```
# ❌ "Foreground command uses '&' backgrounding" 에러
python manage.py runserver 8001 > /tmp/log.txt 2>&1 &
```

long-lived 프로세스(`runserver`, `celery`, `redis-server`, `tailwind --watch`, `gunicorn`)는 **반드시 `terminal(background=true)` 사용**. short 명령(curl, ls, `python3 gpt_structure.py`)은 `terminal(timeout=...)` foreground로 충분.

`notify_on_complete`는 bounded task(테스트, 빌드, CI 폴러)에서 필수, genuine long-lived 서버는 생략 가능.

## write_file 경로 함정

`write_file(path=..., content=...)`의 `path` 또는 `content` 매개변수에 닫는 태그가 실수로 중복 입력되면 의도와 다른 파일명이 만들어집니다:

```python
# 실수 예: content 끝에 "</path>" 잔여
write_file(path="/path/README.md", content="..." + "</path>")
# → 실제 파일: "README.md.kra<" (또는 "README.md<" / "path>")
```

**진단**:
- 직후 `ls -la <expected_path>`로 확인 → "No such file or directory"
- 동시에 `ls -la` 하면 "README.md.kra<" 또는 "path>" 같은 파일이 보임

**복구**:
```bash
# 보통 빈 파일이거나 깨진 텍스트
rm -rf "README.md.kra<" "README.md<" "path>" 2>/dev/null
ls -la | grep -E '(md<|path>)'  # 잔여 확인
```

**예방**:
- write_file 호출 시 `path` 매개변수 끝에 닫는 태그가 들어가지 않는지 더블체크
- 가능하면 절대경로만 사용 (`/Users/.../...`)
