# Django 2.x → 4.x 마이그레이션 체크리스트 (2026)

옛날 Django (2.2 이하)로 작성된 코드를 modern Django (4.x LTS, 5.x)로 마이그레이션할 때 만나는 모든 호환성 문제와 fix.

> 검증: `generative_agents-kr` (Stanford 2023, Django 2.2) → sigco3111 fork (Django 4.2.30, 2026-07-14)

## 4가지 패치 한눈에

| # | 파일 | 증상 | Fix |
|---|------|------|-----|
| 1 | `requirements.txt` | `corsheaders==2.5.3`가 `from django.utils import six` 호출 → `ImportError` | `django-cors-headers>=3.5` (3.5+가 Django 4.x 호환) |
| 2 | `project/urls.py` | `from django.conf.urls import include, url` → `ImportError: cannot import name 'url'` | `from django.urls import include, re_path` + 모든 `url()` → `re_path()` |
| 3 | `app/views.py` | `from django.contrib.staticfiles.templatetags.staticfiles import static` → `ImportError` | `from django.templatetags.static import static` |
| 4 | 모든 템플릿 (`base.html` 포함) | `{% load staticfiles %}` → `TemplateSyntaxError` | `{% load static %}` |

## 패치 1: django-cors-headers

```python
# requirements.txt 변경
-django-cors-headers==2.5.3
+django-cors-headers>=3.5
+# ^ 2.5.3은 `from django.utils import six` 사용 → Django 3.0+에서 제거됨.
```

```bash
# 즉시 fix (기존 requirements.txt 있는 경우)
pip install --upgrade "django-cors-headers>=3.5"
```

## 패치 2: urls.py

Django 4.0에서 `django.conf.urls.url` 제거. `re_path()`로 마이그레이션:

```python
# Before (Django 2.x)
from django.conf.urls import include, url
from django.urls import path

urlpatterns = [
    url(r'^$', views.landing, name='landing'),
    url(r'^replay/(?P<sim_code>[\w-]+)/$', views.replay),
    url(r'^admin/', admin.site.urls),
]

# After (Django 4.x)
from django.urls import include, path, re_path

urlpatterns = [
    re_path(r'^$', views.landing, name='landing'),
    re_path(r'^replay/(?P<sim_code>[\w-]+)/$', views.replay),
    path('admin/', admin.site.urls),
]
```

**자동 변환 sed** (정규식 패턴 모두 동일):
```bash
# 1. import 변경
sed -i '' 's|from django.conf.urls import include, url|from django.urls import include, re_path|' project/urls.py

# 2. url() → re_path() 변환 (모든 url 호출이 re_path와 호환)
sed -i '' 's|\burl(|re_path(|g' project/urls.py
```

⚠️ **macOS sed 주의**: `sed -i ''` (BSD/macOS)와 `sed -i` (GNU/Linux)는 옵션 문법이 다릅니다.
macOS에서는 빈 따옴표 `''`이 필수. Linux에서는 `sed -i 's|...|...|'`만 사용.
Docker/Linux 컨테이너에서 작업 시 `sed -i`로 변경 필요.

## 패치 3: views.py — static import

Django 3.1에서 `django.contrib.staticfiles.templatetags.staticfiles` deprecated, 4.0에서 제거:

```python
# Before
from django.contrib.staticfiles.templatetags.staticfiles import static

# After
from django.templatetags.static import static
```

## 패치 4: 템플릿 `{% load staticfiles %}`

모든 HTML 템플릿에서 `{% load staticfiles %}` → `{% load static %}`:

```bash
# 모든 .html 파일 일괄 변환 (base.html 포함)
find project/ -name "*.html" -exec sed -i '' 's|{% load staticfiles %}|{% load static %}|g' {} +
```

⚠️ **base.html을 빠뜨리기 쉬움**. 다른 디렉토리에 있을 수 있어 `find`로 전체 검색 필수.

## 검증 (3단계)

```bash
# 1. 정적 검증
python manage.py check
# → "System check identified no issues" 나와야 성공

# 2. 런타임 검증 (백그라운드)
python manage.py runserver 8001 &
SERVER_PID=$!
sleep 4

# 3. curl로 응답 확인
curl -s -o /tmp/test.html -w "HTTP_CODE: %{http_code}\n" http://localhost:8001/
# → HTTP_CODE: 200 나와야 성공

kill $SERVER_PID
```

성공 시 `/tmp/test.html`에 실제 HTML 일부가 저장됨 (lang="ko"로 시작하면 한글화 정상).

## 흔한 다른 패턴 (지금까지 본 적 없지만 미래 대비)

| 패턴 | Django 버전 | 상태 |
|------|------------|------|
| `MIDDLEWARE_CLASSES` | 1.x | Django 1.10부터 `MIDDLEWARE`로 변경 |
| `url(r'^$', ...)` | 2.x | Django 4.0부터 `re_path` |
| `@login_required` 장식자 변경 | 4.1 | 동작 변경 없음 (단, `next_page` URL quote 변경) |
| `force_text` → `force_str` | 3.0 | 단순 이름 변경 |
| `URLValidator` API 변경 | 2.x | kwargs 변경 |
| `STORAGES` settings (3.2+) | 4.x | `DEFAULT_FILE_STORAGE` → `STORAGES["default"]` |

## 발견 즉시 진단 패턴

`python manage.py check`에서 에러 시:

| 에러 메시지 키워드 | 패치 |
|-------------------|------|
| `corsheaders/checks.py ... django.utils import six` | 패치 1 |
| `django.conf.urls ... cannot import name 'url'` | 패치 2 |
| `django.contrib.staticfiles.templatetags.staticfiles` | 패치 3 |
| `TemplateSyntaxError ... 'staticfiles'` | 패치 4 |

이 4개로 Django 2.x → 4.x 마이그레이션의 90% 커버. 나머지는 위 표의 부가 패턴으로 처리.
