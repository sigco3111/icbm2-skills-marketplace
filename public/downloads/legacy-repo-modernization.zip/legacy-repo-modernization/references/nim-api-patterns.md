# NIM API Integration Patterns (2026)

NVIDIA NIM API (`https://integrate.api.nvidia.com/v1`)는 OpenAI 호환 엔드포인트. 기존 OpenAI 호출 코드를 `base_url`만 교체하면 그대로 동작.

## 기본 패턴

```python
import urllib.request, json, os

NIM_BASE_URL = "https://integrate.api.nvidia.com/v1"
API_KEY = os.environ["NVIDIA_API_KEY"]

def _nim_post(endpoint, body, timeout=120):
    url = f"{NIM_BASE_URL}{endpoint}"
    req = urllib.request.Request(
        url,
        data=json.dumps(body).encode("utf-8"),
        method="POST",
    )
    req.add_header("Authorization", f"Bearer {API_KEY}")
    req.add_header("Content-Type", "application/json")
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))
```

## Chat Completion (Reasoning 모델)

```python
def chat(prompt: str, model="openai/gpt-oss-120b"):
    resp = _nim_post("/chat/completions", {
        "model": model,
        "messages": [{"role": "user", "content": prompt}],
        "max_tokens": 2048,
        "temperature": 0.7,
    })
    msg = resp["choices"][0]["message"]

    # ⚠️ reasoning 모델 함정 (CRITICAL)
    # gpt-oss-120b, o1, o3 등은 content=None, reasoning_content에 응답
    content = msg.get("content") or ""
    if not content.strip():
        reasoning = msg.get("reasoning_content") or ""
        import re
        # gpt-oss-120b는 보통 <final>...</final> 안에 실제 응답
        m = re.search(r"<final>(.*?)</final>", reasoning, re.DOTALL)
        if m:
            content = m.group(1).strip()
        else:
            # fallback: reasoning 마지막 줄
            lines = [l for l in reasoning.strip().split("\n") if l.strip()]
            content = lines[-1].strip().strip("`") if lines else ""
    return content
```

### 검증된 추출 패턴 (2026-07)
- `<final>...</final>` 매칭 (gpt-oss-120b)
- 마지막 줄 fallback (다른 reasoning 모델)

### 흔한 실수
- ❌ `resp["choices"][0]["message"]["content"]` 직접 반환 → 항상 None
- ❌ `reasoning_content`를 그대로 노출 → 사용자 채팅 화면에 사고 과정 노출됨
- ❌ `finish_reason` 무시 → `length`(max_tokens 도달)와 `stop` 구분 못함

## Embeddings (비대칭)

```python
def embed(text: str, input_type: str = "passage"):
    """input_type: 'passage' (저장) or 'query' (검색). 비대칭 모델은 둘 구분 필수."""
    resp = _nim_post("/embeddings", {
        "model": "nvidia/llama-nemotron-embed-1b-v2",
        "input": text,
        "input_type": input_type,
    })
    return resp["data"][0]["embedding"]
```

### 비대칭 임베딩 모델
- `nvidia/llama-nemotron-embed-1b-v2` (2048d)
- 비대칭: `passage` (저장용)와 `query` (검색용) 구분 → 검색 정확도 ↑
- 검증: 8-모델 비교에서 6/8 (75%) 1위

### 사용 패턴
```python
# 메모리 저장 시
p_emb = embed("이서연은 카페에서 커피를 마신다", input_type="passage")

# 메모리 검색 시
q_emb = embed("이서연이 마신 음료는?", input_type="query")

# 두 벡터의 코사인 유사도 = retrieval score
```

## 한국어 부정 가드 (검색 정확도 보강)

임베딩 모델은 한국어 부정을 약하게 인식 (점수 차이 작음). 코드 레벨에서 보강:

```python
NEGATION_KO = ["않", "안 ", "못 ", "없", "아니", "말고", "싫어하", "거부하", "반대하"]
NEGATION_EN = ["not ", "n't ", " no ", "never", "none", "cannot", "won't", "hate", "refuse"]

def negation_penalty(text_a: str, text_b: str) -> float:
    """passage/query 양쪽의 부정 표현 비대칭 시 페널티."""
    a_lower = text_a.lower()
    b_lower = text_b.lower()
    a_neg = any(neg in a_lower for neg in NEGATION_KO + NEGATION_EN)
    b_neg = any(neg in b_lower for neg in NEGATION_KO + NEGATION_EN)
    if a_neg != b_neg:
        return 0.4  # 한쪽만 부정: 강한 페널티
    if a_neg and b_neg:
        return 0.1  # 양쪽 다 부정: 약한 페널티
    return 0.0

def score_memory(query_text, memory_text, base_score):
    """검색 점수 = base_similarity - negation_penalty"""
    return base_score - negation_penalty(query_text, memory_text)
```

### 검증된 효과
- `이서연은 커피를 마신다` ↔ `이서연은 커피를 마시지 않았다`: 가드 전 0.457 → 가드 후 0.057

## 시스템 fingerprint / 도우미 톤 차단

`gpt-oss-120b`가 가끔 "How can I help you today?" 같은 일반 도우미 톤으로 시작. 캐릭터 응답으로 부적절:

```python
def safe_postprocess(text):
    fingerprint_patterns = ["How can I help", "I'm an AI", "As an AI"]
    for fp in fingerprint_patterns:
        if text.strip().startswith(fp):
            return ""  # 응답 폐기, 폴백
    return text
```

## NIM API 디버깅

| 에러 | 원인 |
|------|------|
| HTTP 401 Unauthorized | 키 형식 오류 |
| HTTP 403 Forbidden | 키 권한 없음 / 모델 액세스 불가 |
| HTTP 500 `Missing request extension: headers::common::authorization` | **키가 잘못됨** (만료/형식 오류) |
| chat → 항상 빈 문자열 | reasoning 모델 `reasoning_content` 미처리 |
| embedding 500 | 모델명에 오타 또는 미지원 모델 |

### 빠른 진단
```bash
curl -s -w "\nHTTP_CODE: %{http_code}\n" \
  -X POST "https://integrate.api.nvidia.com/v1/chat/completions" \
  -H "Authorization: Bearer $NVIDIA_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"model": "openai/gpt-oss-120b", "messages": [{"role":"user","content":"ping"}], "max_tokens": 50}'
```

→ HTTP 200 + content/pong 응답이 보이면 키 정상. 500이면 키 문제.
