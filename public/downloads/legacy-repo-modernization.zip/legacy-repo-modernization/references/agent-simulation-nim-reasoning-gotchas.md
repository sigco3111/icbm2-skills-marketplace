# NIM gpt-oss-120b Reasoning Model — 시뮬레이션 통합 함정 (2026-07-14 실측)

`openai/gpt-oss-120b` (NIM reasoning 모델)을 generative agent 시뮬레이션에
통합할 때 **self-test는 정상 작동하지만 시뮬은 매 step마다 죽는** silent killer들이
여러 개 있다. 이 문서는 `gpt_structure.py`의 self-test가 통과한 직후
`reverie.py` 시뮬이 왜 fail하는지, 그리고 그 함정들을 어떻게 회피하는지 정리한다.

## 9. 🚨 `GPT_request` `max_tokens=100` silent fail (가장 흔한 silent killer)

### 증상

```bash
# self-test는 정상
$ cd reverie/backend_server/persona/prompt_template && python3 gpt_structure.py
=== NIM gpt_structure self-test ===
[1] ChatGPT_single_request('ping 한 단어만')
    응답: ping
[2] 비대칭 임베딩...
    차원: 2048
✅ 모든 self-test 통과

# 하지만 시뮬은 매 step마다 "TOKEN LIMIT EXCEEDED"
$ cd reverie/backend_server && python3 reverie.py
Enter option: run 100
DEBUG LJSDLFSKJF
['TOKEN LIMIT EXCEEDED ((default task)) ((default task))', 1440]
# ... 100 step 동안 fail-safe로만 동작
```

### 원인

`gpt_structure.py`의 `_nim_chat`은 `max_tokens=2048` 명시하지만,
**`safe_generate_response` → `GPT_request` 경로는 `gpt_parameter.get("max_tokens", 100)` 기본값 사용**:

```python
# File: gpt_structure.py, GPT_request()
def GPT_request(prompt, gpt_parameter):
    try:
        return _nim_chat(
            [{"role": "user", "content": prompt}],
            model=CHAT_MODEL,
            temperature=gpt_parameter.get("temperature", 0.7),
            max_tokens=gpt_parameter.get("max_tokens", 100),  # ← 100이 문제!
        )
    except Exception:
        return "TOKEN LIMIT EXCEEDED"
```

원본 (OpenAI text-davinci-003)는 max_tokens 100이 충분했음. NIM `gpt-oss-120b`는
**reasoning 모델**이라 응답에 reasoning + 본문이 들어가서 100 토큰에 잘림.
`_nim_chat`은 정상 응답 받지만, `GPT_request` 호출 시점에서 잘림.

### 🚨 가장 진단하기 어려운 이유

- `_nim_chat` 단독 호출 → 정상 (max_tokens 2048)
- self-test (`gpt_structure.py` 끝부분) → 정상 (ChatGPT_request → `_nim_chat` 직접)
- `safe_generate_response` → `GPT_request` (max_tokens 100) → 잘림
- **에러 메시지 "TOKEN LIMIT EXCEEDED"가 LLM 응답으로 위장**해서, 진짜 문제(max_tokens 부족)인지 모름

### 해결

```python
# ✅ 패치
def GPT_request(prompt, gpt_parameter):
    try:
        return _nim_chat(
            [{"role": "user", "content": prompt}],
            model=CHAT_MODEL,
            temperature=gpt_parameter.get("temperature", 0.7),
            max_tokens=gpt_parameter.get("max_tokens", 1000),  # ← 1000으로 상향
        )
    except Exception:
        return "TOKEN LIMIT EXCEEDED"
```

### 진단 체크리스트

```bash
# self-test는 정상이지만 시뮬의 DEBUG 로그에 "TOKEN LIMIT EXCEEDED"가 반복?
# 1. GPT_request의 max_tokens 기본값 확인
grep -n "max_tokens" gpt_structure.py | head
# 2. safe_generate_response가 GPT_request 호출하는지 확인
grep -n "GPT_request\|safe_generate" gpt_structure.py
# 3. 직접 LLM 호출로 NIM 응답 잘림 여부 확인
curl -X POST "https://integrate.api.nvidia.com/v1/chat/completions" \
  -H "Authorization: Bearer $NVIDIA_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"model": "openai/gpt-oss-120b", "messages": [{"role":"user","content":"ping"}], "max_tokens": 100}'
# 200 + 짧은 응답 = NIM이 100 토큰에 정확히 자른 것 = 패치 후 1000으로 OK
```

## 10. `_nim_embed` 빈 텍스트/500 폴백

### 증상

LLM이 perceive 단계에서 빈 문자열을 임베딩하려고 시도하면 NIM이 `HTTP 500` 반환.
또는 LLM이 특수문자/제어문자만 있는 텍스트를 보내면 NIM이 500.

### 해결

```python
# File: gpt_structure.py, _nim_embed()
def _nim_embed(text, input_type):
    # 빈 텍스트/공백만 → NIM 호출 안 하고 0 벡터 반환 (안전)
    safe_text = (text or "").strip()
    if not safe_text:
        return [0.0] * 2048  # 모델 출력 차원과 동일
    body = {
        "model": EMBED_MODEL,
        "input": [safe_text],
        "input_type": input_type,
    }
    try:
        resp = _nim_post("/embeddings", body)
        return resp["data"][0]["embedding"]
    except urllib.error.HTTPError as e:
        # 500/502/503/504 — 1회 재시도 후 0 벡터 폴백
        if e.code in (500, 502, 503, 504):
            try:
                return _nim_post("/embeddings", body)["data"][0]["embedding"]
            except Exception:
                return [0.0] * 2048
        return [0.0] * 2048
    except Exception:
        return [0.0] * 2048
```

**핵심**: 0 벡터는 retrieval 점수 0에 가까워서 비활성 효과.
하지만 시뮬이 죽지 않고 다음 step으로 진행 → 다음 LLM 호출이 정상일 때 회복.

## 11. `movement/` 디렉토리 자동 생성

### 증상

`FileNotFoundError: [Errno 2] No such file or directory: '../../environment/frontend_server/storage/<sim>/movement/0.json'`

원본은 `shutil.copytree()`로 storage를 통째로 복사하면서 `movement/`도 같이 복사됨.
live 시뮬은 sparse-checkout으로 일부만 받아서 `movement/` 폴더가 없을 수 있음.

### 해결

```python
# File: reverie/backend_server/reverie.py
curr_move_file = f"{sim_folder}/movement/{self.step}.json"
# NIM gpt-oss-120b 마이그레이션: movement 디렉토리 자동 생성
import os as _os
_os.makedirs(os.path.dirname(curr_move_file), exist_ok=True)
with open(curr_move_file, "w") as outfile:
    outfile.write(json.dumps(movements, indent=2))
```

## 12. 시각 자산 sparse-checkout (38MB)

### 증상

Django 시각화 서버 (`ga-server`) 띄운 후 브라우저로 접속:
- `http://localhost:8000/` → 한국어 landing 정상
- `http://localhost:8000/demo/` → 시뮬 진입 페이지
- `http://localhost:8000/path_tester/` → **검은 화면** (Phaser 캔버스 안 그려짐)
- `http://localhost:8000/demo/<sim>/<step>/2/` → **검은 화면** (맵 안 그려짐)

### 원인

원본 repo의 `static_dirs/assets/the_ville/visuals/` 폴더 (맵 타일 PNG, CSV) 38MB가
**.gitignore에 `static_dirs/*`로 ignore 처리됨**. sparse-checkout으로 storage만 받으면
visuals는 빠짐.

### 해결

```bash
# visuals만 sparse-checkout으로 다운로드
TMPDIR=/tmp/ga-visual
rm -rf "$TMPDIR"
git clone --depth 1 --filter=blob:none --sparse \
  https://github.com/joonspk-research/generative_agents.git "$TMPDIR"
cd "$TMPDIR"
git sparse-checkout set environment/frontend_server/static_dirs/assets/the_ville/visuals
# 우리 repo로 복사
mkdir -p /your/fork/environment/frontend_server/static_dirs/assets/the_ville/
cp -r environment/frontend_server/static_dirs/assets/the_ville/visuals \
      /your/fork/environment/frontend_server/static_dirs/assets/the_ville/
rm -rf "$TMPDIR"
```

### .gitignore에 visuals 추가 (38MB 추적)

```gitignore
# 시뮬레이션 시각 자산 (visuals/) — 추적 (38MB)
!static_dirs/assets/the_ville/visuals/
```

`!` 패턴은 `static_dirs/*` (전체 ignore) 뒤에 와야 effective.

## 13. `/demo/` 인덱스 + `master_movement.json` 미존재 fallback

### 증상

`http://localhost:8000/demo/` → **404 Page not found**

### 원인

`urls.py`에 `re_path(r'^demo/(?P<sim_code>...)/(?P<step>...)/(?P<play_speed>...)/$', ...)`만
있고 인덱스 URL이 없음. 또한 `demo` view가 `compressed_storage/<sim>/master_movement.json`
파일을 요구하는데, **live NIM 시뮬은 master_movement.json을 생성하지 않음**
(원본의 pre-computed demo용).

### 해결

`urls.py`:
```python
urlpatterns = [
    re_path(r'^$', views.landing, name='landing'),
    re_path(r'^simulator_home$', views.home, name='home'),
    re_path(r'^demo/$', views.demo_index, name='demo_index'),  # ← 추가
    re_path(r'^demo/(?P<sim_code>[\w-]+)/(?P<step>[\w-]+)/(?P<play_speed>[\w-]+)/$', views.demo, name='demo'),
    # ...
]
```

`views.py`에 `demo_index` 추가:
```python
def demo_index(request):
    """데모 진입점: 사용 가능한 시뮬 목록."""
    sims = []
    for d in os.listdir("storage"):
        full = os.path.join("storage", d)
        if not os.path.isdir(full):
            continue
        env_dir = os.path.join(full, "environment")
        if not os.path.isdir(env_dir):
            continue
        steps = [int(f.replace(".json", "")) for f in os.listdir(env_dir) if f.endswith(".json")]
        if steps:
            sims.append({"name": d, "latest_step": max(steps)})
    return render(request, "demo/demo_index.html", {"sims": sims})
```

`demo` view에 fallback 추가 (live 시뮬은 master_movement.json 없음):
```python
def demo(request, sim_code, step, play_speed="2"):
    move_file = f"compressed_storage/{sim_code}/master_movement.json"
    meta_file = f"compressed_storage/{sim_code}/meta.json"
    # live 시뮬 fallback: storage/<sim>/environment/ 스캔해서 최신 step으로 리다이렉트
    if not os.path.exists(move_file):
        storage_dir = f"storage/{sim_code}"
        if os.path.exists(storage_dir):
            env_dir = os.path.join(storage_dir, "environment")
            if os.path.isdir(env_dir):
                steps = [int(f.replace(".json", "")) for f in os.listdir(env_dir) if f.endswith(".json")]
                if steps:
                    latest = max(steps)
                    from django.shortcuts import redirect
                    return redirect(f"/demo/{sim_code}/{latest}/2/")
        return HttpResponse(content=f"Demo not available for {sim_code}. Run simulation first.", status=404)
    # ... 원본 로직
```

`templates/demo/demo_index.html` (한국어):
```html
{% extends "base.html" %}
{% block content %}
<br>
<div style="max-width:60em; margin:0 auto; padding:1em">
  <h1>🎬 사용 가능한 시뮬레이션</h1>
  {% if sims %}
    {% for sim in sims %}
      <div style="background-color:#f8f9fa; padding:1.5em; border-radius:10px; margin-bottom:1em">
        <h2>{{ sim.name }}</h2>
        <p>📊 최신 step: <strong>{{ sim.latest_step }}</strong></p>
        <a href="/demo/{{ sim.name }}/{{ sim.latest_step }}/2/">
          <button class="btn btn-primary btn-lg">▶ 데모 보기 (step {{ sim.latest_step }})</button>
        </a>
      </div>
    {% endfor %}
  {% else %}
    <div style="background-color:#fff8dc; padding:1.5em; border-radius:10px">
      <h3>⚠️ 시뮬레이션이 없습니다</h3>
      <p>백엔드에서 시뮬레이션을 먼저 시작해주세요...</p>
    </div>
  {% endif %}
</div>
{% endblock content %}
```

## 14. `zsh` 따옴표 함정 (가장 흔하지만 진단 어려움)

### 증상

```bash
$ pip install Pillow>=10.0
zsh: 10.0 not found

$ pip install Django>=4.2,<5
zsh: 4.2 not found
```

### 원인

zsh는 `>`를 **출력 리다이렉션**으로 해석:
- `Pillow>=10.0` → `Pillow=` 파일 + `10.0` (명령어) → "10.0 not found"
- `Django>=4.2,<5` → `Django=` 파일 + `4.2` + `<5` → "4.2 not found"

### 해결

**반드시 따옴표로 감싸기**:
```bash
# ❌ 모두 실패
pip install Pillow>=10.0
pip install Django>=4.2,<5
pip install "numpy>=1.26,<3"

# ✅ 모두 OK
pip install 'Pillow>=10.0'   # 작은 따옴표
pip install "Django>=4.2,<5"  # 큰 따옴표
pip install 'numpy>=1.26,<3'
```

**bash 호환**: bash도 일부 케이스에서 비슷하게 문제될 수 있으니 항상 따옴표 권장.

`requirements.txt`에 `Pillow>=10.0`이 들어있으면 **파일은 따옴표 안에 있으므로 안전** — pip가 파일 내용을 통째로 읽어서 처리. 문제는 `pip install '패키지>=버전'` 형식의 **명령행 직접 입력**일 때만 발생.

## 부록: 패턴 매핑 (정리)

| 증상 | 가장 흔한 원인 | 첫 시도 |
|------|----------------|---------|
| `zsh: 10.0 not found` | `pip install 'Pkg>=10.0'` 따옴표 누락 | 따옴표로 감싸기 |
| `ModuleNotFoundError: No module named 'django'` | venv 미활성화 또는 PYTHONPATH 간섭 | `source .venv/bin/activate && unset PYTHONPATH` |
| `HTTP 500: Missing request extension` | NIM 키 불량 (KEY_1 vs KEY_2) | `source ~/.hermes/secrets/nvidia_keys.env`로 정상 키 export |
| self-test OK + 시뮬 매 step "TOKEN LIMIT EXCEEDED" | `GPT_request`의 `max_tokens` 기본값 100 (silent killer) | `max_tokens=1000`으로 상향 |
| `FileNotFoundError: .../movement/0.json` | live 시뮬에 `movement/` 폴더 누락 | `os.makedirs(..., exist_ok=True)` |
| `KeyError: 'kitchen'` | LLM이 무효한 arena 반환 | 3-tier 방어 (spatial_memory → plan → execute) |
| `TypeError: argument of type 'NoneType'` | plan=None propagate | `execute.py`에 `if plan is None` 가드 |
| `ValueError: invalid literal for int()` | LLM "TOKEN LIMIT EXCEEDED" 응답에서 split 실패 | regex 폴백 + `cr=[["(default task)", 5]]` 폴백 |
| `/path_tester/` 검은 화면 | `visuals/` 38MB 누락 | sparse-checkout으로 visuals만 다운로드 |
| `/demo/` 404 | urls.py에 `^demo/$` 라우트 없음 | `demo_index` view + 템플릿 추가 |
| `reverie.py` 메인 프롬프트만 반복 | `100`만 입력 (공백 + `run` 누락) | `run 100` 한 단어로 |
| `FileExistsError: .../storage/<sim>` | 같은 이름 시뮬이 이전에 partial로 만들어짐 | `rm -rf` 또는 forked에 이전 + new에 `_v2` |
| `urllib.request.urlopen` NIM keep-alive에서 15분+ hang | NIM connection pool 이슈 + urllib 단일 timeout | `requests.post(timeout=(5, 60))` (connect 5s + read 60s) |
| 시뮬 멈춘 것 같음 (CPU 0% + 15분 정지) | 위 keep-alive hang 또는 NIM 응답 stuck | `ps -p <PID> -o %CPU,etime` — CPU 0% + 큰 etime = hang |
| `safe_generate_response`가 fail_safe 안 가고 깨진 응답 사용 | `__func_validate`가 `gpt_response`를 그대로 반환 (truthy) | `__func_validate`에 `'TOKEN LIMIT' in gpt_response or len(resp)<20 → False` 추가 |
| 1 step당 20-30초 예상했으나 5분+ 걸림 | 1 step = 3명 페르소나 × 7 LLM 호출 = 21 LLM 호출 | `run 3`으로 시작 (15-20분), 점진적으로 늘리기 |
| 한국어 few-shot 응답에 `**헤더**`나 `| 표 |`가 들어가 파싱 실패 | LLM의 한국어 응답 형식 변동 | 정규식 우선 + 마크다운 헤더/표 라인 skip + 라인 기반 폴백 |

## 15. 🚨 `urllib.request.urlopen` NIM keep-alive hang (가장 위험한 silent killer)

### 증상

```bash
# 시뮬 step 0~1은 정상 진행 (3명 페르소나 위치 결정)
# 그 후 15분+ 멈춤
$ ps -p <reverie_pid> -o %CPU,etime
%CPU ELAPSED
 0.0  51:46    # ← CPU 0% + 50분째 idle (실제로는 15분 후부터)
```

시뮬 진행이 15분+ 멈추는데 CPU 0% (idle). `reverie.py`는 살아있지만 아무 일도 안 함.

### 원인

`urllib.request.urlopen`이 NIM의 **keep-alive HTTP 연결에서 응답을 read 안 하고 hang**.
- `urlopen(req, timeout=120)`는 **read timeout만** 있고 **connect timeout은 별도 없음** (default 무한대)
- NIM의 `integrate.api.nvidia.com`가 keep-alive 연결을 재사용할 때 가끔 response를 안 보내는 경우가 있음
- urllib는 이 상황에서 socket이 닫히길 기다리면서 hang

### 진단

```bash
# 1. NIM API 직접 호출 (1초 이내 응답 → NIM 정상)
$ time curl -X POST "https://integrate.api.nvidia.com/v1/chat/completions" \
    -H "Authorization: Bearer $NVIDIA_API_KEY_1" \
    -H "Content-Type: application/json" \
    -d '{"model": "openai/gpt-oss-120b", "messages": [{"role":"user","content":"ping"}], "max_tokens": 50}'
real    0m0.807s    # ← NIM 정상

# 2. 시뮬 프로세스 상태
$ ps aux | grep "python3 reverie.py" | grep -v grep
mac  89782  s011  S+  0.0  51:46  python3 reverie.py  # ← S+ (sleeping)
# S+ 상태 + CPU 0% + 큰 etime = I/O hang (보통 NIM keep-alive)

# 3. 확인
$ ps -p 89782 -o %CPU,etime,stat
%CPU   ELAPSED STAT
 0.0    51:46 S+     # ← S+ = sleeping interruptible (I/O wait)
```

### 해결: `urllib.request` → `requests` 전환

```python
# File: gpt_structure.py, _nim_post()
def _nim_post(endpoint, body, timeout=60):
    """NIM API에 POST 요청. 응답은 JSON dict.

    NIM gpt-oss-120b 마이그레이션: urllib.request.urlopen이 keep-alive
    연결에서 hang. requests + connect_timeout 분리.
    timeout은 60초 (LLM 응답은 보통 5-15초).
    """
    import requests as _requests
    url = f"{NIM_BASE_URL}{endpoint}"
    headers = {
        "Authorization": f"Bearer {nim_api_key}",
        "Content-Type": "application/json",
    }
    try:
        r = _requests.post(
            url,
            json=body,
            headers=headers,
            timeout=(5, timeout),  # (connect, read) — 빠른 fail
        )
        r.raise_for_status()
        return r.json()
    except _requests.exceptions.Timeout:
        raise urllib.error.URLError(f"NIM request timeout ({timeout}s)")
    except _requests.exceptions.RequestException as e:
        if hasattr(e, "response") and e.response is not None:
            raise urllib.error.HTTPError(
                url, e.response.status_code, str(e), {}, None
            )
        raise urllib.error.URLError(str(e))
```

**핵심**:
- `timeout=(5, 60)` — connect 5초, read 60초 (tuples, NIM connection establishment는 빨라야 함)
- `requests` 패키지는 `requirements.txt`에 이미 있음 (`requests>=2.28` 또는 `urllib3[socks]~=1.26`)
- 예외 변환으로 기존 `except urllib.error.HTTPError` 호환성 유지

### 만약 requests도 hang한다면

매우 드물지만 NIM이 모든 endpoint에서 hang하는 경우 (rare outage), 시뮬 안전하게 중단:
- `kill -INT <reverie_pid>` (Ctrl+C) — 안전한 시그널
- `kill -9`는 사용 자제 (storage/ 데이터 손상 가능)

## 16. 시뮬 진행 시간 가이드 (run N은 N개 step)

`run N`이 N개 step을 진행하지만 **1 step당 다수 LLM 호출**이 있음:

### step당 LLM 호출 수 (3 페르소나)

| 호출 종류 | 페르소나당 | 3명 합계 |
|-----------|----------|---------|
| `perceive()` (perception + importance) | 2 | 6 |
| `retrieve()` (생성 임베딩) | 0~2 | 0~6 |
| `plan()` (decomp + action + obj) | 4 | 12 |
| `reflect()` (조건부) | 1 | 3 |
| **합계** | ~7 | **~21 LLM 호출/step** |

### 단계별 진행 시간

| 명령 | step 수 | LLM 호출 | 예상 시간 |
|------|--------|----------|----------|
| `run 1` | 1 | ~21 | 1-2분 |
| `run 3` | 3 | ~63 | 5-10분 |
| `run 5` | 5 | ~105 | 10-20분 |
| `run 10` | 10 | ~210 | 20-40분 |
| `run 50` | 50 | ~1050 | 1.5-3시간 |
| `run 100` | 100 | ~2100 | 3-6시간 |

### 진행 모니터링 (run N 동안)

```bash
# 30초마다 step 수 확인
for i in {1..30}; do
  sleep 30
  echo "$(date +%H:%M) Steps: $(ls /your/fork/environment/frontend_server/storage/<sim>/environment/ 2>/dev/null | wc -l)"
done

# 1분에 1 step 정도 진행 (정상)
```

### 진행 멈춤 진단 (가장 흔한 두 케이스)

**케이스 1: 시뮬이 정상 진행 중 (느린 것일 뿐)**
```bash
$ ps -p <PID> -o %CPU,etime,stat
%CPU ELAPSED STAT
12.0   5:23  R+    # ← CPU 12% + R+ (running) = 정상
```

→ 그냥 더 기다리기.

**케이스 2: 시뮬 hang (CPU 0% + 15분 정지)**
```bash
$ ps -p <PID> -o %CPU,etime,stat
%CPU ELAPSED STAT
 0.0   15:43  S+    # ← CPU 0% + S+ (sleeping) = hang
```

→ `kill -INT <PID>` + `requests.post` 패치 확인 (위 15번 섹션).

## 17. `__func_validate`가 fail_safe를 가로채는 버그

### 증상

LLM이 "TOKEN LIMIT EXCEEDED" 텍스트로 응답 → `__func_validate` 호출 →
`func_clean_up` 호출 (try/except로 모든 예외 swallow) → `gpt_response` (truthy) 그대로 반환 →
`safe_generate_response`가 fail_safe 안 가고 깨진 응답을 plan()에 전달 → 시뮬이
(default task) 폴백으로 무한 진행.

### 원인

```python
# File: run_gpt_prompt.py (원본)
def __func_validate(gpt_response, prompt=""):
    try:
        __func_clean_up(gpt_response)
    except:
        pass  # ← 모든 예외 무시
    return gpt_response  # ← truthy 값 항상 반환
```

`gpt_response`가 "TOKEN LIMIT EXCEEDED" 문자열이라도 non-empty string이라 truthy.

### 해결

```python
# File: run_gpt_prompt.py
def __func_validate(gpt_response, prompt=""):
    # NIM gpt-oss-120b 마이그레이션: 깨진 응답 감지
    if not gpt_response or "TOKEN LIMIT" in gpt_response or len(gpt_response.strip()) < 10:
        return False
    try:
        __func_clean_up(gpt_response)
    except:
        return False
    return gpt_response
```

### 보강: `safe_generate_response` 자체에서 감지

```python
# File: gpt_structure.py
def safe_generate_response(prompt, gpt_parameter, repeat=5, fail_safe_response="error",
                            func_validate=None, func_clean_up=None, verbose=False):
    for i in range(repeat):
        resp = GPT_request(prompt, gpt_parameter)
        # NIM gpt-oss-120b 마이그레이션: 깨진 응답 감지
        if not resp or "TOKEN LIMIT" in resp or len(resp.strip()) < 20:
            if debug:
                print(f"[WARN] bad response (attempt {i+1}): retry")
            continue  # ← 5회 안에 정상 응답 못 받으면 fail_safe 반환
        if func_validate and func_validate(resp, prompt=prompt):
            return func_clean_up(resp, prompt=prompt) if func_clean_up else resp
    return fail_safe_response
```

## 18. 한국어 few-shot 응답 파싱 (markdown + 표 헤더 + 정규식)

### 증상

LLM이 한국어 task_decomp 응답에 다음 형식을 자주 출력:
- `**이름 – ...**` markdown 헤더
- `| 순번 | 수행 작업 |` 표 헤더
- `1) ...` 한 줄 형식 (줄바꿈 없음)

원본 split 로직(`split("duration in minutes")` 등)이 깨짐.

### 해결: 정규식 우선 + 라인 기반 폴백

```python
# File: run_gpt_prompt.py, __func_clean_up
import re as _re
pattern = r'(\d+)\)\s*(.*?)\(duration in minutes:\s*(\d+)'
matches = _re.findall(pattern, gpt_response, re.DOTALL)
cr = []
if matches:
    # 정규식 매칭 성공 (DOTALL로 여러 줄 응답도 잡음)
    for _, task, dur in matches:
        task = task.strip()
        if task.endswith("."): task = task[:-1]
        task = _re.sub(r'\s+', ' ', task).strip()
        try:
            cr += [[task, int(dur)]]
        except ValueError:
            pass
if not cr:
    # 폴백: 라인 기반 파싱 + 마크다운 헤더/표 라인 skip
    temp = [i.strip() for i in gpt_response.split("\n")]
    cleaned = []
    for line in temp:
        if not line: continue
        if (line.startswith("**") and line.endswith("**")) or \
           line.startswith("|") or line.startswith("---") or \
           (line.startswith("**") and ("–" in line or "-" in line)):
            continue
        cleaned.append(line)
    # ... 기존 라인 기반 파싱
```

### 진단

```bash
# LLM 응답 직접 확인 (정규식 매칭 확인)
python3 -c "
import re
resp = '''
**이름 – 09:00 ~ 12:00 (총 180분)**
1) task_name (소요 시간: 15분, 남은 시간: 165분)
2) task_name (소요 시간: 30분, 남은 시간: 135분)
'''
pat = r'(\d+)\)\s*(.*?)\(duration in minutes:\s*(\d+)'
print(re.findall(pat, resp, re.DOTALL))
# [('1', 'task_name', '15'), ('2', 'task_name', '30')] ← 매칭 OK
"
```

## 부록: 진단 의사결정 트리

```
시뮬 hang 증상
├─ CPU 0% + 큰 etime (15분+)
│  └─ urllib keep-alive hang? → #15 섹션 참조
│
├─ CPU 정상 (5-20%) + 진행 느림
│  └─ 정상. 더 기다리거나 run N 줄이기 → #16 섹션 참조
│
└─ 즉각 에러 (예: KeyError, ValueError, TypeError)
   ├─ "TOKEN LIMIT EXCEEDED" 반복? → fail_safe 안 가는 버그 → #17 섹션
   ├─ KeyError? → act_arena 폴백 → 8번 섹션
   ├─ plan=None? → execute None 가드 → 9번 섹션
   └─ 응답 파싱 실패? → 정규식 폴백 → #18 섹션
```
