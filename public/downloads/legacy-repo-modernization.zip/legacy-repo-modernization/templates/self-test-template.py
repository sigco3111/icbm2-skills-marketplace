#!/usr/bin/env python3
"""
Self-test 도구 템플릿.

legacy-repo-modernization 작업의 위임 시, 이 템플릿을 복사해 다음을 검증:
1. LLM API 호출 (chat completion)
2. 임베딩 호출
3. 핵심 시뮬/통합 모듈 호출 (예: daily_planning, task_decomp, agent_chat)

출력 형식:
- [N] 검증 항목 → 결과 (한 줄)
- 성공/실패 시각적 표시 (✅/❌)

사용법:
1. API 키 환경변수 설정
2. python3 test_template.py
3. 모든 항목 통과 시 종료 코드 0, 실패 시 1

실제 사용 예시: generative-agents-kr/reverie/backend_server/test_kr_sim.py
"""

import os
import sys

# ============================================================================
# 1. 환경 검증
# ============================================================================

def test_environment():
    """API 키 + 핵심 패키지 import 확인."""
    print("=== 환경 검증 ===")
    api_key = os.environ.get("NVIDIA_API_KEY", "")
    if not api_key or len(api_key) < 20:
        print(f"  ❌ NVIDIA_API_KEY 환경변수 미설정 또는 너무 짧음 (현재 길이: {len(api_key)})")
        return False
    print(f"  ✅ NVIDIA_API_KEY (길이: {len(api_key)})")

    try:
        import django
        print(f"  ✅ Django {django.__version__}")
    except ImportError:
        print("  ❌ Django 미설치 (venv 활성화 확인)")
        return False

    return True


# ============================================================================
# 2. LLM 호출 검증 (간단 ping)
# ============================================================================

def test_chat_completion():
    """가장 단순한 chat completion 호출. reasoning 모델 처리 포함."""
    print("\n=== LLM 호출 검증 ===")
    try:
        from your_module import ChatGPT_request  # 자신의 모듈 import
        result = ChatGPT_request("ping 한 단어만 답하세요")
        if result and "ping" in result.lower() or "pong" in result.lower():
            print(f"  ✅ LLM 호출: '{result[:50]}'")
            return True
        print(f"  ❌ LLM 응답 이상: '{result[:100]}'")
        return False
    except Exception as e:
        print(f"  ❌ LLM 호출 실패: {e}")
        return False


# ============================================================================
# 3. 임베딩 검증 (비대칭)
# ============================================================================

def test_embedding():
    """passage/query 비대칭 임베딩 검증."""
    print("\n=== 임베딩 검증 ===")
    try:
        from your_module import get_passage_embedding, get_query_embedding
        p = get_passage_embedding("이서연은 카페에서 커피를 마신다")
        q = get_query_embedding("이서연이 마신 음료는?")
        if len(p) != len(q):
            print(f"  ❌ 차원 불일치: passage {len(p)}, query {len(q)}")
            return False
        if len(p) < 100:
            print(f"  ❌ 차원 너무 작음: {len(p)}")
            return False
        # 코사인 유사도 계산
        import numpy as np
        score = float(np.dot(p, q) / (np.linalg.norm(p) * np.linalg.norm(q)))
        print(f"  ✅ 임베딩 정상: 차원 {len(p)}, 유사도 {score:.3f}")
        return True
    except Exception as e:
        print(f"  ❌ 임베딩 실패: {e}")
        return False


# ============================================================================
# 4. 시뮬 핵심 모듈 검증 (예: persona 행동 생성)
# ============================================================================

def test_sim_module():
    """시뮬레이션의 핵심 모듈 호출. 실제 데이터로 검증."""
    print("\n=== 시뮬레이션 핵심 모듈 검증 ===")
    try:
        # from your_module import simulate_step  # 시뮬 함수
        # result = simulate_step(persona="이서연", context={...})
        # if result and len(result) > 0:
        #     print(f"  ✅ 시뮬 모듈 호출: '{result[:80]}...'")
        #     return True
        # return False

        # placeholder — 자신의 시뮬 검증으로 교체
        print("  ⚠️  placeholder: 시뮬 검증 함수를 구현하세요")
        return True
    except Exception as e:
        print(f"  ❌ 시뮬 모듈 실패: {e}")
        return False


# ============================================================================
# 메인
# ============================================================================

def main():
    print("=" * 70)
    print("🧪 Self-test")
    print("=" * 70)

    tests = [
        test_environment,
        test_chat_completion,
        test_embedding,
        test_sim_module,
    ]

    passed = 0
    failed = 0
    for test in tests:
        if test():
            passed += 1
        else:
            failed += 1

    print("\n" + "=" * 70)
    print(f"📊 결과: {passed} 통과, {failed} 실패")
    print("=" * 70)

    sys.exit(0 if failed == 0 else 1)


if __name__ == "__main__":
    main()
