---
name: legacy-repo-modernization
description: 2022년 이전 Python 코드베이스(Django 2.x, Python 3.7-3.9, requirements.txt fixed-version)를 2026년 환경(Python 3.11+, Django 4.x LTS, PEP 668)으로 마이그레이션할 때 사용. requirements.txt 사전 패치, venv 워크플로우, NIM/OpenAI 호환 API 통합, PYTHONPATH Hermes 간섭 회피, Django 2→4 마이그레이션 (corsheaders, url→re_path, staticfiles→static), reasoning 모델 content=None 처리, **GPT_request max_tokens=100 silent fail (TOKEN LIMIT 진짜 원인), _nim_embed 빈텍스트/500 폴백, movement/ 디렉토리 자동 생성, sparse-checkout으로 visuals 38MB 다운로드, /demo/ 인덱스 view, zsh `10.0 found` 따옴표 함정, urllib→requests NIM keep-alive hang, __func_validate truthy 버그, 시뮬 진행 시간 가이드(run N × 21 LLM/step), 한국어 few-shot 정규식 파싱, 진단 의사결정 트리** 까지 검증 도구 작성 패턴을 다룬다.
tags: [nvidia-nim, django-migration, python-venv, openai-to-nim, reasoning-models, agent-simulation, macos-sonoma, korean, django, sparse-checkout, zsh]
---
# Legacy Repo Modernization (2022 → 2026)