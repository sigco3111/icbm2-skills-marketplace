---
name: scoring-system-analyzer
description: Reverse-engineer public ranking/scoring/leaderboard systems (gitfut, wakatime, codeforces rating, dev.to, StackOverflow rep, npmtrends 등) — score 공식 clone, real signals replay, counterfactual 시뮬레이션으로 "왜 내 점수가 X인지 / 어떻게 올리는지" 진단하는 워크플로우. Use when user shares a public profile URL with a score and asks "왜 이렇게 나왔어?" / "올리려면 뭐 해야 해?" / "점수 떨어진 원인".
version: 1.0.0
author: HyeRin
license: MIT
metadata:
  hermes:
    tags: [scoring, reverse-engineering, counterfactual, diagnostics, profile, leaderboard]
    related_skills: [auto-researcher, smart-summary, stock-market-pro]
---

# Public Scoring System Analyzer

## 사용 시기

- 사용자가 public ranking/scoring/leaderboard URL을 던지고 "내 점수 분석해줘" / "왜 X점이야?" / "올리려면?" 같은 진단 요청을 보낼 때
- 예: gitfut (`/u/{login}`), wakatime, codeforces rating, dev.to badge, StackOverflow rep, npmtrends star growth, dev.to "tag" 페이지 점수, `codestats.net`/`wakatime.com` 등
- "점수 떨어진 원인" 같이 시간 변화 분석도 포함
- **NOT** 내부 점수 시스템 (사용자 정의 알고리즘) — 이건 사용자가 직접 명시한 경우만

## 핵심 원칙 (★ 2026-07-24 gitfut 진단에서 도출)

1. **공식(open-source)이어야 정확하게 reverse-engineer할 수 있다.** gitfut는 GitHub에 public code였고 그게 가능했음. 비공개 scoring 시스템은 추정만 가능 — 그 경우 단정 금지.
2. **공식 clone → real signals → replay**이 3-step이다. scoring function을 1:1 복사하고, 사용자의 real input을 측정하고, 그 함수를 그대로 돌려 결과를 본다.
3. **counterfactual = "내가 X를 하면 점수가 얼마나 오르나"**. Lg/sqrt/sigmoid 같은 비선형 함수가 들어가므로 ±1 단위 perturbation이 점수에 미치는 영향이 비대칭. 반드시 시뮬레이션.
4. **사용자 개선 가능 신호 vs 불가 신호**를 명확히 분류. 예: commit date 위조는 GitHub이 봉쇄, star 누르는 건 사람이 결정. 자력으로 못 만지는 시그널은 추천에서 제외.

## 표준 워크플로우 (5 step)

### Step 1: Source code 확보

```bash
# 1a) public repo를 clone (예: younesfdj/gitfut)
git clone --depth 1 https://github.com/<org>/<project>.git /tmp/<project>

# 1b) scoring/ 디렉터리 찾기
find /tmp/<project> -type d -name "scoring" -o -name "rating" -o -name "leaderboard"
# 또는 grep으로
grep -rln "weightedOVR\|compute.*score\|rating.*=.*[0-9]" /tmp/<project>/lib
```

**함정**: SSR/CSR SPA는 HTML이 아니라 client-side hydration. `curl <page>`만으론 데이터가 안 나옴 → GraphQL/internal API endpoint가 있는지 확인 (예: `api.github.com/graphql` for gitfut).

### Step 2: scoring 공식 1:1 복사

scoring engine을 그대로 Node/Python으로 옮긴다. 변수명·함수명 보존, clamp·round·sigmoid·Lg 같은 비선형 변환 일체 보존.

```js
// 예: gitfut engine.ts 그대로 복사
const Lg = x => Math.log10(Math.max(0, x) + 1);
const sigmoid = z => 1 / (1 + Math.exp(-z));
// rawStats / center / zscore / spike / weightedOVR / legacyScore / buildCard
```

**이유**: 공식 creator가 "Lg 0.07 × 12 = 0.84 stat point" 같은 미세 tuning을 해놓음. 큰 흐름만 이해하려고 `mean(stats)` 같은 단순화하면 결과가 ±5 OVR 어긋남. **1:1 복사가 정답**.

### Step 3: 사용자 real signals fetch

사용자 profile에서 실제 점수 input을 받아온다.

```bash
# GraphQL/REST 적절히 (각 시스템의 실제 endpoint 사용)
gh api graphql -f query="$(cat query.txt)" -F login=<login> -F from=<...> > /tmp/raw.json

# 또는 페이지 자체에서 추출 (SPA hydration JSON dump)
curl -sL "https://<system>/u/<login>" > /tmp/page.html
# → React/Next.js payload에서 score + stat 추출
```

**핵심**: 모든 input 변수를 빠짐없이 가져와야 함. 하나 빠뜨리면 그 변수의 default값(보통 0)으로 들어가 점수 결과가 ±10 어긋남.

### Step 4: Replay → 현재 카드/점수 시뮬레이션

```js
const card = buildCard(signals);
console.log(card);  // { stats: {pac:...,sho:...}, position: '...', overall: 69, ... }
```

**검증**: 시뮬 결과가 공개 페이지의 실제 점수와 일치하는지. gitfut의 경우 페이지 6 stat이 PAC 76 / DRI 80 / SHO 65 / DEF 51 / PAS 62 / PHY 72 / OVR 69 — 시뮬 결과가 이거와 정확히 일치해야 공식 재현이 검증된 것.

불일치하면 → 공식에 빠뜨린 모듈이 있는 것 (예: gitfut의 `applyTension` / `cohesion` / `iconAllowlist`). 다시 코드 보면서 채워 넣기.

### Step 5: Counterfactual 시뮬레이션

```js
function mutate(s, label) {
  s = { ...s, ...changes };
  const { overall } = buildCard(s);
  console.log(`${label} → OVR ${overall}`);
}
mutate({ followers: 30 }, "+12 followers");
mutate({ max_repo_stars: 200 }, "viral repo 1개");
mutate({ total_stars_owned: 2000 }, "stars 25 → 2000");
mutate({ active_years: 5 }, "year 분포 5");
```

**정렬**: 출력 표를 Δ OVR 내림차순으로 정렬. **사용자한테 "어떤 게 큰 효과냐"는 순서로 보여주기**.

## 자력 가능 vs 불가능 시그널 분류

| 시그널 종류 | 자력 가능? | 비고 |
|---|---|---|
| star 받기 (max_repo_stars, total_stars) | ⚠️ 부분 | 메가 히트 1개 가능, 다수는 시간 누적 |
| followers | ⚠️ 가능 | 콘텐츠 자동화, share 카드 |
| public_repos (numeric) | ✅ 가능 | 새 repo 생성 |
| languages | ✅ 가능 | 새 언어 hello-world |
| recent_commits/PRs/reviews | ✅ 가능 | 실제 작업 = 정직한 활동 |
| active_years (createdAt 연도 분포) | ⚠️ 1년 단위 | 매년 활동 |
| account_age_years | ❌ 불가 | 시간 누적만 |
| **commit date 위조** | ❌ 봉쇄 | GitHub이 push 시 server-side 검증 |
| **자동 외부 PR (bot)** | ❌ 봉쇄 | GitHub rate limit + 정책 |
| 별 직접 누르기 | ❌ 불가 | 다른 사람 결정 |

**권장 액션** = 위 표의 ✅ + ⚠️ 가능 영역만. ❌ 봉쇄 영역은 추천에서 제외.

## 출력 템플릿

```
[시스템명] /[user-id] 카드 진단

📋 현재 카드
- OVR: 69 (SILVER, CAM Fantasista)
- 6 stat: PAC 76 / DRI 80 / SHO 65 / DEF 51 / PAS 62 / PHY 72
- 최근 변화: 71 → 69 (직전 ±2 노이즈 구간)

🔍 원인 분석
- [점수 변동의 진짜 원인 1-2개, 공식 trace 기반]
- 단정 금지: 공식 클론이 검증된 경우만 단언

📈 신호별 효과 (counterfactual 내림차순)
| 시그널 | 현재 → 변경 | OVR Δ | 자력 가능 |
|---|---|---|---|
| max_repo_stars | 2 → 200 | +5 | ⚠️ |
| total_stars | 25 → 2000 | +12 | ⚠️ |
| followers | 18 → 50 | +3 | ⚠️ |
| recent_commits | 1171 → 1500 | +2 | ✅ |

🎯 추천 실행 (ROI 순)
1. [구체적 작업 1] → +X OVR
2. [구체적 작업 2] → +Y OVR

⚠️ 봉쇄된 영역
- commit date 위조 (GitHub 서버 검증)
- 자동 외부 PR (rate limit + bot 정책)
```

## 검증 체크리스트

1. **공식 클론 정확성**: 시뮬 결과 stat 6개가 페이지의 stat 6개와 1:1 일치
2. **OVR 일치**: 시뮬 OVR이 페이지 OVR과 정확히 일치 (예: 69 = 69)
3. **counterfactual 현실성**: ±10 OVR 변동 신호는 검토. 비현실적으로 큰 변동은 log/sigmoid 곡선 한계 무시한 것
4. **사용자 액션 가능성**: 봉쇄 영역은 추천 제외

## 함정 / 함정 회피

### 함정 1: SPA HTML에 데이터 없음

gitfut, dev.to, StackOverflow 같이 SSR이 client-side로 hydration하는 페이지는 `curl`로 HTML 받아도 score가 안 나옴. 이 경우:

```bash
# GraphQL endpoint가 노출됐는지 확인
curl -sI "https://<system>/api/u/<user>" 
# 200이면 데이터 fetch. 404면 GraphQL/REST 없음 → client JS에서 직접 추출 또는 skip
```

또는: `window.__NEXT_DATA__` / `window.__INITIAL_STATE__` 같은 hydration payload grep.

### 함정 2: 공식에 "위조 가능 변수"가 있어 보임

예: gitfut 공식의 `recent_spike`처럼 `recent_contributions > 2 * lifetime/active_years`. 한쪽이 작으면 자동으로 충족돼 보이지만, GitHub 활동 그래프 + 공개 통계가 그 데이터를 직접 보이므로 "위조 시 노출" 위험.

**규칙**: 공식상 가능해도 cross-verifiable 한 신호는 위조 비권장.

### 함정 3: ±2 노이즈를 "이벤트"로 해석

scoring 공식이 `Math.round()`로 반올림하면 `Math.round(0.5)`가 시스템에 따라 짝수/홀수 반올림 결과가 다름. 71 → 69 같은 ±2 변동은 **공식 자체 노이즈**이지 사용자 활동 변화가 아닐 수 있음.

**규칙**: "점수가 떨어졌다"는 사용자 보고 → 변동이 ±3 이상인지 확인. ±2 이하면 "공식 노이즈 + 시간 누적"으로 설명.

### 함정 4: 자력 가능성 잘못 분류

`max_repo_stars = 200` 같은 메가 히트는 사용자 액션이 "1개 레포 만들기"로 보이지만 실제론 **외부 사용자가 별을 누르는 행위**가 뒷받침. 자력으로 가능한 건 **별 받기 좋은 repo 1개 패키징**이지 별 자체가 아님.

**규칙**: "이 신호가 X에 의존하나?" 트레이스. 다른 사람의 결정에 의존하면 자력 가능이 아님.

## 참고 자료

- `references/gitfut-case-study-2026-07-24.md` — 첫 실전 사례. scoring engine 1:1 복제 + sigco3111의 real signals fetch + 10개 counterfactual 시뮬레이션
- `references/scoring-replay-skeleton.js` — 새 시스템 분석 시 보일러플레이트 Node 코드
- `references/counterfactual-table-template.md` — 시그널별 OVR Δ 표 + 자력 가능성 분류 표

## 금지 사항

- 비공개/내부 scoring 시스템 단정 분석 (가정·추측만 가능)
- 공식 1:1 복사 없이 "공식 같다"로 단정
- 봉쇄 영역(commit 위조, bot PR) 추천에 포함
- ±2 노이즈 변동을 "사용자 활동 변화"로 해석
- 사용자 외부 결정에 의존하는 신호(max_repo_stars 등)를 "자력 가능 1줄 작업"으로 단정
- OVR +N을 단기(1~2주) 안에 가능하다고 약속
