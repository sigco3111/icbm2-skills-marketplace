# Counterfactual 시뮬레이션 결과 표 템플릿

`scoring-system-analyzer` 워크플로우 Step 5에서 사용. 시스템별 OVR (또는 score) 단위에 맞게 조정.

## 출력 표 (콘솔 / 텔레그램 / 노션 공통)

```markdown
| 신호 | 현재 → 변경 | OVR Δ | 자력 가능 | 비고 |
|---|---|---|---|---|
| total_stars_owned | 25 → 2000 | +12 | ⚠️ | 메가 히트 1개 |
| max_repo_stars | 2 → 200 | +5 | ⚠️ | 1개 레포 viral |
| active_years | 2 → 5 | +7 | ✅ | 1시간 push 분포 |
| followers | 18 → 50 | +3 | ⚠️ | 콘텐츠 자동화 |
| recent_contributions | 1171 → 1500 | +2 | ✅ | 누적 |
| prs_to_others | 0 → 80 | +2 | ✅ | 20 PR |
| reviews | 1 → 60 | 0 | ✅ | log 곡선 정점 |
| languages | 9 → 12 | 0 | ✅ | sqrt 곡선 정점 |
| lifetime | 1232 → 5000 | +1~+2 | ⚠️ | 시간 누적 |
```

## 자력 가능성 분류 (★ 핵심 표)

| 시그널 종류 | 자력 가능? | 비고 |
|---|---|---|
| star 받기 (`max_repo_stars`, `total_stars`) | ⚠️ 부분 | 메가 히트 1개 가능, 다수는 시간 누적 |
| followers | ⚠️ 가능 | 콘텐츠 자동화, share 카드 |
| public_repos (numeric) | ✅ 가능 | 새 repo 생성 |
| languages | ✅ 가능 | 새 언어 hello-world |
| recent_commits/PRs/reviews | ✅ 가능 | 실제 작업 = 정직한 활동 |
| active_years (createdAt 연도 분포) | ⚠️ 1년 단위 | 매년 활동 |
| account_age_years | ❌ 불가 | 시간 누적만 |
| **commit date 위조** | ❌ 봉쇄 | GitHub이 push 시 server-side 검증 |
| **자동 외부 PR (bot)** | ❌ 봉쇄 | GitHub rate limit + 정책 |
| 별 직접 누르기 | ❌ 불가 | 다른 사람 결정 |

## 봉쇄 영역 (사용자 추천에서 제외)

1. **commit date 위조** — GitHub이 2017부터 server-side에서 push 시각 검증
2. **자동 외부 PR (bot)** — bot-detected user 차단 + rate limit
3. **인위 star 조작** — 다른 사람의 결정
4. **계정 전환** — 본 시그널이 다른 시스템/계정과 분리돼 있을 때

## 정렬 규칙

표는 **OVR Δ 내림차순**으로 정렬. 효과 작은 신호부터 추천에 넣지 않음.

## 비선형 주의

- **Lg** (log10): 작은 baseline에서 +1 unit이 큰 효과, 큰 baseline에서 +1 unit은 미미. 예: `Lg(0+1)=0`, `Lg(20+1)=1.32`, `Lg(2000+1)=3.30`
- **sqrt** (7·sqrt): 9 → 12는 0.23 차이 → 1.6 stat point. 효과 작음
- **sigmoid** (0~1 bounded): ±0.5 변동이 OVR에 결정적
- **Math.round**: 0.5 경계에서 반올림 결과 변동 (±1 OVR 흔들림)
- **cap** (K.ovrCap=88): OVR 자체가 88에서 잘림 → 그 이상 신호는 무의미

## counterfactual 변동 크기 가이드라인

| 변동 크기 | 의미 | 사용자 액션 가능성 |
|---|---|---|
| ±1 OVR | 공식 노이즈 (Math.round 경계) | 의미 없음 |
| ±2~3 OVR | 시그널 한 단위 변동 (보통) | 시간 누적 + 약간의 노력 |
| ±5~7 OVR | 시그널 큰 변동 (예: 1년 active 분포) | 단기 작업 가능 |
| ±10 OVR | 시그널 극단 변동 (예: 메가 히트) | 단기 불가능, 장기 |
| ±15 OVR | 비현실적 | counterfactual 자체 오류 의심 |
