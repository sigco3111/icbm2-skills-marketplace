# gitfut / sigco3111 카드 진단 — 2026-07-24 첫 사례

## 상황

사용자: `https://gitfut.com/sigco3111` 의 점수가 71점에서 69로 하락. 원인 + 상승책 요청.

## Step 1: Source 확보

gitfut는 GitHub public: `https://github.com/younesfdj/gitfut` (Next.js, TypeScript, App Router)

```bash
git clone --depth 1 https://github.com/younesfdj/gitfut.git /tmp/gitfut-src
# → lib/scoring/ 디렉터리에 engine / constants / attributes / playstyles / types
```

scoring 핵심 파일:

- `lib/scoring/engine.ts` — `buildCard(s: Signals): Card` 함수. 6 stat 계산 → OVR 산출 → 등급 → archetype
- `lib/scoring/constants.ts` — K (가중치 상수), WEIGHTS (포지션별 가중치), STATS, ATTACK_STATS
- `lib/scoring/attributes.ts` — playstyles / skill moves / work rate 등
- `lib/github/client.ts` — GraphQL query. contributionsCollection으로 모든 signals fetch
- `lib/github/signals.ts` — RawPayload → Signals 정규화

## Step 2: 엔진 1:1 복사

`engine.ts`의 다음 함수를 `/tmp/compute.js` Node로 옮김:

```js
const Lg = x => Math.log10(Math.max(0, x) + 1);
const sigmoid = z => 1 / (1 + Math.exp(-z));
const lerp = (a, b, t) => a + (b - a) * t;
const clamp = (x, lo, hi) => Math.max(lo, Math.min(hi, x));
const mean = a => a.reduce((s, x) => s + x, 0) / a.length;

const K = {
  magnitude: { w1:0.5, w2:0.4, w3:0.5, w4:0.08, b:-2.8, lo:48, hi:82 },
  tension: { alpha:0.7, pairs:[["sho","def"],["dri","phy"],["pac","def"]] },
  spike: { base:8, cohesion:0.6 },
  legacy: { a:1.0, b:0.7, c:0.3, d:0.3, e:0.3, f:6.0, activeCap:15, bonusMax:11 },
  ovrCap: 88,
};
const WEIGHTS = {
  Forward:   { pac:0.2,  sho:0.3,  pas:0.1,  dri:0.2,  def:0.05, phy:0.15 },
  Playmaker: { pac:0.1,  sho:0.15, pas:0.3,  dri:0.25, def:0.1,  phy:0.1  },
  Anchor:    { pac:0.1,  sho:0.05, pas:0.15, dri:0.1,  def:0.4,  phy:0.2  },
};

function rawStats(s) {
  const o = {
    pac: 36 + 12 * Lg(s.recent_contributions),
    sho: 36 + 13 * Lg(s.total_stars_owned) + 5 * Lg(s.max_repo_stars),
    pas: 40 + 12 * Lg(s.prs_to_others) + 9 * Lg(s.followers),
    dri: 58 + 7 * Math.sqrt(s.languages),
    def: 40 + 14 * Lg(s.reviews + s.issues_closed),
    phy: 40 + 9 * Lg(s.total_contributions_lifetime) + 2.2 * Math.min(s.active_years, 12),
  };
  for (const k of STATS) o[k] = clamp(Math.round(o[k]), 1, 99);
  return o;
}
// ... (center, zscore, applyTension, spike, weightedOVR, legacyScore, buildCard)
```

**중요**: 한 줄도 단순화하지 말 것. `applyTension` / `cohesion` / `Math.round` 등 다 보존.

## Step 3: sigco3111 real signals fetch

GraphQL endpoint: `https://api.github.com/graphql`. `gh api graphql`로 직접 호출.

```js
// query: contributionsCollection + repositories (top 100 by stars)
const Q1 = await gql(`query Profile(...) { user(...) { ... } }`);

// 5개 연도 lifetime batch
const LIF = await gql(`query Life($login) { user(login) { y2022:..., y2023:..., ... } }`);
```

sigco3111 시그널 (2026-07-24 시점):

| 신호 | 값 |
|---|---|
| followers | 18 |
| total_stars_owned | 25 |
| max_repo_stars | 2 |
| languages (owned ∪ recent) | 9 |
| recent_commits (last 365d) | 1171 |
| recent_prs | 0 |
| recent_reviews | 1 |
| recent_issues | 2 |
| recent_contributions | 1174 |
| total_contributions_lifetime | 1232 |
| active_years | 2 (2025, 2026만 push) |
| account_age_years | 4.35 (2022-03 가입) |
| recent_spike | false |
| public_repos | 224 |

## Step 4: Replay → 검증

`buildCard(signals)` 결과:

```js
{
  stats: { pac:76, sho:65, pas:62, dri:80, def:51, phy:72 },
  position: 'CAM',
  family: 'Playmaker',
  baseOVR: 68,
  overall: 69,
  L: 0.12220859368249223
}
```

페이지 6 stat과 정확히 일치 → 공식 1:1 복제 검증 완료.

## Step 5: Counterfactual 시뮬

```js
function mutate(label, changes) {
  const s = { ...signals, ...changes };
  const { overall } = buildCard(s);
  console.log(`${label} -> ${overall}`);
}

mutate("+12 followers (18→30)",  { followers: 30 });
mutate("+32 followers (18→50)",  { followers: 50 });
mutate("recent 1500 commits",     { recent_contributions: 1500 });
mutate("languages 8→12",          { languages: 12 });
mutate("max_repo_stars 200",      { max_repo_stars: 200 });
mutate("total_stars 600",         { total_stars_owned: 2000 });
mutate("PRs to others 0→80",      { prs_to_others: 80 });
mutate("reviews 1→60",            { reviews: 60 });
mutate("active_years 2→5",        { active_years: 5 });
mutate("lifetime 1232→5000",      { total_contributions_lifetime: 5000 });
```

결과 (정확):

| 변동 | OVR |
|---|---|
| (현재) | 69 |
| followers 50 | 72 |
| recent_contributions 1500 | 71 |
| languages 12 | 69 |
| max_repo_stars 200 | 74 |
| **total_stars 2000** | **81** |
| PRs to others 80 | 71 |
| reviews 60 | 69 |
| **active_years 5** | **76** |
| lifetime 5000 | 71 |

## 원인 분석 (71 → 69 하락)

gitfut 공식 OVR = `clamp(baseOVR + Math.round(11 * L), 1, 99)` where baseOVR=68, L=0.122.

- `Math.round(11 * 0.122) = Math.round(1.34) = 1` → 68+1 = **69**
- 6개월 전 시점에 L=0.130 정도였으면 `Math.round(1.43) = 1`로 동일하게 69.
- L=0.140을 넘는 순간 68+2=70. L=0.180+ 이면 68+2=70 또는 68+3=71.
- **수치 71은 Lg 곡선 한계로 ±0.03 변동에 결정**됨. 71 → 69는 **공식 노이즈 + recent_spike 트리거 변동**이지 사용자 활동 변화가 아님.

게다가 `recent_spike = recent_contrib > 2 * (lifetime / active_years)`:
- 1174 > 2*(1232/2) = 1232 → false (1.9배)
- 분기/월 경계에서 분모/분자 변동으로 false ↔ true 경계 진동 → in-form 트리거 on/off 가능성

## 사용자 액션 가능성

| 신호 | Δ OVR | 자력 가능 |
|---|---|---|
| **total_stars 25 → 2000** | **+12** | ⚠️ 메가 히트 1개 (패키징) |
| **active_years 2 → 5** | **+7** | ✅ 1시간 push 분포 (단, createdAt 분포 4년치) |
| max_repo_stars 2 → 200 | +5 | ⚠️ 1개 별 받기 |
| followers 18 → 50 | +3 | ⚠️ 콘텐츠 자동화 |
| recent_contributions 1500 | +2 | ✅ 누적 (단기 +329) |
| PRs to others 80 | +2 | ✅ 20 PR (병렬 자동화 어려움, 사람 손 필요) |
| lifetime 5000 | +1~+2 | ⚠️ 시간 누적 |

**봉쇄 영역** (사용자 추천 제외):

- **commit date 위조**: 2017부터 GitHub이 push 시 server-side 검증 봉쇄
- **자동 외부 PR (bot)**: rate limit + bot-detected 정책. PR이 merge되지 않으면 효과 0
- **별 직접 누르기**: 다른 사람 결정

## 학습 / 함정

1. **공식 클론 1:1 정확성**: 한 줄 단순화하면 OVR ±5 어긋남. 보일러플레이트는 `references/scoring-replay-skeleton.js` 참조.
2. **신호 단위 Δ의 비선형성**: Lg + sigmoid 곡선이라 `+1` 신호의 가치는 baseline 위치에 따라 다름. counterfactual 시뮬은 반드시 rawStats 적용 후.
3. **OVR 자체의 노이즈**: Math.round + Lg 비선형성 + 88 cap 때문에 OVR 자체가 ±2 노이즈. ±2 변동 = 이벤트 아님.
4. **자력 가능성 정확 분류**: 메가 히트 repo 1개 패키징은 가능, but star 자체는 다른 사람 결정. 사용자에게 정확히 어디까지 자력인지 알려줘야 함.
5. **사용자 follow-up**: "위임할께" 답변에 대해 → 토큰 스코프 확장해도 외부 PR 봉쇄는 풀리지 않음. 다른 시그널로 redirect.
