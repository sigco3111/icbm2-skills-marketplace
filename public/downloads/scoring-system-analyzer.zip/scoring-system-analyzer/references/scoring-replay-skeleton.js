// scoring-replay-skeleton.js
// 새 public scoring/leaderboard 시스템을 reverse-engineer할 때 쓰는 보일러플레이트.
// 1) 시스템 source의 scoring 함수 1:1 복사
// 2) user real signals fetch
// 3) buildCard(s) 결과 == 공개 페이지 결과 검증
// 4) counterfactual mutate()로 각 신호별 Δ 측정

// === 사용자 작업 영역: 아래 함수만 시스템마다 채우기 ===

// 1) 시스템 scoring 함수 1:1 복사
function buildCard(s /* : Signals */) {
  // 시스템 source에서 그대로 옮긴다. 변수명, clamp, round, sigmoid, Lg 등 보존.
  // (예: gitfut engine.ts의 rawStats / center / zscore / spike / weightedOVR / legacyScore / buildCard)
  throw new Error("buildCard not yet ported from system source");
}

// 2) user real signals fetch
async function fetchSignals(userId) {
  // GraphQL/REST endpoint로 user의 real signal 모두 fetch.
  // 예 (gitfut): 5개 연도 contributionsCollection + repositories (top 100) + profile
  throw new Error("fetchSignals not yet wired");
}

// === 분석 함수 (대부분 시스템 공통) ===

async function main(userId) {
  const signals = await fetchSignals(userId);
  const card = buildCard(signals);

  console.log("=== 현재 카드 ===");
  console.log(JSON.stringify(card, null, 2));

  // 3) 검증: 페이지 결과와 시뮬 결과 비교
  // (사용자 수동 확인 또는 자동 fetch)

  // 4) counterfactual 시뮬
  console.log("\n=== Counterfactual 시뮬 (OVR 내림차순) ===");
  const results = [];
  for (const [label, changes] of Object.entries(COUNTERFACTUALS)) {
    const s = { ...signals, ...changes };
    const { overall } = buildCard(s);
    const delta = overall - card.overall;
    results.push({ label, overall, delta });
  }
  results.sort((a, b) => b.delta - a.delta);
  for (const r of results) {
    console.log(`  ${r.delta >= 0 ? "+" : ""}${r.delta} OVR | ${r.label} → ${r.overall}`);
  }
}

// === 카운터팩추얼 후보 (시스템마다 조정) ===
// gitfut 예시:
const COUNTERFACTUALS = {
  "followers 18 → 50":     { followers: 50 },
  "total_stars 25 → 2000": { total_stars_owned: 2000 },
  "max_repo_stars 2 → 200": { max_repo_stars: 200 },
  "active_years 2 → 5":    { active_years: 5 },
  "recent_commits 1171 → 1500": { recent_contributions: 1500 },
  "PRs to others 0 → 80":  { prs_to_others: 80 },
  "reviews 1 → 60":        { reviews: 60 },
  "languages 9 → 12":      { languages: 12 },
  "lifetime 1232 → 5000":  { total_contributions_lifetime: 5000 },
};

// === main 실행 ===
// main("sigco3111").catch(console.error);

module.exports = { buildCard, fetchSignals, main, COUNTERFACTUALS };
