# 2026-07-13 심야 통합 정비 실측 사례

## 결과 한 줄

**19 잡 점검 / 18 ok / 1 warning / 0 critical / 0 fixes. new_issues 1 (known FP), resolved 0. 07-11 대비 노이즈 floor 축소 (warning 4→1, errors 7→5). 결정 지연 4건 모두 4일+ 임계 유지.**

## 1단계 cron_error_monitor

- 19 잡 점검 → **18 ok / 1 warning / 0 critical / 0 alerts / 0 recovery**
- warning 1건 = `📰 Dev News → Wiki 동기화` (55.3h stale)
- 07-11 대비 변화:
  - warning 4 → 1 (−3, 주1회 잡 사이클 정상 진입)
  - critical 0 → 0 (유지, b26b0579a45f GitHub 401 일시 ok 회복 — last_failure 잔존)

## 2단계 cron_self_healer

- 20 잡 점검 → **14 healthy / 5 errors / 1 warning / 0 fixes** (AUTO-FIX 모드)
- 에러 5건 = 모두 output_error 패턴 매치 (FP 메타 트랩):
  - APIError 1: 5d0f14aef84c 🔄 일일 자기 개선 리뷰
  - FileNotFoundError 1: b1bca63a117a 📝 Tistory 자동 발행
  - TimeoutError 3: ed5f37705e68 📖 주간 학습 로그 + 81f1c81f8664 🛡️ 심야 통합 점검 + 0b0e9f44e10a 🍪 Tistory 세션 일일 체크
- warning 1건 = `notion-outage-watch-3h` (의도된 비활성)
- **활성 에러 0, 자동 fix 0**. ISS-068/069/077/082 Self-Healer FP 메타 트랩 시리즈 25회째 안정적 재현.

## 3단계 memory_error_tracker + 동기화

- 87개 에러 파일 (Other 49 / NotebookLM 26 / RSS Feeds 10 / Notion Idea (DEAD) 1 / YouTube 1)
- 07-11(56) 대비 **+31** (주말 누적 + Self-Healer FP 트랩 출력)
- **new_issues 1건 (Notion Idea (DEAD) 1) = known FP** — 06-14/06-22/06-27 tracker 디자인 false positive (단어 매칭 "notion_idea"). ISS-NNN 등록 안 함.
- resolved_issues 0. needs_memory_update=true (단발성 known FP라 무시).
- **MEMORY.md 헤더 07-10 → 07-13 동기화**
- **MEMORY.md "알려진 이슈" 섹션 결정 지연 day count 동기화** (아래 카운터 표 참고)
- **ad-hoc 검증 8/8 PASS** (mktemp -t hermes-verify-memory-2026-07-13-...)

## 결정 지연 누적 카운터 (07-13 갱신)

| ISS | 발견 | 결정 지연 | 직전 대비 |
|---|---|---|---|
| b26b0579a45f GitHub Trending 401 | 07-09 | **4일** | 2→3→4 (+1) — last_failure 잔존, critical 0으로 일시 회복 |
| ISS-086 sync-skills.sh missing | 06-27 | **17일** | 15→17 (+2) — 14일 임계 후 3일 추가, 비활성화/복구 결정 시급 |
| ISS-086-ext git-auto-sync 경로 | 07-04 | **10일** | 8→10 (+2) — 7일 임계 도달 |
| ISS-087 HTTP 429 Token Plan | 07-02 | **11일** | 9→11 (+2) — Token Plan 업그레이드/크레딧 결정 보류 |

07-07 noise-floor 정책 기준 (07-13 갱신):
- 1~3일: 일반 ⚠️
- 4~6일: ⚠️ 결정 지연 N일
- 7일 이상: 🔴 텔레그램/디스코드 푸시 검토 (ISS-086/086-ext/087 모두 7일+ 임계)

→ 4건 모두 4일+ 임계. ISS-086 17일은 14일 임계 후 3일 추가 경과.

## 4단계 Notion 기록

- DB: `33c76f2e-9097-8198-bd1b-c3ea3cfbbae8` (정비 리포트)
- **page_id: `39b76f2e-9097-8186-ae9c-f92a3605b913`**
- URL: https://app.notion.com/p/ICBM2-2026-07-13-03-30-KST-39b76f2e90978186ae9cf92a3605b913
- 상태: `일부 이슈` (07-10의 "⚠️ 문제 발견"에서 status 옵션 변경은 없음 — 보수적 사용 유지)
- 점검 항목 multi_select: 에러 모니터링 / 자가치유 / 메모리 점검 / 메모리 동기화 / 심야정비 / nightly-maintenance / Self-Healer / Error Monitor
- GET 재검증 통과 (id 일치, 7개 속성 모두 정상)
- 페이로드: `write_file /tmp/notion_payload_2026-07-13.json` + `curl -d @file` 패턴 (07-10 사례 "개선점 1" 재확인, 8.8KB JSON 함정 0건)

## 노이즈 floor trend (07-07 정책 → 07-13)

| 신호 | 07-09 | 07-10 | 07-11 | 07-13 | 판정 |
|---|---|---|---|---|---|
| Self-Healer FP errors | 10 | 8 | 7 | **5** | noise (FP 메타 트랩, 추세 ↓) |
| Warning (같은 주1회 잡) | 4 | 4 | 4 | **1** | noise (정상, 주기 회복) |
| new_issue | 0 | 0 | 1 (단발) | 1 (known FP) | noise floor |
| critical | 1 (GitHub 401) | 0 | 0 | **0** | noise (07-10 이후 안정) |
| fixes_applied | 0 | 0 | 0 | **0** | noise (불필요) |
| 결정 지연 누적 | 3건 (6/13/7일) | 4건 (1/14/7/8일) | 4건 (2/15/8/9일) | **4건 (4/17/10/11일)** | **진짜 알림 가치** |
| memory_error_tracker | n/a | 55 | 56 | **87** | +31 (주말 누적 + FP 트랩) |

→ 07-13의 진짜 이슈는 **결정 지연 누적 +2일 (ISS-086/086-ext/087 1~2일 추가 + GitHub 401 +1일)** + ISS-086 17일 임계 초과. 나머지는 모두 noise (warning 1 + Self-Healer FP 5는 정상 운영 패턴).

## 07-11 대비 노이즈 floor 축소

| 항목 | 07-11 | 07-13 | 변화 |
|---|---|---|---|
| warning | 4 | 1 | **−3** |
| Self-Healer errors | 7 | 5 | **−2** |
| critical | 0 | 0 | 유지 |
| fixes_applied | 0 | 0 | 유지 |

→ 07-11에서 4 warning이었던 주1회 잡(d7bd4309/ed5f3770/7995f1387/582ecc59)이 이번 회차에 정상화. **noise floor 정책이 안정적으로 작동 중** — 일시 4 warning은 단순한 스케줄 사이클 artifact였음.

## 사용자에게 권고되는 결정 (우선순위 순)

1. **🔴 ISS-086 sync-skills.sh 17일째 — 비활성화/복구 결정 시급** — 14일 임계 후 3일 추가. 명시적 결정이 다음 단계.
2. **🔴 ISS-087 Token Plan 결정 11일째** — 매일 13:00 실행 중. 업그레이드 또는 크레딧 구매.
3. **🔴 ISS-086-ext git-auto-sync 10일째 — 7일 임계 도달** — 복구/경로 갱신/비활성 3안 결정.
4. **🔴 b26b0579a45f GitHub Trending 401 4일째** — critical 0으로 일시 회복했지만 last_failure 잔존. 토큰 갱신 결정 권고.
5. 🟡 e330c7de50d1 Dev News → Wiki 55.3h stale — 단독 warning, next-cycle 회복 기대.

## 07-10 사례 "개선점" 회고 (07-13 실측에서 실현 여부)

### 개선점 1: Notion 페이로드 write_file + @file 패턴
✅ **07-13에서 재확인** — 8.8KB 페이로드 write_file + `curl -d @file`로 함정 0건. 단순 페이로드(≤10KB)는 이 패턴 우선 유지.

### 개선점 2: memory_error_tracker는 issues.md 자동 갱신 안 함
✅ **07-13에서도 그대로 적용** — `## 🆕 2026-07-13 발견` 섹션을 수동 추가. 워크플로 표준 유지.

### 개선점 3: 결정 지연 카운터를 issues.md 정규 섹션으로
🟡 **부분 실현** — 07-13에서는 MEMORY.md "알려진 이슈" 섹션에 day count를 동기화했음 (`ISS-086 sync-skills.sh 17일째` 형식). issues.md 정규 섹션화는 미구현 유지.

### 개선점 4: ISS-090 노이즈 floor 정식 ISS 등록
🟢 **07-13 결정 보류 유지** — 노이즈 floor는 정책(noise-floor-policy)으로 운영, 정식 ISS-NNN 등록 안 함. 07-13 추세 표가 추가 증거.

### 🆕 개선점 5 (07-13 신규): MEMORY.md "알려진 이슈" 섹션 day count 동기화

3단계 memory_error_tracker 동기화 시 다음 두 곳을 **동시에** 갱신:
1. `issues.md`의 `## 🆕 YYYY-MM-DD` 섹션 본문 (기존)
2. `MEMORY.md`의 "알려진 이슈" 섹션 결정 지연 일수 (07-13 신규)

**MEMORY.md 동기화 패턴**:
```markdown
## 알려진 이슈
- 전체 목록·day count·증거는 `~/.hermes/memory/issues.md`와 `~/.hermes/memory/reports/`가 SSOT.
- 활성 큰 줄기: ISS-086 sync-skills.sh N일째, ISS-086-ext git-auto-sync N일째,
                ISS-087 Token Plan N일째, ISS-088 b26b0579a45f GitHub Trending 401 N일째, ...
- YYYY-MM-DD nightly-maintenance: N/N cron 잡 점검 → ok / warning / critical. Self-Healer FP N건 / fixes 0 (모두 노이즈 floor).
```

`ad-hoc verification` 시 MEMORY.md의 day count 문자열이 issues.md와 일치하는지 검증하면 동기화 신뢰도 보장. 07-13 ad-hoc 검증 (8/8 PASS) 마지막 단계에 ISS-086/087/GitHub 401 day count 일치 확인 포함.

## 변경 이력

- 2026-07-13: 07-13 nightly-maintenance 실측 사례 추가 (page_id `39b76f2e-9097-8186-ae9c-f92a3605b913` 기반, 결정 지연 4일+ 임계 4건)