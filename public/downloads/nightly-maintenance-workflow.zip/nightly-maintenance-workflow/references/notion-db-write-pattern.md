# Notion 정비 리포트 DB 기록 패턴 (2026-07-05 학습)

4단계(Notion 기록) 실행 시 반복 사용되는 검증된 패턴. cron 모드 / 비대화형 모드 모두에서 안전.

## DB 스키마 (정비 리포트 DB, ID: `33c76f2e-9097-8198-bd1b-c3ea3cfbbae8`)

DB에 페이지 작성 **전 반드시** 스키마를 조회. 한글 속성명이라 직관과 다름:

| 잘못 추측 (실패) | 실제 속성명 | 타입 |
|---|---|---|
| `Name` | **`이름`** | title |
| `Date` | **`날짜`** | date |
| `Status` | **`상태`** | select |
| `Errors` | **`에러 수`** | number |
| `Fixes` | **`수리 항목 수`** | number |
| `Summary` | **`요약`** | rich_text |
| `Steps` | **`점검 항목`** | multi_select |

**실패 사례 (07-05):** `Name`으로 POST → `400 validation_error: Name is not a property that exists.` → DB 스키마 GET 후 재시도 성공.

**해결 코드 (재사용 가능):**
```bash
curl -s "https://api.notion.com/v1/databases/${DB_ID}" \
  -H "Authorization: Bearer ${NOTION_TOKEN}" \
  -H "Notion-Version: 2022-06-28" \
  | python3 -c "import json,sys; d=json.load(sys.stdin); [print(f'  {n}: {p.get(\"type\")}') for n,p in d.get('properties',{}).items()]"
```

## Token 처리 (shell 파싱 함정)

`NOTION_TOKEN=*** ~/.hermes/secrets/notion_token.txt | tr -d '[:space:]')` 같이 한 줄로 subshell + 파이프 + tr 조합하면 bash 파싱 오류. **반드시 분리:**

```bash
cat ~/.hermes/secrets/notion_token.txt | tr -d '[:space:]' > /tmp/notion_tok.txt
TOK=$(cat /tmp/notion_tok.txt)   # clean
curl -H "Authorization: Bearer $TOK" ...
```

또는 heredoc으로 토큰을 직접 페이로드에 박지 말 것. **페이로드는 별도 파일로 작성 후 `@file`로 주입:**

```bash
cat > /tmp/notion_payload.json <<'JSONEOF'
{ ... }
JSONEOF

curl -s -X POST "https://api.notion.com/v1/pages" \
  -H "Authorization: Bearer $TOK" \
  -H "Notion-Version: 2022-06-28" \
  -H "Content-Type: application/json" \
  -d @/tmp/notion_payload.json
```

## execute_code는 cron 모드에서 차단됨

cron 잡으로 실행 중일 때 `execute_code`는 거부됨:
> `BLOCKED: execute_code runs arbitrary local Python (including subprocess calls that bypass shell-string approval checks). Cron jobs run without a user present to approve it.`

→ **Notion 기록은 반드시 `terminal` + heredoc 패턴으로.**

## 성공 후 검증 (필수)

curl 응답 JSON에서 `object == "page"` + `id` 추출:

```bash
curl ... | python3 -c "
import json, sys
d = json.load(sys.stdin)
if d.get('object') == 'page':
    print('✅ page_id:', d.get('id'))
    print('   url:', d.get('url'))
else:
    print('❌', json.dumps(d, ensure_ascii=False))
"
```

## 일일 리포트 페이로드 템플릿 (재사용)

```json
{
  "parent": {"database_id": "33c76f2e-9097-8198-bd1b-c3ea3cfbbae8"},
  "properties": {
    "이름": {"title": [{"text": {"content": "ICBM2 심야 통합 정비 — YYYY-MM-DD HH:MM KST"}}]},
    "날짜": {"date": {"start": "YYYY-MM-DDTHH:MM:00+09:00"}},
    "상태": {"select": {"name": "일부 이슈|문제 발견|모두 정상"}},
    "에러 수": {"number": <n>},
    "수리 항목 수": {"number": <n>},
    "요약": {"rich_text": [{"type": "text", "text": {"content": "<한 줄 요약>"}}]},
    "점검 항목": {"multi_select": [{"name": "에러 모니터링"}, {"name": "자가치유"}, {"name": "메모리 동기화"}]}
  },
  "children": [ ... 본문 블록 ... ]
}
```

## 상태 값 (select 옵션)

관찰된 값: `일부 이슈`, `문제 발견`, `모두 정상`. 보수적으로는 `일부 이슈` 사용 (warning이 1건이라도 있으면).

## 변경 이력

- **2026-07-05**: 최초 작성 (page_id `39376f2e-9097-8114-a6be-d32bf98c0585` 성공 사례)
