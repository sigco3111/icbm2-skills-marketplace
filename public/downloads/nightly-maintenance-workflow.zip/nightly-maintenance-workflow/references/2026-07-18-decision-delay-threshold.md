# 2026-07-18 결정 지연 임계 도달 + 노이즈 floor 자기-안정화 (30회째)

07-18 03:30 KST 심야 정비에서 관찰된 두 가지 핵심 현상 — 결정 지연 ISS가 동시에 임계 도달한 첫 사례 + Self-Healer FP 트랩 시리즈 30회째 안정 재현.

## 1. 결정 지연 임계 도달 (첫 사례)

### 07-18 점검 결과

| ISS | 시작일 | 07-18 지연 | 임계 도달 |
|---|---|---|---|
| **ISS-086-ext** (5a376ec002c3 git-auto-sync 경로 결함) | 07-04 | **14일** | ✅ **D+14** |
| **ISS-091** (b26b0579a45f GitHub Trending github_token 부재) | 07-11 | **7일** | ✅ **D+7** |

### 보고서 톤 격상 규칙

기존 `recurring-noise-floor.md`의 결정 지연 표:

| 지연 일수 | 보고 수준 |
|---|---|
| 1~3일 | 일반 ⚠️ 문제 발견, 결정 권고 |
| 4~6일 | ⚠️ 결정 지연 N일 — 결정 시급 |
| **7일 이상** | 🔴 **결정 지연 7일+** — 텔레그램/디스코드 푸시 검토 |

07-18 케이스에서 **두 ISS가 동시에 임계 도달**한 것은 누적 알림 fatigue의 신호 — 사용자가 매일 권고를 받지만 결정을 못 내리고 있다는 뜻. 권고가 무시되는 패턴이 일정 기간 지속되면:

1. **decision escalation cycle**: 매일 권고 → 결정 없음 → 다음날 또 권고 → ... → 결정 거부/비활성화 결정으로 끝남 (07-16 ISS-086 해결 사례처럼)
2. **또는 자동화 자체가 해결**: 코드가 자가 복구되거나 우회로가 생기는 경우 (ISS-086 자체가 07-14 자가 해결된 사례)

07-18 보고서에서 사용한 실제 형식:
```
🔴 결정 지연 임계 도달 (07-18 03:30 KST)
1. ISS-086-ext git-auto-sync D+14 — 비활성화/복구/경로 갱신 결정
2. ISS-091 github_token D+7 — public_repo 토큰 발급 (5분 작업)
```

→ 단순 "⚠️ 결정 시급" 대신 **"🔴 임계 도달"** 표현으로 격상. Notion DB 상태 값도 `⚠️ 문제 발견` 대신 `🔴 결정 시급` 또는 `🟢 정상 + 결정 권고` 중 선택.

## 2. Noise floor 자기-안정화 검증 (30회째)

### 07-18 점검 — Self-Healer FP 트랩

07-18 03:30 KST에서 ISS-068/069/077/082 Self-Healer FP 메타 트랩 시리즈가 **30회째 안정 재현**:

| 잡 ID | 패턴 | 발생 |
|---|---|---|
| 5d0f14aef84c (일일 자기개선) | APIError | ✅ |
| b1bca63a117a (Tistory 자동발행) | FileNotFoundError | ✅ |
| ed5f37705e68 (주간 학습 로그) | TimeoutError | ✅ |
| 81f1c81f8664 (심야 점검, 자기참조) | TimeoutError | ✅ |
| 0b0e9f44e10a (Tistory 세션체크) | TimeoutError | ✅ |

→ **매일 정확히 같은 5건 + warning 4건 + 의도된 disabled 1건 = 매일 정확히 같은 10개 잡이 같은 패턴으로 FP 발생**. 30일 연속 동일 패턴이면 floor로 확립.

### floor가 깨지는 신호 (새 ISS 검토 트리거)

- 패턴 변동 (예: TimeoutError가 갑자기 FileNotFoundError로 바뀜)
- 새 잡 추가 (5건이 6건이 됨)
- 연속 2일 이상 빈도 jump (예: 5건 → 12건)
- 잡 ID가 변경됨 (예: 5d0f14aef84c가 새 ID로 바뀜)

→ 위 신호 중 하나라도 감지되면 신규 ISS 검토. 그 외는 floor로 흡수하고 보고서에 "FP 5건 (self-heal 진단 본문 leak, jobs.json ok)" 1줄로 처리.

## 3. 07-18 점검 전체 결과

```
1단계 cron_error_monitor: 19/19 → 15 ok / 4 warning / 0 critical / 0 recoverable
2단계 cron_self_healer:   20/20 → 13 healthy / 7 errors / 1 warning / 0 fixes
   └ errors 5건 = Self-Healer FP (ISS-068/069/077/082)
   └ errors 2건 = missing_secret + missing_file (ISS-091 github_token)
3단계 memory_error_tracker: 72h 58개 에러 파일
   └ new_issues: {} / resolved_issues: {} / needs_memory_update: false
   └ 신규 ISS-NNN 추가 없음
4단계 Notion 정비 리포트: ✅ page id 3a076f2e-9097-8195-afc7-da8609623b5b
```

→ **활성 critical 0, 신규 이슈 0, 실제 알림 가치 = ISS-086-ext + ISS-091 2건 (둘 다 D+14/D+7 임계 도달)**.

## 4. 페이지 ID 검증 정책 (07-18 강화)

07-18 정비에서 Notion POST 후 page id `3a076f2e-9097-8195-afc7-da8609623b5b` 생성. 보고서 작성 시 다음 항목 함께 기록:

| 검증 항목 | 형식 |
|---|---|
| page id | 32자 UUID (`xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx`) |
| URL | `https://app.notion.com/p/ICBM2-{date}-{id_head}` |
| response.created_time | ISO 8601 |
| status_code | 200 (POST 성공) |

→ 07-18 이전 세션들은 page id + URL만 기록. 07-18부터 created_time + status_code 추가. 이건 GET 재검증 시 일관성 확인용.

## 5. 메모리 동기화 절차 (07-18 검증됨)

매 정비 후 다음 두 파일을 동기화:

1. `~/.hermes/memory/issues.md` — `## 🆕 YYYY-MM-DD 발견` 섹션 append
2. `~/.hermes/memory/MEMORY.md` — 헤더 날짜 갱신 + "알려진 이슈" 결정 지연 일수/임계 도달 반영

07-18 검증:
- issues.md 1158 → 1184줄 (+26줄)
- MEMORY.md 헤더 07-16 → 07-18 + "알려진 이슈" 섹션 결정 지연 일수 갱신

**Patch 함정 (07-18 발견)**: `patch` 도구 사용 시 "sibling subagent already modified this file" 경고가 뜨면, **반드시 `read_file`로 먼저 읽고** 정확한 old_string/new_string으로 패치. 그렇지 않으면 patch 실패 → MEMORY.md가 부분적으로 갱신되어 SSOT 깨짐.

## 변경 이력

- **2026-07-18 03:31 KST**: 결정 지연 임계 도달 케이스 (D+14/D+7) + Noise floor 자기-안정화 30회째 + 페이지 ID 검증 정책 + 메모리 동기화 절차 + patch 함정 추가. page id `3a076f2e-9097-8195-afc7-da8609623b5b` 실측 기반.