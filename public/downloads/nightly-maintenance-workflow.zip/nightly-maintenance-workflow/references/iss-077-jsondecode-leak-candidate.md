# ISS-077 — JSONDecodeError Self-Healer FP (ISS-067 #3, 후보)

> **상태 (2026-06-23 03:30 KST):** 누적 2/3 임계 진행. 3회째 재발 시 정식 등록.
> **등록 안 됨** — SKILL.md "메모리 업데이트 규칙" 3회 반복 임계 미달.

## 패턴 정의

ISS-067 #2 (Tistory known-issues leak, 06-10)와 같은 meta-output trap이지만 **트리거 단어가 JSONDecodeError로 확장**:

- `tistory-publisher` SKILL.md의 진단 노트가 `**Pitfall:** ... json decode error ...` 같은 본문을 포함
- 매시간 cron output이 SKILL.md 진단 텍스트를 인용하면서 leak
- `cron_self_healer.py`의 `(?:json.*decode|expecting.*value|invalid.*json)` regex가 매칭
- `mask_self_healer_terms.py`는 v1.0.18까지 `JSONDecodeError` 단어를 마스킹하지 않음

## 누적 카운트 (06-23 03:30 KST 기준)

| 날짜 | 매칭 잡 | 매칭 라인 | 패턴 | 누계 | 임계 |
|------|--------|----------|------|------|------|
| 06-20 03:30 | b1bca63a117a Tistory | `**Symptom:** ... json decode error ...` | JSONDecodeError | 1회 | 1/3 |
| **06-23 03:30** | **7995f1387b79 주간뉴스레터** | `**Pitfall: tistory_publisher.py --category ...`** | JSONDecodeError | **2회** | **2/3 진행** |

## 판별 기준 (ISS-067 #3 패턴)

1. self-healer가 JSONDecodeError 감지
2. 매칭 라인이 Tistory / 주간뉴스레터 / 일일 리뷰의 **Pitfall** 또는 **Symptom/원인/해결** 마커 본문
3. 매칭 라인 grep 시 같은 라인에 `json.*decode` 단어 + 에러 마커 동시 존재 (정상 운영 가이드 본문)
4. jobs.json: ok, consecutive_failures: 0, last_ok_time 최근

→ **(a)+(b)+(c) 절차 FP 확정** — 자기 진단 본문 leak, 자동 fix 불필요

## 권장 패치 (06-23 22:00 일일 리뷰에서)

### 1. `mask_self_healer_terms.py`에 단어 추가

```python
_MASK_TABLE = [
    # 기존...
    (r'JSONDecodeError', 'json decode issue'),  # 신규
    (r'JSONDecode', 'json decode'),              # 신규
    (r'json decode error', 'json decode issue'), # 신규
]
```

### 2. `**Pitfall:**` 라인 마커 drop 로직 추가

ISS-067 #2의 `**Symptom:**` / `**원인:**` / `**해결:**` 마커와 동일하게 처리:

```python
DROP_MARKERS = [
    '**Symptom:**',
    '**원인:**',
    '**해결:**',
    '**Pitfall:**',  # 신규
]
```

### 3. `cron_self_healer.py`의 `(?:json.*decode|expecting.*value|invalid.*json)` regex에 라인 drop

```python
# Before: 라인 전체 매칭 → FP
if re.search(r'(?:json.*decode|expecting.*value|invalid.*json)', line):
    errors.append(...)

# After: informational 라인 제외
if any(marker in line for marker in DROP_MARKERS):
    continue
if re.search(r'(?:json.*decode|expecting.*value|invalid.*json)', line):
    errors.append(...)
```

### 4. ISS-077 등록 결정

3회째 재발 시 (06-23 22:00 또는 06-24 03:30) 다음 작업:
1. `references/iss-077-jsondecode-leak.md` 정식 등록
2. `memory/issues.md`에 ISS-077 추가
3. `MEMORY.md` "알려진 이슈" 섹션에 추가
4. `feedback_collector.py add --category self_healer_fp --severity medium`

## 핵심 통찰

- ISS-067 #2 (`**Symptom:**`/`**원인:**`/`**해결:**`) 와 동일 구조의 **JSONDecodeError 버전**
- "FP 비용 0 흡수"가 현실적 목표 — 자기 진단 본문을 인용하는 한, mask 도구가 적용되기 전 본문이 다음 cycle의 FP source
- 패치 적용 후에도 **1일 lag 잔존** 예상 (v1.0.18 → v1.0.20 → 06-23 N일차에 안정화)
- ISS-077 등록은 **3회 반복 임계 도달 후** (현 2/3)

## 검증 방법

```bash
# 현재 매칭 잡의 output에서 JSONDecodeError 라인 grep
python3 << 'PY'
import re
from pathlib import Path
from datetime import datetime, timedelta
root = Path('/Users/hjshin/.hermes/cron/output')
cutoff = datetime.now() - timedelta(hours=72)
n = 0
for p in root.rglob('*.md'):
    if datetime.fromtimestamp(p.stat().st_mtime) < cutoff: continue
    try: t = p.read_text(encoding='utf-8', errors='ignore')
    except: continue
    for i, line in enumerate(t.splitlines(), 1):
        if re.search(r'(?:json.*decode|expecting.*value|invalid.*json)', line, re.I):
            if re.search(r'(error|fail|exception|traceback|⛔|❌|🚨)', line, re.I):
                n += 1
                print(f'{p.parent.name}/{p.name}:L{i}: {line.strip()[:160]}')
print(f'Total: {n}건')
PY
```

0건이면 FP-only, 1건이라도 실제 Traceback/ConnectionError 동시 존재 시 진짜 이슈.
