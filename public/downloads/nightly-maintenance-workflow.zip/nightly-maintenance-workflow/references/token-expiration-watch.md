# Token Expiration Watch — 외부 API 토큰 만료 추적 (ISS-064 후속)

**Context**: ISS-064 (2026-06-07) — Notion integration token 401. weekly report 6개 payload 미기록, 자동 복구 불가.

**원인**: `api-key-manager` 스킬이 마지막 검증 일자 추적 + 만료 사전 경고를 안 함. `automation-healthcheck`도 일부 토큰만 검사.

**후속 작업** (api-key-manager + automation-healthcheck 패치 시 참고):

## 추적 대상 토큰 목록

| 토큰 파일 | 서비스 | 예상 만료 | 검증 |
|----------|--------|----------|------|
| `~/.hermes/secrets/notion_token.txt` | Notion | 90일 | 401 unauthorized (ISS-064) |
| `~/.hermes/secrets/telegram_bot_token.txt` | Telegram Bot | 무기한 | getMe |
| `~/.hermes/secrets/youtube_token.pickle` | YouTube | 1시간 (자동 refresh) | `creds.refresh(Request())` |
| `~/.hermes/secrets/github_*` | GitHub | PAT 설정 의존 | curl /user/repos |
| `~/.hermes/secrets/vercel_token.txt` | Vercel | 무기한 | vercel whoami |
| `~/.hermes/secrets/nvidia_*.env` | NVIDIA NIM | 무기한 | API 호출 |
| `~/.hermes/secrets/minimax.env` | MiniMax | 잔여량 기반 | `coding_plan/remains` |
| `~/.hermes/secrets/flux_server.json` | Flux | 무기한 | health check |

## ISS-064 사례에서 배운 것

1. **토큰 파일 syntax 유효 ≠ 토큰 유효**: 파일 존재 + prefix/norm만 체크하면 actual API call 없이 만료를 놓침
2. **monitor의 사각지대**: cron_error_monitor는 jobs.json의 last_status만 보고, 외부 API 401을 직접 감지 안 함
3. **payload 보존**: Notion weekly report는 status 파일에 6개 payload 저장 → 토큰 재발급 시 자동 재시도 가능. 다른 외부 API 의존 잡도 같은 패턴 권장
4. **fail-storm 방지**: 같은 ISS 알림은 1일 1회만. cron이 매번 깨지면 spam
5. **일요일심층 시작 전 precheck**: weekly 잡은 일요일 15:30쯤 집중 실행 → 15:30 KST 1회 health check로 토큰 상태 확인

## 권장 패치 (api-key-manager / automation-healthcheck)

```python
# api-key-manager에 추가
def check_token_last_verified(token_name: str) -> Optional[datetime]:
    """토큰 마지막 검증 일자 추적. 90일 가까이 됐으면 경고."""
    state_file = Path(f"~/.hermes/data/token_health/{token_name}.json")
    if not state_file.exists():
        return None
    return json.loads(state_file.read_text()).get("last_verified")
```

```bash
# automation-healthcheck에 추가
python3 ~/.hermes/scripts/check_external_tokens.py --warn-days 7
# → 모든 외부 API 토큰의 마지막 검증 일자 + 만료 임박 알림
```
