# 2026-07-09 Noise Floor + Discriminator Matrix (verified)

매 03:30 cron에서 재현되는 노이즈 floor의 정확한 신호/노이즈 구분 기준.

## TL;DR — 진짜 에스컬레이션 vs 노이즈

| 신호 | 임계치 | 07-09 실측 | 판정 |
|---|---|---|---|
| `critical` 에러 (cron_error_monitor) | ≥ 1 | **1건 (b26b0579a45f GitHub 401)** | 🔴 에스컬레이션 |
| `fixes_applied` (cron_self_healer) | > 0 | 0 | (fix 불필요면 OK) |
| 결정 지연 (ISS-NNN 일수) | ≥ 5일 | ISS-086 13일째, ISS-087 7일째 | 🔴 모두 지연 |
| `new_issues` (memory_error_tracker) | ≥ 1 AND 잡 본문 grep 매칭 | 0건 (new_issues={}) | ✅ 노이즈 floor |
| Self-Healer `output_error` FP | 7~10건/일 | 10건 | ✅ floor |
| Self-Healer `warning` (notion-outage-watch-3h 등) | 항상 4건 (같은 주1회 잡) | 4건 | ✅ floor |

→ **판별 규칙**: critical ≥ 1 (혹은 fixes_applied > 0, 결정 지연 ≥ 5일) → 에스컬레이션. 그 외 → 노이즈 floor로 흡수.

## 판별 매트릭스 (FP vs 실제 이슈) — 5축 (07-16 갱신)

| jobs.json 상태 | 자기진단 leak | Traceback/APIError | (d) 진단 트랜스크립트 | **(e) 출력 길이 한계** | 판별 |
|---|---|---|---|---|---|
| ok | Yes | No | No | - | ✅ FP (자기 진단 leak) |
| ok | No | No | Yes | - | ⚠️ **실제 이슈 가능** — (d) 진단 내용으로 결정 |
| ok | Yes | No | Yes (ImportError + cookie expired) | - | 🔴 **실제 이슈** (06-26 케이스) |
| ok | No | No | No | **empty_output + "Response truncated"** | 🔴 **LLM 응답 손실** (07-16 ISS-092) |
| ok | No | No | No | empty_output 단발 | ⚠️ 3일 연속 시 ISS 검토 |
| failed | - | Yes | - | - | ❌ 실제 실패 (수정 대상) |

**핵심 교훈 1**: 단순 (a)+(b)+(c) FP 판정 절차로 `ImportError/ModuleNotFoundError`를 FP 확정하지 말 것. **매칭 라인이 진단 트랜스크립트 (cookie expired, redirect to login, HTTP 401/429/500, Token Plan limit 등)를 동반하면 실제 이슈**.

**핵심 교훈 2 (07-16 추가)**: Self-Healer의 `output_error` 패턴 매치 (TimeoutError 4종)에는 안 잡히고 `last_status_error`로만 발현되는 **`Response truncated due to output length limit` + `empty_output` 패턴**은 5번째 축. jobs.json `last_status="error"` + `last_error`에 "Response truncated" 가 포함된 잡은 실제 이슈. ISS-092가 이 케이스의 첫 정식 추적 사례.

## 07-09 실측 결과 — 적용 사례

**cron_error_monitor 1단계**:
- 19 잡 → 14 OK / 4 warning / **1 critical (b26b0579a45f)** / 0 recoverable
- critical 1건 = GitHub Trending 연속 3회 빈 출력 + RuntimeError HTTP 401

**cron_self_healer 2단계**:
- 20 잡 → 10 healthy / 11 errors / 1 warning / 0 fixes
- 판별 매트릭스 적용: 10건 FP (자기진단 leak) + **1건 실제 이슈 (GitHub 401)**

**memory_error_tracker 3단계**:
- new_issues: {} / resolved_issues: {Notion Idea (DEAD): 1}
- needs_memory_update: true (resolved 1건은 MEMORY/issues 동기화)

## Self-Healer FP 트랩 정규 패턴 (20+ 회 안정 재현)

타임스탬프 날 무관하게 매 03:30에 등장하는 FP 잡들 — 절대 신규 이슈 아님:

| 잡 ID | 잡 이름 | 패턴 | 판정 |
|---|---|---|---|
| 5d0f14aef84c | 일일 자기개선 | FileNotFoundError | FP (자기 진단 본문 leak) |
| b1bca63a117a | Tistory 자동발행 | TimeoutError | FP |
| d7bd4309bbf0 | 일요일 심층점검 | TimeoutError | FP |
| ed5f37705e68 | 주간 학습 로그 | TimeoutError | FP |
| 7995f1387b79 | 주간 뉴스레터 | TimeoutError | FP |
| 81f1c81f8664 | **심야 점검 (자기참조)** | TimeoutError | FP (본 점검 잡이 자기 패턴에 매칭) |
| 0b0e9f44e10a | Tistory 세션체크 | TimeoutError | FP |
| 7c2b9a9be162 | skills-marketplace | FileNotFoundError | FP (잡 이름 leak, 진짜 = ISS-086) |

→ **ISS-068/069/077/082 Self-Healer FP 메타 트랩 시리즈**로 흡수. 개별 등록 불필요.

## 노이즈 floor 압축 가이드

Notion 정비 리포트 작성 시 — 노이즈 floor 항목을 매번 길게 나열 ❌:

**❌ 이렇게 쓰지 말 것**:
```
- TimeoutError 6건: Tistory 자동발행, 일요일 심층점검, 주간 학습 로그, 
  주간 뉴스레터, 심야 점검, Tistory 세션체크 (모두 FP)
- FileNotFoundError 2건: 일일리뷰, skills-marketplace
...
```

**✅ 이렇게 압축**:
```
판별 매트릭스 적용: TimeoutError ×6 + FileNotFoundError ×2 = FP 10건 
(self-heal 진단 본문 leak, jobs.json ok). 활성 이슈 0 (이번 점검 제외).
```

## 결정 권장 우선순위 형식

Notion 보고 → MEMORY/issues 갱신 시 항상 다음 형식으로 압축:

```
🚨 결정 권고 (우선순위순)
1. [b26b0579a45f] GitHub Trending API 키 갱신 — HTTP 401 3연패 (즉시)
2. [ISS-087] Token Plan 결정 (7일 지연)
3. [ISS-086] sync-skills.sh 복구/비활성화 (13일 지연)
4. [ISS-086-ext] git-auto-sync 결정 (6일 지연)
```

## memory/issues.md append 형식

매 03:30 정비 후 `## 🆕 YYYY-MM-DD 발견` 섹션을 tail에 append. 형식:

```
## 🆕 YYYY-MM-DD 발견 (심야 통합 정비 03:30 KST)

**1단계 cron_error_monitor**: N/N 점검 → ok N / warning N / critical N.
- Warning(주1회 의도): 잡명 (N.Nh stale) × N건
- 🔴 Critical: 잡ID (잡이름) — 에러 타입 (consecutive_failures N→M)
**2단계 cron_self_healer**: N 잡 점검 → healthy N / errors N / fixes_applied N (AUTO-FIX 모드).
- 판별 매트릭스 적용 결과: FP N건 + 실제 이슈 N건 (있다면 잡ID + 에러)
**3단계 memory_error_tracker**: new_issues {} / resolved_issues {...} / total_errors N / needs_memory_update true|false.
- 카테고리 (전부 잡 제목 leak FP로 추정)
**🔴 신규 에스컬레이션 (있다면)**:
- 잡ID 잡이름 — 에러 메시지. 원인 추정. user 결정 필요.
**누적 안정화**:
- ISS-NNN ... ✅ 해결됨 유지 / 진행중 유지
**07-09 사용자 결정 권장 (우선순위 순)**:
1. ...
**4단계 (Notion 기록)** ✅: 정비 리포트 DB 기록 완료. page id: `...` ...
```

*마지막 업데이트: 2026-07-09 03:30*
