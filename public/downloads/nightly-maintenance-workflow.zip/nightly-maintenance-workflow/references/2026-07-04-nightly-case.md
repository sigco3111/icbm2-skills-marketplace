# 2026-07-04 03:30 KST 심야 통합 정비 실측 케이스

## 상황

- **실행 시각**: 2026-07-04 03:30 KST (Friday)
- **전체 크론 잡**: 18개 점검 (4단계 파이프라인)
- **결과**: ok 14 / warning 4 / critical 0 / recoverable 0
- **자가치유**: 9 errors (모두 FP) / 1 warning / 0 fixes
- **tracker**: 53 에러 파일 (Other 44, NotebookLM 3, RSS 3, YouTube 2, Notion Idea 1) — 신규 ISS 0건
- **Notion 4단계**: HTTP 200, page id `39276f2e-9097-8119-ab78-e313263192fd` (URL: https://app.notion.com/p/2026-07-04-03-30-KST-39276f2e90978119ab78e313263192fd)

## 경고 4건 (모두 오래 미실행, 주간 스케줄 skip 정상)

| 잡 | 미실행 | 판별 |
|---|---|---|
| d7bd4309bbf0 일요일심층 | 125.3h | 주 1회 (다음 07-05) ✅ |
| ed5f37705e68 주간학습로그 | 127.3h | 주 1회 (다음 07-05) ✅ |
| 7995f1387b79 주간기술요약 | 59.0h | 주간 ✅ |
| 582ecc59aaee Benchmark | 136.9h | 주간 ✅ |

## 자가치유 9 errors 분포

| 잡 | 패턴 | 판별 |
|---|---|---|
| 5d0f14aef84c 일일리뷰 | FileNotFoundError | ✅ FP (자기 진단 leak) |
| b1bca63a117a Tistory | TimeoutError | ✅ FP (자기 진단 leak) |
| d7bd4309bbf0 일요일심층 | last_status_error + TimeoutError | ✅ FP (06-29 jobs.json 잔재) |
| ed5f37705e68 주간학습로그 | last_status_error + TimeoutError | ✅ FP (06-29 jobs.json 잔재) |
| 7995f1387b79 주간기술요약 | TimeoutError | ✅ FP (자기 진단 leak) |
| 81f1c81f8664 심야통합 | TimeoutError | ✅ FP (자기 진단 leak) |
| b21d94a14860 쿠키체크 | JSONDecodeError | ✅ FP (자기 진단 leak) |
| 7c2b9a9be162 skills-marketplace | FileNotFoundError + missing_file | 🔴 **ISS-086 진행중** (sync-skills.sh 부재) |
| 582ecc59aaee Benchmark | last_status_error + TimeoutError | ✅ FP (06-29 jobs.json 잔재) |

## 🆕 ISS-086 + ISS-087 진행 상태 갱신 (07-04)

### ISS-086 (skills-marketplace-sync sync-skills.sh missing) — 8일째

- 시작: 06-27, 07-02 (6일째) → **07-04 (8일째)**
- 결정 deadline: **07-04 22:00 KST** (3번째 만료)
- 매번 silent 응답 → jobs.json status=ok 처리되나 실제 sync 0건
- M4 마이그레이션(06-22) 후 `Desktop/project/work/icbm2-skills-marketplace/scripts/sync-skills.sh` 미복구
- **조치 옵션 (3회째 만료 임박)**:
  1. sync-skills.sh 복구 (원본 재작성)
  2. 잡 비활성화 (`enabled=False`)
  3. 둘 다 미루기 (계속 누적)

### ISS-087 (b02a45f4d14e HTTP 429 Token Plan limit) — 4번째 만료 임박

- 시작: 07-01 13:01 (1회 관찰이지만 critical + 사용자 액션 필수)
- 다음 실행: **07-04 13:00 KST** (4번째 만료 임박)
- 해결 방법: MiniMax Token Plan 업그레이드 또는 크레딧 구매
- 자동 fix 불가능, 사용자 결정 필수

## 🆕 이번 세션에서 새로 등장한 함정 2건

### 1. Notion DB 스키마를 `gateway-stdout.log`에서 reverse-engineering

**문제:** `notion_db_ids.json`이 더 이상 존재하지 않음 (6/26 마이그레이션 시 손실 추정). 4단계에서 DB 스키마를 어떻게 알아낼 것인가?

**해결:** `~/.hermes/logs/gateway-stdout.log`에 과거 4단계 POST의 curl 명령이 **Bearer 토큰이 마스킹된 채** 남아있음 → `notion_db_ids.json` 없이도 DB property 구조 (이름/날짜/상태/에러 수/요약) 복원 가능.

```bash
# 1) Bearer가 마스킹된 과거 POST 패턴 찾기
grep -E "POST.*databases/33c76f2e-9097-8198-bd1b-c3ea3cfbbae8" \
  ~/.hermes/logs/gateway-stdout.log | tail -5

# 2) GET 응답에서 프로퍼티 목록 확인
grep -A 1 "GET.*databases/33c76f2e" ~/.hermes/logs/gateway-stdout.log | tail -20
```

**핵심 통찰:** gateway-stdout.log는 **단일 정보 소스** — DB ID, property 이름, 상태 select 옵션, 점검 항목 multi_select 옵션 모두 역추적 가능. 노션이 `notion_db_ids.json`을 더 이상 제공하지 않더라도 4단계 파이프라인이 동작 가능.

### 2. 🆕 Verification 스크립트에서 payload 재실행 회피 — `exec()` 트릭

**문제:** verification gate가 14개 체크로 POST 결과(URL, page_id, status=200)를 검증하려고 함. 그런데 ad-hoc verification 단계에서 **POST를 다시 실행하면 중복 페이지**가 Maint DB에 생성됨 (07-04 실측 위험).

**해결:** verifier가 POST를 재실행하지 않고, **payload-construction 부분만 exec()**해서 구조 검증:

```python
script_text = Path(SCRIPT).read_text()
# POST 직전 라인에서 잘라내기
cut = script_text.find("data = json.dumps(payload")
ns = {}
exec(script_text[:cut], ns)  # payload/TITLE/DATE 등 namespace에 로드
payload = ns["payload"]
title = ns["TITLE"]
date = ns["DATE"]

# 구조 검증
assert payload["parent"]["database_id"] == "33c76f2e-9097-8198-bd1b-c3ea3cfbbae8"
assert "이름" in payload["properties"]  # 등등 14개 체크
```

**왜 효과적인가:**
- POST 호출 (`urllib.request.urlopen`) 직전까지의 모든 변수(`payload`, `TITLE`, `DATE`, `DB_ID`, `NOTION_TOKEN`)가 namespace에 로드됨
- payload의 `parent.database_id` / `properties` / `children` 구조가 실제 전송될 형태로 검증됨
- **HTTP 호출 0건** — 중복 페이지 위험 없음
- 토큰은 `Path.read_text().strip()`으로 런타임 로드되므로 verifier 안에 평문 없음

**체크리스트 (07-04 실측, 14/14 PASS):**
1. MEMORY.md header date = 2026-07-04
2. ISS-086 day count = 8일째 (정규식 `ISS-086.*?(\d+)일째`)
3. ISS-086 7/4 22:00 deadline 언급
4. ISS-087 still referenced
5. 07-04 03:30 nightly summary line
6. `post_notion_report_YYYYMMDD.py` compiles
7. DATE = 2026-07-04
8. TITLE contains "03:30" + "KST"
9. parent.database_id = `33c76f2e-9097-8198-bd1b-c3ea3cfbbae8`
10. 5개 properties 모두 (이름/날짜/상태/에러 수/요약)
11. 상태 = "⚠️ 문제 발견"
12. 에러 수 is integer ≥ 0
13. payload JSON-serializable
14. 4단계 heading_2 sections (1·2·3·4단계) 모두 children에 존재

## 누적 추적 (07-04 03:30 KST)

- **ISS-086**: 8일째 진행중 (결정 미루면 9일째 07-05로 진입)
- **ISS-087**: 4번째 만료 임박 (07-04 13:00 다음 실행)
- **ISS-084/085**: Cron Timeout 12건 stable (raw grep 0건 가능성, 07-04 22:00 일일 리뷰에서 재검증 권장)
- **Self-Healer FP**: 9건 모두 (a)+(b)+(c) 절차로 FP 확정 ✅
- **tracker new_issues**: 0건 (신규 ISS 없음)
- **MEMORY.md 크기**: 3,574자 (4,000자 한도 이내, 90% 임계 안전)

## 07-04 22:00 일일 리뷰 권장 작업

1. **ISS-086 결정 (3번째 만료)** — sync-skills.sh 복구 vs 비활성화
2. **ISS-087 b02a45f4d14e** 13:00 실행 후 HTTP 429 재발 모니터링 (4번째 만료)
3. **ISS-084/085 Cron Timeout 12건 재검증** — raw grep 0건 가능성 확인
4. **MEMORY.md 06-30 stable → 07-04 transition 정리** — 4일간 누적이미 안정, 압축/재구성 검토 (`memory-hygiene` 스킬)
5. **`notion_db_ids.json` 복구** — gateway-stdout.log에서 5개 DB ID (일기/성과/iOS/AI/Maint) + property 구조 역추출 → `~/.hermes/memory/notion_db_ids.json` 재생성
