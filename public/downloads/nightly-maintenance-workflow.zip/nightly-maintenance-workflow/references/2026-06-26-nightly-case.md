# 2026-06-26 03:30 KST 심야 정비 실측 케이스

> **상태:** ✅ 정상 운영 (자동화) + 🔴 실제 이슈 1건 (티스토리 쿠키 만료)
> **실행 시간:** 7.3초 (자가치유) + 31초 (tracker) + 5초 (Notion POST)

## 1단계: 에러 모니터링 결과

```json
{
  "total": 18, "ok": 4, "warning": 14, "critical": 0, "recoverable": 0
}
```

- **warning 14건 모두 FP** (다음 스케줄 대기 중)
- `hermes cron list` 한 번 실행으로 14건 자가 판별 (cron-stale-triage 자동 트리거 미발동)
- 임계 ≥ 5 자동 트리거 자체보다 자가 판별 휴리스틱이 견조하다는 실측 증거

## 2단계: 자가치유 결과

```json
{
  "total_jobs": 19, "healthy_jobs": 12,
  "total_errors": 6, "total_warnings": 1,
  "fixes_applied": 0, "elapsed_seconds": 7.3
}
```

### 6 errors 판별 결과

| 잡 | 패턴 | (a)+(b)+(c) | (d) 진단 트랜스크립트 | 최종 판별 |
|---|------|------------|-------------------|---------|
| 5d0f14aef84c | FileNotFoundError | FP (ISS-068 자기진단 leak) | None | ✅ FP |
| b1bca63a117a | TimeoutError | FP (Picsum 운영 텍스트) | None | ✅ FP |
| 7995f1387b79 | JSONDecodeError | FP (Tistory Pitfall leak, ISS-067 #3) | None | ✅ FP (ISS-077 임계 3/3) |
| 81f1c81f8664 | TimeoutError | FP (ISS-069 자기진단 leak) | None | ✅ FP |
| b21d94a14860 | ImportError | jobs ok, consec_fail 0 | **cookie expired + /manage 리다이렉트** | 🔴 **실제 이슈** |
| 7c2b9a9be162 | missing_file | jobs ok, 마지막 실행 성공 | 경로 미스매치 (`/Users/hjshin/` vs `/Users/mac/`) | ⚠️ 모니터링 FP (홈디렉터리 차이) |

### 핵심 발견: (d) 절차의 필요성

(a)+(b)+(c) 절차만 적용 시 `b21d94a14860`는 FP로 오판 가능했음. **ImportError/ModuleNotFoundError + 의미있는 진단 트랜스크립트 동반 시 실제 이슈**일 수 있음:

```bash
# 매칭 라인 + 진단 트랜스크립트
"ModuleNotFoundError: No module named 'requests'"
"/manage → 로그인 페이지로 리다이렉트"
"세션 만료 확실"
"권장 후속 조치: 쿠키 갱신, pip install"
```

→ (d) 절차 추가: 매칭 라인 grep 결과에 의미있는 진단 트랜스크립트 존재 여부 확인

## 3단계: tracker 결과

```json
{
  "new_issues": {"RSS Feeds": 19, "Notion Idea (DEAD)": 2},
  "resolved_issues": {},
  "total_errors": 153
}
```

### grep 라인 동시 매칭 검증 결과 (실제 에러 vs FP)

| 카테고리 | tracker 카운트 | 실제 grep 매칭 | 판별 |
|---------|--------------|--------------|------|
| RSS Feeds | 19 | 2 (자기 진단 leak) | ✅ FP-only |
| Notion Idea (DEAD) | 2 | 3 (자기 진단 leak) | ✅ FP-only |
| Sandbox | 71 | 263 (모두 FP) | ✅ FP-only (ISS-076 후보) |
| NotebookLM | 39 | 4 | ✅ FP-only |
| YouTube | 5 | 7 | ✅ FP-only |
| Cron Timeout | 10 | 23 | ✅ FP-only (ISS-069 계열) |
| Other | 7 | 512 | ✅ FP-only |

→ **모든 new_issues false positive**, ISS-NNN 등록 0건 유지

### ISS 누적 추적 (06-26 시점)

- **ISS-077 신규 등록 임계 도달** — JSONDecodeError leak 3/3 (06-20, 06-23, 06-26). 06-26 22:00 일일 리뷰에서 정식 등록 권장
- **ISS-076 누적 진행중** — tracker 디자인 함정 (Sandbox 71 / RSS Feeds 2 / Notion Idea 3 모두 FP). 3/3 임계 추적 중

## 4단계: Notion 기록

- 토큰 HEALTH 200 OK (name: ICBM2호)
- DB 스키마 점검 항목 47개 / 상태 16개 옵션 확인
- 상태: `⚠️ 문제 발견` (티스토리 쿠키 만료 1건)
- page id: `38b76f2e-9097-8179-936b-eb2334444ac8` 생성 성공

## 🔴 발견된 실제 이슈

### 티스토리 쿠키 만료 (b21d94a14860)

- **증상:** `/manage` 접근 시 로그인 페이지로 리다이렉트
- **원인:** 5개 쿠키 (REACTION_GUEST, __T_, __T_SECURE, TSSESSION, _T_ANO) 만료
- **추가:** `python3 tistory_publisher.py --check-session` 실행 시 `ModuleNotFoundError: No module named 'requests'` (cron 환경 venv 의존성 누락)
- **조치:**
  1. Chrome에서 sigco.tistory.com 로그인 → 쿠키 5개 갱신
  2. cron 환경의 venv 식별 후 `pip install requests` 적용
- **영향:** Tistory 자동 발행 (b1bca63a117a) 자체는 정상 운영 (마지막 06-25 20:01 ok). 쿠키 만료 체크만 실패 중

## 핵심 교훈

1. **(a)+(b)+(c) 절차만으로 FP 확정 위험** — ImportError + 진단 트랜스크립트 케이스는 (d) 절차 필요
2. **cron-stale-triage 임계 자동 트리거는 안전망이지 필수 아님** — warning 14건에서도 자가 판별 안전
3. **tracker 디자인 함정 누적 가속** — ISS-076 (classify_error 라인 단위 패치) + ISS-077 (JSONDecodeError leak) 동시 진행
4. **ISS-064 Notion 토큰 자동 회복 6회째** — 환경 이슈 패턴 지속, 만료 메커니즘 자체 미해결
5. **Notion API POST 안정화** — `Path.read_text()` 런타임 조합으로 토큰 평문 회피, write_file lint/마스킹 안전

## 06-26 22:00 일일 리뷰 권장 작업

1. ISS-077 정식 등록 (3/3 임계 도달)
2. 티스토리 쿠키 갱신 확인
3. b21d94a14860 cron venv 의존성 복구
4. (d) 절차 SKILL.md 반영 (이미 본 세션에서 패치 완료)
5. ISS-076 tracker classify_error 라인 단위 패치
