# 2026-07-15 심야 통합 정비 실측 사례

## 결과 한 줄
**19 잡 점검 / 14 ok / 4 warning / 0 critical / 1 recoverable. Self-Healer 13 healthy / 7 errors (FP 5 + 실제 hang 1 + missing_secret 2) / 0 fixes. tracker 82개 (FP 2 = 잡 이름 + 본문 leak). 결정 지연 2건 (ISS-086-ext 12일째 / ISS-091 5일째).**

## 1단계 cron_error_monitor

- 19 잡 → **14 ok / 4 warning / 0 critical / 1 recoverable**
- warning 4건 = 모두 주간 잡 (d7bd4309bbf0 60.0h / ed5f37705e68 55.5h / 7995f1387b79 59.4h / 582ecc59aaee 65.4h) 스케줄 노이즈
- recoverable 1건 = `7c2b9a9be162 skills-marketplace-sync` (`error_type: timeout, consecutive_failures: 1`, fresh output 2026-07-15_03-29-37)
- 07-13 대비 변화:
  - warning 1 → 4 (+3, 주간 잡 사이클 artifact — 07-14의 5 → 1이 일시적이었음)
  - recoverable 0 → 1 (skills-marketplace-sync 단발성 hang)
  - critical 0 → 0 (유지)

## 2단계 cron_self_healer (4축 판별 매트릭스 적용)

- 20 잡 → **13 healthy / 7 errors / 1 warning / 0 fixes** (AUTO-FIX, 1.4s)
- errors 7건 분류 (a)+(b)+(c)+(d) 절차 + 신규 **(e) jobs.json `consecutive_failures` 확인**:
  - **`missing_secret` 2건** (`~/.hermes/secrets/github_token.txt` 부재): (b) jobs.json `last_status=ok`, (c) 실제 grep 매칭, → **ISS-091 진행중 (5일째) — ✅ 실제 이슈**
  - **`output_error FileNotFoundError` 2건** (5d0f14aef84c + b1bca63a117a): (a) self-heal 리포트 매칭, (b) jobs.json ok, (c) grep 결과 = 자기 진단 본문 leak (`**FP 4건 (어제와 동일)**` 같은 라인이 trigger 단어 인용), → **Self-Healer FP 메타 트랩 (ISS-062/068)**
  - **`output_error TimeoutError` 3건**:
    - ed5f37705e68 + 0b0e9f44e10a: (c) grep = `urllib.request.urlopen(req, timeout=20)` 같은 코드 예시 (Python `timeout` 키워드) + 잡 PASS 메시지, → **FP**
    - 7c2b9a9be162: (b) jobs.json `last_status=error` **but `consecutive_failures=0`** (첫 에러 후 즉시) → **단발성 hang**
  - **`last_status_error` 1건** (7c2b9a9be162): (e) jobs.json 잔재 (consecutive_failures=0) → 위 hang의 mirror
- warning 1건 = `notion-outage-watch-3h` 의도된 disabled

### 🆕 신규 판별 절차 (e): `consecutive_failures` 확인
**ISS-086 ✅ 해결됨 재검증의 결정적 신호**: jobs.json에서 `consecutive_failures` 필드를 직접 확인하면 "오늘 처음 에러 (일시 hang)인지, 연속 N회 실패 (진짜 회귀)인지" 즉시 판별.
- 7c2b9a9be162: `last_status=error`이지만 `consecutive_failures=0` → **첫 에러, ISS-086 회귀 아님**
- 07-13/07-14 동일 잡 commit `eabe146`/`7ede99b`로 정상 push 확인 + 03-15 03:29 idle 600s timeout 1회 → **단발성 hang, 노이즈 floor 흡수**
- → ISS-086 ✅ 해결됨 상태 유지. 자가치유 `fixes_applied=0` 합리적.

**판별 매트릭스 v1.0.30 (07-15 갱신):**
| jobs.json | 자기진단 leak | Traceback/APIError | `consecutive_failures` | (d) 진단 트랜스크립트 | 판별 |
|-----------|--------------|---------------------|----------------------|---------------------|------|
| ok | Yes | No | 0 | No | ✅ FP (자기 진단 leak) |
| ok | No | No | 0 | Yes | ⚠️ 실제 이슈 가능 — (d) 내용으로 결정 |
| ok | Yes | No | 0 | Yes (ImportError + cookie expired) | 🔴 실제 이슈 (06-26 케이스) |
| **error** | - | - | **0** | - | 🟡 **단발성 hang** — 07-15 신규 패턴, ISS 회귀 아님 |
| error | - | - | ≥2 | - | ❌ **연속 실패 — 실제 회귀**, ISS-NNN 등록 |
| failed | - | Yes | - | - | ❌ 실제 실패 (수정 대상) |

## 3단계 memory_error_tracker + 4축 판별

- 최근 72시간 **82개** 분류 (Other 43 / NotebookLM 26 / RSS Feeds 10 / YouTube 1 / Notion Idea (DEAD) 1 / Cron Timeout 1)
- `new_issues: {Cron Timeout: 1, YouTube: 1}` 모두 FP (07-09 discriminator):
  - **Cron Timeout 1건**: `5d0f14aef84c/2026-07-01_22-06-27.md:1170` — 일일 리뷰 본문 `v1.0.27 patch (ISS-085 root cause, ...)` 인용 (잡 이름 drop 미적용)
  - **YouTube 1건**: `0f893ba14797/2026-07-14_14-01-15.md:1` — 잡 이름 자체가 `🧹 임시 산출물 일일 정리 (Manim+Blog+YouTube)`
- → **ISS-NNN 신규 등록 0건**. resolved_issues 0. needs_memory_update=true (단발성 known FP라 무시, day count 동기화만 적용)

## 메모리 동기화 (개선점 5 첫 실전 적용)

07-13 reference의 "개선점 5: MEMORY.md '알려진 이슈' 섹션 day count 동기화"를 **이번 회차에서 정식 적용**:

1. `~/.hermes/memory/issues.md`에 `## 🆕 2026-07-15 발견` 섹션 append (1102 lines)
2. `~/.hermes/memory/MEMORY.md` 헤더 `2026-07-14 → 2026-07-15` 갱신
3. `MEMORY.md` "알려진 이슈" 섹션 day count 동기화:
   - ISS-086-ext 11일째 → **12일째**
   - ISS-091 4일째 → **5일째** (07-14 신규 표기 `(07-14 신규)` 제거, 누적 일수만)
4. ISS-086 sync-skills / ISS-087 Token Plan / ISS-028 YouTube — 07-14 ✅ 해결됨 유지 명시

→ 동기화 신뢰도 검증: issues.md와 MEMORY.md의 day count 문자열 1:1 일치.

## 결정 지연 누적 카운터 (07-15 갱신)

| ISS | 발견 | 결정 지연 | 직전 대비 |
|---|---|---|---|
| ISS-091 GitHub Trending token 부재 | 07-11 | **5일** | 4→5 (+1) — token 발급 결정 시급 |
| ISS-086-ext git-auto-sync 경로 결함 | 07-04 | **12일** | 11→12 (+1) — 7일 임계 후 5일 추가, 14일 임계 도달 임박 |

07-07 noise-floor 정책 기준:
- 5일: ⚠️ 결정 지연 N일
- 7일+: 🔴 텔레그램/디스코드 푸시 검토
- 14일+: 🔴 비활성화/복구 결정 시급 (ISS-086-ext 14일 임계 도달 임박)

## 4단계 Notion 기록 (부분 완료)

- DB 스키마 pre-introspect ✅: `이름`(title) / `날짜` / `상태`(select 16옵션) / `점검 항목`(multi_select) / `요약` / `에러 수` / `수리 항목 수`
- ⚠️ **Notion POST는 이번 세션에서 완료하지 못함** — tool-call 한도 도달로 payload 작성/POST 단계 진입 전 중단
- 권장 페이로드 (다음 크론 또는 후속 작업):
  - `이름`: "심야 통합 정비 2026-07-15 03:30 KST"
  - `상태`: "일부 이슈" (warning 4 + recoverable 1 + 결정 지연 2건)
  - `점검 항목`: [에러 모니터링, 자가치유, 메모리 점검, 메모리 동기화, 심야정비, nightly-maintenance]
  - `에러 수`: 1 (skills-marketplace-sync 단발성 hang)
  - `수리 항목 수`: 0
- 페이지 ID 미생성. 후속 nightly 또는 수동 작업 필요.

## 노이즈 floor trend (07-07 정책 → 07-15)

| 신호 | 07-13 | 07-15 | 판정 |
|---|---|---|---|
| Self-Healer FP errors | 5 | **5** | noise (안정) |
| Warning (주1회 잡) | 1 | 4 | **noise (스케줄 artifact)** — 07-13 1 → 07-15 4 사이클 회귀 |
| recoverable | 0 | 1 | noise (단발성 hang) |
| new_issue | 1 (known FP) | 0 (FP 2) | noise |
| critical | 0 | **0** | noise |
| fixes_applied | 0 | **0** | noise |
| 결정 지연 누적 | 4건 (4/17/10/11일) | **2건 (5/12일)** | **진짜 알림 가치** — 07-13 4건에서 07-15 2건으로 축소 (ISS-086/087 해결 + ISS-086-ext/091 잔존) |

→ 07-15의 진짜 이슈는 **결정 지연 2건 (ISS-086-ext 12일째, ISS-091 5일째)**. 나머지는 모두 noise.
→ ISS-086/087은 07-14 해결 처리되어 결정 지연 카운터에서 제외됨. ISS-088 b26b0579a45f는 07-14 ✅ 해결됨 확인 (anon API로 정상 운영).

## 사용자에게 권고되는 결정 (우선순위 순)

1. **🔴 ISS-086-ext git-auto-sync 12일째 — 비활성화/복구 결정 시급** — 7일 임계 후 5일 추가, 14일 임계 도달 임박 (1~2일 내). 명시적 결정이 다음 단계.
2. **🟡 ISS-091 GitHub Trending token 5일째 — 발급 결정 권고** — `~/.hermes/secrets/github_token.txt` 1회 생성 (scope: `public_repo`, 5분 작업). 발급 전까지 anon API 정상 운영 중.

## 07-13 개선점 5 회고 (07-15 실전 적용)

- ✅ **MEMORY.md day count 동기화 정식 적용** — `ISS-091 (07-14 신규) ... 4일째` 표기를 `ISS-091 ... 5일째`로 단순화 (누적 일수만)
- ✅ **MEMORY.md 헤더 갱신 + nightly-maintenance 한 줄 요약 추가** — 07-15 노이즈 floor 노트 + ISS-086 단발성 hang 명시
- 🟡 **Notion POST 자동화 미실행** — tool-call 한도 도달로 payload 작성 단계에서 중단. 후속 작업 필요 (다음 nightly 03:30에서 자동 재시도되거나, 수동 후속 권장)

## 변경 이력
- 2026-07-15: 07-15 nightly-maintenance 실측 사례 추가. **신규 패턴: jobs.json `consecutive_failures=0` + `last_status=error` = 단발성 hang (ISS 회귀 아님)**. 결정 지연 4→2건 축소 (ISS-086/087 ✅ 해결 후).