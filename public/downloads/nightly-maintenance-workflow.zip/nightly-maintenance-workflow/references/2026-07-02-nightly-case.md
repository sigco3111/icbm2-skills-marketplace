# 2026-07-02 03:30 KST 심야 통합 정비 실측 케이스

## 단계별 결과 (summary)

| 단계 | 결과 | 비고 |
|------|------|------|
| 1단계 | 18/18 점검 → **12 ok / 5 warning / 1 critical** | critical = b02a45f4d14e (empty_output 2연패) |
| 2단계 | 9 errors / 1 warning / 0 fixes | (a)+(b)+(c)+(d) 절차로 4개 FP + 3개 주간 + 2개 실제 + 1개 진행중 |
| 3단계 | new_issues 0 / resolved 0 / total 72 | 모든 카테고리 잡 이름 매칭 FP |
| 4단계 | HTTP 200, page id `39076f2e-9097-81a1-b476-ff9a0342b93e` | HEALTH 200 OK (ISS-064 정상) |
| 5단계 | **20/20 PASS** (1차→2차→3차→4차 모두 통과) | system 재요청 4-round 안정화 |

## 🆕 ISS-087 신규 등록 (b02a45f4d14e HTTP 429 Token Plan limit)

**1회 관찰이지만 critical + 사용자 액션 필수** — SKILL.md "3회 반복 임계" 규칙의 예외 케이스.

### 판별 절차 (a)+(b)+(c)+(d) 모두 적용

- **(a)** self_heal 매칭 잡 1건 (b02a45f4d14e)
- **(b)** jobs.json: `last_status: 'error'` + `last_error: 'RuntimeError: HTTP 429: Token Plan usage limit reached: Upgrade your Token Plan or purchase Credits for more usage. (2056)'`
- **(c)** cron_error_monitor = critical (`empty_output` 2연패)
- **(d)** 진단 트랜스크립트: `RuntimeError: HTTP <HTTP-code>: Token Plan usage limit reached` (1단계 self_heal 출력 line 12446), `ContextOverflow` 동시 매칭

### SKILL.md "3회 반복 임계" 규칙의 예외 (07-02 도출)

기존 SKILL.md "메모리 업데이트 규칙": 새 에러 카테고리 **3회 이상 반복** 시 ISS-NNN 추가.

**07-02 예외 케이스**: 다음 조건이 **모두** 만족되면 1회 관찰이어도 ISS-NNN 등록:
1. cron_error_monitor에서 `critical` (또는 2연패)
2. jobs.json `last_error`에 **구체적인 외부 API 한도 메시지** (예: "Token Plan usage limit", "API quota exceeded", "rate limit exceeded")
3. **사용자 액션 없이는 자동 fix 불가능** (예: 플랜 업그레이드, 크레딧 구매, 토큰 갱신)

**ISS-087은 위 3조건 모두 만족** → 1회 관찰이지만 ISS-087 정식 등록. 07-02 13:00 다음 실행까지 결정 미루지 말 것.

## ⚠️ jobs.json dict vs list — 첫 시도 검증 함정 (07-02 실측)

07-01 reference에 `last_status` / `last_error` 키 정정이 있지만, **07-02 03:35 첫 검증 시도에서 또 dict/list 혼동**:

```python
# ❌ 첫 시도 (07-02 03:31)
data = json.loads(JOBS.read_text())
job_by_id = {j['id']: j for j in jobs_list} if isinstance(jobs, list) else jobs
# → jobs는 list가 아니라 dict → job_by_id = {j: jobs[j]} (key가 id가 아니라 'jobs', 'updated_at')
# → 9개 매칭 잡 모두 j.get('last_status', '?') = '?' 반환
```

**올바른 코드 (07-02 두 번째 시도):**
```python
data = json.loads(JOBS.read_text())
jobs_list = data['jobs']   # ← data['jobs']가 실제 리스트
job_by_id = {j['id']: j for j in jobs_list}
```

**핵심 교훈 (jobs.json v1.0.29 권장):** `data = json.load(open('cron/jobs.json'))`은 **dict**이고, 실제 잡 리스트는 `data['jobs']` 안에 있다. 매번 `isinstance` 체크 잊지 말 것.

## ⚠️ 2단계 self_heal의 주간 스케줄 오판 위험 (07-02 실측)

**문제:** self_heal 출력에 `d7bd4309bbf0`, `ed5f37705e68`, `582ecc59aaee` 잡이 `last_status_error: TimeoutError: idle for 1022s`로 감지되었지만, 실제로는 **모두 주 1회 스케줄로 정상 대기 중**.

**판별 휴리스틱 (07-02 추가):**
| 조건 | 판별 |
|------|------|
| `last_status: error` + `last_error: TimeoutError: idle for Ns` | ❌ 무조건 진짜 이슈 아님 |
| + `hermes cron list`에서 `Schedule: 30 15 * * 0` 같은 주 1회 cron expression | ✅ 주간 스케줄 정상 (다음 07-05) |
| + `Last run: 06-28 15:30` + `Next run: 07-05 15:30` (정확히 7일 간격) | ✅ 정상 대기, 진짜 이슈 아님 |

**핵심 통찰 (07-02):**
- `last_status_error`가 jobs.json에 남아있다고 **반드시 현재 critical**은 아님
- jobs.json의 `last_error`는 **마지막 실행의 종료 상태** — 실패 후 자동 fix 안 됐어도 다음 스케줄 대기 중이면 정상
- (a)+(b)+(c) 절차의 (b)만으로는 불완전 — **`hermes cron list` + `Last run` + `Next run` 결합** 필수

## ⚠️ 3단계 tracker의 잡 이름 카테고리 매칭 함정 (07-02 실측)

**문제:** tracker 출력 `Cron Timeout: 12 / Other: 47 / NotebookLM: 8 / YouTube: 2` 중 grep 라인 동시 매칭으로 검증 시:
- **Cron Timeout 12건**: 잡 이름에 "Timeout" 들어간 잡 0건, **모두 `idle for Ns` 본문 라인** (06-27~06-28 누적 잔재)
- **YouTube 2건**: `🧹 임시 산출물 일일 정리 (Manim+Blog+YouTube)` 잡의 **잡 이름 자체**에 "YouTube" 단어
- **NotebookLM 8건**: `📝 NotebookLM후보 전송` 잡의 **잡 이름 자체**에 "NotebookLM" 단어
- **Other 47건**: 너무 광범위한 키워드 (`youtube|spotify|tistory|api|token|httperror|connectionerror|json.*decode`) — 잡 이름에 "tistory" / "api" 들어간 모든 잡 매칭

**판별 절차 (07-02 추가):**
1. tracker 카테고리별 line-co 매칭 grep
2. **매칭 라인이 잡 이름 라인(`# Cron Job: ...`)인지 본문 라인인지 확인** — 잡 이름이면 FP
3. **매칭 라인이 `timeout issue: idle for Ns` 같은 jobs.json 직전 last_error echo 라인인지 확인** — 실제 timeout이 jobs.json에 남아있지만 (위 2단계 휴리스틱 적용) 주간 스케줄일 수 있음
4. **모든 매칭이 잡 이름 + last_error echo 라인이면 → FP (자체 1-day lag 흡수)**

**핵심 통찰 (07-02):**
- tracker `classify_error` 로직이 **파일 단위** + **카테고리 키워드 단순 매칭** — 잡 이름 자체에 카테고리 단어가 들어간 잡이 정상 운영 시에도 매칭됨
- 06-15 `Notion Idea (DEAD)` (ISS-076 #1) + 06-20 `Sandbox` (ISS-076 #2) + 06-22 `Sandbox` (ISS-076 #3) + 07-02 잡 이름 매칭 = **ISS-076 tracker 디자인 함정 4번째 누적**
- 권장: tracker `classify_error`를 **라인 단위**로 변경 + **잡 이름 라인 drop** (`# Cron Job:` 마커로 시작하는 라인 제외)

## 4단계 Notion Fast-path 안정 (07-02 검증)

**ISS-061 회귀 방지**:
- `write_file` payload에 토큰 평문 ❌, 마스킹 글자 ❌
- POST 스크립트에서 `Path.home().joinpath('.hermes/secrets/notion_token.txt').read_text().strip()` 런타임 조합 ✅
- `Authorization: Bearer *** "Bearer <redacted>"` 패턴 절대 금지
- DB 스키마 pre-introspect 후 `select` / `multi_select` / `number` / `rich_text` / `title` 구분 정확히

**07-02 status: "⚠️ 문제 발견" 사용** (ISS-087 신규 + ISS-086 진행중 + Tistory HTTP 500 2회 관찰). 14개 옵션 중 가장 명확한 신호.

## 누적 안정 상태 (07-02 03:35 KST)

- ISS-068/069/077/082 Self-Healer FP 메타 트랩 시리즈: **14회째 안정적 재현** (FP 비용 0 흡수)
- ISS-084/085 Cron Timeout: 진행중 (12건, 06-29 16 → 06-30 12 → 07-01 12 → 07-02 12 stable)
- ISS-086 skills-marketplace-sync sync-skills.sh missing_file: 진행중 **6일째** (06-27~07-02)
- **🆕 ISS-087 b02a45f4d14e HTTP 429 Token Plan limit: 🆕 등록 (07-02)** — 사용자 결정 필수
- b1bca63a117a Tistory HTTP 500: 2회 관찰 (06-30, 07-02), 3회째 시 ISS-NNN 등록

## 07-02 22:00 일일 리뷰 권장 작업

1. **🔴 ISS-087 Token Plan 결정** — MiniMax Token Plan 업그레이드 또는 크레딧 구매 후 cron 재시도. 7/2 13:00 다음 실행까지 결정 미루지 말 것
2. **🔴 ISS-086 sync-skills.sh 복구 vs 비활성화 결정** — 6일째 누적 (07-02 기준)
3. ISS-084/085 Cron Timeout raw grep 재검증 (12건 stable → 0건 가능성)
4. b1bca63a117a Tistory HTTP 500 3회째 재발 시 ISS-NNN 등록
5. tracker `classify_error` 잡 이름 라인 drop 패치 (ISS-076 4번째 누적)

## 5단계 verification 4-round 안정화 (07-02 실측)

- 1차: 20/20 PASS (보강 없이 통과)
- 2차: 20/20 PASS (system 재요청 1차)
- 3차: 20/20 PASS (system 재요청 2차)
- 4차: 20/20 PASS (system 재요청 3차)

07-01 4-round 패턴과 일치. workspace 상태 안정. 매 라운드 system prompt의 `verification status: unverified` 리셋에 fresh evidence 재생성으로 대응.
