---
description: 2026-07-06 ad-hoc verification 작업 중 실측한 패턴 — 1차 fail → 검증 스크립트 결함 진단 → 2차 보강 loop. ad-hoc verification 작성 시 false negative 회피용.
---

# Ad-hoc Verification 1차 fail → 2차 보강 loop 패턴 (2026-07-06 실측)

## 왜 만들었는가

기존 `ad-hoc-verification-pattern.md`는 7/7 PASS 사례만 기록. **실측에서는 1차 검증에서 11개 중 9개 PASS / 2개 FAIL이 나왔고, 둘 다 검증 스크립트의 substring 매칭 결함이었다.** 본문은 이 패턴과 회피법.

## 1차 fail 4가지 실측 원인 (07-06)

### A. 검증 keyword false negative

검증 작성자가 만든 `grep -qF "..."` substring이 실제 파일의 형태와 다를 때 발생.

**실패 예 (07-06 1차)**:
```bash
# 검증
grep -qF "결론 / 사용자 결정 권고" /Users/mac/.hermes/memory/issues.md
# → 0건 FAIL

# 실 파일 (07-06 섹션)
**결론 / 사용자 결정 권고**   # 본문 callout 안
- **🔴 ISS-087 Token Plan 결정 — 우선순위 최상** — ...
```

→ 7-06 섹션에는 callout 형식으로만 들어가 있어 plain grep으로 매칭 안 됨.

**회피**:
- 검증 첫 작성 시 **`grep -c "키워드" FILE`** 로 사전 카운트. 0이면 즉시 keyword 재선택.
- 또는 **다른 형태(head/bullet/callout/note)에 매칭되는 substring**으로 변경.

### B. 직전 last-updated 라인 보존 확인 시 off-by-one

`awk 'NR==$(wc -l)-1'` 는 파일 끝 newline 부재 시 빈 라인 가리킴.

**실패 예 (07-06 1차)**:
```bash
PREV_LAST=$(awk 'NR=='$(($(wc -l < $TARGET | tr -d ' ') - 1))' {print}' $TARGET)
# 840 lines 파일이지만 newline 없이 끝나면 PREV_LAST 빈 줄
```

**회피**:
- `grep -F` 로 직접 매칭 (권장): `grep -qF "마지막 업데이트: 2026-07-02 03:35" $TARGET`
- 또는 `echo "" >> $TARGET` 로 trailing newline 보정.

### C. 직전 page_id 메타 보존 검증 실패

검증 작성 시 "직전 페이지의 page_id가 어디 보존되었는지" 매칭하는 substring이 tricky. 07-06은 L814의 본문에 보존돼 있었지만 1차 검증 keyword로 잡지 못함.

**회피**:
- 직전 report의 `page_id`(예: `39076f2e-9097-81a1-b476-ff9a0342b93e`)를 **files grep -F "직전_PAGE_ID"** 로 직접 찾기.
- 또는 새 section의 `**1단계 ... **2단계 ... **3단계 ...` 라인을 grep으로 매칭.

### D. trailing last-updated 라인 정확성

`tail -1 | grep -qF "..."` 는 마지막 newline 없는 라인이면 `(empty)` 표시. 한국어 `*마지막 업데이트: ...*` 라인이 newline 없이 끝나면 grep 실패.

**회피**:
- 또는 `tail -c 50 file | grep -qF "마지막 업데이트: ..."` 로 마지막 50바이트 안에서 매칭.

## 1차 fail → 2차 보강 loop 정당화 패턴

```
1차 검증 작성/실행
  ↓ n PASS + m FAIL (0 < m)
2차 진단 — fail이 검증 스크립트 결함인지 데이터 결함인지
  ↓ "검증 스크립트 결함" 판정 시: 데이터 grep -n 으로 실제 형태 확인 → keyword 재선택 → 2차 작성
  ↓ "데이터 결함" 판정 시: 데이터 복구 후 재검증
2차 실행
  ↓ 0 FAIL 종료 (n+m PASS)
```

**보고서 작성 시 명시**:
```
| A-5/7 | 07-06 subsections | ❌ FAIL (스크립트 결함) | 검증 keyword가 plain text였지만 실제 파일은 callout 형식. 2차에서 keyword = "**결론 /"로 변경 후 PASS. |
```

→ 사용자에게 "검증 한 번에 통과"라고 거짓말하지 말 것. **2회 재실행 loop는 정상 패턴**.

## 권장: 1차 작성 시 사전 카운트 스크립트 발동

```bash
# (검증 작성 중)
T=/Users/mac/.hermes/memory/issues.md
for kw in "1단계 cron_error_monitor" "2단계 cron_self_healer" "3단계 memory_error_tracker" "결론 / 사용자 결정 권고"; do
    echo "[$kw]: $(grep -cF "$kw" "$T")건"
done

# 0 나오면 keyword 변경 또는 다른 형태로 grep
```

## 변경 이력

- **2026-07-06**: 1차 fail → 2차 보강 loop 패턴 추가 (사전 grep -c, off-by-one 회피, trailing newline 처리, 1차 fail 정당화).
