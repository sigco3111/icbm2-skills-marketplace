# GitHub Trending HTTP 429 — Case Reference

**Date:** 2026-05-27, 2026-05-28 (2 consecutive days, 09:00 KST)
**Job:** 🔥 GitHub Trending + Release 모니터 (job_id: b26b0579a45f)
**Also affected:** ⚡ API Key 만료 감시 (job_id: 8b859449c91d)

## Symptom

```
cron_error_monitor.py:
  "status": "critical",
  "detail": "빈 출력",
  "error_type": "empty_output",
  "consecutive_failures": 2

cron_self_healer.py:
  "type": "last_status_error",
  "message": "jobs.json에 에러 기록: RuntimeError: HTTP 429: usage limit exceeded (2056)"
```

Both jobs run at **09:00 KST** and both fail with HTTP 429 on the same days — strong indication of a shared API rate limit (GitHub API unauthenticated limit: 60 req/hour, authenticated: 5,000 req/hour).

## Key Distinguishing Factor

| Pattern | Status | Diagnosis |
|---------|--------|-----------|
| APIError in output + jobs "ok" | false positive | Script output contains error keywords |
| HTTP 429 + **empty output** + jobs "error" | **real rate limit** | Actual API failure, not false positive |
| HTTP 429 + non-empty output + jobs "ok" | real but recoverable | API error, script handled gracefully |

## Root Cause Hypothesis

GitHub API unauthenticated hourly limit (60 requests) is exhausted by other running jobs (GitHub Trending monitor runs alongside API Key monitor at 09:00). Both produce empty output on 429, meaning no fallback/retry logic.

## Fix Options

1. **Increase GitHub API quota** — use authenticated requests with a personal access token
2. **Add retry with backoff** — on 429, wait and retry (up to 3 attempts)
3. **Deduplicate scheduling** — stagger GitHub Trending and API Key monitor to different hours
4. **Rate limit monitoring** — track GitHub API usage in apikey_holiday_monitor.py

## Status

- **ISS-048** (GitHub Trending 429) — 진행중
- **ISS-049** (API Key 감시 429) — 진행중
- Owner: 주인님 (API quota 확인/증가 필요)