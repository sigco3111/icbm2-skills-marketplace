# 2026-07-10 심야 통합 정비 실측 사례

## 결과 한 줄

**19 잡 점검 / 15 ok / 4 warning / 0 critical / 0 fixes. new_issues 0, resolved 2 (YouTube, News-to-Wiki). 시스템 안정 운영 중. 결정 지연 누적만 진짜 이슈.**

## 1단계 cron_error_monitor

- 19 잡 점검 → **15 ok / 4 warning / 0 critical / 0 alerts / 0 recovery**
- warning 4건 = 모두 주1회 잡 (정상 노이즈 floor):
  - d7bd4309bbf0 📋 일요일 심층 점검 (108.0h stale)
  - ed5f37705e68 📖 주간 학습 로그 (103.4h stale)
  - 7995f1387b79 📰 주간 기술 요약 뉴스레터 (107.5h stale)
  - 582ecc59aaee 📊 Agent Benchmark Tracker (113.5h stale)

## 2단계 cron_self_healer

- 19 잡 점검 → **8 errors (FP 메타 트랩) + 1 missing_file (ISS-086) + 1 warning (의도된 비활성) + 0 fixes**
- 모두 노이즈 floor — Self-Healer FP 메타 트랩 (ISS-068/069/077/082 시리즈) + ISS-086 sync-skills.sh missing_file
- **활성 에러 0, 자동 fix 0**
- warning 1건 = `notion-outage-watch-3h` `enabled=False, state=completed` (의도된 비활성)

## 3단계 memory_error_tracker

- 55 파일 (Other 47 / NotebookLM 5 / RSS Feeds 3)
- **new_issues 0 / resolved 2**:
  - YouTube 1→0
  - News-to-Wiki 1→0 (ISS-083 해결 재확인, 2회째)
- needs_memory_update=true (단발성 0건이라 무시)

## 결정 지연 누적 카운터 (07-10 갱신)

| ISS | 발견 | 결정 지연 | 직전 대비 |
|---|---|---|---|
| b26b0579a45f GitHub Trending 401 | 07-09 | 1일 | 🆕 (07-09 신규) |
| ISS-086 sync-skills.sh missing | 06-27 | **14일** | 13→14 (+1) |
| ISS-086-ext git-auto-sync 경로 | 07-04 | **7일** | 6→7 (+1) |
| ISS-087 HTTP 429 Token Plan | 07-02 | **8일** | 7→8 (+1) |

07-07 noise-floor 정책 기준:
- 1~3일: 일반 ⚠️
- 4~6일: ⚠️ 결정 지연 N일
- 7일 이상: 🔴 텔레그램/디스코드 푸시 검토

→ 4건 중 3건이 7일+ 임계 초과. 사용자에게 일별 누적 리포트 권장.

## 4단계 Notion 기록

- DB: `33c76f2e-9097-8198-bd1b-c3ea3cfbbae8` (정비 리포트)
- **page_id: `39876f2e-9097-81c6-ade1-c135e5c869cf`**
- URL: https://app.notion.com/p/ICBM2-2026-07-10-03-30-KST-39876f2e909781c6ade1c135e5c869cf
- 상태: `⚠️ 문제 발견`
- 점검 항목 multi_select: 에러 모니터링 / 자가치유 / 메모리 점검 / 메모리 동기화 / 심야정비 / nightly-maintenance / Self-Healer / Error Monitor
- GET 재검증 통과

## 노이즈 floor 실증 (07-07 정책 → 07-10)

| 신호 | 07-09 | 07-10 | 판정 |
|---|---|---|---|
| Self-Healer FP errors | 10 | 8 | noise (FP 메타 트랩) |
| Warning 4건 (같은 주1회 잡) | 4 | 4 | noise (정상) |
| new_issue | 0 | 0 | noise floor |
| critical | 1 (GitHub 401) | 0 | 07-10 0건 — 안정 |
| fixes_applied | 0 | 0 | noise (불필요) |
| 결정 지연 누적 | 3건 (6/13/7일) | 4건 (1/14/7/8일) | **진짜 알림 가치** |

→ 07-10의 진짜 이슈는 **결정 지연 누적 +1건 (GitHub 401 신규)**. 나머지는 모두 noise.

## 배운 점 / 개선점

### 1. Notion 페이로드는 `write_file` + `@file` 주입이 heredoc보다 깨끗

기존 2026-07-06 패턴(`bash heredoc` + sentinel/sed 토큰 치환)은 토큰 마스킹 + heredoc 따옴표 escape 함정이 많음. 07-10에는 `write_file`로 JSON 페이로드 전체를 파일로 작성 → `curl -d @file`로 주입. 함정 0건. **단순 페이로드(2KB 이하)는 이 패턴이 우선.**

### 2. memory_error_tracker는 issues.md를 자동 갱신하지 않음

스크립트는 JSON 출력만 하고 issues.md 동기화는 에이전트 책임. 3단계 출력 후 `## 🆕 YYYY-MM-DD` 섹션을 issues.md에 수동 추가해야 함. **워크플로 표준: 3단계 JSON 보고 + 즉시 issues.md 동기화**.

### 3. 결정 지연 카운터는 issues.md 표에 통합 가능

현재 결정 지연은 매 세션 섹션 본문에 흩어져 있음. `recurring-noise-floor.md`의 "결정 지연 일수" 표를 issues.md에 정규 섹션으로 두는 게 추세 추적에 유리. (미구현 — 다음 세션 검토)

### 4. ISS-090 추적 갭

07-10 issues.md 본문에 "ISS-090 노이즈 floor"라고 썼지만 ISS-090은 issues.md 표에 정식 등록 안 됨. 노이즈 floor를 정식 ISS로 관리할지 결정 필요.

## 변경 이력

- 2026-07-10: 07-10 nightly-maintenance 실측 사례 추가 (page_id `39876f2e-9097-81c6-ade1-c135e5c869cf` 기반)
