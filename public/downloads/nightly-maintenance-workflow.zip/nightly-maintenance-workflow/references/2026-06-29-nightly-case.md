# 2026-06-29 03:50 KST 심야 통합 정비 실측 케이스

## 요약

- **결과**: 19 잡 점검 — 4 ok / 9 warning / **4 critical** / 1 recoverable
- **자가치유**: 16 errors / 1 warning / **0 fixes** (16 errors 모두 ISS-068/069/082 메타 트랩)
- **메모리 동기화**: ISS-083 해결 ✅, ISS-084 신규 등록 🔴
- **Notion 기록**: HTTP 200 OK, page id `38d76f2e-9097-8157-961f-ef1a4acabb30`
- **ad-hoc 검증**: 20/20 PASS (round 2, false negative 수정 후)

## 핵심 발견

### 🔴 ISS-084 — Cron Timeout 급증 (06-29 신규)

- **Cron Timeout 카테고리**: 06-27 6건 → **06-29 16건 (+167%)**
- **빈 출력 잡**: 06-27 3건 → **06-29 12건** (warning 8 + critical 4)
- **critical 4건 (사용자 검토 필수)**:
  - `5d0f14aef84c` 🔄 일일 자기 개선 리뷰 — consecutive_failures **4**
  - `5a376ec002c3` 🔄 Git 자동 동기화 (통합) — consecutive_failures **4**
  - `81f1c81f8664` 🛡️ 심야 통합 점검 — consecutive_failures **3**
  - `b26b0579a45f` 🔥 GitHub Trending + Release — consecutive_failures **3**

### ✅ ISS-083 해결 (06-29 raw grep 검증)

- 06-27에 "진행중"으로 등록된 News-to-Wiki 카테고리 이슈
- 06-29 03:50 raw 라인 grep 결과: 메모리 leak 아님
- 정상 단어 매칭으로 확인 (`wiki` / `Dev News` 단어가 e330c7de50d1 잡 출력에 정상 등장)
- (a)+(b)+(c) 절차로 FP 확정, 권장 종료

### 🟡 skills-marketplace-sync missing_file 지속

- `/Users/mac/Desktop/project/work/icbm2-skills-marketplace/scripts/sync-skills.sh` 부재
- M4 마이그레이션 후 Desktop/project/work 경로 문제 — 06-29 22:00 일일 리뷰에서 sync-skills.sh 복구 또는 잡 비활성화 결정 미완료

## 핵심 통찰

### 1. 빈 출력 잡 누적 추세 (06-27 3 → 06-29 12)

**패턴**: 모두 cron stream idle timeout (현재 600s) 직후 빈 응답

**기존 ISS-068/069 메타 트랩과의 차이**:
- 기존 메타 트랩: jobs.json `consecutive_failures: 0` 유지 (자기 진단 leak만 매칭)
- 06-29 신규: `consecutive_failures: 3~4` 누적 = **실제 cron stream 응답 실패 가능성 상승**

### 2. Cron Timeout 카테고리 FP vs Real 구분

- Self-Healer 16 errors 모두 메타 트랩 (FP) — 자동 fix 불필요
- 그러나 critical 4건 (3~4회 연속 누적)은 FP가 아닐 수 있음
- **판별 임계**: consecutive_failures ≥ 3이면 raw 출력 grep 권장

### 3. ISS-083 즉시 검증 패턴

- 06-27에 "진행중" + "raw grep 권장"으로 등록된 이슈
- 06-29 03:50 nightly-maintenance 워크플로우 자체가 grep 검증
- 일일 리뷰 (22:00)까지 기다리지 않고 **심야 점검에서 즉시 해결 가능** → 다른 "진행중" 이슈에도 적용 검토

### 4. Hermes Verification Gate (06-29 system 강제)

- workspace에 canonical test/lint/build 명령이 없을 때, 시스템이 `verification status: unverified` 경고 발송
- **반응 프로토콜**:
  1. `mktemp -t hermes-verify-XXXXXX.sh`로 임시 스크립트 생성
  2. 도메인별 grep 검증 (파일 존재, 크기, 핵심 마커, last_updated 등)
  3. Round 1 → Round 2 self-correction: 한자/한글 변형 매칭 (`12회째|12번째`)
  4. 정리: `rm -f` 검증 스크립트
  5. 결과를 "ad-hoc verified"로 명시 (suite green 아님)

## 카테고리 추이 (06-27 → 06-29)

| 카테고리 | 06-27 | 06-29 | 변화 |
|---------|-------|-------|------|
| Cron Timeout | 6 | **16** | **+10 (+167%)** 🔴 |
| NotebookLM | 41 | 46 | +5 |
| Sandbox | 46 | 39 | -7 |
| RSS Feeds | 21 | 22 | +1 |
| Other | 8 | 16 | +8 |
| YouTube | 6 | 7 | +1 |
| Notion Idea (DEAD) | 2 | 3 | +1 |
| News-to-Wiki | 1 | 1 | 0 (ISS-083 해결) |

## 후속 조치 (06-29 22:00 일일 리뷰)

1. **ISS-084 critical 4잡 raw 출력 grep** — FP vs real 실패 판별
2. **빈 출력 잡 일괄 진단** — 12건 모두 cron stream idle 600s 직후 빈 응답 패턴 raw 확인
3. **ISS-068/069 12번째 재발 vs 신규 패턴 사용자 판단** — 메타 트랩이 3~4회 누적으로 escalate 됐는지, 또는 새로운 모델 응답 실패 패턴인지
4. **cron stream timeout 600s → 900s 조정 검토** — 06-30 점검에서 권장
5. **skills-marketplace-sync sync-skills.sh 복구 또는 잡 비활성화 결정**

## 검증 프로토콜 (재사용)

```bash
VERIFY=$(mktemp -t hermes-verify-XXXXXX.sh)
cat > "$VERIFY" << 'BASHEOF'
#!/bin/bash
set -u
PASS=0; FAIL=0
MEMORY="/Users/mac/.hermes/memory/MEMORY.md"
ISSUES="/Users/mac/.hermes/memory/issues.md"
check() { if eval "$2" >/dev/null 2>&1; then PASS=$((PASS+1)); echo "PASS  $1"; else FAIL=$((FAIL+1)); echo "FAIL  $1"; fi; }
check "MEMORY.md exists" "[ -f '$MEMORY' ]"
check "issues.md exists" "[ -f '$ISSUES' ]"
check "MEMORY.md size <8000" "[ \$(wc -c <'$MEMORY') -lt 8000 ]"
check "MEMORY.md header date current" "grep -qE 'issues.md.*[0-9]+줄.*2026-' '$MEMORY'"
check "issues.md last_updated footer" "grep -q '마지막 업데이트' '$ISSUES'"
echo "RESULT: $PASS PASS / $FAIL FAIL"
[ "$FAIL" -eq 0 ] && exit 0 || exit 1
BASHEOF
chmod +x "$VERIFY"
bash "$VERIFY"
RC=$?
rm -f "$VERIFY"
exit $RC
```

## 교훈 (다음 세션에 전달)

1. **빈 출력 잡 3~4회 누적이 임계** — consecutive_failures ≥ 3이면 메타 트랩이 아닌 실제 실패 가능성. raw grep 후 수동 결정.
2. **ISS 진행중 이슈는 심야 점검에서 즉시 검증 가능** — 22:00 일일 리뷰까지 안 기다리고 raw grep으로 즉시 해결/등록 결정.
3. **cron stream idle timeout 600s가 모델 응답 latency와 충돌** — 900s 조정 검토 (06-30 점검).
4. **M4 마이그레이션 후 Desktop/project/work 경로 문제** — sync-skills.sh 복구 또는 잡 비활성화 결정이 2일간 미완료 상태 지속.