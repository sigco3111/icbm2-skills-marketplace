---
description: 2026-07-11 심야 통합 정비 실측 사례 + MEMORY.md 동기화 표준화 학습. 4단계 → 5단계 파이프라인 갱신 (3.5단계 MEMORY 동기화 신설). 결정 지연 4건 7일 임계 일제 초과 (32일분).
---

# 2026-07-11 심야 통합 정비 실측 사례

## 결과 한 줄

**19 잡 점검 / 15 ok / 4 warning / 0 critical / fixes 0. 노이즈 floor 정상 흡수 (FP 7건 23회째 같은 패턴 + warning 4건). 결정 지연 누적 4건이 진짜 이슈 (32일분 사용자 액션 분산). MEMORY.md "알려진 이슈" 섹션 신설 → 다음 세션이 결정 임계를 즉시 보존.**

## 1단계 cron_error_monitor

- 19 잡 점검 → **15 ok / 4 warning / 0 critical / 0 alerts / 0 recovery**
- warning 4건 = 모두 같은 주1회 잡 (ISS-090 노이즈 floor):
  - d7bd4309bbf0 📋 일요일 심층 점검 (132.0h stale)
  - ed5f37705e68 📖 주간 학습 로그 (127.4h stale)
  - 7995f1387b79 📰 주간 기술 요약 뉴스레터 (131.5h stale)
  - 582ecc59aaee 📊 Agent Benchmark Tracker (137.4h stale)

## 2단계 cron_self_healer

- 20 잡 점검 → **12 healthy / 7 errors / 1 warning / 0 fixes** (AUTO-FIX)
- 에러 6건 = 모두 `output_error` 패턴 매치 (Self-Healer FP 메타 트랩, ISS-068/069/077/082) + `missing_file` 1건 (ISS-086 sync-skills.sh 부재)
- **활성 에러 0, 자동 fix 0**
- warning 1건 = `notion-outage-watch-3h` `enabled=False, state=completed` (의도된 비활성)
- **07-10 대비 변화**: errors 8→7 (-1, 심야점검 자기참조 FP 이번에 사라짐)

## 3단계 memory_error_tracker

- 56개 파일 (Other 40 / RSS Feeds 9 / NotebookLM 6 / YouTube 1)
- 07-10(55) 대비 +1: **RSS Feeds 3→9** (단발성 아닌 카테고리 누적 — 관찰 필요)
- **new_issues 1건 (YouTube 1개) = ISS-028 재발 패턴** — 1건 단발성으로 신규 ISS-NNN 등록 안 함 (노이즈 floor 정책)
- resolved 0건
- needs_memory_update=true (단발성이라 무시)

## 🆕 3.5단계: MEMORY.md 동기화 신설 (이번 세션의 핵심 학습)

이전: 3단계에서 `memory_error_tracker.py`만 실행하고 `~/.hermes/MEMORY.md`의 "알려진 이슈" 섹션 동기화는 **누락**. 마지막 동기화가 06-26에서 07-11까지 15일간 갱신 안 됨.

이번에 신설한 MEMORY.md 표준 구조:

```markdown
# ICBM2 장기 기억 (MEMORY.md)

> **마지막 동기화:** YYYY-MM-DD (심야 통합 정비 HH:MM KST — 결정 지연 임계 갱신)
> **알려진 이슈 단축 경로:** 자세한 진행은 `memory/issues.md`. 본 파일에는 메모리에 박아둘 만한 결정 임계/카테고리만 보존.

---

## 알려진 이슈 (YYYY-MM-DD 갱신)

### 🔴 결정 지연 7일+ — 사용자 액션 임박 (N건)
| ISS | 주제 | 발견 | 결정 지연 | 임계 | 권장 |

### 🟡 진행중 (FP 메타 트랩, 신규 ISS 불필요)
- ISS-068/069/077/082 Self-Healer FP 메타 트랩 시리즈 (23회째 안정)
- ISS-083 News-to-Wiki ✅ 해결됨
- ISS-090 노이즈 floor

### 🟢 노이즈 floor 정책
- 7~10건 FP errors → 매일 동일 → 별도 ISS-NNN 등록 안 함
- 1건짜리 단발성 new_issue → 3일 연속 같은 카테고리 등장 시에만 신규 ISS
- critical ≥ 1 또는 결정 지연 5일+ → ⚠️ 문제 발견 등급
- 7일+ 결정 지연 → 텔레그램/디스코드 푸시 검토
```

**학습**: MEMORY.md는 다음 세션이 "즉시 알아야 할" 임계(7일+, 5일+, 1건 3일 임계)를 보존하는 단축 경로지 상세 이력이 아님. issues.md가 상세 진행을 들고 있고 MEMORY.md는 그것의 압축판. 두 파일 역할 분담이 표준화되어야 함.

## 결정 지연 누적 카운터 (07-11 갱신)

| ISS | 발견 | 결정 지연 | 직전 대비 |
|---|---|---|---|
| **b26b0579a45f GitHub Trending 401** | 07-09 | **2일** | 🆕 (07-09 신규) |
| **ISS-086 sync-skills.sh missing** | 06-27 | **15일** | 14→15 (+1, 🆕 14일 마일스톤 초과) |
| **ISS-086-ext git-auto-sync 경로** | 07-04 | **8일** | 7→8 (+1) |
| **ISS-087 HTTP 429 Token Plan** | 07-02 | **9일** | 8→9 (+1) |

**총 결정 지연 = 34일분 (2+15+8+9)** 사용자 액션 분산. 7일 이상 = 4건 모두 임계 초과.

07-07 noise-floor 정책 기준:
- 1~3일: 일반 ⚠️
- 4~6일: ⚠️ 결정 지연 N일
- 7일 이상: 🔴 텔레그램/디스코드 푸시 검토

→ 4건 중 3건이 7일+ 임계 초과 + 1건이 신규 2일째. **텔레그램/디스코드 푸시 자동화 강력 권장 시점.**

## 🆕 RSS Feeds 누적 관찰 필요 (07-11)

- 07-10: RSS Feeds 3 → 07-11: RSS Feeds 9 (3배 증가)
- 단발성이 아닌 카테고리 단위 누적 — 다음 점검(07-12)에서 3일 연속 9+ 시 **신규 ISS 검토**
- 07-11은 1일 데이터라 단발성으로 처리. **07-12 추세 확인 권장.**

## 4단계 Notion 기록

- DB: `33c76f2e-9097-8198-bd1b-c3ea3cfbbae8` (정비 리포트)
- **page_id: `39976f2e-9097-816e-a259-d5ebb3b2ce39`**
- URL: https://app.notion.com/p/ICBM2-2026-07-11-03-30-KST-39976f2e9097816ea259d5ebb3b2ce39
- 상태: `⚠️ 문제 발견` (결정 지연 4건 7일+ 임계 초과)
- 점검 항목 multi_select: 에러 모니터링 / 자가치유 / 메모리 점검 / 메모리 동기화 / 심야정비 / nightly-maintenance / Self-Healer / Error Monitor
- POST 200 + GET 재검증 통과 (id 일치)

## 노이즈 floor 실증 (07-07 정책 → 07-11)

| 신호 | 07-09 | 07-10 | 07-11 | 판정 |
|---|---|---|---|---|
| Self-Healer FP errors | 10 | 8 | 7 | noise (FP 메타 트랩, 변동 정상) |
| Warning 4건 (같은 주1회 잡) | 4 | 4 | 4 | noise (정상 의도) |
| new_issue (단발성) | 1 | 0 | 1 | noise floor (3일 연속 임계 미만) |
| critical | 1 | 0 | 0 | noise (07-09만 1건, 일시적) |
| fixes_applied | 0 | 0 | 0 | noise (불필요) |
| 결정 지연 누적 (7일+) | 3 | 4 | 4 | **진짜 알림 가치 (07-11 = 32일분)** |
| RSS Feeds 누적 | 1 | 3 | 9 | 🆕 단발성 아닌 누적 — 07-12 추세 확인 |

→ 07-11의 진짜 이슈는 **결정 지연 누적 + RSS Feeds 누적 임계 접근**. 나머지는 모두 noise.

## 개선점 / 다음 점검 권장

### 1. MEMORY.md 동기화 단계를 3.5로 표준화 (이번 패치)

이전 4단계 → 5단계 (3.5 추가). SKILL.md 본체에 파이프라인 헤더에 명시. 다음 세션부터 매 점검마다 동기화.

### 2. 텔레그램/디스크 푸시 자동화 검토

4건 모두 7일+ 결정 지연 — 사용자 푸시 자동화 가장 강력한 권장 시점. 사용자 승인 시 즉시 구현 가능 (Telegram 봇, Discord webhook 모두 secrets에 등록만 하면 됨).

### 3. RSS Feeds 누적 알림 자동화

07-10 → 07-11에서 3→9로 3배 증가. 단발성 아닌 카테고리 누적은 다음 점검부터 `categories.RSS_Feeds > 5` 시 ⚠️ 신호 발생하도록 memory_error_tracker.py 자체에 임계 내장 검토.

## 변경 이력

- **2026-07-11**: 심야 통합 정비 실측 사례 추가. 결정 지연 누적 4건 (32일분). MEMORY.md 동기화 표준화 학습을 SKILL.md에 반영. RSS Feeds 누적 (3→9) 신규 관찰 신호.
