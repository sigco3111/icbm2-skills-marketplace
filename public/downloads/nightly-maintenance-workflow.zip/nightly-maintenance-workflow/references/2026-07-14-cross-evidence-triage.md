# 2026-07-14 심야 정비: 상태 파일과 최신 실행 증거 교차검증

## 핵심 교훈

`error_monitor_state.json`의 과거 실패 기록이나 `issues.md`의 누적 일수만으로 활성 이슈를 판정하면 이미 복구된 항목을 계속 진행중으로 보고할 수 있다. 심야 정비에서는 **현재 상태 + 최신 산출물 + 실제 파일/저장소 증거**를 함께 확인한 뒤 해결 여부를 갱신한다.

## 판정 순서

1. `cron_error_monitor.py`와 `cron_self_healer.py`의 현재 결과를 확보한다.
2. `jobs.json`에서 대상 잡의 `last_run_at`, `last_status`, `last_error`를 확인한다.
3. 대상 잡의 최신 cron output을 직접 읽어 실제 성공 결과가 있는지 확인한다.
4. 파일 복구나 Git 동기화 이슈라면 대상 파일 존재, 저장소 HEAD, 원격 주소, 최신 push 증거를 확인한다.
5. API/할당량 이슈라면 최신 실행의 수집·저장·실패 수를 확인한다.
6. 위 증거가 일치할 때만 `issues.md`와 보조 `MEMORY.md`를 해결됨으로 갱신한다.

## 실측 예시

- skills marketplace: 스크립트 존재 + 저장소 HEAD `7ede99b` + 최신 cron output의 main push 성공을 확인해 ISS-086 해결 처리.
- 블로그 주제 갱신: 최신 실행에서 41개 수집, 12개 저장, 실패 0 + `last_status=ok`로 ISS-087 해결 처리.
- GitHub Trending: 최신 실행에서 46개 저장, 관심 저장소 12개 폴링 성공으로 인증 장애 해결 처리.
- git-auto-sync: 잡 상태는 `ok`여도 출력이 `[SILENT]`뿐이고 두 대상 경로가 없으면 실제 동기화 실패로 유지.

## 메모리 동기화 주의

`memory_error_tracker.py`는 상태 JSON을 갱신하지만 `issues.md`와 `MEMORY.md`를 자동으로 쓰지 않을 수 있다. `needs_memory_update=true`이면 파일 mtime과 내용을 확인하고, 변경이 없으면 에이전트가 직접 동기화한 뒤 키 문구를 재검색해 검증한다.

## Notion 기록 의미

- `에러 수`: Self-Healer의 raw 정규식 매치 수가 아니라 **교차검증 후 남은 실제 운영 이슈 수**.
- `수리 항목 수`: 자동 패치 수만 뜻하지 않는다. 이번 점검에서 증거로 해결 상태를 확정하고 레지스트리를 정리한 항목도 별도로 명시해 집계할 수 있다.
- POST 성공 후 `GET /v1/pages/{page_id}`로 제목, 날짜, 상태, 수치, 점검 항목을 재검증한다.
