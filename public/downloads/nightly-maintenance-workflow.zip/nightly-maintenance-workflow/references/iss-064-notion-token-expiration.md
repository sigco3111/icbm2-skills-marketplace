# ISS-064 — 외부 토큰 만료 / 환경 이슈 패턴 (2026-06-07 발견)

**Issue ID**: ISS-064
**Discovered**: 2026-06-07 15:32 KST (일요일심층 weekly report)
**Status**: 진행중 (주인님 액션 대기 — notion.so/my-integrations에서 토큰 재발급)
**Related**: ISS-002 (NotebookLM 인증), ISS-035 (NB 인증), ISS-061 (Bearer 토큰 마스킹 함정)

## 증상

`d7bd4309bbf0 일요일 심층 점검` 15:32 weekly report 실행:
- 6개 payload (Tistory 57건, weekly newsletter, cron 99%, cron 2 fail, wiki 123, broken links 43) 모두 Notion 기록 실패
- `POST https://api.notion.com/v1/pages` → 401 unauthorized
- `GET https://api.notion.com/v1/users/me` → 401 unauthorized
- jobs.json: `d7bd4309bbf0` 상태는 ok (자기는 401을 critical로 안 올림)

상태 파일에 보존된 진단:
```json
{
  "status": "❌ Notion API call rejected (HTTP 401, 'API token is invalid')",
  "token_file": "~/.hermes/secrets/notion_token.txt",
  "token_length": 50,
  "token_prefix": "ntn_",
  "target_db": "33c76f2e-9097-81be-9ea4-cefd03512e81",
  "payloads_preserved": 6
}
```

## Root cause

`~/.hermes/secrets/notion_token.txt` 자체는 50자 + `ntn_` prefix로 syntax 유효. 하지만 **Notion integration이 외부에서 revoke**됨 (90일 만료 정책 또는 workspace 정리 추정).

자가치유 시스템이 잡지 못한 이유:
- `cron_error_monitor.py` 1단계: jobs.json의 last_status_error만 검사 → 잡이 ok면 critical 안 올림
- `cron_self_healer.py` 2단계: scripts/secrets/memory health만 검사 → Notion API 호출 자체는 검증 안 함
- `memory_error_tracker.py` 3단계: cron output의 카테고리 단어 매칭 → 401 키워드는 tracker FP 위험으로 매칭 안 함

즉, **외부 토큰 만료는 모니터의 사각지대**.

## 영향 범위 (2026-06-07 기준)

Notion 의존 잡:
- `d7bd4309bbf0 일요일 심층 점검` (weekly report) — 6개 payload 미기록
- `81f1c81f8664 심야 통합 점검` (Maintenance DB) — 1개 payload 미기록 (이전 03:30 실행)
- `582ecc59aaee Agent Benchmark Tracker` (DB 기록) — 1개 payload 미기록
- `388898171a79 지식 그래프 자동 구축` (DB 기록) — 1개 payload 미기록
- `b02a45f4d14e 블로그 주제 갱신 긱뉴스` (12개 Notion fallback) — 12개 payload 미기록

다행히: Tistory / GitHub / YouTube는 Notion 토큰 무관 → 영향 없음

## 조치 프로토콜 (외부 토큰 만료 감지 시)

### 1단계: 즉시 기록
```bash
python3 ~/.hermes/scripts/feedback_collector.py add \
  --category correction \
  --content "Notion integration token expired (YYYY-MM-DD). [job] [N] payloads failed with 401. Action: 주인님 needs to reissue at notion.so/my-integrations." \
  --severity high \
  --resolved false
```

### 2단계: payload 보존 (자동 재시도 대비)
실패한 Notion 페이지 body, headers, db_id 등을 status 파일에 저장:
```json
{
  "iss": "ISS-064",
  "discovered": "2026-06-07T15:32:00+09:00",
  "pending_payloads": [
    {"db_id": "33c76f2e-9097-81be-9ea4-cefd03512e81", "body": {...}, "type": "weekly_report"},
    ...
  ],
  "retry_after": "주인님 토큰 갱신 후"
}
```

### 3단계: issues.md + MEMORY.md 등록
- `memory/issues.md`에 `ISS-NNN` 진행중 추가
- `memory/MEMORY.md` "알려진 이슈" 섹션에 한 줄 요약

### 4단계: 주인님 알림 (1일 1회 제한)
- 텔레그램: "🔑 외부 토큰 만료: Notion. 재발급 후 자동 재시도 큐 [N]개"
- fail-storm 방지를 위해 같은 ISS는 1일 1회만 알림

## 자동 복구 가능 / 불가 분류

| 케이스 | 자동 복구 | 예시 |
|--------|----------|------|
| 출력 파일 bloat | ✅ | Tistory 60→48 |
| secrets 파일 syntax 오류 | ✅ | `chmod 600` 자동 수정 |
| 외부 API 429 (transient) | ✅ | 재시도 + 백오프 |
| 외부 API 401 (만료) | ❌ | ISS-064 — 주인님 액션 |
| Workspace / 조직 변경 | ❌ | 외부 의존 |
| 시크릿 rotation 정책 변경 | ❌ | 조직 차원 |

## 후속 작업 (api-key-manager 강화)

`api-key-manager` 스킬에 다음 추가 필요:
- Notion / Telegram / YouTube / GitHub / OpenAI 등 외부 API 토큰의 **마지막 검증 일자** 추적
- 90일 추정 만료 7일 전 사전 경고
- `~/.hermes/secrets/notion_token.txt` 외 모든 토큰 파일 health check (현재는 healthcheck에서 일부만 검사)

`automation-healthcheck` (수동 헬스체크)에도 외부 토큰 health precheck 추가.

## 재발 방지 체크리스트

- [ ] 일요일심층 15:32 실행 시 Notion 토큰 health precheck (401면 즉시 중단 + 알림)
- [ ] weekly 잡 (일요일심층 / 주간학습로그 / 주간기술뉴스레터 / Agent Benchmark) 실행 전 토큰 검증
- [ ] 새 외부 API 통합 시 `api-key-manager` 등록 의무화
- [ ] `notion_w23_status.md` 같은 payload 보존 패턴을 모든 외부 API 의존 잡에 적용

## 관련

- `~/.hermes/memory/issues.md` "ISS-064" 항목
- `~/.hermes/memory/MEMORY.md` "알려진 이슈" 섹션 (ISS-064 한 줄)
- `~/.hermes/memory/reports/notion_w23_status.md` (6개 보존 payload)
- `~/.hermes/skills/automation/api-key-manager` (후속 강화 대상)
- `~/.hermes/skills/automation/automation-healthcheck` (수동 health precheck 추가)
