# 기존 CLI 인증을 이용한 시크릿 파일 복구

심야 정비에서 “토큰 파일 없음”이 탐지됐더라도 곧바로 사용자에게 새 토큰 발급을 요구하지 않는다. 먼저 공식 CLI의 OS keyring 인증이 이미 살아 있는지 확인하고, 살아 있다면 그 자격을 필요한 파일 형식으로 안전하게 물질화한다.

## 적용 조건

- 잡이 `~/.hermes/secrets/<service>_token.txt` 같은 파일을 요구한다.
- 해당 서비스의 공식 CLI는 이미 로그인돼 있다.
- 토큰을 새로 발급하지 않고 기존 인증을 재사용할 수 있다.

GitHub 예시:

```bash
gh auth status
```

인증이 정상일 때만 다음을 수행한다.

## 안전한 복구 절차

```bash
umask 077
mkdir -p ~/.hermes/secrets
gh auth token > ~/.hermes/secrets/github_token.txt
chmod 600 ~/.hermes/secrets/github_token.txt
```

1. **값 노출 금지:** 토큰 원문을 stdout이나 리포트에 출력하지 않는다.
2. **복사 일치 검증:** 원문 대신 SHA-256끼리 비교한다.
3. **권한 검증:** macOS에서는 `stat -f '%Lp'`, Linux에서는 `stat -c '%a'`를 사용해 `600`인지 확인한다.
4. **인증 검증:** API 요청에는 명시적인 Authorization 헤더를 넣는다.

```bash
TOK="$(tr -d '\r\n' < ~/.hermes/secrets/github_token.txt)"
curl -sS \
  -H "Authorization: Bearer $TOK" \
  -H 'Accept: application/vnd.github+json' \
  https://api.github.com/user
```

> `GITHUB_TOKEN=... curl ...`처럼 환경변수만 붙여도 일반 `curl`이 Authorization 헤더를 자동 생성해주지는 않는다. 검증 요청에는 `-H "Authorization: Bearer ..."`가 필수다.

## 완료 판정

다음 네 가지가 모두 통과해야 복구 완료로 기록한다.

- 공식 CLI 인증 정상
- CLI 토큰과 파일 토큰의 해시 일치
- 파일 권한 `600`
- 인증 API HTTP 200 및 예상 계정 일치

그 후 원래 탐지기를 **재실행**해 `missing_secret`/`missing_file`이 사라졌는지 확인한다. 최초 탐지 수치와 최종 재검증 수치를 분리해서 보고한다.

## 리포트 집계

- Self-Healer 자체의 `fixes_applied`가 0이어도, 에이전트가 위 절차로 실제 복구했다면 Notion의 `수리 항목 수`에는 **운영자 보조 수리 1건**으로 기록할 수 있다.
- 본문에는 `Self-Healer 자동 수리 0 / 운영자 보조 수리 1`처럼 출처를 구분한다.
- 같은 파일 부재가 `missing_secret`과 `missing_file`로 중복 감지돼도 실제 이슈 수는 1건이다.
