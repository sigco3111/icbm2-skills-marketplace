# 심야 점검 결과 노이즈 floor + 반복 알림 정책 (2026-07-07 학습)

07-07 03:30 KST 실측에서 깨달은 **알림 fatigue 방지 패턴**. 매일 4단계 파이프라인을 돌릴 때 같은 신호가 반복되는데, 매번 동일하게 "⚠️ 문제 발견"으로 보고하면 사용자 알림 fatigue가 누적된다. 이 문서는 어떤 신호가 진짜 알림 가치 있고 어떤 게 noise인지 분류한다.

## Noise floor — 매일 반복되지만 신규 가치 없음

### 1. Self-Healer output_error 7~10건 (FP 메타 트랩)

매일 점검 시 5~10건의 `output_error` 패턴 매치가 발생한다. 모두 Self-Healer FP 메타 트랩 시리즈 (ISS-068/069/077/082) — 자기 진단 본문 leak + 단어 매칭 false positive.

| 잡 | 패턴 | 07-06 | 07-07 | 빈도 |
|---|---|---|---|---|
| 5d0f14aef84c 일일리뷰 | FileNotFoundError | 1 | 1 | 매일 |
| 7c2b9a9be162 skills-marketplace-sync | FileNotFoundError | 1 | 1 | 매일 |
| b1bca63a117a Tistory 자동 발행 | TimeoutError | 1 | 1 | 매일 |
| d7bd4309bbf0 일요일 심층 점검 | TimeoutError | 1 | 1 | 매일 |
| ed5f37705e68 주간 학습 로그 | TimeoutError | 1 | 1 | 매일 |
| 7995f1387b79 주간 기술 뉴스레터 | TimeoutError | 1 | 1 | 매일 |
| 0b0e9f44e10a Tistory 세션 체크 | TimeoutError | 1 | 1 | 매일 |
| 5d0f14aef84c JSONDecodeError | JSONDecodeError | 1 | 0 | 가끔 |

**관찰된 변동 (07-06 → 07-07)**: JSONDecodeError 1건은 07-07에 사라졌고 FileNotFoundError 일일리뷰는 1→2 변동. 즉 **에러 카테고리 구성은 매일 미세하게 흔들리는 노이즈**. 절대 추세로 해석하지 말 것.

**보고 정책**: 7건 모두 FP로 1줄 처리 (`모두 FP 메타 트랩, 활성 에러 0`). 새 잡이 추가되거나 error count가 +5 이상 jump할 때만 상세 보고.

### 2. Warning 4건 = 항상 같은 4개 주1회 잡

cron_error_monitor의 warning은 매일 정확히 같은 4개 잡:
- d7bd4309bbf0 📋 일요일 심층 점검 (36h stale, 7일 1회)
- ed5f37705e68 📖 주간 학습 로그 (31.4h, 7일 1회)
- 7995f1387b79 📰 주간 기술 뉴스레터 (35.5h, 7일 1회)
- 582ecc59aaee 📊 Agent Benchmark Tracker (41.4h, 7일 1회)

모두 주 1회 스케줄 잡. **stale 시간 30~40h는 다음 주간 실행 직전의 정상 노이즈**.

**보고 정책**: warning은 1줄로 압축 ("warning 4건: 모두 주1회 잡 다음 실행 대기"). 별도 결정 권고 불필요.

### 3. memory_error_tracker의 1건짜리 단발성 new_issue

07-06 `Notion Idea (DEAD) 1`, 07-07 `News-to-Wiki 1` — 매번 다른 카테고리에서 1건씩 등장. 1건짜리 단발성은 보통:
- 비활성화된 워크플로의 stale 로그 (Notion Idea DEAD)
- 이전에 ✅ 해결된 카테고리의 동일 잡 패턴 재출현 (News-to-Wiki = ISS-083 동일 패턴)

**보고 정책**: 1건짜리 단발성 new_issue는 별도 ISS-NNN 등록하지 말 것. **누적 3일 연속 같은 카테고리에서 등장**할 때만 신규 ISS 검토. 그 외는 `new_issues: {X: 1}` 한 줄 + "FP 가능성" 주석으로 처리.

## 진짜 알림 가치 있는 신호 (에스컬레이션)

### 1. CRITICAL ≥ 1건

`critical` 또는 `recoverable` 카운트가 1 이상이면 **즉시 ⚠️ 문제 발견** 보고. 07-06/07-07 모두 0건 — 안정 상태.

### 2. 동일 ISS의 결정 지연 ≥ 5일

ISS-086 (skills-marketplace-sync), ISS-087 (HTTP 429 Token Plan) 같은 "사용자 결정 필요" 이슈가 매일 점검에서 반복 등장. **결정 지연 일수를 누적 카운트**해서:

| 지연 일수 | 보고 수준 |
|---|---|
| 1~3일 | 일반 ⚠️ 문제 발견, 결정 권고 |
| 4~6일 | ⚠️ 결정 지연 N일 — 결정 시급 |
| 7일 이상 | 🔴 결정 지연 7일+ — 텔레그램/디스코드 푸시 검토 |

07-07 시점: ISS-086 (11일째), ISS-087 (5일째). 둘 다 결정 임계 초과.

**보고 정책**: 7일 이상 결정 지연은 일반 cron 출력 채널 외에 별도 즉시 알림 (텔레그램/디스코드) 발송 권장. ICBM2 사용자 승인 후 자동화 가능.

### 3. Self-Healer가 fixes_applied > 0

자가치유가 실제로 무언가를 고친 경우 (예: 파일 권한 복구, 디스크 정리). 07-06/07-07 모두 0건 — 정상 운영 중.

### 4. memory_error_tracker의 needs_memory_update=true + 누적 3일

매일 `needs_memory_update: true`이지만 단발성은 무시. **3일 연속 같은 신호**면 memory 파일 자체에 갱신 필요 — 새 ISS 등록 검토.

## Notion 기록 상태 값 선택 가이드

07-06 "⚠️ 문제 발견" 사용, 07-07도 "⚠️ 문제 발견" 사용. select 옵션 16개 중 실제 사용 가치 있는 4개:

| 상태 | 사용 시점 |
|---|---|
| `✅ 정상` | 1단계 19/19 ok + 2단계 fixes > 0 + 3단계 new_issues 0 + 4단계 모두 통과 |
| `일부 이슈` | warning 1~3건 + FP 메타 트랩만 + 결정 지연 0건 |
| `⚠️ 문제 발견` | warning 4건+ 또는 결정 지연 1건+ 또는 new_issue 3일+ 연속 |
| `오류 발견` | critical ≥ 1 또는 fixes_applied > 0 또는 누적 5일+ 결정 지연 |

07-07: 결정 지연 ISS-086(11일)/ISS-087(5일) 2건 → **⚠️ 문제 발견** 정확.

## 보고서 압축 가이드

매 점검 보고서가 너무 길어지지 않도록:

1. **요약 1~2줄**: ok/warning/critical 카운트 + 핵심 발견 1개
2. **상세 표 1개**: 잡 이름 / 상태 / detail
3. **결정 지연 누적**: ISS-NNN 목록만 (있을 때만)
4. **권장 작업**: 우선순위 순 1~3개 (있을 때만)
5. **동기화 완료**: file + Notion page_id

07-07 보고서는 이 가이드 적용 결과 약 1500자로 압축. 사용자가 읽고 30초 안에 상황 파악 가능한 길이.

## 변경 이력

- **2026-07-07**: noise floor (Self-Healer FP / Warning 4건 / 단발성 new_issue) + 에스컬레이션 정책 + Notion 상태 선택 가이드 + 보고서 압축 가이드 추가 (page_id `39576f2e-9097-810d-bca8-c506144503c9` 실측 기반)