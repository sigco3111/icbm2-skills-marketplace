---
description: 2026-07-17 심야 통합 정비 실측 사례 — Notion 기록 성공, 19잡 모니터 정상/주간 경고 4건, Self-Healer 7 errors·1 warning·0 fixes, 72시간 메모리 스캔 59개.
---

# 2026-07-17 심야 통합 정비 실측 사례

## 결과 한 줄

**19잡 모니터: 15 ok / 4 warning / 0 critical / 0 recoverable. Self-Healer: 20잡 중 13 healthy / 7 errors / 1 warning / 0 fixes. Memory tracker: 59개, 신규·해결 이슈 0. Notion POST와 GET read-back 모두 성공.**

## 1. 에러 모니터링

실행:

```bash
python3 ~/.hermes/scripts/cron_error_monitor.py
```

실측 결과:

- 19개 잡 중 15개 정상, 4개 warning, critical 0, recoverable 0
- warning은 일요일 심층 점검, 주간 학습 로그, 주간 기술 요약 뉴스레터, Agent Benchmark Tracker의 주간 주기 지연
- `alerts`와 `recovery_actions`는 빈 배열

## 2. Self-Healer 교차 판정

실행:

```bash
python3 ~/.hermes/scripts/cron_self_healer.py
```

실측 결과:

- 20개 잡 검사: 13 healthy / 7 errors / 1 warning / 0 fixes
- 실제 확인이 필요한 항목: `~/.hermes/secrets/github_token.txt` 부재. 같은 원인이 `missing_secret`와 `missing_file`로 중복 보고됨
- APIError/FileNotFoundError/TimeoutError 출력 패턴 감지는 있었으나, 해당 잡들의 `jobs.json` 상태는 정상. 자기진단 문서·출력 인용에 의한 기존 오탐 판정 절차를 우선 적용
- `notion-outage-watch-3h`의 disabled는 의도된 비활성 상태
- 리포트는 `~/.hermes/memory/self_heal_2026-07-17.md`에 저장됨

**판정 원칙:** Self-Healer의 감지 건수를 그대로 실제 장애 수로 기록하지 않는다. `cron_error_monitor` 결과, `jobs.json`의 `last_status`/`consecutive_failures`, 실제 출력 라인을 교차 확인한다. 시크릿 파일 부재처럼 파일 시스템 상태로 직접 확인되는 항목은 오탐으로 내리지 않는다.

## 3. 메모리 에러 동기화

실행:

```bash
python3 ~/.hermes/scripts/memory_error_tracker.py
```

- 최근 72시간 에러 파일 59개
- Other 40 / RSS Feeds 9 / NotebookLM 6 / YouTube 2 / Cron Timeout 2
- `new_issues: {}`, `resolved_issues: {}`, `needs_memory_update: false`
- 신규 ISS-NNN을 추가하거나 해결 이슈를 갱신하지 않음

## 4. Notion 기록 패턴

정비 리포트 DB(`33c76f2e-9097-8198-bd1b-c3ea3cfbbae8`)에 기록하기 전에 매번 DB schema GET으로 실제 속성명·타입·select/multi_select 옵션을 확인한다.

이번 회차에서 사용한 안정적인 순서:

1. `/tmp/notion_payload_YYYY-MM-DD.json`에 **JSON payload만** 저장한다.
2. `/tmp/post_notion_YYYY-MM-DD.py`에 POST 코드만 저장한다. 토큰은 `Path.home() / '.hermes/secrets/notion_token.txt'`에서 런타임에 읽는다.
3. Python 파일을 저장한 뒤 먼저 syntax check가 통과했는지 확인한다.
4. POST 실행 결과에서 HTTP 200, `object=page`, page `id`를 확인한다.
5. `/v1/pages/{page_id}` GET으로 `archived=false`와 핵심 속성(제목, 날짜, 상태, 에러 수, 수리 항목 수, 요약)을 read-back 검증한다.
6. payload/POST/응답 임시 파일은 검증 후 정리한다.

### 재발 방지: Python 파일과 셸 호출 분리

이번 회차의 첫 POST 스크립트 작성 시 Python 소스 뒤에 `PY`, `chmod`, 실행 명령이 섞여 syntax error가 발생했다. **`write_file`의 `content`에는 해당 파일의 소스만 넣고, `chmod`·실행은 별도의 terminal 단계에서 수행한다.** 파일 작성 응답의 lint가 실패하면 실행하지 말고 파일을 완전히 다시 작성한다.

검증된 결과:

- HTTP 200
- `object: page`
- page id: `39f76f2e-9097-8196-bde2-f29b043e3d6b`
- read-back `archived: false`
- 상태: `일부 이슈`
- 에러 수: 7
- 수리 항목 수: 0

## 운영 결론

critical은 없었지만 GitHub 토큰 파일 부재는 사용자 결정/복구가 필요한 지속 항목이다. 주간 잡 warning은 주기성 지연으로 분리 보고한다. Notion 기록은 POST 성공만으로 완료 처리하지 말고 반드시 page GET read-back까지 수행한다.
