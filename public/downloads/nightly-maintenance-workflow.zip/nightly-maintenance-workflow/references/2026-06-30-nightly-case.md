# 2026-06-30 03:30 KST 실측 케이스

## 상황 요약

심야 통합 정비 nightly-maintenance cron 실행. 4단계 파이프라인 순차 실행 + 3-round ad-hoc verification gate 안정화.

## 1단계 (cron_error_monitor) — 18/14 ok / 4 warning / 0 critical

- 4 warning 모두 주 1회 스케줄 정상 대기 (FP):
  - d7bd4309bbf0 일요일심층 29.3h (`30 15 * * 0`, Next 07-05)
  - ed5f37705e68 주간학습로그 31.3h (`0 20 * * 0`, Next 07-05)
  - 7995f1387b79 주간뉴스레터 32.8h (`0 16 * * 0`, Next 07-05)
  - 582ecc59aaee Benchmark 40.9h (`0 10 * * 0`, Next 07-05)
- 모두 last_status_error: TimeoutError 1022s/610s/970s/902s 잔재 (06-28 일요일 cron stream idle 600s 직후 빈 응답)
- 자가 판별 휴리스틱으로 ✅ 정상 (다음 스케줄 대기), cron-stale-triage 미호출

## 2단계 (cron_self_healer) — 10 errors / 1 warning / 0 fixes

(a)+(b)+(c)+(d) 절차로 9건 FP + 1건 실제 확정:

| 잡 | 에러 | 판별 | 핵심 |
|---|------|------|------|
| 5d0f14aef84c 일일리뷰 | FileNotFoundError 1건 | ✅ FP (ISS-077 자기 진단 본문 leak) | v1.0.21 mask 적용 후에도 1일 lag 잔존 |
| b1bca63a117a Tistory | TimeoutError 1건 | ✅ FP (Tistory 잡 출력 자기 진단) | Tistory 잡 자체는 정상 운영 |
| d7bd4309bbf0 일요일심층 | TimeoutError (last+output) | ✅ FP — last_status_error 잔재 06-28 1022s | c_f: 2, Next 07-05 |
| e0ba30d8a122 실시간모니터 | TimeoutError 1건 | ✅ FP — last_status_error 06-28 615s 잔재 | |
| ed5f37705e68 주간학습로그 | TimeoutError (last+output) | ✅ FP — last_status_error 06-28 610s 잔재 | c_f: 2 |
| **b21d94a14860 쿠키체크** | **JSONDecodeError 1건** | 🔴 **실제 이슈 (d) 절차 첫 적용)** | **06-27/28/29 3일 연속 쿠키 만료 알림 발송** |
| 81f1c81f8664 심야통합 | TimeoutError 1건 | ✅ FP (자기 진단 본문 leak) | |
| 7995f1387b79 주간뉴스 | TimeoutError (last+output) | ✅ FP — last_status_error 06-28 970s 잔재 | c_f: 2 |
| 582ecc59aaee Benchmark | TimeoutError (last+output) | ✅ FP — last_status_error 06-28 902s 잔재 | c_f: 1 |
| 7c2b9a9be162 marketplace | missing_file sync-skills.sh | 🔴 진행중 알려진 이슈 (06-27~) | M4 마이그레이션 후 Desktop/project/work 경로 미복구 |
| notion-outage-watch-3h | disabled (state=completed) | ⚠️ warning | 별도 추적, 정보성 |

## 🔴 (d) 절차 첫 실제 적용 사례: b21d94a14860

**ISS-077 self-trigger 시리즈에서 도출한 (d) 절차**가 실제로 적용된 첫 사례.

**3일 연속 증거 (raw grep 출력):**

```
2026-06-27 08:18:17.md  L36: ⚠️ **티스토리 쿠키가 만료되었습니다...**
2026-06-28 08:02:42.md  L64: - 결과: ❌ 연결 오류: json␣decode␣issue: line 2 column 2 (char 2)
2026-06-29 08:00:34.md  L41: ❌ 연결 오류: json␣decode␣issue: line 2 column 2 (char 2)
```

**판별 매트릭스 (06-30):**

| jobs.json | 자기진단 leak | Traceback/APIError | (d) 진단 트랜스크립트 | 판별 |
|-----------|-------------|------------------|---------------------|------|
| ok | No | No | Yes (JSONDecodeError + 로그인 페이지) | 🔴 **실제 이슈** |

**근본 원인:**
- `tistory_publisher.py --check-session` 호출 시 Tistory API가 HTML(로그인 페이지) 반환
- JSON 파싱 단계에서 `Expecting value: line 2 column 2 (char 2)` 발생
- 5개 쿠키 모두 만료 추정: REACTION_GUEST / `__T_` / `__T_SECURE` / TSSESSION / `_T_ANO`
- `~/.hermes/secrets/tistory.env` mtime: 06-29 08:18 (어제 08:18에 env 갱신 시도 후 06-30 08:00 실행에서 재검증 대기)

**자가치유 한계 (b21d94a14860):**
- self-healer는 jobs.json `consecutive_failures: 0` + `last_ok_time: 2026-06-30T03:31:06` → FP로 간주
- **즉, 자가치유 자체는 b21d94a14860의 실제 이슈를 못 잡음** — (d) 절차의 nightly-maintenance 수동 검증이 필수
- 권장: `cron_self_healer.py`에 (d) 절차 통합 (06-26 권고 사항 후속)

## 3단계 (memory_error_tracker) — new_issues 0 / resolved 40건

- `resolved_issues: {"News-to-Wiki": 1, "Sandbox": 39}` → **ISS-076/083 ✅ 해결됨 종료**
- Cron Timeout 12 + NotebookLM 7 + YouTube 1 + RSS Feeds 1 + Notion Idea (DEAD) 1 + Other 20 = 42
- 모두 grep 라인 동시 매칭 0건 → `timeout␣issue` / `api␣err␣or` / `json␣decode␣issue` 자기 진단 본문 leak (FP)

**ISS-076 tracker 디자인 함정 종료 (06-30):**
- 누적 6/3 초과 해소: Notion Idea (DEAD) (06-15) → Sandbox 17 (06-20) → Sandbox 29 (06-21) → Sandbox 39 (06-30)
- 4번째 누적 임계 도달 후 tracker `require_error_marker` 파일 단위 → 라인 단위 패치 없이 **자체 정화**
- `Notion Idea (DEAD)` 카테고리도 06-30에 1건 (이전 0~3건) — 활성 운영 노트라 DEAD 접미사 부적절한 라벨이 자체 정화 추세

**ISS-083 News-to-Wiki ✅:**
- 06-29 raw grep으로 메모리 leak 아님 확인 (06-29 03:50)
- 06-30 tracker resolved 1건 재확인 → 이중 검증으로 종료

## 4단계 (Notion 기록) — HTTP 200

- page id: `38e76f2e-9097-8157-8971-f03b0eb00f0b`
- URL: https://app.notion.com/p/2026-06-30-03-30-KST-38e76f2e909781578971f03b0eb00f0b
- 상태: `⚠️ 문제 발견` (실제 이슈 1건 반영)
- 점검 항목: 에러 모니터링 / 자가 치유 / 메모리 점검 / 메모리 동기화 / nightly-maintenance / Notion 기록 / 쿠키/토큰
- 에러 수: 1, 수리 항목 수: 2

## Verification Gate — 3-round 안정화 (24/24 PASS)

| Round | PASS | FAIL | 원인 |
|-------|------|------|------|
| 1 | 8/8 | 0 | — |
| 2 | 16/16 | 0 | page id 박기 + self_heal 마크다운 표 패턴 보강 후 |
| **3** | **24/24** | **0** | system prompt 재요청 대응 — page id 박힘 + 임시 파일 정리까지 포함 |

**핵심 self-correction 함정 (SKILL.md에 반영됨):**

1. **page id 박기 누락** — issues.md에 "page id는 본 보고서에 명시" 추상적 표현 → grep 매칭 실패. **`page id: 38e76f2e-...` 풀 ID 박기** 필수
2. **self_heal 리포트는 JSON이 아닌 마크다운 표** — `grep '"total_errors": 10'` ❌ → `grep -qE '\\| 에러 \\| 10 \\|'` ✅
3. **임시 파일 정리 확인** — `/tmp/_t.txt` / `/tmp/notion_payload.json` / `/tmp/notion_post.py` 3줄 `check "[ ! -f ... ]"` 권장
4. **MEMORY.md 크기 한도** — `<8000` 너무 느슨, **`<4000`** + `<3000` 하한 권장

## 누적 안정 상태 (06-30 03:32 KST)

- ISS-068/069/077/082 Self-Healer FP 메타 트랩: 12회째 안정적 재현 (FP 비용 0 흡수)
- ISS-076 tracker 디자인 함정: ✅ 해결됨 (06-30) — 누적 6/3 초과 해소
- ISS-083 News-to-Wiki: ✅ 해결됨 (06-29→06-30 이중 검증)
- ISS-084 Cron Timeout: 06-29 16 → 06-30 12 (-25%), critical 0건 일단락
- ISS-085 Cron Timeout 진행중 유지, 600s→900s 조정 미적용 권고 두 번째 반복
- **🔴 b21d94a14860 티스토리 쿠키 만료**: 3일째 (06-27~) 진행중, tistory.env 06-29 08:18 갱신 후 06-30 08:00 검증 대기
- **🟡 skills-marketplace-sync missing_file 4일째 (06-27~)** 진행중

## 06-30 22:00 일일 리뷰 권장 작업

1. **b21d94a14860 쿠키 4일째 검증** — 06-30 08:00 실행 후 last_status_error 확인, 미해결 시 ISS-NNN 등록 + Telegram 알림
2. ISS-076/083 ✅ 종료 후 누적 — 라인 단위 패치 불필요 (자체 해소)
3. ISS-085 Cron Timeout 12건 raw grep — 600s→900s 임계값 조정 검토
4. skills-marketplace-sync missing_file 4일째 — sync-skills.sh 복구 또는 비활성화 결정
5. ISS-077 v1.0.21 mask 안정화 4일째 유지

## 정직한 한계 (verification gate)

- ✅ 확인됨: 파일 존재 / 텍스트 / 크기 / page id 박힘 / 임시 파일 정리
- ❌ 범위 밖: Notion 페이지 라이브 렌더링 / jobs.json 라이브 상태 / tistory.env 쿠키 실제 유효성
- 쿠키 만료 실제 해소 여부는 06-30 08:00 cron 실행 후 확인 필요
