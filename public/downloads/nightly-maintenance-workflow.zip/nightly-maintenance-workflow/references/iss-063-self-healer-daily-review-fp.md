# ISS-063: Self-Healer FP 1건 재발 (2026-06-07)

## 한 줄 요약

`5d0f14aef84c 일일 자기 개선 리뷰`의 어제(2026-06-06 22:07) 출력 파일이 자기 진단 보고서 본문에서 `api error`, `rate limit`, `out of memory` 같은 단어를 인용 → ISS-062 4차 patch의 informational 마커 13개로도 커버 안 됨. 진짜 해결: `daily-self-review` SKILL.md v1.0.8에서 `mask_self_healer_terms()` 출력 파이프라인 자동 통합.

## 발생 시나리오 (재현)

1. 22:00 daily-self-review 크론 실행
2. 일일 리뷰 출력이 자기 진단 보고서(어제 ISS 해결 내역)를 본문에 인용하며 `apierror`, `api error`, `rate limit` 같은 단어를 그대로 작성
3. 03:30 다음날 심야 정비 2단계 self-healer가 cron/output에서 regex 매칭 → 1건 FP
4. verify_self_healer_patch.py: 4 jobs 중 1 FAIL

## 실제 grep 결과 (2026-06-07 03:30 KST)

파일: `/Users/hjshin/.hermes/cron/output/5d0f14aef84c/2026-06-06_22-07-21.md`

매칭 라인 (일부):
```
123:  - **공통 효과**: doc reference나 파일 경로에 포함된 `api error`, `401`, `out of memory` 같은 substring은 더 이상 매칭하지 않음
124:  ### ⚠️ Meta-output self-trigger pitfall (ISS-058 잔존 문제)**: 일일 리뷰 본문에서 `apierror` 같은 디버그 단어를 인용하면 self-healer가 다음 실행 시 이를 다시 매칭함
132:  | `api error` / `apierror` | `api␣err␣or` |
133:  | `api failed` | `api␣failed` |
134:  | `rate limit` | `rate␣limit` |
158:  **⚠️ v1.0.7 가드는 향후 패치입니다** — ... `api error`, `rate limit`, `out of memory`, `401`~`503` 표현이 나오면 마스킹 후 저장.
168:    - 일일 리뷰 본문이 `apierror` 단어를 인용한 경우 → 다음 날 self-healer가 매칭 (메타 트랩, 미해결)
```

## 왜 4차 patch(ISS-062)로 못 잡았나

ISS-062의 4가지 변경:
1. 부분 마커 → 마커 확장 (`\b(?:api[\s._-]*(?:error|failed)`)
2. 메타 라인 통째 drop
3. line-by-line 검사
4. **informational 마커 13개 추가** — `notion api`, `api rate`, `rate limit`, `공통 효과`, `doc reference`, `substring은 더 이상`, `오탐 대표`, `false positive`, `memory error`, `out of memory` 등

한계:
- 마커 1개가 라인에 있어도 **인접 라인**의 같은 단어(`api error` vs `api error`, 별도 라인)는 매칭됨
- 4차 patch는 SKILL.md/reference 문서 자기 인용을 잡지만, **운영 출력(daily 리포트 본문)이 자기 진단 단어를 인용**하는 케이스는 잡지 못함
- 라인 drop은 informational 마커 1개가 있는 라인만 drop — 같은 단어가 다른 라인에 있으면 그 라인은 살아남음

## ISS-058/059/062와 무엇이 다른가

| ISS | FP 경로 | 원인 | 해결 |
|-----|---------|------|------|
| ISS-058 | SKILL.md 본문 regex 리터럴 인용 | 자기 진단 텍스트가 SKILL.md에 박혀있음 | 1차 부분 마커 |
| ISS-059 | `last_status_error` 본문 길이 | monitor의 빈출력 카운트 오인 | monitor 로직 |
| ISS-062 | reference 문서 / 운영 가이드의 regex 인용 | informational 텍스트 단어 | 4차 patch (마커 13개) |
| **ISS-063** | **daily-self-review 출력 본문** | **자기 진단 단어를 본문에 인용** | **daily-self-review v1.0.8 마스킹** |

## 진단 절차 (verify FAIL 시)

```bash
# 1. verify 실행
python3 ~/.hermes/skills/automation/nightly-maintenance-workflow/scripts/verify_self_healer_patch.py

# 2. FAIL 잡 ID 확인 (예: 5d0f14aef84c)
# 3. 어제(전날) 일일 리뷰 출력 파일 찾기
ls -lt /Users/hjshin/.hermes/cron/output/5d0f14aef84c/ | head -5

# 4. 매칭 라인 직접 확인
grep -nE "api[ _.-]*(error|failed)|rate[ _]*limit" /Users/hjshin/.hermes/cron/output/5d0f14aef84c/2026-06-06_22-*.md

# 5. 라인이 자기 진단 보고서 본문인지 확인 (공통 효과, doc reference, false positive, meta-output 같은 키워드)
```

## 조치

**즉시:**
- ISS-NNN 등록 (트래킹 가치) — `issues.md`에 `ISS-063` 추가
- MEMORY.md `알려진 이슈`에 🟡 항목 추가
- self-healer 5차 patch **하지 말 것** — 마커 추가는 정상 운영 텍스트를 막을 위험

**장기 (자동 해결):**
- `daily-self-review` SKILL.md v1.0.8 — `mask_self_healer_terms()`를 일일 리뷰 출력 파이프라인에 자동 통합
- 현재 v1.0.7은 SKILL.md에 문서화만, 실제 적용은 v1.0.8 (희정님 패치 대기)

**모니터링:**
- verify FAIL = 1건 (5d0f14aef84c만) → 허용, v1.0.8 대기
- verify FAIL = 2건 이상 → v1.0.8 미적용 의심, 즉시 조사
- verify FAIL = 0건 → ISS-062 + v1.0.8 정상 동작 확인

## 핵심 교훈

**양방향 의존성에서 출력 측 마스킹이 정답이다:**

```
cron_self_healer.py (입력 측) ← daily-self-review 출력 (출력 측)
        │                                  │
        └──── ISS-062 4차 patch ──────────→│
                                           │
                              v1.0.8 mask_self_healer_terms()
                              (출력 직전 마스킹)
```

- 입력 측(self-healer)에서 strip 시도: 자기 진단 텍스트 → informational 마커 추가 → 운영 텍스트가 마커로 오염되는 무한 루프
- 출력 측(daily-self-review)에서 마스킹: 본문 작성 완료 → 저장/전송 직전 마스킹 → 다음날 self-healer가 깨끗한 파일 검사

**확장 규칙 (모든 자기 진단 보고서를 출력하는 크론에 적용):**
- 일일 리포트, 주간 리포트, monthly 리포트 등 자기 진단 텍스트를 본문에 인용하는 모든 출력은 `mask_self_healer_terms()` 적용 대상
- 단순한 단어 치환 (예: `api error` → `ap!_err_or`)도 가능, 단 매칭 패턴이 길어지면 마스킹 키도 추가 필요

## 검증 one-liner

```bash
# 5d0f14aef84c의 어제 22시 일일 리뷰가 자기 진단 단어 인용하는지
ls -lt /Users/hjshin/.hermes/cron/output/5d0f14aef84c/*.md | head -3 | \
  awk '{print $NF}' | \
  xargs -I {} grep -lE "doc reference|공통 효과|false positive|out of memory" {}
```
