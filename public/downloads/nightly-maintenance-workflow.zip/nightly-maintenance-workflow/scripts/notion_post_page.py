#!/usr/bin/env python3
"""Notion page creator — POSTs /v1/pages with payload from /tmp/notion_payload.json.

Used by nightly-maintenance-workflow 4단계 (Notion 정비 리포트 기록).
Token read at runtime from ~/.hermes/secrets/notion_token.txt — no
Bearer literal in this file (ISS-061 회귀 방지).

Usage:
    python3 notion_post_page.py /tmp/notion_payload.json
"""
import json
import sys
import urllib.error
import urllib.request
from pathlib import Path


def main(payload_path: str) -> int:
    token_path = Path.home() / ".hermes/secrets/notion_token.txt"
    token = token_path.read_text().strip()
    body = Path(payload_path).read_bytes()

    req = urllib.request.Request(
        "https://api.notion.com/v1/pages",
        data=body,
        headers={
            "Authorization": "Bearer " + token,
            "Notion-Version": "2022-06-28",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            d = json.loads(r.read().decode())
            print("OK")
            print("id:", d.get("id"))
            print("url:", d.get("url"))
            return 0
    except urllib.error.HTTPError as e:
        print(f"HTTP {e.code}: {e.reason}", file=sys.stderr)
        print(e.read().decode()[:1000], file=sys.stderr)
        return 1
    except Exception as e:
        print(f"ERR: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: notion_post_page.py <payload.json>", file=sys.stderr)
        sys.exit(2)
    sys.exit(main(sys.argv[1]))
