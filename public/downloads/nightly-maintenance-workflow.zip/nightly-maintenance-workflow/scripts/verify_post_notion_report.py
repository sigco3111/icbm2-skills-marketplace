#!/usr/bin/env python3
"""
Ad-hoc verifier for ICBM2 nightly-maintenance-workflow 4단계 Notion POST.
Reference: nightly-maintenance-workflow SKILL.md "🆕 4단계 Notion POST를
verification에서 재실행하지 마라 — exec() 트릭 (2026-07-04)"

Usage:
  python3 scripts/verify_post_notion_report.py <path/to/post_notion_report_YYYYMMDD.py>

Validates the *payload* that would be POSTed to the Maint DB without actually
POSTing (which would create a duplicate page in the Maint DB). Uses exec() to
load the script's namespace up to the urllib POST call, then introspects
payload / TITLE / DATE.

Checks (14 typical):
  1. Script compiles
  2. DATE constant matches YYYY-MM-DD (auto-detected or --date override)
  3. TITLE contains "03:30" + "KST"
  4. parent.database_id == Maint DB ID
  5. 5 properties present (이름 / 날짜 / 상태 / 에러 수 / 요약)
  6. 상태 is a valid select option
  7. 에러 수 is integer >= 0
  8. Payload JSON-serializable
  9. All 4 step sections (1/2/3/4단계) present in children

Optional (--with-mem) also checks memory/issues.md / MEMORY.md for date
and ISS-* references.
"""
import argparse
import json
import re
import sys
from pathlib import Path

# Maint DB — single source of truth (SKILL.md)
MAINT_DB_ID = "33c76f2e-9097-8198-bd1b-c3ea3cfbbae8"
REQUIRED_PROPS = ("이름", "날짜", "상태", "에러 수", "요약")
REQUIRED_SECTIONS = ("1단계", "2단계", "3단계", "4단계")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("script", type=Path, help="path to post_notion_report_YYYYMMDD.py")
    ap.add_argument("--date", help="expected YYYY-MM-DD (auto-detected from script)")
    ap.add_argument("--with-mem", action="store_true", help="also verify memory files")
    args = ap.parse_args()

    if not args.script.exists():
        print(f"FAIL: script not found: {args.script}")
        return 1

    # ---- 1. Compile ----
    try:
        compile(args.script.read_text(encoding="utf-8"), str(args.script), "exec")
    except SyntaxError as e:
        print(f"FAIL: script syntax error: {e}")
        return 1
    print("PASS  script compiles")

    # ---- 2. exec() the namespace up to POST ----
    py = args.script.read_text(encoding="utf-8")
    cut = py.find("data = json.dumps(payload")
    if cut < 0:
        print("FAIL: cannot find payload-construction cutoff in script")
        return 1
    ns: dict = {}
    try:
        exec(py[:cut], ns)
    except Exception as e:
        print(f"FAIL: exec() failed: {e}")
        return 1

    payload = ns.get("payload")
    title = ns.get("TITLE")
    date = ns.get("DATE")
    if not (payload and title and date):
        print("FAIL: payload/TITLE/DATE not in namespace")
        return 1

    expected_date = args.date or date
    results = []

    # ---- 3. Structural checks ----
    results.append(("DATE matches", date == expected_date, f"got: {date}"))
    results.append((
        "TITLE has 03:30+KST",
        "03:30" in title and "KST" in title,
        f"got: {title[:80]}",
    ))
    results.append((
        "parent.database_id == Maint",
        payload["parent"]["database_id"] == MAINT_DB_ID,
        payload["parent"]["database_id"],
    ))
    props = payload["properties"]
    for k in REQUIRED_PROPS:
        results.append((f"property '{k}' present", k in props, ""))
    status = props.get("상태", {}).get("select", {}).get("name", "")
    results.append(("상태 select non-empty", bool(status), f"got: {status}"))
    err_count = props.get("에러 수", {}).get("number", -1)
    results.append((
        "에러 수 is int >= 0",
        isinstance(err_count, int) and err_count >= 0,
        f"got: {err_count}",
    ))
    try:
        json.dumps(payload, ensure_ascii=False)
        results.append(("payload JSON-serializable", True, ""))
    except (TypeError, ValueError) as e:
        results.append(("payload JSON-serializable", False, str(e)))
    section_titles = [
        b["heading_2"]["rich_text"][0]["text"]["content"]
        for b in payload["children"]
        if b.get("type") == "heading_2"
    ]
    missing = [s for s in REQUIRED_SECTIONS if not any(s in t for t in section_titles)]
    results.append((
        "4 sections in children",
        not missing,
        f"missing={missing} found={section_titles}",
    ))

    # ---- 4. Optional memory files ----
    if args.with_mem:
        mem = Path("/Users/mac/.hermes/memory/MEMORY.md")
        if mem.exists():
            t = mem.read_text(encoding="utf-8")
            results.append((
                "MEMORY.md header has expected date",
                f"# ICBM2 Memory — {expected_date}" in t,
                "header not found",
            ))

    # ---- Print ----
    all_ok = True
    for label, ok, detail in results:
        mark = "PASS" if ok else "FAIL"
        print(f"  [{mark}] {label}: {detail}")
        if not ok:
            all_ok = False
    print()
    print("=" * 60)
    passed = sum(1 for _, o, _ in results if o)
    print(f"OVERALL: {'PASS' if all_ok else 'FAIL'}  ({passed}/{len(results)})")
    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())
