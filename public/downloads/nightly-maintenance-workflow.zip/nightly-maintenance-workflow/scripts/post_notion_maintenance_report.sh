#!/usr/bin/env bash
# post_notion_maintenance_report.sh
# 4단계: ICBM2 심야 정비 리포트를 Notion Maintenance DB에 기록 (cron 모드 호환)
#
# 사용법:
#   ./post_notion_maintenance_report.sh <YYYY-MM-DD> "<요약 한 줄>" <수리 항목 수> \
#       "점검항목1|점검항목2|..."
#
# 점검 항목 옵션 (2026-06-04 기준): 에러 모니터링, 자가치유, 메모리 점검, Notion 기록,
#   Error Monitor, Self-Healer, 스크립트 무결성, API 연결 등
#
# 동작:
#   1) Maintenance DB 스키마 조회 (--silent) → property 이름 검증
#   2) 페이로드 JSON을 /tmp/notion_payload.json에 작성
#   3) curl POST → /tmp/notion_resp.json
#   4) 결과 PAGE_ID/URL 출력
#
# 의존성: curl, python3, ~/.hermes/secrets/notion_token.txt
# 검증: 2026-06-04 cron 모드에서 execute_code가 BLOCKED되어 fallback으로 확립됨

set -euo pipefail

DATE="${1:-$(date +%Y-%m-%d)}"
SUMMARY="${2:-점검 완료}"
FIX_COUNT="${3:-0}"
ITEMS_RAW="${4:-에러 모니터링|자가치유|메모리 점검|Notion 기록}"

TOKEN_FILE="$HOME/.hermes/secrets/notion_token.txt"
DB_ID="33c76f2e-9097-8198-bd1b-c3ea3cfbbae8"
PAYLOAD="/tmp/notion_payload_$$"
RESP="/tmp/notion_resp_$$"

if [[ ! -f "$TOKEN_FILE" ]]; then
  echo "ERROR: $TOKEN_FILE 없음" >&2
  exit 2
fi
TOKEN=$(cat "$TOKEN_FILE")

# 점검 항목 multi_select JSON 배열로 변환
ITEMS_JSON=$(python3 -c "
items = '$ITEMS_RAW'.split('|')
import json
print(json.dumps([{'name': x.strip()} for x in items if x.strip()], ensure_ascii=False))
")

# 페이로드 작성 (title 프로퍼티 없음 — 2026-06-04 확인)
cat > "$PAYLOAD" <<EOF
{
  "parent": {"database_id": "$DB_ID"},
  "properties": {
    "날짜": {"date": {"start": "${DATE}T03:30:00+09:00"}},
    "수리 항목 수": {"number": ${FIX_COUNT}},
    "요약": {"rich_text": [{"type": "text", "text": {"content": $(python3 -c "import json,sys; print(json.dumps(sys.argv[1]))" "$SUMMARY")}}]},
    "점검 항목": {"multi_select": ${ITEMS_JSON}}
  }
}
EOF

# POST
HTTP_CODE=$(curl -s -o "$RESP" -w "%{http_code}" -X POST "https://api.notion.com/v1/pages" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Notion-Version: 2022-06-28" \
  -H "Content-Type: application/json" \
  -d @"$PAYLOAD")

if [[ "$HTTP_CODE" == "200" ]]; then
  python3 -c "
import json
d = json.load(open('$RESP'))
print('PAGE_ID:', d.get('id'))
print('URL:', d.get('url'))
print('OBJECT:', d.get('object'))
"
  rm -f "$PAYLOAD" "$RESP"
  exit 0
else
  echo "HTTP $HTTP_CODE:" >&2
  head -c 800 "$RESP" >&2
  rm -f "$PAYLOAD" "$RESP"
  exit 1
fi
