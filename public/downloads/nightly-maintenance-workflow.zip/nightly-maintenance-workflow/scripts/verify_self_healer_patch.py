#!/usr/bin/env python3
"""
verify_self_healer_patch.py — ISS-062 4차 patch 검증 스크립트

cron_self_healer.py의 4차 patch (2026-06-05)가 정상 작동하는지 확인.
false positive 0건이어야 통과.

사용법:
    python3 verify_self_healer_patch.py                    # 최근 4개 잡 출력 자동 검사
    python3 verify_self_healer_patch.py <output_file> ...   # 특정 파일 지정 검사
    python3 verify_self_healer_patch.py --status           # 1줄 통과/실패만 출력 (heartbeat용)

검증 로직 (cron_self_healer.py의 meta_markers + line-by-line 검사 재현):
1. 메타 마커가 포함된 라인은 통째 drop
2. 잔존 텍스트에 대해 line-by-line으로 패턴 검사
3. 매칭되는 라인이 0건이어야 통과

종속성: 표준 라이브러리만 (re, sys, pathlib)
"""

import re
import sys
from pathlib import Path

# cron_self_healer.py의 meta_markers와 동기화 필수
META_MARKERS = (
    "패턴 매치:",
    r"\b(?:api[\s._-]*(?:error|failed)",
    "self-healer",
    "self_healer",
    "self_heal",
    "self-heal",
    "self trigger",
    "self_trigger",
    "self-quote",
    "self_quote",
    "iss-044",
    "iss-058",
    "iss-059",
    "iss-062",
    # 4차 patch에서 추가된 informational 마커
    "notion api",
    "api rate",
    "rate limit",
    "rate_limit",
    "공통 효과",
    "doc reference",
    "substring은 더 이상",
    "오탐 대표",
    "false positive",
    "memory error",
    "out of memory",
    "memoryissue",
    "memory\u2423issue",
)

# cron_self_healer.py의 APIError 패턴과 동기화 필수
APIERROR_PATTERN = (
    r"\b(?:api[\s._-]*(?:error|failed)|rate[\s._]*limit(?:\s*exceeded)?"
    r"|http\s*(?:401|403|404|429|500|502|503)\s*(?::|\s+(?:unauthorized"
    r"|forbidden|not\s*found|server\s*error|bad\s*gateway|service\s*unavailable"
    r"|too\s*many\s*requests|internal\s*server\s*error))"
    r"|authentication\s*failed|invalid\s*api\s*key)\b"
)

# 4차 patch 적용 후 검사 대상 — false positive가 발생하던 잡들
DEFAULT_JOBS = {
    "5d0f14aef84c": "일일 자기 개선 리뷰",
    "388898171a79": "지식 그래프 자동 구축",
    "075bec58df7b": "오전 통합 인사이트",
    "ed5f37705e68": "심야 통합 점검",
}

CRON_OUTPUT_DIR = Path.home() / ".hermes" / "cron" / "output"


def filter_meta_lines(content_lower):
    """메타 마커가 포함된 라인은 빈 라인으로 대체 (4차 patch 로직 재현)."""
    filtered = []
    for line in content_lower.splitlines():
        if any(m in line for m in META_MARKERS):
            filtered.append("")
        else:
            filtered.append(line)
    return "\n".join(filtered)


def find_false_positives(content):
    """라인별로 APIError 패턴 검사 — 매칭된 라인 반환."""
    content_lower = content.lower()
    filtered = filter_meta_lines(content_lower)
    matches = []
    for line in filtered.splitlines():
        if re.search(APIERROR_PATTERN, line):
            matches.append(line.strip()[:200])
    return matches


def check_latest_output(job_id):
    """특정 잡의 가장 최근 출력 파일 검사."""
    job_dir = CRON_OUTPUT_DIR / job_id
    if not job_dir.exists():
        return {"job_id": job_id, "status": "skip", "reason": "no output dir"}

    md_files = sorted(job_dir.glob("*.md"), key=lambda p: p.stat().st_mtime, reverse=True)
    if not md_files:
        return {"job_id": job_id, "status": "skip", "reason": "no output files"}

    latest = md_files[0]
    try:
        content = latest.read_text(encoding="utf-8")
    except Exception as e:
        return {"job_id": job_id, "status": "error", "reason": f"read failed: {e}"}

    matches = find_false_positives(content)
    return {
        "job_id": job_id,
        "status": "pass" if not matches else "fail",
        "file": latest.name,
        "fp_count": len(matches),
        "matches": matches[:3],
    }


def main():
    args = sys.argv[1:]

    status_mode = "--status" in args
    if status_mode:
        args.remove("--status")

    if args:
        results = []
        for filepath in args:
            try:
                content = Path(filepath).read_text(encoding="utf-8")
                matches = find_false_positives(content)
                results.append({
                    "file": filepath,
                    "status": "pass" if not matches else "fail",
                    "fp_count": len(matches),
                    "matches": matches[:3],
                })
            except Exception as e:
                results.append({"file": filepath, "status": "error", "reason": str(e)})
    else:
        results = []
        for job_id, job_name in DEFAULT_JOBS.items():
            r = check_latest_output(job_id)
            r["job_name"] = job_name
            results.append(r)

    total = len(results)
    failed = sum(1 for r in results if r["status"] == "fail")
    errored = sum(1 for r in results if r["status"] == "error")
    passed = total - failed - errored

    if status_mode:
        if failed == 0 and errored == 0:
            print(f"PASS: {passed}/{total} jobs clean (ISS-062 4\ucc28 patch OK)")
            sys.exit(0)
        else:
            print(f"FAIL: {failed}/{total} jobs have FP, {errored} errors (ISS-062 \uc7ac\ubc1c)")
            sys.exit(1)

    print(f"=== ISS-062 4\ucc28 patch \uac80\uc99d ({total} jobs) ===\n")
    for r in results:
        job_id = r.get("job_id", r.get("file", "?"))
        job_name = r.get("job_name", "")
        status = r["status"].upper()
        if status == "PASS":
            print(f"\u2705 {job_id} {job_name}: PASS ({r.get('file', '')})")
        elif status == "FAIL":
            print(f"\u274c {job_id} {job_name}: FAIL \u2014 {r['fp_count']} FP in {r.get('file', '')}")
            for m in r.get("matches", []):
                print(f"   > {m[:150]}")
        elif status == "ERROR":
            print(f"\u26a0\ufe0f  {job_id}: ERROR \u2014 {r.get('reason', '?')}")
        else:
            print(f"\u23ed\ufe0f  {job_id}: SKIP \u2014 {r.get('reason', '?')}")

    print()
    if failed == 0 and errored == 0:
        print(f"\u2705 \ubaa8\ub4e0 \uac80\uc0ac \ud1b5\uacfc ({passed}/{total}). ISS-062 4\ucc28 patch \uc815\uc0c1 \uc791\ub3d5 \uc911.")
        sys.exit(0)
    else:
        print(f"\u274c {failed}\uac74 false positive, {errored}\uac74 \uc5d0\ub7ec. ISS-062 \uc7ac\ubc1c \uac00\ub2a5\uc131 \u2192 4\ucc28 patch \uc7ac\uac80\ud1a0 \ub610\ub294 5\ucc28 \ub9c8\ud06c \ucd94\uac00 \ud544\uc694.")
        sys.exit(1)


if __name__ == "__main__":
    main()
