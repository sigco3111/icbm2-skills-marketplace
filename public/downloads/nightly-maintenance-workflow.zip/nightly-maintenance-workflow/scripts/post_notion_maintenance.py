#!/usr/bin/env python3
"""Notion 정비 리포트 DB POST — 4단계 표준 Fast-path (07-09 + 07-22 실측).

사용법:
    python3 post_notion_maintenance.py "정비 제목" "YYYY-MM-DD" "상태" 에러수 fix수

예시:
    python3 post_notion_maintenance.py \
        "심야 통합 정비 2026-07-09 03:30 KST" 2026-07-09 "⚠️ 문제 발견" 1 0

페이로드는 /tmp/notion_payload_maintenance.json에 저장 후 POST.
토큰은 ~/.hermes/secrets/notion_token.txt에서 런타임에 읽음 (평문 노출 없음).

검증:
    - HTTP 200 + object=page → page_id 출력 (정비 리포트 Notion URL 형식)
    - HTTPError → /tmp/notion_resp_maintenance.json에 응답 저장 후 non-zero 종료
"""
import json
import sys
import urllib.error
import urllib.request
from pathlib import Path

DB_ID = "33c76f2e-9097-8198-bd1b-c3ea3cfbbae8"
TOK_PATH = Path.home().joinpath(".hermes/secrets/notion_token.txt")
PAYLOAD_PATH = Path("/tmp/notion_payload_maintenance.json")
RESP_PATH = Path("/tmp/notion_resp_maintenance.json")


def introspect_db() -> dict:
    """DB 스키마 1회 introspect → 한글 속성명 검증. 첫 POST 400 회피."""
    tok = TOK_PATH.read_text().strip()
    req = urllib.request.Request(
        f"https://api.notion.com/v1/databases/{DB_ID}",
        headers={"Authorization": "Bearer " + tok, "Notion-Version": "2022-06-28"},
    )
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read().decode("utf-8"))


def build_payload(title: str, date_iso: str, status: str, errors: int, fixes: int) -> dict:
    return {
        "parent": {"database_id": DB_ID},
        "properties": {
            "이름": {"title": [{"type": "text", "text": {"content": title}}]},
            "날짜": {"date": {"start": date_iso}},
            "상태": {"select": {"name": status}},
            "에러 수": {"number": errors},
            "수리 항목 수": {"number": fixes},
            "요약": {
                "rich_text": [
                    {
                        "type": "text",
                        "text": {
                            "content": f"errors={errors} fixes={fixes} status={status}",
                        },
                    }
                ]
            },
            "점검 항목": {
                "multi_select": [
                    {"name": "에러 모니터링"},
                    {"name": "자가치유"},
                    {"name": "메모리 점검"},
                    {"name": "메모리 동기화"},
                    {"name": "nightly-maintenance"},
                ]
            },
        },
    }


def post_page(payload: dict) -> dict:
    tok = TOK_PATH.read_text().strip()
    req = urllib.request.Request(
        "https://api.notion.com/v1/pages",
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        method="POST",
        headers={
            "Authorization": "Bearer " + tok,
            "Notion-Version": "2022-06-28",
            "Content-Type": "application/json",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            body = r.read().decode("utf-8")
            RESP_PATH.write_text(body, encoding="utf-8")
            return json.loads(body)
    except urllib.error.HTTPError as e:
        RESP_PATH.write_text(e.read().decode("utf-8", errors="replace"), encoding="utf-8")
        raise


def page_id_to_url(page_id: str, title_slug: str) -> str:
    no_dash = page_id.replace("-", "")
    return f"https://app.notion.com/p/{title_slug}-{no_dash}"


def main() -> int:
    if len(sys.argv) < 6:
        print(__doc__)
        return 2

    title = sys.argv[1]
    date_str = sys.argv[2]
    status = sys.argv[3]
    errors = int(sys.argv[4])
    fixes = int(sys.argv[5])

    date_iso = f"{date_str}T03:30:00+09:00"
    title_slug = title.replace(" ", "-").replace(":", "-")

    # 1) introspect (선택 — 첫 실행 시 또는 DB 스키마 변경 의심 시)
    #    비용 < 200ms, 안전을 위해 매번 실행
    introspect_db()

    # 2) build + write payload
    payload = build_payload(title, date_iso, status, errors, fixes)
    PAYLOAD_PATH.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    # 3) POST
    try:
        result = post_page(payload)
    except urllib.error.HTTPError as e:
        print(f"HTTP_ERROR: {e.code}")
        print(f"응답: {RESP_PATH}")
        return 1

    page_id = result.get("id")
    print(f"PAGE_ID: {page_id}")
    if page_id:
        print(f"URL: {page_id_to_url(page_id, title_slug)}")
    print(f"OBJECT: {result.get('object')}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
