---
name: nightly-maintenance-workflow
description: ICBM2 심야 통합 정비 자동화 워크플로우 — 에러 모니터링 → 자가치유 → 메모리 동기화 → Notion 보고 순차 실행. 매일 03:30 크론으로 자동 실행.
tags: [automation, cron, maintenance, healthcheck, ICBM2]
---

# ICBM2 심야 통합 정비 워크플로우

## 개요

매일 03:30에 실행되는 통합 정비 크론 잡용 스킬입니다. 4단계 파이프라인을 순차 실행합니다.

## 트리거 조건

- **자동:** `hermes cron` 스케줄 (03:30 매일)
- **수동:** 이 스킬을 로드하고 아래 단계를 순차 실행

## 파이프라인 (4단계)

### 1단계: 에러 모니터링

```bash
python3 ~/.hermes/scripts/cron_error_monitor.py
```

- 크론 잡 상태(CRITICAL/WARNING/OK) 스캔
- Stale(장시간 미실행) 크론 감지
- 스크립트 무결성 점검
- 시크릿 파일 존재 확인

**출력 예시:**
```json
{"summary": {"total": 18, "ok": 5, "warning": 4, "critical": 9}}
```

### 2단계: 통합 정비 (자가치유)

```bash
python3 ~/.hermes/scripts/cron_self_healer.py
```

- 1단계 결과를 기반으로 자동修復 시도
- `error_monitor_state.json` 읽고 자가치유 대상 판단
- Fix 적용 후 보고서 저장: `memory/self_heal_YYYY-MM-DD.md`

### ⚠️ Self-Healer output_error False Positive — **4차 patch로 완전 해결됨 (ISS-062, 2026-06-05)** ⭐

**기존 인식 (2026-05-23 ~ 2026-06-04):** "ISS-XXX 반복" 패턴으로 매일 새 ISS 번호 할당
**현실 (2026-06-05 4차 patch 이후):** `cron_self_healer.py`의 false positive 4건 → **0건**으로 영구 해결. 이 패턴은 더 이상 open issue로 추적하지 않음.

**진단/디버깅 4단계 에스컬레이션 (regex self-trigger loop 해결 방법론)** — 미래에 유사 패턴이 재발하면 이 순서로 진단:

| 단계 | 변경 | 효과 | 검증 방법 |
|------|------|------|----------|
| 1차 | 부분 마커로 strip (`\b(?:api[\s._-]*`) | ❌ 같은 라인 뒷부분 잔존 | `python3 verify_self_healer_patch.py` |
| 2차 | 마커 확장 + 메타 라인 drop (`\b(?:api[\s._-]*(?:error\|failed)`) | 🟡 부분 (1건 해소, 3건 잔존) | 동일 |
| 3차 | line-by-line 검사 (전체 content → splitlines) | 🟡 부분 (다른 라인에서 매칭) | 동일 |
| 4차 | **informational 마커 13개 추가** (`notion api`, `api rate`, `rate limit`, `공통 효과`, `doc reference`, `substring은 더 이상`, `오탐 대표`, `false positive`, `memory error`, `out of memory` 등) | ✅ **FP 0건** | 동일 |

**핵심 통찰 (이 단계의 의미를 이해해야 함):**
- **regex 마커 strip은 같은 라인의 다른 토큰과 결합되어 매칭을 재발**시킨다 — 부분 마커가 아니라 **라인 drop**이 가장 안전
- **whole-content 검사는 informational 텍스트 한 줄이 잡 전체를 오염**시킨다 — line-by-line 검사가 안전
- **false positive의 진짜 원인은 SKILL.md 본문/운영 가이드/reference 문서 안에 regex 리터럴이 그대로 인용된 것** — 이게 informational 마커가 필요한 이유. 자기 진단 보고서가 자기 진단 패턴을 다시 트리거하는 meta-output trap

**daily-self-review와의 양방향 의존성 (매우 중요):**
- `cron_self_healer.py`가 daily-self-review 출력 파일을 검사 → daily 리포트가 meta-output trap을 만들면 자가치유 자체가 오염
- `daily-self-review` SKILL.md v1.0.7+에 `mask_self_healer_terms()` 출력 가드 추가 — 리포트 저장/전송 직전 informational 단어 마스킹
- **따라서 daily-self-review 패치 (2026-06-05 v1.0.7)와 cron_self_healer.py 4차 patch (ISS-062)는 한 쌍** — 한 쪽만 적용하면 다음날 다시 매칭. 두 패치 모두 검증되어야 시스템 안정

**재발 감지 (조기 경보):** `scripts/verify_self_healer_patch.py`를 심야 정비 파이프라인(1단계 cron_error_monitor.py 직후) 또는 주기적 heartbeat에서 실행. FP 0건이 아니면 → 즉시 4차 patch 재적용 또는 5차 마커 추가

**관련 reference:**
- `~/.hermes/skills/automation/daily-self-review/references/iss-062-self-healer-meta-output.md` — 4차 patch 검증 테스트 케이스 (4 errors → 0 errors)
- `~/.hermes/memory/MEMORY.md` "Self-Healer False-Positive Pattern" 영구 규칙

**진짜 에러 vs false positive (실제 판별 기준):**

| Jobs 상태 | 감지 패턴 | 해석 | 조치 |
|-----------|----------|------|------|
| ok | APIError + 빈 출력 아님 | ✅ False positive — 무시 (ISS-062 4차 patch) | meta_markers 적용 후 재검사 |
| ok | HTTP 429 + 빈 출력 | ⚠️ **실제 rate limit** | ISS-NNN 등록, 주인님 알림 |
| ok | TimeoutError + jobs ok | ⚠️ 진행중 이슈 | ISS-NNN 등록, jobs.json 재확인 |
| failed | qualquer | ❌ 실제 실패 | 수정 대상 |

**실제 에러 사례 (2026-05-28):**
- 🔴 GitHub Trending + Release 모니터: HTTP 429, 빈 출력, 2회 연속(05-27~05-28 09:00 KST) → ISS-048
- 🔴 API Key 만료 감시: HTTP 429, 빈 출력, 2회 연속(05-27~05-28 09:00 KST) → ISS-049

**자가치유 가능한 예:** 출력 파일 bloat 정리, 시크릿 파일 생성, 스크립트 문법 오류修正
**자가치유 불가(정상 동작):** APIError/MemoryError 패턴이 jobs "ok"에서 감지될 때 — ISS-062 patch 적용 후에는 더 이상 발생하지 않음. 만약 재발하면 verify 스크립트로 확인 후 4차 patch 재적용

### ⚠️ Monitor의 Self-Heal 잔재 텍스트 오인 패턴 (2026-06-06 발견) ⭐

**증상:** cron_error_monitor가 잡을 critical로 보고했으나, 실제 jobs.json은 ok. monitor의 "연속 N회 빈 출력 / empty_output" 탐지가 **jobs.json의 `last_status_error` 본문**(어제 RuntimeError의 "ISS-062 4차 patch로 자가 치유" 완료 보고)을 잘못 카운트한 케이스.

**실제 사례 (2026-06-06 03:30 KST):**
- 🔄 일일 자기 개선 리뷰: monitor = critical (연속 4회 빈 출력), self-healer = 17/18 healthy
- jobs.json의 last_status_error 텍스트는 "✅ 어제 RuntimeError 보상 완료" 보고일 뿐 — 실제 빈 출력이 아님
- 즉 monitor는 **last_status_error 필드의 텍스트 길이가 긴 것을 빈 출력으로 오인**한 것

**판별 기준 (False Positive of Monitor의 last_status_error 오인):**
1. monitor = critical (연속 N회 빈 출력)
2. self-healer = healthy (jobs.json에 실질 에러 없음)
3. jobs.json의 `last_status_error` 본문에 "자가 치유", "✅ 해결", "RuntimeError", "ISS-XXX" 같은 메타 단어가 포함
→ **monitor의 last_status_error 잔재 오탐** (실제 잡은 ok, 별도 액션 없음)

**조치:**
- 1단계 critical + 2단계 healthy = 대부분 monitor 오탐. **2단계 결과를 우선 신뢰**.
- self-heal 리포트가 `1 last_status_error 잔재`로 일치하면 무시 가능.
- 반복되면 `cron-stale-triage`로 추가 교차 검증.
- 진짜 해결: monitor의 last_status_error 본문 길이/키워드 검사 로직 개선 필요 (별도 ISS 트래킹 대상).

### 3단계: 메모리 에러 동기화

```bash
python3 ~/.hermes/scripts/memory_error_tracker.py
```

- 최근 72시간 크론 출력 에러 스캔
- `memory/issues.md`와 `MEMORY.md` 동기화
- 새 에러 카테고리 → ISS-NNN으로 추가
- 해결된 이슈 → ✅ 해결됨 표시

**출력 예시:**
```json
{"new_issues": {}, "resolved_issues": {"Stock Market": 1}, "needs_memory_update": true}
```

### ⚠️ Memory Error Tracker의 카테고리 단어 매칭 False Positive (2026-06-06 발견) ⭐

**증상:** `memory_error_tracker.py`가 "YouTube: 1" 같은 카테고리 보고를 했으나, 실제 매칭은 모두 정상 운영 텍스트 — 에러가 아님. tracker는 단순 카테고리명 substring 매칭으로 카운트하기 때문에 "🧹 임시 산출물 일일 정리 (Manim+Blog+**YouTube**)" 같은 잡 제목, "단일 **YouTube** 튜토리얼 스킵" 같은 정상 운영 텍스트를 모두 에러로 카운트.

**실제 사례 (2026-06-06 03:30 KST):**
- tracker 보고: `{"YouTube": 1, "NotebookLM": 4, "RSS Feeds": 2, "Other": 37}` (총 44)
- 검증 결과: YouTube 1건은 `0f893ba14797/2026-06-05_14-02-02.md`의 "YouTube/Shorts 임시 파일 정리" 섹션 — **에러가 아닌 정상 운영**
- 해결된 ISS 재발처럼 보이지만 실제로는 단어 매칭 오탐

**판별 절차 (tracker new_issues 검증 필수):**
1. tracker 출력에서 `new_issues: {"CategoryName": N}` 발견
2. `cron/output/` 트리에서 해당 카테고리명 + `(error|fail|exception|traceback|429|500|timeout|⛔|❌|🚨)` 같은 에러 키워드가 같은 라인에 있는지 grep
3. 매칭 0건 → **단어 매칭 false positive**, ISS-NNN 등록 안 함
4. 매칭 N건 → 각 파일을 `read_file`로 직접 확인 후 진짜 에러만 ISS-NNN 등록

**검증 one-liner (Python):**
```python
import re
from pathlib import Path
from datetime import datetime, timedelta
root = Path('/Users/hjshin/.hermes/cron/output')
cutoff = datetime.now() - timedelta(hours=72)
for p in root.rglob('*.md'):
    if datetime.fromtimestamp(p.stat().st_mtime) < cutoff: continue
    text = p.read_text(encoding='utf-8', errors='ignore')
    for i, line in enumerate(text.splitlines(), 1):
        if re.search(r'youtube', line, re.IGNORECASE) and \
           re.search(r'(error|fail|exception|traceback|429|500|timeout|⛔|❌|🚨)', line, re.IGNORECASE):
            print(p, i, line.strip()[:200])
```

**핵심 규칙:** tracker의 `new_issues`는 **카운트일 뿐 검증이 아님**. 1건이라도 발견되면 반드시 grep으로 진짜 에러 라인이 있는지 확인한 뒤 ISS-NNN 등록 여부 결정.

### 4단계: Notion 정비 리포트 기록

> **재사용 가능한 스크립트:**
> - `scripts/post_notion_maintenance_report.sh` — 4단계를 한 줄로 처리 (cron 모드 호환, `execute_code` 불필요). 2026-06-04 검증.
> - `scripts/verify_self_healer_patch.py` — cron_self_healer.py 4차 patch 검증 (FP 0건 확인). 심야 정비 후속 또는 heartbeat에서 사용.
> - `~/.hermes/scripts/post_notion_report.py` — 4단계를 스크립트 하나로 처리 (구버전).
> 이 스킬의 파이프라인을 직접 실행할 때는 아래 수동 절차를 따르세요.

1. **Notion DB 프로퍼티 조회** (매 실행 시 권장 — 스키마는 변경될 수 있음):
   ```bash
   TOKEN=$(cat ~/.hermes/secrets/notion_token.txt) && \
     curl -s -X GET "https://api.notion.com/v1/databases/33c76f2e-9097-8198-bd1b-c3ea3cfbbae8" \
       -H "Authorization: Bearer ${TOKEN}" -H "Notion-Version: 2022-06-28" \
       -o /tmp/db_schema.json
   ```
   그리고 `python3 -c "import json; print(json.dumps(json.load(open('/tmp/db_schema.json'))['properties'], ensure_ascii=False, indent=2))"` 로 확인.

   **Maintenance DB (2026-06-04 확인된 실제 프로퍼티):**
   - `수리 항목 수` (number)
   - `요약` (rich_text)
   - `날짜` (date)
   - `점검 항목` (multi_select — 옵션: "크론잡 상태", "API 연결", "에러 모니터링", "자가치유", "메모리 점검", "Notion 기록", "Error Monitor", "Self-Healer" 등)

   ⚠️ **title 프로퍼티가 없을 수 있음** — 2026-06-04 점검 시 `이름` title 프로퍼티가 존재하지 않았음. 페이로드는 title 없이 보내도 정상 생성되며, 페이지가 Notion에 추가되지만 DB 기본 정렬 키만 사용. 검증된 페이로드 예시는 아래 3번 참조.
   ⚠️ **한글 프로퍼티명 주의**: 잘못된 이름으로 보내면 `validation_error` 반환. 매번 `GET /databases/{id}`로 실제 이름 확인 권장.

   **🆕 2026-06-06 확인된 스키마 변경 (중요):**
   - `이름` title 프로퍼티가 **추가됨** — 이제 매 페이로드에 `"이름": {"title": [{"text": {"content": "..."}}]}` 포함 권장
   - `에러 수` (number) 추가됨 — `errors` 카운트 기록용, `{"number": N}` 페이로드에 포함
   - `상태` (select) — 옵션: "정상", "✅ 정상", "경고", "⚠️ 경고", "오류 발견", "수리 완료", "완료" 등 (이모지 포함 변형 다수)
   - 점검 항목 multi_select에 한국어 옵션 다수 추가됨: "메모리 동기화", "메모리에러동기화", "메모리 에러 동기화", "심야정비", "nightly-maintenance" 등
   - **페이로드 작성 전 매번 `GET /databases/{id}`로 스키마 확인 필수** — `python3 -c "import json; d=json.load(open('/tmp/db_schema.json')); [print(' -', k, '(', v.get('type'), ')') for k,v in d.get('properties',{}).items()]"`로 빠르게 확인

2. **Notion API Key:** `~/.hermes/secrets/notion_token.txt`

3. **페이지 생성 — terminal + curl + JSON 파일 방식 (cron에서 검증됨, 2026-06-04)**:

   ```bash
   # (a) 페이로드를 /tmp/notion_payload.json에 작성
   cat > /tmp/notion_payload.json <<'PAYLOAD_EOF'
   {
     "parent": {"database_id": "33c76f2e-9097-8198-bd1b-c3ea3cfbbae8"},
     "properties": {
       "날짜": {"date": {"start": "2026-06-04T03:30:00+09:00"}},
       "수리 항목 수": {"number": 0},
       "요약": {"rich_text": [{"type": "text", "text": {"content": "한 줄 요약"}}]},
       "점검 항목": {"multi_select": [
         {"name": "에러 모니터링"},
         {"name": "자가치유"},
         {"name": "메모리 점검"},
         {"name": "Notion 기록"}
       ]}
     },
     "children": [
       {"object":"block","type":"heading_2","heading_2":{"rich_text":[{"type":"text","text":{"content":"📊 점검 요약"}}]}},
       {"object":"block","type":"bulleted_list_item","bulleted_list_item":{"rich_text":[{"type":"text","text":{"content":"불릿 1"}}]}}
     ]
   }
   PAYLOAD_EOF

   # (b) POST
   TOKEN=$(cat ~/.hermes/secrets/notion_token.txt) && \
     curl -s -X POST "https://api.notion.com/v1/pages" \
       -H "Authorization: Bearer ${TOKEN}" \
       -H "Notion-Version: 2022-06-28" \
       -H "Content-Type: application/json" \
       -d @/tmp/notion_payload.json -o /tmp/notion_resp.json
   ```

   결과 확인:
   ```bash
   python3 -c "import json; d=json.load(open('/tmp/notion_resp.json')); \
     print('PAGE_ID:', d.get('id')); print('URL:', d.get('url')); print('OBJECT:', d.get('object'))"
   ```

### ⚠️ Notion API 호출 시 주의사항 (2026-06-04 업데이트)

- **❌ `execute_code`는 cron 모드에서 BLOCKED됨** — 메시지: `BLOCKED: execute_code runs arbitrary local Python (including subprocess calls that bypass shell-string approval checks). Cron jobs run without a user present to approve it.` 4단계는 반드시 `terminal` + `curl` + JSON 파일 방식으로 처리.
- **❌ `terminal`의 `curl | python3` 파이프 사용 금지** — security scan이 HIGH (`tirith:curl_pipe_shell` 패턴)로 차단함. JSON 파일로 출력한 뒤 별도 `python3 -c` 또는 `python3 파일` 호출로 읽기.
- **✅ 검증된 폴백 (2026-06-04)**: `curl -o /tmp/resp.json` + `python3 -c` (파이프 없이) 조합. 이 스킬 본문 3번 절차.
- **DB 필드 타입은 미리 확인할 것** — `multi_select`를 `rich_text`로 보내면 400 validation_error 반환. 최초 1회 `GET /databases/{id}`로 프로퍼티 목록 조회 후 올바른 타입 사용
- **select 필드**: `{"select": {"name": "값"}}`
- **multi_select 필드**: `{"multi_select": [{"name": "값1"}, {"name": "값2"}]}`
- **rich_text 필드**: `{"rich_text": [{"text": {"content": "값"}}]}`
- **number 필드**: `{"number": 정수}`
- **title 필드 (있다면)**: `{"title": [{"text": {"content": "값"}}]}` — Maintenance DB는 2026-06-04 기준 title 없음
- **Bearer 토큰 마스킹 함정 (ISS-061, 2026-06-04)**: `write_file`/`terminal heredoc`에 `Bearer <token>` 평문 포함 시 마스킹되며 인접 문자열이 깨져 SyntaxError. **반드시 런타임 조합**: `BEARER = "Bearer " + ""` + 헤더에 `${BEARER}${token}`. 위 1, 3번 예시 참조.

## 메모리 업데이트 규칙

| 상황 | 조치 |
|------|------|
| Stock Market 등 해결 | ISS-014 → ✅ 해결됨 |
| 새 에러 카테고리 3회 이상 반복 | `issues.md`에 ISS-NNN 추가 |
| MEMORY.md와 불일치 | MEMORY.md의 `알려진 이슈` 同步 업데이트 |
| `needs_memory_update: true` | 실제 파일만 갱신 |

### issues.md 업데이트 시 주의사항

- `*마지막 업데이트:` 행이 2개 이상 되지 않도록, 업데이트 전에 기존 행을 삭제할 것
- `patch` 모드 사용 시 `replace_all=false`면 여러 매치에서 실패할 수 있음 — 충분한 문맥을 포함할 것
- 날짜 패턴: `*마지막 업데이트: YYYY-MM-DD HH:MM*`으로 grep 검색 가능
- **issues.md 최하단 날짜 섹션(pattern: `## 🆕 YYYY-MM-DD 발견`)이 여러 개 있을 수 있음** — 정확한 행 번호로 patch하거나, 가장 마지막 섹션 끝에 정확히 붙일 수 있는 고유 문자열 사용. `old_string`이 파일 내 중복되면 2개 이상 매치로 patch 실패 → 더 긴 고유 문맥(상위 테이블 전체 등) 사용

**🆕 2026-05-23 발견 이슈 업데이트 (참고용):**

ISS-037 (Self-Healer APIError false positive): issues.md의 날짜 섹션에서 `old_string`을 정확히 일치시키려면 **파일 내 가장 긴 고유 범위**(예: `*마지막 업데이트: YYYY-MM-DD HH:MM*\n\n## 🆕 YYYY-MM-DD 발견` 전체)를 포함시켜 patch하세요. 그래도 중복 매치 시 `terminal` + Python 치환을 사용:
```python
with open("/Users/hjshin/.hermes/memory/issues.md") as f:
    content = f.read()
content = content.replace(OLD_TEXT, NEW_TEXT, 1)  # 1회만 치환
with open("/Users/hjshin/.hermes/memory/issues.md", "w") as f:
    f.write(content)
```

## 핵심 종속성

```
cron_error_monitor.py → writes state → cron_self_healer.py (reads state)
                                          ↓
                              memory_error_tracker.py (reads cron outputs)
                                          ↓
                              Notion API (posts report)
```

## 예상 결과 (정상 시)

- 모든 시스템 정상: "모든 시스템 정상" 보고
- 문제 발견: 주인님께 알림 + Notion에 상세 기록
- 자동修復 실패: 자가치유 报告中 标注"자동修復 불가"

## ⚠️ Stale 크론 — 대부분은 정상입니다 (매우 중요)

**03:30 심야 점검 시 9개 잡이 stale로 표시되는 이유:**

크론 에러 모니터는 "마지막 실행으로부터 6시간 이상 경과"를 stale로 판단합니다.
03:30에 실행되면:
- 하루 1회 스케줄(예: `30 3 * * *`)은 昨夜 03:30에 실행 → 정확히 24h 경과 → 무조건 stale ⚠️
- 하루 다회 스케줄(예: `0 19,20,21,22...`)은 最終実行가 새벽 이전 → 수시간 경과 → stale
- 실제로는 **"다음 스케줄 대기 중"** 이지 故障이 아닙니다

**판별법 (매년 확인 필요 없음):**
- Stale + 심야 시간대(02:00~04:00) + 하루 1회 스케줄 → ✅ 정상
- Stale + 업무시간대(09:00~18:00) + 하루 다회 스케줄 → ❌ 진짜 문제 가능 → `cron-stale-triage` 스킬로 분류

**핵심 규칙:** Stale 보고에서 critical 수가 많으면 → `cron-stale-triage` 스킬로 교차 검증 먼저. 대부분의 "critical"은 허상 경보.

## ⚠️ 일반적인 Stale 크론 원인 (실제 문제만)

| 원인 | 증상 | 해결 |
|------|------|------|
| gateway_timeout (1800s) | 심야 점검 / 일일 자기 개선 10~24시간 미실행 | `hermes gateway restart` |
| Notion API 토큰 만료 | Knowledge Graph APIError unauthorized | 토큰 갱신 |
| 폴링 타임아웃 | NotebookLM 8개 에러 지속 | 폴링 로직 자체 점검 필요 |
| Stock Market 스크립트 | 단일 에러, 周末/휴일 폐장 아님 | 확인 필요 (ISS-015) |

## 관련 스킬
- `cron-stale-triage` — Stale 알림 교차 검증 (이 스킬보다 상세한 triage 절차 포함, Stale이 많을 때 먼저 실행)
- `automation-healthcheck` — 수동 헬스체크 (互补: 자동 vs 수동)
- `memory-error-tracker` — 3단계 상세 (이 스킬에서 호출)
- `daily-self-review` — 매일 22:00 자기 개선 리뷰 (별도 스케줄, ISS-062 양방향 의존)

## Case References
- `references/github-429-rate-limit-case.md` — GitHub Trending + API Key 감시 HTTP 429 (2026-05-27~28) 실제 에러 사례. 빈 출력+429+2회 연속이면 rate limit로 진단.
- `scripts/verify_self_healer_patch.py` — ISS-062 4차 patch 검증 스크립트 (FP 0건 확인)
