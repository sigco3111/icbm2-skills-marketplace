---
name: nightly-maintenance-workflow
description: ICBM2 심야 통합 정비 자동화 워크플로우 — 에러 모니터링 → 자가치유 → 메모리 동기화 → Notion 보고 순차 실행. 매일 03:30 크론으로 자동 실행.
tags: [automation, cron, maintenance, healthcheck, ICBM2]
---

# ICBM2 심야 통합 정비 워크플로우

## 개요

매일 03:30에 실행되는 통합 정비 크론 잡용 스킬입니다. 4단계 파이프라인을 순차 실행합니다.

## 트리거 조건

- **자동:** `hermes cron` 스케줄 (03:30 매일)
- **수동:** 이 스킬을 로드하고 아래 단계를 순차 실행

## 파이프라인 (4단계)

### 1단계: 에러 모니터링

```bash
python3 ~/.hermes/scripts/cron_error_monitor.py
```

- 크론 잡 상태(CRITICAL/WARNING/OK) 스캔
- Stale(장시간 미실행) 크론 감지
- 스크립트 무결성 점검
- 시크릿 파일 존재 확인

**출력 예시:**
```json
{"summary": {"total": 18, "ok": 5, "warning": 4, "critical": 9}}
```

### 2단계: 통합 정비 (자가치유)

```bash
python3 ~/.hermes/scripts/cron_self_healer.py
```

- 1단계 결과를 기반으로 자동修復 시도
- `error_monitor_state.json` 읽고 자가치유 대상 판단
- 출력에서 TimeoutError, APIError 등 패턴 감지
- Fix 적용 후 보고서 저장: `memory/self_heal_YYYY-MM-DD.md`

**출력 예시:**
```json
{"summary": {"total_jobs": 18, "healthy_jobs": 16, "total_errors": 2, "fixes_applied": 0}}
```

### 3단계: 메모리 에러 동기화

```bash
python3 ~/.hermes/scripts/memory_error_tracker.py
```

- 최근 72시간 크론 출력 에러 스캔
- `memory/issues.md`와 `MEMORY.md` 동기화
- 새 에러 카테고리 → ISS-NNN으로 추가
- 해결된 이슈 → ✅ 해결됨 표시

**출력 예시:**
```json
{"new_issues": {}, "resolved_issues": {"Stock Market": 1}, "needs_memory_update": true}
```

### 4단계: Notion 정비 리포트 기록

1. **Notion DB 프로퍼티 조회** (첫 실행 시 필수):
   ```
   Notion DB ID: 33c76f2e-9097-8198-bd1b-c3ea3cfbbae8
   프로퍼티: 이름(title), 날짜(date), 상태(select), 점검 항목(multi_select), 에러 수(number), 수리 항목 수(number), 요약(rich_text)
   ```

2. **Notion API Key:** `~/.hermes/secrets/notion_token.txt`

3. **페이지 생성 — execute_code 사용** (security scan이 `curl | python3` 파이프를 차단하므로):
   ```python
   import urllib.request, json, urllib.error
   token = open("/Users/hjshin/.hermes/secrets/notion_token.txt").read().strip()
   db_id = "33c76f2e-9097-8198-bd1b-c3ea3cfbbae8"
   payload = {
       "parent": {"database_id": db_id},
       "properties": {
           "이름": {"title": [{"text": {"content": f"🛡️ 심야 통합 정비 — {date}"}}]},
           "날짜": {"date": {"start": f"{date}T03:30:00+09:00"}},
           "상태": {"select": {"name": "완료"}},
           "에러 수": {"number": <총 에러 수>},
           "수리 항목 수": {"number": <自動修復 수>},
           "요약": {"rich_text": [{"text": {"content": "<요약 텍스트>"}}]},
           "점검 항목": {"multi_select": [{"name": n} for n in ["에러 모니터링", "자가치유", "메모리 동기화"]]}
       }
   }
   data = json.dumps(payload).encode()
   req = urllib.request.Request("https://api.notion.com/v1/pages", data=data,
       headers={"Authorization": f"Bearer {token}", "Notion-Version": "2022-06-28", "Content-Type": "application/json"}, method="POST")
   try:
       with urllib.request.urlopen(req, timeout=15) as r:
           result = json.loads(r.read())
           print("OK" if result.get("object") == "page" else f"ERROR: {result}")
   except urllib.error.HTTPError as e:
       body = e.read().decode()
       print(f"HTTP {e.code}: {body[:500]}")  # validation_error 원인 파악용
   ```

### ⚠️ Notion API 호출 시 주의사항

- **terminal에서 `curl | python3` 파이프 사용 금지** — security scan이 HIGH로 차단함. `execute_code` 도구 사용 필수
- **DB 필드 타입은 미리 확인할 것** — `multi_select`를 `rich_text`로 보내면 400 validation_error 반환. 최초 1회 `GET /databases/{id}`로 프로퍼티 목록 조회 후 올바른 타입 사용
- **select 필드**: `{"select": {"name": "값"}}`
- **multi_select 필드**: `{"multi_select": [{"name": "값1"}, {"name": "값2"}]}`
- **rich_text 필드**: `{"rich_text": [{"text": {"content": "값"}}]}`
- **number 필드**: `{"number": 정수}}`

## 메모리 업데이트 규칙

| 상황 | 조치 |
|------|------|
| Stock Market 등无害エ唎解決 | ISS-014 → ✅ 해결됨 |
| 새 에러 카테고리 3회 이상 반복 | `issues.md`에 ISS-NNN 추가 |
| MEMORY.md와 불일치 | MEMORY.md의 `알려진 이슈`同步 업데이트 |
| `needs_memory_update: true` | 실제 파일만 갱신 |

### issues.md 업데이트 시 주의사항

- `*마지막 업데이트:*` 행이 2개 이상にならないよう、更新前に既存行を削除すること
- `patch` 模式使用时 `replace_all=false` だと複数マッチで失敗する — 十分な文脈を含めること
- 날짜 패턴: `*마지막 업데이트: YYYY-MM-DD HH:MM*` で grep 检索可

## 핵심 종속성

```
cron_error_monitor.py → writes state → cron_self_healer.py (reads state)
                                          ↓
                              memory_error_tracker.py (reads cron outputs)
                                          ↓
                              Notion API (posts report)
```

## 예상 결과 (정상 시)

- 모든 시스템 정상: "모든 시스템 정상" 보고
- 문제 발견: 주인님께 알림 + Notion에 상세 기록
- 자동修復 실패: 자가치유报告中标注"자동修復 불가"

## ⚠️ Stale 크론 — 대부분은 정상입니다 (매우 중요)

**03:30 심야 점검 시 9개 잡이 stale로 표시되는 이유:**

크론 에러 모니터는 "마지막 실행으로부터 6시간 이상 경과"를 stale로 판단합니다.
03:30에 실행되면:
- 하루 1회 스케줄(예: `30 3 * * *`)은昨夜 03:30에 실행 → 정확히 24h 경과 → 무조건 stale ⚠️
- 하루 다회 스케줄(예: `0 19,20,21,22...`)은最終実行가 새벽 이전 → 수시간 경과 → stale
- 실제로는 **"다음 스케줄 대기 중"** 이지故障이 아닙니다

**판별법 (매년 확인 필요 없음):**
- Stale + 심야 시간대(02:00~04:00) + 하루 1회 스케줄 → ✅ 정상
- Stale + 업무시간대(09:00~18:00) + 하루 다회 스케줄 → ❌ 진짜 문제 가능 → `cron-stale-triage` 스킬로 분류

**핵심 규칙:** Stale 보고에서 critical 수가 많으면 → `cron-stale-triage` 스킬로 교차 검증 먼저. 대부분의 "critical"은 허상 경보.

## ⚠️ 일반적인 Stale 크론 원인 (실제 문제만)

| 원인 | 증상 | 해결 |
|------|------|------|
| gateway_timeout (1800s) | 심야 점검 / 일일 자기 개선 10~24시간 미실행 | `hermes gateway restart` |
| Notion API 토큰 만료 | Knowledge Graph APIError unauthorized | 토큰 갱신 |
| 폴링 타임아웃 | NotebookLM 8개 에러 지속 | 폴링 로직 자체 점검 필요 |
| Stock Market 스크립트 | 단일 에러,周末/휴일 폐장 아님 | 확인 필요 (ISS-015) |

## 최근 해결된 이슈 (참고)

| ID | 이슈 | 해결일 |
|----|------|--------|
| ISS-001 | Notion Idea DB 404 (플랫폼 종료) | 2026-05-03 |
| ISS-014 | 폐장 시황 — API 에러 | 2026-05-02 |

## 관련 스킬

- `cron-stale-triage` — Stale 알림 교차 검증 (이 스킬보다 상세한 triage 절차 포함, Stale이 많을 때 먼저 실행)
- `automation-healthcheck` — 수동 헬스체크 (互补: 자동 vs 수동)
- `memory-error-tracker` — 3단계 상세 (이 스킬에서 호출)
- `daily-self-review` — 매일 22:00 자기 개선 리뷰 (별도 스케줄)
