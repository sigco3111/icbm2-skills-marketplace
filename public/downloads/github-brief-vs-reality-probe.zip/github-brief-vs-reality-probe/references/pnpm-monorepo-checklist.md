# pnpm-workspace monorepo checklist

When the brief asks about a monorepo with multiple workspaces, the recursive tree alone won't tell you each workspace's role. Use this checklist to interpret the workspace layout.

## pnpm-workspace.yaml anatomy

```yaml
packages:
  - apollo
  - ares       # client (e.g. React + Vite)
  - artemis    # server (e.g. Express + Prisma)
  - athena     # domain core (Map data, units)
  - deimos     # docs site
  - dionysus   # AI module (BaseAI + AIRegistry)
  - hera       # editor UI
  - hermes     # campaign/level logic
  - i18n       # translation keys + language list
  - offline    # mobile / electron bundle
  - ui         # shared UI components
  - zeus       # bundle wrapper
  - tests
  - codegen
  - docs
  - eslint-plugin
  - fixtures
  - scripts
  - art        # art assets

allowBuilds:
  '@playwright/browser-chromium': true
  # ... (security policy)

overrides:
  react@^18.0.0: 19.0.0-rc.1
  # ...
```

**The `packages:` list is the role-table.** Read it first to map each workspace → role.

## How to identify workspace role from `package.json`

For each workspace `<ws>`, decode the manifest and check three signals:

### 1. Dependencies reveal role

| Role | Key deps to look for |
|---|---|
| **Client (React/Vue/Svelte)** | `react`, `react-dom`, `react-router-dom`, `vite`, `webpack`, `relay`, `apollo-client` |
| **Server (Node)** | `express`, `fastify`, `graphql-yoga`, `apollo-server`, `socket.io`, `prisma`, `@prisma/client`, `stripe`, `resend`, `discord.js`, `aws-sdk` |
| **AI module** | `BaseAI`, `AIRegistry`, `PersephoneBeta`, `DionysusAlpha` (class names, not deps — search by class) |
| **i18n** | no runtime deps; just type definitions + language map |
| **Domain core** | other workspace packages only (`workspace:*`); minimal external deps |
| **Editor UI** | `@deities/<domain>` + `react` + `relay` |
| **Shared UI** | `react`, `styled-components`, `@deities/<domain>` |
| **Docs site** | `vite`, `vocs`, `docusaurus` |
| **Mobile/Electron** | `cordova`, `@capacitor/*`, `electron` |
| **Code generator** | `graphql-codegen`, `plop`, `ts-morph` |

### 2. The dev script line reveals entry file

```bash
"dev:client": "PORTLESS_APP_PORT=3031 portless athena-crisis ./ares/ares.tsx"
"dev:server": "PORTLESS_APP_PORT=3032 portless api.athena-crisis ./artemis/artemis.tsx"
```

This tells you:
- The client entry is `<workspace>/ares.tsx` (or `.tsx`)
- The server entry is `<workspace>/artemis.tsx`
- The hostname the dev server expects (`api.athena-crisis` = backend, `athena-crisis` = frontend)

### 3. The build script reveals deploy artifact

```bash
"build:client": "rm -rf ./dist/ares && pnpm fbtee && pnpm vite build --outDir ../dist/ares -c ./ares/vite.config.ts ./ares/"
"build:server": "./build-server"
"build:docker-server": "RELEASE_ID=$(git rev-parse --short HEAD) docker buildx build --load -f Dockerfile --platform=linux/amd64 --tag athena-crisis --build-arg RELEASE_ID=$RELEASE_ID ."
"build:offline": "rm -rf ./dist/offline && pnpm vite build --outDir ../dist/offline -c ./offline/vite.config.ts ./offline; rm -rf mobile/dist/offline; mkdir mobile/dist; cp -R dist/offline mobile/dist/offline; rm -rf electron/offline; cp -R dist/offline electron/offline"
```

This tells you:
- Client → Vite SPA → `dist/ares/`
- Server → custom `./build-server` script (often esbuild bundle) → Docker image
- Offline → Vite SPA + copy to mobile/electron dirs
- **No `vercel`/`netlify`/`fly` commands = no serverless deploy**

## Inter-workspace deps (`workspace:*`)

```bash
"@deities/apollo": "workspace:*"
"@deities/athena": "workspace:*"
```

These reference local workspaces via pnpm's symlinking. The graph shape:

```
ares (client)
  → apollo (game actions)
  → athena (domain types: Map, Unit)
  → hermes (campaign)
  → i18n

artemis (server)
  → apollo, athena, dionysus, hermes, i18n, zeus
  → graphql-yoga, socket.io, prisma

dionysus (AI)
  → apollo, athena, hermes (AI imports @deities/hermes/messages/getActivatePowerMessage)

zeus (wrapper)
  → apollo, athena, dionysus, hermes (composition)
```

**The `dev:server` script on the server workspace proves the entry file path even if the workspace Contents API is empty** — Pitfall #6 in SKILL.md.

## Common `scripts:` keys for monorepos

| Key | Purpose | Example |
|---|---|---|
| `dev:client` / `dev:server` | Start dev servers (often parallel via `npm-run-all`) | `portless athena-crisis ./ares/ares.tsx` |
| `build:client` / `build:server` | Production bundle per target | `vite build` / `./build-server` |
| `build:docker-server` | Docker image build with release tag | `docker buildx build --tag X --build-arg RELEASE_ID=...` |
| `build:offline` | Mobile/Electron offline bundle | `vite build + cp -R dist/offline mobile/dist/offline` |
| `build:docs` | Documentation site build | `cd docs && pnpm build` |
| `dev:setup` | First-time install bootstrap | `pnpm dev:prisma-generate && pnpm relay && pnpm codegen && pnpm fbtee` |
| `preinstall` | Git hooks setup | `git config core.hooksPath git-hooks` |
| `dev:prisma-generate` | Prisma client regen | `pnpm prisma generate` |
| `codegen` | GraphQL/Relay codegen | `ts-node codegen/generate-all.tsx` |
| `fbtee` / `fbtee:prepare` | Facebook translation extractor | `pnpm fbt` + `fbtee prepare-translations` |
| `portless` | Per-host dev URLs (3031 client, 3032 server) | `portless api.athena-crisis ./artemis/artemis.tsx` |
| `vitest:run` | Test runner with thread budget | `CPUS=$(...) export VITEST_MAX_THREADS=$(($CPUS - 2))` |

## Deploy path inference

Cross-reference **build scripts + Dockerfile presence + vercel/netlify/fly CLI**:

```bash
# Is there a Dockerfile?
gh api repos/<owner>/<repo>/contents/Dockerfile --jq '.download_url // "NOT_FOUND"'

# Is there vercel.json?
gh api repos/<owner>/<repo>/contents/vercel.json --jq '.message // .content'

# Is there a .github/workflows/deploy.yml?
gh api repos/<owner>/<repo>/contents/.github/workflows/deploy.yml --jq '.download_url // "NOT_FOUND"'

# Search for VERCEL / NETLIFY / FLY env references
grep -rEi "VERCEL|NETLIFY|FLY_ROTATION|RAILWAY" --include='*.ts' --include='*.json' --include='Dockerfile' --include='*.yml' .
```

If `Dockerfile` exists AND there's a build:docker-server script AND no vercel.json AND no VERCEL env references → **deploy is self-hosted (Hetzner/DO/AWS EC2/etc.)**.

If `vercel.json` exists OR `VERCEL` env is referenced → Vercel deploy.

## Worked example (2026-07-27, nkzw-tech/athena-crisis)

- 19 workspaces, named after Greek deities — clear role separation
- `apollo` = game actions, `athena` = domain core, `dionysus` = AI
- `ares` = client (React+Vite), `artemis` = server (Express+graphql-yoga+socket.io+Prisma)
- `hermes` = campaign/level logic, `hera` = editor UI, `hera/editor/lib/AIBehaviorLink.tsx` = editor → AI wiring
- `i18n` = 3 files (`AvailableLanguages.tsx`, `Common.ts`, `package.json`), includes `ko_KR`
- `zeus` = composition wrapper (only `package.json`)
- `infra/assets/hetzner.svg` + `build:docker-server` = self-hosted on Hetzner, NOT Vercel

This kind of role-mapping is what the brief-vs-reality probe output should communicate in the "Architecture summary" section.