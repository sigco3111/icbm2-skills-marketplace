# Output templates for github-brief-vs-reality-probe

Three templates for the verdict step. Pick by how badly the brief disagrees with reality.

## Template 1 — Standard (brief mostly correct)

Use when 4+ brief questions match reality with minor deltas.

```markdown
# <owner>/<repo> structure probe

## Per-question results
| # | Question | Result |
|---|---|---|
| 1 | Router | ✅ `<proof>` |
| 2 | i18n | ✅ `<proof>` |
| ... |
| 6 | Vercel config | ⚠️ `<proof>` |

## Architecture summary
- <workspace count> packages, <role split>
- Deploy path: <X>

## Next steps
- <Action item if delta present>
```

## Template 2 — Delta-leading (brief mostly WRONG)

Use when 2+ brief questions disagree with reality. This is the **athena-crisis case** — the brief was wrong on Next.js + Vercel.

```markdown
# <owner>/<repo> structure probe

## ⚠️ Critical delta from brief
The brief assumed **<X>**, but the repo is **<Y>**. Implications:
- <Implication 1: e.g. "Vercel deploy requires architectural rework">
- <Implication 2: e.g. "Next.js routing concepts don't apply">
- <Implication 3: e.g. "AI turn customization target is `dionysus/BaseAI.tsx`, not `aiturn.ts`">

## Per-question results
| # | Question | Brief said | Actual | Proof |
|---|---|---|---|---|
| 1 | Router | Next.js | react-router-dom v7 (Vite SPA) | `ares/package.json` deps |
| 2 | i18n package + languages | (assumed missing) | `@deities/i18n` — 12 langs incl `ko_KR` | `i18n/AvailableLanguages.tsx` |
| 3 | AI turn module | `aiturn.ts` | `dionysus/BaseAI.tsx` + `AIRegistry.tsx` | recursive tree grep |
| 4 | Multiplayer server | (assumed coupled) | Separate `@deities/artemis` workspace | `artemis/package.json` deps |
| 5 | Build/deploy scripts | (assumed vercel) | Vite client + Docker server + offline mobile | `package.json` scripts |
| 6 | Vercel config | (assumed yes) | None — `vercel.json` 404, no VERCEL refs | Contents API + repo grep |

## Architecture summary
- **19 workspaces** (apollo/ares/artemis/athena/deimos/dionysus/hera/hermes/i18n/offline/ui/zeus + tests/codegen/docs/eslint-plugin/fixtures/scripts/art)
- **Client**: `ares` (React 19 + react-router-dom 7 + Vite + Relay)
- **Server**: `artemis` (Express 5 + graphql-yoga 5 + socket.io 4 + Prisma 7 + PostgreSQL + Redis + S3 + Stripe + Discord + Sentry)
- **AI**: `dionysus` (4 AI classes: DionysusAlpha, PersephoneBeta, DiomedesEpsilon, OdysseusDelta)
- **i18n**: `i18n` (fbtee-style, includes `ko_KR` already)
- **Deploy**: Docker (`Dockerfile` + `build:docker-server`), no Vercel/Netlify/Fly

## Open question
"Confirm the brief's assumption (Next.js + Vercel) is now superseded — should I plan Docker-only deployment, or proceed with Vercel migration per the original brief?"
```

## Template 3 — Table-only (very brief answers)

Use when the user explicitly asked for a tight table (e.g. "표로만 답해줘" or memory indicates short-form preference). Even here, **the delta must lead the response** if present — but the body is condensed.

```markdown
# <owner>/<repo> — ⚠️ brief was wrong, repo is Vite SPA + Docker, not Next.js + Vercel

| # | Brief | Actual | File |
|---|---|---|---|
| 1 | Next.js router | react-router-dom v7 (Vite SPA) | `ares/package.json` |
| 2 | i18n package | `@deities/i18n` (12 langs, ko_KR ✅) | `i18n/AvailableLanguages.tsx` |
| 3 | `aiturn.ts` | `dionysus/BaseAI.tsx` + `AIRegistry.tsx` | recursive tree |
| 4 | Multiplayer server | Separate `@deities/artemis` (graphql-yoga+socket.io+Prisma) | `artemis/package.json` |
| 5 | Build/deploy | Vite client + Docker server + offline | root `package.json` |
| 6 | Vercel config | None (no `vercel.json`, no VERCEL refs) | Contents API + grep |

Deploy: Docker only. Vercel needs rework (serverless + Pusher/Ably for socket.io).
```

## Formatting rules (apply to all templates)

1. **Delta block uses `⚠️`** — high visual weight, no risk of being skimmed past
2. **Per-question table uses `✅ / ❌ / ⚠️` glyphs** — adds 5 seconds per row for clarity
3. **Proof column** — every claim has either a file path, command, or line number
4. **Architecture summary is bullet-heavy** — easier to scan than prose
5. **Open question at the end** — explicit invitation to confirm or correct
6. **Never bury the delta in row 6** — even a "small" disagreement (e.g. framework name off by one version) goes at the top
7. **Korean responses** — keep section headers in Korean if user wrote in Korean; technical terms (Vercel, Docker, etc.) stay in English

## Tone rules

- **Factual, not blamey** — "the brief assumed X, but the repo is Y" not "the brief was wrong, sorry"
- **Implications, not just facts** — each delta should explain what it means for the user's downstream plan
- **No padding** — drop greetings, "let me know if you need more", apology for assumptions being off
- **Quantify when possible** — "19 workspaces" not "many packages"; "graphql-yoga 5 + socket.io 4" not "modern server stack"

## Worked example (nkzw-tech/athena-crisis, 2026-07-27)

Full response used Template 2 with Korean summary (architecture summary in Korean since user wrote in Korean). The delta block was the only thing that survived the user's skim — they immediately responded about confirming Vercel rework was out of scope.