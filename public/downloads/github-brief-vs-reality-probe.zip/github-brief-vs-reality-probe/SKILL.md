---
name: github-brief-vs-reality-probe
description: Validate a multi-question repo brief against reality.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [GitHub, repository-analysis, structural-probe, brief-verification, monorepo, pnpm-workspaces, GitHub-API]
---

# github-brief-vs-reality-probe

When a user hands you a GitHub URL and a multi-question structural brief ("router, i18n, AI module, multiplayer server, build/deploy, Vercel config"), the brief **almost always carries baked-in assumptions** — Next.js, App Router, Vercel, "AI turn module is `aiturn.ts`", TypeScript-only, etc. The job is to verify each assumption against the actual repo and **surface the delta prominently** if it disagrees.

**Class-level scope**: distinct from `github-repo-triage` (5-line "worth using?" verdict) and from `github-game-candidate-scouting` (8+ game candidate comparison). This skill is for "deeper-than-triage but no-code-edits-yet" structural probes against one repo.

---

## When to use

- User: "이 저장소 구조 빠르게 점검해줘: 1) 라우터 2) i18n 3) AI 모듈 4) 멀티플레이 5) 빌드/배포 6) Vercel 설정"
- User: "이거 Next.js로 만들어진 거 맞지? 구조 좀 봐줘" (where the assumption is the whole point)
- User: "deploy가 Vercel로 되나 확인해줘" (and the repo turns out to be Docker-only)

**Not for**:
- "이거 뭐하는 거야?" / "사용할만 할까?" → `github-repo-triage`
- "PR #N 리뷰해줘" → `github-pr-workflow` / `github-code-review`
- "fork해서 한국어화" → `oss-fork-localization`
- 8+ 후보 비교 → `github-game-candidate-scouting` (게임) / `open-source-similar-finder` (비교)

---

## Workflow

### Step 1 — Top-level inventory (5 sec)

```bash
gh api repos/<owner>/<repo>/contents --jq '.[] | "\(.type)\t\(.name)"'
```

Note: directories whose top-level Contents response looks suspicious (size 0, sha looks like a blob not a tree) need recursive verification — see Pitfall #1.

### Step 2 — Recursive tree for the real shape (15 sec)

```bash
gh api 'repos/<owner>/<repo>/git/trees/<branch>?recursive=1' --jq '.truncated, (.tree | length)'
# truncated=false is the green light — everything fetched in one call

# Count by top-level prefix (reveals monorepo role split at a glance)
gh api 'repos/<owner>/<repo>/git/trees/<branch>?recursive=1' --jq '
  [.tree[].path | split("/")[0]] | group_by(.) | map({top: .[0], count: length}) | sort_by(-.count)'
```

### Step 3 — Read manifests (30 sec)

```bash
# Root manifest — name, scripts, dev/peer deps
gh api repos/<owner>/<repo>/contents/package.json --jq '.content' | base64 -d

# Workspace list — check ALL three flavours (pnpm/yarn/npm)
gh api repos/<owner>/<repo>/contents/pnpm-workspace.yaml --jq '.content' | base64 -d
gh api repos/<owner>/<repo>/contents/package.json --jq '.content' | base64 -d | jq -r '.workspaces[]?'

# Each workspace's package.json: name + key framework deps
for ws in <workspace-1> <workspace-2> ...; do
  echo "=== $ws ==="
  gh api "repos/<owner>/<repo>/contents/$ws/package.json" --jq '.content' | base64 -d \
    | jq -r '"  name: \(.name)\n  deps: [\( .dependencies | keys | join(", ") )]"'
done
```

For full pnpm workspace patterns (root + workspace roles, common `scripts` keys, inter-workspace `workspace:*` deps), see `references/pnpm-monorepo-checklist.md`.

### Step 4 — Prove-or-disprove each question in the brief

For each item in the brief, run the smallest command that can prove YES or NO. Library of proof patterns:

| Brief asks... | Quick proof (YES) | Negative proof (NO) |
|---|---|---|
| "Is it Next.js?" | `gh api .../contents/<pkg>/package.json \| jq '.dependencies.next'` | grep `next/dist\|pages/\|app/` across the tree |
| "i18n package + languages" | read `i18n/AvailableLanguages.tsx` (or `locales/`) — language map | `find . -name '*.po' -o -name 'translations/*.json'` |
| "AI module location" | recursive tree `contains("ai") or contains("AI")` | `gh api .../git/trees/<branch>?recursive=1 \| jq '[.tree[] \| select(.path \| test("ai\|AI"))]'` |
| "Multiplayer server separation" | list workspace packages, look for `socket.io`, `graphql-yoga`, `express`, `prisma` in deps | `grep -r "socket.io" --include='package.json' .` |
| "Build/deploy scripts" | read root `package.json` `scripts` | `grep '"deploy\|"vercel\|"publish' <root>/package.json` |
| "Vercel config" | `gh api .../contents/vercel.json` (404 = doesn't exist) | `grep -r "VERCEL" --include='*.ts' --include='*.json' .` |
| "Docker deploy" | `gh api .../contents/Dockerfile` | `grep -E '^FROM\|RUN docker' .github/workflows/*.yml` |

### Step 5 — Cross-verify when Contents API looks empty

**Critical pitfall**: GitHub Contents API sometimes returns just one entry for a directory that `git clone` shows has dozens — this is a documented GitHub quirk on certain monorepo layouts. Reproduction recipe + diagnosis flow:

```bash
# 1. Notice: Contents API returns 1 entry but recursive tree shows many
gh api repos/<owner>/<repo>/contents/artemis --jq 'length, .[].name'
# → 1, "package.json"

gh api 'repos/<owner>/<repo>/git/trees/main?recursive=1' --jq \
  '[.tree[] | select(.path | startswith("artemis/")) | .path] | length'
# → 1173 / 1 for just the top-level dir

# 2. Cross-verify with local clone
rm -rf /tmp/<repo>-probe
git clone --depth 1 https://github.com/<owner>/<repo>.git /tmp/<repo>-probe
find /tmp/<repo>-probe/artemis -maxdepth 2 -type f | head
# → reveals the actual source tree

# 3. Cleanup
rm -rf /tmp/<repo>-probe
```

This is **not** a submodule (sha is a tree, not a gitlink), not a permission issue. Treat Contents API as "may be incomplete for monorepo layout X"; always cross-check the recursive tree before drawing conclusions.

### Step 6 — Write the verdict

**Lead with the delta when brief disagrees with reality**. Burying the contradiction in the per-question table leads the user to skim and miss it.

Full templates (standard / delta-leading / table-only) in `references/output-templates.md`. Core shape:

```markdown
# <Repo> structure probe

## ⚠️ Critical delta from brief  (only when present)
The brief assumed **<X>**, but the repo is **<Y>**. Implications:
- <bullet 1>
- <bullet 2>

## Per-question results
| # | Question | Result |
|---|---|---|
| 1 | Router / framework | ✅/❌/⚠️ <one-line proof> |
| ... |

## Architecture summary
- <workspace count> packages, <role split>
- Deploy path: <Docker / Vercel / etc.>

## Open question
"Confirm the brief's assumption or correct it before proceeding."
```

---

## Pitfalls (must-avoid)

1. **Contents API empty-dir trap** — see Step 5 above. Cross-verify with `git clone --depth 1` before declaring a package "minimal/empty".
2. **`pnpm-workspace.yaml` ≠ `package.json#workspaces`** — pnpm uses its own file; check both. A repo can have root `package.json` without `workspaces:` AND a `pnpm-workspace.yaml`.
3. **`recursive=1` truncation** — very large repos (100k+ files) return `truncated: true`. Paginate via `tree_sha` in `tree.truncated` if seen.
4. **Workspace `package.json` ≠ source dir** — monorepos often have `<ws>/` (source) and `<ws>/package.json` (manifest). Always `find <ws> -maxdepth 2 -type f` after locating workspaces.
5. **Grepping for `next.config.*` is a strict YES/NO** — if a Vercel-style Next.js project has been Ejected to Vite/Express, there is no `next.config.*` at all. Don't grep recursively in `node_modules`.
6. **`dev:server` script reveals server entry, not the server workspace** — `dev:server: PORTLESS_APP_PORT=3032 portless api.X ./artemis/artemis.tsx` tells you the entry file, even if `artemis/` Contents API looks empty.
7. **Don't trust brief's filename guesses** — if the brief says "AI turn module should be at `aiturn.ts`", the real module might be `BaseAI.tsx` in a different package. Search by **class/feature name** (`BaseAI`, `AIBehavior`, `AIRegistry`) not by filename.
8. **Public REST API rate limit** — 60 calls/hour/IP unauthenticated. This workflow uses ~10-15 calls per probe. For private repos with high-volume probing, set `GITHUB_TOKEN`.
9. **Cleanup is mandatory** — the `git clone --depth 1 /tmp/...` step leaves hundreds of MB. `rm -rf /tmp/<repo>-probe` at the end.

---

## Anti-patterns

- ❌ Filling out the brief's table even when assumption is wrong — the delta MUST lead the response
- ❌ "Verifying with `git clone`" → leaving the clone in `/tmp` forever
- ❌ Trusting the brief's filename (`aiturn.ts`) — always cross-check
- ❌ Outputting the per-question table without ✅/❌ glyphs — adds 5 seconds per row for clarity
- ❌ "Yes/No" without proof citation (file path, command, line number) — every claim must be traceable

---

## Worked example (2026-07-27, nkzw-tech/athena-crisis)

**Brief**: "Check Next.js router, i18n package + languages, AI turn module, multiplayer server, build/deploy scripts, Vercel config."

**Actual repo**: Vite+react-router-dom SPA + graphql-yoga/socket.io server + Docker deploy. No Vercel. No Next.js.

**Delta leading the response**: "Brief assumed Next.js+Vercel — repo is Vite SPA + Docker. Implication: Vercel deploy requires architectural rework (serverless functions + Pusher/Ably replacement for socket.io)."

**Per-question**: 6-row table with proofs. Notable: AI module is `dionysus/BaseAI.tsx` + `AIRegistry.tsx` (not `aiturn.ts`); i18n already includes `ko_KR`; multiplayer server is separate `@deities/artemis` workspace.

See `references/output-templates.md` for the full output shape and `references/pnpm-monorepo-checklist.md` for the workspace interpretation details.

---

## References

- `references/pnpm-monorepo-checklist.md` — pnpm workspace patterns, common role splits (client/server/AI/i18n/UI), inter-workspace `workspace:*` dep interpretation
- `references/output-templates.md` — three output templates: standard / delta-leading / table-only, plus the worked example full output