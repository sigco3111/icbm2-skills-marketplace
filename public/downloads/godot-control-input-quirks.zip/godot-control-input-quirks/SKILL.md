---
name: godot-control-input-quirks
description: Godot 4 Control 노드의 마우스 입력 / 클릭 / 호버 / 패널 표시 함정 — Area2D vs TextureButton, PanelContainer 부모/자식 visible 동기화, **PanelContainer 동적 추가 시 anchor 4-값 명시 필수 (v4.0.1 회귀 교훈)**, 사이즈 변경 시 누적 위치 보정, 픽셀 누적 shift. "호버 안 됨", "클릭 안 됨", "모달 안 보임", "캐릭터가 좌측상단으로 이동", "Panel 안 보임", "자식이 좌상단에 뭉침", "anchor 미명시로 layout 깨짐" 같은 마우스/시각 관련 버그에 발동.
category: creative
trigger: "Godot 4 Control mouse event not firing, TextureButton vs Area2D, PanelContainer visible parent child sync, character drift on hover, control position offset accumulation, hover scale bug, modal not showing, Panel not visible despite visible VBox, visible parent not enabling visible child, **PanelContainer anchor 4-value missing, child VBox anchor_left top not set, card label text clustered at top-left, UI completely broken after dynamic panel addition**"
---

# Godot 4 Control Input Quirk Patterns

> Godot 4 Control 노드의 **마우스 입력 + 호버 + 시각 표시**에서 자주 발생하는 함정 3종을 카테고리화. 모든 함정은 v1의 `last-banner` v2.3.x cycle (2026-07-16) 실전 검증됨.

## 함정 1: Sprite + Area2D는 Control 부모에서 작동 안 함 (마우스 입력 미수신)

**증상**: Sprite2D + Area2D + CollisionShape2D 콤보 만들었는데 Control 부모 (PanelContainer/SceneHost 등) 안에서 마우스 호버/클릭이 절대 발화 안 함. LB_VERIFY 헤드리스에선 시그널 연결 정상처럼 보이지만 사용자 화면에선 무반응.

**원인**: Godot 4의 Area2D `input_event`는 Node2D 가계 input dispatcher를 따름. Control 부모 안의 `Control > Node2D > Area2D` 트리에서는 input이 Control 가계로 가로채여 Area2D에 안 옴.

**해결**: Control 부모 환경에선 `TextureButton` (Control 기반) 사용. 같은 Control input dispatcher 통합이라 호환 보장.

```gdscript
# 각 캐릭터/클릭 가능 객체 = TextureButton 1개
var btn := TextureButton.new()
btn.texture_normal = tex
btn.texture_pressed = tex
btn.texture_hover = tex
btn.texture_focused = tex
btn.ignore_texture_size = true
btn.position = pos - Vector2(tex.get_width() * scale / 2, tex.get_height() * scale / 2)
btn.size = Vector2(tex.get_width() * scale, tex.get_height() * scale)
btn.custom_minimum_size = btn.size
btn.mouse_filter = Control.MOUSE_FILTER_STOP
parent.add_child(btn)
btn.mouse_entered.connect(_on_hover.bind(character))
btn.mouse_exited.connect(_on_unhover.bind(character))
# 클릭 안 쓸 거면 pressed 시그널 의도적 연결 안 함 (사용자 명세에 따름)
```

**판단 기준 (어떤 부모에 무엇 쓸지)**:

| 부모 | 정답 | 이유 |
|---|---|---|
| Control 부모 (PanelContainer/SceneHost/Control 기반 씬) | **TextureButton** | 같은 Control 트리 |
| Node2D 부모 (게임 월드 자유 카메라) | Area2D + RectangleShape2D | Sprite2D와 input dispatcher 통합 |
| 둘 다 (Node2D + Control 자식 혼재) | TextureButton 우선 | 사용자 PC 호환성 |

**TextureButton에 존재하지 않는 속성 (할당 시 에러)**:
- `btn.stretch = true` ❌ — 존재하지 않음
- `btn.expand_icon = true` ❌ — 존재하지 않음
- 해결: 그냥 빼고 `ignore_texture_size` + `size`/`custom_minimum_size` 설정으로 충분

## 함정 2: PanelContainer는 부모+자식 모두 visible=true여야 보임

**증상**: PanelContainer 안에 VBox 넣고 자식 VBox의 `visible = true` 했는데 화면에 Panel 안 보임. 빈 패널만 보임 또는 아예 안 보임.

**원인**: Godot Control 가시성: 부모 `visible = false`이면 그 자식 아무리 visible이어도 화면 안 나옴. 단, 부모 `visible = false`이어도 자식의 `visible = true`가 **다른 곳에서** 보장 안 됨 (Godot 부모-자식 가시성 룰).

**해결 — 이중 안전망**: 부모 PanelContainer + 자식 VBox 둘 다 같이 토글. **절대 자식만 true로 끝내지 말 것**.

```gdscript
# 모달 열기
func _show_modal() -> void:
    if detail_panel:
        detail_panel.visible = true       # ← 부모
    if detail_vbox:
        detail_vbox.visible = true        # ← 자식
    _populate_content()

# 모달 닫기
func _hide_modal() -> void:
    if detail_vbox:
        detail_vbox.visible = false
    if detail_panel:
        detail_panel.visible = false       # ← 부모

# _find_nodes()에서도 시작 시 명시
if detail_panel:
    detail_panel.visible = false   # tscn이 visible 명시 안 하면 기본 true
    detail_vbox = detail_panel.get_node_or_null("VBox") as VBoxContainer
    if detail_vbox:
        detail_vbox.visible = false
```

**tscn에도 명시 권장** (런타임 race 방지):
```ini
[node name="DetailPanel" type="PanelContainer" parent="..."]
visible = false           # ← 추가
anchor_left = 0.5
# ...
```

**진단 패스트 5단계** (Panel 안 보일 때):
1. `var p = get_node_or_null(...)` not null?
2. `print("[Modal] 표시 log")` 호출?
3. LB_VERIFY에서 `assert(detail_panel.visible)` 통과?
4. tscn에 `visible = false` 명시?
5. `parent.visible = true` 명시? (자식만 true로 끝내지 않았는지)

## 함정 4: Control 자식을 Node2D 직속 또는 Node2D 부모 아래에 두면 가시성 토글 비정상

**증상**: `BattleScene`(Control)을 `Main`(Node2D) 직속 자식으로 인스턴스화. `battle.visible = true` 설정해도 화면에 안 뜸 — 코드 측 진입은 정상 (예: `print("[Battle] start_battle")`), LB_VERIFY도 패스. 하지만 실제 .app에서 무반응.

**원인**: Godot 4의 Control 가시성 토글은 **Control 부모 안에서** 안정 작동. `Node2D` 직속 자식이거나 `Node2D > Control` 트리일 때 `Control.visible = true`가 가끔 무시됨 (Godot가 Control 가시성 처리를 정상적으로 못 함).

**해결 — Control은 반드시 CanvasLayer 또는 Control 부모 안에 둘 것**:

| 부모 트리 | Control 가시성 토글 | 권장 |
|---|---|---|
| `CanvasLayer > Control` | ✅ 안정적 | ✅ 권장 (UI 스크린) |
| `Control > Control` | ✅ 안정적 | ✅ 권장 (UI panel 안) |
| `Node2D > Control` | ⚠️ 불안정 | ❌ 비권장 |
| `Node2D > Control > sub_Control` | ⚠️ 거의 안 됨 | ❌ 비권장 |

**올바른 패턴** — 게임 루트 안의 sub-씬(Control PackedScene) 두려면:
```gdscript
# scenes/main.tscn 구조 예시
[node name="GameRoot" type="Node2D"]

[node name="ManorLayer" type="CanvasLayer" parent="GameRoot"]
layer = 0           # 게임 HUD/세계 (낮음)
[node name="ManorDashboard" parent="ManorLayer" instance=ExtResource("manor_dashboard.tscn")]

[node name="TitleLayer" type="CanvasLayer" parent="GameRoot"]
layer = 5           # 타이틀 (manor 위)
[node name="TitleScreen" parent="TitleLayer" instance=ExtResource("title_screen.tscn")]

[node name="BattleLayer" type="CanvasLayer" parent="GameRoot"]
layer = 90          # 전투 (모달 아래)
[node name="BattleScene" parent="BattleLayer" instance=ExtResource("battle_scene.tscn")]

[node name="UI" type="CanvasLayer" parent="GameRoot"]
layer = 10          # 자원바/버튼 행
visible = false
```

**`main.gd` 동적 라우팅 헬퍼** (Layer 통과):
```gdscript
func _get_control_scene(node_name: String) -> Control:
    # CanvasLayer 자식 우선, Node2D 직속 fallback
    for child in get_children():
        if child is CanvasLayer:
            var found := child.get_node_or_null(node_name)
            if found and found is Control:
                return found
    for child in get_children():
        if child.name == node_name and child is Control:
            return child
    return null
```

**진단 — Control 보이지 않을 때**:
1. `Control`의 부모 트리 path 인쇄: `print(get_path())`
2. `Node2D` 직속 또는 `Node2D` 어딘가에 있지 않은지 확인
3. 해결: `CanvasLayer` 한 단계 더 감싸기

## 함정 5: PanelContainer 안에 VBox 자식 — anchor 4-값 미명시 시 layout 망가짐 (v4.0.1 회귀)

**증상**: Card 안에 Label이 좌상단 (0,0)에 뭉침. 모달 안의 DimBG만 보이고 내용은 안 보임. 사용자가 "UI가 완전히 망가졌음" + 스크린샷으로 즉각 인지.

**근본 원인**: `PanelContainer` 안에 `VBoxContainer` 자식을 둘 때, 자식의 `anchor_right/bottom`만 명시하고 `anchor_left/top`을 기본값(0)으로 두면 부모 안에서 사이즈가 0이 됨.

```gdscript
# ❌ 망가짐 — anchor_left/top = 0 (기본값), right/bottom = 1.0 → 사이즈 0
[node name="CenterCard" type="PanelContainer" parent="."]
anchor_left = 0.5; anchor_top = 0.5; anchor_right = 0.5; anchor_bottom = 0.5
offset_left = -290; offset_top = -240; offset_right = 290; offset_bottom = 240

[node name="CenterBox" type="VBoxContainer" parent="CenterCard"]
anchor_right = 1.0; anchor_bottom = 1.0
# anchor_left/top 누락 → (0, 0) 위치에 0 사이즈

# ✓ 안전 — anchor 4-값 모두 명시
[node name="CenterBox" type="VBoxContainer" parent="CenterCard"]
anchor_left = 0.0; anchor_top = 0.0
anchor_right = 1.0; anchor_bottom = 1.0
```

**v4.0.1 회귀 후 안전 패턴**:
1. 기존 검증된 PanelContainer 구조는 그대로 유지
2. 동적 추가 (예: 모달/튜토리얼) 시 anchor 4-값 명시
3. `add_theme_stylebox_override` + 색상 매핑은 안전 (구조 변경 X)
4. 시각 회귀 시 → LB_VERIFY + 사용자 Mac 데스크탑 스크린샷으로 양쪽 검증

**함정 5 + 함정 4 조합 진단** — PanelContainer가 보이지 않거나 자식이 좌상단 뭉침:
1. `parent.get_path()` 인쇄로 부모가 Node2D인지 확인
2. PanelContainer의 tscn에서 anchor 4-값 명시 여부
3. 자식 VBox의 anchor 4-값 명시 여부
4. 둘 다 OK인데 안 보이면 → 함수 2의 "이중 안전망" 패턴 (visible 부모+자식 둘 다)

## 함정 3: 사이즈 변경 + 누적 위치 보정 시 캐릭터 좌상단으로 drift

**증상**: 호버하면 sprite가 1.08배 커지는데, 매 hover마다 **sprite가 좌측상단으로 조금씩 누적 이동**. 한참 호버/언호버 반복하면 캐릭터가 화면 모서리까지 날아감.

**원인**: 사이즈 키워도 position 그대로 두면 sprite 좌상단 모서리가 그대로 있음. 매번 `(current_pos - delta/2)` 보정시:
- 1차: position (200, 200), 보정 후 (200 - 4, 200 - 4) = (196, 196). OK.
- 2차: position (196, 196)에서 보정 (이미 보정된 값) → (196 - 4, 196 - 4) = (192, 192) ← 누적

**해결 — 절대 좌표 저장 패턴**:

```gdscript
# 캐릭터 dict 생성 시점에 original_position을 1회만 저장
var character := {
    "button": btn,
    "original_size": btn.size,
    "original_position": btn.position,    # ← 절대 기준점
    "is_hovered": false,
}

func _on_hover(character: Dictionary) -> void:
    character["is_hovered"] = true
    var orig_size: Vector2 = character["original_size"]
    var orig_pos: Vector2 = character["original_position"]   # ← 절대값
    var boosted: Vector2 = orig_size * (1.0 + HOVER_SCALE_BOOST)
    var delta: Vector2 = (boosted - orig_size) * 0.5
    character["button"].size = boosted
    character["button"].position = orig_pos - delta    # ← 절대값 기준 1회 보정

func _on_unhover(character: Dictionary) -> void:
    character["is_hovered"] = false
    character["button"].size = character["original_size"]        # ← 복원
    character["button"].position = character["original_position"]  # ← 절대 좌표 복원 (누적 X)
```

**더 안정적인 대체 패턴 — `pivot_offset` + `scale`** (Control 노드):
```gdscript
func _on_hover(character):
    character["is_hovered"] = true
    var btn: TextureButton = character["button"]
    btn.pivot_offset = btn.size * 0.5              # 중심 pivot
    btn.scale = Vector2(1.08, 1.08)                # 시각적 확대

func _on_unhover(character):
    character["is_hovered"] = false
    character["button"].scale = Vector2.ONE         # 축소
    # size, position 그대로 — 끝
```

위 패턴은 **size/position 둘 다 그대로 유지**하면서 시각적 확대만 함. 코드 단순, 누적 없음.

**모든 호버/언호버 페어가 original_position을 절대값으로 복원하는지 검증하는 헬퍼**:
```gdscript
# LB_VERIFY에 추가
assert(md.scene_characters[0]["original_position"] != Vector2.ZERO, "original_position 1회 저장 확인")
md._on_hover(md.scene_characters[0])
var pos_after_hover = md.scene_characters[0]["button"].position
md._on_unhover(md.scene_characters[0])
var pos_after_unhover = md.scene_characters[0]["button"].position
assert(pos_after_unhover == md.scene_characters[0]["original_position"], "언호버 후 원래 위치 복귀 (누적 X)")
```

## 비교 — 호버 인디케이터 패턴 4가지

| 패턴 | 코드량 | 누적 안전성 | 권장도 |
|---|---|---|---|
| A. size 변경 + position 원본 저장 패턴 | 중간 | ✅ 안전 (절대 좌표) | ✅ 권장 |
| B. pivot_offset + scale | 가장 적음 | ✅ 안전 (size/position 그대로) | ✅ 가장 권장 |
| C. size 변경 + 매번 current - delta 보정 | 중간 | ❌ 누적 drift | ❌ 금지 |
| D. Control._draw() 직접 그리기 | 많음 | ✅ | 정적 이미지에만 |

**핵심 권장**: 본 작업을 Godot 4 Control 위에서 호버/클릭 인터랙션 만들 때 **B (pivot_offset + scale)** 1순위. 1회 사이즈 변경 명확 필요할 때만 A. C는 절대 금지.

## 보너스 — 어떤 객체에 마우스 인터랙션 줘야 할지

| 객체 | Godot 4 정답 |
|---|---|
| 캐릭터 sprite / 단일 이미지 클릭 | **TextureButton** (Control 부모 시) / Area2D (Node2D 부모 시) |
| 풍경도 다중 객체 + 호버 강조 | TextureButton + pivot_offset scale 패턴 |
| 텍스트 라벨 (UI 메뉴 등) | **Button** (Control 기본) |
| 자유 위치 + 카메라 + 다중 객체 | Area2D + 다중 CollisionShape2D |
| 충돌이 필요한 게임플레이 | Area2D + CollisionShape2D (물리엔 필수) |

LB_VERIFY 헤드리스에서 마우스 이벤트 시뮬레이션:
```gdscript
# 클릭 안 쓰는 경우 — _on_hover/_on_unhover 직접 호출로 검증
md._on_hover(character)
await get_tree().process_frame
assert(detail_vbox.visible, "호버 시 panel 표시")
md._on_unhover(character)
await get_tree().process_frame
assert(not detail_vbox.visible, "언호버 시 panel 숨김")
```

## 참고

- v2.3.4 (2026-07-16): 3함정 모두 발견 + 해결 패치 적용. `godot-game-bootstrap` 스킬의 "캐릭터 마우스 인터랙션" 섹션 참조.
- users 2회 연속 같은 함정 (모달 안 뜸, 캐릭터 drift) 보고 → 본 스킬 카테고리화.

## v3.1+ 보충 — UI 패널 겹침 + tscn patch 안전 (Last Banner v3.1, 2026-07-16)

v3.1.0~v3.1.7에서 사용자가 같은 클래스(패널 겹침 + tscn 폭파)를 **7번 반복 지적** → 별도 reference로 분리: `references/godot4-ui-panel-overlap-and-tscn-patch-safety.md`.

**이 reference가 다루는 4가지**:

1. **패널 겹침 4단계 진단 절차** (어떤 2개가 겹치는지 → 트리 시각화 → 해결 옵션 3가지 중 선택 → LB_VERIFY+사용자 시각 확인)
2. **tscn `replace_all=true` 폭파 안전 규칙 4가지** (사용 금지 / patch 후 `git status` / 폭파 시 `write_file`로 통째 재작성 / unique context anchor 2~3줄)
3. **GDScript 파스 오타 5종** (`[...])` `var=...` 끊김 / `print(...%(a,b))` 다중 인자 미지원 / `TextureButton.stretch` 미존재 / `theme_override_*` 인덱스 할당 불가)
4. **표준 UI 안전 패턴 5가지** (write_file 4 anchor 명시 / null 가드 / 패딩+라벨 영역 분리 / 텍스트 유무별 패딩 / HBox 분리)

**v3.1에서 발견된 3가지 실전 클래스 함정** (본 reference에 캡처됨):

- **DetailPanel을 ManorTitle HBox 안에 두면 차트와 우상단 위치 충돌** (HBox가 ManorTitle과 같이 자라서 DetailPanel의 anchor_top=0/anchor_bottom=0 위치가 ManorTitle의 영역 안쪽으로 잡힘). 해결: HBox 밖으로 빼고 ManorTitle/ManorScene/BottomRowInColumn 3층 vertical stack.
- **`replace_all=true`로 manor_dashboard.tscn 폭파** — `manor_title`, `DetailPanel`, `VisitorCard`, `QuickStatsCard`, `BottomRowInColumn`, `Roster*` 9개 노드 한꺼번에 사라짐. `write_file`로 통째 재작성이 안전.
- **차트 안에 텍스트 라벨** (`ChartTitle`이 차트 안 22px 영역) + 패딩 미스매치로 그래프와 겹침. 해결: 텍스트는 차트 **바깥** 별도 `ChartTitleLabel` + 차트 안은 `ChartCanvas`만.

**v3.1.7~v3.1.5 차트 위치 변경 3번 반복 (영지 휘장 옆 → 풍경도 좌상단 → ManorTitle(HBox) 내부 → Roster 밖 ChartRow)**:
- **결론**: HUD 패널(상태창, 차트, 휘장)은 `VBox`/`HBox`의 **형제 노드**로 두고 `parent=` 트리 깊이를 같게 → z-order가 부모 트리 순서로 결정되므로 형제끼리 충돌 안 함.
- **같은 Control에 chart + text label 둘 다 두면** 텍스트가 chart 영역 침범 → 별도 부모 분리.

**LB_VERIFY에 추가 권장 패턴** (v3.1.0~v3.1.7 누적):
```gdscript
# [12.5.5] 차트 검증 — 노드 위치 + visible + queue_redraw 모두 확인
var chart_canvas: Control = get_node_or_null("ManorDashboard/.../ChartCanvas") as Control
if chart_canvas:
    # 위치 assert (anchor+offset) — 새 노드 추가 후 anchor 4개 명시 안 했으면 tscn 폭파
    var expected_anchor_top: float = 0.0
    assert(chart_canvas.anchor_top == expected_anchor_top,
        "ChartCanvas anchor_top 변경 감지 — tscn 폭파 가능성")
    chart_canvas.queue_redraw()
```

