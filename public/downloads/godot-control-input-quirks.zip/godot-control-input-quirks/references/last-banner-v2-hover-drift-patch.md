# v2.3.4 last-banner 호버 디버그 + 누적 drift 패치 노트 (2026-07-16)

## 사용자 보고 (2회)

1. **v2.3.2 푸시 후**: "호버해도 상태창이 안 뜸. 캐릭터 호버시 캐릭터가 좌측상단으로 이동" → detail_panel.visible 명시 + original_position dict 저장 시도 → 푸시
2. **v2.3.3 푸시 후**: "이제 호버해도 상태창이 안 나옴" → detail_panel visible 이중 안전망 → 푸시
3. **v2.3.4 푸시 후**: "원래 됐는데 지금 안 됨" → 한 줄 fix 적용 → 푸시

사용자가 build 캐시 또는 화면 어디서 잘못 보고 있는지 모호. **결정적 3가지를 같은 패치에서 같이 적용**해서 알아서 해결되도록 함.

## 누적 drift 진짜 원인 (코드 재검토)

**v2.3.4 코드 흐름**:
```gdscript
func _on_character_hover(character):
    var orig_pos: Vector2 = character["original_position"]  # ✓ dict에서 읽음
    # boosted delta 계산 후 1회 보정
    character["button"].position = orig_pos - delta

func _on_character_unhover(character):
    character["button"].position = character["original_position"]  # ✓ dict에서 읽음
```

→ 이론상 누적 안 됨. 정상.

**문제는 dict 갱신 시점**: `original_position`이 dict에 처음 push됐을 때 캐릭터 sprite 크기가 default size로 측정됐는데, **그 사이 panel.visible = false 라 reload 또는 다른 시점에 btn.position이 변할 수 있나?** → 의심.

**가장 가능성 높은 진짜 원인**: `_on_character_unhover`에서 `character["is_hovered"] = false` 했지만 **`original_position`이 매번 btn.position 읽음**. unhover 후에 dict["original_position"]을 따로 저장 안 했음 → 다음 hover는 옛날 위치. 또는 **`_find_nodes`에서 새로 캐릭터 dict 만들어 `original_position`이 sprite 생성 시점 btn.position이 아니라 후속 변동된 값**.

→ **dict 생성 시점의 absolute position을 다시 확인하지 않아서 누적처럼 보이는 효과**.

## 결정적 3가지 patch (v2.3.5)

### 1. `_add_unit_sprite`에서 original_position을 sprite가 부모에 부착된 직후 즉시 dict에 복사

```gdscript
# btn scene_root에 add_child 한 다음
scene_root.add_child(btn)
# 원본 위치 — 이 시점에서 abs 좌표를 1회 저장
var orig_pos_imm := btn.position
character["original_position"] = orig_pos_imm
```

### 2. `_on_character_unhover`에서 dict에 명시 저장

```gdscript
func _on_character_unhover(character):
    character["is_hovered"] = false
    var orig_pos = character["original_position"]
    character["button"].size = character["original_size"]
    character["button"].position = orig_pos  # 절대 복원
    # 변동 추적: 다음 hover에서 누락 방지
    character["original_position"] = orig_pos  # 명시 재저장 (또는 빼고 add_child 시점만 신뢰)
```

### 3. `pivot_offset` + `scale` 패턴으로 단순화 (가장 권장)

```gdscript
# _add_unit_sprite에서
btn.pivot_offset = btn.size * 0.5
btn.scale = Vector2.ONE

func _on_character_hover(character):
    character["is_hovered"] = true
    character["button"].scale = Vector2(1.08, 1.08)

func _on_character_unhover(character):
    character["is_hovered"] = false
    character["button"].scale = Vector2.ONE
# size/position 안 건드림 → 절대 누적 안전
```

위 패턴은 **size/position 둘 다 안 건드림** → 좌상단 drift 원천 차단.

## 상태창 DetailPanel 이중 안전망

```gdscript
# _find_nodes()
if detail_panel:
    detail_panel.visible = false           # 부모
    detail_vbox = detail_panel.get_node_or_null("VBox") as VBoxContainer
    if detail_vbox:
        detail_vbox.visible = false         # 자식

# _on_character_hover
if detail_panel:
    detail_panel.visible = true           # 부모 반드시 함께
_show_character_detail(character)         # 자식 내용 + visible=true

# _on_character_unhover
if detail_vbox:
    var any_hovered := false
    for c in scene_characters:
        if c.get("is_hovered", false):
            any_hovered = true
            break
    if not any_hovered:
        detail_vbox.visible = false
        if detail_panel:
            detail_panel.visible = false
```

**tscn에 visible=false 명시** (런타임 race 방지):
```ini
[node name="DetailPanel" type="PanelContainer" parent="CenterRoot/LeftColumn/ManorScene/SceneHost"]
visible = false   # ← 이 줄 반드시
```

## 사용자가 "여전히 안 됨"이라 할 때 checklist

1. **빌드 캐시**: `~/work/last-banner/.godot/` 폴더 삭제 + `godot --headless --import` 재실행 → .app 재빌드
2. **tscn 인스펙터**: Godot 에디터로 열고 `ManorScene/SceneHost/DetailPanel` visible 확인
3. **LB_VERIFY [9.5] 직접 실행**: `LB_VERIFY=1 godot --headless 2>&1 | grep -E "DetailPanel|호버"`로 검증 결과 확인
4. **macOS Gatekeeper**: 첫 실행 시 "확인되지 않은 개발자" 경고 → 시스템 설정 → 보안 → "그래도 열기" 필요
5. **재실행**: `open "build/macos/Last Banner.app"` 후 5초 안에 마우스로 캐릭터에 hover. 모달 떠야 함.

## 핵심 코드 차이 (v2.3.4 → v2.3.5)

`scripts/manor_dashboard.gd`의 3가지 핵심 변경:

1. `_add_unit_sprite` 끝에 `character["original_position"] = btn.position` 명시 (sprite가 부모 container add된 직후)
2. `_on_character_unhover` 끝에 `character["original_position"] = orig_pos` 명시 (직전 absolute 복원)
3. `_on_character_hover` 시작에 `if detail_panel: detail_panel.visible = true` **무조건** (자식이 아닌 부모 PanelContainer)

또는 더 단순하게 — 모든 사이즈 변경을 **pivot_offset + scale** 패턴으로 변환.

**확인 사항**: `godot --headless --quit-after 3 2>&1 | tail` stderr에 ERROR 없는지 + LB_VERIFY [9.5] 호버 시뮬레이션 모두 통과하면 진짜 fix 정상.
