# ngrok + HTTP 서버 외부 청취 패턴

사용자가 **원격 (PC 부재 중 모바일 등)** 에서 AI 생성 음악을 청취해야 할 때.

## 1단계: HTTP 서버 시작 (오디오 디렉토리에서)

```bash
cd /path/to/audio
/usr/bin/python3 -m http.server 8080
```

`hermes-agent` venv의 `python3` 가 아닌 `/usr/bin/python3` (시스템) 사용. venv는 google-auth 모듈 누락 등 문제 있음.

백그라운드 실행 시 `background=true` + `notify_on_complete=false` (long-lived process, 종료 알림 불필요).

## 2단계: ngrok 터널 시작

```bash
ngrok http 8080
```

같은 방식으로 백그라운드.

## 3단계: 공개 URL 추출

```bash
curl -s http://127.0.0.1:4040/api/tunnels
```

ngrok 관리 API. `tunnels[0].public_url` 가 `https://xxxx.ngrok-free.app` 형태.

## 4단계: 한글 파일명 우회

ngrok의 HTTP 서버 (Python `http.server`)는 비-ASCII URL을 404로 응답. 심볼릭 링크로 우회:

```bash
ln -sf 오늘도_잘했어_v1.mp3 preview_v1_full.mp3
ln -sf 오늘도_잘했어_v1_preview.mp3 preview_v1.mp3
```

ASCII 이름으로 접근. `curl -I` 로 200 OK 확인.

## 5단계: 사용자에게 URL 전달

ngrok 무료 도메인 형식: `https://xxxx.ngrok-free.dev` (2026+ 기준)

전달 시 주의사항 명시:
- 첫 접속 시 "Visit Site" 경고 페이지
- 세션 종료 전까지만 유효
- 30초 미리듣기 + 전체 둘 다 제공

## 6단계: 정리 (작업 종료 시)

```bash
pkill -f "http.server 8080"
pkill -f "ngrok"
sleep 1
lsof -i :8080
lsof -i :4040
```

모두 빈 결과면 정리 완료.

## 전체 스크립트 (재사용 가능)

```bash
#!/bin/bash
# 외부 청취 서버 시작
AUDIO_DIR="${1:-$HOME/Music/ai-ballad-workspace/audio}"
PORT="${2:-8080}"

cd "$AUDIO_DIR" || exit 1

# 기존 프로세스 정리
pkill -f "http.server $PORT" 2>/dev/null
pkill -f "ngrok http $PORT" 2>/dev/null
sleep 1

# HTTP 서버
/usr/bin/python3 -m http.server "$PORT" &
HTTP_PID=$!
sleep 1

# ngrok 터널
ngrok http "$PORT" --log=stdout > /tmp/ngrok.log 2>&1 &
NGROK_PID=$!
sleep 4

# URL 추출
URL=$(curl -s http://127.0.0.1:4040/api/tunnels | python3 -c "import json, sys; print(json.load(sys.stdin)['tunnels'][0]['public_url'])")

echo "HTTP PID: $HTTP_PID, ngrok PID: $NGROK_PID"
echo "Public URL: $URL"
echo "Files in $AUDIO_DIR:"
ls -la "$AUDIO_DIR"
```

## Pitfalls

1. **ngrok 무료 플랜** — 트래픽 inspect 경고 페이지 한 번 클릭 필요
2. **세션 종료 시 링크 만료** — 사용자에게 미리 고지
3. **심볼릭 링크 권한** — `$AUDIO_DIR` 에 쓰기 권한 필요
4. **포트 충돌** — 다른 서버가 8080 점유 중이면 다른 포트 사용
5. **Telegram `MEDIA:` 태그가 텍스트로만 출력** — 이 패턴의 fallback
6. **Python venv `python3`는 google-auth 오류** 가능 — `/usr/bin/python3` 시스템 사용

## 대안: 직접 다운로드

ngrok 없이 사용자에게 파일을 직접 받을 수 있는 경우:
- Telegram: `MEDIA:/path/to/file` (작동 안 할 수 있음)
- 이메일 첨부 (대용량 불가)
- 클라우드 업로드 (Google Drive, Dropbox)

ngrok가 가장 단순하고 즉시 작동.
