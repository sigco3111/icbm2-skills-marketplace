---
name: minimax-mmx-music
description: "AI 음악 생성 워크플로우 (mmx CLI music-2.6) - 커버/리메이크, 한국어 가사, 프롬프트 엔지니어링, ngrok 외부 청취. 트리거: 'AI 음악 만들어줘', '커버곡', '원곡 리메이크', 'AI 노래', '음악 생성', 'AI 보컬 곡'."
version: 1.0.0
platforms: [macos, linux, windows]
metadata:
  hermes:
    tags: [music, audio, generation, ai, mmx, lyrics, songs, korean, k-pop, cover, rework]
    related_skills: [kaggle-music-voice-gen, heartmula, music-video-generator]
---

# MiniMax mmx CLI Music Generation

mmx CLI (model: `music-2.6`) 기반 AI 음악 생성 워크플로우. 클라우드 기반이라 로컬 GPU 불필요.

## When to Use

- AI 여성/남성 보컬이 포함된 노래 생성
- 기존 곡의 **커버/리메이크** (시점 변경, 언어 변경, 편곡 변주)
- 한국어 오리지널 곡 (발라드/인디팝/K-pop)
- 사용자 PC가 없어 외부 청취 필요 → ngrok 패턴 사용
- 빠르게 여러 버전 비교/반복

## When NOT to Use

- 순수 TTS (멜로디 없음) → `qwen3-tts` 스킬
- BGM 인스트루멘털만 → mmx `--instrumental` 지원하지만 다른 도구 더 저렴
- 뮤직비디오/영상 제작 → `music-video-generator` 스킬
- 10분+ 장편 → mmx 기본 ~4분 캡

## Prerequisites

```bash
which mmx       # 설치 확인
mmx --version   # 1.0.16+ 권장
mmx auth status # API 키 인증 확인
mmx update      # ⚠️ 반드시 먼저 실행 (버그/신기능)
```

## Workflow

### Phase 1: 요구사항 파악

사용자에게 물어볼 것:
1. **용도** — 개인 감상? 유튜브 업로드? 데모?
2. **원곡** (커버 시) — 가수, 곡명
3. **방향** — 무드, 보컬 스타일, 템포, 악기
4. **가사** — 사용자 제공? AI 생성? 한국어 오리지널? 번역?

### Phase 2: 커버 시 — 원곡 분석

찾을 정보:
- **BPM** (Spotify stats, musicstatsforspotify.com) — 117 BPM 왕치치 곡의 핵심
- **Key** (Chordify, 음악이론 포럼)
- **코드 진행** (Chordify, Ultimate Guitar) — 왕치치 곡: C#m-A-B-E
- **구조** (Verse/Chorus 개수, 길이)
- **가사 테마/메시지** (genius.com, 블로그)

**⚠️ Critical pitfall:** 사용자는 **구조적 충실도**(BPM, key, 후렴 구조)를 강하게 요구합니다. "원곡과 동떨어진 느낌"이라는 피드백은 BPM이나 key가 맞지 않을 때 자주 나옵니다. 창작적 재해석을 해도 원곡의 골격은 유지하세요.

### Phase 3: 브레인스토밍 (생성 전에 필수)

**창작 작업에서는 항상 먼저 브레인스토밍.** 형식:
- 방향 A, B, C 2~3개 제시 (각각 콘셉트/톤/편곡/보컬 한 줄 설명)
- 사용자 선호와 연결하여 추천
- 사용자가 하나 고르거나 하이브리드 요청

예시 구조 (왕치치 곡 커버 시):
- A. 연인에게 (원곡에 가장 가까운 따뜻한 러브송)
- B. 자기 자신에게 (자위 + 위로)
- C. 가족/사회에게
- 각 방향마다 가사 샘플 4~8줄 미리 제시

### Phase 4: 가사 작성

UTF-8 `.txt` 파일에 구조 태그 사용. `templates/lyrics-template.txt` 참고.

**태그 목록:** `[Intro] [Verse 1] [Pre-Chorus] [Chorus] [Verse 2] [Bridge] [Outro] [Post-Chorus] [Interlude] [Hook] [Inst] [Solo]`

**제약:** 가사 3500자 이하. 태그 안에는 설명 금지 (그대로 노래함).

`wc -c` 로 미리 체크.

### Phase 5: mmx 명령어 구성

`references/prompt-template.md` 의 파라미터 레퍼런스와 한국어 발라드 레시피 참고.

핵심 파라미터:
- `--prompt`: 스타일 묘사 (2000자 이하)
- `--vocals`: 보컬 타입
- `--genre` / `--mood` / `--instruments`
- `--tempo` + `--bpm` (둘이 일치해야 함)
- `--key` (D major, C#m, A minor 등)
- `--references`: 참고 트랙 1~3개
- `--lyrics-file` / `--out` / `--aigc-watermark`

### Phase 6: 생성

```bash
mmx music generate \
  --prompt "..." \
  --vocals "..." \
  --lyrics-file lyrics.txt \
  --out output.mp3 \
  --aigc-watermark
```

타임아웃 600초 권장.

### Phase 7: 검증 + 미리듣기

```bash
ls -la output.mp3
ffprobe -v error -show_format output.mp3 | grep -E "duration|bit_rate"

# 30초 미리듣기
ffmpeg -y -i output.mp3 -ss 0 -t 30 -c:a libmp3lame -b:a 96k \
  -ac 1 -ar 22050 output_preview.mp3
```

### Phase 8: 외부 청취 (사용자가 PC 없을 때)

`references/ngrok-delivery.md` 참고:
1. `python3 -m http.server 8080` (오디오 디렉토리에서)
2. `ngrok http 8080` (백그라운드)
3. `localhost:4040/api/tunnels` 에서 공개 URL 추출
4. 비-ASCII 파일명은 ASCII 심볼릭 링크로 우회
5. URL을 사용자에게 전달

### Phase 9: 반복

피드백 패턴:
- "원곡과 동떨어진 느낌" → 원곡 BPM/key/구조 반영
- "v1 좋고 v2 BPM 좋음" → 하이브리드 v3 생성
- "분위기는 좋은데" → 편곡은 유지, 다른 요소 변경

**3 버전 후 사용자에게 중단/백업 여부 물어볼 것.**

## Hybrid Version Pattern

사용자가 "v1 좋고 v2 BPM 좋음" 식의 피드백을 주면:
1. 각 버전에서 유지할 요소 식별 (가사, 무드, BPM, key, 편곡)
2. 결합한 v3 프롬프트 작성
3. 승리한 가사는 변경 없으면 그대로 재사용

## Backup Pattern

작업 종료 전 항상 백업:

```bash
BACKUP_DIR=/path/to/workspace/backup_$(date +%Y-%m-%d)
mkdir -p $BACKUP_DIR/{audio,lyrics}
cp audio/*.mp3 $BACKUP_DIR/audio/
cp lyrics/*.txt $BACKUP_DIR/lyrics/
```

README.md 작성 항목:
- 버전별 비교 표 (분위기/BPM/Key/길이/평가)
- 사용된 프롬프트 히스토리 (재현 가능성)
- 다음 버전 후보 메모
- 외부 링크 만료 안내

## Common Pitfalls

1. **로컬 도구 확인 없이 "못함" 단정 금지** — `which mmx`, `mmx --help` 우선 확인
2. **mmx 업데이트 누락** — `mmx update` 항상 먼저
3. **한글 파일명 HTTP URL → 404** — ASCII 심볼릭 링크 우회
4. **ffmpeg `libopus` 미설치** — OGG는 `opus` 코덱 사용
5. **Telegram `MEDIA:` 태그 미작동 가능** — ngrok fallback
6. **커버 시 원곡 충실도 무시** — BPM/key 매칭
7. **가사 3500자 초과** — `wc -c` 사전 체크
8. **태그 안에 설명** — `[Chorus]` OK, `[Chorus - 밝게]` ✗ (그대로 노래함)
9. **v3+는 처음부터 시작 금지** — 피드백 합성
10. **작업 종료 전 백업 누락** — 사용자가 자주 요청

## User-Specific Notes

- **품질 기준 높음** — 첫 결과물이 "엉망"이면 처음부터 다시 시작 결정
- **하이브리드 선호** — "v1 좋고 v2 BPM 좋음" 식 피드백 빈번
- **브레인스토밍 우선** — 생성 전에 옵션 제시 필수
- **원곡 분석 후 작업** — 커버곡은 원곡의 BPM/key/구조 매칭

## References

- `references/prompt-template.md` — 풀 파라미터 레퍼런스 + 한국 발라드 레시피 3종
- `references/ngrok-delivery.md` — ngrok + http.server 외부 청취 패턴
- `references/cover-workflow.md` — 커버/리메이크 작업 상세 절차
- `templates/lyrics-template.txt` — 가사 스타터 파일
