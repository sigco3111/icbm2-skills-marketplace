---
name: korean-ballad-from-reference
description: "한국어 AI 창작 발라드 생성 — 원곡 메시지/분위기를 참고해 새 가사/제목으로 mmx CLI 음악 생성"
version: 1.0.0
platforms: [macos, linux]
metadata:
  hermes:
    tags: [music, audio, generation, ai, korean, ballad, mmx, lyrics]
    related_skills: [heartmula, kaggle-music-voice-gen]
---

# 한국어 AI 창작 발라드 — 원곡 리스펀스 워크플로우

## Overview
참고할 원곡(중국어/일본어/영어/한국어 무관)의 **분위기·구성·메시지**만 빌려와서, **완전히 새로운 한국어 가사 + 새 제목**으로 AI 창작곡을 만드는 워크플로우. 표절 없이 "원곡의 영감"만 차용한 세련된 결과물을 만든다. 주 도구는 `mmx music generate` (MiniMax 회사 CLI).

## When to Use
- 사용자가 특정 곡의 분위기/분위기를 빌려서 **새 창작곡**을 원할 때
- 한국어 가사 + 여성 보컬 발라드를 빠르게 시안(試案) 내고 싶을 때
- 개인 감상/유튜브 업로드용 AI 음악 시안이 필요할 때
- "원곡은 좋은데 한국어 버전이 듣고 싶다"가 **아님** (그건 커버지 창작이 아님)

## 핵심 원칙
1. **리스펀스 ≠ 커버**: 멜로디/가사 재해석 OK, 원곡 음역 그대로 복사 X
2. **제목 차별화**: 원곡 제목과 결이 달라야 함 (예: 왕치치 "평범하게 네 곁에 있고 싶어" → 창작 "오늘도 잘했어")
3. **가사 콘셉트 3분기**: 방향이 다른 3개 초안을 먼저 제시 → 사용자 선택 → 다듬기
4. **순수 AI 보컬** 선호 시 `--instrumental` 절대 금지, 보컬 톤 명시

## 워크플로우 (5단계)

### Step 1: 원곡 분석
- 코드 진행 / BPM / 분위기 키워드
- 메시지 핵심 한 줄
- 한국어 가사로 재해석 시 살릴 감정 포인트

### Step 2: 사용자 컨셉 확인
다음을 한 번에 묻기:
1. 분위기 (따뜻한 발라드 / 로맨틱 / 위로·힐링 / 이별 등)
2. 가사 방향 (연인 / 자기 위로 / 일상 / 회상)
3. 참고 보컬 톤 (IU / 폴킴 / 이하이 / 김세정 / 볼빨간사순기 등)
4. 용도 (개인 감상 / 유튜브 / 정식 음원)
5. 보컬 형태 (순수 AI / 직접 부르기)

### Step 3: 가사 콘셉트 3분기
- **콘셉트 A/B/C** — 3개 방향성 다른 초안
- 각각 후렴 멜로디 흐름이 다른 식
- 한국어 자연스러움 최우선 (한자/한문 최소화)
- **구조 태그 필수**: `[Intro] [Verse 1] [Pre-Chorus] [Chorus] [Verse 2] [Bridge] [Outro]`
- 가사 길이: **800~1000자** (mmx는 3500자까지 허용하지만 적정 분량은 4분 기준)
- 마지막 단계에서 새 제목도 함께 제안 (원곡과 결이 다른 후보 3~4개)

### Step 4: mmx 음악 생성
```bash
mmx music generate \
  --prompt "Korean warm piano ballad, soft indie pop, late night comfort, healing and gentle, emotional female vocal, soft strings, brushed drums, lo-fi warmth, 70 BPM, D major" \
  --vocals "warm female soprano, soft and breathy, gentle vibrato, emotional and comforting, Korean vocal style" \
  --genre "k-pop ballad, indie pop" \
  --mood "warm, comforting, healing, intimate" \
  --instruments "piano, soft strings, brushed drums, subtle bass, light pad" \
  --tempo "slow" \
  --bpm 70 \
  --key "D major" \
  --references "IU Love poem, IU Through the Night" \
  --lyrics-file /path/to/lyrics.txt \
  --out /path/to/output.mp3 \
  --aigc-watermark
```

### Step 5: 피드백 루프
- 결과물 전달 (mp3)
- 사용자 피드백 받기: 분위기 / 발음 / 길이 / 편곡
- v2 재생성 (BPM/보컬 톤/악기 강조 변경)

## Pitfalls
1. **`mmx music generate` 3500자 가사 제한** — 4분 기준 800~1000자가 안전. 너무 짧으면 길이 못 채움.
2. **`--aigc-watermark` 플래그** — 유튜브/공유 시 권장 (AI 생성 표시). 빼도 동작은 함.
3. **`--output-format url`** — 24시간 만료 URL. 파일 저장이면 기본 hex.
4. **BPM 70~80** — 따뜻한 발라드의 sweet spot. 너무 느리면 늘어지고 빠르면 긴장됨.
5. **한국어 발음** — music-2.6 모델은 한국어 지원하지만 가사가 너무 빨라지지 않게 호흡 단위로 끊어쓰기.
6. **제목 차별화** — 원곡 제목 단어 일부 그대로 쓰지 말 것 (예: 원곡 "평범하게" → 창작 "평범한"도 위험. 다른 결의 단어 선택).

## 검증
1. **파일 형식 검증**: `ffprobe -show_format -show_streams output.mp3` — 256kbps, 44.1kHz, stereo 확인
2. **길이 확인**: 2~4분 적정. 4분 초과 시 `--max_audio_length_ms` 조정
3. **재생 확인**: macOS는 `afplay output.mp3`, Linux는 `mpv output.mp3` 또는 `ffplay`

## 기본 작업 디렉토리
```
~/Music/ai-ballad-workspace/
├── lyrics/    # 가사 txt 파일들
├── audio/     # 생성된 mp3 파일들
└── output/    # 최종본
```

## Links
- mmx CLI 문서: `mmx music generate --help`
- API Reference: https://platform.minimax.io/docs/api-reference/music-generation
- 업그레이드: `npm update -g mmx-cli`
