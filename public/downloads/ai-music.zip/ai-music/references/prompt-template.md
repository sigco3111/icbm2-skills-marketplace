# mmx music generate - 풀 파라미터 레퍼런스

## 명령어 전체 구조

```bash
mmx music generate \
  --prompt "<2000자 이하 스타일 묘사>" \
  --vocals "<보컬 타입>" \
  --genre "<장르>" \
  --mood "<무드/감정>" \
  --instruments "<악기 목록>" \
  --tempo "<slow/medium/fast 또는 묘사>" \
  --bpm <정수> \
  --key "<D major, C#m, A minor 등>" \
  --references "<참고 트랙 1~3개>" \
  --use-case "<용도>" \
  --structure "<verse-chorus-verse-bridge-chorus 등>" \
  --avoid "<피할 요소>" \
  --extra "<기타 요구사항>" \
  --lyrics-file <path> \
  --out <path> \
  --aigc-watermark
```

## 파라미터 상세

| 파라미터 | 설명 | 권장 |
|---------|------|------|
| `--prompt` | 스타일 묘사 (장르+무드+악기+분위 조합) | 가장 영향력 큰 필드 |
| `--vocals` | 보컬 타입/특징 묘사 | 여성/남성, 톤, 발성법, 영향 받은 가수 |
| `--genre` | 장르 태그 | k-pop, indie pop, ballad, folk, electronic 등 |
| `--mood` | 무드/감정 | warm, melancholic, uplifting, hopeful, playful 등 |
| `--instruments` | 특징 악기 | acoustic guitar, piano, strings, drums, bass |
| `--tempo` + `--bpm` | 둘 다 일치 권장 | `tempo: medium, bpm: 117` |
| `--key` | 음악 키 | C#m (왕치치 곡), D major (밝은 발라드), A minor (쓸쓸) |
| `--references` | 참고 트랙/아티스트 | 1~3개 권장, 너무 많으면 충돌 |
| `--use-case` | 용도 컨텍스트 | "background music for video", "theme song" |
| `--structure` | 곡 구조 | "verse-chorus-verse-bridge-chorus" |
| `--avoid` | 피할 요소 | 명시적 부정이 효과적 |
| `--extra` | 기타 세밀 요구 | 메인 프롬프트에 못 담은 부분 |
| `--model` | music-2.6 (default), music-2.5+, music-2.5 | 새 버전일수록 퀄리티 ↑ |
| `--aigc-watermark` | AI 생성 표시 워터마크 | 유튜브/공개 시 권장 |
| `--output-format` | hex (default) 또는 url (24h 만료) | 파일 저장은 hex |
| `--format` | mp3 (default), wav, pcm | wav가 퀄 ↑ |
| `--bitrate` | default 256000 | mp3 기준 |

## 한국어 발라드 검증된 레시피 3종

### 레시피 1: 따뜻한 새벽 발라드 (잔잔)
- **용도:** 위로/힐링, 새벽 감성, 잔잔한 보컬
- **BPM:** 65~75 / Key: D major or F#m
- **프롬프트:** `Korean warm piano ballad, soft indie pop, late night comfort, healing and gentle, emotional female vocal like IU, soft strings, brushed drums, lo-fi warmth`
- **보컬:** `warm female soprano, soft and breathy, gentle vibrato, emotional and comforting, Korean vocal style`
- **악기:** `piano, soft strings, brushed drums, subtle bass, light pad`
- **레퍼런스:** `IU Love poem, IU Through the Night`
- **평가:** 어쿠스틱 기타나 우쿨렐레 빼고 미니멀하게 — "라디오 새벽 발라드" 결

### 레시피 2: 중독성 K-pop 발라드 (원곡 충실)
- **용도:** 커버/리메이크, 중독성 후렴, 4코드 순환
- **BPM:** 100~120 / Key: C#m (왕치치 곡 원곡)
- **프롬프트:** `Korean catchy k-pop ballad, warm and bright, medium tempo, catchy and addictive hook, charming female vocal, IU inspired, light acoustic guitar fingerpicking, piano, soft strings, brushed drums, lo-fi warmth, singalong feel, hopeful and comforting`
- **보컬:** `warm female soprano, IU inspired, sweet and charming, tender yet bright, soft vibrato, sincere Korean vocal, slight playful edge`
- **악기:** `acoustic guitar fingerpicking, piano, soft strings, brushed drums, light bass, soft claps`
- **레퍼런스:** `왕치치 我愿意平凡的陪在你身旁, IU Love poem, 폴킴 안녕`
- **평가:** 원곡의 117 BPM 유지 + 한국 발라드 따뜻함 결합의 정석

### 레시피 3: 밝은 중독성 팝 (위트+귀여움)
- **용도:** 위트 가사, 귀여운 톤, 일상의 자위
- **BPM:** 115~125 / Key: C major or C#m
- **프롬프트:** `Korean Chinese-style catchy pop, bouncy and sweet, medium-fast tempo, addictive hook melody, charming female vocal, light percussion, ukulele, light guitar, soft synth bass, cute and warm, lo-fi pop feel, bright and playful`
- **보컬:** `bright female vocal, playful yet sincere, slight K-pop timbre, IU inspired but with a brighter edge, sweet and charming, light vibrato`
- **악기:** `ukulele, light guitar, soft synth, brushed drums, light bass, soft claps`
- **레퍼런스:** `왕치치 我愿意平凡的陪在你身旁, IU BBIBBI, Cheer Up`
- **평가:** 원곡의 "중독성 있는 중국 팝" 결 — 위트 있는 가사에 최적

## 프롬프트 작성 팁

1. **첫 5단어**가 가장 영향력 큼 → 장르+분위 키워드를 앞에
2. **보컬 묘사는 구체적** — "warm female soprano" > "good vocals"
3. **악기는 4~6개** — 너무 많으면 mud
4. **레퍼런스는 같은 결의 1~3개** — 충돌 방지
5. **BPM과 tempo 일치** — `medium` + 117 OK, `slow` + 117 ✗
6. **영어 프롬프트 권장** — mmx 모델은 영문 프롬프트 학습 데이터가 더 많음

## 가사 매개변수

- `--lyrics "<text>"` — 직접 인라인
- `--lyrics-file <path>` — 파일에서 (UTF-8 .txt)
- `--lyrics-optimizer` — 프롬프트에서 가사 자동 생성 (가사 없을 때)
- `--instrumental` — 보컬 없이 BGM만 (가사 옵션과 mutually exclusive)

## 출력 형식

- 기본: `--out path` 로 hex 디코딩하여 파일 저장
- 24h 만료 URL: `--output-format url` (즉시 다운로드 필요)

## 검증 명령어

```bash
# 메타데이터
ffprobe -v error -show_format output.mp3 | grep -E "duration|bit_rate"

# 30초 미리듣기 (모바일 청취 가벼움)
ffmpeg -y -i input.mp3 -ss 0 -t 30 -c:a libmp3lame -b:a 96k \
  -ac 1 -ar 22050 preview.mp3
```
