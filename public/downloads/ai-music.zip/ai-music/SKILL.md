---
name: ai-music
description: Generate AI music from text — covers mmx CLI (MiniMax music-2.6) for cloud-based Korean/English songs, HeartMuLa for open-source / local-GPU generation, cover/rework workflows, Korean ballad recipe, lyrics templates, prompt engineering, and Telegram/ngrok delivery patterns. One umbrella for the whole AI-music generation class.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [music, audio, generation, ai, mmx, HeartMuLa, lyrics, korean, ballad, k-pop, cover, rework, songsee, ngrok, telegram]
---

# AI Music Generation

Generate AI music from text. This umbrella covers the full class of AI music generation — picking the right tool, prompt engineering, lyrics, generation, and delivery.

**Sections (jump directly):**

1. [Tool selection](#1-tool-selection) — which engine to use
2. [Prerequisites & setup](#2-prerequisites--setup) — `mmx` install and auth
3. [The 5-step workflow](#3-the-5-step-workflow) — the universal pipeline
4. [mmx CLI reference](#4-mmx-cli-reference) — full parameter reference
5. [Korean ballad recipe](#5-korean-ballad-recipe) — warm, healing, IU-style
6. [Cover & rework](#6-cover--rework) — when user gives a source song
7. [Lyrics templates](#7-lyrics-templates) — structure tags and conventions
8. [Prompt engineering](#8-prompt-engineering) — what works, what doesn't
9. [HeartMuLa (open source)](#9-heartmula-open-source) — local GPU alternative
10. [Verification](#10-verification) — how to know it worked
11. [Delivery](#11-delivery) — Telegram, ngrok, local file
12. [Common pitfalls](#12-common-pitfalls)

**Per-tool deep references** (under `references/`):

- `references/mmx-workflow.md` — the original 5-step pipeline with full mmx invocation
- `references/mmx-cli-reference.md` — all mmx CLI parameters, brainstorm-before-create pattern, hybrid version pattern
- `references/prompt-template.md` — Korean ballad recipe, prompt param reference
- `references/cover-workflow.md` — cover/rework detailed procedure
- `references/korean-ballad-recipe.md` — Korean ballad-from-reference, 3-concept brainstorming
- `references/heartmula-open-source.md` — HeartMuLa install + patches + GPU/CUDA
- `references/ngrok-delivery.md` — ngrok + http.server external listening pattern
- `references/example-session-wangqiqi.md` — full session trace

---

## 1. Tool Selection

| Engine | API/Local | Best for | Pros | Cons |
|---|---|---|---|---|
| **mmx (music-2.6)** | Cloud (MiniMax) | Korean vocals, fast iteration, cover/rework | High quality, no GPU, IU/AESPA style | 3500-char lyric cap, ~4 min cap |
| **HeartMuLa** | Local (open-source, Apache-2.0) | Offline, no API cost, Linux/CUDA only | Free, no auth, lyrics+tags conditioned | Needs 8GB+ VRAM, slow on CPU/macOS |
| **AudioCraft** | Local (Meta) | Instrumental, sound design | — | Vocals weak |
| **Suno** | Cloud | Quick demos, no install | Easy | Paid, no fine control |

**Decision rule:**

- **Default to mmx** unless the user explicitly wants open-source / offline / GPU
- **HeartMuLa** when the user has a CUDA box and wants no API cost
- **AudioCraft** for instrumental-only outputs

---

## 2. Prerequisites & Setup

### 2.1 mmx (cloud) — required for default workflow

```bash
which mmx                # check install
mmx --version            # 1.0.16+ recommended
mmx auth status          # check API key

# If not installed
npm install -g mmx-cli
mmx auth login           # enter API key when prompted

# ALWAYS update before use (new model versions ship often)
npm update -g mmx-cli
mmx --version            # re-verify
```

`mmx update` only shows npm command hints — actually run `npm update -g mmx-cli` directly.

### 2.2 HeartMuLa (local)

```bash
# Clone
git clone https://github.com/HeartMuLa/heartlib.git
cd heartlib

# Python 3.10 required
uv venv --python 3.10 .venv
. .venv/bin/activate
uv pip install -e .

# Fix pinned-dependency conflicts (2026)
uv pip install --upgrade datasets transformers

# Patch source for transformers 5.x:
#   - src/heartlib/heartmula/modeling_heartmula.py — add RoPE re-init in setup_caches
#   - src/heartlib/pipelines/music_generation.py — ignore_mismatched_sizes=True on HeartCodec.from_pretrained

# Download checkpoints
hf download --local-dir './ckpt' 'HeartMuLa/HeartMuLaGen'
hf download --local-dir './ckpt/HeartMuLa-oss-3B' 'HeartMuLa/HeartMuLa-oss-3B-happy-new-year'
hf download --local-dir './ckpt/HeartCodec-oss' 'HeartMuLa/HeartCodec-oss-20260123'
```

GPU required for practical use. CPU works but ~30-60min per song. macOS lacks Triton (Linux/CUDA only).

### 2.3 Verifying

```bash
# Quick smoke test
mmx music generate --prompt "warm piano test, 60 BPM" --out /tmp/test.mp3
ls -la /tmp/test.mp3     # > 100KB = success
```

---

## 3. The 5-Step Workflow

Universal pipeline regardless of tool:

1. **Analyze** (if user gave a reference song) — BPM, key, structure, message
2. **Gather requirements** — mood, vocal style, length, language
3. **Brainstorm** — 2-3 directions; user picks
4. **Write lyrics** — Korean/English, structure tags
5. **Generate + verify + deliver** — `mmx` call, ffprobe check, send to user

Detail per step in the sub-references.

### Why this order matters

Skipping step 1 (analysis) leads to "doesn't feel like the reference" feedback. The reference song's BPM/key/structure is the load-bearing constraint — without it, results drift.

Skipping step 3 (brainstorm) leads to "v1 is good but I want it different" → expensive regeneration. 3 cheap options > 1 expensive option that misses.

---

## 4. mmx CLI Reference

Full reference: `references/mmx-cli-reference.md` and `references/mmx-workflow.md`. Key points:

### 4.1 Parameters

| Param | Description |
|---|---|
| `--prompt` | Style description (genre + mood + instruments) |
| `--vocals` | Vocal type (e.g., "warm female soprano, IU inspired") |
| `--genre` | Genre tag (k-pop ballad, indie pop, etc.) |
| `--mood` | Mood tag (warm, comforting, energetic) |
| `--instruments` | Comma-separated instrument list |
| `--tempo` | slow / medium / fast |
| `--bpm` | Numeric BPM (must match `--tempo`) |
| `--key` | D major, C#m, A minor, etc. |
| `--references` | Reference artists/songs (e.g., "IU Love poem") |
| `--lyrics-file` | Path to lyrics `.txt` |
| `--out` | Output mp3 path |
| `--aigc-watermark` | Embed AIGC watermark (recommended) |

### 4.2 Minimal invocation

```bash
mmx music generate \
  --prompt "Korean warm piano ballad, soft indie pop, late night comfort" \
  --vocals "warm female soprano, soft and breathy, IU inspired" \
  --genre "k-pop ballad" \
  --mood "warm, comforting" \
  --instruments "piano, soft strings" \
  --tempo "slow" --bpm 70 --key "D major" \
  --lyrics-file lyrics.txt \
  --out output.mp3 \
  --aigc-watermark
```

### 4.3 Length control

mmx doesn't expose a `--duration` flag (it claims to, but it's unreliable). Length is driven by lyrics structure + char count.

- ~100 Korean chars (≈300 bytes) → ~1 minute
- ~1000 Korean chars → ~3-4 minutes
- 1500+ chars → up to 4-5 min, may needlyrics extension

**To guarantee 3+ min songs, write 1200+ char lyrics with structure tags** (`[Verse]`, `[Chorus]`, `[Bridge]`).

---

## 5. Korean Ballad Recipe

Full reference: `references/korean-ballad-recipe.md` and `references/mmx-workflow.md`.

**Default sweet-spot prompt:**

```text
Korean warm piano ballad, soft indie pop, late night comfort, healing and gentle,
emotional female vocal, soft strings, brushed drums, lo-fi warmth, 70 BPM, D major
```

**Vocal:** `warm female soprano, soft and breathy, gentle vibrato, emotional and comforting, Korean vocal style`

**References:** `IU Love poem, IU Through the Night` work well for emotional warmth; `AESPA` for more pop edge; `폴킴` for male ballad.

**BPM 70-80** is the sweet spot for warm ballads. Below 60 = too slow; above 90 = loses intimacy.

**Lyrics structure for ballads:**

```
[Intro]

[Verse 1]
4-8 lines. Korean natural phrasing, short phrases.

[Pre-Chorus] (optional)
2-4 lines. Build emotional tension.

[Chorus]
4-6 lines. The repeatable hook — make this singable.

[Verse 2]
4-8 lines. Develop the theme.

[Pre-Chorus] (repeat or variant)

[Chorus] (repeat)

[Bridge] (optional)
3-5 lines. Pivot moment.

[Chorus] (final, slight variation)

[Outro]
1-2 lines. Residue.
```

---

## 6. Cover & Rework

Full reference: `references/cover-workflow.md`.

When user says "I want a cover of X" or "make a Y-style version of Z":

### 6.1 Reference analysis (mandatory)

```bash
# Find: BPM, key, structure, message
# - Spotify stats / musicstatsforspotify.com
# - Chordify / Ultimate Guitar for chords and key
# - genius.com / music blogs for lyrics and meaning
# - YouTube lyric videos for subcultural context
```

**Critical pitfall:** If you skip BPM/key matching, the result will feel "off" even if the prompt is good.

### 6.2 Brainstorm 2-3 directions

- **A: Faithful warm** — closest to original mood, just language/tempo adjust
- **B: Twist on perspective** — different narrator (e.g., self-to-other instead of lover-to-lover)
- **C: Genre shift** — same lyrics, different genre (ballad → R&B, etc.)

User picks one or hybrid.

### 6.3 Keep BPM/key/structure aligned with original

- Same BPM (or within ±5)
- Same key (or relative minor/major)
- Same verse/chorus count

Creative reinterpretation is fine; structural deviation loses the "cover" feel.

---

## 7. Lyrics Templates

`templates/lyrics-template.txt` — starter file.

**Structure tags** (English, mmx reads them as section markers):

- `[Intro]` `[Verse 1]` `[Pre-Chorus]` `[Chorus]` `[Verse 2]` `[Bridge]` `[Outro]`
- `[Post-Chorus]` `[Interlude]` `[Hook]` `[Inst]` `[Solo]`

**Hard rules:**

- Max 3500 chars (UTF-8). Korean 1 char ≈ 3 bytes.
- Korean 800-1000 chars safe for 4-min songs.
- **Never put description inside the tag**: `[Chorus - 밝게]` ❌ (mmx will sing "brightly"). Use `[Chorus]` ✅.
- One newline between tag and content.
- Use `wc -c lyrics.txt` to verify before running.

**Filter foreign characters when needed:**

```python
import re
filtered = re.sub(r'[^\uAC00-\uD7A3a-zA-Z0-9\s.,!?~()\-\'\"]+', '', text)
```

Removes Japanese kanji/Chinese hanzi while keeping Korean Hangul + English + punctuation.

---

## 8. Prompt Engineering

What works:

- **Concrete genre + mood + instrument list** — "Korean warm piano ballad, soft indie pop, 70 BPM"
- **Specific vocal descriptions** — "warm female soprano, soft and breathy, gentle vibrato, IU inspired"
- **Reference artists** — "IU Love poem, IU Through the Night" (anchors the style)
- **Numeric BPM + key + tempo that agree** — `--tempo slow --bpm 70`

What doesn't work:

- Vague mood words alone — "sad song" or "happy" produces generic output
- Mixing contradictory signals — "energetic ballad" or "fast slow"
- Too many instruments — "piano strings guitar bass drums synth pads..." dilutes
- Stale CLI version — always `npm update -g mmx-cli` first

**Hybrid version pattern** (when user says "v1's mood is good, v2's BPM is good"):

1. Identify what to keep from each version (mood, BPM, arrangement, lyrics)
2. Combine into a new v3 prompt
3. Reuse the winning lyrics unchanged
4. Don't go back to v0 — synthesize forward

---

## 9. HeartMuLa (Open Source)

Full reference: `references/heartmula-open-source.md`.

### When to choose HeartMuLa over mmx

- No API budget, or offline use required
- Local CUDA box with 8GB+ VRAM available
- Linux (Triton not available on macOS)

### Basic generation

```bash
cd heartlib
. .venv/bin/activate
python ./examples/run_music_generation.py \
  --model_path=./ckpt \
  --version="3B" \
  --lyrics=./assets/lyrics.txt \
  --tags=./assets/tags.txt \
  --save_path=./assets/output.mp3 \
  --lazy_load true
```

**Tags format:** comma-separated, no spaces: `piano,happy,wedding,synthesizer,romantic`

**Lyrics format:** bracketed structural tags (same as mmx).

**Performance:** RTF ≈ 1.0 — a 4-min song takes ~4 min on GPU.

### Hardware notes

- **8GB VRAM**: use `--lazy_load true` (peaks at 6.2GB)
- **16GB+ VRAM**: comfortable
- **Multi-GPU**: `--mula_device cuda:0 --codec_device cuda:1`
- **CPU only**: 30-60+ min per song, 12GB+ RAM; recommend cloud GPU instead

### Pitfalls (HeartMuLa-specific)

1. **Don't use bf16 for HeartCodec** — degrades audio quality. Use fp32 (default).
2. **Tags may be ignored** — known upstream issue; lyrics tend to dominate.
3. **RTX 5080 incompatibility** — reported in upstream issues.
4. **Pinned dependencies conflict** — manual `uv pip install --upgrade datasets transformers` is required.

---

## 10. Verification

```bash
ls -la output.mp3              # > 100KB = non-empty
ffprobe -v error -show_format output.mp3 | grep -E "duration|bit_rate"
# Expect: duration=120-300 (2-5 min), bit_rate=256000

# 30s preview clip for Telegram
ffmpeg -y -i output.mp3 -ss 0 -t 30 \
  -c:a libmp3lame -b:a 96k -ac 1 -ar 22050 \
  preview.mp3
```

Failure modes:

- `duration=0` or file < 100KB → generation failed; retry
- Wrong duration → lyrics too short or too long
- Audio glitches → mmx version stale; `npm update -g mmx-cli`

---

## 11. Delivery

| Situation | Method |
|---|---|
| User at PC + Telegram | `MEDIA:<path>` tag in reply |
| Mobile / Telegram | ngrok tunnel + public URL (`references/ngrok-delivery.md`) |
| No PC, anywhere | ngrok + URL |
| Local file requested | Give file path |

**Preview clip sweet spot:** 30s, mono, 22.05kHz, 96kbps. Telegram recognizes this as a voice bubble.

**Unicode filename pitfall:** HTTP servers may 404 on Korean filenames. Workaround:

```bash
ln -sf "한글파일명.mp3" "ascii_alias.mp3"
```

---

## 12. Common Pitfalls

1. **mmx CLI version stale** — always `npm update -g mmx-cli` first; verify with `mmx --version`
2. **Reference analysis skipped** → "doesn't feel like the original" feedback. Always extract BPM/key/structure first.
3. **Korean lyrics in tags** — `[Chorus - 밝게]` will be sung literally
4. **3500-char cap** — UTF-8 byte count; Korean counts ~3x. Check with `wc -c`.
5. **BPM/tempo mismatch** — `--tempo slow --bpm 120` is contradictory; mmx may pick one
6. **First result mediocre** — normal. Iterate 2-3 times. Brainstorm alternative prompts.
7. **Korean URL 404 on ngrok** — use ASCII alias symlink
8. **macOS ffmpeg without libopus** — use `opus` (native) or `libmp3lame` for Telegram voice bubble
9. **No GPU for HeartMuLa + macOS** — Triton is Linux-only; recommend cloud GPU or mmx
10. **Lyrics extension for 3+ min** — write structure tags explicitly; mmx uses section count to gauge length

---

## Related Skills

- `remote-file-delivery` — ngrok + http.server for external listening
- `telegram-mp3-voice-bubble` — Telegram delivery of mp3 as voice bubble
- `songsee` — spectrogram/audio feature visualization (separate skill)
- `music-video-generator` — full MV pipeline (image + music + FFmpeg + YouTube)
- `kaggle-music-voice-gen` — alternative (instrumental-only via Kaggle)
