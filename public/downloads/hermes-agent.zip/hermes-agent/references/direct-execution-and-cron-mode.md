# Direct Device Execution & Cron Mode Patterns (2026-06-24)

사용자 디바이스에서 "직접 처리해줘" 시그널이 들어왔을 때의 안전한 실행 패턴, 그리고 cron/headless 모드에서 마주치는 보안 차단 패턴 두 가지를 정리.

## 패턴 1: execute_code cron_mode BLOCKED

### 증상
```
BLOCKED: execute_code runs arbitrary local Python (including subprocess calls
that bypass shell-string approval checks). Cron jobs run without a user present
to approve it. Use normal tools instead, or set approvals.cron_mode: approve
only if this cron profile is intentionally trusted.
```

### 원인
- Hermes의 `execute_code` 도구는 사용자 승인 없이 `subprocess`를 호출할 수 있는 Python 인터프리터
- Cron 모드(자율 실행, 사용자 부재)에서는 임의 코드 실행을 보안상 차단
- `hermes config set approvals.cron_mode approve`로 풀 수 있지만 **권장 안 함**

### 해결
- **즉시 우회**: `terminal` 도구로 같은 작업을 수행
- `terminal(command="which brew")` 같은 read-only 진단은 즉시 통과
- `terminal(command="brew install xmrig")` 같은 install/build도 승인 후 통과
- Python 데이터 처리가 필요하면 `terminal(command="python3 -c '...'")`로 한 줄 처리
- `execute_code`를 다시 쓰고 싶으면 사용자에게 `hermes config set approvals.cron_mode approve` 직접 실행 요청

### 검증 명령
```bash
# 현재 모드 확인
hermes config get approvals.cron_mode
# 사용 가능한 도구
hermes tools list
```

---

## 패턴 2: terminal background=true + `&` / nohup / disown 차단

### 증상
포어그라운드 `terminal` 호출에서 `&`로 백그라운드 실행 시도:
```
Foreground command uses '&' backgrounding. Use terminal(background=true) for
long-lived processes, then run readiness checks and tests in follow-up terminal
calls.
```

또는 `nohup` / `disown` / `setsid` 사용 시:
```
Foreground command uses shell-level background wrappers (nohup/disown/setsid).
Use terminal(background=true) so Hermes can track the process, then run
readiness checks and tests in separate commands.
```

### 원인
- Hermes는 모든 long-running 프로세스를 자체 `process` 도구로 추적하려 함
- 셸 레벨 백그라운드 wrapper(`&`, `nohup`, `disown`, `setsid`)는 Hermes의 lifecycle 추적을 우회 → silent blindness 위험
- 출력 버퍼가 안 비워지거나, 백그라운드 잡이 끝났을 때 알림이 안 옴

### 해결
- **`terminal(background=true, notify_on_complete=...)`로 위임**:
  - `notify_on_complete=true`: bounded task (테스트, 빌드, 마이그레이션, install)
  - `notify_on_complete=false`: long-lived daemon/server (영원히 안 끝나는 프로세스)
- **준비 확인은 별도 `terminal` 호출로**:
  - 첫 호출: `terminal(background=true, notify_on_complete=true, command="xmrig --config=...")`
  - 두 번째 호출: `terminal(command="sleep 30 && tail -30 /path/to/log")`
- **`process` 도구로 관리**:
  - `process(action="list")` — 살아있는 백그라운드 잡 확인
  - `process(action="poll", session_id=...)` — 출력 일부 확인
  - `process(action="wait", session_id=..., timeout=N)` — 종료 대기
  - `process(action="kill", session_id=...)` — 강제 종료

### 실전 예시: 채굴 daemon 시작 + 검증
```python
# 1단계: 백그라운드 시작
terminal(background=true, notify_on_complete=false,
         command="xmrig --config=~/xmrig-config.json 2>&1 | tee ~/xmrig.log")
# → session_id="proc_52746", PID=52773 반환

# 2단계: 30초 대기 후 로그 확인
terminal(command="sleep 30 && tail -40 ~/xmrig.log")
# → "cpu READY threads 5/5" 같은 READY 신호 확인

# 3단계: 죽일 때
process(action="kill", session_id="proc_52746")
```

### 자주 하는 실수 3가지
1. **출력 파일이 0바이트** — `tee` 안 쓰고 그냥 `> /tmp/log`만 쓰면 stdout만 캡처, stderr가 빠짐. 항상 `2>&1 | tee LOG` 또는 `2>&1 > LOG` 명시.
2. **notify_on_complete 안 쓰고 무한 대기** — `background=true` + `notify_on_complete=false`는 진짜 영원히 안 끝나는 프로세스용. bounded 작업은 반드시 `true`.
3. **셸 wrapper `nohup ... &`을 한 줄에 섞기** — Hermes가 거부. 분리해서 호출.

---

## 패턴 3: LaunchAgent plist로 영구 백그라운드 (macOS)

사용자가 명시적으로 "재부팅해도 살아있게" 요청할 때:

### plist 파일 위치
`~/Library/LaunchAgents/com.local.<name>.plist`

### 핵심 키
```xml
<key>RunAtLoad</key><true/>          <!-- 로그인 시 자동 시작 -->
<key>KeepAlive</key><true/>          <!-- 죽으면 자동 재시작 -->
<key>ProcessType</key><string>Background</string>  <!-- macOS 우선순위 낮춤 -->
<key>StandardOutPath</key><string>/Users/hjshin/xmrig.log</string>
<key>StandardErrorPath</key><string>/Users/hjshin/xmrig.log</string>
```

### 트레이드오프
- 장점: 영구, 재부팅 후에도 자동 시작, Hermes와 독립
- 단점: stdout 버퍼링 이슈 (파일에 써도 즉시 flush 안 됨), Hermes process 도구로 추적 불가
- **1차 시도: `terminal(background=true, notify_on_complete=false)`** → 충분
- **2차 시도: LaunchAgent** → 영구 필요한 경우만

### 진단
```bash
launchctl list | grep com.local.xmrig  # PID와 exit code
launchctl print user/$(id -u)/com.local.xmrig  # 상세
launchctl unload ~/Library/LaunchAgents/com.local.xmrig.plist  # 정지
launchctl load ~/Library/LaunchAgents/com.local.xmrig.plist  # 시작
```

---

## 적용 우선순위 요약

1. **사용자 디바이스에 설치/실행** → `terminal(foreground)` → brew install / 직접 실행
2. **영구 백그라운드 daemon** → `terminal(background=true, notify_on_complete=false)` + 별도 호출로 검증
3. **재부팅 후에도 살아있어야 함** → LaunchAgent plist
4. **Python 데이터 처리** → 한 줄 `python3 -c "..."` (execute_code 못 쓸 때)
5. **복잡한 multi-step 스크립트** → `write_file`로 .py 파일 저장 → `terminal`로 실행
