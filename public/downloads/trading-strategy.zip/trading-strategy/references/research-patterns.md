# Research Patterns

Detailed tool usage patterns for different research scenarios. Load this when you need specific guidance on which tools to use and how.

## Macro Research

- `web_search("[topic] macro outlook [current year]")` — analyst views, articles
- Check total market cap, BTC dominance, 24h volume via market data tools
- Check DeFi TVL, DeFi-to-crypto ratio
- Search social media for trader sentiment (`$BTC macro` with engagement filters)
- Check what's trending in crypto right now

## Asset-Level Research

- Get current prices for multiple assets
- Get OHLC price action (30-day, 90-day, etc.)
- Check technical indicators (RSI, MACD, etc.)
- Identify key support/resistance levels
- Check Galaxy Score, social volume, sentiment via LunarCrush

## Derivatives / Positioning

- Check funding rates (>+0.05% extreme greed, <-0.05% extreme fear)
- Check long/short ratio (>1.5 crowded long, <0.7 crowded short)
- Check aggregate open interest across exchanges
- Check recent liquidations (more long liq = bearish pressure)

## Social / Sentiment

- Search popular crypto tweets with engagement filters
- Check specific analyst/trader posts
- Get topic-level sentiment analysis
- Get top posts on a topic

## Source Fetching

- Fetch full article content from URLs (Substack, news sites, etc.)
- Search for related articles on specific platforms
- Always cross-reference fetched content with live market data

## Monitoring Scripts

Template for price + indicator monitoring:

```python
import requests, os, json

COINGECKO_KEY = os.getenv("COINGECKO_API_KEY")
TAAPI_KEY = os.getenv("TAAPI_API_KEY")

# Check price
price_resp = requests.get(
    "https://pro-api.coingecko.com/api/v3/simple/price",
    params={"ids": "bitcoin", "vs_currencies": "usd"},
    headers={"x-cg-pro-api-key": COINGECKO_KEY}
)
btc_price = price_resp.json()["bitcoin"]["usd"]

# Check RSI
rsi_resp = requests.get(
    "https://api.taapi.io/rsi",
    params={"secret": TAAPI_KEY, "exchange": "binance", "symbol": "BTC/USDT", "interval": "1d"}
)
rsi = rsi_resp.json()["value"]

# Alert logic
alerts = []
if btc_price < 58000:
    alerts.append(f"BTC at ${btc_price:,.0f} — below 58K target zone")
if rsi < 30:
    alerts.append(f"BTC RSI at {rsi:.1f} — oversold on daily")

if alerts:
    print("ALERTS:\n" + "\n".join(alerts))
else:
    print(f"BTC ${btc_price:,.0f} | RSI {rsi:.1f} — no alerts")
```
