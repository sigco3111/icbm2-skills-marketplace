# Twin Lab 게스트 페이지 정밀 재분석 — 1:1 차용 레퍼런스

2026-08-04 hermes-control-room 세션에서 검증된 "Twin Lab 룩 = 7차원 모두 결합" 정밀 차용 워크플로. W17ant/Claude-Office 룩을 "Twin Lab 룩"이라고 인용해서 어두운 청록 박스만 그리는 함정을 피하기 위해, **Twin Lab 게스트 페이지 (https://twin.quantlabnote.com/guest) 의 진짜 모습**을 직접 캡쳐 + 측정 + 7차원 모두 차용하는 정형.

## 사용 시점

- "Twin Lab처럼", "Twin Lab 룩", "원본과 비슷하게" 같은 사용자 요청
- 이전 1차 차용이 "현실적이지 않다" / "원본은 괜찮던데" / "비율이 이상하다" 피드백을 받은 후
- W17ant/Claude-Office의 rooms.ts만 차용하는 1차 시도 → 사용자 거절 → 정밀 재분석으로 재시도

## 1. Twin Lab 게스트 페이지 7차원 측정

| # | 차원 | Twin Lab 실제 모습 | 측정값 (캔버스 1920×1080 기준) |
|---|---|---|---|
| 1 | **큰 흰색 발코니 플랫폼** | 박스들이 놓인 큰 사각형 | ~800px × 600px 화면상, 옆면 3면 (좌/우/앞) 두께감 |
| 2 | **옅은 톤 박스** | 흰 + 살짝 톤 + 진한 네이비 외곽선 | 박스 바닥 `#f5f9f7` / 벽 `#e6efe9` ~ `#d6e3dd` |
| 3 | **캐릭터 박스 안 딱 맞게** | 캐릭터가 박스 안에서 작업 중 | 키 ~70-80px (박스 깊이의 80%), 발 위치 = 박스 표면 |
| 4 | **부서 라벨 알약형** | 검정 둥근 사각형 + 색 점 + 흰 텍스트 | 라벨 박스 위 -WALL_H-20 위치 |
| 5 | **윈도우 불빛** | 좌측 벽 중앙에 작은 시안 원 | ~3-4px (방 활성화 표시) |
| 6 | **큰 잎 구름 나무** | 통로/모서리에 큰 나무 (잎 3-4겹) | 키 ~60-70px 화면상 |
| 7 | **UI 톤** | 다크 네이비 헤더 + 슬라이드 패널 + 뉴스 티커 흐름 | 다크 `#0e1a1f` 베이스 + 시계 1초 깜빡임 + 가로 흐름 60s |

## 2. 캡쳐 + 측정 워크플로

### 2-1. Playwright 캡쳐 (Twin Lab + 우리)

```js
// /tmp/screenshot.mjs (Twin Lab 게스트 페이지 + 우리 프로젝트)
import pw from '/opt/homebrew/lib/node_modules/playwright/index.js'
const { chromium } = pw

const browser = await chromium.launch()
const page = await browser.newPage({ viewport: { width: 1920, height: 1080 } })
const errors = []
page.on('pageerror', e => errors.push(String(e)))
page.on('console', m => { if (m.type() === 'error') errors.push('console: ' + m.text()) })
await page.goto(url, { waitUntil: 'networkidle', timeout: 30000 })
await page.waitForTimeout(3500)  // PixiJS init + sprite PNG 로드 대기
await page.screenshot({ path: out })
console.log(JSON.stringify({ ok: true, errors, url, out }))
await browser.close()
```

해상도: 1920×1080 + 1440×900 + 960×600 (좌우 비교용) 모두 캡쳐.

### 2-2. vision_analyze로 측정값 추출

```python
vision_analyze(
    image_url="/Users/mac/work/{project}/.verify/reanalysis-{date}/twinlab-1920x1080.png",
    question="Twin Lab 게스트 페이지 화면. (1) 방 1개 박스의 픽셀 크기, "
             "(2) 캐릭터 sprite 크기, (3) 박스 색감/지붕 색, "
             "(4) 박스들 사이 통로/그림자, (5) decoration 분포, "
             "(6) 헤더/사이드패널/티커 디자인을 정밀 분석해줘. 픽셀 측정값 추정 포함."
)
```

→ vision이 픽셀 측정값을 표로 반환. 이걸 코드로 매핑.

### 2-3. 우리 매핑 표 (월드 단위)

| 차원 | Twin Lab 측정값 | 우리 매핑 | 함수/상수 |
|---|---|---|---|
| 박스 폭(W) | ~180px 화면상 | ROOM_W = 140 | `drawRoom.ts` 상수 |
| 박스 깊이(D) | ~140px 화면상 | ROOM_D = 130 | `drawRoom.ts` 상수 |
| 박스 높이(WALL_H) | ~100px 화면상 | WALL_H = 110 | `drawRoom.ts` 상수 |
| 캐릭터 키 | ~70-80px 화면상 | 80 (박스 깊이의 0.85) | `drawCharacter.ts` sprite.height |
| 캐릭터 폭 | ~35-40px 화면상 | 38 | `drawCharacter.ts` sprite.width |
| 큰 나무 키 | ~60-70px 화면상 | scale 1.0-1.2 | `drawScene.ts` drawBigTree |
| 통로 폭 | 30-50px 화면상 | GRID_GAP 55-90px | `drawScene.ts` GRID_GAP_X/Y |
| 윈도우 글래스 | ~24x16px | roundRect 24x16 | `drawRoom.ts` drawWindow |
| 문 | ~22x32px | roundRect 22x32 | `drawRoom.ts` drawDoor |
| 책상 | ~56x32px | 56x32 | `drawRoom.ts` drawDesk |

## 3. 7차원 코드 패턴

### 3-1. 큰 흰색 발코니 플랫폼 (drawScene.ts)

```ts
// 흰색 플랫폼 + 옆면 3면 + 타일 결
const platformSide = 12  // 두께감
const platformLeft = new Graphics()
  .moveTo(floorA.x, floorA.y)
  .lineTo(floorB.x, floorB.y)
  .lineTo(floorB.x, floorB.y + platformSide)
  .lineTo(floorA.x, floorA.y + platformSide)
  .closePath()
  .fill(0xc7d8d0)  // 옆면 색
  .stroke({ width: 1.2, color: 0x18313a, alpha: 0.6 })
world.addChild(platformLeft)
// platformRight, platformFront 동일 패턴
const floor = new Graphics()
  .moveTo(floorA.x, floorA.y)
  .lineTo(floorB.x, floorB.y)
  .lineTo(floorC.x, floorC.y)
  .lineTo(floorD2.x, floorD2.y)
  .closePath()
  .fill(0xf5f9f7)  // 흰색
  .stroke({ width: 2, color: 0x18313a, alpha: 0.9 })
world.addChild(floor)
```

### 3-2. 옅은 톤 박스 (drawRoom.ts)

```ts
const DEFAULT_COLORS: RoomColors = {
  floor: 0xf5f9f7,        // 거의 흰색
  wallLeft: 0xe6efe9,     // 아주 옅은 톤
  wallRight: 0xd6e3dd,    // 살짝 더 어두운 옅은 톤
  roof: 0xffffff,         // 흰 지붕
  roofSide: 0xc7d8d0,     // 옅은 지붕 옆면
  outline: 0x18313a,      // 진한 네이비 외곽선
  window: 0xb6e2dc,       // 시안 글래스
  door: 0xa67a5a,         // 브라운
}
```

### 3-3. 캐릭터 박스 안 딱 맞게 (drawCharacter.ts)

```ts
// Twin Lab 정확 비율: 키 80, 폭 38
const sprite = new Sprite(tex)
sprite.width = 38   // 박스 깊이 130의 약 0.30
sprite.height = 80  // 박스 깊이 130의 약 0.62
sprite.anchor.set(0.5, 1)  // 발 위치 기준
wrap.addChild(sprite)
```

### 3-4. 부서 라벨 알약형 (drawScene.ts)

```ts
function drawRoomLabel(text: string, tone: number): Container {
  const c = new Container()
  // 알약 너비를 텍스트 길이에 맞춰 자동 조정
  const labelW = Math.max(120, text.length * 10 + 30)
  const bg = new Graphics()
    .roundRect(-labelW / 2, -12, labelW, 24, 12)
    .fill(0x18313a)
  c.addChild(bg)
  // 색 점 (왼쪽)
  const dot = new Graphics().circle(-labelW / 2 + 14, 0, 4.5).fill(tone)
  c.addChild(dot)
  // 텍스트
  const style = new TextStyle({ fontSize: 10, fontWeight: '600', fill: 0xffffff })
  const t = new Text({ text, style })
  t.anchor.set(0, 0.5)
  t.x = -labelW / 2 + 24
  t.y = 0
  c.addChild(t)
  return c
}
// 박스 위 -WALL_H-20 위치에 배치
label.x = 0
label.y = -WALL_H - 20
```

### 3-5. 윈도우 불빛 (drawScene.ts)

```ts
const windowGlow = new Graphics().circle(0, 0, 3.5).fill(0x6cd1c5)
windowGlow.x = iso(0, ROOM_D * 0.5).x + 8
windowGlow.y = iso(0, ROOM_D * 0.5).y - WALL_H * 0.55
roomContainer.addChild(windowGlow)
```

### 3-6. 큰 잎 구름 나무 (drawScene.ts)

```ts
function drawBigTree(scale: number): Container {
  const c = new Container()
  c.scale.set(scale)
  const trunk = new Graphics().rect(-4, 0, 8, 20).fill(0x875d49)
  c.addChild(trunk)
  // 잎 구름 3-4겹
  const leaves1 = new Graphics().circle(0, -8, 18).fill(0x4a9c64)
  const leaves2 = new Graphics().circle(-13, -2, 13).fill(0x6fbd88)
  const leaves3 = new Graphics().circle(12, -4, 12).fill(0x6fbd88)
  const leaves4 = new Graphics().circle(0, -22, 10).fill(0x88d09a)
  c.addChild(leaves1, leaves2, leaves3, leaves4)
  return c
}
// 6개 위치에 배치
const treePositions = [
  { x: -10, y: GRID_GAP_Y * 0.5, scale: 1.2 },
  { x: 4 * GRID_GAP_X + 15, y: GRID_GAP_Y * 0.5, scale: 1.2 },
  { x: 1.5 * GRID_GAP_X, y: -10, scale: 0.9 },
  { x: 2.5 * GRID_GAP_X, y: 2 * GRID_GAP_Y + 10, scale: 0.9 },
  { x: 0.5 * GRID_GAP_X, y: 2 * GRID_GAP_Y + 10, scale: 0.8 },
  { x: 3.5 * GRID_GAP_X, y: 2 * GRID_GAP_Y + 10, scale: 0.8 },
]
```

### 3-7. UI 톤 (App.css)

```css
/* 다크 네이비 헤더 */
.topbar {
  background: linear-gradient(180deg, rgba(20,32,38,.96) 0%, rgba(20,32,38,.92) 100%);
  border-bottom: 2px solid #0e1a1f;
  color: #f5f9f7;
}

/* 시계 콜론 1초 깜빡임 */
@keyframes clock-blink { 0%,49% { opacity: 1 } 50%,100% { opacity: 0 } }
.clock-colon { animation: clock-blink 1s steps(2) infinite; }

/* 사이드 패널 슬라이드 인 */
.side-panel {
  transition: transform .35s cubic-bezier(.22,1,.36,1), opacity .35s ease;
}
.side-panel.closed { transform: translateX(calc(100% + 40px)); opacity: 0; }

/* 뉴스 티커 가로 흐름 */
.ticker-track {
  animation: ticker-scroll 60s linear infinite;
}
@keyframes ticker-scroll {
  0% { transform: translateX(0); }
  100% { transform: translateX(-50%); }
}
```

## 4. 흔한 실수 (1차 시도에서 빠지기 쉬운 3개)

1. **어두운 청록 박스만 그리기** — Twin Lab 자체는 흰 + 옅은 톤. "Twin Lab 룩" 인용했지만 진짜 Twin Lab 게스트 페이지를 안 본 경우. **해결**: 1차 차용 후 Playwright로 Twin Lab 캡쳐 + vision_analyze 1회 강제.
2. **라벨 알약형 누락** — 박스 위 텍스트만 띄우면 Twin Lab이 아님. **해결**: Twin Lab 캡쳐에서 검정 둥근 사각형 + 색 점 + 흰 텍스트 라벨 확인 후 `drawRoomLabel()` 함수 추가.
3. **큰 흰색 플랫폼 누락** — 박스만 8개 그리면 "이산된 방"이 됨. Twin Lab은 "큰 발코니 위 8개 방". **해결**: `drawScene()` 첫 단계에서 흰 사각형 + 옆면 3면 + 타일 결 그리기.

## 5. 사용자 피드백 → 재측정 트리거

| 사용자 신호 | 의미 | 다음 액션 |
|---|---|---|
| "현실적이지 않다" / "원본은 괜찮던데" / "비율이 이상하다" | 1차 차용 실패 | Twin Lab 직접 캡쳐 + vision_analyze + 7차원 모두 재작업 |
| "비율뿐아니라 애니메이션이나 가능한 비주얼적인 부분을 모두 가져와" | 1차 차용 표면적 | Twin Lab 측정 → 7차원 + 애니메이션 5종 (호흡/시계/패널/티커/pulse) 모두 차용 |
| "OK" / "좋다" / "1:1이다" | 차용 성공 | commit + push 사용자 게이트 후 |

## 6. 검증 정형 (Playwright + 비교 캡쳐)

```js
// Twin Lab vs 우리 좌우 비교
node /tmp/compare.mjs
// → .verify/reanalysis-{date}/twinlab-{w}x{h}.png
// → .verify/reanalysis-{date}/our-{w}x{h}.png
```

```bash
# 비교 리포트
.verify/reanalysis-{date}/comparison.md
# 측정값 표 + 수정 내역 + 잔존 이슈 + git 커밋 해시
```

체크리스트:
- [ ] Twin Lab 캡쳐 (1920×1080, 1440×900, 960×600) 저장
- [ ] 우리 프로젝트 캡쳐 동일 해상도 저장
- [ ] vision_analyze로 7차원 측정값 추출
- [ ] 코드 7차원 모두 수정 (drawRoom/drawCharacter/drawScene/App.css)
- [ ] npx tsc 0 에러
- [ ] npx esbuild 0 에러
- [ ] npm run build dist ≤ 1MB
- [ ] Playwright 캡쳐 runtime errors 0개
- [ ] comparison.md 작성 (측정값 표 + 수정 내역 + 잔존 이슈)
- [ ] phase2-pixijs 브랜치에 commit (push는 사용자 게이트 후)

## 7. 잔존 이슈 + 다음 작업 후보

| 이슈 | 영향 | 다음 작업 |
|---|---|---|
| Twin Lab 큰 검정 빌보드/배너 5-6개 | 박스 위 깃발/광고판 부재 | `drawBillboard()` 추가 — 검정 사각형 + 빨간 띠 + 텍스트 |
| Twin Lab 외곽 큰 건물 실루엣 | 플랫폼 둘레 청록 건물 도형 4개 | `drawBackdrop()` 추가 — 큰 청록 빌딩 실루엣 |
| 캐릭터 시선 회전 | 머리 살짝만 (Twin Lab: 책상 모니터 보는 각도) | 머리 rotation 추가 |
| 식물 흔들림 | 정적 | 식물 sine 진동 추가 |
| 부서 상태 색 점 | 모두 톤 색 | status별 idle/waiting/error 색 점 분기 |

## 8. 참고 자료

- 위임 3차 보고서: `/Users/mac/.hermes/cache/delegation/live/deleg_5cc4f7a7/task-0.log` (W17ant/Claude-Office 차용 1차)
- 위임 5차 보고서: 본 세션 (Twin Lab 정밀 재분석 2차)
- Twin Lab 게스트 페이지: https://twin.quantlabnote.com/guest
- W17ant/Claude-Office: https://github.com/W17ant/Claude-Office (MIT)
- 비교 리포트 예시: `/Users/mac/work/hermes-control-room/.verify/reanalysis-2026-08-04/comparison.md`
