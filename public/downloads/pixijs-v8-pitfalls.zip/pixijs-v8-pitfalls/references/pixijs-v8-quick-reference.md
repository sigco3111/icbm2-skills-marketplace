# PixiJS v8 — 자주 쓰는 스니펫 모음

snkrx-web Phase 1~9에서 검증된 패턴만. copy-paste 가능한 형태로.

## 1. Application + stage 설정 (1280×720, DPR)

```ts
import { Application } from 'pixi.js'

const app = new Application()
await app.init({
  width: 1280,
  height: 720,
  background: 0x14161e,
  resolution: window.devicePixelRatio || 1,
  autoDensity: true,           // DPR 자동 보정
  antialias: true,
})
document.body.appendChild(app.canvas)
```

## 2. Container + Graphics with hit area (함정 1 해결)

```ts
import { Container, Graphics, Rectangle, Text } from 'pixi.js'

const cardW = 80, cardH = 90
const container = new Container()
container.x = 100
container.y = 200
container.eventMode = 'static'
container.cursor = 'pointer'
container.hitArea = new Rectangle(0, 0, cardW, cardH)

const box = new Graphics()
box.eventMode = 'static'           // 안전망
box.cursor = 'pointer'
box.hitArea = new Rectangle(0, 0, cardW, cardH)
box.roundRect(0, 0, cardW, cardH, 6).fill(0x14161e).stroke({ width: 2, color: 0x4a5163 })
container.addChild(box)

const label = new Text({ text: 'WARRIOR', style: { fontSize: 12, fill: 0xe7eef8 } })
label.anchor.set(0.5, 0)
label.x = cardW / 2
label.y = cardH + 6
container.addChild(label)

container.on('pointerdown', () => { /* click handler */ })

app.stage.addChild(container)
```

## 3. BlurFilter 글로우 (함정 6)

```ts
import { BlurFilter } from 'pixi.js'

const glow = new BlurFilter({ strength: 4, quality: 4 })
glow.enabled = false  // 기본 OFF, hover/select 시 ON
container.filters = [glow]

// hover 시
glow.enabled = true
// unhover 시
glow.enabled = false
```

## 4. texture / asset 로딩 (함정 2)

```ts
import { Assets, Texture } from 'pixi.js'

// 신규 로딩
const tex = await Assets.load<Texture>('images/hero.png')

// 같은 URL 재호출 → 같은 Texture (캐시 hit)
const sameTex = await Assets.load<Texture>('images/hero.png')

// HTMLCanvasElement → Texture (canvas는 cache key 자동)
const canvasTex = Texture.from(myCanvas)

// ❌ throw
// const tex = Texture.from(imageData)  // ImageData는 PixiJS v8 미지원
```

## 5. chain-follower (snake 본체, 함정 3)

```ts
const TILE = 16
const SPACING = TILE * 1.75  // 28

const segments: Array<{ x: number; y: number }> = []
const head = { x: 400, y: 300 }
for (let i = 0; i < 5; i++) segments.push({ x: head.x - i * SPACING, y: head.y })

function update(dt: number, heading: { x: number; y: number }) {
  // head 이동
  const speed = 100  // px/s
  head.x += heading.x * speed * dt
  head.y += heading.y * speed * dt

  // 각 마디를 직전 마디로부터 spacing 거리로 보정
  let prev = head
  for (let i = 0; i < segments.length; i++) {
    const seg = segments[i]
    const dx = seg.x - prev.x
    const dy = seg.y - prev.y
    const dist = Math.hypot(dx, dy)
    if (dist > 0) {
      seg.x = prev.x - (dx / dist) * SPACING
      seg.y = prev.y - (dy / dist) * SPACING
    }
    prev = seg
  }
}
```

## 6. 화면 경계 반사 (함정 4)

```ts
const W = 1280, H = 720
function clamp(v: number, min: number, max: number) {
  return Math.max(min, Math.min(max, v))
}

function reflectAndClamp(head: { x: number; y: number }, heading: { x: number; y: number }) {
  if (head.x < 0 || head.x > W) {
    heading.x *= -1
    head.x = clamp(head.x, 0, W)
  }
  if (head.y < 0 || head.y > H) {
    heading.y *= -1
    head.y = clamp(head.y, 0, H)
  }
}
```

## 7. 충돌 (head vs enemy, 함정 5)

```ts
function headHitsEnemy(head: { x: number; y: number; r: number }, enemy: { x: number; y: number; r: number }) {
  return Math.hypot(head.x - enemy.x, head.y - enemy.y) <= head.r + enemy.r
}
```

## 8. ticker + spring 1차 임계감쇠 (Phase 5-8 shop-card)

```ts
// 명시적 오일러 + substep 4 (k=200 같은 강성 안정화)
function integrateSpring(s: { x: number; v: number; activeTarget: number; k: number; d: number }, dt: number) {
  const substeps = 4
  const subDt = dt / substeps
  for (let i = 0; i < substeps; i++) {
    const target = s.activeTarget
    const a = -s.k * (s.x - target) - s.d * s.v
    s.v += a * subDt
    s.x += s.v * subDt
  }
}
```

## 9. dev 서버 띄우기 (함정 7 — Playwright 금지)

```bash
# 사용자 수동 검증용. Playwright 자동 검증 금지.
cd /Users/mac/work/<project>
lsof -ti:5173 | head -3                # 기존 인스턴스 점검
npm run dev -- --host 127.0.0.1 --port 5173
# 브라우저: http://127.0.0.1:5173/?test=1
```

## 10. 디버깅 — DevTools 노이즈 무시 (함정 8)

```
# 콘솔에 빨간 에러 떠도 무시:
Uncaught TypeError: r.closest is not a function at content.js:4
# → Chromium 확장 노이즈. PixiJS와 무관. 게임 검증 진행.
```
