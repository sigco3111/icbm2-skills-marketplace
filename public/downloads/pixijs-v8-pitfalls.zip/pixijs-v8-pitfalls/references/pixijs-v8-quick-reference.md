# PixiJS v8 — 자주 쓰는 스니펫 모음

snkrx-web Phase 1~9 + hermes-control-room Twin Lab 룩 이식에서 검증된 패턴만. copy-paste 가능한 형태로.

## 1. Application + stage 설정 (1280×720, DPR)

```ts
import { Application } from 'pixi.js'

const app = new Application()
await app.init({
  width: 1280,
  height: 720,
  background: 0x14161e,
  resolution: window.devicePixelRatio || 1,
  autoDensity: true,           // DPR 자동 보정
  antialias: true,
})
document.body.appendChild(app.canvas)
```

## 2. Container + Graphics with hit area (함정 1 해결)

```ts
import { Container, Graphics, Rectangle, Text } from 'pixi.js'

const cardW = 80, cardH = 90
const container = new Container()
container.x = 100
container.y = 200
container.eventMode = 'static'
container.cursor = 'pointer'
container.hitArea = new Rectangle(0, 0, cardW, cardH)

const box = new Graphics()
box.eventMode = 'static'           // 안전망
box.cursor = 'pointer'
box.hitArea = new Rectangle(0, 0, cardW, cardH)
box.roundRect(0, 0, cardW, cardH, 6).fill(0x14161e).stroke({ width: 2, color: 0x4a5163 })
container.addChild(box)

const label = new Text({ text: 'WARRIOR', style: { fontSize: 12, fill: 0xe7eef8 } })
label.anchor.set(0.5, 0)
label.x = cardW / 2
label.y = cardH + 6
container.addChild(label)

container.on('pointerdown', () => { /* click handler */ })

app.stage.addChild(container)
```

## 3. BlurFilter 글로우 (함정 6)

```ts
import { BlurFilter } from 'pixi.js'

const glow = new BlurFilter({ strength: 4, quality: 4 })
glow.enabled = false  // 기본 OFF, hover/select 시 ON
container.filters = [glow]

// hover 시
glow.enabled = true
// unhover 시
glow.enabled = false
```

## 4. texture / asset 로딩 (함정 2 + 14)

```ts
import { Assets, Sprite, Texture } from 'pixi.js'

// ✅ 신규 로딩 — alias 명시
const tex = await Assets.load<Texture>({ alias: 'hero', src: 'images/hero.png' })

// 캐시에서 동기 조회 (preload 후)
const cached = Assets.cache.get('hero')

// Sprite 생성 — anchor로 발 위치 정렬
const sprite = new Sprite(cached)
sprite.width = 60
sprite.height = 120
sprite.anchor.set(0.5, 1)  // 발 위치

// HTMLCanvasElement → Texture (canvas는 cache key 자동)
const canvasTex = Texture.from(myCanvas)

// ❌ throw
// const tex = Texture.from(imageData)  // ImageData는 PixiJS v8 미지원
```

캐릭터 sprite 패턴 + fallback (함정 14):

```ts
export function drawCharacter(key: string): Container {
  const wrap = new Container()
  const tex = Assets.cache.get(key)
  if (tex && tex.source) {
    const sprite = new Sprite(tex)
    sprite.width = 60
    sprite.height = 120
    sprite.anchor.set(0.5, 1)
    wrap.addChild(sprite)
  } else {
    // fallback — 캡슐 + 머리 원
    const body = new Graphics().roundRect(-12, -38, 24, 32, 10).fill(0x76cdb2)
    const head = new Graphics().circle(0, -45, 10).fill(0xffd7b5)
    wrap.addChild(body, head)
  }
  return wrap
}
```

## 5. chain-follower (snake 본체, 함정 3)

```ts
const TILE = 16
const SPACING = TILE * 1.75  // 28

const segments: Array<{ x: number; y: number }> = []
const head = { x: 400, y: 300 }
for (let i = 0; i < 5; i++) segments.push({ x: head.x - i * SPACING, y: head.y })

function update(dt: number, heading: { x: number; y: number }) {
  // head 이동
  const speed = 100  // px/s
  head.x += heading.x * speed * dt
  head.y += heading.y * speed * dt

  // 각 마디를 직전 마디로부터 spacing 거리로 보정
  let prev = head
  for (let i = 0; i < segments.length; i++) {
    const seg = segments[i]
    const dx = seg.x - prev.x
    const dy = seg.y - prev.y
    const dist = Math.hypot(dx, dy)
    if (dist > 0) {
      seg.x = prev.x - (dx / dist) * SPACING
      seg.y = prev.y - (dy / dist) * SPACING
    }
    prev = seg
  }
}
```

## 6. 화면 경계 반사 (함정 4)

```ts
const W = 1280, H = 720
function clamp(v: number, min: number, max: number) {
  return Math.max(min, Math.min(max, v))
}

function reflectAndClamp(head: { x: number; y: number }, heading: { x: number; y: number }) {
  if (head.x < 0 || head.x > W) {
    heading.x *= -1
    head.x = clamp(head.x, 0, W)
  }
  if (head.y < 0 || head.y > H) {
    heading.y *= -1
    head.y = clamp(head.y, 0, H)
  }
}
```

## 7. 충돌 (head vs enemy, 함정 5)

```ts
function headHitsEnemy(head: { x: number; y: number; r: number }, enemy: { x: number; y: number; r: number }) {
  return Math.hypot(head.x - enemy.x, head.y - enemy.y) <= head.r + enemy.r
}
```

## 8. ticker + spring 1차 임계감쇠 (Phase 5-8 shop-card)

```ts
// 명시적 오일러 + substep 4 (k=200 같은 강성 안정화)
function integrateSpring(s: { x: number; v: number; activeTarget: number; k: number; d: number }, dt: number) {
  const substeps = 4
  const subDt = dt / substeps
  for (let i = 0; i < substeps; i++) {
    const target = s.activeTarget
    const a = -s.k * (s.x - target) - s.d * s.v
    s.v += a * subDt
    s.x += s.v * subDt
  }
}
```

## 9. dev 서버 띄우기 (함정 7 — Playwright 정적 씬 OK / 게임 loop 무거우면 수동 검증)

```bash
# 사용자 수동 검증용. Playwright 자동 검증은 정적 씬 OK.
cd /Users/mac/work/<project>
lsof -ti:5173 | head -3                # 기존 인스턴스 점검
npm run dev -- --host 127.0.0.1 --port 5173
# 브라우저: http://127.0.0.1:5173/?test=1

# 게임 loop가 무거운 경우 → 사용자 수동 검증 fallback
```

## 10. 디버깅 — DevTools 노이즈 무시 (함정 8)

```
# 콘솔에 빨간 에러 떠도 무시:
Uncaught TypeError: r.closest is not a function at content.js:4
# → Chromium 확장 노이즈. PixiJS와 무관. 게임 검증 진행.
```

## 11. Twin Lab 룩 isometric 룸 (함정 13)

```ts
// iso 좌표 변환 — 2:1 dimetric
export function iso(x: number, y: number): { x: number; y: number } {
  return { x: x - y, y: (x + y) * 0.5 }
}

export const ROOM_W = 200  // 월드 폭
export const ROOM_D = 160  // 월드 깊이
export const WALL_H = 80   // 벽 높이

// 박스 7겹 그리기 — 바닥 + 2벽 + 지붕 평면 + 지붕 옆면 + 창문 + 문 + decoration
// (자세한 패턴은 SKILL.md 함정 13 참조)

// 4×2 그리드 배치
const GRID_GAP_X = ROOM_W + 30
const GRID_GAP_Y = ROOM_D + 50
SCENE_ROOMS.forEach((room, idx) => {
  const px = (idx % 4) * GRID_GAP_X
  const py = Math.floor(idx / 4) * GRID_GAP_Y
  roomContainer.x = iso(px, py).x
  roomContainer.y = iso(px, py).y
})

// 룸 박스 hit area — WALL_H 위까지 포함
roomShape.hitArea = new Rectangle(-ROOM_W / 2, -WALL_H - ROOM_D / 2, ROOM_W + ROOM_D, WALL_H + ROOM_D)
```

**decoration 8종 (방마다 다르게)**:
`plant`, `lamp`, `server`, `bookshelf`, `whiteboard`, `laptop`, `printer`, `coffee`

## 12. 캐릭터 sprite + 호흡 애니메이션 (함정 14)

```ts
// preload는 App.tsx의 Application init 이전에 호출
await preloadCharacters(['char-a', 'char-b', 'char-c'])

// drawScene에서 drawCharacter 호출
const ch = drawCharacter('char-a')
const deskCenter = iso(ROOM_W * 0.45, ROOM_D * 0.45)
ch.x = deskCenter.x - 14
ch.y = deskCenter.y + 16  // 책상 위 + 발 위치 보정
roomContainer.addChild(ch)

// 호흡 애니메이션 (ticker)
app.ticker.add((ticker) => {
  const breathe = 1 + Math.sin(performance.now() / 700 + phase) * 0.012
  ch.scale.set(breathe)
})
```

## 13. PNG 다운스케일 — macOS sips (PIL 없이)

```bash
# PIL이 없거나 venv 호환 안 될 때 macOS native
for f in *.png; do
  sips -Z 160 "$f" --out "$f" > /dev/null 2>&1
done

# -Z 160 = 긴 변 160px로 축소. 비율 유지. PNG는 다시 PNG로 저장.
# 197×527 → 약 60×160 (1080KB → ~20KB per file)
```

PIXEL 아트는 NEAREST 옵션이 좋지만 sips는 NEAREST 직접 미지원. 시각적으로는 LANCZOS도 60px 표시에서는 픽셀 느낌이 유지됨.

## 14. Playwright 스크린샷 — `/tmp/*.mjs` + 글로벌 패키지 import

```js
import pw from '/opt/homebrew/lib/node_modules/playwright/index.js'
const { chromium } = pw

const browser = await chromium.launch()
const ctx = await browser.newContext({ viewport: { width: 1600, height: 1000 } })
const page = await ctx.newPage()

const errors = []
page.on('pageerror', (e) => errors.push(`pageerror: ${e.message}`))
page.on('console', (msg) => { if (msg.type() === 'error') errors.push(msg.text()) })

await page.goto(url, { waitUntil: 'networkidle', timeout: 30000 })
await page.waitForTimeout(3500)  // PixiJS init + sprite 로드 대기

await page.screenshot({ path: out })
if (errors.length) console.log('runtime errors:', errors)
else console.log('runtime errors: none')

await browser.close()
```

NODE_PATH는 ESM에서 무시됨 → 절대 경로 + CommonJS default import가 유일한 방법.

## 15. PIXI canvas fullscreen + CSS (Twin Lab 룩 viewport)

```css
html, body, #root { margin: 0; width: 100%; height: 100%; overflow: hidden }
body { background: #f5f9f7; overscroll-behavior: none; touch-action: none }
.app-root { position: fixed; inset: 0; overflow: hidden }
.pixi-stage { position: absolute; inset: 0; z-index: 0 }
.pixi-stage canvas {
  width: 100vw !important;
  height: 100vh !important;
  image-rendering: pixelated;
  transform: scale(var(--zoom));
  transform-origin: 42% 48%;
}
```