# snkrx-web Phase 5-8 — PixiJS v8 hit area 픽스 실측 사례

2026-07-24 시각 검증에서 발견된 "호버 안 됨 + 클릭이 호버처럼 보임" 증상의 실제 코드 diff. **`Container.hitArea` 명시 + 자식 `Graphics` 안전망** 2-step 픽스.

## 배경

Phase 5-8 `setupShopCardDemo` (snkrx-web/src/main.ts:1041~1198) — 카드 3장 데모. 코드는 정상으로 보임:

```ts
const container = new Container()
container.eventMode = 'static'
container.cursor = 'pointer'

const box = new Graphics()  // 매 frame clear() 후 다시 그림
container.addChild(box)
```

이벤트 핸들러도 정상:

```ts
h.container.on('pointerenter', () => shopCardFx.hoverEnter(h.cardState.id))
h.container.on('pointerleave', () => shopCardFx.hoverExit(h.cardState.id))
h.container.on('pointerdown', () => { /* select/unselect 토글 */ })
```

## 증상 (사용자 시각 검증)

스크린샷 분석 (composer_2026-07-24_05-24-34-511_c96194.png):
- 호버해도 카드 변화 없음
- 클릭하면 글로우 + 녹색 보더만 (호버처럼 보임)
- 가운데 카드 안 보임 (사용자가 클릭으로 die() 시킨 후 페이드)

DevTools 콘솔에 `r.closest is not a function at content.js:4` — **이건 Chromium 확장 노이즈로 무관**.

## 진단 — 매 frame clear() 가 hit area 를 소실

`ticker.add` 안의 `h.box.clear()` → `.roundRect().fill().stroke()` 흐름:

```ts
app.ticker.add((ticker) => {
  for (const h of handles) {
    // ...
    h.box.clear()  // ← 이 호출이 box의 hit area를 소실
    h.box.roundRect(0, 0, cardW, cardH, 6).fill(...)
  }
})
```

PixiJS v8의 `Graphics.clear()`는 도형 데이터 + hit area 모두 초기화. 새 도형을 그려도 Container의 `hitArea`가 명시 안 됐으면 자식 Graphics의 hit area가 container의 transform과 함께 합쳐질 때 경계가 부정확.

## 픽스 (3개 파일)

### 1. `src/main.ts` — import + Container/Box hit area

```diff
-import { Application, Assets, BlurFilter, Container, Graphics, Sprite, Text, type Filter } from 'pixi.js'
+import { Application, Assets, BlurFilter, Container, Graphics, Rectangle, Sprite, Text, type Filter } from 'pixi.js'
```

```diff
   const container = new Container()
   container.label = id
   container.x = startX + i * 100
   container.y = cardY
   container.eventMode = 'static'
   container.cursor = 'pointer'
+  // ★ fix: PixiJS v8 hit area — container 자체에 Rectangle 명시
+  container.hitArea = new Rectangle(0, 0, cardW, cardH)

   const box = new Graphics()
+  box.eventMode = 'static'
+  box.cursor = 'pointer'
+  box.hitArea = new Rectangle(0, 0, cardW, cardH)
   container.addChild(box)
```

### 2. `src/shop-card-fx.ts` — 호버/펄스 정책

**호버 비활성 (no-op)**: 사용자가 spring 진동(0.1~0.7) 안 이쁘다고 명시:

```ts
hoverEnter(id: string): void {
  // no-op — 사용자가 spring 진동 안 이쁘다고 명시
  void id
}

hoverExit(id: string): void {
  void id
}
```

**펄스 진폭 0 → 0.02** (98~102% 살짝 진동):

```diff
-    this.defaultPulseAmp = opts?.pulseAmplitude ?? 0 // 이전 0.03 → 0
+    this.defaultPulseAmp = opts?.pulseAmplitude ?? 0.02 // 살짝만 진동
```

### 3. `src/shop-card-fx.test.mjs` — 호버 no-op 테스트로 교체

```diff
-test('ShopCardFX.update: idle 상태에서 hoverEnter 하면 spring 이 다시 떨어진다', () => {
+test('ShopCardFX.update: hoverEnter 는 no-op (2026-07-24 호버 비활성)', () => {
   const fx = new ShopCardFX()
   const c = fx.add({ id: 'a' })
   for (let i = 0; i < 100; i++) fx.update(0.01)
   assert.equal(c.phase, 'idle')
+  const beforeX = c.spring.x
   fx.hoverEnter('a')
-  assert.equal(c.phase, 'hovered')
+  assert.equal(c.phase, 'idle')  // no-op
+  assert.equal(c.spring.x, beforeX)
   // ...
 })
```

펄스 진폭 0.02에 맞춰 #11번 테스트 범위 조정:

```diff
-  assert.ok(minSx < 1 - 0.01, ...)
-  assert.ok(maxSx > 1 + 0.01, ...)
+  assert.ok(minSx < 1 - 0.005, ...)
+  assert.ok(maxSx > 1 + 0.005, ...)
+  assert.ok(minSx >= 1 - 0.02 - 1e-9, ...)
+  assert.ok(maxSx <= 1 + 0.02 + 1e-9, ...)
```

## 결과

- tsc clean / vite build OK
- shop-card-fx 20/20 통과 (이전 13/20)
- 전체 129/131 (fail 2는 기존 shaders GLSL v8 형식 검증 — 무관)
- 시각 검증: 호버는 no-op, 클릭 시 노란 보더 + 0.02 펄스 + 글로우 정상

## 학습

1. **Container.hitArea 명시는 hit area 누락의 1차 해결책**. 자식 Graphics의 `clear()`는 hit area를 소실시키지만 container의 `hitArea`는 유지.
2. **이벤트 핸들러는 정상이지만 그래픽이 안 잡히는** 상황 = hit area 함정. 코드 리뷰에서 "이벤트는 잘 붙었는데 왜 안 되지?" 상황 = 함정 1 의심.
3. **사용자 선호 ("호버는 빼자")** = 운영자가 강제하지 말고 no-op 정책으로 정착. 이후 호버 관련 단위 테스트도 no-op 검증으로 교체.
