---
name: pixijs-v8-pitfalls
description: PixiJS v8 (8.x) 게임/웹 포팅 시 만나는 class-level 함정 모음. hit area 누락, `Texture.from()` 캐싱, BlurFilter/chain-follower/LÖVE→웹 변환 패턴까지. snkrx-web Phase 1~9 실측 기반. "호버 안 됨", "클릭 안 됨", "텍스처 안 보임", "GL 텍스처 캐시", "BlurFilter", "ImageData throw", "마우스 이벤트가 Graphics 통과" 같은 PixiJS v8 시각/입력 버그에 발동.
version: 1.0.0
author: HyeRin
license: MIT
metadata:
  hermes:
    tags: [pixijs, pixi-v8, game-dev, web-port, hit-area, texture, input]
    related_skills: [kanban-project-delivery, godot-control-input-quirks]
---

# PixiJS v8 Pitfalls — 게임/웹 포팅 class-level 함정

snkrx-web (PixiJS 8.19.0) Phase 1~9 / 30 카드 실측에서 만난 함정. 모든 LÖVE→웹 포팅, PixiJS v8 신규 프로젝트에 동일 적용.

## 사용 시기

- PixiJS 8.x 로 게임/앱을 포팅하거나 새로 작성할 때
- "호버 안 됨", "클릭 안 됨", "마우스 이벤트가 Graphics 통과" 증상
- "텍스처 안 보임", "GL 텍스처 캐시 누락"
- "Container vs Graphics hit area 불일치" 디버깅

## 함정 1 — `eventMode='static'` 만으로는 hit area 가 안 잡힘 (★★★ 가장 빈번)

PixiJS v8에서 `Container`에 `eventMode='static'`을 줘도 자식 `Graphics`가 매 프레임 `clear()`를 호출하면 **hit area가 사라져서** pointer 이벤트가 통과해버림.

**증상**: 호버/클릭 안 됨. 콘솔에 에러 없음. Graphics 모양은 보이지만 인터랙션만 안 됨.

**원인**: PixiJS v8 hit area는 두 layer —

1. `Container` 자체의 `hitArea` (없으면 자식 Graphics 의 hit area 합집합)
2. 자식 `Graphics` 의 hit area (마지막으로 그린 `rect()`/`circle()` 등의 도형)

`box.clear()` 후 `.rect().fill()` 다시 그려도 새 도형이 hit area로 잡혀야 하지만, **Container의 hitArea가 명시되지 않으면 자식 Graphics의 hit area가 container의 transform과 함께 합쳐질 때 경계가 부정확**해진다.

**해결 — 두 곳 모두 명시**:

```ts
import { Container, Graphics, Rectangle } from 'pixi.js'

const container = new Container()
container.x = 100
container.y = 200
container.eventMode = 'static'
container.cursor = 'pointer'
// ★ fix: 정적 hit area 명시. 자식 Graphics가 매 프레임 clear 되어도
// container 자체의 hit area는 유지됨.
container.hitArea = new Rectangle(0, 0, cardW, cardH)

const box = new Graphics()
// 안전망: box 자체에도 hit area
box.eventMode = 'static'
box.cursor = 'pointer'
box.hitArea = new Rectangle(0, 0, cardW, cardH)
container.addChild(box)
```

체크리스트:
- [ ] `Container.hitArea = new Rectangle(0, 0, w, h)` 명시
- [ ] 자식 `Graphics`도 `eventMode='static'` + `hitArea` (안전망)
- [ ] `clear()` 후 다시 그려도 hit area 보존됨

## 함정 2 — `Texture.from()` 은 캐시만, 신규 로딩은 `Assets.load()`

```ts
// ❌ PixiJS v8에서 canvas/ImageData를 직접 전달하면 throw
const tex = Texture.from(canvas)        // cache hit만, 신규면 undefined
const tex = Texture.from(imageData)     // throws

// ✅ 자산 로딩
import { Assets } from 'pixi.js'
const tex = await Assets.load<Texture>('images/hero.png')

// ✅ HTMLImageElement/HTMLCanvasElement → Texture (캐시 키 충돌 방지)
const tex = Texture.from(canvas)  // canvas는 캐시 키가 자동 생성됨
```

**캐시 충돌 함정**: 같은 URL 을 두 번 `Assets.load` 해도 같은 Texture 반환. 의도적으로 새 인스턴스가 필요하면 `Assets.load({ src, data: { ... } })` 또는 `new Texture({ source })`.

## 함정 3 — chain-follower = 누적 거리 (history 스냅샷 X)

snake / chain / 꼬리 따라가는 게임에서 뱀 본체를 history 좌표 스냅샷으로 그리면 **회전 시 직선으로 늘어지는** 버그 발생.

**원인**: 각 마디를 `history[i] = head.position` 으로 저장하면, head가 빠르게 방향 전환할 때 모든 마디가 같은 직선 위에 놓임.

**해결 — 누적 거리 알고리즘**:

```ts
// 각 마디가 직전 마디로부터 spacing 거리 유지. 매 frame distance 보정.
const spacing = TILE * 1.75  // 16 → 28, 화면/속도에 따라 조정
for (const segment of segments) {
  let prev = head
  for (let i = 1; i < segments.length; i++) {
    const seg = segments[i]
    const dx = seg.x - prev.x
    const dy = seg.y - prev.y
    const dist = Math.hypot(dx, dy)
    if (dist > 0) {
      // spacing 거리만큼 뒤로
      seg.x = prev.x - (dx / dist) * spacing
      seg.y = prev.y - (dy / dist) * spacing
    }
    prev = seg
  }
}
```

회전/곡선 추적에 안정적. spacing = TILE * 1.75 가 snkrx-web 기준 최적.

## 함정 4 — 화면 경계 충돌 = heading 축 단위 반사 + head 클램프

snake 게임에서 head가 화면 밖으로 나갈 때 단순히 `x = clamp(x, 0, W)` 하면 head가 벽에 박혀 멈춤. **heading 축 단위 반사** + head만 클램프:

```ts
// heading = head의 마지막 속도 벡터
if (head.x < 0 || head.x > W) {
  heading.x *= -1
  head.x = clamp(head.x, 0, W)
}
if (head.y < 0 || head.y > H) {
  heading.y *= -1
  head.y = clamp(head.y, 0, H)
}
```

전체 뱀이 따라가며 자연스럽게 튕김.

## 함정 5 — 충돌 거리 = `Math.hypot(dx,dy) <= head.r + enemy.r`

원형 hit box 충돌 시 `dx*dx + dy*dy <= (r1+r2)^2` 비교가 표준. 단 snkrx-web 실측에서 **head 8→12** 가독성 + 충돌 정확도 균형점.

## 함정 6 — BlurFilter 는 가벼운 글로우 효과에 충분

`pixi-filters` 패키지의 `OutlineFilter`/`GlowFilter`는 추가 의존성. 카드 hover/select 글로우 같은 단순 효과는 `pixi.js` 코어의 `BlurFilter({ strength: 4, quality: 4 })` 한 줄로 충분:

```ts
import { BlurFilter } from 'pixi.js'
const glow = new BlurFilter({ strength: 4, quality: 4 })
glow.enabled = false  // 기본 OFF
container.filters = [glow]
// hover/select 시: glow.enabled = true
```

## 함정 7 — Playwright/Chromium 자동 검증은 macOS에서 환경 의존적

PixiJS 게임의 시각 검증을 자동화하려고 Playwright/Chromium을 띄울 때:

- snkrx-web Phase 5~9에서는 macOS + PixiJS 게임 + Playwright가 Chromium 비정상 종료 → 워커 hang으로 30분+ 갇힌 사례가 있어 **사용자 브라우저 수동 검증**으로 대체.
- 그러나 hermes-control-room (PixiJS v8 + 8개 룸 + 정적 sprite)에서는 Playwright가 정상 작동함. **장면이 정적(애니메이션만 ticker sin wave)이고 캐릭터 sprite PNG만 로딩**하는 경우 Playwright 검증이 효율적.

### 작동 조건 + 우회법 (★★★ 실측)

`/tmp/...mjs`에서 Playwright 실행 시 macOS 글로벌 패키지를 import하는 함정:

```js
// ❌ 모두 실패
import { chromium } from 'playwright'                      // ERR_MODULE_NOT_FOUND
import { chromium } from '/opt/homebrew/lib/node_modules/playwright/index.mjs'  // syntax error
import { chromium } from '/opt/homebrew/lib/node_modules/playwright/index.js'   // ESM/CJS mismatch
// NODE_PATH=/opt/homebrew/lib/node_modules → 무시됨 (ESM은 NODE_PATH 미사용)

// ✅ CommonJS default export 패턴
import pw from '/opt/homebrew/lib/node_modules/playwright/index.js'
const { chromium } = pw
```

이유: Playwright 패키지 (`/opt/homebrew/lib/node_modules/playwright/index.js`)는 CommonJS라서 named import 불가능. ESM에서 default import → 구조분해 순서로만 가능.

스크린샷 검증 정형:

```js
import pw from '/opt/homebrew/lib/node_modules/playwright/index.js'
const { chromium } = pw

const browser = await chromium.launch()
const ctx = await browser.newContext({ viewport: { width: 1600, height: 1000 } })
const page = await ctx.newPage()

const errors = []
page.on('pageerror', (e) => errors.push(`pageerror: ${e.message}`))
page.on('console', (msg) => { if (msg.type() === 'error') errors.push(msg.text()) })

await page.goto(url, { waitUntil: 'networkidle', timeout: 30000 })
await page.waitForTimeout(3500)  // PixiJS init + sprite PNG 로드 대기

await page.screenshot({ path: out })
if (errors.length) console.log('runtime errors:', errors)
else console.log('runtime errors: none')

await browser.close()
```

체크리스트:
- [ ] `/tmp/*.mjs`에서 Playwright 실행 시 절대 경로 + CommonJS default import
- [ ] PixiJS init + sprite PNG 로드 대기 3초 이상
- [ ] `pageerror` + `console.error` 양쪽 수집
- [ ] snkrx-web처럼 게임 loop가 무거운 경우 → 사용자 수동 검증 fallback (`?test=1`)

## 함정 8 — DevTools 콘솔 `r.closest is not a function at content.js:4` = Chromium 확장 노이즈 (무시)

PixiJS 게임 dev 중 DevTools 콘솔에 빨간 `Uncaught TypeError: r.closest is not a function at content.js:4` 가 떠도 **게임과 무관**. Chrome 확장 (번역/광고 차단)이 PixiJS 내부 접근하다 실패한 것. **무시하고 시각 검증 진행**.

## 함정 9 — 호버 spring 진동이 시각적으로 거슬림 → no-op 정책

사용자 피드백: `hoverEnter` 시 spring을 0.1~0.7 까지 끌어내렸다가 1.0으로 복귀하는 spring 진동이 카드 크기 변동으로 보여서 **호버 자체를 빼는 게 깔끔**. 클릭(펄스 amp=0.02 = 98~102%)만 살림.

```ts
hoverEnter(id: string): void {
  // no-op — 사용자가 spring 진동 안 이쁘다고 명시
  void id
}
```

snkrx-web 에서 `b29a55a` "Phase 5-8 호버 효과 비활성화" 커밋이 그 정책 결정 시점. 이후 호버 없이도 클릭 펄스로 충분.

## 함정 10 — `pixi-react@^8` 요구와 실제 패키지 버전 불일치 + Application destroy race condition

PixiJS 메이저 버전과 React 바인딩 패키지의 메이저 버전은 자동으로 맞지 않는다. 작업 시작 전에 반드시 registry에서 `npm view pixi-react versions --json`와 `npm view pixi.js version`을 따로 확인한다. `pixi-react@8`이 존재하지 않는 경우에는 억지로 설치하지 말고, 바인딩이 꼭 필요하지 않다면 PixiJS v8 직접 API(`Application`, `Container`, `Graphics`, `Text`)를 React `useEffect` lifecycle 안에서 초기화한다. 실제 설치 버전과 직접 API 선택 사유는 README에 기록하고 `npm ls pixi.js pixi-react react react-dom`으로 lockfile 상태를 확인한다.

### 10-A — PixiJS v8 직접 API 사용 시 Application destroy race condition (★★★)

PixiJS v8의 `Application.destroy()`는 **async + 내부적으로 resize observer를 비동기로 cleanup**한다. v7 정형(`app.destroy(true, true)`)을 그대로 이식하면 React StrictMode 더블 마운트 + effect cleanup race condition에서 **`Uncaught TypeError: this._cancelResize is not a function`** 콘솔 에러가 폭발한다. v8의 destroy는 두 가지 형태:
- `app.destroy(rendererDestroyOptions?, options?)` — `Promise<void>` 반환 (v8 정석)
- v7 시그니처 `app.destroy(destroyOptions, baseTextureOptions)` 는 **deprecated** — v8에서 internal `_cancelResize` 콜백 시그니처가 달라짐

**증상**:
- 콘솔: `Uncaught TypeError: this._cancelResize is not a function at App.tsx:NN at pixi__js.js?v=XXX:1523`
- 두 번 연속 보고 (cleanup → cleanup, 또는 StrictMode 더블 호출)
- 화면은 뜨지만 디버깅 노이즈 + memory leak

**해결 정형 — `cancelled` 플래그 + wheel handler 분리 + try/catch destroy**:

```ts
useEffect(() => {
  let app: Application | undefined;
  let cancelled = false;
  let wheelHandler: ((e: WheelEvent) => void) | undefined;
  const mount = canvasRef.current;
  if (!mount) return;

  (async () => {
    app = new Application();
    await app.init({ resizeTo: mount, background: 0xf5f9f7, antialias: false, preference: 'webgl' });
    if (cancelled) {
      // ★ cleanup이 init보다 먼저 호출된 경우 — destroy는 await으로 안전하게
      await app.destroy(true, { children: true });
      return;
    }
    mount.appendChild(app.canvas);
    drawScene(app, state, (id) => setSelected(id));
    app.canvas.style.imageRendering = 'pixelated';
    wheelHandler = (e: WheelEvent) => {
      e.preventDefault();
      setZoom((z) => Math.max(.75, Math.min(1.35, z - e.deltaY * 0.0005)));
    };
    mount.addEventListener('wheel', wheelHandler, { passive: false });
  })();

  return () => {
    cancelled = true;
    if (wheelHandler) mount.removeEventListener('wheel', wheelHandler);
    // ★ destroy는 await 안 해도 cleanup은 진행되지만, race로 이중 destroy 시 throw 가능
    if (app) {
      try { app.destroy(true, { children: true }); } catch (e) { /* ignore double-destroy */ }
    }
  };
}, [state]);
```

**세 가지 핵심**:
1. **`cancelled` 플래그** — `await app.init()` 중 cleanup이 먼저 호출되면 init 완료 후 즉시 destroy (mount 안 하고)
2. **wheel handler를 closure 외부로** — cleanup에서 안정적으로 removeEventListener
3. **`try/catch` destroy** — PixiJS v8 destroy가 비동기라 StrictMode 더블 cleanup이나 빠른 remount에서 이중 destroy 가능

체크리스트:
- [ ] `cancelled = true` 플래그 추가
- [ ] wheel/scroll/resize 등 DOM listener는 closure 외부 변수에 보관
- [ ] destroy 호출은 `try { ... } catch {}` (no-op로 swallow)
- [ ] React StrictMode 켜진 환경에서 마운트→언마운트→재마운트 테스트
- [ ] dev server에서 5분 이상 idle 후 콘솔에 `_cancelResize` 안 떠야 통과

### 10-B — `fetch().then().catch()` 패턴이 콘솔에 빨간 노이즈 (★★★ 사용자 UX)

상태 파일 (`/state.json`)을 PixiJS v8 씬 위에서 fetch할 때 흔한 실수:

```ts
// ❌ 콘솔에 [err: 'not found'] 빨간 노이즈
useEffect(() => {
  fetch('/state.json')
    .then((r) => (r.ok ? r.json() : Promise.reject()))
    .then((x: State) => setState(normalizeState(x)))
    .catch(() => setState(normalizeState({})))
}, [])
```

`Promise.reject()`를 then 안에서 throw하면 콘솔에 `Uncaught (in promise) [err: 'not found']` 가 빨갛게 찍힘. fallback이 의도된 동작이라도 사용자/QA가 보면 버그로 인식.

**해결 — async/await + try/catch (silent fallback)**:

```ts
useEffect(() => {
  (async () => {
    try {
      const r = await fetch('/state.json')
      if (r.ok) {
        const x = await r.json()
        setState(normalizeState(x))
      } else {
        setState(normalizeState({}))  // 404/500 → silently fallback
      }
    } catch {
      setState(normalizeState({}))  // network error → silently fallback
    }
  })()
}, [])
```

**핵심**: `Promise.reject()` 호출 자체가 콘솔에 unhandled rejection을 남긴다. 상태 분기는 `if (r.ok)` 후 `else`로 처리하고, 진짜 catch에는 네트워크 에러만 모이게 한다.

체크리스트:
- [ ] fetch 결과 분기는 `if (r.ok)` + `else` (then 안에서 reject ❌)
- [ ] 진짜 catch는 네트워크/JSON 파싱 에러만
- [ ] fallback setState는 silent — 콘솔 노이즈 ❌
- [ ] state.json이 있어도/없어도 UI 동작 동일

## 함정 11 — R3F 제거 후 TS include에 남은 레거시 컴포넌트

Three/R3F 의존성 제거만으로는 충분하지 않다. `tsconfig.app.json`이 `src` 전체를 include하면 사용하지 않는 레거시 `.tsx`도 검사되어 삭제된 패키지 import 오류를 낸다. 렌더러 전환 시 `search_files`로 `@react-three`, `three` import를 전부 찾고, 미참조 레거시 파일을 제거하거나 교체한 뒤 `npx tsc --noEmit -p tsconfig.app.json`과 esbuild 진입점 번들을 둘 다 실행한다. 빈 `export {}`는 임시 정리로만 사용하고, 커밋 전 dead file 삭제와 `git diff --stat` 확인을 우선한다.

## 함정 12 — Pixi 씬의 클릭과 캐릭터 발 위치를 수학적으로 고정

2.5D dimetric 씬에서는 시각적 중심 기준 배치가 캐릭터를 떠 보이게 한다. 박스 면을 먼저 그리고 캐릭터 컨테이너의 pivot을 발 위치로 둔다. 표준 2:1 투영은 `screenX=(gridX-gridY)*scale`, `screenY=(gridX+gridY)*scale*0.5` 같은 고정 변환으로 구현하며 카메라 회전 없이 wheel 입력은 world scale만 조절한다. 클릭 Container에는 `eventMode='static'`과 명시적 `hitArea = new Rectangle(...)`를 함께 부여한다.

## 함정 13 — Twin Lab 룩 isometric 룸 = 박스 7겹 + decoration (★★★ 2.5D 관제실)

W17ant/Claude-Office (56⭐, MIT) 스타일의 isometric 룸 (Twin Lab 룩)을 PixiJS v8로 그릴 때 흔한 실수 — 박스 4면 중 visible 2면만 그리고 끝내는 것. 진짜 룩은 다음 **7겹**을 모두 그려야 한다:

1. **바닥 평면** (다이아몬드형 rect)
2. **좌측 벽** (x=0 면 — `bottomNear → bottomFar → bottomFar+riseY → bottomNear+riseY`)
3. **우측 벽** (y=0 면)
4. **지붕 평면** (ROOM_W × ROOM_D 평면을 WALL_H 만큼 위로)
5. **지붕 옆면** (좌/우측 벽 위 모서리 띠 — 입체감의 핵심)
6. **창문** (벽 중앙에 작은 박스 + 창살)
7. **문** (벽 끝에 작은 박스 + 손잡이)
8. **책상 + 의자 + 모니터** (방 한가운데)
9. **decoration 1~2개** (방마다 다른 종류 — Twin Lab 룩의 차별화 포인트)

**iso 좌표 변환 정형** (2:1 dimetric):

```ts
export function iso(x: number, y: number): { x: number; y: number } {
  return { x: x - y, y: (x + y) * 0.5 }
}
```

**벽 한 면 그리기 정형** (riseY = -WALL_H로 위로):

```ts
function drawWallFace(
  bottomNear: { x: number; y: number },
  bottomFar: { x: number; y: number },
  riseY: number,  // 음수 = 위로 올라감
  fill: number,
  outline: number,
): Graphics {
  const g = new Graphics()
  g.moveTo(bottomNear.x, bottomNear.y)
    .lineTo(bottomFar.x, bottomFar.y)
    .lineTo(bottomFar.x, bottomFar.y + riseY)  // riseY가 음수면 위로
    .lineTo(bottomNear.x, bottomNear.y + riseY)
    .closePath()
    .fill(fill)
    .stroke({ width: 1.5, color: outline, alpha: 0.55 })
  return g
}
```

**decoration 8종 (Twin Lab 룩 차별화 포인트)**:

```ts
type DecorKind = 'plant' | 'lamp' | 'server' | 'bookshelf' | 'whiteboard' | 'laptop' | 'printer' | 'coffee'
```

각 방마다 다른 decoration 1개를 선택하고, 방마다 다른 책상 색(`deskColor`)을 적용하면 Twin Lab 룩 1:1에 근접. 같은 박스라도 책상 색 + decoration 조합이 다르면 시각적으로 완전히 다른 방으로 인식됨.

**카펫 = 방 안 작은 다이아몬드 평면**:

```ts
function drawCarpet(color: number): Graphics {
  const w = ROOM_W * 0.55, d = ROOM_D * 0.45
  const cx = ROOM_W * 0.5, cy = ROOM_D * 0.5
  const g = new Graphics()
  g.moveTo(iso(cx - w/2, cy - d/2).x, iso(cx - w/2, cy - d/2).y)
    .lineTo(iso(cx + w/2, cy - d/2).x, iso(cx + w/2, cy - d/2).y)
    .lineTo(iso(cx + w/2, cy + d/2).x, iso(cx + w/2, cy + d/2).y)
    .lineTo(iso(cx - w/2, cy + d/2).x, iso(cx - w/2, cy + d/2).y)
    .closePath()
    .fill(color).stroke({ width: 1, color: 0xffffff, alpha: 0.25 })
  return g
}
```

**hit area 함정**: 룸 박스 전체에 `hitArea = new Rectangle(-ROOM_W/2, -WALL_H - ROOM_D/2, ROOM_W + ROOM_D, WALL_H + ROOM_D)`로 잡아야 룸 어느 부분을 클릭해도 방이 선택됨. ROOM_W/2만 잡으면 모서리 클릭이 누락됨.

체크리스트:
- [ ] iso() 좌표 변환은 `(x-y, (x+y)*0.5)` — 2:1 dimetric
- [ ] 박스 7겹 모두 그림 (바닥 + 2벽 + 지붕 평면 + 지붕 옆면 + 창문 + 문)
- [ ] decoration은 방마다 다른 종류 1~2개
- [ ] 책상 색은 방마다 다름
- [ ] 카펫은 방마다 다른 톤
- [ ] hit area는 룸 박스 전체 + WALL_H 위까지 포함

## 함정 14 — `Assets.load({ alias, src })` + `Sprite` + fallback 패턴 (★★★)

캐릭터 sprite PNG를 PixiJS v8에서 로딩할 때 흔한 실수 — `Texture.from('path.png')`로 직접 캐시 키 충돌 또는 preload 누락.

**정형 — `alias` 명시 + fallback 도형**:

```ts
import { Assets, Container, Graphics, Sprite } from 'pixi.js'

export async function preloadCharacters(keys: string[]): Promise<void> {
  await Promise.all(
    keys.map((k) =>
      Assets.load({ alias: k, src: `assets/characters/${k}.png` }).catch((err) => {
        console.warn(`캐릭터 로드 실패: ${k}`, err)
      }),
    ),
  )
}

export function drawCharacter(key: string): Container {
  const wrap = new Container()
  const tex = Assets.cache.get(key)  // 캐시에서 조회 (Promise X)
  if (tex && tex.source) {
    const sprite = new Sprite(tex)
    sprite.width = 60
    sprite.height = 120
    sprite.anchor.set(0.5, 1)  // ★ 발 위치 기준 정렬
    wrap.addChild(sprite)
  } else {
    // fallback — 캡슐 몸통 + 머리 원
    const body = new Graphics().roundRect(-12, -38, 24, 32, 10).fill(0x76cdb2)
    const head = new Graphics().circle(0, -45, 10).fill(0xffd7b5)
    wrap.addChild(body, head)
  }
  return wrap
}
```

**핵심 포인트**:

1. **`Assets.load({ alias, src })`** — alias를 명시해야 `Assets.cache.get(alias)`로 조회 가능. src만 쓰면 캐시 키가 URL 전체가 되어 관리가 어려움.
2. **`Assets.cache.get(alias)`** — `Assets.load` 결과를 Promise가 아닌 동기 조회. preload 후 `drawCharacter`에서 즉시 사용 가능.
3. **fallback 도형** — sprite 로드 실패 시 화면이 비지 않도록 캡슐+원 같은 단순 도형으로 대체. `tex.source` 체크는 PixiJS v8에서 Texture 유효성 확인 표준.
4. **anchor.set(0.5, 1)** — 픽셀 아트 캐릭터는 발 위치로 정렬해야 책상 옆에 자연스럽게 서 있음. anchor 미설정 시 좌상단 정렬 → 캐릭터가 떠 보임.

**App.tsx preload 순서**:

```ts
;(async () => {
  try {
    await preloadCharacters(['char-a', 'char-b'])
  } catch (err) {
    console.warn('캐릭터 preload 일부 실패 — fallback 사용', err)
  }
  app = new Application()
  await app.init({ resizeTo: mount, ... })
  // ...
  drawScene(app, ...)  // drawScene 내부에서 drawCharacter() 호출
})()
```

체크리스트:
- [ ] `Assets.load({ alias, src })` — alias 명시 필수
- [ ] preload는 Application init 전에 호출 (캐시 보장)
- [ ] `drawCharacter`는 `Assets.cache.get(alias)`로 동기 조회
- [ ] fallback 도형 (캡슐+원) 항상 구현
- [ ] sprite anchor는 발 위치 `(0.5, 1)`
- [ ] PNG 크기는 표시 사이즈보다 크게 (다운스케일 후 흐림 방지, 원본 197×527 → 표시 60×120)

## 함정 15 — Twin Lab 류 2.5D 룩 차용 워크플로 (★★★ 패턴)

시각 참조 사이트 (Twin Lab, ai-office 등)와 우리 스택의 룩이 안 맞을 때, 오픈소스 차용 워크플로:

### 15-A — 4단계 부트스트랩 → 부트스트랩 실패 시점 인지

사용자가 "이 사이트처럼 만들고 싶다"고 하면 **첫 시도는 자체 구현**. 두 번 실패하면 OSS 차용으로 전환:

| 시도 | 실패 징후 | 다음 |
|---|---|---|
| 1차 — 우리 스택 + 자체 디자인 | 룩이 "처참하다", "마음에 안 든다" | 사용자 게이트 → 옵션 |
| 2차 — 우리 스택 + 자체 디자인 (조정) | 여전히 "디테일 부족", "Twin Lab 룩 안 남" | OSS 차용 옵션 제시 |
| 3차 — OSS 차용 | 보고서 + 후보 비교 → 사용자 결정 | 후보 중 1개 선택 → 이식 |

**함정**: 1~2차에서 너무 오래 매달리지 말 것. 사용자 피드백("디자인이 처참함") 신호는 명확한 전환점. 한 번 더 시도 vs OSS 차용은 사용자에게 위임.

### 15-B — OSS 후보 발굴 위임 시 위임 컨텍스트에 반드시 포함

```
목표: GitHub 공개 [isometric office / control room / dashboard 2.5D] 스타일 10~15개
각 후보당:
- repo URL + star + 라이선스 (MIT/Apache-2.0 우선)
- 기술 스택 (PixiJS/Phaser/Three.js/Canvas/SVG/Godot)
- 1~2개 핵심 visual feature
- 라이브 demo URL (있으면)
- 학습 추천도 (1~5)
- 한 줄 코멘트
- Twin Lab 룩 차용 가능성

우선순위:
1. 우리 스택 (PixiJS) > Phaser (PixiJS 기반)
2. Three.js isometric (인터랙션 패턴만)
3. Vanilla JS / SVG / Canvas
4. Godot / Bevy (참고용)

검색 키워드 16+개 배치:
"isometric office" / "control room" / "pixel office" / "2.5D office game" /
"isometric dashboard" / "phaser isometric" / "pixi.js isometric game" /
"city builder" / "office simulator" / "isometric building game" /
"mapbox isometric" / "tower tycoon" / "operation center visualization"

라이선스 우선순위:
- MIT/Apache-2.0 (fork OK)
- NOASSERTION (차용만, fork 위험)
- AGPL/GPL-3.0/IP 충돌/archived (즉시 제외)
```

**결과 보고 형식**:
1. **TOP 5** (각 2~3줄 + Twin Lab 차용 가능성)
2. 보너스 5~10개 (한 줄 표)
3. **라이브 데모 3개** URL
4. Twin Lab 컴포넌트별 차용 매트릭스
5. 결론 + 다음 단계

### 15-C — 라이브 데모 3개는 사용자에게 preview pane으로 즉시 보여주기

OSS 후보 발굴 후 **사용자가 직접 보고 결정**하게 해야 함. **반드시 preview pane에 3개 띄우고** 옵션 제시:

```bash
open_preview url="http://demo1.example.com/" label="demo 1 (isometric)"
open_preview url="https://demo2.example.com/" label="demo 2 (SVG)"
open_preview url="https://demo3.example.com/" label="demo 3 (city builder)"
```

`vision_analyze`는 URL을 직접 받지 못함 — preview가 정답.

### 15-D — 차용 위임은 "clone → 패턴 추출 → 우리 스택으로 이식" 순

```
1. 클론 (참조만, 우리 repo엔 안 들어감)
   cd /tmp && git clone --depth 1 <OSS_REPO>.git <oss>-clone
2. 캐릭터 PNG 등 자산 복사 (MIT 표기 필수)
   cp <oss>-clone/docs/images/*.png public/assets/characters/
   public/assets/characters/CREDITS.md 라이선스 표기
3. 핵심 src/ 파일 읽고 패턴 추출
   cat <oss>-clone/src/rooms.ts
   cat <oss>-clone/src/daylight.ts
4. 우리 PixiJS v8로 이식
   src/scene/drawRoom.ts (방 1개 그리기)
   src/scene/drawCharacter.ts (캐릭터 sprite)
   src/scene/drawScene.ts (8개 방 + 캐릭터 배치)
   src/App.tsx (메인)
5. 검증 + Playwright 스크린샷 (Twin Lab 룩 1:1 확인)
6. commit (push는 사용자 게이트 후)
```

**함정**: 클론은 `/tmp/`에 (가드 `/tmp/...py`는 py만 금지, 디렉토리 OK). 우리 repo엔 절대 OSS 코드 직접 안 들어감 — 패턴만 차용.

### 15-E — Twin Lab 류 시각 자산이 우리 스택 (PixiJS)에서 작동 안 할 때의 fallback

| OSS 스택 | 우리 스택 | 차용 전략 |
|---|---|---|
| PixiJS v8 / Phaser 3 | PixiJS v8 | **직접 이식** (90% 차용) |
| Three.js / R3F | PixiJS v8 | **인터랙션/UX 패턴만** (코드 이식 X) |
| Electron + React | React | **src/ 코드만** (Electron 의존 무시) |
| Canvas / SVG | PixiJS v8 | **좌표 변환 + 텍스처** 차용 (코드는 재작성) |
| Godot / Bevy | (어떤 스택) | **시각 디자인만** (코드/엔진 차용 X) |

체크리스트:
- [ ] 1~2차 자체 시도 실패 시 OSS 차용 옵션 사용자에게 제시
- [ ] 위임 컨텍스트에 우선순위 + 검색 키워드 + 라이선스 기준 명시
- [ ] 라이브 데모는 preview pane으로 즉시 보여주기
- [ ] 클론은 `/tmp/`에 (우리 repo 분리)
- [ ] 우리 repo엔 패턴만 이식, OSS 코드 직접 X
- [ ] 라이선스 표기 (CREDITS.md 또는 NOTICE)
- [ ] 차용 위임은 우리 스택에 맞는 시나리오로 명시



| Phase | PixiJS v8 함정 적용 |
|---|---|
| 1 스캐폴딩 | DPR 처리, 1280×720 캔버스 |
| 2 논리 해상도 | sx/sy 자동 확대 stage |
| 3 SpawnMarker | `Graphics` + BlurFilter |
| 4 HitFX | `Flashes` + 5종 셰이더 Filter (combine/replace/shadow/full_combine/displacement) |
| 4-shader | `aVertexPosition` → `aPosition` (PixiJS v8 표준 attribute 명) |
| 5 character-fx | Sprite rotation + Text overlay |
| 6 sound | Web Audio API (PixiJS 무관) |
| 7 slow-motion | `dt * slow_amount` 시스템 |
| 8 shop-card-fx | **함정 1 hit area** + **함정 6 BlurFilter** + **함정 9 호버 no-op** |
| 9 상점 화면 | wave 콜백, 골드/리롤/Go 버튼 |

## 참고 자료

- `references/snkrx-web-hit-area-case.md` — Phase 5-8 hit area 픽스 실측 코드 diff + 단위 테스트 변화
- `references/pixijs-v8-quick-reference.md` — 자주 쓰는 import / 명시적 hit area / chain-follower / isometric 룸 / 캐릭터 sprite / PNG 다운스케일 / Playwright 스니펫 모음

## 금지 사항

- `eventMode='static'`만으로 hit area를 잡으려 하지 말 것 (함정 1).
- `Texture.from(ImageData)` / `Texture.from(canvas)`로 신규 로딩 시도 금지 (함정 2).
- chain-follower를 history 스냅샷으로 구현 금지 (함정 3).
- Playwright/Chromium 자동 검증을 snkrx-web 같은 무거운 게임 loop에 강제 시도 금지 — 정적 씬(PixiJS + sprite PNG)에서는 OK (함정 7).
- DevTools `r.closest` 에러를 PixiJS 버그로 오인 금지 (함정 8).
- 호버 spring 진동 강제 시도 금지 — 사용자 no-op 정책 우선 (함정 9).
- Twin Lab 룩 isometric 룸을 박스 4면만 그리고 끝내지 말 것 — 박스 7겹 + decoration 모두 구현 (함정 13).
- 캐릭터 sprite를 `Texture.from(path)`로 로딩 시도 금지 — `Assets.load({ alias, src })` + fallback 도형 정형 사용 (함정 14).
