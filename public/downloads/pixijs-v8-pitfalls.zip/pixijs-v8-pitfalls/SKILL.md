---
name: pixijs-v8-pitfalls
description: PixiJS v8 (8.x) 게임/웹 포팅 시 만나는 class-level 함정 모음. hit area 누락, `Texture.from()` 캐싱, BlurFilter/chain-follower/LÖVE→웹 변환 패턴까지. snkrx-web Phase 1~9 실측 기반. "호버 안 됨", "클릭 안 됨", "텍스처 안 보임", "GL 텍스처 캐시", "BlurFilter", "ImageData throw", "마우스 이벤트가 Graphics 통과" 같은 PixiJS v8 시각/입력 버그에 발동.
version: 1.0.0
author: HyeRin
license: MIT
metadata:
  hermes:
    tags: [pixijs, pixi-v8, game-dev, web-port, hit-area, texture, input]
    related_skills: [kanban-project-delivery, godot-control-input-quirks]
---

# PixiJS v8 Pitfalls — 게임/웹 포팅 class-level 함정

snkrx-web (PixiJS 8.19.0) Phase 1~9 / 30 카드 실측에서 만난 함정. 모든 LÖVE→웹 포팅, PixiJS v8 신규 프로젝트에 동일 적용.

## 사용 시기

- PixiJS 8.x 로 게임/앱을 포팅하거나 새로 작성할 때
- "호버 안 됨", "클릭 안 됨", "마우스 이벤트가 Graphics 통과" 증상
- "텍스처 안 보임", "GL 텍스처 캐시 누락"
- "Container vs Graphics hit area 불일치" 디버깅

## 함정 1 — `eventMode='static'` 만으로는 hit area 가 안 잡힘 (★★★ 가장 빈번)

PixiJS v8에서 `Container`에 `eventMode='static'`을 줘도 자식 `Graphics`가 매 프레임 `clear()`를 호출하면 **hit area가 사라져서** pointer 이벤트가 통과해버림.

**증상**: 호버/클릭 안 됨. 콘솔에 에러 없음. Graphics 모양은 보이지만 인터랙션만 안 됨.

**원인**: PixiJS v8 hit area는 두 layer —

1. `Container` 자체의 `hitArea` (없으면 자식 Graphics 의 hit area 합집합)
2. 자식 `Graphics` 의 hit area (마지막으로 그린 `rect()`/`circle()` 등의 도형)

`box.clear()` 후 `.rect().fill()` 다시 그려도 새 도형이 hit area로 잡혀야 하지만, **Container의 hitArea가 명시되지 않으면 자식 Graphics의 hit area가 container의 transform과 함께 합쳐질 때 경계가 부정확**해진다.

**해결 — 두 곳 모두 명시**:

```ts
import { Container, Graphics, Rectangle } from 'pixi.js'

const container = new Container()
container.x = 100
container.y = 200
container.eventMode = 'static'
container.cursor = 'pointer'
// ★ fix: 정적 hit area 명시. 자식 Graphics가 매 프레임 clear 되어도
// container 자체의 hit area는 유지됨.
container.hitArea = new Rectangle(0, 0, cardW, cardH)

const box = new Graphics()
// 안전망: box 자체에도 hit area
box.eventMode = 'static'
box.cursor = 'pointer'
box.hitArea = new Rectangle(0, 0, cardW, cardH)
container.addChild(box)
```

체크리스트:
- [ ] `Container.hitArea = new Rectangle(0, 0, w, h)` 명시
- [ ] 자식 `Graphics`도 `eventMode='static'` + `hitArea` (안전망)
- [ ] `clear()` 후 다시 그려도 hit area 보존됨

## 함정 2 — `Texture.from()` 은 캐시만, 신규 로딩은 `Assets.load()`

```ts
// ❌ PixiJS v8에서 canvas/ImageData를 직접 전달하면 throw
const tex = Texture.from(canvas)        // cache hit만, 신규면 undefined
const tex = Texture.from(imageData)     // throws

// ✅ 자산 로딩
import { Assets } from 'pixi.js'
const tex = await Assets.load<Texture>('images/hero.png')

// ✅ HTMLImageElement/HTMLCanvasElement → Texture (캐시 키 충돌 방지)
const tex = Texture.from(canvas)  // canvas는 캐시 키가 자동 생성됨
```

**캐시 충돌 함정**: 같은 URL 을 두 번 `Assets.load` 해도 같은 Texture 반환. 의도적으로 새 인스턴스가 필요하면 `Assets.load({ src, data: { ... } })` 또는 `new Texture({ source })`.

## 함정 3 — chain-follower = 누적 거리 (history 스냅샷 X)

snake / chain / 꼬리 따라가는 게임에서 뱀 본체를 history 좌표 스냅샷으로 그리면 **회전 시 직선으로 늘어지는** 버그 발생.

**원인**: 각 마디를 `history[i] = head.position` 으로 저장하면, head가 빠르게 방향 전환할 때 모든 마디가 같은 직선 위에 놓임.

**해결 — 누적 거리 알고리즘**:

```ts
// 각 마디가 직전 마디로부터 spacing 거리 유지. 매 frame distance 보정.
const spacing = TILE * 1.75  // 16 → 28, 화면/속도에 따라 조정
for (const segment of segments) {
  let prev = head
  for (let i = 1; i < segments.length; i++) {
    const seg = segments[i]
    const dx = seg.x - prev.x
    const dy = seg.y - prev.y
    const dist = Math.hypot(dx, dy)
    if (dist > 0) {
      // spacing 거리만큼 뒤로
      seg.x = prev.x - (dx / dist) * spacing
      seg.y = prev.y - (dy / dist) * spacing
    }
    prev = seg
  }
}
```

회전/곡선 추적에 안정적. spacing = TILE * 1.75 가 snkrx-web 기준 최적.

## 함정 4 — 화면 경계 충돌 = heading 축 단위 반사 + head 클램프

snake 게임에서 head가 화면 밖으로 나갈 때 단순히 `x = clamp(x, 0, W)` 하면 head가 벽에 박혀 멈춤. **heading 축 단위 반사** + head만 클램프:

```ts
// heading = head의 마지막 속도 벡터
if (head.x < 0 || head.x > W) {
  heading.x *= -1
  head.x = clamp(head.x, 0, W)
}
if (head.y < 0 || head.y > H) {
  heading.y *= -1
  head.y = clamp(head.y, 0, H)
}
```

전체 뱀이 따라가며 자연스럽게 튕김.

## 함정 5 — 충돌 거리 = `Math.hypot(dx,dy) <= head.r + enemy.r`

원형 hit box 충돌 시 `dx*dx + dy*dy <= (r1+r2)^2` 비교가 표준. 단 snkrx-web 실측에서 **head 8→12** 가독성 + 충돌 정확도 균형점.

## 함정 6 — BlurFilter 는 가벼운 글로우 효과에 충분

`pixi-filters` 패키지의 `OutlineFilter`/`GlowFilter`는 추가 의존성. 카드 hover/select 글로우 같은 단순 효과는 `pixi.js` 코어의 `BlurFilter({ strength: 4, quality: 4 })` 한 줄로 충분:

```ts
import { BlurFilter } from 'pixi.js'
const glow = new BlurFilter({ strength: 4, quality: 4 })
glow.enabled = false  // 기본 OFF
container.filters = [glow]
// hover/select 시: glow.enabled = true
```

## 함정 7 — Playwright/Chrome 자동 검증 = macOS에서 30분+ 갇힘

PixiJS 게임의 시각 검증을 자동화하려고 Playwright/Chromium 띄우면 macOS 환경에서 Chromium 비정상 종료 → 워커 hang. **사용자 브라우저 수동 검증**으로 대체.

`?test=1` 쿼리 파라미터로 테스트 모드 진입 (HP↑, projectile OFF, 명멸 깜빡임). 사용자가 직접 `http://127.0.0.1:5173/?test=1` 확인.

## 함정 8 — DevTools 콘솔 `r.closest is not a function at content.js:4` = Chromium 확장 노이즈 (무시)

PixiJS 게임 dev 중 DevTools 콘솔에 빨간 `Uncaught TypeError: r.closest is not a function at content.js:4` 가 떠도 **게임과 무관**. Chrome 확장 (번역/광고 차단)이 PixiJS 내부 접근하다 실패한 것. **무시하고 시각 검증 진행**.

## 함정 9 — 호버 spring 진동이 시각적으로 거슬림 → no-op 정책

사용자 피드백: `hoverEnter` 시 spring을 0.1~0.7 까지 끌어내렸다가 1.0으로 복귀하는 spring 진동이 카드 크기 변동으로 보여서 **호버 자체를 빼는 게 깔끔**. 클릭(펄스 amp=0.02 = 98~102%)만 살림.

```ts
hoverEnter(id: string): void {
  // no-op — 사용자가 spring 진동 안 이쁘다고 명시
  void id
}
```

snkrx-web 에서 `b29a55a` "Phase 5-8 호버 효과 비활성화" 커밋이 그 정책 결정 시점. 이후 호버 없이도 클릭 펄스로 충분.

## snkrx-web Phase 1~9 적용 요약

| Phase | PixiJS v8 함정 적용 |
|---|---|
| 1 스캐폴딩 | DPR 처리, 1280×720 캔버스 |
| 2 논리 해상도 | sx/sy 자동 확대 stage |
| 3 SpawnMarker | `Graphics` + BlurFilter |
| 4 HitFX | `Flashes` + 5종 셰이더 Filter (combine/replace/shadow/full_combine/displacement) |
| 4-shader | `aVertexPosition` → `aPosition` (PixiJS v8 표준 attribute 명) |
| 5 character-fx | Sprite rotation + Text overlay |
| 6 sound | Web Audio API (PixiJS 무관) |
| 7 slow-motion | `dt * slow_amount` 시스템 |
| 8 shop-card-fx | **함정 1 hit area** + **함정 6 BlurFilter** + **함정 9 호버 no-op** |
| 9 상점 화면 | wave 콜백, 골드/리롤/Go 버튼 |

## 참고 자료

- `references/snkrx-web-hit-area-case.md` — Phase 5-8 hit area 픽스 실측 코드 diff + 단위 테스트 변화
- `references/pixijs-v8-quick-reference.md` — 자주 쓰는 import / 명시적 hit area / chain-follower 스니펫 모음

## 금지 사항

- `eventMode='static'`만으로 hit area를 잡으려 하지 말 것 (함정 1).
- `Texture.from(ImageData)` / `Texture.from(canvas)`로 신규 로딩 시도 금지 (함정 2).
- chain-follower를 history 스냅샷으로 구현 금지 (함정 3).
- Playwright/Chromium 자동 검증으로 PixiJS 게임 시각 검증 금지 (함정 7).
- DevTools `r.closest` 에러를 PixiJS 버그로 오인 금지 (함정 8).
- 호버 spring 진동 강제 시도 금지 — 사용자 no-op 정책 우선 (함정 9).
