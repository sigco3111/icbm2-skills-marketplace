---
name: memory-hygiene
description: Hermes 메모리 시스템의 디스크/컨텍스트 정리 워크플로우 — MEMORY.md가 4,000자 한도 근처이거나, 일일 리포트/셀프힐 로그가 누적되어 컨텍스트 부담이 될 때 사용. 대량 아카이빙 + 재구성 + 검증까지 한번에.
version: 1.0.1
author: ICBM2
metadata:
  hermes:
    tags: [memory, hygiene, archive, maintenance, self-improvement]
---

# 메모리 위생 워크플로우 (Memory Hygiene)

## 트리거 조건

다음 중 **하나라도** 해당하면 이 워크플로우를 실행한다:

- 시스템 메모리(`memory` 도구)가 90% 이상 차서 신규 항목 추가가 차단될 때
- `~/.hermes/memory/` 루트 또는 `reports/` 에 마크다운 파일이 누적되어 컨텍스트 압박이 심할 때 (보통 50개+)
- MEMORY.md가 만료된 메타 섹션/중복 정보를 포함해 비대해진 경우
- 주인님이 "메모리 정리하자" / "디스크 정리해줘" 등을 명시적으로 요청한 경우
- 주 1회 정기 정비 (heartbeat/cron에서 자동 실행 가능)

**경량 daily 가드 (2026-06-10 추가)**: 일일 리뷰에서 **90~110% 임계치 시 5섹션 동시 압축**만 필요하면 이 워크플로우 전체(2주 룰 archive + 재작성)까지는 과함. `daily-self-review` v1.0.12의 **step 4-1 (시작 시 1줄 점검) + step 4-2 (5섹션 동시 patch)** 만으로 충분. → 한도 110%+ 또는 신규 패턴 도입 시에만 이 워크플로우 진입.

## 절대 하지 말 것

- **수동 편집으로 MEMORY.md를 부분 수정하지 말 것** — 한도가 빡빡할 때 단어 단위 패치는 시간 낭비. 전체 재작성이 빠름
- **아카이빙 전에 사용자 승인 없이 삭제하지 말 것** — `mv`로 archive/ 폴더에 이동은 OK, 영구 삭제는 ❌
- **issues.md 같은 활성 추적 파일은 건드리지 말 것** — 메모리 정리의 대상은 정적 리포트, 동적 추적기가 아님
- **state.json 파일을 건드리지 말 것** — 봇 상태/세션 캐시 등 자동화 시스템이 의존함

## 4단계 절차

### 1단계: 현황 진단 (3분)

**⚠️ 가장 먼저: 어느 MEMORY.md가 진짜 시스템 프롬프트 주입 소스인지 확인한다.**

Hermes 워크스페이스에는 MEMORY.md가 **두 개 이상** 존재할 수 있다:

| 경로 | 정체 | 시스템 프롬프트 주입? |
|------|------|----------------------|
| `~/.hermes/MEMORY.md` | **진짜 주입 소스** (AGENTS.md가 가리킴) | ✅ |
| `~/.hermes/memory/MEMORY.md` | 자동 시스템 보조 파일 | ❌ |
| `~/.hermes/memories/MEMORY.md` | 별도 보조/백업 파일 | ❌ |

확인 방법:
```bash
# 1) AGENTS.md / SOUL.md가 어느 경로를 가리키는지
grep -i "memory" ~/.hermes/AGENTS.md ~/.hermes/SOUL.md 2>/dev/null

# 2) 시스템 프롬프트의 "MEMORY (xx%)" 메모와
#    각 파일의 line count를 대조 → 일치하는 게 진짜
wc -l ~/.hermes/MEMORY.md ~/.hermes/memory/MEMORY.md ~/.hermes/memories/MEMORY.md 2>/dev/null

# 3) 둘 중 하나만 % 메모리에 부합 → 그쪽이 진짜 소스
```

**두 파일이 있으면 진짜 소스를 먼저 정리하고, 보조 파일은 별도 판단(삭제/병합/유지).**
**잘못된 파일을 정리하면 정작 사용 중인 메모리는 그대로 남아 한도가 안 줄어든다.**

```bash
# 메모리 도구 사용량
memory(action='read')  # 시스템 메모리 — percentage 확인

# 디스크 분포 (보조 파일들)
ls ~/.hermes/memory/*.md | wc -l
ls ~/.hermes/memory/reports/*.md | wc -l
ls ~/.hermes/memory/self_heal_*.md 2>/dev/null | wc -l

# MEMORY.md 크기 — 진짜 소스 우선
wc -c ~/.hermes/MEMORY.md
wc -c ~/.hermes/memory/MEMORY.md ~/.hermes/memories/MEMORY.md 2>/dev/null

# archive 폴더 확인 (이미 있다면 활용)
ls ~/.hermes/memory/archive/ 2>/dev/null
```

**판단 기준**:
- 루트 md 30개+, reports 30개+, self_heal 30개+ → 전체 재구성 권장
- MEMORY.md가 4,000자 초과 또는 90% 이상 → 재작성 필수

### 2단계: 아카이빙 (5분)

**2-주 룰**: 14일(2주) 이전의 일일 리포트/로그는 `archive/` 하위 폴더로 이동.

```bash
# 폴더 구조 생성
mkdir -p ~/.hermes/memory/reports/archive/2026-MM-DD
mkdir -p ~/.hermes/memory/archive/2026-MM

# reports/: 2주 이전 일일 리포트 + 모든 weekly 리포트 이동
for f in ~/.hermes/memory/reports/daily_2026-MM-{01..14}.md; do
  [ -f "$f" ] && mv "$f" ~/.hermes/memory/reports/archive/2026-MM-DD/
done
# reports/weekly_*.md도 archive로 (월간 단위)

# 루트 md: 2주 이전 일일 메모리 (예: 2026-02-*.md, 2026-03-*.md) 이동
for f in ~/.hermes/memory/2026-MM-{01..15}-*.md; do
  [ -f "$f" ] && mv "$f" ~/.hermes/memory/archive/2026-MM/
done

# self_heal_YYYY-MM-DD.md도 동일하게 2주 룰 적용
```

**Pitfall**:
- `2026-MM-DD-special-topic.md` 같은 특정 주제 파일은 이동하지 말 것 (예: `critical_notes_*.md`, `botmadang.md`)
- `state.json`, `*.backup`, `*.jsonl` 같은 데이터 파일은 절대 이동 ❌
- `issues.md`, `MEMORY.md`, `2026-06-02.md` (오늘 일기)는 루트에 유지

### 3단계: MEMORY.md 재작성 (10분)

**⚠️ 부분 패치 시 인접 줄까지 매칭될 수 있다.** `patch` 도구의 fuzzy matching이 의도한 줄 너머까지 일치시키면, `old_string`만 들어갔다고 생각한 항목 옆에 있던 줄(예: `- **출력:** ...`)이 통째로 사라질 수 있다. **반드시 패치 직후 `grep` 또는 `read_file`로 인접 5줄을 재확인한다.**

전체 재작성이 부분 패치보다 빠르고 일관성 있다.

**재구성 원칙**:
1. **섹션 순서**: 환경 → DB → 프로필 → 규칙 → API → 워크플로우 순으로 정보 밀도 균일화
2. **중복 제거**: 이슈 13개 행을 모두 나열하지 말고 요약 + `issues.md` 참조
3. **만료 메타 삭제**: "복원 완료", "초기 설정", "오늘 발견" 같은 일회성 섹션 제거
4. **모델 정보 갱신**: 모델 변경 시 즉시 반영 (예: `minimax-m2.7` → `MiniMax-M3`)
5. **표 활용**: `| 항목 | 값 |` 형식으로 가독성 ↑

**권장 섹션 템플릿**:
```
# ICBM2 Memory — 최종 업데이트: YYYY-MM-DD
## 환경
## Notion DB IDs
## 주인님 프로필
## 영상/블로그 제작 규칙
## 뮤직비디오 규칙
## 핵심 API 키/설정
## Tistory API
## Gmail 계정 구분
## NotebookLM
## 이미지 분석
## 블로그 발행 워크플로우
## NotebookLM 영상 워크플로우
## NotebookLM 장애 대응
## Cloudflare Tunnel
## 컨텍스트 최적화
## 알려진 이슈 (전체 목록: issues.md)
## 미해결 작업
```

### 4단계: 검증 (2분)

```bash
# 시스템 메모리 사용량 재확인 (목표: 50% 이하)
# (실제 확인은 다음 세션에서 메모리 도구 read 시)

# 디스크 분포
du -sh ~/.hermes/memory/reports/
du -sh ~/.hermes/memory/archive/

# 새 MEMORY.md 크기
wc -c ~/.hermes/memory/MEMORY.md
```

**3단계 잔여 흔적 확인 (cleanup 후 필수)** — 2026-06-02 세션 교훈:

섹션/스크립트 제거 후 **반드시 3곳을 grep**으로 확인:

```bash
# 1) 진짜 소스 본문에서 잔여 흔적
grep -n "뮤직비디오\|music_video\|datagokr\|apikey" ~/.hermes/MEMORY.md

# 2) 진짜 소스의 "자동화 성과 / 알려진 이슈" 섹션 (별도 위치)
#    예: "🟡 🎬 뮤직비디오 제작 cron: TimeoutError" 같은 이슈 항목이
#    본문은 정리됐는데 이슈 목록에 남아있는 경우

# 3) 보조 파일 (있다면)
grep -n "뮤직비디오\|music_video" ~/.hermes/memories/MEMORY.md 2>/dev/null
```

**왜 3단계?**
- 본문 정리만 하면 "알려진 이슈" 섹션에 dead reference가 남음
- 보조 파일 잔여는 본문과 별개라 별도 grep 필요
- 한 곳에서 발견되면 다른 곳도 같은 키워드로 재검색

**Pitfall (이 단계에서 자주 발생하는 실수)**:
- "본문 정리 끝났으니 끝" → 이슈 섹션의 1줄이 dead reference로 남음
- 보조 파일을 안 봄 → memos 보조 파일이 outdated 상태로 영구 잔존
- 1차 grep으로 안 나오면 "OK" → 키워드 변형(영문/한글/축약) 모두 시도

**성공 기준**:
- ✅ 시스템 메모리 < 60%
- ✅ 루트 md 30개 이하, reports 20개 이하
- ✅ MEMORY.md < 7,000자 (권장)
- ✅ archive 폴더에 안전 보관됨
- ✅ 3단계 grep 모두 0 hits

**의존성 vs 키워드 매칭 — 2026-06-02 교훈 (중요)**:

MEMORY.md 항목을 제거/압축할 때 **키워드 매칭으로 판단하지 말 것**. 예시 사고:

> "숏츠 변환 절대 금지: `pad=...:black` 검은 패드 코드가 계속 복구됨" 항목을
> 키워드 '뮤직비디오'가 들어간 섹션과 함께 묶어 제거 → YouTube Shorts 워크플로우의
> 핵심 규칙(블러 letterbox, `make_shorts()` 함수)이 사라짐.

**판단 기준 — 의존성 우선**:
1. **이 항목이 어떤 시스템에서 호출/참조되는가?** (예: `make_shorts()` 함수가 `video-editing` 스킬에서 정의됨)
2. **어떤 워크플로우의 일부인가?** (예: YouTube Shorts 업로드의 letterbox 처리)
3. **다른 항목과 어떻게 연결되는가?** (예: SKILL.md의 196~209행에 동일 내용 보존됨)

**검증 절차**:
```bash
# 1) grep으로 다른 곳 참조 확인
grep -rln "make_shorts\|블러 letterbox\|boxblur" ~/.hermes/skills/ ~/.hermes/scripts/

# 2) 연관 스킬/스크립트가 살아있으면 → 그쪽이 진짜 소스
#    MEMORY.md 압축은 가능하되, **상세는 스킬이 담당**하도록 위임 표현 추가
#    예: "상세: skills/video-editing/SKILL.md 196~209행 + shorts-ffmpeg-crop-fix.md"
```

**압축 가이드 (스킬이 살아있을 때)**:
- ❌ 키워드 매칭으로 통째 제거
- ✅ 7줄 → 1줄 압축 + 스킬 파일 경로 명시로 위임
- 예: "⚠️ YouTube Shorts: `pad=...:black` 검은 패드 절대 금지 (Chronic Bug) — 상세: `skills/video-editing/SKILL.md` 196~209행"

**3단계 잔여 흔적 확인 (cleanup 후 필수)** — 2026-06-02 세션 교훈:

섹션/스크립트 제거 후 **반드시 3곳을 grep**으로 확인:

```bash
# 1) 진짜 소스 본문에서 잔여 흔적
grep -n "뮤직비디오\|music_video\|datagokr\|apikey" ~/.hermes/MEMORY.md

# 2) 진짜 소스의 "자동화 성과 / 알려진 이슈" 섹션 (별도 위치)
#    예: "🟡 🎬 뮤직비디오 제작 cron: TimeoutError" 같은 이슈 항목이
#    본문은 정리됐는데 이슈 목록에 남아있는 경우

# 3) 보조 파일 (있다면)
grep -n "뮤직비디오\|music_video" ~/.hermes/memories/MEMORY.md 2>/dev/null
```

**왜 3단계?**
- 본문 정리만 하면 "알려진 이슈" 섹션에 dead reference가 남음
- 보조 파일 잔여는 본문과 별개라 별도 grep 필요
- 한 곳에서 발견되면 다른 곳도 같은 키워드로 재검색

**Pitfall (이 단계에서 자주 발생하는 실수)**:
- "본문 정리 끝났으니 끝" → 이슈 섹션의 1줄이 dead reference로 남음
- 보조 파일을 안 봄 → memos 보조 파일이 outdated 상태로 영구 잔존
- 1차 grep으로 안 나오면 "OK" → 키워드 변형(영문/한글/축약) 모두 시도

**성공 기준**:
- ✅ 시스템 메모리 < 60%
- ✅ 루트 md 30개 이하, reports 20개 이하
- ✅ MEMORY.md < 7,000자 (권장)
- ✅ archive 폴더에 안전 보관됨
- ✅ 3단계 grep 모두 0 hits

## 정기 실행 권장 주기

- **매주 일요일 (heartbeat)**: 2주 룰 자동 적용 — 오래된 일일 리포트만 archive로
- **메모리 90% 도달 시**: 즉시 전체 재구성
- **월 1회 (cron 권장)**: 1개월 이전 항목 archive로 강제 이동

## Pitfall 정리

- **메모리 한도 초과 시 일부 추가만 시도하지 말 것** — 한 번에 정리하는 게 시간 효율적
- **`memory` 도구 add 실패 시 `replace`로 우회하지 말 것** — 의미 있는 신규 항목은 archive 후 재시도
- **archive로 이동한 파일을 grep으로 찾을 수 있음을 기억** — `archive/` 안에서도 `search_files`로 검색 가능
- **state.json 파일 절대 건드리지 말 것** — 봇 자동화 시스템이 의존 (notebooklm_selection.json, published_topics.json 등)
- **두 개 이상 MEMORY.md가 있으면 잘못된 파일 정리할 위험** — 1단계의 경로 확인 절차 반드시 따를 것
- **부분 패치의 인접 줄 매칭 위험** — `old_string`을 너무 짧게 잡으면 fuzzy match가 인접 줄까지 잡아먹음. 패치 후 5줄 안쪽 컨텍스트로 grep 검증 필수

## 관련

- `daily-self-review` — 매일 자기 개선 시 incremental 메모리 정리 수행 (작은 단위)
- `nightly-maintenance-workflow` — 심야 자동 정비 (에러 모니터링 중심, 메모리는 일부)
- `memory-error-tracker` — issues.md와 MEMORY.md의 에러 추적 동기화
- `automation-decommission` — 컴포넌트 제거 워크플로우 (메모리도 함께 정리 필요 시)

## 실행 기록 (references/)

- `references/2026-06-02-cleanup-run.md` — 2026-06-02 전체 재구성 실행 결과 (96개 archive, MEMORY.md 4,098→5,647자 재구성)
- `references/2026-06-02-wrong-file-misroute.md` — MEMORY.md 두 개 파일 혼동 사고 보고 + 복구 절차 (잘못된 파일 3건, 진짜 소스 무손상)
- `references/2026-06-02-phase2-decommission.md` — 2차 컴포넌트 폐기 실행 (뮤직비디오 + 공개데이터포탈, MEMORY.md 8,964→4,259B, 시크릿 trash vs 코드 rm 분리 원칙)
