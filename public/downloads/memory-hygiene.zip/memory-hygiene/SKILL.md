---
name: memory-hygiene
description: Hermes 메모리 시스템의 디스크/컨텍스트 정리 워크플로우 — MEMORY.md가 4,000자 한도 근처이거나, 일일 리포트/셀프힐 로그가 누적되어 컨텍스트 부담이 될 때 사용. 대량 아카이빙 + 재구성 + 검증까지 한번에.
version: 1.0.3
author: ICBM2
metadata:
  hermes:
    tags: [memory, hygiene, archive, maintenance, self-improvement]
---

# 메모리 위생 워크플로우 (Memory Hygiene)

## 트리거 조건

다음 중 **하나라도** 해당하면 이 워크플로우를 실행한다:

- 시스템 메모리(`memory` 도구)가 90% 이상 차서 신규 항목 추가가 차단될 때
- `~/.hermes/memory/` 루트 또는 `reports/` 에 마크다운 파일이 누적되어 컨텍스트 압박이 심할 때 (보통 50개+)
- MEMORY.md가 만료된 메타 섹션/중복 정보를 포함해 비대해진 경우
- 주인님이 "메모리 정리하자" / "디스크 정리해줘" 등을 명시적으로 요청한 경우
- **주인님이 능동적으로 "메모리 더 정리할 거 없나?" / "메모리 부족한 것 같은데" 묻는 경우** (2026-06-29 추가) — 보통 이미 한도 80%+ 상태. **항목별 등급 매기기 → 사용자 한 번 확인 → 일괄 실행** 워크플로우로 진입. 상세: `references/2026-06-29-grade-then-clean.md`
- **주인님이 "점진적 공개 가능?" / "progressive disclosure" 등 메모리 구조 자체를 의문**할 때 (2026-07-13 추가) → **"3계층 점진적 공개" 절차로 진입** (아래 §A 참조)
- 주 1회 정기 정비 (heartbeat/cron에서 자동 실행 가능)

**경량 daily 가드 (2026-06-10 추가)**: 일일 리뷰에서 **90~110% 임계치 시 5섹션 동시 압축**만 필요하면 이 워크플로우 전체(2주 룰 archive + 재작성)까지는 과함. `daily-self-review` v1.0.12의 **step 4-1 (시작 시 1줄 점검) + step 4-2 (5섹션 동시 patch)** 만으로 충분. → 한도 110%+ 또는 신규 패턴 도입 시에만 이 워크플로우 진입.

## 절대 하지 말 것

- **수동 편집으로 MEMORY.md를 부분 수정하지 말 것** — 한도가 빡빡할 때 단어 단위 패치는 시간 낭비. 전체 재작성이 빠름
- **아카이빙 전에 사용자 승인 없이 삭제하지 말 것** — `mv`로 archive/ 폴더에 이동은 OK, 영구 삭제는 ❌
- **issues.md 같은 활성 추적 파일은 건드리지 말 것** — 메모리 정리의 대상은 정적 리포트, 동적 추적기가 아님
- **state.json 파일을 건드리지 말 것** — 봇 상태/세션 캐시 등 자동화 시스템이 의존함
- **🚫 세션 내 "보류" 결정을 메모리에 남기지 말 것** (2026-06-29 사용자 코렉션) — "일단 파악만 해두지 보류"라고 받은 결정은 **세션 안에서만** 다룸. 메모리 4,000자 한도는 희소 자원이라 "다음 세션에 떠올릴 일" 중 **반복될 선호/환경 사실**만 남긴다. 보류 결정은 메모리에 안 어울림. 사용자 피드백이 직접 온 사안이라 첫 클래스 신호로 처리.

## ⚠️ Phantom-listing fallback (2026-07-06 실측)

`skills_list`가 `memory-hygiene` 스킬을 정상 표시하고 SKILL.md 본문에 `scripts/hygiene_check.sh` 같은 헬퍼 경로가 명시돼 있지만 **실제 디스크에는 `~/.hermes/skills/memory-hygiene/` 폴더 자체가 부재**일 수 있다 (cross-profile import, sync 실패, 사용자 디렉터리 재배치 등으로 발생). 위임 지시에서 "~/.hermes/skills/memory-hygiene/scripts/hygiene_check.sh 실행" 같은 호출을 받으면:

**즉시 진단 (5초, 1줄)**:
```bash
ls ~/.hermes/skills/memory-hygiene/ 2>&1 || echo "PHANTOM_LISTING"
```

- 출력 = 디렉터리 내용 → 정상 (헬퍼 스크립트 추가 설치 가능)
- 출력 = "No such file or directory" → **phantom listing** (스킬은 보이지만 디렉터리 부재)

**Fallback 1줄 oneliner (직접 측정)**:
```bash
wc -m ~/.hermes/memory/MEMORY.md | awk '{u=$1; if (u<4000) print "OK under_limit usage="u" cap=4000"; else if (u<6000) print "COMPRESS usage="u" cap=4000 diff="(u-4000); else print "RESTRUCTURE usage="u" cap=4000 diff="(u-4000)}'
```

| 측정값 | 동작 |
|---|---|
| `< 4,000자` | "memory-hygiene 불필요 — 한도 내 (usage=X)" 보고 |
| `4,000~6,000자` | older 항목 1-2개 압축 권장 |
| `> 6,000자` | memory-hygiene umbrella 정식 진입 (재구성) |

**Phantom listing 발견 시 우선순위**:
1. 위 1줄 oneliner로 직접 측정 → 보고
2. umbrella SKILL.md 본문만으로 충분히 동작 (`memory` 도구 read + archive + 재작성 4단계 절차)
3. 디렉터리 / 스크립트 부재는 자체 해결 X — **curator 의제로 노트**하고 부모 세션에 통보:
   ```
   ⚠️ 메모리 hygiene 패스 진행 (직접 oneliner 사용). 
   SKILL.md의 `scripts/hygiene_check.sh` 부재 → curator가 디렉터리/스크립트 보강 검토 권장.
   ```
4. umbrella 본인 SKILL.md의 다른 섹션 (절대 하지 말 것 / 4단계 절차 / Pitfall 정리)은 phantom 상황에서도 충분히 동작하므로 정상 진행.

**예방 (umbrella 측)**: 스킬 디렉터리에는 항상 최소한 `SKILL.md` + 빈 `references/` + 빈 `scripts/` 가 있어야 phantom listing이 안 생긴다. 새 umbrella 생성 시 즉시 `mkdir -p references scripts && touch scripts/.gitkeep references/.gitkeep` 패턴.

**재사용**: 다른 umbrella (`daily-self-review`, `nightly-maintenance-workflow`, `memory-error-tracker` 등)에도 동일 패턴이 적용될 수 있음. 위임에서 "X 스킬 scripts/foo.sh 실행"이 오면 `ls ~/.hermes/skills/X/`로 sanity check 우선.

## 4단계 절차

### 1단계: 현황 진단 (3분)

**⚠️ 가장 먼저: 어느 MEMORY.md가 진짜 시스템 프롬프트 주입 소스인지 확인한다.**

Hermes 워크스페이스에는 MEMORY.md가 **두 개 이상** 존재할 수 있다:

| 경로 | 정체 | 시스템 프롬프트 주입? |
|------|------|----------------------|
| `~/.hermes/memories/MEMORY.md` | **진짜 주입 소스** (2026-07-13 실측, 복수형!) | ✅ |
| `~/.hermes/MEMORY.md` | 자동 시스템 보조 파일 | ❌ |
| `~/.hermes/memory/MEMORY.md` | 별도 보조 파일 | ❌ |

> ⚠️ **2026-07-13 실측 교정**: 위 표의 `~/.hermes/memories/MEMORY.md` (복수형)가 진짜 소스였음. 이번 세션에서 시스템 프롬프트 `MEMORY (98% — 3,930/4,000)`와 이 파일 (3,930자) 가 정확히 일치. **이전 버전의 표는 단수형 `~/.hermes/MEMORY.md`이 진짜라고 잘못 표기**돼 있었음. 환경에 따라 다를 수 있으니 **반드시 다음 절차로 확인**한다.

확인 방법 (2026-07-13 개정):
```bash
# 1) AGENTS.md / SOUL.md가 어느 경로를 가리키는지 (보통 결정적이지 않음 — 0건일 가능성 큼)
grep -i "memory" ~/.hermes/AGENTS.md ~/.hermes/SOUL.md 2>/dev/null

# 2) **가장 신뢰할 수 있는 방법**: 시스템 프롬프트에 표시된 "MEMORY (xx% — X/4000)"
#    의 X 값(글자수)과 일치하는 파일을 찾는다
wc -m ~/.hermes/MEMORY.md ~/.hermes/memory/MEMORY.md ~/.hermes/memories/MEMORY.md 2>/dev/null

# 3) 시스템 % × 40 = 글자수와 일치하는 경로 = 진짜 소스
#    예: "98%" → 약 3,920자. 3,930자 파일 = 진짜 소스

# 4) config.yaml의 memory_char_limit 확인 (보통 4000)
grep -A2 'memory_char_limit' ~/.hermes/config.yaml
```

**두 파일이 있으면 진짜 소스를 먼저 정리하고, 보조 파일은 별도 판단(삭제/병합/유지).**
**잘못된 파일을 정리하면 정작 사용 중인 메모리는 그대로 남아 한도가 안 줄어든다.**

```bash
# 메모리 도구 사용량
memory(action='read')  # 시스템 메모리 — percentage 확인

# 디스크 분포 (보조 파일들)
ls ~/.hermes/memory/*.md | wc -l
ls ~/.hermes/memory/reports/*.md | wc -l
ls ~/.hermes/memory/self_heal_*.md 2>/dev/null | wc -l

# MEMORY.md 크기 — 진짜 소스 우선
wc -c ~/.hermes/MEMORY.md
wc -c ~/.hermes/memory/MEMORY.md ~/.hermes/memories/MEMORY.md 2>/dev/null

# archive 폴더 확인 (이미 있다면 활용)
ls ~/.hermes/memory/archive/ 2>/dev/null
```

**판단 기준**:
- 루트 md 30개+, reports 30개+, self_heal 30개+ → 전체 재구성 권장
- MEMORY.md가 4,000자 초과 또는 90% 이상 → 재작성 필수

### 2단계: 아카이빙 (5분)

**2-주 룰**: 14일(2주) 이전의 일일 리포트/로그는 `archive/` 하위 폴더로 이동.

```bash
# 폴더 구조 생성
mkdir -p ~/.hermes/memory/reports/archive/2026-MM-DD
mkdir -p ~/.hermes/memory/archive/2026-MM

# reports/: 2주 이전 일일 리포트 + 모든 weekly 리포트 이동
for f in ~/.hermes/memory/reports/daily_2026-MM-{01..14}.md; do
  [ -f "$f" ] && mv "$f" ~/.hermes/memory/reports/archive/2026-MM-DD/
done
# reports/weekly_*.md도 archive로 (월간 단위)

# 루트 md: 2주 이전 일일 메모리 (예: 2026-02-*.md, 2026-03-*.md) 이동
for f in ~/.hermes/memory/2026-MM-{01..15}-*.md; do
  [ -f "$f" ] && mv "$f" ~/.hermes/memory/archive/2026-MM/
done

# self_heal_YYYY-MM-DD.md도 동일하게 2주 룰 적용
```

**Pitfall**:
- `2026-MM-DD-special-topic.md` 같은 특정 주제 파일은 이동하지 말 것 (예: `critical_notes_*.md`, `botmadang.md`)
- `state.json`, `*.backup`, `*.jsonl` 같은 데이터 파일은 절대 이동 ❌
- `issues.md`, `MEMORY.md`, `2026-06-02.md` (오늘 일기)는 루트에 유지

### 3단계: MEMORY.md 재작성 (10분)

**⚠️ 부분 패치 시 인접 줄까지 매칭될 수 있다.** `patch` 도구의 fuzzy matching이 의도한 줄 너머까지 일치시키면, `old_string`만 들어갔다고 생각한 항목 옆에 있던 줄(예: `- **출력:** ...`)이 통째로 사라질 수 있다. **반드시 패치 직후 `grep` 또는 `read_file`로 인접 5줄을 재확인한다.**

전체 재작성이 부분 패치보다 빠르고 일관성 있다.

**재구성 원칙**:
1. **섹션 순서**: 환경 → DB → 프로필 → 규칙 → API → 워크플로우 순으로 정보 밀도 균일화
2. **중복 제거**: 이슈 13개 행을 모두 나열하지 말고 요약 + `issues.md` 참조
3. **만료 메타 삭제**: "복원 완료", "초기 설정", "오늘 발견" 같은 일회성 섹션 제거
4. **모델 정보 갱신**: 모델 변경 시 즉시 반영 (예: `minimax-m2.7` → `MiniMax-M3`)
5. **표 활용**: `| 항목 | 값 |` 형식으로 가독성 ↑

**권장 섹션 템플릿**:
```
# ICBM2 Memory — 최종 업데이트: YYYY-MM-DD
## 환경
## Notion DB IDs
## 주인님 프로필
## 영상/블로그 제작 규칙
## 뮤직비디오 규칙
## 핵심 API 키/설정
## Tistory API
## Gmail 계정 구분
## NotebookLM
## 이미지 분석
## 블로그 발행 워크플로우
## NotebookLM 영상 워크플로우
## NotebookLM 장애 대응
## Cloudflare Tunnel
## 컨텍스트 최적화
## 알려진 이슈 (전체 목록: issues.md)
## 미해결 작업
```

### 4단계: 검증 (2분)

```bash
# 시스템 메모리 사용량 재확인 (목표: 50% 이하)
# (실제 확인은 다음 세션에서 메모리 도구 read 시)

# 디스크 분포
du -sh ~/.hermes/memory/reports/
du -sh ~/.hermes/memory/archive/

# 새 MEMORY.md 크기
wc -c ~/.hermes/memory/MEMORY.md
```

**3단계 잔여 흔적 확인 (cleanup 후 필수)** — 2026-06-02 세션 교훈:

섹션/스크립트 제거 후 **반드시 3곳을 grep**으로 확인:

```bash
# 1) 진짜 소스 본문에서 잔여 흔적
grep -n "뮤직비디오\|music_video\|datagokr\|apikey" ~/.hermes/MEMORY.md

# 2) 진짜 소스의 "자동화 성과 / 알려진 이슈" 섹션 (별도 위치)
#    예: "🟡 🎬 뮤직비디오 제작 cron: TimeoutError" 같은 이슈 항목이
#    본문은 정리됐는데 이슈 목록에 남아있는 경우

# 3) 보조 파일 (있다면)
grep -n "뮤직비디오\|music_video" ~/.hermes/memories/MEMORY.md 2>/dev/null
```

**왜 3단계?**
- 본문 정리만 하면 "알려진 이슈" 섹션에 dead reference가 남음
- 보조 파일 잔여는 본문과 별개라 별도 grep 필요
- 한 곳에서 발견되면 다른 곳도 같은 키워드로 재검색

**Pitfall (이 단계에서 자주 발생하는 실수)**:
- "본문 정리 끝났으니 끝" → 이슈 섹션의 1줄이 dead reference로 남음
- 보조 파일을 안 봄 → memos 보조 파일이 outdated 상태로 영구 잔존
- 1차 grep으로 안 나오면 "OK" → 키워드 변형(영문/한글/축약) 모두 시도

**성공 기준**:
- ✅ 시스템 메모리 < 60%
- ✅ 루트 md 30개 이하, reports 20개 이하
- ✅ MEMORY.md < 7,000자 (권장)
- ✅ archive 폴더에 안전 보관됨
- ✅ 3단계 grep 모두 0 hits

**의존성 vs 키워드 매칭 — 2026-06-02 교훈 (중요)**:

MEMORY.md 항목을 제거/압축할 때 **키워드 매칭으로 판단하지 말 것**. 예시 사고:

> "숏츠 변환 절대 금지: `pad=...:black` 검은 패드 코드가 계속 복구됨" 항목을
> 키워드 '뮤직비디오'가 들어간 섹션과 함께 묶어 제거 → YouTube Shorts 워크플로우의
> 핵심 규칙(블러 letterbox, `make_shorts()` 함수)이 사라짐.

**판단 기준 — 의존성 우선**:
1. **이 항목이 어떤 시스템에서 호출/참조되는가?** (예: `make_shorts()` 함수가 `video-editing` 스킬에서 정의됨)
2. **어떤 워크플로우의 일부인가?** (예: YouTube Shorts 업로드의 letterbox 처리)
3. **다른 항목과 어떻게 연결되는가?** (예: SKILL.md의 196~209행에 동일 내용 보존됨)

**검증 절차**:
```bash
# 1) grep으로 다른 곳 참조 확인
grep -rln "make_shorts\|블러 letterbox\|boxblur" ~/.hermes/skills/ ~/.hermes/scripts/

# 2) 연관 스킬/스크립트가 살아있으면 → 그쪽이 진짜 소스
#    MEMORY.md 압축은 가능하되, **상세는 스킬이 담당**하도록 위임 표현 추가
#    예: "상세: skills/video-editing/SKILL.md 196~209행 + shorts-ffmpeg-crop-fix.md"
```

**압축 가이드 (스킬이 살아있을 때)**:
- ❌ 키워드 매칭으로 통째 제거
- ✅ 7줄 → 1줄 압축 + 스킬 파일 경로 명시로 위임
- 예: "⚠️ YouTube Shorts: `pad=...:black` 검은 패드 절대 금지 (Chronic Bug) — 상세: `skills/video-editing/SKILL.md` 196~209행"

**3단계 잔여 흔적 확인 (cleanup 후 필수)** — 2026-06-02 세션 교훈:

섹션/스크립트 제거 후 **반드시 3곳을 grep**으로 확인:

```bash
# 1) 진짜 소스 본문에서 잔여 흔적
grep -n "뮤직비디오\|music_video\|datagokr\|apikey" ~/.hermes/MEMORY.md

# 2) 진짜 소스의 "자동화 성과 / 알려진 이슈" 섹션 (별도 위치)
#    예: "🟡 🎬 뮤직비디오 제작 cron: TimeoutError" 같은 이슈 항목이
#    본문은 정리됐는데 이슈 목록에 남아있는 경우

# 3) 보조 파일 (있다면)
grep -n "뮤직비디오\|music_video" ~/.hermes/memories/MEMORY.md 2>/dev/null
```

**왜 3단계?**
- 본문 정리만 하면 "알려진 이슈" 섹션에 dead reference가 남음
- 보조 파일 잔여는 본문과 별개라 별도 grep 필요
- 한 곳에서 발견되면 다른 곳도 같은 키워드로 재검색

**Pitfall (이 단계에서 자주 발생하는 실수)**:
- "본문 정리 끝났으니 끝" → 이슈 섹션의 1줄이 dead reference로 남음
- 보조 파일을 안 봄 → memos 보조 파일이 outdated 상태로 영구 잔존
- 1차 grep으로 안 나오면 "OK" → 키워드 변형(영문/한글/축약) 모두 시도

**성공 기준**:
- ✅ 시스템 메모리 < 60%
- ✅ 루트 md 30개 이하, reports 20개 이하
- ✅ MEMORY.md < 7,000자 (권장)
- ✅ archive 폴더에 안전 보관됨
- ✅ 3단계 grep 모두 0 hits

## §A — 3계층 점진적 공개 (Progressive Disclosure, 2026-07-13 도입)

**언제 쓰나**: 4,000자 한도 압박이 반복될 때 (예: 6개월 누적 후 매 세션 95%+). 평소 4단계 절차로도 충분.

### A.1 — 3계층 구조

| 계층 | 위치 | 부하 | 내용 | 로드 시점 |
|---|---|---|---|---|
| **L0** | `~/.hermes/memories/MEMORY.md` (진짜 주입) | ≤3,800자 | 핵심 선호 + 환경 + 함정 1줄 + **L1 인덱스** | 매 세션 자동 |
| **L1** | `~/.hermes/memories/topics/*.md` | 토픽당 500~2,000자 | 워크플로우 상세 (코딩미션/toss-trader/...) | 필요 시 `search_files`로 fetch |
| **L2** | `~/.hermes/memory/archive/` | 무제한 | 폐기된 컴포넌트, 오래된 이슈 | `session_search` |

**핵심 원칙**: 워크플로우 상세는 skills/ 가 진짜 소스 — 메모리는 **인덱스만**.

### A.2 — L1 토픽 분리 결정 기준

각 메모리 entry에 대해 3초 자문:

| 질문 | ❌ → L0 유지 | ✅ → L1 분리 |
|---|---|---|
| 매 세션 자동으로 필요한가? | Yes | No |
| 다른 곳에 진짜 소스 있는가? (skills/, README, DB) | No | Yes → 거기만, 메모리 X |
| 1주일 후에도 유효한가? | Yes | No |

3개 다 ✅면 L1 토픽 분리 후보. **빈도수보다 재사용성**이 기준.

### A.3 — 절차 (4단계 절차의 변형)

1. **L1 디렉토리 생성**:
   ```bash
   mkdir -p ~/.hermes/memories/topics ~/.hermes/memories/_backup_old_md
   touch ~/.hermes/memories/topics/.gitkeep
   ```

2. **L1 토픽 파일 작성** (워크플로우당 1파일):
   - 헤더: `# <워크플로우명> (YYYY-MM-DD)` + `> L1 토픽 — MEMORY.md에서 분리. <한 줄 요약>`
   - 본문: 원본 메모리 entry 텍스트 보존 + 핵심 명령/코드 블록
   - 푸터: `## 관련` 섹션에 스킬 경로 명시

3. **L0 재작성** — `§` 구분자 트랩 주의:
   - 기존 entry **전체**를 batch `remove` + 새 통합 entry `add` (한 번의 `memory` 도구 `operations` 호출)
   - 단일 `replace`는 entry 통째 매칭 — `§` 구분자가 별도 entry로 분리돼 있으면 실패 (이번 세션 실측)
   - 사용량: `usage=3,930/4,000` 상태에서 add 차단됨 → batch operations로 우회

4. **백업 안전 폴더로 이동** (rm ❌):
   ```bash
   cd ~/.hermes/memories && mv *.bak.* _backup_old_md/  # 7일 후 rm 검토
   ```

5. **3단계 grep 검증**:
   ```bash
   # 진짜 소스 본문에 옛 entry 잔여 0이어야 정상
   # 토픽 키워드는 인덱스 형태로 1회 매칭만 허용
   ```

### A.4 — L0 권장 템플릿 (~1,300자)

```markdown
**L0 메모리 정책 (YYYY-MM-DD 점진적 공개 도입)**: L0 = 이 파일 (≤3,800자, 매 세션 자동 주입) / L1 = ~/.hermes/memories/topics/*.md (필요 시 search_files로 fetch) / L2 = ~/.hermes/memory/archive/ (session_search). **워크플로우 상세 = skills/ 가 진짜 소스, 메모리는 인덱스만**.

**<user> 선호 (불변)**: 한국어 한자 최소화 / clarify 시 4옵션+추천 / "위임할께"=4번째 옵션 신호 위험요소 명시 / 브레인스토밍 우선 / 모든 신규 프로젝트 `/Users/mac/work`.

**환경**: <PC 모델> <RAM> <TZ>, 주=<main model> 폴백=<fallback>, <platform-specific facts>, Python PEP 668=venv/uv 필수, Hermes config 직접수정 ❌ `config edit`.

**L1 인덱스** (X 함정 → `topics/X.md`): `ls ~/.hermes/memories/topics/ → N파일. 워크플로우 상세=L1, L0는 인덱스만.` — **반드시 N값과 화살표 한 줄만**, 토픽명은 절대 나열하지 말 것 (§C.4 실측: 나열하면 +400자).

**자주 만나는 함정 1줄**: <3~5개 핵심 함정>.
```

### A.5 — Pitfall

- **`memory` 도구 `add` 한도 초과 트랩**: `usage=3,930/4,000`에서 `add` 단일 호출 → 거부. **반드시 batch operations**로 `remove + add`를 한 번에. char limit은 최종 결과에서만 검사됨.
- **`memory` 도구 `replace` 단일 entry 트랩**: `§` 구분자가 별도 entry라 entry 통째 매칭 어려움. L0 재작성은 batch `remove` (N개) + `add` (1개) 한 번에.
- **백업 즉시 삭제 ❌**: `MEMORY.md.bak.*` 76~94개를 안전 폴더로 mv만. 7일 후 rm 검토 (memory-hygiene cron이 자동화 가능).
- **L1 파일명 = kebab-case 영문 영숫자만**: `topics/coding-mission-v4.md` (확장자 .md, 공백·특수문자 ❌). grep 인덱스 매칭이 깨질 수 있음.
- **L0 "1줄 인덱스" 형식 통일**: `- **<워크플로우명>** (<한 줄 함정>) → `topics/<file>.md`` — 형식이 매번 다르면 grep 검증이 매번 다르게 동작.
- **3계층 정착 후 daily-self-review cron push 정책 재점검**: cron이 매 자정 푸시하는 데이터가 L0 한도 추월 시 push 정책에 L0 가드 추가 필요.

### A.6 — 재사용

3계층 점진적 공개는 **다른 컨텍스트-압박 시스템에도 적용 가능**:
- 스킬 SKILL.md 본문이 비대해질 때 → `SKILL.md` (핵심) + `references/<topic>.md` (상세) 패턴
- 시스템 프롬프트가 길어질 때 → SOUL.md 압축 + 정책별 sub-file
- Notion DB 페이지가 누적될 때 → 활성 DB + archive DB

**상세 절차 / 8개 L1 토픽 예시 / 검증 결과**: `references/progressive-disclosure-3-tier-2026-07-13.md`

## §B — 위임 패턴 (Delegation Pattern, 2026-07-13 정형화)

**언제 발현하나**: 사용자가 4옵션 clarify에서 **"위임할께"** (또는 "판단 일임", "맡길께", 알아서 해줘 등) 신호를 보냈을 때. **추천 옵션이 명확해도** 사용자가 위임을 선택하는 경우 빈번 (2026-07-12~13 두 차례 관찰). 

### B.1 — 신호 패턴

- "위임할께" / "맡길께" / "판단 일임" / "알아서 해줘"
- clarify 추천을 명시했지만 무시하고 4번째 옵션 (위임) 선택

→ **즉시**: 위험 요소 명시 + 작업 계획 + todo 5~7개 + 진행. **추가 확인 ❌**.

### B.2 — 행동 강령 (위임 받으면 즉시)

1. **위험 요소 4~5가지 명시** (피해 가피 트레이드오프가 아니라 "이런 함정 있으니 미리 알림"):
   ```
   ⚠️ 위험 요소 (5가지)
   1. ...
   2. ...
   ```

2. **작업 계획 제시** (6단계 정도):
   ```
   🎯 작업 계획
   1. ...
   2. ...
   ```

3. **todo 5~7개 즉시 호출** (`todo` 도구):
   - 첫 번째는 `in_progress`
   - 나머지는 `pending`

4. **첫 단계부터 바로 실행** (사용자 응답 기다리지 말 것):
   - 위험 요소 4~5개 + 계획 + todo가 한 메시지에 다 들어가야 함
   - 중간에 clarify 다시 ❌ (이미 위임받음)

5. **완료 후 검증 보고**:
   - 정량 결과 (글자수, 파일 개수, Before/After)
   - Pitfall 발견 시 다음 세션용으로 기록

### B.3 — 위임 트랩

- ❌ 위험 요소 없이 진행 → 사용자가 "이거 위험한 거 아니었어?" 나중에 코렉션
- ❌ todo 없이 진행 → 작업 중간에 어디까지 했는지 추적 불가
- ❌ 첫 단계부터 다시 clarify → 위임 의미 없음
- ❌ 위험 요소 10개+ 나열 → 핵심이 안 보임 (4~5개로 압축)
- ✅ 위험 4~5 + 계획 + todo + 바로 실행 = 1~2 메시지에 완결

### B.4 — 메모리 L0 동반 업데이트

위임 받으면 **반드시** L0 메모리에:
- 위임한 작업의 결과를 1줄로 남길 것 (다음 세션에서 자동 인출 위해)
- 예: "**스킬 라이프사이클 관리 (skill-lifecycle, 2026-07-13 도입)**: ..."

위임 자체의 패턴(신호/행동강령)은 L0가 아니라 **이 §B 섹션**에 박혀 있으므로, 다음 세션 memory-hygiene 자동 로드 시 §B를 참조해 행동.

### B.5 — 재사용

위임 패턴은 **clarify 도구를 사용하는 모든 워크플로우 스킬**에 보편 적용 가능. 각 umbrella SKILL.md에 "위임 받으면 ..." 섹션을 두는 패턴은 권장됨.

**상세 2건 사례 (메모리 점진적공개 + 스킬 폐기)**: `references/2026-07-13-delegation-pattern.md`

## §C — 신규 entry 추가 시 L1 자동 분리 자문 (2026-07-27 도입)

**왜 필요한가**: A안 (NotebookLM entry L0→L1 이동) 시행 결과 — 92% 압박 상태에서도 L1 분리 가능한 entry가 매월 1~2건은 있음. 매번 interactive로 "압축할까?" 묻지 말고 **새 entry 추가 시점에 자가 자문**으로 정형화.

### C.1 — 트리거

`memory` 도구 `add` 진입 직전 (또는 대화 중 "이거 메모리에 박아야 하나" 자문 시점):

### C.2 — 4개 질문 (5초 자문)

| # | 질문 | 예/아니오 |
|---|---|---|
| 1 | **다른 곳에 진짜 소스가 있는가?** (skills/, README, L1 토픽) | Yes → 거기만, 메모리 X |
| 2 | **1주일 후에도 유효한가?** (안 stale해지는가?) | No → memory 부적합 |
| 3 | **매 세션 자동 필요한가?** (정책/신호/워크플로우) | No → L1 후보 |
| 4 | **L1 토픽 8개 중 같은 워크플로우가 이미 있는가?** | Yes → 거기에 merge, L0엔 인덱스 1줄 |

| 결과 | 동작 |
|---|---|
| **Q1=Yes** | 그쪽 가리키는 **인덱스만** L0에 (또는 메모리 안 함) |
| **Q3=No** | `topics/<workflow>.md` 작성 후 L0엔 인덱스 |
| **Q2=No** | 메모리 ❌, 세션 대화/Todo만 |
| **모두 Yes (Q1=No, Q2=Yes, Q3=Yes, Q4=No)** | L0 신규 entry |

### C.3 — L1 작성 절차 (Q3=No 분기)

```bash
# 1) 파일 작성
WRITE_FILE ~/.hermes/memories/topics/<workflow>.md
# 헤더: # <워크플로우명> (YYYY-MM-DD) + L1 토픽 안내
# 본문: 원본 entry 보존 (또는 압축 + 코드 블록)
# 푸터: ## 관련 — 진짜 소스 skills/ 경로

# 2) L0 인덱스 추가 (1줄)
memory(action='add', '**L1 인덱스 +N**: <워크플로우> → `topics/<name>.md`.')
```

### C.4 — Pitfall

- **§A.5 batch operations 트랩 그대로 적용**: L0 ≥90%에서 신규 entry 시 `remove + add`를 한 batch에 묶어야 함.
- **Q1=Yes인데 메모리에 박는 트랩**: 가령 "NotebookLM rookiepy CSNF" → 이미 스킬 `references/notebooklm-...md`에 상세 있음, L1 토픽에 인덱스만. 메모리 본문에 같은 함수정 복제 ❌.
- **Q4=Yes인데 L1 안 만들고 L0 박는 트랩**: 8 토픽에 이미 `notebooklm-fallback.md`가 있는데 새로 추가 entry에 상세 박으면 중복. **반드시 Q4 확인 후 merge**.
- **L1 파일명 = kebab-case 영문**: 공백·특수문자 ❌, grep 인덱스 매칭 깨짐.
- **🚨 L1 "N개 토픽 인덱스" entry 자체가 L0 한도 추월 (2026-07-27 실측)** — `L1 인덱스 (8 토픽, 2026-07-27)`: NotebookLM rookiepy CSNF+created_by=None → `topics/notebooklm-fallback.md` / 코딩미션 풀사이클 → `topics/coding-mission-v4.md` / ... [8개 다 나열]` entry를 L0에 박았더니 +400자. **L0 78% → 98% (2,161자)** 부풀림. 해결: 인덱스 entry를 **`ls ~/.hermes/memories/topics/ → 8파일. 워크플로우 상세=L1, L0는 인덱스만`. 한 줄 (~40자)**로 압축 → L0 1,732자 (78%) 회복. **결론**: L1 인덱스 entry는 **"파일이 어디 있는지 가리키는 화살표만"** — 절대 토픽명을 L0에 나열하지 말 것. 나열하면 §C 도입의 의미가 무너짐 (메모리 한도 = 8개 토픽 x 한 줄 = 추가 한도 압박).
- **`add` 직전/직후 `usage` 확인**: batch operations 호출 후 응답의 `usage` 필드를 봐야 부풀림/절약이 결정적. **`usage < 2,000`이면 OK / ≥ 90% (1,980+)면 작업 중단하고 §A 단계로 진입**. 대화형 시스템에서는 L0 사용량이 보이지 않을 때 — `memory` 도구 결과를 다시 확인.

### C.5 — 분기: §A vs §B vs §C 차이

| | §A (3계층 정착) | §B (위임) | §C (신규 entry) |
|---|---|---|---|
| 트리거 | 메모리 한도 압박 시 작업 시작 | 사용자 "위임할께" 신호 시 | `add` 호출 직전 자동 자문 |
| 동작 | 일괄 재구성 | 즉시 실행 (todo + 위험) | 단일 entry 결정 |
| 빈도 | 6개월+ 1회 | 수 회/월 | 매 `add` 호출 |
| 사용자 확인 | 필요 (등급 매기기) | 불필요 (이미 위임) | 불필요 (자가 자문) |

### C.6 — 재사용

§C 자문 절차는 **다른 컨텍스트-압박 시스템에도 적용**:
- 스킬 SKILL.md 본문에 신규 절차 추가 시 "L0 vs SKILL.md 본문" 자문
- 시스템 프롬프트 항목 추가 시 "메모리 vs SOUL.md" 자문

## 정기 실행 권장 주기

- **매주 일요일 (heartbeat)**: 2주 룰 자동 적용 — 오래된 일일 리포트만 archive로
- **메모리 90% 도달 시**: 즉시 전체 재구성
- **월 1회 (cron 권장)**: 1개월 이전 항목 archive로 강제 이동
- **6개월 누적 후**: 3계층 점진적 공개 (§A) 도입 검토

## Pitfall 정리

- **메모리 한도 초과 시 일부 추가만 시도하지 말 것** — 한 번에 정리하는 게 시간 효율적
- **`memory` 도구 add 실패 시 `replace`로 우회하지 말 것** — 의미 있는 신규 항목은 archive 후 재시도
- **여러 짧은 entry를 1개로 머지할 때 `replace`가 안전 (2026-07-07 실측, NEW)** — `usage=3,989/4,000`처럼 빡빡한 상태에서 신규 entry를 못 넣을 때, 기존 두 entry를 old_text로 묶어 단일 new_string으로 머지. `remove` + `add`는 fuzzy match 트랩 위험. 상세 코드: `references/memory-batch-ops-trap-2026-07-06.md`의 "머지 패턴 — 여러 entry를 한 줄로 압축" 섹션
- **archive로 이동한 파일을 grep으로 찾을 수 있음을 기억** — `archive/` 안에서도 `search_files`로 검색 가능
- **state.json 파일 절대 건드리지 말 것** — 봇 자동화 시스템이 의존 (notebooklm_selection.json, published_topics.json 등)
- **두 개 이상 MEMORY.md가 있으면 잘못된 파일 정리할 위험** — 1단계의 경로 확인 절차 반드시 따를 것 (특히 2026-07-13: `memories/` 복수형이 진짜)
- **부분 패치의 인접 줄 매칭 위험** — `old_string`을 너무 짧게 잡으면 fuzzy match가 인접 줄까지 잡아먹음. 패치 후 5줄 안쪽 컨텍스트로 grep 검증 필수
- **`memory(action='replace')`에 같은 텍스트를 넣으면 효과 0 (2026-06-29)** — 압축 의도라면 반드시 `new_string`이 더 짧아야 함. 같은 길이로 replace한 채 "됐다"고 착각하는 트랩 발견. 검증은 시스템 응답의 `usage` 필드로.
- **`memory(action='remove', old_text='**항목 시작 한 줄**')`은 항목 전체를 제거** (fuzzy match가 § 마커까지 흡수). 부분 제거보다 안전.
- **`§` 구분자가 별도 entry (2026-07-13 실측, NEW)** — L0의 `§\n\n<entry>` 패턴에서 `§` 라인이 그 자체로 entry. `replace` 단일 entry 매칭은 사실상 사용 불가. **batch operations (`remove` + `add`) 사용 필수**.
- **🚫 보류/파악 결정을 메모리에 박지 말 것 (2026-06-29)** — 사용자가 "일단 X만 파악", "보류", "나중에 결정" 등이라 하면 메모리가 아니라 **세션 대화 + Todo/세션 검색**에 남긴다. 4,000자 한도가 빡빡한데 "다음 세션에 떠올릴 후보 항목"을 메모리에 미리 적어두면 → 다음 세션에서 다시 정리하라는 코렉션 받음. **기준**: 메모리는 "다음 세션부터 **즉시** 쓸 사용자 선호/환경 사실"만. 안 떠올려도 되는 건 메모리 후보 아님.
- **MEMORY.md 진짜 소스 식별 트랩 (2026-07-13 NEW)** — `~/.hermes/memories/MEMORY.md` (복수형)이 진짜. 이전 SKILL.md 표는 `~/.hermes/MEMORY.md` (단수형)이라고 잘못 적혀 있었음. **반드시 시스템 프롬프트의 `MEMORY (xx% — X/4000)` 글자수와 일치하는 파일**을 wc -m으로 확인.
- **mtime ≠ 사용 패턴 (2026-07-13 NEW, 스킬 폐기 진단 실측)** — 스킬 `find -name SKILL.md`의 mtime이 모두 30일 이내로 나옴. **사용 신호가 아니라 sync/backup 타임스탬프**. 진짜 사용 추적은 메모리 L0/L1 매칭 + cron 잡 정의 grep + skills_list 호출 로그 (단 영구 세션 DB 없으면 후자는 불가).
- **patch diff 표시 ≠ 실제 파일 (2026-07-13 실측)** — fuzzy match가 의도하지 않은 라인까지 흡수한 것처럼 diff에 표시될 때가 있음 (`--` 라인이 사라지거나 두 라인이 합쳐진 듯 보임). **diff를 신뢰하지 말 것. 반드시 read_file로 실제 파일 끝부분을 재확인**. 특히 SKILL.md같이 외부에서도 patch되는 파일은 더더욱.
- **외부 자동 patch 감지 + 진단 (2026-07-13 실측, NEW)** — 작업 중 `SKILL.md`가 외부에서 patch될 수 있음 (예: `daily-self-review` cron이 `references/` 자동 추가 + SKILL.md patch). `patch` 도구가 "외부 patch 감지" 경고를 띄우면 **diff가 내 작업과 다를 수 있음** → 즉시 read_file로 실제 파일 재확인 + 작성자 진단. **작성자 진단 3단계**:
  1. `ls -lt <file>.md` + 시간 패턴 (06:00~06:10 KST = daily-self-review 23:00 cron)
  2. `grep -rln <keyword> ~/.hermes/cron/` (cron 잡 정의 참조 확인)
  3. `~/.hermes/scripts/self_improve.py` 같은 자동화 스크립트 grep
  → 외부 patch가 정상 동작이면 SKILL.md에 별도 추가 작업 불필요, 새 references 파일만 정리.
- **🚨 `patch` 도구 한국어/특수문자 인코딩 손상 (ISS-098, 2026-08-04 실측, NEW)** — `patch` 도구가 일부 한국어 글자 + `␣` (U+2423, Symbol for Space) 같은 비-ASCII 특수문자를 **U+FFFD (replacement character)**로 손상시킴. 08-04 일일 리뷰 step 4에서 **2회 적중** 확인:
  - **글자 손상 사례**: `갱신` (갱+신) → `갱신신` (글자 중복, 한국어 일부 조합에서 발생)
  - **특수문자 손상 사례**: `␣` (U+2423, `mask_self_healer_terms.py`의 mask 결과) → U+FFFD
  - **판별 신호**: patch 후 파일에 U+FFFD 또는 알 수 없는 박스 문자 등장. diff에는 정상으로 보이지만 실제 파일은 깨진 상태.
  - **반드시 검증** (모든 patch 호출 직후):
    ```bash
    python3 -c "
    p = '<file>'
    c = open(p).read()
    n_ffd = c.count(chr(0xFFFD))
    n_2423 = c.count(chr(0x2423))
    print(f'U+FFFD={n_ffd} (must be 0) | U+2423={n_2423}')
    if n_ffd > 0: sys.exit(1)
    "
    ```
  - **복구 절차 (U+FFFD > 0 발견 시 즉시)**:
    1. **부분 patch는 무의미** — 손상된 위치가 정확히 어디인지 patch로는 알 수 없음
    2. `read_file`로 **깨진 컨텍스트 식별** (예: "갱신신" → "갱신", mask된 단어 주변)
    3. `write_file`로 **파일 전체 재기록** (patch 사용 금지 — patch 도구가 다시 손상시킬 가능성)
    4. 재기록 후 **다시 U+FFFD 검증**
  - **예방**:
    - mask된 텍스트(`␣` U+2423 포함)를 patch할 때는 `write_file` 우선
    - 한국어 일부 글자 (`갱신`, `결재`, `발생` 등 일부 조합) 주변 patch 후 반드시 검증
    - 1byte ASCII 글자만 있는 patch는 안전 (예: 영어-only 라인)
  - **MEMORY.md 영향**: 가장 빈번히 patch되는 파일. step 4 (ISS-088 압축) workflow의 **반드시 추가될 검증 단계**. `daily-self-review` SKILL.md에도 동일 Pitfall 보강 완료.
  - **3번째 적중 시 v1.x 격상**: 1~2회 적중은 patch 도구 환경 의존 (사용자 환경에 따라 발생 빈도 다름). 3번째 적중 시 patch 사용 자체를 write_file로 일원화하는 정책 결정 검토.
- **ISS-094-bis CronPaused raw 단어 자기 잡 잔존 3번째 적중 (08-04 검증)** — daily-self-review 자기 잡 (5d0f14aef84c) 의 Prompt 섹션 (~14k chars) 에 `CronPaused`/`ContextOverflow` 같은 trigger 단어가 살아있으면, cron_self_healer가 dry-run에서 errors 1+ 검출 (FP). 자기 가드 step 11 (in-place Python 마스킹) + step 12 (--check-dir backfill) 가 이걸 fix하지만, **자기 가드를 거치기 전의 dry-run은 항상 1건 오탐** 패턴 확인. **처리**: dry-run errors 1 = 자기 잡 trigger leak 신호 → step 11/12로 자동 회복 기대. 3번째 적중 후 안정화 패턴. ISS-097과 양대 trigger 검출 패턴 (self-quote vs Prompt 잔존).
- **🚨 잡 응답 본문 한국어 trigger 매칭 (ISS-098-extended, 2026-08-08 신규)** — cron_self_healer의 `JSONDecodeError` regex `(?:json.*decode|expecting.*value|invalid.*json)`가 잡 `0b0e9f44e10a` (Tistory 세션 일일 체크) 응답 본문의 `JSON 파싱 실패` 한국어 구문을 매칭 → FP. **잡은 정상 실행** (FAIL=2 검출 + owner 알림). 자기 leak 카테고리 3번째 변형:
  - ISS-094 (07-19): Prompt/Response 혼합 스캔
  - ISS-097 (08-02): Response 내부 self-heal 결과 인용
  - **ISS-098-extended (08-08)**: 잡 응답 본문 한국어 + ASCII 혼합 trigger
  - **월 2~3회 같은 카테고리 적중** 패턴. 자기 보수 도구의 trigger는 모국어 변형에 본질적으로 약함 → 한국어/중국어/일본어 등 비라틴 환경에서 매칭 표면 폭증.
  - **판별 신호 (3가지)**: ① 잡 `last_status=ok`인데 자기 잡 아닌 다른 잡 FP, ② FP 잡 output 본문에 `JSON 파싱`/`JSON 디코드`/`json 오류` 한국어+ASCII 혼합, ③ trigger label이 영어 trigger 0건 매칭.
  - **해결 — `_MASK_TABLE` 페어 패치 (ISS-089 패턴 동일)**: `JSON\s*파싱\s*실패` → `json␣parse␣issue` 등. 일일 리뷰 step 9 마스킹 + step 11 자기 cron output 사후 마스킹이 자동 회복하지만, **1번째 적중 시 `_MASK_TABLE` 페어 패치는 보류** (ISS-098 격상 조건: 2회째 다른 잡에서 재발 시).
  - **상세**: `references/iss-098-korean-trigger-fp-2026-08-08.md` (작성 예정, 격상 시 정식 등록).

## 메모리 적합/부적합 판단 기준 (2026-06-29 추가)

메모리 추가 전 3초 자문:

| 정보 유형 | 메모리 적합? | 예시 |
|---|---|---|
| **사용자 선호 (반복 등장)** | ✅ 적합 | "한국어로 응답", "clarify 시 4옵션+추천" |
| **환경 사실 (불변)** | ✅ 적합 | "에르메스PC = M4 Mac mini 16GB", "zai/GLM 구독 종료" |
| **워크플로우 규칙 (재사용)** | ✅ 적합 | "YouTube 일반 영상 = Shorts 세트" |
| **명시적 "이건 기억해" 요청** | ✅ 적합 | 사용자 직접 지시 |
| ❌ 세션 내 보류 결정 | ❌ 부적합 | "OpenCode 로컬 셋업 보류" → 세션 안에서만 |
| ❌ 일회성 탐색 결과 | ❌ 부적합 | "M4 16GB에서 Gemma 4 12B RAM ~8GB" → 그 세션 답변용 |
| ❌ 다른 시스템이 가진 사실 | ❌ 부적합 | GitHub README, Notion DB, 스킬 본문 → 그쪽이 진짜 소스 |
| ❌ 작업 진행/TODO 상태 | ❌ 부적합 | "Phase 1 끝남", "PR #123 머지" → session_search |
| ❌ 1주일 후면 stale해질 정보 | ❌ 부적합 | "어제 본 뉴스", "오늘 발견한 버그" → 일일 리포트 |

**판단 흐름**:
1. 이 정보가 **다음 세션에서 자동으로** 필요한가? 아니면 그 세션에서만?
2. 이 정보가 **다른 곳에 진짜 소스**가 있는가? (스킬, README, DB) → 있으면 거기만, 메모리 ❌
3. 이 정보가 **1주일 후에도** 유효한가? 아니면 stale해질 것인가?
4. **3개 다 ✅** 면 메모리 후보. 하나라도 ❌면 메모리 ❌.

## 관련

- `daily-self-review` — 매일 자기 개선 시 incremental 메모리 정리 수행 (작은 단위). §A 도입 후 push 정책에 L0 가드 추가 검토.
- `nightly-maintenance-workflow` — 심야 자동 정비 (에러 모니터링 중심, 메모리는 일부)
- `memory-error-tracker` — issues.md와 MEMORY.md의 에러 추적 동기화
- `automation-decommission` — 컴포넌트 제거 워크플로우 (메모리도 함께 정리 필요 시)

## 실행 기록 (references/)

- `references/2026-06-02-cleanup-run.md` — 2026-06-02 전체 재구성 실행 결과 (96개 archive, MEMORY.md 4,098→5,647자 재구성)
- `references/2026-06-02-wrong-file-misroute.md` — MEMORY.md 두 개 파일 혼동 사고 보고 + 복구 절차 (잘못된 파일 3건, 진짜 소스 무손상)
- `references/2026-06-02-phase2-decommission.md` — 2차 컴포넌트 폐기 실행 (뮤직비디오 + 공개데이터포탈, MEMORY.md 8,964→4,259B, 시크릿 trash vs 코드 rm 분리 원칙)
- `references/2026-06-29-defer-not-memory.md` — 사용자 코렉션: "보류 결정을 메모리에 남기지 말 것" (4,000자 한도는 희소 자원, 메모리 적합/부적합 8개 항목 판단 기준 + 3초 자문 흐름 도입)
- `references/2026-06-29-grade-then-clean.md` — 능동 정리 요청 워크플로우: 항목별 ✅유지/⚠️압축/❌제거 등급 매기기 → 사용자 한 번 확인 → `memory` 도구 일괄 실행 (replace 트랩 + remove 항목 흡수 동작 포함)
- `references/memory-batch-ops-trap-2026-07-06.md` — `memory` 도구 batch operations 트랩 (usage 99% → add 차단 → remove + add 한 번에 batch)
- `references/phantom-listing-fallback-2026-07-06.md` — skills_list는 표시되지만 디스크에 폴더 부재 상황 대응
- `references/progressive-disclosure-3-tier-2026-07-13.md` — **3계층 점진적 공개 도입 보고서 (NEW)** — L0/L1/L2 구조, 8개 토픽 파일, batch operations 실측, 검증 결과
- `references/2026-07-13-skill-decommission.md` — **스킬 폐기 1차 실행 (NEW)** — .archive 53개 = 20 버저닝 + 33 폐기, _decommission_2026-07/ 격리, 2026-07-27 rm 검토
- `references/2026-07-13-delegation-pattern.md` — **위임 패턴 정형화 (NEW)** — "위임할께" 신호 → 위험 요소 + 작업 계획 + todo + 바로 실행. 2건 실측 (점진적공개 + 스킬 폐기). §B 정형화 근거.
- `references/2026-07-13-external-patch-detection.md` — **외부 자동 patch 감지 + 진단 (NEW)** — 작업 중 SKILL.md가 daily-self-review cron에 의해 외부 patch될 때 작성자 진단 절차 + 명명 패턴 추정
- `references/iss-098-korean-trigger-fp-2026-08-08.md` — **잡 응답 본문 한국어 trigger FP (NEW, 1번째 적중)** — `0b0e9f44e10a` Tistory 쿠키 만료 체크가 `JSON 파싱 실패` 한국어 구문으로 self-heal `JSONDecodeError` regex 매칭. 자기 leak 카테고리 3번째 변형 (ISS-094/097과 양대). `_MASK_TABLE` 페어 패치 보류, 2회째 다른 잡에서 재발 시 v1.0.45 정식 격상.