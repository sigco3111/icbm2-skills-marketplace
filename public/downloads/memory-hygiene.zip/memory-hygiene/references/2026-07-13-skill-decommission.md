# 스킬 폐기 1차 실행 (2026-07-13)

## 배경

희정님 요청: "사용하지 않는 스킬은 비활성 처리했으면 함"
→ 262개 스킬 중 대부분이 inactive 추정. 4곳(cron/memory/secret/skill) 진단 후 보수적 폐기.

## 진단 결과 (4가지 데이터 소스 교차 검증)

| 데이터 소스 | 결과 |
|---|---|
| **mtime (30일/90일)** | 사용 추적 ❌ — sync 타임스탬프일 뿐 |
| **세션 DB** | 부재 (FTS5만 영구, SQLite 미확보) |
| **메모리 L0/L1 인덱스** | 14개 매칭 (필수 활성) |
| **cron yaml/yml 정의** | 0개 참조 |
| **secrets/ 참조** | 0개 |
| **명명 휴리스틱** | 1개 (`test-driven-development` — 정상 카테고리) |

## .archive 53개 정체 분석

`comm -12/-13` 명령으로 active와 archive 교차 비교:

| 분류 | 개수 | 정체 |
|---|---|---|
| Active ∩ Archive (중복) | 20개 | **버저닝** — active가 신버전, archive가 옛 버전 |
| Archive 전용 | 33개 | **진짜 폐기 후보** |

## 폐기 후보 33개 분류

| 유형 | 개수 | 예시 |
|---|---|---|
| **impeccable-* (디자인 보조)** | 14개 | impeccable-animate, audit, bolder, colorize... |
| **옛 비전 모델** | 3개 | gemini-cli-vision, gemma4-vision, minimax-vision |
| **옛 음악 생성** | 4개 | ai-music-generation, korean-ballad-from-reference, minimax-mmx-music, music-video-pipeline-20260525 |
| **에이전트 CLI 중복** | 2개 | claude-code, codex (active 중복) |
| **기타 폐기** | 10개 | perpetual-engine-zai (zai 구독 종료), telegram-commands, xitter 등 |

## 안전 검증 (4곳 grep)

33개 후보 × 4곳(cron 잡 정의/memory/secrets/cron output):

```
[메모리 L0/L1] 히트: 0 ✅
[cron yaml/yml] 히트: 0 ✅
[secrets/] 히트: 0 ✅
[cron output/] 히트: 15 (과거 산출물, archive 이동 무관)
```

cron output/ 히트는 `2026-06-07 ~ 2026-07-12` 날짜의 자동 생성 md 파일. 현재 cron 동작에 영향 없음.

## 실행 결과

| 항목 | Before | After |
|---|---|---|
| 전체 SKILL.md | 262개 | 262개 (변동 없음 — 이동이라) |
| Active | 188개 | 188개 |
| .archive | 53개 | **20개** (버저닝만 남음) |
| _decommission_2026-07/ | 0개 | **33개** (폐기 후보 격리) |

## 진행 절차

1. **사전 검증** — 4곳 grep ✅
2. **폴더 생성** — `mkdir ~/.hermes/skills/_decommission_2026-07/`
3. **33개 이동** — `mv ~/.hermes/skills/.archive/<name> ~/.hermes/skills/_decommission_2026-07/`
4. **이동 후 검증** — 4곳 grep 0 히트 ✅
5. **메모리 추가** — L0에 "스킬 라이프사이클 관리" 1줄 + 폐기 일정 (2026-07-27 rm 검토)
6. **레퍼런스 기록** — 이 파일

## 보류 사항

### Active 174개 중 미인덱싱

사용 패턴 데이터 없음 → 추측 금지 → **시간 지나면서 자연 사용 패턴 파악**
다음 메모리 한도 압박 시 재진단

### 20개 .archive 중복

active가 신버전, archive는 역사 보존 가치. rm ❌

## 다음 액션 (2026-07-27)

14일 안전 기간 후 `_decommission_2026-07/` 33개 rm 검토:

```bash
# 14일 후 자동 알림 (cron 또는 memory L0 일정 참고)
rm -rf ~/.hermes/skills/_decommission_2026-07/
```

검증 절차:
- 14일 동안 skills_list 새로고침 시 33개 노출 0개 확인
- L0/L1/cron/secret 신규 참조 0개 확인
- 이슈 발생 시 `_decommission_2026-07/` → `~/.hermes/skills/.archive/` mv back으로 복구

## 발견된 함정 (다음 세션 참고)

1. **mtime = sync 타임스탬프** ≠ 사용 패턴. 스킬 사용 추적 X
2. **세션 DB 부재** — 영구 SQLite 미확보, FTS5만 메모리
3. **`.archive` = 폐기 + 버저닝 혼재** — `comm` 명령으로 분리 필수
4. **메모리 도구 `\n\n` 자동 분리** — 한 entry에 `\n\n` 들어가면 자동 split. patch 시 current_entries에 여러 개로 표시됨
5. **`memory tool` 동작**: 5개 entry 각각이 별도 매칭 단위. `replace` 시 정확히 복사 필수.

## 관련

- L0 메모리: `~/.hermes/memories/MEMORY.md` "스킬 라이프사이클 관리" 항목
- 안전 폴더: `~/.hermes/skills/_decommission_2026-07/`
- 잔여 archive: `~/.hermes/skills/.archive/` (20개 버저닝)
- `automation-decommission` 스킬 — 정식 폐기 절차 (이번엔 직접 진단 + mv)