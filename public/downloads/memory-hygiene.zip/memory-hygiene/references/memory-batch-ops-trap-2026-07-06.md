# Memory 도구 batch operations 트랩 (2026-07-06 실측)

## 증상

시스템 메모리가 3,981/4,000 (99%) 상태에서 신규 entry 추가 시도:

```python
memory(action='add', target='memory', content='...264자...')
```

→ **거부됨** (`Adding this entry (264 chars) would exceed the limit`). add 단일 호출로는 절대 통과 안 됨.

## 같은 길이 replace 트랩 (2026-06-29 known)

`memory(action='replace', old_text=..., new_text=...')` 호출 시 **`new_text` 길이 ≤ `old_text` 길이**여야 통과. 같은 길이로 바꾸면 usage 변화 0 — "압축했다" 착각하는 트랩.

## 해결 — batch operations (한 번에 remove + add)

**원리**: `memory` 도구의 `operations` 배열 파라미터로 remove + add를 **atomically 한 번에** 실행. 최종 결과가 4,000자 이하면 통과.

**패턴 (2026-07-06 실측, #43 함정 추가 시)**:

```python
# 1단계: 가장 stale/긴 entry부터 remove (Boutlet 등 빈도 낮은 1줄 패턴)
memory(action='remove', target='memory',
       old_text='**Boutlet/AI 에이전트 경제 (06-30, 압축):** Boutlet = ...')

# 2단계: 공간 확보 후 add
memory(action='add', target='memory',
       content='**NotebookLM후보 cron stdout silent 함정 (07-06):** ...264자...')

# 또는 한 번의 batch 호출:
memory(target='memory', operations=[
    {'action': 'remove', 'old_text': '**Boutlet/AI ...'},
    {'action': 'add', 'content': '**NotebookLM cron stdout silent 함정 (07-06):** ...'},
])
```

## 교훈 — memory 한도 90%+ 시 워크플로

1. **먼저 add 시도** → 거부되면 batch operations 진입
2. **가장 빈도 낮은 entry부터 remove** — 키워드: "06-26 ~ 06-30 같은 옛 날짜", "1줄 요약 가능한 entry", "다른 시스템이 진짜 소스인 entry" (이미 메모리 적합/부적합 표에 명시)
3. **여러 entry를 한 번의 batch로** (remove + remove + add) — char limit은 **최종 결과**에서만 검사됨
4. **결과 확인**: 응답의 `usage` 필드로 `current/limit` 검증

## Pitfall

- **단일 add만 반복하지 말 것** — 한 번에 정리하는 게 시간 효율적 (memory-hygiene SKILL.md Pitfall 섹션과 동일)
- **stale-by-rotation (회전식) 우선** — 가장 오래된 entry부터. 예: 06-30 → 07-01 → 07-05 ...
- **stale-by-frequency 우선** — 가장 적게 참조되는 entry부터. 예: Boutlet (1회 인용) > Tistory (10회+)
- **batch 후 응답에 "Write saved" 뜨면 완료** — `current_chars/limit` 보고 검증 필수
