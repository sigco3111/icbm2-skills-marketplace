# Phantom-listing fallback (skills_list는 보이지만 디스크 부재) — 2026-07-06 실측

## 배경

2026-07-06 세션에서 위임 지시가 "~/.hermes/skills/memory-hygiene/scripts/hygiene_check.sh 실행" 같은 호출을 보냈으나:

- `skills_list` 출력에 `memory-hygiene` 항목 정상 표시
- `skill_view` 응답 정상 (SKILL.md 본문 + linked files 모두 노출)
- **실제 디스크 `~/.hermes/skills/memory-hygiene/` 디렉터리 부재** (cross-profile import / sync 실패 / 디렉터리 재배치 가능성)
- 위임에서 가정한 `scripts/hygiene_check.sh` 실행 → `No such file or directory`

이런 **phantom listing 상태**는 다른 umbrella에도 발생할 수 있는 cross-cutting risk.

## 진단 1줄 oneliner (5초)

```bash
ls ~/.hermes/skills/<umbrella_name>/ 2>&1 || echo "PHANTOM_LISTING"
```

| 출력 | 진단 |
|---|---|
| 디렉터리 내용 (정상) | 헬퍼 스크립트/레퍼런스 추가 설치 가능, 정상 진행 |
| `No such file or directory` | **phantom listing** — umbrella는 보이지만 실제 부재 |
| `Permission denied` | 권한 문제 — 별도 해결 |

## Fallback (umbrella 부재 시)

**memory-hygiene의 경우 (skill 자체는 정상 응답하지만 디렉터리만 부재)**:

1. `skill_view`로 본 SKILL.md 본문만으로 충분한 동작 가능 (`memory` 도구 read + archive + 재작성 4단계 절차)
2. 위임에서 요청한 외부 헬퍼 스크립트가 없어도 **umbrella 본문이 갖는 절차**로 진행
3. 한도 측정 1줄 oneliner:
   ```bash
   wc -m ~/.hermes/memory/MEMORY.md | awk '{u=$1; if (u<4000) print "OK under_limit usage="u" cap=4000"; else if (u<6000) print "COMPRESS usage="u" cap=4000 diff="(u-4000); else print "RESTRUCTURE usage="u" cap=4000 diff="(u-4000)}'
   ```

## 우선순위 (phantom listing 발견 시)

1. 위 oneliner로 직접 측정 → 보고
2. umbrella SKILL.md 본문만으로 동작 (다른 섹션인 "4단계 절차" 등 활용)
3. **없던 스크립트를 직접 새로 만들거나 만들려는 시도 ❌** — umbrella 재구성이 curator 책임
4. 부모 세션에 **curator 의제로 노트**:
   ```
   ⚠️ 메모리 hygiene 패스 진행 (직접 oneliner 사용).
   SKILL.md의 `scripts/hygiene_check.sh` 부재 → curator가 디렉터리/스크립트 보강 검토 권장.
   ```

## 예방 (umbrella 신규 생성 시)

새 umbrella 생성 직후:
```bash
mkdir -p ~/.hermes/skills/<umbrella_name>/{references,scripts,templates} && \
touch ~/.hermes/skills/<umbrella_name>/{references,scripts,templates}/.gitkeep
```

이 4종 (SKILL.md + 빈 `references/` + 빈 `scripts/` + 빈 `templates/`)이 모두 존재해야 phantom listing이 안 생긴다. **반드시 umbrella 디렉터리는 disk-bound**로 만들 것.

## Cross-cutting risk (다른 umbrella에도 동일 가능)

| umbrella | phantom 위험도 | 의존 스크립트 |
|---|---|---|
| `memory-hygiene` | 🟡 High (이번 세션 실측) | `scripts/hygiene_check.sh` |
| `notebooklm-youtube-automation` | 🟢 Low (실재, 6개 scripts 확인) | `scripts/youtube_reauth.py`, `scripts/verify-stdout-fallback.sh`, `scripts/hermes-verify-template.sh`, `scripts/youtube_token_refresh.py` |
| `daily-self-review` | 🟡 Medium | 레퍼런스 다수 |
| `nightly-maintenance-workflow` | 🟡 Medium | 단계별 cron |
| `music-video-generator` | 🟢 Low | mmx-cli 의존 (외부 CLI) |
| `ai-model-tracker` | 🟡 Medium | Notion API |

**트리거 패턴**: 위임에서 "~/.hermes/skills/X/scripts/Y.sh 실행"이 오면 `ls ~/.hermes/skills/X/`로 sanity check 우선 (umbrella 자체가 disk-bound인지 확인). 정상 + 스크립트 부재 시 fallback oneliner로 대체.

## 적용된 umbrella

- `memory-hygiene` SKILL.md에 "Phantom-listing fallback" 섹션 추가 (2026-07-06)
- 5초 진단 + 1줄 oneliner + 우선순위 4단계 + 예방 절차 + cross-cutting risk 표 포함
