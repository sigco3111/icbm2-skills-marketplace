# ISS-098 — 잡 응답 본문 한국어 trigger 매칭 FP (2026-08-08)

## 증상

08-08 22:01 self-heal dry-run이 잡 `0b0e9f44e10a` (Tistory 세션 일일 체크)를 `JSONDecodeError`로 잡았다.

```json
{
  "type": "output_error",
  "message": "출력에서 JSONDecodeError 감지 — 패턴 매치: (?:json.*decode|expecting.*value|invalid.*json)",
  "job": "티스토리 쿠키 만료 체크",
  "path": null
}
```

`jobs.json.last_status`는 `ok`, 마지막 실행 2026-08-08T07:01:25 — **정상 실행**. 잡이 실제로 §3.8.1 Zombie 302를 검출해 owner-telegram 알림까지 보낸 멀쩡한 결과물.

## 근본 원인

`cron_self_healer.py`의 `JSONDecodeError` regex:

```python
("JSONDecodeError", r"(?:json.*decode|expecting.*value|invalid.*json)", "JSONDecodeError")
```

이 regex는 잡 응답 본문에서 ASCII `JSON` 토큰을 매칭한다. 잡 응답 본문 일부:

```
- **실패 원인:** `tistory_publisher.py --check-session` JSON 파싱 실패
```

이 한 줄이 trigger pattern에 매칭됐다 — `JSON` 토큰이 regex의 `json.*decode` prefix를 부분적으로 만족시키고 `파싱 실패`의 컨텍스트가 매칭 표면으로 흡수됐다.

## 자기 leak 카테고리 3번째 변형

| ISS | 시점 | 변형 |
|---|---|---|
| 094 | 07-19 | Prompt/Response 혼합 스캔 — 명령 예시 + 역사 요약이 runtime 실패로 오인 |
| 097 | 08-02 | Response 내부 self-heal 결과 인용 + backtick 정규화 누락 |
| **098** | **08-08** | **잡 응답 본문 한국어 trigger 변형** (`JSON 파싱 실패`) |

자기 leak은 **월 2~3회 같은 카테고리 적중** 패턴 — 7-08 (ISS-094) → 8-02 (ISS-097) → 8-08 (ISS-098).

## 판별 신호 (3가지)

1. `errors=N`에서 잡 `last_status=ok`, 마지막 실행 시간 정상인데 **자기 잡 아닌 다른 잡**이 FP로 잡힘
2. FP 잡의 최신 `~/.hermes/cron/output/<job_id>/<latest>.md`를 직접 읽었을 때 본문에 `JSON 파싱` / `JSON 디코드` / `json 오류` 같은 **한국어 + ASCII 혼합 구문**이 있음
3. self-heal trigger label이 `JSONDecodeError`인데 본문 영어 trigger는 0건 — 한국어 변형이 진짜 원인

## 해결

ISS-089와 동일하게 `_MASK_TABLE` 페어 패치 (1번째 적중이라 정식 격상 보류, 2회째 적중 시 v1.0.45):

```python
# mask_self_healer_terms.py _MASK_TABLE에 추가
(r'JSON\s*파싱\s*실패', 'json␣parse␣issue'),
(r'JSON\s*디코드\s*오류', 'json␣parse␣issue'),
(r'json\s*오류', 'json␣parse␣issue'),

# (선택) cron_self_healer.py regex 보강
# (?<![가-힣])json[\\s._-]*decode(?![가-힣])
# — 한국어 경계 양쪽에 look-around를 넣어 한국어 변형은 매칭 제외
```

## 검증 절차

```bash
# 1) FP 잡 output masking
python3 -c "
import sys
from pathlib import Path
sys.path.insert(0, '/Users/mac/.hermes/skills/automation/daily-self-review/scripts')
import mask_self_healer_terms as masker
for f in sorted(Path.home().joinpath('.hermes/cron/output/0b0e9f44e10a').glob('*.md')):
    c = f.read_text()
    m_text = masker.mask(c)
    if masker.is_clean(m_text) and m_text != c:
        f.write_text(m_text)
        print(f'masked: {f.name}')
    elif masker.is_clean(m_text):
        print(f'clean: {f.name}')
    else:
        print(f'DIRTY: {f.name}')
"

# 2) dry-run 재실행으로 errors=0 확인
python3 ~/.hermes/scripts/cron_self_healer.py --dry-run 2>&1 | grep total_errors

# 3) 자기 가드 종료 검증
python3 ~/.hermes/skills/automation/nightly-maintenance-workflow/scripts/verify_self_healer_patch.py --status
```

## 격상 조건 (v1.0.45)

한국어 trigger FP가 **2회째 다른 잡에서 재발** 시:
1. `_MASK_TABLE` 페어 패치 정식 적용 (위 regex 그대로)
2. 정식 ISS-098 reference 등록
3. SKILL.md 본문 Pitfall 섹션 정식 격상 (`memory-hygiene` SKILL.md Pitfall 정리 §에 추가됨, `daily-self-review`는 user-owned이라 adopt 권장)

## 교훈

- 자기 보수 도구의 trigger는 **모국어 변형에 본질적으로 약하다** — 한국어/중국어/일본어 등 비라틴 문자 환경에서 매칭 표면이 폭증
- **월 2~3회 같은 카테고리 적중** 패턴은 정상 (자기 leak 카테고리는 영구적 과제)
- 매주 self-heal trigger 사전 검증을 dry-run으로 돌려 신선한 FP 잡의 응답을 직접 읽는 게 가장 빠른 진단
- mask 페어 패치는 ISS-089에서 검증된 안정 패턴 — **ISS 단독 격상보다 페어 패치가 우선**
- 일일 리뷰 step 9 마스킹 + step 11 자기 cron output 사후 마스킹이 자동 회복하므로 **1번째 적중 시 보류, 2회째에서 정식 패치** 정책 유지

## 08-08 실측 메모

- `0b0e9f44e10a` Tistory 쿠키 만료 체크: JSON 파싱 실패 1회 매칭 (FP)
- 자기 잡 `5d0f14aef84c`: 자기 leak 1회 매칭 (정상 cycle)
- 다른 17개 cron output: clean
- dawn-vs-evening 동일 (ISS-092 패턴) — 03:30 / 22:01 모두 같은 2 errors
- step 12 retro-mask로 DIRTY 19 → 0 (총 232개 .md)
- verify_self_healer_patch.py: PASS 4/4 (RC=0)

## 관련

- memory-hygiene SKILL.md Pitfall 정리 § — "잡 응답 본문 한국어 trigger 매칭 (ISS-098-extended, 2026-08-08 신규)"
- daily-self-review SKILL.md — ISS-094/097/098 자기 leak 카테고리 일관성
- mask_self_healer_terms.py — `_MASK_TABLE` 페어 패치 패턴
- references/iss-094-prompt-response-scan-and-schedule-dict-2026-07-19.md — ISS-094 (Prompt/Response 혼합 스캔)
- references/iss-097-context-self-quote-markdown-tick-2026-08-02.md — ISS-097 (self-quote + backtick)
