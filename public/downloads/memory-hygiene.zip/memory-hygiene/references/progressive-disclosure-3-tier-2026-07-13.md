# 3계층 점진적 공개 도입 보고서 (2026-07-13 실측)

> **L1 토픽 / SKILL 보강**: memory-hygiene SKILL.md v1.0.2 §A 참조. 본 문서는 실행 보고 + 8개 토픽 템플릿 + batch operations 실측 코드 포함.

## 컨텍스트

사용자 질의: "우리 memory.md파일이 항상 부족해서 매번 삭제하고 압축하고를 반복하는데, 혹시 점진적공개 방식으로 관리가 가능할까?"

→ 4옵션 clarify 후 A옵션 (3계층 분리) 채택, "위임할께" 신호로 즉시 진행.

## 진단 결과

### 진짜 시스템 주입 소스

| 파일 | 글자수 | 시스템 영향 | 비고 |
|---|---|---|---|
| `~/.hermes/memories/MEMORY.md` | **3,930자** | ✅ 진짜 주입 소스 | **복수형! 시스템 프롬프트 98%와 매치** |
| `~/.hermes/MEMORY.md` | 7,178자 | ❌ 보조 | 단수형, 무시 가능 |
| `~/.hermes/memory/MEMORY.md` | 2,140자 | ❌ 보조 | 보조 |

**SKILL.md v1.0.1의 표는 잘못된 정보였음** (단수형을 진짜로 표기). 이번에 정정.

### 디스크 분포

```
~/.hermes/memory/ 루트 md: 75개
~/.hermes/memory/reports/: 59개
~/.hermes/memory/archive/: 15개
~/.hermes/memories/MEMORY.md.bak.* + USER.md.bak.*: 94개
```

## 3계층 구조 (최종)

| 계층 | 위치 | 부하 | 내용 | 로드 시점 |
|---|---|---|---|---|
| **L0** | `~/.hermes/memories/MEMORY.md` | ≤3,800자 | 선호 + 환경 + 함정 1줄 + L1 인덱스 | 매 세션 자동 |
| **L1** | `~/.hermes/memories/topics/*.md` | 토픽당 500~2,000자 | 워크플로우 상세 | `search_files`로 fetch |
| **L2** | `~/.hermes/memory/archive/` | 무제한 | 폐기 사례 | `session_search` |

**핵심**: 워크플로우 상세는 skills/ 가 진짜 소스 — 메모리는 **인덱스만**.

## 실행 절차 (실측)

### 1단계: L1 디렉토리

```bash
mkdir -p ~/.hermes/memories/topics ~/.hermes/memories/_backup_old_md
touch ~/.hermes/memories/topics/.gitkeep
```

### 2단계: L1 토픽 8개 작성

| 파일 | 글자 | 워크플로우 |
|---|---|---|
| `topics/coding-mission-v4.md` | 664 | 코딩미션 v4.0 (사전 방어, 2중 grep) |
| `topics/execute-code-blocked.md` | 920 | execute_code BLOCKED heredoc 우회 |
| `topics/vercel-alias-slots.md` | 970 | Vercel alias 슬롯 + -nu suffix |
| `topics/adhoc-verify-assertions.md` | 752 | git ls-files stdout 비교 함정 |
| `topics/toss-trader-fix3.md` | 1,100 | toss-trader 런타임 fix 3건 |
| `topics/hermes-desktop-and-tele-workers.md` | 897 | Hermes Desktop + 텔레 단일 IP 트랩 |
| `topics/security-no-plaintext-tokens.md` | 965 | 토큰 평문 금지 + kakao-timeline 폐기 |
| `topics/notebooklm-fallback.md` | 1,014 | NotebookLM 후보 DB 사망 + 위임 선호 |
| **합계** | **7,282** | 8개 |

### 3단계: L0 재작성 (batch operations 실측 코드)

**문제**: `usage=3,930/4,000` (98%) 상태에서 `add` 단일 호출 → **거부됨**:
```
Error: Memory at 3,930/4,000 chars. Adding this entry (1309 chars) would exceed the limit.
Consolidate now: use 'replace' to merge overlapping entries into shorter ones or 'remove' stale or less important entries
```

**시도 1**: `replace` (전체 22줄 → 새 통합 entry) → **실패**: `§` 구분자가 별도 entry로 분리돼 있어서 `old_text` 전체 매칭 안 됨.

**시도 2 — 성공 (batch operations)**: 한 번의 `memory` 도구 호출로 `remove` 12개 + `add` 1개:

```python
memory(target='memory', operations=[
    {'action': 'remove', 'old_text': '- **브레인스토밍 우선**: ...'},  # entry 1
    {'action': 'remove', 'old_text': 'LLM Wiki (06-05): ...'},  # entry 2
    # ... 총 12개 remove
    {'action': 'add', 'content': '**L0 메모리 정책 (2026-07-13 점진적 공개 도입)**: ...\n\n**희정님 선호 (불변)**: ...\n\n... (1,309자 통합 entry)'},
])
```

**결과**: `success=true, usage="32% — 1,309/4,000 chars"`. 3,930 → 1,309자 (67% 감소).

### 4단계: 백업 안전 폴더로 이동

```bash
cd ~/.hermes/memories
mv MEMORY.md.bak.* _backup_old_md/  # 76개
mv USER.md.bak.* _backup_old_md/    # 18개
# 합계 94개, 7일 후 rm 검토
```

`MEMORY.md.lock`, `USER.md.lock`은 시스템 자동 생성 파일이라 그대로 둠.

### 5단계: 3단계 grep 검증

```bash
# 진짜 소스 본문에 옛 entry 잔여 0이어야 정상
# 토픽 키워드는 인덱스 형태로 1회 매칭만 허용
```

**결과**: 8개 토픽 키워드 모두 정확히 1회 (인덱스), 옛 L0 22줄 잔여 0.

## 새 L0 템플릿 (실측, ~1,300자)

```markdown
**L0 메모리 정책 (2026-07-13 점진적 공개 도입)**: L0 = 이 파일 (≤3,800자, 매 세션 자동 주입) / L1 = `~/.hermes/memories/topics/*.md` (필요 시 search_files로 fetch) / L2 = `~/.hermes/memory/archive/` (session_search). **워크플로우 상세 = skills/ 가 진짜 소스, 메모리는 인덱스만**.

**희정님 선호 (불변)**: 한국어 한자 최소화 / clarify 시 4옵션+추천 / "위임할께"=4번째 옵션 신호 위험요소 명시 / 브레인스토밍 우선 / 모든 신규 프로젝트 `/Users/mac/work`.

**환경**: 에르메스PC M4 Mac mini 16GB Asia/Seoul, 주=MiniMax-M3 폴백=NIM gpt-oss-120b, Hermes Desktop (Electron Apple Silicon) ≠ CLI, Python PEP 668=venv/uv 필수, Hermes config 직접수정 ❌ `config edit`.

**L1 인덱스** (X 함정 → `topics/X.md`): 코딩미션 v4.0 → coding-mission-v4.md / execute_code BLOCKED heredoc → execute-code-blocked.md / Vercel alias 슬롯 + -nu → vercel-alias-slots.md / ad-hoc verify `git ls-files` stdout 비교 → adhoc-verify-assertions.md / toss-trader fix 3건 → toss-trader-fix3.md / Hermes Desktop + 텔레 단일IP 트랩 → hermes-desktop-and-tele-workers.md / 보안 토큰평문금지 + kakao-timeline 폐기 → security-no-plaintext-tokens.md / NotebookLM 후보 DB 사망 + 위임선호 → notebooklm-fallback.md.

**자주 만나는 함정 1줄**: LLM Wiki = 수동호출만 (`~/wiki/` 조회, 자동주입/RAG 거부) / GitHub API anon 60/h → graceful-degrade = `gh api` (OAuth) + 로컬 SHA / **MEMORY.md 두 개 함정**: `~/.hermes/memories/MEMORY.md` 만 시스템 주입 소스, 다른 두 개(`~/.hermes/MEMORY.md`, `~/.hermes/memory/MEMORY.md`)는 보조 — 정리 잘못하면 정작 주입 메모리 그대로 남음.
```

## 핵심 교훈 (다음 세션에)

### 1. `§` 구분자 = 별도 entry

L0에 `§\n\n<entry>` 패턴으로 22개 항목이 있으면 `memory` 도구는 `§`를 별도 entry로 인식. **`replace` 단일 호출은 사실상 사용 불가**.

→ batch operations (`remove` 12개 + `add` 1개) 한 번에.

### 2. 진짜 MEMORY.md = `~/.hermes/memories/` (복수형)

SKILL.md v1.0.1 표가 `~/.hermes/MEMORY.md` (단수형)을 진짜로 표기했는데 **실측은 복수형이 진짜**. 환경마다 다를 수 있어도, **시스템 프롬프트의 `MEMORY (xx% — X/4000)` 글자수와 일치하는 파일**을 `wc -m`으로 확인하는 게 결정적.

### 3. 매 세션 토큰 부하 -67%

L0 1,309자 → 매 세션 약 600 토큰. 22줄 다 넣었을 때 1,800 토큰 대비 **-67% 절감**. 매달 누적되면 12,000+ 토큰 누적 절감.

### 4. L1 토픽 = search_files로 즉시 fetch

```bash
search_files(pattern="alias", target="content", path="~/.hermes/memories/topics")
# → 1~3초, ~1,000자 토큰 추가
```

필요할 때만 fetch하니 **빈도 낮은 워크플로우 함정이 매 세션 부담 안 됨**.

## 후속 작업 (별도 세션 권장)

1. **2026-07-20** (7일 후): `_backup_old_md/` 94개 백업 `rm` 검토
2. **`daily-self-review` v1.0.13+**: cron push 정책에 L0 가드 (한도 80%+ 시 push 거부/압축 우선)
3. **`nightly-maintenance-workflow`**: 6개월 누적 후 3계층 정렬 cron 자동화
4. **다른 umbrella 적용 검토**: SKILL.md 비대해진 스킬 → SKILL.md (핵심) + `references/<topic>.md` (상세) 패턴

## 관련

- `~/.hermes/skills/automation/memory-hygiene/SKILL.md` v1.0.2 §A
- `~/.hermes/skills/automation/memory-hygiene/references/memory-batch-ops-trap-2026-07-06.md`
- `~/.hermes/memories/topics/*.md` (8개 L1 토픽)