# 외부 자동 patch 감지 + 진단 (2026-07-13 실측)

## 트리거

작업 중 `patch` 도구가 다음 경고 띄움:
```
_warning: /Users/mac/.hermes/skills/<skill>/SKILL.md was modified since you
last read it on disk (external edit or unrecorded writer). Re-read the file
before writing.
```

또는 `skill_manage action=patch`의 `_warning` 필드에 같은 메시지.

## 실측 타임라인 (2026-07-13)

| 시각 (KST) | 이벤트 |
|---|---|
| 06:00:02 | 내가 `2026-07-13-progressive-disclosure.md` 작성 (write_file) |
| 06:00:51 | `progressive-disclosure-3-tier-2026-07-13.md` 자동 생성 (외부) |
| 06:08 | `2026-07-13-delegation-pattern.md` 자동 생성 (외부) |
| 06:00~06:10 | SKILL.md references 목록 자동 patch (외부) |
| 작업 중 | 내가 patch 시도 → "외부 patch 감지" 경고 |

## 진단 절차

### 1단계: 의심 파일 메타 확인

```bash
ls -lt <file>.md  # 시간 정렬로 최근 변경 파일 확인
```

`06:00~06:10 KST` 패턴 = **daily-self-review 23:00 cron** 시그널.

### 2단계: cron 잡 정의 grep

```bash
# 새 파일명 패턴 grep
grep -rln "<new-file-pattern>" ~/.hermes/cron/ 2>/dev/null

# cron yaml/yml 정의만 (output/ 산출물 제외)
find ~/.hermes/cron -name '*.yaml' -o -name '*.yml' | \
  xargs grep -l "<keyword>" 2>/dev/null
```

### 3단계: 자동화 스크립트 grep

```bash
# scripts/ 폴더에서 SKILL.md 자동 patch 가능성
grep -l "SKILL.md\|references/" ~/.hermes/scripts/*.py 2>/dev/null
```

### 4단계: daily-self-review SKILL.md 패턴 확인

```bash
# SKILL.md 본문에 "references/..." 자동 위임 로직 있는지
grep -n "references/\|자동 patch\|자동 보강" \
  ~/.hermes/skills/automation/daily-self-review/SKILL.md
```

## 실측 결과 (2026-07-13)

| 주체 | 증거 |
|---|---|
| **`daily-self-review` v1.0.39** | cron 23:00 KST 매일 실행 (job ID `7c2b9a9be162`) |
| **`scripts/self_improve.py`** | `SKILLS_DIR / "automation" / "shiporslop-kr" / "SKILL.md"` 패턴 = 자동 patch 보유 |
| **`daily-self-review` SKILL.md** | 115줄에 "상세: `references/iss-088-memory-patch-bytes-increase.md`" 등 자동 위임 패턴 보유 |
| **`scripts/knowledge_search.py`** / `telegram_command_router.py` / `cron_self_healer.py` | SKILL.md 참조 후보 (grep 결과) |

## 처리 가이드

### 외부 patch가 정상 동작일 때 (이번 케이스)

```bash
# 1) 내 patch가 의도대로 들어갔는지 read_file로 확인
tail -10 ~/.hermes/skills/<skill>/SKILL.md

# 2) 외부 patch가 내 patch와 충돌 안 하면 그대로 진행
# 3) 중복 references 파일이 생겼으면 한쪽은 _decommission_2026-07/로 이동
```

**판단 기준**:
- 외부 patch가 **자동 정형화/패턴 추출** 목적 → ✅ 정상, 별도 처리 불필요
- 외부 patch가 **내 의도와 모순** → ❌ 두 patch 비교 후 사용자 확인

### 외부 patch가 비정상일 때

- cron 정의에 없는 패턴이 추가됨 → cron ID + 작성자 추적
- `~/.hermes/secrets/` 키 노출 의심 → 즉시 `hermes doctor --fix`
- SKILL.md 본문이 깨졌을 때 → git history에서 가장 최근 정상 버전 복구

## 명명 패턴으로 작성자 추정

| 패턴 | 추정 작성자 |
|---|---|
| `2026-XX-XX-<topic>.md` (날짜 prefix) | 사람 작성 (사용자/에이전트 세션) |
| `<topic>-<description>-2026-XX-XX.md` (설명 prefix) | 자동 생성 (cron/script) |
| `iss-XXX-<description>.md` | issue 추적 (memory-error-tracker 추정) |
| `<skill>-<topic>-YYYY-MM-DD.md` | daily-self-review 자동 패턴 |

## 메모리/스킬 업데이트 가이드

작업 중 외부 patch 발견 시:

1. **`patch` 도구 warning 받음** → 즉시 read_file로 실제 파일 확인
2. **외부 작성자 진단** (1~4단계 절차)
3. **내 patch 의도와 충돌 여부** 판단
4. **충돌 없음** → 진행, 충돌 있음 → 사용자 confirm 후 merge
5. **memory-hygiene SKILL.md §Pitfall**에 "외부 자동 patch 감지 + 진단" 항목 추가 (다음 세션 자동 학습)

## 관련

- SKILL.md §Pitfall — "외부 자동 patch 감지 + 진단 (2026-07-13 실측, NEW)"
- `references/2026-07-13-progressive-disclosure.md` (내가 작성, 4,143자) vs
  `references/progressive-disclosure-3-tier-2026-07-13.md` (자동 생성, 8,093자)
- `references/2026-07-13-delegation-pattern.md` (자동 생성, 3,859자)