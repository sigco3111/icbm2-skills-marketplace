# Self-Healer False Positive Patterns (2026-05-24)

## 问题现象
cron_self_healer.py의 APIError 패턴 감지가 허상 경보(false positive)를 발생시킴.

## 원인
패턴: `r"(?:api.*(?:error|401|403|429|500)|unauthorized)"`

파일 경로에 "401"이 포함된 경우:
- `~/.hermes/memory/notion-401-troubleshooting.md` → "401" 문자열이 경로에 존재
- 이런 파일 경로를 grep하면 APIError로 오탐

## 영향을 받는 Cron Jobs (가양성)
5개 잡이 동시에 "실패"로 표시되지만 jobs.json은 모두 "ok":
- 일일자기리뷰, Tistory 자동발행, 오전정보수집, 심야정비, 지식그래프, 뮤직비디오

## 확인 방법
```bash
grep -i "api.*error\|✅\|❌\|complete\|success" <job_output>.md
```
jobs.json의 실제 상태와 대조해야 함.

## 개선 가능 해결책
패턴에 `\b` (단어 경계) 추가:
```
r"\b(?:api.*(?:error|failed)|unauthorized|rate\s*limit)\b"
```

이렇게 하면 "notion-401-troubleshooting.md"의 "401"은 매칭되지 않음.

## 실제 vs 허상 구분
| 구분 | 기준 |
|------|------|
| 실제 실패 | jobs.json에 "status": "error" |
| 허상 (가양성) | jobs.json "ok", 하지만 grep에서 "401"/"403" 문자열 포함 |