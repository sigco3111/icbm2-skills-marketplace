---
name: cron-stale-triage
description: ICBM2 cron stale 알림 교차 검증 및 오/진报警 분류 스킬 — cron_error_monitor.py의 출력을 실제 출력 파일/스케줄 정의와 대조하여 허상 경보와 실제故障을 분류합니다.
version: 1.0.0
author: ICBM2
metadata:
  hermes:
    tags: [Automation, Cron, Troubleshooting, Monitoring]
---

# Cron Stale Alert Triage 스킬

## 개요

`cron_error_monitor.py`가 감지한 "stale" 알림은 실제故障이 아닌 경우가 많습니다. 이 스킬은 허상 경보(false positive)와 실제 문제를 교차 검증으로 분류하는 절차입니다.

## 트리거 조건

- `cron_error_monitor.py`의 결과에서 3개 이상 `critical` stale 알림이 발견되었을 때
- 매일 17:30 에러 모니터링 크론이 실행된 직후 (매일傍晚)
- `automation-healthcheck` 또는 `nightly-maintenance-workflow` 실행 중 stale 알림이 많을 때

## Step 1: 스크립트 실행

```bash
python3 ~/.hermes/scripts/cron_error_monitor.py
```

JSON 출력을 파싱:
- `alerts[].severity == "critical"` → stale 알림 수집
- `alerts[].type == "stale"` → 대부분 허상 경보 가능성 높음

## Step 2: jobs.json에서 스케줄 확인

```bash
python3 -c "
import json
with open('/Users/hjshin/.hermes/cron/jobs.json') as f:
    data = json.load(f)
jobs = data if isinstance(data, list) else data.get('jobs', [])
for j in jobs:
    print(f\"{j.get('schedule', '?')}: {j.get('name', j.get('id', '?'))} (id={j.get('id', '?')[:8]})\")
"
```

출력 예시:
```
0 22 * * *: 🔄 일일 자기 개선 리뷰 (id=5d0f14ae)       ← 하루 1회
30 3 * * *: 🔄 Git 자동 동기화 (통합) (id=5a376ec0)    ← 하루 1회
0 19,20,21,22,0,1,2,3,4,5,6 * * *: 📝 Tistory 자동 발행 (id=b1bca63a) ← 다회
```

## Step 3: 교차 검증 — 실제 출력 파일 확인

**STALE 경과 시간 vs 스케줄 빈도로 분류:**

| 스케줄 패턴 | stale 경과 | 판정 기준 |
|-------------|-----------|-----------|
| 하루 1회 (예: `0 22 * * *`) | > 6h stale | ✅ 정상 (다음 날 실행预定) |
| 하루 다회 (예: `0 19,20... * * *`) | > 예정 간격 | ❌ 진짜 문제 가능 |
| 매일 03:30 실행 | 14h+ stale | ⚠️ 同时刻実行の別のジョブ тоже stale → gateway scheduling问题可疑 |

**실제 마지막 실행 시간 확인:**

```bash
for job_id in <stale_job_ids>; do
  dir=~/.hermes/cron/output/$job_id
  if [ -d "$dir" ]; then
    latest=$(ls -t "$dir"/*.md 2>/dev/null | head -1)
    if [ -n "$latest" ]; then
      echo "=== $job_id ==="
      ls -la "$latest"
      echo "Run Time: $(head -6 "$latest" | grep 'Run Time' | head -1)"
    fi
  fi
done
```

**output 파일 Run Time 헤더와 jobs.json 스케줄 대조:**
- Run Time이 "오늘 예정 시간"과 일치 → ✅ 정상 실행됨 (stale은スクリプトの閾値設定の問題)
- Run Time이 "오늘预定"인데 파일 없음 → ❌ 오늘 scheduled missed (실제 문제)
- Run Time이 "어제"인데 오늘预定 → ✅ 정상 (아직 오늘预定 시간이 안 됨)

## Step 4: 실제 문제 분류

### ❌ 진짜 문제 — 즉각 대응 필요

1. **gateway 스케줄러 블랙홀:** 여러 잡이 같은 시간에 연속 stale → gateway 재시작 필요
   ```bash
   systemctl --user restart hermes-gateway
   ```

2. **단일 잡 오늘 scheduled missed:** jobs.json에는 등록되어 있는데 오늘 output 파일이 없음
   → 수동 실행 또는 gateway 상태 확인

3. **Notion DB 404:** output 파일에서 API 404 에러 발견 → DB ID 확인/업데이트

### ✅ 허상 경보 — 조치 불필요

1. **하루 1회 잡이 6h+ stale:** STALE_THRESHOLD_HOURS=6이 aggressive. 스크립트 자체는 정상
2. **동일 시간대에 여러 잡이 같은 정도로 stale:** gateway 재시작 후 복구 확인 (guardian pattern)
3. **출력 파일 정상:** Run Time이 오늘预定 시간과 일치하면 → stale는 false positive

## Step 5: 보고 형식

주인님께 보고 시:

```
🚨 [ICBM2 에러 모니터링 리포트 — {날짜}]

총 {N}개 크론 잡 중 {X}개 CRITICAL, {Y}개 정상

⚠️ 주의: 대부분은 허상 경보입니다
| 잡 | 스케줄 | 최근 실행 | 경과 | 판정 |
|----|--------|-----------|------|------|
| ... | ... | ... | ... | ✅/❌ |

🔴 진짜 문제:
1. {잡명} — {간단한 설명}
   → {조치}

✅ 정상 작동 중:
- {잡명1}
- {잡명2}
```

## 핵심 인사이트

### 왜 STALE_THRESHOLD_HOURS=6이 문제인가

`cron_error_monitor.py`의 `STALE_THRESHOLD_HOURS=6`은 **하루 다회 실행 잡**을 위해 설계됨.
하루 1회 잡(`0 22 * * *`)은 실행 후 약 24시간이 경과 → 무조건 6h threshold 초과 → 매번 stale 알림.

→ 이 패턴을 인식하면 "10개 critical"이라는吓人の 숫자가 실제로는 1~2개 이하의 진짜 문제로 줄어듦.

### 게이트웨이 재시작이 필요한 흔한 패턴

| 증상 | 원인 |
|------|------|
| 매일 03:30 잡 2개가 동시에 stale | 같은 시간대 gateway가 스케줄 처리를 건너뜀 |
| 17:30 에러 모니터링만 계속 missed | 자기 자신이 블랙홀에 빠짐 |
| 특정 시간대 모든 잡이 순차적 stale | gateway 프로세스hung/再起動 필요 |

## 관련 스킬

- `automation-healthcheck` — 수동/full healthcheck (이 스킬보다 넓은 범위)
- `nightly-maintenance-workflow` — 03:30 자동 정비 (이 스킬은 triage 전용)
- `memory-error-tracker` — 출력 파일 실제 에러 스캔 (이 스킬의 후속)
