---
name: cron-stale-triage
description: ICBM2 cron stale 알림 교차 검증 및 오/진报警 분류 스킬 — cron_error_monitor.py의 출력을 실제 출력 파일/스케줄 정의와 대조하여 허상 경보와 실제故障을 분류합니다.
version: 1.1.0
author: ICBM2
metadata:
  hermes:
    tags: [Automation, Cron, Troubleshooting, Monitoring]
  last_updated: 2026-05-13
  change_summary: "스케줄 파싱 버그(모든 cron이 * * *를 含므로 false positive 폭증) 수정 반영 + stale severity 구분 로직 추가"
---

# Cron Stale Alert Triage 스킬

## 개요

`cron_error_monitor.py`가 감지한 "stale" 알림은 실제故障이 아닌 경우가 많습니다. 이 스킬은 허상 경보(false positive)와 실제 문제를 교차 검증으로 분류하는 절차입니다.

## ⚠️ CRITICAL: 스크립트 버그 기억 (2026-05-13 수정)

**`cron_error_monitor.py`의 스케줄 파싱 로직에严重的 버그가 있었음이 발견됨:**

```python
# ❌ WRONG — 이 패턴은 모든 cron 표현식에 매칭됨 (* * *은 모든 cron의 일부)
elif "* * *" in schedule_str:
    expected_hours = 2
```

모든 cron 표현식은 `* * *`를 含므로, 이 조건은 **모든 잡**을 `expected_hours=2`로 설정했습니다.
결과: 하루 1회 잡(`0 22 * * *`)이 19시간 후에도 "critical stale"로 표시되는 거짓 경보가 발생.

**올바른 파싱 (수정됨):**

```python
# ✅ Cron 5개 필드를 직접 파싱
cron_parts = schedule_str.split()
if len(cron_parts) >= 5:
    minute, hour, dom, month, dow = cron_parts[0], cron_parts[1], cron_parts[2], cron_parts[3], cron_parts[4]
    if all(p == "*" for p in [minute, hour, dom, month, dow]):
        expected_hours = 0.1       # Every minute
    elif hour == "*" and dom == "*" and month == "*" and dow == "*":
        expected_hours = 2          # Every hour at MM minutes
    elif "-" in hour or "," in hour:
        expected_hours = 12         # Hour range: multiple runs per day
    elif dom == "*" and month == "*" and dow == "*":
        expected_hours = 48         # ✅ Daily job — give 48h leeway
    elif dow != "*":
        expected_hours = 168        # Weekly job
    else:
        expected_hours = 48
```

**수정 전 symptoms (모두 false positive):**
- daily jobs → "critical stale" after 19h
- multi-run daily jobs → "critical stale" after 8h
- total: 9 critical alerts, 실제 문제: 0개

**수정 후:**
- 0 critical, 5 warning, 13 ok (실제 상태와 일치)

### 버그 발견 경로

```
1. 스크립트가 9개 critical stale 알림 출력
2. hermes cron list → 전원 last_status=ok (실제 정상)
3. jobs.json의 last_run_at과 schedule 교차 검증 → 전원 정상 실행 완료
4. 스크립트의 schedule 파싱 로직 검사 → elif "* * *" 버그 발견
5. fix 적용 → alerts 배열이 []로 전환 (정상)
```

## 트리거 조건

- `cron_error_monitor.py`의 결과에서 3개 이상 `critical` stale 알림이 발견되었을 때
- 매일 17:30 에러 모니터링 크론이 실행된 직후 (매일傍晚)
- `automation-healthcheck` 또는 `nightly-maintenance-workflow` 실행 중 stale 알림이 많을 때

## Step 1: 스크립트 실행

```bash
python3 ~/.hermes/scripts/cron_error_monitor.py
```

JSON 출력을 파싱:
- `alerts[].severity == "critical"` → 즉시 대응 필요 (이것은 **실제 실패**를 의미해야 함)
- `alerts[].type == "stale"` → 대부분 허상 경보 가능성 높음 (스케줄 파싱 버그 또는 정상 지연)
- `summary.critical == 0`이고 `summary.warning`만 있음 → 시스템 정상, 조치 불필요

**⚠️ critical이 많을 때 첫 번째 행동:** 항상 `hermes cron list`로 교차 검증하세요. 스크립트의 schedule 파싱에 버그가 있을 수 있습니다 (위 참고).

## Step 2: hermes cron list로 교차 검증

```bash
hermes cron list
```

**모든 잡이 `last run: ok`인데 critical stale 알림이 많으면 → 스크립트의 스케줄 파싱 버그可疑.**
이 때는 `cron_error_monitor.py`의 `check_staleness()` 함수의 `expected_hours` 계산 로직을 점검하세요.

## Step 3: jobs.json에서 스케줄 빈도 확인 (버그 검증용)

```bash
python3 -c "
import json
with open('/Users/hjshin/.hermes/cron/jobs.json') as f:
    data = json.load(f)
jobs = data if isinstance(data, list) else data.get('jobs', [])
for j in jobs:
    sched = j.get('schedule', {})
    expr = sched.get('expr', sched) if isinstance(sched, dict) else str(sched)
    print(f'{expr}: {j.get(\"name\", \"?\")} (id={j.get(\"id\", \"?\")[:8]})')"
```

**핵심:** 매일 1회 잡(`0 22 * * *`, `30 3 * * *` 등)은 48시간이 기준. 24시간 후 "stale"으로 뜨는 것은 **버그 또는 정상**.

## Step 4: 실제 마지막 실행 시간 확인

```bash
for job_id in <stale_job_ids>; do
  dir=~/.hermes/cron/output/$job_id
  if [ -d "$dir" ]; then
    latest=$(ls -t "$dir"/*.md 2>/dev/null | head -1)
    if [ -n "$latest" ]; then
      echo "=== $job_id ==="
      ls -la "$latest"
      echo "Run Time: $(head -6 "$latest" | grep 'Run Time' | head -1)"
    fi
  fi
done
```

**output 파일 Run Time 헤더와 jobs.json 스케줄 대조:**
- Run Time이 "오늘 예약 시간"과 일치 → ✅ 정상 실행됨 (stale은 스크립트의 스케줄 해석 문제)
- Run Time이 "오늘预定"인데 파일 없음 → ❌ 오늘 scheduled missed (실제 문제)
- Run Time이 "어제"인데 오늘预定 → ✅ 정상 (아직 오늘预定 시간이 안 됨)

## Step 5: 실제 문제 분류

### ❌ 진짜 문제 — 즉각 대응 필요

1. **gateway 스케줄러 블랙홀:** 여러 잡이 같은 시간에 연속 stale → gateway 재시작 필요
   ```bash
   systemctl --user restart hermes-gateway
   ```

2. **단일 잡 오늘 scheduled missed:** jobs.json에는 등록되어 있는데 오늘 output 파일이 없음
   → 수동 실행 또는 gateway 상태 확인

3. **Notion DB 404:** output 파일에서 API 404 에러 발견 → DB ID 확인/업데이트

4. **연속 3회+ 실제 실패:** 스크립트 출력의 `last_status != "ok"` + 출력 내용에 실제 에러 키워드

### ✅ 허상 경보 — 조치 불필요 ( Silent )

1. **모든 잡이 `last_status=ok`인데 critical stale:** → `cron_error_monitor.py`의 schedule 파싱 버그 → 스크립트 fix 필요
2. **daily job이 24h+ stale:** → `expected_hours` 계산 오류 (daily는 48h 필요)
3. **동일 시간대에 여러 잡이 같은 정도로 stale:** → gateway 재시작 후 복구 확인 (guardian pattern)
4. **출력 파일 정상:** Run Time이 오늘预约 시간과 일치하면 → stale는 false positive

## Step 6: 보고 형식

**alerts 배열이 비어있으면 → [SILENT] (아무것도 전송하지 말 것)**

실제 문제가 있을 때만 보고:

```
🚨 [ICBM2 에러 모니터링 리포트 — {날짜}]

총 {N}개 크론 잡 중 {X}개 CRITICAL, {Y}개 정상

⚠️ 주의: 대부분은 허상 경보입니다
| 잡 | 스케줄 | 최근 실행 | 경과 | 판정 |
|----|--------|-----------|------|------|
| ... | ... | ... | ... | ✅/❌ |

🔴 진짜 문제:
1. {잡명} — {간단한 설명}
   → {조치}

✅ 정상 작동 중:
- {잡명1}
- {잡명2}
```

## 핵심 인사이트

### stale severity 구분

| 상황 | severity | 의미 |
|------|----------|------|
| 실제 연속 실패 3회+ | `critical` | 即時通報 |
| 출력에 실제 에러 | `critical` | 即時通報 |
| 스크립트 버그로 false positive | `warning` | 조치 불필요 |
| daily job이稍退 | `warning` | 정상 |
| 연속 실패 1~2회 | `warning` | 모니터링 |

**원칙:** `critical`은 **실제 작업 실패**에만. 단순 지연이나 스크립트 버그는 `warning`.

### 게이트웨이 재시작이 필요한 흔한 패턴

| 증상 | 원인 |
|------|------|
| 매일 03:30 잡 2개가 동시에 stale | 같은 시간대 gateway가 스케줄 처리를 건너뜀 |
| 17:30 에러 모니터링만 계속 missed | 자기 자신이 블랙홀에 빠짐 |
| 특정 시간대 모든 잡이 순차적 stale | gateway 프로세스hung/再起動 필요 |

### 버그 발견 시立即修复

`cron_error_monitor.py`의 버그로 false positive가 발생하면:
1. 버그를 고치고
2. 다시 스크립트 실행해서 alerts=[] 확인 후
3. 보고는 "버그 발견 → 수정 완료, 시스템 정상"으로 간결하게

**절대** "9개 critical → 수정 후 0개"라고 상세히 보고하지 마세요 (주인님이 불필요하다고 인식할 수 있음).

## 관련 스킬

- `automation-healthcheck` — 수동/full healthcheck (이 스킬보다 넓은 범위)
- `nightly-maintenance-workflow` — 03:30 자동 정비 (이 스킬은 triage 전용)
- `memory-error-tracker` — 출력 파일 실제 에러 스캔 (이 스킬의 후속)
