---
name: design-artifacts
description: Design work for the agent — three coordinated skills under one umbrella. **claude-design** drives the process (scoping, variants, taste, avoiding AI slop) for one-off HTML artifacts. **popular-web-designs** supplies ready-made visual vocabularies for known brands (Stripe, Linear, Vercel, Notion, etc.). **design-md** handles the formal design-token spec file (Google's DESIGN.md format with WCAG, Tailwind, DTCG export). Pick the section that matches the deliverable.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [design, HTML, design-system, tokens, ui, prototype, ux, creative, claude-design, popular-web-designs, design-md, WCAG, tailwind, DTCG]
---

# Design Artifacts

Three coordinated skills for design work in a CLI/API agent. They do different jobs — load the right one (or combine them) based on what the user actually wants.

| Section | What it gives you | Use when the user wants... |
|---|---|---|
| **[§1 Claude Design](#1-claude-design-process--taste)** | Design *process and taste* — scoping, variants, avoiding AI slop | a from-scratch designed artifact (landing page, prototype, deck, motion study) with no specific brand or token system dictated |
| **[§2 Popular Web Designs](#2-popular-web-designs-brand-lookalikes)** | 54 ready-to-paste design systems — exact colors, typography, components for Stripe, Linear, Vercel, Notion, etc. | "make it look like Stripe/Linear/Vercel", a page styled after a known brand, or a visual starting point pulled from a real product |
| **[§3 DESIGN.md](#3-designmd-design-token-spec)** | Google's DESIGN.md spec format — author/validate/diff/export design-token files with WCAG contrast checking, Tailwind/DTCG export | a formal, persistent, machine-readable design-system *spec file* (tokens + rationale) that lives in a repo and gets consumed by agents over time |

**Composition rule:** `popular-web-designs` for the visual vocabulary + `claude-design` for the process = good combo. `design-md` is for when the deliverable is the spec file, not a rendered artifact.

---

## 1. Claude Design (Process + Taste)

Use this for one-off HTML design artifacts — landing pages, prototypes, decks, component labs, motion studies. The goal: preserve Claude Design's useful design behavior and taste while removing hosted-tool plumbing that doesn't exist in normal agent environments.

### 1.1 When to use

- landing pages, teaser pages, prototypes, mockups
- design option boards, component explorations
- HTML slide decks (1920×1080)
- design system previews (rendered)
- motion studies
- redesigns based on screenshots, repos, brand docs, UI kits
- flow redesigns (UX, interaction, dashboard, settings, command palettes, modals, cards, forms, empty states)

### 1.2 When NOT to use

- Pure DESIGN.md token authoring → use §3
- Match a known brand's look → use §2 (and let §1 drive the process)
- File edits in a real repo → use `read_file` / `write_file` / `patch`
- Web automation → use `browser_*` tools, not type-into-browser

### 1.3 Core identity

HTML is the default tool, but the medium changes by assignment:

- UX designer for flows and product surfaces
- interaction designer for prototypes
- visual designer for static explorations
- motion designer for animated artifacts
- deck designer for presentations
- design-systems designer for tokens, components, visual rules
- frontend-minded prototyper when code fidelity matters

Act as an expert designer. The user is the manager.

### 1.4 Start from context, not vibes

Before designing, look for source context: brand docs, existing product screenshots, current repo components, design tokens, UI kits, prior mockups, reference models, copy docs, constraints. If a repo is available, inspect actual source files (theme/token/global style/component files) before inventing UI.

### 1.5 Asking questions

Ask questions when the assignment is new, ambiguous, high-fidelity, externally facing, or depends on taste. Usually ask for:

- intended output format
- audience
- fidelity level
- source materials available
- brand/design system in play
- number of variations
- conservative vs divergent
- which dimension matters most: layout, visual language, interaction, copy, motion, systemization

Skip questions when: the user gave enough direction, small tweak, clear continuation, or the missing detail has an obvious default.

### 1.6 Workflow

1. **Understand the brief** — what, who, deliverable, constraints
2. **Gather context** — read docs, screenshots, repo files, design assets
3. **Define the design system for this artifact** — colors, type, spacing, radii, shadows, motion, components, interactions
4. **Choose the right format** — static visual comparison / interaction & flow / presentation deck / component lab / motion
5. **Build** — single self-contained HTML file (or repo implementation if applicable)
6. **Verify** — file exists, syntax OK, open in browser, check console errors
7. **Report briefly** — file path, what was created, caveats, next iteration

### 1.7 Artifact format rules

For standalone artifacts:

- descriptive filename: `Landing Page.html`, `Command Palette Prototype.html`
- embedded CSS in `<style>`, JS in `<script>`
- openable directly in a browser
- avoid remote dependencies unless explicitly useful and stable
- responsive behavior unless format is intentionally fixed

For significant revisions, preserve previous as `Name.html`, create `Name v2.html`, etc.

For repo implementation, follow the repo's actual stack and use existing components.

### 1.8 HTML/CSS/JS standards

Use modern CSS well: CSS variables for tokens, CSS grid for layout, container queries, `text-wrap: pretty`, real focus + hover states, `prefers-reduced-motion`, responsive scaling, semantic HTML.

Mobile hit targets ≥ 44px. Print documents ≥ 12pt. 1920×1080 slides ≥ 24px text.

Avoid: huge monolithic files when a real repo structure is expected, fragile hard-coded viewport assumptions, inaccessible tiny hit targets, decorative JS that fights usability, `scrollIntoView` unless no safer option.

### 1.9 React guidance (for standalone HTML)

Use plain HTML/CSS/JS by default. Use React only when: meaningful state, variants/toggles are easier as components, interaction complexity warrants it, or target implementation is React/Next.js.

If using React from CDN: pin exact versions, avoid unpinned `react@18` URLs, avoid `type="module"` unless necessary, avoid multiple global `styles` objects, attach shared components to `window` explicitly.

### 1.10 Deck rules

For slide decks, fixed-size canvas scaling to fit viewport. Default 1920×1080 16:9.

Requirements: keyboard navigation, visible slide count, localStorage persistence for current slide, print-friendly layout, stable IDs for important slides, no speaker notes unless asked.

Use 1-2 background colors max. Sparse slides — solve with layout/rhythm/scale/imagery placeholders, not filler text.

### 1.11 Prototype rules

Make the primary path clickable. Include key states (default, hover/focus, loading, empty, error, success). Expose variations with in-page controls. Persist important state in localStorage.

### 1.12 Variation rules (for exploration)

Default to 3 options:

1. **Conservative** — closest to existing patterns / lowest risk
2. **Strong-fit** — best interpretation of the brief
3. **Divergent** — more novel, useful for discovering taste boundaries

Variations can explore: layout, hierarchy, type scale, density, color, surface, motion, interaction, copy, component shape. Don't create color-swap-only variations.

### 1.13 Tweaks panel (CLI/API mode)

The hosted edit-mode toolbar doesn't exist here. Add an in-page `Tweaks` panel for theme, layout, density, accent, type scale, motion on/off, copy variant, component variant. Keep it small and unobtrusive. Persist with localStorage.

### 1.14 Content discipline

No filler content. No fake metrics, decorative stats, generic feature grids, unnecessary icons, placeholder testimonials, AI-generated fluff sections, invented content that changes strategy or claims.

If additional sections/copy would help, ask before adding. When copy is not final, mark as draft or placeholder.

### 1.15 Anti-slop rules

Avoid common AI design sludge:

- aggressive gradient backgrounds
- glassmorphism by default
- emoji unless brand uses them
- generic SaaS cards with icons everywhere
- left-border accent callout cards
- fake dashboards with arbitrary numbers
- stock-photo hero sections
- oversized rounded rectangles as substitute for hierarchy
- rainbow palettes
- vague labels ("Insights," "Growth," "Scale," "Optimize") without content
- decorative SVG illustrations pretending to be product imagery

### 1.16 Typography

Use existing type system if one exists. If not, choose deliberately:

- **editorial** — serif/humanist headline + restrained sans body
- **software/productivity** — precise sans + strong numeric treatment
- **luxury/minimal** — fewer weights, more spacing discipline
- **technical** — mono accents only, not mono everywhere
- **deck** — large, clear, high contrast

Use type as hierarchy before adding boxes, icons, or color.

### 1.17 Color

Brand/design-system colors first. If no palette, define a small system: neutrals, surface, ink, muted text, border, accent, danger/success. Use one primary accent unless broader palette is required. Prefer oklch for harmonious invented palettes.

### 1.18 Motion

Motion as discipline, not theater. Good motion clarifies state changes, reduces loading anxiety, shows continuity, gives controls tactility, stays subtle. Bad motion loops without purpose, delays the user, calls attention to itself, hides poor hierarchy.

Respect `prefers-reduced-motion`.

### 1.19 Source-code fidelity

When recreating/ extending a UI from a repo: inspect the repo tree, identify the actual UI source files, read theme/token/global style/component files, lift exact values, match spacing/radii/shadows/copy tone/density/interaction, only then design or modify.

### 1.20 Copyright and reference models

Don't recreate a company's distinctive UI, proprietary command structure, branded screens, or exact visual identity unless the user has rights to that source. Acceptable to extract general principles (density, command-first, monochrome with accent, editorial hierarchy, empty states, keyboard affordances).

### 1.21 Verification

Before final response, verify as much as the environment allows.

Minimum: file exists, HTML is saved completely, obvious syntax checked.

Better: open in a browser tool and check console errors, inspect screenshots, test key interactions, test light/dark variants, test responsive breakpoints.

If verification is limited by environment, say exactly what was and was not verified. Never say "done" if the file wasn't actually written.

### 1.22 Final response format

Keep short. Include: artifact path, what it contains, verification status, next suggested action.

Example:

```
Created: /path/to/Prototype.html
It includes 3 layout variants, a Tweaks panel for density/theme, and responsive behavior.
Verified: file exists and opened cleanly in browser, no console errors.
Next: pick the strongest direction and I'll tighten copy + motion.
```

---

## 2. Popular Web Designs (Brand Lookalikes)

For matching a known brand's visual vocabulary. **54 ready-to-paste design systems** with exact colors, typography, components, CSS values for sites like Stripe, Linear, Vercel, Notion, Airbnb.

### 2.1 When to use

- "make it look like Stripe / Linear / Vercel / Notion"
- a page styled after a known brand
- a visual starting point pulled from a real product
- when the user has named a brand and wants its look applied

### 2.2 When NOT to use

- For purely visual inspiration or layout examples when no brand is named → use a different inspiration approach
- For *process and taste* when designing a from-scratch artifact → use §1 (and load §2 alongside for visual vocabulary)
- For a formal token spec file → use §3

### 2.3 Composing with Claude Design

These two compose well: use §1 to drive the process (intake, variants, verify), and use §2 to supply the visual vocabulary. Avoid the anti-slop rules in §1 even when matching a brand.

### 2.4 Pick by attribute, not by index

When the user says "make it look like Notion" but the actual deliverable is a focused single-task tool, "Notion" might be the wrong brand — the *attribute* "warm, content-first, low-chrome" is what they want. Match by attribute, then suggest the closest brand.

Common attribute-to-brand mappings:

- **Precise / tool-like / monochrome with one accent** → Linear, Vercel
- **Friendly / content-first / soft** → Notion, Stripe (consumer)
- **Dense / professional / data** → Bloomberg, FT, Stripe (dashboard)
- **Editorial / publication** → NYT, Substack
- **Playful / illustrative** → Mailchimp, Headspace

### 2.5 Specific brand constraints

When applying a brand, do not:

- Recreate their distinctive UI verbatim (copyright + ethics)
- Use their exact logo or trademarks in derivative work
- Imply official association

Transform the posture and principles into an original design that follows the same vocabulary.

---

## 3. DESIGN.md (Design Token Spec)

Google's open spec (Apache-2.0, `google-labs-code/design.md`) for describing a visual identity to coding agents. One file combines:

- **YAML front matter** — machine-readable design tokens (normative values)
- **Markdown body** — human-readable rationale, organized into canonical sections

Tokens give exact values. Prose tells agents *why* those values exist and how to apply them. The CLI (`npx @google/design.md`) lints structure + WCAG contrast, diffs versions, and exports to Tailwind or W3C DTCG JSON.

### 3.1 When to use

- User asks for a DESIGN.md file, design tokens, or a design system spec
- User wants consistent UI/brand across multiple projects
- User pastes an existing DESIGN.md and asks to lint, diff, export, or extend
- User wants to port a style guide into a format agents can consume
- User wants WCAG accessibility validation on their color palette

### 3.2 When NOT to use

- For purely visual inspiration or layout examples → use §2 or §1
- For one-off HTML artifacts (landing pages, prototypes) → use §1
- For a *rendered* design preview → use §1

### 3.3 File anatomy

```md
---
version: alpha
name: Heritage
description: Architectural minimalism meets journalistic gravitas.
colors:
  primary: "#1A1C1E"
  secondary: "#6C7278"
  tertiary: "#B8422E"
  neutral: "#F7F5F2"
typography:
  h1:
    fontFamily: Public Sans
    fontSize: 3rem
    fontWeight: 700
    lineHeight: 1.1
    letterSpacing: "-0.02em"
  body-md:
    fontFamily: Public Sans
    fontSize: 1rem
rounded: { sm: 4px, md: 8px, lg: 16px }
spacing: { sm: 8px, md: 16px, lg: 24px }
components:
  button-primary:
    backgroundColor: "{colors.tertiary}"
    textColor: "#FFFFFF"
    rounded: "{rounded.sm}"
    padding: 12px
---

## Overview
Architectural Minimalism meets Journalistic Gravitas...

## Colors
- **Primary (#1A1C1E):** Deep ink for headlines and core text.
- **Tertiary (#B8422E):** "Boston Clay" — the sole driver for interaction.

## Typography
Public Sans for everything except small all-caps labels...

## Components
`button-primary` is the only high-emphasis action on a page...
```

### 3.4 Token types

| Type | Format | Example |
|---|---|---|
| Color | `#` + hex (sRGB) | `"#1A1C1E"` |
| Dimension | number + unit (`px`, `em`, `rem`) | `48px`, `-0.02em` |
| Token reference | `{path.to.token}` | `{colors.primary}` |
| Typography | object with `fontFamily`, `fontSize`, `fontWeight`, `lineHeight`, `letterSpacing`, `fontFeature`, `fontVariation` | |

Component property whitelist: `backgroundColor`, `textColor`, `typography`, `rounded`, `padding`, `size`, `height`, `width`. Variants (hover, active, pressed) are separate component entries with related key names (`button-primary-hover`), not nested.

### 3.5 Canonical section order

Sections optional but must appear in this order (duplicates reject the file):

1. Overview (alias: Brand & Style)
2. Colors
3. Typography
4. Layout (alias: Layout & Spacing)
5. Elevation & Depth (alias: Elevation)
6. Shapes
7. Components
8. Do's and Don'ts

Unknown sections preserved. Unknown token names accepted if value type valid. Unknown component properties produce warning.

### 3.6 Workflow: authoring a new DESIGN.md

1. Ask the user (or infer) brand tone, accent color, typography direction
2. Write `DESIGN.md` in project root using `write_file`. Always include `name:` and `colors:`
3. Use token references (`{colors.primary}`) in `components:` instead of re-typing hex
4. Lint it (see §3.7). Fix broken references or WCAG failures before returning.
5. If the user has an existing project, also write Tailwind or DTCG exports next to the file (`tailwind.theme.json`, `tokens.json`).

### 3.7 Workflow: lint / diff / export

CLI: `@google/design.md` (Node). Use `npx` — no global install.

```bash
# Validate structure + token references + WCAG contrast
npx -y @google/design.md lint DESIGN.md

# Compare two versions, fail on regression (exit 1 = regression)
npx -y @google/design.md diff DESIGN.md DESIGN-v2.md

# Export to Tailwind theme JSON
npx -y @google/design.md export --format tailwind DESIGN.md > tailwind.theme.json

# Export to W3C DTCG (Design Tokens Format Module) JSON
npx -y @google/design.md export --format dtcg DESIGN.md > tokens.json

# Print the spec itself — useful when injecting into agent prompt
npx -y @google/design.md spec --rules-only --format json
```

All commands accept `-` for stdin. `lint` returns exit 1 on errors.

### 3.8 Lint rules (what the 7 rules catch)

- `broken-ref` (error) — `{colors.missing}` points at non-existent token
- `duplicate-section` (error) — same `## Heading` appears twice
- `invalid-color`, `invalid-dimension`, `invalid-typography` (error)
- `wcag-contrast` (warning/info) — component `textColor` vs `backgroundColor` ratio against WCAG AA (4.5:1) and AAA (7:1)
- `unknown-component-property` (warning) — outside the whitelist

When the user cares about accessibility, call this out explicitly — WCAG findings are the most load-bearing reason to use the CLI.

### 3.9 Starter template

`templates/design-md-starter.md` (in this skill's `templates/` directory) is a complete starter.

### 3.10 Pitfalls

- **Don't nest component variants.** `button-primary.hover` is wrong; `button-primary-hover` as a sibling key is right.
- **Hex colors must be quoted strings.** YAML will otherwise choke on `#` or truncate values like `#1A1C1E` oddly.
- **Negative dimensions need quotes too.** `letterSpacing: -0.02em` parses as a YAML flow — write `letterSpacing: "-0.02em"`.
- **Section order is enforced.** If the user gives prose in random order, reorder to canonical.
- **`version: alpha` is current spec** (as of Apr 2026). Spec is marked alpha — watch for breaking changes.
- **Token references resolve by dotted path.** `{colors.primary}` works; `{primary}` does not.

### 3.11 Spec source of truth

- Repo: https://github.com/google-labs-code/design.md (Apache-2.0)
- CLI: `@google/design.md` on npm
- License of generated DESIGN.md files: whatever the user's project uses; the spec itself is Apache-2.0

---

## Reference Files

- `templates/design-md-starter.md` — complete DESIGN.md starter template
