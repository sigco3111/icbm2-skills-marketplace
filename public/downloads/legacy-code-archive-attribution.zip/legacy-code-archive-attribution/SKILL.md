---
name: legacy-code-archive-attribution
description: "레거시 코드 GitHub 백업 시 README attribution 처리 워크플로"
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [legacy, archive, attribution, copyright, readme, github]
    related_skills: [github-repo-management, tistory-publisher]
---

# Legacy Code Archive — Attribution Handling

**트리거:** 사용자가 레거시/오래된 소스를 GitHub에 백업/올리라고 지시하고, 원본 코드에 명시적 authorship·copyright·회사명 표기가 있을 때. **또는** "레거시 백업" 의도가 명시된 repo.

## 핵심 원칙 (희정님 기본 선호 — 2026-07-30 검증)

1. **원본 소스 코드는 절대 손대지 않는다** — 헤더 주석, 오타(`ReleseImage`, `DDCliper`), MSVC `#pragma warning`, euc-kr 인코딩 주석 모두 보존. 코드 자체는 박물관 조개처럼 다룬다.
2. **README/github-facing 문서에서 attribution 문자열을 제거한다** — 작성자 이름, 회사명, "Copyright (C) XXXX YYYY" 라인은 README/description에서 빼고 **소스 파일 헤더에 보존됨**을 안내만 한다.
3. **공개판이지만 redistribution license가 아니다** — 본 repo는 외부 공개를 위한 redistribute가 아니라 **history record**임을 README 첫 줄에 명시한다 (예: "🗄️ 레거시 백업 (YYYY-MM-DD 스냅샷) — 기록 보관본. 적극 개발 계획 없음").

## 왜 분리해야 하는가 (배경)

- **공개 = 외부에서 다운로드 가능**: github.com/foo/bar 링크를 포럼/이슈에 박으면 attribution이 부각됨
- **기록 = 본인 보관용**: sigco3111 같은 사용자 본인이 6개월 뒤에 찾으려고 두는 것
- 둘 다 GitHub에 올라가지만 **외부 인지도가 매우 다름**. 사용자가 "기록용이니까 일단 올려"라고 했을 때는 후자 의도. attribution 박지 않는 게 안전.

## 워크플로

### 1. 코드 진단

레거시 코드 4-5개 파일을 받으면 다음을 한 번에 추출:

```bash
# 원본 헤더 80줄 확인
head -80 <file1> <file2> ...

# attribution 단서 grep
grep -E '@ Name|@ Make|@ Version|@ Date|Copyright|@ Author' *.h *.c

# 회사/저작자 약자 추출 (예: E.A.S.T.V.I.L)
grep -E '\bE\.[A-Z]\.[S-Z]\.[T-Z]\.[V-Z]\.[I-Z]\.[L-Z]\b'
```

### 2. README 작성 시 attribution 분류

| 정보 종류 | 원본 헤더 | README/github-facing |
|----------|----------|-------------------|
| 엔진명 | 보존 | 그대로 사용 가능 (기술 식별자) |
| 버전 (3.1) | 보존 | 그대로 사용 가능 |
| 작성일 (2009-04-13) | 보존 | 그대로 사용 가능 |
| **작성자 이름** | 보존 | **제거** |
| **회사명** | 보존 | **제거** |
| **`Copyright (C) YYYY` 라인** | 보존 | **제거** |
| 함수 오타/주석 | 보존 | README에서는 무관 (코드 영역) |
| 알고리즘 (블렌드 매크로) | 보존 | README에서 설명 가능 (기법은 공지식) |

### 3. README 라이선스 섹션 패턴

원본 라이선스를 README에서 빼버리되, "보존됨" 안내는 박는다:

```markdown
## 📜 출처 / 라이선스

원본 저작자/저작권 표기는 **소스 파일 헤더 주석에만** 보존되어 있습니다. 본 리포지토리는 외부 공개를 전제로 한 배포본이 아니며, 원본 파일에 명시된 권리 표기를 따릅니다. 별도 라이선스 파일은 포함되어 있지 않습니다.
```

### 4. 푸시 후 검증

```bash
# 1) 로컬에서 0건 확인
grep -ic "EASTVIL\|Kim Jong Wook\|Shin Hee Jung\|E\\.A\\.S\\.T\\.V\\.I\\.L" README.md
# 2) 깃허브 README 디코딩 후 0건 확인
curl -s https://api.github.com/repos/<user>/<repo>/contents/README.md \
  | python3 -c "import sys,json,base64; print(len(re.findall(r'PATTERN', base64.b64decode(json.load(sys.stdin)['content']).decode())))"
```

## 실수 사례 (이번 세션에서 학습)

- **사용자가 "EASTVIL 관련 내용은 제거해줘"라고 명시**. 그 전까지 README에 박혀 있던 항목: 엔진명 표기의 EASTVIL prefix, 작성자 2명, `..E.A.S.T.V.I.L..` 회사명, "EASTVIL에 사용·재배포 조건 확인" 라이선스 문구. **사용자는 README 안 회사명을 원하지 않았고, 동시에 C 소스 헤더는 그대로 두길 원했음** — 이 분리가 핵심.
- 헷갈리면 안 되는 신호: 사용자가 "**README**에서" 라고 명시했으면 코드는 보존이 기본. 코드를 수정하면 외부 라이선스 위반이 됨.

## Preflight 질문 (사용자에게 짧게)

레거시 백업 작업 시작 시 다음 2개는 한 번에 받아두는 게 안전:

1. **공개 의도**: "외부 공개용 redistribution" vs "본인 기록용" — 일반 사용자가 '내 github에 일단 올려'라고 하면 후자. **명시 확인 안 받았으면 후자로 가정**.
2. **레포 이름**: 폴더명 그대로가 디폴트지만, 의미가 좁은 폴더명(`wipic_draw3_1` 같은 빌드 넘버) → 우아한 정리 이름 추천

## Pitfalls

- **attribution을 코드에서 지우면 라이선스 위반 가능**. README/github-facing만 정리하고, 원본 소스 헤더는 절대 수정하지 않는다.
- **회사명에 띄어쓰기 없는 대문자 약자가 등장하면 의심** — `E.A.S.T.V.I.L` 같은 패턴. 이런 표기는 README에서 한 번 더 grep으로 0건 확인할 것.
- **euc-kr 인코딩 헤더 주석** — Visual Studio 외 환경에서 깨져 보이지만 보존이 원칙.
- **원본 파일명 오타** — 함수가 외부에서 호출될 수 있는 심볼이면 절대 수정 금지 (`ReleseImage`, `DDCliper` 사례).
- **사용자 신호 vs 의도 혼동** — "EASTVIL 제거해줘"는 README 한정. 본인이 모든 컨텍스트를 잃었을 때 코드를 건드리는 사고로 이어질 수 있음. 명확치 않으면 멈추고 확인.

## 확장 패턴: 레거시 콘솔 SDK + 매뉴얼 HTM (2026-07-31 검증)

GP32 / 게임파크 / DS / PSP 같은 2000년대 임베디드 콘솔 프로젝트를 GitHub에 올릴 때 자주 등장하는 추가 결정 항목.

### 1. 닫힌 SDK / 툴체인 zip 제외

- **ADS (`ads.zip`)**, **GP32 SDK**, **NitroSDK**, **Metrowerks CodeWarrior** 등은 유료 라이선스. GitHub 공개 저장소에 그대로 포함하면 라이선스 위반.
- 처리: 작업 사본에서 zip을 삭제 + README에 "빌드하려면 SDK 별도 확보 필요" 명시.
- 같은 폴더에 같은 이름의 `*.h` 헤더만 있는 경우도 마찬가지로 라이선스 표시를 코드 헤더에 보존, README에는 "SDK 헤더는 원 SDK 라이선스 적용" 단서만.

### 2. Windows 작업 환경 `.lnk` 단축아이콘

- `__FxeMaker.lnk`, `__GPDevTool.lnk`, `__geepee32.lnk`, `make_zgotod.lnk` — 본인 PC의 작업 환경(시작메뉴/바탕화면 단축아이콘) 파일.
- 다른 PC에서 받아도 동작 안 함. 보안 위험은 없지만 노이즈.
- 권장: `.gitignore`에 `*.lnk` 추가. 사용자가 따로 보관하고 싶다면 README에 "작업 환경 단축아이콘은 원본에 그대로 보존됨" 안내.

### 3. Win32 / Visual C++ 6 빌드 산출물 일괄 제외

레거시 프로젝트에 흔한 항목들:

```gitignore
Debug/
Release/
debug/
release/
*.opt
*.plg
*.ncb
*.positions
*.obj
*.o
*.exe
*.pdb
*.idb
*.pch
*.sbr
*.bsc
*.res
*.ilk
*.tlog
BuildLog.htm
*.fxe
*.elf
*.gxb
*.lnk
```

`.dsp` / `.dsw` (VC6 프로젝트 파일)은 **삭제하지 않는다** — 현재 Visual Studio 2022에서 직접 열리진 않지만, 프로젝트 구조 보존 가치가 있음. README에 "VC6 포맷, 최신 VS에서는 직접 열리지 않음" 명시.

### 4. EUC-KR HTM 매뉴얼 디코딩

2000년대 한국어 매뉴얼은 대부분 EUC-KR로 인코딩되어 있고 Namo WebEditor로 작성됨. macOS/Linux의 `cat`/기본 툴로 읽으면 한글이 깨져서 `����`처럼 보임. 반드시 인코딩을 명시해서 읽어야 함:

```bash
# bash에서 직접 디코딩
iconv -f euc-kr -t utf-8 Azmanga_Main.htm | head -50

# Python으로 안전하게
python3 -c "
from pathlib import Path
text = Path('Azmanga_Main.htm').read_bytes().decode('euc-kr', errors='replace')
print(text[:500])
"
```

깨진 상태로 추측해서 README를 쓰면 게임명·개발자명·기간이 모두 틀어짐.

매뉴얼 HTML은 GitHub에서 직접 렌더링 안 되지만, README에 **이미지를 첨부해서 게임 화면을 보여주는 것**이 효과적. 매뉴얼 폴더(`manual/Azmanga_manual/Image/*.jpg` 등)를 작업 사본에 함께 복사한 뒤 README에 마크다운 이미지 링크로 임베드:

```markdown
| 화면 | 이미지 |
|---|---|
| 타이틀 | ![start](manual/Azmanga_manual/Image/start.jpg) |
| 메인 메뉴 | ![menu](manual/Azmanga_manual/Image/menu.jpg) |
```

매뉴얼 폴더명 자체가 잘못되어 있는 경우(`Azmanga_manual`인데 실제로는 부루마블대왕 매뉴얼)가 있으므로, `Setup.htm`/`rule.htm`의 내용을 직접 읽고 어떤 게임의 매뉴얼인지 판정한 후 README에 "폴더명은 작업 중 임시 라벨, 실제 게임은 X"라고 명시.

### 5. 작업 사본 폴더 분리 + 원본 보존 (2026-07-31)

- **원본(`/Users/mac/work/backup/...`)은 절대 수정/이동/삭제 금지.**
- 작업 사본 폴더 패턴:
  ```text
  /Users/mac/work/github/<repo-name>/   ← 작업 + 푸시
  /Users/mac/work/backup/...            ← 원본 (변경 없음)
  ```
- `cp -a`로 원본을 작업 사본에 복사 → 사본 안에서만 zip 삭제, .gitignore 적용, README 작성.

다만 사용자가 **"원본에 추가해"** 라고 하면 별도 의미: 원본 백업 폴더 안에도 README.md를 직접 두길 원한다는 뜻. 푸시 여부와 무관하게 백업 폴더 자체에 README가 있어야 함. 작업 순서:

1. 작업 사본(`/Users/mac/work/github/<repo>/`)에서 README 작성 + 푸시
2. 원본(`/Users/mac/work/backup/.../`)에도 같은 README를 복사

### 6. 빌드 환경 변수 + README 빌드 안내

레거시 콘솔 빌드는 보통 다음 변수가 필요하므로 README에 명시:

```bash
export ADS_PATH=/path/to/ads           # ADS / GP32 SDK
export NITROSDK_ROOT=/path/to/nitro    # NDS
```

빌드 명령:

```bash
make -f makefile clean
make -f makefile all
```

또는 Windows 호스트에서:

```bat
make_all.bat
make_rungxb.bat
```

### 7. 공개 푸시 후 README 보강 사이클 (2026-07-31)

레거시 프로젝트 푸시 후에도 README는 계속 보강될 수 있다. 매뉴얼 추가, 스크린샷 추가, 게임 규칙 추가 같은 단계적 보강이 흔함. 작업 사본 폴더에 git이 이미 초기화되어 있으므로:

```bash
git add manual/Azmanga_manual/
git commit -m "부루마블대왕 매뉴얼 + 스크린샷 10장 추가"
git push origin main
```

푸시 후 GitHub API로 검증:

```bash
# 커밋 두 개 다 있는지
gh api repos/<user>/<repo>/commits | python3 -c "
import sys, json
cs = json.load(sys.stdin)
print('커밋 수:', len(cs))
for c in cs: print(' ', c['sha'][:7], c['commit']['message'].splitlines()[0])
"

# README 크기 변화 확인
gh api repos/<user>/<repo>/readme | python3 -c "
import sys, json
r = json.load(sys.stdin)
print('README size:', r['size'], 'bytes')
"
```

## 검증 체크리스트

- [ ] 원본 소스 헤더 grep으로 attribution 단서 추출됨
- [ ] README에서 작성자/회사/copyright 라인 제거됨
- [ ] 라이선스 섹션은 "소스 헤더에 보존됨" 안내만
- [ ] 푸시 후 로컬 + 원격 0건 grep 검증 통과
- [ ] 코드는 한 글자도 수정되지 않음 (git diff로 확인)
- [ ] 닫힌 SDK zip (`ads.zip` 등) 작업 사본에서 삭제 + README에 "SDK 별도 필요" 명시
- [ ] `*.lnk`, `*.opt`, `*.ncb`, `Debug/`, `Release/`, `*.obj`, `*.exe`, `*.fxe`, `*.elf`, `*.gxb` 등 빌드 산출물 .gitignore로 제외
- [ ] EUC-KR HTM 매뉴얼은 `iconv -f euc-kr -t utf-8` 또는 Python `read_bytes().decode('euc-kr')`로 디코딩 후 내용 확인
- [ ] 매뉴얼 이미지(JPG)는 README에 마크다운 이미지로 임베드
- [ ] 원본 폴더와 작업 사본 폴더가 분리되어 있고, 원본은 변경되지 않음
- [ ] 원본 폴더 자체에도 README가 있는지 확인 (사용자가 "원본에 추가해"로 의도 명시한 경우)
