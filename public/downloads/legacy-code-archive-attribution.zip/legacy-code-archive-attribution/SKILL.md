---
name: legacy-code-archive-attribution
description: "레거시 코드 GitHub 백업 시 README attribution 처리 워크플로"
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [legacy, archive, attribution, copyright, readme, github]
    related_skills: [github-repo-management, tistory-publisher]
---

# Legacy Code Archive — Attribution Handling

**트리거:** 사용자가 레거시/오래된 소스를 GitHub에 백업/올리라고 지시하고, 원본 코드에 명시적 authorship·copyright·회사명 표기가 있을 때. **또는** "레거시 백업" 의도가 명시된 repo.

## 핵심 원칙 (희정님 기본 선호 — 2026-07-30 검증)

1. **원본 소스 코드는 절대 손대지 않는다** — 헤더 주석, 오타(`ReleseImage`, `DDCliper`), MSVC `#pragma warning`, euc-kr 인코딩 주석 모두 보존. 코드 자체는 박물관 조개처럼 다룬다.
2. **README/github-facing 문서에서 attribution 문자열을 제거한다** — 작성자 이름, 회사명, "Copyright (C) XXXX YYYY" 라인은 README/description에서 빼고 **소스 파일 헤더에 보존됨**을 안내만 한다.
3. **공개판이지만 redistribution license가 아니다** — 본 repo는 외부 공개를 위한 redistribute가 아니라 **history record**임을 README 첫 줄에 명시한다 (예: "🗄️ 레거시 백업 (YYYY-MM-DD 스냅샷) — 기록 보관본. 적극 개발 계획 없음").

## 왜 분리해야 하는가 (배경)

- **공개 = 외부에서 다운로드 가능**: github.com/foo/bar 링크를 포럼/이슈에 박으면 attribution이 부각됨
- **기록 = 본인 보관용**: sigco3111 같은 사용자 본인이 6개월 뒤에 찾으려고 두는 것
- 둘 다 GitHub에 올라가지만 **외부 인지도가 매우 다름**. 사용자가 "기록용이니까 일단 올려"라고 했을 때는 후자 의도. attribution 박지 않는 게 안전.

## 워크플로

### 1. 코드 진단

레거시 코드 4-5개 파일을 받으면 다음을 한 번에 추출:

```bash
# 원본 헤더 80줄 확인
head -80 <file1> <file2> ...

# attribution 단서 grep
grep -E '@ Name|@ Make|@ Version|@ Date|Copyright|@ Author' *.h *.c

# 회사/저작자 약자 추출 (예: E.A.S.T.V.I.L)
grep -E '\bE\.[A-Z]\.[S-Z]\.[T-Z]\.[V-Z]\.[I-Z]\.[L-Z]\b'
```

### 2. README 작성 시 attribution 분류

| 정보 종류 | 원본 헤더 | README/github-facing |
|----------|----------|-------------------|
| 엔진명 | 보존 | 그대로 사용 가능 (기술 식별자) |
| 버전 (3.1) | 보존 | 그대로 사용 가능 |
| 작성일 (2009-04-13) | 보존 | 그대로 사용 가능 |
| **작성자 이름** | 보존 | **제거** |
| **회사명** | 보존 | **제거** |
| **`Copyright (C) YYYY` 라인** | 보존 | **제거** |
| 함수 오타/주석 | 보존 | README에서는 무관 (코드 영역) |
| 알고리즘 (블렌드 매크로) | 보존 | README에서 설명 가능 (기법은 공지식) |

### 3. README 라이선스 섹션 패턴

원본 라이선스를 README에서 빼버리되, "보존됨" 안내는 박는다:

```markdown
## 📜 출처 / 라이선스

원본 저작자/저작권 표기는 **소스 파일 헤더 주석에만** 보존되어 있습니다. 본 리포지토리는 외부 공개를 전제로 한 배포본이 아니며, 원본 파일에 명시된 권리 표기를 따릅니다. 별도 라이선스 파일은 포함되어 있지 않습니다.
```

### 4. 푸시 후 검증

```bash
# 1) 로컬에서 0건 확인
grep -ic "EASTVIL\|Kim Jong Wook\|Shin Hee Jung\|E\\.A\\.S\\.T\\.V\\.I\\.L" README.md
# 2) 깃허브 README 디코딩 후 0건 확인
curl -s https://api.github.com/repos/<user>/<repo>/contents/README.md \
  | python3 -c "import sys,json,base64; print(len(re.findall(r'PATTERN', base64.b64decode(json.load(sys.stdin)['content']).decode())))"
```

## 실수 사례 (이번 세션에서 학습)

- **사용자가 "EASTVIL 관련 내용은 제거해줘"라고 명시**. 그 전까지 README에 박혀 있던 항목: 엔진명 표기의 EASTVIL prefix, 작성자 2명, `..E.A.S.T.V.I.L..` 회사명, "EASTVIL에 사용·재배포 조건 확인" 라이선스 문구. **사용자는 README 안 회사명을 원하지 않았고, 동시에 C 소스 헤더는 그대로 두길 원했음** — 이 분리가 핵심.
- 헷갈리면 안 되는 신호: 사용자가 "**README**에서" 라고 명시했으면 코드는 보존이 기본. 코드를 수정하면 외부 라이선스 위반이 됨.

## Preflight 질문 (사용자에게 짧게)

레거시 백업 작업 시작 시 다음 2개는 한 번에 받아두는 게 안전:

1. **공개 의도**: "외부 공개용 redistribution" vs "본인 기록용" — 일반 사용자가 '내 github에 일단 올려'라고 하면 후자. **명시 확인 안 받았으면 후자로 가정**.
2. **레포 이름**: 폴더명 그대로가 디폴트지만, 의미가 좁은 폴더명(`wipic_draw3_1` 같은 빌드 넘버) → 우아한 정리 이름 추천

## Pitfalls

- **attribution을 코드에서 지우면 라이선스 위반 가능**. README/github-facing만 정리하고, 원본 소스 헤더는 절대 수정하지 않는다.
- **회사명에 띄어쓰기 없는 대문자 약자가 등장하면 의심** — `E.A.S.T.V.I.L` 같은 패턴. 이런 표기는 README에서 한 번 더 grep으로 0건 확인할 것.
- **euc-kr 인코딩 헤더 주석** — Visual Studio 외 환경에서 깨져 보이지만 보존이 원칙.
- **원본 파일명 오타** — 함수가 외부에서 호출될 수 있는 심볼이면 절대 수정 금지 (`ReleseImage`, `DDCliper` 사례).
- **사용자 신호 vs 의도 혼동** — "EASTVIL 제거해줘"는 README 한정. 본인이 모든 컨텍스트를 잃었을 때 코드를 건드리는 사고로 이어질 수 있음. 명확치 않으면 멈추고 확인.

## 검증 체크리스트

- [ ] 원본 소스 헤더 grep으로 attribution 단서 추출됨
- [ ] README에서 작성자/회사/copyright 라인 제거됨
- [ ] 라이선스 섹션은 "소스 헤더에 보존됨" 안내만
- [ ] 푸시 후 로컬 + 원격 0건 grep 검증 통과
- [ ] 코드는 한 글자도 수정되지 않음 (git diff로 확인)
