---
name: coding-mission-fullcycle
description: sigco3111 코딩미션(cokac.com 코드깎는노인 챌린지)의 End-to-End 풀사이클 정형 워크플로. **부트스트랩 (저장소 + README 1차 + OpenCode 인계) → OpenCode 본체 구현 → vercel 배포 + README v1.0 다층 bump → 4축 bit-perfect 검증 → 단일 commit + push** 까지 5번의 풀사이클 미션에서 검증된 패턴. 사용자가 "코딩미션" 또는 "OpenCode + MiniMax-M3" 키워드로 2-Phase 워크플로를 명시적으로 분리해 진행 요청할 때 발화.
category: devops
tags:
  - coding-mission
  - sokac
  - opencode
  - minmax-m3
  - vercel
  - github
  - static-site
  - canvas
  - simulation
  - fullcycle
  - bootstrap
when to use: >
  사용자가 "X 코딩미션을 진행할거임. 저장소 생성 + 리드미에 추가 + 오픈코드 작업
  인계" 또는 "vercel로 배포 + sigco3111/{repo} 형식 참고 + 리드미 갱신" 2-Phase
  워크플로를 명시적으로 요청할 때. sigco3111 GitHub 조직 하위 새 저장소 + README
  헤딩 11종 처음부터 정규화로 anchor 깨짐 0 노선 유지. 트리거: "코딩미션",
  "cokac.com", "오픈코드", "OpenCode + MiniMax-M3", "vercel로 배포", "리드미 형식
  참고", "리드미 파일 갱신".
---

# coding-mission-fullcycle (2026-07-09 umbrella, NEW)

> 5번의 풀사이클(optics-prism-lab / offroad-suspension / heat-conduction-heatmap / genetic-walking + sigco3111 이전 6개) 패턴이 정형화되어 umbrella로 분리.
> 이전 위치: `canvas-static-site-pipeline` step 7.5.* (bootstrapping), §7.5.3 (anchor 깨짐), §7.5.5 (WT dirty), §7.5.7 (사용자 위임) — 모두 본 스킬로 **forward**. 부모 스킬 본문은 변형 선택 (웹 vs 플랫폼 SDK vs pygame) + step 0~6 + cleanup 유지.

## 표지 — 이 스킬이 발화할 때

다음 키워드가 한 줄이라도 등장하면 본 스킬을 우선 로드:
- **"코딩미션"** / **"cokac.com"** (코드깎는노인) / **"OpenCode + MiniMax-M3"** / **"오픈코드에서 작업할테니"**
- **"vercel로 배포하고"** / **"sigco3111/{repo} 리드미 형식 참고"** / **"리드미 파일을 갱신해줘"**

**사용자 시그니처 패턴 (5번 실측)**: 항상 **2-Phase 분리 요청**. 1차 = "부트스트랩" → 2차 = "vercel 배포 + 리드미 갱신". 한 번에 다 해달라는 요청은 0건. 본 스킬은 두 Phase 모두 다룸.

**forward 패턴**: 본 스킬 발화 시 step 7.5.* (bootstrap / scaffolding / anchor 깨짐 / WT dirty / 사용자 위임) 노트는 모두 본 스킬로 forward. 부모 스킬 `canvas-static-site-pipeline`은 step 0/1/4/6/cleanup 같은 일반 단계 + variants(웹/플랫폼 SDK/pygame)만 다룸.

## 0. 두 Phase 분리 — 사용자가 항상 2번 요청

이 시그니처 패턴이 본 스킬의 핵심. 사용자는 절대 한 번에 풀사이클을 요청하지 않는다:

**Phase 1 — Bootstrap (사용자 1차 요청)**:
> "**X 코딩미션을 진행할거임. 저장소를 생성하고, 리드미에 ... 추가해줘. 오픈코드에서 작업할테니 리드미만 간단히 만들어서 커밋해.**"

→ 4개 산출물: ① 빈 디렉토리 + git init + gh repo create + 푸시 ② `README.md` (1차 — Status 체크박스 4개 + 헤딩 8종 정규화) ③ `index.html` (placeholder — OpenCode 컨텍스트 복원용 프롬프트 verbatim echo) ④ `.gitignore` (sigco3111 표준 4줄).

**Phase 2 — Full cycle (사용자 2차 요청)**:
> "**vercel로 배포하고, sigco3111/{다른 리포}의 리드미 형식을 참고해서 리드미 파일을 갱신해줘.**"

→ 4개 산출물: ① `vercel deploy` + raw alias 확보 ② `README.md` 다층 v1.0 (헤딩 11종 정규화 + 라이브 데모 URL + 디자인 결정 7종 + CONFIG 표 + 검증 시나리오 + 프롬프트 이력) ③ `README.en.md` 미러 (KR canonical, EN naturalized whitelist) ④ 4축 bit-perfect 검증 + 단일 commit + push.

**왜 두 Phase로 분리하는가**:
- Phase 1 = OpenCode 작업 자리를 넘기는 단계 → 사용자 컨텍스트 보존 + OpenCode 컨텍스트 복원의 균형점
- Phase 2 = 1차 push 후 OpenCode가 index.html 작업한 결과물을 검증 + 배포하는 단계 → 사용자가 코드 작업자는 아니므로 Hermes가 중간 다리
- 사용자가 "**한 번에 다 해줘**" 라고 요청하는 경우는 거의 없음 (실측 5건 중 0건)

## 1. Phase 1 — Bootstrap 단계

**목표**: 사용자가 OpenCode에 작업 자리를 넘기고, OpenCode가 grep 한 번으로 컨텍스트 복원 가능하게.

**순서**:

```bash
# 1) 디렉토리 + git init + gh repo create — 한 번에 (cold-start 워크플로)
mkdir -p /Users/mac/work/<project-name>
cd /Users/mac/work/<project-name>
git init -b main
gh repo create sigco3111/<project-name> --public \
  --description "{한 줄 컨셉}" \
  --source=. --remote=origin
```

**사전 검증 (= 헤딩 anchor 깨짐 사전 방어 §7.5.3.1 노트)**:
- README 작성 시 **헤딩 11종을 처음부터 이모지 + 한글 only로 메모한 뒤 시작** — `templates/README-bootstrap.md`의 8개 헤딩 셋 또는 `templates/README-multilayer-v1.md`의 11개 헤딩 셋 중 선택 (Phase 1은 8개, Phase 2 다층화 시 11개로 확장)
- **검증 2중 grep**: ① `bash ~/.hermes/skills/ad-hoc-verifier/scripts/check-kr-en-mixed-headings.sh README.md` 통과 → ② `python3 -c "import re; print(len(re.findall(r'^## .*\\([^\\n]*[A-Z][^\\n]*\\)\\s*$', open('README.md').read(), flags=re.MULTILINE)))"` 0 출력. 두 번째 grep이 1차 통과에서 누락된 케이스 잡음 (genetic-walking 2026-07-09 실측: `## 🧠 구현 힌트 (OpenCode 참고용)`)

**4개 산출물 동시 write_file**:
- `README.md` — `templates/README-bootstrap.md` 기반 8개 헤딩 정규화 + Status 체크박스 4개 + 🤖 생성 정보 절 + 프롬프트 verbatim 보존
- `index.html` — `templates/index-html-placeholder.md` 기반 placeholder + 프롬프트 verbatim echo 주석 (OpenCode grep으로 컨텍스트 복원 보장)
- `.gitignore` — `templates/gitignore-sigco3111.md` 기반 12줄
- (LICENSE는 Phase 2에서 자동 보완 — sigco3111 4건 모두 동일 패턴)

```bash
git add README.md index.html .gitignore
git commit -m "docs: 코딩미션 1차 README — OpenCode + MiniMax-M3 프롬프트 명시

{프로젝트 한 줄 설명} 코딩미션 scaffolding.

🤖 Generated with OpenCode CLI + MiniMax-M3"
git push -u origin main
```

**보고 형식 (5줄)**:
1. 저장소 URL (https://github.com/sigco3111/{name})
2. 루트 커밋 SHA
3. remote HEAD == local HEAD
4. 한/영 혼합 헤딩 0개 (anchor 깨짐 부재)
5. 다음 단계 (OpenCode가 본체 구현 — 사용자가 작업 마무리 시 "vercel로 배포 + 리드미 갱신" 2차 요청)

## 2. Phase 2 — Full cycle 단계

**목표**: OpenCode 작업 결과물을 검증 + Vercel raw alias 배포 + README v1.0 다층화.

### 2.1 Vercel raw alias 확보

```bash
vercel deploy --prod --yes --token $(cat ~/.hermes/secrets/vercel_token.txt) 2>&1 | tail -25
# 출력에서 "▲ Aliased         https://{name}.vercel.app" 라인이 라이브 데모 URL
```

**alias suffix 점유 맵** (2026-07-09 갱신 — 점유 -0 슬롯이 raw, -1은 -one, -2는 -two ...):
```
optics-prism-lab.vercel.app          ← 점유-0
offroad-suspension.vercel.app         ← 점유-0
heat-conduction-heatmap.vercel.app    ← 점유-0
genetic-walking.vercel.app            ← 점유-0
ripple-tank.vercel.app                ← 점유-0
magnetic-fields.vercel.app            ← 점유-0
3d-matrix-rain.vercel.app             ← 점유-0
synthwave-terrain.vercel.app          ← 점유-0
neon-fluid-one.vercel.app             ← 점유-1
boids-flocking-two.vercel.app         ← 점유-2
bridge-constructor-three.vercel.app   ← 점유-3
```

**점유 충돌 회피**: Vercel raw alias 자동 시도 후 점유 안 됐으면 그대로 발급. 점유면 -one/-two suffix 자동 시도.

### 2.2 README.md 다층 v1.0 — 헤딩 11종 정규화

**11종 표준 셋** (offroad-suspension + optics-prism-lab + heat-conduction-heatmap + genetic-walking 4번의 실측, 2026-07-09 확정):
```
1. ## 🎬 라이브 데모 (또는 프로젝트 이모지 🔥/🧬)
2. ## 🤖 생성 정보
3. ## ✨ 주요 특징
4. ## 🚀 실행 방법
5. ## 🎮 조작법
6. ## 🛠️ 기술 스택
7. ## 📂 프로젝트 구조
8. ## 🎨 디자인 결정
9. ## 🧠 동작 원리
10. ## 🔬 검증
11. ## 📝 프롬프트 이력
```

**templates/README-multilayer-v1.md** 가 본 셋을 정확히 따름 (14,000B 전후).

**핵심 작성 요소**:
- 라이브 데모에 `https://{name}.vercel.app/` URL 명시 + 4개 shield.io 배지
- 🤖 생성 정보에 MiniMax-M3 + OpenCode CLI 명시 + **프롬프트 원문 verbatim 보존** (KR codeblock)
- ✨ 주요 특징 — 8~10개 불릿
- 🎮 조작법 — 마우스 / 키보드 / 슬라이더 표 분리
- 🎨 디자인 결정 — 7개 + CONFIG Object.freeze 표
- 🧠 동작 원리 — ASCII 다이어그램 + 핵심 공식 1개
- 🔬 검증 — bit-perfect 사이즈 + 의존성 개수
- 📝 프롬프트 이력 — 1차/2차/3차/4차 시간순 표

**2중 헤딩 검증 필수** (1중이면 false-pass 위험 — §3 참조):
```bash
bash ~/.hermes/skills/ad-hoc-verifier/scripts/check-kr-en-mixed-headings.sh README.md
python3 -c "
import re
t = open('README.md', encoding='utf-8').read()
mixed = re.findall(r'^## .*\\([^\\n]*[A-Z][^\\n]*\\)\\s*$', t, flags=re.MULTILINE)
assert len(mixed) == 0, f'mixed: {mixed}'
"
```

### 2.3 README.en.md 미러 — 3-tier 번역 정책

**Tier 1 — verbatim 보존 (양쪽 README에 그대로)**: `MiniMax-M3`, `OpenCode CLI`, `sigco3111/{repo-path}`, `코드깎는노인`, 코드블록 안 프롬프트 verbatim.

**Tier 2 — EN 자연 번역 whitelist (의도됨)**: 단일 단어 매핑만 (`단일 HTML → single HTML` / `물리 엔진 → physics engine`).

**Tier 3 — KR-only 영역**: 헤더 디자인 결정 본문 / Project Structure 한글 라벨.

상세 + 자주 빠지는 함정 6종은 `references/coding-mission-bilingual-readme-policy.md` 참조 (canvas-static-site-pipeline umbrella에 위치).

### 2.4 4축 bit-perfect 검증

```python
import os, urllib.request
local_size = os.path.getsize('index.html')
req = urllib.request.Request('https://{name}.vercel.app/',
                              headers={'User-Agent':'Mozilla/5.0'})
remote_size = len(urllib.request.urlopen(req).read())
print(f'local={local_size} remote={remote_size} '
      f'{"PASS" if local_size == remote_size else "FAIL"}')

# 컨텐츠 키워드 5종 매칭
content = urllib.request.urlopen(req).read().decode('utf-8', errors='ignore')
import re
keys = [domain_keyword_a, domain_keyword_b, domain_keyword_c,
        domain_keyword_d, domain_keyword_e]
hits = {k: len(re.findall(k, content, re.IGNORECASE)) for k in keys}
print(f'keywords: {hits} (sum={sum(hits.values())})')
```

`scripts/bit-perfect-verify.py`로 자동화. **shell `[ "$a" = "$b" ]` 비교는 4건 모두 false negative 재발** — `wc -c <` trailing 2줄 suffix 때문. python `os.path.getsize()` 통일 권장.

### 2.5 LICENSE 자동 보완 (sigco3111 표준)

```bash
test -f LICENSE || gh api repos/sigco3111/neon-fluid/contents/LICENSE --jq '.content' | base64 -d > LICENSE
wc -c < LICENSE && head -3 LICENSE
```

### 2.6 단일 commit + push + post-push fresh evidence

```bash
git status --short  # 4파일 (M .gitignore + M README.md + ?? LICENSE + ?? README.en.md) 확인
git diff .gitignore  # .vercel/ 1줄 자동 staging 확인 — sigco3111 표준

git add README.md README.en.md LICENSE .gitignore
git commit -m "docs(README): multi-layer v1.0 — KR/EN, header 0 mixed, bit-perfect alias

- KR README.md ({size}B) — sigco3111 다층 패턴
- EN README.en.md ({size}B) — 미러 (KR canonical, EN naturalized)
- LICENSE ({size}B) — neon-fluid에서 MIT 보완
- .gitignore — .vercel/ 1줄 추가 (Vercel 부산물 추적 제외)

오픈코드 + MiniMax-M3 생성 표시 (🤖 생성 정보 / Attribution) 명시.
헤딩 {N}종 처음부터 이모지+한글 only 정규화 → anchor 깨짐 0개 (사전 발견 {X} + 패치 {X} = 깨짐 0).

Vercel raw alias 확보: https://{name}.vercel.app/
bit-perfect: 로컬 {size}B ≡ alias {size}B (HTTP 200)"

git push origin main

# Post-push fresh evidence
SHA=$(git rev-parse --short=10 HEAD)
REMOTE=$(gh api repos/sigco3111/{name}/commits/main --jq '.sha[:10]')
echo "local=$SHA remote=$REMOTE"

curl -sS -o /dev/null -w "POST-PUSH HTTP %{http_code} | %{size_download}B\n" \
  -A "Mozilla/5.0" https://{name}.vercel.app/
```

### 2.7 보고 (3-block 형식)

```
## ✅ {name} 풀사이클 완료

### 🔥 라이브 데모
> **👉 [https://{name}.vercel.app/](https://{name}.vercel.app/)**

### 📊 4축 검증 결과
| 축 | 결과 |
|---|---|
| **HTTP** | {200} ✅ |
| **사이즈** | {size}B (로컬 {size}B ≡ alias {size}B) ✅ |
| **bit-perfect** | PASS ✅ |
| **컨텐츠 키워드** | ... |
| **앵커 깨짐** | KR/EN 모두 0/{N} ✅ |
| **remote SHA** | {sha} == {sha} ✅ |
| **post-push fresh** | HTTP 200 ✅ |

### 🏗️ {name vs 패턴} 정렬 체크리스트
| 차원 | A | B | 본 미션 |
|---|---|---|---|
| ... |
```

### 2.8 다음 단계 후보 + WT 보고

푸시 직후 WT 0건 unstaged → "WT 0건 — 의도된 4파일만 staged" 한 줄 보고로 충분.

## 3. 측정값 — "패치 0회" 의 정확한 의미

`canvas-static-site-pipeline` §7.5.3.1 노트의 "패치 0회" 표현이 정확하지 않다는 게 5번째 풀사이클(genetic-walking)에서 검증됨:

| 풀사이클 | 사전 발견 | 패치 | 깨짐 | 측정 |
|---|---|---|---|---|
| offroad-suspension (2026-07-09) | 0 | 0 | 0 | "패치 0회" ✅ |
| optics-prism-lab (2026-07-09) | 0 | 0 | 0 | "패치 0회" ✅ |
| heat-conduction-heatmap (2026-07-09) | 0 | 0 | 0 | "패치 0회" ✅ |
| **genetic-walking (2026-07-09)** | **1** | **1** | 0 | **"사전 발견 1 + 패치 1"** ⚠️ |

**정확한 측정값** = **"사전 발견 N + 패치 N = 깨짐 0"**. genetic-walking에서 `## 🧠 구현 힌트 (OpenCode 참고용)` 헤딩이 표준 스크립트 1차 grep에서 false-pass로 통과됐는데, **python 2차 grep에서 잡힘** → 1 patch → 깨짐 0.

**개선**:
- `ad-hoc-verifier/scripts/check-kr-en-mixed-headings.sh` 스크립트 자체에 python heredoc으로 2중 grep 통합 필요 → `references/check-kr-en-mixed-headings-false-pass.md`
- 모든 Phase 2 README 작성 후 **반드시 2중 grep 둘 다 실행** — 한쪽만 통과하고 다른 쪽는 망각하는 함정 회피

## 4. WT clean 4가지 조건 — Phase 1 단계부터 채워야

WT clean 자동 진입 (이전 §7.5.5.1 노트) — 4가지 조건 모두 만족 시 staging boundary 보고 불필요:

1. **`.gitignore`에 PNG 패턴 사전 박힘** — `s?-*.png` / `fix*-*.png` / `final-*.png` / `screenshot-*.png`
2. **OpenCode 디바이스 부산물도 사전 ignore** — `.omo/`, `.playwright-mcp/`, `.codegraph/`, `.vercel/`
3. **`LICENSE` 누락 자동 보완** — Phase 2 진입 시 neon-fluid에서 `gh api` 1줄로 보완
4. **stage 의도가 정확히 4파일** — `README.md` + `README.en.md` + `LICENSE` + `.gitignore`

상세: `references/wt-clean-4conditions.md`

## 5. 자주 빠지는 함정 4종

**5.1 LICENSE 첫 push 시 누락** — sigco3111 4건 모두 동일. 자동 보완 1줄.

**5.2 shell `[ "$a" = "$b" ]` false negative (4건 모두 재발)** — `wc -c < file` stdout trailing 2줄 suffix. python `os.path.getsize()` 통일.

**5.3 placeholder index.html OpenCode 컨텍스트 손실** — Phase 1에서 placeholder 본문에 프롬프트 verbatim echo 필수.

**5.4 헤딩 한/영 혼합 false-pass (이번 미션에서 발견)** — `^## .*\(.*[A-Z].*\)\s*$` 가 `(OpenCode 참고용)` 같은 영문+한글 혼합 케이스를 놓침. 정규식 강화 필요 → `references/check-kr-en-mixed-headings-false-pass.md`.

## 6. related skills

- `devops/canvas-static-site-pipeline` — 본 스킬이 위임받은 step 7.5.* 가 본래 있던 부모 스킬. 역호환 위해 step 7.5 노트는 본 스킬로 forward.
- `devops/ad-hoc-verifier` — `scripts/check-kr-en-mixed-headings.sh` 호스트. 본 스킬의 2중 grep 2번째 어서션이 여기에 의존.
- `github/github-cli` — `gh repo create`, `gh api`, `gh repo delete` 등
- `devops/vercel` — vercel CLI 작업 (모호한 이름 회피 위해 카테고리 경로 명시)

## 7. 시그니처 패턴 변화 추적

이 umbrella는 **사용자의 두 단계 분리 요청 패턴** 에 의존. 만약 미래에 사용자가 "한 번에 다 해줘" 또는 "OpenCode 안 쓰고 너가 다 해줘" 같은 변형 요청을 하면 본 umbrella의 trigger가 더 단순한 변형으로 진화 가능. 추적:
- 2026-07-09 — 5번 풀사이클 모두 2단계 분리 패턴 유지. 변경 사항 없음.

## 8. meta — 이 스킬이 다루는 않은 것

- **다른 PC 핸드오프** — 다른 PC에서 작업 의도가 있을 땐 `canvas-static-site-pipeline` step 7 (풀 패키지 docs/ + AGENTS.md) 사용. 본 스킬은 같은 자리 작업 의도만 다룸.
- **데스크탑 pygame / 플랫폼 SDK 미니앱** — `canvas-static-site-pipeline` 부모 스킬의 variants. 본 스킬은 sigco3111 코딩미션 풀사이클 1개 변형(정적 웹 단일 HTML)만 다룸.
- **OpenCode 위임** — `autonomous-ai-agents/opencode` 스킬 또는 `autonomous-coding-agents` umbrella 사용. 본 스킬은 OpenCode 결과물을 **수령 + 검증 + 배포** 만 다룸.
- **시각화 라이브러리 선택 (Three.js vs regl vs r3f)** — `canvas-static-site-pipeline` step 0.3 결정 포인트. 본 스킬은 시각화 라이브러리 선택 자체는 다루지 않음.
