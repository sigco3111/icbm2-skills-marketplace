#!/usr/bin/env bash
# header-pre-defense-normalize.py — 헤딩 anchor 깨짐 사전 방어 2중 grep + 자동 정규화
# 2026-07-09 genetic-walking 실측 — 표준 스크립트 1차 grep에서 false-pass 케이스 발견 →
#   표준 스크립트만으론 부족. 본 스크립트는 **2중 grep 통합** + 발견 시 자동 patch 1회.
#
# 사용법:
#   bash scripts/header-pre-defense-normalize.py README.md
#
# 의존: python3, git (없어도 동작)
# 출력:
#   - 발견 시: 발견된 mixed 헤딩 라인 + 자동 patch diff
#   - 깨끗: "✅ KR mixed: 0 (verified by 2중 grep)"

set -euo pipefail

FILE="${1:-README.md}"

if [[ ! -f "$FILE" ]]; then
    echo "❌ File not found: $FILE"
    exit 2
fi

python3 << PYEOF
import re, sys, subprocess
from pathlib import Path

p = Path("${FILE}")
t = p.read_text(encoding="utf-8")

# 2중 grep:
# (1) 표준 정규식 — 영문 괄호 (영문 only / 영문+한글 혼합) 모두 잡음
# (2) 한글 단독 괄호/콜아웃 표기 + 영문 괄호 패턴 — 영문 토큰이 한글 사이에 끼어드는 케이스
mixed_pattern_1 = re.compile(
    r'^## [^\n]*\([^)\n]*[A-Za-z][^)\n]*\)[ \t]*\$',
    re.MULTILINE,
)

# 안전 헤딩 패턴: 한글만 있는 괄호, 또는 괄호 없음
def is_korean_only_or_none(s):
    s = s.strip()
    m = re.match(r'^\(([^)]*)\)\$', s)
    if m:
        return all('\uac00' <= c <= '\ud7a3' or c in ' ,-' for c in m.group(1)) or not m.group(1).strip()
    return True

mixed = []
for line in t.split('\n'):
    if line.startswith('## '):
        if mixed_pattern_1.search(line):
            m = re.search(r'\(([^)]*)\)', line)
            if m and not is_korean_only_or_none(m.group(0)):
                mixed.append(line)

if not mixed:
    print("✅ KR mixed: 0 (verified by 2중 grep)")
    sys.exit(0)

# 발견 시 — 자동 patch 1회 (영문 괄호 부분만 제거)
print(f"⚠️  Found {len(mixed)} mixed heading(s):")
for line in mixed:
    print(f"   - {line}")
print()

# 패치 후보 미리보기 — 헤더 # 다음의 영문 괄호 (...) 제거
patch_pairs = []
for line in mixed:
    new_line = re.sub(r'\s*\(([^)]*)\)\s*\$', '', line)
    if new_line != line:
        patch_pairs.append((line, new_line))

if not patch_pairs:
    print("(자동 patch 패턴 매칭 실패 — 수동 patch 필요)")
    sys.exit(1)

print("Auto-patch 후보:")
for old, new in patch_pairs:
    print(f"  - {old}")
    print(f"  + {new}")
print()

# patch 적용
new_t = t
for old, new in patch_pairs:
    new_t = new_t.replace(old, new)
p.write_text(new_t, encoding="utf-8")
print(f"✅ Patched {FILE}")
print()
print("재검증:")
subprocess.run(["python3", "-c", f"""
import re
t = open({FILE!r}, encoding='utf-8').read()
mixed = re.findall(r'^## [^\n]*\\([^)\n]*[A-Za-z][^)\n]*\\)[ \\t]*\$', t, flags=re.MULTILINE)
print(f'  잔여: {{len(mixed)}}=0' if not mixed else f'  잔여: {{mixed}}')
"""])
PYEOF
