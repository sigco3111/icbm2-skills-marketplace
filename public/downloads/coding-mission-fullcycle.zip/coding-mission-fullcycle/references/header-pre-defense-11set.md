# 헤딩 anchor 깨짐 사전 방어 — 11종 표준 셋 (2026-07-09 확정)

> 5번 풀사이클(optics-prism-lab / offroad-suspension / heat-conduction-heatmap / genetic-walking + 이전 sigco3111 6개) 실측 기반.
> GitHub README anchor slug 생성기 함정 — `## 🛠️ 기술 스택 (Tech Stack)` 같은 (이모지 + 한글 + 영문 괄호) 헤딩은 anchor가 `🌡️-라이브-데모` 처럼 깨짐. 11종 모두 처음부터 **이모지 + 한글 only**로 정규화해서 깨짐 0 노선 유지.

## 11종 표준 헤딩 셋 (offroad-suspension → optics-prism-lab 11개로 확장 확정)

| # | 헤딩 (정규화 완료) | 비고 |
|---|---|---|
| 1 | `## 🎬 라이브 데모` (또는 프로젝트 이모지 🔥/🧬) | (Live Demo) ❌, 라이브 데모 ✅ |
| 2 | `## 🤖 생성 정보` | (Attribution) ❌, 생성 정보 ✅ |
| 3 | `## ✨ 주요 특징` | (Features) ❌, 주요 특징 ✅ |
| 4 | `## 🚀 실행 방법` | (Quick Start) ❌, 실행 방법 ✅ |
| 5 | `## 🎮 조작법` | (Controls) ❌, 조작법 ✅ |
| 6 | `## 🛠️ 기술 스택` | (Tech Stack) ❌ — **가장 위험한 헤딩 (3/3 다른 미션 모두 깨짐)** |
| 7 | `## 📂 프로젝트 구조` | (Project Structure) ❌ (Phase 2에서만 추가) |
| 8 | `## 🎨 디자인 결정` | (Design Choices) ❌, 디자인 결정 ✅ |
| 9 | `## 🧠 동작 원리` | (How It Works) ❌, 동작 원리 ✅ |
| 10 | `## 🔬 검증` | (Verification) ❌, 검증 ✅ |
| 11 | `## 📝 프롬프트 이력` | (Prompt Log) ❌, 프롬프트 이력 ✅ (1차 grep에서 자주 누락) |

**Phase 1 (Bootstrap) 표준**: 8종 (1~6 + 10). Status 체크박스 4개와 라이브 데모 placeholder 정도만 채움.
**Phase 2 (Full cycle) 표준**: 11종 (전체). 디자인 결정 + 프로젝트 구조 + 프롬프트 이력 추가.

## 영문 콜아웃은 별도 라인

영문 명칭이 필요하면 헤딩이 아니라 **별도 라인**으로 콜아웃. 헤딩 인라인 영문 괄호 X:

```markdown
## 🎬 라이브 데모

> **👉 [Live Demo URL]({url})** — 브라우저에서 바로 실행

> Live Demo · 60fps · zero deps

... (본문 한글)
```

EN 미러는 **영문 only** (이모지 없이): `## Live Demo`, `## Tech Stack`, `## How It Works`. KR 헤딩과 정확히 매칭되지 않아도 무방 (3-tier 번역 정책 Tier 3 영역).

## 2중 검증 (genetic-walking 2026-07-09 실측 기반 — 필수)

**중요**: 표준 스크립트 `check-kr-en-mixed-headings.sh`만으론 false-pass 위험이 있음 (실측 1건 — `## 🧠 구현 힌트 (OpenCode 참고용)`). **반드시 2중 grep 둘 다 PASS**:

```bash
# 1) 표준 스크립트 (대부분의 케이스 잡음)
bash ~/.hermes/skills/ad-hoc-verifier/scripts/check-kr-en-mixed-headings.sh README.md
# → "✅ KR README 한/영 혼합 헤딩 부재 (anchor 깨짐 위험 0개)" 또는 mixed 라인 출력

# 2) python heredoc 2차 grep (false-pass 케이스 보강)
python3 -c "
import re
t = open('README.md', encoding='utf-8').read()
mixed = re.findall(r'^## .*\\([^\\n]*[A-Z][^\\n]*\\)\\s*\$', t, flags=re.MULTILINE)
assert len(mixed) == 0, f'false-pass headers detected: {mixed}'
print('KR mixed: 0 (verified)')
"
```

이 2중 grep을 단일 스크립트로 묶은 버전은 `scripts/header-pre-defense-normalize.py` 참조 (umbrella 본체).

## 측정값 — "사전 발견 N + 패치 N = 깨짐 0"

5번 풀사이클 측정값:

| 풀사이클 | 사전 발견 | 패치 | 깨짐 | 측정 |
|---|---|---|---|---|
| offroad-suspension (2026-07-09) | 0 | 0 | 0 | 사전 발견 0 + 패치 0 |
| optics-prism-lab (2026-07-09) | 0 | 0 | 0 | 사전 발견 0 + 패치 0 |
| heat-conduction-heatmap (2026-07-09) | 0 | 0 | 0 | 사전 발견 0 + 패치 0 |
| **genetic-walking (2026-07-09)** | **1** | **1** | 0 | **사전 발견 1 + 패치 1** |

`canvas-static-site-pipeline` §7.5.3.1 노트의 "패치 0회" 표현은 정확하지 않음 — genetic-walking에서 표준 스크립트만으론 잡히지 않는 케이스 발견. **정확한 측정값 = "사전 발견 N + 패치 N = 깨짐 0"**.

**결론**: 2중 grep + 정규화 셋 메모 + 작성 단계에서 헤딩 11종 준수 → 거의 항상 사전 발견 0. 다만 false-pass 케이스(영문 [A-Z] 룰이 한글 사이에 끼어드는 영문 토큰을 놓침)가 종종 발생 — 2중 grep으로 잡고 1 patch → 깨짐 0 유지.

## false-pass 케이스 예시 (genetic-walking 2026-07-09)

| 헤딩 | 표준 스크립트 | python 2차 grep | 결과 |
|---|---|---|---|
| `## 🎬 라이브 데모` | PASS | PASS | OK |
| `## 🤖 생성 정보` | PASS | PASS | OK |
| `## 🚀 실행 방법 (예정)` | PASS | PASS | OK (한글 괄호는 정상) |
| **`## 🧠 구현 힌트 (OpenCode 참고용)`** | **PASS (false-pass!)** | **FAIL** | 표준 스크립트 bypass → 2차에서 1 patch |
| `## 🤖 생성 워크플로` | PASS | PASS | OK |

핵심 패턴: `(OpenCode 참고용)` 처럼 **괄호 안에 영문 토큰이 한글 사이에 끼어있는** 케이스. 영문 [A-Z] 룰은 만족하지만 의도는 영문+한글 혼합으로 anchor 깨짐 위험. python heredoc으로 잡음.
