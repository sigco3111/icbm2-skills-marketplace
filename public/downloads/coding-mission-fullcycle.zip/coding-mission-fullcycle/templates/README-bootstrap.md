# {EMOJI} {프로젝트명}

> {한국어 한 줄 부제}
> {Korean subtitle}

{2~3줄 — 사용자가 요청한 미션의 핵심 컨셉을 한국어로 설명. 구현되지 않은 상태이므로 placeholder 표현 사용.}

[🇰🇷 한국어 (기본)](#) · [🇺🇸 English](./README.en.md)

---

## {EMOJI} 라이브 데모

> 🚧 **배포 후 활성화 예정** — Vercel alias URL이 발급되면 이 줄이 라이브 데모로 교체됩니다.

---

## 🤖 생성 정보

이 프로젝트의 코드는 아래 모델과 프롬프트를 이용해 **자동으로 생성**됩니다.

| 항목 | 값 |
|---|---|
| **모델** | MiniMax-M3 |
| **실행 환경** | OpenCode CLI |
| **저장소** | [`sigco3111/{repo-name}`](https://github.com/sigco3111/{repo-name}) |
| **라이선스** | MIT |
| **의존성** | {0~2개에 따라 자동 산출} |

### 📝 사용된 프롬프트 (원문)

```
{사용자 원본 프롬프트 verbatim — Implementation Advice 포함}
```

---

## 🚧 Status

코딩미션 진행 단계 — 1차 작업은 저장소 bootstrap + OpenCode에게 작업 자리 인계까지.

- [x] 저장소 생성 + README 1차 커밋 (현재 단계)
- [ ] OpenCode가 `index.html` 본체 구현
- [ ] Vercel 배포 + 라이브 데모 URL 발급
- [ ] README 다층화 v1.0 (Live Demo URL + Design Choices + Config 표)

---

## 🚀 실행 방법 (예정)

```bash
# 옵션 A: 브라우저에서 직접 열기
open index.html

# 옵션 B: 로컬 정적 서버 (권장)
python3 -m http.server 8000
# → http://localhost:8000 접속

# 옵션 C: Vercel 라이브 데모 (배포 후 활성화)
# 위 "라이브 데모" 섹션의 URL을 브라우저에서 열기
```

> **참고**: 모든 의존관계가 `index.html` 하나에 인라인됩니다.

---

## 🧠 구현 힌트

Implementation Advice가 권장하는 핵심 설계:

- {사용자 Implementation Advice 본문을 그대로 bullet 1~3개로 정리}

> **판단 기준**: {OpenCode가 어떤 선택지를 가지는지 한 줄 메모}

---

## 🤖 생성 워크플로

이 저장소는 동일한 sigco3111 코딩미션 패턴으로 작업됩니다:

1. **1차 (현재)** — README + placeholder `index.html` + `.gitignore` 생성, OpenCode 인계
2. **OpenCode가 본체 구현** — `index.html`에 본체 + 인터랙션 모두 인라인
3. **Vercel 배포 + README 다층화** — `offroad-suspension` / `optics-prism-lab` 등의 다층 README 형식으로 v1.0 완성

다른 미션 사례: [`optics-prism-lab`](https://github.com/sigco3111/optics-prism-lab) · [`offroad-suspension`](https://github.com/sigco3111/offroad-suspension) · [`heat-conduction-heatmap`](https://github.com/sigco3111/heat-conduction-heatmap) · [`neon-fluid`](https://github.com/sigco3111/neon-fluid)

---

## 📜 License

MIT © 2026 sigco3111

---

## 🙏 Acknowledgments

이 프로젝트는 [MiniMax-M3](https://example.com) 모델과 OpenCode CLI 환경에서 생성됩니다. 프롬프트 엔지니어링과 디자인 결정은 저장소 소유자가 직접 수행합니다.

- **코딩미션 참조 페이지**: [cokac.com — 코드깎는노인](https://cokac.com/list/announcement/24)
