<!--
  🚧 Under construction — OpenCode (MiniMax-M3) 가 다음 프롬프트로 작업할 예정:

  "{사용자 원본 프롬프트 verbatim — 한 줄로 압축하지 말고 줄바꿈 포함해서}"

  Implementation Advice: {핵심 조언 1~2줄}

  자세한 내용은 README.md 참조.
-->
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{프로젝트명} · {English subtitle}</title>
</head>
<body>
<p style="font-family:system-ui;text-align:center;margin-top:20vh">
🚧 Under construction. <a href="./README.md">README.md</a> 참조.
</p>
</body>
</html>
