---
name: tokscale
description: |
  Tokscale 설치/사용/두 PC 통합 워크플로. AI 코딩 어시스턴트(Claude Code, Codex, Cursor,
  OpenCode, Hermes, OpenClaw 등 30+)의 토큰 사용량과 비용을 추적·시각화·경쟁하는 CLI +
  글로벌 리더보드 (https://tokscale.ai). 동일 GitHub OAuth 기반 사용자 인증으로 **여러 PC의
  데이터를 자동 합산** — 집/회사/노트북 등 멀티 디바이스 환경에서 한 프로필로 통합 관리.
  "내 토큰 사용량 추적", "AI 비용 시각화", "리더보드 등록", "두 PC 데이터 통합", "Tokscale
  설치", "bunx tokscale" 같은 요청에 발동.
version: 1.0.1
author: sigco3111
license: MIT
metadata:
  hermes:
    tags: [tokscale, token-usage, leaderboard, multi-machine, github-oauth,
           cost-tracking, ai-coding, opencode, claude-code, hermes]
    related_skills: [ai-model-tracker, daily-self-review]
---

# Tokscale — AI 토큰 사용량 추적 + 글로벌 리더보드

> *"The Kardashev Scale for AI Devs"* — AI 개발자의 카르다셰프 스케일
> 만든 사람: [junhoyeo](https://github.com/junhoyeo) · 라이선스: MIT · ⭐ 3,815+

## 한 줄 정의

AI 코딩 어시스턴트(**30+ 클라이언트**)의 **로컬 데이터**를 읽어서 토큰 사용량 + 비용을
계산하고, **GitHub OAuth 기반 글로벌 리더보드**에 제출. **여러 PC에서 같은 GitHub 계정으로
로그인하면 데이터가 자동 합산**.

## 핵심 컨셉

```
[각 PC의 AI 에이전트 로컬 DB]
   │
   │  tok scale CLI가 직접 읽음 (DB/SQLite/JSON)
   │  → 클라이언트 SDK / API 키 불필요
   │  → 사용자 동의 1회 (GitHub OAuth)
   │
   ▼
[Tokscale 서버] — username 기준 누적, session_id로 dedup
   │
   ▼
https://tokscale.ai/{username} — 통합 프로필 + 리더보드
```

## 빠른 시작

```bash
# 1. 설치 (Bun 권장, Node 18+도 OK)
curl -fsSL https://bun.sh/install | bash    # macOS/Linux
brew install bun                              # 또는 Homebrew

# 2. 로그인 (브라우저 OAuth, GitHub 계정 1회)
bunx tokscale@latest login

# 3. 로컬 데이터 확인
bunx tokscale@latest clients
bunx tokscale@latest --light                  # 메인 리포트 (테이블)

# 4. 글로벌 리더보드 제출
bunx tokscale@latest submit --dry-run          # 미리보기
bunx tokscale@latest submit                   # 실제 제출

# 5. 프로필 확인
open https://tokscale.ai/{github-username}
```

## 두 PC 통합 (가장 흔한 사용 시나리오)

**같은 GitHub 계정으로 두 PC에 모두 로그인** → 한 프로필에 데이터 자동 누적.

| PC | 환경 | GitHub | 누적되는 데이터 |
|---|---|---|---|
| PC-A (집) | macOS | sigco3111 | OpenCode, Claude Code, Hermes, OpenClaw |
| PC-B (회사) | Linux/Windows | sigco3111 | Codex, Cursor 등 |

→ tokscale.ai/sigco3111 에서 **통합 프로필** 자동 표시.

### 시나리오별 동작

| 시나리오 | 결과 |
|---|---|
| 같은 클라이언트 (둘 다 OpenCode) | session_id 기준 dedup, 시간순 합산 |
| 다른 클라이언트 | 두 클라이언트 모두 동일 username으로 누적 |
| 같은 시간대 양쪽 PC | 별개 세션 카운트 (의도된 동작) |

### 두 PC 세팅 체크리스트

- [ ] PC-A: `bunx tokscale@latest login` → GitHub OAuth
- [ ] PC-B: 동일하게 (반드시 **같은 GitHub 계정**!)
- [ ] 양쪽에서 `bunx tokscale@latest clients` → 데이터 소스 확인
- [ ] 양쪽에서 `tokscale submit` 한 번씩 실행
- [ ] https://tokscale.ai/{username} → 통합 프로필 확인

## 핵심 명령어 (전체)

| 명령 | 용도 |
|---|---|
| `tokscale` | 메인 리포트 (TUI, `--light`로 테이블 출력) |
| `tokscale --light --json` | JSON 출력 (스크립트용) |
| `tokscale models` | 모델별 사용량 |
| `tokscale monthly` | 월간 리포트 |
| `tokscale hourly` | 시간별 리포트 |
| `tokscale clients` | 로컬 데이터 소스 + 세션 수 |
| `tokscale pricing <model>` | 모델 가격 확인 |
| `tokscale graph` | contribution graph 데이터 (JSON) |
| `tokscale tui` | 인터랙티브 TUI |
| `tokscale wrapped` | Spotify Wrapped 스타일 연간 리캡 |
| `tokscale time-metrics` | 세션 시간 메트릭 |
| `tokscale login` | GitHub OAuth 로그인 |
| `tokscale whoami` | 현재 로그인 사용자 |
| `tokscale qr` | API 토큰 QR 표시 (다른 디바이스 전달용) |
| `tokscale submit` | 글로벌 리더보드 제출 |
| `tokscale logout` | 로그아웃 |
| `tokscale delete-submitted-data` | 서버에 제출된 모든 데이터 삭제 |

### 필터 옵션

```bash
-c, --client <CLIENTS>    # 필터: opencode,claude,hermes,openclaw,codex,cursor,gpt-oss ...
    --today               # 오늘만
    --yesterday
    --week                # 최근 7일
    --month
    --since 2024-01-01    # 시작일
    --until 2024-12-31    # 종료일
    --year 2025
    --json                # JSON 출력
    --no-spinner          # AI agent / cron용 spinner 비활성
    --home /path/to/home  # 다른 home 디렉토리 데이터 읽기
```

### 커스텀 가격 (모델 가격 미등록 시)

`~/.config/tokscale/custom-pricing.json`:
```json
{
  "custom-model-name": {
    "input_cost_per_million_tokens": 0.20,
    "output_cost_per_million_tokens": 0.20,
    "cache_read_input_token_cost": 0.05
  }
}
```

## 자동화 패턴

### 셸 alias (가장 흔함)

`~/.zshrc` 또는 `~/.bashrc`에 추가:
```bash
alias tk="bunx tokscale@latest"
alias tks="bunx tokscale@latest submit"
alias tks-yes="(echo y | bunx tokscale@latest submit)"  # 비대화형
alias tkw="bunx tokscale@latest wrapped"
alias tkt="bunx tokscale@latest tui"
```

### 매일 자동 submit (cron)

```bash
crontab -e
# 매일 23:00 자동 submit
0 23 * * * /path/to/tokscale-setup/scripts/daily-submit.sh >> /path/to/tokscale-setup/logs/cron.log 2>&1
```

스크립트 본문은 `references/daily-submit-template.sh` 참조.

**필수 검증 (2026-06-19 발견 함정)**: 스크립트 파일만 만들어두고 **crontab / LaunchAgent
등록을 빠뜨리는** 경우 매우 많음. `daily-submit.sh` 가 있어도 자동 실행 안 됨.
스크립트 작성 직후 반드시 `crontab -l | grep tokscale` 로 등록 확인.

## 🔄 갱신 주기 (데이터 흐름별)

> **pull 기반 아키텍처** — 자동 갱신 없음. `submit` 실행해야 서버에 반영됨.

| 데이터 종류 | 갱신 주기 | 트리거 |
|---|---|---|
| 💾 **로컬 TUI/리포트** (`tokscale`, `daily`, `hourly`) | **매번 실시간** | CLI 실행 시 AI 클라이언트 DB 직접 읽기 |
| 💲 **LiteLLM 가격 캐시** | **1시간 disk cache** 후 자동 갱신 | `~/.config/tokscale/cache/pricing-*.json` |
| 🌐 **프로필 페이지** (`tokscale.ai/{user}`) | submit 후 **~1시간** | `tokscale submit` 실행 |
| 🎨 **GitHub 임베드 SVG** (`/api/embed/{user}/svg`) | **~1~24시간** (서버 + CDN 이중 캐시) | 프로필 페이지 갱신 이후 지연 |

### 일반적인 갱신 사이클 (cron 권장)

```
[23:00 KST] cron → daily-submit.sh
    ↓
[즉시] tokscale.ai 서버 도착
    ↓
[~1h] 프로필 페이지 반영
    ↓
[~수h~24h] GitHub README SVG 배지 반영
    ↓
[익일 23:00] 다음 자동 submit
```

### 검증 방법 (각 단계)

```bash
# 1. 로컬 캐시 갱신 시점
ls -la ~/.config/tokscale/cache/*.json | head -5

# 2. 프로필 페이지 실시간 확인
curl -s "https://tokscale.ai/api/embed/{username}/svg?template=graph&tokens=compact&cost=compact" | head -3
# (변경 시각은 svg 안에 인코딩돼 있으나 시각 검증은 웹에서)

# 3. 서버 측 마지막 submit 시각 (공개 API 한정)
# 프로필 페이지 하단 "Last updated" 타임스탬프 확인
```

## 🪤 함정: 스크립트만 있고 cron 미등록 (2026-06-19)

`tokscale-setup/scripts/daily-submit.sh` 작성 후 **crontab에 라인 추가를 빠뜨리면**
자동 실행이 절대 안 됨. 이 시점에 "크론 안 됐나?" 라고 의심조차 안 들기 쉬움
(파일 존재 = 동작 이라는 착각). 134개 repo 만들면서 다른 작업에 밀려 등록 단계를
놓치기 매우 쉬움.

**필수 자가진단 체크리스트** (스크립트 작성 직후):

```bash
# 1. 스크립트 존재 확인
test -x ~/workspace/tokscale-setup/scripts/daily-submit.sh && echo "✅ script exists" || echo "❌ missing"

# 2. crontab 등록 확인 (둘 중 하나라도 hit)
crontab -l 2>/dev/null | grep -q "tokscale-setup/scripts/daily-submit.sh" && echo "✅ crontab registered" || echo "❌ NOT in crontab"
ls ~/Library/LaunchAgents/ 2>/dev/null | grep -qi tokscale && echo "✅ LaunchAgent registered" || echo "❌ NOT in LaunchAgent"

# 3. 실행 로그 존재 확인 (한 번이라도 돌았으면)
ls ~/workspace/tokscale-setup/logs/submit-*.log 2>/dev/null | head -1
```

세 가지 모두 통과해야 비로소 "자동 submit 작동 중"이라 부를 수 있음.
미통과 시 crontab 1줄 추가:

```bash
(crontab -l 2>/dev/null | grep -v "tokscale-setup/scripts/daily-submit.sh"; \
 echo "0 23 * * * /Users/hjshin/workspace/tokscale-setup/scripts/daily-submit.sh >> /Users/hjshin/.config/tokscale/logs/cron.log 2>&1") \
 | crontab -
```

### 헤드리스 / CI 환경

```bash
# 환경변수 우선 (credentials 파일 무시)
export TOKSCALE_API_TOKEN=tt_xxxxxxxxxxxx
bunx tokscale@latest submit
# Precedence: TOKSCALE_API_TOKEN env > saved credentials file
```

### 인증서 폐기

https://tokscale.com/settings → Settings > API Tokens → "Revoke" 클릭
→ 즉시 무효화, 다음 요청부터 HTTP 401 "Invalid API token"

## 지원 클라이언트 (30+)

**주요 (자동 인식):**
- **OpenCode** (`~/.local/share/opencode/opencode.db`, legacy: `~/.local/share/opencode/storage/message/`)
- **Claude Code** (`~/.claude/projects/`, `~/.claude/transcripts/`)
- **Codex CLI** (`~/.codex/sessions/`)
- **Cursor IDE** (`~/.config/tokscale/cursor-cache/usage*.csv` — 별도 sync 필요)
- **Gemini CLI** (`~/.gemini/tmp/*/chats/*.json`)
- **Hermes Agent** (`$HERMES_HOME/state.db`, fallback `~/.hermes/state.db`) ← **우리 Hermes!**
- **OpenClaw** (`~/.openclaw/agents/`, legacy: `.clawdbot`, `.moltbot`, `.moldbot`)

**기타 지원:**
- Amp, Codebuff, Droid, Pi, Kimi CLI/Code, Qwen CLI, Roo Code, Kilo/Kilo CLI,
  Mux, Crush, Goose, Antigravity (CLI + sync), Zed Agent, Kiro, Trae IDE/Solo,
  Warp/Oz, Grok Build, Cline, gajae-code, Jcode, MiMo Code, Command Code, Synthetic

**환경변수 override:**
```bash
export HERMES_HOME=/custom/path
export CODEBUFF_DATA_DIR=/custom/codebuff
export KIMI_CODE_HOME=/custom/kimi-code
export GJC_CODING_AGENT_DIR=/custom/gjc
# 등등 — README.md "Supported Clients" 표 참조
```

## 통합 모범 사례

1. **양쪽 PC에 동일한 alias 설치** (`tk`, `tks`)
2. **하루 끝에 한 번씩 `tks`** — 습관화
3. **cron 등록** — 매일 23:00 자동 submit (놓치는 일 없음)
4. **월말에 `tkw`** — Wrapped 리캡 확인 (GitHub 카드 공유용)
5. **새 클라이언트 설치 시** → `clients` 명령으로 자동 인식되는지 확인

## 비용 계산

**[LiteLLM pricing data](https://github.com/BerriAI/litellm)** 실시간 사용:
- 티어드 가격 모델 지원
- 캐시 토큰 할인 자동 적용
- 모델별 정확한 USD 계산

가격 데이터에 없는 모델은 **$0.00**으로 표시. 위 `custom-pricing.json`으로 직접 추가.

## 주의: 환경 / 도구 함정

> ⚠️ **negative claim 금지**: 이 섹션의 함정은 2026-06-18 검증된 사실이지만, 향후 변경될
> 가능성 있음. 캡처 시점의 환경 기준이며 절대 규칙 아님.

### `bunx tokscale@latest whoami` exit code 함정

whoami는 **로그인 안 된 상태에서도 exit code 0**으로 종료하고 stderr에 "Not logged in"만
출력. 단순 `if whoami 2>/dev/null` 패턴이 **잘못된 분기**에 들어감.

**해결 — 반드시 output grep:**
```bash
WHOAMI_OUTPUT=$(bunx tokscale@latest whoami 2>&1 || true)
if echo "$WHOAMI_OUTPUT" | grep -qiE "not logged in|error"; then
  echo "⚠️ 로그인 필요"
else
  echo "✅ 로그인 됨: $(echo "$WHOAMI_OUTPUT" | tail -1)"
fi
```

### `--dry-run` 위치 함정

`--dry-run`은 **글로벌 옵션이 아님** — `submit` 서브커맨드 옵션. 글로벌 위치에서 쓰면:
```
error: unexpected argument '--dry-run' found
```

**정답:**
```bash
# ❌ 잘못
bunx tokscale@latest --dry-run

# ✅ 정답
bunx tokscale@latest submit --dry-run
```

### `--no-spinner` 위치 함정

`--no-spinner`도 글로벌 옵션. submit에서 쓰면 동일 에러. **메인 리포트 명령에서는 OK**.

### bunx 미설치 환경 (2026-06-18 검증, 자동 감지 패턴)

Bun이 없으면 `npx -y tokscale@latest`로 fallback 가능. **단순 fallback이 아니라
install.sh / daily-submit.sh / SETUP_GUIDE.md 셋이 동일한 자동 감지 패턴으로
동기화되어야 한다** — 한 곳만 고치면 다른 두 곳이 stale 상태로 남아 사용자가 혼란.

**검증된 3파일 동기화 패턴 (2026-06-18 `tokscale-setup.zip` 빌드):**

```bash
# install.sh + daily-submit.sh 공통 헤더 (POSIX 호환)
if command -v bunx >/dev/null 2>&1; then
  RUNNER="bunx"
elif command -v npx >/dev/null 2>&1; then
  RUNNER="npx -y"
else
  echo "❌ bunx도 npx도 없습니다. Node 18+ 또는 Bun 설치 필요." >&2
  exit 1
fi

# 이후 사용
$RUNNER tokscale@latest login
$RUNNER tokscale@latest submit
```

**함정 — 부분 갱신 (2026-06-18 발견)**:
- `bunx → npx -y`로 일괄 교체하려다 `command -v bunx` 실패 → `npx -y`만 가능함을
  install.sh만 patch하고 daily-submit.sh/SETUP_GUIDE.md를 빠뜨림
- 사용자가 SETUP_GUIDE.md의 예제를 따라하다 `bunx` hardcode → `command not found` 에러
- **수정**: 3파일 동기 patch (commit: `8b60d67 fix: bunx → npx -y (cron 호환)`)
- **교훈**: Node 프로젝트 셋업 시 *runner 감지 로직을 단일 함수로 추출*하고 3파일이
  같은 함수를 source하도록 만들 것. 셋업 스크립트 3종은 항상 같이 patch.

**SETUP_GUIDE.md 동기화 체크리스트**:
- [ ] 코드 블록 예제: `bunx` → `${RUNNER}` 또는 환경별 둘 다 명시
- [ ] README quickstart 섹션: `bunx` 단독 → "Bun or Node 18+" 명시
- [ ] 에러 메시지: "bunx: command not found" → "bunx/npx 모두 없으면 Node 설치 안내"

**대상 프로젝트 일반화 (2026-06-18 패턴)**: Tokscale뿐 아니라 *Node CLI를 cron으로
배포하는 모든 프로젝트*에 동일 패턴 적용 가능 — `npx -y`는 npm 패키지 즉시 실행이라
별도 설치 단계 없이 cron 호환. 적용 대상 예: AI 코딩 어시스턴트 wrapper, npm 배포
CLI 도구, 정기 실행 스크립트.

### 첫 제출 시 시간 오래 걸림

수십만 메시지를 처음 제출할 때 30초~2분. **cron에서는 절대 안 됨** — 수동 또는
캐시된 후 incremental submit만 cron으로.

### stats-cache.json 미사용

`~/.claude/stats-cache.json`은 aggregate `/usage` 데이터로 per-message attribution이
없어서 **이중 카운트 위험** → tokscale이 의도적으로 **import 안 함**. 정상이므로 놀라지 말 것.

## 관련 URL

- 웹: https://tokscale.ai
- GitHub: https://github.com/junhoyeo/tokscale
- npm: https://www.npmjs.com/package/tokscale
- Discord: https://discord.gg/h6DUGWdBbm

## 보조 파일

자세한 내용은 `references/` 참조:
- **`references/cli-options-reference.md`** — 전체 CLI 옵션 카탈로그 + 출력 예시
- **`references/daily-submit-template.sh`** — cron용 자동 submit 스크립트 템플릿
- **`references/two-pc-setup-recipe.md`** — 두 PC 세팅 상세 레시피 (희정님 2026-06-18 세션 검증)
- **`references/client-data-locations.md`** — 클라이언트별 데이터 경로 + 환경변수 override 표
- **`references/bunx-npx-fallback-2026-06-18.md`** — bunx 미설치 PC 자동 감지 → npx -y fallback 패턴 (3파일 동기화, cron 호환)
- **`references/firetoken-nim-pattern.md`** — NVIDIA NIM 무료 모델 wrapping + 4중 부스트 전략 + 컨텍스트 자동 관리 + PowerShell 구현 (2026-06-19 fireToken 검증)

## 시그널 / 트리거

이 스킬은 다음 요청 시 자동 발동:
- "내 토큰 사용량 추적"
- "AI 비용 계산"
- "Tokscale 설치"
- "bunx tokscale"
- "리더보드 등록"
- "두 PC 데이터 통합"
- "글로벌 리더보드"
- "Kardashev Scale"
- "토큰 비용 시각화"
- "AI 코딩 비용"

## 🔥 리더보드 부스트 변형 (2026-06-19 fireToken)

> "무의미하더라도 토큰 사용량을 어떻게든 늘려서 순위를 올리는 것" — KARDASHEV Scale for AI Devs 점수 게임.

사용자가 **명시적으로** "순위 올리기" 또는 "토큰 부풀리기" 같은 의도를 밝히면,
Tokscale은 단순 추적 도구에서 **부스트 전략 + 비공개 OSS** 영역으로 확장.

**핵심 통찰 4가지**:

1. **Tokscale은 30+ AI 클라이언트의 local DB만 읽음** — 직접 NIM/OpenAI API 호출은 Tokscale에 안 잡힘. 반드시 Hermes/OpenCode/Claude Code 같은 추적 대상 툴을 통해 호출해야 함.
2. **Reasoning 모델의 `thinking` 토큰도 카운트** — `reasoning_effort=high` 켜면 output이 2~5배 부풀어 오름.
3. **NIM 무료 tier 40 rpm + 컨텍스트 누적형 자동화** = 일 ~1~2B 토큰 가능 (top 1~5% 글로벌).
4. **NIM gpt-oss-120b는 MoE 36 layers + 120K 컨텍스트 + reasoning 지원** (HF config 2026-06-19 검증).

**4중 부스트 전략 (fireToken v0.1.0, 2026-06-19 검증)**:

| 전략 | 효과 | 구현 |
|---|---|---|
| **A. Reasoning 폭발** | output 30K→60K (2배) | `reasoning_effort=high` |
| **B. 입력 부풀리기** | +100K input/req | system prompt에 junk text 주입 |
| **C. 재귀 루프** | 컨텍스트 한도까지 | output → 다음 input (지수적) |
| **D. 병렬 N세션** | ×N throughput | PowerShell `Start-Job` × N |

**예상 throughput**:

| 모드 | 일일 토큰 | 글로벌 순위 |
|---|---|---|
| 1세션, 단순 | 170M | top 30% |
| 5세션 병렬 | 860M | top 10% |
| 5 + A+B+C | 1.3B | top 5% |
| **5 + A+B+C+D 풀옵션** | **2.5B (이론)** | **top 1%** |

**컨텍스트 자동 관리 (120K 한도, `references/firetoken-context-management.md` 참조)**:
- 80K → slide (70% keep)
- 100K → reset (system prompt만)
- 120K → hard reset (새 세션 ID)

**부스트 OSS 위치**:
- 비공개 repo: `sigco3111/fireToken` (2026-06-19, v0.1.0)
- 부트스트랩 절차: `python-oss-bootstrap` 스킬의 "Windows native 변형" 참조
- README에 의도/면책 명시 (윤리적 가치 없음 + KARDASHEV Scale 점수 게임 + 사용자 책임)

## 🆕 모델 등록: NVIDIA NIM 무료 모델 (2026-06-19 추가)

NIM `openai/gpt-oss-120b`는 **무료** + **reasoning 지원**으로 부스트 자동화의 핵심 모델.

**지원 NIM 모델 (2026-06-19 검증)**:
- `openai/gpt-oss-120b` — MoE 36 layers, 120K 컨텍스트, reasoning 지원, 무료 40 rpm
- `openai/gpt-oss-20b` — 같은 시리즈의 작은 모델
- 기타 100+ 모델: https://integrate.api.nvidia.com/v1/models

**Litellm pricing 등록 여부**: 2026-06-19 시점 LiteLLM pricing에 NIM 모델 가격 정보가 일부만 등록. 미등록 시 Tokscale은 `$0.00`으로 표시. **NIM 무료 티어 사용 시 비용 0이라 문제 없음** — `custom-pricing.json` 등록 불필요.

**API 응답 패턴** (`gpt-oss-120b`, OpenAI 호환):
```json
{
  "id": "resp_xyz",
  "model": "openai/gpt-oss-120b",
  "output": [{"type": "message", "content": [{"type": "output_text", "text": "..."}]}],
  "reasoning": {"effort": "high", "summary": "..."},
  "usage": {
    "input_tokens": 100023,
    "output_tokens": 23,
    "reasoning_tokens": 47,    // ← output 합산되어 Tokscale 카운트
    "total_tokens": 100093
  }
}
```

**토큰 카운트 검증 방법** (Tokscale에 잡히는지):
```bash
# 1. 추적 대상 클라이언트에서 gpt-oss-120b 호출 (예: OpenCode, Hermes)
# 2. macOS에서
bunx tokscale@latest --light --json | jq '.[] | select(.model | contains("gpt-oss"))'
# 3. 클라이언트별 확인
bunx tokscale@latest --client opencode --light
bunx tokscale@latest --client hermes --light
```

**NIM API 키 발급**:
- https://build.nvidia.com/openai/gpt-oss-120b → "Get API Key"
- 환경변수: `NVIDIA_API_KEY=nvapi-xxxx`
- 40 rpm 무료 (NIM 정책, 향후 변경 가능)