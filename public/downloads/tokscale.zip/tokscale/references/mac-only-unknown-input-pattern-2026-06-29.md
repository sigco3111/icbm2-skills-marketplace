# macOS에서만 누적되는 "Claude Code unknown Input" 패턴 (2026-06-29 진단)

## 증상

Tokscale 대시보드에서:
- 사용자가 **Claude Code를 한 번도 실행 안 했는데도** `Claude Code` 클라이언트에 Input 토큰이 매일 일정량 누적됨
- 모델명은 항상 **`unknown`**으로 표시됨 (비용 $0.00)
- **macOS에서만** 발생. Windows만 켰을 때는 누적 0
- OpenCode/oh-my-openagent는 정상적으로 카운트됨 (별도 행)

## 1분 진단 명령

```bash
# 1) transcripts 파일 중 가장 최근 것의 첫 줄 (실제 모델 정보 박혔는지)
f=$(ls -t ~/.claude/transcripts/*.jsonl 2>/dev/null | head -1)
[ -n "$f" ] && head -1 "$f" | python3 -c "
import sys, json
o = json.loads(sys.stdin.read())
print('keys:', list(o.keys()))
print('has message?', 'message' in o)
print('has model?', bool(o.get('message', {}).get('model')))
"

# 2) transcripts의 메시지 타입 통계 (tool_use만 많고 assistant 거의 0이면 미러링)
head -1 ~/.claude/transcripts/*.jsonl 2>/dev/null | python3 -c "
import json, sys
from collections import Counter
c = Counter()
for line in sys.stdin:
    try:
        o = json.loads(line.split(': ', 1)[1] if ': ' in line and not line.startswith('{') else line)
        c[o.get('type')] += 1
    except: pass
print(dict(c.most_common(5)))
"

# 3) OpenCode storage에 동일 세션 ID 공유 확인 (증거)
for sid in $(ls -t ~/.claude/transcripts/*.jsonl 2>/dev/null | head -2 | xargs -n1 basename); do
  base=${sid%.jsonl}
  echo "SID=$base"
  find ~/.local/share/opencode -name "$base*" 2>/dev/null
done
```

세 가지 모두 "모델 없음 / tool_use 위주 / OpenCode와 SID 공유" 패턴이면 이 함정 확정.

## 근본 원인

**`oh-my-openagent` 플러그인이 OpenCode 세션을 `~/.claude/transcripts/`로 미러링**하면서, 거기에 다음 두 가지 데이터 형식 문제가 동시에 발생:

1. **모델 식별 정보 부재**: 미러된 transcripts는 표준 `{type, message: {role, model}}`가 아니라 `{type, timestamp, content}` 평탄 구조. `message.usage`도 없음 → tokscale이 input_tokens를 raw content 길이에서 근사 추정, model은 "unknown".
2. **assistant 메시지 0개, tool_use 위주**: 정상 Claude Code transcripts라면 assistant 메시지가 user보다 많음. 미러본은 OpenCode의 tool 호출만 캡처하므로 assistant 호출 흔적이 거의 없음.

```bash
# OpenCode가 active한지 확인
ls -la ~/.local/share/opencode/opencode.db 2>/dev/null
test -f ~/.config/opencode/oh-my-openagent.json && echo "oma yes"
```

## 왜 Mac만 누적되는가

`oh-my-openagent` 플러그인은 **macOS에만 설치**되어 있음 (`~/.config/opencode/oh-my-openagent.json` 존재). Windows에서 OpenCode는 작동해도 이 플러그인이 없어 transcripts 미러링이 일어나지 않음 → 누적 0.

## 영향 진단

| 항목 | 상태 |
|---|---|
| 실제 사용한 모델은 다른 행(OpenCode/Hermes 등)에 정상 카운트됨 | 정상 |
| `unknown`은 이 미러본 때문이고 입력 토큰은 raw 길이 근사치 | 노이즈 |
| 비용 계산은 $0.00 (model 식별 불가) | 영향 없음 |
| 글로벌 리더보드 점수에 영향? | 토큰 수는 합산되므로 점수 부풀 가능 |

## 조치 옵션

| 옵션 | 효과 | 부작용 |
|---|---|---|
| A. tokscale exclude로 `~/.claude/transcripts` path mask | unknown 즉시 사라짐 | `--client claude` 리포트 비게 됨 |
| B. oh-my-openagent의 transcripts writer 코드 찾아 비활성화 | 진짜 Claude Code 사용만 카운트 | 플러그인 fork/upstream patch 필요 |
| C. 그대로 두고 보기 | 그래도 누적됨 | 대시보드 노이즈 (사용자 2026-06-29 결정) |

## 디버깅 핵심 (30초 안에 답 나오는 패턴)

> "Claude Code 안 썼는데도 Input이 잡힌다" → **`~/.claude/transcripts/`의 파일 중 하나를 `head -1` 후 `message` 키 존재 여부 확인**. 없으면 미러본, 이 함정 확정.

## 환경 의존 메모리

- `~/.claude/transcripts/`: Claude Code native transcripts (정상) + oh-my-openagent 미러본 (이상). 같은 폴더에 섞여 있음
- `~/.local/share/opencode/opencode.db`: OpenCode SQLite (정상 카운트 소스)
- `~/.local/share/opencode/storage/`: oh-my-openagent 메타데이터 (세션 ID 공유 증거 위치)
- `~/.config/opencode/oh-my-openagent.json`: 플러그인 정의