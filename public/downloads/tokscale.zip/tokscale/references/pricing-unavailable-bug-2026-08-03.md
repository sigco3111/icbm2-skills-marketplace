# Tokscale `submit` 거부 — `pricing is unavailable for submitted token usage`

> 토큰 가격 lookup이 batch 전체를 거부하는 패턴. 2026-08-03 첫 보고 (`junhoyeo/tokscale#1021`).
> Tokscale 소스 (`crates/tokscale-core/`, v4.9.0) 차원에서 진단한 결과.

## 증상

```sh
bunx tokscale@latest submit
# Scanning local session data...
# Error: pricing is unavailable for submitted token usage:
# github-copilot/oswe-vscode-prime,
# google/gemini-3-pro-preview, x17,
# nvidia/minimaxai/minimax-m2.7, xN,
# zai/glm-4.5-flash
```

> 💡 **다른 PC에서도 같은 에러** 또는 모델 목록만 다르게 발생함 (캐시 1h 만료 영향).

## 한 줄 진단

**Tokscale `validate_priced_messages`는 batch 통째 거부** (partial fail 아님).
토큰이 있고 + 가격 lookup 실패 + authoritative cost 없으면 1개 행만 걸려도
전부 fail. → 토큰 카운트 자체는 정확한데 가격 모를 때도 **submit이 영구 막힘**.

## 핵심 4가지 발견 (tokscale v4.9.0 소스)

| # | 파일:라인 | 코드 | 의미 |
|---|---|---|---|
| 1 | `crates/tokscale-core/src/lib.rs:2950-2992` | `validate_priced_messages` | 한 행이라도 미가격이면 **batch 전체 거부** |
| 2 | `crates/tokscale-core/src/pricing/mod.rs:26` | `const EXCLUDED_LITELLM_PREFIXES: &["github_copilot/"]` | LiteLLM의 `github_copilot/*` 키를 **의도적으로 데이터셋에서 제거** (구독 모델, $0.00라 per-token 무의미) |
| 3 | `crates/tokscale-core/src/pricing/custom.rs:81-87` | `if !input_cost_per_token.is_some_and(\|v\| v > 0.0) && !output_cost_per_token.is_some_and(\|v\| v > 0.0) { return Err(...) }` | **`custom-pricing.json`이 0/null 거부** → escape hatch 무용 |
| 4 | `crates/tokscale-core/src/pricing/lookup.rs:6-48` | `PROVIDER_PREFIXES` / `RESELLER_PROVIDER_PREFIXES` | `github-copilot/`, `nvidia_nim/`, `zai/` 화이트리스트 부재 → prefix strip 안 됨 |

## 4개 모델 ID별 원인 분해

### `github-copilot/oswe-vscode-prime` ❌ 정직 가격 없음

- **공식 가격 미공개**: Verdent 사이트 (`verdent.ai/pricing`), GitHub Copilot docs,
  OpenRouter 전부 OSWE/prime 가격 정보 없음.
- Verdent 상품 구조는 **월 구독 + 크레딧 모델** (per-token 가격 노출 X).
- LiteLLM에 등록 가능: **NO** (가짜 데이터 = LiteLLM 신뢰성 훼손).
- 진짜 해결책: Tokscale 옵션 `--prune-unpriced` (해당 행만 drop) 또는
  `--allow-zero-cost` (가격 $0 강제 통과) — 현재 미존재.

### `nvidia/minimaxai/minimax-m2.7` ❌ NIM catalog에 미존재

- `https://integrate.api.nvidia.com/v1/models` (102개 모델) 검색: **m2.7 모델 없음**.
- NIM MiniMax-* 라우팅은 `minimaxai/minimax-m3` 1개만 catalog 등재.
- LiteLLM에는 `sambanova/MiniMax-M2.7`, `fireworks_ai/MiniMax-M2.7` 등 **타 벤더** 호스팅 키만 존재 (NVIDIA 호스팅 아님).
- **사용자 PC의 OpenCode/Hermes가 잘못된 ID 보고 중** — 클라이언트 측 alias 오류 가능성.
- 정직 추가: LiteLLM에 `nvidia/minimaxai/minimax-m2.7` 가짜 등록 **절대 금지**.
- 진짜 해결책: OpenCode/Tokscale 측에서 비표준 ID 라우팅 정상화.

### `google/gemini-3-pro-preview`, `zai/glm-4.5-flash` ⚠️ 이미 등록됨

- LiteLLM `model_prices_and_context_window.json`에 정상 등재 (총 2986 키).
- `gemini-3-pro-preview`: vertex/openrouter 등 **7개 provider 변형** 포함, 가격 $2/M input, $12/M output.
- `zai/glm-4.5-flash`: litellm_provider="zai", **공짜 티어 (가격 0)** — `has_any_usable_base_rate()` 통과 ($0 ≥ 0).
- 다른 PC 에러는 **Tokscale 캐시 1h 만료 전이면 정상 hit**, 만료 후 재시도 시 정상.

## 캐시 진단 + 리셋

```bash
# 캐시 위치
ls -la ~/.config/tokscale/cache/pricing-*.json 2>/dev/null   # Linux
ls -la ~/Library/Application\ Support/tokscale/cache/ 2>/dev/null  # macOS
ls "%APPDATA%\tokscale\cache\"  # Windows

# 캐시 강제 리셋 → 다음 submit 시 LiteLLM 재다운로드
rm -f ~/.config/tokscale/cache/pricing-*.json
# 또는 macOS
rm -f ~/Library/Application\ Support/tokscale/cache/pricing-*.json
```

## Issue 보고 — `junhoyeo/tokscale#1021` (2026-08-03 등록)

요약:
1. 4개 모델 ID lookup 실패 (위 표 그대로)
2. `validate_priced_messages`의 hard-fail semantics 변경 요청:
   - 미가격 행을 batch에서 drop (옵션 `--prune-unpriced`)
   - $0/null 강제 통과 (옵션 `--allow-zero-cost`)
3. `custom-pricing.json`이 0/null 수용하도록 (`pricing/custom.rs:81-87` 완화)
4. `EXCLUDED_LITELLM_PREFIXES` → 옵션화 또는 authoritative-cost 메시지 캐리어 추가

## 즉시 워크어라운드 (Tokscale PR 머지 전)

`~/workspace/tokscale-pricing-workaround/install.sh` 가 이 레포에 첨부됨:

```bash
bash ~/workspace/tokscale-pricing-workaround/install.sh
```

→ macOS `~/Library/Application Support/tokscale/custom-pricing.json`,
Linux `~/.config/tokscale/custom-pricing.json` 으로 사본 설치.

⚠️ **주의**: 현재 Tokscale은 0 가격을 거부하므로 **이 워크어라운드는 "가격 $0" 정책
변경 전까지는 작동 안 함**. PR 머지 후 자동 유효화. 그 전까지는 cron submit이
당분간 막혀 있어도 토큰 카운트는 `tokscale --light` 로컬 리포트로 확인 가능.

## LiteLLM 측 작업 (비권장)

- `gemini-3-pro-preview`, `zai/glm-4.5-flash`는 **이미 등록됨** → PR 만들 가치 없음.
- `github-copilot/oswe-vscode-prime`, `nvidia/minimaxai/minimax-m2.7`는 **공식 가격 없음** → LiteLLM PR로 가짜 등록 절대 금지.
- LiteLLM 측 변경 없이 **Tokscale 옵션화만으로 해결 가능**.

## 교훈 / 회고

1. **PR 보내기 전 issue로 가이드라인 확인** — 가격 데이터 없는 모델은 maintainer 응답 없이 PR 보내면 reject + 시간 낭비. 1~2주 issue 대기가 더 빠름.
2. **`validate_priced_messages` 같은 hard-fail 의도 분석 먼저** — 소스 안 열어보고 "그냥 모델 추가하면 되는 거 아냐?" 가정 함정. v4.9.0 라이브러리가 의도적으로 subscription prefix를 LiteLLM에서 빼고 있다는 사실은 주석 안 읽으면 모름 (`pricing/mod.rs:22-26`).
3. **custom-pricing.json escape hatch 작동 여부 검증 먼저** — README만 믿고 진행했다가 시간 낭비. `0.0` 제약은 `pricing/custom.rs:81-87` 확인으로 사전 검증 가능.
4. **delegate_task 병렬 활용** — 3개 (조사 2 + 검증 1) 동시 dispatch, 메인 컨텍스트 부담 최소화. 모델 ID 검증과 소스 진단이 의존성 없어서 안전하게 병렬화 가능.

## 재현 환경 (다른 PC 진단 시 참고)

- Tokscale v4.9.0 (`3311b492`)
- Bundled CLI via `bunx tokscale@latest` 또는 `npx -y tokscale@latest`
- 두 머신 (macOS + Windows) 모두 재현, 캐시 리셋 후 일관됨.
- 영향 클라이언트: OpenCode (NIM cat.), Hermes (`nvidia/...` reroute), Codex CLI (`zai/...`).
