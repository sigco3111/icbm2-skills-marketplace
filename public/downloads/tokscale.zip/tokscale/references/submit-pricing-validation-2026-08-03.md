---
name: tokscale submit pricing validation internals
version: 1.0.0
captured: 2026-08-03
applies_to: tokscale-cli (Rust) v4.9.x+, the submit command path
---

# `tokscale submit` 가격 검증 internals (2026-08-03 캡처)

> 사용자가 `submit` 시 받는 `pricing is unavailable for submitted token usage: …` 에러가
> 정확히 어디서 발생하고, 어떤 모델 ID가 어떻게 정규화된 뒤 LiteLLM과 대조되는지 정리.
> 출처: `junhoyeo/tokscale` `crates/tokscale-core` @ `3311b492` (v4.9.0).

## 1. 에러 메시지의 정확한 발신처

`crates/tokscale-core/src/lib.rs`:

| 메시지 | 라인 | 발화 조건 |
|---|---|---|
| `"pricing data is unavailable for submission"` | **L2955** | `pricing: Option<&PricingService>` 가 `None` 으로 들어옴 (모든 소스 fetch 실패 + 캐시도 없을 때) |
| `"pricing is unavailable for submitted token usage: {unpriced}"` | **L2987-2990** | `validate_priced_messages` 가 (model_id, provider_id) 페어를 가격표에서 못 찾은 메세지가 ≥ 1개일 때 |

### `validate_priced_messages` 발화 조건 (`lib.rs:2950-2992`)

```rust
fn validate_priced_messages(messages, pricing) -> Result<(), String> {
    let Some(pricing) = pricing else { return Err("pricing data is unavailable for submission"...); };  // L2955

    let unpriced = messages.iter().filter(|m| {
        let t = &m.tokens;
        let token_bearing = t.input > 0 || t.output > 0 || t.cache_read > 0 || t.cache_write > 0 || t.reasoning > 0;
        token_bearing
            && !m.has_authoritative_cost()                                              // L2968 — ProviderReported 만 면제
            && !pricing.covers_usage_with_provider(&m.model_id, Some(&m.provider_id), &m.tokens)  // L2969
    }).map(|m| if m.provider_id.is_empty() { m.model_id.clone() } else { format!("{}/{}", m.provider_id, m.model_id) })
    .collect();

    if unpriced.is_empty() { Ok(()) } else { Err(format!("pricing is unavailable for submitted token usage: {}", unpriced.join(", "))) }
}
```

**호출 지점**: `lib.rs:2865-2866` — `build_graph_from_messages` 가 `GraphPricingRequirement::Submission` 일 때만.
이 플래그는 `generate_submission_graph` (`lib.rs:2934`) 에서만 켜지며, 이는 **오직** `tokscale-cli/src/main.rs:5514` 의 submit 명령 경로에서 호출됨.
**`generate_graph` / TUI / 리포트는 `Lenient`** — 같은 모델이 메세지에 있어도 submit 만이 reject 함.

## 2. 핵심 동작 정리

### (a) skip / zero-cost vs whole-batch block
**Whole-batch block.** unpriced 리스트가 비어있지 않으면 `validate_priced_messages` 가 즉시
`Err(...)` 반환, submit 전체가 실패. 부분 제출 없음. 메세지 1개라도 가격이 없으면 배치 전체 거부.

### (b) 면제 조건 (`has_authoritative_cost`, `sessions/mod.rs:394-400`)
오직 `cost_source == CostSource::ProviderReported` 일 때만 면제.
이는 **에이전트 런타임이 자기 usage API 에서 보고한 cost**(예: Anthropic / OpenAI usage 콜)를 그대로 쓰는 메세지.
**`cost: 0.0` 으로 추정된 row는 면제 아님** — 여전히 가격이 매겨졌는지 검증.
따라서 "unknown 모델 row 비용 0으로 보내지냐" 가 아니라 **"가격 정보를 찾을 수 없으니 배치 거부"**.

### (c) `0` vs `null` vs missing vs lookup miss
`crates/tokscale-core/src/pricing/litellm.rs:32-39` 의 `covers_usage`:

```rust
let valid_rate = |rate: Option<f64>| rate.is_some_and(|r| r.is_finite() && r >= 0.0);
(usage.input  <= 0 || valid_rate(self.input_cost_per_token))
&& (usage.output <= 0 && usage.reasoning <= 0 || valid_rate(self.output_cost_per_token))
&& (usage.cache_read <= 0 || valid_rate(self.cache_read_input_token_cost))
&& (usage.cache_write <= 0 || valid_rate(self.cache_creation_input_token_cost))
```

| 케이스 | 결과 |
|---|---|
| 명시적 `0.0` rate | **성공** (`>= 0.0` 통과) |
| `null`/missing field + 사용된 버킷 | **실패** |
| NaN/inf | **실패** |
| lookup miss 자체로는 불충분 — 메세지의 사용된 토큰 버킷에 대한 base rate 가 양수 finite 여야 함 |

## 3. 모델 ID 정규화 룰 (lookup.rs)

`pricing/lookup.rs:6-18` 의 `PROVIDER_PREFIXES` 에 다음 prefix 가 등록되어 있어 exact match 실패시 자동 strip 후 재조회:

```
openai/  anthropic/  google/  meta-llama/  mistralai/  MiniMax/
deepseek/  qwen/  cohere/  perplexity/  x-ai/
```

**`github-copilot/`, `github_copilot/` 둘 다 이 리스트에 없음** — 자동 strip 후 재조회 대상 아님.

대신 `pricing/lookup.rs:1800-1806` 의 `strip_generic_provider_prefix` 가 일반 우회:
id 에 `/` 가 있으면 **terminal segment** (`rsplit('/').next()`) 를 다시 lookup 시도.
즉 `anthropic/claude-sonnet-4` → `claude-sonnet-4` 재시도는 동작. 그러나
`copilot` 세션의 실제 메세지 형태는 `model_id="claude-sonnet-4"` + `provider_id="github-copilot"`
(sessions/copilot.rs:459-462 — `inferred_provider_from_model(...).unwrap_or("github-copilot")`)
로 provider_id 가 **별개 필드**이므로 strip 단계까지 가지 않음. 즉 ID 자체엔 prefix 가 없다.

### `provider_id == "github-copilot"` 인 실제 lookup 경로
1. `validate_priced_messages` → `pricing.covers_usage_with_provider(model_id, Some("github-copilot"), usage)`
2. `PricingService::lookup_with_source_and_provider(model_id, None, Some("github-copilot"))`
3. `lookup_with_source_and_provider` (lookup.rs:321) → `do_lookup` = `lookup_auto` (force_source=None 이므로)
4. `lookup_auto` (lookup.rs:423) → `lookup_provider_scoped_path` (model_id 가 `accounts/...` 형태일 때만)
5. 실패 시 `strip_known_provider_prefix(model_id)` — 단 model_id 에 prefix 가 없으니 None
6. `exact_match_litellm(model_id)` — LiteLLM 데이터셋에서 lowercase 일치 키 검색
7. (소진) `choose_best_source_result(...)` → openrouter/models.dev 까지
8. 최종 None → `validate_priced_messages` 가 이 row 를 unpriced 로 표시

**요약**: `provider_id` 는 "힌트" 로 사용되어 정확 매칭 위치를 좁히는 역할이지,
model_id 에 prefix 자동 strip 을 유발하지 않음. 따라서 `provider_id` 와 model_id 가
LiteLLM 키 형식과 맞지 않으면 무조건 lookup miss.

## 4. 핵심 함정: `github_copilot/` 의 의도적 차단

`pricing/mod.rs:22-26, 91-103`:

```rust
const EXCLUDED_LITELLM_PREFIXES: &[&str] = &["github_copilot/"];

/// Provider prefixes in LiteLLM data that use subscription-based pricing ($0.00)
/// and should be excluded from pay-per-token cost estimation.
fn filter_litellm_data(mut data) -> … {
    data.retain(|key, _| {
        let lower = key.to_lowercase();
        !EXCLUDED_LITELLM_PREFIXES.iter().any(|p| lower.starts_with(p))
    });
    data.retain(|_, p| p.has_any_usable_base_rate());
    data
}
```

- LiteLLM raw JSON 에 들어있는 모든 `github_copilot/*` 키가 **in-memory dataset 단계에서 제거됨**.
- 이유: Copilot 은 구독제 ($0/토큰) 이라 per-token 가격 추정이 무의미.
- **부작용**: 만약 세션이 `model_id = "github_copilot/some-model"` 같은 prefix 형태 그대로 보내고,
  같은 이름이 LiteLLM 에만 있고 다른 prefix(key 어디에도) 없다면, lookup miss + submit reject.
- 진짜 case: `provider_id="github-copilot"` 이지만 `model_id="claude-sonnet-4"` (bare) 라서 LiteLLM 의
  `claude-sonnet-4` 키에 잡힘 → 정상 통과.

## 5. 가격 소스 URL 템플릿

| 소스 | 모듈 | URL | 캐시 |
|---|---|---|---|
| **LiteLLM** | `pricing/litellm.rs:6-7` | `https://raw.githubusercontent.com/BerriAI/litellm/main/model_prices_and_context_window.json` | `pricing-litellm.json` 1h TTL (`pricing/cache.rs:6`) |
| **OpenRouter** | `pricing/openrouter.rs` | `https://openrouter.ai/api/v1/models` (+ 가격 매핑) | `pricing-openrouter.json` 1h TTL |
| **models.dev** | `pricing/models_dev.rs` | `https://models.dev/api.json` | `pricing-models-dev.json` 1h TTL |
| **Custom** | `pricing/custom.rs` | `~/.config/tokscale/custom-pricing.json` | 디스크 직접 |
| **Bundled overrides** | `pricing/mod.rs:109-195` | 하드코드 (Cursor composer*, gpt-5.3*, Sakana fugu-ultra) | 빌트인 |

세 동적 소스 모두 독립적으로 실패 시 stale cache → 빈 `HashMap` 으로 degrade.
LiteLLM 만 죽어도 OpenRouter/models.dev 가 가격을 가지고 있으면 정상 작동 (#1002 회귀 테스트 보장).

## 6. 진단 / 조치 의사결정 트리

`submit` 이 `pricing is unavailable for submitted token usage: A, B` 로 실패할 때:

```
A 의 형태: "provider/model"  또는  "model"
   │
   ├─ model_id 에 prefix 가 보임 (`github_copilot/foo`, `copilot/foo` 등)
   │  → 그 prefix 는 strip 후보(PROVIDER_PREFIXES)에 없는가?
   │      ├─ YES → lookup miss. 사용자 옵션:
   │      │    1. 해당 모델을 LiteLLM 에 추가 (https://github.com/BerriAI/litellm PR)
   │      │    2. custom-pricing.json 에 키 추가 (모델 ID 그대로)
   │      │    3. 에이전트/세션 측에서 model_id 를 정규화 (e.g. prefix 제거) 하도록 수정
   │      └─ NO (openai/, anthropic/, ... 중 하나)
   │          → strip_generic_provider_prefix 가 이미 자동 시도하지만 실패.
   │            LiteLLM/OpenRouter 키 매핑이 stale 한 케이스 → upstream PR.
   │
   └─ model_id 가 bare (`claude-sonnet-4`), provider_id 가 별도 (`github-copilot`)
      → LiteLLM 에 `claude-sonnet-4` 키가 있는가?
          ├─ YES 인데도 실패 → stale 캐시 (1h TTL). `~/.config/tokscale/cache/pricing-litellm.json`
          │  삭제 + 재시도. 또는 LiteLLM 데이터셋에 `has_any_usable_base_rate()` false 인 entry
          │   가 섞여있는 케이스 (`pricing/litellm.rs:80` 의 retain 단계).
          └─ NO → custom-pricing.json 으로 fallback.
```

### 자주 발생하는 패턴 3가지

1. **신규 모델 (LiteLLM PR 머지 후 1시간 이내)**: 캐시 만료 대기 또는 `pricing-litellm.json` 삭제.
   `tokscale submit --provider litellm` 으로 강제하면 stale 우회 가능 여부 확인.

2. **subscription-based provider 의 row (`copilot`, `cursor` 일부 tier)**:
   `EXCLUDED_LITELLM_PREFIXES` 또는 `pricing/mod.rs` 의 override 정책 의도적 차단. **이건 정상**.
   해결책: 해당 row 의 provider_id 를 verify 후 `client_cost_overrides` 또는 custom-pricing.json
   으로 가격 0 명시 → has_authoritative_cost 는 안되지만 `covers_usage` 가 0 rate 를 valid 로 인정.

3. **"github-copilot/foo" 같은 비표준 model_id**:
   가장 흔한 버그. tokscale 은 prefix 자동 strip 안함 → upstream 에 모델 키 추가가 정답.

## 7. 디버깅 명령

```bash
# 1. 메시지에 들어있는 model_id / provider_id 추출 — submit 직전 dry-run 으로 확인
bunx tokscale@latest submit --dry-run --json 2>&1 | jq '.graph.models | to_entries[] | {key: .key, sample: .value.samples[0]}'

# 2. 특정 모델의 가격 lookup 결과 직접 보기
bunx tokscale@latest pricing "<model-id>"                # 옵션 flag에 따라 custom/litellm/openrouter/models.dev

# 3. 캐시 초기화 (1h TTL 무시하고 재다운로드)
rm -rf ~/.config/tokscale/cache/pricing-*.json
# 이후 다음 submit 이 전체 가격 재페치 → ~수 초~1분 (LiteLLM JSON ~5MB)

# 4. provider 강제 (특정 소스만)
bunx tokscale@latest submit --provider litellm    # 값: custom | litellm | openrouter | models.dev
```

## 8. 다음 submit 시 권장 우선순위

1. **먼저 dry-run 으로 offending 모델 ID 확인** — 4 에러 메시지들이 같은 모델에 대한 것인지 다른 모델 4개인지.
2. **여러 모델 → LiteLLM upstream PR 후보** (정석). 캐시 초기화 후 재시도.
3. **단일 모델 / 사내 모델 → custom-pricing.json** (1~2 모델은 여기서 끝).
4. **prefix 형태가 일관되게 잘못 들어오는 경우** → tokscale upstream 이슈:
   "model_id prefix 자동 strip 후보에 `github-copilot/`, `<my-proxy>/` 등 추가" 또는
   "validate_priced_messages 가 unknown row 를 zero-cost 로 보내도록 옵트인" 같은 개선.

## 9. 토큰 사용량 추적 자체에는 영향 없음

이 에러는 **submit 단계의 가격 검증** 실패이지, 로컬 집계나 --light 리포트와 무관.
`tokscale --light`, `tokscale models`, `tokscale monthly` 등은 같은 PricingService 를 쓰지만
`Lenient` 요구사항이므로 unpriced row 도 그대로 표시됨. **리더보드에만 안 올라감**.
즉 `submit` 만 막히고 로컬 사용량 추적은 정상.
