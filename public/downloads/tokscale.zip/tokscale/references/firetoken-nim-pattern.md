# fireToken — NIM 무료 모델 + 컨텍스트 자동 관리 패턴

> 2026-06-19 fireToken v0.1.0 부트스트랩 세션에서 검증된 NIM wrapping 패턴.
> "리더보드 부스트" 변형의 핵심 기술 노트.

## 🎯 핵심 발견 4가지

### 1. NIM gpt-oss-120b 기본 사양 (HF config 2026-06-19 검증)

```json
{
  "architectures": ["GptOssForCausalLM"],
  "attention_bias": true,
  "head_dim": 64,
  "hidden_size": 2880,
  "initial_context_length": 4096,   // 학습 시 초기
  "experts_per_token": 4,           // MoE
  "layer_types": ["sliding_attention", "full_attention", ...]  // 36 layers
}
```

- **실제 운영 한도**: 120K 컨텍스트 (학습은 128K, NIM에서 120K cap)
- **아키텍처**: MoE (36 layers, sliding + full attention 혼합)
- **reasoning**: ✅ OpenAI Responses API 형식 (`reasoning.effort: high`)
- **가격**: 무료 (NIM 정책)
- **rpm 한도**: 40 (key당)

### 2. REST API 패턴 (OpenAI 호환)

```bash
# chat/completions 엔드포인트 (OpenAI SDK 호환)
POST https://integrate.api.nvidia.com/v1/chat/completions
Authorization: Bearer $NVIDIA_API_KEY
Content-Type: application/json

{
  "model": "openai/gpt-oss-120b",
  "messages": [...],
  "max_tokens": 65536,
  "temperature": 1.0,
  "reasoning_effort": "high"   # ← 핵심
}
```

**응답 (실측)**:
```json
{
  "id": "resp_xyz",
  "model": "openai/gpt-oss-120b",
  "output": [{"type": "message", "content": [{"type": "output_text", "text": "..."}]}],
  "reasoning": {"effort": "high", "summary": "Used distributive property..."},
  "usage": {
    "input_tokens": 100023,
    "output_tokens": 23,
    "reasoning_tokens": 47,   // ← output 합산 (Tokscale 카운트)
    "total_tokens": 100093
  }
}
```

### 3. 4중 부스트 전략 (전체 시뮬레이션)

| 전략 | 효과 | 1회당 | 분당 | 일일 |
|---|---|---|---|---|
| A. Reasoning | 30K→60K output (2배) | 60K | 600K | 860M |
| B. 입력 부풀리기 | +100K input | 100K | 1M | 1.4B |
| C. 재귀 루프 | 컨텍스트 한도까지 | ×1.6 | ×1.6 | ×1.6 |
| D. 5세션 병렬 | ×5 throughput | ×5 | ×5 | ×5 |

**A+B+C+D 풀옵션** (이론): 일 ~12B 토큰  
**현실 throttle** (40 rpm × 컨텍스트 관리 오버헤드): 일 1~3B 토큰

### 4. 컨텍스트 자동 관리 임계치

```
0K ─────────── 80K ─────────── 100K ────────── 120K (CAP)
│              │                │                │
│   safe       │   warning      │   critical     │
│   (신규 세션) │   (슬라이딩)   │   (강제 초기화) │
```

| 구간 | 누적 input | 동작 | 우선순위 |
|---|---|---|---|
| 0~80K | 여유 | 정상 진행 | 🟢 |
| 80~100K | 67~83% | **자동 슬라이딩** (γ 정책) | 🟡 |
| 100~120K | 83~100% | **자동 /new-session** (β 정책) | 🔴 |
| 120K 초과 | 100%+ | API 400 → 즉시 초기화 | 🚨 |

## 🔧 PowerShell 구현 패턴 (검증됨)

### NIM 호출 (Invoke-RestMethod)

```powershell
$body = @{
    model = "openai/gpt-oss-120b"
    messages = $messages
    max_tokens = 65536
    temperature = 1.0
    top_p = 1.0
    stream = $false
} | ConvertTo-Json -Depth 20

$headers = @{
    "Authorization" = "Bearer $ApiKey"
    "Content-Type" = "application/json"
    "Accept" = "application/json"
}

$response = Invoke-RestMethod `
    -Uri "https://integrate.api.nvidia.com/v1/chat/completions" `
    -Method Post `
    -Headers $headers `
    -Body $body `
    -TimeoutSec 120
```

### 컨텍스트 슬라이딩

```powershell
function Invoke-ContextSlide {
    param([array]$Messages, [int]$KeepRatio = 70)

    if ($Messages.Count -le 2) { return $Messages }

    $system = $Messages[0]
    $history = $Messages[1..($Messages.Count - 1)]
    $keepCount = [Math]::Floor($history.Count * $KeepRatio / 100)
    if ($keepCount -lt 1) { $keepCount = 1 }
    $trimmed = $history[($history.Count - $keepCount)..($history.Count - 1)]
    return @($system) + $trimmed
}
```

### 입력 부풀리기 (junk text)

```powershell
function New-JunkText {
    param([int]$SizeKB)

    $chars = "abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 .-,\n"
    $target = $SizeKB * 1024
    $sb = [System.Text.StringBuilder]::new($target + 1024)
    $rng = [System.Random]::new()

    while ($sb.Length -lt $target) {
        $lineLen = $rng.Next(50, 150)
        $line = -join (1..$lineLen | ForEach-Object { $chars[$rng.Next($chars.Length)] })
        [void]$sb.AppendLine($line)
        [void]$sb.AppendLine("")
    }

    return $sb.ToString().Substring(0, [Math]::Min($target, $sb.Length))
}
```

## ⚠️ 함정 5가지 (fireToken 06-19 발견)

1. **`reasoning_effort` 응답에서 `reasoning_content` 필드 없을 수 있음** — OpenAI SDK의 `getattr(choice.message, "reasoning_content", None)` 안전 접근 필수. JSON 직접 파싱 시에도 `response["output"][0]["content"][0].get("text", "")` 패턴.

2. **PowerShell 백그라운드 Job 출력 캡처 까다로움** — `Start-Job` + `Receive-Job -Keep` 조합으로 5초마다 폴링. `Wait-Job *` 단독 사용 시 출력 손실.

3. **curl의 `--max-time` 미지정 시 hang 위험** — PowerShell `Invoke-RestMethod`는 `-TimeoutSec 120` 필수. NIM 응답이 reasoning 포함 60K+ tokens 생성 시 시간이 길어짐.

4. **Windows native에서 `mkdir -p` 안 됨** — PowerShell은 `New-Item -ItemType Directory -Force` 또는 `[System.IO.Directory]::CreateDirectory($path)` 사용. .bat에서는 `mkdir` (단일) 사용.

5. **NIM 응답 JSON에 `usage` 필드 위치가 SDK마다 다름** — OpenAI Python SDK는 `response.usage.total_tokens`, 스트림은 `chunk.usage.total_tokens`, Responses API는 `response["usage"]["total_tokens"]`. **호출 전 SDK 문서 확인 필수**.

## 🔄 다른 무료 모델로 확장

| 서비스 | Endpoint | 인증 | rpm | reasoning |
|---|---|---|---|---|
| **NVIDIA NIM** | `integrate.api.nvidia.com/v1/chat/completions` | `NVIDIA_API_KEY` | 40 | ✅ |
| **HuggingFace Inference API** | `api-inference.huggingface.co/models/<model>` | `HF_TOKEN` | 무료 (제한) | 모델별 |
| **OpenRouter 무료 tier** | `openrouter.ai/api/v1/chat/completions` | `OPENROUTER_API_KEY` | 모델별 | 모델별 |
| **GitHub Models** | `models.inference.ai.azure.com` | GitHub PAT | 무료 (제한) | ❌ |
| **Google AI Studio** | `generativelanguage.googleapis.com` | `GOOGLE_API_KEY` | 60 (Flash) | ❌ |

**재사용 가능한 wrapping 패턴**: 위 모든 서비스는 OpenAI 호환 또는 비슷한 REST 형식. `burn.ps1`의 `Invoke-NimCall` 함수만 시그니처에 맞게 수정하면 즉시 다른 모델로 전환 가능.

## 📊 Tokscale 카운트 검증

fireToken 실행 후 macOS에서 확인:

```bash
# 5분마다 누적 토큰량
watch -n 300 "bunx tokscale@latest --light"

# 클라이언트별 (OpenCode/Hermes만)
bunx tokscale@latest --client opencode --light
bunx tokscale@latest --client hermes --light

# 모델별 필터
bunx tokscale@latest --json | jq '.[] | select(.model | contains("gpt-oss"))'

# 일간 리포트
bunx tokscale@latest daily

# 시간당 추이
bunx tokscale@latest hourly | tail -10
```

**예상 출력** (5세션 가동 1시간 후):
```
📊 Token Usage Report
─────────────────────
Client       | Model                | Tokens     | Cost
OpenCode     | gpt-oss-120b         | 50,000,000 | $0.00  ← fireToken
Hermes       | gpt-oss-120b         | 30,000,000 | $0.00  ← fireToken
Claude Code  | claude-sonnet-4      | 5,000,000  | $15.00 (평소)
─────────────────────
Total                            | 85,000,000 | $15.00
```

## 📜 검증된 사례

- **fireToken v0.1.0** (2026-06-19, sigco3111/fireToken 비공개)
  - 12개 파일 (md 6 + .ps1 3 + .bat 2 + .gitignore + LICENSE), ~57KB
  - 4중 전략 풀옵션 (A+B+C+D) 일 ~1~3B 토큰 (현실)
  - 컨텍스트 자동 관리 (80K/100K/120K 임계치)
  - Task Scheduler 등록 (cron 미사용 환경)
  - 부트스트랩 절차: `python-oss-bootstrap` 스킬의 "Windows native 변형" 참조