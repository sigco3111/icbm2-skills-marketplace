# nb_id 누락 함정 — 2026-06-20 검증 (3/3 케이스)

## 문제 정의

`notebooklm_prepare.py --skip-telegram`을 정상 실행해도 **`selected[]` 배열에 `nb_id` 키가 저장되지 않는다**.

- stdout에는 `✅ 노트북 생성 (ID: e4f13320...)` 같은 로그가 찍힘
- 그러나 `~/.hermes/memory/notebooklm_selection.json`의 `selected[]`를 확인하면 `name`/`category`/`url`만 있고 `nb_id` 없음
- → `--review` 단계에서 `collect_sources_for_description()`이 `nb_id` 부재로 `topic_url` 박기 스킵
- → description에 `📚 출처` 다음 줄이 빈 줄로 출력됨 (GeekNews URL 누락)

## 재현 절차

```python
# 1) selection.json에 5개 선택
import json
path = "/Users/hjshin/.hermes/memory/notebooklm_selection.json"
d = json.load(open(path))
d["selection_numbers"] = [3, 6, 7, 11, 12]  # 5개 선택
json.dump(d, open(path, "w"), ensure_ascii=False, indent=2)

# 2) prepare.py 실행 — 노트북 5/5 생성 OK
# /Users/hjshin/.hermes/venv-notebooklm/bin/python3 /Users/hjshin/.hermes/scripts/notebooklm_prepare.py --skip-telegram

# 3) selected[] 확인
d = json.load(open(path))
print(d["selected"][0].keys())  # dict_keys(['name', 'category', 'url']) ← nb_id 없음!
```

## 해결 (3단계 패치)

```python
# 1) notebooklm list로 ID 수집
import subprocess, json
out = subprocess.run(
    ["/Users/hjshin/.hermes/venv-notebooklm/bin/python3", "-m", "notebooklm", "list", "--json"],
    capture_output=True, text=True
)
data = json.loads(out.stdout)

# 2) 선택한 5개 토픽의 nb_id 매칭 (title에 선택 토픽명이 substring으로 포함)
nb_ids = {}
for nb in data["notebooks"]:
    title = nb.get("title", "")
    for sel in d["selected"]:
        # selection의 name 일부가 title에 포함되는지 (양방향 안전)
        if sel["name"][:25] in title or title.split(" | ")[-1][:25] in sel["name"]:
            sel["nb_id"] = nb["id"]
            nb_ids[sel["name"][:30]] = nb["id"]
            break

# 3) 저장 + 검증
json.dump(d, open(path, "w"), ensure_ascii=False, indent=2)
for sel in d["selected"]:
    assert sel.get("nb_id"), f"#{sel.get('number','?')} nb_id 누락"
print(f"✅ {len(d['selected'])} selected 모두 nb_id 보유")
```

## 더 안전한 패치 (제목 prefix 매칭)

selection.json의 `name`은 `OpenAI Codex Record & Replay: ...` 같은 원본이고, 노트북 title은 `ICBM | OpenAI Codex Record & Replay: ...`로 prefix 있음. 양방향 substring 매칭이 안전:

```python
def find_nb_id(target_name: str, notebooks: list) -> str | None:
    for nb in notebooks:
        title = nb.get("title", "")
        # ICBM | 접두사 제거 후 비교
        clean_title = title.replace("ICBM | ", "", 1)
        # 짧은 prefix (30자)로 매칭
        if target_name[:30] in clean_title or clean_title[:30] in target_name:
            return nb["id"]
    return None
```

## 검증 oneliner (--review 직전 필수)

```python
import json
d = json.load(open("/Users/hjshin/.hermes/memory/notebooklm_selection.json"))
for sel in d["selected"]:
    assert sel.get("nb_id"), f"#{sel.get('number','?')} nb_id 누락"
    assert "https://" in sel.get("url", ""), f"#{sel.get('number','?')} url 누락"
print(f"✅ {len(d['selected'])} selected 모두 nb_id + url 보유")
```

## 영향 범위

- **on-demand 업로드 (5/5 시나리오)**: 이 함정에 빠짐
- **일반 4단계 파이프라인 (16:00 크론)**: 16:00 → 17:00 '업로드' 사이에 `selected[].nb_id` 누락 상태로 진행
- **사후 토픽 추가**: 같은 함정 반복 (selection.json의 `selected`에 nb_id 직접 주입 필요)

## SKILL.md 본체 위치

이 함정은 본체 SKILL.md의 "금기" 섹션에 #29로 추가됨. 본 참조 파일은 재현 절차 + 해결 코드 + 검증 oneliner를 제공.
