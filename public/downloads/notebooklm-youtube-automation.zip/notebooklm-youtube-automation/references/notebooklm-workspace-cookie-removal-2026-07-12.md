# NotebookLM Workspace 쿠키 (.google.co.kr) 1줄 제거로 인증 복구 (2026-07-12)

> 작성: 2026-07-12 (어제 못 한 노트북 크론 재개 세션 — 4개 노트북: Apple Silicon / fenic / 유지보수 / colibrì)
> **핵심 발견**: storage_state.json이 정상 크기(12KB)이고 `.google.com` SID도 살아있지만, `.google.co.kr` (Google Workspace) SID가 섞여 있으면 NotebookLM이 Workspace SAML 리다이렉트로 인증 실패 → **풀 OAuth 재로그인 없이 `.google.co.kr` 쿠키만 제거하면 복구됨**

---

## ⚠️ 기존 가이드(storage-state-recovery-2026-06-16)와 다른 케이스

| 케이스 | storage_state.json 크기 | SID .google.com | SID .google.co.kr | 해결 |
|--------|------------------------|-----------------|-------------------|------|
| **기존 (0바이트)** | 0 bytes | ❌ 없음 | ❌ 없음 | 풀 OAuth 재로그인 (5분) |
| **이번 케이스 (Workspace 잔재)** | ✅ 12,932 bytes | ✅ 있음 | ✅ 있음 | `.google.co.kr` 쿠키만 제거 (**10초**) |

**판별 기준**: `notebooklm list --json` 호출 시 `Authentication expired or invalid. Redirected to: https://accounts.google.com/<redacted>` 나오면 두 케이스 모두 가능. **크기와 도메인 확인이 핵심**.

---

## 🔸 진단 순서 (30초)

```bash
# 1. venv 인터프리터 OK
ls /Users/mac/.hermes/venv-notebooklm/bin/python3
# → "No such file or directory" 나오면 §A venv 복구

# 2. storage_state.json 크기 + 쿠키 도메인 확인
ls -la ~/.notebooklm/profiles/default/storage_state.json
# → 정상 케이스: 12KB 이상 (이번 12,932 bytes)
# → 0 bytes면 풀 OAuth 케이스 → references/storage-state-recovery-2026-06-16.md

/Users/mac/.hermes/venv-notebooklm/bin/python3 -c "
from notebooklm.auth import _load_storage_state
data = _load_storage_state()
cookies = data.get('cookies', [])
print(f'쿠키 수: {len(cookies)}')
for c in cookies:
    if c['name'] == 'SID':
        print(f'  SID domain={c[\"domain\"]}, expires=unix:{int(c.get(\"expires\", 0))}')
"
# 정상: .google.com (consumer Gmail) 만
# Workspace 잔재: .google.com + .google.co.kr 둘 다

# 3. list --json 테스트
/Users/mac/.hermes/venv-notebooklm/bin/python3 -m notebooklm list --json 2>&1 | head -3
# 성공: {"notebooks": [{"index": 1, ...}]}
# 실패: Authentication expired or invalid...
```

---

## 🔸 해결 — `.google.co.kr` 쿠키 1줄 제거 (10초)

```bash
/Users/mac/.hermes/venv-notebooklm/bin/python3 << 'PYEOF'
import json
p = '/Users/mac/.notebooklm/profiles/default/storage_state.json'
d = json.load(open(p))
before = len(d.get('cookies', []))
d['cookies'] = [c for c in d['cookies'] if not c.get('domain', '').endswith('google.co.kr')]
after = len(d['cookies'])
removed = before - after
json.dump(d, open(p, 'w'), indent=2)
print(f'쿠키: {before}개 → {after}개 (.google.co.kr {removed}개 제거)')
print(f'✅ 저장 완료: {p}')
PYEOF
```

**검증**:
```bash
/Users/mac/.hermes/venv-notebooklm/bin/python3 -m notebooklm list --json | head -5
# → {"notebooks": [...]} 정상 응답
```

**실측 (2026-07-12)**: 쿠키 36개 → 26개 (.google.co.kr 10개 제거) → 즉시 인증 복구

---

## 🔸 어제 못 한 노트북 크론 재개 — 전체 워크플로

### 왜 이게 별도 시나리오인가

- **selection.json이 어제 패치 그대로 보존됨** — date가 오늘로 갱신돼도 selection_numbers는 그대로
- **어제 만든 노트북 4/4 모두 살아있음** — cleanup은 업로드 성공 후에만 실행 (gold #11) → 업로드 안 했으니 보존
- **prepare.py 재실행 → ⏭️ skip** (gold #10 멱등성) — 새로 안 만들어짐

즉 **사용자 입장에서는 "어제 그거 다시 해줘" 한마디로 4개 노트북 + nb_id 확보까지 즉시 가능**.

### 1단계: 현재 상태 진단 (10초)

```bash
python3 -c "
import json
d = json.load(open('/Users/mac/.hermes/memory/notebooklm_selection.json'))
print(f'  date: {d[\"date\"]}')
print(f'  topics: {len(d[\"topics\"])}개')
print(f'  selected: {len(d.get(\"selected\", []))}개')
print(f'  selection_numbers: {d[\"selection_numbers\"]}')
"
# date가 오늘이면 selection_numbers 그대로 진행
# 어제 날짜면 새 cron 대기 또는 수동 갱신 필요
```

### 2단계: NotebookLM 인증 확인 (위 진단 순서 참고)

`.google.co.kr` 쿠키 발견 시 → **위 1줄 제거 (10초)** → list --json 검증

### 3단계: prepare.py 실행 (2~6분, 멱등성 #10)

```bash
/Users/mac/.hermes/venv-notebooklm/bin/python3 ~/.hermes/scripts/notebooklm_prepare.py --skip-telegram
```

**기대 출력 (어제 만든 노트북 있는 경우)**:
```
⏭️ [1/4] 이미 존재: ICBM | Apple Silicon 임원이 말한...
⏭️ [2/4] 이미 존재: ICBM | fenic - 사람과 에이전트를 위한...
⏭️ [3/4] 이미 존재: ICBM | 사람이 유지보수할 것처럼...
⏭️ [4/4] 이미 존재: ICBM | colibrì - 느린 컴퓨터에서...

✅ 노트북 준비 완료!
   생성된 노트북: 4개
```

→ 2초 만에 끝남 (노트북 생성 0건이지만 "4개" 카운트는 멱등성으로 skip된 것)

### 4단계: nb_id 확보 (10초)

```bash
/Users/mac/.hermes/venv-notebooklm/bin/python3 << 'PYEOF'
import json, subprocess
out = subprocess.check_output(
    ['/Users/mac/.hermes/venv-notebooklm/bin/python3', '-m', 'notebooklm', 'list', '--json'],
    cwd='/Users/mac/.hermes'
).decode()
d = json.loads(out)
notebooks = d.get('notebooks', [])

# 키워드 매핑 (헥사 prefix 루프 금지 — gold #46)
target_keywords = ['Apple Silicon', 'fenic', '유지보수', 'colibr']
for kw in target_keywords:
    for nb in notebooks:
        if kw in nb['title']:
            print(f"  {kw:15s} → {nb['id']}")
            print(f"      {nb['title']}")
            break
PYEOF
```

### 5단계: 사용자에게 보고

"4개 노트북 + nb_id 확보 완료. NotebookLM 웹 UI에서 Video Overview 생성해주세요" 형태로 메시지 전달

---

## 🔸 PC 접근 불가 시 — 어제 작업 보존 패턴 (2026-07-11)

이번 세션에서 검증된 별도 시나리오:

- PC 접근 불가 + 다음 날 PC 복구 시
- `/tmp/notebooklm-resume.md` 파일에 재개 절차 문서화 (15KB)
- `selection.json` 패치 그대로 보존
- PC 복구 시 `cat /tmp/notebooklm-resume.md` → Step 1부터 자동 실행

**문서 핵심 내용**: 10단계 재개 절차 (Step 1 환경 검증 ~ Step 10 --approved 업로드) + 5개 부록 (venv 복구 §A, 풀 OAuth §B, 영상 실패 §C, 토큰 refresh §D, Shorts 변환 §E).

**왜 메모리가 아닌 파일인가**: 일회성 상황이라 7일 후엔 stale → 메모리 가치 없음. PC 복구 시점에 그 자리에서 즉시 실행 가능해야 하므로 파일이 적합.

---

## 💡 핵심 교훈 3가지

### 1. **Workspace 쿠키 제거는 풀 OAuth보다 항상 우선 시도**

- 시간: 10초 (vs 5분)
- 사용자 개입: 0 (vs Chromium 띄우고 Gmail 로그인)
- 안전성: 쿠키 일부만 제거 (vs 전체 재생성)

→ `storage_state.json` 크기가 정상이면 `.google.co.kr` 도메인 검사부터!

### 2. **쿠키 살아있음 ≠ 인증 통과**

- size OK + .google.com SID OK + .google.co.kr SID OK + NotebookLM 401
- Google이 **요청 시점에 Workspace SAML 리다이렉트** 트리거 → 쿠키 도메인 무관하게 인증 실패
- → **쿠키 도메인 분리는 여전히 필요**

### 3. **"어제 못 한 cron" = 멱등성 #10 + cleanup #11의 조합 활용**

- 노트북이 cleanup되지 않은 상태로 보존됨
- prepare.py 멱등성으로 skip → 자원 낭비 0
- nb_id도 그대로 유효
- → **단, YouTube 토큰 / 영상 파일은 별개 → 5종 사전 체크는 매번 필수**

---

## 📋 디버깅 체크리스트 (이번 세션 + 기존 통합)

| 증상 | 원인 | 해결 |
|------|------|------|
| `Authentication expired` + storage_state 0 bytes | OAuth 풀 만료 | `references/storage-state-recovery-2026-06-16.md` 풀 OAuth 절차 |
| `Authentication expired` + storage_state 정상 크기 | Workspace 쿠키 잔재 | **이 문서 §1줄 제거 (10초)** |
| `Authentication expired` + .google.com 만 있음 | Workspace 계정 자체 사용 | Gmail.com 재로그인 필요 |
| `SID domain=.google.co.kr` 만 있음 | Workspace 계정 쿠키 | 정책상 인증 불가, Gmail.com 필요 |
| 어제 만든 노트북 안 보임 | cleanup #11 발동 (업로드 성공 후) | 새 nb_id로 재생성 |
| 어제 만든 노트북 4/4 보임 | cleanup 미발동 (업로드 안 함) | 멱등성 #10으로 skip → 즉시 진행 |
