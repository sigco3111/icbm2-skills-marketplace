# 2026-05-13 Session — Upload Pipeline ct NameError + notebook_info.json Workaround

## What happened

User requested notebook creation for topics 2, 3, 6, 7 from the daily notebooklm selection.
1. `selection.json` updated with `selection_numbers: [2, 3, 6, 7]`
2. `notebooklm_prepare.py` ran successfully → 4 notebooks created
3. User confirmed video generation complete → triggered "업로드"
4. First `notebooklm_upload_pipeline.py` run failed with `NameError: name 'ct' is not defined`

## Root cause

In `download_and_upload_video` (line ~364), `create_shorts_from_video` was called without the `ct` argument:
```python
shorts_ok = create_shorts_from_video(video_path, nb_original_title, today, no_upload)
```

`ct` is defined at line ~324 as `nb_info["content_type"]` but never passed to the shorts function.

## Fix applied

1. Updated function signature at line ~247:
   ```python
   def create_shorts_from_video(video_path, nb_original_title, today, no_upload=False, ct=None):
   ```

2. Updated call site at line ~364:
   ```python
   shorts_ok = create_shorts_from_video(video_path, nb_original_title, today, no_upload, ct)
   ```

3. Pipeline re-ran successfully: 4 videos + 4 Shorts uploaded.

## Secondary issue: notebook_info.json missing

The pipeline expects `notebook_info.json` in `/tmp/icbm_notebooklm/`, but `prepare.py` only writes `notebook_ids.json`.
Manually created `notebook_info.json` with the 4 notebook IDs to unblock the pipeline.

**Note:** `notebook_ids.json` (prepare output) ≠ `notebook_info.json` (pipeline input). They have different schemas.