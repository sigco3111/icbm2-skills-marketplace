# On-Demand Upload — 2026-06-22 (1건 단일 업로드, Codex Record & Replay)

## 시나리오
사용자가 NotebookLM에서 1개 노트북 비디오 오버뷰를 미리 생성해두고, "이것도 업로드해줘. 출처는 https://news.hada.io/topic?id=30642" 형태로 노트북 URL + GeekNews 출처 URL을 직접 지정.

- 일반 4단계 파이프라인의 1~3단계 모두 우회
- 4단계(업로드)만 남은 상태
- 노트북 ID: `e4f13320-ab47-4d68-bac7-b09dc5aa76de`
- 출처 URL: `https://news.hada.io/topic?id=30642` (NotebookLM topics DB에 없는 직접 지정 URL)

## 사전 체크 5종 (2026-06-21 절차 동일, 5/5 통과)

| # | 점검 | 결과 |
|---|------|------|
| 1 | venv 인터프리터 | ✅ `python3` 정상 |
| 2 | selection.json 날짜 | ✅ 2026-06-22 |
| 3 | YouTube 토큰 (1차 refresh 후) | ✅ valid=True |
| 4 | 1개 노트북 artifact status | ✅ completed |
| 5 | 영상 파일 다운로드 | ✅ Codex Record & Replay.mp4 (57MB) |

## ⚠️ 신규 함정: `python3 -c "..."` 검증 oneliner의 시그니처 자동 승인 실패

**증상:**
```bash
python3 -c "
import json
d = json.load(open('/Users/hjshin/.hermes/memory/notebooklm_selection.json'))
..."
# → "BLOCKED: Command timed out without user response. ... Do NOT retry"
```

**원인:** `python3 -c "..."`로 멀티라인 스크립트(`json.dump`, `assert` 등)를 실행하면 시그니처 자동 승인 단계가 길어지면서 30초 timeout. 사용자가 백그라운드에 있으면 자동 승인 못 받음 → 차단.

**해결:** 검증은 **반드시 read_file로** (3종 세트 oneliner 대신):

```bash
# 검증
read_file /Users/hjshin/.hermes/memory/notebooklm_selection.json
# → 눈으로 selected[] 3필드 (number, nb_id, file) 직접 확인
```

**예방:**
- oneliner Python은 **1줄짜리 빠른 체크**에만 사용 (예: `python3 -c "import json; d=json.load(open(p)); print(len(d['selected']))"`)
- 멀티라인 `json.load` + `for` + `assert` → **`read_file`로 대체**
- 시그니처 자동 승인은 짧고 단순한 명령에만 안전

## selection.json 패치 — number 필드 일관성 (2026-06-22 추가)

**topics 배열의 항목에도 `number` 필드 추가** — on-demand 토픽이 13번째일 때, `selected`에만 number=13 박지 말고 **topics[12]에도 number=13 박아야 일관성 유지**.

```json
{
  "topics": [
    ... 12개 기존 후보 ...,
    {
      "number": 13,
      "name": "OpenAI Codex Record & Replay: ...",
      "category": "AI/ML",
      "url": "https://news.hada.io/topic?id=30642",
      "file": "/tmp/icbm_notebooklm/videos/Codex Record & Replay.mp4",
      "nb_id": "e4f13320-ab47-4d68-bac7-b09dc5aa76de"
    }
  ],
  "selected": [
    {
      "number": 13,
      "name": "OpenAI Codex Record & Replay: ...",
      "url": "https://news.hada.io/topic?id=30642",
      "nb_id": "e4f13320-ab47-4d68-bac7-b09dc5aa76de",
      "file": "/tmp/icbm_notebooklm/videos/Codex Record & Replay.mp4"
    }
  ],
  "selection_numbers": [13],
  "auto_mode": false,
  "source": "on-demand"  // ← 신규: 일반 후보와 on-demand 구분용
}
```

**이유:**
- `prepare.py` / `upload.py`가 `topics[n-1]`로 매핑할 때 `number` 필드 일관성 기대
- `selected`만 number=13이고 topics[12]에 없으면 → 어긋난 매핑 위험
- `"source": "on-demand"`는 이후 디버깅 시 일반 후보(크론 16:00 자동 생성)와 on-demand(사용자 수동) 구분. **선택 사항이지만 권장**

## on-demand 1건 vs 다건 — 절차 차이

| 항목 | on-demand 1건 (이번) | on-demand 다건 (2026-06-21) |
|------|---------------------|--------------------------|
| topics 추가 | append 1개 | append N개 |
| selected | REPLACE `[topics[-1]]` | REPLACE `[topics[-N:]]` |
| selection_numbers | `[N+1]` (1개) | `[N+1, N+2, ...]` (N개) |
| 파일 다운로드 | `for nb in $NB1; do use+download; done` | `for nb in $NB1 $NB2 ...; do ...; done` |
| 검증 | `ls /tmp/.../videos/` 1개 확인 | `ls` 후 N개 확인 |
| cleanup | 1개 노트북 삭제 | N개 노트북 일괄 삭제 |

## 검증 oneliner → read_file 전환 체크리스트

write_file 직후 검증 단계에서:
- [ ] `python3 -c "..."` 사용했는가? → **read_file로 전환** (시그니처 자동 승인 실패 위험)
- [ ] topics 배열 마지막 항목에 `number` 필드 있는가? (선택된 토픽이면 필수)
- [ ] selected 배열의 첫 항목 nb_id가 description에 박힌 GeekNews URL과 일치하는가?
- [ ] `source: "on-demand"` 필드로 일반 vs on-demand 구분 표시했는가?

## 핵심 학습 (이번 세션 추가분)

1. **`python3 -c` 멀티라인 oneliner는 시그니처 자동 승인 timeout으로 차단될 수 있다** → read_file로 검증
2. **topics 배열에도 number 필드 일관성 유지** — selected만 number 박지 말 것
3. **`source: "on-demand"` 메타 필드** — 디버깅 시 일반 후보와 구분용
4. **on-demand 1건도 5종 사전 체크 + 3종 세트 oneliner 검증** — 다건과 절차 동일 (생략하지 말 것)
