# Cron 메시지 vs `selection.json` Mismatch — 진단 & 복구

**작성일:** 2026-07-12
**적용 시나리오:** 사용자가 16:00 cron 메시지에 답장으로 번호를 선택했지만 `selection.json`은 어제 사이클 잔재가 그대로 보존된 상태.

## 🔍 핵심 문제

`notebooklm_selection.py`의 `existing.date == today` 가드 (line 198)는 "오늘 날짜면 덮어쓰지 않음" 로직인데, **어제 on-demand 진행 중(partial upload 등)이라 `selection.json`이 어제 데이터로 가득 찬 상태**에서 오늘 cron이 silent-skip하면 `selection.json`은 어제 그대로. 사용자가 오늘 cron 메시지에 답장하면 번호 매핑이 완전 틀림.

## ⚠️ 실측 (2026-07-12 16:18)

- cron 메시지: `1. 🤖 AI 2040: 플랜 A` ~ `12. 📌 Android 앱을 웹페이지로 바꿔본 과정` (새 사이클)
- `selection.json` topics[0].name: `"2026년 12월 말 윤초 추가 없음"` (어제 사이클)
- → 완전 다른 후보 풀. 사용자가 "1, 4, 7, 12 노트북 생성"이라고 답장해도:
  - `selection_numbers = [1, 4, 7, 12]` 패치만 하면
  - `topics[0]` (윤초) / `topics[3]` (Meta CXL) / `topics[6]` (fenic) / `topics[11]` (Codeberg) → 4개 모두 다른 주제

## 📋 진단 절차 (30초)

```python
import json
d = json.load(open('/Users/mac/.hermes/memory/notebooklm_selection.json'))
print(f"date: {d.get('date')}")
print(f"topics[0]: {d['topics'][0].get('name', '?')}")
print(f"selection_numbers: {d.get('selection_numbers', [])}")
print(f"selected: {len(d.get('selected', []))}개")
print(f"skipped: {len(d.get('skipped', []))}개")
```

**판정 기준**:
- `topics[0].name` ≠ cron 메시지 첫 항목 → **다른 사이클** (gold #56)
- `topics[0].name` = cron 메시지 첫 항목 → 같은 사이클, 진행 가능

## 🚦 4옵션 + 추천 워크플로

사용자에게 다음 4옵션 + 추천으로 한 번에 묶어서 clarify:

```
🔸 진단 결과: 어제 사이클 데이터가 selection.json에 남아있어요
   (topics[0]: "윤초 추가 없음" vs cron 메시지 1번: "AI 2040: 플랜 A")

1. A. (추천) 새 사이클로 진행 — selection.json topics를 cron 메시지 후보로 REPLACE
2. B. 어제 사이클 데이터 유지 — 일단 보류, 다음 사이클 cron 대기
3. C. 내가 잘못 보냈다 — 메시지 다시 확인
4. D. 다른 행동
```

**"위임" 응답 시**: 즉시 A 진행 (자동 결정). 사용자가 다른 옵션 선택 시 그에 따름.

## 🔧 A 옵션 실행 (자동 진행)

```python
import json
from datetime import datetime, timezone, timedelta

p = '/Users/mac/.hermes/memory/notebooklm_selection.json'
d = json.load(open(p))

# 1) 어제 사이클 잔재 초기화
d['selected'] = []
d['skipped'] = []

# 2) 새 사이클 topics (cron 메시지 12개, URL은 fallback #57에서)
new_topics = [
    {"name": "AI 2040: 플랜 A", "category": "AI/ML", "url": None, "number": 1},
    {"name": "스크레이퍼 공격으로 유지 어려워지는 개방형 웹", "category": "AI/ML", "url": None, "number": 2},
    # ... 12개 전체
]
d['topics'] = new_topics

# 3) 사용자 선택 (URL이 확보된 #만 또는 "위임" 시 fallback 가능한 것만)
d['selection_numbers'] = [1, 4]  # 7번은 URL 검색 실패로 제외
d['date'] = '2026-07-12'

with open(p, 'w') as f:
    json.dump(d, f, ensure_ascii=False, indent=2)
```

## ⚠️ URL이 없을 때 — 3-tier fallback (gold #57)

cron 메시지에 URL이 전혀 없을 때 (이번 케이스):

1. **`~/.hermes/cron/output/<job_id>/<날짜>.md`** — `ls -la` + `grep "news.hada.io" *.md`. 7/12 케이스는 `.md`에도 URL 없었음 (cron LLM이 직접 생성한 케이스).
2. **Notion DB 직접 조회** — `curl -X POST -H "Authorization: Bearer ..." -d '{"page_size": 100}' ...` 활성 후보 0개.
3. **HN Algolia 검색** — `https://hn.algolia.com/api/v1/search?query=<encoded>&tags=story`. 영어 제목일 때 효과적. 한글은 URL 인코딩 필수 (`%ED%95%9C%EA%B8%80+...`).

7/12 결과:
- `#1 AI 2040: 플랜 A` → HN 검색 OK → `https://ai-2040.com/` 원본 URL 확보
- `#4 GPT-5.6/Grok/Claude/Muse` → HN 검색 OK → `https://www.tryai.dev/blog/gpt-5.6-build-off-12-models`
- `#7 '터미네이터 2' 기술의 구술사` → HN + 한글 검색 둘 다 실패 → 사용자 선택에서 제외

## ⚠️ 정책 #8 위반 알림 (필수)

원본 URL은 `news.hada.io`가 아니므로 **"이번만 예외로 원본 URL 사용" 알리고 proceed**. GeekNews URL이 다시 확보되는 다음 사이클부터는 정상 정책으로 복귀.

## 🔄 #56 vs #39 (stale-data) 비교

| # | 발생 조건 | `selection.json` 상태 | 해결 |
|---|----------|---------------------|------|
| **#39 (stale-data)** | Notion DB 풀만 교체, `selection.json`의 topics는 어제 | 같은 사이클인데 풀만 stale | 진단 4종 + 4옵션 |
| **#56 (mismatch)** | cron 메시지 자체가 다른 후보 (Notion 비었거나 cron LLM이 직접 생성) | topics가 아예 다른 사이클 | topics REPLACE |

## 🚫 예방 (장기)

1. **cron LLM 프롬프트 개선**: stdout에 항상 `===== NOTEBOOKLM 후보 =====` 마커 + 후보 12개 + URL 출력 강제 (gold #43 변형).
2. **`notebooklm_selection.py` line 198 강화**: `existing.date == today` 외 `topics[0].name` 해시 비교 추가 → 어제 풀 + 오늘 새 풀 자동 감지.
3. **사용자 워크플로**: cron 메시지 수신 시 즉시 `selection.json`의 `topics[0].name` 1줄 비교 → 불일치면 1분 안에 진단 보고.

## 📚 연관 금기

- #39 — selection.json 자체 stale (같은 사이클 내 풀 교체)
- #43 — cron empty stdout → LLM 거짓 보고 (silent-skip)
- #57 — cron 메시지 URL 없을 때 3-tier fallback
- #58 — cron output `.md` 파일 canonical
- #59 — 사용자 "위임" 시 자율 결정
