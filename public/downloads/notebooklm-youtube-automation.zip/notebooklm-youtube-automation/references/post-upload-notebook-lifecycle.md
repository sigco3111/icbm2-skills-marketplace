# 업로드 후 노트북 라이프사이클 함정

> 작성: 2026-06-04 (Gemma 4 노트북 재업로드 시 발견)

## 현상

업로드 성공 후 `notebooklm_upload.py`의 사후 정리 단계에서 **노트북 자체가 NotebookLM에서 사라지는** 현상이 관측됨.

### 증거 (2026-06-04 세션)

1. 16:08 — `76716a40-78e9-4437-83e8-ffeaaf763290` (Gemma 4) 노트북 생성
2. 16:45 — 업로드 성공 (4/4)
3. 사후 정리 로그: `🗑️ 삭제: 76716a40... (성공)` — 영상 파일만 지워야 하는데 **노트북도 같이 삭제**
4. 16:52 — 같은 ID로 `notebooklm use` 시도 → `RPC rLM1Ne returned null result data` (서버가 모름)
5. `notebooklm list` 결과: `76716a40` 부재 확인 (36개 중)

## 원인 가설

`notebooklm_upload.py`의 cleanup 단계가 `notebooklm delete`를 호출하는데, 이게 **영상 파일이 아닌 노트북 자체를 삭제**하고 있을 가능성. 

→ 스킬 작성자가 의도한 동작은 "디스크의 .mp4 정리"였을 텐데, NotebookLM CLI의 `delete` 명령이 노트북 메타데이터까지 지우는 API를 호출.

## 영향

- 같은 주제 재업로드 시 **새 노트북 ID로 다시 생성** 필요
- 기존 노트북의 `source list` / `artifact list` 모두 조회 불가
- 멱등성 가정이 깨짐: "이미 노트북 있으면 skip"이 작동하려면 노트북이 살아있어야 함

## 우회 방법

### 방법 1: 업로드 후 노트북 보존 모드 (검증 필요)

`notebooklm_upload.py`의 cleanup 단계가 `--preserve-notebooks` 같은 옵션을 지원하는지 확인. 없으면 패치 필요.

### 방법 2: 재업로드 시 새 노트북 생성 (현재 사용 패턴)

스킬의 멱등성 가설은 "**같은 selection.json** 으로 재실행 시 중복 skip"이므로, 노트북이 사라진 후에는:

```bash
# 1. selection_numbers에 같은 번호 다시 추가
python3 - << 'EOF'
import json
with open("/Users/hjshin/.hermes/memory/notebooklm_selection.json") as f:
    d = json.load(f)
d["selection_numbers"] = [4]  # Gemma 4
d["selected"] = [d["topics"][3]]
with open(...open..., "w") as f:
    json.dump(d, f, ensure_ascii=False, indent=2)
EOF

# 2. prepare.py 재실행 → 새 노트북 ID로 생성됨
source ~/.hermes/venv-notebooklm/bin/activate
python3 ~/.hermes/scripts/notebooklm_prepare.py --skip-telegram
```

### 방법 3: 수동 보존

`upload_review.json`이나 `notebook_ids.json`에 노트북 ID를 기록해두고, 이후 같은 주제로 작업할 때 그 ID를 직접 `notebooklm use`로 활성화.

## 권장 액션 (다음 세션)

- [ ] `notebooklm_upload.py` cleanup 단계 코드 확인
- [ ] 의도된 동작이 "디스크 정리"라면 `notebooklm delete` 호출 제거 또는 가드 추가
- [ ] 의도된 동작이 "노트북 폐기"라면 명시적 옵션 + 로그 강화

## 재업로드 안전 검증 (2026-06-04 실측)

- 16:53 — 같은 주제 4번으로 `prepare.py` 재실행 → 새 ID `48d85614-904a-4b27-8e19-1f7f2d1561cf` 생성 성공
- 즉, **노트북이 사라져도 정상적인 재생성 흐름은 작동**함. 단지 같은 ID로 Video Overview 같은 아티팩트가 살아있었다면 손실되는 문제만 존재.
