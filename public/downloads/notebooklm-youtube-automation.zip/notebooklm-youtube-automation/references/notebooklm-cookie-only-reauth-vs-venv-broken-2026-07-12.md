# NotebookLM 쿠키 단독 만료 vs venv/Playwright 손상 — 재로그인 트리아지 (2026-07-12 실측)

## 1. 상황

2026-07-12 08:22 KST. 7/10 16:51에 마지막으로 정상 작동한 NotebookLM 세션이 40시간쯤 지나서 `Authentication expired or invalid. Redirected to: https://accounts.google.com/<redacted>...` 메시지로 list 호출이 실패.

**이 reference의 핵심** — "뭐가 망가진 거지?"에 따라 1분 vs 5분이 갈리는데, 자주 헷갈려서 트리아지 체크리스트가 필요했음.

## 2. 3-종 진단 (30초)

```bash
# (a) venv 인터프리터 살아있는지
ls -la ~/.hermes/venv-notebooklm/bin/python3 bin/notebooklm 2>&1 | head -2
# → python3.12 심볼릭 + notebooklm 스크립트 둘 다 있으면 OK

# (b) Playwright/Chromium 살아있는지
ls ~/.hermes/venv-notebooklm/bin/playwright 2>&1
~/.hermes/venv-notebooklm/bin/python3 -m playwright --version 2>&1 | head -1
# → 둘 다 있으면 OK

# (c) 쿠키 파일 살아있는데 만료된 거지, 0바이트로 망가진 거지?
ls -la ~/.notebooklm/profiles/default/storage_state.json
# → size > 0 (e.g. 12,946B) but 만료됐을 가능성 큼
# → size = 0 then 백업 → 풀 OAuth (기존 references/notebooklm-relogin-2026-06-16.md 절차)
# → 파일 자체 없으면 풀 OAuth
```

3종 모두 OK인데 `notebooklm list`가 `Authentication expired`로 떨어지면 → **쿠키만 만료된 거**, 1분 절차로 끝.

## 3. 1분 절차: `notebooklm login` 재실행 (Playwright/venv 살아있음)

venv 재생성 + Playwright 재설치는 필요 없음. **오직 인증만 새로 박는 거**:

```bash
# PTY + background launch (Chrome 창이 사용자에게 보여야 함)
~/.hermes/venv-notebooklm/bin/python3 -u -m notebooklm login
```

**백그라운드 launch 패턴 (terminal 도구)**:

- `background=true`
- `pty=true`
- `notify_on_complete=true` (5분 안에 끝나면 자동 알림)

**실측 출력 (2026-07-12, ~1분)**:
```
Profile: default
Opening Chromium for Google login...
Using persistent profile: ~/.notebooklm/profiles/default/browser_profile

Instructions:
1. Complete the Google login in the browser window
2. Authentication will be saved automatically once login is detected

Waiting for login (up to 5 minutes)...
Login detected.
Identifying Google account...
Account: hjshin@ubob.com

Authentication saved to: ~/.notebooklm/profiles/default/storage_state.json
```

**메시지 트림치**: `Waiting for login`까지 5~10초, 사용자 로그인 후 10~30초, `Login detected` 후 storage 저장까지 5초 — **총 1분 안에 끝남**.

## 4. 검증 (10초)

```bash
~/.hermes/venv-notebooklm/bin/python3 -m notebooklm list --json 2>&1 | head -3
# → {"notebooks": [...]} 나오면 OK

# 노트북 N개 확인
~/.hermes/venv-notebooklm/bin/python3 -c "
import subprocess, json
out = subprocess.check_output(['~/.hermes/venv-notebooklm/bin/python3', '-m', 'notebooklm', 'list', '--json']).decode()
d = json.loads(out)
print(f'✅ 인증 정상 — 노트북 {len(d.get(\"notebooks\", []))}개')
"
```

## 5. 계정 표시 함정 (gold #36 재확인)

`Login detected.` 직후 출력되는 `Account: hjshin@ubob.com`이 Google Workspace처럼 보여도 **SID 쿠키 도메인이 `.google.com`이면 정상 (consumer Gmail로 실제 인증됨)**. Workspace 판정은 출력 도메인이 아니라 쿠키 도메인:

```bash
~/.hermes/venv-notebooklm/bin/python3 -c "
from notebooklm.auth import _load_storage_state
data = _load_storage_state()
for c in data.get('cookies', []):
    if c['name'] == 'SID':
        print('SID domain:', c['domain']); break
"
# → .google.com → OK
# → .google.co.kr → Workspace 계정 → 인증 불가 (gold #36)
```

## 6. "Chrome이 안 뜨는 거 같은데?" — PTY 안 쓰면 Chromium이 백그라운드 표시됨

`background=true` 만 하고 `pty=true` 빠뜨리면 — `tee` 로그엔 메시지 찍히지만 **Chromium 창이 사용자에게 안 보임**. PTY 필수 (`gold` §OAuth 로그인 절차 본문 참조).

## 7. 시스템 `/usr/bin/python3` (3.9) 토큰 검증 시 `cryptography` native binding 심볼 충돌 회피 (2026-07-12 실측)

YouTube 토큰 `valid` 체크를 MEMORY gold #25대로 `/usr/bin/python3` (Python 3.9)로 돌리면 — Hermes agent의 Python 3.11 venv site-packages가 글로벌하게 잡혀서 다음 에러 발생:

```
ImportError: dlopen(.../cryptography/hazmat/bindings/_rust.abi3.so, 0x0002):
symbol not found in flat namespace '_PyType_GetName'
```

**원인**: `cryptography` 41.x의 `_rust.abi3.so`가 Python 3.11 ABI로 빌드됐는데 Python 3.9에서 import 시도. ABI3 = 안정 API 같지만 의존 심볼은 여전히 다른 ABI.

**해결 — `env -i` + `sys.path` 필터**:

```bash
env -i HOME=/Users/mac PATH=/usr/bin:/bin /usr/bin/python3 -c "
import sys, pickle
sys.path = [p for p in sys.path if 'hermes-agent' not in p]
c = pickle.load(open(os.path.expanduser('~/.hermes/secrets/youtube_token.pickle'), 'rb'))
print(f'valid={c.valid} refresh_token={\"있음\" if c.refresh_token else \"없음\"}')
" 2>&1 | grep -vE "^/Users/mac/Library|warnings.warn"
```

**원칙**: 

1. `/usr/bin/python3` 호출 시 `env -i` 로 환경 최소화 + `sys.path` 에서 `hermes-agent` 포함된 경로 제거
2. `FutureWarning`/`NotOpenSSLWarning`은 `grep -v` 로 무시 (출력 결과에만 영향)
3. `>>`로 결과도 file에 저장하면 regex 안전

**대안 (venv-notebooklm + google-auth 추가 설치)**: `~/.hermes/venv-notebooklm/bin/pip install google-auth` 한 줄이면 3.9 fallback 우회. 단 google-auth + cryptography 40+ 설치가 다른 의존성 깨뜨릴 수 있어 **3.9+env -i 방식이 안전**.

## 8. 트리아지 의사결정 플로우

```
notebooklm list → Authentication expired
  │
  ├─ bin/python3 없음 OR bin/notebooklm 깨짐 → §A venv 재생성 (5분)
  │
  ├─ bin/playwright 없음 OR login 시 "Playwright not installed" → §B pip install + chromium 97MB (3분)
  │
  ├─ storage_state.json 0B → §C 백업 복구 → 실패 시 풀 OAuth (5분)
  │
  └─ 위 3개 모두 OK + size > 0 → §3 1분 login 재실행
```

## 9. 사용자에게 안내 메시지 템플릿 (PTY background 직후)

```
✅ PTY 모드로 notebooklm login 띄웠어요.
브라우저 창에서 Gmail 로그인 → NotebookLM 홈 뜨면 터미널에서 Enter 한 번 눌러주세요.
(1분 안에 끝나면 storage_state.json 자동 갱신 → list 재검증으로 마무리)
```

## 10. 메모리 vs 스킬 분류

- **저장 가치 있음 (skill)**: 위 1~9의 체크리스트 + 의사결정 플로우 — "쿠키만 만료 vs venv 손상 vs Playwright 미스" 3가지 구분은 다음 세션부터 반복될 일반화된 함정
- **메모리 불필요**: 이번 세션에서만 해당되는 40시간 만료 시각, 08:22 KST 등 일시적 정보
- **상위 SKILL.md 위치**: `notebooklm-youtube-automation/SKILL.md` 의 "인증 실패 디버깅 (v0.14.0+)" 섹션과 "OAuth 풀 재로그인" 절 사이에 § "쿠키만 만료된 경우 빠른 1분 절차" 신규 subsection으로 묶어야 함 (이 reference는 상세 로그)
