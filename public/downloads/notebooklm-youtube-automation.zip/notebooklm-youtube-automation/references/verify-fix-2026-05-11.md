# NotebookLM侯選 Fix 검증 참고 (2026-05-11)

## 버그 패턴
크론이 Telegram로 전송한侯選 목록의 번호와, prepare.py가 Notion DB를 재쿼리해서 만든 목록의 번호가 다름.
→ 사용자가 "1, 4, 6" 선택 → 엉뚱한 주제 생성

## 수정 내용
- `prepare.py`: selection.json의 `topics` (크론 전송 시 저장)를 직접 사용 — Notion 재쿼리 없음
- `upload.py`: YouTube 제목 = 토픽 이름 원본 그대로 (변환 없음)

## 검증 방법

### 1. selection.json 무결성 체크
```python
import json
with open("~/.hermes/memory/notebooklm_selection.json") as f:
    d = json.load(f)
assert "topics" in d, "topics 키 없음 — 크론 전송 실패 가능성"
assert "selected" in d or "selection_numbers" in d, "선택 정보 없음"
assert d["date"] == datetime.now(KST).strftime("%Y-%m-%d"), "날짜 불일치"
```

### 2. topics vs selected 번호 매핑 검증 (선택 직후 prepare 전)
```bash
# selection.json의 topics[0], topics[3], topics[5]가 Telegram 메시지 1,4,6번과 같은지 확인
python3 -c "
import json
with open('~/.hermes/memory/notebooklm_selection.json') as f:
    d = json.load(f)
nums = d.get('selection_numbers', [])
topics = d.get('topics', [])
print('선택:', [topics[i-1]['name'][:30] for i in nums if i <= len(topics)])
"
```

### 3. prepare.py 실행 로그에서 확인
```
[HH:MM:SS] 🔄 selected 복원: N개 (selection_numbers → topics 매핑)
```
이 로그가 보이면 → 수정 적용됨 (Notion 재쿵리 대신 selection.json 사용)

### 4. YouTube 업로드 후 제목 확인
수정 전: "【속보】 X 공개" / "X 핵심 정리" 등 변환된 제목
수정 후: "Show GN: Hermes 에이전트와 Discord로 통화하며 작업하기" (원본 토픽명)
