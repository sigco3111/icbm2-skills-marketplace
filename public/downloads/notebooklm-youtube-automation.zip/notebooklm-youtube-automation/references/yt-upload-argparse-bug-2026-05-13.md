# 2026-05-13: yt_upload.py positional args bug + YouTube title="--title" incident

## Incident Summary

8 YouTube videos uploaded with title `--title` and malformed descriptions.
Root cause: `yt_upload.py` was called with `--title`, `--description`, `--tags` flags, but it only parsed positional `sys.argv`.

## Bug: yt_upload.py positional-only argument parsing

**Original code (broken):**
```python
if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python3 yt_upload.py <file_path> <title> [description]")
        sys.exit(1)
    file_path = sys.argv[1]  # ← filepath goes here
    title = sys.argv[2]        # ← "--title" goes here (not the actual title!)
    description = sys.argv[3] if len(sys.argv) > 3 else ""
```

**Called as:**
```python
cmd = ["python3", upload_script, file_path,
       "--title", title,          # sys.argv[2] = "--title" literal
       "--description", full_desc, # sys.argv[3] = "--description" literal
       "--tags", "ICBM,AI,...",   # sys.argv[4] = "--tags" literal
       ...]
```

Result: Title was literally the string `"--title"`.

## Fix Applied

Replaced main block with argparse:
```python
if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("file_path")
    parser.add_argument("--title", dest="title", required=True)
    parser.add_argument("--description", dest="description", default="")
    parser.add_argument("--tags", dest="tags", default="")
    parser.add_argument("--category", dest="category", default="28")
    parser.add_argument("--privacy", dest="privacy", default="public")
    parser.add_argument("--shorts", dest="is_shorts", action="store_true")
    args = parser.parse_args()
    # ...
```

## YouTube API Scope Issue (BONUS)

Upload-only scope (`youtube.upload`) does NOT allow `search` or `video.delete`.
When we needed to delete the 8 malformed videos, had to re-auth with full `youtube` scope:
```python
SCOPES = ['https://www.googleapis.com/auth/youtube']
flow = InstalledAppFlow.from_client_secrets_file(CLIENT_SECRET, SCOPES)
creds = flow.run_local_server(port=0)
# Token file must be re-written from scratch
os.remove(TOKEN_FILE)
creds = flow.run_local_server(port=0)
with open(TOKEN_FILE, 'wb') as f:
    pickle.dump(creds, f)
```

## Lesson

Any script that moves from positional-only to flag-based arguments MUST be updated
in ALL callers before it works. The pipeline called it with `--key value` style since
commit `7cbc9f6` (May 2026), but the script still expected positionals.