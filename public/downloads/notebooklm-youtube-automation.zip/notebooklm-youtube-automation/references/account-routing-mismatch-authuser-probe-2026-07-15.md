# Account-Routing Mismatch + authuser probe (2026-07-15 실측)

> **핵심 함정 (금기 #62, NEW)** — `notebooklm list --json`은 멀티 Google 계정 풀에서 노트북을 표시하지만, **RPC 호출(`download video`, `artifact get`, `--json` 모드의 `artifact list`)은 인증된 `authuser=0` 한 계정으로만 라우팅**된다. 이 PC가 `hjshin@ubob.com` (Google Workspace) 하나로만 signed-in 상태인데 list에 다른 Gmail 계정의 노트북이 섞여 보일 때, **모든 download/get 시도가 "No completed video artifacts" 또는 `RPC rLM1Ne returned null result`로 실패**한다.

## 증상

### 정상 케이스 (authuser 일치)
```
notebooklm list --json → 5개 표시
notebooklm artifact list -n <nb_id> → completed ✅
notebooklm download video --all /tmp/.../ --force → mp4 다운로드 ✅
```

### Broken 케이스 (authuser mismatch)
```
notebooklm list --json → 5개 표시 (다른 계정 노트북 포함)
notebooklm artifact list -n <nb_id> (테이블 출력) → completed 표시 ✅ (이것만 정상)
notebooklm artifact list -n <nb_id> --json → "RPC rLM1Ne returned null result" ❌
notebooklm download video --all /tmp/.../ --force → "No completed video artifacts found" ❌
notebooklm download video -n <nb_id> --all /tmp/.../ --force → 동일하게 ❌
notebooklm use <nb_id> → "RPC rLM1Ne returned null result with status code 5 (Not found)" ❌
```

**핵심**: `--force`로 verification을 우회해도 download는 여전히 실패 (context는 박혀도 실제 artifact fetch는 다른 계정).

## 진단 3단계 oneliner

### 1단계: storage_state.json account 메타데이터 확인
```bash
python3 -c "
import json
d = json.load(open('/Users/mac/.notebooklm/profiles/default/storage_state.json'))
acct = d.get('notebooklm', {}).get('account', {})
print('authuser:', acct.get('authuser'))
print('email:', acct.get('email'))
print('top keys:', list(d.keys()))
"
```
- `authuser=0, email=@ubob.com` → **Google Workspace 계정 (금기 #23/#36 케이스)**
- `authuser=0, email=@gmail.com` → consumer Gmail (정상)

### 2단계: authuser probe (이 PC에 몇 개 계정이 signed-in되어 있는지)
```python
# /tmp/probe_authuser.py
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, '/Users/mac/.hermes/venv-notebooklm/lib/python3.12/site-packages')

from notebooklm._auth.account import _probe_authuser, MAX_AUTHUSER_PROBE
from notebooklm._auth.cookies import build_httpx_cookies_from_storage
import httpx

async def main():
    storage = Path('/Users/mac/.notebooklm/profiles/default/storage_state.json')
    jar = build_httpx_cookies_from_storage(storage)
    print(f"Cookie jar: {len(jar)} cookies")
    async with httpx.AsyncClient(cookies=jar, timeout=30.0) as client:
        seen_emails = set()
        for n in range(MAX_AUTHUSER_PROBE):
            email = await _probe_authuser(client, n)
            if email is None:
                print(f"  authuser={n}: <no active or past last>")
                if n > 0:
                    break
                continue
            if email in seen_emails:
                print(f"  authuser={n}: {email} (DUP — past last)")
                break
            seen_emails.add(email)
            print(f"  authuser={n}: {email}")

asyncio.run(main())
```

**예상 결과 (2026-07-15 실측, 이 PC):**
```
Cookie jar: 26 cookies
  authuser=0: hjshin@ubob.com
  authuser=1: hjshin@ubob.com
  authuser=2: hjshin@ubob.com
  ... (모두 동일 — 단일 Workspace 계정)
  authuser=9: hjshin@ubob.com
```
→ **이 PC는 단일 Workspace 계정만 signed-in, 다른 Gmail 계정 노트북에는 접근 불가**

**정상 케이스 (멀티 계정 환경):**
```
authuser=0: primary@gmail.com
authuser=1: work@company.com  ← 노트북 소유자가 여기에 있을 수 있음
authuser=2: secondary@gmail.com
```

### 3단계: NotebookLM list의 owner 확인 (보조 진단)
```bash
/Users/mac/.hermes/venv-notebooklm/bin/python3 -m notebooklm list --json 2>&1 | python3 -c "
import json, sys
d = json.loads(sys.stdin.read())
print(f'총 {len(d[\"notebooks\"])} 노트북')
# is_owner=true 인 것만 카운트
owners = sum(1 for nb in d['notebooks'] if nb.get('is_owner'))
print(f'is_owner=true: {owners}')
"
```
- 모든 노트북 `is_owner=true` 인데 download 실패 → 거의 확실히 다른 계정 노트북이 섞여있음

## 해결 옵션

### 옵션 A — 풀 OAuth 재로그인 (5분, 추천)
1. `~/.hermes/venv-notebooklm/bin/python3 -m notebooklm logout` (현재 쿠키 무효화)
2. `~/.hermes/venv-notebooklm/bin/python3 -m notebooklm login` (PTY background launch)
3. 브라우저에서 **Gmail.com 계정 (Workspace 아닌)** 으로 로그인
4. 로그인 후 NotebookLM 홈 확인되면 ENTER → 토큰 자동 저장
5. `python3 -c "import json; print(json.load(open('~/.notebooklm/profiles/default/storage_state.json'))['notebooklm']['account'])"` 로 새 authuser/email 확인
6. `notebooklm list --json | grep "Xcode 없이"` 으로 노트북 보이는지 + `--json` 모드에서 artifact list 테스트

### 옵션 B — NotebookLM 웹 UI에서 수동 다운로드
1. notebooklm.google.com에 **노트북 소유자 Gmail 계정**으로 로그인
2. 5개 노트북 각각 들어가서 Studio → Video Overview → Download
3. 다운로드한 .mp4를 `/tmp/icbm_notebooklm/videos/`에 복사
4. `selection.json`에 `nb_id` + `file` 박은 후 `--review` → `--approved`

### 옵션 C — 사이클 보류, 다음 16:00 cron 대기
이번 사이클 skip, 다음 cron에서 새로 selected 받기

## 자주 하는 실수 (False Positive 진단)

| 증상 | 잘못된 진단 | 올바른 진단 |
|------|------------|------------|
| `artifact list` (테이블) = completed, `download` = not found | "노트북 상태가 변경됐다" | **계정 라우팅 mismatch** (테이블은 멀티 계정 풀, download는 단일 계정) |
| `--force` 후에도 "No completed video artifacts" | "Playwright 캐시 손상" | **인증된 계정에 그 노트북이 없음** (`--force`는 verification만 우회, artifact fetch는 그대로) |
| `auth refresh` 후에도 같은 에러 | "토큰 갱신 안 됨" | **`authuser=0` 계정 자체가 다른 계정** (refresh는 같은 계정 쿠키만 갱신) |
| `authuser=0` Workspace, `authuser=1~9` 모두 동일 | "authuser=N override 시도" | **이 PC에는 단일 계정만 signed-in**, override 불가능 (다른 Google profile의 쿠키 필요) |

## 자동 진단 스크립트 (재사용 가능)

`scripts/diagnose-account-routing.sh` — 다음 3가지를 한 번에:
1. storage_state.json `authuser`/`email` 출력
2. `notebooklm list --json | jq` 로 `is_owner` 비율
3. `notebooklm artifact list -n <첫 nb_id> --json` 으로 RPC 라우팅 테스트 (성공 = 정상, "RPC rLM1Ne returned null" = mismatch)

→ 한 번에 mismatch 판별 가능. partial upload 시작 전 필수.

## 연관 금기

- **금기 #23**: NotebookLM storage_state.json 0바이트 + 백업 만료 (venv 복구 직후 발생)
- **금기 #36**: OAuth 로그인 시 출력 도메인 ≠ 실제 쿠키 도메인 (`Account: user@ubob.com` 보여도 SID `.google.com`이면 정상 — 이 케이스와는 **반대** 케이스)
- **금기 #52**: `.google.co.kr` Workspace 쿠키 제거로 풀 OAuth 없이 인증 복구 (storage_state에 Workspace + Consumer 쿠키가 **둘 다** 섞여있을 때만 적용 가능, 이번 케이스는 **단일 Workspace**라 적용 불가)

## 결론

`notebooklm list --json`에 5개 노트북이 보이지만 어떤 download 시도든 "No completed video artifacts" 또는 "RPC rLM1Ne returned null result"로 실패하면, **이 PC의 인증된 Google 계정이 그 노트북의 소유자가 아님**. `authuser` probe로 단일/멀티 계정 환경 여부 즉시 판별 후 옵션 A/B/C 선택. **5분+ 자원 낭비 방지**.