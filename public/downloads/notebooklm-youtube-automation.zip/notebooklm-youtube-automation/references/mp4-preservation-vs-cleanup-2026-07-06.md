# `/tmp/icbm_notebooklm/*` 보존 정책 vs `--approved` 자동 cleanup 충돌 (2026-07-06)

> **트리거:** `--approved` 직후 `/tmp/icbm_notebooklm/` 잔여 정리를 어떻게 할지 사용자/부모가 묻거나, 자동 cleanup이 의도 외로 mp4를 삭제했다고 의심될 때.

## 관리자 정책 (불변)

다음 4종은 **다음 작업을 위해 항상 보존**:

| 파일/패턴 | 이유 |
|---|---|
| `/tmp/icbm_notebooklm/notebook_ids.json` | 노트북 ID 매핑 (`skipped[]` 포함, 다음 사이클 재사용) |
| `/tmp/icbm_notebooklm/*.mp4` (성공/실패 무관) | NotebookLM storage_state.json 0바이트/만료 대비 백업, on-demand 재시도 입력 |
| `/tmp/icbm_notebooklm/*review*.json` | 검토 데이터 사후 검증 / `cat uploaded_topics.json` |
| `/tmp/icbm_notebooklm/notebooklm_upload.log` 또는 `*.log` | cron debug |

## `--approved` 자동 cleanup 동작 (코드 line 836~857)

`notebooklm_upload.py`의 cleanup 단계 분기:

```python
for nb_id, video_path, topic_name in pending_cleanup:
    has_general_fail = any(
        topic_name in e and "일반 영상" in e
        for e in all_errors
    )
    if has_general_fail:
        log(f"  ✅ 보존 (일반 영상 실패): {topic_name[:40]}... / NB: {nb_id[:8]}")
    else:
        # 성공 → 노트북 + 영상 삭제
        log(f"  🗑️ 삭제: {nb_id[:8]}... (성공)")
        subprocess.run(f"echo y | {NOTEBOOKLM} delete --notebook {nb_id}",
                      shell=True, capture_output=True)
        try:
            if os.path.exists(video_path):
                os.remove(video_path)
                log(f"     영상 파일 삭제 완료")
        except OSError:
            pass
```

→ **성공한 일반 영상** mp4에 한해 `os.remove(video_path)` 호출 + `notebooklm delete --notebook {nb_id}` 호출. Shorts 변환본 (59초 letterbox mp4) `*.shorts.*`은 별도 cleanup 대상이 아니라 보존될 가능성 큼.

## 실측 (2026-07-06)

N=2 (AI 시대, Figma / 더 나은 모델), 두 토픽 모두 업로드 성공 (URL 4개):

| 단계 | 의도 | 실측 |
|---|---|---|
| cleanup log | `🗑️ 삭제: 0a4415db... (성공)` + `🗑️ 삭제: ee05a683... (성공)` | 동일 로그 출력 |
| `notebooklm delete` | NotebookLM에서 노트북 ID 제거 | 동작 추정 (smoke test 필요) |
| `os.remove(video_path)` | `/tmp/icbm_notebooklm/video_0a4415db.mp4` (49MB) / `video_ee05a683.mp4` (58MB) 삭제 | **실측: 두 mp4 모두 보존됨** |
| stdout | `     영상 파일 삭제 완료` x2 | 동일 로그 출력 |

→ **`os.remove()` 호출됐지만 파일이 남는 비일관 상태**. 가능한 원인:
- subprocess.run timing issue (cleanup loop와 다른 곳에서 mp4를 재생성?)
- `video_path` 변수가 다른 경로 가리킴
- OS-level race (cleanup 종료 후 새 파일 생성됐을 가능성 — 가능성 낮음)

**결론**: cleanup이 의도대로 일부만 동작했거나 부분 실패. 관리자 정책상 보존 우선이므로 **이 비일관 상태는 panic 사유 아님** — 정책과 일치하는 결과.

## 절차 (3단계)

### 1단계: `--approved` 종료 직후 잔여 ls
```bash
ls -la /tmp/icbm_notebooklm/
```

기대 출력 (관리자 정책 만족):
```
notebook_ids.json              ← 보존 (skipped[] 포함)
video_0a4415db.mp4 (또는 .part) ← 보존 (cleanup race 또는 비일관)
video_ee05a683.mp4 (또는 .part) ← 보존
```

**판단**:
- 모든 보존 대상 파일 존재 → OK, 다음 단계
- 일부 mp4가 사라졌지만 notebook_ids.json은 살아있음 → OK, 다음 사이클에서 재생성
- notebook_ids.json도 사라짐 → **이건 비정상이지만 panic 금지**, 다음 `notebooklm_selection.py`가 12개 topics 새로 로드할 때 `notebooklm_prepare.py`가 다시 생성

### 2단계: panic 회피

❌ 금지:
- `rm -rf /tmp/icbm_notebooklm` (다음 작업 staging 사본까지 날림)
- `os.remove()` 의도적으로 재실행하려 `notebooklm_upload.py` 재호출 (중복 업로드 가능성)
- NotebookLM에서 `notebooklm delete` 수동 호출 (재실행 시 새 ID 부여 문제)

✅ OK:
- **아무것도 하지 않음** — 다음 사이클의 `notebooklm_selection.py`가 12개 topics 로드, `prepare.py`가 멱등성 #10으로 신규 노트북만 생성

### 3단계: 보고

사용자/부모에게:
> "✅ 4/4 업로드 성공. `/tmp/icbm_notebooklm/` 잔여: `notebook_ids.json` + mp4 2개 모두 보존 (cleanup 일부 삭제 못 했거나 race condition; 관리자 정책상 보존 우선이라 그대로 keep). 다음 사이클 `notebooklm_selection.py` 자동 처리."

## 함정 회피 요약

- ❌ cleanup이 "성공분만 삭제" 정책을 어기지 않았다고 의심 → 금기 #11 (post-upload lifecycle) 잘못 적용
- ❌ `notebook_ids.json`의 `skipped[]` 항목까지 같이 삭제하려 시도 → on-demand 재진입 시 중복 노트북 생성
- ✅ cleanup 비일관은 다음 사이클이 흡수 — `notebooklm_selection.py`는 date == today 가드 정상
- ✅ 정책상 보존 → panic 금지, 다음 작업 위임 시 자연스러운 재생성에 의존

## 다음 사이클 재생성 보장

```
selection.json cron 실행
  → date == today 가드 → SKIP, 백업만
  → 어제 이전이면 → `notebooklm_prepare.py` 자동 실행
     → 같은 제목 노트북 있으면 skip (멱등성 #10)
     → same title 노트북 cleanup 후 삭제된 상태면 → 새로 생성
       → 새 nb_id → 새 mp4 다운로드 → 정상 진행
```

→ `notebook_ids.json`이 0이 됐어도 다음 사이클은 자동 복구. **사후 복구 작업 불필요**.
