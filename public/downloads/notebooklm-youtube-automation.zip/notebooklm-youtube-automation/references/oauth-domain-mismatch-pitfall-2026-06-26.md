# OAuth 로그인 Account 출력 vs 실제 쿠키 도메인 Mismatch (2026-06-26 검증)

## 핵심 한 줄

> **`notebooklm login` 완료 시 stdout에 출력되는 `Account: xxx@ubob.com`이 Google Workspace 도메인처럼 보여도, 실제 `storage_state.json` 안의 SID 쿠키는 `.google.com` (consumer Gmail)일 수 있다. 판단 기준은 출력 도메인이 아니라 SID 쿠키 `domain` 필드.**

## 실측 사례

```
Profile: default
Opening Chromium for Google login...
Using persistent profile: /Users/mac/.notebooklm/profiles/default/browser_profile

Instructions:
1. Complete the Google login in the browser window
2. Authentication will be saved automatically once login is detected

Waiting for login (up to 5 minutes)...
Login detected.
Identifying Google account...
Account: hjshin@ubob.com     ← Workspace처럼 보임

Authentication saved to: /Users/mac/.notebooklm/profiles/default/storage_state.json
```

이 출력을 보고 "Workspace 계정이네 → 인증 안 되겠지"라고 단정하면 **큰 오판**. 실제로는:

```bash
~/.hermes/venv-notebooklm/bin/python3 -c "
from notebooklm.auth import _load_storage_state
data = _load_storage_state()
for c in data.get('cookies', []):
    if c['name'] == 'SID':
        print('SID domain:', c['domain'])
        # .google.com → consumer Gmail (정상)
        # .google.co.kr → Google Workspace (인증 불가)
        break
"
```

→ **`.google.com`** → list/download 정상. **`notebooklm list --json`** 200 OK.

## 왜 이런 mismatch가 생기나

NotebookLM login flow는:
1. Chromium이 자동으로 Google 계정 선택 화면 띄움
2. 사용자가 브라우저에서 **여러 계정 중 하나** 골라 로그인
3. Chromium이 "현재 로그인된 Google 계정" 정보를 stdout에 뿌림 — 이게 `Account:` 라인
4. **이 라인에 표시되는 이메일은 "주 계정" 또는 "마지막 사용 계정"** 일 뿐, 실제 저장된 쿠키가 그 계정 거라는 보장은 없음
5. `storage_state.json`에는 그 순간 브라우저에 떠 있던 **모든 Google 세션 쿠키**가 저장됨

→ 출력 도메인은 **UI 신호**고, 실제 인증 가능 여부는 **쿠키 도메인**이 결정.

## 판단 기준 (1초)

| SID 쿠키 도메인 | 상태 | list/download |
|---|---|---|
| `.google.com` | consumer Gmail (정상) | ✅ 작동 |
| `.google.co.kr` | Google Workspace (한국) | ❌ 인증 불가 |
| `.google.co.jp` | Google Workspace (일본) | ❌ 인증 불가 |
| 그 외 `.google.<TLD>` | Workspace (해당 지역) | ❌ 인증 불가 |

## 추가 주의: Workspace에서도 작동할 수 있음

일부 Google Workspace 계정에서도 list/download는 작동한다 (2026-06-16 검증). 단, 시간이 지나면 Google이 SAML 리다이렉트 요구해서 막힐 수 있어 **장기적으로 불안정**. **consumer Gmail 계정이 안전**.

## 예방 절차

1. `notebooklm login` 완료 시 stdout의 `Account:` 줄은 **무시**
2. **항상 SID 쿠키 도메인 확인**:
   ```bash
   ~/.hermes/venv-notebooklm/bin/python3 -c "
   from notebooklm.auth import _load_storage_state
   data = _load_storage_state()
   for c in data.get('cookies', []):
       if c['name'] == 'SID':
           print(c['domain']); break
   "
   ```
3. `.google.com`이 아니면 **풀 OAuth 재로그인** (다른 계정으로)

## 관련 금기

- 금기 #23: NotebookLM storage_state.json 0바이트 함정 (만료 vs Workspace 차이)
- 금기 #24: 백업 만료 패턴
- 금기 #35: OAuth 로그인 시 출력 도메인 ≠ 실제 쿠키 도메인 (이 문서의 본체)
