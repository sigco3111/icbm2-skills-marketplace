# NotebookLM侯選 파일 혼동 버그 (2026-05-12)

## 증상
사용자가侯選 topic 번호 "2, 3, 4, 10"을 선택 → 에이전트가 "10번이 없다"고 잘못 응답.

## 근본 원인
두 JSON 파일의 역할을 혼동:

| 파일 | 역할 | 오늘侯選 포함? |
|------|------|---------------|
| `/tmp/icbm_notebooklm/notebook_ids.json` | prepare.py 실행 결과 — **이미 생성된 노트북**만 있음 (4개) | ❌ |
| `~/.hermes/memory/notebooklm_selection.json` | selection.py 실행 결과 — **오늘侯選 전체 topics** (11개) | ✅ |

에이전트가 `notebook_ids.json`만 읽어서侯選 10번이 "없다"고 판단.

## 재발방지
-侯選 topic 번호 매핑은 항상 `~/.hermes/memory/notebooklm_selection.json`의 `topics` 배열 사용
- `notebook_ids.json`은 노트북 ID 확인용으로만 사용
-侯選 번호로 topics를 조회할 때: `topics[n-1]` (1-indexed 번호 → 0-indexed 배열)

## 추가教训: upload_pipeline OAuth 토큰 만료

오늘 upload_pipeline 실행 시 timeout 120초 발생. 실제 원인:
```
$ python3 -c "..."
creds.valid: False
creds.expired: True
creds.refresh_token: True
```

토큰이 만료되어서 `yt_upload.py`가 OAuth refresh loop에 빠져 hanging 상태.
수동으로 토큰 refresh 후 정상 업로드 완료.

**반복教训:** 토큰 만료 시 upload script가 120초 이상 hung 상태가 됨.
이전 호출이 credential을 refresh하면 다음 호출은 정상 동작.