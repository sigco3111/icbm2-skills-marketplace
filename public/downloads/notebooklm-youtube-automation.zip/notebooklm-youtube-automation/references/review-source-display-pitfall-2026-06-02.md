# `--review` 출처 표시 함정 (2026-06-02 pitfall)

## 무엇이 일어났나

2026-06-02 업로드 검토 시 `--review` 검토 메시지에서 두 종류의 출처 URL이 표시되어 사용자가 혼란:

1. **`sources[].url`** — NotebookLM 노트북에 추가된 원본 기사 URL
   - 예: `nvidia.com/en-us/products/rtx-spark/`, `github.com/zubair-trabzada/geo-seo-claude`, `venturebeat.com/...`
2. **`topic_url`** — `selection.json` topics 배열의 GeekNews 토픽 URL
   - 예: `news.hada.io/topic?id=30102`

사용자: **"출처는 모두 깃뉴스 출처로 해야함."**

→ 사실 description은 **이미 `topic_url` (GeekNews URL)**을 사용하고 있었음. 표시 혼동만 발생. 10분간 응답 없음 + "수정중임?" 추가 질문.

## 왜 헷갈렸나

`upload_review.json` JSON 구조:

```json
{
  "topics": [
    {
      "index": 1,
      "topic_name": "...",
      "description": "...📚 출처\n• {topic_name}\n  https://news.hada.io/topic?id=30072\n...",  // ← GeekNews URL ✅
      "topic_url": "https://news.hada.io/topic?id=30072",     // ← GeekNews URL ✅
      "sources": [                                                // ← NotebookLM 원본 URL
        {
          "title": "...",
          "url": "https://thoughts.hmmz.org/2026-05-31.html",   // ← 메타데이터일 뿐
          "type": "SourceType.WEB_PAGE"
        }
      ]
    }
  ]
}
```

**`description`과 `topic_url`은 모두 GeekNews URL**이지만, `sources[]`만 다르게 보여서 사용자가 "description에 다른 URL이 들어가는구나" 라고 오해.

## 해결: 검증 패턴 (3초 안에 확인)

```python
import json, re
with open('/Users/hjshin/.hermes/memory/upload_review.json') as f:
    d = json.load(f)
for t in d['topics']:
    urls = re.findall(r'https://[^\s]+', t['description'])
    for u in urls:
        assert 'news.hada.io' in u, f"#{t['index']} description에 GeekNews 외 URL: {u}"
print("✅ 모든 description 출처가 GeekNews URL입니다.")
```

## 다음 세션이 기억할 것

1. **`description` 안의 URL만 검증** — `sources[]`는 무시
2. **`description`에 `news.hada.io`만 있으면 정상** (GeekNews URL)
3. **사용자가 "출처는 깃뉴스로" 라고 하면 `description`을 먼저 확인** — `sources[]`는 메타데이터
4. **검토 메시지를 텔레그램으로 전송할 때** sources[]를 명시적으로 표시하면 사용자가 헷갈릴 수 있음 → 2026-06-02 교정:
   - 검토 메시지에서 `sources[]` 표시는 유지하되 (NotebookLM 검수용 메타데이터 가치는 있음)
   - **"이 출처는 YouTube에 올라가지 않고 GeekNews URL이 올라갑니다" 라는 안내 문구 1줄 추가** 권장

## 코드 패치 위치 (선택적 개선)

`scripts/notebooklm_upload.py`의 검토 메시지 포맷 함수에서:

```python
# 검토 메시지 푸터에 추가:
print("---")
print("ℹ️ 위 출처는 NotebookLM 노트북 검수용 메타데이터입니다.")
print("   YouTube에 업로드되는 description은 GeekNews 토픽 URL을 사용합니다.")
```

## 일자별 변경 이력

| 날짜 | 변경 |
|------|------|
| 2026-06-02 (저녁) | 첫 발생. 사용자가 "출처는 깃뉴스로" 라고 교정했으나, 사실 description은 올바르게 GeekNews URL을 사용 중이었음. 10분간 대기 + 추가 질문. 검토 메시지 표시가 두 출처를 같이 보여줘서 발생. |
