# cron 메시지 URL 부재 시 3-tier Fallback + Cron Output Canonical

**작성일:** 2026-07-12
**적용 케이스:** 16:00 cron 메시지에 후보 제목은 있지만 GeekNews URL이 포함 안 된 사이클.

## 🔍 핵심 문제

`notebooklm_selection.py`가 정상 동작하면 후보마다 `https://news.hada.io/topic?id=XXXXX` URL이 함께 출력됨. 7/12 케이스에서는:
- Notion DB 활성 후보 0개 (DB 자체가 비었거나 archive됨)
- cron LLM이 Notion 대신 직접 후보 12개 생성 (제목만)
- Telegram 메시지에 URL 미포함
- `selection.json`은 어제 데이터 그대로 (gold #56 mismatch)

→ `prepare.py`가 URL 없이 노트북 생성 시도 → 실패.

## 🚦 3-tier Fallback (URL 확보)

### Tier 1: Cron Output `.md` 파일 (가장 신뢰)

```bash
# 7/12 실측 위치
ls -la ~/.hermes/cron/output/dc9a2e6aaaaa/*.md | tail -5
# → 2026-07-12_16-01-06.md (3118 bytes)

# URL 추출
grep -E "https://news.hada.io" ~/.hermes/cron/output/dc9a2e6aaaaa/2026-07-12_16-01-06.md | head -30
```

**성공률**: 보통 높음 (cron LLM이 stdout에 URL을 출력한 경우).
**실패 케이스 (7/12)**: cron LLM이 후보 직접 생성 → stdout에도 URL 없음.

### Tier 2: Notion DB 직접 조회

```python
import subprocess, json

auth_header = "Authorization: " + "Bearer " + open('/Users/mac/.hermes/secrets/notion_token.txt').read().strip()
out = subprocess.check_output([
    'curl', '-s', '--max-time', '20',
    'https://api.notion.com/v1/databases/32e76f2e-9097-8081-98d0-f54524fe4c47/query',
    '-X', 'POST',
    '-H', 'Notion-Version: 2022-06-28',
    '-H', 'Content-Type: application/json',
    '-H', auth_header,
    '-d', json.dumps({"page_size": 100}),
]).decode()

d = json.loads(out)
print(f"전체 후보: {len(d.get('results', []))}개")
```

**성공률**: 활성 후보 DB가 잘 관리되어 있다면 높음.
**실패 케이스 (7/12)**: DB 404 (`object_not_found`). DB ID가 stale이거나 archive됨.

### Tier 3: HN Algolia 검색 (마지막 수단)

```bash
# 영어 제목 (직접 인코딩)
curl -s "https://hn.algolia.com/api/v1/search?query=AI+2040+Plan+A&tags=story&hitsPerPage=3" | python3 -c "
import json, sys
d = json.load(sys.stdin)
for h in d.get('hits', [])[:3]:
    print(f\"  - {h.get('title', '?')[:80]}\")
    print(f\"    url: {h.get('url', '?')}\")
"

# 한글 제목 (URL 인코딩 필수)
curl -s "https://hn.algolia.com/api/v1/search?query=%ED%84%B0%EB%AF%B8%EB%84%A4%EC%9D%B4%ED%84%B0+2+%EA%B8%B0%EC%88%A0&tags=story&hitsPerPage=3"
```

**성공률**: 영어 제목은 양호, 한글은 낮음 (HN 자체가 영어 위주).
**실패 케이스 (7/12)**: `#7 '터미네이터 2' 기술의 구술사`는 HN/Algolia에 검색 결과 0건 → 선택에서 제외.

**핵심 인사이트**: HN Algolia는 title 필드에서 매칭하므로 **영문 키워드 ≥2개 + 의미있는 단어** 조합이 효과적. 한글 단독은 매칭 어려움.

## ⚠️ Cron Output Canonical Source 패턴

`~/.hermes/cron/output/<job_id>/<날짜>.md` 는 cron stdout canonical. **3가지 케이스에서 사용**:

| 케이스 | `.md` 상태 | Telegram 메시지 | 해결 |
|--------|-----------|----------------|------|
| 1. 정상 | URL 12개 모두 포함 | 그대로 전달 | Tier 1로 URL 추출 |
| 2. Truncation | URL 12개 모두 포함 | 8/12 잘림 | `.md`로 보충 |
| 3. URL 부재 (NEW) | stdout에 URL 없음 | 제목만 | Tier 2 → Tier 3 |

**핵심**: Telegram은 사용자용 알림, `.md`는 canonical. **Telegram만 보고 "URL 없네" 라고 판단하지 말 것**.

## ⚠️ 정책 #8 위반 알림 (필수)

원본 URL로 노트북 생성 시 사용자에게 한 줄 알림:

> ⚠️ **정책 #8 위반 알림**: 원본 URL은 `news.hada.io`가 아닙니다 (이번만 예외로 진행). 향후 사이클에서 GeekNews URL 정상 확보되면 자동으로 정책 복귀.

## 📋 종합 진단 명령 (1분)

```bash
# 1. Cron output 확인
ls -la ~/.hermes/cron/output/<job_id>/<오늘날짜>*.md

# 2. Notion DB 활성 후보 확인
curl -sL "https://api.github.com/repos/<owner>/<repo>" | python3 -c "..."  # GitHub redirect 패턴 주의
# 또는 Notion DB 직접 조회

# 3. HN Algolia fallback (제목별)
for title in "AI 2040 Plan A" "GPT-5.6 Grok Claude Muse"; do
  curl -s "https://hn.algolia.com/api/v1/search?query=$title&tags=story&hitsPerPage=1" | python3 -c "
import json, sys
d = json.load(sys.stdin)
if d.get('hits'): print(f\"  $title → {d['hits'][0].get('url', '?')}\")
"
done
```

## 📚 연관 금기

- #56 — cron 메시지 vs `selection.json` mismatch (이 fallback의 트리거)
- #43 — cron empty stdout → LLM 거짓 보고 (Tier 1 무용지물 케이스)
- #58 — cron output canonical (Tier 1의 위치)
- #60 — GitHub API 301 redirect (다른 도구 조회 시 함정)
- gold #8 — 출처 URL은 GeekNews URL 사용 (이번만 예외 처리)
