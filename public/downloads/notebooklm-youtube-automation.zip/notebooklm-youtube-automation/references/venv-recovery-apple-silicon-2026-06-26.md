# venv 복구 — Apple Silicon (`/opt/homebrew/`) 레시피 (2026-06-26 검증)

## 맥락

`~/.hermes/venv-notebooklm` 폴더가 백업에서 복원됐거나 다른 사용자 PC 환경에서 가져온 경우, shebang + `pyvenv.cfg`가 깨진 상태일 수 있다. 이 레시피는 **Apple Silicon Mac (`/opt/homebrew/...`)** + 현재 사용자 `mac` 가정.

## 진단 (1초, 3개 명령)

```bash
cat ~/.hermes/venv-notebooklm/pyvenv.cfg | grep -E "^(home|executable)"
[ -e ~/.hermes/venv-notebooklm/bin/python3 ] && echo "OK" || echo "❌ bin/python3 없음"
head -1 ~/.hermes/venv-notebooklm/bin/notebooklm
```

**깨진 신호**:
- `executable` 경로가 `/usr/local/Cellar/...` (Intel) 또는 `/Users/hjshin/...` (다른 사용자)
- `bin/python3` 파일이 없음
- shebang이 `/Users/hjshin/.hermes/venv-notebooklm/bin/python3.12` 처럼 다른 사용자 가리킴

## 5분 복구 레시피

```bash
# 1) 깨진 venv 통째로 제거
rm -rf ~/.hermes/venv-notebooklm ~/.hermes/venv-notebooklm-enterprise

# 2) Python 3.12 확인 (없으면 설치)
ls /opt/homebrew/bin/python3.12 2>/dev/null || brew install python@3.12

# 3) venv 재생성
/opt/homebrew/bin/python3.12 -m venv ~/.hermes/venv-notebooklm

# 4) 5개 패키지 한 번에
~/.hermes/venv-notebooklm/bin/pip install --quiet --upgrade pip
~/.hermes/venv-notebooklm/bin/pip install --quiet "notebooklm-py[browser]" \
  requests google-api-python-client google-auth-oauthlib google-auth-httplib2

# 5) Playwright chromium
~/.hermes/venv-notebooklm/bin/playwright install chromium

# 6) 검증
~/.hermes/venv-notebooklm/bin/notebooklm --version
# → NotebookLM CLI, version 0.7.x
```

## ⚠️ 함정 1: Python 3.9 시스템 fallback은 작동 안 함

Apple Silicon에서 시스템 `/usr/bin/python3`는 **3.9.6** (PEP 604 미지원). `pip install --user "notebooklm-py[browser]"`로 설치는 성공해도 실행 시:

```
TypeError: unsupported operand type(s) for |: 'type' and 'NoneType'
```

발생 위치: `cli/helpers.py:111 get_current_notebook() -> str | None:`

**결론**: venv-notebooklm은 반드시 3.10+ python으로. Apple Silicon에서는 `/opt/homebrew/bin/python3.12` (or 3.11/3.13) 권장.

## ⚠️ 함정 2: 인증은 venv와 무관

`~/.notebooklm/profiles/default/storage_state.json`은 venv 재생성 후에도 보존된다. **단** 다음 조건이면 만료:
- 파일이 0바이트로 변함 (금기 #24)
- 쿠키 만료 (보통 1년+, 그러나 백업에서 가져온 경우 이미 만료)

만료 시 풀 OAuth 재로그인 필요 (PTY + 백그라운드 + `notebooklm login`).

## ⚠️ 함정 3: 검증 스크립트 false negative

`cd /Users/mac/.hermes && source venv-notebooklm/bin/activate`처럼 cd 후 **상대 경로**로 activate하는 스크립트를 검증할 때, 절대 경로 `"/Users/mac/.hermes/venv-notebooklm/bin/activate"`로 substring match하면 **false negative** 발생.

**해결**:
```python
if "/Users/mac/.hermes" in content and "venv-notebooklm" in content:
    print("✅ OK")
```
두 토큰을 따로 검사하거나, `cd` 타겟 경로와 activate 경로 컴포넌트를 별도 assert.

## 관련 금기

- 금기 #21: Homebrew python@3.13 사라짐 + venv broken interpreter (이전 세션, Intel Mac)
- 금기 #22: `notebooklm` vs `notebooklm-py` 패키지 이름
- 금기 #23: `notebooklm-py[browser]` extra + Playwright chromium 필수
- 금기 #24: storage_state.json 0바이트 함정
- 금기 #33: venv 경로 사용자/아키텍처 차이 사전 감지
- 금기 #34: Python 3.9 시스템 fallback은 작동 안 함
- 금기 #36: venv 경로 검증 스크립트 false positive

## 실측 세션

- 2026-06-26: Apple Silicon `mac` 사용자, 백업에서 복원된 venv, `bin/python3` 부재, `pyvenv.cfg`가 `/usr/local/...` 가리킴 → 위 레시피로 5분 내 복구.
