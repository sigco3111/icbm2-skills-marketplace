# NotebookLM 소스 교정 절차 (2026-05-21)

주인님이 "엉뚱한 소스가 들어갔다"고報告 시, 올바른 소스 URL로 교체하는 절차.

## 증상

`notebooklm source list` 출력 시 topic 제목과 무관한 다른 기사가 소스로 들어감.
(예: Qwen3.7-Max topic에 "Bambu AGPLv3 위반" 기사가 추가됨)

## 원인

NotebookLM이 GeekNews 토픽 URL(`news.hada.io/topic?id=XXXXX`)을 소스로 추가할 때,
토픽 페이지 하단에 표시된 **관련 아티클들 중 하나**를 잘못 scraping하는 것으로 추정.

## 교정 절차

### Step 1: 현재 소스 확인
```bash
cd ~/.hermes && source venv-notebooklm/bin/activate
notebooklm use <nb_id>
notebooklm source list
```
출력에서 잘못된 소스의 **Source ID**를 확인 (예: `87a9f019-ade1-4773-9c97-1e0ac364da73`).

### Step 2: 잘못된 소스 삭제
```bash
notebooklm source delete <WRONG_SOURCE_ID> -y
```

### Step 3: 올바른 소스 추가
```bash
notebooklm source add "<CORRECT_URL>"
```
주인님이 직접 URL을 알려주면 그걸 사용. 모르겠으면 GeekNews 원본 기사를 크롤링:
```bash
# GeekNews 토픽 페이지에서 "원본 기사" 링크 추출 (HTML 구조 기준)
curl -s "https://news.hada.io/topic?id=XXXXX" | grep -o '<a href="\[^"]*" class="bold ud"><h1>' | head -1
```

### Step 4: 확인
```bash
notebooklm source list
```
올바른 소스만 표시되면 완료.

## notebook_ids.json 업데이트

노트북 ID가 변경된 경우 (삭제 후 재생성):
```
/tmp/icbm_notebooklm/notebook_ids.json
~/.hermes/memory/notebooklm_selection.json
```
두 파일의 노트북 ID를 모두 업데이트해야 한다.

## 주인님이 교정 소스를 직접 알려준 경우

주인님이 `https://news.hada.io/topic?id=29716`처럼 정확한 URL을 주면,
Step 2~3만 실행하면 된다.