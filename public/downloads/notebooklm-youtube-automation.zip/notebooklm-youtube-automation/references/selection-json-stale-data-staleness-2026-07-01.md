# selection.json Stale Data 함정 (2026-07-01 발견)

## 문제

`notebooklm_selection.py`의 line 198 "이미 오늘 처리됨" 가드는 **같은 날 두 번째 실행** 시 정상 동작하지만,
**Notion DB 풀 자체가 다른 시각에 교체된 경우**에는 **stale data를 그대로 보존**하는 함정이 된다.

## 실패 시나리오 (실측 2026-07-01)

1. **2026-06-30 16:00 크론** — Notion DB 활성 풀 (id 30934~30967, 12개)로 selection.json 생성
2. **2026-07-01 새벽 무렵** — Notion 자동 일괄 upsert (GeekNews 신규 글 등) → 활성 풀 12개가 (id 30971~31002)로 교체
3. **2026-07-01 16:00 크론** — line 198 가드: `existing.date == "2026-07-01"` 이고 topics 존재 → **stale 보존** → 사용자 인상: "어제꺼"
4. **Notion DB 직접 조회** — 활성 풀은 (id 30971~31002) 정상 갱신되어 있음
5. **결론**: selection.json ≠ Notion DB 활성 풀 = "어제꺼" 인상

## 진단 체크리스트 (사용자가 "어제꺼"/"이상해" 보고 시)

| # | 확인 명령 | 정상 |
|---|---|---|
| 1 | `python3 -c "import json; print(json.load(open('/Users/mac/.hermes/memory/notebooklm_selection.json'))['date'])"` | 오늘 KST (YYYY-MM-DD) |
| 2 | Notion API로 활성 풀 직접 조회 (DB ID `34276f2e-9097-811e-ab69-f8759ecf0be7`) | created_time desc 정렬 |
| 3 | selection.json의 id 범위 vs Notion 활성 풀의 id 범위 비교 | 동일해야 정상 |
| 4 | selection.json의 topic name vs Notion 활성 풀의 topic name 비교 | 동일해야 정상 |

**불일치 시**: 아래 "강제 갱신 레시피" 적용.

## 강제 갱신 레시피 (5분, 검증됨)

```bash
#!/bin/bash
# /tmp/icbm_refresh_selection.sh
set -e

TS=$(date +%Y%m%d_%H%M%S)
SRC="$HOME/.hermes/memory/notebooklm_selection.json"
BAK="${SRC}.bak_refresh_${TS}"

# 1) 백업
cp "$SRC" "$BAK"
echo "✅ 백업: $BAK"

# 2) 삭제 — 덮어쓰기 방지 가드(line 198) 우회
rm "$SRC"
echo "🗑️ 삭제: $SRC"

# 3) 정상 재실행 (line 198 guard 우회해 새로 씀)
python3 "$HOME/.hermes/scripts/notebooklm_selection.py"

# 4) 검증
python3 -c "
import json
d = json.load(open('$SRC'))
ids = [int(t['url'].split('id=')[1]) for t in d['topics'] if t.get('url') and 'id=' in t['url']]
print(f'date: {d[\"date\"]}')
print(f'generated_at: {d[\"generated_at\"]}')
print(f'topics: {len(d[\"topics\"])}')
print(f'GeekNews ID range: {min(ids)} ~ {max(ids)}')
"
```

## 안전 가드

- 진행 중인 on-demand (selected 비어있지 않음)가 있으면 `rm selection.json` 금지. 대신 **importlib.util로 `load_topics()` + `format_selection_message()` 직접 호출** (방법 B, 2026-06-15 검증, `references/cron-16-00-silent-fix-2026-05-19.md`).
- 진행 중 on-demand 없을 때만 위 레시피 적용.

## 검증 oneliner

```python
import json
d = json.load(open('/Users/mac/.hermes/memory/notebooklm_selection.json'))
print(f'date: {d["date"]}')
print(f'generated_at: {d["generated_at"]}')
print(f'selected: {len(d.get("selected", []))}')
print(f'selection_numbers: {d.get("selection_numbers", [])}')
ids = [int(t['url'].split('id=')[1]) for t in d['topics'] if t.get('url') and 'id=' in t['url']]
print(f'GeekNews ID range: {min(ids)} ~ {max(ids)}')
```

## Notion DB 직접 조회 oneliner

```bash
TOKEN=$(head -1 ~/.hermes/secrets/notion_token.txt)
curl -sS -X POST "https://api.notion.com/v1/databases/34276f2e-9097-811e-ab69-f8759ecf0be7/query" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Notion-Version: 2022-06-28" \
  -H "Content-Type: application/json" \
  -d '{"filter":{"property":"상태","select":{"equals":"활성"}},"page_size":100,"sorts":[{"timestamp":"created_time","direction":"descending"}]}' \
  > /tmp/notion_active.json
```

서브에이전트에 위임해 통계 출력까지 받는 게 토큰 효율적 (이번 세션 실측: 1m16s로 12개 풀 + 일자별 분포 + 5개 통계 완료).

## 근본 해결 후보 (스크립트 패치 — 미적용)

`notebooklm_selection.py`의 line 198 가드를 다음 중 하나로 강화하면 이런 함정을 영구 제거 가능:

1. **`generated_at` 시각 비교** — 같은 날이라도 N시간(예: 4h) 이상 차이나면 재생성 허용 (구현 3줄)
2. **`topics` 해시 비교** — topics 배열 hash()해서 직전과 다르면 무조건 재생성
3. **강제 갱신 플래그** — `--force` 인자 추가 (cron 외 수동 사용)

→ **권장**: 옵션 2 (topics 해시 비교). Notion 풀이 하루에도 여러 번 교체될 수 있어 가장 견고.

## 사용자 워크플로 권장 (2026-06-29 확립 선호 반영)

사용자가 "후보가 어제꺼 같다 / 이상하다 / 같은 주제만 보인다" 같은 **모호한 보고**를 할 때:

1. **즉시 진단 2종** — selection.json date + Notion 활성 풀 직접 조회 (서브에이전트 위임)
2. **불일치 확인** → 4옵션 + 추천 명시 (사용자 선호: 4-option + 추천)
   - A. 텍스트로 12개 정리
   - B. selection.json 완전 리셋
   - C. GeekNews 최신 글 수동 추가
   - D. 바로 번호 선택
3. **선택 액션 즉시 진행** + 결과 + 다음 단계

**핵심**: "진단만 / action 한 번에 묶지 말 것" 사용자 선호. 진단 보고 후 **바로 갱신 옵션을 4가지 + 추천으로 묶어서 묻기**.

## 사용자 선호 (MEMORY user.md와 일치)

- **clarify 시 4옵션 + 추천 명시** — "그냥 어떻게?" ❌
- **모호한 보고 → 4옵션으로 좁히기** 후 진단+액션 1회 응답
- **16시 크론처럼 '어제'/어떤 기준이 모호한 단어 → 진단 즉시**
