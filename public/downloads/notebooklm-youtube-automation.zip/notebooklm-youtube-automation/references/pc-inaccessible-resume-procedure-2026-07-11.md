# PC 접근 불가 보류 시 재개 절차 (2026-07-11 패턴 정형화)

## 트리거 조건

다음 조건이 **모두** 충족되면 이 패턴 적용:

1. **사용자가 노트북 번호 선택을 완료** (예: "2, 7, 9, 12 노트북 생성")
2. **`selection.json` 패치까지 완료** (selection_numbers 박힘)
3. **실제 노트북 생성/업로드 작업은 PC 접근 불가로 보류**

즉 "사용자 결정은 끝났는데 실행 환경이 없는" 상태.

## 발견 배경

이전 세션들(Tailscale/Termius 시도, 이번 노트북 작업)에서 **같은 패턴이 반복적으로 발생**:

- 사용자는 텔레그램으로 의사결정만 가능
- 실제 실행은 로컬 PC에서 일어나야 함 (NotebookLM 로그인, Playwright, FFmpeg, yt_upload 등)
- PC 접근이 막혀있으면 자동화 파이프라인 자체가 정지

이전에 이런 케이스를 만났을 때 "그냥 보류"로 끝내면 다음 세션에서 같은 의사결정을 다시 해야 함. **재개 절차를 문서화해두면 PC 복구 후 즉시 이어서 진행 가능**.

## 핵심 원칙

| 원칙 | 설명 |
|------|------|
| **`selection.json` 절대 손대지 말 것** | 이미 패치된 `selection_numbers`를 보존. `topics` 배열 재작성 금지 (금기) |
| **재개 절차는 `/tmp/`에 저장** | 메모리가 아니라 파일 1개로 충분. 7일 후 stale data 우려 때문 |
| **`selection.json` 검증 oneliner 포함** | PC 복구 후 "패치 보존 여부" 즉시 확인 가능 |
| **함정/복구 부록 함께 저장** | 10단계 재개 절차 끝에 venv 깨짐, OAuth 만료 등 케이스별 복구 명령 |
| **메모리에는 안 적기** | 일회성 상황이라 7일 후 의미 없음. 메모리는 영구 자산에만 사용 |

## 표준 절차 (이번 세션 실측 검증)

### Step 1: selection.json 보존 검증

```bash
python3 -c "
import json
p = '/Users/mac/.hermes/memory/notebooklm_selection.json'
d = json.load(open(p))
print('✅ date:', d['date'])
print('✅ topics:', len(d['topics']))
print('✅ selected:', len(d['selected']))
print('✅ selection_numbers:', d['selection_numbers'])
"
```

### Step 2: 핵심 환경 상태 스냅샷

```bash
# storage_state.json (NotebookLM 인증)
ls -la ~/.notebooklm/profiles/default/storage_state.json
# 12KB+ = 정상, 0 bytes = 풀 OAuth 필요

# venv 인터프리터
ls /Users/mac/.hermes/venv-notebooklm/bin/python3
# No such file = §A venv 복구 필요

# YouTube 토큰
/usr/bin/python3 -c "
import pickle
c = pickle.load(open('/Users/mac/.hermes/secrets/youtube_token.pickle', 'rb'))
print(f'valid={c.valid}')
"
```

### Step 3: 재개 절차 문서 작성 → `/tmp/notebooklm-resume.md`

**필수 섹션 7종:**

1. 헤더: 작성 시각 + 대상 자동화 + **선택된 번호 명시** (예: "선택된 번호: 2, 7, 9, 12")
2. 선택된 토픽 표 (4컬럼: # / 카테고리 / 주제 / URL)
3. 10단계 재개 절차 (환경검증 → 인증확인 → prepare → 영상생성(사용자) → 다운로드 → on-demand패치 → 5종체크 → --review → 사용자확인 → --approved)
4. 부록 §A~§E (venv / OAuth / 일부실패 / 토큰만료 / Shorts실패)
5. 핵심 금기 8종 (selection.json 재작성, selected append, etc.)
6. 즉시 시작 체크리스트 (□ 체크박스 형태)
7. 작성자 + 시각 (예: "혜린, 2026-07-11 18:00 KST, PC 접근 불가로 보류")

**명령어 형태 가이드:**

- 모든 명령은 절대 경로 사용 (예: `/Users/mac/.hermes/venv-notebooklm/bin/python3`)
- `cd` + 상대경로 패턴 금지 (gold #17)
- heredoc 사용 시 `<<'PYEOF'` (no expansion) 권장
- `python3 -c "..."` 단독 호출은 OK, 단 멀티라인은 read_file로 대체 (2026-06-22 #40 검증)

### Step 4: 사용자에게 파일 경로 안내

텔레그램 답변에 다음 포함:
- `selection.json` 보존 사실
- `/tmp/notebooklm-resume.md` 위치
- PC 복구 후 재개 신호 (예: "에르메스PC 다시 켰어, 노트북 이어서 진행해줘")

## Step별 예상 시간

| Step | 시간 | 자동/수동 |
|------|------|----------|
| 환경 검증 | 1분 | 자동 |
| 인증 확인 | 30초 | 자동 |
| prepare.py | 4~6분 | 자동 |
| 영상 생성 | 5~15분 | **수동 (NotebookLM 웹 UI)** |
| 다운로드 | 1~2분 | 자동 |
| on-demand 패치 | 1분 | 자동 |
| 5종 사전 체크 | 10초 | 자동 |
| --review | 30초 | 자동 |
| 사용자 확인 | 사용자 응답 | **수동** |
| --approved | 1~2분 | 자동 |

총 15~30분 예상 (사용자 개입은 Step 4, Step 9 두 번).

## 메모리 vs 파일 선택 기준

| 상황 | 저장 위치 | 이유 |
|------|----------|------|
| PC 접근 불가 보류 (이번 케이스) | `/tmp/notebooklm-resume.md` | 일회성, 7일 후 stale |
| 특정 사용자 선호 (예: 호칭 변경) | `MEMORY.md` | 영구 |
| 새 함정 발견 (예: Workspace 쿠키 충돌) | `references/<topic>.md` | 영구 자산 |
| 재사용 템플릿 (예: 5종 사전 체크 oneliner) | `templates/<name>.md` | 영구 자산 |

## 다음 세션 진입 신호

사용자가 채팅창에 다음 중 하나 보내면 즉시 `/tmp/notebooklm-resume.md` 읽고 재개:

- "에르메스PC 다시 켰어, 노트북 이어서 진행해줘"
- "PC 살아났어. 아까 보류한 거 이어서 해줘"
- "재개해줘" (맥락상 보류 작업이 명확한 경우)

## 알려진 한계

- **storage_state.json 만료일이 다르면** PC 복구 시점에 풀 OAuth 재로그인 필요 → 사용자가 브라우저 클릭해야 함
- **NotebookLM 가격 정책 변경** 등 외부 요인 발생 시 절차 일부 무효화 가능
- **백업 파일 없음** — 이번 세션 storage_state.json.bak*, .personal_backup 모두 없음 확인. 백업 자동화는 별도 작업
