# NotebookLM YouTube 자동화 — 함정 & 실전 노트

## 1. 빈도 떨어짐 ≠ 손쉬움, 함정 9개

### ❌ 함정 1: `execute_code` cron 컨텍스트 차단

서브프로세스 호출이 차단되는 환경 (`BLOCKED: execute_code runs arbitrary local Python (including subprocess calls that bypass shell-string approval checks). Cron jobs run without a user present to approve it`)에서 파일 편집 시도하면 0회 tool call로 종료됨.

**해결**: `patch` / `write_file` 직접 호출. JSON 파일은 후행 newline이 다른 경우 `patch`가 reject할 수 있으니 그땐 `write_file`로 통째 재작성.

### ❌ 함정 2: `patch` 도구의 JSON 검증 reject

```bash
# 후행 newline / 외부 수정 등으로 line N, column M 에러 → .json 파일이라 더 엄격
# 예: "candidate content fails .json syntax validation (JSONDecodeError: Expecting ',' delimiter (line 92, column 15))"
```

**해결**: `read_file`로 통째 읽고 `write_file`로 rewrite. `selection.json` / `upload_review.json` 둘 다 pretty-print로 다시 저장됨.

### ❌ 함정 3: NotebookLM 비디오 오버뷰 생성 ≠ 즉시 사용 가능

UI에서 "Studio → Video Overview → 생성" 클릭 후 **5~10분** 소요. 그 사이 `notebooklm upload --approved` 실행하면:
- `⚠️ 비디오가 아직 생성되지 않음` 메시지
- 해당 주제 패스, 성공분만 업로드 ✅ (자동 스킵 로직 동작 확인: 2026-07-16)

**해결**: 비디오 오버뷰 생성 → 잠시 대기 → 모든 항목 만든 다음에 `--approved`. 사용자가 "N번 실패" 명시 시 `--review` 결과물 `upload_review.json`에서 해당 인덱스 통째로 제거 + `approved: true` 패치 후 `--approved`.

### ❌ 함정 4: `selection.json` pretty-print 자동 변환

`patch`로 일부 값만 바꾸면 pretty-print로 변환됨. 같은 파일을 다시 `patch`로 매칭하려면 새 형식으로 매칭해야 함:

```json
// 처음 상태 (간결)
"selection_numbers": [1, 3, 4, 10]

// patch 후 (pretty-print)
"selection_numbers": [
  1,
  3,
  4,
  10
]
```

### ❌ 함정 5: `--review`는 모든 selection 주제를 가져옴

`selection_numbers`가 4개면 4개 모두 검토 대상으로 들어옴. 사용자가 "실패한 것 빼고" 요청해도 --review 단계에선 알 수 없음.

**해결 흐름**:
1. `--review` 실행 → `upload_review.json` 4개 받음
2. 사용자가 실패한 번호 알림 → `upload_review.json`에서 해당 항목 통째 제거 + `approved: true` 패치
3. `--approved` → 비디오 없는 건 자동 패스 (15초 추가 시간 들지만 무관)

### ❌ 함정 6: 자동 스킵 후 사후 정리 동작

성공한 노트북만 자동 삭제, 실패분은 보존 (`재시도 대비`). 즉 한 번 `--approved` 돌리면 다음에 `--approved` 다시 돌리면 같은 비디오 오버뷰가 없으면 같은 항목만 다시 패스됨. **노트북 ID 기록해둘 것** (재시도 시 수동으로 `selection.json`에 다시 넣어야 함).

### ❌ 함정 7: "노트북 생성해" ≠ .md 파일 작성 (2026-07-17)

사용자가 **"노트북 생성해"** 라고 말하면 **반드시 `notebooklm_prepare.py --skip-telegram --auto`** 를 의미한다. `~/work/notebooklm/<번호>_<주제>.md` 같은 마크다운 파일을 만드는 행위는 **절대** 노트북 생성이 아니다.

**왜 위험한가**:
- 결과물 = 로컬 .md 파일 1개 (사용자가 보지도 못함)
- NotebookLM 웹 UI 에는 노트북이 0개 → 비디오 오버뷰 단계로 못 넘어감
- 사용자는 **"노트북 생성 왜 안함?"** 이라고 짜증 → 세션 신뢰도 하락 (실제 발생)

**판단 기준** — 다음 중 하나라도 해당하면 `notebooklm_prepare.py` 실행이다:
- 사용자가 후보 번호(예: "2, 3, 4, 5, 6, 8, 11")를 언급
- 이전 턴에 NotebookLM 후보 목록 cron 응답이 있었음
- 사용자가 "노트북 생성" / "노트북 만들어" / "NotebookLM 진행" 같은 표현 사용

**반대로 다음은 노트북 생성이 아니다**:
- "주제 설명해줘" / "이거 요약해줘" → 텍스트 응답
- "이 주제 관련 .md 작성해줘" 명시 → 로컬 파일 OK
- 일반 Q&A

### ❌ 함정 8: `selection.json` `selected` 필드 타입 충돌 (2026-07-17)

스크립트는 `selected` 를 `list[dict]` (topic 객체) 로 기대하지만, 사람이 손으로 적은 JSON 은 `list[str]` (이름 문자열) 인 경우가 많다.

```python
# 기존 동작: list[dict] 만 가정 → string list 면 TypeError
topic_name = topic["name"]   # 💥 TypeError: string indices must be integers
```

**수정 (`notebooklm_prepare.py:223~228`)**:
```python
elif selected and all(isinstance(x, str) for x in selected):
    # string 리스트 → name 매칭으로 topic dict 복원
    name_to_topic = {t["name"]: t for t in all_topics}
    selected = [name_to_topic[n] for n in selected if n in name_to_topic]
    log(f"  🔄 selected 복원: {len(selected)}개 (name → topic dict 매핑)")
```

### ❌ 함정 9: HTML 엔티티 (`&#039;`) 이름 매칭 실패 (2026-07-17)

Notion DB 에 저장된 `topics[].name` 은 가끔 HTML 엔티티 그대로 들어있다 (예: `앤트로픽·블랙스톤, 15억 달러 규모 &#039;AI 구현&#039; 합작사 Ode 출범`).  
사용자가 입력한 선택 이름은 보통 일반 어포스트로피(`'`) → **눈으로는 같아 보이지만 `==` 비교 실패** → 스크립트가 매칭 0건 으로 조용히 건너뜀.

**증상**: `🔄 selected 복원: 5개` (6개 선택했는데 5개만) — **조용한 데이터 손실**.

**해결 옵션** (우선순위):
1. **구조적 (권장)**: `selection.json` 에 `selected` 대신 `selection_numbers` 만 저장 → 스크립트가 `topics[i-1]` 로 직접 인덱싱 (이미 1차 경로로 구현됨). 6번 항목의 경우 인덱스 기반이면 매칭 실패 없음.
2. **검증**: 스크립트 시작 부분에 `len(selected) != len(selection_numbers)` 면 명시적 경고 + 누락 번호 출력.
3. **일회성**: `html.unescape()` 로 topics[].name 정규화 후 비교.

**실전 처리**: 인덱스 기반 경로를 우선 사용하고, `selected` 가 있으면 비교 검증 후 사용.

## 2. 메모리 노트와 실제 동작 일치 (2026-07-16 검증)

| 메모리 항목 | 실제 동작 | 일치 |
|---|---|---|
| `selection_numbers` 수동 패치 → `notebooklm_prepare.py --skip-telegram` (한국 자연어) | ✅ 정확히 동작 | ✅ |
| `--skip-telegram` 미지원? (upload만) 환경변수 미설정 시 자연 차단 | ✅ 정상 (텔레그램 토큰 없어도 stdout에 결과) | ✅ |
| **`notebooklm_upload.py`에 자동 스킵 로직 = 비디오 오버뷰 없으면 그 토픽만 패스** | ✅ 확인 (`⚠️ 비디오가 아직 생성되지 않음` 후 다음 주제로) | ✅ |
| 사용자가 "오버뷰 실패는 패스, 성공분만 업로드" 선호 | ✅ 정상 동작 | ✅ |

## 3. 실전 세션 흐름 (2026-07-16 → 2026-07-17 업데이트)

```
[크론] 16:00 NotebookLM 후보 12개 도착 → 텔레그램
[사용자] "1, 3, 4, 10 노트북 생성"
  ↓
[혜린] ~/.hermes/memory/notebooklm_selection.json 패치
       selection_numbers: [1, 3, 4, 10]
  ↓
[혜린] python3 notebooklm_prepare.py --skip-telegram --auto
       → 노트북 4개 생성 (각 ~5초)
  ↓
[사용자] NotebookLM UI에서 비디오 오버뷰 생성 (4개)
[사용자] "영상생성을 하나 실패했어, 성공한 3개만 업로드"
  ↓
[혜린] upload_review.json 검토 (4개 받음)
[혜린] 10번 인덱스(4번째) 항목 제거 + approved: true
[혜린] notebooklm_upload.py --approved
       → 6개 업로드 (3 normal + 3 shorts)
       → 1개 자동 패스 (실패분)
       → 성공 노트북 자동 정리, 실패분 보존
```

### 07-17 추가 케이스: HTML 엔티티 이름 매칭 실패 (함정 9)

```
[사용자] "2, 3, 4, 5, 6, 8 노트북 생성"   ← 6개 선택
  ↓
[혜린] selection.json 의 selected 에 string list 로 입력
       → script 가 TypeError → fallback: name 매핑 → 5개만 복원 (6번 매칭 실패)
       → 로그: "🔄 selected 복원: 5개 (name → topic dict 매핑)"
       → 5개 노트북 생성, 6번 조용히 빠짐
  ↓
[혜린] 사용자 알림: "6번 항목 누락, 다시 생성 원하시면 알려주세요"
```

## 4. 환경변수 / 시크릿

- `~/.hermes/secrets/telegram_bot_token.txt` (선택, 없어도 stdout 전달)
- `~/.hermes/secrets/telegram_chat_id.txt`
- `~/.hermes/secrets/notion_token.txt` (크론 세션에서 Notion DB 조회)
- `~/.hermes/secrets/youtube_oauth.json` (YouTube 업로드용)
- venv: `~/.hermes/venv-notebooklm/bin/`

## 5. 산출물 위치

- 후보: `~/.hermes/memory/notebooklm_selection.json`
- 검토: `~/.hermes/memory/upload_review.json`
- 다운로드 비디오: `/tmp/icbm_notebooklm/`
- Notion DB (후보 수집): `34276f2e-9097-811e-ab69-f8759ecf0be7`
