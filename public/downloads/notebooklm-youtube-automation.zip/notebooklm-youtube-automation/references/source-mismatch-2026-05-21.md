# NotebookLM 소스 불일치 사고 (2026-05-21)

## incident

`Qwen3.7-Max: 에이전트 프런티어`(topic_url: `https://news.hada.io/topic?id=29694`) 업로드 후,
주인님이 **"엉뚱한 소스가 들어갔다"**고 보고.

## root cause

`--review`에서 표시되는 출처가 **GeekNews 주제 URL**뿐이었음.
NotebookLM 노트북에 추가된 실제 소스(원본 기사 URLs)를 보여주지 않아서,
사용자가 업로드 전에 소스 correctness를 검증할 수 없었음.

## fix applied

`notebooklm_upload.py`의 `prepare_review()` 함수에서:
1. `get_notebook_sources(nb_id)`로 실제 노트북 소스를 조회
2. 검토 메시지에서 **NotebookLM 실제 소스**와 **주제 URL**을 모두 표시
3. `upload_review.json`의 `topics[].sources`에 실제 소스 배열 저장

## resulting review message format

```
◆ 2. Qwen3.7-Max: 에이전트 프런티어
🎬 일반 영상: Qwen3.7-Max: 에이전트 프런티어
🔥 숏츠: 🔥 Qwen3.7-Max: 에이전트 프런티어
📝 설명: ...

🔗 출처 (NotebookLM):         ← 사용자 검증용
  • {원본 기사 제목}
    {원본 URL}
  • {또 다른 소스}
    {URL}

📰 주제: https://news.hada.io/topic?id=29694
---
```

사용자가 **위(NotebookLM 소스)**와 **아래(주제 URL)**를 비교하여 소스 correctness를 즉시 검출 가능.