# On-Demand Upload — 2026-06-21 (3개 동시 업로드, GPT-5.5/인시던트/open-code-review)

## 시나리오
사용자가 NotebookLM에서 비디오 오버뷰 3개 생성을 완료하고 "업로드"라고 회신.
- 일반 4단계 파이프라인의 1~3단계(후보 전송 → 노트북 생성 → 영상 생성)는 **이미 완료**.
- 4단계(업로드)만 남은 상태.
- 노트북 ID는 사용자가 텔레그램으로 직접 전달:
  - `b696c7e0-...` GPT-5.5
  - `00c5b000-...` LLM 인시던트 보고서
  - `6495eaa2-...` open-code-review

## 사전 체크 — 5종 (금기 #20 + #25 + #27 + 신규 #29)

| # | 점검 항목 | 명령 | 기대 결과 |
|---|----------|------|----------|
| 1 | venv Python 인터프리터 정상 | `ls ~/.hermes/venv-notebooklm/bin/python3 && ~/.hermes/venv-notebooklm/bin/python3 --version` | Python 3.12.x 출력 |
| 2 | selection.json 상태 | `cat ~/.hermes/memory/notebooklm_selection.json` | `date`=오늘 KST, `selection_numbers`=[2,3,6], `selected` 3개 |
| 3 | 노트북 ID 매핑 | `notebooklm list --json` + 파싱 | 3개 노트북 ID 모두 출력 |
| 4 | 비디오 artifact status | `for nb in $NB1 $NB2 $NB3; do notebooklm use $nb && notebooklm artifact list 2>&1 \| grep Video; done` | 3/3 `completed` |
| 5 | YouTube 토큰 valid | `/usr/bin/python3 -c "import pickle; c=pickle.load(open('~/.hermes/secrets/youtube_token.pickle','rb')); print(c.valid)"` | `True` (False면 refresh 1차 시도) |

## 다운로드 — 각 노트북마다 use+download 반복 (금기 #18)

```bash
mkdir -p /tmp/icbm_notebooklm/videos
for nb_id in b696c7e0-1b64-4c3a-baf1-e2041c0300ee \
             00c5b000-1462-42da-8ccc-cc83bc9dbf63 \
             6495eaa2-f437-4962-840c-3317844c1ace; do
  /Users/hjshin/.hermes/venv-notebooklm/bin/python3 -m notebooklm use $nb_id 2>&1 | tail -1
  /Users/hjshin/.hermes/venv-notebooklm/bin/python3 -m notebooklm download video --all /tmp/icbm_notebooklm/videos/ --force 2>&1 | tail -3
done
ls -la /tmp/icbm_notebooklm/videos/   # ← 파일 수 = 3개 검증
```

**실제 다운로드 결과 (NotebookLM 자동 생성 제목, 토픽 ≠ 파일):**
- `AI 무한 확장 신화와 환각 문제.mp4` (← GPT-5.5 토픽)
- `LLM 인시던트 보고서의 미래.mp4` (← LLM 인시던트 토픽)
- `알리바바 open-code-review.mp4` (← open-code-review 토픽)

→ 금기 #27 확인: 3/3에서 토픽명 ≠ 파일명. ls 후 토픽→파일 매핑 dictionary 작성 필수.

## selection.json 패치 — nb_id + file 명시 (금기 #26)

⚠️ **topics 배열을 처음부터 재생성하지 말 것** — `notebooklm_selection.py`가 생성한 `topics` 배열(12개) 보존, **`selected` 배열과 매칭되는 `topics` 항목에만 `nb_id`/`file` 추가**.

```bash
# 1) 백업
cp /Users/hjshin/.hermes/memory/notebooklm_selection.json \
   /Users/hjshin/.hermes/memory/notebooklm_selection.json.bak_pre_ondemand_2026-06-21

# 2) write_file로 전체 JSON 다시 쓰기 (선택된 topics에 nb_id/file 추가)
#    patch로 selected만 패치하면 들여쓰기 깨질 수 있음 (금기 #26의 일부)
```

**3종 세트 검증 oneliner (금기 #27):**
```bash
python3 -c "
import json, os
d = json.load(open('/Users/hjshin/.hermes/memory/notebooklm_selection.json'))
for t in d['selected']:
    assert t.get('nb_id'), f'{t[\"name\"]} nb_id missing'
    assert t.get('file'), f'{t[\"name\"]} file missing'
    assert os.path.exists(t['file']), f'{t[\"name\"]} file not found: {t[\"file\"]}'
    assert 'https://' in t['url'], f'{t[\"name\"]} url missing'
print(f'✅ {len(d[\"selected\"])} topics validated (nb_id + file + url)')
"
```

## YouTube 토큰 refresh (금기 #25)

토큰이 `valid=False`인 경우 1차 시도:
```bash
/usr/bin/python3 -c "
import pickle
from google.auth.transport.requests import Request
p = '/Users/hjshin/.hermes/secrets/youtube_token.pickle'
c = pickle.load(open(p,'rb'))
try:
    c.refresh(Request())
    pickle.dump(c, open(p,'wb'))
    print('✅ refresh 성공')
except Exception as e:
    print(f'❌ refresh 실패 → 풀 OAuth 필요: {e}')
" 2>&1 | grep -v -E "(FutureWarning|NotOpenSSLWarning|warn)"
```

**이번 세션 결과:** `valid=False` → `c.refresh(Request())` 1차 성공. 풀 OAuth 5분 절차 안 걸림.

## --review (검토)

```bash
/Users/hjshin/.hermes/venv-notebooklm/bin/python3 \
  /Users/hjshin/.hermes/scripts/notebooklm_upload.py --review 2>&1 | tail -20
```

**검토 결과 (3/3 description에 GeekNews URL 정상 박힘 — 금기 #26 검증):**

| # | 토픽 | 일반 영상 | Shorts |
|---|------|-----------|--------|
| 1 | GPT-5.5, MIT 라이선스 GLM-5.2보다 환각률 3배 | https://news.hada.io/topic?id=30668 | 🔥 GPT-5.5... |
| 2 | LLM이 작성한 인시던트 보고서의 미래가 두렵다 | https://news.hada.io/topic?id=30675 | 🔥 LLM 인시던트... |
| 3 | open-code-review — Alibaba의 AI 코드 리뷰 도구 | https://news.hada.io/topic?id=30677 | 🔥 open-code-review... |

## --review 후 read_file 안전망 (금기 #19)

`/Users/hjshin/.hermes/memory/upload_review.json`을 직접 읽어서 사용자에게 표시.
텔레그램이 placeholder이거나 silent fail해도 검토 내용이 도달함.

## 핵심 학습

1. **사전 체크 5종**을 모두 통과한 후에야 `--review` 실행 — 사후 발견 시 자원 낭비 큼
2. **nb_id + file 명시** 필수 — on-demand에서 description 출처 박기 위해 (금기 #26)
3. **YouTube 토큰 refresh 1차 시도** — `valid=False`여도 refresh_token 살아있으면 5초 만에 회복
4. **write_file + read_file 2-툴 패턴**이 `execute_code` 차단 시 가장 깔끔한 우회 (금기 #13 heredoc 마스킹 회피)
5. **sibling subagent 경고** — 동시성 문제로 selection.json이 자식 에이전트에 의해 수정됐을 가능성. write_file 직후 read_file로 검증 권장
