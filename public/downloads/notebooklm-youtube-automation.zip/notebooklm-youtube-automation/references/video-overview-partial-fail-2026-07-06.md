# Video Overview Partial Fail — NotebookLM 자동 생성 실패 패턴 (2026-07-06)

> **요청 시나리오:** "비디오오버뷰 하나는 생성에 실패했음. 성공한 노트북 두개를 업로드해"
> **핵심 차이:** `selection.json`에 `skipped` 배열로 **실패 정보를 영속화** + `notebook_ids.json`에도 동일 필드 추가 → 다음 사이클에서 재처리 시 같은 NotebookLM 노트북을 또 시도하는 부작용 방지.

## 1단계: 실패 노트북 식별 (단서)

사용자가 "비디오오버뷰 생성에 실패"라고 하면 **먼저 어떤 노트북이 실패했는지 확인**해야 한다. Notion API나 selection.json에는 video overview 상태가 저장되지 않으므로, NotebookLM CLI 직접 조회:

```bash
for id in 0a4415db-f219-4ccf-808f-a90d95bd296a ee05a683-3c62-4bf3-ac32-f585479a3071 cd5e2c02-cc70-48a8-b674-855555402bc8; do
  echo "--- $id ---"
  bash -c "source ~/.hermes/venv-notebooklm/bin/activate && notebooklm download video --notebook $id /tmp/test_$id.mp4 2>&1" | head -3
done
```

**판별 신호:**
- `Video saved to: /tmp/test_<id>.mp4` → 성공 (artifact completed)
- `Error: No completed video artifacts found` → **실패** (artifact status != completed)

## 2단계: 성공한 노트북만 mp4로 이동

```bash
mkdir -p /tmp/icbm_notebooklm
mv /tmp/test_<SUCCESS_ID>.mp4 /tmp/icbm_notebooklm/video_<ID>.mp4
ls -la /tmp/icbm_notebooklm/
```

**⚠️ 함정**: `cd5e2c02`처럼 실패한 노트북은 **/tmp/test_*.mp4 파일이 생성되지 않음** (No completed artifact) → 별도 삭제 불필요.

## 3단계: selection.json 패치 — `skipped` 배열 추가 (NEW, 2026-07-06)

```json
{
  "date": "2026-07-06",
  "generated_at": "2026-07-06T17:11:00+09:00",
  "selection_numbers": [1, 6],
  "topics": [ /* 12개 모두 유지 (실패 노트북도 topics에 보존) */ ],
  "selected": [ /* 성공한 2개만 */ ],
  "skipped": [
    {
      "name": "AI 코딩 시대의 개발자 역할 변화: ...",
      "category": "개발팁",
      "url": "https://news.hada.io/topic?id=31165",
      "notebook_id": "cd5e2c02-cc70-48a8-b674-855555402bc8",
      "reason": "video_overview_generation_failed",
      "verified_at": "2026-07-06T17:50:00+09:00"
    }
  ],
  "auto_mode": false
}
```

**핵심 차이 (gold #28 vs #41 vs 이번 신규):**

| 항목 | gold #28 (failed 자동) | gold #41 (사용자 의도 exclude) | 이번 (Video Overview fail) |
|---|---|---|---|
| 제외 이유 | NotebookLM artifact list failed | 사용자 명시 ("이거 빼줘") | NotebookLM download `No completed` |
| `topics` 처리 | failed 항목도 topics 유지 | 12개 그대로 유지 | **12개 그대로 유지** |
| `selected` 처리 | REPLACE (성공분만) | REPLACE (사용자 선택만) | **REPLACE (성공분만)** |
| `skipped` 배열 | ❌ (없었음) | ❌ (없었음) | ✅ **신규 추가** |
| `notebook_ids.json` | 자동 cleanup이 failed 정리 | cleanup은 성공분만 정리 | **수동으로 skipped 블록 추가** |
| NotebookLM 노트북 | cleanup이 자동 삭제 | 보존 (다음 사이클 재사용) | **보존 (사용자가 웹에서 재생성 가능)** |

## 4단계: notebook_ids.json 패치 (병행)

`/tmp/icbm_notebooklm/notebook_ids.json`에도 동일하게 `skipped` 블록 추가:

```json
{
  "date": "2026-07-06",
  "notebooks": [ /* 성공한 2개만 */ ],
  "skipped": [
    {
      "id": "cd5e2c02-cc70-48a8-b674-855555402bc8",
      "title": "ICBM | AI 코딩 시대의 ...",
      "reason": "video_overview_generation_failed",
      "verified_at": "2026-07-06T17:50:00+09:00"
    }
  ]
}
```

## 5단계: `--review` / `--approved` — `selected` 2개만 처리

이후 일반 4단계 파이프라인 (gold #20 사전 체크 → `--review` → 사용자 확인 → `--approved`) 동일.

`upload_review.json`은 `selected` 길이 = 2로 자동 생성됨 (이번 세션 `approved=False` 대기).

## ⚠️ `--review` 결과의 `title` 키 누락 관찰 (2026-07-06, NEW)

이번 세션 `notebooklm_upload.py --review` 출력 분석 결과:

```python
{
  "topics": [
    {
      "description": "AI 시대, Figma를 다시 생각하다 관련 최신 소식을 다루는 영상입니다. ... #ICBM #AI #테크 #개발자 #인공지능",
      "tags": ["ICBM", "AI", "인공지능", "개발", "테크"],
      # ← "title" / "video_title" / "shorts_title" 키 없음
    },
    ...
  ]
}
```

**관찰**:
- `description` 필드는 정상 (GeekNews URL + 원본 URL 자동 resolve, 태그 5개)
- `tags` 필드 정상
- **`title`/`video_title`/`shorts_title` 키가 빈채로 생성** ← 신규 관찰

**영향**:
- YouTube 업로드 시 제목은 다른 경로 (topic name fallback)로 생성되어 정상 동작
- description + tags가 모두 깨끗해서 검토 단계 통과 가능
- 4옵션 (A: 그대로 업로드 / B: title만 지정 / C: SKIP / D: description 커스터마이즈) 워크플로 (사용자 선호와 일치)

**수정 후보** (미적용, 다음 사이클 검토):
- `notebooklm_upload.py`의 `prepare_review()` 함수에서 `selected[].name`을 `topics[].title`로 박는 로직 추가
- 또는 `upload_review.json` 직접 패치 후 `--approved` 진행

## 검증 oneliner (6종 통합, 이번 세션 실측)

```python
import json, os, subprocess

sel = "/Users/mac/.hermes/memory/notebooklm_selection.json"
out_dir = "/tmp/icbm_notebooklm"
PASS = 0; FAIL = 0

# T1: selection_numbers 정확
SN = json.load(open(sel))['selection_numbers']
assert isinstance(SN, list) and len(SN) > 0, f"selection_numbers empty: {SN}"
print(f"✅ T1: selection_numbers = {SN}"); PASS += 1

# T2: selected N개 = selection_numbers N개 매핑
d = json.load(open(sel))
exp = [d['topics'][n-1]['name'] for n in d['selection_numbers'] if 1 <= n <= len(d['topics'])]
got = [s['name'] for s in d['selected']]
assert len(d['selected']) == len(d['selection_numbers']), f"selected {len(d['selected'])} != selection_numbers {len(d['selection_numbers'])}"
assert exp == got, f"mismatch: exp={exp} got={got}"
print(f"✅ T2: selected {len(got)}개 = {got}"); PASS += 1

# T3: skipped (있으면) reason 정확
sk = d.get('skipped', [])
if sk:
    assert all(s.get('reason') == 'video_overview_generation_failed' for s in sk), \
        f"skipped reason mismatch: {[s.get('reason') for s in sk]}"
    print(f"✅ T3: skipped {len(sk)}개 (reason: video_overview_generation_failed)"); PASS += 1
else:
    print(f"⏭️ T3: skipped 없음 (해당 없음)")

# T4: mp4 파일 검증 (1280x720, ≥5MB)
for t in d['selected']:
    nb_short = t.get('nb_id', '')[:8] if t.get('nb_id') else None
    p = os.path.join(out_dir, f"video_{nb_short}.mp4") if nb_short else None
    if p and os.path.exists(p):
        sz = os.path.getsize(p)
        r = subprocess.run(["ffprobe","-v","error","-select_streams","v:0","-show_entries","stream=width,height","-of","csv=p=0",p], capture_output=True, text=True)
        dims = r.stdout.strip().split(",")
        assert sz >= 5_000_000, f"too small: {sz}"
        assert dims == ["1280", "720"], f"wrong dims: {dims}"
print(f"✅ T4: mp4 검증 (1280x720, ≥5MB)"); PASS += 1

# T5: notebook_ids.json 노트북 == selected
nbd = json.load(open(f"{out_dir}/notebook_ids.json"))
nbs_ids = {n['id'] for n in nbd.get('notebooks', [])}
sel_ids = {s.get('nb_id') for s in d['selected'] if s.get('nb_id')}
assert nbs_ids == sel_ids, f"mismatch: notebooks={nbs_ids} selected={sel_ids}"
print(f"✅ T5: notebook_ids.json notebooks = selected"); PASS += 1

# T6: upload_review.json (있으면) topics == selected
ur_path = "/Users/mac/.hermes/memory/upload_review.json"
if os.path.exists(ur_path):
    ur = json.load(open(ur_path))
    assert len(ur.get('topics', [])) == len(d['selected']), f"review topics {len(ur.get('topics', []))} != selected {len(d['selected'])}"
    print(f"✅ T6: upload_review topics = selected ({len(d['selected'])}개, approved={ur.get('approved')})"); PASS += 1
else:
    print(f"⏭️ T6: upload_review.json 없음 (--review 미실행)")

print(f"\n===== {PASS} PASS / 0 FAIL =====")
```

## 실측 결과 (2026-07-06)

- 3개 노트북 생성 → `cd5e2c02` (AI 코딩 역할 변화) 비디오 overview 생성 실패
- `notebooklm download video --notebook cd5e2c02-...` → "Error: No completed video artifacts found"
- 2개 성공한 mp4 (49MB / 58MB, 1280x720, 7분/8분 46초)
- selection.json `skipped: 1개` + notebook_ids.json `skipped: 1개` 추가
- `--review` → 2개 topics 검토 (title 키 없음 관찰)
- 4옵션 (A/B/C/D) 사용자 응답 대기 중

## 사용자 4옵션 메시지 템플릿

```
📋 현재 상태
- ✅ #1 AI 시대, Figma를 다시 생각하다 (1280x720, 49MB)
- ✅ #6 더 나은 모델, 더 나빠진 도구 (1280x720, 58MB)
- ❌ #10 AI 코딩 시대의 개발자 역할 변화 — 비디오 overview 생성 실패 (NotebookLM 클라우드)

검토 내용:
- description: {description 요약} + 출처 URL + #ICBM #AI #테크 #개발자 #인공지능
- tags: ['ICBM', 'AI', '인공지능', '개발', '테크']
- title: ⚠️ upload_review.json에 title 키 비어있음 (YouTube 자동 fallback 사용)

A. 그대로 업로드 (description 좋음, 태그 적절) → --approved
B. title만 지정 (예: [1] Figma 다시 생각하다 / [2] Better Models, Worse Tools)
C. 업로드 보류 (이번엔 SKIP)
D. description 커스터마이즈
```

## 함정 회피 체크리스트

- [ ] **모든 노트북에 대해** `notebooklm download video` 실행 후 success/failure 분기
- [ ] `skipped` 배열에 `reason: "video_overview_generation_failed"` 명시
- [ ] `notebook_ids.json`에도 동일 skipped 블록 추가
- [ ] topics 배열은 **REPLACE 금지** (12개 그대로 유지, 실패 노트북도 유지)
- [ ] selected 배열은 REPLACE (성공분만)
- [ ] `--review` 후 title 키 부재 관찰되면 사용자에게 보고
- [ ] `upload_review.json` 직접 read (Telegram placeholder 안전망, gold #19)
- [ ] `--approved` 직전 YouTube 토큰 valid=True 확인 (gold #40)
