# NotebookLM 재로그인 / venv 복구 절차 (2026-06-16 실측)

venv 복구 중 storage_state.json 0바이트 → 백업 만료 → 풀 OAuth 재로그인까지의 **완전한 로그 + 재현 가능한 절차**.

## 시나리오

**환경**: macOS 15.5, Homebrew python@3.13 사라진 상태에서 venv-notebooklm 깨짐.
**목표**: 5개 노트북 (CrankGPT, hera-agent-unity, AI/ML 논문, 리우데자네이루, tradingcodex) 업로드.
**장애**: venv 복구 + Playwright 누락 + storage_state.json 손상 3중 함정.

## Step 1: 사전 진단 (필수)

```bash
# 1) venv 인터프리터 상태
ls -la /Users/hjshin/.hermes/venv-notebooklm/bin/notebooklm
# -rwxr-xr-x 1 hjshin staff 208 Jun 16 16:12 → 정상 (해시 OK)

# 2) 인증 파일 상태
ls -la /Users/hjshin/.notebooklm/storage_state.json
# -rw------- 1 hjshin staff 0 Jun 16 16:12 → ⚠️ 0바이트 = 인증 풀림
```

**size=0이면 백업 시도 → 만료 시 풀 OAuth 진행.**

## Step 2: 백업 복구 시도

```bash
# 1) 가장 오래된 백업
cp ~/.notebooklm/storage_state.json.bak.personal ~/.notebooklm/storage_state.json
~/.hermes/venv-notebooklm/bin/python3 -m notebooklm list --json | head -3
# → {"error": true, "code": "UNEXPECTED_ERROR", "message": "Authentication expired"}

# 2) 중간 백업
cp ~/.notebooklm/storage_state.json.personal_backup ~/.notebooklm/storage_state.json
~/.hermes/venv-notebooklm/bin/python3 -m notebooklm list --json | head -3
# → 동일하게 expired
```

**두 백업 모두 만료. SID 도메인 검증 후 풀 OAuth 진행:**

```bash
~/.hermes/venv-notebooklm/bin/python3 -c "
from notebooklm.auth import _load_storage_state
data = _load_storage_state()
for c in data.get('cookies', []):
    if c['name'] == 'SID':
        print('SID domain:', c['domain']); break
"
# → .google.com (consumer Gmail, 정상)
# .google.co.kr 이면 Google Workspace 계정 → 인증 불가
```

## Step 3: Playwright + chromium 설치 (login 전제)

```bash
~/.hermes/venv-notebooklm/bin/pip install --quiet "notebooklm-py[browser]"
~/.hermes/venv-notebooklm/bin/playwright install chromium
# Chrome Headless Shell 148.0.7778.96 downloaded to ~/Library/Caches/ms-playwright/chromium_headless_shell-1223
```

**⚠️ 둘 중 하나라도 빠지면** login/list 즉시 종료.

## Step 4: 백그라운드 OAuth login

```bash
~/.hermes/venv-notebooklm/bin/python3 -u -m notebooklm login 2>&1 | tee /tmp/notebooklm_oauth.log
# → background=true, pty=true, notify_on_complete=true
```

**출력 시퀀스**:
1. `Profile: default`
2. `Opening Chromium for Google login...`
3. `Using persistent profile: /Users/hjshin/.notebooklm/profiles/default/browser_profile`
4. `Instructions: 1. Complete the Google login in the browser window 2. Authentication will be saved automatically once login is detected`
5. `Waiting for login (up to 5 minutes)...`

**사용자 액션**: Chromium 창이 자동으로 뜸 → consumer Gmail 계정으로 로그인 → 자동 저장.

## Step 5: 검증

```bash
~/.hermes/venv-notebooklm/bin/python3 -m notebooklm list --json | head -3
# → JSON 배열 (notebook 목록) 나오면 인증 성공
```

## 실수 노트

1. **`notebooklm-py`만 설치 후 login 시도** → "Playwright not installed" 메시지로 즉시 종료. v0.7.1 기준.
2. **PTY 모드 안 쓰고 background launch** → Chromium이 백그라운드 프로세스로 띄워져 사용자가 브라우저 창을 못 봄. 반드시 `pty=true`.
3. **tee 없이 background** → stdout 못 잡음. 반드시 `tee /tmp/notebooklm_oauth.log`.
4. **5분 timeout** → 사용자가 다른 일 하다 놓치면 자동 종료. `Waiting for login` 메시지 보이면 즉시 사용자에게 알림.
5. **storage_state.json이 0바이트인 채로 백업** → cp 명령이 빈 파일을 복사해서 "복구된 것"처럼 보임. `ls -la`로 size 먼저 확인.

## venv 복구 5분 레시피 (모든 금기 통합, 2026-06-16 검증)

```bash
# 1) 남은 python 확인
ls /usr/local/opt/ | grep python
# → python@3.10, python@3.12 등

# 2) venv 재생성 (3.12로)
/usr/local/opt/python@3.12/bin/python3.12 -m venv --clear /Users/hjshin/.hermes/venv-notebooklm

# 3) 패키지 ([browser] extra + Playwright 필수)
cd /Users/hjshin/.hermes/venv-notebooklm
./bin/pip install --quiet --upgrade pip
./bin/pip install --quiet "notebooklm-py[browser]"
./bin/playwright install chromium

# 4) 인증 상태 확인
ls -la ~/.notebooklm/storage_state.json
./bin/python3 -m notebooklm list --json | head -3
# → 0바이트거나 expired면 백업 복구 → 풀 OAuth

# 5) OAuth 재로그인 (필요시)
./bin/python3 -u -m notebooklm login 2>&1 | tee /tmp/oauth.log
# → background=true, pty=true
```
