# `notebooklm` 관련 도구 통합 진단 — 4가지 외부 의존성 1페이지 매트릭스

## 목적

"NotebookLM 업로드 자동화"가 깨졌을 때 어느 한 군데만 고치면 되는 일은 거의 없음. **venv, Playwright, 쿠키, YouTube 토큰**이 직간접으로 모두 연관. 매번 어디부터 손대야 할지 헷갈리는데, 이 reference가 1페이지 진단표 + 워밍업 절차 + 검증 명령을 모음.

## 4가지 외부 의존성 매트릭스 (2026-07-12)

| # | 의존성 | 상태 체크 1줄 | 정상 시그널 | 망가졌을 때 증상 | 복구 시간 |
|---|--------|-------------|----------|---------------|----------|
| 1 | `venv-notebooklm/bin/python3` | `ls ~/.hermes/venv-notebooklm/bin/python3` | python3.12 심볼릭 OK | `No such file or directory` | 5분 (재생성) |
| 2 | `notebooklm-py[browser]` + Playwright | `~/.hermes/venv-notebooklm/bin/playwright --version` | 1.x.x 출력 | `notebooklm login` 시 "Playwright not installed" | 3분 (pip + chromium 97MB) |
| 3 | `~/.notebooklm/profiles/default/storage_state.json` | `ls -la ~/.notebooklm/profiles/default/storage_state.json` | size > 0 (12KB+) | size = 0 또는 `Authentication expired` | 5분 (백업 → 풀 OAuth) |
| 4 | `~/.hermes/secrets/youtube_token.pickle` | `/usr/bin/python3 -c "import pickle; c=pickle.load(open('~/.hermes/secrets/youtube_token.pickle','rb')); print(c.valid)"` | `valid=True` | `valid=False` 또는 `invalid_grant` | 5초 (refresh) / 5분 (풀 OAuth) |

## "뭐부터 확인하지?" 의사결정 플로우 (체크리스트)

```
notebooklm list → 실패
  │
  ├─ #1 venv 깨짐? → §A 5분 재생성
  ├─ #2 Playwright 미스? → §B 3분 설치
  ├─ #3 쿠키 손상? → §C 5분 풀 OAuth
  └─ 1~3 다 정상 → #1 로그인 절차만 (PTY background, 1분)
                   + §D YouTube 토큰 valid 체크
```

## §A venv 재생성 5분 레시피 (gold #34 + #35 + §1)

```bash
ls /opt/homebrew/bin/python3.12 2>&1 || brew install python@3.12
rm -rf ~/.hermes/venv-notebooklm
/opt/homebrew/bin/python3.12 -m venv ~/.hermes/venv-notebooklm
~/.hermes/venv-notebooklm/bin/pip install --quiet --upgrade pip
~/.hermes/venv-notebooklm/bin/pip install --quiet "notebooklm-py[browser]" \
    requests google-api-python-client google-auth-oauthlib google-auth-httplib2
~/.hermes/venv-notebooklm/bin/playwright install chromium
~/.hermes/venv-notebooklm/bin/python3 -m notebooklm --version  # 0.7.x 확인
```

**인증 보존**: `~/.notebooklm/.../storage_state.json`은 venv와 무관 → 새로 login 안 해도 됨 (단 size=0이 됐을 수 있으니 확인 후 §C).

## §B Playwright 설치 (gold #23 + #24)

```bash
~/.hermes/venv-notebooklm/bin/pip install "notebooklm-py[browser]"  # browser extra
~/.hermes/venv-notebooklm/bin/playwright install chromium  # 97MB
```

둘 중 하나만 있어도 `notebooklm login`/`list`가 Playwright 의존성 부족으로 실패.

## §C 풀 OAuth 재로그인 (Cookie 단독 만료 / size=0 모두)

**size > 0 + 만료만 됐을 때** → `notebooklm login` (PTY background) 1분 안에 끝:
```bash
~/.hermes/venv-notebooklm/bin/python3 -u -m notebooklm login  # PTY + background + notify_on_complete
```

**size = 0 또는 파일 자체 없을 때** → §C.1 백업 복구 시도:
```bash
# 가장 오래된 백업 (.bak.personal, .personal_backup 순서)
cp ~/.notebooklm/storage_state.json.bak.personal ~/.notebooklm/storage_state.json
~/.hermes/venv-notebooklm/bin/python3 -m notebooklm list --json | head -3
# → expired면 백업 만료 → 풀 OAuth만 가능
```

§C.2 SID 도메인 검증 → `.google.com` 이어야 정상 (consumer Gmail vs Workspace 판정):
```bash
~/.hermes/venv-notebooklm/bin/python3 -c "
from notebooklm.auth import _load_storage_state
data = _load_storage_state()
for c in data.get('cookies', []):
    if c['name'] == 'SID':
        print('SID domain:', c['domain']); break
"
```

상세 풀 OAuth 절차 + Chromium PTY background launch 가이드:
- `references/notebooklm-relogin-2026-06-16.md` (전체 시나리오)
- `references/notebooklm-cookie-only-reauth-vs-venv-broken-2026-07-12.md` (이 reference가 가장 빠름)

## §D YouTube 토큰 valid 체크 (gold #25 + 07-12 env -i 강화)

```bash
# ⚠️ hermes-agent venv 충돌 회피 — env -i + PATH 정리 + sys.path 필터
env -i HOME=/Users/mac PATH=/usr/bin:/bin /usr/bin/python3 -c "
import sys, os, pickle
sys.path = [p for p in sys.path if 'hermes-agent' not in p]
c = pickle.load(open(os.path.expanduser('~/.hermes/secrets/youtube_token.pickle'), 'rb'))
print(f'valid={c.valid} refresh_token={\"있음\" if c.refresh_token else \"없음\"}')
" 2>&1 | grep -vE "^/Users/mac/Library|warnings\\.warn"
```

**왜 env -i 가 필요한지 (2026-07-12 실측)**: `/usr/bin/python3` (Python 3.9) 만 호출해도 Hermes agent의 Python 3.11 venv site-packages가 글로벌하게 잡혀서 `cryptography 41.x`의 `_rust.abi3.so`가 Python 3.11 ABI로 빌드된 채 import 시도 → `_PyType_GetName` 심볼 not found → ImportError. `env -i` + `sys.path` 필터로 격리.

**valid=False + refresh_token 있음** → 5초 갱신 (gold #40):
```bash
env -i HOME=/Users/mac PATH=/usr/bin:/bin /usr/bin/python3 -c "
import sys, os, pickle
sys.path = [p for p in sys.path if 'hermes-agent' not in p]
from google.auth.transport.requests import Request
p = os.path.expanduser('~/.hermes/secrets/youtube_token.pickle')
c = pickle.load(open(p, 'rb'))
c.refresh(Request())
pickle.dump(c, open(p, 'wb'))
print('✅ refresh 성공 → 곧바로 upload 재시도')
" 2>&1 | grep -vE "^/Users/mac/Library|warnings\\.warn"
```

**refresh 실패 시** → 풀 OAuth: `references/youtube-oauth-reauth.md` (§`youtube_reauth.py` background launch).

## §E 사전 체크 5종 oneliner (gold #29)

업로드 명령 수신 직전 항상 5종 한 번에:

```bash
ls /Users/mac/.hermes/venv-notebooklm/bin/python3 && \
python3 -c "import json; d=json.load(open('/Users/mac/.hermes/memory/notebooklm_selection.json')); print('date:', d['date'], 'sel:', d.get('selection_numbers'))" && \
ls /tmp/icbm_notebooklm/videos/ | wc -l && \
env -i HOME=/Users/mac PATH=/usr/bin:/bin /usr/bin/python3 -c "
import sys, pickle
sys.path = [p for p in sys.path if 'hermes-agent' not in p]
c = pickle.load(open('/Users/mac/.hermes/secrets/youtube_token.pickle', 'rb'))
print('yt_valid:', c.valid)
" 2>&1 | grep -vE "^/Users/mac/Library|warnings\\.warn"
```

기대 출력:
```
/Users/mac/.hermes/venv-notebooklm/bin/python3
date: 2026-07-12 sel: [2, 7, 9, 12]
4    ← 영상 파일 N개 = selected N개
yt_valid: True
```

## 일자별 실측 노트

- **2026-07-12**: venv 정상 + Playwright 정상 + 쿠키 12KB size>0 + 만료 → 1분 login만 (Section §C.1 PTY background). YouTube 토큰 valid=False → 5초 refresh 복구. cryptography ABI 충돌 1회 → env -i 우회.
- **2026-06-26**: venv 깨짐 (sj Mac 백업 이관) + size=0 → §A 5분 + §C 5분.
- **2026-06-16**: python@3.13 formula 사라짐 + 0B 백업 만료 → §A + §C 동일.

## 메모리 vs 스킬

- **스킬 적합**: 4-가지 의존성 매트릭스 + 의사결정 플로우 + env -i 회피법 + §A~§E 레시피
- **메모리 적합**: 토큰 valid 갱신 패턴 (이미 MEMORY.gold #25/#40), Workspace vs Consumer Gmail 함정 (이미 MEMORY.gold #23/#24)
- **상위 SKILL.md 통합 위치**: SKILL.md 본문 §"NotebookLM CLI 실행 원칙" 다음에 신규 subsection "사전 진단 + 트리아지 (5종)" 박는 걸 권장
