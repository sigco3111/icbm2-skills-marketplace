# verify-fix-2026-05-12.md — 2026-05-12 세션 기록

## ✅ 오늘 수정한 버그 3건

### Bug 1: upload.py 경로 오류 (upload_pipeline 실패)
**문제:** `notebooklm_upload_pipeline.py`의 `UPLOAD_SCRIPT_DIR`이 존재하지 않는 `~/.hermes/skills/creative/youtube-uploader/scripts/`를 가리켰음
**영향:** `[ERROR] upload.py 없음` → 모든 업로드 실패
**수정:**
```python
# Before
UPLOAD_SCRIPT_DIR = os.path.join(HOME, ".hermes/skills/creative/youtube-uploader/scripts")
NOTEBOOK_INFO_FILE = os.path.join(OUTPUT_DIR, "notebook_info.json")

# After
UPLOAD_SCRIPT = os.path.join(HOME, ".hermes/scripts/yt_upload.py")
UPLOAD_SCRIPT_DIR = os.path.dirname(UPLOAD_SCRIPT)
NOTEBOOK_INFO_FILE = os.path.join(OUTPUT_DIR, "notebook_info.json")

# upload_to_youtube() 내부:
# Before: upload_script = os.path.join(UPLOAD_SCRIPT_DIR, "upload.py")
# After:  upload_script = UPLOAD_SCRIPT
```

### Bug 2: notebooklm delete CLI 인자 오류
**문제:** `notebooklm delete <id> -y` → `Got unexpected extra argument (id)`
**수정:**
```python
# Before
r = nb_cmd(["delete", nb_id, "-y"])
# After
r = nb_cmd(["delete", "-n", nb_id, "-y"])
```
정답 확인: `notebooklm delete --help` → `notebooklm delete [OPTIONS]`, 옵션: `-n, --notebook TEXT`

### Bug 3: OAuth 토큰 만료 → 120초 timeout
**문제:** upload_pipeline 실행 시 `yt_upload.py` subprocess 호출이 120초 timeout.
직접 테스트: token이 expired → `creds.valid: False, creds.expired: True` → refresh 필요.
**수정:** 직접 `yt_upload.py` 호출 → 토큰 확인 → expired면 refresh → 성공.

**토큰 확인コマンド:**
```python
import os, pickle
from google.auth.transport.requests import Request
TOKEN_FILE = os.path.expanduser("~/.hermes/secrets/youtube_token.pickle")
with open(TOKEN_FILE, "rb") as f:
    creds = pickle.load(f)
print("valid:", creds.valid, "expired:", creds.expired)
if not creds.valid:
    creds.refresh(Request())
    with open(TOKEN_FILE, "wb") as f:
        pickle.dump(creds, f)
    print("Refreshed! valid:", creds.valid)
```

## 📁 파일 경로 혼동 주의 (매일 반복되는 실수)

오늘 같은 실수:侯選 topic 번호 매핑 시 `/tmp/icbm_notebooklm/notebook_ids.json`를 읽음 → 4개만 보임 → "10번이 없다"고 잘못 응답

**올바른 파일:**
- `~/.hermes/memory/notebooklm_selection.json` → **侯選 topics 목록** (date, topics[], selection_numbers)
- `/tmp/icbm_notebooklm/notebook_ids.json` → **이미 생성된 노트북 ID 목록** (prepare.py 결과물)
- `/tmp/icbm_notebooklm/notebook_info.json` → **업로드 파이프라인용 메타데이터**

**번외:**侯選 전송 크론의 DB ID = `41d83ee7-6925-4f77-a26d-40a3a10bf852`
prepare.py 내부 DB ID = `34276f2e-9097-811e-ab69-f8759ecf0be7` (다른 DB)

## ⚠️ yt_upload.py는 positional argument만 받는다

`yt_upload.py`는 `sys.argv[1]`, `sys.argv[2]`, `sys.argv[3]` positional 인자만 해석.
절대 `--title`, `--description` 같은 키워드 인자로 호출하지 말 것.

```python
# ✅ 올바른 호출
subprocess.run(["python3", script, file_path, title, description], ...)

# ❌ 잘못된 호출 (인자 무시됨)
subprocess.run(["python3", script, file_path, "--title", title, "--description", description], ...)
```

## 오늘 업로드 결과

| 영상 | YouTube | 길이 |
|------|---------|------|
| Rapid-MLX (일반) | https://www.youtube.com/watch?v=f_WMjPWWBhY | 537s |
| Rapid-MLX (Shorts) | https://www.youtube.com/watch?v=GJV57xSNNMY | 59s |
| GitHub이 침몰 (일반) | https://www.youtube.com/watch?v=lJmLWLYPSA0 | 467s |
| GitHub이 침몰 (Shorts) | https://www.youtube.com/watch?v=RNOBjQ2emzg | 59s |

**2번(M4 24GB 메모리) 영상은 생성 실패로 다운로드 못 함 → 업로드에서 제외됨.**