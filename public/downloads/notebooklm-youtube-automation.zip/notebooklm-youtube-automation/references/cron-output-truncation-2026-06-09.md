# 크론 출력 Truncation — 사용자 회신 번호가 후보 목록에 매핑 안 될 때

## 증상 (2026-06-09 실측)

16:00 크론이 Telegram으로 후보 12개를 보내야 하는데, **메시지 길이 제한으로 8번 항목 중간에서 잘림**:

```
오늘의 후보 주제 (12개) — 번호를 입력해주세요 (예: 1,3,5):

1. 🤖 DeepSeek V4 Pro, 정밀도에서 GPT-5.5 Pro를 앞서다
2. 🤖 Loop Engineering - Addy Osmani
3. 🤖 Show GN: 1인 앱 개발을 위한 React Native + Expo 베이스 ...
4. 🤖 Show HN: Lathe – LLM으로 새 도메인을 건너뛰지 않고 학습하기
5. 🤖 Show HN: Performative-UI – 디자인 트로프 기반 React 컴...
6. 🤖 Tokenomics: 에이전트형 SW 엔지니어링에서 토큰이 어디에 사용되는지...
7. 🤖 [2026/06/01 ~ 07] 이번 주에 살펴볼 만한 AI/ML 논문 모음
8. 🤖 xA    ← 여기서 절단, 9~12번 + 메타데이터 누락
```

→ 사용자가 "1, 6, 7, 10 노트북 생성" 이라고 회신하면 **에이전트가 어떤 주제가 10번인지 모름**.

## 안전 출처: 크론 출력 파일 (Telegram 메시지 X)

크론 job은 stdout 마커 + `~/.hermes/cron/output/<job_id>/<date>.md` 파일에 **전체 출력**을 저장한다. Telegram 메시지가 잘려도 파일은 완전.

```bash
# 최신 job의 출력 디렉토리
ls -t ~/.hermes/cron/output/ | head -1
# 예: dc9a2e6aaaaa

# 오늘 날짜의 .md 파일
cat ~/.hermes/cron/output/<job_id>/$(date +%Y-%m-%d)_*.md
```

## 표준 대응 절차

1. **사용자 회신 번호를 받기 전**: Telegram 메시지가 잘렸는지 의심되면 즉시 `~/.hermes/cron/output/<job_id>/` 의 최신 `.md` 파일을 `read_file`로 읽기.
2. **전체 후보 매핑 확인** 후 사용자에게 "잘려서 10번은 X 입니다, 맞죠?" 라고 짧게 확인 (선택).
3. **`selection.json`은 이미 완전한 topics 배열을 가지고 있음** — 그게 결국 canonical source. `cat ~/.hermes/memory/notebooklm_selection.json | jq '.topics[]'` 으로도 매핑 가능.
4. **selection_numbers 패치 시** topics 인덱스 매핑 안전: `topics[n-1]` (n=1~12).

## 핵심 교훈

- **Telegram 메시지 = 표시용, 진짜 source = `~/.hermes/cron/output/<job_id>/*.md`**
- 12개 이상 후보 시 Telegram truncation 거의 확정적 (특히 후보명에 코드블록/긴 제목 섞이면 더 잘림)
- 사용자가 "1, 6, 7, 10" 처럼 **잘린 번호**를 회신해도 **selection.json topics 배열로 안전하게 매핑 가능** (이름 안 봐도 됨)
- **verify the source, not the message** 패턴은 모든 cron-driven 워크플로에 적용

## 검증 스크립트 (옵션)

```bash
# 후보 수 + topics 길이 일치 확인
python3 -c "
import json
with open('/Users/hjshin/.hermes/memory/notebooklm_selection.json') as f:
    d = json.load(f)
print(f'topics={len(d[\"topics\"])} selection_numbers={d[\"selection_numbers\"]}')
for n in d['selection_numbers']:
    t = d['topics'][n-1]
    print(f'  {n}. {t[\"name\"]}  →  {t[\"url\"]}')"
```
