# nb_id 패치 + description 검증 2단계 패턴 — 2026-06-25 재검증

## 배경

`notebooklm_prepare.py --skip-telegram`은 **3가지 필드를 `selected[]`에 자동으로 채우지 않는다**:

1. `number` — topics 배열에도 없을 수 있음 (크론이 만든 selection.json은 `{name, category, url}` 3필드만)
2. `nb_id` — 노트북 ID는 `notebooklm list --json`에서 별도로 가져와야 함
3. `file` — 비디오 파일 경로 (다운로드 후 매핑 필요)

→ `upload_review.json`의 description에서 `📚 출처` 다음 줄이 비거나 `topic_url` 박기가 스킵됨 (금기 #26).

## 검증된 on-demand 진입 절차 (3/3 성공)

이 세션(2026-06-25, 1/5/7 → AI 전문성 재설계 / OpenAI Jalapeño / VibeThinker-3B)에서 실측 성공한 전체 절차:

```python
import json
p = '/Users/hjshin/.hermes/memory/notebooklm_selection.json'
d = json.load(open(p))

# 1) topics에 number 부여 (1~N 전체)
for i, t in enumerate(d['topics'], 1):
    t['number'] = i

# 2) nb_id 매핑 dict (notebooklm list --json으로 미리 조회한 값)
mapping = {
    1: {'nb_id': '3c1fc728-...', 'file': '/tmp/icbm_notebooklm/videos/AI 시대, 나의 전문성을 재설계하는 법.mp4'},
    5: {'nb_id': '2350b9c2-...', 'file': '/tmp/icbm_notebooklm/videos/OpenAI 할라페뇨_ 기대와 현실.mp4'},
    7: {'nb_id': '2a6bdaed-...', 'file': '/tmp/icbm_notebooklm/videos/VibeThinker-3B_ 거인을 이긴 모델.mp4'},
}

# 3) selected REPLACE (append 금지 — 금기 #15)
d['selected'] = []
for n in [1, 5, 7]:
    t = d['topics'][n-1].copy()
    t['nb_id'] = mapping[n]['nb_id']
    t['file'] = mapping[n]['file']
    d['selected'].append(t)
    # topics에도 채움 (--review가 topics.url을 fallback으로 사용)
    d['topics'][n-1]['nb_id'] = mapping[n]['nb_id']
    d['topics'][n-1]['file'] = mapping[n]['file']

json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
```

## 핵심: file 경로 정확성 (금기 #27 실측 3/3)

NotebookLM이 자동 생성한 비디오 파일명은 **한글 + 언더스코어(`_`) + 공백 + 콜론 일부 치환** 패턴이 섞여 있다. 이 세션 실측:

| 토픽 제목 | 다운로드 파일명 |
|---|---|
| AI시대, 나의 전문성을 재설계하는 법 | `AI 시대, 나의 전문성을 재설계하는 법.mp4` |
| OpenAI, Broadcom과 만든 첫 자체 추론 칩 Jalapeño 공개 | `OpenAI 할라페뇨_ 기대와 현실.mp4` |
| VibeThinker-3B: SFT+GRPO로 Opus 4.5 추론 성능을 넘긴 3B 모델 | `VibeThinker-3B_ 거인을 이긴 모델.mp4` |

**규칙**:
- 토픽 제목에서 콜론(`:`) 뒤 부분이 **자체 제목으로 대체**되는 경우가 대부분
- 한글/영문 공백, 언더스코어는 그대로 유지
- `ls /tmp/icbm_notebooklm/videos/` 후 토픽명 → 파일명 매핑 dictionary를 만들어 `selected[].file`에 정확히 입력

## 검증 oneliner (3종 — write_file 직후 필수)

```python
import json
d = json.load(open('/Users/hjshin/.hermes/memory/notebooklm_selection.json'))
for t in d['topics']:
    assert t.get('number'), f'topics[{t.get("name","?")}] number missing'
for t in d.get('selected', []):
    assert t.get('nb_id'), f'selected#{t.get("number")} nb_id missing'
    assert t.get('file'), f'selected#{t.get("number")} file missing'
    assert t.get('number'), f'selected nb_id={t["nb_id"][:13]} number missing'
print(f'✅ {len(d["topics"])} topics ({len(d["selected"])} selected) fully validated')
```

## description 검증 2단계 패턴 (금기 #26 강화, 2026-06-25 신규)

이전에는 `--review` 후 `upload_review.json` 1회만 description 검증을 했다. 이번 세션에서 **2단계 검증**으로 강화:

### 1단계: `--review` 직후 (GeekNews URL 박힘 확인)

```python
import json, re
with open('/Users/hjshin/.hermes/memory/upload_review.json') as f:
    d = json.load(f)
for t in d['topics']:
    urls = re.findall(r'https://\S+', t['description'])
    geeknews = [u for u in urls if 'news.hada.io' in u]
    assert geeknews, f"#{t['index']} description에 GeekNews URL 없음: {urls}"
    print(f"✅ #{t['index']} — GeekNews URL OK ({geeknews[0]})")
print('✅ 모든 description 출처가 GeekNews URL입니다.')
```

### 2단계: `--approved` 직전 (사용자 검토 후 다시 한 번)

`--review` → 사용자 확인 → `--approved` 사이에 `upload_review.json`이 다른 스크립트에 의해 변형될 가능성이 극히 낮지만, **YouTube 정책상 description에 출처 없는 영상은 검토 단계에서 차단**되기 쉽다. 사용자 승인 사이에 한 번 더 돌려서 "approved 시점에도 출처 OK" 보장:

```bash
/Users/hjshin/.hermes/venv-notebooklm/bin/python3 -c "
import json, re
d = json.load(open('/Users/hjshin/.hermes/memory/upload_review.json'))
for t in d['topics']:
    assert any('news.hada.io' in u for u in re.findall(r'https://\S+', t['description']))
print(f'✅ {len(d[\"topics\"])} topics — approved 직전 GeekNews URL 재검증 OK')
"
```

**이점**:
- `--review`에서 placeholder 토큰 문제 등으로 description이 비어서 박혔는데, 사용자가 "확인"을 누르기 전에 발견 가능
- 사용자가 `upload_review.json`을 직접 패치해서 사용자 지정 출처 URL을 박은 경우(예: 토스 URL)에도 정규식이 다른 URL을 감지하므로 사후 검증 가능

## YouTube 토큰 valid=False 발견 시 1차 refresh (금기 #29 4번째 확장, 2026-06-25 검증)

`upload_review.json` 생성 직후 `--approved` 직전에 YouTube 토큰 `valid=False`가 발견되면 1차 refresh로 5초 내 복구:

```bash
/usr/bin/python3 -c "
import os, pickle
from google.auth.transport.requests import Request
p = os.path.expanduser('~/.hermes/secrets/youtube_token.pickle')
c = pickle.load(open(p,'rb'))
try:
    c.refresh(Request())
    pickle.dump(c, open(p,'wb'))
    print(f'✅ refresh 성공 — valid={c.valid}')
except Exception as e:
    print(f'❌ refresh 실패 → 풀 OAuth 필요: {e}')
" 2>&1 | grep -v FutureWarning | grep -v NotOpenSSL
```

**검증된 결과**: refresh 성공 시 `--approved`가 곧바로 통과 (풀 OAuth 5분 절차 회피).

## 이번 세션 사전 체크 5종 통과 로그 (2026-06-25 17:05)

| # | 항목 | 결과 |
|---|---|---|
| 1 | venv 인터프리터 | `/Users/hjshin/.hermes/venv-notebooklm/bin/python3` 존재 OK |
| 2 | selection.json | `date=2026-06-25`, selection_numbers=[1,5,7] |
| 3 | 영상 파일 | 3개 다운로드 (총 14개 중 오늘 3개) |
| 4 | YouTube 토큰 | valid=False → refresh 성공 → valid=True |
| 5 | artifact status | 3/3 completed |

→ `--review` 1회 만에 통과, `--approved` 6개 영상(일반 3 + Shorts 3) 업로드.

## SKILL.md 본체 위치

이 학습은 본체 SKILL.md의 "금기" 섹션에 #32로 추가됨.