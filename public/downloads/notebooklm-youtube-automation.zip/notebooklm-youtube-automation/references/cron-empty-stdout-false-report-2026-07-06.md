# Cron Empty Stdout → LLM False Report 함정 (2026-07-06 실측)

## 증상

- 16:00 cron `dc9a2e6aaaaa` (NotebookLM 후보 전송) 가동
- Notion DB에 활성 후보 **12건 정상** (수동 `--dry-run` 으로도 확인)
- 그런데 cron 출력 .md 에 **"Notion DB에 활성 후보가 없습니다"** 라는 거짓 보고가 박혀서 도착
- 사용자가 "Notion 화면엔 12건 보이는데 왜 없다고 하지?" 라고 정정

## 진짜 원인

`notebooklm_selection.py`의 내부 호출 체인이 두 가지 환경에서 모두 **stdout에 후보를 안 찍고 silent 종료**:

1. `send_telegram()` 이 curl + placeholder 토큰으로 `exit_code=3` (빈 응답) 실패
2. `load_topics()` 결과 12개 → `format_selection_message()` 호출 → 메시지 생성
3. **그런데 stdout에 `===== NOTEBOOKLM 후보 =====` 마커를 찍는 코드가 어디에도 없음**
4. cron LLM이 stdout 캡처에서 마커 + 후보 블록 모두 못 찾음
5. 폴백 규칙("마커 없으면 Notion에 활성후보 없음")이 작동 → 거짓 보고

**중요:** 스크립트는 정상이고 DB는 정상이지만, **두 layer 사이의 연결 고리(stdout 마커)가 빠져 있는 설계 결함**.

## 검증 절차 (3단계 oneliner)

```bash
# 1) cron output .md 확인
cat ~/.hermes/cron/output/dc9a2e6aaaaa/<YYYY-MM-DD>_<HH-MM-SS>.md | grep -A 5 "## Response"

# 2) 스크립트 수동 dry-run (Telegram 우회)
bash -c "source ~/.hermes/venv-notebooklm/bin/activate && python3 ~/.hermes/scripts/notebooklm_selection.py --dry-run" 2>&1 | head -30

# 3) Notion API 직접 probe — 활성 12건 확인
TOKEN=$(cat ~/.hermes/secrets/notion_token.txt | head -1)
DB="34276f2e-9097-811e-ab69-f8759ecf0be7"
curl -s -X POST "https://api.notion.com/v1/databases/$DB/query" \
  -H "Authorization: Bearer $TOKEN" -H "Notion-Version: 2022-06-28" -H "Content-Type: application/json" \
  -d '{"filter":{"property":"상태","select":{"equals":"활성"}},"page_size":100}' \
  | python3 -c "import sys,json; d=json.load(sys.stdin); print('active count:', len(d.get('results',[])))"
```

## 진단 우선순위

| 우선 | 검증 | 기대 결과 | 실패 시 의미 |
|------|------|----------|------------|
| 1 | Notion API 활성 카운트 | 12 | DB 자체 문제 (다른 DB ID 가리키는 중일 수 있음) |
| 2 | `notebooklm_selection.py --dry-run` | 12개 메시지 출력 | 스크립트 자체 문제 (auth, Notion token 등) |
| 3 | cron output .md | `===== NOTEBOOKLM 후보 =====` 마커 + 12개 | **이번 함정 — stdout fallback 누락** |

## 수정 방향 (3가지 옵션, 사용자 선택)

**A. 진단 (가볍게 원인만):**
직전 cron .md 와 비교해서 silent-skip 발생 여부만 확인. 다음 16:00 cron까지 두고 동일 패턴 재현 시 B/C로 진행.

**B. 액션 (즉시 + 안전) — 추천:**
스크립트에 **`if __name__ == "__main__"`: 항상 `print("===== NOTEBOOKLM 후보 =====\n" + msg + "\n===========================")` 추가** (Telegram 성공/실패/예외 무관). 즉, 텔레그램 호출 결과를 stdout으로 **동기 출력**하도록 만들어 LLM 폴백이 "Notion에 후보 없음"으로 빠지는 경로 자체를 차단.

**C. 액션 + 진단:**
A + B 동시. 패치 후 1회 dry-run 으로 stdout 정상 출력 검증.

## 사용자 선호 워크플로

MEMORY user.md 따라:
- "진단 vs 액션 구분 선호" (06-29) → 진단만 하고 액션 묻기
- "clarify 시 4옵션 + 추천 명시" → 4옵션 + 추천으로 묶어서 선택 받기
- 위 A/B/C + 추천 (저는 B) 사용

## 재사용 트리거

- 다른 cron → script → LLM 보고 체인에서 **"X 없습니다" 거짓 보고** 도착
- Notion DB / API / 스크립트 자체는 모두 정상으로 확인됐는데 cron LLM만 "없다"고 답할 때
- stdout 캡처가 비어 있는 게 root cause

## 연관 금기

- **#19** (Telegram silent fail) — Telegram 미설정 시 `--review` 메시지 silent fail. 이번 케이스는 stdout 마커 자체가 없는 별도 함정.
- **#31** (Telegram timeout) — `--review` 가 60초 timeout 으로 hang. 동일 placeholder 환경에서 발생하지만, 이번은 즉시 silent 종료로 더 위험 (사용자가 알기 어려움).
- **#39** (stale data) — selection.json 자체가 stale 한 다른 케이스. 진단 시 selection.json date + topics id 범위 동시 확인으로 구분.

## 실측 진단 타임라인 (2026-07-06)

- T+0:00 — cron 16:57:20 실행, "활성 후보 없음" 거짓 보고
- T+1:00 — 사용자가 Notion 화면 스크린샷 + "왜 없다고 하지?" 정정
- T+2:00 — cron output .md 확인 → stdout에 마커 없음 발견
- T+3:00 — `--dry-run` 수동 실행 → 12개 정상 로드 확인
- T+4:00 — Notion API 직접 query → 12건 정상 반환 확인
- T+5:00 — 스크립트 코드 검토 → stdout fallback 마커 코드 부재 확인
- T+6:00 — 사용자에게 A/B/C 옵션 + B 추천 제시
