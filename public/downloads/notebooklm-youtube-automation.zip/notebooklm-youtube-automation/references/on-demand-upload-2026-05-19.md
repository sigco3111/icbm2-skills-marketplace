# On-Demand Upload — 2026-05-19 (3개 동시 업로드)

## 시나리오
사용자가 "노트북 비디오 오버뷰 생성 완료. 업로드"라고 말함.
4단계 파이프라인([侯選 → prepare → 영상 생성])은 모두 완료된 상태.
기존 크론에 의해 생성된 3개 노트북의 영상을 동시에 YouTube에 업로드.

## 대상 노트북 3개

| nb_id (접두사) | 제목 | 영상 아티팩트 ID |
|---|---|---|
| `39bac968` | AI 구독은 엔터프라이즈의 시한폭탄 | `f2cc1bd9` |
| `98f442be` | AI는 기술이지, 제품이 아니다 | `c1ec20b3` |
| `3cf2bbc7` | AI와 함께 일하며 복리처럼 쌓아 성장하는 법 | `bd59f6ed` |

## 완료된 업로드

| 영상 | URL |
|---|---|
| AI 구독은 엔터프라이즈의 시한폭탄 - 일반 | https://www.youtube.com/watch?v=fPOpNowQP_o |
| AI 구독은 엔터프라이즈의 시한폭탄 - Shorts | https://www.youtube.com/watch?v=9jQQ8MYrbB0 |
| AI는 기술이지, 제품이 아니다 - 일반 | https://www.youtube.com/watch?v=XnjwrFveEJY |
| AI는 기술이지, 제품이 아니다 - Shorts | https://www.youtube.com/watch?v=fZTUDOwMihs |
| AI와 함께 일하며 복리처럼 쌓아 성장하는 법 - 일반 | https://www.youtube.com/watch?v=t-Ht8yoU2kI |
| AI와 함께 일하며 복리처럼 쌓아 성장하는 법 - Shorts | https://www.youtube.com/watch?v=rWVjPZiDIXI |

## 핵심 발견: python3 경로 문제

**문제:** `notebooklm_upload.py --approved` 실행 시 모든 업로드가 `No module named 'googleapiclient'`로 실패.

**원인:** 스크립트가 내부에서 `subprocess.run(['python3', ...])`로 `yt_upload.py`를 호출하는데, 시스템 python3(`/Library/Frameworks/Python.framework/Versions/3.8/bin/python3`)에는 `google-api-python-client`가 설치되어 있지 않음.

**해결:** `./venv-notebooklm/bin/python3`을 사용해서 스크립트 실행:
```bash
cd ~/.hermes && ./venv-notebooklm/bin/python3 scripts/notebooklm_upload.py --approved
```

**참고:** `--review`는 API 호출 없이 JSON 로드+작성만 하므로 정상 동작. `--approved`에서만 발생.

## 완전한 절차 (이 세션에서 검증됨)

### Step 0: 노트북 목록에서 대상 확인
```bash
notebooklm list  # → 05-18/05-19 날짜의 노트북 ID + 제목 확인
```

### Step 1: 영상 아티팩트 ID 확인 (노트북별)
```bash
notebooklm use <nb_id>
notebooklm artifact list  # → Video 아티팩트 ID + status 확인
```

### Step 2: 영상 다운로드 (positional 인자 — `-o` 없음)
```bash
mkdir -p /tmp/icbm_notebooklm/videos
notebooklm use <nb_id>
notebooklm download video --all /tmp/icbm_notebooklm/videos/ --force
# ⚠️ positional: -o 옵션 없음. 넘기면 "No such option: -o" 오류
```

### Step 3: selection.json 수동 생성
`memory/notebooklm_selection.json`의 `date`가 오늘(KST)이어야 `--review` 동작.
수동 생성 시 required structure:
```json
{
  "date": "2026-05-19",
  "topics": [
    { "number": 1, "name": "...", "category": "AI/ML",
      "url": "https://news.hada.io/topic?id=xxxxx",
      "file": "/tmp/icbm_notebooklm/videos/영상파일.mp4" }
  ],
  "selection_numbers": [1, 2, 3],
  "selected": [ /* topics와 동일 */ ]
}
```

### Step 4: 검토 → 업로드
```bash
cd ~/.hermes && ./venv-notebooklm/bin/python3 scripts/notebooklm_upload.py --review
# '확인' 입력
./venv-notebooklm/bin/python3 scripts/notebooklm_upload.py --approved
```

## FFmpeg Shorts 변환 결과

| 원본 | 변환 | 크기 |
|---|---|---|
| 539s → 59s | AI 구독은...Letterbox | 5.0MB |
| 609s → 59s | AI는 기술이지...Letterbox | 3.4MB |
| 531s → 59s | 복리처럼...Letterbox | 3.6MB |

전부 9:16(1080x1920) Letterbox 방식으로 변환 완료.