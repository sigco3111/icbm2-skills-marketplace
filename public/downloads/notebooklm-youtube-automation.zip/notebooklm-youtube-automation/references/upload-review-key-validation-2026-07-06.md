# upload_review.json 키 검증 워크플로 (2026-07-06)

> **트리거:** 사용자/부모 위임에서 "title 빈 문자열 보강해줘", "topic_url 추가해줘", "description에 X 추가" 같은 **필드 보강/추가 지시**.
> **핵심 위험:** 위임 지시가 가정한 키와 실제 `upload_review.json`의 키가 다를 수 있음 → 패치 실패 또는 의도 외 위치 패치.

## 실측 사례 (2026-07-06)

위임:
> "upload_review.json의 각 topic에 'title' 키 보강 (현재 topics 모두 title 빈 문자열). 추천: title[0]: 'AI 시대, Figma를 다시 생각하다 | GeekNews #31169' ..."

실제 파일 (`/Users/mac/.hermes/memory/upload_review.json`):
```json
{
  "topics": [
    {"index": 1, "topic_name": "AI 시대, Figma를 다시 생각하다",
     "video_title": "AI 시대, Figma를 다시 생각하다",   ← 이미 채워짐
     "shorts_title": "🔥 AI 시대, Figma를 다시 생각하다",   ← 이미 채워짐
     "description": "...",
     "tags": [...], "nb_id": "0a4415db-...",
     "topic_url": "https://news.hada.io/topic?id=31169"}
  ]
}
```

**차이점**:
- 위임이 가정한 `title` 키 → 실제 파일에 **부재**
- 실제 키: `video_title`, `shorts_title` 둘 다 **이미 값이 채워져 있음**
- 위임이 가정한 `topic_url` → 실제 키는 `topic_url` (일치) — 이건 OK
- 보강 자체가 **불필요**했다 (스크립트가 자동으로 잘 박아둠 + `make_sentence_title()` 폴백)

## 5단계 검증 워크플로

### 1단계: read_file + json.tool로 구조 노출
```bash
read_file /Users/mac/.hermes/memory/upload_review.json
```

### 2단계: 1줄 oneliner로 키 + 값 동시 검사
```bash
python3 -c "
import json
d = json.load(open('/Users/mac/.hermes/memory/upload_review.json'))
for t in d.get('topics', []):
    print(f'#{t.get(\"index\")} keys={sorted(t.keys())} video_title={t.get(\"video_title\")!r} shorts_title={t.get(\"shorts_title\")!r}')
"
```

### 3단계: 위임 키 vs 실제 키 매핑 결정
| 위임 지시 키 | 실제 upload_review.json 키 | 결론 |
|---|---|---|
| `title` | `video_title` + `shorts_title` | 두 키 모두 확인 — 이미 채워졌으면 skip |
| `topic` | `topic_name` | list 표시용 — 패치 불필요 |
| `desc` | `description` | OK |
| `nb_id` | `nb_id` | OK |
| `url` | `topic_url` | OK |

### 4단계: 패치 (필요 시) 또는 silent skip
- 둘 다 이미 채워져 있으면 → patch 안 하고 `--approved` 직행
- 빈 문자열 또는 누락이면 → 정확한 실제 키로 patch
- 다른 위치의 키를 패치하려 했으면 → `keys=` 출력으로 anchor 위치 재확인 후 patch

### 5단계: 검증
```bash
python3 -c "import json; json.load(open('/Users/mac/.hermes/memory/upload_review.json')); print('JSON valid')"
# + read_file 로 들여쓰기 확인
```

## 전체 키 매핑표 (upload_review.json)

| 용도 | 실제 키 | 위임에서 자주 잘못 부르는 이름 |
|---|---|---|
| YouTube 일반 영상 제목 | `video_title` | `title`, `main_title` |
| YouTube Shorts 제목 | `shorts_title` | `shorts`, `short_title` |
| 영상 설명 | `description` | `desc`, `body` |
| 토픽 이름 (표시용) | `topic_name` | `topic`, `name` |
| 주제 URL | `topic_url` | `url`, `link` |
| 노트북 ID | `nb_id` | - |
| 카테고리 | `category` | - |
| 태그 배열 | `tags` | - |
| 출처 배열 (NotebookLM 내부) | `sources` | - |
| 토픽 인덱스 | `index` | `number`, `idx` |

## 보강 자체가 불필요한 경우 (조기 종료)

다음 조건 모두 만족 시 patch 안 함 + `--approved` 직행:

1. `video_title`이 빈 문자열이 아니거나 `topic_name`에서 자동 생성 가능한 경우
2. `shorts_title`이 빈 문자열이 아니거나 `video_title`에서 자동 생성 가능한 경우
3. `description`에 URL이 정상 박혀 있음
4. `nb_id`가 비어있지 않음

→ 스크립트 내부 `make_sentence_title()` 폴백이 `topic_name` + 카테고리 기반 생성하므로 비어도 동작. **패치보다 직행이 시간 효율적**.

## 함정 회피 요약

- ❌ 위임 지시의 키 이름 그대로 `patch` 도구 → 매칭 실패 / 의도 외 패치
- ❌ jq / sed로 파일 직접 편집 → 들여쓰기 깨짐 + validation 실패
- ❌ `write_file`로 upload_review.json 전체 재작성 → topics topics topics 12개 + selected 동기화 깨질 위험
- ✅ `read_file` → `python3 -c "import json; ..."` 구조 확인 → 정확한 키로 patch 또는 skip
