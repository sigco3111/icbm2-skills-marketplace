# Notion DB 정밀 진단 절차 (2026-07-06 실측)

## 목적

"어제 발행한 주제" / "이거 다시 선정해" 같은 사용자 피드백 시, 단순 "12개 후보" 가 아닌 **Notion DB의 `등록일`/`마지막 사용일` 둘 다** 보고 **진짜 사용 가능한 후보**를 좁히는 절차. #39 (stale-data 함정) 의 후속/심화.

## Notion DB 의 함정 2종 (실측)

### 함정 A — Notion API date filter가 작동 안 함

`{"property": "마지막 사용일", "date": {"equals": "2026-07-05"}}` 같은 필터를 보내도 **모든 row가 page_size 만큼 반환됨**. Notion REST API의 date filter는 정확히 작동하지 않음 (2026-07-06 실측).

```bash
# 이 필터는 무시되는 듯 — 모든 row가 반환됨
"filter": {"property": "마지막 사용일", "date": {"equals": "2026-07-05"}}
"sorts": [{"property": "마지막 사용일", "direction": "descending"}]
"page_size": 100  # 100 row cap. 그 이상은 next_cursor 필요
```

→ **해결**: 필터를 무조건 보내되 **Python에서 클라이언트 필터링**을 한다.

### 함정 B — page_size 100 hard cap

Notion API query는 한 번에 최대 100 row만 반환. 더 필요한 경우 `next_cursor`로 다음 페이지 요청해야 함. 12~30개 후보 풀이라면 100으로 충분.

## 진단 절차 (4단계, 검증됨)

### 1단계: 빈 필터로 모든 row 가져오기

```bash
TOKEN=$(head -1 ~/.hermes/secrets/notion_token.txt)
DB_ID="34276f2e-9097-811e-ab69-f8759ecf0be7"   # 📝 블로그 발행 주제 DB

curl -sS -X POST "https://api.notion.com/v1/databases/$DB_ID/query" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Notion-Version: 2022-06-28" \
  -H "Content-Type: application/json" \
  -d '{"page_size": 100}' \
  > /tmp/notion_all.json
```

### 2단계: Python에서 등록일 / 마지막 사용일 둘 다 필터링

```python
import json
d = json.load(open('/tmp/notion_all.json'))
results = d.get('results', [])
print(f'rows: {len(results)} (예상 100, Notion API가 page_size로 cap)')

# 등록일 기준 7/5~7/6 윈도우 + USED (마지막 사용일 존재) 여부 함께 표시
USED_IDS = set()
AVAILABLE_IDS = set()  # 등록일 최근인데 마지막 사용일 비어있는 것
for r in results:
    p = r.get('properties', {})
    name = ''.join(t.get('plain_text','') for t in p.get('이름',{}).get('title',[]))
    url = p.get('URL',{}).get('url','')
    tid = int(url.split('=')[1]) if 'id=' in url else None
    reg_date = p.get('등록일',{}).get('date',{}).get('start') if p.get('등록일',{}).get('date') else None
    last = p.get('마지막 사용일',{}).get('date',{}).get('start') if p.get('마지막 사용일',{}).get('date') else None
    if tid is None: continue
    if reg_date in ['2026-07-05', '2026-07-06']:
        if last:
            USED_IDS.add(tid)
            print(f'  등록 {reg_date} USED {last}  [{name[:50]}]  id={tid}')
        else:
            AVAILABLE_IDS.add(tid)
            print(f'  등록 {reg_date} 가능           [{name[:50]}]  id={tid}')

print(f'\nUSED ({len(USED_IDS)}): {sorted(USED_IDS)}')
print(f'AVAILABLE ({len(AVAILABLE_IDS)}): {sorted(AVAILABLE_IDS)}')
```

### 3단계: selection.json의 12개 후보와 교차

```python
import json
sel = json.load(open('/Users/mac/.hermes/memory/notebooklm_selection.json'))
selection_numbers = sel.get('selection_numbers', [])

# 선택된 4개가 AVOID 리스트에 들어있는지 검사
for n in selection_numbers:
    t = sel['topics'][n-1]
    tid = int(t['url'].split('=')[1])
    if tid in USED_IDS:
        print(f'⚠️ #{n} ({t["name"][:40]}) → 이미 USED — 재발행 위험, 제외 권장')
    else:
        print(f'✅ #{n} ({t["name"][:40]}) → 안전')
```

### 4단계: 사용자 옵션 제시 (4옵션 + 추천)

`selection.json`의 `selection_numbers`에 USED ID가 섞여 있으면:

1. **A. 텍스트로 새 8개 정리** — 사용 가능 후보만 골라서 다시 보여주기
2. **B. `selection_numbers`/`selected` 초기화** — 사용자 재선정 대기
3. **C. Notion DB 직접 새 글 추가** — 어제/오늘 등록 안 된 신선한 후보
4. **D. 이전 선택 강제 진행** — USED 무시 (재발행 위험 감수)

**추천은 A**: 금기 #39 (stale-data)와 일관, 사용 가능 후보만 정리해서 보여주는 게 가장 안전. B는 사용자 부담 적지만 결정 못하면 막힘.

## 실측 결과 (2026-07-06)

```
어제(7/5) USED: {31117, 31124, 31129, 31134}        # 4개 — Leanstral/배우는게/MemNixFS/축구감독
오늘(7/6) USED: {31127, 31135, 31136, 31138, 31143, # 9개 — Fable 비용/유출/htop/C&C/워크스페이스/
                 31144, 31145, 31147, 31148}        # Codex/Epoll/공장은 그저 방/더 나은 모델

selection.json 사용 가능 후보 (USED ∩ registration 7/5~7/6 아님):
  #6 ✅  최신 수준 LLM 로컬 실행 가이드 (id=31121)
  #7 ✅  Show GN: Cluedoc (id=31133)
  #8 ✅  Wordgard (id=31125)
  #9 ✅  웹 개발자 Safari MCP 서버 (id=31131)
```

→ **12개 중 단 4개만 사용 가능**. 이전 사용자 선택 [6, 7, 9, 12] 중 #12 (Command & Conquer = 31138)는 오늘 USED → **재발행 위험**.

## 빠른 진단 oneliner (사용 가능 후보 즉시 출력)

```python
import json
sel = json.load(open('/Users/mac/.hermes/memory/notebooklm_selection.json'))

# Notion 조회 결과를 piped JSON 파일로 받았다고 가정
ndata = json.load(open('/tmp/notion_all.json'))
USED_IDS = set()
for r in ndata.get('results', []):
    p = r.get('properties', {})
    last = p.get('마지막 사용일',{}).get('date',{}).get('start') if p.get('마지막 사용일',{}).get('date') else None
    reg = p.get('등록일',{}).get('date',{}).get('start') if p.get('등록일',{}).get('date') else None
    url = p.get('URL',{}).get('url','')
    tid = int(url.split('=')[1]) if 'id=' in url else None
    if tid and reg in ['2026-07-05','2026-07-06'] and last:
        USED_IDS.add(tid)

# selection.json의 12개에 AVAILABLE/USED 마크
print('=== 사용 가능 후보 ===')
for i, t in enumerate(sel['topics'], 1):
    tid = int(t['url'].split('=')[1]) if 'id=' in t.get('url','') else 0
    marker = '⚠️ USED' if tid in USED_IDS else '✅ 가능'
    print(f'  #{i:2d} {marker:8s}  [{t.get("category","?"):8s}]  {t["name"][:50]}')
```

## 비교: 이 reference vs #39 (stale-data)

| 관점 | #39 (stale-data) | 본 reference |
|---|---|---|
| **트리거** | selection.json ≠ Notion 활성 풀 | selection.json 후보가 이미 USED |
| **사용자 인상** | "후보가 어제꺼 같다" | "어제 발행한 주제. 다시 선정해" |
| **Notion 상태** | DB 풀은 정상이지만 selection.json이 옛것 | selection.json은 정상이지만 후보 중 USED가 있음 |
| **근본 해결** | `notebooklm_selection.py` line 198 가드 강화 | 후보 선정 시 Notion USED 조회 필수화 |

## 사용자 워크플로 (2026-06-29 확립 선호 통합)

"다시 선정해" / "어제 발행한 것 빼고" 같은 모호한 요청 시:

1. **Notion DB 클라이언트 필터링 진단** (2분)
2. **USED vs AVAILABLE 시각화 표시** (채팅)
3. **4옵션 + 추천** (사용자 선호 — 본인의 4옵션 선호 memory와 일치)
4. **선택 즉시 진행** + 결과 + 다음 단계

## 안전 가드

- `selection.json`의 `selection_numbers`만 비우고 topics는 보존 (금기 #6 + #15 동일 패턴)
- `rm selection.json` 절대 금지 — 진행 중 on-demand 상태 파괴 위험
- USED 후보를 강제 진행(D 옵션)할 땐 **사용자 명시 확인 필수** (재발행은 자동화 정지에 가까움)
