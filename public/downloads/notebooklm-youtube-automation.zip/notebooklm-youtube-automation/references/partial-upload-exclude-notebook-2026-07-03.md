# Partial Upload — 단일 노트북 제외 패턴 (2026-07-03)

> **요청 시나리오:** "CursorBench 3.1 (#4) 제외, 나머지 3개만 업로드"
> **차이점 (금기 #28 vs 신규 패턴):** #28은 failed 비디오를 자동 제외하는 reactive 케이스. 이번 신규는 **사용자가 의도적으로 정상 노트북을 제외**하는 proactive 케이스.

## 워크플로 (5단계, 2026-07-03 실측 검증)

### 1) 제외 대상 확인
```bash
# 현재 활성 4개 노트북 조회 (selection.json + NotebookLM 양쪽 cross-check)
/Users/mac/.hermes/venv-notebooklm/bin/python3 -m notebooklm list --json
# → ICBM | CursorBench 3.1 모델 평가 결과의 nb_id 기록 (e.g. 07ad9132-7957-4459-aa1d-422f8d4beabc)
```

### 2) 영상 다운로드 (각 노트북별 use + download 반복 — 금기 #18)
```python
NOTEBOOKS = {
    2: "41c7b950-fd02-467f-bed6-b72944bab99a",   # AI가 일자리보다 먼저 가져가는 것
    6: "db67f99d-3028-431e-b6ff-8de33340aa23",   # ZCode: GLM-5.2용 공식 하네스
    9: "6222d7cb-0140-4cff-871e-2b9117e14873",   # Kimi K2.7 Code
    # 4는 의도적으로 제외
}
# CursorBench 3.1 (07ad9132-...)는 use/download 반복 대상 아님
```

### 3) selection.json 일괄 패치 (4단계 동시 — gold #32 패턴)
```python
d['topics'][i] 에 number + nb_id + file 3필드 채움 (12개 전체)
d['selected'] = [d['topics'][1], d['topics'][5], d['topics'][8]]  # REPLACE (금기 #15)
d['selection_numbers'] = [2, 6, 9]  # exclude 4
```

### 4) 5종 사전 체크 (gold #29)
1. venv 인터프리터 정상
2. selection.json date 오늘 + selected 의도대로
3. 영상 파일 존재 + 크기 (3/3, CursorBench.mp4 부재 확인)
4. artifact status 3/3 completed
5. **YouTube 토큰 valid=True** ← 이 세션에서 `valid=False` 발견, refresh 5초 복구 (gold #40)

### 5) --review → --approved
`upload_review.json` 직접 read (Telegram placeholder 환경) → 사용자 확인 → 업로드.

## 핵심 차이 — 금기 #28 (failed) vs 신규 (사용자 의도 exclude)

| 항목 | 금기 #28 (failed) | 신규 (사용자 의도 exclude) |
|---|---|---|
| 제외 이유 | NotebookLM 자동 failed | 사용자 명시적 요청 |
| 노트북 상태 | `status: failed` | `status: completed` (정상) |
| `topics` 배열 처리 | failed 항목 topics에서도 제거 | **유지** (다음 사이클에서 재사용 가능성) |
| `selected` 처리 | REPLACE (failed 제외) | REPLACE (사용자 선택만) |
| cleanup 영향 | cleanup이 failed 노트북도 자동 정리 | cleanup은 **성공분만** 정리 (정상 노트북은 보존) |

## 실측 결과 (2026-07-03)

- 4개 노트북 생성 → 4개 모두 completed
- 사용자 요청: "#4 CursorBench 3.1 제외, 3개만 업로드"
- 다운로드 3개: 86MB / 43MB / 47MB
- `--review` → 토큰 refresh → `--approved`
- **6개 영상 업로드 성공** (일반 3 + Shorts 3)
- 제외된 CursorBench 노트북은 보존 (cleanup 대상 아님)
- 총 소요 시간: ~80초

## 검증 oneliner (5종 통합)

```python
import json, os, hashlib, re
PATH = "/Users/mac/.hermes/memory/notebooklm_selection.json"
with open(PATH) as f:
    d = json.load(f)

# 1) selected 모든 항목 nb_id + file + number + url 확인
for t in d['selected']:
    assert t.get('number'), f"{t['name'][:20]} number missing"
    assert t.get('nb_id'), f"{t['name'][:20]} nb_id missing"
    assert t.get('file'), f"{t['name'][:20]} file missing"
    assert 'https://' in t.get('url', ''), f"{t['name'][:20]} url missing"

# 2) topics는 12개 그대로 보존 (제외된 노트북도 topics에 유지)
assert len(d['topics']) == 12, f"topics count {len(d['topics'])} != 12"

# 3) selection_numbers = selected 항목 번호와 일치
selected_numbers = sorted([t['number'] for t in d['selected']])
assert sorted(d['selection_numbers']) == selected_numbers, "selection_numbers mismatch"

# 4) 제외된 노트북 (e.g. #4)는 selected에는 없고 topics에는 있음
excluded_number = 4  # 사용자 명시
all_topic_numbers = sorted([t.get('number', i+1) for i, t in enumerate(d['topics'])])
assert excluded_number in all_topic_numbers, f"excluded #{excluded_number} not in topics"

print(f"✅ Partial upload exclude validated: {len(d['selected'])} selected, #{excluded_number} excluded (preserved in topics)")
```

## 함정 회피 체크리스트

- [ ] topics 배열은 **REPLACE 금지** (12개 그대로 유지, 제외 노트북도 유지)
- [ ] selected 배열은 **REPLACE** (사용자 선택만)
- [ ] `topics[i]` 에 `number`/`nb_id`/`file` 3필드 모두 채우기
- [ ] download 직전 `notebooklm use` 매번 호출 (금기 #18)
- [ ] download 직후 `ls /tmp/icbm_notebooklm/videos/` 로 파일 수 == selected 개수 검증
- [ ] `--review` 직후 `upload_review.json` read로 사용자 검토 (Telegram placeholder 안전망)
- [ ] `--approved` 직전 YouTube 토큰 valid=True 확인 (gold #40 refresh 패턴)

## 메시지 템플릿 (사용자 보고)

```
✅ #N1. {주제명} — nb_id={id[:13]}... → file={size}MB
✅ #N2. {주제명} — nb_id={id[:13]}... → file={size}MB
✅ #N3. {주제명} — nb_id={id[:13]}... → file={size}MB
❌ #{excluded}. {제외된 주제} — EXCLUDED by user request (preserved in selection.json topics, NOT deleted from NotebookLM)
```

## 핵심 차이점 vs 일반 업로드

| 단계 | 일반 (4-stage) | 신규 (partial exclude) |
|---|---|---|
| 1단계 (후보) | 16:00 크론 자동 | 16:00 크론 자동 (변화 없음) |
| 2단계 (생성) | prepare.py --skip-telegram | prepare.py --skip-telegram (변화 없음) |
| 3단계 (검토) | --review | **--review (제외 반영된 selected)** |
| 4단계 (업로드) | --approved | **--approved (제외 반영된 selected)** |
| **차이** | 없음 | **사전: selection.json selected 3개로 REPLACE** |