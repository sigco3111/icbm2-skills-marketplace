# FFmpeg 8.x Shorts 변환 실패 + 재시도 워크플로 (2026-06-26)

## 증상

`notebooklm_upload.py --approved` 실행 시 일반 영상 3개는 성공하는데 Shorts 3개만 다음 에러로 실패:

```
[fc#0 @ 0x71ac24000] Cannot find an unused video input stream to feed the unlabeled input pad scale:default.
Error binding filtergraph inputs/outputs: Invalid argument
```

## 원인 분석

3가지 트리거가 동시 작용:

1. **`-filter_complex`** 사용 — FFmpeg 8.x에서 compound filter는 첫 번째 입력을 자동 연결하지 않음. 명시적 input labeling(`[0:v]scale=...[v]`) 필요.
2. **`-map "0:v?"` / `-map "0:a?"`** — `-filter_complex`와 함께 쓰면 filtergraph와의 명시적 매핑이 필요해지는데 위에서 labeling이 없어서 broken.
3. **`-pix_fmt yuv420p`** — FFmpeg 8.x 호환성 문제 (금기 #30의 boxblur 함정과 같은 계열).

## 해결 (make_shorts 함수 패치)

`notebooklm_upload.py`의 `make_shorts()` 함수를 다음처럼 단순화:

**Before (실패):**
```python
r = subprocess.run([
    "ffmpeg", "-y", "-i", video_path,
    "-t", str(trim),
    "-filter_complex", filter_simple,  # ❌
    "-map", "0:v?",                     # ❌
    "-map", "0:a?",                     # ❌
    "-c:v", "libx264", "-preset", "ultrafast", "-crf", "23",
    "-c:a", "aac", "-b:a", "128k",
    "-af", f"atrim=0:{trim},afade=t=out:st={fade_start}:d=3",  # ❌ atrim 중복
    "-pix_fmt", "yuv420p", "-movflags", "+faststart",          # ❌
    "-shortest", output_path
], capture_output=True, text=True, timeout=120)
```

**After (성공):**
```python
r = subprocess.run([
    "ffmpeg", "-y", "-i", video_path,
    "-t", str(trim),
    "-vf", filter_simple,  # ✅ -filter_complex → -vf
    "-c:v", "libx264", "-preset", "ultrafast", "-crf", "23",
    "-c:a", "aac", "-b:a", "128k",
    "-af", f"afade=t=out:st={fade_start}:d=3",  # ✅ atrim 제거
    "-movflags", "+faststart",
    "-shortest", output_path
], capture_output=True, text=True, timeout=120)
```

**핵심 변경**:
- `-filter_complex` → `-vf` (단순 필터는 자동 입력 연결)
- `-map "0:v?"` / `-map "0:a?"` 제거 (불필요)
- `-pix_fmt yuv420p` 제거 (FFmpeg 8.x 호환)
- `-af`의 `atrim=0:N,` 제거 (이미 `-t N`이 처리)

## 재시도 패턴 (cleanup 후)

`--approved`가 cleanup 단계로 노트북을 삭제한 경우 (`/tmp/icbm_notebooklm/shorts_*.mp4` 0바이트):

1. **원본 영상이 cleanup 후에도 보존됨**: `ls /tmp/icbm_notebooklm/videos/` (cleanup은 노트북만 삭제, 영상 파일은 그대로)

2. **수정된 패턴으로 Shorts 3개 직접 변환**:
   ```bash
   for topic_num in 1 2 3; do
     case $topic_num in
       1) SRC="/tmp/icbm_notebooklm/videos/앤스로픽 대 알리바바 논란.mp4" ;;
       2) SRC="/tmp/icbm_notebooklm/videos/Krea 2 기술 보고서 해부.mp4" ;;
       3) SRC="/tmp/icbm_notebooklm/videos/auth.md_ 에이전트를 위한 프로토콜.mp4" ;;
     esac
     OUT="/tmp/shorts_retry/shorts_${topic_num}.mp4"
     ffmpeg -y -i "$SRC" -t 59 \
       -vf "scale=1080:-1,pad=0:1920:(ow-iw)/2:(oh-ih)/2:black,setsar=1,setdar=9/16" \
       -c:v libx264 -preset ultrafast -crf 23 \
       -c:a aac -b:a 128k \
       -af "afade=t=out:st=56:d=3" \
       -movflags +faststart \
       -shortest "$OUT"
   done
   ```

3. **`yt_upload.py --shorts`로 단독 업로드** (positional `file_path` + 플래그):
   ```bash
   ~/.hermes/venv-notebooklm/bin/python3 /Users/mac/.hermes/scripts/yt_upload.py \
     /tmp/shorts_retry/shorts_1.mp4 \
     --title 'Anthropic, "Alibaba가 Claude AI 모델 역량을 불법 추출했다"' \
     --description "..." \
     --tags "ICBM,AI,테크,개발자,인공지능,Shorts" \
     --shorts \
     --privacy public
   ```

4. **description 재구성**: cleanup이 `upload_review.json`을 망가뜨렸을 수 있으니 GeekNews URL + 해시태그 + ▼ 더보기 마커 모두 명시:
   ```
   '{토픽명}' 관련 최신 소식 영상입니다.

   ▼ 더보기
   📚 출처
   • {토픽명}
     https://news.hada.io/topic?id={id}

   #ICBM #AI #테크 #개발자 #인공지능
   ```

## 검증 oneliner

```python
import sys
sys.path.insert(0, '/Users/mac/.hermes/scripts')
import notebooklm_upload
import tempfile, subprocess, json, os
src = '/tmp/icbm_notebooklm/videos/<원본파일>.mp4'
out = tempfile.mktemp(suffix='.mp4')
ok = notebooklm_upload.make_shorts(src, out)
assert ok and os.path.exists(out)
r = subprocess.run(['ffprobe', '-v', 'error', '-show_entries',
                    'stream=width,height:format=duration', '-of', 'json', out],
                   capture_output=True, text=True, timeout=15)
info = json.loads(r.stdout)
w = info['streams'][0]['width']
h = info['streams'][0]['height']
dur = float(info['format']['duration'])
assert w == 1080 and h == 1920 and dur <= 59.5, f"FAIL {w}x{h} {dur}s"
print(f"✅ Shorts 변환 OK: {w}x{h} {dur}s")
os.unlink(out)
```

## 결과 (이번 세션 실측)

| 영상 | 원본 크기 | Shorts 크기 | 상태 |
|---|---|---|---|
| 앤스로픽 대 알리바바 논란 | 70MB | 4.3MB | ✅ |
| Krea 2 기술 보고서 해부 | 55MB | 4.2MB | ✅ |
| auth.md: 에이전트를 위한 프로토콜 | 52MB | 3.2MB | ✅ |

3/3 Shorts 변환 성공, `yt_upload.py --shorts`로 업로드 → **6/6 영상 (일반 3 + Shorts 3) 모두 YouTube 업로드 완료**.

## 재발 방지

다음 자동화 사이클에는 패치된 `make_shorts()`가 적용되어 한 번에 Shorts까지 처리됨. 만약 재발 시:
1. `python3 -c "import notebooklm_upload; notebooklm_upload.make_shorts(...)"`로 즉시 단위 테스트
2. 실패하면 동일 패턴으로 ffmpeg CLI 직접 실행 → `yt_upload.py --shorts` 단독 업로드
3. SKILL.md 본체에 #33번 pitfall 참조
