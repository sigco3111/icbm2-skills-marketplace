# NotebookLM이 자체 생성하는 비디오 제목 — 패턴 분석

> 작성: 2026-06-17 (3개 토픽 모두에서 발생, 실측 기반)
> 관련 금기: #18 (`download video --all` 1개만 받음), #19 (Telegram silent fail)

## 현상

NotebookLM이 **Video Overview를 생성할 때 토픽 제목과 다른 자체 제목을 부여**하는 경우가 매우 빈번함. 다운로드된 파일명도 이 자체 제목으로 저장되어, 토픽 → 파일명 매핑이 1:1이 아님.

## 2026-06-17 실측 케이스 (3/3 모두 발생)

| # | 토픽 제목 (selection.json) | 비디오 파일명 (실제 다운로드) | 패턴 |
|---|---------------------------|------------------------------|------|
| 1 | Claude Code의 수석 디자이너가 AI로 빌드하는 방법 [유튜브] | 실전 AI 워크플로우_ 클로드 활용법.mp4 | 추상화 + 관점 전환 |
| 2 | OpenRouter Fusion API | OpenRouter Fusion API.mp4 | **동일** (이번만 우연히 일치) |
| 3 | 연구자들 "Fable 5 논란은 탈옥이 아니라 'fix this code'에서 시작됐다" | Fable 5 제한과 세 단어의 파장.mp4 | 다이어지 + 핵심 키워드 압축 |

→ **3개 중 2개 (66%)가 토픽명과 다른 제목 생성**. 빈도가 매우 높아 기본값으로 가정해야 함.

## 영향

1. **사용자 혼동**: "NotebookLM에서 다른 제목으로 만들어졌는데 내 주제랑 매칭이 안 되는 것 같다?" 반응 유발
2. **YouTube 제목 매핑은 자동**: `notebooklm_upload.py`의 `video_title`은 `topic_name` 기준으로 매핑하므로 **실제 YouTube 업로드 제목은 토픽명** (정상)
3. **파일명 매핑**: `selection.json` 패치 시 `file` 필드에 **실제 다운로드된 파일명**을 정확히 입력해야 함

## 대응 패턴

### 패턴 A: 토픽명 ≠ 파일명일 때 (흔함)

```bash
ls -la /tmp/icbm_notebooklm/videos/  # ← 실제 파일명 확인
# → "실전 AI 워크플로우_ 클로드 활용법.mp4" 확인됨
# → selection.json의 topics[0].file = "실전 AI 워크플로우_ 클로드 활용법.mp4"
```

### 패턴 B: 토픽명 = 파일명일 때 (드묾)

이번 06-17 세션 #2 OpenRouter처럼 우연히 일치하는 경우도 있음. **가정하지 말고 항상 `ls`로 확인**.

## `--review` 출력에서 매핑 확인

검토 메시지에는 다음 두 항목이 모두 표시됨:
- `video_title`: `selection.json.topic_name` (YouTube 업로드 제목)
- `shorts_title`: 동일

→ **다운로드된 .mp4 파일명이 아닌 토픽명이 YouTube 제목으로 간다는 점**을 사용자에게 명시적으로 안내하면 혼동 방지됨.

## YouTube에는 영향 없음

**중요**: 토픽명과 다른 파일명이어도 YouTube 설명/제목은 정상:
- `video_title` ← `topic_name` (토픽 제목)
- `shorts_title` ← `topic_name` (숏츠 제목)
- `description` ← `topic_name` (description 첫 줄)

→ 파일명 불일치는 **로컬 파일시스템**에만 존재. YouTube에는 영향 0.

## 다음 세션 체크리스트

1. `ls /tmp/icbm_notebooklm/videos/` 직후 "다운로드된 파일명 ≠ 토픽 제목일 수 있음" 안내
2. `--review` 검토 메시지에 "YouTube 제목 = 토픽명, 파일명 = NotebookLM 자체 제목" 명시
3. 사용자가 "파일명이 내 토픽과 다른데?" 물으면 → 정상 동작이라고 안내 (위 YouTube 영향 없음 섹션 참조)