---
name: notebooklm-youtube-automation
description: NotebookLM에서 생성한 비디오 오버뷰를 YouTube에 업로드하는 워크플로우 — 사용자가 직접 선택 후 수동 요청
trigger: "notebooklm, youtube upload, video overview, automation"
---

# NotebookLM YouTube 자동화 워크플로우

## 개요

Notion DB侯選 주제 → 사용자 선택 → NotebookLM 노트북 생성 → 비디오 오버뷰 생성 → 업로드 요청 → 일반 영상 + 숏츠 동시 업로드

**N:N 정책:** 비디오 오버뷰 N개 → 일반 영상 N개 + 숏츠 N개 (총 2N개 업로드)

---

## 워크플로우 3단계

### 1단계:侯選 전송 (매일 16:00 크론)
**스크립트:** `notebooklm_selection.py`

Notion DB에서 최신侯選 주제를 로드하여 텔레그램으로 전송.
최대 12개 주제를 카테고리 순서로 정렬하여 번호 선택지로 제공.

**출력 예시:**
```
🎬 NotebookLM 비디오 주제 선택

오늘의候選 주제 (8개) — 번호를 입력해주세요:
1. 🤖 Garry Tan's "Skillify" — AI 에이전트의 실패...
2. 💡 GoScrapy - Go기반 초고속 웹 스크래핑...
3. 🛠️ Show GN: purplemux – Claude Code 세션...
...
💡 Tip: 쉼표로 여러 개 선택 가능 (예: 1,3,5,7)
```

**저장:** `~/.hermes/memory/notebooklm_selection.json`

---

### 2단계: 노트북 생성 (사용자 번호 선택 후)
**스크립트:** `notebooklm_prepare.py`

사용자가 선택한 번호(예: `1,3,5`)를 읽고:
1. 각 주제에 맞는 소스를 동적으로 수집 (GitHub API, HackerNews, ProductHunt)
2. NotebookLM 노트북 생성
3. 노트북에 소스 추가

```bash
# 사용자가 Telegram에서 "1,3,5" 입력 시
# 에이전트가 실행:
python3 ~/.hermes/scripts/notebooklm_prepare.py
```

**소스 수집 규칙:**
| 카테고리 | 소스 |
|---------|------|
| AI/ML | GitHub API (키워드 검색) + HackerNews |
| 개발도구 | GitHub API + ProductHunt |
| 개발팁 | HackerNews + Reddit |

---

### 3단계: 업로드 (사용자가 "업로드"라고 요청)
**스크립트:** `notebooklm_upload.py`

주인님이 NotebookLM에서 비디오 오버뷰를 모두 생성한 후 "업로드"라고 알려주시면:

1. 각 노트북에서 비디오 오버뷰 다운로드
2. 주제 키워드로 출처 재수집 → 설명에 출처 URL 포함
3. 일반 영상 + 숏츠 동시 업로드 (N:N)
4. 노트북 자동 정리

```bash
python3 ~/.hermes/scripts/notebooklm_upload.py
```

**출처 설명 템플릿:**
```
'[주제명]' 관련最新 소식을 다루는 영상입니다.

▼ 더보기
📚 출처
• Repo name
  https://github.com/...
• Article title
  https://...

#ICBM #AI #테크 #개발자 #인공지능
```

---

## NotebookLM SDK 아티팩트 제목 조회 (2026-04-30)

NotebookLM이 생성한 비디오 오버뷰의 **원본 제목**을 SDK로 조회하여 YouTube 업로드 타이틀에 사용.

**핵심 패턴 — Python venv 서브프로세스 실행:**
```python
# 시스템 Python에는 notebooklm SDK가 없음
# → venv Python으로 인라인 코드 실행
venv_python = os.path.join(VENV_BIN, "python3")  # ~/.hermes/venv-notebooklm/bin/python3
code = f"""
import asyncio
from notebooklm import NotebookLMClient, StudioContentType

async def _get():
    async with NotebookLMClient.from_storage() as client:
        artifacts = await client.artifacts.list('{notebook_id}', artifact_type=StudioContentType.VIDEO)
        for art in artifacts:
            if art.id == '{artifact_id}':
                print(art.title)
                return
        # Fallback: any completed video
        for art in artifacts:
            if art.status == 3:
                print(art.title)
                return
        print('')
asyncio.run(_get())
"""
result = subprocess.run([venv_python, "-c", code], capture_output=True, text=True, timeout=30)
title = result.stdout.strip()
```

**주요 SDK 클래스/메서드:**
- `NotebookLMClient.from_storage()` — 저장된 OAuth 토큰으로 인증
- `client.artifacts.list(notebook_id, artifact_type=StudioContentType.VIDEO)` — VIDEO 타입 아티팩트 목록
- `art.id`, `art.title`, `art.status` — 아티팩트 메타데이터 (status=3 완료)
- `StudioContentType.VIDEO.value` = 3

**YouTube 업로드 타이틀 우선순위:**
1. NotebookLM 원본 제목 (`art.title`) — 최우선
2. 폴백 타이틀 (하드코딩된 기존 타이틀)

→ 업로드 스크립트에서 항상 `upload_title = nb_title if nb_title else fallback_title` 패턴 사용

**⚠️ Python `hash()` 절대 사용 금지:**
Python의 `str(hash())`는 해시 랜덤화(보안)로 매 프로세스마다 다른 값을 반환.  
크로스 프로세스 중복 체크에는 반드시 `hashlib.md5(text.encode()).hexdigest()` 사용.

## 핵심 개선사항 (2026-04-29)

### ✅ 출처 상세记载
이전: description에 출처 없음
개선: `collect_sources_for_description()`가 GitHub/HN/ProductHunt에서 실제 URL+제목 수집 → description에 포함

### ✅ N:N 숏츠 정책
이전: 4개 일반 + 1개 숏츠
개선: N개 영상 → N개 일반 + N개 숏츠 (총 2N개)

### ✅ 동적 소스 수집
이전: 하드코딩된 URL만
개선: 주제 키워드 기반 동적 검색 → 관련성 높은 소스 우선

### ✅ 사용자 선택 방식
이전: 4개 고정 주제 자동 생성
개선: Notion DB侯選 중 번호로 직접 선택 → 주제 중복 방지

---

## 파일 구조

```
~/.hermes/
├── scripts/
│   ├── notebooklm_selection.py   #侯選 전송 (16:00)
│   ├── notebooklm_prepare.py     #노트북+소스 생성 (선택 후)
│   └── notebooklm_upload.py      #다운로드+업로드 (업로드 요청 시)
├── memory/
│   └── notebooklm_selection.json #오늘의 선택 데이터
└── secrets/
    └── notion_token.txt         #Notion API 토큰
```

## 크론 잡

| 시간 | 작업 | 상태 |
|------|------|------|
| 16:00 매일 |侯選 전송 + 선택 요청 | ✅ 유지 |
| 사용자 선택 후 | 노트북+소스 생성 | ✅ 수동 |
| "업로드" 요청 시 | YouTube 업로드 | ✅ 수동 |

**자동 크론 제거:**
- ~~00:15 YouTube 업로드~~ → 제거됨
- ~~02:15 숏츠 업로드~~ → 제거됨

## 🎬 기존 노트북 → YouTube 업로드 (On-Demand)

> **단일 영상**만 있는 경우 위 단일 영상 가이드를 사용.

**다중 영상 일괄 업로드 (배치):**
1. `notebooklm artifact list -n <notebook_id> --type video` → 완료된 비디오 artifact 확인
2. `notebooklm download video -n <notebook_id> <path>` → 각 노트북별 다운로드
3. `ffprobe`로 길이 체크 → 60초 이하 = Shorts, 이상 = 일반영상
4. 일반영상: `upload.py`로 동시 백그라운드 업로드 (privacy: unlisted)
5. Shorts: `ffmpeg 9:16 변환` 후 동일하게 업로드

**핵심 인사이트 (2026-04-30):**
- `notebook_ids.json` (`/tmp/icbm_notebooklm/notebook_ids.json`)에 오늘 생성된 노트북 ID+제목+URL 저장됨 → 배치 다운로드 시 이 파일 재활용
- 6개 동시에 백그라운드 업로드 시 PID 추적 → 30초 후 로그로 성공/실패 확인
- `ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 <file>`로 길이 체크

### FFmpeg 9:16 숏츠 letterbox 블러 필터 (2026-04-30 수정)

**⚠️ 이전 버전 버그:** `[bg]scale=...:increase,crop=1080:1920` — crop이 letterbox 영역(위아래 656px)을 자르므로 블러가 적용 안 됨

**올바른 필터 체인:**
```bash
ffmpeg -y -i input.mp4 -t 60 \
  -filter_complex "
[0:v]split=2[fg][bg];
[fg]scale=1080:-1[fg2];
[bg]scale=1080:1920,boxblur=20[bg2];
[0:a]atrim=0:60,afade=t=out:st=55:d=5[aout];
[bg2][fg2]overlay=(W-w)/2:(H-h)/2[vout]
" \
  -map "[vout]" -map "[aout]" \
  -c:v libx264 -preset ultrafast -crf 26 \
  -c:a aac -b:a 128k \
  -pix_fmt yuv420p -shortest \
  output.mp4
```

**원리:**
- `[fg]scale=1080:-1` → 16:9(1280x720)를 너비 1080으로 스케일 → 1080x607 (위아래 letterbox 656px)
- `[bg]scale=1080:1920,boxblur=20` → crop 없음 → 전체 9:16 프레임을 블러 (letterbox 영역이 블러 배경)
- `[bg2][fg2]overlay=(W-w)/2:(H-h)/2` → fg를 중앙 배치, 위아래는 블러 배경
- 최종: foreground(60%) + letterbox 블러(위아래 각 20%)

**cf. crop 방식 (letterbox 없이 채우기):** `scale=-1:1920,crop=1080:1920` — 16:9 영상을 확대해서 9:16에 가득 채움, 위아래 잘림

### pipeline_shorts shorts_type 버그 fix (2026-04-30)

`notebooklm_youtube_pipeline.py`의 `pipeline_shorts` 함수에서:
```python
# ❌ 버그
description = build_youtube_description(shorts_type, data, ...)
# ✅ 수정
description = build_youtube_description(content_type, data, ...)
```
`content_type`이 함수 인자이고 `shorts_type`은 정의되지 않은 변수.

### Batch On-Demand 완전한 워크플로우 (2026-04-30)

```python
# 1. notebook_ids.json에서 오늘 생성된 노트북 ID 로드
import json
with open("/tmp/icbm_notebooklm/notebook_ids.json") as f:
    data = json.load(f)
notebooks = data["notebooks"]  # [{"id", "title", "topic": {"name","url"}}]

# 2. 모든 노트북에서 비디오 다운로드 (병렬)
import subprocess, os
os.makedirs("/tmp/icbm_notebooklm", exist_ok=True)
for nb in notebooks:
    nb_id = nb["id"]
    out = f"/tmp/icbm_notebooklm/raw_{nb_id[:8]}.mp4"
    subprocess.Popen([
        "bash", "-c",
        f"source ~/.hermes/venv-notebooklm/bin/activate && "
        f"notebooklm download video -n {nb_id} {out} --force"
    ])

# 3. 6개 동시에 백그라운드 업로드
upload_script = "~/.hermes/skills/creative/youtube-uploader/scripts/upload.py"
for nb in notebooks:
    vid = nb["id"][:8]
    subprocess.Popen([
        "python3", upload_script,
        f"/tmp/icbm_notebooklm/raw_{vid}.mp4",
        "--title", f"ICBM | {nb['topic']['name']}",
        "--description", DESC_BASE,
        "--privacy", "public",  # shorts는 public만 가능
        "--category", "22",
        "--tags", "ICBM", "AI", "테크", "개발자", "인공지능"
    ])

# 4. 30초 후 로그로 성공/실패 확인
import time; time.sleep(30)
for vid in [...]:
    with open(f"/tmp/icbm_notebooklm/upload_{vid}.log") as f:
        print(f.read())  # "✅ Upload successful! URL: ..." 확인
```

모든 영상/숏츠 업로드 시 **출처 포함 설명** 사용.

> **단일 영상**만 있는 경우 위 단일 영상 가이드를 사용.

**다중 영상 일괄 업로드 (배치):**
1. `notebooklm artifact list -n <notebook_id> --type video` → 완료된 비디오artifact 확인
2. `notebooklm download video -n <notebook_id> <path>` → 각 노트북별 다운로드
3. `ffprobe`로 길이 체크 → 60초 이하 = Shorts, 이상 = 일반영상
4. 일반영상: `upload.py`로 동시 백그라운드 업로드 (privacy: unlisted)
5. Shorts: `ffmpeg 9:16 변환` 후 동일하게 업로드

**핵심 인사이트 (2026-04-30):**
- `notebook_ids.json` (`/tmp/icbm_notebooklm/notebook_ids.json`)에 오늘 생성된 노트북 ID+제목+URL 저장됨 → 배치 다운로드 시 이 파일 재활용
- 6개 동시에 백그라운드 업로드 시 PID 추적 → 30초 후 로그로 성공/실패 확인
- `ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 <file>`로 길이 체크

사용자가 NotebookLM에서 **이미 비디오 오버뷰를 생성**한 후 "이것 YouTube에 올려줘"라고 URL만 알려줄 때.

**절대 Playwright 사용 금지** — 네트워크 캡처/요소 탐색이 불안정함.
**CLI 방식만 사용.**

```bash
# 1. 노트북 접근
source ~/.hermes/venv-notebooklm/bin/activate
notebooklm use <notebook_id>

# 2. 비디오 다운로드
notebooklm download video <notebook_id> /tmp/video.mp4
# 출력 예: "Video saved to: /tmp/video.mp4"

# 3. ffprobe로 정보 확인
ffprobe -v error -show_entries stream=width,height,duration -of json /tmp/video.mp4

# 4. 숏츠 생성 (60초, 9:16)
ffmpeg -y -i /tmp/video.mp4 \
  -ss 90 -t 60 \
  -vf "scale=1080:1920:force_original_aspect_ratio=decrease,pad=1080:1920:(ow-iw)/2:(oh-ih)/2:color=black,setsar=1" \
  -c:v libx264 -preset fast -crf 23 \
  -c:a aac -b:a 128k \
  /tmp/shorts.mp4

# 5. YouTube 업로드 (OAuth API)
~/.hermes/hermes-agent/venv/bin/python3 << 'PYEOF'
import os, pickle
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

TOKEN = os.path.expanduser("~/.hermes/secrets/youtube_token.pickle")
with open(TOKEN, 'rb') as f:
    creds = pickle.load(f)
if creds.expired:
    creds.refresh(Request())
    with open(TOKEN, 'wb') as f:
        pickle.dump(creds, f)

youtube = build('youtube', 'v3', credentials=creds)
youtube.videos().insert(
    part='snippet,status',
    body={
        'snippet': {
            'title': '영상 제목',
            'description': '설명\n\n#해시태그',
            'categoryId': '28',
        },
        'status': {'privacyStatus': 'public'}
    },
    media_body=MediaFileUpload("/tmp/video.mp4")
).execute()
PYEOF
```

**핵심 교훈 (2026-04-30):**
- Playwright 네트워크 캡처로 비디오 URL 탐지 → 실패 (blob URL, iframe 등 복잡)
- CLI `notebooklm download video` → 완벽 작동
- **항상 CLI 우선**

모든 영상/숏츠 업로드 시 **출처 포함 설명** 사용.

| 구분 | 일반 영상 | 숏츠 |
|------|---------|------|
| 요약 | `[주제명] 관련最新 소식` | 동일 |
| 출처 | GitHub/HN/ProductHunt 실제 URL | 동일 |
| 해시태그 | `#ICBM #AI #테크 #개발자 #인공지능` | 동일 |

## 🚨 오류 처리

### YouTube OAuth 토큰 만료 (가장 흔한 장애)

**증상:** `invalid_grant: Token has been expired or revoked`  
**영향:** 업로드만 실패, 노트북은 이미 삭제된 상태

**복구 절차:**
1.的主人님이 직접 브라우저 인증 실행:
   ```bash
   python3 ~/.hermes/skills/creative/youtube-uploader/scripts/auth.py
   ```
   - 브라우저 열림 → Google 계정 로그인 → 권한 승인
2. 토큰 갱신 완료 후 다시 **'업로드'** 라고 요청
3. 단, 오늘의 노트북은 이미 삭제되었으므로 **'1,3,5' 등 선택 번호**를 다시 알려주시면 노트북+영상 재생성

> ⚠️ **중요:** 오늘 노트북 재생성 시 기존 소스는 gone. NotebookLM에서 새 영상 생성하면 `업로드` 재요청

### YouTube OAuth 토큰 만료 예방

`auth.py`의 `refresh_token`이 만료되면 재인증 필요.  
주인님이 한 달에 1회 정도 토큰 상태를 확인하는 걸 권장 (자주 쓰면 자연스럽게 갱신됨).

### 비디오 미생성
- 업로드 시 텔레그램 알림 → NotebookLM에서 수동 생성 후 다시 "업로드" 요청
- **삭제 금지**: 다운로드+업로드 성공한 것만 삭제

### 소스 없음
- HN/Reddit fallback 사용 → 그래도 없으면 GitHub Trending

### 노트북 없음
- 메모리 파일 확인 → `notebooklm_selection.py` 재실행 유도

### 업로드 실패 시 절대 삭제 금지
노트북 삭제(`notebooklm delete`)는 **다운로드 + 일반 영상 + 숏츠 모두 성공**했을 때만 실행.  
부분 성공 시에도 삭제하지 않고 주인님에게 상태 보고.
