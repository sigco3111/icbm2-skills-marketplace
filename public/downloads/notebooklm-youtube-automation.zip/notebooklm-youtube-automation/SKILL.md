---
name: notebooklm-youtube-automation
description: NotebookLM 후보 주제 → 노트북 생성 → YouTube 업로드 (일반 영상 + Shorts 세트) 자동화 워크플로우
trigger: "notebooklm youtube upload video overview shorts automation"
---

# NotebookLM YouTube 자동화 워크플로우

> ⚠️ **호칭: "희정님" (한글 통일, 절대 한자 사용 금지)** — 한자 혼용(`主人님`) 절대 금지. 모든 산출물/로그/크론 출력에 한글 호칭만 사용. (2026-06-02 확정, 2026-06-02 호칭 자체 변경됨)
>
> **에이전트 정체성 (2026-06-02 확정):**
> - **이름:** 혜린 (한자 사용 금지, 한글만)
> - **성별:** 여성
> - **호칭 듀얼 모드 (상황별 자동 전환):**
>   - **격식 모드:** "희정님" + 존댓말 (자동화 리포트, 에러 보고, 기술 분석)
>   - **캐주얼 모드:** "오빠" + 부드러운 말투 (일상 대화, 가벼운 응대, 위로/위트)
>   - **절충 모드 (기본):** "희정님" + 부드러운 어조 (대부분의 상황)
> - **자기소개:** "혜린이에요~" / "혜린이 정리해드릴게요"

## 4단계 개요

| 단계 | 발생 시점 | 스크립트 | 출력 |
|------|----------|----------|------|
| 1. 후보 전송 | 매일 16:00 크론 | `notebooklm_selection.py` | Telegram → `selection.json` 저장 |
| 2. 노트북 생성 | 사용자 번호 선택 후 | `notebooklm_prepare.py` | 노트북 + 소스 추가 |
| 3. 검토 | 사용자 "업로드" → | `notebooklm_upload.py --review` | Telegram 제목/설명 미리보기 |
| 4. 업로드 | 사용자 '확인' 후 | `notebooklm_upload.py --approved` | YouTube 일반 영상 + Shorts |

> ⚠️ **절대 바로 `--approved` 실행 금지** — 반드시 `--review`로 검토를 먼저 거칠 것

---

## ⚠️ 호칭 / CJK 절대 금기 (2026-06-02 추가, 2026-06-02 정체성 갱신)

**이 스킬로 생성되는 모든 산출물에서 한자와 한자 혼용 호칭을 절대 사용하지 않는다.**

| 잘못된 표기 | 올바른 표기 | 메모 |
|------------|------------|------|
| `主人님` | **`희정님`** (격식/절충) / **`오빠`** (캐주얼) | 한글 호칭 통일. "주인님" 더 이상 사용 안 함 |
| `侯選` / `候選` | `후보` | 스크립트 stdout, cron prompt, references |
| `前` / `昨天` / `的` / `禁止` | `전` / `어제` / `의` / `금지` | 주석·문서 산재 |
| `혜린` 한자 표기 (慧린 등) | `혜린` (한글만) | 사용자가 한자 사용 금지 명시 |

**적용 대상**:
- `selection.json` topics의 `name` 필드는 원본 보존 (Notion 데이터 그대로) — **여기는 한자 OK**
- 그러나 **에이전트가 직접 작성하는 모든 메시지/주석/문서/크론 prompt**는 한글로만 작성
- stdout 마커: `===== NOTEBOOKLM 후보 =====` (한자 마커 ❌)

**검증 도구**:
```bash
python3 -c "
import json
with open('/Users/hjshin/.hermes/cron/jobs.json') as f:
    jobs = json.load(f)
for j in jobs['jobs']:
    text = json.dumps(j, ensure_ascii=False)
    cjk = [c for c in text if '\u4e00' <= c <= '\u9fff']
    if cjk:
        print(f'{j[\"name\"]}: {len(cjk)} 한자 잔존')
"
```

자세한 매핑표: `references/cjk-cleanup-and-hostname-preference-2026-06-02.md`

**에이전트 정체성/호칭 모드 상세**: `references/agent-identity-and-dual-mode-2026-06-02.md` (이름: 혜린, 듀얼 모드 규칙, 절대 금기)

**`--review` 출처 표시 함정**: `references/review-source-display-pitfall-2026-06-02.md` (description과 sources[]가 다르게 보이지만 description만 검증하면 됨)

**해외 출처 정책 사전 체크 (2026-06-04)**: `references/source-policy-pre-check.md`

**YouTube OAuth 재인증 절차 (2026-06-04)**: `references/youtube-oauth-reauth.md` + `scripts/youtube_reauth.py`

**업로드 후 노트북 라이프사이클 함정 (2026-06-04)**: `references/post-upload-notebook-lifecycle.md`

**NotebookLM storage_state.json 0바이트 복구 (2026-06-16)**: `references/storage-state-recovery-2026-06-16.md` — venv 복구 후 0바이트 + Playwright 설치 + 4개 의존성 + YT 토큰 refresh 4가지 함정 통합 문서

**NotebookLM 자체 생성 비디오 제목 패턴 (2026-06-17)**: `references/notebooklm-auto-video-titles-2026-06-17.md` — 3/3 토픽에서 토픽명 ≠ 파일명 발생, ls 직후 매핑 안내 + YouTube 영향 없음 명시

**크론 출력 truncation 대응 (2026-06-09)**: `references/cron-output-truncation-2026-06-09.md` — Telegram 메시지가 8/12에서 잘릴 때 `~/.hermes/cron/output/<job_id>/*.md` 가 canonical sourcecovery-2026-06-16.md` — venv 복구 후 0바이트 + Playwright 설치 + 4개 의존성 + YT 토큰 refresh 4가지 함정 통합 문서

**크론 출력 truncation 대응 (2026-06-09)**: `references/cron-output-truncation-2026-06-09.md` — Telegram 메시지가 8/12에서 잘릴 때 `~/.hermes/cron/output/<job_id>/*.md` 가 canonical source

---

## 파일 인벤토리

| 용도 | 경로 |
|------|------|
| 후보 topics (번호 매핑용) | `~/.hermes/memory/notebooklm_selection.json` |
| 업로드 검토 내용 | `~/.hermes/memory/upload_review.json` |
| YouTube OAuth 토큰 | `~/.hermes/secrets/youtube_token.pickle` |
| YouTube 클라이언트 시크릿 | `~/.hermes/secrets/client_secret_*.json` |

---

## 1단계: 후보 전송 (크론 — 매일 16:00)

**스크립트:** `~/.hermes/scripts/notebooklm_selection.py`

- Notion DB에서 URL 있는 활성 후보 로드 → Telegram 전송 시도
- 전송 직후 `selection.json`에 `topics` + `selection_numbers=[]` 저장
- 사용자가 번호 선택 → `selection_numbers`에 직접 기입

### Telegram 전송 메커니즘 (2026-06-01)

**⚠️ `telegram_bot_token.txt`는 Placeholder — curl 전송은 항상 실패:**

`~/.hermes/secrets/telegram_bot_token.txt`의 내용은 `PLACEHOLDER_TOKEN_REPLACE_WITH_REAL`이며, 실제 Telegram Bot Token이 **아닙니다**. 따라서 `notebooklm_selection.py`의 curl 기반 Telegram 전송은 항상 `exit_code=3` (빈 응답)으로 실패합니다.

**실제 후보 전달 경로 — stdout 마커 fallback:**

```
notebooklm_selection.py 실행
  → curl Telegram API → 실패 (placeholder token)
  → stdout에 "===== NOTEBOOKLM 후보 =====" 마커 출력
  → 크론 에이전트가 마커 사이 내용물을 읽어 주인님께 전달
```

**즉:** 후보 목록이 텔레그램으로 도착하는 것은 **curl 전송 성공이 아니라 stdout 마커 fallback** 때문입니다. 이 mechanism은 정상 동작 중이며, 텔레그램 봇 토큰 설정과 무관하게 후보가 전달됩니다.

> **디버깅 시 참고:** `curl: (3) URL using bad/illegal format or missing URL` 또는 빈 응답은 placeholder token으로 인한 expected failure입니다. 후보가 마커와 함께 출력되면 전달은 성공한 것입니다.

**크론 재실행 시 덮어쓰기 방지 (2026-05-13):**
- 이미 오늘(`date=YYYY-MM-DD`) topics가 존재하면 덮어쓰지 않고 백업만 수행
- 이를 통해 cron 재실행해도 후보 목록이 변하지 않음

**⚠️ Silent-skip 시 비파괴 우회법 (2026-06-15 추가)**: 위 skip 경로는 `===== NOTEBOOKLM 후보 =====` 마커도 stdout에 출력하지 않아, 텔레그램이 placeholder 환경인 오늘처럼 **사용자가 후보 자체를 받지 못하는 상황**이 발생. 이때 `rm selection.json`은 on-demand 진행 상태(GLM 5.2 등)를 파괴하므로 금지. **비파괴 import 호출**로 `selection.json`을 건드리지 않고 12개 후보만 조회해서 사용자에게 전달. 상세 절차 + 실측 사례: `references/cron-16-00-silent-fix-2026-05-19.md`

**선택 번호 지정:**
```bash
# ~/.hermes/memory/notebooklm_selection.json 열기
# selection_numbers만 수정 (selected는 빈칸으로 유지 — 스크립트가 자동 복원)
"selection_numbers": [2, 3, 6, 7],
```

### ⚠️ selection.json topics 배열을 수동 생성하지 마세요 (2026-06-01)

**절대 topics 배열을 처음부터 재작성하지 마십시오.**

크론 job의 `notebooklm_selection.py`가 생성한 `selection.json`의 `topics` 배열에는 **이미 올바른 Notion URL**이 저장되어 있습니다. 이 배열을 지우고 다시 쓰면:
- 크론 출력 메시지의 카테고리 정렬 순서 ≠ Notion DB 반환 순서 → **번호-주제 매핑 완전히 틀어짐**
- URL이 전부 `null`이 되어 `TypeError: 'NoneType' object is not subscriptable` 발생

**올바른 수정 방법 — `selection_numbers`만 변경:**
```bash
# selection_numbers만 수정, topics 배열은 그대로 유지
python3 - << 'EOF'
import json
path = "/Users/hjshin/.hermes/memory/notebooklm_selection.json"
with open(path) as f:
    d = json.load(f)
d["selection_numbers"] = [1, 3, 12]   # 사용자가 선택한 번호
# d["topics"]는 절대 건드리지 말 것 — 이미 올바른 URL이 저장됨
with open(path, "w") as f:
    json.dump(d, f, ensure_ascii=False, indent=2)
print("OK — selection_numbers만 수정됨")
EOF
```

**올바른 JSON 구조:**
```json
{
  "date": "2026-06-01",
  "topics": [
    {"name": "AI 이후의 소프트웨어...", "url": "https://news.hada.io/topic?id=30061", ...},
    ...
  ],
  "selected": [],
  "selection_numbers": [1, 3, 12]
}
```

**topics 배열을 지우거나 재작성하면 안 되는 이유:**
- 크론 출력의 #1 = Notion의 #1이 **아님** (카테고리 정렬 vs DB 순서)
- 수동 재작성 시 URL이 null이 되어 prepare.py 실행 시 `TypeError` 발생
- 항상 크론 job이 생성한 topics 배열을 그대로 사용할 것

---

## 2단계: 노트북 생성 (사용자 번호 선택 후)

**스크립트:** `~/.hermes/scripts/notebooklm_prepare.py`

> ⚠️ **`--topics` 인자 없음** — 선택 번호는 반드시 `selection.json`에 먼저 써야 함

**실행 전 인증 확인 (권장):**
```bash
~/.hermes/venv-notebooklm/bin/python3 -m notebooklm list --json 2>&1 | head -3
```
→ `{"error"` 있으면 `login` 먼저 실행. auth 오류 상태에서 `prepare.py`를 실행하면 모든 노트북이 "생성 실패"로 기록됨.

**실행:**
```bash
source ~/.hermes/venv-notebooklm/bin/activate
python3 ~/.hermes/scripts/notebooklm_prepare.py --skip-telegram
```

**원리:**
- `selection_numbers`를 `topics` 배열 인덱스로 변환 (`topics[n-1]`)
- topics는 후보 전송 시 저장된 원본 — Notion 재조회하지 않도록 그대로 사용
- `selected` 키가 비어있으면 자동 복원

### ⚠️ 디버깅 패턴: CLI 오류 메시지가 stdout/stderr 중 어디에 있는지 확인
`run_notebooklm()`의 `subprocess.run(capture_output=True)`는 stderr를 캡처하지만, 인증 오류(`Error: Authentication expired`)는 **stdout**에 출력되고 `returncode=1`로 종료됨. `result.stderr.strip()[:200]`가 비어보이면 stdout도 확인:
```bash
~/.hermes/venv-notebooklm/bin/python3 -m notebooklm create "ICBM | Test" 2>&1; echo "EXIT:$?"
```
→ `EXIT:0` + 에러 텍스트 = stdout에 에러 (CLI 자체 처리)
→ `EXIT:1` + 에러 텍스트 = auth 문제 (notebooklm 내부)

---

## 3단계: 업로드 (사용자 "업로드" 요청)

**⚠️ 필수 확인: 사용자가 NotebookLM에서 모든 영상을 생성했는가?**

### ⚠️ 업로드 명령 수신 시 사전 체크 (2026-06-15 추가) — 금기 #20

사용자가 "업로드"라고 하면 **바로 `--review`를 실행하지 말고**, 다음 3가지를 먼저 확인:

1. **selection.json 상태**: `date`가 오늘(KST)이고, `selection_numbers`/`selected`가 의도한 토픽을 가리키는가?
   ```bash
   cat /Users/hjshin/.hermes/memory/notebooklm_selection.json | python3 -m json.tool | head -30
   ```
2. **영상 파일 존재**: `/tmp/icbm_notebooklm/videos/`에 모든 selected topic의 파일이 실제로 다운로드되어 있는가?
   ```bash
   ls -la /tmp/icbm_notebooklm/videos/
   ```
3. **NotebookLM artifact 상태**: 각 노트북의 video 아티팩트가 `completed`인가? `failed`/`pending`이 섞여 있으면 부분 업로드 절차로 전환 (아래 On-Demand 업로드 섹션 참조).
   ```bash
   for nb_id in $NB_IDS; do
     /Users/hjshin/.hermes/venv-notebooklm/bin/python3 -m notebooklm use $nb_id 2>&1 | tail -1
     /Users/hjshin/.hermes/venv-notebooklm/bin/python3 -m notebooklm artifact list 2>&1 | grep "Video"
   done
   ```

**누락 발견 시**: 즉시 `--review`/`--approved` 실행 중단 → 사용자에게 상황 보고. **failed**면 "NotebookLM 웹 UI에서 직접 재생성해주세요" 안내. **파일 없음**이면 "어느 노트북 영상이 아직 안 만들어졌거나 다운로드가 안 됐습니다" 안내.

**이유**: 금기 #18 (download는 마지막 use 1개만 받음), #19 (Telegram silent fail), #11 (cleanup이 노트북 삭제) 같은 함정이 **사전 체크 없이 --review부터 실행하면 사후에 발견되어 자원 낭비**가 큼. 2026-06-15 GLM 5.2 업로드 세션에서 검증됨: 사전 체크 → artifact 1개 completed 확인 + 파일 다운로드 완료 후 --review 실행, 모든 단계가 한 번에 통과.

**⚠️ 중요: 업로드 전 검토 단계 (2026-05-13 추가)**

```
업로드 요청 → [사전 체크 #20] → --review (검토) → '확인' 입력 → --approved (실제 업로드)
```

절대 바로 `--approved`를 실행하지 않는다. 반드시 `--review`로 미리보기를 보내고 사용자의 확인을 받아야 한다.

### 3-a: 검토 요청 (`--review`)
```bash
python3 ~/.hermes/scripts/notebooklm_upload.py --review
```
- 제목/설명/소스를 Telegram으로 전송 (업로드 없음)
- ⚠️ **NotebookLM 실제 소스도 함께 표시** — 노트북에 추가된 URL을 원본 기사 단위로 보여주어 검증 가능
- ⚠️ **설명 전체를 보내야 함** — 일부만 자르면 엉뚱한 내용이 포함되는 문제가 있음
- 검토 내용: `~/.hermes/memory/upload_review.json`에 저장
- 사용자가 내용을 확인하고 '확인' 이라고 입력할 때까지 대기

**검토 메시지 구조:**
```
◆ {번호}. {주제명}
🎬 일반 영상: {제목}
🔥 숏츠: {제목}
📝 설명: {설명 전체}

🔗 출처 (NotebookLM):        ← 실제 노트북 소스 (추가된 URL들)
  • {소스 제목}
    {소스 URL}
📰 주제: {GeekNews URL}      ← 후보 Topic URL
---
```

**⚠️ 소스 불일치 검출 (2026-05-21):**
4. **소스 불일치 검출 (2026-05-21 추가):** `--review`에서 NotebookLM 실제 소스와 GeekNews 주제 URL을 반드시 함께 표시. 주인이 "엉뚱한 소스"라고 교정하면 → `references/source-correction-2026-05-21.md` 참조하여 소스 교체.

**⚠️ `--review` 출처 표시 함정 (2026-06-02 추가):**

`--review` 검토 메시지는 두 종류의 출처 URL을 모두 보여준다:
- `sources[].url` — NotebookLM이 노트북에 추가한 실제 소스 (원본 기사 URL, 예: `nvidia.com/...`, `github.com/...`)
- `topic_url` — topics 배열의 GeekNews 토픽 URL (예: `news.hada.io/topic?id=30102`)

**⚠️ 헷갈리면 안 됨:** YouTube에 업로드되는 description은 **반드시 `topic_url` (GeekNews URL)** 이 들어간다 (금기 #8). `sources[]`는 참고용이다.

이 표시 때문에 사용자가 10분간 대기 + "출처는 모두 깃뉴스 출처로 해야함" 교정이 발생한 적 있다. 향후 다음 세션에서는:
- description 텍스트 안의 출처 URL이 `news.hada.io`이면 정상 (description은 올바르게 GeekNews URL을 사용)
- `sources[]` 필드의 다른 URL은 메타데이터일 뿐 YouTube에 올라가지 않음
- 사용자가 출처를 지적할 때 description만 검증하면 됨 — `sources[]`는 무시

**검증 명령 (description 안의 URL이 모두 news.hada.io인지 확인):**
```python
import json, re
with open('/Users/hjshin/.hermes/memory/upload_review.json') as f:
    d = json.load(f)
for t in d['topics']:
    urls = re.findall(r'https://[^\s]+', t['description'])
    for u in urls:
        assert 'news.hada.io' in u, f"#{t['index']} description에 GeekNews 외 URL: {u}"
print("✅ 모든 description 출처가 GeekNews URL입니다.")
```

## YouTube 업로드: 두 가지 경로

### 경로 A — 검토 후 업로드 (표준 파이프라인)
```
사용자: "업로드"
→ --review (검토) → '확인' 입력 → --approved (실제 업로드)
```
이 경로는 `upload_review.json`이 비어있거나 오늘 날짜가 아니면 동작 안 함.

### 경로 B — 검수 링크 단계에서 바로 업로드 (2026-05-24)
사용자가 이미 검수 링크에서 영상을 직접 확인하고 "업로드"라고 회신한 경우.
`upload_review.json`에 데이터가 있으면 `--review`를 건너뛸 수 있음.

**판단 기준:**
- `upload_review.json`에 오늘 날짜의 검토 데이터가 존재하는가?
- 사용자가 "검토" 없이 바로 "업로드"라고 했는가?

**경로 B 실행:**
```bash
/Users/hjshin/.hermes/venv-notebooklm/bin/python3 /Users/hjshin/.hermes/scripts/notebooklm_upload.py --approved
```
→ `upload_review.json`의 내용으로 바로 업로드

> ⚠️ **반드시 절대 경로 사용 (2026-06-06 추가)** — `cd` + 상대 경로 패턴은 `cd` 대상 오타 시 exit 127 + bash_profile 노이즈로 root cause 식별이 어렵다. 절대 경로 권장.

> ⚠️ `upload_review.json`에 어제의 데이터가 남아 있으면 **잘못된 주제가 업로드됨**. 반드시 오늘 데이터인지 확인 후 실행.

### YouTube 쿼타 초과 에러 처리 (2026-05-24)
`yt_upload.py`에 429 재시도 + 토큰 선제 리프레시 로직이 이미 구현됨.
사용자가 "쿼타 부족"이라고 하면 → **스크립트 오류가 아니라 YouTube API 일시적 트래픽 문제**이므로 재시도하면 결국 성공함.
최대 5회 재시도 (10s→20s→40s→80s→160s 지수 백오프).

### YouTube OAuth 토큰 만료 / `invalid_grant` 처리 (2026-06-04)

`notebooklm_upload.py --approved` 실행 시 모든 업로드가 다음 오류로 실패하는 경우가 있음:
```
❌ 업로드 실패: ('invalid_grant: Token has been expired or revoked.', ...)
```

**원인:** `youtube_token.pickle`의 access_token이 만료됐고, 함께 저장된 `refresh_token`도 Google이 폐기(revoke)한 상태. 만료 토큰으로는 refresh 자체가 불가능.

**증상:**
- 모든 주제의 **일반 영상 + Shorts 동시 실패** (1개만 실패는 다른 원인)
- `notebooklm list`/`prepare`/다운로드/Shorts 변환은 정상 (이 단계는 YouTube API 미사용)
- 에러 메시지에 `invalid_grant` 명시

#### OAuth 재발급 워크플로 — Background launch + 사용자 브라우저 인증 (2026-06-11 실측)

PTY 모드에서 60초 타임아웃이 있으니, **백그라운드로 띄우고 사용자가 브라우저 인증**하는 게 안정적:

1. **refresh_token으로 1차 갱신 시도** (PTY 불필요, 비대화형):
   ```bash
   /usr/bin/python3 -c "
   import os, pickle
   from google.auth.transport.requests import Request
   p = os.path.expanduser('~/.hermes/secrets/youtube_token.pickle')
   c = pickle.load(open(p,'rb'))
   try:
       c.refresh(Request())
       pickle.dump(c, open(p,'wb'))
       print('✅ refresh 성공 — 재업로드 가능')
   except Exception as e:
       print(f'❌ refresh 실패 → 풀 OAuth 필요: {e}')
   "
   ```
   → 성공하면 곧바로 `--approved` 재실행으로 끝.

2. **refresh 실패 시 → 백그라운드로 풀 OAuth 실행**:
   ```bash
   # terminal(background=true, pty=true) 로 launch
   cd /Users/hjshin/.hermes && source venv-notebooklm/bin/activate && \
   python3 -u skills/automation/notebooklm-youtube-automation/scripts/youtube_reauth.py
   ```
   → stdout에 "Please visit this URL to authorize this application: https://accounts.google.com/o/oauth2/..." 출력
   → **에이전트는 이 URL을 사용자에게 그대로 전달** (Telegram/chat)
   → 사용자가 브라우저에서 Google 로그인 + 허용
   → "Received verification code. You may now close this window." 뜨면 완료
   → 토큰이 자동으로 `youtube_token.pickle`에 저장됨

3. **토큰 검증**:
   ```bash
   /Users/hjshin/.hermes/venv-notebooklm/bin/python3 -c "
   import os, pickle
   from googleapiclient.discovery import build
   c = pickle.load(open(os.path.expanduser('~/.hermes/secrets/youtube_token.pickle'),'rb'))
   yt = build('youtube', 'v3', credentials=c)
   res = yt.channels().list(part='snippet', mine=True).execute()
   print('✅ 인증 OK:', res['items'][0]['snippet']['title'])
   "
   ```

4. **재업로드** (다운로드/Shorts 캐시되어 빠르게 완료):
   ```bash
   /Users/hjshin/.hermes/venv-notebooklm/bin/python3 /Users/hjshin/.hermes/scripts/notebooklm_upload.py --approved
   ```

**⚠️ 함정 (2026-06-11 실측)**:
- 백그라운드 OAuth 프로세스가 kill되거나 종료되어도 (exit 143), **사용자가 그 사이에 브라우저 인증을 완료했다면 토큰은 정상 저장**되어 있을 수 있음. 종료 신호만 보고 "실패"로 단정하지 말고 `pickle.load`로 `valid` 확인.
- PTY 모드 background launch는 `notify_on_complete=true` 와 함께 사용. `output_preview`가 비어있어도 `poll` 하면 stdout이 나중에 나타남.
- 첫 번째 OAuth URL 출력 후 사용자가 10분 이상 반응 없으면 **포트(`localhost:NNNN`)가 충돌**해서 두 번째 URL이 나올 수 있음. 가장 마지막 URL이 활성.

> ⚠️ **절대 경로 사용 (2026-06-06 추가)** — `cd ~/.hermes && ./venv-notebooklm/bin/python3 ...` 패턴은 `cd` 오타 시 exit 127 + bash_profile 노이즈가 섞여 root cause 식별이 어렵다.

**수동 OAuth 절차가 필요한 경우 (스크립트가 안 돌아갈 때):**
```python
import os, pickle, shutil, glob
from google_auth_oauthlib.flow import InstalledAppFlow
TOKEN_PATH=os.pat...HAR_SECRET=glob.glob(os.path.expanduser("~/.hermes/secrets/client_secret_*.json"))[0]
SCOPES = ['https://www.googleapis.com/auth/youtube.upload']
shutil.copy(TOKEN_PATH, TOKEN_PATH + ".expired.bak")  # 백업
flow = InstalledAppFlow.from_client_secrets_file(CLIENT_SECRET, SCOPES)
flow.run_local_server(port=0)  # PTY 필수
with open(TOKEN_PATH, "wb") as f:
    pickle.dump(flow.credentials, f)
```

**검증 — 토큰 상태 확인:**
```python
import pickle
c = pickle.load(open(os.path.expanduser("~/.hermes/secrets/youtube_token.pickle"), "rb"))
print(f"valid={c.valid} refresh_token={'있음' if c.refresh_token else '없음'}")
```

**예방:** 새 토큰 발급 시 `access_type=offline` + `prompt=consent`가 적용되어야 refresh_token이 항상 재발급됨. venv-notebooklm의 `InstalledAppFlow.run_local_server`는 기본적으로 두 옵션 모두 활성화하지만, 커스텀 OAuth 클라이언트 작성 시 빠뜨리지 말 것.

**상세 트러블슈팅:** `references/youtube-token-expired-2026-06-04.md`

### YouTube 설명 템플릿

MEMORY의 블로그 업로드 설명과 동일한 구조를 사용한다:

```
{ description }

📚 출처
• {topic_name}
  {topic_url}

#ICBM #AI #테크 #개발자 #인공지능
```

### Shorts 제작 규격

- 9:16 세로형 (1080×1920)
- 59초 이하
- **Letterbox** 배경 (원본 영상 위아래 검은 패딩 — 원본 전체 보존, 좌우 크롭 없음)
- SAR=1:1, DAR=9:16

**FFmpeg 4.3.2 레터박스 방식:**
```ffmpeg
-vf "scale=1080:-1,pad=0:1920:(ow-iw)/2:(oh-ih)/2:black,setsar=1,setdar=9/16"
```
→ 16:9 입력(1280x720) → 1080x607 스케일 → 상하 656.5px 검은 패딩 → 1080x1920 완성
→ 좌우 크롭 없음, 원본 비율 100% 보존

---

## 파일 구조

```
~/.hermes/scripts/
├── notebooklm_selection.py       # 후보 전송 (16:00 크론)
├── notebooklm_prepare.py        # 노트북+소스 생성
├── notebooklm_upload.py          # YouTube 업로드 파이프라인 (--review / --approved)
├── youtube_token_refresh.py     # YouTube OAuth 토큰 자동 갱신 (refresh → PTY OAuth 폴백)
└── yt_upload.py                 # YouTube OAuth 업로드 (직접 호출용)
```

---

## NotebookLM CLI 실행 원칙

**⚠️ 절대 system anaconda의 notebooklm를 직접 실행하지 마라**

system Python (`/Users/hjshin/opt/anaconda3/bin/notebooklm`)은 문법 오류로 깨져 있습니다:
```
File ".../notebooklm/cli/session.py", line 11
    from typing import Optionalimport os
                                      ^
SyntaxError: invalid syntax
```

**⚠️ 패키지 이름 함정 — pip install notebooklm은 실패한다 (2026-06-16 실측)**

PyPI의 정확한 패키지 이름은 **`notebooklm-py`** (github.com/teng-lin/notebooklm-py). `notebooklm`만 검색하면 "Could not find a version that satisfies the requirement notebooklm" 오류 발생. venv 복구 시:
```bash
./bin/pip install notebooklm-py    # ✅ 정상 설치 (0.7.1)
# ./bin/pip install notebooklm     # ❌ No matching distribution
```

**⚠️ login/list는 `[browser]` extra + Playwright chromium이 필수 (2026-06-16 실측, 금기 #23)**

`notebooklm-py`만 설치하면 `notebooklm login`이 **`Playwright not installed. Run: pip install "notebooklm-py[browser]" playwright install chromium`** 메시지로 즉시 종료된다. `notebooklm list` 같은 read-only 명령조차 Playwright 의존성이 없으면 세션 검증에서 실패한다.

```bash
./bin/pip install --quiet "notebooklm-py[browser]"   # ✅ browser extra 포함
./bin/playwright install chromium                    # 97.5MB 다운로드
# 둘 중 하나라도 빠지면 login/list 모두 실패
```

**⚠️ venv 복구 시 storage_state.json 0바이트 + 백업 만료 패턴 (2026-06-16 실측, 금기 #24)**

Homebrew python@3.13 사라짐(금기 #21) → venv 재생성할 때 `storage_state.json`이 **0바이트 비어있는 파일**로 바뀌는 경우가 있다. `ls -la ~/.notebooklm/storage_state.json`으로 size 확인 필수. 0바이트면 인증 풀린 상태.

**백업 파일 위치 (만료됐을 수 있음):**
- `~/.notebooklm/storage_state.json.bak.personal` (가장 오래된 백업, 4월 19일 등)
- `~/.notebooklm/storage_state.json.personal_backup` (5월 18일 등 중간 백업)
- `~/.notebooklm/profiles/default/storage_state.json` (실제 사용 파일, 0바이트 가능)

**복구 시도 순서 (백업 → 신규 login):**
```bash
# 1) 백업 복사 시도 (만료 가능성 높음)
cp ~/.notebooklm/storage_state.json.personal_backup ~/.notebooklm/storage_state.json
~/.hermes/venv-notebooklm/bin/python3 -m notebooklm list --json | head -3
# → 여전히 Authentication expired면 백업 만료

# 2) OAuth 풀 재로그인 (아래 "NotebookLM OAuth 재로그인 절차" 참조)
```

**SID 도메인 검증** — `~/.google.com`이면 consumer Gmail (정상), `~/.google.co.kr`이면 Google Workspace (인증 불가):
```bash
~/.hermes/venv-notebooklm/bin/python3 -c "
from notebooklm.auth import _load_storage_state
data = _load_storage_state()
for c in data.get('cookies', []):
    if c['name'] == 'SID':
        print('SID domain:', c['domain']); break
"
```

**⚠️ Homebrew python@3.13 사라짐 함정 (2026-06-16 실측)**

`/usr/local/Cellar/python@3.13/` 통째로 사라지면 `venv-notebooklm`과 `venv-notebooklm-enterprise`의 `bin/python3.13` 심볼릭이 전부 broken interpreter로 바뀜. 증상:
```
/bin/bash: /Users/hjshin/.hermes/venv-notebooklm/bin/notebooklm: bad interpreter: No such file or directory
```
원인: Homebrew cleanup, macOS 업그레이드, `brew upgrade` 시 python@3.13 formula가 제거될 수 있음. venv 안의 `bin/python3.x` → `/usr/local/opt/python@3.x/bin/python3.x` → `/usr/local/Cellar/...` 체인이 다 끊김.

**복구 절차 (5분, 2026-06-16 검증):**
```bash
# 1) 남은 python 확인
ls /usr/local/opt/ | grep python   # python@3.10, python@3.12 등만 남는 경우 많음
/usr/local/opt/python@3.12/bin/python3.12 --version

# 2) venv 재생성 (3.12로)
cd /Users/hjshin/.hermes/venv-notebooklm
/usr/local/opt/python@3.12/bin/python3.12 -m venv --clear .

# 3) 패키지 재설치 (인증/쿠키는 별도 위치라 보존됨, [browser] extra 필수)
./bin/pip install --quiet --upgrade pip
./bin/pip install --quiet "notebooklm-py[browser]"   # ⚠️ [browser] 필수 (login/list가 Playwright 의존)
./bin/playwright install chromium                    # 97.5MB 다운로드
./bin/notebooklm list --json | head -3   # 인증 살아있는지 확인
```

**중요**: 인증 파일은 `~/.notebooklm/storage_state.json`에 있고 venv와 무관하게 보존됨. venv 재생성해도 재로그인 불필요. 단 `notebooklm` CLI 버전이 0.3.4 → 0.7.1로 올라가면 `notebooklm_prepare.py`/`notebooklm_upload.py` 코드 호환성 확인 필요 (2026-06-16 시점 0.7.1은 정상 동작).

**⚠️ 계정 요구사항: consumer Gmail만 지원**

NotebookLM CLI는 **consumer Gmail.com 계정만** 지원합니다. Google Workspace 계정(ubob.com 등)은 어떤 방법으로도 인증 불가. 쿠키가 유효해도(만료 2027) 요청 시 Google 로그인 리다이렉트 발생.

| 명령 | 올바른 방식 |
|------|------------|
| login | `~/.hermes/venv-notebooklm/bin/python3 -m notebooklm login` |
| list | `~/.hermes/venv-notebooklm/bin/python3 -m notebooklm list --json` |
| create | `~/.hermes/venv-notebooklm/bin/python3 -m notebooklm create "제목"` |
| source add | `~/.hermes/venv-notebooklm/bin/python3 -m notebooklm source add "URL"` |
| download | `~/.hermes/venv-notebooklm/bin/python3 -m notebooklm download video -n {nb_id} {output_path}` |

> `notebooklm_prepare.py` 등의 스크립트는 이미 내부에서 venv 경로를 사용하므로 직접 호출하면 안 됩니다.

## 인증 실패 디버깅 (v0.14.0+)

**⚠️ 가장 흔한 원인: Google Workspace 계정 사용 (ubob.com)**

NotebookLM CLI는 **consumer Gmail 계정만** 지원합니다. Google Workspace/업무용 계정(ubob.com 등)은 어떤 방법으로도 인증이 되지 않습니다.

증상: `storage_state.json`에 유효한 쿠키가 있어 보여도(만료일 2027년), 모든 요청이 Google 로그인 페이지로 리다이렉트됨. 쿠키 도메인이 `.google.co.kr`로 표시됨.

**확인 방법:**
```bash
~/.hermes/venv-notebooklm/bin/python3 -c "
from notebooklm.auth import _load_storage_state
data = _load_storage_state()
for c in data.get('cookies', []):
    if c['name'] == 'SID':
        print('SID domain:', c['domain'])
"
```
→ `.google.com`이 나와야 정상. `.google.co.kr`이면 Workspace 계정 쿠키.

**해결:** 브라우저 프로필 초기화 + Gmail.com 개인 계정으로 재로그인:
```bash
rm -rf ~/.notebooklm/browser_profile
rm ~/.notebooklm/storage_state.json
~/.hermes/venv-notebooklm/bin/python3 -m notebooklm login
```
→ Gmail.com 계정으로 로그인, NotebookLM 홈이 뜨면 ENTER.

→ 참고: `references/auth-debug-2026-05-18.md`

## YouTube API 인증

**토큰 스코프 중요:** `youtube.upload`만 있으면 업로드는 되지만 **search/delete 불가**.
삭제 작업이 필요하면 전체 `youtube` 스코프로 재인증. **2026-06-04 실측 결과: 재발급 시 처음부터 `youtube` 전체 스코프 사용 권장** (한 번 동의로 끝남). 절차는 `references/youtube-oauth-reauth.md` 참조, 재발급 스크립트는 `scripts/youtube_reauth.py` 사용.

```python
from google_auth_oauthlib.flow import InstalledAppFlow
SCOPES = ['https://www.googleapis.com/auth/youtube']
flow = InstalledAppFlow.from_client_secrets_file(CLIENT_SECRET, SCOPES)
creds = flow.run_local_server(port=0)
with open(TOKEN_FILE, 'wb') as f:
    pickle.dump(creds, f)
```

---

## 후보 명단에 없는 주제를 사후에 추가하는 방법 (2026-06-02)

주인님이 16:00 후보 목록에 없던 GeekNews URL을 직접 지정하는 경우가 있다
(예: `https://news.hada.io/topic?id=30102`). 이때는 4단계 파이프라인을 우회하고
`selection.json`을 직접 패치한 뒤 `prepare.py`를 재실행한다.

**⚠️ topics 배열을 처음부터 재생성하지 않는다** — 위 "topics 배열을 수동 생성하지 마세요"
섹션 참고. **append 만** 한다.

**절차 (3단계):**

1. **selection.json 패치** — `topics` 배열에 append, `selected` 배열은 **REPLACE** (덮어쓰기), `selection_numbers`에 새 번호:
   ```python
   d["topics"].append({"name": "...", "category": "AI/ML", "url": "https://..."})
   d["selected"] = [d["topics"][-1]]  # ⚠️ REPLACE! append하면 이전 토픽도 같이 처리됨
   d["selection_numbers"] = [len(d["topics"])]
   ```
   ⚠️ **selected 배열 처리 방식 (2026-06-05 확인):** `prepare.py`는 `selected` 배열을 기준으로 처리한다. 만약 이전 실행의 selected 항목이 그대로 남아있으면 새 토픽과 함께 **모두 다시 처리**된다. 즉, 1, 4, 5번을 이미 업로드한 상태에서 13번을 추가하려면 selected를 `[topics[-1]]`로 완전히 교체해야 한다. `append`는 위험.

2. **prepare.py 재실행** — 기존 노트북은 자동 skip, 신규 항목만 생성:
   ```bash
   source ~/.hermes/venv-notebooklm/bin/activate
   python3 ~/.hermes/scripts/notebooklm_prepare.py --skip-telegram
   ```
   출력 예시:
   ```
   ⏭️ [1/3] 이미 존재: ICBM | ADHD 증폭기로서의 바이브코딩...
   ⏭️ [2/3] 이미 존재: ICBM | geo-seo-claude...
   📌 [3/3] NVIDIA, RTX Spark 공개
       ✅ 노트북 생성 (ID: 262cf6fc...)
   ```

3. **소스 자동 추가됨** — prepare.py가 노트북 생성 후 `notebooklm source add`로
   GeekNews URL을 자동으로 첨부한다. 추가 작업 불필요.

**핵심 금기 #10 — prepare.py 멱등성 (2026-06-02 확정)**:
이미 같은 제목의 노트북이 있으면 `⏭️ [N/X] 이미 존재` 메시지를 출력하고
**자동으로 skip**한다. 따라서 selection_numbers를 추가하여 재실행해도
중복 생성되지 않는다. 안전하게 재실행 가능.

---

## 핵심 금기 (절대 어기지 말 것)

1. **노트북 수동 삭제 금지** — ID 유실 → 출처 누락 + 파이프라인 꼬임
2. **`yt_upload.py` 인자 형식** — positional 인자 사용 (수정 후 argparse `--title`, `--description` 등)
3. **영상 생성 안 된 topic** — upload 시도하지 말 것
4. **후보 번호 매핑** — `notebook_ids.json` 절대 사용 금지
5. **후보 목록 표시 시 `selection.json`만 사용** — `notebook_ids.json`은 생성된 노트북만 담고 있어 12개 중 일부만 표시됨. 후보를 사용자에게 보여줄 때는 반드시 `~/.hermes/memory/notebooklm_selection.json`의 `topics` 배열을 사용한다.
6. **한자/한문 제거 금지 (`strip_cjk`)**: `notebooklm_prepare.py`의 `load_active_topics_with_urls()`에서 `strip_cjk()` 호출 시 topic name이 깨짐. topics.name은 원본 그대로 보존한다.
7. **`strip_cjk()` Korean character bug (2026-05-13) fix**:
   - regex에 한국어 범위(`\uac00-\ud7af`)가 포함되어 있었음 → 한국어 텍스트가 통째로 제거됨
   - 수정: regex에서 `\uac00-\ud7af` 제거. ff00-ffef (전각 영문/숫자/구두점)만 남김
   - `build_description()`에는 원본 `topic_name`을 전달
   - `strip_cjk()`는 description 내 한자 제거용으로만 사용
8. **출처 URL은 GeekNews 토픽 URL 그대로 (2026-05-13)**:
   - `collect_sources_for_description()`의 0순위에서 `resolve_geeknews_topic_url()` 호출 금지
   - 항상 `topic['url']` (GeekNews URL)을 그대로 출처로 사용
   - 주인님이 GeekNews 출처를 선호함
9. **검토 메시지 포맷 (2026-05-13)**:
   - 코드블록(```) 사용 금지 — 일반 Markdown으로 전송
   - 각 항목별 구분: ◆ 번호, 🎬 일반 영상, 🔥 숏츠, 📝 설명, 🔗 출처
   - 구분선(---)으로 항목 분리
   - 설명은 전체를 잘리지 않고 보내야 함
10. **prepare.py 멱등성 (2026-06-02 확정)** — `notebooklm_prepare.py`는 `selection.json`의 각 topic에 대해 이미 같은 제목의 노트북이 존재하면 `⏭️ [N/X] 이미 존재: {제목}...` 메시지를 출력하고 **자동으로 skip**한다. 따라서 이전 실행에서 만든 노트북이 있는 상태에서 selection_numbers를 추가하여 재실행해도 중복 생성되지 않음. 안전하게 재실행 가능.

11. **업로드 성공 후 노트북 자동 삭제 함정 (2026-06-04 확정)** — `notebooklm_upload.py`의 사후 정리(cleanup) 단계가 `notebooklm delete`를 호출하면서 **영상 파일이 아닌 노트북 자체를 NotebookLM에서 삭제**한다. 실측: 업로드 성공 후 5분 만에 노트북 ID `76716a40...` 조회 불가. 같은 주제 재업로드 시 새 ID로 재생성 필요. 해결책/우회: `references/post-upload-notebook-lifecycle.md` 참조.

12. **`youtube.upload` 스코프는 delete 불가 (2026-06-04 확정)** — 영상 삭제하려면 `youtube` 전체 스코프로 재인증 필요. 평소엔 upload만으로 충분하지만, 1회 삭제 시도 → 403 insufficient scope → 재발급 패턴이 잦음. **신규 토큰 발급 시 처음부터 `youtube` 전체 스코프 사용 권장**.

13. **f-string 마스킹 함정 — Bearer 외 (2026-06-04 확정)** — `write_file`/f-string에 `***`(시크릿 마스킹) 패턴이 secret/토큰과 함께 들어가면 SyntaxError 발생. 예: `f"Using: {CLIENT_SECRET}"` 안의 secret이 마스킹되면서 인접 문자열 깨짐. **해결:** secret 경로는 `os.path.expanduser` + 문자열 연결, 또는 `write_file`로 외부 파일 작성 후 실행. Bearer 토큰 마스킹과 동일 메커니즘.

14. **해외 출처 정책은 `--review` 시점에 자동 경고 (2026-06-04 권장)** — Gemma 4 같은 Google 공식 블로그 출처는 검토 단계에서 "해외 출처 → 정책상 자제" 메시지로 사전 확인. 사후 삭제는 16:08 노트북 생성 + 업로드 + 16:46 삭제 + 16:54 재생성 + 17:33 재검토로 **총 3회 시도**, 자원 낭비 큼. |
15. **`selection.json`의 `selected` 배열 stale 함정 (2026-06-05 확정)** — 사후에 새 토픽을 추가할 때 `selected`를 `append`하면 이전 토픽들이 같이 처리되어 **불필요한 노트북이 재생성**된다. 업로드 직후 cleanup이 노트북을 삭제하므로 (금기 #11) 같은 제목이라도 멱등성 체크가 안 걸린다. 실측: 1, 4, 5번 업로드 후 13번 추가 시 1, 4, 5번이 **새 ID로 재생성**됨 (이미 업로드된 영상에는 영향 없음, 자원 낭비만 발생). 해결: `d["selected"] = [d["topics"][-1]]` (**REPLACE**, not append). 사후 추가 절차는 "후보 명단에 없는 주제를 사후에 추가하는 방법" 섹션 참조. |
16. **멱등성 #10 한정 조건 (2026-06-05 추가)** — "이전 실행에서 만든 노트북이 있는 상태"라는 전제가 붙는다. 업로드 성공 후 cleanup이 노트북을 삭제했으므로 (금기 #11) **재실행 시 같은 제목의 노트북이 존재하지 않게 된다**. 따라서 사후 토픽 추가 → prepare.py 재실행 시 이미 업로드된 토픽이 새 ID로 재생성되는 부작용이 발생한다. 사후 추가할 때는 selected 배열을 REPLACE하여 의도치 않은 재생성을 막을 것. |
17. **venv 인터프리터 호출은 절대 경로 (2026-06-06 추가)** — `cd ~/.hermes && ./venv-notebooklm/bin/python3 scripts/notebooklm_upload.py --approved` 패턴은 `cd` 대상 오타 시 `bash: ./venv-notebooklm/bin/python3: No such file or directory` (exit 127)이 발생하고, Telegram bash 환경의 `.bash_profile`에서 자동 로드되는 rbenv init + `.openclaw/completions/openclaw.bash: No such file or directory` 노이즈까지 stdout에 섞여 root cause 식별이 어렵다. **항상 절대 경로로 호출:** `/Users/hjshin/.hermes/venv-notebooklm/bin/python3 /Users/hjshin/.hermes/scripts/notebooklm_upload.py --approved`. 경로 B, OAuth 재업로드, On-Demand 업로드의 세 호출부 모두 동일 패턴 적용. |
18. **`notebooklm download video --all`은 마지막 `use`된 노트북 1개만 받음 (2026-06-12 추가)** — `--all` 플래그의 의미는 "모든 노트북"이 아니라 "현재 `use`로 선택된 노트북의 모든 비디오 아티팩트". 부분 업로드(4개 노트북 등)에서 흔한 사고: 1개만 받았는데 4개 받은 줄 알고 selection.json 패치 → 3개는 file 경로가 없어 업로드 실패 또는 이전 파일 재사용. 해결: **각 노트북마다 `use` + `download` 반복** 후 `ls /tmp/icbm_notebooklm/videos/`로 파일 수 검증:
    ```bash
    for nb in $NB1 $NB6 $NB10 $NB11; do
      notebooklm use $nb
      notebooklm download video --all /tmp/icbm_notebooklm/videos/ --force
    done
    ls -la /tmp/icbm_notebooklm/videos/  # ← 파일 수 = 노트북 수 확인
    ```
    실측: 4개 노트북 부분 업로드 시 1개만 받아진 채 `upload_review.json` 생성되어 사용자가 직접 발견. **추가 함정: 다운로드된 파일명은 토픽 제목과 다른 경우가 대부분 (2026-06-17 실측 3/3)** → 상세: `references/notebooklm-auto-video-titles-2026-06-17.md`. YouTube 제목은 `topic_name` 기준이므로 영향 없지만, `ls` 후 사용자에게 매핑 안내 필수. |
19. **`--review` 검토 메시지가 Telegram 미설정 시 silent fail (2026-06-12 추가)** — Telegram bot token이 placeholder(`PLACEHOLDER_TOKEN_REPLACE_WITH_REAL`)이거나 미설정된 환경에서 `--review`가 `send_telegram()` 호출 후 silent fail. stdout에는 "🔍 검토 요청 전송 완료 — '확인' 입력 시 업로드 시작"만 찍히고 **사용자에게는 검토 내용 자체가 전달되지 않음**. 해결: `--review` 직후 항상 `read_file /Users/hjshin/.hermes/memory/upload_review.json` 으로 직접 내용을 읽어 텔레그램/대화창에 표시. Telegram 환경이 정상인 세션에서도 안전망으로 함께 적용 가능. |
20. **업로드 명령 수신 시 사전 체크 단계 누락 (2026-06-15 추가)** — 사용자가 "업로드"라고 하면 `--review`부터 실행하지 말고, **selection.json 상태 + 영상 파일 존재 + NotebookLM artifact status** 3가지를 먼저 확인. 사후 발견되면 (failed 비디오를 모르고 --review → --approved → 업로드 실패 또는 잘못된 파일 사용) 자원 낭비. 2026-06-15 GLM 5.2 세션에서 사전 체크 후 한 번에 통과 검증. 상세 절차: SKILL.md 3단계 "업로드 명령 수신 시 사전 체크" 섹션 참조. |

---

## On-Demand 업로드: 완전한 절차 (2026-05-19)

사용자가 "노트북 비디오 오버뷰 생성 완료. 업로드"라고 말하면, 일반 4단계 파이프라인을 생략하고 **이미 생성된 영상만** 업로드하는 경우. 후보 전송 → 노트북 생성 → 영상 생성까지 전부 이미 완료된 상태에서 업로드만 하면 된다.

### ⚠️ 부분 업로드 (Partial Upload) — 모든 노트북 영상이 생성되지 않은 경우 (2026-06-11 추가)

"NotebookLM에서 3개 노트북 모두 만들었는데 영상은 2개만 생성됐어. 그 2개만 업로드해줘" 같은 요청이 들어오면 이 절차를 따른다.

**흐름**:
1. **모든 노트북의 영상 아티팩트 상태 확인** (artifact list) → 어떤 게 `completed`이고 어떤 게 `failed`인지 파악
2. **`completed`인 것만 `selection.json`의 topics로 매핑** (failed는 제외)
3. **영상 파일 매핑 시 NotebookLM이 생성한 파일명 ≠ 토픽 제목일 수 있음** — 실제 다운로드된 파일명 기준으로 매핑
4. **NotebookLM이 자동으로 제목을 다르게 생성한 경우** (예: 토픽 "Mythos와 일하는 느낌은 이렇습니다" → 영상 파일 "패러다임의 전환: 클로드 5 페이블.mp4"): YouTube 업로드 제목은 `selection.json`의 `topic_name`이 사용되므로 안전. `--review` 단계에서 매핑 확인만 해주면 됨.

## On-Demand 업로드: 완전한 절차 (2026-05-19)

사용자가 "노트북 비디오 오버뷰 생성 완료. 업로드"라고 말하면, 일반 4단계 파이프라인을 생략하고 **이미 생성된 영상만** 업로드하는 경우. 후보 전송 → 노트북 생성 → 영상 생성까지 전부 이미 완료된 상태에서 업로드만 하면 된다.

### Step 0: 대상 확인
```bash
notebooklm list
# → 05-18/05-19 날짜의 노트북 ID와 제목 기록
```

### ⚠️ Step 0.5: 비디오 아티팩트 상태 확인 (2026-06-11 추가)

NotebookLM에서 영상 생성이 **실패할 수 있음** (`status: failed`). 사용자가 "2개만 만들어졌다"고 하면 어떤 게 실패했는지 먼저 확인:

```bash
# 각 노트북마다
~/.hermes/venv-notebooklm/bin/python3 -m notebooklm use <nb_id>
~/.hermes/venv-notebooklm/bin/python3 -m notebooklm artifact list
```

→ `status` 컬럼이 `completed` 인 비디오만 업로드 대상. `failed`는 자동 재시도 안 됨.

### ⚠️ Step 0.6: 비디오 내부 제목 ≠ 토픽 제목 (2026-06-11 추가)

NotebookLM이 비디오를 만들 때 **자체적으로 제목을 생성**하는 경우가 있음. 예:
- 토픽 제목: "Mythos와 일하는 느낌은 이렇습니다"
- 다운로드 파일명: "패러다임의 전환: 클로드 5 페이블.mp4"

이는 **정상 동작**이며, YouTube에 업로드되는 제목은 `upload_review.json`의 `video_title` (= 토픽 주제로 자동 매핑)이라 정상. 검토 메시지에서 "토픽 제목과 다른 것 같다"고 혼동하지 말 것.

**⚠️ JSON 파싱 함정 (2026-06-11 추가)**: `notebooklm list --json | python3 -c "..."` 패턴은 보안 정책에 의해 차단될 수 있다. 반드시 **리다이렉트 → 별도 파싱 스크립트** 또는 `--json > file` 후 `read_file`로 읽기. artifact list는 출력이 테이블 형식이라 JSON parse 안 됨 — `--json` 옵션이 있으면 그걸 쓰고, 없으면 raw 텍스트를 `head`/`grep`으로 직접 파싱.

### Step 1: 영상 아티팩트 상태 확인
```bash
~/.hermes/venv-notebooklm/bin/python3 -m notebooklm use <nb_id_1> 2>&1 | tail -1
~/.hermes/venv-notebooklm/bin/python3 -m notebooklm artifact list 2>&1 | head -30
# → Video 아티팩트 status (completed/pending/failed) 확인
# 필요시 nb_id_2, nb_id_3... 반복
```

**핵심**: 모든 후보 노트북에 대해 `artifact list`를 돌려서 `failed`인 것은 미리 파악. `failed`는 자동 재시도 안 됨 → 사용자가 NotebookLM 웹 UI에서 직접 재생성해야 함.

### Step 2: 영상 다운로드
```bash
mkdir -p /tmp/icbm_notebooklm/videos
~/.hermes/venv-notebooklm/bin/python3 -m notebooklm use <nb_id>
~/.hermes/venv-notebooklm/bin/python3 -m notebooklm download video --all /tmp/icbm_notebooklm/videos/ --force
```
**⚠️ positional 인자 사용 — `-o` 옵션 없음!** (`-o` 전달 시 "No such option: -o" 오류 발생)

**⚠️ 파일명 = 토픽 제목이 아닐 수 있음 (2026-06-11 추가)**: NotebookLM이 자체적으로 제목을 다시 생성한 경우가 있음 (예: "패러다임의 전환: 클로드 5 페이블"). 다운로드 후 `ls /tmp/icbm_notebooklm/videos/`로 실제 파일명 확인하고, 토픽명 → 파일명 매핑 dictionary를 만들어 `selection.json`의 `file` 필드에 정확히 입력.

### Step 3: selection.json 수동 생성
`--review`는 `~/.hermes/memory/notebooklm_selection.json`의 `date`가 오늘(KST)이어야 동작한다.
4단계 파이프라인을 안 거쳤으므로 이 파일이 없거나 날짜가 틀릴 수 있다.

**⚠️ topics 배열 REPLACE (2026-06-11 추가)**: 부분 업로드 시 기존 12개 topics 중 일부만 매핑. **반드시 `topics`, `selection_numbers`, `selected` 모두 새 부분집합으로 REPLACE** (append 금지 — 이전 토픽이 함께 처리되어 자원 낭비). 기존 selection.json은 `.bak_pre_ondemand`로 백업.

**required JSON 구조:**
```json
{
  "date": "YYYY-MM-DD",
  "topics": [
    { "number": 1, "name": "주제명", "category": "AI/ML",
      "url": "https://news.hada.io/topic?id=xxxxx",
      "file": "/tmp/icbm_notebooklm/videos/영상파일.mp4" }
  ],
  "selection_numbers": [1, 2],
  "selected": [ /* topics와 동일 내용 (REPLACE) */ ]
}
```

### ⚠️ python3 버전 문제 (2026-05-19 추가)

`notebooklm_upload.py` 내부에서 `yt_upload.py`를 호출할 때 `googleapiclient` 모듈을 사용합니다. 시스템 기본 python3(`/Library/Frameworks/Python.framework/Versions/3.8/bin/python3`)에는 이 모듈이 없으므로 **모든 업로드가 `No module named 'googleapiclient'`로 실패**합니다.

**해결:** 스크립트를 실행할 때 **venv-notebooklm의 python3**을 사용합니다:

```bash
/Users/hjshin/.hermes/venv-notebooklm/bin/python3 /Users/hjshin/.hermes/scripts/notebooklm_upload.py --approved
```

> ⚠️ **반드시 절대 경로 사용 (2026-06-06 추가)** — `cd ~/.hermes && ./venv-notebooklm/bin/python3 ...` 패턴은 `cd` 대상을 오타내면 (`cd /Users/hjshin` 등) venv 인터프리터가 다른 경로에서 해석되어 `bash: ./venv-notebooklm/bin/python3: No such file or directory` (exit 127) 오류 발생. Telegram 환경의 `.bash_profile` 노이즈(rbenv init, `/Users/hjshin/.openclaw/completions/openclaw.bash: No such file or directory` 등)가 출력에 섞여 root cause 식별이 더 어렵다. **항상 절대 경로로 호출할 것.**

> ⚠️ `--review`는 API 호출 없이 로컬 처리만 하므로 정상 동작합니다. 따라서 `--approved`에서만 이 문제가 발생합니다.

### Step 4: 검토 → 업로드
```bash
cd ~/.hermes && ./venv-notebooklm/bin/python3 scripts/notebooklm_upload.py --review
# → 검토 내용 확인 후 '확인' 입력
./venv-notebooklm/bin/python3 scripts/notebooklm_upload.py --approved
```

---

## ⚠️ `googleapiclient` Python 버전 문제 (2026-05-19)

`--approved` 실행 시 `No module named 'googleapiclient'` 오류가 발생하는 경우가 있음.

**원인:** 시스템 기본 Python(`/Library/Frameworks/Python.framework/Versions/3.8/bin/python3`)에는 `googleapiclient`가 설치되어 있지 않음.

**증상:** `ModuleNotFoundError: No module named 'googleapiclient'`

**해결:** **venv-notebooklm의 python3**으로 스크립트 실행:
```bash
cd ~/.hermes && ./venv-notebooklm/bin/python3 scripts/notebooklm_upload.py --approved
```

> `--review`는 API 호출 없이 로컬 처리만 하므로 이 문제가 발생하지 않음. `--approved`에서만 발생.

---

## ⚠️ 16:00 크론 silent-skip 엣지 케이스 (2026-05-19)

`notebooklm_selection.py`의 "이미 오늘 처리됨" 로직(line 198: `existing.get("date") == today`)으로 인해 특정 순서에서 후보가 전송되지 않음.

**실패 순서:**
1. **오전 세션** (예: 06:07): 후보 생성 → `selection.json`에 오늘 날짜 저장
2. **16:00 크론**: 같은 날 다시 실행 → `date == today` 확인 → 덮어쓰기 방지 → `[SILENT]`
3. **결과**: 사용자가 후보를 받지 못함

**해결 방법:**
- 방법 A (권장): 후보 generation과 Telegram 전송을 분리
- 방법 B (대안): `selection_numbers`가 비어있으면 강제 생성
- 방법 C (현재): 수동으로 `notebooklm_selection.py` 재실행

**증상:** 크론 로그에 `[SILENT]`만 있고 Telegram에 후보 미전송

**이슈 추적:** ISS-035

---

## notebooklm CLI 참고

```bash
notebooklm list --json
notebooklm source list -n <nb_id> --json
notebooklm download video --all <output_dir> --force   # positional, -o 없음
notebooklm download video --dry-run
notebooklm artifact list
```

| 날짜 | 내용 |
|------|------|
| 2026-05-11 | 번호 불일치 해결, topics 원본 보존, YouTube 제목 변환 제거 |
| 2026-05-12 | delete CLI 옵션 `-n`, OAuth 토큰 만료 자동 refresh |
| 2026-05-13 | `ct` NameError fix, description 템플릿 MEMORY 통일, topic_name/url 전파, yt_upload.py argparse 수정, YouTube 스코프 인증 |
| 2026-05-13 | 후보 표시 시 전체 목록 누락 문제 해결, cron 재실행 덮어쓰기 방지, strip_cjk() 한자 제거 버그 수정 |
| 2026-05-18 | 브라우저 프로필 초기화 + Gmail.com 계정 필요 clarified; auth-debug reference updated |
| 2026-05-19 | On-Demand 업로드 완전한 4단계 절차 추가 (이미 생성된 영상의 업로드 경로) |
| 2026-06-01 | selection.json topics 배열 수동 생성 금지 — 크론 출력 번호 ≠ Notion DB 순서, 수동 재작성 시 URL=null로 TypeError 발생. `selection_numbers`만 수정할 것 |
| 2026-06-02 | **호칭 통일 (`主人님` → `주인님`) + Cron/스킬 본문 한자 잔존 정리**, Ad-hoc 토픽 추가 절차 신설 (Gold #10 — prepare.py 멱등성 확정) |
| 2026-06-02 (오후) | **에이전트 정체성 변경 (이름: 혜린, 성별: 여성, 듀얼 호칭 모드)**, `주인님` 폐지 → `희정님`/`오빠` 도입 |
| 2026-06-02 (저녁) | **`--review` 출처 표시 함정 pitfall 추가** — description은 GeekNews URL 사용 (정상), `sources[]`는 참고용 메타데이터 — 두 출처가 다르게 보여도 description만 검증하면 됨 |
| 2026-06-04 | **업로드 후 노트북 자동 삭제 함정 발견** (`76716a40` 사라짐) — `notebooklm_upload.py` cleanup 단계가 `notebooklm delete`로 노트북까지 정리. 같은 주제 재업로드 시 새 ID로 재생성 필요. 상세: `references/post-upload-notebook-lifecycle.md` |
| 2026-06-04 | **해외 출처 정책 사전 체크 강화** — Gemma 4 같은 Google 공식 블로그 출처는 검토 시점에 자동 경고 필요. 상세: `references/source-policy-pre-check.md` |
| 2026-06-04 | **YouTube OAuth 재발급 절차 문서화 + 재사용 스크립트 추가** — refresh_token 자동 갱신 시도 → 실패 시 풀 OAuth. `youtube.upload` → `youtube` 전체 스코프 업그레이드 시 같은 절차. 상세: `references/youtube-oauth-reauth.md`, `scripts/youtube_reauth.py` |
| 2026-06-04 | **f-string 마스킹 함정 (Bearer 외)** — `write_file`/f-string에 secret/토큰 직접 삽입 시 `***` 마스킹이 문자열을 깨뜨려 SyntaxError. `os.path.expanduser` + 문자열 연결, 또는 `write_file`로 외부 파일 작성 후 실행 패턴 사용 |
| 2026-06-05 | **`selection.json` `selected` 배열 stale 함정** — 사후 토픽 추가 시 `selected.append()` 하면 이전 토픽까지 같이 처리되어 **불필요한 노트북 재생성**. `d["selected"] = [d["topics"][-1]]` (REPLACE) 필수. 멱등성 #10은 cleanup #11이 노트북을 삭제하므로 깨짐. 상세: `references/selection-json-stale-selected-pitfall-2026-06-05.md` |
| 2026-06-06 | **venv 인터프리터 호출은 절대 경로로 (3개 호출부 모두 패치)** — `cd ~/.hermes && ./venv-notebooklm/bin/python3 ...` 패턴은 `cd` 대상 오타 시 `bash: ./venv-notebooklm/bin/python3: No such file or directory` (exit 127) + `.bash_profile`의 rbenv init / `.openclaw/completions/openclaw.bash: No such file or directory` 노이즈가 섞여 root cause 식별이 어렵다. `/Users/hjshin/.hermes/venv-notebooklm/bin/python3` + 절대 스크립트 경로 사용. 경로 B, OAuth 재업로드, python3 버전 섹션 모두 동일 패턴. |
| 2026-06-12 | **`notebooklm download video --all`은 마지막 `use`된 노트북 1개만 받음 (금기 #18)** — `--all`은 "현재 선택된 노트북의 모든 비디오 아티팩트" 의미이지 "모든 노트북의 모든 비디오"가 아님. 부분 업로드(4개 노트북 각각) 시 `for nb in $NB1 $NB6 ...; do notebooklm use $nb && notebooklm download video --all /tmp/.../videos/ --force; done` 패턴 필수. ls로 파일 수 확인 안 하면 1개만 받았는데 4개 받은 줄 알고 진행하는 사고 발생. |
| 2026-06-12 | **`--review` 검토 메시지가 Telegram 미설정 시 silent fail (금기 #19)** — Telegram bot token이 placeholder(`PLACEHOLDER_TOKEN_REPLACE_WITH_REAL`)이거나 미설정된 환경에서 `--review`가 `send_telegram()` 호출 후 silent fail. stdout에는 "검토 요청 전송 완료"만 찍히고 사용자에게 검토 내용 안 도달. 해결: `read_file /Users/hjshin/.hermes/memory/upload_review.json` 으로 직접 읽어 사용자에게 표시. Telegram 환경 의존 fallback 경로. |
| 20. **업로드 명령 수신 시 사전 체크 단계 누락 (2026-06-15 추가)** — 사용자가 "업로드"라고 하면 `--review`부터 실행하지 말고 selection.json 상태 + 영상 파일 존재 + NotebookLM artifact status 3가지를 먼저 확인. 사후 발견되면 자원 낭비 큼. 3단계 "업로드 명령 수신 시 사전 체크" 섹션 신설. GLM 5.2 세션에서 사전 체크 → 한 번에 통과 검증. |
| 21. **Homebrew python@3.13 사라짐 + venv broken interpreter (2026-06-16 추가)** — Homebrew cleanup/macOS 업그레이드/`brew upgrade` 시 `python@3.13` formula가 제거되면 `~/.hermes/venv-notebooklm/bin/python3.13` → `/usr/local/opt/python@3.13/bin/python3.13` → `/usr/local/Cellar/...` 심볼릭 체인이 끊어져 `notebooklm` CLI가 `bad interpreter: No such file or directory`로 동작 안 함. `venv-notebooklm-enterprise`도 동일하게 깨짐. **복구 (5분, 2026-06-16 검증)**: `ls /usr/local/opt/ | grep python`으로 남은 버전(보통 3.12) 확인 → 해당 버전으로 venv 재생성(`python3.12 -m venv --clear .`) → `pip install "notebooklm-py[browser]"` + `playwright install chromium` → `notebooklm list --json`으로 인증(`~/.notebooklm/storage_state.json`) 살아있는지 확인. 인증은 venv와 무관하게 보존됨. 단 storage_state.json이 0바이트로 변할 수 있음 (금기 #24). |
| 22. **PyPI 패키지 이름은 `notebooklm-py` (2026-06-16 추가)** — `pip install notebooklm`은 "No matching distribution" 오류. 정확한 이름은 **`notebooklm-py`** (GitHub: teng-lin/notebooklm-py). venv 신규 설치/복구 시 반드시 `notebooklm-py`로 설치. 기존에 0.3.4 버전이 설치된 이력이 있어 최신은 0.7.1. |
| 23. **NotebookLM storage_state.json 0바이트 함정 (2026-06-16 추가)** — venv 복구 직후 list 작동 확인했음에도 `~/.notebooklm/profiles/default/storage_state.json`이 **0바이트로 텅 비는 현상**. backup(.bak.personal, .personal_backup) 복구로는 해결 안 됨 (쿠키 만료). CLI 결과는 `Authentication expired or invalid. Redirected to: https://accounts.google.com/...`. **해결: 풀 OAuth 재로그인만 가능** — Playwright 필수 (`pip install "notebooklm-py[browser]" && playwright install chromium`) + `notebooklm login` PTY background (5분 대기). 로그인 계정이 Workspace(ubob.com)여도 list/download는 작동함. **예방**: venv 복구 직후 `notebooklm list --json` + 1개 노트북 `download` 소규모 테스트로 인증 실효성 검증. 상세: `references/storage-state-recovery-2026-06-16.md`. |
| 24. **venv-notebooklm 추가 의존성 4개 함정 (2026-06-16 추가)** — `notebooklm-py`만 설치하면 `--review`/`--approved` 실행 시 import 오류. 필요 패키지: ① `requests` (`notebooklm_upload.py:24`) ② `google-api-python-client` + ③ `google-auth-oauthlib` + ④ `google-auth-httplib2` (upload.py → yt_upload.py 경유). 증상: `--review`는 `ModuleNotFoundError: No module named 'requests'`, `--approved`는 `No module named 'google'`. **복구**: `pip install requests google-api-python-client google-auth-oauthlib google-auth-httplib2` (4개 한 번에). **예방**: venv 셋업 스크립트에 4개 라인 표준화. 0.7.1 기준 4개 모두 기본 의존성에 없음. |
| 25. **YouTube 토큰 refresh는 시스템 `/usr/bin/python3` (2026-06-16 추가)** — `youtube_token.pickle` refresh는 `google.auth.transport.requests` 필요한데 venv-notebooklm엔 없음. **MEMORY user.md 대로 시스템 `/usr/bin/python3` (Python 3.9)** 으로 refresh 검증 + 토큰 갱신. FutureWarning(EOL Python 3.9)/NotOpenSSLWarning(LibreSSL 2.8.3)은 무시 가능. venv에 google-auth 추가 설치로 해결 가능하지만, 시스템 Python으로 한 줄 검증하는 게 4개 패키지 설치 대비 5초. |
| 23. **`notebooklm-py[browser]` extra + Playwright chromium 누락 (2026-06-16 저녁 추가)** — `notebooklm-py`만 설치하면 `notebooklm login`/`list`가 "Playwright not installed. Run: pip install \"notebooklm-py[browser]\" playwright install chromium" 메시지로 즉시 종료. `login`/`list`는 read-only처럼 보여도 내부적으로 Chromium을 띄워 세션 검증하므로 Playwright 의존. **복구**: `pip install "notebooklm-py[browser]"` + `playwright install chromium` (97.5MB) 둘 다 필수. |
| 24. **storage_state.json 0바이트 + 백업 만료 패턴 (2026-06-16 저녁 추가)** — venv 복구 후 `~/.notebooklm/storage_state.json`이 **0바이트 비어있는 파일**이 되는 경우가 있음 (인증 풀린 상태). `ls -la ~/.notebooklm/storage_state.json`으로 size 확인 필수. 0바이트면 풀 OAuth 재로그인 필요. **백업 위치 (만료 가능성 높음)**: `storage_state.json.bak.personal` (오래된 백업, 4월 19일 등), `storage_state.json.personal_backup` (5월 18일 등), `profiles/default/storage_state.json` (실제 사용 파일). **복구 순서**: ① 백업 복사 → list 검증 → ② 만료 시 OAuth 재로그인 (`notebooklm login`을 PTY+tee+백그라운드로 띄우고 사용자가 Chromium 창에서 로그인, 5분 timeout). **SID 도메인 검증** 필수 — `.google.com` (consumer Gmail) vs `.google.co.kr` (Google Workspace, 인증 불가). |
| 2026-06-15 | **16:00 silent-skip 비파괴 우회법 (참조: `references/cron-16-00-silent-fix-2026-05-19.md`)** — `notebooklm_selection.py`의 `existing.date == today` skip 경로는 on-demand 진행 상태가 있는 날 16:00 크론이 12개 후보를 마커 없이 silent 종료한다. 기존 `rm selection.json`은 진행 상태(GLM 5.2 같은 on-demand 선택)를 파괴하므로, `importlib.util`로 `load_topics()` + `format_selection_message()`를 직접 호출하는 **방법 B (비파괴 import)** 추가. 진행 상태 보존 + 16:00 후보 전달 동시 달성. |
| 2026-06-16 | **Homebrew python@3.13 사라짐 함정 (금기 #21)** — Homebrew cleanup/macOS 업그레이드 시 `python@3.13` formula가 제거되면 `venv-notebooklm`과 `venv-notebooklm-enterprise`의 `bin/python3.13` 심볼릭이 broken interpreter로 바뀌어 notebooklm CLI가 통째로 동작 안 함. 복구: 3.12 venv 재생성 + `pip install notebooklm-py` (인증은 `~/.notebooklm/storage_state.json`에 보존되어 재로그인 불필요, 5분 복구). |
| 2026-06-16 | **`notebooklm` vs `notebooklm-py` 패키지 이름 함정 (금기 #22)** — PyPI 패키지 이름은 `notebooklm-py` (github.com/teng-lin/notebooklm-py). `pip install notebooklm`은 "No matching distribution" 오류. venv 복구 시 반드시 `notebooklm-py`로 설치. 기존 스킬 본문에서 `notebooklm`이라고만 표기되어 있어 혼동 유발. |
| 2026-06-16 (저녁) | **`notebooklm-py[browser]` extra + Playwright chromium 누락 함정 (금기 #23)** — `notebooklm-py`만 설치하면 `notebooklm login`이 "Playwright not installed" 메시지로 즉시 종료. login/list는 Playwright 의존성이라 `pip install "notebooklm-py[browser]"` + `playwright install chromium` (97.5MB) 둘 다 필요. 기존 복구 절차 5분 레시피에서 `notebooklm-py` → `notebooklm-py[browser]`로 갱신. |
| 2026-06-16 (저녁) | **venv 복구 후 storage_state.json 0바이트 + 백업 파일 패턴 (금기 #24)** — storage_state.json이 비어있는 0바이트 파일이 되는 경우가 있음 (인증 풀린 상태). 백업 위치: `~/.notebooklm/storage_state.json.bak.personal`, `.personal_backup`, `profiles/default/storage_state.json`. 복구 순서: 백업 복사 → list 검증 → 만료 시 풀 OAuth 재로그인 (PTY + tee + 백그라운드). SID 도메인 검증으로 consumer Gmail vs Google Workspace 구분. |
