---
name: notebooklm-youtube-automation
description: NotebookLM에서 생성한 비디오 오버뷰를 YouTube에 업로드하는 워크플로우 — 사용자가 직접 선택 후 수동 요청
trigger: "notebooklm, youtube upload, video overview, automation"
---

# NotebookLM YouTube 자동화 워크플로우

## 개요

Notion DB侯選 주제 → 사용자 선택 → NotebookLM 노트북 생성 → 비디오 오버뷰 생성 → 업로드 요청 → 일반 영상 + 숏츠 동시 업로드

**N:N 정책:** 비디오 오버뷰 N개 → 일반 영상 N개 + 숏츠 N개 (총 2N개 업로드)

---

## 워크플로우 3단계

### 1단계:侯選 전송 (매일 16:00 크론)
**스크립트:** `notebooklm_selection.py`

Notion DB에서 최신侯選 주제를 로드하여 텔레그램으로 전송.
최대 12개 주제를 카테고리 순서로 정렬하여 번호 선택지로 제공.

**출력 예시:**
```
🎬 NotebookLM 비디오 주제 선택

오늘의候選 주제 (8개) — 번호를 입력해주세요:
1. 🤖 Garry Tan's "Skillify" — AI 에이전트의 실패...
2. 💡 GoScrapy - Go기반 초고속 웹 스크래핑...
3. 🛠️ Show GN: purplemux – Claude Code 세션...
...
💡 Tip: 쉼표로 여러 개 선택 가능 (예: 1,3,5,7)
```

**저장:** `~/.hermes/memory/notebooklm_selection.json`

---

### 2단계: 노트북 생성 (사용자 번호 선택 후)
**스크립트:** `notebooklm_prepare.py`

사용자가 선택한 번호(예: `1,3,5`)를 읽고:
1. 각 주제에 맞는 소스를 동적으로 수집 (GitHub API, HackerNews, ProductHunt)
2. NotebookLM 노트북 생성
3. 노트북에 소스 추가

```bash
# 사용자가 Telegram에서 "1,3,5" 입력 시
# 에이전트가 실행:
python3 ~/.hermes/scripts/notebooklm_prepare.py
```

**소스 수집 규칙:**
| 카테고리 | 소스 |
|---------|------|
| AI/ML | GitHub API (키워드 검색) + HackerNews |
| 개발도구 | GitHub API + ProductHunt |
| 개발팁 | HackerNews + Reddit |

---

### 3단계: 업로드 (사용자가 "업로드"라고 요청)
**스크립트:** `notebooklm_upload.py`

주인님이 NotebookLM에서 비디오 오버뷰를 모두 생성한 후 "업로드"라고 알려주시면:

1. 각 노트북에서 비디오 오버뷰 다운로드
2. 주제 키워드로 출처 재수집 → 설명에 출처 URL 포함
3. 일반 영상 + 숏츠 동시 업로드 (N:N)
4. 노트북 자동 정리

```bash
python3 ~/.hermes/scripts/notebooklm_upload.py
```

**출처 설명 템플릿:**
```
'[주제명]' 관련最新 소식을 다루는 영상입니다.

▼ 더보기
📚 출처
• Repo name
  https://github.com/...
• Article title
  https://...

#ICBM #AI #테크 #개발자 #인공지능
```

---

## 핵심 개선사항 (2026-04-29)

### ✅ 출처 상세记载
이전: description에 출처 없음
개선: `collect_sources_for_description()`가 GitHub/HN/ProductHunt에서 실제 URL+제목 수집 → description에 포함

### ✅ N:N 숏츠 정책
이전: 4개 일반 + 1개 숏츠
개선: N개 영상 → N개 일반 + N개 숏츠 (총 2N개)

### ✅ 동적 소스 수집
이전: 하드코딩된 URL만
개선: 주제 키워드 기반 동적 검색 → 관련성 높은 소스 우선

### ✅ 사용자 선택 방식
이전: 4개 고정 주제 자동 생성
개선: Notion DB侯選 중 번호로 직접 선택 → 주제 중복 방지

---

## 파일 구조

```
~/.hermes/
├── scripts/
│   ├── notebooklm_selection.py   #侯選 전송 (16:00)
│   ├── notebooklm_prepare.py     #노트북+소스 생성 (선택 후)
│   └── notebooklm_upload.py      #다운로드+업로드 (업로드 요청 시)
├── memory/
│   └── notebooklm_selection.json #오늘의 선택 데이터
└── secrets/
    └── notion_token.txt         #Notion API 토큰
```

## 크론 잡

| 시간 | 작업 | 상태 |
|------|------|------|
| 16:00 매일 |侯選 전송 + 선택 요청 | ✅ 유지 |
| 사용자 선택 후 | 노트북+소스 생성 | ✅ 수동 |
| "업로드" 요청 시 | YouTube 업로드 | ✅ 수동 |

**자동 크론 제거:**
- ~~00:15 YouTube 업로드~~ → 제거됨
- ~~02:15 숏츠 업로드~~ → 제거됨

## YouTube 설명 템플릿

모든 영상/숏츠 업로드 시 **출처 포함 설명** 사용.

| 구분 | 일반 영상 | 숏츠 |
|------|---------|------|
| 요약 | `[주제명] 관련最新 소식` | 동일 |
| 출처 | GitHub/HN/ProductHunt 실제 URL | 동일 |
| 해시태그 | `#ICBM #AI #테크 #개발자 #인공지능` | 동일 |

## 🚨 오류 처리

### YouTube OAuth 토큰 만료 (가장 흔한 장애)

**증상:** `invalid_grant: Token has been expired or revoked`  
**영향:** 업로드만 실패, 노트북은 이미 삭제된 상태

**복구 절차:**
1.的主人님이 직접 브라우저 인증 실행:
   ```bash
   python3 ~/.hermes/skills/creative/youtube-uploader/scripts/auth.py
   ```
   - 브라우저 열림 → Google 계정 로그인 → 권한 승인
2. 토큰 갱신 완료 후 다시 **'업로드'** 라고 요청
3. 단, 오늘의 노트북은 이미 삭제되었으므로 **'1,3,5' 등 선택 번호**를 다시 알려주시면 노트북+영상 재생성

> ⚠️ **중요:** 오늘 노트북 재생성 시 기존 소스는 gone. NotebookLM에서 새 영상 생성하면 `업로드` 재요청

### YouTube OAuth 토큰 만료 예방

`auth.py`의 `refresh_token`이 만료되면 재인증 필요.  
주인님이 한 달에 1회 정도 토큰 상태를 확인하는 걸 권장 (자주 쓰면 자연스럽게 갱신됨).

### 비디오 미생성
- 업로드 시 텔레그램 알림 → NotebookLM에서 수동 생성 후 다시 "업로드" 요청
- **삭제 금지**: 다운로드+업로드 성공한 것만 삭제

### 소스 없음
- HN/Reddit fallback 사용 → 그래도 없으면 GitHub Trending

### 노트북 없음
- 메모리 파일 확인 → `notebooklm_selection.py` 재실행 유도

### 업로드 실패 시 절대 삭제 금지
노트북 삭제(`notebooklm delete`)는 **다운로드 + 일반 영상 + 숏츠 모두 성공**했을 때만 실행.  
부분 성공 시에도 삭제하지 않고 주인님에게 상태 보고.
