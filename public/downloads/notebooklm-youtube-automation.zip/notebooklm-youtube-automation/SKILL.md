---
name: notebooklm-youtube-automation
description: NotebookLM에서 생성한 비디오 오버뷰를 YouTube에 업로드하는 워크플로우 — 사용자가 직접 선택 후 수동 요청
trigger: "notebooklm, youtube upload, video overview, automation"
---

# NotebookLM YouTube 자동화 워크플로우

## ⚠️ 스크립트 구조 (중요: 2026-05-04 기준)

**활성 스크립트 4개 (`~/.hermes/scripts/`):**
```
notebooklm_selection.py       侯選 전송 (16:00 크론)
notebooklm_prepare.py         선택 후 노트북+소스 생성
notebooklm_upload.py           On-Demand 업로드 (업로드 명령 시)
notebooklm_upload_pipeline.py  00:15 크론 업로드
```

**삭제된 스크립트 (절대 사용 금지):**
- `notebooklm_video_pw.py` — Playwright 영상 생성 (실패)
- `notebooklm_youtube_pipeline.py` — 자동 영상 생성+업로드 (중복)
- `youtube_shorts_factory.py` — 불필요
- `youtube_upload_pw.py` — 불필요
- `youtube_video_factory.py` — 불필요
- `youtube_video_factory_subagent.py` — 불필요

**runtime ↔ git repo 동기화:**
- 스크립트 수정 시: `~/.hermes/scripts/` (runtime) 에서 작업 → `~/hermes_bot/scripts/` 로 복사 후 commit+push
- hermes_bot gitignore에 `~/.hermes/` 가 포함되어 있어서 두 디렉토리는 별도로 관리됨

**노트북 수동 삭제 금지 (2026-05-04):**
- 오늘 생성된 노트북을 NotebookLM 웹에서 수동 삭제하지 말 것
- ID 유실 → `notebooklm_selection.json` 날짜 불일치 → 출처 누락 + 파이프라인 꼬임
- `/tmp/icbm_notebooklm/` 은 재부팅 시 자동 정리됨

---

## 재발방지 가드: 날짜 검증 (2026-05-04 추가)

`notebooklm_upload.py` 실행 시 선택 파일(`notebooklm_selection.json`)의 `date`가 오늘인지 확인:
- 날짜 불일치 → 즉시 중단 + 텔레그램 안내
- 순서 지키지 않았을 때 (`16:00侯選 → 선택 → prepare → 영상 생성 → 업로드`) 이 검증으로 방지

---

## 워크플로우 3단계

### 1단계:侯選 전송 (매일 16:00 크론)
**스크립트:** `notebooklm_selection.py`

Notion DB에서 최신侯選 주제를 로드하여 텔레그램으로 전송.
최대 12개 주제를 카테고리 순서로 정렬하여 번호 선택지로 제공.

**출력 예시:**
```
🎬 NotebookLM 비디오 주제 선택

오늘의候選 주제 (8개) — 번호를 입력해주세요:
1. 🤖 Garry Tan's "Skillify" — AI 에이전트의 실패...
2. 💡 GoScrapy - Go기반 초고속 웹 스크래핑...
3. 🛠️ Show GN: purplemux – Claude Code 세션...
...
💡 Tip: 쉼표로 여러 개 선택 가능 (예: 1,3,5,7)
```

**저장:** `~/.hermes/memory/notebooklm_selection.json`

---

### 2단계: 노트북 생성 (사용자 번호 선택 후)
**스크립트:** `notebooklm_prepare.py`

사용자가 선택한 번호(예: `1,3,5`)를 읽고:
1. 각 주제에 맞는 소스를 동적으로 수집 (GitHub API, HackerNews, ProductHunt)
2. NotebookLM 노트북 생성
3. 노트북에 소스 추가

```bash
# 사용자가 Telegram에서 "1,3,5" 입력 시
# 에이전트가 실행:
python3 ~/.hermes/scripts/notebooklm_prepare.py
```

**소스 수집 규칙:**
| 카테고리 | 소스 |
|---------|------|
| AI/ML | GitHub API (키워드 검색) + HackerNews |
| 개발도구 | GitHub API + ProductHunt |
| 개발팁 | HackerNews + Reddit |

---

### 3단계: 업로드 (사용자가 "업로드"라고 요청)
**스크립트:** `notebooklm_upload.py`

주인님이 NotebookLM에서 비디오 오버뷰를 모두 생성한 후 "업로드"라고 알려주시면:

1. 각 노트북에서 비디오 오버뷰 다운로드
2. 주제 키워드로 출처 재수집 → 설명에 출처 URL 포함
3. 일반 영상 + 숏츠 동시 업로드 (N:N)
4. 노트북 자동 정리

```bash
python3 ~/.hermes/scripts/notebooklm_upload.py
```

**출처 설명 템플릿:**
```
'[주제명]' 관련最新 소식을 다루는 영상입니다.

▼ 더보기
📚 출처
• Repo name
  https://github.com/...
• Article title
  https://...

#ICBM #AI #테크 #개발자 #인공지능
```

---

## NotebookLM SDK 아티팩트 제목 조회 (2026-04-30)

NotebookLM이 생성한 비디오 오버뷰의 **원본 제목**을 SDK로 조회하여 YouTube 업로드 타이틀에 사용.

**핵심 패턴 — Python venv 서브프로세스 실행:**
```python
# 시스템 Python에는 notebooklm SDK가 없음
# → venv Python으로 인라인 코드 실행
venv_python = os.path.join(VENV_BIN, "python3")  # ~/.hermes/venv-notebooklm/bin/python3
code = f"""
import asyncio
from notebooklm import NotebookLMClient, StudioContentType

async def _get():
    async with NotebookLMClient.from_storage() as client:
        artifacts = await client.artifacts.list('{notebook_id}', artifact_type=StudioContentType.VIDEO)
        for art in artifacts:
            if art.id == '{artifact_id}':
                print(art.title)
                return
        # Fallback: any completed video
        for art in artifacts:
            if art.status == 3:
                print(art.title)
                return
        print('')
asyncio.run(_get())
"""
result = subprocess.run([venv_python, "-c", code], capture_output=True, text=True, timeout=30)
title = result.stdout.strip()
```

**주요 SDK 클래스/메서드:**
- `NotebookLMClient.from_storage()` — 저장된 OAuth 토큰으로 인증
- `client.artifacts.list(notebook_id, artifact_type=StudioContentType.VIDEO)` — VIDEO 타입 아티팩트 목록
- `art.id`, `art.title`, `art.status` — 아티팩트 메타데이터 (status=3 완료)
- `StudioContentType.VIDEO.value` = 3

**YouTube 업로드 타이틀 우선순위:**
1. NotebookLM 원본 제목 (`art.title`) — 최우선
2. 폴백 타이틀 (하드코딩된 기존 타이틀)

→ 업로드 스크립트에서 항상 `upload_title = nb_title if nb_title else fallback_title` 패턴 사용

**⚠️ Python `hash()` 절대 사용 금지:**
Python의 `str(hash())`는 해시 랜덤화(보안)로 매 프로세스마다 다른 값을 반환.  
크로스 프로세스 중복 체크에는 반드시 `hashlib.md5(text.encode()).hexdigest()` 사용.

## 핵심 개선사항 (2026-04-29)

### ✅ 출처 상세记载
이전: description에 출처 없음
개선: NotebookLM 노트북에 추가된 실제 소스를 `notebooklm source list`로 조회 → 출처 URL 우선 사용. 소스가 없으면 키워드 기반 GitHub/HN/ProductHunt 검색 폴백.

### ✅ N:N 숏츠 정책
이전: 4개 일반 + 1개 숏츠
개선: N개 영상 → N개 일반 + N개 숏츠 (총 2N개)

### ✅ 동적 소스 수집
이전: 하드코딩된 URL만
개선: 주제 키워드 기반 동적 검색 → 관련성 높은 소스 우선

### ✅ 사용자 선택 방식
이전: 4개 고정 주제 자동 생성
개선: Notion DB侯選 중 번호로 직접 선택 → 주제 중복 방지

---

## 파일 구조

```
~/.hermes/
├── scripts/
│   ├── notebooklm_selection.py   #侯選 전송 (16:00)
│   ├── notebooklm_prepare.py     #노트북+소스 생성 (선택 후)
│   └── notebooklm_upload.py      #다운로드+업로드 (업로드 요청 시)
├── memory/
│   └── notebooklm_selection.json #오늘의 선택 데이터
└── secrets/
    └── notion_token.txt         #Notion API 토큰
```

## 크론 잡

| 시간 | 작업 | 상태 |
|------|------|------|
| 16:00 매일 |侯選 전송 + 선택 요청 | ✅ 유지 |
| 사용자 선택 후 | 노트북+소스 생성 | ✅ 수동 |
| "업로드" 요청 시 | YouTube 업로드 | ✅ 수동 |

**자동 크론 제거:**
- ~~00:15 YouTube 업로드~~ → 제거됨
- ~~02:15 숏츠 업로드~~ → 제거됨

## 🎬 기존 노트북 → YouTube 업로드 (On-Demand)

> **단일 영상**만 있는 경우 위 단일 영상 가이드를 사용.

**다중 영상 일괄 업로드 (배치):**
1. `notebooklm artifact list -n <notebook_id> --type video` → 완료된 비디오 artifact 확인
2. `notebooklm download video -n <notebook_id> <path>` → 각 노트북별 다운로드
3. `ffprobe`로 길이 체크 → 60초 이하 = Shorts, 이상 = 일반영상
4. 일반영상: `upload.py`로 동시 백그라운드 업로드 (privacy: unlisted)
5. Shorts: `ffmpeg 9:16 변환` 후 동일하게 업로드

**핵심 인사이트 (2026-04-30, updated 2026-05-04):**
- `notebook_info.json` (`/tmp/icbm_notebooklm/notebook_info.json`)에 오늘 생성된 노트북 ID+제목+content_type 저장됨 → 업로드 파이프라인이 이 파일을 참조한다
- `notebooklm_upload_pipeline.py` 실행 전 반드시 이 파일이 존재해야 한다 — 수동 생성 노트북의 경우 수동으로 생성할 것
- 6개 동시에 백그라운드 업로드 시 PID 추적 → 30초 후 로그로 성공/실패 확인
- `ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 <file>`로 길이 체크

## ✅ 올바른 FFmpeg 9:16 숏츠 필터 — Black Letterbox (2026-05-04)

**⚠️ Blur Letterbox 사용 금지** — 복잡한 `split+boxblur+overlay` 필터 체인이 FFmpeg 4.3(macOS)에서 ultrawide(21:9) 입력 시 실패. 반드시 **Black Letterbox** 사용.

**권장 필터 (`notebooklm_upload.py` 현재 방식):**
```bash
ffmpeg -y -i input.mp4 -t 60 \
  -filter_complex "
    [0:v]scale=1080:-2:force_original_aspect_ratio=decrease,setsar=1,
    pad=iw:ih+256:0:-128:black,
    scale=1080:1920,setsar=1[out];
    [0:a]atrim=0:60,afade=t=out:st=57:d=3[aout]
  " \
  -map "[out]" -map "[aout]" \
  -c:v libx264 -preset ultrafast -crf 26 \
  -c:a aac -b:a 128k \
  -pix_fmt yuv420p -movflags +faststart \
  output_9x16.mp4
```

**원리:**
1. `scale=1080:-2` — 너비를 **2의 배수**로強制 (ultrawide 21:9도 안전). `-2` 핵심.
2. `pad=iw:ih+256:0:-128:black` — 세로 방향 검은 패드 추가 (256px, 위아래 128px씩)
3. `scale=1080:1920` — 최종 9:16 고정 해상도

**FFmpeg 4.3 boxblur 주의:** `boxblur=lr:lp` 형태만 지원. `cr=`, `cs=`, `cp=` 옵션 없음 → 에러 발생.

```bash
ffmpeg -y -i input.mp4 -t 60 \
  -filter_complex "
    [0:v]scale=1080:-1:force_original_aspect_ratio=decrease,setsar=1,
    split[main][bg];
    [bg]scale=1080:1920:force_original_aspect_ratio=increase,
    boxblur=20:5,
    format=yuv420p[bgBlurred];
    [bgBlurred][main]overlay=(W-w)/2:(H-h)/2[out];
    [0:a]atrim=0:60,afade=t=out:st=57:d=3[aout]
  " \
  -map "[out]" -map "[aout]" \
  -c:v libx264 -preset ultrafast -crf 26 \
  -c:a aac -b:a 128k \
  -pix_fmt yuv420p -movflags +faststart \
  output_9x16.mp4
```

**원리:**
1. `split[main][bg]` — 원본 영상 복사 (main=sharp용, bg=배경용)
2. `[bg]scale=1080:1920:force_original_aspect_ratio=increase` — 배경용 복사 → 9:16 전체 프레임으로 리스케일
3. `boxblur=20:5` — 강 블러로 패딩 배경 생성 (FFmpeg 4.3: `lr:lp` 형태, `cr/cs/cp` 옵션 없음)
4. `[bgBlurred][main]overlay=(W-w)/2:(H-h)/2` — 블러 배경 위에 sharp 영상 中央 배치
5. `[out]` — overlay 출력 라벨 명시 (없으면 `-map "[out]"` 실패)
6. `-map "[aout]"` — 오디오도 명시적으로 매핑

**FFmpeg 4.3 boxblur 주의:** `boxblur=lr:lp` 형태만 지원. `cr=`, `cs=`, `cp=` 옵션 없음 → 에러 발생.

**단일 영상 파이프라인 (Shorts 변환):**
```bash
# 1. 노트북 접근
source ~/.hermes/venv-notebooklm/bin/activate
notebooklm use <notebook_id>

# 2. 비디오 다운로드
notebooklm download video --artifact <artifact_id> --force /tmp/video.mp4

# 3. ffprobe로 정보 확인
ffprobe -v error -show_entries stream=width,height,duration -of json /tmp/video.mp4

# 4. 숏츠 생성 (60초, 9:16) — Blur Letterbox ⭐
ffmpeg -y -i /tmp/video.mp4 -t 60 \
  -filter_complex "
    [0:v]scale=1080:-1:force_original_aspect_ratio=decrease,setsar=1,
    split[main][bg];
    [bg]scale=1080:1920:force_original_aspect_ratio=increase,
    boxblur=20:5,
    format=yuv420p[bgBlurred];
    [bgBlurred][main]overlay=(W-w)/2:(H-h)/2[out];
    [0:a]atrim=0:60,afade=t=out:st=57:d=3[aout]
  " \
  -map "[out]" -map "[aout]" \
  -c:v libx264 -preset ultrafast -crf 26 \
  -c:a aac -b:a 128k \
  -pix_fmt yuv420p -movflags +faststart \
  /tmp/shorts.mp4
```

### pipeline_shorts shorts_type 버그 fix (2026-04-30)

`notebooklm_youtube_pipeline.py`의 `pipeline_shorts` 함수에서:
```python
# ❌ 버그
description = build_youtube_description(shorts_type, data, ...)
# ✅ 수정
description = build_youtube_description(content_type, data, ...)
```
`content_type`이 함수 인자이고 `shorts_type`은 정의되지 않은 변수.

### Batch On-Demand 완전한 워크플로우 (2026-04-30)

```python
# 1. notebook_ids.json에서 오늘 생성된 노트북 ID 로드
import json
with open("/tmp/icbm_notebooklm/notebook_ids.json") as f:
    data = json.load(f)
notebooks = data["notebooks"]  # [{"id", "title", "topic": {"name","url"}}]

# 2. 모든 노트북에서 비디오 다운로드 (병렬)
import subprocess, os
os.makedirs("/tmp/icbm_notebooklm", exist_ok=True)
for nb in notebooks:
    nb_id = nb["id"]
    out = f"/tmp/icbm_notebooklm/raw_{nb_id[:8]}.mp4"
    subprocess.Popen([
        "bash", "-c",
        f"source ~/.hermes/venv-notebooklm/bin/activate && "
        f"notebooklm download video -n {nb_id} {out} --force"
    ])

# 3. 6개 동시에 백그라운드 업로드
upload_script = "~/.hermes/skills/creative/youtube-uploader/scripts/upload.py"
for nb in notebooks:
    vid = nb["id"][:8]
    subprocess.Popen([
        "python3", upload_script,
        f"/tmp/icbm_notebooklm/raw_{vid}.mp4",
        "--title", f"ICBM | {nb['topic']['name']}",
        "--description", DESC_BASE,
        "--privacy", "public",  # shorts는 public만 가능
        "--category", "22",
        "--tags", "ICBM", "AI", "테크", "개발자", "인공지능"
    ])

# 4. 30초 후 로그로 성공/실패 확인
import time; time.sleep(30)
for vid in [...]:
    with open(f"/tmp/icbm_notebooklm/upload_{vid}.log") as f:
        print(f.read())  # "✅ Upload successful! URL: ..." 확인
```

모든 영상/숏츠 업로드 시 **출처 포함 설명** 사용.

> **단일 영상**만 있는 경우 위 단일 영상 가이드를 사용.

**다중 영상 일괄 업로드 (배치):**
1. `notebooklm artifact list -n <notebook_id> --type video` → 완료된 비디오artifact 확인
2. `notebooklm download video -n <notebook_id> <path>` → 각 노트북별 다운로드
3. `ffprobe`로 길이 체크 → 60초 이하 = Shorts, 이상 = 일반영상
4. 일반영상: `upload.py`로 동시 백그라운드 업로드 (privacy: unlisted)
5. Shorts: `ffmpeg 9:16 변환` 후 동일하게 업로드

**핵심 인사이트 (2026-04-30, updated 2026-05-04):**
- `notebook_info.json` (`/tmp/icbm_notebooklm/notebook_info.json`)에 오늘 생성된 노트북 ID+제목+content_type 저장됨 → 업로드 파이프라인이 이 파일을 참조한다
- `notebooklm_upload_pipeline.py` 실행 전 반드시 이 파일이 존재해야 한다 — 수동 생성 노트북의 경우 수동으로 생성할 것
- 6개 동시에 백그라운드 업로드 시 PID 추적 → 30초 후 로그로 성공/실패 확인
- `ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 <file>`로 길이 체크

사용자가 NotebookLM에서 **이미 비디오 오버뷰를 생성**한 후 "이것 YouTube에 올려줘"라고 URL만 알려줄 때.

**절대 Playwright 사용 금지** — 네트워크 캡처/요소 탐색이 불안정함.
**CLI 방식만 사용.**

```bash
# 1. 노트북 접근
source ~/.hermes/venv-notebooklm/bin/activate
notebooklm use <notebook_id>

# 2. 비디오 다운로드 (--artifact로 부분 ID 매칭, --force 필수)
notebooklm download video --artifact <artifact_id> --force /tmp/video.mp4
# 출력 예: "Video saved to: /tmp/video.mp4"

# 3. ffprobe로 정보 확인
ffprobe -v error -show_entries stream=width,height,duration -of json /tmp/video.mp4

# 4. 숏츠 생성 (60초, 9:16) — Blur Letterbox ⭐
ffmpeg -y -i /tmp/video.mp4 -t 60 \
  -filter_complex "
    [0:v]scale=1080:-1:force_original_aspect_ratio=decrease,setsar=1,
    split[main][bg];
    [bg]scale=1080:1920:force_original_aspect_ratio=increase,
    boxblur=20:5,
    format=yuv420p[bgBlurred];
    [bgBlurred][main]overlay=(W-w)/2:(H-h)/2[out];
    [0:a]atrim=0:60,afade=t=out:st=57:d=3[aout]
  " \
  -map "[out]" -map "[aout]" \
  -c:v libx264 -preset ultrafast -crf 26 \
  -c:a aac -b:a 128k \
  -pix_fmt yuv420p -movflags +faststart \
  /tmp/shorts.mp4

# 5. YouTube 업로드 (OAuth API)
~/.hermes/hermes-agent/venv/bin/python3 << 'PYEOF'
import os, pickle
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

TOKEN = os.path.expanduser("~/.hermes/secrets/youtube_token.pickle")
with open(TOKEN, 'rb') as f:
    creds = pickle.load(f)
if creds.expired:
    creds.refresh(Request())
    with open(TOKEN, 'wb') as f:
        pickle.dump(creds, f)

youtube = build('youtube', 'v3', credentials=creds)
youtube.videos().insert(
    part='snippet,status',
    body={
        'snippet': {
            'title': '영상 제목',
            'description': '설명\n\n#해시태그',
            'categoryId': '28',
        },
        'status': {'privacyStatus': 'public'}
    },
    media_body=MediaFileUpload("/tmp/video.mp4")
).execute()
PYEOF
```

**핵심 교훈 (2026-04-30):**
- Playwright 네트워크 캡처로 비디오 URL 탐지 → 실패 (blob URL, iframe 등 복잡)
- CLI `notebooklm download video` → 완벽 작동
- **항상 CLI 우선**

모든 영상/숏츠 업로드 시 **출처 포함 설명** 사용.

| 구분 | 일반 영상 | 숏츠 |
|------|---------|------|
| 요약 | `[주제명] 관련最新 소식` | 동일 |
| 출처 | GitHub/HN/ProductHunt 실제 URL | 동일 |
| 해시태그 | `#ICBM #AI #테크 #개발자 #인공지능` | 동일 |

### 크론 워크플로우 우회 시 — `notebook_info.json` 수동 생성 (2026-05-04)

**발생 상황:** `notebooklm_prepare.py`를 통하지 않고 수동으로 노트북을 생성한 경우, `notebooklm_upload_pipeline.py`가 필요로 하는 `/tmp/icbm_notebooklm/notebook_info.json`이 존재하지 않아 업로드 파이프라인이 바로 실패한다.

**작업 흐름:**
```
16:00 크론 →侯選 전송 → 사용자가 번호 선택
    ↓
[표준] notebooklm_prepare.py 실행 → notebook_info.json 자동 생성 ✅
[우회] 수동 notebooklm create → notebook_info.json 없음 ❌
```

**수동 생성 workaround:**
```bash
mkdir -p /tmp/icbm_notebooklm
cat > /tmp/icbm_notebooklm/notebook_info.json << 'EOF'
[
  {
    "notebook_id": "<생성된-노트북-ID>",
    "title": "<주제명>",
    "content_type": "daily_tech"
  }
]
EOF
python3 ~/.hermes/scripts/notebooklm_upload_pipeline.py
```

**content_type 옵션:** `ai_news`, `github_trending`, `daily_tech`, `ai_deep_review`

**핵심 인사이트:** `notebooklm_upload_pipeline.py`는 `notebooklm_prepare.py`가 만든 `notebook_info.json`의 존재를 전제한다. 우회로 노트북을 생성했다면 이 파일을 반드시 수동으로 만들어야 한다.

## 🚨 오류 처리

#### video_title UnboundLocalError 버그 fix (2026-05-01)
NotebookLM SDK로 아티팩트 제목 조회 실패 시 → 자체 생성 로직 `else` 브랜치 부재로 UnboundLocalError 발생.

```python
# ❌ 버그: else 브랜치 없음 → if len(video_title)에서 UnboundLocalError
if nb_video_title:
    video_title = make_sentence_title(...)
    log(f"  🎬 NotebookLM 제목: {nb_video_title}")
if len(video_title) > 90:  # ← 여기서 CRASH

# ✅ 수정: else 브랜치 필수
if nb_video_title:
    video_title = make_sentence_title(...)
    log(f"  🎬 NotebookLM 제목: {nb_video_title}")
else:
    video_title = make_sentence_title(clean_topic_name(clean_topic), category)
    log(f"  🎬 자체 제목: {video_title}")
if len(video_title) > 90:
```

#### pending_cleanup: 재발방지 — 모든 처리 완료 후까지 파일/노트북 보존 (2026-05-01)
**핵심 교훈:** topic마다 바로 삭제하면 — FFmpeg 에러, YouTube API 에러 등 중간 장애 시 복구 불가.

```python
pending_cleanup = []  # [(nb_id, video_path, topic_name), ...]

for i, topic in enumerate(selected, 1):
    # ... 다운로드, 업로드 처리 ...
    pending_cleanup.append((nb_id, video_path, topic_name))  # 삭제하지 않음!

# 모든 topic 처리 완료 후 → 성공분만 선택적 삭제
for nb_id, video_path, topic_name in pending_cleanup:
    has_general_fail = any(
        topic_name in e and "일반 영상" in e for e in all_errors
    )
    if has_general_fail:
        log(f"  ✅ 보존 (일반 영상 실패): {topic_name[:40]}")
    else:
        subprocess.run(f"echo y | {NOTEBOOKLM} delete --notebook {nb_id}", ...)
        os.remove(video_path)
```

**삭제 규칙:**

| 상태 | 노트북 | 영상 파일 |
|------|--------|---------|
| 일반 영상 업로드 성공 | 삭제 | 삭제 |
| 일반 영상 업로드 실패 | 보존 🔒 | 보존 🔒 |
| 숏츠만 실패 | 보존 (일반 영상은 이미 YT에) | 일반 영상만 삭제 |

### YouTube OAuth 토큰 만료 (가장 흔한 장애)

**증상:** `invalid_grant: Token has been expired or revoked`  
**영향:** 업로드만 실패, 노트북은 이미 삭제된 상태

**복구 절차:**
1.的主人님이 직접 브라우저 인증 실행:
   ```bash
   python3 ~/.hermes/skills/creative/youtube-uploader/scripts/auth.py
   ```
   - 브라우저 열림 → Google 계정 로그인 → 권한 승인
2. 토큰 갱신 완료 후 다시 **'업로드'** 라고 요청
3. 단, 오늘의 노트북은 이미 삭제되었으므로 **'1,3,5' 등 선택 번호**를 다시 알려주시면 노트북+영상 재생성

> ⚠️ **중요:** 오늘 노트북 재생성 시 기존 소스는 gone. NotebookLM에서 새 영상 생성하면 `업로드` 재요청

### YouTube OAuth 토큰 만료 예방

`auth.py`의 `refresh_token`이 만료되면 재인증 필요.  
주인님이 한 달에 1회 정도 토큰 상태를 확인하는 걸 권장 (자주 쓰면 자연스럽게 갱신됨).

### 비디오 미생성
- 업로드 시 텔레그램 알림 → NotebookLM에서 수동 생성 후 다시 "업로드" 요청
- **삭제 금지**: 다운로드+업로드 성공한 것만 삭제

### 소스 없음
- HN/Reddit fallback 사용 → 그래도 없으면 GitHub Trending

### 노트북 없음
- 메모리 파일 확인 → `notebooklm_selection.py` 재실행 유도

### 업로드 실패 시 절대 삭제 금지
노트북 삭제(`notebooklm delete`)와 영상 파일 삭제는 **모든 topic의 일반 영상 처리 완료 후까지 절대 실행하지 말 것.** `pending_cleanup` 패턴을 사용할 것.
