---
name: notebooklm-youtube-automation
description: NotebookLM 에서 생성한 비디오 오버뷰를 자동으로 YouTube 에 업로드하는 워크플로우
trigger: "notebooklm, youtube upload, video overview, automation"
---

# NotebookLM YouTube 자동화 워크플로우

## 목적
NotebookLM 에서 생성한 비디오 오버뷰를 자동으로 YouTube 에 업로드하는 워크플로우.

## 워크플로우 개요
1. **준비 (16:00):** ICBM2 가 NotebookLM 에 4 개 노트북 생성 + 소스 추가
2. **생성 (주인님):** 주인님이 NotebookLM 에서 비디오 오버뷰 생성
3. **업로드 (00:15):** ICBM2 가 다운로드 → YouTube 업로드 → 노트북 삭제

## 단계별 상세

### 1. 노트북 준비 (16:00 크론 잡)
**스크립트:** `~/.hermes/scripts/notebooklm_prepare.py`
**작업:**
- 4 개 노트북 생성:
  - 데일리 테크 브리핑
  - AI 심층 리뷰
  - AI 뉴스
  - GitHub 트렌딩
- 각 노트북에 소스 4 개 추가 (웹 스크래핑 또는 RSS 기반)
- 노트북 ID 를 `~/.hermes/data/notebooklm_ids.json` 에 저장

**명령어:**
```bash
python3 ~/.hermes/scripts/notebooklm_prepare.py
```

### 2. 주인님 생성 (수동)
**작업:**
- NotebookLM 접속 (`https://notebooklm.google.com`)
- 각 노트북에서 **비디오 오버뷰** 생성 클릭
- 생성 완료 대기 (보통 5-15 분)

**체크리스트:**
- [ ] 데일리 테크 브리핑 - 비디오 오버뷰 생성 완료
- [ ] AI 심층 리뷰 - 비디오 오버뷰 생성 완료
- [ ] AI 뉴스 - 비디오 오버뷰 생성 완료
- [ ] GitHub 트렌딩 - 비디오 오버뷰 생성 완료

### 3. YouTube 업로드 (00:15 크론 잡)
**스크립트:** `~/.hermes/scripts/notebooklm_upload.py`
**작업:**
- 저장된 노트북 ID 로 비디오 오버뷰 다운로드
- AI 뉴스 또는 GitHub 트렌딩 중 하나를 선택하여 숏츠로 편집 (60 초 이하)
- YouTube 에 업로드:
  - 일반 영상 4 개 (데일리 테크, AI 심층 리뷰, AI 뉴스, GitHub 트렌딩)
  - 숏츠 1 개 (AI 뉴스 또는 GitHub 트렌딩 하이라이트)
- 업로드 완료 후 노트북 자동 삭제

**명령어:**
```bash
python3 ~/.hermes/scripts/notebooklm_upload.py
```

## 파일 구조
```
~/.hermes/
├── scripts/
│   ├── notebooklm_prepare.py   # 노트북 생성 + 소스 추가
│   └── notebooklm_upload.py    # 다운로드 + 업로드 + 삭제
├── data/
│   └── notebooklm_ids.json     # 노트북 ID 저장
└── secrets/
    └── youtube_token.pickle    # YouTube OAuth 토큰
```

## 오류 처리 및 개선 사항 (2026-04-26)

### ✅ 동적 ID 조회 (주요 개선)
- **문제**: `notebook_ids.json` 의 정적 ID 가 만료/변경되어 다운로드 실패
- **해결**: 업로드 전 `notebooklm list --json`으로 최신 ID 실시간 검색 (제목 키워드 매칭)
- **효과**: ID 변경 문제 자동 해결

### ✅ 상태 검증
- **문제**: 비디오 생성 안됨에도 다운로드 시도 → 실패
- **해결**: `notebooklm download video --dry-run`으로 생성 완료 확인 후 다운로드
- **효과**: 불필요한 시도 방지, 명확한 오류 메시지

### ✅ 자동 복구 로직
- **문제**: 다운로드 실패 시 즉시 중단
- **해결**: 2 단계 재시도 전략
  1. `--notebook` 옵션으로 직접 다운로드 시도
  2. `notebooklm use` 후 다운로드 시도
- **효과**: 일시적 오류 자동 복구

### ✅ 안전 삭제
- **문제**: 실패한 노트북도 삭제되어 복구 불가
- **해결**: 업로드 성공한 노트북만 삭제, 실패 건은 유지
- **효과**: 수동 복구 가능

### 📢 알림 시스템
- **비디오 오버뷰 미생성**: 스크립트가 다운로드 실패 시 주인님께 텔레그램 알림 전송 (노트북 URL + 생성 프롬프트 포함)
- **YouTube 인증 만료**: `python3 /tmp/youtube_auth_manual.py` 실행하여 수동 인증
- **노트북 없음**: `notebooklm_prepare.py` 재실행 요청

## YouTube 설명 템플릿 표준 (▼ 더보기 + 📚 출처)

모든 YouTube 업로드 시 **일관된 설명 템플릿**을 사용합니다 (`notebooklm_youtube_pipeline.py`에 `build_youtube_description()` 함수로 구현).

### 템플릿 형식

```
{요약 텍스트}

▼ 더보기
📚 출처
• 제목...
  https://url...

#ICBM #AI #테크 #개발자 #인공지능
```

| 구분 | 일반 영상 | 숏츠 |
|------|---------|------|
| 요약 텍스트 | "오늘의 핵심 테크/AI 뉴스를 빠르게 정리해드립니다." | "AI/개발 트렌드를 60초에 담았습니다. 🔥" |
| 출처 | `collect_*()` 함수에서 수집된 URL 목록 | 동일 |

## 주의사항
- **비디오 오버뷰만**: 팟캐스트 미사용 (NotebookLM Video Overview만 사용)
- **자동 삭제**: 업로드 완료 후 노트북은 자동 삭제되어 공간 확보
- **숏츠 선택**: AI 뉴스와 GitHub 트렌딩 중 하나를 자동 선택 (매일 교차 또는 랜덤)
- **ID 관리**: 정적 ID 파일 불필요, 실시간 검색 사용 (2026-04-26 개선)
- **오류 복구**: 다운로드 실패 시 자동 2단계 재시도, 실패 시 텔레그램 알림

## 크론 잡 설정
```bash
# 노트북 준비 (매일 16:00)
0 16 * * * cd ~/.hermes && python3 scripts/notebooklm_prepare.py >> logs/notebooklm_prepare.log 2>&1

# YouTube 업로드 (매일 00:15)
15 0 * * * cd ~/.hermes && python3 scripts/notebooklm_upload.py >> logs/notebooklm_upload.log 2>&1
```