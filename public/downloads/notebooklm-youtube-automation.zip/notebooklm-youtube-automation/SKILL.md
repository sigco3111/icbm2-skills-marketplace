# NotebookLM YouTube 자동화 — 핵심 워크플로우 (개요)

> ℹ️ **이 스킬 본문은 워크플로우 개요/단계별 명령**만 담고, **실전 함정/메모리 노트 일치 검증은 [`references/pitfalls.md`](references/pitfalls.md)에 분리** (2026-07-16 세션 회고에서 추가).

## 4단계

| 단계 | 시점 | 스크립트 | 산출물 |
|------|------|----------|--------|
| 1. 후보 전송 | 매일 16:00 크론 | `notebooklm_selection.py` | Telegram → `selection.json` |
| 2. 노트북 생성 | 사용자 번호 선택 | `notebooklm_prepare.py --skip-telegram --auto` | 4개 노트북 + 소스 |
| 3. 검토 | 사용자 "업로드" | `notebooklm_upload.py --review` | `upload_review.json` |
| 4. 업로드 | 사용자 "확인" | `notebooklm_upload.py --approved` | YouTube 일반 + Shorts |

> ⚠️ **절대 바로 `--approved` 금지** — 반드시 `--review` → 검토 → 확정.

## 빠른 명령

```bash
# 1) 후보 패치 (사용자 "1, 3, 4, 10" → patch selection.json)
patch ~/.hermes/memory/notebooklm_selection.json \
  -d '{"selection_numbers": [1, 3, 4, 10]}'

# 2) 노트북 생성
bash -c "source ~/.hermes/venv-notebooklm/bin/activate && \
  python3 ~/.hermes/scripts/notebooklm_prepare.py --skip-telegram --auto"

# 3) 검토
bash -c "source ~/.hermes/venv-notebooklm/bin/activate && \
  python3 ~/.hermes/scripts/notebooklm_upload.py --review"

# 4) 업로드 (사용자 "확인" 후)
bash -c "source ~/.hermes/venv-notebooklm/bin/activate && \
  python3 ~/.hermes/scripts/notebooklm_upload.py --approved"
```

## 산출물 위치

- 후보: `~/.hermes/memory/notebooklm_selection.json`
- 검토: `~/.hermes/memory/upload_review.json`
- 비디오 일시 저장: `/tmp/icbm_notebooklm/`

## 참조

- [`references/pitfalls.md`](references/pitfalls.md) — 6가지 실전 함정 + 메모리 노트 검증 표 + 세션 흐름 예시
