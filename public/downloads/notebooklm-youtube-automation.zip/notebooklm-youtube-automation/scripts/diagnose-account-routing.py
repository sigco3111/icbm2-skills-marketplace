"""Account-Routing Mismatch 진단 — authuser probe (재사용 가능).

이 PC의 cookie jar에 몇 개의 Google 계정이 signed-in 되어 있는지,
어떤 authuser index에 어떤 이메일이 매핑되어 있는지 probe.

Usage:
    python3 diagnose-account-routing.py

Output 예시 (단일 Workspace 계정 — 2026-07-15 이 PC 실측):
    Cookie jar: 26 cookies
      authuser=0: hjshin@ubob.com
      authuser=1: hjshin@ubob.com
      authuser=2: hjshin@ubob.com
      ...
      authuser=9: hjshin@ubob.com

    진단: 단일 Workspace 계정만 signed-in (authuser=0~9 모두 동일).
    → list의 다른 Gmail 계정 노트북은 이 PC에서 접근 불가.
    → 옵션 A (풀 OAuth 재로그인) / B (웹 UI 수동 다운로드) / C (skip) 선택.

Output 예시 (멀티 계정):
    Cookie jar: 47 cookies
      authuser=0: primary@gmail.com
      authuser=1: work@company.com   ← 노트북 소유자가 여기를 쓸 수 있음
      authuser=2: secondary@gmail.com

    진단: 3개 Google 계정 signed-in. 노트북 소유자에 따라
    storage_state.json 의 account.authuser 값을 0, 1, 2 중 하나로 맞춰야 함.

Related: 금기 #62, references/account-routing-mismatch-authuser-probe-2026-07-15.md
"""
import asyncio
import json
import sys
from pathlib import Path


def main():
    """Synchronous wrapper: import venv packages then run async probe."""
    # venv site-packages 자동 추가
    venv_site = Path.home() / '.hermes' / 'venv-notebooklm' / 'lib'
    candidates = list(venv_site.glob('python*/site-packages'))
    if not candidates:
        print(f"ERROR: venv-notebooklm site-packages not found under {venv_site}", file=sys.stderr)
        sys.exit(2)
    sys.path.insert(0, str(candidates[0]))

    try:
        from notebooklm._auth.account import _probe_authuser, MAX_AUTHUSER_PROBE
        from notebooklm._auth.cookies import build_httpx_cookies_from_storage
    except ImportError as e:
        print(f"ERROR: notebooklm 모듈 import 실패: {e}", file=sys.stderr)
        print(f"  sys.path: {candidates[0]}", file=sys.stderr)
        sys.exit(2)

    import httpx

    storage = Path.home() / '.notebooklm' / 'profiles' / 'default' / 'storage_state.json'
    if not storage.exists():
        print(f"ERROR: storage_state.json 없음: {storage}", file=sys.stderr)
        sys.exit(2)

    # 1단계: storage_state account 메타데이터
    try:
        data = json.loads(storage.read_text())
        acct = data.get('notebooklm', {}).get('account', {})
        print(f"[1] storage_state.json account 메타데이터:")
        print(f"    authuser: {acct.get('authuser')}")
        print(f"    email: {acct.get('email')}")
        print()
    except Exception as e:
        print(f"WARN: storage_state.json 읽기 실패: {e}", file=sys.stderr)

    # 2단계: authuser probe
    jar = build_httpx_cookies_from_storage(storage)
    print(f"[2] Cookie jar: {len(jar)} cookies")
    print(f"    authuser probe (0~{MAX_AUTHUSER_PROBE - 1}):")

    async def probe_all():
        async with httpx.AsyncClient(cookies=jar, timeout=30.0) as client:
            seen_emails = []
            last_email = None
            for n in range(MAX_AUTHUSER_PROBE):
                email = await _probe_authuser(client, n)
                if email is None:
                    print(f"    authuser={n}: <no active or past last>")
                    if n > 0:
                        break
                    continue
                if email == last_email:
                    # Stop condition: Google silently falls back to default
                    print(f"    authuser={n}: {email} (DUP — past last)")
                    break
                seen_emails.append(email)
                last_email = email
                print(f"    authuser={n}: {email}")
            return seen_emails

    seen_emails = asyncio.run(probe_all())
    print()
    unique_count = len(seen_emails)
    print(f"[3] 진단 결과:")
    if unique_count == 1:
        print(f"    ⚠️  단일 Google 계정만 signed-in ({seen_emails[0]})")
        print(f"    → list의 다른 계정 노트북은 이 PC에서 접근 불가")
        print(f"    → 옵션 A (풀 OAuth 재로그인, 5분) / B (웹 UI 수동 다운로드) / C (skip)")
    elif unique_count > 1:
        print(f"    ✅ {unique_count}개 Google 계정 signed-in:")
        for i, email in enumerate(seen_emails):
            print(f"       authuser={i}: {email}")
        print(f"    → notebooklm list --json의 노트북 소유자에 따라")
        print(f"      storage_state.json의 account.authuser를 0~{unique_count - 1} 중 매칭")
        print(f"    → 또는 옵션 A (풀 OAuth 재로그인)로 소유자 계정으로 직접 전환")
    else:
        print(f"    ❌ 어떤 authuser index에서도 활성 계정 없음 — 인증 풀림")
        print(f"    → 옵션 A 풀 OAuth 재로그인 필수")


if __name__ == '__main__':
    main()