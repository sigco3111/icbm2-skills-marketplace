#!/usr/bin/env python3
"""
NotebookLM nb_id 매핑 헬퍼 (금기 #46 해결)

`notebooklm_prepare.py` 출력 truncation + hex prefix for-loop 함정 회피.
`notebooklm list --json` 1회 호출로 전체 매핑 + topic name keyword 필터링.

Usage:
    # 1) 직접 실행 — 4개 nb_id + title 테이블 출력
    python3 resolve-notebook-ids.py

    # 2) 다른 스크립트에서 import
    from resolve_notebook_ids import resolve_nb_ids
    nb_map = resolve_nb_ids(['Anthropic', 'Fable5', '저커버그', 'Astryx'])

원칙:
    - 헥사 prefix (예: 5fc2d4c2) for-loop 매칭 금지 (UUID 충돌 가능)
    - 항상 notebooklm list --json 1회 + topic name keyword 필터링
    - 결과는 dict {topic_keyword: full_nb_id} 로 반환
"""

import json
import subprocess
import sys

VENV_PYTHON = "/Users/mac/.hermes/venv-notebooklm/bin/python3"
LIST_CMD = [VENV_PYTHON, "-m", "notebooklm", "list", "--json"]


def _fetch_all_notebooks():
    """notebooklm list --json 호출 → 모든 노트북 dict 반환"""
    out = subprocess.check_output(LIST_CMD, cwd="/Users/mac/.hermes").decode()
    return json.loads(out)["notebooks"]


def resolve_nb_ids(keywords):
    """topic name keyword 리스트로 nb_id 매핑 dict 반환

    Args:
        keywords: topic 식별 키워드 리스트 (예: ['Anthropic', 'Fable5', '저커버그', 'Astryx'])

    Returns:
        dict: {keyword: full_nb_id} — 매칭 안 된 keyword는 None

    Raises:
        ValueError: 동일 keyword가 여러 노트북에 매칭되는 모호한 경우
    """
    notebooks = _fetch_all_notebooks()
    # 최신순 정렬 (created_at 최신이 먼저 — 오늘 생성한 노트북 우선)
    notebooks.sort(key=lambda n: n.get("created_at", ""), reverse=True)

    result = {kw: None for kw in keywords}
    for nb in notebooks:
        title = nb.get("title", "")
        for kw in keywords:
            if kw in title:
                if result[kw] is not None:
                    raise ValueError(
                        f"keyword '{kw}' matches multiple notebooks:\n"
                        f"  - {result[kw]}\n"
                        f"  - {nb['id']}\n"
                        f"Use a more specific keyword."
                    )
                result[kw] = nb["id"]
    return result


def main():
    """CLI 모드 — 키워드 인자 또는 4개 기본 keyword 사용"""
    if len(sys.argv) > 1:
        keywords = sys.argv[1:]
    else:
        # 오늘 일반적으로 사용되는 4개 토픽 keyword (필요시 변경)
        keywords = ["Anthropic", "Fable5", "저커버그", "Astryx"]

    result = resolve_nb_ids(keywords)
    print("NotebookLM nb_id 매핑 결과:")
    print("=" * 60)
    for kw, nb_id in result.items():
        if nb_id:
            print(f"  {kw:<15} → {nb_id}")
        else:
            print(f"  {kw:<15} → ❌ 매칭 없음")
    print("=" * 60)

    not_found = [k for k, v in result.items() if v is None]
    if not_found:
        print(f"⚠️  {len(not_found)}개 keyword 미매칭: {not_found}")
        sys.exit(1)
    sys.exit(0)


if __name__ == "__main__":
    main()