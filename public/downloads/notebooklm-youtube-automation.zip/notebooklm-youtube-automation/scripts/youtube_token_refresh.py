"""YouTube OAuth 토큰 자동 갱신.

refresh_token으로 선제 갱신 시도 → 실패 시 PTY OAuth 플로우로 폴백.
만료된 토큰은 자동 백업. venv-notebooklm 또는 시스템 python3 어느 쪽에서나 동작.

Usage:
    python3 scripts/youtube_token_refresh.py
    # 또는
    source ~/.hermes/venv-notebooklm/bin/activate && python3 scripts/youtube_token_refresh.py

반드시 PTY로 실행할 것 (OAuth 브라우저 플로우):
    terminal(command=..., pty=true)
"""
import os
import sys
import pickle
import shutil
import glob

# --- 설정 ---
TOKEN_PATH = os.path.expanduser("~/.hermes/secrets/youtube_token.pickle")
SECRETS_DIR = os.path.expanduser("~/.hermes/secrets")
SCOPES = ["https://www.googleapis.com/auth/youtube.upload"]


def find_client_secret() -> str | None:
    matches = glob.glob(os.path.join(SECRETS_DIR, "client_secret_*.json"))
    return matches[0] if matches else None


def show_status(creds) -> None:
    print(f"   Type: {type(creds).__name__}")
    print(f"   Has refresh_token: {bool(getattr(creds, 'refresh_token', None))}")
    print(f"   Expired: {creds.expired}")
    print(f"   Valid: {creds.valid}")
    if creds.token:
        print(f"   Token (...last 10): ...{creds.token[-10:]}")


def try_refresh(creds) -> bool:
    """refresh_token으로 갱신 시도. 성공 시 True."""
    try:
        from google.auth.transport.requests import Request
        creds.refresh(Request())
        return bool(creds.valid)
    except Exception as e:
        print(f"   ❌ refresh 실패: {e}")
        return False


def oauth_full_flow(client_secret: str) -> object:
    """PTY에서 run_local_server로 전체 OAuth 플로우 실행."""
    from google_auth_oauthlib.flow import InstalledAppFlow
    flow = InstalledAppFlow.from_client_secrets_file(client_secret, SCOPES)
    creds = flow.run_local_server(port=0)
    return creds


def main() -> int:
    if not os.path.exists(TOKEN_PATH):
        print(f"❌ 토큰 파일 없음: {TOKEN_PATH}")
        print(f"   → 먼저 OAuth 인증을 1회 수동으로 진행해야 합니다.")
        return 1

    client_secret = find_client_secret()
    if not client_secret:
        print(f"❌ client_secret_*.json 없음: {SECRETS_DIR}")
        return 1

    print(f"📁 Using: {client_secret}")
    print(f"📁 Token: {TOKEN_PATH}")

    # 만료 토큰 백업 (이미 .bak 있으면 덮어쓰지 않음)
    bak_path = TOKEN_PATH + ".expired.bak"
    if not os.path.exists(bak_path):
        shutil.copy(TOKEN_PATH, bak_path)
        print(f"💾 백업 저장: {bak_path}")
    else:
        print(f"💾 기존 백업 보존: {bak_path}")

    with open(TOKEN_PATH, "rb") as f:
        creds = pickle.load(f)

    print("\n=== 현재 토큰 상태 ===")
    show_status(creds)

    # 1차 시도: refresh_token
    if creds.refresh_token and not creds.valid:
        print("\n=== refresh_token으로 갱신 시도 ===")
        if try_refresh(creds):
            with open(TOKEN_PATH, "wb") as f:
                pickle.dump(creds, f)
            print("✅ refresh_token으로 갱신 성공!")
            show_status(creds)
            return 0
        print("→ OAuth 플로우로 폴백")

    # 2차 시도: 전체 OAuth 플로우
    print("\n=== 전체 OAuth 플로우 실행 (브라우저 로그인 필요) ===")
    try:
        creds = oauth_full_flow(client_secret)
    except Exception as e:
        print(f"❌ OAuth 플로우 실패: {e}")
        return 2

    with open(TOKEN_PATH, "wb") as f:
        pickle.dump(creds, f)

    print("\n✅ 새 토큰 발급 완료")
    show_status(creds)
    print(f"   저장: {TOKEN_PATH}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
