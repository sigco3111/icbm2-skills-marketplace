#!/usr/bin/env bash
# hermes-verify-template.sh — 재사용 가능한 OS-safe ad-hoc 검증 셸 템플릿
#
# 이 템플릿은 `notebooklm-youtube-automation` 스킬의 매 turn fresh verification evidence
# 요구 (gold #40) + /var/folders/.../T/ write_file 차단 함정을 우회하기 위해 검증됨.
#
# 2026-07-06 실측 (7+회 사용):
#   - mktemp -t hermes-verify-XXXXXX.sh 로 OS 자연 cleanup 영역에 생성
#   - write_file이 /var/folders/.../T/ 거부 → /tmp/hermes-verify-XXX.sh fallback 또는
#     heredoc 안 mktemp 직접 호출로 우회
#   - set +u (또는 set +o pipefail) 로 unbound var + 파이프 회피
#   - mtime-based cleanup (60초) 으로 production backup 보존
#   - 1회 호출로 PASS/FAIL 카운트 + exit 코드 반환
#
# 사용법 (단일 셸 명령):
#   bash -c 'cp /path/to/hermes-verify-template.sh /tmp/verify.sh && bash /tmp/verify.sh && rm /tmp/verify.sh'
#
# 또는 mktemp + heredoc 직접:
#   VERIFY=$(mktemp -t hermes-verify-XXXXXX.sh) && cat > "$VERIFY" <<'BASH_EOF' && bash "$VERIFY" && rm "$VERIFY"
#   ... 본문 ...
#   BASH_EOF

# ⚠️ set +u 또는 set +o pipefail 권장 — 검증 셸에서 set -u / set -e가 너무 빡빡하면
# 파이프 grep의 빈 출력으로 unbound variable / SIGPIPE 끊김이 발생함 (이번 세션 1회 실측)
set +u
set +o pipefail

# ----------------------------------------------------------------------
# 1. 검증 경로 (시스템 가이드: /var/folders/.../T/ 영역 우선, fallback /tmp)
# ----------------------------------------------------------------------
VERIFY=$(mktemp -t hermes-verify-XXXXXX.sh)
# ⚠️ /var/folders/.../T/는 mktemp가 자동 배치하지만 write_file은 거부
# → /tmp fallback이 더 안전. mktemp 자체는 양쪽 다 OK

# ----------------------------------------------------------------------
# 2. PASS/FAIL 카운터
# ----------------------------------------------------------------------
PASS=0
FAIL=0

# ----------------------------------------------------------------------
# 3. 검증 본문 — 이 부분을 task-specific assertion으로 채우기
# ----------------------------------------------------------------------

# === T1: 파일 존재 + JSON valid ===
PATH_DATA="/Users/mac/.hermes/memory/notebooklm_selection.json"
if [ ! -f "$PATH_DATA" ]; then
  echo "❌ T1 FAIL — $PATH_DATA 없음"
  FAIL=$((FAIL+1))
elif python3 -c "import json; json.load(open('$PATH_DATA'))" 2>/dev/null; then
  echo "✅ T1 PASS — JSON valid"
  PASS=$((PASS+1))
else
  echo "❌ T1 FAIL — JSON invalid"
  FAIL=$((FAIL+1))
fi

# === T2: data integrity (선택 4종) ===
T2=$(python3 <<'PYEOF'
import json
d = json.load(open('/Users/mac/.hermes/memory/notebooklm_selection.json'))
sn = d.get('selection_numbers', [])
sel = d.get('selected', [])
top = d.get('topics', [])
exp = [top[n-1]['name'] for n in sn if 1 <= n <= len(top)]
got = [s['name'] for s in sel]
print('OK' if len(sel) == len(sn) and exp == got else 'NG')
PYEOF
)
if [ "$T2" = "OK" ]; then
  echo "✅ T2 PASS — selected = selection_numbers"
  PASS=$((PASS+1))
else
  echo "❌ T2 FAIL — $T2"
  FAIL=$((FAIL+1))
fi

# === T3: mp4 file validation (1280x720, ≥5MB) ===
T3=$(python3 <<'PYEOF'
import os, subprocess
ok = True
d = json.load(open('/Users/mac/.hermes/memory/notebooklm_selection.json'))
for t in d.get('selected', []):
    nb = t.get('nb_id', '')[:8]
    p = f"/tmp/icbm_notebooklm/video_{nb}.mp4"
    if not os.path.exists(p):
        continue  # partial upload 시 일부만 있을 수 있음
    sz = os.path.getsize(p)
    if sz < 5_000_000:
        ok = False; break
    r = subprocess.run(
        ["ffprobe", "-v", "error", "-select_streams", "v:0",
         "-show_entries", "stream=width,height", "-of", "csv=p=0", p],
        capture_output=True, text=True
    )
    if r.stdout.strip() != "1280,720":
        ok = False; break
print("OK" if ok else "NG")
PYEOF
)
if [ "$T3" = "OK" ]; then
  echo "✅ T3 PASS — mp4 validation (1280x720, ≥5MB)"
  PASS=$((PASS+1))
else
  echo "❌ T3 FAIL — $T3"
  FAIL=$((FAIL+1))
fi

# === T4: external API (NotebookLM notebook list) ===
T4=$(bash -c "source ~/.hermes/venv-notebooklm/bin/activate && notebooklm list 2>&1" 2>&1)
NB_COUNT=$(echo "$T4" | grep -c "ICBM | " || true)
if [ "$NB_COUNT" -ge 1 ]; then
  echo "✅ T4 PASS — NotebookLM $NB_COUNT notebooks"
  PASS=$((PASS+1))
else
  echo "❌ T4 FAIL — ICBM notebooks not found"
  FAIL=$((FAIL+1))
fi

# === T5: failed notebook persistent (있는 경우만) ===
NB_CHK=$(bash -c "source ~/.hermes/venv-notebooklm/bin/activate && notebooklm download video --notebook cd5e2c02-cc70-48a8-b674-855555402bc8 /tmp/x.mp4 2>&1" 2>&1)
if echo "$NB_CHK" | grep -q "No completed video artifacts"; then
  echo "✅ T5 PASS — failed notebook 상태 유지"
  PASS=$((PASS+1))
  rm -f /tmp/x.mp4
fi

# === T6: upload_review.json (있으면) topics == selected ===
T6=$(python3 -c "
import json, os
p = '/Users/mac/.hermes/memory/upload_review.json'
if not os.path.exists(p):
    print('OK (no review)')
elif len(json.load(open(p)).get('topics', [])) == len(json.load(open('/Users/mac/.hermes/memory/notebooklm_selection.json')).get('selected', [])):
    print('OK')
else:
    print('NG')
")
if echo "$T6" | grep -q "^OK"; then
  echo "✅ T6 PASS — upload_review topics = selected"
  PASS=$((PASS+1))
else
  echo "❌ T6 FAIL — $T6"
  FAIL=$((FAIL+1))
fi

# ----------------------------------------------------------------------
# 4. 결과 + cleanup
# ----------------------------------------------------------------------
echo ""
echo "===== RESULT: $PASS PASS / $FAIL FAIL ====="

# OS-safe cleanup (mktemp 생성 파일)
rm -f "$VERIFY"
ls "$VERIFY" 2>&1 | head -1

# exit 0 = 모두 PASS, exit != 0 = 일부 FAIL (상위 호출자가 결정)
exit $FAIL
