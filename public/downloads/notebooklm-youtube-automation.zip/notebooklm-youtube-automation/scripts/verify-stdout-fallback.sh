#!/usr/bin/env bash
# verify-stdout-fallback.sh (2026-07-06, 재사용 가능)
# Purpose: notebooklm_selection.py의 4가지 분기 모두 stdout에
#   "===== NOTEBOOKLM 후보 =====" 마커를 출력하는지 검증.
#   본 마커는 cron LLM이 후보를 받을 수 있는 contract — Telegram 실패와 무관.
#
# Usage: bash verify-stdout-fallback.sh
# Output: T1~T4 PASS/FAIL + RESULT
#
# 검증 4종:
#   T1: 정상 (Telegram creds 비움 → stdout fallback)
#   T2: 백업-유지 (16:57 사고 재현 — date==today and topics 존재)
#   T3: Telegram 실패 → stdout fallback
#   T4: topics=0 (코드 인스펙션)
#
# 함정 (2026-07-06 실측):
#   A1: write_file이 /var/folders/.../T/ 거부 → /tmp 하위에 직접 작성 가능
#   A2: set -uo pipefail + 빈 unbound variable → set +u 또는 || echo 0
#   A3: cleanup 광범위 prefix → mtime < 60s 필터 또는 .bak_* 화이트리스트

set +u  # A2 우회
SCRIPT="/Users/mac/.hermes/scripts/notebooklm_selection.py"
VENV="/Users/mac/.hermes/venv-notebooklm"
MEM_DIR="/Users/mac/.hermes/memory"
SEL_FILE="$MEM_DIR/notebooklm_selection.json"
BACKUP_PREFIX="notebooklm_selection.json.backup_"
TODAY=$(date +%Y-%m-%d)
PASS=0; FAIL=0

run_script() {
  bash -c "
    source $VENV/bin/activate
    export TELEGRAM_BOT_TOKEN='' TELEGRAM_CHAT_ID=''
    python3 $SCRIPT
  " 2>&1
}
has_marker() {
  echo "$1" | grep -q '===== NOTEBOOKLM 후보 =====' && \
  echo "$1" | grep -q '===== 후보 END ====='
}
count_topics() {
  echo "$1" | grep -cE '^\s*`[0-9]+`\.'
}

# T1: 정상
echo "=== T1: 정상 분기 (Telegram creds 비움) ==="
python3 -c "
import json
from pathlib import Path
p = Path('$SEL_FILE'); p.parent.mkdir(parents=True, exist_ok=True)
p.write_text(json.dumps({'date': '1999-01-01', 'topics': [], 'selected': [], 'selection_numbers': [], 'auto_mode': False}, ensure_ascii=False), encoding='utf-8')
"
OUT=$(run_script)
M=$(has_marker "$OUT" && echo Y || echo N); T=$(count_topics "$OUT")
if [ "$M" = "Y" ] && [ "$T" -ge 12 ]; then echo "  PASS — marker=$M topics=$T"; PASS=$((PASS+1)); else echo "  FAIL — marker=$M topics=$T"; FAIL=$((FAIL+1)); fi

# T2: 백업-유지 (16:57 사고)
echo ""; echo "=== T2: 백업-유지 (16:57 사고) ==="
python3 -c "
import json
from pathlib import Path
p = Path('$SEL_FILE')
topics = [{'name': f'topic_{i}', 'category': 'AI/ML', 'url': f'https://example.com/{i}'} for i in range(12)]
p.write_text(json.dumps({'date': '$TODAY', 'topics': topics, 'selected': [], 'selection_numbers': [], 'auto_mode': False}, ensure_ascii=False), encoding='utf-8')
"
OUT=$(run_script)
M=$(has_marker "$OUT" && echo Y || echo N); T=$(count_topics "$OUT"); B=$(echo "$OUT" | grep -c 'topics 백업 완료' || echo 0)
if [ "$M" = "Y" ] && [ "$T" -ge 12 ] && [ "$B" -ge 1 ]; then echo "  PASS — marker=$M topics=$T backup_log=$B"; PASS=$((PASS+1)); else echo "  FAIL"; FAIL=$((FAIL+1)); fi

# T3: Telegram 실패
echo ""; echo "=== T3: Telegram 자격증명 빈 문자열 → 실패 → stdout fallback ==="
python3 -c "
import json
from pathlib import Path
p = Path('$SEL_FILE')
p.write_text(json.dumps({'date': '1999-01-01', 'topics': [], 'selected': [], 'selection_numbers': [], 'auto_mode': False}, ensure_ascii=False), encoding='utf-8')
"
OUT=$(run_script)
M=$(has_marker "$OUT" && echo Y || echo N); T=$(count_topics "$OUT"); F=$(echo "$OUT" | grep -c '전송 실패' || echo 0)
if [ "$M" = "Y" ] && [ "$T" -ge 12 ] && [ "$F" -ge 1 ]; then echo "  PASS — marker=$M topics=$T fail_log=$F"; PASS=$((PASS+1)); else echo "  FAIL"; FAIL=$((FAIL+1)); fi

# T4: topics=0 — 코드 인스펙션
echo ""; echo "=== T4: topics=0 분기 (코드 인스펙션) ==="
FOUND=$(awk '/if not topics:/{flag=6} flag>0 && /NOTEBOOKLM 후보/{print "FOUND"; flag=0; exit}' "$SCRIPT")
if [ "$FOUND" = "FOUND" ]; then echo "  PASS — topics=0 분기 마커 print 존재"; PASS=$((PASS+1)); else echo "  FAIL"; FAIL=$((FAIL+1)); fi

# Cleanup (A3 우회: mtime < 60s 만)
echo ""; echo "=== cleanup (mtime < 60s 만) ==="
python3 -c "
import os, time, glob
now = time.time()
removed = []
for f in glob.glob('$MEM_DIR/${BACKUP_PREFIX}*.json'):
    if now - os.path.getmtime(f) < 60:
        os.remove(f)
        removed.append(os.path.basename(f))
print(f'  removed this run: {removed}')
print(f'  preserved old: {len(glob.glob(\"$MEM_DIR/${BACKUP_PREFIX}*.json\"))} files')
"

echo ""
echo "===== RESULT: $PASS PASS / $FAIL FAIL ====="
exit $FAIL
