# 📋 NotebookLM 자동화 재개 절차

**작성 시각 (KST):** {YYYY-MM-DD HH:MM}
**대상 자동화:** {YYYY-MM-DD HH:MM} 후보 12개 중 N개 노트북 생성 → YouTube 업로드
**선택된 번호:** **{N1, N2, N3, ...}** (이미 `selection.json`에 패치 완료 — 손대지 말 것)

---

## 🎯 선택된 N개 토픽 (변경 금지)

| # | 카테고리 | 주제 | URL |
|---|---------|------|-----|
| **{N1}** | {카테고리} | {주제} | https://news.hada.io/topic?id={NNNNN} |
| **{N2}** | {카테고리} | {주제} | https://news.hada.io/topic?id={NNNNN} |
| **{N3}** | {카테고리} | {주제} | https://news.hada.io/topic?id={NNNNN} |
| **{N4}** | {카테고리} | {주제} | https://news.hada.io/topic?id={NNNNN} |

**`selection.json` 파일:** `/Users/mac/.hermes/memory/notebooklm_selection.json`

---

## 🚀 재개 절차 (총 10~15분 예상)

### Step 1. 환경 검증 (1분)

```bash
# 1-1) venv 인터프리터 살아있는지 (Apple Silicon 사용자 'mac')
ls /Users/mac/.hermes/venv-notebooklm/bin/python3
# → "No such file or directory" 나오면 §A. venv 복구 필요

# 1-2) storage_state.json 정상인지 (정상 ~12,586 bytes)
ls -la ~/.notebooklm/profiles/default/storage_state.json
# → 0 bytes 나오면 §B. 풀 OAuth 재로그인 필요

# 1-3) selection.json 패치 보존 확인
python3 -c "
import json
d = json.load(open('/Users/mac/.hermes/memory/notebooklm_selection.json'))
print('selection_numbers:', d['selection_numbers'])
print('selected 개수:', len(d['selected']))
assert d['selection_numbers'] == [{SELECTION_NUMBERS}], '패치 깨짐!'
print('✅ 패치 정상')
"
```

### Step 2. NotebookLM 인증 확인 (30초)

```bash
/Users/mac/.hermes/venv-notebooklm/bin/python3 -m notebooklm list --json 2>&1 | head -3
```

- **정상:** `{"notebooks": [...]}` 같은 JSON 응답
- **만료:** `Authentication expired or invalid. Redirected to: ...` → **§B 풀 OAuth 재로그인으로 점프**

### Step 3. 노트북 생성 (4~6분, 자동화)

```bash
/Users/mac/.hermes/venv-notebooklm/bin/python3 ~/.hermes/scripts/notebooklm_prepare.py --skip-telegram 2>&1 | tail -80
```

**기대 출력:**
```
📌 [1/N] {주제1}
  1️⃣ 노트북 생성...
  ✅ 노트북 생성 (ID: xxxxxxxx-xxxx-...)
  2️⃣ 소스 추가...
  ✅ 소스 추가
📌 [2/N] {주제2}
  ✅ 노트북 생성 (ID: yyyyyyyy-yyyy-...)
...

✅ 노트북 준비 완료!
   생성된 노트북: N개
```

**nb_id 확보 헬퍼** (prepare.py 출력 truncation 회피):
```bash
/Users/mac/.hermes/venv-notebooklm/bin/python3 ~/.hermes/skills/automation/notebooklm-youtube-automation/scripts/resolve-notebook-ids.py "{키워드1}" "{키워드2}" "{키워드3}" "{키워드4}"
```

### Step 4. NotebookLM 웹 UI에서 영상 생성 (사용자 작업, 5~15분)

> ⚠️ **`prepare.py`는 노트북 + 소스만 추가합니다. 영상 생성은 사용자가 웹 UI에서 직접 누르는 작업입니다.**

1. https://notebooklm.google.com 접속 → 로그인 (Gmail.com 계정)
2. N개 노트북 각각 들어가서:
   - **Studio → Video Overview → Generate** 클릭
   - 영상 길이 옵션 (기본/Brief/Detailed) 선택
   - 3~10분 대기
3. N/N 모두 `Completed` 상태인지 확인 (Pending/Failed 섞이면 §C 참조)

### Step 5. 영상 다운로드 (1~2분)

```bash
mkdir -p /tmp/icbm_notebooklm/videos

# ⚠️ --all은 마지막 use 1개만 받음 (금기 #18). 각 노트북마다 반복 필수!
for nb_id in $NB_ID_N1 $NB_ID_N2 $NB_ID_N3 $NB_ID_N4; do
  /Users/mac/.hermes/venv-notebooklm/bin/python3 -m notebooklm use $nb_id
  /Users/mac/.hermes/venv-notebooklm/bin/python3 -m notebooklm download video --all /tmp/icbm_notebooklm/videos/ --force
done

ls -la /tmp/icbm_notebooklm/videos/
# → 파일 N개 확인 (0 또는 부족하면 Step 4로 돌아가서 영상 생성 상태 확인)
```

### Step 6. selection.json on-demand 패치 (number + file + nb_id)

> ⚠️ **prepare.py는 topics에 `number`/`file`/`nb_id`를 자동 채우지 않습니다 (금기 #28, #32). on-demand 진입 시 직접 패치 필요.**

```bash
python3 << 'PYEOF'
import json, os, glob

p = '/Users/mac/.hermes/memory/notebooklm_selection.json'
videos_dir = '/tmp/icbm_notebooklm/videos'
nb_id_map = {
    {N1}: 'NB_ID_{TOPIC1}',   # ← Step 3에서 받은 ID로 교체
    {N2}: 'NB_ID_{TOPIC2}',
    {N3}: 'NB_ID_{TOPIC3}',
    {N4}: 'NB_ID_{TOPIC4}',
}

d = json.load(open(p))

# 1) topics 12개 전체에 number 부여
for i, t in enumerate(d['topics'], 1):
    t['number'] = i

# 2) nb_id + file 매핑
videos = {os.path.splitext(os.path.basename(f))[0]: f for f in glob.glob(f'{videos_dir}/*.mp4')}
print(f"다운로드된 영상 {len(videos)}개: {list(videos.keys())}")

# 키워드 기반 자동 매핑 (NotebookLM이 제목을 다르게 생성한 경우 대비)
for num, t in enumerate(d['topics'], 1):
    if num in d['selection_numbers']:
        keyword_map = {{{N1}: '{KEYWORD1}', {N2}: '{KEYWORD2}', {N3}: '{KEYWORD3}', {N4}: '{KEYWORD4}'}}
        for kw in [keyword_map[num], str(num)]:
            for vname, vpath in videos.items():
                if kw.lower() in vname.lower() and num not in [t.get('number') for t in d.get('selected', [])]:
                    t['nb_id'] = nb_id_map[num]
                    t['file'] = vpath
                    break

# 3) selected REPLACE (append 금지 — 금기 #15)
d['selected'] = [t for t in d['topics'] if t.get('number') in d['selection_numbers']]
d['selected'].sort(key=lambda x: x['number'])

with open(p, 'w') as f:
    json.dump(d, f, ensure_ascii=False, indent=2)

# 검증
for t in d['selected']:
    assert t.get('nb_id'), f"#{t['number']} nb_id missing"
    assert t.get('file'), f"#{t['number']} file missing"
    assert os.path.exists(t['file']), f"#{t['number']} file not exists"
    print(f"✅ #{t['number']} {t['name'][:30]}... → {os.path.basename(t['file'])}")

print(f"\n✅ {len(d['selected'])}개 selected 완전 검증")
PYEOF
```

### Step 7. YouTube 토큰 + venv 5종 사전 체크 (10초)

```bash
# venv 인터프리터 OK
ls /Users/mac/.hermes/venv-notebooklm/bin/python3

# selection.json 오늘 날짜 + selection_numbers 보존
python3 -c "
import json
d = json.load(open('/Users/mac/.hermes/memory/notebooklm_selection.json'))
assert d['date'] == '{YYYY-MM-DD}', f\"날짜 다름: {d['date']}\"
assert d['selection_numbers'] == [{SELECTION_NUMBERS}], f\"선택 번호 다름: {d['selection_numbers']}\"
print('✅ selection.json 정상')
"

# 영상 파일 N개
ls /tmp/icbm_notebooklm/videos/ | wc -l   # → N 기대

# YouTube 토큰 valid
/usr/bin/python3 -c "
import pickle
c = pickle.load(open('/Users/mac/.hermes/secrets/youtube_token.pickle', 'rb'))
print(f'valid={c.valid} refresh_token={\"있음\" if c.refresh_token else \"없음\"}')
"
# → valid=False면 §D 토큰 refresh
```

### Step 8. --review (검토)

```bash
/Users/mac/.hermes/venv-notebooklm/bin/python3 /Users/mac/.hermes/scripts/notebooklm_upload.py --review
```

**⚠️ Telegram placeholder 환경이면 silent fail (금기 #19, #31)** — 그땐 직접 검토:
```bash
cat /Users/mac/.hermes/memory/upload_review.json | python3 -m json.tool
```

검토 후 **description의 출처 URL이 모두 `news.hada.io`인지 확인** (금기 #8, #26):
```bash
python3 -c "
import json, re
d = json.load(open('/Users/mac/.hermes/memory/upload_review.json'))
for t in d['topics']:
    desc = t['description']
    urls = re.findall(r'https://\S+', desc)
    assert urls, f\"#{t['index']} description에 URL 없음\"
    assert any('news.hada.io' in u for u in urls), f\"#{t['index']} GeekNews URL 없음\"
    print(f\"  #{t['index']} OK\")
print('✅ N/N description GeekNews URL 검증 통과')
"
```

### Step 9. 사용자에게 검토 내용 전달 → "확인" 대기

텔레그램으로 검토 메시지 보냈거나 직접 read_file로 사용자에게 표시. 사용자가 **"확인"** 이라고 입력할 때까지 대기.

### Step 10. --approved (실제 업로드, 1~2분)

```bash
/Users/mac/.hermes/venv-notebooklm/bin/python3 /Users/mac/.hermes/scripts/notebooklm_upload.py --approved
```

**기대 출력:**
```
✅ 업로드 성공: 일반 영상 × N, Shorts × N
   - 영상 URL: ...
   - Shorts URL: ...
```

**자동 cleanup:** 성공한 노트북 N개는 NotebookLM에서 자동 삭제됨 (금기 #11). 같은 주제 재업로드 시 새 ID로 재생성 필요.

---

## 🛠 부록: 함정/복구 절차

### §A. venv-notebooklm 깨진 경우 (gold #34, #35)

```bash
# 진단
cat ~/.hermes/venv-notebooklm/pyvenv.cfg | grep -E "^(home|executable)"
head -1 ~/.hermes/venv-notebooklm/bin/notebooklm  # /Users/hjshin/ 같은 타 사용자 경로 = 깨진 venv

# 재생성 (5분)
/opt/homebrew/bin/python3.12 -m venv --clear ~/.hermes/venv-notebooklm
~/.hermes/venv-notebooklm/bin/pip install --quiet --upgrade pip
~/.hermes/venv-notebooklm/bin/pip install --quiet "notebooklm-py[browser]" \
  requests google-api-python-client google-auth-oauthlib google-auth-httplib2
~/.hermes/venv-notebooklm/bin/playwright install chromium
~/.hermes/venv-notebooklm/bin/notebooklm --version   # 0.7.x 확인
```

### §B. NotebookLM 풀 OAuth 재로그인 (금기 #23, #24, #36)

> ⚠️ **Storage_state.json에 .google.co.kr 쿠키가 섞여 있으면 Workspace 계정 → 인증 불가 가능성**

**사전 진단:**
```bash
/Users/mac/.hermes/venv-notebooklm/bin/python3 -c "
from notebooklm.auth import _load_storage_state
data = _load_storage_state()
for c in data.get('cookies', []):
    if c['name'] == 'SID':
        print('SID domain:', c['domain'])
"
# .google.com → consumer Gmail (정상)
# .google.co.kr → Google Workspace (인증 불가)
```

**Workspace 쿠키 제거:**
```bash
/Users/mac/.hermes/venv-notebooklm/bin/python3 << 'PYEOF'
import json
p = '/Users/mac/.notebooklm/profiles/default/storage_state.json'
d = json.load(open(p))
before = len(d.get('cookies', []))
d['cookies'] = [c for c in d['cookies'] if not c.get('domain', '').endswith('google.co.kr')]
after = len(d['cookies'])
json.dump(d, open(p, 'w'), indent=2)
print(f'쿠키: {before}개 → {after}개 (.google.co.kr 제거)')
PYEOF
```

**OAuth 재로그인 (PTY background, ~3분):**
```bash
/Users/mac/.hermes/venv-notebooklm/bin/python3 -m notebooklm login
# → 브라우저 창이 뜨면 Gmail.com 계정으로 로그인
# → NotebookLM 홈이 뜨면 터미널에서 Enter
```

### §C. 일부 노트북 영상 생성 실패 (금기 #28, #44)

`artifact list`로 상태 확인:
```bash
for nb_id in $NB_ID_N1 $NB_ID_N2 $NB_ID_N3 $NB_ID_N4; do
  /Users/mac/.hermes/venv-notebooklm/bin/python3 -m notebooklm use $nb_id
  /Users/mac/.hermes/venv-notebooklm/bin/python3 -m notebooklm artifact list 2>&1 | grep -iE "video|status"
done
```

- `Status: completed` → 정상
- `Status: failed` → NotebookLM 웹 UI에서 재생성 필요
- `No all artifacts found` → artifact 자체 미생성 → Create 다시 누르기

**부분 업로드:** 실패한 노트북 제외하고 `selected` REPLACE:
```bash
python3 << 'PYEOF'
import json
p = '/Users/mac/.hermes/memory/notebooklm_selection.json'
d = json.load(open(p))
failed_numbers = [{FAILED}]  # 예: #9만 failed, 나머지 [N1, N2, N3]만 진행
d['selection_numbers'] = [n for n in d['selection_numbers'] if n not in failed_numbers]
d['selected'] = [t for t in d['topics'] if t.get('number') in d['selection_numbers']]
d['selected'].sort(key=lambda x: x['number'])
json.dump(d, open(p, 'w'), ensure_ascii=False, indent=2)
print(f'✅ 업로드 대상 {len(d["selected"])}개로 변경')
PYEOF
```

### §D. YouTube 토큰 valid=False (금기 #40)

```bash
# 1차 refresh 시도 (5초)
/usr/bin/python3 -c "
import os, pickle
from google.auth.transport.requests import Request
p = os.path.expanduser('~/.hermes/secrets/youtube_token.pickle')
c = pickle.load(open(p, 'rb'))
try:
    c.refresh(Request())
    pickle.dump(c, open(p, 'wb'))
    print('✅ refresh 성공')
except Exception as e:
    print(f'❌ refresh 실패 → 풀 OAuth 필요: {e}')
"

# 실패 시 풀 OAuth (background launch, 브라우저 인증)
/Users/mac/.hermes/venv-notebooklm/bin/python3 ~/.hermes/skills/automation/notebooklm-youtube-automation/scripts/youtube_reauth.py
# → 출력된 URL을 사용자에게 전달 → 브라우저에서 로그인 + 허용
```

### §E. Shorts 변환 실패 (금기 #33)

FFmpeg 8.x에서 `-filter_complex`+`-map`+`-pix_fmt yuv420p` 조합 broken. 이미 `notebooklm_upload.py`의 `make_shorts()`가 패치되어 있어야 함. 만약 Shorts만 실패하면:

```bash
# 원본 .mp4는 cleanup 후에도 /tmp/icbm_notebooklm/videos/에 보존됨
for f in /tmp/icbm_notebooklm/videos/*.mp4; do
  base=$(basename "$f" .mp4)
  ffmpeg -y -i "$f" -t 59 \
    -vf "scale=1080:-1,pad=0:1920:(ow-iw)/2:(oh-ih)/2:black,setsar=1,setdar=9/16" \
    -c:v libx264 -preset ultrafast -crf 23 \
    -c:a aac -b:a 128k -af "afade=t=out:st=56:d=3" \
    -movflags +faststart -shortest \
    "/tmp/icbm_notebooklm/shorts/${base}_shorts.mp4"
done

# 단독 Shorts 업로드
for f in /tmp/icbm_notebooklm/shorts/*_shorts.mp4; do
  /Users/mac/.hermes/venv-notebooklm/bin/python3 ~/.hermes/scripts/yt_upload.py "$f" --shorts ...
done
```

---

## ⚠️ 핵심 금기 (절대 어기지 말 것)

1. **`selection.json`의 `topics` 배열 처음부터 재작성 금지** — URL 손실
2. **`selected` 배열 `append` 금지** — 이전 토픽까지 같이 처리됨. `REPLACE`만
3. **topics에 `number`/`nb_id`/`file` 자동 채워진다고 가정 금지** — on-demand 진입 시 명시 패치 필수
4. **`notebooklm download video --all` = 모든 노트북이 아님** — 마지막 use 1개만 받음. `for` 루프 필수
5. **`upload_review.json` 어제 데이터면 진행 금지** — 오늘 날짜 확인 필수
6. **`--approved` 직전에 토큰 valid 재확인** — False면 refresh 먼저
7. **description 출처는 GeekNews URL만** — `sources[]` 메타데이터와 다름 (금기 #8)
8. **Telegram placeholder 환경에서 `--review` silent fail 가능** — `read_file upload_review.json`으로 직접 확인 (금기 #19, #31)

---

## 📞 PC 복구 후 즉시 시작 체크리스트

```
□ PC 다시 켜짐
□ Step 1: 환경 검증 (1분)
  □ venv 인터프리터 살아있는지
  □ storage_state.json 12KB 이상인지
  □ selection.json [{SELECTION_NUMBERS}] 보존인지
□ Step 2: notebooklm list --json (인증 확인)
  □ 인증 만료면 §B 풀 OAuth
□ Step 3: prepare.py 실행 (N개 노트북 생성)
□ Step 4: NotebookLM 웹 UI에서 영상 생성 (사용자)
□ Step 5: 영상 N개 다운로드
□ Step 6: selection.json on-demand 패치 (number + file + nb_id)
□ Step 7: 5종 사전 체크
□ Step 8: --review (검토)
□ Step 9: 사용자 "확인" 대기
□ Step 10: --approved (업로드)
```

**작성:** 혜린 ({YYYY-MM-DD HH:MM} KST, PC 접근 불가로 보류된 상태)
