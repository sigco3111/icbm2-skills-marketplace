---
name: skill-maintenance-policy
description: Make every session patch or add to the skill library.
category: automation
---

# Skill Maintenance Policy

- **Active Update Rule**: Each interactive session must result in at least one skill library modification (patch, new file, or new umbrella).
- **When to Patch**: If the user corrects a workflow, style, or reveals a new technique, update the relevant existing skill.
- **When to Add**: If no umbrella covers the emerging knowledge, create a new class‑level skill with an appropriate category and add supporting reference files.
- **Reference Files**: Store session‑specific details under `references/` with a filename that includes the session date (e.g., `2026-07-29_session_notes.md`), linking from the skill body.
- **Review Cycle**: Periodically run the `skill-lifecycle` skill to audit for overlapping umbrellas and consolidate.
- **User Preference**: Users may request minimal verbosity; embed their style preferences in the skill body to guide future responses.

## Supporting Reference

See the session‑specific note: `references/2026-07-29_session_notes.md`.
