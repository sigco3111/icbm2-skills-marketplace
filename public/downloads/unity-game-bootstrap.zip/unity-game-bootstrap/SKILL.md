---
name: unity-game-bootstrap
description: Unity로 새 게임 프로젝트를 부트스트랩할 때 사용 — Unity Hub 설치, Editor 버전 선택, Asset Store 구매 자산 Import, 프로젝트 구조 설계, M4/Apple Silicon 검증. macOS 우선.
---

# Unity Game Bootstrap

Unity 신규 프로젝트 부트스트랩 전체 워크플로 — Unity Hub 설치부터 첫 에셋 Import + 첫 씬까지.

## 트리거 조건

다음 중 하나라도 해당되면 로드:
- "Unity 설치", "Unity 에셋 사용", "Unity 프로젝트 시작", "유니티 깔아줘"
- Asset Store 구매 목록을 게임 프로젝트로 변환
- 기존 Godot 프로젝트의 Unity 포팅 검토

## Phase 0 — 시스템 사전 확인

먼저 실행:

```bash
df -h / | tail -1                             # 10GB+ 여유 필요
system_profiler SPHardwareDataType | grep -E "(Chip|Memory)"
```

- **M1+ Apple Silicon** → Unity 2022.2+ IL2CPP 네이티브 지원
- **RAM 16GB+** → Editor 1개 + IDE 동시 가능
- **디스크 10GB+** → Editor 3GB + 에셋 평균 500MB × N
- 자동 점검 스크립트: `scripts/check-unity-prereqs.sh`

## Phase 1 — Unity Hub 설치 (CLI 가능)

```bash
brew install --cask unity-hub
```

> ⚠️ **Pitfall (2026년 기준)**: `https://public-cdn.cloud.unity3d.com/hub/prod/UnityHubSetup.dmg` URL은 **404 반환**. 직접 .dmg 다운로드 받으려고 하지 말 것. **brew cask가 유일하게 안정적인 경로.**

> ⚠️ **Pitfall**: Unity Hub CLI에 `--help` 옵션 **없음**. 모든 설치/설정 작업이 GUI 필수. agent가 헤드리스로 Editor 설치하는 정식 경로는 없음 — Hub의 GUI 흐름을 사용자에게 안내해야 함.

설치 후 `/Applications/Unity Hub.app` 생성 확인.

## Phase 2 — Unity ID 로그인

Unity Hub GUI에서:
1. 우측 상단 사람 아이콘 → **Sign in**
2. 브라우저 또는 로그인 창에서 Unity ID 입력
3. **Asset Store 구매한 계정과 동일해야** Package Manager의 My Assets에 표시됨

> ⚠️ **Pitfall**: 다른 계정으로 로그인되어 있으면 My Assets가 비어 보임 → 에셋이 없는 게 아니라 계정 불일치.

## Phase 3 — Editor 설치 (GUI, 사용자 직접)

Unity Hub → **Installs** → **Install Editor** → 버전 선택:

| Unity 버전 | 적합한 경우 |
|-----------|----------|
| **2022.3 LTS** (기본 권장) | 대부분의 Asset Store 패키지 호환, 신규 프로젝트 디폴트, 3GB 가벼움 |
| 2023.3 LTS | URP 최신 기능, 신규 URP 프로젝트 |
| Unity 6 LTS | "Unity 6 이상 필요" 에셋, 장기 지원 |

**모듈 선택 체크리스트**:
- ✅ Microsoft Visual Studio Community (코드 에디터)
- ✅ Mac Build Support (IL2CPP) — 빌드 시 필요
- ✅ Documentation (선택)

설치 시간: 3~5분 (네트워크에 따라 10분+)

## Phase 4 — 프로젝트 생성

Unity Hub → **Projects** → **New project** → 템플릿:

| 템플릿 | 용도 |
|--------|------|
| **3D (URP)** | Polygon Fantasy/MicroVerse 등 3D 에셋 (기본 추천) |
| **3D Core** | 범용 3D (URP 안 쓸 때, 더 가벼움) |
| **2D** | 2D 게임 |
| **3D HDRP** | 고품질 그래픽 |

> ⚠️ **Pitfall (치명적)**: URP/HDRP는 **서로 교체 불가** — 잘못 고르면 새 프로젝트. 빌드 후 마이그레이션 비용 매우 큼.

프로젝트 위치: `/Users/mac/work/unity-<game-name>/`

## Phase 5 — Asset Store 에셋 Import

### 정상 흐름 (Unity 설치된 상태)

Asset Store 웹(https://assetstore.unity.com/account/assets)의 **"Unity에서 열기"** 버튼:
- Unity Hub가 자동으로 라우팅 → Editor의 Package Manager가 해당 에셋 표시
- Download → Import 자동 진행

### 진단 신호: "Unity에서 열기" 버튼이 무반응

이건 **Unity가 설치되지 않았다는 명확한 신호**다 (단순 버그 아님):
- Unity Hub 미설치 → Phase 1부터
- Unity Hub만 있고 Editor 미설치 → Hub에서 Editor 설치 후 재시도

### Package Manager에서 수동 Import

1. **Window → Package Manager**
2. 좌상단 드롭다운 → **Packages: My Assets**
3. 에셋 클릭 → 우측 하단 **Download** → 끝나면 **Import** 버튼으로 변경
4. Import 팝업 → 모두 체크 → **Import**

> ⚠️ **Pitfall (2026 정책)**: 웹에서 직접 `.unitypackage` 다운로드는 **막혀 있음**. "Download" 버튼 자체가 없거나 작동 안 함. **Editor 내부 Import가 유일한 정식 경로.**

### 우회: 다른 프로젝트로 옮길 때

1. 원본 프로젝트에서 Project 창 → 에셋 폴더 우클릭 → **Export Package...**
2. 모두 체크 → Export → `.unitypackage` 저장
3. 대상 프로젝트에서 Assets → Import Package → Custom Package

## 프로젝트 구조 권장

```
Assets/
├── Scenes/        # 씬 파일 (.unity)
├── Scripts/       # C# 스크립트 (.cs)
├── Prefabs/       # 프리팹 (.prefab)
├── Materials/     # 머티리얼 (.mat)
├── Audio/         # 오디오
├── Animations/    # 애니메이션 (.anim)
├── Sprites/       # 2D 스프라이트 또는 Textures/
├── Settings/      # URP/HDRP 설정
└── Plugins/       # 서드파티 라이브러리
```

## 검증

```bash
# 프로젝트 폴더 확인
ls ~/work/unity-<game>/Assets/

# Hub에서 설치된 Editor 목록
ls ~/Library/Application\ Support/Unity/Hub/Editor/

# Editor 로그 (선택, 디버그용)
cat ~/Library/Logs/Unity/Editor.log | tail -50
```

## 자주 발생하는 함정

| 증상 | 원인 | 해결 |
|------|------|------|
| "Unity에서 열기" 무반응 | Unity 미설치 | Phase 1부터 |
| Package Manager My Assets 비어있음 | 다른 계정 로그인 | 로그아웃 → 구매 계정으로 재로그인 |
| 에셋 import 후 pink shader | URP/HDRP 비호환 | 템플릿과 에셋 렌더 파이프라인 일치 확인 |
| Script 컴파일 에러 | .NET 버전 불일치 | Project Settings → Player → .NET Standard 2.1 |
| Editor 시작 시 "License missing" | Personal 라이선스 미활성 | Hub → 계정 → Manage Licenses → Activate |

## 다음 단계

이 스킬은 부트스트랩만 다룬다. 이후 작업은 별도:
- 씬/컨트롤러 C# 작성 — 직접 코딩 가이드
- 빌드/배포 — `references/build-deployment.md` (TODO)
- 에셋별 통합 — Asset ReadMe 우선 참조

## References

- `scripts/check-unity-prereqs.sh` — 디스크/RAM/칩/Hub 설치 상태 자동 점검
- `references/asset-store-flow.md` — Asset Store 워크플로우 심화 (구매 → 클레임 → Import → Export)