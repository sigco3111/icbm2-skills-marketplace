# Asset Store → Unity Import 워크플로우 (2026 검증)

## 계정 흐름

```
Asset Store 구매 (브라우저, 계정 A)
       ↓
Unity ID 로그인 (Hub, 반드시 같은 계정 A)
       ↓
Package Manager → My Assets (9개 보임)
       ↓
Download → Import
```

**계정 불일치 시 My Assets가 비어 보임** — 패키지 미구매가 아님.

## "Unity에서 열기" 버튼 — 정상 / 비정상

### 정상 (Unity 설치된 상태)
- 클릭 → Hub가 자동 라우팅 → Editor가 활성 상태면 Package Manager가 그 에셋을 띄움
- 자동으로 Download/Import는 시작되지 않음 — Package Manager에서 한 번 더 클릭 필요

### 비정상 — 무반응
이는 **Unity 미설치의 명확한 진단 신호**:
- Hub 자체 미설치
- Hub만 있고 Editor 미설치
- Hub/Editor 설치됨 + 로그인 안 됨

> ⚠️ 2026년 기준 Asset Store 웹에서 **직접 .unitypackage 다운로드는 정책적으로 막혀 있음**.
> "Download" 버튼이 노출되더라도 작동 안 함. **Editor 내부 Package Manager가 유일한 정식 경로.**

## 패키지 단위 Import 절차

1. Package Manager 열기 (`Window → Package Manager`)
2. 좌상단 드롭다운 → `Packages: My Assets`
3. 에셋 검색/선택 → 우측 패널에 상세 표시
4. 우측 하단 **Download** 버튼 클릭
5. 진행률 표시줄 완료 대기
6. 자동으로 **Import** 버튼으로 변경 → 클릭
7. 팝업 Import Package 창:
   - 기본적으로 모든 체크박스 ON
   - **건드리지 말고** 그대로 `Import`
8. Project 창에 새 폴더 생성됨 (보통 `Assets/<에셋이름>/`)
9. 에셋 ReadMe 파일 우선 확인 (`README.pdf` 또는 `Readme.txt`)

## Export Package (다른 프로젝트로 옮길 때)

에셋을 받아둔 원본 프로젝트에서:
1. Project 창에서 옮길 에셋 폴더 선택
2. 우클릭 → `Export Package...`
3. `Export...` 클릭 (모든 의존성 자동 선택)
4. 저장 위치 선택 → `.unitypackage` 파일 생성
5. 대상 프로젝트에서 `Assets → Import Package → Custom Package...`

## 의존성 함정

일부 패키지는 다른 패키지에 의존:
- **Visual Scripting / Bolt** → 호환 버전 확인
- **URP 전용 에셋** → Core RP 프로젝트에서는 작동 안 함 (Pink/Default material)
- **HDRP 전용 에셋** → URP 프로젝트에서 작동 안 함
- **MicroVerse / Vegetation Studio** → Render Pipeline 정렬 + Terrain 설정 필수

해결: Project Settings → Graphics → Render Pipeline Asset 확인 후 일치하는 에셋만 Import.

## 자주 묻는 질문

**Q: Import 후 메뉴에 새 항목이 안 생겨요**
A: 에셋 ReadMe에 "Setup" 단계가 별도로 있을 수 있음. 보통 Tools/GameObject 메뉴에 추가됨. ReadMe 먼저 확인.

**Q: Demo 씬이 어디 있나요?**
A: 보통 `Assets/<에셋이름>/Scenes/Demo.unity` 또는 `Demos/` 폴더. 더블클릭으로 열어서 어떻게 작동하는지 보면 빨리 감 잡힘.

**Q: Import 했는데 컴파일 에러가 났어요**
A: Unity 버전 비호환. 에셋의 최소 Unity 버전 확인 → Project Settings → Player → Other Settings에서 API Compatibility Level 확인.