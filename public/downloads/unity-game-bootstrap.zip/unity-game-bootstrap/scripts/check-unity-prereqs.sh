#!/usr/bin/env bash
# Unity 부트스트랩 사전 조건 점검 — M4 Mac mini에서 검증됨 (2026-07-20)
# 사용법: bash check-unity-prereqs.sh

set -e
echo "=== Unity 사전 조건 점검 ==="
echo

echo "[1/5] 디스크 공간:"
DF_FREE=$(df -h / | tail -1 | awk '{print $4}')
echo "  여유: $DF_FREE"
DF_FREE_NUM=$(df -h / | tail -1 | awk '{print $4}' | sed 's/Gi//' | sed 's/G//')
if [[ "$DF_FREE_NUM" =~ ^[0-9.]+$ ]] && (( $(echo "$DF_FREE_NUM >= 10" | bc -l) )); then
  echo "  ✓ 충분 (10GB+ 권장)"
else
  echo "  ⚠ 10GB 이상 권장 — Editor 3GB + 에셋 Import 공간"
fi
echo

echo "[2/5] 칩셋:"
CHIP=$(sysctl -n machdep.cpu.brand_string 2>/dev/null || system_profiler SPHardwareDataType | grep "Chip:" | head -1 | awk '{print $2}')
echo "  $CHIP"
case "$CHIP" in
  Apple*) echo "  ✓ Apple Silicon — Unity 2022.2+ IL2CPP 네이티브" ;;
  Intel*) echo "  ✓ Intel — Unity 모든 버전 지원" ;;
  *)     echo "  ? 확인 필요" ;;
esac
echo

echo "[3/5] RAM:"
RAM_GB=$(system_profiler SPHardwareDataType | grep "Memory:" | awk '{print $2}')
echo "  ${RAM_GB} GB"
if [[ "$RAM_GB" -ge 16 ]]; then
  echo "  ✓ 충분"
elif [[ "$RAM_GB" -ge 8 ]]; then
  echo "  ⚠ 8GB는 Editor 1개에 최소 — 동시 IDE는 무리"
else
  echo "  ✗ 16GB 이상 권장"
fi
echo

echo "[4/5] Unity Hub 설치:"
if [[ -d "/Applications/Unity Hub.app" ]]; then
  echo "  ✓ /Applications/Unity Hub.app 존재"
else
  echo "  ✗ 미설치 → brew install --cask unity-hub"
fi
echo

echo "[5/5] 설치된 Editor:"
HUB_DIR=~/Library/Application\ Support/Unity/Hub/Editor
if [[ -d "$HUB_DIR" ]]; then
  VERSIONS=$(ls "$HUB_DIR" 2>/dev/null)
  if [[ -n "$VERSIONS" ]]; then
    echo "$VERSIONS" | while read v; do echo "  ✓ Unity $v"; done
  else
    echo "  ⚠ Hub는 있지만 Editor 없음 → Install Editor 가이드 필요"
  fi
else
  echo "  ⚠ Hub 디렉토리 없음 — 한 번도 Editor 설치 안 됨"
fi
echo

echo "=== 점검 완료 ==="