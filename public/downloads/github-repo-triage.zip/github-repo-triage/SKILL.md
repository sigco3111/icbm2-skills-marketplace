---
name: github-repo-triage
description: 사용자가 GitHub URL을 던지며 "이거 뭔가?" / "사용할만 할까?" / "API 키 필요?" / "라이선스?" 식으로 빠르게 평가해달라고 물을 때 발동. gh CLI 메타데이터 → raw README → license/activity/source 점검로 5분 안에 verdict(추천/조건부/비추천 + 옵션) 산출. 단일 OSS 도입 의사결정 워크플로.
---

# github-repo-triage

사용자가 `https://github.com/<owner>/<repo>` URL을 던지며 빠르게 평가 요청할 때의 표준 워크플로. **5분 안에 답**하고, **명확한 verdict(추천/조건부/비추천) + 3개 이내 옵션**으로 끝내는 게 목표. 깊은 분석·fork·로컬라이즈는 이 스킬의 범위 밖 → 후속 스킬(`oss-fork-localization`, `cpp-game-koreanization` 등)로 인계.

## 트리거 조건

다음 중 하나라도 매칭되면 발동:

- 사용자가 GitHub URL 던지고 단문 질문 (예: "이거 뭔가?", "사용할만 할까?", "API 키 필요?", "라이선스?", "관련 스킬 있어?")
- "TOP N 추천해줘" 같이 비교 후보군 빠른 평가
- 새 의존성을 SI에 들이기 전 사전 검증

트리거 안 됨: 이미 git clone 했거나 코드 작업 중 → `github-repo-management` / `oss-fork-localization` 사용.

## 5단계 워크플로

### 1. 메타데이터 (10초)

```bash
gh repo view <owner>/<repo> --json name,description,url,primaryLanguage,stargazerCount,updatedAt,createdAt,licenseInfo,isFork,forkCount
```

빠른 1차 표에 넣을 5컬럼: **이름 / 설명 / 언어 / ⭐ / 최근 업데이트**.

### 2. README raw (10초)

⚠️ **함정**: `gh repo view --json readme` 는 readme 필드를 비워서 반환함. 반드시 raw로:

```bash
curl -fsSL https://raw.githubusercontent.com/<owner>/<repo>/<branch>/README.md | head -150
```

기본 브랜치는 거의 항상 `main`이지만 모르면 `gh repo view ... --json defaultBranchRef` 로 확인.

### 3. 파일 인벤토리 (필요시 30초)

소스 의존성/스크립트 구조 보고 싶을 때:

```bash
gh api repos/<owner>/<repo>/git/trees/<branch>?recursive=1 | \
  python3 -c "import json,sys; d=json.load(sys.stdin); [print(t['path']) for t in d.get('tree',[])]"
```

확장자 분포·CSS/JS/MD 파일 수 빠르게 셀 때:

```bash
gh api repos/<owner>/<repo>/git/trees/<branch>?recursive=1 | python3 -c "
import json,sys,collections
d=json.load(sys.stdin)
ext=collections.Counter(p.rsplit('.',1)[-1] for p in [t['path'] for t in d.get('tree',[])] if '.' in p['path'])
print(dict(ext))
"
```

### 4. 활동성 / 기여자 (필요시 30초)

```bash
# 최근 30일 커밋 수 + 작성자 분포
gh api "repos/<owner>/<repo>/commits?per_page=100&since=$(date -u -v-30d +%Y-%m-%dT%H:%M:%SZ 2>/dev/null || date -u -d '30 days ago' +%Y-%m-%dT%H:%M:%SZ)" | \
  python3 -c "
import json,sys,collections
d=json.load(sys.stdin)
print('last 30d commits:', len(d))
authors=[(c.get('author') or {}).get('login') or (c.get('commit',{}).get('author') or {}).get('email') for c in d]
print(collections.Counter(authors).most_common())
"

# 기여자 수
gh api repos/<owner>/<repo>/contributors | python3 -c "
import json,sys
d=json.load(sys.stdin)
print('contributors:', len(d))
for c in d[:5]:
    print(' ', c.get('login'), c.get('contributions'))
"
```

### 5. Verdict 산출 (출력 템플릿)

**항상 5줄 이내 표 + 한 줄 결론 + 옵션 3개 이내**로 응답. 메모리 `응답 스타일: 짧은 명령. 미니멀. clarify 4옵션+추천` 준수.

```markdown
| 항목 | 값 |
|---|---|
| 이름 | <owner>/<repo> |
| 설명 | <description> |
| 언어 | <primaryLanguage> |
| ⭐ | <stargazerCount> |
| 최근 업데이트 | <updatedAt> |
| 라이선스 | <license> |

**한 줄 결론**: 추천 / 조건부 (이유) / 비추천 (이유)

🟢 장점 2-3개
🟥 리스크 2-3개 (라이선스, 1인 OSS, 인용만, 의존성 등)

**옵션**
- A. ❌ 안 함
- B. 🟡 5분 preflight (대표 파일 1-2개만 확인)
- C. 🟢 도입 (코드 붙이기/설치 가이드 요청)
```

## Pitfalls (반드시 회피)

1. **`gh repo view --json readme` 빈 값 함정** — 항상 raw.githubusercontent.com로 fallback. 이 한 번에 readme 못 가져와서 시간 낭비하기 쉬움.

2. **`license: null` ≠ "missing data"** — null은 진짜 라이선스 미명시. ★100+ OSS도 라이선스 없는 경우 있음 → 비추천 사유 1순위로 사용.

3. **인용만 한 fork 의심** — `source_lineage:` 같은 frontmatter 필드에 외부 출처(every-layout.dev, carbon 등)만 있고 LICENSE가 None이면 그냥 fork인용. → 원작 링크를 우선 추천.

4. **⭐ 100 미만 + 기여자 1-2명 = 1인 OSS** — fork/localize 결정 전 신뢰도 평가 필요. 보안 감사가 필요하면 `skill-security-audit` 트리거.

5. **이름으로 카테고리 착각** — 사용자가 "ui 관련 스킬인가?" 물으면 → 스킬이 아니라 외부 라이브러리라는 점을 명확히 짚어주기. 메모리에 `astryx` 류 질문이 종종 옴.

6. **HEAD 150줄만 읽기** — README가 길면 `head -150`으로 잘라서 핵심만. 진짜 깊이 보고 싶을 때만 `limit` 키워드로 read_file 사용.

7. **macOS vs Linux date 문법** — `date -u -v-30d +...` (BSD/macOS) vs `date -u -d '30 days ago' +...` (GNU/Linux). 두 개 다 OR(`||`)로 묶어 양쪽 호환.

8. **swift/single-binary OSS는 cross-build 가능성 높음** — C++ 게임처럼 Linux CI로 macOS 바이너리 안 나옴. swift 단일 언어면 사용자 .app 빌드 직결 안내.

9. **사용자가 후속 작업 요청 시** — verdict만으로 끝내지 말고 옵션 3개 제시 후 사용자 선택 대기. 메모리 `큰 결정 단계적 검증` 준수.

## Anti-patterns (하지 말 것)

- ❌ 분석 텍스트 1000자 + 표 1개 → 메모리 위반. 표 5줄 + 결론 1줄.
- ❌ "사용할만 할까?"에 verdict 없이 "잘 모르겠어요" → 무조건 3 옵션 제시.
- ❌ 라이선스 None 보고도 "괜찮을 수도" 식으로 회피 → 직접적인 리스크로 짚기.
- ❌ README 다 읽고 나서 요약 → 150줄 head만으로 verdict 가능하면 거기서 멈추기.

## 후속 워크플로 연결

- verdict = **🟢 도입** + fork 계획 → `oss-fork-localization`
- verdict = **🟢 도입** + C++ 게임 → `cpp-game-koreanization`
- verdict = **🟡 조건부** + 보안 의심 → `skill-security-audit`
- verdict = **❌ 비추천** + 비슷한 거 추천 요청 → `github-trending-monitor` 또는 다음 세션에서 재질문

## 참조

- `references/quick-eval-commands.md` — 단축 명령 치트시트 (eval 루프용)
