---
name: github-repo-triage
description: 사용자가 GitHub URL을 던지며 "이거 뭔가?" / "사용할만 할까?" / "API 키 필요?" / "라이선스?" 식으로 빠르게 평가해달라고 물을 때 발동. gh CLI 메타데이터 → raw README → license/activity/source 점검로 5분 안에 verdict(추천/조건부/비추천 + 옵션) 산출. 단일 OSS 도입 의사결정 워크플로.
---

# github-repo-triage

사용자가 `https://github.com/<owner>/<repo>` URL을 던지며 빠르게 평가 요청할 때의 표준 워크플로. **5분 안에 답**하고, **명확한 verdict(추천/조건부/비추천) + 3개 이내 옵션**으로 끝내는 게 목표. 깊은 분석·fork·로컬라이즈는 이 스킬의 범위 밖 → 후속 스킬(`oss-fork-localization`, `cpp-game-koreanization` 등)로 인계.

## 트리거 조건

다음 중 하나라도 매칭되면 **무조건** 발동 (raw README 읽기 전 답변 금지):

- 사용자가 GitHub URL 던지고 단문 질문 (예: "이거 뭐지?", "사용할만 할까?", "API 키 필요?", "라이선스?", "관련 스킬 있어?")
- 카테고리 추측 요청 ("이거 AI 코딩용 터미널 아님?", "메뉴바 위젯이지?")
- "TOP N 추천해줘" 같이 비교 후보군 빠른 평가
- 새 의존성을 SI에 들이기 전 사전 검증
- README/about/about-not-verified 추측 답변 후 사용자 반박

트리거 안 됨: 이미 git clone 했거나 코드 작업 중 → `github-repo-management` / `oss-fork-localization` 사용.

> **메모**: 게임 fork 후보 8+개 비교 평가는 별도 스킬 `github-game-candidate-scouting`이 처리함 (장르 쿼리 뱅크, 5축 평가 매트릭스, 한국어 polish 임팩트 측정 등). 라이선스 커스텀 함정(`licenseInfo.key: "other"`), 한국어 잔존 비율 측정, `gh search repos -L` 플래그 등도 모두 그 스킬에 있음.

> **NEW (2026-07-31)**: pitfall #20 참조. "이거 뭐지?" 카테고리 추측 질문은 verify-first 워크플로 강제.

## 5단계 워크플로

### 1. 메타데이터 (10초)

```bash
gh repo view <owner>/<repo> --json name,description,url,primaryLanguage,stargazerCount,updatedAt,createdAt,licenseInfo,isFork,forkCount
```

빠른 1차 표에 넣을 5컬럼: **이름 / 설명 / 언어 / ⭐ / 최근 업데이트**.

### 1.5. CONTRIBUTING.md 확인 (NEW, 2026-07-28) — PR 가능/봉쇄 판정

```bash
gh api repos/<owner>/<repo>/contents/CONTRIBUTING.md?ref=<branch> | python3 -c "import sys,json,base64; d=json.load(sys.stdin); print(base64.b64decode(d.get('content','')).decode('utf-8','ignore')[:1500] if d.get('content') else 'NONE')"
```

**첫 30줄 안에 "We do not accept pull requests" / "This repository is a mirror" / "PRs will be closed" 같은 문구가 있으면 PR 봉쇄로 즉시 판정** (pitfall #12). 이건 license와 무관 — 정책적 봉쇄. sister-repo나 fork-only 경로로 verdict가 분기됨. 사용자가 "기여" 의도 보이면 **1단계 직후에 무조건** 확인할 것.

### 2. README raw (10초)

⚠️ **함정**: `gh repo view --json readme` 는 readme 필드를 비워서 반환함. 반드시 raw로:

```bash
curl -fsSL https://raw.githubusercontent.com/<owner>/<repo>/<branch>/README.md | head -150
```

기본 브랜치는 거의 항상 `main`이지만 모르면 `gh repo view ... --json defaultBranchRef` 로 확인.

### 3. 파일 인벤토리 (필요시 30초)

소스 의존성/스크립트 구조 보고 싶을 때:

```bash
gh api repos/<owner>/<repo>/git/trees/<branch>?recursive=1 | \
  python3 -c "import json,sys; d=json.load(sys.stdin); [print(t['path']) for t in d.get('tree',[])]"
```

확장자 분포·CSS/JS/MD 파일 수 빠르게 셀 때:

```bash
gh api repos/<owner>/<repo>/git/trees/<branch>?recursive=1 | python3 -c "
import json,sys,collections
d=json.load(sys.stdin)
ext=collections.Counter(p.rsplit('.',1)[-1] for p in [t['path'] for t in d.get('tree',[])] if '.' in p['path'])
print(dict(ext))
"
```

### 4. 활동성 / 기여자 (필요시 30초)

```bash
# 최근 30일 커밋 수 + 작성자 분포
gh api "repos/<owner>/<repo>/commits?per_page=100&since=$(date -u -v-30d +%Y-%m-%dT%H:%M:%SZ 2>/dev/null || date -u -d '30 days ago' +%Y-%m-%dT%H:%M:%SZ)" | \
  python3 -c "
import json,sys,collections
d=json.load(sys.stdin)
print('last 30d commits:', len(d))
authors=[(c.get('author') or {}).get('login') or (c.get('commit',{}).get('author') or {}).get('email') for c in d]
print(collections.Counter(authors).most_common())
"

# 기여자 수
gh api repos/<owner>/<repo>/contributors | python3 -c "
import json,sys
d=json.load(sys.stdin)
print('contributors:', len(d))
for c in d[:5]:
    print(' ', c.get('login'), c.get('contributions'))
"
```

### 5. Verdict 산출 (출력 템플릿)

**항상 5줄 이내 표 + 한 줄 결론 + 옵션 3개 이내**로 응답. 메모리 `응답 스타일: 짧은 명령. 미니멀. clarify 4옵션+추천` 준수.

```markdown
| 항목 | 값 |
|---|---|
| 이름 | <owner>/<repo> |
| 설명 | <description> |
| 언어 | <primaryLanguage> |
| ⭐ | <stargazerCount> |
| 최근 업데이트 | <updatedAt> |
| 라이선스 | <license> |
| **PR 가능** | **<허용 / sister-repo만 / 봉쇄>** |  ← CONTRIBUTING.md 1.5단계 결과
```
**한 줄 결론**: 추천 / 조건부 (이유) / 비추천 (이유)

🟢 장점 2-3개
🟥 리스크 2-3개 (라이선스, 1인 OSS, 인용만, 의존성 등)

**옵션**
- A. ❌ 안 함
- B. 🟡 5분 preflight (대표 파일 1-2개만 확인)
- C. 🟢 도입 (코드 붙이기/설치 가이드 요청)
```

## Pitfalls (반드시 회피)

1. **`gh repo view --json readme` 빈 값 함정** — 항상 raw.githubusercontent.com로 fallback. 이 한 번에 readme 못 가져와서 시간 낭비하기 쉬움.

2. **`license: null` ≠ "missing data"** — null은 진짜 라이선스 미명시. ★100+ OSS도 라이선스 없는 경우 있음 → 비추천 사유 1순위로 사용.

3. **인용만 한 fork 의심** — `source_lineage:` 같은 frontmatter 필드에 외부 출처(every-layout.dev, carbon 등)만 있고 LICENSE가 None이면 그냥 fork인용. → 원작 링크를 우선 추천.

4. **⭐ 100 미만 + 기여자 1-2명 = 1인 OSS** — fork/localize 결정 전 신뢰도 평가 필요. 보안 감사가 필요하면 `skill-security-audit` 트리거.

5. **이름으로 카테고리 착각** — 사용자가 "ui 관련 스킬인가?" 물으면 → 스킬이 아니라 외부 라이브러리라는 점을 명확히 짚어주기. 메모리에 `astryx` 류 질문이 종종 옴.

6. **HEAD 150줄만 읽기** — README가 길면 `head -150`으로 잘라서 핵심만. 진짜 깊이 보고 싶을 때만 `limit` 키워드로 read_file 사용.

7. **macOS vs Linux date 문법** — `date -u -v-30d +...` (BSD/macOS) vs `date -u -d '30 days ago' +...` (GNU/Linux). 두 개 다 OR(`||`)로 묶어 양쪽 호환.

8. **swift/single-binary OSS는 cross-build 가능성 높음** — C++ 게임처럼 Linux CI로 macOS 바이너리 안 나옴. swift 단일 언어면 사용자 .app 빌드 직결 안내.

9. **사용자가 후속 작업 요청 시** — verdict만으로 끝내지 말고 옵션 3개 제시 후 사용자 선택 대기. 메모리 `큰 결정 단계적 검증` 준수.

10. **장르/카테고리 비교 (8+ 후보) → 본 스킬 범위 밖** — `github-game-candidate-scouting` (게임), `open-source-similar-finder` (특정 프로젝트 대안) 사용. 라이선스 커스텀 함정, 한국어 잔존 비율 측정 등도 그쪽에 있음.

11. **Open Core / 비공개 본체 = "🟢 추천"으로 판정 금지 (NEW, 2026-07-27, athena-crisis-kr 실측)** — `ares/`, `deimos/` 같은 모노레포 워크스페이스가 `package.json`만 있고 `src/`가 비어있거나, `.gitignore`에 `src/generated/*` 같은 codegen 산출물이 추적 제외되어 있거나, README에 공식 배포 URL (athenacrisis.com 같은)이 있으면 **Open Core 정책 가능성 ↑**. **MIT 라이선스 + i18n 모듈 분리 + 한국어 0% 같은 표면 신호는 Open Core를 가리지 못함**. 워크스페이스별 파일 수 + `.gitignore` codegen 추적 + 공식 URL 3개 동시 매치 시 **조건부/비추천으로 판정**. → 진단 명령 + 판별 매트릭스 + 정리 워크플로는 `oss-fork-localization/references/athena-crisis-open-core-pitfall.md` 참조.

12. **PR 봉쇄 = CONTRIBUTING.md 1줄로 판정 (NEW, 2026-07-28, OpenMinis 실측)** — `CONTRIBUTING.md`에 "We do not accept pull requests" / "This repository is a mirror. PR has nowhere to land" / "Development happens in a private tree" 같은 문구가 있으면 **PR/이슈/외부 기여 전부 봉쇄**. 이건 라이선스(GPLv3든 MIT든)와 무관 — 정책적 거부. 판정 후 옵션:
    - **🟡 fork only (학습/내 빌드)** — GPL 가능 시, 외부 배포 의무 확인
    - **🟢 sister-repo 기여** — 같은 org의 AwesomeMinis/MinisSkills 같은 PR 받는 sister 저장소 안내
    - **🟢 issue-only 기여** — 코드 PR 거부라도 정식 이슈 리포트는 환영인 경우 많음
    verdict에 **"PR 가능/봉쇄"를 첫 줄에 박을 것**. 사용자가 "포트해서 기여" 같은 의도 보이면 1번 단계에서 CONTRIBUTING.md를 무조건 읽을 것 (license만 보고 추천하면 사고).

13. **clarify 연쇄 함정 (NEW, 2026-07-28)** — OpenMinis 세션에서 4번 연속 clarify (방향 → 깊이 → 후보 옵션) 끝에 사용자가 "그냥 해/포크만"으로 끊기는 패턴. **첫 clarify에 "권장 진행" 옵션을 하나 박고**, 2회째 clarify 전에는 **"지금 결정 안 주시면 이 옵션으로 진행합니다 (5초 카운트다운)"** 식으로 자동 진행 옵션을 명시. 3회째부터는 clarify를 멈추고 **자동 추천 진행 + 사후 보고**로 전환. 메모리 `응답 스타일: 짧은 명령. 미니멀`과 결합 — clarify는 1~2회, 3회째부터는 실행.

14. **`gh search repos` → 인증 사용자에게 1초 만에 HTTP 403 secondary rate limit (NEW, 2026-07-28)** — `gh search`는 인증된 user 토큰으로 호출되어 **secondary (abuse) rate limit**에 즉시 걸림. 빈 결과가 아니라 `HTTP 403: API rate limit exceeded for user ID …` 가 나옴. **해결**: GitHub REST API를 curl로 직접 호출. 토큰은 `TOKEN=$(gh auth token)`.
    ```bash
    curl -s -H "Authorization: token $TOKEN" -H "Accept: application/vnd.github.v3+json" \
      "https://api.github.com/search/repositories?q=<QUERY>&sort=stars&order=desc&per_page=15" \
      > /tmp/out.json
    python3 -c "import json; d=json.load(open('/tmp/out.json')); print(d['total_count']); ..."
    ```
    인증 토큰을 같이 보내면 primary 5000/h quota + 별도 abuse quota → 충분. 빈 stdout을 보고 --json 플래그 문제라고 의심하지 말 것.

15. **`gh search repos --json` 필드명은 REST API와 다름 (NEW, 2026-07-28)** — `gh` CLI는 camelCase + 축약: `stargazersCount`, `language`, `fullName`, `pushedAt`, `openIssuesCount`, `url`. REST API는 snake_case + 풀네임: `stargazers_count`, `language`(같음), `full_name`, `pushed_at`, `open_issues_count`, `html_url`. 흔한 실수:
    - `gh search ... --json primaryLanguage` → **필드 없음** (정확한 이름은 `language`)
    - `gh search ... --json name,fullName` 만 쓰면 stargazers는 따로 요청
    - 라이선스 처리는 두 API 모두 같음: `r.get('license') or 'NOASSERTION'`, dict면 `.get('spdx_id') or 'spdxId'`
    
    curl 직접 호출 시 옵션 `--sort stars`는 `gh search --sort stars` 와 동일하게 GitHub API 쿼리 파라미터로 전달. 검색 결과 0건일 때 --json 플래그 위치 의심보다 **rate limit**이나 **쿼리 매칭**을 먼저 의심할 것.

16. **검색 기반 후보 N개 평가는 단일 URL 트리아지와 다른 루프 (NEW, 2026-07-28)** — 사용자가 "AI·자동화 프로젝트 개선 후보 조사" 식으로 카테고리 측면에서 후보 풀을 요청하면 `references/search-driven-candidate-survey.md`의 6단계 루프로 전환. 핵심 차이: (a) 시드 검색 → 풀 (b) 풀 → 5개로 좁힘 (c) 5개에 메타데이터 일괄 (d) 면밀 점검 항목 일괄 (i18n / 외부 API / AGPL-3.0) (e) 매트릭스 비교 + 1위 추천. 단일 URL 트리아지의 5단계 워크플로는 그대로 유효 — 후보별 5단계를 도는 것.

17. **`gh search issues`는 silent hang → `issues?labels=X`로 우회 (NEW, 2026-07-28)** — `gh search repos`는 빨리 403 떨어지지만 `gh search issues` / `gh search prs`는 **30~60초 동안 stdout 안 찍고 멈춰 있다가 timeout**으로 죽음 (참고로 pitfall #14에서 다룬 403은 `gh search repos` 한정). 라벨별 오픈 이슈 카운트 (help-wanted / good-first-issue)가 필요하면:
    ```bash
    # ❌ 이건 hang
    gh search issues "repo:owner/repo is:open is:issue label:\"help wanted\"" --jq '.total_count'
    # ✅ 이렇게 직접 카운트
    gh api "repos/owner/repo/issues?labels=help%20wanted&state=open&per_page=1" --jq 'length'
    ```
    라벨 슬러그로 직접 필터하는 REST 엔드포인트는 빠르고, 빈 응답(`length=0`)이 곧 카운트 0을 의미. `?labels=help%20wanted`처럼 URL-encode 필요 (띄어쓰기). 이 우회로 5개 후보 루프가 멈추지 않음.

18. **1인 OSS 진단: 30일 머지 PR의 author 분포가 가장 정확한 신호 (NEW, 2026-07-28, mise 실측)** — 기존 pitfall #4는 "⭐100 미만 + 1-2명"로 좁음. ⭐31k인 `jdx/mise`도 외부에서 보면 활발해 보이지만, **30일 머지 PR 96건 중 `jdx` 본인이 50건 (52%)** 이면 1인 OSS. 진단 명령:
    ```bash
    gh api "repos/owner/repo/pulls?state=closed&per_page=100" --jq '
      [.[] | select(.merged_at != null and .merged_at > "<30d-ago>")
       | {author: .user.login}] | 
      group_by(.author) | map({author: .[0].author, count: length}) | sort_by(-.count) | .[0:5]'
    ```
    **판정 임계값**: 최상위 author가 머지 PR의 ≥ 40% 차지 → 1인 OSS. PR 환영도 메인테이너 1인의 의사결정에 좌우됨 (방향 바뀌면 즉시 봉쇄 가능). `jdx/mise`: 52% → 1인 OSS. `astral-sh/ruff`: 22% (carljm) → 코어팀 + 외부 분산. verdict에 "1인 OSS 성격" 박을 것.

19. **PR 활동성 측정 시 `merged_at != null` 필터 필수 (NEW, 2026-07-28)** — `state=closed`만 쓰면 "closed but not merged" PR (거절/취소/Superseded)도 포함되어 활동성이 부풀려짐. 30일 "PR 머지 수"는 정확히 다음처럼:
    ```bash
    gh api "repos/owner/repo/pulls?state=closed&per_page=100" \
      --jq '[.[] | select(.merged_at != null and .merged_at > "2026-06-28")] | length'
    ```
    `merged_at`은 ISO 8601 string, lexicographic 비교 가능. 시간 윈도우 계산 시 `date -u -v-30d +%Y-%m-%dT%H:%M:%SZ` (macOS) / `date -u -d '30 days ago' +...` (Linux) 두 문법 OR 패턴은 pitfall #7에서 이미 다룸.

20. **"이거 뭐지?" 트리거 시 verify-first 강제 (NEW, 2026-07-31, Kaku + openwork 이중 실수)** — 사용자가 GitHub URL 던지며 "이거 뭐지?" / "이건 AI 코딩용 터미널 아님?" / 카테고리 추측 묻기 식으로 물으면 **분류/추측 답변 전에 무조건 raw README + description + homepage fetch**. 두 번 연속 (Kaku = "메뉴바 위젯"으로 오답, openwork = 추측 답변) 동일한 실수 반복 후 사용자가 직접 정정함. 검증 안 된 추측 답변은 **사용자 신뢰 손상** + **다음 세션에 잘못된 컨텍스트 누적**.

    **워크플로**: raw README 1단계 → description 2단계 → 안 나오면 meta tag scrape. README 첫 30줄 + og:description만 봐도 카테고리는 확정 가능. "잘 모르겠습니다" + 5단계 워크플로 진행 중이라고 명시하는 게 추측 + 즉답보다 낫다.

    **anti-pattern**: README 안 읽고 "이거 대충 X 아닌가?" 식으로 답하는 것. 사용자 반박 들어오면 즉시 인정 (이미 두 번 함).

## Anti-patterns (하지 말 것)

- ❌ 분석 텍스트 1000자 + 표 1개 → 메모리 위반. 표 5줄 + 결론 1줄.
- ❌ "사용할만 할까?"에 verdict 없이 "잘 모르겠어요" → 무조건 3 옵션 제시.
- ❌ 라이선스 None 보고도 "괜찮을 수도" 식으로 회피 → 직접적인 리스크로 짚기.
- ❌ README 다 읽고 나서 요약 → 150줄 head만으로 verdict 가능하면 거기서 멈추기.

## 후속 워크플로 연결

- verdict = **🟢 도입** + fork 계획 → `oss-fork-localization`
- verdict = **🟢 도입** + C++ 게임 → `cpp-game-koreanization`
- verdict = **🟡 조건부** + 보안 의심 → `skill-security-audit`
- verdict = **❌ 비추천** + 비슷한 거 추천 요청 → `github-trending-monitor` 또는 다음 세션에서 재질문

## 참조

- `references/quick-eval-commands.md` — 단축 명령 치트시트 (eval 루프용)
- `references/i18n-contribution-eval.md` — 4-축 매트릭스로 한국어 i18n PR 가능성 점수화 (16-20점 = 즉시 PR)
- `references/search-driven-candidate-survey.md` — 카테고리 측면 후보 N개 풀 → 5개 → 매트릭스 1위 추천 루프 (AI 자동화 / 워크플로우 / 브라우저 자동화 등 평가 시)
