# i18n Contribution 가능성 평가 (2026-07-26 추가)

기존 `github-repo-triage` 의 verdict (추천/조건부/비추천) 에 더해, **"한글화 / i18n 기여할 만한가?"** 의사결정을 도와주는 4-축 매트릭스.

## 트리거

- "한글화할 만한 프로젝트 찾아줘"
- "개선/PR 보낼 만한 OSS 추천"
- "이 저장소 한국어 README 추가하면 머지될까?"

## 4-축 평가 (각각 1-5점, 합계 20점 만점)

| 축 | 평가 기준 | 1점 (최악) | 5점 (최고) |
|---|---|---|---|
| **A. i18n 구조 깔끔함** | messages/, locale/, lang/ 폴더 존재 + 다른 언어 README 있음 | 영어만, i18n 흔적 0 | 기존 zh/ja README + next-intl 등 i18n 라이브러리 사용 |
| **B. 메인테이너 활발도** | 최근 push 7일 이내 + open issues < 50 + 응답 빠름 | 마지막 push 30일+ 전, 200+ issues (burnout) | 7일 이내 push, < 20 issues, 1~3일 PR 응답 |
| **C. 한국 시장 가치** | 한국 사용자가 이 프로젝트 쓸 이유 | 한국 GFW/언어/시장 무관 | 한국에서 인기 + i18n 부재 = 명확한 가치 |
| **D. PR 작은 비용** | 변경 파일 수 + 컨벤션 엄격도 | 모노레포 10+ 파일 + strict CI | README 1파일 + 1줄 패치, 5분 작업 |

**판정**:
- 16-20점: 🟢 **즉시 PR 가능** — README만 추가해도 머지 가능성 70%+
- 12-15점: 🟡 **가벼운 PR 검토** — 1~2시간 작업, 머지 50%
- 8-11점: 🟠 **큰 PR 필요** — i18n 인프라 자체 추가, 5시간+
- 4-7점: 🔴 **비추천** — fork도 가치 낮음

## 실전 예시 (2026-07-26 검증)

### 🟢 neko-master (16점)

- A: 5 (next-intl + messages/en.json,zh.json 구조 완벽)
- B: 5 (하루 push, 24 issues, 응답 빠름)
- C: 3 (OpenClash 한국 사용자 소수, 하지만 i18n 가치 명확)
- D: 3 (3개 파일, 67% 번역은 30분 작업, 100%는 2시간)

→ **즉시 PR** → PR #84 (https://github.com/foru17/neko-master/pull/84) 67.1% 번역

### 🟢 i-have-adhd (19점)

- A: 5 (README.ja.md, README.zh-CN.md 이미 존재)
- B: 5 (7일 이내 push, 6 issues, 활발)
- C: 4 (ADHD 프롬프팅은 언어 무관, 한국 사용자 가치 큼)
- D: 5 (README 1파일 + 1줄 패치, 5분)

→ **즉시 PR** → PR #72 (https://github.com/ayghri/i-have-adhd/pull/72) 5분 작업

### 🟡 DietrichGebert/ponytail (14점)

- A: 4 (JS 프롬프트 패턴, 구조 깔끔)
- B: 5 (89.5k★ 폭발 인기, 활발)
- C: 3 (AI 코딩 에이전트 한국어 예시 가치)
- D: 2 (패턴 5~10개 한국어 번역 = 3~5시간)

→ **선택적** — 시간 여유 있으면 가치 큼

### 🟠 odysseus-dev/odysseus (8점)

- A: 3 (자체 i18n 구조 없음)
- B: 1 (936 issues, burnout 가능성)
- C: 2 (로컬 AI 워크스페이스, 한국 사용자 소수)
- D: 2 (모노레포 + i18n 인프라 자체 추가 = 10시간+)

→ **비추천** — 메인테이너 PR 안 받을 위험

## 빠른 스캐폴딩 명령

### 1) i18n 구조 점검 (10초)

```bash
# 기존 다른 언어 README 가 있는지 (가장 강한 시그널)
curl -s "https://api.github.com/repos/$REPO/contents/" | python3 -c "
import json, sys
d = json.load(sys.stdin)
readmes = [f['name'] for f in d if f.get('type') == 'file' and 'README' in f.get('name', '').upper()]
print('READMEs:', readmes)
"

# messages/ 폴더 (next-intl / i18next 패턴)
curl -s "https://api.github.com/repos/$REPO/contents/apps/web/messages" 2>/dev/null | python3 -c "
import json, sys
try:
    d = json.load(sys.stdin)
    if isinstance(d, list):
        print('messages:', [f['name'] for f in d])
except: print('no messages/')
"
```

### 2) 메인테이너 활발도 (5초)

```bash
curl -s "https://api.github.com/repos/$REPO" | python3 -c "
import json, sys
d = json.load(sys.stdin)
print(f'pushed={d[\"pushed_at\"][:10]} issues={d[\"open_issues_count\"]} stars={d[\"stargazers_count\"]}')
"
```

### 3) 한국 시장 가치 (판단)

- 한국어 검색어 `"<project name>" 한국어` 로 한국 블로그/Reddit 글 있는지
- OpenClash/Surge 같은 한국 친화 도구 → 3점
- 한국어 자료 전혀 없음 → 1점

## PR 템플릿 (3-라인 요약)

```
title: "docs(i18n): add Korean (ko) README"
body: 
- 뭐 했는지 (1-2 bullets)
- 컨벤션 준수 (브랜드/도구명 그대로, 10규칙 등)
- 왜 작은 PR 인지 (1-2 bullets)
```

## 함정

1. **큰 PR 보내지 말 것** — README 1파일 + 1줄 패치보다 크면 머지율 급락
2. **machine-translation 티 내지 말 것** — 한국어 어색하면 메인테이너 한국어 네이티브 리뷰어 요청 가능
3. **zh/ja README 있는 프로젝트 우선** — 기존 다국어 운영 = PR 거의 무조건 머지
4. **1인 OSS 조심** — 메인테이너 1명 + 100+ issues = burnout, PR 무시당함
5. **로열티 요구하는 라이선리는 피하기** — AGPL/SSPL 등 — 한국어 README 만 추가해도 라이선스 영향
