# Search-Driven Candidate Survey (2026-07-28)

`github-repo-triage`의 변형 모드. 사용자가 **카테고리**(AI 자동화, 워크플로우, 브라우저 자동화 등) 측면에서 후보 풀을 던지거나 "이 분야 개선 후보 N개 조사" 같은 요청을 할 때 사용. 단일 URL 트리아지의 5단계를 후보별로 돌리는 매트릭스 패턴.

## 트리거

- "AI·자동화 프로젝트 개선 후보 조사" 같이 카테고리 기반 풀 요청
- "TOP N 추천해줘" (단, 사용자가 후속 결정 권한을 갖고 있을 것 — 단순 평가만 필요하면 OK)
- "X 분야 OSS 후보다/대안/포트 후보" 식의 비교
- 라이선스/활동성/한국어 i18n 친화도 같은 다축 매트릭스가 자연스러운 경우

## 6단계 루프

### 0. 시드 쿼리 결정 (10초)

- 카테고리 키워드 1-3개 선정 (예: `"ai automation"`, `"workflow automation llm"`, `"browser automation agent"`)
- 라이선스 면제 후보가 있으면 사전 필터 — `&license=mit` 또는 `&license=apache-2.0`
- 한국어 i18n 친화도를 보고 싶으면 별도 패스 (5단계에서 일괄)

### 1. 시드 검색 — curl REST 직접 (5-10초)

⚠️ **함정**: `gh search repos` 는 인증 사용자 토큰으로 호출되어 **즉시 HTTP 403 secondary rate limit** — 무조건 curl REST 사용. 자세한 함정은 SKILL.md pitfall #14.

```bash
TOKEN=$(gh auth token)
curl -s -H "Authorization: token $TOKEN" -H "Accept: application/vnd.github.v3+json" \
  "https://api.github.com/search/repositories?q=ai+automation+platform&sort=stars&order=desc&per_page=15" \
  > /tmp/c1.json

python3 -c "
import json
d = json.load(open('/tmp/c1.json'))
print('Total:', d.get('total_count'), '| returned:', len(d.get('items', [])))
for r in d.get('items', [])[:15]:
    lic = (r.get('license') or {}).get('spdx_id') or 'NOASSERTION'
    desc = (r.get('description') or '')[:75]
    print(f\"{r['stargazers_count']:>6}★ | {r['full_name']:<40} | {lic:<10} | pushed={r['pushed_at'][:10]} | open_issues={r['open_issues_count']:>4} | {desc}\")
"
```

**시드 2-3개 쿼리** 돌려서 풀 다양성을 확보 (예: `"ai automation"` / `"workflow automation llm"` / `"browser automation agent"`). 같은 카테고리라도 쿼리마다 다른 후보가 나옴.

### 2. 풀 → 5개 좁힘 (1분)

**선택 기준 (우선순위 순)**:
1. **라이선스** — MIT / Apache-2.0 > AGPL-3.0 (fork·배포 가능성)
2. **활동성** — 7d 커밋 ≥ 5 (정지/감속 프로젝트 제외)
3. **⭐ 다양성** — 풀에서 ⭐ 분포 보고 상위 1-2개 + 중간 2-3개 (검증된 인기도 + 신선한 후보)
4. **중복 제거** — 같은 카테고리 풀에서 서로 다른 니치 (워크플로 / 스크래핑 / 브라우저 자동화 등)
5. **외부 의존성 눈에 띄는 것** — SaaS 가입 필요, AGPL-3.0, 컨트리뷰터 1-2명 등

`★ ≥ 4k` 가 부족하면 풀 자체를 다시 — 시드 쿼리 변경하거나 검색어 1단어 더.

### 3. 후보별 1차 메타 일괄 (30초/후보)

```bash
TOKEN=$(gh auth token)
for repo in "owner1/repo1" "owner2/repo2" ...; do
  curl -s -H "Authorization: token $TOKEN" "https://api.github.com/repos/$repo" | python3 -c "
import json, sys
r = json.load(sys.stdin)
print(f\"  {r['full_name']} | Stars: {r['stargazers_count']} | Forked: {r['fork']} | Archived: {r['archived']}\")
print(f\"  License: {(r.get('license') or {}).get('spdx_id') or 'NOASSERTION'}\")
print(f\"  Lang: {r.get('language')} | Size: {r['size']}KB\")
print(f\"  Pushed: {r['pushed_at'][:10]} | Open issues(=issues+PRs): {r['open_issues_count']}\")
"
done
```

### 4. 후보별 2차 면밀 점검 일괄 (1분/후보)

다음 4개 항목을 **for 루프로 한 번에** — 매트릭스 비교에 직결:

```bash
TOKEN=$(gh auth token)
for repo in "owner1/repo1" "owner2/repo2" ...; do
  echo "=== $repo ==="
  # (a) 최근 PR 5개 — 메인테이너 활동 + 컨벤션 힌트
  curl -s -H "Authorization: token $TOKEN" "https://api.github.com/repos/$repo/pulls?state=open&per_page=5&sort=updated&direction=desc" \
    | python3 -c "
import json, sys
prs = json.load(sys.stdin)
if isinstance(prs, list):
    for p in prs[:5]:
        labels = [l['name'] for l in p.get('labels', [])]
        print(f\"  PR #{p['number']} | updated={p['updated_at'][:10]} | {p['title'][:70]} | labels={labels}\")
"
  # (b) help-wanted / good-first-issue 카운트 (PR 받기 의향)
  for label in "help-wanted" "good-first-issue"; do
    curl -s -H "Authorization: token $TOKEN" \
      "https://api.github.com/search/issues?q=repo:$repo+label:$label+state:open&per_page=1" \
      | python3 -c "import json,sys; print(f'  $label open: {json.load(sys.stdin).get(\"total_count\",0)}')"
  done
  # (c) Dockerfile / Compose / 워크플로 존재 → CI 성숙도 + 실행 가능성
  for f in ".github/workflows" "Dockerfile" "docker-compose.yml"; do
    code=$(curl -s -o /dev/null -w "%{http_code}" -H "Authorization: token $TOKEN" "https://api.github.com/repos/$repo/contents/$f")
    [ "$code" = "200" ] && echo "  EXISTS: $f ($code)"
  done
  # (d) 30 커밋 활동성 (7d / 30d / unique authors)
  curl -s -H "Authorization: token $TOKEN" "https://api.github.com/repos/$repo/commits?per_page=30" | python3 -c "
import json, sys, datetime
items = json.load(sys.stdin)
now = datetime.datetime.utcnow()
recent30 = sum(1 for it in items if (now - datetime.datetime.fromisoformat(it['commit']['author']['date'].replace('Z',''))).days <= 30)
recent7 = sum(1 for it in items if (now - datetime.datetime.fromisoformat(it['commit']['author']['date'].replace('Z',''))).days <= 7)
authors = len(set(it['commit']['author']['email'] for it in items if it.get('commit',{}).get('author',{}).get('email')))
print(f'  7d={recent7} 30d={recent30} authors={authors}')
"
done
```

### 5. 한국어 친화도 일괄 (1분)

```bash
TOKEN=$(gh auth token)
for repo in ...; do
  # (a) 한국어 README 별칭 파일
  for branch in main master; do
    for f in "README.ko.md" "README.kr.md" "README_KO.md" "i18n/ko.md" "docs/ko/README.md"; do
      code=$(curl -s -o /dev/null -w "%{http_code}" -H "Authorization: token $TOKEN" "https://raw.githubusercontent.com/$repo/$branch/$f")
      [ "$code" = "200" ] && echo "  KO README EXISTS: $branch/$f"
    done
  done
  # (b) 한국어 관련 이슈/PR 검색
  curl -s -H "Authorization: token $TOKEN" \
    "https://api.github.com/search/issues?q=repo:$repo+korean+OR+%ED%95%9C%EA%B5%AD%EC%96%B4+state:any&per_page=1" \
    | python3 -c "import json,sys; print('  KO issues:', json.load(sys.stdin).get('total_count',0))"
done
```

**판정 매트릭스**:
- 한국어 README 0 + 한국어 이슈 0 + 기존 다국어 README ≥ 3 → **🟢 즉시 PR 가능 (16-20점)**
- 한국어 README 0 + 한국어 이슈 0 + 기존 다국어 0-2 → **🟡 단일 README PR 검토**
- 한국어 README 0 + 한국어 이슈 ≥ 1 (이전 시도 거부됨) → **🔴 메인테이너 의향 불명**

자세한 점수 매트릭스는 `references/i18n-contribution-eval.md` 참조.

### 6. 매트릭스 + verdict (출력)

응답은 **5개 후보 매트릭스 표 1개 + 1위 추천 1줄 + 옵션 3개**로 종결. deep analysis / fork / PR 작업은 본 스킬 범위 밖.

```markdown
| 후보 | 라이선스 | 7d 커밋 | 다국어 README | 한국어 | 한국어 PR 적합성 |
|---|---|---|---|---|---|
| owner1/repo1 | MIT | 18 | EN/ZH | ❌ | ★★★ |
| owner2/repo2 | AGPL-3.0 | 30 | EN | ❌ | ★ (배제 사유) |
| ... | ... | ... | ... | ... | ... |

**최종 추천**: owner1/repo1 (이유 3개)
**후속 옵션**:
- A. ❌ 이번엔 안 함
- B. 🟡 이 후보만 5분 preflight (raw README 더 읽기)
- C. 🟢 도입 (fork + PR 작업)
```

## 실전 예시 (2026-07-28 시드)

**질문**: "AI·자동화 프로젝트 개선 후보를 조사하세요."

**시드 쿼리 3개**: `"ai automation"`, `"workflow automation llm"`, `"browser automation agent"`

**풀에서 5개 좁힘** (⭐ + 라이선스 + 다양성):
- web-infra-dev/midscene (MIT, 14.4k★, 비전 기반 UI 자동화)
- getmaxun/maxun (AGPL-3.0, 16.9k★, 노코드 스크래핑)
- bytedance/flowgram.ai (MIT, 8.3k★, 워크플로 캔버스)
- browser-act/skills (MIT, 4.9k★, 브라우저 자동화 CLI)
- TracecatHQ/tracecat (AGPL-3.0, 3.7k★, 보안 자동화)

**한국어 친화도 매트릭스**:
- flowgram.ai: EN/ZH/ES/RU/PT/DE/JA **6개국어 한국어만 비어있음** → 🟢 16점
- midscene: EN/ZH 만 → 🟡 13점
- browser-act/skills: 영문만, 메인테이너 2명 → 🟠 9점
- maxun: AGPL-3.0 (실행 가능성 ↓) → 🟡
- tracecat: AGPL-3.0 + 보안 특화 → 🟡

**최종 추천**: flowgram.ai (MIT, 6개국어 패턴 = 한국어만 빈자리, PR 정당성 최강, Rate limit 잔여 충분).

## 함정 (이 모드 한정)

1. **풀에서 한 카테고리로 편중** — 시드 쿼리 2개 이상 돌려 워크플로 vs 스크래핑 vs 브라우저 등 서로 다른 니치를 포괄할 것. 한 쿼리만 돌리면 동일 부모/오너의 fork가 다수 나옴.
2. **`pushed_at` vs `updated_at` 헷갈리기** — `pushed_at`이 commit 활동, `updated_at`은 이슈/PR/릴리즈 등 메타데이터 변경도 포함. 활동성 판단은 `pushed_at` 사용.
3. **⭐ 1k 미만 후보도 무시하지 말 것** — `browser-act/skills` 처럼 신규 후보가 "⭐ 적음 + 7d 커밋 多" 조합이면 가벼운 PR 더 잘 받아들여짐. ⭐ < 1k + 30d 0 커밋만 진짜 정지 후보.
4. **메인테이너 활동성 vs 신규 PR 받기 의향 별개** — 7d=0 커밋이라도 `help-wanted` / `good-first-issue` 라벨이 활성이면 메인테이너가 외부 PR 환영일 수 있음. 라벨 카운트 0이면 보수적으로 평가.
5. **bash for-loop에서 인증 토큰 매번 호출** — `$(gh auth token)`이 keyring을 5회 hit — `TOKEN=$(gh auth token); curl ... -H "Authorization: token $TOKEN"` 식으로 한 번 추출해 재사용. 매 호출마다 keyring hit하면 5개 후보 루프에서 150회 hit.
6. **빈 stdout ≠ 정상** — `gh search`이 403 떨어질 때 stderr만 채우고 stdout은 비어서 빈 파일이 됨. `2>/dev/null > /tmp/...` 패턴은 stderr 자체를 삼키므로 403 메시지도 못 봄. **반드시 `2>&1` 또는 에러 출력 보존**.
7. **per_page=15가 max 아님** — GitHub REST search는 `per_page=100` 까지 받음. 큰 풀 받을 때는 30-100으로 올려도 됨. 단 `total_count`는 API가 page 1 응답에 제공하므로 페이지네이션 풀지 않아도 됨.
