# Quick Eval Commands Cheatsheet

GitHub URL 빠른 평가용 단축 명령 모음. 모든 명령은 `<owner>/<repo>` 플레이스홀더 사용. 한 줄씩 복붙 가능.

## 1. 메타 1차 (필수)

```bash
gh repo view <owner>/<repo> --json name,description,url,primaryLanguage,stargazerCount,updatedAt,createdAt,licenseInfo,isFork,forkCount
```

## 2. README (raw fallback 필수)

```bash
curl -fsSL https://raw.githubusercontent.com/<owner>/<repo>/main/README.md | head -150
```

브랜치 불명 시:

```bash
gh repo view <owner>/<repo> --json defaultBranchRef -q .defaultBranchRef.name
```

## 3. 파일 인벤토리

```bash
# 전체 트리
gh api repos/<owner>/<repo>/git/trees/main?recursive=1 | \
  python3 -c "import json,sys; d=json.load(sys.stdin); [print(t['path']) for t in d.get('tree',[])]"

# 확장자 분포 + 파일 수
gh api repos/<owner>/<repo>/git/trees/main?recursive=1 | python3 -c "
import json,sys,collections
d=json.load(sys.stdin)
paths=[t['path'] for t in d.get('tree',[])]
ext=collections.Counter(p.rsplit('.',1)[-1] for p in paths if '.' in p)
print('total files:', len(paths))
print('ext:', dict(ext))
print('css files:', sum(1 for p in paths if p.endswith('.css')))
print('md files:', sum(1 for p in paths if p.endswith('.md')))
print('mjs files:', sum(1 for p in paths if p.endswith('.mjs')))
"
```

## 4. 활동성

```bash
# 최근 30일 커밋 수 + 작성자 분포 (BSD/GNU date 양쪽 호환)
gh api "repos/<owner>/<repo>/commits?per_page=100&since=$(date -u -v-30d +%Y-%m-%dT%H:%M:%SZ 2>/dev/null || date -u -d '30 days ago' +%Y-%m-%dT%H:%M:%SZ)" | \
  python3 -c "
import json,sys,collections
d=json.load(sys.stdin)
print('last 30d commits:', len(d))
authors=[(c.get('author') or {}).get('login') or (c.get('commit',{}).get('author') or {}).get('email') for c in d]
print(collections.Counter(authors).most_common())
"

# 기여자 수 + 상위 5명
gh api repos/<owner>/<repo>/contributors | python3 -c "
import json,sys
d=json.load(sys.stdin)
print('contributors:', len(d))
for c in d[:5]:
    print(' ', c.get('login'), c.get('contributions'))
"
```

## 5. 패턴 파일 단발 샘플

```bash
# 패턴/예제 카테고리 1개 헤드
gh api repos/<owner>/<repo>/contents/<subdir> 2>/dev/null | python3 -c "
import json,sys
d=json.load(sys.stdin)
for it in d:
    print(it.get('type'), it.get('name'))
"
```

## 6. 한방 풀 eval (eval 루프용)

```bash
gh repo view <owner>/<repo> --json name,description,url,primaryLanguage,stargazerCount,updatedAt,createdAt,licenseInfo,isFork,forkCount
curl -fsSL https://raw.githubusercontent.com/<owner>/<repo>/main/README.md | head -150
gh api repos/<owner>/<repo>/git/trees/main?recursive=1 | python3 -c "
import json,sys,collections
d=json.load(sys.stdin)
paths=[t['path'] for t in d.get('tree',[])]
ext=collections.Counter(p.rsplit('.',1)[-1] for p in paths if '.' in p)
print('total:', len(paths), 'ext:', dict(ext))
"
gh api repos/<owner>/<repo>/contributors | python3 -c "
import json,sys
d=json.load(sys.stdin)
print('contributors:', len(d))
"
```

## 알려진 함정

- `gh repo view --json readme,licenseInfo` → readme 필드 항상 빈 문자열. raw fallback 필수.
- macOS `gh api ...?since=...` 에서 `date -v-30d` BSD 문법 사용. CI가 Linux면 `date -d '30 days ago'`. OR 묶기.
- `gh api repos/.../contents/<path>` 응답이 큰 디렉토리면 truncation. recursive=1로 트리 받는 게 안전.
- 빈 응답 (예: package.json 404) → 라이선스 누락보다 흔함. 트리 먼저 보고 존재 확인.

## 예시 실행 결과 (2026-07-21 StyleGallery)

```
total files: 167
ext: {'github': 1, 'github/CODEOWNERS': 1, 'github/workflows': 1, 'yml': 1, 'md': 113, 'json': 4, 'mjs': 22}
css files: 0
md files: 113
mjs files: 22
contributors: 4
last 30d commits: 30
```

→ 이 한 방으로 "MD 카탈로그 113 + .mjs 22 + CSS 0 + 기여자 4 + 1인 OSS 다수" 결론 즉시 가능.
