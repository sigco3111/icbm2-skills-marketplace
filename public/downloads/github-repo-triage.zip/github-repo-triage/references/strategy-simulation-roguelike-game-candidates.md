# 전략/시뮬/로그라이크/샌드박스 게임 후보 풀 (2026-07-27 실측)

이 문서는 `gh search repos` + 라이선스 + 한국어 외부화 실측으로 검증된 게임 후보 목록. 다음 세션의 "추천해줘" 류 요청에서 즉시 비교표로 활용 가능.

## 🥇 최상위 후보 (한국어화 즉시 시작 가능)

### pmotschmann/Evolve ⭐ 1,185 — 최우선
- **repo**: https://github.com/pmotschmann/Evolve
- **license**: MPL-2.0 (permissive, 파일 단위 copyleft)
- **카테고리**: 증분 + 문명 진화 + 매크로 관리 (SNKRX와 정반대)
- **언어/빌드**: JavaScript + LESS, `npm run build` → GitHub Pages 자동 배포
- **한국어 상태**: `strings/strings.ko-KR.json` **이미 머지**, `src/locale.js`에 `ko-KR` 등록 완료
- **한국어 완성도**: 10,164 키 중 1,213개 (12%) 영문 잔존 — **polish 임팩트 큼**
- **외부화 모범**: `strings/strings.<locale>.json` 형식, `%0`/`%1` 토큰 시스템, `checkStrings.py`/`updateStrings.py` 자동화
- **메인테이너**: pmotschmann 직접 활동 중 (2026-06 활발)
- **추천 작업**: `gh repo fork pmotschmann/Evolve` → strings/strings.ko-KR.json 다듬기 → PR

### nroutasuo/level13 ⭐ 259 — 차선
- **repo**: https://github.com/nroutasuo/level13
- **license**: Apache-2.0 (permissive)
- **카테고리**: 텍스트 로그라이키 + SF + 자원 관리 + 도시 건설
- **언어/스택**: jQuery + Require.js + Ash.js ECS, 789 파일 (src js 313)
- **한국어 상태**: 영어 메인 (`strings/strings.json` 236KB), 핀란드어 별도 (`-fi.json` 패턴)
- **외부화 구조**: `strings/strings.json` + `messages.json` 분리 깔끔
- **메인테이너**: 6월 활발 (`[world]`, `[ui]`, `[dev]` prefix 커밋)
- **추천 작업**: `strings/strings-ko.json` 신규 생성 (기계번역 + 다듬기 4-6시간 추정) → 한국적 시설/이벤트 데이터 추가

### Tendsty/gooboo ⭐ 115 — 3순위
- **repo**: https://github.com/Tendsty/gooboo
- **license**: GPL-3.0 (copyleft, 동일 라이선스 공개 의무)
- **카테고리**: 증분 + 미니게임 + 통계
- **언어/스택**: Vue 2 + Pinia (한국 친화적 스택)
- **한국어 상태**: vue-i18n 시스템 있음, 일부 미번역 가능 (디버그 모드 미번역 명시)
- **추천 작업**: `locales/ko.json` 추가/보완

## ❌ 제외 후보 (실측으로 사유 확인)

| 후보 | ⭐ | 제외 사유 |
|---|---|---|
| **R74nCom/sandboxels** | 439 | **R74n Content License v1.1** — "We reserve the right to request that you remove our content from your project at any time, for any reason" + 상업용도 금지. PR/fork 가치 없음. |
| **ihtasham42/progress-knight** | 174 | 2021년 이후 5년 무활동 — 사실상 죽은 프로젝트 |
| **Patashu/break_infinity.js** | 247 | 게임이 아닌 JavaScript 수학 라이브러리 (분류 오류) |
| **TotomInc/skid-inc** | 43 | `licenseInfo: null` — 라이선스 미명시 |
| **Anuken/Mindustry** | 28,374 | GPL-3.0 fork는 가능하나 Java 코드베이스 거대 — 모드/번역 기여가 fork보다 현실적 |

## 검증된 검색 패턴 (재사용)

```bash
# 카테고리별 후보 발굴 (실측 성공 패턴)
gh search repos "strategy roguelike game" --sort stars -L 10 --json name,owner,description,stargazersCount,language,updatedAt
gh search repos "incremental game" --sort stars -L 15 --json ...
gh search repos "topic:tower-defense" --sort stars -L 15 --json ...
gh search repos "topic:autobattler" --sort stars -L 10 --json ...
gh search repos "topic:sandbox-game" --sort stars -L 10 --json ...
gh search repos "topic:incremental-game" --sort stars -L 15 --json ...
gh search repos "topic:roguelike" --sort stars -L 15 --json ...
gh search repos "topic:text-based-game" --sort stars -L 10 --json ...
```

## 외부화 구조 빠른 판별 패턴

```bash
# 한국어/strings/lang 디렉터리 존재 확인
gh api repos/<owner>/<repo>/git/trees/<branch>?recursive=1 \
  | jq -r '.tree[] | select(.path | test("strings|lang|i18n|locale|messages"; "i")) | .path'

# 한국어 strings 파일 직접 다운로드 시도
curl -fsSL https://raw.githubusercontent.com/<owner>/<repo>/<branch>/<path>/<filename>.ko.json

# 한국어 완성도 실측 (한글 음절 0xAC00~0xD7A3 비율)
curl -fsSL <url> | python3 -c "
import json,sys
d=json.loads(sys.stdin.read())
not_ko = [k for k,v in d.items() if v and not any(0xAC00 <= ord(c) <= 0xD7A3 for c in v) and len(v) > 5]
print(f'non-korean (longer values): {len(not_ko)}/{len(d)}')
"
```

## 라이선스 커스텀 케이스 본문 키워드

라이선스 본문 다운로드 후 다음 문구 포함 시 비추천:

```bash
curl -fsSL https://raw.githubusercontent.com/<owner>/<repo>/<branch>/LICENSE \
  || curl -fsSL https://raw.githubusercontent.com/<owner>/<repo>/<branch>/license.txt
```

차단 키워드:
- `"commercial purposes"` + 금지 문구 → fork 가치 의문
- `"reserve the right to request"` + 제거 요구 → 권리 불안정
- `"All Rights Reserved"` → 사실상 사용 불가

## 평가 매트릭스 (희정님 워크플로우용)

7개 항목 × 5점 만점, 한국어화+독자 기능 워크플로우에 가중치:

1. 한국어화 난이도 (높을수록 쉬움)
2. 외부화 구조 점수
3. 활동성
4. 라이선스 친화도
5. 독자 기능 임팩트 (fork 후 추가 가능성)
6. 실행/빌드 용이성
7. SNKRX/이전 fork 프로젝트와의 차별성

2026-07-27 점수:
- Evolve 34/35
- Level 13 32/35
- Gooboo 29/35

## 작업 흐름 (확정)

```bash
# Phase 1: Evolve 한국어 polish (가장 빠른 임팩트)
gh repo fork pmotschmann/Evolve --clone
# strings/strings.ko-KR.json → 1,213개 영문 잔존 정리
# strings/checkStrings.py로 검증
gh pr create --repo pmotschmann/Evolve ...

# Phase 2: Level 13 한국어 풀번역 + 콘텐츠 추가
gh repo fork nroutasuo/level13 --clone
# strings/strings-ko.json 생성 (236KB 기계번역 + 다듬기)
# 한국적 시설/이벤트 데이터 추가
```