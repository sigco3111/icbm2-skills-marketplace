---
name: godot-dialogue-manager-localization
title: Korean Localization for Dialogue Manager
description: Korean UI localization workflow for Dialogue Manager.
trigger: "When needing Korean UI for Dialogue Manager."
category: localization
---

## Overview
Provides a class‑level workflow to set the project locale to Korean, edit test scene labels, and verify the UI appears in Korean.

### Prerequisites
- Godot 4.7+ installed.
- Access to the project directory.
- Existing `addons/dialogue_manager/l10n/ko.po` file.

## Steps
1. **Configure project locale** – add/replace in `project.godot` under `[internationalization]`:
   ```ini
   [internationalization]
   locale="ko"
   locale/language_filter=["ko"]
   locale/translations=PackedStringArray("res://addons/dialogue_manager/l10n/ko.po")
   ```
2. **Edit test scene labels** – in `tests/tests.tscn` replace:
   - `"Tests"` → `"테스트"`
   - `"Assertions"` → `"검증"`
   - `"Seconds"` → `"초"`
3. **Verify** – run headless:
   ```bash
   godot --headless --path . res://tests/tests.tscn
   ```
   Output should show Korean labels and `85 tests with 367 assertions`.
4. **Optional extension** – add any missing UI strings to `ko.po` and restart Godot.

## Pitfalls & Tips
- Forgetting `locale="ko"` loads the PO but UI stays English.
- Leaving the old language filter (`["de", "en"]`) blocks Korean; replace it.
- Apply locale changes before editing scenes to avoid loading before the locale is active.
- Keep CSharpState autoload removed unless C# is required.

## Verification
Confirm console output shows the Korean labels and the test suite passes.

## References
- `references/localization_guide.md` – session transcript and command notes.
