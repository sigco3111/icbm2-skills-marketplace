---
name: rust-frontend-monorepo-setup
description: Rust 백엔드 (cargo workspace) + WASM shared crate + Vite/Svelte/React 프론트엔드 풀스택 모노레포를 Hermes PC에 처음 셋업 + cold build + 동시 구동하는 워크플로. OpenMMO가 첫 실측 사례 (2026-07-22). **rustup + cargo-watch + wasm-pack 3종 cold install이 11분**, **cargo cold build (objc2-foundation 포함)는 5~10분**, **wasm-pack cold build는 wasm-bindgen-cli 6분 자체 빌드 = 13~15분**, **cargo 빌드와 wasm-pack 빌드는 동시 실행 시 CPU 경합으로 서로 2배 느려짐**. "이 저장소 Rust인데 어떻게 실행해?", "OpenMMO 빌드해줘", "cargo + npm 풀스택 셋업" 요청에 발동.
version: 0.1.0
author: HyeRin (Hermes)
license: MIT
metadata:
  hermes:
    tags: [rust, cargo, wasm, wasm-pack, vite, monorepo, setup, m4, apple-silicon, cold-build, parallel-build, openmmo]
    related_skills: [mac-bootstrap, godot-game-bootstrap, oss-fork-localization, opencode-cli-free-models]
---

# Rust + WASM + Vite 풀스택 모노레포 셋업

> 첫 사례: **Julian-adv/OpenMMO** (Rust + WASM shared + Svelte/Three.js 클라이언트, PolyForm Noncommercial).
> 일반화: cargo workspace + WASM shared crate + Vite/Svelte/React 풀스택 게임/앱 모두 적용.

## 언제 발동하나

- "이 저장소 Rust인데 실행 방법 알려줘"
- "OpenMMO 빌드해줘", "OpenMMO 셋업"
- "cargo 워크스페이스 + npm 풀스택", "Rust 서버 + JS 클라이언트"
- `Cargo.toml` + `client/package.json` + `wasm-pack build` 흔적이 있는 모노레포
- `client/.env.example` + `cargo` env 양쪽에 같은 키(예: Google OAuth) 주입 패턴
- `ports 10006 + 10004` 같은 서버/클라이언트 분리 포트 패턴

## Cold Install 타임라인 (M4 macOS 26.5, 16GB, 실측)

| 단계 | 도구 | 시간 | 백그라운드 |
|---|---|---|---|
| 1 | rustup + stable-aarch64-apple-darwin | **78초** | ✅ 가능 |
| 2 | `npm install` (node 22 + 패키지) | 5~15초 | ❌ foreground |
| 3 | `.venv` + `uv` (Python 데이터 도구) | 5초 | ❌ foreground |
| 4 | `cargo install cargo-watch` | **6분 19초** | ✅ 권장 (objc2-foundation 거대) |
| 5 | `cargo install wasm-pack` | **3분 29초** | ✅ 권장 (wasm-bindgen-cli 빌드) |
| 6 | `cargo watch -w server ...` 첫 실행 (cold) | 4~5분 | ❌ blocking |
| 7 | `wasm-pack build` 첫 실행 (cold) | **13분 27초** | ❌ blocking |
| 8 | Vite ready | 3.4초 | ❌ blocking |
| **합계** | | **약 33분** | |

> **CPU 경합 함정 (가장 중요)**: 6번과 7번을 **동시에 백그라운드로 띄우면 둘 다 2배 느려짐**. rustc 인스턴스가 동시에 CPU 점유 → cargo 빌드는 4분→8분, wasm 빌드는 13분→20분. **순차 실행**이 총합 더 빠름.

## 단계별 셋업 워크플로

### Phase 1: 환경 진단 + 클론 (5초)

```bash
mkdir -p ~/work && cd ~/work
git clone <repo-url> <project-name>  # 5~15초
cd <project-name>
ls Cargo.toml client/package.json  # 모노레포 구조 확인
```

**구조 진단 출력** (OpenMMO 예시):
```
Cargo.toml          ← workspace: agent-client, server, shared, terrain, tools/terrain-gen
client/package.json ← Vite + Svelte + Three.js (Threlte)
shared/Cargo.toml   ← crate-type = ["cdylib", "rlib"]  ← WASM 타겟
```

**즉시 분류**:
- `shared`에 `cdylib` 있으면 → WASM 빌드 필수
- `client/` 디렉토리에 `package.json` → Vite/npm 워크플로
- 둘 다 있으면 → **이 스킬 적용**

### Phase 2: 병렬 cold install (11분)

**3개를 동시에** 띄우되, **빌드 캐시 의존성 없으니** 동시 OK (cold install은 disk I/O bound).

```bash
# 1) rustup — background 가능
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y --default-toolchain stable --profile minimal

# 2) npm install — foreground (node_modules 생성, 5~15초)
cd client && npm install && cd ..

# 3) Python venv (만약 .venv 사용하는 빌드 도구 있음)
python3 -m venv .venv && source .venv/bin/activate && pip install uv
```

```bash
# cargo install 2종 — 각각 background로 띄우기
source "$HOME/.cargo/env"
cargo install cargo-watch 2>&1 | tail -5    # background OK
cargo install wasm-pack --locked 2>&1 | tail -5  # background OK
# 두 빌드는 다른 crate set이라 동시 빌드 OK
```

### Phase 3: .env + .env.local (1분)

대부분의 풀스택 모노레포는 **같은 API 키를 양쪽**에 넣어야 함:

```bash
# 1) 서버용 env (Rust env 또는 cli flag)
# 예: GOOGLE_CLIENT_ID, ADMIN_EMAILS, NPC_AUTH_TOKEN
export GOOGLE_CLIENT_ID="xxx.apps.googleusercontent.com"
export ADMIN_EMAILS="you@gmail.com"

# 2) 클라이언트용 .env.local (Vite는 VITE_ prefix를 코드에 inject)
cd client
cp .env.example .env.local
# VITE_GOOGLE_CLIENT_ID 같은 값 편집
```

**Vite의 .env 규칙**:
- `VITE_` 접두사가 붙은 키만 `import.meta.env.VITE_*`로 클라이언트 코드에 노출
- `.env.local`은 `.gitignore` (OpenMMO 확인됨)
- `.env.example`에 템플릿 + Authorized JS origins 안내 있음 → 그대로 따르기

### Phase 4: 서버 cold build + 실행 (4~5분) — **순차**

**`cargo watch`로 띄우는 게 정석** (소스 변경 시 자동 재시작):

```bash
source "$HOME/.cargo/env" && cd ~/work/<project>
cargo watch -w server -w shared -w data-src \
  -x "run -p <server-crate-name>" 2>&1
```

**cold build 신호** (정상):
```
   Compiling hyper v1.8.1
   ...
   Compiling <server-crate-name> v0.1.0 (/Users/mac/work/<project>/server)
   ...
🎮 Server listening on: 0.0.0.0:10006
```

**첫 cold build 4~5분 후 서버 LISTEN**. 그 후 hot reload는 2~10초.

### Phase 5: WASM cold build (13분) — **Phase 4 끝난 후 시작**

**순서가 중요**. cargo 빌드가 끝나서 rustc가 idle 상태에서 wasm-pack 시작.

```bash
cd client
npm run dev -- --port 10004 --host 127.0.0.1 2>&1
```

`npm run dev`는 보통 내부에서 `npm run build:wasm` 호출:
```bash
> build:wasm
> npm run generate:footprints && \
  rm -rf src/lib/wasm && \
  cd ../shared && wasm-pack build --target web --out-dir ../client/src/lib/wasm
```

**cold build 신호**:
```
[INFO]: Compiling to Wasm...
   Compiling onlinerpg-shared v0.1.0
    Finished `release` profile [optimized] target(s) in 13m 27s
[INFO]: Optimizing wasm binaries with `wasm-opt`...
[INFO]: ✨   Done in 13m 27s
```

**wasm-pack 첫 실행 = wasm-bindgen-cli 자체 빌드** (5~6분)이 메인 비용. 두 번째부터 캐시 hit.

### Phase 6: Vite ready + 포트 검증 (10초)

```bash
# 모든 포트 LISTEN 확인
lsof -i :10004 -i :10006 -i :10007

# Vite 헬스체크
curl -sI http://127.0.0.1:10004/
# → HTTP/1.1 200 OK

# Terrain REST API (서버 REST가 있으면)
curl -s http://127.0.0.1:10007/health  # 또는 README에 명시된 endpoint
```

**완료 신호**:
- 10004: node (vite)
- 10006: onlinerpg (서버 WebSocket)
- 10007: onlinerpg (서버 REST API, 127.0.0.1 only)

브라우저 `http://127.0.0.1:10004` → 로그인 화면 → 게임 진입.

## OpenMMO 적용 사례 (2026-07-22)

**저장소**: https://github.com/Julian-adv/OpenMMO (Rust + WASM + Svelte/Three.js)
**라이선스**: PolyForm Noncommercial 1.0.0 (상업적 사용 금지)
**API 키**: Google OAuth Web Client ID만 필요 (브라우저 로그인용)

| 항목 | 값 |
|---|---|
| Cargo workspace members | `agent-client`, `server`, `shared`, `terrain`, `tools/terrain-gen` |
| Server port | 10006 (WebSocket) + 10007 (REST API 127.0.0.1) |
| Client port | 10004 (Vite dev) + 10005 (GLB Editor) |
| 데이터 빌드 | `data-src/*.csv` → `data/*.json` (Cargo build script에서 자동) |
| WASM shared | `shared` crate가 `cdylib`으로 빌드 → `client/src/lib/wasm` |
| Auth 패턴 | `GOOGLE_CLIENT_ID` (서버) + `VITE_GOOGLE_CLIENT_ID` (클라이언트) 양쪽 동일 |
| Admin 권한 | `ADMIN_EMAILS` env에 본인 Gmail → 맵 에디터 쓰기 권한 |

## 함정 (Pitfalls)

### 1. cargo cold build + wasm-pack 동시 실행 시 2배 느려짐

**증상**: 두 빌드를 background로 동시 띄우면 rustc가 동시에 CPU 점유 → cargo 빌드 4분→8분, wasm 빌드 13분→20분. 총 30분 → 45분.

**해결**:
1. **`cargo watch -x "run -p server"` 먼저 띄워서 서버 cold build 끝낼 때까지 대기**
2. 서버 LISTEN 확인 후 **`npm run dev` (WASM build 포함) 시작**
3. 순차 실행 시 총 18분 vs 동시 45분

**판별**: cold build 진행 중 `ps aux | grep rustc | wc -l` → 6개 이상이면 동시 빌드 중.

### 2. `cargo install` 첫 실행 시 objc2-foundation 6분+ 소요

**macOS 특유의 거대 의존성**:
```
Compiling objc2-foundation v0.3.2
   (Foundation NSArray, NSBundle, NSDate, NSError, NSURL, ... 250+ features)
```

**해결**: `cargo install cargo-watch`를 **첫 단계에서 background로 띄우기** — 다른 셋업과 동시에 진행. 6분 후 사용 가능.

### 3. wasm-pack cold build는 wasm-bindgen-cli 자체 빌드 6분

`wasm-pack`은 cargo subcommand지만, 실제로는 `wasm-bindgen-cli`를 별도 빌드 후 호출. cold일 때:
```
Updating crates.io index
Downloading crates ...
Downloaded wasm-bindgen-cli v0.2.114
Installing wasm-bindgen-cli v0.2.114
... (walrus, jiff, multipart, ureq 등 컴파일)
```

**해결**: `cargo install wasm-pack --locked`를 background로 띄워두기. 3분 29초 후 사용 가능.

### 4. `Cargo.lock` 변경 시 무효화

**증상**: 의존성 업데이트 후 cargo 빌드 → 전체 재컴파일.

**대응**: 평소엔 `Cargo.lock`을 repo에 커밋 (lockfile 추적). 의존성 업데이트 시 `cargo update` 명시적으로.

### 5. Vite `.env.local` 의 `VITE_` prefix

**증상**: `.env.local`에 키를 넣었는데 클라이언트 코드에서 `undefined`.

**원인**: Vite는 `VITE_` 접두사만 `import.meta.env.VITE_*`로 노출. 일반 키는 서버에서만 보임.

**해결**: 모든 클라이언트용 키에 `VITE_` prefix. 예: `VITE_GOOGLE_CLIENT_ID`, `VITE_BACKEND_HOST`.

### 6. 서버 cold build 후 `data/` 디렉토리 검증

**증상**: 서버 첫 실행 시 "csv file not found" 또는 "data directory missing" 에러.

**원인**: `data-src/*.csv` → `data/*.json` 변환이 `build.rs`에서 실행되지만, **이미 `data/`가 빌드된 상태로 clone 됐다면 OK**. fresh clone이 아니거나 일부만 clone된 경우 fail.

**해결**:
```bash
ls data/  # items.json, monsters.json, npcs.json 등 확인
# 비어있으면 python3 tools/convert.mjs 또는 cargo clean && 재빌드
```

### 7. WebGPU 브라우저 요구사항

**OpenMMO 같은 Three.js + Threlte 8.x + WebGPU 사용 시**:
- Safari 18+ (macOS Sonoma+)
- Chrome 113+ / Edge 113+
- Firefox는 WebGPU 실험적 지원

**증상**: 브라우저가 검은 화면 + 콘솔에 "WebGPU not supported".

**해결**: Safari/Chrome 최신으로 업데이트. 또는 Three.js 설정에서 WebGL fallback.

## 진단 패턴

### 포트 충돌

```bash
# 어떤 프로세스가 점유 중인지
lsof -i :10004 -i :10006 -i :10007

# 죽은 cargo watch 프로세스 정리
pkill -f "cargo watch" && pkill -f "vite"
```

### cold build vs hot reload 구분

```bash
# cold build 신호: "Compiling onlinerpg-server v0.1.0" 메시지가 보임
# hot reload 신호: "Compiling onlinerpg-shared v0.1.0" (shared만 변경) → 2~10초
# 핫리로드: "Finished `dev` profile [unoptimized + debuginfo] target(s) in 2.34s"
```

### 메모리 사용량

- cargo 빌드 피크: ~3.5GB RSS
- wasm-pack 빌드 피크: ~2.5GB RSS
- 동시 실행 시: ~6GB → M4 16GB은 안전, M1 8GB은 swap 주의

## 백그라운드 프로세스 관리

```bash
# 살아있는 빌드/실행 프로세스 목록
process(action="list")

# 로그 확인
process(action="log", session_id="<id>", limit=50)

# 종료
process(action="kill", session_id="<id>")
```

**셧다운 순서**: 클라이언트(Vite) → 서버(cargo watch). cargo watch가 죽으면 백엔드 WebSocket 끊김.

## 다음 단계 옵션 (사용자 신호 시)

1. **에이전트 봇**: `agent-client/` 디렉토리에 LLM 두뇌 연결 (Claude/Gemini/OpenRouter)
2. **맵 에디터**: `ADMIN_EMAILS` 설정 + `tools/glb-editor` 실행 (포트 10005)
3. **운영 배포**: GitHub Actions `macos-15` runner + Docker + 도메인 연결
4. **크로스 플랫폼 빌드**: macOS .app + Windows zip + Linux AppImage (love2d-game-fork 패턴 차용)

## 보조 파일 (세션 상세)

세션별 구체 로그/함정 상세는 `references/` 참조:
- **`references/openmmo-2026-07-22-setup.md`** — OpenMMO 셋업 실측 로그 (33분 타임라인, 명령 시퀀스, 포트 검증 체크리스트, 미수행 항목). cargo + WASM cold build 동시 실행 시 CPU 경합 함정의 실측 사례.

## 변경 이력

| 날짜 | 버전 | 내용 |
|---|---|---|
| 2026-07-22 | v0.1.0 | 초기 작성. OpenMMO 셋업 실측 (33분 타임라인, 7대 함정, 포트 진단, .env.local + cargo env 패턴). |
