# OpenMMO 셋업 실측 로그 (2026-07-22)

> 첫 실측 사례. Julian-adv/OpenMMO (https://github.com/Julian-adv/OpenMMO) — Rust 서버 + WASM shared + Svelte/Three.js 클라이언트 + Threlte 8.5 + WebGPU. PolyForm Noncommercial 1.0.0 라이선스.

## 저장소 정보

| 항목 | 값 |
|---|---|
| GitHub | https://github.com/Julian-adv/OpenMMO |
| ⭐ | 686 (2026-07-22) |
| 라이선스 | PolyForm Noncommercial 1.0.0 |
| 기본 브랜치 | master |
| 데이터 폴더 | `data-src/*.csv` → `data/*.json` (Cargo build script에서 자동 변환) |
| 언어 분포 | Rust 1.9MB, TypeScript 1.2MB, Svelte 844KB, Python 47KB |

## 포트 매트릭스

| 포트 | 서비스 | 바인드 | PID |
|---|---|---|---|
| 10004 | Vite dev (브라우저) | 127.0.0.1 | node |
| 10005 | GLB Editor | (옵션) | tools/glb-editor |
| 10006 | Server WebSocket | 0.0.0.0 | onlinerpg-server |
| 10007 | Server REST API | 127.0.0.1 | onlinerpg-server |

## 실측 타임라인 (33분 총합)

| # | 작업 | 도구 | 시간 | 비고 |
|---|---|---|---|---|
| 1 | git clone | git | ~10초 | 855 파일 |
| 2 | `npm install` | npm | 9초 | 213 패키지, 0 vulnerabilities |
| 3 | `.venv` + `uv` | python3 | 5초 | Python 3.9.6 (시스템), uv 0.11.30 |
| 4 | rustup 설치 | curl + rustup | **78초** | rustc 1.97.1 (8bab26f4f 2026-07-14) |
| 5 | `cargo install cargo-watch` | cargo | **6분 19초** | objc2-foundation 거대 의존성 |
| 6 | `cargo install wasm-pack --locked` | cargo | **3분 29초** | wasm-bindgen-cli 0.2.114 자체 빌드 |
| 7 | `cargo watch -w server ...` (cold) | cargo | ~4분 | tokio/axum/reqwest/jwt 컴파일 |
| 8 | `npm run dev` (cold WASM) | npm + wasm-pack | **13분 27초** | wasm-bindgen-cli 재빌드 + shared crate wasm 컴파일 |
| 9 | Vite ready | vite | 3.4초 | `http://127.0.0.1:10004/` |

## 핵심 명령 시퀀스

### 환경 셋업 (Phase 1~2, 11분)

```bash
mkdir -p ~/work && cd ~/work
git clone https://github.com/Julian-adv/OpenMMO.git openmmo
cd openmmo

# npm install (foreground)
cd client && npm install && cd ..

# Python venv (data 변환 도구용)
python3 -m venv .venv
source .venv/bin/activate
pip install uv

# rustup (background OK)
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y --default-toolchain stable --profile minimal

# source cargo env
source "$HOME/.cargo/env"
which rustc cargo
# → /Users/mac/.cargo/bin/{rustc,cargo}
```

### Cargo 도구 2종 설치 (background 동시 가능)

```bash
# cargo-watch 6분, wasm-pack 3분
cargo install cargo-watch 2>&1 | tail -5
cargo install wasm-pack --locked 2>&1 | tail -5
```

### .env.local (Phase 3)

```bash
cd client
cp .env.example .env.local
```

`.env.local` 작성 (OpenMMO):
```bash
VITE_BACKEND_HOST=localhost
VITE_HMR_HOST=localhost
VITE_HMR_PROTOCOL=ws
VITE_GOOGLE_CLIENT_ID=318935548238-f7drcs2pmt440u9kttb6g84hl7a9nj81.apps.googleusercontent.com
```

### 서버 실행 (Phase 4, 4~5분)

```bash
cd ~/work/openmmo
source "$HOME/.cargo/env"
GOOGLE_CLIENT_ID=318935548238-f7drcs2pmt440u9kttb6g84hl7a9nj81.apps.googleusercontent.com \
ADMIN_EMAILS= \
cargo watch -w server -w shared -w data-src -x "run -p onlinerpg-server" 2>&1
```

**cold build 출력 끝**:
```
Loaded 1 dungeon entrances
INFO onlinerpg_server: MMORPG Server listening on: 0.0.0.0:10006
INFO onlinerpg_server: Terrain REST API listening on: 127.0.0.1:10007
INFO onlinerpg_server: 🎮 MMORPG Server started successfully!
INFO onlinerpg_server: 📡 WebSocket server ready for connections
```

### 클라이언트 실행 (Phase 5, 13분 cold WASM)

```bash
cd client
npm run dev -- --port 10004 --host 127.0.0.1 2>&1
```

**cold WASM build 출력 끝**:
```
[INFO]: Optimizing wasm binaries with `wasm-opt`...
[INFO]: ✨   Done in 13m 27s
[INFO]: 📦   Your wasm pkg is ready to publish at /Users/mac/work/openmmo/client/src/lib/wasm.
[csv] Converted 1 entry/entries from dungeons.csv
[csv] Converted 24 entry/entries from items.csv
... (7종 CSV 모두 변환)
7:28:46 AM [vite] (client) Forced re-optimization of dependencies
  VITE v7.3.6  ready in 3389 ms
  ➜  Local:   http://127.0.0.1:10004/
```

### 검증 (Phase 6, 10초)

```bash
lsof -i :10004 -i :10006 -i :10007
# COMMAND     PID USER   FD   TYPE             DEVICE SIZE/OFF NODE NAME
# onlinerpg 26821  mac   19u  IPv4 ... TCP *:10006 (LISTEN)
# onlinerpg 26821  mac   20u  IPv4 ... TCP localhost:mvs-capacity (LISTEN)
# node      53946  mac   64u  IPv4 ... TCP localhost:10004 (LISTEN)

curl -sI http://127.0.0.1:10004/
# HTTP/1.1 200 OK
```

## 배경: OpenMMO 구조

```
openmmo/
├── Cargo.toml          ← workspace
├── Cargo.lock
├── AGENTS.md           ← AI 에이전트 통합 가이드
├── CLAUDE.md
├── GEMINI.md
├── server/             ← Rust async server (axum, tokio, rusqlite)
│   ├── src/
│   ├── Cargo.toml      ← onlinerpg-server
│   └── build.rs        ← data-src → data 변환 트리거
├── shared/             ← WASM 공유 crate
│   ├── src/
│   ├── Cargo.toml      ← crate-type = ["cdylib", "rlib"]
│   └── worldgen/
├── client/             ← Svelte + TypeScript + Three.js
│   ├── package.json    ← Vite 7.1.0, Svelte 5.53
│   ├── src/
│   └── vite.config.ts
├── agent-client/       ← Rust MCP server (rmcp, tokio-tungstenite)
│   ├── src/
│   │   ├── claude.rs
│   │   ├── codex.rs
│   │   ├── openrouter.rs
│   │   └── llm_scheduler.rs
│   └── data/config.toml
├── terrain/            ← Rust terrain crate (서버 의존성)
├── data/               ← 생성된 JSON (clone 시 포함)
└── data-src/           ← 원본 CSV
```

**Cargo workspace members**:
- `agent-client` — MCP 서버 (Claude/Codex/OpenRouter 호출)
- `server` — 게임 서버 (axum WebSocket + REST)
- `shared` — WASM 공유 라이브러리
- `terrain` — 지형 생성 crate
- `tools/terrain-gen` — 지형 CLI

## 환경 검증 체크리스트

- [x] `rustc --version` → 1.97.1
- [x] `cargo --version` → 1.97.1
- [x] `cargo watch --version` → 8.5.3
- [x] `wasm-pack --version` → 0.15.0
- [x] `node --version` → v22.23.1
- [x] `npm --version` → 10.9.8
- [x] Python venv에 uv 설치 → 0.11.30
- [x] `client/node_modules/` 213 패키지
- [x] `client/.env.local` 작성 (VITE_GOOGLE_CLIENT_ID)
- [x] 포트 10004/10006/10007 모두 LISTEN
- [x] Vite HTTP 200 OK
- [x] Terrain REST API LISTEN
- [x] 7종 CSV → JSON 변환 (dungeons, items, map_labels, merchants, monsters, npcs, world_drop)
- [x] WASM pkg at `client/src/lib/wasm/`

## 미수행 (사용자 신호 시)

- [ ] 브라우저 http://127.0.0.1:10004 접속 → Google 로그인 흐름 검증
- [ ] `ADMIN_EMAILS=본인@gmail.com` 추가 → 서버 재시작 → 맵 에디터 활성화
- [ ] `agent-client/` 빌드 + LLM 두뇌 연결 (Claude Code/Codex/OpenRouter)
- [ ] `tools/glb-editor` (포트 10005) 빌드 + 실행

## 두 가지 환경 의존 함정 (수정 시 패치)

- `npm install`은 양호 (PEP 668 없음, Node 22 사용)
- `python3` 시스템 3.9.6 사용 (Homebrew Python 미설치) — 빌드 도구용으로만 필요, 시스템 Python 보호

## 학습 신호

이 세션에서 가장 큰 시간 손실 = **cargo build + wasm-pack 동시 실행으로 인한 CPU 경합** (총 30분 vs 순차 18분 추정). 다음부터는:
1. 서버 cold build를 먼저 끝낸다 (LISTEN 확인)
2. 그 다음 WASM build를 시작한다

순서를 지켜야 cold start가 30분 내외로 들어옴.
