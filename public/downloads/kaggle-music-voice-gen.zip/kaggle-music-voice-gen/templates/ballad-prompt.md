# 보컬 발라드 프롬프트 템플릿 (mmx music generate)

> 한국어 여성 보컬, IU 풍 따뜻한 발라드 기준. 다른 보컬/장르로 바꿀 때는 `--vocals`/`--genre` 부분만 수정.

## 프롬프트 본문 (`--prompt`)

```
korean female vocal, emotional k-pop ballad, piano ballad, soft pop, singer-songwriter, warm and gentle, late night, soft strings, brushed drums, healing, comforting
```

## 변형 모듈

### 보컬 톤 (`--vocals`)
- IU 풍 (밝고 청아, 숨소리 섞인): `bright female soprano, IU-inspired, breathy, whispery`
- 폴킴 풍 (남성, 따뜻): `warm male baritone, Paul Kim-inspired, soft`
- 헤이즈 풍 (중성, 개성섞인): `soft husky female vocal, Heize-inspired, lo-fi warmth`
- 자우림/김범수 풍 (클래식): `rich female alto, classical korean ballad, vibrato`

### 장르 (`--genre`)
- `pop ballad` (기본)
- `folk ballad`
- `r&b ballad`
- `acoustic pop`
- `indie ballad`

### 무드 (`--mood`)
- 위로/힐링: `warm, comforting, healing`
- 이별: `melancholic, longing, bittersweet`
- 로맨틱: `romantic, tender, intimate`
- 새벽 일상: `nostalgic, dreamy, late night`

### 악기 (`--instruments`)
- 미니멀: `piano, soft strings`
- 따뜻한 풀밴드: `piano, acoustic guitar, soft strings, brushed drums, bass`
- lo-fi 힙합: `piano, soft lo-fi drums, vinyl crackle`
- 시네마틱: `piano, strings, cello, ambient pads`

### BPM/Key (장르별 권장)
| 장르 | BPM | Key |
|------|-----|-----|
| 슬로우 발라드 | 60–72 | D major / B minor |
| 미디엄 발라드 | 75–88 | G major / E minor |
| 로맨틱 R&B | 80–95 | C major / A minor |
| 위로 발라드 | 65–75 | D major |

### 레퍼런스 (`--references`)
- 한국 발라드 베이스라인: `IU 밤편지, Paul Kim, Heize`
- 서양 따뜻한 톤: `Adele, Ed Sheeran`
- 어쿠스틱: `Damien Rice, Bon Iver`

## 가사 템플릿 (구조태그)

```
[Intro]

[Verse 1]
(2~4줄, 첫 이미지/상황)

[Pre-Chorus]
(1~2줄, 감정 고조)

[Chorus]
(3~4줄, 후렴)

[Verse 2]
(2~4줄, 전개)

[Pre-Chorus]

[Chorus]

[Bridge]
(2~4줄, 정서 전환/클라이맥스)

[Outro]
(1~2줄, 여운)
```

## 한 줄 호출 예시
```bash
mmx music generate \
  --prompt "korean female vocal, emotional k-pop ballad, piano ballad, soft pop, singer-songwriter, warm and gentle, late night, soft strings, brushed drums, healing, comforting" \
  --vocals "bright female soprano, IU-inspired, breathy, whispery" \
  --genre "pop ballad" --mood "warm, comforting, healing" \
  --instruments "piano, soft strings, brushed drums, acoustic guitar" \
  --bpm 70 --key "D major" \
  --references "IU 밤편지, Paul Kim" \
  --lyrics-file ./lyrics/song.txt \
  --out ./output/song_v1.mp3
```
