---
name: kaggle-music-voice-gen
description: Kaggle T4 GPU에서 ACE-Step 1.5 (음악 생성) + Qwen3-TTS (음성 생성) 실행 가이드
---

# Kaggle 음악/음성 생성 노트북

## 모델
- **ACE-Step 1.5** — Text-to-Music (인스트 + 보이스 포함 가능)
- **Qwen3-TTS-12Hz-1.7B-CustomVoice** — Text-to-Speech (한국어 Sohee 보이스 포함)

## 필수 조건
- **GPU:** T4 (P100 불가 — bfloat16 미지원)
- **Internet:** ON
- **HuggingFace 토큰:** Read 권한

## 주의사항 (T4)
- `ACESTEP_DTYPE=float32` 필수 (float16에서 NaN 발생)
- 두 모델 동시 로드 불가 → 함수 분리 후 사용 시 로드/해제
- MP3 직접 인코딩 불가 → wav 후 ffmpeg 변환
- `MPLBACKEND` 환경변수 제거 필수
- uv venv 패키지를 Jupyter에서 사용하려면 sys.path 추가

## 셀1 — 설치

```python
!git clone https://github.com/ACE-Step/ACE-Step-1.5.git
%cd ACE-Step-1.5
!pip install uv qwen-tts
!uv sync
import os
os.environ["PATH"] = os.getcwd() + "/.venv/bin:" + os.environ["PATH"]
!apt-get install -y ffmpeg
```

## 셀2 — 함수 정의

```python
import os, sys, subprocess, torch, gc

os.environ.pop("MPLBACKEND", None)
venv_site = "/kaggle/working/ACE-Step-1.5/.venv/lib/python3.12/site-packages"
sys.path.insert(0, venv_site)

def generate_music(prompt, duration=30, lyrics=None, vocal_language="en", output_path="/kaggle/working/output/music.mp3"):
    gc.collect()
    torch.cuda.empty_cache()
    
    # T4용 float32 설정 (필수)
    os.environ["ACESTEP_DTYPE"] = "float32"
    
    from acestep.handler import AceStepHandler
    from acestep.inference import GenerationParams, GenerationConfig, generate_music as gm
    
    dit = AceStepHandler()
    dit.initialize_service(
        project_root="/kaggle/working/ACE-Step-1.5",
        config_path="acestep-v15-turbo",
        device="cuda"
    )
    
    params = GenerationParams(
        caption=prompt,
        duration=duration,
        lyrics=lyrics,
        vocal_language=vocal_language,
    )
    config = GenerationConfig(audio_format="wav")
    result = gm(dit, None, params, config, save_dir="/kaggle/working/output")
    
    if result.success:
        for audio in result.audios:
            fixed_wav = "/kaggle/working/output/music.wav"
            os.rename(audio['path'], fixed_wav)
            subprocess.run(["ffmpeg", "-y", "-i", fixed_wav, "-codec:a", "libmp3lame", "-q:a", "2", output_path])
            print(f"✅ 음악 생성 완료: {output_path}")
    else:
        print(f"❌ 실패: {result.error}")
    
    del dit
    gc.collect()
    torch.cuda.empty_cache()

def generate_voice(text, language="Korean", speaker="Sohee", output_path="/kaggle/working/output/voice.mp3"):
    gc.collect()
    torch.cuda.empty_cache()
    
    from qwen_tts import Qwen3TTSModel
    import torchaudio
    
    tts = Qwen3TTSModel.from_pretrained(
        "Qwen/Qwen3-TTS-12Hz-1.7B-CustomVoice",
        device_map="cuda:0",
        dtype=torch.float16,
    )
    
    wavs, sr = tts.generate_custom_voice(text=text, language=language, speaker=speaker)
    fixed_wav = "/kaggle/working/output/voice.wav"
    tensor = torch.tensor(wavs[0]).unsqueeze(0)
    torchaudio.save(fixed_wav, tensor, sr)
    subprocess.run(["ffmpeg", "-y", "-i", fixed_wav, "-codec:a", "libmp3lame", "-q:a", "2", output_path])
    print(f"✅ 음성 생성 완료: {output_path}")
    
    del tts
    gc.collect()
    torch.cuda.empty_cache()
```

## 사용법

```python
# 인스트
generate_music("upbeat K-pop instrumental with synth hooks")

# 보이스 포함 음악
generate_music(
    "emotional K-pop ballad with piano and strings",
    lyrics="[Verse 1]\n별이 빛나는 밤이면\n너의 생각에 잠기곤 해",
    vocal_language="ko"
)

# 음성 생성
generate_voice("안녕하세요! 이것은 테스트 음성입니다.")
```

## 지원 스피커 (Qwen3-TTS)
한국어: Sohee (여성)
전체: tts.get_supported_speakers()로 확인

## 트러블슈팅
| 문제 | 해결 |
|------|------|
| NaN/Inf latents | `ACESTEP_DTYPE=float32` 설정 |
| OOM | 커널 재시작, 한 모델씩만 실행 |
| ModuleNotFoundError (loguru 등) | sys.path에 venv site-packages 추가 |
| MPLBACKEND ValueError | `os.environ.pop("MPLBACKEND", None)` |
| soundfile LibsndfileError | torchaudio.save 대신 사용 |
| MP3 인코딩 실패 | wav로 생성 후 ffmpeg CLI 변환 |
| REST API 서버 타임아웃 | Python API 직접 호출 사용 |
| 백그라운드 프로세스 불가 | subprocess.Popen 사용 (Kaggle 제약) |
