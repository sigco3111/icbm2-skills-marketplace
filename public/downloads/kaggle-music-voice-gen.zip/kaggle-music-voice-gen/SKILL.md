---
name: kaggle-music-voice-gen
description: "음악/음성 생성 가이드 — ACE-Step 1.5 (카글) + edge-tts (로컬, 기본 TTS)"
tags: [tts, voice, music, edge-tts, ace-step, deprecated-kaggle]
---

# 음악/음성 생성

> ⚠️ **2026-04-16 변경:** TTS를 edge-tts로 전환. 음악 생성(ACE-Step)은 카글 수동 구동 시에만 사용.

## TTS (기본: edge-tts)

→ `qwen3-tts` 스킬 참조

## 음악 생성: ACE-Step 1.5 (카글, 수동)

카글 T4 GPU에서 인스트루멘탈 음악 생성.

### 주의사항 (T4)
- `ACESTEP_DTYPE=float32` 필수
- uv venv 패키지 사용 시 sys.path 추가 필요
- wav 출력 후 ffmpeg으로 mp3 변환

### 사용 중단 사유 (상시 서버 불가)
- 카글 40분 유휴 타임아웃
- 주간 GPU 30시간 제한
