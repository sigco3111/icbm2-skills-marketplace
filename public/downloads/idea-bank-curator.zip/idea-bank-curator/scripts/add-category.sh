#!/usr/bin/env bash
# idea-bank-curator/add-category.sh
# sigco3111/idea-bank 저장소에 새 카테고리 1개 추가 (clone → patch 4 files → push → verify)
#
# 사용법:
#   bash add-category.sh \
#     --category-name "TUI 게임" \
#     --file-name "TUI_Game_Project_Ideas.md" \
#     --emoji "🖥️" \
#     --description "터미널 UI 기반 업무 위장형 게임" \
#     --count 5 \
#     --ideas-file /tmp/TUI_Game_Project_Ideas.md \
#     [--dry-run]
#
# 필요 환경: gh CLI 인증 완료

set -euo pipefail

CATEGORY_NAME=""
FILE_NAME=""
EMOJI="🏷️"
DESCRIPTION=""
COUNT=""
IDEAS_FILE=""
DRY_RUN=false

while [[ $# -gt 0 ]]; do
  case "$1" in
    --category-name) CATEGORY_NAME="$2"; shift 2 ;;
    --file-name) FILE_NAME="$2"; shift 2 ;;
    --emoji) EMOJI="$2"; shift 2 ;;
    --description) DESCRIPTION="$2"; shift 2 ;;
    --count) COUNT="$2"; shift 2 ;;
    --ideas-file) IDEAS_FILE="$2"; shift 2 ;;
    --dry-run) DRY_RUN=true; shift ;;
    *) echo "Unknown arg: $1"; exit 1 ;;
  esac
done

if [[ -z "$CATEGORY_NAME" || -z "$FILE_NAME" || -z "$DESCRIPTION" || -z "$COUNT" || -z "$IDEAS_FILE" ]]; then
  echo "Missing required args"; exit 1
fi

REPO="sigco3111/idea-bank"
WORK="/tmp/idea-bank-clone"

echo "▶ Clone $REPO → $WORK"
gh repo clone "$REPO" "$WORK" 2>&1 | tail -2

cd "$WORK"
git config user.email "icbm2-bot@sigco3111.local"
git config user.name "ICBM2 Bot"

echo "▶ Copy $IDEAS_FILE → $WORK/$FILE_NAME"
cp "$IDEAS_FILE" "$WORK/$FILE_NAME"

echo "▶ Patch README.md (category table + structure tree)"
# 카테고리 표 마지막 줄 다음에 새 행 추가
python3 - <<EOF
import re
p = "README.md"
s = open(p).read()
# 카테고리 표 마지막 행 다음에 삽입
new_row = f"| {repr('$EMOJI')[1:-1]} [$CATEGORY_NAME]($FILE_NAME) | $DESCRIPTION | $COUNT |\n"
s = re.sub(r"(🎭 \[Playwright E2E 자동화\]\(Playwright_E2E_Project_Ideas\.md\) \| Playwright 기반 E2E 테스트 자동화 도구 \| 25 \|)\n",
           r"\1\n" + new_row, s)
# 구조 트리에 추가
s = re.sub(r"(├── Playwright_E2E_Project_Ideas\.md      # Playwright E2E 테스트 자동화 아이디어 \(25개\))\n",
           r"\1\n├── $FILE_NAME             # $CATEGORY_NAME 아이디어 ($COUNT개)", s)
open(p, 'w').write(s)
EOF

echo "▶ Patch IDEA_INDEX.md (new section + stats)"
python3 - <<EOF
import re
p = "IDEA_INDEX.md"
s = open(p).read()
# # 📊 통계 직전에 새 섹션 삽입 (간단한 마커만 — 실제 표는 별도 작업 필요)
# 이 스크립트는 메타 패치만 자동화, 표 내용은 사용자 제공
section_marker = "\n---\n\n# 📊 통계\n"
new_section = "\n---\n\n## $EMOJI $CATEGORY_NAME (${COUNT}개) — [상세보기]($FILE_NAME)\n\n(\$IDEAS 파일에서 표 추출 필요)\n\n---"
# 실제로는 통계 표에 행 추가하는 로직 필요 — 사용자가 직접 patch
print("⚠️  IDEA_INDEX.md의 새 섹션과 통계 표는 수동 patch 필요 (count +N, 새 카테고리 행 추가)")
EOF

echo "▶ Patch IDEA_GENERATION_GUIDE.md (coverage map)"
python3 - <<EOF
import re
p = "IDEA_GENERATION_GUIDE.md"
s = open(p).read()
new_row = f"| $CATEGORY_NAME | $FILE_NAME | $COUNT | (하위 분야) |"
# 기존 Playwright 행 다음에 추가
s = re.sub(r"(\| Playwright E2E 자동화 \| Playwright_E2E_Project_Ideas\.md \| 25 \| [^\n]+\n)",
           r"\1" + new_row + "\n", s)
open(p, 'w').write(s)
EOF

if [[ "$DRY_RUN" == "true" ]]; then
  echo "▶ DRY-RUN: skipping commit/push. Check diffs:"
  git diff --stat
  exit 0
fi

echo "▶ Commit + push"
git add "$FILE_NAME" README.md IDEA_INDEX.md IDEA_GENERATION_GUIDE.md
git commit -m "feat: $CATEGORY_NAME 카테고리 추가 (${COUNT}개 아이디어)

- $FILE_NAME: ${COUNT}개 신규 아이디어
- README.md: 카테고리 표 + 구조 트리 업데이트
- IDEA_INDEX.md: 새 섹션 + 통계 갱신
- IDEA_GENERATION_GUIDE.md: 카테고리 커버리지 맵 추가"

git push origin main 2>&1 | tail -3

echo "▶ Verify"
gh api "repos/$REPO/contents/$FILE_NAME" > /tmp/verify.json
python3 -c "import json; d=json.load(open('/tmp/verify.json')); print(f'OK: {d[\"name\"]} ({d[\"size\"]} bytes)'); print('URL:', d['html_url'])"

echo "✅ Done"