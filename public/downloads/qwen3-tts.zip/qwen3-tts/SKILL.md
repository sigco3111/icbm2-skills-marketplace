---
name: qwen3-tts
description: "Kaggle T4 GPU에서 Qwen3-TTS-12Hz로 한국어 음성(TTS) 생성 — Kaggle API 원격 실행 + 텔레그램 전송"
tags: [tts, voice, qwen3, kaggle, t4, gpu, korean, speech, telegram]
---

# Qwen3-TTS Korean Voice Generation

Kaggle 무료 T4 GPU에서 Qwen3-TTS-12Hz 모델로 한국어 음성을 생성합니다. ICBM2가 Kaggle API로 원격 실행하고, 결과 mp3를 다운로드하여 텔레그램으로 전송할 수 있습니다.

## 모델 정보

| 항목 | 값 |
|---|---|
| 모델 | Qwen/Qwen3-TTS-12Hz-1.7B-CustomVoice |
| 언어 | 한국어, 영어 등 다국어 |
| 보이스 | Sohee, Chelsie, Nick 등 |
| 출력 | wav → ffmpeg로 mp3 변환 |
| GPU 요구 | T4 16GB 이상 |

## 전제 조건

- Kaggle 계정 + API 토큰 (Legacy API Token, KGAT_ 접두사는 불가)
- `~/.kaggle/kaggle.json` 설정 완료
- `kaggle` CLI 설치됨

## Kaggle API 원격 실행 (ICBM2 자동화용)

### 1. 커널 준비

```
/tmp/kaggle-tts/
├── kernel-metadata.json
└── qwen3-tts.ipynb
```

kernel-metadata.json:
```json
{
  "id": "icbm3112k/qwen3-tts-test",
  "title": "qwen3-tts-test",
  "code_file": "qwen3-tts.ipynb",
  "language": "python",
  "kernel_type": "notebook",
  "is_private": true,
  "enable_gpu": true,
  "enable_internet": true,
  "dataset_sources": [],
  "competition_sources": [],
  "kernel_sources": []
}
```

### 2. 노트북 핵심 코드

**⚠️ 중요: PyTorch를 2.6.0+cu124로 고정해야 T4에서 동작함 (기본 PyTorch 2.10+cu128은 T4 미지원)**

```python
# 셀 1: T4 호환 PyTorch 설치 + 패키지
!pip install torch==2.6.0 torchvision torchaudio --index-url https://download.pytorch.org/whl/cu124 --quiet
!pip install qwen-tts scipy --quiet
!apt-get install -y ffmpeg > /dev/null 2>&1
```

```python
# 셀 2: 음성 생성
import os, subprocess, torch, gc, numpy as np
import scipy.io.wavfile as wavfile

from qwen_tts import Qwen3TTSModel

tts = Qwen3TTSModel.from_pretrained(
    "Qwen/Qwen3-TTS-12Hz-1.7B-CustomVoice",
    device_map="cuda:0",
    dtype=torch.float16,
)

wavs, sr = tts.generate_custom_voice(text="...", language="Korean", speaker="Sohee")
audio_np = np.array(wavs[0], dtype=np.float32)
wavfile.write("/kaggle/working/voice.wav", sr, audio_np)
subprocess.run(["ffmpeg", "-y", "-i", "/kaggle/working/voice.wav", "-codec:a", "libmp3lame", "-q:a", "2", "/kaggle/working/voice.mp3"])
print("SUCCESS: /kaggle/working/voice.mp3")
```

### 3. 실행 파이프라인

```bash
# 푸시
cd /tmp/kaggle-tts && kaggle kernels push -p .

# 상태 모니터링 (약 3~5분 소요)
kaggle kernels status icbm3112k/qwen3-tts-test

# 완료 후 output 다운로드
kaggle kernels output icbm3112k/qwen3-tts-test -p /tmp/kaggle-tts-output
```

다운로드된 `/tmp/kaggle-tts-output/voice.mp3`를 텔레그램으로 `MEDIA:` 접두사로 전송.

### 4. Python 스크립트 자동화 예시

```python
import subprocess, time, os

# 푸시
subprocess.run(["kaggle", "kernels", "push", "-p", "/tmp/kaggle-tts"])

# 완료 대기
while True:
    r = subprocess.run(["kaggle", "kernels", "status", "icbm3112k/qwen3-tts-test"], capture_output=True, text=True)
    if "COMPLETE" in r.stdout:
        break
    elif "ERROR" in r.stdout:
        raise Exception(f"Kernel failed: {r.stdout}")
    time.sleep(30)

# 다운로드
os.makedirs("/tmp/kaggle-tts-output", exist_ok=True)
subprocess.run(["kaggle", "kernels", "output", "icbm3112k/qwen3-tts-test", "-p", "/tmp/kaggle-tts-output"])

# mp3 경로
mp3 = "/tmp/kaggle-tts-output/voice.mp3"
```

## 수동 실행 (Kaggle 노트북에서 직접)

스크립트: `~/.hermes/scripts/kaggle/qwen3-tts.ipynb`

Kaggle 노트북 설정: Settings → **Internet: On** → **Accelerator: GPU T4 x2**

## 지원 보이스

| 보이스 | 언어 | 특징 |
|---|---|---|
| Sohee | 한국어 | 한국어 여성 보이스 |
| Chelsie | 영어 | 영어 여성 보이스 |
| Nick | 영어 | 영어 남성 보이스 |

## ⚠️ 함정 (Pitfalls)

- **PyTorch 버전**: 반드시 `torch==2.6.0+cu124` 고정. 기본 PyTorch 2.10+cu128은 T4에서 `CUDA error: no kernel image is available` 발생
- **Kaggle API 토큰**: Legacy API 토큰 필요. `KGAT_` 접두사 토큰은 Kernels API에서 401 에러
- **kernel_type**: 반드시 `"notebook"`. `"script"`로 하면 ipynb를 .py로 변환하다가 SyntaxError
- **torchaudio.save() 금지**: torchcodec 호환성 문제로 반드시 `scipy.io.wavfile` 사용
- **pad_token_id 경고**: 무시해도 정상 동작
- **커널 id/title**: slug 형식 일치 필수. 불일치 시 409 Conflict
- **output 다운로드**: 전체 /kaggle/working이 다운로드됨. .venv 등이 포함되면 매우 무거우니 주의
- **동시 커널 실행**: Kaggle에서 GPU 커널은 동시 1개만 실행 가능
- **긴 텍스트**: 500자 이하 권장. 길면 생성 시간 급증
