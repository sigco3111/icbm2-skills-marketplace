---
name: qwen3-tts
description: "한국어 음성(TTS) 생성 — edge-tts (기본) / Qwen3-TTS (카글, 필요시 수동 구동)"
tags: [tts, voice, korean, speech, edge-tts, deprecated-kaggle]
---

# 한국어 음성 생성

> ⚠️ **2026-04-16 변경:** 기본 TTS를 edge-tts로 전환. 카글 Qwen3-TTS는 필요시 수동 구동.

## 현재 방식: edge-tts (기본)

로컬에서 즉시 실행, 외부 서버 불필요.

### 음성
- `ko-KR-SunHiNeural` (여성, 기본)
- `ko-KR-InJoonNeural` (남성)
- `ko-KR-HyunsuMultilingualNeural` (남성, 다국어)

### 사용법
```bash
edge-tts --voice ko-KR-SunHiNeural --rate=-5% --text "안녕하세요" --write-media output.mp3
```

### 한계
- Qwen3-TTS보다 자연스러움 떨어짐
- 커스텀 보이스 불가
- 감정 표현 제한적

## 레거시: 카글 Qwen3-TTS (사용 중단)

### Qwen3-TTS-12Hz 사양
| 항목 | 값 |
|---|---|
| 모델 | Qwen/Qwen3-TTS-12Hz-1.7B-CustomVoice |
| 보이스 | Sohee, Chelsie, Nick 등 |
| GPU | T4 16GB (카글) |
| 출력 | wav → ffmpeg mp3 변환 |

### 사용 중단 사유
- 카글 40분 유휴 타임아웃
- 주간 GPU 30시간 제한
- ICBM2가 서버 원격 재시작 불가

### 레거시 참고
- 카글 커널: `icbm3112k/qwen3-tts-test`
- 스크립트: `~/.hermes/scripts/kaggle_account3_audio_gen.py`
- 노트북: `~/.hermes/scripts/kaggle/qwen3-tts.ipynb`
