---
name: qwen3-tts
description: "Kaggle T4 GPU에서 Qwen3-TTS-12Hz로 한국어 음성(TTS) 생성 — 커스텀 보이스 지원, torchcodec 우회"
tags: [tts, voice, qwen3, kaggle, t4, gpu, korean, speech]
---

# Qwen3-TTS Korean Voice Generation

Kaggle 무료 T4 GPU에서 Qwen3-TTS-12Hz 모델로 한국어 음성을 생성합니다. 커스텀 보이스(Sohee, Chelsie, Nick 등)를 지원하며, scipy로 WAV를 저장해 torchcodec 호환성 문제를 우회합니다.

## 모델 정보

| 항목 | 값 |
|---|---|
| 모델 | Qwen/Qwen3-TTS-12Hz-1.7B-CustomVoice |
| 언어 | 한국어, 영어 등 다국어 |
| 보이스 | Sohee, Chelsie, Nick 등 |
| 출력 | wav → ffmpeg로 mp3 변환 |
| GPU 요구 | T4 16GB 이상 |

## 전제 조건

- Kaggle 계정
- Kaggle 노트북 설정: Settings → **Internet: On** → **Accelerator: GPU T4 x2**

## Kaggle 노트북

스크립트: `~/.hermes/scripts/kaggle/qwen3-tts.ipynb`

### 사용법

1. Kaggle에 새 노트북 생성
2. Settings → Internet: On, Accelerator: GPU T4 x2
3. 아래 셀들을 순서대로 실행

### 셀 1 — FFmpeg + 패키지 설치

```python
!apt-get install -y ffmpeg
!pip install uv qwen-tts scipy
```

### 셀 2 — 음성 생성 함수 정의

```python
import os, subprocess, torch, gc, numpy as np
import scipy.io.wavfile as wavfile

def generate_voice(text, language="Korean", speaker="Sohee",
                   output_path="/kaggle/working/output/voice.mp3"):
    """Qwen3-TTS로 음성 생성 (torchcodec 우회)

    Args:
        text: 음성으로 변환할 텍스트
        language: 언어 ("Korean", "English", "Japanese" 등)
        speaker: 보이스 이름 ("Sohee", "Chelsie", "Nick" 등)
        output_path: 출력 mp3 경로
    """
    gc.collect()
    torch.cuda.empty_cache()

    from qwen_tts import Qwen3TTSModel

    tts = Qwen3TTSModel.from_pretrained(
        "Qwen/Qwen3-TTS-12Hz-1.7B-CustomVoice",
        device_map="cuda:0",
        dtype=torch.float16,
    )

    wavs, sr = tts.generate_custom_voice(text=text, language=language, speaker=speaker)
    fixed_wav = "/kaggle/working/output/voice.wav"

    # scipy로 WAV 저장 (torchaudio.save 대신 — torchcodec 에러 우회)
    audio_np = np.array(wavs[0], dtype=np.float32)
    wavfile.write(fixed_wav, sr, audio_np)

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    subprocess.run(["ffmpeg", "-y", "-i", fixed_wav,
                   "-codec:a", "libmp3lame", "-q:a", "2", output_path])
    print(f"✅ 음성 생성 완료: {output_path}")

    del tts
    gc.collect()
    torch.cuda.empty_cache()
```

### 셀 3 — 음성 생성 실행

```python
generate_voice(
    text="안녕하십니까? 보이스 테스트 중입니다.",
    language="Korean",
    speaker="Sohee"
)
```

## 사용 예시

```python
# 한국어
generate_voice("오늘 날씨가 정말 좋네요.", language="Korean", speaker="Sohee")

# 영어
generate_voice("Hello! This is a voice test.", language="English", speaker="Chelsie")

# 긴 텍스트
generate_voice("안녕하세요. 오늘은 인공지능에 대해 이야기해볼까요? "
               "최근 AI 기술은 정말 놀라운 속도로 발전하고 있습니다.",
               language="Korean", speaker="Sohee")
```

## 지원 보이스

| 보이스 | 언어 | 특징 |
|---|---|---|
| Sohee | 한국어 | 한국어 여성 보이스 |
| Chelsie | 영어 | 영어 여성 보이스 |
| Nick | 영어 | 영어 남성 보이스 |

## 주의사항

- **torchaudio.save() 에러**: Kaggle T4에서 torchcodec과 PyTorch 버전 호환성 문제로 `torchaudio.save()` 사용 불가. 반드시 `scipy.io.wavfile` 사용
- **pad_token_id 경고**: "Setting `pad_token_id` to `eos_token_id`:2150" 경고는 무시해도 정상 동작
- **긴 텍스트**: 너무 긴 텍스트는 생성 시간이 길어짐. 500자 이하 권장
- **OOM 시**: 세션 재시작 후 다른 작업 없이 바로 음성 생성 실행
