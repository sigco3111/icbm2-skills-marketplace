# GitHub Secret Scanner False Positives for i18n Work

## When to use

You're shipping TypeScript / Python / generic code where any string literal
might *look* like an API token / secret prefix. The scanner runs at push time
and blocks the PR or quarantines the file. The trap is dense in i18n code
because token-shape placeholders show up in fixtures, dynamic-import keys,
and test-string assertions.

## Common false-positive triggers

| Pattern | Source it can appear in | Mitigation |
|---|---|---|
| `ghp_` + 16+ chars | `expect(...).toBe("ghp_xxxx...")` in tests | Replace with `"ghp_<redacted>"` or `"***"` — note the GitHub scanner requires the *prefix + length match*, so dropping length to 8 often (but not always) is enough; prefer `***` |
| `xoxb-`, `xoxp-`, `xoxs-`, `xoxa-` | Slack token-shape strings in fixtures | Same — `***` |
| `sk-` + 20+ chars | OpenAI / Stripe / Anthropic key shapes in tests | Same |
| Long base64 segments that look like JWT `eyJ...` | JWT literals in code samples | `***` |
| `vcp_` + chars | Vendor-specific prefixes in tests | `***` |

The scanner is **prefix-driven**: it needs the right prefix AND a length that
matches a token shape. Replacing `"ghp_abcdef0123456789..."` with
`"ghp_..."` (only 6 chars after prefix) almost always evades detection.

## How to write tests safely

Never use realistic token strings as fixtures — even in dev — because they
get cached in git history. Two safe patterns:

1. **Mask:** `"ghp_<redacted>"`, `"xoxb-***"`, `"sk-***"`. Length doesn't have
   to match; the scanner's prefix + length check fails on these.
2. **Avoid:** Use a clearly-not-a-token shape: `"TOKEN_OF_DOOM"` is fine.

## Why this matters in an i18n migration specifically

The `t.ts` translator and dict files live in the same module graph as the
scoring engine. While wiring up OG route locked keys (`@ui....`) you might
test with dictionary values that look like tokens (e.g. a brand prefix
`"ghf_" + 40` for a fake "github-feed" token). If a future agent pulls one
of those test fixtures out of context, the scanner takes the whole file down.

Lock the pattern in CONTRIBUTING:

- Comment around fake-token test fixtures: `// safe: real pattern masked`
- Pre-commit grep: `grep -rPn 'ghp_[A-Za-z0-9]{16,}|sk-[A-Za-z0-9]{20,}|xox[baprs]-...' --include='*.ts' --include='*.tsx' src/ tests/`
- If you find a masked-but-still-triggering one, lengthen the gap between
  the prefix and the next characters beyond 8 (e.g. `"ghp_short"`) so the
  pattern doesn't fire — then verify by pushing to a test branch.

## What does NOT help

- **Marking the file as "test"** — the scanner reads content, not path.
- **Adding a comment "this is a fake token"** — content-level redaction only.
- **Splitting the prefix across concatenations** — `"gh" + "p_xxx"` still
  trips the scanner; it normalises string literals.

## Cleanup when you trip the scanner

1. The push is blocked but the commit is local. Edit the file.
2. Amend the commit (`git commit --amend`) so the bad string isn't in
   history — secret-scanner bans **history** not just HEAD.
3. If already pushed: `git filter-branch` or `git filter-repo`, force-push,
   then ask a maintainer to unblock the PR. Don't bother doing this for a
   synthetic test string — the maintainer can manually push through.

## Related patterns

- `tistory-publisher-freshness-fp-evasion` skill: parallel case for
  Tistory's "freshness" detector being tripped by string matching in
  published posts. Different signal, same principle: detectors use plain
  string matching and trip on accidental shape matches.
- General: ship fixtures with masked strings, never real-shape tokens.
