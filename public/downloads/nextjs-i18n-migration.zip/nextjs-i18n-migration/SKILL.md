---
name: nextjs-i18n-migration
description: "Retrofit i18n into a Next.js app with EN-only copy."
version: 0.1.0
platforms: [macos, linux]
metadata:
  hermes:
    tags: [nextjs, i18n, typescript, react, refactor]
---

# Next.js i18n Migration

A class-level recipe for retrofitting i18n onto an existing Next.js app where copy is hard-coded in components, scoring/data layers, OG image routes, and error pages. Goal: clean dict + `t()` API consumed by the rendering layer, with **OG/JSON cards pinned to EN** and a **drift guard** that fails the test suite if any locale drifts behind.

Trigger conditions:

- Repo has string literals across components, error pages, scoring blurbs/playstyles, and OG/JSON card generators
- A user requested "add Korean / Spanish / other locale support"
- You inherited a fork and noticed EN is the only locale
- A scoring/data layer mixes copy + numbers (e.g. "1.2k stars") and you need a single place to override the noun per locale

## 1. Why this isn't next-intl / next-i18next

Use next-intl if you're greenfielding a Next.js app. For a retrofit where copy is already leaking into 50+ components and a scoring/data layer, next-intl's bundle wiring fights you on every edit. A 200-line hand-rolled dict + `t()` covers the same surface area in one file with no new transitive deps.

## 2. Directory shape

```
lib/i18n/
├── index.ts          — Locale union, isLocale, negotiateLocale (Accept-Language),
│                        LOCALE_COOKIE_NAME, LOCALE_COOKIE_MAX_AGE
├── dictionaries.ts   — Record<Locale, Dictionary> — the only file that
│                        imports each locale dict
├── dict/
│   ├── types.ts      — `Dictionary` interface (precise shape of every key)
│   ├── en.ts         — the seed locale
│   └── ko.ts         — same keys; the drift test catches missing ones
├── t.ts              — `t(key, locale, params)` + namespaced helpers
│                        (`t.archetype`, `t.playstyle`, `t.metric`,
│                        `t.workRate_reason`, `t.attribute.*`, `t.style`,
│                        `t.pun`)
├── format.ts         — formatCount(n, locale), formatInt(n, locale)
├── server.ts         — resolveServerLocale(), resolveEnglishLocale()
├── LocaleProvider.tsx— "use client" — useState + cookie read/write,
│                        dispatches `gitfut:localechange` window event
├── useLocale.ts      — useSyncExternalStore + custom event listener
└── hooks.ts          — useUIDict(), useT(), useActiveLocale()
```

## 3. Dict shape — the part that gets wrong

Pitfalls, each cost a debug cycle in the original session:

- **Function-shaped entries must be typed as functions, not strings.** `workRate.reason: "{attack} ..."` looks fine but breaks Dictionary narrowing. Write `(vars: { attack; defense }) => \`Attack ${vars.attack}...\``. Same for `winnerA/B` in duel, `tweetTemplate`, `playstyle.plusSuffix`. If the type says `ReasonWithVarsFn` and you put a string, both the drift test passes AND the type checker fails — double guard.
- **Lean namespaced helpers over monolith t().** `t.archetype("poacher", "ko")` returns `{ name, blurb }` at the callsite — autocompleted, refactor-safe, type-narrowed. A single `t()` with string keys forces every caller to cast.
- **Keep enum-string discriminators outside the dict.** If a `Card` field is typed `finish: "bronze" | "silver" | ...`, do NOT translate the enum. The display label goes through `t.finishLabel(finish, locale)`, the serializable value stays. This lets OG, JSON, localStorage, and analytics keep EN-keyed values.
- **Locked `@` prefix as the OG/card escape hatch.** `t("@ui.scoutForm.headline", "ko")` always returns EN. Components that double as OG-image sources or social-card templates use `@` for every visible string — see step 6.
- **Preserve a legacy `METRIC_LABELS`-style export for backwards compatibility.** If the existing codebase imports display-label strings as a vocabulary (duel.ts, tests), keep a flat EN-shaped `METRIC_LABELS = { commits: "Commits", ... }` and let the dict be the locale-aware override layer above it. Drift is then two-step: rename in METRIC_LABELS → rename in en.ts → ko.ts.
- **Don't put the dict inside `@/types`.** Imports across the project need a stable `getDict(locale)` entry. Put `dictionaries.ts` at the module root so the LocaleProvider, useLocale hook, and t.ts all share one resolve path.

## 4. Drift guard — mandatory, write BEFORE the second locale

```ts
// tests/i18n.test.ts
const walk = (o: unknown, path: string[] = []): string[] => {
  if (o == null || typeof o === "string" || typeof o === "function") return path.length ? [path.join(".")] : [];
  if (Array.isArray(o)) return o.flatMap((v, i) => walk(v, [...path, String(i)]));
  if (typeof o === "object") return Object.entries(o).flatMap(([k, v]) => walk(v, [...path, k]));
  return [];
};
it("en + ko have the same key set (drift detector)", () => {
  const enKeys = new Set(walk(getDict("en")));
  const koKeys = new Set(walk(getDict("ko")));
  expect([...enKeys].filter((k) => !koKeys.has(k))).toEqual([]);
  expect([...koKeys].filter((k) => !enKeys.has(k))).toEqual([]);
});
```

Add a key to en.ts without ko.ts → test fails. Add to ko.ts without en.ts → same.

## 5. Server-side locale resolution

For App Router projects:

```ts
// app/layout.tsx (server component)
import { cookies } from "next/headers";
import { LOCALE_COOKIE_NAME, localeFromCookie, type Locale } from "@/lib/i18n";
import { LocaleProvider } from "@/lib/i18n/LocaleProvider";

export default async function RootLayout({ children }) {
  const cookieStore = await cookies();
  const locale = localeFromCookie(cookieStore.get(LOCALE_COOKIE_NAME)?.value);
  return (
    <html lang={locale}>
      <body>
        <LocaleProvider initialLocale={locale}>{children}</LocaleProvider>
        ...
      </body>
    </html>
  );
}
```

- `await cookies()` is mandatory in Next 15+; sync `cookies()` throws.
- The provider gets `initialLocale={locale}` so first paint matches the cookie.
- Server components use `resolveServerLocale()` (cookie > AL > default). Pin to EN for OG/JSON routes via `resolveEnglishLocale()`.

## 6. OG / card pinning — the most-missed requirement

Social embeds must stay in EN regardless of viewer locale. Three enforced layers:

1. **buildCard / score functions take `(signals, locale)` with default `"en"`**. The OG route / JSON API call without specifying locale → automatic EN.
2. **Dict `@`-prefix for component-level strings** that the OG route renders ("OFFSIDE", "Match abandoned").
3. **Dictionary `: "en"` for social-only copy** — twitters, share-tweet templates with brand hashtag.

Test: run the OG route with `Cookie: gitfut_locale=ko`. The rendered image should still read English.

## 7. Locale toggle component (client only)

```tsx
// components/LocaleToggle.tsx
"use client";
export default function LocaleToggle() {
  const locale = useLocale();  // useSyncExternalStore on cookie
  const next = SUPPORTED_LOCALES[(SUPPORTED_LOCALES.indexOf(locale) + 1) % SUPPORTED_LOCALES.length];
  return (
    <button onClick={() => {
      writeLocaleCookie(next, LOCALE_COOKIE_MAX_AGE);
      // writeLocaleCookie fires `gitfut:localechange` window event —
      // useLocale subscribers re-render. No router.refresh() needed
      // for client-only copy; server-rendered copy picks up the
      // cookie on next navigation.
    }}>...</button>
  );
}
```

Pair `writeLocaleCookie` with `window.dispatchEvent(new Event("gitfut:localechange"))` so subscriber hooks flip without a full reload. Keep cookie max-age ≥ 1 year — it's a deliberate user choice, not detection drift.

## 8. Incremental signature migration (least churn on data layer)

For an existing `buildCard(signals: Signals): Card` with copy baked into the scoring engine, the *order* of changes matters:

1. Add `locale` parameter with default `"en"` everywhere: `buildCard(s, locale = "en")`.
2. Replace string literals in the function body with `t.fn(...).with(...)` calls.
3. Add `locale` parameter to each helper it calls (attributes, playstyles, scoring) with the same default.
4. Update tests to call `buildCard(s, "en")` explicitly OR keep default and let them pass.
5. **Do not change the Card type's serializable fields** (e.g. don't rename `finish: Finish` to `finishLabel: string` — keep `finish: Finish` AND add `finishLabel` for display).

Old call sites `map(buildCard)` break because `(s: Signals) => Card` no longer matches. Fix: `map((s) => buildCard(s))` (lambda breaks second-arg inference). The diagnostic looks like a TypeScript mismatch on `locale` but the actual cause is the map callback signature.

## 9. Diagnostic pitfalls — these look like i18n bugs but are environment state

| Symptom | Real cause | Fix |
|---|---|---|
| `Expected 1 arguments, but got 2` inside `t.attribute.skillMoves(...)` | Old `formatCount(n: number): string` (single-arg) is still imported | Update import path to `lib/i18n/format` (two-arg) |
| `tsc` reports errors that disappear after re-importing the same file | `.next` cache or stale `.tsbuildinfo` | `rm -rf .next .tsbuildinfo node_modules/.cache && npx tsc --noEmit` |
| `t("ui.howItWorks.ladder", locale)` returns `[object Object]` or undefined | Array paths can't be reached through dotted `t()` — only leaves / objects | Read arrays via `getDict(locale).ui.howItWorks.ladder` directly, not via `t()` |
| `Object.values(METRIC_LABELS)` test fails after rename | METRIC_LABELS holds EN display labels (vocabulary); dict holds locale versions — they should be the same in en.ts | Keep one canonical place for EN display strings; have tests assert against METRIC_LABELS, not dict values |

## 10. Verification sequence

After implementing, run these in order:

1. `npx tsc --noEmit` → 0 errors
2. `npm test` → all pre-existing tests still pass + `tests/i18n.test.ts` passes
3. `npm run lint` → no new warnings (existing warnings are fine; document them)
4. `npm run dev` → load `/`, click `<LocaleToggle/>`:
   - Cookie `gitfut_locale` flips between `en` / `ko`
   - Client components re-render with localized copy
   - Server-side metadata (`<title>`, OG `<meta>`) stays in EN (by design)
   - `<html lang>` reflects the active locale
5. `git push` → check the GitHub secret scanner doesn't trip on token-looking strings in t.ts. If a placeholder string `"ghp_..."` or `"xoxb-..."` is used in any test, mask it as `***`. See `references/github-secret-scanner-pitfalls.md`.

## 11. Out of scope (later sessions)

- Locale-aware URL routing (`/ko/torvalds`) — flip once dicts mature
- Server-component re-render on cookie change in the same tab — needs `useRouter().refresh()` wiring; out of scope for the initial retrofit
- Translation platforms (Crowdin, Lokalise) integration — do not introduce until at least 3 locales
- ICU MessageFormat / plural rules — only needed for languages with complex plural forms (Russian, Arabic, Polish)
