---
name: device-environment-migration
description: "macOS/Linux 사용자 디바이스 간 환경 이전 워크플로. Intel ↔ Apple Silicon, PC 교체, 새 노트북 셋업 시 발동. Hermes 에이전트 + 개발 도구 + 인증 토큰 + venv/node_modules + 시스템 cron + zshrc/LaunchAgent까지 한 번에 이전. **압축 exclude 패턴의 반복 함정** + **아키텍처 의존성(virtualenv, node_modules, wheel) 재설치 필요** + **인증 파일 권한(700/600) 복원** + **시스템 경로 하드코딩 사용자명/디렉토리 동일성** + **공식 `hermes backup`/`hermes import` 우선 확인** 등 비자명한 함정 16종 정리. 'M4 맥미니로 옮길꺼야', 'PC 교체', '새 노트북 셋업', '환경 이전', '백업 + 복원' 요청에 발동."
trigger: "macOS/Linux 디바이스 간 사용자 환경 이전. 'M1/M2/M3/M4 맥미니/맥북 교체', 'Intel → Apple Silicon', 'PC 바꾸기', '새 노트북 셋업', '환경 백업/복원', 'venv 재구성', 'Hermes 이전' 요청 시 발동. **반드시** Phase 0 사전 점검 → Phase 1 백업 → Phase 2 신규 셋업 → Phase 3 이전 → Phase 4 venv 재생성 → Phase 5 검증 6단계 사이클."
version: 0.1.3
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [migration, backup-restore, macos, apple-silicon, hermes, venv, node-modules, crontab, system-admin, migration-dir]
    related_skills: [direct-device-execution, hermes-agent]
---

# Device Environment Migration (디바이스 환경 이전 워크플로)

사용자 디바이스(macOS/Linux) 교체 시 **사용자 환경 전체를 이전**하는 클래스. 단순 파일 복사가 아니라 **아키텍처 의존성 + 인증 + 시스템 설정**을 한 사이클로 처리.

**검증 사례 (2026-06-25)**:
- Intel iMac → M4 맥미니 예정
- Hermes 9.6GB → **214MB 압축** (97.7% 절감, 5단계 exclude 정밀화)
- 5종 백업 파일 생성 (`hermes_migrate.tar.gz`, `notebook_auth.tar.gz`, `crontab.txt`, `zshrc_backup.txt`, `bash_profile_backup.txt`)
- 47개 항목 dry-run 검증 스크립트로 마이그레이션 가능 여부 사전 확인
- **9개 파일 단일 폴더화** (`M4_Migration_20260625/`) → `MIGRATION_DIR` 환경변수 패턴 도입 → 스크립트 2종 + MIGRATION.md 경로 일괄 통일
- **`hermes backup` 공식 명령어 발견** (2026-06-25 추가) — `state.db` SQLite 안전 백업 + 자동 canonical exclude + `hermes import` 한 줄 복원. **공식 backup을 우선으로**, 시스템 레벨(crontab/zshrc/notebooklm_auth)은 수동 백업 = 이중 안전망

---

## 트리거 시그널

- "M4 맥미니로 옮길꺼야" / "PC 교체" / "새 노트북 셋업"
- "환경 이전" / "백업 + 복원" / "이사"
- "venv 재구성" / "venv 통째 복사" (함정 신호)
- "Hermes 옮기기" / "에이전트 이전"
- "데스크탑에 폴더 만들어 정리" / "관련 파일 한곳에" (P14 트리거)

## 절대 트리거 X

- 단순 파일 1\~2개 이동 (cp로 충분)
- 다른 PC에서 작업 (→ `python-oss-bootstrap` Phase 0)
- 클라우드 동기화 (iCloud/Dropbox로 충분)

---

## ⚠️ P15 함정 (2026-06-25 추가) — **공식 `hermes backup`을 먼저 확인하라**

**증상**: 백업 시작 전에 `hermes backup`/`hermes import` 공식 명령어가 있는지 먼저 탐색하지 않으면, 정크 스크립트(tar + 30+ exclude)로 `state.db` (SQLite 2GB) 같은 비-트래버설 안전 처리가 필요한 항목을 **그냥 포함하거나 무식하게 exclude**하게 됨. 사용자가 "공식백업 기능 있는 것 같던데?"라고 지적해서야 발견.

**탐지 단계 (Phase 0 맨 앞에 추가)**:
```bash
# 0-a) 공식 백업 명령 우선 확인
hermes backup --help 2>&1 | head -10
# → 옵션이 보이면 공식 backup 사용 결정

# 0-b) 결과 비교
echo "공식 backup 사용 시: state.db 안전, hermes-agent 자동 제외, hermes import 한 줄 복원"
echo "수동 backup 사용 시: 시스템 레벨(crontab/zshrc/notebooklm)까지 한 번에 다룸"
```

**공식 backup의 강점 (커버하지 못한 영역)**:
- **`state.db` SQLite 안전 백업** — `sqlite3.backup()` API로 일관된 스냅샷 (WAL/journal 안 깨짐)
- **자동 canonical exclude** — `hermes-agent/`, `__pycache__/`, `node_modules/`, `backups/`, `.venv/`, `venv/`, `site-packages/`, `.cache/`, `.git/`, `*.pyc`, `*.db-wal` 등 코드베이스가 알고 있는 재생성 가능 항목
- **`hermes import` 한 줄 복원** — zip overlay 자동, 권한 조정
- **백업 중첩 방지** — `backups/` 디렉토리 자동 제외
- **버전 호환 검증** — 백업/복원 CLI가 같은 Hermes 버전 가정으로 작동

**수동 스크립트가 여전히 필요한 영역**:
- 시스템 crontab (`crontab -l`)
- `~/.zshrc`, `~/.bash_profile`, `~/.zprofile`
- `~/.ssh/` (SSH 키)
- **`~/.notebooklm/`** (Hermes 외부)
- 시스템 디렉토리 (`/Users/<user>/clawd/`, `~/.openclaw/workspace/` 등)

**⚠️ 권장 전략 (이중 안전망)**:
```bash
# 메인 백업 (Hermes 안전 + 포괄)
hermes backup --output ~/Desktop/M4_Migration_${DATE}/hermes_official.zip
# → 2.5GB, state.db 포함, hermes-agent 자동 제외

# 보조 백업 (시스템 레벨 — 수동)
tar czf ~/Desktop/M4_Migration_${DATE}/notebook_auth_${DATE}.tar.gz ~/.notebooklm/profiles/default/storage_state.json
crontab -l > ~/Desktop/M4_Migration_${DATE}/crontab_${DATE}.txt
cp ~/.zshrc ~/.bash_profile ~/Desktop/M4_Migration_${DATE}/

# 결과: M4_Migration_20260625/ 폴더 안에 hermes_official.zip + 4종 보조 파일
```

**M4 복원 (한 줄)**:
```bash
hermes import ~/Desktop/M4_Migration_20260625/hermes_official.zip
# → SQLite 안전 복원 + 권한 자동 + hermes-agent 재설치 안내
```

**공식 backup 사용 시 `state.db` 결정 포인트 자동 해결**:
- 이전 방식 (수동): `state.db` 2GB 제외 vs 포함 결정 → 사용자에게 confirm 필요
- 공식 방식 (`hermes backup`): `state.db` 자동 포함 (SQLite 안전 스냅샷) → 결정 불필요, 141K 메시지 + FTS 인덱스 모두 보존

**함정 인식 신호** (이런 패턴 보이면 공식 backup 의심):
- "직접 tar + 30+ exclude 패턴 짜는 중" → `hermes backup --help` 먼저 실행
- "`state.db` 너무 커서 제외할지" 고민 → 공식 backup이면 안전하게 포함 가능
- "`hermes-agent` 내부 .git/venv 어떻게 빼지" → 공식은 자동
- "수동 import 스크립트 어떻게 짜지" → `hermes import` 있음

**예방 (다음 마이그레이션 시작 시 첫 명령)**:
```bash
# 어떤 작업이든 Phase 0 진입 전
hermes backup --help
hermes import --help
hermes channels --help
# → 사용 가능한 공식 도구 먼저 파악
```

---

## 6단계 핵심 워크플로

### Phase 0: 사전 점검 (현재 PC, 30분)

```bash
# 0-1) 시스템 cron
crontab -l > ~/Desktop/crontab_$(date +%Y%m%d).txt

# 0-2) Hermes 크기 + 핵심 파일 인벤토리
du -sh ~/.hermes/
ls -la ~/.hermes/{config.yaml,MEMORY.md,SOUL.md,USER.md,auth.json,.env}

# 0-3) venv 목록 (재생성 대상)
ls -la ~/.hermes/venv* 2>&1
du -sh ~/.hermes/venv-notebooklm/ ~/.hermes/venv-notebooklm-enterprise/ ~/.hermes/venvs/

# 0-4) NotebookLM 인증 (위치 함정 있음)
find ~/.notebooklm/ -maxdepth 4 -name "storage_state*" -ls

# 0-5) API 키/시크릿
ls -la ~/.hermes/secrets/
```

**⚠️ P0 함정**: `storage_state.json`은 보통 `~/.notebooklm/profiles/default/`에 있음. 루트에 없는 경우가 많아서 `find`로 위치 확인 필수.

**⚠️ P1 함정**: `state.db`는 SQLite 141K 메시지, **2GB 차지**. `MEMORY.md` + `memory/` 디렉토리로 90% 복원 가능 → 제외 권장. 결정 포인트로 사용자에게 확인.

---

### Phase 1: 백업 생성 (30분)

**핵심 압축 명령** (Hermes 디렉토리 9.6GB → 214MB):

```bash
DATE=$(date +%Y%m%d)
tar czf ~/Desktop/hermes_migrate_${DATE}.tar.gz \
  --exclude='venv-notebooklm' \
  --exclude='venv-notebooklm-enterprise' \
  --exclude='venvs' \
  --exclude='node_modules' \
  --exclude='sessions' \
  --exclude='state-snapshots' \
  --exclude='cache' \
  --exclude='logs' \
  --exclude='audio_cache' \
  --exclude='.DS_Store' \
  --exclude='__pycache__' \
  --exclude='*.pyc' \
  --exclude='*.wasm' \
  --exclude='*.map' \
  --exclude='.pytest_cache' \
  --exclude='hermes-agent/venv' \
  --exclude='hermes-agent/.venv' \
  --exclude='hermes-agent/node_modules' \
  --exclude='hermes-agent/build' \
  --exclude='hermes-agent/dist' \
  --exclude='hermes-agent/.next' \
  --exclude='hermes-agent/.turbo' \
  --exclude='hermes-agent/coverage' \
  --exclude='hermes-agent/.git' \
  --exclude='hermes-agent/**/.git' \
  --exclude='notebooklm_env' \
  --exclude='lsp/node_modules' \
  --exclude='state.db' \
  --exclude='state.db-wal' \
  --exclude='state.db-shm' \
  ~/.hermes/
```

**⚠️ P2 함정 (최다 반복, 4차 시도)**: `hermes-agent/` 내부에도 `.git`, `venv`, `node_modules`가 있어요. 루트 레벨 `--exclude='venv*'` / `--exclude='node_modules'`로는 nested 항목 못 잡음. **`hermes-agent/.git`, `hermes-agent/venv`, `hermes-agent/node_modules` 명시 필요**.

**⚠️ P3 함정**: `--exclude='*.git'` 같은 glob은 `.git` 디렉토리 자체와 일치 안 함. 반드시 `--exclude='path/.git'` 형식으로 경로 명시.

**⚠️ P4 함정**: `hermes-agent/skills/webwright` 같은 nested `.git`은 `--exclude='hermes-agent/.git'`만으로 부족. **`--exclude='hermes-agent/**/.git'`** 필요 (검증: 4차 반복에서 발견).

**NotebookLM 인증 별도 백업**:
```bash
tar czf ~/Desktop/notebook_auth_${DATE}.tar.gz \
  ~/.notebooklm/profiles/default/storage_state.json \
  ~/.notebooklm/storage_state.json.bak.personal \
  ~/.notebooklm/storage_state.json.personal_backup
```

**시스템 crontab + 쉘 환경**:
```bash
crontab -l > ~/Desktop/crontab_${DATE}.txt
cp ~/.zshrc ~/Desktop/zshrc_backup.txt
cp ~/.zprofile ~/Desktop/zprofile_backup.txt 2>/dev/null
cp ~/.bash_profile ~/Desktop/bash_profile_backup.txt 2>/dev/null
cp -r ~/.ssh ~/Desktop/ssh_backup_${DATE}/  # (있으면)
```

**이동 5종 파일**:
| 파일 | 크기 | 전송 방법 |
|---|---:|---|
| `hermes_migrate_${DATE}.tar.gz` | ~214MB | AirDrop / SSD / 클라우드 |
| `notebook_auth_${DATE}.tar.gz` | ~수KB | 위와 동일 |
| `crontab_${DATE}.txt` | 1KB | 위와 동일 |
| `zshrc_backup.txt`, `bash_profile_backup.txt` | 2KB | 위와 동일 |
| `ssh_backup_${DATE}/` (선택) | 수KB | 위와 동일 |

---

### Phase 1.5: 단일 폴더화 + `MIGRATION_DIR` 환경변수 패턴 (P14, 2026-06-25 추가)

사용자가 "데스크탑에 폴더 하나 만들어서 모두 정리해줘" 요청 시 수행. **백업 파일들을 `M4_Migration_${DATE}/` 단일 폴더로 묶고, 모든 스크립트의 하드코딩 경로를 `MIGRATION_DIR` 환경변수로 일괄 변경**하는 패턴.

```bash
DATE=$(date +%Y%m%d)
FOLDER=~/Desktop/M4_Migration_${DATE}

mkdir -p "$FOLDER"
mv ~/Desktop/hermes_migrate_${DATE}.tar.gz "$FOLDER/"
mv ~/Desktop/notebook_auth_${DATE}.tar.gz "$FOLDER/"
mv ~/Desktop/crontab_${DATE}.txt "$FOLDER/"
mv ~/Desktop/zshrc_backup.txt "$FOLDER/"
mv ~/Desktop/bash_profile_backup.txt "$FOLDER/"
mv ~/Desktop/ssh_backup_${DATE} "$FOLDER/"
mv ~/Desktop/restore_hermes.sh "$FOLDER/"
mv ~/Desktop/verify_migration.sh "$FOLDER/"
mv ~/Desktop/MIGRATION.md "$FOLDER/"
```

**⚠️ P14 함정 (2026-06-25 추가)**: 폴더로 묶으면 기존 스크립트(`restore_hermes.sh`, `verify_migration.sh`)가 `~/Desktop/hermes_migrate_*.tar.gz` 같은 하드코딩 경로를 찾으려 해서 **즉시 모든 검증 FAIL로 떨어짐**. 해결:

```bash
# 스크립트 상단에 환경변수 fallback 추가
MIGRATION_DIR="${MIGRATION_DIR:-$HOME/Desktop/M4_Migration_${DATE}}"
# 모든 ~/Desktop/ → $MIGRATION_DIR/ 일괄 변경 (patch 도구로 replace_all)
```

**M4에서 사용법**:
```bash
# 기본 (폴더 안에 있을 때)
bash ~/Desktop/M4_Migration_20260625/restore_hermes.sh

# 다른 위치 (Downloads/Migration 등)
MIGRATION_DIR=~/Downloads/Migration bash ~/Desktop/M4_Migration_20260625/restore_hermes.sh
```

**장점**:
- AirDrop으로 **폴더째** 한 번에 전송 가능 (파일 9번 보낼 필요 없음)
- M4에서도 같은 폴더 구조 유지 → 스크립트가 자동 인식
- 환경변수 fallback으로 위치 자유도 유지

**MIGRATION.md 가이드 문서 업데이트**:
- 모든 명령 예시의 `~/Desktop/hermes_migrate_*.tar.gz` → `~/Desktop/M4_Migration_*/...` 경로로 일괄 수정
- Phase 1.5 섹션을 문서 상단에 추가하여 사용자가 동일 폴더 구조 인식
- `MIGRATION_DIR` 환경변수 옵션 명시

---

### Phase 2: 신규 PC 셋업 (M4 맥미니, 1시간)

```bash
# 2-1) macOS 초기 설정 (Apple ID, Wi-Fi, 사용자명 동일하게 — 중요!)

# 2-2) Homebrew (M4 = Apple Silicon → /opt/homebrew/)
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# 2-3) Python (M4 네이티브는 3.12/3.13)
brew install python@3.12

# 2-4) Node.js
brew install node@22

# 2-5) Git + Xcode CLT
brew install git
xcode-select --install  # 5분, 대화형

# 2-6) Rosetta 2 (x86 패키지 필요 시)
softwareupdate --install-rosetta --agree-to-license

# 2-7) 디렉토리 준비
mkdir -p ~/.hermes/secrets ~/.notebooklm
```

**⚠️ P5 함정**: Apple Silicon은 `/opt/homebrew/`, Intel은 `/usr/local/`. **사용자명(예: `hjshin`)과 디렉토리 구조를 동일하게** 만들어야 시스템 cron 잡과 hermes 설정 경로가 작동.

**⚠️ P6 함정**: `~/.hermes/secrets/`는 반드시 **`chmod 700`** (소유자만 읽기/쓰기/실행). 안 그러면 Hermes가 토큰 로드 거부.

---

### Phase 3: 압축 해제 + 이전 (15분)

```bash
# 3-1) 백업 가져오기 (AirDrop/SSD/클라우드, 폴더째 전송)

# 3-2) 압축 해제
cd ~
tar xzf "$MIGRATION_DIR/hermes_migrate_${DATE}.tar.gz"
tar xzf "$MIGRATION_DIR/notebook_auth_${DATE}.tar.gz"

# 3-3) 권한/소유권 정리 (UID가 달라질 수 있음)
chown -R $(whoami):staff ~/.hermes/
chown -R $(whoami):staff ~/.notebooklm/
chmod 700 ~/.hermes/secrets/
chmod 600 ~/.hermes/secrets/*

# 3-4) 시스템 crontab 복원
crontab "$MIGRATION_DIR/crontab_${DATE}.txt"

# 3-5) 쉘 환경 복원 (기존 파일은 .before_restore로 백업)
[ -f ~/.zshrc ] && cp ~/.zshrc ~/.zshrc.before_restore 2>/dev/null
cp "$MIGRATION_DIR/zshrc_backup.txt" ~/.zshrc
[ -f ~/.bash_profile ] && cp ~/.bash_profile ~/.bash_profile.before_restore 2>/dev/null
cp "$MIGRATION_DIR/bash_profile_backup.txt" ~/.bash_profile

# 3-6) Hermes 설치/인증
pip install hermes-agent   # 또는 공식 설치 절차
hermes login
```

**⚠️ P7 함정**: `tar`가 절대경로에서 leading `/`를 빼면서 `Users/<user>/.hermes/...` 형식으로 풀림. `cd ~` 후 풀면 정상 복원되지만, `cd /`에서 풀면 다른 사용자 디렉토리에 들어갈 위험.

**⚠️ P8 함정**: 시스템 cron에 `/Users/hjshin/clawd/...`, `/Users/hjshin/.openclaw/workspace/...` 같은 **경로 하드코딩**. M4에서 같은 사용자명 + 같은 디렉토리 구조 안 만들면 cron이 조용히 실패함. `crontab -l`로 경로 먼저 확인.

---

### Phase 4: venv 재생성 (30분, **M4에서 필수**)

**venv는 아키텍처 의존성 있어서 통째 복사 불가** (Intel wheel이 M4에서 깨짐).

```bash
# 4-1) venv 3개 재생성
for name in venv-notebooklm venv-notebooklm-enterprise venvs; do
  python3.12 -m venv --clear ~/.hermes/$name
done

# 4-2) notebooklm venv (Hermes 워크플로우용)
source ~/.hermes/venv-notebooklm/bin/activate
pip install --upgrade pip
pip install "notebooklm-py[browser]"   # ⚠️ [browser] extra 필수 (Playwright 의존)
playwright install chromium            # 97.5MB 다운로드
pip install requests google-api-python-client \
            google-auth-oauthlib google-auth-httplib2
deactivate

# 4-3) 다른 venv는 ~/.hermes/venvs/<name>/requirements.txt 일괄 설치
ls ~/.hermes/venvs/
```

**⚠️ P9 함정**: `notebooklm-py` (정확한 패키지명) vs `notebooklm` (PyPI에 없음). `pip install notebooklm`은 "No matching distribution" 오류. **반드시 `notebooklm-py`** 사용.

**⚠️ P10 함정**: `notebooklm-py[browser]` extra + `playwright install chromium` 둘 다 필수. 하나만 설치하면 `notebooklm login`/`list` 즉시 실패.

---

### Phase 5: 검증 (30분)

```bash
# 5-1) Hermes 자체
hermes --version
hermes status

# 5-2) 메모리 로드 확인
ls -la ~/.hermes/MEMORY.md ~/.hermes/memory/

# 5-3) NotebookLM 인증 (쿠키 살아있는지)
~/.hermes/venv-notebooklm/bin/python3 -m notebooklm list --json | head -3

# 5-4) 크론 잡
crontab -l | head -10

# 5-5) YouTube 토큰
/usr/bin/python3 -c "
import pickle
c = pickle.load(open('/Users/hjshin/.hermes/secrets/youtube_token.pickle','rb'))
print(f'valid={c.valid}')"

# 5-6) 채널 재연결 (Telegram/Discord)
hermes channels list
hermes channels connect telegram
```

**⚠️ P11 함정**: YouTube 토큰은 M4에서 `valid=False`일 가능성 높음 (refresh_token 만료/폐기). 1차 refresh 시도 → 실패 시 풀 OAuth 필요. 토큰 상태 확인 5종 oneliner:

```bash
ls /Users/hjshin/.hermes/venv-notebooklm/bin/python3 && \
  grep -c '"date": "2026-06-' /Users/hjshin/.hermes/memory/notebooklm_selection.json && \
  ls /tmp/icbm_notebooklm/videos/ | wc -l && \
  /usr/bin/python3 -c "import pickle; print(pickle.load(open('/Users/hjshin/.hermes/secrets/youtube_token.pickle','rb')).valid)"
```

---

## 비자명한 함정 요약 (15종)

| # | 함정 | 영향 |
|---|---|---|
| P0 | `storage_state.json` 위치 (`profiles/default/`) | 백업 누락 |
| P1 | `state.db` 2GB (메모리로 대부분 복원) | 압축 비대화 |
| P2 | `hermes-agent/` 내부 `.git`/`venv`/`node_modules` | nested 항목 잔존 |
| P3 | `--exclude='*.git'` glob 함정 | `.git` 디렉토리 못 잡음 |
| P4 | nested `.git` (skills 안의 submodule) | `--exclude='path/**/.git'` 필요 |
| P5 | Apple Silicon `/opt/homebrew/` vs Intel `/usr/local/` | PATH 깨짐 |
| P6 | 시크릿 디렉토리 권한 700/600 | Hermes 토큰 로드 거부 |
| P7 | `tar` 절대경로 leading `/` 처리 | 다른 사용자 경로 오염 |
| P8 | cron 잡 경로 하드코딩 (사용자명/디렉토리) | cron 조용한 실패 |
| P9 | `notebooklm` vs `notebooklm-py` 패키지명 | pip install 실패 |
| P10 | `[browser]` extra + Playwright chromium 누락 | login/list 실패 |
| P11 | YouTube 토큰 refresh_token 폐기 | 재인증 필요 |
| P12 | bash 산술 비교 (`[[ $var -gt $n ]]`) 빈 문자열 에러 | set -u 환경 syntax error |
| P13 | `set -uo pipefail` 환경에서 main 컨텍스트 `local` 사용 | 즉시 exit ("can only be used in a function") |
| P14 | 단일 폴더화 시 스크립트 하드코딩 경로 깨짐 | `MIGRATION_DIR` 환경변수 패턴으로 해결 |
| **P15** | **공식 `hermes backup`/`hermes import` 명령어를 사전 탐색 안 함** | **`hermes backup --help` 먼저 실행 → SQLite 안전 백업 + hermes-agent 자동 제외 + 한 줄 복원** |

---

## 자주 빠뜨리는 5가지

1. **venv 통째 복사** → M4에서 즉시 깨짐 (Intel wheel). **반드시 재생성**.
2. **`state.db` 포함** → 2GB 추가. **제외 권장** (사용자 확인 후).
3. **`storage_state.json` 권한** → `chmod 600` 안 하면 NotebookLM 인증 실패.
4. **zshrc vs bash_profile 혼용** → zsh 기본이지만 시스템 일부가 bash_profile 참조 (Telegram, rbenv 등).
5. **Telegram/Discord 채널 재연결** → 새 PC에서 `hermes channels connect`로 다시 인증 필요.

---

## 📦 지원 파일 (재사용 가능)

- `scripts/migration-pre-check.sh` — Phase 0 점검 + Phase 1 백업 5종 자동 생성. `verify` 인자로 백업 무결성 검증만 단독 실행 가능.
- `scripts/migration-restore.sh` — Phase 3 복원 + Phase 4 venv 재생성 + Phase 5 5종 검증 한 번에.
- `scripts/migration-verify.sh` — **47개 항목 dry-run 검증** (4 모드: full/--backup/--restore/--preflight). 7개 카테고리: 백업 파일 / Hermes 환경 / 인증 / venv / 시스템 / 디렉토리 내용 / 메모리 & 설정. M4 복원 후 검증에 최적화. **`MIGRATION_DIR` 환경변수 fallback 지원** (v0.1.2+).
- `templates/MIGRATION.md` — 사용자용 7단계 수동 가이드 템플릿 (Phase 0\~5 + Troubleshooting 6종 + 체크리스트). `M4_Migration_${DATE}/` 폴더 구조에 맞춰진 경로 예시 포함.

> **사용 시점**:
> - **이 PC에서 (백업 전)**: `bash migration-pre-check.sh` → 점검 + 백업
> - **이 PC에서 (백업 검증)**: `bash migration-pre-check.sh verify`
> - **이 PC에서 (마이그레이션 가능 여부 dry-run)**: `bash migration-verify.sh`
> - **M4에서 (복원 전)**: `bash migration-restore.sh`
> - **M4에서 (복원 후 검증)**: `bash migration-verify.sh --restore`

---

## ⚠️ P12 함정 상세 (2026-06-25 추가, `migration-verify.sh` 첫 dry-run에서 발견)

검증 스크립트 작성 시 bash 산술 비교에서 빈 문자열/unset 변수 에러가 자주 발생:

```bash
# ❌ FAIL: 변수가 빈 문자열이면 syntax error
local count=$(find "$path" -maxdepth 3 -type f | wc -l | tr -d ' ')
if [[ $count -gt $expected_min ]]; then    # count가 비면 syntax error

# ❌ FAIL: set -u 환경에서 unbound variable
echo "⚠️ 경고 $WARN개"                       # main 컨텍스트의 WARN은 unbound

# ❌ FAIL: wc -l 결과에 줄바꿈이 끼면 빈 줄이 같이 비교됨
local job_count=$(crontab -l 2>/dev/null | grep -v '^#' | grep -v '^$' | wc -l | tr -d ' ')
```

**해결 패턴 (3가지)**:
1. **변수 직후 안전장치**: `count=${count:-0}`
2. **메인 컨텍스트 비교 시 braces**: `[[ ${WARN:-0} -eq 0 ]]`
3. **`grep -c` 실패 시 fallback**: `local provider_count=$(grep -c ... 2>/dev/null || true); provider_count=${provider_count:-0}`

**예방**: 모든 카운트/파싱 결과 변수에 `${var:-0}` 패턴 적용. `set -u`와 함께 쓸 때 특히 중요.

---

## ⚠️ P13 함정 상세 (2026-06-25 추가, `migration-verify.sh` 작성 중 발견)

`set -uo pipefail` + `set -e` 조합에서 **함수 밖 main 컨텍스트**에 `local` 키워드를 쓰면 "local: can only be used in a function" 에러로 스크립트 즉시 종료. 함수 안에서만 `local` 사용 가능, 메인 컨텍스트는 그냥 변수 할당.

```bash
# ❌ main 컨텍스트 (함수 밖)
local WARN_COUNT="$WARN"        # bash error → exit

# ✅ 함수 안
my_function() {
  local WARN_COUNT="$WARN"      # OK
}
```

**해결**: `local`을 함수 내부로 옮기거나, 메인에서는 `WARN_COUNT="$WARN"` (local 없이).

---

## ⚠️ P14 함정 상세 (2026-06-25 추가, 사용자 "데스크탑에 폴더 만들어 정리" 요청)

**증상**: 사용자가 "관련 파일 모두 어디에 있지?" → "데스크탑에 폴더 하나 만들고 거기에 모두 정리해줘" 요청 시, 백업 파일 9개를 `~/Desktop/M4_Migration_${DATE}/`로 일괄 이동. 그런데 기존 `restore_hermes.sh`/`verify_migration.sh`는 `~/Desktop/hermes_migrate_*.tar.gz`처럼 **하드코딩 경로**라 즉시 모든 백업 파일 검증을 FAIL로 떨어뜨림.

**해결 — `MIGRATION_DIR` 환경변수 패턴**:
1. 스크립트 상단에 환경변수 fallback 추가:
   ```bash
   MIGRATION_DIR="${MIGRATION_DIR:-$HOME/Desktop/M4_Migration_${DATE}}"
   DATE_TAG="20260625"  # 또는 다른 백업 날짜
   ```
2. 모든 `~/Desktop/${fname}` → `"$MIGRATION_DIR/${fname}"` 일괄 변경 (`patch` 도구의 `replace_all` 활용)
3. **빈 경로 fallback 시 명확한 에러 메시지**: 파일 없으면 어떤 경로에서 찾았는지 표시
4. `MIGRATION.md` 가이드 문서도 동일하게 경로 일괄 수정
5. 다른 위치에 두려면 `MIGRATION_DIR=~/Downloads/Migration bash ...`로 환경변수 override 가능

**검증**: 폴더 이동 후 즉시 `bash verify_migration.sh` 실행 → 모든 백업 파일 PASS 확인 필수.

**예방**: 마이그레이션 스크립트는 처음부터 절대경로 하드코딩 대신 환경변수 + 기본값 fallback 패턴 사용.

---

## 변경 이력

| 날짜 | 버전 | 내용 |
|---|---|---|
| 2026-06-25 | v0.1.0 | 초기 작성. Intel → M4 맥미니 예정 검증. 9.6GB → 214MB 압축, 11개 함정 (P0\~P11), 5종 백업 파일 생성 절차, 6단계 워크플로. |
| 2026-06-25 | v0.1.1 | `scripts/migration-verify.sh` 추가 (47개 항목 dry-run 검증, 4 모드). P12 (bash 산술 비교 빈 문자열), P13 (`set -uo pipefail` + main 컨텍스트 `local` 금지) 2개 함정 추가. 11종 → 13종 함정. 7개 카테고리 검증 체계 확립. |
| 2026-06-25 | v0.1.2 | **P14 (단일 폴더화 + `MIGRATION_DIR` 환경변수 패턴) 추가** — 사용자 "데스크탑에 폴더 만들어 정리" 요청에서 발견. Phase 1.5 신규 섹션, `templates/MIGRATION.md` 지원 파일, 13종 → 15종 함정. M4에서 폴더째 AirDrop 전송 가능 워크플로 확립. `MIGRATION_DIR` 환경변수 fallback으로 위치 자유도 확보. |
| 2026-06-25 | v0.1.3 | **P15 (공식 `hermes backup`/`hermes import` 우선 확인) 추가** — 사용자가 "공식백업 기능 있는 것 같던데?" 지적으로 발견. 정크 스크립트 작성 전 Phase 0 맨 앞에 `hermes backup --help` / `hermes import --help` 실행. SQLite `state.db` 안전 백업 + canonical exclude 자동 + 한 줄 복원의 장점. **이중 안전망 패턴**: 공식 backup (Hermes 포괄) + 수동 backup (시스템 crontab/zshrc/notebooklm). 15종 → 16종 함정. |