#!/bin/bash
# M4 맥미니 / 신규 PC에서 Hermes 환경 복원 스크립트
# 사용법: bash migration-restore.sh
#
# 전제조건:
#   1. macOS 초기 설정 + Homebrew + Python 3.12 + Node 설치 완료
#   2. 사용자명이 기존 PC와 동일 (예: hjshin)
#   3. ~/Desktop/ 에 백업 파일 5종 존재

set -e

DATE=$(date +%Y%m%d)
DESKTOP="$HOME/Desktop"

echo "============================================"
echo "🔄 Phase 3: Hermes 환경 복원"
echo "============================================"
echo ""

# 백업 파일 존재 확인
echo "📦 백업 파일 확인..."
for f in "hermes_migrate_${DATE}.tar.gz" "notebook_auth_${DATE}.tar.gz" \
         "crontab_${DATE}.txt" "zshrc_backup.txt" "bash_profile_backup.txt"; do
    if [ ! -f "${DESKTOP}/${f}" ]; then
        echo "❌ ${f} 없음. ${DESKTOP}/${f} 확인 필요."
        exit 1
    fi
    echo "  ✅ $f"
done

echo ""
echo "💾 Phase 3-1: 압축 해제"
cd ~
tar xzf "${DESKTOP}/hermes_migrate_${DATE}.tar.gz"
tar xzf "${DESKTOP}/notebook_auth_${DATE}.tar.gz"
echo "  ✅ 압축 해제 완료"

echo ""
echo "🔐 Phase 3-2: 권한 정리"
chown -R $(whoami):staff "$HOME/.hermes/"
chown -R $(whoami):staff "$HOME/.notebooklm/"
chmod 700 "$HOME/.hermes/secrets/"
chmod 600 "$HOME/.hermes/secrets/"*
echo "  ✅ 권한 정리 완료"

echo ""
echo "⏰ Phase 3-3: 시스템 cron 복원"
crontab "${DESKTOP}/crontab_${DATE}.txt"
echo "  ✅ crontab 복원 완료 ($(crontab -l | wc -l) lines)"

echo ""
echo "🐚 Phase 3-4: 쉘 환경 복원"
cp "${DESKTOP}/zshrc_backup.txt" "$HOME/.zshrc" 2>/dev/null && echo "  ✅ zshrc 복원" || echo "  ⚠️  zshrc 스킵"
cp "${DESKTOP}/bash_profile_backup.txt" "$HOME/.bash_profile" 2>/dev/null && echo "  ✅ bash_profile 복원" || echo "  ⚠️  bash_profile 스킵"

echo ""
echo "🚀 Phase 3-5: Hermes 설치"
if command -v hermes &> /dev/null; then
    echo "  ✅ hermes 이미 설치됨: $(hermes --version)"
else
    echo "  pip install hermes-agent 실행..."
    pip install hermes-agent
    echo "  ✅ hermes 설치 완료"
fi

echo ""
echo "============================================"
echo "🔨 Phase 4: venv 재생성 (필수!)"
echo "============================================"
echo ""

# venv 재생성
for name in venv-notebooklm venv-notebooklm-enterprise venvs; do
    if [ -d "$HOME/.hermes/$name" ]; then
        echo "⏱️  $name 재생성..."
        python3.12 -m venv --clear "$HOME/.hermes/$name"
        echo "  ✅ $name 재생성 완료"
    fi
done

# notebooklm venv 패키지
echo ""
echo "⏱️  notebooklm 패키지 설치..."
"$HOME/.hermes/venv-notebooklm/bin/pip" install --quiet --upgrade pip
"$HOME/.hermes/venv-notebooklm/bin/pip" install --quiet "notebooklm-py[browser]"
"$HOME/.hermes/venv-notebooklm/bin/playwright" install chromium 2>&1 | tail -2
"$HOME/.hermes/venv-notebooklm/bin/pip" install --quiet \
    requests google-api-python-client google-auth-oauthlib google-auth-httplib2
echo "  ✅ notebooklm 환경 설치 완료"

echo ""
echo "============================================"
echo "✅ Phase 5: 검증 (5종 체크)"
echo "============================================"
echo ""

# 5-1) venv 인터프리터
if [ -f "$HOME/.hermes/venv-notebooklm/bin/python3" ]; then
    echo "✅ venv 인터프리터 OK"
else
    echo "❌ venv 인터프리터 없음"
fi

# 5-2) 메모리
if [ -f "$HOME/.hermes/MEMORY.md" ]; then
    echo "✅ MEMORY.md OK ($(wc -c < "$HOME/.hermes/MEMORY.md") bytes)"
else
    echo "❌ MEMORY.md 없음"
fi

# 5-3) NotebookLM 인증
echo ""
echo "⏱️  NotebookLM 인증 검증..."
if "$HOME/.hermes/venv-notebooklm/bin/python3" -m notebooklm list --json 2>&1 | head -3 | grep -q '"notebooks"'; then
    echo "✅ NotebookLM 인증 OK"
else
    echo "❌ NotebookLM 인증 실패 (재로그인 필요: notebooklm login)"
fi

# 5-4) Cron
echo ""
echo "⏱️  Cron 잡 확인:"
crontab -l | head -5

# 5-5) YouTube 토큰
echo ""
echo "⏱️  YouTube 토큰 검증..."
/usr/bin/python3 -c "
import pickle
try:
    c = pickle.load(open('$HOME/.hermes/secrets/youtube_token.pickle','rb'))
    print(f'valid={c.valid} refresh_token={\"있음\" if c.refresh_token else \"없음\"}')
except Exception as e:
    print(f'❌ 토큰 로드 실패: {e}')
" 2>&1 | grep -v -E "(FutureWarning|NotOpenSSLWarning|warnings\.warn)"

echo ""
echo "============================================"
echo "🎉 마이그레이션 완료!"
echo "============================================"
echo ""
echo "📋 다음 단계:"
echo "  1. Telegram/Discord 채널 재연결: hermes channels connect"
echo "  2. 16:00 NotebookLM 후보 크론 확인"
echo "  3. 'hermes status'로 전체 상태 점검"
echo ""