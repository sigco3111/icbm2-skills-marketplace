#!/bin/bash
# ==============================================================================
# Hermes 마이그레이션 검증 스크립트 (47개 항목 dry-run)
# ==============================================================================
#
# 사용법:
#   bash ~/Desktop/migration-verify.sh              # 전체 검증
#   bash ~/Desktop/migration-verify.sh --backup      # 백업 파일만 검증 (현재 PC)
#   bash ~/Desktop/migration-verify.sh --restore     # 복원 후 검증 (M4)
#   bash ~/Desktop/migration-verify.sh --preflight   # 사전 비행 점검 (현재 PC)
#
# 검증 7개 카테고리 / 47개 항목:
#   [1/7] 백업 파일 5종 (Desktop/에 있어야 함)
#   [2/7] Hermes 환경 (~/.hermes/ 핵심 파일 + 권한)
#   [3/7] 인증 (NotebookLM + YouTube + Telegram)
#   [4/7] venv (인터프리터 + 패키지 + Playwright)
#   [5/7] 시스템 (cron + 아키텍처 + Homebrew)
#   [6/7] 디렉토리 내용 (skills/cron/memory 등)
#   [7/7] 메모리 & 설정 sanity check
#
# 종료 코드:
#   0 = 모든 검증 통과 (마이그레이션 진행 가능)
#   1 = 1개 이상 FAIL (진행 금지)
#
# ⚠️ DATE_TAG는 백업 날짜와 일치해야 함 (기본: 20260625)
# ==============================================================================

set -uo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

PASS=0
FAIL=0
WARN=0
TOTAL=0

ok()   { PASS=$((PASS + 1)); TOTAL=$((TOTAL + 1)); echo -e "  ${GREEN}✅ PASS${NC}  $*"; }
ng()   { FAIL=$((FAIL + 1)); TOTAL=$((TOTAL + 1)); echo -e "  ${RED}❌ FAIL${NC}  $*"; }
warn() { WARN=$((WARN + 1)); TOTAL=$((TOTAL + 1)); echo -e "  ${YELLOW}⚠️  WARN${NC}  $*"; }
hdr()  { echo -e "\n${BLUE}━━━ $* ━━━${NC}"; }

MODE="${1:-full}"
DATE_TAG="${DATE_TAG:-20260625}"

# ------------------------------------------------------------------------------
# [1/7] 백업 파일 검증 (현재 PC에서)
# ------------------------------------------------------------------------------
check_backup_files() {
  hdr "[1/7] 백업 파일 검증 (Desktop/)"

  local files=(
    "hermes_migrate_${DATE_TAG}.tar.gz|true|true"
    "notebook_auth_${DATE_TAG}.tar.gz|true|true"
    "crontab_${DATE_TAG}.txt|true|false"
    "zshrc_backup.txt|false|false"
    "bash_profile_backup.txt|false|false"
  )

  for entry in "${files[@]}"; do
    IFS='|' read -r fname required is_tar <<< "$entry"
    local path="$HOME/Desktop/$fname"

    if [[ ! -f "$path" ]]; then
      if [[ "$required" == "true" ]]; then
        ng "필수 백업 없음: $fname"
      else
        warn "선택 백업 없음: $fname (선택사항)"
      fi
      continue
    fi

    local size=$(stat -f%z "$path")
    local size_mb=$((size / 1024 / 1024))
    ok "$fname 존재 ($size_mb MB)"

    if [[ "$is_tar" == "true" ]]; then
      if tar tzf "$path" >/dev/null 2>&1; then
        ok "  └ tar 무결성 OK"
      else
        ng "  └ tar 손상 (재압축 필요)"
      fi
      local count=$(tar tzf "$path" | wc -l | tr -d ' ')
      count=${count:-0}
      ok "  └ 항목 수: ${count}"
    fi
  done
}

# ------------------------------------------------------------------------------
# [2/7] Hermes 환경 검증
# ------------------------------------------------------------------------------
check_hermes_env() {
  hdr "[2/7] Hermes 환경 검증 (~/.hermes/)"

  local critical_files=(
    "config.yaml|10000"
    "MEMORY.md|2000"
    "SOUL.md|2000"
    "auth.json|3000"
    ".env|1000"
  )

  for entry in "${critical_files[@]}"; do
    IFS='|' read -r fname expected_min <<< "$entry"
    local path="$HOME/.hermes/$fname"

    if [[ ! -f "$path" ]]; then
      ng "필수 파일 없음: ~/.hermes/$fname"
      continue
    fi

    local size=$(stat -f%z "$path")
    if [[ $size -eq 0 ]]; then
      ng "$fname (0바이트 — 손상)"
    else
      ok "$fname ($size bytes)"
    fi
  done

  for dir in "secrets" "skills" "cron" "memory" "scripts"; do
    if [[ -d "$HOME/.hermes/$dir" ]]; then
      local count=$(find "$HOME/.hermes/$dir" -maxdepth 2 -type f | wc -l | tr -d ' ')
      count=${count:-0}
      ok "디렉토리: $dir/ ($count 파일)"
    else
      warn "디렉토리 없음: $dir/"
    fi
  done

  if [[ -d "$HOME/.hermes/secrets" ]]; then
    local perms=$(stat -f%p "$HOME/.hermes/secrets" | tail -c 4)
    if [[ "$perms" == "700" ]]; then
      ok "secrets/ 권한 700"
    else
      warn "secrets/ 권한 $perms (700 권장)"
    fi
  fi

  local sample_secret="$HOME/.hermes/secrets/youtube_token.pickle"
  if [[ -f "$sample_secret" ]]; then
    local perms=$(stat -f%Lp "$sample_secret")
    if [[ "$perms" == "rw-------" ]]; then
      ok "secrets/* 권한 600"
    else
      warn "secrets/* 권한 $perms (600 권장)"
    fi
  fi
}

# ------------------------------------------------------------------------------
# [3/7] 인증 검증
# ------------------------------------------------------------------------------
check_auth() {
  hdr "[3/7] 인증 검증"

  # 3-1) NotebookLM
  if [[ -f "$HOME/.hermes/venv-notebooklm/bin/python3" ]]; then
    if "$HOME/.hermes/venv-notebooklm/bin/python3" -m notebooklm list --json 2>&1 | head -3 | grep -q "notebooks"; then
      ok "NotebookLM 인증 OK"
    else
      ng "NotebookLM 인증 실패 (풀 OAuth 재로그인 필요)"
    fi
  else
    warn "venv-notebooklm 없음 (재생성 필요)"
  fi

  # 3-2) storage_state.json (여러 경로)
  for sf in "$HOME/.notebooklm/storage_state.json" \
            "$HOME/.notebooklm/profiles/default/storage_state.json"; do
    if [[ -f "$sf" && -s "$sf" ]]; then
      local size=$(stat -f%z "$sf")
      ok "storage_state.json 존재 ($size bytes) — $sf"
    elif [[ -f "$sf" ]]; then
      ng "storage_state.json 0바이트 — $sf"
    fi
  done

  # 3-3) YouTube 토큰 (refresh 시도 + 결과 표시)
  if [[ -f "$HOME/.hermes/secrets/youtube_token.pickle" ]]; then
    local valid=$(/usr/bin/python3 -c "
import pickle
try:
    c = pickle.load(open('$HOME/.hermes/secrets/youtube_token.pickle','rb'))
    print('valid' if c.valid else 'expired')
except Exception as e:
    print(f'error: {e}')
" 2>/dev/null)
    if [[ "$valid" == "valid" ]]; then
      ok "YouTube 토큰 valid"
    elif [[ "$valid" == "expired" ]]; then
      warn "YouTube 토큰 expired (refresh 시도 가능)"
    else
      ng "YouTube 토큰 오류: $valid"
    fi
  else
    ng "youtube_token.pickle 없음"
  fi

  # 3-4) Telegram 토큰
  if [[ -f "$HOME/.hermes/secrets/telegram_bot_token.txt" ]]; then
    local token=$(cat "$HOME/.hermes/secrets/telegram_bot_token.txt")
    if [[ "$token" == *"PLACEHOLDER"* ]] || [[ -z "$token" ]]; then
      warn "Telegram 토큰 placeholder/empty (정상 — fallback 모드)"
    else
      ok "Telegram 토큰 설정됨 (길이 ${#token})"
    fi
  else
    warn "telegram_bot_token.txt 없음"
  fi
}

# ------------------------------------------------------------------------------
# [4/7] venv 검증
# ------------------------------------------------------------------------------
check_venv() {
  hdr "[4/7] venv 검증"

  for pybin in "/opt/homebrew/bin/python3.12" \
               "/usr/local/bin/python3.12" \
               "/opt/homebrew/bin/python3.11" \
               "/usr/local/bin/python3.11" \
               "/usr/bin/python3"; do
    if [[ -x "$pybin" ]]; then
      ok "Python 발견: $pybin ($($pybin --version 2>&1))"
      break
    fi
  done

  if [[ -f "$HOME/.hermes/venv-notebooklm/bin/python3" ]]; then
    local py_version=$("$HOME/.hermes/venv-notebooklm/bin/python3" --version 2>&1)
    ok "venv-notebooklm 인터프리터 OK ($py_version)"

    if "$HOME/.hermes/venv-notebooklm/bin/python3" -c "import notebooklm" 2>/dev/null; then
      ok "  └ notebooklm-py 설치됨"
    else
      ng "  └ notebooklm-py 없음 (pip install 필요)"
    fi

    if "$HOME/.hermes/venv-notebooklm/bin/python3" -c "import googleapiclient" 2>/dev/null; then
      ok "  └ google-api-python-client 설치됨"
    else
      ng "  └ googleapiclient 없음"
    fi

    if [[ -d "$HOME/.hermes/venv-notebooklm/lib/python3."*"/site-packages/playwright" ]]; then
      ok "  └ playwright 설치됨"
    else
      warn "  └ playwright 없음 (playwright install chromium 필요)"
    fi
  else
    ng "venv-notebooklm/bin/python3 없음 (venv 재생성 필요)"
  fi

  for venv in "venv-notebooklm-enterprise" "venvs/whisper"; do
    if [[ -d "$HOME/.hermes/$venv" ]]; then
      ok "$venv 존재"
    else
      warn "$venv 없음 (선택사항)"
    fi
  done
}

# ------------------------------------------------------------------------------
# [5/7] 시스템 검증
# ------------------------------------------------------------------------------
check_system() {
  hdr "[5/7] 시스템 검증"

  if [[ "$OSTYPE" == "darwin"* ]]; then
    local macos_ver=$(sw_vers -productVersion 2>/dev/null)
    ok "macOS $macos_ver"
  else
    ng "macOS 아님 ($OSTYPE)"
  fi

  local arch=$(uname -m)
  if [[ "$arch" == "arm64" ]]; then
    ok "Apple Silicon ($arch)"
  else
    warn "Intel ($arch) — 호환성 확인 필요"
  fi

  if command -v brew &>/dev/null; then
    ok "Homebrew 설치됨 ($(brew --version | head -1))"
  else
    warn "Homebrew 없음 (설치 권장)"
  fi

  local job_count=$(crontab -l 2>/dev/null | grep -v '^#' | grep -v '^$' | wc -l | tr -d ' ')
  job_count=${job_count:-0}
  if [[ $job_count -gt 0 ]]; then
    ok "cron 활성 잡: ${job_count}개"
  else
    warn "cron 잡 없음 (crontab 복원 필요)"
  fi

  local free_gb=$(df -g ~ | awk 'NR==2 {print $4}')
  if [[ $free_gb -gt 10 ]]; then
    ok "디스크 여유: ${free_gb}GB"
  elif [[ $free_gb -gt 5 ]]; then
    warn "디스크 여유: ${free_gb}GB (10GB 이상 권장)"
  else
    ng "디스크 여유: ${free_gb}GB (5GB 이상 필요)"
  fi

  if command -v hermes &>/dev/null; then
    ok "hermes 명령어 사용 가능"
  else
    warn "hermes 명령어 없음 (pip install hermes-agent)"
  fi
}

# ------------------------------------------------------------------------------
# [6/7] 디렉토리 내용 검증 (M4 복원 후)
# ------------------------------------------------------------------------------
check_directories() {
  hdr "[6/7] 디렉토리 내용 검증"

  local checks=(
    "skills|1000"
    "cron|300"
    "memory|200"
    "data|40"
    "checkpoints|200"
  )

  for entry in "${checks[@]}"; do
    IFS='|' read -r dir expected_min <<< "$entry"
    local path="$HOME/.hermes/$dir"

    if [[ -d "$path" ]]; then
      local count=$(find "$path" -maxdepth 5 -type f 2>/dev/null | wc -l | tr -d ' ')
      count=${count:-0}
      if [[ $count -gt $expected_min ]]; then
        ok "$dir/: $count 파일"
      else
        warn "$dir/: $count 파일 (예상 ${expected_min}+, 백업 누락 가능)"
      fi
    else
      ng "$dir/ 없음"
    fi
  done
}

# ------------------------------------------------------------------------------
# [7/7] 메모리 & 설정 sanity check
# ------------------------------------------------------------------------------
check_memory() {
  hdr "[7/7] 메모리 & 설정 sanity check"

  if [[ -f "$HOME/.hermes/MEMORY.md" ]]; then
    local lines=$(wc -l < "$HOME/.hermes/MEMORY.md" | tr -d ' ')
    if [[ $lines -gt 5 ]]; then
      ok "MEMORY.md 내용 있음 ($lines 줄)"
    else
      warn "MEMORY.md 너무 짧음 ($lines 줄)"
    fi
  fi

  if [[ -f "$HOME/.hermes/config.yaml" ]]; then
    local provider_count=$(grep -c "^  - name:" "$HOME/.hermes/config.yaml" 2>/dev/null || true)
    provider_count=${provider_count:-0}
    if [[ $provider_count -gt 0 ]]; then
      ok "config.yaml providers: $provider_count"
    else
      warn "config.yaml providers 없음"
    fi

    if grep -q "fallback_providers" "$HOME/.hermes/config.yaml" 2>/dev/null; then
      ok "fallback_providers 설정됨"
    else
      warn "fallback_providers 없음 (단일 provider만 의존)"
    fi
  fi

  if [[ -f "$HOME/.hermes/USER.md" ]]; then
    ok "USER.md 존재"
  else
    warn "USER.md 없음 (선택)"
  fi
}

# ------------------------------------------------------------------------------
# 메인
# ------------------------------------------------------------------------------
case "$MODE" in
  --backup)    check_backup_files ;;
  --preflight) check_hermes_env; check_auth; check_system ;;
  --restore)   check_hermes_env; check_auth; check_venv; check_directories; check_memory; check_system ;;
  full|*)
    check_backup_files
    check_hermes_env
    check_auth
    check_venv
    check_directories
    check_memory
    check_system
    ;;
esac

echo ""
echo "================================================================"
echo -e "${BLUE}📊 검증 결과 요약${NC}"
echo "================================================================"
echo -e "  ${GREEN}✅ PASS${NC}: $PASS"
echo -e "  ${YELLOW}⚠️  WARN${NC}: $WARN"
echo -e "  ${RED}❌ FAIL${NC}: $FAIL"
echo -e "  📋 TOTAL: $TOTAL"
echo ""

if [[ ${FAIL:-0} -eq 0 ]]; then
  if [[ ${WARN:-0} -eq 0 ]]; then
    echo -e "${GREEN}🎉 모든 검증 통과! 마이그레이션 진행 가능합니다.${NC}"
    EXIT_CODE=0
  else
    echo -e "${YELLOW}⚠️ 경고 ${WARN}개 — 진행 가능하지만 위 항목 확인 권장${NC}"
    EXIT_CODE=0
  fi
else
  echo -e "${RED}❌ 실패 ${FAIL}개 — 위 항목 반드시 해결 후 진행${NC}"
  EXIT_CODE=1
fi
echo "================================================================"

exit $EXIT_CODE