#!/bin/bash
# M4 맥미니 / 신규 PC 마이그레이션 사전 점검 + 백업 검증 스크립트
# 사용법: bash migration-pre-check.sh [verify]
#   인자 없음 → 점검 + 백업 생성
#   verify → 백업 파일 무결성 검증만

set -e

DATE=$(date +%Y%m%d)
DESKTOP="$HOME/Desktop"

if [ "$1" = "verify" ]; then
    echo "============================================"
    echo "🔍 백업 파일 무결성 검증"
    echo "============================================"
    echo ""

    # 백업 파일 존재 + 크기 확인
    for f in "hermes_migrate_${DATE}.tar.gz" "notebook_auth_${DATE}.tar.gz" "crontab_${DATE}.txt" \
             "zshrc_backup.txt" "bash_profile_backup.txt"; do
        if [ -f "${DESKTOP}/${f}" ]; then
            size=$(du -h "${DESKTOP}/${f}" | cut -f1)
            echo "✅ ${f} (${size})"
        else
            echo "❌ ${f} 없음"
        fi
    done

    echo ""
    echo "📦 Hermes 백업 내용 검증:"
    tar tzf "${DESKTOP}/hermes_migrate_${DATE}.tar.gz" 2>/dev/null | \
        awk -F'/' '{print $4}' | sort | uniq -c | sort -rn | head -10

    echo ""
    echo "총 파일 수: $(tar tzf "${DESKTOP}/hermes_migrate_${DATE}.tar.gz" | wc -l)"
    exit 0
fi

echo "============================================"
echo "🔍 Phase 0: 사전 점검"
echo "============================================"
echo ""

# 0-1) 시스템 cron
echo "=== 0-1) 시스템 cron ==="
crontab -l 2>&1 | head -10
echo ""

# 0-2) Hermes 크기
echo "=== 0-2) Hermes 크기 ==="
du -sh "$HOME/.hermes/" 2>/dev/null
echo ""

# 0-3) 핵심 파일 인벤토리
echo "=== 0-3) 핵심 설정 파일 ==="
for f in config.yaml MEMORY.md SOUL.md USER.md auth.json .env; do
    if [ -f "$HOME/.hermes/$f" ]; then
        echo "  ✅ $f ($(du -h "$HOME/.hermes/$f" | cut -f1))"
    else
        echo "  ⚠️  $f 없음"
    fi
done
echo ""

# 0-4) venv
echo "=== 0-4) venv (재생성 대상) ==="
for d in "$HOME/.hermes/venv-notebooklm" "$HOME/.hermes/venv-notebooklm-enterprise" "$HOME/.hermes/venvs"; do
    if [ -d "$d" ]; then
        echo "  $(du -sh "$d" | cut -f1) $d"
    fi
done
echo ""

# 0-5) NotebookLM 인증
echo "=== 0-5) NotebookLM 인증 ==="
find "$HOME/.notebooklm/" -maxdepth 4 -name "storage_state*" -ls 2>/dev/null | head -5
echo ""

# 0-6) 시크릿
echo "=== 0-6) API 시크릿 ==="
ls -la "$HOME/.hermes/secrets/" 2>/dev/null | tail -n +2 | wc -l | xargs -I{} echo "  시크릿 파일: {}개"
echo ""

# Phase 1: 백업
echo "============================================"
echo "📦 Phase 1: 백업 생성"
echo "============================================"
echo ""
read -p "백업을 진행할까요? (y/n) " -n 1 -r
echo ""
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "⏭️  백업 스킵. 'bash migration-pre-check.sh verify'로 나중에 검증 가능."
    exit 0
fi

echo ""
echo "⏱️  Hermes 압축 중... (예상 2\~3분)"
tar czf "${DESKTOP}/hermes_migrate_${DATE}.tar.gz" \
  --exclude='venv-notebooklm' \
  --exclude='venv-notebooklm-enterprise' \
  --exclude='venvs' \
  --exclude='node_modules' \
  --exclude='sessions' \
  --exclude='state-snapshots' \
  --exclude='cache' \
  --exclude='logs' \
  --exclude='audio_cache' \
  --exclude='.DS_Store' \
  --exclude='__pycache__' \
  --exclude='*.pyc' \
  --exclude='*.wasm' \
  --exclude='*.map' \
  --exclude='.pytest_cache' \
  --exclude='hermes-agent/venv' \
  --exclude='hermes-agent/.venv' \
  --exclude='hermes-agent/node_modules' \
  --exclude='hermes-agent/build' \
  --exclude='hermes-agent/dist' \
  --exclude='hermes-agent/.next' \
  --exclude='hermes-agent/.turbo' \
  --exclude='hermes-agent/coverage' \
  --exclude='hermes-agent/.git' \
  --exclude='hermes-agent/**/.git' \
  --exclude='notebooklm_env' \
  --exclude='lsp/node_modules' \
  --exclude='state.db' \
  --exclude='state.db-wal' \
  --exclude='state.db-shm' \
  "$HOME/.hermes/"

echo ""
echo "✅ Hermes 압축 완료: $(du -h "${DESKTOP}/hermes_migrate_${DATE}.tar.gz" | cut -f1)"

echo ""
echo "⏱️  NotebookLM 인증 백업..."
tar czf "${DESKTOP}/notebook_auth_${DATE}.tar.gz" \
  "$HOME/.notebooklm/profiles/default/storage_state.json" \
  "$HOME/.notebooklm/storage_state.json.bak.personal" \
  "$HOME/.notebooklm/storage_state.json.personal_backup" 2>/dev/null || \
  echo "⚠️  일부 백업 파일 없음 (스킵)"

echo ""
echo "⏱️  시스템 crontab + 쉘 환경 백업..."
crontab -l > "${DESKTOP}/crontab_${DATE}.txt"
cp "$HOME/.zshrc" "${DESKTOP}/zshrc_backup.txt" 2>/dev/null || echo "  ⚠️  zshrc 없음"
cp "$HOME/.bash_profile" "${DESKTOP}/bash_profile_backup.txt" 2>/dev/null || echo "  ⚠️  bash_profile 없음"
[ -d "$HOME/.ssh" ] && cp -r "$HOME/.ssh" "${DESKTOP}/ssh_backup_${DATE}/" 2>/dev/null

echo ""
echo "============================================"
echo "✅ 백업 완료! 다음 단계:"
echo "============================================"
echo ""
echo "📦 ~/Desktop/ 의 백업 파일 5종:"
ls -lh "${DESKTOP}/hermes_migrate_${DATE}.tar.gz" \
       "${DESKTOP}/notebook_auth_${DATE}.tar.gz" \
       "${DESKTOP}/crontab_${DATE}.txt" \
       "${DESKTOP}/zshrc_backup.txt" \
       "${DESKTOP}/bash_profile_backup.txt" 2>/dev/null
echo ""
echo "🚚 전송 방법:"
echo "  - AirDrop (가장 빠름, 214MB도 몇 초)"
echo "  - 외장 SSD"
echo "  - iCloud Drive / Google Drive"
echo ""
echo "🆕 M4 맥미니에서 실행:"
echo "  bash migration-pre-check.sh verify"
echo ""