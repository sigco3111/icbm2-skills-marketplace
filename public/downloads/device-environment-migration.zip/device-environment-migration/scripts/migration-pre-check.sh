#!/bin/bash
# M4 맥미니 / 신규 PC 마이그레이션 사전 점검 + 백업 검증 스크립트
# 사용법: bash migration-pre-check.sh [verify]
#   인자 없음 → 점검 + 백업 생성
#   verify → 백업 파일 무결성 검증만

set -e

DATE=$(date +%Y%m%d)
DESKTOP="$HOME/Desktop"

if [ "$1" = "verify" ]; then
    echo "============================================"
    echo "🔍 백업 파일 무결성 검증"
    echo "============================================"
    echo ""

    # 공식 backup 확인 (P15)
    if [ -f "${DESKTOP}/hermes_official_${DATE}.zip" ]; then
        size=$(du -h "${DESKTOP}/hermes_official_${DATE}.zip" | cut -f1)
        echo "✅ hermes_official_${DATE}.zip (공식 backup, ${size})"
        echo "   → M4에서: hermes import ${DESKTOP}/hermes_official_${DATE}.zip"
    fi

    # 수동 backup 파일 확인
    for f in "hermes_migrate_${DATE}.tar.gz" "notebook_auth_${DATE}.tar.gz" "crontab_${DATE}.txt" \
             "zshrc_backup.txt" "bash_profile_backup.txt"; do
        if [ -f "${DESKTOP}/${f}" ]; then
            size=$(du -h "${DESKTOP}/${f}" | cut -f1)
            echo "✅ ${f} (${size})"
        else
            echo "❌ ${f} 없음"
        fi
    done

    echo ""
    # 공식 backup 내용 검증
    if [ -f "${DESKTOP}/hermes_official_${DATE}.zip" ]; then
        echo "📦 공식 backup 내용 검증:"
        unzip -l "${DESKTOP}/hermes_official_${DATE}.zip" 2>/dev/null | \
            awk 'NR>3 && $NF !~ /^---/ && $NF != "" {print $NF}' | \
            awk -F'/' '{print $2}' | sort | uniq -c | sort -rn | head -10
        echo ""
        echo "공식 backup 파일 수: $(unzip -l "${DESKTOP}/hermes_official_${DATE}.zip" 2>/dev/null | tail -1 | awk '{print $2}')"
    fi

    # 수동 backup이 있으면 그것도 검증
    if [ -f "${DESKTOP}/hermes_migrate_${DATE}.tar.gz" ]; then
        echo ""
        echo "📦 수동 backup 내용 검증:"
        tar tzf "${DESKTOP}/hermes_migrate_${DATE}.tar.gz" 2>/dev/null | \
            awk -F'/' '{print $4}' | sort | uniq -c | sort -rn | head -10
        echo ""
        echo "수동 backup 파일 수: $(tar tzf "${DESKTOP}/hermes_migrate_${DATE}.tar.gz" | wc -l)"
    fi
    exit 0
fi

echo "============================================"
echo "🔍 Phase 0: 사전 점검"
echo "============================================"
echo ""

# 0-0) ⚠️ P15 예방: 공식 hermes backup 우선 확인
echo "=== 0-0) 공식 백업 명령 우선 확인 (P15 예방) ==="
if command -v hermes &>/dev/null; then
    if hermes backup --help &>/dev/null; then
        echo "  ✅ 공식 'hermes backup' 발견 — SQLite 안전 백업, hermes-agent 자동 제외"
        echo "  📌 권장: 'hermes backup --output ${DESKTOP}/hermes_official_${DATE}.zip'"
        echo ""
        read -p "  공식 backup으로 진행할까요? (y/n, n이면 수동 tar 방식) " -n 1 -r
        echo ""
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            echo "⏱️  공식 backup 실행 중... (state.db 포함, 5~10분)"
            hermes backup --output "${DESKTOP}/hermes_official_${DATE}.zip"
            echo "✅ 공식 backup 완료: $(du -h "${DESKTOP}/hermes_official_${DATE}.zip" 2>/dev/null | cut -f1)"
            echo ""
            echo "→ 시스템 레벨 백업(crontab/zshrc/notebooklm)만 별도 진행합니다."
            # 시스템 레벨만 백업하는 헬퍼로 점프
            system_only_backup=true
        else
            echo "  → 수동 tar 방식으로 진행"
            system_only_backup=false
        fi
    else
        echo "  ⚠️  hermes CLI 설치되어 있으나 backup 명령 없음 (구버전?)"
        system_only_backup=false
    fi
else
    echo "  ⚠️  hermes CLI 없음 — 수동 tar 방식만 가능"
    system_only_backup=false
fi
echo ""

# 0-1) 시스템 cron
echo "=== 0-1) 시스템 cron ==="
crontab -l 2>&1 | head -10
echo ""

# 0-2) Hermes 크기
echo "=== 0-2) Hermes 크기 ==="
du -sh "$HOME/.hermes/" 2>/dev/null
echo ""

# 0-3) 핵심 파일 인벤토리
echo "=== 0-3) 핵심 설정 파일 ==="
for f in config.yaml MEMORY.md SOUL.md USER.md auth.json .env; do
    if [ -f "$HOME/.hermes/$f" ]; then
        echo "  ✅ $f ($(du -h "$HOME/.hermes/$f" | cut -f1))"
    else
        echo "  ⚠️  $f 없음"
    fi
done
echo ""

# 0-4) venv
echo "=== 0-4) venv (재생성 대상) ==="
for d in "$HOME/.hermes/venv-notebooklm" "$HOME/.hermes/venv-notebooklm-enterprise" "$HOME/.hermes/venvs"; do
    if [ -d "$d" ]; then
        echo "  $(du -sh "$d" | cut -f1) $d"
    fi
done
echo ""

# 0-5) NotebookLM 인증
echo "=== 0-5) NotebookLM 인증 ==="
find "$HOME/.notebooklm/" -maxdepth 4 -name "storage_state*" -ls 2>/dev/null | head -5
echo ""

# 0-6) 시크릿
echo "=== 0-6) API 시크릿 ==="
ls -la "$HOME/.hermes/secrets/" 2>/dev/null | tail -n +2 | wc -l | xargs -I{} echo "  시크릿 파일: {}개"
echo ""

# Phase 1: 백업
echo "============================================"
echo "📦 Phase 1: 백업 생성"
echo "============================================"
echo ""
read -p "백업을 진행할까요? (y/n) " -n 1 -r
echo ""
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "⏭️  백업 스킵. 'bash migration-pre-check.sh verify'로 나중에 검증 가능."
    exit 0
fi

echo ""
echo "⏱️  Hermes 압축 중... (예상 2\~3분)"
if [ "$system_only_backup" = "true" ]; then
    # 공식 backup이 이미 완료됨 — 수동 tar 압축 스킵
    echo "  ↪️ 공식 backup 완료됨 (${DESKTOP}/hermes_official_${DATE}.zip)"
    echo "  ↪️ 수동 tar 압축 스킵, 시스템 레벨 백업만 진행"
else
    # 수동 tar 압축
    tar czf "${DESKTOP}/hermes_migrate_${DATE}.tar.gz" \
      --exclude='venv-notebooklm' \
      --exclude='venv-notebooklm-enterprise' \
      --exclude='venvs' \
      --exclude='node_modules' \
      --exclude='sessions' \
      --exclude='state-snapshots' \
      --exclude='cache' \
      --exclude='logs' \
      --exclude='audio_cache' \
      --exclude='.DS_Store' \
      --exclude='__pycache__' \
      --exclude='*.pyc' \
      --exclude='*.wasm' \
      --exclude='*.map' \
      --exclude='.pytest_cache' \
      --exclude='hermes-agent/venv' \
      --exclude='hermes-agent/.venv' \
      --exclude='hermes-agent/node_modules' \
      --exclude='hermes-agent/build' \
      --exclude='hermes-agent/dist' \
      --exclude='hermes-agent/.next' \
      --exclude='hermes-agent/.turbo' \
      --exclude='hermes-agent/coverage' \
      --exclude='hermes-agent/.git' \
      --exclude='hermes-agent/**/.git' \
      --exclude='notebooklm_env' \
      --exclude='lsp/node_modules' \
      --exclude='state.db' \
      --exclude='state.db-wal' \
      --exclude='state.db-shm' \
      "$HOME/.hermes/"

    echo ""
    echo "✅ Hermes 압축 완료: $(du -h "${DESKTOP}/hermes_migrate_${DATE}.tar.gz" | cut -f1)"
fi

echo ""
echo "✅ Hermes 압축 완료: $(du -h "${DESKTOP}/hermes_migrate_${DATE}.tar.gz" | cut -f1)"

echo ""
echo "⏱️  NotebookLM 인증 백업..."
tar czf "${DESKTOP}/notebook_auth_${DATE}.tar.gz" \
  "$HOME/.notebooklm/profiles/default/storage_state.json" \
  "$HOME/.notebooklm/storage_state.json.bak.personal" \
  "$HOME/.notebooklm/storage_state.json.personal_backup" 2>/dev/null || \
  echo "⚠️  일부 백업 파일 없음 (스킵)"

echo ""
echo "⏱️  시스템 crontab + 쉘 환경 백업..."
crontab -l > "${DESKTOP}/crontab_${DATE}.txt"
cp "$HOME/.zshrc" "${DESKTOP}/zshrc_backup.txt" 2>/dev/null || echo "  ⚠️  zshrc 없음"
cp "$HOME/.bash_profile" "${DESKTOP}/bash_profile_backup.txt" 2>/dev/null || echo "  ⚠️  bash_profile 없음"
[ -d "$HOME/.ssh" ] && cp -r "$HOME/.ssh" "${DESKTOP}/ssh_backup_${DATE}/" 2>/dev/null

echo ""
echo "============================================"
echo "✅ 백업 완료! 다음 단계:"
echo "============================================"
echo ""
if [ "$system_only_backup" = "true" ]; then
    echo "📦 ~/Desktop/ 의 백업 파일 2종 (이중 안전망):"
    ls -lh "${DESKTOP}/hermes_official_${DATE}.zip" \
           "${DESKTOP}/notebook_auth_${DATE}.tar.gz" \
           "${DESKTOP}/crontab_${DATE}.txt" \
           "${DESKTOP}/zshrc_backup.txt" \
           "${DESKTOP}/bash_profile_backup.txt" 2>/dev/null
    echo ""
    echo "🚚 전송 방법:"
    echo "  - AirDrop (가장 빠름)"
    echo "  - 외장 SSD"
    echo "  - iCloud Drive / Google Drive"
    echo ""
    echo "🆕 M4 맥미니에서 실행 (공식 backup 우선):"
    echo "  hermes import ~/Desktop/hermes_official_${DATE}.zip   # Hermes 복원"
    echo "  crontab ~/Desktop/crontab_${DATE}.txt                # 시스템 cron"
    echo "  cp ~/Desktop/zshrc_backup.txt ~/.zshrc               # zsh 환경"
    echo "  cp ~/Desktop/bash_profile_backup.txt ~/.bash_profile # bash_profile"
    echo ""
    echo "  # 시스템 레벨 backup 위치 자동 탐지:"
    echo "  bash ~/Desktop/migration-pre-check.sh verify"
else
    echo "📦 ~/Desktop/ 의 백업 파일 5종:"
    ls -lh "${DESKTOP}/hermes_migrate_${DATE}.tar.gz" \
           "${DESKTOP}/notebook_auth_${DATE}.tar.gz" \
           "${DESKTOP}/crontab_${DATE}.txt" \
           "${DESKTOP}/zshrc_backup.txt" \
           "${DESKTOP}/bash_profile_backup.txt" 2>/dev/null
    echo ""
    echo "🚚 전송 방법:"
    echo "  - AirDrop (가장 빠름, 214MB도 몇 초)"
    echo "  - 외장 SSD"
    echo "  - iCloud Drive / Google Drive"
    echo ""
    echo "🆕 M4 맥미니에서 실행:"
    echo "  bash migration-pre-check.sh verify"
fi
echo ""