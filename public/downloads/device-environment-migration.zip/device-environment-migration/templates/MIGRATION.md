# 🚚 {TARGET_DEVICE} 이전 체크리스트

> {SOURCE_OS} → {TARGET_DEVICE}, **{SYSTEM_NAME} 이전 가이드**
> 작성: {YYYY-MM-DD} | 백업 날짜: {YYYY-MM-DD}

---

## 📦 1단계: 백업 파일 준비 ({SOURCE_OS} — ✅ 완료)

### 📁 `~/Desktop/MIGRATION_FOLDER/` 폴더에서 {TARGET_DEVICE}로 전송할 파일 {N}종

> **모든 파일이 한 폴더에 정리되어 있습니다.**
> **위치:** `~/Desktop/MIGRATION_FOLDER/`
> **폴더 크기:** ~{SIZE} MB

| # | 파일 | 크기 | 용도 |
|---|---|---:|---|
| 1 | `{main_backup}.tar.gz` | {SIZE} | 메인 백업 |
| 2 | `{auth_backup}.tar.gz` | {SIZE} | 인증 백업 |
| 3 | `{config_backup}.txt` | {SIZE} | 시스템 설정 |
| 4 | `{shell_env_backup}.txt` | {SIZE} | 셸 환경 |
| 5 | `{restore_script}.sh` | {SIZE} | 자동 복원 스크립트 |
| 6 | `{verify_script}.sh` | {SIZE} | 검증 스크립트 |
| 7 | `MIGRATION.md` | {SIZE} | 이 문서 (가이드) |

**총합: ~{TOTAL} MB**

### 📂 {TARGET_DEVICE}에서의 권장 위치

**{TARGET_DEVICE}에서는 같은 폴더 구조를 유지하세요:**

```bash
# {TARGET_DEVICE}에서
mkdir -p ~/Desktop/MIGRATION_FOLDER
# AirDrop으로 받은 파일을 이 폴더에 모두 넣기
```

스크립트는 자동으로 `~/Desktop/MIGRATION_FOLDER/` 경로를 찾아 동작합니다.
다른 위치에 두려면 `MIGRATION_DIR` 환경변수로 변경 가능:

```bash
MIGRATION_DIR=~/Downloads/Migration bash ~/Desktop/MIGRATION_FOLDER/{restore_script}.sh
```

### 전송 방법 (택 1)

| 방법 | 소요 시간 | 비고 |
|---|---|---|
| **AirDrop (폴더째)** | {TIME} | 가장 빠름, 무선 — Finder에서 폴더째 AirDrop 가능 |
| **외장 SSD** | {TIME} | 가장 안전 |
| **iCloud Drive** | {TIME} | 무선이지만 느림 |
| **ZIP 압축 후 1개** | +30초 | `cd ~/Desktop && zip -r {backup_name}.zip MIGRATION_FOLDER/` |

---

## 🛠 2단계: {TARGET_DEVICE} 신규 셋업 ({TIME})

### 2-1) {TARGET_OS} 초기 설정 ({TIME})

| # | 작업 | 비고 |
|---|---|---|
| 2-1-1 | {TARGET_OS} 초기 설정 마법사 | 언어, Wi-Fi, Apple ID |
| 2-1-2 | **사용자 계정명을 `{USERNAME}`으로 동일하게** | ⚠️ 매우 중요 — 다른 이름이면 모든 cron 잡이 깨짐 |
| 2-1-3 | Siri, 분석 데이터 OFF | 선택 |
| 2-1-4 | 펌웨어 업데이트 | 재시작 필요할 수 있음 |

### 2-2) Homebrew 설치 ({TIME})

```bash
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Apple Silicon 경로 추가 (zsh 기본)
echo 'eval "$(/opt/homebrew/bin/brew shellenv)"' >> ~/.zprofile
eval "$(/opt/homebrew/bin/brew shellenv)"
```

### 2-3) 필수 도구 설치 ({TIME})

```bash
# Xcode CLT (대화형, 5분)
xcode-select --install

# Python 3.12 (메인 Python)
brew install python@3.12
which python3.12   # /opt/homebrew/bin/python3.12 확인

# Node.js
brew install node@22

# Git, jq, tree, htop, ffmpeg (유틸)
brew install git jq tree htop ffmpeg

# Rosetta 2 (Intel 패키지 필요시 — 옵션)
softwareupdate --install-rosetta --agree-to-license
```

### 2-4) 디렉토리 구조 준비 ({TIME})

⚠️ **cron 잡이 다음 경로를 하드코딩 참조**합니다. 동일하게 만들어야 함:

```bash
# 시스템 홈 디렉토리
mkdir -p ~/.hermes/secrets
mkdir -p ~/.notebooklm/profiles/default

# cron 잡이 참조하는 디렉토리 (필요한 것만)
mkdir -p /Users/{USERNAME}/CLAWD/scripts
mkdir -p /Users/{USERNAME}/.openclaw/workspace/scripts
mkdir -p /Users/{USERNAME}/.openclaw/workspace/logs

# 권한
chmod 700 ~/.hermes/secrets
```

### 2-5) 백업 파일 가져오기 ({TIME})

AirDrop/SSD/클라우드에서 `MIGRATION_FOLDER/` 폴더째 `~/Desktop/` 에 복사

```bash
ls -la ~/Desktop/MIGRATION_FOLDER/
# {N}개 파일/폴더가 모두 보여야 정상
```

---

## 🚀 3단계: 시스템 복원 (자동, {TIME})

### 옵션 A: 자동 스크립트 (권장)

```bash
bash ~/Desktop/MIGRATION_FOLDER/{restore_script}.sh
```

스크립트가 자동으로 7단계 모두 수행:
1. 사전 확인 (macOS, 아키텍처, 디스크)
2. 압축 해제 (메인 + 인증 백업)
3. 권한 정리 (700/600)
4. crontab 복원
5. 셸 환경 복원
6. venv 재생성 + 패키지 설치
7. 최종 검증 + 리포트

### 옵션 B: 수동 (스크립트 안 돌릴 때)

스크립트가 실패하면 아래 명령을 순서대로:

```bash
# 3-1) 압축 해제
cd ~
tar xzf ~/Desktop/MIGRATION_FOLDER/{main_backup}.tar.gz
tar xzf ~/Desktop/MIGRATION_FOLDER/{auth_backup}.tar.gz

# 3-2) 권한 정리
chown -R "$(whoami):staff" ~/.hermes/ ~/.notebooklm/
chmod 700 ~/.hermes/secrets/
chmod 600 ~/.hermes/secrets/* ~/.notebooklm/storage_state.json*

# 3-3) crontab 복원
crontab ~/Desktop/MIGRATION_FOLDER/{config_backup}.txt

# 3-4) 셸 환경 복원
cp ~/Desktop/MIGRATION_FOLDER/{shell_env_backup}.txt ~/.zshrc
cp ~/Desktop/MIGRATION_FOLDER/{shell_env_backup2}.txt ~/.bash_profile

# 3-5) venv 재생성
for venv in {venv_list}; do
  rm -rf ~/.hermes/$venv
  python3.12 -m venv ~/.hermes/$venv
done

# 3-6) 패키지 설치
source ~/.hermes/{main_venv}/bin/activate
pip install --upgrade pip
pip install "{main_package}[browser]"
{pip_extra_packages}
playwright install chromium
deactivate
```

---

## ✅ 4단계: 검증 ({TIME})

```bash
# 전체 검증 ({N}개 항목)
bash ~/Desktop/MIGRATION_FOLDER/{verify_script}.sh

# 또는 부분 검증
bash ~/Desktop/MIGRATION_FOLDER/{verify_script}.sh --preflight   # 시스템/인증만
bash ~/Desktop/MIGRATION_FOLDER/{verify_script}.sh --backup      # 백업 파일만
bash ~/Desktop/MIGRATION_FOLDER/{verify_script}.sh --restore     # 복원 후 디렉토리 검증
```

### 통과 기준

| 항목 | 통과 |
|---|---|
| PASS | 35+ |
| WARN | 0\~15 (대부분 무시 가능) |
| **FAIL** | **반드시 0** |

FAIL이 1개 이상이면 마이그레이션 완료 아님 — 출력 로그 확인 후 해결.

---

## 🔌 5단계: 채널 재연결 ({TIME})

`{cli_command}` 명령어로 채널 인증 새로 받기:

```bash
# 상태 확인
{cli_command} status

# 채널 목록 확인
{cli_command} channels list

# 각 채널 재연결 (필요한 것만)
{cli_command} channels connect telegram
{cli_command} channels connect discord
{cli_command} channels connect homeassistant
```

브라우저가 열리면 OAuth 로그인. Telegram은 bot token 재입력 필요할 수 있음.

---

## 🧪 6단계: End-to-End 테스트 ({TIME})

### 6-1) 기본 대화 테스트

Telegram/Discord에서 시스템한테 **아무 메시지나** 보내보기:

```
/ping
```

또는:

```
안녕, 잘 도착했어?
```

→ 응답이 와야 성공. 안 오면 `~/.hermes/logs/` 확인.

### 6-2) 노트북 워크플로우 테스트 (선택)

```bash
# NotebookLM 인증 확인
~/.hermes/{main_venv}/bin/python3 -m notebooklm list --json | head -3

# YouTube 토큰 확인
/usr/bin/python3 -c "
import pickle
c = pickle.load(open('/Users/{USERNAME}/.hermes/secrets/youtube_token.pickle','rb'))
print(f'valid={c.valid}')
"
```

### 6-3) 크론 잡 테스트

```bash
# 활성 잡 확인
crontab -l

# 1개만 즉시 실행 테스트 (선택)
# 예: system-monitor.py를 수동 실행
cd /Users/{USERNAME}/CLAWD/scripts && python3 system-monitor.py
```

### 6-4) 메모리 검색 테스트

Telegram에서:

```
memory에서 "Jalapeño" 검색해줘
```

또는:

```
내가 6월에 했던 작업 중에 NotebookLM 관련 찾아줘
```

→ `session_search` 또는 `MEMORY.md`/`memory/` 검색 결과.

---

## 🐛 7단계: 문제 해결 (Troubleshooting)

### 문제 1: 인증 실패

```
❌ 인증 실패 (풀 OAuth 재로그인 필요)
```

**해결:**
```bash
{cli_command} login
# → 브라우저에서 계정으로 로그인
# → SID 도메인이 .google.com 인지 확인 (.google.co.kr이면 Workspace 계정 → 인증 불가)
```

### 문제 2: 토큰 invalid

```
⚠️ 토큰 expired (refresh 필요)
```

**해결:**
```bash
/usr/bin/python3 -c "
import pickle, os
from google.auth.transport.requests import Request
p = os.path.expanduser('~/.hermes/secrets/{token_file}')
c = pickle.load(open(p,'rb'))
try:
    c.refresh(Request())
    pickle.dump(c, open(p,'wb'))
    print('✅ refresh 성공')
except Exception as e:
    print(f'❌ refresh 실패 → 풀 OAuth 필요: {e}')
"
```

refresh 실패 시 풀 OAuth.

### 문제 3: venv 인터프리터 깨짐

```
❌ venv/bin/python3 없음
```

**원인:** Homebrew에서 python formula 제거됨.

**해결:**
```bash
ls /opt/homebrew/opt/ | grep python
# 남은 버전 (예: 3.12)으로 재생성
PYTHON_BIN=/opt/homebrew/opt/python@3.12/bin/python3.12
$PYTHON_BIN -m venv --clear ~/.hermes/{main_venv}
~/.hermes/{main_venv}/bin/pip install --upgrade pip
~/.hermes/{main_venv}/bin/pip install "{main_package}[browser]"
# ... 추가 패키지 재설치
~/.hermes/{main_venv}/bin/playwright install chromium
```

### 문제 4: cron 잡이 실행 안 됨

```bash
# cron 데몬 상태 확인
sudo launchctl list | grep cron

# 로그 확인
log show --predicate 'process == "cron"' --last 1h
```

### 문제 5: 봇 무응답

```bash
# 1) 시스템 상태
{cli_command} status

# 2) 채널 상태
{cli_command} channels list

# 3) 로그
tail -100 ~/.hermes/logs/*.log | grep -i "telegram\|discord"

# 4) 채널 재연결
{cli_command} channels disconnect telegram
{cli_command} channels connect telegram
```

### 문제 6: 아키텍처 호환 안 됨

`venv/` 등이 Intel wheel을 가져왔다면:

```bash
# Intel venv는 무조건 새로 만들어야 함 (M4 wheel과 호환 안 됨)
rm -rf ~/.hermes/{main_venv}
/opt/homebrew/bin/python3.12 -m venv ~/.hermes/{main_venv}
# ... 패키지 재설치
```

---

## 📊 마이그레이션 완료 체크리스트

```
□ 1단계: 백업 파일 {N}개 {TARGET_DEVICE}로 전송 완료
□ 2단계: {TARGET_OS} 초기 설정 + Homebrew + Python 3.12
□ 3단계: {restore_script}.sh 실행 (또는 수동 6단계)
□ 4단계: {verify_script}.sh — FAIL 0개 확인
□ 5단계: 시스템 채널 재연결
□ 6단계: End-to-End 테스트 (메시지 + 인증 + cron)
□ 7단계: 문제 있으면 troubleshooting으로 해결
□ 모든 단계 통과 시 {TARGET_DEVICE}에서 평소처럼 사용 시작
```

---

## 🔗 참고 링크

- 📜 **자동 복원 스크립트**: `~/Desktop/MIGRATION_FOLDER/{restore_script}.sh`
- 🔍 **검증 스크립트**: `~/Desktop/MIGRATION_FOLDER/{verify_script}.sh`
- 📚 **워크플로우 스킬**: `~/.hermes/skills/devops/device-environment-migration/SKILL.md`

---

## ⏱ 예상 소요 시간

| 단계 | 시간 | 비고 |
|---|---|---|
| 1단계 (백업 파일 전송) | {TIME} | AirDrop 기준 |
| 2단계 ({TARGET_OS} 셋업) | {TIME} | 다운로드 시간 포함 |
| 3단계 (시스템 복원) | {TIME} | venv 패키지 설치 시간 포함 |
| 4단계 (검증) | {TIME} | 자동 |
| 5단계 (채널 재연결) | {TIME} | OAuth 대기 시간 포함 |
| 6단계 (E2E 테스트) | {TIME} | 수동 |
| **총합** | **{TOTAL}** | |

---

> **작성:** {YYYY-MM-DD}
> **적용 환경:** {SOURCE_OS} → {TARGET_DEVICE}