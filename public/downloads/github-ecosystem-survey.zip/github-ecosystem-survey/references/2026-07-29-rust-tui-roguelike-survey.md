# Rust TUI Roguelike Ecosystem — Verified 2026-07-29

Knowledge bank captured from the first session that produced this skill.
Goal: provide a future agent (or future session) with the verified candidate list
so a new Rust TUI roguelike project doesn't have to re-discover the landscape.

## Top-3 ranked references (full evaluation in the original deliverable)

| Rank | Repo | Stars | License | Why it matters |
|---|---|---|---|---|
| 1 | `kako-jun/nobiscuit` | 0 | MIT | Exact half-block + 24-bit RGB TUI game. 2026-07 active. `crates/nobiscuit-cli/src/terminal.rs` shows the canonical `HalfBlockCell { top, bottom }` data model + diff output pattern. ~3.7K LOC. |
| 2 | `maria-rcks/mythos-adventure` | 29 | MIT | PS1-style 3D adventure rendered via ratatui `Widget` trait with `cell.set_symbol("▀")` + fg/bg RGB. ratatui buffer diff for free. ~3.3K LOC. |
| 3 | `001TMF/ProteinView` | 289 | MIT | ratatui + braille + Sixel/Kitty multi-modal. The reference if half-block doesn't satisfy. 11K LOC, modular widget/render/parser/model structure. |

## Half-block TUI projects (priority 1)

- `kako-jun/nobiscuit` — half-block + raycasting, BSP map gen, MIT, 2026-07-16 push
- `kako-jun/termray` — half-block raycasting engine (library), v0.3.0, MIT-equivalent (NOASSERTION)
- `kako-jun/street-golf` — half-block raycasting game, MIT, 2026-04-26 push
- `maria-rcks/mythos-adventure` — half-block via ratatui Widget (above)
- `GeorgeQLe/tui-doom` — DOOM-style raycasting in terminal, NOASSERTION, 2026-02-11 push

## Ratatui TUI games (priority 2 — broad)

| Repo | Stars | License | Notes |
|---|---|---|---|
| `thomas-mauran/chess-tui` | 1135 | MIT | Standard ratatui game reference (chess + Stockfish) |
| `unhappychoice/gittype` | 1528 | MIT | Code-typing game, advanced UX patterns |
| `Mjoyufull/Setrixtui` | 148 | GPL-3.0 | Tetris+Sand, ratatui Canvas/Block |
| `Hopson97/Asciimon` | 131 | NOASSERTION | Pokemon-style, ANSI-only, 2022 |
| `deepu105/battleship-rs` | 97 | MIT | TUI board game, state/input/render split |
| `ProHaller/sharad_ratatui` | 69 | Apache-2.0 | RPG port to ratatui |
| `cxreiff/ratthew` | 56 | NOASSERTION | Bevy → ratatui via bevy_ratatui_camera |
| `mtclab/deep-world-tui` | 0 | MIT | Procedural life-RPG, 2026-07-18 push |
| `RyanMAubrey/Dungeon-Core` | 0 | MIT | "Roguelike dungeon engine" Bevy ECS + ratatui |
| `daffyd-jones/the_caves` | 20 | NOASSERTION | 27K LOC generative RPG |
| `DraSoGo/Crawl_RS` | 1 | MIT | Classic ASCII roguelike, 2026-05-08 push |
| `Plusive27-max/ASCII-dungeon-crawler-in-Rust` | 1 | NOASSERTION | procgen + AI + permadeath |
| `gold-silver-copper/soft_ratatui` | 104 | Apache-2.0 | ratatui software renderer (Buffer → pixel) |
| `orhun/ratty` | 3149 | MIT | GPU-rendered terminal emulator w/ ratatui |
| `ratatui/tachyonfx` | 1269 | (ratatui org) | Effects/animation lib for ratatui |
| `cxreiff/bevy_ratatui_camera` | 334 | NOASSERTION | Bevy → ratatui |

## Braille visualization (priority 3 — comparison only)

- `001TMF/ProteinView` — ratatui `Marker::Braille` + Kitty + Sixel fallback (289⭐)
- `psmux/TerminalMap` — OSM tiles in braille, MIT, 2026-07-18 push
- `booleancoercion/braille-image` — image → braille CLI, MIT, 2021

## Procgen libraries (priority 4 — borrow map)

| Library | Algorithm | License | State |
|---|---|---|---|
| `THeK3nger/CellularMaps-Rust` | 2D CA → bitmap | Unlicense | Active, 210 LOC, single-file lib |
| `madwareru/simple-tiled-wfc` | Simple WFC | NOASSERTION | 2021 |
| `math-fehr/fast-wfc-rs` | Performance WFC | NOASSERTION | — |
| `BonsonW/wfc_voxel` | WFC + voxel input | NOASSERTION | — |
| `ur-fault/TMaze` | Maze algorithms + game | NOASSERTION | 2026-07-22 push |

WFC crates exist but are heavy for game-sized mazes — BSP for rooms+corridors, CA
for room interior texture is the practical split.

## Verified borrowing patterns (with file:line citations)

### half-block emission (canonical pattern, mythos-adventure)

```rust
// src/render.rs (mythos-adventure) — set_symbol("▀") + fg/bg RGB
cell.set_symbol("▀");
cell.set_style(
    Style::new()
        .fg(Color::Rgb(top[0], top[1], top[2]))
        .bg(Color::Rgb(bot[0], bot[1], bot[2])),
);
```

Why this is the right approach: ratatui's buffer diff handles flicker reduction
without manual front/back Vec swap (which nobiscuit does manually).

### Framebuffer abstraction (mythos-adventure)

```rust
pub struct Framebuffer {
    pub w: usize,
    pub h: usize,
    color: Vec<[u8; 3]>,
    depth: Vec<f32>,  // for z-buffer if going 3D
}
```

### diff-based manual rendering (nobiscuit)

```rust
// src/terminal.rs:80-100 — for when you don't use ratatui Widget
let idx = r * self.cols + c;
if cell != self.front[idx] {
    queue!(writer, cursor::MoveTo(c as u16, r as u16),
           SetForegroundColor(...), SetBackgroundColor(...), Print("▀"));
}
```

## License compatibility summary

| Repo | License | Compatibility with MIT/Apache-2.0 |
|---|---|---|
| nobiscuit | MIT | ✅ |
| mythos-adventure | MIT | ✅ |
| ProteinView | MIT | ✅ |
| bracket-lib | MIT | ✅ |
| CellularMaps-Rust | Unlicense | ✅ public domain |
| tachyonfx | MIT (verify before dep) | ✅ (verify) |
| Setrixtui | GPL-3.0 | ⚠️ copyleft — incompatible with MIT/Apache distribution |
| Various "NOASSERTION" | Custom | ⚠️ read LICENSE file manually |

## Anti-patterns (do not adopt)

- `bracket-lib` whole-package: ratatui + bracket-lib dual console abstraction creates friction. Borrow algorithms only.
- Bevy/wgpu GPU pipeline: heavy, requires terminal-emulator-level work (see `orhun/ratty`). Stick with half-block in ratatui Buffer for TUI roguelike.
- Braille-as-primary: scattered dots, bad for solid shading. Use braille for minimap or charts only.

## Verified method (this session)

- GitHub API `search/repositories` × 30+ queries
- Direct `git clone --depth=1` × 6: nobiscuit, ProteinView, ratty, mythos-adventure, the_caves, CellularMaps-Rust
- Real LOC measurement via `find -name "*.rs" -exec wc -l`
- License verified via `repo.license.spdx_id` from API + spot-checked raw LICENSE file
- 2-3 repos hit secondary rate limit (skius/teng, Stattek/starstruck-rust) — flagged in metadata appendix

## Future research directions

- ratatui Canvas widget patterns (Marker::Braille/Dot/Block) for hybrid rendering
- tachyonfx animation library integration for floor transitions
- bevy_ratatui_camera if user later wants Bevy ECS integration (cxreiff/ratthew is the demo)
