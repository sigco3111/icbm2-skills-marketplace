---
name: github-ecosystem-survey
description: Survey GitHub repos before building a new OSS project.
tags: [github, survey, reference-research, pre-build, code-patterns, ecosystem]
category: github
---

# GitHub Ecosystem Reference Survey

Class-level workflow for the **pre-build research phase**: produce a single reference dossier that maps the existing GitHub ecosystem around a project the user is about to start, with verified code patterns and explicit "borrow this from X" recommendations.

## When to use

- User: "Rust로 된 TUI 로그라이키 레퍼런스 조사해줘"
- User: "React Three.js 게임 fork 후보 5개 + 차용 패턴 정리"
- User: "Python CLI 도구 구현 패턴 — typer/click/argparse 비교"
- User: "이 도메인의 기존 OSS 프로젝트들 + 우리 구현에 참고할 점"
- User: "before I start building X, survey the existing ecosystem"

The deliverable is a **deep reference document** (one file, typically 150-300 lines), not a 5-line alternatives table.

## When NOT to use

- User just wants to evaluate ONE known repo → `github-repo-triage`
- User wants alternatives to ONE known ref (no code inspection) → `open-source-similar-finder`
- User wants to fork + localize a specific repo → `github-game-candidate-scouting` (or `oss-fork-localization`)
- User wants structural probe of one repo → `github-brief-vs-reality-probe`
- User wants news/article-based research → `auto-researcher`

## Output structure (the one the user will read)

```markdown
# <Domain> Reference Survey (YYYY-MM-DD)

## 추천 3개 (핵심)
(가장 우선 검토 3개 — full evaluation)

## <Priority category 1> (e.g. "half-block visual Rust projects")
(table + per-row 2-line evaluation)

## <Priority category 2> (e.g. "ratatui TUI games broad")
(table + evaluation)

## <Priority category 3> (e.g. "braille visualization — comparison only")
(short)

## <Priority category 4> (e.g. "procgen libraries — borrow map")
(short)

## 차용 권장 패턴 요약
(concrete code-pattern recommendations — file:line citations)

## 부록 — 메타
(data sources, API rate-limit events, measurement caveats)
```

The user's natural-language spec already enumerates the priority categories — use them verbatim as section headings.

## Workflow

### Phase 0 — Lock the priorities

Before any API call, restate the user's priority list as section headings of the final document. This is the contract:
- Each priority category becomes a table section.
- "추천 3개" section is at the top (the user reads this first).
- The closing "차용 권장 패턴" section is mandatory — the deliverable is not just a list, it's a build-direction document.

### Phase 1 — Multi-source data collection (batched)

Run 8-15 GitHub API queries in parallel, dedupe by `full_name`. Sources to combine:
- `search/repositories?q=<keyword>+language:<lang>&sort=stars&per_page=N`
- `search/repositories?q=<characteristic>+language:<lang>` (broader net)
- `search/repositories?q=<specific-tech>+<visual-mode>` for each priority
- For each top candidate (10-15), `repos/<owner>/<name>` for metadata
- For each top-3 in "추천 3개", fetch `/readme` (raw) and `/languages`

**Pitfall 1: GitHub API secondary rate limit (403).** Use `time.sleep(5-8)` between search calls and `time.sleep(2)` between detail calls. When 403 fires, drop to web search (GitHub HTML scraping fails too — see Pitfall 2).

**Pitfall 2: HTML search scrape returns 429 fast.** If API is rate-limited, do NOT pivot to `github.com/search?q=...&type=repositories` HTML — it 429s even faster. Wait 60s, then resume API.

**Pitfall 3: `description` can be null.** Always handle: `r.get('description') or ''`. F-string format like `f"{r.get('description')[:80]}"` will TypeError on None.

**Pitfall 4: 0⭐ is not "dead".** New repos (especially cargo crate releases) start at 0. Verify via `pushed_at < 90 days` + active commit count before scoring. Multiple top findings in 2026 have been 0⭐ projects that turned out to be the canonical implementation.

### Phase 2 — Clone-and-peek the top 5-6

Metadata is necessary but not sufficient. For each top recommendation, `git clone --depth=1` to `/tmp/<name>` and read:
- `Cargo.toml` / `package.json` (deps, Rust edition, MSRV)
- Top 2-3 source files by `find -name "*.rs" | xargs wc -l | sort -rn | head`
- The file that contains the canonical implementation of the technique the user asked about (e.g. `terminal.rs` for half-block emission)

This step produces:
- Real LOC measurement (`find . -name "*.rs" -exec wc -l {} \; | awk '{sum+=$1}'`)
- File-level pattern citations for the closing recommendations
- License confirmation (some repos have no GitHub-API license field but a real LICENSE file)

**Do not skip this phase.** Metadata-only surveys are easy to fake and easy to be wrong about. The clone-and-peek is what gives the survey its credibility.

### Phase 3 — Cross-reference visual modes and techniques

The user almost always wants to know "who does this technique well?" not just "who works in this domain?". Build a small mental map:

| Technique | Who does it cleanly | Pattern |
|---|---|---|
| half-block emission | X / Y / Z | A vs B (which is simpler?) |
| braille rendering | ProteinView | ratatui Canvas + Marker::Braille |
| terminal diff (front/back buffer) | nobiscuit | manual swap per frame |
| ... | ... | ... |

This becomes the "## 추천 3개" section body — each entry cites the technique, the repo, and the file:line.

### Phase 4 — License compatibility matrix

Mandatory. For each top recommendation, fill a row:
- License (SPDX)
- Compatible with user's likely project license (MIT/Apache-2.0 = permissive; GPL = copyleft; Unlicense = public domain)
- Attribution requirement
- Code-level vs asset-level split (some repos are MIT for code but CC-BY-NC for assets — easy to miss, see `github-game-candidate-scouting` Pitfall 2b)

End with explicit "OK to fork / OK with attribution / OK for non-commercial only / Avoid" verdict per repo.

### Phase 5 — Write the closing "차용 권장 패턴" section

This is the deliverable's payoff. Pattern: numbered list, each item contains:
1. **What** — 1-line pattern name (e.g. "half-block 핵심 트릭 — mythos-adventure 방식 채택")
2. **Why** — 1-2 sentences on why this is the right approach
3. **Code citation** — actual code snippet or file:line reference
4. **Concrete structure for OUR project** — `Framebuffer { w, h, color: Vec<[u8;3]> }`, etc.

Add an explicit "피해야 할 것" subsection — the user benefits as much from "don't adopt X" as "do adopt Y".

### Phase 6 — Honest metadata appendix

End with a brief meta section. Items to include:
- Investigation date
- Tools used (GitHub API endpoints + repos cloned)
- Rate limit events and how they affected coverage
- LOC measurement caveat (which repos were real-measured vs KB-only)
- License confirmation caveat (GitHub API vs LICENSE file)
- Any judgment calls ("we treated 0⭐ + active push as 'alive' because...")

The user explicitly asked for honesty in the session that produced this skill — don't manufacture data you didn't actually verify.

## Output principles

1. **Recommended 3 first.** Even if the survey found 30 repos, lead with the 3 the user should actually read. Everything else is supporting evidence.
2. **One file, not many.** Markdown file at `/Users/mac/work/<project>_references.md`. The user reads top-to-bottom in one go.
3. **Clickable links, every repo.** Use `[`owner/repo`](https://github.com/owner/repo)` format. The user will click from the document.
4. **Tables for bulk comparison.** Markdown tables for >3 candidates at the same priority level. Per-row evaluation can go in a "평가" subsection below the table.
5. **Korean by default.** This skill originated in a Korean-language session. Adjust to user's language.
6. **No fluff.** No "이 조사는 ..." opening paragraph. Start with the recommended 3.
7. **The closing section is the deliverable.** "추천 3개" is the summary; "차용 권장 패턴" is the action. Time spent in Phase 5 is well-spent.

## Pitfalls

- **Don't drown the user in candidates.** 20 candidates across 4 priority categories is too many. 5-7 per priority category, 3 in "추천 3개", 2-3 in "비교용" / "차용용" categories.
- **Don't recommend 0⭐ as "popular".** Present them as "actively maintained but low discoverability" — different signal.
- **0⭐ + active push ≠ active in production.** A 0⭐ repo with daily commits might be a personal project, not a battle-tested library. Call this out.
- **License N/A on GitHub API ≠ no license.** Always `curl -fsSL https://raw.githubusercontent.com/<owner>/<repo>/<branch>/LICENSE` to confirm. Many repos forget to set the GitHub API license field.
- **KB ≠ LOC.** Repo `size` field is in KB and includes everything (`.git` not counted but `node_modules` is). For LOC, `find -name "*.rs" -exec wc -l` after clone is the only reliable measurement.
- **Don't duplicate content between sections.** The "추천 3개" full evaluation should not be repeated in the priority-category tables — point to it.
- **Code citations must be file:line or file:function — not "see the source".** The user will read these. `nobiscuit/src/terminal.rs:80-100 (present function)` is useful; "the terminal handling code" is not.
- **Don't recommend Bevy/ECS integration when the user explicitly said ratatui-only.** If the user's spec rules out an approach, even good matches in that direction go to "비교용" section, not "추천".
- **Don't fabricate descriptions when API returns null.** Fetch the README or write "README 미확인" — never invent.
- **Survey is not a fork decision.** Even when surveys turn up great candidates, the user might still choose to build from scratch. Don't slip into fork advocacy — the deliverable is the reference dossier, not a recommendation to fork.

## Verification commands (per phase)

### Phase 1 — Multi-source collection

```python
# Resilient GitHub API call with rate-limit awareness
import urllib.request, urllib.parse, json, time

def gh_search(q, per_page=10):
    encoded = urllib.parse.quote(q + " language:<LANG>")
    url = f"https://api.github.com/search/repositories?q={encoded}&sort=stars&order=desc&per_page={per_page}"
    req = urllib.request.Request(url, headers={"User-Agent": "<your-bot-name>"})
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read().decode()).get("items", [])
    except urllib.error.HTTPError as e:
        if e.code == 403:
            return [{"rate_limited": True}]
        return [{"error": str(e)}]

# Batch with sleep
queries = ["q1", "q2", "q3", ...]
for q in queries:
    items = gh_search(q, 8)
    # process; track rate-limit events
    time.sleep(7)  # API gap
```

### Phase 2 — Clone + peek

```bash
# Pick top 5 candidates from "추천 3개" + 2 more if close
mkdir -p /tmp/refs
cd /tmp/refs
for repo in owner1/repo1 owner2/repo2 owner3/repo3; do
    git clone --depth=1 "https://github.com/${repo}.git" 2>&1 | tail -2
    sleep 1
done

# Per repo:
cd /tmp/refs/<repo>
find . -name "*.rs" -not -path "*/target/*" -exec wc -l {} \; | awk '{sum+=$1} END {print "Total LOC:", sum}'
# Find the file containing the key technique:
grep -rl "▀\|set_pixel\|half.*block" src/ 2>/dev/null
# Read that file's relevant lines
sed -n '50,150p' src/terminal.rs
```

### Phase 4 — License confirmation

```bash
# GitHub API may say N/A — actual LICENSE file is the truth
curl -fsSL "https://raw.githubusercontent.com/<owner>/<repo>/<branch>/LICENSE" | head -5
# If 404, try:
for branch in main master; do
    code=$(curl -s -o /dev/null -w "%{http_code}" "https://raw.githubusercontent.com/<owner>/<repo>/$branch/LICENSE")
    echo "$branch: $code"
done
```

## Reference files (knowledge banks)

- `references/2026-07-29-rust-tui-roguelike-survey.md` — verified candidate list
  for the Rust TUI roguelike ecosystem as of 2026-07-29. Top-3 with file:line
  citations, license compatibility matrix, verified borrowing patterns. Future
  sessions building a Rust TUI roguelike can skip Phase 1-2 of the workflow
  if this data is still current.

## Related skills

- `open-source-similar-finder` — when user has a known reference and wants alternatives (no code inspection)
- `github-game-candidate-scouting` — when user wants fork + localization scoring (not reference material)
- `github-repo-triage` — 5-line verdict on a single known repo
- `github-brief-vs-reality-probe` — deep structural verification of one repo
- `auto-researcher` — news/article-based research, Notion-tied, Korean
- `github-cli` — `gh` CLI recipes for everything in this skill
