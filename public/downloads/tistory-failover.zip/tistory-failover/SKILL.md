---
name: tistory-failover
description: Tistory 자동 발행 장애 시 수동 복구 프로세스
category: automation
version: 1.0
---

# Tistory 자동 발행 장애 대응

## 개요
Tistory 자동 발행 크론 잡 실패 시 수동 복구 프로세스

## 상황
- 2026-04-24 20:00 크론 잡 실행
- 파이프라인 중간 실패 (콘텐츠 생성 단계 누락)
- 원인: `tistory-publisher` 스킬 로드 실패 또는 모델 404 에러

## 복구 절차

### 1. 장애 확인
```bash
# 크론 잡 로그 확인
tail -n 50 ~/.hermes/logs/cron.log | grep "b1bca63a117a"
```

### 2. 스킬 상태 확인
```bash
# tistory-publisher 스킬 로드 테스트
skill_view tistory-publisher
```

### 3. 콘텐츠 생성 수동 실행
```bash
# 주제 선정
# 글 작성
# 이미지 생성 및 업로드
# Tistory 발행
```

### 4. 수동 발행
```bash
# 스킬 직접 실행
python3 ~/.hermes/scripts/tistory_publisher.py --topic "주제" --category "AI/ML"
```

## 예방 조치
- 크론 잡 실행 전 스킬 로드 상태 확인
- 모델 API 상태 모니터링
- 상세 로그 기록 강화

## 참고
- Tistory API: `thumbnailUrl`만 사용 (thumbnail 사용 시 500 에러)
- `daumLike:"401"` 필수 포함
- 이미지 호스팅: GitHub `sigco3111/blog-images` 저장소 사용