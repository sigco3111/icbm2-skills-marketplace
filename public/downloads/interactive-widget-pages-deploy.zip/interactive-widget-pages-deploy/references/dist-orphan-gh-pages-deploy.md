# Dist-build + orphan `gh-pages` branch deployment

When you have a bundler-produced `dist/` folder (Vite / PixiJS / Three.js / esbuild / CRA / Next static export) and want it on GitHub Pages with **zero CI dependency**, this is the fastest cold-start path. Worked example: `sigco3111/hermes-control-room` (PixiJS 2.5D Control Room, 2026-08-04, hermes-control-room-746682c) — 30 files in the gh-pages branch, deployed and serving 200 in under 2 minutes.

## When this variant fits

- Project uses a bundler (`vite build`, `esbuild --bundle`, `next build && next export`, `react-scripts build`, etc.) and produces a `dist/` or `build/` folder.
- Source code lives on one branch (`main` or `phase2-pixijs` or whatever), built output lives on `gh-pages`.
- You want a live URL fast, no Actions configuration.
- You're OK doing manual redeploys (`git checkout gh-pages && cp -r dist/. . && git add . && git commit && git push`) when the source changes.

## When this variant does NOT fit

- You want auto-redeploy on every push → use `.github/workflows/deploy.yml` + `actions/deploy-pages@v4`.
- You have build-time secrets or env vars → CI workflow with `secrets:` block.
- Project is a single HTML file → use the main §3 pattern (push `main` directly).

## The verified recipe (7 steps)

```bash
cd /path/to/project

# 0. Sanity: dist exists, build is current
ls dist/ | head
ls dist/assets/ | head

# 1. Create orphan branch — NO history inherited, NO .gitignore inherited
git checkout --orphan gh-pages

# 2. Clear the previous branch's index from working tree
git rm -rf . 2>/dev/null | tail -3

# 3. CRITICAL: write .gitignore on this branch BEFORE first git add
#    Orphan branch loses the parent .gitignore, so node_modules/ and dist/
#    would get staged on first add and bloat the commit to 6000+ files.
cat > .gitignore <<'EOF'
node_modules/
dist/
EOF

# 4. Copy dist contents to repo root
cp -r dist/. .

# 5. .nojekyll — Pages would otherwise run Jekyll over your output,
#    silently mangling asset paths and stripping files starting with _
touch .nojekyll

# 6. Commit + push
git add .
git commit -m "deploy: gh-pages initial"
git push -u origin gh-pages
```

Then enable Pages via REST API (gh CLI has no `--enable-pages` flag):

```bash
gh api -X POST "repos/$OWNER/$REPO/pages" \
  -f "source[branch]=gh-pages" \
  -f "source[path]=/"
# 409 = already enabled (harmless, retry was already executed)
```

## Mandatory verification (before reporting success)

GitHub Pages has a **1-5 minute propagation delay** after the first push. Verify with the same pattern every time:

```bash
# 1. Wait + check Pages build status (more reliable than blind sleep)
sleep 15
gh api "repos/$OWNER/$REPO/pages" | python3 -c "
import sys, json
p = json.load(sys.stdin)
print('status:', p['status'])           # 'building' -> 'built' -> null
print('url:', p['html_url'])
print('source:', p['source']['branch'], p['source']['path'])
"

# 2. Probe HTML root
curl -sL -o /dev/null -w "HTML: HTTP %{http_code}\n" \
  https://$GH_USER.github.io/$REPO/

# 3. Probe a representative asset (favicon + main bundle)
curl -sL -o /dev/null -w "favicon: HTTP %{http_code}\n" \
  https://$GH_USER.github.io/$REPO/favicon.svg
curl -sL -o /dev/null -w "main bundle: HTTP %{http_code} | size=%{size_download}\n" \
  https://$GH_USER.github.io/$REPO/assets/<main-bundle>.js

# 4. Spot-check 1-2 character/asset files (PNG, etc.)
curl -sL -o /dev/null -w "asset: HTTP %{http_code}\n" \
  https://$GH_USER.github.io/$REPO/assets/<some-asset>.png

# 5. Verify HTML body is correct (Korean title, modulepreload tags, etc.)
curl -sL https://$GH_USER.github.io/$REPO/ | head -20
```

Pass criteria: every URL returns 200. If HTML is 200 but assets 404 → check `.nojekyll` and that filenames don't start with `_`. If everything 404 → build hasn't propagated yet, `sleep 60` and retry.

## Pitfalls (each one cost ~5 minutes when they bit)

1. **Orphan branch forgets `.gitignore`** — first `git add .` after `git checkout --orphan` will happily stage `node_modules/` and `dist/`. Bloat: 6000+ files, 100MB+ commit, push timeout. Fix: write `.gitignore` BEFORE first `git add`, or `git rm -rf --cached node_modules dist` + `git commit --amend` if you caught it after.
2. **`git checkout --orphan` does NOT clear the working tree** — files persist from the previous branch checkout. `git rm -rf .` (with the dot) clears both index AND working tree. Use `--cached` if you only want to unstage.
3. **`gh repo edit --enable-pages` is a phantom flag** — `gh repo edit --help` does not list it, and `--enable-pages --pages-source-branch X --pages-source-path /` is silently rejected (CLI just prints the full `--help` flag list). Always use the REST API: `gh api -X POST repos/$OWNER/$REPO/pages -f "source[branch]=gh-pages" -f "source[path]=/"`. 409 response = already enabled, no-op.
4. **Missing `.nojekyll`** — without it, GitHub Pages runs Jekyll over your output. Jekyll strips files starting with `_`, processes some `.md`/`.html` for Liquid, ignores some asset paths. For an SPA from a bundler it's almost always wrong.
5. **Build path mismatch** — if you put `dist/*` at the repo root on `gh-pages`, set `source[path]` to `/`. If you keep `dist/` as a subdirectory (less common), set it to `/dist`. The Pages build serves from `source[path]` relative to `source[branch]`.
6. **First-deploy propagation 1-5 min** — `pages-build-deployment` workflow runs asynchronously after you push. Polling `GET /repos/{o}/{r}/pages` for `status: "built"` is more reliable than blind `sleep 60`.
7. **`pages-build-deployment` workflow is auto-injected** by GitHub when Pages is first enabled. You don't write this workflow. It shows up in `GET /actions/workflows` as soon as you push to `gh-pages`. Looking for it before the push is futile.
8. **Custom workflows that "deploy" but don't** — if you have a `.github/workflows/snapshot.yml` (or similar) that pushes `public/state.json` on the default branch, but your dist reads from `state.json` at root, the cron runs but the deployed site never updates. Always verify what file the deployed HTML actually loads.
9. **`gh-pages` npm package is optional** — `npm run deploy` using `gh-pages -d dist` works fine, but it adds a dependency and runs through the local Node environment. Direct branch push (this recipe) is faster and removes that coupling.
10. **Asset filenames with leading underscore** — if any asset starts with `_` (e.g. `_internal.js`), Jekyll will silently skip it. Either rename or use `.nojekyll` (recommended).

## Worked example: sigco3111/hermes-control-room

Session: 2026-08-04, 12 tool calls to fully deployed + verified.

**Setup**:
- Vite + React + PixiJS project at `/Users/mac/work/hermes-control-room/`
- Source branch: `phase2-pixijs` (3 commits, head `746682c`)
- `dist/` pre-built: 30 files, ~1MB total. Includes `assets/index-BPeAyKxf.js` (414KB main bundle), `assets/characters/*.png` (8 character PNGs), `state.json` (live state snapshot), `index.html` (Korean title).
- Repo didn't exist yet on github.com.

**Steps taken**:
1. `gh repo create sigco3111/hermes-control-room --public --description "..." --license MIT` (cold-start: NO `--add-readme`/`--source`/`--push` flags)
2. `git config user.email "sigco3111@users.noreply.github.com" && git config user.name "sigco3111"` (for gh-pages push identity)
3. `git remote add origin ... && git push -u origin phase2-pixijs --tags`
4. `git checkout --orphan gh-pages && git rm -rf . && cp -r dist/. . && touch .nojekyll`
5. First commit attempt staged `node_modules/`+`dist/` → 6821 files, 1.8M insertions (bloated). Caught it post-commit, did `git rm -rf --cached node_modules dist` + wrote fresh `.gitignore` + `git commit --amend`. Final: 30 files, 1149 insertions.
6. `git push -u origin gh-pages`
7. `gh api -X POST repos/.../pages -f "source[branch]=gh-pages" -f "source[path]=/"` → first call returned 409 (already enabled — first call must have succeeded silently), retried, confirmed Pages enabled.
8. Verified: `GET /repos/.../pages` returned `status: building`, then `status: built`. 8 character PNGs all 200. `pages-build-deployment` workflow status: completed/success.

**Final state**:
- Repo: https://github.com/sigco3111/hermes-control-room
- Live: https://sigco3111.github.io/hermes-control-room
- 3 commits + 1 tag (`phase1-r3f`) on `phase2-pixijs`. 1 commit on `gh-pages`. 0 user Actions runs (only the auto-injected `pages-build-deployment`).

**Issue found (not in scope to fix this session)**: pre-existing `.github/workflows/snapshot.yml` runs every 5 min on `*/5 * * * *`, but (a) checks out the default branch which is `main`, not `phase2-pixijs`, and (b) pushes `public/state.json` while dist serves `state.json` at root. So the cron runs but doesn't actually update the deployed site. Future fix: change the workflow to check out `gh-pages`, update root `state.json`, and commit back. Or change the build to copy `public/state.json` → `dist/state.json` before deploy.

## Updating an existing gh-pages deploy

When the source changes and you want to redeploy:

```bash
cd /path/to/project
npm run build              # or whatever builds dist/
git checkout gh-pages
git pull origin gh-pages   # get any remote updates
git rm -rf . 2>/dev/null | tail -3   # clear current gh-pages tree
cp -r dist/. .                          # copy fresh build
git add .
git commit -m "deploy: $(date +%Y-%m-%d-%H%M)"   # fresh commit
git push origin gh-pages
git checkout <source-branch>            # return to source branch
```

Don't use `git commit --amend` after a `git pull` — that loses the fetched history. Use a fresh commit message.

## Removing gh-pages deployment

```bash
# Disable Pages first (URL stops resolving immediately)
gh api -X DELETE "repos/$OWNER/$REPO/pages"

# Delete the branch
gh api -X DELETE "repos/$OWNER/$REPO/git/refs/heads/gh-pages"
# Or via git:
git push origin --delete gh-pages
```

`gh repo delete` does NOT remove the `gh-pages` branch automatically.