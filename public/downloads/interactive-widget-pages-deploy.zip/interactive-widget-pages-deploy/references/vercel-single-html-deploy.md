# Single-HTML + Vercel deploy pattern

A worked example of the **"single HTML file → GitHub → Vercel auto-deploy → hotfix loop"** pattern, from sigco3111/clipboard-history (2026-08-03).

## When this pattern fits

- The user wants a **standalone web page** (not an embeddable Web Component)
- The user has a Vercel account and `~/.vercel_token` set
- Single `<script>` block is feasible (no 10+ files of separate JS modules)
- The user is iterating fast: "버그 수정 했음. 다시 배포해줘" pattern (3+ times in a session)
- The user is OK with no build step and no framework

## The minimum viable project

```
~/work/<name>/
├── index.html              # HTML + <style> + <script> all in one file
├── README.md               # quick start, what it does, screenshot if possible
├── LICENSE                  # MIT
├── vercel.json              # static-build config (3 lines)
└── .gitignore               # .DS_Store, node_modules, *.log
```

### `vercel.json` for a static-only project

```json
{
  "buildCommand": null,
  "outputDirectory": ".",
  "framework": null
}
```

That's it. Vercel serves the root.

### `vercel.json` for an SPA with client-side routing

```json
{
  "rewrites": [{ "source": "/(.*)", "destination": "/index.html" }],
  "cleanUrls": false
}
```

This catches 404s on hard refreshes for any URL path → serves `index.html` → app handles routing client-side. Without this, `https://<app>.vercel.app/some/deep/path` returns 404 on direct visit but works on SPA navigation.

## Deploy commands (1-line)

```bash
TOKEN=$(cat ~/.vercel_token)
VERCEL_TOKEN="$TOKEN" vercel deploy --prod --yes
```

**Output**:
- `https://<project>-<random-hash>-<owner>.vercel.app` — initial preview URL
- `https://<project>-three.vercel.app` — auto-aliased stable URL (after 2nd+ deploy)

**Wait for deploy** (Vercel CLI is sync, but the CDN takes ~30s to propagate):
```bash
sleep 3
curl -sI https://<project>-three.vercel.app | head -1
# expect: HTTP/2 200
```

## Hotfix-deploy cycle (the speed advantage)

The point of this pattern is that you can ship a fix, see it live, in **under 30 seconds**:

```
T+0s   Edit index.html
T+5s   `node -e "<syntax check>"` (see "Pre-deploy validation" below)
T+10s  `git add -A && git commit -m "fix: ..."`
T+15s  `VERCEL_TOKEN="$TOKEN" vercel deploy --prod --yes`
T+25s  Deploy complete. User Cmd+Shift+R to hard-refresh.
T+30s  User verifies fix.
```

For a personal project where the user is the sole stakeholder, **skip the PR review / CI / staging environment** entirely. The risk model is "I break my own site" → trivial to recover (commit revert + redeploy).

## Pre-deploy HTML/JS validation (the one check that matters)

Before every `vercel deploy`, run the **JS syntax check** that catches 90% of "I broke my own site" bugs:

```bash
# Extract the <script> block and run new Function() on it
node -e "
const fs = require('fs');
const html = fs.readFileSync('index.html', 'utf-8');
const m = html.match(/<script>([\s\S]*?)<\/script>/);
if (m) {
  try { new Function(m[1]); console.log('JS syntax OK'); }
  catch (e) { console.log('JS SYNTAX ERROR:', e.message); process.exit(1); }
} else {
  console.log('no <script> block found');
}
"
```

**Why this works**: `new Function(jsString)` parses the JS without executing it. Any syntax error (missing brace, undeclared duplicate var, invalid template literal) throws a SyntaxError before the deploy. **Real example**: sigco3111/clipboard-history v0.2.2 had `let lastImageHash = ''` declared twice (once in v0.2.0 setup, once in v0.2.1 additions). A `new Function()` check would have caught the duplicate declaration in 1 second. The bug shipped and broke all UI (tab toggle, capture button) for one deploy cycle.

**After deploy**, also verify the right code went live:

```bash
# Quick smoke test: critical keyword should appear in both local and live
LOCAL_COUNT=$(grep -c "MY_CRITICAL_KEYWORD" index.html)
LIVE_COUNT=$(curl -s https://<project>-three.vercel.app/ | grep -c "MY_CRITICAL_KEYWORD")
[ "$LOCAL_COUNT" = "$LIVE_COUNT" ] || echo "MISMATCH! Local=$LOCAL_COUNT Live=$LIVE_COUNT"
```

## Token / credential setup

`~/.vercel_token` is a single account-scoped Vercel token (60 chars, starts with `vcp_`). It can deploy ANY project on the user's account. Treat as production-grade:

- `chmod 600 ~/.vercel_token`
- Do NOT log the value
- Do NOT commit
- Reference only by path: `$(cat ~/.vercel_token)`

**Token scope check** (Vercel CLI):
```bash
VERCEL_TOKEN="$TOKEN" vercel whoami
# expect: prints the username. If 401, token is bad.
```

**Project name** is auto-derived from the directory name or you can override:
```bash
vercel deploy --prod --yes --name <custom-project-name>
```

## The "버그 수정 했음. 다시 배포해줘" loop

The user comes back with "I fixed the bug, deploy it." Their commit is on their local working tree but **not yet pushed**:

```bash
# 1. Check what the user did
git status --short                    # may be clean (user committed but didn't say so)
git log --oneline | head -3           # check for fresh local commit

# 2. If working tree is clean and there's a fresh local commit
#    AHEAD of origin, push it before deploying
git log origin/main..HEAD --oneline   # shows local-only commits
git push origin main                  # CRITICAL: Vercel deploys from origin/main

# 3. Deploy
TOKEN=$(cat ~/.vercel_token)
VERCEL_TOKEN="$TOKEN" vercel deploy --prod --yes
```

**Why push matters**: `vercel deploy` builds from the local working tree or from the last-pushed remote commit (depending on how Vercel is configured). If the user's fix is committed locally but not pushed, the deploy may use the old code. **The `vercel deploy` CLI actually uses the local working tree by default** — it doesn't care about git. So:

- **If you `git add -A` first, then `vercel deploy`**: deploys the latest uncommitted changes (no commit needed)
- **If you commit + push, then `vercel deploy`**: deploys from working tree (which is now the latest commit) — same result
- **The danger**: user commits locally, says "deploy it", you `vercel deploy` directly → local working tree is clean (matches the user's commit) → fine. But if you `git pull` first to "be safe" and the user hadn't pushed, the pull might fast-forward to an older remote commit → deploy reverts the user's fix.

**Safe pattern**:
1. `git status --short` + `git log --oneline | head -3` to see the local state
2. If local has commits ahead of origin, push them: `git push origin main`
3. Then deploy

## When the user wants to delete

If the user is unhappy and says "저장소 제거" / "delete":

```bash
# Vercel — works immediately with the same token
TOKEN=$(cat ~/.vercel_token)
VERCEL_TOKEN="$TOKEN" vercel rm <project-name> --yes
# Cascades: project + all deployments + aliased URLs all gone.

# GitHub — needs `delete_repo` OAuth scope
gh repo delete <owner>/<repo> --yes
# If 403: user must `gh auth refresh -h github.com -s delete_repo` or delete via web UI.
```

**Order**: clean up Vercel first (URL stops working), then GitHub (so the user can't land on a 200 page after "I deleted everything"). Parallel is safe but sequential feels more honest.

**Local clone**: just `rm -rf` the project folder. No side effects.

## Full project example: sigco3111/clipboard-history

Built and shipped in one session (~2 hours, 8 versions). Final structure:

```
~/work/clipboard-history/
├── index.html              # 39KB single file (HTML + CSS + JS inline)
├── README.md               # 7.8KB
├── LICENSE                  # MIT
├── vercel.json              # { buildCommand: null, framework: null }
└── .gitignore               # standard
```

**Live URL**: `https://clipboard-history-three.vercel.app` (aliased, stable)
**GitHub**: `github.com/sigco3111/clipboard-history` (now deleted by user)

The repository went through these versions in one session:

| Version | Change | Deploy time |
|---------|--------|------------|
| v0.1.0 | Text clipboard MVP + JSON backup | 4s |
| v0.2.0 | Image capture + ZIP backup + tab UI | 6s |
| v0.2.1 | SHA-256 dedup + 100-item limit | 5s |
| v0.2.2 | Hotfix: duplicate `let lastImageHash` | 5s |
| v0.2.3 | paste event + visibilitychange + webp/gif | 6s |
| v0.2.4 | phantom-denied state fix | 5s |
| v0.2.5 | 1s polling + activity trigger | 5s |
| v0.2.6 | hash index migration fix | 6s |

**Total hotfix-deploy cycles: 8.** All worked. The pattern is robust.

## Common mistakes in this pattern

1. **Forgetting the syntax check before deploy** — caused the v0.2.2 bug that broke UI. Always run `node -e "new Function(...)"`.
2. **Calling `vercel deploy` without `--prod --yes`** — defaults to preview, requires interactive confirm, may use different alias.
3. **Pushing to a branch other than `main`** — Vercel deploys from the production branch (usually `main`). If your default branch is `master` or something else, Vercel may not pick it up.
4. **Logging the token value** — `$(cat ~/.vercel_token)` is the safe reference. Never `echo $TOKEN` in commit messages or chat messages.
5. **Not waiting for CDN propagation** — after deploy, `curl -sI` may return 200 from a fresh region but the user's browser may still be on a stale region for 30-60s. Tell them to hard-refresh.
6. **Mixing `package.json` + `vercel.json` + a build step** — for a true single-HTML project, you should have NONE of these. The Vercel default static detection is enough.

## Decision: when to migrate away from this pattern

Migrate to a real framework (Next.js, SvelteKit) when:
- The HTML file grows past ~100KB and is hard to navigate
- You need SSR or server-side data fetching
- You need multiple routes (an SPA with 5+ pages)
- The user starts asking about "build step" or "TypeScript" or "lint"

Until then, **stay single-HTML**. The simplicity is the value.
