# Library Showcase Page Template

**When to use this**: The user has shipped a single Web Component widget (`<bracket-view>`, etc.) and then says things like *"make a page where people can see multiple libraries side by side"* or *"I don't want iframes — make a sample using each library's source"*. This is the verified template for that second pass.

The pattern came from `https://sigco3111.github.io/bracket-view/`. The page mixes two kinds of samples:

1. **Self-implemented renderers** — a small JS module that mimics a third-party library's design pattern using vanilla DOM. Cheap, deterministic, always works.
2. **Live CDN imports** — the actual library's UMD script tag or ESM module loaded into the page. High-fidelity, but a real third-party lib can fail its own init.

## Layout

```
<header>
  Title + 1-paragraph "why this page" + tag badges (e.g. vanilla JS, React, ESM)
</header>

<main>
  <h2>Why this page</h2>
  <p>...</p>

  <div class="note">
    Each card below renders the SAME data using a different approach.
  </div>

  <h2>The samples</h2>

  <div class="lib-grid">
    [5 cards: self-implemented renderers]
    [2 cards: live CDN imports (with fallback for failure)]
  </div>

  <h2>Code that drives them all</h2>
  <pre><code>// 5 self-implemented render functions + 2 live import wrappers
</code></pre>
</main>

<script id="sample-data" type="application/json">
  { ... one shared data object, all 8 teams, all rounds ... }
</script>
<script src="./bracket-samples.js"></script>
<script src="https://cdn.jsdelivr.net/npm/lib@x/dist/lib.min.js"></script>
<script type="module">
  // live-import wrappers
</script>
```

## Card grid CSS

```css
.lib-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(360px, 1fr));
  gap: 20px;
  margin-bottom: 32px;
}
.lib-card {
  background: var(--card);
  border: 1px solid var(--line);
  border-radius: 12px;
  overflow: hidden;
  display: flex;
  flex-direction: column;
}
.lib-meta { padding: 14px 16px; border-bottom: 1px solid var(--line); }
.lib-frame { padding: 16px; background: #fafafc; min-height: 360px; }
.lib-card .actions { padding: 12px 16px; border-top: 1px solid var(--line); }
```

`auto-fit + minmax(360px, 1fr)` keeps the cards equal-width and the grid responsive without media queries.

## The 5 self-implementation functions (pattern template)

Each function takes a `target` DOM element and writes the bracket into it. The shared data shape goes through:

```js
function renderXxx(target) {
  const root = document.createElement('div');
  root.className = 'xxx-root';
  // build DOM from data.reactBV.matches tree
  // each match knows its `next` (parent match id) and `players[]`
  target.appendChild(root);
}

document.querySelectorAll('[data-sample]').forEach(el => {
  const which = el.dataset.sample;
  ({bv: renderBv, vue: renderVue, jq: renderJq, react: renderReact, css: renderCssOnly}[which]?.(el));
});
```

CSS for each pattern is namespaced under its own class (`.bv-root`, `.vue-root`, `.jq-root`, `.rt-root`, `.css-root`) so the 5 implementations don't fight each other.

## Live import wrapper pattern (with failure fallback)

```js
(function () {
  try {
    const lib = await import('https://esm.sh/some-library@1?deps=...');
    const target = document.getElementById('livesample-foo');
    target.appendChild(lib.render(...));
    target.dataset.loaded = '1';
  } catch (e) {
    console.warn('foo failed:', e);
    // The card body is already a .lib-status panel with a fallback msg.
  }
})();
```

For the failure case, **pre-render a fallback card body** that the live-import wrapper never overwrites:

```html
<div id="livesample-shk" class="lib-status">
  <div class="lib-status-msg">
    <p class="lib-status-tag">library self-fail</p>
    <p>The published 1.0.7 build tries to write to <code>.shadowRoot</code>
       (read-only in modern browsers). Try 1.0.8 when released.</p>
    <p><a href="https://github.com/..." target="_blank">Source on GitHub ↗</a></p>
  </div>
</div>
```

```css
.lib-status { display: flex; align-items: center; justify-content: center;
              min-height: 280px; padding: 20px; }
.lib-status-tag { background: rgba(245,158,11,.15); color: #92580b;
                  border-radius: 999px; padding: 4px 12px;
                  font-size: 11px; font-weight: 700; text-transform: uppercase; }
```

## The 5+2 verified combinations (live as of 2026-07-17)

| # | Library | Stack | Import URL | Pattern source |
|---|---|---|---|---|
| 1 | brackets-viewer.js | vanilla | (self-impl) | DOM cards + hover highlight |
| 2 | vue-tournament-bracket | Vue 3 | (self-impl) | column + thin divider between rows |
| 3 | jquery-bracket | jQuery | (self-impl) | green stage label + dashed seed grid |
| 4 | react-tournament-bracket | React SVG | (self-impl) | crisp 1px rect + L-shape connector path |
| 5 | CSS-only baseline | none | (self-impl) | flex column with `margin-top: <nextRound * gap>` |
| 6 | @amirhossein-shk/tournament-bracket-js | vanilla | `<script src="https://cdn.jsdelivr.net/npm/@amirhossein-shk/tournament-bracket-js@1.0.7/dist/tournament-bracket.min.js">` | self-fail at runtime |
| 7 | Zettersten/gracket | vanilla | `<script type="module" src="https://cdn.jsdelivr.net/npm/gracket@2.1.1/dist/adapters/webcomponent.js">` then `<gracket-bracket players="...">` | WebComponent adapter |

## Subagent fan-out prompt template for OSS discovery

When the user wants *more* libraries to add, use `delegate_task` with this exact prompt shape — it worked to surface 6+ candidates in 3 minutes:

```
Goal: Find X OSS libraries on GitHub that match these constraints:
- [import format constraint, e.g. "CDN-script-tag or ESM-import friendly"]
- [framework constraint, e.g. "vanilla JS preferred"]
- [size constraint, e.g. "stars > 20"]
- [license constraint, e.g. "MIT"]

For each candidate:
1. repo URL
2. stars / last push date
3. exact import URL (jsDelivr / unpkg / esm.sh)
4. data model
5. how to render an 8-team single-elim demo in ~200 lines
6. license

End with "Top 4-5 recommended, ordered by ease of demo".
```

Critical detail: ask for the **exact import URL** and **a working demo snippet**, not just the README. The subagent has access to `curl` for `cdn.jsdelivr.net` and `npm` registry HEAD requests — make it use them.

## Hard-earned verification ritual

For every page like this:

```python
from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    b = p.chromium.launch()
    page = b.new_context(viewport={"width": 1280, "height": 2000}).new_page()
    err = []
    page.on("pageerror", lambda e: err.append(str(e)))
    page.goto("http://127.0.0.1:8765/", wait_until="networkidle")
    page.wait_for_timeout(8000)
    summary = page.evaluate("""({
        title: document.querySelector('h1')?.textContent,
        cardCount: document.querySelectorAll('.lib-card').length,
        childrenPerCard: [...document.querySelectorAll('[data-sample], [id^=livesample]')]
            .map(el => ({ id: el.id || el.dataset.sample, n: el.children.length })),
    })""")
    print("LIVE:", summary, "errors:", len(err))
    b.close()
```

Then on the live Pages URL:

```python
page.goto("https://sigco3111.github.io/<name>/", wait_until="networkidle")
page.wait_for_timeout(8000)
```

Both must report `errors: 0` and the expected `cardCount` + children counts.
