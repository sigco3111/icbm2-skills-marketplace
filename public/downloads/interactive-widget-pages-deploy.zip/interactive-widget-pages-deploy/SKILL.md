---
name: interactive-widget-pages-deploy
description: Build a self-contained, zero-dependency, zero-build interactive Web Component or widget, ship it as a public GitHub repo with a live demo on GitHub Pages, and iterate via Playwright-verified commits that auto-redeploy in ~30s. Use when the user wants a small, embeddable, browser-only interactive thing — a bracket view, an SVG visualizer, a slideshow, a custom editor, a chart — that runs anywhere with a single `<script>` import and has a public, shareable URL.
---

# interactive-widget-pages-deploy

A reusable workflow for **standalone interactive web widgets** — small single-file Web Components or vanilla-JS modules with a live demo on GitHub Pages. The whole thing — code, demo page, docs — lives in one repo and ships in four commits or fewer. No build step, no framework, no Vercel.

This pattern came out of building `<bracket-view>` (sigco3111/bracket-view): a tournament-bracket Web Component that started as a flat SVG, grew into a paper-fold card UX, and got connector lines and tabbed round pages — all shipped as a single 49 KB JS file at `https://sigco3111.github.io/bracket-view/`.

## When to use

Trigger on any of:
- "build me an interactive widget / component / visualizer"
- "make a `<my-thing>` I can drop into any page"
- "publish a tiny demo on GitHub Pages"
- "make it look like Google Search's [thing]"
- "single-file component, no build"

Skip when the project already needs a framework (React/Vue/Svelte), a build pipeline, server-side rendering, or backend logic. Those belong on Vercel + `coding-mission-fullcycle`.

## The pattern (5 steps)

### 1. Scaffold one JS file + one demo HTML

```
~/work/<name>/
  <name>.js          # the component itself, zero deps, ES module
  index.html         # demo, imports <name>.js as a module
  README.md          # usage, data shape, events, theming
  .gitignore         # DS_Store, .vscode/, node_modules/, *.log
```

Lock the component to **vanilla ES module + Custom Element** (`customElements.define('my-thing', ...)`). No npm, no bundler, no TypeScript compile step. The demo loads it with:

```html
<script type="module" src="./my-thing.js"></script>
<my-thing data="..."></my-thing>
```

Pick a category prefix (`<bracket-view>`, `<confetti-burst>`, `<stepper-chart>` — never `<v2-bracket>` or `<fix-X>`). One element name per repo.

### 2. Build in vertical slices, verify at every commit

Don't write the whole thing blind. Slice it so each commit is **renderable + verifiable** on its own:

1. **v0** — flat layout, no animation, just renders the data correctly. Commit. Live demo confirms it loads.
2. **v1** — add interaction (click handlers, winner propagation). Commit. Verify the click flow works.
3. **v2** — improve UX (transitions, sticky nav, theming). Commit.
4. **v3** — add the visual glue (connectors, alignment, polish). Commit.

Each slice ships to Pages and produces a real screenshot to inspect. Skipping the verification step per slice is how designs end up with broken layouts you don't notice until the user looks at production.

### 3. Ship to GitHub Pages in two commands

```bash
cd ~/work/<name>
gh repo create sigco3111/<name> --public \
  --description "Short tagline." \
  --source=. --remote=origin --push
gh api -X POST repos/sigco3111/<name>/pages \
  -H "Accept: application/vnd.github+json" \
  -f source[branch]=main -f source[path]=/
```

The `pages/builds/latest` endpoint reports the build status. Builds take ~30–35s for these tiny repos. Wait, then `curl -sIL https://sigco3111.github.io/<name>/` returns 200.

Do **not** add a `gh-pages` branch, a `.github/workflows/` action, or a build step. Pages serves the `/` of `main` directly. Every push to main = new build.

### 4. Verify with Playwright (template: `scripts/verify-widget.py`)

The companion script in this skill boots a headless chromium, takes screenshots of every interaction state, runs in both desktop and mobile viewports, and prints a summary line so you can read the result at a glance.

```bash
python3 scripts/verify-widget.py
# expects a local server on http://127.0.0.1:8765/
```

In your actual session, the local server comes from `python3 -m http.server 8765 --bind 127.0.0.1` in a backgrounded terminal. Kill it after verification.

A live post-push check — paste-and-run in the next session:

```python
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b = p.chromium.launch()
    page = b.new_context(viewport={"width":1280,"height":900}).new_page()
    err = []
    page.on("pageerror", lambda e: err.append(str(e)))
    page.goto("https://sigco3111.github.io/<name>/", wait_until="networkidle")
    page.wait_for_timeout(1500)
    print("errors:", len(err))
    b.close()
```

### 5. Stop verifying when it's boring

Stop adding tests/screenshots once a state is stable. The user knows it's done. Don't run the verifier on trivial README edits — push and move on.

## Interaction patterns worth keeping

These UX patterns came up while building `<bracket-view>` and are worth reaching for again:

- **Paper-fold cards** — multiple pages on a horizontal `scroll-snap-type: x proximity` track, with an IntersectionObserver tying active tab to scroll position. Touch swipe moves one page at a time; tab clicks call `track.scrollTo({left: page.offsetLeft, top: 0, behavior:'smooth'})`. Do **not** call `page.scrollIntoView()` or `tab.scrollIntoView()` because either can move the document viewport vertically.
- **M-curve connectors** between two columns on the same page — use a `grid-template-columns: 1fr 12px 1fr` with `grid-template-areas: 'from sv to'` and an absolutely-positioned SVG in the trench. Compute y1/y2 from card height + gap (`UNIT = CARD_H + GAP`) rather than reading DOM measurements, so layout math stays deterministic and reproducible.
- **Next-round preview slots** — instead of showing the full next round, render compact ghost cards with two slots each. A slot becomes filled (sky-blue, left-bordered) once the corresponding from-match decides. This keeps each page to one round's worth of cards while preserving the cascade visualization.
- **CSS LOCKED units** — when the connector math assumes `height: 84px` and `gap: 10px`, never let a "natural height" override break alignment. Set fixed heights on `.card`, fixed gaps on `.col`, and document the constants at the top of the CSS.

## Pitfalls (don't do these)

- **Do not put the SVG inside a wrapper SVG without a stable viewBox.** A viewBox of `0 0 1 N` with `preserveAspectRatio="none"` deforms the path; use a fixed pixel viewBox (`0 0 12 N`) so each unit = 1 pixel.
- **Do not use `setData()` then call helper functions that touch `_propagateWinner` before the new data is bound.** Propagate reads `this._data.rounds`; if `_data` is still the old structure you'll get `Cannot read properties of null (reading 'rounds')`.
- **Do not let SVG inside shadow DOM intercept clicks.** SVG containers by default catch pointer events on the root. Add `pointer-events: none` to the SVG root and `pointer-events: all` only on the clickable sub-groups, or use Playwright `dispatchEvent` to bypass pixel-level hit testing for E2E.
- **Do not introduce a second column with a real next round on a "single-round page."** Each tab = one round. Use the preview column with ghost slots; do not re-render the full next round.
- **Do not run Playwright clicks with `locator.click()` on SVG `<g>` elements that contain `pointer-events: none` children — Playwright will time out complaining about intercepts.** Use `page.evaluate(() => el.dispatchEvent(...))` or click the topmost interactive leaf, not the parent.
- **Do not add build steps (`vite`, `esbuild`, `tsc`) "to be safe."** Pages serves static files. A build step just adds a CI failure mode for no gain.

## Files in this skill

- `templates/widget-skeleton.html` — drop-in `index.html` with import + 2 demo instances + tabbed footer + README-style usage banner. Copy and replace names.
- `scripts/verify-widget.py` — Playwright verifier with desktop + mobile passes, page-error capture, screenshot set, and a one-line summary print.
- `references/gh-pages-quirks.md` — Pages-specific things: no build, no `buildCommand`, build duration, MIME types, `gh api` incantations.
- `references/interaction-patterns.md` — extended notes on paper-fold, scroll-snap, M-curves, IntersectionObserver, the "single-round page with preview" decision.

## When NOT to update this skill

- Skip update when the new learning is about a specific widget's *content* (e.g., "always sort teams alphabetically"). That's an in-component comment.
- Skip update when the user just wanted a tweak and didn't change the workflow. Tiny CSS nudges don't earn a skill edit.
