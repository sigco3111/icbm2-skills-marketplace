---
name: interactive-widget-pages-deploy
description: Build a self-contained, zero-dependency, zero-build interactive Web Component or widget, ship it as a public GitHub repo with a live demo on GitHub Pages, and iterate via Playwright-verified commits that auto-redeploy in ~30s. Use when the user wants a small, embeddable, browser-only interactive thing — a bracket view, an SVG visualizer, a slideshow, a custom editor, a chart — that runs anywhere with a single `<script>` import and has a public, shareable URL.
---

# interactive-widget-pages-deploy

A reusable workflow for **standalone interactive web widgets** — small single-file Web Components or vanilla-JS modules with a live demo on GitHub Pages. The whole thing — code, demo page, docs — lives in one repo and ships in four commits or fewer. No build step, no framework, no Vercel.

This pattern came out of building `<bracket-view>` (sigco3111/bracket-view): a tournament-bracket Web Component that started as a flat SVG, grew into a paper-fold card UX, got connector lines and tabbed round pages, then was repurposed as a 7-card library showcase page that runs both self-implemented renderers AND CDN-imported third-party libraries on the same data — all shipped as static files at `https://sigco3111.github.io/bracket-view/`.

## When to use

Trigger on any of:
- "build me an interactive widget / component / visualizer"
- "make a `<my-thing>` I can drop into any page"
- "publish a tiny demo on GitHub Pages"
- "make it look like Google Search's [thing]"
- "single-file component, no build"
- "comparative showcase of multiple widget libraries"

Skip when the project already needs a framework (React/Vue/Svelte), a build pipeline, server-side rendering, or backend logic. Those belong on Vercel + `coding-mission-fullcycle`.

## The pattern (5 steps)

### 1. Scaffold one JS file + one demo HTML

```
~/work/<name>/
  <name>.js          # the component itself, zero deps, ES module
  index.html         # demo, imports <name>.js as a module
  README.md          # usage, data shape, events, theming
  .gitignore         # DS_Store, .vscode/, node_modules/, *.log
```

Lock the component to **vanilla ES module + Custom Element** (`customElements.define('my-thing', ...)`). No npm, no bundler, no TypeScript compile step. The demo loads it with:

```html
<script type="module" src="./my-thing.js"></script>
<my-thing data="..."></my-thing>
```

Pick a category prefix (`<bracket-view>`, `<confetti-burst>`, `<stepper-chart>` — never `<v2-bracket>` or `<fix-X>`). One element name per repo.

### 2. Build in vertical slices, verify at every commit

Don't write the whole thing blind. Slice it so each commit is **renderable + verifiable** on its own:

1. **v0** — flat layout, no animation, just renders the data correctly. Commit. Live demo confirms it loads.
2. **v1** — add interaction (click handlers, winner propagation). Commit. Verify the click flow works.
3. **v2** — improve UX (transitions, sticky nav, theming). Commit.
4. **v3** — add the visual glue (connectors, alignment, polish). Commit.
5. **v4+** — if the user wants the demo page to become a *library showcase*, swap the demo HTML for a 7-card grid: 5 self-implementations of well-known patterns (boxed teams, column+divider, jQuery grid, SVG rect+L-connector, CSS-only baseline) + 2 actual CDN imports (one UMD, one WebComponent adapter) all rendering the same shared data. See `references/library-showcase-pages.md` for the verified template.

Each slice ships to Pages and produces a real screenshot to inspect. Skipping the verification step per slice is how designs end up with broken layouts you don't notice until the user looks at production.

### 3. Ship to GitHub Pages in two commands

```bash
cd ~/work/<name>
gh repo create sigco3111/<name> --public \
  --description "Short tagline." \
  --source=. --remote=origin --push
gh api -X POST repos/sigco3111/<name>/pages \
  -H "Accept: application/vnd.github+json" \
  -f source[branch]=main -f source[path]/
```

The `pages/builds/latest` endpoint reports the build status. Builds take ~30–35s for these tiny repos. Wait, then `curl -sIL https://sigco3111.github.io/<name>/` returns 200.

Do **not** add a `gh-pages` branch, a `.github/workflows/` action, or a build step. Pages serves the `/` of `main` directly. Every push to main = new build.

### 4. Verify with Playwright (template: `scripts/verify-widget.py`)

The companion script in this skill boots a headless chromium, takes screenshots of every interaction state, runs in both desktop and mobile viewports, and prints a summary line so you can read the result at a glance.

```bash
python3 scripts/verify-widget.py
# expects a local server on http://127.0.0.1:8765/
```

In your actual session, the local server comes from `python3 -m http.server 8765 --bind 127.0.0.1` in a backgrounded terminal. Kill it after verification.

A live post-push check — paste-and-run in the next session:

```python
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b = p.chromium.launch()
    page = b.new_context(viewport={"width":1280,"height":900}).new_page()
    err = []
    page.on("pageerror", lambda e: err.append(str(e)))
    page.goto("https://sigco3111.github.io/<name>/", wait_until="networkidle")
    page.wait_for_timeout(1500)
    print("errors:", len(err))
    b.close()
```

### 5. Stop verifying when it's boring

Stop adding tests/screenshots once a state is stable. The user knows it's done. Don't run the verifier on trivial README edits — push and move on.

## Interaction patterns worth keeping

These UX patterns came up while building `<bracket-view>` and are worth reaching for again:

- **Paper-fold cards** — multiple pages on a horizontal `scroll-snap-type: x proximity` track, with an IntersectionObserver tying active tab to scroll position. Touch swipe moves one page at a time; tab clicks call `track.scrollTo({left: page.offsetLeft, top: 0, behavior:'smooth'})`. **Do not call `page.scrollIntoView()` or `tab.scrollIntoView()`** — either can move the document viewport vertically. Combine with `overscroll-behavior-y: none` and `scroll-snap-stop: normal` so cross-axis snap never fires. See pitfalls below for the diagnostic.
- **Equal-width 2-column grid** — for any "left card + right card" or "from round + to round" layout, use `grid-template-columns: minmax(0, 1fr) 12px minmax(0, 1fr)` AND give every column child an explicit `grid-area: from` / `grid-area: to` (or named `grid-template-areas`). Otherwise auto-placement leaves an unused named area and the second column lands in an implicit 4th track that has no width allocation. See pitfalls below for the full story.
- **M-curve connectors** between two columns on the same page — use the trench `12px` between the two `minmax(0, 1fr)` columns as `grid-area: sv` and put an absolutely-positioned SVG there (NOT inside a wrapping SVG that gets stretched by `preserveAspectRatio="none"`). Compute y1/y2 from card height + gap (`UNIT = CARD_H + GAP`) rather than reading DOM measurements, so layout math stays deterministic and reproducible.
- **Next-round preview slots** — instead of showing the full next round, render compact ghost cards with two slots each. A slot becomes filled (sky-blue, left-bordered) once the corresponding from-match decides. This keeps each page to one round's worth of cards while preserving the cascade visualization.
- **CSS LOCKED units** — when the connector math assumes `height: 84px` and `gap: 10px`, never let a "natural height" override break alignment. Set fixed heights on `.card`, fixed gaps on `.col`, and document the constants at the top of the CSS.

## Pitfalls (don't do these)

- **Do not put the SVG inside a wrapper SVG without a stable viewBox.** A viewBox of `0 0 1 N` with `preserveAspectRatio="none"` deforms the path; use a fixed pixel viewBox (`0 0 12 N`) so each unit = 1 pixel.
- **Do not use `setData()` then call helper functions that touch `_propagateWinner` before the new data is bound.** Propagate reads `this._data.rounds`; if `_data` is still the old structure you'll get `Cannot read properties of null (reading 'rounds')`.
- **Do not let SVG inside shadow DOM intercept clicks.** SVG containers by default catch pointer events on the root. Add `pointer-events: none` to the SVG root and `pointer-events: all` only on the clickable sub-groups, or use Playwright `dispatchEvent` to bypass pixel-level hit testing for E2E.
- **Do not introduce a second column with a real next round on a "single-round page."** Each tab = one round. Use the preview column with ghost slots; do not re-render the full next round.
- **Do not run Playwright clicks with `locator.click()` on SVG `<g>` elements that contain `pointer-events: none` children — Playwright will time out complaining about intercepts.** Use `page.evaluate(() => el.dispatchEvent(...))` or click the topmost interactive leaf, not the parent.
- **Do not add build steps (`vite`, `esbuild`, `tsc`) "to be safe."** Pages serves static files. A build step just adds a CI failure mode for no gain.
- **Do not assume `grid-template-columns: 1fr 1fr` gives equal columns.** CSS Grid's `1fr` defaults to `min-width: auto`, so a column with a wider intrinsic min-content (long team names, larger fonts, dense data) silently claims more space than the other. Use `grid-template-columns: minmax(0, 1fr) 12px minmax(0, 1fr)` to force a floor of 0. **Diagnostic**: Playwright reports two cards on the same row with different `offsetWidth`. **Symptom**: Playwright code that asserts "left card width === right card width" fails despite CSS looking correct.
- **Do not let auto-placement put a child in an implicit column when you meant `grid-area: to`.** When the HTML uses `<div class="bv-col bv-col-next-preview">` but the CSS only assigns `.bv-col-from { grid-area: from }`, the preview column goes into an implicit column 4 instead of the named `to` slot — leaving the explicit `to` cell empty and the track one column wider than expected. The columns then *appear* the same width but the layout has an unused grid cell. **Always assign `grid-area: <name>` for every column child** that should land in a named area, and verify with `getComputedStyle(.bv-columns).gridTemplateAreas` returning the expected `"from sv to"` string.
- **Do not call `page.scrollIntoView()` from a tab click handler.** Even with `block: 'nearest'`, the browser will scroll the *document* to bring the focused button into view if the button is inside a sticky container that's not yet at the top. The user sees a vertical jump of ~280px on the first click — and again on every tab click where the active button changes. **Use `track.scrollTo({ left: page.offsetLeft, top: 0, behavior: 'smooth' })` on the inner track instead.** Also add `e.preventDefault()` on the click handler, `scroll-snap-type: x proximity` (not `mandatory`), and `overscroll-behavior-y: none`. **Diagnostic**: `window.scrollY` jumps from `0 → ~280` on the first tab click in Playwright while the user only intends horizontal change. Set up a Playwright listener that compares `window.scrollY` before/after each tab click; it should be `Δ === 0`.
- **Do not let a CDN-imported library silently corrupt the page.** When a third-party library fails its own init (e.g. tries to assign to `.shadowRoot` which is read-only, or throws inside `setTimeout`), capture the failure with a `try/catch` + visible fallback card showing the upstream repo URL + a one-line explanation of the failure mode. A page error in the console is invisible to most users — show them what's wrong so they know you tried.
- **Do not stuff JavaScript expressions into a `<script type="application/json">` block.** JSON.parse will throw on things like `players: ["A","B"].map((name,i)=>({id:i+1,name}))`. Build the JSON as a literal object — functions, `Date` constructors, regex literals, and `undefined` all break JSON.parse.
- **Do not skip cache invalidation when the user reports "no change."** When a GitHub Pages site has changed on `main` but the user reports identical behavior, first ask them to hard-refresh (Cmd+Shift+R / Ctrl+F5) or append `?v=<n>` to the URL. Browser cache + the GH Pages build cache are the most common "no change" causes, not a code bug. If `curl https://sigco3111.github.io/<name>/<file>.js | grep <marker>` shows the new code, the deploy is correct and the user is seeing cached assets.

## Files in this skill

- `templates/widget-skeleton.html` — drop-in `index.html` with import + 2 demo instances + tabbed footer + README-style usage banner. Copy and replace names.
- `references/library-showcase-pages.md` — the 5-self-impl + 2-live-import card grid used when the demo page is repurposed to compare multiple widget libraries. Includes the shared `SAMPLE_DATA` JSON shape, the 5 minimal render functions (`renderBracketsViewer`, `renderVue`, `renderJqBracket`, `renderReact`, `renderCssOnly`), the CSS for each visual style, and the CDN URLs that actually load + render.

For the Web-Component-specific patterns (shadow DOM, scroll-snap, IntersectionObserver, SVG overlays, paper-fold pages, equal-width grids), see the companion skill `vanilla-interactive-component` (software-development), which carries the verified Playwright scaffold (`scripts/verify-shadow-component.py`) and the deduped pitfall list.

## When NOT to update this skill

- Skip update when the new learning is about a specific widget's *content* (e.g., "always sort teams alphabetically"). That's an in-component comment.
- Skip update when the user just wanted a tweak and didn't change the workflow. Tiny CSS nudges don't earn a skill edit.