---
name: interactive-widget-pages-deploy
description: Build a self-contained, zero-dependency, zero-build interactive Web Component or widget, ship it as a public GitHub repo with a live demo on GitHub Pages, and iterate via Playwright-verified commits that auto-redeploy in ~30s. Use when the user wants a small, embeddable, browser-only interactive thing — a bracket view, an SVG visualizer, a slideshow, a custom editor, a chart — that runs anywhere with a single `<script>` import and has a public, shareable URL.
---

# interactive-widget-pages-deploy

A reusable workflow for **standalone interactive web widgets** — small single-file Web Components or vanilla-JS modules with a live demo on GitHub Pages. The whole thing — code, demo page, docs — lives in one repo and ships in four commits or fewer. No build step, no framework, no Vercel.

This pattern came out of building `<bracket-view>` (sigco3111/bracket-view): a tournament-bracket Web Component that started as a flat SVG, grew into a paper-fold card UX, got connector lines and tabbed round pages, then was repurposed as a 7-card library showcase page that runs both self-implemented renderers AND CDN-imported third-party libraries on the same data — all shipped as static files at `https://sigco3111.github.io/bracket-view/`.

## When to use

Trigger on any of:
- "build me an interactive widget / component / visualizer"
- "make a `<my-thing>` I can drop into any page"
- "publish a tiny demo on GitHub Pages"
- "make it look like Google Search's [thing]"
- "single-file component, no build"
- "comparative showcase of multiple widget libraries"

Skip when the project already needs a framework (React/Vue/Svelte), a build pipeline, server-side rendering, or backend logic. Those belong on Vercel + `coding-mission-fullcycle`.

**Trigger this skill for Vercel + single-HTML projects too** when the user wants a tiny interactive web app to deploy and iterate fast — even if it's not a "Web Component" in the `<my-tag>` sense. The hotfix-deploy cycle (§4 below) is the value-add; the deployment target (GitHub Pages vs Vercel) is a 3-line config swap. See "Vercel + inline-script single-HTML variant" below.

**Trigger this skill also for the build-from-dist variant** when the user has a bundler-produced `dist/` (Vite/PixiJS/Three.js/CRA/Next static export/esbuild output) and wants it on GitHub Pages. This is the orphan-`gh-pages`-branch recipe in §3b below — different packaging, same goal of a live `*.github.io/<repo>/` URL. Real example: `sigco3111/hermes-control-room` (PixiJS 2.5D Control Room, 2026-08-04).

## The pattern (5 steps)

### 1. Scaffold one JS file + one demo HTML

```
~/work/<name>/
  <name>.js          # the component itself, zero deps, ES module
  index.html         # demo, imports <name>.js as a module
  README.md          # usage, data shape, events, theming
  .gitignore         # DS_Store, .vscode/, node_modules/, *.log
```

Lock the component to **vanilla ES module + Custom Element** (`customElements.define('my-thing', ...)`). No npm, no bundler, no TypeScript compile step. The demo loads it with:

```html
<script type="module" src="./my-thing.js"></script>
<my-thing data="..."></my-thing>
```

Pick a category prefix (`<bracket-view>`, `<confetti-burst>`, `<stepper-chart>` — never `<v2-bracket>` or `<fix-X>`). One element name per repo.

### 2. Build in vertical slices, verify at every commit

Don't write the whole thing blind. Slice it so each commit is **renderable + verifiable** on its own:

1. **v0** — flat layout, no animation, just renders the data correctly. Commit. Live demo confirms it loads.
2. **v1** — add interaction (click handlers, winner propagation). Commit. Verify the click flow works.
3. **v2** — improve UX (transitions, sticky nav, theming). Commit.
4. **v3** — add the visual glue (connectors, alignment, polish). Commit.
5. **v4+** — if the user wants the demo page to become a *library showcase*, swap the demo HTML for a 7-card grid: 5 self-implementations of well-known patterns (boxed teams, column+divider, jQuery grid, SVG rect+L-connector, CSS-only baseline) + 2 actual CDN imports (one UMD, one WebComponent adapter) all rendering the same shared data. See `references/library-showcase-pages.md` for the verified template.

Each slice ships to Pages and produces a real screenshot to inspect. Skipping the verification step per slice is how designs end up with broken layouts you don't notice until the user looks at production.

### 3. Ship to GitHub Pages in two commands

```bash
cd ~/work/<name>
gh repo create sigco3111/<name> --public \
  --description "Short tagline." \
  --source=. --remote=origin --push
gh api -X POST repos/sigco3111/<name>/pages \
  -H "Accept: application/vnd.github+json" \
  -f source[branch]=main -f source[path]/
```

The `pages/builds/latest` endpoint reports the build status. Builds take ~30–35s for these tiny repos. Wait, then `curl -sIL https://sigco3111.github.io/<name>/` returns 200.

Do **not** add a `gh-pages` branch, a `.github/workflows/` action, or a build step. Pages serves the `/` of `main` directly. Every push to main = new build.

### 3b. Dist-build variant: orphan `gh-pages` branch from `dist/`

When the project already has a bundler (Vite/PixiJS/Three.js/esbuild/Next static export/CRA) that produces a `dist/` folder, do **not** try to teach Pages to build from `main`. The recipe is a separate orphan `gh-pages` branch that contains **only** the built output. This is the fastest cold-start deploy — no CI, no Actions, no `gh-pages` npm package, no waiting for build workflow. The full worked recipe with pitfalls is in `references/dist-orphan-gh-pages-deploy.md`; the summary:

```bash
# 0. dist/ already exists
git checkout --orphan gh-pages
git rm -rf . 2>/dev/null | tail -3
cat > .gitignore <<'EOF'
node_modules/
dist/
EOF
cp -r dist/. .
touch .nojekyll                # skip Jekyll processing
git add . && git commit -m "deploy: gh-pages initial"
git push -u origin gh-pages

# Enable Pages via REST API (gh CLI has no --enable-pages flag)
gh api -X POST repos/sigco3111/<name>/pages \
  -f "source[branch]=gh-pages" -f "source[path]=/"
# 409 = already enabled, harmless

# Verify (1-5 min propagation)
sleep 15
curl -sL -o /dev/null -w "HTML: HTTP %{http_code}\n" \
  https://sigco3111.github.io/<name>/
```

Pitfalls unique to this variant:
- **`git checkout --orphan` discards `.gitignore`** — first `git add .` will gladly stage `node_modules/` and `dist/` (6000+ files, 100MB+ commit). Always write `.gitignore` BEFORE the first `git add .`, or `git rm -rf --cached node_modules dist` + amend.
- **`.nojekyll` is mandatory** for any SPA with bundler-hashed assets — without it, GitHub Pages runs Jekyll over your output and silently mangles some paths.
- **`gh repo edit --enable-pages` is a phantom flag** that the CLI rejects silently. Always use the REST API.
- **First-deploy propagation 1–5 min** — poll `GET /repos/{o}/{r}/pages` for `status: "built"` rather than blind `sleep`.
- **`pages-build-deployment` workflow is auto-injected** by GitHub when Pages is first enabled. You don't write it; it shows up in `GET /actions/workflows` as soon as you push to `gh-pages`. Don't look for it before then.

When to prefer this variant over §3 above:
- Project has `dist/` from a bundler (Vite/PixiJS/etc.) — **this is the only variant that works for those.**
- Cold-start one-shot deploy where you don't need CI rebuild on every push.
- You want to keep source code on `main` separate from built output on `gh-pages`.

When to prefer §3 instead:
- Single-HTML or vanilla ES module project. Zero-build → push `main` directly.

When to prefer a custom Actions workflow (`.github/workflows/deploy.yml`) instead:
- You need auto-redeploy on every push to `main`.
- You have secrets/build-time env vars that can't live in the repo.
- You want preview deployments on PRs.

### 4. Verify with Playwright (template: `scripts/verify-widget.py`)

The companion script in this skill boots a headless chromium, takes screenshots of every interaction state, runs in both desktop and mobile viewports, and prints a summary line so you can read the result at a glance.

```bash
python3 scripts/verify-widget.py
# expects a local server on http://127.0.0.1:8765/
```

In your actual session, the local server comes from `python3 -m http.server 8765 --bind 127.0.0.1` in a backgrounded terminal. Kill it after verification.

A live post-push check — paste-and-run in the next session:

```python
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b = p.chromium.launch()
    page = b.new_context(viewport={"width":1280,"height":900}).new_page()
    err = []
    page.on("pageerror", lambda e: err.append(str(e)))
    page.goto("https://sigco3111.github.io/<name>/", wait_until="networkidle")
    page.wait_for_timeout(1500)
    print("errors:", len(err))
    b.close()
```

### 5. Stop verifying when it's boring

Stop adding tests/screenshots once a state is stable. The user knows it's done. Don't run the verifier on trivial README edits — push and move on.

## Interaction patterns worth keeping

These UX patterns came up while building `<bracket-view>` and are worth reaching for again:

- **Paper-fold cards** — multiple pages on a horizontal `scroll-snap-type: x proximity` track, with an IntersectionObserver tying active tab to scroll position. Touch swipe moves one page at a time; tab clicks call `track.scrollTo({left: page.offsetLeft, top: 0, behavior:'smooth'})`. **Do not call `page.scrollIntoView()` or `tab.scrollIntoView()`** — either can move the document viewport vertically. Combine with `overscroll-behavior-y: none` and `scroll-snap-stop: normal` so cross-axis snap never fires. See pitfalls below for the diagnostic.
- **Equal-width 2-column grid** — for any "left card + right card" or "from round + to round" layout, use `grid-template-columns: minmax(0, 1fr) 12px minmax(0, 1fr)` AND give every column child an explicit `grid-area: from` / `grid-area: to` (or named `grid-template-areas`). Otherwise auto-placement leaves an unused named area and the second column lands in an implicit 4th track that has no width allocation. See pitfalls below for the full story.
- **M-curve connectors** between two columns on the same page — use the trench `12px` between the two `minmax(0, 1fr)` columns as `grid-area: sv` and put an absolutely-positioned SVG there (NOT inside a wrapping SVG that gets stretched by `preserveAspectRatio="none"`). Compute y1/y2 from card height + gap (`UNIT = CARD_H + GAP`) rather than reading DOM measurements, so layout math stays deterministic and reproducible.
- **Next-round preview slots** — instead of showing the full next round, render compact ghost cards with two slots each. A slot becomes filled (sky-blue, left-bordered) once the corresponding from-match decides. This keeps each page to one round's worth of cards while preserving the cascade visualization.
- **CSS LOCKED units** — when the connector math assumes `height: 84px` and `gap: 10px`, never let a "natural height" override break alignment. Set fixed heights on `.card`, fixed gaps on `.col`, and document the constants at the top of the CSS.

## Pitfalls (don't do these)

- **Do not put the SVG inside a wrapper SVG without a stable viewBox.** A viewBox of `0 0 1 N` with `preserveAspectRatio="none"` deforms the path; use a fixed pixel viewBox (`0 0 12 N`) so each unit = 1 pixel.
- **Do not use `setData()` then call helper functions that touch `_propagateWinner` before the new data is bound.** Propagate reads `this._data.rounds`; if `_data` is still the old structure you'll get `Cannot read properties of null (reading 'rounds')`.
- **Do not let SVG inside shadow DOM intercept clicks.** SVG containers by default catch pointer events on the root. Add `pointer-events: none` to the SVG root and `pointer-events: all` only on the clickable sub-groups, or use Playwright `dispatchEvent` to bypass pixel-level hit testing for E2E.
- **Do not introduce a second column with a real next round on a "single-round page."** Each tab = one round. Use the preview column with ghost slots; do not re-render the full next round.
- **Do not run Playwright clicks with `locator.click()` on SVG `<g>` elements that contain `pointer-events: none` children — Playwright will time out complaining about intercepts.** Use `page.evaluate(() => el.dispatchEvent(...))` or click the topmost interactive leaf, not the parent.
- **Do not add build steps (`vite`, `esbuild`, `tsc`) "to be safe."** Pages serves static files. A build step just adds a CI failure mode for no gain.
- **Do not assume `grid-template-columns: 1fr 1fr` gives equal columns.** CSS Grid's `1fr` defaults to `min-width: auto`, so a column with a wider intrinsic min-content (long team names, larger fonts, dense data) silently claims more space than the other. Use `grid-template-columns: minmax(0, 1fr) 12px minmax(0, 1fr)` to force a floor of 0. **Diagnostic**: Playwright reports two cards on the same row with different `offsetWidth`. **Symptom**: Playwright code that asserts "left card width === right card width" fails despite CSS looking correct.
- **Do not let auto-placement put a child in an implicit column when you meant `grid-area: to`.** When the HTML uses `<div class="bv-col bv-col-next-preview">` but the CSS only assigns `.bv-col-from { grid-area: from }`, the preview column goes into an implicit column 4 instead of the named `to` slot — leaving the explicit `to` cell empty and the track one column wider than expected. The columns then *appear* the same width but the layout has an unused grid cell. **Always assign `grid-area: <name>` for every column child** that should land in a named area, and verify with `getComputedStyle(.bv-columns).gridTemplateAreas` returning the expected `"from sv to"` string.
- **Do not call `page.scrollIntoView()` from a tab click handler.** Even with `block: 'nearest'`, the browser will scroll the *document* to bring the focused button into view if the button is inside a sticky container that's not yet at the top. The user sees a vertical jump of ~280px on the first click — and again on every tab click where the active button changes. **Use `track.scrollTo({ left: page.offsetLeft, top: 0, behavior: 'smooth' })` on the inner track instead.** Also add `e.preventDefault()` on the click handler, `scroll-snap-type: x proximity` (not `mandatory`), and `overscroll-behavior-y: none`. **Diagnostic**: `window.scrollY` jumps from `0 → ~280` on the first tab click in Playwright while the user only intends horizontal change. Set up a Playwright listener that compares `window.scrollY` before/after each tab click; it should be `Δ === 0`.
- **Do not let a CDN-imported library silently corrupt the page.** When a third-party library fails its own init (e.g. tries to assign to `.shadowRoot` which is read-only, or throws inside `setTimeout`), capture the failure with a `try/catch` + visible fallback card showing the upstream repo URL + a one-line explanation of the failure mode. A page error in the console is invisible to most users — show them what's wrong so they know you tried.
- **Do not stuff JavaScript expressions into a `<script type="application/json">` block.** JSON.parse will throw on things like `players: ["A","B"].map((name,i)=>({id:i+1,name}))`. Build the JSON as a literal object — functions, `Date` constructors, regex literals, and `undefined` all break JSON.parse.
- **Do not skip cache invalidation when the user reports "no change."** When a GitHub Pages site has changed on `main` but the user reports identical behavior, first ask them to hard-refresh (Cmd+Shift+R / Ctrl+F5) or append `?v=<n>` to the URL. Browser cache + the GH Pages build cache are the most common "no change" causes, not a code bug. If `curl https://sigco3111.github.io/<name>/<file>.js | grep <marker>` shows the new code, the deploy is correct and the user is seeing cached assets.
- **Do not declare the same `let` / `const` variable name twice in a single `<script>` block** (2026-08-03, sigco3111/clipboard-history v0.2.2 hotfix). JavaScript throws `SyntaxError: Identifier 'X' has already been declared` and the **entire script never executes** — no event listeners, no listeners on `DOMContentLoaded`, no fallback. The page renders HTML/CSS but every button is dead. **Symptom**: user says "버튼이 안 먹어요 / 토글 안 됨 / 아무 반응 없음." **Root cause**: variable name collision across the 5+ edit passes. **Mitigation**: ALWAYS run `node -e "const fs=require('fs'); const m=fs.readFileSync('index.html','utf-8').match(/<script>([\s\S]*?)<\/script>/); if(m) new Function(m[1])"` before every `vercel deploy`. Catches 100% of duplicate-var / typo / unclosed-brace errors in <1 second.
- **Do not assume your hotfix is the only change the user has made.** (2026-08-03, sigco3111/clipboard-history session pattern) When a user comes back 4+ times in a row with "버그 수정 했음. 다시 배포해줘", the safe pattern is: (1) `git status --short` → see what's actually changed; (2) if working tree is clean, check `git log --oneline` for the most recent local commit; (3) `git push origin main` to make sure the user's commit is on remote before deploying. If the user committed locally but didn't push, `vercel deploy` from main with no fresh push will deploy the OLD remote SHA and the user's fix won't appear. The pattern "user fixes locally, agent deploys" requires explicit push, not implicit "already on main."
- **Do not chase "user wants to delete" requests by struggling to satisfy every step.** (2026-08-03, sigco3111/deep-ocean deletion) The user said "깃허브에 새프로젝트를 진행하고 싶은데, 뭐가 좋을까?" → we picked deep-ocean → built → deployed → fixed → user said "버그 수정 배포" → fixed more → user said "ok 리드미를 더 다듬을 것이 있다면 갱신해주고, 프로젝트를 마무리하자" → I finished it → user said "조금 실망이네... 저장소와 vercel 제거" (literally "I'm a little disappointed... remove the repository and vercel"). The lesson: the user has a **stop-loss heuristic for projects**. When the project stops delighting them (frequent hotfix cycles, persistent bugs), they cut losses and move on. **This is a feature, not a failure.** Don't try to talk them out of deletion; the next-iteration cost is higher than the rebuild cost. The Vercel + GitHub deletion workflow:
  - GitHub: `gh repo delete owner/repo --yes` — **requires `delete_repo` OAuth scope** that the gh CLI doesn't have by default. The user has to either re-auth (`gh auth refresh -h github.com -s delete_repo`) or delete via web UI (https://github.com/owner/repo/settings → Danger Zone). Don't claim the deletion worked from the CLI without `delete_repo` scope — you'll get 403.
  - Vercel: `vercel rm <project>` — works with the same `~/.vercel_token` you used to deploy. The deployment alias (`<project>-three.vercel.app`) cascades down automatically. No need to `vercel alias rm` separately.
  - **Order matters**: clean up Vercel FIRST (so the user can't accidentally land on a 200 page after "deleting"), then GitHub. Or in parallel — both safe in any order, but visually user-perceived "the URL still works" can confuse.
- **Do not recommend large-disk projects when the user has just deleted one for that reason.** (2026-08-03, sigco3111 session pattern) The user deleted deep-ocean (Globe.gl + ETOPO1, ~7GB Git history) and immediately said "생각보다 저장공간이 많이 필요하네... 다른 아이디어를 찾자". The signal is **strong**: prefer candidates whose total footprint is under 100MB (single HTML, simple Swift app, small CLI). For visual ideas, this means **PNG/JSON data bundled in code, not 6.7GB of raw Earth bathymetry**. The user's mental model is "I want to git-clone this and the disk impact should be negligible" — match that.
- **Do not propose a "use this other person's repo" as the next step without first running a candidate scouting pass.** (2026-08-03, sigco3111 session) After deep-ocean deletion, the user gave generic idea prompts that didn't excite them. I escalated through 3 rounds of "give me more options" before they finally said "다른 사람의 저장소를 참고해보자" (let's reference someone else's repo). **The right move at the "끌리는 것이 없네" signal** is to immediately load `github-ecosystem-survey` or run a `gh search repos` query for popular OSS in the candidate category — show a 3-5 row table of stars/last-active/description, then ask which to investigate. **Don't loop through your own idea-bank** if the user has already heard 5+ options from it. Switch the source of inspiration to the OSS ecosystem at the first "끌리는 것 없음" signal.

## Files in this skill

- `templates/widget-skeleton.html` — drop-in `index.html` with import + 2 demo instances + tabbed footer + README-style usage banner. Copy and replace names.
- `references/library-showcase-pages.md` — the 5-self-impl + 2-live-import card grid used when the demo page is repurposed to compare multiple widget libraries. Includes the shared `SAMPLE_DATA` JSON shape, the 5 minimal render functions (`renderBracketsViewer`, `renderVue`, `renderJqBracket`, `renderReact`, `renderCssOnly`), the CSS for each visual style, and the CDN URLs that actually load + render.
- `references/vercel-single-html-deploy.md` — single-HTML + Vercel deploy recipe (no build, hotfix-deploy cycle, pre-deploy validation, token handling). For when the user wants `*.vercel.app` instead of `*.github.io`.
- `references/dist-orphan-gh-pages-deploy.md` — bundler `dist/` → orphan `gh-pages` branch recipe for Vite/PixiJS/Three.js/esbuild/CRA SPAs. Covers orphan-branch .gitignore pitfall, REST API Pages enable, `.nojekyll` requirement, 1-5 min propagation, worked example from `sigco3111/hermes-control-room` (2026-08-04).

For the Web-Component-specific patterns (shadow DOM, scroll-snap, IntersectionObserver, SVG overlays, paper-fold pages, equal-width grids), see the companion skill `vanilla-interactive-component` (software-development), which carries the verified Playwright scaffold (`scripts/verify-shadow-component.py`) and the deduped pitfall list.

## Vercel + inline-script single-HTML variant (2026-08-03, sigco3111/clipboard-history 실측)

When the user wants a tiny **standalone HTML file** (not a Web Component) — full-page app, not embeddable tag — and prefers Vercel over GitHub Pages, this is the recipe. Same principle (no build, no framework, no node_modules), different packaging.

**Differences from the GitHub Pages pattern above:**

| | Pages pattern | Vercel + HTML pattern |
|---|---|---|
| Module | ES module + `<my-tag>` | All in one `<script>` block (no module) |
| CSS | Often shadow DOM or global | All in one `<style>` block |
| Deploy | `gh api /pages` (3-step) | `vercel deploy --prod --yes` (1-step) |
| Domain | `*.github.io/<name>/` | `*.vercel.app` (instant) + custom domain |
| VCS | GitHub Pages auto-builds on push | Vercel auto-deploys on push (if GitHub integration) or via CLI |
| Repo size | 1 file + README | Same |
| User expectation | Embeddable / shareable | Full standalone web app |

### Project layout

```
~/work/<name>/
├── index.html              # everything: HTML + CSS + JS inline
├── README.md               # quick start, what it does
├── LICENSE                 # MIT (or your choice)
├── vercel.json             # 1-line static build config
└── .gitignore
```

**`vercel.json` is a 1-liner** for static-only sites:

```json
{
  "buildCommand": null,
  "outputDirectory": ".",
  "framework": null
}
```

That's it. Vercel serves the root, no build step. Push to main → auto-deploy via Vercel GitHub integration, OR deploy via CLI:

```bash
TOKEN=$(cat ~/.vercel_token)  # ~/.vercel_token: plain text, chmod 600, Vercel CLI token
VERCEL_TOKEN="$TOKEN" vercel deploy --prod --yes
```

**`vercel.json` rewrites pattern** (for SPA with custom routes):

```json
{
  "rewrites": [{ "source": "/(.*)", "destination": "/index.html" }]
}
```

This catches 404s on hard refreshes for any URL path → serves index.html → app handles routing client-side.

### Hotfix-deploy cycle (the speed advantage)

**The killer feature of this pattern: ship a fix, see it live, in <30 seconds.** No build, no PR review, no CI.

```
1. Edit index.html
2. (optional but recommended) `node -e "new Function(<script content>)"` syntax check
3. `git add -A && git commit -m "fix: ..."` (or skip commit, deploy directly)
4. `VERCEL_TOKEN="$TOKEN" vercel deploy --prod --yes`
5. Verify: `curl -sI https://<alias>.vercel.app | head -1` → 200
6. User refreshes browser (Cmd+Shift+R for hard refresh)
```

For 5+ rapid iterations on a broken app, this beats any PR/CI workflow. The trade-off is **no review gate** — accept the risk for a personal project, don't use it for shared/team code.

**Vercel auto-aliases** the first deployment to `<project>-<random-hash>.vercel.app` and the second+ to a stable `<project>-<rand>.vercel.app`. To get a clean `<project>-three.vercel.app` URL, do the first manual deploy via `vercel deploy --prod --yes`, then set the alias via Vercel dashboard or `vercel alias set <deployment-url> <alias>`.

**Token caveat**: Vercel tokens are account-scoped, not project-scoped. `~/.vercel_token` is a single credential that can deploy ANY project on the user's account. Treat as production-grade secret. **Do NOT log the token value** in commit messages or notes — only reference its path.

### Pre-deploy HTML/JS validation (must-do)

Single-HTML apps are one mistake away from a totally broken site. The 3 fast checks before every `vercel deploy`:

```bash
# 1) Pull the <script> block and run a JS syntax check
node -e "
const fs = require('fs');
const html = fs.readFileSync('index.html', 'utf-8');
const m = html.match(/<script>([\s\S]*?)<\/script>/);
if (m) {
  try { new Function(m[1]); console.log('JS syntax OK'); }
  catch (e) { console.log('JS ERROR:', e.message); process.exit(1); }
} else { console.log('no <script> block'); }
"

# 2) Count critical keywords — quick smoke test that deployment actually got the right content
grep -c "<critical-keyword>" index.html

# 3) After deploy, fetch the live URL and re-grep
curl -s https://<alias>.vercel.app/ | grep -c "<critical-keyword>"
# Both should match. If local N != live N, either cache or wrong commit.
```

**The 2026-08-03 clipbout-history hotfix that this would have caught**: a duplicate `let lastImageHash` declaration caused a JS SyntaxError, which broke the entire script. All UI (tabs, capture button, search) stopped working. A 5-second `new Function()` syntax check before deploy would have caught it. See "Pitfalls" §duplicate-declared-var below.

### When to use this variant

- User wants a **full-page web app**, not an embeddable component
- User mentions **"deploy", "vercel", "live demo"** without specifying pages
- The app needs to work as `https://<thing>.vercel.app` standalone (no surrounding site)
- Hot-iteration is the priority (user reports "버그 수정 했음. 다시 배포해줘" multiple times in a row)
- Single-file is feasible (no big asset pipeline)

### When NOT to use this variant

- App needs SSR, server-side data, or auth → use Vercel + framework (Next.js, SvelteKit)
- App has 5+ large JS files → use Vite/Webpack build + Pages
- User wants embeddable `<my-tag>` in other sites → Pages + ES module pattern
- User is on Pages-only constraint (no Vercel account)

## When NOT to update this skill

- Skip update when the new learning is about a specific widget's *content* (e.g., "always sort teams alphabetically"). That's an in-component comment.
- Skip update when the user just wanted a tweak and didn't change the workflow. Tiny CSS nudges don't earn a skill edit.