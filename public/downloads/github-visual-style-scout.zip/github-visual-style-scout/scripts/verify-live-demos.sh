#!/usr/bin/env bash
# verify-live-demos.sh
# 2026-08-04 verified — 7개 후보 라이브 데모 URL 일괄 HTTP 200 + HTML body keyword 검사
#
# Usage:
#   ./scripts/verify-live-demos.sh
#   또는 source 후 verify_url "name" "url" 호출

set -euo pipefail

# 후보 목록 (저장소 | URL | 라벨)
declare -a CANDIDATES=(
  "Gaurav2693/ai-office|http://skill-deploy-qmm7droauc.vercel.app/|Vercel 3D isometric"
  "askmojo/moltcraft|https://moltcraft.xyz|Moltcraft npm"
  "victorqribeiro/isocity (homepage)|https://victorribeiro.com/isocity|isocity 베이스"
  "victorqribeiro/isocity (gh-pages)|https://victorribeiro.github.io/isocity/|isocity 보조"
  "elchininet/isometric|https://elchininet.github.io/isometric/|elchininet SVG"
  "Hafaux/pixi-framework|https://pixi-framework.onrender.com/|pixi-fw canvas"
)

verify_url() {
  local name="$1"
  local url="$2"
  local label="$3"

  local code size has_canvas has_pixi has_three has_phaser title

  # HEAD 먼저 시도 (가벼움)
  code=$(curl -s -o /dev/null -w "%{http_code}" -L \
    -A "Mozilla/5.0 (Macintosh)" --max-time 15 "$url" || echo "000")

  if [[ "$code" == "200" ]]; then
    # body 받기 + keyword 검사
    local body
    body=$(curl -s -L -A "Mozilla/5.0 (Macintosh)" --max-time 15 "$url" || echo "")
    size=$(echo -n "$body" | wc -c | tr -d ' ')

    # keyword 검사 (lowercase)
    local lower
    lower=$(echo "$body" | tr '[:upper:]' '[:lower:]')
    has_canvas="false"
    has_pixi="false"
    has_three="false"
    has_phaser="false"

    [[ "$lower" == *"<canvas"* ]] && has_canvas="true"
    [[ "$lower" == *"pixi"* ]] && has_pixi="true"
    [[ "$lower" == *"three"* ]] && has_three="true"
    [[ "$lower" == *"phaser"* ]] && has_phaser="true"

    # title 추출
    title=$(echo "$body" | grep -oE '<title>[^<]*</title>' | head -1 | sed 's/<title>//;s/<\/title>//' | head -c 80)
    [[ -z "$title" ]] && title="(no title)"

    echo "✓ $name"
    echo "    URL: $url"
    echo "    HTTP $code | ${size} bytes | canvas=$has_canvas pixi=$has_pixi three=$has_three phaser=$has_phaser"
    echo "    Title: $title"
  else
    echo "✗ $name (HTTP $code)"
    echo "    URL: $url — DEAD, exclude or mark as (로컬 설치 필요)"
  fi
  echo ""
}

main() {
  echo "=== Live Demo URL Verification (08-04 batch) ==="
  echo ""

  for entry in "${CANDIDATES[@]}"; do
    IFS='|' read -r name url label <<< "$entry"
    verify_url "$name" "$url" "$label"
  done

  echo "=== Summary ==="
  echo "If any HTTP != 200, exclude from final report or mark as 'local install required'."
  echo "Keyword hits (canvas/pixi/three/phaser) hint at rendering tech."
}

main "$@"
