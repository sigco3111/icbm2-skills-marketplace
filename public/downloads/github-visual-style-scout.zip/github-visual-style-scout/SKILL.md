---
name: github-visual-style-scout
description: Find GitHub OSS projects to copy visual style from.
tags: [github, visual, scout, reference, design-inspiration, borrow-style]
---

# GitHub Visual-Style Scout

Class-level workflow for the **look-and-borrow phase**: scanning GitHub to find open-source projects whose **visual style** is close enough to copy patterns from into your own project. **No fork, no PR, no Korean translation work** — the goal is reference inspiration for design (rooms, characters, decoration, dashboards, animations).

## Reference docs

- `references/2026-08-04-isometric-office-bank.md` — 검증된 isometric office / control room / dashboard 15개 (재실행 불필요)
- `references/visual-closeness-matrix.md` — Twin Lab 룩 차용 매트릭스 + 컴포넌트별 추천 차용처
- `references/visual-genre-query-bank.md` — isometric / pixel / 2.5D / dashboard 시각 스타일 검색 쿼리 30+

## When to use

- User: "GitHub에서 isometric office 스타일 OSS 찾아줘 (참고용)"
- User: "이런 룩(control room, 2.5D dashboard, pixel office) 차용할 만한 거 있을까?"
- User: "내 프로젝트 룩이 처참한데, 오픈소스 참고할 만한 거 10~15개"
- User: "이 라이브러리/엔진 말고 비슷한 룩 가진 게임/앱 좀"
- User: "Find OSS projects to copy visual style from"

This skill **ends** when you have a ranked list of 10-15 candidates with **TOP 5 detailed + live demo URLs verified + component-borrow matrix**. Unlike `github-game-candidate-scouting`, there is **no fork/PR follow-up** — the user takes the inspiration back to their own project.

## Critical divergence from `github-game-candidate-scouting`

| Phase | fork+localize scout | **visual-style scout (this skill)** |
|-------|---------------------|--------------------------------------|
| Goal | Find repos to **fork + translate + PR** | Find repos to **look at + borrow patterns from** |
| Phase 0 exclude | User's previous forks | **Target project itself** (don't recommend the project the user is trying to look like) |
| Phase 3 dimensions | Differentiation, build ease, ko gap, i18n readiness, playability | **Visual closeness, borrowable component count, live demo quality, license clarity, activity** |
| Phase 4 ideation | First PR scope | **Component borrow matrix** (which file/concept to copy into user's project) |
| Phase 5 report | Top 3-5 + first PR | **Top 5 detailed + 10 bonus + 3 live demo URLs + component borrow matrix** |
| License strictness | High (must allow fork) | Medium (visual style reference OK even with NOASSERTION, just don't copy code verbatim) |
| i18n focus | Core | **Irrelevant** (we're not translating) |
| Build verification | Critical (must build) | **Optional** (live demo URL or screenshot is enough) |

## Phase 0 — Project-Style Exclude (30 sec)

사용자가 **이미 따라하려고 하는 프로젝트 = 추천 금지**. 매 세션 첫 30초에 1회 실행:

```bash
# 1) 사용자가 작업 중인 프로젝트의 컨셉 단서 추출
ls /Users/mac/work | while read dir; do
  if [ -f "/Users/mac/work/$dir/README.md" ]; then
    head -5 "/Users/mac/work/$dir/README.md" | grep -iE "isometric|pixel|control.room|2.5d|dashboard|office" \
      && echo "↑ $dir matches visual-style query"
  fi
done

# 2) 사용자가 비교 대상으로 언급한 URL/저장소
# (직전 세션 컨텍스트에서 추출 — session_search 사용)
```

**08-04 실증**: 사용자가 Twin Lab (https://twin.quantlabnote.com/guest) 을 "1:1 차용 시도했지만 디테일이 부족"하다고 함 → Twin Lab 자체는 추천 안 함. 다른 isometric office 프로젝트 15개 발굴이 목표.

## Phase 1 — Multi-Query Batched Search (5 min)

기존 `github-game-candidate-scouting`와 동일한 gh search 메커니즘. 다만 **시각 단서**에 집중:

```bash
# ✅ "visual style" 단서 포함 (게임 단독 아님)
"isometric+office"
"isometric+control+room"
"pixel+office"
"2.5d+dashboard"
"isometric+dashboard"
"isometric+city+builder"        # 룩 차용에 좋은 베이스
"phaser+isometric"
"pixi.js+isometric+game"
"isometric+building+simulator"
"control+room+visualization"
"operation+center+game"
"tower+tycoon+isometric"
"sims+clone+open+source"        # 룩 차용 베이스
"css+isometric"                  # SVG/CSS 룩 차용
"svg+isometric"
"react+isometric+grid"
"three.js+isometric+room"
"isometric+tilemap+pixi"
"isometric+typescript"
"isometric+character+sprite"    # 캐릭터 룩 차용
"isometric+tilemap+kenney"      # Kenney 텍스처
"isometric+2.5d+web"

for q in "isometric+office" "isometric+control+room" "2.5d+office+game" \
         "pixi.js+isometric" "phaser+isometric+game" "isometric+city+builder" \
         "isometric+building+simulator" "isometric+dashboard"; do
  echo "=== $q ==="
  gh search repos "$q" --limit 5 \
    --json fullName,description,stargazersCount,language,license,pushedAt,url
done
```

**Pitfall 14 / 27 (검색 함정)** 재사용:
- `gh search repos` CLI는 OR/NOT 5+ 시 422
- `api.github.com/search/repositories` 12+ 연속 호출 시 secondary rate limit 403
- **방어**: batch 8-12개씩, 0 결과면 batch 분할 + sleep

## Phase 2 — Initial Triage (2 min)

Dedupe by `full_name`. Discard:

- Archived repos
- **Pure libraries (no demo/screenshot)** — visual style scout needs a look, not just code
- 0 stars / 0 forks
- Tutorials (Unity FPS-Sample, Brackeys series, etc.)
- No activity in 6+ months
- **Phase 0 exclude 리스트에 매치되는 후보** (재추천 금지)

**Keep 10-15 with a visual look** (live demo, screenshot, or GIF).

## Phase 3 — 5-Dimension Visual Closeness Matrix

기존 fork scout의 5-dimension과 **완전히 다른** 차원 사용:

| Dimension | Weight | What to check |
|---|---|---|
| **Visual Closeness** | 35% | How close is the look to user's target? Compare README screenshots + live demo. Same isometric angle? Same color palette? Same character style? Same room layout pattern? |
| **Borrowable Component Count** | 25% | How many discrete visual elements can be lifted? (rooms, characters, decoration, dashboard, animation) Each = 1 component |
| **Live Demo Quality** | 15% | Live URL works? HTTP 200? Renders immediately? Or require local install? |
| **License Clarity** | 10% | MIT/Apache = can copy patterns freely. NOASSERTION = look but don't lift code verbatim. GPL = reference only. |
| **Activity (push within 6 mo)** | 15% | Active = modern best practices, updated patterns. Stale = outdated conventions. |

**Formula**: `0.35*visual + 0.25*components + 0.15*demo + 0.10*license + 0.15*activity`

**Critical**: **Visual Closeness는 vision_analyze로 실측**. README의 screenshot URL을 `vision_analyze`로 보내서 Twin Lab(또는 사용자 타겟 룩)과 비교.

```python
# vision_analyze로 visual closeness 점수 (1-5)
vision_analyze(
    image_url="https://raw.githubusercontent.com/OWNER/REPO/main/docs/images/screenshot.png",
    question="이 이미지가 isometric office 룩인지 1-5점. 캐릭터, 방, dashboard, decoration 등 Twin Lab과 비슷한 부분 강조."
)
```

## Phase 4 — Component Borrow Matrix (per candidate)

기존 scout의 "First PR Scope" 대신, **각 후보에서 어떤 컴포넌트를 우리 프로젝트로 차용할 수 있는지** 매트릭스:

| Twin Lab 컴포넌트 | 차용 소스 | 차용 방법 |
|-------------------|-----------|-----------|
| 방(room) 배치 로직 | W17ant/Claude-Office `src/rooms.ts` | 박스형 isometric → 우리 PixiJS Graphics |
| 캐릭터 SVG sprite | Claude-Office `docs/images/*.png` | PNG 그대로 또는 SVG 변환 |
| 빌딩 = 데이터 패널 | askmojo/moltcraft | 클릭한 빌딩에 dashboard popover |
| Decoration (책상/모니터/화분) | elchininet/isometric (SVG path) | SVG → Pixi Graphics 변환 |
| Day/Night cycle | W17ant/Claude-Office `src/daylight.ts` | tint + lighting |
| 다중 모델 color coding | honorstudio/claude-ville | color tokens |
| Isometric 베이스 텍스처 | victorqribeiro/isocity Kenney CC0 | Kenney 텍스처 키트 다운로드 |
| CSS-only fallback | elchininet/isometric-css | preview/loading state |

**차용 시 주의**:
- **MIT/Apache 코드**: 파일 단위 차용 + 라이선스 표기 OK
- **NOASSERTION 자산**: 룩(스타일)만 참고, 코드 verbatim 복사 금지
- **CC-BY-NC 자산**: 비상업 사용만 OK
- **이미지/스프라이트**: 각 repo의 LICENSE + `assets/LICENSE.md` 둘 다 확인 (Pitfall 2b 재사용)

## Phase 5 — Final Report (4 sections)

```markdown
## 🏆 TOP 5 (가장 추천)
- 각 후보: 시각적 강점 2-3줄 + Twin Lab 룩과 비슷한 부분 + 우리 프로젝트 적용 가능성 (1-5⭐)

## 📋 보너스 10개
- 한 줄 요약 표 (저장소 | ⭐ | 라이선스 | 스택 | 한 줄)

## 🎯 바로 차용 가능 라이브 데모 3개 (URL)
- URL + 1줄 설명 + Twin Lab이 보여줘야 할 장면과의 매핑

## 💡 결론 및 차용 제안
- 어떤 프로젝트가 가장 Twin Lab 룩에 가까운가 (1-2-3순위)
- 컴포넌트별 차용처 매트릭스
- 즉시 실행 가능한 다음 단계 (예: "W17ant/Claude-Office 클론 → src/rooms.ts 읽기")
```

**Format rationale**: 사용자가 10~15개 + TOP 5 + 즉시 차용 데모 + 컴포넌트 매트릭스를 원함. 4개 섹션 고정.

## Pitfalls (encountered in real sessions)

1. **🎨 visual-style scout ≠ fork scout** — 가장 큰 함정. Phase 0-2 메커니즘은 같지만 Phase 3-5는 완전히 다름. "i18n readiness 점수" 따위를 그대로 쓰면 무의미. Phase 3을 5-dimension visual closeness matrix로 교체 필수.

2. **README screenshot만 보고 점수 매기지 말 것 (08-04 verified)** — Twin Lab과 비슷한 후보가 5개 넘게 나옴. **vision_analyze로 실제 이미지 분석해서** visual closeness 점수 산정. README description만으로 "isometric office 룩" 판단하면 50% 오판.

3. **live demo URL HTTP 200 검증 필수 (08-04 verified)** — 7개 후보 중 1개 (gh-pages 보조 링크) 404. **모든 homepage URL은 curl로 HTTP 200 + HTML body size 확인**:
   ```python
   for name, url, label in demos:
       req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0 (Macintosh)'})
       with urllib.request.urlopen(req, timeout=15) as r:
           code = r.status
           content = r.read().decode('utf-8', errors='ignore')
       has_canvas = '<canvas' in content.lower()
       print(f"  {name}: HTTP {code} | {len(content)} bytes | canvas={has_canvas}")
   ```
   404 = 추천에서 제외 또는 "(로컬 설치 필요)" 명시.

4. **Electron 의존성은 무시하고 src/만 차용 (08-04 verified)** — W17ant/Claude-Office 같은 Electron 프로젝트는 브라우저만 쓸 우리에겐 "src/ 폴더만 봐도 80% 차용 가능". **package.json에서 electron 의존성 발견 시** "브라우저 차용: src/만" 메모.

5. **NOASSERTION 자산은 룩만 참고 (08-04 verified)** — visual-style scout은 fork와 달리 라이선스가 느슨해도 OK. 단, **코드 verbatim 복사 금지**. 룩(스타일)만 보고 우리 코드로 다시 구현.

6. **Twin Lab 자체는 추천 금지 (08-04 verified)** — 사용자가 "Twin Lab 1:1 차용 시도" → Twin Lab은 목표/참조 대상, 우리가 발굴할 후보 아님. **Phase 0에서 명확히 exclude**.

7. **두 단계 visual closeness 측정** — (a) vision_analyze로 README screenshot 평가 + (b) live demo URL 직접 fetch해서 HTML body + canvas/svg/pixi/three/phaser keyword 검사. 둘 다 OK = high score.

8. **컴포넌트 차용 매트릭스 — 한 줄에 1 컴포넌트** — "rooms + characters + dashboard + animation" 같이 뭉뚱그리지 말 것. 각 차용처마다 1개 컴포넌트 1행.

9. **다음 단계는 4단계 이내** — 보고서 끝에 "다음 4단계" 명시:
   1. 1순위 후보 클론 + src/ 읽기
   2. SVG isometric 라이브러리 npm install
   3. 라이브 데모 5분 시연
   4. Kenney 텍스처 다운로드
   너무 많으면 사용자가 overwhelmed.

## Reference

- `references/2026-08-04-isometric-office-bank.md` — 검증된 15개 isometric office 후보 (W17ant/Claude-Office, askmojo/moltcraft, Gaurav2693/ai-office, honorstudio/claude-ville, victorqribeiro/isocity 등)
- `references/visual-closeness-matrix.md` — Twin Lab 룩 차용 컴포넌트별 매트릭스 (10개 컴포넌트 × 차용 소스)
- `references/visual-genre-query-bank.md` — isometric / pixel / 2.5D / dashboard / control room 시각 스타일 30+ 검색 쿼리
- `scripts/verify-live-demos.sh` — homepage URL 일괄 HTTP 200 검증 + HTML body keyword 검사 (08-04 실측)

## Next steps after scouting

**No fork follow-up** (different from `github-game-candidate-scouting`). User takes inspiration back to their own project. Adjacent skills that may help:

- **`pixijs-v8-pitfalls`** — 우리 프로젝트 자체 (PixiJS v8) 차용 작업 시
- **`github-cli`** — 1순위 후보 클론 시
- **`catchup`** — 보고서 30일 후 "어디까지 했지?" 컨텍스트 복구
