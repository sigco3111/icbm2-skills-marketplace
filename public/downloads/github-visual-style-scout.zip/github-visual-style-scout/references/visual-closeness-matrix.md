# Twin Lab 룩 차용 — 컴포넌트별 Visual Closeness Matrix

2026-08-04 시각 스타일 스카우팅에서 도출한 Twin Lab 룩 차용 매트릭스. **Twin Lab의 10개 핵심 컴포넌트 × 15개 후보 차용처**. 1개 차용처가 1개 컴포넌트를 담당하도록 매핑 (한 행에 한 컴포넌트).

## Twin Lab 컴포넌트 분해

Twin Lab (https://twin.quantlabnote.com/guest) 의 1:1 차용 시 필요한 10개 컴포넌트:

1. **Isometric 좌표 변환** — (x, y) → (screenX, screenY) 수식
2. **방(room) 배치** — 박스형 isometric 방 시스템
3. **캐릭터 SVG sprite** — AI 에이전트 인물 비주얼
4. **빌딩 = 데이터 패널** — 클릭한 개체에 dashboard popover
5. **Decoration (책상/모니터/화분)** — 방 안 furniture
6. **Day/Night cycle** — 시간대별 광원/색상 변화
7. **다중 모델 color coding** — Claude/Codex/Gemini 구분
8. **Isometric 베이스 텍스처** — tile/road/tree
9. **CSS-only fallback** — PixiJS 로딩 전 preview
10. **이벤트 로그 / chat panel** — Slack-style chatter

## 컴포넌트별 차용처

| # | Twin Lab 컴포넌트 | 차용 소스 (저장소 / 파일) | 차용 방법 | 라이선스 | 차용 비용 |
|---|-------------------|---------------------------|-----------|----------|-----------|
| 1 | Isometric 좌표 변환 | `victorqribeiro/isocity` (Canvas) | (x,y)→(screenX,screenY) 수식 1개 | MIT | 1시간 |
| 2 | 방(room) 배치 | `W17ant/Claude-Office` `src/rooms.ts` (21KB) | 박스형 isometric → 우리 PixiJS Graphics | MIT | 2-3시간 |
| 3 | 캐릭터 SVG sprite | `W17ant/Claude-Office` `docs/images/*.png` (27명) | PNG 그대로 또는 SVG 변환 | MIT | 30분 |
| 4 | 빌딩 = 데이터 패널 | `askmojo/moltcraft` (Vanilla JS) | 클릭한 빌딩에 dashboard popover | MIT | 2시간 |
| 5 | Decoration (책상/모니터/화분) | `elchininet/isometric` (SVG path 라이브러리) | SVG → Pixi Graphics 변환 | Apache-2.0 | 3-4시간 |
| 6 | Day/Night cycle | `W17ant/Claude-Office` `src/daylight.ts` (2.6KB) | tint + lighting | MIT | 1시간 |
| 7 | 다중 모델 color coding | `honorstudio/claude-ville` | color tokens (Claude=🟣, Codex=🟢, Gemini=🔵) | MIT | 30분 |
| 8 | Isometric 베이스 텍스처 | `victorqribeiro/isocity` Kenney 텍스처 (CC0) | Kenney 텍스처 키트 다운로드 | CC0 | 1시간 (다운로드) |
| 9 | CSS-only fallback | `elchininet/isometric-css` | PixiJS 렌더 전 preview/loading | Apache-2.0 | 2시간 |
| 10 | 이벤트 로그 / chat panel | `W17ant/Claude-Office` `src/events.ts` (11.8KB) | Slack-style chatter | MIT | 2시간 |

## 1순위 차용처 종합 추천

**W17ant/Claude-Office (56⭐, MIT)** — 10개 컴포넌트 중 4개를 단독 제공:
- #2 (방 배치)
- #3 (캐릭터 sprite)
- #6 (Day/Night)
- #10 (이벤트 로그)

**askmojo/moltcraft (32⭐, MIT)** — 1개:
- #4 (빌딩 = 데이터 패널)

**victorqribeiro/isocity (3246⭐, MIT)** — 2개:
- #1 (좌표 변환)
- #8 (베이스 텍스처)

**elchininet/isometric + isometric-css (Apache-2.0)** — 2개:
- #5 (SVG decoration)
- #9 (CSS fallback)

**honorstudio/claude-ville (13⭐, MIT)** — 1개:
- #7 (color coding)

## Twin Lab 차용 점수 (5-Dimension Visual Closeness)

| 후보 | Visual (35%) | Components (25%) | Demo (15%) | License (10%) | Activity (15%) | Total |
|------|--------------|------------------|------------|---------------|----------------|-------|
| W17ant/Claude-Office | 5/5 | 4/10 | 2/5 (로컬) | 5/5 (MIT) | 5/5 (1개월) | **4.2** |
| askmojo/moltcraft | 4/5 | 1/10 | 5/5 (npm) | 5/5 (MIT) | 4/5 (6개월) | **3.5** |
| Gaurav2693/ai-office | 5/5 (3D voxel) | 3/10 | 5/5 (Vercel) | 5/5 (MIT) | 5/5 (4개월) | **4.5** |
| honorstudio/claude-ville | 4/5 | 1/10 | 3/5 (Widget) | 5/5 (MIT) | 5/5 (4개월) | **3.4** |
| victorqribeiro/isocity | 3/5 (도시) | 2/10 | 5/5 (live) | 5/5 (MIT) | 2/5 (2년+) | **3.0** |

## Twin Lab 차용 즉시 실행 4단계

1. **W17ant/Claude-Office 클론** → `src/rooms.ts` + `src/daylight.ts` + `src/assets.ts` 코드 읽고 우리 PixiJS v8로 이식 (1-2일)
2. **elchininet/isometric `npm install`** → SVG isometric path 변환 함수 차용 (1일)
3. **Gaurav2693/ai-office 라이브 데모 5분 시연** → Twin Lab이 보여줘야 할 장면 구체화 (5분)
4. **victorqribeiro/isocity Kenney 텍스처 다운로드** → 우리 `assets/`에 추가 (30분)

## Twin Lab 자체는 차용처 아님

Twin Lab (https://twin.quantlabnote.com/guest) 은 **참조 목표지 fork/차용 대상이 아님**. 우리는 Twin Lab과 비슷한 룩을 가진 다른 OSS 15개를 발굴해서 Twin Lab의 룩을 1:1 재현하는 것이 목표. Twin Lab 자체를 추천하지 말 것 (Phase 0 exclude).
