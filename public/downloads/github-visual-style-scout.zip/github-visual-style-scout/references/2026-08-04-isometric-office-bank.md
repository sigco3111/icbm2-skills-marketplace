# 2026-08-04 검증된 Isometric Office / Control Room / Dashboard 15개

Hermes Control Room (PixiJS v8 + React 19 + zustand, 2026-08-04) 프로젝트의 Twin Lab 룩 차용을 위해 발굴한 15개 OSS 후보. 검색어 16개 배치 (`isometric office / control room / pixel / 2.5d / dashboard / phaser / pixi / three.js / city builder / office simulator` 등), dedupe 후 40+ 후보 → 15개 선정. 라이브 데모 URL 모두 HTTP 200 검증 완료.

## TOP 5

### 1. W17ant/Claude-Office (56⭐, MIT, TypeScript) — 가장 강력 추천
- **URL**: https://github.com/W17ant/Claude-Office
- **데스크립션**: *"A pixel art virtual office that visualizes your AI agents working in real-time"* — Twin Lab과 컨셉 거의 동일
- **스택**: React 18 + TypeScript + Vite + Electron + Express + WebSocket
- **라이브**: 로컬 설치 (Claude Code hooks 필요). 데모 이미지: `docs/images/dunder-mifflin-day.png`
- **차용 자산**:
  - `src/App.tsx` 79KB (룸 + 캐릭터 + 이벤트 통합 패턴)
  - `src/rooms.ts` 21KB (방 배치 로직)
  - `src/daylight.ts` 2.6KB (day/night cycle)
  - `src/assets.ts` 6.4KB (sprite 매니저)
  - `src/events.ts` 11.8KB (Slack-style chatter)
  - `docs/images/michael-scott.png` 등 27명 캐릭터 sprite
  - `docs/THEME_SWAP.md` (Dunder Mifflin 테마 토글 = 룩 스왑 패턴)
- **Twin Lab 차용 점수**: ⭐⭐⭐⭐⭐ (5/5)
- **주의**: Electron 의존성 — 브라우저만 쓸 우리엔 `src/` 코드만 차용

### 2. askmojo/moltcraft (32⭐, MIT, Vanilla JS) — 가장 가벼운 차용처
- **URL**: https://github.com/askmojo/moltcraft
- **데모 URL**: https://moltcraft.xyz (HTTP 200, 18KB HTML) / npm: `npx @ask-mojo/moltcraft`
- **데스크립션**: *"Isometric pixel-art dashboard for Moltbot"*
- **스택**: Vanilla JS + Node.js + Express + WebSocket (의존성 거의 없음)
- **차용 자산**:
  - Minecraft 스타일 isometric world (픽셀 블록 + 캐릭터 + 빌딩)
  - 클릭 가능한 빌딩 = 데이터 패널 (Twin Lab의 8개 방 = 8개 빌딩 매핑)
    - 🕐 Clock Tower = cron jobs · ⛏️ Mine = token usage · 🏰 Barracks = skills · 📡 Command Center
  - Day/night cycle + weather + particles
  - Voice TTS/STT 통합 (ElevenLabs + 브라우저 Speech Recognition)
  - Channel status indicators (Telegram/WhatsApp/Slack)
- **Twin Lab 차용 점수**: ⭐⭐⭐⭐⭐ (5/5) — 우리 PixiJS v8에 가장 이식 쉬움

### 3. Gaurav2693/ai-office (44⭐, MIT, JavaScript) — 3D isometric 변주
- **URL**: https://github.com/Gaurav2693/ai-office
- **데모 URL**: http://skill-deploy-qmm7droauc.vercel.app/ (HTTP 200, "the-office" 페이지)
- **데스크립션**: *"A miniature isometric 3D office where 9 AI agents work, walk, talk, and hold meetings. Built with React 19 + Three.js."*
- **스택**: React 19 + Three.js r183 + Vite 8 (3D isometric voxel)
- **차용 자산**:
  - 9명 AI agent 책상/워터쿨러/미팅룸 3-state FSM
  - Drag to orbit · Scroll to zoom · Slide time bar · LIGHTS OFF (cyberpunk) · 'i' 키 info panel
  - 화면마다 다른 content scrolling
  - Water cooler에서 만남 → 스폰티니어스 대화
  - Glass-walled conference room
- **Twin Lab 차용 점수**: ⭐⭐⭐ (3/5) — 3D Three.js라 직접 이식 어렵지만 인터랙션/UX/시각 장면 디자인은 80% 차용 가능

### 4. honorstudio/claude-ville (13⭐, MIT, JavaScript) — 다중 CLI 에이전트 통합
- **URL**: https://github.com/honorstudio/claude-ville
- **데모**: macOS Desktop Widget 빌드 (네이티브 `.app` + WidgetKit)
- **데스크립션**: *"Universal AI Coding Agent Visualization Dashboard — Claude Code + Codex CLI + Gemini CLI 통합"*
- **스택**: Vanilla JS + macOS WidgetKit + Zero dependencies
- **차용 자산**:
  - World Mode (isometric village) + Dashboard Mode (card grid) 듀얼 뷰 토글
  - Provider별 색상 coding (Claude=🟣 Purple, Codex=🟢 Green, Gemini=🔵 Blue)
  - Live stream from local CLI session logs (`~/.claude/`, `~/.codex/`, `~/.gemini/`)
  - macOS Desktop Widget 구조
- **Twin Lab 차용 점수**: ⭐⭐⭐⭐ (4/5) — `claudeville/index.html` 11.6KB + `server.js` 18.6KB 직접 차용

### 5. victorqribeiro/isocity (3246⭐, MIT, JavaScript) — 베이스 isometric 엔진
- **URL**: https://github.com/victorqribeiro/isocity
- **데모 URL**: https://victorribeiro.com/isocity (HTTP 200, canvas 1개, 1131 bytes HTML)
- **데스크립션**: *"A simple isometric city builder in JavaScript"*
- **스택**: Vanilla JS + Canvas (의존성 0, 7년된 검증된 코드)
- **차용 자산**:
  - 검증된 isometric 좌표 변환 (다른 13개 후보의 거의 모든 isometric이 이 패턴 차용)
  - Kenney.nl 텍스처 (CC0) — Twin Lab 룩의 텍스처 즉시 차용
  - 타일 + 빌딩 + 트리 + 도로 + 구역
- **Twin Lab 차용 점수**: ⭐⭐⭐ (3/5) — Canvas 기반이라 PixiJS로 이식 필요. **isometric 좌표 변환 수식 + 텍스처 키트**는 거의 모든 룩의 기초

## 보너스 10개

| # | 저장소 | ⭐ | 라이선스 | 스택 | 한 줄 |
|---|--------|----|----------|------|-------|
| 6 | breslavsky/openclaw-pixel-world | 11 | MIT | TS + WebSocket | "Pixel-game command center for live AI agent operations" — OpenClaw 게이트웨이 의존 |
| 7 | talamar49/virtual-office-poc | 0 | NOASSERTION | HTML + Vite + WS | "Isometric pixel art AI team dashboard" — OpenClaw virtual office, Hebrew/EN i18n 내장 |
| 8 | agustinafassina/AI.Agents.Office.Map.WebGL | 1 | NOASSERTION | TS + WebGL | "Isometric office diorama rendered with WebGL" — Twin Lab과 매우 유사한 룩 |
| 9 | jand-2/MapofAgents | 2 | Apache-2.0 | Swift + SwiftUI | "Native SwiftUI control room for Codex App Server" — macOS 네이티브 |
| 10 | elchininet/isometric | 233 | Apache-2.0 | TypeScript | **"Lightweight JS library to create isometric projections using SVGs"** — Twin Lab SVG decoration 즉시 차용 (라이브: https://elchininet.github.io/isometric/) |
| 11 | elchininet/isometric-css | 74 | Apache-2.0 | TypeScript | "Build isometric projections through declarative HTML attributes" (라이브: https://elchininet.github.io/isometric-css/) |
| 12 | colincode0/github-readme | 64 | NOASSERTION | Python + SVG | "Isometric 3D contributions graph" — SVG isometric 차트 패턴 |
| 13 | Hafaux/pixi-framework | 45 | MIT | TypeScript + PixiJS + Vite | **"Simple 2D Game Framework for PixiJS using Vite"** — 우리 PixiJS v8과 직접 매칭 (라이브: https://pixi-framework.onrender.com/) |
| 14 | mizy/dark-isle | 0 | NOASSERTION | TS + Phaser3 | "2.5D isometric game engine built with Phaser3" — Phaser → PixiJS 마이그레이션 참고 |
| 15 | GeorgeQLe/iso-room-three | 0 | MIT | TS + Three.js | "Three.js isometric room engine and accessible React editor" — Twin Lab editor 패턴 |

## 라이브 데모 검증 결과 (08-04)

| 후보 | URL | HTTP | bytes | canvas | 비고 |
|------|-----|------|-------|--------|------|
| Gaurav2693/ai-office | http://skill-deploy-qmm7droauc.vercel.app/ | 200 | 460 | false | 5분 시연 추천 |
| askmojo/moltcraft | https://moltcraft.xyz | 200 | 18,164 | false | npm install 가능 |
| victorqribeiro/isocity (homepage) | https://victorribeiro.com/isocity | 200 | 1,131 | true | 베이스 |
| victorqribeiro/isocity (gh-pages) | https://victorribeiro.github.io/isocity/ | **404** | - | - | 보조 링크 죽음 — homepage만 사용 |
| elchininet/isometric | https://elchininet.github.io/isometric/ | 200 | 1,976 | false | SVG 기반이라 canvas 없음 |
| Hafaux/pixi-framework | https://pixi-framework.onrender.com/ | 200 | 536 | true | PixiJS canvas |
| W17ant/Claude-Office | (로컬 설치) | - | - | - | Claude Code hooks 필요 |

## 라이선스 분포

- **MIT** (안전, fork OK): 8개 (Claude-Office, ai-office, isocity, isometric, isometric-css, Hafaux/pixi-framework, honorstudio/claude-ville, GeorgeQLe/iso-room-three)
- **Apache-2.0**: 3개 (MapofAgents, elchininet/isometric, elchininet/isometric-css)
- **NOASSERTION** (차용만 OK): 4개 (moltcraft, claude-ville, colincode0, talamar49)
- **GPL-3.0**: 0개 (agricola-city는 우리와 안 맞아 제외)

## 기술스택 분포

- **PixiJS**: 1개 (Hafaux/pixi-framework) — 직접 호환
- **Phaser 3** (PixiJS 기반): 4개 (ClickerTown, daan93/phaser-isometric-demo 등) — 마이그레이션 쉬움
- **Three.js / WebGL**: 4개 (ai-office, agustinafassina, GeorgeQLe, shpowley)
- **Vanilla JS + Canvas/SVG**: 5개 (isocity, moltcraft, claude-ville, colincode0, isometric-css)
- **Electron + React**: 1개 (W17ant/Claude-Office) — src/만 차용
- **Swift/SwiftUI**: 1개 (MapofAgents) — macOS 네이티브 참고
- **CSS-only**: 2개 (elchininet/isometric-css, peter-kimanzi/isometric-steps-effect)
