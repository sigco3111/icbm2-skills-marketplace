# Visual Style Scout — 검색 쿼리 뱅크 (30+)

isometric / pixel / 2.5D / dashboard / control room / office 시각 스타일 검색용. **Phase 1** 에서 8-12개 배치 사용.

## 쿼리 작성 규칙 (07-28 verified)

- **`+` 대신 공백 또는 `+` 둘 다 OK** — `gh search repos`는 URL-encoded 공백 받음
- **broad 쿼리 금지** — `"open source game"` / `"rpg game"` 같은 broad term은 vuejs/tensorflow/opencode/electron 매칭
- **시각 단서 + 도메인** — `"isometric+office"` 같이 visual 단서 + 도메인 결합
- **8-12개 batch 후 dedupe** — full_name 기준 dedupe, 12+ 시 secondary rate limit 403

## Tier 1 — Isometric Office / Control Room (Twin Lab 직결)

```
"isometric+office"
"isometric+control+room"
"isometric+workplace"
"isometric+coworking"
"isometric+meeting+room"
"isometric+boardroom"
"control+room+visualization"
"operation+center+game"
"ncc+1701+bridge+simulator"
```

## Tier 2 — Pixel Art Office / Dashboard

```
"pixel+office"
"pixel+art+workplace"
"pixel+dashboard"
"pixel+art+dashboard"
"8bit+office"
"16bit+office"
"retro+office"
```

## Tier 3 — 2.5D / Isometric Dashboard

```
"2.5d+office+game"
"2.5d+dashboard"
"2.5d+control+room"
"2.5d+visualization"
"isometric+dashboard"
"isometric+monitoring"
"isometric+telemetry"
```

## Tier 4 — Engine-specific (기술스택 매칭)

```
"phaser+isometric+game"        # Phaser 3 = PixiJS 기반이라 마이그레이션 쉬움
"pixi.js+isometric+game"       # 우리 PixiJS v8과 직접 매칭
"pixijs+game"
"three.js+isometric+room"      # 3D isometric 대안
"react+isometric+grid"         # React + isometric
"isometric+tilemap+pixi"       # tilemap 패턴
"isometric+typescript"         # TS 베이스
"css+isometric"                # SVG/CSS 룩 차용
"svg+isometric"
```

## Tier 5 — City / Building / Sim (베이스 룩)

```
"isometric+city+builder"
"isometric+building+simulator"
"isometric+tower+tycoon"
"isometric+tycoon"
"sims+clone+open+source"
"monster+factory+isometric"
"office+simulator"
"factory+isometric"
"workshop+isometric"
```

## Tier 6 — Character / Decoration / Sprite

```
"isometric+character+sprite"
"isometric+sprite+sheet"
"isometric+tilemap+kenney"
"isometric+decoration"
"isometric+prop"
"isometric+furniture"
```

## Tier 7 — AI Agent Visualization (2026 신규 카테고리)

```
"ai+agent+visualization"
"ai+agent+office"
"ai+agent+dashboard"
"isometric+ai+agent"
"claude+code+visualization"
"codex+cli+dashboard"
"gemini+cli+visualization"
"multi+agent+visualization"
"agent+office"
"claude+office"
"codex+office"
"ai+agents+live"
```

## Phase 1 batch script (검증됨)

```bash
queries=(
  "isometric+office"
  "isometric+control+room"
  "2.5d+office+game"
  "pixi.js+isometric"
  "phaser+isometric+game"
  "isometric+city+builder"
  "isometric+building+simulator"
  "isometric+dashboard"
)

for q in "${queries[@]}"; do
  echo "=== $q ==="
  gh search repos "$q" --limit 5 \
    --json fullName,description,stargazersCount,language,license,pushedAt,url
  sleep 1.2  # secondary rate limit 방어
done
```

## 노이즈가 많은 쿼리 (피할 것)

```
"isometric"                    # 너무 broad → 라이브러리 매칭
"2d+game"                      # broad
"open+source+game"             # engine/tutorial 매칭
"javascript+game"              # broad
"rpg+game"                     # broad
"platformer"                   # broad
"tower+defense"                # broad (visual 무관)
"visualization"                # 너무 broad
```

## Pitfall 27 — secondary rate limit 403

12+ 연속 `api.github.com/search/repositories` 호출 시 403. **방어**:
- batch 8-12 query → 결과 0이면 batch 분할 + sleep
- 또는 `gh search repos "keyword" --limit 5` CLI 사용 (secondary limit 별도 풀)
- 1-2분 대기 후 재시도
