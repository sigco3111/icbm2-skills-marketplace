---
name: fork-first-investigation
description: "fork에서 부모 보정 상태를 파악한 뒤 작업 분간. no-op + 이중 보정 방지."
version: 1.0.0
license: MIT
category: software-development
metadata:
  hermes:
    tags: [fork, port, refactor, workflow, upstream-tracking]
    related_skills: [systematic-debugging, ad-hoc-verification]
---

# Fork-First Investigation

**이 스킬은 fork 프로젝트(부모 repo에서 clone한 저장소)에서 부모의 최신 보정 상태를 정확히 파악한 뒤, 부모가 이미 끝낸 일과 내가 새로 할 일을 분간하는 워크플로다.**

README에 적힌 진단이 "unfixed"여도 **코드에 박힌 자세한 코멘트가 그 보정이 끝났음을 가리킬 수 있다**. 그걸 놓치면:
- no-op 패치 (이미 끝난 보정을 다시 함)
- 이중 보정 (양쪽 다 적용돼서 의도와 어긋남)
- 부모만 아는 코드 의도를 깸

본 세션의 핵심 교훈은 **"README 진단 + 코드 상태 검사 + 자가측정 코멘트 확인"** 3축을 모두 거쳐야 한다는 점.

## 핵심 규칙

### 1. fork 시작 시 — README 진단만 믿지 마라. 코드와 코멘트 확인이 1차이다

```bash
# 1) README/CHANGELOG에서 "unfixed"/"known issue"/"open problem" 진단 발췌
grep -E "unfixed|known issue|remains|root cause" README.md CHANGELOG.md

# 2) 그 진단과 관련된 코드/주석 블록을 검색
grep -rn "viewKeyScale\|viewRig\|irradiance" src/ 2>/dev/null
# → 보정 코멘트가 보이면: "the original rig delivered ~20× ... albedo x3.0.098 -> 0.285"

# 3) **코멘트의 마지막 단락**을 정독 — 거기에 "two coupled moves" / "applied" / "shipped" 표시
# 가 있으면 = **이미 끝난 보정**이다
```

### 2. 부모 코드 안에 보정 코멘트가 있는 패턴 — 3가지 식별 신호

**Signal A: 패치 단계가 코멘트에 명시되어 있다**

```
* Two coupled moves, and neither works alone:
*   1. specularIntensity 0.5 -> 0.11
*   2. albedo x3. 0.098 -> 0.285
```

→ 1번과 2번 모두 적용됐는지 코드 값을 grep으로 확인.

**Signal B: 측정값이 표로 박혀있다**

```
*            base albedo   diffuse-only   with spec (shipped)
*   rail          0.0033        L=106            L=192
```

→ 표의 'shipped' 컬럼 = 출시 빌드 상태. 출하 전 L=192가 적혀있으면 그게 정답이고, fork에서는 그게 이미 적용됨.

**Signal C: "이전 라운드는 잘못 접근했다, 이번에는 그 반대" 식의 명시**

```
* Every previous pass fought the same symptom ... by driving albedos DOWN.
* This one measured what was actually on screen and it is the opposite problem.
```

→ "This one"이 **현재 코드를 가리킬 가능성이 매우 높음**. 측정값이 표나 박힌 값으로 지지됨.

### 3. 4가지 결정 — fork 작업의 출발점 정의

조사 끝나면 다음 넷 중 하나:

| 결정 | 의미 | 작업 |
|---|---|---|
| **A. 부모가 끝까지 감** | 부모의 보정이 균형을 회복한 상태가 fork의 출발점 | no 추가 작업, fork는 부모의 자식 |
| **B. 부모는 일부만 끝냄** | 일부 표면/클래스만 보정됨, 나머지는 의도된 미완 | 잔여 보정만 fork에서 완료 |
| **C. 부모는 못 건드림** | README 진단 그대로, 자식에서 처음 작업 | README 진단 그대로 진행 |
| **D. Open Core 공개 — fork가 빌드 자체를 못 함** | 부모 저장소가 의도적으로 일부 비공개 (싱글 플레이 캠페인, 백엔드, 콘텐츠, 일급 패키지의 본체). 공개 쪽은 placeholder만 남아 실행 가능한 코드가 아님 | 자산 보존 + 정직한 README 한계 명시 + 임시 산출물 청소. **빌드 성공으로 보고하지 말 것** |

**판별이 안 되면 A로 보수적으로 시작** — "no-op(자식이 안 함) + 정직한 README"는 항상 합리적인 출발점. 잘못된 B/C 적용이 더 위험.

**D 결정의 식별 신호** (Open Core / 일부 비공개 fork):
- README 또는 `CONTRIBUTING.md`에 "Backend implementations ... are not open source" / "single-player campaign ... not open source" 식의 명시
- 특정 패키지(예: `ares/`, `artemis/`)가 placeholder만 있고 `package.json`의 `private: true` 또는 `workspaces` 의존성 메타만 있음
- `pnpm install` / `npm install` 성공해도 `pnpm dev` 또는 `pnpm build`가 placeholder 부재로 즉시 실패
- 원본 sidecar 파일(예: `art/Variants.nkzw.tsx`)이 paid 빌드 마커 역할로 존재
- 다른 fork도 같은 빈 패키지 흔적을 보임 → 본체 비공개 확정

D인 경우 fork의 가치는 **빌드 가능한 완성 게임이 아니라** "재사용 가능한 자산의 보존·이식"이 된다. README는 (a) 단독으로 빌드할 수 없음을 첫 줄에 명시, (b) 보존된 자산(번역 데이터, AI 코드, 스크립트)을 나열, (c) 후속 작업 시 자산을 옮길 수 있는 경로를 안내해야 한다.

### 4. 보정이 "이미 끝났는지" 검증 — 빌드 산출물의 결정적 신호

가장 빠른 검증은 **빌드 산출물의 byte-level 비교**.

```bash
# 부모 commit (또는 첫 분기점) 로 가서 빌드
git checkout <upstream-tag> -- src/
npm run build
NEW_HASH=$(ls dist/assets/index-*.js | sed 's/.*index-//;s/\.js//')
echo "upstream build hash: $NEW_HASH"

# 내 fork 빌드
git checkout main
npm run build
NEW_HASH=$(ls dist/assets/index-*.js | sed 's/.*index-//;s/\.js//')
echo "fork build hash:     $NEW_HASH"

# 두 hash가 동일하면 → fork의 게임 코드가 부모와 byte 단위 동일
# 이게 결정적 증거: "내 fork는 부모의 출시 빌드와 동일하다"가 입증됨
```

이 패턴은 이 세션에서 실제로 사용했고 (`index-BSKuygEx.js`가 i18n 1단계 커밋과 동일), **Vercel 자동배포 alias가 부모와 동일한 빌드를 서빙하고 있음을 검증**했다. **build hash 비교 = 코드 동일성 결정적 검증**.

### 5. 결정 후 정직한 README 갱신 — fork만 있는 특별 정보

A 안을 결정하면, **원본 README의 self-assessment 섹션에는 정확한 한국어 fork 정정 노트가 필요**:

```markdown
### 한국어 fork 정정 (YYYY-MM-DD)

원본 README의 이 섹션은 "A known root cause remains unfixed"라고 적혀있지만,
**이 fork에서는 정확하지 않다**. `weapons/materials.js` 안에 남겨진 자세한
코멘트가 그 이유를 설명한다:

  - 패치 단계가 "two coupled moves"로 코멘트에 명시됨
  - 각 단계의 코드 값이 보정 완료된 상태로 박혀있음
  - 따라서 fork의 출발점은 균형 회복된 상태

> 짧은 시도 이력: 한 번 `viewKeyScale 0.55 → 0.42` 패치를 했었음
> (`19f62a3` 커밋). 분석 결과 이중 보정이 돼서 0.55로 되돌림.
```

이 노트는 사용자가 "원본이 unfix라고 했는데 fix됐어?" 라고 물을 때 답이 됨. **시도 + 되돌림 + 이유** 트리오가 정직성.

### 5b. D 결정 — "빌드 불가 + 자산 보존" README 템플릿

Open Core fork에서 단독 빌드가 불가능한 경우, README는 일반적 'fork 추가 기능' 표현을 **즉시 삭제**하고 다음 구조로 갈아끼운다:

1. **상단 안내**: "이 fork는 Athena Crisis의 Open Core 공개 부분 기반 실험 코드입니다. 비공개 본체(싱글 플레이 캠페인, 멀티플레이, 백엔드, 아트·음악·콘텐츠) 소스가 없어 이 fork만으로 빌드할 수 없습니다."
2. **보존 자산 섹션**: 한국어 번역 데이터, AI 코드, 생성 스크립트 등 이식이 가능한 항목을 명시. **각 파일의 정확한 항목 수(예: "1,535개 번역")를 검증해서 쓴다** — JSON 파싱 / 파일 glob / 라인 수 등으로 확인된 수치만.
3. **활용 안내**: "권장 활용: 후속 작업 또는 다른 fork로 위 파일들을 이식" — 이산 자산 단위로 옮길 수 있음을 명시.
4. **원본 Setup 섹션 위**: "아래의 영문 Setup은 원본 저장소 문서 보존용 참고 자료이며, 이 fork에서 `pnpm dev`가 성공한다는 의미가 아닙니다." — 오해 차단.

이렇게 두면 README 자체가 자가 검증 결론이 된다. 사용자가 "이거 실행돼?" 물으면 README 첫 줄이 답이 됨.

D인 경우 작업 보고도 다르게 작성한다: "임시 산출물 정리, N개 보존 자산의 무결성 확인, README 한계 명시, 커밋 + 푸시 완료" — **"빌드 성공"이라는 강한 표현 금지**. 검증 결과는 'assets preserved, repo clean, push confirmed' 같은 약한 표현으로.

## Workflow 6단계 (fork 시작 시)

```
1. README + CHANGELOG에서 부모의 진단/마지막 상태 정리
2. fork 디렉토리에서 grep으로 관련 코드 + 코멘트 블록 검색
3. 코멘트 끝-끝 읽기 — "already applied"/"shipped"/"this one" 같은 단서
4. 코드 값 grep으로 보정 값 확인 (e.g. `grep "specularIntensity: 0.11" weapons/materials.js`)
5. 빌드 산출물의 hash 비교 — 부모의 출시 빌드와 byte-level 일치 확인
6. 결정 (A/B/C/D) + README에 정직한 정정 노트 추가 (A인 경우) / 자산 보존 + 한계 명시 (D인 경우)
```

**D 결정 시 추가 단계** (6단계 위에 prepend):
- 0a. 부모 README 양 끝 점검 — "Open Source" / "What is open source and what isn't?" / "Q&A" 섹션에서 비공개 본체 목록 발췌
- 0b. `package.json` + 각 패키지 디렉토리에서 placeholder 흔적 식별 (`private: true`, 빈 `src/`, `__generated__` 무시 패턴, sidecar 패턴 더미)
- 0c. 실험·임시 산출물 인벤토리: `ko_batch_*.json`, 헬퍼 Python 파일, sidecar 더미, `git status --untracked-files=all`로 미커밋 파일 전부 triage
- 0d. 보존 자산 인벤토리: 번역 JSON(항목 수 검증), AI/도메인 코드, 재실행 가능한 스크립트
- 0e. D 결정 시 보존 자산의 SHA가 직전 커밋과 byte-identical 인지 재확인 (정리 작업 중 실수 없음 보장)

## Anti-patterns

### ❌ "README 진단 = 진실" 가정

README는 marketing과 함께 자주 단순화된다. **코드는 진실**. 코멘트가 더 자세한 정보를 자주 가지고 있다.

### ❌ 자식 보정을 부모 위에 추가적용

부모의 자식 보정이 유지될 거라 기대하지 마라. 부모의 출시 빌드에 자식 보정을 그냥 얹으면 **이중 보정**이 되어 원본 의도와 어긋난다. 자식이 할 일은 **남아 있는 것**만.

### ❌ 분석 후에만 시도한 패치를 그대로 남기기

시도 → 분석 → 깨달음 → 되돌리기 흐름은 정직하지만 **시도한 패치를 squash merge하지 마라**. **되돌린 커밋도 git 히스토리에 남겨** "왜 X를 안 했는지"의 학습 흔적이 됨. 단, **squash하지 말 것** — `--amend`나 rebase는 시도 흔적을 지움.

### ❌ fork 작업 보고서를 "성공 패치 N건" 식으로 쓰기

"시도 1 + 되돌림 1 + 정직한 docs 추가 1"이 보고되면 **읽는 사람이 결정 과정을 신뢰함**. "성공 패치 1건"만 보고하면 결정 과정이 안 보임.

## 실측: minimax-of-duty viewmodel (2026-07-27)

| 단계 | 발견 |
|---|---|
| README "Honest assessment" | "viewmodel light rig delivers ~20× the irradiance ... Every weapon albedo was cheated to a third" |
| `weapons/materials.js` line 99~138 | "Two coupled moves, and neither works alone: 1. specularIntensity 0.5 -> 0.11 ... 2. albedo x3. 0.098 -> 0.285" |
| `weapons/materials.js` line 148 | `three: { physical: true, specularIntensity: 0.11 }` ← **이미 적용** |
| `weapons/materials.js` line 139 | `tint: c(0.285, 0.302, 0.349)` ← **이미 적용** |
| → **결정: A (부모가 끝까지 감)**. fork는 no-op + 정직한 docs |

**A 결정의 증거**:
- 빌드 hash 비교: i18n 1단계 커밋(`005b039`)과 viewmodel 되돌림 커밋(`a262152`)의 JS 번들이 **동일한 `index-BSKuygEx.js`**.
- 이건 게임 코드가 부모 출시 빌드와 byte 단위로 같다는 결정적 증거.

**시도 → 되돌림 흐름의 가치**:
- `19f62a3` viewKeyScale 0.55 → 0.42 시도 커밋은 git 히스토리에 남아 있음
- `a262152` revert 커밋에서 분석 + 결정 + 정직한 README 갱신 한 번에 처리
- 사용자가 "왜 viewmodel이 fork의 시작점이 아니지?"라고 물어도 답이 코드 안 + 커밋 메시지에 박혀 있음

## 실측 검증 명령 모음

```bash
# 부모 진단 발췌
grep -iE "unfixed|known issue|root cause|20 ?x|irradiance" README.md

# 자식 코드에서 보정 흔적 검색
grep -n "specularIntensity: 0.11\|albedo x3\|tint: c(0.285" src/weapons/materials.js

# 다른 부모 후보가 있는지도 확인 — fork가 mshumer/Claude-of-Duty 외에서 갈래를 탔나
git log --all --oneline | grep -iE "fix|patch|calibrat" | head -20

# 빌드 hash 비교
echo "fork build:" && ls dist/assets/index-*.js | head -1
```

## 관련 스킬

- `systematic-debugging` — 보정이 끝났는지 확인하는 단계가 디버깅의 일부일 때
- `ad-hoc-verification` — fork 빌드의 byte-level 동일성 검증
- `patch-line-context-safety` — fork의 보정 시도가 fuzzy match로 어긋날 때
