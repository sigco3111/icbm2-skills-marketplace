# sigco-fruitbox 세션 실측 노트 (2026-08-07)

본 파일은 본 스킬의 1차 실측 세션에서 검증된 구체적 사실관계 + 디버깅 단계 + 발견 함정 verbatim. 다음 게임 부트스트랩 시 첫 reference.

## 세션 컨텍스트

- **사용자 요청**: "너 이게임을 만들 수 있나?" + fruitboxgame.com/ko#fruit-box-rules URL + 커스텀 규칙 ("항상 10이 아닌 시작할때 12나 8등의 랜덤한 숫자를 합하도록")
- **결과물**: `~/work/sigco-fruitbox/` 사과게임 v0.2 (17×10 사과 보드 + 매 판 랜덤 타겟합 8/10/12/15 + 5-버튼 HUD + i18n + 일시정지 + 색맹모드 + 효과음 + SVG 사과)
- **v0.1 → v0.2 회전**: 사용자가 원본 fruitboxgame.com 스크린샷 2장 첨부 → 사과 모양 SVG, 보드 외곽 빨강 테두리, 합계 라벨, 5-버튼 컨트롤 등 반영

## 검증된 사실관계 (★ 모두 실측 PASS)

| 항목 | 값 |
|---|---|
| `tsc --noEmit` | 0 errors |
| `npm run build` | 165KB JS / 16KB CSS (gzip 54KB / 4KB), 39 modules |
| Vite dev server | http://localhost:5173 → 200 OK |
| Playwright 드래그 (valid pair 5+7=12) | 점수 2/170 정확, 사과 168개 |
| Playwright 모바일 (390×844) | 점수 2/170 정확 (PointerEvents 통합 정상) |
| 콘솔 에러 | 0 |
| 셀 17×10 = 170개 렌더링 | OK |
| SVG 사과 (잎+줄기+그라데이션) 렌더링 | OK |
| 셀렉션 박스 색상 피드백 (무효=흰색, 유효=빨강) | OK |
| 합계 라벨 "12" 박스 우상단 표시 | OK |
| 일시정지/재개/색맹/효과음 토글 | OK |

## 발견된 8대 함정 verbatim (이 세션에서 실측, 코드 + 진단 포함)

### 함정 1 — postcss peer-dep 미스매치

**증상**:
```bash
$ npm install
npm error ERESOLVE unable to resolve dependency tree
npm error While resolving: sigco-fruitbox@0.1.0
npm error Found: postcss@undefined
npm error node_modules/postcss
npm error   dev postcss@"^8.5.99" from the root project
npm error Could not resolve dependency:
npm error peer postcss@"^8.1.0" from autoprefixer@10.5.4
```

**진단**:
```bash
# postcss 8.5+는 autoprefixer 10.x의 peer-dep 범위에 안 들어감
# npm은 postcss를 install 안 함 (autoprefixer가 자체 postcss 사용)
```

**해결**:
```json
// package.json
"postcss": "^8.4.49"   // 8.4.x로 pin
```

**원인 가설**: Tailwind 3.x + autoprefixer 10.x 조합에서 `^8.5.99`는 npm이 postcss 패키지를 install 안 함 → `tailwindcss`가 빌드 시 `postcss` 찾지 못해 fail.

### 함정 2 — tsconfig composite + noEmit 충돌

**증상**:
```bash
$ npx tsc -b --noEmit
tsconfig.json(20,18): error TS6310: Referenced project '/.../tsconfig.node.json' may not disable emit.
```

**원인**: Vite 공식 template의 `tsconfig.json` (composite project) + `tsconfig.node.json` (composite referenced project) 구조. `tsconfig.json`에 `noEmit:true` 박으면 composite project가 emit을 요구하는 스펙과 충돌.

**해결**:
1. `tsconfig.json`에서 `references` 제거 + `composite: true` 제거
2. `tsconfig.node.json` 삭제
3. 단일 tsconfig로 단순화:
```json
{
  "compilerOptions": {
    "target": "ES2020", "useDefineForClassFields": true,
    "lib": ["ES2020", "DOM", "DOM.Iterable"],
    "module": "ESNext", "skipLibCheck": true,
    "moduleResolution": "bundler",
    "resolveJsonModule": true, "isolatedModules": true,
    "noEmit": true, "jsx": "react-jsx", "strict": true,
    "types": ["node"]
  },
  "include": ["src", "vite.config.ts"]
}
```
4. `package.json` scripts:
```json
"build": "tsc -b && vite build",   // ← tsc -b는 typecheck만, vite build가 실제 emit
"typecheck": "tsc --noEmit"
```

**★ 핵심**: `tsc -b`는 typecheck 역할, 실제 emit은 vite. `tsconfig.node.json` 없어도 vite.config.ts 타입 체크는 위 단일 tsconfig가 담당.

### 함정 3 — vite.config.ts에 `process` not defined

**증상**:
```
vite.config.ts(1,30): error TS2307: Cannot find module 'vite' or its corresponding type declarations.
```

**해결**:
```bash
npm install -D @types/node
```
+ tsconfig에 `"types": ["node"]` 추가.

### 함정 4 — setState-in-updater 안티패턴 (★★★ 가장 발견 어려운 React 18 함정)

**증상**: 처음에 작성한 코드:
```ts
const setDrag = useCallback((r, c) => {
  if (!board || !meta) return;
  setSelection((prev) => {
    if (!prev) return { r1: r, c1: c, r2: r, c2: c };
    const r1 = Math.min(prev.r1, r);
    const c1 = Math.min(prev.c1, c);
    const r2 = Math.max(prev.r2, r);
    const c2 = Math.max(prev.c2, c);
    const sel = { r1, c1, r2, c2 };
    setLiveSum(rectSum(board, r1, c1, r2, c2));      // ← side effect in updater
    setLiveAlive(rectAliveCount(board, r1, c1, r2, c2));  // ← side effect in updater
    return sel;
  });
}, [board, meta]);
```

**원인 분석**:
- `setLiveSum`, `setLiveAlive`는 setState 호출
- React 18 strict mode에서 setState-in-updater는 double-invoke 시 side effect 2회 실행
- React batching이 setState-in-updater는 batch 안 함 (업데이트는 pure function이어야)
- "selection 변경 → liveSum 변경" 의존 관계가 useState만으로 깨끗하게 표현 안 됨

**해결**:
```ts
const setDrag = useCallback((r, c) => {
  if (!board || !meta) return;
  setSelection((prev) => {
    if (!prev) return { r1: r, c1: c, r2: r, c2: c };
    const r1 = Math.min(prev.r1, r);
    const c1 = Math.min(prev.c1, c);
    const r2 = Math.max(prev.r2, r);
    const c2 = Math.max(prev.c2, c);
    return { r1, c1, r2, c2 };
  });
}, [board, meta]);

// 별도 useEffect로 분리 — 의존 관계 명시
useEffect(() => {
  if (!board || !selection) {
    setLiveSum(0);
    setLiveAlive(0);
    return;
  }
  setLiveSum(rectSum(board, selection.r1, selection.c1, selection.r2, selection.c2));
  setLiveAlive(rectAliveCount(board, selection.r1, selection.c1, selection.r2, selection.c2));
}, [board, selection]);
```

**진단 heuristic**: setState-in-updater는 lint로 잡기 어려움 (eslint-plugin-react-hooks의 exhaustive-deps가 못 잡음). **"updater 안에서 다른 setState 호출"** + **"setState 콜백 안에서 외부 state 읽기"** 가 동시이면 의심. → useEffect로 분리.

### 함정 5 — CSS `padding: %` in absolute child = 폭 폭주 (★★★ 30분+ 디버깅)

**증상**: SVG 사과가 안 보임. 정확히는 렌더되지만 width=0, height=0.

**진단** (Playwright + computed style chain):
```js
// SVG getBoundingClientRect
{w: 0, h: 0}   // ← 0x0

// parent chain
0 svg         w=0  h=0
1 DIV w-full  w=0  h=0
2 DIV abs     w=50.375 h=50.375 padding=25.1875px  ← 폭의 50% (??)
3 DIV aspect  w=840  h=494
4 DIV max-w   w=860
```

**원인**: `padding: '3%'` in absolute child:
- CSS percentage padding은 **containing block (가장 가까운 positioned ancestor) 의 width** 기준
- absolute child의 width = 5.88% of 840 = 50.375px
- but padding 3% = 3% of **840px** (positioned ancestor 폭) = 25.2px
- 50.375 - 25.2 * 2 = -0.025 → inner div 폭 0
- 0 폭 wrapper 안 SVG 0x0

**해결**:
```tsx
// ❌ 폭 폭주
<div className="absolute" style={{ width: '5.88%', padding: '3%' }}>

// ✅ box-sizing: border-box + 작은 px padding
<div className="absolute" style={{
  width: '5.88%', boxSizing: 'border-box', padding: '2px'
}}>
```

**진단 heuristic**: SVG 또는 inner div가 `width=0, height=0`인데 코드는 정상 → `padding: %` in absolute child 의심. computed style chain 따라가면서 padding이 폭의 절반 이상이면 함정 5.

### 함정 6 — SVG 0x0 chained parent (함정 5의 증상)

**증상**: 함정 5와 동일. SVG 렌더되지만 width=0, height=0.

**진단**: 함정 5의 진단 명령으로 parent chain 따라가면서 폭 0인 div 찾기.

**해결**: 함정 5와 동일 (`box-sizing: border-box` + px padding). 또는 width를 `calc(100% / 17)` 식으로 명시.

### 함정 7 — Playwright 드래그 "valid pair" 함정 (★★★ 가장 자주 만나는 검증 함정)

**증상**: 임의 두 사과를 골라서 sum=target 되는 pair로 드래그 → 점수 안 올라감 (commit이 invalid로 무시됨).

**원인**: 사과게임 룰 — **합=target 이어도 사이에 다른 사과가 끼면 invalid**. 예: col 1의 "2" + col 5의 "8" = 10 (target). col 1~5 사이에 사과들 있으면 합 10 넘김 → invalid.

**잘못된 검증 (fb2_smoke.py v1)**:
```python
# ❌ 임의 두 사과 — 사이에 다른 사과 있어도 pair 추출
pair = next(c1 for c1 in cells if c1['v'] + c2['v'] == target)
# → 5@col1 + 5@col5 = 10, but 사이에 사과 3개 더 → invalid
# → commit 무시 → 점수 0 → false FAIL
```

**올바른 검증 (fb4.py)**:
```python
# ✅ 엔진 격리 — findAnyValidRect와 동일 로직으로 grid 순회
from collections import defaultdict
grid = [[None]*17 for _ in range(10)]
for c in cells:
    col = max(0, min(16, round((c['cx'] - rect['x']) / cw)))
    row = max(0, min(9, round((c['cy'] - rect['y']) / ch)))
    grid[row][col] = (c['v'], c['cx'], c['cy'])

def find_valid():
    for r1 in range(10):
        for c1 in range(17):
            if grid[r1][c1] is None: continue
            for r2 in range(r1, 10):
                for c2 in range(c1, 17):
                    s = 0; n = 0
                    for r in range(r1, r2+1):
                        for c in range(c1, c2+1):
                            if grid[r][c] is not None:
                                s += grid[r][c][0]; n += 1
                    if s == target and n >= 2:
                        return (r1, c1, r2, c2)
    return None

r1, c1, r2, c2 = find_valid()
# 픽셀 좌표 변환 후 드래그 → 점수 정확히 2
```

**★ 교훈**: 엔진 격리 패턴 (engine.ts를 React 무관 순수 함수로 분리)이 Playwright 검증의 정밀도를 직접적으로 올려줌. engine에 `findAnyValidRect`가 있으면 Playwright가 동일 알고리즘으로 valid rect 찾기 가능. **엔진 격리는 단위 테스트용이 아니라 검증용으로도 가치**.

### 함정 8 — Playwright localStorage 공유 = i18n 자동 토글

**증상**: 첫 smoke test (fb_smoke.py)는 한국어로 부팅. 두 번째 (fb_trace.py)는 같은 컨텍스트에서 localStorage 공유되어 영문으로 부팅 (`navigator.language` 디폴트 'en-US'). 텍스트 selector `"시작"`이 안 잡힘.

**진단**:
```python
# ✅ 첫 진단 — 어떤 button들이 보이는지 dump
buttons = await page.evaluate("() => [...document.querySelectorAll('button')].map(b => b.innerText.trim())")
print("Buttons visible:", buttons)
# → ['Copy today's seed', '한국어', 'Start', '💡 Hint']
# → 'Start'는 영문 버튼. selector 'button:has-text(\"시작\")' 실패
```

**해결**:
```python
# 매 컨텍스트 명시적 locale
ctx = browser.new_context(viewport={'width': 1100, 'height': 900}, locale='ko-KR')

# 또는 useLang fallback 자체에 한국어 우선 박기 (이미 구현됨)
# navigator.language.startsWith('ko')이면 ko
```

**★ 교훈**: Playwright 컨텍스트의 default `navigator.language`는 'en-US'. **한국어 우선 사용자에게 locale 명시 필수**. 또한 **컨텍스트 간 localStorage 공유됨** (매번 fresh context 만들지 않으면).

## 디버깅 타임라인 (이 세션의 검증 워크플로)

1. **1차 typecheck/build/dev** — `tsc --noEmit` 0 errors + `npm run build` PASS
2. **fb_smoke.py v1** — Playwright 첫 드래그. selector로 "시작" 매칭. **점수 0** → 잘못된 가설 (엔진 버그 의심)
3. **fb_diag.py** — status=playing 검증 + timer 카운트다운 확인 → **엔진 정상** (점수 0은 invalid pair 때문)
4. **fb_valid.py** — fb_smoke와 동일 시드 + valid pair (5+7=12) 찾기 → **점수 2 정확** → 엔진 정상 확인
5. **사용자 스크린샷 첨부** → v0.2 리디자인 (사과 SVG, 보드 테두리, 합계 라벨, 5-버튼, 일시정지, 색맹, 효과음)
6. **fb2_smoke.py** — v0.2 시각 검증. **사과 안 보임** → parent chain 진단 (함정 5 발견)
7. **fb_svg_probe.py / fb_chain.py** — SVG width=0, parent 폭 0 → padding 3% = 25.18px 폭의 50% → 함정 5 verbatim
8. **함정 5 해결** (box-sizing + 2px padding) → 사과 정상 렌더
9. **fb3_diag.py / fb4.py** — valid_rect 엔진 격리 → 점수 2 정확, 셀렉션 박스 빨강, 합계 "12" 라벨 정상
10. **fb_mobile.py** — 모바일 390×844 viewport → 점수 2 정확, 터치 드래그 정상

## 결정적 진단 도구 (이번 세션에서 가장 효과적)

1. **Playwright `page.evaluate` + parent chain 따라가며 computed style 출력** — 함정 5/6 30분 디버깅 → 5분 해결
2. **Playwright `getBoundingClientRect()` + width/height=0 즉시 감지** — 함정 5/6 시그널
3. **engine 격리 (React 무관 순수 함수)** — Playwright가 동일 알고리즘으로 valid_rect 찾기 (함정 7)
4. **`vision_analyze`로 스크린샷 확인** — 사과 SVG/테두리/라벨/HUD 모두 정상 시각 확인

## 후속 작업 (다음 세션에서)

- 2048/테트리스/매치-3 같은 다른 보드게임으로 재검증 (함정 1-8 일반성 확인)
- Vitest 단위 테스트 추가 (engine.ts는 React 무관이라 자연스러움)
- GitHub Actions CI 추가
- A11y 키보드 내비게이션 (Tab/Space/Arrow)
- 멀티플레이어 (WebSocket, 별도 서버 필요)
- 콤보 시스템 (5개+ 한 번에 지우면 보너스)
