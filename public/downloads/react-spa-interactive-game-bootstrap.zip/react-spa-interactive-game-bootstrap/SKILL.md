---
name: react-spa-interactive-game-bootstrap
description: "Vite+React+TS+Tailwind 보드게임/퍼즐 부트스트랩. 사과게임/2048/테트리스."
version: 1.0.0
author: HyeRin
license: MIT
metadata:
  hermes:
    tags: [vite, react, typescript, tailwind, game, puzzle, drag, spa, i18n, daily-seed, svg, web-audio, vercel, hooks, strict-mode]
    related_skills: [canvas-static-site-pipeline, vite-threejs-game-bootstrap, vite-react-spa-game-fork, gh-pages-spa-deploy, ad-hoc-verification]
when_to_use: >
  "단일 페이지 인터랙티브 게임/퍼즐 만들어줘", "사과게임/2048/테트리스/슬라이딩 퍼즐 류 만들어줘",
  "드래그/탭/스와이프 인터랙티브 보드게임", "데일리 시드 + i18n + Vercel 정적 호스팅",
  "DOM/SVG 기반 게임 엔진 + React state machine + PointerEvents 통합".
  풀스택 + OAuth/DB/socket.io 류는 `canvas-static-site-pipeline` 변형 4 (Next.js 풀스택) 사용.
  fork 워크플로는 `vite-react-spa-game-fork` 사용.
  Three.js/Canvas/WebGL 류는 `vite-threejs-game-bootstrap`.
category: software-development
---

# React SPA Interactive Game Bootstrap (Vite + React 18 + TS + Tailwind)

**클래스**: 17×10 사과게임, 2048, 테트리스, 슬라이딩 퍼즐, 매치-3 류의 **단일 페이지 인터랙티브 보드게임**. DOM/SVG 기반 렌더링, React state machine으로 게임 엔진, PointerEvents로 드래그/탭 통합, 데일리 시드 + i18n + Vercel 정적 호스팅.

**이번 세션 실측**: 2026-08-07 sigco-fruitbox (`~/work/sigco-fruitbox/`, 사과게임 + 커스텀 규칙 + 5-버튼 HUD + i18n + 데일리 시드 + SVG 사과 + Web Audio 합성 효과음). 본 스킬의 모든 함정/패턴은 이 실측에서 검증됨.

## ★★★ 사용 시기 (트리거)

다음 키워드/조건 **하나라도** 해당되면 이 스킬 첫 reference로:

| 키워드/조건 | 스킬 |
|---|---|
| "단일 페이지 게임 만들어줘", "퍼즐 게임", "보드게임" | **이 스킬** |
| 사과게임, 2048, 테트리스, 슬라이딩 퍼즐, 매치-3, minesweeper, sudoku | **이 스킬** |
| 드래그/탭/스와이프 인터랙션 + 격자/보드 | **이 스킬** |
| React + state machine + 데일리 시드 + i18n | **이 스킬** |
| "내 PC에서 실행", "pygame", "데스크탑 게임" | `canvas-static-site-pipeline` 변형 3 (pygame) |
| Three.js / WebGL / 3D 시각화 | `vite-threejs-game-bootstrap` |
| Canvas 2D (no library) 단순 시뮬레이션 | `canvas-static-site-pipeline` 변형 1 |
| 기존 OSS 게임 fork + 한국어화 | `vite-react-spa-game-fork` |
| 풀스택 (OAuth/DB/socket.io) | `canvas-static-site-pipeline` 변형 4 (Next.js) |
| gh-pages 배포 | `gh-pages-spa-deploy` |

## 부트스트랩 5단계 (이번 세션 실측)

### 1단계 — 프로젝트 스캐폴드 (★ 3대 함정 동시 주의)

```bash
mkdir -p ~/work/<game-name> && cd ~/work/<game-name>
```

**package.json** (★ postcss peer-dep 충돌 회피):
```json
{
  "name": "<game-name>",
  "private": true,
  "version": "0.1.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "tsc -b && vite build",
    "preview": "vite preview --host",
    "typecheck": "tsc --noEmit"
  },
  "dependencies": {
    "react": "^18.3.1",
    "react-dom": "^18.3.1"
  },
  "devDependencies": {
    "@types/node": "^22.0.0",
    "@types/react": "^18.3.12",
    "@types/react-dom": "^18.3.1",
    "@vitejs/plugin-react": "^4.3.4",
    "autoprefixer": "^10.4.20",
    "postcss": "^8.4.49",       // ★ 8.4.x 고정 (8.5+는 autoprefixer peer-dep 미스매치)
    "tailwindcss": "^3.4.17",   // ★ v3.x — v4는 alpha, prod 부적합
    "typescript": "^5.6.3",
    "vite": "^5.4.11"
  }
}
```

**★★ 함정 1 — postcss peer-dep 미스매치**:
```bash
$ npm install
npm error ERESOLVE unable to resolve dependency tree
npm error Found: postcss@undefined
npm error Could not resolve dependency:
npm error peer postcss@"^8.1.0" from autoprefixer@10.5.4
```
**원인**: `postcss: "^8.5.99"`로 두면 npm이 postcss를 install 안 함 (autoprefixer가 자체 postcss 사용). tailwind 3.x + autoprefixer 10.x는 `postcss ^8.1.0` 필요.
**해결**: `postcss: "^8.4.49"`로 명시적 pin. 또는 `npm install --legacy-peer-deps`. **8.4 pin이 정석**.

**★★ 함정 2 — tsconfig composite + noEmit 충돌**:
```json
// ❌ 충돌: composite project는 noEmit:true 불가
{
  "compilerOptions": { "composite": true, "noEmit": true }
}
// error TS6310: Referenced project may not disable emit.
```
**원인**: Vite template이 기본 생성하는 `tsconfig.json` + `tsconfig.node.json` (composite project) 구조에서 `tsconfig.json`에 `noEmit:true` 박으면 `tsc -b` 빌드 시 충돌.
**해결**: `composite` 모드 안 쓰고 단일 tsconfig로 단순화:
```json
{
  "compilerOptions": {
    "target": "ES2020",
    "useDefineForClassFields": true,
    "lib": ["ES2020", "DOM", "DOM.Iterable"],
    "module": "ESNext",
    "skipLibCheck": true,
    "moduleResolution": "bundler",
    "resolveJsonModule": true,
    "isolatedModules": true,
    "noEmit": true,
    "jsx": "react-jsx",
    "strict": true,
    "types": ["node"]
  },
  "include": ["src", "vite.config.ts"]
}
```
`tsconfig.node.json` 삭제 + `package.json` scripts는 `tsc --noEmit` (단일 호출, 참조 없음). `tsc -b` 빌드도 typecheck + build를 따로 호출.

**★★ 함정 3 — vite.config.ts에 `types: ["node"]` 누락**:
`vite.config.ts`에서 `process.cwd()`나 `path.resolve(__dirname, ...)` 쓰면 `Cannot find name 'process'` 에러.
**해결**: 위 tsconfig `types: ["node"]` + `npm install -D @types/node`. 또는 `vite.config.ts`에 `/// <reference types="node" />` 한 줄.

**tailwind.config.js + postcss.config.js** (v3 표준):
```js
// postcss.config.js
export default { plugins: { tailwindcss: {}, autoprefixer: {} } };

// tailwind.config.js
/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: { extend: { fontFamily: { sans: ['"Apple SD Gothic Neo"', 'system-ui', 'sans-serif'] } } },
  plugins: [],
};
```

**index.html**:
```html
<!doctype html>
<html lang="ko">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="theme-color" content="#0f172a" />
  </head>
  <body class="bg-slate-950 text-slate-100">
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
```

**src/index.css**:
```css
@tailwind base; @tailwind components; @tailwind utilities;
html, body, #root { height: 100%; }
body {
  -webkit-user-select: none; user-select: none;
  -webkit-tap-highlight-color: transparent;
  overscroll-behavior: none;
}
.no-touch-default { touch-action: none; }
```

### 2단계 — 게임 엔진 분리 (★ 모듈 경계 3종)

**src/game/random.ts** — 결정론적 시드 RNG:
```ts
export function mulberry32(seed: number): () => number { /* ... */ }
export function dailySeed(d = new Date()): number {
  return d.getFullYear() * 10000 + (d.getMonth() + 1) * 100 + d.getDate();
}
export function hashStringToInt(s: string): number { /* FNV-1a */ }
```

**src/game/engine.ts** — 순수 함수 (React 무관, 단위 테스트 가능):
```ts
export const ROWS = 10, COLS = 17, TOTAL = ROWS * COLS;
export const TIME_LIMIT_SEC = 120;
export const TARGET_SUMS = [8, 10, 12, 15] as const;
export type TargetSum = (typeof TARGET_SUMS)[number];
export type Cell = number | null;
export type Board = Cell[][];

export function createRound(roundIndex: number, explicitTarget?: TargetSum) { /* ... */ }
export function isValidSelection(board, r1, c1, r2, c2, target): boolean { /* sum==target, alive>=2 */ }
export function applySelection(board, r1, c1, r2, c2): Board { /* immutable */ }
export function findAnyValidRect(board, target): { r1, c1, r2, c2 } | null { /* for hint */ }
export function aliveCount(board): number { /* ... */ }
```

**★ 엔진은 React 의존성 0** — 순수 TypeScript 함수. useGame.ts가 React state로 감쌈. 이렇게 분리하면:
- 엔진 단위 테스트 가능 (React 안 띄워도 됨)
- Playwright 드래그 검증 시 엔진 함수 직접 호출 가능 (§6단계)
- StrictMode 더블 effect 영향 없음 (엔진은 mount/unmount 무관)

**★ 데일리 시드 패턴 (★ 모든 보드게임에 적용)**:
```ts
const day = dailySeed();                              // YYYYMMDD 정수
const target = TARGET_SUMS[Math.floor(Math.random() * TARGET_SUMS.length)];  // 매 판 랜덤
const seed = hashStringToInt(`${day}-${roundIndex}-${target}`);
const rng = mulberry32(seed);
```
- 같은 날 + 같은 roundIndex → 같은 보드 (모든 플레이어 공유)
- roundIndex 만 바꾸면 즉시 새 보드
- target 바꾸면 같은 패턴에서 다른 합 목표

### 3단계 — useGame 훅 (★ React 18 setState-in-updater 안티패턴 회피)

**★★★ 함정 4 — setState-in-updater 안티패턴** (가장 자주 만나는 React 18 함정):

```ts
// ❌ 절대 이렇게 쓰지 말 것
const setDrag = useCallback((r, c) => {
  setSelection(prev => {
    const sel = { r1, c1, r2, c2 };
    setLiveSum(rectSum(board, r1, c1, r2, c2));  // ← setState in updater = side effect
    setLiveAlive(rectAliveCount(board, r1, c1, r2, c2));
    return sel;
  });
}, [board, meta]);

// ✅ useEffect로 분리
const setDrag = useCallback((r, c) => {
  if (!board || !meta) return;
  setSelection(prev => prev ? { r1: min(prev.r1,r), ..., c2: max(prev.c2,c) } : { r1:r, c1:c, r2:r, c2:c });
}, [board, meta]);

useEffect(() => {
  if (!board || !selection) { setLiveSum(0); setLiveAlive(0); return; }
  setLiveSum(rectSum(board, selection.r1, selection.c1, selection.r2, selection.c2));
  setLiveAlive(rectAliveCount(board, selection.r1, selection.c1, selection.r2, selection.c2));
}, [board, selection]);
```

**왜 문제인가**:
- React 18 strict mode에서 setState-in-updater는 **double-invoke 시 side effect 2회 실행**
- setLiveSum/setLiveAlive는 setState 호출이므로 React가 batching하려고 하면 **deadlock 가능**
- "selection 변경 → liveSum 변경" 의존 관계가 useState만으로 깨끗하게 표현 안 됨

**useEffect로 분리하면**:
- 의존 관계 명시적 (`[board, selection]`)
- React batching이 정상 작동
- strict mode double-invoke 안전

**useGame 표준 구조**:
```ts
export type Status = 'idle' | 'playing' | 'paused' | 'over';

export function useGame() {
  // 상태 7종: roundIndex, board, status, score, timeLeft, selection, hintRect
  // 파생 상태 2종: liveSum, liveAlive → useEffect로 계산
  // useRef 2종: tickRef (setInterval), draggingRef (drag 중 여부)

  // effects:
  //   1) mount: createRound(1) → board/meta
  //   2) status === 'playing' → setInterval(timeLeft--), 0이면 finish()
  //   3) board 변경 → aliveCount === 0이면 finish() (perfect clear)
  //   4) board || selection 변경 → liveSum/liveAlive 재계산 (★ 위 함정 4 회피)

  // actions: start, pauseToggle, newRound, setDrag, clearDrag, commitDrag, useHint
}
```

### 4단계 — 인터랙션 (★ CSS percentage padding in absolute child 함정)

**★★★ 함정 5 — CSS `padding: %` in absolute child = 폭 폭주**:

```tsx
// ❌ 폭 폭주 — padding 3% = positioned ancestor 폭 840px의 3% = 25.2px
// inner wrapper 폭 = 50.375 - 25.2 * 2 = 0
<div className="absolute" style={{ width: '5.88%', padding: '3%' }}>
  <div className="w-full h-full">  {/* ← 폭 0 */}
    <Apple />  {/* ← SVG 0x0 렌더됨 */}
  </div>
</div>

// ✅ 해결 1: box-sizing: border-box + 작은 padding
<div className="absolute" style={{ width: '5.88%', boxSizing: 'border-box', padding: '2px' }}>

// ✅ 해결 2: width/height을 % 대신 calc()로
<div className="absolute" style={{ width: 'calc(100% / 17)', padding: '2px' }}>

// ✅ 해결 3: padding 제거하고 SVG가 자체 margin
```

**원인**: CSS percentage padding은 **containing block (가장 가까운 positioned ancestor) 의 width** 기준. absolute child의 width는 자기 폭, but padding %는 부모 폭 840px의 3% = 25.2px. 50.375px 폭의 cell이 양쪽에 25.2px씩 padding = 0.88px만 남음 → inner div 폭 0 → SVG 0x0.

**진단 명령** (Playwright):
```js
// SVG width=0 즉시 감지
const svg = document.querySelector("svg");
const r = svg.getBoundingClientRect();
// r.width === 0, r.height === 0 → 함정 5
```

**★★ 함정 6 — SVG 0x0 chained parent**:
absolute div chain이 부모 폭 0 → 모든 자식 (wrapper + svg) 폭 0. computed style chain 디버깅:
```js
// Playwright로 parent chain 따라가며 computed width 확인
let el = svg;
while (el) {
  const cs = getComputedStyle(el);
  console.log(el.tagName, el.className, 'w=', cs.width, 'h=', cs.height, 'padding=', cs.padding);
  el = el.parentElement;
}
// → 'absolute' div에서 w=50.375px padding=25.18px 발견 → 함정 5 시그널
```

**해결**: 함정 5와 동일 (`box-sizing: border-box` + 작은 px padding). SVG 자체는 0x0 아님 — 부모 폭이 0이라서 그런 것.

**PointerEvents 통합 (모바일 + 데스크탑)**:
```tsx
const containerRef = useRef<HTMLDivElement>(null);
const draggingRef = useRef(false);
const pointerIdRef = useRef<number | null>(null);

useEffect(() => {
  function onMove(e: PointerEvent) {
    if (!draggingRef.current) return;
    if (pointerIdRef.current !== null && e.pointerId !== pointerIdRef.current) return;
    handleMove(e.clientX, e.clientY);
  }
  function onUp() { if (draggingRef.current) { draggingRef.current = false; handleUp(); } }
  window.addEventListener('pointermove', onMove);
  window.addEventListener('pointerup', onUp);
  return () => { window.removeEventListener('pointermove', onMove); window.removeEventListener('pointerup', onUp); };
}, [handleMove, handleUp]);

const onPointerDown = (e: React.PointerEvent) => {
  draggingRef.current = true;
  pointerIdRef.current = e.pointerId;
  (e.target as Element).setPointerCapture?.(e.pointerId);
  handleStart(e.clientX, e.clientY);
};
```

**★ window-level 리스너가 핵심**: containerRef 밖으로 나가도 드래그가 끊기지 않음. useRef로 dragging 상태 관리 (state 아님 — 매 setState마다 리렌더 안 함).

### 5단계 — 게임 디자인 패턴 (★ 사과게임 실측 5종)

**(a) SVG 셀 렌더링** — 사과, 체스 말, 카드 등:
```tsx
export function Apple({ value, hueShift = 0, colorBlind = false }: Props) {
  const hue = colorBlind ? 0 : (340 + hueShift + (value * 7) % 24) % 360;
  return (
    <svg viewBox="0 0 100 100" width="100%" height="100%">
      <defs>
        <radialGradient id={`body-${value}-${hueShift}`} cx="35%" cy="32%" r="70%">
          <stop offset="0%" stopColor={highlight} />
          <stop offset="20%" stopColor={bodyFrom} />
          <stop offset="100%" stopColor={bodyTo} />
        </radialGradient>
      </defs>
      <path d="..." fill={`url(#body-${value}-${hueShift})`} />
      <ellipse cx="36" cy="44" rx="9" ry="6" fill="white" fillOpacity="0.35" />
    </svg>
  );
}
```

**★ SVG id 충돌 방지**: 인접 셀이 같은 hueShift 가지면 gradient id 충돌 → 셀별 unique id (`${value}-${hueShift}`).

**(b) 셀렉션 박스 실시간 피드백**:
```tsx
const validSelection = !!selection && liveSum === target && liveAlive >= 2;

<div
  className="absolute pointer-events-none rounded-md"
  style={{
    border: `3px solid ${validSelection ? '#c43a3a' : '#ffffff'}`,
    boxShadow: validSelection ? '0 0 18px rgba(196,58,58,0.45)' : '0 0 12px rgba(255,255,255,0.4)',
    transition: 'border-color 0.12s, box-shadow 0.12s',
  }}
>
  {liveAlive >= 1 && (
    <div style={{
      position: 'absolute', right: -2, top: -2, transform: 'translate(0, -100%)',
      background: validSelection ? '#c43a3a' : 'rgba(15,23,42,0.85)',
      color: 'white', padding: '2px 6px', borderRadius: 4, fontWeight: 800,
    }}>{liveSum}</div>
  )}
</div>
```

**(c) HUD 3컬럼 미니멀 + 5-버튼 컨트롤**:
```tsx
// 3-column: 점수 / 시간+진행바 / 최고기록
<div className="grid grid-cols-3 items-end gap-4">
  <Stat label="점수" value={`${score}`} sub={`/${total}`} />
  <div>
    <div className="text-xs">{t('timeLeft')}</div>
    <div className="text-4xl font-black tabular-nums">{m}:{s}</div>
    <div className="h-1.5 rounded-full bg-emerald-900/15">
      <div className="h-full bg-emerald-600" style={{ width: `${(timeLeft/timeTotal)*100}%` }} />
    </div>
  </div>
  <Stat label="최고 기록" value={`${best}`} align="right" />
</div>

// 5-버튼: 힌트 / 일시정지 / 새보드 / 색맹모드 / 효과음
<div className="grid grid-cols-5 gap-2">
  <Ctrl icon="💡" label={t('hint')} onClick={onHint} disabled={!playing || hintUsed} />
  <Ctrl icon={paused ? '▶️' : '⏸'} label={paused ? t('resume') : t('pause')} onClick={onPauseToggle} />
  <Ctrl icon="🔄" label={t('newBoard')} onClick={onNewBoard} />
  <Ctrl icon="🎨" label={t('colorBlind')} onClick={onColorBlindToggle} active={colorBlind} />
  <Ctrl icon={soundOn ? '🔊' : '🔇'} label={t('sound')} onClick={onSoundToggle} active={soundOn} />
</div>
```

**(d) i18n (한국어/영어 토글)**:
```ts
// src/i18n.ts
const dict = { ko: {...}, en: {...} } as const;
export function useLang() {
  const [lang, setLang] = useState<Lang>(() => {
    const saved = localStorage.getItem('<app>.lang');
    if (saved === 'ko' || saved === 'en') return saved;
    return navigator.language.toLowerCase().startsWith('ko') ? 'ko' : 'en';
  });
  useEffect(() => { localStorage.setItem('<app>.lang', lang); document.documentElement.lang = lang; }, [lang]);
  return { lang, setLang, t: (k) => dict[lang][k] ?? k };
}
```

**(e) Web Audio API 합성 효과음 (의존성 0)**:
```ts
// src/game/sound.ts
let ctx: AudioContext | null = null;
let enabled = true;
export function setSoundEnabled(v: boolean) { enabled = v; }

function tone(freq, durMs, type = 'sine', gain = 0.15, when = 0) {
  const c = ctx ??= new (window.AudioContext || (window as any).webkitAudioContext)();
  const t0 = c.currentTime + when;
  const osc = c.createOscillator();
  const g = c.createGain();
  osc.type = type; osc.frequency.setValueAtTime(freq, t0);
  g.gain.setValueAtTime(0, t0);
  g.gain.linearRampToValueAtTime(gain, t0 + 0.01);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + durMs / 1000);
  osc.connect(g); g.connect(c.destination);
  osc.start(t0); osc.stop(t0 + durMs / 1000 + 0.05);
}

export const playSuccess = () => { if (!enabled) return; tone(660, 120, 'triangle', 0.18, 0); tone(990, 160, 'triangle', 0.16, 0.08); };
export const playError   = () => { if (!enabled) return; tone(180, 180, 'sawtooth', 0.1, 0); };
export const playHint    = () => { if (!enabled) return; tone(520, 100, 'sine', 0.12, 0); tone(780, 120, 'sine', 0.12, 0.06); };
```

### 6단계 — 검증 (★ Playwright "valid pair" 함정 + 시각 확인)

**★★★ 함정 7 — Playwright 드래그 검증 "valid pair" 함정** (가장 자주 만나는 검증 함정):

```python
# ❌ 잘못된 검증 — 임의 2 셀의 sum=target이어도 그 사이에 다른 셀이 있으면 invalid
pair = next(c1 for c1 in cells if c1['v'] + c2['v'] == target)  # ← invalid pair 가능
page.mouse.move(a['cx'], a['cy']); page.mouse.down()
page.mouse.move(b['cx'], b['cy']); page.mouse.up()
assert score == 2  # ← 0으로 fail (commit 무시됨)

# ✅ 올바른 검증 — 엔진 레벨 findAnyValidRect 직접 호출
target = int(... 헤더에서 추출 ...)
valid_rect = find_valid_rect_in_grid(grid, target)  # ← sum==target, alive>=2 정확 검증
x1, y1 = pixel(rect, valid_rect.c1, valid_rect.r1)
x2, y2 = pixel(rect, valid_rect.c2, valid_rect.r2)
page.mouse.move(x1, y1); page.mouse.down()
page.mouse.move(x2, y2, steps=10); page.mouse.up()
assert score == 2  # ← 통과
```

**★ 엔진 격리 패턴의 효과**: 엔진 함수를 격리해두면 Playwright가 브라우저 내 셀을 직접 grid로 변환 후 **엔진과 동일한 알고리즘**으로 valid rectangle 찾기 가능. 또는 **엔진 함수를 page.evaluate로 호출**:
```python
# 엔진 격리 시 가장 단순
valid_rect = page.evaluate("""
  () => {
    // board state를 직접 읽어 findAnyValidRect와 동일한 로직 실행
  }
""")
```

**시각 확인 (★ 1회 이상 필수)**:
```python
# 자동 진단 후 반드시 vision_analyze로 스크린샷 확인
await page.screenshot(path="/tmp/game-after-drag.png", full_page=True)
# vision_analyze(image_url, question) 호출 → 사과/그리드/셀렉션 박스/라벨 모두 확인
```

**★★★ 함정 8 — Playwright localStorage 공유 = i18n 자동 토글**:
```python
# 한 컨텍스트에서 여러 page 띄우면 localStorage 공유됨
ctx1 = browser.new_context()  # 한국어
ctx2 = browser.new_context()  # ← 첫 컨텍스트의 localStorage 따라 영문 가능
# 해결: 매번 fresh context 또는 명시적 locale
ctx = browser.new_context(locale='ko-KR')  # 명시
```

### 7단계 — 빌드 + Vercel 배포

```bash
npm run typecheck   # → 0 errors
npm run build       # → 150~170KB JS
vercel deploy --prod --yes --token $(cat ~/.hermes/secrets/vercel_token.txt)
# → ▲ Aliased https://<name>.vercel.app
```

**★ Vite 빌드 결과 사이즈**: React 18 + Tailwind 3 + TS 5 + 게임 엔진 모듈 5개 = **150~170KB JS (gzip ~55KB)**. 외부 라이브러리 0개면 더 작음. 게임 한 개당 200KB 이하가 적정.

## 디렉터리 구조 (목표)

```
<game-name>/
├── package.json              # 위 부트스트랩 §1 참조
├── tsconfig.json             # ★ composite 없음, noEmit:true, types:["node"]
├── vite.config.ts            # plugins:[react()], server:{host:true,port:5173}
├── tailwind.config.js
├── postcss.config.js
├── index.html                # 한국어 lang, viewport, theme-color
├── README.md                 # 규칙 + 구조 + 시드 규칙 + v0.X
└── src/
    ├── main.tsx              # ReactDOM.createRoot
    ├── App.tsx               # 최상위 (HUD + Board + GameOverPanel)
    ├── index.css             # Tailwind + touch-action: none
    ├── i18n.ts               # 한국어/영어 dict + useLang
    ├── game/
    │   ├── random.ts         # mulberry32 + dailySeed + hashStringToInt
    │   ├── engine.ts         # ★ React 무관 순수 함수
    │   ├── useGame.ts        # ★ state machine + setState-in-updater 회피
    │   ├── storage.ts        # localStorage 헬퍼 + useBestScore/usePrefBool
    │   └── sound.ts          # Web Audio 합성 (의존성 0)
    └── components/
        ├── BoardView.tsx     # 격자 + 드래그 셀렉션 + 합계 라벨
        ├── HUD.tsx           # 3컬럼 + 5-버튼 컨트롤
        ├── GameOverPanel.tsx # 종료 모달
        └── <GamePiece>.tsx   # SVG 사과/체스 말/카드 등
```

## 검증 절차 (★ 모든 새 commit 전)

```bash
cd ~/work/<game-name>

# 1. 타입체크 + 빌드 (3대 부트스트랩 함정 검증)
npx tsc --noEmit                              # 0 errors
npm run build                                  # 150~170KB JS

# 2. dev 서버 + Playwright 드래그 검증 (함정 7 회피)
npx vite --host 127.0.0.1 --port 5173 --strictPort &
sleep 3
python3 /tmp/verify_drag.py                   # engine 격리 valid_rect 찾기 + 드래그
# → score 증가 확인

# 3. vision_analyze로 시각 검증
# → 사과/그리드/테두리/라벨/HUD 모두 정상
# → 함정 5/6 (SVG 0x0, padding %) 없음
# → 함정 8 (i18n 자동 토글) 없음

# 4. 모바일 viewport (★ 1회 이상)
# → 390x844 viewport + has_touch=True + is_mobile=True
# → 터치 드래그 동작 확인

# 5. 콘솔 에러 0
# → pageerror / console.error 모두 0건
```

## 누적 통계 (2026-08-07 sigco-fruitbox 실측)

| 메트릭 | 값 |
|---|---|
| **저장소** | `~/work/sigco-fruitbox/` |
| **빌드 사이즈** | 165KB JS / 16KB CSS (gzip 54KB / 4KB) |
| **외부 의존성** | 0개 (React + Tailwind만, 사운드는 Web Audio 합성) |
| **모듈 수** | 9개 (engine / random / useGame / storage / sound / Apple / BoardView / HUD / GameOverPanel) |
| **Playwright 검증** | 점수 2/170 정확, 사과 168개, 일시정지 동작, 색맹 모드 동작 |
| **콘솔 에러** | 0 |
| **Vercel alias** | (배포 시) `https://<name>.vercel.app` (alias 미점유 시) |

## 즉시 적용 규칙 종합

1. **postcss 8.4.x pin** — 8.5+는 autoprefixer peer-dep 미스매치
2. **tsconfig composite 사용 안 함** — 단일 tsconfig + `tsc --noEmit` (composite + noEmit 충돌 회피)
3. **engine은 React 무관 순수 함수** — useGame이 state로 감쌈, 단위 테스트 + Playwright 검증 가능
4. **setState-in-updater 금지** — useEffect로 의존 관계 명시 ([board, selection])
5. **CSS percentage padding in absolute child = 폭 폭주** — `box-sizing: border-box` + 작은 px padding
6. **PointerEvents window-level** — containerRef 밖 드래그 끊김 방지
7. **Playwright 드래그 = 엔진 격리 valid_rect** — 임의 pair 추측 ❌, 엔진 알고리즘 ✅
8. **SVG id 셀별 unique** — `id={\`body-${value}-${hueShift}\`}` 패턴
9. **Web Audio 합성** — 0 dependency, success/error/hint 3종
10. **매 커밋 전 typecheck + build + Playwright + vision_analyze 4축** — Vercel 배포 전

## 후속 작업 (다음 세션에서)

- 본 스킬이 1개 게임 실측만 거치므로, 2048/테트리스/매치-3 다른 보드게임으로 재검증 필요
- Vitest 단위 테스트 패턴 (engine은 React 무관이라 단위 테스트 자연스러움) 보강
- PR workflow + GitHub Actions CI 패턴 추가
- A11y (키보드 내비게이션) 패턴 추가

## 지원 파일

- `references/sigco-fruitbox-sesac-2026-08-07.md` — **2026-08-07 sigco-fruitbox 세션 실측 노트**. 8대 함정의 verbatim 증상/원인/해결 + 진단 명령 + 디버깅 타임라인 + 결정적 진단 도구. 다음 게임 부트스트랩 시 첫 번째 reference.
- `scripts/verify_game.py` — **Playwright 드래그 검증 스크립트** (★ 베껴서 사용). 8대 함정 회피 패턴 모두 박혀있음 — 엔진 격리 valid_rect, 명시적 locale, parent chain 진단, 모바일 viewport, 콘솔 에러 검증. `python3 verify_game.py --url http://localhost:5173 --target-num 12 --out-dir /tmp`.
