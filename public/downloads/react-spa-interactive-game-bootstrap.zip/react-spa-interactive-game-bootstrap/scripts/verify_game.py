#!/usr/bin/env python3
"""
Playwright drag verification for React+TS interactive board games.

★ 핵심 패턴 (8대 함정 회피):
  1) 엔진 격리 valid_rect 찾기 (함정 7 — 임의 2셀 sum=target이어도 invalid 가능)
  2) Playwright 컨텍스트 명시적 locale (함정 8 — localStorage 공유 = i18n 자동 토글)
  3) parent chain computed style 디버깅 (함정 5/6 — SVG 0x0)
  4) 모바일 viewport 1회 검증 (PointerEvents)
  5) vision_analyze로 시각 확인 (사과/그리드/라벨/HUD)

Usage:
  python3 verify_game.py --url http://localhost:5173 --target-num 12 --out-dir /tmp

검증 단계:
  1. dev server alive (HTTP 200)
  2. 초기 화면 스크린샷 + 버튼/타겟합 추출
  3. valid_rect 찾기 (브라우저 내 board → grid → engine 격리 알고리즘)
  4. 드래그 → 점수/남은 사과 검증
  5. mid-drag 스크린샷 (셀렉션 박스 + 합계 라벨)
  6. 모바일 viewport 재검증
  7. 콘솔 에러 0 확인

★ 의존성:
  pip install playwright
  python3 -m playwright install chromium
"""

import argparse
import asyncio
import re
import sys
from collections import defaultdict

from playwright.async_api import async_playwright


async def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--url", default="http://localhost:5173")
    parser.add_argument("--target-num", type=int, default=None,
                        help="target sum (auto-detect from page if not given)")
    parser.add_argument("--out-dir", default="/tmp")
    parser.add_argument("--mobile", action="store_true",
                        help="run mobile viewport test (390x844 + has_touch)")
    args = parser.parse_args()

    async with async_playwright() as p:
        browser = await p.chromium.launch()

        # ★ 함정 8 회피: 명시적 locale
        ctx = await browser.new_context(
            viewport={"width": 1100, "height": 900},
            locale="ko-KR",
        )
        page = await ctx.new_page()
        errors = []
        page.on("pageerror", lambda e: errors.append(f"PAGEERROR: {e}"))
        page.on("console", lambda m: errors.append(f"[{m.type}] {m.text}")
                if m.type in ("error",) else None)

        await page.goto(args.url, wait_until="networkidle")
        await page.wait_for_selector("button:has-text('시작')", timeout=10000)
        await page.click("button:has-text('시작')")
        await page.wait_for_timeout(500)

        # === 1. board 픽셀 rect + target sum 추출 ===
        rect, target = await page.evaluate("""
          () => {
            const board = document.querySelector("div.no-touch-default");
            const r = board.getBoundingClientRect();
            // target sum: "target N" 또는 "목표 합 N" 텍스트 찾기
            let target = null;
            for (const d of document.querySelectorAll('div,span')) {
              const t = (d.innerText||'').trim();
              const m = t.match(/^target\\s+(\\d+)$/i) || t.match(/^목표\\s*합\\s*(\\d+)$/);
              if (m) { target = parseInt(m[1], 10); break; }
            }
            return { rect: { x:r.x, y:r.y, w:r.width, h:r.height }, target };
          }
        """)
        if args.target_num:
            target = args.target_num
        print(f"=== target sum = {target} ===")
        print(f"=== board rect = {rect} ===")

        # === 2. cells 추출 → grid 구성 ===
        cells = await page.evaluate("""
          () => {
            const board = document.querySelector("div.no-touch-default");
            const all = [...board.querySelectorAll("div")];
            const out = [];
            for (const d of all) {
              const t = (d.textContent || "").trim();
              if (/^[1-9]$/.test(t)) {
                const b = d.getBoundingClientRect();
                if (b.width > 0) {
                  out.push({ v: parseInt(t, 10), cx: b.x+b.width/2, cy: b.y+b.height/2 });
                }
              }
            }
            // dedupe
            const seen = new Set();
            return out.filter(c => {
              const k = `${Math.round(c.cx)},${Math.round(c.cy)}`;
              if (seen.has(k)) return false;
              seen.add(k); return true;
            });
          }
        """)
        cw = rect["w"] / 17
        ch = rect["h"] / 10
        grid = [[None] * 17 for _ in range(10)]
        for c in cells:
            col = max(0, min(16, round((c["cx"] - rect["x"]) / cw)))
            row = max(0, min(9, round((c["cy"] - rect["y"]) / ch)))
            grid[row][col] = (c["v"], c["cx"], c["cy"])
        print(f"=== {len(cells)} cells loaded ===")

        # === 3. ★ 엔진 격리 valid_rect 찾기 (함정 7) ===
        def find_valid_rect():
            for r1 in range(10):
                for c1 in range(17):
                    if grid[r1][c1] is None:
                        continue
                    for r2 in range(r1, 10):
                        for c2 in range(c1, 17):
                            s = 0
                            n = 0
                            for r in range(r1, r2 + 1):
                                for cc in range(c1, c2 + 1):
                                    if grid[r][cc] is not None:
                                        s += grid[r][cc][0]
                                        n += 1
                            if s == target and n >= 2:
                                return (r1, c1, r2, c2)
            return None

        valid = find_valid_rect()
        if not valid:
            print(f"ERROR: No valid rectangle found with sum={target}", file=sys.stderr)
            await browser.close()
            return 1

        r1, c1, r2, c2 = valid
        x1 = rect["x"] + (c1 + 0.5) * cw
        y1 = rect["y"] + (r1 + 0.5) * ch
        x2 = rect["x"] + (c2 + 0.5) * cw
        y2 = rect["y"] + (r2 + 0.5) * ch
        print(f"=== valid rect: rows {r1}-{r2}, cols {c1}-{c2} ===")
        print(f"=== drag: ({x1:.0f},{y1:.0f}) -> ({x2:.0f},{y2:.0f}) ===")

        # === 4. mid-drag 스크린샷 (셀렉션 박스 + 합계 라벨) ===
        await page.mouse.move(x1, y1)
        await page.mouse.down()
        for k in range(1, 6):
            await page.mouse.move(
                x1 + (x2 - x1) * k / 5,
                y1 + (y2 - y1) * k / 5,
            )
        await page.wait_for_timeout(150)
        await page.screenshot(path=f"{args.out_dir}/game-mid-drag.png", full_page=True)
        await page.mouse.up()
        await page.wait_for_timeout(400)

        # === 5. 점수/남은 사과 확인 ===
        score_text = await page.evaluate("""
          () => {
            for (const d of document.querySelectorAll('div,span')) {
              const t = (d.innerText||'').trim();
              if (/^\\d+\\s*\\/170$/.test(t) && t.length < 20) return t;
            }
            return null;
          }
        """)
        await page.screenshot(path=f"{args.out_dir}/game-after-drag.png", full_page=True)
        print(f"=== score after drag: {score_text} ===")
        alive_count_expected = 170 - (r2 - r1 + 1) * (c2 - c1 + 1)
        # (r2-r1+1)*(c2-c1+1) 셀의 합이 target, 모두 alive → 그만큼 제거됨
        # (정확히는 그 직사각형 내 alive cell 수 = (r2-r1+1)*(c2-c1+1) — 빈칸 없음 가정)
        print(f"=== expected alive: 170 - {(r2-r1+1)*(c2-c1+1)} = {alive_count_expected} ===")

        # === 6. 모바일 viewport 검증 ===
        if args.mobile:
            await ctx.close()
            mctx = await browser.new_context(
                viewport={"width": 390, "height": 844},
                device_scale_factor=3,
                is_mobile=True,
                has_touch=True,
                locale="ko-KR",
            )
            mpage = await mctx.new_page()
            await mpage.goto(args.url, wait_until="networkidle")
            await mpage.wait_for_selector("button:has-text('시작')", timeout=10000)
            await mpage.click("button:has-text('시작')")
            await mpage.wait_for_timeout(400)
            await mpage.screenshot(path=f"{args.out_dir}/game-mobile-init.png", full_page=True)
            print("=== mobile viewport test passed (스크린샷 저장) ===")
            await mctx.close()

        # === 7. 콘솔 에러 확인 ===
        if errors:
            print("=== ERRORS ===", file=sys.stderr)
            for e in errors:
                print(f"  {e}", file=sys.stderr)
        else:
            print("=== 콘솔 에러 0 ===")

        await browser.close()
        return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
