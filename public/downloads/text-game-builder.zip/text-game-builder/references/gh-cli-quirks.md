# GitHub CLI (`gh`) 비대화형 함정 모음

> `text-game-builder` 워크플로에서 자주 쓰는 gh 명령들의 비대화형 사용 함정. 2026-06-12 실전 검증.

## 일반 원칙

PTY가 없는 일반 `terminal` 호출에서 `-y`/`--yes` 플래그만으로 비대화형 실행이 안 될 수 있음. **명령에 컨텍스트(OWNER/REPO)를 절대 지정**하는 게 안전.

## 검증된 함정

### 1. `gh repo rename` 비대화형

**문제**:
```bash
# cwd가 다른 곳에서 실행하면 -y만으로는 confirmation prompt를 못 넘김
gh repo rename new-name -y
# → "HTTP 404" 또는 confirmation prompt 출력
```

**해결**:
```bash
# OLD repo를 --repo로 절대 지정 + -y
gh repo rename <new-name> --repo <OWNER>/<OLD-NAME> --yes
```

**검증**: 2026-06-12, `ai-gm-core` → `ai-gm` rename 성공.

### 2. 디렉토리명 + 원격 URL 동기화

`gh repo rename`은 GitHub 측 이름만 바꿈. 로컬에서:
```bash
# 디렉토리명 변경
mv old-name new-name
cd new-name

# 원격 URL 갱신
git remote set-url origin https://github.com/<OWNER>/<NEW-NAME>.git

# 확인
git remote -v
```

### 3. 인증 확인

```bash
gh auth status 2>&1 | head -20
# → 계정, token, scope 확인
# repo 생성/rename은 'repo' scope 필요
```

## 자주 쓰는 명령 조합 (검증됨)

### 새 repo 생성 + 즉시 푸시
```bash
gh repo create <OWNER>/<NAME> \
  --public \
  --description "<한글 설명>" \
  --source /Users/.../path \
  --remote=origin \
  --push
```

### About(description + topics) 갱신
```bash
gh repo edit <OWNER>/<NAME> \
  --description "<한글 설명>" \
  --homepage "https://github.com/<OWNER>/<REL>" \
  --add-topic "tag1,tag2,tag3"
```

### 푸시된 README 실제 검증
```bash
# GitHub에 푸시 후 mcp_ddg_search_fetch_content로 실제 렌더링 확인
# URL 예: https://github.com/<OWNER>/<NAME>
```

## 일반 디버깅

- `HTTP 404` + 명령이 `repos/...` 형태: repo가 존재하지 않거나 토큰 scope 부족
- `gh: Not Found (HTTP 404)`: 같은 의미
- `gh auth status`로 항상 먼저 확인할 것

## 관련 스킬

- `github-cli` — 일반 gh 명령 레퍼런스
- `oss-python-bootstrap` — Python OSS 부트스트랩 (gh repo create + v태그 패턴)
