# Case Study: ai-gm-core + ai-gm-strategy-war (2026-06-12)

> 첫 번째 "Text Game Builder" 세션의 실제 워크플로. 향후 유사 요청 시 참조용.

## 입력

사용자 요청: "OpenCode/Claude Code/Hermes로 AI 대화형 게임을 만들자. 장르별로 GitHub repo. 컨텍스트 윈도우 부족 해결책은?"

## 세션 타임라인 (~30분)

### Phase 1: 브레인스토밍 (5분)
- 사용자가 결정 6개를 한 번에 제시:
  1. 장르 = 전략/전쟁
  2. 메모리 = 추천한 D안 (하이브리드)
  3. 에이전트 = OpenCode 우선
  4. 저장소 = 장르별
  5. 진행 = 무한
  6. 세션 = 1 게임 = 1 세션

### Phase 2: 레퍼런스 조사 (10분)
- 사용자가 LLM Wiki / 오픈소스 검토 요청
- arxiv 2510.18395 (MASMP) 발견 → **즉시 "정확히 우리 케이스" 단정** ❌
- 사용자가 "RTS 아닌 턴제인데 MASMP가 적합한가?" 짚음
- 재조사: LoreKit, NarrativeEngine-P, SillyTavern Lorebook 발견 → **3-tier + chunk 분류** 가 정답

**학습된 교훈**: 검색 1위 ≠ 우리 케이스 1위. 차원 차이 비교표로 검증 후 추천.

### Phase 3: 아키렉처 문서 작성 (5분)
- `/Users/hjshin/.openclaw/workspace/ai-gm-architecture.md` (14KB)
- 4 Tier 컨텍스트 + 7 엔티티 + 13 MCP 도구 + ASCII 다이어그램 + Phase 로드맵

### Phase 4: README 2개 + repo 생성/푸시 (5분)
- `ai-gm-core` (11.9KB README) + LICENSE + .gitignore
- `ai-gm-strategy-war` (7.1KB README) + LICENSE + .gitignore + games/.gitkeep
- `gh repo create --public --source=<dir> --remote=origin --push` 2회

### Phase 5: 검증 (1분)
- gh repo URL 2개 확인
- 워크스페이스 디렉토리 + GitHub repo 일치 확인

## 산출물

| 종류 | 위치 | 크기 |
|------|------|------|
| 아키텍처 문서 | `~/.openclaw/workspace/ai-gm-architecture.md` | 14KB |
| 코어 repo | https://github.com/sigco3111/ai-gm-core | README 11.9KB |
| 장르 repo | https://github.com/sigco3111/ai-gm-strategy-war | README 7.1KB |
| 로컬 클론 | `~/.openclaw/workspace/ai-gm-{core,strategy-war}/` | (git tracked) |

## 잘 작동한 것

- **브레인스토밍 후 결정 → 즉시 README/아키텍처** — 중간 단계 생략, 한 세션에 결론
- **비교표 형식 후보** — 사용자가 "더 자세히 논의" 선택 → 4개 자료 비교표 제시 → 정답 도출
- **gh repo create --source --push** 한 줄로 repo + push 동시 처리
- **Phase 0 변형** — README만 + LICENSE + .gitignore로 끝, 실제 코드는 다른 PC

## 개선 가능

- **"더 자세히 논의" 선택지**를 처음부터 다른 옵션에 넣었어야 — 사용자가 다시 선택하게 한 번 더
- **장르별 README에 "Tone & Inspiration"** 섹션이 sigco3111님 선호 (CK3/EU4/HOI4) 반영되어 잘 작동
- **MASMP = state machine** 부분 차용 결정 시 별도 표로 정당화했으면 더 좋았을 듯 (현재는 "MASMP 제외"로 결정만)

## 다음 세션이 이 PC에서 할 때

- 사용자가 다른 PC로 이동해서 작업 예정
- Phase 1+: JSON 스키마 → MCP 서버 골격 → 최소 도구 3개
- `python-oss-bootstrap` 스킬의 1~7단계가 본격적으로 시작됨
