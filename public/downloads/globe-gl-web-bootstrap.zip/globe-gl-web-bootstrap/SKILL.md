---
name: globe-gl-web-bootstrap
description: Globe.gl 3D globe + datasets + Vercel bootstrap.
trigger: "react-globe.gl/three-globe 기반 3D 글로브 웹 시각화 부트스트랩. NOAA/OpenSky/Natural Earth 데이터셋 + Vite + Vercel. '글로브 시각화 만들어줘' 등. 흔들림/스크롤/클릭 인터랙션/위키 lazy fetch 등 4대 UI 함정도 함께 처리."
version: 0.2.0
status: battle-tested-2
last_updated: 2026-08-03
metadata:
  hermes:
    tags: [globe.gl, react-globe.gl, three-globe, three.js, vite, react, data-visualization, etopo1, noaa, bathymetry, vercel]
    related_skills: [python-oss-bootstrap, canvas-static-site-pipeline, idea-bank-sync]
---

# Globe.gl Web Bootstrap Recipe

react-globe.gl + Three.js 기반 3D 글로브 웹 시각화 프로젝트를 빠르게 부트스트랩하는 워크플로우. 검증 사례: [sigco3111/deep-ocean v0.1.0](https://github.com/sigco3111/deep-ocean) (2026-08-03, NOAA ETOPO1 42,615개 해저 점 + Natural Earth 110m + Vercel).

## ⚠️ 트리거 시 절대 놓치지 말 것

1. **3-step 사전 검증 우선** — Vite 스캐폴드 → npm install → tsc/esbuild 컴파일 통과 후 데이터 변환에 진입. Globe.gl 버전 호환성 + TypeScript 이슈 사전 차단.
2. **외부 데이터는 변환 후 `public/data/` 정적 서빙** — fetch(`/api/...`) 호출은 CORS + 캐싱 + Vercel Cold Start 3가지 함정 동시 노출. 변환된 JSON을 public에 넣으면 Vercel CDN이 자동 처리.
3. **Vercel 무료 100MB 한도** — 변환 데이터 1\~2MB가 안전선. 200MB+ ETOPO1 원본 NetCDF는 .gitignore로 제외.
4. **PolygonsData(육지) + PointsData(추가 레이어) 분리** — Globe.gl은 한 layer에 두 데이터 혼합 불가. 두 prop 별도 사용.
5. **depthColor/depthAltitude 헬퍼는 항상 별도 함수** — Inline 람다는 디버깅 + 단위테스트 어려움. 컴포넌트 밖 또는 별도 파일.
6. **`globeImageUrl`/`bumpImageUrl`은 unpkg CDN 사용** — `//unpkg.com/three-globe/example/img/earth-blue-marble.jpg`. 자체 호스팅 불필요 (Vercel 비용 절감).

## 🏗️ 검증된 기술 스택 (2026-08-03 기준)

```json
{
  "dependencies": {
    "react": "^19.2.8",
    "react-dom": "^19.2.8",
    "react-globe.gl": "^2.34.4",
    "three": "^0.180.0",
    "three-globe": "^2.34.4"
  },
  "devDependencies": {
    "@types/node": "^24.13.3",
    "@types/react": "^19.2.17",
    "@types/react-dom": "^19.2.3",
    "@types/three": "^0.180.0",
    "@vitejs/plugin-react": "^6.0.4",
    "typescript": "~6.0.2",
    "vite": "^8.2.0"
  }
}
```

`react-globe.gl` 2.34.x ↔ `three-globe` 2.34.x ↔ `three` 0.180.x 버전 호환성 확인됨.

## 🚀 6-Step Recipe (deep-ocean 사례 기반)

### Step 1: Vite 스캐폴드 (13초)

```bash
cd ~/work/github  # 또는 ~/work/github-private
gh repo create sigco3111/<name> --public --description "..."
gh repo clone sigco3111/<name>
cd <name>

# 로컬 검증 폴더는 별도 (/tmp/...)에서
cd /tmp && rm -rf <name>-verify && mkdir <name>-verify && cd <name>-verify
npm create vite@latest . -- --template react-ts -y
```

Vite 8.x는 React 19 기본. `--template react-ts -y`로 비대화형 설치.

### Step 2: Globe.gl 의존성 추가 (13초)

```bash
cd /tmp/<name>-verify
npm install react-globe.gl three three-globe @types/three
```

총 92\~93 packages, 13초.

### Step 3: TypeScript 사전 검증 (필수)

```bash
npx tsc --noEmit -p tsconfig.app.json
```

**반드시 통과 확인.** Vite 템플릿의 미사용 import(`* as THREE`)나 콜백의 미사용 param(`(d: any) =>`)도 TS6133 에러로 빌드 차단.

### Step 4: 데이터셋 다운로드 + 변환 (병렬 가능)

저장소 생성 + 데이터 다운로드를 병렬로:
```bash
# Background A — GitHub repo
gh repo create sigco3111/<name> --public --description "..."

# Foreground — 데이터
curl -sL "<data-url>" -o data/<file>
```

ETOPO1 (NOAA NetCDF) 변환은 `scripts/convert_etopo1.py` 참조. 핵심 함정:
- ETOPO1 `.grd.gz`는 좌표가 `x`/`y` (lat/lon 아님)
- 변수가 `z` (소문자)
- scipy 없어도 numpy nearest-neighbor로 충분

### Step 5: Globe.gl 컴포넌트 + 빌드 검증

`templates/bathymetry-app.tsx` 템플릿 참조. 핵심 5-prop:

```tsx
<Globe
  ref={globeEl}
  globeImageUrl="//unpkg.com/three-globe/example/img/earth-blue-marble.jpg"
  backgroundColor="#000"
  polygonsData={countries.features}  // Natural Earth 육지
  polygonAltitude={() => 0.01}
  polygonCapColor={() => 'rgba(...)'}
  pointsData={oceanPoints}            // ETOPO1 해저
  pointLat={(d) => d.lat}
  pointLng={(d) => d.lon}
  pointColor={(d) => depthColor(d.depth)}
  pointAltitude={(d) => depthAltitude(d.depth)}
  pointRadius={(d) => ...}
  width={window.innerWidth}
  height={window.innerHeight}
/>
```

### Step 6: 번들 검증 + 저장소 푸시

```bash
# vite build는 Hermes shell에서 long-lived process로 거부됨
# → esbuild로 단발성 번들 검증
npx esbuild src/App.tsx --bundle --format=esm \
  --outfile=/tmp/check.js --log-level=warning \
  --define:process.env.NODE_ENV="production"

# 검증 폴더의 코드를 정식 저장소로 복사
cp -r /tmp/<name>-verify/{src,public,scripts,index.html,package.json,tsconfig*,vite.config.ts} ~/work/github/<name>/
cd ~/work/github/<name>
npm install
git add -A
git commit -m "feat: <name> v0.1.0 — Globe.gl + <data> 시각화"
git push origin main

# GitHub raw fetch 검증 (5/5 200 OK 목표)
for f in README.md package.json src/App.tsx public/data/<file>.json scripts/<script>.py; do
  echo "$(curl -s -o /dev/null -w '%{http_code}' https://raw.githubusercontent.com/sigco3111/<name>/main/$f)  $f"
done
```

## ⚠️ 검증된 함정 (Pitfalls)

### Pit 1: Hermes venv의 pip이 깨져있음
Hermes venv(`/Users/mac/.hermes/hermes-agent/venv/`)의 pip이 다음 에러로 동작 안 함:
```
TypeError: dataclass() got an unexpected keyword argument 'slots'
```

**해결: env 격리 + system Python + user 패키지**
```bash
unset VIRTUAL_ENV PYTHONHOME PYTHONPATH
env -i HOME=/Users/mac PATH=/usr/local/bin:/usr/bin:/bin PYTHONPATH= /usr/bin/python3 \
  /usr/bin/python3 /path/to/script.py
```

`/usr/bin/python3`는 macOS Xcode 3.9.6. 사용자 패키지는 `/Users/mac/Library/Python/3.9/lib/python/site-packages`. xarray, netCDF4, numpy 모두 여기 있음.

### Pit 2: ETOPO1 .grd.gz는 좌표가 x/y
대부분의 Python 예제가 lat/lon으로 가정하지만 ETOPO1은:
- 차원: `x` (21601), `y` (10801)
- 변수: `z` (소문자)
- lat range: -90\~90, lon range: -180\~180

**해결: 차원 이름 추론 + numpy nearest-neighbor 다운샘플**
```python
lat_name = next((c for c in ['lat','latitude','y'] if c in da.coords), None)
lon_name = next((c for c in ['lon','longitude','x'] if c in da.coords), None)

orig_lat = da.coords[lat_name].values
orig_lon = da.coords[lon_name].values

def nearest_idx(arr, vals):
    return np.array([np.argmin(np.abs(arr - v)) for v in vals])

z_small = z_full[np.ix_(nearest_idx(orig_lat, target_lats),
                        nearest_idx(orig_lon, target_lons))]
```

### Pit 3: scipy가 system Python user packages에도 없음
xarray의 `interp(method='linear')`이 scipy를 요구. system python user packages에 scipy가 없어도 numpy nearest-neighbor로 1° 다운샘플은 충분히 매끄러움.

### Pit 4: vite build는 shell guard에 의해 거부됨
Hermes의 terminal tool이 `npx vite build`를 long-lived process로 인식해 거부. **esbuild 직접 사용**으로 우회:
```bash
npx esbuild src/App.tsx --bundle --format=esm --outfile=/tmp/check.js
```

### Pit 5: Globe.gl README에는 bathymetry/elevation 예제 없음
직접 패턴 만들어야 함. 검증된 구조:
- `polygonsData` + `polygonCapColor` → Natural Earth 육지 배경
- `pointsData` + `pointColor` + `pointAltitude` → 사용자 데이터 레이어
- 색상은 수심/고도 구간별 분기 (5단계 색상 그라데이션)

### Pit 6: TypeScript TS6133 unused warning이 빌드 차단
Vite 8.x + React 19 템플릿:
- `import * as THREE from 'three'` — 사용 안 해도 경고
- `polygonAltitude={(d: any) => ...}` — d 미사용 시 경고

**반드시 사전 패치**. tsc `--noEmit` 통과 후 번들.

### Pit 7: 4MB 번들은 Globe.gl normal
react-globe.gl + three + three-globe + React 19 합쳐서 4\~5MB. 코드 자체 작아도 어쩔 수 없음. **Vite 코드 스플리팅은 효과 미미** (Globe.gl이 단일 entry).

### Pit 8: Vercel 자동 감지 정확도
Vercel은 Vite 프로젝트를 자동 감지하지만 `package.json`에 `"type": "module"`이 명시되어야 ESM 빌드 정상 동작.

### Pit 9: Globe.gl 흔들림 + 가로 스크롤 4가지 원인 동시 발생 (deep-ocean v0.2.1 실측, ★★★)

사용자 보고: "화면이 좌우로 흔들리면서 스크롤됨" → 진단 결과 **4가지 원인이 동시에** 작용:

**(1) `htmlElementsData`로 DOM 핀 N개 생성 → 마우스 드래그와 충돌**
Globe.gl의 `htmlElementsData`/`htmlElement` prop은 `<div>` DOM element를 globe surface 위에 띄움. 50개 이상이면 마우스 hover/drag 시 Globe.gl 자체 드래그 rotate와 충돌하면서 **element가 끌려가는 듯한 좌우 진동** 발생.

**해결: DOM 핀 완전 제거 → WebGL `ringsData`로 통합** + 글로브 자체 클릭 (`onGlobeClick`) 사용.

**(2) `width/height={window.innerWidth}` JS prop이 매 프레임 reflow 유발**
Globe.gl은 이 prop이 바뀌면 canvas를 destroy + recreate. 자동 회전 인터벌(30ms)이 돌면서 미세 흔들림 발생.

**해결: JS prop 제거 → CSS로 통일**
```css
#root canvas {
  width: 100vw !important;
  height: 100vh !important;
  position: absolute !important;
  top: 0 !important;
  left: 0 !important;
}
```

**(3) `#root`가 `position: fixed` 아님 → viewport 초과 시 흔들림**
Vite 템플릿의 `#root`는 `position: static`. Globe.gl canvas가 살짝 viewport 밖으로 나가면 페이지 reflow 발생.

**해결: `#root { position: fixed; overflow: hidden; top: 0; left: 0 }`**

**(4) `body` overscroll + touch action 미차단 → 트랙패드/모바일에서 rubber-band 스크롤**
macOS 트랙패드 two-finger swipe 시 body가 scroll됨.

**해결:**
```css
body {
  overflow: hidden;
  overscroll-behavior: none;   /* rubber-band 차단 */
  touch-action: none;         /* 모바일 핀치/스크롤 차단 */
}
```

**4가지 모두 동시 적용 필수**. 어느 하나만 빠지면 흔들림 잔존.

### Pit 10: 클릭 가능한 feature = DOM 핀 ❌, 글로브 onGlobeClick + 거리 임계값 ✅

DOM element로 클릭 가능한 마커를 만들려는 함정 3가지:
- `htmlElement`에 `onclick` 직접 부착 → Globe.gl drag-rotate 가로채서 event bubbling 깨짐
- `<button>` layer를 globe 위에 겹치기 → z-index 충돌 + 페이지 reflow
- 50+ DOM element → Pit 9의 흔들림 원인

**해결 패턴 — 글로브 자체 `onGlobeClick` + 거리 임계값**:
```tsx
onGlobeClick={({ lat, lng }) => {
  if (!features.length) return;
  let best: Feature | null = null;
  let bestDist = Infinity;
  for (const f of features) {
    const d = Math.hypot(f.lat - lat, f.lon - lng);
    if (d < bestDist) { bestDist = d; best = f; }
  }
  if (best && bestDist < 5) {  // 5° 반경 내만 인정
    handleFeatureClick(best);
  }
}}
```

5° 임계값 = globe surface distance ~ 1000km. 너무 좁으면 마리아나 해구 vs 일본 해구처럼 가까운 feature miss. 너무 넓으면 잘못된 feature 클릭으로 인식.

### Pit 11: 위키백과 Wikidata P31 인스턴스 분류는 일관성 없음

해구/산맥/화산 같은 지질 feature를 Wikidata로 가져오려 하면 P31 (instance of) 분류가 항목마다 다름:
- Q23498 (해구) → 일부 항목만 등록, 대부분 disambig 페이지
- Q3762354 (해저 산맥) → 0개
- Q55633515 (해저 화산) → 0개

**해결: Wikidata SPARQL 직접 조회 포기 → Wikipedia category API + REST page summary 조합**:
1. `en.wikipedia.org/w/api.php?action=query&list=categorymembers&cmtitle=Category:Oceanic_trenches_of_the_Pacific_Ocean` — 카테고리 멤버 일괄 추출
2. 각 항목의 `pageprops.wikibase_item` (Q-ID) 가져오기
3. Wikidata SPARQL로 `Q-ID` 묶음의 좌표(P625) 일괄 조회 — **POST 방식 (GET은 User-Agent 적용 안 됨)**
4. 클릭 시점 lazy fetch: `en.wikipedia.org/api/rest_v1/page/summary/<title>` → `extract` + `thumbnail`

배치 크기 50개 권장. 100+ 요청 시 SPARQL rate limit 429.

### Pit 12: Globe.gl 정보 패널 = absolute + backdrop-filter + pointerEvents 분기

`pointerEvents: 'none'` 기본값 + 사이드 패널만 `pointerEvents: 'auto'`. 그렇지 않으면 panel 위 마우스가 글로브에 가로채져 클릭/드래그가 panel 위에서도 globe에 적용됨.

글래스모피즘 = `backdropFilter: 'blur(8px)'` + `WebkitBackdropFilter: 'blur(8px)'` (Safari 호환) + `background: 'rgba(0, 16, 32, 0.78)'` + `border: '1px solid rgba(100, 180, 240, 0.25)'` + `boxShadow: '0 4px 24px rgba(0, 0, 0, 0.4)'`.

### Pit 13: `globeEl.current.pointOfView()` 자동 회전 시 lng 무한 증가 → 미세 floating-point drift

`pointOfView({ lat, lng: cp.lng + 0.3, altitude: cp.altitude })` 패턴으로 자동 회전 시 lng 값이 무한히 증가 (작지만 floating-point 정밀도 손실 발생). 30분+ 회전 후 가끔 미세 jitter 발생 가능.

**해결**: 회전 간격을 충분히 크게 (예: lng += 0.5) + 필요 시 `Math.round(cp.lng) % 360`로 정규화. 실측에서는 v0.2.1까지 발생 안 했지만 미리 인지.

## 🔗 Globe.gl 패턴 카탈로그 (v0.2.1 추가)

| 패턴 | Prop | 사례 | 사례 repo |
|------|------|------|----------|
| 육지 배경 | `polygonsData` | Natural Earth 110m countries | deep-ocean |
| 데이터 점 | `pointsData` + `pointColor` + `pointAltitude` | ETOPO1 42,615개 해저 점 | deep-ocean |
| 항공 경로 | `arcsData` + `arcColor` + `arcDashLength` | OpenSky 항공기 추적 | sky-radar (예정) |
| 헥사곤 격자 | `hexBinPointsData` + `hexBinPointWeight` | 데이터 밀도 히트맵 | (예정) |
| 3D mesh | `objectsData` + `objectThreeObject` | 건물/지형 3D 모델 | (예정) |
| **펄스 링 (NEW)** | `ringsData` + `ringColor` + `ringMaxRadius` + `ringPropagationSpeed` + `ringRepeatPeriod` | feature 위치 pulsing 표시 | **deep-ocean v0.2.0+** |
| **글로브 클릭 (NEW)** | `onGlobeClick` | 5° 반경 내 가장 가까운 feature 선택 | **deep-ocean v0.2.0+** |
| **Wikipedia lazy fetch (NEW)** | `fetch('https://en.wikipedia.org/api/rest_v1/page/summary/<title>')` | 클릭 시점 detail 정보 로딩 | **deep-ocean v0.2.0+** |

## 🔗 Wikipedia 데이터 수집 워크플로우 (deep-ocean v0.2.0 신규)

해저 feature 90개를 직접 수집한 검증된 패턴 (`scripts/build_features.py`):

```python
# 1) EN Wiki 카테고리 멤버 일괄 추출
categories = [
    ("trench", "Category:Oceanic_trenches_of_the_Pacific_Ocean"),
    ("trench", "Category:Oceanic_trenches_of_the_Atlantic_Ocean"),
    ("seamount", "Category:Submarine_volcanoes"),
    # ...
]
# cmcontinue로 페이지네이션 처리, disambig/리스트 페이지 제외

# 2) pageprops.wikibase_item으로 Q-ID 매핑
# 3) Wikidata SPARQL POST로 P625 좌표 일괄 (50개씩 배치)
# 4) features.json 저장
```

참조: `scripts/build_features.py` (deep-ocean에서 그대로 재사용 가능).

## 🔗 Globe.gl 패턴 카탈로그

| 패턴 | Prop | 사례 | 사례 repo |
|------|------|------|----------|
| 육지 배경 | `polygonsData` | Natural Earth 110m countries | deep-ocean |
| 데이터 점 | `pointsData` + `pointColor` + `pointAltitude` | ETOPO1 42,615개 해저 점 | deep-ocean |
| 항공 경로 | `arcsData` + `arcColor` + `arcDashLength` | OpenSky 항공기 추적 | sky-radar (예정) |
| 헥사곤 격자 | `hexBinPointsData` + `hexBinPointWeight` | 데이터 밀도 히트맵 | (예정) |
| 3D mesh | `objectsData` + `objectThreeObject` | 건물/지형 3D 모델 | (예정) |

## 📁 관련 파일

- **`references/etopo1-conversion.md`** — ETOPO1 NetCDF → JSON 변환 전체 레시피 (env 격리, x/y naming, numpy 다운샘플)
- **`references/globe-gl-patterns.md`** — Globe.gl 레이어 4종 (PointsLayer/PolygonLayer/ArcLayer/HexagonLayer) 사용 패턴 + 데이터 매핑 헬퍼
- **`templates/bathymetry-app.tsx`** — PointsLayer 시작 템플릿 (deep-ocean 사례 기반)
- **`scripts/convert_etopo1.py`** — 검증된 ETOPO1 변환 스크립트 (deep-ocean에서 사용, 그대로 재사용 가능)

## 🔗 관련 스킬

- `python-oss-bootstrap` — HTML/Canvas single-file 변형 (Globe.gl 단일 HTML이 아닌 Vite 프로젝트이므로 별도)
- `canvas-static-site-pipeline` — 미니앱 E2E 파이프라인 (Vercel 배포 단계 차용)
- `idea-bank-sync` — 본 프로젝트의 idea-bank 동기화 시 (deep-ocean을 3D_Globe 카테고리에 정식 추가)

## 📋 검증 사례

**v0.1.0 (2026-08-03)**: [sigco3111/deep-ocean v0.1.0](https://github.com/sigco3111/deep-ocean) — NOAA ETOPO1 42,615개 해저 점 + Natural Earth 110m + Vercel
- ✅ Vite 스캐폴드 13초
- ✅ npm install 92 packages, 11초
- ✅ tsc --noEmit 0 에러 (TS6133 2개 사전 수정 후)
- ✅ esbuild 번들 4.0 MB
- ✅ NOAA ETOPO1 376 MB → 1.88 MB
- ✅ 마리아나 해구 lat 14°N, lon 142°E, -10,898m 정확히 식별
- ✅ GitHub raw fetch 5/5 200 OK
- ✅ 푸시 후 0 에러

**v0.2.1 (2026-08-03)**: deep-ocean Tier 2 — 90개 해구/화산 클릭 인터랙션
- ✅ Wikipedia category API + Wikidata SPARQL POST로 feature 90개 수집 (해구 35 + 해저 화산 55)
- ✅ WebGL `ringsData` pulsing ring + 글로브 `onGlobeClick` (5° 반경)
- ✅ Wikipedia REST API lazy fetch (클릭 시점)
- ✅ 4가지 UI 함정 동시 해결 (Pit 9)
  - htmlElementsData → ringsData (DOM 충돌 제거)
  - width/height JS prop → CSS 100vw/100vh !important (reflow 제거)
  - #root position: fixed + overflow: hidden (viewport 고정)
  - body overscroll-behavior: none + touch-action: none (rubber-band 차단)
- ✅ esbuild 번들 4.2 MB (인터랙션 추가로 +0.2 MB만 증가)
