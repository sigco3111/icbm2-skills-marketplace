import Globe from 'react-globe.gl';
import { useEffect, useRef, useState } from 'react';

/**
 * PointsLayer 시작 템플릿 — sigco3111/deep-ocean 사례 기반.
 *
 * 사전 요구:
 * - public/data/countries.json (Natural Earth 110m)
 * - public/data/ocean_points.json ([{ lat, lon, depth }, ...])
 *
 * 사용법:
 * 1. 이 파일을 src/App.tsx로 복사
 * 2. ocean_points.json의 스키마에 맞춰 헬퍼 함수 조정
 * 3. 색상 구간은 데이터 도메인에 맞게 수정
 */

// ─── 데이터 → 색상/높이 헬퍼 ─────────────────────────────────────────

// 해저 깊이 → 색상 (5단계 그라데이션)
function depthColor(depth: number): string {
  if (depth < 200)  return '#1e5f8e';   // 천해 (대륙붕)
  if (depth < 1000) return '#15456b';   // 대륙사면
  if (depth < 3000) return '#0c314d';   // 심해 평원
  if (depth < 6000) return '#062236';   // 심해
  return '#011826';                      // 해구 (>6000m)
}

// 해저 깊이 → Globe.gl 점 높이 (0~0.05 범위로 cap)
function depthAltitude(depth: number): number {
  return Math.min(0.05, depth / 200000);
}

// ─── 메인 컴포넌트 ────────────────────────────────────────────────────

interface OceanPoint {
  lat: number;
  lon: number;
  depth: number;
}

interface Country {
  type: string;
  properties: { name: string };
  geometry: any;
}

function App() {
  const globeEl = useRef<any>(null);
  const [oceanPoints, setOceanPoints] = useState<OceanPoint[]>([]);
  const [countries, setCountries] = useState<{ features: Country[] }>({ features: [] });
  const [loaded, setLoaded] = useState(false);
  const [stats, setStats] = useState({ maxDepth: 0, minDepth: 0, points: 0 });

  useEffect(() => {
    // 1) Natural Earth countries (육지 배경)
    fetch('/data/countries.json')
      .then((r) => r.json())
      .then((d: { features: Country[] }) => setCountries(d))
      .catch(console.error);

    // 2) 데이터 점 (예: ETOPO1 해저)
    fetch('/data/ocean_points.json')
      .then((r) => r.json())
      .then((d: OceanPoint[]) => {
        setOceanPoints(d);
        const depths = d.map((p) => p.depth);
        setStats({
          maxDepth: Math.max(...depths),
          minDepth: Math.min(...depths),
          points: d.length,
        });
        setLoaded(true);
      })
      .catch(console.error);

    // 3) 자동 회전 (30ms마다 lng +0.3°)
    const id = setInterval(() => {
      if (globeEl.current) {
        const cp = globeEl.current.pointOfView();
        globeEl.current.pointOfView({
          lat: cp.lat,
          lng: cp.lng + 0.3,
          altitude: cp.altitude,
        });
      }
    }, 30);
    return () => clearInterval(id);
  }, []);

  return (
    <div style={{ width: '100vw', height: '100vh', background: '#000' }}>
      <Globe
        ref={globeEl}
        // unpkg CDN 사용 — 자체 호스팅 불필요
        globeImageUrl="//unpkg.com/three-globe/example/img/earth-blue-marble.jpg"
        bumpImageUrl="//unpkg.com/three-globe/example/img/earth-topology.png"
        backgroundColor="#000"

        // ── PolygonsLayer: Natural Earth 육지 ──
        polygonsData={countries.features}
        polygonAltitude={() => 0.01}
        polygonCapColor={() => 'rgba(30, 95, 142, 0.4)'}
        polygonSideColor={() => 'rgba(15, 50, 80, 0.2)'}
        polygonStrokeColor={() => '#1a3a5a'}

        // ── PointsLayer: 데이터 점 ──
        pointsData={oceanPoints}
        pointLat={(d: OceanPoint) => d.lat}
        pointLng={(d: OceanPoint) => d.lon}
        pointColor={(d: OceanPoint) => depthColor(d.depth)}
        pointAltitude={(d: OceanPoint) => depthAltitude(d.depth)}
        pointRadius={(d: OceanPoint) => Math.max(0.15, Math.min(0.4, d.depth / 80000))}
        pointResolution={6}

        width={window.innerWidth}
        height={window.innerHeight}
      />

      {/* 좌상단 정보 패널 */}
      <div
        style={{
          position: 'absolute',
          top: 16,
          left: 16,
          color: '#fff',
          fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
          background: 'rgba(0, 20, 40, 0.75)',
          padding: '12px 16px',
          borderRadius: 8,
          border: '1px solid rgba(100, 180, 240, 0.3)',
          fontSize: 13,
          lineHeight: 1.5,
          pointerEvents: 'none',
        }}
      >
        <div style={{ fontSize: 16, fontWeight: 600, marginBottom: 4 }}>
          🐋 deep-ocean
        </div>
        <div style={{ opacity: 0.7, fontSize: 11 }}>
          전 세계 심해 지형 3D 인터랙티브 시각화
        </div>
        <div style={{ marginTop: 8, opacity: 0.85 }}>
          📊 데이터: NOAA ETOPO1 (1° 격자)
          <br />
          🌊 해저 점: {loaded ? `${stats.points.toLocaleString()}개` : '로딩…'}
          <br />
          📉 최대 수심: {loaded ? `${stats.maxDepth.toFixed(0)}m` : '–'}
          <br />
          📈 최소 수심: {loaded ? `${stats.minDepth.toFixed(0)}m` : '–'}
        </div>
      </div>
    </div>
  );
}

export default App;
