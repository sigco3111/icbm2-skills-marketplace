#!/usr/bin/env python3
"""ETOPO1 NetCDF → Globe.gl bathymetry JSON 변환

검증: sigco3111/deep-ocean v0.1.0 (2026-08-03)

사용법:
    unset VIRTUAL_ENV PYTHONHOME PYTHONPATH
    /usr/bin/python3 convert_etopo1.py

출력:
    bathymetry.json — 전체 180×360 격자 (0.5MB)
    ocean_points.json — 해저 점만 (1.9MB, Globe.gl PointsLayer 입력)

환경:
    xarray, netCDF4, numpy 필요 (Hermes venv pip 깨짐 → system python 우회)
    scipy 없어도 nearest-neighbor로 충분
"""

import os
import sys
import time
import gzip
import json

# 격리 환경 강제 — Hermes venv의 pip/dataclass 오류 우회
os.environ.pop('VIRTUAL_ENV', None)
os.environ.pop('PYTHONHOME', None)
os.environ['PYTHONPATH'] = ''

import numpy as np

# xarray/netCDF4는 script 호출자가 미리 설치해야 함
import xarray as xr

DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'public', 'data')
os.makedirs(DATA_DIR, exist_ok=True)

ETOPO1_URL = 'https://www.ngdc.noaa.gov/mgg/global/relief/ETOPO1/data/ice_surface/grid_registered/netcdf/ETOPO1_Ice_g_gmt4.grd.gz'
gz_path = os.path.join(DATA_DIR, '..', '..', 'data', 'ETOPO1.grd.gz')  # gitignore 대상
nc_path = os.path.join(DATA_DIR, '..', '..', 'data', 'ETOPO1.nc')


def download_if_missing():
    if not os.path.exists(nc_path):
        if not os.path.exists(gz_path):
            print(f'[1/4] ETOPO1 다운로드 (~377MB, 5분 소요)...')
            print(f'  URL: {ETOPO1_URL}')
            import urllib.request
            urllib.request.urlretrieve(ETOPO1_URL, gz_path)
        print(f'[1/4] 압축 해제 중...', flush=True)
        t0 = time.time()
        with gzip.open(gz_path, 'rb') as f_in, open(nc_path, 'wb') as f_out:
            chunk = 64 * 1024 * 1024
            while True:
                block = f_in.read(chunk)
                if not block: break
                f_out.write(block)
        print(f'  완료: {time.time()-t0:.1f}초, {os.path.getsize(nc_path)/1024/1024:.0f} MB')


def convert():
    print('[2/4] NetCDF 로드...', flush=True)
    t0 = time.time()
    ds = xr.open_dataset(nc_path, engine='netcdf4')
    zvar = list(ds.data_vars)[0]  # 보통 'z'
    da = ds[zvar]
    print(f'  변수: {zvar}, 차원: {dict(ds.sizes)}', flush=True)
    print(f'  z 범위: {float(da.min()):.1f}m ~ {float(da.max()):.1f}m', flush=True)
    print(f'  로드 시간: {time.time()-t0:.1f}초', flush=True)

    # ETOPO1 .grd.gz는 좌표가 x/y (lat/lon 아님) — Pit 2 참조
    lat_name = next((c for c in ['lat', 'latitude', 'y'] if c in da.coords), None)
    lon_name = next((c for c in ['lon', 'longitude', 'x'] if c in da.coords), None)
    if lat_name is None or lon_name is None:
        raise SystemExit(f'lat/lon 좌표 추론 실패. coords={list(da.coords)}')

    # 1° 격자로 다운샘플 (numpy nearest-neighbor — scipy 없음 우회)
    print('[3/4] 다운샘플링 (1° 격자, 180×360)...', flush=True)
    target_lats = np.arange(-89.5, 90, 1.0)
    target_lons = np.arange(-179.5, 180, 1.0)

    orig_lat = da.coords[lat_name].values
    orig_lon = da.coords[lon_name].values
    z_full = da.values

    def nearest_idx(arr, vals):
        return np.array([np.argmin(np.abs(arr - v)) for v in vals])

    lat_idx = nearest_idx(orig_lat, target_lats)
    lon_idx = nearest_idx(orig_lon, target_lons)
    z = z_full[np.ix_(lat_idx, lon_idx)]

    print(f'  다운샘플 완료: {z.shape}, {time.time()-t0:.1f}초', flush=True)

    # JSON 저장
    print('[4/4] 데이터 저장...', flush=True)
    ocean_mask = z < 0
    land_mask = z >= 0
    print(f'  해저 점: {ocean_mask.sum():,} / 총 {z.size:,}')
    print(f'  가장 깊은 곳: {z.min():.0f}m')

    # 1) 전체 격자 (클라이언트 측 분석용)
    bathymetry = {
        'lats': target_lats.tolist(),
        'lons': target_lons.tolist(),
        'depths': z.astype(np.float32).tolist(),
        'meta': {
            'source': 'NOAA ETOPO1 Ice Surface',
            'url': ETOPO1_URL,
            'resolution': '1 degree',
            'min_depth': float(z.min()),
            'max_depth': float(z.max()),
            'shape': list(z.shape),
        }
    }
    bath_path = os.path.join(DATA_DIR, 'bathymetry.json')
    with open(bath_path, 'w') as f:
        json.dump(bathymetry, f)
    print(f'  bathymetry.json: {os.path.getsize(bath_path)/1024/1024:.2f} MB')

    # 2) Globe.gl PointsLayer용 — 해저 점만
    points = []
    for i, lat in enumerate(target_lats):
        for j, lon in enumerate(target_lons):
            depth = float(z[i, j])
            if depth < 0:
                points.append({
                    'lat': float(lat),
                    'lon': float(lon),
                    'depth': -depth,  # 양수 = 깊이
                })

    pts_path = os.path.join(DATA_DIR, 'ocean_points.json')
    with open(pts_path, 'w') as f:
        json.dump(points, f)
    print(f'  ocean_points.json: {len(points):,}개 점, {os.path.getsize(pts_path)/1024/1024:.2f} MB')

    print()
    print('=== 변환 완료 ===')
    print(f'  bathymetry.json: {os.path.getsize(bath_path)/1024/1024:.2f} MB')
    print(f'  ocean_points.json: {os.path.getsize(pts_path)/1024/1024:.2f} MB')


if __name__ == '__main__':
    download_if_missing()
    convert()
