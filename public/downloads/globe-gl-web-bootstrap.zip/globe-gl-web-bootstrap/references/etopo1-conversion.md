# ETOPO1 NetCDF → Globe.gl 변환 레시피

NOAA ETOPO1 Ice Surface 데이터를 react-globe.gl의 PointsLayer 입력으로 변환하는 전체 절차. sigco3111/deep-ocean v0.1.0 (2026-08-03)에서 검증.

## ⚠️ 핵심 함정 3개

### 1. Hermes venv의 pip이 깨져있음

Hermes venv(`/Users/mac/.hermes/hermes-agent/venv/`)의 pip이 다음 에러로 동작 안 함:

```
File "/Users/mac/.hermes/hermes-agent/venv/lib/python3.11/site-packages/pip/_internal/locations/__init__.py", line 10, in <module>
  from pip._internal.models.scheme import SCHEME, Scheme
TypeError: dataclass() got an unexpected keyword argument 'slots'
```

Python 3.11 dataclass에 `slots=True`가 추가된 게 원인 (PEP 681). 시스템 pip의 버그.

**해결: env 격리 + system Python + user packages**

```bash
unset VIRTUAL_ENV PYTHONHOME PYTHONPATH
env -i HOME=/Users/mac PATH=/usr/local/bin:/usr/bin:/bin PYTHONPATH= /usr/bin/python3 /path/to/script.py
```

- `/usr/bin/python3` = macOS Xcode 3.9.6
- 사용자 패키지: `/Users/mac/Library/Python/3.9/lib/python/site-packages`
- xarray 2024.7.0, netCDF4 1.7.2, numpy 2.4.3 모두 설치되어 있음

**xarray는 격리 환경에서 import 가능**하지만 `execute_code` sandbox는 다른 Python이에서 import 불가. 무조건 terminal의 system python으로.

### 2. ETOPO1 .grd.gz는 좌표가 x/y (lat/lon 아님)

대부분 Python 예제가 lat/lon으로 가정하지만 ETOPO1 netCDF는:

- 차원: `x` (21601), `y` (10801)
- 변수: `z` (소문자)
- 좌표 값: lat -90\~90, lon -180\~180

xarray `interp(lat=..., lon=...)` 호출 시:

```
ValueError: Dimensions {'lat', 'lon'} do not exist.
Expected one or more of FrozenMappingWarningOnValuesAccess({'x': 21601, 'y': 10801})
```

**해결: 차원 이름 추론 후 numpy 다운샘플**

```python
lat_name = next((c for c in ['lat','latitude','y'] if c in da.coords), None)
lon_name = next((c for c in ['lon','longitude','x'] if c in da.coords), None)

orig_lat = da.coords[lat_name].values  # y coords
orig_lon = da.coords[lon_name].values  # x coords
z_full = da.values  # shape (lat_size, lon_size)

# nearest-neighbor
def nearest_idx(arr, vals):
    return np.array([np.argmin(np.abs(arr - v)) for v in vals])

z_small = z_full[np.ix_(nearest_idx(orig_lat, target_lats),
                        nearest_idx(orig_lon, target_lons))]
```

### 3. scipy가 system Python user packages에도 없음

xarray의 `interp(method='linear')`은 scipy가 필요. system Python에 scipy 없음 → numpy nearest-neighbor로 다운샘플.

1° 격자 다운샘플에는 nearest-neighbor로도 충분히 매끄러움. 6 arc-minute처럼 더 세밀한 다운샘플 시엔 scipy 직접 설치 필요 (`/usr/bin/python3 -m pip install --user scipy`).

## 📊 변환 출력 (deep-ocean 사례)

| 출력 파일 | 크기 | 내용 | 용도 |
|----------|------|------|------|
| `bathymetry.json` | 0.51 MB | 전체 180×360 격자 | 클라이언트 측 슬라이더/분석 |
| `ocean_points.json` | 1.88 MB | 해저 점 42,615개 | Globe.gl `pointsData` 직접 입력 |

**검증 결과**:
- 가장 깊은 곳: -9,200m (deep-ocean은 downsampling 때문에 -10,898m → -9,200m, 원본은 마리아나 해구 정확)
- 가장 높은 곳: +5,855m
- 해저 비율: 65.7% (42,615 / 64,800)

## 🚀 다운로드 시간

| 단계 | 시간 | 비고 |
|------|------|------|
| 377MB .gz 다운로드 | 270초 | NOAA 서버 |
| 압축 해제 (890MB) | 2.2초 | 로컬 |
| NetCDF 로드 | 5\~6초 | xarray |
| 다운샘플 180×360 | <1초 | numpy |
| JSON 저장 | 1\~2초 | |

## 🔗 환경 검증 명령

```bash
# 격리 환경 + 사용자 패키지 동작 확인
unset VIRTUAL_ENV PYTHONHOME PYTHONPATH
env -i HOME=/Users/mac PATH=/usr/local/bin:/usr/bin:/bin PYTHONPATH= /usr/bin/python3 -c "
import xarray as xr
import netCDF4
import numpy as np
print(f'xarray {xr.__version__}')
print(f'netCDF4 {netCDF4.__version__}')
print(f'numpy {np.__version__}')
"
```

## 🔗 다음 단계 옵션

- **고해상도 다운샘플** (6 arc-minute, 1800×900): scipy 설치 + interp1d → 파일 크기 7\~10MB
- **해구 등고선 추출**: matplotlib contour → GeoJSON LineString
- **Web Worker 변환**: 클라이언트 측에서 bathymetry.json → 사용자 정의 색상 슬라이더
