# Globe.gl Layer Patterns

react-globe.gl의 4가지 핵심 레이어 패턴 + 사용 사례. 검증 사례: sigco3111/deep-ocean v0.1.0 (2026-08-03).

## 1. PolygonsLayer (육지/국가 배경)

**용도**: Natural Earth countries, 행정구역, 보호구역

```tsx
<Globe
  polygonsData={countries.features}  // GeoJSON FeatureCollection
  polygonAltitude={(d) => 0.01}        // 0~1 범위 (radius 대비)
  polygonCapColor={() => 'rgba(30, 95, 142, 0.4)'}  // 상단 색
  polygonSideColor={() => 'rgba(15, 50, 80, 0.2)'}  // 측면 색
  polygonStrokeColor={() => '#1a3a5a'}               // 윤곽선
  polygonLabel={(d) => `
    <div style="background:rgba(0,0,0,0.7);padding:4px 8px;border-radius:4px">
      <b>${d.properties.name}</b>
    </div>
  `}
/>
```

**데이터 소스**: [Natural Earth](https://www.naturalearthdata.com/) 110m/50m/10m countries (GeoJSON)

## 2. PointsLayer (데이터 점)

**용도**: ETOPO1 해저 점, 화산 위치, 측정소 위치

```tsx
<Globe
  pointsData={points}  // [{ lat, lon, value, ... }, ...]
  pointLat={(d) => d.lat}
  pointLng={(d) => d.lon}
  pointColor={(d) => depthColor(d.value)}     // 6자 hex or rgba
  pointAltitude={(d) => depthAltitude(d.value)} // 0~0.05 typical
  pointRadius={(d) => Math.max(0.15, Math.min(0.4, d.value / 80000))}
  pointResolution={6}  // 4~8 (low=fast, high=smooth)
  pointLabel={(d) => `<div>${d.value}m</div>`}
/>
```

**색상 헬퍼 패턴** (구간별 그라데이션):

```typescript
function depthColor(depth: number): string {
  if (depth < 200)  return '#1e5f8e';   // 천해
  if (depth < 1000) return '#15456b';   // 대륙사면
  if (depth < 3000) return '#0c314d';   // 심해 평원
  if (depth < 6000) return '#062236';   // 심해
  return '#011826';                      // 해구
}
```

**높이 헬퍼** (값의 범위에 비례):

```typescript
function depthAltitude(depth: number): number {
  return Math.min(0.05, depth / 200000);  // cap at 0.05
}
```

## 3. ArcsLayer (이동 경로)

**용도**: 항공기 비행경로, 해류, 무역로, 마이그레이션

```tsx
<Globe
  arcsData={flights}  // [{ startLat, startLng, endLat, endLng, color }, ...]
  arcColor={(d) => [d.color, d.color]}  // start/end 별 색
  arcDashLength={0.4}
  arcDashGap={2}
  arcDashAnimateTime={3000}
  arcStroke={0.5}
  arcAltitudeAutoScale={0.3}
  arcLabel={(d) => `${d.from} → ${d.to}`}
/>
```

**OpenSky Network 데이터** (실시간 항공기):
- 무료 API: https://opensky-network.org/api/states/all
- 인증 없이도 사용 가능 (rate limit 있음)

## 4. HexagonLayer (밀도 히트맵)

**용도**: 데이터 밀도 시각화, earthquake cluster

```tsx
<Globe
  hexBinPointsData={earthquakes}  // [{ lat, lng, magnitude }, ...]
  hexBinPointWeight={(d) => d.magnitude}
  hexAltitude={(d) => d.sumWeight * 0.01}
  hexTopColor={() => 'rgba(255, 100, 50, 0.8)'}
  hexSideColor={() => 'rgba(255, 100, 50, 0.3)'}
  hexBinResolution={4}
/>
```

## 5. ObjectsLayer (3D mesh)

**용도**: 건물, 산, 위성 모델

```tsx
<Globe
  objectsData={[{ lat: 35.6586, lng: 139.7454, alt: 0.05, model: mountainMesh }]}
/>
```

## 🎨 시각화 패턴 카탈로그

| 데이터 종류 | 권장 Layer | 핵심 Prop | 사례 |
|------------|------------|-----------|------|
| 국가/행정구역 | PolygonsLayer | polygonCapColor | Natural Earth |
| 측정소/위치 | PointsLayer | pointColor + pointAltitude | ETOPO1, 화산 |
| 항공/해류/이동 | ArcsLayer | arcDashAnimateTime | OpenSky, 해류 |
| 밀도/클러스터 | HexagonLayer | hexBinPointWeight | Earthquake, 범죄 통계 |
| 건물/3D 객체 | ObjectsLayer | objectThreeObject | 도시 3D 모델 |
| 실시간 데이터 | PointsLayer + 자동 회전 | pointResolution: 6 | 실시간 트래픽 |
| 위성 궤도 | ArcsLayer + dashed | arcDashLength: 0.1 | satellite-board |

## ⚠️ 공통 함정

1. **Layer prop은 Globe 컴포넌트에 직접** — wrapper 컴포넌트 만들면 props가 안 내려감
2. **점 개수 100K+ 시 성능 저하** — `pointResolution={3}` 또는 HexagonLayer 사용
3. **PolygonsData는 GeoJSON FeatureCollection** — 단순 배열 ❌, `features` 키 필요
4. **자동 회전은 setInterval로 pointOfView 갱신** (deep-ocean 참조):
   ```typescript
   setInterval(() => {
     const cp = globeRef.current.pointOfView();
     globeRef.current.pointOfView({ lat: cp.lat, lng: cp.lng + 0.3, altitude: cp.altitude });
   }, 30);
   ```

## 🔗 데이터 → Layer 빠른 매핑

```
JSON 데이터         →  Globe.gl prop
─────────────────────────────────────────
[{ lat, lon, ... }] →  pointsData + pointLat + pointLng
[{ startLat, ... }] →  arcsData (startLat/startLng/endLat/endLng)
GeoJSON FeatureColl →  polygonsData
GeoJSON LineString  →  pathsData
GeoJSON Point       →  pointsData (pointLat, pointLng)
```

## 🔗 외부 데이터 무료 소스

| 소스 | 종류 | API |
|------|------|-----|
| NOAA ETOPO1 | Bathymetry | .grd.gz 다운로드 |
| Natural Earth | Countries (110m/50m/10m) | GitHub raw |
| OpenSky Network | 실시간 항공기 | REST API |
| USGS | 화산/지진 | GeoJSON feed |
| WHO/CDC | 감염병 | CSV/API |
| NASA Black Marble | 빛공해 | TIF/WMS |
